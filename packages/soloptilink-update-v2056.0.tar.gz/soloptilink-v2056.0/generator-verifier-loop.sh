#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2014.0 - Generator-Verifier Loop
# =============================================================================
# Automated generate -> verify -> fix cycle for production-quality output.
#
# Pattern:
#   Generate code -> Verify (build/lint/test) -> If fails, feed errors back
#   -> Re-generate fix -> Verify again -> Loop until pass or max retries.
#
# This is the single most impactful quality improvement for code generation.
# Instead of hoping the first attempt is correct, we close the loop: every
# generation is verified, and every failure is fed back as a targeted fix
# prompt so the next attempt addresses the exact errors.
#
# Dependencies:
#   - build-verifier.sh (bv_init, bv_verify_all, bv_get_errors)
#
# Functions:
#   gv_init              - Initialize with project directory and config
#   gv_run_cycle         - Main generate -> verify -> fix loop
#   gv_verify            - Run all verifications on project directory
#   gv_build_fix_prompt  - Create targeted fix prompt from errors
#   gv_assess_quality    - Score output 0-100 across 6 axes
#   gv_report            - Summary of attempts, errors, fixes applied
#
# All globals use the GV_ prefix.
# =============================================================================

[[ -n "${_GV_LOOP_LOADED:-}" ]] && return 0
_GV_LOOP_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g GV_VERSION="2.0"
declare -g GV_MAX_RETRIES=3
declare -g GV_BUILD_TIMEOUT=300       # v2015.0: Configurable timeout for slow builds (seconds)
declare -g GV_ERROR_OUTPUT_LIMIT=8000 # v2015.0: Error output limit (was 3000)
declare -g GV_CURRENT_ATTEMPT=0
declare -g GV_PROJECT_DIR=""
declare -g GV_LOG_DIR=""
declare -g GV_LOG_FILE=""
declare -g GV_TOTAL_CYCLES=0
declare -g GV_TOTAL_PASSES=0
declare -g GV_TOTAL_FAILS=0
declare -g GV_LAST_QUALITY_SCORE=0
declare -g GV_CYCLE_HISTORY=""  # JSON array of cycle results

# Colour constants
GV_GREEN='\033[0;32m'   GV_YELLOW='\033[0;33m'  GV_RED='\033[0;31m'
GV_CYAN='\033[0;36m'    GV_PURPLE='\033[0;35m'  GV_BOLD='\033[1m'
GV_DIM='\033[2m'        GV_NC='\033[0m'

# =============================================================================
# _gv_log(level, message)
# =============================================================================
_gv_log() {
    local level="$1" message="$2" color="${GV_NC}"
    case "$level" in
        INFO|SUCCESS) color="${GV_GREEN}"  ;;
        WARN)         color="${GV_YELLOW}" ;;
        ERROR|FAIL)   color="${GV_RED}"    ;;
        STEP)         color="${GV_CYAN}"   ;;
        SECTION)      color="${GV_PURPLE}" ;;
    esac
    echo -e "  ${color}[GV-LOOP:${level}]${GV_NC} ${message}"
    if [[ -n "${GV_LOG_FILE:-}" ]]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [${level}] ${message}" >> "$GV_LOG_FILE" 2>/dev/null || true
    fi
}

# =============================================================================
# _gv_json_escape(string)
# Escape a string for safe JSON embedding.
# =============================================================================
_gv_json_escape() {
    printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g; s/\t/\\t/g' | tr '\n' ' '
}

# =============================================================================
# gv_init(project_dir [, max_retries])
# Initialize the generator-verifier loop for a project.
# =============================================================================
gv_init() {
    local project_dir="${1:?gv_init: project_dir required}"
    local max_retries="${2:-3}"

    GV_PROJECT_DIR="$(cd "$project_dir" 2>/dev/null && pwd)" || {
        _gv_log "ERROR" "Directory not found: $project_dir"
        return 1
    }
    GV_MAX_RETRIES="$max_retries"
    GV_CURRENT_ATTEMPT=0
    GV_TOTAL_CYCLES=0
    GV_TOTAL_PASSES=0
    GV_TOTAL_FAILS=0
    GV_LAST_QUALITY_SCORE=0
    GV_CYCLE_HISTORY="[]"

    GV_LOG_DIR="${GV_PROJECT_DIR}/docs/chain-logs"
    GV_LOG_FILE="${GV_LOG_DIR}/gv-loop_$(date +%Y%m%d_%H%M%S).log"
    mkdir -p "$GV_LOG_DIR" 2>/dev/null || true

    # Initialize build-verifier if available
    if type bv_init &>/dev/null; then
        bv_init "$GV_PROJECT_DIR"
    fi

    _gv_log "SECTION" "Generator-Verifier Loop v${GV_VERSION} initialized"
    _gv_log "INFO" "Project: ${GV_PROJECT_DIR}"
    _gv_log "INFO" "Max retries: ${GV_MAX_RETRIES}"
    return 0
}

# =============================================================================
# gv_verify(project_dir)
# Run all verifications on the project. Returns structured JSON via GV_VERIFY_RESULT.
#
# Checks:
#   1. npm run build / npx tsc --noEmit (TypeScript)
#   2. npm run lint (ESLint)
#   3. Empty handler scan (onClick={() => {}}, etc.)
#   4. TODO/FIXME remnant scan
#   5. Mock/placeholder data scan
#
# Return: 0 = all pass, 1 = failures found
# =============================================================================
declare -g GV_VERIFY_RESULT=""
declare -g GV_VERIFY_ERRORS=""
declare -g GV_VERIFY_ERROR_COUNT=0

gv_verify() {
    local dir="${1:-$GV_PROJECT_DIR}"
    local pass=true
    local errors_json="[]"
    local error_count=0
    local build_ok=false lint_ok=false
    local todo_count=0 mock_count=0 empty_handler_count=0
    local build_output="" lint_output="" tsc_output=""

    _gv_log "SECTION" "======= Verification Start ======="

    # --- v2015.0: Package cache persistence ---
    if [[ -f "${dir}/package.json" ]] && [[ ! -d "${dir}/node_modules" ]]; then
        _gv_log "INFO" "node_modules not found - running npm install (cached for retries)"
        (cd "$dir" && timeout "${GV_BUILD_TIMEOUT}" npm install 2>&1) || _gv_log "WARN" "npm install had issues"
    elif [[ -d "${dir}/node_modules" ]]; then
        _gv_log "INFO" "node_modules cached from previous attempt - skipping install"
    fi

    # --- 1. Build check ---
    _gv_log "STEP" "[1/5] Build verification"
    if [[ -f "${dir}/package.json" ]]; then
        # Try build-verifier integration first
        if type bv_verify_all &>/dev/null; then
            bv_verify_all "$dir"
            local bv_rc=$?
            if [[ $bv_rc -eq 0 ]]; then
                build_ok=true
                lint_ok=true
                _gv_log "SUCCESS" "bv_verify_all passed"
            elif [[ $bv_rc -eq 2 ]]; then
                build_ok=true
                lint_ok=false
                _gv_log "WARN" "Build passed, lint warnings found"
            else
                build_ok=false
                pass=false
                _gv_log "FAIL" "bv_verify_all failed"
            fi
            # Collect errors from build-verifier
            if type bv_get_errors &>/dev/null && [[ $bv_rc -ne 0 ]]; then
                GV_VERIFY_ERRORS="$(bv_get_errors)"
                error_count="${BV_ERROR_COUNT:-0}"
            fi
        else
            # Standalone build check
            if grep -q '"build"' "${dir}/package.json" 2>/dev/null; then
                build_output=$(cd "$dir" && npm run build 2>&1)
                local _build_rc=$?
                if [[ $_build_rc -ne 0 ]]; then
                    build_ok=false
                    pass=false
                    _gv_log "FAIL" "npm run build failed (exit code: ${_build_rc})"
                else
                    build_ok=true
                fi
            fi
            # TypeScript check
            if [[ -f "${dir}/tsconfig.json" ]]; then
                tsc_output=$(cd "$dir" && npx tsc --noEmit 2>&1)
                if [[ $? -ne 0 ]]; then
                    build_ok=false
                    pass=false
                    _gv_log "FAIL" "TypeScript type check failed"
                    build_output="${build_output}${tsc_output}"
                fi
            fi
        fi
    fi
    [[ "$build_ok" == true ]] && _gv_log "SUCCESS" "Build: PASS"

    # --- 2. Lint check (if not already done by bv_verify_all) ---
    if [[ "$lint_ok" != true ]] && [[ -f "${dir}/package.json" ]]; then
        _gv_log "STEP" "[2/5] Lint verification"
        if grep -q '"lint"' "${dir}/package.json" 2>/dev/null; then
            lint_output=$(cd "$dir" && npm run lint 2>&1)
            if [[ $? -eq 0 ]]; then
                lint_ok=true
                _gv_log "SUCCESS" "Lint: PASS"
            else
                lint_ok=false
                _gv_log "WARN" "Lint: warnings/errors found"
            fi
        else
            lint_ok=true
            _gv_log "INFO" "Lint: no lint script, skipped"
        fi
    fi

    # --- 3. Empty handler scan ---
    _gv_log "STEP" "[3/5] Empty handler scan"
    if [[ -d "${dir}/src" ]]; then
        empty_handler_count=$(grep -rn \
            -e 'onClick={() => {}}' \
            -e 'onChange={() => {}}' \
            -e 'onSubmit={() => {}}' \
            -e '() => { }' \
            -e 'async () => {}' \
            "${dir}/src" 2>/dev/null | grep -v node_modules | grep -v '.test.' | wc -l | tr -d ' ')
        # v2016.0: 空ハンドラが GV_EMPTY_HANDLER_LIMIT (デフォルト 3) を超えたら FAIL
        local _gv_eh_limit="${GV_EMPTY_HANDLER_LIMIT:-3}"
        if [[ "$empty_handler_count" -gt "$_gv_eh_limit" ]]; then
            _gv_log "FAIL" "Empty handlers exceed limit (${empty_handler_count} > ${_gv_eh_limit})"
            pass=false
            error_count=$((error_count + empty_handler_count))
        elif [[ "$empty_handler_count" -gt 0 ]]; then
            _gv_log "WARN" "Empty handlers found: ${empty_handler_count} (under limit ${_gv_eh_limit})"
        else
            _gv_log "SUCCESS" "Empty handlers: PASS (0 found)"
        fi
    fi

    # --- 4. TODO/FIXME remnant scan ---
    _gv_log "STEP" "[4/5] TODO/FIXME scan"
    if [[ -d "${dir}/src" ]]; then
        todo_count=$(grep -rn \
            -e 'TODO' -e 'FIXME' -e 'HACK' -e 'XXX' \
            "${dir}/src" 2>/dev/null | grep -v node_modules | grep -v '.test.' | wc -l | tr -d ' ')
        if [[ "$todo_count" -gt 0 ]]; then
            _gv_log "WARN" "TODO/FIXME remnants: ${todo_count}"
        else
            _gv_log "SUCCESS" "TODO scan: PASS (0 found)"
        fi
    fi

    # --- 5. Mock/placeholder data scan ---
    _gv_log "STEP" "[5/5] Mock data scan"
    if [[ -d "${dir}/src" ]]; then
        mock_count=$(grep -rn \
            -e 'mock_data\|mockData\|MOCK_' \
            -e 'placeholder.*data' \
            -e '"John Doe"\|"Jane Doe"\|"test@example"' \
            -e 'lorem ipsum' \
            "${dir}/src" 2>/dev/null \
            | grep -v node_modules \
            | grep -v '.test.\|.spec.\|__test__\|__mock__\|fixtures' \
            | wc -l | tr -d ' ')
        if [[ "$mock_count" -gt 0 ]]; then
            _gv_log "WARN" "Mock/placeholder data found: ${mock_count}"
        else
            _gv_log "SUCCESS" "Mock data scan: PASS (0 found)"
        fi
    fi

    # --- v2016.0: 6. Reality Verification Gate (RVG) ---
    # GV_RUN_RVG=true の時のみ実行。dev サーバー起動を伴うため通常は chain.sh の
    # 最終フェーズで qg_run_rvg が呼ばれる想定。ここでは verdict.json の有無を
    # チェックして FAIL なら GV ループを差し戻す。
    local rvg_verdict="${dir}/.rvg/verdict.json"
    if [[ "${GV_RUN_RVG:-false}" == "true" || "${GV_RUN_RVG:-false}" == "1" ]]; then
        _gv_log "STEP" "[6/6] Reality Verification Gate (RVG)"
        if type -t qg_run_rvg &>/dev/null; then
            local rvg_base_url="${GV_BASE_URL:-http://localhost:3000}"
            qg_run_rvg "$dir" "$rvg_base_url" || true
        elif [[ -f "$(dirname "${BASH_SOURCE[0]}")/lib/quality-gate.sh" ]]; then
            source "$(dirname "${BASH_SOURCE[0]}")/lib/quality-gate.sh" 2>/dev/null
            type -t qg_run_rvg &>/dev/null && qg_run_rvg "$dir" "${GV_BASE_URL:-http://localhost:3000}" || true
        fi
    fi
    if [[ -f "$rvg_verdict" ]]; then
        local _gv_rvg_v _gv_rvg_s _gv_rvg_miss _gv_rvg_fail
        _gv_rvg_v=$(grep -oE '"verdict":[[:space:]]*"[^"]+"' "$rvg_verdict" | head -1 | cut -d'"' -f4)
        _gv_rvg_s=$(grep -oE '"score":[[:space:]]*[0-9]+' "$rvg_verdict" | head -1 | grep -oE '[0-9]+')
        _gv_rvg_fail=$(grep -oE '"crawl_fail":[[:space:]]*[0-9]+' "$rvg_verdict" | head -1 | grep -oE '[0-9]+')
        _gv_rvg_miss=$(grep -oE '"missing":[[:space:]]*[0-9]+' "$rvg_verdict" | head -1 | grep -oE '[0-9]+')
        if [[ "$_gv_rvg_v" != "PASS" ]]; then
            _gv_log "FAIL" "RVG FAIL: score=${_gv_rvg_s}/95 crawl_fail=${_gv_rvg_fail:-?} missing=${_gv_rvg_miss:-?}"
            pass=false
            error_count=$((error_count + ${_gv_rvg_fail:-0} + ${_gv_rvg_miss:-0}))
        else
            _gv_log "SUCCESS" "RVG PASS: score=${_gv_rvg_s}/95"
        fi
    fi

    # Build combined error output for fix prompt generation
    if [[ "$pass" == false ]] && [[ -z "${GV_VERIFY_ERRORS:-}" ]]; then
        local combined_errors=""
        [[ -n "$build_output" ]] && combined_errors="${build_output}"
        [[ -n "$lint_output" ]] && combined_errors="${combined_errors}\n${lint_output}"
        local esc_errors
        esc_errors=$(_gv_json_escape "${combined_errors:0:$GV_ERROR_OUTPUT_LIMIT}")
        GV_VERIFY_ERRORS=$(printf '{
  "error_count": %d,
  "build_ok": %s,
  "lint_ok": %s,
  "todo_count": %d,
  "mock_count": %d,
  "empty_handler_count": %d,
  "raw_output": "%s"
}' "$error_count" "$build_ok" "$lint_ok" "$todo_count" "$mock_count" "$empty_handler_count" "$esc_errors")
    fi

    GV_VERIFY_ERROR_COUNT=$((error_count + todo_count + mock_count + empty_handler_count))

    # Build structured result
    GV_VERIFY_RESULT=$(printf '{
  "pass": %s,
  "build_ok": %s,
  "lint_ok": %s,
  "todo_count": %d,
  "mock_count": %d,
  "empty_handler_count": %d,
  "total_issues": %d,
  "verified_at": "%s"
}' "$pass" "$build_ok" "$lint_ok" "$todo_count" "$mock_count" "$empty_handler_count" \
   "$GV_VERIFY_ERROR_COUNT" "$(date '+%Y-%m-%dT%H:%M:%S')")

    _gv_log "SECTION" "======= Verification Complete ======="
    if [[ "$pass" == true ]]; then
        _gv_log "SUCCESS" "All verifications passed (issues: ${GV_VERIFY_ERROR_COUNT})"
        return 0
    else
        _gv_log "FAIL" "Verification failed (issues: ${GV_VERIFY_ERROR_COUNT})"
        return 1
    fi
}

# =============================================================================
# gv_build_fix_prompt(errors_json, original_prompt)
# Create a targeted fix prompt from structured error output.
# Returns the prompt via stdout.
# =============================================================================
gv_build_fix_prompt() {
    local errors_json="${1:?gv_build_fix_prompt: errors_json required}"
    local original_prompt="${2:-}"
    local attempt="${GV_CURRENT_ATTEMPT:-1}"

    # v2016.0: RVG verdict.json から不足機能・404 URL を抽出して指示に組み込む
    local rvg_section=""
    local dir="${GV_PROJECT_DIR:-}"
    local rvg_verdict="${dir}/.rvg/verdict.json"
    local rvg_crawl="${dir}/.rvg/crawl-results.json"
    local rvg_diff="${dir}/.rvg/inference-diff.json"
    if [[ -f "$rvg_verdict" ]]; then
        local missing_features failed_urls
        missing_features=""
        [[ -f "$rvg_diff" ]] && missing_features=$(grep -oE '"missing":[[:space:]]*\[[^]]*\]' "$rvg_diff" | head -1 | tr -d '"' | sed 's/missing://; s/\[//; s/\]//')
        failed_urls=""
        if [[ -f "$rvg_crawl" ]]; then
            failed_urls=$(grep -oE '"url":"[^"]+","method":"[^"]+","file":"[^"]*","status_code":[0-9]+,"size":[0-9]+,"verdict":"FAIL","reason":"[^"]+"' "$rvg_crawl" \
                | sed -E 's/.*"url":"([^"]+)".*"status_code":([0-9]+).*"reason":"([^"]+)".*/  - \1 (HTTP \2: \3)/' | head -20)
        fi
        if [[ -n "$missing_features" ]] || [[ -n "$failed_urls" ]]; then
            rvg_section="

=== REALITY VERIFICATION GATE FAILURES ===
The following items prove the previous output is NOT actually finished.
You MUST add or fix them in this attempt.

Missing features (declared in DESIGN_CONTRACT.md but no matching route):
${missing_features:-(none)}

URLs returning 4xx/5xx (route not implemented or broken):
${failed_urls:-(none)}

When fixing:
- For each missing feature, create the corresponding pages and API routes
- For each 404, create the missing page.tsx / route.ts file with full handler logic
- For each 5xx, fix the runtime error (DB query, missing import, undefined access)
- Always implement the FULL CRUD flow: list → new → detail → edit → delete
- Detail pages MUST exist for any list page that allows clicking a row"
        fi
    fi

    local fix_prompt="CRITICAL: Fix the following build/verification errors.
This is attempt ${attempt}/${GV_MAX_RETRIES}. The previous code generation failed verification.

=== ERRORS TO FIX ===
${errors_json}
${rvg_section}

=== RULES ===
1. Fix ONLY the errors listed above. Do not refactor unrelated code.
2. Preserve all existing functionality that was working.
3. Ensure all imports resolve to existing files.
4. Remove any TODO/FIXME placeholders - implement real logic.
5. Replace any mock/placeholder data with proper implementations.
6. Ensure all event handlers have real implementations, not empty callbacks.
7. All TypeScript types must be complete - no 'any' type escapes.
8. Every list page MUST have a corresponding detail page that opens cleanly.
9. Every CRUD endpoint MUST be backed by a working DB query.

=== OUTPUT FORMAT ===
Output the COMPLETE fixed files using --- FILE: path --- markers.
Only include files that need changes."

    if [[ -n "$original_prompt" ]]; then
        fix_prompt="${fix_prompt}

=== ORIGINAL TASK ===
${original_prompt}"
    fi

    printf '%s' "$fix_prompt"
}

# =============================================================================
# gv_run_cycle(phase, prompt, output_file)
# Main generator-verifier loop.
#
# 1. Generate code via agent (call_claude or ar_execute_phase)
# 2. Run verification (gv_verify)
# 3. If pass -> done
# 4. If fail -> extract errors, build fix prompt, regenerate
# 5. Loop until pass or max_retries
#
# Returns: 0 = passed, 1 = exhausted retries
# =============================================================================
gv_run_cycle() {
    local phase="${1:?gv_run_cycle: phase required}"
    local prompt="${2:?gv_run_cycle: prompt required}"
    local output_file="${3:-}"
    local dir="${GV_PROJECT_DIR:?gv_init must be called first}"

    GV_CURRENT_ATTEMPT=0
    (( GV_TOTAL_CYCLES++ ))
    local cycle_start
    cycle_start=$(date +%s)

    _gv_log "SECTION" "=== GV Cycle Start: ${phase} ==="
    _gv_log "INFO" "Max retries: ${GV_MAX_RETRIES}"

    while [[ $GV_CURRENT_ATTEMPT -lt $GV_MAX_RETRIES ]]; do
        (( GV_CURRENT_ATTEMPT++ ))
        _gv_log "STEP" "--- Attempt ${GV_CURRENT_ATTEMPT}/${GV_MAX_RETRIES} ---"

        # Step 1: Generate code
        _gv_log "INFO" "Generating code for phase: ${phase}"
        local gen_rc=0
        if type ar_execute_phase &>/dev/null; then
            ar_execute_phase "$phase" "$prompt" "$output_file" || gen_rc=$?
        elif type call_claude &>/dev/null; then
            call_claude "$prompt" "$output_file" || gen_rc=$?
        else
            _gv_log "ERROR" "No code generation function available (need ar_execute_phase or call_claude)"
            return 1
        fi

        if [[ $gen_rc -ne 0 ]]; then
            _gv_log "WARN" "Generation returned non-zero exit code: ${gen_rc}"
        fi

        # Step 2: Verify
        _gv_log "INFO" "Running verification..."
        gv_verify "$dir"
        local verify_rc=$?

        # Step 3: Check result
        if [[ $verify_rc -eq 0 ]]; then
            local duration=$(( $(date +%s) - cycle_start ))
            _gv_log "SUCCESS" "Verification PASSED on attempt ${GV_CURRENT_ATTEMPT} (${duration}s)"
            (( GV_TOTAL_PASSES++ ))

            # Record cycle result
            _gv_append_cycle_history "$phase" "$GV_CURRENT_ATTEMPT" "PASS" "$duration"

            # Assess quality
            gv_assess_quality "$dir" >/dev/null 2>&1
            _gv_log "INFO" "Quality score: ${GV_LAST_QUALITY_SCORE}/100"
            return 0
        fi

        # Step 4: Build fix prompt and loop
        if [[ $GV_CURRENT_ATTEMPT -lt $GV_MAX_RETRIES ]]; then
            _gv_log "WARN" "Verification FAILED. Building fix prompt for retry..."
            local errors="${GV_VERIFY_ERRORS:-$GV_VERIFY_RESULT}"
            prompt="$(gv_build_fix_prompt "$errors" "$prompt")"
            _gv_log "INFO" "Fix prompt generated (${#prompt} chars)"
        else
            _gv_log "FAIL" "Verification FAILED. Max retries exhausted."
        fi
    done

    # All retries exhausted
    local duration=$(( $(date +%s) - cycle_start ))
    (( GV_TOTAL_FAILS++ ))
    _gv_append_cycle_history "$phase" "$GV_CURRENT_ATTEMPT" "FAIL" "$duration"
    _gv_log "FAIL" "=== GV Cycle Failed: ${phase} after ${GV_CURRENT_ATTEMPT} attempts (${duration}s) ==="
    return 1
}

# =============================================================================
# _gv_append_cycle_history(phase, attempts, result, duration_sec)
# =============================================================================
_gv_append_cycle_history() {
    local phase="$1" attempts="$2" result="$3" duration="$4"
    local entry
    entry=$(printf '{"phase":"%s","attempts":%d,"result":"%s","duration_sec":%d,"quality_score":%d,"timestamp":"%s"}' \
        "$(_gv_json_escape "$phase")" "$attempts" "$result" "$duration" \
        "$GV_LAST_QUALITY_SCORE" "$(date '+%Y-%m-%dT%H:%M:%S')")
    if [[ "$GV_CYCLE_HISTORY" == "[]" ]]; then
        GV_CYCLE_HISTORY="[${entry}]"
    else
        GV_CYCLE_HISTORY="${GV_CYCLE_HISTORY%]},${entry}]"
    fi
}

# =============================================================================
# gv_assess_quality(project_dir)
# Score the project output 0-100 across 6 axes:
#   Build success:        30 pts
#   Lint clean:           20 pts
#   No TODOs:             10 pts
#   No mock data:         10 pts
#   Error handling:       15 pts
#   Types complete:       15 pts
#
# Sets GV_LAST_QUALITY_SCORE. Returns score via stdout.
# =============================================================================
gv_assess_quality() {
    local dir="${1:-$GV_PROJECT_DIR}"
    local score=0
    local breakdown=""

    _gv_log "STEP" "Assessing quality for: ${dir}"

    # --- Axis 1: Build success (30 pts) ---
    local build_pts=0
    if [[ -f "${dir}/package.json" ]]; then
        if grep -q '"build"' "${dir}/package.json" 2>/dev/null; then
            if (cd "$dir" && npm run build >/dev/null 2>&1); then
                build_pts=30
            fi
        elif [[ -f "${dir}/tsconfig.json" ]]; then
            if (cd "$dir" && npx tsc --noEmit >/dev/null 2>&1); then
                build_pts=30
            fi
        else
            build_pts=30  # No build step means no build errors
        fi
    else
        build_pts=30  # Non-Node project: skip build axis
    fi
    score=$((score + build_pts))
    breakdown="build:${build_pts}/30"

    # --- Axis 2: Lint clean (20 pts) ---
    local lint_pts=0
    if [[ -f "${dir}/package.json" ]] && grep -q '"lint"' "${dir}/package.json" 2>/dev/null; then
        local lint_errors
        lint_errors=$(cd "$dir" && npm run lint 2>&1 | grep -c -i 'error' || true)
        if [[ "$lint_errors" -eq 0 ]]; then
            lint_pts=20
        elif [[ "$lint_errors" -lt 5 ]]; then
            lint_pts=12
        elif [[ "$lint_errors" -lt 15 ]]; then
            lint_pts=5
        fi
    else
        lint_pts=20  # No lint config means no lint errors
    fi
    score=$((score + lint_pts))
    breakdown="${breakdown}, lint:${lint_pts}/20"

    # --- Axis 3: No TODOs (10 pts) ---
    local todo_pts=0
    if [[ -d "${dir}/src" ]]; then
        local todos
        todos=$(grep -rn 'TODO\|FIXME\|HACK\|XXX' "${dir}/src" 2>/dev/null \
            | grep -v node_modules | grep -v '.test.\|.spec.' | wc -l | tr -d ' ')
        if [[ "$todos" -eq 0 ]]; then
            todo_pts=10
        elif [[ "$todos" -lt 3 ]]; then
            todo_pts=6
        elif [[ "$todos" -lt 8 ]]; then
            todo_pts=2
        fi
    else
        todo_pts=10
    fi
    score=$((score + todo_pts))
    breakdown="${breakdown}, todo:${todo_pts}/10"

    # --- Axis 4: No mock data (10 pts) ---
    local mock_pts=0
    if [[ -d "${dir}/src" ]]; then
        local mocks
        mocks=$(grep -rn 'mock_data\|mockData\|MOCK_\|"John Doe"\|"Jane Doe"\|lorem ipsum' \
            "${dir}/src" 2>/dev/null \
            | grep -v node_modules \
            | grep -v '.test.\|.spec.\|__test__\|__mock__\|fixtures' \
            | wc -l | tr -d ' ')
        if [[ "$mocks" -eq 0 ]]; then
            mock_pts=10
        elif [[ "$mocks" -lt 3 ]]; then
            mock_pts=5
        fi
    else
        mock_pts=10
    fi
    score=$((score + mock_pts))
    breakdown="${breakdown}, mock:${mock_pts}/10"

    # --- Axis 5: Error handling present (15 pts) ---
    local err_pts=0
    if [[ -d "${dir}/src" ]]; then
        local total_files catch_files
        total_files=$(find "${dir}/src" -name '*.ts' -o -name '*.tsx' -o -name '*.js' -o -name '*.jsx' \
            2>/dev/null | grep -v node_modules | wc -l | tr -d ' ')
        catch_files=$(grep -rl 'try.*{.*catch\|\.catch(\|onError\|handleError\|error.*boundary' \
            "${dir}/src" 2>/dev/null \
            | grep -v node_modules | wc -l | tr -d ' ')
        if [[ "$total_files" -gt 0 ]]; then
            local ratio=$(( (catch_files * 100) / total_files ))
            if [[ "$ratio" -ge 30 ]]; then
                err_pts=15
            elif [[ "$ratio" -ge 15 ]]; then
                err_pts=10
            elif [[ "$ratio" -ge 5 ]]; then
                err_pts=5
            fi
        else
            err_pts=15
        fi
    else
        err_pts=15
    fi
    score=$((score + err_pts))
    breakdown="${breakdown}, errh:${err_pts}/15"

    # --- Axis 6: Types complete (15 pts) ---
    local type_pts=0
    if [[ -d "${dir}/src" ]]; then
        local any_count
        any_count=$(grep -rn ': any\b\|as any\b\|<any>' "${dir}/src" 2>/dev/null \
            | grep -v node_modules | grep -v '.test.\|.spec.\|.d.ts' | wc -l | tr -d ' ')
        if [[ "$any_count" -eq 0 ]]; then
            type_pts=15
        elif [[ "$any_count" -lt 3 ]]; then
            type_pts=10
        elif [[ "$any_count" -lt 8 ]]; then
            type_pts=5
        fi
    else
        type_pts=15
    fi
    score=$((score + type_pts))
    breakdown="${breakdown}, types:${type_pts}/15"

    GV_LAST_QUALITY_SCORE=$score
    _gv_log "INFO" "Quality: ${score}/100 [${breakdown}]"
    echo "$score"
    return 0
}

# =============================================================================
# gv_report()
# Print a summary of all generator-verifier cycles in this session.
# =============================================================================
gv_report() {
    _gv_log "SECTION" "============================================"
    _gv_log "SECTION" "  Generator-Verifier Loop Report v${GV_VERSION}"
    _gv_log "SECTION" "============================================"
    _gv_log "INFO" "Project:        ${GV_PROJECT_DIR:-N/A}"
    _gv_log "INFO" "Total cycles:   ${GV_TOTAL_CYCLES}"
    _gv_log "INFO" "Passed:         ${GV_TOTAL_PASSES}"
    _gv_log "INFO" "Failed:         ${GV_TOTAL_FAILS}"
    _gv_log "INFO" "Last quality:   ${GV_LAST_QUALITY_SCORE}/100"
    _gv_log "INFO" "Max retries:    ${GV_MAX_RETRIES}"

    if [[ "$GV_TOTAL_CYCLES" -gt 0 ]]; then
        local pass_rate=$(( (GV_TOTAL_PASSES * 100) / GV_TOTAL_CYCLES ))
        _gv_log "INFO" "Pass rate:      ${pass_rate}%"
    fi

    echo ""
    _gv_log "INFO" "Cycle history:"
    echo "$GV_CYCLE_HISTORY" | tr ',' '\n' | while IFS= read -r line; do
        echo "    $line"
    done

    # Return structured JSON report
    printf '{
  "version": "%s",
  "project_dir": "%s",
  "total_cycles": %d,
  "total_passes": %d,
  "total_fails": %d,
  "last_quality_score": %d,
  "max_retries": %d,
  "cycle_history": %s,
  "generated_at": "%s"
}\n' \
    "$GV_VERSION" \
    "$(_gv_json_escape "${GV_PROJECT_DIR:-}")" \
    "$GV_TOTAL_CYCLES" \
    "$GV_TOTAL_PASSES" \
    "$GV_TOTAL_FAILS" \
    "$GV_LAST_QUALITY_SCORE" \
    "$GV_MAX_RETRIES" \
    "$GV_CYCLE_HISTORY" \
    "$(date '+%Y-%m-%dT%H:%M:%S')"
}

# =============================================================================
# v2015.0: Weighted Error Scoring
# Build errors = 10x, lint warnings = 3x, TODO markers = 1x
# Returns weighted error count for prioritized fix ordering.
# =============================================================================
gv_weighted_error_score() {
    local dir="${1:-$GV_PROJECT_DIR}"
    local build_errors=0 lint_warnings=0 todo_markers=0

    # Build errors (weight 10x)
    if [[ -f "${dir}/package.json" ]] && grep -q '"build"' "${dir}/package.json" 2>/dev/null; then
        local build_out
        build_out=$(cd "$dir" && timeout "${GV_BUILD_TIMEOUT}" npm run build 2>&1) || true
        build_errors=$(echo "$build_out" | grep -ciE '^error|TS[0-9]+:' 2>/dev/null || echo "0")
        build_errors="${build_errors%%[!0-9]*}"
        build_errors="${build_errors:-0}"
    fi

    # Lint warnings (weight 3x)
    if [[ -f "${dir}/package.json" ]] && grep -q '"lint"' "${dir}/package.json" 2>/dev/null; then
        local lint_out
        lint_out=$(cd "$dir" && npm run lint 2>&1) || true
        lint_warnings=$(echo "$lint_out" | grep -ciE 'warning|error' 2>/dev/null || echo "0")
        lint_warnings="${lint_warnings%%[!0-9]*}"
        lint_warnings="${lint_warnings:-0}"
    fi

    # TODO markers (weight 1x)
    if [[ -d "${dir}/src" ]]; then
        todo_markers=$(grep -rn 'TODO\|FIXME\|HACK\|XXX' "${dir}/src" 2>/dev/null \
            | grep -v node_modules | wc -l | tr -d ' ')
        todo_markers="${todo_markers:-0}"
    fi

    local weighted=$(( (build_errors * 10) + (lint_warnings * 3) + (todo_markers * 1) ))
    _gv_log "INFO" "Weighted errors: ${weighted} (build=${build_errors}x10, lint=${lint_warnings}x3, todo=${todo_markers}x1)"
    echo "$weighted"
}

# =============================================================================
# v2015.0: Multi-Stage Review Integration Hook
# Call multi-stage-review.sh after verification passes for deeper analysis.
# =============================================================================
gv_hook_multi_stage_review() {
    local dir="${1:-$GV_PROJECT_DIR}"
    local phase="${2:-unknown}"

    if type -t msr_execute_review &>/dev/null; then
        _gv_log "INFO" "Running multi-stage-review hook for phase: ${phase}"
        msr_execute_review "$dir" "$phase" 2>/dev/null || {
            _gv_log "WARN" "Multi-stage review returned non-zero (non-blocking)"
        }
        return 0
    else
        _gv_log "INFO" "multi-stage-review.sh not loaded - hook skipped"
        return 0
    fi
}

# =============================================================================
# v2015.0: Enhanced run cycle with timeout, caching, and review hook
# =============================================================================
gv_run_cycle_v2015() {
    local phase="${1:?gv_run_cycle_v2015: phase required}"
    local prompt="${2:?gv_run_cycle_v2015: prompt required}"
    local output_file="${3:-}"

    # Run standard cycle with v2015 enhancements (cache + timeout already active)
    gv_run_cycle "$phase" "$prompt" "$output_file"
    local rc=$?

    # If passed, run multi-stage review hook
    if [[ $rc -eq 0 ]]; then
        gv_hook_multi_stage_review "$GV_PROJECT_DIR" "$phase"
    fi

    return $rc
}
