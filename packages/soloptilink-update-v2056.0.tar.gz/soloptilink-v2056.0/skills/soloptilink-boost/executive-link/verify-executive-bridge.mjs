#!/usr/bin/env node
/**
 * Executive → BOOST 連携の検証ゲート (born-passing)
 * ============================================================================
 * 配線が「実際に効く」ことを end-to-end で実証する。
 * 実行: node verify-executive-bridge.mjs   終了コード: 全PASS=0 / 1つでもFAIL=1
 *
 * 検証する性質:
 *   V1 バンドル/meta/bridge が同梱されている
 *   V2 bundle --selftest (経営層→注入 / 通常業務→no-op) が PASS
 *   V3 bridge: 経営層案件 → has_data=true + 注入文に経営UX/ロールが出る + 成果物生成
 *   V4 bridge: 通常業務アプリ → has_data=false (過剰注入ガード)
 *   V5 bridge: 依頼文なし → no-op かつ exit 0 (本流を止めない)
 *   V6 バンドルのソースハッシュが meta と一致 (陳腐化していない)
 */

import * as fs from "node:fs";
import * as path from "node:path";
import * as os from "node:os";
import * as crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const BUNDLE = path.join(HERE, "executive-recall.bundle.mjs");
const META = path.join(HERE, "executive-recall.bundle.meta.json");
const BRIDGE = path.join(HERE, "executive-bridge.mjs");
const EXEC_LIB = path.resolve(HERE, "..", "..", "soloptilink-executive", "lib");

const results = [];
function check(id, name, fn) {
  try {
    const r = fn();
    results.push({ id, name, pass: r === true, detail: r === true ? "" : String(r) });
  } catch (e) {
    results.push({ id, name, pass: false, detail: "EXC: " + e.message });
  }
}
function runNode(args, env) {
  return spawnSync(process.execPath, args, { env: { ...process.env, ...env }, encoding: "utf-8", timeout: 25000 });
}
function lastJson(stdout) {
  const line = (stdout || "").trim().split("\n").filter(Boolean).pop();
  return line ? JSON.parse(line) : null;
}

check("V1", "バンドル/meta/bridge が同梱", () => {
  if (!fs.existsSync(BUNDLE)) return "bundle なし";
  if (!fs.existsSync(META)) return "meta なし";
  if (!fs.existsSync(BRIDGE)) return "bridge なし";
  return true;
});

check("V2", "bundle --selftest (注入/no-op両方) PASS", () => {
  const r = runNode([BUNDLE, "--selftest"]);
  const j = lastJson(r.stdout);
  if (r.status !== 0) return "exit!=0: " + (j?.failures?.join("; ") || r.stderr);
  if (!j || j.ok !== true) return "failures: " + (j?.failures?.join("; ") || "?");
  return true;
});

check("V3", "bridge: 経営層案件 → 注入+成果物", () => {
  const ws = fs.mkdtempSync(path.join(os.tmpdir(), "exec-verify-ws-"));
  try {
    const r = runNode([BRIDGE, "--task", "CFO向けの資金繰り・ヨミ表ダッシュボードと中期経営計画", "--workspace", ws]);
    const j = lastJson(r.stdout);
    if (!j?.has_data) return "has_data=false (注入されない)";
    const inj = (j.injection_lines_for_agents || []).join("\n");
    if (!/経営層/.test(inj)) return "注入文にロール設計が無い";
    if (!/Pyramid|5枚以内/.test(inj)) return "注入文に経営UX原則が無い";
    if (!fs.existsSync(path.join(ws, "agent-evidence", "executive-recall.md")))
      return "成果物(executive-recall.md)が無い";
    return true;
  } finally {
    fs.rmSync(ws, { recursive: true, force: true });
  }
});

check("V4", "bridge: 通常業務アプリ → no-op (過剰注入ガード)", () => {
  const r = runNode([BRIDGE, "--task", "在庫管理システムを作って"]);
  const j = lastJson(r.stdout);
  if (j?.has_data !== false) return "通常アプリに誤発火(過剰注入)";
  if (j?.injection_lines_for_agents?.length !== 0) return "注入文が空でない";
  return true;
});

check("V5", "bridge: 依頼文なし → no-op かつ exit 0", () => {
  const r = runNode([BRIDGE], { SOLOPTILINK_EXEC_TASK: "" });
  const j = lastJson(r.stdout);
  if (j?.has_data !== false) return "has_data が false でない";
  return r.status === 0 ? true : "exit=" + r.status;
});

check("V6", "バンドルが陳腐化していない (source_hash 一致)", () => {
  if (!fs.existsSync(META)) return "meta なし";
  const meta = JSON.parse(fs.readFileSync(META, "utf-8"));
  let combined =
    crypto.createHash("sha256").update(fs.readFileSync(path.join(HERE, "executive-entry.ts"))).digest("hex") +
    "  executive-entry.ts\n";
  const files = [];
  const walk = (d) => {
    for (const e of fs.readdirSync(d, { withFileTypes: true })) {
      const p = path.join(d, e.name);
      if (e.isDirectory()) walk(p);
      else if (e.name.endsWith(".ts")) files.push(p);
    }
  };
  walk(EXEC_LIB);
  files.sort();
  for (const f of files) {
    combined += crypto.createHash("sha256").update(fs.readFileSync(f)).digest("hex") + "  " + path.relative(EXEC_LIB, f) + "\n";
  }
  const cur = crypto.createHash("sha256").update(combined).digest("hex");
  return meta.source_hash === cur ? true : "陳腐化: build-bundle.sh 再実行が必要";
});

const passed = results.filter((r) => r.pass).length;
const failed = results.length - passed;
console.log("=== Executive → BOOST 連携 検証ゲート ===");
for (const r of results) console.log(`${r.pass ? "✓" : "✗"} ${r.id} ${r.name}${r.detail ? "  — " + r.detail : ""}`);
console.log("---");
console.log(`PASS=${passed} FAIL=${failed} (計 ${results.length})`);
process.exit(failed === 0 ? 0 : 1);
