/**
 * Executive (経営者DNA) → BOOST 連携エントリ (ビルド元)
 * ------------------------------------------------------------------
 * このファイルは esbuild で `executive-recall.bundle.mjs` に単一ファイルへ
 * バンドルされる「ビルド元ソース」。実行時はバンドル済み .mjs を bare node で動かす。
 *
 * 役割:
 *   - soloptilink-executive の「正規 API」(inferRolesFromPrompt / matchDecisions /
 *     renderDecisionForPrompt / inferIndustry / selectFrameworks /
 *     composeMorningDashboard) をそのまま呼ぶ (ロジック写経なし = ドリフト防止)。
 *   - BOOST が読み取れる JSON を stdout に出す。
 *   - 経営層シグナル検出時のみ注入を生成し、非検出時は無音 no-op。
 *
 * 過剰注入ガード (最重要):
 *   inferRolesFromPrompt は無条件で CEO を返すため、これを発火条件に使わない。
 *   発火は「明示的な経営層キーワード」または「matchDecisions/selectFrameworks が
 *   実際にヒット」したときのみ。通常の業務アプリ(介護記録/在庫管理 等)には注入しない。
 *
 * 入力 (環境変数):
 *   EXEC_TASK      事業内容/依頼文(必須)
 *   EXEC_INDUSTRY  検出業種(任意)
 *   EXEC_WORKSPACE 作業ディレクトリ(任意)
 *
 * 出力 (stdout, 1行 JSON):
 *   { ok, mode, has_data, inference_block_markdown, injection_lines_for_agents }
 */

import {
  inferRolesFromPrompt,
  composeMorningDashboard,
  matchDecisions,
  renderDecisionForPrompt,
  inferIndustry,
  selectFrameworks,
  CSUITE_PROFILES,
} from "../../soloptilink-executive/lib/index";

// 明示的な経営層キーワード(過剰注入を防ぐ発火ゲート)。
// 業種語(介護/不動産等)は含めない — それは「経営層向けか」とは無関係なため。
const EXEC_GATE_RE =
  /ceo|cfo|coo|cto|chro|cmo|cso|cro|ciso|cxo|c-?suite|cスイート|経営者|社長|代表取締役|取締役会|役員|経営判断|経営戦略|経営計画|中期経営計画|事業承継|事業ポートフォリオ|資金繰り|資金調達|ヨミ表|着地見込|board\s*deck|ボードデック|m&a|エムアンドエー|\bir\b|投資家|経営ダッシュボード|資本配分|kpi設計/i;

function emit(obj: unknown): void {
  process.stdout.write(JSON.stringify(obj) + "\n");
}

function hasExecSignal(task: string): boolean {
  if (EXEC_GATE_RE.test(task)) return true;
  // 経営判断パターン・戦略フレームワークが実際にヒットすれば経営文脈とみなす。
  if (matchDecisions(task).length > 0) return true;
  if (selectFrameworks(task).length > 0) return true;
  return false;
}

interface ExecResult {
  has_data: boolean;
  inference_block_markdown: string;
  injection_lines_for_agents: string[];
}

/** 依頼文から経営者DNAの注入テキストを構築する(正規APIのみ使用)。 */
function buildExecInjection(task: string, industryHint?: string): ExecResult {
  if (!hasExecSignal(task)) {
    return {
      has_data: false,
      inference_block_markdown:
        "【Executive 自動適用】経営層シグナル未検出のため適用なし(通常の業務システムとして構築)。",
      injection_lines_for_agents: [],
    };
  }

  const roles = inferRolesFromPrompt(task); // 最低 CEO は返る
  const roleTitles = roles
    .map((r) => `${r}(${CSUITE_PROFILES[r]?.jpTitle ?? r})`)
    .join(" / ");
  const dashboard = composeMorningDashboard(roles); // 5枚以内
  const decisions = matchDecisions(task).slice(0, 3);
  const frameworks = selectFrameworks(task).slice(0, 4);
  const industryKey = inferIndustry(task);

  const lines: string[] = [];

  // ① 利用者ロール + ホーム/通知設計
  lines.push(
    `本システムの主要利用者は経営層(${roleTitles})。各役割のホーム画面・通知・権限を経営者視点で最優先設計すること。`,
  );

  // ② 朝のダッシュボード(KPI 5枚以内)
  if (dashboard.length > 0) {
    lines.push(
      `経営ダッシュボードには次の指標を1画面5枚以内で優先配置(認知負荷4±1): ${dashboard.join(" / ")}。`,
    );
  }

  // ③ 経営判断パターン(確認指標・典型的誤り)
  for (const d of decisions) {
    lines.push(
      `経営判断『${d.name}』を支援する画面/集計を用意: 確認すべき指標=${d.keyMetrics.join("・")} / 回避すべき誤り=${d.commonMistakes.join("・")}。`,
    );
  }

  // ④ 戦略フレームワーク
  if (frameworks.length > 0) {
    lines.push(
      `次の戦略フレームワークを分析機能・帳票に反映: ${frameworks.map((f) => f.jpName).join(" / ")}。`,
    );
  }

  // ⑤ 業界ベンチマーク対比
  if (industryKey) {
    lines.push(
      `業界ベンチマーク(${industryKey})と自社実績を対比し、中央値/上位25%/警報閾値を併記すること。`,
    );
  }

  // ⑥ 経営者向けUX原則(固定)
  lines.push(
    "経営者向けUX原則: 結論先出し(Pyramid Principle)・KPIは1画面5枚以内・金額は億/万の日本語表記・警報閾値超過は即アラート・各指標はドリルダウンで根拠データへ到達可能にすること。",
  );

  // 推論ブロック(設計入力・人間可読)
  const block: string[] = [];
  block.push("【Executive 自動適用】経営者DNAレイヤー");
  block.push(`- 対象ロール: ${roleTitles}`);
  if (dashboard.length > 0) block.push(`- 朝のダッシュボード: ${dashboard.join(" / ")}`);
  if (decisions.length > 0)
    block.push(`- 関連経営判断: ${decisions.map((d) => d.name).join(" / ")}`);
  if (frameworks.length > 0)
    block.push(`- 戦略フレームワーク: ${frameworks.map((f) => f.jpName).join(" / ")}`);
  if (industryKey) block.push(`- 業界ベンチ: ${industryKey}`);
  if (industryHint) block.push(`- 事業推論業種(boost): ${industryHint}`);

  return {
    has_data: true,
    inference_block_markdown: block.join("\n"),
    injection_lines_for_agents: lines,
  };
}

function runRecall(): void {
  const task = (process.env.EXEC_TASK ?? "").trim();
  const industry = (process.env.EXEC_INDUSTRY ?? "").trim() || undefined;
  if (!task) {
    emit({
      ok: true,
      mode: "recall",
      has_data: false,
      inference_block_markdown: "",
      injection_lines_for_agents: [],
    });
    return;
  }
  const out = buildExecInjection(task, industry);
  emit({ ok: true, mode: "recall", ...out });
}

/**
 * born-passing 自己検証。
 * 経営層シグナルあり → 注入生成 / 通常業務アプリ → no-op、の両方を実証する。
 */
function runSelftest(): void {
  const failures: string[] = [];
  try {
    // positive: 明確な経営層案件
    const pos = buildExecInjection(
      "CFO向けの資金繰り・ヨミ表ダッシュボードと中期経営計画の管理システム",
    );
    if (!pos.has_data) failures.push("経営層案件で has_data=false");
    const joined = pos.injection_lines_for_agents.join("\n");
    if (!/経営層/.test(joined)) failures.push("注入文にロール設計が無い");
    if (!/Pyramid|5枚以内/.test(joined)) failures.push("注入文に経営者UX原則が無い");
    if (!/CFO/.test(joined)) failures.push("CFO案件なのにCFOロールが反映されない");

    // negative: 通常の業務アプリ(過剰注入ガード)
    const neg = buildExecInjection("介護記録システムを作って");
    if (neg.has_data) failures.push("通常業務アプリに経営者注入が誤発火(過剰注入)");
    if (neg.injection_lines_for_agents.length !== 0)
      failures.push("通常業務アプリで注入文が生成された");

    // negative2: 空
    const empty = buildExecInjection("");
    if (empty.has_data) failures.push("空入力で has_data=true");
  } catch (e) {
    failures.push("selftest 例外: " + (e as Error).message);
  }
  emit({ ok: failures.length === 0, mode: "selftest", failures });
  process.exit(failures.length === 0 ? 0 : 1);
}

const arg = process.argv[2] ?? "";
if (arg === "--selftest") {
  runSelftest();
} else {
  try {
    runRecall();
  } catch (e) {
    // 経営者注入の失敗は BOOST 本流を絶対に止めない。
    emit({
      ok: false,
      mode: "recall",
      has_data: false,
      inference_block_markdown: "",
      injection_lines_for_agents: [],
      error: (e as Error).message,
    });
  }
}
