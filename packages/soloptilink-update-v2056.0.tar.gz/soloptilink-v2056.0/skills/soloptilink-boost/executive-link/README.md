# Executive → BOOST 知識連携 (executive-link)

`/soloptilink-boost` 起動時に、`/soloptilink-executive`（経営者DNAレイヤー）の知識
（対象C-Suiteロール・経営ダッシュボード指標・経営判断パターン・戦略フレームワーク・
経営者UX原則）を自動で想起し、ビルドの全105ロールへ反映する連携レイヤー。
顧客が executive を明示起動しなくても、経営層向けの依頼なら BOOST が自動適用する。

## 設計判断（tenant-dna-link と同型）

- **executive 本体は無編集（越境ゼロ）**。連携 API（`inferRolesFromPrompt` /
  `matchDecisions` + `renderDecisionForPrompt` / `inferIndustry` / `selectFrameworks` /
  `composeMorningDashboard`）は executive 側に実装・export 済みだったが、BOOST 側に
  対応ステップ（executive が宣言する Step 0.55）が無く**未配線**だった。本フォルダが配線する。
- **ロジックを写経しない**。注入テキストの真実源は executive の正規 API のみ（バンドル経由）。
- **実行基盤**: recall 依存グラフは外部 npm ゼロ（純ロジック）。esbuild で単一の
  自己完結 `.mjs` にバンドルし、bare `node` で高速実行（数十 ms）・オフライン・依存ゼロ。
- **最優先指令の死守**: 依頼文なし・経営層シグナルなし・失敗はすべて no-op で素通り
  （bridge は常に exit 0）。

## 過剰注入ガード（最重要）

`inferRolesFromPrompt` は無条件で CEO を返すため、これを**発火条件に使わない**。
発火は「明示的な経営層キーワード（CEO/CFO/経営者/資金繰り/中期経営計画/事業承継/
Board Deck/M&A 等）」または「`matchDecisions`/`selectFrameworks` が実際にヒット」
したときのみ。通常の業務アプリ（介護記録/在庫管理 等）には**注入しない**。

## 構成ファイル

| ファイル | 役割 | 実行時必要 |
|---|---|---|
| `executive-entry.ts` | バンドルのビルド元。executive API を呼ぶ薄いエントリ＋selftest | ✗ (ビルド時のみ) |
| `executive-recall.bundle.mjs` | 自己完結バンドル（executive の正規コードを内包） | ✓ |
| `executive-recall.bundle.meta.json` | ソースハッシュ封緘（陳腐化検知） | ✓ |
| `executive-bridge.mjs` | BOOST Step 0.55 の窓口。依頼文→陳腐化検知→バンドル実行→成果物出力 | ✓ |
| `verify-executive-bridge.mjs` | born-passing 検証ゲート（6軸） | 検証時 |
| `build-bundle.sh` | バンドル再生成＋メタ封緘 | 保守時 |

## BOOST からの呼び出し（Step 0.55）

```bash
node ~/.claude/skills/soloptilink-boost/executive-link/executive-bridge.mjs \
  --task "$TASK_DESC" --industry "$DETECTED_INDUSTRY"
```

出力（1行 JSON）: `has_data` / `injection_lines_for_agents`（$TARGET_TASK に折り込む）/
`inference_block_markdown`（agent-evidence/executive-recall.md に保存）。

## 検証（born-passing 6軸）

```bash
node ~/.claude/skills/soloptilink-boost/executive-link/verify-executive-bridge.mjs
```

V1 同梱 / V2 selftest（経営層→注入・通常業務→no-op）/ V3 bridge経営層案件→注入+成果物 /
V4 過剰注入ガード / V5 依頼文なし no-op exit0 / V6 陳腐化検知。

## 保守

executive の lib を更新したら必ずバンドルを再生成:

```bash
bash ~/.claude/skills/soloptilink-boost/executive-link/build-bundle.sh
```

## ★ SKILL.md 配線の重要注意（SoT）

boost の SKILL.md は **4箇所に同期されるミラー**で、**正典(SoT)は
`~/.claude/commands/soloptilink-boost.md`**。`~/.claude/skills/.../SKILL.md`(稼働スキル)を
直接編集しても、Stop フックの `skill-sot-guard.sh heal` が正典で上書きして**巻き戻す**。
よって Step 配線は必ず**正典を編集 → `skill-sot-guard.sh heal` → `refresh`(snapshot再取得)**
の順で行うこと。本連携の Step 0.55 はこの手順で4箇所すべてに反映済み。
（lib/bundle/bridge は SKILL.md ではないため heal の対象外＝直接配置で永続する。）

## 既知の制約 / owner 申し送り

- 注入は「明示的経営層シグナル検出時のみ」。経営層案件なのにキーワードが曖昧で
  発火しない場合は、依頼文に経営層の語（CFO/資金繰り 等）を補うか env で明示する。
- バンドルは executive の lib を内包する。executive 更新時は必ず `build-bundle.sh` を再実行。
- 同型の先行例は `../tenant-dna-link/`（Step 0.95）。
