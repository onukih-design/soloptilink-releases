#!/usr/bin/env bash
# =============================================================================
# Executive → BOOST 連携バンドルの再ビルド
# -----------------------------------------------------------------------------
# executive-entry.ts と soloptilink-executive の lib を単一の自己完結 .mjs に
# バンドルし、ソースハッシュの sidecar(meta.json) を更新する。
# バンドル後の .mjs は外部依存ゼロ(純ロジック)のため実行に esbuild は不要。
#
# 実行タイミング:
#   - soloptilink-executive/lib を変更したとき
#   - executive-entry.ts を変更したとき
#   - bridge が「バンドルが陳腐化」と WARN を出したとき
# =============================================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
EXEC_LIB="$(cd "$HERE/../../soloptilink-executive/lib" && pwd)"
ENTRY="$HERE/executive-entry.ts"
OUT="$HERE/executive-recall.bundle.mjs"
META="$HERE/executive-recall.bundle.meta.json"

# --- esbuild の所在を解決 ---
ESB=""
for c in \
  "$HOME/.soloptilink/admin-dashboard-true-source/node_modules/.bin/esbuild" \
  "$(command -v esbuild 2>/dev/null || true)" \
  "$HERE/node_modules/.bin/esbuild"; do
  if [ -n "$c" ] && [ -x "$c" ]; then ESB="$c"; break; fi
done
if [ -z "$ESB" ]; then
  echo "ERROR: esbuild が見つかりません。" >&2
  exit 2
fi

# --- バンドル生成 ---
"$ESB" "$ENTRY" \
  --bundle --platform=node --target=node18 --format=esm \
  --outfile="$OUT" --log-level=warning

# --- ソースハッシュ封緘(entry + executive lib 全 .ts) ---
COMBINED="$(shasum -a 256 "$ENTRY" | awk '{print $1}')  executive-entry.ts
"
while IFS= read -r f; do
  COMBINED+="$(shasum -a 256 "$f" | awk '{print $1}')  ${f#$EXEC_LIB/}
"
done < <(find "$EXEC_LIB" -name '*.ts' | sort)
SRC_HASH="$(printf '%s' "$COMBINED" | shasum -a 256 | awk '{print $1}')"
BUNDLE_HASH="$(shasum -a 256 "$OUT" | awk '{print $1}')"

cat > "$META" <<JSON
{
  "schema": "executive-recall-bundle/1",
  "source_hash": "$SRC_HASH",
  "bundle_hash": "$BUNDLE_HASH",
  "note": "source_hash は executive-entry.ts + soloptilink-executive/lib 全.tsの複合ハッシュ。bridge が実行時に再計算して陳腐化を検知する。"
}
JSON

echo "OK: executive bundle 再生成完了"
echo "  bundle: $OUT"
echo "  source_hash: $SRC_HASH"
