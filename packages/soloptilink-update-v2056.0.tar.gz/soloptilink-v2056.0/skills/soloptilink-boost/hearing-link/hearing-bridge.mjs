#!/usr/bin/env node
/**
 * Hearing (要件ヒアリング) → BOOST 連携ブリッジ (純 node・外部依存ゼロ)
 * ============================================================================
 * BOOST Step 0.65 から呼ばれる唯一の窓口。
 *
 * 設計原則:
 *  - 「絶対に BOOST 本流を止めない」。失敗はすべて no-op で exit 0。
 *  - 業種→DBL 再解決は書かない (engine が単独 SoT)。
 *  - 曖昧点は推測で埋めない。
 *  - engagement-ledger 未配置環境では無害スキップ。
 *
 * has_data=false 時は「完全 no-op」 (R28: R3 の拡張):
 *  - injection_lines_for_agents = [] / inference_block_markdown = ""
 *  - pre_build_confirmation_questions = [] / silent_drop_warnings = [] / sanitization_incidents = []
 *  - ambiguities / required_modules / applicable_regulations / workflow = [] / industry = "" / dbl = ""
 *  - purpose = "" / purpose_source = "" (T-I0-A: 目的も no-op 時は一切露出しない)
 *  - engagement_ledger_available = false / engagement_ledger_path = "" (露出を全て抑止)
 *  - evidence_md_path = "" / evidence_write_error = ""
 * BOOST 側は has_data だけを見て判断する (単純化・fail-safe)。
 *
 * workspace 必須化 (R29):
 *  - --workspace 未指定/空 → cwd フォールバックしない。noop 返却。
 *  - BOOST は必ず --workspace $PROJECT_DIR を渡す仕様。
 *
 * 陳腐化ゲート (R13/R14):
 *  - META 不在/破損・bundle_hash 空・source/bundle いずれかの不一致で stale=true。
 *  - stale=true → runBundle を実行せず noop で返す。
 *
 * バッファ (R25):
 *  - spawnSync に maxBuffer=1GB を指定 (Round 3 で 32MB を超える巨大セッションが誤 corrupt 化した対策)。
 *  - ENOBUFS 判別: エラーメッセージに ENOBUFS が含まれれば専用 reason 明示 (corrupt とは区別)。
 *
 * kill-switch:
 *   ENABLE_HEARING_LINK=off  → 完全 no-op
 */

import * as fs from "node:fs";
import * as path from "node:path";
import * as crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const BUNDLE = path.join(HERE, "hearing-recall.bundle.mjs");
const META = path.join(HERE, "hearing-recall.bundle.meta.json");
const ENTRY = path.join(HERE, "hearing-entry.ts");

/**
 * R19+R29+R47 (Round 5): workspace 正規化。
 * 空/未指定 or **相対パス** ('.' '..' 'foo/bar' 等 = !path.isAbsolute) は空文字を返す
 * (cwd フォールバックしない)。絶対パスのみ path.resolve で冪等 normalize。
 */
function normalizeWorkspace(v) {
  const s = typeof v === "string" ? v.trim() : "";
  if (!s) return "";
  if (!path.isAbsolute(s)) return "";
  return path.resolve(s);
}

function parseArgs(argv) {
  const a = { workspace: "", session: "", out: "", workspace_provided: false };
  for (let i = 2; i < argv.length; i++) {
    const k = argv[i];
    if (k === "--workspace") { a.workspace = argv[++i] ?? ""; a.workspace_provided = true; }
    else if (k === "--session") a.session = argv[++i] ?? "";
    else if (k === "--out") a.out = argv[++i] ?? "";
  }
  a.workspace = normalizeWorkspace(a.workspace);
  if (a.session) a.session = path.resolve(a.session);
  else if (a.workspace) a.session = path.join(a.workspace, ".soloptilink-hearing-session.json");
  if (a.out) a.out = path.resolve(a.out);
  else if (a.workspace) a.out = path.join(a.workspace, "agent-evidence");
  return a;
}

/** R28: noop 時は engagement_ledger も一切露出しない (完全 no-op)。 */
function noop(reason, session_state = "absent") {
  return {
    ok: true, wired: true, has_data: false, session_state, reason,
    industry: "", dbl: "", dbl_valid: false, business_scale: "",
    purpose: "", purpose_source: "",
    required_modules: [], applicable_regulations: [], workflow: [], workflow_truncated_count: 0,
    ambiguities: [], ambiguities_input_count: 0, ambiguities_dropped_count: 0,
    total_dropped_count: 0, silent_drop_warnings: [], sanitization_incidents: [],
    pre_build_confirmation_questions: [], inference_block_markdown: "", injection_lines_for_agents: [],
    stale: false, stale_note: "",
    engagement_ledger_available: false, engagement_ledger_path: "", engagement_ledger_note: "",
    evidence_md_path: "", evidence_write_error: "",
  };
}

/** R36: ENTRY/BUNDLE 削除に耐える (存在チェック + try/catch)。 */
function computeHashes() {
  try {
    const srcData = fs.existsSync(ENTRY) ? fs.readFileSync(ENTRY) : Buffer.from("MISSING");
    const src = crypto.createHash("sha256").update(srcData).digest("hex") + "  hearing-entry.ts\n";
    const source_hash = crypto.createHash("sha256").update(src).digest("hex");
    const bundle_hash = fs.existsSync(BUNDLE)
      ? crypto.createHash("sha256").update(fs.readFileSync(BUNDLE)).digest("hex")
      : "";
    return { source_hash, bundle_hash };
  } catch {
    return { source_hash: "", bundle_hash: "" };
  }
}

/**
 * R36: checkStale の全体を try/catch で覆う。
 *   - meta.json 不在 / parse 失敗 / null / 非オブジェクト → stale=true
 *   - source_hash/bundle_hash 空/欠落 → stale=true
 *   - computeHashes 失敗 → stale=true (絶対に throw させない)
 */
function checkStale() {
  try {
    if (!fs.existsSync(META)) return { stale: true, note: "meta.json 不在" };
    let meta;
    try { meta = JSON.parse(fs.readFileSync(META, "utf-8")); }
    catch { return { stale: true, note: "meta.json 破損" }; }
    // meta が null / 非オブジェクトなら stale
    if (meta === null || typeof meta !== "object" || Array.isArray(meta))
      return { stale: true, note: "meta.json が object でない (null/Array 含む)" };
    if (typeof meta.bundle_hash !== "string" || meta.bundle_hash.length === 0)
      return { stale: true, note: "meta.bundle_hash 空/欠落" };
    if (typeof meta.source_hash !== "string" || meta.source_hash.length === 0)
      return { stale: true, note: "meta.source_hash 空/欠落" };
    const cur = computeHashes();
    if (!cur.source_hash || !cur.bundle_hash) return { stale: true, note: "computeHashes 失敗 (entry/bundle 削除等)" };
    if (meta.source_hash !== cur.source_hash) return { stale: true, note: "source_hash 不一致" };
    if (meta.bundle_hash !== cur.bundle_hash) return { stale: true, note: "bundle_hash 不一致 (改竄検知)" };
    return { stale: false, note: "fresh" };
  } catch {
    return { stale: true, note: "checkStale 予期しない例外" };
  }
}

/** R25: maxBuffer=1GB (Round 3 で 32MB 超過セッションが誤 corrupt 化した対策)。 */
function runBundle(sessionPath) {
  const env = { ...process.env, HEARING_SESSION_JSON_PATH: sessionPath };
  const r = spawnSync(process.execPath, [BUNDLE], {
    env, encoding: "utf-8", timeout: 60000, maxBuffer: 1024 * 1024 * 1024,
  });
  if (r.status !== 0 || !r.stdout) {
    const stderr = r.stderr || r.error?.message || "unknown";
    const err = new Error("バンドル実行失敗: " + stderr);
    err._enobufs = /ENOBUFS|maxBuffer/i.test(stderr);
    throw err;
  }
  return JSON.parse(r.stdout.trim().split("\n").filter(Boolean).pop());
}

/** R27: エラー詳細は短縮 (フルパス露出を抑制)。 */
function writeArtifact(outDir, recall) {
  try {
    fs.mkdirSync(outDir, { recursive: true });
    const md = [
      "<!-- AUTO-GENERATED by hearing-bridge (BOOST Step 0.65) -->",
      "# Hearing 自動取り込みレポート (要件ヒアリング → 全105ロール)",
      "",
      recall.inference_block_markdown || "(なし)",
      "",
      "## 全エージェントへの注入命令",
      "",
      ...(recall.injection_lines_for_agents ?? []).map((l) => `- ${l}`),
      "",
      "## 構築前確認質問 (曖昧点・仮定を置かず必ず顧客確認)",
      "",
      ...(recall.pre_build_confirmation_questions ?? []).map((q) => `- ${q}`),
      "",
      "## silent drop / サニタイズ警告 (常時可視化)",
      "",
      ...(recall.silent_drop_warnings ?? []).map((w) => `- ${w}`),
      "",
    ].join("\n");
    const outPath = path.join(outDir, "hearing-recall.md");
    fs.writeFileSync(outPath, md, "utf-8");
    return { ok: true, path: outPath, error: "" };
  } catch (e) {
    const code = e?.code ?? "";
    return { ok: false, path: "", error: code ? `書き込み失敗 (${code})` : "書き込み失敗" };
  }
}

function checkEngagementLedger() {
  const cand = process.env.HOME
    ? path.join(process.env.HOME, ".soloptilink", "lib", "engagement-ledger.sh")
    : "";
  const available = cand ? fs.existsSync(cand) : false;
  return {
    engagement_ledger_available: available,
    engagement_ledger_path: available ? cand : "",
    engagement_ledger_note: available
      ? "配置あり (bridge は変更しない・ledger 更新は /soloptilink-hearing 側で完結)"
      : "未配置 (寛容スキップ)",
  };
}

/**
 * R3+R28: has_data=false のときは engagement_ledger まで含めて顧客可視フィールドを全て空/false。
 * BOOST 側は has_data だけを見ればよい (単一の判断基準)。
 * sanitization_incidents だけは残す (内部監査用・顧客不可視・BOOST 正典で「顧客提示禁止」明記):
 *   incidents が非空 = 攻撃入力を無害化した記録 → デバッグ・監査に必要。
 *   silent_drop_warnings は顧客可視 (成果物 md に載る) のため空化する。
 */
function enforceCompleteNoop(result) {
  if (result.has_data === false) {
    const preserved = { ok: result.ok, wired: result.wired, has_data: false,
      session_state: result.session_state, reason: result.reason,
      stale: result.stale ?? false, stale_note: result.stale_note ?? "",
      kill_switch: result.kill_switch,
      sanitization_incidents: result.sanitization_incidents ?? [] };
    Object.assign(result, {
      industry: "", dbl: "", dbl_valid: false, business_scale: "",
      purpose: "", purpose_source: "",
      required_modules: [], applicable_regulations: [], workflow: [], workflow_truncated_count: 0,
      ambiguities: [], ambiguities_input_count: 0, ambiguities_dropped_count: 0,
      total_dropped_count: 0, silent_drop_warnings: [], sanitization_incidents: [],
      pre_build_confirmation_questions: [], inference_block_markdown: "", injection_lines_for_agents: [],
      engagement_ledger_available: false, engagement_ledger_path: "", engagement_ledger_note: "",
      evidence_md_path: "", evidence_write_error: "",
    });
    Object.assign(result, preserved);
    if (result.kill_switch === undefined) delete result.kill_switch;
  }
  return result;
}

function main() {
  const killSwitch = (process.env.ENABLE_HEARING_LINK ?? "").trim().toLowerCase();
  if (killSwitch === "off" || killSwitch === "false" || killSwitch === "0") {
    const out = { ...noop("ENABLE_HEARING_LINK=off (kill-switch により完全 no-op)"), kill_switch: "off" };
    process.stdout.write(JSON.stringify(out) + "\n");
    process.exit(0);
    return;
  }

  const args = parseArgs(process.argv);

  // R29+R47: workspace 必須化 + 絶対パス強制 (未指定/相対 → noop・cwd フォールバックしない)
  if (!args.workspace) {
    process.stdout.write(JSON.stringify(noop(
      "--workspace 未指定 or 相対パス (絶対パス必須・cwd フォールバックは廃止)"
    )) + "\n");
    process.exit(0);
    return;
  }
  // R48 (Round 5): --session が --workspace 配下でない場合は noop 返却 (workspace 外 JSON の注入経路封鎖)
  if (args.session) {
    const rel = path.relative(args.workspace, args.session);
    if (rel.startsWith("..") || path.isAbsolute(rel)) {
      process.stdout.write(JSON.stringify(noop(
        "--session が --workspace の外を指しています (workspace 配下のみ許可)"
      )) + "\n");
      process.exit(0);
      return;
    }
  }

  const ledger = checkEngagementLedger();
  let result;

  if (!fs.existsSync(args.session)) {
    // R28: noop 経路では ledger を spread しない (完全 no-op 保持)
    // R38: reason に絶対パス露出禁止 → basename に短縮
    result = noop(`セッションJSON 不在 (${path.basename(args.session)})`, "absent");
  } else {
    const stale = checkStale();
    if (stale.stale) {
      // R28: stale 経路も ledger を露出しない (完全 no-op)
      result = {
        ...noop(`【陳腐化検知】${stale.note} — 注入を抑止し、build-bundle.sh 再実行を待つ`, "absent"),
        stale: true, stale_note: stale.note,
      };
    } else {
      try {
        const recall = runBundle(args.session);
        result = {
          ok: recall.ok !== false, wired: true,
          has_data: Boolean(recall.has_data),
          session_state: recall.session_state ?? "present_valid",
          reason: recall.reason ?? "",
          industry: recall.industry ?? "", dbl: recall.dbl ?? "", dbl_valid: Boolean(recall.dbl_valid),
          business_scale: recall.business_scale ?? "",
          // T-I0-A: システム化の目的 (思想) を構築側へ素通しする。
          purpose: recall.purpose ?? "",
          purpose_source: recall.purpose_source ?? "",
          required_modules: recall.required_modules ?? [],
          applicable_regulations: recall.applicable_regulations ?? [],
          workflow: recall.workflow ?? [],
          workflow_truncated_count: typeof recall.workflow_truncated_count === "number" ? recall.workflow_truncated_count : 0,
          ambiguities: recall.ambiguities ?? [],
          ambiguities_input_count: typeof recall.ambiguities_input_count === "number" ? recall.ambiguities_input_count : 0,
          ambiguities_dropped_count: typeof recall.ambiguities_dropped_count === "number" ? recall.ambiguities_dropped_count : 0,
          total_dropped_count: typeof recall.total_dropped_count === "number" ? recall.total_dropped_count : 0,
          silent_drop_warnings: recall.silent_drop_warnings ?? [],
          sanitization_incidents: recall.sanitization_incidents ?? [],
          pre_build_confirmation_questions: recall.pre_build_confirmation_questions ?? [],
          inference_block_markdown: recall.inference_block_markdown ?? "",
          injection_lines_for_agents: recall.injection_lines_for_agents ?? [],
          stale: false, stale_note: stale.note, ...ledger,
        };
        if (result.has_data) {
          const w = writeArtifact(args.out, recall);
          result.evidence_md_path = w.ok ? w.path : "";
          result.evidence_write_error = w.error;
        } else {
          result.evidence_md_path = "";
          result.evidence_write_error = "";
        }
        // R3+R28: has_data=false なら engagement_ledger 等も全て空にする
        result = enforceCompleteNoop(result);
      } catch (e) {
        // R25: ENOBUFS を専用 reason に (corrupt とは区別)
        // R28: 例外経路も ledger 露出しない
        // R37: e.message にはスタックトレース/絶対パスが含まれるため reason に載せない
        const isEnobufs = e._enobufs === true;
        result = noop(
          isEnobufs
            ? "セッションJSON が上限 1GB を超えるため実行不可 (hearing 側で分割保存を推奨)"
            : "バンドル実行で例外 (推測補完せず安全スキップ)",
          "corrupt_or_schema_mismatch"
        );
      }
    }
  }
  process.stdout.write(JSON.stringify(result) + "\n");
  process.exit(0);
}

main();
