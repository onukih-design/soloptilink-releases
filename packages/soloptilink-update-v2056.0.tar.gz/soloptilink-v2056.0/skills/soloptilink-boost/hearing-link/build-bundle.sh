#!/usr/bin/env bash
# =============================================================================
# Hearing → BOOST 連携バンドルの再ビルド
# -----------------------------------------------------------------------------
# hearing-entry.ts を単一の自己完結 .mjs にバンドルし、ソースハッシュの
# sidecar(meta.json) を更新する。バンドル後の .mjs は外部依存ゼロ (fs/os/path のみ)
# のため実行に esbuild は不要。
#
# 実行タイミング:
#   - hearing-entry.ts を変更したとき
#   - bridge が「バンドルが陳腐化」と WARN を出したとき
#
# 【重要】hearing 本体 (~/.claude/skills/soloptilink-hearing/) および
# ~/.soloptilink/lib/hearing-engine.sh は「無編集参照」= バンドルに取り込まない。
# 依頼書「越境ゼロ」を担保するため、source_hash は hearing-entry.ts 単独で計算する。
# =============================================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENTRY="$HERE/hearing-entry.ts"
OUT="$HERE/hearing-recall.bundle.mjs"
META="$HERE/hearing-recall.bundle.meta.json"

# --- esbuild の所在を解決 ---
ESB=""
for c in \
  "$HOME/.soloptilink/admin-dashboard-true-source/node_modules/.bin/esbuild" \
  "$(command -v esbuild 2>/dev/null || true)" \
  "$HERE/node_modules/.bin/esbuild"; do
  if [ -n "$c" ] && [ -x "$c" ]; then ESB="$c"; break; fi
done
if [ -z "$ESB" ]; then
  echo "ERROR: esbuild が見つかりません。" >&2
  exit 2
fi

# --- バンドル生成 ---
"$ESB" "$ENTRY" \
  --bundle --platform=node --target=node18 --format=esm \
  --outfile="$OUT" --log-level=warning

# --- ソースハッシュ封緘 (entry 単独 = 越境ゼロ) ---
COMBINED="$(shasum -a 256 "$ENTRY" | awk '{print $1}')  hearing-entry.ts
"
SRC_HASH="$(printf '%s' "$COMBINED" | shasum -a 256 | awk '{print $1}')"
BUNDLE_HASH="$(shasum -a 256 "$OUT" | awk '{print $1}')"

cat > "$META" <<JSON
{
  "schema": "hearing-recall-bundle/1",
  "source_hash": "$SRC_HASH",
  "bundle_hash": "$BUNDLE_HASH",
  "note": "source_hash は hearing-entry.ts 単独の複合ハッシュ (hearing 本体・hearing-engine.sh は無編集参照=バンドルに取り込まない)。bridge が実行時に再計算して陳腐化を検知する。"
}
JSON

echo "OK: hearing bundle 再生成完了"
echo "  bundle: $OUT"
echo "  source_hash: $SRC_HASH"
