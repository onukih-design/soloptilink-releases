# Hearing → BOOST 知識連携 (hearing-link)

`/soloptilink-boost` 起動時に、`/soloptilink-hearing`（要件ヒアリングエンジン）が
Step 3 で保存した **`.soloptilink-hearing-session.json`（RFP-DNA 互換）** を自動で
読取専用消費し、ヒアリング済みの確定情報（業種・事業規模・必須モジュール・該当規制・
業務フロー）を全105ロールへ反映する連携レイヤー。**曖昧点（ambiguities）は推測で埋めず、
「構築前確認質問」として顧客提示ラインに変換**して注入する（hearing 側の捏造禁止規約を継承）。

**顧客が hearing を明示起動しなくても、セッションJSON があれば BOOST が起動時に自動適用する。**
研修A認定オペレーターの動線「ヒアリング→構築」の口頭転記断絶（Step 0.7 が再ヒアリングする問題）を根絶。

## 設計判断（executive-link / tenant-dna-link と同型）

- **hearing 本体・hearing-engine.sh は無編集参照（越境ゼロ）**。連携 API 相当は
  hearing 側にセッションJSON形式で保存済みだったが、BOOST 側に対応ステップ（Step 0.65）
  が無く **未配線**だった。本フォルダが配線する。
- **業種→DBL 再解決は書かない**。DBL の正規エンジンは `~/.soloptilink/lib/hearing-engine.sh`
  （CLI 契約: `sheet "<業種フレーズ>"` / `digest "<dbl名>"` — 変更禁止）が単独 SoT。
  bridge は **セッションJSON 内の `dbl` フィールド（detected/low_confidence/unregistered 三値相当）
  と `hearing.industry` をそのまま読取**する。CLI 契約の流用改変・独自再実装は禁止（V9 で静的検査）。
- **ロジックを写経しない**。注入行組み立ての真実源は hearing-entry.ts のみ（バンドル経由）。
- **実行基盤**: recall 依存グラフは外部 npm ゼロ（node 組込 fs/os/path/crypto のみ）。
  esbuild で単一の自己完結 `.mjs` にバンドルし、bare `node` で高速実行（数十 ms）・オフライン・依存ゼロ。
- **最優先指令の死守**: セッションJSON なし・破損・失敗はすべて no-op で素通り
  （bridge は常に exit 0）。

## 三状態 + 欠陥検知（born-passing で両側実証）

| 状態 | 入力 | 出力 | 意図 |
|---|---|---|---|
| ① present_valid | セッションJSON あり + スキーマ健全 | `has_data=true` / 注入行 / 確認質問 / 成果物 `agent-evidence/hearing-recall.md` | ヒアリング取り込み成功 |
| ② absent | セッションJSON 不在 | `has_data=false` / `session_state=absent` / 無害スキップ | hearing なし顧客・過剰注入禁止 |
| ③ corrupt_or_schema_mismatch | 破損JSON or skill≠soloptilink-hearing | `has_data=false` / `session_state=corrupt_or_schema_mismatch` / **推測補完せず安全スキップ** | 誤注入・捏造回避 |
| ④ 欠陥検知（FAIL 実証） | 変異版 bridge が曖昧点を確定値で穴埋め | 検知器が「= <値>(推論)」パターン or 「曖昧点あり かつ 確認質問空」を捕捉 | 恒真禁止・欠陥がすり抜けないこと |

## 過剰注入ガード（重要）

セッションJSON が **不在**の顧客には **完全に発火しない**（`has_data=false` / 注入行 0 件 /
成果物なし）。「hearing なし顧客への過剰注入」は V4 で常時検証。

## 曖昧点の扱い（捏造禁止規約継承）

`hearing.ambiguities[]` は各要素を `[要確認] <元文言> — この点はどう扱いますか?` 形式で
`pre_build_confirmation_questions[]` に **変換**する（元文字列を破棄せず温存）。
確定値・推論値・「はい/いいえ」等での**穴埋めは絶対にしない**。
注入行にも「以下の曖昧点は仮定を置かず必ず顧客に確認してから実装（推測・確定値での穴埋め禁止・
回答が得られるまで該当機能を仮実装しない）」を1本入れる。

## engagement-ledger との関係（寛容設計）

bridge は engagement-ledger を **読取のみ**（配置有無を JSON に記録するだけで、
書き換えはしない）。ledger 更新は `/soloptilink-hearing` 側で完結する仕様。
未配置環境では JSON に `engagement_ledger_available:false` を出して素通り
（hearing 側の寛容設計を bridge でも踏襲）。

## 構成ファイル

| ファイル | 役割 | 実行時必要 |
|---|---|---|
| `hearing-entry.ts` | バンドルのビルド元。セッションJSON パース＋注入行組み立て＋selftest（三状態＋欠陥） | ✗ (ビルド時のみ) |
| `hearing-recall.bundle.mjs` | 自己完結バンドル（hearing-entry.ts をバンドル済み） | ✓ |
| `hearing-recall.bundle.meta.json` | ソースハッシュ封緘（陳腐化検知） | ✓ |
| `hearing-bridge.mjs` | BOOST Step 0.65 の窓口。セッション検出→陳腐化検知→バンドル実行→成果物出力 | ✓ |
| `verify-hearing-bridge.mjs` | born-passing 検証ゲート（9軸） | 検証時 |
| `build-bundle.sh` | バンドル再生成＋メタ封緘 | 保守時 |

## BOOST からの呼び出し（Step 0.65）

```bash
node ~/.claude/skills/soloptilink-boost/hearing-link/hearing-bridge.mjs \
  --workspace "$PROJECT_DIR"   # → 1行 JSON
```

出力の主フィールド:
- `has_data` … 取り込み成功したか（false なら BOOST は無音で素通り）
- `session_state` … `present_valid` / `absent` / `corrupt_or_schema_mismatch`
- `injection_lines_for_agents` … `$TARGET_TASK` に追記する確定情報＋確認ガード文
- `pre_build_confirmation_questions` … 顧客に見せる確認質問（曖昧点を変換したもの）
- `inference_block_markdown` … 設計入力（`$PROJECT_DIR/agent-evidence/hearing-recall.md` に自動保存）
- `industry` / `dbl` / `business_scale` / `required_modules` / `applicable_regulations` / `workflow` … 個別フィールド
- `stale` … バンドルが陳腐化していれば true
- `engagement_ledger_available` … ledger 配置状況（未配置=false で寛容スキップ）
- `kill_switch` … `off` のとき完全 no-op

## kill-switch

- `ENABLE_HEARING_LINK=off`（`false`/`0` も可）→ 完全 no-op（旧挙動へフォールバック・障害時の安全弁）
- 既定は on（環境変数未設定または `auto`/`on`）

## 検証（born-passing 9軸）

```bash
node ~/.claude/skills/soloptilink-boost/hearing-link/verify-hearing-bridge.mjs
```

V1 同梱 / V2 selftest（三状態＋欠陥） / V3 present_valid → 注入＋確認質問＋成果物 /
V4 absent → 無害スキップ / V5 corrupt → 安全スキップ / V6 kill-switch off → no-op /
V7 陳腐化検知 / V8 欠陥検知器（曖昧点確定値埋めを捕捉） /
V9 **独自DBL再解決の禁止**（`spawnSync`/`execSync` に `hearing-engine.sh`/`dbl-detect.sh` が
現れないことを静的検査 = CLI 契約流用改変ゼロ）。

## 保守

hearing-entry.ts を変更したら必ずバンドルを再生成:

```bash
bash ~/.claude/skills/soloptilink-boost/hearing-link/build-bundle.sh
```

## ★ SKILL.md 配線の重要注意（SoT）

boost の SKILL.md は **4箇所に同期されるミラー**で、**正典(SoT)は
`~/.claude/commands/soloptilink-boost.md`**。`~/.claude/skills/.../SKILL.md`(稼働スキル)を
直接編集しても、Stop フックの `skill-sot-guard.sh heal` が正典で上書きして**巻き戻す**。
よって Step 0.65 配線は必ず **正典を編集 → `skill-sot-guard.sh heal` → `refresh`(snapshot再取得)**
の順で行うこと。本連携の Step 0.65 はこの手順で4箇所すべてに反映済み。
（lib/bundle/bridge は SKILL.md ではないため heal の対象外＝直接配置で永続する。）

## 既知の制約 / owner 申し送り

- 発火は「セッションJSON 実在時のみ」。hearing を経ずに boost を起動した場合は完全 no-op。
- バンドルは hearing-entry.ts 単独を内包する（hearing 本体・hearing-engine.sh は無編集参照＝バンドルに取り込まない）。
- engagement-ledger 未配置環境では JSON にその旨を出して素通り（hearing 側の寛容設計を踏襲）。
- 同型の先行例は `../executive-link/`（Step 0.55）・`../tenant-dna-link/`（Step 0.95）・`../japan-link/`（Step 0.88）。
