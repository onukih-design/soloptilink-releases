#!/usr/bin/env node
/**
 * Tenant DNA → BOOST 連携の検証ゲート (born-passing)
 * ============================================================================
 * 配線が「実際に効く」ことを end-to-end で実証する。
 * 健全データを正規ライターで種付けし、想起→注入文生成までを検証する。
 * 配線が壊れる / tenant-dna のスキーマが変わる / バンドルが陳腐化すると FAIL。
 *
 * 実行: node verify-tenant-dna-bridge.mjs
 * 終了コード: 全 PASS=0 / 1つでも FAIL=1
 *
 * 検証する性質 (CHECK):
 *   V1  バンドルと meta が同梱されている
 *   V2  bundle --selftest (安全版・命名規則注入) が PASS
 *   V3  bundle --selftest-home (banLibrary 往復含む) が PASS
 *   V4  bridge: 識別子なし → has_data=false の no-op (本流を止めない)
 *   V5  bridge: 種付け済み workspace → has_data=true + 命名規則/禁止LIB が注入文に出る
 *   V6  bundle のソースハッシュが meta と一致 (陳腐化していない)
 *   V7  no-op でも exit 0 (BOOST 最優先指令: 絶対に止めない)
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import * as os from 'node:os';
import * as crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const BUNDLE = path.join(HERE, 'tenant-dna-recall.bundle.mjs');
const META = path.join(HERE, 'tenant-dna-recall.bundle.meta.json');
const BRIDGE = path.join(HERE, 'tenant-dna-bridge.mjs');
const TDNA_LIB = path.resolve(HERE, '..', '..', 'soloptilink-tenant-dna', 'lib');

const results = [];
function check(id, name, fn) {
  try {
    const r = fn();
    results.push({ id, name, pass: r === true, detail: r === true ? '' : String(r) });
  } catch (e) {
    results.push({ id, name, pass: false, detail: 'EXC: ' + e.message });
  }
}

function runNode(args, env) {
  return spawnSync(process.execPath, args, {
    env: { ...process.env, ...env },
    encoding: 'utf-8',
    timeout: 25000,
  });
}
function lastJson(stdout) {
  const line = (stdout || '').trim().split('\n').filter(Boolean).pop();
  return line ? JSON.parse(line) : null;
}

// --- V1 ---
check('V1', 'バンドルと meta が同梱', () => {
  if (!fs.existsSync(BUNDLE)) return 'bundle が無い';
  if (!fs.existsSync(META)) return 'meta が無い';
  if (!fs.existsSync(BRIDGE)) return 'bridge が無い';
  return true;
});

// --- V2 ---
// 注: tenant-dna 上流の recall 経路 (recall_engine:50 distillPatterns /
//     memory_graph:80,280 getSier) は root 引数を引き継がず実 STORAGE_ROOT を
//     触るため、root 指定だけでは隔離できない。唯一確実な隔離は HOME 上書き。
//     よって安全版 selftest も temp HOME 配下で実行し、実データ汚染を完全に防ぐ。
check('V2', 'bundle --selftest (命名規則注入) PASS', () => {
  const tmpHome = fs.mkdtempSync(path.join(os.tmpdir(), 'tdna-verify-st-'));
  try {
    const r = runNode([BUNDLE, '--selftest'], { HOME: tmpHome });
    const j = lastJson(r.stdout);
    if (r.status !== 0) return 'exit!=0: ' + (j?.failures?.join('; ') || r.stderr);
    if (!j || j.ok !== true) return 'failures: ' + (j?.failures?.join('; ') || '?');
    return true;
  } finally {
    fs.rmSync(tmpHome, { recursive: true, force: true });
  }
});

// --- V3 ---
check('V3', 'bundle --selftest-home (banLibrary往復) PASS', () => {
  const tmpHome = fs.mkdtempSync(path.join(os.tmpdir(), 'tdna-verify-home-'));
  try {
    const r = runNode([BUNDLE, '--selftest-home'], {
      HOME: tmpHome,
      TDNA_SELFTEST_ALLOW: '1',
    });
    const j = lastJson(r.stdout);
    if (r.status !== 0) return 'exit!=0: ' + (j?.failures?.join('; ') || r.stderr);
    if (!j || j.ok !== true) return 'failures: ' + (j?.failures?.join('; ') || '?');
    return true;
  } finally {
    fs.rmSync(tmpHome, { recursive: true, force: true });
  }
});

// --- V4 / V7 ---
check('V4', 'bridge 識別子なし → no-op (has_data=false)', () => {
  const tmpHome = fs.mkdtempSync(path.join(os.tmpdir(), 'tdna-verify-empty-'));
  const ws = fs.mkdtempSync(path.join(os.tmpdir(), 'tdna-verify-ws-'));
  try {
    const r = runNode([BRIDGE, '--workspace', ws], { HOME: tmpHome });
    const j = lastJson(r.stdout);
    if (j?.has_data !== false) return 'has_data が false でない';
    if (j?.injection_lines_for_agents?.length !== 0) return '注入文が空でない';
    return true;
  } finally {
    fs.rmSync(tmpHome, { recursive: true, force: true });
    fs.rmSync(ws, { recursive: true, force: true });
  }
});
check('V7', 'bridge no-op でも exit 0 (本流を止めない)', () => {
  const tmpHome = fs.mkdtempSync(path.join(os.tmpdir(), 'tdna-verify-exit-'));
  const ws = fs.mkdtempSync(path.join(os.tmpdir(), 'tdna-verify-exitws-'));
  try {
    const r = runNode([BRIDGE, '--workspace', ws], { HOME: tmpHome });
    return r.status === 0 ? true : 'exit=' + r.status;
  } finally {
    fs.rmSync(tmpHome, { recursive: true, force: true });
    fs.rmSync(ws, { recursive: true, force: true });
  }
});

// --- V5 (種付け→bridge想起 end-to-end) ---
check('V5', 'bridge: 種付け済み → 命名規則/禁止LIB が注入される', () => {
  const tmpHome = fs.mkdtempSync(path.join(os.tmpdir(), 'tdna-verify-seed-'));
  const ws = fs.mkdtempSync(path.join(os.tmpdir(), 'tdna-verify-seedws-'));
  try {
    // 正規ライター (selftest-home) で HOME に種付け
    const seed = runNode([BUNDLE, '--selftest-home'], {
      HOME: tmpHome,
      TDNA_SELFTEST_ALLOW: '1',
    });
    if (seed.status !== 0) return '種付け失敗: ' + seed.stderr;
    // workspace ファイルで識別子を指定
    fs.writeFileSync(
      path.join(ws, '.soloptilink-tenant.json'),
      JSON.stringify({ sier_id: 'nttdata', tenant_id: 'selftest-home-co' })
    );
    const r = runNode([BRIDGE, '--workspace', ws], { HOME: tmpHome });
    const j = lastJson(r.stdout);
    if (!j?.has_data) return 'has_data=false (想起されない)';
    const inj = (j.injection_lines_for_agents || []).join('\n');
    if (!/snake_case/.test(inj)) return '命名規則が注入文に無い';
    if (!/moment/.test(inj)) return '採用禁止ライブラリが注入文に無い';
    if (!/date-fns/.test(inj)) return '代替推奨が注入文に無い';
    // 成果物が書かれたか
    if (!fs.existsSync(path.join(ws, 'agent-evidence', 'tenant-dna-recall.md')))
      return '成果物(tenant-dna-recall.md)が書かれていない';
    return true;
  } finally {
    fs.rmSync(tmpHome, { recursive: true, force: true });
    fs.rmSync(ws, { recursive: true, force: true });
  }
});

// --- V6 (陳腐化検知) ---
check('V6', 'バンドルが陳腐化していない (source_hash 一致)', () => {
  if (!fs.existsSync(META)) return 'meta が無い';
  const meta = JSON.parse(fs.readFileSync(META, 'utf-8'));
  const files = [
    path.join(HERE, 'recall-entry.ts'),
    path.join(TDNA_LIB, 'index.ts'),
    path.join(TDNA_LIB, 'recall_engine.ts'),
    path.join(TDNA_LIB, 'memory_graph.ts'),
    path.join(TDNA_LIB, 'cross_project_synthesizer.ts'),
    path.join(TDNA_LIB, 'storage.ts'),
    path.join(TDNA_LIB, 'types.ts'),
    path.join(TDNA_LIB, 'tenant_profile.ts'),
    path.join(TDNA_LIB, 'naming_convention.ts'),
    path.join(TDNA_LIB, 'library_blacklist.ts'),
    path.join(TDNA_LIB, 'decision_memory.ts'),
  ];
  let combined = '';
  for (const f of files) {
    if (!fs.existsSync(f)) continue;
    const h = crypto.createHash('sha256').update(fs.readFileSync(f)).digest('hex');
    combined += `${h}  ${path.basename(f)}\n`;
  }
  const cur = crypto.createHash('sha256').update(combined).digest('hex');
  return meta.source_hash === cur
    ? true
    : '陳腐化: meta=' + meta.source_hash.slice(0, 12) + ' cur=' + cur.slice(0, 12) + ' → build-bundle.sh 再実行';
});

// --- 出力 ---
const passed = results.filter((r) => r.pass).length;
const failed = results.length - passed;
console.log('=== Tenant DNA → BOOST 連携 検証ゲート ===');
for (const r of results) {
  console.log(`${r.pass ? '✓' : '✗'} ${r.id} ${r.name}${r.detail ? '  — ' + r.detail : ''}`);
}
console.log(`---`);
console.log(`PASS=${passed} FAIL=${failed} (計 ${results.length})`);
process.exit(failed === 0 ? 0 : 1);
