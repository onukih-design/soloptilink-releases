#!/usr/bin/env bash
# =============================================================================
# Tenant DNA → BOOST 連携バンドルの再ビルド
# -----------------------------------------------------------------------------
# recall-entry.ts と tenant-dna の recall 依存グラフを単一の自己完結 .mjs に
# バンドルし、ソースハッシュの sidecar (meta.json) を更新する。
#
# 実行タイミング:
#   - tenant-dna の lib/ (recall 系) を変更したとき
#   - recall-entry.ts を変更したとき
#   - bridge が「バンドルが陳腐化している」と WARN を出したとき
#
# 依存: esbuild (admin-dashboard 同梱を build-time tool として使用)。
#       バンドル後の .mjs は外部依存ゼロ (node 組込のみ) のため、
#       配布物の実行に esbuild は不要。
# =============================================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TDNA_LIB="$(cd "$HERE/../../soloptilink-tenant-dna/lib" && pwd)"
ENTRY="$HERE/recall-entry.ts"
OUT="$HERE/tenant-dna-recall.bundle.mjs"
META="$HERE/tenant-dna-recall.bundle.meta.json"

# --- esbuild の所在を解決 (複数候補をフォールバック) ---
ESB=""
for c in \
  "$HOME/.soloptilink/admin-dashboard-true-source/node_modules/.bin/esbuild" \
  "$(command -v esbuild 2>/dev/null || true)" \
  "$HERE/node_modules/.bin/esbuild"; do
  if [ -n "$c" ] && [ -x "$c" ]; then ESB="$c"; break; fi
done
if [ -z "$ESB" ]; then
  echo "ERROR: esbuild が見つかりません。ビルドできません。" >&2
  exit 2
fi

# --- バンドル生成 ---
"$ESB" "$ENTRY" \
  --bundle \
  --platform=node \
  --target=node18 \
  --format=esm \
  --outfile="$OUT" \
  --log-level=warning

# --- ソースハッシュ封緘 (tenant-dna recall 依存 + entry) ---
# これらのファイルが変わるとハッシュが変わり、bridge が陳腐化を検知する。
SRC_FILES=(
  "$ENTRY"
  "$TDNA_LIB/index.ts"
  "$TDNA_LIB/recall_engine.ts"
  "$TDNA_LIB/memory_graph.ts"
  "$TDNA_LIB/cross_project_synthesizer.ts"
  "$TDNA_LIB/storage.ts"
  "$TDNA_LIB/types.ts"
  "$TDNA_LIB/tenant_profile.ts"
  "$TDNA_LIB/naming_convention.ts"
  "$TDNA_LIB/library_blacklist.ts"
  "$TDNA_LIB/decision_memory.ts"
)
COMBINED=""
for f in "${SRC_FILES[@]}"; do
  if [ -f "$f" ]; then
    COMBINED+="$(shasum -a 256 "$f" | awk '{print $1}')  $(basename "$f")
"
  fi
done
SRC_HASH="$(printf '%s' "$COMBINED" | shasum -a 256 | awk '{print $1}')"
BUNDLE_HASH="$(shasum -a 256 "$OUT" | awk '{print $1}')"

cat > "$META" <<JSON
{
  "schema": "tenant-dna-recall-bundle/1",
  "source_hash": "$SRC_HASH",
  "bundle_hash": "$BUNDLE_HASH",
  "source_files": [
$(printf '    "%s"' "$(basename "${SRC_FILES[0]}")"; for f in "${SRC_FILES[@]:1}"; do printf ',\n    "%s"' "$(basename "$f")"; done)
  ],
  "note": "source_hash は tenant-dna recall 依存 + recall-entry.ts の複合ハッシュ。bridge が実行時に再計算して陳腐化を検知する。"
}
JSON

echo "OK: bundle 再生成完了"
echo "  bundle: $OUT"
echo "  meta:   $META"
echo "  source_hash: $SRC_HASH"
