/**
 * Tenant DNA → BOOST 連携エントリ (ビルド元)
 * ------------------------------------------------------------------
 * このファイルは esbuild で `tenant-dna-recall.bundle.mjs` に
 * 単一ファイルへバンドルされる「ビルド元ソース」です。実行時には
 * バンドル済み .mjs を bare `node` で動かすため、本ファイル自体は
 * 直接 import されません (build-bundle.sh 参照)。
 *
 * 役割:
 *   - tenant-dna の「正規 API」recallForBoost をそのまま呼び出す
 *     (ロジックを写経せず、唯一の真実源として再利用 = ドリフト防止)。
 *   - BOOST 側が読み取れる JSON を stdout に出力する。
 *   - --selftest モードでは合成テナントを正規ライターで種付けし、
 *     想起 → 注入文生成までを end-to-end で自己検証する (born-passing)。
 *
 * 入力 (環境変数):
 *   TDNA_SIER       SIer id (nttdata|fujitsu|nri|nomura|nec|hitachi|tis|generic)
 *   TDNA_TENANT     顧客テナント id
 *   TDNA_PROJECT    プロジェクト id (任意)
 *   TDNA_HINT       想起ヒント (任意)
 *   TDNA_INDUSTRY   検出業種 (任意)
 *   TDNA_KEYWORDS   検出キーワード カンマ区切り (任意)
 *   TDNA_WORKSPACE  作業ディレクトリ (任意)
 *   TDNA_STORAGE_ROOT 学習データ root の上書き (テスト用・任意)
 *
 * 出力 (stdout, 1行 JSON):
 *   { ok, mode, has_data, inference_block_markdown,
 *     injection_lines_for_agents, handoff_markdown }
 */

import * as os from 'node:os';
import * as path from 'node:path';
import * as fs from 'node:fs';

import {
  recallForBoost,
  renderCustomerHandoffSection,
  registerSier,
  registerCustomer,
  defineNamingRule,
  banLibrary,
  type SierId,
} from '../../soloptilink-tenant-dna/lib/index';

const VALID_SIERS: readonly SierId[] = [
  'nttdata',
  'fujitsu',
  'nri',
  'nomura',
  'nec',
  'hitachi',
  'tis',
  'generic',
];

function emit(obj: unknown): void {
  process.stdout.write(JSON.stringify(obj) + '\n');
}

/** 環境変数から RecallForBoost 入力を組み立てる。SIer は許可リストで検証。 */
function buildInputFromEnv(): {
  sier_id?: SierId;
  tenant_id?: string;
  project_id?: string;
  hint?: string;
  workspace_dir?: string;
  detected_industry?: string;
  detected_keywords?: string[];
} {
  const rawSier = (process.env.TDNA_SIER ?? '').trim();
  const sier_id = VALID_SIERS.includes(rawSier as SierId)
    ? (rawSier as SierId)
    : undefined;
  const tenant_id = (process.env.TDNA_TENANT ?? '').trim() || undefined;
  const project_id = (process.env.TDNA_PROJECT ?? '').trim() || undefined;
  const hint = (process.env.TDNA_HINT ?? '').trim() || undefined;
  const workspace_dir = (process.env.TDNA_WORKSPACE ?? '').trim() || undefined;
  const detected_industry =
    (process.env.TDNA_INDUSTRY ?? '').trim() || undefined;
  const kw = (process.env.TDNA_KEYWORDS ?? '').trim();
  const detected_keywords = kw
    ? kw
        .split(',')
        .map((s) => s.trim())
        .filter((s) => s.length > 0)
    : undefined;
  return {
    sier_id,
    tenant_id,
    project_id,
    hint,
    workspace_dir,
    detected_industry,
    detected_keywords,
  };
}

/** 通常の想起。学習データを読み取り、注入ブロックと注入文を返す。 */
function runRecall(rootOverride?: string): void {
  const input = buildInputFromEnv();
  const root =
    rootOverride ?? (process.env.TDNA_STORAGE_ROOT?.trim() || undefined);

  // 識別子が無い (= 顧客未指定) 場合は何もしない。BOOST はこれを無音で素通りする。
  const out = root
    ? recallForBoost(input, root)
    : recallForBoost(input);

  let handoff_markdown = '';
  if (out.has_data && input.sier_id && input.tenant_id) {
    try {
      handoff_markdown = root
        ? renderCustomerHandoffSection(input.sier_id, input.tenant_id, root)
        : renderCustomerHandoffSection(input.sier_id, input.tenant_id);
    } catch {
      // 引継ぎ生成失敗は致命ではない。空のまま続行。
      handoff_markdown = '';
    }
  }

  emit({
    ok: true,
    mode: 'recall',
    has_data: out.has_data,
    inference_block_markdown: out.inference_block_markdown,
    injection_lines_for_agents: out.injection_lines_for_agents,
    handoff_markdown,
  });
}

/**
 * born-passing 自己検証 (安全版・いつでも実行可)。
 * root 引数を取るライターのみで合成テナントを種付けし、recallForBoost が
 * その命名規則を注入文へ反映するか / 識別子なしで no-op になるかを実証する。
 * 全書き込みが tmpRoot に閉じるため、実データを一切汚染しない。
 *   ※ banLibrary は root 引数を持たず HOME 固定の STORAGE_ROOT に書くため、
 *     ここでは呼ばない (実データ汚染回避)。採用禁止ライブラリの round-trip は
 *     --selftest-home (HOME 上書き前提) 側で検証する。
 */
function runSelftest(): void {
  const failures: string[] = [];

  const tmpRoot = fs.mkdtempSync(
    path.join(os.tmpdir(), 'tdna-boost-selftest-')
  );
  try {
    const sier_id: SierId = 'nttdata';
    const tenant_id = 'selftest-co';

    // --- 種付け (root 指定の正規ライターのみ = tmpRoot に閉じる) ---
    registerSier({ sier_id }, tmpRoot);
    registerCustomer(
      {
        sier_id,
        tenant_id,
        display_name: 'セルフテスト商事',
        industry_ja: '建設業',
      },
      tmpRoot
    );
    defineNamingRule(
      {
        sier_id,
        tenant_id,
        scope: 'db_table',
        case_style: 'snake_case',
        prefix: 'm_',
        rationale: 'selftest: テーブルは m_ 接頭辞 + snake_case',
      },
      tmpRoot
    );

    // --- 想起 ---
    const out = recallForBoost({ sier_id, tenant_id }, tmpRoot);

    // --- 表明 (assertions) ---
    if (!out.has_data) {
      failures.push('has_data が false (命名規則を入れたのに想起されない)');
    }
    const joined = out.injection_lines_for_agents.join('\n');
    if (!/snake_case/.test(joined)) {
      failures.push('注入文に命名規則(snake_case)が反映されていない');
    }
    if (!/m_/.test(joined)) {
      failures.push('注入文に接頭辞(prefix=m_)が反映されていない');
    }
    if (!out.inference_block_markdown.includes('Tenant DNA 自動適用')) {
      failures.push('推論ブロックのヘッダが欠落');
    }

    // --- negative: 識別子なし → 必ず no-op ---
    const empty = recallForBoost({}, tmpRoot);
    if (empty.has_data) {
      failures.push('識別子なしなのに has_data=true (no-op になっていない)');
    }
    if (empty.injection_lines_for_agents.length !== 0) {
      failures.push('識別子なしなのに注入文が生成された');
    }
  } catch (e) {
    failures.push('selftest 実行中に例外: ' + (e as Error).message);
  } finally {
    try {
      fs.rmSync(tmpRoot, { recursive: true, force: true });
    } catch {
      /* cleanup 失敗は無視 */
    }
  }

  emit({
    ok: failures.length === 0,
    mode: 'selftest',
    failures,
  });
  process.exit(failures.length === 0 ? 0 : 1);
}

/**
 * born-passing 自己検証 (完全版・HOME 上書き前提)。
 * default の STORAGE_ROOT (HOME ベース) に対して種付け→想起を行い、
 * banLibrary を含む採用禁止ライブラリの round-trip まで検証する。
 *   呼び出し側 (verify ゲート) が必ず HOME を temp に差し替えてから
 *   別プロセスで起動する。実 HOME での誤実行を防ぐため、
 *   TDNA_SELFTEST_ALLOW=1 を必須とし、HOME 配下に実テナントが無いことも確認する。
 */
function runSelftestHome(): void {
  const failures: string[] = [];

  if (process.env.TDNA_SELFTEST_ALLOW !== '1') {
    emit({
      ok: false,
      mode: 'selftest-home',
      failures: ['TDNA_SELFTEST_ALLOW=1 が未設定 (実データ汚染防止のため拒否)'],
    });
    process.exit(1);
  }

  const learningRoot = path.join(
    os.homedir(),
    '.soloptilink',
    'learning',
    'tenants'
  );
  // 安全装置: 既存テナント (auto_harvest 以外のディレクトリ) がある HOME では実行しない。
  try {
    if (fs.existsSync(learningRoot)) {
      const entries = fs
        .readdirSync(learningRoot)
        .filter((n) => n !== 'auto_harvest' && !n.startsWith('.'));
      if (entries.length > 0) {
        emit({
          ok: false,
          mode: 'selftest-home',
          failures: [
            'HOME 配下に既存テナントを検出: ' +
              entries.join(',') +
              ' (実データ汚染防止のため拒否。temp HOME で実行すること)',
          ],
        });
        process.exit(1);
      }
    }
  } catch {
    /* 読めない場合は続行 (空とみなす) */
  }

  try {
    const sier_id: SierId = 'nttdata';
    const tenant_id = 'selftest-home-co';

    // default root (HOME ベース) へ種付け
    registerSier({ sier_id });
    registerCustomer({
      sier_id,
      tenant_id,
      display_name: 'セルフテスト(HOME)商事',
    });
    defineNamingRule({
      sier_id,
      tenant_id,
      scope: 'db_column',
      case_style: 'snake_case',
      rationale: 'selftest-home: カラムは snake_case',
    });
    banLibrary(
      {
        tenant_id,
        library_name: 'moment',
        language: 'typescript',
        reason: 'selftest-home: バンドルサイズ過大',
        alternative_recommendation: 'date-fns',
        scope: 'customer',
      },
      sier_id
    );

    const out = recallForBoost({ sier_id, tenant_id });

    if (!out.has_data) failures.push('has_data が false');
    const joined = out.injection_lines_for_agents.join('\n');
    if (!/snake_case/.test(joined)) {
      failures.push('注入文に命名規則が反映されていない');
    }
    if (!/moment/.test(joined)) {
      failures.push('注入文に採用禁止ライブラリ(moment)が反映されていない');
    }
    if (!/date-fns/.test(joined)) {
      failures.push('注入文に代替推奨(date-fns)が反映されていない');
    }
  } catch (e) {
    failures.push('selftest-home 実行中に例外: ' + (e as Error).message);
  }

  emit({
    ok: failures.length === 0,
    mode: 'selftest-home',
    failures,
  });
  process.exit(failures.length === 0 ? 0 : 1);
}

// --- エントリポイント ---
const arg = process.argv[2] ?? '';
if (arg === '--selftest') {
  runSelftest();
} else if (arg === '--selftest-home') {
  runSelftestHome();
} else {
  try {
    runRecall();
  } catch (e) {
    // 想起の失敗は BOOST 本流を絶対に止めない。空の no-op として返す。
    emit({
      ok: false,
      mode: 'recall',
      has_data: false,
      inference_block_markdown: '',
      injection_lines_for_agents: [],
      handoff_markdown: '',
      error: (e as Error).message,
    });
  }
}
