# Tenant DNA → BOOST 知識連携 (tenant-dna-link)

`/soloptilink-boost` 起動時に、`/soloptilink-tenant-dna` が学習した**顧客固有の暗黙知**
（命名規則・採用禁止ライブラリ・過去の決裁・推奨スタック）を自動で想起し、
ビルドの全105ロールへ反映する連携レイヤー。顧客が tenant-dna を明示起動しなくても、
登録済みなら BOOST が起動時に自動適用する。

## 設計判断（なぜこの形か）

- **tenant-dna は無編集（越境ゼロ）**。連携 API `recallForBoost` は tenant-dna 側に
  既に実装・export 済みだったが、BOOST 側に対応ステップ（Step 0.4d）が無く
  **完全に未配線（孤立した完成者）**だった。本フォルダはその API を BOOST に配線する。
- **ロジックを写経しない**。recall の唯一の真実源は tenant-dna の `recallForBoost`。
  ブリッジは識別子解決と入出力の配線のみを担う。スキーマや想起ロジックを
  BOOST 側に複製しない（ドリフト防止）。
- **実行基盤**: Node 18（型ストリップ不可）・tsx 無し・esbuild は管理ダッシュボード配下のみ。
  recall 依存グラフは **外部 npm ゼロ（node 組込のみ）** のため、esbuild で
  **単一の自己完結 `.mjs` にバンドル**して同梱。実行は bare `node` で高速（数十 ms）・
  オフライン・依存ゼロ。
- **最優先指令の死守**: BOOST の「一発完成・止めない」を壊さないため、
  識別子なし・データ空・失敗はすべて **no-op で素通り（常に exit 0）**。

## 構成ファイル

| ファイル | 役割 | 実行時必要 |
|---|---|---|
| `recall-entry.ts` | バンドルのビルド元。`recallForBoost` を呼ぶ薄いエントリ＋selftest 2種 | ✗ (ビルド時のみ) |
| `tenant-dna-recall.bundle.mjs` | 自己完結バンドル（tenant-dna の正規コードを内包） | ✓ |
| `tenant-dna-recall.bundle.meta.json` | ソースハッシュ封緘（陳腐化検知用） | ✓ |
| `tenant-dna-bridge.mjs` | BOOST Step 0.95 の窓口。識別子解決→陳腐化検知→バンドル実行→成果物出力 | ✓ |
| `verify-tenant-dna-bridge.mjs` | born-passing 検証ゲート（7軸） | 検証時 |
| `build-bundle.sh` | バンドル再生成＋メタ封緘 | 保守時 |

## 顧客識別子の解決順位（ブリッジ内・上が優先）

1. 環境変数 `SOLOPTILINK_SIER` / `SOLOPTILINK_TENANT`（+ `_PROJECT` / `_HINT`）
2. `$PROJECT_DIR/.soloptilink-tenant.json` … `{ "sier_id", "tenant_id", "project_id?", "hint?" }`
3. 自動検出: 学習データに **SIer 1社 × 顧客 1社** だけ登録されている場合のみ採用
4. いずれも無ければ **no-op**

SIer は `nttdata|fujitsu|nri|nomura|nec|hitachi|tis|generic` のいずれか。

## BOOST からの呼び出し（Step 0.95）

```bash
node ~/.claude/skills/soloptilink-boost/tenant-dna-link/tenant-dna-bridge.mjs \
  --workspace "$PROJECT_DIR" --industry "$DETECTED_INDUSTRY"
```

出力（1行 JSON）の主フィールド:
- `has_data` … 想起できたか（false なら BOOST は無音で素通り）
- `injection_lines_for_agents` … `$TARGET_TASK` に追記する制約文（命名規則・禁止LIB・過去判断・推奨スタック）
- `inference_block_markdown` … 設計入力（`$PROJECT_DIR/agent-evidence/tenant-dna-recall.md` に自動保存）
- `handoff_markdown` … 引継ぎ/設計契約文書への添付用
- `stale` … バンドルが陳腐化していれば true

`injection_lines_for_agents` を `$TARGET_TASK` に折り込むと、Step 2.A の `plan` が
各ロール prompt に自動注入するため、**全105ロールが顧客固有ルールに準拠**する
（orchestrator 無編集）。

## 検証（born-passing 7軸）

```bash
node ~/.claude/skills/soloptilink-boost/tenant-dna-link/verify-tenant-dna-bridge.mjs
```

V1 同梱確認 / V2 安全版selftest（命名規則注入）/ V3 完全版selftest（banLibrary往復）/
V4 識別子なし no-op / V5 種付け→注入 end-to-end / V6 陳腐化検知 / V7 no-op でも exit 0。

## 保守

tenant-dna の recall 系（`lib/recall_engine.ts` など）を更新したらバンドルを再生成:

```bash
bash ~/.claude/skills/soloptilink-boost/tenant-dna-link/build-bundle.sh
```

ブリッジは実行時にソースハッシュを再計算し、`meta.json` と不一致なら
`stale=true` を返す（陳腐化を黙殺しない）。再生成後は検証ゲートで裏取りする。

## 既知の制約 / owner 申し送り

- `banLibrary` は root 引数を取らず HOME 固定の STORAGE_ROOT に書くため、
  採用禁止ライブラリ往復の検証は HOME 上書き前提の `--selftest-home`
  （`TDNA_SELFTEST_ALLOW=1` 必須・実テナント検出時は拒否）で行う。
- 自動検出は「SIer1社×顧客1社」のみ。複数顧客を扱う端末では
  `.soloptilink-tenant.json` か環境変数で明示すること（誤適用防止）。
- バンドルは tenant-dna の recall ロジックを内包する。tenant-dna 更新時は
  必ず `build-bundle.sh` を再実行する（陳腐化 WARN が出る）。
- **【上流の既知不具合・owner 候補修正】** tenant-dna の recall 経路に
  `root` 引数を引き継がず実 STORAGE_ROOT（HOME 配下）を触る箇所がある:
  `lib/recall_engine.ts:50`（distillPatterns）/ `lib/memory_graph.ts:80,280`
  （getSier）。このため root 指定だけでは想起をテスト用領域に隔離できず、
  recall 実行時に builtin SIer プロファイルが実 HOME に書かれる（顧客0件・
  機能的には無害）。本連携の selftest は **HOME 上書き**で完全隔離して回避済み
  （直接 `node bundle.mjs --selftest` を実 HOME で叩くと builtin プロファイルが
  残る点に注意。検証は必ず `verify-tenant-dna-bridge.mjs` 経由で行う）。
  本番では実 HOME が正しい対象なので影響なし。恒久修正は tenant-dna 側で
  上記3箇所に `root` を渡すこと（本連携は tenant-dna 無編集方針のため未修正）。
