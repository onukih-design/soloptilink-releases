// recall-entry.ts
import * as os2 from "node:os";
import * as path3 from "node:path";
import * as fs3 from "node:fs";

// ../../soloptilink-tenant-dna/lib/storage.ts
import * as fs from "node:fs";
import * as path from "node:path";
import * as os from "node:os";
import * as crypto from "node:crypto";
var STORAGE_ROOT = process.env.SOLOPTILINK_TENANT_DNA_ROOT || path.join(os.homedir(), ".soloptilink", "learning", "tenants");
function ensureStorageRoot(root = STORAGE_ROOT) {
  if (!fs.existsSync(root)) {
    fs.mkdirSync(root, { recursive: true });
  }
}
function sierDir(sierId, root = STORAGE_ROOT) {
  return path.join(root, sierId);
}
function customerDir(sierId, tenantId, root = STORAGE_ROOT) {
  return path.join(sierDir(sierId, root), "customers", sanitizeId(tenantId));
}
function projectDir(sierId, tenantId, projectId, root = STORAGE_ROOT) {
  return path.join(customerDir(sierId, tenantId, root), "projects", sanitizeId(projectId));
}
function sanitizeId(id) {
  return id.replace(/[^a-zA-Z0-9_-]/g, "-").replace(/-+/g, "-").replace(/^-|-$/g, "").toLowerCase();
}
function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}
function readSierProfile(sierId, root = STORAGE_ROOT) {
  const file = path.join(sierDir(sierId, root), "_profile.json");
  if (!fs.existsSync(file)) return null;
  try {
    return JSON.parse(fs.readFileSync(file, "utf-8"));
  } catch {
    return null;
  }
}
function writeSierProfile(profile, root = STORAGE_ROOT) {
  const dir = sierDir(profile.sier_id, root);
  ensureDir(dir);
  const file = path.join(dir, "_profile.json");
  fs.writeFileSync(file, JSON.stringify(profile, null, 2), "utf-8");
}
function readCustomerProfile(sierId, tenantId, root = STORAGE_ROOT) {
  const file = path.join(customerDir(sierId, tenantId, root), "_profile.json");
  if (!fs.existsSync(file)) return null;
  try {
    return JSON.parse(fs.readFileSync(file, "utf-8"));
  } catch {
    return null;
  }
}
function writeCustomerProfile(profile, root = STORAGE_ROOT) {
  const dir = customerDir(profile.sier_id, profile.tenant_id, root);
  ensureDir(dir);
  const file = path.join(dir, "_profile.json");
  fs.writeFileSync(file, JSON.stringify(profile, null, 2), "utf-8");
}
function readProjectProfile(sierId, tenantId, projectId, root = STORAGE_ROOT) {
  const file = path.join(projectDir(sierId, tenantId, projectId, root), "_project.json");
  if (!fs.existsSync(file)) return null;
  try {
    return JSON.parse(fs.readFileSync(file, "utf-8"));
  } catch {
    return null;
  }
}
function readDecisionsForCustomer(sierId, tenantId, root = STORAGE_ROOT) {
  const file = path.join(customerDir(sierId, tenantId, root), "decisions.jsonl");
  return readJsonl(file);
}
function readNamingRules(sierId, tenantId, root = STORAGE_ROOT) {
  const file = path.join(customerDir(sierId, tenantId, root), "naming.json");
  if (!fs.existsSync(file)) return [];
  try {
    const parsed = JSON.parse(fs.readFileSync(file, "utf-8"));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
function writeNamingRules(sierId, tenantId, rules, root = STORAGE_ROOT) {
  const dir = customerDir(sierId, tenantId, root);
  ensureDir(dir);
  fs.writeFileSync(path.join(dir, "naming.json"), JSON.stringify(rules, null, 2), "utf-8");
}
function readBlacklist(sierId, tenantId, root = STORAGE_ROOT) {
  const file = path.join(customerDir(sierId, tenantId, root), "library_blacklist.json");
  if (!fs.existsSync(file)) return [];
  try {
    const parsed = JSON.parse(fs.readFileSync(file, "utf-8"));
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}
function writeBlacklist(sierId, tenantId, entries, root = STORAGE_ROOT) {
  const dir = customerDir(sierId, tenantId, root);
  ensureDir(dir);
  fs.writeFileSync(
    path.join(dir, "library_blacklist.json"),
    JSON.stringify(entries, null, 2),
    "utf-8"
  );
}
function readPatterns(scope, scopeId, root = STORAGE_ROOT) {
  const file = scope === "global" ? path.join(root, "_global_patterns.jsonl") : path.join(sierDir(scopeId, root), "_patterns.jsonl");
  return readJsonl(file);
}
function readJsonl(file) {
  if (!fs.existsSync(file)) return [];
  const text = fs.readFileSync(file, "utf-8");
  if (!text.trim()) return [];
  const result = [];
  for (const line of text.split("\n")) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    try {
      result.push(JSON.parse(trimmed));
    } catch {
    }
  }
  return result;
}
function generateId(prefix) {
  return `${prefix}-${Date.now().toString(36)}-${crypto.randomBytes(3).toString("hex")}`;
}

// ../../soloptilink-tenant-dna/lib/tenant_profile.ts
var BUILTIN_TIMESTAMP = "2024-01-01T00:00:00.000Z";
function makeBuiltin(sierId, display, displayJa, naming, preferred_libraries, banned_libraries, preferred_architecture, preferred_deployment, notes_ja) {
  return {
    sier_id: sierId,
    display_name: display,
    display_name_ja: displayJa,
    default_naming: naming,
    preferred_libraries,
    banned_libraries,
    preferred_architecture,
    preferred_deployment,
    notes_ja,
    meta: {
      is_builtin: true,
      created_at: BUILTIN_TIMESTAMP,
      last_updated: BUILTIN_TIMESTAMP,
      project_count: 0
    }
  };
}
var BUILTIN_PROFILES = {
  nttdata: makeBuiltin(
    "nttdata",
    "NTT DATA",
    "NTT\u30C7\u30FC\u30BF",
    {
      db_table: "snake_case",
      db_column: "snake_case",
      typescript_var: "camelCase",
      api_path: "kebab-case",
      table_prefix: "T_",
      master_table_prefix: "M_"
    },
    ["Spring Boot", "Spring Framework", "Java EE", "Oracle DB", "PostgreSQL", "JUnit", "Mockito"],
    ["\u672A\u691C\u8A3COSS\u5168\u822C", "EOL\u6E08\u307F\u30E9\u30A4\u30D6\u30E9\u30EA"],
    ["3\u5C64\u30A2\u30FC\u30AD\u30C6\u30AF\u30C1\u30E3", "\u30DE\u30A4\u30AF\u30ED\u30B5\u30FC\u30D3\u30B9", "Hexagonal"],
    ["\u30AA\u30F3\u30D7\u30EC\u30DF\u30B9", "\u30D7\u30E9\u30A4\u30D9\u30FC\u30C8\u30AF\u30E9\u30A6\u30C9", "OpenShift"],
    "NTT\u30C7\u30FC\u30BF\u5F0F: snake_case (DB)\u30FBcamelCase (TS)\u30FB\u63A5\u982D\u8F9E T_/M_\u3002Spring Boot\u4E3B\u6D41\u3001\u30AA\u30F3\u30D7\u30EC+\u30D7\u30E9\u30A4\u30D9\u30FC\u30C8\u30AF\u30E9\u30A6\u30C9\u4E2D\u5FC3\u3002"
  ),
  fujitsu: makeBuiltin(
    "fujitsu",
    "Fujitsu",
    "\u5BCC\u58EB\u901A",
    {
      db_table: "snake_case",
      db_column: "UPPER_SNAKE",
      typescript_var: "camelCase",
      api_path: "kebab-case",
      table_prefix: "tbl_"
    },
    ["INTERSTAGE", "Apworks", "Symfoware", "Java EE", "Spring Framework"],
    ["\u975E\u30B5\u30DD\u30FC\u30C8OSS", "\u30E9\u30A4\u30BB\u30F3\u30B9\u4E0D\u660E\u30E9\u30A4\u30D6\u30E9\u30EA"],
    ["SOA", "3\u5C64\u30A2\u30FC\u30AD\u30C6\u30AF\u30C1\u30E3", "\u30B3\u30F3\u30DD\u30FC\u30CD\u30F3\u30C8\u6307\u5411"],
    ["FUJITSU Cloud Service", "\u30D7\u30E9\u30A4\u30D9\u30FC\u30C8\u30AF\u30E9\u30A6\u30C9", "\u30AA\u30F3\u30D7\u30EC\u30DF\u30B9"],
    "\u5BCC\u58EB\u901A\u5F0F: snake_case + UPPER\u7565\u79F0\u3001tbl_\u63A5\u982D\u8F9E\u3002INTERSTAGE/Apworks\u3002FUJITSU Cloud\u4E3B\u4F53\u3002"
  ),
  nri: makeBuiltin(
    "nri",
    "NRI (Nomura Research Institute)",
    "\u91CE\u6751\u7DCF\u5408\u7814\u7A76\u6240",
    {
      db_table: "UPPER_SNAKE",
      db_column: "UPPER_SNAKE",
      typescript_var: "camelCase",
      api_path: "kebab-case",
      table_prefix: "TBL_"
    },
    ["THE STAR", "Java EE", "Spring Framework", "Oracle DB", "JBoss EAP"],
    ["\u30B3\u30DF\u30E5\u30CB\u30C6\u30A3\u7248\u306E\u307F\u306EOSS", "\u672A\u8A8D\u5B9A\u30E9\u30A4\u30D6\u30E9\u30EA"],
    ["THE STAR\u6E96\u62E0\u30A2\u30FC\u30AD\u30C6\u30AF\u30C1\u30E3", "3\u5C64\u30A2\u30FC\u30AD\u30C6\u30AF\u30C1\u30E3"],
    ["\u81EA\u793E\u30C7\u30FC\u30BF\u30BB\u30F3\u30BF\u30FC", "\u91D1\u878D\u7279\u5316\u30D7\u30E9\u30A4\u30D9\u30FC\u30C8\u30AF\u30E9\u30A6\u30C9"],
    "NRI\u5F0F: UpperCamelCase (Java)\u30FBTBL_\u63A5\u982D\u8F9E\u3002THE STAR \u30D5\u30EC\u30FC\u30E0\u30EF\u30FC\u30AF\u3002\u81EA\u793EDC\u4E2D\u5FC3\u3001\u91D1\u878D\u6A19\u6E96\u3002"
  ),
  nomura: makeBuiltin(
    "nomura",
    "Nomura Securities IT",
    "\u91CE\u6751\u8B49\u5238IT",
    {
      db_table: "UPPER_SNAKE",
      db_column: "UPPER_SNAKE",
      typescript_var: "camelCase",
      api_path: "kebab-case",
      table_prefix: "TBL_"
    },
    ["THE STAR", "Java EE", "Spring Framework", "Oracle DB", "kdb+"],
    ["\u30B3\u30DF\u30E5\u30CB\u30C6\u30A3\u7248\u306E\u307F\u306EOSS", "\u76E3\u67FB\u672A\u901A\u904E\u30E9\u30A4\u30D6\u30E9\u30EA"],
    ["THE STAR\u6E96\u62E0\u30A2\u30FC\u30AD\u30C6\u30AF\u30C1\u30E3", "CEP", "\u30DE\u30A4\u30AF\u30ED\u30B5\u30FC\u30D3\u30B9"],
    ["\u81EA\u793E\u30C7\u30FC\u30BF\u30BB\u30F3\u30BF\u30FC", "\u91D1\u878D\u7279\u5316\u30D7\u30E9\u30A4\u30D9\u30FC\u30C8\u30AF\u30E9\u30A6\u30C9"],
    "\u91CE\u6751\u8B49\u5238IT\u5F0F: NRI\u4E92\u63DB\u898F\u7D04\u3002\u91D1\u878D\u8A3C\u5238\u7279\u5316\u3001\u4F4E\u30EC\u30A4\u30C6\u30F3\u30B7\u8981\u4EF6\u3002\u81EA\u793EDC\u904B\u7528\u3002"
  ),
  nec: makeBuiltin(
    "nec",
    "NEC",
    "NEC",
    {
      db_table: "snake_case",
      db_column: "snake_case",
      typescript_var: "camelCase",
      api_path: "kebab-case",
      table_prefix: "tbl_"
    },
    ["NEC\u5171\u901A\u30D5\u30EC\u30FC\u30E0\u30EF\u30FC\u30AF", "WebSAM", "SystemDirector", "Spring Framework", "PostgreSQL"],
    ["\u672A\u8A8D\u5B9AOSS", "\u30BB\u30AD\u30E5\u30EA\u30C6\u30A3\u975E\u8A8D\u8A3C\u30E9\u30A4\u30D6\u30E9\u30EA"],
    ["SystemDirector\u6E96\u62E0", "3\u5C64\u30A2\u30FC\u30AD\u30C6\u30AF\u30C1\u30E3"],
    ["NEC Cloud IaaS", "\u81EA\u6CBB\u4F53\u5C02\u7528\u30AF\u30E9\u30A6\u30C9", "\u30AA\u30F3\u30D7\u30EC\u30DF\u30B9"],
    "NEC\u5F0F: NEC\u5171\u901A\u30D5\u30EC\u30FC\u30E0\u30EF\u30FC\u30AF\u57FA\u6E96\u3001WebSAM/SystemDirector\u4E2D\u5FC3\u3002NEC Cloud IaaS\u3001\u81EA\u6CBB\u4F53\u7CFB\u5F37\u307F\u3002"
  ),
  hitachi: makeBuiltin(
    "hitachi",
    "Hitachi",
    "\u65E5\u7ACB\u88FD\u4F5C\u6240",
    {
      db_table: "snake_case",
      db_column: "snake_case",
      typescript_var: "camelCase",
      api_path: "kebab-case",
      table_prefix: "tbl_"
    },
    ["\u65E5\u7ACB\u5171\u901A\u57FA\u76E4", "Cosminexus", "JP1", "HiRDB", "Spring Framework"],
    ["\u30E9\u30A4\u30D5\u30B5\u30A4\u30AF\u30EB\u5207\u308COSS", "\u672A\u8A8D\u8A3C\u30E9\u30A4\u30D6\u30E9\u30EA"],
    ["\u65E5\u7ACB\u5171\u901A\u57FA\u76E4\u6E96\u62E0", "SOA", "3\u5C64\u30A2\u30FC\u30AD\u30C6\u30AF\u30C1\u30E3"],
    ["Hitachi Cloud", "\u516C\u5171\u7CFB\u30D7\u30E9\u30A4\u30D9\u30FC\u30C8\u30AF\u30E9\u30A6\u30C9", "\u30AA\u30F3\u30D7\u30EC\u30DF\u30B9"],
    "\u65E5\u7ACB\u5F0F: \u65E5\u7ACB\u5171\u901A\u57FA\u76E4\u3001Cosminexus/JP1\u3002Hitachi Cloud\u3002\u516C\u5171\u7CFB\u30FB\u793E\u4F1A\u30A4\u30F3\u30D5\u30E9\u7CFB\u5F37\u307F\u3002"
  ),
  tis: makeBuiltin(
    "tis",
    "TIS",
    "TIS",
    {
      db_table: "snake_case",
      db_column: "snake_case",
      typescript_var: "camelCase",
      api_path: "kebab-case",
      table_prefix: "tbl_"
    },
    ["TIDS", "Spring Framework", "Apache HTTP Server", "JDDS", "PostgreSQL", "Oracle DB"],
    ["EOL OSS", "\u5546\u7528\u30E9\u30A4\u30BB\u30F3\u30B9\u672A\u8A31\u8AFE\u30E9\u30A4\u30D6\u30E9\u30EA"],
    ["TIDS\u6E96\u62E0", "\u30DE\u30A4\u30AF\u30ED\u30B5\u30FC\u30D3\u30B9", "3\u5C64\u30A2\u30FC\u30AD\u30C6\u30AF\u30C1\u30E3"],
    ["TIS\u30D7\u30E9\u30A4\u30D9\u30FC\u30C8\u30AF\u30E9\u30A6\u30C9", "AWS", "\u30AA\u30F3\u30D7\u30EC\u30DF\u30B9"],
    "TIS\u5F0F: TIDS \u30D5\u30EC\u30FC\u30E0\u30EF\u30FC\u30AF\u3002Spring + Apache + JDDS\u3002\u30D7\u30E9\u30A4\u30D9\u30FC\u30C8\u30AF\u30E9\u30A6\u30C9\u4E3B\u4F53\u3001\u91D1\u878DB2B\u5F37\u307F\u3002"
  ),
  generic: makeBuiltin(
    "generic",
    "Generic",
    "\u6C4E\u7528",
    {
      db_table: "snake_case",
      db_column: "snake_case",
      typescript_var: "camelCase",
      api_path: "kebab-case"
    },
    [],
    [],
    [],
    [],
    "\u6C4E\u7528: \u6848\u4EF6\u3054\u3068\u306B\u81EA\u7531\u306B\u6C7A\u5B9A\u3002\u56FA\u5B9A\u306E\u898F\u7D04\u306A\u3057\u3001\u30D7\u30ED\u30B8\u30A7\u30AF\u30C8\u5358\u4F4D\u3067\u547D\u540D\u898F\u5247\u3092\u5B9A\u7FA9\u3059\u308B\u3002"
  )
};
function registerSier(input, root = STORAGE_ROOT) {
  ensureStorageRoot(root);
  const existing = readSierProfile(input.sier_id, root);
  const base = existing ?? cloneBuiltin(input.sier_id);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const merged = {
    sier_id: input.sier_id,
    display_name: input.display_name ?? base.display_name,
    display_name_ja: input.display_name_ja ?? base.display_name_ja,
    default_naming: {
      ...base.default_naming,
      ...input.default_naming ?? {}
    },
    preferred_libraries: input.preferred_libraries ?? base.preferred_libraries,
    banned_libraries: input.banned_libraries ?? base.banned_libraries,
    preferred_architecture: input.preferred_architecture ?? base.preferred_architecture,
    preferred_deployment: input.preferred_deployment ?? base.preferred_deployment,
    notes_ja: input.notes_ja ?? base.notes_ja,
    meta: {
      is_builtin: existing ? base.meta.is_builtin : false,
      created_at: existing ? base.meta.created_at : now,
      last_updated: now,
      project_count: base.meta.project_count
    }
  };
  writeSierProfile(merged, root);
  return merged;
}
function getSier(sierId, root = STORAGE_ROOT) {
  const existing = readSierProfile(sierId, root);
  if (existing) return existing;
  if (!(sierId in BUILTIN_PROFILES)) return null;
  const seeded = cloneBuiltin(sierId);
  writeSierProfile(seeded, root);
  return seeded;
}
function registerCustomer(input, root = STORAGE_ROOT) {
  getSier(input.sier_id, root);
  const existing = readCustomerProfile(input.sier_id, input.tenant_id, root);
  const now = (/* @__PURE__ */ new Date()).toISOString();
  const next = existing ? {
    ...existing,
    display_name: input.display_name ?? existing.display_name,
    display_name_ja: input.display_name_ja ?? existing.display_name_ja,
    domain: input.domain ?? existing.domain,
    industry: input.industry ?? existing.industry,
    industry_ja: input.industry_ja ?? existing.industry_ja,
    size: input.size ?? existing.size,
    contact_info: { ...existing.contact_info, ...input.contact_info ?? {} },
    meta: {
      ...existing.meta,
      last_updated: now,
      interaction_count: existing.meta.interaction_count + 1
    }
  } : {
    tenant_id: input.tenant_id,
    sier_id: input.sier_id,
    display_name: input.display_name,
    display_name_ja: input.display_name_ja,
    domain: input.domain,
    industry: input.industry,
    industry_ja: input.industry_ja,
    size: input.size,
    active_projects: [],
    archived_projects: [],
    contact_info: input.contact_info ?? {},
    meta: {
      created_at: now,
      last_updated: now,
      interaction_count: 1
    }
  };
  writeCustomerProfile(next, root);
  return next;
}
function getCustomer(sierId, tenantId, root = STORAGE_ROOT) {
  return readCustomerProfile(sierId, tenantId, root);
}
function getProject(sierId, tenantId, projectId, root = STORAGE_ROOT) {
  return readProjectProfile(sierId, tenantId, projectId, root);
}
function cloneBuiltin(sierId) {
  const src = BUILTIN_PROFILES[sierId];
  if (!src) {
    throw new Error(`Unknown builtin SIer: ${sierId}`);
  }
  return JSON.parse(JSON.stringify(src));
}

// ../../soloptilink-tenant-dna/lib/naming_convention.ts
var SIER_DEFAULT_TENANT = "__sier_default__";
function defineNamingRule(input, root = STORAGE_ROOT) {
  const rule = {
    tenant_id: input.tenant_id,
    rule_id: generateId("naming"),
    scope: input.scope,
    case_style: input.case_style,
    prefix: input.prefix,
    suffix: input.suffix,
    forbidden_patterns: input.forbidden_patterns,
    example_good: input.example_good,
    example_bad: input.example_bad,
    rationale: input.rationale,
    enforced: input.enforced ?? true,
    source_decision_id: input.source_decision_id
  };
  if (input.tenant_id === SIER_DEFAULT_TENANT) {
    return rule;
  }
  const existing = readNamingRules(input.sier_id, input.tenant_id, root);
  const filtered = existing.filter(
    (r) => !(r.scope === rule.scope && r.case_style === rule.case_style && r.prefix === rule.prefix && r.suffix === rule.suffix)
  );
  writeNamingRules(input.sier_id, input.tenant_id, [...filtered, rule], root);
  return rule;
}

// ../../soloptilink-tenant-dna/lib/library_blacklist.ts
function nowIso() {
  return (/* @__PURE__ */ new Date()).toISOString();
}
function normalizeLibName(name) {
  return name.trim().toLowerCase();
}
function findEntryIndex(list, library, language) {
  const target = normalizeLibName(library);
  return list.findIndex(
    (e) => normalizeLibName(e.library_name) === target && (e.language === language || e.language === "any")
  );
}
function banLibrary(input, sier_id) {
  const tenant_id = input.tenant_id;
  const list = readBlacklist(sier_id, tenant_id);
  const entry = {
    tenant_id,
    library_name: input.library_name.trim(),
    language: input.language,
    reason: input.reason,
    alternative_recommendation: input.alternative_recommendation,
    banned_at: nowIso(),
    banned_until: input.banned_until,
    scope: input.scope,
    related_project_ids: input.related_project_ids,
    source_decision_id: input.source_decision_id
  };
  const idx = findEntryIndex(list, entry.library_name, entry.language);
  if (idx >= 0) {
    list[idx] = entry;
  } else {
    list.push(entry);
  }
  writeBlacklist(sier_id, tenant_id, list);
  return entry;
}

// ../../soloptilink-tenant-dna/lib/sier_template.ts
function namingRule(scope, case_style, rationale, options = {}) {
  return {
    tenant_id: "__sier_default__",
    rule_id: `${scope}-${case_style}`,
    scope,
    case_style,
    rationale,
    enforced: true,
    ...options
  };
}
var NTTDATA_TEMPLATE = {
  sier_id: "nttdata",
  display_name: "NTT DATA",
  display_name_ja: "NTT\u30C7\u30FC\u30BF",
  architecture: {
    name: "TERASOLUNA 5\u5C64 + \u30D0\u30C3\u30C1 + EAI",
    description: "NTT\u30C7\u30FC\u30BF\u304C OSS \u3067\u516C\u958B\u3059\u308B Spring \u30D9\u30FC\u30B9\u306E\u4F01\u696D\u5411\u3051 5 \u5C64\u30E2\u30C7\u30EB\u3002Web / Domain / Infrastructure \u3092\u53B3\u683C\u306B\u5206\u96E2\u3057\u3001\u30D0\u30C3\u30C1\u5C64\u306F TERASOLUNA Batch 5.x \u3092\u63A1\u7528\u3002EAI \u306F HULFT/Magic/\u72EC\u81EA\u88FD\u54C1\u3067\u9023\u643A\u3002",
    layers: [
      "Presentation (Spring MVC + Thymeleaf or React)",
      "Application Service",
      "Domain (Entity + DomainService)",
      "Infrastructure (Repository + RestClient)",
      "Common (Constants/Exception/MessageSource)",
      "Batch (TERASOLUNA Batch 5.x)",
      "EAI (HULFT / Magic xpi)"
    ],
    mandatory_components: [
      "Spring Framework 6.x",
      "TERASOLUNA Server Framework for Java 5.x",
      "MyBatis 3.x",
      "JSR-303 Bean Validation",
      "SLF4J + Logback",
      "JUnit 5 + Mockito",
      "JaCoCo (\u30AB\u30D0\u30EC\u30C3\u30B8)",
      "\u793E\u5185 Sonar (\u30B3\u30FC\u30C9\u54C1\u8CEA)"
    ],
    forbidden_components: [
      "Spring Boot (\u5358\u72EC\u63A1\u7528)",
      "Hibernate (TERASOLUNA \u6A19\u6E96\u306F MyBatis)",
      "Lombok (\u793E\u5185\u9759\u7684\u89E3\u6790\u3068\u76F8\u6027\u4E0D\u53EF)"
    ]
  },
  naming_rules: [
    namingRule("db_table", "UPPER_SNAKE", "NTT\u30C7\u30FC\u30BF\u6A19\u6E96: \u5927\u6587\u5B57\u30B9\u30CD\u30FC\u30AF\u3001\u696D\u52D9\u7565\u53F73\u6587\u5B57\u3092 prefix \u306B\u6301\u305F\u305B\u308B", {
      prefix: "M_/T_/H_",
      example_good: ["M_USER", "T_ORDER", "H_AUDIT_LOG"],
      example_bad: ["user", "orders"]
    }),
    namingRule("db_column", "snake_case", "\u5C0F\u6587\u5B57\u30B9\u30CD\u30FC\u30AF\u3002\u65E5\u4ED8\u5217\u306F _DT\u3001\u30D5\u30E9\u30B0\u306F _FLG suffix"),
    namingRule("typescript_var", "camelCase", "JS/TS \u6A19\u6E96"),
    namingRule("typescript_type", "PascalCase", "\u578B\u30FB\u30AF\u30E9\u30B9\u306F Pascal"),
    namingRule("api_path", "kebab-case", "REST API \u30D1\u30B9\u306F kebab\u3002/api/v1/order-items \u306A\u3069", {
      example_good: ["/api/v1/order-items"],
      example_bad: ["/api/v1/orderItems"]
    }),
    namingRule("component", "PascalCase", "React \u30B3\u30F3\u30DD\u30FC\u30CD\u30F3\u30C8\u306F Pascal"),
    namingRule("file", "PascalCase", "Java \u30AF\u30E9\u30B9\u30D5\u30A1\u30A4\u30EB\u306F PascalCase.java"),
    namingRule("route", "kebab-case", "Next.js \u30EB\u30FC\u30C8/Spring URL \u306F kebab")
  ],
  preferred_libraries: [
    {
      language: "java",
      libraries: [
        { name: "spring-framework", version_range: "6.x", reason: "TERASOLUNA 5 \u7CFB\u306E\u524D\u63D0" },
        { name: "terasoluna-gfw-common", version_range: "5.7.x", reason: "NTT\u30C7\u30FC\u30BF\u6A19\u6E96\u30D5\u30EC\u30FC\u30E0\u30EF\u30FC\u30AF" },
        { name: "mybatis", version_range: "3.5.x", reason: "TERASOLUNA \u6A19\u6E96 ORM" },
        { name: "spring-batch", version_range: "5.x", reason: "TERASOLUNA Batch \u30D9\u30FC\u30B9" },
        { name: "logback-classic", version_range: "1.4.x", reason: "SLF4J \u6A19\u6E96 binding" },
        { name: "junit-jupiter", version_range: "5.x", reason: "\u6A19\u6E96\u30C6\u30B9\u30C8\u30D5\u30EC\u30FC\u30E0\u30EF\u30FC\u30AF" },
        { name: "mockito-core", version_range: "5.x", reason: "\u30E2\u30C3\u30AF\u6A19\u6E96" }
      ]
    },
    {
      language: "typescript",
      libraries: [
        { name: "react", version_range: "18.x", reason: "BFF \u7528\u30D5\u30ED\u30F3\u30C8\u6A19\u6E96" },
        { name: "next", version_range: "14.x", reason: "\u793E\u5185\u627F\u8A8D\u6E08 Next.js" },
        { name: "axios", version_range: "1.x", reason: "\u793E\u5185 HTTP \u30AF\u30E9\u30A4\u30A2\u30F3\u30C8\u6A19\u6E96" },
        { name: "zod", version_range: "3.x", reason: "\u30B9\u30AD\u30FC\u30DE\u691C\u8A3C (TS \u5074)" },
        { name: "vitest", version_range: "1.x", reason: "TS \u30C6\u30B9\u30C8\u6A19\u6E96" }
      ]
    },
    {
      language: "python",
      libraries: [
        { name: "fastapi", version_range: "0.110.x", reason: "\u793E\u5185 PoC \u7528 API \u30D5\u30EC\u30FC\u30E0\u30EF\u30FC\u30AF" },
        { name: "pydantic", version_range: "2.x", reason: "\u30D0\u30EA\u30C7\u30FC\u30B7\u30E7\u30F3\u6A19\u6E96" }
      ]
    }
  ],
  banned_libraries: [
    {
      language: "java",
      libraries: [
        { name: "spring-boot-starter-parent", reason: "TERASOLUNA \u6A19\u6E96\u306F Spring Framework \u5358\u4F53\u69CB\u6210\u306E\u305F\u3081" },
        { name: "lombok", reason: "\u793E\u5185 Sonar \u306E\u8B66\u544A\u6291\u6B62\u304C\u56F0\u96E3" },
        { name: "hibernate-orm", reason: "TERASOLUNA \u6A19\u6E96\u306F MyBatis" }
      ]
    },
    {
      language: "javascript",
      libraries: [
        { name: "mongoose", reason: "\u672C\u90E8\u6A19\u6E96\u306F RDB (PostgreSQL/Oracle)" },
        { name: "next-auth", reason: "\u793E\u5185 CIAM SDK \u3068\u7D71\u5408\u3067\u304D\u306A\u3044\u305F\u3081\u4E0D\u53EF" }
      ]
    }
  ],
  deployment_targets: [
    "NTT\u30C7\u30FC\u30BF\u793E\u5185\u30AF\u30E9\u30A6\u30C9 OpenCanvas",
    "AWS (NTT\u30C7\u30FC\u30BF DTC \u30A2\u30AB\u30A6\u30F3\u30C8)",
    "Azure (NTT\u30C7\u30FC\u30BF Microsoft \u30A2\u30E9\u30A4\u30A2\u30F3\u30B9)",
    "\u30AA\u30F3\u30D7\u30EC\u30DF\u30B9 (Red Hat Enterprise Linux 9)",
    "\u30D7\u30E9\u30A4\u30D9\u30FC\u30C8\u30AF\u30E9\u30A6\u30C9 (VMware vSphere)"
  ],
  documentation_template: {
    sections: [
      {
        title: "1. \u30B7\u30B9\u30C6\u30E0\u6982\u8981",
        outline: "\u5BFE\u8C61\u696D\u52D9\u30FB\u95A2\u4FC2\u8005\u30FB\u5168\u4F53\u69CB\u6210\u56F3 (Visio)\u30FB\u4E3B\u8981 KPI \u3092\u8A18\u8F09\u3002\u793E\u5185\u30AC\u30A4\u30C9\u30E9\u30A4\u30F3 v3 \u6E96\u62E0\u3002"
      },
      { title: "2. \u6A5F\u80FD\u8981\u4EF6", outline: "BR/FR/QR/CR \u306E\u968E\u5C64\u3067 WBS \u3068\u5BFE\u5FDC\u4ED8\u3051\u3001\u8981\u4EF6 ID \u3092\u63A1\u756A\u3002" },
      { title: "3. \u975E\u6A5F\u80FD\u8981\u4EF6", outline: "IPA \u975E\u6A5F\u80FD\u8981\u6C42\u30B0\u30EC\u30FC\u30C9\u306B\u6CBF\u3063\u3066 6 \u5927\u9805\u76EE \xD7 100 \u6307\u6A19\u3092\u57CB\u3081\u308B\u3002" },
      { title: "4. \u30A2\u30FC\u30AD\u30C6\u30AF\u30C1\u30E3", outline: "TERASOLUNA 5 \u5C64\u30E2\u30C7\u30EB\u56F3\u30FB\u30B3\u30F3\u30DD\u30FC\u30CD\u30F3\u30C8\u56F3\u30FB\u914D\u7F6E\u56F3 (UML)\u3002" },
      { title: "5. \u753B\u9762\u8A2D\u8A08", outline: "\u753B\u9762\u4E00\u89A7 + \u753B\u9762\u9077\u79FB\u56F3 + \u753B\u9762\u9805\u76EE\u5B9A\u7FA9\u66F8 (Excel \u30C6\u30F3\u30D7\u30EC)\u3002" },
      { title: "6. \u30C7\u30FC\u30BF\u30D9\u30FC\u30B9\u8A2D\u8A08", outline: "ERD\u30FB\u30C6\u30FC\u30D6\u30EB\u5B9A\u7FA9\u66F8\u30FBCRUD \u56F3 (\u793E\u5185 Excel \u30D5\u30A9\u30FC\u30DE\u30C3\u30C8)\u3002" },
      { title: "7. API/\u30D0\u30C3\u30C1\u8A2D\u8A08", outline: "REST API \u4E00\u89A7 + IF \u4ED5\u69D8\u66F8 + \u30D0\u30C3\u30C1\u5B9A\u7FA9\u66F8 (TERASOLUNA Batch)\u3002" },
      { title: "8. \u8A66\u9A13\u8A08\u753B/\u7D50\u679C", outline: "\u5358\u4F53\u30FB\u7D50\u5408\u30FB\u7DCF\u5408\u30FB\u53D7\u5165\u306E 4 \u968E\u5C64\u3001JaCoCo 80% \u5FC5\u9808\u3002" },
      { title: "9. \u904B\u7528\u8A2D\u8A08", outline: "\u904B\u7528\u624B\u9806\u66F8\u30FB\u969C\u5BB3\u5BFE\u5FDC Runbook\u30FB\u76E3\u8996\u8A2D\u8A08 (Hinemos/JP1)\u3002" },
      { title: "10. \u30BB\u30AD\u30E5\u30EA\u30C6\u30A3\u8A2D\u8A08", outline: "IPA \u5B89\u5168\u306A Web \u30A2\u30D7\u30EA\u306E\u4F5C\u308A\u65B9\u30FBOWASP ASVS Level 2 \u4EE5\u4E0A\u3002" }
    ]
  },
  code_review_checklist: [
    "TERASOLUNA 5 \u5C64\u69CB\u9020\u3092\u9038\u8131\u3057\u3066\u3044\u306A\u3044\u304B (DomainService \u304C\u76F4\u63A5 SQL \u3092\u767A\u884C\u3057\u3066\u3044\u306A\u3044\u304B)",
    "MyBatis Mapper \u306E SQL \u306B\u52D5\u7684\u30D0\u30A4\u30F3\u30C7\u30A3\u30F3\u30B0\u4EE5\u5916\u3067\u5916\u90E8\u5165\u529B\u304C\u6DF7\u5165\u3057\u3066\u3044\u306A\u3044\u304B",
    "JSR-303 \u30A2\u30CE\u30C6\u30FC\u30B7\u30E7\u30F3\u304C\u5168 Form \u306B\u4ED8\u4E0E\u3055\u308C\u3066\u3044\u308B\u304B",
    "Logback \u306E MDC \u3067 traceId/userId \u304C\u51FA\u529B\u3055\u308C\u3066\u3044\u308B\u304B",
    "\u30B3\u30DF\u30C3\u30C8\u7C92\u5EA6\u304C WBS \u5358\u4F4D\u304B\u3064\u793E\u5185\u30B3\u30DF\u30C3\u30C8\u30E1\u30C3\u30BB\u30FC\u30B8\u898F\u7D04\u306B\u6E96\u62E0\u3057\u3066\u3044\u308B\u304B",
    "JaCoCo \u306E line coverage \u304C 80% \u3092\u4E0B\u56DE\u3063\u3066\u3044\u306A\u3044\u304B",
    "SonarQube Critical/Blocker 0 \u4EF6\u304B",
    "\u30D1\u30B9\u30EF\u30FC\u30C9/\u79D8\u5BC6\u9375\u304C PR \u4E0A\u306B\u9732\u51FA\u3057\u3066\u3044\u306A\u3044\u304B (\u793E\u5185 Talisman \u5FC5\u9808)",
    "\u753B\u9762\u9805\u76EE\u306B\u5BFE\u3059\u308B Form/Validation \u306E\u5BFE\u5FDC\u6F0F\u308C\u304C\u7121\u3044\u304B",
    "\u30D0\u30C3\u30C1\u306E\u518D\u5B9F\u884C\u6027 (\u30EA\u30B9\u30BF\u30FC\u30C8\u8D77\u70B9\u8A2D\u5B9A) \u304C\u5B9A\u7FA9\u3055\u308C\u3066\u3044\u308B\u304B",
    "Web \u753B\u9762\u3067 CSRF/XSS \u5BFE\u7B56\u304C TERASOLUNA \u65E2\u5B9A\u901A\u308A\u306B\u6709\u52B9\u5316\u3055\u308C\u3066\u3044\u308B\u304B",
    "\u30ED\u30B0\u30DE\u30B9\u30AD\u30F3\u30B0 (\u500B\u4EBA\u60C5\u5831) \u304C\u5171\u901A\u30E2\u30B8\u30E5\u30FC\u30EB\u7D4C\u7531\u3067\u884C\u308F\u308C\u3066\u3044\u308B\u304B",
    "OSS \u30E9\u30A4\u30BB\u30F3\u30B9\u304C\u793E\u5185 OSS \u59D4\u54E1\u4F1A\u306E\u627F\u8A8D\u30EA\u30B9\u30C8\u5185\u304B"
  ],
  qa_gate: {
    coverage_min: 80,
    lighthouse_min: 80,
    security_scan: true,
    static_analysis_tool: "SonarQube + Checkmarx",
    pen_test_required: true,
    load_test_required: true,
    doc_review_required: true,
    notes: "IPA \u975E\u6A5F\u80FD\u8981\u6C42\u30B0\u30EC\u30FC\u30C9 6 \u5927\u9805\u76EE\u306E\u5408\u683C\u5224\u5B9A\u3092\u5FC5\u9808\u3068\u3059\u308B"
  }
};
var FUJITSU_TEMPLATE = {
  sier_id: "fujitsu",
  display_name: "Fujitsu",
  display_name_ja: "\u5BCC\u58EB\u901A",
  architecture: {
    name: "INTERSTAGE \u6A19\u6E96 (Java EE + Apworks)",
    description: '\u5BCC\u58EB\u901A\u306E Application Server "Interstage" \u4E0A\u306B Apworks \u958B\u767A\u30D5\u30EC\u30FC\u30E0\u30EF\u30FC\u30AF\u3092\u4E57\u305B\u308B\u69CB\u6210\u3002FNJ (Fujitsu Network Japan) \u7CFB\u3067\u306F Symfoware DB \u304C\u5B9A\u77F3\u3002\u6700\u8FD1\u306F Azure \u3078\u306E\u30EA\u30D5\u30C8\u3067\u3082\u8E0F\u8972\u3002',
    layers: [
      "Presentation (Apcoordinator / React+Spring)",
      "Business Logic (Apworks)",
      "Data Access (Apworks DB Access)",
      "Persistence (Symfoware / PostgreSQL)",
      "Common (Apworks Common)",
      "Integration (Interstage Application Framework Suite)"
    ],
    mandatory_components: [
      "Interstage Application Server V12",
      "Apworks \u958B\u767A\u30D5\u30EC\u30FC\u30E0\u30EF\u30FC\u30AF",
      "Symfoware Server / PostgreSQL",
      "Java EE 8 (Jakarta EE 10 \u79FB\u884C\u4E2D)",
      "Systemwalker \u76E3\u8996",
      "JUnit 5"
    ],
    forbidden_components: [
      "Apache Tomcat (\u5358\u72EC\u63A1\u7528)",
      "WebPack \u5358\u4F53 (\u793E\u5185\u30D3\u30EB\u30C9\u306F Vite/esbuild)",
      "Jest (\u793E\u5185\u6A19\u6E96\u306F Vitest)"
    ]
  },
  naming_rules: [
    namingRule("db_table", "UPPER_SNAKE", "\u5BCC\u58EB\u901A\u6A19\u6E96: \u5927\u6587\u5B57\u30B9\u30CD\u30FC\u30AF, \u696D\u52D9 prefix 3 \u6587\u5B57 + \u901A\u756A", {
      example_good: ["MST_USER_001", "TRN_ORDER_002"]
    }),
    namingRule("db_column", "snake_case", "\u5C0F\u6587\u5B57\u30B9\u30CD\u30FC\u30AF. \u65E5\u4ED8\u306F _date / \u6642\u523B\u306F _time"),
    namingRule("typescript_var", "camelCase", "TS \u6A19\u6E96"),
    namingRule("typescript_type", "PascalCase", "\u578B\u30FB\u30AF\u30E9\u30B9\u306F Pascal"),
    namingRule("api_path", "kebab-case", "REST \u30D1\u30B9 kebab. \u30D0\u30FC\u30B8\u30E7\u30F3\u306F /v1/"),
    namingRule("component", "PascalCase", "React \u30B3\u30F3\u30DD\u30FC\u30CD\u30F3\u30C8"),
    namingRule("file", "PascalCase", "Java \u30AF\u30E9\u30B9\u306F PascalCase")
  ],
  preferred_libraries: [
    {
      language: "java",
      libraries: [
        { name: "apworks-framework", reason: "\u5BCC\u58EB\u901A\u6A19\u6E96\u30D5\u30EC\u30FC\u30E0\u30EF\u30FC\u30AF" },
        { name: "jakarta.ee-api", version_range: "10.x", reason: "Interstage V12 \u5BFE\u5FDC" },
        { name: "logback-classic", version_range: "1.4.x", reason: "Log4j2 \u304B\u3089\u6BB5\u968E\u79FB\u884C" },
        { name: "junit-jupiter", version_range: "5.x", reason: "\u30C6\u30B9\u30C8\u6A19\u6E96" },
        { name: "mockito-core", version_range: "5.x", reason: "\u30E2\u30C3\u30AF\u6A19\u6E96" }
      ]
    },
    {
      language: "typescript",
      libraries: [
        { name: "react", version_range: "18.x", reason: "\u5BCC\u58EB\u901A\u30D5\u30ED\u30F3\u30C8\u6A19\u6E96" },
        { name: "vite", version_range: "5.x", reason: "\u793E\u5185\u30D3\u30EB\u30C9\u6A19\u6E96" },
        { name: "vitest", version_range: "1.x", reason: "\u30C6\u30B9\u30C8\u6A19\u6E96" },
        { name: "fetch-undici", reason: "Node 18+ \u6A19\u6E96 fetch" },
        { name: "zod", version_range: "3.x", reason: "\u30B9\u30AD\u30FC\u30DE\u691C\u8A3C" }
      ]
    }
  ],
  banned_libraries: [
    {
      language: "java",
      libraries: [
        { name: "log4j-core", reason: "Log4Shell \u7D4C\u7DEF\u304B\u3089\u793E\u5185\u5168\u9762\u7981\u6B62" },
        { name: "tomcat-embed-core", reason: "\u5BCC\u58EB\u901A\u6A19\u6E96 AP \u306F Interstage" },
        { name: "spring-boot", reason: "Apworks \u3068\u306E\u4E8C\u91CD\u7BA1\u7406\u306B\u306A\u308A\u7981\u6B62" }
      ]
    },
    {
      language: "javascript",
      libraries: [
        { name: "webpack", reason: "\u793E\u5185\u30D3\u30EB\u30C9\u306F Vite \u306B\u7D71\u4E00\u4E2D" },
        { name: "jest", reason: "\u793E\u5185 CI \u306F vitest \u6A19\u6E96" },
        { name: "request", reason: "deprecated \u30D1\u30C3\u30B1\u30FC\u30B8\u306E\u305F\u3081\u65B0\u898F\u63A1\u7528\u7981\u6B62" }
      ]
    }
  ],
  deployment_targets: [
    "FUJITSU Hybrid IT Service FJcloud-V (\u65E7 K5)",
    "FUJITSU Cloud Service for OSS (FOCUS)",
    "AWS Tokyo Region",
    "Azure Japan East (\u5BCC\u58EB\u901A\u30A2\u30E9\u30A4\u30A2\u30F3\u30B9)",
    "\u30AA\u30F3\u30D7\u30EC\u30DF\u30B9 (FUJITSU PRIMERGY)"
  ],
  documentation_template: {
    sections: [
      { title: "1. \u30B7\u30B9\u30C6\u30E0\u6982\u8981\u66F8", outline: "\u5BCC\u58EB\u901A\u6A19\u6E96 1\u30DA\u30FC\u30B8\u6982\u8981 + \u30B4\u30FC\u30EB + \u95A2\u4FC2\u8005\u4E00\u89A7\u3002" },
      { title: "2. \u696D\u52D9\u8981\u4EF6\u5B9A\u7FA9\u66F8", outline: "BPMN \u696D\u52D9\u30D5\u30ED\u30FC + \u696D\u52D9\u4E00\u89A7 + To-Be \u8981\u4EF6\u3002" },
      { title: "3. \u6A5F\u80FD\u8981\u4EF6\u5B9A\u7FA9\u66F8", outline: "\u6A5F\u80FD ID \u63A1\u756A + \u5165\u51FA\u529B + \u696D\u52D9\u30EB\u30FC\u30EB\u3002" },
      { title: "4. \u975E\u6A5F\u80FD\u8981\u4EF6\u5B9A\u7FA9\u66F8", outline: "IPA \u975E\u6A5F\u80FD\u8981\u6C42\u30B0\u30EC\u30FC\u30C9 + Systemwalker \u76E3\u8996\u8981\u4EF6\u3002" },
      { title: "5. \u30A2\u30FC\u30AD\u30C6\u30AF\u30C1\u30E3\u8A2D\u8A08\u66F8", outline: "Interstage + Apworks \u69CB\u6210\u56F3 + \u914D\u7F6E\u56F3\u3002" },
      { title: "6. \u753B\u9762\u8A2D\u8A08\u66F8", outline: "\u753B\u9762\u4E00\u89A7 + \u753B\u9762\u9077\u79FB + \u9805\u76EE\u5B9A\u7FA9\u66F8\u3002" },
      { title: "7. \u30C7\u30FC\u30BF\u30D9\u30FC\u30B9\u8A2D\u8A08\u66F8", outline: "ERD + \u30C6\u30FC\u30D6\u30EB\u5B9A\u7FA9 + Symfoware/PostgreSQL \u7269\u7406\u8A2D\u8A08\u3002" },
      { title: "8. \u30C6\u30B9\u30C8\u8A08\u753B\u66F8/\u6210\u7E3E\u66F8", outline: "\u5358\u4F53/\u7D50\u5408/\u7DCF\u5408/\u53D7\u5165\u3002Excel \u30C6\u30F3\u30D7\u30EC\u6E96\u62E0\u3002" },
      { title: "9. \u904B\u7528\u8A2D\u8A08\u66F8", outline: "Systemwalker \u76E3\u8996 + JP1 \u9023\u643A + \u969C\u5BB3\u5BFE\u5FDC Runbook\u3002" },
      { title: "10. \u79FB\u884C\u8A2D\u8A08\u66F8", outline: "\u30C7\u30FC\u30BF\u79FB\u884C\u30FB\u5207\u66FF\u624B\u9806\u30FB\u30EA\u30CF\u30FC\u30B5\u30EB\u8A08\u753B\u3002" }
    ]
  },
  code_review_checklist: [
    "Apworks \u306E\u5C64\u5206\u96E2\u304C\u9075\u5B88\u3055\u308C\u3066\u3044\u308B\u304B",
    "Symfoware/PostgreSQL \u306E\u6587\u5B57\u30B3\u30FC\u30C9 (UTF-8) \u304C\u4E00\u8CAB\u3057\u3066\u3044\u308B\u304B",
    "Interstage \u306E JNDI \u540D\u304C Apworks \u306E\u6A19\u6E96\u547D\u540D\u3068\u4E00\u81F4\u3057\u3066\u3044\u308B\u304B",
    "Systemwalker \u76E3\u8996\u30ED\u30B0\u51FA\u529B\u304C\u6A19\u6E96 LogFormat \u3092\u6E80\u305F\u3057\u3066\u3044\u308B\u304B",
    "JUnit 5 \u306E\u30C6\u30B9\u30C8\u547D\u540D\u304C Given_When_Then \u69CB\u9020\u306B\u306A\u3063\u3066\u3044\u308B\u304B",
    "\u500B\u4EBA\u60C5\u5831\u30DE\u30B9\u30AD\u30F3\u30B0\u304C\u5171\u901A AOP \u3067\u5B9F\u88C5\u3055\u308C\u3066\u3044\u308B\u304B",
    "OSS \u30E9\u30A4\u30BB\u30F3\u30B9\u60C5\u5831\u304C\u793E\u5185 OSS Hub \u306B\u767B\u9332\u6E08\u304B",
    "\u30B3\u30FC\u30C9\u30AB\u30D0\u30EC\u30C3\u30B8\u304C 75% \u4EE5\u4E0A\u304B",
    "\u5BCC\u58EB\u901A i-Cure (\u8106\u5F31\u6027\u30B9\u30AD\u30E3\u30F3) \u304C PR \u5358\u4F4D\u3067\u901A\u904E\u3057\u3066\u3044\u308B\u304B",
    "\u30C9\u30AD\u30E5\u30E1\u30F3\u30C8\u3068\u30B3\u30FC\u30C9\u306E WBS ID \u5BFE\u5FDC\u8868\u304C\u66F4\u65B0\u3055\u308C\u3066\u3044\u308B\u304B",
    "PR \u30BF\u30A4\u30C8\u30EB\u306B\u6848\u4EF6\u756A\u53F7 (FJ-12345) \u304C\u4ED8\u4E0E\u3055\u308C\u3066\u3044\u308B\u304B",
    "OWASP Top10 \u5BFE\u5FDC\u30C1\u30A7\u30C3\u30AF\u8868\u306B\u7F72\u540D\u304C\u3042\u308B\u304B"
  ],
  qa_gate: {
    coverage_min: 75,
    lighthouse_min: 80,
    security_scan: true,
    static_analysis_tool: "Fujitsu i-Cure + SonarQube",
    pen_test_required: true,
    load_test_required: true,
    doc_review_required: true,
    notes: "Systemwalker \u76E3\u8996\u30C6\u30F3\u30D7\u30EC\u304C\u5FC5\u9808\u3002\u7D0D\u54C1\u7269 = ZIP + Word \u4E00\u5F0F"
  }
};
var NRI_TEMPLATE = {
  sier_id: "nri",
  display_name: "NRI",
  display_name_ja: "\u91CE\u6751\u7DCF\u5408\u7814\u7A76\u6240",
  architecture: {
    name: "THE STAR / aslead \u958B\u767A\u6A19\u6E96",
    description: 'NRI \u306E\u72EC\u81EA\u30D5\u30EC\u30FC\u30E0\u30EF\u30FC\u30AF "THE STAR" \u3068 DevOps \u74B0\u5883 "aslead" \u3092\u7D44\u307F\u5408\u308F\u305B\u308B\u3002\u91D1\u878D\u696D\u754C\u5411\u3051\u306F BizForge / FENICS \u304C\u5B9A\u77F3\u3002\u76E3\u67FB\u8981\u4EF6 (FISC \u5B89\u5BFE) \u3092\u6E80\u305F\u3059\u591A\u5C64\u69CB\u9020\u3002',
    layers: [
      "Channel (Web/App/Batch)",
      "Service (Java + STAR Service Layer)",
      "Domain (DDD \u30D9\u30FC\u30B9 Aggregate)",
      "Repository (JPA + STAR DAO)",
      "Common Infrastructure (aslead OSS \u30B9\u30BF\u30C3\u30AF)",
      "Audit (FISC \u76E3\u67FB\u30ED\u30B0)"
    ],
    mandatory_components: [
      "aslead DevOps \u30B9\u30A4\u30FC\u30C8",
      "THE STAR Application Framework",
      "Spring Framework 6 + Spring Security",
      "Oracle Database 19c / PostgreSQL 15",
      "JUnit 5 + Cucumber",
      "JFrog Artifactory"
    ],
    forbidden_components: [
      "MongoDB (\u91D1\u878D\u7CFB)",
      "GraphQL (\u91D1\u878D\u7CFB)",
      "Edge Functions (\u56FD\u5916\u8D8A\u5883)"
    ]
  },
  naming_rules: [
    namingRule("db_table", "UPPER_SNAKE", "NRI \u91D1\u878D\u6A19\u6E96: \u5927\u6587\u5B57\u30B9\u30CD\u30FC\u30AF + \u696D\u52D9 prefix 3 \u6587\u5B57"),
    namingRule("db_column", "snake_case", "\u5C0F\u6587\u5B57\u30B9\u30CD\u30FC\u30AF. \u76E3\u67FB\u5217\u306F AUD_ \u63A5\u982D"),
    namingRule("typescript_var", "camelCase", "TS \u6A19\u6E96"),
    namingRule("typescript_type", "PascalCase", "\u578B\u30FB\u30AF\u30E9\u30B9"),
    namingRule("api_path", "kebab-case", "REST kebab + /v1/"),
    namingRule("component", "PascalCase", "React \u30B3\u30F3\u30DD\u30FC\u30CD\u30F3\u30C8"),
    namingRule("file", "PascalCase", "Java \u30AF\u30E9\u30B9\u30D5\u30A1\u30A4\u30EB"),
    namingRule("route", "kebab-case", "URL kebab. \u30AD\u30E3\u30E1\u30EB\u306F\u7981\u6B62")
  ],
  preferred_libraries: [
    {
      language: "java",
      libraries: [
        { name: "spring-framework", version_range: "6.x", reason: "THE STAR \u306E\u524D\u63D0" },
        { name: "spring-security", version_range: "6.x", reason: "\u8A8D\u53EF\u5FC5\u9808" },
        { name: "spring-boot-starter-web", version_range: "3.x", reason: "\u793E\u5185 boot \u306F OK (NTT\u30C7\u30FC\u30BF\u3068\u5DEE\u7570)" },
        { name: "lombok", version_range: "1.18.x", reason: "NRI \u3067\u306F\u8A31\u5BB9 (NTT\u30C7\u30FC\u30BF\u3068\u5DEE\u7570)" },
        { name: "jackson-databind", version_range: "2.16.x", reason: "JSON \u6A19\u6E96" },
        { name: "cucumber-java", version_range: "7.x", reason: "BDD \u6A19\u6E96" }
      ]
    },
    {
      language: "typescript",
      libraries: [
        { name: "react", version_range: "18.x", reason: "\u30D5\u30ED\u30F3\u30C8\u6A19\u6E96" },
        { name: "next", version_range: "14.x", reason: "\u793E\u5185\u627F\u8A8D\u6E08" },
        { name: "tanstack-query", reason: "\u30C7\u30FC\u30BF\u53D6\u5F97\u6A19\u6E96" },
        { name: "zod", reason: "\u30B9\u30AD\u30FC\u30DE\u691C\u8A3C" }
      ]
    }
  ],
  banned_libraries: [
    {
      language: "any",
      libraries: [
        { name: "mongodb", reason: "\u91D1\u878D ACID \u8981\u4EF6\u4E0D\u8DB3\u306E\u305F\u3081" },
        { name: "graphql", reason: "\u76E3\u67FB\u8981\u4EF6 (REST + OpenAPI) \u5FC5\u9808\u306E\u305F\u3081" },
        { name: "firebase", reason: "\u30C7\u30FC\u30BF\u8D8A\u5883\u30EA\u30B9\u30AF" }
      ]
    },
    {
      language: "javascript",
      libraries: [
        { name: "request", reason: "deprecated package" },
        { name: "moment", reason: "tree-shake \u4E0D\u53EF" }
      ]
    }
  ],
  deployment_targets: [
    "NRI \u30D7\u30E9\u30A4\u30D9\u30FC\u30C8\u30AF\u30E9\u30A6\u30C9 aslead-Cloud",
    "AWS (NRI ManagedCloud)",
    "Azure Japan East",
    "\u30AA\u30F3\u30D7\u30EC (NRI Tokyo II \u30C7\u30FC\u30BF\u30BB\u30F3\u30BF\u30FC)"
  ],
  documentation_template: {
    sections: [
      { title: "1. \u30D7\u30ED\u30B8\u30A7\u30AF\u30C8\u8A08\u753B\u66F8", outline: "NRI \u6848\u4EF6\u756A\u53F7 + Charter + \u30DE\u30A4\u30EB\u30B9\u30C8\u30FC\u30F3\u3002" },
      { title: "2. \u8981\u4EF6\u5B9A\u7FA9\u66F8", outline: "BR/FR/NFR \u306E\u4E09\u6BB5\u968E\u3002FISC \u5B89\u5BFE / \u30B7\u30B9\u30C6\u30E0\u76E3\u67FB\u57FA\u6E96\u5BFE\u5FDC\u3002" },
      { title: "3. \u57FA\u672C\u8A2D\u8A08\u66F8", outline: "THE STAR \u30EC\u30A4\u30E4\u56F3 + \u30E6\u30FC\u30B9\u30B1\u30FC\u30B9 + \u696D\u52D9\u30EB\u30FC\u30EB\u3002" },
      { title: "4. \u8A73\u7D30\u8A2D\u8A08\u66F8", outline: "\u30AF\u30E9\u30B9\u56F3 + \u30B7\u30FC\u30B1\u30F3\u30B9\u56F3 + DB \u7269\u7406\u8A2D\u8A08 (Oracle \u60F3\u5B9A)\u3002" },
      { title: "5. \u8A66\u9A13\u8A08\u753B/\u6210\u7E3E\u66F8", outline: "CT/IT/ST/UT \u306E 4 \u968E\u5C64 + Cucumber feature\u3002" },
      { title: "6. \u904B\u7528\u8A2D\u8A08\u66F8", outline: "aslead \u76E3\u8996 + \u969C\u5BB3\u5BFE\u5FDC + RTO/RPO\u3002" },
      { title: "7. \u79FB\u884C\u8A08\u753B\u66F8", outline: "\u30C7\u30FC\u30BF\u79FB\u884C + \u5207\u66FF\u30EA\u30CF\u30FC\u30B5\u30EB + \u30ED\u30FC\u30EB\u30D0\u30C3\u30AF\u8A08\u753B\u3002" },
      { title: "8. \u30BB\u30AD\u30E5\u30EA\u30C6\u30A3\u8A2D\u8A08\u66F8", outline: "FISC \u5B89\u5BFE\u5BFE\u5FDC\u8868 + OWASP ASVS L3\u3002" }
    ]
  },
  code_review_checklist: [
    "THE STAR \u30EC\u30A4\u30E4\u9055\u53CD\u304C\u7121\u3044\u304B",
    "FISC \u5B89\u5BFE\u306E\u30C1\u30A7\u30C3\u30AF\u9805\u76EE\u306B\u5BFE\u3059\u308B\u8A2D\u8A08\u8A18\u8FF0\u304C\u3042\u308B\u304B",
    "Spring Security \u306E\u8A8D\u53EF\u8A2D\u5B9A\u304C role + scope \u30D9\u30FC\u30B9\u304B",
    "Cucumber feature \u30D5\u30A1\u30A4\u30EB\u304C\u65E5\u672C\u8A9E\u30B7\u30CA\u30EA\u30AA\u3067\u7DB2\u7F85\u3055\u308C\u3066\u3044\u308B\u304B",
    "\u76E3\u67FB\u30ED\u30B0 (AUD_*) \u306E\u633F\u5165\u304C DAO \u306B\u7D71\u4E00\u3055\u308C\u3066\u3044\u308B\u304B",
    "OSS \u306F aslead OSS \u30EA\u30B9\u30C8\u627F\u8A8D\u6E08\u304B",
    "JFrog Artifactory \u306B\u30D3\u30EB\u30C9\u6210\u679C\u7269\u304C\u767B\u9332\u3055\u308C\u3066\u3044\u308B\u304B",
    "\u30AB\u30D0\u30EC\u30C3\u30B8 85% (\u91D1\u878D\u6848\u4EF6) \u3092\u8D85\u3048\u3066\u3044\u308B\u304B",
    "PR \u5358\u4F4D\u306E\u8106\u5F31\u6027\u30B9\u30AD\u30E3\u30F3 (Snyk) \u304C PASS \u304B",
    "\u500B\u4EBA\u60C5\u5831\u306E\u6697\u53F7\u5316 (KMS) \u304C\u5171\u901A\u30E2\u30B8\u30E5\u30FC\u30EB\u7D4C\u7531\u304B",
    "i18n \u306E\u6587\u8A00\u30AD\u30FC\u304C NRI \u6A19\u6E96\u30D5\u30A9\u30FC\u30DE\u30C3\u30C8\u304B",
    "DB \u30DE\u30A4\u30B0\u30EC\u30FC\u30B7\u30E7\u30F3\u304C Liquibase \u3067\u7BA1\u7406\u3055\u308C\u3066\u3044\u308B\u304B"
  ],
  qa_gate: {
    coverage_min: 85,
    lighthouse_min: 85,
    security_scan: true,
    static_analysis_tool: "SonarQube + Snyk",
    pen_test_required: true,
    load_test_required: true,
    doc_review_required: true,
    notes: "\u91D1\u878D\u6848\u4EF6\u306F FISC \u5B89\u5BFE\u30C1\u30A7\u30C3\u30AF\u30B7\u30FC\u30C8 + \u30B7\u30B9\u30C6\u30E0\u76E3\u67FB\u57FA\u6E96\u5B8C\u4E86\u304C\u5FC5\u9808"
  }
};
var NOMURA_TEMPLATE = {
  sier_id: "nomura",
  display_name: "Nomura Holdings (Internal)",
  display_name_ja: "\u91CE\u6751\u30DB\u30FC\u30EB\u30C7\u30A3\u30F3\u30B0\u30B9 (\u5185\u88FD)",
  architecture: {
    name: "NSP (Nomura Service Platform) / Quantum FX \u7CFB",
    description: "\u91CE\u6751\u8A3C\u5238\u30B0\u30EB\u30FC\u30D7\u306E\u5185\u88FD\u30D7\u30E9\u30C3\u30C8\u30D5\u30A9\u30FC\u30E0\u3002\u4F4E\u30EC\u30A4\u30C6\u30F3\u30B7 + FISC \u5B89\u5BFE + \u6D77\u5916\u898F\u5236 (SEC/FCA) \u540C\u6642\u6E96\u62E0\u304C\u5FC5\u9808\u3002Java + Aeron / Chronicle \u3067\u4F4E\u30EC\u30A4\u30C6\u30F3\u30B7\u3001\u5F8C\u6BB5\u306F Spring + Oracle\u3002",
    layers: [
      "Edge (Aeron / Chronicle for low latency)",
      "Gateway (Spring Cloud Gateway)",
      "Service (Spring + DDD)",
      "Persistence (Oracle 19c + Aurora PostgreSQL)",
      "Audit/Compliance (Splunk + \u5185\u88FD\u30B3\u30F3\u30D7\u30E9 DSL)",
      "Reporting (Power BI + \u5185\u88FD\u30EC\u30DD\u30B8)"
    ],
    mandatory_components: [
      "Spring Framework 6.x",
      "Aeron / Chronicle (\u4F4E\u30EC\u30A4\u30C6\u30F3\u30B7)",
      "Oracle Database 19c",
      "Splunk Enterprise",
      "JUnit 5 + JMH",
      "Datadog APM"
    ],
    forbidden_components: [
      "MongoDB",
      "Firebase",
      "Edge Functions (\u56FD\u5916\u8D8A\u5883)",
      "CDN Edge Workers (\u898F\u5236\u30C7\u30FC\u30BF\u542B\u3080\u5834\u5408)"
    ]
  },
  naming_rules: [
    namingRule("db_table", "UPPER_SNAKE", "\u91CE\u6751\u6A19\u6E96: \u5927\u6587\u5B57\u30B9\u30CD\u30FC\u30AF + \u696D\u52D9 prefix (TRD_/MKT_/CMP_)"),
    namingRule("db_column", "snake_case", "\u5C0F\u6587\u5B57\u30B9\u30CD\u30FC\u30AF. PII \u306F ENC_ \u63A5\u982D\u3067\u6697\u53F7\u5316\u5FC5\u9808"),
    namingRule("typescript_var", "camelCase", "\u793E\u5185 BFF \u6A19\u6E96"),
    namingRule("typescript_type", "PascalCase", "\u578B Pascal"),
    namingRule("api_path", "kebab-case", "REST API kebab + /v1/"),
    namingRule("component", "PascalCase", "React \u30B3\u30F3\u30DD\u30FC\u30CD\u30F3\u30C8"),
    namingRule("file", "PascalCase", "Java \u30AF\u30E9\u30B9")
  ],
  preferred_libraries: [
    {
      language: "java",
      libraries: [
        { name: "spring-framework", version_range: "6.x", reason: "\u793E\u5185\u6A19\u6E96" },
        { name: "aeron", reason: "\u4F4E\u30EC\u30A4\u30C6\u30F3\u30B7 messaging" },
        { name: "chronicle-queue", reason: "\u6C38\u7D9A\u30AD\u30E5\u30FC" },
        { name: "jmh", reason: "\u6027\u80FD\u6E2C\u5B9A\u6A19\u6E96" },
        { name: "micrometer-tracing", reason: "\u5206\u6563\u30C8\u30EC\u30FC\u30B9\u6A19\u6E96" }
      ]
    },
    {
      language: "typescript",
      libraries: [
        { name: "react", version_range: "18.x", reason: "BFF \u30D5\u30ED\u30F3\u30C8" },
        { name: "next", version_range: "14.x", reason: "\u793E\u5185\u627F\u8A8D" },
        { name: "d3", version_range: "7.x", reason: "\u30C1\u30E3\u30FC\u30C8\u6A19\u6E96" }
      ]
    },
    {
      language: "python",
      libraries: [
        { name: "pandas", reason: "\u793E\u5185\u30AF\u30AA\u30F3\u30C4\u6A19\u6E96" },
        { name: "numpy", reason: "\u540C\u4E0A" }
      ]
    }
  ],
  banned_libraries: [
    {
      language: "any",
      libraries: [
        { name: "mongodb", reason: "FISC \u5B89\u5BFE\u6E96\u62E0\u56F0\u96E3" },
        { name: "firebase", reason: "\u6D77\u5916\u30C7\u30FC\u30BF\u8D8A\u5883" },
        { name: "cdn-edge-functions", reason: "\u30C7\u30FC\u30BF\u56FD\u5916\u914D\u7F6E\u30EA\u30B9\u30AF" }
      ]
    },
    {
      language: "javascript",
      libraries: [
        { name: "moment", reason: "tree-shake \u4E0D\u53EF" },
        { name: "request", reason: "deprecated" }
      ]
    }
  ],
  deployment_targets: [
    "\u793E\u5185\u30D7\u30E9\u30A4\u30D9\u30FC\u30C8\u30AF\u30E9\u30A6\u30C9 (Tokyo + Singapore + London)",
    "AWS Tokyo Region (\u898F\u5236\u9069\u5408\u6E08\u30A2\u30AB\u30A6\u30F3\u30C8)",
    "AWS London Region (FCA \u9069\u5408)",
    "AWS NY Region (SEC \u9069\u5408)"
  ],
  documentation_template: {
    sections: [
      { title: "1. Charter / Project Plan", outline: "\u6848\u4EF6\u756A\u53F7 + \u95A2\u4FC2\u90E8\u9580 + \u30EA\u30B9\u30AF\u30AA\u30FC\u30CA\u30FC\u3002" },
      { title: "2. Business Requirements", outline: "\u53D6\u5F15\u30D5\u30ED\u30FC + \u6CD5\u898F\u5236\u5BFE\u5FDC (FISC/SEC/FCA)\u3002" },
      { title: "3. Functional Spec", outline: "\u6A5F\u80FD ID + \u30E6\u30FC\u30B9\u30B1\u30FC\u30B9 + \u4F8B\u5916\u51E6\u7406\u3002" },
      { title: "4. Non-Functional Spec", outline: "Latency budget (\u4F8B: <10ms p99) + \u53EF\u7528\u6027 99.99%\u3002" },
      { title: "5. Architecture Spec", outline: "NSP \u30EC\u30A4\u30E4\u56F3 + Aeron \u901A\u4FE1\u56F3\u3002" },
      { title: "6. Data Model", outline: "ERD + \u6697\u53F7\u5316\u65B9\u91DD + \u30C7\u30FC\u30BF\u4FDD\u6301\u671F\u9593\u3002" },
      { title: "7. Test Plan/Result", outline: "\u5358\u4F53/\u7D50\u5408/\u6027\u80FD (JMH)/\u53D7\u5165\u3002" },
      { title: "8. Operations Spec", outline: "Splunk \u76E3\u8996 + Datadog APM + \u969C\u5BB3\u5BFE\u5FDC\u3002" },
      { title: "9. Security/Compliance", outline: "FISC + ISO27001 + GDPR/CCPA \u5BFE\u5FDC\u8868\u3002" }
    ]
  },
  code_review_checklist: [
    "p99 latency budget \u3092\u8D85\u904E\u3057\u3066\u3044\u306A\u3044\u304B (JMH \u30D9\u30F3\u30C1\u901A\u904E)",
    "FISC \u5B89\u5BFE\u30C1\u30A7\u30C3\u30AF\u30EA\u30B9\u30C8\u6E96\u62E0\u304B",
    "\u500B\u4EBA\u60C5\u5831/\u53D6\u5F15\u60C5\u5831\u306E\u6697\u53F7\u5316 (KMS + Vault) \u304C\u5FC5\u9808",
    "Splunk \u76E3\u67FB\u30ED\u30B0\u306B\u30A4\u30D9\u30F3\u30C8\u304C\u8A18\u9332\u3055\u308C\u308B\u304B",
    "\u6D77\u5916\u30C7\u30FC\u30BF\u8D8A\u5883\u3057\u3066\u3044\u306A\u3044\u304B (\u30EA\u30FC\u30B8\u30E7\u30F3\u660E\u793A)",
    "Aeron / Chronicle \u306E termBuffer \u8A2D\u5B9A\u304C\u9069\u5207\u304B",
    "JMH \u30D9\u30F3\u30C1\u304C nightly \u3067\u8A08\u6E2C\u3055\u308C\u3066\u3044\u308B\u304B",
    "Datadog APM trace \u30BF\u30B0\u304C\u4ED8\u4E0E\u3055\u308C\u3066\u3044\u308B\u304B",
    "OWASP ASVS L3 \u6E96\u62E0\u304B",
    "\u793E\u5185\u30B3\u30F3\u30D7\u30E9 DSL \u306E\u30C1\u30A7\u30C3\u30AF\u304C PR \u5358\u4F4D\u3067 PASS \u304B",
    "\u30AB\u30D0\u30EC\u30C3\u30B8 90% (\u53D6\u5F15\u30B3\u30A2) \u3092\u6E80\u305F\u3059\u304B",
    "OSS \u30E9\u30A4\u30BB\u30F3\u30B9\u304C\u793E\u5185 OSS \u59D4\u54E1\u4F1A\u627F\u8A8D\u6E08\u304B"
  ],
  qa_gate: {
    coverage_min: 90,
    lighthouse_min: 85,
    security_scan: true,
    static_analysis_tool: "SonarQube + Veracode + \u5185\u88FD DSL",
    pen_test_required: true,
    load_test_required: true,
    doc_review_required: true,
    notes: "p99 latency / \u6D77\u5916\u898F\u5236\u9069\u5408\u306E\u4E8C\u91CD\u30B2\u30FC\u30C8"
  }
};
var NEC_TEMPLATE = {
  sier_id: "nec",
  display_name: "NEC",
  display_name_ja: "\u65E5\u672C\u96FB\u6C17 (NEC)",
  architecture: {
    name: "WebOTX + WebSAM \u6A19\u6E96 (\u516C\u5171/\u901A\u4FE1\u696D\u5411\u3051)",
    description: 'NEC \u306E AP \u30B5\u30FC\u30D0 "WebOTX" \u3068\u904B\u7528\u7D71\u5408\u7BA1\u7406 "WebSAM" \u3092\u4E2D\u6838\u3068\u3059\u308B\u3002\u516C\u5171\u7CFB\u3067\u306F SX-Aurora / Spica DB \u3068\u7D44\u307F\u5408\u308F\u305B\u3001\u5B98\u516C\u5E81 LGWAN \u74B0\u5883\u306B\u3082\u9069\u5408\u3055\u305B\u308B\u69CB\u6210\u3002',
    layers: [
      "Presentation (WebOTX Web Edition)",
      "Application (WebOTX Standard / Enterprise)",
      "Persistence (Oracle / Spica / PostgreSQL)",
      "Operation (WebSAM JobCenter / SystemManager)",
      "Integration (WebOTX ESB)"
    ],
    mandatory_components: [
      "WebOTX Application Server V11",
      "WebSAM JobCenter / SystemManager",
      "Oracle Database 19c \u307E\u305F\u306F Spica DB",
      "JDK 17",
      "JUnit 5"
    ],
    forbidden_components: [
      "JBoss",
      "Apache Cassandra",
      "Puppet (\u793E\u5185\u6A19\u6E96\u306F Ansible)"
    ]
  },
  naming_rules: [
    namingRule("db_table", "UPPER_SNAKE", "NEC \u516C\u5171\u7CFB\u6A19\u6E96: \u5927\u6587\u5B57\u30B9\u30CD\u30FC\u30AF + \u696D\u52D9\u7565\u53F7 (KOKU_/CHIHO_)"),
    namingRule("db_column", "snake_case", "\u5C0F\u6587\u5B57\u30B9\u30CD\u30FC\u30AF. \u524A\u9664\u30D5\u30E9\u30B0\u306F del_flg"),
    namingRule("typescript_var", "camelCase", "TS \u6A19\u6E96"),
    namingRule("typescript_type", "PascalCase", "\u578B Pascal"),
    namingRule("api_path", "kebab-case", "REST API kebab + /v1/"),
    namingRule("component", "PascalCase", "React \u30B3\u30F3\u30DD\u30FC\u30CD\u30F3\u30C8"),
    namingRule("file", "PascalCase", "Java \u30AF\u30E9\u30B9\u30D5\u30A1\u30A4\u30EB")
  ],
  preferred_libraries: [
    {
      language: "java",
      libraries: [
        { name: "webotx-cdi-api", reason: "NEC \u6A19\u6E96 CDI \u5B9F\u88C5" },
        { name: "jakarta.ee-api", version_range: "10.x", reason: "Jakarta EE 10" },
        { name: "spring-framework", version_range: "6.x", reason: "PoC\u30FB\u65B0\u898F\u7CFB\u3067\u8A31\u5BB9" },
        { name: "mybatis", version_range: "3.5.x", reason: "NEC \u516C\u5171\u7CFB\u3067\u591A\u7528" },
        { name: "junit-jupiter", version_range: "5.x", reason: "\u30C6\u30B9\u30C8\u6A19\u6E96" }
      ]
    },
    {
      language: "typescript",
      libraries: [
        { name: "react", version_range: "18.x", reason: "\u30D5\u30ED\u30F3\u30C8\u6A19\u6E96" },
        { name: "vite", reason: "\u30D3\u30EB\u30C9\u6A19\u6E96" },
        { name: "vitest", reason: "\u30C6\u30B9\u30C8\u6A19\u6E96" }
      ]
    }
  ],
  banned_libraries: [
    {
      language: "java",
      libraries: [
        { name: "jboss-as", reason: "NEC \u6A19\u6E96\u306F WebOTX" },
        { name: "wildfly", reason: "\u540C\u4E0A" }
      ]
    },
    {
      language: "any",
      libraries: [
        { name: "apache-cassandra", reason: "\u4FDD\u5B88\u8981\u54E1\u78BA\u4FDD\u56F0\u96E3" },
        { name: "puppet", reason: "\u793E\u5185\u6A19\u6E96\u306F Ansible/WebSAM" }
      ]
    }
  ],
  deployment_targets: [
    "NEC Cloud IaaS",
    "AWS (NEC ManagedCloud)",
    "Azure (NEC \u30A2\u30E9\u30A4\u30A2\u30F3\u30B9)",
    "\u30AA\u30F3\u30D7\u30EC (NEC Express5800)",
    "LGWAN-ASP \u63A5\u7D9A\u74B0\u5883"
  ],
  documentation_template: {
    sections: [
      { title: "1. \u30B7\u30B9\u30C6\u30E0\u6982\u8981\u66F8", outline: "\u6848\u4EF6\u5168\u4F53\u50CF + \u95A2\u4FC2\u7701\u5E81/\u90E8\u9580\u3002" },
      { title: "2. \u8981\u4EF6\u5B9A\u7FA9\u66F8", outline: "BR/FR/NFR + LGWAN \u63A5\u7D9A\u8981\u4EF6\u3002" },
      { title: "3. \u57FA\u672C\u8A2D\u8A08\u66F8", outline: "WebOTX/WebSAM \u69CB\u6210\u56F3 + \u696D\u52D9\u30D5\u30ED\u30FC\u3002" },
      { title: "4. \u8A73\u7D30\u8A2D\u8A08\u66F8", outline: "\u30AF\u30E9\u30B9\u56F3/\u30B7\u30FC\u30B1\u30F3\u30B9 + DB \u7269\u7406\u8A2D\u8A08\u3002" },
      { title: "5. \u8A66\u9A13\u8A08\u753B/\u6210\u7E3E\u66F8", outline: "4 \u968E\u5C64 + \u516C\u5171\u5411\u3051\u8FFD\u52A0\u9805\u76EE\u3002" },
      { title: "6. \u904B\u7528\u8A2D\u8A08\u66F8", outline: "WebSAM JobCenter \u30B8\u30E7\u30D6 + \u76E3\u8996\u8A2D\u8A08\u3002" },
      { title: "7. \u79FB\u884C\u8A2D\u8A08\u66F8", outline: "\u30C7\u30FC\u30BF\u79FB\u884C + \u5207\u66FF\u624B\u9806\u3002" },
      { title: "8. \u30BB\u30AD\u30E5\u30EA\u30C6\u30A3\u8A2D\u8A08\u66F8", outline: "\u653F\u5E9C\u7D71\u4E00\u57FA\u6E96 + ISMAP \u5BFE\u5FDC\u8868\u3002" }
    ]
  },
  code_review_checklist: [
    "WebOTX Application Server \u8A2D\u5B9A\u304C\u6A19\u6E96\u5024\u304B",
    "WebSAM JobCenter \u306E\u30B8\u30E7\u30D6\u30CD\u30C3\u30C8\u5B9A\u7FA9\u304C ER \u56F3\u3068\u6574\u5408\u3057\u3066\u3044\u308B\u304B",
    "LGWAN \u63A5\u7D9A\u8981\u4EF6 (TLS 1.2 \u4EE5\u4E0A + IP \u5236\u9650) \u3092\u6E80\u305F\u3059\u304B",
    "OSS \u30E9\u30A4\u30BB\u30F3\u30B9\u304C\u793E\u5185 OSS \u59D4\u54E1\u4F1A\u627F\u8A8D\u6E08\u304B",
    "\u30AB\u30D0\u30EC\u30C3\u30B8 80% \u3092\u8D85\u3048\u3066\u3044\u308B\u304B",
    "\u500B\u4EBA\u60C5\u5831\u9805\u76EE\u306B\u6697\u53F7\u5316 (NEC CipherCraft) \u304C\u9069\u7528\u3055\u308C\u3066\u3044\u308B\u304B",
    "PR \u30BF\u30A4\u30C8\u30EB\u306B\u6848\u4EF6\u756A\u53F7 + WBS-ID \u304C\u4ED8\u4E0E\u3055\u308C\u3066\u3044\u308B\u304B",
    "OWASP ASVS L2 \u6E96\u62E0\u304B",
    "\u653F\u5E9C\u7D71\u4E00\u57FA\u6E96 (R5 \u6539\u5B9A\u7248) \u306E\u30C1\u30A7\u30C3\u30AF\u30EA\u30B9\u30C8\u306B\u7F72\u540D\u304C\u3042\u308B\u304B",
    "\u30B8\u30E7\u30D6\u306E\u518D\u5B9F\u884C\u6027 (\u30EA\u30B9\u30BF\u30FC\u30C8\u8D77\u70B9) \u304C\u5B9A\u7FA9\u3055\u308C\u3066\u3044\u308B\u304B",
    "WebOTX \u306E\u30BB\u30C3\u30B7\u30E7\u30F3\u7BA1\u7406\u304C\u5171\u901A\u8A2D\u5B9A\u7D4C\u7531\u304B",
    "\u30D0\u30C3\u30C1 I/O \u306E\u6587\u5B57\u30B3\u30FC\u30C9 (UTF-8 / EBCDIC) \u304C\u660E\u793A\u3055\u308C\u3066\u3044\u308B\u304B"
  ],
  qa_gate: {
    coverage_min: 80,
    lighthouse_min: 80,
    security_scan: true,
    static_analysis_tool: "SonarQube + NEC CipherSecurity",
    pen_test_required: true,
    load_test_required: true,
    doc_review_required: true,
    notes: "\u516C\u5171\u7CFB\u306F ISMAP / \u653F\u5E9C\u7D71\u4E00\u57FA\u6E96 (R5 \u6539\u5B9A) \u306E\u30C1\u30A7\u30C3\u30AF\u30EA\u30B9\u30C8\u5FC5\u9808"
  }
};
var HITACHI_TEMPLATE = {
  sier_id: "hitachi",
  display_name: "Hitachi",
  display_name_ja: "\u65E5\u7ACB\u88FD\u4F5C\u6240",
  architecture: {
    name: "Cosminexus + JP1 \u6A19\u6E96",
    description: '\u65E5\u7ACB\u306E Application Server "Cosminexus" \u3068\u7D71\u5408\u904B\u7528\u7BA1\u7406 "JP1" \u3092\u4E2D\u6838\u3068\u3059\u308B\u3002\u91CD\u8981\u30A4\u30F3\u30D5\u30E9\u7CFB\u30FB\u793E\u4F1A\u30B7\u30B9\u30C6\u30E0\u5411\u3051\u306B\u4FE1\u983C\u6027 5 \u30CA\u30A4\u30F3 (99.999%) \u3092\u72D9\u3046\u69CB\u6210\u3002',
    layers: [
      "Presentation (Cosminexus Web Container)",
      "Business (Cosminexus EJB Container)",
      "Persistence (HiRDB / Oracle)",
      "Integration (Cosminexus Integration Platform)",
      "Operation (JP1/IT Service Management + JP1/AJS3)"
    ],
    mandatory_components: [
      "Cosminexus Application Server V11",
      "JP1/AJS3 (Automatic Job Management)",
      "JP1/IT Service Management",
      "HiRDB or Oracle 19c",
      "JDK 17",
      "JUnit 5"
    ],
    forbidden_components: [
      "Apache Tomcat (\u5358\u72EC)",
      "GraphQL (JP1 \u9023\u643A\u4E0D\u53EF\u306E\u305F\u3081)",
      "Jenkins-Pipeline (\u88DC\u52A9\u306E\u307F)"
    ]
  },
  naming_rules: [
    namingRule("db_table", "UPPER_SNAKE", "\u65E5\u7ACB\u6A19\u6E96: \u5927\u6587\u5B57\u30B9\u30CD\u30FC\u30AF + \u696D\u52D9 prefix (HIT_/MFG_/INFRA_)"),
    namingRule("db_column", "snake_case", "\u5C0F\u6587\u5B57\u30B9\u30CD\u30FC\u30AF. \u76E3\u67FB\u5217\u306F AUD_ \u63A5\u982D"),
    namingRule("typescript_var", "camelCase", "TS \u6A19\u6E96"),
    namingRule("typescript_type", "PascalCase", "\u578B Pascal"),
    namingRule("api_path", "kebab-case", "REST kebab + /v1/"),
    namingRule("component", "PascalCase", "React \u30B3\u30F3\u30DD\u30FC\u30CD\u30F3\u30C8"),
    namingRule("file", "PascalCase", "Java \u30AF\u30E9\u30B9")
  ],
  preferred_libraries: [
    {
      language: "java",
      libraries: [
        { name: "cosminexus-component", reason: "\u65E5\u7ACB\u6A19\u6E96\u30B3\u30F3\u30DD\u30FC\u30CD\u30F3\u30C8" },
        { name: "jakarta.ee-api", version_range: "10.x", reason: "Cosminexus 11 \u306E\u524D\u63D0" },
        { name: "spring-framework", version_range: "6.x", reason: "\u65B0\u898F\u7CFB\u3067\u4F75\u7528\u53EF" },
        { name: "mybatis", version_range: "3.5.x", reason: "HiRDB \u3068\u76F8\u6027\u826F" },
        { name: "junit-jupiter", version_range: "5.x", reason: "\u30C6\u30B9\u30C8\u6A19\u6E96" }
      ]
    },
    {
      language: "typescript",
      libraries: [
        { name: "react", version_range: "18.x", reason: "\u30D5\u30ED\u30F3\u30C8\u6A19\u6E96" },
        { name: "vite", reason: "\u30D3\u30EB\u30C9\u6A19\u6E96" },
        { name: "zod", reason: "\u30B9\u30AD\u30FC\u30DE\u691C\u8A3C" },
        { name: "tanstack-query", reason: "\u30C7\u30FC\u30BF\u53D6\u5F97\u6A19\u6E96" }
      ]
    }
  ],
  banned_libraries: [
    {
      language: "java",
      libraries: [
        { name: "tomcat-embed-core", reason: "\u65E5\u7ACB\u6A19\u6E96\u306F Cosminexus" },
        { name: "log4j-core", reason: "Log4Shell \u7D4C\u7DEF\u304B\u3089\u975E\u63A8\u5968" }
      ]
    },
    {
      language: "any",
      libraries: [
        { name: "graphql", reason: "JP1 \u9023\u643A\u5BFE\u8C61\u5916\u306E\u305F\u3081\u76E3\u67FB\u5916" },
        { name: "jenkins-pipeline", reason: "\u65E5\u7ACB\u6A19\u6E96\u306F JP1/AJS3" }
      ]
    }
  ],
  deployment_targets: [
    "\u65E5\u7ACB\u30AF\u30E9\u30A6\u30C9 SaaS / IaaS",
    "AWS (\u65E5\u7ACB\u30A2\u30E9\u30A4\u30A2\u30F3\u30B9)",
    "Azure (\u65E5\u7ACB\u30A2\u30E9\u30A4\u30A2\u30F3\u30B9)",
    "\u30AA\u30F3\u30D7\u30EC (\u65E5\u7ACB BladeSymphony)",
    "OT \u74B0\u5883 (\u5236\u5FA1\u7CFB/\u5DE5\u5834)"
  ],
  documentation_template: {
    sections: [
      { title: "1. \u30D7\u30ED\u30B8\u30A7\u30AF\u30C8\u8A08\u753B\u66F8", outline: "\u6848\u4EF6 ID + \u30DE\u30A4\u30EB\u30B9\u30C8\u30FC\u30F3 + \u30EA\u30B9\u30AF\u767B\u9332\u7C3F\u3002" },
      { title: "2. \u8981\u4EF6\u5B9A\u7FA9\u66F8", outline: "BR/FR/NFR + \u5B89\u5168\u8981\u4EF6 (\u6A5F\u80FD\u5B89\u5168 IEC 61508 \u7CFB)\u3002" },
      { title: "3. \u57FA\u672C\u8A2D\u8A08\u66F8", outline: "Cosminexus + JP1 \u69CB\u6210\u56F3\u3002" },
      { title: "4. \u8A73\u7D30\u8A2D\u8A08\u66F8", outline: "\u30AF\u30E9\u30B9\u56F3/\u30B7\u30FC\u30B1\u30F3\u30B9 + HiRDB \u7269\u7406\u8A2D\u8A08\u3002" },
      { title: "5. \u8A66\u9A13\u8A08\u753B/\u6210\u7E3E\u66F8", outline: "4 \u968E\u5C64 + \u30D5\u30A7\u30A4\u30EB\u30AA\u30FC\u30D0\u8A66\u9A13\u3002" },
      { title: "6. \u904B\u7528\u8A2D\u8A08\u66F8", outline: "JP1/AJS3 + JP1/ITSM + \u30E9\u30F3\u30D6\u30C3\u30AF\u3002" },
      { title: "7. \u4FE1\u983C\u6027\u8A2D\u8A08\u66F8", outline: "\u53EF\u7528\u6027 99.999% / FMEA / FTA\u3002" },
      { title: "8. \u79FB\u884C\u8A2D\u8A08\u66F8", outline: "\u30C7\u30FC\u30BF\u79FB\u884C + \u5207\u66FF\u30EA\u30CF\u30FC\u30B5\u30EB + \u30ED\u30FC\u30EB\u30D0\u30C3\u30AF\u3002" },
      { title: "9. \u30BB\u30AD\u30E5\u30EA\u30C6\u30A3\u8A2D\u8A08\u66F8", outline: "CSIRT \u5BFE\u5FDC + \u653F\u5E9C\u7D71\u4E00\u57FA\u6E96\u3002" }
    ]
  },
  code_review_checklist: [
    "Cosminexus \u306E\u30AF\u30E9\u30B9\u30ED\u30FC\u30C0\u968E\u5C64\u304C\u6A19\u6E96\u5024\u304B",
    "JP1 \u30B8\u30E7\u30D6\u30CD\u30C3\u30C8\u304C\u696D\u52D9\u30D5\u30ED\u30FC\u3068\u4E00\u81F4\u3057\u3066\u3044\u308B\u304B",
    "HiRDB \u306E\u8868\u9818\u57DF\u8A2D\u8A08\u304C\u627F\u8A8D\u56F3\u3068\u4E00\u81F4\u3057\u3066\u3044\u308B\u304B",
    "\u30D5\u30A7\u30A4\u30EB\u30AA\u30FC\u30D0\u8A66\u9A13\u304C\u8A66\u9A13\u8A08\u753B\u66F8\u306B\u7D44\u307F\u8FBC\u307E\u308C\u3066\u3044\u308B\u304B",
    "\u30AB\u30D0\u30EC\u30C3\u30B8 85% \u3092\u6E80\u305F\u3059\u304B (\u793E\u4F1A\u30B7\u30B9\u30C6\u30E0\u306F\u53B3\u683C)",
    "OSS \u30E9\u30A4\u30BB\u30F3\u30B9\u304C\u793E\u5185 OSS Hub \u627F\u8A8D\u6E08\u304B",
    "PR \u30BF\u30A4\u30C8\u30EB\u306B\u6848\u4EF6\u756A\u53F7 + JIRA \u30AD\u30FC\u304C\u4ED8\u4E0E\u3055\u308C\u3066\u3044\u308B\u304B",
    "OWASP ASVS L2 \u4EE5\u4E0A\u304B",
    "CSIRT \u9023\u7D61\u7D4C\u8DEF\u304C\u904B\u7528\u8A2D\u8A08\u66F8\u306B\u8A18\u8F09\u3055\u308C\u3066\u3044\u308B\u304B",
    "\u30B8\u30E7\u30D6\u306E\u7570\u5E38\u7D42\u4E86\u30D1\u30BF\u30FC\u30F3\u304C\u7DB2\u7F85\u3055\u308C\u3066\u3044\u308B\u304B",
    "\u76E3\u67FB\u30ED\u30B0 (AUD_*) \u304C\u5171\u901A\u30E2\u30B8\u30E5\u30FC\u30EB\u7D4C\u7531\u3067\u51FA\u529B\u3055\u308C\u308B\u304B",
    "\u6A5F\u80FD\u5B89\u5168\u8981\u4EF6 (IEC 61508) \u306E\u30C8\u30EC\u30FC\u30B5\u30D3\u30EA\u30C6\u30A3\u8868\u304C\u3042\u308B\u304B"
  ],
  qa_gate: {
    coverage_min: 85,
    lighthouse_min: 85,
    security_scan: true,
    static_analysis_tool: "SonarQube + \u65E5\u7ACB Hitachi Cyber Defender",
    pen_test_required: true,
    load_test_required: true,
    doc_review_required: true,
    notes: "\u793E\u4F1A\u30A4\u30F3\u30D5\u30E9\u7CFB\u306F\u6A5F\u80FD\u5B89\u5168/\u30D5\u30A7\u30A4\u30EB\u30AA\u30FC\u30D0\u8A66\u9A13\u5FC5\u9808"
  }
};
var TIS_TEMPLATE = {
  sier_id: "tis",
  display_name: "TIS Inc.",
  display_name_ja: "TIS",
  architecture: {
    name: "TIDS (TIS Integrated Development Standard) / Xenlon Cloud Native",
    description: "TIS \u306E\u6A19\u6E96\u30A2\u30FC\u30AD\u30C6\u30AF\u30C1\u30E3\u306F Spring Boot + React + AWS/Azure \u306E\u30AF\u30E9\u30A6\u30C9\u30CD\u30A4\u30C6\u30A3\u30D6\u3002\u91D1\u878D\u30FB\u30AB\u30FC\u30C9\u30FB\u516C\u5171\u5411\u3051\u306B Xenlon \u30D7\u30E9\u30C3\u30C8\u30D5\u30A9\u30FC\u30E0\u3092\u4F75\u7528\u3002\u30B3\u30F3\u30C6\u30CA\u5316\u3092\u5F37\u304F\u63A8\u5968\u3002",
    layers: [
      "Frontend (Next.js / React)",
      "BFF (Spring Boot WebFlux)",
      "Service (Spring Boot 3 + DDD)",
      "Persistence (PostgreSQL 15 / MySQL 8)",
      "Cloud Native (EKS / AKS + Istio)",
      "CI/CD (GitHub Actions + ArgoCD)"
    ],
    mandatory_components: [
      "Spring Boot 3.x",
      "Next.js 14 / React 18",
      "PostgreSQL 15",
      "Kubernetes (EKS or AKS)",
      "Terraform",
      "GitHub Actions + ArgoCD"
    ],
    forbidden_components: [
      "Aurelia (\u65E7\u5F0F)",
      "Rancher (\u793E\u5185\u975E\u6A19\u6E96)",
      "MongoDB (\u516C\u5171\u7CFB)"
    ]
  },
  naming_rules: [
    namingRule("db_table", "snake_case", "TIS \u306F\u5C0F\u6587\u5B57\u30B9\u30CD\u30FC\u30AF\u4E3B\u6D41 (PostgreSQL \u30D9\u30FC\u30B9)"),
    namingRule("db_column", "snake_case", "\u5C0F\u6587\u5B57\u30B9\u30CD\u30FC\u30AF"),
    namingRule("typescript_var", "camelCase", "TS \u6A19\u6E96"),
    namingRule("typescript_type", "PascalCase", "\u578B Pascal"),
    namingRule("api_path", "kebab-case", "REST kebab + /v1/"),
    namingRule("component", "PascalCase", "React \u30B3\u30F3\u30DD\u30FC\u30CD\u30F3\u30C8"),
    namingRule("file", "kebab-case", "TS/JS \u30D5\u30A1\u30A4\u30EB\u306F kebab-case (Next.js App Router)"),
    namingRule("route", "kebab-case", "URL kebab")
  ],
  preferred_libraries: [
    {
      language: "java",
      libraries: [
        { name: "spring-boot-starter-web", version_range: "3.x", reason: "TIS \u6A19\u6E96" },
        { name: "spring-boot-starter-webflux", version_range: "3.x", reason: "BFF \u6A19\u6E96" },
        { name: "spring-data-jpa", version_range: "3.x", reason: "ORM \u6A19\u6E96" },
        { name: "lombok", version_range: "1.18.x", reason: "TIS \u3067\u306F\u8A31\u5BB9" },
        { name: "flyway-core", version_range: "10.x", reason: "\u30DE\u30A4\u30B0\u30EC\u30FC\u30B7\u30E7\u30F3\u6A19\u6E96" }
      ]
    },
    {
      language: "typescript",
      libraries: [
        { name: "next", version_range: "14.x", reason: "\u30D5\u30ED\u30F3\u30C8\u6A19\u6E96" },
        { name: "react", version_range: "18.x", reason: "\u30D5\u30ED\u30F3\u30C8\u6A19\u6E96" },
        { name: "tailwindcss", version_range: "3.x", reason: "\u30B9\u30BF\u30A4\u30EB\u6A19\u6E96" },
        { name: "zod", version_range: "3.x", reason: "\u30D0\u30EA\u30C7\u30FC\u30B7\u30E7\u30F3" },
        { name: "tanstack-query", reason: "\u30C7\u30FC\u30BF\u53D6\u5F97" },
        { name: "vitest", version_range: "1.x", reason: "\u30C6\u30B9\u30C8" },
        { name: "playwright", version_range: "1.x", reason: "E2E" }
      ]
    },
    {
      language: "go",
      libraries: [
        { name: "gin-gonic/gin", reason: "API \u30D5\u30EC\u30FC\u30E0\u30EF\u30FC\u30AF (PoC \u7528)" },
        { name: "spf13/cobra", reason: "CLI \u6A19\u6E96" }
      ]
    }
  ],
  banned_libraries: [
    {
      language: "javascript",
      libraries: [
        { name: "aurelia", reason: "\u4FDD\u5B88\u56F0\u96E3\u3067\u63A1\u7528\u3057\u306A\u3044" },
        { name: "angularjs", reason: "EOL \u306E\u305F\u3081" },
        { name: "jquery", reason: "\u65B0\u898F\u63A1\u7528\u7981\u6B62" }
      ]
    },
    {
      language: "any",
      libraries: [
        { name: "rancher", reason: "TIS \u30A4\u30F3\u30D5\u30E9\u6A19\u6E96\u306F EKS/AKS" },
        { name: "mongodb", reason: "\u516C\u5171\u7CFB\u3067\u306F\u63A1\u7528\u3057\u306A\u3044" }
      ]
    }
  ],
  deployment_targets: [
    "AWS (TIS Managed Cloud)",
    "Azure (TIS Managed Cloud)",
    "Xenlon Platform (TIS \u5185\u88FD\u30AF\u30E9\u30A6\u30C9)",
    "EKS / AKS",
    "\u30AA\u30F3\u30D7\u30EC (TIS \u30C7\u30FC\u30BF\u30BB\u30F3\u30BF\u30FC)"
  ],
  documentation_template: {
    sections: [
      { title: "1. \u30D7\u30ED\u30B8\u30A7\u30AF\u30C8 Charter", outline: "\u30B9\u30B3\u30FC\u30D7 + \u30B9\u30C6\u30FC\u30AF\u30DB\u30EB\u30C0 + \u4FA1\u5024 KPI\u3002" },
      { title: "2. \u8981\u4EF6\u5B9A\u7FA9\u66F8", outline: "BR/FR/NFR + \u30EA\u30B9\u30AF + \u5236\u7D04\u3002" },
      { title: "3. \u30B7\u30B9\u30C6\u30E0\u8A2D\u8A08\u66F8", outline: "\u30DE\u30A4\u30AF\u30ED\u30B5\u30FC\u30D3\u30B9\u5206\u5272 + API \u8A2D\u8A08 + \u30C7\u30FC\u30BF\u8A2D\u8A08\u3002" },
      { title: "4. \u958B\u767A\u6A19\u6E96\u66F8", outline: "TIDS \u30B3\u30FC\u30C7\u30A3\u30F3\u30B0\u898F\u7D04 + Git Flow + PR \u30C6\u30F3\u30D7\u30EC\u3002" },
      { title: "5. \u30A4\u30F3\u30D5\u30E9\u8A2D\u8A08\u66F8", outline: "Terraform + EKS + Istio + \u76E3\u8996\u3002" },
      { title: "6. \u8A66\u9A13\u8A08\u753B/\u6210\u7E3E\u66F8", outline: "\u5358\u4F53 (Vitest/JUnit) + \u7D50\u5408 + E2E (Playwright)\u3002" },
      { title: "7. \u904B\u7528\u8A2D\u8A08\u66F8", outline: "PagerDuty / Datadog + \u30E9\u30F3\u30D6\u30C3\u30AF + SLO\u3002" },
      { title: "8. \u30BB\u30AD\u30E5\u30EA\u30C6\u30A3\u8A2D\u8A08\u66F8", outline: "OWASP ASVS L2 + Snyk + \u500B\u4EBA\u60C5\u5831\u4FDD\u8B77\u3002" }
    ]
  },
  code_review_checklist: [
    "\u30DE\u30A4\u30AF\u30ED\u30B5\u30FC\u30D3\u30B9\u5883\u754C (Bounded Context) \u304C\u5D29\u308C\u3066\u3044\u306A\u3044\u304B",
    "OpenAPI \u4ED5\u69D8\u66F8\u304C\u30B3\u30FC\u30C9\u3068\u540C\u671F\u3057\u3066\u3044\u308B\u304B (linter PASS)",
    "Terraform plan \u306E\u5DEE\u5206\u304C PR \u306B\u8CBC\u3089\u308C\u3066\u3044\u308B\u304B",
    "\u30AB\u30D0\u30EC\u30C3\u30B8 80% \u3092\u6E80\u305F\u3059\u304B",
    "Snyk / Trivy \u306E\u8106\u5F31\u6027\u304C High \u4EE5\u4E0B\u304B",
    "GitHub Actions \u306E matrix \u304C node 18/20 \u901A\u904E\u3057\u3066\u3044\u308B\u304B",
    "PR \u30BF\u30A4\u30C8\u30EB\u306B JIRA \u30AD\u30FC\u304C\u4ED8\u4E0E\u3055\u308C\u3066\u3044\u308B\u304B",
    "OWASP Top10 \u5BFE\u5FDC\u30C1\u30A7\u30C3\u30AF\u304C\u3042\u308B\u304B",
    "feature flag \u306E trunk-based \u958B\u767A\u3092\u9038\u8131\u3057\u3066\u3044\u306A\u3044\u304B",
    "ArgoCD \u306E sync \u304C Green \u304B",
    "Datadog \u306E SLO \u30A2\u30E9\u30FC\u30C8\u304C\u69CB\u6210\u3055\u308C\u3066\u3044\u308B\u304B",
    "\u30B3\u30DF\u30C3\u30C8\u30E1\u30C3\u30BB\u30FC\u30B8\u304C Conventional Commits \u6E96\u62E0\u304B",
    "i18n \u306E\u6587\u8A00\u30AD\u30FC\u304C TIS \u6A19\u6E96\u30D5\u30A9\u30FC\u30DE\u30C3\u30C8\u304B"
  ],
  qa_gate: {
    coverage_min: 80,
    lighthouse_min: 90,
    security_scan: true,
    static_analysis_tool: "SonarQube + Snyk + Trivy",
    pen_test_required: true,
    load_test_required: true,
    doc_review_required: true,
    notes: "\u30AF\u30E9\u30A6\u30C9\u30CD\u30A4\u30C6\u30A3\u30D6\u524D\u63D0\u3002SLO \u30D9\u30FC\u30B9\u306E\u904B\u7528\u304C\u5FC5\u9808"
  }
};
var GENERIC_TEMPLATE = {
  sier_id: "generic",
  display_name: "Generic SIer",
  display_name_ja: "\u6C4E\u7528 SI / \u4E2D\u5805\u53D7\u8A17\u958B\u767A",
  architecture: {
    name: "Modern Web Stack (Next.js + Node + Postgres)",
    description: "\u4E2D\u5805 SIer / \u53D7\u8A17\u958B\u767A\u3067\u5E83\u304F\u63A1\u7528\u3055\u308C\u308B\u6A19\u6E96\u69CB\u6210\u3002Next.js + Prisma + PostgreSQL + Vercel/AWS\u3002Claude Code \u4E92\u63DB\u6027\u3092\u91CD\u8996\u3057\u3001SIer \u56FA\u6709\u5236\u7D04\u3092\u6700\u5C0F\u9650\u306B\u3059\u308B\u3002",
    layers: [
      "Frontend (Next.js App Router)",
      "API Routes / Server Actions",
      "Service Layer (TypeScript)",
      "Persistence (Prisma + PostgreSQL)",
      "Auth (Auth.js / Clerk)",
      "CI/CD (GitHub Actions)"
    ],
    mandatory_components: [
      "Next.js 14+",
      "TypeScript 5.x",
      "PostgreSQL 15+",
      "Prisma 5.x or Drizzle ORM",
      "Vitest 1.x",
      "Playwright 1.x"
    ],
    forbidden_components: [
      "jQuery \u5358\u72EC\u69CB\u6210",
      "PHP 5.x",
      "Internet Explorer \u5C02\u7528 JS"
    ]
  },
  naming_rules: [
    namingRule("db_table", "snake_case", "\u4E00\u822C\u7684: \u5C0F\u6587\u5B57\u30B9\u30CD\u30FC\u30AF (PostgreSQL \u6D41\u5100)"),
    namingRule("db_column", "snake_case", "\u5C0F\u6587\u5B57\u30B9\u30CD\u30FC\u30AF"),
    namingRule("typescript_var", "camelCase", "TS \u6A19\u6E96"),
    namingRule("typescript_type", "PascalCase", "\u578B Pascal"),
    namingRule("api_path", "kebab-case", "REST kebab"),
    namingRule("component", "PascalCase", "React \u30B3\u30F3\u30DD\u30FC\u30CD\u30F3\u30C8"),
    namingRule("file", "kebab-case", "Next.js App Router \u6A19\u6E96"),
    namingRule("route", "kebab-case", "URL kebab")
  ],
  preferred_libraries: [
    {
      language: "typescript",
      libraries: [
        { name: "next", version_range: "14.x", reason: "\u30D5\u30ED\u30F3\u30C8+API \u6A19\u6E96" },
        { name: "react", version_range: "18.x", reason: "\u6A19\u6E96" },
        { name: "prisma", version_range: "5.x", reason: "ORM \u6A19\u6E96" },
        { name: "zod", version_range: "3.x", reason: "\u30D0\u30EA\u30C7\u30FC\u30B7\u30E7\u30F3\u6A19\u6E96" },
        { name: "tailwindcss", version_range: "3.x", reason: "\u30B9\u30BF\u30A4\u30EB" },
        { name: "vitest", version_range: "1.x", reason: "\u30C6\u30B9\u30C8" },
        { name: "playwright", version_range: "1.x", reason: "E2E" }
      ]
    },
    {
      language: "python",
      libraries: [
        { name: "fastapi", version_range: "0.110.x", reason: "API \u7528" },
        { name: "pydantic", version_range: "2.x", reason: "\u30D0\u30EA\u30C7\u30FC\u30B7\u30E7\u30F3" }
      ]
    }
  ],
  banned_libraries: [
    {
      language: "javascript",
      libraries: [
        { name: "request", reason: "deprecated package (2020)" },
        { name: "moment", reason: "tree-shake \u4E0D\u53EF" },
        { name: "jquery", reason: "\u65B0\u898F\u63A1\u7528\u306F\u63A8\u5968\u3057\u306A\u3044" }
      ]
    },
    {
      language: "java",
      libraries: [
        { name: "log4j-core", reason: "Log4Shell \u7CFB\u7D71\u306F 2.17.1+ \u306E\u307F" }
      ]
    }
  ],
  deployment_targets: [
    "Vercel",
    "AWS (Lambda + RDS)",
    "Cloudflare Pages",
    "Railway / Render",
    "\u30AA\u30F3\u30D7\u30EC\u30DF\u30B9 (Docker Swarm / k3s)"
  ],
  documentation_template: {
    sections: [
      { title: "1. \u30D7\u30ED\u30B8\u30A7\u30AF\u30C8\u6982\u8981", outline: "\u30B4\u30FC\u30EB + \u30B9\u30C6\u30FC\u30AF\u30DB\u30EB\u30C0 + \u671F\u9593\u3002" },
      { title: "2. \u8981\u4EF6\u5B9A\u7FA9\u66F8", outline: "\u6A5F\u80FD\u8981\u4EF6 + \u975E\u6A5F\u80FD\u8981\u4EF6 + \u5236\u7D04\u3002" },
      { title: "3. \u30B7\u30B9\u30C6\u30E0\u69CB\u6210\u56F3", outline: "\u30AF\u30E9\u30A6\u30C9\u69CB\u6210 + \u30C7\u30FC\u30BF\u30D5\u30ED\u30FC\u3002" },
      { title: "4. \u30C7\u30FC\u30BF\u30D9\u30FC\u30B9\u8A2D\u8A08\u66F8", outline: "ERD + \u30C6\u30FC\u30D6\u30EB\u5B9A\u7FA9 + \u30DE\u30A4\u30B0\u30EC\u30FC\u30B7\u30E7\u30F3\u8A08\u753B\u3002" },
      { title: "5. API \u4ED5\u69D8\u66F8", outline: "OpenAPI 3.1 \u30D9\u30FC\u30B9 + \u8A8D\u53EF\u65B9\u91DD\u3002" },
      { title: "6. \u8A66\u9A13\u8A08\u753B/\u6210\u7E3E\u66F8", outline: "\u5358\u4F53 + \u7D50\u5408 + E2E\u3002" },
      { title: "7. \u904B\u7528\u624B\u9806\u66F8", outline: "\u30C7\u30D7\u30ED\u30A4 + \u76E3\u8996 + \u969C\u5BB3\u5BFE\u5FDC\u3002" },
      { title: "8. \u30BB\u30AD\u30E5\u30EA\u30C6\u30A3\u8981\u4EF6", outline: "OWASP Top10 + \u500B\u4EBA\u60C5\u5831\u4FDD\u8B77\u6CD5\u3002" }
    ]
  },
  code_review_checklist: [
    "TypeScript strict mode \u3092\u6709\u52B9\u306B\u3057\u3066\u3044\u308B\u304B",
    "Zod \u30D0\u30EA\u30C7\u30FC\u30B7\u30E7\u30F3\u304C API \u5165\u529B\u306B\u5B58\u5728\u3059\u308B\u304B",
    "Prisma migration \u304C PR \u306B\u540C\u68B1\u3055\u308C\u3066\u3044\u308B\u304B",
    "\u30AB\u30D0\u30EC\u30C3\u30B8 70% \u3092\u6E80\u305F\u3059\u304B",
    "Lighthouse Performance >= 80 \u304B",
    "OWASP Top10 (A01-A10) \u5BFE\u5FDC\u30C1\u30A7\u30C3\u30AF\u304C\u3042\u308B\u304B",
    "PR \u30BF\u30A4\u30C8\u30EB\u306B issue \u756A\u53F7\u304C\u3042\u308B\u304B",
    "\u74B0\u5883\u5909\u6570\u304C .env.example \u306B\u3082\u53CD\u6620\u3055\u308C\u3066\u3044\u308B\u304B",
    "README \u304C\u66F4\u65B0\u3055\u308C\u3066\u3044\u308B\u304B",
    "\u4F9D\u5B58\u30E9\u30A4\u30D6\u30E9\u30EA\u306E\u8106\u5F31\u6027\u304C npm audit \u3067 moderate \u4EE5\u4E0B\u304B",
    "\u65E5\u672C\u8A9E/\u82F1\u8A9E\u306E i18n \u30AD\u30FC\u304C\u63C3\u3063\u3066\u3044\u308B\u304B",
    "\u30B3\u30DF\u30C3\u30C8\u30E1\u30C3\u30BB\u30FC\u30B8\u304C Conventional Commits \u6E96\u62E0\u304B"
  ],
  qa_gate: {
    coverage_min: 70,
    lighthouse_min: 80,
    security_scan: true,
    static_analysis_tool: "ESLint + Biome + Snyk",
    pen_test_required: false,
    load_test_required: false,
    doc_review_required: true,
    notes: "\u4E2D\u5805 SIer \u30D9\u30FC\u30B9\u30E9\u30A4\u30F3\u3002\u8981\u4EF6\u6B21\u7B2C\u3067 NTT\u30C7\u30FC\u30BF/NRI \u7D1A\u306B\u5F15\u304D\u4E0A\u3052\u53EF"
  }
};

// ../../soloptilink-tenant-dna/lib/cross_project_synthesizer.ts
import * as fs2 from "node:fs";
import * as path2 from "node:path";
function tokenize(text) {
  return text.toLowerCase().replace(/[^a-z0-9ぁ-んァ-ヶ一-龯_\-\s]/g, " ").split(/\s+/).filter((t) => t.length >= 2);
}
function jaccard(a, b) {
  const sa = a instanceof Set ? a : new Set(a);
  const sb = b instanceof Set ? b : new Set(b);
  if (sa.size === 0 && sb.size === 0) return 0;
  let inter = 0;
  for (const v of sa) if (sb.has(v)) inter += 1;
  const uni = sa.size + sb.size - inter;
  return uni === 0 ? 0 : inter / uni;
}
function tokenSimilarity(textA, textB) {
  return jaccard(tokenize(textA), tokenize(textB));
}
function clusterDecisions(decisions, threshold = 0.6) {
  const clusters = [];
  for (const d of decisions) {
    let placed = false;
    for (const c of clusters) {
      const seed = c[0];
      if (seed.category !== d.category) continue;
      const sim = tokenSimilarity(seed.decision, d.decision);
      if (sim >= threshold) {
        c.push(d);
        placed = true;
        break;
      }
    }
    if (!placed) clusters.push([d]);
  }
  return clusters;
}
function outcomeScore(outcome) {
  switch (outcome) {
    case "success":
      return 1;
    case "partial":
      return 0.5;
    case "failed":
      return 0;
    case "in_progress":
    case void 0:
    default:
      return null;
  }
}
function listAllProjectsInSier(sier_id, root = STORAGE_ROOT) {
  const result = [];
  const customersBase = path2.join(sierDir(sier_id, root), "customers");
  if (!fs2.existsSync(customersBase)) return result;
  for (const td of fs2.readdirSync(customersBase, { withFileTypes: true })) {
    if (!td.isDirectory()) continue;
    const tenant_id = td.name;
    const projectsBase = path2.join(customerDir(sier_id, tenant_id, root), "projects");
    if (!fs2.existsSync(projectsBase)) continue;
    for (const pd of fs2.readdirSync(projectsBase, { withFileTypes: true })) {
      if (!pd.isDirectory()) continue;
      result.push({ tenant_id, project_id: pd.name });
    }
  }
  return result;
}
function listAllSiers(root = STORAGE_ROOT) {
  if (!fs2.existsSync(root)) return [];
  return fs2.readdirSync(root, { withFileTypes: true }).filter((d) => d.isDirectory() && !d.name.startsWith("_")).map((d) => d.name);
}
function gatherDecisionsWithOutcome(scope, scope_id, root = STORAGE_ROOT) {
  const decisions = [];
  const projectOutcomes = /* @__PURE__ */ new Map();
  const siers = scope === "global" ? listAllSiers(root) : [scope_id];
  if (scope === "customer") {
    for (const sid of listAllSiers(root)) {
      const decs = readDecisionsForCustomer(sid, scope_id, root);
      if (decs.length === 0) continue;
      decisions.push(...decs);
      const customersBase = path2.join(sierDir(sid, root), "customers", scope_id, "projects");
      if (fs2.existsSync(customersBase)) {
        for (const pd of fs2.readdirSync(customersBase, { withFileTypes: true })) {
          if (!pd.isDirectory()) continue;
          const pp = readProjectProfile(sid, scope_id, pd.name, root);
          if (pp) projectOutcomes.set(pp.project_id, outcomeScore(pp.outcome));
        }
      }
    }
    return { decisions, projectOutcomes };
  }
  for (const sid of siers) {
    for (const { tenant_id, project_id } of listAllProjectsInSier(sid, root)) {
      const pp = readProjectProfile(sid, tenant_id, project_id, root);
      if (pp) projectOutcomes.set(project_id, outcomeScore(pp.outcome));
    }
    const customersBase = path2.join(sierDir(sid, root), "customers");
    if (!fs2.existsSync(customersBase)) continue;
    for (const td of fs2.readdirSync(customersBase, { withFileTypes: true })) {
      if (!td.isDirectory()) continue;
      const decs = readDecisionsForCustomer(sid, td.name, root);
      decisions.push(...decs);
    }
  }
  return { decisions, projectOutcomes };
}
function summarizePattern(cluster) {
  const tf = /* @__PURE__ */ new Map();
  for (const d of cluster) {
    for (const t of tokenize(`${d.title} ${d.decision}`)) {
      tf.set(t, (tf.get(t) ?? 0) + 1);
    }
  }
  const top = [...tf.entries()].sort((a, b) => b[1] - a[1]).slice(0, 5).map(([t]) => t).join(", ");
  const head = cluster[0].decision.replace(/\s+/g, " ").trim();
  const headShort = head.length > 80 ? head.slice(0, 80) + "\u2026" : head;
  return `[${top}] ${headShort}`;
}
function recommendationFromPattern(cluster) {
  const occ = cluster.length;
  const alts = /* @__PURE__ */ new Set();
  for (const d of cluster) {
    for (const a of d.alternatives_considered ?? []) alts.add(a);
  }
  const altText = alts.size > 0 ? ` (\u4EE3\u66FF\u6848\u3068\u3057\u3066\u691C\u8A0E\u3055\u308C\u305F: ${[...alts].slice(0, 3).join(", ")})` : "";
  if (occ >= 8) {
    return `\u904E\u53BB ${occ} \u30D7\u30ED\u30B8\u30A7\u30AF\u30C8\u3067\u63A1\u7528\u3055\u308C\u305F\u5B9A\u77F3\u3002\u539F\u5247\u8E0F\u8972\u3092\u63A8\u5968${altText}`;
  }
  if (occ >= 4) {
    return `\u904E\u53BB ${occ} \u30D7\u30ED\u30B8\u30A7\u30AF\u30C8\u3067\u63A1\u7528\u3002\u540C\u69D8\u306E\u5236\u7D04\u304C\u3042\u308C\u3070\u8E0F\u8972\u3092\u63A8\u5968${altText}`;
  }
  return `\u904E\u53BB ${occ} \u30D7\u30ED\u30B8\u30A7\u30AF\u30C8\u3067\u63A1\u7528\u3055\u308C\u305F\u524D\u4F8B\u3042\u308A\u3002\u8981\u4EF6\u6B21\u7B2C\u3067\u53C2\u8003${altText}`;
}
function distillPatterns(scope, scope_id, options = {}) {
  const minOccurrence = options.min_occurrence ?? 3;
  const minSuccess = options.min_success_rate ?? 0;
  const { decisions, projectOutcomes } = gatherDecisionsWithOutcome(scope, scope_id);
  if (decisions.length === 0) return [];
  const byCategory = /* @__PURE__ */ new Map();
  for (const d of decisions) {
    if (!byCategory.has(d.category)) byCategory.set(d.category, []);
    byCategory.get(d.category).push(d);
  }
  const out = [];
  const now = (/* @__PURE__ */ new Date()).toISOString();
  for (const [category, cat_decs] of byCategory) {
    const clusters = clusterDecisions(cat_decs, 0.6);
    for (const cluster of clusters) {
      if (cluster.length < minOccurrence) continue;
      const projectIds = Array.from(
        new Set(cluster.map((d) => d.project_id).filter((p) => Boolean(p)))
      );
      const scores = [];
      for (const pid of projectIds) {
        const s = projectOutcomes.get(pid);
        if (s !== null && s !== void 0) scores.push(s);
      }
      const success_rate = scores.length === 0 ? 0 : scores.reduce((a, b) => a + b, 0) / scores.length;
      if (success_rate < minSuccess) continue;
      out.push({
        pattern_id: generateId("ptn"),
        scope,
        scope_id,
        category,
        pattern_summary: summarizePattern(cluster),
        occurrence_count: cluster.length,
        success_rate: Number(success_rate.toFixed(3)),
        example_project_ids: projectIds.slice(0, 10),
        recommendation_text: recommendationFromPattern(cluster),
        distilled_at: now
      });
    }
  }
  out.sort((a, b) => {
    if (b.occurrence_count !== a.occurrence_count) return b.occurrence_count - a.occurrence_count;
    return b.success_rate - a.success_rate;
  });
  return out;
}

// ../../soloptilink-tenant-dna/lib/memory_graph.ts
function snapshotCustomerMaterials(sier_id, tenant_id, root = STORAGE_ROOT) {
  return {
    sier: getSier(sier_id),
    customer: getCustomer(sier_id, tenant_id),
    decisions: readDecisionsForCustomer(sier_id, tenant_id, root),
    naming_rules: readNamingRules(sier_id, tenant_id, root),
    blacklist: readBlacklist(sier_id, tenant_id, root),
    patterns: readPatterns("sier", sier_id, root)
  };
}
function recallSummary(ctx, root = STORAGE_ROOT) {
  const warnings = [];
  const generatedAt = (/* @__PURE__ */ new Date()).toISOString();
  if (!ctx.sier_id || !ctx.tenant_id) {
    warnings.push("sier_id / tenant_id \u304C\u6307\u5B9A\u3055\u308C\u3066\u3044\u306A\u3044\u305F\u3081\u3001\u7A7A\u306E RecallResult \u3092\u8FD4\u3057\u307E\u3059\u3002");
    return {
      generated_at: generatedAt,
      tenant_id: ctx.tenant_id,
      project_id: ctx.project_id,
      active_naming_rules: [],
      active_blacklist: [],
      recent_decisions: [],
      related_patterns: [],
      warnings
    };
  }
  const materials = snapshotCustomerMaterials(ctx.sier_id, ctx.tenant_id, root);
  if (!materials.sier) warnings.push(`SIer \u30D7\u30ED\u30D5\u30A1\u30A4\u30EB ${ctx.sier_id} \u304C\u672A\u767B\u9332\u3067\u3059\u3002`);
  if (!materials.customer) warnings.push(`\u9867\u5BA2\u30D7\u30ED\u30D5\u30A1\u30A4\u30EB ${ctx.tenant_id} \u304C\u672A\u767B\u9332\u3067\u3059\u3002`);
  return {
    generated_at: generatedAt,
    tenant_id: ctx.tenant_id,
    project_id: ctx.project_id,
    sier_profile: materials.sier ?? void 0,
    customer_profile: materials.customer ?? void 0,
    project_profile: ctx.project_id && materials.sier && materials.customer ? getProject(ctx.sier_id, ctx.tenant_id, ctx.project_id) ?? void 0 : void 0,
    active_naming_rules: materials.naming_rules.filter((r) => r.enforced),
    active_blacklist: materials.blacklist,
    recent_decisions: materials.decisions.filter((d) => d.status === "active").slice(-10).reverse(),
    related_patterns: materials.patterns.slice(0, 5),
    warnings
  };
}

// ../../soloptilink-tenant-dna/lib/recall_engine.ts
function recallForBoost(input, root = STORAGE_ROOT) {
  const baseResult = recallSummary(input, root);
  const hasIdentifiers = Boolean(input.sier_id && input.tenant_id);
  if (!hasIdentifiers) {
    return {
      result: baseResult,
      inference_block_markdown: buildEmptyBlock(input),
      injection_lines_for_agents: [],
      has_data: false
    };
  }
  let enrichedPatterns = baseResult.related_patterns;
  if (input.sier_id && enrichedPatterns.length === 0) {
    try {
      enrichedPatterns = distillPatterns("sier", input.sier_id, { min_occurrence: 2 }).slice(0, 5);
    } catch {
    }
  }
  const result = {
    ...baseResult,
    related_patterns: enrichedPatterns,
    recommended_stack: deriveRecommendedStack(baseResult, input)
  };
  return {
    result,
    inference_block_markdown: buildInferenceBlock(result, input),
    injection_lines_for_agents: buildAgentInjections(result, input),
    has_data: result.recent_decisions.length > 0 || result.active_naming_rules.length > 0
  };
}
function deriveRecommendedStack(result, _input) {
  const stackDecisions = result.recent_decisions.filter((d) => d.category === "stack");
  if (stackDecisions.length === 0) {
    if (result.sier_profile?.preferred_libraries?.length) {
      return result.sier_profile.preferred_libraries.slice(0, 6);
    }
    return void 0;
  }
  return stackDecisions.slice(0, 1).flatMap(
    (d) => d.decision.split(/[\/、,，]/).map((s) => s.trim()).filter((s) => s.length > 0)
  );
}
function buildEmptyBlock(input) {
  const lines = [];
  lines.push("\u3010Tenant DNA \u81EA\u52D5\u9069\u7528\u3011v2019.2");
  lines.push(`- \u72B6\u614B: \u672A\u767B\u9332 (sier_id=${input.sier_id ?? "-"}, tenant_id=${input.tenant_id ?? "-"})`);
  lines.push(
    "- \u30A2\u30AF\u30B7\u30E7\u30F3: \u521D\u56DE\u8D77\u52D5\u6642\u306F `/soloptilink-tenant-dna --mode register --sier <id> --tenant <id> --project <id>` \u3067\u767B\u9332\u3057\u3066\u304F\u3060\u3055\u3044\u3002\u4EE5\u964D\u306E\u30BB\u30C3\u30B7\u30E7\u30F3\u3067\u6C38\u7D9A\u5B66\u7FD2\u304C\u6709\u52B9\u306B\u306A\u308A\u307E\u3059\u3002"
  );
  lines.push("- \u51FA\u8377\u6642 SIer \u96DB\u5F62: 8\u7A2E (nttdata/fujitsu/nri/nomura/nec/hitachi/tis/generic) \u306F\u7D44\u8FBC\u6E08\u3002");
  return lines.join("\n");
}
function buildInferenceBlock(result, input) {
  const lines = [];
  lines.push("\u3010Tenant DNA \u81EA\u52D5\u9069\u7528\u3011v2019.2");
  if (result.sier_profile) {
    lines.push(
      `- SIer: ${result.sier_profile.display_name_ja} (project_count=${result.sier_profile.meta.project_count})`
    );
  }
  if (result.customer_profile) {
    lines.push(
      `- \u9867\u5BA2: ${result.customer_profile.display_name}${result.customer_profile.industry_ja ? ` (${result.customer_profile.industry_ja})` : ""}`
    );
  }
  if (result.project_profile) {
    lines.push(`- \u30D7\u30ED\u30B8\u30A7\u30AF\u30C8: ${result.project_profile.display_name} (${result.project_profile.status})`);
  }
  if (result.active_naming_rules.length > 0) {
    const summary = result.active_naming_rules.map((r) => `${r.scope}=${r.case_style}${r.prefix ? `(${r.prefix})` : ""}`).slice(0, 6).join(" / ");
    lines.push(`- \u547D\u540D\u898F\u5247: ${summary}`);
  }
  if (result.active_blacklist.length > 0) {
    const banned = result.active_blacklist.slice(0, 8).map((b) => `${b.library_name}(${b.scope})`).join(", ");
    lines.push(`- \u63A1\u7528\u7981\u6B62\u30E9\u30A4\u30D6\u30E9\u30EA: ${banned}`);
  }
  if (result.recent_decisions.length > 0) {
    const top = result.recent_decisions.slice(0, 3).map((d) => `${d.category}: ${d.title}`).join(" / ");
    lines.push(`- \u76F4\u8FD1\u5224\u65AD: ${top}`);
  }
  if (result.related_patterns.length > 0) {
    const pat = result.related_patterns.slice(0, 3).map((p) => `${p.category}: ${p.pattern_summary} (occ=${p.occurrence_count}, succ=${(p.success_rate * 100).toFixed(0)}%)`).join(" / ");
    lines.push(`- \u6A2A\u65AD\u30D1\u30BF\u30FC\u30F3: ${pat}`);
  }
  if (result.recommended_stack && result.recommended_stack.length > 0) {
    lines.push(`- \u63A8\u5968\u30B9\u30BF\u30C3\u30AF: ${result.recommended_stack.join(" / ")}`);
  }
  if (input.workspace_dir) {
    lines.push(`- \u4F5C\u696D\u30C7\u30A3\u30EC\u30AF\u30C8\u30EA: ${input.workspace_dir}`);
  }
  if (result.warnings.length > 0) {
    lines.push(`- \u8B66\u544A: ${result.warnings.join(" / ")}`);
  }
  return lines.join("\n");
}
function buildAgentInjections(result, _input) {
  const out = [];
  if (result.active_naming_rules.length > 0) {
    out.push(
      `\u547D\u540D\u898F\u5247\u306F\u4EE5\u4E0B\u306B\u53B3\u5BC6\u6E96\u62E0\u3059\u308B\u3053\u3068: ${result.active_naming_rules.map((r) => `${r.scope}=${r.case_style}${r.prefix ? `(prefix=${r.prefix})` : ""}`).join(", ")}`
    );
  }
  if (result.active_blacklist.length > 0) {
    out.push(
      `\u4EE5\u4E0B\u306E\u30E9\u30A4\u30D6\u30E9\u30EA\u306F\u7D76\u5BFE\u306B\u63A1\u7528\u3057\u306A\u3044\u3053\u3068 (\u4EE3\u66FF\u3092\u63D0\u6848\u3059\u308B): ${result.active_blacklist.map((b) => `${b.library_name}${b.alternative_recommendation ? ` \u2192 \u4EE3\u66FF: ${b.alternative_recommendation}` : ""}`).join(", ")}`
    );
  }
  if (result.recent_decisions.length > 0) {
    out.push(
      `\u904E\u53BB\u306E\u6709\u52B9\u5224\u65AD\u3092\u5C0A\u91CD\u3059\u308B\u3053\u3068: ${result.recent_decisions.slice(0, 5).map((d) => `[${d.category}] ${d.title} \u2014 ${d.decision}`).join(" / ")}`
    );
  }
  if (result.related_patterns.length > 0) {
    out.push(
      `\u540CSIer\u5185\u306E\u6210\u529F\u30D1\u30BF\u30FC\u30F3\u3092\u63A1\u7528\u5019\u88DC\u306B\u542B\u3081\u308B\u3053\u3068: ${result.related_patterns.slice(0, 3).map((p) => p.recommendation_text).join(" / ")}`
    );
  }
  if (result.recommended_stack && result.recommended_stack.length > 0) {
    out.push(`\u63A8\u5968\u30B9\u30BF\u30C3\u30AF\u306F ${result.recommended_stack.join(", ")} \u3092\u7B2C\u4E00\u5019\u88DC\u3068\u3057\u3001\u5909\u66F4\u3059\u308B\u5834\u5408\u306F\u660E\u793A\u7684\u306A\u7406\u7531\u3092 docs/DESIGN_CONTRACT.md \u306B\u8A18\u8F09\u3059\u308B\u3053\u3068\u3002`);
  }
  return out;
}
function renderCustomerHandoffSection(sier_id, tenant_id, root = STORAGE_ROOT) {
  const m = snapshotCustomerMaterials(sier_id, tenant_id, root);
  const lines = [];
  lines.push(`## Tenant DNA \u30B5\u30DE\u30EA`);
  if (m.sier) lines.push(`- **SIer**: ${m.sier.display_name_ja}`);
  if (m.customer) lines.push(`- **\u9867\u5BA2**: ${m.customer.display_name}`);
  lines.push(`- **\u5224\u65AD\u8A18\u9332**: ${m.decisions.length} \u4EF6`);
  lines.push(`- **\u547D\u540D\u898F\u5247**: ${m.naming_rules.length} \u4EF6`);
  lines.push(`- **\u63A1\u7528\u7981\u6B62\u30E9\u30A4\u30D6\u30E9\u30EA**: ${m.blacklist.length} \u4EF6`);
  if (m.naming_rules.length > 0) {
    lines.push("");
    lines.push(`### \u547D\u540D\u898F\u5247`);
    for (const r of m.naming_rules) {
      lines.push(`- ${r.scope}: ${r.case_style}${r.prefix ? ` (\u63A5\u982D\u8F9E: ${r.prefix})` : ""} \u2014 ${r.rationale}`);
    }
  }
  if (m.blacklist.length > 0) {
    lines.push("");
    lines.push(`### \u63A1\u7528\u7981\u6B62\u30E9\u30A4\u30D6\u30E9\u30EA`);
    for (const b of m.blacklist) {
      lines.push(`- ${b.library_name} (${b.language}) \u2014 ${b.reason}${b.alternative_recommendation ? ` / \u4EE3\u66FF: ${b.alternative_recommendation}` : ""}`);
    }
  }
  return lines.join("\n");
}

// recall-entry.ts
var VALID_SIERS = [
  "nttdata",
  "fujitsu",
  "nri",
  "nomura",
  "nec",
  "hitachi",
  "tis",
  "generic"
];
function emit(obj) {
  process.stdout.write(JSON.stringify(obj) + "\n");
}
function buildInputFromEnv() {
  const rawSier = (process.env.TDNA_SIER ?? "").trim();
  const sier_id = VALID_SIERS.includes(rawSier) ? rawSier : void 0;
  const tenant_id = (process.env.TDNA_TENANT ?? "").trim() || void 0;
  const project_id = (process.env.TDNA_PROJECT ?? "").trim() || void 0;
  const hint = (process.env.TDNA_HINT ?? "").trim() || void 0;
  const workspace_dir = (process.env.TDNA_WORKSPACE ?? "").trim() || void 0;
  const detected_industry = (process.env.TDNA_INDUSTRY ?? "").trim() || void 0;
  const kw = (process.env.TDNA_KEYWORDS ?? "").trim();
  const detected_keywords = kw ? kw.split(",").map((s) => s.trim()).filter((s) => s.length > 0) : void 0;
  return {
    sier_id,
    tenant_id,
    project_id,
    hint,
    workspace_dir,
    detected_industry,
    detected_keywords
  };
}
function runRecall(rootOverride) {
  const input = buildInputFromEnv();
  const root = rootOverride ?? (process.env.TDNA_STORAGE_ROOT?.trim() || void 0);
  const out = root ? recallForBoost(input, root) : recallForBoost(input);
  let handoff_markdown = "";
  if (out.has_data && input.sier_id && input.tenant_id) {
    try {
      handoff_markdown = root ? renderCustomerHandoffSection(input.sier_id, input.tenant_id, root) : renderCustomerHandoffSection(input.sier_id, input.tenant_id);
    } catch {
      handoff_markdown = "";
    }
  }
  emit({
    ok: true,
    mode: "recall",
    has_data: out.has_data,
    inference_block_markdown: out.inference_block_markdown,
    injection_lines_for_agents: out.injection_lines_for_agents,
    handoff_markdown
  });
}
function runSelftest() {
  const failures = [];
  const tmpRoot = fs3.mkdtempSync(
    path3.join(os2.tmpdir(), "tdna-boost-selftest-")
  );
  try {
    const sier_id = "nttdata";
    const tenant_id = "selftest-co";
    registerSier({ sier_id }, tmpRoot);
    registerCustomer(
      {
        sier_id,
        tenant_id,
        display_name: "\u30BB\u30EB\u30D5\u30C6\u30B9\u30C8\u5546\u4E8B",
        industry_ja: "\u5EFA\u8A2D\u696D"
      },
      tmpRoot
    );
    defineNamingRule(
      {
        sier_id,
        tenant_id,
        scope: "db_table",
        case_style: "snake_case",
        prefix: "m_",
        rationale: "selftest: \u30C6\u30FC\u30D6\u30EB\u306F m_ \u63A5\u982D\u8F9E + snake_case"
      },
      tmpRoot
    );
    const out = recallForBoost({ sier_id, tenant_id }, tmpRoot);
    if (!out.has_data) {
      failures.push("has_data \u304C false (\u547D\u540D\u898F\u5247\u3092\u5165\u308C\u305F\u306E\u306B\u60F3\u8D77\u3055\u308C\u306A\u3044)");
    }
    const joined = out.injection_lines_for_agents.join("\n");
    if (!/snake_case/.test(joined)) {
      failures.push("\u6CE8\u5165\u6587\u306B\u547D\u540D\u898F\u5247(snake_case)\u304C\u53CD\u6620\u3055\u308C\u3066\u3044\u306A\u3044");
    }
    if (!/m_/.test(joined)) {
      failures.push("\u6CE8\u5165\u6587\u306B\u63A5\u982D\u8F9E(prefix=m_)\u304C\u53CD\u6620\u3055\u308C\u3066\u3044\u306A\u3044");
    }
    if (!out.inference_block_markdown.includes("Tenant DNA \u81EA\u52D5\u9069\u7528")) {
      failures.push("\u63A8\u8AD6\u30D6\u30ED\u30C3\u30AF\u306E\u30D8\u30C3\u30C0\u304C\u6B20\u843D");
    }
    const empty = recallForBoost({}, tmpRoot);
    if (empty.has_data) {
      failures.push("\u8B58\u5225\u5B50\u306A\u3057\u306A\u306E\u306B has_data=true (no-op \u306B\u306A\u3063\u3066\u3044\u306A\u3044)");
    }
    if (empty.injection_lines_for_agents.length !== 0) {
      failures.push("\u8B58\u5225\u5B50\u306A\u3057\u306A\u306E\u306B\u6CE8\u5165\u6587\u304C\u751F\u6210\u3055\u308C\u305F");
    }
  } catch (e) {
    failures.push("selftest \u5B9F\u884C\u4E2D\u306B\u4F8B\u5916: " + e.message);
  } finally {
    try {
      fs3.rmSync(tmpRoot, { recursive: true, force: true });
    } catch {
    }
  }
  emit({
    ok: failures.length === 0,
    mode: "selftest",
    failures
  });
  process.exit(failures.length === 0 ? 0 : 1);
}
function runSelftestHome() {
  const failures = [];
  if (process.env.TDNA_SELFTEST_ALLOW !== "1") {
    emit({
      ok: false,
      mode: "selftest-home",
      failures: ["TDNA_SELFTEST_ALLOW=1 \u304C\u672A\u8A2D\u5B9A (\u5B9F\u30C7\u30FC\u30BF\u6C5A\u67D3\u9632\u6B62\u306E\u305F\u3081\u62D2\u5426)"]
    });
    process.exit(1);
  }
  const learningRoot = path3.join(
    os2.homedir(),
    ".soloptilink",
    "learning",
    "tenants"
  );
  try {
    if (fs3.existsSync(learningRoot)) {
      const entries = fs3.readdirSync(learningRoot).filter((n) => n !== "auto_harvest" && !n.startsWith("."));
      if (entries.length > 0) {
        emit({
          ok: false,
          mode: "selftest-home",
          failures: [
            "HOME \u914D\u4E0B\u306B\u65E2\u5B58\u30C6\u30CA\u30F3\u30C8\u3092\u691C\u51FA: " + entries.join(",") + " (\u5B9F\u30C7\u30FC\u30BF\u6C5A\u67D3\u9632\u6B62\u306E\u305F\u3081\u62D2\u5426\u3002temp HOME \u3067\u5B9F\u884C\u3059\u308B\u3053\u3068)"
          ]
        });
        process.exit(1);
      }
    }
  } catch {
  }
  try {
    const sier_id = "nttdata";
    const tenant_id = "selftest-home-co";
    registerSier({ sier_id });
    registerCustomer({
      sier_id,
      tenant_id,
      display_name: "\u30BB\u30EB\u30D5\u30C6\u30B9\u30C8(HOME)\u5546\u4E8B"
    });
    defineNamingRule({
      sier_id,
      tenant_id,
      scope: "db_column",
      case_style: "snake_case",
      rationale: "selftest-home: \u30AB\u30E9\u30E0\u306F snake_case"
    });
    banLibrary(
      {
        tenant_id,
        library_name: "moment",
        language: "typescript",
        reason: "selftest-home: \u30D0\u30F3\u30C9\u30EB\u30B5\u30A4\u30BA\u904E\u5927",
        alternative_recommendation: "date-fns",
        scope: "customer"
      },
      sier_id
    );
    const out = recallForBoost({ sier_id, tenant_id });
    if (!out.has_data) failures.push("has_data \u304C false");
    const joined = out.injection_lines_for_agents.join("\n");
    if (!/snake_case/.test(joined)) {
      failures.push("\u6CE8\u5165\u6587\u306B\u547D\u540D\u898F\u5247\u304C\u53CD\u6620\u3055\u308C\u3066\u3044\u306A\u3044");
    }
    if (!/moment/.test(joined)) {
      failures.push("\u6CE8\u5165\u6587\u306B\u63A1\u7528\u7981\u6B62\u30E9\u30A4\u30D6\u30E9\u30EA(moment)\u304C\u53CD\u6620\u3055\u308C\u3066\u3044\u306A\u3044");
    }
    if (!/date-fns/.test(joined)) {
      failures.push("\u6CE8\u5165\u6587\u306B\u4EE3\u66FF\u63A8\u5968(date-fns)\u304C\u53CD\u6620\u3055\u308C\u3066\u3044\u306A\u3044");
    }
  } catch (e) {
    failures.push("selftest-home \u5B9F\u884C\u4E2D\u306B\u4F8B\u5916: " + e.message);
  }
  emit({
    ok: failures.length === 0,
    mode: "selftest-home",
    failures
  });
  process.exit(failures.length === 0 ? 0 : 1);
}
var arg = process.argv[2] ?? "";
if (arg === "--selftest") {
  runSelftest();
} else if (arg === "--selftest-home") {
  runSelftestHome();
} else {
  try {
    runRecall();
  } catch (e) {
    emit({
      ok: false,
      mode: "recall",
      has_data: false,
      inference_block_markdown: "",
      injection_lines_for_agents: [],
      handoff_markdown: "",
      error: e.message
    });
  }
}
