#!/usr/bin/env node
/**
 * Tenant DNA → BOOST 連携ブリッジ (純 node・外部依存ゼロ)
 * ============================================================================
 * BOOST Step 0.95 から呼ばれる唯一の窓口。
 *
 *  1. 顧客識別子 (sier_id / tenant_id / project_id) を優先順位で解決する。
 *  2. 同梱バンドル (tenant-dna-recall.bundle.mjs) のソース陳腐化を検知する。
 *  3. バンドルを bare node で実行し、推論ブロック + 注入文 + 引継ぎを得る。
 *  4. 成果物をファイルに書き出し、最終 JSON を stdout に出す。
 *
 * 設計原則:
 *  - 「絶対に BOOST 本流を止めない」。識別子なし / 学習データなし / 失敗時は
 *    すべて has_data=false の no-op として exit 0 で返す。
 *  - ロジックの真実源は tenant-dna の recallForBoost のみ (バンドル経由)。
 *    ブリッジは識別子解決と入出力の配線だけを担い、recall ロジックを写経しない。
 *
 * 識別子の解決順位 (上が優先):
 *   1. 環境変数 SOLOPTILINK_SIER / SOLOPTILINK_TENANT / SOLOPTILINK_PROJECT / SOLOPTILINK_HINT
 *   2. 作業ディレクトリの .soloptilink-tenant.json  { sier_id, tenant_id, project_id, hint }
 *   3. 自動検出: 学習データに SIer 1社 かつ 顧客 1社 だけ登録されている場合のみ採用
 *   4. いずれも無ければ no-op
 *
 * 使い方:
 *   node tenant-dna-bridge.mjs [--workspace <dir>] [--industry <s>] \
 *        [--keywords a,b,c] [--out <dir>] [--quiet]
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import * as os from 'node:os';
import * as crypto from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';

const HERE = path.dirname(fileURLToPath(import.meta.url));
const BUNDLE = path.join(HERE, 'tenant-dna-recall.bundle.mjs');
const META = path.join(HERE, 'tenant-dna-recall.bundle.meta.json');
const TDNA_LIB = path.resolve(HERE, '..', '..', 'soloptilink-tenant-dna', 'lib');
const LEARNING_ROOT = path.join(
  os.homedir(),
  '.soloptilink',
  'learning',
  'tenants'
);

const VALID_SIERS = [
  'nttdata',
  'fujitsu',
  'nri',
  'nomura',
  'nec',
  'hitachi',
  'tis',
  'generic',
];

// ---- 引数パース ----------------------------------------------------------
function parseArgs(argv) {
  const a = { workspace: process.cwd(), industry: '', keywords: '', out: '', quiet: false };
  for (let i = 2; i < argv.length; i++) {
    const k = argv[i];
    if (k === '--workspace') a.workspace = argv[++i] ?? a.workspace;
    else if (k === '--industry') a.industry = argv[++i] ?? '';
    else if (k === '--keywords') a.keywords = argv[++i] ?? '';
    else if (k === '--out') a.out = argv[++i] ?? '';
    else if (k === '--quiet') a.quiet = true;
  }
  if (!a.out) a.out = path.join(a.workspace, 'agent-evidence');
  return a;
}

// ---- no-op 結果 ----------------------------------------------------------
function noop(reason) {
  return {
    ok: true,
    wired: true,
    has_data: false,
    reason,
    identifiers: null,
    inference_block_markdown: '',
    injection_lines_for_agents: [],
    handoff_markdown: '',
    stale: false,
  };
}

// ---- 識別子解決 ----------------------------------------------------------
function normSier(v) {
  const s = (v ?? '').toString().trim();
  return VALID_SIERS.includes(s) ? s : '';
}

function fromEnv() {
  const sier = normSier(process.env.SOLOPTILINK_SIER);
  const tenant = (process.env.SOLOPTILINK_TENANT ?? '').trim();
  if (sier && tenant) {
    return {
      source: 'env',
      sier_id: sier,
      tenant_id: tenant,
      project_id: (process.env.SOLOPTILINK_PROJECT ?? '').trim() || undefined,
      hint: (process.env.SOLOPTILINK_HINT ?? '').trim() || undefined,
    };
  }
  return null;
}

function fromWorkspaceFile(workspace) {
  for (const name of ['.soloptilink-tenant.json', '.soloptilink/tenant.json']) {
    const p = path.join(workspace, name);
    try {
      if (!fs.existsSync(p)) continue;
      const j = JSON.parse(fs.readFileSync(p, 'utf-8'));
      const sier = normSier(j.sier_id);
      const tenant = (j.tenant_id ?? '').toString().trim();
      if (sier && tenant) {
        return {
          source: 'workspace-file:' + name,
          sier_id: sier,
          tenant_id: tenant,
          project_id: (j.project_id ?? '').toString().trim() || undefined,
          hint: (j.hint ?? '').toString().trim() || undefined,
        };
      }
    } catch {
      /* 壊れたファイルは無視して次へ */
    }
  }
  return null;
}

function fromAutoDetect() {
  try {
    if (!fs.existsSync(LEARNING_ROOT)) return null;
    const siers = fs
      .readdirSync(LEARNING_ROOT, { withFileTypes: true })
      .filter(
        (d) =>
          d.isDirectory() &&
          d.name !== 'auto_harvest' &&
          !d.name.startsWith('.') &&
          VALID_SIERS.includes(d.name)
      )
      .map((d) => d.name);
    if (siers.length !== 1) return null; // 0社 or 複数 → 曖昧なので自動採用しない
    const sier = siers[0];
    const custDir = path.join(LEARNING_ROOT, sier, 'customers');
    if (!fs.existsSync(custDir)) return null;
    const customers = fs
      .readdirSync(custDir, { withFileTypes: true })
      .filter((d) => d.isDirectory() && !d.name.startsWith('.'))
      .map((d) => d.name);
    if (customers.length !== 1) return null; // 顧客が0 or 複数 → 自動採用しない
    return {
      source: 'auto-detect',
      sier_id: sier,
      tenant_id: customers[0],
      project_id: undefined,
      hint: undefined,
    };
  } catch {
    return null;
  }
}

function resolveIdentifiers(workspace) {
  return fromEnv() || fromWorkspaceFile(workspace) || fromAutoDetect() || null;
}

// ---- 陳腐化検知 (bridge 側でソースハッシュ再計算) -------------------------
function computeSourceHash() {
  const files = [
    path.join(HERE, 'recall-entry.ts'),
    path.join(TDNA_LIB, 'index.ts'),
    path.join(TDNA_LIB, 'recall_engine.ts'),
    path.join(TDNA_LIB, 'memory_graph.ts'),
    path.join(TDNA_LIB, 'cross_project_synthesizer.ts'),
    path.join(TDNA_LIB, 'storage.ts'),
    path.join(TDNA_LIB, 'types.ts'),
    path.join(TDNA_LIB, 'tenant_profile.ts'),
    path.join(TDNA_LIB, 'naming_convention.ts'),
    path.join(TDNA_LIB, 'library_blacklist.ts'),
    path.join(TDNA_LIB, 'decision_memory.ts'),
  ];
  let combined = '';
  for (const f of files) {
    try {
      const h = crypto
        .createHash('sha256')
        .update(fs.readFileSync(f))
        .digest('hex');
      combined += `${h}  ${path.basename(f)}\n`;
    } catch {
      /* tenant-dna 未同梱環境ではスキップ (= 陳腐化判定不能) */
    }
  }
  return crypto.createHash('sha256').update(combined).digest('hex');
}

function checkStale() {
  try {
    if (!fs.existsSync(META)) return { stale: false, note: 'meta なし' };
    const meta = JSON.parse(fs.readFileSync(META, 'utf-8'));
    const cur = computeSourceHash();
    return {
      stale: meta.source_hash !== cur,
      note: meta.source_hash !== cur ? 'バンドルが陳腐化 (build-bundle.sh 再実行を推奨)' : 'fresh',
    };
  } catch {
    return { stale: false, note: 'meta 解析失敗' };
  }
}

// ---- バンドル実行 --------------------------------------------------------
function runBundle(ids, args) {
  const env = { ...process.env };
  env.TDNA_SIER = ids.sier_id;
  env.TDNA_TENANT = ids.tenant_id;
  if (ids.project_id) env.TDNA_PROJECT = ids.project_id;
  if (ids.hint) env.TDNA_HINT = ids.hint;
  if (args.industry) env.TDNA_INDUSTRY = args.industry;
  if (args.keywords) env.TDNA_KEYWORDS = args.keywords;
  if (args.workspace) env.TDNA_WORKSPACE = args.workspace;

  const r = spawnSync(process.execPath, [BUNDLE], {
    env,
    encoding: 'utf-8',
    timeout: 20000,
  });
  if (r.status !== 0 || !r.stdout) {
    throw new Error(
      'バンドル実行失敗: ' + (r.stderr || r.error?.message || 'unknown')
    );
  }
  const line = r.stdout.trim().split('\n').filter(Boolean).pop();
  return JSON.parse(line);
}

// ---- 過去の判断 (相棒化 P2 / decisions.jsonl) ------------------------------
// 「同じ議論を二度しない」ための想起。人が答えた判断 (採用/不採用/修正) だけを
// 過去判断として配る。★応答待ち (pending) は配らない — 黙認を「決めたこと」として
// 次回に配ると、誰も決めていない前提が既成事実になる。
function readDecisions(workspace) {
  const out = [];
  try {
    const p = path.join(workspace, '.soloptilink', 'decisions.jsonl');
    const raw = fs.readFileSync(p, 'utf-8');
    for (const line of raw.split('\n')) {
      const t = line.trim();
      if (!t) continue;
      let o;
      try { o = JSON.parse(t); } catch { continue; }
      if (!o || typeof o !== 'object') continue;
      const r = o.human_response;
      if (r !== 'adopted' && r !== 'rejected' && r !== 'modified') continue;
      out.push(o);
    }
  } catch { /* 記録が無いのは正常 */ }
  return out.slice(-20);
}

function decisionLines(decisions) {
  const JA = { adopted: '採用', rejected: '不採用', modified: '修正' };
  return decisions.map((o) => {
    const why = o.why ? `（理由: ${o.why}）` : '';
    return `過去判断: 「${o.topic}」は「${o.chosen}」で${JA[o.human_response]}${why}。覆すときは理由を所見に書くこと。`;
  });
}

// ---- 成果物書き出し ------------------------------------------------------
function writeArtifacts(outDir, ids, recall, stale, decisions) {
  try {
    fs.mkdirSync(outDir, { recursive: true });
    const dec = decisions || [];
    const JA = { adopted: '採用', rejected: '不採用', modified: '修正' };
    const md = [
      '<!-- AUTO-GENERATED by tenant-dna-bridge (BOOST Step 0.95) -->',
      '# Tenant DNA 自動適用レポート',
      '',
      `- SIer: ${ids ? ids.sier_id : '(未指定)'}`,
      `- 顧客: ${ids ? ids.tenant_id : '(未指定)'}`,
      ids && ids.project_id ? `- プロジェクト: ${ids.project_id}` : '',
      ids ? `- 解決元: ${ids.source}` : '',
      stale && stale.stale ? `- ⚠ ${stale.note}` : '',
      '',
      '## 推論ブロック',
      '',
      recall.inference_block_markdown || '(なし)',
      '',
      '## 全エージェントへの注入命令',
      '',
      ...(recall.injection_lines_for_agents.length
        ? recall.injection_lines_for_agents.map((l) => `- ${l}`)
        : ['(なし)']),
      '',
      '## 過去の判断（この案件で決めたこと）',
      '',
      ...(dec.length
        ? dec.map((o) => `- 「${o.topic}」→「${o.chosen}」で${JA[o.human_response]}${o.why ? `（理由: ${o.why}）` : ''}`)
        : ['(まだ人が答えた判断はありません)']),
      '',
      recall.handoff_markdown ? '## 引継ぎ用サマリ\n\n' + recall.handoff_markdown : '',
      '',
    ]
      .filter((l) => l !== '')
      .join('\n');
    fs.writeFileSync(path.join(outDir, 'tenant-dna-recall.md'), md, 'utf-8');
  } catch {
    /* 書き出し失敗は致命ではない */
  }
}

// ---- main ---------------------------------------------------------------
function main() {
  const args = parseArgs(process.argv);

  let result;
  // 過去判断は顧客識別子に依存しない (案件フォルダに閉じた記録) ため先に読む
  const decisions = readDecisions(args.workspace);
  const dlines = decisionLines(decisions);
  const ids = resolveIdentifiers(args.workspace);
  if (!ids) {
    result = noop('顧客識別子が解決できません (env/.soloptilink-tenant.json/自動検出いずれも該当なし)');
  } else {
    const stale = checkStale();
    try {
      const recall = runBundle(ids, args);
      result = {
        ok: recall.ok !== false,
        wired: true,
        has_data: Boolean(recall.has_data),
        reason: recall.has_data ? '想起成功' : '識別子は解決したが学習データが空',
        identifiers: ids,
        inference_block_markdown: recall.inference_block_markdown || '',
        injection_lines_for_agents: recall.injection_lines_for_agents || [],
        handoff_markdown: recall.handoff_markdown || '',
        stale: stale.stale,
        stale_note: stale.note,
      };
      // 学習データが空でも、過去判断があれば想起として書き出す
      if (result.has_data || decisions.length) {
        writeArtifacts(args.out, ids, recall, stale, decisions);
      }
    } catch (e) {
      result = noop('バンドル実行で例外: ' + e.message);
      result.identifiers = ids;
    }
  }

  // 過去判断を全ロールへの注入文へ合流させる (E-1 記憶 / B-5 判断の持ち越し)
  if (dlines.length) {
    result.injection_lines_for_agents = (result.injection_lines_for_agents || []).concat(dlines);
    result.decisions_recalled = decisions.length;
    if (!result.has_data) {
      // 学習データが無くても「過去判断は想起できた」ことを正直に示す
      result.reason = (result.reason || '') + ' / 過去判断 ' + decisions.length + ' 件を想起';
      if (!ids) writeArtifacts(args.out, null, { inference_block_markdown: '', injection_lines_for_agents: [], handoff_markdown: '' }, { stale: false }, decisions);
    }
  } else {
    result.decisions_recalled = 0;
  }

  process.stdout.write(JSON.stringify(result) + '\n');
  // BOOST 本流を止めないため、常に exit 0。
  process.exit(0);
}

main();
