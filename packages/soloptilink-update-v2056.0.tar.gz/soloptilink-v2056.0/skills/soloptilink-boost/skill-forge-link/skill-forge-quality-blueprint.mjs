#!/usr/bin/env node
/**
 * Skill Forge Quality Blueprint (SoT)
 * ============================================================================
 * SoloptiLinkAI スキル (Claude Code Skill / .claude/skills 配下 SKILL.md) の
 * 「品質最大化教典」の単一真実源。skill-forge-bridge と skill-forge-gate.sh の
 * 両方がここを参照する (二重実装ドリフト防止)。
 *
 * 内包する知識:
 *  1. 必須 frontmatter フィールド (name / description / allowed-tools)
 *  2. description 品質基準 (トリガー語明示/300字上限/フィラー禁止)
 *  3. 構造チェックリスト (言語ポリシー/顧客可視ポリシー/Step 0/selftest 章)
 *  4. 禁止パターン (frontmatter 破損/英語ナレーション常用/内部用語顧客露出)
 *  5. 検出パターン (何をもって「スキル作成依頼」と判定するか)
 *  6. 105ロールへの注入本文 (Silent Inference で構造化される品質指示)
 *
 * 使い方:
 *  - CommonJS/ESM 両対応で export される
 *  - skill-forge-bridge.mjs が dynamic import して inference/injection を組み立てる
 *  - skill-forge-gate.sh は同ロジックを bash 実装 (規範一致・SoT はここ)
 */

// ============================================================================
// 検出パターン (スキル作成依頼の判定)
// ============================================================================

/**
 * Claude Code スキル生成の「強シグナル」(単独 1 件で detected=true).
 * これらは Claude Code 固有の名詞 (SKILL.md / .claude/ / soloptilink-*) と生成動詞の共起、
 * または明示的な文脈語込みのみを含める.
 */
export const SKILL_CREATE_STRONG_TRIGGERS = [
  // Claude Code 固有識別子 + 空白許容 + 生成動詞
  /(?:SKILL\.md|\.claude\/skills\/|soloptilink-[a-z][\w-]*)\s*(?:を|の)?\s*(?:作|創|開発|新規|新設|追加|拡張|強化|生成)/i,
  /(?:作|生成|開発|新規|追加)[^\n]{0,30}SKILL\.md/i,
  /\/soloptilink-[\w-]+\s*(?:を|の)?\s*(?:作|開発|新規|追加|生成)/,
  /(?:新しい|新規|カスタム)\s*(?:Claude(?:\s*Code)?|SoloptiLink|オープンクロー)\s*(?:スキル|フック|MCP|エージェント|プラグイン|スラッシュコマンド)/i,
  /(?:Claude(?:\s*Code)?|\.claude|SKILL\.md)[^\n]{0,20}スラッシュコマンド|スラッシュコマンド[^\n]{0,20}(?:Claude(?:\s*Code)?|\.claude|SKILL\.md|カスタムコマンド)/i,
  /(?:高品質|最高品質|プロダクション品質)[^\n]{0,20}(?:Claude(?:\s*Code)?|SoloptiLink)?\s*スキル/,
  /(?:スキル.*クオリティ|クオリティ.*スキル)[^\n]{0,20}(?:最大|向上|上げ)/,
  /create.*(?:new|custom)?\s*(?:Claude\s*Code\s*)?skill/i,
  /(?:new|custom)\s*Claude\s*Code\s*skill\b/i,
];

/**
 * Claude Code スキル生成の「弱シグナル」(単独では detected=false・文脈語 anchor と共起が必要).
 * 「スキルを作る」等の一般語は HR / 教育業種で頻出のため、二段検出で防衛する.
 */
export const SKILL_CREATE_WEAK_TRIGGERS = [
  /スキル(?:を|の)?(?:作|創|開発|新規|新設|追加|拡張|強化|生成)/,
  /スキル(?:作成|開発|生成|強化)/,
  /(?:新しい|新規)\s*スキル/,
  /スラッシュコマンド(?:を|の)?(?:作|開発|新規|追加)/,
  /skill.*(?:development|creation|scaffolding)/i,
  /custom\s+skill/i,
];

/** 弱シグナルを confirm する文脈 anchor (どれか 1 つでもあれば弱シグナル確定) */
export const SKILL_CONTEXT_ANCHORS = [
  // Claude Code 固有 (最高信頼度)
  /SKILL\.md/,
  /\.claude\/(?:skills|agents|commands|plugins)\//,
  /soloptilink-[a-z][\w-]*/,
  /frontmatter/i,
  /allowed-tools/,
  /argument-hint/,
  /(?:Claude\s*Code|Claude\s*Agent\s*SDK|オープンクロー|Open\s*Claude)/i,
  /(?:MCP)\s*(?:server|サーバー|クライアント|inspector)/i,
  /Anthropic\s*(?:SDK|API|Messages)/i,
  /(?:hook|フック).*(?:SessionStart|PostToolUse|UserPromptSubmit|PreToolUse|SessionEnd|PreCompact|Stop|Notification|SubagentStop)/i,
  // ドメイン特化語 (建設図面/API 連携/SDK 系) — これらとスキル生成弱シグナル共起で検出
  /建築図面|建設図面|意匠図|構造図|設備図|平面図|立面図|断面図|矩計図|配置図|JIS\s*[A-Z]?\s*\d{3,}|SXF|construction-drawing-specialist/,
  /施工管理|工事写真|現場写真|構造計算|積算|工程表|安全書類|躯体図|配筋図/,
  /API\s*連携|IBL|connector[- ]?forge|IBL\s*コネクタ|Salesforce\s*(?:API|連携)|Slack\s*(?:API|Bot|Webhook)|freee\s*(?:API|連携)|Anthropic\s*API/i,
  /(?:tool_use|tool_choice|input_schema|structured\s*output)/,
  /(?:RAG|Retrieval|embedding|vector\s*DB|prompt[- ]?caching|batch\s*API|extended\s*thinking)/i,
  /(?:webhook|Webhook|HMAC.*(?:signature|署名)|Idempotency-Key)/,
  /(?:サブエージェント|slash\s*command|カスタム\s*スラッシュ|独自\s*(?:スキル|エージェント|MCP|フック))/i,
];

/** 既存参照名 (後方互換用): 強+弱 の連結 */
export const SKILL_CREATE_TRIGGERS = [...SKILL_CREATE_STRONG_TRIGGERS, ...SKILL_CREATE_WEAK_TRIGGERS];

/**
 * スキル作成でない業種システム標準機能 / スキル利用 / 明示除外の陰性パターン.
 * HR / 教育 / SIer / 建設業の業種システムでは「スキル管理」「スキル台帳」「スキル評価」等が
 * 業種標準機能名として頻出するため、これらを明示除外して false positive を防ぐ.
 */
export const SKILL_NEGATIVE_PATTERNS = [
  // 単純利用 (Claude Code スキルを使う意図)
  /スキル(?:を)?実行/,
  /スキル(?:を)?使/,
  /スキル(?:の)?説明/,
  /スキル(?:を)?起動/,
  /スキル一覧/,
  // HR / 人材業種の業種標準機能名 (「スキル + 管理系名詞」)
  /スキル(?:マップ|評価|台帳|管理|情報|セット|保有|習得|認定|向上|アップ|階層|カテゴリ|レベル|体系|開発ロードマップ|データベース|マスタ|シート|ラベル|バッジ|ツリー|グラフ|チャート)/,
  // HR 主語 + スキル
  /(?:従業員|社員|スタッフ|新人|エンジニア|人材|受講者|研修生|営業|技術者|職員|メンバー|チーム|部下|新卒|中途|派遣)[^\n]{0,20}スキル/,
  // スキル + HR 業務動詞
  /スキル[^\n]{0,20}(?:研修|育成|教育|人事|評価制度|昇格|昇進|等級|給与|査定|1on1|考課|キャリア|離職|定着)/,
  // 一般スキル区分名
  /(?:営業|技術|マネジメント|コミュニケーション|プログラミング|ヒューマン|ビジネス|語学|専門)スキル/,
];

// ============================================================================
// スキル品質基準 (frontmatter / 構造 / doctrine)
// ============================================================================

/** frontmatter 必須フィールド */
export const REQUIRED_FRONTMATTER_FIELDS = ["name", "description"];

/** frontmatter 推奨フィールド (無くても FAIL ではないが減点) */
export const RECOMMENDED_FRONTMATTER_FIELDS = ["argument-hint", "allowed-tools"];

/** description の品質基準 */
export const DESCRIPTION_QUALITY_RULES = {
  min_length: 30,       // 30字未満 → 説明不足
  max_length: 400,      // 400字超え → 冗長
  ideal_range: [80, 250], // 80-250字が理想
  must_contain_triggers: true, // 「〜等で起動」型のトリガー語必須
  forbidden_fillers: [
    /^このスキルは.*(?:役立|便利|素晴らしい|素敵|最高)/,
    /^あなたを.*(?:サポート|お手伝い|支援)します$/,
    /^AIが.*(?:自動で|勝手に|なんとかして)/,
    /helps you\b/i,
    /this skill (?:will |can )?(?:help|assist|make|allow)/i,
  ],
};

/** SKILL.md 構造チェックリスト (含まれるべき章/文言) */
export const SKILL_MD_STRUCTURE = [
  {
    key: "frontmatter_valid",
    description: "frontmatter (---で囲まれた) が先頭に存在し name/description を含む",
    weight: 25,
    critical: true,
  },
  {
    key: "language_policy_declared",
    description: "言語ポリシー (日本語応答/英語ナレーション禁止) を明示している",
    weight: 15,
    hint: "「言語ポリシー」「日本語で応答」「CLAUDE.md.*準拠」等の記述",
  },
  {
    key: "customer_visible_policy_declared",
    description: "顧客可視出力ポリシー (機械言語を地の文に貼らない) を明示している",
    weight: 15,
    hint: "「顧客可視」「機械言語」「地の文」「タグを貼らない」等の記述",
  },
  {
    key: "step0_or_precondition",
    description: "Step 0 相当の前提チェック (認証/依存/引数解析) が明示されている",
    weight: 10,
    hint: "「Step 0」「端末認証」「前提」「起動条件」等の見出し",
  },
  {
    key: "clear_steps_or_flow",
    description: "スキル本体のステップ/フローが番号付きまたは見出しで明示されている",
    weight: 10,
    hint: "「Step 1」「## 1.」「## 手順」等",
  },
  {
    key: "kill_switch_or_graceful_skip",
    description: "kill-switch (環境変数 off) か no-op 素通り条件を明示している",
    weight: 10,
    hint: "「kill-switch」「no-op」「素通り」「ENABLE_.*=off」等",
  },
  {
    key: "selftest_or_verify_reference",
    description: "selftest または verify スクリプトへの言及がある (born-passing 担保)",
    weight: 10,
    hint: "「selftest」「verify」「born-passing」「回帰ゲート」等",
  },
  {
    key: "trade_secret_or_scope_boundary",
    description: "スキルの担当範囲 (何をやり/何をやらないか) が明示されている",
    weight: 5,
    hint: "「担当範囲」「役割」「範囲外」「他スキル」等の記述",
  },
];

/** 禁止パターン (見つかったら FAIL/BLOCK) */
export const FORBIDDEN_PATTERNS = [
  {
    key: "duplicate_frontmatter",
    description: "frontmatter (---) ブロックが 2 個以上ある (Claude Code が読めない)",
    severity: "BLOCK",
    detect: (text) => (text.match(/^---\s*$/gm) || []).length > 2,
  },
  {
    key: "english_only_narration",
    description: "冒頭に I'll help / Let me / Now I'll 等の英語ナレーションが並ぶ",
    severity: "FAIL",
    detect: (text) => /^#[^\n]*\n\s*(?:I'll|Let me|Now I'll|Here's|I will)/im.test(text),
  },
  {
    key: "missing_name",
    description: "frontmatter に name フィールドが無い",
    severity: "BLOCK",
    detect: (text) => {
      const m = text.match(/^---\s*\n([\s\S]*?)\n---\s*$/m);
      return m ? !/^name\s*:/m.test(m[1]) : true;
    },
  },
  {
    key: "missing_description",
    description: "frontmatter に description フィールドが無い",
    severity: "BLOCK",
    detect: (text) => {
      const m = text.match(/^---\s*\n([\s\S]*?)\n---\s*$/m);
      return m ? !/^description\s*:/m.test(m[1]) : true;
    },
  },
  {
    key: "raw_credentials_in_body",
    description: "本文に生の API キー/パスワード/トークンが記載されている",
    severity: "BLOCK",
    detect: (text) => /(?:sk-[A-Za-z0-9]{20,}|xoxb-[A-Za-z0-9-]{20,}|ghp_[A-Za-z0-9]{20,})/.test(text),
  },
];

// ============================================================================
// 105ロールへの注入本文 (Silent Inference 出力)
// ============================================================================

/**
 * 品質最大化のためにビルドの全ロールへ届ける指示文.
 * Step 2.A の plan が task テキストを各ロール prompt に構造注入するため、
 * これらの1行が全105ロールへ波及する.
 */
export function buildInjectionLines(context) {
  const { skillNameHint, targetDirHint } = context;
  const lines = [];

  // 生成ゴールの明示
  lines.push(
    `【スキル生成モード】あなたは今、Claude Code の SKILL.md ${
      skillNameHint ? `(候補名: ${skillNameHint})` : ""
    } を作成する任務を持つ。単なるドキュメントではなく Claude が自動起動するトリガー付きプロンプトを設計する.`
  );

  // 保存先
  if (targetDirHint) {
    lines.push(`【保存先】${targetDirHint}/SKILL.md を第一成果物とする (絶対に別パスへ書かない).`);
  } else {
    lines.push(
      "【保存先】~/.claude/skills/<kebab-case-slug>/SKILL.md を第一成果物とする. ディレクトリ名 = frontmatter の name と完全一致."
    );
  }

  // frontmatter 契約
  lines.push(
    "【frontmatter 契約】必ず --- で囲み name (kebab-case・ディレクトリ名と一致) と description (日本語・80-250字・冒頭にトリガー語) を含める. 推奨: argument-hint / allowed-tools."
  );

  // description 品質
  lines.push(
    "【description 品質】冒頭に「〜等で起動」型でトリガー語を列挙 (例: 「「Xを作」「Yして」等で起動。〜する〜スキル.」). 冗長なフィラー (「便利」「素晴らしい」「helps you」等) 禁止."
  );

  // 言語/顧客可視ポリシー (グローバル準拠)
  lines.push(
    "【言語ポリシー】応答・進捗・確認・完了はすべて日本語. 英語ナレーション (I'll / Let me / Done 等) 禁止. コード識別子は英語のまま許容."
  );
  lines.push(
    "【顧客可視ポリシー】お客さんが読む地の文に bash・生ログ・生 JSON・<invoke> 等のタグを貼らない. 技術作業はツールで実行し日本語自然文にだけ要約."
  );

  // Step 0 パターン
  lines.push(
    "【Step 0 前提チェック】スキル本体の前に「Step 0」の見出しで前提条件 (端末認証/引数解析/対象ファイル存在) を明示的にチェック. UNAUTHORIZED や前提未達なら中止."
  );

  // kill-switch
  lines.push(
    "【kill-switch/no-op 素通り】環境変数 (ENABLE_<機能>=off) で無効化できる形にし、入力空/前提未達/失敗は例外を投げず no-op 素通り (BOOST 本流を止めない)."
  );

  // selftest
  lines.push(
    "【selftest/verify】スキル動作を検証する selftest コマンド or verify スクリプトを併設し、SKILL.md 内で参照. born-passing (最初から通る) 状態で提出."
  );

  // Trade Secret Watermark
  lines.push(
    "【PFP-082 Watermark】生成する主要ファイル (bridge/verify/gate/README) の先頭に SoloptiLink Trade Secret ヘッダを注入 (BOOST 本体と同じテンプレ)."
  );

  // 既存 skill との整合
  lines.push(
    "【既存 soloptilink-* との整合】命名は soloptilink-<機能> 系. 既に近い機能を持つスキル (hearing/executive/japan/tenant-dna/blueprint/rfp/handoff 等) との重複回避 or 明確な役割分担を README に記載."
  );

  // 検証手順の同梱
  lines.push(
    "【検証セクション】SKILL.md 末尾または verify スクリプトで「発行直後にこのスキル自身が SoT 品質ゲート (skill-forge-gate.sh) を通過することを実測」を担保."
  );

  // ドメイン特化 (検出された場合のみ上乗せ)
  if (context && Array.isArray(context.detected_domains) && context.detected_domains.length > 0) {
    const domainLines = buildDomainInjectionLines(context.detected_domains);
    if (domainLines.length > 0) {
      lines.push(""); // 見出しの前に空行
      for (const dl of domainLines) lines.push(dl);
    }
  }

  return lines;
}

/**
 * 顧客可視の推論ブロック (Markdown).
 * $PROJECT_DIR/agent-evidence/skill-forge-recall.md に保存され、設計入力として温存される.
 */
export function buildInferenceMarkdown(context) {
  const lines = buildInjectionLines(context);
  const md = [
    "## Skill Forge 自動適用レポート",
    "",
    "SoloptiLinkAI BOOST がスキル作成依頼を検知しました. 以下の品質基準を全ロールに適用します:",
    "",
    ...lines.map((l) => `- ${l}`),
    "",
    "### 適用される品質ゲート",
    "",
    "- `skill-forge-gate.sh` — frontmatter/構造/禁止パターンを静的検証 (BLOCK/FAIL/WARN 3段階)",
    "- description のトリガー精度・字数を実測",
    "- 言語ポリシー / 顧客可視ポリシー / Step 0 / kill-switch / selftest の宣言有無を採点",
    "",
  ].join("\n");
  return md;
}

// ============================================================================
// 検出エントリ (bridge から呼ばれる)
// ============================================================================

/**
 * NFKC 正規化 (全角記号→半角) + 空白正規化.
 * 日本語 IME で発生する全角スペース/全角スラッシュ/全角ダッシュ等でパターンが漏れることを防ぐ.
 */
export function normalizeTaskText(taskText) {
  if (!taskText || typeof taskText !== "string") return "";
  return taskText.normalize("NFKC").replace(/[\s　]+/g, " ");
}

/**
 * タスク文からスキル作成意図を判定 (2 段検出).
 *
 * 判定ロジック:
 *  1. 陰性が陽性より多ければ即座に detected=false (業種システム標準機能名の優先)
 *  2. 強シグナル (SKILL_CREATE_STRONG_TRIGGERS) が 1 つでもヒット → detected=true
 *  3. 弱シグナルのみヒットの場合 → 文脈 anchor (SKILL_CONTEXT_ANCHORS) が 1 つでも共起で detected=true
 *  4. 弱シグナルのみで anchor 無し → detected=false (HR 業種等の false positive を根絶)
 */
export function detectSkillCreationIntent(taskText) {
  if (!taskText || typeof taskText !== "string" || taskText.trim().length === 0) {
    return { detected: false, reason: "task 空", positive_hits: [], negative_hits: [], strong: false, has_anchor: false };
  }
  const normalized = normalizeTaskText(taskText);
  const strong_hits = [];
  const weak_hits = [];
  const negative_hits = [];
  const anchor_hits = [];
  for (const pat of SKILL_CREATE_STRONG_TRIGGERS) {
    const m = normalized.match(pat);
    if (m) strong_hits.push({ pattern: pat.source, snippet: m[0] });
  }
  for (const pat of SKILL_CREATE_WEAK_TRIGGERS) {
    const m = normalized.match(pat);
    if (m) weak_hits.push({ pattern: pat.source, snippet: m[0] });
  }
  for (const pat of SKILL_NEGATIVE_PATTERNS) {
    const m = normalized.match(pat);
    if (m) negative_hits.push({ pattern: pat.source, snippet: m[0] });
  }
  for (const pat of SKILL_CONTEXT_ANCHORS) {
    const m = normalized.match(pat);
    if (m) anchor_hits.push({ pattern: pat.source, snippet: m[0] });
  }

  const positive_hits = [...strong_hits, ...weak_hits]; // 後方互換

  // 陰性が優勢 (>= 陽性) なら即座に業種システム扱い
  if (negative_hits.length > 0 && negative_hits.length >= positive_hits.length) {
    return {
      detected: false,
      reason: `業種システム標準機能名を検出 (陰性 ${negative_hits.length} 件優勢)`,
      positive_hits, negative_hits, strong: false, has_anchor: anchor_hits.length > 0,
    };
  }

  // 強シグナル 1 件以上 → 即 detect
  if (strong_hits.length > 0) {
    return {
      detected: true,
      reason: `Claude Code 固有スキル生成シグナル ${strong_hits.length} 件検出`,
      positive_hits, negative_hits, strong: true, has_anchor: anchor_hits.length > 0,
    };
  }

  // 弱シグナル + anchor 共起 → detect
  if (weak_hits.length > 0 && anchor_hits.length > 0) {
    return {
      detected: true,
      reason: `弱シグナル ${weak_hits.length} 件 + 文脈 anchor ${anchor_hits.length} 件共起`,
      positive_hits, negative_hits, strong: false, has_anchor: true,
    };
  }

  // 弱シグナルのみ + anchor 無し → 業種システム扱い (false positive 根絶)
  if (weak_hits.length > 0) {
    return {
      detected: false,
      reason: `弱シグナルのみ ${weak_hits.length} 件・文脈 anchor 無し (業種システム扱い)`,
      positive_hits, negative_hits, strong: false, has_anchor: false,
    };
  }

  return {
    detected: false,
    reason: "スキル作成トリガー未ヒット",
    positive_hits, negative_hits, strong: false, has_anchor: false,
  };
}

/**
 * タスク文からスキル名候補と保存先を推定 (Silent Inference).
 * 例: "顧客サポート用のスキルを作って" → { skillNameHint: "soloptilink-customer-support", targetDirHint: "~/.claude/skills/soloptilink-customer-support" }
 */
export function inferSkillNameAndTarget(taskText) {
  const t = String(taskText || "");
  // 明示的な soloptilink-xxx 名指し
  const m1 = t.match(/soloptilink-([a-z][a-z0-9-]{1,40})/i);
  if (m1) {
    const name = "soloptilink-" + m1[1].toLowerCase();
    return { skillNameHint: name, targetDirHint: `~/.claude/skills/${name}` };
  }
  // "「XX スキル」" 型
  const m2 = t.match(/「([^」]{2,20})」\s*スキル/);
  if (m2) {
    // 日本語→ローマ字化は困難なため、識別子は Refiner フェーズで決めさせる
    return { skillNameHint: `soloptilink-<${m2[1]}>`, targetDirHint: "" };
  }
  return { skillNameHint: "", targetDirHint: "" };
}

// ============================================================================
// ドメイン特化教典 (3 ドメインの深い品質最大化知識)
// ============================================================================
// 用途: skill 生成依頼が特定ドメイン (建設図面 / Claude Code SDK / API-エージェント制御)
//       に該当した場合、汎用注入行に上乗せしてドメイン専用の実装指示を全ロールへ届ける.
//       研究フェーズ (parallel(construction / claude-code-sdk / api-agent-control)) の
//       深掘り成果 (14〜15 検出パターン・10 注入行・7〜9 品質軸) を SoT として温存.
// ============================================================================

/**
 * ドメイン別定義 (研究成果の SoT 化).
 * 順序: detectSkillDomains でクロスドメインドリフト解消 (SDK が MCP/SKILL.md 共起で優先) を後段で実施.
 */
export const SKILL_DOMAINS = [
  {
    key: "construction_drawing",
    name_ja: "建設・建築図面",
    example_skill_name: "soloptilink-construction-drawing",
    detection_patterns: [
      /建築図面|建設図面|意匠図|構造図|設備図/,
      /平面図|立面図|断面図|矩計図|展開図|配置図|詳細図/,
      /仕上表|建具表|図面リスト|表題欄|図枠/,
      /JIS\s*Z\s*8114|JIS\s*A\s*0150|建築製図通則|製図規格/,
      /SVG.*図面|\bDXF\b|\bDWG\b|\bIFC\b|\bBIM\b|CAD\s*(?:出力|入力|交換|データ)/,
      /通り芯|真北|磁北|\bGL\b|\bFL\b|\bCH\b|基準線|レベル基準/,
      /尺度|縮尺|1\/(?:50|100|200|20|10|500)/,
      /確認申請図|竣工図|施工図|実施設計図|基本設計図/,
      /建築士法|建築基準法|建設業法.*図面|図面保存義務/,
      /線種|線太さ|ハッチング|寸法記入|寸法補助線/,
      /レイヤ.*(?:壁|柱|建具|通り芯|寸法)|CAD.*レイヤ規約|SXF.*(?:レイヤ|準拠)/,
      /用紙.*(?:A0|A1|A2|A3)|建築図面.*サイズ/,
      /construction-drawing-specialist|建築図面.*スキル|図面.*スキル.*(?:作|開発)/,
      /工事台帳.*図面|物件.*図面管理|図面.*台帳/,
      // 建設業実務の主要業務 (施工管理・現場写真・構造計算・積算・工程表・安全書類 等)
      /施工管理|施工体制台帳|工事管理|現場管理|工程管理|安全管理|品質管理/,
      /現場写真|工事写真|写真台帳|黒板電子化|SITEBOX|フォトマネージャ/,
      /構造計算|一貫構造計算|SS7|BUS-6|構造適判|構造適合性判定/,
      /積算|概算積算|数量拾い|見積書|工事見積|材料拾い|歩掛/,
      /工程表|バーチャート|ネットワーク工程|クリティカルパス|工事日報/,
      /安全書類|グリーンサイト|作業員名簿|新規入場者|KY活動|安全衛生|健康管理/,
      /躯体図|配筋図|型枠加工図|杭伏図|基礎伏図|床伏図|軸組図/,
      /建設DX|土木施工|土量計算|土工|盛土|切土|舗装/,
      /電気設備図|給排水衛生設備図|空調換気設備図|防災設備図/,
      // === 建設強化パッチ (追加 detection patterns) ===
      /建築士法|一級建築士|二級建築士|木造建築士|管理建築士|建築士事務所登録/,
      /建築基準法|建基法|確認申請|確認済証|検査済証|中間検査|完了検査|建築主事|指定確認検査機関/,
      /構造計算適合性判定|適判|ルート1|ルート2|ルート3|保有水平耐力|限界耐力計算|時刻歴応答解析/,
      /建設業法|建設業許可|一般建設業|特定建設業|経営事項審査|経審|CCUS|建設キャリアアップシステム/,
      /主任技術者|監理技術者|専任技術者|技術者資格|1級施工管理技士|2級施工管理技士/,
      // 下請法・下請代金支払遅延等防止法は業界横断語のため単独では建設判定しない (製造業/物流業等でも該当).
      // 建設固有の 一括下請負・丸投げ禁止・下請取引 (現場文脈) と、支払遅延・買いたたき (下請関連の実務用語) のみ強シグナルに残す.
      /一括下請負|丸投げ禁止|支払遅延|買いたたき/,
      /下請取引.*(?:建設|建築|工事|現場)|下請取引\s*(?:管理|台帳)/,
      /省エネ法|建築物省エネ法|BEI|一次エネルギー|外皮性能|UA値|ηAC値|BELS|ZEB|ZEH|適合性判定|説明義務制度/,
      /都市計画法|開発許可|用途地域|準工業地域|第一種低層住居専用地域|市街化区域|市街化調整区域|地区計画/,
      /耐震改修促進法|耐震診断|耐震補強|Is値|要緊急安全確認|特定既存耐震不適格|旧耐震|新耐震/,
      /バリアフリー法|ハートビル法|移動等円滑化|特別特定建築物|建築物移動等円滑化基準|認定建築物/,
      /建設リサイクル法|分別解体|特定建設資材|再資源化|事前届出|廃棄物処理法|マニフェスト/,
      /品確法|住宅品質確保促進法|10年瑕疵担保|住宅性能表示|構造耐力上主要な部分|雨水の浸入|住宅瑕疵担保履行法/,
    ],
    injection_lines: [
      "【CAD形式ポリシー】必ず SVG (Web プレビュー) と DXF (CAD 交換) を第一級出力として実装せよ. IFC は BIM 連携要件時のみオプション. DWG は AutoCAD 商用のため出力対象から除外し「DXF 経由で AutoCAD に読込可」と明記.",
      "【JIS準拠必須】JIS A 0150 建築製図通則 / JIS Z 8114 製図用語 / JIS Z 8317 寸法記入法 / JIS Z 8321 線の基本原則 の 4 規格を参照実装. 太線 0.5-0.7mm / 中線 0.25-0.35mm / 細線 0.13-0.18mm・実線/破線/一点鎖線/二点鎖線・寸法補助線・引出線・ハッチング (コンクリート/断熱材/木材/地盤) を規格通り再現.",
      "【図面種別網羅】意匠図 (配置図/平面図/立面図/断面図/矩計図/展開図/天井伏図/仕上表/建具表)・構造図 (基礎伏図/床伏図/軸組図/部材リスト)・設備図 (電気/給排水/空調/ガス) をカテゴリ別に生成可能とせよ. 単図面指定にも対応.",
      "【座標・基準厳守】通り芯 (X1-Xn/Y1-Yn または A通り-Z通り)・真北記号・GL/FL/CH/SL 基準レベル・寸法基準を必ず記入. 図面右上または左上に方位記号を配置し、平面図には通り芯と寸法を必須で描画.",
      "【尺度と用紙】尺度を表題欄に明記 (1/100・1/50・1/20 等). 用紙は A1・A2 を建築業界標準とし A3 は縮小版扱い. 図枠 (輪郭線)・とじ代 25mm・表題欄 (右下 165×280mm 目安) を必ず描画. SVG は viewBox で mm 単位を実寸管理.",
      "【レイヤ規約】SXF 準拠命名を採用: A-WALL(壁)・A-COLM(柱)・A-DOOR/WIND(建具)・A-GRID(通り芯)・A-DIMN(寸法)・A-FNSH(仕上げ)・A-TEXT(文字)・S-*(構造)・M-*(機械)・E-*(電気)・P-*(衛生). SVG は <g id='layer-a-wall'> で分離し表示切替可能に.",
      "【construction-drawing-specialist連携】図面生成の実処理は既存 construction-drawing-specialist エージェント (Tools: All tools) を Task tool の subagent_type='construction-drawing-specialist' で呼び出せ. スキル本体は入力ヒアリング → エージェント委譲 → 結果整形 → 品質ゲート の司令塔役に徹する.",
      "【法令対応】建築士法第 20 条 (図面等 15 年保存)・建築基準法第 6 条 (確認申請)・建設業法第 40 条の 3 (施工体制台帳と図面保管) 対応の図面種別マーカー (確認申請図/実施設計図/施工図/竣工図) を表題欄に必ず記載. 改訂履歴 (Rev A/B/C・日付・承認者) 欄も必須.",
      "【顧客可視】生成中の進捗は「配置図を作成中です」「平面図に寸法を記入しています」「JIS 準拠チェックを実行中です」等の日本語自然文で報告. SVG/DXF の生ソース・DXF グループコード・座標配列・XML タグを地の文に貼らない (CLAUDE.md 顧客可視ポリシー準拠).",
      "【first-boot-perfect連携】~/.soloptilink/lib/first-boot-perfect/drawings/ の図面テンプレート・construction-knowledge/ の建築知識辞書を必ず参照し、soloptilink-template-kit の工事台帳との図番連携・物件管理との紐付けを実装.",
      // === 建設強化パッチ (追加 injection lines) ===
      "建築士法第2条・第3条・第3条の2に基づき、設計図書には建築士の記名(旧押印)を必須とし、規模別(一級/二級/木造)の業務独占範囲をUI・DBスキーマ両面で強制する。名義貸し(法第24条)は入力段階で検知しブロックする。",
      "建築基準法第6条(確認申請)・第7条(完了検査)・第12条(定期報告)・第20条(構造計算)・第48条〜第56条(集団規定/用途地域・建蔽率・容積率・斜線制限・日影規制)を図面属性として保持し、確認申請フェーズと定期報告フェーズを工程表に自動連携させる。",
      "建設業法第19条(請負契約書14項目)・第24条の3〜第24条の8(下請代金・一括下請負禁止)・第26条(主任技術者・監理技術者配置)・第27条の23(経営事項審査)を契約管理と技術者配置管理に組み込み、CCUS就業履歴と連動させる。",
      "下請法(建設工事は建設業法第24条の3〜24条の8が特別法として優先適用)により、下請代金支払は工事目的物受領日から50日以内・材料供与から起算した支払期日管理を必須とし、買いたたき・受領拒否・減額・返品・やり直しの禁止事項を自動チェックする。なお下請3条書面・5条書面テンプレは legal_document ドメインから再利用し重複生成を回避する。",
      "建築物省エネ法(建築物のエネルギー消費性能の向上等に関する法律)に基づき、非住宅300㎡以上は適合性判定義務・住宅は説明義務制度を工程に組み込み、BEI・UA値・ηAC値・一次エネルギー消費量・BELS/ZEB/ZEH区分を図面メタデータとして保持する。",
      "都市計画法第29条(開発許可)・第33条(技術基準)・第34条(市街化調整区域立地基準)・第43条(建築等の制限)・第53条(都市計画事業制限)と、耐震改修促進法(要緊急安全確認大規模建築物のIs値0.6以上/q値・CTU・SD値)、バリアフリー法(特別特定建築物2000㎡以上の建築物移動等円滑化基準適合義務)、建設リサイクル法(床面積80㎡以上の解体・500㎡以上の新築・請負1億円以上の修繕/1000万円以上の新築工事は分別解体・再資源化・事前届出義務)、品確法(新築住宅の構造耐力上主要な部分・雨水の浸入を防止する部分の10年間瑕疵担保責任+住宅性能表示制度)を、案件属性・地番・用途・規模から自動判定して該当工程と検査項目に展開する。",
      "上記10法令は japan-link の recommendLaws('construction') 経由で最新条文・改正履歴・所管省庁通達を取得し、SoloptiLinkAI japan モードの法令キャッシュと同期する。手打ちで条文番号をハードコードせず、必ずレジストリ経由で参照する。",
      "図面成果物と施工プロセスは、上記法令要件と1対1で対応する検査記録(確認申請書・構造計算書・省エネ計算書・分別解体等計画書・住宅性能評価書等)を PDF/A で保管し、瑕疵担保期間(品確法10年・建設業法瑕疵担保2年〜)を跨いだ長期アーカイブ対象とする。",
      "資材BOM・施工BOMは construction_drawing 側の『資材台帳』テンプレで扱い、manufacturing_production の製造BOMとは責務を分離する(MES/OPC UA/JIS Q 9001が共起しない限り本ドメインで受ける)。",
      // === 業種別サブセット選択・実装契約 (drawings/construction-knowledge SoT 参照) ===
      "【業種別サブセット】生成 SKILL.md は最初の質問で project_type を 5 択で確定させよ (wood_detached_house / rc_apartment / steel_office / renovation / civil_engineering). drawing-types-catalog.json の business_subsets に従い、木造なら配筋図除外・S造なら配筋図除外・土木工事は本ドメイン非該当として civil-engineering-drawing 誘導. 全 21 種を一律出力せず、業種に必要な図面のみに絞ることでノイズを減らす.",
      "【実装契約・construction-drawing-specialist】Task tool 呼出は 9 入力パラメータ (project_type / structure / total_floor_area_m2 / use_district / rooms / openings / grid_x_axes / grid_y_axes / north_direction_deg / prisma_schema_path) と 5 返り値 (implemented_drawings / prisma_changes / ui_pages_added / law_coverage / unresolved) の I/O 契約を JSON schema で明示. 失敗時は unresolved に例外メッセージを返し、placeholder SVG を混入させない.",
      "【版管理 DB スキーマ】drawings (id/type/rev/svg/dxf/created_at) + drawing_revisions (drawing_id/rev/approved_by/approved_at/change_summary) + approval_flow (drawing_id/status: draft|reviewing|approved|rejected) の 3 テーブルを Prisma に必ず追加. Rev A→B→C の連番と承認者を電子署名 (建築士記名) で担保.",
      "【観測可能性】S1 台帳への記録 (drawings_generated 台帳・図面種別ごとの成功率/失敗率/生成時間/DXF レイヤ数) を実装. 生成失敗時は S1 に error_class + stack + input_hash を記録して S6 セキュリティ側の異常検知に接続.",
      "【multi-tenant 分離】テナントごとに drawings/{tenant_id}/ で図面ストレージを分離. cross-tenant read/write は RLS (Row Level Security) でブロック. multi-tenant-saas-architect のロールと連携.",
      "【SVG セキュリティ】生成 SVG に <script>/<foreignObject>/<use xlink:href='http...'> は絶対に混入させない. XXE/SVG-XSS 対策として DOMPurify (SVG プロファイル) 相当のサニタイザを通した後で保存. 画面表示時は sandbox iframe または img タグでの埋込を必須.",
      "【冪等性・再送安全】同一入力 (project_type + rooms hash + openings hash) からは同一 SVG/DXF を生成 (deterministic). Idempotency-Key を Prisma unique index で保証し、同 Key の再送は最後の結果を返す (再生成しない).",
      "【承認回付通知】approval_flow.status が draft → reviewing に遷移した時に監理者へメール/Slack 通知. reviewing → approved で建築主へ電子署名済み PDF/A-3 を配信. notification-system-engineer と連携.",
      "【長期アーカイブ】完了検査後の竣工図は PDF/A-3 で保存し、瑕疵担保 10 年 + 建築士法図書 15 年の 2 系統タイマーを設定. 期限接近時 (残 1 年) にアラート. long-term-archive-policy.json の retention_periods を SoT.",
      "【ランタイム smoke】生成 SKILL 本体に tests/smoke-drawings.mjs を必ず同梱し、実際に `lib/japan/drawings.ts` の `buildDrawingSet` と `exportMinimalDxf` を bare node で呼び出して SVG が非空かつ DXF が最低 20 行以上を返すことを検証. SVG/DXF が空文字列や 3 行未満の場合は BLOCK. 文字列マッチだけでの偽 PASS を根絶する.",
      "【改訂法分岐】設計変更発生時の法的分岐を必ず提示せよ: (1) 建築基準法第6条第1項に該当する変更 (延べ面積・階数・構造耐力上主要な部分・防火避難規定に影響) → 計画変更確認申請 (新規確認申請と同等の審査). (2) 建築基準法施行規則第3条の3の軽微な変更 → 軽微変更届 (審査なしの届出). drawing_revisions テーブルに `filing_type` カラム (enum: plan_change / minor_notification / none) を追加. 自動判定は補助にとどめ、最終判断は建築士入力を必須にする (法的責任は建築士側).",
      "【現場写真・工程・積算横串】図面変更が施工管理領域に波及する時、以下の横串を実装せよ: (a) 工事写真台帳の該当図面参照 (現場写真の drawing_id 紐付), (b) バーチャート工程表の該当タスク影響評価, (c) 積算・数量拾いの再計算, (d) 施工体制台帳の技術者配置再確認. business-process-optimization-expert と協調.",
      "【BIM/CAD 混在対応】現場実務では JW-CAD / AutoCAD LT / ArchiCAD / Vectorworks / Revit / SketchUp / IFC の CAD 混在が常態. 受け渡しフォーマットは (a) DXF R12 を最低保証 (JW-CAD 対応), (b) DXF R2010 をオプション提供 (AutoCAD LT 現行版), (c) IFC 2x3 or IFC4 を BIM オプション (Revit/ArchiCAD/Vectorworks). BIM 連携時は ifc.js / web-ifc を使い、施主向け閲覧は SVG/PNG プレビュー.",
      "【建材メーカーカタログ連携】LIXIL / TOTO / YKK AP / 積水ハウス / 大和ハウス / パナソニック / 三協アルミ 等の建具・住設カタログ品番を仕上表・建具表に紐付ける経路を残す (メーカー API 直接統合は API 契約次第・スクレイピング禁止). ホームズプラス等の集約 API も参考.",
      // === H2 施工系 6 種+労安衛規則 88 条 ===
      "【施工系図面 6 種】DrawingType の Phase 3 として仮設計画図 (temporary_structure_plan)・揚重計画図 (lifting_plan)・工法説明図 (construction_method_diagram)・場内動線図 (site_logistics_plan)・解体計画図 (demolition_plan)・割付図 (partition_layout) を第一級追加. 施工計画書の添付図として工程・積算・現場写真台帳と横串連携.",
      "【労安衛規則第88条連動】足場高さ 10m 以上 60 日以上・型枠支保工の設置は労働安全衛生規則第 88 条『機械等設置届』を工事開始 30 日前までに労働基準監督署に提出. 高さ 31m 超建物・掘削深 10m 以上・トンネル工事等は同法『建設工事計画届』. 仮設計画図・揚重計画図の DrawingType と 1 対 1 で提出雛形を紐付け.",
      // === H3 消防法 (第 17 条 + 第 8 条) ===
      "【消防法第17条 消防用設備等】用途区分 15 種 × 延床面積 × 収容人員で消防用設備を自動判定: スプリンクラー (11 階以上 or 6000 ㎡以上 or 特定用途 3000 ㎡以上)・自動火災報知設備 (原則 300 ㎡以上・特定用途は面積問わず)・屋内消火栓 (原則 700 ㎡以上・特定用途 500 ㎡以上)・排煙設備 (500 ㎡超の居室). 意匠図の防火区画と設備図の消防設備配置に自動連動. FIRE_SERVICE_LAW_ART17_THRESHOLDS テーブルを architecture.ts で参照.",
      "【消防法第8条 防火管理者】用途 × 収容人員で防火管理者選任義務を自動判定. 甲種 (特定用途 30 人以上 or 非特定 50 人以上・延床 500 ㎡以上) と 乙種 (面積小規模) の区分を工事竣工後の運営管理と連携.",
      // === H4 建築物省エネ法 2025 年 4 月改正 ===
      "【省エネ法 2025 年 4 月改正】原則すべての新築 (床面積 10 ㎡超) が省エネ基準適合義務化. 省エネ適合性判定 (適判) が建築確認と一体運用 → 適判不合格なら確認済証が交付されない. 非住宅 300 ㎡以上は登録省エネ判定機関の判定書取得を確認済証の前提とする. architecture.ts の ENERGY_LAW_2025_04_TRANSITION テーブルで改正前/改正後の閾値遷移を管理し、旧法解説は履歴として保持.",
      // === H5 Rev版管理・承認回付・配布記録・図面一覧マスタ (Prisma 4 テーブル必須出力) ===
      "【Prisma 4 テーブル必須】以下 4 テーブルを Prisma schema に必須追加. (1) drawings (id/type/purpose/rev/svg/dxf/pdf/created_at/tenant_id) (2) drawing_revisions (drawing_id/rev/diff_summary/approved_by/approved_at/filing_type: plan_change|minor_notification|none) (3) approval_routes (drawing_id/route_type: design|construction_shop|fabrication / stage: 意匠→構造→設備→監理→施主 / current_stage / next_approver_id) (4) distribution_logs (drawing_id/recipient_id/sent_at/received_at/opened_at/method: email|api|physical). 竣工図一式は PDF/A-1a で 15 年保存 slot に自動格納. 図枠・表題欄・レイヤ規約・図面種別カタログは実在資産 `~/.soloptilink/lib/first-boot-perfect/drawings/` (paper-frames.svg / title-block-fields.json / sxf-layer-conventions.json / drawing-types-catalog.json) を参照する. ※2026-08-06 是正: 旧記述は同ディレクトリの revision-model.mjs / approval-routing.mjs / distribution-ledger.mjs / drawing-list-master.mjs を『同梱参照』と指示していたが、4 本とも実在しない (manifest.json の files にも無い) ため撤去した.",
      // === H6 設計図/施工図/製作図の 3 層役割分離 ===
      "【3 層役割分離】drawings.ts の DrawingPurpose 型 (design_document / construction_shop_drawing / fabrication_drawing) を第一級属性化. 承認回付ワークフローを設計図 (意匠→構造→設備→監理) と施工図 (元請→監理→設計者確認) と製作図 (専門工事業者→元請) の 3 系統に分離. 製作図署名者は CCUS 就業履歴・技能者資格 (登録基幹技能者・特級技能士) と紐付け ccus-competence-levels.json レベル 3/4 相当を必須とする.",
      // === H7 構造計算プログラム連携 ===
      "【構造計算プログラム連携】SS7 (ユニオンシステム)・BUS-6 (構造システム)・SEIN (NTT データ)・Super Build 等の一貫構造計算プログラム出力から構造 4 図 (基礎伏図・床伏図・軸組図・配筋図) への自動反映. buildStructuralDrawingsFromCalcOutput(calcOutput: StructuralCalcOutput) を新設し、部材リスト・断面リスト・接合部詳細・柱脚詳細・基礎断面リストを各図に自動反映. 表題欄に構造計算適合性判定 (建基法 20 条 3 項) 提出書類の書誌情報 (計算プログラム名・版・計算日) を必須注入. 図面側の受け皿 (レイヤ・図枠) は実在資産 `~/.soloptilink/lib/first-boot-perfect/drawings/sxf-layer-conventions.json` を参照. ※2026-08-06 是正: 旧記述は同ディレクトリの structural-calc-adapter (.mjs) を『テンプレとして同梱参照』と指示していたが実在しないため撤去した (アダプタは生成 SKILL 側で実装する).",
      // === H8 積算 pipeline (数量拾い→歩掛→単価→見積書) ===
      "【積算 pipeline】buildDrawingSet に quantityTakeoff() サブ関数経路を残し、部屋ポリゴン・開口部・部材から数量を自動拾いして estimates.ts の歩掛 (公共建築工事積算基準) テーブルに渡す 4 段パイプラインを実装. 単価 source は『建設物価 (建設物価調査会)』『積算資料 (経済調査会)』『RIBC-3 (施設整備の予定価格・国土交通省)』の 3 系統をレジストリ化し、SKILL 生成時にどの source を使うかを選択. 見積書出力に単価出典を必ず表示 (数量精度 ±5% 目標).",
      // === C4 実走スモーク (L46-CDSM 生成側呼応) ===
      "【L46-CDSM 呼応】生成 SKILL は tests/smoke-drawings.mjs で fixtures/wooden-2story.json を読み込み、buildDrawingSet と exportMinimalDxf を bare node で実呼び出し. SVG≧6 枚・各 SVG≧2KB・<path/<rect/<text の 3 タグ必須・DXF が 0/SECTION/2/HEADER/2/ENTITIES/0/EOF を含み≧500byte・SVG の viewBox が A1/A2 用紙比 (841x594/594x420) と一致. 1 つでも欠落なら BLOCK. これで空 DXF/空 SVG の false PASS を根絶.",
    ],
    quality_axes: [
      { key: "jis_drawing_standards_compliance", severity: "BLOCK", description_ja: "JIS 5 規格 (A 0150 建築製図通則 + Z 8114 製図用語 + Z 8317 寸法記入法 + Z 8321 線の基本原則 + Z 8311 縮尺) の少なくとも 4 規格が SKILL.md 本文に明記されていること. H1 統合: blueprint/実装 drawings.ts/agent md/品質軸 の 4 点で完全一致.",
        match_count_at_least: { keywords: ["JIS A 0150", "JIS Z 8114", "JIS Z 8317", "JIS Z 8321", "JIS Z 8311", "建築製図通則"], min: 4 },
        must_all_regex: [/線種|線太さ|線の基本/, /寸法記入|寸法補助線/, /尺度|縮尺/, /図枠|表題欄/] },
      { key: "cad_format_dual_output", severity: "BLOCK", description_ja: "SVG と DXF の両方が第一級出力として実装指示されている. DWG は否定側で禁止 (積極的 export を弾く). DXF はバージョン明示 (R12/R2000/R2010) を強制.",
        must_all: ["SVG", "DXF"],
        must_all_regex: [/DXF\s*(?:R12|R2000|R2010|AC1009|AC1015|AC1024)/i],
        must_not_regex: [/DWG.*(?:出力|生成|export|write|save)/i, /DWG\s*形式で保存/] },
      { key: "drawing_types_coverage", severity: "FAIL", description_ja: "意匠図・構造図・設備図の 3 大分類と主要図面種別 (平面図/立面図/断面図/矩計図/配置図) が網羅されている",
        match_count_at_least: { keywords: ["平面図", "立面図", "断面図", "矩計図", "配置図"], min: 4 },
        must_any: ["意匠図", "構造図", "設備図"] },
      { key: "layer_convention_sxf", severity: "FAIL", description_ja: "SXF 準拠レイヤ命名 (A-WALL/A-COLM/A-GRID 等) または同等のレイヤ分離規約が定義されている",
        must_any: ["A-WALL", "A-COLM", "A-GRID", "A-DIMN", "SXF", "レイヤ規約", "レイヤ命名"] },
      { key: "coordinate_reference_system", severity: "FAIL", description_ja: "通り芯・真北・GL/FL/CH 等の基準記号と座標系が明記されている",
        match_count_at_least: { keywords: ["通り芯", "真北", "GL", "FL", "CH", "基準線"], min: 3 } },
      { key: "agent_delegation_wiring", severity: "FAIL", description_ja: "construction-drawing-specialist エージェントへの委譲 (Task tool subagent_type) が実装指示されている",
        must_all: ["construction-drawing-specialist"],
        must_any_regex: ["Task.*tool|subagent_type"] },
      { key: "legal_compliance_markers", severity: "WARN", description_ja: "建築士法 20 条・建築基準法 6 条・図面種別マーカー (確認申請図/実施設計図/施工図/竣工図) が言及されている",
        match_count_at_least: { keywords: ["建築士法", "建築基準法", "確認申請", "竣工図", "施工図", "実施設計図"], min: 3 } },
      // === 建設強化パッチ (追加 quality axes) ===
      {
        key: "law_citation_construction_core",
        description_ja: "建設業界コア3法(建築士法・建築基準法・建設業法)の条文番号が生成物中に具体的に(第○条形式で)明示されていること。総論的な言及だけでなく、確認申請=法第6条、構造計算=法第20条、技術者配置=法第26条など、機能と条文の対応が取れていることを検証する。",
        severity: "FAIL",
        must_all_regex: [/建築士法/, /建築基準法/, /建設業法/],
        must_any_regex: [/建築基準法\s*(?:第\s*)?6\s*条/, /建築基準法\s*(?:第\s*)?20\s*条/, /建設業法\s*(?:第\s*)?26\s*条/, /建築士法\s*(?:第\s*)?(?:2|3|3の2)\s*条/],
        must_not_regex: [/建築関連法令等を?遵守/, /関係法令を?厳守/],
      },
      {
        key: "law_citation_construction_extended",
        description_ja: "拡張7法(下請法・省エネ法・都市計画法・耐震改修促進法・バリアフリー法・建設リサイクル法・品確法)のうち少なくとも5つ以上が生成物中に明示的に登場し、かつ各法令の建設業への適用場面(規模閾値・対象建築物・義務内容)が具体的に記述されていること。C2昇格: match_count_at_least min=5 で1件PASSのfalse PASSを根絶.",
        severity: "FAIL",
        match_count_at_least: { keywords: ["建築物省エネ法", "省エネ法", "都市計画法", "耐震改修促進法", "バリアフリー法", "移動等円滑化", "建設リサイクル法", "品確法", "住宅品質確保促進法", "下請法", "消防法"], min: 5 },
        must_not_regex: [/法令については別途確認/, /詳細は法令を参照/],
      },
      {
        key: "japan_link_recommendLaws_wiring",
        description_ja: "法令参照は japan-link の recommendLaws('construction') 経由で取得され、条文・改正履歴・所管省庁通達がハードコードではなくレジストリから動的に展開されていることを検証する。",
        severity: "FAIL",
        must_all_regex: [/japan-link|japan_link|recommendLaws/],
        must_any_regex: [/recommendLaws\(\s*['\"]construction['\"]/, /japan-link.*construction/],
        must_not_regex: [/法令データを手動で更新|条文をハードコード/],
      },
      {
        key: "regulation_threshold_specificity",
        description_ja: "法令適用の規模閾値が数値付きで正確に記述されていること. C2昇格: min=3 で単一閾値のみのfalse PASSを排除. 建築物省エネ法2025年4月改正の10㎡超も対象.",
        severity: "FAIL",
        match_count_at_least: { keywords: ["80㎡", "80平米", "80m2", "500㎡", "500平米", "500m2", "300㎡", "300平米", "300m2", "2000㎡", "Is値0.6", "10年", "瑕疵担保", "10㎡超", "2025年4月", "令和7年4月"], min: 3 },
        must_not_regex: [/一定規模以上|規模に応じて|所定の面積/],
      },
      {
        key: "workflow_phase_law_binding",
        description_ja: "工程表・施工管理フェーズの各フェーズに対応する法令要件・提出書類・検査記録が紐付けられていること. C2昇格: 4 フェーズ (確認申請/中間検査/完了検査/省エネ適合性判定) を must_all で必須化しWARNからFAILへ.",
        severity: "FAIL",
        must_all_regex: [/確認申請/, /中間検査/, /完了検査/, /省エネ適合性判定|省エネ.*適判/],
        match_count_at_least: { keywords: ["定期報告", "分別解体等計画書", "住宅性能評価書", "構造計算適合性判定", "計画変更確認申請", "軽微変更届"], min: 2 },
        must_not_regex: [/工程は別途調整|法令対応は個別対応/],
      },
      // === 追加品質軸 (敵対解析後の強化) ===
      {
        key: "business_subset_scoping",
        description_ja: "業種別サブセット (wood_detached_house / rc_apartment / steel_office / renovation / civil_engineering) の 5 択質問が Step 0 で実装されていること. 全 21 種を一律出力せず、業種に応じた図面種別サブセットを選択する UI/ロジックがあること.",
        severity: "FAIL",
        must_any_regex: [/wood_detached_house|木造専門|戸建て木造/, /rc_apartment|RC集合住宅/, /steel_office|S造事務所/, /renovation|リフォーム|改修/],
        must_any: ["business_subset", "業種別サブセット", "project_type", "5択"],
        must_not_regex: [/全21種を一律|全図面を必ず生成/],
      },
      {
        key: "specialist_io_contract",
        description_ja: "construction-drawing-specialist agent への Task tool 呼出時の入力パラメータ (project_type / structure / total_floor_area_m2 / rooms / openings 等) と返り値 (implemented_drawings / prisma_changes / law_coverage / unresolved) の I/O 契約が JSON schema または型定義で明示されていること.",
        severity: "FAIL",
        must_all_regex: [/subagent_type\s*[=:]\s*['\"]?construction-drawing-specialist/, /(?:input|入力|params?|パラメータ)/, /(?:return|返り値|output|出力|response)/],
        must_any: ["project_type", "rooms", "openings", "implemented_drawings"],
        must_not_regex: [/入出力は自由|契約は個別実装/],
      },
      {
        key: "revision_and_approval_wiring",
        description_ja: "版管理 (Rev A/B/C) と承認回付の DB スキーマ (drawings/drawing_revisions/approval_flow の 3 テーブル) が Prisma 定義として明示されていること. 承認者・承認日時・改訂内容の記録も.",
        severity: "FAIL",
        must_any_regex: [/drawing_revisions?|approval_flow|Rev\s*A\/B\/C|改訂履歴/],
        must_all: ["approved_by", "承認"],
        must_not_regex: [/版管理は別途|承認は現場運用/],
      },
      {
        key: "svg_security_hardening",
        description_ja: "SVG 生成時のセキュリティ対策 (script/foreignObject/外部 xlink:href の排除, DOMPurify SVG プロファイル通過, sandbox iframe/img 埋込) が明示されていること. XXE/SVG-XSS 対策の記載.",
        severity: "FAIL",
        must_any_regex: [/DOMPurify|SVG.*サニタイ|SVG.*sanitize|XXE|SVG.*XSS/i],
        must_any: ["script", "foreignObject", "xlink", "sandbox"],
        must_not_regex: [/SVG は安全なので特に対策不要/],
      },
      {
        key: "long_term_archive_pdf_a3",
        description_ja: "長期保存フォーマット (PDF/A-3) と保存期間 (瑕疵担保 10 年・図書 15 年) が具体的に明示されていること. PDF/A-1b/A-2b/A-3 の使い分け.",
        severity: "WARN",
        must_any_regex: [/PDF\/A-3|PDF\/A-2b|PDF\/A-1b/],
        must_any: ["10年", "15年", "瑕疵担保", "長期保存"],
        must_not_regex: [/PDF 保存だけで長期対応/],
      },
      {
        key: "multi_tenant_isolation",
        description_ja: "テナント分離 (drawings/{tenant_id}/ でのストレージ分離, RLS による cross-tenant 遮断) が明示されていること.",
        severity: "WARN",
        must_any_regex: [/tenant_id|テナント分離|multi-?tenant|RLS|Row\s*Level\s*Security/i],
      },
      {
        key: "s1_observability_wiring",
        description_ja: "S1 台帳への図面生成観測性 (drawings_generated 台帳・成功率/失敗率/生成時間/レイヤ数) の記録が明示されていること.",
        severity: "WARN",
        must_any_regex: [/S1\s*台帳|drawings_generated|observability|観測.*図面|生成.*(?:成功|失敗)率/],
      },
      // === 敵対 workflow (F04/F08) で確定した追加真陽性軸 ===
      {
        key: "runtime_smoke_dxf_svg",
        description_ja: "生成 SKILL に tests/smoke-drawings.mjs を同梱し、実際に lib/japan/drawings.ts の buildDrawingSet / exportMinimalDxf を bare node で呼び出して SVG が非空かつ DXF が 20 行以上を返すことを smoke 検証していること (文字列マッチだけの偽 PASS を根絶).",
        severity: "FAIL",
        must_any_regex: [/smoke.*(?:drawings?|dxf|svg)|tests?\/smoke.*drawings?/i, /buildDrawingSet.*(?:呼|call|invoke|実走)|exportMinimalDxf.*(?:呼|call|invoke|実走)/],
        must_any: ["smoke", "bare node", "実走", "non-empty", "非空"],
        must_not_regex: [/smoke は静的検証で代替|文字列マッチで十分/],
      },
      {
        key: "revision_law_branching",
        description_ja: "設計変更時の法的分岐 (建築基準法第6条第1項の計画変更確認申請 vs 施行規則第3条の3の軽微な変更) が明示され、drawing_revisions テーブルに filing_type カラム (plan_change / minor_notification / none) を追加する指示があること. 最終判断は建築士入力必須.",
        severity: "FAIL",
        must_any_regex: [/計画変更確認申請|軽微(?:な)?変更(?:届)?|施行規則第\s*3\s*条の\s*3|法第\s*6\s*条第\s*1\s*項/],
        must_all: ["filing_type", "建築士"],
        must_not_regex: [/変更届は不要|軽微な変更は自動判定/],
      },
      {
        key: "cad_mixed_environment_support",
        description_ja: "現場実務の CAD 混在対応 (JW-CAD / AutoCAD LT / ArchiCAD / Vectorworks / Revit / SketchUp / IFC) に対する受け渡しフォーマット選択が明示されていること. DXF R12 最低保証 + R2010 オプション + IFC 2x3 or IFC4 BIM オプション.",
        severity: "WARN",
        must_any_regex: [/JW-?CAD|AutoCAD\s*LT|ArchiCAD|Vectorworks|Revit|SketchUp/],
        must_any_regex_all: [/DXF/, /IFC/],
      },
      // === H2 施工系 6 種+労安衛規則 88 条 ===
      {
        key: "construction_plan_drawings_and_reg88",
        description_ja: "施工系 6 種 (仮設/揚重/工法/場内動線/解体/割付) が DrawingType に列挙され、労働安全衛生規則第 88 条『機械等設置届』(足場高さ 10m 以上 60 日以上/型枠支保工) と『建設工事計画届』(高さ 31m 超建物/掘削深 10m 以上) の提出雛形が仮設計画図・揚重計画図に紐付けられていること.",
        severity: "FAIL",
        match_count_at_least: { keywords: ["仮設計画図", "揚重計画図", "工法説明図", "場内動線図", "解体計画図", "割付図", "temporary_structure_plan", "lifting_plan"], min: 3 },
        must_any_regex: [/労働安全衛生規則第?\s*88\s*条|労安衛規則88条|機械等設置届|建設工事計画届/],
      },
      // === H3 消防法 (第 17 条 + 第 8 条) ===
      {
        key: "fire_service_law_wiring",
        description_ja: "消防法第 17 条 (消防用設備等) と第 8 条 (防火管理者) が生成物に明示され、スプリンクラー/自動火災報知/屋内消火栓/排煙設備 の少なくとも 3 種の判定閾値が数値付きで記述されていること.",
        severity: "FAIL",
        must_all_regex: [/消防法/],
        must_any_regex: [/第\s*17\s*条|17条|消防用設備等/, /第\s*8\s*条|8条|防火管理者/],
        match_count_at_least: { keywords: ["スプリンクラー", "自動火災報知", "屋内消火栓", "排煙設備", "防火区画"], min: 3 },
      },
      // === H4 建築物省エネ法 2025 年 4 月改正 ===
      {
        key: "energy_law_2025_04_reform",
        description_ja: "建築物省エネ法 2025 年 4 月改正 (原則全新築 10 ㎡超が省エネ基準適合義務化・適判と確認申請の一体運用) が明示されていること.",
        severity: "FAIL",
        must_any_regex: [/2025\s*年\s*4\s*月|令和\s*7\s*年\s*4\s*月/],
        must_any_regex_all: [/省エネ.*適合(?:性|義務)|適合(?:性)?判定/, /10\s*㎡|10\s*平米/],
        must_not_regex: [/現行法どおり|改正の詳細は別途/],
      },
      // === H5 Prisma 4 テーブル必須出力 ===
      {
        key: "prisma_4tables_drawing_management",
        description_ja: "Prisma schema に (1) drawings (2) drawing_revisions (3) approval_routes (4) distribution_logs の 4 テーブルが必須追加されていること. drawing_revisions に filing_type (plan_change/minor_notification/none) カラム必須.",
        severity: "FAIL",
        must_all: ["drawings", "drawing_revisions", "approval_routes", "distribution_logs"],
        must_any_regex: [/filing_type/, /計画変更確認申請|軽微(?:な)?変更/],
      },
      // === H6 3 層役割分離 quality axis (drawing_purpose 属性) ===
      {
        key: "drawing_purpose_3layer",
        description_ja: "drawings.ts の DrawingPurpose 型 (design_document / construction_shop_drawing / fabrication_drawing) の 3 層役割分離が明示されており、承認回付ワークフローが 3 系統に分離されていること. 製作図署名者は CCUS レベル 3 以上と紐付け.",
        severity: "FAIL",
        must_any_regex: [/design_document|設計図書/, /construction_shop_drawing|施工図/, /fabrication_drawing|製作図/],
        must_any: ["DrawingPurpose", "drawing_purpose", "3層役割分離", "承認回付"],
      },
      // === H7 構造計算プログラム連携 ===
      {
        key: "structural_calc_program_binding",
        description_ja: "構造計算プログラム (SS7/BUS-6/SEIN/Super Build/一貫構造計算) の出力を構造 4 図に反映する経路が明示されていること. 表題欄に計算プログラム名・版・計算日を必須注入.",
        severity: "WARN",
        must_any_regex: [/SS7|BUS-?6|SEIN|Super\s*Build|一貫構造計算/],
        match_count_at_least: { keywords: ["部材リスト", "断面リスト", "接合部詳細", "柱脚詳細", "基礎断面リスト", "構造計算適合性判定"], min: 2 },
      },
      // === H8 積算 pipeline ===
      {
        key: "estimation_pipeline_completeness",
        description_ja: "積算 4 段パイプライン (数量拾い→歩掛→単価→見積書) が明示され、単価 source (建設物価 / 積算資料 / RIBC-3) のうち少なくとも 1 つが具体的に指定されていること. 見積書出力に単価出典表示必須.",
        severity: "WARN",
        must_all_regex: [/数量拾い|数量.*拾|takeoff/, /歩掛|公共建築工事積算基準/, /見積書|見積り書/],
        must_any_regex: [/建設物価|積算資料|RIBC-?3/],
        must_not_regex: [/単価は自由入力|参考単価のみ/],
      },
    ],
    reference_libraries: [
      "Task tool (subagent_type='construction-drawing-specialist')",
      "SVG.js または純粋 SVG 文字列 (viewBox mm 実寸)",
      "dxf-writer / dxf-parser (npm・R2000/R2010)",
      "ifc.js / web-ifc (BIM オプション)",
      "jsPDF + svg2pdf.js (図面 PDF)",
      "pdf-lib (PDF/A-3 出力・添付ファイル埋込)",
      "sharp / puppeteer (SVG→PNG ラスタライズ)",
      "~/.soloptilink/lib/japan/drawings.ts (座標計算・SVG/DXF 生成 SoT)",
      "~/.soloptilink/lib/japan/architecture.ts (用途地域・容積率・斜線・構造ルート・耐火・避難)",
      "~/.soloptilink/lib/japan/laws.ts recommendLaws('construction') (建設業界コア 11 法令)",
      "~/.soloptilink/lib/japan/laws_extended.ts recommendExtendedLaws('construction') (拡張 7 法令)",
      "~/.soloptilink/lib/first-boot-perfect/drawings/paper-frames.svg (JIS A 0150 図枠+表題欄)",
      "~/.soloptilink/lib/first-boot-perfect/drawings/jis-line-types.svg (JIS Z 8321 線種)",
      "~/.soloptilink/lib/first-boot-perfect/drawings/hatching-patterns.svg (JIS A 0150 材料)",
      "~/.soloptilink/lib/first-boot-perfect/drawings/electrical-symbols.svg (JIS C 0303)",
      "~/.soloptilink/lib/first-boot-perfect/drawings/plumbing-symbols.svg (JIS A 0407)",
      "~/.soloptilink/lib/first-boot-perfect/drawings/dxf-r12-header.dxf (DXF R12 テンプレ 20 レイヤ)",
      "~/.soloptilink/lib/first-boot-perfect/drawings/drawing-types-catalog.json (21 種+業種別サブセット 5)",
      "~/.soloptilink/lib/first-boot-perfect/drawings/sxf-layer-conventions.json (SXF レイヤ 32 種)",
      "~/.soloptilink/lib/first-boot-perfect/drawings/title-block-fields.json (表題欄 12 必須項目)",
      "~/.soloptilink/lib/first-boot-perfect/construction-knowledge/law-inspection-mapping.json (10 法×検査項目)",
      "~/.soloptilink/lib/first-boot-perfect/construction-knowledge/scale-standards.json (JIS Z 8311)",
      "~/.soloptilink/lib/first-boot-perfect/construction-knowledge/construction-permit-29types.json",
      "~/.soloptilink/lib/first-boot-perfect/construction-knowledge/workflow-phase-law-binding.json",
      "~/.soloptilink/lib/first-boot-perfect/construction-knowledge/regulation-thresholds.json",
      "~/.soloptilink/lib/first-boot-perfect/construction-knowledge/ccus-competence-levels.json",
      "~/.soloptilink/lib/first-boot-perfect/construction-knowledge/long-term-archive-policy.json",
      "soloptilink-japan (建築士法・建築基準法・建設業法・下請法・省エネ法・都市計画法・耐震改修促進法・バリアフリー法・建設リサイクル法・品確法)",
      "soloptilink-template-kit (工事台帳・物件管理・図番連携)",
    ],
    integration_notes:
      "既存 construction-drawing-specialist に処理委譲し、生成スキルは司令塔役に徹する. 呼出は Task tool の subagent_type='construction-drawing-specialist' 経由・9 入力パラメータ (project_type/structure/total_floor_area_m2/use_district/rooms/openings/grid_axes/north_direction_deg/prisma_schema_path) と 5 返り値 (implemented_drawings/prisma_changes/ui_pages_added/law_coverage/unresolved) の I/O 契約を守る. 参照資産は first-boot-perfect/drawings/ (10 資産) と construction-knowledge/ (9 資産) を実物として参照 (ハードコード禁止). 業種別サブセット (戸建て木造/RC 集合住宅/S 造事務所/リフォーム/土木工事) で生成範囲を絞り、無関係な図面種別を除外. soloptilink-template-kit の工事台帳と図番連携.",
  },
  {
    key: "claude_code_sdk_dev",
    name_ja: "Claude Code SDK / オープンクロー開発",
    example_skill_name: "soloptilink-claude-forge",
    detection_patterns: [
      /Claude Code SDK|Claude Agent SDK|クロードコードSDK|クロードエージェントSDK/i,
      // スラッシュコマンド: Claude Code 文脈が同時にある時のみ有効化 (Slack/Discord/Teams の誤検出防止)
      /(?:Claude(?:\s*Code)?|\.claude|SKILL\.md|カスタムコマンド|~\/\.claude\/commands).{0,40}スラッシュコマンド|スラッシュコマンド.{0,40}(?:Claude(?:\s*Code)?|\.claude|SKILL\.md|~\/\.claude\/commands)/i,
      /サブエージェント|sub[- ]?agent|subagent|\.claude\/agents/i,
      /(?:hook|フック)\s*(?:定義|開発|作成|設計|生成|manifest)|SessionStart|PostToolUse|UserPromptSubmit|PreToolUse|SessionEnd|PreCompact|SubagentStop|Notification フック|Stop フック/i,
      /(?:MCP|Model Context Protocol)\s*(?:server|サーバー|コネクタ|クライアント|開発|作成|manifest|inspector)|mcp[- ]?server|stdio transport|JSON-?RPC/i,
      /(?:SKILL\.md|frontmatter|allowed-tools|argument-hint)\s*(?:を|の)?\s*(?:作|生成|開発|新規|frontmatter|allowed-tools|argument-hint)|skill creator|skill-creator|\.claude\/skills/i,
      /claude marketplace|プラグイン配布|\.claude\/plugins|plugin manifest|claude plugin|marketplace\.json/i,
      /(?:~\/\.claude\/)?settings\.(?:json|local\.json)|permissions\.(?:allow|deny)|パーミッション設定/,
      /anthropic sdk|@anthropic-ai\/sdk|anthropic-sdk-python|(?:tool_use|tool_result|input_schema)\s*(?:を|の)?\s*(?:作|開発|実装)|tools=\[/i,
      /claude-opus-4-8|claude-sonnet-5|claude-haiku-4-5|claude-fable-5|最新モデル|モデルID.*(?:claude-|Anthropic)/i,
      /MCP inspector|born-passing|hook テスト|フックテスト|モックフック/i,
      /オープンクロー|Open Claude|独自(?:スキル|エージェント|MCP|フック|スラッシュコマンド|プラグイン)|自作(?:スキル|エージェント|MCP|フック|スラッシュコマンド|プラグイン)/,
      /Claude Code 拡張|Claude Code extension|CLI 拡張|Anthropic CLI/i,
      // 2025-2026 の最新機能 (output-styles / keybindings / plugin / extended thinking)
      /output[- ]?styles?|OutputStyle|出力スタイル|応答スタイル/i,
      /keybindings\.json|キーバインド定義|Claude\s*Code\s*ショートカット/i,
      /extended[- ]?thinking|thinking mode\s*(?:on|off|有効)|Anthropic\s*prompt\s*caching|prompt[- ]?caching\s*(?:enable|有効化)/i,
      /computer\s*use|computer_use|コンピュータ使用|Anthropic\s*computer/i,
    ],
    injection_lines: [
      "【frontmatter完全性】生成する SKILL.md には必ず name / description / argument-hint / allowed-tools の 4 フィールドを含めよ. description は「いつトリガーされるか」を英語 3-4 文または日本語で明示 (例: Use when the user asks to create a custom Claude Code skill).",
      "【対象要素の網羅】Claude Code 拡張の 5 種 (スラッシュコマンド / サブエージェント / フック / MCP サーバー / プラグイン) と Agent SDK (Python / TypeScript) を対象カバレッジ表として提示し、ユーザー要求がどの種類かを最初に分岐判定する Step 0 を入れよ.",
      "【フック JSON 契約】フック生成時は SessionStart / UserPromptSubmit / PreToolUse / PostToolUse / Stop / Notification の 6 イベントで、入力 JSON (session_id / cwd / tool_name / tool_input) と出力 JSON (decision / systemMessage / suppressOutput) を JSON schema で契約化. 終了コード規約 (0=continue, 2=block) も明記.",
      "【MCP サーバー最小仕様】MCP サーバー生成時は (1) stdio transport (2) JSON-RPC 2.0 メソッド (initialize / tools/list / tools/call / resources/list / prompts/list) (3) tool schema (name/description/inputSchema) (4) claude mcp add コマンド (5) MCP inspector 検証手順 の 5 要素を必ず含める.",
      "【モデル ID 規律】claude-opus-4-8 / claude-sonnet-5 / claude-haiku-4-5-20251001 / claude-fable-5 等のモデル ID・料金・context window・rate limit は絶対に記憶で書かない. 生成 SKILL.md 内に「モデル ID/料金/パラメータは claude-api スキルを参照」の注意書きを必須で入れる.",
      "【権限最小化】settings.json 生成時は permissions.allow / permissions.deny を必ず対で提示. Bash 系は個別コマンド許可 (例: Bash(git status:*)) で全許可を避ける. MCP は mcp__<serverId>__<toolName> 形式で個別許可.",
      "【born-passing テスト】生成スキル本体には tests/selftest.sh を同梱し、(1) frontmatter パース (2) description 反応語適合 (3) allowed-tools 実在確認 (4) フック生成物の JSON schema 往復 (5) MCP tools/list 応答 を全て緑で通ることを提出直後に実測.",
      "【顧客可視】生成 SKILL.md 本文は英語で書いてよいが、ユーザーへの進捗報告は日本語. bash・生ログ・<invoke> タグ・raw JSON は地の文に出さず「フックの入出力契約を検証しました」等の日本語ステータスに要約.",
      "【PFP-082 Watermark】生成 SKILL.md 末尾に SoloptiLink Watermark ブロック (generated_by / domain: claude_code_sdk_dev / forge_version / timestamp / role_council_size / quality_gates) を必ず注入.",
      "【Agent SDK 統合】Python は anthropic (公式) + mcp (MCP client) を、TypeScript は @anthropic-ai/sdk + @modelcontextprotocol/sdk を使う雛形を提示. streaming (client.messages.stream) / tool use (tools=[{name,description,input_schema}]) / MCP server 起動 (stdio) を同梱.",
    ],
    quality_axes: [
      { key: "frontmatter_completeness", severity: "BLOCK", description_ja: "frontmatter に name / description / argument-hint / allowed-tools の 4 フィールドが全て存在する",
        frontmatter_required_fields: ["name", "description", "argument-hint", "allowed-tools"] },
      { key: "hook_json_contract", severity: "FAIL", description_ja: "フック生成物に SessionStart / UserPromptSubmit / PreToolUse / PostToolUse / Stop / Notification の 6 イベントと decision / exit code が言及されている",
        must_all: ["SessionStart", "PostToolUse", "UserPromptSubmit"],
        must_any_regex: ["decision|exit code|終了コード"] },
      { key: "mcp_full_stack", severity: "FAIL", description_ja: "MCP サーバー生成物に stdio transport / JSON-RPC / inputSchema / claude mcp add / MCP inspector の 5 要素が揃う",
        must_all_regex: ["stdio", "JSON-?RPC", "inputSchema", "claude mcp add", "inspector"] },
      { key: "model_id_discipline", severity: "BLOCK", description_ja: "モデル ID (opus/sonnet/haiku/fable) を記憶で断定せず claude-api スキル参照の注意書きを含む",
        must_all_regex: ["claude-api"] },
      { key: "permission_least_privilege", severity: "FAIL", description_ja: "settings.json 例に permissions.allow / permissions.deny 対が存在し Bash は個別コマンド許可",
        must_all_regex: ["permissions", "\"allow\"", "\"deny\"", "Bash\\("] },
      { key: "born_passing_selftest", severity: "BLOCK", description_ja: "同梱の tests/selftest.sh がスキル作成直後にゼロ改変で 5 項目を緑で通る旨が言及されている",
        must_all_regex: ["tests\\/selftest|selftest\\.sh|born-passing"] },
      { key: "pfp082_watermark", severity: "FAIL", description_ja: "生成 SKILL.md 末尾に PFP-082 Watermark (SoloptiLink Skill Forge / domain / forge_version / timestamp) がある",
        tail_must_all_regex: ["SoloptiLink", "domain", "generated_by|forge"] },
    ],
    reference_libraries: [
      "anthropic (Python 公式 SDK)",
      "@anthropic-ai/sdk (TypeScript/Node)",
      "mcp (Python MCP SDK)",
      "@modelcontextprotocol/sdk (TypeScript MCP SDK)",
      "@modelcontextprotocol/inspector (対話テスタ)",
      "claude mcp add / claude mcp list",
      "ajv (フック JSON Schema 検証)",
      "yaml / gray-matter (frontmatter パース)",
      "shellcheck (フックスクリプト静的解析)",
      "anthropic-skills:skill-creator (雛形生成)",
      "anthropic-skills:claude-api (モデル ID 参照)",
      "SoloptiLinkAI L42-QLOOP (9 波敵対検証)",
    ],
    integration_notes:
      "Skill Forge Link (PFP-161) の domain=claude_code_sdk_dev として全 105 ロールへ品質教典を注入. skill-creator を主幹ハンドラに指定し、integration-architect / mcp-designer / test-harness-engineer / permissions-auditor と共働. claude-api スキル参照ルール厳守.",
  },
  {
    key: "api_integration_ai_control",
    name_ja: "API 連携で AI 動作制御 (MCP・エージェントオーケストレーション)",
    example_skill_name: "soloptilink-api-orchestrator",
    detection_patterns: [
      /API\s*(?:連携|統合|紐づけ|バインディング|自動化)/,
      /(?:外部|他社|SaaS)\s*API/,
      // SaaS 名詞は API/連携/webhook との共起を必須化 (Slack 通知業務システムの誤検出防止)
      /(?:Salesforce|HubSpot|Zoho|kintone|Slack|Teams|Discord|LINE|Zoom|Google Meet|freee|マネーフォワード|勘定奉行|弥生|GitHub|GitLab|Notion|Airtable|Stripe|Shopify)\s*(?:API|連携|統合|コネクタ|webhook|Webhook|Bot|OAuth|Zapier|MCP)/i,
      // MCP は必ず server/コネクタ/連携/統合との共起
      /(?:MCP|Model Context Protocol)\s*(?:server|サーバー|コネクタ|クライアント|統合|連携|inspector|stdio|JSON-?RPC)|(?:サーバー|コネクタ|統合|連携).{0,10}MCP/i,
      /webhook|Webフック|イベント駆動|署名検証|HMAC/i,
      /tool use|tool_choice|関数呼び出し|function call|structured output|JSON schema出力/i,
      /IBL|Integration Blueprint|connector[- ]?forge|一発配線|ibl\.sh/i,
      /fan[- ]?out|fan[- ]?in|判定パネル|judge panel|敵対検証|adversarial|loop[- ]?until[- ]?dry/i,
      /rate limit|レート制限|指数バックオフ|(?:retry|再送).{0,10}(?:API|HTTP)|冪等|idempoten|Idempotency-Key/i,
      /LLM\s*ルーティング|モデル選定.*(?:Opus|Sonnet|Haiku|Fable)|プロンプトキャッシュ|prompt[- ]?caching/i,
      /(?:取得|fetch).*(?:して|して.).{0,20}(?:通知|投稿|反映|同期|Slack|Teams)|定期的.*(?:API|Anthropic)|毎(?:朝|日|時).{0,10}(?:要約|集計|通知).*(?:AI|API|LLM|Claude|Anthropic)/,
      /仕訳.*(?:自動|API|LLM)|会計.*(?:API|連携)|CRM.*(?:API|連携)|チケット.*(?:API|連携)|カレンダー.*(?:API|連携)|チャット.*(?:API|連携)/,
      /SSE.*(?:Anthropic|API)|ストリーミング.*(?:Anthropic|API|LLM)|streaming.*(?:Anthropic|API)|graceful fallback/i,
      /API\s*キー|シークレット|OAuth\s*(?:2|認可|Client)|token refresh|リフレッシュトークン/i,
      /オーケストレーション|マルチエージェント|Centuria|105\s*ロール|parallel[- ]?exec/i,
      // 2025-2026 の Anthropic API 主要機能 (RAG / embedding / prompt caching / batch / thinking)
      /RAG|Retrieval[- ]?Augmented|検索拡張生成/i,
      /vector\s*(?:DB|database|store)|ベクトル(?:DB|検索|データベース)|pinecone|weaviate|qdrant|chroma|milvus|pgvector/i,
      /embedding|エンベディング|埋め込みベクトル|text-embedding|voyage[- ]?ai/i,
      /prompt[- ]?caching|プロンプトキャッシュ|batch\s*API|message\s*batches/i,
      /extended\s*thinking|thinking\s*mode|files\s*API|citations|knowledge\s*base/i,
    ],
    injection_lines: [
      // ★2026-08-06 是正: コネクタ生成器の置き場を ~/.soloptilink/tools/ と書いていたが実体は lib/ 配下。
      "【API統合骨格】外部 API との接続は必ず ~/.soloptilink/lib/ibl.sh detect で該当コネクタを検出し、存在すれば inject、無ければ ~/.soloptilink/lib/connector-forge.sh forge <target> で一発生成. 素の curl / fetch 書き下ろしを禁止する.",
      "【秘密管理】API キー・トークン・OAuth シークレットは必ず .env / 環境変数から参照. SKILL.md・生成コード・ログ・エラーメッセージへの平文埋め込みを一切禁止し、PFP-090 secret-protection-guarantee.sh の scan を通す.",
      "【冪等性と再送】外部書込み API は Idempotency-Key を送出し、指数バックオフ+ジッター (初期 250ms・最大 30s・最大 5 回) + Retry-After 尊重 + 429/5xx 分別再送を実装. webhook 受信は HMAC 署名検証 + timestamp 5 分窓 + nonce 重複排除を必須.",
      "【LLM ルーティング】タスクの性質でモデルを使い分けよ. 下書き/分類/要約は Fable5 (claude-fable-5)、バランスと全コーディングは Sonnet5 (claude-sonnet-5)、最終判断/敵対検証/複雑推論は Opus4.8 (claude-opus-4-8)、大量並列の軽量作業は Haiku4.5. 単一固定モデルで全処理を回すことを禁止.",
      "【Tool use と構造化出力】Anthropic Messages API の tools / tool_choice / parallel tool use を使い、外部 API 呼び出しは必ず tool として宣言. 結果は JSON schema で強制し、バリデーション失敗時は最大 2 回まで LLM に修正再要求してから fail.",
      "【マルチエージェント編成】単発 LLM 呼び出しで完結させず、fan-out (調査) → fan-in (統合) → judge panel (3 人以上奇数の敵対検証) → loop-until-dry (誤り 0 まで反復) の Centuria 105 ロール編成を parallel-exec-v2 で並列駆動. 品質は必ず S11 品質閉ループを通す.",
      "【MCP バインディング】既存 MCP コネクタ (mcp-registry) を優先し、無い場合のみカスタム MCP サーバーを stdio transport で起動. MCP ツールは tool_choice=any で LLM に自律選択させる設計を既定とする.",
      "【観測性と監査】全 API 呼び出しに request_id を付与し、input_tokens / output_tokens / cost_usd / latency_ms / status を S1 資産注入台帳に書き込む. PFP-136 live-browser-smoke で実到達を確認し、失敗経路はダッシュボードに露出.",
      "【顧客可視ゲート】生成スキル内でユーザーが読むメッセージは日本語自然文のみ. API のエラーレスポンス JSON・スタックトレース・curl コマンド・トークン文字列を顧客可視応答に貼ることを禁止 (CLAUDE.md 顧客可視ポリシー準拠).",
      "【テストとモック】単体テストは VCR パターンでリクエスト/レスポンスを固定録画・再生. webhook 署名は正例・改竄例・timestamp 窓外・nonce 重複の 4 パターンを負テストに含める. ゴールデン出力による回帰検知を必須.",
    ],
    quality_axes: [
      { key: "ibl_used", severity: "BLOCK", description_ja: "IBL 検出→注入 or Connector Forge 経由で API 統合されている (素の curl 直書きを禁止)",
        must_any_regex: ["ibl\\.sh (detect|inject)", "connector-forge\\.sh forge"],
        must_not_regex: ["^[^#]*curl -[XH].*https?://[^ ]*api"] },
      { key: "secret_safety", severity: "BLOCK", description_ja: "API キー・トークンが .env / 環境変数参照でありハードコードされていない",
        must_not_regex: ["sk-[A-Za-z0-9]{20,}", "xox[baprs]-[A-Za-z0-9-]{10,}", "AKIA[0-9A-Z]{16}", "ghp_[A-Za-z0-9]{20,}", "Bearer [A-Za-z0-9._-]{40,}"],
        must_any_regex: ["\\.env", "process\\.env", "os\\.environ", "ENV\\["] },
      { key: "retry_idempotency", severity: "FAIL", description_ja: "書込み API に Idempotency-Key + 指数バックオフ + 429/5xx 分別再送 + Retry-After 尊重が実装されている",
        must_any_regex: ["Idempotency-Key", "idempotency_key"],
        must_any_regex_second: ["backoff", "指数バックオフ", "jitter", "Retry-After"] },
      { key: "llm_routing", severity: "FAIL", description_ja: "タスク別に Fable5/Sonnet5/Opus4.8/Haiku4.5 を使い分け (単一固定モデル運用を FAIL)",
        count_distinct_regex: { patterns: ["claude-fable-5", "claude-sonnet-5", "claude-opus-4-8", "claude-haiku-4-5"], min: 2 } },
      { key: "tool_use_schema", severity: "FAIL", description_ja: "Anthropic tool use と JSON schema 強制の structured output が使われている",
        must_any_regex: ["tool_choice", "tools\\s*=\\s*\\[", "input_schema"],
        must_any_regex_second: ["json[- ]?schema", "pydantic", "zod", "validate"] },
      { key: "multiagent_orchestration", severity: "WARN", description_ja: "fan-out/fan-in/judge panel/loop-until-dry のマルチエージェント編成が Centuria/parallel-exec-v2 経由で組まれている",
        must_any_regex: ["fan[- ]?out", "fan[- ]?in", "judge panel", "敵対検証", "loop[- ]?until[- ]?dry", "Centuria", "parallel-exec"] },
      { key: "observability", severity: "WARN", description_ja: "token/cost/latency の記録と S1 台帳・監査ログへの書込が実装されている",
        must_any_regex: ["input_tokens", "output_tokens", "cost_usd", "latency_ms", "S1(台帳|ledger)", "監査ログ"] },
      { key: "mock_test", severity: "WARN", description_ja: "モック/VCR/ゴールデン出力による単体テストと webhook 負テストが定義されている",
        must_any_regex: ["mock", "VCR", "cassette", "golden", "ゴールデン", "リプレイ"] },
    ],
    reference_libraries: [
      "~/.soloptilink/lib/ibl.sh (194+ コネクタ)",
      // ★2026-08-06 是正: tools/ 配下と書いていたが実体は lib/ 配下 (実測で 2 件とも不在だった)
      "~/.soloptilink/lib/connector-forge.sh (一発配線)",
      "~/.soloptilink/lib/parallel-exec-v2.sh (16.5倍並列)",
      "~/.soloptilink/lib/centuria/ (105 ロール Orchestrator)",
      "@anthropic-ai/sdk / anthropic (Messages API + tool use + streaming)",
      "@modelcontextprotocol/sdk (MCP stdio)",
      "mcp-registry (list/search/suggest)",
      "PFP-090 secret-protection-guarantee.sh",
      "S1 asset-injection-ledger",
      "S11 quality-closed-loop",
      "指数バックオフ (p-retry / tenacity / backoff)",
      "VCR/cassette (vcrpy / nock / polly.js)",
    ],
    integration_notes:
      "(1) 起動時に ibl.sh detect で既存コネクタ (194+) を検索、無ければ connector-forge.sh forge で一発生成. (2) LLM 処理は Centuria 105 ロール編成に載せ fan-out → fan-in → judge panel → loop-until-dry を parallel-exec-v2 で 16.5 倍並列. (3) モデル選択は task 性質で分岐 (Fable5/Sonnet5/Opus4.8/Haiku4.5).",
  },
  {
    key: "accounting_tax_finance",
    name_ja: "会計税務 (電帳法/インボイス/freee/MF/勘定奉行)",
    example_skill_name: "soloptilink-accounting-tax-finance",
    law_industry_key: "accounting",
    detection_patterns: [
      /会計.{0,4}(スキル|SKILL\.md|Claude Code).{0,30}(電帳法|インボイス|消費税|仕訳|勘定科目|元帳|T\d{13})/,
      /税務.{0,4}(スキル|SKILL\.md|Claude Code|自動化).{0,30}(電帳法|インボイス|消費税|申告|源泉|年末調整)/,
      /仕訳.{0,6}(自動|生成|登録|API|連携)/,
      /(電帳法|電子取引).{0,6}(保存|要件|タイムスタンプ|真実性)/,
      /インボイス.{0,6}(登録番号|区分記載|検証|判定)/,
      /(消費税|軽減税率).{0,4}(10%|8%|区分|計算)/,
      /(法人税|所得税|源泉).{0,6}(申告|計算|税額|控除)/,
      /freee.{0,4}(API|会計|連携|OAuth)/,
      /(マネーフォワード|MoneyForward|MF ?クラウド).{0,4}(API|連携|会計)/,
      /(勘定奉行|OBIC).{0,4}(連携|API|仕訳)/,
      /弥生.{0,4}(会計|API|連携)/,
      /(会計|経理).{0,4}(業務|システム|自動化).{0,10}(スキル|Claude|SKILL).{0,30}(電帳法|インボイス|消費税|仕訳)/,
      /総勘定元帳.{0,6}(生成|出力|集計)/,
      /(貸借対照表|損益計算書|BS|PL).{0,6}(生成|出力|集計)/,
      /(適格|課税|免税).{0,4}事業者.{0,6}(判定|区分)/,
      /電子取引.{0,6}(真実性|可視性|検索要件)/,
      /(勘定科目|補助科目).{0,6}(マスタ|コード|辞書)/,
      /国税庁.{0,10}(登録番号|Web-?API|公表サイト)/,
      /(e-?Tax|eLTAX).{0,6}(連携|申告|送信)/,
      /会計.{0,4}(仕訳|帳簿|元帳).{0,6}(生成|自動)/,
      /定額減税.{0,20}(年末調整|源泉|給与)/,
      /適格請求書発行事業者公表.{0,10}(API|サイト).{0,20}(照合|検証)/,
      /(EC|楽天|Amazon).{0,30}(仕訳|消費税区分|インボイス).{0,30}(freee|MF|勘定奉行|弥生)/,
    ],
    injection_lines: [
      "- 会計税務ドメイン: 委譲は Centuria の finance-tax-agent / compliance-guardian-agent を優先し、税額計算とインボイス検証を分離する",
      "- 主要ライブラリ: freee-accounting-sdk / moneyforward-cloud-api / obic-openapi / yayoi-api / invoice-jp / e-tax-sdk を実在バージョンで pin する",
      "- 標準規格: 電子取引保存は JIS X 0208 / ISO 8601 / RFC 3161 タイムスタンプ / 国税庁公表 CSV UTF-8-BOM 形式",
      "- 命名規則: テーブルは journal_entries / invoices / tax_ledgers、カラムは registration_no (T+13桁) / tax_rate (8|10) / posting_date (ISO8601)、API パスは /api/v1/journals /api/v1/invoices/verify で固定",
      "- 法令根拠: 電子帳簿保存法第7条 (電子取引保存 4 要件) と消費税法第30条 (仕入税額控除の要件) は必ず注入",
      "- 法令根拠: 法人税法第74条 (確定申告) / 所得税法第183条 (源泉徴収義務) を条文番号付きで明示し、japan-link の recommendLaws('accounting') で自動同梱される旨を明記",
      "- **法令根拠 (2025-2026 最新)**: 定額減税 2024 (年末調整実務), インボイス 2 割特例 (免税事業者経過措置), インボイス 8 割・5 割控除の負担軽減措置, 電帳法スキャナ保存 JIIMA 認証, e-Tax API / eLTAX PCdesk, 適格請求書発行事業者公表サイト API, 改正法人税法の外形標準課税拡大 2026, グローバルミニマム課税 (GloBE 15% ルール), 暗号資産期末時価評価, IT 導入補助金インボイス枠を injection_lines と Q/A テンプレに反映.",
      "- 実装パターン: 税額計算は round_half_up の丸め関数を pure function で分離し、10%/8% は税率マスタで外だし、仕訳生成は借方・貸方の等値ゲートで冪等化",
      "- 実装パターン: freee/MF/勘定奉行/弥生 の API 差分は adapter パターンで吸収し、レート制限・冪等性キー・OAuth トークン失効の 3 種類のエラーハンドリングを必須化",
      "- インボイス検証: T+13桁 の登録番号は国税庁 Web-API で照合し、キャッシュ TTL は 24 時間、失効事業者はブロック",
      "- 電帳法対応: 真実性 / 可視性 / 検索要件 の 3 要件を born-passing テストで検証",
      "- 品質チェック: 単体テストは税額計算/丸め/軽減税率区分で 100% カバレッジ、E2E は「請求書 PDF 取込 → 仕訳生成 → 帳簿記入 → BS/PL 出力」を born-passing で 1 回目から緑",
      "- **law_ai_boundary (税理士法52条越境防止)**: SKILL.md 冒頭に『本スキルは税理士法第52条に鑑み、税務代理・税務書類作成・税務相談を業として行わず、経理業務の記録支援・仕訳の下書き・帳票の集計・電帳法保存の要件チェックに留める』を明記. 税務判断が必要な場面 (交際費/損金算入/インボイス区分の疑義) では『税理士にご確認ください』を強制表示. 電子申告書 (e-Tax) 送信主体は納税者本人または税理士に限る旨を明示. 国税庁『税務事務における生成 AI 活用に関する留意事項』(2024年) を injection.",
      "- 禁止事項: 税理士法第52条 (税理士業務の制限) 抵触の個別税務相談回答生成を禁止し、税額の最終確定判断は税理士監修フラグ必須",
      "- 禁止事項: 弁護士法第72条抵触の税務調査対応助言、および無資格での税務代理・税務書類作成・税務相談生成を明示的にブロック",
      "- 禁止事項: 実在事業者の登録番号を fixture に直書きしない (公表 API モックを使用)、機密性区分 3 の税務データを平文ログに出さない",
      "- **cross_domain 境界**: 単なる『請求書 + 管理』の 2 語ヒットでは発火しない. 電帳法/インボイス/消費税/T+13桁/仕訳/勘定科目/元帳のいずれかとの共起を必須とする. EC 連携案件は『EC 側税率・特商法表記は retail_ecommerce に委譲、仕訳・消費税区分・電帳法保存は本ドメイン主管』.  請求管理 kit の単発依頼は SoloptiLink-template-kit へ流す.",
    ],
    quality_axes: [
      {
        key: "law_citation_completeness",
        description_ja: "電帳法・消費税法・法人税法・所得税法の 4 法令すべてが条文番号付きで引用されていること",
        severity: "FAIL",
        must_all_regex: [/電子帳簿保存法.{0,20}第?7条/, /消費税法.{0,20}第?30条/],
        must_any_regex: [/法人税法.{0,20}第?74条/, /所得税法.{0,20}第?183条/],
      },
      {
        key: "invoice_registration_number_format",
        description_ja: "適格請求書登録番号が T + 13 桁数字の正規表現バリデーション付きで扱われていること",
        severity: "FAIL",
        must_all_regex: [/T\\?\\d\{13\}|T\[0-9\]\{13\}/],
        must_any_regex: [/登録番号.{0,10}(検証|バリデーション|正規表現)/, /国税庁.{0,10}(API|公表サイト)/],
      },
      {
        key: "consumption_tax_rate_separation",
        description_ja: "消費税率 10% と軽減税率 8% が区分され、税率マスタで外だし",
        severity: "FAIL",
        must_all_regex: [/10%/, /8%/],
        must_any_regex: [/軽減税率/, /税率.{0,4}(マスタ|区分|判定)/],
      },
      {
        key: "denchoho_four_requirements",
        description_ja: "電帳法 4 要件 (真実性・可視性・検索要件)",
        severity: "FAIL",
        must_all_regex: [/真実性/, /可視性/, /検索要件/],
        must_any_regex: [/タイムスタンプ|RFC ?3161|訂正削除ログ/],
      },
      {
        key: "api_adapter_pattern",
        description_ja: "freee / MF / 勘定奉行 / 弥生 のいずれか 2 系統以上を adapter で抽象化",
        severity: "FAIL",
        must_any_regex: [/adapter|アダプタ|抽象化/],
        count_distinct_regex: { patterns: [/freee/, /マネーフォワード|MoneyForward|MF ?クラウド/, /勘定奉行|OBIC/, /弥生/], min: 2 },
      },
      {
        key: "professional_law_guardrail",
        description_ja: "税理士法52条または弁護士法72条の禁止事項が明示され、無資格での税務相談生成をブロック",
        severity: "FAIL",
        must_all_regex: [/禁止|ブロック|制限/],
        must_any_regex: [/税理士法.{0,10}第?52条/, /弁護士法.{0,10}第?72条/],
      },
      {
        key: "idempotency_and_double_entry",
        description_ja: "仕訳生成が借方・貸方の等値チェックと冪等性キーで守られている",
        severity: "WARN",
        must_all_regex: [/冪等/],
        must_any_regex: [/借方.{0,10}貸方|複式簿記|double.?entry/],
      },
      {
        key: "born_passing_e2e_flow",
        description_ja: "請求書取込→仕訳→帳簿→BS/PL の E2E が born-passing で 1 回目から緑",
        severity: "WARN",
        must_all_regex: [/born-?passing/],
        must_any_regex: [/(請求書|インボイス).{0,20}(仕訳|帳簿|BS|PL|貸借対照表|損益計算書)/],
      },
      {
        key: "japan_link_industry_binding",
        description_ja: "japan-link recommendLaws('accounting') 経由で法令が自動同梱される旨",
        severity: "WARN",
        must_all_regex: [/japan-?link/, /recommendLaws/],
        must_any_regex: [/accounting/],
      },
      {
        key: "latest_tax_reforms_2024_2026",
        description_ja: "定額減税・2割特例・JIIMA認証・e-Tax API・GloBE のいずれかが明示.",
        severity: "WARN",
        must_any_regex: [/定額減税/, /2\s*割特例/, /JIIMA\s*認証/, /e-Tax\s*API/, /GloBE|グローバルミニマム課税/, /適格請求書発行事業者公表(?:API|サイト)/],
      },
    ],
  },
  {
    key: "care_welfare",
    name_ja: "介護福祉 (介護保険/介護報酬/加算)",
    example_skill_name: "soloptilink-care-welfare",
    law_industry_key: "healthcare",
    detection_patterns: [
      /介護(記録|日誌|ソフト|システム|事業所)[^。\n]{0,40}(スキル|SKILL\.md|Claude\s*Code).{0,40}(?:介護事業所|介護施設|ケアマネ|介護福祉士|訪問介護員|サービス提供責任者|居宅|特養|老健|GH|グループホーム|小規模多機能)/,
      /ケアプラン[^。\n]{0,30}(作成|生成|管理|システム|スキル).{0,40}(?:ケアマネ|介護支援専門員|居宅|事業所)/,
      /(訪問介護|通所介護|デイサービス|ショートステイ|特養|老健|グループホーム|小規模多機能)[^。\n]{0,40}(システム|請求|加算|スキル)/,
      /介護保険[^。\n]{0,30}(請求|給付|報酬|加算|システム)/,
      /(要支援|要介護)[1-5][^。\n]{0,30}(判定|区分|限度額|システム)/,
      /国保連[^。\n]{0,30}(伝送|請求|CSV|返戻)/,
      /(処遇改善|特定処遇改善|ベースアップ|認知症専門ケア|看取り介護|中重度者ケア|サービス提供体制強化)加算/,
      /介護(DX|ICT)[^。\n]{0,30}(加算|導入|補助金)/,
      /(介護|福祉)[^。\n]{0,30}(サービスコード|単位数|地域区分|人件費割合)/,
      /(介護|福祉用具|居宅介護支援)[^。\n]{0,30}(事業者|事業所)[^。\n]{0,30}(システム|スキル|加算)/,
      /モニタリング(記録|表)[^。\n]{0,30}(介護|ケアマネ)/,
      /アセスメントシート[^。\n]{0,30}(介護|居宅|施設)/,
      /(バイタル|排泄|入浴|食事|服薬)記録[^。\n]{0,30}(介護|施設|訪問)/,
      /LIFE[^。\n]{0,30}(科学的介護|フィードバック|提出)/,
      /科学的介護[^。\n]{0,30}(情報|LIFE|加算)/,
      /介護給付費[^。\n]{0,30}(明細書|請求書|返戻|過誤)/,
      /サービス提供票[^。\n]{0,30}(実績|予定|居宅)/,
      /利用者負担[^。\n]{0,30}(割合|1割|2割|3割|高額介護)/,
      /(介護福祉士|ケアマネ|ケアマネジャー|介護支援専門員|訪問介護員|サービス提供責任者|サ責)[^。\n]{0,40}(システム|スキル|台帳)/,
      /身体拘束(廃止|適正化)[^。\n]{0,30}(委員会|指針|記録)/,
      /高齢者虐待[^。\n]{0,30}(防止|通報|マニュアル)/,
      /個別機能訓練[^。\n]{0,30}(計画|加算|記録)/,
      /介護記録[^。\n]{0,30}(電子|ICT|音声入力|システム).{0,40}(?:介護事業所|介護施設|ケアマネ|訪問介護|通所|入所)/,
      /訪問看護.{0,20}(介護保険|介護給付費|介護報酬)/,
    ],
    injection_lines: [
      "- **委譲エージェント**: `centuria-medical-care`, `centuria-japan-law`, `centuria-billing`",
      "- **主要ライブラリ**: `care-record-sdk`, `kokuho-transmission`, `care-service-code`, `jaconv`, `pydantic>=2`, `python-dateutil`",
      "- **標準規格/フォーマット**: 介護給付費請求 CSV は厚労省告示準拠, Shift_JIS (CP932), CRLF, レコード種別 1-9 桁数厳守. JIS Q 15001, TLS 1.2以上",
      "- **命名規則**: `care_` プレフィックス, snake_case, API `/api/v1/care/{resource}`",
      "- **発火主体制限**: 本ドメインは **介護事業所/介護施設/ケアマネ/介護福祉士/訪問介護員/サービス提供責任者を主体とする案件のみ**発火する. 従業員の介護休業取得管理などの HR 案件は hr_labor_management (育児介護休業法) 側に流す.",
      "- **法令根拠 (必須)**: 介護保険法第 41 条 / 第 42 条の 2 / 第 48 条 / 第 118 条. 介護報酬告示 (厚生労働省告示第 19 号) の別表単位数を service_code マスタと照合",
      "- **法令根拠 (必須)**: 高齢者虐待防止法第 21 条 (通報義務), 個人情報保護法第 20 条 (安全管理措置), 老人福祉法第 29 条 (秘密保持). japan-link `recommendLaws('healthcare')` で自動同梱",
      "- **法令根拠 (2024-2026 最新)**: 2024年度介護報酬改定 (基本報酬・加算改定), LIFE データ提出加算, 生産性向上推進体制加算, BCP 未策定減算, 高齢者虐待防止推進体制加算, 看護小規模多機能 (看多機), 介護保険総合データベース (介護 DB), 地域包括ケアシステム 2025 を injection.",
      "- **law_ai_boundary (介護保険法・ケアマネ独占業務越境防止)**: SKILL.md 冒頭に『本スキルは介護保険法に鑑み、居宅介護支援・ケアプラン作成の主体は介護支援専門員 (ケアマネジャー) であり、AI はアセスメント情報の集計・過去プランの検索・作成支援に留める』を明記. ケアプラン第1〜7表の生成物には『ケアマネジャーによる最終確認と署名』を必須フィールド化. 虐待通報義務 (高齢者虐待防止法) と身体拘束禁止 (原則禁止・例外3要件) を guidance に組み込み. 要介護状態は要配慮個人情報として同意取得フローを template 化.",
      "- **実装パターン**: 加算計算は `calc_addition(service_code, care_level, region_class, staff_ratio)` の単一責務関数へ分割. 伝送 CSV 生成は冪等. 金額は Decimal で扱い浮動小数禁止.",
      "- **実装パターン**: ケアプラン第 1〜7 表は状態マシンで管理. LIFE 提出項目 (Barthel Index / DBD-13 / Vitality Index) は `assessment_records` テーブルで版管理",
      "- **品質チェック**: born-passing で `pytest tests/test_calc_addition.py` 全緑, `test_kokuho_csv_layout.py` で CSV レイアウト 1 バイトも差異なきこと. E2E は Playwright で「アセスメント → 第 1 表署名 → 実績入力 → 国保連 CSV DL」",
      "- **品質チェック**: 加算算定要件チェックリストを `assert_addition_eligibility()` で機械検証. 返戻率 5% 超で PagerDuty 通知",
      "- **禁止事項**: 弁護士法第 72 条 (成年後見の要否判断・遺産分割助言等) を生成しない. 医師法第 17 条・第 20 条 (褥瘡ステージ判定・服薬指示・死亡診断) を生成しない. 個人情報保護法第 27 条の同意取得フロー必須",
      "- **禁止事項**: 実在の被保険者番号・介護保険証番号・マイナンバーをサンプルデータに含めない. 虐待疑いを検知しても自動的に 110/自治体通報しない. 加算算定要件を満たさないまま請求 CSV を出力しない",
      "- **cross_domain 境界**: (1) 訪問看護は保険区分により medical_healthcare と共起 — 介護給付費処理は本ドメイン、医療レセ電処理は medical_healthcare、共通の利用者マスタは本ドメイン側で保持. (2) 介護分野の処遇改善加算算定・国保連伝送は本ドメイン主管、加算分の給与配分計算は hr_labor_management に委譲.",
    ],
    quality_axes: [
      {
        key: "care_law_citation_depth",
        description_ja: "介護保険法・介護報酬告示・高齢者虐待防止法の条文番号が明示 + japan-link 経由自動同梱",
        severity: "FAIL",
        must_all_regex: [/介護保険法第\s*[0-9]+\s*条/, /介護報酬告示/, /高齢者虐待防止法/],
        must_any_regex: [/japan-link/, /recommendLaws/],
        count_distinct_regex: { patterns: [/介護保険法第\s*[0-9]+\s*条/, /老人福祉法第\s*[0-9]+\s*条/, /個人情報保護法第\s*[0-9]+\s*条/, /高齢者虐待防止法第\s*[0-9]+\s*条/], min: 2 },
      },
      {
        key: "care_service_code_and_units",
        description_ja: "介護サービスコード (6桁)、単位数、地域区分、人件費割合、要介護度",
        severity: "FAIL",
        must_all_regex: [/介護サービスコード/, /単位数/, /地域区分/],
        must_any_regex: [/6\s*桁/, /人件費割合/, /要介護[1-5]/, /要支援[1-2]/],
        must_not_regex: [/診療報酬点数表/],
      },
      {
        key: "kokuho_transmission_format",
        description_ja: "国保連伝送 CSV の Shift_JIS/CRLF/レコード種別/返戻・過誤",
        severity: "FAIL",
        must_all_regex: [/国保連/, /Shift_JIS|CP932/, /CRLF|\\r\\n/],
        must_any_regex: [/返戻/, /過誤/, /レコード種別/, /伝送区分/],
      },
      {
        key: "care_plan_lifecycle",
        description_ja: "ケアプラン第 1〜7 表・アセスメント・モニタリング・LIFE 提出",
        severity: "WARN",
        must_all_regex: [/ケアプラン/, /アセスメント/, /モニタリング/],
        must_any_regex: [/第\s*[1-7]\s*表/, /LIFE/, /科学的介護/],
      },
      {
        key: "care_addition_types_coverage",
        description_ja: "各種加算 4 系統以上",
        severity: "WARN",
        must_any_regex: [/処遇改善加算/, /特定処遇改善加算/, /ベースアップ/, /認知症専門ケア加算/, /看取り介護加算/, /中重度者ケア/, /サービス提供体制強化/, /生産性向上推進体制加算/],
        count_distinct_regex: { patterns: [/処遇改善加算/, /特定処遇改善加算/, /ベースアップ等支援加算/, /認知症専門ケア加算/, /看取り介護加算/, /中重度者ケア体制加算/, /サービス提供体制強化加算/, /生産性向上推進体制加算/], min: 4 },
      },
      {
        key: "care_prohibited_acts",
        description_ja: "弁護士法72条・医師法違反・不正請求・同意なき第三者提供を禁止",
        severity: "FAIL",
        must_all_regex: [/弁護士法/, /医師法/],
        must_any_regex: [/第\s*72\s*条/, /第\s*17\s*条/, /第\s*20\s*条/],
        must_not_regex: [/法律相談を提供する/, /診断を行う/],
      },
      {
        key: "care_privacy_and_retention",
        description_ja: "介護記録の暗号化保存・5 年保存・アクセスログ・虐待通報導線",
        severity: "WARN",
        must_all_regex: [/個人情報/, /5\s*年/],
        must_any_regex: [/暗号化/, /アクセスログ/, /JIS Q 15001/, /TLS/],
      },
      {
        key: "care_delegation_and_libs",
        description_ja: "委譲エージェント (centuria-*) + 主要ライブラリ",
        severity: "FAIL",
        must_all_regex: [/centuria-/, /care-record-sdk/],
        must_any_regex: [/kokuho-transmission/, /care-service-code/],
      },
      {
        key: "care_naming_convention",
        description_ja: "テーブル名 care_* / API /api/v1/care/*",
        severity: "WARN",
        must_all_regex: [/care_/, /\/api\/v1\/care\//],
        must_any_regex: [/snake_case/, /insured_number/, /care_level/, /service_code/],
      },
      {
        key: "care_quality_gate",
        description_ja: "born-passing / pytest / Playwright / 返戻率",
        severity: "WARN",
        must_all_regex: [/born-passing|born\s*passing/],
        must_any_regex: [/pytest/, /Playwright/, /E2E/, /返戻率/],
      },
      {
        key: "latest_care_2024_2026",
        description_ja: "LIFE / 生産性向上推進体制加算 / BCP未策定減算 / 看多機いずれかへの言及",
        severity: "WARN",
        must_any_regex: [/LIFE/, /科学的介護情報システム/, /生産性向上推進体制加算/, /BCP\s*未策定減算/, /看多機|看護小規模多機能/, /2024年度介護報酬改定/],
      },
    ],
  },
  {
    key: "education_lms",
    name_ja: "教育LMS (学籍/eラーニング/SCORM)",
    example_skill_name: "soloptilink-education-lms",
    law_industry_key: "education",
    detection_patterns: [
      /学籍(?:番号|管理|情報|台帳)/,
      /成績(?:管理|評価|処理|一覧|通知表).{0,40}(?:学生|生徒|児童|受講者|学籍|学校|塾|大学|学習者)/,
      /e[- ]?ラーニング.{0,20}(?:プラットフォーム|構築|システム|教材)/,
      /(?:学習|受講)(?:履歴|進捗|進度|管理)/,
      /教材(?:配信|管理|コンテンツ|ライブラリ)/,
      /コース(?:管理|受講|申込|カタログ)/,
      /(?:小|中|高|大)学校.{0,10}(?:システム|管理|LMS)/,
      /学習塾.{0,10}(?:管理|システム|生徒)/,
      /企業(?:研修|教育|eラーニング)(?:管理)?/,
      /出席(?:管理|簿|状況).{0,20}(?:学校|授業|受講)/,
      /時間割.{0,10}(?:編成|管理|作成)/,
      /履修(?:登録|管理|科目|状況)/,
      /単位(?:認定|取得|管理|数)/,
      /テスト(?:配信|作成|採点|問題|受験)/,
      /小テスト(?:配信|作成|採点)?/,
      /(?:受講者|学習者|生徒|児童|学生)(?:管理|登録|一覧|情報)/,
      /教員(?:管理|情報|アカウント|評価)/,
      /通知表.{0,10}(?:作成|出力|生成)/,
      /調査書.{0,10}(?:作成|出力)/,
      /指導要録.{0,10}(?:電子化|管理|作成)/,
      /SCORM.{0,10}(?:教材|コンテンツ|パッケージ|準拠)/,
      /xAPI.{0,10}(?:準拠|送信|連携|ステートメント)/,
      /LRS.{0,10}(?:連携|送信|導入)/,
      /(?:授業|講義)(?:動画|配信|録画|コンテンツ)/,
      /MEXCBT.{0,20}(連携|接続|導入)/,
      /校務DX|次世代校務支援システム/,
      /LTI\s*Advantage/,
    ],
    injection_lines: [
      "- **委譲エージェント**: `centuria-education-lms`, `centuria-compliance-privacy`",
      "- **主要ライブラリ (Node.js)**: `scorm-again`, `@xapi/xapi`, `@rusticisoftware/tincan`, `moodle-client`",
      "- **主要ライブラリ (Python)**: `pyxapi`, `scormcloud-api-v2`, `openedx-learner-api`",
      "- **標準規格準拠**: SCORM 2004 4th Edition の CMI データモデル と xAPI 1.0.3 (IEEE 9274.1.1) Statement 構造 (actor / verb / object / result / context)",
      "- **文字コード**: 内部保存は UTF-8 (NFC正規化) 固定. 外部連携 CSV は文教CSV形式 (BOM付 UTF-8) を既定",
      "- **命名規則**: `students` / `enrollments` / `courses` / `lessons` / `scorm_activities` / `xapi_statements` / `grade_records` / `attendance_logs`. `student_lid` (UUID v7), `student_no`. API `/api/v1/lms/students/{lid}/enrollments`",
      "- **法令根拠 (自動同梱)**: 学校教育法 第28条 / 第30条, 学校教育法施行規則 第24条 (指導要録の作成・保存 5年/20年). japan-link `recommendLaws('education')` により学習指導要領・教育基本法が自動同梱",
      "- **法令根拠 (個人情報・著作権)**: 個人情報保護法 第20条 (要配慮個人情報の取得制限), 著作権法 第35条 (授業目的公衆送信補償金/SARTRAS) 適合",
      "- **法令根拠 (2024-2025 最新)**: GIGA スクール NEXT (第 2 期), 教育データ利活用ロードマップ, 校務 DX/次世代校務支援システム, 個別最適な学び, デジタル教科書無償化 (小中), 大学入学共通テスト 情報 I, 生成 AI の学校教育ガイドライン 2024, 学習 e ポータル, MEXCBT, LTI Advantage を injection.",
      "- **実装パターン**: SCORM ランタイム API (LMSInitialize/LMSSetValue/LMSCommit/LMSFinish) は必ずエラーコードを返却する冪等関数. xAPI Statement 送信は指数バックオフ, LRS 到達失敗時は outbox キューイング",
      "- **品質チェック**: SCORM パッケージ (imsmanifest.xml) の XSD 検証, xAPI Statement の JSON Schema 検証, 学籍番号の重複禁止制約, 成績評定値の値域チェック",
      "- **E2E テスト**: 学習者ログイン → コース選択 → SCORM 教材起動 → 進捗保存 → LMSFinish → 成績記録 → 指導要録反映",
      "- **禁止事項 (法令遵守)**: 教員免許を持たないユーザに正式な成績評定確定権限を UI から与えない (校務分掌ロールで縛る). 学校教育法施行規則 第28条違反となる指導要録の5年未満削除, 学校保健安全法 第7条違反となる保健情報の目的外利用禁止",
      "- **禁止事項 (子ども情報)**: 18歳未満の学習者データを海外 LRS へ本人・保護者同意なく送信禁止 (個人情報保護法 第28条). SCORM 教材の著作権表示 (© / ライセンス条項) を削除・改変しない",
      "- **cross_domain 境界**: (1) 企業研修文脈で 36 協定/労働時間との連動要求があれば hr_labor_management と併走し、労働時間該当性は本ドメインでは判断せずデータ提供のみ. (2) 発火主体は学生/生徒/児童/受講者/学籍/学校/塾/大学. 営業/業績/KPI 文脈での『成績』は本ドメイン非該当.",
    ],
    quality_axes: [
      {
        key: "scorm_xapi_standard_compliance",
        description_ja: "SCORM 2004 / xAPI 標準規格への準拠",
        severity: "FAIL",
        must_all_regex: [/SCORM\s*2004/, /xAPI|Tin\s*Can/],
        must_any_regex: [/cmi\.core\.|cmi\.interactions|cmi\.objectives/, /LMSInitialize|LMSSetValue|LMSCommit|LMSFinish/, /actor.{0,30}verb.{0,30}object/, /LRS/],
      },
      {
        key: "education_law_grounding",
        description_ja: "学校教育法・施行規則・学習指導要領の条文2件以上",
        severity: "FAIL",
        must_any_regex: [/学校教育法(?:施行規則)?\s*第\s*\d+\s*条/, /学習指導要領/, /教育基本法\s*第\s*\d+\s*条/],
        count_distinct_regex: { patterns: [/学校教育法\s*第\s*\d+\s*条/, /学校教育法施行規則\s*第\s*\d+\s*条/, /学習指導要領/, /教育基本法\s*第\s*\d+\s*条/, /私立学校法\s*第\s*\d+\s*条/], min: 2 },
      },
      {
        key: "student_data_privacy",
        description_ja: "個人情報保護法・要配慮個人情報・未成年データ・越境移転規制",
        severity: "FAIL",
        must_all_regex: [/個人情報保護法/],
        must_any_regex: [/要配慮個人情報|第\s*20\s*条/, /越境移転|第\s*28\s*条/, /未成年|18歳未満|保護者同意/],
      },
      {
        key: "copyright_education_exception",
        description_ja: "著作権法第35条 (SARTRAS)",
        severity: "WARN",
        must_all_regex: [/著作権法/],
        must_any_regex: [/第\s*35\s*条/, /SARTRAS|授業目的公衆送信/],
      },
      {
        key: "lms_domain_libraries",
        description_ja: "SCORM/xAPI/LMS 系ライブラリ2件以上",
        severity: "FAIL",
        count_distinct_regex: { patterns: [/scorm-again/, /@xapi\/xapi|xapi-node/, /tincan|@rusticisoftware\/tincan/, /moodle-client|moodle-sdk/, /pyxapi|scormcloud/, /openedx/], min: 2 },
      },
      {
        key: "naming_convention_lms",
        description_ja: "LMS 特有のテーブル/カラム/API 命名規則",
        severity: "FAIL",
        must_any_regex: [/students|enrollments|courses|scorm_activities|xapi_statements|grade_records/],
        count_distinct_regex: { patterns: [/students/, /enrollments/, /courses/, /scorm_activities|xapi_statements/, /grade_records|attendance_logs/, /student_lid|student_no/], min: 3 },
      },
      {
        key: "shidoyoroku_retention",
        description_ja: "指導要録の保存年限 (5年・20年)",
        severity: "WARN",
        must_any_regex: [/指導要録/, /5\s*年.{0,20}(?:保存|保管)/, /20\s*年.{0,20}(?:保存|保管)/],
      },
      {
        key: "role_based_access_school",
        description_ja: "校務分掌に基づくロール制御",
        severity: "FAIL",
        must_all_regex: [/(?:ロール|権限|RBAC|校務分掌)/],
        must_any_regex: [/教員|校長|事務職員|担任/],
      },
      {
        key: "born_passing_and_e2e",
        description_ja: "born-passing + SCORM/xAPI E2E",
        severity: "FAIL",
        must_all_regex: [/born[- ]passing/],
        must_any_regex: [/Playwright|Cypress|E2E/, /imsmanifest\.xml|XSD|JSON\s*Schema/],
      },
      {
        key: "latest_education_2024_2025",
        description_ja: "MEXCBT / 学習eポータル / 校務DX / LTI Advantage / 生成AI学校ガイドラインいずれか",
        severity: "WARN",
        must_any_regex: [/MEXCBT/, /学習eポータル/, /校務DX|次世代校務支援システム/, /LTI\s*Advantage/, /生成AIの学校教育ガイドライン/, /デジタル教科書/, /GIGAスクール\s*NEXT/],
      },
    ],
  },
  {
    key: "hr_labor_management",
    name_ja: "HR労務管理 (労基/36協定/勤怠/給与)",
    example_skill_name: "soloptilink-hr-labor-management",
    law_industry_key: "hr",
    detection_patterns: [
      /36協定.{0,40}(?:勤怠システム|給与計算|労務管理|人事システム|社労士|労基署.*届出)/,
      /時間外労働の上限規制.{0,40}(?:勤怠システム|給与計算|労務管理|人事システム)/,
      /月45時間.{0,10}年360時間.{0,40}(?:勤怠システム|給与計算|労務管理|人事システム)/,
      /特別条項.{0,40}(?:36協定|勤怠|労務管理)/,
      /労基署(への|に).{0,5}(届出|申請|報告).{0,40}(?:勤怠システム|労務管理|人事システム|給与計算)/,
      /打刻(データ|漏れ|修正)/,
      /勤怠(締め|集計|打刻)/,
      /残業時間.{0,10}(集計|管理|上限)/,
      /みなし労働時間/,
      /フレックスタイム制/,
      /変形労働時間制/,
      /裁量労働制/,
      /所定労働時間/,
      /有給休暇.{0,5}(付与|管理|残日数)/,
      /年5日.{0,5}有給.{0,5}取得義務/,
      /給与計算(ロジック|エンジン|システム)/,
      /社会保険.{0,5}(算定|月額変更|随時改定)/,
      /算定基礎届/,
      /月額変更届/,
      /労働保険料.{0,5}(申告|年度更新)/,
      /源泉徴収(税|票)/,
      /年末調整/,
      /マイナンバー.{0,5}(収集|保管|廃棄)/,
      /雇用形態(区分|マスタ)/,
      /育児休業.{0,5}(取得|給付金)/,
      /介護休業.{0,5}(取得|給付金)/,
      /ストレスチェック(制度|義務)/,
      /障害者雇用率/,
      /同一労働同一賃金/,
      /パートタイム有期雇用労働法/,
      /社会保険適用拡大.{0,30}(2024|51人|従業員)/,
      /フリーランス保護新法.{0,30}(業務委託|労務|人事)/,
    ],
    injection_lines: [
      "- 委譲エージェント: `centuria-hr-labor-officer`, `centuria-payroll-calculator`, `centuria-compliance-auditor`, `centuria-social-insurance-broker` を並列起動. 単一エージェントに集約しない.",
      "- 主要ライブラリ: `smarthr-api`, `@kingoftime/api-client`, `jobcan-api-client`, `freee-hr-sdk`, `sr-supportsql`. 自作HTTPクライアントは冪等性・リトライ・レート制限を必ず実装.",
      "- 標準規格: マイナンバー JIS X 0401/0402, 全銀EDI/ISO 20022 pain.001, e-Gov API (REST/JSON), 雇用保険被保険者番号は11桁ハイフン区切り, 健康保険等級表 (協会けんぽ最新版).",
      "- 命名規則: テーブルは `hr_employees` / `hr_attendance_records` / `hr_payroll_slips` / `hr_36_agreements` / `hr_social_insurance_grades`. API パスは `/api/v1/hr/{resource}` (kebab-case複数形). カラムは snake_case. 金額は円単位 integer.",
      "- 発火主体制限: 本ドメインは **企業の労務/人事/勤怠/給与主体の案件のみ**発火する. kit=経費精算/工事台帳/介護記録等の他ドメイン kit 主眼案件では発火せず、労務は補助として injection のみ. 単なる『36協定 + 労基署』の 2 語ヒットでは発火しない.",
      "- 法令根拠 (japan-link `recommendLaws(\"hr\")` で自動同梱): 労働基準法 32条 / 36条 / 37条 / 39条 / 89条. 育児介護休業法 5条 / 11条. 障害者雇用促進法 43条.",
      "- 法令根拠 (追加同梱): 労働安全衛生法 66条の10 (ストレスチェック) / 66条 (健康診断). パートタイム有期雇用労働法 8条. 男女雇用機会均等法 6-9条. 個人情報保護法. マイナンバー法 19条 / 20条.",
      "- **法令根拠 (2024-2026 最新)**: 改正育児介護休業法 2025年4月 (柔軟な働き方), 女性活躍推進法・男女賃金差公表義務, 改正労働安全衛生法 (化学物質規制), パワハラ防止措置義務, 特定技能 2 号拡大, フリーランス保護新法 (2024年11月), 高年齢者雇用安定法 (70歳就業機会確保努力義務), 改正雇用保険法 (2024年), マイナンバー健康保険証, 社会保険適用拡大 (2024年10月 従業員 51 人以上) を injection.",
      "- **law_ai_boundary (社労士法27条越境防止)**: SKILL.md 冒頭に『本スキルは社会保険労務士法第27条に鑑み、労働社会保険諸法令に基づく書類 (36協定/就業規則/労働保険/社会保険算定基礎届等) の作成・提出代行を業として行わない. 作成主体は事業主または委託を受けた社会保険労務士に限る』を明記. 労基署提出書類・年金機構提出書類の出力時に『事業主または顧問社労士による最終確認』を必須ステップに組み込み. 就業規則・36協定の労働者代表選出プロセス (民主的手続き) を guidance として提示. 提携社労士連携フローを template として提供.",
      "- 実装パターン: 勤怠→給与→社保の3段パイプラインは各段で `pure function` 化. `calculate_overtime()` / `calculate_gross_salary()` / `calculate_social_insurance()` を分離. 丸め処理は「1分単位管理・切り捨て禁止 (労基法37条通達)」. 全処理を冪等・トランザクション境界で ACID 保証.",
      "- エラーハンドリング: 36協定上限超過は `Overtime36LimitExceededError` を送出. 月45h/年360h/複数月平均80h/単月100h を独立チェック. 特別条項適用時は年6回・年720h・複数月平均80h・単月100h未満の4条件AND判定.",
      "- 品質チェック: born-passing で最低賃金 (地域別) 検証・36協定境界値 (44h59min/45h00min)・産休育休期間の社保免除・随時改定 (2等級以上変動) の単体テスト必須. E2E は SmartHR sandbox または `msw` で API モックし、月末締め処理をゴールデンレコードで検証.",
      "- 禁止事項: 弁護士法72条により個別労使紛争の法律判断・示談交渉の代理は不可 (社労士/弁護士へエスカレーション). 社会保険労務士法 27条により、社労士独占業務の無資格代行を禁止. 医師法17条により、ストレスチェック結果の医学的診断は産業医委託必須.",
      "- 禁止事項 (データ保護): マイナンバーは目的外利用禁止・利用終了時は速やかに廃棄・アクセスログ7年保存 (マイナンバー法12条). 人事評価/病歴は要配慮個人情報として本人同意なき第三者提供禁止. 給与データは最低3年保存 (労基法109条).",
      "- 参照ドキュメント: 厚労省「時間外労働の上限規制わかりやすい解説」・日本年金機構「算定基礎届の記入・提出ガイドブック」・協会けんぽ「保険料額表」・e-Gov電子申請API仕様書 を SKILL.md 冒頭の References に明記.",
      "- **cross_domain 境界**: (1) 社員研修は education_lms と共起、勤怠連動判定 (研修時間の労働時間該当性) のみ本ドメインが主管し、教材配信・受講記録は education_lms へ委譲. (2) 従業員の介護休業取得管理は本ドメイン (育児介護休業法) 側で受け、介護事業所側の介護保険業務は care_welfare へ. (3) 介護分野の処遇改善加算算定・国保連伝送は care_welfare 主管、加算分の給与配分計算は本ドメインで受ける.",
    ],
    quality_axes: [
      {
        key: "law_citations_present",
        description_ja: "労働基準法・36協定・関連法令の条文番号 2箇所以上",
        severity: "FAIL",
        must_all_regex: [/36協定/, /recommendLaws/],
        must_any_regex: [/労働基準法\s*(第)?\s*3[267]\s*条/, /労働基準法\s*(第)?\s*39\s*条/, /労働安全衛生法\s*(第)?\s*66\s*条/, /育児介護休業法\s*(第)?\s*[0-9]+\s*条/, /マイナンバー法\s*(第)?\s*[0-9]+\s*条/],
      },
      {
        key: "delegation_agents_named",
        description_ja: "委譲エージェント centuria-* 2種以上",
        severity: "FAIL",
        count_distinct_regex: { patterns: [/centuria-hr-[a-z-]+/, /centuria-payroll-[a-z-]+/, /centuria-compliance-[a-z-]+/, /centuria-social-insurance-[a-z-]+/], min: 2 },
      },
      {
        key: "library_realistic",
        description_ja: "SmartHR/KING OF TIME/ジョブカン/freee人事労務 系",
        severity: "FAIL",
        must_any_regex: [/smarthr-api/, /@kingoftime\/api-client/, /kingoftime-api/, /jobcan-api/, /freee-hr-sdk/, /freeehr-api/, /sr-supportsql/],
        must_not_regex: [/fake-hr-lib/, /sample-payroll-sdk/],
      },
      {
        key: "naming_convention_locked",
        description_ja: "hr_ prefix / /api/v1/hr/ / snake_case",
        severity: "FAIL",
        must_all_regex: [/hr_employees/, /\/api\/v1\/hr\//, /snake_case/],
      },
      {
        key: "overtime_36_limit_logic",
        description_ja: "36協定上限 (月45h/年360h) + 特別条項 (年720h/複数月平均80h/単月100h)",
        severity: "FAIL",
        must_all_regex: [/月\s*45\s*(時間|h)/, /年\s*360\s*(時間|h)/],
        must_any_regex: [/年\s*720\s*(時間|h)/, /単月\s*100\s*(時間|h)/, /複数月.{0,5}平均\s*80\s*(時間|h)/],
      },
      {
        key: "prohibited_practices_stated",
        description_ja: "弁護士法72条・社労士法27条・医師法17条の無資格業務禁止",
        severity: "FAIL",
        must_any_regex: [/弁護士法\s*(第)?\s*72\s*条/, /社会保険労務士法\s*(第)?\s*27\s*条/, /医師法\s*(第)?\s*17\s*条/],
      },
      {
        key: "privacy_mynumber_handling",
        description_ja: "マイナンバー・要配慮個人情報の取扱い制限",
        severity: "FAIL",
        must_all_regex: [/マイナンバー/, /要配慮個人情報|個人情報保護法/],
        must_any_regex: [/目的外利用禁止/, /第三者提供/, /アクセスログ|7年保存|3年保存/],
      },
      {
        key: "quality_gate_born_passing",
        description_ja: "born-passing + 境界値 + E2E モック",
        severity: "FAIL",
        must_all_regex: [/born-passing/, /境界値|ゴールデンレコード|E2E/],
        must_not_regex: [/テストは省略/, /テストなし/],
      },
      {
        key: "no_hr_domain_scope_leak",
        description_ja: "HR業種スキル管理 (人材スキル台帳/教育管理) 系記述に流出していない",
        severity: "WARN",
        must_not_regex: [/人材[ ]?スキルマップ.{0,10}管理システム/, /研修受講履歴のみ/, /1on1\s*面談記録専用/, /エンゲージメントサーベイ専用/],
      },
      {
        key: "payroll_calc_pure_function",
        description_ja: "給与計算・社保計算の pure function 分離と冪等性",
        severity: "WARN",
        must_all_regex: [/冪等/],
        must_any_regex: [/pure\s*function/, /calculate_overtime|calculate_gross_salary|calculate_social_insurance/],
      },
      {
        key: "latest_hr_2024_2026",
        description_ja: "社会保険適用拡大/フリーランス保護新法/女性活躍男女賃金差/特定技能2号/パワハラ防止/改正雇用保険法 いずれか",
        severity: "WARN",
        must_any_regex: [/社会保険適用拡大/, /フリーランス保護新法/, /女性活躍推進法.*男女賃金差/, /特定技能\s*2号/, /パワハラ防止措置義務/, /改正雇用保険法/],
      },
    ],
  },
  {
    key: "legal_document",
    name_ja: "法務 (契約書レビュー/弁護士法/電子契約)",
    example_skill_name: "soloptilink-legal-document",
    law_industry_key: "legal",
    detection_patterns: [
      /契約書.{0,10}(レビュー|チェック|差分|比較|抽出|条項抽出|リスク判定|法令根拠)/,
      /(NDA|秘密保持契約|業務委託契約|請負契約|準委任契約|売買契約|賃貸借契約).{0,20}(レビュー|チェック|差分|条項抽出|リスク判定)/,
      /電子契約.{0,20}(締結|署名|API|連携|スキル|SKILL)/,
      /電子署名.{0,20}(検証|タイムスタンプ|長期署名|PAdES|XAdES|CAdES)/,
      /下請.{0,20}(発注書|3条書面|5条書面|支払遅延|買いたたき)/,
      /印紙.{0,15}(貼付|税額|第[0-9]+号)/,
      /契約.{0,10}(条項|条文|文言).{0,10}(抽出|指摘|リスク)/,
      /リーガル.{0,10}(チェック|レビュー|テック)/,
      /(弁護士|法律事務所).{0,15}(監修|連携|チェック)/,
      /紛争.{0,10}(予防|解決|条項)/,
      /(準拠法|管轄|専属的合意管轄).{0,15}(条項|指摘|抽出)/,
      /特商法|特定商取引法/,
      /消費者契約法.{0,20}(不当条項|10条|8条|9条)/,
      /個人情報.{0,10}(取扱条項|データ処理契約|DPA)/,
      /反社(会的勢力)?.{0,10}(排除|条項)/,
      /(印影|電子印鑑|実印|認印).{0,15}(検証|確認|抽出)/,
      /AI.{0,10}(契約書|法務|リーガル).{0,10}(生成|作成|レビュー).{0,20}(条項抽出|差分|法令根拠|リスク)/,
      /書面.{0,10}(3条|5条|下請).{0,10}(生成|チェック|審査)/,
      /契約.{0,10}(ライフサイクル|CLM|管理).{0,10}(SKILL|Claude Code|スキル|生成)/,
      /eシール|タイムスタンプ.{0,10}(RFC3161|検証)/,
      /フリーランス保護新法.{0,30}(業務委託|下請|レビュー)/,
    ],
    injection_lines: [
      "- **委譲エージェント**: `legal-review-agent` (契約書差分抽出/リスク指摘), `esign-orchestrator-agent`, `stamp-tax-classifier-agent`, `subcontract-act-auditor-agent`",
      "- **主要ライブラリ**: `docusign-esign`, `cloudsign-api`, `@gmo-sign/sdk`, `adobe-sign-sdk`, `clm-sdk`, `contract-io`, `pdf-lib`, `node-forge`. Python 側は `python-docx` + `pypdf` + `signxml`",
      "- **標準規格/フォーマット**: PAdES (ETSI EN 319 142) / XAdES (EN 319 132) / CAdES (EN 319 122), タイムスタンプ RFC 3161, 長期署名 ISO 14533 / PAdES-LTV. 契約書ID は `LGL-{YYYYMMDD}-{類型コード2桁}-{連番4桁}`",
      "- **命名規則**: `contracts` / `contract_versions` / `contract_clauses` / `esign_envelopes` / `stamp_tax_assessments` / `subcontract_notices`. API `/api/v1/contracts/{contract_id}/clauses`",
      "- **law_ai_boundary (弁護士法72条 強制越境防止)**: (1) SKILL.md 冒頭に『本スキルは弁護士法第72条の趣旨に鑑み、法律事件に関する法律事務 (鑑定/代理/仲裁/和解) を行わず、契約書の形式チェック・条項抽出・法令引用・リスク箇所の提示に留める』を明記. (2) 生成されたレビュー結果 UI に『本結果は AI による情報整理であり法的助言ではありません。最終判断は必ず弁護士にご確認ください』の disclaimer を全画面ヘッダに強制表示. (3) 出力 PDF/Word のヘッダフッタにも同 disclaimer を自動挿入. (4) 業務規制チェックとして『登記申請書生成/税務相談/官公署提出書類代行/示談交渉/和解案提示』を生成禁止語彙として quality_gate で BLOCK. (5) `assert_no_legal_judgment()` linter で SKILL.md 全出力を CI ゲート.",
      "- **法令根拠 (契約類型別)**: 電子署名法 第3条 (真正推定), 電子帳簿保存法 第7条, 下請法 第3条 / 第4条, 印紙税法 別表第一 第1〜20号文書, 民法 第415条 / 第522条 / 第632条 / 第643条, 消費者契約法 第8〜10条, 特商法 を japan-link `recommendLaws('legal')` で自動同梱.",
      "- **法令根拠 (2025-2026 最新)**: フリーランス保護新法 (特定受託事業者に係る取引の適正化等に関する法律, 2024年11月施行), 改正下請法 2026 (価格転嫁対応), AI 事業者ガイドライン 2024年4月 (人間関与の原則), 改正個人情報保護法 3年ごと見直し 2025, 経済安全保障推進法・特定重要技術, 改正公益通報者保護法, 改正商業登記法・オンライン登記. LegalOn / MNTSQ / リーガルフォース 等の主要 API との連携パターンを template 化.",
      "- **実装パターン**: 契約書パースは (1) テキスト抽出→(2) 条項ツリー化→(3) 標準条項テンプレとの差分→(4) リスクラベリング→(5) 弁護士監修フラグ の 5 関数. 電子契約 API 呼び出しは指数バックオフ + Idempotency-Key. LLM 呼び出しは system prompt に「弁護士法72条遵守」を強制注入.",
      "- **品質チェック**: born-passing で契約書サンプル (NDA / 業務委託 / 請負 / 賃貸借) を fixture 化. 単体テストは条項抽出 (Jaccard係数 ≥ 0.85), 印紙税分類, 下請法3条書面必須10項目. E2E は CloudSign sandbox または DocuSign demo",
      "- **禁止事項1 (弁護士法72条)**: (a) 個別事案への法的助言, (b) 契約条項の有効/無効の断定, (c) 相手方との交渉代理, (d) ADR の代理, (e) 「勝訴確率」「損害賠償額の予測」の提示 を全面禁止.",
      "- **禁止事項2 (関連士業法)**: 司法書士法 第3条 (登記代理), 税理士法 第52条, 行政書士法 第1条の2 の各独占業務に該当する出力を禁止. 電子帳簿保存法対応で「税務署長への申請書代行」は不可.",
      "- **禁止事項3 (データ保護)**: 契約書本文の氏名/住所/金額は `***` マスキング必須. 外部 LLM 送信時は個人情報保護法 第27条同意フロー実装. GDPR 対象契約は EU リージョン強制.",
      "- **japan-link 連携**: `japan-link.recommendLaws('legal')` が弁護士法/電子署名法/電子帳簿保存法/下請法/印紙税法/民法(債権法)/消費者契約法/特商法/フリーランス保護新法 の 9 法令を自動注入.",
      "- **禁止事項4 (成果物)**: 「これは有効な契約です」「この条項は無効です」「支払わなくてよい」等の断定表現を出力に含めない.",
      "- **cross_domain 境界**: (1) 建設下請の 3 条/5 条書面は construction_drawing 側の下請書面テンプレを優先し、本ドメインは法令根拠と条項レビューのみ副次的に担当. (2) 営業 CRM の契約書テンプレ生成のみの依頼 (レビュー/条項抽出/リスク判定が伴わない) は sales kit 側に流す — 単なる『契約書 + 生成』では発火しない.",
    ],
    quality_axes: [
      {
        key: "bengoshi_ho_72_disclaimer",
        description_ja: "弁護士法72条ディスクレーマの明示",
        severity: "FAIL",
        must_all_regex: [/弁護士法.{0,10}(第)?72条/, /(法的判断|法律相談|非弁).{0,30}(禁止|回避|しない|除外)/],
        must_any_regex: [/最終判断.{0,10}(弁護士|専門家)/, /形式(的)?(チェック|差分|抽出)/],
        must_not_regex: [/法的.{0,5}アドバイス.{0,5}(提供|行う)/, /有効.{0,5}(と|であると).{0,5}(判断|断定)/, /無効.{0,5}(と|であると).{0,5}(判断|断定)/],
      },
      {
        key: "electronic_signature_law_grounding",
        description_ja: "電子署名法・電帳法の条文根拠と標準規格 (PAdES/RFC3161)",
        severity: "FAIL",
        must_all_regex: [/電子署名法|電子署名及び認証業務に関する法律/, /電子帳簿保存法/],
        must_any_regex: [/PAdES|XAdES|CAdES/, /RFC ?3161/, /第3条.{0,10}(真正推定|推定)/, /タイムスタンプ/],
      },
      {
        key: "subcontract_act_coverage",
        description_ja: "下請法3条書面と4条禁止事項",
        severity: "FAIL",
        must_all_regex: [/下請(代金支払遅延等防止)?法/, /(3条|三条).{0,10}(書面|発注)/],
        must_any_regex: [/4条|四条|禁止事項/, /支払遅延|買いたたき|受領拒否/, /検収期日|支払期日|手形サイト/],
      },
      {
        key: "stamp_tax_classification",
        description_ja: "印紙税法の第1〜20号文書区分",
        severity: "FAIL",
        must_all_regex: [/印紙税(法)?/, /(第)?1(〜|-|から)20号文書|第[0-9]+号文書/],
        must_any_regex: [/別表第一|類型分類|機械的(分類|判定)/],
        must_not_regex: [/税務代理|税額.{0,5}確定判断/],
      },
      {
        key: "civil_code_reform_reference",
        description_ja: "民法債権法改正の主要条文 2つ以上",
        severity: "WARN",
        must_all_regex: [/民法/],
        must_any_regex: [/第415条|第522条|第632条|第643条|債権法改正/],
        count_distinct_regex: { patterns: [/第415条/, /第522条/, /第632条/, /第643条/, /債権法改正/], min: 2 },
      },
      {
        key: "esign_library_and_naming",
        description_ja: "電子契約 API ライブラリと ID/テーブル/API 命名",
        severity: "FAIL",
        must_all_regex: [/docusign-esign|cloudsign-api|@gmo-sign|adobe-sign/, /contracts|contract_clauses|esign_envelopes/],
        must_any_regex: [/\/api\/v1\/contracts|\/api\/v1\/esign/, /LGL-\{|LGL-[0-9]/],
      },
      {
        key: "delegation_and_related_law_bounds",
        description_ja: "委譲エージェント + 関連士業法越境禁止",
        severity: "WARN",
        must_all_regex: [/(legal-review-agent|esign-orchestrator-agent|stamp-tax-classifier-agent|subcontract-act-auditor-agent)/],
        must_any_regex: [/司法書士法|税理士法|行政書士法/, /独占業務.{0,10}(禁止|該当しない|回避)/],
        count_distinct_regex: { patterns: [/legal-review-agent/, /esign-orchestrator-agent/, /stamp-tax-classifier-agent/, /subcontract-act-auditor-agent/], min: 2 },
      },
      {
        key: "japan_link_and_pii_protection",
        description_ja: "japan-link 連携 + 個人情報/営業秘密マスキング",
        severity: "WARN",
        must_all_regex: [/japan-link|recommendLaws/],
        must_any_regex: [/個人情報保護法|第27条/, /マスキング|\*\*\*/],
        must_not_regex: [/個人情報.{0,10}(平文|そのまま).{0,10}(送信|保存)/],
      },
      {
        key: "born_passing_and_e2e",
        description_ja: "born-passing fixture と電子契約 sandbox E2E",
        severity: "WARN",
        must_all_regex: [/born-passing|fixture/, /(sandbox|demo).{0,20}(CloudSign|DocuSign|GMO|Adobe)/],
        must_any_regex: [/Jaccard|一致度/, /E2E/],
      },
      {
        key: "latest_legal_2024_2026",
        description_ja: "フリーランス保護新法・改正下請法2026・AI事業者ガイドライン・LegalOn/MNTSQ いずれかへの言及",
        severity: "WARN",
        must_any_regex: [/フリーランス保護新法/, /改正下請法\s*2026/, /AI事業者ガイドライン/, /LegalOn|MNTSQ|リーガルフォース/, /PAdES-LTV/],
      },
    ],
  },
  {
    key: "logistics_transportation",
    name_ja: "物流輸送 (貨物利用運送/送り状/追跡)",
    example_skill_name: "soloptilink-logistics-transportation",
    law_industry_key: "logistics",
    detection_patterns: [
      /(送り状|伝票).{0,20}(EDI|発行|印刷|生成)/,
      /(輸配送|配車|運行).{0,15}(計画|管理|最適化|自動化)/,
      /(WMS|倉庫管理システム).{0,20}(構築|設計|連携|実装).{0,40}(?:荷主|運送会社|物流倉庫|宅配|3PL)/,
      /(貨物|荷物|荷).{0,10}(追跡|トラッキング|ステータス)/,
      /(ヤマト運輸|佐川急便|日本郵便|西濃運輸|福山通運).{0,20}(API|連携|集荷|B2)/,
      /(TMS|輸配送管理).{0,15}(スキル|Skill|SKILL\.md|Claude Code)/,
      /(改善基準告示|拘束時間|運転時間).{0,20}(遵守|チェック|管理)/,
      /(3PL|4PL|フォワーダ|フォワーダー).{0,15}(業務|システム|管理)/,
      /(コールドチェーン|温度帯|定温|冷蔵|冷凍).{0,15}(輸送|保管|記録)/,
      /(ドライバー|運転者).{0,10}(日報|点呼|勤怠|拘束時間)/,
      /(JAN.{0,3}コード|GTIN|SSCC).{0,15}(採番|生成|読取|バーコード)/,
      /(車両|トラック|運行).{0,10}(日報|管理|割当|配車)/,
      /(荷主|着荷主|元請|下請).{0,15}(管理|EDI|請求)/,
      /(集荷|配達|再配達).{0,15}(登録|依頼|自動化)/,
      /(運賃|料金|タリフ).{0,15}(計算|表|請求)/,
      /(倉庫|保管|入出庫|棚卸).{0,15}(管理|記録|自動化).{0,40}(?:荷主|運送会社|物流倉庫|宅配|3PL)/,
      /(乗務員|運行管理者|安全運転管理者).{0,20}(選任|台帳|管理)/,
      /(貨物|運送).{0,10}(利用運送|自動車運送).{0,10}(事業|届出|許可)/,
      /(デジタコ|デジタルタコグラフ|運行記録計).{0,15}(連携|取込|解析)/,
      /2024年問題.{0,30}(?:中継輸送|共同配送|時間外|960時間)/,
      /フィジカルインターネット|中継輸送|共同配送/,
    ],
    injection_lines: [
      "## ドメイン: 物流輸送 (貨物利用運送/送り状/追跡)",
      "- **委譲エージェント**: `centuria-logistics-orchestrator`, `centuria-edi-broker`, `centuria-compliance-guard`",
      "- **主要ライブラリ**: `yamato-b2` / `sagawa-webapi` / `japanpost-api` / `seino-webapi` / `logi-edi` / `waku-tms`. npm 側は `node-edifact` / `csv-parse`, Python 側は `ortools` / `geopy`",
      "- **標準規格**: JIS X 0501 (JAN), GS1-128 (SSCC 18桁), EDIFACT D96A/IFTMIN, JTRN, ISO 6346, RFC 4180",
      "- **命名規則**: テーブル = `shipments` / `waybills` / `tracking_events` / `drivers` / `vehicles` / `routes`, カラム = `waybill_no` (12桁), `tracking_status` enum. API = `/api/v1/shipments/{waybill_no}/tracking`",
      "- **発火主体制限**: 本ドメインは **荷主/運送会社/物流倉庫/宅配/3PL を主体とする案件のみ**発火する. 工場内倉庫 (製造業の内製 WMS) は manufacturing_production 側.",
      "- **法令根拠 (japan-link `recommendLaws('logistics')` で自動同梱)**: 貨物利用運送事業法 第6条 / 第20条, 貨物自動車運送事業法 第3条 / 第17条, 改善基準告示 (令和6年4月施行) 拘束時間 1日13時間以内・1か月284時間以内・運転時間 2日平均9時間以内",
      "- **追加法令**: 道路交通法 第22条 / 第66条の2, 独占禁止法 (優越的地位濫用), 労働基準法 第32条",
      "- **法令根拠 (2024-2025 最新)**: 2024年問題 (トラック運転者時間外上限 960時間), 改正物流総合効率化法 (2024年5月), フィジカルインターネット, 共同配送プラットフォーム, AI 配車最適化 (Nextmv/Optym), 置き配 EAZY, ドローン配送 (レベル4飛行), GTIN/GLN/GS1 標準, ETC2.0 商用車, 中継輸送を injection.",
      "- **実装パターン**: 送り状発行は冪等 (`waybill_no` 一意制約 + `Idempotency-Key` ヘッダ), 追跡ステータス更新はイベントソーシング (append-only `tracking_events`), 配車最適化は OR-Tools VRP + 拘束時間制約を hard constraint",
      "- **品質チェック**: born-passing 必須. 単体テスト (送り状 CSV バリデーション/運賃タリフ計算/拘束時間累積), E2E (集荷登録→追跡→配達完了), property-based で 12桁チェックデジット検証",
      "- **禁止事項**: 貨物利用運送事業法 第6条違反の無登録運送手配, 改善基準告示違反となる拘束時間超過を許すロジック, 弁護士法 72条違反となる下請運賃紛争の代理判断, 白ナンバー車両への有償運送手配 (道路運送法 第78条違反)",
      "- **UI 文字列**: 日本語固定 (「送り状」「集荷依頼」「再配達」「配達完了」「持戻り」). 識別子は英語",
      "- **セキュリティ**: 個人情報 (着荷主氏名/住所/電話) はカラム暗号化 (AES-256-GCM), 追跡 URL は署名付き (JWT 期限7日), キャリア API キーは環境変数分離",
      "- **cross_domain 境界**: EC × 物流の一気通貫案件は主管ドメインを 1 つ選び補助ドメインの injection_lines のみ追加インポート. 『貨物利用運送事業法/改善基準告示』の strong_anchor がヒットしていれば本ドメイン主管, 『特商法/景表法/PL 法』の strong_anchor がヒットしていれば retail_ecommerce 主管.",
    ],
    quality_axes: [
      {
        key: "law_citations_logistics",
        description_ja: "貨物利用運送事業法・貨物自動車運送事業法・改善基準告示を条文番号付き",
        severity: "FAIL",
        must_all_regex: [/貨物利用運送事業法/, /貨物自動車運送事業法/, /改善基準告示/],
        must_any_regex: [/第\s*6\s*条/, /第\s*3\s*条/, /第\s*17\s*条/, /拘束時間/],
      },
      {
        key: "carrier_library_coverage",
        description_ja: "主要キャリア連携ライブラリ 3個以上",
        severity: "FAIL",
        count_distinct_regex: { patterns: [/yamato-b2/, /sagawa-webapi/, /japanpost-api/, /seino-webapi/, /logi-edi/, /waku-tms/], min: 3 },
      },
      {
        key: "standard_codes",
        description_ja: "JAN/GS1/EDIFACT/JTRN 等",
        severity: "FAIL",
        must_all_regex: [/送り状/],
        must_any_regex: [/JIS\s*X\s*0501/, /GS1-128/, /SSCC/, /EDIFACT/, /JTRN/, /ISO\s*6346/],
      },
      {
        key: "tracking_status_enum",
        description_ja: "貨物追跡ステータス enum",
        severity: "FAIL",
        must_all_regex: [/tracking_status/, /集荷/, /配達完了/],
        must_any_regex: [/持戻り/, /輸送中/, /配達中/],
      },
      {
        key: "improved_standard_notification",
        description_ja: "改善基準告示 (令和6年4月施行) の数値制約",
        severity: "FAIL",
        must_all_regex: [/拘束時間/],
        must_any_regex: [/13\s*時間/, /284\s*時間/, /9\s*時間/],
      },
      {
        key: "delegation_agents_logistics",
        description_ja: "Centuria 系委譲エージェント 2個以上",
        severity: "FAIL",
        count_distinct_regex: { patterns: [/centuria-logistics-orchestrator/, /centuria-edi-broker/, /centuria-compliance-guard/], min: 2 },
      },
      {
        key: "idempotency_and_eventsourcing",
        description_ja: "送り状発行の冪等性 + 追跡イベントの append-only",
        severity: "WARN",
        must_all_regex: [/冪等/, /tracking_events/],
        must_any_regex: [/Idempotency-Key/, /append-only/, /イベントソーシング/],
      },
      {
        key: "prohibited_actions",
        description_ja: "無登録運送手配・白ナンバー有償運送・拘束時間超過禁止",
        severity: "FAIL",
        must_any_regex: [/無登録/, /白ナンバー/, /拘束時間\s*超過/],
        must_not_regex: [/違反しても構わない/, /拘束時間は無視/],
      },
      {
        key: "no_domain_crosstalk",
        description_ja: "建設図面/SDK 内部語/API AI 統制固有語混入禁止",
        severity: "WARN",
        must_not_regex: [/DXF\s*R14/, /IFC4/, /output-styles/, /prompt\s*caching/, /computer-use/],
      },
      {
        key: "latest_logistics_2024_2025",
        description_ja: "2024年問題/改正物流総合効率化法/フィジカルインターネット/中継輸送/共同配送 いずれか",
        severity: "WARN",
        must_any_regex: [/2024年問題/, /改正物流総合効率化法/, /フィジカルインターネット/, /中継輸送/, /共同配送/, /GS1標準/],
      },
    ],
  },
  {
    key: "manufacturing_production",
    name_ja: "製造業 (BOM/トレーサビリティ/JIS品質)",
    example_skill_name: "soloptilink-manufacturing-production",
    law_industry_key: "manufacturing",
    detection_patterns: [
      /(BOM|部品表)[^。\n]{0,20}(展開|階層|構成|管理|マスタ).{0,40}(?:MES|OPC\s*UA|JIS\s*Q\s*9001|Cpk|SPC|工程能力|生産管理|製造管理|工場|プラント|生産ライン)/,
      /(生産管理|製造管理|工程管理)[^。\n]{0,20}(スキル|SKILL\.md|Claude[ ]?Code|生成|構築|作)/,
      /(トレーサビリティ|追跡)[^。\n]{0,20}(ロット|シリアル|工程|順逆).{0,40}(?:製造|工場|プラント|生産ライン|MES)/,
      /(品質管理|QC工程表|検査記録)[^。\n]{0,20}(スキル|生成|作|管理).{0,40}(?:JIS\s*Q\s*9001|Cpk|SPC|製造|工場)/,
      /(IoT|OPC|PLC|SCADA)[^。\n]{0,20}(連携|接続|収集|MES)/,
      /(工程能力|Cp|Cpk|SPC|管理図|Xbar)[^。\n]{0,20}(算出|計算|判定|逸脱)/,
      /(MRP|所要量|安全在庫|リードタイム)[^。\n]{0,20}(計算|展開|算出)/,
      /(OEE|設備総合効率|稼働率|可用性)[^。\n]{0,20}(計算|算出|集計)/,
      /(下請法|下請代金)[^。\n]{0,20}(60日|60營業日|支払遅延|割引困難).{0,40}(?:製造|工場|生産)/,
      /(省エネ法|省エネルギー法|エネルギー使用)[^。\n]{0,20}(定期報告|中長期計画|原単位)/,
      /(温対法|温室効果ガス|GHG)[^。\n]{0,20}(算定|報告|Scope)/,
      /(化管法|PRTR|化学物質)[^。\n]{0,20}(届出|排出|移動)/,
      /(危険物|高圧ガス|保安)[^。\n]{0,20}(製造|貯蔵|取扱)/,
      /(食品衛生法|HACCP)[^。\n]{0,20}(製造|工程|記録)/,
      /(医療機器|QMS省令|GMP)[^。\n]{0,20}(製造|品質|バリデーション)/,
      /(電気用品安全法|PSE)[^。\n]{0,20}(適合|表示|届出)/,
      /(ロット|バッチ|シリアル)番号[^。\n]{0,20}(採番|体系|生成|フォーマット)/,
      /(工程|作業|段取り)コード[^。\n]{0,20}(体系|マスタ|採番)/,
      /(検査成績書|ミルシート|COA)[^。\n]{0,20}(発行|管理|出力)/,
      /(在庫|棚卸|入出庫)[^。\n]{0,20}(製造|工程|仕掛)/,
      /(製造業|工場|プラント|生産ライン)[^。\n]{0,30}(Claude[ ]?Code|SKILL\.md|スキル|エージェント)/,
      /(4M|人[ ]?機械[ ]?材料[ ]?方法)[^。\n]{0,20}(変更管理|記録)/,
      /IEC\s*62443.{0,30}(OT|産業制御)/,
      /デジタルツイン|予知保全|Scope\s*3|CBAM/,
    ],
    injection_lines: [
      "- **委譲エージェント**: `centuria-manufacturing-planner`, `centuria-quality-inspector`, `centuria-traceability-tracker`, `centuria-compliance-guard`",
      // ★2026-08-06 是正: 旧記述は mrp-sdk / bom-manager / spc-tools / oee-calc / mes-connector /
      //   opc-ua-client の 6 パッケージを package.json へピン留めするよう FAIL 重大度で要求していたが、
      //   実測 (npm view) で 6 件すべて E404 = npm に実在しない。実在しない依存を宣言させると
      //   顧客生成物が npm install で即死し、かつ『実装なき OPC UA 宣言』が納品物へ流れ出す。
      //   → 自前実装を既定とし、実接続が要るときだけ実在パッケージ (node-opcua) を使う指示へ改める。
      "- **主要ライブラリ**: BOM 展開・MRP 所要量計算・SPC/工程能力・OEE は **外部パッケージに依存せず自前の純粋関数として実装**する (該当領域に定番の npm パッケージは存在しない). OPC UA で実機収集する場合のみ実在パッケージ `node-opcua` を `package.json` に固定バージョンでピン留めする. **npm に実在しないパッケージ名を package.json へ書いてはならない** (install 不能な納品物になる).",
      "- **標準規格準拠**: `JIS Q 9001:2015`, `JIS Q 14001:2015`, `ISO 22400`, `ISA-95`, `IEC 62264`, `ISO 8601`, `GS1-128`",
      "- **命名規則**: `manufacturing_*` プレフィックス (`manufacturing_bom_items` / `manufacturing_lots` / `manufacturing_processes` / `manufacturing_inspections`), snake_case, API `/api/manufacturing/{resource}`, ロット番号は `YYYYMMDD-<line>-<seq>`",
      "- **発火主体制限**: 本ドメインは **MES/OPC UA/JIS Q 9001/工程能力 (Cpk)/SPC 管理図のいずれかが共起する製造業案件のみ**発火する. 建設業の施工 BOM・資材 BOM は construction_drawing 側の資材台帳テンプレへ, IT/飲食の BOM は本ドメイン非該当.",
      "- **法令根拠 (下請法)**: 下請代金支払遅延等防止法 第2条の2 / 第4条 (受領後60日以内支払・遅延利息年14.6%) / 第5条. japan-link `recommendLaws('manufacturing')` で自動同梱",
      "- **法令根拠 (省エネ・環境系)**: 省エネ法 第7条 / 第15条, 化管法/PRTR法 第5条, 温対法 第26条",
      "- **法令根拠 (製造対象別)**: 高圧ガス保安法 第5条, 消防法 第10条, 食品衛生法 第55条 と HACCP, 医薬品医療機器等法 第23条の2の3 と QMS 省令, 電気用品安全法 第8条 (PSE)",
      "- **法令根拠 (2024-2026 最新)**: DX Silverline/白書, インダストリー 5.0, 予知保全 (Predictive Maintenance), デジタルツイン, Industry 4.0 RAMI 4.0, Asset Administration Shell (AAS), MTConnect, IEC 62443 (産業制御セキュリティ), GHG プロトコル Scope 3, CBAM (国境炭素調整措置) を injection.",
      "- **実装パターン**: BOM 展開は再帰 CTE か DFS で循環参照検出付き実装, MRP 所要量計算は純粋関数化, OPC UA 収集は指数バックオフ再接続, SPC 判定は Nelson Rules 8 種を関数分割",
      "- **品質チェック (born-passing)**: BOM 循環参照テスト・Cpk 計算の JIS Z 9020 準拠テスト・下請60日ルール境界値テスト (59/60/61日) ・ロット順逆追跡の Given-When-Then テストを含む単体テスト 30 件以上",
      "- **UI/UX**: 日本語ラベル, Cpk<1.33 は警告色, 下請法違反疑いは赤帯で警告",
      "- **禁止事項 (法令)**: 弁護士法 第72条違反となる契約解釈助言禁止, 医師法 第17条違反となる医療機器製造時の診断的判断禁止, 下請法違反となる 60日超支払サイト・買いたたき・受領拒否のシステム上許容禁止, 労働基準法違反となる工数実績の恣意的改ざん禁止",
      "- **禁止事項 (安全)**: 高圧ガス・危険物・毒劇物の閾値超過保管を無警告で許容しない, PSE 未表示品の出荷承認を許容しない, HACCP CCP 逸脱記録の物理削除を禁止",
      "- **監査ログ**: 全 CRUD に `audit_logs` テーブルへ `who/when/what/before/after/legal_basis` を書き込み, `retention_years` カラムで管理",
      "- **提供元表示**: 生成物ヘッダに `Provided by SoloptiLink`",
      "- **cross_domain 境界**: 医療機器製造 (QMS省令・GMP・BOM) は本ドメイン主管で medical_healthcare は診療報酬・電子カルテ・オンライン資格確認のみ担当. 建設 BOM は construction_drawing 側.",
    ],
    quality_axes: [
      {
        key: "bom_traceability_core",
        description_ja: "BOM 階層と ロットトレーサビリティ の中核機能",
        severity: "FAIL",
        must_all_regex: [/BOM/, /(ロット|トレーサビリティ)/],
        must_any_regex: [/(親子|階層|展開|再帰)/, /(順逆|追跡|回収)/],
      },
      {
        key: "quality_spc_jis",
        description_ja: "SPC/工程能力指数 と JIS Q 9001",
        severity: "FAIL",
        must_all_regex: [/(Cp|Cpk|工程能力|SPC|管理図)/, /JIS[ ]?Q[ ]?9001/],
      },
      {
        key: "subcontract_law_60days",
        description_ja: "下請法の 60日ルール・遅延利息 14.6%",
        severity: "FAIL",
        must_all_regex: [/下請代金支払遅延等防止法/, /60日/],
        must_any_regex: [/第4条/, /14\.6/],
      },
      {
        key: "energy_env_laws",
        description_ja: "省エネ法・化管法(PRTR)・温対法 2つ以上",
        severity: "FAIL",
        must_any_regex: [/第\d+条/],
        count_distinct_regex: { patterns: [/省エネ法/, /化管法|PRTR/, /温対法|温室効果ガス/], min: 2 },
      },
      {
        // ★2026-08-06 是正: 旧軸 libraries_pinned は実在しない 6 パッケージのうち 4 種以上を
        //   名指しさせる FAIL 軸だった (実測 npm E404)。要求を反転し『実在しない依存を書いたら落ちる』軸にする。
        key: "no_fictional_dependencies",
        description_ja: "npm に実在しないパッケージ名 (mrp-sdk / bom-manager / spc-tools / oee-calc / mes-connector / opc-ua-client) を依存として宣言していないこと。OPC UA 実接続は実在の node-opcua を使う。",
        severity: "FAIL",
        must_not_regex: [/\bmrp-sdk\b/, /\bbom-manager\b/, /\bspc-tools\b/, /\boee-calc\b/, /\bmes-connector\b/, /\bopc-ua-client\b/],
      },
      {
        key: "delegate_agents",
        description_ja: "Centuria 委譲エージェント 2 種以上",
        severity: "FAIL",
        count_distinct_regex: { patterns: [/centuria-manufacturing-planner/, /centuria-quality-inspector/, /centuria-traceability-tracker/, /centuria-compliance-guard/], min: 2 },
      },
      {
        key: "naming_convention",
        description_ja: "テーブル/カラム/API パスの命名規則",
        severity: "FAIL",
        must_all_regex: [/manufacturing_/, /\/api\/manufacturing\//],
        must_any_regex: [/lot_no|parent_item_code|cpk_value/],
      },
      {
        key: "born_passing_tests",
        description_ja: "born-passing/単体/E2E の品質チェック",
        severity: "FAIL",
        must_all_regex: [/born-passing/],
        must_any_regex: [/単体テスト|E2E|スモーク/],
      },
      {
        key: "prohibition_legal",
        description_ja: "弁護士法72条・医師法・下請法違反等禁止事項",
        severity: "FAIL",
        must_any_regex: [/弁護士法.*72/, /医師法.*17/, /下請法.*(違反|買いたたき|受領拒否)/],
      },
      {
        key: "no_hr_skill_confusion",
        description_ja: "HR業種の「スキル管理」「人材評価」等と誤認する語が本文中で強調されていない",
        severity: "FAIL",
        must_not_regex: [/人材[ ]?スキル管理/, /従業員スキル台帳/, /タレントマネジメント/, /人事評価制度/],
      },
      {
        key: "latest_manufacturing_2024_2026",
        description_ja: "IEC 62443/AAS/MTConnect/デジタルツイン/予知保全/Scope 3/CBAM いずれか",
        severity: "WARN",
        must_any_regex: [/IEC\s*62443/, /AAS|Asset\s*Administration\s*Shell/, /MTConnect/, /デジタルツイン/, /予知保全/, /GHG\s*プロトコル\s*Scope\s*3/, /CBAM/],
      },
    ],
  },
  {
    key: "medical_healthcare",
    name_ja: "医療 (レセ電/電子カルテ/HL7 FHIR/DPC/オンライン資格確認)",
    example_skill_name: "soloptilink-medical-healthcare",
    law_industry_key: "healthcare",
    detection_patterns: [
      /電子カルテ.{0,20}(?:スキル|Skill|SKILL\.md|生成|作成|開発).{0,30}(?:医療機関|病院|クリニック|診療所|薬局)/,
      /レセプト.{0,15}(?:作成|請求|点検|チェック|生成).{0,30}(?:医療機関|病院|クリニック|診療所|薬局)/,
      /医療機関.{0,20}(?:向け|向けの).{0,10}(?:業務システム|スキル)/,
      /診療報酬.{0,15}(?:請求|算定|明細|点数)/,
      /ICD-?10.{0,20}(?:コード|マスタ|マッピング).{0,40}(?:医療機関|病院|クリニック|診療所|薬局|電子カルテ|レセプト)/,
      /傷病名.{0,15}(?:マスタ|標準|コード|辞書)/,
      /医科(?:入院|外来).{0,15}(?:レセプト|点数)/,
      /処方(?:箋|データ).{0,15}(?:電子|発行|送信)/,
      /調剤.{0,15}(?:レセプト|報酬|薬局)/,
      /地域医療.{0,15}(?:連携|情報|ネットワーク)/,
      /PHR.{0,15}(?:連携|データ|標準)/,
      /医療情報.{0,15}(?:標準化|交換|システム)/,
      /厚生労働省.{0,20}(?:通知|告示|標準規格)/,
      /被保険者.{0,10}(?:資格|確認|マイナ保険証)/,
      /マイナ(?:ンバー)?保険証/,
      /看護記録.{0,15}(?:電子化|標準化)/,
      /医事(?:会計|コン|システム)/,
      /生体信号.{0,15}(?:モニタリング|波形)/,
      /健診(?:データ|結果).{0,10}(?:連携|標準化).{0,30}(?:医療機関|病院|クリニック)/,
      /医療AI.{0,15}(?:診断|支援|画像)/,
      /電子処方箋管理サービス/,
      /訪問看護.{0,20}(?:医療保険|療養費)/,
    ],
    injection_lines: [
      "**委譲エージェント**: `centuria-medical-record-agent`, `centuria-receipt-agent`, `centuria-fhir-integration-agent`, `centuria-hpki-signature-agent`",
      "**主要ライブラリ**: `@medplum/core` `@medplum/fhirtypes` `fhir.js` `hl7-fhir-typescript`, `node-hl7-client`, `dpc-sdk`, `pkcs11js`",
      "**標準規格/フォーマット**: HL7 FHIR R4, SS-MIX2 v1.2j, レセプト電算処理システム記録条件仕様 (医科・DPC・調剤), ICD-10, JLAC10, MEDIS-DC 標準病名マスター, HOT9, X.509 v3",
      "**命名規則**: `mst_` / `trn_` / `rcpt_` 接頭辞, snake_case, API `/fhir/R4/{ResourceType}/{id}`",
      "**発火主体制限**: 本ドメインは **医療機関 (病院/クリニック/診療所) または調剤薬局を主体とする案件のみ**発火する. 健保組合/生保/企業健診主体は本ドメイン非該当で保険/分析側に流す.",
      "**法令根拠**: 医師法第17条 (医業独占), 医療法第1条の4, 薬機法第2条 — japan-link `recommendLaws('healthcare')` で自動同梱",
      "**法令根拠 (2025-2026 最新)**: 次世代医療基盤法 2023年改正 (仮名加工医療情報), 医療機関等サイバーセキュリティチェックリスト v6.0, DPC/PDPS 2024年改定, 看護必要度 IV, オンライン診療の適切な実施に関する指針. マイナ保険証移行 (2024年12月健康保険証廃止・経過措置1年) を電子カルテ資格確認モジュールに反映.",
      "**法令根拠 (個人情報・電子化)**: 個人情報保護法第2条第3項 (要配慮個人情報), 医療情報の安全管理に関するガイドライン 第6.0版 (3省2ガイドライン), 電子処方箋管理サービス運用マニュアル, 保険医療機関及び保険医療養担当規則",
      "**law_ai_boundary (医師法17条越境防止)**: SKILL.md 冒頭に『本スキルは医師法17条に鑑み、診断・治療方針決定・処方判断を AI が行わず、医師の判断を補助する情報整理・データ集計・記録支援に留める』を明記. 症状評価/診断/治療提案系の出力を quality_gate で BLOCK し『医師にご相談ください』を強制注入. SaMD (医療機器プログラム) 該当性判定チェックリストを設計工程に組み込み薬機法認証取得手続きを guidance 提示. 医療広告ガイドライン (虚偽/誇大/比較優良広告禁止) を Web 画面生成時に必ずチェック.",
      "**実装パターン**: FHIR は `Bundle` transaction で冪等 PUT + ETag 楽観ロック, レセ電生成は 4段パイプ, HPKI 署名は 4ステップ, エラーは `OperationOutcome` FHIR で返却",
      "**実装パターン (資格確認)**: オンライン資格確認は 顔認証カードリーダー → 支払基金/国保中央会 API → 資格情報 4項目. PKCS#11 経由の HPKI 秘密鍵は 60秒以内で破棄",
      "**品質チェック**: FHIR Validator, 単体テスト (Patient/Encounter/Claim), E2E は オンライン資格確認テスト環境で券面情報取得 → レセ電生成 → HPKI 署名 → 返戻ゼロ",
      "**品質チェック (セキュリティ)**: TLS 1.2以上, 監査ログ 6年保管, RBAC, AES-256, 仮名化, append-only 監査ログ",
      "**禁止事項**: 医師法第17条違反 (確定診断UI), 弁護士法第72条 (医療訴訟法律相談), 薬機法第68条 (未承認品広告), 混合診療自動計算",
      "**禁止事項 (データ保護)**: 平文クラウド送信・LLM プロンプト直接埋込禁止 (仮名化+マスキング必須), 患者氏名/生年月日/保険者番号ログ出力禁止, HPKI 秘密鍵の平文保管・Gitコミット禁止, テストデータでも実在患者情報禁止",
      "**cross_domain 境界**: (1) 訪問看護は保険区分により両ドメイン共起 — 医療レセ電処理は本ドメイン、介護給付費処理は care_welfare、共通の利用者マスタは care_welfare 側で保持. (2) 医療機器製造 (QMS 省令/GMP/BOM) は manufacturing_production 主管で本ドメインは診療報酬・電子カルテ・オンライン資格確認のみ. (3) 看護師シフト管理は hr_labor_management 側.",
    ],
    quality_axes: [
      {
        key: "fhir_standard_conformance",
        description_ja: "HL7 FHIR R4 リソースが具体的に言及され @medplum/core 等と結びついていること.",
        severity: "FAIL",
        must_all_regex: [/HL7\s*FHIR/, /R4/],
        must_any_regex: [/Patient/, /Encounter/, /Observation/, /MedicationRequest/, /Claim/, /Bundle/],
        must_not_regex: [/FHIR\s*R2/, /DSTU1/],
      },
      {
        key: "receipt_denshi_specification",
        description_ja: "レセ電の 医科/DPC/調剤 区分と月次オンライン請求 (10日締切) が明示.",
        severity: "FAIL",
        must_all_regex: [/(?:医科|DPC|調剤)/],
        must_any_regex: [/レセ電/, /レセプト電算/, /オンライン請求/],
        must_not_regex: [/紙(?:提出|請求)のみ/],
      },
      {
        key: "code_system_completeness",
        description_ja: "ICD-10 / MEDIS-DC / HOT9 / JLAC10 / DPC のうち 3種以上が採用.",
        severity: "FAIL",
        count_distinct_regex: { patterns: [/ICD-?10/, /MEDIS-?DC/, /HOT9/, /JLAC10/, /DPC/], min: 3 },
      },
      {
        key: "law_grounding_medical",
        description_ja: "医師法・医療法・薬機法・個情法・3省2ガイドラインのうち条文付き3件以上.",
        severity: "FAIL",
        must_any_regex: [/recommendLaws\(['"]healthcare['"]\)/, /japan-link/],
        count_distinct_regex: { patterns: [/医師法\s*第?\s*\d+\s*条/, /医療法\s*第?\s*\d+\s*条/, /薬機法\s*第?\s*\d+\s*条/, /個人情報保護法\s*第?\s*\d+\s*条/, /3省2ガイドライン/, /医療情報の安全管理に関するガイドライン/, /次世代医療基盤法/], min: 3 },
      },
      {
        key: "security_3sho2gl_baseline",
        description_ja: "3省2ガイドライン準拠 (TLS/監査ログ/RBAC/暗号化/仮名化) 3項目以上.",
        severity: "FAIL",
        must_not_regex: [/TLS\s*1\.0/, /SSL\s*3\.0/],
        count_distinct_regex: { patterns: [/TLS\s*1\.[23]/, /監査ログ/, /RBAC/, /AES-?256/, /仮名化|マスキング/, /アクセス制御/, /6年(?:間)?保管/], min: 3 },
      },
      {
        key: "online_qualification_confirmation",
        description_ja: "オンライン資格確認 (顔認証/マイナ保険証/資格情報4項目) が具体的.",
        severity: "WARN",
        must_all_regex: [/(?:資格情報|資格区分|一部負担金|限度額)/],
        must_any_regex: [/オンライン資格確認/, /マイナ保険証/, /顔認証(?:付き)?カードリーダー/],
      },
      {
        key: "hpki_signature_flow",
        description_ja: "HPKI 電子署名 (PKCS#11/X.509/タイムスタンプ/電子処方箋).",
        severity: "WARN",
        must_all_regex: [/HPKI/],
        must_any_regex: [/PKCS#?11/, /X\.509/, /タイムスタンプ/, /電子処方箋/, /電子署名/],
      },
      {
        key: "prohibited_actions_medical",
        description_ja: "医師法17条 (無資格診断禁止) / 薬機法68条 / 患者情報プロンプト平文送信禁止.",
        severity: "FAIL",
        must_all_regex: [/(?:仮名化|マスキング|平文.{0,10}禁止)/],
        must_any_regex: [/医師法\s*第?\s*17\s*条/, /無資格診断/, /確定診断.{0,10}(?:禁止|不可)/],
      },
      {
        key: "delegated_agent_wiring",
        description_ja: "centuria-* 医療系委譲先が最低 2つ.",
        severity: "WARN",
        count_distinct_regex: { patterns: [/centuria-medical-record-agent/, /centuria-receipt-agent/, /centuria-fhir-integration-agent/, /centuria-hpki-signature-agent/], min: 2 },
      },
      {
        key: "born_passing_quality_gate",
        description_ja: "born-passing / FHIR Validator / 単体テスト / E2E のうち 3項目以上.",
        severity: "WARN",
        count_distinct_regex: { patterns: [/born-passing/, /FHIR\s*Validator/, /単体テスト/, /E2E/, /回帰テスト/], min: 3 },
      },
      {
        key: "latest_medical_regulations_2025_2026",
        description_ja: "マイナ保険証・電子処方箋管理サービス・次世代医療基盤法・DPC/PDPS 改定・SaMD いずれかへの言及.",
        severity: "WARN",
        must_any_regex: [/マイナ保険証/, /電子処方箋管理サービス/, /次世代医療基盤法/, /DPC\/PDPS/, /SaMD/, /看護必要度\s*IV/, /全国医療情報プラットフォーム/],
      },
    ],
  },
  {
    key: "multi_llm_provider",
    name_ja: "マルチLLMプロバイダ抽象化 (Gemini/GPT-5/DeepSeek/Grok/Llama)",
    example_skill_name: "soloptilink-multi-llm-provider",
    law_industry_key: "multi_llm",
    detection_patterns: [
      /(?:Gemini|GPT-5|DeepSeek|Grok|Llama|Mistral|Cohere|Ollama|Qwen|Kimi).{0,40}(?:スキル|SKILL\.md|Claude\s*Code)/,
      /(?:プロバイダ|provider).{0,20}(?:切替|切り替え|ルーティング|フェイルオーバー|フォールバック)/,
      /モデル\s*(?:ルーター|ゲートウェイ|プロキシ|オーケストレーション)/,
      /(?:複数|マルチ)\s*(?:LLM|モデル|プロバイダ).{0,30}(?:統合|抽象|切替|ルーティング)/,
      /(?:レート\s*リミット|rate\s*limit).{0,30}(?:マルチ|複数|Gemini.{0,30}(?:GPT|DeepSeek|Grok)|フェイルオーバー|ルーティング|フォールバック|抽象化)/,
      /(?:response|レスポンス|出力).{0,20}(?:schema|スキーマ|正規化).{0,30}(?:マルチ|複数プロバイダ|Gemini.{0,20}GPT|DeepSeek)/,
      /(?:プロンプト|prompt)\s*(?:キャッシュ|caching).{0,30}(?:マルチ|複数プロバイダ|Gemini.{0,20}GPT)/,
      /(?:トークン|token).{0,15}(?:換算|正規化|コスト計算).{0,30}(?:プロバイダ|マルチ|LLM)/,
      /(?:LangChain|@langchain\/).{0,40}(?:マルチ|複数プロバイダ|抽象化)/,
      /(?:ai\s*sdk|Vercel\s*AI).{0,30}(?:マルチプロバイダ|抽象化|generateText|streamText|複数モデル)/,
      /(?:generateText|streamText|createOpenAI|createGoogleGenerativeAI|createAnthropic)\b.{0,30}(?:マルチ|複数|抽象)/,
      /(?:ollama).{0,30}(?:local|ローカル|オンプレ|self[- ]?host).{0,30}(?:マルチ|複数プロバイダ|抽象)/,
      /(?:function\s*calling|tool\s*use|tool\s*calling).{0,40}(?:マルチプロバイダ|複数プロバイダ|統一|抽象)/,
      /(?:ストリーミング|streaming|SSE).{0,30}(?:マルチプロバイダ|複数プロバイダ|統一抽象)/,
      /(?:個人情報保護法|電帳法|電子帳簿保存法).{0,40}(?:マルチ|複数プロバイダ|越境.*LLM)/,
      /(?:PII|個人情報).{0,20}(?:マスキング|除去|送出).{0,30}(?:マルチ|複数プロバイダ|越境)/,
      /(?:BYOK|Bring\s*Your\s*Own\s*Key).{0,30}(?:マルチ|複数プロバイダ|LLM抽象)/,
      /(?:モデル\s*カード|model\s*card|context\s*window|コンテキスト\s*ウィンドウ).{0,30}(?:比較|一覧|切替).{0,20}(?:マルチ|複数プロバイダ)/,
      /(?:埋め込み|embedding).{0,30}(?:マルチプロバイダ|Gemini.{0,20}OpenAI|Cohere.{0,20}OpenAI)/,
      /(?:together[- ]?ai|Fireworks|Groq|Bedrock|Vertex\s*AI|OpenRouter|Portkey).{0,40}(?:プロバイダ|統合|ルーティング|抽象)/,
      /(?:@openai\/agents|openai-agents).{0,40}(?:マルチ|抽象|複数プロバイダ)/,
      /(?:Bedrock|Vertex\s*AI|Azure\s*OpenAI).{0,30}(?:Claude|Gemini|GPT|Llama).{0,30}(?:ルーティング|抽象|フォールバック)/,
      /(?:LiteLLM|OpenRouter|Portkey).{0,20}(?:ルーティング|抽象化|統合|プロキシ)/,
      /(?:Claude\s*4|Opus\s*4|Sonnet\s*4|Gemini\s*2\.5|GPT-5|o3|Llama\s*4|Qwen\s*3|Kimi\s*K2)/,
    ],
    injection_lines: [
      "- 委譲エージェント: `centuria-integration-architect` (統合設計), `centuria-security-officer` (PII/鍵管理/越境移転), `centuria-cost-guardian` (トークンコスト最適化) を必ず経由し, 単独判断でプロバイダ選定を行わない.",
      "- **本スキルは AI 事業者ガイドライン (総務省/経産省 2024年4月) に鑑み、プロバイダ切替時の説明責任 (どのプロバイダがどのデータをどう扱ったか) を確保する.** ルーティング判断ログ (プロバイダ選択理由・データ分類・タイムスタンプ) を `llm_routing_audit_log` に監査保存し 7 年保管する.",
      "- 必須ライブラリ (npm): `ai` (Vercel AI SDK v4系), `@ai-sdk/openai`, `@ai-sdk/google`, `@ai-sdk/anthropic`, `@ai-sdk/mistral`, `@ai-sdk/cohere`, `ollama`, `together-ai`, `openrouter-client`, `portkey-ai`. Python 側は `litellm>=1.55`, `langchain>=0.3`, `openai>=1.55`, `google-genai>=0.3`, `boto3` (Bedrock), `google-cloud-aiplatform` (Vertex AI Model Garden), `azure-ai-inference` (Azure OpenAI) を SoT とする.",
      "- 対応モデル (2025-2026年時点): `claude-opus-4-7` / `claude-4.5-sonnet` / `gemini-2.5-pro` / `gemini-2.5-flash` / `gpt-5` / `gpt-5-turbo` / `o3` / `o3-mini` / `o1-pro` / `deepseek-v3` / `deepseek-reasoner` / `grok-4` / `grok-3` / `llama-4-scout` / `llama-3.3-70b` / `qwen-3` / `kimi-k2` / `yi-large` / `mixtral-8x22b` / `command-r-plus`. マルチクラウド抽象は `bedrock:anthropic.claude-*` / `vertex:gemini-*` / `azure:gpt-*` の URI 形式で `models.registry.json` に集約.",
      "- 標準規格・フォーマット: canonical は **OpenAI Chat Completions 互換スキーマ (JSON Schema draft-07)** とし adapter で吸収. ストリーミングは **RFC 8895 (SSE)** と **RFC 6455 (WebSocket)** を明示区別. トレースは **W3C Trace Context (traceparent)** と **OpenTelemetry GenAI Semantic Conventions v1.29** 必須.",
      "- 命名規則: DB テーブルは `llm_provider` / `llm_model_registry` / `llm_call_log` / `llm_route_policy` / `llm_pii_redaction_audit` / `llm_routing_audit_log` / `llm_consent_log`, API パスは `/api/v1/llm/{provider}/{model}/{action}`, 環境変数は `LLM_<PROVIDER>_API_KEY` (接頭辞 `LLM_` を強制).",
      "- **法令根拠 (japan-link `recommendLaws('multi_llm')` で自動同梱)**: **個人情報保護法 (令和4年改正) 第20条 (利用目的の特定・変更制限), 第27条 (第三者提供の制限), 第28条 (外国にある第三者への提供の制限)** に基づき, 越境プロバイダ (US系: OpenAI/Anthropic/Google/xAI, 中国系: DeepSeek/Qwen/Kimi, EU系: Mistral) 別に同意取得フローを分岐生成し `llm_consent_log` に本人同意ログを記録.",
      "- **法令根拠 (追加)**: **電子帳簿保存法 第8条 第4項 (電子取引データの真実性・可視性)** に基づき, 業務判断利用時の入出力ログは **7年間 (欠損金繰越時 10 年)** 改ざん困難な形で保存. **プロ責法 第3条** に基づき削除請求手続きを備える. **EU AI 法 General Purpose AI 透明性義務 (2025年8月適用)** を guidance として注入.",
      "- 実装パターン: (1) `Provider` interface に `chat()` / `stream()` / `embed()` / `countTokens()` を定義, (2) fallback chain は **primary → secondary → tertiary の 3 段階** + exponential backoff (base 500ms, max 8s, jitter ±20%) + circuit breaker (失敗率 50% / 60秒窓で open), (3) 全呼び出しに **idempotency-key (SHA256(prompt+model+temp))** 付与, (4) tool-calling は Vercel AI SDK の `tool()` 抽象で統一.",
      "- 品質チェック: born-passing = (a) 各プロバイダ mock で JSON Schema 一致率 100%, (b) primary 500 応答 → secondary への切替 3 秒以内, (c) 429 応答時の Retry-After header 遵守, (d) PII マスキング (メール/電話/マイナンバー) 正規表現カバレッジ 100%, (e) 越境同意取得漏れ検出テスト (DeepSeek 送出前の consent gate BLOCK), (f) Playwright で E2E ストリーミング検証.",
      "- **禁止事項 (法令)**: **弁護士法72条** の法律相談回答, **医師法17条** の無資格診断, **金融商品取引法29条** の無登録投資助言, **著作権法30条の4** を超える学習データ流用. **個人情報保護法28条違反となる越境プロバイダへの同意なきPII送出** を routing policy の deny-list に登録. これらは全て `assert_no_regulated_action()` linter で CI BLOCK.",
      "- 禁止事項 (技術): API キーを `console.log` / `stderr` / エラーレスポンスに露出させること, ユーザプロンプトを SoT 外の第三者ログ収集に本人同意なく送出すること, `system` プロンプトを未認証エンドポイントから返却すること, ハードコード API キーの `git commit` (pre-commit で `gitleaks` + `trufflehog` 必須).",
      "- コスト・レート制御: `litellm` の router-based limits または独自 token-bucket (Redis) で **プロバイダ別 TPM/RPM 必須設定**. 月次コストは `llm_call_log.cost_jpy` に円換算保存. プロンプトキャッシュ対応モデル (Gemini 2.5 / gpt-4.1 / gpt-5 / DeepSeek / Claude) は必ず有効化.",
      "- 観測性: OpenTelemetry GenAI Semconv v1.29 の `gen_ai.system` / `gen_ai.request.model` / `gen_ai.usage.input_tokens` / `gen_ai.usage.output_tokens` / `gen_ai.response.finish_reasons` を全 span に付与. トレースは Jaeger / Grafana Tempo / Langfuse に export.",
      "- 並存の設計原則: Anthropic 単独案件 (Claude API のみ) は `api_integration_ai_control` ドメインが主管. 本ドメインは **プロバイダ名 2 個以上共起または抽象化キーワード (routing/fallback/orchestration/proxy/OpenRouter/LiteLLM/Portkey/Bedrock/Vertex/Azure OpenAI) 共起** を必須ゲートとし, 単独の LLM + rate limit 共起では発火しない.",
    ],
    quality_axes: [
      {
        key: "provider_coverage",
        description_ja: "Gemini/GPT/DeepSeek/Grok/Llama を含む複数プロバイダが明示され, 単一プロバイダ依存の記述になっていないことを保証する.",
        severity: "FAIL",
        must_any_regex: [/gemini-2\.5/, /gpt-5/, /deepseek-(?:v3|reasoner)/, /grok-[34]/, /llama-(?:3\.3|4)/],
        must_not_regex: [/^(?:(?!gemini|gpt|deepseek|grok|llama|mistral|cohere|ollama|qwen|kimi).)*$/],
        count_distinct_regex: { patterns: [/gemini/, /gpt-?5/, /deepseek/, /grok/, /llama/, /mistral|mixtral/, /cohere|command-r/, /ollama/, /qwen|kimi/], min: 5 },
      },
      {
        key: "abstraction_library",
        description_ja: "Vercel AI SDK / LiteLLM / LangChain / OpenRouter / Portkey いずれか 2 系統以上への言及と統一 interface 定義.",
        severity: "FAIL",
        must_all_regex: [/(?:chat|stream|embed)/],
        must_any_regex: [/ai\s*sdk|@ai-sdk\//, /litellm/, /langchain/, /OpenRouter/, /Portkey/],
        count_distinct_regex: { patterns: [/ai\s*sdk|@ai-sdk\//, /litellm/, /langchain/, /OpenRouter/, /Portkey/], min: 2 },
      },
      {
        key: "multicloud_abstraction",
        description_ja: "AWS Bedrock / Vertex AI / Azure OpenAI いずれかへの言及があること.",
        severity: "WARN",
        must_any_regex: [/Bedrock/, /Vertex\s*AI/, /Azure\s*OpenAI/],
      },
      {
        key: "fallback_and_rate_limit",
        description_ja: "fallback / retry / circuit breaker / rate limit の数値付き記述.",
        severity: "FAIL",
        must_all_regex: [/(?:fallback|フォールバック)/, /(?:retry|リトライ|backoff|バックオフ)/, /(?:rate\s*limit|レート\s*リミット|TPM|RPM)/],
        must_any_regex: [/circuit\s*breaker|サーキット\s*ブレーカー/, /exponential/, /jitter/, /idempotency/],
      },
      {
        key: "law_grounding",
        description_ja: "個人情報保護法・電子帳簿保存法・プロ責法・AI事業者ガイドライン・EU AI 法いずれか 2 系統以上を条文番号付きで引用.",
        severity: "FAIL",
        must_all_regex: [/第\s*\d+\s*条/],
        must_any_regex: [/個人情報保護法/, /電子帳簿保存法|電帳法/, /プロ責法|特定電気通信役務提供者/, /弁護士法\s*第?72条/, /医師法\s*第?17条/, /金融商品取引法\s*第?29条/, /AI事業者ガイドライン/, /EU\s*AI\s*法/],
        count_distinct_regex: { patterns: [/個人情報保護法/, /電子帳簿保存法|電帳法/, /プロ責法|特定電気通信/, /弁護士法/, /医師法/, /金融商品取引法/, /AI事業者ガイドライン/, /EU\s*AI\s*法/], min: 2 },
      },
      {
        key: "pii_and_security",
        description_ja: "PII マスキング・BYOK・API キー保護・越境移転同意.",
        severity: "FAIL",
        must_any_regex: [/PII|個人情報/, /マスキング|redaction/, /BYOK|API\s*キー/, /越境|第三者提供/],
        must_not_regex: [/console\.log\([^)]*API_?KEY/],
        count_distinct_regex: { patterns: [/PII|個人情報/, /マスキング|redaction/, /BYOK/, /越境|第三者提供|外国/], min: 3 },
      },
      {
        key: "observability_standards",
        description_ja: "OpenTelemetry GenAI Semconv / W3C Trace Context / SSE / JSON Schema.",
        severity: "WARN",
        must_any_regex: [/OpenTelemetry|OTel|OTEL/, /W3C\s*Trace\s*Context|traceparent/, /JSON\s*Schema/, /SSE|Server-Sent\s*Events|RFC\s*8895/],
        count_distinct_regex: { patterns: [/OpenTelemetry|OTel/, /W3C|traceparent/, /JSON\s*Schema/, /SSE|RFC/], min: 2 },
      },
      {
        key: "naming_conventions",
        description_ja: "DB テーブル / API パス / 環境変数の命名規則 LLM_* prefix 一貫性.",
        severity: "FAIL",
        must_all_regex: [/llm_[a-z_]+/, /\/api\/v\d+\/llm\//, /LLM_[A-Z_]+/],
      },
      {
        key: "cost_control",
        description_ja: "トークンコスト・プロンプトキャッシュ・円換算コスト保存.",
        severity: "WARN",
        must_any_regex: [/トークン|token/, /コスト|cost/, /プロンプト\s*キャッシュ|prompt\s*caching/],
        count_distinct_regex: { patterns: [/トークン|token/, /コスト|cost/, /キャッシュ|caching/, /円換算|JPY|cost_jpy/], min: 3 },
      },
      {
        key: "cross_domain_boundary",
        description_ja: "Anthropic 単独の api_integration_ai_control との境界明示. Claude 単独 tool-use に閉じた記述でないこと.",
        severity: "WARN",
        must_any_regex: [/抽象化|抽象レイヤ|横断|マルチ/, /並存|併走|共存|responsibility/],
        must_not_regex: [/^(?:(?!(?:マルチ|複数|抽象|横断|プロバイダ)).)*$/],
      },
      {
        key: "forbidden_actions",
        description_ja: "弁護士法72条・医師法17条・金商法29条・個情法28条・API キー漏洩など禁止事項が deny-list として明示.",
        severity: "FAIL",
        must_all_regex: [/禁止/],
        must_any_regex: [/弁護士法/, /医師法/, /金融商品取引法|金商法/, /個人情報保護法\s*第?28条/, /API\s*キー.{0,10}(?:露出|漏洩|流出)/],
        count_distinct_regex: { patterns: [/弁護士法/, /医師法/, /金商法|金融商品取引法/, /個人情報保護法.*28/, /API\s*キー/], min: 2 },
      },
    ],
  },
  {
    key: "real_estate",
    name_ja: "不動産 (宅建業法/重説/借地借家法)",
    example_skill_name: "soloptilink-real-estate",
    law_industry_key: "real_estate",
    detection_patterns: [
      /不動産.{0,10}(スキル|SKILL\.md|Claude Code|エージェント|生成).{0,30}(?:宅建|重説|35条|37条|借地借家|賃貸借|媒介契約|レインズ)/,
      /(重説|重要事項).{0,10}(スキル|生成|作成|自動)/,
      /(賃貸|売買).{0,10}(契約|管理).{0,20}(スキル|システム|生成).{0,30}(?:宅建|重説|媒介|レインズ)/,
      /物件.{0,10}(管理|台帳|マスタ).{0,20}(スキル|システム|生成).{0,40}(?:宅建|重説|賃貸借|借地借家|媒介|レインズ|不動産)/,
      /区分所有.{0,10}(マンション|管理組合).{0,20}(スキル|システム)/,
      /(媒介|代理|売主).{0,10}(契約|報告書|台帳)/,
      /(借主|貸主|賃借人|賃貸人).{0,15}(契約|管理|システム)/,
      /(建物|土地).{0,10}(登記|謄本).{0,20}(取得|連携)/,
      /(用途地域|建ぺい率|容積率).{0,20}(判定|チェック|表示)/,
      /レインズ.{0,15}(連携|登録|API|取り込み)/,
      /at\s*home.{0,15}(連携|API|登録)/,
      /SUUMO.{0,15}(連携|API|掲載)/,
      /(住宅ローン|フラット35).{0,20}(審査|シミュレーション)/,
      /(敷金|礼金|更新料).{0,15}(計算|精算|管理)/,
      /(宅建士|宅地建物取引士).{0,15}(記名押印|説明|システム)/,
      /(修繕積立|管理費).{0,15}(徴収|管理|会計)/,
      /(定期借家|普通借家).{0,15}(契約|更新)/,
      /(不動産登記|登記事項証明書).{0,20}(取得|参照)/,
      /(固定資産税|都市計画税).{0,15}(按分|精算|計算)/,
      /IT重説.{0,15}(対応|システム|録画)/,
      /電子書面交付.{0,20}(35条|37条|承諾)/,
      /不動産ID/,
    ],
    injection_lines: [
      "## 業種特化: 不動産 (宅建業法/重説/借地借家法)",
      "- 委譲: `real-estate-domain-agent`, `legal-compliance-agent`, `document-generator-agent`",
      "- 主要ライブラリ: `reins-sdk`, `ath-osaka-connect`, `real-estate-portal-sdk`, `pdfkit`, `zenginkoto`",
      "- 標準規格: 全銀協フォーマット, ISO 8601, RFC 3339, JIS X 0401/0402, 不動産公正取引協議会 表示規約",
      "- 命名規則: テーブル `properties` / `contracts_35jo` / `contracts_37jo` / `tenants` / `landlords` / `management_associations`, カラム `transaction_type` (baibai_shu / dairi / baikai), API `/api/v1/properties/:id/juyou-jikou`",
      "- 発火主体制限: 本ドメインは **宅建業者/不動産仲介業者/賃貸管理会社/マンション管理会社を主体とする案件のみ**発火する. IT 資産管理・レンタル物件管理・倉庫物件管理は本ドメイン非該当.",
      "- 法令根拠: 宅地建物取引業法 第35条 (重要事項説明), 第37条 (契約書面交付), 第47条 (誇大広告禁止), 第64条の8 (弁済業務保証金) — japan-link `recommendLaws('real_estate')` で自動同梱",
      "- 法令根拠: 借地借家法 第26条 / 第28条 / 第38条, 区分所有法 第30条 / 第39条, 民法 第601条 / 第606条, 建築基準法 第52-56条, 都市計画法 第8-9条",
      "- **法令根拠 (2023-2025 最新)**: IT 重説 (2021年3月本格化), 電子書面交付 (35条・37条電子化 2022年5月, 相手方承諾書必須), 空き家対策特別措置法 2023年改正 (管理不全空家), 不動産 ID (2024年運用開始), 民法改正 (相隣関係・共有物・所有者不明土地), 相続登記義務化 (2024年4月), 改正建物区分所有法 (2025年), レインズ IP-VPN 廃止/API 化, 住宅省エネ 2024 キャンペーン, 土地基本方針を injection.",
      "- **law_ai_boundary (宅建業法35条越境防止)**: SKILL.md 冒頭に『本スキルは宅建業法第35条・第37条に鑑み、重要事項説明書の作成主体は宅地建物取引業者、説明主体は宅地建物取引士 (IT 重説を含む) に限られる。AI は書面の下書き作成・条項の網羅チェック・法令引用の補助に留める』を明記. 生成書面に『宅建士氏名・登録番号・記名』を必須フィールド化し AI 生成のみでの送信を quality_gate で BLOCK. IT 重説実施要件 (通信環境・図面確認・宅建士証提示・録音録画) をチェックリスト化. 賃貸媒介の重説項目 (2024年施行の管理業法対応含む) を最新化.",
      "- 実装パターン: 重説35条は 5関数に分割, 契約更新処理は冪等キー (契約ID + 更新回次) で二重発行防止, 登記情報取得は指数バックオフ",
      "- 品質チェック: born-passing で35条書面必須32項目の欠落検出, 用途地域13区分の網羅テスト, 借地借家法38条定期借家契約の書面要件E2E, レインズ登録期限 (専任媒介7日/専属専任5日) の期限アラート",
      "- 禁止事項: 弁護士法72条抵触 (契約紛争の代理・仲裁 → 提携弁護士へエスカレーション), 宅地建物取引士以外による重要事項説明の代行 (35条違反), 個人情報保護法23条違反となる家賃滞納情報の第三者提供, おとり広告 (宅建業法47条/公正競争規約違反), 反社会的勢力排除条項の未挿入",
      "- IT重説対応: 賃貸は完全実施可, 売買は2021年3月以降解禁. 録画・録音の3年間保管義務, 事前に35条書面電磁的交付の承諾取得を必須化",
      "- 個人情報保護: 借主/貸主の本人確認書類 (犯罪収益移転防止法4条) は暗号化保管, アクセスログ7年保持, 反社チェックAPI 連携",
      "- 区分所有マンション管理: 管理費/修繕積立金の会計は「マンション標準管理規約」準拠, 総会議事録は区分所有法42条の書面要件",
    ],
    quality_axes: [
      {
        key: "law_citation_completeness",
        description_ja: "宅建業法/借地借家法/区分所有法の主要条文が条番号付き",
        severity: "FAIL",
        must_all_regex: [/宅地建物取引業法.{0,10}第?35条/, /宅地建物取引業法.{0,10}第?37条/, /借地借家法/],
        must_any_regex: [/区分所有法/, /民法.{0,10}第?601条/, /建築基準法/],
      },
      {
        key: "juyou_jikou_35jo_coverage",
        description_ja: "重要事項説明書35条の必須記載項目",
        severity: "FAIL",
        must_all_regex: [/重要事項説明/, /35条/],
        must_any_regex: [/登記/, /用途地域/, /インフラ|給排水|ガス|電気/, /取引条件|代金|手付/],
        count_distinct_regex: { patterns: [/物件.{0,5}(所在|情報)/, /権利/, /法令.{0,5}制限/, /インフラ|給排水/, /取引条件/], min: 3 },
      },
      {
        key: "transaction_type_enum",
        description_ja: "取引態様 (売主/代理/媒介) の3区分 enum",
        severity: "FAIL",
        must_all_regex: [/取引態様/],
        must_any_regex: [/売主.{0,5}代理.{0,5}媒介|baibai_shu.{0,10}dairi.{0,10}baikai/],
      },
      {
        key: "prohibited_practices",
        description_ja: "弁護士法72条・宅建士以外の重説代行・おとり広告",
        severity: "FAIL",
        must_all_regex: [/禁止|禁じ/],
        must_any_regex: [/弁護士法.{0,5}72条/, /宅地建物取引士|宅建士/, /おとり広告|誇大広告|47条/],
        must_not_regex: [/宅建士.{0,10}無資格.{0,10}(代行|説明).{0,5}(可|OK|許可)/],
      },
      {
        key: "library_and_integration",
        description_ja: "レインズ/アットホーム/ポータル連携ライブラリ",
        severity: "FAIL",
        must_any_regex: [/reins-sdk/, /ath-osaka-connect/, /real-estate-portal-sdk/, /レインズ/],
      },
      {
        key: "leased_property_law_coverage",
        description_ja: "借地借家法の主要条項",
        severity: "WARN",
        must_all_regex: [/借地借家法/],
        must_any_regex: [/定期借家|38条/, /更新拒絶|26条/, /正当事由|28条/],
      },
      {
        key: "condominium_management",
        description_ja: "区分所有マンション管理の管理費/修繕積立金/総会決議",
        severity: "WARN",
        must_any_regex: [/管理費/, /修繕積立/, /総会|集会/, /管理組合/],
        count_distinct_regex: { patterns: [/管理費/, /修繕積立/, /総会|集会|39条/, /規約|30条/], min: 2 },
      },
      {
        key: "it_juusetsu_compliance",
        description_ja: "IT重説の録画保管義務・電磁的交付",
        severity: "WARN",
        must_any_regex: [/IT重説/, /電磁的.{0,10}(交付|方法)|電子書面交付/, /録画|録音/],
      },
      {
        key: "naming_convention_stability",
        description_ja: "テーブル名/API パスが英小文字スネークケース",
        severity: "WARN",
        must_any_regex: [/properties|contracts_35jo|contracts_37jo|tenants|landlords/],
        must_not_regex: [/Properties\s*テーブル/, /ContractsCamelCase/],
      },
      {
        key: "delegation_agents_declared",
        description_ja: "Centuria 実在エージェント委譲宣言",
        severity: "WARN",
        must_any_regex: [/real-estate-domain-agent/, /legal-compliance-agent/, /document-generator-agent/],
      },
      {
        key: "latest_real_estate_2023_2025",
        description_ja: "IT重説/電子書面交付/不動産ID/相続登記義務化/管理不全空家 いずれか",
        severity: "WARN",
        must_any_regex: [/IT重説/, /電子書面交付/, /不動産ID/, /相続登記義務化/, /管理不全空家/, /改正建物区分所有法/, /レインズ\s*API/],
      },
    ],
  },
  {
    key: "retail_ecommerce",
    name_ja: "小売EC (特商法/景表法/PL法)",
    example_skill_name: "soloptilink-retail-ecommerce",
    law_industry_key: "retail",
    detection_patterns: [
      /特定商取引法.{0,10}(表記|表示|11項目|SKILL|スキル)/,
      /景品表示法.{0,15}(チェック|審査|表示|違反|SKILL|スキル)/,
      /(EC|イーコマース|通販|ネット通販).{0,20}(サイト|システム|スキル|SKILL\.md|Claude Code)/,
      /(Shopify|BASE|STORES|楽天|Amazon|メルカリ).{0,15}(連携|API|同期|在庫|注文|スキル)/,
      /(店舗|店頭|レジ).{0,10}POS.{0,20}(在庫|売上|同期|スキル|SKILL)/,
      /在庫.{0,10}(引当|同期|補充|棚卸|SKU|マルチチャネル)/,
      /(JAN|EAN|GTIN|ISBN).{0,15}(コード|管理|採番|スキャン)/,
      /リコール.{0,15}(管理|台帳|通知|届出|PL法|製品事故)/,
      /二重価格.{0,15}(8週間|比較対照|表示|ルール)/,
      /(優良誤認|有利誤認).{0,15}(表示|該当|チェック|判定)/,
      /特商法.{0,10}(11項目|返品|事業者名|所在地|表記自動生成)/,
      /薬機法.{0,15}(広告|表示|化粧品|健康食品|効能効果)/,
      /(消費者契約法|電子契約法).{0,15}(EC|通販|規約|同意)/,
      /(容器包装|資源有効利用).{0,15}(識別|表示|プラマーク|リサイクル)/,
      /PL法.{0,15}(製造物責任|リコール|表示|警告)/,
      /(SKU|バリアント|商品マスタ).{0,15}(管理|登録|CSV|スキル)/,
      /(送料|配送|お届け).{0,15}(自動|計算|表示|離島|地域別)/,
      /(定期購入|サブスク).{0,15}(EC|通販|解約|表示|特商法)/,
      /(景表法|措置命令|優良誤認).{0,20}(SKILL|スキル生成|Claude Code)/,
      /ステマ規制.{0,30}(EC|表示|景表法)/,
      /Cookie\s*同意管理|外部送信規律/,
    ],
    injection_lines: [
      "**委譲エージェント**: `centuria-legal-compliance`, `centuria-ec-integration`, `centuria-copy-auditor`",
      "**主要ライブラリ (npm)**: `shopify-api-node` / `@amazon-sp-api/amazon-sp-api` / `rakuten-webservice` / `base-partner-api` / `stores-partner-api` / `mercari-shops-api`. 楽天/Amazon は OAuth 2.0 + Refresh Token 必須",
      "**主要ライブラリ (Python 補完)**: `python-stdnum` (ISBN/EAN/JAN), `weasyprint`, `sudachipy` + 独自辞書 `retail_ec_ng_words.json`",
      "**標準規格/フォーマット**: JAN-13/EAN-13 (ISO/IEC 15420), ISBN-13 (ISO 2108), PCI DSS v4.0, 流通 BMS (JIS X 7011-1), RFC 9110, HMAC-SHA256 (RFC 2104)",
      "**命名規則**: `products` / `product_variants` / `inventories` / `orders` / `order_items` / `tokushoho_disclosures` / `recall_incidents` / `channel_sync_logs`. カラムは `jan_code` / `sku` / `list_price_yen` / `compared_price_started_at`. API `/api/v1/{channel}/inventory/sync` `/api/v1/tokushoho/disclosures`",
      "**法令根拠 (特商法)**: 特定商取引法 第11条 (通信販売の広告表示) の 11項目, 定期購入は第12条の6 (最終確認画面の表示義務, 2022年6月改正). **japan-link の recommendLaws('retail') により自動同梱**",
      "**法令根拠 (景表法/PL法/薬機法)**: 景品表示法 第5条 (優良誤認・有利誤認), 二重価格は過去8週間のうち4週間以上の販売実績. 製造物責任法 第3条 によりリコール台帳保管期間10年. 医薬品医療機器等法 第68条 と 化粧品の効能効果56項目を NG チェック",
      "**法令根拠 (2023-2025 最新)**: 改正特商法 2023年6月 (定期購入 詳細表示義務), 改正電気通信事業法 (外部送信規律 2023年6月), Cookie 同意管理, 改正景表法 (ステマ規制 2023年10月), 改正 PL 法 (製造物責任オンライン販売者の責任), Amazon SP-API v2, Shopify Functions, TikTok Shop, 改正資金決済法 (前払式支払手段), 特定デジタルプラットフォーム透明化法を injection.",
      "**実装パターン (冪等性)**: `channel_sync_logs.idempotency_key = ${channel}:${sku}:${event_ts}` で二重同期抑止. Webhook は署名検証 → 重複判定 → キューイング → ワーカで引当反転 → 各チャネル API PATCH の 5段. 失敗は Dead Letter Queue",
      "**実装パターン (特商法表記自動生成)**: `TokushohoDisclosureGenerator` を `generate() / validate11Items() / renderHtml() / renderPdf()` に分割. 11項目欠落時は `MissingRequiredItemError` を 422 で返却",
      "**実装パターン (景表法チェック)**: `PriceAuditor.checkDualPrice(product)` は `compared_price_started_at` が `now() - 8週間` 以前かつ 該当価格での販売実績が延べ4週間以上あることをDBで検証. NG ワード辞書は `KeisohoLinter.lint(text)`",
      "**品質チェック (born-passing)**: (1) 特商法11項目全欠落→11個の error 検出, (2) 二重価格 8週間未満→違反1件, (3) 楽天在庫Webhook 二重送信→1回だけ引当, (4) JAN チェックデジット不正→登録拒否, (5) リコール発生→顧客通知メールキュー投入. E2E は Shopify Sandbox + 楽天RMS Test",
      "**禁止事項 (法令)**: (1) 特商法11項目のいずれかを省略した EC 公開は法令違反, (2) 二重価格 8週間ルール未検証のセール価格表示は景表法違反, (3) 化粧品/健康食品の効能効果を医薬品的に暗示する表現は薬機法68条違反, (4) リコール台帳の10年保管未満は PL法・消費生活用製品安全法違反",
      "**禁止事項 (越境)**: 弁護士法 第72条により約款・利用規約の個別法律アドバイス生成禁止. 医師法 第17条により健康食品の症状改善診断表現を生成禁止. 個人情報保護法 第27条により顧客リストの外部チャネル送信は同意取得ログ必須",
      "**cross_domain 境界**: (1) EC 側税率・特商法表記は本ドメイン主管、仕訳・消費税区分・電帳法保存は accounting_tax_finance に委譲. (2) EC × 物流の一気通貫案件は主管ドメインを 1 つ選び補助ドメインの injection_lines のみ追加インポート — 特商法/景表法/PL 法 anchor がヒットしていれば本ドメイン主管.",
    ],
    quality_axes: [
      {
        key: "tokushoho_11items_coverage",
        description_ja: "特商法11項目 + 定期購入 (12条の6)",
        severity: "FAIL",
        must_all_regex: [/特定商取引法/, /11項目/, /返品特約/, /最終確認画面/],
        must_any_regex: [/第11条/, /第12条の6/],
      },
      {
        key: "keihyoho_dual_price_rule",
        description_ja: "景表法二重価格 8週間ルール",
        severity: "FAIL",
        must_all_regex: [/景品表示法/, /二重価格/, /8週間/],
        must_any_regex: [/4週間/, /比較対照/, /販売実績/],
        must_not_regex: [/景表法.{0,20}(問題なし|自由)/],
      },
      {
        key: "pl_law_recall_management",
        description_ja: "製造物責任法 + リコール管理台帳 (保管期間10年)",
        severity: "FAIL",
        must_all_regex: [/製造物責任法/, /リコール/],
        must_any_regex: [/10年/, /第3条/, /台帳/],
      },
      {
        key: "multi_channel_integration",
        description_ja: "最低4チャネル連携ライブラリ",
        severity: "FAIL",
        count_distinct_regex: { patterns: [/shopify-api-node/, /amazon-sp-api/, /rakuten-webservice/, /base-partner-api/, /stores-partner-api/, /mercari-shops-api/], min: 4 },
      },
      {
        key: "product_code_standards",
        description_ja: "JAN/EAN/GTIN/ISBN の標準規格番号",
        severity: "FAIL",
        must_all_regex: [/JAN|EAN/],
        must_any_regex: [/ISO\/IEC 15420/, /ISO 2108/, /GS1/, /JAN-13/, /EAN-13/],
      },
      {
        key: "yakkiho_ad_restriction",
        description_ja: "薬機法68条 + 化粧品効能効果56項目",
        severity: "FAIL",
        must_all_regex: [/薬機法/],
        must_any_regex: [/第68条/, /効能効果/, /承認前/, /化粧品/],
      },
      {
        key: "idempotency_and_webhook_security",
        description_ja: "HMAC-SHA256 + idempotency_key",
        severity: "FAIL",
        must_all_regex: [/HMAC-SHA256|HMAC/, /idempotency/, /Webhook/],
        must_any_regex: [/署名検証/, /冪等/, /重複/],
      },
      {
        key: "born_passing_tests_present",
        description_ja: "born-passing 5シナリオ",
        severity: "FAIL",
        must_all_regex: [/born-passing/],
        count_distinct_regex: { patterns: [/特商法/, /二重価格/, /在庫/, /JAN/, /リコール/], min: 4 },
      },
      {
        key: "cross_domain_boundary_guard",
        description_ja: "弁護士法72条 / 医師法17条 / 個情法27条",
        severity: "FAIL",
        must_all_regex: [/弁護士法/, /72条/],
        must_any_regex: [/医師法/, /個人情報保護法/, /同意取得/],
      },
      {
        key: "japan_link_recommend_laws",
        description_ja: "japan-link recommendLaws('retail') 自動同梱",
        severity: "WARN",
        must_all_regex: [/japan-link/, /recommendLaws/],
        must_any_regex: [/retail/, /自動同梱/],
      },
      {
        key: "latest_ec_2023_2025",
        description_ja: "ステマ規制/定期購入表示義務/外部送信規律/特定デジタルプラットフォーム透明化法いずれか",
        severity: "WARN",
        must_any_regex: [/ステマ規制/, /定期購入表示義務/, /Cookie\s*同意管理/, /外部送信規律/, /特定デジタルプラットフォーム透明化法/],
      },
    ],
  },
];

/**
 * ドメイン強アンカー (1 件でも当たれば確定・共起不要).
 * Claude Code 固有名詞や JIS 規格名等の高信頼度ワード群.
 */
export const SKILL_DOMAIN_STRONG_ANCHORS = {
  construction_drawing: [
    /construction-drawing-specialist/,
    /JIS\s*A\s*0150|JIS\s*Z\s*8114|JIS\s*Z\s*8317|JIS\s*Z\s*8321/,
    /建築製図通則/,
    /SXF/,
    /矩計図|意匠図.*(?:構造|設備)/,
    /建築士法|建築基準法|建設業法/,
    /確認申請図|竣工図|実施設計図|基本設計図/,
    /BIM|IFC.*(?:BIM|建築|建設)/,
    /施工管理|工事写真|構造計算|積算|工程表|安全書類|躯体図|配筋図/,
    // === 建設強化パッチ (追加 strong anchors) ===
    /建築士法\s*(?:第\s*)?(?:2|3|3の2|18|20|24)条.*(?:設計図書|工事監理|重要事項説明|名義貸し|一級建築士|二級建築士)/,
    /建築基準法\s*(?:第\s*)?(?:6|6の2|7|12|20|48|52|53|56)条.*(?:確認申請|完了検査|定期報告|構造計算適合性判定|用途地域|建蔽率|容積率|斜線制限|日影規制)/,
    /建設業法\s*(?:第\s*)?(?:19|24の3|24の6|24の8|26|27の23)条.*(?:請負契約書|下請代金|一括下請負|主任技術者|監理技術者|経営事項審査|CCUS)/,
    /下請法.*(?:建設|建築|工事).*(?:60日以内|支払期日|受領拒否|買いたたき|返品|減額|やり直し)/,
    /省エネ法|建築物省エネ法.*(?:BEI|一次エネルギー消費量|外皮平均熱貫流率|UA値|ηAC値|適合性判定|届出|説明義務|ZEB|ZEH)/,
    /都市計画法\s*(?:第\s*)?(?:29|33|34|43|53)条.*(?:開発許可|市街化区域|市街化調整区域|地区計画|用途地域|建築制限)/,
    /耐震改修促進法.*(?:要緊急安全確認大規模建築物|要安全確認計画記載建築物|耐震診断|Is値|q値|CTU・SD値|特定既存耐震不適格建築物)/,
    /バリアフリー法|建築物移動等円滑化.*(?:特定建築物|特別特定建築物|認定建築物|廊下幅|スロープ勾配|多機能便房|視覚障害者誘導用ブロック)/,
    /建設リサイクル法.*(?:80㎡以上|500㎡以上|1億円以上|1000万円以上|特定建設資材|分別解体|再資源化|事前届出|コンクリート|アスファルト|木材)/,
    /品確法|住宅品質確保促進法.*(?:10年間|瑕疵担保|構造耐力上主要な部分|雨水の浸入|住宅性能表示|評価書|新築住宅)/,
  ],
  claude_code_sdk_dev: [
    /Claude Code SDK|Claude Agent SDK|クロードコードSDK|クロードエージェントSDK/i,
    /@anthropic-ai\/sdk|@modelcontextprotocol\/sdk|@modelcontextprotocol\/inspector/,
    /\.claude\/agents|\.claude\/commands|\.claude\/plugins|\.claude\/skills/,
    /SessionStart|PostToolUse|UserPromptSubmit|PreToolUse|SessionEnd|PreCompact|SubagentStop/,
    /claude mcp add|claude mcp list/,
    /(?:SKILL\.md|allowed-tools|argument-hint|frontmatter).*(?:frontmatter|SKILL\.md|allowed-tools|argument-hint)/i,
    /オープンクロー|Open Claude|自作(?:スキル|エージェント|MCP|フック|スラッシュコマンド)/,
    /output[- ]?style|OutputStyle|出力スタイル/i,
    /keybindings\.json|~\/\.claude\/settings|permissions\.(allow|deny)/,
    /Claude\s*Code\s*Plugin|プラグイン開発|marketplace\.json|plugin manifest/i,
  ],
  api_integration_ai_control: [
    /~\/\.soloptilink\/lib\/ibl\.sh|ibl\.sh (?:detect|inject)/,
    /connector-forge\.sh forge/,
    /parallel-exec-v2/,
    /Centuria|105\s*ロール/,
    /Idempotency-Key|idempotency_key/,
    /(?:MCP|Model Context Protocol)\s*(?:server|サーバー|コネクタ|クライアント|統合|連携)|(?:サーバー|コネクタ|統合|連携)\s*MCP/i,
    /HMAC.*(?:signature|署名)|X-Hub-Signature|X-Signature/i,
    /(?:Salesforce|HubSpot|Zoho|kintone|Slack|Teams|Discord|LINE|Zoom|freee|勘定奉行|GitHub|GitLab|Notion|Airtable|Stripe|Shopify)\s*(?:API|連携|統合|コネクタ|webhook|Webhook)/i,
    /tool_choice|tool_use|structured output|input_schema/i,
    /Retrieval[- ]?Augmented|RAG.*(?:検索|生成|拡張)|(?:vector\s*(?:DB|database|store))|ベクトル(?:DB|検索|データベース)|pinecone|weaviate|qdrant|chroma|pgvector/i,
    /prompt[- ]?caching|プロンプトキャッシュ|batch\s*API|message\s*batches|extended\s*thinking|thinking\s*mode|files\s*API|citations/i,
    /(?:embedding|エンベディング|埋め込みベクトル|text-embedding|voyage[- ]?ai)/i,
  ],
  accounting_tax_finance: [
    /電子帳簿保存法/,
    /電帳法/,
    /適格請求書等保存方式/,
    /インボイス制度/,
    /適格請求書発行事業者登録番号/,
    /T\d{13}/,
    /freee[- ]?accounting[- ]?sdk/,
    /moneyforward[- ]?cloud[- ]?api/,
    /obic[- ]?openapi/,
    /勘定奉行/,
    /弥生会計/,
    /法人税別表/,
    /e[- ]?Tax[- ]?sdk/,
    /e-Tax\s*API/,
    /eLTAX\s*PCdesk/,
    /源泉徴収税額表/,
    /消費税法第30条/,
    /定額減税/,
    /2\s*割特例/,
    /インボイス\s*8\s*割控除/,
    /インボイス\s*5\s*割控除/,
    /JIIMA\s*認証/,
    /適格請求書発行事業者公表(?:API|サイト)/,
    /グローバルミニマム課税/,
    /GloBE/,
    /外形標準課税拡大/,
  ],
  care_welfare: [
    /介護報酬請求/,
    /国保連伝送/,
    /介護給付費請求/,
    /処遇改善加算/,
    /特定処遇改善加算/,
    /介護職員等ベースアップ等支援加算/,
    /介護サービスコード/,
    /ケアプラン第[1-7]表/,
    /居宅サービス計画書/,
    /介護保険法第[0-9]+条/,
    /介護報酬告示/,
    /要介護認定[1-5]/,
    /care-record-sdk/,
    /kokuho-transmission/,
    /care-service-code/,
    /LIFE/,
    /科学的介護情報システム/,
    /生産性向上推進体制加算/,
    /BCP\s*未策定減算/,
    /高齢者虐待防止推進体制加算/,
    /看多機|看護小規模多機能/,
    /介護DB|介護保険総合データベース/,
    /2024年度介護報酬改定/,
    /地域包括ケアシステム\s*2025/,
  ],
  education_lms: [
    /SCORM\s*2004/,
    /SCORM\s*1\.2/,
    /xAPI\s*Statement/,
    /Tin\s*Can\s*API/,
    /cmi\.core\./,
    /cmi\.interactions/,
    /cmi\.objectives/,
    /LRS\s*(?:サーバ|エンドポイント|連携)/,
    /学校教育法施行規則/,
    /学習指導要領/,
    /指導要録/,
    /調査書\s*(?:出力|生成|様式)/,
    /moodle-sdk/,
    /scorm-again/,
    /IMS\s*Global/,
    /MEXCBT/,
    /学習eポータル/,
    /校務DX|次世代校務支援システム/,
    /LTI\s*Advantage/,
    /生成AIの学校教育ガイドライン/,
    /デジタル教科書/,
    /GIGAスクール\s*NEXT/,
  ],
  hr_labor_management: [
    /36協定[^\S\n]{0,3}(スキル|SKILL\.md|Claude Code)/,
    /労働基準法[^\S\n]{0,3}(スキル|SKILL\.md|自動生成)/,
    /労働安全衛生法[^\S\n]{0,3}(スキル|SKILL\.md|Claude Code)/,
    /育児介護休業法[^\S\n]{0,3}(スキル|SKILL\.md|Claude Code)/,
    /障害者雇用促進法[^\S\n]{0,3}(スキル|SKILL\.md|Claude Code)/,
    /SmartHR[^\S\n]{0,3}(API|連携|スキル)/,
    /KING\s?OF\s?TIME[^\S\n]{0,3}(API|連携|勤怠)/,
    /ジョブカン[^\S\n]{0,3}(API|連携|勤怠)/,
    /freee[人事労務|HR][^\S\n]{0,3}(API|連携|スキル)/,
    /健康保険等級[^\S\n]{0,3}(スキル|自動計算|判定)/,
    /厚生年金等級[^\S\n]{0,3}(スキル|自動計算|判定)/,
    /特別条項付き36協定[^\S\n]{0,3}(スキル|チェック|上限)/,
    /労務管理[^\S\n]{0,3}(スキル|SKILL\.md|Claude Code)/,
    /勤怠管理[^\S\n]{0,3}(スキル|SKILL\.md|Claude Code)/,
    /給与計算[^\S\n]{0,3}(スキル|SKILL\.md|Claude Code)/,
    /社会保険適用拡大/,
    /フリーランス保護新法/,
    /女性活躍推進法.*男女賃金差/,
    /特定技能\s*2号/,
    /パワハラ防止措置義務/,
    /改正雇用保険法/,
  ],
  legal_document: [
    /契約書レビュー.{0,20}(スキル|SKILL\.md|Claude Code)/,
    /弁護士法.{0,10}72条/,
    /非弁(行為|提携)/,
    /電子署名法.{0,20}(第[0-9]+条|スキル|SKILL)/,
    /下請代金支払遅延等防止法/,
    /下請法.{0,20}(審査|チェック|レビュー|スキル)/,
    /印紙税(法|額).{0,20}(第[0-9]+号文書|スキル|SKILL)/,
    /リーガルテック.{0,20}(スキル|SKILL\.md|Claude Code|生成)/,
    /CloudSign|クラウドサイン/,
    /DocuSign|ドキュサイン/,
    /GMOサイン|GMO電子印鑑/,
    /e-Sign.{0,20}(スキル|API|SKILL|Claude Code)/,
    /電子帳簿保存法.{0,20}(電子取引|スキャナ保存|スキル)/,
    /民法.{0,10}(債権法改正|第[0-9]+条)/,
    /契約書.{0,10}(21類型|類型判定)/,
    /フリーランス保護新法/,
    /特定受託事業者に係る取引の適正化/,
    /改正下請法\s*2026/,
    /AI事業者ガイドライン/,
    /経済安全保障推進法|特定重要技術/,
    /LegalOn|MNTSQ|リーガルフォース/,
    /PAdES-LTV|長期署名/,
  ],
  logistics_transportation: [
    /貨物利用運送事業法/,
    /貨物自動車運送事業法/,
    /改善基準告示/,
    /yamato-b2/,
    /sagawa-webapi/,
    /japanpost-api/,
    /seino-webapi/,
    /logi-edi/,
    /waku-tms/,
    /送り状番号/,
    /貨物追跡ステータス/,
    /運行三費/,
    /digital-tachograph/,
    /2024年問題/,
    /改正物流総合効率化法/,
    /フィジカルインターネット/,
    /中継輸送/,
    /共同配送/,
    /GS1標準/,
    /ETC2\.0/,
  ],
  manufacturing_production: [
    /BOM階層/,
    /MES連携/,
    /OPC[- ]?UA/,
    /OEE計算/,
    /SPC管理図/,
    /ロットトレーサビリティ/,
    /JIS[ ]?Q[ ]?9001/,
    /JIS[ ]?Q[ ]?14001/,
    /省エネ法.*(定期報告|エネルギー使用状況)/,
    /下請代金支払遅延等防止法/,
    /化管法.*PRTR/,
    /MRP所要量計算/,
    /工程能力指数[ ]?(Cp|Cpk)/,
    // ★2026-08-06 是正: 実在しないパッケージ名 (opc-ua-client / mes-connector / bom-manager) を
    //   検出語から撤去。当社が自ら注入した架空名でドメイン確定するのは自己参照であり、
    //   かつ実在しない依存を再生産する温床になる。実機収集の語は OPC-UA / MES連携 側が拾う。
    /IEC\s*62443/,
    /AAS|Asset\s*Administration\s*Shell/,
    /MTConnect/,
    /デジタルツイン/,
    /予知保全/,
    /GHG\s*プロトコル\s*Scope\s*3/,
    /CBAM/,
  ],
  medical_healthcare: [
    /レセ電/,
    /レセプト電算/,
    /オンライン資格確認/,
    /電子処方箋/,
    /電子処方箋管理サービス/,
    /マイナ保険証/,
    /全国医療情報プラットフォーム/,
    /医療DX令和ビジョン2030/,
    /次世代医療基盤法/,
    /HL7\s*FHIR/,
    /SS-?MIX2/,
    /DPC(?:\s*(?:診断群分類|コード|6桁))/,
    /DPC\/PDPS/,
    /HPKI(?:カード|署名)?/,
    /3省2ガイドライン/,
    /医療情報の安全管理に関するガイドライン/,
    /医療機関等サイバーセキュリティチェックリスト/,
    /MEDIS-?DC/,
    /JLAC10/,
    /HOT9(?:桁)?医薬品/,
    /看護必要度\s*IV/,
    /SaMD/,
    /オンライン診療の適切な実施に関する指針/,
    /@medplum\/(?:core|fhirtypes)/,
    /hl7-fhir-typescript/,
  ],
  multi_llm_provider: [
    /マルチ\s*LLM\s*プロバイダ/,
    /LLM\s*プロバイダ\s*抽象化/,
    /LLM\s*ルーティング/,
    /LLM\s*フォールバック\s*チェーン/,
    /LLM\s*フェイルオーバー/,
    /Vercel\s*AI\s*SDK.{0,20}(?:スキル|SKILL\.md)/,
    /LiteLLM.{0,30}(?:スキル|SKILL\.md|Claude\s*Code)/,
    /マルチプロバイダ.{0,20}(?:抽象化|ルーター|ゲートウェイ)/,
    /OpenRouter/,
    /Portkey/,
    /AWS\s*Bedrock/,
    /Vertex\s*AI\s*Model\s*Garden/,
    /Azure\s*OpenAI/,
    /Groq/,
    /Together\s*AI/,
    /Fireworks/,
    /Cerebras/,
    /@google\/genai/,
    /gemini-2\.5-pro/,
    /gemini-2\.5-flash/,
    /deepseek-(?:v3|reasoner|chat)/,
    /grok-(?:3|4)\b/,
    /llama-(?:3\.3|4)-/,
    /mixtral-8x22b/,
    /command-r-plus/,
    /Claude\s*4(?:\.5)?\s*Sonnet/,
    /Claude\s*Opus\s*4(?:\.7)?/,
    /Qwen\s*3/,
    /Kimi\s*K2/,
    /Yi-Large/,
    /AI事業者ガイドライン/,
  ],
  real_estate: [
    /重要事項説明書/,
    /35条書面/,
    /37条書面/,
    /宅地建物取引業法/,
    /借地借家法/,
    /区分所有法/,
    /宅建業/,
    /取引態様/,
    /reins-sdk/,
    /ath-osaka-connect/,
    /real-estate-portal-sdk/,
    /レインズ/,
    /レインズ\s*API/,
    /用途地域/,
    /宅地建物取引士/,
    /IT重説/,
    /電子書面交付/,
    /不動産ID/,
    /相続登記義務化/,
    /管理不全空家|空き家対策特別措置法/,
    /改正建物区分所有法/,
    /住宅省エネ\s*2024/,
  ],
  retail_ecommerce: [
    /特定商取引法に基づく表記/,
    /景品表示法/,
    /特商法表記/,
    /二重価格表示/,
    /有利誤認表示/,
    /優良誤認表示/,
    /shopify-api-node/,
    /amazon-sp-api/,
    /rakuten-webservice/,
    /mercari-shops-api/,
    /製造物責任法/,
    /景表法チェック/,
    /リコール管理台帳/,
    /JAN\/EAN/,
    /薬機法広告/,
    /ステマ規制/,
    /定期購入表示義務/,
    /Cookie同意管理/,
    /外部送信規律/,
    /特定デジタルプラットフォーム透明化法/,
    /Shopify\s*Functions/,
    /Amazon\s*SP-API\s*v2/,
    /TikTok\s*Shop/,
  ],
};

/**
 * ドメイン別最小ヒット数 (弱パターンヒットのみの場合の必要件数).
 * 強アンカーが 1 件でも当たればこの閾値を無視して確定する.
 */
export const SKILL_DOMAIN_MIN_HITS = {
  construction_drawing: 2,
  claude_code_sdk_dev: 2,
  api_integration_ai_control: 2,
  accounting_tax_finance: 2,
  care_welfare: 2,
  education_lms: 2,
  hr_labor_management: 2,
  legal_document: 2,
  logistics_transportation: 2,
  manufacturing_production: 2,
  medical_healthcare: 2,
  multi_llm_provider: 2,
  real_estate: 2,
  retail_ecommerce: 2,
};

/**
 * タスク文からドメインを検出 (複数該当可・二段閾値).
 *
 * 判定ロジック (ドメイン毎):
 *  1. 強アンカーが 1 件でもヒット → 確定 (Claude Code 固有語・JIS 規格・IBL 等の高信頼度ワード)
 *  2. 弱パターンが min_hits (既定 2) 件以上 → 確定
 *  3. どれも満たさない → 未検出 (false positive 根絶)
 *
 * これにより「MCP」「Slack」「平面図」等の単独出現による誤発火を根絶する.
 */
export function detectSkillDomains(taskText) {
  if (!taskText || typeof taskText !== "string") return [];
  const normalized = normalizeTaskText(taskText);
  const detected = [];
  for (const dom of SKILL_DOMAINS) {
    // 1. 強アンカー確認
    const strong_anchors = SKILL_DOMAIN_STRONG_ANCHORS[dom.key] || [];
    const strong_matches = [];
    for (const pat of strong_anchors) {
      const m = normalized.match(pat);
      if (m) strong_matches.push({ pattern: pat.source, snippet: m[0] });
    }
    // 2. 弱パターン全走査 (件数を数える)
    const weak_matches = [];
    for (const pat of dom.detection_patterns) {
      const m = normalized.match(pat);
      if (m) weak_matches.push({ pattern: pat.source, snippet: m[0] });
    }
    const min_hits = SKILL_DOMAIN_MIN_HITS[dom.key] || 2;
    const confirmed = strong_matches.length > 0 || weak_matches.length >= min_hits;
    if (confirmed) {
      detected.push({
        domain_key: dom.key,
        name_ja: dom.name_ja,
        matched: (strong_matches[0] || weak_matches[0]).snippet,
        pattern: (strong_matches[0] || weak_matches[0]).pattern,
        strong_matches: strong_matches.length,
        weak_matches: weak_matches.length,
        source: strong_matches.length > 0 ? "strong_anchor" : `weak_matches>=${min_hits}`,
      });
    }
  }

  // クロスドメインドリフト解消:
  // SDK と API 両方が weak_matches のみで検出された場合、Claude Code 固有 anchor があれば SDK 優先し API を落とす.
  // (「MCP prompt を作るスキル」→ SDK に流したい / api_integration_ai_control の MCP パターンから逃す)
  const has_sdk = detected.find((d) => d.domain_key === "claude_code_sdk_dev");
  const has_api = detected.find((d) => d.domain_key === "api_integration_ai_control");
  if (has_sdk && has_api && has_sdk.strong_matches === 0 && has_api.strong_matches === 0) {
    // Claude Code 固有 anchor (SKILL.md / .claude/ / SDK / スラッシュコマンド SDK 系) が優勢なら API を除去
    const sdkAnchors = /SKILL\.md|\.claude\/(?:skills|agents|commands|plugins)|Claude Code SDK|@anthropic-ai\/sdk|@modelcontextprotocol\/sdk|frontmatter|allowed-tools|argument-hint|オープンクロー/i;
    // API 側の強いシグナル (RAG/embedding/webhook/HMAC 等) の非在確認
    const apiExclusive = /RAG|embedding|vector\s*(?:DB|store)|webhook|HMAC|Idempotency-Key|IBL|connector-forge|Salesforce|prompt[- ]?caching|batch\s*API/i;
    if (sdkAnchors.test(normalized) && !apiExclusive.test(normalized)) {
      // SDK 優先、API を除去
      const idx = detected.findIndex((d) => d.domain_key === "api_integration_ai_control");
      if (idx >= 0) detected.splice(idx, 1);
    }
  }

  return detected;
}

/** ドメイン別注入行を組み立てる (buildInjectionLines から呼ばれる) */
export function buildDomainInjectionLines(detectedDomains) {
  if (!Array.isArray(detectedDomains) || detectedDomains.length === 0) return [];
  const lines = [];
  for (const dd of detectedDomains) {
    const key = typeof dd === "string" ? dd : dd.domain_key;
    const dom = SKILL_DOMAINS.find((d) => d.key === key);
    if (!dom) continue;
    lines.push(`【${dom.name_ja} ドメイン特化教典・全ロール必須遵守】以下 ${dom.injection_lines.length} 項目を汎用品質基準に上乗せして適用する:`);
    for (const l of dom.injection_lines) lines.push(l);
    if (Array.isArray(dom.reference_libraries) && dom.reference_libraries.length > 0) {
      lines.push(`【${dom.name_ja} 参考資産】${dom.reference_libraries.slice(0, 6).join(" / ")}`);
    }
    if (dom.example_skill_name) {
      lines.push(`【${dom.name_ja} 例名】推奨スキル名: ${dom.example_skill_name}`);
    }
    // japan-link 法令ブリッジ (該当業種のドメインのみ)
    if (dom.law_industry_key) {
      lines.push(
        `【${dom.name_ja} 法令連携】japan-link の recommendLaws('${dom.law_industry_key}') / recommendExtendedLaws('${dom.law_industry_key}') 経由で該当法令の条文サマリを取得し、SKILL.md の「法令根拠」節に必ず明示すること. ハードコードせずレジストリ経由で参照 (改正時の自動追従).`
      );
    }
  }
  return lines;
}

/**
 * ドメイン key → japan-link 業種キーの逆引き.
 * skill-forge-bridge が recommendLaws() 呼出前に使用する.
 */
export function domainToJapanLawIndustry(domainKey) {
  const dom = SKILL_DOMAINS.find((d) => d.key === domainKey);
  return dom?.law_industry_key || "";
}
