#!/usr/bin/env bash
# =============================================================================
# Japan → BOOST 連携バンドルの再ビルド
# -----------------------------------------------------------------------------
# japan-entry.ts と soloptilink-japan の連携3ファイル(laws/laws_extended/
# feature_recommender)を単一の自己完結 .mjs にバンドルし、ソースハッシュの
# sidecar(meta.json)を更新する。バンドル後の .mjs は外部依存ゼロ。
#
# 注: japan の lib/japan は ~/.soloptilink/skills/... へのシンボリックリンク。
#     esbuild は追従する。ハッシュは symlink 越しに実体内容を読む。
# =============================================================================
set -euo pipefail

HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
JP_LIB="$HERE/../../soloptilink-japan/lib/japan"   # symlink
ENTRY="$HERE/japan-entry.ts"
OUT="$HERE/japan-recall.bundle.mjs"
META="$HERE/japan-recall.bundle.meta.json"

ESB=""
for c in \
  "$HOME/.soloptilink/admin-dashboard-true-source/node_modules/.bin/esbuild" \
  "$(command -v esbuild 2>/dev/null || true)" \
  "$HERE/node_modules/.bin/esbuild"; do
  if [ -n "$c" ] && [ -x "$c" ]; then ESB="$c"; break; fi
done
if [ -z "$ESB" ]; then echo "ERROR: esbuild が見つかりません。" >&2; exit 2; fi

# --- バンドル生成 ---
"$ESB" "$ENTRY" \
  --bundle --platform=node --target=node18 --format=esm \
  --outfile="$OUT" --log-level=warning

# --- ソースハッシュ封緘(entry + 連携3ファイル) ---
SRC_FILES=(
  "$ENTRY"
  "$JP_LIB/laws.ts"
  "$JP_LIB/laws_extended.ts"
  "$JP_LIB/feature_recommender.ts"
)
COMBINED=""
for f in "${SRC_FILES[@]}"; do
  if [ -f "$f" ]; then
    COMBINED+="$(shasum -a 256 "$f" | awk '{print $1}')  $(basename "$f")
"
  fi
done
SRC_HASH="$(printf '%s' "$COMBINED" | shasum -a 256 | awk '{print $1}')"
BUNDLE_HASH="$(shasum -a 256 "$OUT" | awk '{print $1}')"

cat > "$META" <<JSON
{
  "schema": "japan-recall-bundle/1",
  "source_hash": "$SRC_HASH",
  "bundle_hash": "$BUNDLE_HASH",
  "source_files": ["japan-entry.ts", "laws.ts", "laws_extended.ts", "feature_recommender.ts"],
  "note": "source_hash は japan-entry.ts + 連携3ファイルの複合ハッシュ。bridge が実行時に再計算して陳腐化を検知する。"
}
JSON

echo "OK: japan bundle 再生成完了"
echo "  bundle: $OUT"
echo "  source_hash: $SRC_HASH"
