#!/usr/bin/env node
/**
 * Japan → BOOST 連携の検証ゲート (born-passing)
 * ============================================================================
 * 実行: node verify-japan-bridge.mjs   終了コード: 全PASS=0 / 1つでもFAIL=1
 *
 * 検証する性質:
 *   V1 バンドル/meta/bridge が同梱されている
 *   V2 bundle --selftest (業種→法令+機能 / 未知業種→基本3法 / 空→no-op) が PASS
 *   V3 bridge: 業種あり → has_data=true + 法令(インボイス等)注入 + 成果物生成
 *   V4 bridge: 未知業種 → 基本3法は注入される(default safe)
 *   V5 bridge: 業種・依頼文なし → no-op かつ exit 0 (本流を止めない)
 *   V6 バンドルのソースハッシュが meta と一致 (陳腐化していない)
 */

import * as fs from "node:fs";
import * as path from "node:path";
import * as os from "node:os";
import * as crypto from "node:crypto";
import { fileURLToPath } from "node:url";
import { spawnSync } from "node:child_process";

const HERE = path.dirname(fileURLToPath(import.meta.url));
const BUNDLE = path.join(HERE, "japan-recall.bundle.mjs");
const META = path.join(HERE, "japan-recall.bundle.meta.json");
const BRIDGE = path.join(HERE, "japan-bridge.mjs");
const JP_LIB = path.join(HERE, "..", "..", "soloptilink-japan", "lib", "japan");

const results = [];
function check(id, name, fn) {
  try {
    const r = fn();
    results.push({ id, name, pass: r === true, detail: r === true ? "" : String(r) });
  } catch (e) {
    results.push({ id, name, pass: false, detail: "EXC: " + e.message });
  }
}
function runNode(args, env) {
  return spawnSync(process.execPath, args, { env: { ...process.env, ...env }, encoding: "utf-8", timeout: 25000 });
}
function lastJson(stdout) {
  const line = (stdout || "").trim().split("\n").filter(Boolean).pop();
  return line ? JSON.parse(line) : null;
}

check("V1", "バンドル/meta/bridge が同梱", () => {
  if (!fs.existsSync(BUNDLE)) return "bundle なし";
  if (!fs.existsSync(META)) return "meta なし";
  if (!fs.existsSync(BRIDGE)) return "bridge なし";
  return true;
});

check("V2", "bundle --selftest PASS", () => {
  const r = runNode([BUNDLE, "--selftest"]);
  const j = lastJson(r.stdout);
  if (r.status !== 0) return "exit!=0: " + (j?.failures?.join("; ") || r.stderr);
  if (!j || j.ok !== true) return "failures: " + (j?.failures?.join("; ") || "?");
  return true;
});

check("V3", "bridge: 業種あり → 法令注入+成果物", () => {
  const ws = fs.mkdtempSync(path.join(os.tmpdir(), "jp-verify-ws-"));
  try {
    const r = runNode([BRIDGE, "--industry", "construction", "--task", "建設業の原価管理", "--workspace", ws]);
    const j = lastJson(r.stdout);
    if (!j?.has_data) return "has_data=false";
    const inj = (j.injection_lines_for_agents || []).join("\n");
    if (!/インボイス/.test(inj)) return "インボイス制度が注入されない";
    if (!/建設業法/.test(inj)) return "建設業法が注入されない";
    if (!fs.existsSync(path.join(ws, "agent-evidence", "japan-recall.md"))) return "成果物が無い";
    return true;
  } finally {
    fs.rmSync(ws, { recursive: true, force: true });
  }
});

check("V4", "bridge: 未知業種 → 基本3法は注入(default safe)", () => {
  const r = runNode([BRIDGE, "--industry", "staffing-agency"]);
  const j = lastJson(r.stdout);
  if (!j?.has_data) return "has_data=false";
  const inj = (j.injection_lines_for_agents || []).join("\n");
  if (!/インボイス制度/.test(inj) || !/電子帳簿保存法/.test(inj) || !/個人情報保護法/.test(inj))
    return "基本3法が揃わない";
  return true;
});

check("V5", "bridge: 業種・依頼文なし → no-op かつ exit 0", () => {
  const r = runNode([BRIDGE], { SOLOPTILINK_DETECTED_INDUSTRY: "" });
  const j = lastJson(r.stdout);
  if (j?.has_data !== false) return "has_data が false でない";
  return r.status === 0 ? true : "exit=" + r.status;
});

check("V6", "バンドルが陳腐化していない (source_hash 一致)", () => {
  if (!fs.existsSync(META)) return "meta なし";
  const meta = JSON.parse(fs.readFileSync(META, "utf-8"));
  const files = [
    path.join(HERE, "japan-entry.ts"),
    path.join(JP_LIB, "laws.ts"),
    path.join(JP_LIB, "laws_extended.ts"),
    path.join(JP_LIB, "feature_recommender.ts"),
  ];
  let combined = "";
  for (const f of files) {
    if (!fs.existsSync(f)) continue;
    combined += crypto.createHash("sha256").update(fs.readFileSync(f)).digest("hex") + "  " + path.basename(f) + "\n";
  }
  const cur = crypto.createHash("sha256").update(combined).digest("hex");
  return meta.source_hash === cur ? true : "陳腐化: build-bundle.sh 再実行が必要";
});

const passed = results.filter((r) => r.pass).length;
const failed = results.length - passed;
console.log("=== Japan → BOOST 連携 検証ゲート ===");
for (const r of results) console.log(`${r.pass ? "✓" : "✗"} ${r.id} ${r.name}${r.detail ? "  — " + r.detail : ""}`);
console.log("---");
console.log(`PASS=${passed} FAIL=${failed} (計 ${results.length})`);
process.exit(failed === 0 ? 0 : 1);
