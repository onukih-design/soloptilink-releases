// ../../../.soloptilink/skills/soloptilink-japan/lib/japan/laws_extended.ts
function recommendExtendedLaws(industry) {
  switch (industry) {
    case "construction":
      return [
        "\u52B4\u50CD\u5B89\u5168\u885B\u751F\u6CD5",
        "\u52B4\u50CD\u5B89\u5168\u885B\u751F\u898F\u5247\u7B2C88\u6761",
        // H2: 機械等設置届 (足場高さ10m以上60日以上/型枠支保工) と 建設工事計画届 (高さ31m超建物/掘削深10m以上)
        "\u5EC3\u68C4\u7269\u51E6\u7406\u6CD5",
        "\u5927\u6C17\u6C5A\u67D3\u9632\u6B62\u6CD5",
        // 石綿飛散防止 (アスベスト事前調査結果報告制度)
        "\u52B4\u50CD\u8005\u6D3E\u9063\u6CD5",
        // 建設業務労働者派遣事業は原則禁止 (適正な請負区分)
        "\u96FB\u6C17\u4E8B\u696D\u6CD5",
        "\u6C34\u9053\u6CD5",
        "\u30AC\u30B9\u4E8B\u696D\u6CD5",
        // 建設現場のガス管接続
        "\u9053\u8DEF\u6CD5"
        // 道路占用許可 (仮設・足場が公道に張り出す時)
      ];
    case "manufacturing":
      return ["PL\u6CD5", "\u52B4\u50CD\u5B89\u5168\u885B\u751F\u6CD5"];
    case "food_service":
      return ["\u98DF\u54C1\u885B\u751F\u6CD5", "\u98DF\u54C1\u8868\u793A\u6CD5", "PL\u6CD5"];
    case "healthcare":
      return ["\u85AC\u6A5F\u6CD5", "\u52B4\u50CD\u5B89\u5168\u885B\u751F\u6CD5"];
    case "beauty":
      return ["\u85AC\u6A5F\u6CD5", "\u666F\u54C1\u8868\u793A\u6CD5"];
    case "real_estate":
      return ["\u5B85\u5730\u5EFA\u7269\u53D6\u5F15\u696D\u6CD5"];
    case "hotel":
    case "bridal":
      return ["\u65C5\u9928\u696D\u6CD5", "\u98DF\u54C1\u885B\u751F\u6CD5"];
    case "childcare":
    case "education":
      return ["\u5150\u7AE5\u798F\u7949\u6CD5"];
    case "retail":
      return ["\u666F\u54C1\u8868\u793A\u6CD5", "\u7279\u5B9A\u5546\u53D6\u5F15\u6CD5", "PL\u6CD5"];
    case "advertising":
      return ["\u666F\u54C1\u8868\u793A\u6CD5", "\u85AC\u6A5F\u6CD5"];
    case "logistics":
    case "transport":
      return ["\u52B4\u50CD\u5B89\u5168\u885B\u751F\u6CD5"];
    case "it":
      return ["\u52B4\u50CD\u8005\u6D3E\u9063\u6CD5"];
    default:
      return [];
  }
}

// ../../../.soloptilink/skills/soloptilink-japan/lib/japan/laws.ts
var INDUSTRY_KEY_ALIASES = {
  // ---------------------------------------------------------------------------
  // (a) コア法 (laws.ts recommendLaws) の分岐へ寄せるもの
  // ---------------------------------------------------------------------------
  // 小売POS: 景品表示法 (景品額の上限)・特定商取引法第11条の8項目・製造物責任法第5条の
  //   3年/10年・薬機法第36条の8/9の販売区分が、業種辞書の regulations の記載値と
  //   一致することを確認済 (2026-08-11)
  "retail-pos": "retail",
  // 飲食: 食品衛生法の営業許可業種と食中毒24時間届出・食品表示法のアレルゲン義務8品目/
  //   推奨20品目/栄養5項目が実装に実在し、業種辞書の要求と一致することを確認済
  "food-service": "food_service",
  // 印刷: 業種辞書が category=manufacturing を宣言。かつ下請法の条文・数値
  //   (第2条の資本金区分・第2条の2の60日・第3条の三条書面・第4条の禁止行為) が
  //   実装 API と逐語で対応することを確認済
  printing: "manufacturing",
  // 産業廃棄物処理: 廃棄物処理法 (S45法律137) の産廃20種・特別管理の性状判定・
  //   12条の3のマニフェスト・14条の許可5年更新が実装に実在することを確認済
  "industrial-waste": "industrial_waste",
  // ---------------------------------------------------------------------------
  // (b) 拡張法令 (laws_extended.ts recommendExtendedLaws) の分岐へ寄せるもの
  //     ★2026-08-14 追加。
  //
  //     【直した欠陥 — 直す前の実測】
  //       拡張法令の分岐は 15 件あるのに、114 業種を全通しで呼んで実際に発火したのは
  //       6 件だけだった (construction / manufacturing / food_service / healthcare /
  //       retail / bridal)。残る 9 件 (beauty / real_estate / hotel / childcare /
  //       education / advertising / logistics / transport / it) は、その分岐名に
  //       当たる業種名が本表に無いため **一度も発火しない死んだ分岐** だった。
  //       業種辞書には美容室も不動産も宿泊も保育も実在するのに、その業種で
  //       いちばん外せない業法 (薬機法・宅建業法・旅館業法・児童福祉法) が
  //       生成物の「該当法令」から丸ごと落ちていた。
  //
  //     【足す条件は (a) と同じ。推測で足さない】
  //       返る法令が業種辞書の regulations の記載と一致するか、返る実体の実装が
  //       その業種を名指ししていることを 1 件ずつ確認した。確認できない業種は
  //       足していない (足すと無関係な法令が顧客の画面に「該当法令」として出る)。
  //       ★本表に足しても KNOWN_INDUSTRY_KEYS には入らないため、コア法
  //         (recommendLaws) と適格簡易請求書 (canIssueSimplified) の判定は
  //         いずれも従来どおり (基本3法 / false) で変わらない。変わるのは
  //         拡張法令が返るようになる点と、その結果 fallsBackToBaseLaws が
  //         「基本3法だけ」ではなくなる点だけである。
  //
  // 美容室: 辞書の regulations に「医薬品医療機器等法 (薬機法)」「不当景品類及び
  //   不当表示防止法 (景品表示法)」を明記。分岐が返す2法と逐語で一致する。
  //   ★beauty-clinic (美容クリニック) は足さない。辞書の regulations は医療法
  //     (医療広告ガイドライン)・医師法であり、景品表示法の記載が無い。医療機関の
  //     広告規制は医療法側であって、機械的に寄せると誤った規制を提示する。
  "beauty-salon": "beauty",
  // 不動産: 辞書の regulations 筆頭が「宅地建物取引業法」。分岐が返す法令と一致する。
  //   ★real-estate-portal / property-management も同法を掲げており同様に寄せられるが、
  //     本回は死んだ分岐の解消に必要な 1 件ずつに留めた (未追加であって不適格ではない)。
  "real-estate": "real_estate",
  // 宿泊 (ホテル・旅館): 辞書の regulations に「旅館業法」「食品衛生法」を明記し、
  //   分岐が返す2法と一致する。「住宅宿泊事業法 (民泊新法)」も掲げており、
  //   実装側の RyokanGyo.isMinpaku (年間営業日数 180 日) と対応する。
  "hotel-ryokan": "hotel",
  // 保育所: 辞書の regulations 筆頭が「児童福祉法」。分岐が返す法令と一致する。
  "nursery-school": "childcare",
  // 学童保育 (放課後児童健全育成事業): 辞書の regulations 筆頭が
  //   「児童福祉法(放課後児童健全育成事業)」、category も education-welfare。
  //   ★childcare と education は同一の分岐 (どちらも児童福祉法だけを返す) であり、
  //     どちらの札に寄せても返る法令は変わらない。両業種とも辞書に児童福祉法がある。
  //   ★学校 (school)・学習塾 (cram-school)・語学学校 (language-school) は足さない。
  //     いずれも辞書の regulations に児童福祉法が無く (学校教育法・特定商取引法)、
  //     寄せると学校に児童福祉法を「該当法令」として提示することになる。
  "after-school-care": "education",
  // SNSマーケティング代理店: 景品表示法は辞書の regulations に「景品表示法 (ステマ規制)
  //   第5条第3号・令和5年告示第19号」として明記されており一致する。
  //   ★薬機法は辞書の regulations に記載が無い。寄せる根拠は、薬機法第66条 (誇大広告等)
  //     が「何人も」を名宛人とし広告を作成・依頼する事業者を直接規制すること、および
  //     分岐が返す実体 Yakkiho.forbiddenMedicalClaims() が広告表現の禁止例そのもので
  //     あることによる。★辞書側に記載が無い点は隠さずここに残す (owner 再判断用)。
  "sns-marketing-agency": "advertising",
  // 物流 (運送): 辞書の regulations は貨物自動車運送事業法・改善基準告示等であり、
  //   労働安全衛生法の記載は無い。寄せる根拠は、分岐が返す実体
  //   AnzenEisei.safetyManagerRequiredIndustries() が「運輸業」を安全管理者選任業種
  //   として明記していること (安衛法施行令第2条)。産業医・ストレスチェックの
  //   50人以上要件は業種を問わず全事業場に及ぶため、誤った義務の提示にはならない。
  "logistics-trucking": "logistics",
  // 運送 (トラック運送): 上と同じ根拠。
  //   ★moving-company / taxi-operator は category=transport を自ら宣言しており
  //     同様に寄せられるが、本回は 1 件ずつに留めた (未追加であって不適格ではない)。
  "trucking-transport": "transport",
  // IT (プロジェクト管理・SES): 辞書の regulations に「労働者派遣事業の適正な運営の
  //   確保等に関する法律(労働者派遣法)」を明記し、その key_articles の
  //   「派遣期間制限 … 原則3年 (事業所単位・個人単位)」が実装の
  //   HakenHou.individualMaxYears() / workplaceMaxYears() = 3 と数値まで一致する。
  "project-management": "it"
};
var KNOWN_INDUSTRY_KEYS = /* @__PURE__ */ new Set([
  "construction",
  "manufacturing",
  "healthcare",
  "professional",
  "retail",
  "food_service",
  "finance",
  "industrial_waste"
]);
function normalizeIndustryKey(industry) {
  if (!industry) return industry;
  const raw = industry.trim();
  const alias = INDUSTRY_KEY_ALIASES[raw.toLowerCase()];
  if (alias) return alias;
  const snake = raw.toLowerCase().replace(/-/g, "_");
  if (KNOWN_INDUSTRY_KEYS.has(snake)) return snake;
  if (recommendExtendedLaws(snake).length > 0) return snake;
  return raw;
}
function recommendLaws(industry) {
  const base = ["\u30A4\u30F3\u30DC\u30A4\u30B9\u5236\u5EA6", "\u96FB\u5B50\u5E33\u7C3F\u4FDD\u5B58\u6CD5", "\u500B\u4EBA\u60C5\u5831\u4FDD\u8B77\u6CD5"];
  switch (normalizeIndustryKey(industry)) {
    case "construction":
      return [
        ...base,
        "\u5EFA\u7BC9\u58EB\u6CD5",
        "\u5EFA\u7BC9\u57FA\u6E96\u6CD5",
        "\u5EFA\u8A2D\u696D\u6CD5",
        "\u4E0B\u8ACB\u6CD5",
        "\u52B4\u50CD\u57FA\u6E96\u6CD5",
        "\u5EFA\u7BC9\u7269\u7701\u30A8\u30CD\u6CD5",
        "\u90FD\u5E02\u8A08\u753B\u6CD5",
        "\u8010\u9707\u6539\u4FEE\u4FC3\u9032\u6CD5",
        "\u30D0\u30EA\u30A2\u30D5\u30EA\u30FC\u6CD5",
        "\u5EFA\u8A2D\u30EA\u30B5\u30A4\u30AF\u30EB\u6CD5",
        "\u4F4F\u5B85\u54C1\u8CEA\u78BA\u4FDD\u4FC3\u9032\u6CD5",
        "\u6D88\u9632\u6CD5"
      ];
    case "manufacturing":
      return [...base, "\u4E0B\u8ACB\u6CD5", "PL\u6CD5", "\u52B4\u50CD\u57FA\u6E96\u6CD5"];
    case "healthcare":
      return [...base, "\u30DE\u30A4\u30CA\u30F3\u30D0\u30FC\u6CD5", "\u533B\u7642\u6CD5", "\u4ECB\u8B77\u4FDD\u967A\u6CD5"];
    case "professional":
      return [...base, "\u30DE\u30A4\u30CA\u30F3\u30D0\u30FC\u6CD5", "\u58EB\u696D\u6CD5", "\u52B4\u50CD\u57FA\u6E96\u6CD5"];
    case "retail":
      return [...base, "\u666F\u54C1\u8868\u793A\u6CD5", "\u7279\u5B9A\u5546\u53D6\u5F15\u6CD5"];
    case "food_service":
      return [...base, "\u98DF\u54C1\u885B\u751F\u6CD5", "\u666F\u54C1\u8868\u793A\u6CD5"];
    case "finance":
      return [...base, "\u91D1\u878D\u5546\u54C1\u53D6\u5F15\u6CD5", "\u8CB8\u91D1\u696D\u6CD5", "\u8CC7\u91D1\u6C7A\u6E08\u6CD5"];
    // ★2026-08-11 追加 (全結線計画 第3群)。lib/japan/waste.ts が廃棄物処理法
    //   (S45法律137) の産廃20種・特別管理の性状判定・12条の3のマニフェスト90日/180日・
    //   14条の許可5年更新を実装しており、業種辞書 industrial-waste の regulations と
    //   直接対応することを確認したうえで追加した。
    //   ★確認していない法令 (建設リサイクル法・フロン排出抑制法) はここに書かない。
    //     解体工事や第一種特定製品を扱うかは事業者ごとに異なり、一律に「該当法令」として
    //     出すと誤った義務を提示することになる。
    case "industrial_waste":
      return [...base, "\u5EC3\u68C4\u7269\u51E6\u7406\u6CD5"];
    default:
      return base;
  }
}

// ../../../.soloptilink/skills/soloptilink-japan/lib/japan/feature_recommender.ts
var INDUSTRY_FEATURE_BUNDLE = {
  construction: [
    {
      feature: "\u6982\u7B97\u898B\u7A4D\u30A8\u30F3\u30B8\u30F3 (\u576A\u5358\u4FA1\u2192\u6570\u91CF\u62FE\u3044\u2192\u8A73\u7D30)",
      rationale: "\u5EFA\u8A2D\u696D\u306E80%\u304C\u521D\u56DE\u554F\u3044\u5408\u308F\u305B\u6642\u306B\u6982\u7B97\u898B\u7A4D\u3092\u8981\u6C42 (\u696D\u7A2E\u30D2\u30A2\u30EA\u30F3\u30B0\u96C6\u8A08)",
      priority: "P0",
      required_modules: ["estimates", "architecture", "regional_laws"],
      required_dictionaries: ["construction"],
      required_templates: ["Estimate", "Invoice"],
      estimated_quality_lift: 8
    },
    {
      feature: "\u5EFA\u8A2D\u696D\u6CD5\u6E96\u62E0 \u53D7\u6CE8\u53F0\u5E33",
      rationale: "\u4E0B\u8ACB\u6CD5+\u5EFA\u8A2D\u696D\u6CD5 19\u6761\u306E3 \u306E\u7F70\u5247\u56DE\u907F\u304C\u6700\u91CD\u8981",
      priority: "P0",
      required_modules: ["laws", "save_guarantee"],
      required_dictionaries: ["construction"],
      required_templates: ["PurchaseOrder", "DeliveryNote"],
      estimated_quality_lift: 6
    }
  ],
  healthcare: [
    {
      feature: "\u8A3A\u7642\u5831\u916C\u8A08\u7B97 + UKE\u30EC\u30BB\u30D7\u30C8\u96FB\u7B97\u51E6\u7406",
      rationale: "\u533B\u7642\u6A5F\u95A2\u3067\u306F\u6708\u521D\u306E\u30EC\u30BB\u30D7\u30C8\u63D0\u51FA\u304C\u6CD5\u5B9A\u7FA9\u52D9 (R6\u6539\u5B9A\u5BFE\u5FDC\u5FC5\u9808)",
      priority: "P0",
      required_modules: ["medical", "law_tracker"],
      required_dictionaries: ["healthcare"],
      required_templates: ["Invoice", "Receipt"],
      estimated_quality_lift: 10
    },
    {
      feature: "HPKI \u96FB\u5B50\u7F72\u540D (3\u77012\u30AC\u30A4\u30C9\u30E9\u30A4\u30F3\u6E96\u62E0)",
      rationale: "\u96FB\u5B50\u30AB\u30EB\u30C6/\u51E6\u65B9\u7B8B\u306E\u672C\u4EBA\u8A8D\u8A3C\u3067\u5FC5\u9808",
      priority: "P1",
      required_modules: ["medical", "eseal"],
      required_dictionaries: ["healthcare"],
      required_templates: [],
      estimated_quality_lift: 5
    }
  ],
  longterm_care: [
    {
      feature: "\u4ECB\u8B77\u5831\u916C\u8A08\u7B97 + LIFE \u79D1\u5B66\u7684\u4ECB\u8B77\u60C5\u5831\u30A2\u30C3\u30D7\u30ED\u30FC\u30C9",
      rationale: "R6\u6539\u5B9A\u3067\u51E6\u9047\u6539\u5584\u52A0\u7B97\u304C\u4E00\u672C\u5316\u3001LIFE\u63D0\u51FA\u306F\u52A0\u7B97\u8981\u4EF6",
      priority: "P0",
      required_modules: ["longterm_care"],
      required_dictionaries: ["healthcare"],
      required_templates: ["Invoice"],
      estimated_quality_lift: 9
    },
    {
      feature: "\u30B1\u30A2\u30D7\u30E9\u30F31\u301C7\u8868 \u81EA\u52D5\u751F\u6210",
      rationale: "\u5C45\u5B85\u4ECB\u8B77\u652F\u63F4\u4E8B\u696D\u6240\u306E\u5FC5\u9808\u5E33\u7968",
      priority: "P0",
      required_modules: ["longterm_care"],
      required_dictionaries: ["healthcare"],
      required_templates: ["Report"],
      estimated_quality_lift: 7
    }
  ],
  finance: [
    {
      feature: "\u5168\u9280\u30D5\u30A9\u30FC\u30DE\u30C3\u30C8 120\u30D0\u30A4\u30C8\u56FA\u5B9A\u9577\u632F\u8FBC\u30D5\u30A1\u30A4\u30EB\u751F\u6210",
      rationale: "\u91D1\u878D\u6A5F\u95A2\u9023\u643A\u306E\u4E8B\u5B9F\u4E0A\u306E\u30C7\u30D5\u30A1\u30AF\u30C8",
      priority: "P0",
      required_modules: ["finance"],
      required_dictionaries: ["finance"],
      required_templates: [],
      estimated_quality_lift: 8
    },
    {
      feature: "\u91D1\u5546\u6CD5\u9069\u5408\u6027\u539F\u5247 \u81EA\u52D5\u30C1\u30A7\u30C3\u30AF (75\u6B73/\u6295\u8CC7\u7D4C\u9A13/\u7D14\u8CC7\u7523)",
      rationale: "\u91D1\u878D\u5546\u54C1\u53D6\u5F15\u696D\u306E\u8AAC\u660E\u8CAC\u4EFB\u3067\u5FC5\u9808",
      priority: "P1",
      required_modules: ["finance", "laws_extended"],
      required_dictionaries: ["finance"],
      required_templates: ["Contract"],
      estimated_quality_lift: 6
    }
  ],
  retail: [
    {
      feature: "\u666F\u8868\u6CD5 + \u7279\u5546\u6CD5 \u30DE\u30FC\u30B1\u30B3\u30D4\u30FC\u691C\u8A3C",
      rationale: "EC/\u5C0F\u58F2\u306E\u8CA9\u4FC3\u6587\u8A00\u306F\u666F\u8868\u6CD5\u7B2C5\u6761 (\u512A\u826F\u8AA4\u8A8D/\u6709\u5229\u8AA4\u8A8D) \u9055\u53CD\u30EA\u30B9\u30AF",
      priority: "P0",
      required_modules: ["marketing_compliance"],
      required_dictionaries: ["retail"],
      required_templates: [],
      estimated_quality_lift: 7
    },
    {
      feature: "RFM\u5206\u6790 + LTV\u4E88\u6E2C",
      rationale: "\u9867\u5BA2\u30BB\u30B0\u30E1\u30F3\u30C8\u5225\u306E\u6253\u3061\u624B\u306E\u6839\u62E0\u4ED8\u3051",
      priority: "P1",
      required_modules: ["customer_journey"],
      required_dictionaries: ["retail"],
      required_templates: ["Report"],
      estimated_quality_lift: 5
    }
  ],
  it: [
    {
      feature: "SES\u5951\u7D04\u66F8 + 36\u5354\u5B9A \u81EA\u52D5\u30C1\u30A7\u30C3\u30AF",
      rationale: "\u52B4\u57FA\u6CD5+\u6D3E\u9063\u6CD5\u306E\u30EA\u30B9\u30AF\u304C\u96C6\u4E2D\u3059\u308B\u696D\u7A2E",
      priority: "P1",
      required_modules: ["laws", "hr_payroll"],
      required_dictionaries: ["it"],
      required_templates: ["Contract"],
      estimated_quality_lift: 6
    }
  ]
};
var COMMON_BACKBONE = [
  {
    feature: "save_guarantee.ts \u306B\u3088\u308B\u5168 CRUD \u9632\u5FA1\u5C64",
    rationale: "Phase 6 \u30D0\u30B0\u4E88\u9632DNA: 23502/UNIQUE/FK/\u697D\u89B3\u30ED\u30C3\u30AF \u591A\u767A\u9632\u6B62",
    priority: "P0",
    required_modules: ["save_guarantee", "bug_prevention"],
    required_dictionaries: [],
    required_templates: [],
    estimated_quality_lift: 8
  },
  {
    feature: "\u30ED\u30FC\u30EB\u8A2D\u8A08 (admin/user \u5C0F\u6587\u5B57\u7D71\u4E00) + RBAC",
    rationale: "\u904E\u53BB\u4E8B\u4F8B: \u30ED\u30FC\u30EB\u5927\u6587\u5B57\u6DF7\u5165\u3067 SSO/RBAC \u8AA4\u52D5\u4F5C\u591A\u767A",
    priority: "P0",
    required_modules: [],
    required_dictionaries: [],
    required_templates: [],
    estimated_quality_lift: 5
  },
  {
    feature: "\u76E3\u67FB\u30ED\u30B0 + WORM\u4FDD\u7BA1",
    rationale: "\u500B\u60C5\u6CD5\u7B2C26\u6761 R4\u6539\u6B63\u5BFE\u5FDC + J-SOX ITGC",
    priority: "P1",
    required_modules: ["security_audit", "incident"],
    required_dictionaries: [],
    required_templates: [],
    estimated_quality_lift: 6
  }
];
function recommendFeatures(inference, coverage = [], usage = []) {
  const out = [];
  if (inference.industry) {
    const bundle = INDUSTRY_FEATURE_BUNDLE[inference.industry];
    if (bundle) out.push(...bundle);
  }
  out.push(...COMMON_BACKBONE);
  const lowQualityDomain = coverage.find(
    (c) => c.domain === inference.industry && (c.avg_quality_score ?? 100) < 80
  );
  if (lowQualityDomain) {
    out.push({
      feature: `${inference.industry} \u696D\u7A2E\u306E\u54C1\u8CEA\u30D9\u30F3\u30C1\u30DE\u30FC\u30AF\u5F37\u5316 (\u73FE\u72B6 ${lowQualityDomain.avg_quality_score})`,
      rationale: "\u904E\u53BB\u30BB\u30C3\u30B7\u30E7\u30F3\u306E\u5E73\u5747\u54C1\u8CEA\u30B9\u30B3\u30A2\u304C\u95BE\u5024\u672A\u6E80",
      priority: "P0",
      required_modules: ["learning_analytics", "usage_insights"],
      required_dictionaries: inference.industry ? [inference.industry] : [],
      required_templates: [],
      estimated_quality_lift: 10
    });
  }
  if (usage.some((u) => u.module === "marketing_compliance" && u.trend_30d === "rising")) {
    out.push({
      feature: "marketing_compliance.ts \u306B\u3088\u308B\u666F\u8868\u6CD5\u30D0\u30CA\u30FC\u691C\u8A3C",
      rationale: "\u76F4\u8FD130\u65E5\u3067\u5229\u7528\u7387\u4E0A\u6607\u4E2D\u306E\u4EBA\u6C17\u30E2\u30B8\u30E5\u30FC\u30EB",
      priority: "P1",
      required_modules: ["marketing_compliance"],
      required_dictionaries: [],
      required_templates: [],
      estimated_quality_lift: 4
    });
  }
  return dedupePreservingOrder(out);
}
function dedupePreservingOrder(arr) {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const r of arr) {
    if (seen.has(r.feature)) continue;
    seen.add(r.feature);
    out.push(r);
  }
  return out;
}
function selectTopRecommendations(recs, options = {}) {
  const { maxP0 = 5, maxP1 = 5, maxP2 = 3 } = options;
  const p0 = recs.filter((r) => r.priority === "P0").slice(0, maxP0);
  const p1 = recs.filter((r) => r.priority === "P1").slice(0, maxP1);
  const p2 = recs.filter((r) => r.priority === "P2").slice(0, maxP2);
  return [...p0, ...p1, ...p2];
}

// ../../../.claude/skills/soloptilink-boost/japan-link/japan-entry.ts
function emit(obj) {
  process.stdout.write(JSON.stringify(obj) + "\n");
}
function buildJapanInjection(industry, task, roles) {
  if (!industry && !task) {
    return {
      has_data: false,
      inference_block_markdown: "\u3010Japan \u81EA\u52D5\u9069\u7528\u3011\u696D\u7A2E\u30FB\u4F9D\u983C\u6587\u304C\u7121\u3044\u305F\u3081\u9069\u7528\u306A\u3057\u3002",
      injection_lines_for_agents: []
    };
  }
  const baseLaws = recommendLaws(industry || "");
  const extLaws = recommendExtendedLaws(normalizeIndustryKey(industry || ""));
  const laws = Array.from(/* @__PURE__ */ new Set([...baseLaws, ...extLaws]));
  const inference = {
    industry: industry || void 0,
    roles: roles.length ? roles : void 0,
    scope: "new"
  };
  let recs = recommendFeatures(inference);
  try {
    recs = selectTopRecommendations(recs, 6) ?? recs;
  } catch {
  }
  const lines = [];
  lines.push(
    `\u672C\u30B7\u30B9\u30C6\u30E0\u306F\u65E5\u672C\u306E\u4EE5\u4E0B\u306E\u6CD5\u4EE4\u306B\u6E96\u62E0\u3057\u3066\u8A2D\u8A08\u30FB\u5B9F\u88C5\u3059\u308B\u3053\u3068: ${laws.join(" / ")}\u3002\u7279\u306B\u30A4\u30F3\u30DC\u30A4\u30B9\u5236\u5EA6(\u9069\u683C\u8ACB\u6C42\u66F8\u767A\u884C\u4E8B\u696D\u8005\u767B\u9332\u756A\u53F7\u306E\u4FDD\u6301\u30FB\u7A0E\u7387\u5225\u306E\u7AEF\u6570\u51E6\u7406)\u3001\u96FB\u5B50\u5E33\u7C3F\u4FDD\u5B58\u6CD5(\u96FB\u5B50\u53D6\u5F15\u30C7\u30FC\u30BF\u306E\u4FDD\u5B58\u8981\u4EF6\u30FB\u30BF\u30A4\u30E0\u30B9\u30BF\u30F3\u30D7)\u3001\u500B\u4EBA\u60C5\u5831\u4FDD\u8B77\u6CD5(\u5B89\u5168\u7BA1\u7406\u63AA\u7F6E\u30FB\u5229\u7528\u76EE\u7684\u660E\u793A)\u306F\u5E33\u7968\u30FBDB\u8A2D\u8A08\u306B\u53CD\u6620\u3059\u308B\u3053\u3068\u3002`
  );
  const topFeatures = recs.slice(0, 4);
  for (const r of topFeatures) {
    const tmpl = r.required_templates?.length ? ` / \u5FC5\u8981\u5E33\u7968=${r.required_templates.join("\u30FB")}` : "";
    lines.push(
      `\u512A\u5148\u5B9F\u88C5\u6A5F\u80FD\u300E${r.feature}\u300F(\u512A\u5148\u5EA6${r.priority}): ${r.rationale}${tmpl}\u3002`
    );
  }
  const allTemplates = Array.from(
    new Set(recs.flatMap((r) => r.required_templates ?? []))
  ).slice(0, 8);
  if (allTemplates.length > 0) {
    lines.push(
      `\u65E5\u672C\u306E\u696D\u52D9\u3067\u5FC5\u8981\u306A\u5E33\u7968/\u69D8\u5F0F\u3092\u51FA\u529B\u3067\u304D\u308B\u3088\u3046\u306B\u3059\u308B\u3053\u3068: ${allTemplates.join(" / ")}\u3002`
    );
  }
  const block = [];
  block.push("\u3010Japan \u81EA\u52D5\u9069\u7528\u3011\u65E5\u672C\u6CD5\u4EE4\u30FB\u696D\u7A2E\u77E5\u8B58\u30EC\u30A4\u30E4\u30FC");
  if (industry) block.push(`- \u696D\u7A2E: ${industry}`);
  block.push(`- \u9069\u7528\u6CD5\u4EE4: ${laws.join(" / ")}`);
  if (topFeatures.length > 0)
    block.push(`- \u512A\u5148\u6A5F\u80FD: ${topFeatures.map((r) => r.feature).join(" / ")}`);
  if (allTemplates.length > 0) block.push(`- \u5FC5\u8981\u5E33\u7968: ${allTemplates.join(" / ")}`);
  return {
    has_data: true,
    inference_block_markdown: block.join("\n"),
    injection_lines_for_agents: lines
  };
}
function runRecall() {
  const industry = (process.env.JP_INDUSTRY ?? "").trim();
  const task = (process.env.JP_TASK ?? "").trim();
  const roles = (process.env.JP_ROLES ?? "").split(",").map((s) => s.trim()).filter(Boolean);
  const out = buildJapanInjection(industry, task, roles);
  emit({ ok: true, mode: "recall", ...out });
}
function runSelftest() {
  const failures = [];
  try {
    const pos = buildJapanInjection("construction", "\u5EFA\u8A2D\u696D\u306E\u539F\u4FA1\u7BA1\u7406\u30B7\u30B9\u30C6\u30E0", []);
    if (!pos.has_data) failures.push("\u5EFA\u8A2D\u696D\u3067 has_data=false");
    const joined = pos.injection_lines_for_agents.join("\n");
    if (!/建設業法/.test(joined)) failures.push("\u5EFA\u8A2D\u696D\u6CD5\u304C\u6CE8\u5165\u3055\u308C\u306A\u3044");
    if (!/インボイス/.test(joined)) failures.push("\u30A4\u30F3\u30DC\u30A4\u30B9\u5236\u5EA6\u304C\u6CE8\u5165\u3055\u308C\u306A\u3044");
    const reachCases = [
      ["real-estate", "\u5B85\u5730\u5EFA\u7269\u53D6\u5F15\u696D\u6CD5"],
      ["hotel-ryokan", "\u65C5\u9928\u696D\u6CD5"],
      ["nursery-school", "\u5150\u7AE5\u798F\u7949\u6CD5"],
      ["after-school-care", "\u5150\u7AE5\u798F\u7949\u6CD5"],
      ["beauty-salon", "\u85AC\u6A5F\u6CD5"],
      ["sns-marketing-agency", "\u666F\u54C1\u8868\u793A\u6CD5"],
      ["logistics-trucking", "\u52B4\u50CD\u5B89\u5168\u885B\u751F\u6CD5"],
      ["trucking-transport", "\u52B4\u50CD\u5B89\u5168\u885B\u751F\u6CD5"],
      ["project-management", "\u52B4\u50CD\u8005\u6D3E\u9063\u6CD5"]
    ];
    for (const [ind, law] of reachCases) {
      const j = buildJapanInjection(ind, "", []).injection_lines_for_agents.join("\n");
      if (!new RegExp(law).test(j)) failures.push(`${ind} \u306B ${law} \u304C\u6CE8\u5165\u3055\u308C\u306A\u3044`);
    }
    const bogus = buildJapanInjection("zzz-not-a-real-industry", "", []);
    const jb = bogus.injection_lines_for_agents.join("\n");
    for (const law of ["\u5B85\u5730\u5EFA\u7269\u53D6\u5F15\u696D\u6CD5", "\u65C5\u9928\u696D\u6CD5", "\u5150\u7AE5\u798F\u7949\u6CD5", "\u5EFA\u8A2D\u696D\u6CD5", "\u52B4\u50CD\u8005\u6D3E\u9063\u6CD5"]) {
      if (new RegExp(law).test(jb)) failures.push(`\u5B9F\u5728\u3057\u306A\u3044\u696D\u7A2E\u540D\u306B ${law} \u304C\u904E\u5270\u767A\u706B`);
    }
    const unknown = buildJapanInjection("staffing-agency", "", []);
    if (!unknown.has_data) failures.push("\u672A\u77E5\u696D\u7A2E\u3067 has_data=false");
    const ju = unknown.injection_lines_for_agents.join("\n");
    if (!/インボイス制度/.test(ju) || !/電子帳簿保存法/.test(ju) || !/個人情報保護法/.test(ju))
      failures.push("\u672A\u77E5\u696D\u7A2E\u3067\u57FA\u672C3\u6CD5\u304C\u63C3\u308F\u306A\u3044");
    const empty = buildJapanInjection("", "", []);
    if (empty.has_data) failures.push("\u7A7A\u5165\u529B\u3067 has_data=true (no-op\u3067\u306A\u3044)");
    if (empty.injection_lines_for_agents.length !== 0)
      failures.push("\u7A7A\u5165\u529B\u3067\u6CE8\u5165\u6587\u304C\u751F\u6210\u3055\u308C\u305F");
  } catch (e) {
    failures.push("selftest \u4F8B\u5916: " + e.message);
  }
  emit({ ok: failures.length === 0, mode: "selftest", failures });
  process.exit(failures.length === 0 ? 0 : 1);
}
var arg = process.argv[2] ?? "";
if (arg === "--selftest") {
  runSelftest();
} else {
  try {
    runRecall();
  } catch (e) {
    emit({
      ok: false,
      mode: "recall",
      has_data: false,
      inference_block_markdown: "",
      injection_lines_for_agents: [],
      error: e.message
    });
  }
}
