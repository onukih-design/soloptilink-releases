# Japan → BOOST 知識連携 (japan-link)

`/soloptilink-boost` 起動時に、`/soloptilink-japan`(日本法令・業種知識レイヤー)の知識
（適用法令・業種別の優先実装機能・必要帳票）を自動で想起し、ビルドの全105ロールへ
反映する連携レイヤー。顧客が japan を明示起動しなくても、検出業種から日本法令準拠を
自動適用する。

## 設計判断（tenant-dna-link / executive-link と同型）

- **japan 本体は無編集（越境ゼロ）**。連携 API（`recommendLaws` / `recommendExtendedLaws`
  / `recommendFeatures` / `explainRecommendations`）は japan 側に実装・export 済みだったが、
  BOOST 側に $TARGET_TASK へ折り込む配線が無かった。本フォルダが配線する。
- **index.ts は経由しない**。japan の index.ts は `@/` alias や `@soloptilink/legal-sdk`
  等の外部参照を含みバンドル不能。連携に必要な**3ファイルを直接 import** する
  （`laws.ts`/`laws_extended.ts` は import 無し、`feature_recommender.ts` は type-only のみ）。
- **実行基盤**: 依存3ファイルは外部 npm ゼロ。esbuild で単一の自己完結 `.mjs` に
  バンドルし bare `node` で高速実行。`lib/japan` は `~/.soloptilink/skills/...` への
  symlink だが esbuild が追従する。
- **最優先指令の死守**: 業種・依頼文なし・失敗はすべて no-op で素通り（bridge は常に exit 0）。

## なぜ「ほぼ常に適用」でよいか（過剰注入にならない）

executive はロール注入が無関係な業務で誤発火しうるため厳格ゲートを置いたが、japan の
**インボイス制度・電子帳簿保存法・個人情報保護法**は日本の業務システムほぼ全てに適用される。
よって業種が判明していれば適用するのが正しいデフォルト（`recommendLaws` は未知業種でも
基本3法を安全に返す）。業種も依頼文も無いときだけ no-op。

## 構成ファイル

| ファイル | 役割 | 実行時必要 |
|---|---|---|
| `japan-entry.ts` | バンドルのビルド元。japan API を呼ぶ薄いエントリ＋selftest | ✗ (ビルド時のみ) |
| `japan-recall.bundle.mjs` | 自己完結バンドル（japan の連携3ファイルを内包） | ✓ |
| `japan-recall.bundle.meta.json` | ソースハッシュ封緘（陳腐化検知） | ✓ |
| `japan-bridge.mjs` | BOOST Step 0.88 の窓口。業種→陳腐化検知→バンドル実行→成果物出力 | ✓ |
| `verify-japan-bridge.mjs` | born-passing 検証ゲート（6軸） | 検証時 |
| `build-bundle.sh` | バンドル再生成＋メタ封緘 | 保守時 |

## BOOST からの呼び出し（Step 0.88）

```bash
node ~/.claude/skills/soloptilink-boost/japan-link/japan-bridge.mjs \
  --industry "$DETECTED_INDUSTRY" --task "$TASK_DESC"
```

出力（1行 JSON）: `has_data` / `injection_lines_for_agents`（$TARGET_TASK に折り込む）/
`inference_block_markdown`（agent-evidence/japan-recall.md に保存）。

## 検証（born-passing 6軸）

```bash
node ~/.claude/skills/soloptilink-boost/japan-link/verify-japan-bridge.mjs
```

V1 同梱 / V2 selftest（業種→法令+機能・未知業種→基本3法・空→no-op）/ V3 bridge業種あり→
法令注入+成果物 / V4 未知業種→基本3法 / V5 業種なし no-op exit0 / V6 陳腐化検知。

## 保守

japan の連携3ファイル（laws/laws_extended/feature_recommender）を更新したら必ず:

```bash
bash ~/.claude/skills/soloptilink-boost/japan-link/build-bundle.sh
```

## ★ SKILL.md 配線の重要注意（SoT）

boost SKILL.md は **4箇所同期ミラー**で、**正典(SoT)は `~/.claude/commands/soloptilink-boost.md`**。
稼働スキルを直接編集しても Stop フックの `skill-sot-guard.sh heal` が巻き戻す。
配線は必ず **正典編集 → `skill-sot-guard.sh heal` → `refresh`** の順で行うこと。
本連携の Step 0.88 はこの手順で4箇所すべてに反映済み。

## 既知の制約 / owner 申し送り

- 物理注入 `jp_inject.sh` は package.json を書き換えるため既定では行わず opt-in。
  主軸は知識注入($TARGET_TASK 折り込み)。
- 業種キーは英語（construction/manufacturing/healthcare/retail/food_service/finance 等）。
  boost の DBL 名がこれらと異なる場合でも基本3法は安全に注入される（default fallback）。
- バンドルは japan の連携3ファイルを内包。japan 更新時は必ず `build-bundle.sh` 再実行。
- 同型の先行例は `../executive-link/`（Step 0.55）・`../tenant-dna-link/`（Step 0.95）。
