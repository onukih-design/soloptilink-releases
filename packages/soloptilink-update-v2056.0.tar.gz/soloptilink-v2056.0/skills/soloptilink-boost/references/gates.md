# BOOST 品質ゲート詳細リファレンス (v2040 — コア「ゲート実行表」の全詳細)

> コア SKILL.md の Step 3「ゲート実行表」はここに退避した各ゲート詳細の索引である。各ゲートの軸定義・自動修復内容・完成宣言の必須条件・禁止パターンは本ファイルが正本。経緯・真因の物語段落は 09-step3-archive.md。

---

## 実データ品質検証（全レベル共通・ゲート実行前の基礎 3 点）
1. **モックデータ残存**: `grep -rE "TODO.*DB|data: \[\]|Date\.now\(\)" src/` で残存スタブ検出→修正
2. **DB接続テスト**: `npx prisma db push --dry-run` 等で実DB接続確認
3. **.env完備**: DATABASE_URL等の必須環境変数の設定確認

---

## PFP-061 + PFP-071: First-Login Zero-Friction Gate (初回ログインゼロ摩擦) - 全レベル必須

目的: 「1回目ログイン失敗」の構造的根絶。

4-Check (PFP-071 自動実行):
| Check | 内容 | 自動修復 |
|---|---|---|
| **C1 PORT_CONSISTENT** | `package.json` dev port と `.env` NEXTAUTH_URL port 一致 | `next dev -p N` + `NEXTAUTH_URL=http://localhost:N` 整合 |
| **C2 EMAIL_NORMALIZATION** | `auth.ts` で `email.toLowerCase().trim()` 強制 | 4パターン (credentials.email / parsed.data.email / { email } / email:email) を sed 書換 |
| **C3 SEED_DISPLAY** | `login/page.tsx` に seed credentials pre-fill (空白 useState 禁止) | `seed.ts` 先頭メールを `useState('admin@...')` に注入 |
| **C4 DB_SETUP_SCRIPT** | `db:setup`=`prisma generate && migrate && tsx prisma/seed.ts` | jq/sed で `db:setup` + `postinstall: prisma generate` 追加 |

実行: chain.sh `phase_first_login_gate` (smoke_test 直前)。直接実装時は完成宣言前に `bash ~/.soloptilink/scripts/structural-defenses/pfp-071-first-login-gate.sh --apply "$PROJECT_DIR"` 必須。ephemeral port (49152-65535) は PFP-061 が `env_hallucinated` 判定→3000 正規化。

完成宣言の必須条件:
- [ ] PFP-061 verdict=`consistent`/`applied` (mismatch/env_hallucinated 不可)
- [ ] PFP-071 verdict=`PASS` (C1-C4 全 passed)
- [ ] login form に seed credentials pre-fill (またはデモアカウント表示)
- [ ] `npm run dev` 直後 `/login` デフォルト値のまま `signIn` 押下でダッシュボード到達

禁止パターン:
- ❌ `useState('')` で email/password 空
- ❌ `findUnique({ where: { email: credentials.email } })` で `.toLowerCase()` 省略
- ❌ NEXTAUTH_URL と dev port 不一致
- ❌ ephemeral port (49152-65535) を NEXTAUTH_URL に書く

---

## PFP-079: Login Redirect Race Gate (LRRG) - 全レベル必須

目的: 認証 200 OK + cookie発行成功でも /login に戻る3層 race (callbackUrlフルURL / refresh race / SessionProvider 300回polling) の根絶。

5-Check (chain.sh phase_first_login_gate が PFP-071 直後に自動実行):
| Check | 内容 | 自動修復 |
|---|---|---|
| **L1 CALLBACK_URL_NORMALIZED** | `params.get('callbackUrl')` が pathname-only か | `sanitizeCallbackUrl()` 注入+取得行経由化 |
| **L2 NO_REFRESH_AFTER_PUSH** | `router.push(...); router.refresh()` 二重発火検出 | `router.refresh()` 行削除 |
| **L3 SESSIONPROVIDER_THROTTLE** | `<SessionProvider refetchInterval={0} refetchOnWindowFocus={false}>` 設定済か | props 注入 |
| **L4 SIGNIN_PATTERN_SAFE** | signIn `redirect:false` 時 L1+L2 PASS か | WARN のみ (L1+L2 PASS で自動 PASS) |
| **L5 MIDDLEWARE_CALLBACK_HINT** | `next-auth/middleware` 直使い時の callbackUrl フルURL警告 | INFO のみ (L1 で吸収) |

実行: `STRICT_FIRST_LOGIN_GATE=true` (default) で FAIL なら生成停止。直接実装時は完成宣言前に `bash ~/.soloptilink/scripts/structural-defenses/pfp-079-login-redirect-race-gate.sh --apply "$PROJECT_DIR"` 必須。

完成宣言の必須条件:
- [ ] PFP-079 verdict=`PASS` (L1-L3 passed / L4-L5 は WARN/INFO 許容)
- [ ] cookie クリア→/login→seed pre-fill のままサインイン→dashboard に**1回で滞在** (preview_eval+preview_snapshot)
- [ ] `/api/auth/session` polling 安定 (300回連打なし / preview_network)
- [ ] middleware redirect 後の `callbackUrl` がフルURLでも内部 navigation で正常動作

禁止パターン:
- ❌ `const callbackUrl = params.get('callbackUrl') || '/dashboard'`
- ❌ `router.push(callbackUrl); router.refresh()` の連続発火
- ❌ `<SessionProvider>` の素のまま使用
- ❌ middleware で `next-auth/middleware` を直接 default export

---

## PFP-074: Form Critical Path Gate (FCPG/REHD/OSCG 三兄弟) - 全レベル必須

目的: 「請求書/見積/契約/受注/予約フォームが一発で送信できない」の根絶。

3-Module (chain.sh phase_form_critical_path 自動実行):
| Module | 軸数 | 内容 | 失敗時 |
|---|---|---|---|
| **REHD** | - | Server Component に `onChange`/`onClick`/`onSubmit` 直書き検出 | Strict で exit 1 |
| **FCPG** | 8 | ZHRC (Zod↔HTML required整合) / NMA (name属性) / DLR (動的行最低1行required) / SBR (Submit binding) / ESC (Error Surface Coverage) / EMP (空ハンドラ排除) / CSR (Critical Path全PASS) / PPV (印刷ビュー整合) | Strict で exit 1 |
| **OSCG** | 13 | DB副作用 / 遷移 / トースト / ローディング状態 / 監査ログ等の一発完成 | Strict で exit 1 |

実行: `STRICT_FORM_CRITICAL_PATH=true` (default) で FAIL なら生成停止 (smoke_test 直前)。直接実装時は完成宣言前に必ず実行:
```bash
bash ~/.soloptilink/lib/first-boot-perfect/rsc-event-handler-detector.sh run "$PROJECT_DIR"
bash ~/.soloptilink/lib/first-boot-perfect/form-critical-path-guarantor.sh run "$PROJECT_DIR"
bash ~/.soloptilink/lib/first-boot-perfect/one-shot-completeness-gate.sh run "$PROJECT_DIR"
```

完成宣言の必須条件 (Quality Fortress 上位互換):
- [ ] REHD exit 0 (イベント直書き 0件) / FCPG exit 0 (8軸違反 0件) / OSCG exit 0 (13軸 PASS)
- [ ] 上記フォームを空入力送信→**全フィールドのバリデーションエラー表示**
- [ ] valid入力 submit → 200 → 一覧反映 → トースト表示まで一発

禁止パターン:
- ❌ `<Button onClick={save}>` で送信 (`<form onSubmit>` / `<form action={serverAction}>` 必須)
- ❌ Zod `.min(1)` 必須なのに `<input>` に `required` なし
- ❌ Server Component に `onChange={...}` 直書き
- ❌ `parsed.error.errors[0].message` で1個だけ返す (`parsed.error.errors.map` で全件)
- ❌ 動的行追加UIで1行目の required 省略

---

## PFP-080: Layered Depth Gate (業界深掘り L0-L3 / 23軸目) - 全レベル必須

目的: 「一発目が L0 汎用骨組み止まりで L2/L3 未到達」の根絶。

4-Layer (chain.sh phase_layered_depth_gate 自動実行):
| Layer | 内容 | 判定基準 |
|---|---|---|
| **L0 骨組み** | User/Auth/health/api scaffolding | Prisma model≥1 かつ pages≥1 |
| **L1 業界画面** | DBL keyword in page filename or .tsx content | grep hit ≥ 5 |
| **L2 業界マスタ** | DBL keyword in Prisma model/enum names | grep hit ≥ 3 |
| **L3 業界ロジック** | DBL keyword in lib/services logic | grep hit ≥ 10 |

達成判定 (連続到達式): L0→L1→L2→L3 順評価、途中 FAIL で以降 achieved に含めない。業界用語含有率 (二重ゲート): DBL 登録済み=100語+ / 未登録=150語+ 必須。
実行: `STRICT_LAYERED_DEPTH=true` (default) で `LAYERED_DEPTH_MIN_LAYER` (default: L2) 未達なら生成停止。直接実装時 (Step 2) は完成宣言前に必ず:
```bash
bash ~/.soloptilink/lib/first-boot-perfect/layered-depth-gate.sh run "$PROJECT_DIR" --dbl <dbl_name>   # DBL 自動推測なら --dbl 省略可
```
Refiner (Strict 停止時): L2未達→DBL `models` から業界マスタ5-10件追加 / L3未達→DBL `business_logic[]` から3-5件実コード化 / 含有率不足→description・コメント・placeholder 補強+DBL pages 追加。

完成宣言の必須条件:
- [ ] layered-depth-gate.sh run exit 0
- [ ] `.soloptilink/layered-depth-results.json` の `achieved_layer` ≥ `LAYERED_DEPTH_MIN_LAYER`
- [ ] 同 json の `industry_terminology_coverage.status`=`PASS`

禁止パターン:
- ❌ DBL に `KasanMaster` model 登録済なのに schema.prisma に無い
- ❌ DBL に `calculateMonthlyReward` business_logic 登録済なのに lib/ に実装無し
- ❌ pages が全て汎用 (`/dashboard /jobs /community`) で業界ページ無し
- ❌ enums が `JobType / ApplicationStatus` のみで業界 enum 無し

---

## PFP-098: Deep System Gate (L4/L5/L6 / 27軸目) - 全レベル必須・「薄っぺらい」根絶

目的: 「UIは綺麗だが中身が薄い」の根絶。PFP-080 (L0-L3) の上に「実運用できる深さ」を L4/L5/L6 で測る。

| Layer | 内容 | 判定 |
|---|---|---|
| **L4 データ充足** | 全業務テーブルに業界文脈の実データ seed 済 (空テーブル無し) | seed 網羅率 ≥ 70% かつ seedファイル実在 |
| **L5 画面連携 (ドリルダウン)** | 一覧主要列→詳細クリック遷移 + 全業務モデルに `[id]` 詳細ページ | 詳細ページ網羅率 ≥ 50% かつ ドリルダウン率 ≥ 60% |
| **L6 業務貫通** | 詳細→関連モジュール相互リンク + ダッシュボード全モデル集計 + 孤児ページ無し | 集計モデル ≥ 3(or過半) かつ 相互リンク ≥ 1 かつ 孤児ページ ≤ 10% |

達成判定 (連続到達式): L3 起点に L4→L5→L6 順評価、途中 FAIL で連鎖断絶。

実行 (直接実装 Step 2 / 完成宣言前に必ず):
```bash
bash ~/.soloptilink/lib/first-boot-perfect/deep-system-gate.sh run "$PROJECT_DIR"
# 結果: .soloptilink/deep-system-results.json (achieved_layer / verdict)
# 補強: .soloptilink/deep-system-refiner.json (needs_detail_page / needs_clickable_list / needs_dashboard_aggregation / needs_cross_links / orphan_pages / instructions)
```
Refiner (achieved<DEEP_SYSTEM_MIN_LAYER): L4→`needs_seed` へ業界文脈 seed (各10〜50件・FK整合) / L5→`needs_detail_page` へ `app/<module>/[id]/page.tsx` 作成+`needs_clickable_list` を `<Link href={`/<module>/${row.id}`}>` 結線 / L6→相互 `<Link>`+`needs_dashboard_aggregation` 集計化+`orphan_pages` ナビ結線。

完成宣言の必須条件:
- [ ] `achieved_layer` ≥ `DEEP_SYSTEM_MIN_LAYER` (既定 L5)
- [ ] `deep-system-refiner.json` の `needs_detail_page` / `needs_clickable_list` が空
- [ ] 一覧の企業名/氏名/件名クリック→詳細が開く (preview_click+preview_snapshot)
- [ ] ダッシュボードに各業務モジュールの実集計が反映

禁止パターン:
- ❌ 一覧の企業名/氏名が素の `<p>{name}</p>` でクリック不可 (必ず `<Link>`/onRowClick)
- ❌ 一覧だけ作って `[id]` 詳細ページが無いモジュール
- ❌ 全テーブル空 or admin1件のみ
- ❌ ダッシュボードがハードコード値 or 一部モデルのみ集計
- ❌ 詳細が関連モジュール (顧客↔商談↔請求) へ相互リンクしない
- ❌ 孤児ページを残す

---

## PFP-100: CRUD Input Capability Gate (28軸目) - 全レベル必須・「入力できないシステムを出さない」根絶

目的: 「閲覧専用システム」の出荷前根絶。PFP-098 の「読む導線」の対=**「書く導線 (新規作成→編集→削除)」の実在**を測る唯一のゲート。

3軸 (業務モデル単位):
| 軸 | 内容 | 判定 |
|---|---|---|
| **C1 作成フォーム** | `app/<module>/new(create/add)/page.tsx` もしくは module 配下の入力フォーム tsx | 網羅率 ≥ 60% |
| **C2 書込パス** | `prisma.<model>.create/upsert` を行う server action / API route(POST) (seed 除く) | 網羅率 ≥ 60% |
| **E 編集フォーム** | `[id]/edit/page.tsx` + `prisma.<model>.update` (副次・WARN のみ) | — |

verdict: `not_applicable` (Prisma/Next でない・業務モデル0) / **`BLOCK`** (業務モデルが在るのに作成フォーム「ゼロ」=完全閲覧専用 → **Strict 不問で生成停止・完成ゲート hook が物理ブロック**) / `FAIL` (Strict かつ 作成網羅<基準) / `WARN` (非Strict・refiner 指示) / `PASS`。

実行 (直接実装 Step 2 / 完成宣言前に必ず):
```bash
bash ~/.soloptilink/lib/first-boot-perfect/crud-input-capability-gate.sh run "$PROJECT_DIR"
# 結果: .soloptilink/crud-input-capability-results.json / 補強: crud-input-capability-refiner.json
```
Refiner: `needs_create_form`→`app/<module>/new/page.tsx` (react-hook-form+zod 全編集可能フィールド・一覧に「新規作成」`<Link>` 結線) / `needs_write_path`→server action / API route(POST) で `prisma.<model>.create` (zod 二重防御) / `needs_edit_form`→`[id]/edit/page.tsx` (update)+詳細に「編集」「削除」。

完成宣言の必須条件:
- [ ] verdict が BLOCK/FAIL でない (PASS/WARN/not_applicable)
- [ ] `needs_create_form` が空 (全業務モデルに入力導線疎通)
- [ ] `/login`→ダッシュボード→「新規作成」→入力→保存→一覧反映 が一発成功 (preview_fill+preview_click+preview_snapshot)
- [ ] 詳細ページの「編集」「削除」が機能

禁止パターン:
- ❌ 業務モデルが在るのに作成フォームが1つも無い (完全閲覧専用。最重大・BLOCK)
- ❌ 「新規作成」ボタンはあるがフォーム実体無し/押しても何も起きない
- ❌ onSubmit が空 or `console.log` だけで `prisma.<model>.create` に到達しない
- ❌ 読む画面 (一覧/詳細) だけ作って書く画面 (作成/編集) を後回し
- ❌ seed データを眺めるだけでユーザーがデータを増やせない

---

## PFP-106: Security Hardening Gate (29軸目) - 全レベル必須・「守りの無いシステムを出さない」根絶

目的: セキュリティヘッダ・レート制限・ログインロックアウト・npm audit・機微カラム暗号化が「検査のみ・実装なし」だった盲点 (2026-06-11 セキュリティ総点検) の根絶。認証総当たり・クリックジャッキング・DoS・DB漏洩時の平文露出への防御を既定で装備する。

7軸 (apply で安全に自動是正 — ファイル追加・ヘッダ注入のみ・破壊的変更なし):
| 軸 | 内容 | 既定動作 |
|---|---|---|
| **S1 SECURITY_HEADERS** | next.config の headers() — HSTS / X-Frame-Options: DENY / nosniff / Referrer-Policy / Permissions-Policy 全ルート適用 | apply で自動注入 |
| **S2 RATE_LIMIT** | `lib/rate-limit.ts` (スライディングウィンドウ・checkRateLimit) | apply で生成 + refiner で配線指示 |
| **S3 LOGIN_LOCKOUT** | `lib/login-guard.ts` (5回連続失敗→15分ロック) | apply で生成 + refiner で配線指示 |
| **S4 NPM_AUDIT** | package.json scripts に `audit:security` (npm audit --audit-level=high) | apply で追加 |
| **S5 IDOR_CHECK** | `[id]` 動的ルートの findUnique に tenantId/userId 等の所有権条件 | WARN + refiner |
| **S6 ZOD_MAX** | z.string() への .max() 普及率 ≥30% (巨大入力 DoS 防止) | WARN + refiner |
| **S7 FIELD_CRYPTO** | 機微カラム (myNumber/bankAccount 等) があるのに `lib/field-crypto.ts` (AES-256-GCM) 不在 | apply で生成 + refiner |

実行: `bash ~/.soloptilink/lib/first-boot-perfect/security-hardening-gate.sh apply "$PROJECT_DIR"` (結果: `.soloptilink/security-hardening-results.json` / 補強: security-hardening-refiner.json)。chain.sh 経由は `phase_security_hardening_gate` が PFP-100 直後に自動実行。

Refiner (生成しただけで終わらせない — 配線まで):
- S2 → `checkRateLimit(\`signin:${ip}\`, { limit: 5, windowMs: 60_000 })` を signin/signup/パスワードリセット/重要 POST の handler 冒頭へ配線し 429 を返す
- S3 → NextAuth `authorize()` 冒頭で `isLockedOut(email)` → 即 null / bcrypt 不一致で `recordLoginFailure(email)` / 成功で `clearLoginFailures(email)`
- S5 → `[id]` ルートの where に session 由来の tenantId/userId を必ず含める
- S7 → 機微カラムは `encryptField()` で保存・`decryptField()` で表示。`FIELD_ENCRYPTION_KEY` (32byte base64) を .env に発行

完成宣言の必須条件:
- [ ] verdict が FAIL でない / S1-S4 が passed/applied (apply 後の再 run で確認)
- [ ] S2/S3 は生成だけでなく**実配線済** (rate-limit/login-guard の import が認証経路に存在)
- [ ] ログイン画面で誤パスワード連続入力→6回目以降は正しいパスワードでも一定時間拒否されることを実測

禁止パターン:
- ❌ レート制限・ロックアウト無しで認証 API を公開
- ❌ rate-limit.ts / login-guard.ts を生成だけして import 0 件のまま完成宣言
- ❌ マイナンバー/口座番号/保険証番号カラムを平文保存
- ❌ next.config に headers() が無いまま本番デプロイ

---

## PFP-107: Permission Matrix Gate (権限マトリクス / 30軸目・v2040 NEW) - 全レベル必須

「UIで隠すだけ権限管理」を根絶。4軸: P1 schema.prisma に role フィールド/enum 実在 / P2 管理者系 API route (admin/users/settings 系) に session取得+role判定 (一般ユーザーの直叩き遮断・コア軸) / P3 [id] 動的ルートの findUnique/update/delete に session 由来の所有権条件 (PFP-106 S5 と同一規約) / P4 admin ページのサーバ側 role 判定 (layout/middleware)。

**完成宣言前に必ず** `bash ~/.soloptilink/lib/first-boot-perfect/permission-matrix-gate.sh apply "$PROJECT_DIR"` を実行し、`.soloptilink/permission-matrix-results.json` の verdict が FAIL でない + `permission-matrix-refiner.json` の配線指示 (requireAdmin/ownedWhere の import 配線・admin layout の redirect) を全消化。apply は lib/authz.ts (権限ヘルパ・ロール値は小文字 'admin'/'user' 統一) の追加のみで非破壊。既定 WARN (`STRICT_PERMISSION_MATRIX=true` で FAIL 昇格)。一時無効化: `SOLOPTILINK_PERMISSION_MATRIX_GATE=off`

---

## PFP-108: Document Output Gate (帳票印刷/PDF出力保証・v2040 NEW)

日本の中小企業必須の「紙に出す/PDFで渡す」(見積書・納品書・領収書・請求書・報告書) を保証し「画面では見えるが印刷すると崩れる」を根絶。4軸: D1 帳票対象検出 (請求|見積|納品|領収|invoice|estimate|quote|receipt|report 等。0件なら not_applicable) / D2 印刷ビュー実在 (@media print or print 専用 page.tsx) / D3 PDF生成経路 (@react-pdf/jspdf/puppeteer/pdfkit or /api/*pdf* ルート) / D4 帳票テンプレ A4 最低要素 (社名・日付・合計・宛先)。

**帳票系モデル/画面があるビルドは完成宣言前に必ず** `bash ~/.soloptilink/lib/first-boot-perfect/document-output-gate.sh apply "$PROJECT_DIR"` を実行し、`.soloptilink/document-output-results.json` の verdict が FAIL でない + `document-output-refiner.json` の指示 (PDF ルート実装・A4 要素配置・印刷ボタン) を全消化。D2 不足は apply が globals.css へ基本 @media print CSS (背景非表示・A4 余白 12mm・改ページ制御) を安全注入。既定 WARN (`STRICT_DOCUMENT_OUTPUT=true` で FAIL 昇格)。一時無効化: `SOLOPTILINK_DOCUMENT_OUTPUT_GATE=off`

---

## PFP-171: Form Fidelity Gate (帳票様式忠実度・v2054 NEW / 柱2)

「出るけど中身が違う」の根絶。PFP-108 が『帳票が出る』、PFP-165 が『実機で PDF が物理生成される』を保証するのに対し、本ゲートは『出た帳票の中身が規定様式 (法定記載事項・業種様式) に一致している』を保証する最終層。lib/japan/official-forms/required-fields/*.json (様式SoT 6種: 適格請求書 / 建設出来高請求 / 介護提供実績記録 / 源泉徴収票 / 障害者雇用状況報告 / 補助金申請) と生成物の帳票テンプレ実装を突合する。

- **F1 様式該当性検出**: schema/画面/本文から該当様式を検出 (建設シグナル時は construction-invoice が invoice-qualified に優先)。該当 0 件は not_applicable。
- **F2 必須記載事項カバレッジ**: 該当様式の requiredFields (required=true) 全項目が生成物ソースに実装されていること (label/id/表記ゆれ別名で突合)。**1項目でも欠落 = FAIL (exit 1)**。
- **F3 実機PDF中身検証 (WARN型・一気通貫)**: PFP-165/RDP が保全した `.soloptilink/artifacts/last-document.pdf` に pdftotext (在れば) で必須記載の実在を突合。

**完成宣言前に必ず** `bash ~/.soloptilink/lib/first-boot-perfect/form-fidelity-gate.sh run "$PROJECT_DIR"` を実行し、`.soloptilink/form-fidelity-results.json` の verdict が FAIL でないこと + 非PASS 時は `form-fidelity-refiner.json` の指示 (欠落記載事項の実装) を全消化。

**PFP-108 との統合 (AUTO_STRICT)**: document-output-gate の D6 軸として自動実行され、**該当様式が 1 件以上 (=帳票該当業種) のビルドでは PFP-108 の Strict が自動昇格して FAIL がブロックになる** (明示 `STRICT_DOCUMENT_OUTPUT=true|false` が常に最優先)。較正用降格: `FORM_FIDELITY_MODE=warn`。一時無効化: `SOLOPTILINK_FORM_FIDELITY_GATE=off`。selftest: `form-fidelity-gate.sh selftest` (健全/欠落/較正/非該当の弁別) / `document-output-gate.sh selftest` (AUTO_STRICT のブロック性込み4面)。

---

## PFP-109: CSV I/O Gate (Excel台帳の取込/CSV受渡し保証・v2040 NEW)

「今 Excel で管理している台帳を取り込みたい / 税理士に CSV で渡したい」を保証。3軸: C1 主要業務モデルの CSVエクスポート経路 (app/api/<module>/export/route.ts or エクスポートボタン・網羅率60%+) / C2 UTF-8 BOM 付与の実在 (Excel 文字化け根絶) / C3 CSVインポート画面 (アップロード+取込前プレビュー+エラー行表示・業務モデル5以上の本格規模のみ)。

**完成宣言前に必ず** `bash ~/.soloptilink/lib/first-boot-perfect/csv-io-gate.sh apply "$PROJECT_DIR"` を実行し、`.soloptilink/csv-io-results.json` の verdict が FAIL でない + `csv-io-refiner.json` の配線指示 (export route 実装・csvResponse 使用・インポート画面) を全消化。apply は lib/csv-export.ts (BOM付きユーティリティ) のみ安全生成。既定 WARN (`STRICT_CSV_IO=true` で FAIL 昇格)。一時無効化: `SOLOPTILINK_CSV_IO_GATE=off`

---

## PFP-110: Performance Baseline Gate (性能基礎・v2040 NEW) - 一般業務システム全件

「納品直後は速いが半年後に遅くなる」を事前根絶。4軸: B1 ループ (.map/for) 内 await prisma.*.find* の N+1 疑い / B2 findMany の take/skip ページネーション実在 / B3 First Load JS 概算 (.next がある場合のみ・既定 800KB) / B4 重量ライブラリ (recharts/chart.js/@react-pdf 等) の page.tsx 直 import (next/dynamic 推奨)。

完成宣言前に `bash ~/.soloptilink/lib/first-boot-perfect/performance-baseline-gate.sh run "$PROJECT_DIR"` を実行し、`.soloptilink/performance-baseline-results.json` の verdict 確認 + 非PASS 時は `performance-baseline-refiner.json` の指示を消化。既定 WARN 非ブロッキング (`STRICT_PERFORMANCE_BASELINE=true` で FAIL 昇格)。一時無効化: `SOLOPTILINK_PERFORMANCE_GATE=off`

---

## PFP-111: Backup/Restore Gate (バックアップ/リストア・v2040 NEW) - 全レベル必須

「全データが消えた」事故の根絶。3軸: R1 scripts/backup.(sh|ts|mjs) 実在 (PostgreSQL は pg_dump / SQLite は世代コピー・最新14世代保持) / R2 docs/RESTORE.md (日本語リストア手順書・5ステップ以内) / R3 管理画面エクスポート導線 (WARN のみ)。

**完成宣言前に必ず** `bash ~/.soloptilink/lib/first-boot-perfect/backup-restore-gate.sh apply "$PROJECT_DIR"` を実行し、`.soloptilink/backup-restore-results.json` の verdict が FAIL でない + `backup-restore-refiner.json` の指示 (CSV エクスポート導線追加等) を全消化。R1/R2 不足は apply が DATABASE_URL 種別 (file:|postgres) に適合した実体を自動生成 (ファイル追加・注入のみ)。既定 WARN (`STRICT_BACKUP_RESTORE=true` で FAIL 昇格)。一時無効化: `SOLOPTILINK_BACKUP_GATE=off`

---

## PFP-115: Enterprise Integration Gate (基幹統合・v2040 NEW) - enterprise ビルドのみ

基幹システム級ビルド (Step 0.87 で `enterprise-blueprint.json` を生成した場合) の連携 3 軸を保証: G1 自動仕訳連動 (受注→出荷→売上仕訳 等) / G2 在庫引当整合 / G3 承認ワークフロー実在 (ApprovalRequest + /approvals)。

完成宣言前に `bash ~/.soloptilink/lib/first-boot-perfect/enterprise-integration-gate.sh apply "$PROJECT_DIR"` (run で検証のみ) を実行し G1/G2/G3 PASS を完成条件に含める。不足は apply が安全に自動是正 (ヘルパ追加・schema 追記のみ) + refiner 指示で配線。enterprise-blueprint.json 不在なら not_applicable。既定 WARN (`STRICT_ENTERPRISE_INTEGRATION=true` で昇格)。kill-switch: `SOLOPTILINK_ENTERPRISE_GATE=off`

---

## PFP-094: Incremental Integration Gate (26軸目) - 追加開発時必須

feature_add / modification 時、追加 model/api/page の結線を4軸検証: 孤児テーブル / 死蔵API / 孤児ページ / ダッシュボード未反映。**完成宣言前に必ず** `bash ~/.soloptilink/lib/first-boot-perfect/incremental-integration-gate.sh run "$PROJECT_DIR" --scope changed` (新規構築時 `--scope full`) を実行し、`.soloptilink/incremental-integration-results.json` の verdict 確認 + refiner を反映。既定 WARN (`STRICT_INCREMENTAL_INTEGRATION=true` で昇格)。

---

## PFP-086: Runtime Login Smoke Gate (実DBログイン検証) - 全レベル必須・最重要

目的: 「auth.ts は完璧なのに初回ログイン必失敗」(DB 未起動/未push/未seed→User 空→findUnique null) の根絶。既存 PFP-061/071/079 は静的検査のみで実DBログイン未検証。
実体: プロジェクト自身の Prisma client+bcryptjs で authorize() (email.toLowerCase().trim()→findUnique→bcrypt.compare) を実DBに再現。probe PASS=DB不触 (稼働DB保護) / FAIL時のみ db:setup (generate→push→seed) / Postgres role/db 不在は自動プロビジョニング / bcrypt 不一致は即 FAIL。

```bash
bash ~/.soloptilink/lib/first-boot-perfect/runtime-login-smoke.sh "$PROJECT_DIR"
# 実 HTTP ログインまで検証するなら --full (next-auth credentials callback + session cookie 発行確認)
```

Desktop 強制: Stop hook `~/.soloptilink/lib/hooks/boost-completion-gate-hook.sh` — BOOST 成果物が cwd に在り `runtime-login-smoke.json` 未PASS なら完成宣言を `{"decision":"block"}` でブロック。カウンタ最大4回+kill-switch `SOLOPTILINK_COMPLETION_GATE=off` (回避禁止)。
**verdict=PASS は実走で生成した最新成果物 (produced_by=script / 直近生成 / tested_email 非空) に限り有効**。手書き・古い JSON は `unverified` 降格でブロック (捏造封じ)。

完成宣言の必須条件:
- [ ] `.soloptilink/runtime-login-smoke.json` の verdict=`PASS`
- [ ] SQLite なら dev.db に seed 済ユーザ存在 / Postgres ならローカル DB 自動プロビジョニング+seed 済
- [ ] login画面に seed credentials 表示 (pre-fill) され、それで実 probe 成立

禁止パターン:
- ❌ build 成功 / typecheck 0 errors だけで「ログイン可能」と完成宣言
- ❌ curl で `/api/auth/callback/credentials` 1回 200 だけで「完全動作」判断 (DB 未初期化でも cookie は出る)
- ❌ `runtime-login-smoke.json` を生成せず完成宣言

---

## PFP-087: Deploy-Time Login Guarantee Gate (デプロイ時ログイン保証) - デプロイ時最重要

大前提: 「デプロイして」=**本番URLでログインできる状態で出力** (2026-05-31 owner 指示)。既存ゲートは localhost 検証のみ・SQLite 既定はサーバーレスで永続しない盲点を塞ぐ。

検出する 5 モード:
| モード | 内容 | 症状 |
|---|---|---|
| **M1** | SQLite のままサーバーレス (Vercel/Netlify) へデプロイ | ephemeral FS で User 不在→恒常ログイン不可 |
| **M2** | NEXTAUTH_URL が localhost のまま / 未設定 | callback ドメイン不一致→/login に戻る |
| **M3** | NEXTAUTH_SECRET (AUTH_SECRET) 本番未設定 | JWT 署名/復号失敗→セッション不成立 (断続失敗の主因) |
| **M4** | 本番 DB が migrate / seed されていない | スキーマ無し or admin 不在→ログイン不可 |
| **M5** | Postgres on serverless でプール未設定 (Neon -pooler / pgbouncer=true / directUrl 無し) | cold start で接続枯渇→断続失敗 |

3モード: **preflight**=M1〜M5 静的検出 (M1/M2/M3 致命で BLOCK・mutate なし) / **--apply**=安全是正のみ (NEXTAUTH_SECRET 生成→Vercel設定・NEXTAUTH_URL 整合・本番 migrate+seed。DATABASE_URL は捏造せず未用意なら BLOCK) / **--probe <url>**=最終保証 (本番URLで csrf→callback→session を seed 認証情報で実走・3回リトライで M5 検出)。
自動配線: `lib/auto-deploy.sh` `deploy_auto` 組込済 — `--deploy` 時 preflight 致命→中止、成功後に自動 probe。一時回避 `SOLOPTILINK_DEPLOY_LOGIN_GATE=warn`。

```bash
bash ~/.soloptilink/lib/first-boot-perfect/deploy-login-guarantee.sh "$PROJECT_DIR"                      # デプロイ前 preflight
bash ~/.soloptilink/lib/first-boot-perfect/deploy-login-guarantee.sh "$PROJECT_DIR" --apply --url "<本番URL>"   # 安全是正
bash ~/.soloptilink/lib/first-boot-perfect/deploy-login-guarantee.sh "$PROJECT_DIR" --probe "<本番URL>"  # デプロイ後 最終保証
```

完成宣言の必須条件 (デプロイを伴う場合):
- [ ] preflight verdict が `BLOCK` でない (`.soloptilink/deploy-login-guarantee.json`)
- [ ] デプロイ後 `--probe <本番URL>` の verdict=`PASS`
- [ ] DB エンジンがサーバーレス互換 (本番は PostgreSQL、SQLite はローカル専用)
- [ ] 本番 env に NEXTAUTH_URL (本番ドメイン)+NEXTAUTH_SECRET 設定済

禁止パターン:
- ❌ ローカル PASS だからと本番ログイン未検証で完成宣言
- ❌ SQLite (`file:./dev.db`) のまま Vercel にデプロイ
- ❌ NEXTAUTH_URL=localhost / NEXTAUTH_SECRET 未設定のまま本番デプロイ
- ❌ 本番 DB に migrate deploy + seed をせず「デプロイ完了」報告

---

## PFP-089: Data Persistence Gate (DPG / 永続DB保証) - 全レベル必須

大前提 (2026-07-15 owner方針): SQLite はサーバーレスで揮発するため本番は必ず永続DB(PostgreSQL)に接続する。**保存先は「無料の永続DB」を既定適用し、お客様への質問はしない。** 無料枠でもデータは永続保存される (0円のまま消えない)。**「有料でないと永続しません」という案内は誤りであり厳禁。** 有料は (a) 顧客の明示要求 (b) 無料枠で成立しない規模が判明した場合のみ、`lib/cost-simulator.sh estimate` の概算費用を提示して合意の上で選ぶ (勝手に有料化しない)。PFP-087=本番URL実ログイン保証 / PFP-089=永続DBの構造保証。

判定 (`.soloptilink/data-persistence-guarantee.json` の verdict): not_applicable (デプロイ意図なし/既に永続DB/Prisma無し)=通過 / PASS (無料既定 or 有料明示で永続DBに整合)=通過 / **BLOCK (未接続=none のまま本番意図あり)=ブロック**。旧挙動 (tier未指定=BLOCKで確認強制) は `DPG_REQUIRE_TIER_CONFIRM=true` でのみ復元可。

実行: 本番意図あり+SQLite なら tier 未指定で実行するだけ (無料の永続DBが既定適用される)。
```bash
bash ~/.soloptilink/lib/first-boot-perfect/data-persistence-guarantee.sh "$PROJECT_DIR" --apply           # 無料既定 (推奨)
bash ~/.soloptilink/lib/first-boot-perfect/data-persistence-guarantee.sh "$PROJECT_DIR" --tier paid --apply  # 有料を明示合意した場合のみ
```
chain.sh 経由は `DB_PERSISTENCE_TIER` 環境変数 (未指定=free 既定)。カタログ: 無料=Neon Free (0.5GB・データ永続・無アクセス時休止で初回のみ遅延)・Supabase Free (500MB) / 有料=Neon Launch ($5〜)・Supabase Pro ($25・東京)・Prisma Postgres。詳細: `... catalog`

顧客への開示 (前向きに一言): 「データは無料のまま永続的に保存されます。しばらく使わないと初回表示だけ少し待ちが出ることがあります。データ量が無料枠 (数十万件規模) を超える見込みになったら、概算費用をご提示して有料プランをご提案します。」

禁止パターン:
- ❌ SQLite のまま本番 (Vercel等) にデプロイ
- ❌ 「有料でないと永続しない」「無料だとデータが消える」という誤案内 (無料枠でもデータは永続保存される)
- ❌ 顧客の合意なく有料プランへ誘導・切替 (勝手に有料化)
- ❌ verdict=BLOCK のまま完成宣言

---

## PFP-090: Secret-in-Prompt Protection Gate (SIPG / 機密保護) - 全レベル必須

大前提: 顧客入力の APIキー/接続文字列/トークンが平文で Anthropic/ログ/テレメトリ/生成コード/git 等へ出ると顧客インシデント+当社受領責任が発生。
鍵タイプ (混同禁止): **Type A** (`sk-ant-`/`ANTHROPIC_API_KEY`)=保管せず strip・OAuth 案内・子プロセス env から除去 / **Type B** (Stripe/SendGrid/OpenAI/AWS/DB接続文字列等)=api-key-vault で envelope 暗号化+handle 化、生成コードは env 参照。
3層基盤: `api-key-vault` (AES-256-GCM envelope+RSA-OAEP-4096+Outbound Proxy+90日ローテ) / `local-prompt-shield` (settings.json 4フックで prompt 送信前 handle 化+OS Keychain) / chain.sh `shield-bootstrap` で CLI 引数(LR3) pre-scrub (AKP17)。
検出 SoT: `~/.soloptilink/lib/security/secret-patterns.json` (12パターン)。

判定 (`.soloptilink/secret-protection-guarantee.json` の verdict): not_applicable / PASS / WARN (.env が git 追跡・平文 leak 0件) =通過 / **BLOCK (追跡対象ソースに平文の機密残存)=ブロック**。

```bash
bash ~/.soloptilink/lib/first-boot-perfect/secret-protection-guarantee.sh "$PROJECT_DIR"
# verdict=BLOCK なら平文キーを削除し環境変数(本番は Vercel encrypted env)/api-key-vault へ移すまで完成宣言しない
```

禁止パターン:
- ❌ 生成コードに `const key = "sk_live_..."` をハードコード
- ❌ `.env` 平文キーを git 追跡対象にする
- ❌ Type A (Anthropic キー) を保管 / env に残して従量課金に化けさせる
- ❌ verdict=BLOCK のまま完成宣言

---

## PFP-092: Build/Dev Hygiene + Production Demo Handoff Gate - 全レベル必須・デモ受け渡し

大前提: お客様に見せる成果物はログイン・全ページ巡回・**ログアウト**までエラー0で受け渡す。目的: 「ログアウト押下で `Cannot find module './vendor-chunks/next-auth.js'` (500)」型事故の根絶。

3つの構造対策:
| 対策 | 内容 |
|---|---|
| **guard-build** | 同ポートの稼働サーバを検出・停止し `.next` 並走破損を断つ。`npm run build` を真の終了コードで実行 |
| **serve-prod** | dev停止→provider是正→`.next`掃除→クリーン build→**本番 `next start` (全ルート事前コンパイル)**→ready待ち→スモーク |
| **check (HTTP smoke)** | `/api/auth/csrf,session,providers` + **POST `/api/auth/signout`** を実 HTTP で叩き、500 / MODULE_NOT_FOUND / vendor-chunks 欠落 0 件を実測 |

第2のバグも吸収: provider/URL 不一致 (schema=postgresql+DATABASE_URL=file:) を検出し `file:`→`sqlite` 方向を自動是正 (enum/@db. native 型は手動)。

```bash
bash ~/.soloptilink/lib/first-boot-perfect/build-dev-hygiene-gate.sh serve-prod --auto-stop "$PROJECT_DIR"   # デモ受け渡しを1発で安全化
bash ~/.soloptilink/lib/first-boot-perfect/build-dev-hygiene-gate.sh check "$PROJECT_DIR"                    # 稼働中なら check のみ可
```

完成宣言の必須条件:
- [ ] `.soloptilink/build-dev-hygiene.json` の verdict=`PASS`
- [ ] お客様に渡すのは**本番サーバ (`next start`)** (dev サーバ不可・デモ用途)
- [ ] ログイン→全ページ巡回→**ログアウト**をブラウザ実行し、コンソールエラー0 / 失敗ネットワーク0
- [ ] DB provider が DATABASE_URL のスキームと一致

禁止パターン:
- ❌ 稼働中の `next dev` を止めずに `npm run build` 実行
- ❌ お客様デモに `npm run dev` のサーバをそのまま渡す
- ❌ パイプで終了コードを握り潰しビルド失敗を成功と誤読
- ❌ ログイン画面 200 だけで「動作OK」完成宣言

---

## PFP-UI: UI Quality Gate (リッチUI・Desktop 構造強制) - 全レベル必須

`bash ~/.soloptilink/lib/first-boot-perfect/ui-quality-gate.sh run "$PROJECT_DIR"` の verdict が **FAIL でない**こと (理想 PASS≥9/12)。完成ゲート hook が **Desktop でも自走**し FAIL なら完成宣言をブロック。12軸: shadcn/ui・デザイントークン・アプリシェル・グラフ・スケルトン・空状態・トースト・指標カード・レスポンシブ・ダークモード・アイコン・仕上げユーティリティ。不足は `... apply "$PROJECT_DIR"` で deps/cn 底上げ。kill-switch: `SOLOPTILINK_UI_QUALITY_GATE=off`

---

## PFP-083 + PFP-084: Mega Portal Gate / Image CMS Gate (Mega Portal Edition 時のみ)

### 判定条件 (Step 0.85 / いずれか満たせば起動)
1. DBL category が `mega-portal` (登録済: `real-estate-portal` models 30 / pages 47 / apis 44 / keywords 311)
2. DBL 名が `*-portal` パターン (real-estate/job/car/travel/news)
3. 明示オプション `--portal-scale large` または `MEGA_PORTAL_FORCE=true`
4. 事業推論キーワード「物件検索」「賃貸/売買」「数百万件」「ポータルサイト」「画像CMS」「ファセット検索」「地図検索」「沿線検索」等 3 つ以上

### PFP-083 Mega Portal Gate (13軸 / 24軸目)
M01 next/image 強制 / M02 ISR / M03 sharp / M04 動的 sitemap / M05 robots / M06 JSON-LD / M07 動的 OGP / M08 image remotePatterns / M09 Edge Runtime / M10 Bundle Analyzer / M11 Web Vitals / M12 `<Suspense>` Streaming / M13 Lighthouse Budget

### PFP-084 Image CMS Gate (10軸 / 25軸目)
I01 S3互換ストレージ (R2/MinIO/Cloudinary/Vercel Blob) / I02 sharp pipeline / I03 ドラッグ&ドロップ UI (react-dropzone) / I04 並列アップロード / I05 進捗表示 / I06 WebP+AVIF / I07 サムネ4サイズ / I08 EXIF削除 (個情法R4 GPS漏洩防止) / I09 画像バリデーション / I10 CDN URL 統一返却

### 採用スタック (デフォルト / 顧客環境で差し替え可)
| カテゴリ | 第一選択 | 代替 |
|---|---|---|
| 画像 storage | S3互換 (R2 / MinIO) | Cloudinary / Vercel Blob |
| 検索エンジン | PostgreSQL Full-Text Search | Meilisearch (OSS) / Algolia |
| 地図 | Leaflet + OpenStreetMap | Mapbox / Google Maps |
| 配信 | Vercel Edge Network + ISR | Cloudflare Pages + KV |

### Auto-heal
`bash ~/.soloptilink/lib/first-boot-perfect/mega-portal-gate.sh apply "$PROJECT_DIR"` (sharp install / robots.ts / sitemap.ts / og route + @vercel/og) → `bash ~/.soloptilink/lib/first-boot-perfect/image-cms-gate.sh apply "$PROJECT_DIR"` (`lib/image-cms.ts` + `components/ImageDropzone.tsx` + `app/api/upload/cms-image/route.ts`)。各軸 PASS まで最大 3 巡。

### 完成宣言の必須条件 (Mega Portal Edition 時)
- [ ] PFP-083 verdict が PASS/PARTIAL (min_pass=10/13) / PFP-084 verdict が PASS/PARTIAL (min_pass=7/10)
- [ ] `/search` を localhost で開いて LCP < 3s 実測
- [ ] `/admin/properties/[id]/images` に画像3枚 D&D で全件 200 OK + WebP/AVIF URL 返却
- [ ] `/sitemap.xml` が動的に内容を返す / OGP route (`/api/og?title=test`) が 1200x630 PNG 返却

---

## PFP-120: Quality Evidence Report (品質証明書・v2040 NEW) - 完成宣言直前・非ブロッキング

全品質ゲート実行後 (上記ゲート群の `.soloptilink/*-results.json` が出揃った後) に `bash ~/.soloptilink/lib/quality-evidence-report.sh generate "$PROJECT_DIR"` を実行し `$PROJECT_DIR/品質証明書.html` を発行する。内容は実測記録 (results.json 判定 / agent-evidence 証跡実数 / app ページ走査 / 実測軸レーダーチャート) のみから自動生成され捏造ゼロ・PFP番号非露出 (顧客向け日本語名称)。完成報告でお客様に「品質証明書を同梱しました」と一言添える (中身のコード・内部ゲート名は地の文に貼らない)。生成失敗でも完成は妨げない。kill-switch: `ENABLE_QUALITY_EVIDENCE_REPORT=false`

---

## セキュリティハードニング (Level 2以上)
```bash
~/.soloptilink/soloptilink --security-scan . --security-fix
```

## ドキュメント生成 (Level 3のみ・Claude が直接生成)
`docs/API.md` (OpenAPI準拠) / `docs/SETUP.md` / `docs/ARCHITECTURE.md` / `docs/DEPLOYMENT.md` (Vercel/Railway/Docker) / `docs/COMPLIANCE.md` (業界規制対応)

## dev server 自動起動 (preview_*)
1. `.claude/launch.json` をプロジェクトルートに作成（Next.js + Prisma Studio） 2. `preview_start` で dev server 起動 3. `preview_snapshot` でランディングページ確認 4. `/api/health` で DB 接続検証

---

## PFP-046: Deep Page Traversal Test (DPT / 全ページ実走) - 全レベル必須

目的: build PASS でも本番2層目以降ページで出るエラー (Hydration mismatch / 500 / RSC) の根絶。Playwright + headless Chromium。

1. **ルートインベントリ抽出**: `find src/app -name "page.tsx" -o -name "page.jsx"` で全ルート列挙。動的ルート `[id]`/`[slug]` は **DBシードから実IDを取得**して展開。API ルート (`route.ts`) も GET 疎通確認。
2. **認証セッション確立**: シード済みアカウントで `/login` 認証→session cookie 取得・永続化し全巡回で再利用。
3. **全ルート巡回 + 4種エラー監視**: ①コンソールエラー ②未捕捉例外 (pageerror) ③ネットワーク失敗 (requestfailed) ④HTTP 4xx/5xx (401/403 除外)。
4. **2階層目以降強化検証 (DPTの肝)**: 一覧→詳細 (先頭3行リンク→詳細確認→戻る) / サイドバー全展開 / モーダル全開閉 (`[data-modal-trigger]`・`button:has-text("追加")` 等) / タブ全切替 (`[role="tab"]`)。
5. **フォーム送信検証**: 各 `<form>`: (a) 空入力 submit=バリデーションエラー表示確認 (日本語) / (b) valid入力 submit=遷移先 URL+成功トースト/リダイレクト確認。
6. **エラー集約 + 自動修復ループ**: `dpt-results/<page-path>.png` 保存 / `dpt-results/errors.json`。**0件まで最大5回の自動修復ループ**。
7. **スクリプト雛形**: `cp ~/.soloptilink/lib/templates/dpt.spec.template.mjs tests/dpt.spec.mjs` (テンプレートは本体同梱済)。

実行手順:
```bash
cd "$PROJECT_DIR"
[ ! -d node_modules/@playwright ] && npm i -D @playwright/test && npx playwright install --with-deps chromium
( npm run dev > dpt-dev.log 2>&1 ) &
DEV_PID=$!; trap "kill $DEV_PID 2>/dev/null" EXIT; sleep 10
BASE_URL=http://localhost:3000 \
  DPT_USER="$(node -e "const c=require('./prisma/seed.json');console.log(c.admin_email)")" \
  DPT_PASS="$(node -e "const c=require('./prisma/seed.json');console.log(c.admin_password)")" \
  npx playwright test tests/dpt.spec.mjs --reporter=list 2>&1 | tee dpt.log
cat dpt-results/errors.json
```

完成宣言の必須条件:
- [ ] DPT で errors.json の total が **0**
- [ ] 全ページのスクリーンショットが `dpt-results/` 配下に存在
- [ ] 動的ルート [id]/[slug] が実DB ID で開ける
- [ ] React Hydration mismatch 0件 (`Did not match` をコンソールエラーで検出)
- [ ] サブメニュー / モーダル / タブ展開が機能

**DPT が PASS しない限り、`/soloptilink-boost` は完成宣言してはならない。** (`feedback_always_test_all_pages.md` ルールの強制実装)
