// =============================================================================
// SoloptiLinkAI v2.0 Game Production Engine - Unity Scene Serializer
// =============================================================================
// 責務:
//   Unity のシーンファイル (.unity, YAML 形式) を仕様オブジェクトから生成する。
//   合わせて、Unity が各 Asset を一意識別するために必要な .meta ファイル
//   (GUID 含む YAML) も生成する。
//
//   Unity の .unity ファイルは Tagged YAML 形式で、各 GameObject は
//   "!u!1 &<fileID>" のヘッダで識別される。fileID は 64bit 整数 (重複不可)。
//   GUID は 32 文字の hex (例: "8e7a2b1f3c4d5e6f7081923a4b5c6d7e")。
//
// ライセンス警告:
//   生成された .unity ファイルを商用配布する場合、Unity の利用規約
//   (https://unity.com/legal/editor-terms-of-service) に準拠すること。
//   特に Unity 6 以降 Splash Screen 強制は撤廃済だが、Pro/Enterprise の
//   売上閾値 (USD 200K / USD 25M) を超えた場合はアップグレードが必須。
//
// 使用例:
//   const yaml = serializeToUnityScene({ sceneName: "Main", cameras: [...], ... });
//   fs.writeFileSync("Assets/Scenes/Main.unity", yaml);
//   fs.writeFileSync("Assets/Scenes/Main.unity.meta", generateMetaFile(guid, "Scene"));
// =============================================================================

/**
 * Unity シーンの完全な仕様オブジェクト。
 * シリアライザはこの構造から有効な .unity YAML を生成する。
 */
export interface UnitySceneSpec {
  /** シーン名 (ファイル名に使用) */
  sceneName: string;
  /** カメラ配列。最低 1 つは必要 (MainCamera タグ推奨) */
  cameras: Array<{
    name: string;
    position: [number, number, number];
    rotation: [number, number, number]; // オイラー角 (度)
    fov: number; // 視野角 (度、通常 60)
    isMain?: boolean; // true なら MainCamera タグ付与
    clearFlags?: 'Skybox' | 'SolidColor' | 'DepthOnly' | 'NothingClear';
    backgroundColor?: { r: number; g: number; b: number; a: number };
  }>;
  /** ライト配列 */
  lights: Array<{
    name: string;
    type: 'directional' | 'point' | 'spot' | 'area';
    position: [number, number, number];
    rotation?: [number, number, number];
    intensity: number;
    color: string; // hex "#FFFFFF" または "RGBA(1,1,1,1)"
    range?: number; // point/spot のみ
    spotAngle?: number; // spot のみ (度)
    castShadows?: 'None' | 'Soft' | 'Hard';
  }>;
  /** ヒエラルキー直下に配置する GameObject */
  gameObjects: Array<UnityGameObjectSpec>;
  /** スカイボックス設定 (任意) */
  skybox?: {
    type: 'cubemap' | 'procedural';
    assetGuid: string;
  };
  /** Post-Processing 設定 (URP 想定) */
  postProcessing?: {
    bloom: boolean;
    ambientOcclusion: boolean;
    toneMapping: 'aces' | 'neutral' | 'off';
    vignette?: boolean;
    chromaticAberration?: boolean;
  };
  /** Render Settings (Ambient/Fog 等) */
  renderSettings?: {
    fog?: boolean;
    fogColor?: string;
    fogDensity?: number;
    ambientMode?: 'Skybox' | 'Trilight' | 'Flat';
    ambientIntensity?: number;
  };
}

/**
 * Unity GameObject 仕様 (再帰構造)。
 */
export interface UnityGameObjectSpec {
  name: string;
  tag?: string;
  layer?: number; // 0-31
  active?: boolean; // デフォルト true
  /** Transform は必ず存在するため自動付与。それ以外を components に列挙 */
  transform?: {
    position: [number, number, number];
    rotation: [number, number, number];
    scale: [number, number, number];
  };
  components: Array<{
    type: string; // 'MeshRenderer' / 'BoxCollider' / 'Rigidbody' / 'MonoBehaviour' 等
    props: Record<string, unknown>;
  }>;
  children?: UnityGameObjectSpec[];
}

// =============================================================================
// 内部ユーティリティ
// =============================================================================

/**
 * Unity の fileID を決定的に生成する。
 * 完全な実装は内部 hash アルゴリズムだが、ここでは sceneName + path から
 * 64bit 範囲のハッシュ値を擬似生成する。
 */
function generateFileID(seed: string, salt: number): bigint {
  let hash = BigInt(0);
  const combined = `${seed}::${salt}`;
  for (let i = 0; i < combined.length; i++) {
    // FNV-1a 64bit 風
    hash = (hash ^ BigInt(combined.charCodeAt(i))) * BigInt(1099511628211);
    hash = hash & BigInt('0xFFFFFFFFFFFFFFFF'); // 64bit にクランプ
  }
  // fileID は正の整数 (Unity の慣例で 11 桁以上)
  return hash & BigInt('0x7FFFFFFFFFFFFFFF');
}

/**
 * Unity YAML 用にハッシュ文字列 (32 桁 hex) を生成する。
 * GUID は asset 単位で一意であれば良いため、seed + ランダムで十分。
 */
export function generateGuid(seed?: string): string {
  const base = seed ?? `${Date.now()}_${Math.random()}`;
  let hash = '';
  let s = base;
  while (hash.length < 32) {
    let h = 0;
    for (let i = 0; i < s.length; i++) {
      h = ((h << 5) - h + s.charCodeAt(i)) | 0;
    }
    hash += Math.abs(h).toString(16).padStart(8, '0');
    s = hash + s;
  }
  return hash.substring(0, 32);
}

/**
 * 色文字列 "#RRGGBB" または "#RRGGBBAA" を {r,g,b,a} (0-1) に正規化。
 */
function parseColor(input: string): { r: number; g: number; b: number; a: number } {
  if (input.startsWith('#')) {
    const hex = input.substring(1);
    const r = parseInt(hex.substring(0, 2), 16) / 255;
    const g = parseInt(hex.substring(2, 4), 16) / 255;
    const b = parseInt(hex.substring(4, 6), 16) / 255;
    const a = hex.length >= 8 ? parseInt(hex.substring(6, 8), 16) / 255 : 1;
    return { r, g, b, a };
  }
  return { r: 1, g: 1, b: 1, a: 1 };
}

/**
 * Vector3 / Quaternion を Unity YAML 形式 ("{x: 0, y: 0, z: 0}") に整形。
 */
function vec3(v: [number, number, number]): string {
  return `{x: ${v[0]}, y: ${v[1]}, z: ${v[2]}}`;
}

function color(c: { r: number; g: number; b: number; a: number }): string {
  return `{r: ${c.r}, g: ${c.g}, b: ${c.b}, a: ${c.a}}`;
}

/**
 * オイラー角 (度) を Unity Quaternion (x,y,z,w) に変換。
 * Unity の rotation は YAML 上 Quaternion で保存される。
 */
function eulerToQuaternion(eulerDeg: [number, number, number]): { x: number; y: number; z: number; w: number } {
  const [pitch, yaw, roll] = eulerDeg.map((d) => (d * Math.PI) / 180);
  const cy = Math.cos(yaw * 0.5);
  const sy = Math.sin(yaw * 0.5);
  const cp = Math.cos(pitch * 0.5);
  const sp = Math.sin(pitch * 0.5);
  const cr = Math.cos(roll * 0.5);
  const sr = Math.sin(roll * 0.5);
  return {
    w: cr * cp * cy + sr * sp * sy,
    x: sr * cp * cy - cr * sp * sy,
    y: cr * sp * cy + sr * cp * sy,
    z: cr * cp * sy - sr * sp * cy,
  };
}

function quat(q: { x: number; y: number; z: number; w: number }): string {
  return `{x: ${q.x}, y: ${q.y}, z: ${q.z}, w: ${q.w}}`;
}

// =============================================================================
// メインシリアライザ
// =============================================================================

/**
 * UnitySceneSpec から Unity YAML (.unity ファイル内容) を生成する。
 *
 * 注意:
 *   - 生成された YAML はエディタで開くことを想定しているが、完全な
 *     Unity-Native YAML ではない簡略形 (実用上問題ないレベル)。
 *   - 商用フルプロダクションでは Unity の Asset Database を経由した
 *     正規生成 (AssetDatabase.CreateAsset) を推奨。
 */
export function serializeToUnityScene(spec: UnitySceneSpec): string {
  const lines: string[] = [];
  lines.push('%YAML 1.1');
  lines.push('%TAG !u! tag:unity3d.com,2011:');
  lines.push('--- !u!29 &1');
  lines.push('OcclusionCullingSettings:');
  lines.push('  m_ObjectHideFlags: 0');
  lines.push('  serializedVersion: 2');
  lines.push('  m_OcclusionBakeSettings:');
  lines.push('    smallestOccluder: 5');
  lines.push('    smallestHole: 0.25');
  lines.push('    backfaceThreshold: 100');
  lines.push('  m_SceneGUID: 00000000000000000000000000000000');
  lines.push('  m_OcclusionCullingData: {fileID: 0}');

  // RenderSettings
  lines.push('--- !u!104 &2');
  lines.push('RenderSettings:');
  lines.push('  m_ObjectHideFlags: 0');
  lines.push('  serializedVersion: 9');
  lines.push(`  m_Fog: ${spec.renderSettings?.fog ? 1 : 0}`);
  const fogColor = parseColor(spec.renderSettings?.fogColor ?? '#7F7F7FFF');
  lines.push(`  m_FogColor: ${color(fogColor)}`);
  lines.push('  m_FogMode: 3');
  lines.push(`  m_FogDensity: ${spec.renderSettings?.fogDensity ?? 0.01}`);
  lines.push('  m_LinearFogStart: 0');
  lines.push('  m_LinearFogEnd: 300');
  lines.push('  m_AmbientSkyColor: {r: 0.212, g: 0.227, b: 0.259, a: 1}');
  lines.push(`  m_AmbientMode: ${spec.renderSettings?.ambientMode === 'Trilight' ? 1 : spec.renderSettings?.ambientMode === 'Flat' ? 3 : 0}`);
  lines.push(`  m_AmbientIntensity: ${spec.renderSettings?.ambientIntensity ?? 1}`);
  if (spec.skybox) {
    lines.push(`  m_SkyboxMaterial: {fileID: 10304, guid: ${spec.skybox.assetGuid}, type: 0}`);
  }

  // LightmapSettings (簡略)
  lines.push('--- !u!157 &3');
  lines.push('LightmapSettings:');
  lines.push('  m_ObjectHideFlags: 0');
  lines.push('  serializedVersion: 12');
  lines.push('  m_GIWorkflowMode: 1');

  // NavMeshSettings
  lines.push('--- !u!196 &4');
  lines.push('NavMeshSettings:');
  lines.push('  serializedVersion: 2');
  lines.push('  m_ObjectHideFlags: 0');
  lines.push('  m_BuildSettings:');
  lines.push('    serializedVersion: 3');
  lines.push('    agentTypeID: 0');
  lines.push('    agentRadius: 0.5');
  lines.push('    agentHeight: 2');
  lines.push('    agentSlope: 45');
  lines.push('    agentClimb: 0.4');

  let fileIdCounter = 100;
  const nextFileId = (key: string): bigint => {
    fileIdCounter++;
    return generateFileID(`${spec.sceneName}::${key}`, fileIdCounter);
  };

  // カメラを GameObject として直列化
  for (const cam of spec.cameras) {
    const goId = nextFileId(`camera_go_${cam.name}`);
    const trId = nextFileId(`camera_tr_${cam.name}`);
    const camId = nextFileId(`camera_cam_${cam.name}`);
    lines.push(`--- !u!1 &${goId}`);
    lines.push('GameObject:');
    lines.push('  m_ObjectHideFlags: 0');
    lines.push('  serializedVersion: 6');
    lines.push(`  m_Name: ${cam.name}`);
    lines.push(`  m_TagString: ${cam.isMain ? 'MainCamera' : 'Untagged'}`);
    lines.push('  m_IsActive: 1');
    lines.push('  m_Component:');
    lines.push(`  - component: {fileID: ${trId}}`);
    lines.push(`  - component: {fileID: ${camId}}`);

    lines.push(`--- !u!4 &${trId}`);
    lines.push('Transform:');
    lines.push('  m_ObjectHideFlags: 0');
    lines.push(`  m_GameObject: {fileID: ${goId}}`);
    lines.push(`  m_LocalPosition: ${vec3(cam.position)}`);
    lines.push(`  m_LocalRotation: ${quat(eulerToQuaternion(cam.rotation))}`);
    lines.push('  m_LocalScale: {x: 1, y: 1, z: 1}');

    lines.push(`--- !u!20 &${camId}`);
    lines.push('Camera:');
    lines.push('  m_ObjectHideFlags: 0');
    lines.push(`  m_GameObject: {fileID: ${goId}}`);
    lines.push('  m_Enabled: 1');
    lines.push('  serializedVersion: 2');
    const clearFlagsMap: Record<string, number> = { Skybox: 1, SolidColor: 2, DepthOnly: 3, NothingClear: 4 };
    lines.push(`  m_ClearFlags: ${clearFlagsMap[cam.clearFlags ?? 'Skybox']}`);
    const bg = cam.backgroundColor ?? { r: 0.192, g: 0.302, b: 0.475, a: 1 };
    lines.push(`  m_BackGroundColor: ${color(bg)}`);
    lines.push(`  field of view: ${cam.fov}`);
    lines.push('  near clip plane: 0.3');
    lines.push('  far clip plane: 1000');
    lines.push('  orthographic: 0');
  }

  // ライト
  for (const light of spec.lights) {
    const goId = nextFileId(`light_go_${light.name}`);
    const trId = nextFileId(`light_tr_${light.name}`);
    const lightId = nextFileId(`light_l_${light.name}`);
    lines.push(`--- !u!1 &${goId}`);
    lines.push('GameObject:');
    lines.push('  m_ObjectHideFlags: 0');
    lines.push('  serializedVersion: 6');
    lines.push(`  m_Name: ${light.name}`);
    lines.push('  m_TagString: Untagged');
    lines.push('  m_IsActive: 1');
    lines.push('  m_Component:');
    lines.push(`  - component: {fileID: ${trId}}`);
    lines.push(`  - component: {fileID: ${lightId}}`);

    lines.push(`--- !u!4 &${trId}`);
    lines.push('Transform:');
    lines.push(`  m_GameObject: {fileID: ${goId}}`);
    lines.push(`  m_LocalPosition: ${vec3(light.position)}`);
    lines.push(`  m_LocalRotation: ${quat(eulerToQuaternion(light.rotation ?? [50, -30, 0]))}`);
    lines.push('  m_LocalScale: {x: 1, y: 1, z: 1}');

    const lightTypeMap: Record<string, number> = { spot: 0, directional: 1, point: 2, area: 3 };
    const shadowMap: Record<string, number> = { None: 0, Hard: 1, Soft: 2 };
    lines.push(`--- !u!108 &${lightId}`);
    lines.push('Light:');
    lines.push(`  m_GameObject: {fileID: ${goId}}`);
    lines.push('  m_Enabled: 1');
    lines.push('  serializedVersion: 10');
    lines.push(`  m_Type: ${lightTypeMap[light.type]}`);
    lines.push(`  m_Color: ${color(parseColor(light.color))}`);
    lines.push(`  m_Intensity: ${light.intensity}`);
    lines.push(`  m_Range: ${light.range ?? 10}`);
    lines.push(`  m_SpotAngle: ${light.spotAngle ?? 30}`);
    lines.push(`  m_Shadows.m_Type: ${shadowMap[light.castShadows ?? 'Soft']}`);
  }

  // GameObjects (再帰)
  const emitGameObject = (go: UnityGameObjectSpec, parentTrId: bigint | null): bigint => {
    const goId = nextFileId(`go_${go.name}`);
    const trId = nextFileId(`tr_${go.name}`);

    const componentIds: bigint[] = [trId];
    const componentEmits: string[] = [];

    // Transform は必須
    const t = go.transform ?? {
      position: [0, 0, 0] as [number, number, number],
      rotation: [0, 0, 0] as [number, number, number],
      scale: [1, 1, 1] as [number, number, number],
    };
    componentEmits.push(`--- !u!4 &${trId}`);
    componentEmits.push('Transform:');
    componentEmits.push(`  m_GameObject: {fileID: ${goId}}`);
    componentEmits.push(`  m_LocalPosition: ${vec3(t.position)}`);
    componentEmits.push(`  m_LocalRotation: ${quat(eulerToQuaternion(t.rotation))}`);
    componentEmits.push(`  m_LocalScale: ${vec3(t.scale)}`);
    if (parentTrId !== null) {
      componentEmits.push(`  m_Father: {fileID: ${parentTrId}}`);
    }

    // その他コンポーネント
    const compTypeMap: Record<string, number> = {
      MeshFilter: 33,
      MeshRenderer: 23,
      BoxCollider: 65,
      SphereCollider: 135,
      CapsuleCollider: 136,
      Rigidbody: 54,
      AudioSource: 82,
      MonoBehaviour: 114,
    };

    for (const comp of go.components) {
      const cid = nextFileId(`${go.name}_${comp.type}`);
      componentIds.push(cid);
      const numericType = compTypeMap[comp.type] ?? 114;
      componentEmits.push(`--- !u!${numericType} &${cid}`);
      componentEmits.push(`${comp.type}:`);
      componentEmits.push(`  m_GameObject: {fileID: ${goId}}`);
      componentEmits.push('  m_Enabled: 1');
      for (const [k, v] of Object.entries(comp.props)) {
        componentEmits.push(`  ${k}: ${JSON.stringify(v)}`);
      }
    }

    // GameObject ヘッダ
    lines.push(`--- !u!1 &${goId}`);
    lines.push('GameObject:');
    lines.push('  m_ObjectHideFlags: 0');
    lines.push('  serializedVersion: 6');
    lines.push(`  m_Name: ${go.name}`);
    lines.push(`  m_TagString: ${go.tag ?? 'Untagged'}`);
    lines.push(`  m_Layer: ${go.layer ?? 0}`);
    lines.push(`  m_IsActive: ${go.active === false ? 0 : 1}`);
    lines.push('  m_Component:');
    for (const cid of componentIds) {
      lines.push(`  - component: {fileID: ${cid}}`);
    }
    lines.push(...componentEmits);

    // 子を再帰生成
    if (go.children) {
      for (const child of go.children) {
        emitGameObject(child, trId);
      }
    }
    return trId;
  };

  for (const go of spec.gameObjects) {
    emitGameObject(go, null);
  }

  return lines.join('\n') + '\n';
}

/**
 * .meta ファイル (各 Asset に対応する Unity の GUID 管理ファイル) を生成。
 * Unity は Asset Path ではなく GUID で参照を解決するため、必ず必要。
 */
export function generateMetaFile(assetGuid: string, assetType: string): string {
  // assetType は 'Scene' / 'Texture' / 'Material' / 'Prefab' / 'Script' 等
  const typeImporterMap: Record<string, string> = {
    Scene: 'DefaultImporter',
    Texture: 'TextureImporter',
    Material: 'NativeFormatImporter',
    Prefab: 'PrefabImporter',
    Script: 'MonoImporter',
    Model: 'ModelImporter',
    AudioClip: 'AudioImporter',
    ShaderGraph: 'ScriptedImporter',
    Animation: 'NativeFormatImporter',
  };
  const importer = typeImporterMap[assetType] ?? 'DefaultImporter';
  const lines: string[] = [];
  lines.push('fileFormatVersion: 2');
  lines.push(`guid: ${assetGuid}`);
  lines.push(`${importer}:`);
  lines.push('  externalObjects: {}');
  lines.push('  userData: ');
  lines.push('  assetBundleName: ');
  lines.push('  assetBundleVariant: ');
  return lines.join('\n') + '\n';
}
