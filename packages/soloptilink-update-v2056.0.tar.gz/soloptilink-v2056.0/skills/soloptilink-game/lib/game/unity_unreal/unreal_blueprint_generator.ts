// =============================================================================
// SoloptiLinkAI v2.0 Game Production Engine - Unreal Blueprint Generator
// =============================================================================
// 責務:
//   Unreal Engine 5 用の C++ ヘッダ (.h) / ソース (.cpp) を自動生成する。
//   UCLASS / UPROPERTY / UFUNCTION マクロを正しく付与し、エンジンの
//   リフレクションシステム (UnrealHeaderTool) に認識される構文で出力する。
//
//   Blueprint Asset 自体はバイナリ (.uasset) で生成不可だが、C++ で
//   親クラスを定義すれば Blueprint からの継承 + Override は完全に可能。
//
// ライセンス警告:
//   Unreal Engine 5 は売上 USD 1,000,000 (年100万ドル) 未満まで無料。
//   それを超えると 5% ロイヤリティが発生する。Epic Games Store 経由販売は
//   減免あり。https://www.unrealengine.com/eula を必ず最新確認すること。
//
// 使用例:
//   const header = generateUnrealHeader({ className: "AMyPawn", parentClass: "APawn", ... });
//   const cpp = generateUnrealCpp({ className: "AMyPawn", parentClass: "APawn", ... });
//   fs.writeFileSync("Source/MyGame/Public/MyPawn.h", header);
//   fs.writeFileSync("Source/MyGame/Private/MyPawn.cpp", cpp);
// =============================================================================

/**
 * Unreal クラスの完全な仕様。
 */
export interface UnrealClassSpec {
  /** クラス名 ('A' / 'U' / 'F' プレフィックス必須) */
  className: string;
  /** 親クラス (UE 規約に従ったプレフィックス付き) */
  parentClass:
    | 'AActor'
    | 'APawn'
    | 'ACharacter'
    | 'AGameModeBase'
    | 'AGameStateBase'
    | 'APlayerController'
    | 'APlayerState'
    | 'AHUD'
    | 'AController'
    | 'AAIController'
    | 'AStaticMeshActor'
    | 'UUserWidget'
    | 'UActorComponent'
    | 'USceneComponent'
    | 'UPrimitiveComponent'
    | 'UObject'
    | 'UInterface'
    | string;
  /** Blueprint からの継承を許可するか */
  isBlueprint: boolean;
  /** モジュール名 (Build.cs のモジュール名) */
  moduleName?: string;
  /** API マクロ (例: 'MYGAME_API') */
  apiMacro?: string;
  /** クラス自体への UCLASS 属性 (例: 'Blueprintable, BlueprintType') */
  uclassSpecifiers?: string[];
  /** XML 風ドキュメンテーション (Unreal の Doxygen 形式コメント) */
  documentation?: string;
  /** UPROPERTY (フィールド) */
  uproperties: Array<UnrealPropertySpec>;
  /** UFUNCTION (メソッド) */
  ufunctions: Array<UnrealFunctionSpec>;
  /** インクルードする追加ヘッダ */
  additionalIncludes?: string[];
}

export interface UnrealPropertySpec {
  name: string;
  type: string; // 'int32' / 'float' / 'FString' / 'TArray<int32>' / 'UStaticMeshComponent*' 等
  category?: string; // インスペクタのグループ名
  /** Editor で編集可能か */
  editAnywhere?: boolean;
  editDefaultsOnly?: boolean;
  editInstanceOnly?: boolean;
  /** Blueprint からの読み書き */
  blueprintReadWrite?: boolean;
  blueprintReadOnly?: boolean;
  /** デフォルト値 */
  defaultValue?: string;
  /** ネットワーク同期 */
  replicated?: boolean;
  /** Transient (シリアライズ対象外) */
  transient?: boolean;
  /** ToolTip テキスト (日本語/英語) */
  tooltip?: string;
  /** ClampMin/ClampMax */
  clamp?: { min: number; max: number };
  /** アクセス修飾子 (省略時 protected) */
  access?: 'public' | 'private' | 'protected';
}

export interface UnrealFunctionSpec {
  name: string;
  returnType: string; // 'void' / 'int32' / 'FString' / 'bool' 等
  parameters: Array<{ name: string; type: string; defaultValue?: string }>;
  /** Blueprint から呼び出し可能か */
  blueprintCallable?: boolean;
  /** Blueprint でオーバーライド可能か */
  blueprintImplementableEvent?: boolean;
  blueprintNativeEvent?: boolean;
  /** Blueprint で純粋関数として扱う */
  blueprintPure?: boolean;
  /** Server/Client/NetMulticast */
  netMode?: 'Server' | 'Client' | 'NetMulticast';
  /** Reliable RPC */
  reliable?: boolean;
  /** カテゴリ */
  category?: string;
  /** メソッド本体 (cpp 側に出力) */
  body: string;
  /** virtual / override */
  modifier?: 'virtual' | 'override' | 'virtual override' | 'static' | 'const';
  /** ドキュメンテーション */
  documentation?: string;
  /** アクセス修飾子 */
  access?: 'public' | 'private' | 'protected';
}

// =============================================================================
// 内部ユーティリティ
// =============================================================================

function buildUclassMacro(spec: UnrealClassSpec): string {
  const specs: string[] = [...(spec.uclassSpecifiers ?? [])];
  if (spec.isBlueprint) {
    if (!specs.includes('Blueprintable')) specs.push('Blueprintable');
    if (!specs.includes('BlueprintType')) specs.push('BlueprintType');
  }
  return specs.length > 0 ? `UCLASS(${specs.join(', ')})` : 'UCLASS()';
}

function buildUpropertyMacro(p: UnrealPropertySpec): string {
  const specs: string[] = [];
  if (p.editAnywhere) specs.push('EditAnywhere');
  if (p.editDefaultsOnly) specs.push('EditDefaultsOnly');
  if (p.editInstanceOnly) specs.push('EditInstanceOnly');
  if (p.blueprintReadWrite) specs.push('BlueprintReadWrite');
  if (p.blueprintReadOnly) specs.push('BlueprintReadOnly');
  if (p.replicated) specs.push('Replicated');
  if (p.transient) specs.push('Transient');
  if (p.category) specs.push(`Category = "${p.category}"`);
  const metaParts: string[] = [];
  if (p.tooltip) metaParts.push(`ToolTip="${p.tooltip.replace(/"/g, '\\"')}"`);
  if (p.clamp) {
    metaParts.push(`ClampMin="${p.clamp.min}"`);
    metaParts.push(`ClampMax="${p.clamp.max}"`);
    metaParts.push(`UIMin="${p.clamp.min}"`);
    metaParts.push(`UIMax="${p.clamp.max}"`);
  }
  if (metaParts.length > 0) {
    specs.push(`meta=(${metaParts.join(', ')})`);
  }
  return specs.length > 0 ? `UPROPERTY(${specs.join(', ')})` : 'UPROPERTY()';
}

function buildUfunctionMacro(f: UnrealFunctionSpec): string {
  const specs: string[] = [];
  if (f.blueprintCallable) specs.push('BlueprintCallable');
  if (f.blueprintImplementableEvent) specs.push('BlueprintImplementableEvent');
  if (f.blueprintNativeEvent) specs.push('BlueprintNativeEvent');
  if (f.blueprintPure) specs.push('BlueprintPure');
  if (f.category) specs.push(`Category = "${f.category}"`);
  if (f.netMode) {
    specs.push(f.netMode);
    if (f.reliable) specs.push('Reliable');
    else specs.push('Unreliable');
  }
  return specs.length > 0 ? `UFUNCTION(${specs.join(', ')})` : 'UFUNCTION()';
}

function groupByAccess<T extends { access?: 'public' | 'private' | 'protected' }>(items: T[]): {
  publicItems: T[];
  protectedItems: T[];
  privateItems: T[];
} {
  const out = { publicItems: [] as T[], protectedItems: [] as T[], privateItems: [] as T[] };
  for (const it of items) {
    const a = it.access ?? 'protected';
    if (a === 'public') out.publicItems.push(it);
    else if (a === 'private') out.privateItems.push(it);
    else out.protectedItems.push(it);
  }
  return out;
}

// =============================================================================
// メインジェネレータ
// =============================================================================

/**
 * UnrealClassSpec から .h ヘッダファイル内容を生成する。
 */
export function generateUnrealHeader(spec: UnrealClassSpec): string {
  // class 名から ベース名 (プレフィックス除去) を作成
  const baseName = spec.className.replace(/^[AUFE]/, '');
  const apiMacro = spec.apiMacro ?? `${(spec.moduleName ?? baseName).toUpperCase()}_API`;

  const lines: string[] = [];
  lines.push('// -----------------------------------------------------------------------------');
  lines.push(`// ${baseName}.h`);
  lines.push('// SoloptiLinkAI v2.0 Game Production Engine - Auto-Generated');
  lines.push('// ライセンス警告: UE5 は売上 USD 100 万超で 5% ロイヤリティが発生する。');
  lines.push('//   https://www.unrealengine.com/eula を必ず確認すること。');
  lines.push('// -----------------------------------------------------------------------------');
  lines.push('#pragma once');
  lines.push('');
  lines.push('#include "CoreMinimal.h"');

  // 親クラスから推測される追加ヘッダ
  const parentHeaderMap: Record<string, string> = {
    AActor: 'GameFramework/Actor.h',
    APawn: 'GameFramework/Pawn.h',
    ACharacter: 'GameFramework/Character.h',
    AGameModeBase: 'GameFramework/GameModeBase.h',
    AGameStateBase: 'GameFramework/GameStateBase.h',
    APlayerController: 'GameFramework/PlayerController.h',
    APlayerState: 'GameFramework/PlayerState.h',
    AHUD: 'GameFramework/HUD.h',
    AAIController: 'AIController.h',
    AStaticMeshActor: 'Engine/StaticMeshActor.h',
    UUserWidget: 'Blueprint/UserWidget.h',
    UActorComponent: 'Components/ActorComponent.h',
    USceneComponent: 'Components/SceneComponent.h',
    UObject: 'UObject/NoExportTypes.h',
  };
  const parentHeader = parentHeaderMap[spec.parentClass];
  if (parentHeader) lines.push(`#include "${parentHeader}"`);
  if (spec.additionalIncludes) {
    for (const h of spec.additionalIncludes) lines.push(`#include "${h}"`);
  }
  lines.push(`#include "${baseName}.generated.h"`);
  lines.push('');

  if (spec.documentation) {
    lines.push('/**');
    for (const docLine of spec.documentation.split('\n')) lines.push(` * ${docLine}`);
    lines.push(' */');
  }

  lines.push(buildUclassMacro(spec));
  lines.push(`class ${apiMacro} ${spec.className} : public ${spec.parentClass}`);
  lines.push('{');
  lines.push('    GENERATED_BODY()');
  lines.push('');

  // コンストラクタ
  lines.push('public:');
  lines.push(`    ${spec.className}();`);
  lines.push('');

  // セクション別に出力 (public -> protected -> private)
  const propGroups = groupByAccess(spec.uproperties);
  const funcGroups = groupByAccess(spec.ufunctions);

  const emitPropertyDecl = (p: UnrealPropertySpec): string[] => {
    const macro = buildUpropertyMacro(p);
    const defaultStr = p.defaultValue !== undefined ? ` = ${p.defaultValue}` : '';
    return [`    ${macro}`, `    ${p.type} ${p.name}${defaultStr};`, ''];
  };

  const emitFunctionDecl = (f: UnrealFunctionSpec): string[] => {
    const out: string[] = [];
    if (f.documentation) {
      out.push('    /**');
      for (const docLine of f.documentation.split('\n')) out.push(`     * ${docLine}`);
      out.push('     */');
    }
    // UFUNCTION が必要ならマクロ追加
    const needsUfunction =
      f.blueprintCallable ||
      f.blueprintImplementableEvent ||
      f.blueprintNativeEvent ||
      f.blueprintPure ||
      f.netMode;
    if (needsUfunction) out.push(`    ${buildUfunctionMacro(f)}`);
    const params = f.parameters
      .map((p) => `${p.type} ${p.name}${p.defaultValue !== undefined ? ` = ${p.defaultValue}` : ''}`)
      .join(', ');
    const constSuffix = f.modifier === 'const' ? ' const' : '';
    const virtualPrefix = f.modifier === 'virtual' || f.modifier === 'virtual override' ? 'virtual ' : '';
    const overrideSuffix = f.modifier === 'override' || f.modifier === 'virtual override' ? ' override' : '';
    const staticPrefix = f.modifier === 'static' ? 'static ' : '';
    out.push(`    ${virtualPrefix}${staticPrefix}${f.returnType} ${f.name}(${params})${constSuffix}${overrideSuffix};`);
    out.push('');
    return out;
  };

  if (propGroups.publicItems.length > 0 || funcGroups.publicItems.length > 0) {
    for (const p of propGroups.publicItems) lines.push(...emitPropertyDecl(p));
    for (const f of funcGroups.publicItems) lines.push(...emitFunctionDecl(f));
  }

  if (propGroups.protectedItems.length > 0 || funcGroups.protectedItems.length > 0) {
    lines.push('protected:');
    for (const p of propGroups.protectedItems) lines.push(...emitPropertyDecl(p));
    for (const f of funcGroups.protectedItems) lines.push(...emitFunctionDecl(f));
  }

  if (propGroups.privateItems.length > 0 || funcGroups.privateItems.length > 0) {
    lines.push('private:');
    for (const p of propGroups.privateItems) lines.push(...emitPropertyDecl(p));
    for (const f of funcGroups.privateItems) lines.push(...emitFunctionDecl(f));
  }

  // ライフサイクルの virtual override 宣言 (BeginPlay / Tick)
  const hasOverride = (name: string): boolean =>
    spec.ufunctions.some((f) => f.name === name && (f.modifier?.includes('override') ?? false));
  if (!hasOverride('BeginPlay') && spec.parentClass !== 'UObject') {
    lines.push('protected:');
    lines.push('    virtual void BeginPlay() override;');
    lines.push('');
  }

  lines.push('};');
  return lines.join('\n');
}

/**
 * UnrealClassSpec から .cpp 実装ファイル内容を生成する。
 */
export function generateUnrealCpp(spec: UnrealClassSpec): string {
  const baseName = spec.className.replace(/^[AUFE]/, '');
  const lines: string[] = [];
  lines.push('// -----------------------------------------------------------------------------');
  lines.push(`// ${baseName}.cpp`);
  lines.push('// SoloptiLinkAI v2.0 Game Production Engine - Auto-Generated');
  lines.push('// -----------------------------------------------------------------------------');
  lines.push(`#include "${baseName}.h"`);
  lines.push('#include "Engine/World.h"');
  lines.push('#include "Kismet/GameplayStatics.h"');
  if (spec.additionalIncludes) {
    for (const h of spec.additionalIncludes) lines.push(`#include "${h}"`);
  }
  lines.push('');

  // コンストラクタ
  lines.push(`${spec.className}::${spec.className}()`);
  lines.push('{');
  // APawn/ACharacter なら Tick 有効化が一般的
  if (spec.parentClass === 'APawn' || spec.parentClass === 'ACharacter' || spec.parentClass === 'AActor') {
    lines.push('    PrimaryActorTick.bCanEverTick = true;');
  }
  // デフォルト値の初期化
  for (const p of spec.uproperties) {
    if (p.defaultValue !== undefined && !['int32', 'float', 'bool', 'double'].some((t) => p.type === t)) {
      // 複雑型はコンストラクタで設定
    }
  }
  lines.push('}');
  lines.push('');

  // BeginPlay (override がなければ既定実装)
  const hasOverride = (name: string): boolean =>
    spec.ufunctions.some((f) => f.name === name && (f.modifier?.includes('override') ?? false));
  if (!hasOverride('BeginPlay') && spec.parentClass !== 'UObject') {
    lines.push(`void ${spec.className}::BeginPlay()`);
    lines.push('{');
    lines.push('    Super::BeginPlay();');
    lines.push(`    UE_LOG(LogTemp, Log, TEXT("[${spec.className}] BeginPlay"));`);
    lines.push('}');
    lines.push('');
  }

  // 各 UFUNCTION の本体
  for (const f of spec.ufunctions) {
    const params = f.parameters
      .map((p) => `${p.type} ${p.name}`)
      .join(', ');
    const constSuffix = f.modifier === 'const' ? ' const' : '';
    lines.push(`${f.returnType} ${spec.className}::${f.name}(${params})${constSuffix}`);
    lines.push('{');
    // override の場合は Super 呼び出し提案
    if (f.modifier === 'override' || f.modifier === 'virtual override') {
      const superCallable = ['BeginPlay', 'Tick', 'EndPlay', 'SetupPlayerInputComponent'].includes(f.name);
      if (superCallable) {
        const args = f.parameters.map((p) => p.name).join(', ');
        lines.push(`    Super::${f.name}(${args});`);
      }
    }
    for (const bodyLine of f.body.split('\n')) {
      lines.push(`    ${bodyLine}`);
    }
    lines.push('}');
    lines.push('');
  }

  return lines.join('\n');
}
