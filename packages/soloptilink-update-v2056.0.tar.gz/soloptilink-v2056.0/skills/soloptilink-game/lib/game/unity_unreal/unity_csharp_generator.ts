// =============================================================================
// SoloptiLinkAI v2.0 Game Production Engine - Unity C# Generator
// =============================================================================
// 責務:
//   Unity 用の C# スクリプトを自動生成する。
//   MonoBehaviour / ScriptableObject / NetworkBehaviour 等の継承クラス、
//   フィールド (SerializeField + Tooltip 含む)、Unity ライフサイクル
//   コールバック (Awake/Start/Update 等) を構文的に valid な形で出力する。
//
//   PlayerController / EnemyAI など、ジャンル横断で再利用されるパターンの
//   テンプレ生成も提供 (3D/2D/物理ベース/FPS/TPS 切替対応)。
//
// ライセンス警告:
//   Unity 6 LTS 利用規約 (https://unity.com/legal/editor-terms-of-service)
//   を必ず確認すること。Personal は売上 USD 200K 未満限定、Pro 以上は
//   別途サブスク契約が必要。本ジェネレータが生成するコードは MIT 互換だが、
//   Unity Engine 自体への依存は Unity ライセンスに従う。
//
// 使用例:
//   const code = generateCSharpClass({
//     className: "EnemyShooter", baseClass: "MonoBehaviour",
//     fields: [{ name: "damage", type: "int", serializeField: true, defaultValue: "10" }],
//     methods: [...], unityCallbacks: ["Awake", "Update"]
//   });
//   fs.writeFileSync("Assets/Scripts/EnemyShooter.cs", code);
// =============================================================================

/**
 * C# クラスの完全な仕様。
 */
export interface CSharpClassSpec {
  /** クラス名 (PascalCase 推奨) */
  className: string;
  /** 継承元 (省略時 'MonoBehaviour') */
  baseClass?: string;
  /** 名前空間 (省略時はグローバル) */
  namespaceName?: string;
  /** using 文 (基本セットは自動で含まれる) */
  additionalUsings?: string[];
  /** クラス自体の修飾子 ('public' / 'public sealed' / 'public abstract' 等) */
  classModifiers?: string;
  /** XML ドキュメンテーション (// /// 形式) */
  documentation?: string;
  /** インターフェース実装 */
  implements?: string[];
  /** フィールド定義 */
  fields: Array<CSharpFieldSpec>;
  /** メソッド定義 */
  methods: Array<CSharpMethodSpec>;
  /** Unity ライフサイクルコールバック (本体は空 or 簡易ログ) */
  unityCallbacks?: Array<
    | 'Awake'
    | 'Start'
    | 'OnEnable'
    | 'Update'
    | 'FixedUpdate'
    | 'LateUpdate'
    | 'OnDisable'
    | 'OnDestroy'
    | 'OnCollisionEnter'
    | 'OnCollisionExit'
    | 'OnTriggerEnter'
    | 'OnTriggerExit'
    | 'OnGUI'
    | 'OnDrawGizmos'
  >;
  /** [RequireComponent(typeof(X))] 属性 */
  requireComponents?: string[];
}

export interface CSharpFieldSpec {
  name: string;
  type: string;
  /** [SerializeField] を付けるか (private でも Inspector に出る) */
  serializeField?: boolean;
  /** デフォルト値 (= "100" や = "new List<int>()") */
  defaultValue?: string;
  /** [Tooltip("...")] 属性のテキスト */
  tooltip?: string;
  /** [Header("...")] 属性のテキスト */
  header?: string;
  /** [Range(min, max)] 属性 (数値型のみ) */
  range?: { min: number; max: number };
  /** アクセス修飾子 (省略時 private) */
  access?: 'public' | 'private' | 'protected' | 'internal';
  /** readonly / const */
  readonly?: boolean;
  /** static 修飾子 */
  isStatic?: boolean;
}

export interface CSharpMethodSpec {
  name: string;
  returnType: string;
  parameters: Array<{ name: string; type: string; defaultValue?: string }>;
  /** メソッド本体 (中括弧の中身、改行込み) */
  body: string;
  /** アクセス修飾子 (省略時 public) */
  access?: 'public' | 'private' | 'protected' | 'internal';
  /** override / virtual / abstract / static */
  modifier?: 'override' | 'virtual' | 'abstract' | 'static' | 'sealed override';
  /** XML ドキュメンテーション */
  documentation?: string;
  /** 属性 ([ContextMenu("...")] 等) */
  attributes?: string[];
}

// =============================================================================
// 内部ユーティリティ
// =============================================================================

function indent(str: string, level: number): string {
  const pad = '    '.repeat(level);
  return str
    .split('\n')
    .map((l) => (l.length > 0 ? pad + l : l))
    .join('\n');
}

function emitField(f: CSharpFieldSpec): string {
  const lines: string[] = [];
  if (f.header) lines.push(`[Header("${f.header.replace(/"/g, '\\"')}")]`);
  if (f.tooltip) lines.push(`[Tooltip("${f.tooltip.replace(/"/g, '\\"')}")]`);
  if (f.range) lines.push(`[Range(${f.range.min}, ${f.range.max})]`);
  if (f.serializeField && (f.access ?? 'private') !== 'public') {
    lines.push('[SerializeField]');
  }
  const access = f.access ?? 'private';
  const staticMod = f.isStatic ? ' static' : '';
  const readonlyMod = f.readonly ? ' readonly' : '';
  const defaultPart = f.defaultValue !== undefined ? ` = ${f.defaultValue}` : '';
  lines.push(`${access}${staticMod}${readonlyMod} ${f.type} ${f.name}${defaultPart};`);
  return lines.join('\n');
}

function emitMethod(m: CSharpMethodSpec): string {
  const lines: string[] = [];
  if (m.documentation) {
    for (const docLine of m.documentation.split('\n')) {
      lines.push(`/// ${docLine}`);
    }
  }
  if (m.attributes) {
    for (const attr of m.attributes) {
      lines.push(attr.startsWith('[') ? attr : `[${attr}]`);
    }
  }
  const access = m.access ?? 'public';
  const modifier = m.modifier ? `${m.modifier} ` : '';
  const params = m.parameters
    .map((p) => `${p.type} ${p.name}${p.defaultValue !== undefined ? ` = ${p.defaultValue}` : ''}`)
    .join(', ');
  lines.push(`${access} ${modifier}${m.returnType} ${m.name}(${params})`);
  lines.push('{');
  lines.push(indent(m.body, 1));
  lines.push('}');
  return lines.join('\n');
}

function emitUnityCallback(name: string): CSharpMethodSpec {
  // Awake/Start 系は無引数 / 衝突系は引数あり
  const collisionPairs: Record<string, string> = {
    OnCollisionEnter: 'Collision collision',
    OnCollisionExit: 'Collision collision',
    OnTriggerEnter: 'Collider other',
    OnTriggerExit: 'Collider other',
  };
  const sig = collisionPairs[name] ?? '';
  const params = sig
    ? [{ name: sig.split(' ')[1], type: sig.split(' ')[0] }]
    : ([] as Array<{ name: string; type: string }>);
  return {
    name,
    returnType: 'void',
    access: 'private',
    parameters: params,
    // T-028: 顧客成果物へ未実装印を焼き込まない。既定は「意図した空実装」として納品する。
    body: `// ${name}: 既定では処理なし (意図した空実装)。必要に応じて処理を追加してください。`,
  };
}

// =============================================================================
// メインジェネレータ
// =============================================================================

/**
 * CSharpClassSpec から構文的に valid な Unity C# コードを生成する。
 */
export function generateCSharpClass(spec: CSharpClassSpec): string {
  const usings = new Set<string>([
    'System',
    'System.Collections',
    'System.Collections.Generic',
    'UnityEngine',
  ]);
  // baseClass から追加 using を推測
  const base = spec.baseClass ?? 'MonoBehaviour';
  if (base.includes('NetworkBehaviour')) usings.add('Unity.Netcode');
  if (base === 'ScriptableObject') usings.add('UnityEngine');
  if (spec.additionalUsings) {
    for (const u of spec.additionalUsings) usings.add(u);
  }
  // フィールド型から追加 using を推測
  for (const f of spec.fields) {
    if (f.type.includes('UnityEvent')) usings.add('UnityEngine.Events');
    if (f.type.includes('InputAction')) usings.add('UnityEngine.InputSystem');
    if (f.type.includes('NavMeshAgent')) usings.add('UnityEngine.AI');
    if (f.type.includes('Image') || f.type.includes('Slider') || f.type.includes('Text')) {
      usings.add('UnityEngine.UI');
    }
    if (f.type.includes('TMP_') || f.type.includes('TextMeshPro')) usings.add('TMPro');
  }

  const lines: string[] = [];
  lines.push('// -----------------------------------------------------------------------------');
  lines.push(`// ${spec.className}.cs`);
  lines.push('// SoloptiLinkAI v2.0 Game Production Engine - Auto-Generated');
  lines.push('// 注意: Unity 6 LTS 利用規約 (https://unity.com/legal/editor-terms-of-service)');
  lines.push('//       を確認すること。Pro 以上は売上 USD 200K 超で必須。');
  lines.push('// -----------------------------------------------------------------------------');

  for (const u of usings) lines.push(`using ${u};`);
  lines.push('');

  const namespaceDepth = spec.namespaceName ? 1 : 0;
  if (spec.namespaceName) {
    lines.push(`namespace ${spec.namespaceName}`);
    lines.push('{');
  }

  // XML ドキュメンテーション
  if (spec.documentation) {
    for (const docLine of spec.documentation.split('\n')) {
      lines.push(indent(`/// ${docLine}`, namespaceDepth));
    }
  }

  // [RequireComponent]
  if (spec.requireComponents) {
    for (const rc of spec.requireComponents) {
      lines.push(indent(`[RequireComponent(typeof(${rc}))]`, namespaceDepth));
    }
  }

  const mods = spec.classModifiers ?? 'public';
  const inherits: string[] = [];
  inherits.push(base);
  if (spec.implements) inherits.push(...spec.implements);
  const inheritStr = inherits.length > 0 ? ` : ${inherits.join(', ')}` : '';
  lines.push(indent(`${mods} class ${spec.className}${inheritStr}`, namespaceDepth));
  lines.push(indent('{', namespaceDepth));

  // フィールド
  for (const f of spec.fields) {
    lines.push(indent(emitField(f), namespaceDepth + 1));
    lines.push('');
  }

  // Unity ライフサイクルコールバック
  if (spec.unityCallbacks) {
    for (const cb of spec.unityCallbacks) {
      lines.push(indent(emitMethod(emitUnityCallback(cb)), namespaceDepth + 1));
      lines.push('');
    }
  }

  // 任意メソッド
  for (const m of spec.methods) {
    lines.push(indent(emitMethod(m), namespaceDepth + 1));
    lines.push('');
  }

  lines.push(indent('}', namespaceDepth));
  if (spec.namespaceName) lines.push('}');
  return lines.join('\n');
}

// =============================================================================
// テンプレ生成
// =============================================================================

/**
 * PlayerController スクリプトのテンプレ生成。
 * 3D/2D、物理ベース/CharacterController、FPS/TPS の組み合わせを切替。
 */
export function generatePlayerControllerScript(opts: {
  use3D: boolean;
  physicsBased: boolean;
  firstPerson: boolean;
}): string {
  const baseClass = 'MonoBehaviour';
  const isFPS = opts.firstPerson;
  const movement = opts.use3D
    ? opts.physicsBased
      ? 'Rigidbody'
      : 'CharacterController'
    : 'Rigidbody2D';

  const fields: CSharpFieldSpec[] = [
    {
      name: 'moveSpeed',
      type: 'float',
      access: 'private',
      serializeField: true,
      defaultValue: '5f',
      header: '移動設定',
      tooltip: '基本移動速度 (units/sec)',
    },
    {
      name: 'jumpForce',
      type: 'float',
      access: 'private',
      serializeField: true,
      defaultValue: opts.use3D ? '7f' : '12f',
      tooltip: 'ジャンプ力',
    },
    {
      name: 'maxHealth',
      type: 'int',
      access: 'private',
      serializeField: true,
      defaultValue: '100',
      header: 'ヘルス',
      range: { min: 1, max: 9999 },
    },
    {
      name: 'currentHealth',
      type: 'int',
      access: 'private',
    },
    {
      name: 'mover',
      type: movement,
      access: 'private',
    },
  ];

  if (isFPS && opts.use3D) {
    fields.push({
      name: 'cameraPivot',
      type: 'Transform',
      access: 'private',
      serializeField: true,
      tooltip: '一人称視点のカメラ親 Transform',
    });
    fields.push({
      name: 'mouseSensitivity',
      type: 'float',
      access: 'private',
      serializeField: true,
      defaultValue: '2f',
      range: { min: 0.1, max: 10 },
    });
  }

  const methodBodyAwake = `currentHealth = maxHealth;\nmover = GetComponent<${movement}>();\nif (mover == null)\n{\n    Debug.LogError("[PlayerController] ${movement} が必要です");\n}\n${isFPS ? 'Cursor.lockState = CursorLockMode.Locked;' : ''}`;

  const moveBody = opts.use3D
    ? opts.physicsBased
      ? `// Rigidbody ベースの 3D 移動\nfloat h = Input.GetAxisRaw("Horizontal");\nfloat v = Input.GetAxisRaw("Vertical");\nVector3 input = transform.right * h + transform.forward * v;\nVector3 vel = mover.linearVelocity;\nvel.x = input.x * moveSpeed;\nvel.z = input.z * moveSpeed;\nmover.linearVelocity = vel;`
      : `// CharacterController ベースの 3D 移動\nfloat h = Input.GetAxisRaw("Horizontal");\nfloat v = Input.GetAxisRaw("Vertical");\nVector3 input = transform.right * h + transform.forward * v;\nmover.Move(input * moveSpeed * Time.deltaTime);`
    : `// 2D 移動\nfloat h = Input.GetAxisRaw("Horizontal");\nVector2 vel = mover.linearVelocity;\nvel.x = h * moveSpeed;\nmover.linearVelocity = vel;`;

  const lookBody = isFPS
    ? `// 一人称視点のカメラ回転\nfloat mx = Input.GetAxis("Mouse X") * mouseSensitivity;\nfloat my = Input.GetAxis("Mouse Y") * mouseSensitivity;\ntransform.Rotate(0f, mx, 0f);\nif (cameraPivot != null)\n{\n    Vector3 e = cameraPivot.localEulerAngles;\n    e.x = Mathf.Clamp(((e.x + 180f) % 360f) - 180f - my, -85f, 85f);\n    cameraPivot.localEulerAngles = e;\n}`
    : '// 三人称または 2D ではカメラは別コンポーネントで管理';

  const methods: CSharpMethodSpec[] = [
    {
      name: 'TakeDamage',
      returnType: 'void',
      access: 'public',
      parameters: [{ name: 'amount', type: 'int' }],
      body: `currentHealth = Mathf.Max(0, currentHealth - amount);\nDebug.Log($"[Player] HP: {currentHealth}/{maxHealth}");\nif (currentHealth <= 0) Die();`,
      documentation: '<summary>ダメージを受ける。0 以下で Die() を呼ぶ。</summary>',
    },
    {
      name: 'Heal',
      returnType: 'void',
      access: 'public',
      parameters: [{ name: 'amount', type: 'int' }],
      body: 'currentHealth = Mathf.Min(maxHealth, currentHealth + amount);',
    },
    {
      name: 'Die',
      returnType: 'void',
      access: 'private',
      parameters: [],
      body: 'Debug.Log("[Player] Died");\nDestroy(gameObject, 1.5f);',
    },
  ];

  return generateCSharpClass({
    className: 'PlayerController',
    baseClass,
    namespaceName: 'SoloptiLinkAI.Game.Player',
    documentation: `自動生成された PlayerController。\n3D=${opts.use3D}, Physics=${opts.physicsBased}, FPS=${opts.firstPerson}`,
    requireComponents: [movement],
    fields,
    unityCallbacks: [],
    methods: [
      {
        name: 'Awake',
        returnType: 'void',
        access: 'private',
        parameters: [],
        body: methodBodyAwake,
      },
      {
        name: 'Update',
        returnType: 'void',
        access: 'private',
        parameters: [],
        body: `HandleMovement();\nHandleLook();`,
      },
      {
        name: 'HandleMovement',
        returnType: 'void',
        access: 'private',
        parameters: [],
        body: moveBody,
      },
      {
        name: 'HandleLook',
        returnType: 'void',
        access: 'private',
        parameters: [],
        body: lookBody,
      },
      ...methods,
    ],
  });
}

/**
 * EnemyAI スクリプトのテンプレ生成。
 * BehaviorTree 採用時は外部アセット参照のみ、NavMeshAgent 採用時は AI モジュールを使用。
 */
export function generateEnemyAIScript(opts: {
  behaviorTree: boolean;
  navMeshAgent: boolean;
}): string {
  const fields: CSharpFieldSpec[] = [
    {
      name: 'detectRange',
      type: 'float',
      access: 'private',
      serializeField: true,
      defaultValue: '10f',
      header: 'AI 設定',
      tooltip: 'プレイヤー検出距離',
    },
    {
      name: 'attackRange',
      type: 'float',
      access: 'private',
      serializeField: true,
      defaultValue: '1.8f',
    },
    {
      name: 'attackDamage',
      type: 'int',
      access: 'private',
      serializeField: true,
      defaultValue: '10',
    },
    {
      name: 'maxHealth',
      type: 'int',
      access: 'private',
      serializeField: true,
      defaultValue: '50',
    },
    {
      name: 'currentHealth',
      type: 'int',
      access: 'private',
    },
  ];

  if (opts.navMeshAgent) {
    fields.push({
      name: 'agent',
      type: 'UnityEngine.AI.NavMeshAgent',
      access: 'private',
    });
  }

  fields.push({
    name: 'target',
    type: 'Transform',
    access: 'private',
  });

  const updateBody = opts.navMeshAgent
    ? `if (target == null)\n{\n    var p = GameObject.FindWithTag("Player");\n    if (p != null) target = p.transform;\n    return;\n}\nfloat dist = Vector3.Distance(transform.position, target.position);\nif (dist < detectRange)\n{\n    agent.SetDestination(target.position);\n    if (dist < attackRange) AttackTarget();\n}`
    : `// NavMeshAgent 不使用時の単純な追跡\nif (target == null) return;\nVector3 dir = (target.position - transform.position).normalized;\ntransform.position += dir * 2f * Time.deltaTime;\nif (Vector3.Distance(transform.position, target.position) < attackRange) AttackTarget();`;

  return generateCSharpClass({
    className: 'EnemyAI',
    baseClass: 'MonoBehaviour',
    namespaceName: 'SoloptiLinkAI.Game.Enemy',
    documentation: `自動生成された EnemyAI。\nBehaviorTree=${opts.behaviorTree}, NavMesh=${opts.navMeshAgent}`,
    requireComponents: opts.navMeshAgent ? ['UnityEngine.AI.NavMeshAgent'] : [],
    fields,
    methods: [
      {
        name: 'Awake',
        returnType: 'void',
        access: 'private',
        parameters: [],
        body: `currentHealth = maxHealth;\n${opts.navMeshAgent ? 'agent = GetComponent<UnityEngine.AI.NavMeshAgent>();' : ''}`,
      },
      {
        name: 'Update',
        returnType: 'void',
        access: 'private',
        parameters: [],
        body: updateBody,
      },
      {
        name: 'AttackTarget',
        returnType: 'void',
        access: 'private',
        parameters: [],
        body: 'Debug.Log("[EnemyAI] Attack");',
      },
      {
        name: 'TakeDamage',
        returnType: 'void',
        access: 'public',
        parameters: [{ name: 'amount', type: 'int' }],
        body: 'currentHealth -= amount;\nif (currentHealth <= 0) Destroy(gameObject);',
      },
    ],
  });
}
