// =============================================================================
// SoloptiLinkAI v2.0 Game Production Engine - Engine Chooser (Extended)
// =============================================================================
// 責務:
//   Unity / Unreal / Godot / Three.js / Phaser / Pixi の 6 種から、
//   入力された制作条件 (ジャンル/プラットフォーム/スケール/予算/品質/
//   チームサイズ/経験レベル) に最適なエンジンを選定する。
//
//   v1.0 では Phaser/Pixi/Three/Godot の 4 種のみだったが、v2.0 で
//   Unity / Unreal を追加し、商用 AAA 開発までカバーする。
//
//   選定は決定論的ルールエンジン (スコアリング) で行い、日本語の
//   選定理由と警告を出力する。
//
// ライセンス警告:
//   各エンジンのライセンス条件は流動的。本モジュールは 2025 年時点の
//   情報に基づくが、商用採用前に必ず公式の最新規約を確認すること。
// =============================================================================

export type ExtendedEngine = 'phaser' | 'pixi' | 'three' | 'godot' | 'unity' | 'unreal';

export interface ExtendedSelectionInput {
  /** ジャンル */
  genre: string;
  /** ターゲットプラットフォーム配列 */
  targetPlatforms: string[];
  /** スケール */
  scale: 'mini' | 'casual' | 'full' | 'aaa';
  /** 予算 */
  budget: 'free' | 'cheap' | 'standard' | 'premium';
  /** グラフィック要求 */
  graphicsQuality: 'low' | 'medium' | 'high' | 'photoreal';
  /** チームサイズ */
  teamSize: 'solo' | 'small' | 'medium' | 'large';
  /** 経験レベル */
  experienceLevel: 'beginner' | 'intermediate' | 'advanced';
}

export interface EngineSelectionResult {
  primary: ExtendedEngine;
  alternatives: ExtendedEngine[];
  reasoning: string;
  warnings: string[];
  /** 各エンジンの最終スコア (0-100、デバッグ用) */
  allScores: Array<{ engine: ExtendedEngine; score: number }>;
}

interface EngineProfile {
  /** 2D 適性 (0-10) */
  fit2D: number;
  /** 3D 適性 (0-10) */
  fit3D: number;
  /** AAA 適性 (0-10) */
  fitAAA: number;
  /** モバイル適性 */
  fitMobile: number;
  /** Web 適性 (ブラウザ配信容易性) */
  fitWeb: number;
  /** VR 適性 */
  fitVR: number;
  /** コンソール出版適性 */
  fitConsole: number;
  /** 学習曲線の緩やかさ (10=易、0=難) */
  beginnerFriendly: number;
  /** 商用ライセンスコスト負担の低さ (10=完全無料、0=高額) */
  licenseCheap: number;
  /** 開発速度 (プロトタイピング速さ) */
  iterationSpeed: number;
  /** 小規模チーム適性 */
  fitSolo: number;
  /** 大規模チーム適性 */
  fitLarge: number;
  /** フォトリアル到達度 */
  photorealCapability: number;
}

const PROFILES: Record<ExtendedEngine, EngineProfile> = {
  phaser: {
    fit2D: 10, fit3D: 0, fitAAA: 1, fitMobile: 7, fitWeb: 10, fitVR: 0, fitConsole: 2,
    beginnerFriendly: 9, licenseCheap: 10, iterationSpeed: 10, fitSolo: 10, fitLarge: 3, photorealCapability: 0,
  },
  pixi: {
    fit2D: 9, fit3D: 0, fitAAA: 1, fitMobile: 7, fitWeb: 10, fitVR: 0, fitConsole: 2,
    beginnerFriendly: 7, licenseCheap: 10, iterationSpeed: 9, fitSolo: 10, fitLarge: 4, photorealCapability: 0,
  },
  three: {
    fit2D: 4, fit3D: 7, fitAAA: 3, fitMobile: 5, fitWeb: 10, fitVR: 6, fitConsole: 1,
    beginnerFriendly: 5, licenseCheap: 10, iterationSpeed: 7, fitSolo: 8, fitLarge: 4, photorealCapability: 4,
  },
  godot: {
    fit2D: 9, fit3D: 7, fitAAA: 4, fitMobile: 7, fitWeb: 6, fitVR: 4, fitConsole: 5,
    beginnerFriendly: 7, licenseCheap: 10, iterationSpeed: 8, fitSolo: 9, fitLarge: 5, photorealCapability: 5,
  },
  unity: {
    fit2D: 7, fit3D: 9, fitAAA: 8, fitMobile: 10, fitWeb: 6, fitVR: 9, fitConsole: 9,
    beginnerFriendly: 6, licenseCheap: 6, iterationSpeed: 7, fitSolo: 7, fitLarge: 9, photorealCapability: 8,
  },
  unreal: {
    fit2D: 2, fit3D: 10, fitAAA: 10, fitMobile: 6, fitWeb: 3, fitVR: 10, fitConsole: 10,
    beginnerFriendly: 3, licenseCheap: 8, iterationSpeed: 5, fitSolo: 4, fitLarge: 10, photorealCapability: 10,
  },
};

const ENGINE_LABEL_JP: Record<ExtendedEngine, string> = {
  phaser: 'Phaser 3 (Web 2D)',
  pixi: 'PixiJS (Web 2D 高速描画)',
  three: 'Three.js (Web 3D)',
  godot: 'Godot 4 (オープンソース 2D/3D)',
  unity: 'Unity 6 (商用 2D/3D 業界デファクト)',
  unreal: 'Unreal Engine 5 (AAA フォトリアル 3D)',
};

const GENRE_BIAS: Record<string, Partial<Record<ExtendedEngine, number>>> = {
  puzzle: { phaser: 8, pixi: 8, godot: 6, unity: 5, three: 3, unreal: 0 },
  '2d_action': { phaser: 9, godot: 9, pixi: 7, unity: 6, three: 1, unreal: 0 },
  shooter: { phaser: 5, godot: 7, unity: 9, unreal: 10, pixi: 2, three: 5 },
  '3d_shooter': { unreal: 10, unity: 9, godot: 6, three: 4, phaser: 0, pixi: 0 },
  rpg: { unity: 9, godot: 7, unreal: 8, phaser: 6, pixi: 4, three: 5 },
  '3d_rpg': { unreal: 9, unity: 10, godot: 6, three: 4, phaser: 0, pixi: 0 },
  '3d_open_world': { unreal: 10, unity: 9, godot: 5, three: 2, phaser: 0, pixi: 0 },
  novel: { phaser: 9, pixi: 8, godot: 8, unity: 6, three: 1, unreal: 0 },
  board: { phaser: 9, pixi: 9, godot: 8, unity: 6, three: 4, unreal: 1 },
  card: { phaser: 9, pixi: 9, godot: 7, unity: 7, three: 3, unreal: 1 },
  hyper_casual: { phaser: 10, pixi: 9, godot: 7, unity: 8, three: 5, unreal: 1 },
  rhythm: { phaser: 8, pixi: 8, godot: 7, unity: 9, three: 4, unreal: 5 },
  simulation: { unity: 9, unreal: 8, godot: 6, phaser: 5, three: 4, pixi: 3 },
  strategy: { unity: 9, godot: 7, unreal: 7, phaser: 6, pixi: 5, three: 4 },
  clicker: { phaser: 10, pixi: 9, godot: 7, unity: 6, three: 2, unreal: 0 },
  vr: { unreal: 10, unity: 10, godot: 5, three: 5, phaser: 0, pixi: 0 },
  ar: { unity: 10, unreal: 7, godot: 4, three: 5, phaser: 1, pixi: 1 },
  cinematic: { unreal: 10, unity: 7, godot: 4, three: 3, phaser: 0, pixi: 0 },
};

const PLATFORM_BIAS: Record<string, Partial<Record<ExtendedEngine, number>>> = {
  web: { phaser: 10, pixi: 10, three: 10, godot: 6, unity: 4, unreal: 2 },
  browser: { phaser: 10, pixi: 10, three: 10, godot: 6, unity: 4, unreal: 2 },
  ios: { unity: 10, unreal: 7, godot: 6, phaser: 6, pixi: 6, three: 5 },
  android: { unity: 10, unreal: 7, godot: 6, phaser: 6, pixi: 6, three: 5 },
  mobile: { unity: 10, unreal: 6, godot: 7, phaser: 7, pixi: 7, three: 5 },
  windows: { unity: 9, unreal: 10, godot: 8, three: 5, phaser: 5, pixi: 5 },
  mac: { unity: 9, unreal: 9, godot: 8, three: 5, phaser: 5, pixi: 5 },
  linux: { godot: 10, unity: 7, unreal: 7, three: 5, phaser: 5, pixi: 5 },
  switch: { unity: 10, unreal: 9, godot: 4, three: 0, phaser: 0, pixi: 0 },
  ps5: { unreal: 10, unity: 9, godot: 3, three: 0, phaser: 0, pixi: 0 },
  xbox: { unreal: 10, unity: 9, godot: 3, three: 0, phaser: 0, pixi: 0 },
  meta_quest: { unity: 10, unreal: 9, godot: 4, three: 4, phaser: 0, pixi: 0 },
  vr: { unity: 10, unreal: 10, godot: 4, three: 4, phaser: 0, pixi: 0 },
};

/**
 * 拡張選定ロジック。
 */
export function selectEngineExtended(input: ExtendedSelectionInput): EngineSelectionResult {
  const engines: ExtendedEngine[] = ['phaser', 'pixi', 'three', 'godot', 'unity', 'unreal'];
  const scoreMap: Record<ExtendedEngine, number> = {
    phaser: 0, pixi: 0, three: 0, godot: 0, unity: 0, unreal: 0,
  };

  // 1. ジャンルバイアス
  const genreKey = input.genre.toLowerCase();
  const genreScores = GENRE_BIAS[genreKey] ?? {};
  for (const e of engines) {
    scoreMap[e] += (genreScores[e] ?? 5) * 3; // ウェイト 3
  }

  // 2. プラットフォームバイアス (複数 OR 平均)
  for (const p of input.targetPlatforms) {
    const pk = p.toLowerCase();
    const platformScores = PLATFORM_BIAS[pk];
    if (platformScores) {
      for (const e of engines) {
        scoreMap[e] += (platformScores[e] ?? 5) * 2;
      }
    }
  }

  // 3. スケール
  const scaleMultipliers: Record<typeof input.scale, Record<ExtendedEngine, number>> = {
    mini: { phaser: 1.3, pixi: 1.3, three: 1.0, godot: 1.1, unity: 0.7, unreal: 0.4 },
    casual: { phaser: 1.2, pixi: 1.2, three: 1.0, godot: 1.1, unity: 1.0, unreal: 0.6 },
    full: { phaser: 0.9, pixi: 0.9, three: 0.8, godot: 1.0, unity: 1.2, unreal: 1.1 },
    aaa: { phaser: 0.3, pixi: 0.3, three: 0.4, godot: 0.6, unity: 1.2, unreal: 1.4 },
  };
  const scaleMul = scaleMultipliers[input.scale];
  for (const e of engines) scoreMap[e] *= scaleMul[e];

  // 4. グラフィック品質
  const gqBias: Record<typeof input.graphicsQuality, Record<ExtendedEngine, number>> = {
    low: { phaser: 5, pixi: 5, three: 3, godot: 4, unity: 3, unreal: 1 },
    medium: { phaser: 3, pixi: 3, three: 5, godot: 5, unity: 5, unreal: 3 },
    high: { phaser: 1, pixi: 1, three: 5, godot: 5, unity: 8, unreal: 9 },
    photoreal: { phaser: 0, pixi: 0, three: 3, godot: 3, unity: 8, unreal: 10 },
  };
  const gq = gqBias[input.graphicsQuality];
  for (const e of engines) scoreMap[e] += gq[e] * 4;

  // 5. 経験レベル (初心者は学習曲線重視)
  const expMul: Record<typeof input.experienceLevel, number> = {
    beginner: 1.5,
    intermediate: 1.0,
    advanced: 0.4,
  };
  for (const e of engines) {
    scoreMap[e] += PROFILES[e].beginnerFriendly * expMul[input.experienceLevel] * 1.5;
  }

  // 6. 予算 (free は商用エンジンに不利)
  const budgetBonus: Record<typeof input.budget, Record<ExtendedEngine, number>> = {
    free: { phaser: 6, pixi: 6, three: 6, godot: 6, unity: 3, unreal: 4 },
    cheap: { phaser: 5, pixi: 5, three: 5, godot: 6, unity: 4, unreal: 5 },
    standard: { phaser: 3, pixi: 3, three: 3, godot: 4, unity: 6, unreal: 6 },
    premium: { phaser: 2, pixi: 2, three: 2, godot: 3, unity: 7, unreal: 8 },
  };
  const bb = budgetBonus[input.budget];
  for (const e of engines) scoreMap[e] += bb[e] * 2;

  // 7. チームサイズ
  if (input.teamSize === 'solo') {
    for (const e of engines) scoreMap[e] += PROFILES[e].fitSolo;
  } else if (input.teamSize === 'large') {
    for (const e of engines) scoreMap[e] += PROFILES[e].fitLarge * 1.2;
  } else if (input.teamSize === 'medium') {
    for (const e of engines) scoreMap[e] += (PROFILES[e].fitSolo + PROFILES[e].fitLarge) * 0.5;
  } else {
    for (const e of engines) scoreMap[e] += PROFILES[e].fitSolo * 0.7;
  }

  // 正規化 (0-100)
  const max = Math.max(...engines.map((e) => scoreMap[e]));
  const normalized: Array<{ engine: ExtendedEngine; score: number }> = engines
    .map((e) => ({ engine: e, score: max > 0 ? Math.round((scoreMap[e] / max) * 100) : 0 }))
    .sort((a, b) => b.score - a.score);

  const primary = normalized[0].engine;
  const alternatives = normalized.slice(1, 4).map((x) => x.engine);

  // 日本語の選定理由を構築
  const reasoningParts: string[] = [];
  reasoningParts.push(`【選定結果】${ENGINE_LABEL_JP[primary]} を主推奨。スコア ${normalized[0].score}/100。`);
  reasoningParts.push(`【ジャンル】"${input.genre}" は ${ENGINE_LABEL_JP[primary]} の得意分野。`);
  if (input.scale === 'aaa') {
    reasoningParts.push('【スケール】AAA タイトル制作は商用エンジン (Unity/Unreal) でなければ難しい。');
  } else if (input.scale === 'mini') {
    reasoningParts.push('【スケール】ミニゲームは軽量エンジン (Phaser/Pixi/Godot) が iteration が速く生産性高。');
  }
  if (input.graphicsQuality === 'photoreal') {
    reasoningParts.push('【グラフィック】フォトリアル要求は Unreal Engine 5 (Nanite/Lumen) が最高峰、Unity URP/HDRP も次点。');
  }
  if (input.targetPlatforms.includes('web') || input.targetPlatforms.includes('browser')) {
    reasoningParts.push('【Web 配信】Phaser/Pixi/Three は WebGL ネイティブで配信サイズが最小。Unity Web GL は 20MB+ 注意。');
  }
  if (input.targetPlatforms.some((p) => ['switch', 'ps5', 'xbox'].includes(p.toLowerCase()))) {
    reasoningParts.push('【コンソール】コンソール出版は Unity / Unreal が実績豊富、NDA + プラットフォーマー契約必須。');
  }
  if (input.experienceLevel === 'beginner') {
    reasoningParts.push('【経験】初心者は学習曲線の緩やかな Phaser/Godot/Unity が推奨。');
  }
  reasoningParts.push(`【代替候補】${alternatives.map((a) => ENGINE_LABEL_JP[a]).join(' / ')}`);

  // 警告
  const warnings: string[] = [];
  if (primary === 'unity') {
    warnings.push('Unity 6 ライセンス: 売上 USD 200K 超で Pro 必須 ($2,200/seat/年)。https://unity.com/products/pricing-updates 最新確認必須。');
  }
  if (primary === 'unreal') {
    warnings.push('Unreal Engine 5 ライセンス: 売上 USD 100 万超で 5% ロイヤリティ。https://www.unrealengine.com/eula 確認必須。');
  }
  if (primary === 'unreal' && input.experienceLevel === 'beginner') {
    warnings.push('Unreal は学習曲線が急。C++ または Blueprint いずれかの習得に数ヶ月必要。');
  }
  if (primary === 'unity' && input.targetPlatforms.includes('web')) {
    warnings.push('Unity WebGL ビルドは最小でも 10-20MB、初回ロード遅延あり。Web 主体なら Phaser/Pixi 検討推奨。');
  }
  if (input.scale === 'aaa' && input.teamSize === 'solo') {
    warnings.push('AAA タイトルを solo 開発は現実的でない。スコープ縮小または小規模 indie として再設計を推奨。');
  }
  if (input.budget === 'free' && primary === 'unreal') {
    warnings.push('予算 free でも Unreal は売上 100 万ドル以下で無料利用可。ただし開発機材 (RTX GPU 推奨) コスト別途。');
  }

  return {
    primary,
    alternatives,
    reasoning: reasoningParts.join('\n'),
    warnings,
    allScores: normalized,
  };
}
