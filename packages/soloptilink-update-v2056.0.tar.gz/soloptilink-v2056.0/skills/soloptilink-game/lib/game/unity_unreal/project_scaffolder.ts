// =============================================================================
// SoloptiLinkAI v2.0 Game Production Engine - Project Scaffolder
// =============================================================================
// 責務:
//   Unity / Unreal プロジェクトの初期ディレクトリ構造と最小実行可能な
//   ファイル一式を targetDir 直下に生成する。
//
//   生成内容:
//     [Unity]
//       - Assets/_Project/Scripts/Bootstrap/GameManager.cs
//       - Assets/_Project/Scripts/Player/PlayerController.cs
//       - Assets/_Project/Scripts/Enemy/EnemyAI.cs
//       - Assets/_Project/Scenes/Main.unity
//       - Packages/manifest.json
//       - ProjectSettings/EditorSettings.asset (簡易)
//     [Unreal]
//       - Source/<ProjectName>/Public/MyGameMode.h
//       - Source/<ProjectName>/Private/MyGameMode.cpp
//       - <ProjectName>.uproject
//       - Source/<ProjectName>/<ProjectName>.Build.cs
//       - Config/DefaultEngine.ini / DefaultGame.ini
//
//   features オプション (multiplayer/vr/ar/mobile/console/savesys/inventory/
//   questlog) に応じて、対応するスクリプト + パッケージ依存を追加する。
//
// ライセンス警告:
//   Unity 6 / Unreal 5 の利用規約を必ず確認すること。商用利用には
//   売上閾値に応じたサブスク / ロイヤリティが発生する。
// =============================================================================

import * as fs from 'fs';
import * as path from 'path';

import {
  generatePlayerControllerScript,
  generateEnemyAIScript,
  generateCSharpClass,
} from './unity_csharp_generator';
import { generateUnrealHeader, generateUnrealCpp } from './unreal_blueprint_generator';
import { serializeToUnityScene, generateMetaFile, generateGuid } from './unity_scene_serializer';
import { generatePackageJson } from './unity_package_exporter';

/**
 * Scaffold 要求。
 */
export interface ScaffoldRequest {
  /** ターゲットエンジン */
  engine: 'unity' | 'unreal';
  /** プロジェクト名 (PascalCase / 英数字のみ推奨) */
  projectName: string;
  /** 出力先ディレクトリ (絶対パス推奨) */
  targetDir: string;
  /** ジャンル (テンプレ選択用) */
  genre: string;
  /** 含める機能 */
  features: Array<
    | 'multiplayer'
    | 'vr'
    | 'ar'
    | 'mobile'
    | 'console'
    | 'savesys'
    | 'inventory'
    | 'questlog'
  >;
  /** 既存ファイルを上書きするか (デフォルト false: 既存があればエラー) */
  overwrite?: boolean;
  /** 3D かどうか (Unity のみ。デフォルト true) */
  use3D?: boolean;
}

/**
 * Scaffold 結果。
 */
export interface ScaffoldResult {
  /** 生成したファイル絶対パスの配列 */
  generatedFiles: string[];
  /** インストール (記述) したパッケージ */
  packagesInstalled: string[];
  /** 次に実行すべきガイダンス (日本語) */
  nextSteps: string[];
}

// =============================================================================
// ヘルパー
// =============================================================================

/** ファイル名サニタイズ */
function sanitizeName(input: string): string {
  if (!/^[A-Za-z][A-Za-z0-9_]*$/.test(input)) {
    throw new Error(
      `[Scaffolder] projectName "${input}" は英字始まりの英数字/アンダースコアのみ許可 (Unreal/Unity の制約)`
    );
  }
  return input;
}

/** ディレクトリを再帰的に作成。既存なら何もしない */
async function ensureDir(dir: string): Promise<void> {
  await fs.promises.mkdir(dir, { recursive: true });
}

/** ファイル書き込み (上書き制御) */
async function writeFile(
  filePath: string,
  content: string,
  overwrite: boolean,
  generated: string[]
): Promise<void> {
  if (!overwrite) {
    try {
      await fs.promises.access(filePath);
      throw new Error(`[Scaffolder] 既存ファイル "${filePath}" を上書きできません (overwrite=false)`);
    } catch (e) {
      // ENOENT 以外は再 throw
      if ((e as NodeJS.ErrnoException).code !== 'ENOENT') {
        if (!(e as Error).message.includes('既存ファイル')) {
          // access 例外 (ENOENT) は無視、それ以外は throw
        } else {
          throw e;
        }
      }
    }
  }
  await ensureDir(path.dirname(filePath));
  await fs.promises.writeFile(filePath, content, 'utf-8');
  generated.push(filePath);
}

// =============================================================================
// Unity プロジェクト雛形
// =============================================================================

async function scaffoldUnity(req: ScaffoldRequest, result: ScaffoldResult): Promise<void> {
  const root = req.targetDir;
  const overwrite = req.overwrite ?? false;
  const use3D = req.use3D ?? true;
  const features = req.features;

  // 1. ディレクトリ作成
  const dirs = [
    'Assets/_Project/Scripts/Bootstrap',
    'Assets/_Project/Scripts/Player',
    'Assets/_Project/Scripts/Enemy',
    'Assets/_Project/Scripts/UI',
    'Assets/_Project/Scripts/Save',
    'Assets/_Project/Scenes',
    'Assets/_Project/Prefabs',
    'Assets/_Project/Materials',
    'Assets/_Project/Settings',
    'Packages',
    'ProjectSettings',
  ];
  for (const d of dirs) await ensureDir(path.join(root, d));

  // 2. Scripts
  await writeFile(
    path.join(root, 'Assets/_Project/Scripts/Player/PlayerController.cs'),
    generatePlayerControllerScript({
      use3D,
      physicsBased: features.includes('multiplayer'), // マルチプレイヤーは物理ベース推奨
      firstPerson: features.includes('vr'),
    }),
    overwrite,
    result.generatedFiles
  );

  await writeFile(
    path.join(root, 'Assets/_Project/Scripts/Enemy/EnemyAI.cs'),
    generateEnemyAIScript({
      behaviorTree: false,
      navMeshAgent: use3D,
    }),
    overwrite,
    result.generatedFiles
  );

  // GameManager
  const gameManager = generateCSharpClass({
    className: 'GameManager',
    baseClass: 'MonoBehaviour',
    namespaceName: `${sanitizeName(req.projectName)}.Bootstrap`,
    classModifiers: 'public sealed',
    documentation: 'ゲーム全体のエントリポイントとシングルトン管理',
    fields: [
      { name: 'Instance', type: 'GameManager', access: 'public', isStatic: true },
    ],
    methods: [
      {
        name: 'Awake',
        returnType: 'void',
        access: 'private',
        parameters: [],
        body: `if (Instance != null && Instance != this)\n{\n    Destroy(gameObject);\n    return;\n}\nInstance = this;\nDontDestroyOnLoad(gameObject);`,
      },
    ],
  });
  await writeFile(
    path.join(root, 'Assets/_Project/Scripts/Bootstrap/GameManager.cs'),
    gameManager,
    overwrite,
    result.generatedFiles
  );

  // SaveSystem (savesys 機能要求時)
  if (features.includes('savesys')) {
    const saveSys = generateCSharpClass({
      className: 'SaveSystem',
      baseClass: 'MonoBehaviour',
      namespaceName: `${sanitizeName(req.projectName)}.Save`,
      documentation: 'JSON ベースの簡易セーブシステム',
      additionalUsings: ['System.IO'],
      fields: [
        { name: 'FILE_NAME', type: 'string', access: 'private', isStatic: true, readonly: true, defaultValue: '"savedata.json"' },
      ],
      methods: [
        {
          name: 'GetPath',
          returnType: 'string',
          access: 'private',
          parameters: [],
          body: 'return Path.Combine(Application.persistentDataPath, FILE_NAME);',
        },
        {
          name: 'Save',
          returnType: 'void',
          access: 'public',
          parameters: [{ name: 'json', type: 'string' }],
          body: `File.WriteAllText(GetPath(), json);\nDebug.Log("[SaveSystem] Saved");`,
        },
        {
          name: 'Load',
          returnType: 'string',
          access: 'public',
          parameters: [],
          body: `if (!File.Exists(GetPath())) return string.Empty;\nreturn File.ReadAllText(GetPath());`,
        },
      ],
    });
    await writeFile(
      path.join(root, 'Assets/_Project/Scripts/Save/SaveSystem.cs'),
      saveSys,
      overwrite,
      result.generatedFiles
    );
  }

  // 3. シーンファイル
  const sceneYaml = serializeToUnityScene({
    sceneName: 'Main',
    cameras: [
      {
        name: 'Main Camera',
        position: [0, 1.6, -10],
        rotation: [0, 0, 0],
        fov: 60,
        isMain: true,
        clearFlags: 'Skybox',
      },
    ],
    lights: [
      {
        name: 'Directional Light',
        type: 'directional',
        position: [0, 3, 0],
        rotation: [50, -30, 0],
        intensity: 1.0,
        color: '#FFF4E6',
        castShadows: 'Soft',
      },
    ],
    gameObjects: [
      {
        name: 'GameManager',
        components: [
          {
            type: 'MonoBehaviour',
            props: {
              m_Script: `{fileID: 11500000, guid: 00000000000000000000000000000000, type: 3}`,
            },
          },
        ],
      },
    ],
    renderSettings: { fog: false, ambientMode: 'Skybox', ambientIntensity: 1 },
  });
  const scenePath = path.join(root, 'Assets/_Project/Scenes/Main.unity');
  await writeFile(scenePath, sceneYaml, overwrite, result.generatedFiles);
  await writeFile(
    `${scenePath}.meta`,
    generateMetaFile(generateGuid(scenePath), 'Scene'),
    overwrite,
    result.generatedFiles
  );

  // 4. Packages/manifest.json
  const baseDeps: Array<{ packageName: string; version: string }> = [
    { packageName: 'com.unity.inputsystem', version: '1.7.0' },
    { packageName: 'com.unity.render-pipelines.universal', version: '17.0.3' },
    { packageName: 'com.unity.cinemachine', version: '3.1.1' },
    { packageName: 'com.unity.textmeshpro', version: '3.0.9' },
    { packageName: 'com.unity.test-framework', version: '1.4.5' },
  ];
  if (use3D) {
    baseDeps.push({ packageName: 'com.unity.ai.navigation', version: '2.0.4' });
  }
  if (features.includes('multiplayer')) {
    baseDeps.push({ packageName: 'com.unity.netcode.gameobjects', version: '2.0.0' });
    baseDeps.push({ packageName: 'com.unity.services.relay', version: '1.1.0' });
    baseDeps.push({ packageName: 'com.unity.services.lobby', version: '1.2.0' });
  }
  if (features.includes('vr')) {
    baseDeps.push({ packageName: 'com.unity.xr.management', version: '4.5.0' });
    baseDeps.push({ packageName: 'com.unity.xr.openxr', version: '1.11.0' });
    baseDeps.push({ packageName: 'com.unity.xr.interaction.toolkit', version: '3.0.5' });
  }
  if (features.includes('ar')) {
    baseDeps.push({ packageName: 'com.unity.xr.arfoundation', version: '6.0.2' });
    baseDeps.push({ packageName: 'com.unity.xr.arkit', version: '6.0.2' });
    baseDeps.push({ packageName: 'com.unity.xr.arcore', version: '6.0.2' });
  }

  const manifest = generatePackageJson({
    packageName: `com.soloptilinkai.${sanitizeName(req.projectName).toLowerCase()}`,
    version: '0.1.0',
    description: `${req.projectName} - SoloptiLinkAI で生成された ${req.genre} ゲームプロジェクト`,
    displayName: req.projectName,
    unityVersion: '6000.0',
    assets: [],
    dependencies: baseDeps,
  });
  // ただし Packages/manifest.json は UPM 形式とは異なるため、専用フォーマットで上書き
  const upmManifest = {
    dependencies: Object.fromEntries(baseDeps.map((d) => [d.packageName, d.version])),
    scopedRegistries: [],
  };
  await writeFile(
    path.join(root, 'Packages/manifest.json'),
    JSON.stringify(upmManifest, null, 2) + '\n',
    overwrite,
    result.generatedFiles
  );
  // 念のため UPM 形式の package.json も Tooling ディレクトリに保存
  await writeFile(
    path.join(root, 'Packages/.soloptilinkai_package_template.json'),
    manifest,
    overwrite,
    result.generatedFiles
  );

  // 5. ProjectSettings/ProjectVersion.txt
  await writeFile(
    path.join(root, 'ProjectSettings/ProjectVersion.txt'),
    'm_EditorVersion: 6000.0.23f1\nm_EditorVersionWithRevision: 6000.0.23f1 (xxxxxxxxxxxx)\n',
    overwrite,
    result.generatedFiles
  );

  // パッケージ記録
  result.packagesInstalled.push(...baseDeps.map((d) => `${d.packageName}@${d.version}`));

  // 次ステップ
  result.nextSteps.push(
    `Unity Hub から "Open project" で "${root}" を選択し、Unity 6 LTS でプロジェクトを開いてください`
  );
  result.nextSteps.push(
    `初回起動時はパッケージ復元 + シェーダコンパイルで数分かかります`
  );
  result.nextSteps.push(
    `Assets/_Project/Scenes/Main.unity を開き、GameManager オブジェクトに GameManager スクリプトをアタッチしてください`
  );
  if (features.includes('vr')) {
    result.nextSteps.push(
      `VR 設定: Project Settings > XR Plug-in Management で OpenXR を有効化し、対象デバイスのプロファイル (Meta Quest 等) を追加してください`
    );
  }
  if (features.includes('multiplayer')) {
    result.nextSteps.push(
      `マルチプレイ設定: Unity Gaming Services (UGS) のダッシュボードでプロジェクト ID を取得し、Project Settings > Services に登録してください`
    );
  }
  result.nextSteps.push(
    `[ライセンス重要] Unity 6 LTS の利用規約 https://unity.com/legal/editor-terms-of-service を必ず確認してください。Pro 以上は売上 USD 200K 超で必須です`
  );
}

// =============================================================================
// Unreal プロジェクト雛形
// =============================================================================

async function scaffoldUnreal(req: ScaffoldRequest, result: ScaffoldResult): Promise<void> {
  const root = req.targetDir;
  const overwrite = req.overwrite ?? false;
  const projectName = sanitizeName(req.projectName);
  const features = req.features;
  const moduleName = projectName;

  // ディレクトリ作成
  const dirs = [
    `Source/${moduleName}/Public`,
    `Source/${moduleName}/Private`,
    'Content/Blueprints/Player',
    'Content/Blueprints/Enemy',
    'Content/Blueprints/UI',
    'Content/Blueprints/GameModes',
    'Content/Maps',
    'Content/Materials',
    'Content/Meshes',
    'Content/Audio',
    'Config',
    'Plugins',
  ];
  for (const d of dirs) await ensureDir(path.join(root, d));

  // .uproject ファイル
  const uproject = {
    FileVersion: 3,
    EngineAssociation: '5.4',
    Category: 'Game',
    Description: `${projectName} - SoloptiLinkAI で生成された ${req.genre} ゲームプロジェクト`,
    Modules: [
      {
        Name: moduleName,
        Type: 'Runtime',
        LoadingPhase: 'Default',
        AdditionalDependencies: ['Engine', 'CoreUObject'],
      },
    ],
    Plugins: [
      { Name: 'EnhancedInput', Enabled: true },
      { Name: 'ModelingToolsEditorMode', Enabled: true },
      ...(features.includes('vr') ? [{ Name: 'OpenXR', Enabled: true }] : []),
      ...(features.includes('ar') ? [{ Name: 'AppleARKit', Enabled: true }, { Name: 'GoogleARCore', Enabled: true }] : []),
      ...(features.includes('multiplayer') ? [{ Name: 'OnlineSubsystem', Enabled: true }] : []),
    ],
    TargetPlatforms: [
      ...(features.includes('mobile') ? ['IOS', 'Android'] : []),
      ...(features.includes('console') ? ['PS5', 'XSX'] : []),
      'Windows',
    ],
  };
  await writeFile(
    path.join(root, `${projectName}.uproject`),
    JSON.stringify(uproject, null, 2) + '\n',
    overwrite,
    result.generatedFiles
  );

  // Build.cs
  const buildCs = `// SoloptiLinkAI v2.0 - 自動生成された Unreal モジュール定義\nusing UnrealBuildTool;\n\npublic class ${moduleName} : ModuleRules\n{\n    public ${moduleName}(ReadOnlyTargetRules Target) : base(Target)\n    {\n        PCHUsage = PCHUsageMode.UseExplicitOrSharedPCHs;\n        PublicDependencyModuleNames.AddRange(new string[] {\n            "Core",\n            "CoreUObject",\n            "Engine",\n            "InputCore",\n            "EnhancedInput",\n            "UMG",\n            "AIModule",\n            "NavigationSystem",\n            "GameplayTasks"${features.includes('multiplayer') ? ',\n            "OnlineSubsystem",\n            "OnlineSubsystemUtils"' : ''}\n        });\n    }\n}\n`;
  await writeFile(
    path.join(root, `Source/${moduleName}/${moduleName}.Build.cs`),
    buildCs,
    overwrite,
    result.generatedFiles
  );

  // Target.cs (ゲーム + Editor)
  const targetCs = `using UnrealBuildTool;\nusing System.Collections.Generic;\n\npublic class ${moduleName}Target : TargetRules\n{\n    public ${moduleName}Target(TargetInfo Target) : base(Target)\n    {\n        Type = TargetType.Game;\n        DefaultBuildSettings = BuildSettingsVersion.V5;\n        IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_4;\n        ExtraModuleNames.Add("${moduleName}");\n    }\n}\n`;
  await writeFile(
    path.join(root, `Source/${moduleName}.Target.cs`),
    targetCs,
    overwrite,
    result.generatedFiles
  );

  const editorTargetCs = `using UnrealBuildTool;\nusing System.Collections.Generic;\n\npublic class ${moduleName}EditorTarget : TargetRules\n{\n    public ${moduleName}EditorTarget(TargetInfo Target) : base(Target)\n    {\n        Type = TargetType.Editor;\n        DefaultBuildSettings = BuildSettingsVersion.V5;\n        IncludeOrderVersion = EngineIncludeOrderVersion.Unreal5_4;\n        ExtraModuleNames.Add("${moduleName}");\n    }\n}\n`;
  await writeFile(
    path.join(root, `Source/${moduleName}Editor.Target.cs`),
    editorTargetCs,
    overwrite,
    result.generatedFiles
  );

  // モジュールエントリポイント
  const moduleHeader = `#pragma once\n#include "CoreMinimal.h"\n#include "Modules/ModuleManager.h"\n\nclass F${moduleName}Module : public IModuleInterface\n{\npublic:\n    virtual void StartupModule() override;\n    virtual void ShutdownModule() override;\n};\n`;
  await writeFile(
    path.join(root, `Source/${moduleName}/Public/${moduleName}.h`),
    moduleHeader,
    overwrite,
    result.generatedFiles
  );

  const moduleCpp = `#include "${moduleName}.h"\n#include "Modules/ModuleManager.h"\n\nvoid F${moduleName}Module::StartupModule()\n{\n    UE_LOG(LogTemp, Log, TEXT("[${moduleName}] Module Started"));\n}\n\nvoid F${moduleName}Module::ShutdownModule()\n{\n    UE_LOG(LogTemp, Log, TEXT("[${moduleName}] Module Shutdown"));\n}\n\nIMPLEMENT_PRIMARY_GAME_MODULE(F${moduleName}Module, ${moduleName}, "${moduleName}");\n`;
  await writeFile(
    path.join(root, `Source/${moduleName}/Private/${moduleName}.cpp`),
    moduleCpp,
    overwrite,
    result.generatedFiles
  );

  // GameMode (h + cpp)
  const apiMacro = `${moduleName.toUpperCase()}_API`;
  const gmHeader = generateUnrealHeader({
    className: 'AMyGameMode',
    parentClass: 'AGameModeBase',
    isBlueprint: true,
    moduleName,
    apiMacro,
    documentation: '自動生成されたゲームモード。Player/HUD のデフォルトクラスを設定',
    uproperties: [
      {
        name: 'InitialScore',
        type: 'int32',
        category: 'Gameplay',
        editDefaultsOnly: true,
        blueprintReadWrite: true,
        defaultValue: '0',
        tooltip: '初期スコア値',
      },
      {
        name: 'CurrentScore',
        type: 'int32',
        category: 'Gameplay',
        blueprintReadOnly: true,
        defaultValue: '0',
      },
    ],
    ufunctions: [
      {
        name: 'AddScore',
        returnType: 'void',
        access: 'public',
        parameters: [{ name: 'Amount', type: 'int32' }],
        blueprintCallable: true,
        category: 'Gameplay',
        body: 'CurrentScore += Amount;',
      },
    ],
  });
  await writeFile(
    path.join(root, `Source/${moduleName}/Public/MyGameMode.h`),
    gmHeader,
    overwrite,
    result.generatedFiles
  );

  const gmCpp = generateUnrealCpp({
    className: 'AMyGameMode',
    parentClass: 'AGameModeBase',
    isBlueprint: true,
    moduleName,
    apiMacro,
    uproperties: [],
    ufunctions: [
      {
        name: 'AddScore',
        returnType: 'void',
        parameters: [{ name: 'Amount', type: 'int32' }],
        body: `CurrentScore += Amount;\nUE_LOG(LogTemp, Log, TEXT("[GameMode] Score=%d"), CurrentScore);`,
      },
    ],
  });
  await writeFile(
    path.join(root, `Source/${moduleName}/Private/MyGameMode.cpp`),
    gmCpp,
    overwrite,
    result.generatedFiles
  );

  // Config/DefaultEngine.ini
  const defaultEngineIni = `[/Script/EngineSettings.GameMapsSettings]\nGameDefaultMap=/Game/Maps/MainMap.MainMap\nEditorStartupMap=/Game/Maps/MainMap.MainMap\nGlobalDefaultGameMode=/Script/${moduleName}.MyGameMode\n\n[/Script/Engine.RendererSettings]\nr.DefaultFeature.AutoExposure=False\nr.DefaultFeature.LensFlare=False\nr.DefaultFeature.MotionBlur=False\nr.Lumen.HardwareRayTracing=1\nr.RayTracing=True\nr.SkinCache.CompileShaders=True\n\n[/Script/Engine.PhysicsSettings]\nDefaultGravityZ=-980.000000\n`;
  await writeFile(
    path.join(root, 'Config/DefaultEngine.ini'),
    defaultEngineIni,
    overwrite,
    result.generatedFiles
  );

  const defaultGameIni = `[/Script/EngineSettings.GeneralProjectSettings]\nProjectID=${generateGuid(projectName).substring(0, 32).toUpperCase()}\nProjectName=${projectName}\nProjectVersion=0.1.0\nCompanyName=SoloptiLinkAI\nCopyrightNotice=Copyright (C) ${new Date().getFullYear()} ${projectName}\n`;
  await writeFile(
    path.join(root, 'Config/DefaultGame.ini'),
    defaultGameIni,
    overwrite,
    result.generatedFiles
  );

  // パッケージ記録
  result.packagesInstalled.push('UE 5.4 Engine', 'EnhancedInput', 'ModelingTools');
  if (features.includes('vr')) result.packagesInstalled.push('OpenXR');
  if (features.includes('ar')) result.packagesInstalled.push('AppleARKit', 'GoogleARCore');
  if (features.includes('multiplayer')) result.packagesInstalled.push('OnlineSubsystem');

  // 次ステップ
  result.nextSteps.push(
    `Unreal Engine 5.4 で "${root}/${projectName}.uproject" をダブルクリックして開いてください`
  );
  result.nextSteps.push(
    `初回ビルドで C++ コンパイル + シェーダコンパイルに数十分かかります (要 SSD + 16GB RAM 以上)`
  );
  result.nextSteps.push(
    `エディタで Content/Maps に新規 Level を作成し、Project Settings > Maps & Modes で Default Map に設定してください`
  );
  result.nextSteps.push(
    `BP_GameMode (Content/Blueprints/GameModes) を AMyGameMode から派生して作成すると、Blueprint 上で詳細を調整できます`
  );
  if (features.includes('multiplayer')) {
    result.nextSteps.push(
      `マルチプレイヤー設定: Edit > Editor Preferences > Play で "Number of Players" を 2 以上にし、 Net Mode を Listen Server に変更してテスト`
    );
  }
  result.nextSteps.push(
    `[ライセンス重要] Unreal Engine 5 EULA https://www.unrealengine.com/eula を必ず確認してください。売上 USD 100 万超で 5% ロイヤリティが発生します`
  );
}

// =============================================================================
// 公開 API
// =============================================================================

/**
 * Scaffold メイン関数。
 */
export async function scaffold(req: ScaffoldRequest): Promise<ScaffoldResult> {
  sanitizeName(req.projectName);
  if (!path.isAbsolute(req.targetDir)) {
    throw new Error('[Scaffolder] targetDir は絶対パスで指定してください');
  }
  await ensureDir(req.targetDir);

  const result: ScaffoldResult = {
    generatedFiles: [],
    packagesInstalled: [],
    nextSteps: [],
  };

  if (req.engine === 'unity') {
    await scaffoldUnity(req, result);
  } else if (req.engine === 'unreal') {
    await scaffoldUnreal(req, result);
  } else {
    throw new Error(`[Scaffolder] 未対応エンジン: ${req.engine as string}`);
  }

  return result;
}
