// =============================================================================
// SoloptiLinkAI v2.0 Game Production Engine - Unity Package Exporter
// =============================================================================
// 責務:
//   .unitypackage 形式のパッケージ作成に必要な構成記述ファイル (package.json
//   for UPM / Export Manifest) を生成する。Unity Package Manager 形式 (UPM)
//   と従来の AssetStore .unitypackage 形式の両方をカバーする。
//
//   実際の tar.gz 圧縮 (.unitypackage 物理生成) はファイルシステム操作を
//   伴うため本モジュールでは生成記述のみを提供し、実際のパッケージング
//   は project_scaffolder.ts / 外部ツール (UnityPackager CLI 等) に委譲する。
//
// ライセンス警告:
//   生成されたパッケージを Unity Asset Store で配布する場合、
//   Asset Store Provider Agreement (https://unity.com/legal/as-provider-agreement)
//   に従うこと。商用配布物は 30% プラットフォーム手数料、$25K/年以下の
//   売上で 0% (2024 改定) など条件あり。
//
// 使用例:
//   const pkg = generatePackageJson({
//     packageName: "com.soloptilinkai.game-template",
//     version: "1.0.0",
//     description: "ゲーム雛形パッケージ",
//     assets: [...],
//     dependencies: [{ packageName: "com.unity.cinemachine", version: "3.1.1" }]
//   });
//   fs.writeFileSync("Packages/com.soloptilinkai.game-template/package.json", pkg);
// =============================================================================

/**
 * Unity Package Manager (UPM) / .unitypackage 共通の仕様。
 */
export interface UnityPackageSpec {
  /** UPM パッケージ名 (com.organization.name 形式、推奨) */
  packageName: string;
  /** Semver (例: "1.0.0") */
  version: string;
  /** 説明 (日本語可) */
  description: string;
  /** 表示名 (Package Manager UI 上) */
  displayName?: string;
  /** Unity 最低バージョン (例: "2022.3") */
  unityVersion?: string;
  /** 著者情報 */
  author?: { name: string; email?: string; url?: string };
  /** ライセンス (SPDX 識別子) */
  license?: string;
  /** キーワード (検索用) */
  keywords?: string[];
  /** 含めるアセット */
  assets: Array<{
    /** ローカルファイルシステム上のパス */
    srcPath: string;
    /** Unity プロジェクト内の配置先 (例: "Assets/Plugins/SoloptiLink/Player.cs") */
    targetUnityPath: string;
    /** アセット種別 */
    assetType: 'Script' | 'Prefab' | 'Material' | 'Texture' | 'Model' | 'Scene' | 'AudioClip' | 'Animation' | 'ShaderGraph' | 'Other';
    /** Asset の GUID (省略時は自動生成) */
    guid?: string;
  }>;
  /** UPM 依存パッケージ */
  dependencies: Array<{
    packageName: string;
    version: string;
  }>;
  /** サンプルシーン/コード (UPM Samples 仕様) */
  samples?: Array<{
    displayName: string;
    description: string;
    path: string;
  }>;
  /** リポジトリ情報 (Open UPM 対応) */
  repository?: { type: 'git'; url: string };
}

// =============================================================================
// package.json (UPM 形式) 生成
// =============================================================================

/**
 * Unity Package Manager (UPM) の package.json を生成する。
 * UPM 形式は Unity 2018.1+ で公式サポート。.unitypackage より推奨される
 * 現代の標準形式。
 */
export function generatePackageJson(spec: UnityPackageSpec): string {
  // パッケージ名の検証 (UPM の規約)
  if (!/^[a-z0-9][a-z0-9_.\-]*$/.test(spec.packageName)) {
    throw new Error(
      `[UnityPackage] packageName "${spec.packageName}" は UPM 命名規約 (小文字 + ドット + ハイフン) に違反`
    );
  }
  // Semver 検証
  if (!/^\d+\.\d+\.\d+(-[\w.]+)?(\+[\w.]+)?$/.test(spec.version)) {
    throw new Error(`[UnityPackage] version "${spec.version}" は SemVer 形式ではない`);
  }

  const pkg: Record<string, unknown> = {
    name: spec.packageName,
    version: spec.version,
    displayName: spec.displayName ?? spec.packageName,
    description: spec.description,
    unity: spec.unityVersion ?? '2022.3',
    keywords: spec.keywords ?? [],
    category: 'Game',
    license: spec.license ?? 'MIT',
  };

  if (spec.author) pkg.author = spec.author;
  if (spec.repository) pkg.repository = spec.repository;

  // dependencies は UPM 形式 (オブジェクト)
  if (spec.dependencies.length > 0) {
    const deps: Record<string, string> = {};
    for (const d of spec.dependencies) {
      deps[d.packageName] = d.version;
    }
    pkg.dependencies = deps;
  }

  // samples
  if (spec.samples && spec.samples.length > 0) {
    pkg.samples = spec.samples.map((s) => ({
      displayName: s.displayName,
      description: s.description,
      path: s.path,
    }));
  }

  return JSON.stringify(pkg, null, 2) + '\n';
}

// =============================================================================
// Export Manifest (.unitypackage 形式向け) 生成
// =============================================================================

/**
 * 従来の .unitypackage (tar.gz 形式) を生成する際に必要な
 * Export Manifest を生成する。各アセットの GUID -> パスのマッピング、
 * メタファイル一式を JSON で表現する。
 *
 * 実際の tar.gz 作成は別途 tar コマンドや専用 CLI で実行する。
 * このマニフェストはその入力として使用する。
 */
export function generateExportManifest(spec: UnityPackageSpec): string {
  const generateLocalGuid = (seed: string): string => {
    let hash = '';
    let s = seed;
    while (hash.length < 32) {
      let h = 0;
      for (let i = 0; i < s.length; i++) {
        h = ((h << 5) - h + s.charCodeAt(i)) | 0;
      }
      hash += Math.abs(h).toString(16).padStart(8, '0');
      s = hash + s;
    }
    return hash.substring(0, 32);
  };

  const manifest = {
    _comment_jp: 'Unity .unitypackage Export Manifest。tar.gz 圧縮入力用',
    packageName: spec.packageName,
    version: spec.version,
    description: spec.description,
    unityMinVersion: spec.unityVersion ?? '2022.3',
    license: spec.license ?? 'MIT',
    author: spec.author ?? null,
    generatedAt: new Date().toISOString(),
    totalAssetCount: spec.assets.length,
    assets: spec.assets.map((a, index) => {
      const guid = a.guid ?? generateLocalGuid(`${spec.packageName}::${a.targetUnityPath}::${index}`);
      return {
        index,
        guid,
        sourceLocalPath: a.srcPath,
        targetUnityPath: a.targetUnityPath,
        assetType: a.assetType,
        metaFileContent: buildMetaContent(guid, a.assetType),
        // tar 内エントリ (Unity の .unitypackage は GUID ディレクトリ構造)
        archiveEntries: [
          {
            path: `${guid}/asset`,
            sourceFile: a.srcPath,
            description: 'アセット本体',
          },
          {
            path: `${guid}/asset.meta`,
            sourceFile: `${a.srcPath}.meta`,
            description: 'GUID 管理メタファイル',
          },
          {
            path: `${guid}/pathname`,
            content: a.targetUnityPath,
            description: 'インポート時の配置先',
          },
        ],
      };
    }),
    dependencies: spec.dependencies,
    instructions_jp: [
      '1. 各アセットを上記 archiveEntries に従って配置',
      '2. tar -czf <packageName>-<version>.unitypackage <すべてのGUIDディレクトリ>',
      '3. Unity Editor で Assets > Import Package > Custom Package... で読込',
    ],
  };

  return JSON.stringify(manifest, null, 2) + '\n';
}

/**
 * .meta ファイル内容を生成 (assetType 別の importer 切替)。
 */
function buildMetaContent(guid: string, assetType: string): string {
  const importerMap: Record<string, string> = {
    Script: 'MonoImporter',
    Prefab: 'PrefabImporter',
    Material: 'NativeFormatImporter',
    Texture: 'TextureImporter',
    Model: 'ModelImporter',
    Scene: 'DefaultImporter',
    AudioClip: 'AudioImporter',
    Animation: 'NativeFormatImporter',
    ShaderGraph: 'ScriptedImporter',
    Other: 'DefaultImporter',
  };
  const importer = importerMap[assetType] ?? 'DefaultImporter';
  return `fileFormatVersion: 2\nguid: ${guid}\n${importer}:\n  externalObjects: {}\n  userData: \n  assetBundleName: \n  assetBundleVariant: \n`;
}

/**
 * UPM パッケージのディレクトリ構造を平坦に列挙する (パッケージ作成補助)。
 */
export function listUpmRequiredFiles(spec: UnityPackageSpec): Array<{
  path: string;
  description: string;
  required: boolean;
}> {
  return [
    { path: 'package.json', description: 'UPM マニフェスト (本モジュール generatePackageJson で生成)', required: true },
    { path: 'README.md', description: 'パッケージ概要 (日本語/英語推奨)', required: false },
    { path: 'CHANGELOG.md', description: 'バージョン履歴', required: false },
    { path: 'LICENSE.md', description: 'ライセンスファイル', required: false },
    { path: 'Runtime/', description: 'ランタイムスクリプト (.cs)', required: false },
    { path: 'Runtime/<AssemblyName>.asmdef', description: 'Assembly Definition (推奨)', required: false },
    { path: 'Editor/', description: 'エディタ専用スクリプト', required: false },
    { path: 'Editor/<EditorAssemblyName>.asmdef', description: 'Editor Assembly Definition', required: false },
    { path: 'Tests/', description: 'PlayMode/EditMode テスト', required: false },
    { path: 'Samples~/', description: 'サンプル (チルダ付きで本体から除外)', required: false },
    { path: 'Documentation~/', description: 'ドキュメント (チルダ付き)', required: false },
  ];
}
