/**
 * SoloptiLinkAI v1.0 - Game Production Engine
 * GDD (Game Design Document) Generator
 *
 * GDDテンプレートを読み込み、ジャンル定義から初期値を補完し、
 * Markdown形式の完成度の高いGDDを生成する。
 */

import * as fs from 'node:fs';
import * as path from 'node:path';

// =============================================================================
// 型定義
// =============================================================================

/**
 * 12種類のゲームジャンル
 */
export type GameGenre =
  | 'puzzle'
  | 'action_2d'
  | 'shooter'
  | 'rpg'
  | 'novel'
  | 'board'
  | 'card'
  | 'hypercasual'
  | 'rhythm'
  | 'simulation'
  | 'strategy'
  | 'clicker';

/**
 * 対応エンジン4種
 */
export type GameEngine = 'phaser' | 'pixi' | 'three' | 'godot';

/**
 * 配信プラットフォーム
 */
export type GamePlatform = 'web' | 'mobile' | 'desktop' | 'steam';

/**
 * マネタイズモデル
 */
export type Monetization = 'free' | 'paid' | 'f2p_ads' | 'iap' | 'subscription';

/**
 * GDD 生成への入力
 */
export interface GddInput {
  /** ゲームタイトル */
  title: string;
  /** ワンライナー (15字以内推奨) */
  oneLiner: string;
  /** ジャンル */
  genre: GameGenre;
  /** 想定エンジン */
  engine: GameEngine;
  /** 配信プラットフォーム (複数可) */
  platform: GamePlatform[];
  /** ターゲット層 (例: "20-30代、カジュアル層、モバイル中心") */
  targetAudience: string;
  /** セッション時間 (分) */
  sessionLengthMin: { min: number; max: number };
  /** マネタイズモデル */
  monetization: Monetization;
  /** 作成者 (省略可) */
  author?: string;
  /** USP (省略可、自動推論される) */
  usp?: string;
}

/**
 * GDD バリデーション結果
 */
export interface GddValidationResult {
  valid: boolean;
  missingSections: string[];
  warnings: string[];
}

/**
 * ジャンル定義 (genres/<genre>.json から読み込まれる形式)
 */
export interface GenreDefinition {
  id: GameGenre;
  name_ja: string;
  core_loop_template: string;
  default_actions: { name: string; desc: string }[];
  default_win_condition: string;
  default_lose_condition: string;
  default_art_style: string;
  default_bgm_mood: string;
  recommended_engine: GameEngine;
  reward_short_template: string;
  reward_mid_template: string;
  reward_long_template: string;
  reward_meta_template: string;
  tutorial_policy: string;
}

// =============================================================================
// ジャンルデフォルト (genres/*.json が存在しない場合のフォールバック)
// =============================================================================

const GENRE_FALLBACKS: Record<GameGenre, GenreDefinition> = {
  puzzle: {
    id: 'puzzle',
    name_ja: 'パズル',
    core_loop_template: '盤面観察→手筋発見→操作→クリア→次面',
    default_actions: [
      { name: 'ブロック移動', desc: 'マウス/タッチで対象ブロックを動かす' },
      { name: 'リセット', desc: '現在面を初期状態に戻す' },
      { name: 'ヒント', desc: '1手だけ正解を表示する (有限資源)' },
    ],
    default_win_condition: '盤面が指定の完成パターンに到達する',
    default_lose_condition: '手数超過 or 詰み状態 (リセット可能)',
    default_art_style: 'クリーンミニマル + 限定パレット 8色',
    default_bgm_mood: 'minimal / lofi / jazz (集中力維持)',
    recommended_engine: 'phaser',
    reward_short_template: 'ブロック整列のチャラリン音',
    reward_mid_template: '面クリアの達成演出',
    reward_long_template: 'ステージ群クリアでギャラリー解放',
    reward_meta_template: '全実績解除、タイムアタックランキング',
    tutorial_policy: '面1-3 でメカニクス全て導入、テキスト最小',
  },
  action_2d: {
    id: 'action_2d',
    name_ja: '2Dアクション',
    core_loop_template: '移動→敵発見→攻撃/回避→撃破→アイテム獲得→成長',
    default_actions: [
      { name: '移動', desc: '左右移動 + ジャンプ' },
      { name: '攻撃', desc: '近接 or 遠距離攻撃' },
      { name: '回避', desc: 'ダッシュ/ローリング' },
    ],
    default_win_condition: 'ステージのゴール到達 or ボス撃破',
    default_lose_condition: 'HP 0 で死亡、リトライ可能',
    default_art_style: '16-bit ピクセル + 限定パレット 12色',
    default_bgm_mood: 'chiptune / orchestral (盛り上がり重視)',
    recommended_engine: 'phaser',
    reward_short_template: '敵撃破のヒット感 (画面振動+SE+エフェクト)',
    reward_mid_template: 'アイテム獲得とスコア上昇',
    reward_long_template: 'ステージクリアと装備強化',
    reward_meta_template: '全ボス撃破、ハードモード解放、隠しキャラ',
    tutorial_policy: '任天堂式 4-Step Teaching でメカニクス段階導入',
  },
  shooter: {
    id: 'shooter',
    name_ja: 'シューティング',
    core_loop_template: '敵出現→照準→射撃→撃破→ボス→クリア',
    default_actions: [
      { name: '移動', desc: '8方向自由移動' },
      { name: 'ショット', desc: '連射 + 弾種切替' },
      { name: 'ボム', desc: '画面全体ダメージ + 無敵 (有限)' },
    ],
    default_win_condition: 'ステージ最後のボス撃破',
    default_lose_condition: '残機 0 で死亡、コンティニュー可',
    default_art_style: 'ネオン + 高彩度 + パーティクル多用',
    default_bgm_mood: 'electronic / EDM (高揚感)',
    recommended_engine: 'pixi',
    reward_short_template: '撃破時の爆発演出 + コンボ加算',
    reward_mid_template: 'ボス撃破とパワーアップ獲得',
    reward_long_template: 'ステージクリアと機体強化',
    reward_meta_template: 'ハイスコアランキング、全機体解放',
    tutorial_policy: '面1 を低密度デモにして弾幕に慣れさせる',
  },
  rpg: {
    id: 'rpg',
    name_ja: 'RPG',
    core_loop_template: '探索→戦闘→経験値/装備→成長→ストーリー進行',
    default_actions: [
      { name: 'マップ移動', desc: 'フィールド/ダンジョン探索' },
      { name: '戦闘', desc: 'コマンド/リアルタイム戦闘' },
      { name: '装備変更', desc: '武器/防具/アクセサリーの装備' },
    ],
    default_win_condition: 'メインストーリークリア',
    default_lose_condition: '全滅、町に戻る (リスタート)',
    default_art_style: 'JRPG風アニメ + キャラ立ち絵',
    default_bgm_mood: 'orchestral / world music (世界観重視)',
    recommended_engine: 'phaser',
    reward_short_template: '戦闘勝利のファンファーレ + 経験値獲得',
    reward_mid_template: 'レベルアップ、新スキル習得',
    reward_long_template: 'ストーリー進行、新エリア解放',
    reward_meta_template: 'エンディング分岐、クリア後ダンジョン',
    tutorial_policy: '序盤で操作キャラ1人、徐々に仲間追加',
  },
  novel: {
    id: 'novel',
    name_ja: 'ノベル / アドベンチャー',
    core_loop_template: '読む→選択肢→分岐→次章→エンディング',
    default_actions: [
      { name: 'テキスト送り', desc: 'クリック/タップで進める' },
      { name: '選択肢', desc: '分岐点で行動を選ぶ' },
      { name: 'ログ閲覧', desc: '過去のテキスト/選択を振り返る' },
    ],
    default_win_condition: 'いずれかのエンディング到達 (Good/Bad/True)',
    default_lose_condition: 'Bad End も終了の一形態 (探索的価値あり)',
    default_art_style: '水彩風アニメ立ち絵 + 静止背景',
    default_bgm_mood: 'ambient / piano (情緒重視)',
    recommended_engine: 'phaser',
    reward_short_template: 'テキスト送りのリズム感 + 立ち絵切替',
    reward_mid_template: '選択肢による分岐感',
    reward_long_template: '1エンディング到達 + CG解放',
    reward_meta_template: '全エンディング回収、True End 解放',
    tutorial_policy: 'プロローグで操作説明をテキストに溶け込ませる',
  },
  board: {
    id: 'board',
    name_ja: 'ボードゲーム',
    core_loop_template: 'ターン開始→思考→着手→相手手番→局面進行',
    default_actions: [
      { name: '駒選択', desc: '動かす駒/手を選ぶ' },
      { name: '着手', desc: '選んだ手を実行する' },
      { name: '待った', desc: '直前手を取り消す (オフライン時)' },
    ],
    default_win_condition: 'ルール上の勝利条件達成 (詰み/陣地/枚数)',
    default_lose_condition: 'ルール上の敗北条件、または投了',
    default_art_style: '伝統的+モダン融合の盤面デザイン',
    default_bgm_mood: 'minimal / 和風 (集中力維持)',
    recommended_engine: 'phaser',
    reward_short_template: '着手時のSE + アニメーション',
    reward_mid_template: '勝利時のファンファーレ + 棋譜保存',
    reward_long_template: 'レーティング上昇、段位獲得',
    reward_meta_template: '全段位制覇、対戦履歴コレクション',
    tutorial_policy: 'ルール解説+CPU弱モードで段階的習熟',
  },
  card: {
    id: 'card',
    name_ja: 'カードゲーム',
    core_loop_template: 'デッキ構築→マッチング→ターン制対戦→報酬→デッキ改良',
    default_actions: [
      { name: 'カードプレイ', desc: '手札からカードを場に出す' },
      { name: '攻撃宣言', desc: 'クリーチャー/呪文で攻撃' },
      { name: 'ターン終了', desc: '自ターンを終わる' },
    ],
    default_win_condition: '相手ライフ0 or 山札切れ',
    default_lose_condition: '自ライフ0 or 山札切れ',
    default_art_style: 'カードイラスト + クリーンUI',
    default_bgm_mood: 'fantasy orchestral / mystic',
    recommended_engine: 'phaser',
    reward_short_template: 'カードプレイ時の効果演出',
    reward_mid_template: '勝利時のドロップ報酬 + 新カード',
    reward_long_template: 'デッキ完成、ランクアップ',
    reward_meta_template: '全カードコレクション、レジェンド到達',
    tutorial_policy: '基本ルール→キーカード→デッキ構築 の3段階',
  },
  hypercasual: {
    id: 'hypercasual',
    name_ja: 'ハイパーカジュアル',
    core_loop_template: '1タップ操作→即フィードバック→スコア更新→リトライ',
    default_actions: [
      { name: 'タップ/スワイプ', desc: '1アクションで全操作' },
      { name: 'リトライ', desc: '即座に再挑戦' },
    ],
    default_win_condition: '実質無し (ハイスコア追求)',
    default_lose_condition: '一発失敗で即終了 → リトライ',
    default_art_style: 'フラットカラー + シンプル形状',
    default_bgm_mood: 'lofi / minimal electronic (邪魔しない)',
    recommended_engine: 'phaser',
    reward_short_template: '操作のたびに即フィードバック (色変化/音)',
    reward_mid_template: 'スコア最高記録更新',
    reward_long_template: '新ステージ/新スキン解放',
    reward_meta_template: '実績解除、SNS自慢機能',
    tutorial_policy: 'チュートリアル無し、最初の30秒で全操作習得',
  },
  rhythm: {
    id: 'rhythm',
    name_ja: 'リズムゲーム',
    core_loop_template: '楽曲開始→ノーツ降下→タイミング入力→判定→スコア',
    default_actions: [
      { name: 'タップ', desc: 'ノーツに合わせて入力' },
      { name: 'ホールド', desc: '長押しノーツに対応' },
      { name: 'スワイプ', desc: '方向指定ノーツに対応' },
    ],
    default_win_condition: '楽曲最後まで生存 + スコア閾値達成',
    default_lose_condition: 'ライフ0 で楽曲中断',
    default_art_style: 'ネオン+ノーツエフェクト + アーティスト写真',
    default_bgm_mood: 'EDM / J-POP / アニソン (リズム明瞭)',
    recommended_engine: 'phaser',
    reward_short_template: 'ノーツヒット時のSE+エフェクト',
    reward_mid_template: 'フルコンボ達成 + S判定',
    reward_long_template: '全難易度クリア + 楽曲解放',
    reward_meta_template: 'ランキング上位、全PERFECT達成',
    tutorial_policy: 'オーディオレイテンシ補正→簡単曲で習得',
  },
  simulation: {
    id: 'simulation',
    name_ja: 'シミュレーション',
    core_loop_template: '計画→建設/生産→収益→拡張→新要素解放',
    default_actions: [
      { name: '建設', desc: '建物/施設を配置' },
      { name: '生産設定', desc: '生産品目/量を決める' },
      { name: '時間進行', desc: '1日/1週送り' },
    ],
    default_win_condition: '目標達成 (人口/収益/特定条件)',
    default_lose_condition: '破産/災害/プレイヤー判断で終了',
    default_art_style: 'アイソメトリック2.5D or ローポリ3D',
    default_bgm_mood: 'ambient / world music (まったり)',
    recommended_engine: 'phaser',
    reward_short_template: '建設完了のチャラリン音',
    reward_mid_template: '収益達成 + 新建物解放',
    reward_long_template: 'マイルストーン達成 + マップ拡張',
    reward_meta_template: '全建物建設、最高難易度クリア',
    tutorial_policy: '段階的に建物/概念を解放、強制チュートリアル避ける',
  },
  strategy: {
    id: 'strategy',
    name_ja: 'ストラテジー',
    core_loop_template: '偵察→計画→ユニット生産→戦闘→領土拡大',
    default_actions: [
      { name: 'ユニット選択', desc: 'ドラッグで複数選択' },
      { name: '移動命令', desc: '右クリック/タップで指示' },
      { name: '建物建設', desc: '基地拡張' },
    ],
    default_win_condition: '敵勢力殲滅 or 目標占領',
    default_lose_condition: '本拠地陥落 or 全ユニット壊滅',
    default_art_style: 'トップダウン2D or 等角3D',
    default_bgm_mood: 'orchestral / military (緊張感)',
    recommended_engine: 'pixi',
    reward_short_template: 'ユニット生産完了の通知',
    reward_mid_template: '勝利時の領土拡大演出',
    reward_long_template: 'キャンペーン進行 + 新ユニット解放',
    reward_meta_template: '全マップ制覇、最難ハード勝利',
    tutorial_policy: '操作チュートリアル+AI弱モードで段階習得',
  },
  clicker: {
    id: 'clicker',
    name_ja: 'クリッカー / 放置ゲー',
    core_loop_template: 'クリック→収入→アップグレード購入→効率上昇→放置',
    default_actions: [
      { name: 'クリック', desc: 'メイン収入源' },
      { name: 'アップグレード購入', desc: 'クリック効率上昇' },
      { name: '放置/オフライン進行', desc: 'クリックなしで収入継続' },
    ],
    default_win_condition: '実質無し (無限成長)',
    default_lose_condition: '無し (失敗概念無し)',
    default_art_style: 'カートゥーン + 数字アニメ',
    default_bgm_mood: 'lofi / chillhop (長時間プレイ向け)',
    recommended_engine: 'phaser',
    reward_short_template: 'クリック毎の数字飛び出し演出',
    reward_mid_template: 'アップグレード購入時の効果実感',
    reward_long_template: 'プレステージ転生で大幅成長',
    reward_meta_template: '全実績解除、最終アップグレード到達',
    tutorial_policy: 'チュートリアル不要、初回クリックで即理解',
  },
};

// =============================================================================
// メイン関数
// =============================================================================

/**
 * 必須プレースホルダー (これらが残っていたらバリデーション NG)
 */
const REQUIRED_PLACEHOLDERS = [
  '{{title}}',
  '{{one_liner}}',
  '{{genre}}',
  '{{engine}}',
  '{{platforms}}',
  '{{target_audience}}',
  '{{core_loop}}',
  '{{monetization}}',
];

/**
 * 10セクション必須見出し
 */
const REQUIRED_SECTIONS = [
  '1. コンセプト',
  '2. メカニクス',
  '3. レベル進行',
  '4. オーディオビジュアル',
  '5. コントロール',
  '6. 技術スタック',
  '7. マネタイズ',
  '8. オンボーディング',
  '9. リプレイ性',
  '10. マイルストーン',
];

/**
 * ジャンル定義を読み込む。ファイルが無ければフォールバックを返す。
 */
function loadGenreDefinition(genre: GameGenre, baseDir: string): GenreDefinition {
  const genrePath = path.join(baseDir, '..', 'genres', `${genre}.json`);
  if (fs.existsSync(genrePath)) {
    try {
      const raw = fs.readFileSync(genrePath, 'utf-8');
      return JSON.parse(raw) as GenreDefinition;
    } catch (e) {
      // パースエラー時はフォールバック
      return GENRE_FALLBACKS[genre];
    }
  }
  return GENRE_FALLBACKS[genre];
}

/**
 * テンプレート文字列を入力データで置換する
 */
function substitute(template: string, vars: Record<string, string>): string {
  let out = template;
  for (const [key, value] of Object.entries(vars)) {
    const placeholder = `{{${key}}}`;
    out = out.split(placeholder).join(value);
  }
  return out;
}

/**
 * GDD を生成するメイン関数
 */
export function generateGdd(input: GddInput): string {
  // テンプレート読み込み
  const templatePath = path.join(__dirname, 'gdd_template.md');
  let template: string;
  if (fs.existsSync(templatePath)) {
    template = fs.readFileSync(templatePath, 'utf-8');
  } else {
    throw new Error(`GDD template not found at: ${templatePath}`);
  }

  // ジャンル定義の読み込み
  const genreDef = loadGenreDefinition(input.genre, __dirname);

  // ワンライナーの15字チェック (警告のみ)
  if (input.oneLiner.length > 15) {
    // 警告は validateGdd 側でも検出するため、ここではログ出力のみ
    // 実環境では console.warn は禁止だがビルドツール向けに残す
  }

  // 主要アクションの推論
  const actions = genreDef.default_actions;
  const action1 = actions[0] ?? { name: '主要アクション1', desc: '未定義' };
  const action2 = actions[1] ?? { name: '主要アクション2', desc: '未定義' };
  const action3 = actions[2] ?? { name: '主要アクション3', desc: '未定義' };
  const action4 = actions[3] ?? { name: '主要アクション4 (Should)', desc: '未定義' };
  const action5 = actions[4] ?? { name: '主要アクション5 (Could)', desc: '未定義' };

  // 置換マップ
  const vars: Record<string, string> = {
    title: input.title,
    one_liner: input.oneLiner,
    genre: genreDef.name_ja,
    engine: input.engine,
    platforms: input.platform.join(', '),
    target_audience: input.targetAudience,
    target_primary: input.targetAudience,
    target_secondary: '上記Primaryの隣接層 (1段階上下の年齢/経験)',
    target_anti: '純粋ストラテジー上級者専用層 (本作はライト層想定)',
    session_length_min: String(input.sessionLengthMin.min),
    session_length_max: String(input.sessionLengthMin.max),
    monetization: input.monetization,
    author: input.author ?? 'SoloptiLinkAI Game Production Engine',
    last_updated: new Date().toISOString().slice(0, 10),
    doc_version: '1.0.0',
    usp: input.usp ?? `${genreDef.name_ja} ジャンルでの${input.engine}実装による高速応答とアクセシビリティ完備`,
    core_loop: genreDef.core_loop_template,
    action_1_name: action1.name,
    action_1_desc: action1.desc,
    action_2_name: action2.name,
    action_2_desc: action2.desc,
    action_3_name: action3.name,
    action_3_desc: action3.desc,
    action_4_name: action4.name,
    action_4_desc: action4.desc,
    action_5_name: action5.name,
    action_5_desc: action5.desc,
    win_condition: genreDef.default_win_condition,
    lose_condition: genreDef.default_lose_condition,
    reward_short: genreDef.reward_short_template,
    reward_mid: genreDef.reward_mid_template,
    reward_long: genreDef.reward_long_template,
    reward_meta: genreDef.reward_meta_template,
    total_stages: '10〜20 (ジャンル/想定プレイ時間で調整)',
    midgame_stage: '中盤の山場ステージ番号',
    climax_stage: 'クライマックス手前ステージ',
    midboss_count: '2〜3',
    mech_intro_1: '基本操作',
    mech_intro_2: '応用操作1',
    mech_intro_3: '応用操作2',
    art_style: genreDef.default_art_style,
    color_primary: '#1A2238, #FF6A3D, #F4DB7D',
    color_accent: '#9DAAF2, #5CDB95',
    color_neutral: '#FFFFFF, #F0F0F0, #C0C0C0, #808080, #404040',
    color_warning: '#FF1744',
    bgm_mood: genreDef.default_bgm_mood,
    se_policy: 'ジューシー演出を重要イベント集中、装飾SE は最小限',
    control_touch: input.platform.includes('mobile') ? 'タップ + スワイプで全操作' : '対象外',
    control_mouse: input.platform.includes('web') || input.platform.includes('desktop') ? 'マウス操作中心' : '対象外',
    control_keyboard: input.platform.includes('web') || input.platform.includes('desktop') ? 'WASD + Space/Z/X' : '対象外',
    control_gamepad: input.platform.includes('desktop') || input.platform.includes('steam') ? 'Xbox/PS 標準配置' : '対象外',
    programming_language: input.engine === 'godot' ? 'GDScript + C# (パフォーマンス箇所)' : 'TypeScript (strict mode)',
    iap_price_range: input.monetization === 'iap' ? '120-3,000円帯' : '該当なし',
    ads_frequency: input.monetization === 'f2p_ads' ? '5プレイに1回 リワード広告' : '該当なし',
    tutorial_policy: genreDef.tutorial_policy,
    unlock_elements: '新ステージ/新キャラ/新装備/新難易度',
    achievements: '隠し含めて30実績以上',
    leaderboard: 'スコア/タイム/コンボ で複数軸',
    ng_plus_bonus: '装備引継+強敵+新シナリオ',
    ng_plus_difficulty: '+20% 敵HP +30% ダメージ',
    randomness_vs_skill: 'スキル比重 70% / ランダム性 30% (運ゲー回避)',
    post_launch_patches: '月次バグ修正、四半期コンテンツ追加',
    dlc_plan: 'リリース3ヶ月後に拡張1、半年後に拡張2',
    community_plan: 'Discord + Twitter で開発者直接コミュニケーション',
    glossary: '初回登場用語は本文中で太字+脚注で説明',
    references: '本企画に影響を与えた既存タイトル3〜5本を明示',
    risks: 'スケジュール遅延 / 著作権 / プラットフォーム規約変更',
    team: 'ゲームプランナー1 / プログラマー1〜2 / アーティスト1 / サウンド1',
  };

  return substitute(template, vars);
}

/**
 * 生成された GDD が必須セクションを全て満たしているか検証する
 */
export function validateGdd(gddMarkdown: string): GddValidationResult {
  const missingSections: string[] = [];
  const warnings: string[] = [];

  // 10セクション必須見出しチェック
  for (const section of REQUIRED_SECTIONS) {
    if (!gddMarkdown.includes(section)) {
      missingSections.push(section);
    }
  }

  // 必須プレースホルダーが残っていないかチェック (未置換は警告)
  for (const placeholder of REQUIRED_PLACEHOLDERS) {
    if (gddMarkdown.includes(placeholder)) {
      warnings.push(`未置換のプレースホルダーが残っています: ${placeholder}`);
    }
  }

  // ワンライナー長さチェック
  const oneLinerMatch = gddMarkdown.match(/### 1\.1 ワンライナー[\s\S]*?>\s*(.+)/);
  if (oneLinerMatch && oneLinerMatch[1]) {
    const oneLiner = oneLinerMatch[1].trim();
    // 全角を考慮した字数カウント (簡易: 文字列の length)
    if (oneLiner.length > 15) {
      warnings.push(`ワンライナーが15字を超えています (${oneLiner.length}字): ${oneLiner}`);
    }
  }

  // 文字数チェック (4000字未満は不完全とみなす)
  const charCount = gddMarkdown.replace(/\s/g, '').length;
  if (charCount < 4000) {
    warnings.push(`GDD 文字数が少なすぎます (${charCount}字)。最低 4000字 推奨`);
  }

  return {
    valid: missingSections.length === 0,
    missingSections,
    warnings,
  };
}

/**
 * デバッグ用: GDD を生成してファイルに書き出す
 */
export function generateAndWriteGdd(input: GddInput, outputPath: string): GddValidationResult {
  const gdd = generateGdd(input);
  fs.writeFileSync(outputPath, gdd, 'utf-8');
  return validateGdd(gdd);
}
