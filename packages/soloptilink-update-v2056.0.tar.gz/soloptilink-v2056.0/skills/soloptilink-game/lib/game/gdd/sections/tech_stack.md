# 6. 技術スタック 選定ガイド

## このセクションの目的

ゲームエンジン/言語/配信先を技術的根拠とともに選定する。「とりあえず Unity」のような選択は、ジャンル/プラットフォーム/チーム規模との不整合で開発中盤に致命傷を負う。

## ゲームエンジン選定マトリクス

| エンジン | 用途 | ライセンス | 推奨ジャンル | 配信先 |
|---------|-----|-----------|------------|-------|
| Phaser 3 | 2D Web カジュアル | MIT | パズル/ハイパーカジュアル/2Dアクション | Web/PWA |
| PixiJS | 高度2D描画/エフェクト | MIT | シューティング/アクション/エフェクト重視 | Web |
| Three.js | 3D Web | MIT | 3Dカジュアル/可視化系 | Web |
| Godot Web Export | 2D/3D マルチプラットフォーム | MIT | 全ジャンル/Native配信 | Web/Mobile/Desktop/Steam |

## 選定基準

### ジャンル軸
- 2Dカジュアル/モバイル → Phaser 3
- 高度2D描画/エフェクト → PixiJS
- 3D Web → Three.js
- マルチプラットフォーム/Native → Godot

### プラットフォーム軸
- Web のみ → Phaser/PixiJS/Three.js
- Mobile (iOS/Android) → Godot (Web Export も可)
- Desktop (Windows/Mac/Linux) → Godot
- Steam → Godot

### チーム規模軸
- 1〜2人 → Phaser/Godot (学習コスト低)
- 3〜5人 → Phaser/PixiJS/Godot
- 6人以上 → Godot (Native性能)

## 言語選定

- TypeScript (strict mode): Phaser/PixiJS/Three.js プロジェクト全般
- GDScript: Godot プロジェクト
- C# (Godot 4): パフォーマンス必須箇所
- WebAssembly (Rust/C++): 物理演算/AI 等の重処理

## 配信先と要件

### Web (HTML5)
- 必須: HTTPS, PWA Manifest, Service Worker (オフライン)
- 推奨: bundle size 5MB 以下, 初回ロード3秒以内

### Mobile (iOS/Android)
- 必須: App Store / Google Play 規約遵守
- iOS: 13.0以降対応、Apple Developer Program (年$99)
- Android: API 21以降、Google Play Console ($25 一回)

### Desktop
- Windows/Mac/Linux 各種: コード署名証明書必須
- Electron / Tauri / Godot Native

### Steam
- Steamworks SDK 統合
- 個人開発者: Steam Direct ($100/タイトル)

## パフォーマンス予算

| 指標 | 目標値 | 計測方法 |
|-----|-------|---------|
| FPS | 60fps 維持 (5%タイル 55以上) | Chrome DevTools Performance |
| 入力遅延 | 16ms 以下 (1フレーム) | RAF タイムスタンプ計測 |
| ロード時間 | 3秒以内 (初回) | Network パネル |
| メモリ | リーク無し (10分プレイで増加無し) | Memory タブ |
| バンドルサイズ | 5MB 以下 (Web) | Webpack Bundle Analyzer |

## チェックリスト

- [ ] エンジン選定に技術的根拠 (ジャンル/プラットフォーム/チーム規模) が付いているか
- [ ] 言語選定がエンジンと整合しているか
- [ ] 配信先ごとに必須要件 (証明書/SDK/規約) を確認したか
- [ ] パフォーマンス予算 (FPS/遅延/ロード) を数値で定義したか
- [ ] ビルドパイプライン (dev/staging/production) を設計したか
- [ ] ソースマップが本番に漏れない設定か
- [ ] アセットがミニファイ/圧縮されるか

## アンチパターン

- 「とりあえず Unity」 → ジャンル不一致でビルドサイズ膨張、ライセンス問題
- パフォーマンス予算未定義 → 開発後半でFPS低下発覚し全面リファクタ
- 配信先要件未確認 → リリース直前で証明書取得遅延
- 言語をエンジンと逆向きに選ぶ (例: Godot で TypeScript) → 統合コスト爆発
