/**
 * shader_complexity.ts
 * 責務: GLSL / HLSL シェーダー文字列を静的解析し、複雑度スコア(0-100)を推定する。
 *   実コンパイル(SPIR-V等)は外部ツール依存になるため、ここでは命令数+サンプラー+分岐+
 *   組み込み関数の出現頻度から経験的に推定する。
 *   game_fortress_3d.ts の rendering_budget 軸の入力として使う。
 *   - 一般値の目安: モバイル30 / デスクトップ60 / AAA 80
 */

/** 解析結果 */
export interface ShaderComplexity {
  /** 0-100 のスコア(高いほど複雑) */
  score: number;
  /** 命令数の推定(セミコロン+組み込み関数+分岐の合計) */
  instructionCountEstimate: number;
  /** texture/sampler への参照数 */
  textureSamplerCount: number;
  /** if/for/while 等の分岐数 */
  branchCount: number;
  /** 警告メッセージ(閾値超過の指摘) */
  warnings: string[];
}

/**
 * 1行コメント // 〜 と 複数行コメント /* 〜 *\/ を削除する。
 * 文字列解析の精度を上げるための前処理。
 */
function stripComments(src: string): string {
  // 複数行コメント
  let out = src.replace(/\/\*[\s\S]*?\*\//g, ' ');
  // 1行コメント
  out = out.replace(/\/\/[^\n]*/g, ' ');
  return out;
}

/**
 * GLSL/HLSL 両方で組み込み関数として扱われる代表的な関数名。
 * これらの呼び出し数を「重い命令」としてカウントする。
 */
const HEAVY_BUILTINS = [
  // 一般的な数学関数
  'sin', 'cos', 'tan', 'asin', 'acos', 'atan', 'atan2',
  'pow', 'exp', 'log', 'exp2', 'log2', 'sqrt', 'inversesqrt', 'rsqrt',
  'normalize', 'length', 'distance', 'dot', 'cross', 'reflect', 'refract',
  // テクスチャ系(別途カウントもするが命令としても重い)
  'texture', 'texture2D', 'textureLod', 'textureProj', 'textureGrad',
  'tex2D', 'tex2Dlod', 'tex2Dgrad', 'SampleLevel', 'Sample',
  // 行列系
  'mul', 'transpose', 'inverse', 'determinant',
  // パターン分岐回避用
  'mix', 'lerp', 'step', 'smoothstep', 'clamp', 'saturate',
];

/**
 * GLSL/HLSL シェーダー文字列を解析して複雑度を返す。
 * スコアの構成(0-100):
 *   - 命令数: 0命令で 0、200命令で +60
 *   - サンプラー数: 0で 0、16で +20
 *   - 分岐数: 0で 0、10で +20
 *   各上限値で打ち止め、合計を clamp(0,100) する。
 */
export function analyzeShader(glslOrHlsl: string): ShaderComplexity {
  const warnings: string[] = [];
  const src = stripComments(glslOrHlsl);

  // 1. 命令数推定: セミコロンの個数(基本ステートメント) + 組み込み関数呼び出し
  // セミコロンは for(...;...;...) 等で実命令以外もカウントするが、近似として使用。
  const semicolons = (src.match(/;/g) ?? []).length;
  let builtinCalls = 0;
  for (const fn of HEAVY_BUILTINS) {
    // 関数呼び出し: fn 直後に ( (空白許容) パターン
    const re = new RegExp(`\\b${fn}\\s*\\(`, 'g');
    const matches = src.match(re);
    if (matches) builtinCalls += matches.length;
  }
  const instructionCountEstimate = semicolons + builtinCalls;

  // 2. サンプラー(uniform sampler2D 等 / Texture2D / SamplerState)の出現
  const samplerPatterns = [
    /\bsampler[1-3]D(?:Array|Cube|Shadow)?\b/g, // GLSL
    /\bSamplerCube\b/g,
    /\bTexture2D\b/g, // HLSL
    /\bTexture3D\b/g,
    /\bTextureCube\b/g,
    /\bSamplerState\b/g,
  ];
  let textureSamplerCount = 0;
  for (const re of samplerPatterns) {
    const matches = src.match(re);
    if (matches) textureSamplerCount += matches.length;
  }
  // texture()/tex2D() 等の呼び出しを実際のサンプル動作カウントとして加算(重複は許容)
  const sampleCallRe = /\b(?:texture(?:2D|Lod|Proj|Grad)?|tex2D(?:lod|grad)?|Sample(?:Level|Grad|Cmp)?)\s*\(/g;
  const sampleCallMatches = src.match(sampleCallRe);
  if (sampleCallMatches) {
    textureSamplerCount += sampleCallMatches.length;
  }

  // 3. 分岐数(if / for / while / switch)
  const branchRe = /\b(?:if|for|while|switch)\s*\(/g;
  const branchMatches = src.match(branchRe);
  const branchCount = branchMatches ? branchMatches.length : 0;

  // スコア計算
  let score = 0;
  // 命令数: 0→0、200→60 (線形)
  score += Math.min(60, (instructionCountEstimate / 200) * 60);
  // サンプラー: 0→0、16→20
  score += Math.min(20, (textureSamplerCount / 16) * 20);
  // 分岐: 0→0、10→20
  score += Math.min(20, (branchCount / 10) * 20);
  score = Math.max(0, Math.min(100, score));

  // 警告
  if (instructionCountEstimate > 100) {
    warnings.push(`fragment shader has > 100 instructions (${instructionCountEstimate})`);
  }
  if (textureSamplerCount > 8) {
    warnings.push(`shader uses > 8 texture samplers (${textureSamplerCount}) — may cause bandwidth pressure`);
  }
  if (branchCount > 5) {
    warnings.push(`shader has > 5 dynamic branches (${branchCount}) — GPU branch divergence risk`);
  }
  if (/\bdiscard\b/.test(src)) {
    warnings.push('shader uses discard — disables early-z optimization');
  }
  if (/\bdFdx|\bdFdy|\bfwidth|\bddx|\bddy\b/.test(src)) {
    warnings.push('shader uses derivative functions — requires 2x2 fragment quads');
  }

  return {
    score: Number(score.toFixed(2)),
    instructionCountEstimate,
    textureSamplerCount,
    branchCount,
    warnings,
  };
}
