/**
 * vr_comfort_analyzer.ts
 * 責務: VR ヘッドセットのカメラ軌跡(ヘッドトラッキング)から、動揺病(motion sickness)
 *   リスクに直結する 3 指標を抽出する。
 *     - fpsDropEvents : フレーム落ち回数(90fps 基準で <85)
 *     - cameraAccelerationPeak : カメラ加速度のピーク値(m/s^2)
 *     - forcedRotationEvents : ユーザー操作によらない強制視点回転回数
 *     - interactionTargetMinSize : インタラクション可能な最小UI要素(cm)
 *   game_fortress_3d.ts の VR 3軸採点に使う。
 */

import type { VrMetrics } from './game_fortress_3d';

/** 軌跡の1フレーム分のデータ(タイムスタンプ + 位置 + 回転オイラー角) */
export interface CameraFrame {
  /** タイムスタンプ(ms) */
  ts: number;
  /** 位置(m): [x, y, z] */
  pos: [number, number, number];
  /** 回転(rad): [pitch, yaw, roll](オイラー角) */
  rot: [number, number, number];
}

/** インタラクション要素の物理サイズ(cm) */
export interface InteractionElement {
  /** 要素 ID または名前 */
  id: string;
  /** 幅(cm) */
  widthCm: number;
  /** 高さ(cm) */
  heightCm: number;
}

/**
 * 3次元ベクトルのノルムを計算する。
 */
function vec3Norm(v: [number, number, number]): number {
  return Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
}

/**
 * 隣接2フレームの差分から速度ベクトルを計算する。
 * 単位: m/s
 */
function velocity(a: CameraFrame, b: CameraFrame): [number, number, number] {
  const dt = (b.ts - a.ts) / 1000;
  if (dt <= 0) return [0, 0, 0];
  return [(b.pos[0] - a.pos[0]) / dt, (b.pos[1] - a.pos[1]) / dt, (b.pos[2] - a.pos[2]) / dt];
}

/**
 * VR ヘッドセットのカメラ軌跡を解析するクラス。
 */
export class VrComfortAnalyzer {
  /** 強制視点回転判定の閾値(rad/フレーム)。一般プレイヤーの自然な首回転は 0.04 rad/frame まで */
  private static readonly FORCED_ROTATION_THRESHOLD_RAD_PER_FRAME = 0.10;

  /** 動揺病リスク加速度閾値(m/s^2) */
  private static readonly UNCOMFORTABLE_ACCEL_MPS2 = 5.0;

  /**
   * カメラ軌跡を解析して VrMetrics を返す。
   * @param cameraTrajectory ヘッドセット軌跡(時系列フレーム配列)
   * @param fpsHistory フレームレート履歴(オプション、無ければ 0 で計測)
   * @param interactionElements UI 要素一覧(最小サイズ計測用、オプション)
   */
  analyzeMotion(
    cameraTrajectory: CameraFrame[],
    fpsHistory: number[] = [],
    interactionElements: InteractionElement[] = [],
  ): VrMetrics {
    // 1. fpsDropEvents: 90fps 基準で <85 になった回数
    let fpsDropEvents = 0;
    for (const fps of fpsHistory) {
      if (fps < 85) fpsDropEvents++;
    }

    // 2. cameraAccelerationPeak: 加速度ベクトルのノルムの最大値
    let cameraAccelerationPeak = 0;
    if (cameraTrajectory.length >= 3) {
      for (let i = 1; i < cameraTrajectory.length - 1; i++) {
        const v1 = velocity(cameraTrajectory[i - 1], cameraTrajectory[i]);
        const v2 = velocity(cameraTrajectory[i], cameraTrajectory[i + 1]);
        const dt = (cameraTrajectory[i + 1].ts - cameraTrajectory[i - 1].ts) / 2 / 1000;
        if (dt <= 0) continue;
        const accel: [number, number, number] = [
          (v2[0] - v1[0]) / dt,
          (v2[1] - v1[1]) / dt,
          (v2[2] - v1[2]) / dt,
        ];
        const a = vec3Norm(accel);
        if (a > cameraAccelerationPeak) cameraAccelerationPeak = a;
      }
    }

    // 3. forcedRotationEvents: フレーム間の回転変化量が閾値超過した回数
    // 注意: yaw が ±π を跨ぐと差分が 2π 近くなるため、最短経路に補正する。
    let forcedRotationEvents = 0;
    for (let i = 1; i < cameraTrajectory.length; i++) {
      const r1 = cameraTrajectory[i - 1].rot;
      const r2 = cameraTrajectory[i].rot;
      const dPitch = Math.abs(this.shortestAngle(r2[0] - r1[0]));
      const dYaw = Math.abs(this.shortestAngle(r2[1] - r1[1]));
      const dRoll = Math.abs(this.shortestAngle(r2[2] - r1[2]));
      const maxDelta = Math.max(dPitch, dYaw, dRoll);
      if (maxDelta > VrComfortAnalyzer.FORCED_ROTATION_THRESHOLD_RAD_PER_FRAME) {
        forcedRotationEvents++;
      }
    }

    // 4. interactionTargetMinSize: UI要素群の最小エッジサイズ
    let interactionTargetMinSize = Number.POSITIVE_INFINITY;
    for (const el of interactionElements) {
      const minEdge = Math.min(el.widthCm, el.heightCm);
      if (minEdge < interactionTargetMinSize) interactionTargetMinSize = minEdge;
    }
    if (!Number.isFinite(interactionTargetMinSize)) {
      // 要素未指定なら満点とみなして 5cm を返す(VR業界推奨下限)
      interactionTargetMinSize = 5.0;
    }

    return {
      fpsDropEvents,
      cameraAccelerationPeak: Number(cameraAccelerationPeak.toFixed(3)),
      forcedRotationEvents,
      interactionTargetMinSize: Number(interactionTargetMinSize.toFixed(2)),
    };
  }

  /**
   * 角度を [-π, π] の範囲に正規化(最短経路差分)。
   */
  private shortestAngle(rad: number): number {
    const TWO_PI = Math.PI * 2;
    let r = rad % TWO_PI;
    if (r > Math.PI) r -= TWO_PI;
    if (r < -Math.PI) r += TWO_PI;
    return r;
  }

  /**
   * 加速度ピークから動揺病リスクを5段階で文字列分類する(UI向け)。
   *   - none(0-1) / mild(1-2.5) / moderate(2.5-5) / severe(5-10) / critical(10+)
   */
  classifyMotionSicknessRisk(accelPeak: number): 'none' | 'mild' | 'moderate' | 'severe' | 'critical' {
    if (accelPeak < 1) return 'none';
    if (accelPeak < 2.5) return 'mild';
    if (accelPeak < VrComfortAnalyzer.UNCOMFORTABLE_ACCEL_MPS2) return 'moderate';
    if (accelPeak < 10) return 'severe';
    return 'critical';
  }

  /**
   * フレーム軌跡の総飛距離(m)を返す(セッションの活発さの参考値)。
   */
  totalDistanceMeters(cameraTrajectory: CameraFrame[]): number {
    let total = 0;
    for (let i = 1; i < cameraTrajectory.length; i++) {
      const a = cameraTrajectory[i - 1].pos;
      const b = cameraTrajectory[i].pos;
      total += vec3Norm([b[0] - a[0], b[1] - a[1], b[2] - a[2]]);
    }
    return Number(total.toFixed(3));
  }
}
