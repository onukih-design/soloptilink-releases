/**
 * game_fortress_3d.ts
 * 責務: 3D特化の Game Quality Fortress 12軸採点エンジン。
 *   v1.0 の 10軸(FPS安定性/入力遅延/ロード時間/ゲームバランス/リプレイ性/
 *   オンボーディング/AV統一感/UI/UX/アクセシビリティ/楽しさFUNスコア)を継承し、
 *   3D固有の 2軸(レンダリング予算/物理コスト)を追加して計 12軸とする。
 *   VR検出時はさらに 3軸(モーションシックネス/インタラクション明瞭性/快適性設定)を加算。
 *   各軸 0-10、合計 0-120 点(+VR時 0-150 点)で認定ランクを返す。
 *   閾値はゲーム業界標準(60fps/16ms/3秒/モバイル100kポリゴン/物理4ms 等)に準拠。
 */

// ========================================
// 共通型(v1.0 game_fortress.ts と互換)
// ========================================

/** 1軸ごとの採点結果 */
export interface AxisScore {
  /** 0-10 点 */
  score: number;
  /** 採点根拠の詳細値 */
  details: Record<string, number | string>;
  /** 合格したチェック項目 */
  passed_checks: string[];
  /** 失敗したチェック項目 */
  failed_checks: string[];
}

// ========================================
// 3D 採点メトリクス型
// ========================================

/** レンダリング系メトリクス(ポリゴン数+draw call+シェーダー複雑度+テクスチャ+GPU時間) */
export interface RenderingMetrics {
  /** 平均ポリゴン数 */
  polygonCountAvg: number;
  /** ピーク時ポリゴン数 */
  polygonCountPeak: number;
  /** 平均draw call数 */
  drawCallAvg: number;
  /** ピーク時draw call数 */
  drawCallPeak: number;
  /** シェーダー複雑度スコア(0-100、命令数ベース) */
  shaderComplexityScore: number;
  /** テクスチャメモリ使用量(MB) */
  textureMemoryMB: number;
  /** フレームあたりのGPU時間(ms) */
  gpuMsPerFrame: number;
}

/** 物理系メトリクス(物理ステップ時間+衝突検出効率) */
export interface PhysicsMetrics {
  /** 平均物理ステップ時間(ms) */
  physicsStepMsAvg: number;
  /** ピーク時物理ステップ時間(ms) */
  physicsStepMsPeak: number;
  /** 平均アクティブ剛体数 */
  activeRigidBodiesAvg: number;
  /** 平均衝突ペア数 */
  collisionPairsAvg: number;
  /** 物理アイランド数(独立した物理クラスター数) */
  islandCount: number;
}

/** VR系メトリクス(動揺病リスク+インタラクション計測) */
export interface VrMetrics {
  /** 90fps基準で <85fps になった回数 */
  fpsDropEvents: number;
  /** カメラ加速度のピーク(m/s^2) */
  cameraAccelerationPeak: number;
  /** ユーザー操作によらない強制視点回転イベント数 */
  forcedRotationEvents: number;
  /** インタラクション可能な最小ターゲットサイズ(cm) */
  interactionTargetMinSize: number;
}

/** 3D ゲーム全体メトリクス入力 */
export interface GameMetrics3D {
  // 2D 共通の10軸メトリクス
  /** 60秒分のフレームレート履歴 */
  fpsHistory: number[];
  /** 入力遅延履歴(ms) */
  inputLatencyHistory: number[];
  /** 初回ロード時間(ms) */
  loadTimeMs: number;
  /** 難易度カーブ */
  difficultyCurve: number[];
  /** チュートリアル有無 */
  hasTutorial: boolean;
  /** AV統一感(0-1) */
  audioVisualConsistency: number;
  /** UI/UXヒューリスティック(0-10) */
  uiUxScore: number;
  /** 自動プレイFUNスコア(0-10 または 0-1) */
  funScore: number;
  /** セーブ/ロード有無 */
  hasSaveLoad: boolean;
  /** リプレイ性詳細 */
  replayFeatures: {
    hasUnlocks: boolean;
    hasAchievements: boolean;
    hasRankings: boolean;
    hasNGPlus: boolean;
  };
  /** チュートリアル所要時間(分) */
  tutorialDurationMin: number;
  /** 楽しい瞬間までの時間(分) */
  firstFunMomentMin: number;
  /** UI/UX詳細 */
  uiUxDetails: {
    tapTargetMinPx: number;
    hasErrorRecovery: boolean;
    hasLoadingFeedback: boolean;
  };
  /** アクセシビリティ詳細 */
  accessibilityDetails: {
    hasColorBlindMode: boolean;
    hasFontScaling: boolean;
    hasSubtitles: boolean;
    hasKeyboardNav: boolean;
  };
  // 3D 追加メトリクス
  /** レンダリング系メトリクス */
  rendering: RenderingMetrics;
  /** 物理系メトリクス */
  physics: PhysicsMetrics;
  /** プラットフォーム種別(レンダリング採点の閾値が変わる) */
  platform: 'mobile' | 'desktop' | 'vr' | 'aaa';
  /** 目標FPS(60/90/120) */
  targetFps: 60 | 90 | 120;
  /** VR検出時のみ指定 */
  vr?: VrMetrics;
  /** VR快適性設定の有無 */
  vrComfortOptions?: {
    snapRotation: boolean;
    teleportation: boolean;
    fadeTransition: boolean;
    ipdAdjust: boolean;
  };
}

/** 3D ゲーム全体の品質スコア */
export interface GameQualityScore3D {
  /** 合計点(VR無=0-120、VR有=0-150) */
  total: number;
  /** 認定ランク */
  rank: 'Reject' | 'Bronze' | 'Silver' | 'Gold' | 'Platinum' | 'Diamond';
  /** 12軸の個別スコア */
  axes: {
    fps_stability: AxisScore;
    input_latency: AxisScore;
    load_time: AxisScore;
    game_balance: AxisScore;
    replayability: AxisScore;
    onboarding: AxisScore;
    av_consistency: AxisScore;
    ui_ux: AxisScore;
    accessibility: AxisScore;
    fun_score: AxisScore;
    rendering_budget: AxisScore;
    physics_cost: AxisScore;
  };
  /** VR検出時のみ存在する3軸 */
  vrAxes?: {
    motion_sickness_risk: AxisScore;
    interaction_clarity: AxisScore;
    comfort_settings: AxisScore;
  };
  /** 警告メッセージ一覧 */
  warnings: string[];
  /** 改善推奨一覧 */
  recommendations: string[];
  /** 採点日時 (ISO8601) */
  generated_at: string;
}

// ========================================
// 内部ユーティリティ
// ========================================

/** 0-10 の範囲にクランプ */
function clamp10(v: number): number {
  if (!Number.isFinite(v)) return 0;
  return Math.max(0, Math.min(10, v));
}

/** 線形補間: x が a→b の範囲で p→q に変化(範囲外は端点で打ち止め) */
function lerp(x: number, a: number, b: number, p: number, q: number): number {
  if (a === b) return p;
  const t = (x - a) / (b - a);
  return p + (q - p) * Math.max(0, Math.min(1, t));
}

/** 配列の平均 */
function mean(arr: number[]): number {
  if (arr.length === 0) return 0;
  return arr.reduce((s, v) => s + v, 0) / arr.length;
}

/** パーセンタイル(0-100) */
function percentile(arr: number[], p: number): number {
  if (arr.length === 0) return 0;
  const sorted = [...arr].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((p / 100) * (sorted.length - 1))));
  return sorted[idx];
}

// ========================================
// 2D 共通10軸(v1.0と同一ロジックの転記、3Dでも継承)
// ========================================

/** FPS安定性スコア(目標FPSで動的に変化) */
export function scoreFpsStability(fpsHistory: number[], targetFps: 60 | 90 | 120 = 60): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  if (fpsHistory.length === 0) {
    return { score: 0, details: { reason: 'no_samples' }, passed_checks: [], failed_checks: ['no_fps_samples_collected'] };
  }
  // 目標FPSの 50% を「下限」とする(60→30、90→45、120→60)
  const dropThreshold = targetFps * 0.5;
  const avg = mean(fpsHistory);
  const aboveTarget = fpsHistory.filter((f) => f >= targetFps).length;
  const belowDrop = fpsHistory.filter((f) => f < dropThreshold).length;
  const ratioTarget = aboveTarget / fpsHistory.length;
  const ratioDrop = belowDrop / fpsHistory.length;
  const p1 = percentile(fpsHistory, 1);
  const p99 = percentile(fpsHistory, 99);

  // 目標FPS維持率 90% で満点
  let score = lerp(ratioTarget, 0, 0.9, 0, 10);

  if (ratioDrop >= 0.3) {
    score -= 5;
    failed.push('severe_fps_drops_over_30pct');
  } else if (ratioDrop >= 0.1) {
    score -= 3;
    failed.push('fps_drops_over_10pct');
  } else {
    passed.push('low_fps_drops');
  }

  if (avg < targetFps) {
    score -= (targetFps - avg) * 0.05;
  } else {
    passed.push(`avg_fps_above_${targetFps}`);
  }
  if (ratioTarget >= 0.9) passed.push(`fps_${targetFps}_maintained_90pct`);
  else failed.push(`fps_${targetFps}_maintenance_below_90pct`);

  return {
    score: clamp10(score),
    details: {
      avg_fps: Number(avg.toFixed(2)),
      p1_fps: Number(p1.toFixed(2)),
      p99_fps: Number(p99.toFixed(2)),
      target_fps: targetFps,
      ratio_target_above: Number(ratioTarget.toFixed(4)),
      ratio_below_drop: Number(ratioDrop.toFixed(4)),
      samples: fpsHistory.length,
    },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/** 入力遅延スコア(平均16ms以下で満点、32ms以上で0) */
export function scoreInputLatency(latencyHistory: number[]): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  if (latencyHistory.length === 0) {
    return { score: 0, details: { reason: 'no_samples' }, passed_checks: [], failed_checks: ['no_latency_samples'] };
  }
  const avg = mean(latencyHistory);
  const p95 = percentile(latencyHistory, 95);
  let score = lerp(avg, 16, 32, 10, 0);
  if (avg <= 16) passed.push('avg_latency_under_16ms');
  else failed.push('avg_latency_above_16ms');
  if (p95 > 50) {
    score -= 2;
    failed.push('p95_latency_exceeds_50ms');
  } else passed.push('p95_latency_acceptable');
  return {
    score: clamp10(score),
    details: { avg_ms: Number(avg.toFixed(2)), p95_ms: Number(p95.toFixed(2)), samples: latencyHistory.length },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/** ロード時間スコア(3秒以下で満点、10秒で0) */
export function scoreLoadTime(loadTimeMs: number): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  const score = lerp(loadTimeMs, 3000, 10000, 10, 0);
  if (loadTimeMs <= 3000) passed.push('load_under_3sec');
  else if (loadTimeMs <= 10000) failed.push('load_over_3sec');
  else failed.push('load_over_10sec_unacceptable');
  return {
    score: clamp10(score),
    details: { load_ms: loadTimeMs, load_sec: Number((loadTimeMs / 1000).toFixed(2)) },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/** ゲームバランススコア(山と休憩の階段カーブが理想) */
export function scoreGameBalance(curve: number[]): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  if (curve.length < 3) {
    return { score: 5, details: { reason: 'insufficient_stages', stages: curve.length }, passed_checks: [], failed_checks: ['too_few_stages'] };
  }
  const deltas: number[] = [];
  for (let i = 1; i < curve.length; i++) deltas.push(curve[i] - curve[i - 1]);
  const increasing = deltas.filter((d) => d > 0).length;
  const monotonicity = increasing / deltas.length;
  let peaks = 0;
  let troughs = 0;
  for (let i = 1; i < deltas.length; i++) {
    if (deltas[i - 1] > 0 && deltas[i] < 0) peaks++;
    if (deltas[i - 1] < 0 && deltas[i] > 0) troughs++;
  }
  let signChanges = 0;
  for (let i = 1; i < deltas.length; i++) {
    if (Math.sign(deltas[i - 1]) !== Math.sign(deltas[i]) && deltas[i] !== 0 && deltas[i - 1] !== 0) signChanges++;
  }
  const oscillation = signChanges / Math.max(1, deltas.length - 1);
  const range = Math.max(...curve) - Math.min(...curve);
  let shape: 'flat' | 'linear' | 'staircase' | 'exponential' | 'oscillating';
  if (range < 0.1) shape = 'flat';
  else if (oscillation > 0.5) shape = 'oscillating';
  else if (monotonicity > 0.9) {
    const last = deltas[deltas.length - 1];
    const first = deltas[0];
    shape = last > first * 2 ? 'exponential' : 'linear';
  } else if (peaks >= 1 && troughs >= 1) shape = 'staircase';
  else shape = 'linear';

  let score = 10;
  if (shape === 'flat') {
    score -= 5;
    failed.push('balance_curve_flat');
  } else if (shape === 'oscillating') {
    score -= 5;
    failed.push('balance_curve_oscillating');
  } else if (shape === 'exponential') {
    score -= 3;
    failed.push('balance_curve_only_rising_steep');
  } else {
    passed.push(`balance_curve_${shape}`);
  }
  if (peaks >= 1 && peaks <= 3 && troughs >= 1 && troughs <= 3) passed.push('has_peaks_and_rests');
  else if (shape !== 'flat' && shape !== 'oscillating') {
    score -= 1;
    failed.push('lacks_rest_segments');
  }
  return {
    score: clamp10(score),
    details: {
      shape,
      stages: curve.length,
      monotonicity: Number(monotonicity.toFixed(2)),
      peaks,
      troughs,
      oscillation: Number(oscillation.toFixed(2)),
      range: Number(range.toFixed(2)),
    },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/** リプレイ性スコア(4機能×2.5点) */
export function scoreReplayability(features: {
  hasUnlocks: boolean;
  hasAchievements: boolean;
  hasRankings: boolean;
  hasNGPlus: boolean;
}): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  if (features.hasUnlocks) passed.push('has_unlocks');
  else failed.push('no_unlocks');
  if (features.hasAchievements) passed.push('has_achievements');
  else failed.push('no_achievements');
  if (features.hasRankings) passed.push('has_rankings');
  else failed.push('no_rankings');
  if (features.hasNGPlus) passed.push('has_ng_plus');
  else failed.push('no_ng_plus');
  return {
    score: clamp10(passed.length * 2.5),
    details: { features_implemented: passed.length, out_of: 4 },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/** オンボーディングスコア(3分以内で満点) */
export function scoreOnboarding(opts: { tutorialDurationMin: number; firstFunMomentMin: number }): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  let score = 10;
  if (opts.tutorialDurationMin <= 3) passed.push('tutorial_under_3min');
  else if (opts.tutorialDurationMin <= 5) {
    score -= 2;
    failed.push('tutorial_over_3min');
  } else {
    score -= 4;
    failed.push('tutorial_over_5min');
  }
  if (opts.firstFunMomentMin <= 3) passed.push('first_fun_under_3min');
  else if (opts.firstFunMomentMin <= 5) {
    score -= 2;
    failed.push('first_fun_over_3min');
  } else {
    score -= 4;
    failed.push('first_fun_over_5min');
  }
  return {
    score: clamp10(score),
    details: { tutorial_min: opts.tutorialDurationMin, first_fun_min: opts.firstFunMomentMin },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/** AV統一感スコア(0-1 を 10倍) */
export function scoreAvConsistency(score: number): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  const clamped = Math.max(0, Math.min(1, score));
  if (clamped >= 0.8) passed.push('av_consistency_high');
  else if (clamped >= 0.6) failed.push('av_consistency_medium');
  else failed.push('av_consistency_low');
  return {
    score: clamp10(clamped * 10),
    details: { raw_score: Number(clamped.toFixed(3)) },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/** UI/UXスコア */
export function scoreUiUx(opts: { tapTargetMinPx: number; hasErrorRecovery: boolean; hasLoadingFeedback: boolean }): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  let score = 10;
  if (opts.tapTargetMinPx >= 48) passed.push('tap_target_min_48px');
  else {
    score -= 3;
    failed.push('tap_target_below_48px');
  }
  if (opts.hasErrorRecovery) passed.push('has_error_recovery');
  else {
    score -= 3;
    failed.push('no_error_recovery');
  }
  if (opts.hasLoadingFeedback) passed.push('has_loading_feedback');
  else {
    score -= 2;
    failed.push('no_loading_feedback');
  }
  return {
    score: clamp10(score),
    details: {
      tap_target_px: opts.tapTargetMinPx,
      error_recovery: opts.hasErrorRecovery ? 1 : 0,
      loading_feedback: opts.hasLoadingFeedback ? 1 : 0,
    },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/** アクセシビリティスコア */
export function scoreAccessibility(opts: {
  hasColorBlindMode: boolean;
  hasFontScaling: boolean;
  hasSubtitles: boolean;
  hasKeyboardNav: boolean;
}): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  if (opts.hasColorBlindMode) passed.push('has_color_blind_mode');
  else failed.push('no_color_blind_mode');
  if (opts.hasFontScaling) passed.push('has_font_scaling');
  else failed.push('no_font_scaling');
  if (opts.hasSubtitles) passed.push('has_subtitles');
  else failed.push('no_subtitles');
  if (opts.hasKeyboardNav) passed.push('has_keyboard_nav');
  else failed.push('no_keyboard_nav');
  return {
    score: clamp10(passed.length * 2.5),
    details: { features_implemented: passed.length, out_of: 4 },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/** 楽しさFUNスコア(0-1 or 0-10) */
export function scoreFunScore(autoplayScore: number): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  let normalized: number;
  if (autoplayScore <= 1) normalized = autoplayScore * 10;
  else normalized = autoplayScore;
  const finalScore = clamp10(normalized);
  if (finalScore >= 8) passed.push('fun_score_high');
  else if (finalScore >= 6) failed.push('fun_score_medium');
  else failed.push('fun_score_low');
  return {
    score: finalScore,
    details: { raw_score: Number(autoplayScore.toFixed(2)) },
    passed_checks: passed,
    failed_checks: failed,
  };
}

// ========================================
// 3D 追加2軸: レンダリング予算+物理コスト
// ========================================

/**
 * レンダリング予算スコア
 * プラットフォーム別の閾値:
 *   - mobile : polygon <=100k / drawCall <=100 / shader <=30 / tex <=256MB / gpuMs <=8
 *   - desktop: polygon <=2M  / drawCall <=2000 / shader <=60 / tex <=2GB / gpuMs <=8
 *   - vr     : polygon <=500k / drawCall <=200  / shader <=40 / tex <=1GB / gpuMs <=11 (90fps基準)
 *   - aaa    : polygon <=10M / drawCall <=5000 / shader <=80 / tex <=8GB / gpuMs <=16
 */
export function scoreRenderingBudget(m: RenderingMetrics, target: 'mobile' | 'desktop' | 'vr' | 'aaa'): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  // プラットフォーム別予算テーブル
  const budgets: Record<typeof target, { poly: number; draw: number; shader: number; tex: number; gpuMs: number }> = {
    mobile: { poly: 100_000, draw: 100, shader: 30, tex: 256, gpuMs: 8 },
    desktop: { poly: 2_000_000, draw: 2_000, shader: 60, tex: 2048, gpuMs: 8 },
    vr: { poly: 500_000, draw: 200, shader: 40, tex: 1024, gpuMs: 11 },
    aaa: { poly: 10_000_000, draw: 5_000, shader: 80, tex: 8192, gpuMs: 16 },
  };
  const b = budgets[target];

  let score = 10;

  // ポリゴン数(平均ベース、ピークは別途減点)
  if (m.polygonCountAvg <= b.poly) passed.push('polygon_budget_ok');
  else {
    const over = m.polygonCountAvg / b.poly;
    score -= Math.min(3, (over - 1) * 5);
    failed.push(`polygon_over_${(over).toFixed(2)}x_budget`);
  }
  if (m.polygonCountPeak > b.poly * 2) {
    score -= 1;
    failed.push('polygon_peak_over_2x_budget');
  }

  // draw call
  if (m.drawCallAvg <= b.draw) passed.push('draw_call_budget_ok');
  else {
    const over = m.drawCallAvg / b.draw;
    score -= Math.min(3, (over - 1) * 5);
    failed.push(`draw_call_over_${over.toFixed(2)}x_budget`);
  }
  if (m.drawCallPeak > b.draw * 1.5) {
    score -= 0.5;
    failed.push('draw_call_peak_high');
  }

  // シェーダー複雑度
  if (m.shaderComplexityScore <= b.shader) passed.push('shader_complexity_ok');
  else {
    score -= Math.min(2, (m.shaderComplexityScore - b.shader) / 20);
    failed.push('shader_too_complex');
  }

  // テクスチャメモリ
  if (m.textureMemoryMB <= b.tex) passed.push('texture_memory_ok');
  else {
    score -= 1;
    failed.push('texture_memory_over_budget');
  }

  // GPU時間(フレーム予算 16.67ms 60fps / 11.11ms 90fps を超えるとフレーム落ち)
  if (m.gpuMsPerFrame <= b.gpuMs) passed.push('gpu_ms_within_budget');
  else {
    score -= Math.min(3, (m.gpuMsPerFrame - b.gpuMs) * 0.5);
    failed.push('gpu_ms_over_budget');
  }

  return {
    score: clamp10(score),
    details: {
      target_platform: target,
      polygon_avg: m.polygonCountAvg,
      polygon_peak: m.polygonCountPeak,
      polygon_budget: b.poly,
      draw_call_avg: m.drawCallAvg,
      draw_call_peak: m.drawCallPeak,
      draw_call_budget: b.draw,
      shader_complexity: m.shaderComplexityScore,
      shader_budget: b.shader,
      texture_mb: m.textureMemoryMB,
      texture_budget_mb: b.tex,
      gpu_ms: m.gpuMsPerFrame,
      gpu_budget_ms: b.gpuMs,
    },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/**
 * 物理コストスコア
 * - 目標FPS のフレーム予算(60→16.67ms / 90→11.11ms / 120→8.33ms)に対し
 *   物理ステップが占める割合で採点。
 * - 平均 4ms 以下で満点、16ms 以上で 0。
 * - 衝突ペア過多/剛体過多はピーク減点。
 */
export function scorePhysicsCost(m: PhysicsMetrics, targetFps: 60 | 90 | 120): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  // フレーム予算
  const frameBudgetMs = 1000 / targetFps;

  // 平均ステップ 4ms→10点、16ms→0点
  let score = lerp(m.physicsStepMsAvg, 4, 16, 10, 0);

  if (m.physicsStepMsAvg <= 4) passed.push('physics_step_under_4ms');
  else if (m.physicsStepMsAvg <= 8) failed.push('physics_step_over_4ms');
  else failed.push('physics_step_over_8ms_critical');

  // ピーク値減点
  if (m.physicsStepMsPeak > frameBudgetMs * 0.5) {
    score -= 1.5;
    failed.push('physics_peak_consumes_over_50pct_frame_budget');
  } else passed.push('physics_peak_acceptable');

  // 剛体数(1000以上で減点 = broadphase 最適化不十分)
  if (m.activeRigidBodiesAvg > 1000) {
    score -= 1;
    failed.push('too_many_active_rigid_bodies');
  } else passed.push('rigid_body_count_ok');

  // 衝突ペア数(剛体数 × 5 を超えると非効率)
  if (m.collisionPairsAvg > m.activeRigidBodiesAvg * 5 && m.activeRigidBodiesAvg > 0) {
    score -= 1;
    failed.push('collision_pairs_explosion');
  } else passed.push('collision_pairs_reasonable');

  // アイランド数 (1だと完全直列化で並列化不可、剛体数の1/100程度が理想)
  if (m.islandCount < 2 && m.activeRigidBodiesAvg > 10) {
    score -= 0.5;
    failed.push('single_physics_island_no_parallelism');
  } else passed.push('multiple_islands_parallelizable');

  return {
    score: clamp10(score),
    details: {
      step_avg_ms: Number(m.physicsStepMsAvg.toFixed(2)),
      step_peak_ms: Number(m.physicsStepMsPeak.toFixed(2)),
      frame_budget_ms: Number(frameBudgetMs.toFixed(2)),
      active_bodies: m.activeRigidBodiesAvg,
      collision_pairs: m.collisionPairsAvg,
      islands: m.islandCount,
    },
    passed_checks: passed,
    failed_checks: failed,
  };
}

// ========================================
// VR 追加3軸: 動揺病/インタラクション明瞭性/快適性設定
// ========================================

/**
 * モーションシックネスリスクスコア
 * - fpsDropEvents (90fps→85以下に落ちた数) 0 で満点
 * - cameraAccelerationPeak 5 m/s^2 以上は動揺病要因
 * - forcedRotationEvents 0 で満点(強制視点回転は最悪因)
 */
export function scoreMotionSicknessRisk(m: VrMetrics): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  let score = 10;

  // FPS ドロップ: 1分(60秒)あたり 0回で満点、10回で -3
  if (m.fpsDropEvents === 0) passed.push('no_fps_drops');
  else if (m.fpsDropEvents <= 3) {
    score -= 1;
    failed.push('minor_fps_drops');
  } else if (m.fpsDropEvents <= 10) {
    score -= 3;
    failed.push('moderate_fps_drops');
  } else {
    score -= 5;
    failed.push('severe_fps_drops_motion_sickness_risk');
  }

  // カメラ加速度ピーク
  // 2 m/s^2 以下: 自然 / 5 m/s^2 以下: 注意 / それ以上: 即動揺病
  if (m.cameraAccelerationPeak <= 2) passed.push('camera_acceleration_low');
  else if (m.cameraAccelerationPeak <= 5) {
    score -= 1.5;
    failed.push('camera_acceleration_moderate');
  } else {
    score -= 4;
    failed.push('camera_acceleration_severe_motion_sickness');
  }

  // 強制視点回転(ユーザー視点を勝手に動かす事象=最悪因)
  if (m.forcedRotationEvents === 0) passed.push('no_forced_rotation');
  else {
    score -= Math.min(3, m.forcedRotationEvents * 1.5);
    failed.push('forced_camera_rotation_detected');
  }

  return {
    score: clamp10(score),
    details: {
      fps_drop_events: m.fpsDropEvents,
      camera_accel_peak_mps2: Number(m.cameraAccelerationPeak.toFixed(2)),
      forced_rotation_events: m.forcedRotationEvents,
    },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/**
 * インタラクション明瞭性スコア
 * - VRボタン/掴み対象は最低 5cm 四方が業界推奨
 * - 3cm 未満は失格レベル
 */
export function scoreInteractionClarity(m: VrMetrics): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  let score = 10;

  const sizeCm = m.interactionTargetMinSize;
  if (sizeCm >= 5) {
    passed.push('interaction_target_5cm_or_more');
  } else if (sizeCm >= 3) {
    score -= 4;
    failed.push('interaction_target_below_5cm');
  } else {
    score -= 7;
    failed.push('interaction_target_below_3cm_unusable');
  }

  return {
    score: clamp10(score),
    details: {
      min_target_cm: Number(sizeCm.toFixed(2)),
      recommended_cm: 5,
    },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/**
 * 快適性設定スコア
 * - VR業界推奨: スナップ回転/テレポート/フェード遷移/IPD調整 の4要件
 * - 4つ全部で満点(10)、3つで7、2つで4、1つで2、0で0
 */
export function scoreComfortSettings(opts: {
  snapRotation: boolean;
  teleportation: boolean;
  fadeTransition: boolean;
  ipdAdjust: boolean;
}): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];

  if (opts.snapRotation) passed.push('has_snap_rotation');
  else failed.push('no_snap_rotation');
  if (opts.teleportation) passed.push('has_teleportation');
  else failed.push('no_teleportation');
  if (opts.fadeTransition) passed.push('has_fade_transition');
  else failed.push('no_fade_transition');
  if (opts.ipdAdjust) passed.push('has_ipd_adjust');
  else failed.push('no_ipd_adjust');

  const count = passed.length;
  // 段階配点: 0/2/4/7/10
  const table = [0, 2, 4, 7, 10];
  const score = clamp10(table[count] ?? 0);

  return {
    score,
    details: { features_implemented: count, out_of: 4 },
    passed_checks: passed,
    failed_checks: failed,
  };
}

// ========================================
// 総合採点エンジン
// ========================================

/**
 * 3D ゲームの 12軸採点(+VR時 3軸)。
 * 認定:
 *   - VR無 (max 120): 0-71 Reject / 72-95 Bronze / 96-107 Silver / 108-113 Gold / 114-117 Platinum / 118-120 Diamond
 *   - VR有 (max 150): 0-89 Reject / 90-119 Bronze / 120-134 Silver / 135-141 Gold / 142-146 Platinum / 147-150 Diamond
 */
export function scoreGame3D(metrics: GameMetrics3D): GameQualityScore3D {
  // 2D 互換10軸
  const fps = scoreFpsStability(metrics.fpsHistory, metrics.targetFps);
  const lat = scoreInputLatency(metrics.inputLatencyHistory);
  const load = scoreLoadTime(metrics.loadTimeMs);
  const balance = scoreGameBalance(metrics.difficultyCurve);
  const replay = scoreReplayability(metrics.replayFeatures);
  const onboard = scoreOnboarding({
    tutorialDurationMin: metrics.tutorialDurationMin,
    firstFunMomentMin: metrics.firstFunMomentMin,
  });
  const av = scoreAvConsistency(metrics.audioVisualConsistency);
  const uiUx = scoreUiUx(metrics.uiUxDetails);
  const a11y = scoreAccessibility(metrics.accessibilityDetails);
  const fun = scoreFunScore(metrics.funScore);

  // 3D 追加2軸
  const renderingBudget = scoreRenderingBudget(metrics.rendering, metrics.platform);
  const physicsCost = scorePhysicsCost(metrics.physics, metrics.targetFps);

  const axes = {
    fps_stability: fps,
    input_latency: lat,
    load_time: load,
    game_balance: balance,
    replayability: replay,
    onboarding: onboard,
    av_consistency: av,
    ui_ux: uiUx,
    accessibility: a11y,
    fun_score: fun,
    rendering_budget: renderingBudget,
    physics_cost: physicsCost,
  };

  // VR 追加3軸
  let vrAxes: GameQualityScore3D['vrAxes'] | undefined = undefined;
  let total = Object.values(axes).reduce((s, ax) => s + ax.score, 0);
  let maxPoints = 120;

  if (metrics.platform === 'vr' && metrics.vr) {
    const msr = scoreMotionSicknessRisk(metrics.vr);
    const ic = scoreInteractionClarity(metrics.vr);
    const cs = scoreComfortSettings(
      metrics.vrComfortOptions ?? {
        snapRotation: false,
        teleportation: false,
        fadeTransition: false,
        ipdAdjust: false,
      },
    );
    vrAxes = { motion_sickness_risk: msr, interaction_clarity: ic, comfort_settings: cs };
    total += msr.score + ic.score + cs.score;
    maxPoints = 150;
  }

  const totalRounded = Number(total.toFixed(2));

  // ランク判定(満点比率ベース)
  const ratio = totalRounded / maxPoints;
  let rank: GameQualityScore3D['rank'];
  if (ratio >= 0.98) rank = 'Diamond';
  else if (ratio >= 0.95) rank = 'Platinum';
  else if (ratio >= 0.90) rank = 'Gold';
  else if (ratio >= 0.80) rank = 'Silver';
  else if (ratio >= 0.60) rank = 'Bronze';
  else rank = 'Reject';

  // 警告/推奨の集約
  const warnings: string[] = [];
  const recommendations: string[] = [];
  for (const [name, ax] of Object.entries(axes)) {
    if (ax.score < 5) {
      warnings.push(`${name}: スコア ${ax.score.toFixed(1)}/10 が低い`);
      if (ax.failed_checks.length > 0) {
        recommendations.push(`${name}: ${ax.failed_checks.join(', ')} を改善`);
      }
    } else if (ax.score < 7) {
      recommendations.push(`${name}: スコア ${ax.score.toFixed(1)}/10 — 改善余地あり`);
    }
  }
  if (vrAxes) {
    for (const [name, ax] of Object.entries(vrAxes)) {
      if (ax.score < 5) {
        warnings.push(`VR ${name}: スコア ${ax.score.toFixed(1)}/10 が低い`);
        if (ax.failed_checks.length > 0) {
          recommendations.push(`VR ${name}: ${ax.failed_checks.join(', ')} を改善`);
        }
      } else if (ax.score < 7) {
        recommendations.push(`VR ${name}: スコア ${ax.score.toFixed(1)}/10 — 改善余地あり`);
      }
    }
  }
  if (!metrics.hasSaveLoad) recommendations.push('セーブ/ロード機能の実装を推奨');
  if (!metrics.hasTutorial) recommendations.push('チュートリアル実装を推奨');

  return {
    total: totalRounded,
    rank,
    axes,
    vrAxes,
    warnings,
    recommendations,
    generated_at: new Date().toISOString(),
  };
}
