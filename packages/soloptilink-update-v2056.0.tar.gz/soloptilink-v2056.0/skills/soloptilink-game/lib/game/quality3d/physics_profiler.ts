/**
 * physics_profiler.ts
 * 責務: 物理エンジン(Rapier/Cannon/Ammo/Bullet/Havok 等)の step 時間を実測収集し、
 *   PhysicsMetrics 形式で集計する。
 *   ゲームのメインループで物理 step の直前/直後に start/stop を呼び、内部に履歴を蓄積。
 *   stop() 時に平均/ピーク/剛体数/衝突ペア数/アイランド数を集計して返す。
 *   game_fortress_3d.ts の physics_cost 軸の入力として使う。
 */

/** physics_profiler が返す物理メトリクス */
export interface PhysicsMetrics {
  /** 平均物理ステップ時間(ms) */
  physicsStepMsAvg: number;
  /** ピーク時物理ステップ時間(ms) */
  physicsStepMsPeak: number;
  /** 平均アクティブ剛体数 */
  activeRigidBodiesAvg: number;
  /** 平均衝突ペア数 */
  collisionPairsAvg: number;
  /** 物理アイランド数 */
  islandCount: number;
}

/** 1サンプルの履歴データ */
interface PhysicsSample {
  stepMs: number;
  activeBodies: number;
  collisionPairs: number;
  islands: number;
}

/**
 * 高解像度時刻取得(performance.now → process.hrtime → Date.now の順でフォールバック)。
 * Node/ブラウザ双方で動作させるためのアダプタ。
 */
function nowMs(): number {
  // ブラウザ/Deno/Node 18+
  if (typeof performance !== 'undefined' && typeof performance.now === 'function') {
    return performance.now();
  }
  // Node legacy
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const proc = (globalThis as any).process;
  if (proc && typeof proc.hrtime === 'function') {
    const [s, ns] = proc.hrtime();
    return s * 1000 + ns / 1e6;
  }
  return Date.now();
}

/**
 * 物理ステップを計測するプロファイラ。
 * 使い方:
 *   const prof = new PhysicsProfiler();
 *   for (let frame = 0; frame < 600; frame++) {
 *     prof.start();
 *     world.step(1/60);
 *     prof.recordWorldStats(world.numActiveBodies(), world.numContactPairs(), world.numIslands());
 *     prof.stopSample();
 *   }
 *   const metrics = prof.stop();
 */
export class PhysicsProfiler {
  /** 現在のサンプル開始時刻(ms) */
  private startTime = 0;
  /** 計測中フラグ */
  private running = false;
  /** 履歴 */
  private samples: PhysicsSample[] = [];
  /** 当該サンプル中に記録された world 統計の一時保持 */
  private pendingActiveBodies = 0;
  private pendingCollisionPairs = 0;
  private pendingIslands = 0;
  /** 集計開始時刻 */
  private sessionStart = 0;

  /**
   * 計測セッションを開始する(履歴をクリア)。
   * 1セッション = 複数の step を含む計測単位。
   */
  start(): void {
    this.samples = [];
    this.sessionStart = nowMs();
    this.running = true;
  }

  /**
   * 1ステップの計測を開始する(start() のあと、各ステップの直前に呼ぶ)。
   */
  beginSample(): void {
    if (!this.running) {
      // start() を呼んでいなくても緊急的にセッション開始扱い
      this.start();
    }
    this.startTime = nowMs();
    this.pendingActiveBodies = 0;
    this.pendingCollisionPairs = 0;
    this.pendingIslands = 1;
  }

  /**
   * 物理エンジンから取得した世界統計を現サンプルに記録する。
   * (Rapier の world.numActiveBodies() 等を渡す想定)
   */
  recordWorldStats(activeBodies: number, collisionPairs: number, islands: number): void {
    this.pendingActiveBodies = activeBodies;
    this.pendingCollisionPairs = collisionPairs;
    this.pendingIslands = islands;
  }

  /**
   * 現サンプルの計測を終了する。物理ステップ完了直後に呼ぶ。
   */
  endSample(): void {
    if (!this.running || this.startTime === 0) return;
    const elapsed = nowMs() - this.startTime;
    this.samples.push({
      stepMs: elapsed,
      activeBodies: this.pendingActiveBodies,
      collisionPairs: this.pendingCollisionPairs,
      islands: this.pendingIslands,
    });
    this.startTime = 0;
  }

  /**
   * セッションを終了し、集計済みメトリクスを返す。
   */
  stop(): PhysicsMetrics {
    this.running = false;
    if (this.samples.length === 0) {
      return {
        physicsStepMsAvg: 0,
        physicsStepMsPeak: 0,
        activeRigidBodiesAvg: 0,
        collisionPairsAvg: 0,
        islandCount: 0,
      };
    }
    const total = this.samples.length;
    const stepSum = this.samples.reduce((s, x) => s + x.stepMs, 0);
    const stepPeak = this.samples.reduce((m, x) => Math.max(m, x.stepMs), 0);
    const bodiesAvg = this.samples.reduce((s, x) => s + x.activeBodies, 0) / total;
    const pairsAvg = this.samples.reduce((s, x) => s + x.collisionPairs, 0) / total;
    // アイランド数は最後のサンプルの値(動的に変化するため、現在値の代表として)
    const islandLast = this.samples[this.samples.length - 1].islands;

    return {
      physicsStepMsAvg: Number((stepSum / total).toFixed(3)),
      physicsStepMsPeak: Number(stepPeak.toFixed(3)),
      activeRigidBodiesAvg: Math.round(bodiesAvg),
      collisionPairsAvg: Math.round(pairsAvg),
      islandCount: islandLast,
    };
  }

  /**
   * 計測進捗を取得(セッション経過秒数+サンプル数)。
   */
  getProgress(): { elapsedSec: number; sampleCount: number } {
    return {
      elapsedSec: Number(((nowMs() - this.sessionStart) / 1000).toFixed(2)),
      sampleCount: this.samples.length,
    };
  }

  /**
   * 履歴を JSON 文字列として出力(デバッグ/外部解析用)。
   */
  exportJson(): string {
    return JSON.stringify(this.samples, null, 2);
  }
}
