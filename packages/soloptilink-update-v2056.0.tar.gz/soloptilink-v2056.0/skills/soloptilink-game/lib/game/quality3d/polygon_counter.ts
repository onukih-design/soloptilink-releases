/**
 * polygon_counter.ts
 * 責務: 3D シーンのポリゴン数+draw call+メッシュ/マテリアル数を計測する。
 *   サポート形式:
 *     - glTF (JSON または URL から読み込み)
 *     - three.js のシーンオブジェクト(in-memory)
 *     - Godot 4 の .tscn / .escn ファイル(テキストスキャン)
 *   3D Game Quality Fortress の rendering_budget 軸採点に必要なメトリクスを供給する。
 *   draw call 推定はマテリアル種別単位の集約で行う(三角形ストリップ等は近似)。
 */

/** glTF メッシュ計測結果 */
export interface GltfMeshStats {
  /** ポリゴン(三角形)総数 */
  polygonCount: number;
  /** メッシュ数 */
  meshCount: number;
  /** マテリアル数(draw call 推定の上限) */
  materialCount: number;
}

/** three.js シーン計測結果 */
export interface ThreeSceneStats {
  /** ポリゴン総数 */
  polygonCount: number;
  /** draw call の概算(同マテリアルの statically batched は1として数える) */
  drawCallEstimate: number;
}

/** Godot シーン計測結果 */
export interface GodotSceneStats {
  /** ポリゴン総数(MeshInstance3D のメタ情報から推定) */
  polygonCount: number;
}

/**
 * glTF 仕様の primitive のうち、ポリゴン数をインデックス(必須なら count、なければ vertex)から推定する。
 * - TRIANGLES (mode=4 or undefined) : 三角形 = count / 3
 * - TRIANGLE_STRIP (mode=5)         : 三角形 = max(0, count - 2)
 * - TRIANGLE_FAN (mode=6)           : 三角形 = max(0, count - 2)
 * - 他 (POINTS/LINES/...)           : 0 を返す
 */
function trianglesFromPrimitive(prim: any, accessors: any[]): number {
  const mode = prim.mode ?? 4; // glTF default = TRIANGLES
  // インデックスがあればその count、なければ position attribute の count
  let count = 0;
  if (typeof prim.indices === 'number' && accessors[prim.indices]) {
    count = accessors[prim.indices].count ?? 0;
  } else if (prim.attributes && typeof prim.attributes.POSITION === 'number' && accessors[prim.attributes.POSITION]) {
    count = accessors[prim.attributes.POSITION].count ?? 0;
  }
  if (count <= 0) return 0;
  switch (mode) {
    case 4: // TRIANGLES
      return Math.floor(count / 3);
    case 5: // TRIANGLE_STRIP
    case 6: // TRIANGLE_FAN
      return Math.max(0, count - 2);
    default:
      return 0;
  }
}

/**
 * PolygonCounter: 各種3Dシーン形式からポリゴン数を計測するユーティリティ集約クラス。
 */
export class PolygonCounter {
  /**
   * glTF JSON / URL からメッシュ統計を取得。
   * - 引数が string で http(s):// なら fetch、それ以外はファイルパス扱い(Node fs)。
   * - 引数が object ならそのまま JSON として解析。
   */
  static async fromGltf(gltfJsonOrUrl: string | object): Promise<GltfMeshStats> {
    let gltf: any;
    if (typeof gltfJsonOrUrl === 'string') {
      if (/^https?:\/\//i.test(gltfJsonOrUrl)) {
        // Web から取得
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        const resp = await (globalThis as any).fetch(gltfJsonOrUrl);
        gltf = await resp.json();
      } else {
        // ローカルファイル
        // eslint-disable-next-line @typescript-eslint/no-var-requires
        const fs = await import('node:fs/promises');
        const text = await fs.readFile(gltfJsonOrUrl, 'utf-8');
        gltf = JSON.parse(text);
      }
    } else {
      gltf = gltfJsonOrUrl;
    }

    const meshes: any[] = Array.isArray(gltf.meshes) ? gltf.meshes : [];
    const accessors: any[] = Array.isArray(gltf.accessors) ? gltf.accessors : [];
    const materials: any[] = Array.isArray(gltf.materials) ? gltf.materials : [];

    let polygonCount = 0;
    for (const mesh of meshes) {
      const prims: any[] = Array.isArray(mesh.primitives) ? mesh.primitives : [];
      for (const prim of prims) {
        polygonCount += trianglesFromPrimitive(prim, accessors);
      }
    }

    return {
      polygonCount,
      meshCount: meshes.length,
      materialCount: materials.length,
    };
  }

  /**
   * three.js のシーンオブジェクトからポリゴン数+draw call 推定を取得。
   * - shape: Object3D ツリーを traverse する。
   * - 同一マテリアル+InstancedMesh はまとめて1 draw call としてカウント。
   *   (ただし transparent / depth-test 違いで実際は分割されることもある近似)
   */
  static fromThreeScene(scene: any): ThreeSceneStats {
    let polygonCount = 0;
    const materialKeys = new Set<string>();
    let drawCallEstimate = 0;
    let instancedMeshCount = 0;

    if (!scene || typeof scene.traverse !== 'function') {
      return { polygonCount: 0, drawCallEstimate: 0 };
    }

    scene.traverse((obj: any) => {
      if (!obj || !obj.geometry) return;
      const geom = obj.geometry;
      // 三角形数 = インデックス数/3、なければ position attribute から
      let triangles = 0;
      if (geom.index && typeof geom.index.count === 'number') {
        triangles = Math.floor(geom.index.count / 3);
      } else if (geom.attributes && geom.attributes.position && typeof geom.attributes.position.count === 'number') {
        triangles = Math.floor(geom.attributes.position.count / 3);
      }
      // InstancedMesh の場合は inst 数倍
      if (obj.isInstancedMesh && typeof obj.count === 'number') {
        triangles *= obj.count;
        instancedMeshCount++;
      }
      polygonCount += triangles;

      // draw call 推定: マテリアルUUIDで集約
      if (obj.material) {
        const mat = obj.material;
        if (Array.isArray(mat)) {
          for (const m of mat) {
            if (m && m.uuid) materialKeys.add(m.uuid);
          }
        } else if (mat.uuid) {
          materialKeys.add(mat.uuid);
        }
      }
    });

    // draw call は「ユニークマテリアル数 + InstancedMesh数」を最低限とする
    drawCallEstimate = Math.max(materialKeys.size, instancedMeshCount);
    return { polygonCount, drawCallEstimate };
  }

  /**
   * Godot 4 のシーン(.tscn / .escn)からポリゴン数を推定する。
   * .tscn はテキスト形式で、MeshInstance3D ノードのリソース参照(mesh = ExtResource(...))から
   * メッシュリソースをカウントする。実頂点数は外部の .mesh / .res から取れないので
   * MeshInstance3D ノード数 × デフォルト想定値 100 三角形/ノードで近似する。
   * 厳密な計測が必要なら glTF エクスポート後に fromGltf を使うのが推奨。
   */
  static async fromGodotScene(scenePath: string): Promise<GodotSceneStats> {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const fs = await import('node:fs/promises');
    const text = await fs.readFile(scenePath, 'utf-8');

    // [node ... type="MeshInstance3D" ...] の数を数える
    const nodeRe = /\[node\b[^\]]*?type="MeshInstance3D"[^\]]*?\]/g;
    const meshInstanceMatches = text.match(nodeRe) ?? [];
    const meshInstanceCount = meshInstanceMatches.length;

    // メタコメントで実頂点数を埋めてあれば優先(SoloptiLink ジェネレーター用)
    // 例: # meta_triangles=1234
    const metaRe = /^\s*#\s*meta_triangles\s*=\s*(\d+)/gm;
    let polygonCount = 0;
    let metaFound = false;
    let m: RegExpExecArray | null;
    while ((m = metaRe.exec(text)) !== null) {
      polygonCount += Number(m[1]);
      metaFound = true;
    }
    if (!metaFound) {
      // フォールバック: ノード数 × 100 三角形
      polygonCount = meshInstanceCount * 100;
    }

    return { polygonCount };
  }
}
