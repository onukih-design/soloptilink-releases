/**
 * metrics_collector.ts
 * 責務: ゲーム側ブラウザに注入され、FPS/入力遅延/メモリ使用量を継続的に計測し
 *   `window.__playtest_metrics` に蓄積する。auto_player.ts から `evaluate` で
 *   この window 変数を読み取って結果に統合する。
 *   Node.js 環境で import しても型エラーにならないよう window ガードを徹底。
 *   ダミー値ではなく実フレームから算出する。
 */

/** ブラウザ側に注入される計測データの形 */
export interface PlaytestMetrics {
  /** 各秒の FPS 値 */
  fpsHistory: number[];
  /** 入力遅延 (ms) の履歴 */
  inputLatencyHistory: number[];
  /** メモリ使用量 (MB) 履歴 — Chromiumのperformance.memoryから取得 */
  memoryHistory: number[];
  /** 計測開始時刻 (performance.now()) */
  startTime: number;
  /** イベント記録 (positive/negative ヒューリスティック) */
  positiveEvents: number;
  negativeEvents: number;
  /** 計測が稼働中か */
  running: boolean;
}

/** Window 拡張型 */
declare global {
  interface Window {
    __playtest_metrics?: PlaytestMetrics;
    __playtest_collector_started?: boolean;
  }
}

/**
 * ブラウザに注入する計測スクリプト本体。
 * `start()` 後は内部で rAF ループと event listener が稼働。
 *
 * Node.js 環境では window が無いため何もしない (no-op)。
 */
export function startMetricsCollector(): void {
  if (typeof window === 'undefined' || typeof performance === 'undefined') return;
  if (window.__playtest_collector_started) return; // 二重起動防止
  window.__playtest_collector_started = true;

  // 初期化
  const metrics: PlaytestMetrics = {
    fpsHistory: [],
    inputLatencyHistory: [],
    memoryHistory: [],
    startTime: performance.now(),
    positiveEvents: 0,
    negativeEvents: 0,
    running: true,
  };
  window.__playtest_metrics = metrics;

  // ---- FPS計測 ----
  let lastSecondMark = performance.now();
  let framesThisSecond = 0;
  const fpsTick = (): void => {
    if (!metrics.running) return;
    framesThisSecond++;
    const now = performance.now();
    if (now - lastSecondMark >= 1000) {
      metrics.fpsHistory.push(framesThisSecond);
      framesThisSecond = 0;
      lastSecondMark = now;
      // メモリ使用量も同じタイミングで記録
      const mem = (performance as any).memory;
      if (mem && typeof mem.usedJSHeapSize === 'number') {
        metrics.memoryHistory.push(Math.round(mem.usedJSHeapSize / 1024 / 1024));
      }
    }
    window.requestAnimationFrame(fpsTick);
  };
  window.requestAnimationFrame(fpsTick);

  // ---- 入力遅延計測 ----
  const pending: number[] = [];
  const recordInput = (): void => {
    if (!metrics.running) return;
    pending.push(performance.now());
  };
  window.addEventListener('pointerdown', recordInput, { passive: true } as AddEventListenerOptions);
  window.addEventListener('touchstart', recordInput, { passive: true } as AddEventListenerOptions);
  window.addEventListener('keydown', recordInput, { passive: true } as AddEventListenerOptions);

  const latencyTick = (now: number): void => {
    if (!metrics.running) return;
    if (pending.length > 0) {
      for (const t of pending) {
        const lat = now - t;
        if (lat >= 0 && lat < 1000) metrics.inputLatencyHistory.push(lat);
      }
      pending.length = 0;
    }
    window.requestAnimationFrame(latencyTick);
  };
  window.requestAnimationFrame(latencyTick);

  // ---- ヒューリスティック: ポジティブ/ネガティブイベント検出 ----
  // 仕様: window.dispatchEvent(new CustomEvent('game:positive')) などを
  //   ゲーム側から発行することで記録できる。
  window.addEventListener('game:positive', () => {
    if (metrics.running) metrics.positiveEvents++;
  });
  window.addEventListener('game:negative', () => {
    if (metrics.running) metrics.negativeEvents++;
  });

  // エラーをネガティブイベントとして記録
  window.addEventListener('error', () => {
    if (metrics.running) metrics.negativeEvents++;
  });
  window.addEventListener('unhandledrejection', () => {
    if (metrics.running) metrics.negativeEvents++;
  });
}

/** 計測を停止する */
export function stopMetricsCollector(): void {
  if (typeof window === 'undefined') return;
  if (window.__playtest_metrics) {
    window.__playtest_metrics.running = false;
  }
}

/** 現在の計測結果スナップショットを取得 (主にデバッグ用) */
export function getMetricsSnapshot(): PlaytestMetrics | null {
  if (typeof window === 'undefined') return null;
  const m = window.__playtest_metrics;
  if (!m) return null;
  // 配列はコピーして返す
  return {
    fpsHistory: [...m.fpsHistory],
    inputLatencyHistory: [...m.inputLatencyHistory],
    memoryHistory: [...m.memoryHistory],
    startTime: m.startTime,
    positiveEvents: m.positiveEvents,
    negativeEvents: m.negativeEvents,
    running: m.running,
  };
}

/**
 * 注入用の <script> 文字列を生成する。
 * auto_player から page.addInitScript() で注入する用途。
 */
export function buildInjectionScript(): string {
  return `
(function() {
  if (typeof window === 'undefined') return;
  if (window.__playtest_collector_started) return;
  window.__playtest_collector_started = true;
  var metrics = {
    fpsHistory: [],
    inputLatencyHistory: [],
    memoryHistory: [],
    startTime: performance.now(),
    positiveEvents: 0,
    negativeEvents: 0,
    running: true
  };
  window.__playtest_metrics = metrics;

  var lastSec = performance.now();
  var frames = 0;
  function fpsTick() {
    if (!metrics.running) return;
    frames++;
    var now = performance.now();
    if (now - lastSec >= 1000) {
      metrics.fpsHistory.push(frames);
      frames = 0;
      lastSec = now;
      if (performance.memory && typeof performance.memory.usedJSHeapSize === 'number') {
        metrics.memoryHistory.push(Math.round(performance.memory.usedJSHeapSize / 1024 / 1024));
      }
    }
    window.requestAnimationFrame(fpsTick);
  }
  window.requestAnimationFrame(fpsTick);

  var pending = [];
  function record() { if (metrics.running) pending.push(performance.now()); }
  window.addEventListener('pointerdown', record, { passive: true });
  window.addEventListener('touchstart', record, { passive: true });
  window.addEventListener('keydown', record, { passive: true });

  function latencyTick(now) {
    if (!metrics.running) return;
    if (pending.length > 0) {
      for (var i = 0; i < pending.length; i++) {
        var lat = now - pending[i];
        if (lat >= 0 && lat < 1000) metrics.inputLatencyHistory.push(lat);
      }
      pending.length = 0;
    }
    window.requestAnimationFrame(latencyTick);
  }
  window.requestAnimationFrame(latencyTick);

  window.addEventListener('game:positive', function() { if (metrics.running) metrics.positiveEvents++; });
  window.addEventListener('game:negative', function() { if (metrics.running) metrics.negativeEvents++; });
  window.addEventListener('error', function() { if (metrics.running) metrics.negativeEvents++; });
  window.addEventListener('unhandledrejection', function() { if (metrics.running) metrics.negativeEvents++; });
})();
`.trim();
}
