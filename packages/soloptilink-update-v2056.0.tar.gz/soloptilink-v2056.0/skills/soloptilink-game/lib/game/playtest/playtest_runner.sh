#!/usr/bin/env bash
###############################################################################
# playtest_runner.sh
# 責務: プロジェクトの devサーバー起動 → URL検出 → auto_player.ts起動 →
#   結果JSON出力 → game_fortress.tsで採点 → レポート出力 を一気通貫で実行。
#   exit code: 採点80以上で0、未満で1。
###############################################################################
set -u  # 未定義変数を検出 (-eにすると後段でtrapしきれず終了するためあえて外す)

# ---- 引数解析 ----
PROJECT_DIR=""
DURATION_SEC=60
STRATEGY="random"
URL_OVERRIDE=""
SCREENSHOT_DIR=""
REPORT_DIR=""
HEADLESS="true"

usage() {
  cat <<EOF
Usage: $0 --project <dir> [--duration <sec>] [--strategy <random|spam_click|agent_planned>]
          [--url <url>] [--screenshot-dir <dir>] [--report-dir <dir>] [--no-headless]

Options:
  --project DIR          プロジェクトディレクトリ (必須)
  --duration SEC         自動プレイ継続時間 (秒、既定: 60)
  --strategy STRATEGY    プレイ戦略 (既定: random)
  --url URL              dev server URL を明示指定 (既定: 自動検出)
  --screenshot-dir DIR   スクリーンショット保存先
  --report-dir DIR       レポート保存先 (既定: <project>/playtest-report)
  --no-headless          ブラウザを表示モードで起動
EOF
}

while [[ $# -gt 0 ]]; do
  case "$1" in
    --project) PROJECT_DIR="$2"; shift 2 ;;
    --duration) DURATION_SEC="$2"; shift 2 ;;
    --strategy) STRATEGY="$2"; shift 2 ;;
    --url) URL_OVERRIDE="$2"; shift 2 ;;
    --screenshot-dir) SCREENSHOT_DIR="$2"; shift 2 ;;
    --report-dir) REPORT_DIR="$2"; shift 2 ;;
    --no-headless) HEADLESS="false"; shift ;;
    -h|--help) usage; exit 0 ;;
    *) echo "Unknown option: $1" >&2; usage; exit 2 ;;
  esac
done

if [[ -z "$PROJECT_DIR" ]]; then
  echo "Error: --project は必須です" >&2
  usage
  exit 2
fi

if [[ ! -d "$PROJECT_DIR" ]]; then
  echo "Error: プロジェクトディレクトリが存在しません: $PROJECT_DIR" >&2
  exit 2
fi

# ---- パス設定 ----
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
LIB_DIR="$( cd "$SCRIPT_DIR/.." && pwd )"
QUALITY_DIR="$LIB_DIR/quality"
PLAYTEST_DIR="$LIB_DIR/playtest"

REPORT_DIR="${REPORT_DIR:-$PROJECT_DIR/playtest-report}"
mkdir -p "$REPORT_DIR"
SCREENSHOT_DIR="${SCREENSHOT_DIR:-$REPORT_DIR/screenshots}"
mkdir -p "$SCREENSHOT_DIR"

REPORT_JSON="$REPORT_DIR/result-$(date +%Y%m%d-%H%M%S).json"
REPORT_SCORE="$REPORT_DIR/score-$(date +%Y%m%d-%H%M%S).json"
REPORT_MD="$REPORT_DIR/report-$(date +%Y%m%d-%H%M%S).md"

# ---- dev server を起動 ----
DEV_SERVER_PID=""
DEV_SERVER_URL=""

start_dev_server() {
  cd "$PROJECT_DIR" || return 1

  # package.json があるか
  if [[ ! -f "package.json" ]]; then
    echo "Warning: package.json が見つかりません。URLを直接指定してください" >&2
    return 1
  fi

  # dev または start スクリプト検出
  local script=""
  if grep -q '"dev"' package.json; then
    script="dev"
  elif grep -q '"start"' package.json; then
    script="start"
  elif grep -q '"serve"' package.json; then
    script="serve"
  else
    echo "Warning: dev/start/serve スクリプトが見つかりません" >&2
    return 1
  fi

  echo "Starting dev server: npm run $script"
  npm run "$script" > "$REPORT_DIR/dev-server.log" 2>&1 &
  DEV_SERVER_PID=$!

  # URL検出 (最大60秒待機)
  for i in $(seq 1 60); do
    sleep 1
    # ログから URL を検出
    if grep -Eo 'http://(localhost|127\.0\.0\.1):[0-9]+' "$REPORT_DIR/dev-server.log" 2>/dev/null | head -n 1 > /tmp/.playtest_url_$$ 2>/dev/null; then
      DEV_SERVER_URL=$(cat /tmp/.playtest_url_$$)
      rm -f /tmp/.playtest_url_$$
      if [[ -n "$DEV_SERVER_URL" ]]; then
        echo "Detected dev server URL: $DEV_SERVER_URL"
        return 0
      fi
    fi
  done

  echo "Error: dev server が60秒以内に起動しませんでした" >&2
  return 1
}

stop_dev_server() {
  if [[ -n "$DEV_SERVER_PID" ]] && kill -0 "$DEV_SERVER_PID" 2>/dev/null; then
    echo "Stopping dev server (PID $DEV_SERVER_PID)"
    kill "$DEV_SERVER_PID" 2>/dev/null || true
    # 子プロセスもまとめて
    pkill -P "$DEV_SERVER_PID" 2>/dev/null || true
    wait "$DEV_SERVER_PID" 2>/dev/null || true
  fi
}

trap stop_dev_server EXIT

# ---- URL確定 ----
if [[ -n "$URL_OVERRIDE" ]]; then
  DEV_SERVER_URL="$URL_OVERRIDE"
  echo "Using overridden URL: $DEV_SERVER_URL"
else
  if ! start_dev_server; then
    echo "Error: dev server を起動できませんでした" >&2
    exit 2
  fi
fi

# ---- auto_player を実行 ----
# Node.js経由でTSをロードして実行する小さなランナースクリプトを生成
RUN_SCRIPT="$REPORT_DIR/.run.mjs"
cat > "$RUN_SCRIPT" <<'NODESCRIPT'
import { register } from 'node:module';
import { pathToFileURL } from 'node:url';
import { writeFileSync } from 'node:fs';

const [,, autoPlayerPath, url, durationSecStr, strategy, screenshotDir, headlessStr, outPath] = process.argv;

// TS実行のため tsx/ts-node を試す
let loaded = false;
for (const loader of ['tsx/esm', 'ts-node/esm']) {
  try {
    register(loader, pathToFileURL('./'));
    loaded = true;
    break;
  } catch {}
}

const mod = await import(pathToFileURL(autoPlayerPath).href);
const AutoPlayer = mod.AutoPlayer;
const player = new AutoPlayer();
const result = await player.playSession(url, {
  durationSec: parseInt(durationSecStr, 10),
  strategy,
  headless: headlessStr === 'true',
  screenshotDir,
});
writeFileSync(outPath, JSON.stringify(result, null, 2));
console.log(JSON.stringify({ ok: true, driver: result.driver, crashed: result.crashed }));
NODESCRIPT

# tsx または ts-node が必要 — 不在ならコンパイル済みjsをfallback
AUTO_PLAYER_TS="$PLAYTEST_DIR/auto_player.ts"
AUTO_PLAYER_JS="$PLAYTEST_DIR/auto_player.js"

PLAYER_PATH=""
if [[ -f "$AUTO_PLAYER_JS" ]]; then
  PLAYER_PATH="$AUTO_PLAYER_JS"
elif command -v tsx >/dev/null 2>&1; then
  PLAYER_PATH="$AUTO_PLAYER_TS"
elif npx --no-install tsx --version >/dev/null 2>&1; then
  PLAYER_PATH="$AUTO_PLAYER_TS"
else
  echo "Warning: tsx も auto_player.js も見つかりません。npx tsx を試します" >&2
  PLAYER_PATH="$AUTO_PLAYER_TS"
fi

echo "Running auto player against $DEV_SERVER_URL (duration=${DURATION_SEC}s, strategy=$STRATEGY)"
if [[ "$PLAYER_PATH" == *.ts ]]; then
  if ! npx --yes tsx "$RUN_SCRIPT" "$PLAYER_PATH" "$DEV_SERVER_URL" "$DURATION_SEC" "$STRATEGY" "$SCREENSHOT_DIR" "$HEADLESS" "$REPORT_JSON"; then
    echo "Error: auto player の実行に失敗しました" >&2
    exit 2
  fi
else
  if ! node "$RUN_SCRIPT" "$PLAYER_PATH" "$DEV_SERVER_URL" "$DURATION_SEC" "$STRATEGY" "$SCREENSHOT_DIR" "$HEADLESS" "$REPORT_JSON"; then
    echo "Error: auto player の実行に失敗しました" >&2
    exit 2
  fi
fi

rm -f "$RUN_SCRIPT"

if [[ ! -f "$REPORT_JSON" ]]; then
  echo "Error: 結果JSON が生成されませんでした: $REPORT_JSON" >&2
  exit 2
fi

echo "Playtest result written: $REPORT_JSON"

# ---- スコア計算 ----
SCORE_SCRIPT="$REPORT_DIR/.score.mjs"
cat > "$SCORE_SCRIPT" <<'NODESCRIPT'
import { register } from 'node:module';
import { pathToFileURL } from 'node:url';
import { readFileSync, writeFileSync } from 'node:fs';

const [,, fortressPath, resultPath, outPath] = process.argv;

const mod = await import(pathToFileURL(fortressPath).href);
const scoreGame = mod.scoreGame;

const result = JSON.parse(readFileSync(resultPath, 'utf8'));

// プレイテスト結果 → GameMetrics
const metrics = {
  fpsHistory: result.fpsHistory ?? [],
  inputLatencyHistory: result.inputLatencyHistory ?? [],
  loadTimeMs: result.loadTimeMs ?? 0,
  hasTutorial: false,
  hasSettings: false,
  hasAccessibilityOptions: false,
  hasSaveLoad: false,
  hasReplayability: false,
  difficultyCurve: [1, 2, 3, 4, 5],  // 自動推定不可なので等差仮定
  audioVisualConsistency: result.crashed ? 0.3 : 0.7,
  uiUxScore: result.crashed ? 3 : 7,
  funScore: Math.min(10, Math.max(0,
    5 + (result.positiveEvents - result.negativeEvents) * 0.1 - (result.crashed ? 5 : 0)
  )),
};

const score = scoreGame(metrics);
writeFileSync(outPath, JSON.stringify(score, null, 2));
console.log(JSON.stringify({ total: score.total, rank: score.rank }));
NODESCRIPT

FORTRESS_TS="$QUALITY_DIR/game_fortress.ts"
FORTRESS_JS="$QUALITY_DIR/game_fortress.js"
FORTRESS_PATH=""
if [[ -f "$FORTRESS_JS" ]]; then
  FORTRESS_PATH="$FORTRESS_JS"
else
  FORTRESS_PATH="$FORTRESS_TS"
fi

if [[ "$FORTRESS_PATH" == *.ts ]]; then
  if ! npx --yes tsx "$SCORE_SCRIPT" "$FORTRESS_PATH" "$REPORT_JSON" "$REPORT_SCORE"; then
    echo "Error: スコア計算に失敗しました" >&2
    exit 2
  fi
else
  if ! node "$SCORE_SCRIPT" "$FORTRESS_PATH" "$REPORT_JSON" "$REPORT_SCORE"; then
    echo "Error: スコア計算に失敗しました" >&2
    exit 2
  fi
fi
rm -f "$SCORE_SCRIPT"

# ---- レポート生成 ----
TOTAL=$(grep -oE '"total":[[:space:]]*[0-9.]+' "$REPORT_SCORE" | head -n 1 | grep -oE '[0-9.]+' || echo "0")
RANK=$(grep -oE '"rank":[[:space:]]*"[A-Za-z]+"' "$REPORT_SCORE" | head -n 1 | grep -oE '"[A-Za-z]+"$' | tr -d '"' || echo "Reject")

cat > "$REPORT_MD" <<EOF
# Game Quality Fortress 採点レポート

- 日時: $(date '+%Y-%m-%d %H:%M:%S')
- プロジェクト: $PROJECT_DIR
- URL: $DEV_SERVER_URL
- 戦略: $STRATEGY (${DURATION_SEC}秒)

## 結果

- 合計スコア: **$TOTAL / 100**
- 認定ランク: **$RANK**

## 詳細

- プレイテスト結果: \`$REPORT_JSON\`
- スコアJSON: \`$REPORT_SCORE\`

EOF

echo ""
echo "==================== Game Quality Fortress 結果 ===================="
echo "合計: $TOTAL / 100"
echo "ランク: $RANK"
echo "レポート: $REPORT_MD"
echo "===================================================================="

# ---- exit code ----
# bashで小数比較は awk を使う
GE_80=$(awk -v t="$TOTAL" 'BEGIN { print (t >= 80) ? 1 : 0 }')
if [[ "$GE_80" == "1" ]]; then
  exit 0
else
  exit 1
fi
