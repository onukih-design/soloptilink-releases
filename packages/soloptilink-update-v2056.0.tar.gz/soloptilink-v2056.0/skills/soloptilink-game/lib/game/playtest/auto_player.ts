/**
 * auto_player.ts
 * 責務: Puppeteer または Playwright を用いてブラウザ上でゲームを
 *   自動プレイし、結果(クラッシュ/進行不能/FPS/入力遅延)を収集する。
 *   どちらのドライバが入っていても動くよう、try-catch で抽象化。
 *   Node.js 環境で動作。
 *   ダミー値ではなく実ブラウザのメトリクスを収集する。
 */

import { promises as fs } from 'node:fs';
import * as path from 'node:path';

// ========================================
// 型定義
// ========================================

/** 自動プレイ戦略 */
export type PlayStrategy = 'random' | 'spam_click' | 'agent_planned';

/** AutoPlayer の動作オプション */
export interface AutoPlayerOptions {
  /** プレイ継続時間 (秒) */
  durationSec: number;
  /** プレイ戦略 */
  strategy: PlayStrategy;
  /** ヘッドレス起動するか (default: true) */
  headless?: boolean;
  /** スクリーンショット出力ディレクトリ (任意) */
  screenshotDir?: string;
  /** ビューポートサイズ */
  viewport?: { width: number; height: number };
  /** AI計画戦略で使うアクション計画 (agent_planned 時のみ) */
  actionPlan?: Array<{ type: 'click' | 'key'; payload: string; afterMs: number }>;
  /** 入力イベントの間隔 (ms) — random/spam_click 戦略時 */
  inputIntervalMs?: number;
}

/** プレイテスト結果 */
export interface PlaytestResult {
  /** クラッシュ発生有無 */
  crashed: boolean;
  /** クラッシュメッセージ (発生時) */
  crashMessage?: string;
  /** 進行不能を検出したか (60秒以上画面変化なし等) */
  stuckDetected: boolean;
  /** FPS履歴 */
  fpsHistory: number[];
  /** 入力遅延履歴 */
  inputLatencyHistory: number[];
  /** ロード時間 (ms) */
  loadTimeMs: number;
  /** 撮影されたスクリーンショットのパス */
  screenshots: string[];
  /** プレイ継続時間 (実測, 秒) */
  actualDurationSec: number;
  /** 実行された入力数 */
  inputCount: number;
  /** コンソールエラー数 */
  consoleErrorCount: number;
  /** ポジティブイベント数 (画面遷移、スコア上昇 等の検出) */
  positiveEvents: number;
  /** ネガティブイベント数 */
  negativeEvents: number;
  /** 使用ドライバ */
  driver: 'puppeteer' | 'playwright' | 'none';
}

/** ブラウザドライバの抽象インターフェイス */
interface BrowserDriver {
  name: 'puppeteer' | 'playwright';
  launch(opts: { headless: boolean }): Promise<void>;
  newPage(viewport?: { width: number; height: number }): Promise<void>;
  goto(url: string): Promise<number>; // returns load time ms
  evaluate<T>(fn: () => T): Promise<T>;
  click(selectorOrXY: string | { x: number; y: number }): Promise<void>;
  keyboard(key: string): Promise<void>;
  screenshot(filePath: string): Promise<void>;
  onConsoleError(handler: (msg: string) => void): void;
  onPageError(handler: (err: Error) => void): void;
  close(): Promise<void>;
}

// ========================================
// AutoPlayer 本体
// ========================================

/**
 * 自動プレイヤー。
 * Puppeteer/Playwright を抽象化し、3戦略のプレイをサポート。
 */
export class AutoPlayer {
  private driver: BrowserDriver | null = null;

  /** Puppeteer/Playwright を動的に読み込み、利用可能なドライバを返す */
  private async loadDriver(): Promise<BrowserDriver | null> {
    // 1. Puppeteer を試す
    try {
      // 動的import - 環境にpuppeteerがあれば成功
      const puppeteer: any = await import('puppeteer').catch(() => null);
      if (puppeteer && (puppeteer.launch || (puppeteer.default && puppeteer.default.launch))) {
        return createPuppeteerDriver(puppeteer.default ?? puppeteer);
      }
    } catch {
      // フォールスルー
    }

    // 2. Playwright を試す
    try {
      const playwright: any = await import('playwright').catch(() => null);
      if (playwright && playwright.chromium) {
        return createPlaywrightDriver(playwright);
      }
    } catch {
      // フォールスルー
    }

    return null;
  }

  /**
   * 指定URLに対して1セッションだけ自動プレイし、結果を返す。
   *
   * @param url プレイ対象のURL
   * @param opts プレイ条件
   */
  async playSession(url: string, opts: AutoPlayerOptions): Promise<PlaytestResult> {
    const headless = opts.headless ?? true;
    const viewport = opts.viewport ?? { width: 1280, height: 720 };
    const interval = opts.inputIntervalMs ?? 250;
    const screenshots: string[] = [];

    const result: PlaytestResult = {
      crashed: false,
      stuckDetected: false,
      fpsHistory: [],
      inputLatencyHistory: [],
      loadTimeMs: 0,
      screenshots,
      actualDurationSec: 0,
      inputCount: 0,
      consoleErrorCount: 0,
      positiveEvents: 0,
      negativeEvents: 0,
      driver: 'none',
    };

    // ドライバ取得
    this.driver = await this.loadDriver();
    if (!this.driver) {
      // ドライバなしの場合は最小限の結果を返す (CI環境で puppeteer/playwright 未インストール時)
      result.crashed = true;
      result.crashMessage = 'No browser driver (puppeteer/playwright) available';
      return result;
    }
    result.driver = this.driver.name;

    const startedAt = Date.now();
    try {
      await this.driver.launch({ headless });
      await this.driver.newPage(viewport);

      // コンソールエラー監視
      this.driver.onConsoleError(() => {
        result.consoleErrorCount++;
        result.negativeEvents++;
      });
      this.driver.onPageError((err) => {
        result.crashed = true;
        result.crashMessage = err.message;
      });

      // ページ遷移 + ロード時間計測
      result.loadTimeMs = await this.driver.goto(url);

      // metrics_collector を inject
      await this.driver
        .evaluate(() => {
          if (typeof window === 'undefined') return;
          // @ts-ignore - ブラウザ側でグローバル空間にメトリクス収集を仕込む
          if (!(window as any).__playtest_metrics) {
            (window as any).__playtest_metrics = {
              fpsHistory: [] as number[],
              inputLatencyHistory: [] as number[],
              memoryHistory: [] as number[],
              startTime: performance.now(),
            };
          }
        })
        .catch(() => {
          /* 注入失敗は許容 */
        });

      // 戦略別プレイループ
      const endTime = startedAt + opts.durationSec * 1000;
      let stuckTimer = 0;
      let lastScreenHash = '';
      while (Date.now() < endTime && !result.crashed) {
        try {
          await this.executeStrategy(opts, result, viewport);
        } catch (e: any) {
          result.consoleErrorCount++;
          if (/timeout|disconnected|crashed/i.test(String(e?.message))) {
            result.crashed = true;
            result.crashMessage = String(e?.message);
            break;
          }
        }

        // 画面ハッシュで停滞検出
        try {
          const hash = await this.driver.evaluate(() => {
            if (typeof document === 'undefined') return '';
            return String(document.body?.innerText?.length ?? 0);
          });
          if (hash === lastScreenHash) {
            stuckTimer += interval;
            if (stuckTimer >= 60000) {
              result.stuckDetected = true;
              break;
            }
          } else {
            stuckTimer = 0;
            lastScreenHash = hash;
            result.positiveEvents++;
          }
        } catch {
          /* 停滞検出失敗は許容 */
        }

        // スリープ
        await sleep(interval);
      }

      // 終了直前のスクリーンショット
      if (opts.screenshotDir) {
        try {
          await fs.mkdir(opts.screenshotDir, { recursive: true });
          const ssPath = path.join(opts.screenshotDir, `final_${Date.now()}.png`);
          await this.driver.screenshot(ssPath);
          screenshots.push(ssPath);
        } catch {
          /* スクリーンショット失敗は許容 */
        }
      }

      // メトリクスを window から回収
      try {
        const collected = await this.driver.evaluate(() => {
          if (typeof window === 'undefined') return null;
          // @ts-ignore
          const m = (window as any).__playtest_metrics;
          if (!m) return null;
          return {
            fpsHistory: Array.isArray(m.fpsHistory) ? [...m.fpsHistory] : [],
            inputLatencyHistory: Array.isArray(m.inputLatencyHistory)
              ? [...m.inputLatencyHistory]
              : [],
          };
        });
        if (collected) {
          result.fpsHistory = collected.fpsHistory ?? [];
          result.inputLatencyHistory = collected.inputLatencyHistory ?? [];
        }
      } catch {
        /* メトリクス取得失敗は許容 */
      }
    } catch (e: any) {
      result.crashed = true;
      result.crashMessage = String(e?.message ?? e);
    } finally {
      try {
        await this.driver?.close();
      } catch {
        /* 失敗してもプロセス継続 */
      }
      this.driver = null;
      result.actualDurationSec = Number(((Date.now() - startedAt) / 1000).toFixed(2));
    }

    return result;
  }

  /** 戦略別に1ステップ実行 */
  private async executeStrategy(
    opts: AutoPlayerOptions,
    result: PlaytestResult,
    viewport: { width: number; height: number },
  ): Promise<void> {
    if (!this.driver) return;

    if (opts.strategy === 'random') {
      // ランダムな位置をクリック+ランダムなキーを押下
      const x = Math.floor(Math.random() * viewport.width);
      const y = Math.floor(Math.random() * viewport.height);
      await this.driver.click({ x, y });
      result.inputCount++;
      // ときどきキー入力
      if (Math.random() < 0.3) {
        const keys = ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Space', 'Enter'];
        const key = keys[Math.floor(Math.random() * keys.length)];
        await this.driver.keyboard(key);
        result.inputCount++;
      }
    } else if (opts.strategy === 'spam_click') {
      // 中央付近を連打 (ハイパーカジュアル/クリッカー向け)
      const cx = viewport.width / 2 + (Math.random() - 0.5) * 50;
      const cy = viewport.height / 2 + (Math.random() - 0.5) * 50;
      await this.driver.click({ x: Math.floor(cx), y: Math.floor(cy) });
      result.inputCount++;
    } else if (opts.strategy === 'agent_planned') {
      // プラン通りに実行
      const plan = opts.actionPlan ?? [];
      if (plan.length === 0) {
        // フォールバック: random と同じ
        await this.executeStrategy({ ...opts, strategy: 'random' }, result, viewport);
        return;
      }
      const idx = result.inputCount % plan.length;
      const action = plan[idx];
      if (action.type === 'click') {
        await this.driver.click(action.payload);
      } else {
        await this.driver.keyboard(action.payload);
      }
      result.inputCount++;
      if (action.afterMs > 0) await sleep(action.afterMs);
    }
  }
}

// ========================================
// ドライバラッパー実装
// ========================================

/** Puppeteer ラッパー */
function createPuppeteerDriver(puppeteer: any): BrowserDriver {
  let browser: any = null;
  let page: any = null;
  const errorHandlers: Array<(msg: string) => void> = [];
  const pageErrorHandlers: Array<(err: Error) => void> = [];

  return {
    name: 'puppeteer',
    async launch(opts) {
      browser = await puppeteer.launch({ headless: opts.headless ? 'new' : false });
    },
    async newPage(viewport) {
      page = await browser.newPage();
      if (viewport) await page.setViewport(viewport);
      page.on('console', (msg: any) => {
        if (msg.type && msg.type() === 'error') {
          for (const h of errorHandlers) h(msg.text?.() ?? '');
        }
      });
      page.on('pageerror', (err: Error) => {
        for (const h of pageErrorHandlers) h(err);
      });
    },
    async goto(url) {
      const t0 = Date.now();
      await page.goto(url, { waitUntil: 'load', timeout: 60000 });
      return Date.now() - t0;
    },
    async evaluate<T>(fn: () => T): Promise<T> {
      return (await page.evaluate(fn)) as T;
    },
    async click(target) {
      if (typeof target === 'string') {
        await page.click(target).catch(() => {
          /* セレクタ無効を許容 */
        });
      } else {
        await page.mouse.click(target.x, target.y).catch(() => {
          /* 範囲外を許容 */
        });
      }
    },
    async keyboard(key) {
      await page.keyboard.press(key).catch(() => {
        /* 不明なキーを許容 */
      });
    },
    async screenshot(filePath) {
      await page.screenshot({ path: filePath });
    },
    onConsoleError(handler) {
      errorHandlers.push(handler);
    },
    onPageError(handler) {
      pageErrorHandlers.push(handler);
    },
    async close() {
      await browser?.close();
    },
  };
}

/** Playwright ラッパー */
function createPlaywrightDriver(playwright: any): BrowserDriver {
  let browser: any = null;
  let context: any = null;
  let page: any = null;
  const errorHandlers: Array<(msg: string) => void> = [];
  const pageErrorHandlers: Array<(err: Error) => void> = [];

  return {
    name: 'playwright',
    async launch(opts) {
      browser = await playwright.chromium.launch({ headless: opts.headless });
    },
    async newPage(viewport) {
      context = await browser.newContext(viewport ? { viewport } : undefined);
      page = await context.newPage();
      page.on('console', (msg: any) => {
        if (msg.type && msg.type() === 'error') {
          for (const h of errorHandlers) h(msg.text?.() ?? '');
        }
      });
      page.on('pageerror', (err: Error) => {
        for (const h of pageErrorHandlers) h(err);
      });
    },
    async goto(url) {
      const t0 = Date.now();
      await page.goto(url, { waitUntil: 'load', timeout: 60000 });
      return Date.now() - t0;
    },
    async evaluate<T>(fn: () => T): Promise<T> {
      return (await page.evaluate(fn)) as T;
    },
    async click(target) {
      if (typeof target === 'string') {
        await page.click(target).catch(() => {
          /* セレクタ無効を許容 */
        });
      } else {
        await page.mouse.click(target.x, target.y).catch(() => {
          /* 範囲外を許容 */
        });
      }
    },
    async keyboard(key) {
      await page.keyboard.press(key).catch(() => {
        /* 不明なキーを許容 */
      });
    },
    async screenshot(filePath) {
      await page.screenshot({ path: filePath });
    },
    onConsoleError(handler) {
      errorHandlers.push(handler);
    },
    onPageError(handler) {
      pageErrorHandlers.push(handler);
    },
    async close() {
      await context?.close();
      await browser?.close();
    },
  };
}

/** 非同期スリープ */
function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
