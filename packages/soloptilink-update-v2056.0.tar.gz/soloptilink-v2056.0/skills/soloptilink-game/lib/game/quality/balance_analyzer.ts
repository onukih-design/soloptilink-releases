/**
 * balance_analyzer.ts
 * 責務: 各ステージ/ウェーブの難易度推定値配列からカーブ形状を分類し
 *   ゲームバランスの良し悪しを採点。
 *   単調増加性 / 山と谷の検出 / 休憩区間検出 / 振動度 をアルゴリズムで判定。
 *   ダミー値ではなく実データから算出する。
 */

/** 難易度カーブの形状 */
export type CurveShape = 'flat' | 'linear' | 'staircase' | 'exponential' | 'oscillating';

/** 難易度カーブ解析結果 */
export interface BalanceAnalysis {
  /** 形状分類 */
  shape: CurveShape;
  /** 0-10 スコア */
  score: number;
  /** 警告メッセージ */
  warnings: string[];
  /** 詳細統計 */
  stats: {
    stages: number;
    monotonicity: number; // 単調増加率 0-1
    peaks: number;         // 山の数
    troughs: number;       // 谷の数
    oscillation: number;   // 振動度 0-1
    range: number;         // レンジ (max-min)
    avg: number;
    restSegments: number;  // 休憩区間数 (横ばい以下が2つ以上連続)
    slopeAvg: number;      // 平均傾き
  };
}

/**
 * 難易度カーブを解析する。
 * @param curve 各ステージの難易度推定値 (例: 敵HP合計、敵数、必要操作数 等)
 */
export function analyzeBalance(curve: number[]): BalanceAnalysis {
  const warnings: string[] = [];

  if (curve.length < 3) {
    return {
      shape: 'flat',
      score: 5,
      warnings: ['カーブを解析するためのステージ数が不足 (最低3ステージ必要)'],
      stats: {
        stages: curve.length,
        monotonicity: 0,
        peaks: 0,
        troughs: 0,
        oscillation: 0,
        range: 0,
        avg: curve.reduce((s, v) => s + v, 0) / Math.max(1, curve.length),
        restSegments: 0,
        slopeAvg: 0,
      },
    };
  }

  // 差分列の算出
  const deltas: number[] = [];
  for (let i = 1; i < curve.length; i++) deltas.push(curve[i] - curve[i - 1]);

  // 統計
  const max = Math.max(...curve);
  const min = Math.min(...curve);
  const range = max - min;
  const avg = curve.reduce((s, v) => s + v, 0) / curve.length;

  // 単調増加性
  const increasing = deltas.filter((d) => d > 0).length;
  const monotonicity = increasing / deltas.length;

  // 山(極大点)と谷(極小点)
  let peaks = 0;
  let troughs = 0;
  for (let i = 1; i < deltas.length; i++) {
    const prev = deltas[i - 1];
    const curr = deltas[i];
    if (prev > 0 && curr < 0) peaks++;
    if (prev < 0 && curr > 0) troughs++;
  }

  // 振動度: 符号変化が多すぎる
  let signChanges = 0;
  for (let i = 1; i < deltas.length; i++) {
    if (
      Math.sign(deltas[i - 1]) !== Math.sign(deltas[i]) &&
      deltas[i] !== 0 &&
      deltas[i - 1] !== 0
    ) {
      signChanges++;
    }
  }
  const oscillation = signChanges / Math.max(1, deltas.length - 1);

  // 休憩区間: 2つ以上連続して横ばい(微小)または下降している部分
  let restSegments = 0;
  let restRun = 0;
  for (const d of deltas) {
    if (d <= 0.01 * (range || 1)) {
      restRun++;
    } else {
      if (restRun >= 2) restSegments++;
      restRun = 0;
    }
  }
  if (restRun >= 2) restSegments++;

  // 平均傾き
  const slopeAvg = deltas.reduce((s, v) => s + v, 0) / deltas.length;

  // 形状の分類
  let shape: CurveShape;
  if (range < 0.01 * Math.max(1, Math.abs(avg))) {
    shape = 'flat';
  } else if (oscillation > 0.5) {
    shape = 'oscillating';
  } else if (monotonicity > 0.9) {
    // ほぼ単調増加: 後半の傾きが前半より急なら exponential
    const halfIdx = Math.floor(deltas.length / 2);
    const firstHalfAvg =
      halfIdx > 0 ? deltas.slice(0, halfIdx).reduce((s, v) => s + v, 0) / halfIdx : 0;
    const secondHalfAvg =
      deltas.length - halfIdx > 0
        ? deltas.slice(halfIdx).reduce((s, v) => s + v, 0) / (deltas.length - halfIdx)
        : 0;
    if (secondHalfAvg > firstHalfAvg * 1.8 && secondHalfAvg > 0) shape = 'exponential';
    else shape = 'linear';
  } else if (peaks >= 1 && troughs >= 1) {
    shape = 'staircase';
  } else {
    shape = 'linear';
  }

  // 採点
  let score = 10;
  if (shape === 'flat') {
    score -= 5;
    warnings.push('難易度がフラット(変化なし)。プレイヤーが飽きやすい。');
  } else if (shape === 'oscillating') {
    score -= 5;
    warnings.push('難易度カーブが振動的。一貫した上昇感がない。');
  } else if (shape === 'exponential') {
    score -= 3;
    warnings.push('急上昇のみで休憩区間がない。後半でプレイヤーが脱落しやすい。');
  }

  // 山と谷のバランス (理想は staircase = 1-3 山 + 1-3 谷)
  if (shape !== 'flat' && shape !== 'oscillating') {
    if (peaks === 0 && troughs === 0) {
      score -= 1;
      warnings.push('山と谷がなく、メリハリに欠ける。');
    } else if (peaks > 5 || troughs > 5) {
      score -= 1;
      warnings.push('山と谷が多すぎて構成が散漫。');
    }
  }

  // 休憩区間 (0なら-1)
  if (shape !== 'flat' && restSegments === 0 && curve.length >= 5) {
    score -= 1;
    warnings.push('休憩区間が一つもなく、プレイヤーが疲弊しやすい。');
  }

  // 0-10にクランプ
  score = Math.max(0, Math.min(10, score));

  return {
    shape,
    score: Number(score.toFixed(2)),
    warnings,
    stats: {
      stages: curve.length,
      monotonicity: Number(monotonicity.toFixed(3)),
      peaks,
      troughs,
      oscillation: Number(oscillation.toFixed(3)),
      range: Number(range.toFixed(2)),
      avg: Number(avg.toFixed(2)),
      restSegments,
      slopeAvg: Number(slopeAvg.toFixed(3)),
    },
  };
}

/**
 * 既存ゲームの難易度カーブから「理想カーブ」を生成する。
 * stairs型 (1-2山+1-2休憩を含む線形上昇) を推奨カーブとして返す。
 */
export function suggestIdealCurve(stages: number, startDifficulty: number, endDifficulty: number): number[] {
  if (stages <= 1) return [startDifficulty];
  const curve: number[] = [];
  const range = endDifficulty - startDifficulty;
  for (let i = 0; i < stages; i++) {
    const base = startDifficulty + (range * i) / (stages - 1);
    // 1/3 と 2/3 の位置に小さな山、1/2 の位置に休憩を入れる
    const ratio = i / (stages - 1);
    let adjust = 0;
    if (Math.abs(ratio - 0.33) < 0.05) adjust = range * 0.05;
    else if (Math.abs(ratio - 0.5) < 0.05) adjust = -range * 0.03;
    else if (Math.abs(ratio - 0.66) < 0.05) adjust = range * 0.07;
    curve.push(Number((base + adjust).toFixed(2)));
  }
  return curve;
}
