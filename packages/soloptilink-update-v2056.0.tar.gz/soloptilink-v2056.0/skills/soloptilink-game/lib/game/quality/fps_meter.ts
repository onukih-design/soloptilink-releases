/**
 * fps_meter.ts
 * 責務: ブラウザ環境で requestAnimationFrame と performance.now を用いて
 *   毎秒のFPSをサンプリングし履歴を保持。60秒分の履歴+平均/p1/p99/dropFrames を返す。
 *   Node.js 環境でも import 可能(`typeof window !== 'undefined'` ガード)。
 *   ダミー値ではなく実フレーム時間から算出する。
 */

/** スナップショット結果 */
export interface FpsSnapshot {
  /** 各秒の fps 値の履歴 (最大60エントリ程度) */
  history: number[];
  /** 平均FPS */
  avg: number;
  /** 1パーセンタイル(下位1%、最悪フレームレート) */
  p1: number;
  /** 99パーセンタイル(上位1%、最良フレームレート) */
  p99: number;
  /** ドロップフレーム数 (1フレームでも33ms以上かかったフレーム数) */
  dropFrames: number;
  /** サンプリング期間 (ms) */
  durationMs: number;
}

/**
 * FPS計測クラス。start() で計測開始、stop() で停止、
 * getSnapshot() で履歴と統計を取得する。
 */
export class FpsMeter {
  private running = false;
  private frameStamps: number[] = [];
  private rafId: number | null = null;
  private startTime = 0;
  private lastSecondMark = 0;
  private framesThisSecond = 0;
  private fpsHistory: number[] = [];
  private dropFrames = 0;

  /** ブラウザ環境かどうかを判定 */
  private isBrowser(): boolean {
    return (
      typeof window !== 'undefined' &&
      typeof window.requestAnimationFrame === 'function' &&
      typeof performance !== 'undefined' &&
      typeof performance.now === 'function'
    );
  }

  /** 計測を開始する */
  start(): void {
    if (!this.isBrowser()) {
      // Node.js環境では何もしない(エラーにはしない)
      this.running = false;
      return;
    }
    if (this.running) return;
    this.running = true;
    this.frameStamps = [];
    this.fpsHistory = [];
    this.dropFrames = 0;
    this.startTime = performance.now();
    this.lastSecondMark = this.startTime;
    this.framesThisSecond = 0;

    const tick = (now: number): void => {
      if (!this.running) return;

      // フレーム時刻を記録
      const last = this.frameStamps[this.frameStamps.length - 1];
      if (last !== undefined) {
        const frameDelta = now - last;
        // 33ms (= 30fps 相当) を超えたフレームを drop と数える
        if (frameDelta > 33) this.dropFrames++;
      }
      this.frameStamps.push(now);
      this.framesThisSecond++;

      // 1秒境界を超えたら fps を記録
      if (now - this.lastSecondMark >= 1000) {
        this.fpsHistory.push(this.framesThisSecond);
        this.framesThisSecond = 0;
        this.lastSecondMark = now;
        // メモリリーク防止: 古いフレームスタンプを破棄(最近1秒分のみ保持)
        const cutoff = now - 1000;
        while (this.frameStamps.length > 0 && this.frameStamps[0] < cutoff) {
          this.frameStamps.shift();
        }
      }

      this.rafId = window.requestAnimationFrame(tick);
    };

    this.rafId = window.requestAnimationFrame(tick);
  }

  /** 計測を停止する */
  stop(): void {
    this.running = false;
    if (this.rafId !== null && this.isBrowser()) {
      window.cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
    // 残った今秒のフレーム数も履歴に加える(部分秒は除く)
    if (this.framesThisSecond > 0 && this.isBrowser()) {
      const elapsedInSec = (performance.now() - this.lastSecondMark) / 1000;
      if (elapsedInSec >= 0.5) {
        // 0.5秒以上経過していれば外挿
        this.fpsHistory.push(Math.round(this.framesThisSecond / elapsedInSec));
      }
    }
  }

  /** 履歴と統計のスナップショットを取得 */
  getSnapshot(): FpsSnapshot {
    const history = [...this.fpsHistory];
    const avg = history.length === 0 ? 0 : history.reduce((s, v) => s + v, 0) / history.length;
    const sorted = [...history].sort((a, b) => a - b);
    const p1 = sorted.length === 0 ? 0 : sorted[Math.max(0, Math.floor(sorted.length * 0.01))];
    const p99 =
      sorted.length === 0 ? 0 : sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * 0.99))];
    const durationMs = this.isBrowser() && this.startTime > 0 ? performance.now() - this.startTime : 0;

    return {
      history,
      avg: Number(avg.toFixed(2)),
      p1,
      p99,
      dropFrames: this.dropFrames,
      durationMs: Number(durationMs.toFixed(0)),
    };
  }

  /** 履歴を手動でリセット (テスト用) */
  reset(): void {
    this.frameStamps = [];
    this.fpsHistory = [];
    this.dropFrames = 0;
    this.framesThisSecond = 0;
    this.startTime = 0;
    this.lastSecondMark = 0;
  }
}

/**
 * シンプルな計測ヘルパー: 指定秒数だけ計測してスナップショットを返す。
 * ブラウザ環境専用。
 */
export async function measureFpsForDuration(durationSec: number): Promise<FpsSnapshot> {
  const meter = new FpsMeter();
  meter.start();
  await new Promise<void>((resolve) => {
    if (typeof window === 'undefined' || typeof setTimeout === 'undefined') {
      resolve();
      return;
    }
    setTimeout(resolve, durationSec * 1000);
  });
  meter.stop();
  return meter.getSnapshot();
}
