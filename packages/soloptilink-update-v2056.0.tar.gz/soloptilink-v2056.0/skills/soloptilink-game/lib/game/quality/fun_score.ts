/**
 * fun_score.ts
 * 責務: 自動プレイの結果(セッション継続時間/リトライ/ゲームオーバー/ポジ・ネガイベント)
 *   から「楽しさFUNスコア」を 0-10 で算出。要因分解付きで返す。
 *   ダミー値ではなく実データから算出する。
 */

/** FUNスコアの入力 */
export interface FunInput {
  /** 自動プレイのセッション継続時間 (秒) */
  sessionDurationSec: number;
  /** リトライ回数 (適度ならポジティブ、過剰ならネガティブ) */
  retryCount: number;
  /** ゲームオーバー回数 */
  gameOverCount: number;
  /** ポジティブイベント (得点、撃破、達成、レベルアップ等) */
  positiveEvents: number;
  /** ネガティブイベント (ダメージ、ペナルティ、放置等) */
  negativeEvents: number;
}

/** 要因分解 */
export interface FunFactors {
  /** 継続時間スコア (0-3点) */
  durationScore: number;
  /** エンゲージメントスコア (0-3点) */
  engagementScore: number;
  /** チャレンジバランススコア (0-2点) */
  challengeBalanceScore: number;
  /** ポジ/ネガ比スコア (0-2点) */
  emotionalScore: number;
}

/** FUNスコア結果 */
export interface FunResult {
  /** 0-10 総合スコア */
  score: number;
  /** 要因分解 */
  factors: FunFactors;
  /** 注釈メッセージ */
  notes: string[];
}

/**
 * FUNスコアを算出する。
 *
 * 重み付け:
 *   - 継続時間: 0-3点 (60秒で0.5、180秒で1.5、300秒以上で3点)
 *   - エンゲージメント: 0-3点 (ポジティブイベント密度 events/sec * 30 で算出)
 *   - チャレンジバランス: 0-2点 (リトライ数が適度=2、過剰/過小=-1)
 *   - 感情比: 0-2点 (positive / (positive + negative) を 0-2 にマップ)
 *
 * 合計 10点。
 */
export function computeFunScore(input: FunInput): FunResult {
  const notes: string[] = [];

  // 1. 継続時間スコア (0-3)
  let durationScore: number;
  if (input.sessionDurationSec >= 300) {
    durationScore = 3;
    notes.push('5分以上の継続: 高エンゲージメント');
  } else if (input.sessionDurationSec >= 180) {
    durationScore = 1.5 + ((input.sessionDurationSec - 180) / 120) * 1.5;
  } else if (input.sessionDurationSec >= 60) {
    durationScore = 0.5 + ((input.sessionDurationSec - 60) / 120) * 1.0;
    notes.push('1〜3分の継続: 中程度エンゲージメント');
  } else {
    durationScore = (input.sessionDurationSec / 60) * 0.5;
    notes.push('1分未満で離脱: 入口で躓いている可能性');
  }
  durationScore = Math.max(0, Math.min(3, durationScore));

  // 2. エンゲージメントスコア (0-3) — ポジティブイベント密度
  const eventsPerSec = input.sessionDurationSec > 0 ? input.positiveEvents / input.sessionDurationSec : 0;
  // 0.1 events/sec で1点、0.5 events/sec で3点
  let engagementScore = eventsPerSec * 6; // 0.5*6 = 3
  engagementScore = Math.max(0, Math.min(3, engagementScore));
  if (engagementScore >= 2.5) notes.push('ポジティブイベント密度が高い: 楽しさを感じやすい');
  else if (engagementScore < 1) notes.push('ポジティブイベントが乏しい: 報酬感を補強すべき');

  // 3. チャレンジバランス (0-2)
  let challengeBalanceScore: number;
  const retryRatio =
    input.gameOverCount > 0 ? input.retryCount / input.gameOverCount : input.retryCount > 0 ? 1 : 0;
  if (input.retryCount === 0 && input.gameOverCount === 0) {
    // 簡単すぎる or プレイし切らなかった
    challengeBalanceScore = 0.5;
    notes.push('ゲームオーバーもリトライもなし: 簡単すぎ or 触っていない可能性');
  } else if (retryRatio >= 0.5 && retryRatio <= 1.0 && input.retryCount <= 10) {
    // 適度なチャレンジ感
    challengeBalanceScore = 2;
    notes.push('リトライ/ゲームオーバー比が適度: 良いチャレンジ感');
  } else if (input.retryCount > 10 && retryRatio >= 0.8) {
    // 何度も挑戦するほどには面白いが厳しすぎる
    challengeBalanceScore = 1.2;
    notes.push('リトライ多発: 高難易度ループ気味');
  } else if (input.gameOverCount > 0 && input.retryCount / Math.max(1, input.gameOverCount) < 0.3) {
    // ゲームオーバーするとリトライされない
    challengeBalanceScore = 0.5;
    notes.push('ゲームオーバー後の継続率が低い: 失敗フィードバックがネガティブすぎ');
  } else {
    challengeBalanceScore = 1;
  }
  challengeBalanceScore = Math.max(0, Math.min(2, challengeBalanceScore));

  // 4. 感情比 (0-2)
  const totalEvents = input.positiveEvents + input.negativeEvents;
  let emotionalScore: number;
  if (totalEvents === 0) {
    emotionalScore = 0;
    notes.push('イベント記録なし: 計測精度に懸念');
  } else {
    const posRatio = input.positiveEvents / totalEvents;
    // 0.7以上で満点2、0.3以下で0
    emotionalScore = Math.max(0, Math.min(2, (posRatio - 0.3) * 5));
    if (posRatio >= 0.7) notes.push('ポジティブ感情優位: ユーザー体験が前向き');
    else if (posRatio < 0.3) notes.push('ネガティブイベント優位: ストレス過多の可能性');
  }

  const total = durationScore + engagementScore + challengeBalanceScore + emotionalScore;

  return {
    score: Number(Math.max(0, Math.min(10, total)).toFixed(2)),
    factors: {
      durationScore: Number(durationScore.toFixed(2)),
      engagementScore: Number(engagementScore.toFixed(2)),
      challengeBalanceScore: Number(challengeBalanceScore.toFixed(2)),
      emotionalScore: Number(emotionalScore.toFixed(2)),
    },
    notes,
  };
}

/**
 * 複数セッションの平均FUNスコアを算出する。
 */
export function aggregateFunScores(inputs: FunInput[]): FunResult {
  if (inputs.length === 0) {
    return {
      score: 0,
      factors: {
        durationScore: 0,
        engagementScore: 0,
        challengeBalanceScore: 0,
        emotionalScore: 0,
      },
      notes: ['サンプルなし'],
    };
  }
  const results = inputs.map(computeFunScore);
  const avg = (k: keyof FunFactors): number =>
    results.reduce((s, r) => s + r.factors[k], 0) / results.length;
  const avgScore = results.reduce((s, r) => s + r.score, 0) / results.length;
  return {
    score: Number(avgScore.toFixed(2)),
    factors: {
      durationScore: Number(avg('durationScore').toFixed(2)),
      engagementScore: Number(avg('engagementScore').toFixed(2)),
      challengeBalanceScore: Number(avg('challengeBalanceScore').toFixed(2)),
      emotionalScore: Number(avg('emotionalScore').toFixed(2)),
    },
    notes: [`${inputs.length}セッションの平均`],
  };
}
