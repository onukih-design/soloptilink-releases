/**
 * game_fortress.ts
 * 責務: Game Quality Fortress 10軸採点エンジンの中核。
 *   FPS安定性 / 入力遅延 / ロード時間 / ゲームバランス / リプレイ性 /
 *   オンボーディング / AV統一感 / UI/UX / アクセシビリティ / 楽しさFUNスコア
 *   の10軸を 0-10 点で採点し合計 0-100 点+認定ランクを返す。
 *   ダミー値ではなく実メトリクスから算出する。
 *   各軸の閾値はゲーム業界の標準値(60fps/16ms/3秒等)に準拠。
 */

// ========================================
// 型定義
// ========================================

/** 1軸ごとの採点結果 */
export interface AxisScore {
  /** 0-10 点 */
  score: number;
  /** 採点の根拠となる詳細値 */
  details: Record<string, number | string>;
  /** 合格したチェック項目 */
  passed_checks: string[];
  /** 失敗したチェック項目 */
  failed_checks: string[];
}

/** ゲーム全体の品質スコア */
export interface GameQualityScore {
  /** 0-100 点合計 */
  total: number;
  /** 認定ランク */
  rank: 'Reject' | 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
  /** 10軸の個別スコア */
  axes: {
    fps_stability: AxisScore;
    input_latency: AxisScore;
    load_time: AxisScore;
    game_balance: AxisScore;
    replayability: AxisScore;
    onboarding: AxisScore;
    av_consistency: AxisScore;
    ui_ux: AxisScore;
    accessibility: AxisScore;
    fun_score: AxisScore;
  };
  /** 警告メッセージ一覧 */
  warnings: string[];
  /** 改善推奨一覧 */
  recommendations: string[];
  /** 採点日時 (ISO8601) */
  generated_at: string;
}

/** 採点に必要なメトリクス入力 */
export interface GameMetrics {
  /** 60秒分のフレームレート履歴 (fps値の配列) */
  fpsHistory: number[];
  /** 入力遅延履歴 (ms単位、各入力イベントごと) */
  inputLatencyHistory: number[];
  /** 初回ロード時間 (ms) */
  loadTimeMs: number;
  /** チュートリアル有無 */
  hasTutorial: boolean;
  /** 設定画面有無 */
  hasSettings: boolean;
  /** アクセシビリティオプション有無 */
  hasAccessibilityOptions: boolean;
  /** セーブ/ロード有無 */
  hasSaveLoad: boolean;
  /** リプレイ性機能の有無 */
  hasReplayability: boolean;
  /** 難易度カーブ (各ステージ/ウェーブの難易度推定値) */
  difficultyCurve: number[];
  /** AV統一感スコア (0-1) */
  audioVisualConsistency: number;
  /** UI/UXヒューリスティックスコア (0-10) */
  uiUxScore: number;
  /** 自動プレイ満足度スコア (0-10) */
  funScore: number;
  /** オプション: チュートリアル所要時間(分)。未指定ならhasTutorialから推定 */
  tutorialDurationMin?: number;
  /** オプション: 楽しい瞬間到達時間(分)。未指定なら3.0と仮定 */
  firstFunMomentMin?: number;
  /** オプション: リプレイ性機能の内訳 */
  replayFeatures?: {
    hasUnlocks: boolean;
    hasAchievements: boolean;
    hasRankings: boolean;
    hasNGPlus: boolean;
  };
  /** オプション: UI/UX 詳細 */
  uiUxDetails?: {
    tapTargetMinPx: number;
    hasErrorRecovery: boolean;
    hasLoadingFeedback: boolean;
  };
  /** オプション: アクセシビリティ詳細 */
  accessibilityDetails?: {
    hasColorBlindMode: boolean;
    hasFontScaling: boolean;
    hasSubtitles: boolean;
    hasKeyboardNav: boolean;
  };
}

// ========================================
// ユーティリティ
// ========================================

/** 0-10の範囲にクランプ */
function clamp10(v: number): number {
  if (!Number.isFinite(v)) return 0;
  return Math.max(0, Math.min(10, v));
}

/** 線形補間: x が a→b の範囲で p→q に変化する */
function lerp(x: number, a: number, b: number, p: number, q: number): number {
  if (a === b) return p;
  const t = (x - a) / (b - a);
  return p + (q - p) * Math.max(0, Math.min(1, t));
}

/** 配列の平均 */
function mean(arr: number[]): number {
  if (arr.length === 0) return 0;
  return arr.reduce((s, v) => s + v, 0) / arr.length;
}

/** パーセンタイル (0-100) */
function percentile(arr: number[], p: number): number {
  if (arr.length === 0) return 0;
  const sorted = [...arr].sort((a, b) => a - b);
  const idx = Math.min(sorted.length - 1, Math.max(0, Math.floor((p / 100) * (sorted.length - 1))));
  return sorted[idx];
}

// ========================================
// 各軸の採点関数
// ========================================

/**
 * FPS安定性スコア
 * 採点ルール:
 *   - 60fps以上の維持率が90%以上で満点(10)
 *   - 30fps未満の区間が10%以上あれば-3点
 *   - 30fps未満の区間が30%以上あれば-5点
 *   - 平均が60fps未満の場合、線形補間で減点
 */
export function scoreFpsStability(fpsHistory: number[]): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  if (fpsHistory.length === 0) {
    return {
      score: 0,
      details: { reason: 'no_samples' },
      passed_checks: [],
      failed_checks: ['no_fps_samples_collected'],
    };
  }

  const avg = mean(fpsHistory);
  const above60 = fpsHistory.filter((f) => f >= 60).length;
  const below30 = fpsHistory.filter((f) => f < 30).length;
  const ratio60 = above60 / fpsHistory.length;
  const ratio30Drop = below30 / fpsHistory.length;
  const p1 = percentile(fpsHistory, 1);
  const p99 = percentile(fpsHistory, 99);

  // 基本スコア: 60fps維持率が90%以上で満点、0%で0点
  let score = lerp(ratio60, 0, 0.9, 0, 10);

  // 30fps未満区間の減点
  if (ratio30Drop >= 0.3) {
    score -= 5;
    failed.push('severe_fps_drops_over_30pct');
  } else if (ratio30Drop >= 0.1) {
    score -= 3;
    failed.push('fps_drops_over_10pct');
  } else {
    passed.push('low_fps_drops');
  }

  // 平均が60fps未満なら追加減点 (避けがたい)
  if (avg < 60) {
    score -= (60 - avg) * 0.05;
  } else {
    passed.push('avg_fps_above_60');
  }

  if (ratio60 >= 0.9) passed.push('fps_60_maintained_90pct');
  else failed.push('fps_60_maintenance_below_90pct');

  return {
    score: clamp10(score),
    details: {
      avg_fps: Number(avg.toFixed(2)),
      p1_fps: Number(p1.toFixed(2)),
      p99_fps: Number(p99.toFixed(2)),
      ratio_60_above: Number(ratio60.toFixed(4)),
      ratio_below_30: Number(ratio30Drop.toFixed(4)),
      samples: fpsHistory.length,
    },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/**
 * 入力遅延スコア
 * 採点ルール:
 *   - 平均16ms以下で満点(10)
 *   - 32ms以上で0点
 *   - その間は線形補間
 *   - p95が50ms超なら-2点
 */
export function scoreInputLatency(latencyHistory: number[]): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  if (latencyHistory.length === 0) {
    return {
      score: 0,
      details: { reason: 'no_samples' },
      passed_checks: [],
      failed_checks: ['no_latency_samples_collected'],
    };
  }

  const avg = mean(latencyHistory);
  const p95 = percentile(latencyHistory, 95);

  // 16ms以下=10点、32ms以上=0点、線形補間
  let score = lerp(avg, 16, 32, 10, 0);

  if (avg <= 16) passed.push('avg_latency_under_16ms');
  else if (avg <= 32) failed.push('avg_latency_above_16ms');
  else failed.push('avg_latency_above_32ms_unacceptable');

  if (p95 > 50) {
    score -= 2;
    failed.push('p95_latency_exceeds_50ms');
  } else {
    passed.push('p95_latency_acceptable');
  }

  return {
    score: clamp10(score),
    details: {
      avg_ms: Number(avg.toFixed(2)),
      p95_ms: Number(p95.toFixed(2)),
      samples: latencyHistory.length,
    },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/**
 * ロード時間スコア
 * 採点ルール:
 *   - 3秒以下で満点(10)
 *   - 10秒で0点
 *   - その間は線形補間
 */
export function scoreLoadTime(loadTimeMs: number): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];

  // 3000ms以下=10点、10000ms以上=0点
  const score = lerp(loadTimeMs, 3000, 10000, 10, 0);

  if (loadTimeMs <= 3000) passed.push('load_under_3sec');
  else if (loadTimeMs <= 10000) failed.push('load_over_3sec');
  else failed.push('load_over_10sec_unacceptable');

  return {
    score: clamp10(score),
    details: {
      load_ms: loadTimeMs,
      load_sec: Number((loadTimeMs / 1000).toFixed(2)),
    },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/**
 * ゲームバランススコア
 * 採点ルール:
 *   - 単調増加 + 1-2箇所の山 + 1-2箇所の休憩で満点
 *   - フラット(変化なし)で -5
 *   - 急上昇のみで -3
 *   - 振動(無秩序)で -5
 */
export function scoreGameBalance(curve: number[]): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  if (curve.length < 3) {
    return {
      score: 5,
      details: { reason: 'insufficient_stages', stages: curve.length },
      passed_checks: [],
      failed_checks: ['too_few_stages_to_analyze'],
    };
  }

  // 差分系列
  const deltas: number[] = [];
  for (let i = 1; i < curve.length; i++) deltas.push(curve[i] - curve[i - 1]);

  // 単調増加性: 増加カウント / 全体
  const increasing = deltas.filter((d) => d > 0).length;
  const monotonicity = increasing / deltas.length;

  // 山と谷の検出 (符号反転回数)
  let peaks = 0;
  let troughs = 0;
  for (let i = 1; i < deltas.length; i++) {
    if (deltas[i - 1] > 0 && deltas[i] < 0) peaks++;
    if (deltas[i - 1] < 0 && deltas[i] > 0) troughs++;
  }

  // 休憩区間 (連続して横ばい or 下降)
  let restCount = 0;
  for (let i = 0; i < deltas.length; i++) {
    if (deltas[i] <= 0) restCount++;
  }

  // 振動度: 符号変化が多すぎる
  let signChanges = 0;
  for (let i = 1; i < deltas.length; i++) {
    if (Math.sign(deltas[i - 1]) !== Math.sign(deltas[i]) && deltas[i] !== 0 && deltas[i - 1] !== 0) {
      signChanges++;
    }
  }
  const oscillation = signChanges / Math.max(1, deltas.length - 1);

  // 範囲(レンジ)= 最大 - 最小
  const range = Math.max(...curve) - Math.min(...curve);

  // 形状分類
  let shape: 'flat' | 'linear' | 'staircase' | 'exponential' | 'oscillating';
  if (range < 0.1) shape = 'flat';
  else if (oscillation > 0.5) shape = 'oscillating';
  else if (monotonicity > 0.9) {
    const last = deltas[deltas.length - 1];
    const first = deltas[0];
    shape = last > first * 2 ? 'exponential' : 'linear';
  } else if (peaks >= 1 && troughs >= 1) shape = 'staircase';
  else shape = 'linear';

  let score = 10;
  if (shape === 'flat') {
    score -= 5;
    failed.push('balance_curve_flat');
  } else if (shape === 'oscillating') {
    score -= 5;
    failed.push('balance_curve_oscillating');
  } else if (shape === 'exponential') {
    // 急上昇のみ
    score -= 3;
    failed.push('balance_curve_only_rising_steep');
  } else {
    passed.push(`balance_curve_${shape}`);
  }

  // 理想形(山1-2箇所+休憩1-2箇所)に近いほどボーナス維持
  if (peaks >= 1 && peaks <= 3 && troughs >= 1 && troughs <= 3) {
    passed.push('has_peaks_and_rests');
  } else if (shape !== 'flat' && shape !== 'oscillating') {
    score -= 1;
    failed.push('lacks_rest_segments');
  }

  return {
    score: clamp10(score),
    details: {
      shape,
      stages: curve.length,
      monotonicity: Number(monotonicity.toFixed(2)),
      peaks,
      troughs,
      oscillation: Number(oscillation.toFixed(2)),
      range: Number(range.toFixed(2)),
      rest_count: restCount,
    },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/**
 * リプレイ性スコア
 * 採点ルール: 4機能のうち何個あるか × 2.5点
 */
export function scoreReplayability(features: {
  hasUnlocks: boolean;
  hasAchievements: boolean;
  hasRankings: boolean;
  hasNGPlus: boolean;
}): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];

  if (features.hasUnlocks) passed.push('has_unlocks');
  else failed.push('no_unlocks');
  if (features.hasAchievements) passed.push('has_achievements');
  else failed.push('no_achievements');
  if (features.hasRankings) passed.push('has_rankings');
  else failed.push('no_rankings');
  if (features.hasNGPlus) passed.push('has_ng_plus');
  else failed.push('no_ng_plus');

  const count = passed.length;
  const score = clamp10(count * 2.5);

  return {
    score,
    details: {
      features_implemented: count,
      out_of: 4,
    },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/**
 * オンボーディングスコア
 * 採点ルール:
 *   - チュートリアル3分以内 + 楽しい瞬間が3分以内で満点(10)
 *   - チュートリアル5分以上で -3
 *   - 楽しい瞬間が5分以上で -4
 *   - 両方超過なら 0 近傍
 */
export function scoreOnboarding(opts: {
  tutorialDurationMin: number;
  firstFunMomentMin: number;
}): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];

  let score = 10;

  // チュートリアル所要時間
  if (opts.tutorialDurationMin <= 3) {
    passed.push('tutorial_under_3min');
  } else if (opts.tutorialDurationMin <= 5) {
    score -= 2;
    failed.push('tutorial_over_3min');
  } else {
    score -= 4;
    failed.push('tutorial_over_5min');
  }

  // 最初の「楽しい瞬間」までの時間
  if (opts.firstFunMomentMin <= 3) {
    passed.push('first_fun_under_3min');
  } else if (opts.firstFunMomentMin <= 5) {
    score -= 2;
    failed.push('first_fun_over_3min');
  } else {
    score -= 4;
    failed.push('first_fun_over_5min');
  }

  return {
    score: clamp10(score),
    details: {
      tutorial_min: opts.tutorialDurationMin,
      first_fun_min: opts.firstFunMomentMin,
    },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/**
 * AV統一感スコア
 * 採点ルール: 0-1のスコア × 10
 */
export function scoreAvConsistency(score: number): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  const clamped = Math.max(0, Math.min(1, score));
  if (clamped >= 0.8) passed.push('av_consistency_high');
  else if (clamped >= 0.6) failed.push('av_consistency_medium');
  else failed.push('av_consistency_low');

  return {
    score: clamp10(clamped * 10),
    details: { raw_score: Number(clamped.toFixed(3)) },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/**
 * UI/UXスコア
 * 採点ルール:
 *   - タップターゲット48px以上 + エラー回復 + ローディング表示で満点
 *   - タップターゲット未満で -3
 *   - エラー回復なしで -3
 *   - ローディング表示なしで -2
 */
export function scoreUiUx(opts: {
  tapTargetMinPx: number;
  hasErrorRecovery: boolean;
  hasLoadingFeedback: boolean;
}): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];
  let score = 10;

  if (opts.tapTargetMinPx >= 48) {
    passed.push('tap_target_min_48px');
  } else {
    score -= 3;
    failed.push('tap_target_below_48px');
  }

  if (opts.hasErrorRecovery) passed.push('has_error_recovery');
  else {
    score -= 3;
    failed.push('no_error_recovery');
  }

  if (opts.hasLoadingFeedback) passed.push('has_loading_feedback');
  else {
    score -= 2;
    failed.push('no_loading_feedback');
  }

  return {
    score: clamp10(score),
    details: {
      tap_target_px: opts.tapTargetMinPx,
      error_recovery: opts.hasErrorRecovery ? 1 : 0,
      loading_feedback: opts.hasLoadingFeedback ? 1 : 0,
    },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/**
 * アクセシビリティスコア
 * 採点ルール: 4機能のうち何個あるか × 2.5点
 */
export function scoreAccessibility(opts: {
  hasColorBlindMode: boolean;
  hasFontScaling: boolean;
  hasSubtitles: boolean;
  hasKeyboardNav: boolean;
}): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];

  if (opts.hasColorBlindMode) passed.push('has_color_blind_mode');
  else failed.push('no_color_blind_mode');
  if (opts.hasFontScaling) passed.push('has_font_scaling');
  else failed.push('no_font_scaling');
  if (opts.hasSubtitles) passed.push('has_subtitles');
  else failed.push('no_subtitles');
  if (opts.hasKeyboardNav) passed.push('has_keyboard_nav');
  else failed.push('no_keyboard_nav');

  const count = passed.length;
  return {
    score: clamp10(count * 2.5),
    details: {
      features_implemented: count,
      out_of: 4,
    },
    passed_checks: passed,
    failed_checks: failed,
  };
}

/**
 * 楽しさFUNスコア
 * 採点ルール: 自動プレイのスコア(0-1) × 10 (既に0-10ならそのまま)
 */
export function scoreFunScore(autoplayScore: number): AxisScore {
  const passed: string[] = [];
  const failed: string[] = [];

  // 0-1 範囲なら 10 倍、0-10 範囲ならそのまま
  let normalized: number;
  if (autoplayScore <= 1) normalized = autoplayScore * 10;
  else normalized = autoplayScore;

  const finalScore = clamp10(normalized);

  if (finalScore >= 8) passed.push('fun_score_high');
  else if (finalScore >= 6) failed.push('fun_score_medium');
  else failed.push('fun_score_low');

  return {
    score: finalScore,
    details: { raw_score: Number(autoplayScore.toFixed(2)) },
    passed_checks: passed,
    failed_checks: failed,
  };
}

// ========================================
// 総合採点エンジン
// ========================================

/**
 * メトリクスから 10軸を採点して合計スコア+ランクを返す。
 * 各軸 0-10、合計 0-100。
 * 認定: 0-59 Reject / 60-79 Bronze / 80-89 Silver / 90-94 Gold / 95+ Platinum
 */
export function scoreGame(metrics: GameMetrics): GameQualityScore {
  // 各軸の採点
  const fps = scoreFpsStability(metrics.fpsHistory);
  const lat = scoreInputLatency(metrics.inputLatencyHistory);
  const load = scoreLoadTime(metrics.loadTimeMs);
  const balance = scoreGameBalance(metrics.difficultyCurve);

  // リプレイ性: 詳細指定があればそれを使い、なければhasReplayabilityから推定
  const replayFeatures = metrics.replayFeatures ?? {
    hasUnlocks: metrics.hasReplayability,
    hasAchievements: metrics.hasReplayability,
    hasRankings: false,
    hasNGPlus: false,
  };
  const replay = scoreReplayability(replayFeatures);

  // オンボーディング: チュートリアル時間が未指定ならhasTutorialから推定
  const tutorialMin = metrics.tutorialDurationMin ?? (metrics.hasTutorial ? 2.5 : 99);
  const firstFunMin = metrics.firstFunMomentMin ?? 3.0;
  const onboard = scoreOnboarding({
    tutorialDurationMin: tutorialMin,
    firstFunMomentMin: firstFunMin,
  });

  const av = scoreAvConsistency(metrics.audioVisualConsistency);

  // UI/UX: 詳細があれば使い、なければuiUxScoreから等価変換
  const uiUxDetails = metrics.uiUxDetails ?? {
    tapTargetMinPx: metrics.uiUxScore >= 7 ? 48 : 32,
    hasErrorRecovery: metrics.uiUxScore >= 6,
    hasLoadingFeedback: metrics.uiUxScore >= 5,
  };
  const uiUx = scoreUiUx(uiUxDetails);

  // アクセシビリティ: 詳細があれば使い、なければhasAccessibilityOptionsから推定
  const a11yDetails =
    metrics.accessibilityDetails ?? {
      hasColorBlindMode: metrics.hasAccessibilityOptions,
      hasFontScaling: metrics.hasAccessibilityOptions,
      hasSubtitles: metrics.hasAccessibilityOptions,
      hasKeyboardNav: metrics.hasAccessibilityOptions,
    };
  const a11y = scoreAccessibility(a11yDetails);

  const fun = scoreFunScore(metrics.funScore);

  const axes = {
    fps_stability: fps,
    input_latency: lat,
    load_time: load,
    game_balance: balance,
    replayability: replay,
    onboarding: onboard,
    av_consistency: av,
    ui_ux: uiUx,
    accessibility: a11y,
    fun_score: fun,
  };

  // 合計 (各軸 0-10 × 10軸 = 0-100)
  const total = Object.values(axes).reduce((s, ax) => s + ax.score, 0);
  const totalRounded = Number(total.toFixed(2));

  // ランク判定
  let rank: GameQualityScore['rank'];
  if (totalRounded >= 95) rank = 'Platinum';
  else if (totalRounded >= 90) rank = 'Gold';
  else if (totalRounded >= 80) rank = 'Silver';
  else if (totalRounded >= 60) rank = 'Bronze';
  else rank = 'Reject';

  // 警告/推奨の集約
  const warnings: string[] = [];
  const recommendations: string[] = [];
  for (const [name, ax] of Object.entries(axes)) {
    if (ax.score < 5) {
      warnings.push(`${name}: スコア ${ax.score.toFixed(1)}/10 が低い`);
      if (ax.failed_checks.length > 0) {
        recommendations.push(`${name}: ${ax.failed_checks.join(', ')} を改善`);
      }
    } else if (ax.score < 7) {
      recommendations.push(`${name}: スコア ${ax.score.toFixed(1)}/10 — 改善余地あり`);
    }
  }
  if (!metrics.hasSaveLoad) recommendations.push('セーブ/ロード機能の実装を推奨');
  if (!metrics.hasSettings) recommendations.push('設定画面の実装を推奨');

  return {
    total: totalRounded,
    rank,
    axes,
    warnings,
    recommendations,
    generated_at: new Date().toISOString(),
  };
}
