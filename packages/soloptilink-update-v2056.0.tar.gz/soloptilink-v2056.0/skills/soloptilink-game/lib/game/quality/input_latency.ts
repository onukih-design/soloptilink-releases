/**
 * input_latency.ts
 * 責務: pointerdown/touchstart/keydown イベントから次の paint (rAF) までの
 *   時間を計測して入力遅延を算出。16ms / 32ms 閾値判定を含む。
 *   Node.js 環境でも import 可能 (typeof window !== 'undefined' ガード)。
 *   ダミー値ではなく実イベントから算出する。
 */

/** 入力遅延のスナップショット */
export interface InputLatencySnapshot {
  /** 入力遅延 (ms) の履歴 */
  history: number[];
  /** 平均 */
  avg: number;
  /** 中央値 */
  median: number;
  /** p95 */
  p95: number;
  /** 最大 */
  max: number;
  /** 16ms以下のサンプル比率 (0-1) */
  ratioUnder16ms: number;
  /** 32ms超のサンプル比率 (0-1) */
  ratioOver32ms: number;
  /** 判定: 'excellent' (avg<=16) / 'acceptable' (avg<=32) / 'poor' */
  verdict: 'excellent' | 'acceptable' | 'poor';
  /** サンプル数 */
  samples: number;
}

/** 内部用: 計測中の入力イベントレコード */
interface PendingInput {
  timestamp: number;
  type: string;
}

/**
 * 入力遅延計測クラス。
 * pointerdown / touchstart / keydown を listen し、
 * 次の rAF までの時間を入力遅延として記録する。
 */
export class InputLatencyMeter {
  private running = false;
  private latencies: number[] = [];
  private pending: PendingInput[] = [];
  private handlers: {
    pointerdown?: (e: Event) => void;
    touchstart?: (e: Event) => void;
    keydown?: (e: Event) => void;
  } = {};
  private rafId: number | null = null;
  /** 計測対象とするイベント要素。デフォルトは window */
  private target: EventTarget | null = null;

  /** ブラウザ環境判定 */
  private isBrowser(): boolean {
    return (
      typeof window !== 'undefined' &&
      typeof window.addEventListener === 'function' &&
      typeof window.requestAnimationFrame === 'function' &&
      typeof performance !== 'undefined' &&
      typeof performance.now === 'function'
    );
  }

  /**
   * 計測を開始
   * @param target 計測対象 (default: window)
   */
  start(target?: EventTarget): void {
    if (!this.isBrowser()) {
      this.running = false;
      return;
    }
    if (this.running) return;
    this.running = true;
    this.latencies = [];
    this.pending = [];
    this.target = target ?? window;

    // 各イベントで pending リストに記録
    const record = (e: Event): void => {
      if (!this.running) return;
      this.pending.push({ timestamp: performance.now(), type: e.type });
    };

    this.handlers.pointerdown = record;
    this.handlers.touchstart = record;
    this.handlers.keydown = record;

    this.target.addEventListener('pointerdown', this.handlers.pointerdown, { passive: true } as AddEventListenerOptions);
    this.target.addEventListener('touchstart', this.handlers.touchstart, { passive: true } as AddEventListenerOptions);
    this.target.addEventListener('keydown', this.handlers.keydown, { passive: true } as AddEventListenerOptions);

    // 毎フレーム: pending を消化して遅延を確定
    const tick = (now: number): void => {
      if (!this.running) return;
      if (this.pending.length > 0) {
        for (const p of this.pending) {
          const latency = now - p.timestamp;
          // 異常値(負/巨大)はガード
          if (latency >= 0 && latency < 1000) {
            this.latencies.push(latency);
          }
        }
        this.pending = [];
      }
      this.rafId = window.requestAnimationFrame(tick);
    };
    this.rafId = window.requestAnimationFrame(tick);
  }

  /** 計測を停止 */
  stop(): void {
    this.running = false;
    if (!this.isBrowser() || !this.target) return;

    if (this.handlers.pointerdown) {
      this.target.removeEventListener('pointerdown', this.handlers.pointerdown);
    }
    if (this.handlers.touchstart) {
      this.target.removeEventListener('touchstart', this.handlers.touchstart);
    }
    if (this.handlers.keydown) {
      this.target.removeEventListener('keydown', this.handlers.keydown);
    }
    this.handlers = {};

    if (this.rafId !== null) {
      window.cancelAnimationFrame(this.rafId);
      this.rafId = null;
    }
  }

  /** 履歴と統計のスナップショットを取得 */
  getSnapshot(): InputLatencySnapshot {
    const history = [...this.latencies];
    if (history.length === 0) {
      return {
        history: [],
        avg: 0,
        median: 0,
        p95: 0,
        max: 0,
        ratioUnder16ms: 0,
        ratioOver32ms: 0,
        verdict: 'poor',
        samples: 0,
      };
    }
    const sorted = [...history].sort((a, b) => a - b);
    const avg = history.reduce((s, v) => s + v, 0) / history.length;
    const median = sorted[Math.floor(sorted.length / 2)];
    const p95 = sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * 0.95))];
    const max = sorted[sorted.length - 1];

    const under16 = history.filter((v) => v <= 16).length;
    const over32 = history.filter((v) => v > 32).length;

    // 判定
    let verdict: InputLatencySnapshot['verdict'];
    if (avg <= 16) verdict = 'excellent';
    else if (avg <= 32) verdict = 'acceptable';
    else verdict = 'poor';

    return {
      history,
      avg: Number(avg.toFixed(2)),
      median: Number(median.toFixed(2)),
      p95: Number(p95.toFixed(2)),
      max: Number(max.toFixed(2)),
      ratioUnder16ms: Number((under16 / history.length).toFixed(4)),
      ratioOver32ms: Number((over32 / history.length).toFixed(4)),
      verdict,
      samples: history.length,
    };
  }

  /** リセット (テスト用) */
  reset(): void {
    this.latencies = [];
    this.pending = [];
  }
}

/**
 * 閾値判定ヘルパー: 1サンプルが基準を満たすか
 */
export function classifyLatency(ms: number): 'excellent' | 'acceptable' | 'poor' {
  if (ms <= 16) return 'excellent';
  if (ms <= 32) return 'acceptable';
  return 'poor';
}
