// ===========================================================
// SoloptiLinkAI v1.0 Game Production Engine
// engine_selector.ts - ゲームエンジン推奨ロジック
//
// 12ジャンル × 5プラットフォーム × 3規模 のマトリクスで
// 最適なゲームエンジン(Phaser 3 / PixiJS / Three.js / Godot 4)を選定する。
// 日本語コメントで「なぜ推奨するか」を必ず明記。
// ===========================================================

import phaser from './phaser.json' assert { type: 'json' };
import pixi from './pixi.json' assert { type: 'json' };
import three from './three.json' assert { type: 'json' };
import godot from './godot.json' assert { type: 'json' };

// ===== 型定義 =====

/** 対応ゲームジャンル(12種) */
export type GameGenre =
  | 'puzzle'         // パズル(テトリス・ぷよぷよ・マッチ3)
  | 'action_2d'      // 2Dアクション(マリオ風)
  | 'shooter'        // シューティング(東方風弾幕含む)
  | 'rpg'            // RPG(ドラクエ風・FF風)
  | 'novel'          // ノベル/アドベンチャー
  | 'board'          // ボード(将棋・オセロ・チェス)
  | 'card'           // カード(トランプ・TCG)
  | 'hyper_casual'   // ハイパーカジュアル(タップ系)
  | 'rhythm'         // リズム(太鼓・音ゲー)
  | 'simulation'     // シミュレーション(街づくり・経営)
  | 'strategy'       // ストラテジー(SLG・RTS)
  | 'clicker'        // クリッカー/放置ゲー
  | '3d_action'      // 3Dアクション
  | '3d_shooter'     // 3D FPS/TPS
  | '3d_puzzle'      // 3Dパズル
  | 'vr';            // VR/AR体験

/** 配信プラットフォーム */
export type Platform = 'web' | 'mobile' | 'desktop' | 'steam' | 'vr';

/** ゲーム規模 */
export type Scale = 'mini' | 'casual' | 'full';

/** エンジン推奨結果 */
export interface EngineRecommendation {
  /** 第1推奨エンジン名 */
  primary: string;
  /** 代替候補エンジン名(優先度順) */
  alternatives: string[];
  /** 推奨理由(日本語) */
  reason: string;
  /** 注意点・落とし穴(任意) */
  warnings?: string[];
}

// ===== エンジン名定数 =====
const ENGINE = {
  PHASER: 'Phaser 3',
  PIXI: 'PixiJS',
  THREE: 'Three.js',
  GODOT: 'Godot 4 Web Export'
} as const;

// ===========================================================
// メイン推奨関数
// ===========================================================

/**
 * ジャンル・プラットフォーム・規模から最適なゲームエンジンを推奨する。
 *
 * 選定ロジック:
 *  1. VR要件があれば Three.js(WebXR)を最優先
 *  2. 3D要件があれば Three.js または Godot
 *  3. Steam/Desktop配信なら Godot(ネイティブExport)を最優先
 *  4. 大規模RPG/SLGなら Godot(統合エディタ+シーン管理)
 *  5. 弾幕シューティング・大量描画なら PixiJS(WebGL最適化)
 *  6. それ以外の2Dゲームなら Phaser 3(学習曲線が緩やか)
 *
 * @param genre    ゲームジャンル
 * @param platform 配信先プラットフォーム(既定値: web)
 * @param scale    ゲーム規模(既定値: casual)
 * @returns        推奨エンジンと代替候補、推奨理由
 */
export function recommendEngine(
  genre: GameGenre,
  platform: Platform = 'web',
  scale: Scale = 'casual'
): EngineRecommendation {
  // ----- VR ジャンル / プラットフォーム最優先 -----
  // WebXR 標準対応の Three.js が唯一の選択肢。Phaser/Pixi/Godot WebはVR非対応。
  if (genre === 'vr' || platform === 'vr') {
    return {
      primary: ENGINE.THREE,
      alternatives: [ENGINE.GODOT],
      reason:
        'VR/AR体験は WebXR 標準対応の Three.js が最優先。Meta Quest や Apple Vision Pro のブラウザで追加実装ほぼ不要で動作する。Godot は XR Plugin が利用可能だが Web Export では制限があるため代替候補。',
      warnings: [
        'モバイルVRはGPU負荷が高いため、ポリゴン数とテクスチャ解像度を厳しく管理すること',
        'WebXRはHTTPS必須。ローカル開発でも自己署名証明書を準備'
      ]
    };
  }

  // ===== ジャンル別ロジック =====
  switch (genre) {
    // ----- パズル(テトリス・ぷよぷよ・マッチ3) -----
    case 'puzzle': {
      // パズルは2Dグリッドベース。Phaserのシーン管理+Arcade Physicsで実装が最短。
      // miniなら学習コスト低い Phaser 一択。full でも Phaser で十分回せる。
      return {
        primary: ENGINE.PHASER,
        alternatives: [ENGINE.PIXI, ENGINE.GODOT],
        reason:
          'パズルゲームはグリッド管理とアニメーションが主体。Phaser 3 の Scene/Tween/Input が最短実装。学習曲線が緩やかで日本語チュートリアルも豊富なため、miniからfullまで対応可能。',
        warnings:
          scale === 'full' ? ['大規模パズル(50ステージ超)ではメモリ管理に注意'] : undefined
      };
    }

    // ----- 2Dアクション(マリオ風) -----
    case 'action_2d': {
      // 2Dアクションはタイルマップ + 物理判定 + アニメーション。
      // PhaserのArcade Physics+Tiledタイルマップ標準対応が圧倒的に楽。
      // Steam配信視野なら Godot の方がネイティブExportで有利。
      if (platform === 'steam' || platform === 'desktop') {
        return {
          primary: ENGINE.GODOT,
          alternatives: [ENGINE.PHASER],
          reason:
            '2DアクションでSteam/Desktop配信なら Godot のネイティブExportが第一選択。CharacterBody2D + AnimationPlayer で物理挙動とアニメーション遷移を統合エディタで設計可能。Phaser はWeb版併設なら併用候補。',
          warnings: ['Web版も同時提供する場合は Godot Web Export のサイズ(15-30MB)を考慮']
        };
      }
      return {
        primary: ENGINE.PHASER,
        alternatives: [ENGINE.GODOT, ENGINE.PIXI],
        reason:
          '2DアクションはWebなら Phaser 3。Arcade Physics + Tiledタイルマップ標準対応で、横スクロール・重力・ジャンプ・コイン取得が最短実装可能。',
        warnings: undefined
      };
    }

    // ----- シューティング(弾幕含む) -----
    case 'shooter': {
      // 弾幕(数千個の弾)が前提なら WebGL高速描画の PixiJS が最適。
      // 普通のSTGなら Phaser でも十分。
      if (scale === 'full') {
        return {
          primary: ENGINE.PIXI,
          alternatives: [ENGINE.PHASER],
          reason:
            'フルスケールのシューティング(弾幕含む)は PixiJS の WebGLバッチレンダラーで数千個のスプライトを60FPS維持可能。BulletPool パターンと組み合わせて東方風弾幕を実装できる。',
          warnings: [
            'シーン管理・入力管理・物理は自前実装が必要',
            'モバイルGPUでは弾数の上限テストを必ず実施'
          ]
        };
      }
      return {
        primary: ENGINE.PHASER,
        alternatives: [ENGINE.PIXI],
        reason:
          'カジュアル規模のシューティングは Phaser 3 のArcade Physics + Groupで簡単に実装可能。学習コストが低くプロトタイピングが速い。',
        warnings: undefined
      };
    }

    // ----- RPG(ドラクエ風・FF風) -----
    case 'rpg': {
      // RPGはシーン数(街・ダンジョン・バトル・メニュー)が多くシーン管理が肝。
      // Godotの統合エディタ+シーンツリーが最も効率的。
      // miniならPhaserでも可だが、fullなら Godot 一択。
      if (scale === 'mini') {
        return {
          primary: ENGINE.PHASER,
          alternatives: [ENGINE.GODOT],
          reason:
            'ミニRPG(短編・1-2時間)なら Phaser 3 で十分実装可能。Scene分割でマップ/バトル/メニューを切り替え、Tiledタイルマップでフィールドを構築。',
          warnings: undefined
        };
      }
      return {
        primary: ENGINE.GODOT,
        alternatives: [ENGINE.PHASER],
        reason:
          '中〜大規模RPGは Godot 4 の統合エディタ + シーンツリー + AnimationTree が最強。マップ・バトル・メニュー・セーブの設計が直感的で、Steam/PC/Mobile配信も同一プロジェクトから可能。',
        warnings:
          platform === 'web'
            ? ['Web Export のサイズが15-30MB。初回ロード時間を覚悟']
            : undefined
      };
    }

    // ----- ノベル/アドベンチャー -----
    case 'novel': {
      // ノベルゲームはテキスト演出が主役。PixiJSのテキスト演出+Filter+Spineが美しい。
      // ただし機能をシンプルにするなら Phaser でも対応可能。
      return {
        primary: ENGINE.PIXI,
        alternatives: [ENGINE.PHASER],
        reason:
          'ノベル/アドベンチャーは PixiJS のテキスト演出(タイプライター・揺れ・グロー・フェード)とFilterシステムが美しい。Spine対応で立ち絵アニメも本格的に作れる。',
        warnings: ['シナリオエンジン(分岐・既読管理)は自前構築が必要']
      };
    }

    // ----- ボード(将棋・オセロ・チェス) -----
    case 'board': {
      // 盤面と駒があるだけのシンプル構造。Phaser で過剰な機能なし。
      return {
        primary: ENGINE.PHASER,
        alternatives: [ENGINE.PIXI],
        reason:
          '将棋・オセロ・チェス等のボードゲームは Phaser 3 のグリッド管理 + Input が最適。盤面UI + 駒選択 + AI思考(Minimax/AlphaBeta) の組み合わせで実装可能。',
        warnings: undefined
      };
    }

    // ----- カード(トランプ・TCG) -----
    case 'card': {
      // カードゲームは Tween でカードの移動・反転が頻発。Phaser のTweenが最も簡潔。
      return {
        primary: ENGINE.PHASER,
        alternatives: [ENGINE.PIXI],
        reason:
          'カードゲームは Phaser 3 の Tween で「カードを引く・捨てる・反転する」演出が直感的に実装可能。TCGの複雑なルールも Scene分割で管理しやすい。',
        warnings: undefined
      };
    }

    // ----- ハイパーカジュアル(タップ・スワイプ系) -----
    case 'hyper_casual': {
      // ハイパーカジュアルは「3日で完成」が目標。学習コスト最小のPhaserで決まり。
      // ただしモバイル中心なら、ロード時間短縮のため PixiJS の軽量バンドルも選択肢。
      if (platform === 'mobile' && scale === 'mini') {
        return {
          primary: ENGINE.PIXI,
          alternatives: [ENGINE.PHASER],
          reason:
            'モバイル向けミニハイパーカジュアルは PixiJS の軽量バンドル(最小50KB)とWebGL高速描画でロード時間を最短化。広告SDK統合も容易。',
          warnings: ['シーン管理は自前で実装。タップ判定もInteractionManagerで構築']
        };
      }
      return {
        primary: ENGINE.PHASER,
        alternatives: [ENGINE.PIXI],
        reason:
          'ハイパーカジュアルは Phaser 3 の入力API(タッチ・マウス統一)とTweenで「3日でプロトタイプ完成」が現実的。Capacitorでモバイル配信も即対応。',
        warnings: undefined
      };
    }

    // ----- リズム(太鼓・音ゲー) -----
    case 'rhythm': {
      // 音ゲーは音とタイミングの精度が命。WebAudio直接制御がしやすい PixiJS。
      // 演出豊富なら Phaser でも可。
      if (scale === 'full') {
        return {
          primary: ENGINE.PIXI,
          alternatives: [ENGINE.PHASER],
          reason:
            'フルスケールの音ゲーは PixiJS + WebAudio API 直接制御で入力遅延を16ms以下に抑えやすい。@pixi/sound で音楽の精密同期も実現。',
          warnings: ['入力遅延の最適化のため audioContext.outputLatency を必ず計測補正']
        };
      }
      return {
        primary: ENGINE.PHASER,
        alternatives: [ENGINE.PIXI],
        reason:
          'カジュアル音ゲーは Phaser 3 のサウンドマネージャと Tween でノーツアニメーションを実装可能。プロトタイピングが速い。',
        warnings: undefined
      };
    }

    // ----- シミュレーション(街づくり・経営) -----
    case 'simulation': {
      // シミュは大量のオブジェクト管理 + 永続化 + UI複雑。Godot のシーンツリーが最強。
      return {
        primary: ENGINE.GODOT,
        alternatives: [ENGINE.PHASER],
        reason:
          'シミュレーション(街づくり・経営・ライフシム)は Godot 4 のシーンツリー + Resource システムでデータと表示を分離設計可能。長時間プレイのセーブ/ロードや UI が複雑なため、統合エディタの恩恵が最も大きい。',
        warnings:
          platform === 'web'
            ? ['Web Export はサイズが大きいため、初回ローディング演出を必ず用意']
            : undefined
      };
    }

    // ----- ストラテジー(SLG・RTS) -----
    case 'strategy': {
      // SLGはユニット管理・経路探索・AI思考が肝。Godotの統合性が活きる。
      return {
        primary: ENGINE.GODOT,
        alternatives: [ENGINE.PHASER],
        reason:
          'ストラテジー(SLG/RTS)はユニット管理・A*経路探索・思考AI・複雑なUIが必要。Godot 4 の NavigationServer2D/3D とシーンツリーが最適。Steam配信も視野に入る。',
        warnings: ['RTS的にユニット数が増える場合は、ノード生成のプール化を設計']
      };
    }

    // ----- クリッカー/放置ゲー -----
    case 'clicker': {
      // クリッカーはロジック単純。Phaser の Tween/Particle で「気持ちよさ」を演出。
      return {
        primary: ENGINE.PHASER,
        alternatives: [ENGINE.PIXI],
        reason:
          'クリッカー/放置ゲーは Phaser 3 の Tween + Particles + Text演出で「クリックの気持ちよさ」を最大化。localStorage で進捗永続化、オフライン進行計算も標準JSで完結。',
        warnings: ['オフライン経過時間の悪用対策(時計戻し)を必ず実装']
      };
    }

    // ----- 3Dアクション -----
    case '3d_action': {
      // 3Dは Three.js か Godot の2択。Web中心なら Three.js、Steam中心なら Godot。
      if (platform === 'steam' || platform === 'desktop' || scale === 'full') {
        return {
          primary: ENGINE.GODOT,
          alternatives: [ENGINE.THREE],
          reason:
            'フルスケールの3DアクションでSteam/Desktop配信なら Godot 4 がベスト。CharacterBody3D + AnimationTree + Physics の統合がスムーズ。Three.js は Web中心なら代替候補。',
          warnings: undefined
        };
      }
      return {
        primary: ENGINE.THREE,
        alternatives: [ENGINE.GODOT],
        reason:
          'Web中心の3Dアクションは Three.js が最有力。GLTF標準対応 + Cannon-es 物理連携 + PointerLockControlsでFPS視点が即実装可能。',
        warnings: ['シーン管理・入力管理は自前構築が必要']
      };
    }

    // ----- 3D FPS/TPSシューター -----
    case '3d_shooter': {
      // 3D FPSは Three.js のPointerLockControlsとRaycasterが定番。
      if (platform === 'steam' || platform === 'desktop') {
        return {
          primary: ENGINE.GODOT,
          alternatives: [ENGINE.THREE],
          reason:
            '3D FPS/TPSでSteam/Desktop配信は Godot 4 の3Dシステムとレンダリングが本格派。商用FPSタイトルの実績も増加中。',
          warnings: undefined
        };
      }
      return {
        primary: ENGINE.THREE,
        alternatives: [ENGINE.GODOT],
        reason:
          'Web向け3D FPS/TPSは Three.js のPointerLockControls + Raycasterが定番の組み合わせ。撃った先のHit判定もRaycastで簡潔。',
        warnings: ['モバイルGPUではポリゴン数LODを必ず設計']
      };
    }

    // ----- 3Dパズル -----
    case '3d_puzzle': {
      // 3DパズルはWeb中心が多くTree.jsが扱いやすい。
      return {
        primary: ENGINE.THREE,
        alternatives: [ENGINE.GODOT],
        reason:
          '3Dパズル(立体迷路・ルービックキューブ風)は Three.js のシンプルなSceneGraph + OrbitControls で実装が直感的。Webカジュアル配信に最適。',
        warnings: undefined
      };
    }

    // ----- フォールバック -----
    default: {
      // 未定義ジャンルはとりあえず Phaser を推奨(2Dが多い前提)
      return {
        primary: ENGINE.PHASER,
        alternatives: [ENGINE.PIXI, ENGINE.GODOT, ENGINE.THREE],
        reason:
          'ジャンル未指定または未対応のため、汎用性が最も高い Phaser 3 を推奨。要件が明確化したら recommendEngine() を再実行のこと。',
        warnings: ['ジャンルを明確化することで、より適切なエンジン選定が可能']
      };
    }
  }
}

// ===========================================================
// エンジンメタデータ取得
// ===========================================================

/**
 * エンジン名から対応するJSON定義を返す。
 * 引数は engine_name の name フィールドと一致する文字列(大文字小文字を緩く判定)。
 *
 * @param engineName エンジン名(例: "Phaser 3" / "phaser" / "PixiJS")
 * @returns エンジン定義JSON、または null
 */
export function getEngineMetadata(engineName: string): unknown {
  const normalized = engineName.toLowerCase().trim();
  // 部分一致で寛容に判定 (UIから来る文字列ゆらぎ吸収)
  if (normalized.includes('phaser')) return phaser;
  if (normalized.includes('pixi')) return pixi;
  if (normalized.includes('three')) return three;
  if (normalized.includes('godot')) return godot;
  return null;
}

/**
 * 利用可能な全エンジンのメタデータを返す。
 * UIのエンジン選択ドロップダウン等で利用想定。
 */
export function listAllEngines(): unknown[] {
  return [phaser, pixi, three, godot];
}
