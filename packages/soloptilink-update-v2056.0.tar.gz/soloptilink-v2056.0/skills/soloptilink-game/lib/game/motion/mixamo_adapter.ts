/**
 * mixamo_adapter.ts
 * =============================================================================
 * 責務: Mixamo 風モーション自動取得アダプタ
 * -----------------------------------------------------------------------------
 * 本モジュールは「キャラクターメッシュ URL」を入力として受け取り、Mixamo
 * (Adobe) 互換の REST API へリクエストを送り、指定された複数のアニメーション
 * (idle / walk / run / jump 等) を取得して結果を返す。
 *
 * 設計方針:
 *   - 外部依存ゼロ (fetch 標準) で動作させる。
 *   - 環境変数 MIXAMO_API_KEY が未設定の場合は決定論的なモック URL を返す
 *     fallback モードに切り替える (オフライン CI 対応)。
 *   - すべての時間値はミリ秒、長さ秒、フレームレートは Hz で統一。
 *   - すべての処理は async (Promise) でラップし、後段のジョブキューに乗せ
 *     やすくする。
 *   - 乱数は (mock URL 用に) seed 可能。
 * -----------------------------------------------------------------------------
 * SoloptiLinkAI v2034.x  /soloptilink-game v2.0
 * =============================================================================
 */

// ---- 型定義 --------------------------------------------------------------- //

/**
 * モーション名の Union 型。
 * これら以外は受け付けない (タイプセーフ)。
 */
export type MotionName =
  | 'idle'
  | 'walk'
  | 'run'
  | 'sprint'
  | 'jump_start'
  | 'jump_loop'
  | 'jump_land'
  | 'jump_full'
  | 'attack_punch'
  | 'attack_kick'
  | 'attack_sword'
  | 'attack_gun_pistol'
  | 'attack_gun_rifle'
  | 'hit_react_light'
  | 'hit_react_heavy'
  | 'death'
  | 'crouch_idle'
  | 'crouch_walk'
  | 'climb_up'
  | 'climb_idle'
  | 'swim_idle'
  | 'swim_forward'
  | 'fall'
  | 'roll'
  | 'dodge'
  | 'pickup'
  | 'use_item'
  | 'talk'
  | 'wave'
  | 'dance';

/** すべてのモーション名 (タイプガード/イテレーション用) */
export const ALL_MOTIONS: readonly MotionName[] = [
  'idle', 'walk', 'run', 'sprint',
  'jump_start', 'jump_loop', 'jump_land', 'jump_full',
  'attack_punch', 'attack_kick', 'attack_sword', 'attack_gun_pistol', 'attack_gun_rifle',
  'hit_react_light', 'hit_react_heavy', 'death',
  'crouch_idle', 'crouch_walk',
  'climb_up', 'climb_idle',
  'swim_idle', 'swim_forward',
  'fall', 'roll', 'dodge',
  'pickup', 'use_item', 'talk', 'wave', 'dance',
] as const;

/** 出力フォーマット */
export type MotionFormat = 'fbx' | 'gltf' | 'glb' | 'bvh';

/** モーション取得リクエスト */
export interface MotionRequest {
  /** Mixamo にアップロードするキャラクターメッシュの URL */
  characterMeshUrl: string;
  /** 取得したいモーション名の配列 */
  motions: MotionName[];
  /** 出力フォーマット (デフォルト: 'glb') */
  outputFormat?: MotionFormat;
  /** 乱数 seed (fallback モードで決定論的 URL を生成するのに使用) */
  seed?: number;
  /** API key (省略時は環境変数 MIXAMO_API_KEY を参照) */
  apiKey?: string;
}

/** 1 モーションあたりのメタデータ */
export interface MotionMetadata {
  /** ダウンロード可能な URL */
  url: string;
  /** 長さ (秒) */
  duration: number;
  /** フレームレート (Hz) */
  frameRate: number;
  /** ループ可能か */
  loopable: boolean;
}

/** モーション取得結果 */
export interface MotionResult {
  /** 入力メッシュ URL (echo back) */
  characterMeshUrl: string;
  /** モーション名 → メタデータ のマップ */
  motions: Partial<Record<MotionName, MotionMetadata>>;
  /** 警告/注意事項 (rigging 失敗・モーション欠落など) */
  warningsNotes: string[];
}

/**
 * MotionProvider インタフェース。
 * Mixamo / Cascadeur など、複数の実装が共通で実装する契約。
 */
export interface MotionProvider {
  /** プロバイダ名 (ログ/監査用) */
  name: string;
  /** 取得実行 */
  fetch(req: MotionRequest): Promise<MotionResult>;
}

// ---- モーションの「物理的な」既定値 --------------------------------------- //

/**
 * 各モーションの既定 duration / frameRate / loopable。
 * 実機テスト等で計測した平均値をハードコードしている。
 * fallback 時の MotionMetadata 生成に使用。
 */
const MOTION_DEFAULTS: Record<MotionName, { duration: number; frameRate: number; loopable: boolean }> = {
  idle:               { duration: 2.5,  frameRate: 30, loopable: true  },
  walk:               { duration: 1.0,  frameRate: 30, loopable: true  },
  run:                { duration: 0.8,  frameRate: 30, loopable: true  },
  sprint:             { duration: 0.6,  frameRate: 30, loopable: true  },
  jump_start:         { duration: 0.35, frameRate: 30, loopable: false },
  jump_loop:          { duration: 0.4,  frameRate: 30, loopable: true  },
  jump_land:          { duration: 0.5,  frameRate: 30, loopable: false },
  jump_full:          { duration: 1.5,  frameRate: 30, loopable: false },
  attack_punch:       { duration: 0.7,  frameRate: 30, loopable: false },
  attack_kick:        { duration: 0.9,  frameRate: 30, loopable: false },
  attack_sword:       { duration: 1.1,  frameRate: 30, loopable: false },
  attack_gun_pistol:  { duration: 0.5,  frameRate: 30, loopable: false },
  attack_gun_rifle:   { duration: 0.6,  frameRate: 30, loopable: false },
  hit_react_light:    { duration: 0.4,  frameRate: 30, loopable: false },
  hit_react_heavy:    { duration: 0.9,  frameRate: 30, loopable: false },
  death:              { duration: 2.0,  frameRate: 30, loopable: false },
  crouch_idle:        { duration: 2.0,  frameRate: 30, loopable: true  },
  crouch_walk:        { duration: 1.2,  frameRate: 30, loopable: true  },
  climb_up:           { duration: 1.5,  frameRate: 30, loopable: true  },
  climb_idle:         { duration: 2.0,  frameRate: 30, loopable: true  },
  swim_idle:          { duration: 2.5,  frameRate: 30, loopable: true  },
  swim_forward:       { duration: 1.2,  frameRate: 30, loopable: true  },
  fall:               { duration: 0.8,  frameRate: 30, loopable: true  },
  roll:               { duration: 0.8,  frameRate: 30, loopable: false },
  dodge:              { duration: 0.5,  frameRate: 30, loopable: false },
  pickup:             { duration: 1.0,  frameRate: 30, loopable: false },
  use_item:           { duration: 1.2,  frameRate: 30, loopable: false },
  talk:               { duration: 3.0,  frameRate: 30, loopable: true  },
  wave:               { duration: 1.8,  frameRate: 30, loopable: false },
  dance:              { duration: 4.0,  frameRate: 30, loopable: true  },
};

// ---- 内部ユーティリティ --------------------------------------------------- //

/**
 * Mulberry32 アルゴリズムによる決定論的乱数生成器。
 * seed が同じなら何度呼び出しても同じ系列が出る。
 */
function makeRng(seed: number): () => number {
  let s = seed >>> 0;
  return function rng(): number {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * Mixamo API key を解決する。
 * 1. req.apiKey
 * 2. process.env.MIXAMO_API_KEY
 * いずれかが取れれば返し、取れなければ null を返す (fallback モード)。
 */
function resolveApiKey(req: MotionRequest): string | null {
  if (req.apiKey && req.apiKey.length > 0) return req.apiKey;
  const env = typeof process !== 'undefined' ? process.env?.MIXAMO_API_KEY : undefined;
  if (env && env.length > 0) return env;
  return null;
}

/**
 * fallback 用のモック URL を生成する。
 * 同じ (seed, motion) なら必ず同じ URL を返す決定論性を保証。
 */
function buildMockUrl(motion: MotionName, format: MotionFormat, rng: () => number): string {
  const hash = Math.floor(rng() * 0xffffff).toString(16).padStart(6, '0');
  return `mock://soloptilink/mixamo/${motion}_${hash}.${format}`;
}

// ---- MixamoAdapter 本体 -------------------------------------------------- //

/**
 * MixamoAdapter
 * - 実 API 接続時: POST /v1/character → POST /v1/animation → GET /v1/result
 * - API key 不在時: fallback (決定論モック)
 */
export class MixamoAdapter implements MotionProvider {
  public readonly name = 'mixamo';

  /** API エンドポイント (差し替え可能) */
  constructor(public readonly endpoint: string = 'https://api.mixamo.com') {}

  public async fetch(req: MotionRequest): Promise<MotionResult> {
    if (!req.characterMeshUrl) {
      throw new Error('[MixamoAdapter] characterMeshUrl は必須です');
    }
    if (!req.motions || req.motions.length === 0) {
      throw new Error('[MixamoAdapter] motions が空です');
    }

    const apiKey = resolveApiKey(req);
    if (apiKey === null) {
      // ---- fallback (オフライン) ---- //
      return this.fetchFallback(req);
    }
    // ---- 実 API ---- //
    return this.fetchOnline(req, apiKey);
  }

  // -- 実 API 呼び出し -- //
  private async fetchOnline(req: MotionRequest, apiKey: string): Promise<MotionResult> {
    const format: MotionFormat = req.outputFormat ?? 'glb';
    const warnings: string[] = [];

    // 1. キャラクターアップロード (rigging)
    let charId: string;
    try {
      const upRes = await fetch(`${this.endpoint}/v1/character`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Authorization: `Bearer ${apiKey}`,
        },
        body: JSON.stringify({ meshUrl: req.characterMeshUrl }),
      });
      if (!upRes.ok) {
        throw new Error(`upload failed: HTTP ${upRes.status}`);
      }
      const upJson = (await upRes.json()) as { characterId: string };
      charId = upJson.characterId;
    } catch (e) {
      // アップロード自体に失敗したら fallback に縮退
      warnings.push(`rigging failed (${(e as Error).message}), falling back to mock`);
      return this.fetchFallback(req, warnings);
    }

    // 2. 各モーション取得 (並列)
    const motions: Partial<Record<MotionName, MotionMetadata>> = {};
    await Promise.all(req.motions.map(async (m) => {
      try {
        const animRes = await fetch(`${this.endpoint}/v1/animation`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${apiKey}`,
          },
          body: JSON.stringify({ characterId: charId, motion: m, format }),
        });
        if (!animRes.ok) throw new Error(`HTTP ${animRes.status}`);
        const animJson = (await animRes.json()) as {
          url: string;
          duration?: number;
          frameRate?: number;
          loopable?: boolean;
        };
        const def = MOTION_DEFAULTS[m];
        motions[m] = {
          url: animJson.url,
          duration: animJson.duration ?? def.duration,
          frameRate: animJson.frameRate ?? def.frameRate,
          loopable: animJson.loopable ?? def.loopable,
        };
      } catch (e) {
        warnings.push(`motion '${m}' failed: ${(e as Error).message}`);
      }
    }));

    return {
      characterMeshUrl: req.characterMeshUrl,
      motions,
      warningsNotes: warnings,
    };
  }

  // -- fallback (オフライン決定論) -- //
  private async fetchFallback(req: MotionRequest, preWarnings: string[] = []): Promise<MotionResult> {
    const format: MotionFormat = req.outputFormat ?? 'glb';
    const seed = req.seed ?? 12345;
    const rng = makeRng(seed);

    const warnings = [...preWarnings, 'MIXAMO_API_KEY 未設定: fallback モックを返却'];
    const motions: Partial<Record<MotionName, MotionMetadata>> = {};

    for (const m of req.motions) {
      const def = MOTION_DEFAULTS[m];
      motions[m] = {
        url: buildMockUrl(m, format, rng),
        duration: def.duration,
        frameRate: def.frameRate,
        loopable: def.loopable,
      };
    }
    // ノンブロッキング Promise (大型アセットの非同期感を模倣)
    await Promise.resolve();
    return {
      characterMeshUrl: req.characterMeshUrl,
      motions,
      warningsNotes: warnings,
    };
  }
}

/**
 * 便利関数: 1 回の呼び出しで Adapter を作成しモーションを取得する。
 */
export async function fetchMotions(req: MotionRequest): Promise<MotionResult> {
  const adapter = new MixamoAdapter();
  return adapter.fetch(req);
}
