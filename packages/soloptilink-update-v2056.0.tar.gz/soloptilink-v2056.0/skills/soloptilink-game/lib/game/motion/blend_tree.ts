/**
 * blend_tree.ts
 * =============================================================================
 * 責務: 2D Blendspace (ブレンドツリー) 実装
 * -----------------------------------------------------------------------------
 * 用途例:
 *   ノード:
 *     - walk_forward  -> [ 0,  1]
 *     - walk_backward -> [ 0, -1]
 *     - strafe_left   -> [-1,  0]
 *     - strafe_right  -> [ 1,  0]
 *     - idle          -> [ 0,  0]
 *   2D 入力 (forward, right) から、各モーションの混合重みを返す。
 *
 * アルゴリズム:
 *   - 距離ベース逆数加重 (Inverse Distance Weighting / IDW)。
 *   - 入力がノードと完全一致したら重み 1.0 をそのノードに、他は 0 を割り当てる。
 *   - 全ノードからの距離 d_i から w_i = 1 / d_i^p (p=2) を計算し、総和で正規化。
 *   - k 近傍 (kNN) で上位 4 ノードに制限すると安定。
 *
 * 計算量: O(n log n) の sort 1 回 + O(k) の正規化 (n=ノード数, k=近傍数)。
 * -----------------------------------------------------------------------------
 * SoloptiLinkAI v2034.x  /soloptilink-game v2.0
 * =============================================================================
 */

import type { MotionName } from './mixamo_adapter';

// ---- 型定義 --------------------------------------------------------------- //

/** ブレンドツリー上の 1 ノード */
export interface BlendTreeNode {
  /** モーション名 */
  motion: MotionName;
  /**
   * 2D 平面上の座標。
   * 例: walk_forward は [0, 1], strafe_left は [-1, 0]。
   */
  position2d: [number, number];
}

/** 評価結果: 各モーションへの重み (重み合計 = 1.0 になることを保証) */
export interface BlendWeight {
  motion: MotionName;
  weight: number;
}

/** BlendTree オプション */
export interface BlendTreeOptions {
  /** 近傍数 (デフォルト 4) */
  kNeighbors?: number;
  /** 距離指数 (デフォルト 2) */
  power?: number;
  /** ノード一致判定の閾値 (デフォルト 1e-4) */
  epsilon?: number;
}

// ---- BlendTree 本体 ------------------------------------------------------ //

/**
 * 2D ブレンドツリー。
 * - new BlendTree(nodes) でインスタンス化
 * - evaluate([forward, right]) で重みを得る
 */
export class BlendTree {
  private readonly k: number;
  private readonly p: number;
  private readonly eps: number;

  constructor(
    public readonly nodes: BlendTreeNode[],
    options: BlendTreeOptions = {},
  ) {
    if (nodes.length === 0) {
      throw new Error('[BlendTree] nodes が空です');
    }
    this.k = Math.max(1, options.kNeighbors ?? 4);
    this.p = options.power ?? 2;
    this.eps = options.epsilon ?? 1e-4;
  }

  /**
   * 重複モーションを統合 (同名モーションは平均位置にマージ)。
   * 必要なときだけ呼ぶ補助 API。
   */
  public dedupe(): BlendTree {
    const byMotion = new Map<MotionName, { sumX: number; sumY: number; n: number }>();
    for (const n of this.nodes) {
      const cur = byMotion.get(n.motion) ?? { sumX: 0, sumY: 0, n: 0 };
      cur.sumX += n.position2d[0];
      cur.sumY += n.position2d[1];
      cur.n += 1;
      byMotion.set(n.motion, cur);
    }
    const merged: BlendTreeNode[] = [];
    for (const [motion, v] of byMotion) {
      merged.push({ motion, position2d: [v.sumX / v.n, v.sumY / v.n] });
    }
    return new BlendTree(merged, {
      kNeighbors: this.k,
      power: this.p,
      epsilon: this.eps,
    });
  }

  /**
   * 入力点に対する各モーションの重みを返す。
   * 重みは正規化済 (Σweight = 1)。
   */
  public evaluate(input: [number, number]): BlendWeight[] {
    const [ix, iy] = input;

    // 1) 各ノードまでの距離を計算
    const dists: Array<{ idx: number; d: number }> = [];
    for (let i = 0; i < this.nodes.length; i++) {
      const [nx, ny] = this.nodes[i].position2d;
      const dx = ix - nx;
      const dy = iy - ny;
      const d = Math.sqrt(dx * dx + dy * dy);
      dists.push({ idx: i, d });
      // 完全一致なら early return
      if (d < this.eps) {
        return this.nodes.map((n, j) =>
          j === i
            ? { motion: n.motion, weight: 1.0 }
            : { motion: n.motion, weight: 0.0 },
        );
      }
    }

    // 2) k 近傍を抽出
    dists.sort((a, b) => a.d - b.d);
    const neighbors = dists.slice(0, Math.min(this.k, dists.length));

    // 3) 逆距離加重 (w_i = 1 / d_i^p)
    let sumW = 0;
    const rawWeights: number[] = [];
    for (const nb of neighbors) {
      const w = 1 / Math.pow(nb.d, this.p);
      rawWeights.push(w);
      sumW += w;
    }

    // 4) 正規化
    const result: BlendWeight[] = this.nodes.map((n) => ({
      motion: n.motion,
      weight: 0,
    }));
    for (let i = 0; i < neighbors.length; i++) {
      const idx = neighbors[i].idx;
      result[idx] = {
        motion: this.nodes[idx].motion,
        weight: rawWeights[i] / sumW,
      };
    }

    // 5) 浮動小数点誤差で合計が 1 から微妙にずれることがあるため再正規化
    const finalSum = result.reduce((acc, r) => acc + r.weight, 0);
    if (finalSum > 0 && Math.abs(finalSum - 1) > 1e-9) {
      for (const r of result) r.weight /= finalSum;
    }

    return result;
  }

  /**
   * 入力点に対する「主要モーション 1 つ + 重み」だけが欲しいケース用。
   */
  public evaluateDominant(input: [number, number]): BlendWeight {
    const weights = this.evaluate(input);
    let best: BlendWeight = weights[0];
    for (const w of weights) {
      if (w.weight > best.weight) best = w;
    }
    return best;
  }

  /**
   * 入力点が「ノード網羅範囲外」かどうか判定する。
   * - 全ノード座標の凸包 (簡易バウンディングボックスで近似) の外に出ているか
   */
  public isOutOfRange(input: [number, number]): boolean {
    let minX = Infinity, maxX = -Infinity, minY = Infinity, maxY = -Infinity;
    for (const n of this.nodes) {
      const [x, y] = n.position2d;
      if (x < minX) minX = x;
      if (x > maxX) maxX = x;
      if (y < minY) minY = y;
      if (y > maxY) maxY = y;
    }
    return input[0] < minX || input[0] > maxX || input[1] < minY || input[1] > maxY;
  }

  /**
   * 標準的な移動 8 方向ブレンドツリーを返す static factory。
   * (forward / back / strafe / 斜め)
   */
  public static defaultLocomotion(): BlendTree {
    return new BlendTree([
      { motion: 'idle',          position2d: [ 0,  0] },
      { motion: 'walk',          position2d: [ 0,  1] },  // 前進
      { motion: 'walk',          position2d: [ 0, -1] },  // 後退 (同名で別ポジ)
      { motion: 'walk',          position2d: [-1,  0] },  // 左ストレイフ
      { motion: 'walk',          position2d: [ 1,  0] },  // 右ストレイフ
      { motion: 'run',           position2d: [ 0,  2] },  // 全力前進
      { motion: 'crouch_walk',   position2d: [ 0,  0.5] }, // しゃがみ前進
    ]);
  }
}

/**
 * 便利関数: 単発で評価。
 */
export function blendEvaluate(
  nodes: BlendTreeNode[],
  input: [number, number],
  options?: BlendTreeOptions,
): BlendWeight[] {
  return new BlendTree(nodes, options).evaluate(input);
}
