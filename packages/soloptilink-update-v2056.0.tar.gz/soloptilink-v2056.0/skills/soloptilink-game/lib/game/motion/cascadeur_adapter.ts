/**
 * cascadeur_adapter.ts
 * =============================================================================
 * 責務: Cascadeur (物理ベースモーション編集ツール) アダプタ
 * -----------------------------------------------------------------------------
 * Mixamo 等で取得した base motion に対して「キーフレーム単位の上書き」と
 * 「物理拘束 (バランスロック / 慣性保存)」を適用し、新しいモーション URL を
 * 返却する。
 *
 * 設計方針:
 *   - mixamo_adapter.ts と同じ MotionProvider インタフェースを実装する
 *     (これにより上位のステートマシン生成は実装非依存)。
 *   - 物理ソルバは AABB ベースの軽量実装にとどめ、本格的な剛体シミュレーション
 *     は外部委譲する余地を残す (CascadeurEditOptions.physicalConstraints)。
 *   - すべての処理を async (Promise) でラップ。
 *   - 乱数は seed 可能 (結果の URL/hash 再現)。
 * -----------------------------------------------------------------------------
 * SoloptiLinkAI v2034.x  /soloptilink-game v2.0
 * =============================================================================
 */

import type {
  MotionName,
  MotionRequest,
  MotionResult,
  MotionMetadata,
  MotionProvider,
  MotionFormat,
} from './mixamo_adapter';

// ---- Cascadeur 固有型 ----------------------------------------------------- //

/** キーフレーム編集 (1 ボーン分) */
export interface KeyframeEdit {
  /** 編集対象のキーフレーム番号 (0-based) */
  keyframe: number;
  /** ボーン名 (例: 'mixamorig:Spine', 'mixamorig:LeftArm') */
  bone: string;
  /** 回転 [pitch, yaw, roll] (deg) — 省略可 */
  rotation?: [number, number, number];
  /** 位置 [x, y, z] (m) — 省略可 */
  position?: [number, number, number];
}

/** 物理拘束 */
export interface PhysicalConstraints {
  /** バランスロック: 重心を支持基底面に保ち続ける */
  balanceLock: boolean;
  /** 慣性保存: 角運動量/線運動量を保持し、滑らかさを担保する */
  momentumPreservation: boolean;
  /** 重力 (m/s^2)。省略時は 9.81 */
  gravity?: number;
  /** 摩擦係数 (0..1)。省略時は 0.6 */
  friction?: number;
}

/** Cascadeur 編集オプション */
export interface CascadeurEditOptions {
  /** 編集元モーションの URL (Mixamo 取得物など) */
  basemotionUrl: string;
  /** キーフレーム編集の配列 */
  modifications: KeyframeEdit[];
  /** 物理拘束 (任意) */
  physicalConstraints?: PhysicalConstraints;
  /** 出力フォーマット (デフォルト: 'glb') */
  outputFormat?: MotionFormat;
  /** 乱数 seed */
  seed?: number;
  /** 編集対象モーション名 (タグ) */
  motionName?: MotionName;
}

// ---- 内部ユーティリティ --------------------------------------------------- //

/**
 * Mulberry32 (mixamo_adapter と同形・別 instance)。
 */
function makeRng(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * バランスロックの簡易判定。
 *
 *  - 各 KeyframeEdit.position を「重心 (COM)」の摂動とみなす。
 *  - すべての COM 摂動の合計が水平面で 0.5 m 以内に収まっていれば
 *    「バランス可能」と判断し、超えていれば自動補正をかける。
 *
 * 本実装は教育用の近似であり、本格的なフルボディ IK は外部に委ねる。
 */
function applyBalanceLock(edits: KeyframeEdit[]): KeyframeEdit[] {
  let sumX = 0;
  let sumZ = 0;
  for (const e of edits) {
    if (e.position) {
      sumX += e.position[0];
      sumZ += e.position[2];
    }
  }
  const drift = Math.hypot(sumX, sumZ);
  if (drift <= 0.5) return edits; // 許容範囲内

  // 反対向きに均等補正を入れる
  const correctionX = -sumX / Math.max(edits.length, 1);
  const correctionZ = -sumZ / Math.max(edits.length, 1);
  return edits.map((e) => ({
    ...e,
    position: e.position
      ? [e.position[0] + correctionX, e.position[1], e.position[2] + correctionZ]
      : undefined,
  }));
}

/**
 * 慣性保存の簡易補正。
 *
 *  - 連続するキーフレーム間の rotation 差分を「角速度」と見なす。
 *  - 隣接キーフレーム間で 90 deg/frame を超える急変化があれば、
 *    線形補間で 90 deg 以内に収める。
 */
function applyMomentumPreservation(edits: KeyframeEdit[]): KeyframeEdit[] {
  const sorted = [...edits].sort((a, b) => a.keyframe - b.keyframe);
  const MAX_DELTA = 90;
  for (let i = 1; i < sorted.length; i++) {
    const prev = sorted[i - 1];
    const cur = sorted[i];
    if (!prev.rotation || !cur.rotation) continue;
    if (prev.bone !== cur.bone) continue;
    const out: [number, number, number] = [cur.rotation[0], cur.rotation[1], cur.rotation[2]];
    for (let axis = 0; axis < 3; axis++) {
      const delta = cur.rotation[axis] - prev.rotation[axis];
      if (Math.abs(delta) > MAX_DELTA) {
        const sign = delta >= 0 ? 1 : -1;
        out[axis] = prev.rotation[axis] + sign * MAX_DELTA;
      }
    }
    sorted[i] = { ...cur, rotation: out };
  }
  return sorted;
}

/**
 * 編集後 URL を決定論的に生成する。
 */
function buildEditedUrl(baseUrl: string, format: MotionFormat, rng: () => number): string {
  const hash = Math.floor(rng() * 0xffffff).toString(16).padStart(6, '0');
  // baseUrl からファイル名らしき末尾を抜き取って prefix にする
  const last = baseUrl.split('/').pop() ?? 'edited';
  const stem = last.replace(/\.(fbx|gltf|glb|bvh)$/i, '');
  return `cascadeur://soloptilink/edited/${stem}_${hash}.${format}`;
}

// ---- CascadeurAdapter 本体 ------------------------------------------------ //

/**
 * CascadeurAdapter
 * - MotionProvider インタフェースに準拠。
 * - fetch() の引数 MotionRequest は characterMeshUrl を base motion URL の
 *   代わりに使用する (アダプタとしての契約は維持しつつ、編集対象を渡す)。
 * - 詳細な編集を行う場合は editMotion() を直接呼ぶこと。
 */
export class CascadeurAdapter implements MotionProvider {
  public readonly name = 'cascadeur';

  constructor(public readonly endpoint: string = 'https://api.cascadeur.io') {}

  /**
   * MotionProvider 契約による fetch。
   *
   *  - characterMeshUrl を base motion URL として扱う
   *  - 編集オプションは省略され、metadata 既定値で「無編集コピー」を返す
   */
  public async fetch(req: MotionRequest): Promise<MotionResult> {
    if (!req.characterMeshUrl) {
      throw new Error('[CascadeurAdapter] characterMeshUrl (base motion URL) は必須です');
    }
    if (!req.motions || req.motions.length === 0) {
      throw new Error('[CascadeurAdapter] motions が空です');
    }

    const format = req.outputFormat ?? 'glb';
    const seed = req.seed ?? 67890;
    const rng = makeRng(seed);

    // 全モーションに対し base motion URL を共通の編集元として扱う
    const motions: Partial<Record<MotionName, MotionMetadata>> = {};
    for (const m of req.motions) {
      const url = buildEditedUrl(req.characterMeshUrl, format, rng);
      motions[m] = {
        url,
        duration: 1.0,
        frameRate: 30,
        loopable: false,
      };
    }

    return {
      characterMeshUrl: req.characterMeshUrl,
      motions,
      warningsNotes: [
        'CascadeurAdapter.fetch は無編集の構造のみを返却します。',
        '実編集には editMotion() を使用してください。',
      ],
    };
  }

  /**
   * 本命: キーフレーム編集 + 物理拘束を適用してモーションを生成する。
   */
  public async editMotion(opts: CascadeurEditOptions): Promise<MotionMetadata> {
    if (!opts.basemotionUrl) {
      throw new Error('[CascadeurAdapter] basemotionUrl は必須です');
    }
    const format = opts.outputFormat ?? 'glb';
    const seed = opts.seed ?? 67890;
    const rng = makeRng(seed);

    // 1) キーフレーム編集の前処理 (バリデーション)
    let edits = opts.modifications.filter((e) => e.bone && Number.isFinite(e.keyframe));

    // 2) 物理拘束
    if (opts.physicalConstraints?.balanceLock) {
      edits = applyBalanceLock(edits);
    }
    if (opts.physicalConstraints?.momentumPreservation) {
      edits = applyMomentumPreservation(edits);
    }

    // 3) 出力 URL の組み立て
    const url = buildEditedUrl(opts.basemotionUrl, format, rng);

    // 4) 編集モーションの長さ推定 = 最大 keyframe / frameRate
    const frameRate = 30;
    const maxKf = edits.reduce((mx, e) => Math.max(mx, e.keyframe), 0);
    const duration = Math.max(0.5, maxKf / frameRate);

    // ノンブロッキング (実 API 呼び出しを想定して async 化)
    await Promise.resolve();
    return {
      url,
      duration,
      frameRate,
      loopable: false,
    };
  }
}

/**
 * 便利関数: 1 回の呼び出しで Adapter を作って編集する。
 */
export async function editWithCascadeur(opts: CascadeurEditOptions): Promise<MotionMetadata> {
  const adapter = new CascadeurAdapter();
  return adapter.editMotion(opts);
}
