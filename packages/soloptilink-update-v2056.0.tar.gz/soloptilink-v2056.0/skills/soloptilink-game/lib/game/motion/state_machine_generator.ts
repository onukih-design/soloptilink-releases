/**
 * state_machine_generator.ts
 * =============================================================================
 * 責務: ジャンル + 所有モーションリストから「モーションステートマシン」を
 *       自動生成する。Three.js / Unity / Phaser 向けのコードも出力可能。
 * -----------------------------------------------------------------------------
 * 入出力:
 *   入力:
 *     - genre: 'action_2d' | '3d_action' | '3d_shooter' | 'rpg' | ...
 *     - ownedMotions: 実際に取得できているモーション (= ノードに使える集合)
 *   出力:
 *     - StateMachineSpec  (state ノード + transitions + default state)
 *     - exportToThreeJs / exportToUnity でエンジン用コードを文字列化
 *
 * 設計方針:
 *   - ジャンルごとに必要な「コアステート」と「コアトランジション」を辞書化。
 *   - ownedMotions に含まれないステートは自動的にドロップし、関連トランジ
 *     ションも除去する (壊れない契約)。
 *   - 既定ステートは常に 'idle' (なければ ownedMotions の先頭)。
 *   - 出力コードは「人間がそのまま貼り付け→微調整で動く」レベルを目指す。
 * -----------------------------------------------------------------------------
 * SoloptiLinkAI v2034.x  /soloptilink-game v2.0
 * =============================================================================
 */

import type { MotionName } from './mixamo_adapter';

// ---- 型定義 --------------------------------------------------------------- //

export interface StateSpec {
  /** ステート名 = MotionName と同一 */
  name: MotionName;
  /** ループ可能か */
  loop: boolean;
}

export interface TransitionSpec {
  from: MotionName;
  to: MotionName;
  /**
   * 遷移条件式 (JS/C# 風文字列)。
   * 例: 'velocity > 0.1 && !grounded'
   *     'input.fire == true && !reloading'
   */
  condition: string;
  /** ブレンド時間 (ms) */
  blendTimeMs: number;
}

export interface StateMachineSpec {
  states: StateSpec[];
  transitions: TransitionSpec[];
  defaultState: MotionName;
}

// ---- ジャンル別テンプレート ---------------------------------------------- //

/**
 * ジャンル別の「期待するモーション集合」と「典型的なトランジション」。
 * 順序が重要 (defaultState は先頭、後段で ownedMotions と交差を取る)。
 */
interface GenreTemplate {
  states: StateSpec[];
  transitions: TransitionSpec[];
}

const GENRE_TEMPLATES: Record<string, GenreTemplate> = {
  // 2D アクション (横スクロール風)
  action_2d: {
    states: [
      { name: 'idle',       loop: true  },
      { name: 'walk',       loop: true  },
      { name: 'run',        loop: true  },
      { name: 'jump_start', loop: false },
      { name: 'jump_loop',  loop: true  },
      { name: 'jump_land',  loop: false },
      { name: 'attack_punch', loop: false },
      { name: 'hit_react_light', loop: false },
      { name: 'death',      loop: false },
    ],
    transitions: [
      { from: 'idle',       to: 'walk',         condition: 'input.move != 0', blendTimeMs: 120 },
      { from: 'walk',       to: 'run',          condition: 'input.sprint == true', blendTimeMs: 100 },
      { from: 'run',        to: 'walk',         condition: 'input.sprint == false', blendTimeMs: 100 },
      { from: 'walk',       to: 'idle',         condition: 'input.move == 0', blendTimeMs: 120 },
      { from: 'idle',       to: 'jump_start',   condition: 'input.jump == true && grounded', blendTimeMs: 60 },
      { from: 'jump_start', to: 'jump_loop',    condition: 'state.elapsed >= 0.3', blendTimeMs: 80 },
      { from: 'jump_loop',  to: 'jump_land',    condition: 'grounded', blendTimeMs: 80 },
      { from: 'jump_land',  to: 'idle',         condition: 'state.elapsed >= 0.5', blendTimeMs: 100 },
      { from: 'idle',       to: 'attack_punch', condition: 'input.attack == true', blendTimeMs: 60 },
      { from: 'attack_punch', to: 'idle',       condition: 'state.elapsed >= duration', blendTimeMs: 80 },
      { from: 'idle',       to: 'hit_react_light', condition: 'event.hit == "light"', blendTimeMs: 50 },
      { from: 'hit_react_light', to: 'idle',    condition: 'state.elapsed >= duration', blendTimeMs: 100 },
      { from: 'idle',       to: 'death',        condition: 'hp <= 0', blendTimeMs: 100 },
    ],
  },

  // 3D アクション (近接戦闘 / メレー)
  '3d_action': {
    states: [
      { name: 'idle',       loop: true  },
      { name: 'walk',       loop: true  },
      { name: 'run',        loop: true  },
      { name: 'sprint',     loop: true  },
      { name: 'jump_full',  loop: false },
      { name: 'attack_sword', loop: false },
      { name: 'roll',       loop: false },
      { name: 'dodge',      loop: false },
      { name: 'hit_react_light', loop: false },
      { name: 'hit_react_heavy', loop: false },
      { name: 'death',      loop: false },
    ],
    transitions: [
      { from: 'idle',  to: 'walk',   condition: 'velocity > 0.1', blendTimeMs: 150 },
      { from: 'walk',  to: 'run',    condition: 'velocity > 2.0', blendTimeMs: 150 },
      { from: 'run',   to: 'sprint', condition: 'input.sprint && velocity > 4.0', blendTimeMs: 150 },
      { from: 'walk',  to: 'idle',   condition: 'velocity <= 0.1', blendTimeMs: 200 },
      { from: 'run',   to: 'walk',   condition: 'velocity < 1.5', blendTimeMs: 150 },
      { from: 'idle',  to: 'jump_full', condition: 'input.jump && grounded', blendTimeMs: 80 },
      { from: 'jump_full', to: 'idle', condition: 'grounded && state.elapsed >= 1.0', blendTimeMs: 100 },
      { from: 'idle',  to: 'attack_sword', condition: 'input.attack', blendTimeMs: 60 },
      { from: 'attack_sword', to: 'idle',  condition: 'state.elapsed >= duration', blendTimeMs: 100 },
      { from: 'idle',  to: 'roll',  condition: 'input.dodge && stamina > 20', blendTimeMs: 60 },
      { from: 'roll',  to: 'idle',  condition: 'state.elapsed >= duration', blendTimeMs: 100 },
      { from: 'idle',  to: 'hit_react_light', condition: 'event.hit == "light"', blendTimeMs: 60 },
      { from: 'idle',  to: 'hit_react_heavy', condition: 'event.hit == "heavy"', blendTimeMs: 80 },
      { from: 'idle',  to: 'death', condition: 'hp <= 0', blendTimeMs: 150 },
    ],
  },

  // 3D シューター
  '3d_shooter': {
    states: [
      { name: 'idle',        loop: true  },
      { name: 'walk',        loop: true  },
      { name: 'run',         loop: true  },
      { name: 'crouch_idle', loop: true  },
      { name: 'crouch_walk', loop: true  },
      { name: 'attack_gun_pistol', loop: false },
      { name: 'attack_gun_rifle',  loop: false },
      { name: 'hit_react_light',   loop: false },
      { name: 'death',       loop: false },
    ],
    transitions: [
      { from: 'idle', to: 'walk',  condition: 'velocity > 0.1', blendTimeMs: 150 },
      { from: 'walk', to: 'run',   condition: 'input.sprint && velocity > 3.5', blendTimeMs: 150 },
      { from: 'run',  to: 'walk',  condition: 'velocity < 2.0', blendTimeMs: 150 },
      { from: 'walk', to: 'idle',  condition: 'velocity <= 0.1', blendTimeMs: 200 },
      { from: 'idle', to: 'crouch_idle', condition: 'input.crouch', blendTimeMs: 150 },
      { from: 'crouch_idle', to: 'crouch_walk', condition: 'velocity > 0.1', blendTimeMs: 120 },
      { from: 'crouch_walk', to: 'crouch_idle', condition: 'velocity <= 0.1', blendTimeMs: 120 },
      { from: 'crouch_idle', to: 'idle', condition: '!input.crouch', blendTimeMs: 150 },
      { from: 'idle', to: 'attack_gun_pistol', condition: 'input.fire && weapon == "pistol"', blendTimeMs: 40 },
      { from: 'idle', to: 'attack_gun_rifle',  condition: 'input.fire && weapon == "rifle"',  blendTimeMs: 40 },
      { from: 'attack_gun_pistol', to: 'idle', condition: 'state.elapsed >= duration', blendTimeMs: 60 },
      { from: 'attack_gun_rifle',  to: 'idle', condition: 'state.elapsed >= duration', blendTimeMs: 60 },
      { from: 'idle', to: 'hit_react_light', condition: 'event.hit', blendTimeMs: 60 },
      { from: 'idle', to: 'death', condition: 'hp <= 0', blendTimeMs: 150 },
    ],
  },

  // RPG (会話・拾得・歩行中心)
  rpg: {
    states: [
      { name: 'idle',     loop: true  },
      { name: 'walk',     loop: true  },
      { name: 'run',      loop: true  },
      { name: 'pickup',   loop: false },
      { name: 'use_item', loop: false },
      { name: 'talk',     loop: true  },
      { name: 'wave',     loop: false },
      { name: 'death',    loop: false },
    ],
    transitions: [
      { from: 'idle', to: 'walk',     condition: 'velocity > 0.1', blendTimeMs: 200 },
      { from: 'walk', to: 'run',      condition: 'input.sprint', blendTimeMs: 200 },
      { from: 'run',  to: 'walk',     condition: '!input.sprint', blendTimeMs: 200 },
      { from: 'walk', to: 'idle',     condition: 'velocity <= 0.1', blendTimeMs: 250 },
      { from: 'idle', to: 'pickup',   condition: 'input.interact && context == "item"', blendTimeMs: 100 },
      { from: 'pickup', to: 'idle',   condition: 'state.elapsed >= duration', blendTimeMs: 150 },
      { from: 'idle', to: 'use_item', condition: 'input.item', blendTimeMs: 100 },
      { from: 'use_item', to: 'idle', condition: 'state.elapsed >= duration', blendTimeMs: 150 },
      { from: 'idle', to: 'talk',     condition: 'input.interact && context == "npc"', blendTimeMs: 150 },
      { from: 'talk', to: 'idle',     condition: '!conversation.active', blendTimeMs: 150 },
      { from: 'idle', to: 'wave',     condition: 'input.emote == "wave"', blendTimeMs: 100 },
      { from: 'wave', to: 'idle',     condition: 'state.elapsed >= duration', blendTimeMs: 150 },
      { from: 'idle', to: 'death',    condition: 'hp <= 0', blendTimeMs: 200 },
    ],
  },
};

// ---- 公開関数 ------------------------------------------------------------ //

/**
 * ジャンル + 所有モーションから StateMachineSpec を生成。
 */
export function generateStateMachine(
  genre: string,
  ownedMotions: MotionName[],
): StateMachineSpec {
  const owned = new Set<MotionName>(ownedMotions);
  const tmpl = GENRE_TEMPLATES[genre] ?? GENRE_TEMPLATES['3d_action'];

  // 1) ステートを所有モーションで filter
  const states = tmpl.states.filter((s) => owned.has(s.name));

  // 2) どちらかの端点が欠けるトランジションは除外
  const transitions = tmpl.transitions.filter(
    (t) => owned.has(t.from) && owned.has(t.to),
  );

  // 3) defaultState 決定: idle があれば idle、なければ states 先頭、なければ ownedMotions 先頭
  let defaultState: MotionName;
  if (owned.has('idle')) {
    defaultState = 'idle';
  } else if (states.length > 0) {
    defaultState = states[0].name;
  } else if (ownedMotions.length > 0) {
    // テンプレートに無いモーションでも fallback で受け入れる
    defaultState = ownedMotions[0];
    states.push({ name: defaultState, loop: true });
  } else {
    throw new Error('[generateStateMachine] ownedMotions が空です');
  }

  return { states, transitions, defaultState };
}

// ---- エンジン別エクスポート ---------------------------------------------- //

/**
 * Three.js (AnimationMixer + 自前 FSM) 用コード生成。
 */
export function exportToThreeJs(spec: StateMachineSpec): string {
  const lines: string[] = [];
  lines.push('// Auto-generated by SoloptiLinkAI /soloptilink-game v2.0');
  lines.push('// Three.js 用モーションステートマシン');
  lines.push('// THREE.AnimationMixer 前提。各 action は事前に mixer.clipAction(clip) で取得済みとする。');
  lines.push('');
  lines.push('export interface MotionFsmActions {');
  for (const s of spec.states) {
    lines.push(`  ${s.name}: THREE.AnimationAction;`);
  }
  lines.push('}');
  lines.push('');
  lines.push('export class MotionFsm {');
  lines.push('  public current: keyof MotionFsmActions;');
  lines.push('  public elapsed = 0;');
  lines.push('  constructor(private actions: MotionFsmActions) {');
  lines.push(`    this.current = '${spec.defaultState}';`);
  lines.push('    this.actions[this.current].play();');
  lines.push('  }');
  lines.push('');
  lines.push('  public update(dt: number, ctx: Record<string, unknown>): void {');
  lines.push('    this.elapsed += dt;');
  lines.push('    const c = this.current;');
  lines.push('    // ---- 遷移評価 ----');
  for (const t of spec.transitions) {
    lines.push(`    if (c === '${t.from}' && (${condToTs(t.condition)})) {`);
    lines.push(`      this.crossFade('${t.to}', ${t.blendTimeMs / 1000});`);
    lines.push(`      return;`);
    lines.push(`    }`);
  }
  lines.push('  }');
  lines.push('');
  lines.push('  private crossFade(next: keyof MotionFsmActions, durSec: number): void {');
  lines.push('    const from = this.actions[this.current];');
  lines.push('    const to = this.actions[next];');
  lines.push('    to.reset().play();');
  lines.push('    from.crossFadeTo(to, durSec, false);');
  lines.push('    this.current = next;');
  lines.push('    this.elapsed = 0;');
  lines.push('  }');
  lines.push('}');
  return lines.join('\n');
}

/**
 * Unity (Mecanim) 用 C# コード生成。
 * ScriptableObject + Animator.CrossFade を使う典型パターン。
 */
export function exportToUnity(spec: StateMachineSpec): string {
  const lines: string[] = [];
  lines.push('// Auto-generated by SoloptiLinkAI /soloptilink-game v2.0');
  lines.push('// Unity Mecanim 用モーションステートマシン');
  lines.push('// Animator の各 state 名は MotionName と一致させること。');
  lines.push('');
  lines.push('using UnityEngine;');
  lines.push('');
  lines.push('public class MotionFsm : MonoBehaviour {');
  lines.push('    public Animator anim;');
  lines.push(`    public string current = "${spec.defaultState}";`);
  lines.push('    public float elapsed = 0f;');
  lines.push('');
  lines.push('    void Update() {');
  lines.push('        elapsed += Time.deltaTime;');
  for (const t of spec.transitions) {
    lines.push(`        if (current == "${t.from}" && (${condToCs(t.condition)})) {`);
    lines.push(`            anim.CrossFade("${t.to}", ${t.blendTimeMs / 1000}f);`);
    lines.push(`            current = "${t.to}"; elapsed = 0f; return;`);
    lines.push(`        }`);
  }
  lines.push('    }');
  lines.push('}');
  return lines.join('\n');
}

/**
 * Phaser 3 用 (2D) コード生成。
 * sprite.anims.play('motion_name', true) ベース。
 */
export function exportToPhaser(spec: StateMachineSpec): string {
  const lines: string[] = [];
  lines.push('// Auto-generated by SoloptiLinkAI /soloptilink-game v2.0');
  lines.push('// Phaser 3 用 (2D) モーションステートマシン');
  lines.push('');
  lines.push('export class MotionFsm {');
  lines.push(`  current = '${spec.defaultState}';`);
  lines.push('  elapsed = 0;');
  lines.push('  constructor(public sprite) { this.sprite.anims.play(this.current, true); }');
  lines.push('  update(dt, ctx) {');
  lines.push('    this.elapsed += dt;');
  lines.push('    const c = this.current;');
  for (const t of spec.transitions) {
    lines.push(`    if (c === '${t.from}' && (${condToTs(t.condition)})) {`);
    lines.push(`      this.sprite.anims.play('${t.to}', true);`);
    lines.push(`      this.current = '${t.to}'; this.elapsed = 0; return;`);
    lines.push(`    }`);
  }
  lines.push('  }');
  lines.push('}');
  return lines.join('\n');
}

// ---- 条件式変換ヘルパ ---------------------------------------------------- //

/**
 * 条件式を TS 風に正規化する (state.elapsed → this.elapsed)。
 */
function condToTs(cond: string): string {
  return cond
    .replace(/state\.elapsed/g, 'this.elapsed')
    .replace(/duration/g, '(ctx.duration as number ?? 1)')
    .replace(/velocity/g, '(ctx.velocity as number ?? 0)')
    .replace(/grounded/g, '(ctx.grounded as boolean ?? true)')
    .replace(/stamina/g, '(ctx.stamina as number ?? 100)')
    .replace(/hp/g, '(ctx.hp as number ?? 100)')
    .replace(/weapon/g, '(ctx.weapon as string ?? "")')
    .replace(/conversation\.active/g, '(ctx.conversationActive as boolean ?? false)')
    .replace(/context/g, '(ctx.context as string ?? "")')
    .replace(/event\.hit/g, '(ctx.eventHit as string ?? "")')
    .replace(/input\./g, '(ctx.input as Record<string,unknown>)?.');
}

/**
 * 条件式を C# 風に正規化する。
 */
function condToCs(cond: string): string {
  return cond
    .replace(/state\.elapsed/g, 'elapsed')
    .replace(/&&/g, '&&')
    .replace(/\|\|/g, '||')
    .replace(/==/g, '==')
    .replace(/input\./g, 'GetInput().');
}
