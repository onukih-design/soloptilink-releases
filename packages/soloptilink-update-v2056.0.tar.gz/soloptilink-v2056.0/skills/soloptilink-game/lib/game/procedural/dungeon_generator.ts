/**
 * dungeon_generator.ts
 * =============================================================================
 * 責務: ダンジョン (2D グリッドベース) 自動生成
 * -----------------------------------------------------------------------------
 * サポート4アルゴリズム:
 *   1. 'bsp'           — Binary Space Partition (再帰二分割 → 部屋配置 → 廊下接続)
 *   2. 'random_rooms'  — 矩形を非衝突でランダム配置 → 最近傍接続
 *   3. 'cellular'      — Cellular Automaton (Game of Life 風) で洞窟生成
 *   4. 'drunkard_walk' — 酔歩 (random walk) で広間を掘る
 *
 * 出力:
 *   - grid: 'floor' | 'wall' | 'door' | 'entrance' | 'exit' | 'treasure' | 'enemy_spawn'
 *   - rooms: 部屋一覧
 *   - startPos / goalPos
 *
 * 設計方針:
 *   - 乱数 seed で完全再現可能
 *   - generate() は async (Promise)
 *   - 入力値のサニタイズ (min > max 等を自動補正)
 * -----------------------------------------------------------------------------
 * SoloptiLinkAI v2034.x  /soloptilink-game v2.0
 * =============================================================================
 */

// ---- 型定義 --------------------------------------------------------------- //

export type DungeonAlgorithm = 'bsp' | 'random_rooms' | 'cellular' | 'drunkard_walk';

export type TileKind =
  | 'floor'
  | 'wall'
  | 'door'
  | 'entrance'
  | 'exit'
  | 'treasure'
  | 'enemy_spawn';

export interface DungeonConfig {
  width: number;
  height: number;
  roomCount: { min: number; max: number };
  roomSize: { min: number; max: number };
  corridorWidth: number;
  algorithm: DungeonAlgorithm;
  seed?: number;
  /** 宝箱配置率 (0..1) — 部屋ごとの確率 */
  treasureRate?: number;
  /** 敵スポーン配置率 (0..1) — 部屋ごとの確率 */
  enemyRate?: number;
}

export interface Room {
  x: number;
  y: number;
  w: number;
  h: number;
  type: 'normal' | 'entrance' | 'exit' | 'treasure';
}

export interface DungeonResult {
  grid: TileKind[][];
  rooms: Room[];
  startPos: [number, number];
  goalPos: [number, number];
}

// ---- 乱数 ---------------------------------------------------------------- //

function makeRng(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function randInt(rng: () => number, lo: number, hi: number): number {
  return Math.floor(rng() * (hi - lo + 1)) + lo;
}

// ---- DungeonGenerator 本体 ----------------------------------------------- //

export class DungeonGenerator {
  private readonly rng: () => number;

  constructor(public readonly config: DungeonConfig) {
    if (config.width < 8 || config.height < 8) {
      throw new Error('[DungeonGenerator] width/height は 8 以上必須');
    }
    if (config.roomCount.min > config.roomCount.max) {
      const tmp = config.roomCount.min;
      config.roomCount.min = config.roomCount.max;
      config.roomCount.max = tmp;
    }
    if (config.roomSize.min > config.roomSize.max) {
      const tmp = config.roomSize.min;
      config.roomSize.min = config.roomSize.max;
      config.roomSize.max = tmp;
    }
    this.rng = makeRng(config.seed ?? 42);
  }

  public async generate(): Promise<DungeonResult> {
    let result: DungeonResult;
    switch (this.config.algorithm) {
      case 'bsp':
        result = this.generateBsp();
        break;
      case 'random_rooms':
        result = this.generateRandomRooms();
        break;
      case 'cellular':
        result = this.generateCellular();
        break;
      case 'drunkard_walk':
        result = this.generateDrunkardWalk();
        break;
      default:
        result = this.generateRandomRooms();
    }

    // 共通ポスト処理: 宝箱/敵スポーン散布
    this.scatterFeatures(result);

    await Promise.resolve();
    return result;
  }

  // -- BSP -- //
  private generateBsp(): DungeonResult {
    const { width: W, height: H, roomCount, roomSize, corridorWidth } = this.config;
    const grid = this.emptyGrid('wall');

    // 木構造で再帰分割
    interface Leaf {
      x: number; y: number; w: number; h: number;
      left?: Leaf; right?: Leaf;
      room?: Room;
    }
    const root: Leaf = { x: 0, y: 0, w: W, h: H };

    const splitMin = Math.max(roomSize.max + 4, 12);
    const split = (leaf: Leaf): void => {
      if (leaf.w < splitMin * 2 && leaf.h < splitMin * 2) return;
      const horizontal = leaf.w < leaf.h
        ? true
        : leaf.h < leaf.w
          ? false
          : this.rng() < 0.5;
      if (horizontal && leaf.h >= splitMin * 2) {
        const cut = randInt(this.rng, splitMin, leaf.h - splitMin);
        leaf.left = { x: leaf.x, y: leaf.y, w: leaf.w, h: cut };
        leaf.right = { x: leaf.x, y: leaf.y + cut, w: leaf.w, h: leaf.h - cut };
      } else if (!horizontal && leaf.w >= splitMin * 2) {
        const cut = randInt(this.rng, splitMin, leaf.w - splitMin);
        leaf.left = { x: leaf.x, y: leaf.y, w: cut, h: leaf.h };
        leaf.right = { x: leaf.x + cut, y: leaf.y, w: leaf.w - cut, h: leaf.h };
      } else {
        return;
      }
      split(leaf.left!);
      split(leaf.right!);
    };
    split(root);

    // 葉ノードに部屋を配置
    const rooms: Room[] = [];
    const placeRoom = (leaf: Leaf): void => {
      if (leaf.left || leaf.right) {
        if (leaf.left) placeRoom(leaf.left);
        if (leaf.right) placeRoom(leaf.right);
        return;
      }
      const rw = Math.min(leaf.w - 2, randInt(this.rng, roomSize.min, roomSize.max));
      const rh = Math.min(leaf.h - 2, randInt(this.rng, roomSize.min, roomSize.max));
      if (rw < 3 || rh < 3) return;
      const rx = leaf.x + randInt(this.rng, 1, leaf.w - rw - 1);
      const ry = leaf.y + randInt(this.rng, 1, leaf.h - rh - 1);
      const room: Room = { x: rx, y: ry, w: rw, h: rh, type: 'normal' };
      leaf.room = room;
      rooms.push(room);
      this.fillRect(grid, rx, ry, rw, rh, 'floor');
    };
    placeRoom(root);

    // 兄弟ノード間で廊下接続
    const connect = (leaf: Leaf): Room | undefined => {
      if (leaf.room) return leaf.room;
      const lr = leaf.left ? connect(leaf.left) : undefined;
      const rr = leaf.right ? connect(leaf.right) : undefined;
      if (lr && rr) {
        const c1 = this.roomCenter(lr);
        const c2 = this.roomCenter(rr);
        this.carveCorridor(grid, c1, c2, corridorWidth);
      }
      return lr ?? rr;
    };
    connect(root);

    // 部屋数制限
    while (rooms.length > roomCount.max) {
      const idx = randInt(this.rng, 0, rooms.length - 1);
      const r = rooms[idx];
      this.fillRect(grid, r.x, r.y, r.w, r.h, 'wall');
      rooms.splice(idx, 1);
    }

    return this.finalize(grid, rooms);
  }

  // -- random rooms -- //
  private generateRandomRooms(): DungeonResult {
    const { width: W, height: H, roomCount, roomSize, corridorWidth } = this.config;
    const grid = this.emptyGrid('wall');
    const rooms: Room[] = [];
    const target = randInt(this.rng, roomCount.min, roomCount.max);

    let attempts = 0;
    while (rooms.length < target && attempts < target * 30) {
      attempts++;
      const w = randInt(this.rng, roomSize.min, roomSize.max);
      const h = randInt(this.rng, roomSize.min, roomSize.max);
      const x = randInt(this.rng, 1, Math.max(1, W - w - 2));
      const y = randInt(this.rng, 1, Math.max(1, H - h - 2));
      const candidate: Room = { x, y, w, h, type: 'normal' };
      const collide = rooms.some((r) => this.roomsOverlap(candidate, r, 1));
      if (collide) continue;
      rooms.push(candidate);
      this.fillRect(grid, x, y, w, h, 'floor');
    }

    // 部屋を順番に接続 (最近傍チェーン)
    for (let i = 1; i < rooms.length; i++) {
      const a = this.roomCenter(rooms[i - 1]);
      const b = this.roomCenter(rooms[i]);
      this.carveCorridor(grid, a, b, corridorWidth);
    }

    return this.finalize(grid, rooms);
  }

  // -- cellular automaton -- //
  private generateCellular(): DungeonResult {
    const { width: W, height: H } = this.config;
    let cur: number[][] = [];
    for (let y = 0; y < H; y++) {
      const row: number[] = [];
      for (let x = 0; x < W; x++) {
        // 端は壁、それ以外は 45% で壁
        if (x === 0 || y === 0 || x === W - 1 || y === H - 1) row.push(1);
        else row.push(this.rng() < 0.45 ? 1 : 0);
      }
      cur.push(row);
    }

    // 5 回反復: 隣 8 マスに壁が 5 以上なら壁、それ以外は床
    for (let iter = 0; iter < 5; iter++) {
      const next: number[][] = cur.map((r) => r.slice());
      for (let y = 1; y < H - 1; y++) {
        for (let x = 1; x < W - 1; x++) {
          let n = 0;
          for (let dy = -1; dy <= 1; dy++) {
            for (let dx = -1; dx <= 1; dx++) {
              if (dx === 0 && dy === 0) continue;
              n += cur[y + dy][x + dx];
            }
          }
          next[y][x] = n >= 5 ? 1 : 0;
        }
      }
      cur = next;
    }

    const grid = this.emptyGrid('wall');
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        grid[y][x] = cur[y][x] === 1 ? 'wall' : 'floor';
      }
    }

    // 大広間を 1 つ「部屋」として登録 (連結成分の中心)
    const rooms = this.detectFloorPockets(grid);
    return this.finalize(grid, rooms);
  }

  // -- drunkard walk -- //
  private generateDrunkardWalk(): DungeonResult {
    const { width: W, height: H } = this.config;
    const grid = this.emptyGrid('wall');
    let x = Math.floor(W / 2);
    let y = Math.floor(H / 2);
    const targetFloors = Math.floor(W * H * 0.45);
    let floors = 0;
    let steps = 0;
    const maxSteps = targetFloors * 20;
    while (floors < targetFloors && steps++ < maxSteps) {
      if (grid[y][x] !== 'floor') {
        grid[y][x] = 'floor';
        floors++;
      }
      const dir = randInt(this.rng, 0, 3);
      if (dir === 0 && x > 1) x--;
      else if (dir === 1 && x < W - 2) x++;
      else if (dir === 2 && y > 1) y--;
      else if (dir === 3 && y < H - 2) y++;
    }
    const rooms = this.detectFloorPockets(grid);
    return this.finalize(grid, rooms);
  }

  // -- 共通: 仕上げ (entrance / exit 配置) -- //
  private finalize(grid: TileKind[][], rooms: Room[]): DungeonResult {
    if (rooms.length === 0) {
      throw new Error('[DungeonGenerator] 部屋が 1 つも生成できませんでした');
    }
    // 距離最大の 2 部屋を entrance / exit に
    let best: { i: number; j: number; d: number } = { i: 0, j: 0, d: -1 };
    for (let i = 0; i < rooms.length; i++) {
      for (let j = i + 1; j < rooms.length; j++) {
        const ci = this.roomCenter(rooms[i]);
        const cj = this.roomCenter(rooms[j]);
        const d = Math.abs(ci[0] - cj[0]) + Math.abs(ci[1] - cj[1]);
        if (d > best.d) best = { i, j, d };
      }
    }
    rooms[best.i].type = 'entrance';
    rooms[best.j].type = 'exit';
    const start = this.roomCenter(rooms[best.i]);
    const goal = this.roomCenter(rooms[best.j]);
    grid[start[1]][start[0]] = 'entrance';
    grid[goal[1]][goal[0]] = 'exit';
    return {
      grid,
      rooms,
      startPos: start,
      goalPos: goal,
    };
  }

  // -- 共通: 宝箱・敵スポーン散布 -- //
  private scatterFeatures(res: DungeonResult): void {
    const tRate = this.config.treasureRate ?? 0.35;
    const eRate = this.config.enemyRate ?? 0.6;
    for (const r of res.rooms) {
      if (r.type === 'entrance' || r.type === 'exit') continue;
      if (this.rng() < tRate) {
        const tx = r.x + randInt(this.rng, 0, r.w - 1);
        const ty = r.y + randInt(this.rng, 0, r.h - 1);
        if (res.grid[ty][tx] === 'floor') res.grid[ty][tx] = 'treasure';
      }
      if (this.rng() < eRate) {
        const ex = r.x + randInt(this.rng, 0, r.w - 1);
        const ey = r.y + randInt(this.rng, 0, r.h - 1);
        if (res.grid[ey][ex] === 'floor') res.grid[ey][ex] = 'enemy_spawn';
      }
    }
  }

  // -- ヘルパ群 -- //
  private emptyGrid(fill: TileKind): TileKind[][] {
    const g: TileKind[][] = [];
    for (let y = 0; y < this.config.height; y++) {
      const r: TileKind[] = [];
      for (let x = 0; x < this.config.width; x++) r.push(fill);
      g.push(r);
    }
    return g;
  }

  private fillRect(g: TileKind[][], x: number, y: number, w: number, h: number, t: TileKind): void {
    for (let j = y; j < y + h; j++) {
      for (let i = x; i < x + w; i++) {
        if (j >= 0 && j < g.length && i >= 0 && i < g[0].length) g[j][i] = t;
      }
    }
  }

  private roomsOverlap(a: Room, b: Room, pad: number): boolean {
    return !(
      a.x + a.w + pad <= b.x ||
      b.x + b.w + pad <= a.x ||
      a.y + a.h + pad <= b.y ||
      b.y + b.h + pad <= a.y
    );
  }

  private roomCenter(r: Room): [number, number] {
    return [Math.floor(r.x + r.w / 2), Math.floor(r.y + r.h / 2)];
  }

  private carveCorridor(g: TileKind[][], a: [number, number], b: [number, number], width: number): void {
    const [ax, ay] = a;
    const [bx, by] = b;
    // L 字: 先に水平、後で垂直
    const horizFirst = this.rng() < 0.5;
    const xs = horizFirst ? ax : bx;
    const xe = horizFirst ? bx : ax;
    const ys = horizFirst ? ay : by;
    const ye = horizFirst ? by : ay;
    const minX = Math.min(xs, xe);
    const maxX = Math.max(xs, xe);
    const minY = Math.min(ys, ye);
    const maxY = Math.max(ys, ye);
    const halfW = Math.max(1, Math.floor(width / 2));
    for (let x = minX; x <= maxX; x++) {
      for (let dy = -halfW; dy <= halfW; dy++) {
        const yy = (horizFirst ? ay : by) + dy;
        if (yy >= 0 && yy < g.length && x >= 0 && x < g[0].length) {
          if (g[yy][x] === 'wall') g[yy][x] = 'floor';
        }
      }
    }
    for (let y = minY; y <= maxY; y++) {
      for (let dx = -halfW; dx <= halfW; dx++) {
        const xx = (horizFirst ? bx : ax) + dx;
        if (y >= 0 && y < g.length && xx >= 0 && xx < g[0].length) {
          if (g[y][xx] === 'wall') g[y][xx] = 'floor';
        }
      }
    }
  }

  /**
   * 連結床領域を BFS で検出し、各領域の bounding box を Room として返す。
   * (cellular / drunkard_walk 用)
   */
  private detectFloorPockets(g: TileKind[][]): Room[] {
    const H = g.length;
    const W = g[0].length;
    const seen: boolean[][] = Array.from({ length: H }, () => Array(W).fill(false));
    const rooms: Room[] = [];
    for (let y = 0; y < H; y++) {
      for (let x = 0; x < W; x++) {
        if (g[y][x] !== 'floor' || seen[y][x]) continue;
        // BFS
        const queue: Array<[number, number]> = [[x, y]];
        let minX = x, maxX = x, minY = y, maxY = y;
        let count = 0;
        while (queue.length > 0) {
          const [cx, cy] = queue.shift()!;
          if (cx < 0 || cy < 0 || cx >= W || cy >= H) continue;
          if (seen[cy][cx]) continue;
          if (g[cy][cx] !== 'floor') continue;
          seen[cy][cx] = true;
          count++;
          if (cx < minX) minX = cx;
          if (cx > maxX) maxX = cx;
          if (cy < minY) minY = cy;
          if (cy > maxY) maxY = cy;
          queue.push([cx + 1, cy], [cx - 1, cy], [cx, cy + 1], [cx, cy - 1]);
        }
        if (count >= 16) {
          rooms.push({
            x: minX,
            y: minY,
            w: maxX - minX + 1,
            h: maxY - minY + 1,
            type: 'normal',
          });
        }
      }
    }
    return rooms;
  }
}

/**
 * 便利関数: 1 呼び出しで生成。
 */
export async function generateDungeon(config: DungeonConfig): Promise<DungeonResult> {
  return new DungeonGenerator(config).generate();
}
