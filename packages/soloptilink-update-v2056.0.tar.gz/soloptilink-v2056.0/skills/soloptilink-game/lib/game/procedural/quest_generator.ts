/**
 * quest_generator.ts
 * =============================================================================
 * 責務: クエスト (任務) 自動生成
 * -----------------------------------------------------------------------------
 * 入力:
 *   - QuestTemplate: 種別 (fetch/kill/escort/explore/puzzle/survive) と難易度
 *   - world: NPC / 場所 / アイテムの語彙集合
 * 出力:
 *   - QuestResult: タイトル / 説明 / objectives[] / rewards
 *
 * 設計方針:
 *   - テンプレート × 語彙 をランダム合成 (Mad Libs スタイル)
 *   - 難易度 1..5 に応じて報酬 (exp, gold, items 数) をスケーリング
 *   - 乱数 seed 可能
 *   - 同期関数 (軽量) — 1 リクエスト = 1 クエスト
 * -----------------------------------------------------------------------------
 * SoloptiLinkAI v2034.x  /soloptilink-game v2.0
 * =============================================================================
 */

// ---- 型定義 --------------------------------------------------------------- //

export type QuestType = 'fetch' | 'kill' | 'escort' | 'explore' | 'puzzle' | 'survive';

export interface QuestTemplate {
  type: QuestType;
  difficulty: 1 | 2 | 3 | 4 | 5;
  estimatedDurationMin: number;
  /** 乱数 seed (省略時 Date.now()) */
  seed?: number;
}

export interface QuestObjective {
  id: string;
  description: string;
  type: string;
  /** 目標オブジェクトに依存する追加データ (NPC 名 / アイテム ID 等) */
  target: Record<string, unknown>;
}

export interface QuestRewards {
  exp: number;
  gold: number;
  items: string[];
}

export interface QuestResult {
  title: string;
  description: string;
  objectives: QuestObjective[];
  rewards: QuestRewards;
}

export interface WorldVocabulary {
  /** NPC 名一覧 */
  npcs: string[];
  /** 場所 (地名/ダンジョン名) 一覧 */
  locations: string[];
  /** アイテム ID 一覧 */
  items: string[];
}

// ---- 乱数 ---------------------------------------------------------------- //

function makeRng(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function pick<T>(rng: () => number, arr: T[]): T {
  if (arr.length === 0) throw new Error('[quest] pick: 配列が空です');
  return arr[Math.floor(rng() * arr.length)];
}

function pickN<T>(rng: () => number, arr: T[], n: number): T[] {
  if (arr.length === 0) return [];
  const copy = arr.slice();
  const out: T[] = [];
  for (let i = 0; i < n && copy.length > 0; i++) {
    const idx = Math.floor(rng() * copy.length);
    out.push(copy.splice(idx, 1)[0]);
  }
  return out;
}

// ---- テンプレート定義 ---------------------------------------------------- //

/**
 * クエスト種別ごとのタイトル / 説明 / objective テンプレート。
 * {{npc}} / {{location}} / {{item}} / {{count}} はプレースホルダ。
 */
interface QuestTemplateBundle {
  titles: string[];
  descriptions: string[];
  buildObjectives: (
    rng: () => number,
    w: WorldVocabulary,
    diff: number,
  ) => QuestObjective[];
}

const TEMPLATES: Record<QuestType, QuestTemplateBundle> = {
  fetch: {
    titles: [
      '{{npc}}の頼みごと',
      '失われた{{item}}',
      '{{location}}での収集任務',
      '{{npc}}に届けて',
    ],
    descriptions: [
      '{{npc}}が{{item}}を{{count}}個必要としている。{{location}}で集めて届けてほしい。',
      '{{location}}に{{item}}が落ちているという情報がある。{{count}}個持ち帰ろう。',
    ],
    buildObjectives: (rng, w, diff) => {
      const item = pick(rng, w.items);
      const npc = pick(rng, w.npcs);
      const loc = pick(rng, w.locations);
      const count = diff * 2 + Math.floor(rng() * 3);
      return [
        {
          id: 'collect',
          description: `${loc}で${item}を${count}個集める`,
          type: 'collect',
          target: { item, count, location: loc },
        },
        {
          id: 'deliver',
          description: `${npc}に${item}を届ける`,
          type: 'deliver',
          target: { item, npc },
        },
      ];
    },
  },

  kill: {
    titles: [
      '{{location}}の脅威',
      '{{npc}}の復讐',
      '害獣討伐',
      '{{location}}の魔物退治',
    ],
    descriptions: [
      '{{location}}に出没する敵を{{count}}体倒してほしい。報告は{{npc}}まで。',
      '{{npc}}が{{location}}での被害に困っている。敵を駆逐せよ。',
    ],
    buildObjectives: (rng, w, diff) => {
      const loc = pick(rng, w.locations);
      const npc = pick(rng, w.npcs);
      const count = diff * 3 + Math.floor(rng() * 3);
      return [
        {
          id: 'slay',
          description: `${loc}で敵を${count}体倒す`,
          type: 'slay',
          target: { location: loc, count, enemyTier: diff },
        },
        {
          id: 'report',
          description: `${npc}に成果を報告する`,
          type: 'talk',
          target: { npc },
        },
      ];
    },
  },

  escort: {
    titles: [
      '{{npc}}の護衛',
      '危険な道行き',
      '{{location}}までの案内',
    ],
    descriptions: [
      '{{npc}}を{{location}}まで安全に護衛してほしい。途中の敵から守ること。',
    ],
    buildObjectives: (rng, w, diff) => {
      const npc = pick(rng, w.npcs);
      const loc = pick(rng, w.locations);
      return [
        {
          id: 'escort',
          description: `${npc}を${loc}まで護衛する`,
          type: 'escort',
          target: { npc, destination: loc, dangerLevel: diff },
        },
      ];
    },
  },

  explore: {
    titles: [
      '未踏の{{location}}',
      '{{location}}の謎',
      '探索任務',
    ],
    descriptions: [
      '{{location}}には未発見の場所があるという。隅々まで踏破せよ。',
    ],
    buildObjectives: (rng, w, diff) => {
      const loc = pick(rng, w.locations);
      const checkpoints = 1 + diff;
      return [
        {
          id: 'reach',
          description: `${loc}の${checkpoints}箇所のチェックポイントを巡る`,
          type: 'reach',
          target: { location: loc, checkpoints },
        },
      ];
    },
  },

  puzzle: {
    titles: [
      '{{location}}の謎解き',
      '古き仕掛け',
      '{{npc}}の試練',
    ],
    descriptions: [
      '{{location}}に古代の仕掛けがある。解き明かしてほしい。',
    ],
    buildObjectives: (rng, w, diff) => {
      const loc = pick(rng, w.locations);
      return [
        {
          id: 'solve',
          description: `${loc}のパズルを解く`,
          type: 'solve',
          target: { location: loc, complexity: diff },
        },
      ];
    },
  },

  survive: {
    titles: [
      '{{location}}での生存',
      '波状攻撃',
      '最後まで耐えよ',
    ],
    descriptions: [
      '{{location}}で押し寄せる敵から{{count}}分間生き延びよ。',
    ],
    buildObjectives: (rng, w, diff) => {
      const loc = pick(rng, w.locations);
      const minutes = diff * 2;
      return [
        {
          id: 'survive',
          description: `${loc}で${minutes}分間生き延びる`,
          type: 'survive',
          target: { location: loc, durationMin: minutes, waves: diff },
        },
      ];
    },
  },
};

// ---- 公開関数 ------------------------------------------------------------ //

/**
 * テンプレートと世界辞書からクエストを 1 つ生成する。
 */
export function generateQuest(
  template: QuestTemplate,
  world: WorldVocabulary,
): QuestResult {
  if (!world.npcs.length || !world.locations.length || !world.items.length) {
    throw new Error('[generateQuest] world.npcs / locations / items はすべて 1 要素以上必須');
  }
  const seed = template.seed ?? Math.floor(Date.now() % 0xffffffff);
  const rng = makeRng(seed);
  const bundle = TEMPLATES[template.type];

  // 1) タイトル / 説明組み立て
  const title = renderTemplate(pick(rng, bundle.titles), rng, world, template.difficulty);
  const description = renderTemplate(
    pick(rng, bundle.descriptions),
    rng,
    world,
    template.difficulty,
  );

  // 2) 目標
  const objectives = bundle.buildObjectives(rng, world, template.difficulty);

  // 3) 報酬スケーリング (difficulty 線形 + 時間ボーナス)
  const diff = template.difficulty;
  const exp = 100 * diff + Math.floor(template.estimatedDurationMin * 5);
  const gold = 50 * diff + Math.floor(template.estimatedDurationMin * 3);
  const rewardItemCount = Math.max(1, Math.floor(diff / 2));
  const items = pickN(rng, world.items, rewardItemCount);

  return {
    title,
    description,
    objectives,
    rewards: { exp, gold, items },
  };
}

/**
 * バッチ生成: 複数のクエストを一括で作る。
 */
export function generateQuestBatch(
  templates: QuestTemplate[],
  world: WorldVocabulary,
): QuestResult[] {
  return templates.map((t) => generateQuest(t, world));
}

// ---- 内部: テンプレート展開 ---------------------------------------------- //

function renderTemplate(
  tmpl: string,
  rng: () => number,
  world: WorldVocabulary,
  diff: number,
): string {
  return tmpl
    .replace(/\{\{npc\}\}/g, () => pick(rng, world.npcs))
    .replace(/\{\{location\}\}/g, () => pick(rng, world.locations))
    .replace(/\{\{item\}\}/g, () => pick(rng, world.items))
    .replace(/\{\{count\}\}/g, () => String(diff * 2 + Math.floor(rng() * 3)));
}
