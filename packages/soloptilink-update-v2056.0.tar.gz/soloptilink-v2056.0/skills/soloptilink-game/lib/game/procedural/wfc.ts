/**
 * wfc.ts
 * =============================================================================
 * 責務: Wave Function Collapse (WFC) アルゴリズムによるタイル/ボクセル自動生成
 * -----------------------------------------------------------------------------
 * 概要:
 *   - 各セルが「取りうるタイル集合 (重ね合わせ状態)」を保持し、
 *     順次 collapse (1 つに確定) しながら隣接互換性を伝播させる。
 *   - 矛盾が発生したら backtrack して別の選択肢に切り替える。
 *
 * 入出力:
 *   入力: タイル定義 (上下左右前後それぞれに接続可能なタイル ID リスト)、
 *         グリッドサイズ (width / height / depth)。
 *   出力: 各セルに確定したタイル ID の 3 次元配列 grid[z][y][x]。
 *
 * 設計方針:
 *   - 2D の場合は depth=1 とする (3D 用 API と同一)。
 *   - エントロピー最小ヒューリスティック (Shannon でなく単純な選択肢数で OK)。
 *   - 矛盾発生時はスタックを巻き戻し別タイルで再試行。最大試行回数で abort。
 *   - 乱数は seed 可能 (Mulberry32)。
 *   - generate() は async (Promise) でラップ。
 *
 * 計算量:
 *   - 平均: O(N log N), 最悪 (backtrack 多発): O(N^2). N = グリッドセル数。
 * -----------------------------------------------------------------------------
 * SoloptiLinkAI v2034.x  /soloptilink-game v2.0
 * =============================================================================
 */

// ---- 型定義 --------------------------------------------------------------- //

/**
 * 方向 (6 方向、2D の場合は up/down/left/right のみ)。
 */
type Direction = 'up' | 'down' | 'left' | 'right' | 'forward' | 'back';

/**
 * タイル定義。weights 内の文字列配列は「その方向に隣接可能なタイル ID」。
 */
export interface WfcTile {
  /** 一意の ID */
  id: string;
  /** タイルの 2D 画像 URL (任意) */
  imageUrl?: string;
  /** タイルの 3D メッシュ URL (任意) */
  meshUrl?: string;
  /** 出現確率の重み (省略時 1.0) */
  weight?: number;
  /** 方向別の隣接互換タイル ID リスト */
  weights: {
    up: string[];
    down: string[];
    left: string[];
    right: string[];
    forward?: string[];
    back?: string[];
  };
}

/** WFC 設定 */
export interface WfcConfig {
  tiles: WfcTile[];
  width: number;
  height: number;
  /** 3D の場合のみ指定 (省略時 1 = 2D) */
  depth?: number;
  /** 乱数 seed */
  seed?: number;
  /** 最大 backtrack 回数 (default: width*height*depth) */
  maxBacktracks?: number;
  /** 最大反復回数 (default: width*height*depth*10) */
  maxIterations?: number;
}

/** WFC 実行結果 */
export interface WfcResult {
  /** [z][y][x] = タイル ID */
  grid: string[][][];
  width: number;
  height: number;
  depth: number;
  durationMs: number;
  /** 矛盾解決 (backtrack) が発生した回数 */
  contradictionResolved: number;
  /** 全セル確定できたか (false の場合は max 試行に到達) */
  success: boolean;
}

// ---- 内部ユーティリティ --------------------------------------------------- //

function makeRng(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

/**
 * 反対方向。
 */
const OPPOSITE: Record<Direction, Direction> = {
  up: 'down',
  down: 'up',
  left: 'right',
  right: 'left',
  forward: 'back',
  back: 'forward',
};

/**
 * Direction 全集合 (2D / 3D を上位で振り分け)。
 */
const DIRS_2D: Direction[] = ['up', 'down', 'left', 'right'];
const DIRS_3D: Direction[] = ['up', 'down', 'left', 'right', 'forward', 'back'];

/** 方向ごとのオフセット (dx, dy, dz) */
const OFFSET: Record<Direction, [number, number, number]> = {
  // y は上方向を +1 とする (画面下方向に行を増やす場合は呼び出し側で反転)
  up:      [0, -1, 0],
  down:    [0,  1, 0],
  left:    [-1, 0, 0],
  right:   [ 1, 0, 0],
  forward: [0,  0, 1],
  back:    [0,  0, -1],
};

// ---- WaveFunctionCollapse 本体 ------------------------------------------- //

/**
 * セルの状態 = 取りうるタイル ID 集合 (Set<string>)。
 */
type Cell = Set<string>;

/**
 * バックトラック用スナップショット。
 */
interface Snapshot {
  /** スナップ取得時点のグリッド (deep copy) */
  cells: Cell[][][];
  /** 試行したセル座標と除外済みタイル ID 群 */
  cellX: number;
  cellY: number;
  cellZ: number;
  triedTiles: Set<string>;
}

export class WaveFunctionCollapse {
  private readonly W: number;
  private readonly H: number;
  private readonly D: number;
  private readonly is3D: boolean;
  private readonly tileMap: Map<string, WfcTile>;
  private readonly tileIds: string[];
  private readonly rng: () => number;
  private readonly dirs: Direction[];

  constructor(public readonly config: WfcConfig) {
    if (config.width <= 0 || config.height <= 0) {
      throw new Error('[WFC] width/height は 1 以上必須です');
    }
    if (!config.tiles || config.tiles.length === 0) {
      throw new Error('[WFC] tiles が空です');
    }
    this.W = config.width;
    this.H = config.height;
    this.D = Math.max(1, config.depth ?? 1);
    this.is3D = this.D > 1;
    this.dirs = this.is3D ? DIRS_3D : DIRS_2D;
    this.tileMap = new Map(config.tiles.map((t) => [t.id, t]));
    this.tileIds = config.tiles.map((t) => t.id);
    this.rng = makeRng(config.seed ?? 1);
  }

  /**
   * 生成を実行する。
   */
  public async generate(): Promise<WfcResult> {
    const t0 = Date.now();
    const maxBacktracks = this.config.maxBacktracks ?? this.W * this.H * this.D;
    const maxIterations = this.config.maxIterations ?? this.W * this.H * this.D * 10;

    let cells = this.initCells();
    const stack: Snapshot[] = [];
    let contradictionResolved = 0;
    let iterations = 0;

    while (iterations++ < maxIterations) {
      // 1) 最小エントロピーセルを選択
      const target = this.pickMinEntropyCell(cells);
      if (target === null) {
        // すべて確定
        const grid = this.cellsToGrid(cells);
        return {
          grid,
          width: this.W,
          height: this.H,
          depth: this.D,
          durationMs: Date.now() - t0,
          contradictionResolved,
          success: true,
        };
      }

      const { x, y, z, cell } = target;

      if (cell.size === 0) {
        // 矛盾 → backtrack
        if (stack.length === 0 || contradictionResolved >= maxBacktracks) {
          return {
            grid: this.cellsToGrid(cells),
            width: this.W,
            height: this.H,
            depth: this.D,
            durationMs: Date.now() - t0,
            contradictionResolved,
            success: false,
          };
        }
        contradictionResolved++;
        const snap = stack[stack.length - 1];
        cells = this.deepCopyCells(snap.cells);
        // 試行済みタイルを除外して再試行
        const remaining = Array.from(cells[snap.cellZ][snap.cellY][snap.cellX])
          .filter((id) => !snap.triedTiles.has(id));
        if (remaining.length === 0) {
          // 全候補試した → さらに親をたぐる
          stack.pop();
          continue;
        }
        const pick = this.weightedPick(remaining);
        snap.triedTiles.add(pick);
        cells[snap.cellZ][snap.cellY][snap.cellX] = new Set([pick]);
        this.propagate(cells, snap.cellX, snap.cellY, snap.cellZ);
        continue;
      }

      // 2) ターゲットセルから 1 タイル選択 (重み付きランダム)
      const choices = Array.from(cell);
      const pick = this.weightedPick(choices);
      const snap: Snapshot = {
        cells: this.deepCopyCells(cells),
        cellX: x,
        cellY: y,
        cellZ: z,
        triedTiles: new Set([pick]),
      };
      stack.push(snap);
      cells[z][y][x] = new Set([pick]);

      // 3) 互換性を伝播
      this.propagate(cells, x, y, z);
    }

    // 最大反復に到達
    return {
      grid: this.cellsToGrid(cells),
      width: this.W,
      height: this.H,
      depth: this.D,
      durationMs: Date.now() - t0,
      contradictionResolved,
      success: false,
    };
  }

  // -- 初期化 -- //
  private initCells(): Cell[][][] {
    const all = new Set(this.tileIds);
    const out: Cell[][][] = [];
    for (let z = 0; z < this.D; z++) {
      const plane: Cell[][] = [];
      for (let y = 0; y < this.H; y++) {
        const row: Cell[] = [];
        for (let x = 0; x < this.W; x++) {
          row.push(new Set(all));
        }
        plane.push(row);
      }
      out.push(plane);
    }
    return out;
  }

  // -- 深い複製 -- //
  private deepCopyCells(src: Cell[][][]): Cell[][][] {
    return src.map((plane) => plane.map((row) => row.map((c) => new Set(c))));
  }

  // -- 最小エントロピーセル選択 -- //
  private pickMinEntropyCell(
    cells: Cell[][][],
  ): { x: number; y: number; z: number; cell: Cell } | null {
    let best: { x: number; y: number; z: number; cell: Cell } | null = null;
    let bestSize = Infinity;
    for (let z = 0; z < this.D; z++) {
      for (let y = 0; y < this.H; y++) {
        for (let x = 0; x < this.W; x++) {
          const c = cells[z][y][x];
          if (c.size <= 1) continue; // 既に確定
          if (c.size < bestSize) {
            bestSize = c.size;
            best = { x, y, z, cell: c };
          }
        }
      }
    }
    if (best === null) {
      // 未確定セルなし → 矛盾セル (size=0) があれば返す
      for (let z = 0; z < this.D; z++) {
        for (let y = 0; y < this.H; y++) {
          for (let x = 0; x < this.W; x++) {
            if (cells[z][y][x].size === 0) {
              return { x, y, z, cell: cells[z][y][x] };
            }
          }
        }
      }
    }
    return best;
  }

  // -- 重み付きランダム選択 -- //
  private weightedPick(ids: string[]): string {
    let total = 0;
    const weights = ids.map((id) => {
      const w = this.tileMap.get(id)?.weight ?? 1.0;
      total += w;
      return w;
    });
    let r = this.rng() * total;
    for (let i = 0; i < ids.length; i++) {
      r -= weights[i];
      if (r <= 0) return ids[i];
    }
    return ids[ids.length - 1];
  }

  // -- 制約伝播 (queue ベース) -- //
  private propagate(cells: Cell[][][], sx: number, sy: number, sz: number): void {
    const queue: Array<[number, number, number]> = [[sx, sy, sz]];
    while (queue.length > 0) {
      const [cx, cy, cz] = queue.shift()!;
      const cur = cells[cz][cy][cx];
      for (const d of this.dirs) {
        const [dx, dy, dz] = OFFSET[d];
        const nx = cx + dx;
        const ny = cy + dy;
        const nz = cz + dz;
        if (nx < 0 || nx >= this.W) continue;
        if (ny < 0 || ny >= this.H) continue;
        if (nz < 0 || nz >= this.D) continue;
        const neigh = cells[nz][ny][nx];
        if (neigh.size <= 1) {
          // 確定済 or 矛盾。size==0 はそのままにして上位 pick で検出させる
          if (neigh.size === 1) continue;
        }
        // cur 内の全タイルから「d 方向で許可されるタイル ID 集合」を構築
        const allowed = new Set<string>();
        for (const id of cur) {
          const tile = this.tileMap.get(id)!;
          const list = (tile.weights[d as keyof typeof tile.weights] ?? []) as string[];
          for (const a of list) allowed.add(a);
        }
        // neigh と allowed の積を取って更新
        let changed = false;
        for (const id of Array.from(neigh)) {
          if (!allowed.has(id)) {
            neigh.delete(id);
            changed = true;
          }
        }
        if (changed) queue.push([nx, ny, nz]);
      }
    }
  }

  // -- 出力グリッドに整形 -- //
  private cellsToGrid(cells: Cell[][][]): string[][][] {
    const grid: string[][][] = [];
    for (let z = 0; z < this.D; z++) {
      const plane: string[][] = [];
      for (let y = 0; y < this.H; y++) {
        const row: string[] = [];
        for (let x = 0; x < this.W; x++) {
          const c = cells[z][y][x];
          if (c.size === 1) {
            row.push(Array.from(c)[0]);
          } else if (c.size === 0) {
            row.push(''); // 矛盾セル
          } else {
            row.push('?'); // 未確定 (max iter 到達)
          }
        }
        plane.push(row);
      }
      grid.push(plane);
    }
    return grid;
  }
}

/**
 * 便利関数: インスタンスを作って generate() を呼ぶショートカット。
 */
export async function runWfc(config: WfcConfig): Promise<WfcResult> {
  return new WaveFunctionCollapse(config).generate();
}
