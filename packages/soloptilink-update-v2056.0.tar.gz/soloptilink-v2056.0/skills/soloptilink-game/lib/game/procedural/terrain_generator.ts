/**
 * terrain_generator.ts
 * =============================================================================
 * 責務: 地形 (オープンワールド) の高さマップ / バイオームマップ自動生成
 * -----------------------------------------------------------------------------
 * サポートノイズ:
 *   1. 'perlin'  — Perlin Noise (Ken Perlin, 1985)
 *   2. 'simplex' — Simplex Noise (Ken Perlin, 2001) — 軽量近似実装
 *   3. 'fractal' — フラクタル合成 (オクターブ FBM)
 *   4. 'worley'  — Worley/Cellular Noise (Steven Worley, 1996)
 *
 * 機能:
 *   - 河川生成 (高所→低所への勾配ベース流路)
 *   - 山岳 / 渓谷の強調
 *   - バイオーム判定 (高度 + 緯度 + 湿度の 3 軸近似)
 *   - 簡易ナビメッシュ (傾斜閾値で歩行可能セル集合)
 *
 * 設計方針:
 *   - 乱数 seed で完全再現可能
 *   - generate() は async (Promise)
 *   - メッシュ GLTF 出力は URL ベース (実バイナリは別パイプライン)
 * -----------------------------------------------------------------------------
 * SoloptiLinkAI v2034.x  /soloptilink-game v2.0
 * =============================================================================
 */

// ---- 型定義 --------------------------------------------------------------- //

export type NoiseType = 'perlin' | 'simplex' | 'fractal' | 'worley';

export type Biome = 'grass' | 'desert' | 'snow' | 'tundra' | 'ocean' | 'forest';

export interface TerrainFeatures {
  rivers: boolean;
  mountains: boolean;
  valleys: boolean;
  /** バイオームの種類数 (1..6) */
  biomes: number;
}

export interface TerrainConfig {
  /** ワールド幅 (m) */
  width: number;
  /** ワールド奥行 (m) */
  depth: number;
  /** メッシュ密度 (cell/m が低いほど粗、高いほど精細) */
  resolution: number;
  /** 高さスケール (m) */
  heightScale: number;
  noiseType: NoiseType;
  seed?: number;
  features?: TerrainFeatures;
}

export interface NavMesh {
  walkable: boolean[][];
  slopeMap: number[][];
}

export interface TerrainResult {
  heightmap: number[][];
  biomemap?: Biome[][];
  meshGltfUrl?: string;
  navMesh?: NavMesh;
  width: number;
  depth: number;
}

// ---- 乱数 ---------------------------------------------------------------- //

function makeRng(seed: number): () => number {
  let s = seed >>> 0;
  return () => {
    s = (s + 0x6d2b79f5) >>> 0;
    let t = s;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

// ---- ノイズ生成器 (シンプル実装) ----------------------------------------- //

/**
 * Perlin noise の 2D 実装 (古典的 grid hash + 補間)。
 * - 256 entry の置換テーブルを seed で生成
 * - 各 lattice 点の勾配は 4 方向単位ベクトルからランダム選択
 */
class PerlinNoise2D {
  private readonly perm: number[];

  constructor(seed: number) {
    const rng = makeRng(seed);
    const p = Array.from({ length: 256 }, (_, i) => i);
    // Fisher-Yates shuffle (seeded)
    for (let i = 255; i > 0; i--) {
      const j = Math.floor(rng() * (i + 1));
      [p[i], p[j]] = [p[j], p[i]];
    }
    this.perm = [...p, ...p];
  }

  private fade(t: number): number {
    return t * t * t * (t * (t * 6 - 15) + 10);
  }

  private lerp(a: number, b: number, t: number): number {
    return a + t * (b - a);
  }

  private grad(hash: number, x: number, y: number): number {
    const h = hash & 7;
    const u = h < 4 ? x : y;
    const v = h < 4 ? y : x;
    return ((h & 1) ? -u : u) + ((h & 2) ? -2 * v : 2 * v);
  }

  /** noise2(x, y) ∈ おおむね [-1, 1] */
  public noise2(x: number, y: number): number {
    const X = Math.floor(x) & 255;
    const Y = Math.floor(y) & 255;
    const xf = x - Math.floor(x);
    const yf = y - Math.floor(y);
    const u = this.fade(xf);
    const v = this.fade(yf);
    const aa = this.perm[this.perm[X] + Y];
    const ab = this.perm[this.perm[X] + Y + 1];
    const ba = this.perm[this.perm[X + 1] + Y];
    const bb = this.perm[this.perm[X + 1] + Y + 1];
    return this.lerp(
      this.lerp(this.grad(aa, xf, yf),       this.grad(ba, xf - 1, yf),       u),
      this.lerp(this.grad(ab, xf, yf - 1),   this.grad(bb, xf - 1, yf - 1),   u),
      v,
    );
  }
}

/**
 * Simplex 風の軽量実装。Perlin ベースで 30 度回転を加えた近似。
 * (完全な Simplex 実装ではないが、Perlin より方向偏向が少ない結果が得られる)
 */
class SimplexLikeNoise2D {
  private readonly p: PerlinNoise2D;
  constructor(seed: number) { this.p = new PerlinNoise2D(seed ^ 0x9e3779b9); }
  public noise2(x: number, y: number): number {
    const c = Math.cos(Math.PI / 6);
    const s = Math.sin(Math.PI / 6);
    return this.p.noise2(x * c - y * s, x * s + y * c);
  }
}

/**
 * フラクタル合成 (FBM): N オクターブの Perlin を周波数倍 / 振幅半 で重ねる。
 */
class FractalNoise2D {
  private readonly p: PerlinNoise2D;
  constructor(seed: number, private readonly octaves: number = 5) {
    this.p = new PerlinNoise2D(seed ^ 0xb5297a4d);
  }
  public noise2(x: number, y: number): number {
    let total = 0;
    let amp = 1;
    let freq = 1;
    let max = 0;
    for (let i = 0; i < this.octaves; i++) {
      total += this.p.noise2(x * freq, y * freq) * amp;
      max += amp;
      amp *= 0.5;
      freq *= 2;
    }
    return total / max;
  }
}

/**
 * Worley/Cellular noise — 最近傍特徴点までの距離。
 */
class WorleyNoise2D {
  private readonly points: Array<[number, number]>;
  constructor(seed: number, count: number = 64) {
    const rng = makeRng(seed ^ 0x68e31da4);
    this.points = Array.from({ length: count }, () => [rng() * 256, rng() * 256] as [number, number]);
  }
  public noise2(x: number, y: number): number {
    // 0..256 範囲にラップ
    const wx = ((x % 256) + 256) % 256;
    const wy = ((y % 256) + 256) % 256;
    let best = Infinity;
    for (const [px, py] of this.points) {
      const dx = wx - px;
      const dy = wy - py;
      const d = dx * dx + dy * dy;
      if (d < best) best = d;
    }
    // 適度にスケーリングして [-1, 1] に近づける
    return 1 - Math.min(1, Math.sqrt(best) / 64);
  }
}

interface NoiseFn { noise2(x: number, y: number): number }

function buildNoise(type: NoiseType, seed: number): NoiseFn {
  switch (type) {
    case 'perlin':  return new PerlinNoise2D(seed);
    case 'simplex': return new SimplexLikeNoise2D(seed);
    case 'fractal': return new FractalNoise2D(seed);
    case 'worley':  return new WorleyNoise2D(seed);
  }
}

// ---- TerrainGenerator 本体 ----------------------------------------------- //

export class TerrainGenerator {
  private readonly rng: () => number;

  constructor(public readonly config: TerrainConfig) {
    if (config.width <= 0 || config.depth <= 0 || config.resolution <= 0) {
      throw new Error('[TerrainGenerator] width/depth/resolution は正の値必須');
    }
    this.rng = makeRng(config.seed ?? 7);
  }

  public async generate(): Promise<TerrainResult> {
    const seed = this.config.seed ?? 7;
    const noise = buildNoise(this.config.noiseType, seed);

    const cellsX = Math.max(2, Math.floor(this.config.width * this.config.resolution));
    const cellsY = Math.max(2, Math.floor(this.config.depth * this.config.resolution));

    // 1) 高さマップ生成
    const heightmap: number[][] = [];
    for (let y = 0; y < cellsY; y++) {
      const row: number[] = [];
      for (let x = 0; x < cellsX; x++) {
        // 8x8 セル単位の周波数 (ワールド規模に応じて自動調整)
        const nx = (x / cellsX) * 8;
        const ny = (y / cellsY) * 8;
        let h = (noise.noise2(nx, ny) + 1) * 0.5; // 0..1
        // mountains / valleys 強調
        if (this.config.features?.mountains) h = Math.pow(h, 0.7);
        if (this.config.features?.valleys) h = Math.pow(h, 1.5);
        row.push(h * this.config.heightScale);
      }
      heightmap.push(row);
    }

    // 2) 河川 (水路) 生成
    if (this.config.features?.rivers) {
      this.carveRivers(heightmap);
    }

    // 3) バイオームマップ
    let biomemap: Biome[][] | undefined;
    if ((this.config.features?.biomes ?? 0) > 0) {
      biomemap = this.assignBiomes(heightmap);
    }

    // 4) ナビメッシュ (傾斜閾値 30 deg = tan 0.577 で歩行可能)
    const navMesh = this.buildNavMesh(heightmap);

    // 5) メッシュ URL (実エクスポートは別パイプラインに渡す前提のスタブ)
    const meshGltfUrl = `terrain://soloptilink/${this.config.noiseType}_${seed}_${cellsX}x${cellsY}.gltf`;

    await Promise.resolve();
    return {
      heightmap,
      biomemap,
      navMesh,
      meshGltfUrl,
      width: this.config.width,
      depth: this.config.depth,
    };
  }

  // -- 河川生成: 高所からの勾配下降をたどる -- //
  private carveRivers(hm: number[][]): void {
    const H = hm.length;
    const W = hm[0].length;
    const startCount = Math.max(2, Math.floor(W * H * 0.001));
    const rng = this.rng;
    for (let i = 0; i < startCount; i++) {
      let x = Math.floor(rng() * W);
      let y = Math.floor(rng() * H);
      // 高所 (上位 25%) から start
      if (hm[y][x] < this.config.heightScale * 0.6) continue;
      let safety = 0;
      while (safety++ < W + H) {
        hm[y][x] = Math.max(0, hm[y][x] - this.config.heightScale * 0.15);
        // 隣 8 マスから最低を選択
        let bestX = x, bestY = y, bestH = hm[y][x];
        for (let dy = -1; dy <= 1; dy++) {
          for (let dx = -1; dx <= 1; dx++) {
            const nx = x + dx;
            const ny = y + dy;
            if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
            if (hm[ny][nx] < bestH) {
              bestH = hm[ny][nx];
              bestX = nx;
              bestY = ny;
            }
          }
        }
        if (bestX === x && bestY === y) break;
        x = bestX;
        y = bestY;
        if (hm[y][x] < this.config.heightScale * 0.05) break; // 海到達
      }
    }
  }

  // -- バイオーム判定 -- //
  private assignBiomes(hm: number[][]): Biome[][] {
    const H = hm.length;
    const W = hm[0].length;
    const out: Biome[][] = [];
    const noiseHumid = buildNoise('fractal', (this.config.seed ?? 7) ^ 0xdeadbeef);
    const desiredCount = Math.min(6, Math.max(1, this.config.features?.biomes ?? 4));
    for (let y = 0; y < H; y++) {
      const row: Biome[] = [];
      for (let x = 0; x < W; x++) {
        const h = hm[y][x] / this.config.heightScale; // 0..1
        const lat = y / H; // 0..1 (擬似緯度)
        const humid = (noiseHumid.noise2(x / W * 4, y / H * 4) + 1) * 0.5;
        row.push(this.pickBiome(h, lat, humid, desiredCount));
      }
      out.push(row);
    }
    return out;
  }

  private pickBiome(h: number, lat: number, humid: number, k: number): Biome {
    // 海 (高さ ~ 0)
    if (h < 0.1) return 'ocean';
    // 極地 (緯度高 + 高度高)
    if (lat > 0.85 || h > 0.85) return k >= 3 ? 'snow' : 'grass';
    // 寒冷地
    if (lat > 0.7) return k >= 4 ? 'tundra' : 'grass';
    // 乾燥地
    if (humid < 0.3 && h < 0.5) return k >= 2 ? 'desert' : 'grass';
    // 森林 (湿度高)
    if (humid > 0.65) return k >= 5 ? 'forest' : 'grass';
    return 'grass';
  }

  // -- ナビメッシュ -- //
  private buildNavMesh(hm: number[][]): NavMesh {
    const H = hm.length;
    const W = hm[0].length;
    const walkable: boolean[][] = [];
    const slopeMap: number[][] = [];
    const cellSize = 1 / this.config.resolution; // m
    const slopeLimit = Math.tan((30 * Math.PI) / 180); // tan 30deg
    for (let y = 0; y < H; y++) {
      const wrow: boolean[] = [];
      const srow: number[] = [];
      for (let x = 0; x < W; x++) {
        let maxSlope = 0;
        for (let dy = -1; dy <= 1; dy++) {
          for (let dx = -1; dx <= 1; dx++) {
            const nx = x + dx;
            const ny = y + dy;
            if (nx < 0 || ny < 0 || nx >= W || ny >= H) continue;
            const dh = Math.abs(hm[ny][nx] - hm[y][x]);
            const dist = cellSize * Math.hypot(dx, dy);
            const slope = dist > 0 ? dh / dist : 0;
            if (slope > maxSlope) maxSlope = slope;
          }
        }
        srow.push(maxSlope);
        wrow.push(maxSlope <= slopeLimit && hm[y][x] > 0.05 * this.config.heightScale);
      }
      walkable.push(wrow);
      slopeMap.push(srow);
    }
    return { walkable, slopeMap };
  }
}

/**
 * 便利関数: 1 呼び出しで地形生成。
 */
export async function generateTerrain(config: TerrainConfig): Promise<TerrainResult> {
  return new TerrainGenerator(config).generate();
}
