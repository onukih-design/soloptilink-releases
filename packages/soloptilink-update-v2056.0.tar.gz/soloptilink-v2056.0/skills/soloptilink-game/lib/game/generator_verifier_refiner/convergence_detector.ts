/**
 * convergence_detector.ts
 * 責務: GVR ループの収束判定。イテレーション履歴を見て、
 *   (a) 改善幅が閾値未満で連続2回以上停滞 → 収束
 *   (b) 急激な悪化 (regression) → ロールバック推奨
 *   (c) いずれでもなければ継続
 *   を判定し、次に取るべきアクション (continue/rollback/stop/change_strategy) を返す。
 *   判定根拠を日本語の reason として返すため、レポート生成にそのまま流用可能。
 *   ダミー値ではなく履歴の数値変化のみから判定する。
 *   純粋関数的なクラスなので Node.js / ブラウザ両環境で動作。
 */

import type { GvrIteration } from './orchestrator';

// ========================================
// 型定義
// ========================================

/** 収束判定基準 */
export interface ConvergenceCriteria {
  /** 1イテレーション当たりの最小改善幅 (例: 1.5 = +1.5点未満なら停滞扱い) */
  scoreImprovementThreshold: number;
  /** 停滞と判断するまでの連続イテレーション数 (例: 2) */
  stableIterationsRequired: number;
  /** 許容する最大悪化幅 (負値, 例: -3 = 3点以上悪化したらロールバック) */
  maxRegressionAllowed: number;
  /** スコア天井 (例: 100点満点なら100, 省略時100) */
  scoreCeiling?: number;
}

/** 収束判定結果 */
export interface ConvergenceResult {
  /** 収束した (= ループを止めるべき) か */
  converged: boolean;
  /** 判定理由 (日本語) */
  reason: string;
  /** 直前イテレーションを巻き戻すべきか */
  shouldRollback: boolean;
  /** 次に取るべきアクション */
  suggestedNextAction: 'continue' | 'rollback' | 'stop' | 'change_strategy';
  /** 直近イテレーションの改善幅 (参考値) */
  lastDelta?: number;
  /** 直近 N 件の平均改善幅 */
  recentMeanDelta?: number;
}

// ========================================
// ConvergenceDetector 本体
// ========================================

/**
 * 収束判定器。状態を持たないシングルトン的に使える純粋関数群を内包。
 */
export class ConvergenceDetector {
  /**
   * 履歴を評価して収束結果を返す。
   * history は時系列順 (古い→新しい)。空 or 1件のみなら継続。
   */
  evaluate(history: GvrIteration[], criteria: ConvergenceCriteria): ConvergenceResult {
    const ceiling = criteria.scoreCeiling ?? 100;

    // ---- 1. 早期終了パターン: 履歴不十分 ----
    if (history.length === 0) {
      return {
        converged: false,
        reason: '履歴が空のためまだ判定できません。継続。',
        shouldRollback: false,
        suggestedNextAction: 'continue',
      };
    }
    if (history.length === 1) {
      return {
        converged: false,
        reason: 'イテレーション1回目 — 改善幅を測定するため最低2回必要。継続。',
        shouldRollback: false,
        suggestedNextAction: 'continue',
        lastDelta: undefined,
      };
    }

    // ---- 2. 直近の差分 ----
    const last = history[history.length - 1];
    const prev = history[history.length - 2];
    const lastDelta = last.qualityScore - prev.qualityScore;

    // ---- 3. 急激な悪化 (regression) 判定 ----
    if (lastDelta <= criteria.maxRegressionAllowed) {
      return {
        converged: false,
        reason: `直近イテレーションで ${lastDelta.toFixed(2)} 点悪化 (許容: ${criteria.maxRegressionAllowed} 点)。ロールバック推奨。`,
        shouldRollback: true,
        suggestedNextAction: 'rollback',
        lastDelta,
      };
    }

    // ---- 4. 天井到達 ----
    if (last.qualityScore >= ceiling) {
      return {
        converged: true,
        reason: `スコア天井 ${ceiling} に到達 (${last.qualityScore.toFixed(2)})。十分に収束。`,
        shouldRollback: false,
        suggestedNextAction: 'stop',
        lastDelta,
      };
    }

    // ---- 5. 改善停滞 判定 ----
    const need = Math.max(1, criteria.stableIterationsRequired);
    if (history.length >= need + 1) {
      // 直近 need 件すべてが threshold 未満なら収束
      const recent = history.slice(-need);
      const recentDeltas: number[] = [];
      for (let i = 0; i < recent.length; i++) {
        const baseIdx = history.length - need + i - 1;
        if (baseIdx < 0) continue;
        const baseScore = history[baseIdx].qualityScore;
        const cur = recent[i].qualityScore;
        recentDeltas.push(cur - baseScore);
      }
      const allBelow = recentDeltas.every((d) => d < criteria.scoreImprovementThreshold);
      const recentMeanDelta =
        recentDeltas.length > 0
          ? recentDeltas.reduce((s, v) => s + v, 0) / recentDeltas.length
          : 0;
      if (allBelow && recentDeltas.length === need) {
        return {
          converged: true,
          reason: `連続 ${need} 回の改善幅がいずれも閾値 ${criteria.scoreImprovementThreshold} 点未満 (平均 ${recentMeanDelta.toFixed(2)} 点)。収束と判定。`,
          shouldRollback: false,
          suggestedNextAction: 'stop',
          lastDelta,
          recentMeanDelta,
        };
      }
    }

    // ---- 6. 同点 or 微改善のみ続いている場合の戦略変更ヒント ----
    if (
      history.length >= 5 &&
      Math.abs(lastDelta) < 0.5 &&
      history.slice(-5).every((it, i, arr) => {
        if (i === 0) return true;
        return Math.abs(it.qualityScore - arr[i - 1].qualityScore) < 0.5;
      })
    ) {
      return {
        converged: false,
        reason:
          '5回連続でスコアがほぼ変動なし。同じ戦略では限界の可能性。戦略変更(別カテゴリの軸を狙う/別LLMプロバイダ等)を推奨。',
        shouldRollback: false,
        suggestedNextAction: 'change_strategy',
        lastDelta,
      };
    }

    // ---- 7. それ以外: 継続 ----
    return {
      converged: false,
      reason: `直近イテレーション改善幅 ${lastDelta.toFixed(2)} 点 — まだ収束基準に到達せず。継続。`,
      shouldRollback: false,
      suggestedNextAction: 'continue',
      lastDelta,
    };
  }

  /**
   * 履歴に対する単純な統計サマリを返す (レポート用)。
   * 純粋関数。
   */
  summarize(history: GvrIteration[]): {
    count: number;
    minScore: number;
    maxScore: number;
    meanScore: number;
    totalGain: number;
    bestIteration: number;
  } {
    if (history.length === 0) {
      return { count: 0, minScore: 0, maxScore: 0, meanScore: 0, totalGain: 0, bestIteration: 0 };
    }
    const scores = history.map((h) => h.qualityScore);
    const minScore = Math.min(...scores);
    const maxScore = Math.max(...scores);
    const meanScore = scores.reduce((s, v) => s + v, 0) / scores.length;
    const totalGain = scores[scores.length - 1] - scores[0];
    const bestIteration = history.findIndex((h) => h.qualityScore === maxScore) + 1;
    return {
      count: history.length,
      minScore,
      maxScore,
      meanScore,
      totalGain,
      bestIteration,
    };
  }
}

// ========================================
// 単発呼び出し用ヘルパ
// ========================================

/** ワンライナーで使うための便利関数 */
export function evaluateConvergence(
  history: GvrIteration[],
  criteria: ConvergenceCriteria,
): ConvergenceResult {
  return new ConvergenceDetector().evaluate(history, criteria);
}
