/**
 * verifier.ts
 * 責務: Game Quality Fortress 10軸を用いて現在のゲーム品質を計測し、
 *   各軸の目標との差分から日本語の改善要望 (ImprovementRequest) を生成する。
 *   AutoPlaytestSession (実プレイ結果) or 静的メトリクス JSON のどちらからでも
 *   採点できるよう抽象化。severity 判定は -30以上不足=critical、-15=high、
 *   -5=medium、それ以下=low の閾値ベース。
 *   ダミー値ではなく実メトリクスを優先し、欠落時のみ妥当なフォールバック値で補完。
 *   Node.js 環境で動作。すべての非同期処理は try-catch で堅牢化。
 */

import { promises as fs } from 'node:fs';
import * as path from 'node:path';

import {
  scoreGame,
  type GameMetrics,
  type GameQualityScore,
  type AxisScore,
} from '../quality/game_fortress';
import type { AutoPlaytestSession } from './auto_playtest';
import type {
  ImprovementRequest,
  ImprovementCategory,
  ImprovementSeverity,
} from './orchestrator';

// ========================================
// 型定義
// ========================================

/** Verifier の設定 */
export interface VerifierConfig {
  /** 対象プロジェクトディレクトリ */
  projectDir: string;
  /** AutoPlaytester の出力結果 (あれば実メトリクス優先) */
  playtest?: AutoPlaytestSession;
  /** 静的メトリクス JSON ファイルへのパス (任意, 補完用) */
  metricsPath?: string;
  /** 各軸の目標スコア (省略時は全軸 9.0) */
  axisTargets?: Partial<Record<ImprovementCategory, number>>;
}

/** Verifier の出力 */
export interface VerifierResult {
  /** 合計スコア (0-100) */
  totalScore: number;
  /** 認定ランク */
  rank: 'Reject' | 'Bronze' | 'Silver' | 'Gold' | 'Platinum';
  /** 各軸のスコア (0-10) */
  axisScores: Record<string, number>;
  /** 生成された全改善要望 */
  improvementRequests: ImprovementRequest[];
  /** severity 優先順に並べた改善要望 */
  prioritized: ImprovementRequest[];
  /** 採点詳細 (game_fortress の出力をそのまま保持) */
  rawFortress: GameQualityScore;
  /** 採点に使った GameMetrics (デバッグ用) */
  rawMetrics: GameMetrics;
}

// ========================================
// Verifier 本体
// ========================================

/**
 * 品質計測+改善要望生成器。
 * `measure()` だけが公開API。
 */
export class Verifier {
  /**
   * 品質を計測して結果を返す。
   * 失敗してもスコア0で返し、例外を上に投げない。
   */
  async measure(config: VerifierConfig): Promise<VerifierResult> {
    // ---- 1. プレイテスト結果 or 静的JSON からメトリクスを構築 ----
    const metrics: GameMetrics = await this.buildMetrics(config);

    // ---- 2. game_fortress.ts で採点 ----
    const fortress: GameQualityScore = scoreGame(metrics);

    // ---- 3. 軸名マップ (game_fortress → ImprovementCategory) ----
    const axisToCategory: Record<string, ImprovementCategory> = {
      fps_stability: 'fps',
      input_latency: 'input_latency',
      load_time: 'load_time',
      game_balance: 'balance',
      replayability: 'replayability',
      onboarding: 'onboarding',
      av_consistency: 'av_consistency',
      ui_ux: 'ui_ux',
      accessibility: 'accessibility',
      fun_score: 'fun',
    };

    // ---- 4. 各軸ごとに ImprovementRequest を生成 ----
    const axisTargets = config.axisTargets ?? {};
    const requests: ImprovementRequest[] = [];
    const axisScoreSummary: Record<string, number> = {};

    for (const [axisKey, axisScore] of Object.entries(fortress.axes) as [string, AxisScore][]) {
      axisScoreSummary[axisKey] = axisScore.score;
      const category = axisToCategory[axisKey];
      if (!category) continue;

      // 軸の目標値 (10点満点中)
      const target = axisTargets[category] ?? 9.0;
      const diff = target - axisScore.score;
      // 既に目標達成なら改善要望不要
      if (diff <= 0) continue;

      // severity 判定: 10点満点ベースの差分 × 10 で換算
      // -30以上(=3.0以上)=critical / -15(=1.5)=high / -5(=0.5)=medium
      const diff100 = diff * 10;
      let severity: ImprovementSeverity;
      if (diff100 >= 30) severity = 'critical';
      else if (diff100 >= 15) severity = 'high';
      else if (diff100 >= 5) severity = 'medium';
      else severity = 'low';

      const { description, suggestedFix, affectedFiles } = this.buildImprovementDetails(
        category,
        axisScore,
        config.projectDir,
      );

      requests.push({
        category,
        severity,
        currentScore: Number(axisScore.score.toFixed(2)),
        targetScore: target,
        description,
        suggestedFix,
        affectedFiles,
      });
    }

    // ---- 5. severity 優先順にソート (critical → high → medium → low) ----
    const severityRank: Record<ImprovementSeverity, number> = {
      critical: 0,
      high: 1,
      medium: 2,
      low: 3,
    };
    const prioritized = [...requests].sort((a, b) => {
      const r = severityRank[a.severity] - severityRank[b.severity];
      if (r !== 0) return r;
      // 同 severity 内ではスコア差(=target-current)が大きい方を優先
      return (b.targetScore - b.currentScore) - (a.targetScore - a.currentScore);
    });

    return {
      totalScore: fortress.total,
      rank: fortress.rank,
      axisScores: axisScoreSummary,
      improvementRequests: requests,
      prioritized,
      rawFortress: fortress,
      rawMetrics: metrics,
    };
  }

  // ========================================
  // 内部: メトリクス構築
  // ========================================

  /**
   * プレイテスト結果と静的JSONから GameMetrics を組み立てる。
   * プレイテストが優先、欠落分のみ妥当なフォールバック値で補完。
   */
  private async buildMetrics(config: VerifierConfig): Promise<GameMetrics> {
    // 静的メトリクスJSON を任意で読み込み
    let staticMetrics: Partial<GameMetrics> = {};
    if (config.metricsPath) {
      try {
        const raw = await fs.readFile(config.metricsPath, 'utf8');
        const parsed = JSON.parse(raw) as Partial<GameMetrics>;
        staticMetrics = parsed;
      } catch {
        // 読み込み失敗は無視 (フォールバック値で補う)
      }
    }

    // プレイテスト結果から実メトリクスを抽出
    const playtest = config.playtest;
    const fpsHistory = playtest?.metrics.fpsHistory ?? staticMetrics.fpsHistory ?? [];
    const latencyHistory =
      playtest?.metrics.inputLatencyMs ?? staticMetrics.inputLatencyHistory ?? [];
    const loadTimeMs = staticMetrics.loadTimeMs ?? 3000; // 不明時は仮値3秒
    const difficultyCurve = staticMetrics.difficultyCurve ?? this.inferDifficultyCurve(playtest);

    // プロジェクト内ファイルから推定できるフラグ
    const featureFlags = await this.detectFeatureFlags(config.projectDir);

    // プレイテストからの FUN スコア推定 (継続時間/プログレス/イベント数で簡易計算)
    const playtestFun = this.estimateFunFromPlaytest(playtest);

    const metrics: GameMetrics = {
      fpsHistory,
      inputLatencyHistory: latencyHistory,
      loadTimeMs,
      hasTutorial: staticMetrics.hasTutorial ?? featureFlags.hasTutorial,
      hasSettings: staticMetrics.hasSettings ?? featureFlags.hasSettings,
      hasAccessibilityOptions:
        staticMetrics.hasAccessibilityOptions ?? featureFlags.hasAccessibilityOptions,
      hasSaveLoad: staticMetrics.hasSaveLoad ?? featureFlags.hasSaveLoad,
      hasReplayability: staticMetrics.hasReplayability ?? featureFlags.hasReplayability,
      difficultyCurve,
      audioVisualConsistency:
        staticMetrics.audioVisualConsistency ?? featureFlags.audioVisualConsistency,
      uiUxScore: staticMetrics.uiUxScore ?? 6, // 不明時は中央値
      funScore: staticMetrics.funScore ?? playtestFun,
      tutorialDurationMin: staticMetrics.tutorialDurationMin,
      firstFunMomentMin: staticMetrics.firstFunMomentMin,
      replayFeatures: staticMetrics.replayFeatures,
      uiUxDetails: staticMetrics.uiUxDetails,
      accessibilityDetails: staticMetrics.accessibilityDetails,
    };
    return metrics;
  }

  /** プレイテスト履歴から擬似的な難易度カーブを推定 */
  private inferDifficultyCurve(playtest?: AutoPlaytestSession): number[] {
    if (!playtest || !playtest.events || playtest.events.length === 0) {
      // フォールバック: 緩やかな単調増加
      return [1, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0];
    }
    // events 中の death/clear イベントの密度から難易度を推測
    const buckets = 7;
    const duration = playtest.duration || 1;
    const bucketSize = duration / buckets;
    const counts = new Array(buckets).fill(0);
    for (const ev of playtest.events) {
      if (!['death', 'gameover', 'fail', 'stage_clear'].includes(String(ev.type))) continue;
      const idx = Math.min(buckets - 1, Math.floor(ev.ts / bucketSize));
      counts[idx]++;
    }
    // 各バケット内 death 数を 1〜5 スケールに正規化
    const max = Math.max(1, ...counts);
    return counts.map((c) => 1 + (c / max) * 4);
  }

  /**
   * プロジェクト内ファイル一覧から軽量にフィーチャーフラグを推定。
   * 完全には判定できないが、AV統一感や tutorial 有無などのヒントになる。
   */
  private async detectFeatureFlags(projectDir: string): Promise<{
    hasTutorial: boolean;
    hasSettings: boolean;
    hasAccessibilityOptions: boolean;
    hasSaveLoad: boolean;
    hasReplayability: boolean;
    audioVisualConsistency: number;
  }> {
    const flags = {
      hasTutorial: false,
      hasSettings: false,
      hasAccessibilityOptions: false,
      hasSaveLoad: false,
      hasReplayability: false,
      audioVisualConsistency: 0.7, // デフォルト
    };
    try {
      const allFiles = await this.listProjectFiles(projectDir, 6);
      const text = allFiles.join('\n').toLowerCase();
      if (/tutorial|onboarding|チュートリアル/.test(text)) flags.hasTutorial = true;
      if (/settings|config|設定/.test(text)) flags.hasSettings = true;
      if (/accessibility|a11y|colorblind|font_scale|アクセシビリティ/.test(text))
        flags.hasAccessibilityOptions = true;
      if (/save|load|localstorage|セーブ|ロード/.test(text)) flags.hasSaveLoad = true;
      if (/achievement|ranking|unlock|ng_plus|アチーブ|ランキング/.test(text))
        flags.hasReplayability = true;
    } catch {
      // ファイル列挙失敗時は全部 false のまま
    }
    return flags;
  }

  /** プロジェクトの相対ファイルパス一覧 (制限付き) */
  private async listProjectFiles(root: string, depth: number): Promise<string[]> {
    const results: string[] = [];
    const skip = new Set(['node_modules', '.git', 'dist', 'build', '.next', '.gvr-checkpoints']);
    const walk = async (dir: string, d: number): Promise<void> => {
      if (d < 0) return;
      let entries: import('node:fs').Dirent[];
      try {
        entries = await fs.readdir(dir, { withFileTypes: true });
      } catch {
        return;
      }
      for (const ent of entries) {
        if (skip.has(ent.name)) continue;
        const full = path.join(dir, ent.name);
        if (ent.isDirectory()) {
          await walk(full, d - 1);
        } else if (ent.isFile()) {
          results.push(path.relative(root, full));
        }
      }
    };
    await walk(root, depth);
    return results;
  }

  /** プレイテスト結果から簡易 FUN スコアを推定 */
  private estimateFunFromPlaytest(playtest?: AutoPlaytestSession): number {
    if (!playtest) return 5; // 中央値
    const m = playtest.metrics;
    let s = 5; // ベース
    // クラッシュ/ソフトロックは大幅減点
    s -= m.crashCount * 2;
    s -= m.softlockCount * 1.5;
    // 進行度が高いとプラス
    s += (m.progressionPercent / 100) * 2;
    // 継続時間が長いとプラス (10分以上満点)
    s += Math.min(2, m.sessionContinuedMin / 5);
    // 死亡が極端に多いとマイナス (難易度高すぎ)
    if (m.deathCount > 20) s -= 1;
    return Math.max(0, Math.min(10, s));
  }

  // ========================================
  // 内部: 改善要望の詳細生成
  // ========================================

  /** 軸ごとに日本語の改善説明・修正方針・影響ファイル候補を生成 */
  private buildImprovementDetails(
    category: ImprovementCategory,
    axisScore: AxisScore,
    projectDir: string,
  ): { description: string; suggestedFix: string; affectedFiles: string[] } {
    const details = axisScore.details ?? {};
    const failed = axisScore.failed_checks.join(', ') || '具体的失敗は未特定';

    switch (category) {
      case 'fps':
        return {
          description: `FPS安定性スコアが ${axisScore.score.toFixed(1)}/10。失敗項目: ${failed}。平均FPS=${details.avg_fps ?? '不明'}、p1=${details.p1_fps ?? '不明'}。`,
          suggestedFix:
            '描画ループの最適化(オブジェクトプール導入/不要なnew回避)、テクスチャアトラス化、Canvas/WebGLの選択見直し、requestAnimationFrame の二重実行を確認。重い処理は Web Worker へ移譲。',
          affectedFiles: this.guessFiles(projectDir, ['game.', 'main.', 'scene.', 'render.']),
        };
      case 'input_latency':
        return {
          description: `入力遅延スコアが ${axisScore.score.toFixed(1)}/10。失敗項目: ${failed}。平均レイテンシ=${details.avg_ms ?? '不明'}ms、p95=${details.p95_ms ?? '不明'}ms。`,
          suggestedFix:
            'pointerdown を使い click 待ちを避ける、event listener の passive 属性追加、重い処理を入力ハンドラから切り離し setTimeout(0) で deferred 実行。touchstart で即時応答。',
          affectedFiles: this.guessFiles(projectDir, ['input.', 'controller.', 'handler.']),
        };
      case 'load_time':
        return {
          description: `ロード時間スコアが ${axisScore.score.toFixed(1)}/10。失敗項目: ${failed}。実測=${details.load_sec ?? '不明'}秒。`,
          suggestedFix:
            'アセット遅延ロード(初期画面で必要なものだけ)、テクスチャ圧縮(WebP/AVIF/Basis)、コードスプリッティング、HTTPキャッシュヘッダ調整、preload タグ追加。',
          affectedFiles: this.guessFiles(projectDir, ['loader.', 'preload.', 'assets/']),
        };
      case 'balance':
        return {
          description: `ゲームバランススコアが ${axisScore.score.toFixed(1)}/10。失敗項目: ${failed}。カーブ形状=${details.shape ?? '不明'}、ステージ数=${details.stages ?? '不明'}。`,
          suggestedFix:
            '難易度カーブを単調増加+山1-2箇所+休憩1-2箇所に調整、敵HP/スピードのレベル別パラメータを log カーブに、序盤に easy ステージを2-3個挿入、難所の前に休憩ステージを配置。',
          affectedFiles: this.guessFiles(projectDir, ['levels.', 'stages.', 'enemies.', 'balance.']),
        };
      case 'replayability':
        return {
          description: `リプレイ性スコアが ${axisScore.score.toFixed(1)}/10。失敗項目: ${failed}。実装数=${details.features_implemented ?? 0}/4。`,
          suggestedFix:
            '解放要素(アンロックキャラ/ステージ)・アチーブメント・スコアランキング・NG+(2周目)のいずれかを最低1つ実装。LocalStorage で進行を永続化。',
          affectedFiles: this.guessFiles(projectDir, ['achievement', 'unlock', 'ranking', 'save']),
        };
      case 'onboarding':
        return {
          description: `オンボーディングスコアが ${axisScore.score.toFixed(1)}/10。失敗項目: ${failed}。チュートリアル=${details.tutorial_min ?? '不明'}分、初回楽しさ瞬間=${details.first_fun_min ?? '不明'}分。`,
          suggestedFix:
            '3分以内に「楽しい瞬間」を体験させる導線へ。冒頭チュートリアルを 3分以内に圧縮、スキップ可能ボタン提供、操作説明はインゲームのオーバーレイで段階的に表示。',
          affectedFiles: this.guessFiles(projectDir, ['tutorial.', 'onboarding.', 'intro.']),
        };
      case 'av_consistency':
        return {
          description: `AV統一感スコアが ${axisScore.score.toFixed(1)}/10。失敗項目: ${failed}。`,
          suggestedFix:
            'カラーパレットを5色以内に統一、フォントは2種類以内、SE/BGMの音量レベルを揃える(BGM -20dB, SE -10dB 目安)、UI要素のサイズ・余白に統一グリッド適用。',
          affectedFiles: this.guessFiles(projectDir, ['style.', 'theme.', 'palette.', 'audio.']),
        };
      case 'ui_ux':
        return {
          description: `UI/UXスコアが ${axisScore.score.toFixed(1)}/10。失敗項目: ${failed}。タップターゲット=${details.tap_target_px ?? '不明'}px。`,
          suggestedFix:
            'タップターゲットを最低48x48pxに、エラー回復ボタン追加、ローディングインジケータ実装、誤タップ防止のため重要ボタン周囲にパディング。',
          affectedFiles: this.guessFiles(projectDir, ['ui.', 'button.', 'menu.', 'hud.']),
        };
      case 'accessibility':
        return {
          description: `アクセシビリティスコアが ${axisScore.score.toFixed(1)}/10。失敗項目: ${failed}。実装数=${details.features_implemented ?? 0}/4。`,
          suggestedFix:
            '色覚多様性モード(色弱フィルタ)、フォントサイズ可変、字幕オン/オフ、キーボード操作対応(Tab+矢印キー)のいずれかを実装。設定画面に集約。',
          affectedFiles: this.guessFiles(projectDir, [
            'accessibility.',
            'settings.',
            'a11y.',
          ]),
        };
      case 'fun':
        return {
          description: `楽しさFUNスコアが ${axisScore.score.toFixed(1)}/10。失敗項目: ${failed}。`,
          suggestedFix:
            'プレイヤーが達成感を得るフィードバック(画面エフェクト/SE/振動)を強化、コンボシステム導入、クリア時の演出を厚く、ヒット感を強める(画面シェイク/ヒットストップ)。',
          affectedFiles: this.guessFiles(projectDir, ['feedback.', 'effect.', 'combo.', 'fx.']),
        };
      default:
        return {
          description: `${category} スコアが ${axisScore.score.toFixed(1)}/10。失敗項目: ${failed}。`,
          suggestedFix: '該当軸の標準ベストプラクティスを適用してください。',
          affectedFiles: [],
        };
    }
  }

  /** プロジェクト内からキーワード一致するファイル候補を返す (best-effort) */
  private guessFiles(projectDir: string, keywords: string[]): string[] {
    // 同期的な glob は使わずヒント文字列のみ返す。Refiner 側で実ファイル探索する。
    // ここでは検索ヒントとしてキーワードを返す。
    return keywords.map((kw) => `<keyword:${kw}*>`);
  }
}
