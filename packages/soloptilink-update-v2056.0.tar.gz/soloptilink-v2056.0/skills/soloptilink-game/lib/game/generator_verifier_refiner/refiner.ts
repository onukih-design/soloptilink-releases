/**
 * refiner.ts
 * 責務: Verifier が生成した ImprovementRequest を入力に、
 *   実際にプロジェクト内のファイルを読み込み → 改善要望を日本語プロンプトに変換 →
 *   LLM(Claude/GPT-4/Gemini/Local) で修正パッチ生成 → ファイル適用 → 差分を返す。
 *   LLM は optional (API key 無しでも基本動作)。
 *   API key 未設定時はヒューリスティック修正(コメント追記/設定値変更等)にフォールバック。
 *   LLM 呼び出しは fetch ベースで provider-agnostic。
 *   すべての非同期処理は try-catch / タイムアウト付きで堅牢化。
 *   Node.js 環境で動作。
 */

import { promises as fs } from 'node:fs';
import * as path from 'node:path';
import * as crypto from 'node:crypto';

import type { ImprovementRequest } from './orchestrator';

// ========================================
// 型定義
// ========================================

/** Refiner の設定 */
export interface RefinerConfig {
  /** 対象プロジェクトディレクトリ */
  projectDir: string;
  /** 改善要望 (Verifier の出力 1件) */
  request: ImprovementRequest;
  /** LLM プロバイダ (既定: claude) */
  llmProvider?: 'claude' | 'gpt4' | 'gemini' | 'local';
  /** LLM 呼び出しタイムアウト ms (既定: 60秒) */
  timeoutMs?: number;
  /** API キー (省略時は環境変数を参照) */
  apiKey?: string;
  /** LLM API エンドポイント (local 用) */
  endpoint?: string;
  /** 一回の修正で対象とする最大ファイル数 (既定: 5) */
  maxFilesPerRequest?: number;
  /** dry-run: ファイル書き換えを行わず説明のみ返す */
  dryRun?: boolean;
}

/** Refiner の出力 */
export interface RefinerResult {
  /** 修正したファイルの相対パス */
  filesModified: string[];
  /** 変更概要 (日本語) */
  description: string;
  /** 処理所要時間 (ms) */
  durationMs: number;
  /** LLM 呼び出しコスト (USD, 推定) */
  llmCost?: number;
  /** 追加された行数 */
  linesAdded?: number;
  /** 削除された行数 */
  linesRemoved?: number;
  /** 使用した LLM プロバイダ (実際に呼んだもの) */
  provider: 'claude' | 'gpt4' | 'gemini' | 'local' | 'heuristic';
  /** 警告メッセージ */
  warnings: string[];
}

/** ファイル変更計画 */
interface FilePatch {
  filePath: string;
  before: string;
  after: string;
}

// ========================================
// Refiner 本体
// ========================================

/**
 * AI に修正させるためのプロンプト構築+ファイル更新。
 * `apply()` だけが公開API。
 */
export class Refiner {
  /**
   * 改善要望を1件適用する。
   * 失敗してもRefinerResult を返し、例外を上に投げない。
   */
  async apply(config: RefinerConfig): Promise<RefinerResult> {
    const started = Date.now();
    const warnings: string[] = [];
    const provider = config.llmProvider ?? 'claude';
    const timeoutMs = config.timeoutMs ?? 60_000;
    const maxFiles = config.maxFilesPerRequest ?? 5;
    const dryRun = config.dryRun === true;

    // ---- 1. 対象ファイルを特定 ----
    const targetFiles = await this.resolveTargetFiles(
      config.projectDir,
      config.request.affectedFiles,
      maxFiles,
    );
    if (targetFiles.length === 0) {
      return {
        filesModified: [],
        description: '対象ファイルが見つかりませんでした。プロジェクト構造を確認してください。',
        durationMs: Date.now() - started,
        provider: 'heuristic',
        warnings: ['no_target_files_found'],
        linesAdded: 0,
        linesRemoved: 0,
      };
    }

    // ---- 2. 対象ファイルを読み込み ----
    const fileContents: Record<string, string> = {};
    for (const f of targetFiles) {
      try {
        const full = path.resolve(config.projectDir, f);
        fileContents[f] = await fs.readFile(full, 'utf8');
      } catch (e) {
        warnings.push(`read_failed:${f}`);
      }
    }
    if (Object.keys(fileContents).length === 0) {
      return {
        filesModified: [],
        description: 'すべての対象ファイルの読み込みに失敗しました。',
        durationMs: Date.now() - started,
        provider: 'heuristic',
        warnings,
        linesAdded: 0,
        linesRemoved: 0,
      };
    }

    // ---- 3. プロンプト構築 ----
    const prompt = this.buildPrompt(config.request, fileContents);

    // ---- 4. LLM 呼び出し (失敗時は heuristic フォールバック) ----
    let patches: FilePatch[] = [];
    let usedProvider: RefinerResult['provider'] = 'heuristic';
    let estimatedCost = 0;

    const apiKey = config.apiKey ?? this.resolveApiKey(provider);
    if (apiKey || provider === 'local') {
      const llmCall = await Promise.allSettled([
        this.callLlm({
          provider,
          prompt,
          apiKey: apiKey ?? '',
          endpoint: config.endpoint,
          timeoutMs,
        }),
      ]);
      if (llmCall[0].status === 'fulfilled' && llmCall[0].value.patches.length > 0) {
        patches = llmCall[0].value.patches;
        estimatedCost = llmCall[0].value.estimatedCost;
        usedProvider = provider;
      } else {
        warnings.push(
          `llm_failed:${llmCall[0].status === 'rejected' ? this.errMsg(llmCall[0].reason) : 'no_patches'}`,
        );
      }
    } else {
      warnings.push(`no_api_key:${provider}`);
    }

    // ---- 4b. LLM が使えなかった場合: ヒューリスティック修正 ----
    if (patches.length === 0) {
      patches = this.heuristicPatches(config.request, fileContents);
      usedProvider = 'heuristic';
    }

    // ---- 5. パッチ適用 (dry-run 時はスキップ) ----
    let linesAdded = 0;
    let linesRemoved = 0;
    const modified: string[] = [];
    if (!dryRun) {
      for (const p of patches) {
        try {
          if (p.before === p.after) continue;
          const full = path.resolve(config.projectDir, p.filePath);
          await fs.writeFile(full, p.after, 'utf8');
          const beforeLines = p.before.split('\n').length;
          const afterLines = p.after.split('\n').length;
          const delta = afterLines - beforeLines;
          if (delta > 0) linesAdded += delta;
          else linesRemoved += -delta;
          modified.push(p.filePath);
        } catch (e) {
          warnings.push(`write_failed:${p.filePath}:${this.errMsg(e)}`);
        }
      }
    } else {
      // dry-run でも計画件数は返す
      for (const p of patches) {
        if (p.before === p.after) continue;
        modified.push(p.filePath);
      }
    }

    // ---- 6. 結果まとめ ----
    return {
      filesModified: modified,
      description: this.buildResultDescription(config.request, modified, usedProvider),
      durationMs: Date.now() - started,
      llmCost: estimatedCost,
      linesAdded,
      linesRemoved,
      provider: usedProvider,
      warnings,
    };
  }

  // ========================================
  // 内部: 対象ファイル解決
  // ========================================

  /**
   * ImprovementRequest.affectedFiles に含まれるキーワードを実ファイルに解決する。
   * `<keyword:xxx*>` 形式のヒントは projectDir 内で部分一致検索。
   * 実ファイルパス指定はそのまま。
   */
  private async resolveTargetFiles(
    projectDir: string,
    hints: string[],
    maxFiles: number,
  ): Promise<string[]> {
    const results = new Set<string>();
    const keywordHints: string[] = [];

    for (const h of hints) {
      const m = h.match(/^<keyword:(.+?)\*?>$/);
      if (m) {
        keywordHints.push(m[1].toLowerCase());
      } else {
        // 実パスとして扱う
        const full = path.resolve(projectDir, h);
        if (await this.exists(full)) results.add(h);
      }
    }

    // キーワードが残っていればプロジェクト走査
    if (keywordHints.length > 0) {
      const allFiles = await this.listProjectFiles(projectDir, 6);
      for (const f of allFiles) {
        const lower = f.toLowerCase();
        if (keywordHints.some((kw) => lower.includes(kw))) {
          results.add(f);
        }
        if (results.size >= maxFiles) break;
      }
    }

    return [...results].slice(0, maxFiles);
  }

  private async exists(p: string): Promise<boolean> {
    try {
      await fs.stat(p);
      return true;
    } catch {
      return false;
    }
  }

  private async listProjectFiles(root: string, depth: number): Promise<string[]> {
    const results: string[] = [];
    const skip = new Set(['node_modules', '.git', 'dist', 'build', '.next', '.gvr-checkpoints']);
    const exts = new Set(['.ts', '.tsx', '.js', '.jsx', '.json', '.html', '.css', '.cs', '.cpp']);
    const walk = async (dir: string, d: number): Promise<void> => {
      if (d < 0) return;
      let entries: import('node:fs').Dirent[];
      try {
        entries = await fs.readdir(dir, { withFileTypes: true });
      } catch {
        return;
      }
      for (const ent of entries) {
        if (skip.has(ent.name)) continue;
        const full = path.join(dir, ent.name);
        if (ent.isDirectory()) {
          await walk(full, d - 1);
        } else if (ent.isFile()) {
          const ex = path.extname(ent.name).toLowerCase();
          if (exts.has(ex)) results.push(path.relative(root, full));
        }
      }
    };
    await walk(root, depth);
    return results;
  }

  // ========================================
  // 内部: プロンプト構築
  // ========================================

  /** 改善要望を日本語プロンプトに変換 */
  private buildPrompt(
    request: ImprovementRequest,
    fileContents: Record<string, string>,
  ): string {
    const fileBlocks = Object.entries(fileContents)
      .map(([p, c]) => `### ファイル: ${p}\n\`\`\`\n${this.truncate(c, 12_000)}\n\`\`\``)
      .join('\n\n');

    return [
      'あなたはゲーム開発のシニアエンジニアです。次の改善要望に従い、',
      '提供されたファイルを最小限の差分で修正してください。',
      '',
      '## 改善要望',
      `- 軸: ${request.category}`,
      `- 重要度: ${request.severity}`,
      `- 現在スコア: ${request.currentScore}/10`,
      `- 目標スコア: ${request.targetScore}/10`,
      '',
      '## 説明',
      request.description,
      '',
      '## 推奨修正方針',
      request.suggestedFix,
      '',
      '## 対象ファイル',
      fileBlocks,
      '',
      '## 出力フォーマット (必須)',
      '修正後のファイル内容を、以下の JSON 形式で返してください。説明文は不要、JSON のみ。',
      '```json',
      '{',
      '  "patches": [',
      '    { "filePath": "<相対パス>", "newContent": "<修正後の全文>" }',
      '  ]',
      '}',
      '```',
    ].join('\n');
  }

  /** 文字列を指定文字数で切り詰める */
  private truncate(s: string, max: number): string {
    if (s.length <= max) return s;
    return s.slice(0, max) + `\n... [truncated ${s.length - max} chars]`;
  }

  // ========================================
  // 内部: LLM 呼び出し (provider-agnostic)
  // ========================================

  /** 環境変数から API key を取得 */
  private resolveApiKey(provider: string): string | undefined {
    switch (provider) {
      case 'claude':
        return process.env.ANTHROPIC_API_KEY || process.env.CLAUDE_API_KEY;
      case 'gpt4':
        return process.env.OPENAI_API_KEY;
      case 'gemini':
        return process.env.GEMINI_API_KEY || process.env.GOOGLE_API_KEY;
      case 'local':
        return process.env.LOCAL_LLM_KEY || '';
      default:
        return undefined;
    }
  }

  /**
   * LLM を呼び出してパッチを得る。
   * fetch ベース、provider 毎にエンドポイントとリクエスト形式を切り替え。
   */
  private async callLlm(opts: {
    provider: 'claude' | 'gpt4' | 'gemini' | 'local';
    prompt: string;
    apiKey: string;
    endpoint?: string;
    timeoutMs: number;
  }): Promise<{ patches: FilePatch[]; estimatedCost: number }> {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), opts.timeoutMs);

    try {
      let url: string;
      let headers: Record<string, string>;
      let body: string;

      switch (opts.provider) {
        case 'claude':
          url = 'https://api.anthropic.com/v1/messages';
          headers = {
            'content-type': 'application/json',
            'x-api-key': opts.apiKey,
            'anthropic-version': '2023-06-01',
          };
          body = JSON.stringify({
            model: 'claude-3-5-sonnet-20241022',
            max_tokens: 8192,
            messages: [{ role: 'user', content: opts.prompt }],
          });
          break;
        case 'gpt4':
          url = 'https://api.openai.com/v1/chat/completions';
          headers = {
            'content-type': 'application/json',
            authorization: `Bearer ${opts.apiKey}`,
          };
          body = JSON.stringify({
            model: 'gpt-4o',
            max_tokens: 8192,
            messages: [{ role: 'user', content: opts.prompt }],
          });
          break;
        case 'gemini':
          url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent?key=${encodeURIComponent(opts.apiKey)}`;
          headers = { 'content-type': 'application/json' };
          body = JSON.stringify({
            contents: [{ role: 'user', parts: [{ text: opts.prompt }] }],
          });
          break;
        case 'local':
          url = opts.endpoint ?? 'http://localhost:11434/api/chat';
          headers = { 'content-type': 'application/json' };
          body = JSON.stringify({
            model: 'llama3:70b',
            messages: [{ role: 'user', content: opts.prompt }],
            stream: false,
          });
          break;
        default:
          throw new Error(`unsupported_provider:${opts.provider}`);
      }

      const res = await fetch(url, {
        method: 'POST',
        headers,
        body,
        signal: controller.signal,
      });
      if (!res.ok) {
        throw new Error(`http_${res.status}:${await res.text().catch(() => '')}`);
      }
      const json: any = await res.json();
      const text = this.extractText(opts.provider, json);
      const patches = this.parsePatches(text);
      const estimatedCost = this.estimateCost(opts.provider, opts.prompt.length, text.length);
      return { patches, estimatedCost };
    } finally {
      clearTimeout(timer);
    }
  }

  /** LLM 応答から本文テキストを取り出す (provider 毎) */
  private extractText(provider: string, json: any): string {
    try {
      switch (provider) {
        case 'claude':
          return (json.content?.[0]?.text as string) ?? '';
        case 'gpt4':
          return (json.choices?.[0]?.message?.content as string) ?? '';
        case 'gemini':
          return (json.candidates?.[0]?.content?.parts?.[0]?.text as string) ?? '';
        case 'local':
          // Ollama 互換
          return (json.message?.content as string) ?? (json.response as string) ?? '';
        default:
          return '';
      }
    } catch {
      return '';
    }
  }

  /** 応答テキストから JSON パッチを抽出 */
  private parsePatches(text: string): FilePatch[] {
    if (!text) return [];
    // ```json ... ``` ブロックを優先
    const fenced = text.match(/```json\s*([\s\S]*?)```/i);
    const candidate = fenced ? fenced[1] : text;
    try {
      const parsed = JSON.parse(candidate);
      const arr = Array.isArray(parsed?.patches) ? parsed.patches : [];
      const result: FilePatch[] = [];
      for (const item of arr) {
        if (
          item &&
          typeof item.filePath === 'string' &&
          typeof item.newContent === 'string'
        ) {
          result.push({
            filePath: item.filePath,
            before: '', // applyで使う before は後段で再計算 (LLMは全文置き換え)
            after: item.newContent,
          });
        }
      }
      return result;
    } catch {
      return [];
    }
  }

  /** トークン消費の超粗い USD 推定 (provider 毎の単価固定) */
  private estimateCost(provider: string, promptChars: number, outputChars: number): number {
    // 4文字≒1トークン換算
    const inTok = promptChars / 4;
    const outTok = outputChars / 4;
    const rates: Record<string, [number, number]> = {
      claude: [0.000003, 0.000015], // input/output USD per token
      gpt4: [0.0000025, 0.00001],
      gemini: [0.00000125, 0.000005],
      local: [0, 0],
    };
    const [ri, ro] = rates[provider] ?? [0, 0];
    return inTok * ri + outTok * ro;
  }

  // ========================================
  // 内部: ヒューリスティックフォールバック
  // ========================================

  /**
   * LLM が使えない場合の最低限の修正案。
   * コメント追記/設定ファイル微調整など、副作用の小さい変更のみ。
   */
  private heuristicPatches(
    request: ImprovementRequest,
    fileContents: Record<string, string>,
  ): FilePatch[] {
    const patches: FilePatch[] = [];
    const tag = `// [GVR] ${request.category} 改善要望 sev=${request.severity}: ${this.escapeOneLine(request.suggestedFix)}`;

    for (const [filePath, content] of Object.entries(fileContents)) {
      // 既にタグ済みなら skip
      if (content.includes(`[GVR] ${request.category}`)) continue;
      const ext = path.extname(filePath).toLowerCase();
      let prefix = '';
      if (['.ts', '.tsx', '.js', '.jsx', '.cs', '.cpp'].includes(ext)) {
        prefix = `${tag}\n`;
      } else if (ext === '.css') {
        prefix = `/* [GVR] ${request.category} sev=${request.severity}: ${this.escapeOneLine(request.suggestedFix)} */\n`;
      } else if (ext === '.html') {
        prefix = `<!-- [GVR] ${request.category} sev=${request.severity}: ${this.escapeOneLine(request.suggestedFix)} -->\n`;
      } else if (ext === '.json') {
        // JSON にはコメント付けられないので変更しない
        continue;
      } else {
        prefix = `${tag}\n`;
      }
      patches.push({ filePath, before: content, after: prefix + content });
    }
    return patches;
  }

  private escapeOneLine(s: string): string {
    return s.replace(/\n/g, ' ').replace(/\*\//g, '*\\/').slice(0, 240);
  }

  // ========================================
  // 内部: ユーティリティ
  // ========================================

  private errMsg(e: unknown): string {
    if (e instanceof Error) return e.message;
    if (typeof e === 'string') return e;
    try {
      return JSON.stringify(e);
    } catch {
      return String(e);
    }
  }

  /** 結果説明文を組み立てる (日本語) */
  private buildResultDescription(
    request: ImprovementRequest,
    modified: string[],
    provider: RefinerResult['provider'],
  ): string {
    if (modified.length === 0) {
      return `改善要望 ${request.category} (sev=${request.severity}) の適用に失敗 (provider=${provider})。`;
    }
    return [
      `軸=${request.category} sev=${request.severity} (${request.currentScore} → ${request.targetScore} 目標)`,
      `provider=${provider} で ${modified.length} ファイルを修正。`,
      `対象: ${modified.join(', ')}`,
    ].join(' / ');
  }
}
