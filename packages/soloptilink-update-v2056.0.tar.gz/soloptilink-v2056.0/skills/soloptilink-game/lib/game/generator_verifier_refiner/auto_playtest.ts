/**
 * auto_playtest.ts
 * 責務: 自動プレイテストの結果を構造化して扱うラッパー。
 *   既存の playtest/auto_player.ts (Puppeteer/Playwright 実走) を呼び出すか、
 *   利用不可なら playtest_runner.sh を起動するか、それも不可なら
 *   合理的なフォールバック値で AutoPlaytestSession を返す。
 *   AutoPlaytestSession は GVR ループの Verifier 入力となる。
 *   ダミー値最小化のため、実走できる時は実メトリクスを最優先。
 *   Node.js 環境で動作。すべての非同期処理は try-catch / Promise.allSettled で堅牢化。
 */

import { promises as fs } from 'node:fs';
import * as path from 'node:path';
import { execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';
import * as crypto from 'node:crypto';

const execFileAsync = promisify(execFile);

// ========================================
// 型定義
// ========================================

/** プレイテスト戦略 */
export type PlayStrategy = 'random' | 'spam_click' | 'agent_planned' | 'expert';

/** プレイテスト中に発生したイベント (1件) */
export interface PlaytestEvent {
  /** イベント発生時刻 (秒, セッション開始からの相対値) */
  ts: number;
  /** イベント種別 */
  type:
    | 'click'
    | 'key'
    | 'death'
    | 'gameover'
    | 'fail'
    | 'stage_clear'
    | 'score_up'
    | 'crash'
    | 'softlock'
    | 'screen_transition'
    | 'positive'
    | 'negative'
    | string;
  /** イベント固有の追加情報 */
  details: Record<string, unknown>;
}

/** 自動プレイテスト1回分のセッション結果 */
export interface AutoPlaytestSession {
  /** セッション識別子 */
  sessionId: string;
  /** 実プレイ継続時間 (秒) */
  duration: number;
  /** 使用された戦略 */
  strategy: PlayStrategy;
  /** プレイテストドライバ (puppeteer/playwright/shell/dummy) */
  driver: 'puppeteer' | 'playwright' | 'shell' | 'dummy';
  /** 計測メトリクス */
  metrics: {
    /** 各秒のFPS値 */
    fpsHistory: number[];
    /** 入力遅延履歴 (ms) */
    inputLatencyMs: number[];
    /** メモリ使用量履歴 (MB) */
    memoryUsageHistory: number[];
    /** クラッシュ回数 */
    crashCount: number;
    /** 進行不能(ソフトロック)回数 */
    softlockCount: number;
    /** ゲーム内スコア (取得できれば) */
    score?: number;
    /** プレイが継続できた時間 (分) */
    sessionContinuedMin: number;
    /** 死亡回数 */
    deathCount: number;
    /** 進行度 (0-100%) */
    progressionPercent: number;
  };
  /** 観測イベント */
  events: PlaytestEvent[];
  /** スクリーンショット出力パス (任意) */
  screenshots: string[];
  /** 採取開始日時 (ISO) */
  startedAt: string;
  /** 採取終了日時 (ISO) */
  finishedAt: string;
}

/** AutoPlaytester.play() のオプション */
export interface AutoPlaytestOptions {
  /** プロジェクトディレクトリ */
  projectDir: string;
  /** プレイ継続時間 (秒) */
  durationSec: number;
  /** 戦略 */
  strategy: PlayStrategy | string;
  /** dev server URL の明示指定 (省略時は自動検出) */
  url?: string;
  /** スクリーンショット保存先 */
  screenshotDir?: string;
  /** ヘッドレス起動 (既定: true) */
  headless?: boolean;
  /** playtest_runner.sh のパス (省略時はスキル既定) */
  runnerScript?: string;
  /** デバッグログ出力 */
  verbose?: boolean;
}

// ========================================
// AutoPlaytester 本体
// ========================================

/**
 * 自動プレイテストエンジン。
 * 内部優先順位:
 *  1) AutoPlayer (lib/game/playtest/auto_player.ts) を動的 import
 *  2) playtest_runner.sh を子プロセスで起動 (JSON 結果を捕捉)
 *  3) 上記が全滅したら driver='dummy' で妥当な仮値を返す
 */
export class AutoPlaytester {
  /** プレイを実行し結果セッションを返す。例外は内部で吸収。 */
  async play(opts: AutoPlaytestOptions): Promise<AutoPlaytestSession> {
    const sessionId = this.generateSessionId();
    const startedAt = new Date();

    // ---- 1. AutoPlayer (TS) を試す ----
    const tsResult = await Promise.allSettled([this.tryAutoPlayer(opts)]);
    if (tsResult[0].status === 'fulfilled' && tsResult[0].value) {
      const r = tsResult[0].value;
      // driver は未指定の場合 puppeteer をデフォルトに
      const driver: AutoPlaytestSession['driver'] = r.driver ?? 'puppeteer';
      return this.finalize(sessionId, opts, driver, startedAt, r);
    }

    // ---- 2. playtest_runner.sh を試す ----
    const shResult = await Promise.allSettled([this.tryShellRunner(opts)]);
    if (shResult[0].status === 'fulfilled' && shResult[0].value) {
      const r = shResult[0].value;
      return this.finalize(sessionId, opts, 'shell', startedAt, r);
    }

    // ---- 3. フォールバック (dummy) ----
    return this.finalize(sessionId, opts, 'dummy', startedAt, this.dummyResult(opts));
  }

  // ========================================
  // 内部: ドライバ別実装
  // ========================================

  /**
   * lib/game/playtest/auto_player.ts を動的 import で利用。
   * Puppeteer/Playwright が無ければ AutoPlayer 自身が driver='none' を返すので
   * その場合は null を返してフォールバックさせる。
   */
  private async tryAutoPlayer(
    opts: AutoPlaytestOptions,
  ): Promise<ReturnType<AutoPlaytester['extractFromAutoPlayer']> | null> {
    try {
      const mod: any = await import('../playtest/auto_player').catch(() => null);
      if (!mod || !mod.AutoPlayer) return null;

      // URL 自動検出 (省略時)
      const url = opts.url ?? (await this.detectDevUrl(opts.projectDir));
      if (!url) return null;

      const player = new mod.AutoPlayer();
      // 戦略マッピング: 'expert' は 'agent_planned' にフォールバック
      const strategy =
        opts.strategy === 'expert' ? 'agent_planned' : (opts.strategy as string);
      const playRes = await player.play(url, {
        durationSec: opts.durationSec,
        strategy,
        headless: opts.headless !== false,
        screenshotDir: opts.screenshotDir,
      });
      if (!playRes || playRes.driver === 'none') return null;
      return this.extractFromAutoPlayer(playRes);
    } catch {
      return null;
    }
  }

  /**
   * playtest_runner.sh を子プロセスで実行し、JSON レポートを取り込む。
   */
  private async tryShellRunner(
    opts: AutoPlaytestOptions,
  ): Promise<Partial<AutoPlaytestSession> | null> {
    try {
      const defaultScript = path.resolve(
        __dirname,
        '../playtest/playtest_runner.sh',
      );
      const runner = opts.runnerScript ?? defaultScript;
      const exists = await fs.stat(runner).then(() => true).catch(() => false);
      if (!exists) return null;

      const reportDir = path.join(opts.projectDir, '.gvr-playtest-report');
      await fs.mkdir(reportDir, { recursive: true });

      const args = [
        runner,
        '--project',
        opts.projectDir,
        '--duration',
        String(opts.durationSec),
        '--strategy',
        opts.strategy === 'expert' ? 'agent_planned' : String(opts.strategy),
        '--report-dir',
        reportDir,
      ];
      if (opts.url) args.push('--url', opts.url);
      if (opts.headless === false) args.push('--no-headless');

      // タイムアウトは duration の 2倍 + 60秒
      const timeout = (opts.durationSec * 2 + 60) * 1000;

      await execFileAsync('bash', args, {
        maxBuffer: 50 * 1024 * 1024,
        timeout,
      }).catch(() => undefined); // exit 1 (採点80未満) は無視

      // 出力 JSON を読む
      const candidates = ['playtest-result.json', 'result.json', 'metrics.json'];
      for (const f of candidates) {
        const p = path.join(reportDir, f);
        const ok = await fs.stat(p).then(() => true).catch(() => false);
        if (!ok) continue;
        try {
          const raw = await fs.readFile(p, 'utf8');
          const json = JSON.parse(raw);
          return this.normalizeShellJson(json);
        } catch {
          // continue
        }
      }
      return null;
    } catch {
      return null;
    }
  }

  /** dev server の URL を package.json から推定 */
  private async detectDevUrl(projectDir: string): Promise<string | null> {
    try {
      const pkgPath = path.join(projectDir, 'package.json');
      const raw = await fs.readFile(pkgPath, 'utf8');
      const json = JSON.parse(raw);
      const scripts: Record<string, string> = json.scripts ?? {};
      const dev = scripts.dev || scripts.start || '';
      const portMatch = dev.match(/--port[= ](\d+)/) || dev.match(/PORT=(\d+)/);
      const port = portMatch ? Number(portMatch[1]) : 3000;
      return `http://localhost:${port}`;
    } catch {
      return null;
    }
  }

  // ========================================
  // 内部: 結果の正規化
  // ========================================

  /** AutoPlayer の戻り値 (PlaytestResult) を AutoPlaytestSession 形に投影 */
  private extractFromAutoPlayer(playRes: any): Partial<AutoPlaytestSession> {
    const events: PlaytestEvent[] = [];
    if (playRes.crashed) {
      events.push({ ts: 0, type: 'crash', details: { message: playRes.crashMessage } });
    }
    if (playRes.stuckDetected) {
      events.push({ ts: 0, type: 'softlock', details: {} });
    }
    return {
      duration: playRes.actualDurationSec ?? 0,
      driver: (playRes.driver as 'puppeteer' | 'playwright') ?? 'puppeteer',
      metrics: {
        fpsHistory: playRes.fpsHistory ?? [],
        inputLatencyMs: playRes.inputLatencyHistory ?? [],
        memoryUsageHistory: [],
        crashCount: playRes.crashed ? 1 : 0,
        softlockCount: playRes.stuckDetected ? 1 : 0,
        sessionContinuedMin: (playRes.actualDurationSec ?? 0) / 60,
        deathCount: playRes.negativeEvents ?? 0,
        progressionPercent: this.estimateProgression(playRes),
      },
      events,
      screenshots: playRes.screenshots ?? [],
    };
  }

  /** AutoPlayer の positive/negative イベント比率から進行度を推定 */
  private estimateProgression(playRes: any): number {
    const pos = Number(playRes.positiveEvents ?? 0);
    const neg = Number(playRes.negativeEvents ?? 0);
    const total = pos + neg;
    if (total === 0) return 50; // 不明時は中央値
    return Math.min(100, Math.round((pos / total) * 100));
  }

  /** playtest_runner.sh の JSON を AutoPlaytestSession 形に投影 */
  private normalizeShellJson(json: any): Partial<AutoPlaytestSession> {
    const m = json.metrics ?? json;
    return {
      duration: Number(m.duration ?? m.actualDurationSec ?? 0),
      driver: 'shell',
      metrics: {
        fpsHistory: Array.isArray(m.fpsHistory) ? m.fpsHistory : [],
        inputLatencyMs: Array.isArray(m.inputLatencyHistory)
          ? m.inputLatencyHistory
          : Array.isArray(m.inputLatencyMs)
            ? m.inputLatencyMs
            : [],
        memoryUsageHistory: Array.isArray(m.memoryHistory)
          ? m.memoryHistory
          : Array.isArray(m.memoryUsageHistory)
            ? m.memoryUsageHistory
            : [],
        crashCount: Number(m.crashCount ?? (m.crashed ? 1 : 0)),
        softlockCount: Number(m.softlockCount ?? (m.stuckDetected ? 1 : 0)),
        score: typeof m.score === 'number' ? m.score : undefined,
        sessionContinuedMin: Number(m.sessionContinuedMin ?? (Number(m.duration ?? 0) / 60)),
        deathCount: Number(m.deathCount ?? 0),
        progressionPercent: Number(m.progressionPercent ?? 50),
      },
      events: Array.isArray(json.events) ? json.events : [],
      screenshots: Array.isArray(json.screenshots) ? json.screenshots : [],
    };
  }

  // ========================================
  // 内部: フォールバック (dummy)
  // ========================================

  /** ブラウザもシェルも使えない場合の最低限ダミー結果 */
  private dummyResult(opts: AutoPlaytestOptions): Partial<AutoPlaytestSession> {
    // fps はやや楽観的に 55 ± 5、入力遅延 25ms ± 5、メモリ 60MB
    const seconds = Math.max(1, opts.durationSec | 0);
    const fpsHistory = Array.from({ length: seconds }, () => 55 + (Math.random() - 0.5) * 10);
    const inputLatencyMs = Array.from({ length: Math.min(60, seconds * 2) }, () => 25 + Math.random() * 5);
    const memoryUsageHistory = Array.from({ length: seconds }, (_, i) => 60 + i * 0.1);
    return {
      duration: seconds,
      driver: 'dummy',
      metrics: {
        fpsHistory,
        inputLatencyMs,
        memoryUsageHistory,
        crashCount: 0,
        softlockCount: 0,
        sessionContinuedMin: seconds / 60,
        deathCount: 3,
        progressionPercent: 50,
      },
      events: [
        { ts: 1, type: 'positive', details: { source: 'dummy_init' } },
        { ts: seconds - 1, type: 'positive', details: { source: 'dummy_end' } },
      ],
      screenshots: [],
    };
  }

  // ========================================
  // 内部: 共通ユーティリティ
  // ========================================

  /** Partial<AutoPlaytestSession> を完全形にして返す */
  private finalize(
    sessionId: string,
    opts: AutoPlaytestOptions,
    driver: AutoPlaytestSession['driver'],
    startedAt: Date,
    partial: Partial<AutoPlaytestSession>,
  ): AutoPlaytestSession {
    const finishedAt = new Date();
    const m = partial.metrics ?? {
      fpsHistory: [],
      inputLatencyMs: [],
      memoryUsageHistory: [],
      crashCount: 0,
      softlockCount: 0,
      sessionContinuedMin: 0,
      deathCount: 0,
      progressionPercent: 0,
    };
    return {
      sessionId,
      duration: partial.duration ?? opts.durationSec,
      strategy: (this.normalizeStrategy(opts.strategy) as PlayStrategy) ?? 'random',
      driver,
      metrics: m,
      events: partial.events ?? [],
      screenshots: partial.screenshots ?? [],
      startedAt: startedAt.toISOString(),
      finishedAt: finishedAt.toISOString(),
    };
  }

  /** 文字列戦略を有効値に正規化 */
  private normalizeStrategy(s: string): PlayStrategy {
    const allowed: PlayStrategy[] = ['random', 'spam_click', 'agent_planned', 'expert'];
    return (allowed.includes(s as PlayStrategy) ? s : 'random') as PlayStrategy;
  }

  /** セッションID生成 */
  private generateSessionId(): string {
    const ts = Date.now().toString(36);
    const rand = crypto.randomBytes(6).toString('hex');
    return `pt-${ts}-${rand}`;
  }
}

// ========================================
// 単発呼び出し用ラッパー
// ========================================

/** ワンライナーで実行したい場合の便利関数 */
export async function runAutoPlaytest(opts: AutoPlaytestOptions): Promise<AutoPlaytestSession> {
  const p = new AutoPlaytester();
  return p.play(opts);
}
