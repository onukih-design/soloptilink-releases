/**
 * orchestrator.ts
 * 責務: Generator-Verifier-Refiner ループ全体のオーケストレーター。
 *   1回生成 → 自動プレイテスト → Game Quality Fortress 採点 →
 *   低スコア軸の特定 → ImprovementRequest 生成 → AI(任意LLM)で
 *   修正コード生成 → ファイル適用 → ビルド+疎通確認 → 次イテレーション
 *   というサイクルを最大 N 回 自動で回し、収束または最大回数到達で停止する。
 *   各イテレーション完了時にチェックポイントを保存し、悪化時はロールバック可能。
 *   v2.0 の核心モジュール: 「1発出力」を「実質的な多発出力」に化けさせる。
 *   Node.js 環境で動作。すべての非同期処理は try-catch / Promise.allSettled で堅牢化。
 */

import { promises as fs } from 'node:fs';
import * as path from 'node:path';
import * as crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';

import { Verifier } from './verifier';
import type { VerifierResult } from './verifier';
import { Refiner } from './refiner';
import type { RefinerResult } from './refiner';
import { AutoPlaytester } from './auto_playtest';
import type { AutoPlaytestSession } from './auto_playtest';
import { ConvergenceDetector } from './convergence_detector';
import type { ConvergenceCriteria } from './convergence_detector';

const execFileAsync = promisify(execFile);

// ========================================
// 型定義
// ========================================

/** 改善要望カテゴリ (Game Quality Fortress 10軸に対応) */
export type ImprovementCategory =
  | 'fps'
  | 'input_latency'
  | 'balance'
  | 'fun'
  | 'av_consistency'
  | 'onboarding'
  | 'replayability'
  | 'ui_ux'
  | 'accessibility'
  | 'load_time';

/** 改善要望の重要度 */
export type ImprovementSeverity = 'critical' | 'high' | 'medium' | 'low';

/** 1件の改善要望 */
export interface ImprovementRequest {
  /** どの軸に対する改善か */
  category: ImprovementCategory;
  /** 重要度 */
  severity: ImprovementSeverity;
  /** 現在のスコア (0-10) */
  currentScore: number;
  /** 目標スコア (0-10) */
  targetScore: number;
  /** 改善内容の自然言語説明 (日本語) */
  description: string;
  /** 推奨修正方針 (日本語) */
  suggestedFix: string;
  /** 影響するファイル一覧 (相対パス) */
  affectedFiles: string[];
}

/** 1イテレーションの記録 */
export interface GvrIteration {
  /** イテレーション番号 (1始まり) */
  iteration: number;
  /** イテレーション開始日時 */
  generatedAt: Date;
  /** 採点で得た合計スコア (0-100) */
  qualityScore: number;
  /** このイテレーションで適用した改善要望 */
  improvementsRequested: ImprovementRequest[];
  /** ファイル差分情報 (適用後) */
  diff?: {
    filesChanged: string[];
    linesAdded: number;
    linesRemoved: number;
  };
  /** イテレーション所要時間 (ms) */
  durationMs: number;
  /** チェックポイントID (ロールバック用) */
  checkpointId?: string;
  /** エラーが発生した場合のメッセージ */
  errorMessage?: string;
}

/** GVR セッション全体の状態 */
export interface GvrSession {
  /** セッション識別子 */
  sessionId: string;
  /** 対象プロジェクトディレクトリ (絶対パス) */
  projectDir: string;
  /** 目標品質スコア (例: 90 = Gold相当) */
  targetQualityScore: number;
  /** 最大イテレーション数 */
  maxIterations: number;
  /** イテレーション履歴 */
  iterationHistory: GvrIteration[];
  /** セッション状態 */
  status: 'running' | 'converged' | 'maxIterations' | 'failed';
  /** 最終スコア (停止時) */
  finalScore?: number;
  /** 開始日時 */
  startedAt: Date;
  /** 終了日時 */
  finishedAt?: Date;
  /** 停止理由 (日本語) */
  stopReason?: string;
}

/** run() のオプション */
export interface GvrRunOptions {
  /** 対象プロジェクトディレクトリ */
  projectDir: string;
  /** 目標スコア (既定: 90) */
  targetScore?: number;
  /** 最大イテレーション数 (既定: 10) */
  maxIterations?: number;
  /** Game Quality Fortress (game_fortress.ts) への参照パス */
  qualityFortressPath?: string;
  /** イテレーション完了時のコールバック */
  onIterationComplete?: (iter: GvrIteration) => void;
  /** プレイテスト 1回あたりの継続時間 (秒, 既定: 60) */
  playtestDurationSec?: number;
  /** プレイテスト戦略 (既定: random) */
  playtestStrategy?: 'random' | 'spam_click' | 'agent_planned' | 'expert';
  /** LLM プロバイダ (既定: claude) */
  llmProvider?: 'claude' | 'gpt4' | 'gemini' | 'local';
  /** 収束判定基準 (省略時はデフォルト) */
  convergenceCriteria?: ConvergenceCriteria;
  /** ビルドコマンドの上書き (既定: npm run build) */
  buildCommand?: string[];
  /** チェックポイントを git commit ライクに保存するか (既定: true) */
  enableCheckpoints?: boolean;
  /** デバッグログ出力 */
  verbose?: boolean;
}

// ========================================
// オーケストレーター本体
// ========================================

/**
 * Generator-Verifier-Refiner ループのオーケストレーター。
 * `run()` を呼ぶと収束または maxIterations 到達まで自動で回す。
 */
export class GvrOrchestrator {
  private verifier: Verifier;
  private refiner: Refiner;
  private playtester: AutoPlaytester;
  private convergenceDetector: ConvergenceDetector;

  constructor() {
    this.verifier = new Verifier();
    this.refiner = new Refiner();
    this.playtester = new AutoPlaytester();
    this.convergenceDetector = new ConvergenceDetector();
  }

  /**
   * GVR ループを実行する。
   * 失敗時も status='failed' で GvrSession を返す (例外を上に投げない)。
   */
  async run(opts: GvrRunOptions): Promise<GvrSession> {
    // ---- デフォルト値の確定 ----
    const targetScore = opts.targetScore ?? 90;
    const maxIterations = opts.maxIterations ?? 10;
    const playtestDurationSec = opts.playtestDurationSec ?? 60;
    const playtestStrategy = opts.playtestStrategy ?? 'random';
    const llmProvider = opts.llmProvider ?? 'claude';
    const enableCheckpoints = opts.enableCheckpoints !== false;
    const verbose = opts.verbose === true;
    const convergenceCriteria: ConvergenceCriteria = opts.convergenceCriteria ?? {
      scoreImprovementThreshold: 1.5,
      stableIterationsRequired: 2,
      maxRegressionAllowed: -3,
    };

    // ---- セッション初期化 ----
    const session: GvrSession = {
      sessionId: this.generateSessionId(),
      projectDir: path.resolve(opts.projectDir),
      targetQualityScore: targetScore,
      maxIterations,
      iterationHistory: [],
      status: 'running',
      startedAt: new Date(),
    };

    this.log(verbose, `GVR セッション開始: id=${session.sessionId} target=${targetScore} max=${maxIterations}`);

    // プロジェクトディレクトリ存在チェック
    try {
      const stat = await fs.stat(session.projectDir);
      if (!stat.isDirectory()) {
        session.status = 'failed';
        session.stopReason = `プロジェクトディレクトリではありません: ${session.projectDir}`;
        session.finishedAt = new Date();
        return session;
      }
    } catch (err) {
      session.status = 'failed';
      session.stopReason = `プロジェクトディレクトリが存在しません: ${session.projectDir}`;
      session.finishedAt = new Date();
      return session;
    }

    // ---- メインループ ----
    for (let i = 1; i <= maxIterations; i++) {
      const iterStart = Date.now();
      const iter: GvrIteration = {
        iteration: i,
        generatedAt: new Date(),
        qualityScore: 0,
        improvementsRequested: [],
        durationMs: 0,
      };

      try {
        // ---- 1. 自動プレイテスト ----
        this.log(verbose, `[iter ${i}] 自動プレイテスト開始 (${playtestStrategy}, ${playtestDurationSec}s)`);
        let playtest: AutoPlaytestSession | null = null;
        const playRes = await Promise.allSettled([
          this.playtester.play({
            projectDir: session.projectDir,
            durationSec: playtestDurationSec,
            strategy: playtestStrategy,
          }),
        ]);
        if (playRes[0].status === 'fulfilled') {
          playtest = playRes[0].value;
        } else {
          iter.errorMessage = `プレイテスト失敗: ${this.errMsg(playRes[0].reason)}`;
          this.log(verbose, `[iter ${i}] ${iter.errorMessage}`);
        }

        // ---- 2. Game Quality Fortress 採点 ----
        this.log(verbose, `[iter ${i}] 品質計測中`);
        const verifyResult: VerifierResult = await this.verifier.measure({
          projectDir: session.projectDir,
          playtest: playtest ?? undefined,
          metricsPath: opts.qualityFortressPath,
        });
        iter.qualityScore = verifyResult.totalScore;
        this.log(verbose, `[iter ${i}] スコア=${verifyResult.totalScore} ランク=${verifyResult.rank}`);

        // ---- 3. 目標達成チェック ----
        if (verifyResult.totalScore >= targetScore) {
          iter.durationMs = Date.now() - iterStart;
          session.iterationHistory.push(iter);
          opts.onIterationComplete?.(iter);
          session.status = 'converged';
          session.finalScore = verifyResult.totalScore;
          session.stopReason = `目標スコア ${targetScore} に到達 (${verifyResult.totalScore})`;
          break;
        }

        // ---- 4. ImprovementRequest 生成 (severity 高い順に最大3件) ----
        const top = verifyResult.prioritized.slice(0, 3);
        iter.improvementsRequested = top;

        if (top.length === 0) {
          // 改善要望が無い (= 全軸高得点だが目標未達) はまれ。停止。
          iter.durationMs = Date.now() - iterStart;
          session.iterationHistory.push(iter);
          opts.onIterationComplete?.(iter);
          session.status = 'converged';
          session.finalScore = verifyResult.totalScore;
          session.stopReason = '改善要望が0件 — 各軸とも閾値以上のため停止';
          break;
        }

        // ---- 5. チェックポイント保存 (ロールバック用) ----
        if (enableCheckpoints) {
          const cpId = await this.saveCheckpoint(session, i).catch((e) => {
            this.log(verbose, `[iter ${i}] チェックポイント保存失敗: ${this.errMsg(e)}`);
            return undefined;
          });
          iter.checkpointId = cpId;
        }

        // ---- 6. Refiner で各 ImprovementRequest を適用 ----
        const filesChangedSet = new Set<string>();
        let linesAdded = 0;
        let linesRemoved = 0;
        for (const req of top) {
          this.log(verbose, `[iter ${i}] 改善適用: ${req.category} (sev=${req.severity})`);
          const refineResults = await Promise.allSettled([
            this.refiner.apply({
              projectDir: session.projectDir,
              request: req,
              llmProvider,
            }),
          ]);
          if (refineResults[0].status === 'fulfilled') {
            const r: RefinerResult = refineResults[0].value;
            r.filesModified.forEach((f) => filesChangedSet.add(f));
            linesAdded += r.linesAdded ?? 0;
            linesRemoved += r.linesRemoved ?? 0;
          } else {
            this.log(verbose, `[iter ${i}] Refiner 失敗: ${this.errMsg(refineResults[0].reason)}`);
          }
        }
        iter.diff = {
          filesChanged: [...filesChangedSet],
          linesAdded,
          linesRemoved,
        };

        // ---- 7. ビルド+疎通確認 ----
        const buildOk = await this.runBuild(session.projectDir, opts.buildCommand, verbose);
        if (!buildOk) {
          this.log(verbose, `[iter ${i}] ビルド失敗 — ロールバック検討`);
          iter.errorMessage = 'ビルド失敗';
          // 直近チェックポイントへロールバック
          if (enableCheckpoints && iter.checkpointId) {
            await this.rollbackToCheckpoint(session, iter.checkpointId).catch((e) => {
              this.log(verbose, `[iter ${i}] ロールバック失敗: ${this.errMsg(e)}`);
            });
          }
        }

        // ---- 8. 収束判定 ----
        iter.durationMs = Date.now() - iterStart;
        session.iterationHistory.push(iter);
        opts.onIterationComplete?.(iter);

        const convResult = this.convergenceDetector.evaluate(session.iterationHistory, convergenceCriteria);
        if (convResult.converged) {
          session.status = 'converged';
          session.finalScore = iter.qualityScore;
          session.stopReason = `収束判定: ${convResult.reason}`;
          break;
        }
        if (convResult.shouldRollback && enableCheckpoints) {
          this.log(verbose, `[iter ${i}] 悪化検知 — 前イテレーションへロールバック`);
          const prev = session.iterationHistory[session.iterationHistory.length - 2];
          if (prev?.checkpointId) {
            await this.rollbackToCheckpoint(session, prev.checkpointId).catch(() => undefined);
          }
        }
      } catch (err) {
        iter.errorMessage = `イテレーション例外: ${this.errMsg(err)}`;
        iter.durationMs = Date.now() - iterStart;
        session.iterationHistory.push(iter);
        opts.onIterationComplete?.(iter);
        this.log(verbose, `[iter ${i}] 例外発生: ${iter.errorMessage}`);
        // 致命的でなければ続行 (LLM一時障害など)
      }
    }

    // ---- 終了処理 ----
    if (session.status === 'running') {
      session.status = 'maxIterations';
      session.finalScore = session.iterationHistory.at(-1)?.qualityScore;
      session.stopReason = `最大イテレーション数 ${maxIterations} に到達`;
    }
    session.finishedAt = new Date();
    this.log(
      verbose,
      `GVR セッション終了: status=${session.status} score=${session.finalScore} iterations=${session.iterationHistory.length}`,
    );
    return session;
  }

  // ========================================
  // 内部ユーティリティ
  // ========================================

  /** セッションID生成 (タイムスタンプ + ランダム16文字) */
  private generateSessionId(): string {
    const ts = Date.now().toString(36);
    const rand = crypto.randomBytes(8).toString('hex');
    return `gvr-${ts}-${rand}`;
  }

  /** エラーオブジェクトを文字列化 */
  private errMsg(e: unknown): string {
    if (e instanceof Error) return e.message;
    if (typeof e === 'string') return e;
    try {
      return JSON.stringify(e);
    } catch {
      return String(e);
    }
  }

  /** 詳細ログ (verbose 時のみ stderr に出力) */
  private log(verbose: boolean, msg: string): void {
    if (!verbose) return;
    // 副作用最小化のため stderr へ。
    process.stderr.write(`[gvr] ${msg}\n`);
  }

  /**
   * チェックポイント保存。
   * git が使えるリポジトリなら `git stash create` ライクに記録。
   * 使えなければ .gvr-checkpoints/<id>/ にファイル一覧と内容をコピー。
   */
  private async saveCheckpoint(session: GvrSession, iteration: number): Promise<string> {
    const cpId = `cp-${iteration}-${crypto.randomBytes(4).toString('hex')}`;
    const cpDir = path.join(session.projectDir, '.gvr-checkpoints', cpId);
    try {
      await fs.mkdir(cpDir, { recursive: true });
      // git があれば diff を保存
      try {
        const { stdout } = await execFileAsync('git', ['-C', session.projectDir, 'diff', 'HEAD'], {
          maxBuffer: 50 * 1024 * 1024,
        });
        await fs.writeFile(path.join(cpDir, 'patch.diff'), stdout, 'utf8');
      } catch {
        // git 非対応プロジェクト: マーカーのみ残す
        await fs.writeFile(path.join(cpDir, 'NO_GIT.txt'), 'fallback checkpoint\n', 'utf8');
      }
      const meta = {
        sessionId: session.sessionId,
        iteration,
        savedAt: new Date().toISOString(),
      };
      await fs.writeFile(path.join(cpDir, 'meta.json'), JSON.stringify(meta, null, 2), 'utf8');
      return cpId;
    } catch (e) {
      throw new Error(`チェックポイント保存失敗: ${this.errMsg(e)}`);
    }
  }

  /**
   * チェックポイントへロールバック。
   * git があれば apply -R、無ければ何もしない (保存物の復元は scope 外)。
   */
  private async rollbackToCheckpoint(session: GvrSession, checkpointId: string): Promise<void> {
    const cpDir = path.join(session.projectDir, '.gvr-checkpoints', checkpointId);
    const patchPath = path.join(cpDir, 'patch.diff');
    try {
      const exists = await fs.stat(patchPath).then(() => true).catch(() => false);
      if (!exists) return;
      // 現在の差分を git apply -R で巻き戻す
      await execFileAsync('git', ['-C', session.projectDir, 'apply', '-R', patchPath], {
        maxBuffer: 50 * 1024 * 1024,
      }).catch(() => {
        // 既に巻き戻し済みなどで失敗してもセッションは続行
      });
    } catch (e) {
      // ロールバック失敗はログに残すだけで停止しない
    }
  }

  /**
   * ビルド+疎通確認。
   * package.json があれば `npm run build` を試す。
   * ビルドコマンドが指定されていればそれを使用。
   * 成功なら true、失敗なら false。
   */
  private async runBuild(projectDir: string, buildCommand: string[] | undefined, verbose: boolean): Promise<boolean> {
    const cmd = buildCommand ?? ['npm', 'run', 'build'];
    try {
      const pkgPath = path.join(projectDir, 'package.json');
      const pkgExists = await fs.stat(pkgPath).then(() => true).catch(() => false);
      if (!pkgExists) {
        // package.json が無いプロジェクト (純HTML+JS) はビルド省略 = OK
        return true;
      }
      const [bin, ...args] = cmd;
      await execFileAsync(bin, args, {
        cwd: projectDir,
        maxBuffer: 100 * 1024 * 1024,
        timeout: 5 * 60 * 1000,
      });
      return true;
    } catch (e) {
      this.log(verbose, `ビルドコマンド失敗: ${this.errMsg(e)}`);
      return false;
    }
  }
}

// ========================================
// 便利関数
// ========================================

/**
 * 単発呼び出し用の薄いラッパー。
 * `import { runGvr } from '...'` 形式で簡単に使える。
 */
export async function runGvr(opts: GvrRunOptions): Promise<GvrSession> {
  const orchestrator = new GvrOrchestrator();
  return orchestrator.run(opts);
}
