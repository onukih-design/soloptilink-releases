/**
 * report_generator.ts
 * 責務: GVR セッション全体を Markdown レポートに変換する。
 *   セッション概要 / イテレーション別品質遷移 ASCII グラフ /
 *   各 iteration で適用した改善 / 最終品質スコア / 残課題 /
 *   推奨次アクション を日本語で構成。
 *   外部依存なし、純粋関数的。Node.js / ブラウザ両環境で動作。
 *   ダミー値はなく、セッション履歴そのものから出力する。
 */

import type {
  GvrSession,
  GvrIteration,
  ImprovementRequest,
  ImprovementSeverity,
  ImprovementCategory,
} from './orchestrator';

// ========================================
// 公開関数
// ========================================

/**
 * GVR セッションから Markdown レポートを生成する。
 */
export function generateGvrReport(session: GvrSession): string {
  const lines: string[] = [];

  lines.push(...renderHeader(session));
  lines.push('');
  lines.push(...renderOverview(session));
  lines.push('');
  lines.push(...renderProgressChart(session));
  lines.push('');
  lines.push(...renderIterationDetails(session));
  lines.push('');
  lines.push(...renderRemainingIssues(session));
  lines.push('');
  lines.push(...renderRecommendation(session));
  lines.push('');
  lines.push('---');
  lines.push(
    `_本レポートは Generator-Verifier-Refiner ループ (SoloptiLinkAI v2.0) により ${new Date().toISOString()} に自動生成されました_`,
  );

  return lines.join('\n');
}

// ========================================
// 各セクションの描画
// ========================================

/** タイトル/メタデータ */
function renderHeader(session: GvrSession): string[] {
  const status = formatStatus(session.status);
  return [
    `# GVR セッションレポート: ${session.sessionId}`,
    '',
    `- **対象プロジェクト**: \`${session.projectDir}\``,
    `- **目標スコア**: ${session.targetQualityScore} 点`,
    `- **最大イテレーション数**: ${session.maxIterations}`,
    `- **状態**: ${status}`,
    `- **最終スコア**: ${formatScore(session.finalScore)} 点`,
    `- **開始日時**: ${formatDate(session.startedAt)}`,
    `- **終了日時**: ${formatDate(session.finishedAt)}`,
    `- **所要時間**: ${formatDuration(session.startedAt, session.finishedAt)}`,
    `- **停止理由**: ${session.stopReason ?? '(未設定)'}`,
  ];
}

/** 概要 (KPI) */
function renderOverview(session: GvrSession): string[] {
  const hist = session.iterationHistory;
  if (hist.length === 0) {
    return ['## 概要', '', 'イテレーションが1回も実行されませんでした。'];
  }
  const first = hist[0].qualityScore;
  const last = hist[hist.length - 1].qualityScore;
  const totalGain = last - first;
  const max = hist.reduce((a, b) => (a.qualityScore >= b.qualityScore ? a : b));
  const totalFilesChanged = new Set<string>();
  let totalLinesAdded = 0;
  let totalLinesRemoved = 0;
  for (const it of hist) {
    if (!it.diff) continue;
    it.diff.filesChanged.forEach((f) => totalFilesChanged.add(f));
    totalLinesAdded += it.diff.linesAdded;
    totalLinesRemoved += it.diff.linesRemoved;
  }
  return [
    '## 概要',
    '',
    `- **実行イテレーション数**: ${hist.length}`,
    `- **初回スコア**: ${first.toFixed(2)} 点`,
    `- **最終スコア**: ${last.toFixed(2)} 点`,
    `- **総改善幅**: ${formatDeltaSign(totalGain)} 点`,
    `- **最高スコア**: ${max.qualityScore.toFixed(2)} 点 (iter ${max.iteration})`,
    `- **変更ファイル累計**: ${totalFilesChanged.size} 件`,
    `- **追加行 / 削除行**: +${totalLinesAdded} / -${totalLinesRemoved}`,
  ];
}

/** ASCII グラフ (スコア遷移) */
function renderProgressChart(session: GvrSession): string[] {
  const hist = session.iterationHistory;
  if (hist.length === 0) return ['## 品質遷移グラフ', '', '_データなし_'];

  const lines: string[] = ['## 品質遷移グラフ', '', '```'];
  const chart = drawAsciiChart(
    hist.map((h) => h.qualityScore),
    {
      width: Math.max(20, Math.min(80, hist.length * 4)),
      height: 12,
      targetLine: session.targetQualityScore,
    },
  );
  lines.push(chart);
  lines.push('```');
  lines.push('');
  lines.push('| iter | スコア | Δ | 所要 (ms) | ファイル数 | エラー |');
  lines.push('|------|--------|---|-----------|-----------|--------|');
  let prev = hist[0].qualityScore;
  for (const it of hist) {
    const delta = it.iteration === 1 ? 0 : it.qualityScore - prev;
    lines.push(
      `| ${it.iteration} | ${it.qualityScore.toFixed(2)} | ${formatDeltaSign(delta)} | ${it.durationMs} | ${it.diff?.filesChanged.length ?? 0} | ${it.errorMessage ? '⚠' : ''} |`,
    );
    prev = it.qualityScore;
  }
  return lines;
}

/** 各イテレーションの詳細 */
function renderIterationDetails(session: GvrSession): string[] {
  const hist = session.iterationHistory;
  if (hist.length === 0) return [];
  const lines: string[] = ['## イテレーション別の適用改善'];
  for (const it of hist) {
    lines.push('');
    lines.push(`### イテレーション ${it.iteration}`);
    lines.push('');
    lines.push(`- **スコア**: ${it.qualityScore.toFixed(2)} 点`);
    lines.push(`- **開始日時**: ${formatDate(it.generatedAt)}`);
    lines.push(`- **所要時間**: ${it.durationMs} ms`);
    if (it.checkpointId) lines.push(`- **チェックポイント**: \`${it.checkpointId}\``);
    if (it.diff) {
      lines.push(
        `- **差分**: ${it.diff.filesChanged.length} ファイル / +${it.diff.linesAdded} / -${it.diff.linesRemoved}`,
      );
    }
    if (it.errorMessage) lines.push(`- **エラー**: ${it.errorMessage}`);
    if (it.improvementsRequested.length === 0) {
      lines.push('');
      lines.push('改善要望なし。');
    } else {
      lines.push('');
      lines.push('#### 適用した改善要望');
      lines.push('');
      for (const req of it.improvementsRequested) {
        lines.push(renderRequestBullet(req));
      }
    }
    if (it.diff && it.diff.filesChanged.length > 0) {
      lines.push('');
      lines.push('#### 変更ファイル');
      for (const f of it.diff.filesChanged) {
        lines.push(`  - \`${f}\``);
      }
    }
  }
  return lines;
}

/** 残課題 (最終イテレーションの未達軸) */
function renderRemainingIssues(session: GvrSession): string[] {
  const hist = session.iterationHistory;
  if (hist.length === 0) return [];
  const last = hist[hist.length - 1];
  const remaining = last.improvementsRequested.filter(
    (r) => r.currentScore < r.targetScore,
  );
  const lines: string[] = ['## 残課題'];
  if (remaining.length === 0) {
    lines.push('');
    lines.push('最終イテレーション時点で残課題は記録されていません。');
    return lines;
  }
  lines.push('');
  for (const r of remaining) {
    lines.push(renderRequestBullet(r));
  }
  return lines;
}

/** 推奨次アクション */
function renderRecommendation(session: GvrSession): string[] {
  const lines: string[] = ['## 推奨次アクション', ''];
  const target = session.targetQualityScore;
  const final = session.finalScore ?? 0;
  switch (session.status) {
    case 'converged':
      if (final >= target) {
        lines.push(`目標 ${target} 点に到達 (${final.toFixed(2)} 点)。本セッションは合格レベル。`);
        lines.push('- 残課題があれば人手でレビューし、ベータ配信 → ユーザーテストへ進む。');
        lines.push('- 必要なら別軸を狙って 2 周目の GVR を回す。');
      } else {
        lines.push(
          `収束したが目標未達 (${final.toFixed(2)} / ${target} 点)。プロンプト or 戦略変更を推奨。`,
        );
        lines.push('- LLM プロバイダを切り替える (claude → gpt4 等)');
        lines.push('- プレイテスト戦略を `agent_planned` / `expert` に変更');
        lines.push('- 不足軸に対する手動改善を 1 段挟んでから再実行');
      }
      break;
    case 'maxIterations':
      lines.push(
        `最大イテレーション数 ${session.maxIterations} に到達 (最終 ${final.toFixed(2)} 点)。改善幅がまだ残る可能性。`,
      );
      lines.push('- `maxIterations` を増やして再実行');
      lines.push('- 一度コードレビューを挟んで局所最適から脱出');
      break;
    case 'failed':
      lines.push('セッションが失敗終了しました。停止理由を確認してください。');
      if (session.stopReason) lines.push(`- 停止理由: ${session.stopReason}`);
      lines.push('- プロジェクトパス / ビルドコマンド / LLM API キーを再確認');
      break;
    default:
      lines.push('現状継続中、もしくは状態不明。');
  }
  return lines;
}

// ========================================
// レンダリングヘルパ
// ========================================

/** 改善要望1件を箇条書きで描画 */
function renderRequestBullet(req: ImprovementRequest): string {
  const sevBadge = formatSeverity(req.severity);
  const catLabel = formatCategory(req.category);
  return [
    `- ${sevBadge} **${catLabel}** (${req.currentScore.toFixed(2)} → 目標 ${req.targetScore.toFixed(2)})`,
    `    - 概要: ${req.description}`,
    `    - 修正方針: ${req.suggestedFix}`,
    `    - 影響ファイル: ${req.affectedFiles.length === 0 ? '(未特定)' : req.affectedFiles.map((f) => `\`${f}\``).join(', ')}`,
  ].join('\n');
}

/** ステータスを日本語ラベルに変換 */
function formatStatus(s: GvrSession['status']): string {
  switch (s) {
    case 'running':
      return '稼働中';
    case 'converged':
      return '収束';
    case 'maxIterations':
      return '最大イテレーション数到達';
    case 'failed':
      return '失敗';
    default:
      return s;
  }
}

/** カテゴリの日本語化 */
function formatCategory(c: ImprovementCategory): string {
  const map: Record<ImprovementCategory, string> = {
    fps: 'FPS安定性',
    input_latency: '入力遅延',
    load_time: 'ロード時間',
    balance: 'ゲームバランス',
    replayability: 'リプレイ性',
    onboarding: 'オンボーディング',
    av_consistency: 'AV統一感',
    ui_ux: 'UI/UX',
    accessibility: 'アクセシビリティ',
    fun: '楽しさFUN',
  };
  return map[c] ?? c;
}

/** severity をバッジ風文字列に変換 */
function formatSeverity(s: ImprovementSeverity): string {
  switch (s) {
    case 'critical':
      return '[CRITICAL]';
    case 'high':
      return '[HIGH]';
    case 'medium':
      return '[MEDIUM]';
    case 'low':
      return '[LOW]';
    default:
      return `[${s}]`;
  }
}

/** スコアの表記揺れ吸収 */
function formatScore(v: number | undefined): string {
  if (v === undefined || Number.isNaN(v)) return 'N/A';
  return v.toFixed(2);
}

/** Date を可読文字列に */
function formatDate(d: Date | undefined): string {
  if (!d) return 'N/A';
  try {
    return d.toISOString();
  } catch {
    return String(d);
  }
}

/** 2点の Date 間の所要時間を人間可読化 */
function formatDuration(start: Date | undefined, end: Date | undefined): string {
  if (!start || !end) return 'N/A';
  const ms = end.getTime() - start.getTime();
  if (ms < 1000) return `${ms}ms`;
  const sec = ms / 1000;
  if (sec < 60) return `${sec.toFixed(1)}s`;
  const min = sec / 60;
  if (min < 60) return `${min.toFixed(1)}min`;
  const h = min / 60;
  return `${h.toFixed(2)}h`;
}

/** +/- 付きの delta 表記 */
function formatDeltaSign(d: number): string {
  if (Number.isNaN(d)) return 'N/A';
  if (d >= 0) return `+${d.toFixed(2)}`;
  return d.toFixed(2);
}

/**
 * シンプルな ASCII ライングラフを描画。
 * 目標ラインがあれば横線で重ねる。
 */
function drawAsciiChart(
  series: number[],
  opts: { width: number; height: number; targetLine?: number },
): string {
  if (series.length === 0) return '(no data)';
  const w = Math.max(8, opts.width | 0);
  const h = Math.max(4, opts.height | 0);
  const min = 0;
  const max = Math.max(100, opts.targetLine ?? 100, Math.max(...series));
  const grid: string[][] = Array.from({ length: h }, () => Array(w).fill(' '));

  // 系列の x 軸をリサンプリング
  const xOf = (i: number): number =>
    Math.round((i / Math.max(1, series.length - 1)) * (w - 1));
  const yOf = (v: number): number => {
    const t = (v - min) / Math.max(1e-9, max - min);
    return Math.max(0, Math.min(h - 1, h - 1 - Math.round(t * (h - 1))));
  };

  // 目標ラインを薄い破線で
  if (typeof opts.targetLine === 'number') {
    const y = yOf(opts.targetLine);
    for (let x = 0; x < w; x++) grid[y][x] = x % 2 === 0 ? '-' : ' ';
  }

  // データプロット
  let prevX = -1;
  let prevY = -1;
  for (let i = 0; i < series.length; i++) {
    const x = xOf(i);
    const y = yOf(series[i]);
    grid[y][x] = '*';
    // 前点と現点を直線で簡易結ぶ (バーチャートではないので分割線で)
    if (prevX >= 0) {
      const dx = x - prevX;
      const dy = y - prevY;
      const steps = Math.max(Math.abs(dx), Math.abs(dy));
      for (let s = 1; s < steps; s++) {
        const xs = Math.round(prevX + (dx * s) / steps);
        const ys = Math.round(prevY + (dy * s) / steps);
        if (grid[ys][xs] === ' ') grid[ys][xs] = '.';
      }
    }
    prevX = x;
    prevY = y;
  }

  // Y軸ラベル付き出力
  const out: string[] = [];
  for (let y = 0; y < h; y++) {
    const label = Math.round(max - ((max - min) * y) / (h - 1));
    out.push(`${String(label).padStart(3, ' ')} | ${grid[y].join('')}`);
  }
  out.push(`    +${'-'.repeat(w)}`);
  out.push(`     iter 1 ${'-'.repeat(Math.max(0, w - 14))}> iter ${series.length}`);
  return out.join('\n');
}
