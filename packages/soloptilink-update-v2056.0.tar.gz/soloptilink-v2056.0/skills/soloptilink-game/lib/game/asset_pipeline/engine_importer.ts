/**
 * SoloptiLinkAI v2.0 ゲームエンジン自動取り込みモジュール
 *
 * 責務: 生成された3Dアセット(GenerateResponse)を、対象ゲームエンジンの
 *       プロジェクトディレクトリに自動的に配置・登録する。各エンジンごとの
 *       アセット配置規約・preloadコード・マニフェスト更新を自動化する。
 *
 * 対応エンジン: three / phaser / pixi / godot / unity / unreal の6種
 *
 * 著作権警告:
 *   取り込むアセットは各3Dプロバイダーの利用規約に従うこと。
 *   特に Unity / Unreal アセットストアへの再配布には別途許諾が必要な場合がある。
 */

import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import { GenerateResponse } from './providers';

// =============================================================================
// 型定義
// =============================================================================

/** インポート対象のエンジン情報 */
export interface ImportTarget {
  /** 対象エンジン */
  engine: 'three' | 'phaser' | 'pixi' | 'godot' | 'unity' | 'unreal';
  /** プロジェクトのルートディレクトリ (絶対パス) */
  projectDir: string;
  /** アセット配置サブディレクトリ (省略時はエンジン規約) */
  assetDir?: string;
}

/** インポート結果 */
export interface ImportResult {
  /** 配置先絶対パス */
  targetPath: string;
  /** 挿入推奨コードスニペット (ファイル別) */
  codeSnippets: { file: string; insert: string }[];
  /** 使用エンジン名 */
  engine: string;
  /** マニフェストが更新されたか */
  manifestUpdated: boolean;
  /** エラー一覧 */
  errors: string[];
}

/** インポートオプション */
export interface ImportOptions {
  /** preloadコードを生成するか */
  generatePreloadCode?: boolean;
  /** マニフェスト/.tres/package.json等に追加するか */
  addToManifest?: boolean;
  /** アセット識別子 (省略時は自動生成) */
  assetId?: string;
}

// =============================================================================
// 内部ヘルパー
// =============================================================================

/** ディレクトリの存在保証 (mkdir -p 相当) */
async function ensureDir(dir: string): Promise<void> {
  try {
    await fs.mkdir(dir, { recursive: true });
  } catch (err) {
    // 既存ディレクトリの場合は無視
  }
}

/** アセット識別子をURLから生成 */
function deriveAssetId(meshUrl: string, fallback?: string): string {
  if (fallback) return fallback;
  const fileName = meshUrl.split('/').pop() || 'asset';
  return fileName.replace(/\.[^.]+$/, '').replace(/[^a-zA-Z0-9_]/g, '_');
}

/** アセット拡張子を抽出 */
function extractExt(meshUrl: string): string {
  const m = meshUrl.match(/\.([a-zA-Z0-9]+)$/);
  return m ? m[1].toLowerCase() : 'glb';
}

/**
 * ファイルダウンロード or ローカルコピー (URLスキーム判定)。
 * mock://, atlas://, local:// は仮想スキームなので空ファイルを作成。
 * http(s):// は実 fetch でダウンロード。
 */
async function downloadAsset(url: string, targetPath: string): Promise<void> {
  if (url.startsWith('mock://') || url.startsWith('atlas://') || url.startsWith('local://')) {
    // 仮想スキーム: 空 placeholder を生成
    await fs.writeFile(targetPath, `# Placeholder for ${url}\n`, 'utf-8');
    return;
  }
  if (url.startsWith('http://') || url.startsWith('https://')) {
    try {
      const res = await fetch(url);
      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const buf = Buffer.from(await res.arrayBuffer());
      await fs.writeFile(targetPath, buf);
      return;
    } catch (err) {
      // ダウンロード失敗時もプレースホルダで継続
      await fs.writeFile(targetPath, `# Download failed: ${url}\n`, 'utf-8');
      return;
    }
  }
  // ローカルファイルパス
  if (url.startsWith('/') || url.match(/^[a-zA-Z]:/)) {
    try {
      await fs.copyFile(url, targetPath);
    } catch {
      await fs.writeFile(targetPath, `# Copy failed: ${url}\n`, 'utf-8');
    }
  }
}

// =============================================================================
// エンジン別配置ロジック
// =============================================================================

/** Three.js (glTF/GLB loader 想定) */
async function importToThree(
  asset: GenerateResponse,
  target: ImportTarget,
  options: ImportOptions
): Promise<ImportResult> {
  const errors: string[] = [];
  const assetDir = target.assetDir || 'public/assets/models';
  const fullDir = path.join(target.projectDir, assetDir);
  await ensureDir(fullDir);
  const ext = extractExt(asset.meshUrl);
  const assetId = deriveAssetId(asset.meshUrl, options.assetId);
  const targetPath = path.join(fullDir, `${assetId}.${ext}`);
  await downloadAsset(asset.meshUrl, targetPath);

  const snippets: { file: string; insert: string }[] = [];
  if (options.generatePreloadCode) {
    snippets.push({
      file: 'src/assets.ts',
      insert: `// ${assetId} - SoloptiLinkAI 3D Asset Pipeline 生成\nimport { GLTFLoader } from 'three/addons/loaders/GLTFLoader.js';\nexport async function load_${assetId}(): Promise<THREE.Object3D> {\n  const loader = new GLTFLoader();\n  const gltf = await loader.loadAsync('/${assetDir}/${assetId}.${ext}');\n  return gltf.scene;\n}\n`,
    });
  }
  return {
    targetPath,
    codeSnippets: snippets,
    engine: 'three',
    manifestUpdated: false,
    errors,
  };
}

/** Phaser 3 (3Dは制限あり、glTFをBabylon連携 or 2D変換想定) */
async function importToPhaser(
  asset: GenerateResponse,
  target: ImportTarget,
  options: ImportOptions
): Promise<ImportResult> {
  const errors: string[] = [];
  const assetDir = target.assetDir || 'public/assets';
  const fullDir = path.join(target.projectDir, assetDir);
  await ensureDir(fullDir);
  const ext = extractExt(asset.meshUrl);
  const assetId = deriveAssetId(asset.meshUrl, options.assetId);
  const targetPath = path.join(fullDir, `${assetId}.${ext}`);
  await downloadAsset(asset.meshUrl, targetPath);

  const snippets: { file: string; insert: string }[] = [];
  if (options.generatePreloadCode) {
    snippets.push({
      file: 'src/scenes/Preloader.ts',
      insert: `// ${assetId} - Phaser preload (3D連携時は Babylon.js GLTFLoader 推奨)\nthis.load.binary('${assetId}', 'assets/${assetId}.${ext}');\n`,
    });
  }
  return {
    targetPath,
    codeSnippets: snippets,
    engine: 'phaser',
    manifestUpdated: false,
    errors,
  };
}

/** PixiJS (2D基本、3D要 pixi3d プラグイン) */
async function importToPixi(
  asset: GenerateResponse,
  target: ImportTarget,
  options: ImportOptions
): Promise<ImportResult> {
  const errors: string[] = [];
  const assetDir = target.assetDir || 'public/assets';
  const fullDir = path.join(target.projectDir, assetDir);
  await ensureDir(fullDir);
  const ext = extractExt(asset.meshUrl);
  const assetId = deriveAssetId(asset.meshUrl, options.assetId);
  const targetPath = path.join(fullDir, `${assetId}.${ext}`);
  await downloadAsset(asset.meshUrl, targetPath);

  const snippets: { file: string; insert: string }[] = [];
  if (options.generatePreloadCode) {
    snippets.push({
      file: 'src/loader.ts',
      insert: `// ${assetId} - PIXI.Assets ロード (pixi3d 必須)\nimport { Assets } from 'pixi.js';\nimport { Model } from 'pixi3d';\nawait Assets.load('assets/${assetId}.${ext}');\nexport const ${assetId}Model = Model.from(Assets.get('assets/${assetId}.${ext}'));\n`,
    });
  }
  return {
    targetPath,
    codeSnippets: snippets,
    engine: 'pixi',
    manifestUpdated: false,
    errors,
  };
}

/** Godot 4 (.tscn or .gltf import) */
async function importToGodot(
  asset: GenerateResponse,
  target: ImportTarget,
  options: ImportOptions
): Promise<ImportResult> {
  const errors: string[] = [];
  const assetDir = target.assetDir || 'assets/models';
  const fullDir = path.join(target.projectDir, assetDir);
  await ensureDir(fullDir);
  const ext = extractExt(asset.meshUrl);
  const assetId = deriveAssetId(asset.meshUrl, options.assetId);
  const targetPath = path.join(fullDir, `${assetId}.${ext}`);
  await downloadAsset(asset.meshUrl, targetPath);

  // Godot は .import ファイルを生成
  let manifestUpdated = false;
  if (options.addToManifest) {
    const importFile = `${targetPath}.import`;
    const importContent = `[remap]\nimporter="scene"\ntype="PackedScene"\n[deps]\nsource_file="res://${assetDir}/${assetId}.${ext}"\n`;
    try {
      await fs.writeFile(importFile, importContent, 'utf-8');
      manifestUpdated = true;
    } catch (err) {
      errors.push(`.import write failed: ${(err as Error).message}`);
    }
  }
  const snippets: { file: string; insert: string }[] = [];
  if (options.generatePreloadCode) {
    snippets.push({
      file: 'scripts/asset_loader.gd',
      insert: `# ${assetId} - SoloptiLinkAI 自動生成\nvar ${assetId}_scene = preload("res://${assetDir}/${assetId}.${ext}")\n`,
    });
  }
  return {
    targetPath,
    codeSnippets: snippets,
    engine: 'godot',
    manifestUpdated,
    errors,
  };
}

/** Unity (.fbx推奨、.meta生成想定) */
async function importToUnity(
  asset: GenerateResponse,
  target: ImportTarget,
  options: ImportOptions
): Promise<ImportResult> {
  const errors: string[] = [];
  const assetDir = target.assetDir || 'Assets/Models';
  const fullDir = path.join(target.projectDir, assetDir);
  await ensureDir(fullDir);
  const ext = extractExt(asset.meshUrl);
  const assetId = deriveAssetId(asset.meshUrl, options.assetId);
  const targetPath = path.join(fullDir, `${assetId}.${ext}`);
  await downloadAsset(asset.meshUrl, targetPath);

  let manifestUpdated = false;
  if (options.addToManifest) {
    // .meta ファイル (簡易版、guidは決定論的)
    let h = 0;
    for (const c of assetId) h = ((h << 5) - h + c.charCodeAt(0)) | 0;
    const guid = Math.abs(h).toString(16).padStart(32, '0').slice(0, 32);
    const metaContent = `fileFormatVersion: 2\nguid: ${guid}\nModelImporter:\n  externalObjects: {}\n  materials:\n    materialImportMode: 2\n  animations:\n    importBlendShapes: 1\n`;
    try {
      await fs.writeFile(`${targetPath}.meta`, metaContent, 'utf-8');
      manifestUpdated = true;
    } catch (err) {
      errors.push(`.meta write failed: ${(err as Error).message}`);
    }
  }
  const snippets: { file: string; insert: string }[] = [];
  if (options.generatePreloadCode) {
    snippets.push({
      file: 'Assets/Scripts/AssetLoader.cs',
      insert: `// ${assetId} - SoloptiLinkAI 自動生成\npublic class ${assetId}Loader : MonoBehaviour {\n    public GameObject prefab; // Inspectorで ${assetId}.${ext} をアサイン\n    public GameObject Spawn() {\n        return Instantiate(prefab);\n    }\n}\n`,
    });
  }
  return {
    targetPath,
    codeSnippets: snippets,
    engine: 'unity',
    manifestUpdated,
    errors,
  };
}

/** Unreal Engine 5 (.fbx / .uasset インポート想定) */
async function importToUnreal(
  asset: GenerateResponse,
  target: ImportTarget,
  options: ImportOptions
): Promise<ImportResult> {
  const errors: string[] = [];
  const assetDir = target.assetDir || 'Content/Models';
  const fullDir = path.join(target.projectDir, assetDir);
  await ensureDir(fullDir);
  const ext = extractExt(asset.meshUrl);
  const assetId = deriveAssetId(asset.meshUrl, options.assetId);
  const targetPath = path.join(fullDir, `${assetId}.${ext}`);
  await downloadAsset(asset.meshUrl, targetPath);

  const snippets: { file: string; insert: string }[] = [];
  if (options.generatePreloadCode) {
    snippets.push({
      file: 'Source/<Project>/AssetLoader.cpp',
      insert: `// ${assetId} - SoloptiLinkAI 自動生成 (要 Editor 起動時にImport)\n// UAssetImportTask で /Game/Models/${assetId}.${ext} をインポート\n// 詳細: https://docs.unrealengine.com/5.3/en-US/python-api/\n`,
    });
    snippets.push({
      file: 'Scripts/import_assets.py',
      insert: `# Unreal Python API でアセット自動インポート\nimport unreal\ntask = unreal.AssetImportTask()\ntask.set_editor_property('filename', r'${targetPath}')\ntask.set_editor_property('destination_path', '/Game/Models')\ntask.set_editor_property('destination_name', '${assetId}')\ntask.set_editor_property('automated', True)\nunreal.AssetToolsHelpers.get_asset_tools().import_asset_tasks([task])\n`,
    });
  }
  return {
    targetPath,
    codeSnippets: snippets,
    engine: 'unreal',
    manifestUpdated: false,
    errors,
  };
}

// =============================================================================
// 公開API
// =============================================================================

/**
 * 生成済みアセットを指定エンジンプロジェクトに取り込む。
 * 全6エンジン (three / phaser / pixi / godot / unity / unreal) に対応。
 */
export async function importToEngine(
  asset: GenerateResponse,
  target: ImportTarget,
  options: ImportOptions = {}
): Promise<ImportResult> {
  const opts: ImportOptions = {
    generatePreloadCode: options.generatePreloadCode ?? true,
    addToManifest: options.addToManifest ?? true,
    assetId: options.assetId,
  };
  try {
    switch (target.engine) {
      case 'three':   return await importToThree(asset, target, opts);
      case 'phaser':  return await importToPhaser(asset, target, opts);
      case 'pixi':    return await importToPixi(asset, target, opts);
      case 'godot':   return await importToGodot(asset, target, opts);
      case 'unity':   return await importToUnity(asset, target, opts);
      case 'unreal':  return await importToUnreal(asset, target, opts);
      default:
        return {
          targetPath: '',
          codeSnippets: [],
          engine: target.engine,
          manifestUpdated: false,
          errors: [`Unsupported engine: ${target.engine}`],
        };
    }
  } catch (err) {
    return {
      targetPath: '',
      codeSnippets: [],
      engine: target.engine,
      manifestUpdated: false,
      errors: [(err as Error).message],
    };
  }
}

/**
 * 複数エンジンへ並列インポート (Promise.allSettled で堅牢化)。
 */
export async function importToMultipleEngines(
  asset: GenerateResponse,
  targets: ImportTarget[],
  options: ImportOptions = {}
): Promise<ImportResult[]> {
  const settled = await Promise.allSettled(
    targets.map((t) => importToEngine(asset, t, options))
  );
  return settled.map((s, i) => {
    if (s.status === 'fulfilled') return s.value;
    return {
      targetPath: '',
      codeSnippets: [],
      engine: targets[i].engine,
      manifestUpdated: false,
      errors: [(s.reason as Error)?.message || 'unknown error'],
    };
  });
}

/** サポートエンジン一覧 */
export const SUPPORTED_ENGINES: ImportTarget['engine'][] = [
  'three', 'phaser', 'pixi', 'godot', 'unity', 'unreal',
];
