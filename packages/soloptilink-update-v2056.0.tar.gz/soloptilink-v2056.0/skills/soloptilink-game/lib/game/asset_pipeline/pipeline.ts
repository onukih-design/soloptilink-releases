/**
 * SoloptiLinkAI v2.0 3Dアセット生成パイプライン オーケストレーター
 *
 * 責務: providers → selector → rigging → lod → atlas → engine_importer の
 *       全工程を1つの runPipeline() で実行し、各工程のエラーは収集しつつ
 *       後段も継続させる(部分成功許容)堅牢なオーケストレーションを提供する。
 *
 * 著作権警告:
 *   本パイプラインで生成された3Dアセット、テクスチャ、スケルトン、LODは
 *   全て使用した各サービス(Tripo3D/Meshy/Stability AI/Rodin/Luma等)の
 *   利用規約に従う。商用利用時は事前に各サービスのライセンスを確認すること。
 */

import {
  Asset3DProvider,
  GenerateRequest,
  GenerateResponse,
} from './providers';
import {
  SelectionCriteria,
  recommendCascade,
} from './provider_selector';
import {
  RigOptions,
  RigResult,
  autoRig,
} from './rigging_pipeline';
import {
  LodConfig,
  LodResult,
  generateLod,
  DEFAULT_LOD_CONFIG,
} from './lod_generator';
import {
  AtlasPackResult,
  packAtlas,
} from './atlas_packer';
import {
  ImportTarget,
  ImportResult,
  importToEngine,
} from './engine_importer';

// =============================================================================
// 型定義
// =============================================================================

/** パイプライン全体の設定 */
export interface PipelineConfig {
  /** アセット生成プロンプト (必須) */
  prompt: string;
  /** プロバイダー選定基準 */
  criteria: SelectionCriteria;
  /** 元GenerateRequestを直接指定する場合 (省略時は prompt + criteria から自動構築) */
  generateRequest?: Partial<GenerateRequest>;
  /** リギング設定 (省略時はリギングしない) */
  rigOptions?: RigOptions;
  /** LOD設定 (省略時はLOD生成しない) */
  lodConfig?: LodConfig;
  /** アトラスパッキングを実行するか */
  packAtlas?: boolean;
  /** アトラス最大サイズ */
  atlasMaxSize?: 4096 | 2048 | 1024;
  /** 取り込み先エンジン (省略時は取り込みなし) */
  importTo?: ImportTarget;
  /** 工程のタイムアウト (ms) */
  timeoutMs?: number;
}

/** パイプライン実行結果 */
export interface PipelineResult {
  /** 生成された基本アセット */
  asset: GenerateResponse;
  /** リギング結果 (リギング実行時のみ) */
  rig?: RigResult;
  /** LOD結果 (LOD実行時のみ) */
  lod?: LodResult;
  /** アトラスパック結果 (実行時のみ) */
  atlas?: AtlasPackResult;
  /** インポート結果 (実行時のみ) */
  importResult?: ImportResult;
  /** 取り込み先パス */
  importPath?: string;
  /** 全工程の総処理時間 (ms) */
  totalDurationMs: number;
  /** 全工程の総コスト (USD) */
  totalCostUSD: number;
  /** 各工程のエラー一覧 (空配列なら全成功) */
  errors: string[];
  /** 工程ごとのステータス */
  stageStatus: {
    generate: 'success' | 'failed' | 'skipped';
    rig: 'success' | 'failed' | 'skipped';
    lod: 'success' | 'failed' | 'skipped';
    atlas: 'success' | 'failed' | 'skipped';
    import: 'success' | 'failed' | 'skipped';
  };
  /** 使用されたプロバイダーチェーン (フォールバック順) */
  providerChain: string[];
}

// =============================================================================
// 内部ヘルパー
// =============================================================================

/** GenerateRequest を config から構築 */
function buildGenerateRequest(config: PipelineConfig): GenerateRequest {
  return {
    prompt: config.prompt,
    style: config.generateRequest?.style,
    category: config.generateRequest?.category,
    outputFormat: config.generateRequest?.outputFormat || 'glb',
    targetPolygonCount: config.generateRequest?.targetPolygonCount || 10000,
    withTextures: config.generateRequest?.withTextures ?? true,
    referenceImageUrl: config.generateRequest?.referenceImageUrl,
  };
}

/**
 * カスケード生成: 1次プロバイダー失敗時に2次・3次へフォールバック。
 * MockProvider が最終保険として必ず成功するため、失敗で全停止しない。
 */
async function generateWithCascade(
  cascade: Asset3DProvider[],
  req: GenerateRequest,
  timeoutMs: number
): Promise<{ response: GenerateResponse; chain: string[]; errors: string[] }> {
  const chain: string[] = [];
  const errors: string[] = [];
  for (const provider of cascade) {
    chain.push(provider.name);
    try {
      const response = await Promise.race([
        provider.generate(req),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error(`${provider.name} timeout`)), timeoutMs)
        ),
      ]);
      // meshUrl が空でなければ成功扱い
      if (response.meshUrl) {
        return { response, chain, errors };
      }
      errors.push(`${provider.name}: empty meshUrl`);
    } catch (err) {
      errors.push(`${provider.name}: ${(err as Error).message}`);
    }
  }
  // 全プロバイダー失敗 → 空応答 (MockProviderが含まれている限り通常起きない)
  return {
    response: {
      meshUrl: '',
      textureUrls: [],
      polygonCount: 0,
      fileSize: 0,
      provider: 'none',
      costUSD: 0,
      durationMs: 0,
    },
    chain,
    errors,
  };
}

// =============================================================================
// 公開API: メインオーケストレーター
// =============================================================================

/**
 * 3Dアセット生成パイプライン全工程実行。
 *
 * 工程:
 *   1. プロバイダー選定 (cascade推奨)
 *   2. アセット生成 (1次失敗時は2次・3次へフォールバック)
 *   3. リギング (rigOptions指定時)
 *   4. LOD生成 (lodConfig指定時)
 *   5. アトラスパッキング (packAtlas=true時)
 *   6. エンジン取り込み (importTo指定時)
 *
 * 各工程はエラー時も後段に影響を最小化し、可能な限り部分成功を返す。
 */
export async function runPipeline(config: PipelineConfig): Promise<PipelineResult> {
  const start = Date.now();
  const errors: string[] = [];
  const timeoutMs = config.timeoutMs || 600000; // デフォルト10分
  const stageStatus: PipelineResult['stageStatus'] = {
    generate: 'skipped',
    rig: 'skipped',
    lod: 'skipped',
    atlas: 'skipped',
    import: 'skipped',
  };

  // ========================================================================
  // 1-2. プロバイダー選定 + 生成
  // ========================================================================
  const genReq = buildGenerateRequest(config);
  const cascade = recommendCascade(genReq, config.criteria);
  const { response: asset, chain: providerChain, errors: genErrors } =
    await generateWithCascade(cascade, genReq, timeoutMs);
  errors.push(...genErrors);
  let totalCost = asset.costUSD;
  stageStatus.generate = asset.meshUrl ? 'success' : 'failed';

  if (!asset.meshUrl) {
    // 生成完全失敗時はここで終了 (後段不可)
    return {
      asset,
      totalDurationMs: Date.now() - start,
      totalCostUSD: totalCost,
      errors,
      stageStatus,
      providerChain,
    };
  }

  // ========================================================================
  // 3. リギング
  // ========================================================================
  let rig: RigResult | undefined;
  if (config.rigOptions) {
    try {
      rig = await Promise.race([
        autoRig(asset, config.rigOptions),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('rigging timeout')), timeoutMs)
        ),
      ]);
      stageStatus.rig = 'success';
    } catch (err) {
      errors.push(`rigging: ${(err as Error).message}`);
      stageStatus.rig = 'failed';
    }
  }

  // ========================================================================
  // 4. LOD生成
  // ========================================================================
  let lod: LodResult | undefined;
  if (config.lodConfig) {
    try {
      // リギング済みメッシュがあればそれを、なければ元アセットをLOD化
      const baseMesh = rig?.riggedMeshUrl || asset.meshUrl;
      lod = await Promise.race([
        generateLod(baseMesh, config.lodConfig, asset.polygonCount),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('lod timeout')), timeoutMs)
        ),
      ]);
      stageStatus.lod = 'success';
    } catch (err) {
      errors.push(`lod: ${(err as Error).message}`);
      stageStatus.lod = 'failed';
    }
  }

  // ========================================================================
  // 5. アトラスパッキング
  // ========================================================================
  let atlas: AtlasPackResult | undefined;
  if (config.packAtlas && asset.textureUrls.length > 0) {
    try {
      atlas = await Promise.race([
        packAtlas(asset.textureUrls, config.atlasMaxSize || 4096),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('atlas timeout')), timeoutMs)
        ),
      ]);
      stageStatus.atlas = 'success';
    } catch (err) {
      errors.push(`atlas: ${(err as Error).message}`);
      stageStatus.atlas = 'failed';
    }
  }

  // ========================================================================
  // 6. エンジン取り込み
  // ========================================================================
  let importResult: ImportResult | undefined;
  let importPath: string | undefined;
  if (config.importTo) {
    try {
      importResult = await Promise.race([
        importToEngine(asset, config.importTo, {
          generatePreloadCode: true,
          addToManifest: true,
        }),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error('import timeout')), timeoutMs)
        ),
      ]);
      importPath = importResult.targetPath;
      stageStatus.import = importResult.errors.length === 0 ? 'success' : 'failed';
      errors.push(...importResult.errors.map((e) => `import: ${e}`));
    } catch (err) {
      errors.push(`import: ${(err as Error).message}`);
      stageStatus.import = 'failed';
    }
  }

  return {
    asset,
    rig,
    lod,
    atlas,
    importResult,
    importPath,
    totalDurationMs: Date.now() - start,
    totalCostUSD: totalCost,
    errors,
    stageStatus,
    providerChain,
  };
}

// =============================================================================
// 便利関数
// =============================================================================

/**
 * シンプルなテキスト→3D変換 (最小設定)。
 * デフォルトでLOD・リギングなし、Mock可。
 */
export async function quickGenerate(prompt: string): Promise<PipelineResult> {
  return runPipeline({
    prompt,
    criteria: { budget: 'cheap', qualityPriority: 'medium', speedPriority: 'medium' },
  });
}

/**
 * フルパイプライン (キャラクター生成 + リグ + LOD + アトラス + Three.js取り込み)。
 */
export async function fullCharacterPipeline(
  prompt: string,
  projectDir: string
): Promise<PipelineResult> {
  return runPipeline({
    prompt,
    criteria: {
      budget: 'standard',
      qualityPriority: 'high',
      speedPriority: 'medium',
      needsPBR: true,
      needsRigging: true,
    },
    generateRequest: { category: 'character', style: 'realistic', targetPolygonCount: 20000 },
    rigOptions: { humanoid: true, bipedSkeleton: true, finger: true, facialBones: true },
    lodConfig: DEFAULT_LOD_CONFIG,
    packAtlas: true,
    atlasMaxSize: 4096,
    importTo: { engine: 'three', projectDir },
  });
}

/**
 * パイプライン結果を1行サマリ文字列に整形。
 */
export function summarizePipelineResult(result: PipelineResult): string {
  const stages = Object.entries(result.stageStatus)
    .map(([k, v]) => `${k}:${v[0]}`)
    .join(' ');
  return `Provider=${result.asset.provider} (chain: ${result.providerChain.join('->')}) | ${stages} | ${result.totalDurationMs}ms | $${result.totalCostUSD.toFixed(2)} | errors=${result.errors.length}`;
}
