/**
 * SoloptiLinkAI v2.0 テクスチャアトラスパッカー
 *
 * 責務: 複数の小テクスチャを1枚の大きなアトラステクスチャにパックして、
 *       GPU draw call を削減し描画パフォーマンスを向上させる。
 *       MaxRects-BSSF (Best Short Side Fit) アルゴリズムベースの
 *       矩形パッキングを実装する。
 *
 * 著作権警告:
 *   アトラスに含めるテクスチャは元素材の利用規約に従うこと。
 *   特に各プロバイダー(Tripo3D等)生成テクスチャを再配布する場合は
 *   各サービスの利用規約に違反しないかを確認すること。
 */

// =============================================================================
// 型定義
// =============================================================================

/** 矩形 (パッキング用) */
interface Rect {
  x: number;
  y: number;
  width: number;
  height: number;
}

/** パック対象のテクスチャ情報 */
interface TextureItem {
  url: string;
  width: number;
  height: number;
}

/** アトラスパック結果 */
export interface AtlasPackResult {
  /** 生成アトラスのURL */
  atlasUrl: string;
  /** UVマッピング情報 (JSON文字列) */
  uvMappingJson: string;
  /** パックされたテクスチャ数 */
  packedCount: number;
  /** 利用率 (0-1、面積比) */
  utilization: number;
  /** draw call 削減数 (推定) */
  drawCallSaving: number;
  /** アトラスサイズ (pixel) */
  atlasSize: number;
  /** 処理時間 (ms) */
  durationMs: number;
  /** パックできなかったテクスチャURL */
  unpackedUrls: string[];
}

/** UVマッピング1件 */
interface UvMapping {
  originalUrl: string;
  /** アトラス内位置 (0-1 normalized) */
  uvRect: { u: number; v: number; w: number; h: number };
  /** ピクセル位置 */
  pixelRect: Rect;
}

// =============================================================================
// MaxRects アルゴリズム実装 (簡易版)
// =============================================================================

/**
 * MaxRects BSSF (Best Short Side Fit) パッキング。
 * 残り空き矩形のうち、テクスチャを置いたときに「最も短い辺の差」が
 * 小さくなる空き矩形に配置する貪欲アルゴリズム。
 */
class MaxRectsPacker {
  private freeRects: Rect[];

  public constructor(private maxWidth: number, private maxHeight: number) {
    this.freeRects = [{ x: 0, y: 0, width: maxWidth, height: maxHeight }];
  }

  /** 1テクスチャをパック。成功時は配置矩形、失敗時 null */
  public insert(width: number, height: number): Rect | null {
    let bestRect: Rect | null = null;
    let bestShortSide = Number.POSITIVE_INFINITY;
    let bestIndex = -1;

    for (let i = 0; i < this.freeRects.length; i++) {
      const free = this.freeRects[i];
      if (free.width < width || free.height < height) continue;
      const leftoverH = Math.abs(free.width - width);
      const leftoverV = Math.abs(free.height - height);
      const shortSide = Math.min(leftoverH, leftoverV);
      if (shortSide < bestShortSide) {
        bestRect = { x: free.x, y: free.y, width, height };
        bestShortSide = shortSide;
        bestIndex = i;
      }
    }
    if (!bestRect || bestIndex < 0) return null;

    // 配置後の空き領域を分割
    this.splitFreeRect(bestIndex, bestRect);
    this.pruneFreeRects();
    return bestRect;
  }

  /** 空き矩形を分割 (Guillotine風) */
  private splitFreeRect(index: number, placed: Rect): void {
    const free = this.freeRects[index];
    // 上下分割
    const newRects: Rect[] = [];
    if (placed.x + placed.width < free.x + free.width) {
      newRects.push({
        x: placed.x + placed.width,
        y: free.y,
        width: free.x + free.width - (placed.x + placed.width),
        height: free.height,
      });
    }
    if (placed.y + placed.height < free.y + free.height) {
      newRects.push({
        x: free.x,
        y: placed.y + placed.height,
        width: free.width,
        height: free.y + free.height - (placed.y + placed.height),
      });
    }
    this.freeRects.splice(index, 1);
    this.freeRects.push(...newRects);
  }

  /** 包含関係にある冗長な空き矩形を除去 */
  private pruneFreeRects(): void {
    for (let i = 0; i < this.freeRects.length; i++) {
      for (let j = i + 1; j < this.freeRects.length; j++) {
        if (this.contains(this.freeRects[j], this.freeRects[i])) {
          this.freeRects.splice(i, 1);
          i--;
          break;
        }
        if (this.contains(this.freeRects[i], this.freeRects[j])) {
          this.freeRects.splice(j, 1);
          j--;
        }
      }
    }
  }

  /** outer が inner を完全包含するか */
  private contains(outer: Rect, inner: Rect): boolean {
    return (
      inner.x >= outer.x &&
      inner.y >= outer.y &&
      inner.x + inner.width <= outer.x + outer.width &&
      inner.y + inner.height <= outer.y + outer.height
    );
  }
}

// =============================================================================
// 内部ヘルパー
// =============================================================================

/**
 * テクスチャURL一覧から各サイズを取得 (実装簡略化: URLから推測 or デフォルト)。
 * 本実装ではURLにサイズ情報があれば利用、無ければ 512x512 と仮定する。
 * 実環境では sharp/canvas で実際の画像サイズを取得すべき。
 */
async function probeTextureSizes(urls: string[]): Promise<TextureItem[]> {
  return urls.map((url) => {
    // URL末尾に _WxH_ 形式があれば抽出 (例: tex_512x512_albedo.png)
    const sizeMatch = url.match(/_(\d{2,4})x(\d{2,4})[_.]/);
    if (sizeMatch) {
      return {
        url,
        width: parseInt(sizeMatch[1], 10),
        height: parseInt(sizeMatch[2], 10),
      };
    }
    return { url, width: 512, height: 512 };
  });
}

/** アトラスURL生成 (decoded hash) */
function generateAtlasUrl(urls: string[], maxSize: number): string {
  let h = 0;
  for (const u of urls) {
    for (let i = 0; i < u.length; i++) {
      h = ((h << 5) - h + u.charCodeAt(i)) | 0;
    }
  }
  return `atlas://packed_${Math.abs(h).toString(16)}_${maxSize}.png`;
}

// =============================================================================
// 公開API
// =============================================================================

/**
 * 複数テクスチャを1枚のアトラスにパック。
 *
 * @param textureUrls パック対象テクスチャURL配列
 * @param maxSize アトラス最大サイズ (4096 / 2048 / 1024)
 * @returns パック結果
 */
export async function packAtlas(
  textureUrls: string[],
  maxSize: 4096 | 2048 | 1024 = 4096
): Promise<AtlasPackResult> {
  const start = Date.now();

  if (textureUrls.length === 0) {
    return {
      atlasUrl: '',
      uvMappingJson: '[]',
      packedCount: 0,
      utilization: 0,
      drawCallSaving: 0,
      atlasSize: maxSize,
      durationMs: Date.now() - start,
      unpackedUrls: [],
    };
  }

  try {
    const items = await probeTextureSizes(textureUrls);
    // 大きいテクスチャから順に配置 (BSSFの効率向上)
    items.sort((a, b) => b.width * b.height - a.width * a.height);

    const packer = new MaxRectsPacker(maxSize, maxSize);
    const uvMappings: UvMapping[] = [];
    const unpackedUrls: string[] = [];
    let usedArea = 0;

    for (const item of items) {
      const placed = packer.insert(item.width, item.height);
      if (placed) {
        uvMappings.push({
          originalUrl: item.url,
          uvRect: {
            u: placed.x / maxSize,
            v: placed.y / maxSize,
            w: placed.width / maxSize,
            h: placed.height / maxSize,
          },
          pixelRect: placed,
        });
        usedArea += placed.width * placed.height;
      } else {
        unpackedUrls.push(item.url);
      }
    }

    const utilization = usedArea / (maxSize * maxSize);
    const packedCount = uvMappings.length;
    // draw call は元 packedCount 回 → 1 回に集約
    const drawCallSaving = packedCount > 1 ? packedCount - 1 : 0;

    return {
      atlasUrl: generateAtlasUrl(textureUrls, maxSize),
      uvMappingJson: JSON.stringify(uvMappings, null, 2),
      packedCount,
      utilization: Math.round(utilization * 10000) / 10000,
      drawCallSaving,
      atlasSize: maxSize,
      durationMs: Date.now() - start,
      unpackedUrls,
    };
  } catch (err) {
    return {
      atlasUrl: '',
      uvMappingJson: '[]',
      packedCount: 0,
      utilization: 0,
      drawCallSaving: 0,
      atlasSize: maxSize,
      durationMs: Date.now() - start,
      unpackedUrls: textureUrls,
    };
  }
}

/**
 * 複数アトラスへ自動分割 (1枚に収まらない場合)。
 * すべてのテクスチャがパックされるまで maxSize アトラスを生成する。
 */
export async function packAtlasMulti(
  textureUrls: string[],
  maxSize: 4096 | 2048 | 1024 = 4096
): Promise<AtlasPackResult[]> {
  const results: AtlasPackResult[] = [];
  let remaining = [...textureUrls];
  const maxAttempts = 10; // 暴走防止
  for (let i = 0; i < maxAttempts; i++) {
    if (remaining.length === 0) break;
    const result = await packAtlas(remaining, maxSize);
    if (result.packedCount === 0) break;
    results.push(result);
    remaining = result.unpackedUrls;
  }
  return results;
}
