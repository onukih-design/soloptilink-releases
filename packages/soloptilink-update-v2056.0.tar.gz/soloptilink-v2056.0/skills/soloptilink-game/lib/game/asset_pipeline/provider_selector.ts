/**
 * SoloptiLinkAI v2.0 3Dアセットプロバイダー自動選定モジュール
 *
 * 責務: 予算・品質・速度・スタイル等の選定基準から最適な3Dプロバイダーを
 *       自動選定する。さらにフォールバック順 (cascade) も提供し、
 *       1次プロバイダー失敗時に2次・3次プロバイダーへ自動切替可能とする。
 *
 * 著作権警告:
 *   選定された各プロバイダーで生成されるアセットの商用利用可否は
 *   各サービスの利用規約に従うこと。
 */

import {
  Asset3DProvider,
  GenerateRequest,
  MockProvider,
  Tripo3DProvider,
  MeshyProvider,
  StableZero123Provider,
  RodinProvider,
  LumaProvider,
  getAllProviders,
} from './providers';

// =============================================================================
// 型定義
// =============================================================================

/** プロバイダー選定基準 */
export interface SelectionCriteria {
  /** 予算レベル */
  budget?: 'free' | 'cheap' | 'standard' | 'premium';
  /** 品質優先度 */
  qualityPriority?: 'low' | 'medium' | 'high';
  /** 速度優先度 */
  speedPriority?: 'fast' | 'medium' | 'slow';
  /** スタイル要件 (lowpoly, realistic等) */
  styleRequirement?: string;
  /** リギング必須か */
  needsRigging?: boolean;
  /** PBRテクスチャ必須か */
  needsPBR?: boolean;
}

// =============================================================================
// スコアリング
// =============================================================================

/** プロバイダーごとのスコア (高いほど推奨) */
interface ProviderScore {
  provider: Asset3DProvider;
  score: number;
  reason: string[];
}

/** 予算ごとの最大価格 (USD) */
const BUDGET_LIMIT_USD: Record<NonNullable<SelectionCriteria['budget']>, number> = {
  free: 0,
  cheap: 0.2,
  standard: 0.5,
  premium: Number.POSITIVE_INFINITY,
};

/** 速度優先度ごとの最大処理時間 (秒) */
const SPEED_LIMIT_SEC: Record<NonNullable<SelectionCriteria['speedPriority']>, number> = {
  fast: 90,
  medium: 240,
  slow: Number.POSITIVE_INFINITY,
};

/**
 * 単一プロバイダーをスコアリング。
 *  - リクエスト能力一致         +30
 *  - 予算内                     +20  / 超過は -100 (実質除外)
 *  - 速度基準内                 +15
 *  - 品質一致 (priceから推定)   +25
 *  - 必須能力 (rigging/PBR) 一致 +30 / 不一致は -100
 *  - スタイル得意分野           +10
 */
function scoreProvider(
  provider: Asset3DProvider,
  req: GenerateRequest,
  criteria: SelectionCriteria
): ProviderScore {
  const reason: string[] = [];
  let score = 0;

  // 0. リクエストがimage2meshなのに対応していない → 大幅減点
  if (req.referenceImageUrl && !provider.capabilities.includes('image2mesh')) {
    return { provider, score: -1000, reason: ['image2mesh非対応'] };
  }
  if (!req.referenceImageUrl && !provider.capabilities.includes('text2mesh') && provider.name !== 'MockProvider') {
    return { provider, score: -1000, reason: ['text2mesh非対応'] };
  }

  // 1. 予算
  const budget = criteria.budget || 'standard';
  const limit = BUDGET_LIMIT_USD[budget];
  if (provider.priceUSDPerAsset > limit) {
    return { provider, score: -1000, reason: [`予算${budget}超過(${provider.priceUSDPerAsset}USD>${limit}USD)`] };
  }
  score += 20;
  reason.push(`予算${budget}内 +20`);

  // 2. 速度
  const speed = criteria.speedPriority || 'medium';
  const speedLimit = SPEED_LIMIT_SEC[speed];
  if (provider.estimatedSeconds <= speedLimit) {
    score += 15;
    reason.push(`速度${speed}基準内 +15`);
  } else {
    score -= 10;
    reason.push(`速度${speed}超過 -10`);
  }

  // 3. 品質 (価格からの近似指標: 高価 = 高品質)
  const quality = criteria.qualityPriority || 'medium';
  if (quality === 'high' && provider.priceUSDPerAsset >= 0.4) {
    score += 25;
    reason.push('高品質一致 +25');
  } else if (quality === 'medium' && provider.priceUSDPerAsset >= 0.15 && provider.priceUSDPerAsset < 0.5) {
    score += 25;
    reason.push('中品質一致 +25');
  } else if (quality === 'low' && provider.priceUSDPerAsset <= 0.2) {
    score += 25;
    reason.push('低品質許容 +25');
  } else {
    score += 5;
  }

  // 4. 必須能力
  if (criteria.needsRigging && !provider.capabilities.includes('rigging')) {
    return { provider, score: -1000, reason: ['リギング非対応'] };
  }
  if (criteria.needsRigging) {
    score += 30;
    reason.push('リギング対応 +30');
  }
  if (criteria.needsPBR && !provider.capabilities.includes('pbr_texture')) {
    return { provider, score: -1000, reason: ['PBR非対応'] };
  }
  if (criteria.needsPBR) {
    score += 30;
    reason.push('PBR対応 +30');
  }

  // 5. スタイル得意分野ボーナス
  const style = criteria.styleRequirement || req.style;
  if (style === 'realistic' && (provider.name === 'Rodin' || provider.name === 'Tripo3D')) {
    score += 10;
    reason.push(`${provider.name}は realistic 得意 +10`);
  } else if (style === 'cartoon' && provider.name === 'Meshy') {
    score += 10;
    reason.push('Meshyは cartoon 得意 +10');
  } else if (style === 'lowpoly' && provider.name === 'StableZero123') {
    score += 10;
    reason.push('StableZero123は lowpoly 得意 +10');
  } else if (style === 'voxel' && provider.name === 'LumaGenie') {
    score += 10;
    reason.push('LumaGenieは voxel 得意 +10');
  }

  return { provider, score, reason };
}

// =============================================================================
// 公開API
// =============================================================================

/**
 * 単一プロバイダー選定。
 * 全候補をスコアリングし、最高スコアのプロバイダーを返す。
 * 全プロバイダーがスコア負の場合は MockProvider を返す (フェイルセーフ)。
 */
export function selectProvider(
  req: GenerateRequest,
  criteria: SelectionCriteria
): Asset3DProvider {
  // free 予算は即 Mock
  if (criteria.budget === 'free') {
    return new MockProvider();
  }
  const candidates = getAllProviders().filter((p) => p.name !== 'MockProvider');
  const scored = candidates.map((p) => scoreProvider(p, req, criteria));
  scored.sort((a, b) => b.score - a.score);
  const best = scored[0];
  if (!best || best.score < 0) {
    return new MockProvider();
  }
  return best.provider;
}

/**
 * フォールバックカスケード推奨。
 * primary → fallback1 → fallback2 → ... の優先順を返す。
 * 1次が失敗した時に自動的に2次へ切り替える用途。
 * 最終要素は必ず MockProvider (確実に動作する保険) を付与。
 */
export function recommendCascade(
  req: GenerateRequest,
  criteria: SelectionCriteria = {}
): Asset3DProvider[] {
  // free 予算は Mock のみ
  if (criteria.budget === 'free') {
    return [new MockProvider()];
  }
  const candidates = getAllProviders().filter((p) => p.name !== 'MockProvider');
  const scored = candidates.map((p) => scoreProvider(p, req, criteria));
  scored.sort((a, b) => b.score - a.score);
  const cascade = scored
    .filter((s) => s.score >= 0)
    .slice(0, 3)
    .map((s) => s.provider);
  // 必ず最後に Mock を付ける
  cascade.push(new MockProvider());
  return cascade;
}

/**
 * 選定理由を診断レポートとして取得 (デバッグ・ログ用)。
 */
export function explainSelection(
  req: GenerateRequest,
  criteria: SelectionCriteria
): { selected: string; cascade: string[]; details: Array<{ name: string; score: number; reasons: string[] }> } {
  const candidates = getAllProviders().filter((p) => p.name !== 'MockProvider');
  const scored = candidates.map((p) => scoreProvider(p, req, criteria));
  scored.sort((a, b) => b.score - a.score);
  const cascade = recommendCascade(req, criteria);
  return {
    selected: selectProvider(req, criteria).name,
    cascade: cascade.map((p) => p.name),
    details: scored.map((s) => ({
      name: s.provider.name,
      score: s.score,
      reasons: s.reason,
    })),
  };
}
