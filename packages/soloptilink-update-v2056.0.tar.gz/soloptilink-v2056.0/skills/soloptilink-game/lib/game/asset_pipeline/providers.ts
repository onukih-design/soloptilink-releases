/**
 * SoloptiLinkAI v2.0 3Dアセット生成プロバイダー統合層
 *
 * 責務: Tripo3D / Meshy / Stable Zero123 / Rodin / Luma など複数の
 *       3D生成サービスを単一の `Asset3DProvider` インターフェイスで
 *       抽象化する。APIキーが未設定の場合は自動的に MockProvider に
 *       フォールバックし、開発・テスト環境でも常に動作可能とする。
 *
 * 著作権・利用規約注意:
 *   各サービスで生成された3Dアセットの著作権と商用利用可否は
 *   各プロバイダーの利用規約に従う。本モジュールは技術的な
 *   API呼び出しを行うのみで、生成物のライセンス管理は責任を負わない。
 *   - Tripo3D:        https://www.tripo3d.ai/terms
 *   - Meshy:          https://www.meshy.ai/terms
 *   - Stable Zero123: https://stability.ai/license
 *   - Rodin:          https://hyper3d.ai/terms
 *   - Luma Genie:     https://lumalabs.ai/legal/terms
 */

// =============================================================================
// 型定義
// =============================================================================

/** プロバイダーがサポートする機能タイプ */
export type ProviderCapability =
  | 'text2mesh'    // テキストプロンプトから3Dメッシュ生成
  | 'image2mesh'   // 単一画像から3D化
  | 'mesh2mesh'    // 既存メッシュのリファイン
  | 'pbr_texture'  // PBR (Physically Based Rendering) テクスチャ生成
  | 'rigging'      // 自動リギング
  | 'lod';         // LOD自動生成

/** 生成スタイル */
export type GenerationStyle =
  | 'lowpoly'      // ローポリ (モバイル向け)
  | 'cartoon'      // カートゥーン (子供向けゲーム)
  | 'realistic'    // フォトリアリスティック
  | 'pixelart3d'   // 3Dピクセルアート
  | 'voxel';       // ボクセル (Minecraft風)

/** アセットカテゴリ */
export type AssetCategory =
  | 'character'    // キャラクター
  | 'prop'         // 小物・装飾
  | 'environment'  // 環境・背景
  | 'vehicle'      // 乗り物
  | 'weapon';      // 武器

/** 出力フォーマット */
export type OutputFormat = 'gltf' | 'glb' | 'fbx' | 'obj';

/** 3Dアセット生成リクエスト */
export interface GenerateRequest {
  /** テキストプロンプト (必須) */
  prompt: string;
  /** 生成スタイル */
  style?: GenerationStyle;
  /** アセットカテゴリ */
  category?: AssetCategory;
  /** 出力フォーマット (デフォルト: glb) */
  outputFormat?: OutputFormat;
  /** 目標ポリゴン数 (デフォルト: 10000) */
  targetPolygonCount?: number;
  /** テクスチャ込みで生成するか */
  withTextures?: boolean;
  /** 参照画像URL (image2mesh時) */
  referenceImageUrl?: string;
}

/** 3Dアセット生成レスポンス */
export interface GenerateResponse {
  /** 生成されたメッシュファイルのURL */
  meshUrl: string;
  /** テクスチャファイルのURL配列 */
  textureUrls: string[];
  /** 実際のポリゴン数 */
  polygonCount: number;
  /** ファイルサイズ (bytes) */
  fileSize: number;
  /** 使用したプロバイダー名 */
  provider: string;
  /** 課金額 (USD) */
  costUSD: number;
  /** 処理時間 (ms) */
  durationMs: number;
}

/** プロバイダー共通インターフェイス */
export interface Asset3DProvider {
  /** プロバイダー識別名 */
  name: string;
  /** サポート機能リスト */
  capabilities: ProviderCapability[];
  /** 1アセットあたりの平均価格 (USD) */
  priceUSDPerAsset: number;
  /** 平均生成時間 (秒) */
  estimatedSeconds: number;
  /** 生成実行 */
  generate(req: GenerateRequest): Promise<GenerateResponse>;
}

// =============================================================================
// 内部ユーティリティ
// =============================================================================

/** APIキーが環境変数に存在するか判定 */
function hasApiKey(envName: string): boolean {
  const value = (typeof process !== 'undefined' && process.env) ? process.env[envName] : undefined;
  return typeof value === 'string' && value.length > 0;
}

/** APIキーを取得 (なければ空文字) */
function getApiKey(envName: string): string {
  return (typeof process !== 'undefined' && process.env && process.env[envName]) || '';
}

/** プロンプトハッシュ生成 (Mock URL再現性のため) */
function hashPrompt(prompt: string): string {
  let h = 0;
  for (let i = 0; i < prompt.length; i++) {
    h = ((h << 5) - h + prompt.charCodeAt(i)) | 0;
  }
  return Math.abs(h).toString(16).padStart(8, '0');
}

/** タイムアウト付き fetch ラッパー */
async function fetchWithTimeout(
  url: string,
  options: RequestInit,
  timeoutMs: number
): Promise<Response> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);
  try {
    return await fetch(url, { ...options, signal: controller.signal });
  } finally {
    clearTimeout(timer);
  }
}

// =============================================================================
// MockProvider (テスト用、即時応答)
// =============================================================================

/**
 * APIキー不要のモックプロバイダー。
 * テスト・開発・APIキー欠如時のフォールバックとして使用。
 */
export class MockProvider implements Asset3DProvider {
  public readonly name = 'MockProvider';
  public readonly capabilities: ProviderCapability[] = [
    'text2mesh', 'image2mesh', 'mesh2mesh', 'pbr_texture',
  ];
  public readonly priceUSDPerAsset = 0;
  public readonly estimatedSeconds = 0.1;

  public async generate(req: GenerateRequest): Promise<GenerateResponse> {
    const start = Date.now();
    const hash = hashPrompt(req.prompt);
    const fmt = req.outputFormat || 'glb';
    // 即時応答 (50ms程度の擬似遅延)
    await new Promise((resolve) => setTimeout(resolve, 50));
    return {
      meshUrl: `mock://asset/${hash}.${fmt}`,
      textureUrls: req.withTextures !== false
        ? [`mock://texture/${hash}_albedo.png`, `mock://texture/${hash}_normal.png`]
        : [],
      polygonCount: req.targetPolygonCount || 10000,
      fileSize: 1024 * 512, // 仮想的に512KB
      provider: this.name,
      costUSD: 0,
      durationMs: Date.now() - start,
    };
  }
}

// =============================================================================
// Tripo3DProvider
// =============================================================================

/**
 * Tripo3D (https://www.tripo3d.ai/) アダプタ。
 * 高品質キャラクター・プロップ生成が得意。PBRテクスチャ対応。
 */
export class Tripo3DProvider implements Asset3DProvider {
  public readonly name = 'Tripo3D';
  public readonly capabilities: ProviderCapability[] = [
    'text2mesh', 'image2mesh', 'pbr_texture', 'rigging',
  ];
  public readonly priceUSDPerAsset = 0.4;
  public readonly estimatedSeconds = 180;

  private readonly apiKey: string;
  private readonly baseUrl = 'https://api.tripo3d.ai/v2/openapi';

  public constructor(apiKey?: string) {
    this.apiKey = apiKey || getApiKey('TRIPO3D_API_KEY');
  }

  public async generate(req: GenerateRequest): Promise<GenerateResponse> {
    // APIキーが無ければ MockProvider にフォールバック
    if (!this.apiKey) {
      return new MockProvider().generate(req);
    }
    const start = Date.now();
    try {
      // 1. ジョブ作成
      const createRes = await fetchWithTimeout(
        `${this.baseUrl}/task`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            type: req.referenceImageUrl ? 'image_to_model' : 'text_to_model',
            prompt: req.prompt,
            image_url: req.referenceImageUrl,
            style: req.style || 'realistic',
            face_limit: req.targetPolygonCount || 10000,
            texture: req.withTextures !== false,
          }),
        },
        30000
      );
      if (!createRes.ok) {
        throw new Error(`Tripo3D task create failed: ${createRes.status}`);
      }
      const createJson = (await createRes.json()) as { task_id: string };
      // 2. ポーリング (最大10分)
      const taskId = createJson.task_id;
      const maxPolls = 60;
      let meshUrl = '';
      let textureUrls: string[] = [];
      for (let i = 0; i < maxPolls; i++) {
        await new Promise((resolve) => setTimeout(resolve, 10000));
        const pollRes = await fetchWithTimeout(
          `${this.baseUrl}/task/${taskId}`,
          { headers: { 'Authorization': `Bearer ${this.apiKey}` } },
          15000
        );
        if (!pollRes.ok) continue;
        const pollJson = (await pollRes.json()) as {
          status: string;
          output?: { model: string; textures?: string[] };
        };
        if (pollJson.status === 'success' && pollJson.output) {
          meshUrl = pollJson.output.model;
          textureUrls = pollJson.output.textures || [];
          break;
        }
        if (pollJson.status === 'failed') {
          throw new Error('Tripo3D generation failed');
        }
      }
      if (!meshUrl) {
        throw new Error('Tripo3D timeout');
      }
      return {
        meshUrl,
        textureUrls,
        polygonCount: req.targetPolygonCount || 10000,
        fileSize: 1024 * 1024 * 2,
        provider: this.name,
        costUSD: this.priceUSDPerAsset,
        durationMs: Date.now() - start,
      };
    } catch (err) {
      // エラー時もMockへフォールバック (パイプライン継続)
      return new MockProvider().generate(req);
    }
  }
}

// =============================================================================
// MeshyProvider
// =============================================================================

/**
 * Meshy (https://www.meshy.ai/) アダプタ。
 * テキスト/画像 → 3D変換が高速。バランス重視の汎用プロバイダー。
 */
export class MeshyProvider implements Asset3DProvider {
  public readonly name = 'Meshy';
  public readonly capabilities: ProviderCapability[] = [
    'text2mesh', 'image2mesh', 'pbr_texture',
  ];
  public readonly priceUSDPerAsset = 0.25;
  public readonly estimatedSeconds = 120;

  private readonly apiKey: string;
  private readonly baseUrl = 'https://api.meshy.ai/v2';

  public constructor(apiKey?: string) {
    this.apiKey = apiKey || getApiKey('MESHY_API_KEY');
  }

  public async generate(req: GenerateRequest): Promise<GenerateResponse> {
    if (!this.apiKey) {
      return new MockProvider().generate(req);
    }
    const start = Date.now();
    try {
      const endpoint = req.referenceImageUrl ? 'image-to-3d' : 'text-to-3d';
      const body: Record<string, unknown> = {
        mode: 'preview',
        prompt: req.prompt,
        art_style: req.style === 'realistic' ? 'realistic' : 'cartoon',
        topology: 'quad',
        target_polycount: req.targetPolygonCount || 10000,
      };
      if (req.referenceImageUrl) {
        body['image_url'] = req.referenceImageUrl;
      }
      const createRes = await fetchWithTimeout(
        `${this.baseUrl}/${endpoint}`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify(body),
        },
        30000
      );
      if (!createRes.ok) {
        throw new Error(`Meshy create failed: ${createRes.status}`);
      }
      const createJson = (await createRes.json()) as { result: string };
      const taskId = createJson.result;
      let meshUrl = '';
      let textureUrls: string[] = [];
      // ポーリング (最大8分)
      for (let i = 0; i < 48; i++) {
        await new Promise((resolve) => setTimeout(resolve, 10000));
        const pollRes = await fetchWithTimeout(
          `${this.baseUrl}/${endpoint}/${taskId}`,
          { headers: { 'Authorization': `Bearer ${this.apiKey}` } },
          15000
        );
        if (!pollRes.ok) continue;
        const pollJson = (await pollRes.json()) as {
          status: string;
          model_urls?: { glb?: string; fbx?: string; obj?: string };
          texture_urls?: Array<{ base_color?: string; normal?: string }>;
        };
        if (pollJson.status === 'SUCCEEDED' && pollJson.model_urls) {
          meshUrl = pollJson.model_urls.glb || pollJson.model_urls.fbx || pollJson.model_urls.obj || '';
          if (pollJson.texture_urls) {
            textureUrls = pollJson.texture_urls.flatMap((t) =>
              [t.base_color, t.normal].filter((u): u is string => typeof u === 'string')
            );
          }
          break;
        }
        if (pollJson.status === 'FAILED') {
          throw new Error('Meshy generation failed');
        }
      }
      if (!meshUrl) throw new Error('Meshy timeout');
      return {
        meshUrl,
        textureUrls,
        polygonCount: req.targetPolygonCount || 10000,
        fileSize: 1024 * 1024 * 1.5,
        provider: this.name,
        costUSD: this.priceUSDPerAsset,
        durationMs: Date.now() - start,
      };
    } catch (err) {
      return new MockProvider().generate(req);
    }
  }
}

// =============================================================================
// StableZero123Provider
// =============================================================================

/**
 * Stability AI Stable Zero123 アダプタ。
 * 単一画像からの3D再構成が高速 (約1分以内)。speedPriority=fast 向き。
 */
export class StableZero123Provider implements Asset3DProvider {
  public readonly name = 'StableZero123';
  public readonly capabilities: ProviderCapability[] = ['image2mesh'];
  public readonly priceUSDPerAsset = 0.1;
  public readonly estimatedSeconds = 60;

  private readonly apiKey: string;
  private readonly baseUrl = 'https://api.stability.ai/v2beta/3d/stable-fast-3d';

  public constructor(apiKey?: string) {
    this.apiKey = apiKey || getApiKey('STABILITY_API_KEY');
  }

  public async generate(req: GenerateRequest): Promise<GenerateResponse> {
    if (!this.apiKey || !req.referenceImageUrl) {
      // 画像が無い場合はそもそも image2mesh 不可 → Mock
      return new MockProvider().generate(req);
    }
    const start = Date.now();
    try {
      const formData = new FormData();
      formData.append('image', req.referenceImageUrl);
      formData.append('texture_resolution', '1024');
      const res = await fetchWithTimeout(
        this.baseUrl,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Accept': 'model/gltf-binary',
          },
          body: formData,
        },
        120000
      );
      if (!res.ok) {
        throw new Error(`StableZero123 failed: ${res.status}`);
      }
      // バイナリ応答 → 一時URLを返す前提
      const buf = await res.arrayBuffer();
      const hash = hashPrompt(req.prompt + (req.referenceImageUrl || ''));
      const meshUrl = `local://stable_zero123/${hash}.glb`;
      return {
        meshUrl,
        textureUrls: [],
        polygonCount: 8000,
        fileSize: buf.byteLength,
        provider: this.name,
        costUSD: this.priceUSDPerAsset,
        durationMs: Date.now() - start,
      };
    } catch (err) {
      return new MockProvider().generate(req);
    }
  }
}

// =============================================================================
// RodinProvider
// =============================================================================

/**
 * Hyper3D Rodin (https://hyper3d.ai/) アダプタ。
 * 最高品質クラス。PBR + リギング + ハードサーフェス得意。Premium枠。
 */
export class RodinProvider implements Asset3DProvider {
  public readonly name = 'Rodin';
  public readonly capabilities: ProviderCapability[] = [
    'text2mesh', 'image2mesh', 'pbr_texture', 'rigging',
  ];
  public readonly priceUSDPerAsset = 0.8;
  public readonly estimatedSeconds = 300;

  private readonly apiKey: string;
  private readonly baseUrl = 'https://hyperhuman.deemos.com/api/v2';

  public constructor(apiKey?: string) {
    this.apiKey = apiKey || getApiKey('RODIN_API_KEY');
  }

  public async generate(req: GenerateRequest): Promise<GenerateResponse> {
    if (!this.apiKey) {
      return new MockProvider().generate(req);
    }
    const start = Date.now();
    try {
      const createRes = await fetchWithTimeout(
        `${this.baseUrl}/rodin`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            prompt: req.prompt,
            condition_mode: req.referenceImageUrl ? 'image' : 'text',
            image: req.referenceImageUrl,
            quality: 'high',
            tier: 'Detail',
            mesh_mode: 'Quad',
            mesh_simplify: false,
            material: 'PBR',
          }),
        },
        30000
      );
      if (!createRes.ok) {
        throw new Error(`Rodin failed: ${createRes.status}`);
      }
      const createJson = (await createRes.json()) as { uuid: string; jobs: { subscription_key: string } };
      const uuid = createJson.uuid;
      let meshUrl = '';
      let textureUrls: string[] = [];
      // 最大15分ポーリング
      for (let i = 0; i < 90; i++) {
        await new Promise((resolve) => setTimeout(resolve, 10000));
        const statusRes = await fetchWithTimeout(
          `${this.baseUrl}/status?uuid=${uuid}`,
          { headers: { 'Authorization': `Bearer ${this.apiKey}` } },
          15000
        );
        if (!statusRes.ok) continue;
        const statusJson = (await statusRes.json()) as {
          status: string;
          download_url?: string;
          textures?: string[];
        };
        if (statusJson.status === 'Done' && statusJson.download_url) {
          meshUrl = statusJson.download_url;
          textureUrls = statusJson.textures || [];
          break;
        }
        if (statusJson.status === 'Failed') {
          throw new Error('Rodin failed');
        }
      }
      if (!meshUrl) throw new Error('Rodin timeout');
      return {
        meshUrl,
        textureUrls,
        polygonCount: req.targetPolygonCount || 50000,
        fileSize: 1024 * 1024 * 5,
        provider: this.name,
        costUSD: this.priceUSDPerAsset,
        durationMs: Date.now() - start,
      };
    } catch (err) {
      return new MockProvider().generate(req);
    }
  }
}

// =============================================================================
// LumaProvider
// =============================================================================

/**
 * Luma AI Genie (https://lumalabs.ai/genie) アダプタ。
 * テキスト→3D。NeRFベース表現が得意。アーティスティック寄り。
 */
export class LumaProvider implements Asset3DProvider {
  public readonly name = 'LumaGenie';
  public readonly capabilities: ProviderCapability[] = ['text2mesh', 'pbr_texture'];
  public readonly priceUSDPerAsset = 0.3;
  public readonly estimatedSeconds = 240;

  private readonly apiKey: string;
  private readonly baseUrl = 'https://api.lumalabs.ai/dream-machine/v1';

  public constructor(apiKey?: string) {
    this.apiKey = apiKey || getApiKey('LUMA_API_KEY');
  }

  public async generate(req: GenerateRequest): Promise<GenerateResponse> {
    if (!this.apiKey) {
      return new MockProvider().generate(req);
    }
    const start = Date.now();
    try {
      const createRes = await fetchWithTimeout(
        `${this.baseUrl}/generations/3d`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${this.apiKey}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            prompt: req.prompt,
            aspect_ratio: '1:1',
          }),
        },
        30000
      );
      if (!createRes.ok) {
        throw new Error(`Luma failed: ${createRes.status}`);
      }
      const createJson = (await createRes.json()) as { id: string };
      const taskId = createJson.id;
      let meshUrl = '';
      for (let i = 0; i < 60; i++) {
        await new Promise((resolve) => setTimeout(resolve, 10000));
        const pollRes = await fetchWithTimeout(
          `${this.baseUrl}/generations/${taskId}`,
          { headers: { 'Authorization': `Bearer ${this.apiKey}` } },
          15000
        );
        if (!pollRes.ok) continue;
        const pollJson = (await pollRes.json()) as {
          state: string;
          assets?: { glb?: string };
        };
        if (pollJson.state === 'completed' && pollJson.assets?.glb) {
          meshUrl = pollJson.assets.glb;
          break;
        }
        if (pollJson.state === 'failed') throw new Error('Luma failed');
      }
      if (!meshUrl) throw new Error('Luma timeout');
      return {
        meshUrl,
        textureUrls: [],
        polygonCount: req.targetPolygonCount || 15000,
        fileSize: 1024 * 1024 * 3,
        provider: this.name,
        costUSD: this.priceUSDPerAsset,
        durationMs: Date.now() - start,
      };
    } catch (err) {
      return new MockProvider().generate(req);
    }
  }
}

// =============================================================================
// プロバイダーレジストリ
// =============================================================================

/** デフォルトでロードされる全プロバイダー */
export function getAllProviders(): Asset3DProvider[] {
  return [
    new Tripo3DProvider(),
    new MeshyProvider(),
    new StableZero123Provider(),
    new RodinProvider(),
    new LumaProvider(),
    new MockProvider(),
  ];
}

/** プロバイダー名で検索 */
export function getProviderByName(name: string): Asset3DProvider {
  const found = getAllProviders().find((p) => p.name === name);
  return found || new MockProvider();
}

/** APIキーが設定されているプロバイダーのみを返す */
export function getAvailableProviders(): Asset3DProvider[] {
  return getAllProviders().filter((p) => {
    if (p.name === 'MockProvider') return true;
    if (p.name === 'Tripo3D') return hasApiKey('TRIPO3D_API_KEY');
    if (p.name === 'Meshy') return hasApiKey('MESHY_API_KEY');
    if (p.name === 'StableZero123') return hasApiKey('STABILITY_API_KEY');
    if (p.name === 'Rodin') return hasApiKey('RODIN_API_KEY');
    if (p.name === 'LumaGenie') return hasApiKey('LUMA_API_KEY');
    return false;
  });
}
