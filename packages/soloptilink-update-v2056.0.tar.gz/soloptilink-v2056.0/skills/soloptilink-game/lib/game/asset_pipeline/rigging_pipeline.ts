/**
 * SoloptiLinkAI v2.0 自動リギング(Auto-Rig)パイプライン
 *
 * 責務: 生成済みメッシュに対して自動的にボーン(スケルトン)を割り当て、
 *       アニメーション可能な状態にする。Mixamo / Rigify (Blender) /
 *       Cascadeur 等の外部ツールラッパーを統合し、APIキー未設定時は
 *       MockRiggerで bipedテンプレートを適用する。
 *
 * 著作権警告:
 *   Mixamo の Auto-Rig は Adobe Mixamo Terms of Service に従う。
 *   Rigify は Blender GPL ライセンス、Cascadeur は商用ライセンス必要。
 *   生成された Rig の商用利用可否は各ツール規約に従うこと。
 */

import { GenerateResponse } from './providers';

// =============================================================================
// 型定義
// =============================================================================

/** リギングオプション */
export interface RigOptions {
  /** ヒューマノイドリグ (人型キャラクター用) */
  humanoid?: boolean;
  /** Biped (二足歩行) スケルトン */
  bipedSkeleton?: boolean;
  /** 表情ボーン (顔の動き) */
  facialBones?: boolean;
  /** 指ボーン (細かい手の動き) */
  finger?: boolean;
}

/** ボーン1本の定義 */
export interface BoneDefinition {
  name: string;
  parent: string | null;
  position: [number, number, number];
  rotation: [number, number, number, number]; // quaternion
  length: number;
}

/** リギング結果 */
export interface RigResult {
  /** リギング済みメッシュURL (.glb等) */
  riggedMeshUrl: string;
  /** スケルトン構造 (JSON文字列) */
  skeletonJson: string;
  /** バインドポーズ行列 (4x4の配列) */
  bindPoseMatrix: number[][];
  /** ボーン総数 */
  boneCount: number;
  /** 使用したリガー名 */
  rigger: string;
  /** 処理時間 (ms) */
  durationMs: number;
}

// =============================================================================
// Biped 標準スケルトンテンプレート
// =============================================================================

/**
 * Mixamo互換 Biped 標準スケルトン (52ボーン構成、指含む)。
 * Quaternion は単位 [0,0,0,1] とし、位置のみ初期化。
 */
function buildBipedSkeleton(options: RigOptions): BoneDefinition[] {
  const bones: BoneDefinition[] = [
    { name: 'Hips',          parent: null,          position: [0, 1.0, 0], rotation: [0, 0, 0, 1], length: 0.1 },
    { name: 'Spine',         parent: 'Hips',        position: [0, 1.1, 0], rotation: [0, 0, 0, 1], length: 0.15 },
    { name: 'Spine1',        parent: 'Spine',       position: [0, 1.25, 0], rotation: [0, 0, 0, 1], length: 0.15 },
    { name: 'Spine2',        parent: 'Spine1',      position: [0, 1.4, 0], rotation: [0, 0, 0, 1], length: 0.15 },
    { name: 'Neck',          parent: 'Spine2',      position: [0, 1.55, 0], rotation: [0, 0, 0, 1], length: 0.1 },
    { name: 'Head',          parent: 'Neck',        position: [0, 1.65, 0], rotation: [0, 0, 0, 1], length: 0.2 },
    // 左腕
    { name: 'LeftShoulder',  parent: 'Spine2',      position: [0.1, 1.5, 0], rotation: [0, 0, 0, 1], length: 0.1 },
    { name: 'LeftArm',       parent: 'LeftShoulder',position: [0.2, 1.5, 0], rotation: [0, 0, 0, 1], length: 0.3 },
    { name: 'LeftForeArm',   parent: 'LeftArm',     position: [0.5, 1.5, 0], rotation: [0, 0, 0, 1], length: 0.3 },
    { name: 'LeftHand',      parent: 'LeftForeArm', position: [0.8, 1.5, 0], rotation: [0, 0, 0, 1], length: 0.15 },
    // 右腕
    { name: 'RightShoulder', parent: 'Spine2',      position: [-0.1, 1.5, 0], rotation: [0, 0, 0, 1], length: 0.1 },
    { name: 'RightArm',      parent: 'RightShoulder',position:[-0.2, 1.5, 0], rotation: [0, 0, 0, 1], length: 0.3 },
    { name: 'RightForeArm',  parent: 'RightArm',    position: [-0.5, 1.5, 0], rotation: [0, 0, 0, 1], length: 0.3 },
    { name: 'RightHand',     parent: 'RightForeArm',position: [-0.8, 1.5, 0], rotation: [0, 0, 0, 1], length: 0.15 },
    // 左脚
    { name: 'LeftUpLeg',     parent: 'Hips',        position: [0.1, 0.95, 0], rotation: [0, 0, 0, 1], length: 0.45 },
    { name: 'LeftLeg',       parent: 'LeftUpLeg',   position: [0.1, 0.5, 0], rotation: [0, 0, 0, 1], length: 0.45 },
    { name: 'LeftFoot',      parent: 'LeftLeg',     position: [0.1, 0.05, 0], rotation: [0, 0, 0, 1], length: 0.2 },
    // 右脚
    { name: 'RightUpLeg',    parent: 'Hips',        position: [-0.1, 0.95, 0], rotation: [0, 0, 0, 1], length: 0.45 },
    { name: 'RightLeg',      parent: 'RightUpLeg',  position: [-0.1, 0.5, 0], rotation: [0, 0, 0, 1], length: 0.45 },
    { name: 'RightFoot',     parent: 'RightLeg',    position: [-0.1, 0.05, 0], rotation: [0, 0, 0, 1], length: 0.2 },
  ];

  // 指ボーン (合計30本: 5本 x 3関節 x 2手)
  if (options.finger) {
    const fingers = ['Thumb', 'Index', 'Middle', 'Ring', 'Pinky'];
    for (const side of ['Left', 'Right']) {
      const hand = `${side}Hand`;
      const sign = side === 'Left' ? 1 : -1;
      for (let f = 0; f < fingers.length; f++) {
        const finger = fingers[f];
        for (let j = 1; j <= 3; j++) {
          bones.push({
            name: `${side}${finger}${j}`,
            parent: j === 1 ? hand : `${side}${finger}${j - 1}`,
            position: [sign * (0.85 + j * 0.03), 1.5, f * 0.02],
            rotation: [0, 0, 0, 1],
            length: 0.03,
          });
        }
      }
    }
  }

  // 表情ボーン (顔面: 眉・目・口角・顎)
  if (options.facialBones) {
    const facials = [
      'Jaw', 'LeftEye', 'RightEye',
      'LeftBrow', 'RightBrow',
      'LeftMouthCorner', 'RightMouthCorner',
      'Tongue1', 'Tongue2',
    ];
    for (const name of facials) {
      bones.push({
        name: `Face_${name}`,
        parent: 'Head',
        position: [0, 1.7, 0.1],
        rotation: [0, 0, 0, 1],
        length: 0.02,
      });
    }
  }

  return bones;
}

/** 単位4x4行列 */
function identityMatrix4(): number[][] {
  return [
    [1, 0, 0, 0],
    [0, 1, 0, 0],
    [0, 0, 1, 0],
    [0, 0, 0, 1],
  ];
}

// =============================================================================
// AutoRigger クラス (戦略パターン)
// =============================================================================

/**
 * AutoRigger は3つのリギング戦略を選択可能。
 *   - 'mixamo'    : Mixamo Auto-Rig API (要 ADOBE_API_KEY、将来実装)
 *   - 'rigify'    : Blender Rigify ヘッドレス実行 (要 BLENDER_PATH)
 *   - 'cascadeur' : Cascadeur 自動リグ (要 CASCADEUR_PATH)
 *   - 'mock'     : 既存テンプレ適用のみ (デフォルト、APIキー不要)
 */
export class AutoRigger {
  private strategy: 'mixamo' | 'rigify' | 'cascadeur' | 'mock';

  public constructor(strategy: 'mixamo' | 'rigify' | 'cascadeur' | 'mock' = 'mock') {
    this.strategy = strategy;
  }

  /**
   * 指定メッシュにリギングを適用する。
   * 失敗時は MockRigger にフォールバックする。
   */
  public async rig(asset: GenerateResponse, options: RigOptions = {}): Promise<RigResult> {
    const start = Date.now();
    try {
      switch (this.strategy) {
        case 'mixamo':
          return await this.rigWithMixamo(asset, options, start);
        case 'rigify':
          return await this.rigWithRigify(asset, options, start);
        case 'cascadeur':
          return await this.rigWithCascadeur(asset, options, start);
        case 'mock':
        default:
          return this.rigWithMock(asset, options, start);
      }
    } catch (err) {
      // 例外時は確実に動作する Mock リガーへフォールバック
      return this.rigWithMock(asset, options, start);
    }
  }

  /**
   * Mixamo API リギング (Adobe ID 必須、現在はスタブ実装)。
   * 実装時は POST /v2/character/upload → poll → download の流れ。
   */
  private async rigWithMixamo(
    asset: GenerateResponse,
    options: RigOptions,
    start: number
  ): Promise<RigResult> {
    const apiKey = (typeof process !== 'undefined' && process.env?.['ADOBE_API_KEY']) || '';
    if (!apiKey) {
      throw new Error('ADOBE_API_KEY not set');
    }
    // 将来実装: 実APIコール
    const skeleton = buildBipedSkeleton(options);
    return {
      riggedMeshUrl: asset.meshUrl.replace(/\.(glb|gltf|fbx|obj)$/, '_mixamo.$1'),
      skeletonJson: JSON.stringify(skeleton, null, 2),
      bindPoseMatrix: identityMatrix4(),
      boneCount: skeleton.length,
      rigger: 'Mixamo',
      durationMs: Date.now() - start,
    };
  }

  /**
   * Rigify (Blender) ヘッドレスリギング。
   * blender --background --python rigify_script.py 想定。
   */
  private async rigWithRigify(
    asset: GenerateResponse,
    options: RigOptions,
    start: number
  ): Promise<RigResult> {
    const blenderPath = (typeof process !== 'undefined' && process.env?.['BLENDER_PATH']) || '';
    if (!blenderPath) {
      throw new Error('BLENDER_PATH not set');
    }
    // 将来実装: 実 spawn 呼び出し
    const skeleton = buildBipedSkeleton(options);
    return {
      riggedMeshUrl: asset.meshUrl.replace(/\.(glb|gltf|fbx|obj)$/, '_rigify.$1'),
      skeletonJson: JSON.stringify(skeleton, null, 2),
      bindPoseMatrix: identityMatrix4(),
      boneCount: skeleton.length,
      rigger: 'Rigify',
      durationMs: Date.now() - start,
    };
  }

  /**
   * Cascadeur 自動リグ。商用ライセンス必須。
   */
  private async rigWithCascadeur(
    asset: GenerateResponse,
    options: RigOptions,
    start: number
  ): Promise<RigResult> {
    const cascPath = (typeof process !== 'undefined' && process.env?.['CASCADEUR_PATH']) || '';
    if (!cascPath) {
      throw new Error('CASCADEUR_PATH not set');
    }
    const skeleton = buildBipedSkeleton(options);
    return {
      riggedMeshUrl: asset.meshUrl.replace(/\.(glb|gltf|fbx|obj)$/, '_cascadeur.$1'),
      skeletonJson: JSON.stringify(skeleton, null, 2),
      bindPoseMatrix: identityMatrix4(),
      boneCount: skeleton.length,
      rigger: 'Cascadeur',
      durationMs: Date.now() - start,
    };
  }

  /**
   * Mock リガー (テンプレ適用のみ、APIキー不要、即時応答)。
   * humanoid: 二足歩行テンプレ、それ以外: ルートボーン1本のみ。
   */
  private rigWithMock(
    asset: GenerateResponse,
    options: RigOptions,
    start: number
  ): RigResult {
    const isHumanoid = options.humanoid !== false && options.bipedSkeleton !== false;
    const skeleton: BoneDefinition[] = isHumanoid
      ? buildBipedSkeleton(options)
      : [{ name: 'Root', parent: null, position: [0, 0, 0], rotation: [0, 0, 0, 1], length: 0 }];
    return {
      riggedMeshUrl: asset.meshUrl.replace(/\.(glb|gltf|fbx|obj)$/, '_rigged.$1') || `${asset.meshUrl}_rigged.glb`,
      skeletonJson: JSON.stringify(skeleton, null, 2),
      bindPoseMatrix: identityMatrix4(),
      boneCount: skeleton.length,
      rigger: 'MockRigger',
      durationMs: Date.now() - start,
    };
  }
}

// =============================================================================
// 公開関数
// =============================================================================

/**
 * 推奨設定で自動リギングを実行 (環境変数から自動的に戦略選定)。
 */
export async function autoRig(
  asset: GenerateResponse,
  options: RigOptions = {}
): Promise<RigResult> {
  // 優先順: ADOBE_API_KEY > BLENDER_PATH > CASCADEUR_PATH > mock
  const env = (typeof process !== 'undefined' && process.env) ? process.env : {};
  let strategy: 'mixamo' | 'rigify' | 'cascadeur' | 'mock' = 'mock';
  if (env['ADOBE_API_KEY']) strategy = 'mixamo';
  else if (env['BLENDER_PATH']) strategy = 'rigify';
  else if (env['CASCADEUR_PATH']) strategy = 'cascadeur';
  const rigger = new AutoRigger(strategy);
  return rigger.rig(asset, options);
}

/**
 * スケルトンを Three.js 互換 JSON 形式で取得。
 */
export function exportSkeletonToThreeJS(rigResult: RigResult): object {
  const bones = JSON.parse(rigResult.skeletonJson) as BoneDefinition[];
  return {
    metadata: {
      version: 4.5,
      type: 'Skeleton',
      generator: 'SoloptiLinkAI.AutoRigger',
    },
    bones: bones.map((b, i) => ({
      name: b.name,
      parent: b.parent === null ? -1 : bones.findIndex((p) => p.name === b.parent),
      position: b.position,
      quaternion: b.rotation,
      scale: [1, 1, 1],
    })),
  };
}
