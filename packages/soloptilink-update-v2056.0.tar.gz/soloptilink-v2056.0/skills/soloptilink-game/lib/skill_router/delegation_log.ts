/**
 * delegation_log.ts
 * --------------------------------------------------------------------------
 * 責務: ルーティング履歴(JSONL)の永続化、読み戻し、統計計算を提供する。
 *
 * 設計方針:
 *   - append-only JSONL (1日1ファイル) で改ざんリスクを下げる。
 *   - 統計関数 stats() で過去Nday分の集計を返す
 *     (totalRequests / 委譲先別件数 / 平均confidence / ambiguous率 / 日次件数)。
 *   - 書き込み失敗は例外を投げる(本処理側で握る設計に合わせる)。
 *
 * 依存: Node標準 (fs/path/os) のみ。
 *
 * SoloptiLinkAI v2.1 Skill Router - 委譲履歴管理層。
 * --------------------------------------------------------------------------
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import * as os from 'node:os';

import type { RouteLogEntry } from './router';

// ---------------------------------------------------------------------------
// 型定義
// ---------------------------------------------------------------------------

/** 1日分のログコンテナ */
export interface RouteLog {
  /** YYYY-MM-DD 形式の日付 */
  date: string;
  /** その日のエントリ列(時系列) */
  entries: RouteLogEntry[];
}

/** stats() の戻り値 */
export interface RouteStats {
  /** 集計対象の総リクエスト数 */
  totalRequests: number;
  /** targetSkill 別の委譲件数 (proceed/blockは集計外) */
  delegationsByDestination: Record<string, number>;
  /** confidence の平均(0.0〜1.0) */
  averageConfidence: number;
  /** ambiguous カテゴリの割合(0.0〜1.0) */
  ambiguousRate: number;
  /** 日別件数 */
  perDay: Array<{ date: string; count: number }>;
}

// ---------------------------------------------------------------------------
// RouteLogger 本体
// ---------------------------------------------------------------------------

/**
 * RouteLogger
 *   - new RouteLogger(dir) で初期化
 *   - append() で1エントリ追記
 *   - load(date) で日付指定の読み戻し
 *   - stats(daysBack) で過去N日の統計
 */
export class RouteLogger {
  /** ログ格納ディレクトリ(コンストラクタで確定) */
  public readonly logDir: string;

  constructor(logDir?: string) {
    this.logDir = logDir ?? path.join(os.homedir(), '.soloptilink', 'router-log');
  }

  /**
   * ログ用ディレクトリを作成する(存在しなければ)。
   */
  private ensureDir(): void {
    if (!fs.existsSync(this.logDir)) {
      fs.mkdirSync(this.logDir, { recursive: true });
    }
  }

  /**
   * 日付 → JSONL ファイル名。
   */
  private filenameFor(date: string): string {
    return path.join(this.logDir, `${date}.jsonl`);
  }

  /**
   * 現在日のYYYY-MM-DD文字列を返す。
   */
  private today(): string {
    const d = new Date();
    return [
      d.getFullYear(),
      String(d.getMonth() + 1).padStart(2, '0'),
      String(d.getDate()).padStart(2, '0'),
    ].join('-');
  }

  /**
   * エントリを1件追記する。
   */
  public append(entry: RouteLogEntry): void {
    this.ensureDir();
    const date = this.today();
    const file = this.filenameFor(date);
    fs.appendFileSync(file, JSON.stringify(entry) + '\n', {
      encoding: 'utf-8',
    });
  }

  /**
   * 指定日のログを読み戻す。存在しない場合は空 entries を返す。
   */
  public load(date: string): RouteLog {
    const file = this.filenameFor(date);
    if (!fs.existsSync(file)) {
      return { date, entries: [] };
    }
    const raw = fs.readFileSync(file, 'utf-8');
    const lines = raw.split('\n').filter((l) => l.trim().length > 0);
    const entries: RouteLogEntry[] = [];
    for (const line of lines) {
      try {
        const parsed = JSON.parse(line) as RouteLogEntry;
        entries.push(parsed);
      } catch {
        // 壊れた行はスキップ(append-only でも稀にfsync中断の可能性)
        continue;
      }
    }
    return { date, entries };
  }

  /**
   * 直近 daysBack 日分の統計を返す。デフォルト 7日。
   */
  public stats(daysBack = 7): RouteStats {
    const today = new Date();
    const perDay: Array<{ date: string; count: number }> = [];
    let totalRequests = 0;
    let confidenceSum = 0;
    let ambiguousCount = 0;
    const delegationsByDestination: Record<string, number> = {};

    for (let i = 0; i < daysBack; i++) {
      const d = new Date(today);
      d.setDate(today.getDate() - i);
      const ymd = [
        d.getFullYear(),
        String(d.getMonth() + 1).padStart(2, '0'),
        String(d.getDate()).padStart(2, '0'),
      ].join('-');
      const log = this.load(ymd);
      perDay.push({ date: ymd, count: log.entries.length });

      for (const entry of log.entries) {
        totalRequests += 1;
        confidenceSum += entry.action.metadata.detection.confidence;

        if (entry.action.metadata.detection.category === 'ambiguous') {
          ambiguousCount += 1;
        }

        if (
          entry.action.action === 'delegate' &&
          entry.action.targetSkill
        ) {
          const dest = entry.action.targetSkill;
          delegationsByDestination[dest] =
            (delegationsByDestination[dest] || 0) + 1;
        }
      }
    }

    // perDay は古い順に並べる
    perDay.reverse();

    const averageConfidence =
      totalRequests > 0 ? confidenceSum / totalRequests : 0;
    const ambiguousRate =
      totalRequests > 0 ? ambiguousCount / totalRequests : 0;

    return {
      totalRequests,
      delegationsByDestination,
      averageConfidence: Math.round(averageConfidence * 1000) / 1000,
      ambiguousRate: Math.round(ambiguousRate * 1000) / 1000,
      perDay,
    };
  }
}
