/**
 * router.ts
 * --------------------------------------------------------------------------
 * 責務: detector.ts の検出結果と「呼び出し元スキル(sourceSkill)」を突合し、
 *       実際の委譲アクション(delegate/proceed/confirm/block)を決定する。
 *
 * 設計方針:
 *   - 呼び出し元が /soloptilink-boost で検出カテゴリが 'game' → /soloptilink-game に委譲
 *   - 呼び出し元が /soloptilink-game で検出カテゴリが 'business' → /soloptilink-boost に委譲
 *   - 同じスキル内で整合する場合は proceed (そのまま継続)
 *   - 'ambiguous' は confirm (ユーザーに二択を提示)
 *   - 'unknown' は proceed (デフォルトで継続)
 *   - confidence の値に応じて delegate/confirm を切り替える
 *     (>=0.7: delegate / 0.4-0.7: confirm / <0.4: proceed)
 *
 * 依存: detector.ts のみ。Node fs/path は logRoute() でのみ使用。
 *
 * SoloptiLinkAI v2.1 Skill Router - 業務系/ゲーム生成の自動振り分けに使用。
 * --------------------------------------------------------------------------
 */

import { detect, DetectionResult } from './detector';
import * as fs from 'node:fs';
import * as path from 'node:path';
import * as os from 'node:os';

// ---------------------------------------------------------------------------
// 型定義
// ---------------------------------------------------------------------------

/** ルーティングアクションの種類 */
export type RouteActionKind = 'delegate' | 'proceed' | 'confirm' | 'block';

/** 呼び出し元スキル(認識可能なもの) */
export type SourceSkill =
  | 'soloptilink-boost'
  | 'soloptilink-game'
  | 'soloptilink'
  | 'other';

/** ルーティングアクション本体 */
export interface RouteAction {
  /** 実行すべきアクション */
  action: RouteActionKind;
  /** 委譲先スキル(action=delegate/confirm のとき設定) */
  targetSkill?: string;
  /** 判定理由(日本語) */
  reasoning: string;
  /** ユーザーへの案内文(日本語、UIに出してOKなトーン) */
  guidanceMessage: string;
  /** ユーザーに見せるべきか(true=見せる / false=内部処理のみ) */
  shouldShowToUser: boolean;
  /** メタデータ(ログ用) */
  metadata: {
    detection: DetectionResult;
    sourceSkill: SourceSkill;
    timestamp: string;
  };
}

/** ログエントリ */
export interface RouteLogEntry {
  timestamp: string;
  input: string;
  sourceSkill: string;
  action: RouteAction;
}

// ---------------------------------------------------------------------------
// 内部ヘルパー
// ---------------------------------------------------------------------------

/**
 * sourceSkill 文字列を SourceSkill 列挙に正規化する。
 */
function normalizeSourceSkill(s: string): SourceSkill {
  const lower = (s || '').toLowerCase().trim();
  if (lower === 'soloptilink-boost' || lower === 'boost') {
    return 'soloptilink-boost';
  }
  if (lower === 'soloptilink-game' || lower === 'game') {
    return 'soloptilink-game';
  }
  if (lower === 'soloptilink') {
    return 'soloptilink';
  }
  return 'other';
}

/**
 * confidence しきい値の判定。
 *   - >= 0.7  → 自動委譲(delegate)
 *   - 0.4-0.7 → 確認(confirm)
 *   - < 0.4   → 継続(proceed)
 */
function confidenceToTier(c: number): 'high' | 'medium' | 'low' {
  if (c >= 0.7) return 'high';
  if (c >= 0.4) return 'medium';
  return 'low';
}

/**
 * 委譲先スキル名から日本語の説明を返す。
 */
function describeSkill(skill: string): string {
  switch (skill) {
    case 'soloptilink-game':
      return '/soloptilink-game (Game Production Engine, Game Quality Fortress 12軸, 5エージェント)';
    case 'soloptilink-boost':
      return '/soloptilink-boost (業務系SaaS, Quality Fortress 71軸, 105エージェント Centuria Swarm)';
    case 'soloptilink':
      return '/soloptilink (汎用モード)';
    default:
      return skill;
  }
}

/**
 * confirm アクション用の二択案内文を生成する。
 */
function buildAmbiguousConfirmMessage(detection: DetectionResult): string {
  return [
    '入力にゲーム要素と業務系要素の両方が含まれています。',
    `ゲームスコア=${detection.gameScore}, 業務スコア=${detection.businessScore}`,
    'どちらのモードで生成しますか?',
    '  (A) ゲームとして作る → /soloptilink-game に委譲します',
    '  (B) 業務システムとして作る → /soloptilink-boost に委譲します',
    '  (C) ゲーミフィケーション要素のある業務システム → /soloptilink-boost で業務軸メインで進めます',
    '回答 (A/B/C) を指示してください。',
  ].join('\n');
}

// ---------------------------------------------------------------------------
// 公開関数: ルーティング決定
// ---------------------------------------------------------------------------

/**
 * 入力と呼び出し元スキルから RouteAction を決定する。
 */
export function route(input: string, sourceSkill: string): RouteAction {
  const detection = detect(input);
  const source = normalizeSourceSkill(sourceSkill);
  const tier = confidenceToTier(detection.confidence);
  const timestamp = new Date().toISOString();

  // ---- カテゴリ × source × confidence の決定表 ----

  // 1) unknown: 何も検出されない → そのまま継続
  if (detection.category === 'unknown') {
    return {
      action: 'proceed',
      reasoning:
        'ゲーム/業務系どちらのキーワードも検出されませんでした。呼び出し元スキルでそのまま継続します。',
      guidanceMessage:
        '振り分け判定: キーワード検出なし。現行スキルで処理を継続します。',
      shouldShowToUser: false,
      metadata: { detection, sourceSkill: source, timestamp },
    };
  }

  // 2) ambiguous: confirm 必須
  if (detection.category === 'ambiguous') {
    return {
      action: 'confirm',
      reasoning:
        'ゲーム要素と業務系要素の両方が同程度に検出されました。自動判定ではなくユーザー確認が必要です。',
      guidanceMessage: buildAmbiguousConfirmMessage(detection),
      shouldShowToUser: true,
      metadata: { detection, sourceSkill: source, timestamp },
    };
  }

  // 3) game カテゴリ
  if (detection.category === 'game') {
    if (source === 'soloptilink-game') {
      // 既にゲームスキル内 → そのまま継続
      return {
        action: 'proceed',
        reasoning:
          'ゲーム生成意図が検出されましたが、既に /soloptilink-game 内のため継続します。',
        guidanceMessage: '振り分け判定: ゲーム生成 → 現行スキルで継続。',
        shouldShowToUser: false,
        metadata: { detection, sourceSkill: source, timestamp },
      };
    }

    // boost / soloptilink / other からの呼び出し → game に委譲提案
    if (tier === 'high') {
      return {
        action: 'delegate',
        targetSkill: 'soloptilink-game',
        reasoning: `ゲーム生成意図が高い確信度(${detection.confidence})で検出されました。/soloptilink-game への自動委譲を行います。`,
        guidanceMessage: [
          `振り分け判定: ゲーム生成 (confidence=${detection.confidence})`,
          `委譲先: ${describeSkill('soloptilink-game')}`,
          `理由: ${detection.delegationMessage}`,
          '※ 業務系アーキテクチャ(Next.js+Prisma+71軸)とゲームエンジンアーキテクチャの衝突を防ぐため、ゲームスキルに切り替えます。',
        ].join('\n'),
        shouldShowToUser: true,
        metadata: { detection, sourceSkill: source, timestamp },
      };
    }
    if (tier === 'medium') {
      return {
        action: 'confirm',
        targetSkill: 'soloptilink-game',
        reasoning: `ゲーム生成意図が中程度の確信度(${detection.confidence})で検出されました。ユーザー確認の上で /soloptilink-game に委譲することを推奨します。`,
        guidanceMessage: [
          `振り分け判定: ゲーム生成の可能性あり (confidence=${detection.confidence})`,
          `委譲候補: ${describeSkill('soloptilink-game')}`,
          'ゲームとして生成しますか? それとも現行スキル(業務系)で継続しますか?',
          '  (Y) /soloptilink-game に委譲',
          '  (N) 現行スキルで継続',
        ].join('\n'),
        shouldShowToUser: true,
        metadata: { detection, sourceSkill: source, timestamp },
      };
    }
    // low: そのまま継続(キーワードは見えたが弱い)
    return {
      action: 'proceed',
      reasoning: `ゲーム生成意図が弱い確信度(${detection.confidence})でしか検出されませんでした。現行スキルで継続します。`,
      guidanceMessage: '振り分け判定: ゲーム関連語あり、ただし低確信度のため現行スキルで継続。',
      shouldShowToUser: false,
      metadata: { detection, sourceSkill: source, timestamp },
    };
  }

  // 4) business カテゴリ
  if (detection.category === 'business') {
    if (source === 'soloptilink-boost' || source === 'soloptilink') {
      // 既に業務系スキル内 → そのまま継続
      return {
        action: 'proceed',
        reasoning:
          '業務系生成意図が検出されましたが、既に業務系スキル内のため継続します。',
        guidanceMessage: '振り分け判定: 業務系生成 → 現行スキルで継続。',
        shouldShowToUser: false,
        metadata: { detection, sourceSkill: source, timestamp },
      };
    }

    // game / other からの呼び出し → boost に委譲提案
    if (tier === 'high') {
      return {
        action: 'delegate',
        targetSkill: 'soloptilink-boost',
        reasoning: `業務系生成意図が高い確信度(${detection.confidence})で検出されました。/soloptilink-boost への自動委譲を行います。`,
        guidanceMessage: [
          `振り分け判定: 業務系生成 (confidence=${detection.confidence})`,
          `委譲先: ${describeSkill('soloptilink-boost')}`,
          `理由: ${detection.delegationMessage}`,
          '※ ゲームエンジン構成と業務系SaaSアーキテクチャの衝突を防ぐため、業務系スキルに切り替えます。',
        ].join('\n'),
        shouldShowToUser: true,
        metadata: { detection, sourceSkill: source, timestamp },
      };
    }
    if (tier === 'medium') {
      return {
        action: 'confirm',
        targetSkill: 'soloptilink-boost',
        reasoning: `業務系生成意図が中程度の確信度(${detection.confidence})で検出されました。ユーザー確認の上で /soloptilink-boost に委譲することを推奨します。`,
        guidanceMessage: [
          `振り分け判定: 業務系生成の可能性あり (confidence=${detection.confidence})`,
          `委譲候補: ${describeSkill('soloptilink-boost')}`,
          '業務系として生成しますか? それとも現行スキル(ゲーム)で継続しますか?',
          '  (Y) /soloptilink-boost に委譲',
          '  (N) 現行スキルで継続',
        ].join('\n'),
        shouldShowToUser: true,
        metadata: { detection, sourceSkill: source, timestamp },
      };
    }
    // low: そのまま継続
    return {
      action: 'proceed',
      reasoning: `業務系生成意図が弱い確信度(${detection.confidence})でしか検出されませんでした。現行スキルで継続します。`,
      guidanceMessage: '振り分け判定: 業務系関連語あり、ただし低確信度のため現行スキルで継続。',
      shouldShowToUser: false,
      metadata: { detection, sourceSkill: source, timestamp },
    };
  }

  // フォールバック(到達しないはず)
  return {
    action: 'proceed',
    reasoning: 'フォールバック: 未定義のカテゴリ。現行スキルで継続します。',
    guidanceMessage: '振り分け判定: 不明。現行スキルで継続。',
    shouldShowToUser: false,
    metadata: { detection, sourceSkill: source, timestamp },
  };
}

// ---------------------------------------------------------------------------
// ログ書き込み(append-only JSONL)
// ---------------------------------------------------------------------------

/**
 * デフォルトのログディレクトリを返す。
 * デフォルト: ~/.soloptilink/router-log/
 */
function defaultLogDir(): string {
  return path.join(os.homedir(), '.soloptilink', 'router-log');
}

/**
 * 日付ベース(YYYY-MM-DD)で JSONL ファイル名を生成する。
 */
function jsonlFilenameFor(date: Date): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}.jsonl`;
}

/**
 * ルーティング結果をJSONL形式で永続化する。
 * 失敗してもメイン処理は継続できるよう例外を握る。
 */
export function logRoute(entry: RouteLogEntry, logDir?: string): void {
  try {
    const dir = logDir ?? defaultLogDir();
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    const filename = jsonlFilenameFor(new Date());
    const fullPath = path.join(dir, filename);
    const line = JSON.stringify(entry) + '\n';
    fs.appendFileSync(fullPath, line, { encoding: 'utf-8' });
  } catch (e) {
    // ログ失敗はサイレントに(本処理を止めない)
    // 必要なら stderr 出力
    if (process.env.SOLOPTILINK_ROUTER_DEBUG === '1') {
      console.error('[skill_router] logRoute failed:', e);
    }
  }
}

/**
 * ルーティング + ログを一括で行う便利関数。
 */
export function routeAndLog(
  input: string,
  sourceSkill: string,
  logDir?: string
): RouteAction {
  const action = route(input, sourceSkill);
  const entry: RouteLogEntry = {
    timestamp: action.metadata.timestamp,
    input,
    sourceSkill,
    action,
  };
  logRoute(entry, logDir);
  return action;
}
