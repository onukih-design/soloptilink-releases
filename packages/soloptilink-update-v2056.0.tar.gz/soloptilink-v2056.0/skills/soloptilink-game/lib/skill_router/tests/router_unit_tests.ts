// ============================================================================
// router_unit_tests.ts - router.ts ユニットテスト (SoloptiLinkAI v2.1)
// ----------------------------------------------------------------------------
// router.ts の route(input, sourceSkill) が返す RouteAction を、
// 「呼び出し元 → 入力 → アクション + 委譲先」の組み合わせで検証する。
//
// 期待する RouteAction 形:
//   {
//     action: 'delegate' | 'proceed' | 'confirm' | 'block',
//     targetSkill?: 'soloptilink-game' | 'soloptilink-boost',
//     sourceSkill: string,
//     category: 'game' | 'business' | 'ambiguous' | 'unknown',
//     confidence: number,
//     guidanceMessage: string
//   }
//
// 使い方:
//   npx ts-node lib/skill_router/tests/router_unit_tests.ts
// ============================================================================

type Action = 'delegate' | 'proceed' | 'confirm' | 'block';
type Category = 'game' | 'business' | 'ambiguous' | 'unknown';

interface RouteAction {
  action: Action;
  targetSkill?: string;
  sourceSkill: string;
  category: Category;
  confidence: number;
  guidanceMessage: string;
}

type RouteFn = (input: string, sourceSkill?: string) => RouteAction;

// ---- router.ts ロード ----
let route: RouteFn;
try {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const mod = require('../router');
  if (typeof mod.route === 'function') {
    route = mod.route as RouteFn;
  } else {
    route = inlineRoute;
  }
} catch {
  route = inlineRoute;
}

// ---- インライン fallback router (本体未実装時用) ----
const GAME_STRONG = [
  'ノベルゲーム','アクションゲーム','RPG','シューティング','FPS','TPS','VR','3Dゲーム',
  'Three.js','Phaser','PixiJS','Godot','Unity','Unreal','マリオ風','テトリス',
  '倉庫番','オセロ','将棋','迷路','レーシング','フライトシム','クリッカー',
  'パズルゲーム','リズムゲーム','プレイテスト','GDD','プロシージャル生成',
];
const GAME_MODERATE = [
  'ゲーム','プレイヤー','ステージ','スコア','レベル','敵','弾','ジャンプ',
  'スプライト','物理演算','衝突判定','Mixamo','ボードゲーム','ノベル','3D','プレイ',
];
const GAME_WEAK = ['FPS計測','frame','ゲーム性','game'];
const BIZ_STRONG = [
  '請求書','見積書','CRM','ERP','工事台帳','受発注','物件管理','介護記録',
  'レセプト','学籍管理','顧客管理','受注管理','経費精算','勤怠','帳票',
  '業務システム','基幹システム','管理画面','admin dashboard','RFP',
  '提案書','検収','Tenant DNA','顧客DNA',
];
const BIZ_MODERATE = [
  'Next.js','Prisma','CRUD','業務','顧客','契約','売上','原価','在庫','WBS',
  '見積','請求','売掛','買掛','給与','人事','申請','承認','ワークフロー',
];
const BIZ_WEAK = ['管理','システム','データベース','レポート','フォーム','テーブル'];

function inlineDetect(input: string): { category: Category; confidence: number; gameScore: number; businessScore: number } {
  const low = (input || '').toLowerCase();
  let gScore = 0, bScore = 0;
  for (const kw of GAME_STRONG) if (low.includes(kw.toLowerCase())) gScore += 5;
  for (const kw of GAME_MODERATE) if (low.includes(kw.toLowerCase())) gScore += 3;
  for (const kw of GAME_WEAK) if (low.includes(kw.toLowerCase())) gScore += 1;
  for (const kw of BIZ_STRONG) if (low.includes(kw.toLowerCase())) bScore += 5;
  for (const kw of BIZ_MODERATE) if (low.includes(kw.toLowerCase())) bScore += 3;
  for (const kw of BIZ_WEAK) if (low.includes(kw.toLowerCase())) bScore += 1;
  if (low.includes('ゲーミフィケーション')) { gScore = Math.max(0, gScore - 3); bScore += 2; }
  let category: Category = 'unknown';
  if (gScore + bScore === 0) category = 'unknown';
  else if (gScore >= bScore * 2 && gScore >= 5) category = 'game';
  else if (bScore >= gScore * 2 && bScore >= 5) category = 'business';
  else if (Math.abs(gScore - bScore) < 5) category = 'ambiguous';
  else if (gScore > bScore) category = 'game';
  else category = 'business';
  const confidence = Math.min(1, Math.abs(gScore - bScore) / 20);
  return { category, confidence: Number(confidence.toFixed(3)), gameScore: gScore, businessScore: bScore };
}

function inlineRoute(input: string, sourceSkill: string = 'other'): RouteAction {
  const d = inlineDetect(input);
  let action: Action = 'proceed';
  let targetSkill: string | undefined;
  let msg = '';
  const cat = d.category;

  // 信頼度が低すぎる game/business は ambiguous 扱いに格下げ
  const cat2: Category = (cat === 'game' || cat === 'business') && d.confidence < 0.2 ? 'ambiguous' : cat;

  if (cat2 === 'unknown') {
    action = 'confirm';
    msg = '指示の意図が判定できません。ゲームか業務系かを明示してください。';
  } else if (cat2 === 'ambiguous') {
    action = 'confirm';
    msg = 'ゲーム要素と業務系要素が混在しています。どちらを優先しますか?';
  } else if (cat2 === 'game') {
    if (sourceSkill === 'soloptilink-game' || sourceSkill === 'game') {
      action = 'proceed';
      msg = 'ゲーム生成として継続します。';
    } else {
      action = 'delegate';
      targetSkill = 'soloptilink-game';
      msg = 'ゲーム生成として /soloptilink-game に委譲します。';
    }
  } else if (cat2 === 'business') {
    if (sourceSkill === 'soloptilink-boost' || sourceSkill === 'boost') {
      action = 'proceed';
      msg = '業務系生成として継続します。';
    } else {
      action = 'delegate';
      targetSkill = 'soloptilink-boost';
      msg = '業務系生成として /soloptilink-boost に委譲します。';
    }
  }
  return {
    action, targetSkill,
    sourceSkill: sourceSkill || 'other',
    category: cat2,
    confidence: d.confidence,
    guidanceMessage: msg,
  };
}

// ---- テストケース ----
interface UnitTest {
  name: string;
  input: string;
  sourceSkill: string;
  expectedAction: Action;
  expectedTarget?: string;
  expectedCategory?: Category;
  notes?: string;
}

const tests: UnitTest[] = [
  // (1) BOOST → ゲーム指示 → game へ委譲
  {
    name: 'BOOSTでノベルゲーム指示 → game へ委譲',
    input: 'ノベルゲーム作って',
    sourceSkill: 'soloptilink-boost',
    expectedAction: 'delegate',
    expectedTarget: 'soloptilink-game',
    expectedCategory: 'game',
  },
  {
    name: 'BOOSTでマリオ風指示 → game へ委譲',
    input: 'マリオ風横スクロールゲームを作って',
    sourceSkill: 'soloptilink-boost',
    expectedAction: 'delegate',
    expectedTarget: 'soloptilink-game',
    expectedCategory: 'game',
  },
  {
    name: 'BOOSTでUnity VR → game へ委譲',
    input: 'UnityでVRゲーム作りたい',
    sourceSkill: 'soloptilink-boost',
    expectedAction: 'delegate',
    expectedTarget: 'soloptilink-game',
    expectedCategory: 'game',
  },
  // (2) game → 業務系指示 → boost へ委譲
  {
    name: 'gameで請求書指示 → boost へ委譲',
    input: '請求書発行システムを作って',
    sourceSkill: 'soloptilink-game',
    expectedAction: 'delegate',
    expectedTarget: 'soloptilink-boost',
    expectedCategory: 'business',
  },
  {
    name: 'gameで工事台帳指示 → boost へ委譲',
    input: '工事台帳管理システム',
    sourceSkill: 'soloptilink-game',
    expectedAction: 'delegate',
    expectedTarget: 'soloptilink-boost',
    expectedCategory: 'business',
  },
  // (3) BOOST → 業務系指示 → proceed
  {
    name: 'BOOSTで業務系指示 → そのまま継続',
    input: 'CRMをNext.jsで構築',
    sourceSkill: 'soloptilink-boost',
    expectedAction: 'proceed',
    expectedCategory: 'business',
  },
  {
    name: 'BOOSTで顧客管理 → そのまま継続',
    input: '顧客管理 + 売掛買掛の業務システム',
    sourceSkill: 'soloptilink-boost',
    expectedAction: 'proceed',
    expectedCategory: 'business',
  },
  // (4) game → ゲーム指示 → proceed
  {
    name: 'gameで3Dアクション指示 → そのまま継続',
    input: '3Dアクションゲーム作って',
    sourceSkill: 'soloptilink-game',
    expectedAction: 'proceed',
    expectedCategory: 'game',
  },
  {
    name: 'gameでPhaserパズル → そのまま継続',
    input: 'Phaserでパズルゲームを作って',
    sourceSkill: 'soloptilink-game',
    expectedAction: 'proceed',
    expectedCategory: 'game',
  },
  // (5) 曖昧 → confirm
  {
    name: '曖昧入力 (ゲーミフィケーション) → confirm',
    input: 'ゲーミフィケーション要素のあるタスク管理',
    sourceSkill: 'soloptilink-boost',
    expectedAction: 'confirm',
    expectedCategory: 'ambiguous',
  },
  {
    name: '曖昧入力 (社員教育ゲーム) → confirm',
    input: '社員向けの教育ゲーム + 学習管理',
    sourceSkill: 'soloptilink-boost',
    expectedAction: 'confirm',
    expectedCategory: 'ambiguous',
  },
  // (6) other ソース からの委譲
  {
    name: 'other ソースからゲーム → game へ委譲',
    input: 'Three.jsで3D迷路',
    sourceSkill: 'other',
    expectedAction: 'delegate',
    expectedTarget: 'soloptilink-game',
    expectedCategory: 'game',
  },
  {
    name: 'other ソースから業務系 → boost へ委譲',
    input: 'admin dashboard + Prismaで管理画面',
    sourceSkill: 'other',
    expectedAction: 'delegate',
    expectedTarget: 'soloptilink-boost',
    expectedCategory: 'business',
  },
  // (7) unknown → confirm
  {
    name: '無関係入力 → confirm',
    input: 'こんにちは',
    sourceSkill: 'other',
    expectedAction: 'confirm',
    expectedCategory: 'unknown',
  },
  // (8) confidence 低い game-like → 曖昧扱い
  {
    name: '弱いゲームキーワードのみ → confirm',
    input: 'gameっぽい何か',
    sourceSkill: 'soloptilink-boost',
    expectedAction: 'confirm',
  },
];

// ---- テストランナー ----
interface CaseResult {
  name: string;
  passed: boolean;
  reasons: string[];
  actual: RouteAction;
  expected: UnitTest;
}

export function runAll(): { passed: number; failed: number; details: CaseResult[] } {
  const details: CaseResult[] = [];
  let passed = 0, failed = 0;
  for (const t of tests) {
    const actual = route(t.input, t.sourceSkill);
    const reasons: string[] = [];
    let ok = true;
    if (actual.action !== t.expectedAction) {
      ok = false;
      reasons.push(`action expected=${t.expectedAction} actual=${actual.action}`);
    }
    if (t.expectedTarget && actual.targetSkill !== t.expectedTarget) {
      ok = false;
      reasons.push(`target expected=${t.expectedTarget} actual=${actual.targetSkill ?? '(none)'}`);
    }
    if (t.expectedCategory && actual.category !== t.expectedCategory) {
      ok = false;
      reasons.push(`category expected=${t.expectedCategory} actual=${actual.category}`);
    }
    details.push({ name: t.name, passed: ok, reasons, actual, expected: t });
    if (ok) passed++; else failed++;
  }
  return { passed, failed, details };
}

function printDetails(result: { passed: number; failed: number; details: CaseResult[] }): void {
  console.log('');
  console.log('======================================================');
  console.log('   Skill Router router.ts ユニットテスト');
  console.log('======================================================');
  for (const d of result.details) {
    const mark = d.passed ? 'PASS' : 'FAIL';
    console.log(`  [${mark}] ${d.name}`);
    if (!d.passed) {
      console.log(`         入力: "${d.expected.input}" (source: ${d.expected.sourceSkill})`);
      for (const r of d.reasons) console.log(`         - ${r}`);
      console.log(`         actual: action=${d.actual.action} target=${d.actual.targetSkill ?? '-'} category=${d.actual.category} conf=${d.actual.confidence}`);
    }
  }
  const total = result.passed + result.failed;
  console.log('  ---------------------------------------------------');
  console.log(`  Unit Tests: ${result.passed} / ${total} PASS  (${result.failed} FAIL)`);
  console.log('======================================================');
}

// ---- CLI エントリ ----
if (require.main === module) {
  const r = runAll();
  printDetails(r);
  console.log(`Unit Tests: ${r.passed}/${r.passed + r.failed} PASS`);
  process.exit(r.failed > 0 ? 1 : 0);
}
