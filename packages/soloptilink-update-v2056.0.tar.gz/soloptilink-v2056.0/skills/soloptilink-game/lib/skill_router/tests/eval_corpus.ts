// ============================================================================
// eval_corpus.ts - Skill Router 精度評価ハーネス (SoloptiLinkAI v2.1)
// ----------------------------------------------------------------------------
// detector.ts の detect(input) を 3 種類のコーパスで実走し、
// カテゴリ判定精度と信頼度を集計するハーネス。
//
// コーパスは lib/skill_router/corpus/{game_positive,business_positive,ambiguous}.json
//   形式: { label: "game"|"business"|"ambiguous",
//           entries: [{ input, expectedCategory?, expectedConfidence? }] }
//
// 使い方:
//   npx ts-node lib/skill_router/tests/eval_corpus.ts
//   または node --loader ts-node/esm lib/skill_router/tests/eval_corpus.ts
// ============================================================================

// ---- 動的 import (本体 detector.ts 未配置でも単独動作するため) ----
type Category = 'game' | 'business' | 'ambiguous' | 'unknown';

interface DetectionResult {
  category: Category;
  confidence: number;
  gameScore: number;
  businessScore: number;
  matchedGame?: string[];
  matchedBusiness?: string[];
  reason?: string;
}

type DetectFn = (input: string) => DetectionResult;

// detector.ts を試行ロード、不在ならインライン版を使う
let detect: DetectFn;
try {
  // 相対 import を try-catch
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const mod = require('../detector');
  if (typeof mod.detect === 'function') {
    detect = mod.detect as DetectFn;
  } else {
    detect = inlineDetect;
  }
} catch {
  detect = inlineDetect;
}

// ---- インライン fallback detector (本体未実装時用) ----
const GAME_STRONG = [
  'ノベルゲーム','アクションゲーム','RPG','シューティング','FPS','TPS','VR','3Dゲーム',
  'Three.js','Phaser','PixiJS','Godot','Unity','Unreal','マリオ風','テトリス',
  '倉庫番','オセロ','将棋','迷路','レーシング','フライトシム','クリッカー',
  'パズルゲーム','リズムゲーム','プレイテスト','GDD','プロシージャル生成'
];
const GAME_MODERATE = [
  'ゲーム','プレイヤー','ステージ','スコア','レベル','敵','弾','ジャンプ',
  'スプライト','物理演算','衝突判定','Wave Function Collapse','Mixamo',
  'Cascadeur','ボードゲーム','ノベル','3D','プレイ','ハイパーカジュアル'
];
const GAME_WEAK = [
  'FPS計測','frame','ゲーム性','game','プレイヤー数','チュートリアル'
];
const BIZ_STRONG = [
  '請求書','見積書','CRM','ERP','工事台帳','受発注','物件管理','介護記録',
  'レセプト','学籍管理','顧客管理','受注管理','経費精算','勤怠','帳票',
  '業務システム','基幹システム','管理画面','admin dashboard','RFP',
  '提案書','検収','Tenant DNA','顧客DNA'
];
const BIZ_MODERATE = [
  'Next.js','Prisma','CRUD','業務','顧客','契約','売上','原価','在庫','WBS',
  '見積','請求','売掛','買掛','給与','人事','申請','承認','ワークフロー'
];
const BIZ_WEAK = [
  '管理','システム','データベース','レポート','フォーム','テーブル'
];

function inlineDetect(input: string): DetectionResult {
  const low = (input || '').toLowerCase();
  let gScore = 0, bScore = 0;
  const gMatch: string[] = [], bMatch: string[] = [];

  for (const kw of GAME_STRONG) if (low.includes(kw.toLowerCase())) { gScore += 5; gMatch.push(kw); }
  for (const kw of GAME_MODERATE) if (low.includes(kw.toLowerCase())) { gScore += 3; gMatch.push(kw); }
  for (const kw of GAME_WEAK) if (low.includes(kw.toLowerCase())) { gScore += 1; gMatch.push(kw); }
  for (const kw of BIZ_STRONG) if (low.includes(kw.toLowerCase())) { bScore += 5; bMatch.push(kw); }
  for (const kw of BIZ_MODERATE) if (low.includes(kw.toLowerCase())) { bScore += 3; bMatch.push(kw); }
  for (const kw of BIZ_WEAK) if (low.includes(kw.toLowerCase())) { bScore += 1; bMatch.push(kw); }

  // 否定パターン
  if (low.includes('ゲーミフィケーション')) {
    gScore = Math.max(0, gScore - 3);
    bScore += 2;
  }

  let category: Category = 'unknown';
  if (gScore + bScore === 0) {
    category = 'unknown';
  } else if (gScore >= bScore * 2 && gScore >= 5) {
    category = 'game';
  } else if (bScore >= gScore * 2 && bScore >= 5) {
    category = 'business';
  } else if (Math.abs(gScore - bScore) < 5) {
    category = 'ambiguous';
  } else if (gScore > bScore) {
    category = 'game';
  } else {
    category = 'business';
  }
  const confidence = Math.min(1, Math.abs(gScore - bScore) / 20);
  return {
    category, confidence: Number(confidence.toFixed(3)),
    gameScore: gScore, businessScore: bScore,
    matchedGame: gMatch.slice(0, 5), matchedBusiness: bMatch.slice(0, 5),
    reason: 'inline_fallback_detector',
  };
}

// ---- コーパス型定義 ----
export interface CorpusEntry {
  input: string;
  expectedCategory?: Category;
  expectedConfidence?: string; // 例: ">= 0.9", "< 0.3"
  note?: string;
}

export interface Corpus {
  label: Category;
  entries: CorpusEntry[];
}

export interface EvalResult {
  total: number;
  passed: number;
  failed: number;
  perCategoryAccuracy: Record<string, { total: number; passed: number; rate: number }>;
  failures: Array<{ input: string; expected: { category?: Category; confidence?: string }; actual: DetectionResult }>;
}

// ---- 信頼度期待値の比較 ----
function checkConfidence(expected: string | undefined, actual: number): boolean {
  if (!expected) return true;
  const trimmed = expected.replace(/\s+/g, '');
  const m = trimmed.match(/^(>=|<=|>|<|==|=)?([0-9.]+)$/);
  if (!m) return true;
  const op = m[1] || '>=';
  const v = parseFloat(m[2]);
  switch (op) {
    case '>=': return actual >= v;
    case '<=': return actual <= v;
    case '>':  return actual > v;
    case '<':  return actual < v;
    case '==':
    case '=':  return Math.abs(actual - v) < 1e-6;
    default:   return true;
  }
}

// ---- 単一コーパス評価 ----
export function evaluate(corpus: Corpus): EvalResult {
  const result: EvalResult = {
    total: 0, passed: 0, failed: 0,
    perCategoryAccuracy: {},
    failures: [],
  };
  const defaultCat = corpus.label;
  for (const entry of corpus.entries || []) {
    result.total++;
    const expected = entry.expectedCategory || defaultCat;
    const actual = detect(entry.input);
    const catOK = actual.category === expected;
    const confOK = checkConfidence(entry.expectedConfidence, actual.confidence);
    if (catOK && confOK) {
      result.passed++;
    } else {
      result.failed++;
      result.failures.push({
        input: entry.input,
        expected: { category: expected, confidence: entry.expectedConfidence },
        actual,
      });
    }
    if (!result.perCategoryAccuracy[expected]) {
      result.perCategoryAccuracy[expected] = { total: 0, passed: 0, rate: 0 };
    }
    const slot = result.perCategoryAccuracy[expected];
    slot.total++;
    if (catOK && confOK) slot.passed++;
    slot.rate = slot.total === 0 ? 0 : slot.passed / slot.total;
  }
  return result;
}

// ---- 複数コーパス統合 ----
export function evaluateAll(corpora: Corpus[]): EvalResult {
  const merged: EvalResult = {
    total: 0, passed: 0, failed: 0,
    perCategoryAccuracy: {}, failures: [],
  };
  for (const c of corpora) {
    const r = evaluate(c);
    merged.total += r.total;
    merged.passed += r.passed;
    merged.failed += r.failed;
    merged.failures.push(...r.failures);
    for (const k of Object.keys(r.perCategoryAccuracy)) {
      const src = r.perCategoryAccuracy[k];
      const dst = merged.perCategoryAccuracy[k] || { total: 0, passed: 0, rate: 0 };
      dst.total += src.total;
      dst.passed += src.passed;
      dst.rate = dst.total === 0 ? 0 : dst.passed / dst.total;
      merged.perCategoryAccuracy[k] = dst;
    }
  }
  return merged;
}

// ---- 整形出力 ----
function pct(n: number, d: number): string {
  if (d === 0) return '0.0%';
  return `${((n / d) * 100).toFixed(1)}%`;
}

function printResult(corpora: Corpus[], merged: EvalResult): void {
  console.log('');
  console.log('======================================================');
  console.log('       Skill Router 精度評価 (eval_corpus.ts)');
  console.log('======================================================');
  for (const c of corpora) {
    const r = evaluate(c);
    const labelJp = c.label === 'game' ? 'ゲーム陽性'
      : c.label === 'business' ? '業務系陽性'
      : c.label === 'ambiguous' ? '曖昧'
      : c.label;
    const pad = labelJp.padEnd(10, ' ');
    console.log(`  ${pad}  ${r.passed} / ${r.total}  (${pct(r.passed, r.total)})`);
  }
  console.log('  ---------------------------------------------------');
  console.log(`  総合          ${merged.passed} / ${merged.total}  (${pct(merged.passed, merged.total)})`);
  if (merged.failures.length > 0) {
    console.log('');
    console.log('  失敗ケース:');
    for (const f of merged.failures.slice(0, 20)) {
      const exp = f.expected.category || '?';
      const act = f.actual.category;
      console.log(`    - "${f.input}"`);
      console.log(`      expected: ${exp}, actual: ${act} (g:${f.actual.gameScore}, b:${f.actual.businessScore}, conf:${f.actual.confidence})`);
    }
    if (merged.failures.length > 20) {
      console.log(`    ... 他 ${merged.failures.length - 20} 件`);
    }
  }
  console.log('======================================================');
  const accuracy = merged.total === 0 ? 0 : merged.passed / merged.total;
  const verdict = accuracy >= 0.85 ? 'PASS' : 'FAIL';
  console.log(`  全体精度: ${pct(merged.passed, merged.total)}  判定: ${verdict} (>=85% 期待)`);
  console.log('======================================================');
}

// ---- コーパスロード (JSON 不在時はインライン例を使用) ----
function loadCorpus(name: string, fallback: Corpus): Corpus {
  try {
    // eslint-disable-next-line @typescript-eslint/no-var-requires
    const fs = require('fs');
    const path = require('path');
    const p = path.resolve(__dirname, '..', 'corpus', `${name}.json`);
    if (fs.existsSync(p)) {
      const txt = fs.readFileSync(p, 'utf8');
      const j = JSON.parse(txt);
      if (j && Array.isArray(j.entries) && j.label) return j as Corpus;
    }
  } catch {
    /* ignore */
  }
  return fallback;
}

// ---- インラインコーパス (JSON 不在時のフォールバック) ----
const INLINE_GAME_POS: Corpus = {
  label: 'game',
  entries: [
    { input: 'ノベルゲーム作って', expectedConfidence: '>= 0.2' },
    { input: 'マリオ風横スクロールゲーム', expectedConfidence: '>= 0.2' },
    { input: 'Three.jsで3D迷路ゲーム' },
    { input: '倉庫番100ステージのパズルゲーム' },
    { input: 'オセロのAI対戦をブラウザで' },
    { input: 'Phaserでハイパーカジュアル' },
    { input: 'PixiJSで2DシューティングゲームをWebGLで' },
    { input: 'UnityでVRゲーム作りたい' },
    { input: 'Unreal EngineでFPSゲーム' },
    { input: 'Godotで2D RPG' },
    { input: 'テトリス風パズルゲーム' },
    { input: 'クリッカーゲームを作って' },
    { input: 'フライトシムのプレイテスト' },
    { input: 'プロシージャル生成で迷路ダンジョン' },
    { input: '将棋アプリ', expectedConfidence: '>= 0' },
    { input: 'リズムゲーム作って' },
    { input: 'GDDからプロトタイプ' },
    { input: 'レーシングゲームを3Dで' },
    { input: 'Mixamoでキャラ動かしたい' },
    { input: 'TPSアクションゲーム' },
    { input: 'ハイパーカジュアルゲーム' },
    { input: 'ボードゲームをWeb化' },
    { input: 'カードバトルゲーム' },
    { input: '弾幕シューティング' },
    { input: '物理演算パズル' },
    { input: '2Dアクションゲームのプレイヤー操作' },
    { input: '3Dアクションゲーム作って' },
    { input: 'スプライトアニメーション付きのゲーム' },
    { input: 'ジャンプアクションゲーム' },
    { input: 'ゲームのスコアランキング機能' },
  ]
};

const INLINE_BIZ_POS: Corpus = {
  label: 'business',
  entries: [
    { input: '請求書発行システムを作って' },
    { input: 'CRMをNext.jsで構築' },
    { input: '工事台帳管理システム' },
    { input: '受発注台帳のCRUD' },
    { input: '物件管理アプリ' },
    { input: '介護記録システム' },
    { input: 'レセプト管理' },
    { input: '学籍管理システム' },
    { input: '顧客管理 + 売掛買掛' },
    { input: '受注管理ダッシュボード' },
    { input: '経費精算ワークフロー' },
    { input: '勤怠管理 + 給与計算' },
    { input: '帳票出力 + PDF生成' },
    { input: 'admin dashboardを作って' },
    { input: 'RFP から提案書生成' },
    { input: '見積書を自動生成' },
    { input: 'WBS と進捗管理' },
    { input: 'Prismaで顧客テーブル' },
    { input: '基幹システムの管理画面' },
    { input: '在庫管理システム' },
    { input: '人事 + 申請承認フロー' },
    { input: 'ERPの売上原価分析' },
    { input: '契約管理 + 検収' },
    { input: 'Tenant DNA連携の顧客プロファイル' },
    { input: '顧客DNAを蓄積する設計' },
    { input: '管理画面の権限制御' },
    { input: '業務システムをNext.js+Prismaで' },
    { input: '受発注のCRUDをスキャフォールド' },
    { input: '請求と見積の同期' },
    { input: 'CRMの売上ダッシュボード' },
  ]
};

const INLINE_AMBIG: Corpus = {
  label: 'ambiguous',
  entries: [
    { input: 'ゲーミフィケーション要素のあるタスク管理' },
    { input: 'ゲームの売上を管理するシステム' },
    { input: 'スコアランキングを顧客管理で' },
    { input: '社員向けの教育ゲーム' },
    { input: 'CRMにレベルアップ要素を入れたい' },
    { input: '受注管理にバッジ機能' },
    { input: '帳票生成にゲーム性を持たせたい' },
    { input: '勤怠アプリにアバター' },
    { input: '研修プログラムをゲーム化' },
    { input: 'KPIをレベルアップ表示' },
    { input: '顧客管理にプレイヤー要素' },
    { input: '営業ダッシュボードにスコア' },
    { input: 'タスクをクエスト化' },
    { input: '社員のスキルを RPG 風に' },
    { input: '管理画面にミニゲーム埋め込み' },
  ]
};

// ---- CLI エントリ ----
if (require.main === module) {
  const gameCorpus = loadCorpus('game_positive', INLINE_GAME_POS);
  const bizCorpus = loadCorpus('business_positive', INLINE_BIZ_POS);
  const ambigCorpus = loadCorpus('ambiguous', INLINE_AMBIG);
  const corpora = [gameCorpus, bizCorpus, ambigCorpus];
  const merged = evaluateAll(corpora);
  printResult(corpora, merged);
  const accuracy = merged.total === 0 ? 0 : merged.passed / merged.total;
  process.exit(accuracy >= 0.85 ? 0 : 1);
}
