/**
 * detector.ts
 * --------------------------------------------------------------------------
 * 責務: ユーザー入力文字列から「ゲーム生成」か「業務系生成」かを判定する
 *       低レベル検出器。
 *
 * 設計方針:
 *   - 形態素解析は使わず、部分一致(includes)ベースで十分な精度を得る。
 *   - キーワードは strong/moderate/weak の三段階の重み(10/5/2)を持ち、
 *     ヒット数 × 重みでスコアを算出する。
 *   - 否定パターン(「ゲーミフィケーション」等)はゲームスコアから減算する。
 *   - confidence は 0.0〜1.0 にクランプし、recommendedSkill を判定する。
 *   - 設定可能な閾値(DetectorConfig)を持ち、将来のチューニングに備える。
 *
 * 依存: Node標準のみ。外部パッケージ不要。
 *
 * SoloptiLinkAI v2.1 Skill Router - 業務系/ゲーム生成の自動振り分けに使用。
 * --------------------------------------------------------------------------
 */

import gameKw from './gameKeywords.json' with { type: 'json' };
import businessKw from './businessKeywords.json' with { type: 'json' };

// ---------------------------------------------------------------------------
// 型定義
// ---------------------------------------------------------------------------

/** 判定カテゴリ */
export type Category = 'game' | 'business' | 'ambiguous' | 'unknown';

/** 推奨される委譲先スキル */
export type RecommendedSkill =
  | 'soloptilink-game'
  | 'soloptilink-boost'
  | 'soloptilink'
  | 'ask';

/** ヒットしたキーワード情報 */
export interface MatchedKeyword {
  /** マッチしたキーワード */
  keyword: string;
  /** 加算された重み */
  weight: number;
  /** どのグループに属するか (strong/moderate/weak/negation) */
  group: string;
}

/** 検出結果から抽出されるシグナル */
export interface DetectionSignals {
  /** 否定パターンが見つかったか */
  hasNegation: boolean;
  /** Three.js/Unity等のゲームエンジン明示があるか */
  hasExplicitEngineMention: boolean;
  /** Next.js/Prisma等の業務系フレームワーク明示があるか */
  hasExplicitFrameworkMention: boolean;
  /** RPG/FPS等のゲームジャンル名があるか */
  hasGenreKeyword: boolean;
  /** 抜粋(マッチ周辺の文字列) */
  contextWindow?: string;
}

/** 検出結果(detector.ts のメイン出力) */
export interface DetectionResult {
  /** カテゴリ判定 */
  category: Category;
  /** 0.0〜1.0 の確信度 */
  confidence: number;
  /** ゲームスコア(否定減算込み) */
  gameScore: number;
  /** 業務系スコア */
  businessScore: number;
  /** ゲーム側でヒットしたキーワード一覧 */
  matchedGameKeywords: MatchedKeyword[];
  /** 業務系側でヒットしたキーワード一覧 */
  matchedBusinessKeywords: MatchedKeyword[];
  /** 補助シグナル */
  signals: DetectionSignals;
  /** 日本語の判定理由(人間可読) */
  reasoning: string;
  /** 推奨スキル */
  recommendedSkill: RecommendedSkill;
  /** 委譲メッセージ(日本語、ユーザーに見せる用) */
  delegationMessage: string;
}

/** 検出器のチューニング可能な閾値 */
export interface DetectorConfig {
  /** ゲーム判定の最低スコア (デフォルト 10) */
  gameThreshold: number;
  /** 業務系判定の最低スコア (デフォルト 10) */
  businessThreshold: number;
  /** 両方>0 時の倍率閾値 (デフォルト 2.0) */
  ratioThreshold: number;
  /** 両方>0 時に差がこれ以下なら ambiguous (デフォルト 5) */
  ambiguousDiffThreshold: number;
}

/** デフォルト設定 */
export const DEFAULT_CONFIG: DetectorConfig = {
  gameThreshold: 10,
  businessThreshold: 10,
  ratioThreshold: 2.0,
  ambiguousDiffThreshold: 5,
};

// ---------------------------------------------------------------------------
// 内部ヘルパー
// ---------------------------------------------------------------------------

/**
 * 全角英数 → 半角化、英字小文字化、空白統一を行う正規化関数。
 * 日本語(ひらがな/カタカナ/漢字)は触らない。
 */
function normalizeInput(input: string): string {
  if (!input) return '';

  // 全角英数 → 半角
  let s = input.replace(/[！-～]/g, (ch) =>
    String.fromCharCode(ch.charCodeAt(0) - 0xfee0)
  );

  // 全角スペース → 半角
  s = s.replace(/　/g, ' ');

  // ASCII英字を小文字化(includes比較用)
  // ※ キーワード側もマッチ時に小文字化して比較するため双方向で整合する
  s = s.replace(/[A-Z]/g, (ch) => ch.toLowerCase());

  // 連続空白の集約
  s = s.replace(/\s+/g, ' ').trim();

  return s;
}

/**
 * キーワードを正規化(入力と同じルール)してから includes 比較する。
 * 大文字小文字を吸収するため英字は小文字化する。
 */
function normalizedIncludes(haystack: string, needle: string): boolean {
  const n = needle.replace(/[A-Z]/g, (ch) => ch.toLowerCase());
  return haystack.includes(n);
}

/**
 * キーワード辞書からマッチを抽出する内部関数。
 */
interface KeywordGroup {
  weight: number;
  keywords: string[];
}

function matchGroup(
  normalized: string,
  group: KeywordGroup,
  groupName: string
): { matches: MatchedKeyword[]; total: number } {
  const matches: MatchedKeyword[] = [];
  let total = 0;

  for (const kw of group.keywords) {
    if (normalizedIncludes(normalized, kw)) {
      matches.push({ keyword: kw, weight: group.weight, group: groupName });
      total += group.weight;
    }
  }

  return { matches, total };
}

/**
 * 否定パターンマッチ(ゲームスコアから減算する用途)。
 */
function matchNegation(normalized: string): {
  matches: MatchedKeyword[];
  total: number;
} {
  const neg = (gameKw as unknown as { negation?: { weight: number; keywords: string[] } }).negation;
  if (!neg) return { matches: [], total: 0 };

  const matches: MatchedKeyword[] = [];
  let total = 0;

  for (const kw of neg.keywords) {
    if (normalizedIncludes(normalized, kw)) {
      matches.push({ keyword: kw, weight: neg.weight, group: 'negation' });
      total += neg.weight; // 重みは負(例: -8)
    }
  }

  return { matches, total };
}

/**
 * 補助シグナルの抽出。
 */
function extractSignals(
  normalized: string,
  gameMatches: MatchedKeyword[],
  hasNegation: boolean
): DetectionSignals {
  const engineNames = [
    'three.js',
    'threejs',
    'phaser',
    'pixijs',
    'pixi.js',
    'godot',
    'unity',
    'unreal',
    'babylon.js',
    'webgl',
    'webxr',
  ];
  const frameworkNames = [
    'next.js',
    'nextjs',
    'prisma',
    'supabase',
    'neon',
    'vercel',
    'stripe',
  ];
  const genreNames = [
    'rpg',
    'jrpg',
    'arpg',
    'srpg',
    'fps',
    'tps',
    'mmorpg',
    'moba',
    'rts',
    'tbs',
    'ノベルゲーム',
    'シューティング',
    'パズルゲーム',
    'リズムゲーム',
    'クリッカー',
    '麻雀',
    'オセロ',
    '将棋',
    'チェス',
    '格闘ゲーム',
  ];

  const hasExplicitEngineMention = engineNames.some((n) =>
    normalized.includes(n.toLowerCase())
  );
  const hasExplicitFrameworkMention = frameworkNames.some((n) =>
    normalized.includes(n.toLowerCase())
  );
  const hasGenreKeyword = genreNames.some((n) =>
    normalized.includes(n.toLowerCase())
  );

  // contextWindow は最初のゲームマッチ周辺40字を抜粋
  let contextWindow: string | undefined = undefined;
  if (gameMatches.length > 0) {
    const firstKw = gameMatches[0].keyword.toLowerCase();
    const idx = normalized.indexOf(firstKw);
    if (idx >= 0) {
      const start = Math.max(0, idx - 20);
      const end = Math.min(normalized.length, idx + firstKw.length + 20);
      contextWindow = normalized.slice(start, end);
    }
  }

  return {
    hasNegation,
    hasExplicitEngineMention,
    hasExplicitFrameworkMention,
    hasGenreKeyword,
    contextWindow,
  };
}

/**
 * 推奨スキルと委譲メッセージを生成する。
 */
function decideRecommendation(
  category: Category,
  confidence: number,
  signals: DetectionSignals
): { recommendedSkill: RecommendedSkill; delegationMessage: string } {
  // カテゴリ別の推奨先
  if (category === 'game') {
    return {
      recommendedSkill: 'soloptilink-game',
      delegationMessage:
        'ゲーム生成の意図が強く検出されました。/soloptilink-game (12軸 Game Quality Fortress + 5エージェント) への委譲を推奨します。',
    };
  }
  if (category === 'business') {
    return {
      recommendedSkill: 'soloptilink-boost',
      delegationMessage:
        '業務系生成の意図が強く検出されました。/soloptilink-boost (71軸 + 105エージェント) への委譲を推奨します。',
    };
  }
  if (category === 'ambiguous') {
    return {
      recommendedSkill: 'ask',
      delegationMessage:
        'ゲーム要素と業務要素の両方が含まれており、自動判定が困難です。ユーザーに「ゲームとして作るか/業務システムとして作るか」を確認してから委譲してください。',
    };
  }
  // unknown
  return {
    recommendedSkill: 'soloptilink',
    delegationMessage:
      'ゲーム/業務系どちらのキーワードも顕在化していません。汎用 /soloptilink モードで開始することを推奨します。',
  };
}

/**
 * 日本語の判定理由文を組み立てる。
 */
function buildReasoning(
  category: Category,
  gameScore: number,
  businessScore: number,
  matchedGameKeywords: MatchedKeyword[],
  matchedBusinessKeywords: MatchedKeyword[],
  signals: DetectionSignals,
  config: DetectorConfig
): string {
  const gKws = matchedGameKeywords
    .slice(0, 5)
    .map((m) => `${m.keyword}(+${m.weight}/${m.group})`)
    .join(', ');
  const bKws = matchedBusinessKeywords
    .slice(0, 5)
    .map((m) => `${m.keyword}(+${m.weight}/${m.group})`)
    .join(', ');

  const lines: string[] = [];
  lines.push(`カテゴリ判定: ${category}`);
  lines.push(`ゲームスコア=${gameScore} / 業務スコア=${businessScore}`);
  if (matchedGameKeywords.length > 0) {
    lines.push(
      `ゲーム側ヒット(${matchedGameKeywords.length}件): ${gKws}${matchedGameKeywords.length > 5 ? ' …' : ''}`
    );
  }
  if (matchedBusinessKeywords.length > 0) {
    lines.push(
      `業務側ヒット(${matchedBusinessKeywords.length}件): ${bKws}${matchedBusinessKeywords.length > 5 ? ' …' : ''}`
    );
  }
  if (signals.hasNegation) {
    lines.push('否定パターン検出: ゲーム以外の文脈(ゲーミフィケーション等)が明示されています');
  }
  if (signals.hasExplicitEngineMention) {
    lines.push('ゲームエンジン明示あり (Three.js/Unity/Phaser等)');
  }
  if (signals.hasExplicitFrameworkMention) {
    lines.push('業務系フレームワーク明示あり (Next.js/Prisma/Supabase等)');
  }
  if (signals.hasGenreKeyword) {
    lines.push('ゲームジャンル名明示あり (RPG/FPS/シューティング等)');
  }
  lines.push(
    `閾値: gameThreshold=${config.gameThreshold}, businessThreshold=${config.businessThreshold}, ratioThreshold=${config.ratioThreshold}, ambiguousDiffThreshold=${config.ambiguousDiffThreshold}`
  );

  return lines.join('\n');
}

// ---------------------------------------------------------------------------
// 公開関数
// ---------------------------------------------------------------------------

/**
 * 入力文字列からゲーム/業務系を判定する。デフォルト閾値を使用する。
 */
export function detect(input: string): DetectionResult {
  return detectWithConfig(input, DEFAULT_CONFIG);
}

/**
 * カスタム閾値で判定する版。
 */
export function detectWithConfig(
  input: string,
  config: DetectorConfig
): DetectionResult {
  const normalized = normalizeInput(input);

  // 1) ゲーム側 strong/moderate/weak のマッチング
  const gStrong = matchGroup(
    normalized,
    gameKw.strong as KeywordGroup,
    'game-strong'
  );
  const gModerate = matchGroup(
    normalized,
    gameKw.moderate as KeywordGroup,
    'game-moderate'
  );
  const gWeak = matchGroup(
    normalized,
    gameKw.weak as KeywordGroup,
    'game-weak'
  );

  // 2) 否定パターン(ゲームスコアから減算する)
  const gNegation = matchNegation(normalized);

  // 3) 業務系 strong/moderate/weak のマッチング
  const bStrong = matchGroup(
    normalized,
    businessKw.strong as KeywordGroup,
    'business-strong'
  );
  const bModerate = matchGroup(
    normalized,
    businessKw.moderate as KeywordGroup,
    'business-moderate'
  );
  const bWeak = matchGroup(
    normalized,
    businessKw.weak as KeywordGroup,
    'business-weak'
  );

  // 4) スコア合算
  const matchedGameKeywords: MatchedKeyword[] = [
    ...gStrong.matches,
    ...gModerate.matches,
    ...gWeak.matches,
    ...gNegation.matches,
  ];
  const matchedBusinessKeywords: MatchedKeyword[] = [
    ...bStrong.matches,
    ...bModerate.matches,
    ...bWeak.matches,
  ];

  // 否定はマイナス重みで total に既に反映済み
  const gameScore = Math.max(
    0,
    gStrong.total + gModerate.total + gWeak.total + gNegation.total
  );
  const businessScore = bStrong.total + bModerate.total + bWeak.total;

  // 5) シグナル抽出
  const signals = extractSignals(
    normalized,
    matchedGameKeywords,
    gNegation.matches.length > 0
  );

  // 6) カテゴリ判定
  let category: Category;
  if (gameScore === 0 && businessScore === 0) {
    category = 'unknown';
  } else if (gameScore > 0 && businessScore === 0) {
    category = gameScore >= config.gameThreshold ? 'game' : 'game';
  } else if (businessScore > 0 && gameScore === 0) {
    category = businessScore >= config.businessThreshold ? 'business' : 'business';
  } else {
    // 両方>0 の場合: 倍率と差で勝者を決める
    const diff = Math.abs(gameScore - businessScore);
    if (diff <= config.ambiguousDiffThreshold) {
      category = 'ambiguous';
    } else if (gameScore >= businessScore * config.ratioThreshold) {
      category = 'game';
    } else if (businessScore >= gameScore * config.ratioThreshold) {
      category = 'business';
    } else {
      category = 'ambiguous';
    }
  }

  // 7) confidence 算出
  //    - 単独サイドのみヒットの場合: スコア / 期待値(2*閾値) で 0.4〜1.0 にマップ
  //    - 両側ヒットの場合: 差 / 合計 で勾配を測る
  //    - unknown は 0.0、ambiguous は 0.3〜0.5
  let confidence: number;
  if (category === 'unknown') {
    confidence = 0.0;
  } else if (category === 'ambiguous') {
    // 両方似たスコア → 低confidence
    const sum = gameScore + businessScore;
    if (sum === 0) {
      confidence = 0.0;
    } else {
      const diff = Math.abs(gameScore - businessScore);
      confidence = Math.max(0.2, Math.min(0.5, diff / sum));
    }
  } else {
    // 勝者サイドのスコアを基準に
    const winner = category === 'game' ? gameScore : businessScore;
    const threshold =
      category === 'game' ? config.gameThreshold : config.businessThreshold;
    // 閾値で 0.6、閾値2倍で 0.9、3倍以上で 0.95〜0.99
    const ratio = winner / threshold;
    let c: number;
    if (ratio >= 3) {
      c = 0.98;
    } else if (ratio >= 2) {
      c = 0.85 + (ratio - 2) * 0.13;
    } else if (ratio >= 1) {
      c = 0.65 + (ratio - 1) * 0.2;
    } else {
      c = Math.max(0.4, ratio * 0.65);
    }

    // strong ヒット数で +0.05 / engine明示で +0.03 のボーナス
    if (category === 'game' && gStrong.matches.length >= 2) c += 0.05;
    if (category === 'business' && bStrong.matches.length >= 2) c += 0.05;
    if (category === 'game' && signals.hasExplicitEngineMention) c += 0.03;
    if (category === 'business' && signals.hasExplicitFrameworkMention) c += 0.03;

    // 否定パターンで -0.15
    if (category === 'game' && signals.hasNegation) c -= 0.15;

    confidence = Math.max(0.0, Math.min(1.0, c));
  }

  // 8) 推奨スキル決定
  const { recommendedSkill, delegationMessage } = decideRecommendation(
    category,
    confidence,
    signals
  );

  // 9) 判定理由文の組み立て
  const reasoning = buildReasoning(
    category,
    gameScore,
    businessScore,
    matchedGameKeywords,
    matchedBusinessKeywords,
    signals,
    config
  );

  return {
    category,
    confidence: Math.round(confidence * 1000) / 1000, // 小数3桁
    gameScore,
    businessScore,
    matchedGameKeywords,
    matchedBusinessKeywords,
    signals,
    reasoning,
    recommendedSkill,
    delegationMessage,
  };
}

/**
 * バッチ判定。コーパス評価/CI回帰テストで使用する。
 */
export function detectBatch(inputs: string[]): DetectionResult[] {
  return inputs.map((s) => detect(s));
}
