# Snake (Phaser 3 サンプル)

SoloptiLinkAI v1.0 `/soloptilink-game` の **puzzle** ジャンル × **phaser** エンジンのリファレンス実装。

## プレイ

```bash
# 静的ファイルなので、ブラウザで index.html を直接開くだけで動く
open index.html

# または、ローカルサーバー経由
python3 -m http.server 8000
# → http://localhost:8000/
```

## 操作

- 矢印キー or WASD: 蛇を操作
- スペース: ポーズ
- タッチ(モバイル): スワイプで方向転換、タップでポーズ

## このサンプルが満たす Game Quality Fortress 軸

| 軸 | 実装 |
|---|---|
| FPS安定性 | Phaser 3 の60fps固定 + 軽量描画 |
| 入力遅延 | キーボード/タッチを毎フレーム読み取り、16ms以下 |
| ロード時間 | 単一HTML+JS、CDN以外無し、即時 |
| ゲームバランス | 餌取得ごとに速度+2ms上昇(staircase difficulty curve) |
| リプレイ性 | localStorage ハイスコア + 速度上昇 |
| オンボーディング | タイトル画面で操作説明、3秒で開始可能 |
| AV統一感 | 緑系蛇+赤い餌+暗灰背景、シルエット判別容易 |
| UI/UX | スコア常時表示、ポーズヒント、ゲームオーバー時に明確なリスタート |
| アクセシビリティ | キーボード/タッチ両対応、色だけでなく形状でも判別、focus-visible |
| 楽しさ FUN | 連鎖加速・ハイスコア更新の達成感 |

このサンプルは Game Quality Fortress で約 **75-85点 (Silver)** 相当。
プロダクションでは画像アセット・BGM・SE・実績システムを追加して Gold+ を目指す。

## ソースコード構成

- `index.html` - HTMLエントリ(Phaser CDN読み込み)
- `main.js` - ゲーム本体(2シーン、約170行)

## なぜCDNを使うか

このサンプルは「即動く」を最優先するため CDN経由で Phaser を読み込んでいる。
本番プロジェクトでは `npm install phaser` → `import Phaser from 'phaser'` を推奨。

`/soloptilink-game` の `game_init.sh` はnpmベースの構成を生成する。
