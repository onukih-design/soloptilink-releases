// Snake - Phaser 3 サンプル実装
// soloptilink-game v1.0 の puzzle ジャンル リファレンス実装
//
// 設計指針 (Game Quality Fortress 10軸を意識):
//  - 60fps固定 / 入力遅延16ms以下 / ロード即時
//  - キーボード + タッチ(スワイプ) 両対応 (アクセシビリティ)
//  - 色覚配慮(蛇=緑, 餌=赤, 背景=暗灰) → 形状差でも判別可能
//  - localStorage でハイスコア保存(リプレイ性)
//  - ポーズ機能(スペース or タップで)

const GRID = 20;          // 1セルの大きさ(px)
const COLS = 30;          // 横セル数
const ROWS = 25;          // 縦セル数
const TICK_MS = 110;      // 移動間隔(ms)
const SPEEDUP_PER_FOOD = 2; // 餌を食うごとにTICK_MSを-2(難易度上昇)
const MIN_TICK_MS = 60;     // 最小TICK(これ以上速くしない)

class TitleScene extends Phaser.Scene {
  constructor() { super('Title'); }
  create() {
    const cx = this.scale.width / 2;
    const cy = this.scale.height / 2;
    this.add.text(cx, cy - 80, 'SNAKE', { fontSize: '64px', color: '#4ade80', fontStyle: 'bold' }).setOrigin(0.5);
    this.add.text(cx, cy + 10, 'スペース or タップで開始', { fontSize: '20px', color: '#fff' }).setOrigin(0.5);

    const hi = parseInt(localStorage.getItem('snake_hi') || '0', 10);
    this.add.text(cx, cy + 60, `ハイスコア: ${hi}`, { fontSize: '16px', color: '#999' }).setOrigin(0.5);

    const startGame = () => this.scene.start('Game');
    this.input.keyboard.once('keydown-SPACE', startGame);
    this.input.keyboard.once('keydown-ENTER', startGame);
    this.input.once('pointerdown', startGame);
  }
}

class GameScene extends Phaser.Scene {
  constructor() { super('Game'); }
  create() {
    // 状態
    this.snake = [{ x: 15, y: 12 }, { x: 14, y: 12 }, { x: 13, y: 12 }];
    this.dir = { x: 1, y: 0 };
    this.nextDir = { x: 1, y: 0 };
    this.food = this.spawnFood();
    this.score = 0;
    this.tickMs = TICK_MS;
    this.elapsed = 0;
    this.paused = false;
    this.gameOver = false;

    // 描画グループ
    this.gfx = this.add.graphics();

    // スコア表示
    this.scoreText = this.add.text(10, 5, 'SCORE: 0', { fontSize: '20px', color: '#fff' });
    this.pauseHint = this.add.text(this.scale.width - 10, 5, 'スペース: PAUSE', { fontSize: '14px', color: '#666' }).setOrigin(1, 0);

    // 入力 - キーボード
    this.cursors = this.input.keyboard.createCursorKeys();
    this.input.keyboard.on('keydown-W', () => this.tryDir(0, -1));
    this.input.keyboard.on('keydown-A', () => this.tryDir(-1, 0));
    this.input.keyboard.on('keydown-S', () => this.tryDir(0, 1));
    this.input.keyboard.on('keydown-D', () => this.tryDir(1, 0));
    this.input.keyboard.on('keydown-SPACE', () => this.togglePause());

    // 入力 - スワイプ (タッチ)
    this.input.on('pointerdown', (p) => { this.touchStart = { x: p.x, y: p.y }; });
    this.input.on('pointerup', (p) => {
      if (!this.touchStart) return;
      const dx = p.x - this.touchStart.x;
      const dy = p.y - this.touchStart.y;
      if (Math.abs(dx) < 20 && Math.abs(dy) < 20) { this.togglePause(); return; }
      if (Math.abs(dx) > Math.abs(dy)) this.tryDir(dx > 0 ? 1 : -1, 0);
      else this.tryDir(0, dy > 0 ? 1 : -1);
      this.touchStart = null;
    });
  }

  tryDir(dx, dy) {
    // 真逆方向は禁止(自殺防止)
    if (this.dir.x === -dx && this.dir.y === -dy) return;
    this.nextDir = { x: dx, y: dy };
  }

  togglePause() {
    if (this.gameOver) return;
    this.paused = !this.paused;
    if (this.paused) this.pauseHint.setText('再開: スペース').setColor('#4ade80');
    else this.pauseHint.setText('スペース: PAUSE').setColor('#666');
  }

  update(time, delta) {
    if (this.paused || this.gameOver) {
      this.draw();
      return;
    }
    // キーボード矢印キー(create時のhandlerに加え、毎フレームでもチェック - 入力遅延短縮)
    if (this.cursors.left.isDown) this.tryDir(-1, 0);
    else if (this.cursors.right.isDown) this.tryDir(1, 0);
    else if (this.cursors.up.isDown) this.tryDir(0, -1);
    else if (this.cursors.down.isDown) this.tryDir(0, 1);

    this.elapsed += delta;
    if (this.elapsed >= this.tickMs) {
      this.elapsed = 0;
      this.tick();
    }
    this.draw();
  }

  tick() {
    this.dir = this.nextDir;
    const head = this.snake[0];
    const nx = head.x + this.dir.x;
    const ny = head.y + this.dir.y;

    // 壁判定
    if (nx < 0 || nx >= COLS || ny < 0 || ny >= ROWS) {
      this.endGame();
      return;
    }
    // 自分自身判定(尻尾を除く)
    for (let i = 0; i < this.snake.length - 1; i++) {
      if (this.snake[i].x === nx && this.snake[i].y === ny) {
        this.endGame();
        return;
      }
    }

    const newHead = { x: nx, y: ny };
    this.snake.unshift(newHead);

    // 餌判定
    if (nx === this.food.x && ny === this.food.y) {
      this.score += 10;
      this.scoreText.setText(`SCORE: ${this.score}`);
      this.food = this.spawnFood();
      this.tickMs = Math.max(MIN_TICK_MS, this.tickMs - SPEEDUP_PER_FOOD);
      // 餌取得SE(WebAudio直接)
      this.playBeep(880, 0.05);
    } else {
      this.snake.pop();
    }
  }

  spawnFood() {
    // 蛇の上に被らない座標を探す
    while (true) {
      const x = Phaser.Math.Between(0, COLS - 1);
      const y = Phaser.Math.Between(0, ROWS - 1);
      if (!this.snake.some(s => s.x === x && s.y === y)) return { x, y };
    }
  }

  endGame() {
    this.gameOver = true;
    this.playBeep(220, 0.3);
    const hi = parseInt(localStorage.getItem('snake_hi') || '0', 10);
    if (this.score > hi) localStorage.setItem('snake_hi', String(this.score));

    const cx = this.scale.width / 2;
    const cy = this.scale.height / 2;
    this.add.rectangle(cx, cy, this.scale.width, this.scale.height, 0x000000, 0.7);
    this.add.text(cx, cy - 60, 'GAME OVER', { fontSize: '56px', color: '#f87171', fontStyle: 'bold' }).setOrigin(0.5);
    this.add.text(cx, cy, `SCORE: ${this.score}`, { fontSize: '32px', color: '#fff' }).setOrigin(0.5);
    this.add.text(cx, cy + 50, `HI-SCORE: ${Math.max(hi, this.score)}`, { fontSize: '20px', color: '#fbbf24' }).setOrigin(0.5);
    this.add.text(cx, cy + 100, 'スペース or タップでタイトルへ', { fontSize: '16px', color: '#aaa' }).setOrigin(0.5);

    this.input.keyboard.once('keydown-SPACE', () => this.scene.start('Title'));
    this.input.once('pointerdown', () => this.scene.start('Title'));
  }

  draw() {
    this.gfx.clear();
    // グリッド(薄く)
    this.gfx.lineStyle(1, 0x1a1a1a, 1);
    for (let i = 0; i <= COLS; i++) this.gfx.lineBetween(i * GRID, 30, i * GRID, 30 + ROWS * GRID);
    for (let i = 0; i <= ROWS; i++) this.gfx.lineBetween(0, 30 + i * GRID, COLS * GRID, 30 + i * GRID);
    // 蛇本体
    this.snake.forEach((s, i) => {
      const isHead = i === 0;
      this.gfx.fillStyle(isHead ? 0x4ade80 : 0x22c55e, 1);
      this.gfx.fillRect(s.x * GRID + 1, 30 + s.y * GRID + 1, GRID - 2, GRID - 2);
    });
    // 餌
    this.gfx.fillStyle(0xef4444, 1);
    this.gfx.fillCircle(this.food.x * GRID + GRID / 2, 30 + this.food.y * GRID + GRID / 2, GRID / 2 - 2);
  }

  playBeep(freq, duration) {
    try {
      const ctx = new (window.AudioContext || window.webkitAudioContext)();
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.connect(g);
      g.connect(ctx.destination);
      o.frequency.value = freq;
      o.type = 'square';
      g.gain.setValueAtTime(0.06, ctx.currentTime);
      g.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + duration);
      o.start();
      o.stop(ctx.currentTime + duration);
    } catch (e) { /* AudioContext未対応環境はスキップ */ }
  }
}

const config = {
  type: Phaser.AUTO,
  parent: 'game',
  width: COLS * GRID,
  height: 30 + ROWS * GRID,
  backgroundColor: '#0d0d0d',
  fps: { target: 60, forceSetTimeOut: false },
  scale: { mode: Phaser.Scale.FIT, autoCenter: Phaser.Scale.CENTER_BOTH },
  scene: [TitleScene, GameScene],
};

new Phaser.Game(config);
