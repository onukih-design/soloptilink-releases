#!/usr/bin/env bash
# ============================================================================
# skill_route.sh - Skill Router CLI (SoloptiLinkAI v2.1)
# ----------------------------------------------------------------------------
# 自然言語入力からゲーム生成 / 業務系生成を判定し、推奨スキルを返す CLI。
# 本体 lib/skill_router/router.ts が存在すればそれを経由、
# 無ければ JSON キーワード辞書を読み込んで簡易判定にフォールバックする。
#
# 使い方:
#   bash skill_route.sh --input "<指示>" [--source boost|game|other] [--json] [--quiet]
#   echo "ノベルゲーム作って" | bash skill_route.sh --stdin
#
# 例:
#   bash skill_route.sh --input "ノベルゲーム作って"
#   bash skill_route.sh --input "請求書発行システム" --source boost --json
#   echo "完璧な3Dゲーム" | bash skill_route.sh --stdin
#
# 出力フィールド:
#   - category:          game | business | ambiguous | unknown
#   - confidence:        0.0 - 1.0
#   - recommendedSkill:  soloptilink-game | soloptilink-boost | ask
#   - guidanceMessage:   日本語の委譲メッセージ
#   - gameScore / businessScore / matchedGame / matchedBusiness
# ============================================================================

set -uo pipefail

INPUT=""
SOURCE="other"
JSON_OUT="false"
QUIET="false"
STDIN_MODE="false"

# ---------- 引数パース ----------
while [[ $# -gt 0 ]]; do
  case "$1" in
    --input)
      [[ $# -lt 2 ]] && { echo "[ERR] --input の値が無い" >&2; exit 2; }
      INPUT="$2"; shift 2;;
    --source)
      [[ $# -lt 2 ]] && { echo "[ERR] --source の値が無い" >&2; exit 2; }
      SOURCE="$2"; shift 2;;
    --json)   JSON_OUT="true"; shift;;
    --quiet)  QUIET="true"; shift;;
    --stdin)  STDIN_MODE="true"; shift;;
    --help|-h)
      cat <<'USAGE'
Skill Router - 自然言語入力からゲーム生成 / 業務系生成を判定

使い方:
  bash skill_route.sh --input "<指示>" [--source boost|game|other] [--json] [--quiet]
  echo "<指示>" | bash skill_route.sh --stdin

引数:
  --input <文字列>   判定対象の指示
  --source <kind>    呼び出し元スキル (boost / game / other) ※省略時 other
  --stdin            標準入力から指示を受け取る
  --json             JSON のみ出力 (機械可読)
  --quiet            ヘッダ装飾を抑制
  --help / -h        このヘルプ

例:
  bash skill_route.sh --input "ノベルゲーム作って"
  bash skill_route.sh --input "請求書発行システム" --source boost --json
  echo "完璧な3Dゲーム" | bash skill_route.sh --stdin

出力:
  - category:          game | business | ambiguous | unknown
  - confidence:        0.0 - 1.0
  - recommendedSkill:  soloptilink-game | soloptilink-boost | ask
  - guidanceMessage:   日本語の委譲メッセージ
USAGE
      exit 0;;
    *)
      echo "[ERR] 未知の引数: $1" >&2
      echo "       --help で使い方を表示" >&2
      exit 2;;
  esac
done

# ---------- 入力取得 ----------
if [[ "$STDIN_MODE" == "true" ]]; then
  INPUT=$(cat)
fi

if [[ -z "$INPUT" ]]; then
  echo "[ERR] --input または --stdin が必要" >&2
  echo "       --help で使い方を表示" >&2
  exit 2
fi

# source の検証
case "$SOURCE" in
  boost|game|other) :;;
  *) echo "[ERR] --source は boost/game/other のいずれか (指定値: $SOURCE)" >&2; exit 2;;
esac

# ---------- スキルディレクトリ解決 ----------
SKILL_DIR="${SOLOPTILINK_GAME_SKILL_DIR:-$HOME/.claude/skills/soloptilink-game}"
ROUTER_TS="$SKILL_DIR/lib/skill_router/router.ts"
DETECTOR_TS="$SKILL_DIR/lib/skill_router/detector.ts"
GAME_KW_JSON="$SKILL_DIR/lib/skill_router/gameKeywords.json"
BIZ_KW_JSON="$SKILL_DIR/lib/skill_router/businessKeywords.json"

# ---------- 判定実行 ----------
RESULT=""
ROUTER_MODE="fallback"

if command -v npx >/dev/null 2>&1 && [[ -f "$ROUTER_TS" && -f "$DETECTOR_TS" ]]; then
  # 本体 router.ts 経由
  ROUTER_MODE="router_ts"
  RESULT=$(npx --yes ts-node --transpile-only -e "
    const path = require('path');
    const mod = require(path.resolve('$ROUTER_TS'));
    const input = process.argv[1];
    const source = process.argv[2];
    const action = mod.route(input, source);
    process.stdout.write(JSON.stringify(action, null, 2));
  " "$INPUT" "$SOURCE" 2>/dev/null || echo "")
fi

# フォールバック (router.ts 不在 or 実行失敗)
if [[ -z "$RESULT" || "$RESULT" == "null" ]]; then
  ROUTER_MODE="fallback"
  if [[ ! -f "$GAME_KW_JSON" || ! -f "$BIZ_KW_JSON" ]]; then
    # キーワード辞書も無い → 最低限のインライン辞書で判定
    RESULT=$(node -e "
      const gameStrong   = ['ノベルゲーム','アクションゲーム','rpg','シューティング','fps','tps','vr','3dゲーム','three.js','phaser','pixijs','godot','unity','unreal','マリオ風','テトリス','倉庫番','オセロ','将棋','迷路','レーシング','フライトシム','クリッカー','パズルゲーム','リズムゲーム','プレイテスト','gdd'];
      const gameModerate = ['ゲーム','プレイヤー','ステージ','スコア','レベル','敵','弾','ジャンプ','スプライト','物理演算','衝突判定','wave function collapse','プロシージャル','mixamo','cascadeur','ボードゲーム','ノベル'];
      const gameWeak     = ['fps計測','frame','ゲーム性','game'];
      const bizStrong    = ['請求書','見積書','crm','erp','工事台帳','受発注','物件管理','介護記録','レセプト','学籍管理','顧客管理','受注管理','経費精算','勤怠','帳票','顧客dna','業務システム','基幹システム','管理画面','admin dashboard','rfp','提案書','検収'];
      const bizModerate  = ['next.js','prisma','crud','業務','顧客','契約','売上','原価','在庫','wbs','見積','請求','売掛','買掛','給与','人事','申請','承認','ワークフロー'];
      const bizWeak      = ['管理','システム','データベース','レポート','フォーム','テーブル'];
      const input = (process.argv[1] || '').toLowerCase();
      let gScore = 0, bScore = 0;
      const gMatch = [], bMatch = [];
      for (const kw of gameStrong)   if (input.includes(kw.toLowerCase())) { gScore += 5; gMatch.push(kw); }
      for (const kw of gameModerate) if (input.includes(kw.toLowerCase())) { gScore += 3; gMatch.push(kw); }
      for (const kw of gameWeak)     if (input.includes(kw.toLowerCase())) { gScore += 1; gMatch.push(kw); }
      for (const kw of bizStrong)    if (input.includes(kw.toLowerCase())) { bScore += 5; bMatch.push(kw); }
      for (const kw of bizModerate)  if (input.includes(kw.toLowerCase())) { bScore += 3; bMatch.push(kw); }
      for (const kw of bizWeak)      if (input.includes(kw.toLowerCase())) { bScore += 1; bMatch.push(kw); }
      // 否定パターン: 'ゲーミフィケーション' は biz 寄り
      if (input.includes('ゲーミフィケーション')) { gScore = Math.max(0, gScore - 3); bScore += 2; }
      let category = 'unknown', skill = 'ask', msg = '指示が判定不能です。具体例を追記してください。';
      if (gScore + bScore === 0) {
        category = 'unknown';
      } else if (gScore >= bScore * 2 && gScore >= 5) {
        category = 'game'; skill = 'soloptilink-game';
        msg = 'ゲーム生成として /soloptilink-game に委譲します。';
      } else if (bScore >= gScore * 2 && bScore >= 5) {
        category = 'business'; skill = 'soloptilink-boost';
        msg = '業務系生成として /soloptilink-boost に委譲します。';
      } else if (Math.abs(gScore - bScore) < 5) {
        category = 'ambiguous';
        msg = 'ゲーム要素と業務系要素が混在しています。どちらを優先しますか?';
      } else if (gScore > bScore) {
        category = 'game'; skill = 'soloptilink-game';
        msg = 'ゲーム寄りと判定。/soloptilink-game に委譲します。';
      } else {
        category = 'business'; skill = 'soloptilink-boost';
        msg = '業務系寄りと判定。/soloptilink-boost に委譲します。';
      }
      const conf = Math.min(1, Math.abs(gScore - bScore) / 20);
      const out = {
        category, confidence: Number(conf.toFixed(3)),
        gameScore: gScore, businessScore: bScore,
        recommendedSkill: skill, guidanceMessage: msg,
        matchedGame: gMatch.slice(0,5), matchedBusiness: bMatch.slice(0,5),
        routerMode: 'inline_fallback', sourceSkill: process.argv[2] || 'other'
      };
      process.stdout.write(JSON.stringify(out, null, 2));
    " "$INPUT" "$SOURCE")
  else
    # JSON 辞書あり: ファイルベースのフォールバック
    RESULT=$(node -e "
      const fs = require('fs');
      const game = JSON.parse(fs.readFileSync('$GAME_KW_JSON', 'utf8'));
      const biz  = JSON.parse(fs.readFileSync('$BIZ_KW_JSON',  'utf8'));
      const input = (process.argv[1] || '').toLowerCase();
      const src   = process.argv[2] || 'other';
      let gScore = 0, bScore = 0;
      const gMatch = [], bMatch = [];
      for (const grp of ['strong','moderate','weak']) {
        const gGrp = game[grp]  || { keywords: [], weight: 0 };
        const bGrp = biz[grp]   || { keywords: [], weight: 0 };
        for (const kw of (gGrp.keywords || [])) {
          if (kw && input.includes(String(kw).toLowerCase())) { gScore += (gGrp.weight || 0); gMatch.push(kw); }
        }
        for (const kw of (bGrp.keywords || [])) {
          if (kw && input.includes(String(kw).toLowerCase())) { bScore += (bGrp.weight || 0); bMatch.push(kw); }
        }
      }
      // 否定パターン: ゲーミフィケーション
      if (input.includes('ゲーミフィケーション')) { gScore = Math.max(0, gScore - 3); bScore += 2; }
      let category = 'unknown', skill = 'ask', msg = '指示が判定不能です。具体例を追記してください。';
      if (gScore + bScore === 0) {
        category = 'unknown';
      } else if (gScore >= bScore * 2 && gScore >= 5) {
        category = 'game'; skill = 'soloptilink-game';
        msg = 'ゲーム生成として /soloptilink-game に委譲します。';
      } else if (bScore >= gScore * 2 && bScore >= 5) {
        category = 'business'; skill = 'soloptilink-boost';
        msg = '業務系生成として /soloptilink-boost に委譲します。';
      } else if (Math.abs(gScore - bScore) < 5) {
        category = 'ambiguous';
        msg = 'ゲーム要素と業務系要素が混在しています。どちらを優先しますか?';
      } else if (gScore > bScore) {
        category = 'game'; skill = 'soloptilink-game';
        msg = 'ゲーム寄りと判定。/soloptilink-game に委譲します。';
      } else {
        category = 'business'; skill = 'soloptilink-boost';
        msg = '業務系寄りと判定。/soloptilink-boost に委譲します。';
      }
      const conf = Math.min(1, Math.abs(gScore - bScore) / 20);
      const out = {
        category, confidence: Number(conf.toFixed(3)),
        gameScore: gScore, businessScore: bScore,
        recommendedSkill: skill, guidanceMessage: msg,
        matchedGame: gMatch.slice(0,5), matchedBusiness: bMatch.slice(0,5),
        routerMode: 'json_fallback', sourceSkill: src
      };
      process.stdout.write(JSON.stringify(out, null, 2));
    " "$INPUT" "$SOURCE")
  fi
fi

if [[ -z "$RESULT" ]]; then
  echo "[ERR] 判定に失敗しました (router/fallback 両方失敗)" >&2
  exit 1
fi

# ---------- 出力 ----------
if [[ "$JSON_OUT" == "true" ]]; then
  printf '%s\n' "$RESULT"
  exit 0
fi

if [[ "$QUIET" == "false" ]]; then
  echo "🧭 Skill Router 判定結果 (mode: $ROUTER_MODE)"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
fi

printf '%s\n' "$RESULT" | python3 -c "
import json, sys
try:
    d = json.load(sys.stdin)
except Exception as e:
    print('[ERR] JSON parse error: ' + str(e))
    sys.exit(1)
print('カテゴリ:      ' + str(d.get('category','?')))
print('信頼度:        {:.2f}'.format(float(d.get('confidence', 0))))
print('ゲームスコア:  ' + str(d.get('gameScore', '?')))
print('業務系スコア:  ' + str(d.get('businessScore', '?')))
print('推奨スキル:    ' + str(d.get('recommendedSkill', '?')))
if d.get('guidanceMessage'):
    print('メッセージ:    ' + d['guidanceMessage'])
if d.get('matchedGame'):
    print('ゲームKW:      ' + ', '.join(d['matchedGame']))
if d.get('matchedBusiness'):
    print('業務系KW:      ' + ', '.join(d['matchedBusiness']))
if d.get('action'):
    print('アクション:    ' + str(d['action']))
if d.get('targetSkill'):
    print('委譲先:        ' + str(d['targetSkill']))
" || true

exit 0
