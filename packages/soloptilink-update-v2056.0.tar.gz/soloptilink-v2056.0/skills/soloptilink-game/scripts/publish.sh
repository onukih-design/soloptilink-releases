#!/usr/bin/env bash
# publish.sh - ゲームを各配信先向けにパッケージング
# /soloptilink-game の Step 8 で呼ばれる

set -euo pipefail
IFS=$'\n\t'

TARGET=""
PROJECT=""

while [[ $# -gt 0 ]]; do
  case "$1" in
    --target)  TARGET="$2";  shift 2;;
    --project) PROJECT="$2"; shift 2;;
    --help|-h)
      echo "使い方: bash publish.sh --target <web|itch.io|steam|appstore|playstore> --project <dir>"
      exit 0;;
    *) echo "[ERR] 未知の引数: $1" >&2; exit 2;;
  esac
done

[[ -z "$TARGET"  ]] && { echo "[ERR] --target 未指定"; exit 2; }
[[ -z "$PROJECT" ]] && { echo "[ERR] --project 未指定"; exit 2; }
[[ -d "$PROJECT" ]] || { echo "[ERR] プロジェクト未検出: $PROJECT"; exit 3; }

# ── 日本語ファイル名が Windows で文字化けしないようにする ────────────────
# macOS に入っている zip は、日本語ファイル名を UTF-8 で保存するのに
# 「これは UTF-8 です」という目印を付けません。そのため日本語 Windows で
# 解凍するとファイル名が読めない文字列になります。素材に日本語名が
# 1 つでもあると、遊ぶ人の手元でファイルが開けなくなります。
# 目印を付ける手段を上から順に試し、どれも使えないときは黙って進まず
# 日本語で警告します (成功したふりをしません)。
zip_fix_japanese_names() {
  local zip_path="$1"
  local tool="${SOLOPTILINK_HOME:-$HOME/.soloptilink}/scripts/zip-utf8-flag.py"
  if [[ -f "$tool" ]] && command -v python3 >/dev/null 2>&1; then
    if python3 "$tool" fix "$zip_path" >/dev/null 2>&1; then
      echo "✅ 日本語ファイル名に Windows 用の目印を付けました"
      return 0
    fi
  fi
  # 2 番目の手段: zip 本体が UTF-8 指定に対応していれば、それで付け直す
  if zip -h2 2>/dev/null | grep -q 'UN=' ; then
    local src_dir; src_dir="$(dirname "$zip_path")/dist"
    if [[ -d "$src_dir" ]] && ( cd "$src_dir" && zip -r -q -UN=UTF8 "$zip_path" . ); then
      echo "✅ 日本語ファイル名に Windows 用の目印を付けました"
      return 0
    fi
  fi
  # どれも使えなかった: 未対応であることをはっきり伝える
  if LC_ALL=C grep -q '[^[:print:]]' <<<"$(unzip -Z1 "$zip_path" 2>/dev/null)"; then
    echo "⚠️ 日本語のファイル名が含まれていますが、Windows 用の目印を付けられませんでした。"
    echo "   このまま配ると、日本語 Windows で解凍したときにファイル名が読めなくなります。"
    echo "   素材のファイル名を英数字に変えてから、もう一度パッケージングしてください。"
  fi
  return 0
}

cd "$PROJECT"

echo "📦 [publish] 配信パッケージング: $TARGET"

case "$TARGET" in
  web)
    npm run build
    echo "✅ web: dist/ をホスティング(Vercel/Netlify/GitHub Pages)に配置してください"
    ;;
  itch.io)
    npm run build
    ZIP="dist-itch.zip"
    (cd dist && zip -r "../$ZIP" .)
    zip_fix_japanese_names "$PWD/$ZIP"
    cat > .itch.toml <<EOF
[[actions]]
name = "play"
path = "index.html"
scope = "browser"
EOF
    echo "✅ itch.io: $ZIP を作成しました"
    echo "    アップロード: butler push $ZIP <user>/<game>:web"
    ;;
  steam)
    echo "ℹ️ Steam配信は Godot(godotエンジン)プロジェクトでのみ完全自動化されます"
    echo "    Steamworks SDK の手動設定が必要です: https://partner.steamgames.com/"
    ;;
  appstore|playstore)
    echo "ℹ️ Capacitor を初期化してネイティブビルドを作成します"
    if ! command -v cap >/dev/null 2>&1; then
      npm install -D @capacitor/cli @capacitor/core
    fi
    npx cap init "$(basename "$PROJECT")" "com.soloptilink.$(basename "$PROJECT" | tr '[:upper:]' '[:lower:]')" --web-dir=dist 2>/dev/null || true
    npm run build
    if [[ "$TARGET" == "appstore" ]]; then
      npx cap add ios
      npx cap copy ios
      echo "✅ iOS プロジェクトを生成しました: ios/"
      echo "    Xcode で開く: npx cap open ios"
    else
      npx cap add android
      npx cap copy android
      echo "✅ Android プロジェクトを生成しました: android/"
      echo "    Android Studio で開く: npx cap open android"
    fi
    ;;
  *)
    echo "[ERR] 未対応ターゲット: $TARGET"
    echo "    対応: web | itch.io | steam | appstore | playstore"
    exit 4;;
esac
