#!/usr/bin/env bash
# asset_forge_3d.sh - 3Dアセット生成パイプライン実行ラッパー
# v2.0 新規。Tripo3D/Meshy/Stable Zero123/Rodin/Luma の3Dアセット生成APIを統一インターフェイスで呼ぶ。
#
# 使い方:
#   bash asset_forge_3d.sh --prompt "中世の騎士キャラ" \
#                          --style realistic \
#                          --category character \
#                          --import-to ./voxel-maze \
#                          --import-engine three

set -euo pipefail
IFS=$'\n\t'

PROMPT=""
STYLE="lowpoly"
CATEGORY="prop"
OUTPUT_FORMAT="gltf"
TARGET_POLY="3000"
WITH_TEXTURE="true"
PROVIDER="auto"
RIG="false"
LOD="false"
ATLAS="false"
IMPORT_TO=""
IMPORT_ENGINE="three"
OUT_DIR="./assets-3d"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --prompt)         PROMPT="$2"; shift 2;;
    --style)          STYLE="$2"; shift 2;;
    --category)       CATEGORY="$2"; shift 2;;
    --output-format)  OUTPUT_FORMAT="$2"; shift 2;;
    --target-poly)    TARGET_POLY="$2"; shift 2;;
    --no-texture)     WITH_TEXTURE="false"; shift;;
    --provider)       PROVIDER="$2"; shift 2;;
    --rig)            RIG="true"; shift;;
    --lod)            LOD="true"; shift;;
    --atlas)          ATLAS="true"; shift;;
    --import-to)      IMPORT_TO="$2"; shift 2;;
    --import-engine)  IMPORT_ENGINE="$2"; shift 2;;
    --out)            OUT_DIR="$2"; shift 2;;
    --help|-h)
      cat <<'USAGE'
3Dアセット生成パイプライン (Tripo3D/Meshy/Stable Zero123/Rodin/Luma 統一)

使い方:
  bash asset_forge_3d.sh --prompt "<日本語/英語プロンプト>" \
                         [--style lowpoly|cartoon|realistic|pixelart3d|voxel] \
                         [--category character|prop|environment|vehicle|weapon] \
                         [--output-format gltf|glb|fbx|obj] \
                         [--target-poly 3000] \
                         [--no-texture] \
                         [--provider auto|tripo3d|meshy|stable-zero123|rodin|luma|mock] \
                         [--rig]   # 自動リギング(Mixamo)
                         [--lod]   # LOD自動生成
                         [--atlas] # テクスチャアトラス化
                         [--import-to <dir> --import-engine three|godot|unity|unreal]
                         [--out <dir>]

注意:
  - 各サービスのAPIキーが ~/.soloptilink/secrets/ に無ければ MockProvider で動作
  - 生成アセットの商用利用は各サービス規約に従うこと
  - APIキー設定方法は docs/ENGINE_COMPARISON.md 参照
USAGE
      exit 0;;
    *) echo "[ERR] 未知の引数: $1" >&2; exit 2;;
  esac
done

[[ -z "$PROMPT" ]] && { echo "[ERR] --prompt 未指定"; exit 2; }

SKILL_DIR="${SOLOPTILINK_GAME_SKILL_DIR:-$HOME/.claude/skills/soloptilink-game}"
PIPELINE_TS="$SKILL_DIR/lib/game/asset_pipeline/pipeline.ts"

mkdir -p "$OUT_DIR"

echo "🎨 [asset_forge_3d] 3Dアセット生成"
echo "    プロンプト: $PROMPT"
echo "    スタイル:    $STYLE"
echo "    カテゴリ:    $CATEGORY"
echo "    フォーマット: $OUTPUT_FORMAT"
echo "    ターゲット poly: $TARGET_POLY"
echo "    プロバイダー: $PROVIDER"
echo "    リギング:    $RIG"
echo "    LOD:         $LOD"
echo "    アトラス:    $ATLAS"
[[ -n "$IMPORT_TO" ]] && echo "    取り込み先:  $IMPORT_TO ($IMPORT_ENGINE)"

if [[ -f "$PIPELINE_TS" ]] && command -v npx >/dev/null 2>&1; then
  echo ""
  echo "    pipeline.ts を起動..."
  npx ts-node "$PIPELINE_TS" \
    --prompt "$PROMPT" \
    --style "$STYLE" \
    --category "$CATEGORY" \
    --output-format "$OUTPUT_FORMAT" \
    --target-poly "$TARGET_POLY" \
    --provider "$PROVIDER" \
    $([[ "$WITH_TEXTURE" == "true" ]] && echo "--with-texture") \
    $([[ "$RIG"     == "true" ]] && echo "--rig") \
    $([[ "$LOD"     == "true" ]] && echo "--lod") \
    $([[ "$ATLAS"   == "true" ]] && echo "--atlas") \
    $([[ -n "$IMPORT_TO" ]] && echo "--import-to $IMPORT_TO --import-engine $IMPORT_ENGINE") \
    --out "$OUT_DIR" \
    || echo "[WARN] pipeline.ts 実行失敗 → プロンプト案のみ出力"
else
  echo ""
  echo "    pipeline.ts未配置 or ts-node未インストール → プロンプト案のみ出力"
fi

# プロンプト案を必ず出力
cat > "$OUT_DIR/3D_PROMPT_${CATEGORY}.md" <<EOF
# 3Dアセット プロンプト案 - ${CATEGORY}

## 設定
- スタイル: ${STYLE}
- カテゴリ: ${CATEGORY}
- 出力フォーマット: ${OUTPUT_FORMAT}
- ターゲット ポリゴン数: ${TARGET_POLY}
- テクスチャ: $([ "$WITH_TEXTURE" = "true" ] && echo "あり" || echo "なし")

## 推奨プロバイダー(品質順)
1. **Tripo3D** (https://www.tripo3d.ai) - text-to-mesh, リギング, PBR
2. **Meshy** (https://www.meshy.ai) - text-to-mesh, リトポロジー
3. **Rodin** (Hyper3D) - 高品質、商用可
4. **Stable Zero123** - image-to-mesh、フォーマット限定
5. **Luma AI Genie** - text-to-mesh、軽量

## プロンプト
\`\`\`
${PROMPT}
\`\`\`

## ネガティブプロンプト(推奨)
\`\`\`
low quality, broken topology, untextured, deformed, multiple objects, blurry
\`\`\`

## 後処理推奨
- リトポロジー: Quad Remesher / ZRemesher
- リギング: Mixamo Auto-Rig(humanoid limited)
- LOD: meshoptimizer / gltf-transform
- テクスチャアトラス化: gltf-pack / 自前

## 著作権
- 生成アセットの商用利用可否は各サービスの利用規約に従う
- AI生成物の著作権は法的にグレー領域。重要案件では人間の修正・確認を経ること
EOF

echo ""
echo "✅ プロンプト案を $OUT_DIR/3D_PROMPT_${CATEGORY}.md に出力しました"
[[ -n "$IMPORT_TO" ]] && echo "✅ 取り込み先: $IMPORT_TO ($IMPORT_ENGINE エンジン)"
