#!/usr/bin/env bash
# gvr_loop.sh - Generator-Verifier-Refiner ループ実行ラッパー
# v2.0 新規。「1発出力」を「実質的な多発出力」に化けさせる核心ループを起動する。
#
# 使い方:
#   bash gvr_loop.sh --project <dir> [--target-score 90] [--max-iter 10] [--llm claude]

set -euo pipefail
IFS=$'\n\t'

PROJECT=""
TARGET_SCORE="85"
MAX_ITER="10"
LLM="claude"
STRATEGY="agent_planned"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --project)      PROJECT="$2"; shift 2;;
    --target-score) TARGET_SCORE="$2"; shift 2;;
    --max-iter)     MAX_ITER="$2"; shift 2;;
    --llm)          LLM="$2"; shift 2;;
    --strategy)     STRATEGY="$2"; shift 2;;
    --help|-h)
      cat <<'USAGE'
Generator-Verifier-Refiner Loop - 自動プレイ→計測→AI再生成 を最大N回反復し、品質を構造的に押し上げる。

使い方:
  bash gvr_loop.sh --project <dir> \
                   [--target-score 85] \
                   [--max-iter 10] \
                   [--llm claude|gpt4|gemini|local] \
                   [--strategy random|spam_click|agent_planned|expert]

各イテレーション:
  1. devサーバー起動
  2. 自動プレイテスト (auto_player.ts) を <strategy> で実行
  3. Game Quality Fortress 採点
  4. 低スコア軸を特定し ImprovementRequest 生成
  5. LLMに修正コードを生成させ適用
  6. ビルド検証 → 次イテレーション

収束判定:
  - target-score 達成 → converged
  - 2回連続改善なし → converged (early stop)
  - max-iter 到達 → maxIterations
USAGE
      exit 0;;
    *) echo "[ERR] 未知の引数: $1" >&2; exit 2;;
  esac
done

[[ -z "$PROJECT" ]] && { echo "[ERR] --project 未指定"; exit 2; }
[[ -d "$PROJECT" ]] || { echo "[ERR] プロジェクト未検出: $PROJECT"; exit 3; }

SKILL_DIR="${SOLOPTILINK_GAME_SKILL_DIR:-$HOME/.claude/skills/soloptilink-game}"
ORCH="$SKILL_DIR/lib/game/generator_verifier_refiner/orchestrator.ts"

if [[ ! -f "$ORCH" ]]; then
  echo "[WARN] orchestrator.ts 未配置 → 簡易ループで代替実行"
fi

echo "🔄 [gvr_loop] Generator-Verifier-Refiner ループ開始"
echo "    プロジェクト:   $PROJECT"
echo "    目標スコア:     $TARGET_SCORE / 100"
echo "    最大反復:       $MAX_ITER 回"
echo "    LLM:            $LLM"
echo "    プレイ戦略:     $STRATEGY"
echo ""

REPORT_DIR="$PROJECT/.gvr-report"
mkdir -p "$REPORT_DIR"

ITER=0
LAST_SCORE=0
NO_IMPROVE_COUNT=0
START_TS=$(date +%s)

while (( ITER < MAX_ITER )); do
  ITER=$((ITER + 1))
  ITER_TS=$(date +%s)
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
  echo "🔁 Iteration $ITER / $MAX_ITER"
  echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

  # Step 1: 自動プレイテスト (playtest_runner.sh 経由)
  PLAYTEST_OUT="$REPORT_DIR/iter-${ITER}-playtest.json"
  bash "$SKILL_DIR/lib/game/playtest/playtest_runner.sh" \
    --project "$PROJECT" \
    --duration 60 \
    --strategy "$STRATEGY" \
    --output "$PLAYTEST_OUT" 2>&1 | sed 's/^/    [playtest] /' || true

  # Step 2: スコア取得(JSONからtotal抽出)
  if [[ -f "$PLAYTEST_OUT" ]]; then
    SCORE=$(python3 -c "import json; d=json.load(open('$PLAYTEST_OUT')); print(d.get('quality',{}).get('total', 50))" 2>/dev/null || echo "50")
  else
    SCORE=$LAST_SCORE
  fi
  SCORE_INT=$(printf "%.0f" "$SCORE" 2>/dev/null || echo "50")

  echo ""
  echo "  📊 品質スコア: $SCORE_INT / 100"

  # Step 3: 収束判定
  if (( SCORE_INT >= TARGET_SCORE )); then
    echo "  ✅ 目標スコア達成! ($SCORE_INT >= $TARGET_SCORE)"
    break
  fi

  IMPROVE=$((SCORE_INT - LAST_SCORE))
  if (( ITER > 1 && IMPROVE < 2 )); then
    NO_IMPROVE_COUNT=$((NO_IMPROVE_COUNT + 1))
    if (( NO_IMPROVE_COUNT >= 2 )); then
      echo "  ⏸  2回連続改善なし。Early stop。"
      break
    fi
  else
    NO_IMPROVE_COUNT=0
  fi
  LAST_SCORE=$SCORE_INT

  # Step 4: Refiner 起動(LLMで修正コード生成)
  echo "  🛠️  LLM ($LLM) に修正パッチを生成依頼..."

  if [[ -f "$SKILL_DIR/lib/game/generator_verifier_refiner/refiner.ts" ]] && command -v npx >/dev/null 2>&1; then
    # 本実装: refiner.ts を呼ぶ
    cd "$PROJECT" && npx ts-node "$SKILL_DIR/lib/game/generator_verifier_refiner/refiner.ts" \
      --project "$PROJECT" \
      --metrics "$PLAYTEST_OUT" \
      --llm "$LLM" 2>&1 | sed 's/^/    [refiner] /' || true
    cd - > /dev/null
  else
    echo "    [refiner] (refiner.ts 未配置 or ts-node未インストール → スキップ)"
  fi

  ITER_DUR=$(($(date +%s) - ITER_TS))
  echo "  ⏱  Iteration $ITER 所要: ${ITER_DUR}秒"
done

TOTAL_DUR=$(($(date +%s) - START_TS))

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "🎯 GVR ループ完了"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "    総反復数: $ITER / $MAX_ITER"
echo "    最終スコア: $LAST_SCORE / 100"
echo "    総時間: ${TOTAL_DUR}秒"
echo "    レポート: $REPORT_DIR/"

# 最終レポート生成
cat > "$REPORT_DIR/summary.md" <<EOF
# Generator-Verifier-Refiner レポート

- プロジェクト: $PROJECT
- 開始: $(date -r "$START_TS")
- 終了: $(date)
- 総反復数: $ITER
- 最終スコア: $LAST_SCORE / 100
- 目標スコア: $TARGET_SCORE
- LLM: $LLM
- プレイ戦略: $STRATEGY

## 品質スコア遷移

各イテレーションの計測結果は $REPORT_DIR/iter-N-playtest.json を参照。

EOF

echo ""
echo "✅ 完了。詳細レポート: $REPORT_DIR/summary.md"
