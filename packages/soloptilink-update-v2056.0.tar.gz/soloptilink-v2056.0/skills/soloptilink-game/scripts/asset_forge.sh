#!/usr/bin/env bash
# asset_forge.sh - 素材生成プロンプト出力 + API呼び出し雛形
# Stable Diffusion / Suno / ElevenLabs を呼んで画像・BGM・SE・ボイスを生成
#
# ⚠️ API キーは ~/.soloptilink/secrets/ で管理。本スキルからは絶対に書き出さない。

set -euo pipefail

MODE=""
PROMPT=""
OUT_DIR="./public/assets"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --mode)   MODE="$2";   shift 2;;       # image|music|se|voice
    --prompt) PROMPT="$2"; shift 2;;
    --out)    OUT_DIR="$2"; shift 2;;
    --help|-h)
      cat <<'USAGE'
使い方: bash asset_forge.sh --mode <image|music|se|voice> --prompt "<プロンプト>" --out <dir>

モード:
  image  - Stable Diffusion / DALL-E でスプライト/背景/UI生成
  music  - Suno / MusicGen でBGM生成
  se     - ElevenLabs Sound Effects / Freesound API でSE生成
  voice  - ElevenLabs Voice / VOICEVOX でセリフ音声生成

注意: APIキー無しの場合はプロンプト案のみ出力(ファイル名/プロンプト/推奨パラメータ)
USAGE
      exit 0;;
    *) echo "[ERR] 未知の引数: $1" >&2; exit 2;;
  esac
done

[[ -z "$MODE"   ]] && { echo "[ERR] --mode 未指定"; exit 2; }
[[ -z "$PROMPT" ]] && { echo "[ERR] --prompt 未指定"; exit 2; }

mkdir -p "$OUT_DIR"

case "$MODE" in
  image)
    SUBDIR="$OUT_DIR/images"
    mkdir -p "$SUBDIR"
    if [[ -n "${OPENAI_API_KEY:-}" ]]; then
      echo "[INFO] DALL-E 3 で画像生成中..."
      # TODO: curl で OpenAI Images API 呼び出し
      echo "[TODO] DALL-E 3 API 呼び出し未実装(本番ではここに curl を入れる)"
    elif [[ -n "${STABILITY_API_KEY:-}" ]]; then
      echo "[INFO] Stable Diffusion 3 で画像生成中..."
      # TODO: curl で Stability AI API 呼び出し
      echo "[TODO] SD3 API 呼び出し未実装"
    else
      echo "[INFO] APIキー無し → プロンプト案のみ出力"
    fi
    cat > "$SUBDIR/PROMPTS.md" <<EOF
# 画像素材プロンプト案

## 生成パラメータ
- モデル: SDXL 1.0 / FLUX.1 dev / DALL-E 3 のいずれか
- サイズ: 1024x1024 (スプライトなら 512x512 → 等倍リサイズ推奨)
- ステップ: 30
- CFG: 7.0
- スタイル: ゲームスプライト, pixel art / 2D anime / 3D LowPoly のいずれか

## プロンプト
\`\`\`
$PROMPT
\`\`\`

## ネガティブプロンプト (推奨)
\`\`\`
blurry, low quality, text, watermark, signature, distorted, deformed
\`\`\`

## バリエーション展開
- 同キャラの異なるポーズ × 4
- 同シーンの異なる時間帯(昼/夕/夜) × 3
- 同UIの異なる状態(通常/ホバー/アクティブ/無効) × 4
EOF
    echo "✅ プロンプト案を $SUBDIR/PROMPTS.md に出力しました"
    ;;
  music)
    SUBDIR="$OUT_DIR/sounds"
    mkdir -p "$SUBDIR"
    cat > "$SUBDIR/BGM_PROMPTS.md" <<EOF
# BGM プロンプト案

## 推奨サービス
- Suno AI (https://suno.ai) - ボーカル有り
- Udio (https://udio.com) - ハイクオリティ
- AIVA (https://aiva.ai) - インスト中心
- MusicGen (Meta) - オープン

## プロンプト
\`\`\`
$PROMPT
\`\`\`

## 推奨パラメータ
- 長さ: 60-120秒 (ループ前提)
- BPM: ジャンルに応じて 80-160
- ループポイント: 30秒/60秒で自然に切れる構成
- フェード: -0.5sec fadeOut → -0.5sec fadeIn でクロスフェード

## 出力フォーマット
- ogg vorbis (Web推奨, サイズ小)
- mp3 128kbps (互換性最大)
- wav (素材原本、編集用)

## 著作権
生成サービスの利用規約を必ず確認。商用利用可否を明確に。
EOF
    echo "✅ BGM プロンプト案を $SUBDIR/BGM_PROMPTS.md に出力しました"
    ;;
  se)
    SUBDIR="$OUT_DIR/sounds/se"
    mkdir -p "$SUBDIR"
    cat > "$SUBDIR/SE_PROMPTS.md" <<EOF
# SE プロンプト案

## 推奨サービス
- ElevenLabs Sound Effects
- Freesound (https://freesound.org) - CC-BY ライブラリ
- 効果音ラボ (https://soundeffect-lab.info) - 商用可・無料(日本)

## プロンプト
\`\`\`
$PROMPT
\`\`\`

## 推奨パラメータ
- 長さ: 0.1-2.0秒 (短いSEほど重要)
- 音量: -6dB (BGMより小さく)
- フォーマット: ogg / mp3
- 同時発音: 4-8 voiceまで(優先度で間引き)
EOF
    echo "✅ SE プロンプト案を $SUBDIR/SE_PROMPTS.md に出力しました"
    ;;
  voice)
    SUBDIR="$OUT_DIR/sounds/voice"
    mkdir -p "$SUBDIR"
    cat > "$SUBDIR/VOICE_PROMPTS.md" <<EOF
# ボイス プロンプト案

## 推奨サービス(日本語)
- VOICEVOX (https://voicevox.hiroshiba.jp) - 無料・商用可・キャラクター40+
- ElevenLabs (https://elevenlabs.io) - 英語/多言語、感情豊か
- にじボイス - 商用可・感情指定可能

## プロンプト/セリフ
\`\`\`
$PROMPT
\`\`\`

## 推奨パラメータ
- ピッチ: キャラに合わせて
- 速度: 1.0倍標準、緊迫シーンで1.2倍
- 音量: -3dB (BGMと同等かやや上)
- フォーマット: ogg vorbis 96kbps

## 著作権
- VOICEVOX: 商用可、キャラ名表記必須
- ElevenLabs: 有料プランで商用可
- 著名声優の声を学習させた音声: 法的リスク高、避ける
EOF
    echo "✅ ボイス プロンプト案を $SUBDIR/VOICE_PROMPTS.md に出力しました"
    ;;
  *)
    echo "[ERR] 未対応モード: $MODE"
    echo "    対応: image | music | se | voice"
    exit 4;;
esac
