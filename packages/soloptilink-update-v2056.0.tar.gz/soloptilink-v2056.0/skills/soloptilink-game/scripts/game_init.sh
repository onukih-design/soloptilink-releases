#!/usr/bin/env bash
# game_init.sh - ゲームプロジェクト雛形を1コマンドで展開
# /soloptilink-game の Step 4 で呼ばれる
#
# 使い方:
#   bash game_init.sh --genre <puzzle|action_2d|shooter|...> \
#                     --engine <phaser|pixi|three|godot> \
#                     --name "<project_name>" \
#                     --target <dir>

set -euo pipefail
IFS=$'\n\t'

# --- 引数パース -------------------------------------------------------------
GENRE=""
ENGINE=""
NAME=""
TARGET=""
SCALE="casual"
PLATFORM="web"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --genre)    GENRE="$2"; shift 2;;
    --engine)   ENGINE="$2"; shift 2;;
    --name)     NAME="$2"; shift 2;;
    --target)   TARGET="$2"; shift 2;;
    --scale)    SCALE="$2"; shift 2;;
    --platform) PLATFORM="$2"; shift 2;;
    --help|-h)
      echo "使い方: bash game_init.sh --genre <id> --engine <id> --name <name> --target <dir>"
      exit 0;;
    *) echo "[ERR] 未知の引数: $1" >&2; exit 2;;
  esac
done

[[ -z "$GENRE"   ]] && { echo "[ERR] --genre 未指定"; exit 2; }
[[ -z "$ENGINE"  ]] && { echo "[ERR] --engine 未指定"; exit 2; }
[[ -z "$NAME"    ]] && { echo "[ERR] --name 未指定"; exit 2; }
[[ -z "$TARGET"  ]] && { echo "[ERR] --target 未指定"; exit 2; }

# --- スキル本体ディレクトリ -------------------------------------------------
SKILL_DIR="${SOLOPTILINK_GAME_SKILL_DIR:-$HOME/.claude/skills/soloptilink-game}"
[[ -d "$SKILL_DIR" ]] || { echo "[ERR] スキル本体が見つからない: $SKILL_DIR"; exit 3; }

ENGINE_JSON="$SKILL_DIR/lib/game/engines/${ENGINE}.json"
GENRE_JSON="$SKILL_DIR/lib/game/genres/${GENRE}.json"

[[ -f "$ENGINE_JSON" ]] || { echo "[ERR] エンジン定義なし: $ENGINE_JSON"; exit 4; }
[[ -f "$GENRE_JSON"  ]] || { echo "[ERR] ジャンル定義なし: $GENRE_JSON"; exit 4; }

# --- ターゲット作成 ---------------------------------------------------------
echo "🎮 [game_init] ゲームプロジェクト雛形を展開中..."
echo "    プロジェクト名: $NAME"
echo "    ジャンル:       $GENRE"
echo "    エンジン:       $ENGINE"
echo "    規模:           $SCALE"
echo "    プラットフォーム: $PLATFORM"
echo "    出力先:         $TARGET"

mkdir -p "$TARGET"
cd "$TARGET"

# --- package.json -----------------------------------------------------------
cat > package.json <<EOF
{
  "name": "${NAME// /-}",
  "version": "0.1.0",
  "description": "$NAME - ${GENRE} game built with ${ENGINE}",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "vite build",
    "preview": "vite preview",
    "playtest": "bash $SKILL_DIR/lib/game/playtest/playtest_runner.sh --project ."
  },
  "devDependencies": {
    "vite": "^5.0.0",
    "typescript": "^5.3.0"
  }
}
EOF

# --- エンジン別 dependencies 追記 -------------------------------------------
case "$ENGINE" in
  phaser)
    node -e "const p=require('./package.json');p.dependencies={...(p.dependencies||{}),'phaser':'^3.70.0'};require('fs').writeFileSync('package.json',JSON.stringify(p,null,2));" 2>/dev/null || \
    python3 -c "import json;p=json.load(open('package.json'));p.setdefault('dependencies',{})['phaser']='^3.70.0';json.dump(p,open('package.json','w'),indent=2)"
    ;;
  pixi)
    node -e "const p=require('./package.json');p.dependencies={...(p.dependencies||{}),'pixi.js':'^8.0.0','@pixi/sound':'^6.0.0'};require('fs').writeFileSync('package.json',JSON.stringify(p,null,2));" 2>/dev/null || \
    python3 -c "import json;p=json.load(open('package.json'));p.setdefault('dependencies',{}).update({'pixi.js':'^8.0.0','@pixi/sound':'^6.0.0'});json.dump(p,open('package.json','w'),indent=2)"
    ;;
  three)
    node -e "const p=require('./package.json');p.dependencies={...(p.dependencies||{}),'three':'^0.160.0','cannon-es':'^0.20.0'};p.devDependencies={...(p.devDependencies||{}),'@types/three':'^0.160.0'};require('fs').writeFileSync('package.json',JSON.stringify(p,null,2));" 2>/dev/null || \
    python3 -c "import json;p=json.load(open('package.json'));p.setdefault('dependencies',{}).update({'three':'^0.160.0','cannon-es':'^0.20.0'});p.setdefault('devDependencies',{})['@types/three']='^0.160.0';json.dump(p,open('package.json','w'),indent=2)"
    ;;
  godot)
    # Godot は npm 外。project.godot を直接作る
    echo "[INFO] Godot プロジェクトは npm 外で構築されます"
    ;;
  *) echo "[ERR] 未対応エンジン: $ENGINE"; exit 5;;
esac

# --- ディレクトリ構造 -------------------------------------------------------
mkdir -p src/scenes src/entities src/systems src/ui src/utils
mkdir -p public/assets/{images,sounds,fonts,fx}
mkdir -p docs

# --- 共通 .gitignore / tsconfig ---------------------------------------------
cat > .gitignore <<'EOF'
node_modules/
dist/
.vite/
*.log
.DS_Store
.env
.env.local
EOF

cat > tsconfig.json <<'EOF'
{
  "compilerOptions": {
    "target": "ES2022",
    "module": "ESNext",
    "moduleResolution": "bundler",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "resolveJsonModule": true,
    "allowImportingTsExtensions": false,
    "noEmit": false,
    "outDir": "./dist",
    "rootDir": "./src",
    "types": ["vite/client"]
  },
  "include": ["src/**/*"]
}
EOF

# --- index.html -------------------------------------------------------------
cat > index.html <<EOF
<!DOCTYPE html>
<html lang="ja">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no" />
  <meta name="theme-color" content="#000000" />
  <title>$NAME</title>
  <style>
    body { margin: 0; padding: 0; background: #000; overflow: hidden; display: flex; justify-content: center; align-items: center; height: 100vh; }
    #game { display: block; max-width: 100vw; max-height: 100vh; }
    /* アクセシビリティ: フォーカスリングを明示 */
    *:focus-visible { outline: 2px solid #fff; outline-offset: 2px; }
  </style>
</head>
<body>
  <div id="game" role="main" aria-label="$NAME ゲーム画面"></div>
  <script type="module" src="/src/main.ts"></script>
</body>
</html>
EOF

# --- src/main.ts (エンジン別雛形) -------------------------------------------
case "$ENGINE" in
  phaser)
    cat > src/main.ts <<'EOF'
// メインエントリ - Phaser 3
import Phaser from 'phaser';
import { BootScene } from './scenes/BootScene';
import { PreloadScene } from './scenes/PreloadScene';
import { TitleScene } from './scenes/TitleScene';
import { GameScene } from './scenes/GameScene';
import { PauseScene } from './scenes/PauseScene';
import { ResultScene } from './scenes/ResultScene';
import { SettingsScene } from './scenes/SettingsScene';

// 60fps固定設定
const config: Phaser.Types.Core.GameConfig = {
  type: Phaser.AUTO,
  parent: 'game',
  width: 800,
  height: 600,
  backgroundColor: '#1a1a1a',
  fps: { target: 60, forceSetTimeOut: false },
  scale: {
    mode: Phaser.Scale.FIT,
    autoCenter: Phaser.Scale.CENTER_BOTH,
  },
  physics: {
    default: 'arcade',
    arcade: { gravity: { x: 0, y: 0 }, debug: false },
  },
  scene: [BootScene, PreloadScene, TitleScene, GameScene, PauseScene, ResultScene, SettingsScene],
};

new Phaser.Game(config);

// 入力遅延計測のフック (window.__playtest_metrics が存在すれば記録)
if (typeof window !== 'undefined') {
  (window as any).__game_started_at = performance.now();
}
EOF
    ;;
  pixi)
    cat > src/main.ts <<'EOF'
// メインエントリ - PixiJS 8
import { Application, Assets } from 'pixi.js';
import { SceneManager } from './systems/SceneManager';
import { TitleScene } from './scenes/TitleScene';

async function main() {
  const app = new Application();
  await app.init({
    width: 800,
    height: 600,
    backgroundColor: 0x1a1a1a,
    antialias: true,
    resolution: window.devicePixelRatio || 1,
    autoDensity: true,
  });
  const gameRoot = document.getElementById('game');
  if (gameRoot) gameRoot.appendChild(app.canvas);

  const sceneMgr = new SceneManager(app);
  await sceneMgr.start(new TitleScene());

  // 60fps固定ループ
  app.ticker.maxFPS = 60;

  if (typeof window !== 'undefined') {
    (window as any).__game_started_at = performance.now();
  }
}

main();
EOF
    ;;
  three)
    cat > src/main.ts <<'EOF'
// メインエントリ - Three.js
import * as THREE from 'three';
import { GameLoop } from './systems/GameLoop';

const scene = new THREE.Scene();
scene.background = new THREE.Color(0x1a1a1a);

const camera = new THREE.PerspectiveCamera(75, window.innerWidth / window.innerHeight, 0.1, 1000);
camera.position.z = 5;

const renderer = new THREE.WebGLRenderer({ antialias: true });
renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

const gameRoot = document.getElementById('game');
if (gameRoot) gameRoot.appendChild(renderer.domElement);

// 環境光+メインライト
scene.add(new THREE.AmbientLight(0xffffff, 0.4));
const directional = new THREE.DirectionalLight(0xffffff, 0.8);
directional.position.set(5, 10, 5);
scene.add(directional);

// 60fps固定ループ
const loop = new GameLoop(scene, camera, renderer);
loop.start();

// リサイズ対応
window.addEventListener('resize', () => {
  camera.aspect = window.innerWidth / window.innerHeight;
  camera.updateProjectionMatrix();
  renderer.setSize(window.innerWidth, window.innerHeight);
});

if (typeof window !== 'undefined') {
  (window as any).__game_started_at = performance.now();
}
EOF
    ;;
  godot)
    cat > project.godot <<EOF
; Godot 4 プロジェクト設定
config_version=5

[application]
config/name="$NAME"
config/features=PackedStringArray("4.2", "Web")
run/main_scene="res://scenes/Title.tscn"

[display]
window/size/viewport_width=1280
window/size/viewport_height=720

[input]
ui_accept={
"deadzone": 0.5,
"events": [Object(InputEventKey,"keycode":32),Object(InputEventKey,"keycode":4194309)]
}
EOF
    ;;
esac

# --- ジャンル別シーン雛形を展開(現状 Phaser のみ雛形あり。他エンジンは雛形なしで進む) ---
if [[ "$ENGINE" == "phaser" ]]; then
  cat > src/scenes/BootScene.ts <<'EOF'
import Phaser from 'phaser';
export class BootScene extends Phaser.Scene {
  constructor() { super('Boot'); }
  preload() {
    // ブートで読むのは最小限のロゴ・フォント
  }
  create() {
    this.scene.start('Preload');
  }
}
EOF

  cat > src/scenes/PreloadScene.ts <<'EOF'
import Phaser from 'phaser';
export class PreloadScene extends Phaser.Scene {
  constructor() { super('Preload'); }
  preload() {
    // 全アセットここで読む
    const loadBar = this.add.graphics();
    this.load.on('progress', (p: number) => {
      loadBar.clear();
      loadBar.fillStyle(0xffffff, 1);
      loadBar.fillRect(100, 290, 600 * p, 20);
    });
    // 例: this.load.image('player', 'assets/images/player.png');
  }
  create() {
    this.scene.start('Title');
  }
}
EOF

  cat > src/scenes/TitleScene.ts <<EOF
import Phaser from 'phaser';
export class TitleScene extends Phaser.Scene {
  constructor() { super('Title'); }
  create() {
    this.add.text(400, 200, '$NAME', { fontSize: '48px', color: '#fff' }).setOrigin(0.5);
    this.add.text(400, 350, 'タップ または スペースキーで開始', { fontSize: '20px', color: '#aaa' }).setOrigin(0.5);
    this.input.once('pointerdown', () => this.scene.start('Game'));
    this.input.keyboard?.once('keydown-SPACE', () => this.scene.start('Game'));
  }
}
EOF

  cat > src/scenes/GameScene.ts <<'EOF'
import Phaser from 'phaser';

/**
 * ゲームのメインシーン。
 * 生成時点で「操作できて・当たり判定があって・スコアが動く」最小の遊べる状態になっている。
 * ここを土台に、作りたいゲームのルールへ書き換えていく。
 */
export class GameScene extends Phaser.Scene {
  private player!: Phaser.GameObjects.Rectangle;
  private target!: Phaser.GameObjects.Rectangle;
  private cursors!: Phaser.Types.Input.Keyboard.CursorKeys;
  private scoreText!: Phaser.GameObjects.Text;
  private score = 0;
  /** プレイヤーの移動速度(ピクセル/秒) */
  private readonly speed = 320;

  constructor() { super('Game'); }

  create() {
    const { width, height } = this.scale;

    this.add.text(20, 20, 'ゲームメインシーン', { fontSize: '24px', color: '#fff' });
    this.add.text(20, 50, '矢印キーまたはドラッグで移動 / Escでポーズ', { fontSize: '14px', color: '#aaa' });
    this.scoreText = this.add.text(20, 76, 'スコア: 0', { fontSize: '18px', color: '#7fd' });

    // 操作対象
    this.player = this.add.rectangle(width / 2, height / 2, 36, 36, 0x4fc3f7);
    // 取りに行く対象
    this.target = this.add.rectangle(0, 0, 24, 24, 0xffd54f);
    this.placeTarget();

    this.cursors = this.input.keyboard!.createCursorKeys();

    // ポインタでも動かせるようにする(スマートフォン対応)
    this.input.on('pointermove', (p: Phaser.Input.Pointer) => {
      if (p.isDown) this.player.setPosition(p.x, p.y);
    });

    this.input.keyboard?.on('keydown-ESC', () => this.scene.launch('Pause').pause());
  }

  update(_time: number, delta: number) {
    const step = (this.speed * delta) / 1000;
    if (this.cursors.left.isDown) this.player.x -= step;
    if (this.cursors.right.isDown) this.player.x += step;
    if (this.cursors.up.isDown) this.player.y -= step;
    if (this.cursors.down.isDown) this.player.y += step;

    // 画面外へ出さない
    const { width, height } = this.scale;
    this.player.x = Phaser.Math.Clamp(this.player.x, 18, width - 18);
    this.player.y = Phaser.Math.Clamp(this.player.y, 18, height - 18);

    // 当たり判定 — 触れたら加点して次の位置へ
    if (Phaser.Math.Distance.Between(this.player.x, this.player.y, this.target.x, this.target.y) < 30) {
      this.score += 1;
      this.scoreText.setText('スコア: ' + this.score);
      this.placeTarget();
    }
  }

  /** 取得対象を画面内のランダムな位置へ置き直す */
  private placeTarget() {
    const { width, height } = this.scale;
    this.target.setPosition(
      Phaser.Math.Between(40, width - 40),
      Phaser.Math.Between(110, height - 40),
    );
  }
}
EOF

  cat > src/scenes/PauseScene.ts <<'EOF'
import Phaser from 'phaser';
export class PauseScene extends Phaser.Scene {
  constructor() { super('Pause'); }
  create() {
    this.cameras.main.setBackgroundColor('rgba(0,0,0,0.5)');
    this.add.text(400, 300, 'PAUSE', { fontSize: '48px', color: '#fff' }).setOrigin(0.5);
    this.input.keyboard?.once('keydown-ESC', () => {
      this.scene.resume('Game');
      this.scene.stop();
    });
  }
}
EOF

  cat > src/scenes/ResultScene.ts <<'EOF'
import Phaser from 'phaser';
export class ResultScene extends Phaser.Scene {
  constructor() { super('Result'); }
  init(data: { score: number }) { (this as any).score = data?.score ?? 0; }
  create() {
    this.add.text(400, 250, 'RESULT', { fontSize: '48px', color: '#fff' }).setOrigin(0.5);
    this.add.text(400, 320, `Score: ${(this as any).score}`, { fontSize: '32px', color: '#fff' }).setOrigin(0.5);
    this.add.text(400, 400, 'タップでタイトルへ', { fontSize: '20px', color: '#aaa' }).setOrigin(0.5);
    this.input.once('pointerdown', () => this.scene.start('Title'));
  }
}
EOF

  cat > src/scenes/SettingsScene.ts <<'EOF'
import Phaser from 'phaser';
export class SettingsScene extends Phaser.Scene {
  constructor() { super('Settings'); }
  create() {
    this.add.text(400, 100, '設定', { fontSize: '36px', color: '#fff' }).setOrigin(0.5);
    // 音量・操作・言語・アクセシビリティ設定UIをここに
    this.add.text(400, 250, '音量: ████████░░ 80%', { fontSize: '20px', color: '#fff' }).setOrigin(0.5);
    this.add.text(400, 300, 'BGM:  ████████░░ 80%', { fontSize: '20px', color: '#fff' }).setOrigin(0.5);
    this.add.text(400, 350, '言語: 日本語', { fontSize: '20px', color: '#fff' }).setOrigin(0.5);
    this.add.text(400, 400, '色覚配慮モード: OFF', { fontSize: '20px', color: '#fff' }).setOrigin(0.5);
  }
}
EOF
fi

# --- セーブ/ロード共通モジュール --------------------------------------------
cat > src/systems/SaveLoad.ts <<'EOF'
// セーブ/ロード - localStorage + 任意でIndexedDB
const KEY_PREFIX = 'game_save_';

export interface SaveData {
  version: number;
  timestamp: number;
  payload: Record<string, unknown>;
}

export function save(slot: string, payload: Record<string, unknown>): void {
  const data: SaveData = { version: 1, timestamp: Date.now(), payload };
  try {
    localStorage.setItem(KEY_PREFIX + slot, JSON.stringify(data));
  } catch (e) {
    console.warn('[SaveLoad] localStorage 書き込み失敗', e);
  }
}

export function load(slot: string): SaveData | null {
  try {
    const raw = localStorage.getItem(KEY_PREFIX + slot);
    return raw ? JSON.parse(raw) as SaveData : null;
  } catch (e) {
    console.warn('[SaveLoad] localStorage 読み込み失敗', e);
    return null;
  }
}

export function deleteSlot(slot: string): void {
  localStorage.removeItem(KEY_PREFIX + slot);
}

export function listSlots(): string[] {
  const slots: string[] = [];
  for (let i = 0; i < localStorage.length; i++) {
    const key = localStorage.key(i);
    if (key && key.startsWith(KEY_PREFIX)) slots.push(key.substring(KEY_PREFIX.length));
  }
  return slots;
}
EOF

# --- 設定モジュール ---------------------------------------------------------
cat > src/systems/GameSettings.ts <<'EOF'
// プレイヤー設定 - 音量・操作・言語・アクセシビリティ
export interface GameSettings {
  volume: { master: number; bgm: number; se: number; voice: number };
  controls: 'touch' | 'mouse' | 'keyboard' | 'gamepad' | 'auto';
  language: 'ja' | 'en' | 'zh-CN' | 'ko';
  accessibility: { colorBlindMode: 'off' | 'protanopia' | 'deuteranopia' | 'tritanopia'; fontScale: number; subtitles: boolean; reducedMotion: boolean };
}

const DEFAULT: GameSettings = {
  volume: { master: 0.8, bgm: 0.8, se: 0.9, voice: 1.0 },
  controls: 'auto',
  language: 'ja',
  accessibility: { colorBlindMode: 'off', fontScale: 1.0, subtitles: true, reducedMotion: false },
};

const KEY = 'game_settings';

export function loadSettings(): GameSettings {
  try {
    const raw = localStorage.getItem(KEY);
    return raw ? { ...DEFAULT, ...JSON.parse(raw) } : DEFAULT;
  } catch { return DEFAULT; }
}

export function saveSettings(s: GameSettings): void {
  localStorage.setItem(KEY, JSON.stringify(s));
}
EOF

# --- README -----------------------------------------------------------------
cat > README.md <<EOF
# $NAME

ジャンル: \`$GENRE\` / エンジン: \`$ENGINE\` / 規模: \`$SCALE\` / 配信先: \`$PLATFORM\`

SoloptiLinkAI v1.0 Game Production Engine で生成された 90%完成プロジェクト。

## セットアップ

\`\`\`bash
npm install
npm run dev
\`\`\`

## 操作

- タップ / マウスクリック: 決定
- スペース / Enter: 決定
- ESC: ポーズ

## ビルド

\`\`\`bash
npm run build  # dist/ に生成
npm run preview  # ビルド結果を確認
\`\`\`

## プレイテスト(自動)

\`\`\`bash
npm run playtest
\`\`\`

## ライセンス

未設定。配信前に LICENSE ファイルを追加してください(MIT / CC-BY / 独自など)。

---

Generated by SoloptiLinkAI v1.0 \`/soloptilink-game\`
EOF

# --- 完了 -------------------------------------------------------------------
echo ""
echo "✅ [game_init] 雛形展開完了!"
echo ""
echo "次のステップ:"
echo "  cd $TARGET"
echo "  npm install"
echo "  npm run dev"
echo ""
echo "GDD作成 (推奨):"
echo "  node $SKILL_DIR/lib/game/gdd/gdd_generator.ts > ./GDD.md"
echo ""
echo "プレイテスト:"
echo "  bash $SKILL_DIR/lib/game/playtest/playtest_runner.sh --project $TARGET"
echo ""
