#!/usr/bin/env bash
# playtest.sh - lib/game/playtest/playtest_runner.sh への薄いラッパー
# /soloptilink-game の Step 7 で呼ばれる

set -euo pipefail
IFS=$'\n\t'

SKILL_DIR="${SOLOPTILINK_GAME_SKILL_DIR:-$HOME/.claude/skills/soloptilink-game}"
RUNNER="$SKILL_DIR/lib/game/playtest/playtest_runner.sh"

if [[ ! -x "$RUNNER" ]]; then
  echo "[ERR] playtest_runner.sh が見つからない: $RUNNER" >&2
  echo "      スキルが破損している可能性があります。" >&2
  exit 1
fi

# 引数をそのまま渡す
exec bash "$RUNNER" "$@"
