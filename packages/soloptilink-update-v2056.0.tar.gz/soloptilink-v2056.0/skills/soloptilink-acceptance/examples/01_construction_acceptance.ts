/**
 * 例題1: 建設業向け工事原価管理システムの検収一式生成
 *
 * 姉妹スキル /soloptilink-rfp の examples/01_construction_proposal.ts と
 * 案件名・発注者・受託者を揃えてあり、提案→検収まで一貫したサンプルになる。
 *
 * 実行: bun run examples/01_construction_acceptance.ts
 *       node --import tsx examples/01_construction_acceptance.ts
 */

import {
  generateAcceptancePackage,
  createBugReportTemplate,
  transitionStatus,
  type BugReport,
} from '../lib/index';

// 1. UAT 期間中に検出されたバグ票 (代表例)
let bugA: BugReport = createBugReportTemplate({
  id: 'BUG-20261101-001',
  reporter: '顧客 山田 太郎',
  module: '帳票PDF出力',
  severity: 'B',
  phase: 'UAT',
  title: '見積書PDFのフッタにページ番号が出力されない',
});
bugA = transitionStatus(bugA, '調査中', '受託者 高橋', '担当アサイン');
bugA = transitionStatus(bugA, '修正中', '受託者 高橋', 'PDFテンプレ修正');
bugA = transitionStatus(bugA, '修正完了', '受託者 高橋', 'fix commit abc1234');
bugA = transitionStatus(bugA, '再テスト中', '顧客 山田 太郎');
bugA = transitionStatus(bugA, 'クローズ', '顧客 山田 太郎', '再現せず');
bugA.fix_commit = 'abc1234';
bugA.assignee = '受託者 高橋';
bugA.verifier = '顧客 山田 太郎';
bugA.reproduction_steps = [
  '見積書一覧を開く',
  '対象案件を選択',
  'PDF出力ボタンを押下',
];
bugA.expected = '全ページに 1/3, 2/3, 3/3 のページ番号が表示される';
bugA.actual = '1ページ目以降のフッタにページ番号が出力されない';
bugA.environment = { os: 'Windows 11', browser: 'Chrome 130', version: 'v1.0.0' };

let bugB: BugReport = createBugReportTemplate({
  id: 'BUG-20261103-002',
  reporter: '顧客 佐藤 花子',
  module: '工事案件',
  severity: 'C',
  phase: 'UAT',
  title: '案件名が30文字超で省略表示されないツールチップが必要',
});
bugB.reproduction_steps = ['工事案件一覧を開く', '案件名を30文字以上にしたデータを表示'];
bugB.expected = '一覧で省略表示+ツールチップで全文表示';
bugB.actual = 'はみ出してレイアウトが崩れる';

const result = generateAcceptancePackage({
  project_name: '工事原価管理システム',
  industry: 'construction',
  client_type: '民間',
  criteria_mode: 'standard',
  warranty_months: 6,
  locale: 'ja',
  client: {
    name: '株式会社サンプル建設',
    address: '東京都港区...',
    representative: '山田 太郎',
    representative_title: '代表取締役',
    contact_person: '情シス課 鈴木',
    seal: 'images/seal_sample_kensetsu.png',
  },
  contractor: {
    name: 'SoloptiLink株式会社',
    address: '東京都千代田区...',
    representative: '山田 太一',
    representative_title: '代表取締役',
    contact_person: 'PM 高橋',
    seal: 'images/seal_solopti.png',
  },
  deliverables: [
    { name: '要件定義書', format: '.docx', version: 'v1.2.0', copies: 2 },
    { name: '基本設計書', format: '.docx', version: 'v1.1.0', copies: 2 },
    { name: '詳細設計書', format: '.docx', version: 'v1.0.0', copies: 2 },
    { name: 'ソースコード一式', format: 'git tag v1.0.0', version: 'v1.0.0' },
    { name: 'テスト報告書', format: '.xlsx + .pdf', version: 'v1.0.0' },
    { name: '運用手順書', format: '.docx', version: 'v1.0.0', copies: 2 },
    { name: '研修資料', format: '.pptx', version: 'v1.0.0' },
  ],
  request_submission_date: '2026-11-15T09:00:00.000Z',
  acceptance_date: '2026-12-05T09:00:00.000Z',
  acceptance_window_start: '2026-11-16T09:00:00.000Z',
  acceptance_window_end: '2026-12-04T18:00:00.000Z',
  remaining_bugs: { P1: 0, P2: 0, P3: 1, P4: 0 },
  bug_reports: [bugA, bugB],
  test_plan_input: {
    project_name: '工事原価管理システム',
    industry: 'construction',
    client_type: '民間',
    criteria_mode: 'standard',
    client_team: [
      { name: '山田 太郎', role: '責任者 (代表取締役)', responsibilities: ['最終承認', '判定会議出席'] },
      { name: '鈴木 一郎', role: '情シス課', responsibilities: ['UAT 計画調整', 'シナリオ実施'] },
      { name: '佐藤 花子', role: '現場監督', responsibilities: ['業務シナリオテスト', '不具合起票'] },
    ],
    contractor_team: [
      { name: '山田 太一', role: 'PM', responsibilities: ['進捗管理', 'リスク対応', '判定会議出席'] },
      { name: '高橋 健', role: 'Lead Engineer', responsibilities: ['不具合修正', '再テスト立会'] },
      { name: '田中 美咲', role: 'QA', responsibilities: ['テスト立会', 'リグレッション'] },
    ],
    schedule: {
      uat_start: '2026-11-16',
      uat_end: '2026-11-27',
      fix_start: '2026-11-28',
      fix_end: '2026-12-02',
      retest_start: '2026-12-03',
      retest_end: '2026-12-04',
      judgment_meeting: '2026-12-04T15:00',
      acceptance_deadline: '2026-12-05',
    },
    environment: {
      name: 'production-equivalent',
      description: '本番と同等構成 (App x2 / DB Primary+Standby / Redis / 勘定奉行接続)',
      data_source: 'masked-production',
      external_systems: ['勘定奉行', 'Microsoft 365 SSO', 'SendGrid'],
      access_control: 'IP制限 + 顧客VPN経由',
    },
    approaches: ['scenario_based', 'exploratory', 'regression', 'performance', 'security'],
    scope: {
      modules: ['認証', '工事案件', '見積書', '注文書', '請求書', '工事日報', 'ダッシュボード', '帳票PDF出力', '監査ログ'],
      scenarios: [
        '新規工事案件の登録〜見積書発行〜注文書発行〜工事日報入力〜請求書発行のE2E',
        '月次集計バッチ実行と粗利率レポート出力',
        '勘定奉行への仕訳CSV連携',
      ],
      out_of_scope: ['会計仕訳の最終確定 (勘定奉行側責務)', '労務費の自動計算 (フェーズ2)'],
    },
  },
  test_spec_input: {
    project_name: '工事原価管理システム',
    industry: 'construction',
    modules: ['認証', '工事案件', '見積書', '注文書', '請求書', 'ダッシュボード', '帳票PDF出力'],
    scenarios: [
      '新規工事案件登録〜見積〜注文〜日報〜請求のE2E (粗利率の即時把握)',
      '月次集計バッチ + 粗利率レポート + キャッシュフローダッシュボード',
      '勘定奉行への仕訳CSV連携 (インボイス番号付与)',
    ],
    implicit_keywords: ['ログイン', 'ダッシュボード', '監査', '帳票', '監視', 'バックアップ', 'セキュリティ'],
    non_functional: {
      performance_slo: '主要画面 95%ile レスポンス ≤ 3 秒、月次バッチ ≤ 30 分',
      availability_target: '99.9% (年間ダウンタイム ≤ 8.76 時間)',
      backup_rpo: '1 時間',
    },
    has_data_migration: true,
  },
});

console.log('===== テスト計画書 (抜粋) =====');
console.log(result.markdown.test_plan.slice(0, 2000));
console.log('\n... (全文 ', result.markdown.test_plan.length, ' 文字)');

console.log('\n===== テスト仕様書 メタ =====');
console.log(JSON.stringify(result.test_spec.meta, null, 2));

console.log('\n===== 不具合管理表 (抜粋) =====');
console.log(result.markdown.bug_tracker.slice(0, 1500));

console.log('\n===== 検収依頼書 (抜粋) =====');
console.log(result.markdown.acceptance_request.slice(0, 1500));

console.log('\n===== 検収完了書 =====');
console.log(`判定: ${result.judgment.verdict}`);
console.log(`理由: ${result.judgment.reason}`);
console.log(`瑕疵担保: ${result.acceptance_completion.warranty.start_date.slice(0, 10)} 〜 ${result.acceptance_completion.warranty.end_date.slice(0, 10)} (${result.acceptance_completion.warranty.months}ヶ月)`);
