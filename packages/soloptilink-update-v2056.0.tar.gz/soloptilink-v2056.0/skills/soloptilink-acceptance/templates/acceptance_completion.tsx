/**
 * 検収完了通知書 React テンプレ (委託者発行 / A4)
 *
 * - 検収判定 (合格 / 条件付合格 / 不合格) を強調表示
 * - 瑕疵担保期間 (民法 636/562/637 条 + 公共調達は会計法 29 条の 3) 明記
 * - 印影プレースホルダ (委託者)
 */
import React from 'react';

export interface AcceptanceCompletionReactProps {
  subject: string;
  projectName: string;
  acceptanceDate: string;
  client: { name: string; address?: string; representative?: string; representativeTitle?: string; sealUrl?: string };
  contractor: { name: string; address?: string; representative?: string; representativeTitle?: string };
  deliverables: { name: string; format: string; version?: string }[];
  verdict: '合格' | '条件付合格' | '不合格';
  verdictReason: string;
  remainingBugs?: { P1: number; P2: number; P3: number; P4: number };
  warrantyStartDate: string;
  warrantyEndDate: string;
  warrantyMonths: number;
  isPublicSector?: boolean;
  remarks?: string[];
  locale?: 'ja' | 'en';
}

const verdictColor: Record<'合格' | '条件付合格' | '不合格', string> = {
  合格: '#1f7a1f',
  条件付合格: '#a86200',
  不合格: '#a83232',
};

export function AcceptanceCompletion(props: AcceptanceCompletionReactProps) {
  const t = (ja: string, en: string) => (props.locale === 'ja' || !props.locale ? ja : en);
  const cell: React.CSSProperties = { padding: '4px 8px', border: '1px solid #ddd' };

  return (
    <div
      style={{
        width: '210mm',
        minHeight: '297mm',
        padding: '20mm',
        fontFamily: "'Noto Sans JP', 'Hiragino Sans', sans-serif",
        background: 'white',
        color: '#222',
        fontSize: '10pt',
      }}
    >
      <h1 style={{ textAlign: 'center', fontSize: '22pt', letterSpacing: props.locale === 'ja' ? '8pt' : '4pt', margin: '0 0 12mm 0' }}>
        {t('検 収 完 了 通 知 書', 'Acceptance Completion Notice')}
      </h1>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8mm' }}>
        <div>
          <div style={{ fontSize: '12pt', borderBottom: '1px solid #222', paddingBottom: '2px' }}>
            {props.contractor.name} {t('御中', '')}
          </div>
          {props.contractor.address && <div style={{ fontSize: '9pt', color: '#555', marginTop: '2px' }}>{props.contractor.address}</div>}
        </div>
        <div style={{ position: 'relative', textAlign: 'right' }}>
          <div style={{ fontWeight: 'bold' }}>{props.client.name}</div>
          {props.client.address && <div style={{ fontSize: '9pt' }}>{props.client.address}</div>}
          {props.client.representative && (
            <div style={{ fontSize: '9pt' }}>
              {props.client.representativeTitle ?? ''} {props.client.representative}
            </div>
          )}
          {props.client.sealUrl && (
            <img src={props.client.sealUrl} alt={t('印影', 'Seal')} style={{ position: 'absolute', top: '0', right: '-4mm', width: '18mm', height: '18mm', objectFit: 'contain' }} />
          )}
        </div>
      </div>

      <div style={{ marginBottom: '4mm', fontSize: '11pt' }}>
        <strong>{t('件名', 'Subject')}</strong>: {props.subject}
      </div>
      <div style={{ marginBottom: '4mm' }}>
        <strong>{t('検収日', 'Acceptance Date')}</strong>: {props.acceptanceDate.slice(0, 10)}
      </div>
      <div style={{ marginBottom: '8mm' }}>
        <strong>{t('案件名', 'Project')}</strong>: {props.projectName}
      </div>

      <div
        style={{
          padding: '8mm',
          border: `2px solid ${verdictColor[props.verdict]}`,
          background: '#fdfdfd',
          textAlign: 'center',
          marginBottom: '8mm',
        }}
      >
        <div style={{ fontSize: '11pt', color: '#555' }}>{t('検収判定', 'Verdict')}</div>
        <div style={{ fontSize: '24pt', fontWeight: 'bold', color: verdictColor[props.verdict], margin: '4mm 0' }}>
          {props.verdict}
        </div>
        <div style={{ fontSize: '10pt', color: '#333' }}>{props.verdictReason}</div>
      </div>

      <h2 style={{ fontSize: '14pt', borderBottom: '1px solid #999', paddingBottom: '2mm' }}>{t('納品物確認', 'Deliverables Confirmed')}</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '8mm' }}>
        <thead>
          <tr style={{ background: '#f5f5f5' }}>
            <th style={cell}>#</th>
            <th style={cell}>{t('納品物', 'Item')}</th>
            <th style={cell}>{t('形式', 'Format')}</th>
            <th style={cell}>{t('バージョン', 'Version')}</th>
            <th style={cell}>{t('受領', 'Received')}</th>
          </tr>
        </thead>
        <tbody>
          {props.deliverables.map((d, i) => (
            <tr key={i}>
              <td style={cell}>{i + 1}</td>
              <td style={cell}>{d.name}</td>
              <td style={cell}>{d.format}</td>
              <td style={cell}>{d.version ?? '-'}</td>
              <td style={{ ...cell, textAlign: 'center' }}>✓</td>
            </tr>
          ))}
        </tbody>
      </table>

      {props.remainingBugs && (
        <>
          <h2 style={{ fontSize: '14pt', borderBottom: '1px solid #999', paddingBottom: '2mm' }}>{t('残不具合', 'Remaining Bugs')}</h2>
          <table style={{ width: '60%', borderCollapse: 'collapse', marginBottom: '8mm' }}>
            <tbody>
              <tr><td style={cell}>P1</td><td style={cell}>{props.remainingBugs.P1}</td></tr>
              <tr><td style={cell}>P2</td><td style={cell}>{props.remainingBugs.P2}</td></tr>
              <tr><td style={cell}>P3</td><td style={cell}>{props.remainingBugs.P3}</td></tr>
              <tr><td style={cell}>P4</td><td style={cell}>{props.remainingBugs.P4}</td></tr>
            </tbody>
          </table>
        </>
      )}

      <h2 style={{ fontSize: '14pt', borderBottom: '1px solid #999', paddingBottom: '2mm' }}>{t('瑕疵担保期間 (契約不適合責任)', 'Warranty Period')}</h2>
      <p>
        <strong>{t('期間', 'Period')}</strong>: {props.warrantyStartDate.slice(0, 10)} 〜 {props.warrantyEndDate.slice(0, 10)} ({props.warrantyMonths}{t('ヶ月', ' months')})
      </p>
      <p style={{ fontSize: '9pt', color: '#555' }}>
        {t(
          '本期間は民法 562 条 / 563 条 / 564 条 / 636 条 / 637 条 (期間制限) に基づき設定。',
          'Based on Japanese Civil Code Art. 562/563/564/636/637 (warranty against defects).',
        )}
        {props.isPublicSector && ` ${t('会計法 29 条の 3 + 予算決算及び会計令 101 条 (検査調書整備) を併せて適用。', 'Additionally Public Accounting Act Art. 29-3 applies for public sector.')}`}
      </p>

      {props.remarks && props.remarks.length > 0 && (
        <>
          <h2 style={{ fontSize: '14pt', borderBottom: '1px solid #999', paddingBottom: '2mm' }}>{t('補足事項', 'Remarks')}</h2>
          <ul>
            {props.remarks.map((r, i) => (
              <li key={i}>{r}</li>
            ))}
          </ul>
        </>
      )}

      <div style={{ marginTop: '20mm', textAlign: 'right' }}>
        <div style={{ fontSize: '9pt', color: '#555' }}>{t('委託者署名 / 印影', 'Client Seal')}</div>
        <div style={{ width: '40mm', height: '20mm', border: '1px solid #999', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', marginTop: '2mm' }}>
          {props.client.sealUrl ? (
            <img src={props.client.sealUrl} alt={t('印影', 'Seal')} style={{ width: '18mm', height: '18mm', objectFit: 'contain' }} />
          ) : (
            <span style={{ color: '#bbb' }}>印</span>
          )}
        </div>
      </div>

      <style>{`@media print { @page { size: A4; margin: 0; } }`}</style>
    </div>
  );
}
