/**
 * バグ票 (個別) React テンプレ (印刷用 / A4)
 *
 * - 起票時 / 修正時 / 検証時 の3回印刷可
 * - 押印欄 (発見者 / 修正担当 / 検証担当)
 */
import React from 'react';

export interface BugReportReactProps {
  id: string;
  discoveredAt: string;
  reporter: string;
  phase: '結合テスト' | 'システムテスト' | 'UAT' | '本番リリース後';
  module: string;
  severity: 'S' | 'A' | 'B' | 'C';
  priority: 'P1' | 'P2' | 'P3' | 'P4';
  title: string;
  reproductionSteps: string[];
  expected: string;
  actual: string;
  environment: { os?: string; browser?: string; device?: string; backendUrl?: string; version?: string };
  screenshots: string[];
  status: string;
  assignee?: string;
  fixCommit?: string;
  verifier?: string;
  reporterSealUrl?: string;
  assigneeSealUrl?: string;
  verifierSealUrl?: string;
  locale?: 'ja' | 'en';
}

export function BugReportTemplate(props: BugReportReactProps) {
  const t = (ja: string, en: string) => (props.locale === 'ja' || !props.locale ? ja : en);
  const cell: React.CSSProperties = { padding: '4px 8px', borderBottom: '1px solid #ddd', verticalAlign: 'top' };
  return (
    <div
      style={{
        width: '210mm',
        minHeight: '297mm',
        padding: '20mm',
        fontFamily: "'Noto Sans JP', 'Hiragino Sans', sans-serif",
        background: 'white',
        color: '#222',
        fontSize: '10pt',
      }}
    >
      <h1 style={{ textAlign: 'center', fontSize: '20pt', margin: '0 0 8mm 0' }}>{t('バグ票', 'Bug Report')}</h1>
      <div style={{ marginBottom: '4mm', fontSize: '12pt' }}>
        <strong>ID</strong>: {props.id}　<strong>{t('タイトル', 'Title')}</strong>: {props.title}
      </div>

      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '6mm' }}>
        <tbody>
          <tr><td style={cell}>{t('発見日', 'Found At')}</td><td style={cell}>{props.discoveredAt.slice(0, 10)}</td><td style={cell}>{t('発見者', 'Reporter')}</td><td style={cell}>{props.reporter}</td></tr>
          <tr><td style={cell}>{t('フェーズ', 'Phase')}</td><td style={cell}>{props.phase}</td><td style={cell}>{t('モジュール', 'Module')}</td><td style={cell}>{props.module}</td></tr>
          <tr><td style={cell}>{t('重大度', 'Severity')}</td><td style={cell}>{props.severity}</td><td style={cell}>{t('優先度', 'Priority')}</td><td style={cell}>{props.priority}</td></tr>
          <tr><td style={cell}>{t('ステータス', 'Status')}</td><td style={cell}>{props.status}</td><td style={cell}>{t('担当', 'Assignee')}</td><td style={cell}>{props.assignee ?? '-'}</td></tr>
          <tr><td style={cell}>{t('修正コミット', 'Fix Commit')}</td><td style={cell}>{props.fixCommit ?? '-'}</td><td style={cell}>{t('検証担当', 'Verifier')}</td><td style={cell}>{props.verifier ?? '-'}</td></tr>
        </tbody>
      </table>

      <h3 style={{ fontSize: '12pt', marginBottom: '2mm' }}>{t('再現手順', 'Reproduction Steps')}</h3>
      <ol style={{ paddingLeft: '20px', marginTop: 0 }}>
        {props.reproductionSteps.map((s, i) => (
          <li key={i}>{s}</li>
        ))}
      </ol>

      <h3 style={{ fontSize: '12pt', marginBottom: '2mm' }}>{t('期待結果', 'Expected Result')}</h3>
      <p style={{ marginTop: 0 }}>{props.expected || '-'}</p>

      <h3 style={{ fontSize: '12pt', marginBottom: '2mm' }}>{t('実際結果', 'Actual Result')}</h3>
      <p style={{ marginTop: 0 }}>{props.actual || '-'}</p>

      <h3 style={{ fontSize: '12pt', marginBottom: '2mm' }}>{t('環境', 'Environment')}</h3>
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '6mm' }}>
        <tbody>
          <tr>
            <td style={cell}>OS</td><td style={cell}>{props.environment.os ?? '-'}</td>
            <td style={cell}>Browser</td><td style={cell}>{props.environment.browser ?? '-'}</td>
          </tr>
          <tr>
            <td style={cell}>{t('端末', 'Device')}</td><td style={cell}>{props.environment.device ?? '-'}</td>
            <td style={cell}>{t('接続先', 'Backend')}</td><td style={cell}>{props.environment.backendUrl ?? '-'}</td>
          </tr>
          <tr>
            <td style={cell}>{t('バージョン', 'Version')}</td><td style={cell} colSpan={3}>{props.environment.version ?? '-'}</td>
          </tr>
        </tbody>
      </table>

      <h3 style={{ fontSize: '12pt', marginBottom: '2mm' }}>{t('スクリーンショット', 'Screenshots')}</h3>
      {props.screenshots.length > 0 ? (
        <ul>
          {props.screenshots.map((s, i) => (
            <li key={i}>{s}</li>
          ))}
        </ul>
      ) : (
        <p>-</p>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-around', marginTop: '12mm', borderTop: '1px solid #999', paddingTop: '6mm' }}>
        <SealBox label={t('発見者印', 'Reporter Seal')} sealUrl={props.reporterSealUrl} />
        <SealBox label={t('修正担当印', 'Assignee Seal')} sealUrl={props.assigneeSealUrl} />
        <SealBox label={t('検証担当印', 'Verifier Seal')} sealUrl={props.verifierSealUrl} />
      </div>

      <style>{`@media print { @page { size: A4; margin: 0; } }`}</style>
    </div>
  );
}

function SealBox({ label, sealUrl }: { label: string; sealUrl?: string }) {
  return (
    <div style={{ textAlign: 'center' }}>
      <div style={{ fontSize: '9pt', marginBottom: '2mm' }}>{label}</div>
      <div style={{ width: '20mm', height: '20mm', border: '1px solid #999', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
        {sealUrl ? <img src={sealUrl} alt={label} style={{ width: '18mm', height: '18mm', objectFit: 'contain' }} /> : <span style={{ color: '#bbb' }}>印</span>}
      </div>
    </div>
  );
}
