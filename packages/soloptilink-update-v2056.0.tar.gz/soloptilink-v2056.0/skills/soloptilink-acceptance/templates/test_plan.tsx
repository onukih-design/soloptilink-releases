/**
 * 受入テスト計画書 React テンプレ (印刷用 / A4)
 *
 * - 和文ヘッダ + 印影プレースホルダ
 * - PDF 化を想定したインラインスタイル
 * - locale 対応 (ja / en)
 */
import React from 'react';

export interface TestPlanReactProps {
  projectName: string;
  industry?: string;
  clientType?: '民間' | '公共' | '自治体';
  generatedAt: string;
  /** 章タイトル + 章本文 (Markdownでない、プレーンテキスト) のリスト */
  chapters: { heading: string; body: string }[];
  /** 受託者印影 (画像URL or データURL) */
  contractorSealUrl?: string;
  /** 表紙の発行者 */
  issuer?: { companyName: string; address?: string; representative?: string };
  locale?: 'ja' | 'en';
}

export function TestPlan({
  projectName,
  industry,
  clientType,
  generatedAt,
  chapters,
  contractorSealUrl,
  issuer,
  locale = 'ja',
}: TestPlanReactProps) {
  const t = (ja: string, en: string) => (locale === 'ja' ? ja : en);
  return (
    <div
      className="test-plan-doc"
      style={{
        width: '210mm',
        minHeight: '297mm',
        padding: '20mm',
        fontFamily: "'Noto Sans JP', 'Hiragino Sans', sans-serif",
        background: 'white',
        color: '#222',
        fontSize: '10pt',
      }}
    >
      <div style={{ textAlign: 'center', marginBottom: '20mm' }}>
        <h1 style={{ fontSize: '24pt', letterSpacing: locale === 'ja' ? '8pt' : '2pt', margin: '0 0 8mm 0' }}>
          {t('受入テスト計画書', 'Acceptance Test Plan')}
        </h1>
        <div style={{ fontSize: '14pt', marginBottom: '4mm' }}>{projectName}</div>
        {industry && <div style={{ fontSize: '11pt', color: '#555' }}>{t('業種', 'Industry')}: {industry}</div>}
        {clientType && <div style={{ fontSize: '11pt', color: '#555' }}>{t('クライアント種別', 'Client Type')}: {clientType}</div>}
        <div style={{ fontSize: '11pt', color: '#555', marginTop: '4mm' }}>
          {t('作成日', 'Issued')}: {generatedAt.slice(0, 10)}
        </div>
      </div>

      {issuer && (
        <div style={{ position: 'relative', textAlign: 'right', marginBottom: '12mm' }}>
          <div style={{ fontWeight: 'bold' }}>{issuer.companyName}</div>
          {issuer.address && <div style={{ fontSize: '9pt' }}>{issuer.address}</div>}
          {issuer.representative && <div style={{ fontSize: '9pt' }}>{issuer.representative}</div>}
          {contractorSealUrl && (
            <img
              src={contractorSealUrl}
              alt={t('受託者印影', 'Contractor Seal')}
              style={{ position: 'absolute', top: '0', right: '0', width: '20mm', height: '20mm', objectFit: 'contain' }}
            />
          )}
        </div>
      )}

      {chapters.map((c, i) => (
        <section key={i} style={{ marginBottom: '8mm', pageBreakInside: 'avoid' }}>
          <h2 style={{ fontSize: '14pt', borderBottom: '1px solid #999', paddingBottom: '2mm', marginBottom: '4mm' }}>
            {c.heading}
          </h2>
          <pre
            style={{
              whiteSpace: 'pre-wrap',
              wordBreak: 'break-word',
              fontFamily: 'inherit',
              fontSize: '10pt',
              lineHeight: 1.6,
              margin: 0,
            }}
          >
            {c.body}
          </pre>
        </section>
      ))}

      <style>{`@media print { @page { size: A4; margin: 0; } .test-plan-doc { box-shadow: none !important; } }`}</style>
    </div>
  );
}
