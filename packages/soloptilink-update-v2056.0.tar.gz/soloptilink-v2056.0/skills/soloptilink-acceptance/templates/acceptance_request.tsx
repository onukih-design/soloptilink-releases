/**
 * 検収依頼書 React テンプレ (受託者→委託者 / A4)
 *
 * - 和文ヘッダ「検収依頼書」 / 印影プレースホルダ
 * - 納品物テーブル + 検収期間 + 受託者署名欄
 */
import React from 'react';

export interface AcceptanceRequestReactProps {
  subject: string;
  projectName: string;
  submissionDate: string;
  client: { name: string; address?: string; representative?: string; representativeTitle?: string };
  contractor: { name: string; address?: string; representative?: string; representativeTitle?: string; sealUrl?: string };
  deliverables: { name: string; format: string; version?: string; copies?: number; deliveryDate?: string }[];
  acceptanceWindowStart: string;
  acceptanceWindowEnd: string;
  remarks?: string[];
  locale?: 'ja' | 'en';
}

export function AcceptanceRequest(props: AcceptanceRequestReactProps) {
  const t = (ja: string, en: string) => (props.locale === 'ja' || !props.locale ? ja : en);
  const cell: React.CSSProperties = { padding: '4px 8px', border: '1px solid #ddd' };

  return (
    <div
      style={{
        width: '210mm',
        minHeight: '297mm',
        padding: '20mm',
        fontFamily: "'Noto Sans JP', 'Hiragino Sans', sans-serif",
        background: 'white',
        color: '#222',
        fontSize: '10pt',
      }}
    >
      <h1 style={{ textAlign: 'center', fontSize: '24pt', letterSpacing: props.locale === 'ja' ? '12pt' : '4pt', margin: '0 0 12mm 0' }}>
        {t('検 収 依 頼 書', 'Acceptance Request')}
      </h1>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8mm' }}>
        <div>
          <div style={{ fontSize: '12pt', borderBottom: '1px solid #222', paddingBottom: '2px' }}>
            {props.client.name} {t('御中', '')}
          </div>
          {props.client.address && <div style={{ fontSize: '9pt', color: '#555', marginTop: '2px' }}>{props.client.address}</div>}
        </div>
        <div style={{ position: 'relative', textAlign: 'right' }}>
          <div style={{ fontWeight: 'bold' }}>{props.contractor.name}</div>
          {props.contractor.address && <div style={{ fontSize: '9pt' }}>{props.contractor.address}</div>}
          {props.contractor.representative && (
            <div style={{ fontSize: '9pt' }}>
              {props.contractor.representativeTitle ?? ''} {props.contractor.representative}
            </div>
          )}
          {props.contractor.sealUrl && (
            <img src={props.contractor.sealUrl} alt={t('印影', 'Seal')} style={{ position: 'absolute', top: '0', right: '-4mm', width: '18mm', height: '18mm', objectFit: 'contain' }} />
          )}
        </div>
      </div>

      <div style={{ marginBottom: '6mm', fontSize: '11pt' }}>
        <strong>{t('件名', 'Subject')}</strong>: {props.subject}
      </div>
      <div style={{ marginBottom: '4mm' }}>
        <strong>{t('提出日', 'Submitted')}</strong>: {props.submissionDate.slice(0, 10)}
      </div>
      <div style={{ marginBottom: '8mm' }}>
        <strong>{t('案件名', 'Project')}</strong>: {props.projectName}
      </div>

      <p style={{ marginBottom: '6mm' }}>
        {t(
          '拝啓 平素より格別のご高配を賜り、厚く御礼申し上げます。下記案件について成果物の納品が完了しましたので、検収をお願い申し上げます。',
          'We respectfully submit the deliverables for the project below, and kindly request your acceptance review.',
        )}
      </p>

      <h2 style={{ fontSize: '14pt', borderBottom: '1px solid #999', paddingBottom: '2mm' }}>{t('納品物一覧', 'Deliverables')}</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '8mm' }}>
        <thead>
          <tr style={{ background: '#f5f5f5' }}>
            <th style={cell}>#</th>
            <th style={cell}>{t('納品物', 'Item')}</th>
            <th style={cell}>{t('形式', 'Format')}</th>
            <th style={cell}>{t('バージョン', 'Version')}</th>
            <th style={cell}>{t('数量', 'Copies')}</th>
            <th style={cell}>{t('引渡日', 'Delivered')}</th>
          </tr>
        </thead>
        <tbody>
          {props.deliverables.map((d, i) => (
            <tr key={i}>
              <td style={cell}>{i + 1}</td>
              <td style={cell}>{d.name}</td>
              <td style={cell}>{d.format}</td>
              <td style={cell}>{d.version ?? '-'}</td>
              <td style={cell}>{d.copies ?? 1}</td>
              <td style={cell}>{d.deliveryDate?.slice(0, 10) ?? props.submissionDate.slice(0, 10)}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2 style={{ fontSize: '14pt', borderBottom: '1px solid #999', paddingBottom: '2mm' }}>{t('検収期間', 'Acceptance Window')}</h2>
      <p>
        {props.acceptanceWindowStart.slice(0, 10)} 〜 {props.acceptanceWindowEnd.slice(0, 10)}
      </p>
      <p style={{ fontSize: '9pt', color: '#555' }}>
        {t(
          '※ 民法 562 条に定める通常合理的な検査期間として上記を提示いたします。',
          '* The above period is provided as a reasonable inspection period per Civil Code Art. 562.',
        )}
      </p>

      {props.remarks && props.remarks.length > 0 && (
        <>
          <h2 style={{ fontSize: '14pt', borderBottom: '1px solid #999', paddingBottom: '2mm' }}>{t('補足事項', 'Remarks')}</h2>
          <ul>
            {props.remarks.map((r, i) => (
              <li key={i}>{r}</li>
            ))}
          </ul>
        </>
      )}

      <div style={{ marginTop: '20mm', textAlign: 'right' }}>
        <div style={{ fontSize: '9pt', color: '#555' }}>{t('受託者署名 / 印影', 'Contractor Seal')}</div>
        <div style={{ width: '40mm', height: '20mm', border: '1px solid #999', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', marginTop: '2mm' }}>
          {props.contractor.sealUrl ? (
            <img src={props.contractor.sealUrl} alt={t('印影', 'Seal')} style={{ width: '18mm', height: '18mm', objectFit: 'contain' }} />
          ) : (
            <span style={{ color: '#bbb' }}>印</span>
          )}
        </div>
      </div>

      <style>{`@media print { @page { size: A4; margin: 0; } }`}</style>
    </div>
  );
}
