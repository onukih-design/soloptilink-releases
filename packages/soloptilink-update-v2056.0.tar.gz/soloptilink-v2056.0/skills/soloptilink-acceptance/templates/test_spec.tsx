/**
 * テスト仕様書 React テンプレ (テストケース集 / A4)
 *
 * - テスト ID / カテゴリ / 前提 / 操作手順 / 期待結果 / 結果記入欄 を表形式で印刷
 * - locale 対応 (ja / en)
 */
import React from 'react';

export interface TestSpecCase {
  id: string;
  category: string;
  module: string;
  scenarioName: string;
  preconditions: string[];
  steps: string[];
  expectedResult: string;
}

export interface TestSpecReactProps {
  projectName: string;
  generatedAt: string;
  totalCases: number;
  cases: TestSpecCase[];
  locale?: 'ja' | 'en';
}

export function TestSpec({ projectName, generatedAt, totalCases, cases, locale = 'ja' }: TestSpecReactProps) {
  const t = (ja: string, en: string) => (locale === 'ja' ? ja : en);
  return (
    <div
      className="test-spec-doc"
      style={{
        width: '210mm',
        minHeight: '297mm',
        padding: '15mm',
        fontFamily: "'Noto Sans JP', 'Hiragino Sans', sans-serif",
        background: 'white',
        color: '#222',
        fontSize: '9pt',
      }}
    >
      <h1 style={{ textAlign: 'center', fontSize: '20pt', margin: '0 0 8mm 0' }}>
        {t('テスト仕様書', 'Test Specification')}
      </h1>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8mm' }}>
        <div>{t('案件名', 'Project')}: {projectName}</div>
        <div>{t('作成日', 'Issued')}: {generatedAt.slice(0, 10)}</div>
        <div>{t('総ケース数', 'Total')}: {totalCases}</div>
      </div>

      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '8.5pt' }}>
        <thead>
          <tr style={{ background: '#333', color: 'white' }}>
            <th style={{ padding: '4px', textAlign: 'left', width: '22mm' }}>ID</th>
            <th style={{ padding: '4px', textAlign: 'left', width: '20mm' }}>{t('カテゴリ', 'Category')}</th>
            <th style={{ padding: '4px', textAlign: 'left' }}>{t('シナリオ', 'Scenario')}</th>
            <th style={{ padding: '4px', textAlign: 'left' }}>{t('期待結果', 'Expected')}</th>
            <th style={{ padding: '4px', textAlign: 'center', width: '12mm' }}>{t('結果', 'Result')}</th>
            <th style={{ padding: '4px', textAlign: 'left', width: '20mm' }}>{t('実施日', 'Date')}</th>
            <th style={{ padding: '4px', textAlign: 'left', width: '20mm' }}>{t('テスター', 'Tester')}</th>
          </tr>
        </thead>
        <tbody>
          {cases.map((c, idx) => (
            <tr key={c.id} style={{ borderBottom: '1px solid #ddd', pageBreakInside: 'avoid' }}>
              <td style={{ padding: '4px', verticalAlign: 'top' }}>{c.id}</td>
              <td style={{ padding: '4px', verticalAlign: 'top' }}>{c.category}</td>
              <td style={{ padding: '4px', verticalAlign: 'top' }}>
                <div style={{ fontWeight: 'bold' }}>{c.scenarioName}</div>
                <div style={{ fontSize: '8pt', color: '#555', marginTop: '2px' }}>
                  {t('前提', 'Pre')}: {c.preconditions.join(' / ') || t('なし', 'None')}
                </div>
                <ol style={{ paddingLeft: '14px', margin: '2px 0 0 0', fontSize: '8pt' }}>
                  {c.steps.map((s, i) => (
                    <li key={i}>{s}</li>
                  ))}
                </ol>
              </td>
              <td style={{ padding: '4px', verticalAlign: 'top' }}>{c.expectedResult}</td>
              <td style={{ padding: '4px', textAlign: 'center', verticalAlign: 'top' }}>
                <div style={{ border: '1px solid #999', height: '5mm', minWidth: '8mm' }} />
              </td>
              <td style={{ padding: '4px', verticalAlign: 'top' }}>
                <div style={{ borderBottom: '1px solid #999', height: '5mm' }} />
              </td>
              <td style={{ padding: '4px', verticalAlign: 'top' }}>
                <div style={{ borderBottom: '1px solid #999', height: '5mm' }} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      <style>{`@media print { @page { size: A4 landscape; margin: 0; } .test-spec-doc { box-shadow: none !important; } }`}</style>
    </div>
  );
}
