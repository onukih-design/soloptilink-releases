/**
 * Test Plan Generator - 受入テスト計画書を生成
 *
 * 責務:
 *   - 日本SI標準 9章構成の受入テスト計画書を Markdown / 構造化データで生成
 *   - V字モデル準拠 (要件定義 → UAT)
 *   - 不具合管理プロセス + 検収判定基準を文書化
 *
 * 入力: TestPlanInput (案件情報 + スケジュール + 体制 + 合格基準モード)
 * 出力: TestPlanDocument (9章の構造化データ + Markdown)
 */

import {
  CRITERIA_THRESHOLDS,
  CRITERIA_DESCRIPTIONS,
  type CriteriaMode,
  type CriteriaThresholds,
} from './criteria_engine';

export type TestApproach = 'scenario_based' | 'exploratory' | 'regression' | 'performance' | 'security' | 'data_migration';

export interface TestPlanParty {
  name: string;
  role: string;
  responsibilities: string[];
}

export interface TestSchedule {
  /** UAT 開始日 (ISO 形式) */
  uat_start: string;
  /** UAT 終了日 */
  uat_end: string;
  /** 不具合修正期間 開始 */
  fix_start: string;
  /** 不具合修正期間 終了 */
  fix_end: string;
  /** 再テスト期間 開始 */
  retest_start: string;
  /** 再テスト期間 終了 */
  retest_end: string;
  /** 検収判定会議 */
  judgment_meeting: string;
  /** 検収完了予定 */
  acceptance_deadline: string;
}

export interface TestEnvironment {
  name: 'production-equivalent' | 'staging' | 'dedicated-uat';
  description: string;
  data_source: 'masked-production' | 'synthetic' | 'snapshot';
  external_systems: string[];
  access_control: string;
}

export interface TestPlanInput {
  project_name: string;
  industry?: string;
  client_type?: '民間' | '公共' | '自治体';
  /** 顧客側の責任者 / テスター */
  client_team: TestPlanParty[];
  /** 受託者側の PM / Lead / テスター */
  contractor_team: TestPlanParty[];
  schedule: TestSchedule;
  environment: TestEnvironment;
  /** 採用するテスト方式の組み合わせ */
  approaches: TestApproach[];
  /** 合格基準モード */
  criteria_mode: CriteriaMode;
  /** 対象モジュール / シナリオ群 */
  scope: {
    modules: string[];
    scenarios: string[];
    out_of_scope?: string[];
  };
  /** リスク・課題 */
  risks?: { description: string; mitigation: string }[];
}

export interface TestPlanChapter {
  heading: string;
  body: string;
}

export interface TestPlanDocument {
  meta: {
    project_name: string;
    industry?: string;
    client_type?: '民間' | '公共' | '自治体';
    generated_at: string;
    criteria_mode: CriteriaMode;
    applied_thresholds: CriteriaThresholds;
  };
  chapters: TestPlanChapter[];
  markdown: string;
}

const APPROACH_LABEL: Record<TestApproach, string> = {
  scenario_based: '業務シナリオベーステスト',
  exploratory: '探索的テスト',
  regression: 'リグレッションテスト',
  performance: '性能テスト',
  security: 'セキュリティテスト',
  data_migration: 'データ移行検証テスト',
};

/** Chapter 1: テスト目的・範囲 */
function buildChapterPurpose(input: TestPlanInput): TestPlanChapter {
  const body = [
    `## 1.1 テスト目的`,
    ``,
    `本計画書は、案件「${input.project_name}」の受入テスト (UAT) を計画的に実施し、契約上の要件を満たすことを確認するための文書である。`,
    ``,
    `## 1.2 テスト範囲 (対象モジュール)`,
    ``,
    ...input.scope.modules.map((m) => `- ${m}`),
    ``,
    `## 1.3 業務シナリオ`,
    ``,
    ...input.scope.scenarios.map((s) => `- ${s}`),
    ``,
    input.scope.out_of_scope && input.scope.out_of_scope.length > 0
      ? [`## 1.4 対象外`, ``, ...input.scope.out_of_scope.map((s) => `- ${s}`), ``].join('\n')
      : '',
  ]
    .filter(Boolean)
    .join('\n');
  return { heading: '1. テスト目的・範囲', body };
}

/** Chapter 2: テスト体制 */
function buildChapterTeam(input: TestPlanInput): TestPlanChapter {
  const formatTeam = (label: string, members: TestPlanParty[]) =>
    [
      `### ${label}`,
      ``,
      `| 担当者 | 役割 | 責務 |`,
      `|--------|------|------|`,
      ...members.map((m) => `| ${m.name} | ${m.role} | ${m.responsibilities.join(' / ')} |`),
      ``,
    ].join('\n');

  const body = [
    `テスト実施に関わる体制は以下のとおり。`,
    ``,
    formatTeam('2.1 顧客側 (委託者)', input.client_team),
    formatTeam('2.2 受託者側', input.contractor_team),
  ].join('\n');

  return { heading: '2. テスト体制', body };
}

/** Chapter 3: テスト環境 */
function buildChapterEnvironment(input: TestPlanInput): TestPlanChapter {
  const env = input.environment;
  const dataSourceJa: Record<TestEnvironment['data_source'], string> = {
    'masked-production': 'マスキング済本番データ',
    synthetic: '合成データ',
    snapshot: '本番スナップショット',
  };
  const envNameJa: Record<TestEnvironment['name'], string> = {
    'production-equivalent': '本番相当環境',
    staging: 'Stage 環境',
    'dedicated-uat': 'UAT 専用環境',
  };
  const body = [
    `| 項目 | 内容 |`,
    `|------|------|`,
    `| 環境種別 | ${envNameJa[env.name]} |`,
    `| 環境説明 | ${env.description} |`,
    `| データ | ${dataSourceJa[env.data_source]} |`,
    `| 連携外部システム | ${env.external_systems.length > 0 ? env.external_systems.join(' / ') : '無し'} |`,
    `| アクセス制御 | ${env.access_control} |`,
    ``,
    `> 個人情報を含むデータを利用する場合、個人情報保護法 23 条 (第三者提供制限) に準拠し、マスキング処理またはモックデータへの置換を行うこと。`,
  ].join('\n');

  return { heading: '3. テスト環境', body };
}

/** Chapter 4: テスト工程・スケジュール */
function buildChapterSchedule(input: TestPlanInput): TestPlanChapter {
  const s = input.schedule;
  const body = [
    `| 工程 | 開始 | 終了 | 担当 |`,
    `|------|------|------|------|`,
    `| UAT 実施期間 | ${s.uat_start} | ${s.uat_end} | 顧客テスター + 受託者立会 |`,
    `| 不具合修正期間 | ${s.fix_start} | ${s.fix_end} | 受託者開発チーム |`,
    `| 再テスト期間 | ${s.retest_start} | ${s.retest_end} | 顧客テスター |`,
    `| 検収判定会議 | ${s.judgment_meeting} | - | PM + 顧客責任者 |`,
    `| 検収完了予定 | ${s.acceptance_deadline} | - | 顧客責任者 |`,
    ``,
    `> 下請法 4 条 2 項 4 号により、検収後 60 日以内に支払を行うこと。`,
  ].join('\n');

  return { heading: '4. テスト工程・スケジュール', body };
}

/** Chapter 5: テスト実施方法 */
function buildChapterApproach(input: TestPlanInput): TestPlanChapter {
  const body = [
    `本案件で採用するテスト方式:`,
    ``,
    ...input.approaches.map((a) => `- **${APPROACH_LABEL[a]}**: ${describeApproach(a)}`),
  ].join('\n');

  return { heading: '5. テスト実施方法', body };
}

function describeApproach(approach: TestApproach): string {
  switch (approach) {
    case 'scenario_based':
      return '業務シナリオごとに End-to-End フローを実行し、業務目的の達成を確認する。';
    case 'exploratory':
      return 'テスト仕様書に記載されていない不具合を経験豊富なテスターが自由に探索する。';
    case 'regression':
      return '修正による既存機能への影響を回帰確認する。CI 自動テストと併用。';
    case 'performance':
      return 'TPS / レスポンスタイム / 同時接続数を計測し、SLO を達成しているか確認する。';
    case 'security':
      return 'OWASP Top 10 に基づき、SQLi / XSS / CSRF / IDOR 等の脆弱性を確認する。';
    case 'data_migration':
      return '既存システムからのデータ移行精度 (件数 / 整合性 / マスタ突合) を検証する。';
  }
}

/** Chapter 6: 合格基準 */
function buildChapterCriteria(input: TestPlanInput): TestPlanChapter {
  const t = CRITERIA_THRESHOLDS[input.criteria_mode];
  const limit = (n: number) => (n < 0 ? '無制限' : `${n} 件以下`);
  const body = [
    `本案件は「${CRITERIA_DESCRIPTIONS[input.criteria_mode]}」を採用する。`,
    ``,
    `| 重大度 | 説明 | 許容件数 |`,
    `|--------|------|----------|`,
    `| P1 | 致命的 (システム停止 / データ破壊) | ${limit(t.P1)} |`,
    `| P2 | 重大 (主要機能の不具合 / 業務継続困難) | ${limit(t.P2)} |`,
    `| P3 | 中程度 (回避策あり / 業務継続可能) | ${limit(t.P3)} |`,
    `| P4 | 軽微 (UI崩れ / 表記揺れ) | ${limit(t.P4)} |`,
    ``,
    `加えて、以下を満たすこと:`,
    ``,
    `- テストケース消化率: 100% (未実施は事前合意の上、対象外扱い)`,
    `- 業務シナリオ網羅率: 100%`,
    `- 性能 SLO: 主要画面のレスポンスタイム 95 パーセンタイル ≤ 3 秒`,
  ].join('\n');

  return { heading: '6. 合格基準', body };
}

/** Chapter 7: 不具合管理プロセス */
function buildChapterBugProcess(): TestPlanChapter {
  const body = [
    `不具合の発見からクローズまでのプロセスは以下のとおり:`,
    ``,
    `1. **発見**: 顧客テスターが不具合を発見`,
    `2. **起票**: 不具合管理ツール (例: Jira / Redmine) にバグ票を起票 (重大度・優先度・再現手順を記載)`,
    `3. **修正依頼**: 受託者 PM が担当者をアサイン`,
    `4. **修正**: 開発者が修正コミットを行い、修正完了ステータスに変更`,
    `5. **再テスト**: 顧客テスターが再現確認・検証`,
    `6. **クローズ**: 再現しない場合クローズ。再現する場合は差戻し`,
    ``,
    `### バグ票必須項目`,
    ``,
    `- ID / 発見日 / 発見者 / モジュール`,
    `- 重大度 (S/A/B/C) / 優先度 (P1〜P4)`,
    `- 再現手順 / 期待結果 / 実際結果`,
    `- 環境 (OS / ブラウザ / バージョン) / スクリーンショット`,
    `- 担当者 / ステータス / 修正コミット ID / 検証担当`,
    ``,
    `### ステートマシン`,
    ``,
    `\`\`\``,
    `新規 → 調査中 → 修正中 → 修正完了 → 再テスト中 → クローズ`,
    `                                       ↓`,
    `                                     差戻し → 修正中 (ループ)`,
    `クローズ → (再オープン許可) → 新規`,
    `\`\`\``,
  ].join('\n');

  return { heading: '7. 不具合管理プロセス', body };
}

/** Chapter 8: 検収判定基準 */
function buildChapterAcceptance(input: TestPlanInput): TestPlanChapter {
  const body = [
    `判定会議 (${input.schedule.judgment_meeting}) において、以下のいずれかの判定を下す:`,
    ``,
    `| 判定 | 条件 | 次工程 |`,
    `|------|------|--------|`,
    `| 合格 | 全許容閾値内 + 業務シナリオ全PASS | 検収完了書発行・支払 |`,
    `| 条件付合格 | P3/P4 のみ閾値超過。期限内修正で本合格 | 期限内に修正・再テスト |`,
    `| 不合格 | P1/P2 が閾値超過、または重大な業務シナリオ失敗 | 修正後、再UAT |`,
    ``,
    `判定の根拠は議事録に記載し、検収依頼書 / 完了書に添付する。`,
    ``,
    `> 本案件の契約不適合責任 (旧瑕疵担保責任) は民法 636 条・562 条に基づく。検収完了書記載の瑕疵担保期間内に発見された不適合については、追完請求 (民 562 条) または報酬減額 (民 563 条) の対象となる。`,
  ].join('\n');

  return { heading: '8. 検収判定基準', body };
}

/** Chapter 9: リスク・課題 */
function buildChapterRisks(input: TestPlanInput): TestPlanChapter {
  const defaultRisks = [
    {
      description: '顧客側テスターのリソース不足によるテスト遅延',
      mitigation: '事前にテスト工数を提示し、専任化を依頼。受託者側立会で支援。',
    },
    {
      description: 'UAT 環境と本番環境の差異による再現困難',
      mitigation: '本番相当データを利用。差異がある項目はテスト計画書に明記。',
    },
    {
      description: '不具合修正の長期化によるスケジュール遅延',
      mitigation: '修正期間を明確に区切り、超過時は条件付合格 + 期限内本合格で対応。',
    },
  ];
  const risks = input.risks && input.risks.length > 0 ? input.risks : defaultRisks;
  const body = [
    `| リスク | 影響 | 対策 |`,
    `|--------|------|------|`,
    ...risks.map((r) => `| ${r.description} | スケジュール / 品質 | ${r.mitigation} |`),
  ].join('\n');

  return { heading: '9. リスク・課題', body };
}

/**
 * 受入テスト計画書を生成する (公開API)
 */
export function generateTestPlan(input: TestPlanInput): TestPlanDocument {
  const chapters: TestPlanChapter[] = [
    buildChapterPurpose(input),
    buildChapterTeam(input),
    buildChapterEnvironment(input),
    buildChapterSchedule(input),
    buildChapterApproach(input),
    buildChapterCriteria(input),
    buildChapterBugProcess(),
    buildChapterAcceptance(input),
    buildChapterRisks(input),
  ];

  const markdown = formatTestPlanAsMarkdown({
    meta: {
      project_name: input.project_name,
      industry: input.industry,
      client_type: input.client_type,
      generated_at: new Date().toISOString(),
      criteria_mode: input.criteria_mode,
      applied_thresholds: CRITERIA_THRESHOLDS[input.criteria_mode],
    },
    chapters,
    markdown: '',
  });

  return {
    meta: {
      project_name: input.project_name,
      industry: input.industry,
      client_type: input.client_type,
      generated_at: new Date().toISOString(),
      criteria_mode: input.criteria_mode,
      applied_thresholds: CRITERIA_THRESHOLDS[input.criteria_mode],
    },
    chapters,
    markdown,
  };
}

/** Markdown 整形 */
export function formatTestPlanAsMarkdown(doc: Omit<TestPlanDocument, 'markdown'> & { markdown: string }): string {
  const header = [
    `# 受入テスト計画書`,
    ``,
    `**案件名**: ${doc.meta.project_name}`,
    doc.meta.industry ? `**業種**: ${doc.meta.industry}` : '',
    doc.meta.client_type ? `**クライアント種別**: ${doc.meta.client_type}` : '',
    `**作成日**: ${doc.meta.generated_at.slice(0, 10)}`,
    `**合格基準モード**: ${doc.meta.criteria_mode}`,
    ``,
    `---`,
    ``,
  ]
    .filter(Boolean)
    .join('\n');

  const body = doc.chapters
    .map((c) => `# ${c.heading}\n\n${c.body}\n`)
    .join('\n---\n\n');

  return header + body;
}
