/**
 * soloptilink-acceptance public API
 *
 * 全モジュールを集約エクスポートし、`generateAcceptancePackage` で
 * テスト計画書 + テスト仕様書 + 不具合管理表 + 検収依頼書 + 検収完了書 を一括生成する。
 *
 * 入力: AcceptancePackageInput (案件情報 + スケジュール + 体制 + 合格基準)
 * 出力: AcceptancePackageOutput (各ドキュメントの構造化データ + Markdown)
 */

export * from './criteria_engine';
export * from './test_plan_generator';
export * from './test_spec_generator';
export * from './bug_tracker';
export * from './acceptance_doc_generator';

import {
  evaluateCriteria,
  type BugCounts,
  type CriteriaJudgment,
  type CriteriaMode,
} from './criteria_engine';
import {
  generateTestPlan,
  type TestPlanDocument,
  type TestPlanInput,
} from './test_plan_generator';
import {
  generateTestSpec,
  type TestSpecDocument,
  type TestSpecInput,
} from './test_spec_generator';
import {
  generateBugTracker,
  type BugReport,
  type BugTrackerDocument,
} from './bug_tracker';
import {
  generateAcceptanceRequest,
  generateAcceptanceCompletion,
  type AcceptanceRequestDocument,
  type AcceptanceCompletionDocument,
  type AcceptanceParty,
  type DeliverableItem,
} from './acceptance_doc_generator';

export interface AcceptancePackageInput {
  /** 案件名 */
  project_name: string;
  /** 業種 (任意 / soloptilink-japan 連携時に使用) */
  industry?: string;
  /** クライアント種別 */
  client_type?: '民間' | '公共' | '自治体';
  /** 合格基準モード (デフォルト 'standard') */
  criteria_mode?: CriteriaMode;
  /** 瑕疵担保期間 (月)。デフォルト 6 ヶ月。public-sector 推奨は 24 ヶ月 */
  warranty_months?: number;
  /** 検収完了書発行時の言語 */
  locale?: 'ja' | 'en';
  /** 委託者 */
  client: AcceptanceParty;
  /** 受託者 */
  contractor: AcceptanceParty;
  /** 納品物リスト */
  deliverables: DeliverableItem[];
  /** 検収日 (検収完了書用) ISO */
  acceptance_date: string;
  /** 検収依頼書の提出日 ISO */
  request_submission_date: string;
  /** 検収期間 開始 / 終了 */
  acceptance_window_start: string;
  acceptance_window_end: string;
  /** 既に集計済の不具合件数 (検収完了書の判定用) */
  remaining_bugs?: BugCounts;
  /** バグ票一覧 (オプション、不具合管理表生成に利用) */
  bug_reports?: BugReport[];
  /** テスト計画書入力 */
  test_plan_input: TestPlanInput;
  /** テスト仕様書入力 */
  test_spec_input: TestSpecInput;
}

export interface AcceptancePackageOutput {
  test_plan: TestPlanDocument;
  test_spec: TestSpecDocument;
  bug_tracker: BugTrackerDocument;
  acceptance_request: AcceptanceRequestDocument;
  acceptance_completion: AcceptanceCompletionDocument;
  judgment: CriteriaJudgment;
  markdown: {
    test_plan: string;
    test_spec: string;
    bug_tracker: string;
    acceptance_request: string;
    acceptance_completion: string;
  };
}

/**
 * 検収フェーズのドキュメント一式を一括生成 (`--mode all` 相当)
 */
export function generateAcceptancePackage(input: AcceptancePackageInput): AcceptancePackageOutput {
  const criteriaMode: CriteriaMode = input.criteria_mode ?? 'standard';

  // 1. テスト計画書
  const testPlan = generateTestPlan({
    ...input.test_plan_input,
    criteria_mode: criteriaMode,
  });

  // 2. テスト仕様書
  const testSpec = generateTestSpec(input.test_spec_input);

  // 3. 不具合管理表
  const bugTracker = generateBugTracker({
    project_name: input.project_name,
    reports: input.bug_reports ?? [],
  });

  // 4. 検収判定
  const remainingBugs: BugCounts = input.remaining_bugs ?? { P1: 0, P2: 0, P3: 0, P4: 0 };
  const judgment = evaluateCriteria(remainingBugs, criteriaMode);

  // 5. 検収依頼書
  const acceptanceRequest = generateAcceptanceRequest({
    project_name: input.project_name,
    submission_date: input.request_submission_date,
    client: input.client,
    contractor: input.contractor,
    deliverables: input.deliverables,
    acceptance_window_start: input.acceptance_window_start,
    acceptance_window_end: input.acceptance_window_end,
    locale: input.locale,
  });

  // 6. 検収完了書
  const acceptanceCompletion = generateAcceptanceCompletion({
    project_name: input.project_name,
    acceptance_date: input.acceptance_date,
    client: input.client,
    contractor: input.contractor,
    deliverables: input.deliverables,
    verdict: judgment.verdict,
    verdict_reason: judgment.reason,
    remaining_bugs: remainingBugs,
    judgment,
    warranty_months: input.warranty_months,
    is_public_sector: input.client_type === '公共' || input.client_type === '自治体',
    locale: input.locale,
  });

  return {
    test_plan: testPlan,
    test_spec: testSpec,
    bug_tracker: bugTracker,
    acceptance_request: acceptanceRequest,
    acceptance_completion: acceptanceCompletion,
    judgment,
    markdown: {
      test_plan: testPlan.markdown,
      test_spec: testSpec.markdown,
      bug_tracker: bugTracker.markdown,
      acceptance_request: acceptanceRequest.markdown,
      acceptance_completion: acceptanceCompletion.markdown,
    },
  };
}
