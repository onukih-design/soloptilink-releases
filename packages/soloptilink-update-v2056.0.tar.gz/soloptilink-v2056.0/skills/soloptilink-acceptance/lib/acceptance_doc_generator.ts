/**
 * Acceptance Doc Generator - 検収依頼書 / 検収完了書を生成
 *
 * 責務:
 *   - 検収依頼書 (受託者→委託者) と検収完了書 (委託者発行) の両端を生成
 *   - 民法 562条 / 636条 / 637条 (契約不適合責任 + 期間制限) を文書化
 *   - 瑕疵担保期間を --warranty-months で柔軟設定 (デフォルト 6ヶ月)
 *   - 公共調達は会計法 29条の3 + 検査調書整備に対応
 *
 * 入力: AcceptanceRequestInput / AcceptanceCompletionInput
 * 出力: AcceptanceRequestDocument / AcceptanceCompletionDocument (構造化 + Markdown)
 */

import type { AcceptanceVerdict, BugCounts, CriteriaJudgment } from './criteria_engine';

export interface AcceptanceParty {
  /** 名称 (会社名 / 部署名) */
  name: string;
  /** 住所 */
  address?: string;
  /** 代表者名 + 役職 */
  representative?: string;
  representative_title?: string;
  /** 担当者名 */
  contact_person?: string;
  /** 印影プレースホルダ (ファイルパス or データURL) */
  seal?: string;
}

export interface DeliverableItem {
  /** 名称 (例: 要件定義書 / ソースコード一式) */
  name: string;
  /** 形式 (例: .docx / .pdf / git tag / DVD) */
  format: string;
  /** バージョン (例: v1.0.0) */
  version?: string;
  /** 件数 (例: 3部) */
  copies?: number;
  /** 引渡日 */
  delivery_date?: string;
}

export interface AcceptanceRequestInput {
  project_name: string;
  /** 件名 (例: 工事原価管理システム 検収のお願い) */
  subject?: string;
  /** 提出日 ISO */
  submission_date: string;
  client: AcceptanceParty;
  contractor: AcceptanceParty;
  deliverables: DeliverableItem[];
  /** 検収期間 開始 */
  acceptance_window_start: string;
  /** 検収期間 終了 */
  acceptance_window_end: string;
  /** 補足事項 */
  remarks?: string[];
  /** 言語 */
  locale?: 'ja' | 'en';
}

export interface AcceptanceRequestDocument {
  meta: {
    project_name: string;
    submission_date: string;
    locale: 'ja' | 'en';
  };
  subject: string;
  body_sections: { heading: string; body: string }[];
  markdown: string;
}

export interface AcceptanceCompletionInput {
  project_name: string;
  /** 件名 */
  subject?: string;
  /** 検収日 ISO */
  acceptance_date: string;
  client: AcceptanceParty;
  contractor: AcceptanceParty;
  deliverables: DeliverableItem[];
  /** 検収判定 */
  verdict: AcceptanceVerdict;
  /** 判定理由 */
  verdict_reason: string;
  /** 残不具合のサマリ */
  remaining_bugs?: BugCounts;
  /** 合格判定エンジンの出力 (任意) */
  judgment?: CriteriaJudgment;
  /** 瑕疵担保期間 (月) - デフォルト 6 */
  warranty_months?: number;
  /** 公共調達かどうか (会計法29条の3 引用) */
  is_public_sector?: boolean;
  /** 言語 */
  locale?: 'ja' | 'en';
  /** 補足事項 */
  remarks?: string[];
}

export interface AcceptanceCompletionDocument {
  meta: {
    project_name: string;
    acceptance_date: string;
    warranty_months: number;
    locale: 'ja' | 'en';
  };
  subject: string;
  verdict: AcceptanceVerdict;
  warranty: {
    start_date: string;
    end_date: string;
    months: number;
    legal_basis: string[];
  };
  body_sections: { heading: string; body: string }[];
  markdown: string;
}

/** 月数を加算した日付 (UTC基準) を ISO 形式で返す */
function addMonths(isoDate: string, months: number): string {
  const d = new Date(isoDate);
  d.setMonth(d.getMonth() + months);
  return d.toISOString();
}

/** 検収依頼書 (受託者→委託者) を生成 */
export function generateAcceptanceRequest(input: AcceptanceRequestInput): AcceptanceRequestDocument {
  const locale = input.locale ?? 'ja';
  const subject = input.subject ?? `${input.project_name} 検収のお願い`;

  const greeting = locale === 'ja'
    ? `拝啓 平素より格別のご高配を賜り、厚く御礼申し上げます。\n\n下記案件について、契約に基づき成果物の納品が完了しましたので、検収のほどよろしくお願い申し上げます。`
    : `Dear Sir or Madam,\n\nWe respectfully submit the deliverables for the project below, and kindly request your acceptance review.`;

  const deliverableTable = [
    `| # | 納品物 | 形式 | バージョン | 数量 | 引渡日 |`,
    `|---|--------|------|-----------|------|--------|`,
    ...input.deliverables.map(
      (d, i) =>
        `| ${i + 1} | ${d.name} | ${d.format} | ${d.version ?? '-'} | ${d.copies ?? 1} | ${d.delivery_date ?? input.submission_date.slice(0, 10)} |`,
    ),
  ].join('\n');

  const sections = [
    { heading: '1. 案件名', body: input.project_name },
    { heading: '2. 提出日', body: input.submission_date.slice(0, 10) },
    {
      heading: '3. 委託者 (甲)',
      body: formatPartyBlock(input.client),
    },
    {
      heading: '4. 受託者 (乙)',
      body: formatPartyBlock(input.contractor),
    },
    { heading: '5. 納品物一覧', body: deliverableTable },
    {
      heading: '6. 検収期間',
      body: `${input.acceptance_window_start.slice(0, 10)} 〜 ${input.acceptance_window_end.slice(0, 10)}\n\n民法 562 条 (買主の追完請求権) に定める通常合理的な検査期間として上記を提示いたします。期間内に異議の申立がない場合、検収完了とみなされます。`,
    },
    {
      heading: '7. 補足事項',
      body: input.remarks && input.remarks.length > 0 ? input.remarks.map((r) => `- ${r}`).join('\n') : 'なし',
    },
    {
      heading: '8. 受託者署名欄',
      body: formatSignatureBlock(input.contractor),
    },
  ];

  const markdown = [
    `# 検収依頼書`,
    ``,
    `**件名**: ${subject}`,
    ``,
    greeting,
    ``,
    ...sections.map((s) => `## ${s.heading}\n\n${s.body}\n`),
    ``,
    `--- `,
    locale === 'ja' ? `敬具` : `Sincerely,`,
  ].join('\n');

  return {
    meta: { project_name: input.project_name, submission_date: input.submission_date, locale },
    subject,
    body_sections: sections,
    markdown,
  };
}

/** 検収完了書 (委託者発行) を生成 */
export function generateAcceptanceCompletion(
  input: AcceptanceCompletionInput,
): AcceptanceCompletionDocument {
  const locale = input.locale ?? 'ja';
  const warrantyMonths = input.warranty_months ?? 6;
  const subject = input.subject ?? `${input.project_name} 検収完了通知書`;

  const warrantyEnd = addMonths(input.acceptance_date, warrantyMonths);

  const legalBasis: string[] = [
    '民法 562 条 (追完請求権)',
    '民法 563 条 (報酬減額請求権)',
    '民法 564 条 (契約解除権)',
    '民法 636 条 (請負人の担保責任)',
    '民法 637 条 (期間制限 / 不適合発見後 1 年以内通知)',
  ];
  if (input.is_public_sector) {
    legalBasis.push('会計法 29 条の3 (一般競争入札の検査義務 / 検査調書整備)');
    legalBasis.push('予算決算及び会計令 101 条 (検査の対象 / 期間)');
  }

  const deliverableTable = [
    `| # | 納品物 | 形式 | バージョン | 確認結果 |`,
    `|---|--------|------|-----------|----------|`,
    ...input.deliverables.map(
      (d, i) => `| ${i + 1} | ${d.name} | ${d.format} | ${d.version ?? '-'} | ✓ 受領確認済 |`,
    ),
  ].join('\n');

  const bugSummaryBlock = input.remaining_bugs
    ? [
        `| 重大度 | 件数 |`,
        `|--------|------|`,
        `| P1 (致命) | ${input.remaining_bugs.P1} |`,
        `| P2 (重大) | ${input.remaining_bugs.P2} |`,
        `| P3 (中程度) | ${input.remaining_bugs.P3} |`,
        `| P4 (軽微) | ${input.remaining_bugs.P4} |`,
      ].join('\n')
    : '_残不具合は記録されていません_';

  const sections = [
    { heading: '1. 案件名', body: input.project_name },
    { heading: '2. 検収日', body: input.acceptance_date.slice(0, 10) },
    {
      heading: '3. 委託者 (甲)',
      body: formatPartyBlock(input.client),
    },
    {
      heading: '4. 受託者 (乙)',
      body: formatPartyBlock(input.contractor),
    },
    { heading: '5. 納品物確認', body: deliverableTable },
    { heading: '6. 残不具合', body: bugSummaryBlock },
    {
      heading: '7. 検収判定',
      body: `**判定**: ${input.verdict}\n\n**理由**: ${input.verdict_reason}`,
    },
    {
      heading: '8. 瑕疵担保期間 (契約不適合責任)',
      body: [
        `本契約の契約不適合責任は、以下の根拠条文に基づきます。`,
        ``,
        ...legalBasis.map((l) => `- ${l}`),
        ``,
        `**担保期間**: ${input.acceptance_date.slice(0, 10)} 〜 ${warrantyEnd.slice(0, 10)} (${warrantyMonths}ヶ月)`,
        ``,
        `本期間内に発見された不適合については、委託者は受託者に対して以下を請求できます:`,
        ``,
        `1. **追完請求** (民 562 条): 修補・代替物の引渡・不足分の引渡`,
        `2. **報酬減額** (民 563 条): 追完不能時 / 追完拒絶時`,
        `3. **損害賠償** (民 415 条): 受託者の帰責事由による損害`,
        `4. **契約解除** (民 564 条): 重大な不適合かつ追完不能時`,
        ``,
        `> 民法 637 条により、契約不適合を発見した時から **1 年以内** に通知する必要があります。`,
      ].join('\n'),
    },
    {
      heading: '9. 委託者署名欄',
      body: formatSignatureBlock(input.client),
    },
  ];
  if (input.remarks && input.remarks.length > 0) {
    sections.push({ heading: '10. 補足事項', body: input.remarks.map((r) => `- ${r}`).join('\n') });
  }

  const markdown = [
    `# 検収完了通知書`,
    ``,
    `**件名**: ${subject}`,
    ``,
    locale === 'ja'
      ? `下記案件について、契約に基づく検収を完了しましたので、本通知書をもって正式に通知いたします。`
      : `We hereby officially notify the completion of acceptance for the project described below.`,
    ``,
    ...sections.map((s) => `## ${s.heading}\n\n${s.body}\n`),
  ].join('\n');

  return {
    meta: {
      project_name: input.project_name,
      acceptance_date: input.acceptance_date,
      warranty_months: warrantyMonths,
      locale,
    },
    subject,
    verdict: input.verdict,
    warranty: {
      start_date: input.acceptance_date,
      end_date: warrantyEnd,
      months: warrantyMonths,
      legal_basis: legalBasis,
    },
    body_sections: sections,
    markdown,
  };
}

function formatPartyBlock(p: AcceptanceParty): string {
  const lines: string[] = [];
  lines.push(`| 項目 | 内容 |`);
  lines.push(`|------|------|`);
  lines.push(`| 名称 | ${p.name} |`);
  if (p.address) lines.push(`| 住所 | ${p.address} |`);
  if (p.representative) {
    lines.push(`| 代表者 | ${p.representative_title ? p.representative_title + ' ' : ''}${p.representative} |`);
  }
  if (p.contact_person) lines.push(`| 担当者 | ${p.contact_person} |`);
  return lines.join('\n');
}

function formatSignatureBlock(p: AcceptanceParty): string {
  return [
    `${p.name}`,
    p.representative_title && p.representative ? `${p.representative_title}: ${p.representative}` : '',
    ``,
    `署名 / 印影:  [印]   ※ ${p.seal ? p.seal : '押印欄'}`,
  ]
    .filter(Boolean)
    .join('\n');
}
