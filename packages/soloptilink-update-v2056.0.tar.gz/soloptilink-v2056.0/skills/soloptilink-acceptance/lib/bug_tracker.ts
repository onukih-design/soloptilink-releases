/**
 * Bug Tracker - 不具合管理表 + バグ票テンプレ生成
 *
 * 責務:
 *   - 不具合票の項目定義 + ステートマシン制御
 *   - 集計表 (重大度別 / フェーズ別 / 担当者別 / オープン日数中央値)
 *   - 不正な状態遷移を防ぐバリデータ
 *
 * 入力: BugTrackerInput (案件情報 + バグ票一覧 or バグ票テンプレ生成要求)
 * 出力: BugTrackerDocument (BugReport[] + 集計 + Markdown)
 */

import type { Priority } from './criteria_engine';

/** 重大度 (S = 致命 / A = 重大 / B = 中程度 / C = 軽微) */
export type Severity = 'S' | 'A' | 'B' | 'C';

/** 不具合のライフサイクル (ステートマシン) */
export type BugStatus =
  | '新規'
  | '調査中'
  | '修正中'
  | '修正完了'
  | '再テスト中'
  | 'クローズ'
  | '差戻し';

/** どのテストフェーズで発見したか */
export type DiscoveryPhase = '結合テスト' | 'システムテスト' | 'UAT' | '本番リリース後';

/** 重大度ラベルの説明 */
export const SEVERITY_DESCRIPTION: Record<Severity, string> = {
  S: '致命的 (システム停止 / データ破壊 / 業務停止)',
  A: '重大 (主要機能の不具合 / 業務継続困難)',
  B: '中程度 (回避策あり / 業務継続可能)',
  C: '軽微 (UI崩れ / 表記揺れ / アクセシビリティ警告)',
};

/** 重大度→優先度のデフォルトマッピング */
export const SEVERITY_TO_PRIORITY: Record<Severity, Priority> = {
  S: 'P1',
  A: 'P2',
  B: 'P3',
  C: 'P4',
};

/** 状態遷移定義 (Allow リスト) */
export const STATUS_TRANSITIONS: Record<BugStatus, BugStatus[]> = {
  新規: ['調査中', 'クローズ'], // 即クローズ可 (重複バグ等)
  調査中: ['修正中', '差戻し', 'クローズ'],
  修正中: ['修正完了', '差戻し'],
  修正完了: ['再テスト中', '差戻し'],
  再テスト中: ['クローズ', '差戻し'],
  差戻し: ['修正中', 'クローズ'],
  クローズ: ['新規'], // 再オープン許可
};

/** バグ票の必須項目 */
export interface BugReport {
  id: string;
  /** 発見日 ISO */
  discovered_at: string;
  /** 発見者 */
  reporter: string;
  /** 発見フェーズ */
  phase: DiscoveryPhase;
  /** 該当モジュール */
  module: string;
  /** 重大度 */
  severity: Severity;
  /** 優先度 (省略時は重大度から導出) */
  priority: Priority;
  /** バグの概要タイトル */
  title: string;
  /** 再現手順 (順序付き) */
  reproduction_steps: string[];
  /** 期待結果 */
  expected: string;
  /** 実際結果 */
  actual: string;
  /** 環境情報 (OS/ブラウザ/端末/接続先) */
  environment: {
    os?: string;
    browser?: string;
    device?: string;
    backend_url?: string;
    version?: string;
  };
  /** スクリーンショットファイル (相対パス) */
  screenshots: string[];
  /** 修正担当者 */
  assignee?: string;
  /** ステータス */
  status: BugStatus;
  /** 修正コミット SHA */
  fix_commit?: string;
  /** 検証担当 */
  verifier?: string;
  /** 状態遷移履歴 */
  transitions: { from: BugStatus | null; to: BugStatus; at: string; by: string; note?: string }[];
}

export interface BugTrackerInput {
  project_name: string;
  reports: BugReport[];
}

/** 集計結果 */
export interface BugSummary {
  total: number;
  open: number;
  closed: number;
  by_severity: Record<Severity, number>;
  by_priority: Record<Priority, number>;
  by_phase: Record<DiscoveryPhase, number>;
  by_assignee: Record<string, number>;
  /** オープンしているバグの経過日数中央値 */
  open_age_days_median: number;
  /** オープンしているバグの経過日数 90 パーセンタイル */
  open_age_days_p90: number;
}

export interface BugTrackerDocument {
  meta: {
    project_name: string;
    generated_at: string;
  };
  reports: BugReport[];
  summary: BugSummary;
  markdown: string;
}

/** ID 生成: BUG-YYYYMMDD-NNN */
export function makeBugId(date: Date, sequence: number): string {
  const yyyy = date.getFullYear();
  const mm = String(date.getMonth() + 1).padStart(2, '0');
  const dd = String(date.getDate()).padStart(2, '0');
  return `BUG-${yyyy}${mm}${dd}-${String(sequence).padStart(3, '0')}`;
}

/**
 * バグ票テンプレを生成 (空フィールドで起票準備)
 */
export function createBugReportTemplate(params: {
  id: string;
  reporter: string;
  module: string;
  severity: Severity;
  phase?: DiscoveryPhase;
  title?: string;
}): BugReport {
  const now = new Date().toISOString();
  return {
    id: params.id,
    discovered_at: now,
    reporter: params.reporter,
    phase: params.phase ?? 'UAT',
    module: params.module,
    severity: params.severity,
    priority: SEVERITY_TO_PRIORITY[params.severity],
    title: params.title ?? '',
    reproduction_steps: [],
    expected: '',
    actual: '',
    environment: {},
    screenshots: [],
    status: '新規',
    transitions: [{ from: null, to: '新規', at: now, by: params.reporter, note: '起票' }],
  };
}

/**
 * ステータス遷移を実行 (バリデーション付き)
 *
 * @throws Error 不正な遷移の場合
 */
export function transitionStatus(
  report: BugReport,
  to: BugStatus,
  by: string,
  note?: string,
): BugReport {
  const allowed = STATUS_TRANSITIONS[report.status];
  if (!allowed.includes(to)) {
    throw new Error(
      `不正なステータス遷移: ${report.status} → ${to} (許可されている遷移: ${allowed.join(', ')})`,
    );
  }
  return {
    ...report,
    status: to,
    transitions: [
      ...report.transitions,
      { from: report.status, to, at: new Date().toISOString(), by, note },
    ],
  };
}

/** 数値配列の中央値 */
function median(values: number[]): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  return sorted.length % 2 === 0 ? (sorted[mid - 1] + sorted[mid]) / 2 : sorted[mid];
}

/** 数値配列の90パーセンタイル */
function percentile90(values: number[]): number {
  if (values.length === 0) return 0;
  const sorted = [...values].sort((a, b) => a - b);
  const index = Math.ceil(sorted.length * 0.9) - 1;
  return sorted[Math.max(0, index)];
}

/** 集計を計算 */
export function summarizeReports(reports: BugReport[], now: Date = new Date()): BugSummary {
  const bySeverity: Record<Severity, number> = { S: 0, A: 0, B: 0, C: 0 };
  const byPriority: Record<Priority, number> = { P1: 0, P2: 0, P3: 0, P4: 0 };
  const byPhase: Record<DiscoveryPhase, number> = {
    結合テスト: 0,
    システムテスト: 0,
    UAT: 0,
    本番リリース後: 0,
  };
  const byAssignee: Record<string, number> = {};

  let open = 0;
  let closed = 0;
  const openAges: number[] = [];

  for (const r of reports) {
    bySeverity[r.severity]++;
    byPriority[r.priority]++;
    byPhase[r.phase]++;
    if (r.assignee) byAssignee[r.assignee] = (byAssignee[r.assignee] ?? 0) + 1;
    if (r.status === 'クローズ') {
      closed++;
    } else {
      open++;
      const ageMs = now.getTime() - new Date(r.discovered_at).getTime();
      const ageDays = Math.max(0, Math.floor(ageMs / (1000 * 60 * 60 * 24)));
      openAges.push(ageDays);
    }
  }

  return {
    total: reports.length,
    open,
    closed,
    by_severity: bySeverity,
    by_priority: byPriority,
    by_phase: byPhase,
    by_assignee: byAssignee,
    open_age_days_median: median(openAges),
    open_age_days_p90: percentile90(openAges),
  };
}

/**
 * 不具合管理表ドキュメントを生成 (公開API)
 */
export function generateBugTracker(input: BugTrackerInput): BugTrackerDocument {
  const summary = summarizeReports(input.reports);
  const meta = {
    project_name: input.project_name,
    generated_at: new Date().toISOString(),
  };
  return {
    meta,
    reports: input.reports,
    summary,
    markdown: formatBugTrackerAsMarkdown({ meta, reports: input.reports, summary, markdown: '' }),
  };
}

/** Markdown 整形 */
export function formatBugTrackerAsMarkdown(
  doc: Omit<BugTrackerDocument, 'markdown'> & { markdown: string },
): string {
  const sev = doc.summary.by_severity;
  const pri = doc.summary.by_priority;
  const phase = doc.summary.by_phase;
  const assigneeRows = Object.entries(doc.summary.by_assignee)
    .sort((a, b) => b[1] - a[1])
    .map(([name, count]) => `| ${name} | ${count} |`)
    .join('\n');

  const reportRows = doc.reports
    .map(
      (r) =>
        `| ${r.id} | ${r.discovered_at.slice(0, 10)} | ${r.module} | ${r.severity} | ${r.priority} | ${r.title.replace(/\|/g, '\\|')} | ${r.status} | ${r.assignee ?? ''} |`,
    )
    .join('\n');

  return [
    `# 不具合管理表`,
    ``,
    `**案件名**: ${doc.meta.project_name}`,
    `**作成日**: ${doc.meta.generated_at.slice(0, 10)}`,
    `**総件数**: ${doc.summary.total} (オープン ${doc.summary.open} / クローズ ${doc.summary.closed})`,
    ``,
    `## サマリ`,
    ``,
    `### 重大度別件数`,
    ``,
    `| 重大度 | 件数 | 説明 |`,
    `|--------|------|------|`,
    `| S | ${sev.S} | ${SEVERITY_DESCRIPTION.S} |`,
    `| A | ${sev.A} | ${SEVERITY_DESCRIPTION.A} |`,
    `| B | ${sev.B} | ${SEVERITY_DESCRIPTION.B} |`,
    `| C | ${sev.C} | ${SEVERITY_DESCRIPTION.C} |`,
    ``,
    `### 優先度別件数`,
    ``,
    `| 優先度 | 件数 |`,
    `|--------|------|`,
    `| P1 | ${pri.P1} |`,
    `| P2 | ${pri.P2} |`,
    `| P3 | ${pri.P3} |`,
    `| P4 | ${pri.P4} |`,
    ``,
    `### 発見フェーズ別件数`,
    ``,
    `| フェーズ | 件数 |`,
    `|----------|------|`,
    `| 結合テスト | ${phase.結合テスト} |`,
    `| システムテスト | ${phase.システムテスト} |`,
    `| UAT | ${phase.UAT} |`,
    `| 本番リリース後 | ${phase.本番リリース後} |`,
    ``,
    `### 担当者別オープン件数`,
    ``,
    assigneeRows.length > 0 ? `| 担当者 | 件数 |\n|--------|------|\n${assigneeRows}` : '_未アサイン_',
    ``,
    `### オープンバグの経過日数`,
    ``,
    `- 中央値: ${doc.summary.open_age_days_median} 日`,
    `- 90パーセンタイル: ${doc.summary.open_age_days_p90} 日`,
    ``,
    `## バグ票一覧`,
    ``,
    doc.reports.length === 0
      ? '_バグ票はまだ起票されていません。_'
      : [
          `| ID | 発見日 | モジュール | 重大度 | 優先度 | タイトル | ステータス | 担当 |`,
          `|----|--------|-----------|--------|--------|----------|----------|------|`,
          reportRows,
        ].join('\n'),
  ].join('\n');
}

/**
 * 単一バグ票を Markdown 形式で出力 (起票テンプレ用)
 */
export function formatBugReportAsMarkdown(report: BugReport): string {
  return [
    `# バグ票: ${report.id}`,
    ``,
    `## 基本情報`,
    ``,
    `| 項目 | 内容 |`,
    `|------|------|`,
    `| ID | ${report.id} |`,
    `| 発見日 | ${report.discovered_at.slice(0, 10)} |`,
    `| 発見者 | ${report.reporter} |`,
    `| フェーズ | ${report.phase} |`,
    `| モジュール | ${report.module} |`,
    `| 重大度 | ${report.severity} (${SEVERITY_DESCRIPTION[report.severity]}) |`,
    `| 優先度 | ${report.priority} |`,
    `| タイトル | ${report.title || '_未記入_'} |`,
    `| ステータス | ${report.status} |`,
    `| 担当者 | ${report.assignee ?? '_未アサイン_'} |`,
    `| 修正コミット | ${report.fix_commit ?? ''} |`,
    `| 検証担当 | ${report.verifier ?? ''} |`,
    ``,
    `## 再現手順`,
    ``,
    report.reproduction_steps.length > 0
      ? report.reproduction_steps.map((s, i) => `${i + 1}. ${s}`).join('\n')
      : '_未記入_',
    ``,
    `## 期待結果`,
    ``,
    report.expected || '_未記入_',
    ``,
    `## 実際結果`,
    ``,
    report.actual || '_未記入_',
    ``,
    `## 環境`,
    ``,
    `| 項目 | 内容 |`,
    `|------|------|`,
    `| OS | ${report.environment.os ?? ''} |`,
    `| ブラウザ | ${report.environment.browser ?? ''} |`,
    `| 端末 | ${report.environment.device ?? ''} |`,
    `| 接続先 | ${report.environment.backend_url ?? ''} |`,
    `| バージョン | ${report.environment.version ?? ''} |`,
    ``,
    `## スクリーンショット`,
    ``,
    report.screenshots.length > 0 ? report.screenshots.map((s) => `- ${s}`).join('\n') : '_添付なし_',
    ``,
    `## 状態遷移履歴`,
    ``,
    `| 時刻 | From | To | 担当 | 備考 |`,
    `|------|------|-----|------|------|`,
    ...report.transitions.map(
      (t) => `| ${t.at.slice(0, 16).replace('T', ' ')} | ${t.from ?? '(起票)'} | ${t.to} | ${t.by} | ${t.note ?? ''} |`,
    ),
  ].join('\n');
}
