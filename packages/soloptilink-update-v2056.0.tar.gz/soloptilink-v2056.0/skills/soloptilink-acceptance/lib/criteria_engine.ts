/**
 * Criteria Engine - 検収合格基準の判定ロジック
 *
 * 責務:
 *   - 重大度別不具合件数を入力として「合格 / 条件付合格 / 不合格」を判定
 *   - standard / strict / public-sector の3モード切替
 *   - 業界慣習 + 会計法29条の3 (公共調達) 対応
 *
 * 入力: BugCounts (P1〜P4 の件数)
 * 出力: CriteriaJudgment (verdict + reason + applied_thresholds)
 */

export type CriteriaMode = 'standard' | 'strict' | 'public-sector';

/** 重大度コード */
export type Priority = 'P1' | 'P2' | 'P3' | 'P4';

/** 重大度別件数 (入力) */
export interface BugCounts {
  P1: number;
  P2: number;
  P3: number;
  P4: number;
}

/** モード別の許容閾値 */
export interface CriteriaThresholds {
  /** P1: 致命的 (システム停止 / データ破壊) */
  P1: number;
  /** P2: 重大 (主要機能の不具合) */
  P2: number;
  /** P3: 中程度 (回避策あり) */
  P3: number;
  /** P4: 軽微 (UI崩れ等)。-1 は無制限 */
  P4: number;
}

/** 判定結果 */
export type AcceptanceVerdict = '合格' | '条件付合格' | '不合格';

export interface CriteriaJudgment {
  verdict: AcceptanceVerdict;
  reason: string;
  applied_thresholds: CriteriaThresholds;
  applied_mode: CriteriaMode;
  failed_priorities: Priority[];
  conditional_priorities: Priority[];
  /** 条件付合格時の再テスト推奨期限 (日数) */
  recommended_retest_days?: number;
}

/**
 * モード別の許容閾値テーブル
 *
 * - standard: 民間 / 一般受託 (P1=0, P2≤2, P3≤10, P4任意)
 * - strict: 大手SIer / 厳格な品質要求 (P1=P2=0, P3≤2, P4任意)
 * - public-sector: 公共調達 / 会計法29条の3 (P1=P2=P3=0, P4≤5)
 */
export const CRITERIA_THRESHOLDS: Record<CriteriaMode, CriteriaThresholds> = {
  standard: { P1: 0, P2: 2, P3: 10, P4: -1 },
  strict: { P1: 0, P2: 0, P3: 2, P4: -1 },
  'public-sector': { P1: 0, P2: 0, P3: 0, P4: 5 },
};

/** モードのメタ情報 (人間可読な説明) */
export const CRITERIA_DESCRIPTIONS: Record<CriteriaMode, string> = {
  standard: '民間案件向け 標準合格基準 (P1=0 / P2≤2 / P3≤10)',
  strict: '大手SIer向け 厳格合格基準 (P1=P2=0 / P3≤2)',
  'public-sector': '公共調達向け 検査調書整備対応基準 (会計法29条の3 / P1=P2=P3=0 / P4≤5)',
};

/**
 * 重大度別の閾値超過を判定する内部ヘルパ
 *
 * 戻り値: 超過した重大度 or 'CONDITIONAL' (条件付合格相当) のリスト
 */
function classifyOverages(counts: BugCounts, thresholds: CriteriaThresholds): {
  failed: Priority[];
  conditional: Priority[];
} {
  const failed: Priority[] = [];
  const conditional: Priority[] = [];

  // P1超過 = 即不合格
  if (thresholds.P1 >= 0 && counts.P1 > thresholds.P1) failed.push('P1');

  // P2超過 = strict / public-sector では即不合格、standard では条件付合格対象
  if (thresholds.P2 >= 0 && counts.P2 > thresholds.P2) {
    failed.push('P2');
  }

  // P3超過 = 条件付合格相当
  if (thresholds.P3 >= 0 && counts.P3 > thresholds.P3) {
    conditional.push('P3');
  }

  // P4超過 = public-sector のみ条件付合格対象
  if (thresholds.P4 >= 0 && counts.P4 > thresholds.P4) {
    conditional.push('P4');
  }

  return { failed, conditional };
}

/**
 * 検収合格基準を評価する (公開API)
 *
 * @param counts 重大度別不具合件数
 * @param mode 適用する合格基準モード
 * @returns CriteriaJudgment
 */
export function evaluateCriteria(counts: BugCounts, mode: CriteriaMode = 'standard'): CriteriaJudgment {
  const thresholds = CRITERIA_THRESHOLDS[mode];
  const { failed, conditional } = classifyOverages(counts, thresholds);

  // 不合格判定
  if (failed.length > 0) {
    const reasonParts = failed.map((p) => `${p}: ${counts[p]} > 許容${thresholds[p]}件`);
    return {
      verdict: '不合格',
      reason: `致命的不具合あり: ${reasonParts.join(' / ')}`,
      applied_thresholds: thresholds,
      applied_mode: mode,
      failed_priorities: failed,
      conditional_priorities: conditional,
    };
  }

  // 条件付合格判定
  if (conditional.length > 0) {
    const reasonParts = conditional.map((p) => `${p}: ${counts[p]} > 許容${thresholds[p]}件`);
    return {
      verdict: '条件付合格',
      reason: `軽微な閾値超過: ${reasonParts.join(' / ')} → 期限内修正で本合格`,
      applied_thresholds: thresholds,
      applied_mode: mode,
      failed_priorities: failed,
      conditional_priorities: conditional,
      recommended_retest_days: mode === 'public-sector' ? 7 : 14,
    };
  }

  // 合格
  return {
    verdict: '合格',
    reason: '全ての重大度で許容閾値内に収まっています',
    applied_thresholds: thresholds,
    applied_mode: mode,
    failed_priorities: [],
    conditional_priorities: [],
  };
}

/**
 * 判定結果を Markdown 表で整形
 */
export function formatJudgmentAsMarkdown(judgment: CriteriaJudgment, counts: BugCounts): string {
  const t = judgment.applied_thresholds;
  const limitStr = (n: number) => (n < 0 ? '無制限' : `${n}件`);

  return [
    `# 検収合格判定結果`,
    ``,
    `**適用モード**: \`${judgment.applied_mode}\` (${CRITERIA_DESCRIPTIONS[judgment.applied_mode]})`,
    ``,
    `**判定**: **${judgment.verdict}**`,
    ``,
    `**理由**: ${judgment.reason}`,
    ``,
    `## 重大度別件数 vs 許容閾値`,
    ``,
    `| 重大度 | 検出件数 | 許容閾値 | 状態 |`,
    `|--------|----------|----------|------|`,
    `| P1 (致命) | ${counts.P1} | ${limitStr(t.P1)} | ${judgment.failed_priorities.includes('P1') ? '✗ 超過' : '✓ 範囲内'} |`,
    `| P2 (重大) | ${counts.P2} | ${limitStr(t.P2)} | ${judgment.failed_priorities.includes('P2') ? '✗ 超過' : '✓ 範囲内'} |`,
    `| P3 (中程度) | ${counts.P3} | ${limitStr(t.P3)} | ${judgment.conditional_priorities.includes('P3') ? '△ 条件付' : '✓ 範囲内'} |`,
    `| P4 (軽微) | ${counts.P4} | ${limitStr(t.P4)} | ${judgment.conditional_priorities.includes('P4') ? '△ 条件付' : '✓ 範囲内'} |`,
    ``,
    judgment.recommended_retest_days != null
      ? `## 再テスト推奨期限\n\n条件付合格時、**${judgment.recommended_retest_days}日以内**に再テスト + 本合格判定を実施してください。`
      : '',
  ]
    .filter(Boolean)
    .join('\n');
}

/**
 * モード一覧を取得 (UIプレゼン用)
 */
export function listCriteriaModes(): { mode: CriteriaMode; thresholds: CriteriaThresholds; description: string }[] {
  return (Object.keys(CRITERIA_THRESHOLDS) as CriteriaMode[]).map((mode) => ({
    mode,
    thresholds: CRITERIA_THRESHOLDS[mode],
    description: CRITERIA_DESCRIPTIONS[mode],
  }));
}
