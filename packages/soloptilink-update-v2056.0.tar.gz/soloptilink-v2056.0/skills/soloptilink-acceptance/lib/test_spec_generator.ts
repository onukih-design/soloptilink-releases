/**
 * Test Spec Generator - テスト仕様書 (テストケース集) を生成
 *
 * 責務:
 *   - RFP-DNA / モジュール一覧から7カテゴリのテストケースを推論生成
 *   - 命名規則 TC-<モジュール>-<番号> を厳格化
 *   - 各テストケースに前提条件 / 操作手順 / 期待結果 / 結果記入欄を付与
 *
 * 入力: TestSpecInput (モジュール / シナリオ / 暗黙要件キーワード)
 * 出力: TestSpecDocument (TestCase[] + Markdown)
 */

export type TestCategory =
  | 'functional'
  | 'ui'
  | 'non_functional'
  | 'business_scenario'
  | 'security'
  | 'disaster_recovery'
  | 'data_migration';

export const TEST_CATEGORY_LABEL: Record<TestCategory, string> = {
  functional: '機能テスト',
  ui: 'UI テスト',
  non_functional: '非機能テスト',
  business_scenario: '業務シナリオテスト',
  security: 'セキュリティテスト',
  disaster_recovery: '障害復旧テスト',
  data_migration: 'データ移行検証',
};

/** テスト結果の記入欄。実施前は 'pending' */
export type TestResult = 'pending' | 'OK' | 'NG' | 'N/A';

export interface TestCase {
  id: string;
  category: TestCategory;
  module: string;
  scenario_name: string;
  preconditions: string[];
  steps: string[];
  expected_result: string;
  result_slot: TestResult;
  /** 実施日 (YYYY-MM-DD) */
  executed_date?: string;
  /** 実施テスター名 */
  tester?: string;
  /** 紐付バグ票ID (NG の場合) */
  linked_bug_id?: string;
  /** 想定実行時間 (分) */
  estimated_minutes?: number;
}

export interface TestSpecInput {
  project_name: string;
  /** 対象モジュール (RFP-DNA の scope.modules を踏襲) */
  modules: string[];
  /** 業務シナリオ */
  scenarios: string[];
  /** 暗黙要件キーワード (RFP-DNA implicit_requirements の trigger_keyword) */
  implicit_keywords?: string[];
  /** 非機能要件 (性能 / 可用性 / セキュリティ) */
  non_functional?: {
    performance_slo?: string;
    availability_target?: string;
    backup_rpo?: string;
  };
  /** データ移行有無 */
  has_data_migration?: boolean;
  /** 業種 (テストケース推論時に参照) */
  industry?: string;
}

export interface TestSpecDocument {
  meta: {
    project_name: string;
    industry?: string;
    generated_at: string;
    total_cases: number;
    by_category: Record<TestCategory, number>;
  };
  test_cases: TestCase[];
  markdown: string;
}

/** モジュール名からTC ID プレフィクスを生成 */
function moduleToPrefix(module: string): string {
  // 全角スペース除去 + 英数化
  const normalized = module
    .replace(/\s+/g, '')
    .replace(/[ぁ-ん]/g, '')
    .replace(/[ァ-ヶ]/g, '')
    .replace(/[一-龥]/g, '');
  if (normalized.length >= 2) {
    return normalized.toUpperCase().slice(0, 12);
  }
  // 日本語のみのモジュールはローマ字化マップを利用
  const ROMAJI_MAP: Record<string, string> = {
    認証: 'AUTH',
    ログイン: 'AUTH',
    ダッシュボード: 'DASHBOARD',
    検索: 'SEARCH',
    帳票: 'REPORT',
    設定: 'SETTINGS',
    ユーザ: 'USER',
    ユーザー: 'USER',
    管理: 'ADMIN',
    通知: 'NOTIFY',
    監視: 'MONITOR',
    監査: 'AUDIT',
    バックアップ: 'BACKUP',
    工事案件: 'JOB',
    見積書: 'QUOTE',
    注文書: 'ORDER',
    請求書: 'INVOICE',
    ダウンロード: 'DOWNLOAD',
    アップロード: 'UPLOAD',
  };
  for (const [k, v] of Object.entries(ROMAJI_MAP)) {
    if (module.includes(k)) return v;
  }
  return 'GENERAL';
}

/** ID 生成 (一意性は呼び出し側のカウンタで担保) */
function makeTcId(prefix: string, n: number): string {
  return `TC-${prefix}-${String(n).padStart(3, '0')}`;
}

/** 機能テスト生成 (CRUD / 検索 / バリデーション) */
function buildFunctionalCases(module: string, startN: number): TestCase[] {
  const prefix = moduleToPrefix(module);
  const baseN = startN;
  const cases: TestCase[] = [
    {
      id: makeTcId(prefix, baseN),
      category: 'functional',
      module,
      scenario_name: `${module}: 新規登録 (正常系)`,
      preconditions: ['有効なログインセッションを保持している', '必要なマスタデータが事前登録されている'],
      steps: [
        `${module}画面を開く`,
        '新規登録ボタンを押下する',
        '必須項目に有効値を入力する',
        '保存ボタンを押下する',
      ],
      expected_result: `${module}が新規登録され、一覧に表示される。登録完了メッセージが表示される。`,
      result_slot: 'pending',
      estimated_minutes: 5,
    },
    {
      id: makeTcId(prefix, baseN + 1),
      category: 'functional',
      module,
      scenario_name: `${module}: 更新 (正常系)`,
      preconditions: ['対象データが既に登録されている'],
      steps: [
        `${module}一覧画面を開く`,
        '対象レコードの編集ボタンを押下する',
        '任意の項目を変更する',
        '更新ボタンを押下する',
      ],
      expected_result: '更新内容が反映され、更新完了メッセージが表示される。',
      result_slot: 'pending',
      estimated_minutes: 4,
    },
    {
      id: makeTcId(prefix, baseN + 2),
      category: 'functional',
      module,
      scenario_name: `${module}: 削除 (正常系)`,
      preconditions: ['削除可能なレコードが存在する'],
      steps: ['対象レコードを選択し削除ボタンを押下', '確認ダイアログで「はい」を押下'],
      expected_result: '対象レコードが論理削除または物理削除され、一覧から消える。監査ログに削除イベントが記録される。',
      result_slot: 'pending',
      estimated_minutes: 3,
    },
    {
      id: makeTcId(prefix, baseN + 3),
      category: 'functional',
      module,
      scenario_name: `${module}: 必須項目未入力エラー`,
      preconditions: [],
      steps: ['新規登録画面を開く', '必須項目を空欄のまま保存ボタンを押下'],
      expected_result: '必須項目エラーメッセージが表示され、登録されない。',
      result_slot: 'pending',
      estimated_minutes: 3,
    },
    {
      id: makeTcId(prefix, baseN + 4),
      category: 'functional',
      module,
      scenario_name: `${module}: 検索 (条件指定)`,
      preconditions: ['検索対象データが10件以上登録されている'],
      steps: ['検索画面を開く', '任意の条件を指定する', '検索ボタンを押下'],
      expected_result: '指定条件に合致するレコードのみ表示される。0件の場合は0件メッセージが表示される。',
      result_slot: 'pending',
      estimated_minutes: 5,
    },
  ];
  return cases;
}

/** UI テスト生成 */
function buildUiCases(module: string, startN: number): TestCase[] {
  const prefix = moduleToPrefix(module);
  return [
    {
      id: makeTcId(prefix, startN),
      category: 'ui',
      module,
      scenario_name: `${module}: レスポンシブ表示確認 (PC / タブレット / モバイル)`,
      preconditions: [],
      steps: [
        `${module}画面を PC (1920x1080) で表示`,
        'タブレット (1024x768) に切替',
        'モバイル (375x667) に切替',
      ],
      expected_result: '各画面サイズで主要要素が崩れず、操作可能であること。横スクロールが発生しないこと。',
      result_slot: 'pending',
      estimated_minutes: 8,
    },
    {
      id: makeTcId(prefix, startN + 1),
      category: 'ui',
      module,
      scenario_name: `${module}: アクセシビリティ (WCAG 2.1 AA レベル)`,
      preconditions: [],
      steps: ['axe DevTools / Lighthouse でアクセシビリティ監査を実行'],
      expected_result: 'クリティカル違反 0 件。コントラスト比 4.5:1 以上。キーボード操作のみで主要機能が利用可能。',
      result_slot: 'pending',
      estimated_minutes: 10,
    },
    {
      id: makeTcId(prefix, startN + 2),
      category: 'ui',
      module,
      scenario_name: `${module}: ブラウザ互換性 (Chrome / Edge / Safari / Firefox)`,
      preconditions: [],
      steps: ['Chrome 最新版で表示・操作', 'Edge / Safari / Firefox で同様の操作'],
      expected_result: '主要機能がいずれのブラウザでも同じ挙動を示す。',
      result_slot: 'pending',
      estimated_minutes: 12,
    },
  ];
}

/** 業務シナリオテスト生成 */
function buildScenarioCases(scenarios: string[], startN: number): TestCase[] {
  return scenarios.map((scenario, idx) => ({
    id: `TC-SCENARIO-${String(startN + idx).padStart(3, '0')}`,
    category: 'business_scenario' as const,
    module: '業務シナリオ',
    scenario_name: scenario,
    preconditions: ['シナリオに登場する全マスタが整備されている', '実施担当者は該当業務の権限を保持している'],
    steps: ['シナリオに沿って End-to-End で操作を実施', '各ステップで期待結果を逐次確認'],
    expected_result: 'シナリオが業務目的を達成し、関連する帳票・通知・連携が正しく動作する。',
    result_slot: 'pending',
    estimated_minutes: 30,
  }));
}

/** 非機能テスト生成 */
function buildNonFunctionalCases(input: TestSpecInput, startN: number): TestCase[] {
  const cases: TestCase[] = [];
  const slo = input.non_functional?.performance_slo ?? '主要画面 95%ile レスポンス ≤ 3 秒';
  cases.push({
    id: `TC-PERF-${String(startN).padStart(3, '0')}`,
    category: 'non_functional',
    module: '性能',
    scenario_name: '主要画面のレスポンスタイム計測',
    preconditions: ['負荷ツール (k6 / JMeter) が準備されている'],
    steps: ['想定同時接続数の50%で5分間負荷投入', '95パーセンタイルレスポンスを記録', '同時接続数の100%でも繰り返し'],
    expected_result: `${slo} を達成すること。エラー率 < 0.1%。`,
    result_slot: 'pending',
    estimated_minutes: 60,
  });
  cases.push({
    id: `TC-AVAIL-${String(startN + 1).padStart(3, '0')}`,
    category: 'non_functional',
    module: '可用性',
    scenario_name: '可用性目標確認 (SLO/SLA)',
    preconditions: ['監視システムが稼働している'],
    steps: ['過去30日の稼働率を監視ログから集計'],
    expected_result: `${input.non_functional?.availability_target ?? '99.9%以上 (年間ダウンタイム ≤ 8.76 時間)'} を達成。`,
    result_slot: 'pending',
    estimated_minutes: 15,
  });
  cases.push({
    id: `TC-BACKUP-${String(startN + 2).padStart(3, '0')}`,
    category: 'non_functional',
    module: 'バックアップ',
    scenario_name: 'バックアップ・リストア検証',
    preconditions: ['事前に取得済バックアップが存在する'],
    steps: ['Stage 環境にバックアップをリストア', '主要データの整合性を確認'],
    expected_result: `RPO ${input.non_functional?.backup_rpo ?? '1 時間'} 以内のデータが復元されること。`,
    result_slot: 'pending',
    estimated_minutes: 45,
  });
  return cases;
}

/** セキュリティテスト生成 (OWASP Top 10 ベース) */
function buildSecurityCases(startN: number): TestCase[] {
  const owaspChecks: { name: string; expectation: string }[] = [
    { name: 'A01: アクセス制御の不備 (IDOR / 権限昇格)', expectation: '認可されていないリソースへのアクセスがブロックされる' },
    { name: 'A02: 暗号化の不備 (TLS / Cipher)', expectation: 'TLS 1.2 以上、HSTS 有効、弱い Cipher 無し' },
    { name: 'A03: インジェクション (SQLi / OS Command)', expectation: 'パラメータ化クエリで防御。エラーメッセージから情報漏洩しない' },
    { name: 'A04: 安全でない設計', expectation: '脅威モデリングで識別された主要リスクが実装で対策されている' },
    { name: 'A05: 設定ミス', expectation: 'デバッグモード OFF、不要ポート閉鎖、デフォルト認証情報撤去' },
    { name: 'A07: 認証不備 (MFA / セッション固定 / ブルートフォース)', expectation: '5回失敗でロック、MFA 必須、セッション ID 再生成' },
    { name: 'A09: ログ・監視不備', expectation: '認証失敗 / 権限変更 / 重要データアクセスを監査ログに記録' },
  ];
  return owaspChecks.map((c, idx) => ({
    id: `TC-SEC-${String(startN + idx).padStart(3, '0')}`,
    category: 'security' as const,
    module: 'セキュリティ',
    scenario_name: c.name,
    preconditions: ['セキュリティスキャナ (ZAP / Burp / nuclei 等) が準備されている'],
    steps: ['対象機能に対しスキャナを実行', '手動で代表的な攻撃ベクトルを試行'],
    expected_result: c.expectation,
    result_slot: 'pending',
    estimated_minutes: 30,
  }));
}

/** 障害復旧テスト */
function buildDisasterRecoveryCases(startN: number): TestCase[] {
  return [
    {
      id: `TC-DR-${String(startN).padStart(3, '0')}`,
      category: 'disaster_recovery',
      module: 'DR',
      scenario_name: 'DBサーバ停止時の自動フェイルオーバー',
      preconditions: ['プライマリ + スタンバイ DB が稼働中'],
      steps: ['プライマリ DB を意図的に停止', '監視 → アラート → フェイルオーバーの実施を確認'],
      expected_result: 'RTO 内に自動フェイルオーバーが完了し、業務継続可能。',
      result_slot: 'pending',
      estimated_minutes: 40,
    },
    {
      id: `TC-DR-${String(startN + 1).padStart(3, '0')}`,
      category: 'disaster_recovery',
      module: 'DR',
      scenario_name: 'バックアップからのフルリストア (最悪ケース)',
      preconditions: ['夜間バックアップ取得済'],
      steps: ['Stage 環境を初期化', 'バックアップからフルリストア', '主要データの整合性を確認'],
      expected_result: '12時間以内にリストア完了、データ欠損 ≤ RPO 設定値。',
      result_slot: 'pending',
      estimated_minutes: 90,
    },
  ];
}

/** データ移行検証テスト */
function buildDataMigrationCases(startN: number): TestCase[] {
  return [
    {
      id: `TC-MIG-${String(startN).padStart(3, '0')}`,
      category: 'data_migration',
      module: 'データ移行',
      scenario_name: '全件件数の整合性確認',
      preconditions: ['旧システムからのエクスポート完了', '新システムへのインポート完了'],
      steps: ['各マスタ・トランザクションテーブルの件数を旧/新で比較'],
      expected_result: '件数が一致すること (ただし論理削除データを除く)。',
      result_slot: 'pending',
      estimated_minutes: 30,
    },
    {
      id: `TC-MIG-${String(startN + 1).padStart(3, '0')}`,
      category: 'data_migration',
      module: 'データ移行',
      scenario_name: 'マスタ突合 (顧客・取引先・商品)',
      preconditions: [],
      steps: ['ランダムサンプル 100 件を旧システムと突合'],
      expected_result: '100% 一致。差異がある場合は移行ルールに記載済の例外であること。',
      result_slot: 'pending',
      estimated_minutes: 45,
    },
    {
      id: `TC-MIG-${String(startN + 2).padStart(3, '0')}`,
      category: 'data_migration',
      module: 'データ移行',
      scenario_name: '集計値整合性 (月次売上 / 残高)',
      preconditions: [],
      steps: ['月次売上 / 残高を旧/新システムで集計'],
      expected_result: '集計差異 0 円 (税端数含む)。',
      result_slot: 'pending',
      estimated_minutes: 30,
    },
  ];
}

/**
 * テスト仕様書を生成する (公開API)
 */
export function generateTestSpec(input: TestSpecInput): TestSpecDocument {
  const cases: TestCase[] = [];

  // 機能テスト + UIテスト (各モジュールごと)
  for (const module of input.modules) {
    cases.push(...buildFunctionalCases(module, 1));
    cases.push(...buildUiCases(module, 100));
  }

  // 業務シナリオテスト
  if (input.scenarios.length > 0) {
    cases.push(...buildScenarioCases(input.scenarios, 1));
  }

  // 非機能テスト
  cases.push(...buildNonFunctionalCases(input, 1));

  // セキュリティテスト
  cases.push(...buildSecurityCases(1));

  // 障害復旧テスト
  cases.push(...buildDisasterRecoveryCases(1));

  // データ移行検証
  if (input.has_data_migration) {
    cases.push(...buildDataMigrationCases(1));
  }

  // カテゴリ別集計
  const byCategory: Record<TestCategory, number> = {
    functional: 0,
    ui: 0,
    non_functional: 0,
    business_scenario: 0,
    security: 0,
    disaster_recovery: 0,
    data_migration: 0,
  };
  for (const c of cases) byCategory[c.category]++;

  const meta = {
    project_name: input.project_name,
    industry: input.industry,
    generated_at: new Date().toISOString(),
    total_cases: cases.length,
    by_category: byCategory,
  };

  return {
    meta,
    test_cases: cases,
    markdown: formatTestSpecAsMarkdown({ meta, test_cases: cases, markdown: '' }),
  };
}

/** Markdown 整形 */
export function formatTestSpecAsMarkdown(doc: Omit<TestSpecDocument, 'markdown'> & { markdown: string }): string {
  const header = [
    `# テスト仕様書 (テストケース集)`,
    ``,
    `**案件名**: ${doc.meta.project_name}`,
    doc.meta.industry ? `**業種**: ${doc.meta.industry}` : '',
    `**作成日**: ${doc.meta.generated_at.slice(0, 10)}`,
    `**総ケース数**: ${doc.meta.total_cases}`,
    ``,
    `## カテゴリ別件数`,
    ``,
    `| カテゴリ | 件数 |`,
    `|----------|------|`,
    ...(Object.keys(doc.meta.by_category) as TestCategory[]).map(
      (k) => `| ${TEST_CATEGORY_LABEL[k]} | ${doc.meta.by_category[k]} |`,
    ),
    ``,
    `---`,
    ``,
  ]
    .filter(Boolean)
    .join('\n');

  const groupedByCategory: Record<TestCategory, TestCase[]> = {
    functional: [],
    ui: [],
    non_functional: [],
    business_scenario: [],
    security: [],
    disaster_recovery: [],
    data_migration: [],
  };
  for (const c of doc.test_cases) groupedByCategory[c.category].push(c);

  const sections = (Object.keys(groupedByCategory) as TestCategory[])
    .filter((k) => groupedByCategory[k].length > 0)
    .map((k) => {
      const heading = `# ${TEST_CATEGORY_LABEL[k]}`;
      const rows = groupedByCategory[k].map((tc) => formatCaseAsMarkdown(tc)).join('\n\n');
      return `${heading}\n\n${rows}`;
    })
    .join('\n\n---\n\n');

  return header + sections;
}

function formatCaseAsMarkdown(tc: TestCase): string {
  return [
    `## ${tc.id}: ${tc.scenario_name}`,
    ``,
    `- **モジュール**: ${tc.module}`,
    `- **想定実行時間**: ${tc.estimated_minutes ?? '-'} 分`,
    ``,
    `### 前提条件`,
    ``,
    tc.preconditions.length > 0 ? tc.preconditions.map((p) => `- ${p}`).join('\n') : '- なし',
    ``,
    `### 操作手順`,
    ``,
    tc.steps.map((s, i) => `${i + 1}. ${s}`).join('\n'),
    ``,
    `### 期待結果`,
    ``,
    tc.expected_result,
    ``,
    `### 結果記入欄`,
    ``,
    `| 結果 | 実施日 | テスター | 紐付バグ票 |`,
    `|------|--------|----------|-----------|`,
    `| ${tc.result_slot} | ${tc.executed_date ?? ''} | ${tc.tester ?? ''} | ${tc.linked_bug_id ?? ''} |`,
  ].join('\n');
}
