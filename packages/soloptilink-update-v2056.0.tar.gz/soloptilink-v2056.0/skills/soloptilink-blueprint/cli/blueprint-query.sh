#!/usr/bin/env bash
# SoloptiLinkAI v2028.0 — /soloptilink-blueprint CLI dispatcher
#
# Domain Blueprint Library (DBL) を CLI から照会する薄いラッパ。
# 本体ロジックは domains/*.json + validate_domain_v2028.sh + generation-recommender.mjs に委譲。

set -euo pipefail

DOMAINS_DIR="$HOME/.claude/skills/soloptilink-japan/domains"
VALIDATOR="$HOME/.claude/skills/soloptilink-japan/contrib/validate_domain_v2028.sh"
RECOMMENDER="$HOME/.soloptilink/lib/iron-dome/generation-recommender.sh"
RPB_DIR="$HOME/.soloptilink/.iron-dome-rpb"
ADMIN_MODE=0
[ -f "$HOME/.soloptilink/.admin_mode" ] || [ -f "$HOME/.soloptilink/.admin-token" ] && ADMIN_MODE=1

CMD="${1:-help}"
shift || true

usage() {
  cat <<EOF
SoloptiLinkAI v2028.0 — Domain Blueprint Library Query

Usage:
  blueprint-query.sh --list                           # 全業種一覧
  blueprint-query.sh --rank                           # 完成度ランキング
  blueprint-query.sh --industry <key>                 # 業種詳細
  blueprint-query.sh --industry <key> --field <name>  # 特定フィールドのみ (laws/competitors/kpis/panels/models/hotspots/grants)
  blueprint-query.sh --search "<keyword>"             # 横断検索 (jp_keywords / applicable_laws / competitor_products)
  blueprint-query.sh --diff <key1> <key2>             # 2業種比較
  blueprint-query.sh --completeness [--industry <key>] # 採点
  blueprint-query.sh --recommend <key>                # Recommender 先読み (P0/P1/P2 件数)
EOF
}

strip_internal() {
  # 顧客モードでは _internal_score を除去して表示
  if [ "$ADMIN_MODE" -eq 1 ]; then
    cat
  else
    jq 'del(._internal_score) | del(.._internal_score?)'
  fi
}

case "$CMD" in
  --list)
    echo "=== SoloptiLinkAI DBL — 全業種一覧 ==="
    ls "$DOMAINS_DIR"/*.json 2>/dev/null | while read -r f; do
      key=$(basename "$f" .json)
      ja=$(jq -r '.industry_ja // ""' "$f")
      phase=$(jq -r '.phase_id // "?"' "$f")
      printf "  [%-2s] %-25s %s\n" "$phase" "$key" "$ja"
    done
    ;;

  --rank)
    if ! command -v jq >/dev/null 2>&1; then echo "jq required" >&2; exit 2; fi
    bash "$VALIDATOR" --json 2>/dev/null | jq -r '
      .details | sort_by(-.blueprint_completeness) | .[] |
      "  [\(.tier | ascii_upcase | (. + "       ")[0:8])] \(.industry | (. + "                         ")[0:25]) — \(.blueprint_completeness)pt"
    '
    ;;

  --industry)
    KEY="${1:-}"
    [ -z "$KEY" ] && { usage; exit 2; }
    shift || true
    FILE="$DOMAINS_DIR/$KEY.json"
    [ -f "$FILE" ] || { echo "ERROR: $KEY not found in DBL" >&2; exit 1; }

    FIELD=""
    [ "${1:-}" = "--field" ] && FIELD="${2:-}" && shift 2 || true

    if [ -n "$FIELD" ]; then
      case "$FIELD" in
        laws)         jq '.applicable_laws // []' "$FILE" ;;
        competitors)  jq '.competitor_products // []' "$FILE" ;;
        kpis)         jq '.standard_dashboard_kpis // []' "$FILE" ;;
        panels)       jq '.standard_panels // []' "$FILE" ;;
        models)       jq '.standard_db_skeleton.models // []' "$FILE" ;;
        hotspots)     jq '.competitor_hotspots_jp // []' "$FILE" ;;
        grants)       jq '.related_grant_keywords // []' "$FILE" ;;
        terminology)  jq '.terminology // {}' "$FILE" ;;
        legal_rules)  jq '.legal_rules // {}' "$FILE" ;;
        density)      jq '.iron_dome_density_target // {}' "$FILE" ;;
        *)            echo "Unknown field: $FIELD (use: laws/competitors/kpis/panels/models/hotspots/grants/terminology/legal_rules/density)" >&2; exit 2 ;;
      esac
    else
      cat "$FILE" | strip_internal
    fi
    ;;

  --search)
    KEYWORD="${1:-}"
    [ -z "$KEYWORD" ] && { usage; exit 2; }
    echo "=== '$KEYWORD' を含む業種 ==="
    for f in "$DOMAINS_DIR"/*.json; do
      key=$(basename "$f" .json)
      ja=$(jq -r '.industry_ja // ""' "$f")
      if jq -e --arg kw "$KEYWORD" '
        (.applicable_laws // [] | tostring | contains($kw)) or
        (.jp_keywords // [] | tostring | contains($kw)) or
        (.terminology // {} | tostring | contains($kw)) or
        (.competitor_products // [] | tostring | contains($kw)) or
        (.report_templates // [] | tostring | contains($kw))
      ' "$f" >/dev/null 2>&1; then
        printf "  ✓ %-25s %s\n" "$key" "$ja"
      fi
    done
    ;;

  --diff)
    K1="${1:-}"; K2="${2:-}"
    [ -z "$K1" ] || [ -z "$K2" ] && { usage; exit 2; }
    F1="$DOMAINS_DIR/$K1.json"; F2="$DOMAINS_DIR/$K2.json"
    [ -f "$F1" ] || { echo "ERROR: $K1 not found"; exit 1; }
    [ -f "$F2" ] || { echo "ERROR: $K2 not found"; exit 1; }

    echo "=== Diff: $K1 vs $K2 ==="
    echo ""
    echo "--- 適用法令の差分 ---"
    diff <(jq -r '.applicable_laws // [] | sort | .[]' "$F1") <(jq -r '.applicable_laws // [] | sort | .[]' "$F2") || true
    echo ""
    echo "--- 競合製品の差分 ---"
    diff <(jq -r '.competitor_products // [] | sort_by(.name) | .[].name' "$F1") <(jq -r '.competitor_products // [] | sort_by(.name) | .[].name' "$F2") || true
    echo ""
    echo "--- DB models の差分 ---"
    diff <(jq -r '.standard_db_skeleton.models // [] | .[]' "$F1") <(jq -r '.standard_db_skeleton.models // [] | .[]' "$F2") || true
    ;;

  --completeness)
    INDUSTRY=""
    [ "${1:-}" = "--industry" ] && INDUSTRY="${2:-}" && shift 2 || true
    if [ -n "$INDUSTRY" ]; then
      bash "$VALIDATOR" --industry "$INDUSTRY"
    else
      bash "$VALIDATOR"
    fi
    ;;

  --recommend)
    KEY="${1:-}"
    [ -z "$KEY" ] && { usage; exit 2; }
    if [ ! -x "$RECOMMENDER" ]; then
      echo "ERROR: Recommender not found at $RECOMMENDER" >&2; exit 1
    fi
    bash "$RECOMMENDER" recommend --industry "$KEY" 2>/dev/null | jq -r '
      "業種: \(.industry_ja) (\(.industry_key))",
      "目標密度: files=\(.density_target.min_files) loc=\(.density_target.min_loc)",
      "P0 件数: \(.summary.p0_count)",
      "P1 件数: \(.summary.p1_count)",
      "P2 件数: \(.summary.p2_count)",
      "総件数: \(.summary.total)",
      "カテゴリ別: \(.summary.categories | tostring)"
    '
    ;;

  -h|--help|help)
    usage
    ;;

  *)
    echo "Unknown command: $CMD" >&2
    usage
    exit 2
    ;;
esac
