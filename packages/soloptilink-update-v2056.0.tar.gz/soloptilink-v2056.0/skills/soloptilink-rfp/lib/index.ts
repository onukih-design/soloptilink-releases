/**
 * soloptilink-rfp public API
 *
 * 全モジュールをまとめてエクスポート。スキルから一括で使えるようにする。
 */

export * from './rfp_parser';
export * from './rate_table';
export * from './cost_estimator';
export * from './wbs_generator';
export * from './proposal_generator';
export * from './contract_generator';

import type { RfpDna } from './rfp_parser';
import { parseRfpFromText, formatRfpDnaAsMarkdown } from './rfp_parser';
import { generateEstimate, formatEstimateAsMarkdown, type EstimateResult } from './cost_estimator';
import { generateWbs, formatWbsAsMarkdown, type WbsResult } from './wbs_generator';
import {
  generateProposal,
  formatProposalAsMarkdown,
  type CompanyInfo,
  type ProposalDocument,
} from './proposal_generator';
import {
  generateContract,
  formatContractAsMarkdown,
  type ContractType,
  type ContractParty,
  type ContractDocument,
} from './contract_generator';

export interface FullPackageInput {
  rfp_text: string;
  industry?: string;
  client_type?: '民間' | '公共' | '自治体';
  scale?: 'small' | 'medium' | 'large' | 'enterprise';
  proposer_company: CompanyInfo;
  client_party: ContractParty;
  contractor_party: ContractParty;
  contract_type?: ContractType;
  approach?: 'waterfall' | 'agile' | 'hybrid';
  rate_client?: 'standard' | 'enterprise' | 'public_sector' | 'startup';
}

export interface FullPackageOutput {
  rfp: RfpDna;
  estimate: EstimateResult;
  wbs: WbsResult;
  proposal: ProposalDocument;
  contract: ContractDocument;
  markdown: {
    rfp_dna: string;
    estimate: string;
    wbs: string;
    proposal: string;
    contract: string;
  };
}

/**
 * RFPテキストから提案書一式を一括生成 (`--mode all` 相当)
 */
export function generateFullPackage(input: FullPackageInput): FullPackageOutput {
  const rfp = parseRfpFromText(input.rfp_text, {
    source: 'inline_text',
    industry: input.industry,
    client_type: input.client_type,
    scale: input.scale,
  });

  const estimate = generateEstimate({
    rfp,
    rate_client: input.rate_client,
    approach: input.approach,
  });

  const wbs = generateWbs({
    rfp,
    approach: input.approach,
  });

  const proposal = generateProposal({
    rfp,
    estimate,
    wbs,
    proposer_company: input.proposer_company,
    client_name: input.client_party.name,
    approach: input.approach,
  });

  const contract = generateContract({
    type: input.contract_type ?? '請負',
    client: input.client_party,
    contractor: input.contractor_party,
    rfp,
    estimate,
  });

  return {
    rfp,
    estimate,
    wbs,
    proposal,
    contract,
    markdown: {
      rfp_dna: formatRfpDnaAsMarkdown(rfp),
      estimate: formatEstimateAsMarkdown(estimate, input.client_party.name),
      wbs: formatWbsAsMarkdown(wbs),
      proposal: formatProposalAsMarkdown(proposal),
      contract: formatContractAsMarkdown(contract),
    },
  };
}
