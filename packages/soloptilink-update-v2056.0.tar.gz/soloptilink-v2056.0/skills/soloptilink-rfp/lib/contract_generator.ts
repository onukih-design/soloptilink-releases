/**
 * Contract Generator - 日本SI業界の契約書 (請負/準委任/派遣) 自動生成
 *
 * 法的リスクを最小化するため、業界標準条項を網羅。
 * 出典: 経産省「情報システム・モデル取引・契約書」(R3.4更新)
 */

import type { RfpDna } from './rfp_parser';
import type { EstimateResult } from './cost_estimator';

export type ContractType = '請負' | '準委任' | '派遣';

export interface ContractParty {
  role: '甲' | '乙';
  name: string;
  name_kana?: string;
  address: string;
  representative: string;
  representative_title?: string;
  registration_no?: string;  // 法人番号 (13桁)
  invoice_no?: string;        // 適格請求書登録番号 (T+13桁)
}

export interface ContractDocument {
  meta: {
    contract_type: ContractType;
    generated_at: string;
    contract_no?: string;
    version: string;
  };
  parties: { client: ContractParty; contractor: ContractParty };
  preamble: string;
  articles: ContractArticle[];
  appendices: { title: string; content: string }[];
  signatures: {
    location: string;
    date: string;
    seals: { party: '甲' | '乙'; representative: string; placeholder: string }[];
  };
  stamp_duty: { amount_jpy: number; reason: string };
}

export interface ContractArticle {
  article_no: number;
  title: string;
  paragraphs: string[];
  notes?: string;
}

export interface GenerateContractInput {
  type: ContractType;
  client: ContractParty;
  contractor: ContractParty;
  rfp: RfpDna;
  estimate?: EstimateResult;
  contract_amount?: number;
  payment_terms?: string;
  delivery_date?: string;
  warranty_months?: number;
  jurisdiction?: string;
  contract_no?: string;
}

export function generateContract(input: GenerateContractInput): ContractDocument {
  const articles = buildArticles(input);
  return {
    meta: {
      contract_type: input.type,
      generated_at: new Date().toISOString(),
      contract_no: input.contract_no,
      version: '1.0',
    },
    parties: { client: input.client, contractor: input.contractor },
    preamble: buildPreamble(input),
    articles,
    appendices: buildAppendices(input),
    signatures: buildSignatures(input),
    stamp_duty: calculateStampDuty(input),
  };
}

function buildPreamble(input: GenerateContractInput): string {
  const target = input.rfp.goal.primary;
  switch (input.type) {
    case '請負':
      return `${input.client.name} (以下「甲」という。) と ${input.contractor.name} (以下「乙」という。) とは、甲が乙に対し ${target} の開発業務 (以下「本件業務」という。) を委託することに関し、以下のとおり請負契約 (以下「本契約」という。) を締結する。`;
    case '準委任':
      return `${input.client.name} (以下「甲」という。) と ${input.contractor.name} (以下「乙」という。) とは、甲が乙に対し ${target} に関する業務 (以下「本件業務」という。) を委託することに関し、以下のとおり準委任契約 (以下「本契約」という。) を締結する。`;
    case '派遣':
      return `${input.client.name} (以下「派遣先」という。) と ${input.contractor.name} (以下「派遣元」という。) とは、派遣元が派遣先に対し ${target} に従事する労働者を派遣することに関し、労働者派遣事業の適正な運営の確保及び派遣労働者の保護等に関する法律 (以下「派遣法」という。) に基づき、以下のとおり労働者派遣個別契約 (以下「本契約」という。) を締結する。`;
  }
}

function buildArticles(input: GenerateContractInput): ContractArticle[] {
  if (input.type === '請負') return buildUkeoiArticles(input);
  if (input.type === '準委任') return buildJunInninArticles(input);
  return buildHakenArticles(input);
}

function buildUkeoiArticles(input: GenerateContractInput): ContractArticle[] {
  const amount = input.contract_amount ?? input.estimate?.total_with_tax ?? 0;
  const warranty = input.warranty_months ?? 6;
  return [
    {
      article_no: 1,
      title: '目的',
      paragraphs: [
        `本契約は、甲が乙に対し ${input.rfp.goal.primary} の開発を発注し、乙が完成・納品することを目的とする。`,
      ],
    },
    {
      article_no: 2,
      title: '業務範囲',
      paragraphs: [
        `本件業務の範囲は、別紙1「業務仕様書」に定めるとおりとする。`,
        `業務範囲外の事項について、甲が乙に追加で依頼する場合、別途見積・契約により対応するものとする。`,
      ],
    },
    {
      article_no: 3,
      title: '納期',
      paragraphs: [
        `乙は ${input.delivery_date ?? input.rfp.constraints.deadline ?? '別途協議で定める期日'} までに、本件業務を完成させ甲に納品する。`,
        `天災地変その他両当事者の責に帰さない事由により納期遵守が困難な場合、両者協議の上、納期を変更できる。`,
      ],
    },
    {
      article_no: 4,
      title: '請負代金',
      paragraphs: [
        `本契約の請負代金は ¥${amount.toLocaleString()} (税込) とする。`,
        `内訳: 本体価格 ¥${Math.round(amount / 1.1).toLocaleString()} + 消費税 ¥${Math.round(amount - amount / 1.1).toLocaleString()}`,
      ],
    },
    {
      article_no: 5,
      title: '支払条件',
      paragraphs: [
        input.payment_terms ?? `請負代金は、甲乙合意の検収完了日から30日以内に、乙の指定口座へ振込により支払う。`,
        `振込手数料は甲の負担とする。`,
        `下請代金支払遅延等防止法 (以下「下請法」という。) の適用がある場合は、同法第2条の2に従い、給付受領日から60日以内に支払うものとする。`,
      ],
    },
    {
      article_no: 6,
      title: '検収',
      paragraphs: [
        `乙は納品物を甲に提出し、甲は受領後14日以内に検査を完了する。`,
        `検査の結果、不適合が認められる場合、甲は乙に補修又は代替物の納品を請求することができる。`,
        `甲が前項の期間内に検査結果を通知しない場合、検査に合格したものとみなす。`,
      ],
    },
    {
      article_no: 7,
      title: '知的財産権',
      paragraphs: [
        `本件業務により創出された成果物に関する著作権 (著作権法第27条及び第28条に定める権利を含む) は、検収完了かつ請負代金完済時点で乙から甲に移転する。`,
        `ただし、乙が本契約締結前から保有する汎用的なプログラム・ライブラリ・ノウハウは乙の権利として留保する。`,
        `成果物の利用に必要な範囲で、乙は甲に対し再使用許諾権を含む利用権を許諾する。`,
      ],
    },
    {
      article_no: 8,
      title: '秘密保持',
      paragraphs: [
        `両当事者は、本契約に関して相手方から開示を受けた情報を秘密として取り扱い、相手方の事前の書面による承諾なく第三者に開示してはならない。`,
        `秘密保持義務は本契約終了後も3年間存続する。`,
      ],
    },
    {
      article_no: 9,
      title: '個人情報保護',
      paragraphs: [
        `両当事者は、本件業務に関し取得する個人情報を、個人情報の保護に関する法律 (令和4年改正) を遵守して取り扱う。`,
        `乙は、漏えい等が発生した場合、覚知後速やかに甲に報告し、個人情報保護委員会への報告 (5日以内速報・30日以内確報) を支援する。`,
      ],
    },
    {
      article_no: 10,
      title: '契約不適合責任',
      paragraphs: [
        `成果物に契約不適合 (民法第562条) があった場合、甲は検収完了後 ${warranty} ヶ月以内に限り、乙に対し補修・代金減額・損害賠償・契約解除を請求できる。`,
        `ただし、甲の指示・支給品に起因する不適合については、この限りでない。`,
      ],
    },
    {
      article_no: 11,
      title: '損害賠償',
      paragraphs: [
        `乙の本契約違反により甲に損害が生じた場合、乙は甲に対し損害を賠償する。`,
        `ただし、賠償額は本契約の請負代金額を上限とする。ただし、乙の故意又は重過失による場合はこの限りでない。`,
      ],
    },
    {
      article_no: 12,
      title: '解除',
      paragraphs: [
        `相手方が本契約に違反し、相当期間を定めた催告後も是正しない場合、無催告で本契約を解除できる。`,
        `相手方が破産・民事再生・会社更生の申立てを行った場合、又は反社会的勢力との関与が判明した場合、催告なく即時解除できる。`,
      ],
    },
    {
      article_no: 13,
      title: '反社会的勢力の排除',
      paragraphs: [
        `両当事者は、自己又は自己の役員等が反社会的勢力でないこと、及び反社会的勢力に関与しないことを確約する。`,
        `本確約に違反した場合、相手方は催告なく本契約を解除できる。`,
      ],
    },
    {
      article_no: 14,
      title: '紛争解決',
      paragraphs: [
        `本契約に関する紛争については、${input.jurisdiction ?? '東京地方裁判所'} を第一審の専属的合意管轄裁判所とする。`,
      ],
    },
    {
      article_no: 15,
      title: '協議事項',
      paragraphs: [
        `本契約に定めのない事項、又は解釈について疑義が生じた場合、両当事者は信義誠実の原則に従い協議の上解決するものとする。`,
      ],
    },
  ];
}

function buildJunInninArticles(input: GenerateContractInput): ContractArticle[] {
  const amount = input.contract_amount ?? input.estimate?.total_with_tax ?? 0;
  return [
    {
      article_no: 1,
      title: '目的',
      paragraphs: [
        `本契約は、甲が乙に対し ${input.rfp.goal.primary} に関する業務 (以下「本件業務」という。) を委託することを目的とする。`,
        `本契約は民法第656条の準委任契約に基づくものであり、乙は完成義務を負わず、善良な管理者の注意義務 (民法第644条) をもって業務を遂行する。`,
      ],
    },
    {
      article_no: 2,
      title: '業務内容',
      paragraphs: [
        `本件業務の内容は、別紙1「業務範囲書」に定めるとおりとする。`,
      ],
    },
    {
      article_no: 3,
      title: '契約期間',
      paragraphs: [
        `本契約の期間は、契約締結日から ${input.delivery_date ?? '別紙に定める期日'} までとする。`,
      ],
    },
    {
      article_no: 4,
      title: '委託料',
      paragraphs: [
        `委託料は ¥${amount.toLocaleString()} (税込) とする。`,
        `本件業務の工数は別紙2「工数明細」のとおりとし、月次精算とする。`,
        `工数の超過・不足が生じた場合、別途協議の上精算する。`,
      ],
    },
    {
      article_no: 5,
      title: '支払条件',
      paragraphs: [
        `委託料は、毎月末締・翌月末払いとし、乙の指定口座へ振込により支払う。`,
        `振込手数料は甲の負担とする。`,
      ],
    },
    {
      article_no: 6,
      title: '善管注意義務',
      paragraphs: [
        `乙は、業務遂行にあたり、善良な管理者の注意をもって業務を遂行する。`,
        `乙は、業務の進捗状況を定期的に甲に報告し、甲の指示を仰ぐものとする。`,
      ],
    },
    {
      article_no: 7,
      title: '指揮命令関係',
      paragraphs: [
        `本件業務における指揮命令権は乙が有する。`,
        `甲は乙の従事者に直接指揮命令を行わない。これは偽装請負を防止するための重要な確認事項である。`,
      ],
    },
    {
      article_no: 8,
      title: '秘密保持',
      paragraphs: [
        `両当事者は、本契約に関して相手方から開示を受けた情報を秘密として取り扱い、相手方の事前の書面による承諾なく第三者に開示してはならない。`,
        `秘密保持義務は本契約終了後も3年間存続する。`,
      ],
    },
    {
      article_no: 9,
      title: '個人情報保護',
      paragraphs: [
        `両当事者は、本件業務に関し取得する個人情報を、個人情報の保護に関する法律 (令和4年改正) を遵守して取り扱う。`,
      ],
    },
    {
      article_no: 10,
      title: '解除',
      paragraphs: [
        `両当事者は、いつでも将来に向かって本契約を解除できる (民法第651条第1項)。`,
        `ただし、相手方の不利な時期に解除した当事者は、相手方に生じた損害を賠償する義務を負う (民法第651条第2項)。`,
      ],
    },
    {
      article_no: 11,
      title: '反社会的勢力の排除',
      paragraphs: [
        `両当事者は、自己又は自己の役員等が反社会的勢力でないこと、及び反社会的勢力に関与しないことを確約する。`,
      ],
    },
    {
      article_no: 12,
      title: '紛争解決',
      paragraphs: [
        `本契約に関する紛争については、${input.jurisdiction ?? '東京地方裁判所'} を第一審の専属的合意管轄裁判所とする。`,
      ],
    },
  ];
}

function buildHakenArticles(input: GenerateContractInput): ContractArticle[] {
  const amount = input.contract_amount ?? input.estimate?.total_with_tax ?? 0;
  return [
    {
      article_no: 1,
      title: '労働者派遣の業務内容',
      paragraphs: [
        `派遣元は派遣先に対し、${input.rfp.goal.primary} に関する業務に従事する派遣労働者を派遣する。`,
        `派遣労働者の業務範囲は別紙1「業務指示書」に定める。`,
      ],
    },
    {
      article_no: 2,
      title: '派遣期間',
      paragraphs: [
        `派遣期間は、契約締結日から ${input.delivery_date ?? '別紙に定める期日'} までとする。`,
        `派遣法第40条の2に基づく事業所単位3年・個人単位3年の制限を遵守する。`,
      ],
    },
    {
      article_no: 3,
      title: '指揮命令関係',
      paragraphs: [
        `派遣労働者に対する指揮命令権は派遣先が有する。`,
        `派遣先は、派遣労働者の業務遂行に関し、派遣法第40条の規定に従い、適切な指揮命令を行う。`,
      ],
    },
    {
      article_no: 4,
      title: '派遣料金',
      paragraphs: [
        `派遣料金は ¥${amount.toLocaleString()} (税込) とする。`,
        `料金は月次精算とし、毎月末締・翌月末払いとする。`,
      ],
    },
    {
      article_no: 5,
      title: '同一労働同一賃金',
      paragraphs: [
        `派遣元は、派遣法第30条の3 (令和2年4月施行) に基づき、派遣労働者の待遇について「労使協定方式」又は「派遣先均等均衡方式」のいずれかにより確保する。`,
        `本契約では「労使協定方式」を採用する。`,
      ],
    },
    {
      article_no: 6,
      title: '苦情処理・指導',
      paragraphs: [
        `派遣先・派遣元それぞれに苦情処理担当者を配置する。`,
        `派遣労働者からの苦情は、まず派遣先苦情処理担当者が対応し、解決しない場合は派遣元苦情処理担当者と協議の上対応する。`,
      ],
    },
    {
      article_no: 7,
      title: '安全衛生',
      paragraphs: [
        `派遣先は労働安全衛生法に基づき、派遣労働者の安全衛生に配慮する。`,
        `派遣元は派遣労働者に対し、必要な安全衛生教育を実施する。`,
      ],
    },
    {
      article_no: 8,
      title: '秘密保持',
      paragraphs: [
        `両当事者及び派遣労働者は、業務上知り得た秘密を漏洩してはならない。`,
        `秘密保持義務は本契約終了後も3年間存続する。`,
      ],
    },
    {
      article_no: 9,
      title: '反社会的勢力の排除',
      paragraphs: [
        `両当事者は、自己又は自己の役員等が反社会的勢力でないことを確約する。`,
      ],
    },
    {
      article_no: 10,
      title: '紛争解決',
      paragraphs: [
        `本契約に関する紛争については、${input.jurisdiction ?? '東京地方裁判所'} を第一審の専属的合意管轄裁判所とする。`,
      ],
    },
  ];
}

function buildAppendices(input: GenerateContractInput): { title: string; content: string }[] {
  const appendices: { title: string; content: string }[] = [];

  appendices.push({
    title: '別紙1: 業務仕様書',
    content: [
      '## 業務目的',
      input.rfp.goal.primary,
      '',
      '## 業務範囲',
      ...input.rfp.scope.in_scope.map((s) => `- ${s}`),
      '',
      '## 成果物',
      ...input.rfp.deliverables.map((d) => `- ${d}`),
      '',
      '## 適用法令',
      ...input.rfp.constraints.legal.map((l) => `- ${l}`),
    ].join('\n'),
  });

  if (input.estimate) {
    appendices.push({
      title: '別紙2: 費用内訳',
      content: input.estimate.phases
        .map((p) => `- ${p.phase_name_ja}: ¥${p.amount.toLocaleString()} (${p.effort_man_months}人月)`)
        .join('\n'),
    });
  }

  appendices.push({
    title: '別紙3: スケジュール',
    content: input.rfp.deadline
      ? `- 開始: ${input.rfp.deadline.start ?? '契約締結日'}\n- 完了: ${input.rfp.deadline.end ?? input.delivery_date ?? '別途協議'}`
      : '別途WBSにて定める。',
  });

  return appendices;
}

function buildSignatures(input: GenerateContractInput): ContractDocument['signatures'] {
  return {
    location: '東京',
    date: new Date().toISOString().slice(0, 10),
    seals: [
      { party: '甲', representative: input.client.representative, placeholder: '[甲印]' },
      { party: '乙', representative: input.contractor.representative, placeholder: '[乙印]' },
    ],
  };
}

/**
 * 印紙税額計算 (印紙税法別表第一 第2号文書「請負契約」)
 *
 * 請負契約のみ印紙税が発生。準委任・派遣は対象外 (継続的役務提供契約は7号 月額4千円)。
 */
/**
 * 印紙税額表 第2号文書 (請負に関する契約書) ── 本則
 *
 * ★正典 (SoT): 本体 lib/japan/eseal.ts の STAMP_TAX_DOC2_BRACKETS /
 *   STAMP_TAX_DOC2_NON_TAXABLE_UNDER。一次情報は
 *   lib/japan/legal-values/approval-workflow.legal.json (国税庁 タックスアンサー No.7140)。
 *   本ファイルは顧客プロジェクトへ配布される独立資産のため本体 lib を import できず、
 *   やむを得ず転記している。SoT との一致は
 *   lib/japan/_verify/stamp-templates.verify.mjs (STPL レーン) が常時実走で突合する。
 *
 * ★本則であり建設工事請負の軽減措置ではない (軽減対象外の契約に軽減額を当てると過少になる)。
 * ★引き方は「上端 (この金額まで) 以下」。上位の階段を頭打ちにすると【過少】になり、
 *   不足分は過怠税 (本税の3倍) の対象になる。
 */
export const STAMP_DUTY_DOC2_BRACKETS: ReadonlyArray<{ upperJpy: number | null; taxJpy: number; label: string }> = [
  { upperJpy: 1_000_000, taxJpy: 200, label: '1万円以上100万円以下' },
  { upperJpy: 2_000_000, taxJpy: 400, label: '100万円超200万円以下' },
  { upperJpy: 3_000_000, taxJpy: 1_000, label: '200万円超300万円以下' },
  { upperJpy: 5_000_000, taxJpy: 2_000, label: '300万円超500万円以下' },
  { upperJpy: 10_000_000, taxJpy: 10_000, label: '500万円超1,000万円以下' },
  { upperJpy: 50_000_000, taxJpy: 20_000, label: '1,000万円超5,000万円以下' },
  { upperJpy: 100_000_000, taxJpy: 60_000, label: '5,000万円超1億円以下' },
  { upperJpy: 500_000_000, taxJpy: 100_000, label: '1億円超5億円以下' },
  { upperJpy: 1_000_000_000, taxJpy: 200_000, label: '5億円超10億円以下' },
  { upperJpy: 5_000_000_000, taxJpy: 400_000, label: '10億円超50億円以下' },
  { upperJpy: null, taxJpy: 600_000, label: '50億円超' },
];

/** 1万円未満は非課税 (第2号文書)。国税庁 No.7140。 */
export const STAMP_DUTY_DOC2_NON_TAXABLE_UNDER = 10_000;

/** 契約金額の記載のないものは200円 (第2号文書)。国税庁 No.7140。 */
export const STAMP_DUTY_DOC2_NO_AMOUNT_STATED = 200;

/** 契約金額 (円) から第2号文書の印紙税額を求める。 */
export function calcStampDutyDoc2(amountYen: number): { amount_jpy: number; label: string } {
  if (!Number.isFinite(amountYen) || amountYen < STAMP_DUTY_DOC2_NON_TAXABLE_UNDER) {
    return { amount_jpy: 0, label: '1万円未満 (非課税)' };
  }
  for (const b of STAMP_DUTY_DOC2_BRACKETS) {
    if (b.upperJpy === null || amountYen <= b.upperJpy) return { amount_jpy: b.taxJpy, label: b.label };
  }
  const last = STAMP_DUTY_DOC2_BRACKETS[STAMP_DUTY_DOC2_BRACKETS.length - 1];
  return { amount_jpy: last.taxJpy, label: last.label };
}

function calculateStampDuty(input: GenerateContractInput): { amount_jpy: number; reason: string } {
  if (input.type === '準委任') {
    return { amount_jpy: 0, reason: '準委任契約は印紙税法別表第一の対象外 (継続的取引基本契約は7号 4千円のケースあり)' };
  }
  if (input.type === '派遣') {
    return { amount_jpy: 4000, reason: '労働者派遣個別契約 (継続的取引基本契約 7号文書)' };
  }
  // 契約金額が一切記載されていない場合は「契約金額の記載のないもの」= 200円 (0円契約とは別物)。
  const stated = input.contract_amount ?? input.estimate?.total_with_tax;
  if (stated === undefined) {
    return { amount_jpy: STAMP_DUTY_DOC2_NO_AMOUNT_STATED, reason: '請負契約 契約金額の記載のないもの (2号文書)' };
  }
  const r = calcStampDutyDoc2(stated);
  return { amount_jpy: r.amount_jpy, reason: `請負契約 ${r.label} (2号文書)` };
}

/**
 * 契約書を Markdown で出力 (.docx 化前のレビュー用)
 */
export function formatContractAsMarkdown(c: ContractDocument): string {
  const lines: string[] = [];
  lines.push(`# ${c.meta.contract_type}契約書`);
  if (c.meta.contract_no) lines.push(`**契約番号**: ${c.meta.contract_no}`);
  lines.push('');
  lines.push(c.preamble);
  lines.push('');
  for (const a of c.articles) {
    lines.push(`## 第${a.article_no}条 (${a.title})`);
    a.paragraphs.forEach((p, i) => lines.push(`${i + 1}. ${p}`));
    lines.push('');
  }
  lines.push('---');
  lines.push('');
  lines.push(`本契約締結の証として、本書2通を作成し、甲乙各1通を保管する。`);
  lines.push('');
  lines.push(`**${c.signatures.date}** ${c.signatures.location}`);
  lines.push('');
  lines.push(`**甲**: ${c.parties.client.name}`);
  lines.push(`住所: ${c.parties.client.address}`);
  lines.push(`代表: ${c.parties.client.representative} ${c.signatures.seals[0].placeholder}`);
  lines.push('');
  lines.push(`**乙**: ${c.parties.contractor.name}`);
  lines.push(`住所: ${c.parties.contractor.address}`);
  lines.push(`代表: ${c.parties.contractor.representative} ${c.signatures.seals[1].placeholder}`);
  lines.push('');
  lines.push(`**印紙税**: ¥${c.stamp_duty.amount_jpy.toLocaleString()} (${c.stamp_duty.reason})`);
  lines.push('');
  for (const ap of c.appendices) {
    lines.push(`---`);
    lines.push(`# ${ap.title}`);
    lines.push('');
    lines.push(ap.content);
    lines.push('');
  }
  return lines.join('\n');
}
