/**
 * WBS Generator - 5階層 WBS + 依存関係 + マイルストーン + ガントチャート
 *
 * 入力: RFP-DNA + プロジェクト規模/期間
 * 出力: WBS Tree + Gantt-ready timeline + マイルストーン
 */

import type { RfpDna } from './rfp_parser';

export interface WbsNode {
  id: string;
  level: number;
  name: string;
  duration_days: number;
  start_offset_days: number;
  end_offset_days: number;
  dependencies: string[];
  responsible_role?: string;
  deliverables: string[];
  children: WbsNode[];
  is_milestone: boolean;
  effort_md?: number;
  notes?: string;
}

export interface WbsResult {
  meta: {
    generated_at: string;
    project_start: string;
    project_end: string;
    total_duration_days: number;
    total_effort_md: number;
    approach: 'waterfall' | 'agile' | 'hybrid';
  };
  root: WbsNode;
  milestones: { id: string; name: string; date: string }[];
  critical_path: string[];
  flat: WbsNode[];
}

export interface GenerateWbsInput {
  rfp: RfpDna;
  project_start?: string;
  total_duration_weeks?: number;
  team_size?: number;
  approach?: 'waterfall' | 'agile' | 'hybrid';
}

export function generateWbs(input: GenerateWbsInput): WbsResult {
  const approach = input.approach ?? 'waterfall';
  const projectStart = input.project_start ?? new Date().toISOString().slice(0, 10);
  const baseDuration = input.total_duration_weeks ?? inferDurationFromScale(input.rfp.meta.scale);
  const totalDays = baseDuration * 7;

  const root: WbsNode =
    approach === 'agile'
      ? buildAgileWbs(input.rfp, totalDays)
      : buildWaterfallWbs(input.rfp, totalDays);

  flattenAndAssignDates(root, 0);
  const flat = flatten(root);
  const milestones = flat
    .filter((n) => n.is_milestone)
    .map((n) => ({
      id: n.id,
      name: n.name,
      date: addDays(projectStart, n.end_offset_days),
    }));
  const criticalPath = computeCriticalPath(flat);
  const totalEffort = flat.reduce((s, n) => s + (n.effort_md ?? 0), 0);

  return {
    meta: {
      generated_at: new Date().toISOString(),
      project_start: projectStart,
      project_end: addDays(projectStart, totalDays),
      total_duration_days: totalDays,
      total_effort_md: round1(totalEffort),
      approach,
    },
    root,
    milestones,
    critical_path: criticalPath,
    flat,
  };
}

function inferDurationFromScale(scale: string): number {
  switch (scale) {
    case 'small': return 8;
    case 'medium': return 16;
    case 'large': return 32;
    case 'enterprise': return 52;
    default: return 16;
  }
}

function buildWaterfallWbs(rfp: RfpDna, totalDays: number): WbsNode {
  const factors = {
    requirements: 0.10,
    basic_design: 0.15,
    detailed_design: 0.15,
    implementation: 0.35,
    integration_test: 0.12,
    acceptance_test: 0.05,
    deployment: 0.05,
    closing: 0.03,
  };

  const root: WbsNode = {
    id: '1',
    level: 1,
    name: 'プロジェクト全体',
    duration_days: totalDays,
    start_offset_days: 0,
    end_offset_days: totalDays,
    dependencies: [],
    deliverables: ['全成果物'],
    is_milestone: false,
    children: [],
  };

  let cursor = 0;
  let phaseIdx = 1;
  for (const [phaseKey, factor] of Object.entries(factors)) {
    const days = Math.ceil(totalDays * factor);
    const phaseId = `1.${phaseIdx}`;
    const phaseNode: WbsNode = {
      id: phaseId,
      level: 2,
      name: phaseLabel(phaseKey),
      duration_days: days,
      start_offset_days: cursor,
      end_offset_days: cursor + days,
      dependencies: phaseIdx > 1 ? [`1.${phaseIdx - 1}`] : [],
      responsible_role: phaseRole(phaseKey),
      deliverables: phaseDeliverables(phaseKey, rfp),
      is_milestone: false,
      children: buildPhaseTasks(phaseId, phaseKey, days, rfp),
      notes: undefined,
    };
    root.children.push(phaseNode);

    const milestoneNode: WbsNode = {
      id: `${phaseId}.M`,
      level: 3,
      name: `${phaseLabel(phaseKey)} 完了マイルストーン`,
      duration_days: 0,
      start_offset_days: cursor + days,
      end_offset_days: cursor + days,
      dependencies: [phaseId],
      deliverables: [`${phaseLabel(phaseKey)} 承認`],
      is_milestone: true,
      children: [],
    };
    phaseNode.children.push(milestoneNode);

    cursor += days;
    phaseIdx++;
  }

  return root;
}

function buildAgileWbs(rfp: RfpDna, totalDays: number): WbsNode {
  const sprintLengthDays = 14;
  const sprintCount = Math.max(2, Math.floor(totalDays / sprintLengthDays));
  const root: WbsNode = {
    id: '1',
    level: 1,
    name: 'アジャイルプロジェクト全体',
    duration_days: totalDays,
    start_offset_days: 0,
    end_offset_days: totalDays,
    dependencies: [],
    deliverables: ['全インクリメント'],
    is_milestone: false,
    children: [],
  };

  const setup: WbsNode = {
    id: '1.1',
    level: 2,
    name: 'Sprint 0 - プロジェクト準備',
    duration_days: 7,
    start_offset_days: 0,
    end_offset_days: 7,
    dependencies: [],
    deliverables: ['プロダクトバックログ', 'インセプションデッキ', '開発環境'],
    is_milestone: false,
    children: [],
  };
  root.children.push(setup);

  for (let i = 1; i <= sprintCount; i++) {
    const sprintStart = 7 + (i - 1) * sprintLengthDays;
    const sprint: WbsNode = {
      id: `1.${i + 1}`,
      level: 2,
      name: `Sprint ${i}`,
      duration_days: sprintLengthDays,
      start_offset_days: sprintStart,
      end_offset_days: sprintStart + sprintLengthDays,
      dependencies: [i === 1 ? '1.1' : `1.${i}`],
      deliverables: [`Sprint ${i} 成果物`, 'スプリントレビュー', 'レトロスペクティブ'],
      is_milestone: false,
      children: [
        {
          id: `1.${i + 1}.1`, level: 3, name: 'スプリントプランニング',
          duration_days: 1, start_offset_days: sprintStart, end_offset_days: sprintStart + 1,
          dependencies: [], deliverables: ['スプリントゴール'], is_milestone: false, children: [],
        },
        {
          id: `1.${i + 1}.2`, level: 3, name: '開発+デイリースクラム',
          duration_days: sprintLengthDays - 3, start_offset_days: sprintStart + 1, end_offset_days: sprintStart + sprintLengthDays - 2,
          dependencies: [`1.${i + 1}.1`], deliverables: ['動作するインクリメント'], is_milestone: false, children: [],
        },
        {
          id: `1.${i + 1}.3`, level: 3, name: 'スプリントレビュー',
          duration_days: 1, start_offset_days: sprintStart + sprintLengthDays - 2, end_offset_days: sprintStart + sprintLengthDays - 1,
          dependencies: [`1.${i + 1}.2`], deliverables: ['ステークホルダーレビュー結果'], is_milestone: true, children: [],
        },
        {
          id: `1.${i + 1}.4`, level: 3, name: 'レトロスペクティブ',
          duration_days: 1, start_offset_days: sprintStart + sprintLengthDays - 1, end_offset_days: sprintStart + sprintLengthDays,
          dependencies: [`1.${i + 1}.3`], deliverables: ['改善アクション'], is_milestone: false, children: [],
        },
      ],
    };
    root.children.push(sprint);
  }

  return root;
}

function phaseLabel(key: string): string {
  const labels: Record<string, string> = {
    requirements: '要件定義',
    basic_design: '基本設計',
    detailed_design: '詳細設計',
    implementation: '実装',
    integration_test: '結合テスト',
    acceptance_test: '受入テスト立会',
    deployment: '本番リリース',
    closing: 'プロジェクト終結',
  };
  return labels[key] ?? key;
}

function phaseRole(key: string): string {
  const roles: Record<string, string> = {
    requirements: 'PMシニア + コンサルタント',
    basic_design: 'アーキテクト + リードエンジニア',
    detailed_design: 'リードエンジニア + ミドルエンジニア',
    implementation: 'ミドル + ジュニアエンジニア',
    integration_test: 'テスター + ミドルエンジニア',
    acceptance_test: 'PM + テスター',
    deployment: 'DevOps + リードエンジニア',
    closing: 'PM',
  };
  return roles[key] ?? '';
}

function phaseDeliverables(key: string, rfp: RfpDna): string[] {
  const base: Record<string, string[]> = {
    requirements: ['要件定義書', 'ユースケース図', '業務フロー図'],
    basic_design: ['基本設計書', '画面遷移図', 'システム構成図', 'DB論理ER図', 'API一覧'],
    detailed_design: ['詳細設計書', '画面仕様書', 'API詳細仕様書', 'DBテーブル定義書'],
    implementation: ['ソースコード', 'ユニットテスト', 'コードレビュー記録'],
    integration_test: ['結合テスト計画', '結合テスト仕様書', '結合テスト結果報告書'],
    acceptance_test: ['受入テスト立会記録', '不具合管理表', '検収完了報告書'],
    deployment: ['リリース手順書', '運用手順書', 'バックアップ・復旧手順書'],
    closing: ['プロジェクト完了報告書', '振り返り資料', '保守引継ぎ書'],
  };
  return base[key] ?? rfp.deliverables.slice(0, 3);
}

function buildPhaseTasks(phaseId: string, phaseKey: string, totalDays: number, rfp: RfpDna): WbsNode[] {
  const tasksByPhase: Record<string, string[]> = {
    requirements: ['キックオフミーティング', 'ステークホルダーヒアリング', '業務要件抽出', '非機能要件抽出', '要件定義書作成', '要件定義書レビュー'],
    basic_design: ['システム構成設計', 'DB論理設計', '画面遷移設計', 'API設計', '非機能設計', '基本設計書レビュー'],
    detailed_design: ['画面詳細設計', 'API詳細設計', 'DBテーブル定義', 'バッチ詳細設計', '詳細設計書レビュー'],
    implementation: ['基盤実装', 'コア機能実装', 'API実装', 'UI実装', 'バッチ実装', 'ユニットテスト'],
    integration_test: ['結合テスト計画作成', 'テストデータ準備', '結合テスト実施', '不具合修正', '再テスト'],
    acceptance_test: ['受入テスト準備', '立会・支援', '不具合対応', '検収'],
    deployment: ['本番環境構築', 'データ移行', '本番リリース', '運用引継ぎ'],
    closing: ['プロジェクト完了報告', '振り返り会議', 'ナレッジ共有'],
  };
  const tasks = tasksByPhase[phaseKey] ?? [];
  const taskDays = Math.ceil(totalDays / Math.max(tasks.length, 1));
  return tasks.map((name, i) => ({
    id: `${phaseId}.${i + 1}`,
    level: 3,
    name,
    duration_days: taskDays,
    start_offset_days: i * taskDays,
    end_offset_days: (i + 1) * taskDays,
    dependencies: i > 0 ? [`${phaseId}.${i}`] : [],
    deliverables: [],
    is_milestone: false,
    children: [],
  }));
}

function flattenAndAssignDates(node: WbsNode, parentStart: number): void {
  if (node.children.length > 0) {
    for (const child of node.children) {
      child.start_offset_days += parentStart;
      child.end_offset_days += parentStart;
      flattenAndAssignDates(child, child.start_offset_days);
    }
  }
}

function flatten(node: WbsNode): WbsNode[] {
  const result: WbsNode[] = [node];
  for (const c of node.children) result.push(...flatten(c));
  return result;
}

function computeCriticalPath(flat: WbsNode[]): string[] {
  const sorted = [...flat].sort((a, b) => b.duration_days - a.duration_days);
  return sorted.slice(0, 5).map((n) => n.id);
}

function addDays(dateStr: string, days: number): string {
  const d = new Date(dateStr);
  d.setDate(d.getDate() + days);
  return d.toISOString().slice(0, 10);
}

function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

/**
 * Markdown 形式 (ガントチャート風) で出力
 */
export function formatWbsAsMarkdown(wbs: WbsResult): string {
  const lines: string[] = [];
  lines.push(`# WBS - プロジェクト計画`);
  lines.push('');
  lines.push(`**期間**: ${wbs.meta.project_start} 〜 ${wbs.meta.project_end} (${wbs.meta.total_duration_days}日)`);
  lines.push(`**総工数**: ${wbs.meta.total_effort_md} 人月`);
  lines.push(`**手法**: ${wbs.meta.approach}`);
  lines.push('');
  lines.push(`## マイルストーン`);
  for (const m of wbs.milestones) {
    lines.push(`- **${m.date}**: ${m.name}`);
  }
  lines.push('');
  lines.push(`## WBS Tree`);
  printNode(wbs.root, lines);
  return lines.join('\n');
}

function printNode(node: WbsNode, lines: string[]): void {
  const indent = '  '.repeat(node.level - 1);
  const milestone = node.is_milestone ? ' 🏁' : '';
  lines.push(`${indent}- **${node.id}** ${node.name}${milestone} (${node.duration_days}日)`);
  if (node.deliverables.length) {
    lines.push(`${indent}  - 成果物: ${node.deliverables.join(' / ')}`);
  }
  for (const c of node.children) printNode(c, lines);
}
