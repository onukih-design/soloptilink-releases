/**
 * 単価テーブル - 日本SI市場の標準単価DB (人月)
 *
 * 出典:
 * - 経産省「IT人材白書」2024年度
 * - JISA (情報サービス産業協会) 単価相場
 * - 公共機関単価表 (会計法29条の3準拠)
 *
 * 業界平均値ベース。実際の見積では±20%の調整可能。
 */

export type RoleId =
  | 'pm_senior'
  | 'pm_mid'
  | 'architect'
  | 'lead_eng'
  | 'mid_eng'
  | 'junior_eng'
  | 'tester'
  | 'designer'
  | 'devops'
  | 'security_eng'
  | 'data_eng'
  | 'ml_eng'
  | 'consultant';

export type RateClient = 'standard' | 'enterprise' | 'public_sector' | 'startup';

export interface RoleDefinition {
  id: RoleId;
  name_ja: string;
  name_en: string;
  experience_years_min: number;
  responsibilities: string[];
}

export const ROLES: Record<RoleId, RoleDefinition> = {
  pm_senior: {
    id: 'pm_senior',
    name_ja: 'PMシニア',
    name_en: 'Senior Project Manager',
    experience_years_min: 10,
    responsibilities: ['プロジェクト全体管理', '顧客交渉', 'リスクマネジメント', 'ステアリング委員会'],
  },
  pm_mid: {
    id: 'pm_mid',
    name_ja: 'PMミドル',
    name_en: 'Project Manager',
    experience_years_min: 5,
    responsibilities: ['プロジェクト進行管理', '工程管理', '品質管理', '報告書作成'],
  },
  architect: {
    id: 'architect',
    name_ja: 'アーキテクト',
    name_en: 'Software Architect',
    experience_years_min: 8,
    responsibilities: ['全体アーキテクチャ設計', '技術選定', '非機能要件定義', '技術リーダーシップ'],
  },
  lead_eng: {
    id: 'lead_eng',
    name_ja: 'リードエンジニア',
    name_en: 'Lead Engineer',
    experience_years_min: 5,
    responsibilities: ['技術的リーダー', 'コードレビュー', 'メンタリング', '基本設計'],
  },
  mid_eng: {
    id: 'mid_eng',
    name_ja: 'ミドルエンジニア',
    name_en: 'Mid-level Engineer',
    experience_years_min: 3,
    responsibilities: ['機能実装', '詳細設計', 'ユニットテスト', 'バグ修正'],
  },
  junior_eng: {
    id: 'junior_eng',
    name_ja: 'ジュニアエンジニア',
    name_en: 'Junior Engineer',
    experience_years_min: 0,
    responsibilities: ['機能実装サポート', 'バグ修正', 'ドキュメント作成', 'テスト実行'],
  },
  tester: {
    id: 'tester',
    name_ja: 'テスター/QA',
    name_en: 'QA Engineer',
    experience_years_min: 2,
    responsibilities: ['テスト計画', 'テスト仕様書作成', 'テスト実行', '不具合管理'],
  },
  designer: {
    id: 'designer',
    name_ja: 'UI/UXデザイナー',
    name_en: 'UI/UX Designer',
    experience_years_min: 3,
    responsibilities: ['画面設計', 'ワイヤーフレーム', 'プロトタイプ', 'デザインシステム構築'],
  },
  devops: {
    id: 'devops',
    name_ja: 'DevOpsエンジニア',
    name_en: 'DevOps Engineer',
    experience_years_min: 4,
    responsibilities: ['CI/CD構築', 'インフラ構築', '監視/ログ設計', '本番運用'],
  },
  security_eng: {
    id: 'security_eng',
    name_ja: 'セキュリティエンジニア',
    name_en: 'Security Engineer',
    experience_years_min: 5,
    responsibilities: ['セキュリティ要件定義', '脆弱性診断', 'ペネトレーションテスト', '監査対応'],
  },
  data_eng: {
    id: 'data_eng',
    name_ja: 'データエンジニア',
    name_en: 'Data Engineer',
    experience_years_min: 4,
    responsibilities: ['DB設計', 'ETL構築', 'データ分析基盤', 'データパイプライン'],
  },
  ml_eng: {
    id: 'ml_eng',
    name_ja: 'MLエンジニア',
    name_en: 'Machine Learning Engineer',
    experience_years_min: 4,
    responsibilities: ['ML/AI実装', 'モデル学習', '推論基盤', 'MLOps'],
  },
  consultant: {
    id: 'consultant',
    name_ja: 'ITコンサルタント',
    name_en: 'IT Consultant',
    experience_years_min: 7,
    responsibilities: ['業務分析', 'BPR', 'IT戦略立案', 'PMO支援'],
  },
};

/**
 * 単価テーブル (円/人月) - 2026年度標準
 */
export const RATE_TABLE: Record<RoleId, Record<RateClient, number>> = {
  pm_senior:    { standard: 1_400_000, enterprise: 1_700_000, public_sector: 2_000_000, startup: 1_200_000 },
  pm_mid:       { standard: 1_100_000, enterprise: 1_300_000, public_sector: 1_500_000, startup: 950_000 },
  architect:    { standard: 1_500_000, enterprise: 1_800_000, public_sector: 2_100_000, startup: 1_300_000 },
  lead_eng:     { standard:   950_000, enterprise: 1_200_000, public_sector: 1_400_000, startup: 850_000 },
  mid_eng:      { standard:   800_000, enterprise:   950_000, public_sector: 1_100_000, startup: 700_000 },
  junior_eng:   { standard:   600_000, enterprise:   700_000, public_sector:   800_000, startup: 550_000 },
  tester:       { standard:   700_000, enterprise:   850_000, public_sector:   950_000, startup: 650_000 },
  designer:     { standard:   800_000, enterprise:   950_000, public_sector: 1_050_000, startup: 700_000 },
  devops:       { standard:   950_000, enterprise: 1_150_000, public_sector: 1_300_000, startup: 850_000 },
  security_eng: { standard: 1_200_000, enterprise: 1_500_000, public_sector: 1_800_000, startup: 1_100_000 },
  data_eng:     { standard:   950_000, enterprise: 1_150_000, public_sector: 1_300_000, startup: 850_000 },
  ml_eng:       { standard: 1_100_000, enterprise: 1_400_000, public_sector: 1_600_000, startup: 1_000_000 },
  consultant:   { standard: 1_500_000, enterprise: 1_900_000, public_sector: 2_200_000, startup: 1_300_000 },
};

/**
 * 業種別工数係数 (基準=1.0)
 */
export const INDUSTRY_EFFORT_MULTIPLIER: Record<string, number> = {
  construction: 1.20,    // 工事台帳/積算複雑
  manufacturing: 1.10,    // EDI/MRP統合
  healthcare: 1.50,       // 3省2GL/レセプト/HPKI
  longterm_care: 1.40,    // 介護報酬/LIFE
  real_estate: 1.20,      // 35条書面/レインズ
  professional: 1.25,     // 士業特有業務
  retail: 1.05,           // POS/在庫
  food_service: 1.05,     // POS/HACCP
  transport: 1.15,        // 運送業/改善基準告示
  it: 1.00,               // 標準
  finance: 1.50,          // FISC/全銀/反社チェック
  public_sector: 1.60,    // 入札/標準ガイドライン
  education: 1.20,        // 学籍/SCORM/LTI
  hotel: 1.10,            // 旅館業法/民泊
  agriculture: 1.10,      // GAP/トレーサビリティ
  default: 1.00,
};

/**
 * 規模別工数係数 (基準=medium)
 */
export const SCALE_EFFORT_MULTIPLIER: Record<string, number> = {
  small: 0.5,        // 小規模 (〜50人/〜10万件)
  medium: 1.0,       // 中規模 (〜500人/〜100万件)
  large: 1.8,        // 大規模 (〜5000人/〜1000万件)
  enterprise: 3.0,   // エンタープライズ (5000人+/1000万件+)
};

export function getRate(role: RoleId, client: RateClient = 'standard'): number {
  return RATE_TABLE[role][client];
}

export function getRoleByExperience(years: number): RoleId {
  if (years >= 10) return 'pm_senior';
  if (years >= 8) return 'architect';
  if (years >= 5) return 'lead_eng';
  if (years >= 3) return 'mid_eng';
  return 'junior_eng';
}

/**
 * 諸経費比率 (材料費/旅費/通信費/管理費含む)
 */
export const EXPENSE_RATIO = {
  standard: 0.10,
  enterprise: 0.12,
  public_sector: 0.15,
  startup: 0.08,
} as const;

/**
 * 一般管理費比率
 */
export const GENERAL_ADMIN_RATIO = {
  standard: 0.08,
  enterprise: 0.10,
  public_sector: 0.12,
  startup: 0.05,
} as const;
