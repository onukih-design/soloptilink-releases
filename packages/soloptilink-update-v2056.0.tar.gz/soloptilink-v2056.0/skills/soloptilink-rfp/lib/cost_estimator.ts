/**
 * 概算見積生成 - RFP-DNA から日本SI標準フォーマットの見積を生成
 *
 * 出力: フェーズ別工数 + 単価 + 内訳明細 + 諸経費 + 消費税 + 総合計
 */

import type { RfpDna } from './rfp_parser';
import {
  RATE_TABLE,
  INDUSTRY_EFFORT_MULTIPLIER,
  SCALE_EFFORT_MULTIPLIER,
  EXPENSE_RATIO,
  GENERAL_ADMIN_RATIO,
  type RateClient,
  type RoleId,
  ROLES,
} from './rate_table';

export interface PhaseEstimate {
  phase_id: string;
  phase_name_ja: string;
  duration_weeks: number;
  members: { role: RoleId; allocation: number }[];
  effort_man_months: number;
  rate_blended: number;
  amount: number;
  description: string;
}

export interface EstimateResult {
  meta: {
    generated_at: string;
    rfp_source: string | null;
    industry?: string;
    scale: string;
    rate_client: RateClient;
    currency: 'JPY';
  };
  phases: PhaseEstimate[];
  subtotal: number;
  expenses: { ratio: number; amount: number };
  general_admin: { ratio: number; amount: number };
  total_before_tax: number;
  tax: { rate: number; amount: number };
  total_with_tax: number;
  payment_terms: {
    schedule: { milestone: string; ratio: number; amount: number }[];
    note: string;
  };
  validity_days: number;
  notes: string[];
}

export interface GenerateEstimateInput {
  rfp: RfpDna;
  rate_client?: RateClient;
  approach?: 'waterfall' | 'agile' | 'hybrid';
  team_size?: number;
  validity_days?: number;
  custom_phase_factors?: Partial<Record<string, number>>;
}

const DEFAULT_PHASE_FACTORS = {
  requirements: 0.10,
  basic_design: 0.15,
  detailed_design: 0.15,
  implementation: 0.35,
  integration_test: 0.12,
  acceptance_test: 0.05,
  deployment: 0.05,
  pm_overhead: 0.08,
} as const;

const PHASE_LABELS: Record<keyof typeof DEFAULT_PHASE_FACTORS, string> = {
  requirements: '要件定義',
  basic_design: '基本設計',
  detailed_design: '詳細設計',
  implementation: '実装',
  integration_test: '結合テスト',
  acceptance_test: '受入テスト立会',
  deployment: '本番リリース',
  pm_overhead: 'PM/品質管理',
};

const PHASE_TEAM_COMPOSITION: Record<keyof typeof DEFAULT_PHASE_FACTORS, { role: RoleId; allocation: number }[]> = {
  requirements: [
    { role: 'pm_senior', allocation: 0.5 },
    { role: 'consultant', allocation: 0.5 },
    { role: 'architect', allocation: 0.5 },
  ],
  basic_design: [
    { role: 'architect', allocation: 1.0 },
    { role: 'lead_eng', allocation: 1.0 },
    { role: 'designer', allocation: 0.5 },
  ],
  detailed_design: [
    { role: 'lead_eng', allocation: 1.0 },
    { role: 'mid_eng', allocation: 1.5 },
    { role: 'designer', allocation: 0.3 },
  ],
  implementation: [
    { role: 'lead_eng', allocation: 0.5 },
    { role: 'mid_eng', allocation: 2.0 },
    { role: 'junior_eng', allocation: 1.0 },
  ],
  integration_test: [
    { role: 'tester', allocation: 1.5 },
    { role: 'mid_eng', allocation: 0.5 },
    { role: 'devops', allocation: 0.3 },
  ],
  acceptance_test: [
    { role: 'pm_mid', allocation: 0.7 },
    { role: 'tester', allocation: 0.5 },
  ],
  deployment: [
    { role: 'devops', allocation: 1.0 },
    { role: 'lead_eng', allocation: 0.5 },
  ],
  pm_overhead: [
    { role: 'pm_senior', allocation: 0.3 },
    { role: 'pm_mid', allocation: 0.5 },
  ],
};

const BASE_EFFORT_MM_BY_SCALE = {
  small: 6,
  medium: 18,
  large: 48,
  enterprise: 120,
} as const;

export function generateEstimate(input: GenerateEstimateInput): EstimateResult {
  const { rfp } = input;
  const rate_client: RateClient = input.rate_client ?? mapClientType(rfp.meta.client_type);
  const industry = rfp.meta.industry ?? 'default';
  const scale = rfp.meta.scale;

  const baseEffort = BASE_EFFORT_MM_BY_SCALE[scale];
  const industryMul = INDUSTRY_EFFORT_MULTIPLIER[industry] ?? INDUSTRY_EFFORT_MULTIPLIER.default;
  const scaleMul = SCALE_EFFORT_MULTIPLIER[scale];
  const implicitMul = 1.0 + Math.min(rfp.implicit_requirements.length * 0.02, 0.30);
  const riskMul = 1.0 + Math.min(rfp.risks.filter((r) => r.impact === 'high').length * 0.05, 0.25);
  const totalEffort = baseEffort * industryMul * scaleMul * implicitMul * riskMul;

  const phases: PhaseEstimate[] = [];
  for (const [phaseKey, factor] of Object.entries(DEFAULT_PHASE_FACTORS) as [keyof typeof DEFAULT_PHASE_FACTORS, number][]) {
    const phaseEffort = totalEffort * (input.custom_phase_factors?.[phaseKey] ?? factor);
    const members = PHASE_TEAM_COMPOSITION[phaseKey];
    const blendedRate = calculateBlendedRate(members, rate_client);
    phases.push({
      phase_id: phaseKey,
      phase_name_ja: PHASE_LABELS[phaseKey],
      duration_weeks: Math.ceil(phaseEffort * 4 / Math.max(members.reduce((s, m) => s + m.allocation, 0), 1)),
      members,
      effort_man_months: round1(phaseEffort),
      rate_blended: blendedRate,
      amount: Math.round(phaseEffort * blendedRate),
      description: PHASE_DESCRIPTIONS[phaseKey],
    });
  }

  const subtotal = phases.reduce((s, p) => s + p.amount, 0);
  const expenseRatio = EXPENSE_RATIO[rate_client];
  const adminRatio = GENERAL_ADMIN_RATIO[rate_client];
  const expenses = Math.round(subtotal * expenseRatio);
  const general_admin = Math.round(subtotal * adminRatio);
  const total_before_tax = subtotal + expenses + general_admin;
  const tax_rate = 0.10;
  const tax_amount = Math.round(total_before_tax * tax_rate);
  const total_with_tax = total_before_tax + tax_amount;

  return {
    meta: {
      generated_at: new Date().toISOString(),
      rfp_source: rfp.meta.source_path,
      industry,
      scale,
      rate_client,
      currency: 'JPY',
    },
    phases,
    subtotal,
    expenses: { ratio: expenseRatio, amount: expenses },
    general_admin: { ratio: adminRatio, amount: general_admin },
    total_before_tax,
    tax: { rate: tax_rate, amount: tax_amount },
    total_with_tax,
    payment_terms: buildPaymentTerms(total_with_tax, rate_client),
    validity_days: input.validity_days ?? 30,
    notes: buildNotes(rfp, rate_client),
  };
}

function calculateBlendedRate(
  members: { role: RoleId; allocation: number }[],
  client: RateClient
): number {
  const totalAllocation = members.reduce((s, m) => s + m.allocation, 0);
  if (totalAllocation === 0) return 0;
  const weightedSum = members.reduce(
    (s, m) => s + RATE_TABLE[m.role][client] * m.allocation,
    0
  );
  return Math.round(weightedSum / totalAllocation);
}

function mapClientType(clientType: string): RateClient {
  switch (clientType) {
    case '公共':
    case '自治体': return 'public_sector';
    default: return 'standard';
  }
}

function buildPaymentTerms(total: number, client: RateClient): EstimateResult['payment_terms'] {
  if (client === 'public_sector') {
    return {
      schedule: [
        { milestone: '検収完了後', ratio: 1.0, amount: total },
      ],
      note: '会計法29条の3 / 政府契約の支払遅延防止等に関する法律準拠 (検収後30日以内)',
    };
  }
  return {
    schedule: [
      { milestone: '契約締結時 (着手金)', ratio: 0.30, amount: Math.round(total * 0.30) },
      { milestone: '基本設計完了時', ratio: 0.30, amount: Math.round(total * 0.30) },
      { milestone: '本番リリース・検収完了時', ratio: 0.40, amount: Math.round(total * 0.40) },
    ],
    note: '下請法第2条の2準拠 (受領後60日以内)',
  };
}

function buildNotes(rfp: RfpDna, client: RateClient): string[] {
  const notes: string[] = [];
  notes.push('本見積は概算見積です。詳細要件確定後に精算見積を提出します。');
  notes.push('消費税率は2026年4月時点 (10%) です。法改正により変動の可能性があります。');
  notes.push(`本見積の有効期限は発行日から30日間です。`);
  if (rfp.implicit_requirements.length > 0) {
    notes.push(`暗黙要件 ${rfp.implicit_requirements.length} 件を反映した工数となっています (詳細は内訳参照)。`);
  }
  if (rfp.risks.filter((r) => r.impact === 'high').length > 0) {
    notes.push('高インパクトリスク検出のため、リスクバッファを工数に含めています。');
  }
  if (client === 'public_sector') {
    notes.push('公共機関向け単価表 (会計法29条の3) を適用しています。');
  }
  notes.push('お客様支給品(既存システム/サーバ等)による工数増減は別途協議とさせていただきます。');
  return notes;
}

const PHASE_DESCRIPTIONS: Record<keyof typeof DEFAULT_PHASE_FACTORS, string> = {
  requirements: 'ステークホルダーヒアリング、業務分析、機能要件・非機能要件確定、要件定義書作成・レビュー',
  basic_design: 'システム全体構成、画面遷移、機能分割、DB論理設計、API設計、基本設計書作成',
  detailed_design: '画面詳細仕様、機能詳細仕様、DBテーブル定義、API詳細仕様、詳細設計書作成',
  implementation: 'ソースコード実装、ユニットテスト、コードレビュー、結合準備',
  integration_test: '結合テスト計画、結合テスト実施、不具合修正、システムテスト',
  acceptance_test: '受入テスト計画作成、受入テスト立会、不具合管理、検収',
  deployment: '本番環境構築、データ移行、リリース作業、運用引継ぎ',
  pm_overhead: 'プロジェクト全体管理、進捗管理、品質管理、リスク管理、ステアリング委員会対応',
};

function round1(n: number): number {
  return Math.round(n * 10) / 10;
}

/**
 * 見積結果をMarkdownの見積書として整形
 */
export function formatEstimateAsMarkdown(estimate: EstimateResult, companyName = '貴社御中'): string {
  const lines: string[] = [];
  lines.push(`# お見積書`);
  lines.push('');
  lines.push(`**${companyName}**`);
  lines.push('');
  lines.push(`発行日: ${new Date().toISOString().slice(0, 10)}`);
  lines.push(`有効期限: 発行日から${estimate.validity_days}日`);
  lines.push(`通貨: ${estimate.meta.currency}`);
  lines.push('');
  lines.push(`## 内訳`);
  lines.push('');
  lines.push(`| フェーズ | 工数 (人月) | 単価 (円) | 金額 (円) |`);
  lines.push(`|---------|------------|----------|----------|`);
  for (const p of estimate.phases) {
    lines.push(
      `| ${p.phase_name_ja} | ${p.effort_man_months} | ${p.rate_blended.toLocaleString()} | ${p.amount.toLocaleString()} |`
    );
  }
  lines.push(`| **小計** | | | **${estimate.subtotal.toLocaleString()}** |`);
  lines.push(`| 諸経費 (${(estimate.expenses.ratio * 100).toFixed(0)}%) | | | ${estimate.expenses.amount.toLocaleString()} |`);
  lines.push(`| 一般管理費 (${(estimate.general_admin.ratio * 100).toFixed(0)}%) | | | ${estimate.general_admin.amount.toLocaleString()} |`);
  lines.push(`| **合計 (税抜)** | | | **${estimate.total_before_tax.toLocaleString()}** |`);
  lines.push(`| 消費税 (${(estimate.tax.rate * 100).toFixed(0)}%) | | | ${estimate.tax.amount.toLocaleString()} |`);
  lines.push(`| **総合計 (税込)** | | | **¥${estimate.total_with_tax.toLocaleString()}** |`);
  lines.push('');
  lines.push(`## 支払条件`);
  for (const s of estimate.payment_terms.schedule) {
    lines.push(`- ${s.milestone}: ¥${s.amount.toLocaleString()} (${(s.ratio * 100).toFixed(0)}%)`);
  }
  lines.push(`> ${estimate.payment_terms.note}`);
  lines.push('');
  lines.push(`## 備考`);
  for (const n of estimate.notes) {
    lines.push(`- ${n}`);
  }
  return lines.join('\n');
}
