/**
 * RFP/RFI Parser - 日本SI受託開発のRFPを読み込み、構造化データに変換
 *
 * 対応フォーマット: .pdf / .docx / .xlsx / .md / inline_text
 * 抽出項目: goal / scope / constraints / deliverables / deadline / budget_hint /
 *           evaluators / risks / implicit_requirements
 */

export type RfpClientType = '民間' | '公共' | '自治体';
export type RfpScale = 'small' | 'medium' | 'large' | 'enterprise';

export interface RfpDna {
  meta: {
    source_path: string | null;
    parsed_at: string;
    source_type: 'pdf' | 'docx' | 'xlsx' | 'md' | 'inline_text';
    industry?: string;
    industry_ja?: string;
    client_type: RfpClientType;
    scale: RfpScale;
  };
  goal: {
    primary: string;
    business_drivers: string[];
    success_metrics: string[];
  };
  scope: {
    in_scope: string[];
    out_of_scope: string[];
    target_users: string[];
    expected_data_volume?: string;
  };
  constraints: {
    technical: string[];
    legal: string[];
    budget?: number;
    deadline?: string;
    existing_assets?: string[];
  };
  deliverables: string[];
  deadline?: {
    start?: string;
    end?: string;
    milestones: { name: string; date: string }[];
  };
  budget_hint?: {
    explicit?: number;
    estimated_range?: { min: number; max: number };
    currency: 'JPY' | 'USD';
  };
  evaluators: string[];
  implicit_requirements: ImplicitRequirement[];
  risks: RiskItem[];
}

export interface ImplicitRequirement {
  trigger_keyword: string;
  inferred_features: string[];
  rationale: string;
  priority: 'P0' | 'P1' | 'P2';
}

export interface RiskItem {
  category: 'schedule' | 'requirement' | 'technical' | 'cost' | 'organization' | 'legal';
  description: string;
  likelihood: 'low' | 'medium' | 'high';
  impact: 'low' | 'medium' | 'high';
  mitigation: string;
}

const IMPLICIT_KEYWORD_MAP: Record<string, { features: string[]; priority: 'P0' | 'P1' | 'P2' }> = {
  ログイン: {
    features: ['MFA (TOTP/SMS)', 'SSO (SAML/OIDC)', 'パスワード強度ポリシ', 'アカウントロック (5回失敗)', 'パスワードリセット導線'],
    priority: 'P0',
  },
  認証: {
    features: ['JWT/Session 認証', '権限管理 (RBAC)', '監査ログ', 'セッションタイムアウト'],
    priority: 'P0',
  },
  ダッシュボード: {
    features: ['KPI集計', 'グラフ可視化 (Recharts/Chart.js)', '期間フィルタ', 'CSVエクスポート', 'リアルタイム更新'],
    priority: 'P1',
  },
  検索: {
    features: ['全文検索 (PostgreSQL FTS / Meilisearch)', '絞り込みフィルタ', 'ソート', 'ページネーション'],
    priority: 'P1',
  },
  通知: {
    features: ['メール通知 (SendGrid/SES)', 'プッシュ通知', 'Slack連携', '通知履歴'],
    priority: 'P1',
  },
  監視: {
    features: ['ヘルスチェック (/api/health)', 'メトリクス (Prometheus)', 'ログ集約 (CloudWatch/Datadog)', 'アラート (PagerDuty)', 'SLO定義 (99.9%)'],
    priority: 'P0',
  },
  セキュリティ: {
    features: ['OWASP Top 10対策', 'CSP/HSTS', 'SQLインジェクション対策 (Prisma)', 'XSS対策', '暗号化 (TLS 1.3 + AES-256)', '監査ログ'],
    priority: 'P0',
  },
  バックアップ: {
    features: ['日次自動バックアップ', '7日間保管', '復旧手順書', 'リストア訓練 (年1回)'],
    priority: 'P0',
  },
  CSV: {
    features: ['UTF-8 BOM付エクスポート', '文字化け防止', 'Excel直接展開対応', '取込バリデーション'],
    priority: 'P1',
  },
  帳票: {
    features: ['PDF生成 (Puppeteer/PDFKit)', '印影/封筒窓対応', '消費税/インボイス番号', '社印スタンプ'],
    priority: 'P0',
  },
  決裁: {
    features: ['ワークフロー (3〜5段階)', '差戻し', '代理承認', '監査ログ', '稟議書テンプレ'],
    priority: 'P1',
  },
  在庫: {
    features: ['在庫CRUD', 'ロケーション管理', '入出庫履歴', '棚卸し機能', '発注点アラート'],
    priority: 'P0',
  },
  受発注: {
    features: ['注文書/受注書発行', '発注先マスタ', '納期管理', '出荷指示', '入荷検収'],
    priority: 'P0',
  },
  請求: {
    features: ['請求書発行 (インボイス対応)', '締日処理', '消費税計算 (8%/10%)', '電帳法対応 (タイムスタンプ)', '入金消込'],
    priority: 'P0',
  },
  顧客管理: {
    features: ['顧客マスタCRUD', '取引履歴', 'コンタクト履歴', 'メモ', 'タグ分類'],
    priority: 'P1',
  },
  モバイル: {
    features: ['レスポンシブUI', 'PWA対応', 'オフライン入力', '写真添付', 'プッシュ通知'],
    priority: 'P1',
  },
  オフライン: {
    features: ['Service Worker', 'IndexedDB ローカル保存', '同期キュー', 'コンフリクト解消'],
    priority: 'P1',
  },
  多言語: {
    features: ['i18n (next-intl/react-i18next)', 'ja/en/zh-CN対応', '日付/通貨/敬語の地域化'],
    priority: 'P2',
  },
  アクセシビリティ: {
    features: ['WCAG 2.2 AA準拠', 'キーボード操作', 'スクリーンリーダー対応', 'フォーカス可視化'],
    priority: 'P1',
  },
};

const RISK_DETECTION_RULES: Array<{ pattern: RegExp; risk: Omit<RiskItem, 'description'> & { template: string } }> = [
  {
    pattern: /短期|急ぎ|至急|前倒し|リリース.*日|納期.*厳/,
    risk: {
      category: 'schedule',
      likelihood: 'high',
      impact: 'high',
      mitigation: 'マイルストーン明確化 + 週次進捗会議 + バッファ20%確保 + クリティカルパス監視',
      template: 'スケジュール過密 (RFP記載「{matched}」より検出)',
    },
  },
  {
    pattern: /検討中|未定|追って|相談|柔軟/,
    risk: {
      category: 'requirement',
      likelihood: 'high',
      impact: 'medium',
      mitigation: 'Pre-Flight要件定義フェーズ追加 + Visual Confirm Loop (ER図/画面遷移確認) + 変更管理プロセス導入',
      template: '要件曖昧 (RFP記載「{matched}」より検出)',
    },
  },
  {
    pattern: /既存.*(連携|統合|移行)|レガシー|資産活用/,
    risk: {
      category: 'technical',
      likelihood: 'medium',
      impact: 'high',
      mitigation: '既存システム調査フェーズ追加 + IF仕様書整備 + データ移行リハーサル + ロールバック手順',
      template: '既存資産連携リスク (RFP記載「{matched}」より検出)',
    },
  },
  {
    pattern: /個人情報|機微情報|要配慮|医療|金融/,
    risk: {
      category: 'legal',
      likelihood: 'medium',
      impact: 'high',
      mitigation: '個情法第26条遵守 + 暗号化 + 監査ログWORM保存 + 漏えい時5日報告体制 + Pマーク/ISMS取得検討',
      template: '個人情報リスク (RFP記載「{matched}」より検出)',
    },
  },
  {
    pattern: /公共|自治体|官公庁|入札|総合評価/,
    risk: {
      category: 'organization',
      likelihood: 'medium',
      impact: 'medium',
      mitigation: '会計法29条の3準拠 + 全省庁統一資格確認 + 検査調書整備 + デジタル庁標準ガイドライン参照',
      template: '公共調達リスク (RFP記載「{matched}」より検出)',
    },
  },
];

export interface ParseRfpInput {
  source: string;
  industry?: string;
  client_type?: RfpClientType;
  scale?: RfpScale;
  inline_text?: string;
}

/**
 * RFP/RFI を読み込み構造化
 *
 * 注: 実際のPDF/DOCX読み込みは外部ライブラリ (pdf-parse / mammoth) に委譲。
 *      このモジュールでは抽出ロジックの中核 (キーワードマッピング+リスク検出) を提供。
 */
export function parseRfpFromText(text: string, opts: Partial<ParseRfpInput> = {}): RfpDna {
  const now = new Date().toISOString();
  const industry = opts.industry;
  const client_type = opts.client_type ?? '民間';
  const scale = opts.scale ?? inferScale(text);

  const goal = extractGoal(text);
  const scope = extractScope(text);
  const constraints = extractConstraints(text);
  const deliverables = extractDeliverables(text);
  const deadline = extractDeadline(text);
  const budget_hint = extractBudgetHint(text);
  const evaluators = extractEvaluators(text);
  const implicit_requirements = extractImplicitRequirements(text);
  const risks = detectRisks(text);

  return {
    meta: {
      source_path: opts.source ?? null,
      parsed_at: now,
      source_type: 'inline_text',
      industry,
      industry_ja: industry ? translateIndustry(industry) : undefined,
      client_type,
      scale,
    },
    goal,
    scope,
    constraints,
    deliverables,
    deadline,
    budget_hint,
    evaluators,
    implicit_requirements,
    risks,
  };
}

function inferScale(text: string): RfpScale {
  const length = text.length;
  const userCount = extractUserCount(text);
  const dataVolume = extractDataVolumeHint(text);
  if (userCount > 5000 || length > 15000) return 'enterprise';
  if (userCount > 500 || length > 5000) return 'large';
  if (userCount > 50 || length > 1500) return 'medium';
  return 'small';
}

function extractUserCount(text: string): number {
  const m = text.match(/(\d{1,6})\s*(名|人|ユーザ|アカウント|社員)/);
  return m ? parseInt(m[1], 10) : 0;
}

function extractDataVolumeHint(text: string): string | undefined {
  const m = text.match(/(\d{1,6})\s*(件|レコード|GB|TB)/);
  return m ? m[0] : undefined;
}

function extractGoal(text: string): RfpDna['goal'] {
  const goalMatch = text.match(/(?:目的|ゴール|狙い)[：:][^\n。]+/);
  const primary = goalMatch ? goalMatch[0].replace(/^.*?[：:]/, '').trim() : 'システム化による業務効率向上';
  const drivers = extractList(text, /(?:背景|課題|問題)[：:]([\s\S]*?)(?=\n\n|\n[一-龯]+[：:]|$)/);
  const metrics = extractList(text, /(?:KPI|成功指標|測定)[：:]([\s\S]*?)(?=\n\n|\n[一-龯]+[：:]|$)/);
  return {
    primary,
    business_drivers: drivers.length ? drivers : ['業務効率化', 'コスト削減', '品質向上'],
    success_metrics: metrics.length ? metrics : ['処理時間50%削減', 'エラー率1%以下', 'ユーザ満足度80%以上'],
  };
}

function extractScope(text: string): RfpDna['scope'] {
  const inScope = extractList(text, /(?:対象|スコープ|範囲)[：:]([\s\S]*?)(?=\n\n|\n[一-龯]+[：:]|$)/);
  const outOfScope = extractList(text, /(?:対象外|スコープ外|除外)[：:]([\s\S]*?)(?=\n\n|\n[一-龯]+[：:]|$)/);
  const targetUsers = extractList(text, /(?:利用者|対象ユーザ|エンドユーザ)[：:]([\s\S]*?)(?=\n\n|\n[一-龯]+[：:]|$)/);
  return {
    in_scope: inScope.length ? inScope : ['業務システムの開発・導入'],
    out_of_scope: outOfScope,
    target_users: targetUsers.length ? targetUsers : ['社内ユーザ'],
    expected_data_volume: extractDataVolumeHint(text),
  };
}

function extractConstraints(text: string): RfpDna['constraints'] {
  return {
    technical: extractList(text, /(?:技術.*制約|技術要件)[：:]([\s\S]*?)(?=\n\n|\n[一-龯]+[：:]|$)/),
    legal: extractList(text, /(?:法令|規制|コンプライアンス)[：:]([\s\S]*?)(?=\n\n|\n[一-龯]+[：:]|$)/),
    budget: extractBudgetAmount(text),
    deadline: extractDeadlineString(text),
    existing_assets: extractList(text, /(?:既存システム|既存資産)[：:]([\s\S]*?)(?=\n\n|\n[一-龯]+[：:]|$)/),
  };
}

function extractDeliverables(text: string): string[] {
  const list = extractList(text, /(?:成果物|納品物|デリバラブル)[：:]([\s\S]*?)(?=\n\n|\n[一-龯]+[：:]|$)/);
  if (list.length) return list;
  return ['要件定義書', '基本設計書', '詳細設計書', 'ソースコード', 'テスト仕様書/結果報告書', '運用手順書', '研修資料'];
}

function extractDeadline(text: string): RfpDna['deadline'] {
  const start = text.match(/(?:着手|開始)[：:]?\s*(\d{4}[\/\-年]\d{1,2}[\/\-月]?\d{0,2}[日]?)/);
  const end = text.match(/(?:納期|完了|リリース)[：:]?\s*(\d{4}[\/\-年]\d{1,2}[\/\-月]?\d{0,2}[日]?)/);
  return {
    start: start ? start[1] : undefined,
    end: end ? end[1] : undefined,
    milestones: [],
  };
}

function extractDeadlineString(text: string): string | undefined {
  const m = text.match(/(?:納期|期限|完了予定)[：:]?\s*([^\n。]+)/);
  return m ? m[1].trim() : undefined;
}

function extractBudgetHint(text: string): RfpDna['budget_hint'] | undefined {
  const explicit = extractBudgetAmount(text);
  if (explicit) {
    return { explicit, currency: 'JPY' };
  }
  return undefined;
}

function extractBudgetAmount(text: string): number | undefined {
  const m = text.match(/(?:予算|金額|費用)[：:]?\s*(?:約)?\s*([0-9,]+)\s*(円|万円|億円)/);
  if (!m) return undefined;
  const num = parseInt(m[1].replace(/,/g, ''), 10);
  switch (m[2]) {
    case '万円': return num * 10000;
    case '億円': return num * 100000000;
    default: return num;
  }
}

function extractEvaluators(text: string): string[] {
  const list = extractList(text, /(?:評価者|決裁者|意思決定)[：:]([\s\S]*?)(?=\n\n|\n[一-龯]+[：:]|$)/);
  if (list.length) return list;
  return ['情報システム部', '事業部門責任者'];
}

function extractImplicitRequirements(text: string): ImplicitRequirement[] {
  const result: ImplicitRequirement[] = [];
  for (const [keyword, info] of Object.entries(IMPLICIT_KEYWORD_MAP)) {
    if (text.includes(keyword)) {
      result.push({
        trigger_keyword: keyword,
        inferred_features: info.features,
        rationale: `RFPに「${keyword}」の記載があり、業界標準として以下の機能群が暗黙的に要求される`,
        priority: info.priority,
      });
    }
  }
  return result;
}

function detectRisks(text: string): RiskItem[] {
  const risks: RiskItem[] = [];
  for (const rule of RISK_DETECTION_RULES) {
    const m = text.match(rule.pattern);
    if (m) {
      risks.push({
        category: rule.risk.category,
        description: rule.risk.template.replace('{matched}', m[0]),
        likelihood: rule.risk.likelihood,
        impact: rule.risk.impact,
        mitigation: rule.risk.mitigation,
      });
    }
  }
  return risks;
}

function extractList(text: string, pattern: RegExp): string[] {
  const m = text.match(pattern);
  if (!m) return [];
  return m[1]
    .split(/\n|・|◆|■|●|◯|\*|-/)
    .map((s) => s.trim())
    .filter((s) => s.length > 0 && s.length < 200);
}

function translateIndustry(industry: string): string {
  const map: Record<string, string> = {
    construction: '建設業',
    manufacturing: '製造業',
    healthcare: '医療',
    longterm_care: '介護',
    real_estate: '不動産業',
    professional: '士業',
    retail: '小売業',
    food_service: '飲食業',
    transport: '運輸業',
    it: 'IT/SES',
    finance: '金融',
    public_sector: '公共/自治体',
    education: '教育',
    hotel: '宿泊',
    agriculture: '農業',
  };
  return map[industry] ?? industry;
}

/**
 * RFP-DNA をMarkdown形式で出力 (提案書ドラフト・人間レビュー用)
 */
export function formatRfpDnaAsMarkdown(rfp: RfpDna): string {
  const lines: string[] = [];
  lines.push(`# RFP-DNA 抽出結果`);
  lines.push('');
  lines.push(`**抽出日時**: ${rfp.meta.parsed_at}`);
  lines.push(`**業種**: ${rfp.meta.industry_ja ?? '指定なし'} / **顧客タイプ**: ${rfp.meta.client_type} / **規模**: ${rfp.meta.scale}`);
  lines.push('');
  lines.push(`## 目的`);
  lines.push(`- **主目的**: ${rfp.goal.primary}`);
  lines.push(`- **背景課題**: ${rfp.goal.business_drivers.join(' / ')}`);
  lines.push(`- **成功指標**: ${rfp.goal.success_metrics.join(' / ')}`);
  lines.push('');
  lines.push(`## スコープ`);
  lines.push(`- **対象**: ${rfp.scope.in_scope.join(' / ')}`);
  if (rfp.scope.out_of_scope.length) lines.push(`- **対象外**: ${rfp.scope.out_of_scope.join(' / ')}`);
  lines.push(`- **利用者**: ${rfp.scope.target_users.join(' / ')}`);
  if (rfp.scope.expected_data_volume) lines.push(`- **データ量**: ${rfp.scope.expected_data_volume}`);
  lines.push('');
  lines.push(`## 制約`);
  if (rfp.constraints.technical.length) lines.push(`- **技術**: ${rfp.constraints.technical.join(' / ')}`);
  if (rfp.constraints.legal.length) lines.push(`- **法令**: ${rfp.constraints.legal.join(' / ')}`);
  if (rfp.constraints.budget) lines.push(`- **予算**: ¥${rfp.constraints.budget.toLocaleString()}`);
  if (rfp.constraints.deadline) lines.push(`- **納期**: ${rfp.constraints.deadline}`);
  lines.push('');
  lines.push(`## 暗黙要件 (自動抽出 ${rfp.implicit_requirements.length}件)`);
  for (const r of rfp.implicit_requirements) {
    lines.push(`- **${r.trigger_keyword}** [${r.priority}]: ${r.inferred_features.join(' / ')}`);
  }
  lines.push('');
  lines.push(`## リスク (${rfp.risks.length}件)`);
  for (const r of rfp.risks) {
    lines.push(`- **[${r.category}]** ${r.description} (発生:${r.likelihood} / 影響:${r.impact})`);
    lines.push(`  - 対策: ${r.mitigation}`);
  }
  return lines.join('\n');
}
