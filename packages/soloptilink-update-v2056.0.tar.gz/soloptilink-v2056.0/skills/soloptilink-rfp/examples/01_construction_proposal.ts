/**
 * 例題1: 建設業向け工事原価管理システムの提案一式生成
 *
 * 実行: bun run examples/01_construction_proposal.ts
 *       node --import tsx examples/01_construction_proposal.ts
 */

import { generateFullPackage } from '../lib/index';

const rfpText = `
【RFP】工事原価管理システム導入

目的: 工事原価のリアルタイム把握とキャッシュフロー改善
背景: 現在Excelで管理しており、月次集計に1週間かかる。粗利率が見えにくい。
KPI: 月次集計時間を1日以内へ短縮、粗利率の即時把握、現場日報の電子化

対象: 工事案件、見積書、注文書、工事日報、出来高、入出金管理
利用者: 現場監督、工事部長、経理、役員 (合計60名想定)
データ量: 年間300件の工事案件、月次1万件の取引

技術制約: 既存の会計システム (勘定奉行) との連携必須、Microsoft 365 SSO希望
法令: インボイス制度、電子帳簿保存法、建設業法、下請法
予算: 約1500万円
納期: 2026年12月リリース希望

成果物: 要件定義書、基本設計書、ソースコード、運用手順書、研修資料

主要機能:
- ログイン (社内SSO)
- 工事案件CRUD
- 見積書/注文書/請求書発行 (インボイス対応)
- 工事日報のモバイル入力 (写真添付)
- ダッシュボード (進行中工事、粗利率、キャッシュフロー)
- 検索 (案件名、工期、請負金額)
- 監視 (システム稼働、夜間バッチ)
- 監査ログ
- バックアップ
- 帳票PDF出力

リスク: 既存会計システムとの連携APIが未公開の可能性あり
`;

const result = generateFullPackage({
  rfp_text: rfpText,
  industry: 'construction',
  client_type: '民間',
  scale: 'medium',
  proposer_company: {
    name: 'SoloptiLink株式会社',
    name_kana: 'ソロプティリンク',
    address: '東京都千代田区...',
    representative: '山田 太一',
    representative_title: '代表取締役',
    license_no: '建設業許可: 国交大臣許可 (般-XX) 第XXXXXX号',
    capital_jpy: 10_000_000,
    established: '2024年4月',
    employees: 12,
    website: 'https://solopti.link',
  },
  client_party: {
    role: '甲',
    name: '株式会社サンプル建設',
    address: '東京都港区...',
    representative: '山田 太郎',
    representative_title: '代表取締役',
    invoice_no: 'T1234567890123',
  },
  contractor_party: {
    role: '乙',
    name: 'SoloptiLink株式会社',
    address: '東京都千代田区...',
    representative: '山田 太一',
    representative_title: '代表取締役',
    invoice_no: 'T9876543210987',
  },
  contract_type: '請負',
  approach: 'waterfall',
  rate_client: 'standard',
});

console.log('===== RFP-DNA =====');
console.log(result.markdown.rfp_dna);
console.log('\n\n===== 見積書 =====');
console.log(result.markdown.estimate);
console.log('\n\n===== WBS =====');
console.log(result.markdown.wbs);
console.log('\n\n===== 提案書 (抜粋) =====');
console.log(result.markdown.proposal.slice(0, 3000));
console.log('\n...(全文は ',result.markdown.proposal.length, ' 文字)');
console.log('\n\n===== 契約書 (印紙税) =====');
console.log(`印紙税: ¥${result.contract.stamp_duty.amount_jpy.toLocaleString()} (${result.contract.stamp_duty.reason})`);
console.log(`契約金額 (税込): ¥${result.estimate.total_with_tax.toLocaleString()}`);
