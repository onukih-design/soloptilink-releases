#!/usr/bin/env node
/**
 * /soloptilink-tenant-dna CLI helper
 *
 * 直接実行用エントリ。スキル本体は TypeScript なので、tsx 経由で動作する想定。
 * 実行例:
 *   node scripts/cli.mjs status
 *   node scripts/cli.mjs list-siers
 *   node scripts/cli.mjs index
 */

import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const STORAGE_ROOT =
  process.env.SOLOPTILINK_TENANT_DNA_ROOT ||
  path.join(os.homedir(), '.soloptilink', 'learning', 'tenants');

const cmd = process.argv[2];

if (!cmd || cmd === 'help' || cmd === '--help') {
  console.log(`Usage: node scripts/cli.mjs <command>

Commands:
  status        現在のストレージ規模を表示
  list-siers    登録済 SIer 一覧
  index         インデックスを再構築 (生成は lib/index.ts の rebuildIndex 経由を推奨)
  paths         ストレージパスを表示
  doctor        セットアップ状況の健全性確認
`);
  process.exit(0);
}

if (cmd === 'paths') {
  console.log(`STORAGE_ROOT: ${STORAGE_ROOT}`);
  console.log(`SKILL_DIR:    ${path.resolve(__dirname, '..')}`);
  process.exit(0);
}

if (cmd === 'doctor') {
  const checks = [
    { name: 'storage_root_exists', ok: fs.existsSync(STORAGE_ROOT) },
    { name: 'lib_index_exists', ok: fs.existsSync(path.resolve(__dirname, '..', 'lib', 'index.ts')) },
    { name: 'skill_md_exists', ok: fs.existsSync(path.resolve(__dirname, '..', 'SKILL.md')) },
    { name: 'tests_exists', ok: fs.existsSync(path.resolve(__dirname, '..', 'tests', 'tenant_dna_check.mjs')) },
  ];
  let allOk = true;
  for (const c of checks) {
    console.log(`${c.ok ? '✓' : '✗'} ${c.name}`);
    if (!c.ok) allOk = false;
  }
  process.exit(allOk ? 0 : 1);
}

if (cmd === 'status') {
  if (!fs.existsSync(STORAGE_ROOT)) {
    console.log(`Storage root does not exist yet: ${STORAGE_ROOT}`);
    process.exit(0);
  }
  const sierDirs = fs.readdirSync(STORAGE_ROOT, { withFileTypes: true })
    .filter((d) => d.isDirectory() && !d.name.startsWith('_'));
  let totalCustomers = 0;
  let totalProjects = 0;
  for (const s of sierDirs) {
    const cdir = path.join(STORAGE_ROOT, s.name, 'customers');
    if (fs.existsSync(cdir)) {
      const customers = fs.readdirSync(cdir, { withFileTypes: true }).filter((d) => d.isDirectory());
      totalCustomers += customers.length;
      for (const c of customers) {
        const pdir = path.join(cdir, c.name, 'projects');
        if (fs.existsSync(pdir)) {
          totalProjects += fs.readdirSync(pdir, { withFileTypes: true }).filter((d) => d.isDirectory()).length;
        }
      }
    }
  }
  console.log(`SIers: ${sierDirs.length}`);
  console.log(`Customers: ${totalCustomers}`);
  console.log(`Projects: ${totalProjects}`);
  process.exit(0);
}

if (cmd === 'list-siers') {
  if (!fs.existsSync(STORAGE_ROOT)) {
    console.log('(no SIers registered yet)');
    process.exit(0);
  }
  for (const d of fs.readdirSync(STORAGE_ROOT, { withFileTypes: true })) {
    if (!d.isDirectory() || d.name.startsWith('_')) continue;
    const profilePath = path.join(STORAGE_ROOT, d.name, '_profile.json');
    if (fs.existsSync(profilePath)) {
      try {
        const p = JSON.parse(fs.readFileSync(profilePath, 'utf-8'));
        console.log(`${d.name.padEnd(10)} ${p.display_name_ja ?? p.display_name ?? ''} (projects=${p.meta?.project_count ?? 0})`);
      } catch {
        console.log(`${d.name} (profile parse error)`);
      }
    } else {
      console.log(`${d.name} (no profile)`);
    }
  }
  process.exit(0);
}

if (cmd === 'index') {
  console.log('Index rebuild requires the TypeScript runtime. Run via tsx:');
  console.log('  npx tsx -e "import(\'../lib/index.ts\').then(m => console.log(JSON.stringify(m.rebuildIndex(), null, 2)))"');
  process.exit(0);
}

console.error(`Unknown command: ${cmd}`);
process.exit(1);
