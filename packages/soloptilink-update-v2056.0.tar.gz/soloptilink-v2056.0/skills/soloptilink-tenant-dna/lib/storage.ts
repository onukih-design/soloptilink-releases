/**
 * Tenant DNA Storage Layer - JSONL ベースの append-only 永続化
 *
 * ストレージルート: ~/.soloptilink/learning/tenants/
 * 階層構造: <storage_root>/<sier_id>/customers/<tenant_id>/projects/<project_id>/
 * JSON: プロファイル系 (上書き可)
 * JSONL: 履歴系 (decisions, patterns 等 — append-only)
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import * as os from 'node:os';
import * as crypto from 'node:crypto';
import type {
  SierId,
  SierProfile,
  CustomerProfile,
  ProjectProfile,
  DecisionRecord,
  NamingRule,
  LibraryBlacklistEntry,
  CrossProjectPattern,
  TenantIndex,
} from './types';

export const STORAGE_ROOT =
  process.env.SOLOPTILINK_TENANT_DNA_ROOT ||
  path.join(os.homedir(), '.soloptilink', 'learning', 'tenants');

export const SCHEMA_VERSION = '1.0.0';

export function ensureStorageRoot(root: string = STORAGE_ROOT): void {
  if (!fs.existsSync(root)) {
    fs.mkdirSync(root, { recursive: true });
  }
}

export function sierDir(sierId: SierId, root: string = STORAGE_ROOT): string {
  return path.join(root, sierId);
}

export function customerDir(sierId: SierId, tenantId: string, root: string = STORAGE_ROOT): string {
  return path.join(sierDir(sierId, root), 'customers', sanitizeId(tenantId));
}

export function projectDir(
  sierId: SierId,
  tenantId: string,
  projectId: string,
  root: string = STORAGE_ROOT
): string {
  return path.join(customerDir(sierId, tenantId, root), 'projects', sanitizeId(projectId));
}

function sanitizeId(id: string): string {
  return id.replace(/[^a-zA-Z0-9_-]/g, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').toLowerCase();
}

function ensureDir(dir: string): void {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

/* ───── SIer Profile ───── */

export function readSierProfile(sierId: SierId, root: string = STORAGE_ROOT): SierProfile | null {
  const file = path.join(sierDir(sierId, root), '_profile.json');
  if (!fs.existsSync(file)) return null;
  try {
    return JSON.parse(fs.readFileSync(file, 'utf-8')) as SierProfile;
  } catch {
    return null;
  }
}

export function writeSierProfile(profile: SierProfile, root: string = STORAGE_ROOT): void {
  const dir = sierDir(profile.sier_id, root);
  ensureDir(dir);
  const file = path.join(dir, '_profile.json');
  fs.writeFileSync(file, JSON.stringify(profile, null, 2), 'utf-8');
}

/* ───── Customer Profile ───── */

export function readCustomerProfile(
  sierId: SierId,
  tenantId: string,
  root: string = STORAGE_ROOT
): CustomerProfile | null {
  const file = path.join(customerDir(sierId, tenantId, root), '_profile.json');
  if (!fs.existsSync(file)) return null;
  try {
    return JSON.parse(fs.readFileSync(file, 'utf-8')) as CustomerProfile;
  } catch {
    return null;
  }
}

export function writeCustomerProfile(profile: CustomerProfile, root: string = STORAGE_ROOT): void {
  const dir = customerDir(profile.sier_id, profile.tenant_id, root);
  ensureDir(dir);
  const file = path.join(dir, '_profile.json');
  fs.writeFileSync(file, JSON.stringify(profile, null, 2), 'utf-8');
}

/* ───── Project Profile ───── */

export function readProjectProfile(
  sierId: SierId,
  tenantId: string,
  projectId: string,
  root: string = STORAGE_ROOT
): ProjectProfile | null {
  const file = path.join(projectDir(sierId, tenantId, projectId, root), '_project.json');
  if (!fs.existsSync(file)) return null;
  try {
    return JSON.parse(fs.readFileSync(file, 'utf-8')) as ProjectProfile;
  } catch {
    return null;
  }
}

export function writeProjectProfile(profile: ProjectProfile, root: string = STORAGE_ROOT): void {
  const dir = projectDir(profile.sier_id, profile.tenant_id, profile.project_id, root);
  ensureDir(dir);
  const file = path.join(dir, '_project.json');
  fs.writeFileSync(file, JSON.stringify(profile, null, 2), 'utf-8');
}

/* ───── Decisions (append-only JSONL) ───── */

export function appendDecision(decision: DecisionRecord, root: string = STORAGE_ROOT): void {
  const customerScopeFile = path.join(
    customerDir(decision.sier_id, decision.tenant_id, root),
    'decisions.jsonl'
  );
  ensureDir(path.dirname(customerScopeFile));
  fs.appendFileSync(customerScopeFile, JSON.stringify(decision) + '\n', 'utf-8');

  if (decision.project_id) {
    const projectScopeFile = path.join(
      projectDir(decision.sier_id, decision.tenant_id, decision.project_id, root),
      'decisions.jsonl'
    );
    ensureDir(path.dirname(projectScopeFile));
    fs.appendFileSync(projectScopeFile, JSON.stringify(decision) + '\n', 'utf-8');
  }
}

export function readDecisionsForCustomer(
  sierId: SierId,
  tenantId: string,
  root: string = STORAGE_ROOT
): DecisionRecord[] {
  const file = path.join(customerDir(sierId, tenantId, root), 'decisions.jsonl');
  return readJsonl<DecisionRecord>(file);
}

export function readDecisionsForProject(
  sierId: SierId,
  tenantId: string,
  projectId: string,
  root: string = STORAGE_ROOT
): DecisionRecord[] {
  const file = path.join(projectDir(sierId, tenantId, projectId, root), 'decisions.jsonl');
  return readJsonl<DecisionRecord>(file);
}

/* ───── Naming rules (project/customer scoped JSON) ───── */

export function readNamingRules(
  sierId: SierId,
  tenantId: string,
  root: string = STORAGE_ROOT
): NamingRule[] {
  const file = path.join(customerDir(sierId, tenantId, root), 'naming.json');
  if (!fs.existsSync(file)) return [];
  try {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf-8'));
    return Array.isArray(parsed) ? (parsed as NamingRule[]) : [];
  } catch {
    return [];
  }
}

export function writeNamingRules(
  sierId: SierId,
  tenantId: string,
  rules: NamingRule[],
  root: string = STORAGE_ROOT
): void {
  const dir = customerDir(sierId, tenantId, root);
  ensureDir(dir);
  fs.writeFileSync(path.join(dir, 'naming.json'), JSON.stringify(rules, null, 2), 'utf-8');
}

/* ───── Library blacklist (JSON) ───── */

export function readBlacklist(
  sierId: SierId,
  tenantId: string,
  root: string = STORAGE_ROOT
): LibraryBlacklistEntry[] {
  const file = path.join(customerDir(sierId, tenantId, root), 'library_blacklist.json');
  if (!fs.existsSync(file)) return [];
  try {
    const parsed = JSON.parse(fs.readFileSync(file, 'utf-8'));
    return Array.isArray(parsed) ? (parsed as LibraryBlacklistEntry[]) : [];
  } catch {
    return [];
  }
}

export function writeBlacklist(
  sierId: SierId,
  tenantId: string,
  entries: LibraryBlacklistEntry[],
  root: string = STORAGE_ROOT
): void {
  const dir = customerDir(sierId, tenantId, root);
  ensureDir(dir);
  fs.writeFileSync(
    path.join(dir, 'library_blacklist.json'),
    JSON.stringify(entries, null, 2),
    'utf-8'
  );
}

/* ───── Cross-project patterns (SIer-wide JSONL) ───── */

export function appendPattern(
  scope: 'sier' | 'global',
  scopeId: string,
  pattern: CrossProjectPattern,
  root: string = STORAGE_ROOT
): void {
  const file =
    scope === 'global'
      ? path.join(root, '_global_patterns.jsonl')
      : path.join(sierDir(scopeId as SierId, root), '_patterns.jsonl');
  ensureDir(path.dirname(file));
  fs.appendFileSync(file, JSON.stringify(pattern) + '\n', 'utf-8');
}

export function readPatterns(
  scope: 'sier' | 'global',
  scopeId: string,
  root: string = STORAGE_ROOT
): CrossProjectPattern[] {
  const file =
    scope === 'global'
      ? path.join(root, '_global_patterns.jsonl')
      : path.join(sierDir(scopeId as SierId, root), '_patterns.jsonl');
  return readJsonl<CrossProjectPattern>(file);
}

/* ───── Index (lightweight overview) ───── */

export function buildIndex(root: string = STORAGE_ROOT): TenantIndex {
  ensureStorageRoot(root);
  const siers: TenantIndex['siers'] = [];
  let totalCustomers = 0;
  let totalProjects = 0;
  let totalDecisions = 0;

  if (!fs.existsSync(root)) {
    return {
      schema_version: SCHEMA_VERSION,
      generated_at: new Date().toISOString(),
      siers: [],
      total_customers: 0,
      total_projects: 0,
      total_decisions: 0,
    };
  }

  const sierIds = fs
    .readdirSync(root, { withFileTypes: true })
    .filter((d) => d.isDirectory() && !d.name.startsWith('_'))
    .map((d) => d.name as SierId);

  for (const sierId of sierIds) {
    const sierProfile = readSierProfile(sierId, root);
    const customers: TenantIndex['siers'][number]['customers'] = [];

    const customersBase = path.join(sierDir(sierId, root), 'customers');
    if (fs.existsSync(customersBase)) {
      const tenantDirs = fs
        .readdirSync(customersBase, { withFileTypes: true })
        .filter((d) => d.isDirectory());

      for (const tdir of tenantDirs) {
        const tenantId = tdir.name;
        const cprofile = readCustomerProfile(sierId, tenantId, root);
        if (!cprofile) continue;
        const projectsBase = path.join(customerDir(sierId, tenantId, root), 'projects');
        const projects: TenantIndex['siers'][number]['customers'][number]['projects'] = [];
        if (fs.existsSync(projectsBase)) {
          for (const pdir of fs.readdirSync(projectsBase, { withFileTypes: true })) {
            if (!pdir.isDirectory()) continue;
            const pp = readProjectProfile(sierId, tenantId, pdir.name, root);
            if (!pp) continue;
            const decisionFile = path.join(projectDir(sierId, tenantId, pdir.name, root), 'decisions.jsonl');
            const decisionCount = countLines(decisionFile);
            projects.push({
              project_id: pp.project_id,
              display_name: pp.display_name,
              status: pp.status,
              decision_count: decisionCount,
              last_active: pp.meta.last_updated,
            });
            totalProjects += 1;
            totalDecisions += decisionCount;
          }
        }
        customers.push({
          tenant_id: cprofile.tenant_id,
          display_name: cprofile.display_name,
          industry: cprofile.industry,
          projects,
          decision_count: countLines(path.join(customerDir(sierId, tenantId, root), 'decisions.jsonl')),
          last_active: cprofile.meta.last_updated,
        });
        totalCustomers += 1;
      }
    }

    siers.push({
      sier_id: sierId,
      display_name: sierProfile?.display_name ?? sierId,
      customers,
      decision_count: customers.reduce((s, c) => s + c.decision_count, 0),
    });
  }

  return {
    schema_version: SCHEMA_VERSION,
    generated_at: new Date().toISOString(),
    siers,
    total_customers: totalCustomers,
    total_projects: totalProjects,
    total_decisions: totalDecisions,
  };
}

export function writeIndex(root: string = STORAGE_ROOT): TenantIndex {
  ensureStorageRoot(root);
  const idx = buildIndex(root);
  fs.writeFileSync(path.join(root, '_index.json'), JSON.stringify(idx, null, 2), 'utf-8');
  return idx;
}

/* ───── Helpers ───── */

function readJsonl<T>(file: string): T[] {
  if (!fs.existsSync(file)) return [];
  const text = fs.readFileSync(file, 'utf-8');
  if (!text.trim()) return [];
  const result: T[] = [];
  for (const line of text.split('\n')) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    try {
      result.push(JSON.parse(trimmed) as T);
    } catch {
      // Skip malformed lines but never crash the recall flow.
    }
  }
  return result;
}

function countLines(file: string): number {
  if (!fs.existsSync(file)) return 0;
  const text = fs.readFileSync(file, 'utf-8');
  if (!text.trim()) return 0;
  return text.split('\n').filter((l) => l.trim().length > 0).length;
}

export function generateId(prefix: string): string {
  return `${prefix}-${Date.now().toString(36)}-${crypto.randomBytes(3).toString('hex')}`;
}

export const __testing__ = { sanitizeId, readJsonl, countLines };
