/**
 * Sync Engine - 既存プロジェクトディレクトリから Tenant DNA を逆抽出
 *
 * 入力: package.json / prisma/schema.prisma / tsconfig.json / .eslintrc / 既存ソース
 * 出力: SyncResult (検出された SIer / 顧客 / 命名規則 / 採用ライブラリ / 推測判断)
 *
 * 抽出戦略:
 * - package.json から dependencies + devDependencies を抽出 → 採用ライブラリ
 * - .git/config から remote URL → 顧客ドメイン推論
 * - prisma/schema.prisma の table 命名規則 → naming_rule
 * - tsconfig の paths から命名規則を推論
 * - sier 推論は package.json の "sier" カスタムフィールド or README.md のキーワード一致
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import type {
  SierId,
  NamingRule,
  DecisionRecord,
  SyncResult,
  NamingCase,
} from './types';
import { generateId } from './storage';

const SIER_KEYWORDS: Record<SierId, string[]> = {
  nttdata: ['NTT DATA', 'NTTデータ', 'TERASOLUNA'],
  fujitsu: ['Fujitsu', '富士通', 'INTERSTAGE', 'Apworks'],
  nri: ['NRI', '野村総合研究所', 'THE STAR'],
  nomura: ['野村', 'NSP'],
  nec: ['NEC', '日本電気', 'WebOTX', 'WebSAM'],
  hitachi: ['Hitachi', '日立', 'Cosminexus'],
  tis: ['TIS', 'TIDS', 'Xenlon'],
  generic: [],
};

export interface SyncOptions {
  source_path: string;
  hint_sier_id?: SierId;
  hint_tenant_id?: string;
  hint_project_id?: string;
  scan_source_lines?: boolean;
}

export function syncFromProject(opts: SyncOptions): SyncResult {
  const root = path.resolve(opts.source_path);
  const result: SyncResult = {
    source_path: root,
    detected_sier: opts.hint_sier_id,
    detected_tenant: opts.hint_tenant_id,
    detected_project: opts.hint_project_id,
    extracted_naming: [],
    extracted_libraries: { adopted: [], banned: [] },
    extracted_decisions: [],
    warnings: [],
  };

  if (!fs.existsSync(root)) {
    result.warnings.push(`source_path が存在しません: ${root}`);
    return result;
  }

  const pkgPath = path.join(root, 'package.json');
  if (fs.existsSync(pkgPath)) {
    extractFromPackageJson(pkgPath, result);
  } else {
    result.warnings.push('package.json が見つかりません。Node.jsプロジェクト前提で動作します。');
  }

  const tsconfigPath = path.join(root, 'tsconfig.json');
  if (fs.existsSync(tsconfigPath)) {
    extractFromTsconfig(tsconfigPath, result);
  }

  const prismaPath = path.join(root, 'prisma', 'schema.prisma');
  if (fs.existsSync(prismaPath)) {
    extractFromPrismaSchema(prismaPath, result);
  }

  const eslintPath = findFirstExisting([
    path.join(root, '.eslintrc.js'),
    path.join(root, '.eslintrc.cjs'),
    path.join(root, '.eslintrc.json'),
    path.join(root, 'eslint.config.js'),
    path.join(root, 'eslint.config.mjs'),
  ]);
  if (eslintPath) {
    result.extracted_decisions.push(buildDecision({
      sier_id: result.detected_sier ?? 'generic',
      tenant_id: result.detected_tenant ?? '__detected__',
      category: 'design_pattern',
      title: 'ESLint構成検出',
      decision: `ESLint設定ファイル検出: ${path.basename(eslintPath)}`,
      rationale: 'コード品質ガードが既に組み込まれている',
    }));
  }

  const readmePath = findFirstExisting([
    path.join(root, 'README.md'),
    path.join(root, 'README.MD'),
    path.join(root, 'docs', 'README.md'),
  ]);
  if (readmePath) {
    inferSierFromReadme(readmePath, result);
  }

  const gitConfigPath = path.join(root, '.git', 'config');
  if (fs.existsSync(gitConfigPath)) {
    inferTenantFromGit(gitConfigPath, result);
  }

  if (opts.scan_source_lines) {
    scanSourceLines(root, result);
  }

  return result;
}

function extractFromPackageJson(pkgPath: string, result: SyncResult): void {
  try {
    const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf-8')) as {
      name?: string;
      dependencies?: Record<string, string>;
      devDependencies?: Record<string, string>;
      sier?: string;
      tenant?: string;
    };
    const deps = { ...(pkg.dependencies ?? {}), ...(pkg.devDependencies ?? {}) };
    result.extracted_libraries.adopted = Object.keys(deps);
    if (pkg.sier && !result.detected_sier && SIER_KEYWORDS[pkg.sier as SierId]) {
      result.detected_sier = pkg.sier as SierId;
    }
    if (pkg.tenant && !result.detected_tenant) {
      result.detected_tenant = sanitize(pkg.tenant);
    }
    if (pkg.name && !result.detected_project) {
      result.detected_project = sanitize(pkg.name);
    }
    result.extracted_decisions.push(buildDecision({
      sier_id: result.detected_sier ?? 'generic',
      tenant_id: result.detected_tenant ?? '__detected__',
      category: 'stack',
      title: '採用ライブラリ検出',
      decision: `package.json から ${result.extracted_libraries.adopted.length} 件のライブラリを検出`,
      rationale: '既存プロジェクトの技術スタックを尊重し、新規追加時は同等性を維持する',
    }));
  } catch (err) {
    result.warnings.push(`package.json の解析に失敗しました: ${(err as Error).message}`);
  }
}

function extractFromTsconfig(tsconfigPath: string, result: SyncResult): void {
  try {
    const content = fs.readFileSync(tsconfigPath, 'utf-8');
    if (content.includes('"strict": true') || content.includes('"strict":true')) {
      result.extracted_decisions.push(buildDecision({
        sier_id: result.detected_sier ?? 'generic',
        tenant_id: result.detected_tenant ?? '__detected__',
        category: 'design_pattern',
        title: 'TypeScript strict mode 採用',
        decision: 'tsconfig.json で strict: true が有効化されている',
        rationale: '型安全を最大化する方針が既に確立されている',
      }));
    }
  } catch (err) {
    result.warnings.push(`tsconfig.json の解析に失敗しました: ${(err as Error).message}`);
  }
}

function extractFromPrismaSchema(schemaPath: string, result: SyncResult): void {
  try {
    const text = fs.readFileSync(schemaPath, 'utf-8');
    const modelMatches = [...text.matchAll(/model\s+(\w+)\s*\{/g)].map((m) => m[1]);
    if (modelMatches.length === 0) return;
    const inferredCase = inferNamingCase(modelMatches);
    const prefixes = modelMatches
      .map((m) => m.match(/^([A-Za-z]+_)/)?.[1])
      .filter((p): p is string => Boolean(p));
    const dominantPrefix =
      prefixes.length > 0 && prefixes.length === modelMatches.length
        ? mostCommon(prefixes)
        : undefined;
    result.extracted_naming.push({
      tenant_id: result.detected_tenant ?? '__detected__',
      rule_id: generateId('naming'),
      scope: 'db_table',
      case_style: inferredCase,
      prefix: dominantPrefix,
      rationale: `prisma/schema.prisma の ${modelMatches.length} 個のモデル名から自動推論`,
      enforced: true,
      example_good: modelMatches.slice(0, 3),
    });
    result.extracted_decisions.push(buildDecision({
      sier_id: result.detected_sier ?? 'generic',
      tenant_id: result.detected_tenant ?? '__detected__',
      category: 'db_schema',
      title: 'Prismaスキーマ検出',
      decision: `${modelMatches.length} モデル定義済み`,
      rationale: '既存スキーマの命名規則・リレーション構造を踏襲する',
    }));
  } catch (err) {
    result.warnings.push(`prisma schema の解析に失敗しました: ${(err as Error).message}`);
  }
}

function inferSierFromReadme(readmePath: string, result: SyncResult): void {
  try {
    const content = fs.readFileSync(readmePath, 'utf-8');
    if (result.detected_sier && result.detected_sier !== 'generic') return;
    let bestSier: SierId | undefined;
    let bestHits = 0;
    for (const [sierId, kws] of Object.entries(SIER_KEYWORDS) as Array<[SierId, string[]]>) {
      const hits = kws.reduce((sum, kw) => (content.includes(kw) ? sum + 1 : sum), 0);
      if (hits > bestHits) {
        bestHits = hits;
        bestSier = sierId;
      }
    }
    if (bestSier && bestHits > 0) {
      result.detected_sier = bestSier;
      result.extracted_decisions.push(buildDecision({
        sier_id: bestSier,
        tenant_id: result.detected_tenant ?? '__detected__',
        category: 'compliance',
        title: 'SIer 推論',
        decision: `README.md キーワード一致から ${bestSier} を推定`,
        rationale: `一致キーワード数=${bestHits}`,
      }));
    }
  } catch {
    // README 解析失敗は致命的ではない
  }
}

function inferTenantFromGit(gitConfigPath: string, result: SyncResult): void {
  try {
    const content = fs.readFileSync(gitConfigPath, 'utf-8');
    const remoteMatch = content.match(/url\s*=\s*([^\n]+)/);
    if (!remoteMatch) return;
    const url = remoteMatch[1].trim();
    const orgMatch = url.match(/github\.com[:/]([^/]+)\//) || url.match(/gitlab\.com[:/]([^/]+)\//);
    if (orgMatch && !result.detected_tenant) {
      result.detected_tenant = sanitize(orgMatch[1]);
      result.extracted_decisions.push(buildDecision({
        sier_id: result.detected_sier ?? 'generic',
        tenant_id: result.detected_tenant,
        category: 'compliance',
        title: 'Git remote から顧客推論',
        decision: `URL=${url} から org=${orgMatch[1]} を抽出`,
        rationale: 'GitHub/GitLab の組織名を顧客IDの初期値とする',
      }));
    }
  } catch {
    // git config 解析失敗は致命的ではない
  }
}

function scanSourceLines(rootDir: string, result: SyncResult): void {
  const targets = ['src', 'app', 'lib', 'pages'];
  for (const t of targets) {
    const p = path.join(rootDir, t);
    if (fs.existsSync(p) && fs.statSync(p).isDirectory()) {
      const files = walkDir(p, ['.ts', '.tsx', '.js', '.jsx']).slice(0, 200);
      const exportedSymbols: string[] = [];
      for (const f of files) {
        try {
          const text = fs.readFileSync(f, 'utf-8');
          const m = [...text.matchAll(/export\s+(?:const|function|class|interface|type)\s+(\w+)/g)].map((x) => x[1]);
          exportedSymbols.push(...m);
        } catch {
          continue;
        }
      }
      if (exportedSymbols.length > 0) {
        const inferred = inferNamingCase(exportedSymbols);
        result.extracted_naming.push({
          tenant_id: result.detected_tenant ?? '__detected__',
          rule_id: generateId('naming'),
          scope: 'typescript_var',
          case_style: inferred,
          rationale: `${t}/ 配下の exported シンボル ${exportedSymbols.length} 件から推論`,
          enforced: true,
          example_good: exportedSymbols.slice(0, 3),
        });
      }
    }
  }
}

function inferNamingCase(samples: string[]): NamingCase {
  let snake = 0, camel = 0, pascal = 0, kebab = 0, upper = 0;
  for (const s of samples) {
    if (/^[A-Z][A-Z0-9_]*$/.test(s)) upper++;
    else if (/^[A-Z][a-zA-Z0-9]*$/.test(s)) pascal++;
    else if (/^[a-z][a-zA-Z0-9]*$/.test(s)) camel++;
    else if (/^[a-z][a-z0-9_]*$/.test(s) && s.includes('_')) snake++;
    else if (/^[a-z][a-z0-9-]*$/.test(s) && s.includes('-')) kebab++;
  }
  const max = Math.max(snake, camel, pascal, kebab, upper);
  if (max === 0) return 'mixed';
  if (max === pascal) return 'PascalCase';
  if (max === camel) return 'camelCase';
  if (max === snake) return 'snake_case';
  if (max === upper) return 'UPPER_SNAKE';
  if (max === kebab) return 'kebab-case';
  return 'mixed';
}

function mostCommon(arr: string[]): string {
  const counts = new Map<string, number>();
  for (const a of arr) counts.set(a, (counts.get(a) ?? 0) + 1);
  let best = arr[0];
  let bestCount = 0;
  for (const [k, v] of counts) if (v > bestCount) { best = k; bestCount = v; }
  return best;
}

function buildDecision(input: {
  sier_id: SierId;
  tenant_id: string;
  category: DecisionRecord['category'];
  title: string;
  decision: string;
  rationale: string;
}): DecisionRecord {
  return {
    decision_id: generateId('decision'),
    tenant_id: input.tenant_id,
    sier_id: input.sier_id,
    category: input.category,
    title: input.title,
    decision: input.decision,
    rationale: input.rationale,
    decided_at: new Date().toISOString(),
    status: 'active',
    tags: ['auto_synced'],
    source: 'auto_sync',
  };
}

function findFirstExisting(paths: string[]): string | null {
  for (const p of paths) if (fs.existsSync(p)) return p;
  return null;
}

function sanitize(s: string): string {
  return s
    .replace(/[^a-zA-Z0-9_-]/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-|-$/g, '')
    .toLowerCase();
}

function walkDir(dir: string, exts: string[]): string[] {
  const out: string[] = [];
  const stack = [dir];
  const skip = new Set(['node_modules', '.git', '.next', 'dist', 'build', 'out', '.turbo']);
  while (stack.length > 0) {
    const cur = stack.pop()!;
    let entries: fs.Dirent[];
    try {
      entries = fs.readdirSync(cur, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const e of entries) {
      if (skip.has(e.name)) continue;
      const full = path.join(cur, e.name);
      if (e.isDirectory()) stack.push(full);
      else if (exts.some((ext) => e.name.endsWith(ext))) out.push(full);
    }
  }
  return out;
}
