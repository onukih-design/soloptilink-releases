/**
 * Recall Engine - BOOST Step 0.4d Layer 5 として呼ばれる主要 API
 *
 * 入力: { sier_id?, tenant_id?, project_id?, hint? } + (推論サマリーへ統合される文脈)
 * 出力: 推論サマリーへ追記する Markdown ブロック + 構造化 RecallResult
 */

import type { SierId, RecallResult } from './types';
import { recallSummary, RecallContext, snapshotCustomerMaterials } from './memory_graph';
import { distillPatterns } from './cross_project_synthesizer';
import { STORAGE_ROOT } from './storage';

export interface RecallForBoostInput extends RecallContext {
  workspace_dir?: string;
  detected_industry?: string;
  detected_keywords?: string[];
}

export interface RecallForBoostOutput {
  result: RecallResult;
  inference_block_markdown: string;
  injection_lines_for_agents: string[];
  has_data: boolean;
}

/**
 * BOOST Step 0.4d Layer 5 から呼ばれる主関数。
 * 推論サマリーに追記する Markdown と、Step 3 の Agent プロンプトに注入する1行命令を返す。
 */
export function recallForBoost(
  input: RecallForBoostInput,
  root: string = STORAGE_ROOT
): RecallForBoostOutput {
  const baseResult = recallSummary(input, root);
  const hasIdentifiers = Boolean(input.sier_id && input.tenant_id);

  if (!hasIdentifiers) {
    return {
      result: baseResult,
      inference_block_markdown: buildEmptyBlock(input),
      injection_lines_for_agents: [],
      has_data: false,
    };
  }

  // Try to enrich with distilled patterns at SIer scope
  let enrichedPatterns = baseResult.related_patterns;
  if (input.sier_id && enrichedPatterns.length === 0) {
    try {
      enrichedPatterns = distillPatterns('sier', input.sier_id, { min_occurrence: 2 }).slice(0, 5);
    } catch {
      // Defensive: distillation failures must never block recall.
    }
  }

  const result: RecallResult = {
    ...baseResult,
    related_patterns: enrichedPatterns,
    recommended_stack: deriveRecommendedStack(baseResult, input),
  };

  return {
    result,
    inference_block_markdown: buildInferenceBlock(result, input),
    injection_lines_for_agents: buildAgentInjections(result, input),
    has_data: result.recent_decisions.length > 0 || result.active_naming_rules.length > 0,
  };
}

function deriveRecommendedStack(result: RecallResult, _input: RecallForBoostInput): string[] | undefined {
  const stackDecisions = result.recent_decisions.filter((d) => d.category === 'stack');
  if (stackDecisions.length === 0) {
    if (result.sier_profile?.preferred_libraries?.length) {
      return result.sier_profile.preferred_libraries.slice(0, 6);
    }
    return undefined;
  }
  return stackDecisions.slice(0, 1).flatMap((d) =>
    d.decision
      .split(/[\/、,，]/)
      .map((s) => s.trim())
      .filter((s) => s.length > 0)
  );
}

function buildEmptyBlock(input: RecallForBoostInput): string {
  const lines: string[] = [];
  lines.push('【Tenant DNA 自動適用】v2019.2');
  lines.push(`- 状態: 未登録 (sier_id=${input.sier_id ?? '-'}, tenant_id=${input.tenant_id ?? '-'})`);
  lines.push(
    '- アクション: 初回起動時は `/soloptilink-tenant-dna --mode register --sier <id> --tenant <id> --project <id>` で登録してください。以降のセッションで永続学習が有効になります。'
  );
  lines.push('- 出荷時 SIer 雛形: 8種 (nttdata/fujitsu/nri/nomura/nec/hitachi/tis/generic) は組込済。');
  return lines.join('\n');
}

function buildInferenceBlock(result: RecallResult, input: RecallForBoostInput): string {
  const lines: string[] = [];
  lines.push('【Tenant DNA 自動適用】v2019.2');
  if (result.sier_profile) {
    lines.push(
      `- SIer: ${result.sier_profile.display_name_ja} (project_count=${result.sier_profile.meta.project_count})`
    );
  }
  if (result.customer_profile) {
    lines.push(
      `- 顧客: ${result.customer_profile.display_name}${result.customer_profile.industry_ja ? ` (${result.customer_profile.industry_ja})` : ''}`
    );
  }
  if (result.project_profile) {
    lines.push(`- プロジェクト: ${result.project_profile.display_name} (${result.project_profile.status})`);
  }
  if (result.active_naming_rules.length > 0) {
    const summary = result.active_naming_rules
      .map((r) => `${r.scope}=${r.case_style}${r.prefix ? `(${r.prefix})` : ''}`)
      .slice(0, 6)
      .join(' / ');
    lines.push(`- 命名規則: ${summary}`);
  }
  if (result.active_blacklist.length > 0) {
    const banned = result.active_blacklist
      .slice(0, 8)
      .map((b) => `${b.library_name}(${b.scope})`)
      .join(', ');
    lines.push(`- 採用禁止ライブラリ: ${banned}`);
  }
  if (result.recent_decisions.length > 0) {
    const top = result.recent_decisions
      .slice(0, 3)
      .map((d) => `${d.category}: ${d.title}`)
      .join(' / ');
    lines.push(`- 直近判断: ${top}`);
  }
  if (result.related_patterns.length > 0) {
    const pat = result.related_patterns
      .slice(0, 3)
      .map((p) => `${p.category}: ${p.pattern_summary} (occ=${p.occurrence_count}, succ=${(p.success_rate * 100).toFixed(0)}%)`)
      .join(' / ');
    lines.push(`- 横断パターン: ${pat}`);
  }
  if (result.recommended_stack && result.recommended_stack.length > 0) {
    lines.push(`- 推奨スタック: ${result.recommended_stack.join(' / ')}`);
  }
  if (input.workspace_dir) {
    lines.push(`- 作業ディレクトリ: ${input.workspace_dir}`);
  }
  if (result.warnings.length > 0) {
    lines.push(`- 警告: ${result.warnings.join(' / ')}`);
  }
  return lines.join('\n');
}

function buildAgentInjections(result: RecallResult, _input: RecallForBoostInput): string[] {
  const out: string[] = [];
  if (result.active_naming_rules.length > 0) {
    out.push(
      `命名規則は以下に厳密準拠すること: ${result.active_naming_rules
        .map((r) => `${r.scope}=${r.case_style}${r.prefix ? `(prefix=${r.prefix})` : ''}`)
        .join(', ')}`
    );
  }
  if (result.active_blacklist.length > 0) {
    out.push(
      `以下のライブラリは絶対に採用しないこと (代替を提案する): ${result.active_blacklist
        .map((b) => `${b.library_name}${b.alternative_recommendation ? ` → 代替: ${b.alternative_recommendation}` : ''}`)
        .join(', ')}`
    );
  }
  if (result.recent_decisions.length > 0) {
    out.push(
      `過去の有効判断を尊重すること: ${result.recent_decisions
        .slice(0, 5)
        .map((d) => `[${d.category}] ${d.title} — ${d.decision}`)
        .join(' / ')}`
    );
  }
  if (result.related_patterns.length > 0) {
    out.push(
      `同SIer内の成功パターンを採用候補に含めること: ${result.related_patterns
        .slice(0, 3)
        .map((p) => p.recommendation_text)
        .join(' / ')}`
    );
  }
  if (result.recommended_stack && result.recommended_stack.length > 0) {
    out.push(`推奨スタックは ${result.recommended_stack.join(', ')} を第一候補とし、変更する場合は明示的な理由を docs/DESIGN_CONTRACT.md に記載すること。`);
  }
  return out;
}

/**
 * 顧客サマリ用の Markdown を別途生成 (引継書・運用報告書への添付用)。
 */
export function renderCustomerHandoffSection(
  sier_id: SierId,
  tenant_id: string,
  root: string = STORAGE_ROOT
): string {
  const m = snapshotCustomerMaterials(sier_id, tenant_id, root);
  const lines: string[] = [];
  lines.push(`## Tenant DNA サマリ`);
  if (m.sier) lines.push(`- **SIer**: ${m.sier.display_name_ja}`);
  if (m.customer) lines.push(`- **顧客**: ${m.customer.display_name}`);
  lines.push(`- **判断記録**: ${m.decisions.length} 件`);
  lines.push(`- **命名規則**: ${m.naming_rules.length} 件`);
  lines.push(`- **採用禁止ライブラリ**: ${m.blacklist.length} 件`);
  if (m.naming_rules.length > 0) {
    lines.push('');
    lines.push(`### 命名規則`);
    for (const r of m.naming_rules) {
      lines.push(`- ${r.scope}: ${r.case_style}${r.prefix ? ` (接頭辞: ${r.prefix})` : ''} — ${r.rationale}`);
    }
  }
  if (m.blacklist.length > 0) {
    lines.push('');
    lines.push(`### 採用禁止ライブラリ`);
    for (const b of m.blacklist) {
      lines.push(`- ${b.library_name} (${b.language}) — ${b.reason}${b.alternative_recommendation ? ` / 代替: ${b.alternative_recommendation}` : ''}`);
    }
  }
  return lines.join('\n');
}
