/**
 * soloptilink-tenant-dna public API
 *
 * 全モジュールを一括 re-export し、CLIスクリプト・例題・他スキルから単一の import で扱えるようにする。
 *
 * 主要利用パス:
 *  - BOOST Step 0.4d Layer 5 → recallForBoost(...)
 *  - 顧客新規受託      → registerSier / registerCustomer / registerProject
 *  - 判断記録         → recordDecision
 *  - 既存プロジェクト統合 → syncFromProject
 *  - 端末間移動       → exportTenantDna / importTenantDna
 */

export * from './types';
export {
  STORAGE_ROOT,
  SCHEMA_VERSION,
  ensureStorageRoot,
  buildIndex,
  writeIndex,
  generateId,
} from './storage';
export {
  registerSier,
  registerCustomer,
  registerProject,
  updateSierProfile,
  updateCustomerProfile,
  updateProjectProfile,
  getSier,
  getCustomer,
  getProject,
  archiveProject,
  listAllSiers,
  listCustomersOfSier,
  listProjectsOfCustomer,
  getBuiltinSierProfile,
  listBuiltinSierIds,
} from './tenant_profile';
export {
  recordDecision,
  supersedeDecision,
  expireDecision,
  findDecisions,
  getActiveDecisionsByCategory,
  summarizeDecisions,
  validateDecisionInput,
  maskPII,
  scanForSecrets,
} from './decision_memory';
export {
  defineNamingRule,
  getActiveNamingRules,
  validateName,
  convertNameToCase,
  inferRuleFromExamples,
  applyRulesToCodeSnippet,
  defaultRulesForSier,
} from './naming_convention';
export {
  banLibrary,
  unbanLibrary,
  isLibraryBanned,
  validatePackageJson,
  validateRequirementsTxt,
  suggestAlternative,
  listBannedForCustomer,
  listBannedForSier,
  defaultBlacklistForSier,
} from './library_blacklist';
export {
  BUILTIN_SIER_TEMPLATES,
  getSierTemplate,
  applySierTemplateToProject,
  compareSierTemplates,
} from './sier_template';
export {
  distillPatterns,
  recommendBasedOnHistory,
  findSimilarProjects,
  compareProjects,
  extractSuccessFactors,
  persistDistilledPatterns,
} from './cross_project_synthesizer';
export {
  buildGraph,
  summarizeMemory,
  formatGraphAsMarkdown,
  snapshotCustomerMaterials,
  rebuildIndex,
  recallSummary,
} from './memory_graph';
export type {
  GraphNode,
  GraphEdge,
  GraphSnapshot,
  GraphQuery,
  RecallContext,
} from './memory_graph';
export {
  recallForBoost,
  renderCustomerHandoffSection,
} from './recall_engine';
export type { RecallForBoostInput, RecallForBoostOutput } from './recall_engine';
export {
  exportTenantDna,
  importTenantDna,
} from './exporter';
export type {
  ExportPayload,
  ExportOptions,
  ImportOptions,
  ImportSummary,
} from './exporter';
export {
  syncFromProject,
} from './sync_engine';
export type { SyncOptions } from './sync_engine';
