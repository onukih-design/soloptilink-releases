/**
 * SIer Template Module — 8 SIer の標準雛形 (アーキ/命名/ライブラリ/レビュー/QAゲート)
 *
 * 責務:
 *   - NTTデータ/富士通/NRI/野村総研/NEC/日立/TIS/Generic の標準雛形を内蔵
 *   - getSierTemplate: ID→雛形 取得
 *   - applySierTemplateToProject: 雛形をプロジェクトディレクトリへ書き出し
 *   - compareSierTemplates: 営業説明用の比較表生成
 *
 * 入力:
 *   - SierId (types.ts) / target_dir (絶対パス推奨)
 *
 * 出力:
 *   - SierTemplate (本ファイルで定義) / 適用ファイル一覧 / 比較表
 *
 * データソース: 各社公開フレームワーク資料・SI業界一般慣行から推定 (NTTデータ TERASOLUNA / 富士通
 *   INTERSTAGE / NRI THE STAR / 野村 NSP / NEC WebSAM/WebOTX / 日立 Cosminexus/JP1 / TIS TIDS 等)
 *
 * ストレージ: 雛形書き出しは fs だが、テナント DB には触らないため storage.ts 経由不要
 *   (storage.ts は永続学習層用、本モジュールは静的雛形のみ)
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import type { SierId, NamingRule, NamingCase } from './types';

/* ───── 型定義 ───── */

export interface SierArchitecture {
  name: string;
  description: string;
  layers: string[];
  mandatory_components: string[];
  forbidden_components?: string[];
}

export interface PreferredLibraryGroup {
  language: 'typescript' | 'javascript' | 'python' | 'java' | 'go' | 'rust' | 'any';
  libraries: { name: string; version_range?: string; reason?: string }[];
}

export interface BannedLibraryGroup {
  language: PreferredLibraryGroup['language'];
  libraries: { name: string; reason: string }[];
}

export interface DocumentationSection {
  title: string;
  outline: string;
}

export interface DocumentationTemplate {
  sections: DocumentationSection[];
}

export interface QaGate {
  coverage_min: number;
  lighthouse_min?: number;
  security_scan: boolean;
  static_analysis_tool?: string;
  pen_test_required?: boolean;
  load_test_required?: boolean;
  doc_review_required?: boolean;
  notes?: string;
}

export interface SierTemplate {
  sier_id: SierId;
  display_name: string;
  display_name_ja: string;
  architecture: SierArchitecture;
  naming_rules: NamingRule[];
  preferred_libraries: PreferredLibraryGroup[];
  banned_libraries: BannedLibraryGroup[];
  deployment_targets: string[];
  documentation_template: DocumentationTemplate;
  code_review_checklist: string[];
  qa_gate: QaGate;
}

/* ───── 命名規則ヘルパ ───── */

function namingRule(
  scope: NamingRule['scope'],
  case_style: NamingCase,
  rationale: string,
  options: Partial<NamingRule> = {}
): NamingRule {
  return {
    tenant_id: '__sier_default__',
    rule_id: `${scope}-${case_style}`,
    scope,
    case_style,
    rationale,
    enforced: true,
    ...options,
  };
}

/* ═══════════════════════════════════════════════════════════
 *   NTTデータ TERASOLUNA Style
 * ═══════════════════════════════════════════════════════════ */

const NTTDATA_TEMPLATE: SierTemplate = {
  sier_id: 'nttdata',
  display_name: 'NTT DATA',
  display_name_ja: 'NTTデータ',
  architecture: {
    name: 'TERASOLUNA 5層 + バッチ + EAI',
    description:
      'NTTデータが OSS で公開する Spring ベースの企業向け 5 層モデル。Web / Domain / Infrastructure を厳格に分離し、バッチ層は TERASOLUNA Batch 5.x を採用。EAI は HULFT/Magic/独自製品で連携。',
    layers: [
      'Presentation (Spring MVC + Thymeleaf or React)',
      'Application Service',
      'Domain (Entity + DomainService)',
      'Infrastructure (Repository + RestClient)',
      'Common (Constants/Exception/MessageSource)',
      'Batch (TERASOLUNA Batch 5.x)',
      'EAI (HULFT / Magic xpi)',
    ],
    mandatory_components: [
      'Spring Framework 6.x',
      'TERASOLUNA Server Framework for Java 5.x',
      'MyBatis 3.x',
      'JSR-303 Bean Validation',
      'SLF4J + Logback',
      'JUnit 5 + Mockito',
      'JaCoCo (カバレッジ)',
      '社内 Sonar (コード品質)',
    ],
    forbidden_components: [
      'Spring Boot (単独採用)',
      'Hibernate (TERASOLUNA 標準は MyBatis)',
      'Lombok (社内静的解析と相性不可)',
    ],
  },
  naming_rules: [
    namingRule('db_table', 'UPPER_SNAKE', 'NTTデータ標準: 大文字スネーク、業務略号3文字を prefix に持たせる', {
      prefix: 'M_/T_/H_',
      example_good: ['M_USER', 'T_ORDER', 'H_AUDIT_LOG'],
      example_bad: ['user', 'orders'],
    }),
    namingRule('db_column', 'snake_case', '小文字スネーク。日付列は _DT、フラグは _FLG suffix'),
    namingRule('typescript_var', 'camelCase', 'JS/TS 標準'),
    namingRule('typescript_type', 'PascalCase', '型・クラスは Pascal'),
    namingRule('api_path', 'kebab-case', 'REST API パスは kebab。/api/v1/order-items など', {
      example_good: ['/api/v1/order-items'],
      example_bad: ['/api/v1/orderItems'],
    }),
    namingRule('component', 'PascalCase', 'React コンポーネントは Pascal'),
    namingRule('file', 'PascalCase', 'Java クラスファイルは PascalCase.java'),
    namingRule('route', 'kebab-case', 'Next.js ルート/Spring URL は kebab'),
  ],
  preferred_libraries: [
    {
      language: 'java',
      libraries: [
        { name: 'spring-framework', version_range: '6.x', reason: 'TERASOLUNA 5 系の前提' },
        { name: 'terasoluna-gfw-common', version_range: '5.7.x', reason: 'NTTデータ標準フレームワーク' },
        { name: 'mybatis', version_range: '3.5.x', reason: 'TERASOLUNA 標準 ORM' },
        { name: 'spring-batch', version_range: '5.x', reason: 'TERASOLUNA Batch ベース' },
        { name: 'logback-classic', version_range: '1.4.x', reason: 'SLF4J 標準 binding' },
        { name: 'junit-jupiter', version_range: '5.x', reason: '標準テストフレームワーク' },
        { name: 'mockito-core', version_range: '5.x', reason: 'モック標準' },
      ],
    },
    {
      language: 'typescript',
      libraries: [
        { name: 'react', version_range: '18.x', reason: 'BFF 用フロント標準' },
        { name: 'next', version_range: '14.x', reason: '社内承認済 Next.js' },
        { name: 'axios', version_range: '1.x', reason: '社内 HTTP クライアント標準' },
        { name: 'zod', version_range: '3.x', reason: 'スキーマ検証 (TS 側)' },
        { name: 'vitest', version_range: '1.x', reason: 'TS テスト標準' },
      ],
    },
    {
      language: 'python',
      libraries: [
        { name: 'fastapi', version_range: '0.110.x', reason: '社内 PoC 用 API フレームワーク' },
        { name: 'pydantic', version_range: '2.x', reason: 'バリデーション標準' },
      ],
    },
  ],
  banned_libraries: [
    {
      language: 'java',
      libraries: [
        { name: 'spring-boot-starter-parent', reason: 'TERASOLUNA 標準は Spring Framework 単体構成のため' },
        { name: 'lombok', reason: '社内 Sonar の警告抑止が困難' },
        { name: 'hibernate-orm', reason: 'TERASOLUNA 標準は MyBatis' },
      ],
    },
    {
      language: 'javascript',
      libraries: [
        { name: 'mongoose', reason: '本部標準は RDB (PostgreSQL/Oracle)' },
        { name: 'next-auth', reason: '社内 CIAM SDK と統合できないため不可' },
      ],
    },
  ],
  deployment_targets: [
    'NTTデータ社内クラウド OpenCanvas',
    'AWS (NTTデータ DTC アカウント)',
    'Azure (NTTデータ Microsoft アライアンス)',
    'オンプレミス (Red Hat Enterprise Linux 9)',
    'プライベートクラウド (VMware vSphere)',
  ],
  documentation_template: {
    sections: [
      {
        title: '1. システム概要',
        outline: '対象業務・関係者・全体構成図 (Visio)・主要 KPI を記載。社内ガイドライン v3 準拠。',
      },
      { title: '2. 機能要件', outline: 'BR/FR/QR/CR の階層で WBS と対応付け、要件 ID を採番。' },
      { title: '3. 非機能要件', outline: 'IPA 非機能要求グレードに沿って 6 大項目 × 100 指標を埋める。' },
      { title: '4. アーキテクチャ', outline: 'TERASOLUNA 5 層モデル図・コンポーネント図・配置図 (UML)。' },
      { title: '5. 画面設計', outline: '画面一覧 + 画面遷移図 + 画面項目定義書 (Excel テンプレ)。' },
      { title: '6. データベース設計', outline: 'ERD・テーブル定義書・CRUD 図 (社内 Excel フォーマット)。' },
      { title: '7. API/バッチ設計', outline: 'REST API 一覧 + IF 仕様書 + バッチ定義書 (TERASOLUNA Batch)。' },
      { title: '8. 試験計画/結果', outline: '単体・結合・総合・受入の 4 階層、JaCoCo 80% 必須。' },
      { title: '9. 運用設計', outline: '運用手順書・障害対応 Runbook・監視設計 (Hinemos/JP1)。' },
      { title: '10. セキュリティ設計', outline: 'IPA 安全な Web アプリの作り方・OWASP ASVS Level 2 以上。' },
    ],
  },
  code_review_checklist: [
    'TERASOLUNA 5 層構造を逸脱していないか (DomainService が直接 SQL を発行していないか)',
    'MyBatis Mapper の SQL に動的バインディング以外で外部入力が混入していないか',
    'JSR-303 アノテーションが全 Form に付与されているか',
    'Logback の MDC で traceId/userId が出力されているか',
    'コミット粒度が WBS 単位かつ社内コミットメッセージ規約に準拠しているか',
    'JaCoCo の line coverage が 80% を下回っていないか',
    'SonarQube Critical/Blocker 0 件か',
    'パスワード/秘密鍵が PR 上に露出していないか (社内 Talisman 必須)',
    '画面項目に対する Form/Validation の対応漏れが無いか',
    'バッチの再実行性 (リスタート起点設定) が定義されているか',
    'Web 画面で CSRF/XSS 対策が TERASOLUNA 既定通りに有効化されているか',
    'ログマスキング (個人情報) が共通モジュール経由で行われているか',
    'OSS ライセンスが社内 OSS 委員会の承認リスト内か',
  ],
  qa_gate: {
    coverage_min: 80,
    lighthouse_min: 80,
    security_scan: true,
    static_analysis_tool: 'SonarQube + Checkmarx',
    pen_test_required: true,
    load_test_required: true,
    doc_review_required: true,
    notes: 'IPA 非機能要求グレード 6 大項目の合格判定を必須とする',
  },
};

/* ═══════════════════════════════════════════════════════════
 *   富士通 INTERSTAGE Style
 * ═══════════════════════════════════════════════════════════ */

const FUJITSU_TEMPLATE: SierTemplate = {
  sier_id: 'fujitsu',
  display_name: 'Fujitsu',
  display_name_ja: '富士通',
  architecture: {
    name: 'INTERSTAGE 標準 (Java EE + Apworks)',
    description:
      '富士通の Application Server "Interstage" 上に Apworks 開発フレームワークを乗せる構成。FNJ (Fujitsu Network Japan) 系では Symfoware DB が定石。最近は Azure へのリフトでも踏襲。',
    layers: [
      'Presentation (Apcoordinator / React+Spring)',
      'Business Logic (Apworks)',
      'Data Access (Apworks DB Access)',
      'Persistence (Symfoware / PostgreSQL)',
      'Common (Apworks Common)',
      'Integration (Interstage Application Framework Suite)',
    ],
    mandatory_components: [
      'Interstage Application Server V12',
      'Apworks 開発フレームワーク',
      'Symfoware Server / PostgreSQL',
      'Java EE 8 (Jakarta EE 10 移行中)',
      'Systemwalker 監視',
      'JUnit 5',
    ],
    forbidden_components: [
      'Apache Tomcat (単独採用)',
      'WebPack 単体 (社内ビルドは Vite/esbuild)',
      'Jest (社内標準は Vitest)',
    ],
  },
  naming_rules: [
    namingRule('db_table', 'UPPER_SNAKE', '富士通標準: 大文字スネーク, 業務 prefix 3 文字 + 通番', {
      example_good: ['MST_USER_001', 'TRN_ORDER_002'],
    }),
    namingRule('db_column', 'snake_case', '小文字スネーク. 日付は _date / 時刻は _time'),
    namingRule('typescript_var', 'camelCase', 'TS 標準'),
    namingRule('typescript_type', 'PascalCase', '型・クラスは Pascal'),
    namingRule('api_path', 'kebab-case', 'REST パス kebab. バージョンは /v1/'),
    namingRule('component', 'PascalCase', 'React コンポーネント'),
    namingRule('file', 'PascalCase', 'Java クラスは PascalCase'),
  ],
  preferred_libraries: [
    {
      language: 'java',
      libraries: [
        { name: 'apworks-framework', reason: '富士通標準フレームワーク' },
        { name: 'jakarta.ee-api', version_range: '10.x', reason: 'Interstage V12 対応' },
        { name: 'logback-classic', version_range: '1.4.x', reason: 'Log4j2 から段階移行' },
        { name: 'junit-jupiter', version_range: '5.x', reason: 'テスト標準' },
        { name: 'mockito-core', version_range: '5.x', reason: 'モック標準' },
      ],
    },
    {
      language: 'typescript',
      libraries: [
        { name: 'react', version_range: '18.x', reason: '富士通フロント標準' },
        { name: 'vite', version_range: '5.x', reason: '社内ビルド標準' },
        { name: 'vitest', version_range: '1.x', reason: 'テスト標準' },
        { name: 'fetch-undici', reason: 'Node 18+ 標準 fetch' },
        { name: 'zod', version_range: '3.x', reason: 'スキーマ検証' },
      ],
    },
  ],
  banned_libraries: [
    {
      language: 'java',
      libraries: [
        { name: 'log4j-core', reason: 'Log4Shell 経緯から社内全面禁止' },
        { name: 'tomcat-embed-core', reason: '富士通標準 AP は Interstage' },
        { name: 'spring-boot', reason: 'Apworks との二重管理になり禁止' },
      ],
    },
    {
      language: 'javascript',
      libraries: [
        { name: 'webpack', reason: '社内ビルドは Vite に統一中' },
        { name: 'jest', reason: '社内 CI は vitest 標準' },
        { name: 'request', reason: 'deprecated パッケージのため新規採用禁止' },
      ],
    },
  ],
  deployment_targets: [
    'FUJITSU Hybrid IT Service FJcloud-V (旧 K5)',
    'FUJITSU Cloud Service for OSS (FOCUS)',
    'AWS Tokyo Region',
    'Azure Japan East (富士通アライアンス)',
    'オンプレミス (FUJITSU PRIMERGY)',
  ],
  documentation_template: {
    sections: [
      { title: '1. システム概要書', outline: '富士通標準 1ページ概要 + ゴール + 関係者一覧。' },
      { title: '2. 業務要件定義書', outline: 'BPMN 業務フロー + 業務一覧 + To-Be 要件。' },
      { title: '3. 機能要件定義書', outline: '機能 ID 採番 + 入出力 + 業務ルール。' },
      { title: '4. 非機能要件定義書', outline: 'IPA 非機能要求グレード + Systemwalker 監視要件。' },
      { title: '5. アーキテクチャ設計書', outline: 'Interstage + Apworks 構成図 + 配置図。' },
      { title: '6. 画面設計書', outline: '画面一覧 + 画面遷移 + 項目定義書。' },
      { title: '7. データベース設計書', outline: 'ERD + テーブル定義 + Symfoware/PostgreSQL 物理設計。' },
      { title: '8. テスト計画書/成績書', outline: '単体/結合/総合/受入。Excel テンプレ準拠。' },
      { title: '9. 運用設計書', outline: 'Systemwalker 監視 + JP1 連携 + 障害対応 Runbook。' },
      { title: '10. 移行設計書', outline: 'データ移行・切替手順・リハーサル計画。' },
    ],
  },
  code_review_checklist: [
    'Apworks の層分離が遵守されているか',
    'Symfoware/PostgreSQL の文字コード (UTF-8) が一貫しているか',
    'Interstage の JNDI 名が Apworks の標準命名と一致しているか',
    'Systemwalker 監視ログ出力が標準 LogFormat を満たしているか',
    'JUnit 5 のテスト命名が Given_When_Then 構造になっているか',
    '個人情報マスキングが共通 AOP で実装されているか',
    'OSS ライセンス情報が社内 OSS Hub に登録済か',
    'コードカバレッジが 75% 以上か',
    '富士通 i-Cure (脆弱性スキャン) が PR 単位で通過しているか',
    'ドキュメントとコードの WBS ID 対応表が更新されているか',
    'PR タイトルに案件番号 (FJ-12345) が付与されているか',
    'OWASP Top10 対応チェック表に署名があるか',
  ],
  qa_gate: {
    coverage_min: 75,
    lighthouse_min: 80,
    security_scan: true,
    static_analysis_tool: 'Fujitsu i-Cure + SonarQube',
    pen_test_required: true,
    load_test_required: true,
    doc_review_required: true,
    notes: 'Systemwalker 監視テンプレが必須。納品物 = ZIP + Word 一式',
  },
};

/* ═══════════════════════════════════════════════════════════
 *   NRI (野村総合研究所) THE STAR Style
 * ═══════════════════════════════════════════════════════════ */

const NRI_TEMPLATE: SierTemplate = {
  sier_id: 'nri',
  display_name: 'NRI',
  display_name_ja: '野村総合研究所',
  architecture: {
    name: 'THE STAR / aslead 開発標準',
    description:
      'NRI の独自フレームワーク "THE STAR" と DevOps 環境 "aslead" を組み合わせる。金融業界向けは BizForge / FENICS が定石。監査要件 (FISC 安対) を満たす多層構造。',
    layers: [
      'Channel (Web/App/Batch)',
      'Service (Java + STAR Service Layer)',
      'Domain (DDD ベース Aggregate)',
      'Repository (JPA + STAR DAO)',
      'Common Infrastructure (aslead OSS スタック)',
      'Audit (FISC 監査ログ)',
    ],
    mandatory_components: [
      'aslead DevOps スイート',
      'THE STAR Application Framework',
      'Spring Framework 6 + Spring Security',
      'Oracle Database 19c / PostgreSQL 15',
      'JUnit 5 + Cucumber',
      'JFrog Artifactory',
    ],
    forbidden_components: [
      'MongoDB (金融系)',
      'GraphQL (金融系)',
      'Edge Functions (国外越境)',
    ],
  },
  naming_rules: [
    namingRule('db_table', 'UPPER_SNAKE', 'NRI 金融標準: 大文字スネーク + 業務 prefix 3 文字'),
    namingRule('db_column', 'snake_case', '小文字スネーク. 監査列は AUD_ 接頭'),
    namingRule('typescript_var', 'camelCase', 'TS 標準'),
    namingRule('typescript_type', 'PascalCase', '型・クラス'),
    namingRule('api_path', 'kebab-case', 'REST kebab + /v1/'),
    namingRule('component', 'PascalCase', 'React コンポーネント'),
    namingRule('file', 'PascalCase', 'Java クラスファイル'),
    namingRule('route', 'kebab-case', 'URL kebab. キャメルは禁止'),
  ],
  preferred_libraries: [
    {
      language: 'java',
      libraries: [
        { name: 'spring-framework', version_range: '6.x', reason: 'THE STAR の前提' },
        { name: 'spring-security', version_range: '6.x', reason: '認可必須' },
        { name: 'spring-boot-starter-web', version_range: '3.x', reason: '社内 boot は OK (NTTデータと差異)' },
        { name: 'lombok', version_range: '1.18.x', reason: 'NRI では許容 (NTTデータと差異)' },
        { name: 'jackson-databind', version_range: '2.16.x', reason: 'JSON 標準' },
        { name: 'cucumber-java', version_range: '7.x', reason: 'BDD 標準' },
      ],
    },
    {
      language: 'typescript',
      libraries: [
        { name: 'react', version_range: '18.x', reason: 'フロント標準' },
        { name: 'next', version_range: '14.x', reason: '社内承認済' },
        { name: 'tanstack-query', reason: 'データ取得標準' },
        { name: 'zod', reason: 'スキーマ検証' },
      ],
    },
  ],
  banned_libraries: [
    {
      language: 'any',
      libraries: [
        { name: 'mongodb', reason: '金融 ACID 要件不足のため' },
        { name: 'graphql', reason: '監査要件 (REST + OpenAPI) 必須のため' },
        { name: 'firebase', reason: 'データ越境リスク' },
      ],
    },
    {
      language: 'javascript',
      libraries: [
        { name: 'request', reason: 'deprecated package' },
        { name: 'moment', reason: 'tree-shake 不可' },
      ],
    },
  ],
  deployment_targets: [
    'NRI プライベートクラウド aslead-Cloud',
    'AWS (NRI ManagedCloud)',
    'Azure Japan East',
    'オンプレ (NRI Tokyo II データセンター)',
  ],
  documentation_template: {
    sections: [
      { title: '1. プロジェクト計画書', outline: 'NRI 案件番号 + Charter + マイルストーン。' },
      { title: '2. 要件定義書', outline: 'BR/FR/NFR の三段階。FISC 安対 / システム監査基準対応。' },
      { title: '3. 基本設計書', outline: 'THE STAR レイヤ図 + ユースケース + 業務ルール。' },
      { title: '4. 詳細設計書', outline: 'クラス図 + シーケンス図 + DB 物理設計 (Oracle 想定)。' },
      { title: '5. 試験計画/成績書', outline: 'CT/IT/ST/UT の 4 階層 + Cucumber feature。' },
      { title: '6. 運用設計書', outline: 'aslead 監視 + 障害対応 + RTO/RPO。' },
      { title: '7. 移行計画書', outline: 'データ移行 + 切替リハーサル + ロールバック計画。' },
      { title: '8. セキュリティ設計書', outline: 'FISC 安対対応表 + OWASP ASVS L3。' },
    ],
  },
  code_review_checklist: [
    'THE STAR レイヤ違反が無いか',
    'FISC 安対のチェック項目に対する設計記述があるか',
    'Spring Security の認可設定が role + scope ベースか',
    'Cucumber feature ファイルが日本語シナリオで網羅されているか',
    '監査ログ (AUD_*) の挿入が DAO に統一されているか',
    'OSS は aslead OSS リスト承認済か',
    'JFrog Artifactory にビルド成果物が登録されているか',
    'カバレッジ 85% (金融案件) を超えているか',
    'PR 単位の脆弱性スキャン (Snyk) が PASS か',
    '個人情報の暗号化 (KMS) が共通モジュール経由か',
    'i18n の文言キーが NRI 標準フォーマットか',
    'DB マイグレーションが Liquibase で管理されているか',
  ],
  qa_gate: {
    coverage_min: 85,
    lighthouse_min: 85,
    security_scan: true,
    static_analysis_tool: 'SonarQube + Snyk',
    pen_test_required: true,
    load_test_required: true,
    doc_review_required: true,
    notes: '金融案件は FISC 安対チェックシート + システム監査基準完了が必須',
  },
};

/* ═══════════════════════════════════════════════════════════
 *   野村総研 (Nomura Holdings 系 in-house) Style
 *   ※ NRI と区別。Nomura (証券・HD 系内製) を想定
 * ═══════════════════════════════════════════════════════════ */

const NOMURA_TEMPLATE: SierTemplate = {
  sier_id: 'nomura',
  display_name: 'Nomura Holdings (Internal)',
  display_name_ja: '野村ホールディングス (内製)',
  architecture: {
    name: 'NSP (Nomura Service Platform) / Quantum FX 系',
    description:
      '野村証券グループの内製プラットフォーム。低レイテンシ + FISC 安対 + 海外規制 (SEC/FCA) 同時準拠が必須。Java + Aeron / Chronicle で低レイテンシ、後段は Spring + Oracle。',
    layers: [
      'Edge (Aeron / Chronicle for low latency)',
      'Gateway (Spring Cloud Gateway)',
      'Service (Spring + DDD)',
      'Persistence (Oracle 19c + Aurora PostgreSQL)',
      'Audit/Compliance (Splunk + 内製コンプラ DSL)',
      'Reporting (Power BI + 内製レポジ)',
    ],
    mandatory_components: [
      'Spring Framework 6.x',
      'Aeron / Chronicle (低レイテンシ)',
      'Oracle Database 19c',
      'Splunk Enterprise',
      'JUnit 5 + JMH',
      'Datadog APM',
    ],
    forbidden_components: [
      'MongoDB',
      'Firebase',
      'Edge Functions (国外越境)',
      'CDN Edge Workers (規制データ含む場合)',
    ],
  },
  naming_rules: [
    namingRule('db_table', 'UPPER_SNAKE', '野村標準: 大文字スネーク + 業務 prefix (TRD_/MKT_/CMP_)'),
    namingRule('db_column', 'snake_case', '小文字スネーク. PII は ENC_ 接頭で暗号化必須'),
    namingRule('typescript_var', 'camelCase', '社内 BFF 標準'),
    namingRule('typescript_type', 'PascalCase', '型 Pascal'),
    namingRule('api_path', 'kebab-case', 'REST API kebab + /v1/'),
    namingRule('component', 'PascalCase', 'React コンポーネント'),
    namingRule('file', 'PascalCase', 'Java クラス'),
  ],
  preferred_libraries: [
    {
      language: 'java',
      libraries: [
        { name: 'spring-framework', version_range: '6.x', reason: '社内標準' },
        { name: 'aeron', reason: '低レイテンシ messaging' },
        { name: 'chronicle-queue', reason: '永続キュー' },
        { name: 'jmh', reason: '性能測定標準' },
        { name: 'micrometer-tracing', reason: '分散トレース標準' },
      ],
    },
    {
      language: 'typescript',
      libraries: [
        { name: 'react', version_range: '18.x', reason: 'BFF フロント' },
        { name: 'next', version_range: '14.x', reason: '社内承認' },
        { name: 'd3', version_range: '7.x', reason: 'チャート標準' },
      ],
    },
    {
      language: 'python',
      libraries: [
        { name: 'pandas', reason: '社内クオンツ標準' },
        { name: 'numpy', reason: '同上' },
      ],
    },
  ],
  banned_libraries: [
    {
      language: 'any',
      libraries: [
        { name: 'mongodb', reason: 'FISC 安対準拠困難' },
        { name: 'firebase', reason: '海外データ越境' },
        { name: 'cdn-edge-functions', reason: 'データ国外配置リスク' },
      ],
    },
    {
      language: 'javascript',
      libraries: [
        { name: 'moment', reason: 'tree-shake 不可' },
        { name: 'request', reason: 'deprecated' },
      ],
    },
  ],
  deployment_targets: [
    '社内プライベートクラウド (Tokyo + Singapore + London)',
    'AWS Tokyo Region (規制適合済アカウント)',
    'AWS London Region (FCA 適合)',
    'AWS NY Region (SEC 適合)',
  ],
  documentation_template: {
    sections: [
      { title: '1. Charter / Project Plan', outline: '案件番号 + 関係部門 + リスクオーナー。' },
      { title: '2. Business Requirements', outline: '取引フロー + 法規制対応 (FISC/SEC/FCA)。' },
      { title: '3. Functional Spec', outline: '機能 ID + ユースケース + 例外処理。' },
      { title: '4. Non-Functional Spec', outline: 'Latency budget (例: <10ms p99) + 可用性 99.99%。' },
      { title: '5. Architecture Spec', outline: 'NSP レイヤ図 + Aeron 通信図。' },
      { title: '6. Data Model', outline: 'ERD + 暗号化方針 + データ保持期間。' },
      { title: '7. Test Plan/Result', outline: '単体/結合/性能 (JMH)/受入。' },
      { title: '8. Operations Spec', outline: 'Splunk 監視 + Datadog APM + 障害対応。' },
      { title: '9. Security/Compliance', outline: 'FISC + ISO27001 + GDPR/CCPA 対応表。' },
    ],
  },
  code_review_checklist: [
    'p99 latency budget を超過していないか (JMH ベンチ通過)',
    'FISC 安対チェックリスト準拠か',
    '個人情報/取引情報の暗号化 (KMS + Vault) が必須',
    'Splunk 監査ログにイベントが記録されるか',
    '海外データ越境していないか (リージョン明示)',
    'Aeron / Chronicle の termBuffer 設定が適切か',
    'JMH ベンチが nightly で計測されているか',
    'Datadog APM trace タグが付与されているか',
    'OWASP ASVS L3 準拠か',
    '社内コンプラ DSL のチェックが PR 単位で PASS か',
    'カバレッジ 90% (取引コア) を満たすか',
    'OSS ライセンスが社内 OSS 委員会承認済か',
  ],
  qa_gate: {
    coverage_min: 90,
    lighthouse_min: 85,
    security_scan: true,
    static_analysis_tool: 'SonarQube + Veracode + 内製 DSL',
    pen_test_required: true,
    load_test_required: true,
    doc_review_required: true,
    notes: 'p99 latency / 海外規制適合の二重ゲート',
  },
};

/* ═══════════════════════════════════════════════════════════
 *   NEC WebSAM / WebOTX Style
 * ═══════════════════════════════════════════════════════════ */

const NEC_TEMPLATE: SierTemplate = {
  sier_id: 'nec',
  display_name: 'NEC',
  display_name_ja: '日本電気 (NEC)',
  architecture: {
    name: 'WebOTX + WebSAM 標準 (公共/通信業向け)',
    description:
      'NEC の AP サーバ "WebOTX" と運用統合管理 "WebSAM" を中核とする。公共系では SX-Aurora / Spica DB と組み合わせ、官公庁 LGWAN 環境にも適合させる構成。',
    layers: [
      'Presentation (WebOTX Web Edition)',
      'Application (WebOTX Standard / Enterprise)',
      'Persistence (Oracle / Spica / PostgreSQL)',
      'Operation (WebSAM JobCenter / SystemManager)',
      'Integration (WebOTX ESB)',
    ],
    mandatory_components: [
      'WebOTX Application Server V11',
      'WebSAM JobCenter / SystemManager',
      'Oracle Database 19c または Spica DB',
      'JDK 17',
      'JUnit 5',
    ],
    forbidden_components: [
      'JBoss',
      'Apache Cassandra',
      'Puppet (社内標準は Ansible)',
    ],
  },
  naming_rules: [
    namingRule('db_table', 'UPPER_SNAKE', 'NEC 公共系標準: 大文字スネーク + 業務略号 (KOKU_/CHIHO_)'),
    namingRule('db_column', 'snake_case', '小文字スネーク. 削除フラグは del_flg'),
    namingRule('typescript_var', 'camelCase', 'TS 標準'),
    namingRule('typescript_type', 'PascalCase', '型 Pascal'),
    namingRule('api_path', 'kebab-case', 'REST API kebab + /v1/'),
    namingRule('component', 'PascalCase', 'React コンポーネント'),
    namingRule('file', 'PascalCase', 'Java クラスファイル'),
  ],
  preferred_libraries: [
    {
      language: 'java',
      libraries: [
        { name: 'webotx-cdi-api', reason: 'NEC 標準 CDI 実装' },
        { name: 'jakarta.ee-api', version_range: '10.x', reason: 'Jakarta EE 10' },
        { name: 'spring-framework', version_range: '6.x', reason: 'PoC・新規系で許容' },
        { name: 'mybatis', version_range: '3.5.x', reason: 'NEC 公共系で多用' },
        { name: 'junit-jupiter', version_range: '5.x', reason: 'テスト標準' },
      ],
    },
    {
      language: 'typescript',
      libraries: [
        { name: 'react', version_range: '18.x', reason: 'フロント標準' },
        { name: 'vite', reason: 'ビルド標準' },
        { name: 'vitest', reason: 'テスト標準' },
      ],
    },
  ],
  banned_libraries: [
    {
      language: 'java',
      libraries: [
        { name: 'jboss-as', reason: 'NEC 標準は WebOTX' },
        { name: 'wildfly', reason: '同上' },
      ],
    },
    {
      language: 'any',
      libraries: [
        { name: 'apache-cassandra', reason: '保守要員確保困難' },
        { name: 'puppet', reason: '社内標準は Ansible/WebSAM' },
      ],
    },
  ],
  deployment_targets: [
    'NEC Cloud IaaS',
    'AWS (NEC ManagedCloud)',
    'Azure (NEC アライアンス)',
    'オンプレ (NEC Express5800)',
    'LGWAN-ASP 接続環境',
  ],
  documentation_template: {
    sections: [
      { title: '1. システム概要書', outline: '案件全体像 + 関係省庁/部門。' },
      { title: '2. 要件定義書', outline: 'BR/FR/NFR + LGWAN 接続要件。' },
      { title: '3. 基本設計書', outline: 'WebOTX/WebSAM 構成図 + 業務フロー。' },
      { title: '4. 詳細設計書', outline: 'クラス図/シーケンス + DB 物理設計。' },
      { title: '5. 試験計画/成績書', outline: '4 階層 + 公共向け追加項目。' },
      { title: '6. 運用設計書', outline: 'WebSAM JobCenter ジョブ + 監視設計。' },
      { title: '7. 移行設計書', outline: 'データ移行 + 切替手順。' },
      { title: '8. セキュリティ設計書', outline: '政府統一基準 + ISMAP 対応表。' },
    ],
  },
  code_review_checklist: [
    'WebOTX Application Server 設定が標準値か',
    'WebSAM JobCenter のジョブネット定義が ER 図と整合しているか',
    'LGWAN 接続要件 (TLS 1.2 以上 + IP 制限) を満たすか',
    'OSS ライセンスが社内 OSS 委員会承認済か',
    'カバレッジ 80% を超えているか',
    '個人情報項目に暗号化 (NEC CipherCraft) が適用されているか',
    'PR タイトルに案件番号 + WBS-ID が付与されているか',
    'OWASP ASVS L2 準拠か',
    '政府統一基準 (R5 改定版) のチェックリストに署名があるか',
    'ジョブの再実行性 (リスタート起点) が定義されているか',
    'WebOTX のセッション管理が共通設定経由か',
    'バッチ I/O の文字コード (UTF-8 / EBCDIC) が明示されているか',
  ],
  qa_gate: {
    coverage_min: 80,
    lighthouse_min: 80,
    security_scan: true,
    static_analysis_tool: 'SonarQube + NEC CipherSecurity',
    pen_test_required: true,
    load_test_required: true,
    doc_review_required: true,
    notes: '公共系は ISMAP / 政府統一基準 (R5 改定) のチェックリスト必須',
  },
};

/* ═══════════════════════════════════════════════════════════
 *   日立 Cosminexus / JP1 Style
 * ═══════════════════════════════════════════════════════════ */

const HITACHI_TEMPLATE: SierTemplate = {
  sier_id: 'hitachi',
  display_name: 'Hitachi',
  display_name_ja: '日立製作所',
  architecture: {
    name: 'Cosminexus + JP1 標準',
    description:
      '日立の Application Server "Cosminexus" と統合運用管理 "JP1" を中核とする。重要インフラ系・社会システム向けに信頼性 5 ナイン (99.999%) を狙う構成。',
    layers: [
      'Presentation (Cosminexus Web Container)',
      'Business (Cosminexus EJB Container)',
      'Persistence (HiRDB / Oracle)',
      'Integration (Cosminexus Integration Platform)',
      'Operation (JP1/IT Service Management + JP1/AJS3)',
    ],
    mandatory_components: [
      'Cosminexus Application Server V11',
      'JP1/AJS3 (Automatic Job Management)',
      'JP1/IT Service Management',
      'HiRDB or Oracle 19c',
      'JDK 17',
      'JUnit 5',
    ],
    forbidden_components: [
      'Apache Tomcat (単独)',
      'GraphQL (JP1 連携不可のため)',
      'Jenkins-Pipeline (補助のみ)',
    ],
  },
  naming_rules: [
    namingRule('db_table', 'UPPER_SNAKE', '日立標準: 大文字スネーク + 業務 prefix (HIT_/MFG_/INFRA_)'),
    namingRule('db_column', 'snake_case', '小文字スネーク. 監査列は AUD_ 接頭'),
    namingRule('typescript_var', 'camelCase', 'TS 標準'),
    namingRule('typescript_type', 'PascalCase', '型 Pascal'),
    namingRule('api_path', 'kebab-case', 'REST kebab + /v1/'),
    namingRule('component', 'PascalCase', 'React コンポーネント'),
    namingRule('file', 'PascalCase', 'Java クラス'),
  ],
  preferred_libraries: [
    {
      language: 'java',
      libraries: [
        { name: 'cosminexus-component', reason: '日立標準コンポーネント' },
        { name: 'jakarta.ee-api', version_range: '10.x', reason: 'Cosminexus 11 の前提' },
        { name: 'spring-framework', version_range: '6.x', reason: '新規系で併用可' },
        { name: 'mybatis', version_range: '3.5.x', reason: 'HiRDB と相性良' },
        { name: 'junit-jupiter', version_range: '5.x', reason: 'テスト標準' },
      ],
    },
    {
      language: 'typescript',
      libraries: [
        { name: 'react', version_range: '18.x', reason: 'フロント標準' },
        { name: 'vite', reason: 'ビルド標準' },
        { name: 'zod', reason: 'スキーマ検証' },
        { name: 'tanstack-query', reason: 'データ取得標準' },
      ],
    },
  ],
  banned_libraries: [
    {
      language: 'java',
      libraries: [
        { name: 'tomcat-embed-core', reason: '日立標準は Cosminexus' },
        { name: 'log4j-core', reason: 'Log4Shell 経緯から非推奨' },
      ],
    },
    {
      language: 'any',
      libraries: [
        { name: 'graphql', reason: 'JP1 連携対象外のため監査外' },
        { name: 'jenkins-pipeline', reason: '日立標準は JP1/AJS3' },
      ],
    },
  ],
  deployment_targets: [
    '日立クラウド SaaS / IaaS',
    'AWS (日立アライアンス)',
    'Azure (日立アライアンス)',
    'オンプレ (日立 BladeSymphony)',
    'OT 環境 (制御系/工場)',
  ],
  documentation_template: {
    sections: [
      { title: '1. プロジェクト計画書', outline: '案件 ID + マイルストーン + リスク登録簿。' },
      { title: '2. 要件定義書', outline: 'BR/FR/NFR + 安全要件 (機能安全 IEC 61508 系)。' },
      { title: '3. 基本設計書', outline: 'Cosminexus + JP1 構成図。' },
      { title: '4. 詳細設計書', outline: 'クラス図/シーケンス + HiRDB 物理設計。' },
      { title: '5. 試験計画/成績書', outline: '4 階層 + フェイルオーバ試験。' },
      { title: '6. 運用設計書', outline: 'JP1/AJS3 + JP1/ITSM + ランブック。' },
      { title: '7. 信頼性設計書', outline: '可用性 99.999% / FMEA / FTA。' },
      { title: '8. 移行設計書', outline: 'データ移行 + 切替リハーサル + ロールバック。' },
      { title: '9. セキュリティ設計書', outline: 'CSIRT 対応 + 政府統一基準。' },
    ],
  },
  code_review_checklist: [
    'Cosminexus のクラスローダ階層が標準値か',
    'JP1 ジョブネットが業務フローと一致しているか',
    'HiRDB の表領域設計が承認図と一致しているか',
    'フェイルオーバ試験が試験計画書に組み込まれているか',
    'カバレッジ 85% を満たすか (社会システムは厳格)',
    'OSS ライセンスが社内 OSS Hub 承認済か',
    'PR タイトルに案件番号 + JIRA キーが付与されているか',
    'OWASP ASVS L2 以上か',
    'CSIRT 連絡経路が運用設計書に記載されているか',
    'ジョブの異常終了パターンが網羅されているか',
    '監査ログ (AUD_*) が共通モジュール経由で出力されるか',
    '機能安全要件 (IEC 61508) のトレーサビリティ表があるか',
  ],
  qa_gate: {
    coverage_min: 85,
    lighthouse_min: 85,
    security_scan: true,
    static_analysis_tool: 'SonarQube + 日立 Hitachi Cyber Defender',
    pen_test_required: true,
    load_test_required: true,
    doc_review_required: true,
    notes: '社会インフラ系は機能安全/フェイルオーバ試験必須',
  },
};

/* ═══════════════════════════════════════════════════════════
 *   TIS Inc. (TIDS) Style
 * ═══════════════════════════════════════════════════════════ */

const TIS_TEMPLATE: SierTemplate = {
  sier_id: 'tis',
  display_name: 'TIS Inc.',
  display_name_ja: 'TIS',
  architecture: {
    name: 'TIDS (TIS Integrated Development Standard) / Xenlon Cloud Native',
    description:
      'TIS の標準アーキテクチャは Spring Boot + React + AWS/Azure のクラウドネイティブ。金融・カード・公共向けに Xenlon プラットフォームを併用。コンテナ化を強く推奨。',
    layers: [
      'Frontend (Next.js / React)',
      'BFF (Spring Boot WebFlux)',
      'Service (Spring Boot 3 + DDD)',
      'Persistence (PostgreSQL 15 / MySQL 8)',
      'Cloud Native (EKS / AKS + Istio)',
      'CI/CD (GitHub Actions + ArgoCD)',
    ],
    mandatory_components: [
      'Spring Boot 3.x',
      'Next.js 14 / React 18',
      'PostgreSQL 15',
      'Kubernetes (EKS or AKS)',
      'Terraform',
      'GitHub Actions + ArgoCD',
    ],
    forbidden_components: [
      'Aurelia (旧式)',
      'Rancher (社内非標準)',
      'MongoDB (公共系)',
    ],
  },
  naming_rules: [
    namingRule('db_table', 'snake_case', 'TIS は小文字スネーク主流 (PostgreSQL ベース)'),
    namingRule('db_column', 'snake_case', '小文字スネーク'),
    namingRule('typescript_var', 'camelCase', 'TS 標準'),
    namingRule('typescript_type', 'PascalCase', '型 Pascal'),
    namingRule('api_path', 'kebab-case', 'REST kebab + /v1/'),
    namingRule('component', 'PascalCase', 'React コンポーネント'),
    namingRule('file', 'kebab-case', 'TS/JS ファイルは kebab-case (Next.js App Router)'),
    namingRule('route', 'kebab-case', 'URL kebab'),
  ],
  preferred_libraries: [
    {
      language: 'java',
      libraries: [
        { name: 'spring-boot-starter-web', version_range: '3.x', reason: 'TIS 標準' },
        { name: 'spring-boot-starter-webflux', version_range: '3.x', reason: 'BFF 標準' },
        { name: 'spring-data-jpa', version_range: '3.x', reason: 'ORM 標準' },
        { name: 'lombok', version_range: '1.18.x', reason: 'TIS では許容' },
        { name: 'flyway-core', version_range: '10.x', reason: 'マイグレーション標準' },
      ],
    },
    {
      language: 'typescript',
      libraries: [
        { name: 'next', version_range: '14.x', reason: 'フロント標準' },
        { name: 'react', version_range: '18.x', reason: 'フロント標準' },
        { name: 'tailwindcss', version_range: '3.x', reason: 'スタイル標準' },
        { name: 'zod', version_range: '3.x', reason: 'バリデーション' },
        { name: 'tanstack-query', reason: 'データ取得' },
        { name: 'vitest', version_range: '1.x', reason: 'テスト' },
        { name: 'playwright', version_range: '1.x', reason: 'E2E' },
      ],
    },
    {
      language: 'go',
      libraries: [
        { name: 'gin-gonic/gin', reason: 'API フレームワーク (PoC 用)' },
        { name: 'spf13/cobra', reason: 'CLI 標準' },
      ],
    },
  ],
  banned_libraries: [
    {
      language: 'javascript',
      libraries: [
        { name: 'aurelia', reason: '保守困難で採用しない' },
        { name: 'angularjs', reason: 'EOL のため' },
        { name: 'jquery', reason: '新規採用禁止' },
      ],
    },
    {
      language: 'any',
      libraries: [
        { name: 'rancher', reason: 'TIS インフラ標準は EKS/AKS' },
        { name: 'mongodb', reason: '公共系では採用しない' },
      ],
    },
  ],
  deployment_targets: [
    'AWS (TIS Managed Cloud)',
    'Azure (TIS Managed Cloud)',
    'Xenlon Platform (TIS 内製クラウド)',
    'EKS / AKS',
    'オンプレ (TIS データセンター)',
  ],
  documentation_template: {
    sections: [
      { title: '1. プロジェクト Charter', outline: 'スコープ + ステークホルダ + 価値 KPI。' },
      { title: '2. 要件定義書', outline: 'BR/FR/NFR + リスク + 制約。' },
      { title: '3. システム設計書', outline: 'マイクロサービス分割 + API 設計 + データ設計。' },
      { title: '4. 開発標準書', outline: 'TIDS コーディング規約 + Git Flow + PR テンプレ。' },
      { title: '5. インフラ設計書', outline: 'Terraform + EKS + Istio + 監視。' },
      { title: '6. 試験計画/成績書', outline: '単体 (Vitest/JUnit) + 結合 + E2E (Playwright)。' },
      { title: '7. 運用設計書', outline: 'PagerDuty / Datadog + ランブック + SLO。' },
      { title: '8. セキュリティ設計書', outline: 'OWASP ASVS L2 + Snyk + 個人情報保護。' },
    ],
  },
  code_review_checklist: [
    'マイクロサービス境界 (Bounded Context) が崩れていないか',
    'OpenAPI 仕様書がコードと同期しているか (linter PASS)',
    'Terraform plan の差分が PR に貼られているか',
    'カバレッジ 80% を満たすか',
    'Snyk / Trivy の脆弱性が High 以下か',
    'GitHub Actions の matrix が node 18/20 通過しているか',
    'PR タイトルに JIRA キーが付与されているか',
    'OWASP Top10 対応チェックがあるか',
    'feature flag の trunk-based 開発を逸脱していないか',
    'ArgoCD の sync が Green か',
    'Datadog の SLO アラートが構成されているか',
    'コミットメッセージが Conventional Commits 準拠か',
    'i18n の文言キーが TIS 標準フォーマットか',
  ],
  qa_gate: {
    coverage_min: 80,
    lighthouse_min: 90,
    security_scan: true,
    static_analysis_tool: 'SonarQube + Snyk + Trivy',
    pen_test_required: true,
    load_test_required: true,
    doc_review_required: true,
    notes: 'クラウドネイティブ前提。SLO ベースの運用が必須',
  },
};

/* ═══════════════════════════════════════════════════════════
 *   Generic (中堅 SIer / 受託開発標準)
 * ═══════════════════════════════════════════════════════════ */

const GENERIC_TEMPLATE: SierTemplate = {
  sier_id: 'generic',
  display_name: 'Generic SIer',
  display_name_ja: '汎用 SI / 中堅受託開発',
  architecture: {
    name: 'Modern Web Stack (Next.js + Node + Postgres)',
    description:
      '中堅 SIer / 受託開発で広く採用される標準構成。Next.js + Prisma + PostgreSQL + Vercel/AWS。Claude Code 互換性を重視し、SIer 固有制約を最小限にする。',
    layers: [
      'Frontend (Next.js App Router)',
      'API Routes / Server Actions',
      'Service Layer (TypeScript)',
      'Persistence (Prisma + PostgreSQL)',
      'Auth (Auth.js / Clerk)',
      'CI/CD (GitHub Actions)',
    ],
    mandatory_components: [
      'Next.js 14+',
      'TypeScript 5.x',
      'PostgreSQL 15+',
      'Prisma 5.x or Drizzle ORM',
      'Vitest 1.x',
      'Playwright 1.x',
    ],
    forbidden_components: [
      'jQuery 単独構成',
      'PHP 5.x',
      'Internet Explorer 専用 JS',
    ],
  },
  naming_rules: [
    namingRule('db_table', 'snake_case', '一般的: 小文字スネーク (PostgreSQL 流儀)'),
    namingRule('db_column', 'snake_case', '小文字スネーク'),
    namingRule('typescript_var', 'camelCase', 'TS 標準'),
    namingRule('typescript_type', 'PascalCase', '型 Pascal'),
    namingRule('api_path', 'kebab-case', 'REST kebab'),
    namingRule('component', 'PascalCase', 'React コンポーネント'),
    namingRule('file', 'kebab-case', 'Next.js App Router 標準'),
    namingRule('route', 'kebab-case', 'URL kebab'),
  ],
  preferred_libraries: [
    {
      language: 'typescript',
      libraries: [
        { name: 'next', version_range: '14.x', reason: 'フロント+API 標準' },
        { name: 'react', version_range: '18.x', reason: '標準' },
        { name: 'prisma', version_range: '5.x', reason: 'ORM 標準' },
        { name: 'zod', version_range: '3.x', reason: 'バリデーション標準' },
        { name: 'tailwindcss', version_range: '3.x', reason: 'スタイル' },
        { name: 'vitest', version_range: '1.x', reason: 'テスト' },
        { name: 'playwright', version_range: '1.x', reason: 'E2E' },
      ],
    },
    {
      language: 'python',
      libraries: [
        { name: 'fastapi', version_range: '0.110.x', reason: 'API 用' },
        { name: 'pydantic', version_range: '2.x', reason: 'バリデーション' },
      ],
    },
  ],
  banned_libraries: [
    {
      language: 'javascript',
      libraries: [
        { name: 'request', reason: 'deprecated package (2020)' },
        { name: 'moment', reason: 'tree-shake 不可' },
        { name: 'jquery', reason: '新規採用は推奨しない' },
      ],
    },
    {
      language: 'java',
      libraries: [
        { name: 'log4j-core', reason: 'Log4Shell 系統は 2.17.1+ のみ' },
      ],
    },
  ],
  deployment_targets: [
    'Vercel',
    'AWS (Lambda + RDS)',
    'Cloudflare Pages',
    'Railway / Render',
    'オンプレミス (Docker Swarm / k3s)',
  ],
  documentation_template: {
    sections: [
      { title: '1. プロジェクト概要', outline: 'ゴール + ステークホルダ + 期間。' },
      { title: '2. 要件定義書', outline: '機能要件 + 非機能要件 + 制約。' },
      { title: '3. システム構成図', outline: 'クラウド構成 + データフロー。' },
      { title: '4. データベース設計書', outline: 'ERD + テーブル定義 + マイグレーション計画。' },
      { title: '5. API 仕様書', outline: 'OpenAPI 3.1 ベース + 認可方針。' },
      { title: '6. 試験計画/成績書', outline: '単体 + 結合 + E2E。' },
      { title: '7. 運用手順書', outline: 'デプロイ + 監視 + 障害対応。' },
      { title: '8. セキュリティ要件', outline: 'OWASP Top10 + 個人情報保護法。' },
    ],
  },
  code_review_checklist: [
    'TypeScript strict mode を有効にしているか',
    'Zod バリデーションが API 入力に存在するか',
    'Prisma migration が PR に同梱されているか',
    'カバレッジ 70% を満たすか',
    'Lighthouse Performance >= 80 か',
    'OWASP Top10 (A01-A10) 対応チェックがあるか',
    'PR タイトルに issue 番号があるか',
    '環境変数が .env.example にも反映されているか',
    'README が更新されているか',
    '依存ライブラリの脆弱性が npm audit で moderate 以下か',
    '日本語/英語の i18n キーが揃っているか',
    'コミットメッセージが Conventional Commits 準拠か',
  ],
  qa_gate: {
    coverage_min: 70,
    lighthouse_min: 80,
    security_scan: true,
    static_analysis_tool: 'ESLint + Biome + Snyk',
    pen_test_required: false,
    load_test_required: false,
    doc_review_required: true,
    notes: '中堅 SIer ベースライン。要件次第で NTTデータ/NRI 級に引き上げ可',
  },
};

/* ─────  内蔵雛形マップ ───── */

export const BUILTIN_SIER_TEMPLATES: Record<SierId, SierTemplate> = {
  nttdata: NTTDATA_TEMPLATE,
  fujitsu: FUJITSU_TEMPLATE,
  nri: NRI_TEMPLATE,
  nomura: NOMURA_TEMPLATE,
  nec: NEC_TEMPLATE,
  hitachi: HITACHI_TEMPLATE,
  tis: TIS_TEMPLATE,
  generic: GENERIC_TEMPLATE,
};

/* ───── API ───── */

export function getSierTemplate(sier_id: SierId): SierTemplate {
  const t = BUILTIN_SIER_TEMPLATES[sier_id];
  if (!t) {
    // SierId 型の変動に備えてフェイルセーフ
    return BUILTIN_SIER_TEMPLATES.generic;
  }
  return t;
}

/**
 * 雛形をプロジェクトディレクトリに書き出す。
 * 生成ファイル:
 *   - .soloptilink/sier-template.json (構造化メタデータ)
 *   - .soloptilink/naming.json
 *   - .eslintrc.sier.cjs (命名 lint 用ヒント)
 *   - .checklist.md (コードレビューチェックリスト)
 *   - docs/00_overview.md (アーキ概要)
 *   - docs/01_documentation_outline.md (章立て)
 *   - docs/02_qa_gate.md (QA ゲート)
 *   - docs/03_libraries.md (推奨/禁止ライブラリ)
 *   - docs/04_deployment.md (デプロイ先)
 */
export function applySierTemplateToProject(
  sier_id: SierId,
  target_dir: string
): { applied: string[]; skipped: string[] } {
  const tmpl = getSierTemplate(sier_id);
  const applied: string[] = [];
  const skipped: string[] = [];

  if (!fs.existsSync(target_dir)) {
    fs.mkdirSync(target_dir, { recursive: true });
  }

  const dotDir = path.join(target_dir, '.soloptilink');
  const docsDir = path.join(target_dir, 'docs');
  if (!fs.existsSync(dotDir)) fs.mkdirSync(dotDir, { recursive: true });
  if (!fs.existsSync(docsDir)) fs.mkdirSync(docsDir, { recursive: true });

  const files: { rel: string; content: string }[] = [
    {
      rel: '.soloptilink/sier-template.json',
      content: JSON.stringify(tmpl, null, 2),
    },
    {
      rel: '.soloptilink/naming.json',
      content: JSON.stringify(tmpl.naming_rules, null, 2),
    },
    {
      rel: '.eslintrc.sier.cjs',
      content: buildEslintHint(tmpl),
    },
    {
      rel: '.checklist.md',
      content: buildChecklistMd(tmpl),
    },
    {
      rel: 'docs/00_overview.md',
      content: buildOverviewMd(tmpl),
    },
    {
      rel: 'docs/01_documentation_outline.md',
      content: buildDocOutlineMd(tmpl),
    },
    {
      rel: 'docs/02_qa_gate.md',
      content: buildQaGateMd(tmpl),
    },
    {
      rel: 'docs/03_libraries.md',
      content: buildLibrariesMd(tmpl),
    },
    {
      rel: 'docs/04_deployment.md',
      content: buildDeploymentMd(tmpl),
    },
  ];

  for (const f of files) {
    const abs = path.join(target_dir, f.rel);
    if (fs.existsSync(abs)) {
      skipped.push(f.rel);
      continue;
    }
    const dir = path.dirname(abs);
    if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(abs, f.content, 'utf-8');
    applied.push(f.rel);
  }

  return { applied, skipped };
}

/* ───── 比較表 ───── */

export interface CompareDifference {
  aspect: string;
  values: Record<SierId, unknown>;
}

export function compareSierTemplates(
  siers: SierId[]
): { differences: CompareDifference[] } {
  const aspects: { key: string; pick: (t: SierTemplate) => unknown }[] = [
    { key: 'architecture.name', pick: (t) => t.architecture.name },
    { key: 'architecture.layers.count', pick: (t) => t.architecture.layers.length },
    { key: 'naming.db_table', pick: (t) => t.naming_rules.find((r) => r.scope === 'db_table')?.case_style },
    { key: 'naming.api_path', pick: (t) => t.naming_rules.find((r) => r.scope === 'api_path')?.case_style },
    { key: 'preferred.languages', pick: (t) => t.preferred_libraries.map((g) => g.language).sort() },
    {
      key: 'preferred.count',
      pick: (t) => t.preferred_libraries.reduce((s, g) => s + g.libraries.length, 0),
    },
    {
      key: 'banned.count',
      pick: (t) => t.banned_libraries.reduce((s, g) => s + g.libraries.length, 0),
    },
    { key: 'deployment.primary', pick: (t) => t.deployment_targets[0] },
    { key: 'qa.coverage_min', pick: (t) => t.qa_gate.coverage_min },
    { key: 'qa.lighthouse_min', pick: (t) => t.qa_gate.lighthouse_min ?? 'n/a' },
    { key: 'qa.pen_test_required', pick: (t) => t.qa_gate.pen_test_required ?? false },
    { key: 'qa.load_test_required', pick: (t) => t.qa_gate.load_test_required ?? false },
    { key: 'qa.static_analysis_tool', pick: (t) => t.qa_gate.static_analysis_tool ?? 'n/a' },
    { key: 'docs.section_count', pick: (t) => t.documentation_template.sections.length },
    { key: 'review.checklist_count', pick: (t) => t.code_review_checklist.length },
  ];

  const differences: CompareDifference[] = [];

  for (const a of aspects) {
    const values: Record<SierId, unknown> = {} as Record<SierId, unknown>;
    for (const id of siers) {
      values[id] = a.pick(getSierTemplate(id));
    }
    differences.push({ aspect: a.key, values });
  }

  return { differences };
}

/* ───── Markdown ビルダ ───── */

function buildEslintHint(t: SierTemplate): string {
  const tsVar = t.naming_rules.find((r) => r.scope === 'typescript_var')?.case_style ?? 'camelCase';
  const tsType = t.naming_rules.find((r) => r.scope === 'typescript_type')?.case_style ?? 'PascalCase';
  return [
    `// SoloptiLinkAI Tenant DNA: SIer 命名規則ヒント (${t.display_name_ja})`,
    `// このファイルは雛形です。実プロジェクトの .eslintrc.* に追記してください。`,
    `module.exports = {`,
    `  rules: {`,
    `    '@typescript-eslint/naming-convention': [`,
    `      'error',`,
    `      { selector: 'variableLike', format: ['${mapEslintCase(tsVar)}'] },`,
    `      { selector: 'typeLike',     format: ['${mapEslintCase(tsType)}'] },`,
    `    ],`,
    `  },`,
    `};`,
    ``,
  ].join('\n');
}

function mapEslintCase(c: NamingCase): string {
  switch (c) {
    case 'camelCase':
      return 'camelCase';
    case 'PascalCase':
      return 'PascalCase';
    case 'snake_case':
      return 'snake_case';
    case 'UPPER_SNAKE':
      return 'UPPER_CASE';
    case 'kebab-case':
      // ESLint naming-convention は kebab を直接扱わない。Pascal/camel 互換にフォールバック
      return 'camelCase';
    case 'mixed':
    default:
      return 'camelCase';
  }
}

function buildChecklistMd(t: SierTemplate): string {
  const head = `# Code Review Checklist — ${t.display_name_ja} 標準\n\n`;
  const items = t.code_review_checklist.map((c, i) => `- [ ] ${i + 1}. ${c}`).join('\n');
  return head + items + '\n';
}

function buildOverviewMd(t: SierTemplate): string {
  return [
    `# ${t.display_name_ja} Architecture Overview`,
    ``,
    `## ${t.architecture.name}`,
    ``,
    t.architecture.description,
    ``,
    `## Layers`,
    ``,
    ...t.architecture.layers.map((l) => `- ${l}`),
    ``,
    `## Mandatory Components`,
    ``,
    ...t.architecture.mandatory_components.map((c) => `- ${c}`),
    ``,
    ...(t.architecture.forbidden_components && t.architecture.forbidden_components.length > 0
      ? [`## Forbidden Components`, ``, ...t.architecture.forbidden_components.map((c) => `- ${c}`), ``]
      : []),
  ].join('\n');
}

function buildDocOutlineMd(t: SierTemplate): string {
  const lines = [`# ${t.display_name_ja} 標準ドキュメント章立て`, ``];
  for (const s of t.documentation_template.sections) {
    lines.push(`## ${s.title}`);
    lines.push('');
    lines.push(s.outline);
    lines.push('');
  }
  return lines.join('\n');
}

function buildQaGateMd(t: SierTemplate): string {
  const q = t.qa_gate;
  return [
    `# ${t.display_name_ja} QA Gate`,
    ``,
    `| 項目 | 基準 |`,
    `| --- | --- |`,
    `| カバレッジ最低 | ${q.coverage_min}% |`,
    `| Lighthouse 最低 | ${q.lighthouse_min ?? 'n/a'} |`,
    `| 静的解析 | ${q.static_analysis_tool ?? 'n/a'} |`,
    `| セキュリティスキャン | ${q.security_scan ? '必須' : '不要'} |`,
    `| ペネトレーションテスト | ${q.pen_test_required ? '必須' : '不要'} |`,
    `| 負荷試験 | ${q.load_test_required ? '必須' : '不要'} |`,
    `| ドキュメントレビュー | ${q.doc_review_required ? '必須' : '不要'} |`,
    ``,
    q.notes ? `> ${q.notes}` : '',
    ``,
  ].join('\n');
}

function buildLibrariesMd(t: SierTemplate): string {
  const lines = [`# ${t.display_name_ja} 推奨/禁止ライブラリ`, ``, `## 推奨ライブラリ`, ``];
  for (const g of t.preferred_libraries) {
    lines.push(`### ${g.language}`);
    lines.push('');
    for (const lib of g.libraries) {
      lines.push(
        `- ${lib.name}${lib.version_range ? ` @ ${lib.version_range}` : ''}${
          lib.reason ? ` — ${lib.reason}` : ''
        }`
      );
    }
    lines.push('');
  }
  lines.push('## 禁止ライブラリ');
  lines.push('');
  for (const g of t.banned_libraries) {
    lines.push(`### ${g.language}`);
    lines.push('');
    for (const lib of g.libraries) {
      lines.push(`- ${lib.name} — ${lib.reason}`);
    }
    lines.push('');
  }
  return lines.join('\n');
}

function buildDeploymentMd(t: SierTemplate): string {
  return [
    `# ${t.display_name_ja} 想定デプロイ先`,
    ``,
    ...t.deployment_targets.map((d) => `- ${d}`),
    ``,
  ].join('\n');
}

export const __testing__ = {
  buildEslintHint,
  buildChecklistMd,
  buildOverviewMd,
  buildDocOutlineMd,
  buildQaGateMd,
  buildLibrariesMd,
  buildDeploymentMd,
  mapEslintCase,
};
