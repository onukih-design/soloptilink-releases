/**
 * Tenant Profile Manager - SIer / Customer / Project の3階層プロファイル高レベルAPI
 *
 * 責務:
 *  - 4階層メモリ (SIer → Customer → Project → Decision) の上位3層 (= プロファイル) を管理
 *  - 8 SIer の builtin プロファイルを内蔵し、未登録 SIer 参照時に永続化
 *  - 登録/更新/参照/アーカイブ/一覧化を一貫した API で提供
 *
 * 入出力:
 *  - 入力: 各種 input オブジェクト (sier_id / tenant_id / project_id / patch 等)
 *  - 出力: 永続化済み SierProfile / CustomerProfile / ProjectProfile
 *  - 副作用: storage.ts 経由で JSON ファイルを read/write (直接 fs は触らない)
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import type {
  SierId,
  SierProfile,
  CustomerProfile,
  ProjectProfile,
  NamingCase,
} from './types';
import {
  STORAGE_ROOT,
  ensureStorageRoot,
  sierDir,
  customerDir,
  readSierProfile,
  writeSierProfile,
  readCustomerProfile,
  writeCustomerProfile,
  readProjectProfile,
  writeProjectProfile,
} from './storage';

/* ───── Types (input shapes) ─────────────────────────────────────── */

export interface RegisterSierInput {
  sier_id: SierId;
  display_name?: string;
  display_name_ja?: string;
  default_naming?: Partial<SierProfile['default_naming']>;
  preferred_libraries?: string[];
  banned_libraries?: string[];
  preferred_architecture?: string[];
  preferred_deployment?: string[];
  notes_ja?: string;
}

export interface RegisterCustomerInput {
  tenant_id: string;
  sier_id: SierId;
  display_name: string;
  display_name_ja?: string;
  domain?: string;
  industry?: string;
  industry_ja?: string;
  size?: CustomerProfile['size'];
  contact_info?: Partial<CustomerProfile['contact_info']>;
}

export interface RegisterProjectInput {
  project_id: string;
  tenant_id: string;
  sier_id: SierId;
  display_name: string;
  description: string;
  industry?: string;
  status?: ProjectProfile['status'];
  start_date?: string;
  end_date?: string;
  tech_stack?: Partial<ProjectProfile['tech_stack']>;
  applicable_laws?: string[];
  outcome?: ProjectProfile['outcome'];
  outcome_notes?: string;
}

/* ───── Built-in 8 SIer profiles ─────────────────────────────────── */

const BUILTIN_TIMESTAMP = '2024-01-01T00:00:00.000Z';

function makeBuiltin(
  sierId: SierId,
  display: string,
  displayJa: string,
  naming: SierProfile['default_naming'],
  preferred_libraries: string[],
  banned_libraries: string[],
  preferred_architecture: string[],
  preferred_deployment: string[],
  notes_ja: string
): SierProfile {
  return {
    sier_id: sierId,
    display_name: display,
    display_name_ja: displayJa,
    default_naming: naming,
    preferred_libraries,
    banned_libraries,
    preferred_architecture,
    preferred_deployment,
    notes_ja,
    meta: {
      is_builtin: true,
      created_at: BUILTIN_TIMESTAMP,
      last_updated: BUILTIN_TIMESTAMP,
      project_count: 0,
    },
  };
}

const BUILTIN_PROFILES: Record<SierId, SierProfile> = {
  nttdata: makeBuiltin(
    'nttdata',
    'NTT DATA',
    'NTTデータ',
    {
      db_table: 'snake_case',
      db_column: 'snake_case',
      typescript_var: 'camelCase',
      api_path: 'kebab-case',
      table_prefix: 'T_',
      master_table_prefix: 'M_',
    },
    ['Spring Boot', 'Spring Framework', 'Java EE', 'Oracle DB', 'PostgreSQL', 'JUnit', 'Mockito'],
    ['未検証OSS全般', 'EOL済みライブラリ'],
    ['3層アーキテクチャ', 'マイクロサービス', 'Hexagonal'],
    ['オンプレミス', 'プライベートクラウド', 'OpenShift'],
    'NTTデータ式: snake_case (DB)・camelCase (TS)・接頭辞 T_/M_。Spring Boot主流、オンプレ+プライベートクラウド中心。'
  ),
  fujitsu: makeBuiltin(
    'fujitsu',
    'Fujitsu',
    '富士通',
    {
      db_table: 'snake_case',
      db_column: 'UPPER_SNAKE',
      typescript_var: 'camelCase',
      api_path: 'kebab-case',
      table_prefix: 'tbl_',
    },
    ['INTERSTAGE', 'Apworks', 'Symfoware', 'Java EE', 'Spring Framework'],
    ['非サポートOSS', 'ライセンス不明ライブラリ'],
    ['SOA', '3層アーキテクチャ', 'コンポーネント指向'],
    ['FUJITSU Cloud Service', 'プライベートクラウド', 'オンプレミス'],
    '富士通式: snake_case + UPPER略称、tbl_接頭辞。INTERSTAGE/Apworks。FUJITSU Cloud主体。'
  ),
  nri: makeBuiltin(
    'nri',
    'NRI (Nomura Research Institute)',
    '野村総合研究所',
    {
      db_table: 'UPPER_SNAKE',
      db_column: 'UPPER_SNAKE',
      typescript_var: 'camelCase',
      api_path: 'kebab-case',
      table_prefix: 'TBL_',
    },
    ['THE STAR', 'Java EE', 'Spring Framework', 'Oracle DB', 'JBoss EAP'],
    ['コミュニティ版のみのOSS', '未認定ライブラリ'],
    ['THE STAR準拠アーキテクチャ', '3層アーキテクチャ'],
    ['自社データセンター', '金融特化プライベートクラウド'],
    'NRI式: UpperCamelCase (Java)・TBL_接頭辞。THE STAR フレームワーク。自社DC中心、金融標準。'
  ),
  nomura: makeBuiltin(
    'nomura',
    'Nomura Securities IT',
    '野村證券IT',
    {
      db_table: 'UPPER_SNAKE',
      db_column: 'UPPER_SNAKE',
      typescript_var: 'camelCase',
      api_path: 'kebab-case',
      table_prefix: 'TBL_',
    },
    ['THE STAR', 'Java EE', 'Spring Framework', 'Oracle DB', 'kdb+'],
    ['コミュニティ版のみのOSS', '監査未通過ライブラリ'],
    ['THE STAR準拠アーキテクチャ', 'CEP', 'マイクロサービス'],
    ['自社データセンター', '金融特化プライベートクラウド'],
    '野村證券IT式: NRI互換規約。金融証券特化、低レイテンシ要件。自社DC運用。'
  ),
  nec: makeBuiltin(
    'nec',
    'NEC',
    'NEC',
    {
      db_table: 'snake_case',
      db_column: 'snake_case',
      typescript_var: 'camelCase',
      api_path: 'kebab-case',
      table_prefix: 'tbl_',
    },
    ['NEC共通フレームワーク', 'WebSAM', 'SystemDirector', 'Spring Framework', 'PostgreSQL'],
    ['未認定OSS', 'セキュリティ非認証ライブラリ'],
    ['SystemDirector準拠', '3層アーキテクチャ'],
    ['NEC Cloud IaaS', '自治体専用クラウド', 'オンプレミス'],
    'NEC式: NEC共通フレームワーク基準、WebSAM/SystemDirector中心。NEC Cloud IaaS、自治体系強み。'
  ),
  hitachi: makeBuiltin(
    'hitachi',
    'Hitachi',
    '日立製作所',
    {
      db_table: 'snake_case',
      db_column: 'snake_case',
      typescript_var: 'camelCase',
      api_path: 'kebab-case',
      table_prefix: 'tbl_',
    },
    ['日立共通基盤', 'Cosminexus', 'JP1', 'HiRDB', 'Spring Framework'],
    ['ライフサイクル切れOSS', '未認証ライブラリ'],
    ['日立共通基盤準拠', 'SOA', '3層アーキテクチャ'],
    ['Hitachi Cloud', '公共系プライベートクラウド', 'オンプレミス'],
    '日立式: 日立共通基盤、Cosminexus/JP1。Hitachi Cloud。公共系・社会インフラ系強み。'
  ),
  tis: makeBuiltin(
    'tis',
    'TIS',
    'TIS',
    {
      db_table: 'snake_case',
      db_column: 'snake_case',
      typescript_var: 'camelCase',
      api_path: 'kebab-case',
      table_prefix: 'tbl_',
    },
    ['TIDS', 'Spring Framework', 'Apache HTTP Server', 'JDDS', 'PostgreSQL', 'Oracle DB'],
    ['EOL OSS', '商用ライセンス未許諾ライブラリ'],
    ['TIDS準拠', 'マイクロサービス', '3層アーキテクチャ'],
    ['TISプライベートクラウド', 'AWS', 'オンプレミス'],
    'TIS式: TIDS フレームワーク。Spring + Apache + JDDS。プライベートクラウド主体、金融B2B強み。'
  ),
  generic: makeBuiltin(
    'generic',
    'Generic',
    '汎用',
    {
      db_table: 'snake_case',
      db_column: 'snake_case',
      typescript_var: 'camelCase',
      api_path: 'kebab-case',
    },
    [],
    [],
    [],
    [],
    '汎用: 案件ごとに自由に決定。固定の規約なし、プロジェクト単位で命名規則を定義する。'
  ),
};

/* ───── SIer Profile API ─────────────────────────────────────────── */

/**
 * SIer 登録 / 更新 (merge)。既存があれば input を上書き、なければ builtin をベースに上書き。
 */
export function registerSier(input: RegisterSierInput, root: string = STORAGE_ROOT): SierProfile {
  ensureStorageRoot(root);
  const existing = readSierProfile(input.sier_id, root);
  const base: SierProfile = existing ?? cloneBuiltin(input.sier_id);

  const now = new Date().toISOString();
  const merged: SierProfile = {
    sier_id: input.sier_id,
    display_name: input.display_name ?? base.display_name,
    display_name_ja: input.display_name_ja ?? base.display_name_ja,
    default_naming: {
      ...base.default_naming,
      ...(input.default_naming ?? {}),
    },
    preferred_libraries: input.preferred_libraries ?? base.preferred_libraries,
    banned_libraries: input.banned_libraries ?? base.banned_libraries,
    preferred_architecture: input.preferred_architecture ?? base.preferred_architecture,
    preferred_deployment: input.preferred_deployment ?? base.preferred_deployment,
    notes_ja: input.notes_ja ?? base.notes_ja,
    meta: {
      is_builtin: existing ? base.meta.is_builtin : false,
      created_at: existing ? base.meta.created_at : now,
      last_updated: now,
      project_count: base.meta.project_count,
    },
  };
  writeSierProfile(merged, root);
  return merged;
}

export function updateSierProfile(
  sierId: SierId,
  patch: Partial<Omit<SierProfile, 'sier_id' | 'meta'>>,
  root: string = STORAGE_ROOT
): SierProfile {
  const existing = getSier(sierId, root);
  if (!existing) {
    throw new Error(`SIer not found: ${sierId}`);
  }
  const now = new Date().toISOString();
  const next: SierProfile = {
    ...existing,
    ...patch,
    default_naming: patch.default_naming
      ? { ...existing.default_naming, ...patch.default_naming }
      : existing.default_naming,
    sier_id: existing.sier_id,
    meta: {
      ...existing.meta,
      is_builtin: false,
      last_updated: now,
    },
  };
  writeSierProfile(next, root);
  return next;
}

/**
 * 取得。未登録 SIer なら builtin を永続化して返す (初回ロード)。
 */
export function getSier(sierId: SierId, root: string = STORAGE_ROOT): SierProfile | null {
  const existing = readSierProfile(sierId, root);
  if (existing) return existing;
  if (!(sierId in BUILTIN_PROFILES)) return null;
  const seeded = cloneBuiltin(sierId);
  writeSierProfile(seeded, root);
  return seeded;
}

export function listAllSiers(root: string = STORAGE_ROOT): SierProfile[] {
  ensureStorageRoot(root);
  const out: SierProfile[] = [];
  const seen = new Set<SierId>();

  if (fs.existsSync(root)) {
    for (const dirent of fs.readdirSync(root, { withFileTypes: true })) {
      if (!dirent.isDirectory() || dirent.name.startsWith('_')) continue;
      const sierId = dirent.name as SierId;
      const profile = readSierProfile(sierId, root);
      if (profile) {
        out.push(profile);
        seen.add(sierId);
      }
    }
  }
  // builtin で未永続化のものも一覧化対象
  for (const id of Object.keys(BUILTIN_PROFILES) as SierId[]) {
    if (!seen.has(id)) {
      out.push(cloneBuiltin(id));
    }
  }
  out.sort((a, b) => a.sier_id.localeCompare(b.sier_id));
  return out;
}

/* ───── Customer Profile API ─────────────────────────────────────── */

export function registerCustomer(
  input: RegisterCustomerInput,
  root: string = STORAGE_ROOT
): CustomerProfile {
  // SIer が builtin だけで未永続化ならここで初期化
  getSier(input.sier_id, root);

  const existing = readCustomerProfile(input.sier_id, input.tenant_id, root);
  const now = new Date().toISOString();
  const next: CustomerProfile = existing
    ? {
        ...existing,
        display_name: input.display_name ?? existing.display_name,
        display_name_ja: input.display_name_ja ?? existing.display_name_ja,
        domain: input.domain ?? existing.domain,
        industry: input.industry ?? existing.industry,
        industry_ja: input.industry_ja ?? existing.industry_ja,
        size: input.size ?? existing.size,
        contact_info: { ...existing.contact_info, ...(input.contact_info ?? {}) },
        meta: {
          ...existing.meta,
          last_updated: now,
          interaction_count: existing.meta.interaction_count + 1,
        },
      }
    : {
        tenant_id: input.tenant_id,
        sier_id: input.sier_id,
        display_name: input.display_name,
        display_name_ja: input.display_name_ja,
        domain: input.domain,
        industry: input.industry,
        industry_ja: input.industry_ja,
        size: input.size,
        active_projects: [],
        archived_projects: [],
        contact_info: input.contact_info ?? {},
        meta: {
          created_at: now,
          last_updated: now,
          interaction_count: 1,
        },
      };
  writeCustomerProfile(next, root);
  return next;
}

export function updateCustomerProfile(
  sierId: SierId,
  tenantId: string,
  patch: Partial<Omit<CustomerProfile, 'tenant_id' | 'sier_id' | 'meta'>>,
  root: string = STORAGE_ROOT
): CustomerProfile {
  const existing = readCustomerProfile(sierId, tenantId, root);
  if (!existing) {
    throw new Error(`Customer not found: ${sierId}/${tenantId}`);
  }
  const now = new Date().toISOString();
  const next: CustomerProfile = {
    ...existing,
    ...patch,
    tenant_id: existing.tenant_id,
    sier_id: existing.sier_id,
    contact_info: patch.contact_info
      ? { ...existing.contact_info, ...patch.contact_info }
      : existing.contact_info,
    active_projects: patch.active_projects ?? existing.active_projects,
    archived_projects: patch.archived_projects ?? existing.archived_projects,
    meta: {
      ...existing.meta,
      last_updated: now,
    },
  };
  writeCustomerProfile(next, root);
  return next;
}

export function getCustomer(
  sierId: SierId,
  tenantId: string,
  root: string = STORAGE_ROOT
): CustomerProfile | null {
  return readCustomerProfile(sierId, tenantId, root);
}

export function listCustomersOfSier(
  sierId: SierId,
  root: string = STORAGE_ROOT
): CustomerProfile[] {
  const base = path.join(sierDir(sierId, root), 'customers');
  if (!fs.existsSync(base)) return [];
  const out: CustomerProfile[] = [];
  for (const dirent of fs.readdirSync(base, { withFileTypes: true })) {
    if (!dirent.isDirectory()) continue;
    const cp = readCustomerProfile(sierId, dirent.name, root);
    if (cp) out.push(cp);
  }
  out.sort((a, b) => a.tenant_id.localeCompare(b.tenant_id));
  return out;
}

/* ───── Project Profile API ──────────────────────────────────────── */

export function registerProject(
  input: RegisterProjectInput,
  root: string = STORAGE_ROOT
): ProjectProfile {
  // 顧客プロファイル未登録ならエラー (上位で先に登録すべき)
  const customer = readCustomerProfile(input.sier_id, input.tenant_id, root);
  if (!customer) {
    throw new Error(
      `Customer not registered. Call registerCustomer first: ${input.sier_id}/${input.tenant_id}`
    );
  }

  const existing = readProjectProfile(input.sier_id, input.tenant_id, input.project_id, root);
  const now = new Date().toISOString();
  const next: ProjectProfile = existing
    ? {
        ...existing,
        display_name: input.display_name ?? existing.display_name,
        description: input.description ?? existing.description,
        industry: input.industry ?? existing.industry,
        status: input.status ?? existing.status,
        end_date: input.end_date ?? existing.end_date,
        tech_stack: { ...existing.tech_stack, ...(input.tech_stack ?? {}) },
        applicable_laws: input.applicable_laws ?? existing.applicable_laws,
        outcome: input.outcome ?? existing.outcome,
        outcome_notes: input.outcome_notes ?? existing.outcome_notes,
        meta: {
          ...existing.meta,
          last_updated: now,
        },
      }
    : {
        project_id: input.project_id,
        tenant_id: input.tenant_id,
        sier_id: input.sier_id,
        display_name: input.display_name,
        description: input.description,
        industry: input.industry,
        status: input.status ?? 'planning',
        start_date: input.start_date ?? now,
        end_date: input.end_date,
        tech_stack: {
          frontend: input.tech_stack?.frontend ?? [],
          backend: input.tech_stack?.backend ?? [],
          database: input.tech_stack?.database ?? [],
          infrastructure: input.tech_stack?.infrastructure ?? [],
          cicd: input.tech_stack?.cicd ?? [],
        },
        applicable_laws: input.applicable_laws,
        outcome: input.outcome ?? 'in_progress',
        outcome_notes: input.outcome_notes,
        meta: {
          created_at: now,
          last_updated: now,
          decision_count: 0,
        },
      };
  writeProjectProfile(next, root);

  // 顧客の active_projects 配列にも反映 (重複なし)
  if (!existing) {
    const activeSet = new Set(customer.active_projects);
    activeSet.add(input.project_id);
    const archivedSet = new Set(customer.archived_projects.filter((p) => p !== input.project_id));
    writeCustomerProfile(
      {
        ...customer,
        active_projects: Array.from(activeSet),
        archived_projects: Array.from(archivedSet),
        meta: {
          ...customer.meta,
          last_updated: now,
          interaction_count: customer.meta.interaction_count + 1,
        },
      },
      root
    );

    // SIer の project_count をインクリメント
    const sier = getSier(input.sier_id, root);
    if (sier) {
      writeSierProfile(
        {
          ...sier,
          meta: {
            ...sier.meta,
            project_count: sier.meta.project_count + 1,
            last_updated: now,
          },
        },
        root
      );
    }
  }

  return next;
}

export function updateProjectProfile(
  sierId: SierId,
  tenantId: string,
  projectId: string,
  patch: Partial<Omit<ProjectProfile, 'project_id' | 'tenant_id' | 'sier_id' | 'meta'>>,
  root: string = STORAGE_ROOT
): ProjectProfile {
  const existing = readProjectProfile(sierId, tenantId, projectId, root);
  if (!existing) {
    throw new Error(`Project not found: ${sierId}/${tenantId}/${projectId}`);
  }
  const now = new Date().toISOString();
  const next: ProjectProfile = {
    ...existing,
    ...patch,
    project_id: existing.project_id,
    tenant_id: existing.tenant_id,
    sier_id: existing.sier_id,
    tech_stack: patch.tech_stack
      ? { ...existing.tech_stack, ...patch.tech_stack }
      : existing.tech_stack,
    meta: {
      ...existing.meta,
      last_updated: now,
    },
  };
  writeProjectProfile(next, root);
  return next;
}

export function getProject(
  sierId: SierId,
  tenantId: string,
  projectId: string,
  root: string = STORAGE_ROOT
): ProjectProfile | null {
  return readProjectProfile(sierId, tenantId, projectId, root);
}

export function archiveProject(
  sierId: SierId,
  tenantId: string,
  projectId: string,
  root: string = STORAGE_ROOT
): ProjectProfile {
  const existing = readProjectProfile(sierId, tenantId, projectId, root);
  if (!existing) {
    throw new Error(`Project not found: ${sierId}/${tenantId}/${projectId}`);
  }
  const now = new Date().toISOString();
  const archived: ProjectProfile = {
    ...existing,
    status: 'archived',
    end_date: existing.end_date ?? now,
    meta: {
      ...existing.meta,
      last_updated: now,
    },
  };
  writeProjectProfile(archived, root);

  // 顧客側の active/archived 配列を整理
  const customer = readCustomerProfile(sierId, tenantId, root);
  if (customer) {
    const active = customer.active_projects.filter((p) => p !== projectId);
    const archivedList = Array.from(new Set([...customer.archived_projects, projectId]));
    writeCustomerProfile(
      {
        ...customer,
        active_projects: active,
        archived_projects: archivedList,
        meta: {
          ...customer.meta,
          last_updated: now,
        },
      },
      root
    );
  }
  return archived;
}

export function listProjectsOfCustomer(
  sierId: SierId,
  tenantId: string,
  root: string = STORAGE_ROOT
): ProjectProfile[] {
  const base = path.join(customerDir(sierId, tenantId, root), 'projects');
  if (!fs.existsSync(base)) return [];
  const out: ProjectProfile[] = [];
  for (const dirent of fs.readdirSync(base, { withFileTypes: true })) {
    if (!dirent.isDirectory()) continue;
    const pp = readProjectProfile(sierId, tenantId, dirent.name, root);
    if (pp) out.push(pp);
  }
  out.sort((a, b) => a.project_id.localeCompare(b.project_id));
  return out;
}

/* ───── Internals ────────────────────────────────────────────────── */

function cloneBuiltin(sierId: SierId): SierProfile {
  const src = BUILTIN_PROFILES[sierId];
  if (!src) {
    throw new Error(`Unknown builtin SIer: ${sierId}`);
  }
  return JSON.parse(JSON.stringify(src)) as SierProfile;
}

/**
 * テスト/外部ツールから builtin を直接参照したい場合のみ使用。書き込みは行われない。
 */
export function getBuiltinSierProfile(sierId: SierId): SierProfile | null {
  if (!(sierId in BUILTIN_PROFILES)) return null;
  return cloneBuiltin(sierId);
}

export function listBuiltinSierIds(): SierId[] {
  return Object.keys(BUILTIN_PROFILES) as SierId[];
}

/* ───── Type re-export for downstream modules ─────────────────────── */

export type { NamingCase };

/*
 * Module summary - exported functions:
 *  - registerSier / updateSierProfile / getSier / listAllSiers
 *  - registerCustomer / updateCustomerProfile / getCustomer / listCustomersOfSier
 *  - registerProject / updateProjectProfile / getProject / archiveProject / listProjectsOfCustomer
 *  - getBuiltinSierProfile / listBuiltinSierIds
 *  Builtin SIer count: 8 (nttdata / fujitsu / nri / nomura / nec / hitachi / tis / generic)
 */
