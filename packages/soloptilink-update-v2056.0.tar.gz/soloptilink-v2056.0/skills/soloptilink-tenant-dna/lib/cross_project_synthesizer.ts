/**
 * Cross-Project Synthesizer — 複数プロジェクトの判断履歴を蒸留し横断パターンを発見
 *
 * 責務:
 *   - SIer / Customer / Global スコープで DecisionRecord を集約
 *   - 同カテゴリ + 類似 decision text を簡易クラスタリング (token 一致率 0.6+)
 *   - 蒸留結果 = CrossProjectPattern (occurrence_count >= min_occurrence) を出力
 *   - 過去パターンから次プロジェクトへの推奨を生成
 *   - プロジェクト間 Jaccard 類似度 / 差分マトリクス / 成功要因抽出
 *
 * 入力:
 *   - SierId / tenant_id / project_id 群
 *   - storage 層から読み込んだ DecisionRecord / ProjectProfile
 *
 * 出力:
 *   - CrossProjectPattern[] / RecommendResult / 類似プロジェクト一覧 / 比較マトリクス
 *
 * 注意:
 *   - storage.ts のみを使用 (fs 直触り禁止)
 *   - 並行 Agent の tenant_profile / decision_memory / naming_convention は import しない
 *     (循環回避)。必要なら storage.read* を直接呼ぶ。
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import {
  STORAGE_ROOT,
  sierDir,
  customerDir,
  projectDir,
  readDecisionsForCustomer,
  readProjectProfile,
  readCustomerProfile,
  appendPattern,
  generateId,
} from './storage';
import type {
  SierId,
  DecisionRecord,
  DecisionCategory,
  ProjectProfile,
  CrossProjectPattern,
  RecommendResult,
} from './types';

/* ───── 公開 API オプション型 ───── */

export interface DistillOptions {
  min_occurrence?: number;
  min_success_rate?: number;
}

export interface SimilarProject {
  project_id: string;
  tenant_id: string;
  similarity: number;
  reasons: string[];
}

export interface ProjectMetadataInput {
  industry?: string;
  tech_stack?: string[];
  size?: ProjectProfile['meta'] extends infer _T ? string : string;
}

export interface CompareEntry {
  aspect: string;
  values: Record<string, string>;
}

export interface SuccessFactor {
  factor: string;
  correlation: number;
  description: string;
}

/* ───── 内部ユーティリティ ───── */

function tokenize(text: string): string[] {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9ぁ-んァ-ヶ一-龯_\-\s]/g, ' ')
    .split(/\s+/)
    .filter((t) => t.length >= 2);
}

function jaccard(a: string[] | Set<string>, b: string[] | Set<string>): number {
  const sa = a instanceof Set ? a : new Set(a);
  const sb = b instanceof Set ? b : new Set(b);
  if (sa.size === 0 && sb.size === 0) return 0;
  let inter = 0;
  for (const v of sa) if (sb.has(v)) inter += 1;
  const uni = sa.size + sb.size - inter;
  return uni === 0 ? 0 : inter / uni;
}

function tokenSimilarity(textA: string, textB: string): number {
  return jaccard(tokenize(textA), tokenize(textB));
}

/** 簡易シングルパス・クラスタリング (閾値 0.6) */
function clusterDecisions(decisions: DecisionRecord[], threshold = 0.6): DecisionRecord[][] {
  const clusters: DecisionRecord[][] = [];
  for (const d of decisions) {
    let placed = false;
    for (const c of clusters) {
      const seed = c[0];
      if (seed.category !== d.category) continue;
      const sim = tokenSimilarity(seed.decision, d.decision);
      if (sim >= threshold) {
        c.push(d);
        placed = true;
        break;
      }
    }
    if (!placed) clusters.push([d]);
  }
  return clusters;
}

function outcomeScore(outcome?: ProjectProfile['outcome']): number | null {
  switch (outcome) {
    case 'success':
      return 1.0;
    case 'partial':
      return 0.5;
    case 'failed':
      return 0.0;
    case 'in_progress':
    case undefined:
    default:
      return null;
  }
}

/** SIer 内の全 (tenant_id, project_id) を列挙 */
function listAllProjectsInSier(
  sier_id: SierId,
  root: string = STORAGE_ROOT
): { tenant_id: string; project_id: string }[] {
  const result: { tenant_id: string; project_id: string }[] = [];
  const customersBase = path.join(sierDir(sier_id, root), 'customers');
  if (!fs.existsSync(customersBase)) return result;
  for (const td of fs.readdirSync(customersBase, { withFileTypes: true })) {
    if (!td.isDirectory()) continue;
    const tenant_id = td.name;
    const projectsBase = path.join(customerDir(sier_id, tenant_id, root), 'projects');
    if (!fs.existsSync(projectsBase)) continue;
    for (const pd of fs.readdirSync(projectsBase, { withFileTypes: true })) {
      if (!pd.isDirectory()) continue;
      result.push({ tenant_id, project_id: pd.name });
    }
  }
  return result;
}

function listAllSiers(root: string = STORAGE_ROOT): SierId[] {
  if (!fs.existsSync(root)) return [];
  return fs
    .readdirSync(root, { withFileTypes: true })
    .filter((d) => d.isDirectory() && !d.name.startsWith('_'))
    .map((d) => d.name as SierId);
}

/** Decision を「success_rate を計算するための project_id 経由 outcome」と束ねる */
function gatherDecisionsWithOutcome(
  scope: 'sier' | 'customer' | 'global',
  scope_id: string,
  root: string = STORAGE_ROOT
): {
  decisions: DecisionRecord[];
  projectOutcomes: Map<string, number | null>;
} {
  const decisions: DecisionRecord[] = [];
  const projectOutcomes = new Map<string, number | null>();
  const siers: SierId[] = scope === 'global' ? listAllSiers(root) : [scope_id as SierId];

  if (scope === 'customer') {
    // scope_id は tenant_id。すべての SIer を回って一致 customer を取り込む
    for (const sid of listAllSiers(root)) {
      const decs = readDecisionsForCustomer(sid, scope_id, root);
      if (decs.length === 0) continue;
      decisions.push(...decs);
      const customersBase = path.join(sierDir(sid, root), 'customers', scope_id, 'projects');
      if (fs.existsSync(customersBase)) {
        for (const pd of fs.readdirSync(customersBase, { withFileTypes: true })) {
          if (!pd.isDirectory()) continue;
          const pp = readProjectProfile(sid, scope_id, pd.name, root);
          if (pp) projectOutcomes.set(pp.project_id, outcomeScore(pp.outcome));
        }
      }
    }
    return { decisions, projectOutcomes };
  }

  // sier / global
  for (const sid of siers) {
    for (const { tenant_id, project_id } of listAllProjectsInSier(sid, root)) {
      const pp = readProjectProfile(sid, tenant_id, project_id, root);
      if (pp) projectOutcomes.set(project_id, outcomeScore(pp.outcome));
    }
    const customersBase = path.join(sierDir(sid, root), 'customers');
    if (!fs.existsSync(customersBase)) continue;
    for (const td of fs.readdirSync(customersBase, { withFileTypes: true })) {
      if (!td.isDirectory()) continue;
      const decs = readDecisionsForCustomer(sid, td.name, root);
      decisions.push(...decs);
    }
  }

  return { decisions, projectOutcomes };
}

function summarizePattern(cluster: DecisionRecord[]): string {
  // 最頻出 token 5 個 + 代表 decision の頭 80 文字
  const tf = new Map<string, number>();
  for (const d of cluster) {
    for (const t of tokenize(`${d.title} ${d.decision}`)) {
      tf.set(t, (tf.get(t) ?? 0) + 1);
    }
  }
  const top = [...tf.entries()]
    .sort((a, b) => b[1] - a[1])
    .slice(0, 5)
    .map(([t]) => t)
    .join(', ');
  const head = cluster[0].decision.replace(/\s+/g, ' ').trim();
  const headShort = head.length > 80 ? head.slice(0, 80) + '…' : head;
  return `[${top}] ${headShort}`;
}

function recommendationFromPattern(cluster: DecisionRecord[]): string {
  // 出現数が高い場合は強く推奨、低い場合は参考。代替 (alternatives_considered) があれば併記。
  const occ = cluster.length;
  const alts = new Set<string>();
  for (const d of cluster) {
    for (const a of d.alternatives_considered ?? []) alts.add(a);
  }
  const altText = alts.size > 0 ? ` (代替案として検討された: ${[...alts].slice(0, 3).join(', ')})` : '';
  if (occ >= 8) {
    return `過去 ${occ} プロジェクトで採用された定石。原則踏襲を推奨${altText}`;
  }
  if (occ >= 4) {
    return `過去 ${occ} プロジェクトで採用。同様の制約があれば踏襲を推奨${altText}`;
  }
  return `過去 ${occ} プロジェクトで採用された前例あり。要件次第で参考${altText}`;
}

/* ───── 1) distillPatterns ───── */

export function distillPatterns(
  scope: 'sier' | 'customer' | 'global',
  scope_id: string,
  options: DistillOptions = {}
): CrossProjectPattern[] {
  const minOccurrence = options.min_occurrence ?? 3;
  const minSuccess = options.min_success_rate ?? 0;

  const { decisions, projectOutcomes } = gatherDecisionsWithOutcome(scope, scope_id);
  if (decisions.length === 0) return [];

  // Category 単位で分けてからクラスタリングする (異カテゴリの混入を防止)
  const byCategory = new Map<DecisionCategory, DecisionRecord[]>();
  for (const d of decisions) {
    if (!byCategory.has(d.category)) byCategory.set(d.category, []);
    byCategory.get(d.category)!.push(d);
  }

  const out: CrossProjectPattern[] = [];
  const now = new Date().toISOString();

  for (const [category, cat_decs] of byCategory) {
    const clusters = clusterDecisions(cat_decs, 0.6);
    for (const cluster of clusters) {
      if (cluster.length < minOccurrence) continue;

      // 関連 project_id 一覧
      const projectIds = Array.from(
        new Set(cluster.map((d) => d.project_id).filter((p): p is string => Boolean(p)))
      );

      // success_rate 計算 (in_progress は除外)
      const scores: number[] = [];
      for (const pid of projectIds) {
        const s = projectOutcomes.get(pid);
        if (s !== null && s !== undefined) scores.push(s);
      }
      const success_rate =
        scores.length === 0 ? 0 : scores.reduce((a, b) => a + b, 0) / scores.length;

      if (success_rate < minSuccess) continue;

      out.push({
        pattern_id: generateId('ptn'),
        scope,
        scope_id,
        category,
        pattern_summary: summarizePattern(cluster),
        occurrence_count: cluster.length,
        success_rate: Number(success_rate.toFixed(3)),
        example_project_ids: projectIds.slice(0, 10),
        recommendation_text: recommendationFromPattern(cluster),
        distilled_at: now,
      });
    }
  }

  // occurrence 降順 / success_rate 降順
  out.sort((a, b) => {
    if (b.occurrence_count !== a.occurrence_count) return b.occurrence_count - a.occurrence_count;
    return b.success_rate - a.success_rate;
  });

  return out;
}

/* ───── 2) recommendBasedOnHistory ───── */

export function recommendBasedOnHistory(
  sier_id: SierId,
  tenant_id: string,
  project_industry?: string
): RecommendResult {
  // tenant スコープ + sier スコープを併用、tenant 優先
  const tenantPatterns = distillPatterns('customer', tenant_id);
  const sierPatterns = distillPatterns('sier', sier_id);

  // industry 指定があれば、関連プロジェクトの industry と一致するものを優先付与
  const industryBoost = (p: CrossProjectPattern): number => {
    if (!project_industry) return 0;
    // industry 情報は project プロファイルから引く (重い処理は避け、example_project_ids ベースで sampling)
    let hits = 0;
    let tries = 0;
    for (const pid of p.example_project_ids.slice(0, 3)) {
      const proj = lookupProject(sier_id, pid);
      if (!proj) continue;
      tries += 1;
      if (proj.industry?.toLowerCase().includes(project_industry.toLowerCase())) hits += 1;
    }
    return tries === 0 ? 0 : (hits / tries) * 0.2; // 最大 +0.2 ブースト
  };

  const merged: CrossProjectPattern[] = [...tenantPatterns, ...sierPatterns];

  // 重複 (同 category + 同 summary) を統合
  const dedup = new Map<string, CrossProjectPattern>();
  for (const p of merged) {
    const key = `${p.category}::${p.pattern_summary}`;
    const prev = dedup.get(key);
    if (!prev) {
      dedup.set(key, p);
      continue;
    }
    // occurrence/success の高い方を残す
    const score = (x: CrossProjectPattern): number =>
      x.occurrence_count + x.success_rate * 5 + industryBoost(x);
    if (score(p) > score(prev)) dedup.set(key, p);
  }

  const ranked = [...dedup.values()].sort(
    (a, b) =>
      b.occurrence_count + b.success_rate * 5 + industryBoost(b) -
      (a.occurrence_count + a.success_rate * 5 + industryBoost(a))
  );

  const top = ranked.slice(0, 10);

  const recommended_decisions: RecommendResult['recommended_decisions'] = top.map((p) => ({
    category: p.category,
    recommendation: p.pattern_summary,
    rationale: p.recommendation_text,
    confidence: Math.min(
      0.99,
      0.4 + Math.log2(1 + p.occurrence_count) / 6 + p.success_rate * 0.3
    ),
    source_pattern_id: p.pattern_id,
  }));

  // alternatives: 同カテゴリ複数候補がある場合の代替提示
  const altByCategory = new Map<DecisionCategory, string[]>();
  for (const p of ranked) {
    if (!altByCategory.has(p.category)) altByCategory.set(p.category, []);
    const arr = altByCategory.get(p.category)!;
    if (!arr.includes(p.pattern_summary)) arr.push(p.pattern_summary);
  }
  const alternatives: RecommendResult['alternatives'] = [];
  for (const [category, options] of altByCategory) {
    if (options.length < 2) continue;
    alternatives.push({
      category,
      options: options.slice(0, 4),
    });
  }

  return {
    generated_at: new Date().toISOString(),
    scope: tenantPatterns.length > 0 ? 'customer' : 'sier',
    scope_id: tenantPatterns.length > 0 ? tenant_id : sier_id,
    recommended_decisions,
    alternatives,
  };
}

/** project_id から ProjectProfile を引く (tenant 不明時は sier 全テナントを走査) */
function lookupProject(sier_id: SierId, project_id: string): ProjectProfile | null {
  for (const { tenant_id, project_id: pid } of listAllProjectsInSier(sier_id)) {
    if (pid !== project_id) continue;
    const pp = readProjectProfile(sier_id, tenant_id, project_id);
    if (pp) return pp;
  }
  return null;
}

/* ───── 3) findSimilarProjects ───── */

export function findSimilarProjects(
  sier_id: SierId,
  tenant_id: string,
  project_metadata: { industry?: string; tech_stack?: string[]; size?: string }
): SimilarProject[] {
  const targetIndustry = project_metadata.industry?.toLowerCase() ?? '';
  const targetStack = new Set((project_metadata.tech_stack ?? []).map((s) => s.toLowerCase()));
  const targetSize = project_metadata.size?.toLowerCase() ?? '';

  // 探索対象: 同 SIer 全プロジェクト (tenant_id 自身は除外しない — 同顧客の過去案件も比較対象)
  const all = listAllProjectsInSier(sier_id);
  const scored: SimilarProject[] = [];

  for (const { tenant_id: tid, project_id } of all) {
    const pp = readProjectProfile(sier_id, tid, project_id);
    if (!pp) continue;

    const reasons: string[] = [];
    let weight = 0;
    let bound = 0;

    // industry
    bound += 1;
    if (targetIndustry && pp.industry) {
      const sim = pp.industry.toLowerCase().includes(targetIndustry) ||
        targetIndustry.includes(pp.industry.toLowerCase())
        ? 1
        : 0;
      weight += sim;
      if (sim) reasons.push(`industry 一致: ${pp.industry}`);
    }

    // tech stack (Jaccard)
    bound += 2;
    const stack = new Set<string>();
    for (const k of ['frontend', 'backend', 'database', 'infrastructure', 'cicd'] as const) {
      for (const v of pp.tech_stack[k] ?? []) stack.add(v.toLowerCase());
    }
    const stackSim = jaccard(targetStack, stack);
    weight += stackSim * 2;
    if (stackSim > 0) {
      const overlap = [...targetStack].filter((s) => stack.has(s)).slice(0, 3);
      if (overlap.length > 0) reasons.push(`stack 重複: ${overlap.join(', ')}`);
    }

    // size
    bound += 0.5;
    if (targetSize) {
      const cust = readCustomerProfile(sier_id, tid);
      if (cust?.size && cust.size.toLowerCase() === targetSize) {
        weight += 0.5;
        reasons.push(`規模一致: ${cust.size}`);
      }
    }

    // 同 customer ボーナス
    bound += 0.3;
    if (tid === tenant_id) {
      weight += 0.3;
      reasons.push('同一顧客');
    }

    const similarity = bound === 0 ? 0 : Number((weight / bound).toFixed(3));
    if (similarity > 0) {
      scored.push({
        project_id,
        tenant_id: tid,
        similarity,
        reasons,
      });
    }
  }

  scored.sort((a, b) => b.similarity - a.similarity);
  return scored.slice(0, 5);
}

/* ───── 4) compareProjects ───── */

export function compareProjects(
  sier_id: SierId,
  project_ids: string[]
): { aspect: string; values: Record<string, string> }[] {
  const projects = new Map<string, ProjectProfile>();
  for (const pid of project_ids) {
    const pp = lookupProject(sier_id, pid);
    if (pp) projects.set(pid, pp);
  }

  const aspects: { key: string; pick: (p: ProjectProfile) => string }[] = [
    { key: 'display_name', pick: (p) => p.display_name },
    { key: 'industry', pick: (p) => p.industry ?? 'n/a' },
    { key: 'status', pick: (p) => p.status },
    { key: 'outcome', pick: (p) => p.outcome ?? 'in_progress' },
    { key: 'frontend', pick: (p) => (p.tech_stack.frontend ?? []).join(', ') || 'n/a' },
    { key: 'backend', pick: (p) => (p.tech_stack.backend ?? []).join(', ') || 'n/a' },
    { key: 'database', pick: (p) => (p.tech_stack.database ?? []).join(', ') || 'n/a' },
    { key: 'infrastructure', pick: (p) => (p.tech_stack.infrastructure ?? []).join(', ') || 'n/a' },
    { key: 'cicd', pick: (p) => (p.tech_stack.cicd ?? []).join(', ') || 'n/a' },
    { key: 'applicable_laws', pick: (p) => (p.applicable_laws ?? []).join(', ') || 'n/a' },
    { key: 'start_date', pick: (p) => p.start_date },
    { key: 'end_date', pick: (p) => p.end_date ?? 'n/a' },
    { key: 'decision_count', pick: (p) => String(p.meta.decision_count ?? 0) },
  ];

  const out: { aspect: string; values: Record<string, string> }[] = [];
  for (const a of aspects) {
    const values: Record<string, string> = {};
    for (const pid of project_ids) {
      const pp = projects.get(pid);
      values[pid] = pp ? a.pick(pp) : 'unknown';
    }
    out.push({ aspect: a.key, values });
  }
  return out;
}

/* ───── 5) extractSuccessFactors ───── */

export function extractSuccessFactors(
  scope: 'sier' | 'customer',
  scope_id: string
): SuccessFactor[] {
  // success プロジェクトを集めて、頻出する判断テキスト/技術スタックを相関スコア化
  const successProjects: ProjectProfile[] = [];
  const successDecisions: DecisionRecord[] = [];
  const allProjects: ProjectProfile[] = [];
  const allDecisions: DecisionRecord[] = [];

  if (scope === 'sier') {
    const sid = scope_id as SierId;
    for (const { tenant_id, project_id } of listAllProjectsInSier(sid)) {
      const pp = readProjectProfile(sid, tenant_id, project_id);
      if (!pp) continue;
      allProjects.push(pp);
      const decs = readDecisionsForCustomer(sid, tenant_id).filter(
        (d) => d.project_id === project_id
      );
      allDecisions.push(...decs);
      if (pp.outcome === 'success') {
        successProjects.push(pp);
        successDecisions.push(...decs);
      }
    }
  } else {
    // customer
    for (const sid of listAllSiers()) {
      const customersBase = path.join(sierDir(sid), 'customers', scope_id, 'projects');
      if (!fs.existsSync(customersBase)) continue;
      for (const pd of fs.readdirSync(customersBase, { withFileTypes: true })) {
        if (!pd.isDirectory()) continue;
        const pp = readProjectProfile(sid, scope_id, pd.name);
        if (!pp) continue;
        allProjects.push(pp);
        const decs = readDecisionsForCustomer(sid, scope_id).filter(
          (d) => d.project_id === pd.name
        );
        allDecisions.push(...decs);
        if (pp.outcome === 'success') {
          successProjects.push(pp);
          successDecisions.push(...decs);
        }
      }
    }
  }

  if (allProjects.length === 0) return [];

  const factors: SuccessFactor[] = [];
  // 1) 技術スタックの相関
  const stackTotal = new Map<string, number>();
  const stackSuccess = new Map<string, number>();
  const collectStack = (
    map: Map<string, number>,
    p: ProjectProfile,
    weight = 1
  ): void => {
    for (const k of ['frontend', 'backend', 'database', 'infrastructure', 'cicd'] as const) {
      for (const v of p.tech_stack[k] ?? []) {
        const key = `${k}:${v}`;
        map.set(key, (map.get(key) ?? 0) + weight);
      }
    }
  };
  for (const p of allProjects) collectStack(stackTotal, p);
  for (const p of successProjects) collectStack(stackSuccess, p);

  for (const [key, totalCount] of stackTotal) {
    if (totalCount < 2) continue;
    const s = stackSuccess.get(key) ?? 0;
    const corr = s / totalCount;
    if (corr <= 0) continue;
    factors.push({
      factor: `tech_stack:${key}`,
      correlation: Number(corr.toFixed(3)),
      description: `${key} を採用したプロジェクト ${totalCount} 件中 ${s} 件が success`,
    });
  }

  // 2) 判断トークンの相関 (token frequency)
  const decTotalTok = new Map<string, number>();
  const decSuccTok = new Map<string, number>();
  const addTokens = (map: Map<string, number>, ds: DecisionRecord[]): void => {
    for (const d of ds) {
      for (const t of new Set(tokenize(`${d.title} ${d.decision}`))) {
        map.set(t, (map.get(t) ?? 0) + 1);
      }
    }
  };
  addTokens(decTotalTok, allDecisions);
  addTokens(decSuccTok, successDecisions);
  for (const [tok, total] of decTotalTok) {
    if (total < 3) continue;
    const s = decSuccTok.get(tok) ?? 0;
    const corr = s / total;
    if (corr <= 0.5) continue; // 半分以下は捨てる
    factors.push({
      factor: `decision_token:${tok}`,
      correlation: Number(corr.toFixed(3)),
      description: `判断テキストに "${tok}" を含む ${total} 件中 ${s} 件が success`,
    });
  }

  factors.sort((a, b) => b.correlation - a.correlation);
  return factors.slice(0, 25);
}

/* ───── 6) persistDistilledPatterns ───── */

export function persistDistilledPatterns(
  scope: 'sier' | 'global',
  scope_id: string,
  patterns: CrossProjectPattern[]
): void {
  for (const p of patterns) {
    appendPattern(scope, scope_id, p);
  }
}

export const __testing__ = {
  tokenize,
  jaccard,
  tokenSimilarity,
  clusterDecisions,
  outcomeScore,
  summarizePattern,
  recommendationFromPattern,
};
