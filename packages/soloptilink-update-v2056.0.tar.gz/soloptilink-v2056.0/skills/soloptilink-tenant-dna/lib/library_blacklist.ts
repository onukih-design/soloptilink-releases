/**
 * Library Blacklist Module — 採用禁止ライブラリの CRUD/検証/代替提案
 *
 * 責務:
 *   - 顧客 (tenant) 単位の禁則ライブラリ登録/解除/問い合わせ
 *   - SIer 全体共通禁則 (tenant_id="__sier_default__") の参照
 *   - package.json / requirements.txt の検査と違反検出
 *   - 代替ライブラリの提案
 *   - SIer 内蔵デフォルト禁則 (banking/public/legacy など) の供給
 *
 * 入力:
 *   - banLibrary: 禁則登録パラメタ (library_name/language/scope/reason ほか)
 *   - validatePackageJson: package.json の文字列内容
 *   - validateRequirementsTxt: pip requirements.txt の文字列内容
 *
 * 出力:
 *   - LibraryBlacklistEntry (types.ts) もしくは違反リスト
 *
 * ストレージ: storage.readBlacklist / writeBlacklist のみを使用 (fs 直触り禁止)
 */

import {
  readBlacklist,
  writeBlacklist,
} from './storage';
import type {
  SierId,
  LibraryBlacklistEntry,
} from './types';

/** SIer 全体共通禁則の擬似 tenant_id */
export const SIER_DEFAULT_TENANT = '__sier_default__';

type BanLanguage = LibraryBlacklistEntry['language'];
type BanScope = LibraryBlacklistEntry['scope'];

export interface BanLibraryInput {
  tenant_id: string;
  library_name: string;
  language: BanLanguage;
  reason: string;
  alternative_recommendation?: string;
  banned_until?: string;
  scope: BanScope;
  related_project_ids?: string[];
  source_decision_id?: string;
}

export interface IsBannedResult {
  banned: boolean;
  entry?: LibraryBlacklistEntry;
  reason?: string;
}

export interface ValidateResult {
  violations: { library: string; reason: string; alternative?: string }[];
  clean: boolean;
}

/* ───── Helpers ───── */

function nowIso(): string {
  return new Date().toISOString();
}

function todayIso(): string {
  return new Date().toISOString().slice(0, 10);
}

/** 大文字小文字・@scope/foo を考慮してライブラリ名を正規化 */
function normalizeLibName(name: string): string {
  return name.trim().toLowerCase();
}

/** banned_until が今日以前か判定 (期限切れ=有効でない) */
function isExpired(entry: LibraryBlacklistEntry): boolean {
  if (!entry.banned_until) return false;
  const until = entry.banned_until.slice(0, 10);
  return until < todayIso();
}

/** 同一 (library, language, tenant_id) のエントリ index を返す。なければ -1 */
function findEntryIndex(
  list: LibraryBlacklistEntry[],
  library: string,
  language: BanLanguage
): number {
  const target = normalizeLibName(library);
  return list.findIndex(
    (e) =>
      normalizeLibName(e.library_name) === target &&
      (e.language === language || e.language === 'any')
  );
}

/* ───── CRUD ───── */

/** 禁則を登録 (既存なら上書き更新) し、保存後のエントリを返す */
export function banLibrary(
  input: BanLibraryInput,
  sier_id: SierId
): LibraryBlacklistEntry {
  const tenant_id = input.tenant_id;
  const list = readBlacklist(sier_id, tenant_id);
  const entry: LibraryBlacklistEntry = {
    tenant_id,
    library_name: input.library_name.trim(),
    language: input.language,
    reason: input.reason,
    alternative_recommendation: input.alternative_recommendation,
    banned_at: nowIso(),
    banned_until: input.banned_until,
    scope: input.scope,
    related_project_ids: input.related_project_ids,
    source_decision_id: input.source_decision_id,
  };
  const idx = findEntryIndex(list, entry.library_name, entry.language);
  if (idx >= 0) {
    list[idx] = entry;
  } else {
    list.push(entry);
  }
  writeBlacklist(sier_id, tenant_id, list);
  return entry;
}

/**
 * 禁則を解除する。
 * 仕様: 履歴を残すため削除ではなく banned_until を today に更新する。
 */
export function unbanLibrary(
  sier_id: SierId,
  tenant_id: string,
  library_name: string,
  language: string
): void {
  const list = readBlacklist(sier_id, tenant_id);
  const lang = language as BanLanguage;
  const idx = findEntryIndex(list, library_name, lang);
  if (idx < 0) return;
  list[idx] = {
    ...list[idx],
    banned_until: todayIso(),
  };
  writeBlacklist(sier_id, tenant_id, list);
}

/* ───── 問い合わせ ───── */

/**
 * 指定ライブラリが当該テナント (＋オプション project) で禁止されているか判定。
 * 判定順:
 *   1. customer 固有禁則 (tenant_id) 内で hit を探索
 *   2. SIer 共通禁則 (__sier_default__) 内で hit を探索
 *   3. scope=production_only: project 指定が無いか production 扱い時のみ ban
 *   4. scope=specific_projects: related_project_ids に含まれる project のみ ban
 *   5. banned_until を過ぎていれば ban 無効
 */
export function isLibraryBanned(
  sier_id: SierId,
  tenant_id: string,
  library_name: string,
  language: string,
  project_id?: string
): IsBannedResult {
  const lang = language as BanLanguage;
  const tenantList = readBlacklist(sier_id, tenant_id);
  const sierList = readBlacklist(sier_id, SIER_DEFAULT_TENANT);
  const candidates = [...tenantList, ...sierList];

  for (const e of candidates) {
    if (isExpired(e)) continue;
    if (lang !== 'any' && e.language !== 'any' && e.language !== lang) continue;
    if (normalizeLibName(e.library_name) !== normalizeLibName(library_name)) continue;

    if (e.scope === 'production_only') {
      // production_only は project_id 不明 (=本番 build) を悲観視して ban
      // project_id が指定されていて、明示的に "dev" や "test" を示さない限り ban
      const isProductionContext = !project_id || !/dev|test|sandbox|preview/i.test(project_id);
      if (!isProductionContext) continue;
    }
    if (e.scope === 'specific_projects') {
      if (!project_id) continue;
      if (!(e.related_project_ids ?? []).includes(project_id)) continue;
    }

    return {
      banned: true,
      entry: e,
      reason: e.reason,
    };
  }

  return { banned: false };
}

/* ───── package.json 検査 ───── */

interface PkgJsonShape {
  dependencies?: Record<string, string>;
  devDependencies?: Record<string, string>;
  peerDependencies?: Record<string, string>;
  optionalDependencies?: Record<string, string>;
}

export function validatePackageJson(
  package_json_content: string,
  sier_id: SierId,
  tenant_id: string
): ValidateResult {
  const violations: ValidateResult['violations'] = [];
  let parsed: PkgJsonShape;
  try {
    parsed = JSON.parse(package_json_content) as PkgJsonShape;
  } catch {
    return {
      violations: [
        { library: '<package.json>', reason: 'package.json が JSON として不正です' },
      ],
      clean: false,
    };
  }

  const allDeps: Record<string, string> = {
    ...(parsed.dependencies ?? {}),
    ...(parsed.devDependencies ?? {}),
    ...(parsed.peerDependencies ?? {}),
    ...(parsed.optionalDependencies ?? {}),
  };

  for (const libName of Object.keys(allDeps)) {
    // typescript / javascript いずれかでヒットを許す
    const tsHit = isLibraryBanned(sier_id, tenant_id, libName, 'typescript');
    const jsHit = tsHit.banned ? tsHit : isLibraryBanned(sier_id, tenant_id, libName, 'javascript');
    if (jsHit.banned && jsHit.entry) {
      violations.push({
        library: libName,
        reason: jsHit.entry.reason,
        alternative: jsHit.entry.alternative_recommendation,
      });
    }
  }

  return { violations, clean: violations.length === 0 };
}

/* ───── requirements.txt 検査 ───── */

export function validateRequirementsTxt(
  requirements_content: string,
  sier_id: SierId,
  tenant_id: string
): ValidateResult {
  const violations: ValidateResult['violations'] = [];
  const lines = requirements_content.split(/\r?\n/);

  for (const raw of lines) {
    const line = raw.trim();
    if (!line) continue;
    if (line.startsWith('#')) continue;
    if (line.startsWith('-')) continue; // -r requirements-dev.txt 等
    // パッケージ名抽出 (例: "django==4.2.0", "numpy>=1.0", "package[extra]>=1")
    const match = line.match(/^([A-Za-z0-9_.\-]+)/);
    if (!match) continue;
    const libName = match[1];
    const hit = isLibraryBanned(sier_id, tenant_id, libName, 'python');
    if (hit.banned && hit.entry) {
      violations.push({
        library: libName,
        reason: hit.entry.reason,
        alternative: hit.entry.alternative_recommendation,
      });
    }
  }

  return { violations, clean: violations.length === 0 };
}

/* ───── 代替提案 ───── */

export function suggestAlternative(
  library_name: string,
  sier_id: SierId,
  tenant_id: string
): string | null {
  const target = normalizeLibName(library_name);
  const sources: LibraryBlacklistEntry[] = [
    ...readBlacklist(sier_id, tenant_id),
    ...readBlacklist(sier_id, SIER_DEFAULT_TENANT),
  ];
  for (const e of sources) {
    if (isExpired(e)) continue;
    if (normalizeLibName(e.library_name) !== target) continue;
    if (e.alternative_recommendation && e.alternative_recommendation.trim().length > 0) {
      return e.alternative_recommendation;
    }
  }
  return null;
}

/* ───── 一覧 API ───── */

export function listBannedForCustomer(
  sier_id: SierId,
  tenant_id: string
): LibraryBlacklistEntry[] {
  return readBlacklist(sier_id, tenant_id).filter((e) => !isExpired(e));
}

export function listBannedForSier(sier_id: SierId): LibraryBlacklistEntry[] {
  return readBlacklist(sier_id, SIER_DEFAULT_TENANT).filter((e) => !isExpired(e));
}

/* ───── SIer 内蔵デフォルト禁則 ───── */

/**
 * SIer ごとのデフォルト禁則サンプル群。
 * 実プロジェクトでは banLibrary 経由で永続化することを推奨するが、
 * 初期セットアップ時にこの関数の戻り値を一括 ban することで
 * 「nttdata は古い Spring を禁止」「金融系は GraphQL 禁止」等を即時適用できる。
 */
export function defaultBlacklistForSier(sier_id: SierId): LibraryBlacklistEntry[] {
  const at = nowIso();
  const base = (
    library_name: string,
    language: BanLanguage,
    reason: string,
    alternative_recommendation?: string,
    scope: BanScope = 'all_projects'
  ): LibraryBlacklistEntry => ({
    tenant_id: SIER_DEFAULT_TENANT,
    library_name,
    language,
    reason,
    alternative_recommendation,
    banned_at: at,
    scope,
  });

  switch (sier_id) {
    case 'nttdata':
      return [
        base(
          'spring-boot',
          'java',
          'NTTデータ標準フレームワーク (TERASOLUNA) と競合。Spring Boot 単独採用は禁止',
          'TERASOLUNA Server Framework for Java (5.x)',
          'production_only'
        ),
        base(
          'lombok',
          'java',
          '社内静的解析 (Sonar) で除外設定が困難なため非採用',
          '明示的な getter/setter または record (Java 16+)'
        ),
        base(
          'mongoose',
          'javascript',
          '本部標準は PostgreSQL/Oracle。MongoDB は AP 構造として採用しない',
          'TypeORM + PostgreSQL'
        ),
        base(
          'next-auth',
          'typescript',
          '社内 SSO (CIAM) と統合不可。独自連携は監査未通過',
          '社内 CIAM SDK + iron-session'
        ),
      ];

    case 'fujitsu':
      return [
        base(
          'tomcat',
          'java',
          '富士通標準 AP サーバは Interstage Application Server。Tomcat 単独採用は禁止',
          'Interstage Application Server V12'
        ),
        base(
          'webpack',
          'javascript',
          '社内ビルド標準は Vite/esbuild に統一中',
          'Vite 5 + esbuild'
        ),
        base(
          'jest',
          'javascript',
          '社内 CI が vitest 標準のため重複導入禁止',
          'vitest 1.x'
        ),
        base(
          'log4j',
          'java',
          'Log4Shell 経緯から社内全面禁止',
          'logback 1.4 もしくは java.util.logging'
        ),
      ];

    case 'nri':
      return [
        base(
          'mongoose',
          'javascript',
          'NRI 金融系は ACID 必須のため MongoDB 全面禁止',
          'PostgreSQL 15 + Prisma',
          'production_only'
        ),
        base(
          'graphql',
          'javascript',
          'NRI 金融系は監査トレースを REST + OpenAPI で統一。GraphQL 禁止',
          'OpenAPI 3.1 + tRPC (内部のみ可)',
          'production_only'
        ),
        base(
          'firebase',
          'javascript',
          'データ越境・監査要件のため金融系プロジェクトでは禁止',
          'Auth0 (国内データ常駐) または Cognito Tokyo Region'
        ),
      ];

    case 'nomura':
      return [
        base(
          'mongodb',
          'any',
          '野村標準では FISC 安対要件を満たせないため全面禁止',
          'Oracle Database 19c もしくは PostgreSQL'
        ),
        base(
          'cdn-edge-functions',
          'typescript',
          'データ国外越境リスクのため Edge Functions 禁止',
          '国内リージョンの Lambda / Cloud Run のみ'
        ),
        base(
          'firebase',
          'any',
          '海外サーバ常駐のため野村業務プロジェクトでは禁止',
          'AWS Cognito (ap-northeast-1) または社内 IAM'
        ),
      ];

    case 'nec':
      return [
        base(
          'jboss',
          'java',
          'NEC 標準 AP サーバは WebOTX/WebSAM。JBoss は禁止',
          'WebOTX Application Server V11'
        ),
        base(
          'apache-cassandra',
          'any',
          '保守要員確保が困難なため社内禁止',
          'PostgreSQL クラスタ + Citus'
        ),
        base(
          'puppet',
          'any',
          'NEC 標準は Ansible/WebSAM。Puppet 禁止',
          'Ansible + WebSAM SystemManager'
        ),
      ];

    case 'hitachi':
      return [
        base(
          'tomcat',
          'java',
          '日立標準 AP は Cosminexus。Tomcat 単独採用は禁止',
          'Cosminexus Application Server V11'
        ),
        base(
          'graphql',
          'any',
          'JP1 と連携する API は OpenAPI が必須。GraphQL は監査外',
          'OpenAPI 3.1 + JP1/IT Service Management'
        ),
        base(
          'jenkins-pipeline',
          'any',
          '日立社内 CI 標準は JP1/Automatic Job Management。Jenkins は補助のみ',
          'JP1/AJS3 + GitHub Actions (補助)'
        ),
      ];

    case 'tis':
      return [
        base(
          'aurelia',
          'javascript',
          'TIS フロント標準は React/Next.js。Aurelia は保守困難で禁止',
          'Next.js 15 (App Router)'
        ),
        base(
          'mongodb',
          'any',
          'TIS 公共系は MongoDB を採用しない',
          'PostgreSQL 15'
        ),
        base(
          'rancher',
          'any',
          'TIS インフラ標準は EKS/AKS。Rancher は管理対象外',
          'Amazon EKS or Azure AKS'
        ),
      ];

    case 'generic':
    default:
      return [
        base(
          'request',
          'javascript',
          '2020 年に deprecated。脆弱性パッチが提供されないため新規採用禁止',
          'undici / fetch (Node 18+) / axios'
        ),
        base(
          'moment',
          'javascript',
          'Tree-shake 不可で bundle 肥大。新規採用禁止',
          'date-fns / dayjs / Temporal'
        ),
        base(
          'log4j',
          'java',
          'Log4Shell 後、未パッチ系統は使用禁止',
          'logback もしくは Log4j 2.17.1+ (検証済 build のみ)'
        ),
      ];
  }
}

export const __testing__ = {
  isExpired,
  normalizeLibName,
  findEntryIndex,
};
