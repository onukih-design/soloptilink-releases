/**
 * Naming Convention - 命名規則の定義 / 検証 / コードスニペット適用
 *
 * 責務:
 *  - NamingRule の定義 / 永続化 (顧客スコープ)
 *  - 個別識別子のケース変換 (snake_case ↔ camelCase ↔ PascalCase ↔ kebab-case ↔ UPPER_SNAKE)
 *  - 規則違反の検証 + 修正候補の生成
 *  - 既存の examples から規則を逆推論
 *  - コードスニペットへの簡易適用 (識別子のみ書換、文字列リテラル/コメントは保護)
 *  - SIer ごとの builtin 命名規則テンプレを返す
 *
 * 入出力:
 *  - 入力: NamingRule input / 識別子 / NamingCase / コード文字列
 *  - 出力: NamingRule, 検証結果, 変換結果, 推論結果, 変換済みスニペット
 *  - 副作用: 顧客スコープ naming.json を read/write (storage.ts 経由)
 */

import type {
  SierId,
  NamingCase,
  NamingRule,
} from './types';
import {
  STORAGE_ROOT,
  readNamingRules,
  writeNamingRules,
  generateId,
} from './storage';
import { getSier } from './tenant_profile';

/* ───── Types (input shapes) ─────────────────────────────────────── */

export interface DefineNamingRuleInput {
  tenant_id: string;
  sier_id: SierId;
  scope: NamingRule['scope'];
  case_style: NamingCase;
  prefix?: string;
  suffix?: string;
  forbidden_patterns?: string[];
  example_good?: string[];
  example_bad?: string[];
  rationale: string;
  enforced?: boolean;
  source_decision_id?: string;
}

export interface NameValidation {
  valid: boolean;
  errors: string[];
  suggestions: string[];
}

export interface NamingInferenceResult {
  case_style: NamingCase;
  prefix?: string;
  suffix?: string;
  confidence: number;
  detail?: {
    samples: number;
    case_distribution: Record<NamingCase, number>;
  };
}

export interface ApplyRulesResult {
  transformed: string;
  warnings: string[];
}

const SIER_DEFAULT_TENANT = '__sier_default__';

/* ───── Public API: define / list / persist ──────────────────────── */

export function defineNamingRule(
  input: DefineNamingRuleInput,
  root: string = STORAGE_ROOT
): NamingRule {
  const rule: NamingRule = {
    tenant_id: input.tenant_id,
    rule_id: generateId('naming'),
    scope: input.scope,
    case_style: input.case_style,
    prefix: input.prefix,
    suffix: input.suffix,
    forbidden_patterns: input.forbidden_patterns,
    example_good: input.example_good,
    example_bad: input.example_bad,
    rationale: input.rationale,
    enforced: input.enforced ?? true,
    source_decision_id: input.source_decision_id,
  };

  // SIer-default は永続化しない (毎回 builtin から導出するため)
  if (input.tenant_id === SIER_DEFAULT_TENANT) {
    return rule;
  }

  const existing = readNamingRules(input.sier_id, input.tenant_id, root);
  // 同 scope の重複は新しいもので置き換える (rule_id は新規)
  const filtered = existing.filter(
    (r) => !(r.scope === rule.scope && r.case_style === rule.case_style && r.prefix === rule.prefix && r.suffix === rule.suffix)
  );
  writeNamingRules(input.sier_id, input.tenant_id, [...filtered, rule], root);
  return rule;
}

/**
 * 顧客スコープ + SIer デフォルトをマージし、enforced=true のもののみ返す。
 * 同 scope については「顧客カスタム」を優先し、不足分のみ SIer デフォルトで補完。
 */
export function getActiveNamingRules(
  sier_id: SierId,
  tenant_id: string,
  root: string = STORAGE_ROOT
): NamingRule[] {
  const tenantRules = readNamingRules(sier_id, tenant_id, root).filter((r) => r.enforced);
  const sierDefaults = defaultRulesForSier(sier_id);
  const tenantScopes = new Set(tenantRules.map((r) => r.scope));
  const filledFromSier = sierDefaults.filter((r) => r.enforced && !tenantScopes.has(r.scope));
  return [...tenantRules, ...filledFromSier];
}

/* ───── Public API: validate / convert / infer / apply ──────────── */

export function validateName(name: string, rule: NamingRule): NameValidation {
  const errors: string[] = [];
  const suggestions: string[] = [];
  const trimmed = (name ?? '').trim();

  if (!trimmed) {
    return { valid: false, errors: ['name is empty'], suggestions: [] };
  }

  // prefix
  let core = trimmed;
  if (rule.prefix) {
    if (!core.startsWith(rule.prefix)) {
      errors.push(`missing required prefix "${rule.prefix}"`);
      suggestions.push(`${rule.prefix}${convertNameToCase(core, rule.case_style)}`);
    } else {
      core = core.slice(rule.prefix.length);
    }
  }
  // suffix
  if (rule.suffix) {
    if (!core.endsWith(rule.suffix)) {
      errors.push(`missing required suffix "${rule.suffix}"`);
      suggestions.push(`${rule.prefix ?? ''}${convertNameToCase(core, rule.case_style)}${rule.suffix}`);
    } else {
      core = core.slice(0, -rule.suffix.length);
    }
  }

  // case_style
  if (!matchesCase(core, rule.case_style)) {
    errors.push(`identifier "${core}" does not match required case "${rule.case_style}"`);
    suggestions.push(
      `${rule.prefix ?? ''}${convertNameToCase(core, rule.case_style)}${rule.suffix ?? ''}`
    );
  }

  // forbidden_patterns
  if (rule.forbidden_patterns && rule.forbidden_patterns.length > 0) {
    for (const raw of rule.forbidden_patterns) {
      try {
        const re = new RegExp(raw);
        if (re.test(trimmed)) {
          errors.push(`matches forbidden pattern "${raw}"`);
        }
      } catch {
        // 正規表現でなければ部分一致でチェック
        if (trimmed.includes(raw)) {
          errors.push(`contains forbidden substring "${raw}"`);
        }
      }
    }
  }

  return {
    valid: errors.length === 0,
    errors,
    suggestions: dedupe(suggestions),
  };
}

export function convertNameToCase(name: string, target: NamingCase): string {
  const tokens = tokenize(name);
  if (tokens.length === 0) return name;
  switch (target) {
    case 'snake_case':
      return tokens.map((t) => t.toLowerCase()).join('_');
    case 'UPPER_SNAKE':
      return tokens.map((t) => t.toUpperCase()).join('_');
    case 'kebab-case':
      return tokens.map((t) => t.toLowerCase()).join('-');
    case 'camelCase':
      return tokens
        .map((t, i) =>
          i === 0 ? t.toLowerCase() : t.charAt(0).toUpperCase() + t.slice(1).toLowerCase()
        )
        .join('');
    case 'PascalCase':
      return tokens.map((t) => t.charAt(0).toUpperCase() + t.slice(1).toLowerCase()).join('');
    case 'mixed':
      return name;
    default:
      return name;
  }
}

export function inferRuleFromExamples(examples: string[]): NamingInferenceResult {
  const samples = (examples ?? []).map((e) => (e ?? '').trim()).filter(Boolean);
  const distribution: Record<NamingCase, number> = {
    snake_case: 0,
    camelCase: 0,
    PascalCase: 0,
    'kebab-case': 0,
    UPPER_SNAKE: 0,
    mixed: 0,
  };

  if (samples.length === 0) {
    return {
      case_style: 'mixed',
      confidence: 0,
      detail: { samples: 0, case_distribution: distribution },
    };
  }

  // prefix / suffix 検出: 全サンプル共通の最長 prefix/suffix を取り、core 部分でケース判定
  const commonPrefix = longestCommonPrefix(samples);
  const commonSuffix = longestCommonSuffix(samples);
  const cores = samples.map((s) => s.slice(commonPrefix.length, s.length - commonSuffix.length));

  for (const c of cores) {
    distribution[detectCase(c)] += 1;
  }

  let bestCase: NamingCase = 'mixed';
  let bestCount = 0;
  for (const k of Object.keys(distribution) as NamingCase[]) {
    if (distribution[k] > bestCount) {
      bestCount = distribution[k];
      bestCase = k;
    }
  }
  const confidence = bestCount / samples.length;
  return {
    case_style: bestCase,
    prefix: commonPrefix.length > 0 ? commonPrefix : undefined,
    suffix: commonSuffix.length > 0 ? commonSuffix : undefined,
    confidence,
    detail: { samples: samples.length, case_distribution: distribution },
  };
}

/**
 * コードスニペットに規則を適用する簡易置換器。
 *  - 文字列リテラル / コメントは保護してから識別子を抽出 → 変換 → 復元。
 *  - SQL は文字列リテラル ('...') をマスク、それ以外の識別子をすべて対象。
 *  - JSON はキー名 ("key": ) のみを対象。
 *  - TypeScript は変数/関数名候補 (英数字+_) を対象とし、予約語は触らない。
 */
export function applyRulesToCodeSnippet(
  snippet: string,
  rules: NamingRule[],
  language: 'typescript' | 'sql' | 'json'
): ApplyRulesResult {
  const warnings: string[] = [];
  if (!snippet) return { transformed: snippet, warnings };

  const ruleByScope = pickRuleByLanguage(rules, language);
  if (!ruleByScope) {
    warnings.push(`no applicable rule for language=${language}`);
    return { transformed: snippet, warnings };
  }

  if (language === 'json') {
    const transformed = snippet.replace(
      /"([A-Za-z_][A-Za-z0-9_-]*)"\s*:/g,
      (_m, key: string) => `"${transformIdentifier(key, ruleByScope, warnings)}":`
    );
    return { transformed, warnings };
  }

  if (language === 'sql') {
    // 文字列リテラル ('...') をマスク
    const masked: string[] = [];
    let working = snippet.replace(/'((?:[^']|'')*)'/g, (_m, body: string) => {
      masked.push(`'${body}'`);
      return `__SQL_LIT_${masked.length - 1}__`;
    });
    // ライン/ブロックコメントもマスク
    const comments: string[] = [];
    working = working.replace(/--[^\n]*/g, (m) => {
      comments.push(m);
      return `__SQL_COM_${comments.length - 1}__`;
    });
    working = working.replace(/\/\*[\s\S]*?\*\//g, (m) => {
      comments.push(m);
      return `__SQL_COM_${comments.length - 1}__`;
    });
    // 識別子変換 (SQL 予約語は除外)
    working = working.replace(/\b([A-Za-z_][A-Za-z0-9_]*)\b/g, (m, ident: string) => {
      if (isSqlKeyword(ident)) return m;
      return transformIdentifier(ident, ruleByScope, warnings);
    });
    // restore
    working = working.replace(/__SQL_COM_(\d+)__/g, (_m, idx: string) => comments[Number(idx)] ?? '');
    working = working.replace(/__SQL_LIT_(\d+)__/g, (_m, idx: string) => masked[Number(idx)] ?? '');
    return { transformed: working, warnings };
  }

  // TypeScript
  const masked: string[] = [];
  let working = snippet
    .replace(/`(?:\\.|[^`])*`/g, (m) => maskAndPush(masked, m, 'TS_LIT'))
    .replace(/"(?:\\.|[^"])*"/g, (m) => maskAndPush(masked, m, 'TS_LIT'))
    .replace(/'(?:\\.|[^'])*'/g, (m) => maskAndPush(masked, m, 'TS_LIT'))
    .replace(/\/\/[^\n]*/g, (m) => maskAndPush(masked, m, 'TS_LIT'))
    .replace(/\/\*[\s\S]*?\*\//g, (m) => maskAndPush(masked, m, 'TS_LIT'));

  working = working.replace(/\b([A-Za-z_$][A-Za-z0-9_$]*)\b/g, (m, ident: string) => {
    if (isTsKeyword(ident)) return m;
    return transformIdentifier(ident, ruleByScope, warnings);
  });

  working = working.replace(/__TS_LIT_(\d+)__/g, (_m, idx: string) => masked[Number(idx)] ?? '');
  return { transformed: working, warnings };
}

/* ───── SIer-default rules ──────────────────────────────────────── */

export function defaultRulesForSier(sier_id: SierId): NamingRule[] {
  const profile = getSier(sier_id);
  if (!profile) return [];

  const make = (
    scope: NamingRule['scope'],
    case_style: NamingCase,
    prefix?: string,
    rationale?: string
  ): NamingRule => ({
    tenant_id: SIER_DEFAULT_TENANT,
    rule_id: `sier-default-${sier_id}-${scope}`,
    scope,
    case_style,
    prefix,
    rationale: rationale ?? `${profile.display_name_ja} default`,
    enforced: true,
  });

  const rules: NamingRule[] = [
    make('db_table', profile.default_naming.db_table, profile.default_naming.table_prefix),
    make('db_column', profile.default_naming.db_column),
    make('typescript_var', profile.default_naming.typescript_var),
    make('typescript_type', 'PascalCase'),
    make('api_path', profile.default_naming.api_path),
    make('route', profile.default_naming.api_path),
    make('component', 'PascalCase'),
    make('file', profile.default_naming.api_path),
  ];
  return rules;
}

/* ───── Helpers: tokenization / case detection ──────────────────── */

function tokenize(name: string): string[] {
  if (!name) return [];
  const trimmed = name.trim();
  if (!trimmed) return [];

  // 区切り文字 _ - スペース で分割
  if (/[_\-\s]/.test(trimmed)) {
    return trimmed
      .split(/[_\-\s]+/)
      .map((p) => p.trim())
      .filter(Boolean);
  }
  // camelCase / PascalCase の境界で分割
  // 先頭は文字、続いて (大文字+小文字) または (連続大文字) を境界化
  return trimmed
    .replace(/([A-Z]+)([A-Z][a-z])/g, '$1 $2')
    .replace(/([a-z\d])([A-Z])/g, '$1 $2')
    .split(' ')
    .map((p) => p.trim())
    .filter(Boolean);
}

function matchesCase(core: string, target: NamingCase): boolean {
  if (target === 'mixed') return true;
  return detectCase(core) === target;
}

function detectCase(s: string): NamingCase {
  if (!s) return 'mixed';
  if (/^[a-z]+(_[a-z0-9]+)*$/.test(s)) return 'snake_case';
  if (/^[A-Z]+(_[A-Z0-9]+)*$/.test(s)) return 'UPPER_SNAKE';
  if (/^[a-z]+(-[a-z0-9]+)*$/.test(s)) return 'kebab-case';
  if (/^[a-z][a-zA-Z0-9]*$/.test(s) && /[A-Z]/.test(s)) return 'camelCase';
  if (/^[A-Z][a-zA-Z0-9]*$/.test(s) && /[a-z]/.test(s)) return 'PascalCase';
  // 全部小文字で記号無し: snake のシングルワード扱いに寄せる
  if (/^[a-z]+$/.test(s)) return 'snake_case';
  if (/^[A-Z]+$/.test(s)) return 'UPPER_SNAKE';
  return 'mixed';
}

function longestCommonPrefix(arr: string[]): string {
  if (arr.length === 0) return '';
  let prefix = arr[0];
  for (let i = 1; i < arr.length; i++) {
    while (arr[i].indexOf(prefix) !== 0) {
      prefix = prefix.slice(0, -1);
      if (!prefix) return '';
    }
  }
  // 「単語境界で切れている」ことを尊重 (途中で切らない)
  // 末尾が _ - のいずれかになるまで縮める
  while (prefix.length > 0 && !/[_-]$/.test(prefix) && !isUpperBoundaryPrefix(prefix, arr)) {
    prefix = prefix.slice(0, -1);
  }
  return prefix;
}

function isUpperBoundaryPrefix(prefix: string, arr: string[]): boolean {
  // 全 sample で prefix 直後が大文字なら境界とみなす
  return arr.every((s) => {
    const next = s.charAt(prefix.length);
    return next === '' || /[A-Z]/.test(next);
  });
}

function longestCommonSuffix(arr: string[]): string {
  if (arr.length === 0) return '';
  let suffix = arr[0];
  for (let i = 1; i < arr.length; i++) {
    while (suffix && !arr[i].endsWith(suffix)) {
      suffix = suffix.slice(1);
    }
    if (!suffix) return '';
  }
  // 単語境界に整える
  while (suffix.length > 0 && !/^[_-]/.test(suffix) && !isUpperBoundarySuffix(suffix, arr)) {
    suffix = suffix.slice(1);
  }
  return suffix;
}

function isUpperBoundarySuffix(suffix: string, arr: string[]): boolean {
  return arr.every((s) => {
    const idx = s.length - suffix.length - 1;
    if (idx < 0) return true;
    const prev = s.charAt(idx);
    return /[a-z0-9_-]/.test(prev) && /[A-Z]/.test(suffix.charAt(0));
  });
}

function dedupe(arr: string[]): string[] {
  return Array.from(new Set(arr));
}

/* ───── Helpers: code transform ─────────────────────────────────── */

function pickRuleByLanguage(
  rules: NamingRule[],
  language: 'typescript' | 'sql' | 'json'
): NamingRule | null {
  if (rules.length === 0) return null;
  switch (language) {
    case 'typescript':
      return rules.find((r) => r.scope === 'typescript_var') ?? null;
    case 'sql':
      return rules.find((r) => r.scope === 'db_column') ?? rules.find((r) => r.scope === 'db_table') ?? null;
    case 'json':
      return rules.find((r) => r.scope === 'typescript_var') ?? rules.find((r) => r.scope === 'api_path') ?? null;
    default:
      return null;
  }
}

function transformIdentifier(ident: string, rule: NamingRule, warnings: string[]): string {
  // prefix/suffix を一旦除去
  let core = ident;
  if (rule.prefix && core.startsWith(rule.prefix)) {
    core = core.slice(rule.prefix.length);
  }
  if (rule.suffix && core.endsWith(rule.suffix)) {
    core = core.slice(0, -rule.suffix.length);
  }
  if (rule.forbidden_patterns) {
    for (const p of rule.forbidden_patterns) {
      try {
        if (new RegExp(p).test(ident)) {
          warnings.push(`forbidden_pattern matched: ${ident} ~ ${p}`);
        }
      } catch {
        if (ident.includes(p)) {
          warnings.push(`forbidden_substring: ${ident} ~ ${p}`);
        }
      }
    }
  }
  const converted = convertNameToCase(core, rule.case_style);
  return `${rule.prefix ?? ''}${converted}${rule.suffix ?? ''}`;
}

function maskAndPush(store: string[], value: string, _tag: string): string {
  store.push(value);
  return `__TS_LIT_${store.length - 1}__`;
}

const SQL_KEYWORDS = new Set([
  'SELECT', 'FROM', 'WHERE', 'AND', 'OR', 'NOT', 'NULL', 'IS', 'IN', 'BETWEEN', 'LIKE',
  'INSERT', 'INTO', 'VALUES', 'UPDATE', 'SET', 'DELETE', 'CREATE', 'TABLE', 'INDEX',
  'PRIMARY', 'KEY', 'FOREIGN', 'REFERENCES', 'JOIN', 'INNER', 'LEFT', 'RIGHT', 'FULL',
  'ON', 'AS', 'GROUP', 'BY', 'ORDER', 'ASC', 'DESC', 'HAVING', 'LIMIT', 'OFFSET', 'UNION',
  'ALL', 'DISTINCT', 'CASE', 'WHEN', 'THEN', 'ELSE', 'END', 'IF', 'EXISTS', 'TRUE', 'FALSE',
  'INT', 'INTEGER', 'BIGINT', 'SMALLINT', 'TEXT', 'VARCHAR', 'CHAR', 'BOOLEAN', 'DATE',
  'TIMESTAMP', 'DECIMAL', 'NUMERIC', 'DEFAULT', 'CHECK', 'CONSTRAINT', 'UNIQUE',
  'ALTER', 'ADD', 'COLUMN', 'DROP', 'RENAME', 'TO', 'WITH',
]);

function isSqlKeyword(s: string): boolean {
  return SQL_KEYWORDS.has(s.toUpperCase());
}

const TS_KEYWORDS = new Set([
  'break', 'case', 'catch', 'class', 'const', 'continue', 'debugger', 'default', 'delete',
  'do', 'else', 'enum', 'export', 'extends', 'false', 'finally', 'for', 'function', 'if',
  'import', 'in', 'instanceof', 'let', 'new', 'null', 'of', 'return', 'super', 'switch',
  'this', 'throw', 'true', 'try', 'typeof', 'var', 'void', 'while', 'with', 'yield',
  'as', 'async', 'await', 'from', 'interface', 'type', 'public', 'private', 'protected',
  'readonly', 'static', 'abstract', 'implements', 'never', 'unknown', 'any', 'string',
  'number', 'boolean', 'object', 'undefined', 'declare', 'is', 'keyof', 'satisfies',
  'true', 'false', 'null',
]);

function isTsKeyword(s: string): boolean {
  return TS_KEYWORDS.has(s);
}

/*
 * Module summary - exported functions:
 *  - defineNamingRule / getActiveNamingRules
 *  - validateName / convertNameToCase / inferRuleFromExamples / applyRulesToCodeSnippet
 *  - defaultRulesForSier
 *  Sentinel tenant_id for SIer-default rules: __sier_default__
 */
