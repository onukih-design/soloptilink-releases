/**
 * Memory Graph - 4階層 (SIer / Customer / Project / Decision) を統合的に扱う高レベルAPI
 *
 * 入出力: storage 層 + tenant_profile + decision_memory + cross_project_synthesizer の組合せ
 * 責務: 階層横断のクエリ・サマリ・グラフ可視化データ生成
 */

import type {
  SierId,
  SierProfile,
  CustomerProfile,
  ProjectProfile,
  DecisionRecord,
  RecallResult,
  TenantIndex,
} from './types';
import {
  buildIndex,
  writeIndex,
  STORAGE_ROOT,
  readDecisionsForCustomer,
  readDecisionsForProject,
  readNamingRules,
  readBlacklist,
  readPatterns,
} from './storage';
import {
  getSier,
  getCustomer,
  getProject,
  listAllSiers,
  listCustomersOfSier,
  listProjectsOfCustomer,
} from './tenant_profile';

export interface GraphNode {
  id: string;
  level: 'sier' | 'customer' | 'project' | 'decision';
  label: string;
  meta?: Record<string, unknown>;
}

export interface GraphEdge {
  from: string;
  to: string;
  kind: 'has_customer' | 'has_project' | 'has_decision' | 'supersedes' | 'related';
}

export interface GraphSnapshot {
  generated_at: string;
  nodes: GraphNode[];
  edges: GraphEdge[];
  totals: {
    siers: number;
    customers: number;
    projects: number;
    decisions: number;
  };
}

export interface GraphQuery {
  sier_id?: SierId;
  tenant_id?: string;
  project_id?: string;
  include_archived?: boolean;
  decision_limit?: number;
}

/**
 * メモリグラフのスナップショットを生成。SIerルートから子孫まで再帰的に探索。
 */
export function buildGraph(query: GraphQuery = {}, root: string = STORAGE_ROOT): GraphSnapshot {
  const nodes: GraphNode[] = [];
  const edges: GraphEdge[] = [];
  let totalDecisions = 0;
  let totalProjects = 0;
  let totalCustomers = 0;

  const siers = query.sier_id
    ? [getSier(query.sier_id)].filter((s): s is SierProfile => s !== null)
    : listAllSiers(root);

  for (const sier of siers) {
    const sierNodeId = `sier:${sier.sier_id}`;
    nodes.push({
      id: sierNodeId,
      level: 'sier',
      label: sier.display_name_ja,
      meta: {
        is_builtin: sier.meta.is_builtin,
        project_count: sier.meta.project_count,
      },
    });

    const customers = query.tenant_id
      ? [getCustomer(sier.sier_id, query.tenant_id)].filter(
          (c): c is CustomerProfile => c !== null
        )
      : listCustomersOfSier(sier.sier_id, root);

    for (const customer of customers) {
      const customerNodeId = `customer:${sier.sier_id}/${customer.tenant_id}`;
      nodes.push({
        id: customerNodeId,
        level: 'customer',
        label: customer.display_name,
        meta: {
          industry: customer.industry,
          size: customer.size,
        },
      });
      edges.push({ from: sierNodeId, to: customerNodeId, kind: 'has_customer' });
      totalCustomers++;

      const projects = query.project_id
        ? [getProject(sier.sier_id, customer.tenant_id, query.project_id)].filter(
            (p): p is ProjectProfile => p !== null
          )
        : listProjectsOfCustomer(sier.sier_id, customer.tenant_id, root);

      for (const project of projects) {
        if (!query.include_archived && project.status === 'archived') continue;
        const projectNodeId = `project:${sier.sier_id}/${customer.tenant_id}/${project.project_id}`;
        nodes.push({
          id: projectNodeId,
          level: 'project',
          label: project.display_name,
          meta: {
            status: project.status,
            outcome: project.outcome,
            industry: project.industry,
          },
        });
        edges.push({ from: customerNodeId, to: projectNodeId, kind: 'has_project' });
        totalProjects++;

        const decisions = readDecisionsForProject(
          sier.sier_id,
          customer.tenant_id,
          project.project_id,
          root
        );
        const limited = query.decision_limit ? decisions.slice(-query.decision_limit) : decisions;

        for (const d of limited) {
          const decisionNodeId = `decision:${d.decision_id}`;
          nodes.push({
            id: decisionNodeId,
            level: 'decision',
            label: d.title,
            meta: {
              category: d.category,
              status: d.status,
              decided_at: d.decided_at,
            },
          });
          edges.push({ from: projectNodeId, to: decisionNodeId, kind: 'has_decision' });
          if (d.superseded_by) {
            edges.push({
              from: decisionNodeId,
              to: `decision:${d.superseded_by}`,
              kind: 'supersedes',
            });
          }
          totalDecisions++;
        }
      }
    }
  }

  return {
    generated_at: new Date().toISOString(),
    nodes,
    edges,
    totals: {
      siers: siers.length,
      customers: totalCustomers,
      projects: totalProjects,
      decisions: totalDecisions,
    },
  };
}

/**
 * 階層別のサマリ統計を返す (ダッシュボード表示用)。
 */
export function summarizeMemory(root: string = STORAGE_ROOT): {
  index: TenantIndex;
  health: { status: 'empty' | 'starter' | 'healthy' | 'mature'; description: string };
  top_sier?: { sier_id: SierId; project_count: number };
} {
  const index = buildIndex(root);
  const status =
    index.total_decisions === 0
      ? 'empty'
      : index.total_decisions < 20
        ? 'starter'
        : index.total_decisions < 200
          ? 'healthy'
          : 'mature';
  const description = {
    empty: '判断記録なし。/soloptilink-tenant-dna --mode register で開始してください。',
    starter: '記録蓄積開始。20件超で recall 精度が向上します。',
    healthy: '横断学習に十分なデータ量。distillPatterns で蒸留可能。',
    mature: '成熟したテナントDNA。新規案件への自動注入が高精度で機能します。',
  }[status];

  let top: { sier_id: SierId; project_count: number } | undefined;
  for (const s of index.siers) {
    const projectCount = s.customers.reduce((sum, c) => sum + c.projects.length, 0);
    if (!top || projectCount > top.project_count) {
      top = { sier_id: s.sier_id, project_count: projectCount };
    }
  }

  return { index, health: { status, description }, top_sier: top };
}

/**
 * 特定の Customer / Project に紐づくグラフサブセットを Markdown で出力。
 */
export function formatGraphAsMarkdown(snapshot: GraphSnapshot): string {
  const lines: string[] = [];
  lines.push(`# Tenant DNA Memory Graph`);
  lines.push('');
  lines.push(`**生成日時**: ${snapshot.generated_at}`);
  lines.push(
    `**規模**: SIer ${snapshot.totals.siers} / 顧客 ${snapshot.totals.customers} / プロジェクト ${snapshot.totals.projects} / 判断 ${snapshot.totals.decisions}`
  );
  lines.push('');
  for (const sier of snapshot.nodes.filter((n) => n.level === 'sier')) {
    lines.push(`## SIer: ${sier.label} (${sier.id.replace('sier:', '')})`);
    const customers = snapshot.edges
      .filter((e) => e.from === sier.id && e.kind === 'has_customer')
      .map((e) => snapshot.nodes.find((n) => n.id === e.to))
      .filter((n): n is GraphNode => n !== undefined);
    for (const c of customers) {
      lines.push(`- 顧客: **${c.label}**`);
      const projects = snapshot.edges
        .filter((e) => e.from === c.id && e.kind === 'has_project')
        .map((e) => snapshot.nodes.find((n) => n.id === e.to))
        .filter((n): n is GraphNode => n !== undefined);
      for (const p of projects) {
        const meta = p.meta as { status?: string; outcome?: string };
        lines.push(`  - プロジェクト: ${p.label} (${meta.status ?? '-'}/${meta.outcome ?? '-'})`);
        const decisions = snapshot.edges
          .filter((e) => e.from === p.id && e.kind === 'has_decision')
          .map((e) => snapshot.nodes.find((n) => n.id === e.to))
          .filter((n): n is GraphNode => n !== undefined);
        for (const d of decisions.slice(-5)) {
          const dmeta = d.meta as { category?: string; status?: string };
          lines.push(`    - 判断 [${dmeta.category}/${dmeta.status}]: ${d.label}`);
        }
        if (decisions.length > 5) {
          lines.push(`    - ...他 ${decisions.length - 5} 件`);
        }
      }
    }
    lines.push('');
  }
  return lines.join('\n');
}

/**
 * 顧客にまつわる全マテリアルを一括取得。recall_engine の核として使用。
 */
export function snapshotCustomerMaterials(
  sier_id: SierId,
  tenant_id: string,
  root: string = STORAGE_ROOT
): {
  sier: SierProfile | null;
  customer: CustomerProfile | null;
  decisions: DecisionRecord[];
  naming_rules: ReturnType<typeof readNamingRules>;
  blacklist: ReturnType<typeof readBlacklist>;
  patterns: ReturnType<typeof readPatterns>;
} {
  return {
    sier: getSier(sier_id),
    customer: getCustomer(sier_id, tenant_id),
    decisions: readDecisionsForCustomer(sier_id, tenant_id, root),
    naming_rules: readNamingRules(sier_id, tenant_id, root),
    blacklist: readBlacklist(sier_id, tenant_id, root),
    patterns: readPatterns('sier', sier_id, root),
  };
}

/**
 * インデックスファイルを再構築して返す。CLI から呼ばれる maintenance 操作。
 */
export function rebuildIndex(root: string = STORAGE_ROOT): TenantIndex {
  return writeIndex(root);
}

export interface RecallContext {
  sier_id?: SierId;
  tenant_id?: string;
  project_id?: string;
  hint?: string;
}

/**
 * BOOST から呼ばれる軽量 recall。RecallResult を組み立てる。
 * 詳細実装は recall_engine.ts に分離されている (これは互換用ショートカット)。
 */
export function recallSummary(ctx: RecallContext, root: string = STORAGE_ROOT): RecallResult {
  const warnings: string[] = [];
  const generatedAt = new Date().toISOString();

  if (!ctx.sier_id || !ctx.tenant_id) {
    warnings.push('sier_id / tenant_id が指定されていないため、空の RecallResult を返します。');
    return {
      generated_at: generatedAt,
      tenant_id: ctx.tenant_id,
      project_id: ctx.project_id,
      active_naming_rules: [],
      active_blacklist: [],
      recent_decisions: [],
      related_patterns: [],
      warnings,
    };
  }

  const materials = snapshotCustomerMaterials(ctx.sier_id, ctx.tenant_id, root);
  if (!materials.sier) warnings.push(`SIer プロファイル ${ctx.sier_id} が未登録です。`);
  if (!materials.customer) warnings.push(`顧客プロファイル ${ctx.tenant_id} が未登録です。`);

  return {
    generated_at: generatedAt,
    tenant_id: ctx.tenant_id,
    project_id: ctx.project_id,
    sier_profile: materials.sier ?? undefined,
    customer_profile: materials.customer ?? undefined,
    project_profile:
      ctx.project_id && materials.sier && materials.customer
        ? (getProject(ctx.sier_id, ctx.tenant_id, ctx.project_id) ?? undefined)
        : undefined,
    active_naming_rules: materials.naming_rules.filter((r) => r.enforced),
    active_blacklist: materials.blacklist,
    recent_decisions: materials.decisions
      .filter((d) => d.status === 'active')
      .slice(-10)
      .reverse(),
    related_patterns: materials.patterns.slice(0, 5),
    warnings,
  };
}
