/**
 * Decision Memory - 判断履歴の append-only 記録 / 検索 / supersede 管理 / PII 防衛
 *
 * 責務:
 *  - DecisionRecord を JSONL に append-only で永続化 (削除 API は提供しない)
 *  - supersede / expire は新エントリの追記で表現し、findDecisions は最新エントリを採用
 *  - 入力バリデーション (長さ・必須・PII・シークレットスキャン)
 *  - PII 自動マスキング (メール / 電話 / 郵便番号 / マイナンバー風数列)
 *  - シークレット検出 (sk- / xoxb- / ghp_ / AKIA / DATABASE_URL=...)
 *
 * 入出力:
 *  - 入力: 判断記録の input オブジェクト / フィルタ条件 / 任意テキスト
 *  - 出力: DecisionRecord, 検索結果, バリデーション結果, マスク済みテキスト
 *  - 副作用: storage.ts 経由で decisions.jsonl に追記、プロジェクトプロファイルの decision_count を更新
 */

import type {
  SierId,
  DecisionCategory,
  DecisionRecord,
} from './types';
import {
  STORAGE_ROOT,
  appendDecision,
  readDecisionsForCustomer,
  readDecisionsForProject,
  generateId,
  readProjectProfile,
  writeProjectProfile,
} from './storage';

/* ───── Types (input shapes) ─────────────────────────────────────── */

export interface RecordDecisionInput {
  tenant_id: string;
  project_id?: string;
  sier_id: SierId;
  category: DecisionCategory;
  title: string;
  decision: string;
  rationale: string;
  alternatives_considered?: string[];
  tags?: string[];
  decided_by?: string;
  expires_at?: string;
  related_files?: string[];
  source?: DecisionRecord['source'];
}

export interface DecisionFilter {
  tenant_id?: string;
  project_id?: string;
  sier_id?: SierId;
  category?: DecisionCategory;
  tags?: string[];
  status?: DecisionRecord['status'];
  from_date?: string;
  to_date?: string;
}

export interface DecisionValidation {
  valid: boolean;
  errors: string[];
  warnings?: string[];
}

export interface DecisionSummary {
  total: number;
  by_category: Record<DecisionCategory, number>;
  by_status: Record<string, number>;
  recent: DecisionRecord[];
}

export interface SecretScanResult {
  found: boolean;
  matches: string[];
}

/* ───── Constants ────────────────────────────────────────────────── */

const TITLE_MAX = 200;
const DECISION_MAX = 4000;
const RATIONALE_MAX = 8000;
const RECENT_LIMIT = 10;

const ALL_CATEGORIES: DecisionCategory[] = [
  'stack',
  'naming',
  'library_ban',
  'design_pattern',
  'deployment',
  'api_spec',
  'db_schema',
  'ui_pattern',
  'compliance',
  'handover',
];

/* ───── Public API: record / supersede / expire ───────────────────── */

export function recordDecision(
  input: RecordDecisionInput,
  root: string = STORAGE_ROOT
): DecisionRecord {
  const validation = validateDecisionInput(input);
  if (!validation.valid) {
    throw new Error(`Invalid decision input: ${validation.errors.join('; ')}`);
  }
  const secrets = scanForSecrets([input.title, input.decision, input.rationale].join('\n'));
  if (secrets.found) {
    throw new Error(
      `Secret-like value detected in decision payload (matches: ${secrets.matches.join(', ')}). ` +
        '保存を拒否しました。シークレットを除去して再度記録してください。'
    );
  }

  const now = new Date().toISOString();
  const record: DecisionRecord = {
    decision_id: generateId('dec'),
    tenant_id: input.tenant_id,
    project_id: input.project_id,
    sier_id: input.sier_id,
    category: input.category,
    title: input.title.trim(),
    decision: input.decision.trim(),
    rationale: input.rationale.trim(),
    alternatives_considered: input.alternatives_considered ?? [],
    decided_at: now,
    decided_by: input.decided_by,
    expires_at: input.expires_at,
    status: 'active',
    tags: dedupeTags(input.tags),
    related_files: input.related_files,
    source: input.source ?? 'manual',
  };
  appendDecision(record, root);
  bumpProjectDecisionCount(record, root);
  return record;
}

/**
 * 旧判断を supersede。新規判断を append し、旧 decision_id に対する supersede マーカーを追記。
 * 履歴の改ざんを避けるため、過去エントリを物理的に書き換えず最新エントリを正とする。
 */
export function supersedeDecision(
  decision_id: string,
  new_input: RecordDecisionInput,
  root: string = STORAGE_ROOT
): DecisionRecord {
  const target = findLatestById(decision_id, new_input.sier_id, new_input.tenant_id, root);
  if (!target) {
    throw new Error(`Decision not found for supersede: ${decision_id}`);
  }
  if (target.status === 'superseded') {
    throw new Error(`Decision already superseded: ${decision_id}`);
  }

  // 1) 新しい判断を記録
  const next = recordDecision(new_input, root);

  // 2) 旧判断の supersede マーカー (同 decision_id, status='superseded', superseded_by=next.decision_id)
  const now = new Date().toISOString();
  const supersedeMarker: DecisionRecord = {
    ...target,
    status: 'superseded',
    superseded_by: next.decision_id,
    decided_at: target.decided_at,
    related_files: target.related_files,
    source: target.source,
  };
  // append-only 原則のため、updated_at を rationale 末尾に注釈、メタ情報は status のみ書き換え
  supersedeMarker.rationale = appendAuditNote(target.rationale, `superseded_at=${now}; superseded_by=${next.decision_id}`);
  appendDecision(supersedeMarker, root);

  return next;
}

export function expireDecision(
  decision_id: string,
  options: { sier_id: SierId; tenant_id: string },
  root: string = STORAGE_ROOT
): DecisionRecord {
  const target = findLatestById(decision_id, options.sier_id, options.tenant_id, root);
  if (!target) {
    throw new Error(`Decision not found for expire: ${decision_id}`);
  }
  if (target.status === 'expired' || target.status === 'superseded') {
    throw new Error(`Decision already terminal: ${decision_id} (${target.status})`);
  }
  const now = new Date().toISOString();
  const marker: DecisionRecord = {
    ...target,
    status: 'expired',
    rationale: appendAuditNote(target.rationale, `expired_at=${now}`),
  };
  appendDecision(marker, root);
  return marker;
}

/* ───── Public API: search / summary ─────────────────────────────── */

export function findDecisions(filter: DecisionFilter, root: string = STORAGE_ROOT): DecisionRecord[] {
  const all = collectAllDecisions(filter, root);
  const latest = collapseToLatest(all);

  return latest.filter((rec) => {
    if (filter.tenant_id && rec.tenant_id !== filter.tenant_id) return false;
    if (filter.project_id !== undefined && rec.project_id !== filter.project_id) return false;
    if (filter.sier_id && rec.sier_id !== filter.sier_id) return false;
    if (filter.category && rec.category !== filter.category) return false;
    if (filter.status && rec.status !== filter.status) return false;
    if (filter.tags && filter.tags.length > 0) {
      const tagSet = new Set(rec.tags);
      if (!filter.tags.every((t) => tagSet.has(t))) return false;
    }
    if (filter.from_date && rec.decided_at < filter.from_date) return false;
    if (filter.to_date && rec.decided_at > filter.to_date) return false;
    return true;
  });
}

export function getActiveDecisionsByCategory(
  tenant_id: string,
  sier_id: SierId,
  category: DecisionCategory,
  root: string = STORAGE_ROOT
): DecisionRecord[] {
  return findDecisions({ tenant_id, sier_id, category, status: 'active' }, root);
}

export function summarizeDecisions(
  tenant_id: string,
  sier_id: SierId,
  root: string = STORAGE_ROOT
): DecisionSummary {
  const all = findDecisions({ tenant_id, sier_id }, root);
  const by_category: Record<DecisionCategory, number> = ALL_CATEGORIES.reduce(
    (acc, cat) => {
      acc[cat] = 0;
      return acc;
    },
    {} as Record<DecisionCategory, number>
  );
  const by_status: Record<string, number> = {
    active: 0,
    superseded: 0,
    expired: 0,
    rejected: 0,
  };
  for (const rec of all) {
    by_category[rec.category] = (by_category[rec.category] ?? 0) + 1;
    by_status[rec.status] = (by_status[rec.status] ?? 0) + 1;
  }
  const recent = [...all]
    .sort((a, b) => b.decided_at.localeCompare(a.decided_at))
    .slice(0, RECENT_LIMIT);

  return {
    total: all.length,
    by_category,
    by_status,
    recent,
  };
}

/* ───── Validation / PII / Secret scanning ───────────────────────── */

export function validateDecisionInput(input: RecordDecisionInput): DecisionValidation {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!input.tenant_id || !input.tenant_id.trim()) {
    errors.push('tenant_id is required');
  }
  if (!input.sier_id) {
    errors.push('sier_id is required');
  }
  if (!input.category || !ALL_CATEGORIES.includes(input.category)) {
    errors.push(`category must be one of: ${ALL_CATEGORIES.join(', ')}`);
  }
  if (!input.title || !input.title.trim()) {
    errors.push('title is required');
  } else if (input.title.length > TITLE_MAX) {
    errors.push(`title exceeds ${TITLE_MAX} chars`);
  }
  if (!input.decision || !input.decision.trim()) {
    errors.push('decision is required');
  } else if (input.decision.length > DECISION_MAX) {
    errors.push(`decision exceeds ${DECISION_MAX} chars`);
  }
  if (!input.rationale || !input.rationale.trim()) {
    errors.push('rationale is required');
  } else if (input.rationale.length > RATIONALE_MAX) {
    errors.push(`rationale exceeds ${RATIONALE_MAX} chars`);
  }
  if (input.expires_at && Number.isNaN(Date.parse(input.expires_at))) {
    errors.push('expires_at must be ISO8601');
  }
  if (input.tags) {
    for (const t of input.tags) {
      if (typeof t !== 'string' || !t.trim()) {
        errors.push('tags must be non-empty strings');
        break;
      }
    }
  }

  // PII の警告 (ブロックはしない: 単に警告)
  const corpus = [input.title ?? '', input.decision ?? '', input.rationale ?? ''].join('\n');
  const piiHits = detectPII(corpus);
  if (piiHits.length > 0) {
    warnings.push(`PII detected (${piiHits.join(', ')}). Consider calling maskPII() before recording.`);
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
  };
}

/**
 * テキスト中の PII を検出してマスク。返り値は元のテキストと同じ長さを保つわけではない。
 *  - メール (a***@***.com)
 *  - 電話 (090-****-****)
 *  - 郵便番号 (****-****)
 *  - マイナンバー風12桁
 */
export function maskPII(text: string): string {
  if (!text) return text;
  let out = text;

  // Email: keep first char + domain TLD masked
  out = out.replace(/([A-Za-z0-9._%+-])([A-Za-z0-9._%+-]*)@([A-Za-z0-9.-]+)\.([A-Za-z]{2,})/g, (_m, head: string) => {
    return `${head}***@***.com`;
  });

  // 郵便番号 〒xxx-xxxx or xxx-xxxx (3-4 数字)
  out = out.replace(/〒?\s*\d{3}-\d{4}/g, '****-****');

  // 携帯/固定電話: 090-1234-5678, 03-1234-5678, +81-90-1234-5678
  out = out.replace(/(?:\+81[- ]?)?\d{2,4}-\d{2,4}-\d{4}/g, '***-****-****');

  // マイナンバー (12 連続数字) — 郵便/電話の置換後の "***" は数字を含まないので衝突しない
  out = out.replace(/\b\d{12}\b/g, '************');

  return out;
}

/**
 * シークレットを検出 (検出時はマスクではなく拒否を推奨)。
 *  - OpenAI: sk-...
 *  - Slack: xoxb-... / xoxp-...
 *  - GitHub: ghp_... / gho_... / ghu_... / ghs_... / ghr_...
 *  - AWS: AKIA[A-Z0-9]{16}
 *  - 接続文字列: DATABASE_URL=... / POSTGRES_URL=... / postgresql://user:pass@host
 *  - PEM: -----BEGIN ... PRIVATE KEY-----
 */
export function scanForSecrets(text: string): SecretScanResult {
  if (!text) return { found: false, matches: [] };
  const patterns: Array<{ name: string; re: RegExp }> = [
    { name: 'openai_key', re: /\bsk-[A-Za-z0-9_-]{20,}/g },
    { name: 'slack_token', re: /\bxox[abposr]-[A-Za-z0-9-]{10,}/g },
    { name: 'github_token', re: /\bgh[pousr]_[A-Za-z0-9]{20,}/g },
    { name: 'aws_access_key', re: /\bAKIA[A-Z0-9]{16}\b/g },
    { name: 'env_assignment', re: /\b(?:DATABASE_URL|POSTGRES_URL|MYSQL_URL|MONGO(?:DB)?_URL|REDIS_URL|ANTHROPIC_API_KEY|OPENAI_API_KEY|HMAC_SECRET|JWT_SECRET)\s*=\s*\S+/g },
    { name: 'connection_uri', re: /\b(?:postgres(?:ql)?|mysql|mongodb(?:\+srv)?|redis):\/\/[^:\s/]+:[^@\s]+@/g },
    { name: 'private_key_pem', re: /-----BEGIN[A-Z ]+PRIVATE KEY-----/g },
  ];
  const matches: string[] = [];
  for (const p of patterns) {
    const found = text.match(p.re);
    if (found && found.length > 0) {
      // 正本は出力せずパターン名のみ列挙
      matches.push(p.name);
    }
  }
  return { found: matches.length > 0, matches };
}

/* ───── Helpers ──────────────────────────────────────────────────── */

function detectPII(text: string): string[] {
  const hits: string[] = [];
  if (/[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}/.test(text)) hits.push('email');
  if (/(?:\+81[- ]?)?\d{2,4}-\d{2,4}-\d{4}/.test(text)) hits.push('phone');
  if (/〒?\s*\d{3}-\d{4}/.test(text)) hits.push('postal_code');
  if (/\b\d{12}\b/.test(text)) hits.push('my_number_like');
  return hits;
}

function dedupeTags(tags?: string[]): string[] {
  if (!tags) return [];
  const seen = new Set<string>();
  const out: string[] = [];
  for (const t of tags) {
    const v = t.trim();
    if (!v) continue;
    if (seen.has(v)) continue;
    seen.add(v);
    out.push(v);
  }
  return out;
}

function appendAuditNote(rationale: string, note: string): string {
  const sep = rationale && rationale.endsWith('\n') ? '' : '\n';
  return `${rationale}${sep}[audit] ${note}`;
}

function bumpProjectDecisionCount(record: DecisionRecord, root: string): void {
  if (!record.project_id) return;
  const proj = readProjectProfile(record.sier_id, record.tenant_id, record.project_id, root);
  if (!proj) return;
  writeProjectProfile(
    {
      ...proj,
      meta: {
        ...proj.meta,
        decision_count: proj.meta.decision_count + 1,
        last_updated: new Date().toISOString(),
      },
    },
    root
  );
}

/**
 * フィルタ初期段階で読み込み範囲を最小化するための内部ヘルパ。
 * project_id 指定なら project スコープのみ、tenant_id 指定なら customer スコープ全件、それ以外は適切に combined。
 */
function collectAllDecisions(filter: DecisionFilter, root: string): DecisionRecord[] {
  if (filter.tenant_id && filter.sier_id) {
    if (filter.project_id) {
      return readDecisionsForProject(filter.sier_id, filter.tenant_id, filter.project_id, root);
    }
    return readDecisionsForCustomer(filter.sier_id, filter.tenant_id, root);
  }
  // 不完全なフィルタの場合は安全側に倒す: 何も返さない
  // (storage.ts は customer/project スコープでしか read API を提供していないため)
  return [];
}

/**
 * append-only ストアから「最新の状態」を抽出する。
 *  - 同一 decision_id の複数エントリは、最後に追記されたものを採用。
 *  - 順序が保たれる前提 (storage.ts は append のみ)。
 */
function collapseToLatest(records: DecisionRecord[]): DecisionRecord[] {
  const map = new Map<string, DecisionRecord>();
  for (const rec of records) {
    map.set(rec.decision_id, rec);
  }
  return Array.from(map.values());
}

function findLatestById(
  decision_id: string,
  sier_id: SierId,
  tenant_id: string,
  root: string
): DecisionRecord | null {
  const all = readDecisionsForCustomer(sier_id, tenant_id, root);
  let latest: DecisionRecord | null = null;
  for (const rec of all) {
    if (rec.decision_id === decision_id) latest = rec;
  }
  return latest;
}

/*
 * Module summary - exported functions:
 *  - recordDecision / supersedeDecision / expireDecision
 *  - findDecisions / getActiveDecisionsByCategory / summarizeDecisions
 *  - validateDecisionInput / maskPII / scanForSecrets
 *  Append-only invariant: never overwrites past records; supersede/expire are new appends.
 */
