/**
 * Tenant DNA Types - 4階層メモリモデルの型定義
 *
 * 階層: SIer → Customer → Project → Decision
 * すべてのモジュールから参照される基本型
 */

export type SierId =
  | 'nttdata'
  | 'fujitsu'
  | 'nri'
  | 'nomura'
  | 'nec'
  | 'hitachi'
  | 'tis'
  | 'generic';

export type DecisionCategory =
  | 'stack'
  | 'naming'
  | 'library_ban'
  | 'design_pattern'
  | 'deployment'
  | 'api_spec'
  | 'db_schema'
  | 'ui_pattern'
  | 'compliance'
  | 'handover';

export type NamingCase = 'snake_case' | 'camelCase' | 'PascalCase' | 'kebab-case' | 'UPPER_SNAKE' | 'mixed';

export interface SierProfile {
  sier_id: SierId;
  display_name: string;
  display_name_ja: string;
  default_naming: {
    db_table: NamingCase;
    db_column: NamingCase;
    typescript_var: NamingCase;
    api_path: NamingCase;
    table_prefix?: string;
    master_table_prefix?: string;
  };
  preferred_libraries: string[];
  banned_libraries: string[];
  preferred_architecture: string[];
  preferred_deployment: string[];
  notes_ja: string;
  meta: {
    is_builtin: boolean;
    created_at: string;
    last_updated: string;
    project_count: number;
  };
}

export interface CustomerProfile {
  tenant_id: string;
  sier_id: SierId;
  display_name: string;
  display_name_ja?: string;
  domain?: string;
  industry?: string;
  industry_ja?: string;
  size?: 'small' | 'medium' | 'large' | 'enterprise';
  active_projects: string[];
  archived_projects: string[];
  contact_info: {
    primary_contact_role?: string;
    decision_speed?: 'fast' | 'normal' | 'slow';
    review_strictness?: 'lenient' | 'normal' | 'strict';
  };
  meta: {
    created_at: string;
    last_updated: string;
    interaction_count: number;
  };
}

export interface ProjectProfile {
  project_id: string;
  tenant_id: string;
  sier_id: SierId;
  display_name: string;
  description: string;
  industry?: string;
  status: 'planning' | 'requirements' | 'design' | 'implementation' | 'testing' | 'deployed' | 'maintenance' | 'archived';
  start_date: string;
  end_date?: string;
  tech_stack: {
    frontend?: string[];
    backend?: string[];
    database?: string[];
    infrastructure?: string[];
    cicd?: string[];
  };
  applicable_laws?: string[];
  outcome?: 'success' | 'partial' | 'failed' | 'in_progress';
  outcome_notes?: string;
  meta: {
    created_at: string;
    last_updated: string;
    decision_count: number;
  };
}

export interface DecisionRecord {
  decision_id: string;
  tenant_id: string;
  project_id?: string;
  sier_id: SierId;
  category: DecisionCategory;
  title: string;
  decision: string;
  rationale: string;
  alternatives_considered?: string[];
  decided_at: string;
  decided_by?: string;
  expires_at?: string;
  status: 'active' | 'superseded' | 'expired' | 'rejected';
  superseded_by?: string;
  tags: string[];
  related_files?: string[];
  source: 'manual' | 'auto_sync' | 'inferred' | 'imported';
}

export interface NamingRule {
  tenant_id: string;
  rule_id: string;
  scope: 'db_table' | 'db_column' | 'typescript_var' | 'typescript_type' | 'api_path' | 'route' | 'component' | 'file';
  case_style: NamingCase;
  prefix?: string;
  suffix?: string;
  forbidden_patterns?: string[];
  example_good?: string[];
  example_bad?: string[];
  rationale: string;
  enforced: boolean;
  source_decision_id?: string;
}

export interface LibraryBlacklistEntry {
  tenant_id: string;
  library_name: string;
  language: 'typescript' | 'javascript' | 'python' | 'java' | 'go' | 'rust' | 'any';
  reason: string;
  alternative_recommendation?: string;
  banned_at: string;
  banned_until?: string;
  scope: 'all_projects' | 'production_only' | 'specific_projects';
  related_project_ids?: string[];
  source_decision_id?: string;
}

export interface CrossProjectPattern {
  pattern_id: string;
  scope: 'sier' | 'customer' | 'global';
  scope_id: string;
  category: DecisionCategory;
  pattern_summary: string;
  occurrence_count: number;
  success_rate: number;
  example_project_ids: string[];
  recommendation_text: string;
  distilled_at: string;
}

export interface TenantIndex {
  schema_version: string;
  generated_at: string;
  siers: SierIndexEntry[];
  total_customers: number;
  total_projects: number;
  total_decisions: number;
}

export interface SierIndexEntry {
  sier_id: SierId;
  display_name: string;
  customers: CustomerIndexEntry[];
  decision_count: number;
}

export interface CustomerIndexEntry {
  tenant_id: string;
  display_name: string;
  industry?: string;
  projects: ProjectIndexEntry[];
  decision_count: number;
  last_active: string;
}

export interface ProjectIndexEntry {
  project_id: string;
  display_name: string;
  status: ProjectProfile['status'];
  decision_count: number;
  last_active: string;
}

export interface RecallResult {
  generated_at: string;
  tenant_id?: string;
  project_id?: string;
  sier_profile?: SierProfile;
  customer_profile?: CustomerProfile;
  project_profile?: ProjectProfile;
  active_naming_rules: NamingRule[];
  active_blacklist: LibraryBlacklistEntry[];
  recent_decisions: DecisionRecord[];
  related_patterns: CrossProjectPattern[];
  recommended_stack?: string[];
  warnings: string[];
}

export interface RecommendResult {
  generated_at: string;
  scope: 'sier' | 'customer' | 'global';
  scope_id: string;
  recommended_decisions: Array<{
    category: DecisionCategory;
    recommendation: string;
    rationale: string;
    confidence: number;
    source_pattern_id?: string;
  }>;
  alternatives: Array<{
    category: DecisionCategory;
    options: string[];
    pros_cons?: Record<string, { pros: string[]; cons: string[] }>;
  }>;
}

export interface SyncResult {
  source_path: string;
  detected_sier?: SierId;
  detected_tenant?: string;
  detected_project?: string;
  extracted_naming: NamingRule[];
  extracted_libraries: { adopted: string[]; banned: string[] };
  extracted_decisions: DecisionRecord[];
  warnings: string[];
}

export interface ExportEnvelope {
  schema_version: string;
  exported_at: string;
  exporter: string;
  scope: 'sier' | 'customer' | 'project' | 'all';
  scope_ids: string[];
  encrypted: boolean;
  payload: unknown;
  signature?: string;
}
