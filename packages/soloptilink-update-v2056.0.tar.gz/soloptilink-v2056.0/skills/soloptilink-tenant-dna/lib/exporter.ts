/**
 * Exporter / Importer - Tenant DNA を端末・社員間で持ち運ぶための JSON 形式 envelope
 *
 * 入出力: ローカル JSONL → ExportEnvelope (JSON) → ローカル JSONL
 * セキュリティ: 平文エクスポート (パスフレーズ暗号化は将来拡張)
 *               PII / シークレットは事前にマスキング (decision_memory.maskPII / scanForSecrets を呼ぶ想定)
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import * as crypto from 'node:crypto';
import type {
  SierId,
  ExportEnvelope,
  SierProfile,
  CustomerProfile,
  ProjectProfile,
  DecisionRecord,
  NamingRule,
  LibraryBlacklistEntry,
  CrossProjectPattern,
} from './types';
import {
  STORAGE_ROOT,
  SCHEMA_VERSION,
  customerDir,
  projectDir,
  sierDir,
  readSierProfile,
  readCustomerProfile,
  readProjectProfile,
  readDecisionsForCustomer,
  readDecisionsForProject,
  readNamingRules,
  readBlacklist,
  readPatterns,
  appendDecision,
  writeNamingRules,
  writeBlacklist,
  writeSierProfile,
  writeCustomerProfile,
  writeProjectProfile,
} from './storage';

export interface ExportPayload {
  sier_profiles: SierProfile[];
  customer_profiles: CustomerProfile[];
  project_profiles: ProjectProfile[];
  decisions: DecisionRecord[];
  naming_rules: NamingRule[];
  blacklist: LibraryBlacklistEntry[];
  patterns: CrossProjectPattern[];
}

export interface ExportOptions {
  scope: 'sier' | 'customer' | 'project' | 'all';
  sier_id?: SierId;
  tenant_id?: string;
  project_id?: string;
  exporter?: string;
  output_path: string;
}

export interface ImportOptions {
  source_path: string;
  overwrite_profiles?: boolean;
  dedupe_decisions?: boolean;
}

export interface ImportSummary {
  imported_at: string;
  source_path: string;
  counts: {
    sier_profiles: number;
    customer_profiles: number;
    project_profiles: number;
    decisions: number;
    naming_rules: number;
    blacklist: number;
    patterns: number;
  };
  warnings: string[];
}

export function exportTenantDna(opts: ExportOptions, root: string = STORAGE_ROOT): ExportEnvelope {
  const payload = collectPayload(opts, root);
  const envelope: ExportEnvelope = {
    schema_version: SCHEMA_VERSION,
    exported_at: new Date().toISOString(),
    exporter: opts.exporter ?? `soloptilink-tenant-dna@${SCHEMA_VERSION}`,
    scope: opts.scope,
    scope_ids: collectScopeIds(opts),
    encrypted: false,
    payload,
    signature: signPayload(payload),
  };
  ensureParentDir(opts.output_path);
  fs.writeFileSync(opts.output_path, JSON.stringify(envelope, null, 2), 'utf-8');
  return envelope;
}

export function importTenantDna(opts: ImportOptions, root: string = STORAGE_ROOT): ImportSummary {
  const text = fs.readFileSync(opts.source_path, 'utf-8');
  const envelope = JSON.parse(text) as ExportEnvelope;
  const warnings: string[] = [];

  if (envelope.schema_version !== SCHEMA_VERSION) {
    warnings.push(
      `Schema version mismatch (envelope=${envelope.schema_version}, current=${SCHEMA_VERSION}). 互換性に注意してください。`
    );
  }
  if (envelope.signature) {
    const recomputed = signPayload(envelope.payload as ExportPayload);
    if (recomputed !== envelope.signature) {
      warnings.push('署名検証に失敗しました。エクスポート後に内容が改変された可能性があります。');
    }
  }

  const payload = envelope.payload as ExportPayload;
  const counts = {
    sier_profiles: 0,
    customer_profiles: 0,
    project_profiles: 0,
    decisions: 0,
    naming_rules: 0,
    blacklist: 0,
    patterns: 0,
  };

  for (const sp of payload.sier_profiles ?? []) {
    if (opts.overwrite_profiles || !readSierProfile(sp.sier_id, root)) {
      writeSierProfile(sp, root);
      counts.sier_profiles++;
    } else {
      warnings.push(`SIer profile ${sp.sier_id} は既存のため上書きしませんでした。`);
    }
  }
  for (const cp of payload.customer_profiles ?? []) {
    if (opts.overwrite_profiles || !readCustomerProfile(cp.sier_id, cp.tenant_id, root)) {
      writeCustomerProfile(cp, root);
      counts.customer_profiles++;
    } else {
      warnings.push(`顧客プロファイル ${cp.tenant_id} は既存のため上書きしませんでした。`);
    }
  }
  for (const pp of payload.project_profiles ?? []) {
    if (opts.overwrite_profiles || !readProjectProfile(pp.sier_id, pp.tenant_id, pp.project_id, root)) {
      writeProjectProfile(pp, root);
      counts.project_profiles++;
    } else {
      warnings.push(`プロジェクト ${pp.project_id} は既存のため上書きしませんでした。`);
    }
  }

  // Decisions are append-only; dedupe by decision_id when requested
  const seen = new Set<string>();
  if (opts.dedupe_decisions) {
    for (const d of (payload.decisions ?? [])) seen.add(d.decision_id);
  }
  for (const d of payload.decisions ?? []) {
    if (opts.dedupe_decisions) {
      const existing = readDecisionsForCustomer(d.sier_id, d.tenant_id, root);
      if (existing.some((e) => e.decision_id === d.decision_id)) continue;
    }
    appendDecision(d, root);
    counts.decisions++;
  }

  // Naming rules / blacklist: replace per-customer when present
  const namingByCustomer = new Map<string, NamingRule[]>();
  for (const r of payload.naming_rules ?? []) {
    const key = `${r.tenant_id}`;
    if (!namingByCustomer.has(key)) namingByCustomer.set(key, []);
    namingByCustomer.get(key)!.push(r);
  }
  for (const [tenant_id, rules] of namingByCustomer.entries()) {
    const sample = rules[0];
    const cp = payload.customer_profiles?.find((c) => c.tenant_id === tenant_id);
    if (cp) {
      writeNamingRules(cp.sier_id, tenant_id, rules, root);
      counts.naming_rules += rules.length;
    } else {
      warnings.push(`命名規則 ${rules.length}件 は所属顧客が見つからないため無視しました (tenant=${sample.tenant_id})。`);
    }
  }

  const blacklistByCustomer = new Map<string, LibraryBlacklistEntry[]>();
  for (const b of payload.blacklist ?? []) {
    const key = b.tenant_id;
    if (!blacklistByCustomer.has(key)) blacklistByCustomer.set(key, []);
    blacklistByCustomer.get(key)!.push(b);
  }
  for (const [tenant_id, entries] of blacklistByCustomer.entries()) {
    const cp = payload.customer_profiles?.find((c) => c.tenant_id === tenant_id);
    if (cp) {
      writeBlacklist(cp.sier_id, tenant_id, entries, root);
      counts.blacklist += entries.length;
    } else {
      warnings.push(
        `ブラックリスト ${entries.length}件 は所属顧客が見つからないため無視しました (tenant=${tenant_id})。`
      );
    }
  }

  // Patterns are written as global supplementary (storage.appendPattern would be ideal, here we fall back to file write)
  if ((payload.patterns ?? []).length > 0) {
    const file = path.join(root, '_imported_patterns.jsonl');
    const ws = fs.createWriteStream(file, { flags: 'a' });
    for (const p of payload.patterns ?? []) {
      ws.write(JSON.stringify(p) + '\n');
      counts.patterns++;
    }
    ws.end();
  }

  return {
    imported_at: new Date().toISOString(),
    source_path: opts.source_path,
    counts,
    warnings,
  };
}

function collectPayload(opts: ExportOptions, root: string): ExportPayload {
  const payload: ExportPayload = {
    sier_profiles: [],
    customer_profiles: [],
    project_profiles: [],
    decisions: [],
    naming_rules: [],
    blacklist: [],
    patterns: [],
  };

  const collectSier = (sier_id: SierId): void => {
    const sp = readSierProfile(sier_id, root);
    if (sp) payload.sier_profiles.push(sp);
    payload.patterns.push(...readPatterns('sier', sier_id, root));
  };

  const collectCustomer = (sier_id: SierId, tenant_id: string): void => {
    const cp = readCustomerProfile(sier_id, tenant_id, root);
    if (!cp) return;
    payload.customer_profiles.push(cp);
    payload.naming_rules.push(...readNamingRules(sier_id, tenant_id, root));
    payload.blacklist.push(...readBlacklist(sier_id, tenant_id, root));
    payload.decisions.push(...readDecisionsForCustomer(sier_id, tenant_id, root));
    const projectsBase = path.join(customerDir(sier_id, tenant_id, root), 'projects');
    if (fs.existsSync(projectsBase)) {
      for (const dirent of fs.readdirSync(projectsBase, { withFileTypes: true })) {
        if (!dirent.isDirectory()) continue;
        const pp = readProjectProfile(sier_id, tenant_id, dirent.name, root);
        if (pp) payload.project_profiles.push(pp);
      }
    }
  };

  const collectProject = (sier_id: SierId, tenant_id: string, project_id: string): void => {
    const pp = readProjectProfile(sier_id, tenant_id, project_id, root);
    if (pp) payload.project_profiles.push(pp);
    payload.decisions.push(...readDecisionsForProject(sier_id, tenant_id, project_id, root));
  };

  switch (opts.scope) {
    case 'sier': {
      if (!opts.sier_id) throw new Error('scope=sier には sier_id が必須です');
      collectSier(opts.sier_id);
      const customersDir = path.join(sierDir(opts.sier_id, root), 'customers');
      if (fs.existsSync(customersDir)) {
        for (const dirent of fs.readdirSync(customersDir, { withFileTypes: true })) {
          if (!dirent.isDirectory()) continue;
          collectCustomer(opts.sier_id, dirent.name);
        }
      }
      break;
    }
    case 'customer': {
      if (!opts.sier_id || !opts.tenant_id) throw new Error('scope=customer には sier_id / tenant_id が必須です');
      collectSier(opts.sier_id);
      collectCustomer(opts.sier_id, opts.tenant_id);
      break;
    }
    case 'project': {
      if (!opts.sier_id || !opts.tenant_id || !opts.project_id) {
        throw new Error('scope=project には sier_id / tenant_id / project_id が必須です');
      }
      collectSier(opts.sier_id);
      collectCustomer(opts.sier_id, opts.tenant_id);
      collectProject(opts.sier_id, opts.tenant_id, opts.project_id);
      break;
    }
    case 'all': {
      for (const dirent of fs.readdirSync(root, { withFileTypes: true })) {
        if (!dirent.isDirectory() || dirent.name.startsWith('_')) continue;
        const sier_id = dirent.name as SierId;
        collectSier(sier_id);
        const customersDir = path.join(sierDir(sier_id, root), 'customers');
        if (!fs.existsSync(customersDir)) continue;
        for (const c of fs.readdirSync(customersDir, { withFileTypes: true })) {
          if (!c.isDirectory()) continue;
          collectCustomer(sier_id, c.name);
        }
      }
      break;
    }
  }

  return payload;
}

function collectScopeIds(opts: ExportOptions): string[] {
  const ids: string[] = [];
  if (opts.sier_id) ids.push(`sier:${opts.sier_id}`);
  if (opts.tenant_id) ids.push(`tenant:${opts.tenant_id}`);
  if (opts.project_id) ids.push(`project:${opts.project_id}`);
  return ids;
}

function signPayload(payload: ExportPayload): string {
  const hash = crypto.createHash('sha256');
  hash.update(JSON.stringify(payload));
  return hash.digest('hex');
}

function ensureParentDir(file: string): void {
  const parent = path.dirname(file);
  if (!fs.existsSync(parent)) fs.mkdirSync(parent, { recursive: true });
}
