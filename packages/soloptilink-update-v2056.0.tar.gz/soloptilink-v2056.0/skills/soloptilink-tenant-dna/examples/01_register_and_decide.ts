/**
 * 例題1: 新規 SIer / Customer / Project 登録 + 判断記録 + recall
 *
 * 実行: bun run examples/01_register_and_decide.ts
 *       node --import tsx examples/01_register_and_decide.ts
 */

import {
  registerSier,
  registerCustomer,
  registerProject,
  recordDecision,
  recallForBoost,
  banLibrary,
  defineNamingRule,
  summarizeMemory,
} from '../lib/index';

const TEST_ROOT = process.env.SOLOPTILINK_TENANT_DNA_ROOT;
console.log(`Storage root: ${TEST_ROOT ?? '(default ~/.soloptilink/learning/tenants)'}`);

// 1. SIer登録 (builtin プロファイルが自動適用される)
const sier = registerSier({
  sier_id: 'nttdata',
  display_name: 'NTT Data Corporation',
  display_name_ja: 'NTTデータ',
});
console.log(`SIer registered: ${sier.display_name_ja} (project_count=${sier.meta.project_count})`);

// 2. 顧客登録
const customer = registerCustomer({
  sier_id: 'nttdata',
  tenant_id: 'sample-construction',
  display_name: '株式会社サンプル建設',
  display_name_ja: 'サンプル建設',
  industry: 'construction',
  industry_ja: '建設業',
  size: 'medium',
});
console.log(`Customer registered: ${customer.display_name}`);

// 3. プロジェクト登録
const project = registerProject({
  project_id: 'kosei-2026',
  tenant_id: 'sample-construction',
  sier_id: 'nttdata',
  display_name: '工事原価管理システム 2026年版',
  description: '工事日報・出来高・粗利率の一元管理',
  industry: 'construction',
  status: 'requirements',
  start_date: '2026-04-01',
  tech_stack: {
    frontend: ['Next.js 15', 'React 19', 'Tailwind v4'],
    backend: ['Node.js 22', 'Prisma 5'],
    database: ['PostgreSQL 16'],
  },
});
console.log(`Project registered: ${project.display_name}`);

// 4. 判断記録 (技術スタック)
const stackDecision = recordDecision({
  tenant_id: 'sample-construction',
  project_id: 'kosei-2026',
  sier_id: 'nttdata',
  category: 'stack',
  title: 'Next.js 15 + Prisma + Postgres 採用',
  decision: 'Next.js 15 / React 19 / Tailwind v4 / Prisma 5 / PostgreSQL 16',
  rationale: '客先がモバイル対応必須・SSR/SSG対応・運用実績重視のため',
  alternatives_considered: ['Rails + Vue', 'Spring Boot + React'],
  tags: ['frontend', 'fullstack'],
});
console.log(`Decision recorded: ${stackDecision.title}`);

// 5. ライブラリ採用禁止
const banResult = banLibrary({
  tenant_id: 'sample-construction',
  library_name: 'mongodb',
  language: 'typescript',
  reason: '客先のDBA体制がPostgreSQLに統一されているため、運用コスト増を回避',
  alternative_recommendation: 'PostgreSQL + JSONB',
  scope: 'all_projects',
}, 'nttdata');
console.log(`Library banned: ${banResult.library_name}`);

// 6. 命名規則定義
const namingRule = defineNamingRule({
  tenant_id: 'sample-construction',
  scope: 'db_table',
  case_style: 'snake_case',
  prefix: 't_',
  rationale: 'NTTデータ標準 + 客先DBAルール',
  enforced: true,
  example_good: ['t_project', 't_invoice', 't_daily_report'],
  example_bad: ['Project', 'invoiceTbl', 'TBL_INVOICE'],
});
console.log(`Naming rule defined: ${namingRule.scope} = ${namingRule.case_style} (prefix: ${namingRule.prefix})`);

// 7. recallForBoost で BOOST 用の推論サマリー素材を取得
const recall = recallForBoost({
  sier_id: 'nttdata',
  tenant_id: 'sample-construction',
  project_id: 'kosei-2026',
  workspace_dir: process.cwd(),
});
console.log('\n===== Tenant DNA Recall Block (BOOST に注入) =====');
console.log(recall.inference_block_markdown);
console.log('\n===== Agent Injections =====');
recall.injection_lines_for_agents.forEach((line, i) => console.log(`${i + 1}. ${line}`));

// 8. メモリサマリ
const summary = summarizeMemory();
console.log('\n===== Memory Health =====');
console.log(`Status: ${summary.health.status} — ${summary.health.description}`);
console.log(`Total: SIer=${summary.index.siers.length} / Customer=${summary.index.total_customers} / Project=${summary.index.total_projects} / Decision=${summary.index.total_decisions}`);
