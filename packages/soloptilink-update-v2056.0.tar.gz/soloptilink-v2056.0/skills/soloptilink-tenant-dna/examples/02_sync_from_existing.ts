/**
 * 例題2: 既存プロジェクトディレクトリから DNA を逆抽出
 *
 * 実行: node --import tsx examples/02_sync_from_existing.ts <project_dir>
 */

import { syncFromProject } from '../lib/index';

const target = process.argv[2] ?? process.cwd();
console.log(`Scanning: ${target}`);

const result = syncFromProject({
  source_path: target,
  scan_source_lines: true,
});

console.log('\n===== Sync Result =====');
console.log(`Detected SIer: ${result.detected_sier ?? '(none)'}`);
console.log(`Detected Tenant: ${result.detected_tenant ?? '(none)'}`);
console.log(`Detected Project: ${result.detected_project ?? '(none)'}`);
console.log(`Adopted libraries: ${result.extracted_libraries.adopted.length} 件`);
console.log(`Banned libraries: ${result.extracted_libraries.banned.length} 件`);
console.log(`Naming rules inferred: ${result.extracted_naming.length} 件`);
console.log(`Decisions auto-recorded: ${result.extracted_decisions.length} 件`);

if (result.extracted_naming.length > 0) {
  console.log('\n===== Naming Rules =====');
  for (const r of result.extracted_naming) {
    console.log(`- ${r.scope}: ${r.case_style}${r.prefix ? ` (prefix=${r.prefix})` : ''} — ${r.rationale}`);
  }
}

if (result.extracted_decisions.length > 0) {
  console.log('\n===== Decisions =====');
  for (const d of result.extracted_decisions) {
    console.log(`- [${d.category}] ${d.title}: ${d.decision}`);
  }
}

if (result.warnings.length > 0) {
  console.log('\n===== Warnings =====');
  for (const w of result.warnings) console.log(`! ${w}`);
}
