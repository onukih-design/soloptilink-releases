/**
 * 例題3: DNA エクスポート → 別パスにインポート (端末間移動シミュレーション)
 *
 * 実行: node --import tsx examples/03_export_import.ts
 */

import * as os from 'node:os';
import * as path from 'node:path';
import * as fs from 'node:fs';
import {
  exportTenantDna,
  importTenantDna,
  registerSier,
  registerCustomer,
  registerProject,
  recordDecision,
  buildIndex,
} from '../lib/index';

const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'tenant-dna-'));
const sourceRoot = path.join(tmp, 'source');
const targetRoot = path.join(tmp, 'target');
fs.mkdirSync(sourceRoot, { recursive: true });
fs.mkdirSync(targetRoot, { recursive: true });

process.env.SOLOPTILINK_TENANT_DNA_ROOT = sourceRoot;

registerSier({ sier_id: 'fujitsu', display_name: 'Fujitsu Limited', display_name_ja: '富士通' });
registerCustomer({
  sier_id: 'fujitsu',
  tenant_id: 'finance-bank',
  display_name: '金融銀行株式会社',
  industry: 'finance',
  industry_ja: '金融',
});
registerProject({
  project_id: 'core-banking-2026',
  tenant_id: 'finance-bank',
  sier_id: 'fujitsu',
  display_name: 'コアバンキング刷新',
  description: '勘定系システム刷新',
  start_date: '2026-04-01',
  status: 'design',
});
recordDecision({
  tenant_id: 'finance-bank',
  project_id: 'core-banking-2026',
  sier_id: 'fujitsu',
  category: 'compliance',
  title: 'FISC安全対策基準準拠',
  decision: 'FISC 安全対策基準 + J-CSIP 監視',
  rationale: '金融庁監督指針への対応必須',
});

const exportPath = path.join(tmp, 'tenant-dna-export.json');
exportTenantDna(
  {
    scope: 'sier',
    sier_id: 'fujitsu',
    output_path: exportPath,
    exporter: 'example-script',
  },
  sourceRoot
);
console.log(`Exported to: ${exportPath}`);
console.log(`File size: ${fs.statSync(exportPath).size} bytes`);

const summary = importTenantDna({ source_path: exportPath, overwrite_profiles: true }, targetRoot);
console.log('\n===== Import Summary =====');
console.log(JSON.stringify(summary.counts, null, 2));
if (summary.warnings.length > 0) {
  console.log('Warnings:');
  for (const w of summary.warnings) console.log(`! ${w}`);
}

const targetIndex = buildIndex(targetRoot);
console.log('\n===== Target Side Index =====');
console.log(`SIer: ${targetIndex.siers.length}`);
console.log(`Customer: ${targetIndex.total_customers}`);
console.log(`Project: ${targetIndex.total_projects}`);
console.log(`Decision: ${targetIndex.total_decisions}`);
console.log('\n移動完了。tmp ディレクトリ:', tmp);
