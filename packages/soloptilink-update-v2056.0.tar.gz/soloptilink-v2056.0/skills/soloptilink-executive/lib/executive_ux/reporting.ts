/**
 * SoloptiLinkAI v2033.0 — Executive Reporting Style
 * Phase 45 Executive Cognitive Layer
 *
 * Pyramid Principle / SCQA / 1ページレポート / Amazon 6-Page Memo / 経営者向けアンチパターン
 */

export interface PyramidStructure {
  bottomLineUpFront: string; // BLUF: 50字以内
  supportingPoints: [string, string, string]; // 3点で支える (MECE)
  evidenceTree: { point: string; evidence: string[] }[];
}

export interface SCQAStructure {
  situation: string;
  complication: string;
  question: string;
  answer: string;
}

/**
 * 5つのダメ報告アンチパターン
 */
export const ANTI_PATTERNS = {
  LONG_WINDED: {
    name: '冗長 (Long-Winded)',
    badExample:
      '今月の売上については、様々な要因が絡み合いまして、前月との比較において、確認したところ、おおむね計画通り推移しておりまして、ただし若干の懸念材料も散見され...',
    goodExample: '今月売上1.8億、計画比+8%。新製品Xが牽引。ただし原料高で粗利率1.2pt低下、来月価格転嫁実施。',
    rule: '一文40字以内 / 受動態より能動態 / 主語と述語の距離を短く',
  },
  JARGON_HEAVY: {
    name: '専門用語連発 (Jargon Heavy)',
    badExample: 'ARPUのKPIモニタリングにおいて、コホート分析のNRRがベンチマーク値を下回り、CACペイバック期間が伸長',
    goodExample: '顧客平均単価が下落傾向。同時期に獲得した顧客の継続率が業界平均を下回り、獲得コスト回収が遅れています',
    rule: '専門用語は初出時に必ず日本語の説明を併記',
  },
  BURYING_THE_LEDE: {
    name: '結論不明 (Burying the Lede)',
    badExample: '[1p] 業界動向...[2p] 競合分析...[3p] 自社の状況...[4p] そして実は重大事案が発生',
    goodExample: '[1p] 結論: A社解約決定。年間1.2億の影響。対策3つ提示',
    rule: '1ページ目に結論+根拠3点。経緯・背景は2ページ目以降',
  },
  DETACHED: {
    name: '他人事 (Detached)',
    badExample: '営業部が目標未達となっており、現場の努力不足が見られ...',
    goodExample: '私の戦略判断ミスで営業目標が未達。X社向け優先順位を誤った。来月は私自身がトップ営業に同行する',
    rule: '主語を「自分」で書く。組織を擬人化しない',
  },
  COVERING_UP: {
    name: '隠蔽 (Covering Up)',
    badExample: '特に大きな問題はなく、順調に推移しております (実は解約予兆や原価異常を伏せている)',
    goodExample: '悪い知らせから先にお伝えします。A社が解約意向。ただし対策3点を実行中で、来週方向性が見えます',
    rule: '悪い知らせは先出し。良い→悪いの順は不信を生む',
  },
};

/**
 * 経営者報告 7秒チェック
 */
export const SEVEN_SECOND_CHECKS = [
  'タイトルで結論が分かるか? (「Q1業績報告」ではダメ。「Q1売上3億 計画達成、ただし粗利率1.2pt悪化」)',
  '冒頭3行で全体像が分かるか? (結論+根拠+対策)',
  '数字に根拠と単位があるか? (「売上10%増」ではなく「売上+2,000万(+11%)」)',
  '次のアクションが明示されているか? (誰が・何を・いつまでに)',
  '悪い知らせを先に書いたか?',
  '反証データを並べたか? (確証バイアス対策)',
  '業界ベンチマーク比較が含まれているか? (アンカー単一回避)',
];

/**
 * 1ページレポートテンプレ (アイゼンハワー流)
 */
export function generateOnePageReport(input: {
  date: string;
  reporter: string;
  recipient: string;
  subject: string;
  bottomLine: string; // 50字以内
  supportingPoints: [string, string, string];
  actions: [string, string, string];
  decisionRequired?: string;
  risksAndMitigation?: string;
}): string {
  return `# ${input.subject}
日付: ${input.date} / 報告者: ${input.reporter} / 宛先: ${input.recipient}

## 結論 (Bottom Line)
${input.bottomLine}

## 根拠 (3点)
1. ${input.supportingPoints[0]}
2. ${input.supportingPoints[1]}
3. ${input.supportingPoints[2]}

## 対策 (3点)
1. ${input.actions[0]}
2. ${input.actions[1]}
3. ${input.actions[2]}

${input.decisionRequired ? `## 決議事項\n${input.decisionRequired}\n` : ''}
${input.risksAndMitigation ? `## リスクと対応\n${input.risksAndMitigation}\n` : ''}
`;
}

/**
 * SCQA構造でストーリーを構築
 */
export function buildSCQA(s: SCQAStructure): string {
  return `## ${s.question}

**状況 (S)**: ${s.situation}
**複雑化 (C)**: ${s.complication}
**問い (Q)**: ${s.question}
**答え (A)**: ${s.answer}
`;
}

/**
 * Pyramid Principle 構造でレポート構築
 */
export function buildPyramid(p: PyramidStructure): string {
  const supportText = p.supportingPoints.map((pt, i) => `${i + 1}. ${pt}`).join('\n');
  const evidence = p.evidenceTree
    .map((e) => `\n### ${e.point}\n${e.evidence.map((ev) => `- ${ev}`).join('\n')}`)
    .join('');
  return `# 結論
${p.bottomLineUpFront}

## 根拠
${supportText}
${evidence}
`;
}

/**
 * Amazon 6-Page Memo 構造
 */
export interface SixPageMemo {
  title: string;
  intro: string; // Situation + Complication
  question: string;
  proposal: string;
  data: string;
  faq: { q: string; a: string }[];
  appendix: string;
}

export function buildSixPageMemo(m: SixPageMemo): string {
  return `# ${m.title}

## 1. Situation & Complication
${m.intro}

## 2. Question
${m.question}

## 3. Proposal
${m.proposal}

## 4. Data
${m.data}

## 5. FAQ
${m.faq.map((f) => `**Q: ${f.q}**\nA: ${f.a}\n`).join('\n')}

## 6. Appendix
${m.appendix}

---
*Reading instruction*: 会議冒頭の30分間、全員で黙読してから議論を開始してください (Bezos method)。
`;
}

/**
 * AI Hallucination 12ガードレール (経営者AI境界)
 */
export const HALLUCINATION_GUARDRAILS = [
  'RAG必須: 自社データなしには回答しない',
  'Provenance表示: 全主張に出典リンク',
  'Confidence Score: 0.85未満は「不確実」明示',
  'Refuse Pattern: 不明時は「分かりません」と回答',
  'PII Redaction: 個人情報マスク',
  'Toxicity Filter: 不適切表現除去',
  '二重チェック: 数値主張は別ソースで検証',
  '時系列整合性: 過去発言との矛盾検出',
  'ドメイン制限: 経営判断以外は委譲',
  '人間承認必須: 不可逆な決定 (送金/発注) は承認必須',
  '監査ログ: 全Q&Aを保管',
  'Galileo型ハルシ検知: 出力をスコアリング',
];

/**
 * 経営者AIが踏み込んではいけない領域
 */
export const AI_FORBIDDEN_ZONES = [
  '法律判断 → 弁護士に必ず確認、AIは選択肢提示まで',
  '税務最終判断 → 税理士確認',
  '人事の最終決定 → 人間が責任を持つ',
  '資金の自動送金 → 必ず人間承認',
  '倫理的グレーゾーン → 明示的に拒否',
];

/**
 * Hedging語彙 (柔らかい不確実性表現)
 */
export const HEDGING_PHRASES = [
  '現状のデータからは...と見られます',
  '過去傾向に基づけば...の可能性が高いと考えられます',
  'ただし以下の前提が崩れた場合は変動します: ...',
  '最終判断は専門家にご確認ください',
];

/**
 * 信頼度ラベル付与
 */
export interface TrustLabel {
  confidence: 'high' | 'medium' | 'low';
  source: string;
  dataFreshness: string; // ISO date
  hedging?: string;
}

export function annotateWithTrust(content: string, label: TrustLabel): string {
  return `${content}

---
*[信頼度: ${label.confidence}] [出典: ${label.source}] [データ鮮度: ${label.dataFreshness}]${
    label.hedging ? `\n${label.hedging}` : ''
  }*`;
}

/**
 * 報告書アンチパターン検出
 */
export function detectAntiPatterns(text: string): { pattern: string; severity: 'high' | 'medium' | 'low' }[] {
  const issues: { pattern: string; severity: 'high' | 'medium' | 'low' }[] = [];

  // 1文の長さチェック
  const sentences = text.split(/[。\.！？!?]/);
  const longSentences = sentences.filter((s) => s.length > 60);
  if (longSentences.length > 0) {
    issues.push({ pattern: `冗長 (一文60字超 ${longSentences.length}件)`, severity: 'medium' });
  }

  // 結論先出しチェック (最初の3行に「結論」「Bottom」「BLUF」キーワード)
  const firstLines = text.split('\n').slice(0, 3).join('\n');
  if (!/結論|Bottom|BLUF|要旨|サマリ/i.test(firstLines)) {
    issues.push({ pattern: '結論不明 (冒頭3行に結論なし)', severity: 'high' });
  }

  // 専門用語密度 (alphabetic acronyms)
  const acronyms = (text.match(/\b[A-Z]{2,}\b/g) || []).length;
  if (acronyms > 10) {
    issues.push({ pattern: `専門用語連発 (略語 ${acronyms}個)`, severity: 'medium' });
  }

  // 他人事チェック
  if (/努力不足|現場のやる気|根性|意識改革/i.test(text)) {
    issues.push({ pattern: '他人事 (組織責任化)', severity: 'medium' });
  }

  // 隠蔽チェック (問題なしの強調)
  if (/特に問題なし|順調に推移|大きな課題なし/i.test(text)) {
    issues.push({ pattern: '隠蔽の可能性 (問題なし強調)', severity: 'low' });
  }

  return issues;
}
