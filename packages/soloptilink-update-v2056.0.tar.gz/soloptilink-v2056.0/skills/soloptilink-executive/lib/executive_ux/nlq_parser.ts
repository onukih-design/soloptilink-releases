/**
 * SoloptiLinkAI v2033.0 — Natural Language Query Parser (Executive)
 * Phase 45 Executive Cognitive Layer
 *
 * 経営者が日常で発する自然言語クエリ100件を構造化。
 * 日本経営者語彙20語 (ヨミ表/Aヨミ/アンダー/内示/銀行筋/着地/腹落ち) を同義語辞書に統合。
 *
 * 用途: 経営者画面/Co-Pilot生成時に、ユーザーが口語で聞きたい質問→集計クエリ→表示UIへ変換。
 */

export type NLQCategory = 'cash' | 'hr' | 'customer' | 'product' | 'market' | 'risk' | 'strategy';

export interface NLQPattern {
  id: string;
  category: NLQCategory;
  phrase: string;
  synonyms: string[];
  parse: string; // 擬似SQL/集計ロジック
  display: string; // 返すグラフ・数値・比較対象
  nextActions: string[]; // 次に見るべきもの3点
  trustLabel: 'high' | 'medium' | 'low';
  latencyTargetMs: number;
}

// 経営者語彙辞書 (日本経営者特有の現場語) - 同義語展開に使用
export const EXECUTIVE_JP_LEXICON: Record<string, { meaning: string; synonyms: string[] }> = {
  ヨミ表: { meaning: '営業の見込み確度表 (リクルート発祥)', synonyms: ['見込み表', '商談ヨミ', 'パイプライン'] },
  Aヨミ: { meaning: '受注確度90%以上', synonyms: ['Aランク', 'ほぼ確実'] },
  Bヨミ: { meaning: '受注確度60-89%', synonyms: ['Bランク', '六分'] },
  Cヨミ: { meaning: '受注確度30-59%', synonyms: ['Cランク', '三分'] },
  内示: { meaning: '正式辞令前の非公式通知', synonyms: ['内々示', '事前通知'] },
  銀行筋: { meaning: '銀行・金融機関関係者の意見', synonyms: ['金融機関', 'バンク筋'] },
  アンダー: { meaning: '公式価格より低い特別価格 / 公式数字に出ない裏取引', synonyms: ['裏価格', '特別価格'] },
  裏目標: { meaning: '公式目標とは別に持つ実質目標', synonyms: ['実質目標', '真の目標'] },
  着地: { meaning: '期末時点の最終数値', synonyms: ['着地予想', '最終着地', '見込み'] },
  ヨコヨコ: { meaning: '横ばい', synonyms: ['横ばい', 'フラット'] },
  頭出し: { meaning: '議論の最初の提案', synonyms: ['イニシャル', '提案'] },
  腹落ち: { meaning: '納得', synonyms: ['納得', '理解', '咀嚼'] },
  ガラポン: { meaning: 'ゼロベース見直し', synonyms: ['抜本見直し', 'ゼロベース'] },
  しゃんしゃん: { meaning: '異論なく議題承認', synonyms: ['全会一致', '無風承認'] },
  稟議: { meaning: '起案者→決裁者の押印承認フロー', synonyms: ['決裁', '承認フロー'] },
  白紙撤回: { meaning: '一旦無かったことに', synonyms: ['撤回', '取消'] },
  ご相談ベース: { meaning: '正式案件化前の非公式打診', synonyms: ['非公式打診', '事前相談'] },
  てっぺん: { meaning: '経営者/最終決定者', synonyms: ['経営者', 'トップ', '社長'] },
  筋の良し悪し: { meaning: '案件・人材の本質的見込み', synonyms: ['案件の質', '見込みの良さ'] },
  背中合わせ: { meaning: '互いに見えない部分を任せ合う関係', synonyms: ['信頼関係', '相互補完'] },
  手挙げ: { meaning: '自主立候補', synonyms: ['立候補', '志願'] },
};

// ========== カネ (cash) 20件 ==========

export const NLQ_CASH: NLQPattern[] = [
  {
    id: 'NLQ_CASH_001', category: 'cash',
    phrase: '資金やばくない?',
    synonyms: ['資金大丈夫?', 'キャッシュ足りる?', '資金繰りどう?', '銀行筋から見て大丈夫?'],
    parse: 'SELECT cash_balance, monthly_burn, runway_months FROM finance.daily WHERE date = TODAY()',
    display: '信号機(赤黄緑) + 残月数(数字) + 過去6ヶ月キャッシュ推移折れ線',
    nextActions: ['未収金トップ5', '今月の固定費', '借入余力'],
    trustLabel: 'high', latencyTargetMs: 2000,
  },
  {
    id: 'NLQ_CASH_002', category: 'cash',
    phrase: '今月儲かってる?',
    synonyms: ['今月の利益どう?', 'MTD どう?', '月次PLどう?'],
    parse: 'MTD粗利 - MTD固定費按分',
    display: '月初〜今日までの累計利益 + 前月同日比 + 月末着地予測(±15%)',
    nextActions: ['受注残', '原価率異常', '値引き多発案件'],
    trustLabel: 'high', latencyTargetMs: 2000,
  },
  {
    id: 'NLQ_CASH_003', category: 'cash',
    phrase: '来月の支払い大丈夫?',
    synonyms: ['来月キャッシュ足りる?', '翌月資金繰り'],
    parse: '翌月の支払予定 vs 翌月末キャッシュ予測',
    display: '翌月キャッシュフロー予測ガントチャート + 安全マージン',
    nextActions: ['回収遅延', '支払サイト交渉余地', '短期借入オプション'],
    trustLabel: 'high', latencyTargetMs: 2500,
  },
  {
    id: 'NLQ_CASH_004', category: 'cash',
    phrase: 'ヨミ通り着地しそう?',
    synonyms: ['着地予想は?', '目標達成しそう?', 'ヨミ表どう?'],
    parse: 'A * 1.0 + B * 0.7 + C * 0.3 vs 期目標',
    display: 'Aヨミ/Bヨミ/Cヨミの3段重ね棒 + 着地予測ファンチャート',
    nextActions: ['Aヨミの停滞案件', 'Cヨミの再評価', '営業ボトルネック'],
    trustLabel: 'medium', latencyTargetMs: 2500,
  },
  {
    id: 'NLQ_CASH_005', category: 'cash',
    phrase: '銀行筋から見て大丈夫?',
    synonyms: ['銀行格付どう?', '融資受けられる?', '信用度どう?'],
    parse: '自己資本比率 + 流動比率 + DEレシオ + DSCR から格付シミュレーション',
    display: '銀行格付シミュレーション (正常先〜破綻懸念) + 改善要因',
    nextActions: ['メインバンク格付け維持要件', '財務制限条項', '次期借入予定'],
    trustLabel: 'medium', latencyTargetMs: 3000,
  },
  {
    id: 'NLQ_CASH_006', category: 'cash',
    phrase: 'うちの原価、上がってない?',
    synonyms: ['原価率悪化してる?', 'GP率下がってる?'],
    parse: '原価率 月次推移 vs 前年同月 vs 業界平均',
    display: '折れ線3本オーバーレイ',
    nextActions: ['値上がり仕入先', '値下がり受注品', '価格転嫁進捗'],
    trustLabel: 'high', latencyTargetMs: 2000,
  },
  {
    id: 'NLQ_CASH_007', category: 'cash',
    phrase: '現金、いつ尽きる?',
    synonyms: ['Runwayは?', '何ヶ月持つ?', '資金枯渇いつ?'],
    parse: 'cash_balance / (monthly_outflow - monthly_inflow)',
    display: '砂時計UI + 月数 + What-if「売上-10%なら何ヶ月?」スライダー',
    nextActions: ['固定費削減候補', '前受金交渉可能顧客', '緊急融資枠'],
    trustLabel: 'high', latencyTargetMs: 2500,
  },
  {
    id: 'NLQ_CASH_008', category: 'cash',
    phrase: '赤字事業どれ?',
    synonyms: ['赤字部門は?', 'マイナス事業は?'],
    parse: '部門×製品マトリクスで営業利益<0をハイライト',
    display: 'ヒートマップ(赤=赤字)',
    nextActions: ['撤退基準到達品', '間接費再配賦試算', '人員配置最適化'],
    trustLabel: 'high', latencyTargetMs: 2500,
  },
  {
    id: 'NLQ_CASH_009', category: 'cash',
    phrase: '利益率いいの何?',
    synonyms: ['高利益率商品は?', '稼ぎ頭は?'],
    parse: '製品別/顧客別の粗利率ランキング上位10',
    display: '棒グラフ + 各バー上に売上額バブル',
    nextActions: ['上位品のキャパ余裕', '類似顧客への横展開', '値上げ余地'],
    trustLabel: 'high', latencyTargetMs: 2000,
  },
  {
    id: 'NLQ_CASH_010', category: 'cash',
    phrase: '今期の着地、いくら?',
    synonyms: ['年度着地は?', '通期見込み'],
    parse: 'YTD実績 + 残月予測(Aヨミ100%+Bヨミ70%+Cヨミ30%)',
    display: '着地予測ファンチャート + 計画線',
    nextActions: ['目標差分', '受注確度UP施策', 'コスト圧縮余地'],
    trustLabel: 'medium', latencyTargetMs: 2500,
  },
  { id: 'NLQ_CASH_011', category: 'cash', phrase: '税金いくら?', synonyms: ['納税額は?', '法人税どれくらい?'], parse: '予想課税所得 × 実効税率', display: '中間納税 + 確定納税 + 消費税', nextActions: ['節税余地', '納税スケジュール', '資金確保'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_CASH_012', category: 'cash', phrase: 'キャッシュコンバージョン何日?', synonyms: ['CCC何日?', '資金繰り効率'], parse: 'DSO + DIO - DPO', display: '在庫日数/売掛日数/買掛日数 水平バー + 業界中央値オーバーレイ', nextActions: ['回収悪化顧客', '滞留在庫', '支払サイト'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_CASH_013', category: 'cash', phrase: '立替金、回収できそう?', synonyms: ['売掛回収状況', 'AR エイジング'], parse: '売掛金エイジング(0-30/31-60/61-90/91+日)', display: '4段階バー + 91日超ハイライト', nextActions: ['遅延トップ10', '督促状況', '貸倒引当'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_CASH_014', category: 'cash', phrase: '役員報酬、変えるべき?', synonyms: ['役員給与どう?'], parse: '業界平均役員報酬 vs 自社 vs 利益額', display: '比較棒 + 増減シミュレーション (法人税影響込み)', nextActions: ['税効果試算', '社会保険負担', '株主説明資料'], trustLabel: 'medium', latencyTargetMs: 3000 },
  { id: 'NLQ_CASH_015', category: 'cash', phrase: '投資、回収できてる?', synonyms: ['ROI出てる?', '投資効果'], parse: '案件別ROI = 累計利益 / 投資額', display: '投資案件カード一覧 + 各カードに回収進捗バー', nextActions: ['回収遅延案件', '黒字化見通し', '撤退判断'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_CASH_016', category: 'cash', phrase: 'ぶっちゃけ今月のPLどう?', synonyms: ['月次PL速報'], parse: 'MTD PL一式 + 前月比 + 計画比', display: 'PLスケジュール(売上→粗利→販管→営業利益→当期純利益) 1画面', nextActions: ['計画乖離項目', '異常仕訳', '月末着地予測'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_CASH_017', category: 'cash', phrase: '無駄遣いしてる?', synonyms: ['経費異常ある?'], parse: '経費科目別の前年比増減率 + 異常検知', display: '棒の長さ=増減額, 色=異常スコア', nextActions: ['交際費異常', 'サブスク棚卸', '重複支払検知'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_CASH_018', category: 'cash', phrase: '補助金もらえそうな?', synonyms: ['補助金マッチング'], parse: '自社属性(業種/規模/地域) × 公募中補助金DB', display: 'マッチ度ランキング + 締切カレンダー', nextActions: ['申請工数試算', '採択率', '専門家紹介'], trustLabel: 'medium', latencyTargetMs: 3000 },
  { id: 'NLQ_CASH_019', category: 'cash', phrase: 'いま借りられる?', synonyms: ['借入余力は?'], parse: '自己資本比率 × 担保 × 既存借入 → 借入余力試算', display: '余力レンジ + メインバンク別シミュレーション', nextActions: ['金利相場', '返済余力', '用途別商品'], trustLabel: 'medium', latencyTargetMs: 3000 },
  { id: 'NLQ_CASH_020', category: 'cash', phrase: '為替どれくらい効いてる?', synonyms: ['為替リスク'], parse: '輸出入金額 × 為替変動率', display: '為替感応度マトリクス(±5円ごと)', nextActions: ['為替予約余地', '価格転嫁', 'ヘッジ比率'], trustLabel: 'medium', latencyTargetMs: 2500 },
];

// ========== ヒト (hr) 15件 ==========

export const NLQ_HR: NLQPattern[] = [
  { id: 'NLQ_HR_001', category: 'hr', phrase: '最近誰か辞めそう?', synonyms: ['離職予兆ある?', 'リテンションリスク'], parse: '離職リスクスコア(残業/評価/勤怠/サーベイ)', display: '上位10名カード + リスク要因タグ', nextActions: ['1on1推奨', '給与レンジ確認', '後任計画'], trustLabel: 'medium', latencyTargetMs: 3000 },
  { id: 'NLQ_HR_002', category: 'hr', phrase: '採用、間に合ってる?', synonyms: ['採用進捗'], parse: '採用計画 vs 内定承諾 + 選考進捗', display: 'ファネル(応募→書類→面接→内定→入社)', nextActions: ['選考ボトルネック', '媒体ROI', '辞退理由分析'], trustLabel: 'high', latencyTargetMs: 2500 },
  { id: 'NLQ_HR_003', category: 'hr', phrase: '人件費、業界平均と比べてどう?', synonyms: ['労分どう?'], parse: '人件費率 vs 同業ベンチマーク', display: '業界4分位の中で自社位置 + 推移', nextActions: ['生産性', '昇給原資', '配置適正'], trustLabel: 'high', latencyTargetMs: 2500 },
  { id: 'NLQ_HR_004', category: 'hr', phrase: '残業多すぎる部署は?', synonyms: ['長時間労働部署'], parse: '部門別平均残業時間', display: '部門ランキング + 36協定閾値ライン', nextActions: ['過労リスク者', '増員要否', '業務棚卸'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_HR_005', category: 'hr', phrase: '評価バラついてない?', synonyms: ['評価分布どう?'], parse: '評価分布 部門×等級', display: 'ヒートマップ(緑=正規分布, 赤=偏り)', nextActions: ['甘い/厳しい評価者', 'キャリブレーション', '異議申立'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_HR_006', category: 'hr', phrase: '給与、市場と乖離してる?', synonyms: ['市場給与どう?'], parse: '役職×年齢別の自社給与 vs 業界中央値', display: '散布図 + 中央値線', nextActions: ['離職リスク高位者', '昇給優先順位', '採用競争力'], trustLabel: 'medium', latencyTargetMs: 3000 },
  { id: 'NLQ_HR_007', category: 'hr', phrase: '内示出してないやつ誰?', synonyms: ['異動通知未済'], parse: '人事異動計画で未通知の社員', display: '異動者リスト + 通知ステータス', nextActions: ['通知期限', '上長承認', '発令日'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_HR_008', category: 'hr', phrase: '研修、ROI出てる?', synonyms: ['研修効果'], parse: '研修費用 vs 受講者の評価・昇格率変化', display: '研修別ROI + 受講前後比較', nextActions: ['継続/廃止判断', '効果高い研修拡大', 'Eラーニング切替'], trustLabel: 'low', latencyTargetMs: 3000 },
  { id: 'NLQ_HR_009', category: 'hr', phrase: '女性管理職比率、目標到達?', synonyms: ['ダイバーシティ進捗'], parse: '女性管理職率 vs 政府目標30% vs 業界平均', display: 'ゲージ + 推移', nextActions: ['育成パイプライン', '昇格候補', '開示準備'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_HR_010', category: 'hr', phrase: 'うちのエンゲージメントどう?', synonyms: ['eNPSどう?', 'サーベイ結果'], parse: '直近サーベイ平均 + 部門別 + 設問別', display: 'レーダーチャート', nextActions: ['低スコア部門', '原因分析', '改善施策'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_HR_011', category: 'hr', phrase: '採用にいくらかかってる?', synonyms: ['採用単価'], parse: '採用単価 = 採用費用 / 入社人数', display: '媒体別単価ランキング', nextActions: ['リファラル拡大', '媒体縮小', 'ダイレクトリクルーティング'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_HR_012', category: 'hr', phrase: 'シニアの活用、進んでる?', synonyms: ['高齢者活用'], parse: '60歳以上の在籍率/活躍度', display: '年齢別生産性', nextActions: ['再雇用制度', 'キャリア面談', '技能伝承'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_HR_013', category: 'hr', phrase: 'うちの離職率、高い?', synonyms: ['離職率業界比'], parse: '直近12ヶ月離職率 vs 業界平均', display: '折れ線 + ベンチライン', nextActions: ['離職理由ヒアリング', '残留施策', '採用強化'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_HR_014', category: 'hr', phrase: '次の役員候補、誰?', synonyms: ['サクセッションプラン'], parse: 'サクセッションプラン', display: '9-Boxマトリクス(業績×ポテンシャル)', nextActions: ['育成計画', '外部公募', '役員研修'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_HR_015', category: 'hr', phrase: '健康診断、要再検査の社員いる?', synonyms: ['健診フォロー'], parse: '健診結果ステータス + 産業医面談予定', display: '要再検査者一覧 + フォロー進捗', nextActions: ['面談設定', '休職リスク', '健康投資ROI'], trustLabel: 'high', latencyTargetMs: 2000 },
];

// ========== 顧客・商品・市場・リスク・戦略 (50件) ==========

export const NLQ_CUSTOMER: NLQPattern[] = [
  { id: 'NLQ_CUS_001', category: 'customer', phrase: '今月、新規どんくらい?', synonyms: ['新規受注数'], parse: 'COUNT(新規契約) WHERE MTD', display: '件数 + MRR + 前月比 + 業種内訳', nextActions: ['受注経路', '単価', 'LTV予測'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_CUS_002', category: 'customer', phrase: '解約、増えてない?', synonyms: ['チャーン率どう?'], parse: 'チャーンレート月次 + コホート別', display: 'コホート行列(緑→赤)', nextActions: ['解約理由トップ3', '解約予兆顧客', 'リテンション施策'], trustLabel: 'high', latencyTargetMs: 2500 },
  { id: 'NLQ_CUS_003', category: 'customer', phrase: 'ヘビーユーザー誰?', synonyms: ['ロイヤル顧客'], parse: '利用頻度・課金額上位顧客', display: 'TOP10カード', nextActions: ['アップセル余地', 'ロイヤルティ施策', '紹介依頼'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_CUS_004', category: 'customer', phrase: 'うちの顧客満足度どう?', synonyms: ['NPSどう?'], parse: 'NPS + CSAT + CES', display: '3指標ゲージ + 業界比', nextActions: ['Detractorの理由', 'Promoter紹介促進', '改善要望'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_CUS_005', category: 'customer', phrase: '単価、上がってる?', synonyms: ['ARPUどう?'], parse: 'ARPU推移', display: '折れ線 + 値上げ実施タイミングマーカー', nextActions: ['値上げ未実施顧客', '高単価プラン浸透率', '値下げ要請'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_CUS_006', category: 'customer', phrase: '失注、何が多い?', synonyms: ['Lost理由'], parse: 'Lost理由分類', display: 'パレート図(価格/機能/タイミング/競合)', nextActions: ['価格戦略', '機能ロードマップ', 'ナーチャリング'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_CUS_007', category: 'customer', phrase: '営業マン誰が伸びてる?', synonyms: ['営業ランキング'], parse: '営業別売上 + 成長率 + Win率', display: 'バブルチャート(売上額×成長率)', nextActions: ['トップ営業のナレッジ抽出', '低迷者コーチング', 'インセンティブ'], trustLabel: 'high', latencyTargetMs: 2500 },
  { id: 'NLQ_CUS_008', category: 'customer', phrase: 'クレーム、傾向ある?', synonyms: ['クレーム分析'], parse: 'クレーム件数月次 + 分類タグ', display: '折れ線 + ワードクラウド', nextActions: ['再発防止策', 'CS人員', '品質改善'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_CUS_009', category: 'customer', phrase: 'リピート率どう?', synonyms: ['Repeat Rate'], parse: 'リピート購入率 顧客別', display: 'コホート + 平均購入回数', nextActions: ['離反予兆', '休眠掘り起こし', 'ロイヤルティ'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_CUS_010', category: 'customer', phrase: 'うちの最大顧客、減ってない?', synonyms: ['TOP顧客状況'], parse: 'TOP10顧客の月次売上推移', display: '折れ線10本 + アラート色', nextActions: ['減少顧客の担当者面談', '競合動向', '依存度リスク'], trustLabel: 'high', latencyTargetMs: 2500 },
  { id: 'NLQ_CUS_011', category: 'customer', phrase: 'セグメント別の伸び、どこ?', synonyms: ['業種別売上'], parse: '業種/規模/地域別の成長率', display: 'マトリクス(業種×規模)、色=成長率', nextActions: ['伸び業種に営業集中', '停滞業種撤退検討', '地域戦略'], trustLabel: 'medium', latencyTargetMs: 3000 },
  { id: 'NLQ_CUS_012', category: 'customer', phrase: 'アンダー値引きしてる案件は?', synonyms: ['特別値引き案件'], parse: '標準価格-実販価格 > 閾値', display: '値引き率TOPランキング + 営業マン名', nextActions: ['承認外値引き', '顧客交渉力', '営業教育'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_CUS_013', category: 'customer', phrase: 'LTV、上がってる?', synonyms: ['LTV推移'], parse: 'LTV = ARPU × 平均継続月数', display: 'コホート別LTV折れ線', nextActions: ['継続期間延伸施策', 'クロスセル', '解約防止'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_CUS_014', category: 'customer', phrase: 'うちのファン顧客、誰?', synonyms: ['Promoter顧客'], parse: 'NPS9-10 + 紹介実績 + 長期契約', display: 'ファン顧客カード', nextActions: ['証言取得', '事例化', '紹介プログラム'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_CUS_015', category: 'customer', phrase: '請求トラブル、最近どう?', synonyms: ['請求業務問題'], parse: '入金遅延件数 + 問合せ件数', display: '折れ線 + 異常検知', nextActions: ['請求書発行品質', '回収プロセス', '与信再評価'], trustLabel: 'high', latencyTargetMs: 2000 },
];

export const NLQ_PRODUCT: NLQPattern[] = [
  { id: 'NLQ_PRD_001', category: 'product', phrase: 'いま何が売れてる?', synonyms: ['売れ筋'], parse: 'MTD売上 by 商品 ORDER BY DESC', display: '商品TOP10 + 売上額/個数/前月比', nextActions: ['欠品リスク', '類似品アップセル', '販促強化'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_PRD_002', category: 'product', phrase: '死に筋、どれ?', synonyms: ['滞留商品'], parse: '過去90日販売数 < 閾値', display: '死筋一覧 + 在庫額', nextActions: ['値引き処分', '廃番判断', '在庫評価損'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_PRD_003', category: 'product', phrase: '在庫、過剰?', synonyms: ['在庫水準どう?'], parse: '在庫回転日数 by 品目', display: 'ヒストグラム + 標準範囲ライン', nextActions: ['過剰在庫品', '欠品リスク品', '発注量見直し'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_PRD_004', category: 'product', phrase: '新商品、立ち上がってる?', synonyms: ['新製品進捗'], parse: '発売後X日の売上 vs 計画', display: '立ち上がり曲線 vs 計画線', nextActions: ['販促強化', '計画修正', '価格調整'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_PRD_005', category: 'product', phrase: '廃番にしたいやつある?', synonyms: ['廃番候補'], parse: '売上停滞 + 利益率低 + 在庫滞留', display: '候補リスト + 廃番影響試算', nextActions: ['顧客通知', '代替品提案', '在庫処分'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_PRD_006', category: 'product', phrase: '原価率、悪化してない?', synonyms: ['原価高騰'], parse: '商品別原価率の月次推移', display: '折れ線 + 警告閾値', nextActions: ['値上げ可否', '仕入見直し', '設計変更'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_PRD_007', category: 'product', phrase: 'セット販売、効いてる?', synonyms: ['バンドル効果'], parse: 'バンドル販売件数 + 単品比較粗利', display: 'バンドル別実績ランキング', nextActions: ['好調バンドル拡大', '不調バンドル見直し', '新セット企画'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_PRD_008', category: 'product', phrase: 'カテゴリ別売上、どう?', synonyms: ['カテゴリ別構成'], parse: '大カテゴリ売上ピボット', display: 'ドリルダウン可能ツリーマップ', nextActions: ['伸びカテゴリ強化', '停滞カテゴリ撤退', '構成比目標'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_PRD_009', category: 'product', phrase: '季節商品、出だしどう?', synonyms: ['シーズン商品'], parse: '季節商品の同時期前年比', display: '折れ線 + 前年同週オーバーレイ', nextActions: ['追加発注', '販促前倒し', '在庫調整'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_PRD_010', category: 'product', phrase: '価格帯別の売上構成、どう?', synonyms: ['価格帯ミックス'], parse: '価格帯ビンの売上構成', display: '階段グラフ', nextActions: ['高単価帯拡大', '低単価品淘汰', '価格再設計'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_PRD_011', category: 'product', phrase: 'うちの主力品、寿命残ってる?', synonyms: ['プロダクトライフサイクル'], parse: 'PLC診断(導入/成長/成熟/衰退)', display: 'PLCマップ + ポジション', nextActions: ['次世代品開発', '延命策', '撤退判断'], trustLabel: 'medium', latencyTargetMs: 3000 },
  { id: 'NLQ_PRD_012', category: 'product', phrase: 'サプライヤー、偏ってない?', synonyms: ['調達集中度'], parse: '仕入先別依存度', display: 'パイチャート + 集中度指数', nextActions: ['第二調達先確保', 'BCP', '価格交渉力'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_PRD_013', category: 'product', phrase: 'ロスどんくらい?', synonyms: ['廃棄ロス'], parse: '廃棄/返品/不良率', display: '月次推移 + 原因タグ', nextActions: ['品質改善', '需要予測', '物流見直し'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_PRD_014', category: 'product', phrase: 'うちの粗利TOP、何?', synonyms: ['利益貢献品'], parse: '商品別粗利額ランキング', display: 'パレート + 80/20カーブ', nextActions: ['TOP品の販売強化', '類似新規開発', '低粗利品縮小'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_PRD_015', category: 'product', phrase: 'サブスク、解約理由は?', synonyms: ['Churn理由'], parse: '解約フォーム回答 + 利用ログ', display: '解約理由パレート', nextActions: ['UI改善', '価格見直し', 'オンボーディング改修'], trustLabel: 'medium', latencyTargetMs: 2500 },
];

export const NLQ_MARKET: NLQPattern[] = [
  { id: 'NLQ_MKT_001', category: 'market', phrase: 'うちのシェア、どんくらい?', synonyms: ['市場シェア'], parse: '自社売上 / 推計市場規模', display: '円グラフ + 業界1位とのギャップ', nextActions: ['ターゲット市場深耕', '隣接市場', 'M&A候補'], trustLabel: 'low', latencyTargetMs: 3000 },
  { id: 'NLQ_MKT_002', category: 'market', phrase: '競合、最近何やってる?', synonyms: ['競合動向'], parse: '競合社のニュース/プレス/決算/SNS要約', display: 'タイムライン + AIサマリ', nextActions: ['脅威度評価', '対抗策', '共同戦線'], trustLabel: 'medium', latencyTargetMs: 5000 },
  { id: 'NLQ_MKT_003', category: 'market', phrase: '業界、伸びてる?', synonyms: ['業界トレンド'], parse: '業界統計の月次/四半期推移', display: 'マクロ指標 + 自社成長との対比', nextActions: ['追い風活用', '逆風対応', '隣接領域'], trustLabel: 'medium', latencyTargetMs: 3000 },
  { id: 'NLQ_MKT_004', category: 'market', phrase: '価格、競合と比べてどう?', synonyms: ['価格競争力'], parse: '代表製品の競合価格マップ', display: '価格分布散布図', nextActions: ['値上げ余地', '値下げ圧', '価値伝達'], trustLabel: 'medium', latencyTargetMs: 3000 },
  { id: 'NLQ_MKT_005', category: 'market', phrase: '失注先、どこ?', synonyms: ['Lost先'], parse: 'Lost理由「他社決定」の競合名集計', display: '競合別失注件数ランキング', nextActions: ['競合分析', '差別化強化', 'バトルカード'], trustLabel: 'high', latencyTargetMs: 2500 },
  { id: 'NLQ_MKT_006', category: 'market', phrase: 'うちの口コミ、評判どう?', synonyms: ['SNS評判'], parse: 'SNS/レビューサイトのセンチメント分析', display: 'スコア + 主要キーワード', nextActions: ['ネガ要因対応', 'ポジ要因強化', 'インフルエンサー連携'], trustLabel: 'medium', latencyTargetMs: 4000 },
  { id: 'NLQ_MKT_007', category: 'market', phrase: '規制、影響ある?', synonyms: ['法改正影響'], parse: '業界関連法改正/ガイドライン更新', display: '影響度マトリクス', nextActions: ['コンプラ対応', '制度活用', '意見表明'], trustLabel: 'medium', latencyTargetMs: 3000 },
  { id: 'NLQ_MKT_008', category: 'market', phrase: '新規参入、出てきてる?', synonyms: ['新規参入者'], parse: '業界の新規参入企業/スタートアップ', display: '参入マップ + 資金調達情報', nextActions: ['脅威度評価', '提携検討', 'M&A候補'], trustLabel: 'low', latencyTargetMs: 5000 },
  { id: 'NLQ_MKT_009', category: 'market', phrase: '次のトレンド、何?', synonyms: ['未来トレンド'], parse: '業界トレンドキーワード集計 + Google Trends', display: 'トレンドカーブ + 自社対応度', nextActions: ['早期投資', 'PoC', '人材確保'], trustLabel: 'low', latencyTargetMs: 5000 },
  { id: 'NLQ_MKT_010', category: 'market', phrase: 'うちの強み、客観的に何?', synonyms: ['競争優位'], parse: '顧客アンケート + 受注理由 + 競合差分', display: 'SWOT自動生成', nextActions: ['強み訴求拡大', '弱み補強', '機会捕捉'], trustLabel: 'medium', latencyTargetMs: 4000 },
];

export const NLQ_RISK: NLQPattern[] = [
  { id: 'NLQ_RSK_001', category: 'risk', phrase: 'ヤバい取引先、ある?', synonyms: ['与信リスク'], parse: '与信スコア低 + 支払遅延', display: 'リスク顧客リスト + スコア', nextActions: ['与信枠縮小', '前金交渉', '与信保険'], trustLabel: 'high', latencyTargetMs: 2500 },
  { id: 'NLQ_RSK_002', category: 'risk', phrase: 'コンプラ違反、ない?', synonyms: ['コンプライアンス'], parse: '内部監査/通報窓口/契約逸脱検知', display: 'アラート一覧 + 重要度', nextActions: ['即時調査', '是正措置', '再発防止'], trustLabel: 'high', latencyTargetMs: 2500 },
  { id: 'NLQ_RSK_003', category: 'risk', phrase: '契約、期限切れそうなのある?', synonyms: ['契約満了'], parse: '契約満了60日以内', display: '満了カレンダー + 自動更新有無', nextActions: ['再契約交渉', '値上げ機会', '解約阻止'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_RSK_004', category: 'risk', phrase: '事故、起きてない?', synonyms: ['労災状況'], parse: '労災/品質事故/情報漏洩件数', display: '月次推移 + 重大度', nextActions: ['原因分析', '保険申請', '再発防止'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_RSK_005', category: 'risk', phrase: '業界処分事例、近いの?', synonyms: ['処分事例'], parse: '業界の行政処分/訴訟事例', display: '事例タイムライン', nextActions: ['自社該当チェック', '予防策', '弁護士相談'], trustLabel: 'medium', latencyTargetMs: 4000 },
  { id: 'NLQ_RSK_006', category: 'risk', phrase: 'サイバー脅威、大丈夫?', synonyms: ['サイバーリスク'], parse: '脆弱性スコア + 過去30日のアラート', display: '信号機 + 攻撃トレンド', nextActions: ['パッチ適用', '訓練実施', '保険加入'], trustLabel: 'high', latencyTargetMs: 2500 },
  { id: 'NLQ_RSK_007', category: 'risk', phrase: '個人情報、漏れてない?', synonyms: ['情報漏洩リスク'], parse: 'アクセスログ異常検知 + メール誤送信', display: '検知件数 + 内容', nextActions: ['影響範囲調査', '本人通知', '個情委報告'], trustLabel: 'high', latencyTargetMs: 2500 },
  { id: 'NLQ_RSK_008', category: 'risk', phrase: '災害BCP、機能する?', synonyms: ['BCP状況'], parse: 'BCP訓練実施状況 + RTO/RPO達成率', display: 'チェックリストスコア', nextActions: ['訓練計画', 'バックアップ確認', '代替拠点'], trustLabel: 'medium', latencyTargetMs: 3000 },
  { id: 'NLQ_RSK_009', category: 'risk', phrase: 'ハラスメント、通報ある?', synonyms: ['通報状況'], parse: '通報窓口の受領件数 + 進捗', display: '件数 + 対応ステータス', nextActions: ['迅速対応', '再発防止研修', '制度見直し'], trustLabel: 'high', latencyTargetMs: 2000 },
  { id: 'NLQ_RSK_010', category: 'risk', phrase: '為替/金利、感応度どう?', synonyms: ['マクロ感応度'], parse: '為替±5円, 金利±1%の利益感応度', display: '感応度マトリクス', nextActions: ['ヘッジ', '価格転嫁', '借換'], trustLabel: 'medium', latencyTargetMs: 3000 },
];

export const NLQ_STRATEGY: NLQPattern[] = [
  { id: 'NLQ_STG_001', category: 'strategy', phrase: '中計、進捗どう?', synonyms: ['中期計画進捗'], parse: '中期計画KPI vs 実績', display: '進捗ゲージ × 主要KPI', nextActions: ['遅延要因', '挽回策', '計画見直し'], trustLabel: 'high', latencyTargetMs: 2500 },
  { id: 'NLQ_STG_002', category: 'strategy', phrase: '投資、何にしてる?', synonyms: ['投資配分'], parse: '設備投資/R&D/M&A配分', display: '円グラフ + ROI予測', nextActions: ['ROI低投資の縮小', '高ROI拡大', '再配分'], trustLabel: 'medium', latencyTargetMs: 3000 },
  { id: 'NLQ_STG_003', category: 'strategy', phrase: 'うちの強み、伸ばせてる?', synonyms: ['コア強化'], parse: 'コア事業の成長率 vs 非コア', display: '事業ポートフォリオ(BCGマトリクス)', nextActions: ['Star強化', 'Cow活用', 'Dog撤退'], trustLabel: 'medium', latencyTargetMs: 3000 },
  { id: 'NLQ_STG_004', category: 'strategy', phrase: '次の事業、何やるべき?', synonyms: ['新規事業候補'], parse: '隣接領域分析 + 顧客課題 + 自社ケイパビリティ', display: '機会マップ', nextActions: ['PoC候補', 'パートナー', 'M&A候補'], trustLabel: 'low', latencyTargetMs: 5000 },
  { id: 'NLQ_STG_005', category: 'strategy', phrase: 'DX、進んでる?', synonyms: ['DX進捗'], parse: 'DX投資額 + システム稼働率 + 業務効率化指標', display: '進捗ダッシュボード', nextActions: ['遅延プロジェクト', '人材育成', 'ベンダー評価'], trustLabel: 'medium', latencyTargetMs: 3000 },
  { id: 'NLQ_STG_006', category: 'strategy', phrase: '経営課題、何だっけ?', synonyms: ['経営イシュー'], parse: '役員会議事録の重要トピック抽出', display: '課題リスト + 担当者 + 期限', nextActions: ['期限超過', '未着手', '次回議題'], trustLabel: 'high', latencyTargetMs: 2500 },
  { id: 'NLQ_STG_007', category: 'strategy', phrase: '3年後、どうなってる?', synonyms: ['長期見通し'], parse: '中計KPIから3年後の財務予測', display: 'PL/BS/CF予測', nextActions: ['目標達成のための施策', 'リスク要因', '上方修正可能性'], trustLabel: 'low', latencyTargetMs: 5000 },
  { id: 'NLQ_STG_008', category: 'strategy', phrase: 'うちの会社価値、いくら?', synonyms: ['企業価値'], parse: '簡易企業価値評価(DCF/類似会社)', display: 'バリュエーション + レンジ', nextActions: ['価値向上施策', 'M&A可能性', 'IR強化'], trustLabel: 'low', latencyTargetMs: 5000 },
  { id: 'NLQ_STG_009', category: 'strategy', phrase: 'サステナビリティ、対応進んでる?', synonyms: ['ESG進捗'], parse: 'ESG指標 + 開示対応状況', display: 'TCFD/GHG/人的資本ダッシュボード', nextActions: ['開示準備', '目標設定', '外部評価対応'], trustLabel: 'medium', latencyTargetMs: 3000 },
  { id: 'NLQ_STG_010', category: 'strategy', phrase: '海外、伸ばせてる?', synonyms: ['海外売上'], parse: '海外売上比率 + 国別収益', display: '世界地図 + 国別バブル', nextActions: ['重点国選定', '撤退検討', '現地パートナー'], trustLabel: 'high', latencyTargetMs: 2500 },
  { id: 'NLQ_STG_011', category: 'strategy', phrase: 'IPO、出来そう?', synonyms: ['上場可能性'], parse: '上場基準 vs 自社現状', display: 'チェックリストスコア', nextActions: ['管理体制整備', '監査法人', '主幹事'], trustLabel: 'medium', latencyTargetMs: 3000 },
  { id: 'NLQ_STG_012', category: 'strategy', phrase: '次の幹部、育ってる?', synonyms: ['幹部育成'], parse: 'サクセッションプラン進捗', display: 'パイプライン状態', nextActions: ['次世代研修', '抜擢計画', '外部招聘'], trustLabel: 'medium', latencyTargetMs: 2500 },
  { id: 'NLQ_STG_013', category: 'strategy', phrase: 'うちの会社、外から見てどう?', synonyms: ['外部評価'], parse: 'メディア露出 + SNS言及 + 求人サイト評価', display: 'ブランド健全度スコア', nextActions: ['PR強化', 'ネガ対応', '採用ブランディング'], trustLabel: 'medium', latencyTargetMs: 4000 },
  { id: 'NLQ_STG_014', category: 'strategy', phrase: 'M&A候補、誰がある?', synonyms: ['M&Aターゲット'], parse: '業種/規模/地域から候補抽出 + シナジー試算', display: '候補リスト + シナジースコア', nextActions: ['アプローチ計画', 'DDタスク', '資金計画'], trustLabel: 'low', latencyTargetMs: 5000 },
  { id: 'NLQ_STG_015', category: 'strategy', phrase: '経営者勘、データと合ってる?', synonyms: ['仮説検証'], parse: '経営者の仮説 vs データ実態の差分検知', display: '仮説検証ダッシュボード', nextActions: ['仮説修正', 'データ追加収集', '仮説保持判断'], trustLabel: 'medium', latencyTargetMs: 3500 },
];

export const ALL_NLQ: NLQPattern[] = [
  ...NLQ_CASH, ...NLQ_HR, ...NLQ_CUSTOMER, ...NLQ_PRODUCT, ...NLQ_MARKET, ...NLQ_RISK, ...NLQ_STRATEGY,
];

/**
 * 経営者の自然言語入力からマッチするクエリパターンを抽出
 */
export function matchNLQ(userInput: string): NLQPattern[] {
  const normalized = userInput.toLowerCase().trim();
  return ALL_NLQ.filter((nlq) => {
    if (nlq.phrase.toLowerCase().includes(normalized) || normalized.includes(nlq.phrase.toLowerCase())) return true;
    return nlq.synonyms.some((s) => s.toLowerCase().includes(normalized) || normalized.includes(s.toLowerCase()));
  });
}

/**
 * 経営者語彙を一般語に正規化 (LLMへの渡し前の前処理)
 */
export function normalizeExecutiveJpLexicon(input: string): string {
  let out = input;
  for (const [term, def] of Object.entries(EXECUTIVE_JP_LEXICON)) {
    if (out.includes(term)) {
      out = out.replace(new RegExp(term, 'g'), `${term}(=${def.meaning})`);
    }
  }
  return out;
}
