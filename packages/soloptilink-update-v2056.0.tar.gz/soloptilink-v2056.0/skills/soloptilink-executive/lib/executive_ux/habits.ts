/**
 * SoloptiLinkAI v2033.0 — Executive Habits & Scheduler
 * Phase 45 Executive Cognitive Layer
 *
 * 経営者の朝/月初/月末/四半期/年初年末の習慣を構造化。
 * システムが先回りで通知・下書き生成・準備を行うための時間軸DB。
 */

export interface DailyTask {
  time: string; // HH:MM
  task: string;
  category: 'briefing' | 'meeting' | 'review' | 'communication' | 'thinking';
  systemAutoPrep?: string; // システムが自動で準備すべきもの
}

export interface PeriodicChecklist {
  period: 'monthly_open' | 'monthly_close' | 'quarterly_close' | 'year_end' | 'year_start';
  tasks: { name: string; deadline: string; systemAutoPrep?: string }[];
}

// ========== 経営者の朝のルーティン (20件) ==========

export const MORNING_ROUTINE: DailyTask[] = [
  { time: '05:00', task: '起床 (年収1,000万円以上の70%が朝型)', category: 'briefing' },
  { time: '05:15', task: '軽い運動・ストレッチ', category: 'thinking' },
  { time: '05:30', task: '瞑想/マインドフルネス', category: 'thinking' },
  { time: '05:45', task: '経済新聞・業界ニュース', category: 'briefing', systemAutoPrep: '日経/業界ヘッドラインAI要約' },
  { time: '06:00', task: 'メール/Slack優先チェック (緊急のみ)', category: 'communication', systemAutoPrep: '重要度自動分類+5件まで絞込' },
  { time: '06:00', task: 'Dawn Brief 受信 (今日の3つ)', category: 'briefing', systemAutoPrep: '異常検知+優先度ソート+Push通知' },
  { time: '06:30', task: '朝食 + 家族時間', category: 'thinking' },
  { time: '07:00', task: '戦略思考時間 / 読書', category: 'thinking', systemAutoPrep: '提案中の戦略議題リマインド' },
  { time: '08:00', task: '会社到着、デスクで前日売上確認', category: 'review', systemAutoPrep: '前日確定数値ダッシュボード' },
  { time: '08:15', task: '朝礼前のスタッフブリーフィング', category: 'meeting', systemAutoPrep: '朝礼アジェンダ自動生成' },
  { time: '08:30', task: '朝礼 (Chorei)', category: 'meeting' },
  { time: '08:45', task: '当日アジェンダ最終確認', category: 'review', systemAutoPrep: 'カレンダー + 会議資料事前配信' },
  { time: '09:00', task: '最重要会議または重要顧客面談', category: 'meeting' },
];

// ========== 月初の経営者タスク ==========

export const MONTH_OPEN_CHECKLIST: PeriodicChecklist = {
  period: 'monthly_open',
  tasks: [
    { name: '前月確定数値の確認 (売上/利益/CF)', deadline: '月初3営業日内', systemAutoPrep: '前月確定PL/CF自動表示' },
    { name: '計画比達成度のレビュー', deadline: '月初3営業日内', systemAutoPrep: '予実差異TOP10' },
    { name: '今月の重点KPI設定', deadline: '月初5営業日内' },
    { name: '月初経営会議', deadline: '月初5営業日内', systemAutoPrep: '議題下書き+資料生成' },
    { name: '朝礼での前月総括メッセージ', deadline: '月初1日目', systemAutoPrep: 'メッセージ下書き (3行)' },
    { name: '取引先トップ3への挨拶', deadline: '月初1週間内', systemAutoPrep: '主要取引先リスト+前回接触履歴' },
    { name: '重要顧客の月初訪問計画', deadline: '月初1週間内' },
    { name: '部門長との1on1', deadline: '月初2週間内' },
  ],
};

// ========== 月末の経営者タスク ==========

export const MONTH_CLOSE_CHECKLIST: PeriodicChecklist = {
  period: 'monthly_close',
  tasks: [
    { name: '月末締め指示', deadline: '月末-3営業日', systemAutoPrep: '締めスケジュール自動通知' },
    { name: '売上着地予測の最終確認', deadline: '月末-3営業日', systemAutoPrep: '着地予測ファンチャート' },
    { name: '仕掛/在庫の物理棚卸状況確認', deadline: '月末日' },
    { name: '与信先の入金確認', deadline: '月末日', systemAutoPrep: '入金未完了顧客リスト' },
    { name: '当月のリスクサマリ作成', deadline: '月初3営業日', systemAutoPrep: 'リスク異常検知サマリ' },
    { name: '翌月予算の最終調整', deadline: '月末-1営業日' },
    { name: '月末挨拶/感謝メール送信', deadline: '月末日', systemAutoPrep: 'メール下書き生成' },
    { name: '朝礼での月次総括', deadline: '月初1日目', systemAutoPrep: '月次総括3行' },
  ],
};

// ========== 四半期末の経営者タスク ==========

export const QUARTERLY_CHECKLIST: PeriodicChecklist = {
  period: 'quarterly_close',
  tasks: [
    { name: '四半期決算レビュー (取締役会向け)', deadline: 'Q末+30日', systemAutoPrep: '決算データ自動集計' },
    { name: '中期計画進捗確認 (KPI vs 計画)', deadline: 'Q末+15日', systemAutoPrep: '中計KPIダッシュボード自動更新' },
    { name: '役員1on1 (個別評価)', deadline: 'Q末+30日' },
    { name: '投資家向け説明会準備 (上場企業)', deadline: 'Q末+30日', systemAutoPrep: 'FAQ下書き+想定問答30問' },
    { name: '戦略修正の意思決定 (環境変化対応)', deadline: 'Q末+45日' },
    { name: '次四半期予算最終化', deadline: 'Q末+10日' },
    { name: '競合分析の更新', deadline: 'Q末+30日', systemAutoPrep: '競合6社四半期決算ニュース要約' },
    { name: '株主・取引先銀行への説明資料', deadline: 'Q末+45日', systemAutoPrep: 'Board Deck Pyramid Principle' },
  ],
};

// ========== 年初の経営者タスク ==========

export const YEAR_START_CHECKLIST: PeriodicChecklist = {
  period: 'year_start',
  tasks: [
    { name: '年頭挨拶 (社員/取引先/銀行)', deadline: '1/1〜1/15', systemAutoPrep: '挨拶リスト+下書きメッセージ' },
    { name: '期初予算発表', deadline: '期初1週間内' },
    { name: '重点プロジェクト立ち上げ', deadline: '期初1ヶ月内' },
    { name: '今年の3つの重要目標設定 (Eisenhower型)', deadline: '1/1', systemAutoPrep: '目標入力プロンプト' },
  ],
};

// ========== 年末の経営者タスク ==========

export const YEAR_END_CHECKLIST: PeriodicChecklist = {
  period: 'year_end',
  tasks: [
    { name: '年間総括の社員メッセージ', deadline: '12/15〜12/30', systemAutoPrep: '年間KPI集計+メッセージ下書き' },
    { name: '来期戦略の最終確定', deadline: '12/30' },
    { name: '役員賞与決定', deadline: '12/20' },
    { name: '取引先・顧客への年末挨拶', deadline: '12/15〜12/30', systemAutoPrep: '年末挨拶リスト自動生成' },
    { name: '翌年の3つの重要目標設定', deadline: '12/30' },
  ],
};

// ========== 通知タイミング設計 ==========

export interface NotificationSchedule {
  time: string;
  content: string;
  channel: 'push' | 'email' | 'slack' | 'in_app';
  priority: 'urgent' | 'high' | 'normal';
}

export const DEFAULT_NOTIFICATION_SCHEDULE: NotificationSchedule[] = [
  { time: '06:00', content: 'Dawn Brief (最重要3件)', channel: 'push', priority: 'high' },
  { time: '08:00', content: '朝礼アジェンダ + 当日カレンダー', channel: 'in_app', priority: 'normal' },
  { time: '12:00', content: '午前中の異常検知サマリ', channel: 'in_app', priority: 'normal' },
  { time: '17:30', content: '翌日準備リマインド', channel: 'in_app', priority: 'normal' },
  { time: '19:00', content: '当日決裁待ち最終リマインド', channel: 'push', priority: 'high' },
];

/**
 * 月初・月末・四半期・年末年初の自動切替ロジック
 */
export function getActiveChecklists(date: Date = new Date()): PeriodicChecklist[] {
  const active: PeriodicChecklist[] = [];
  const day = date.getDate();
  const month = date.getMonth() + 1; // 1-12
  const lastDayOfMonth = new Date(date.getFullYear(), month, 0).getDate();

  // 月初 (1-5日)
  if (day <= 5) active.push(MONTH_OPEN_CHECKLIST);

  // 月末 (lastDay-3日 〜 lastDay)
  if (day >= lastDayOfMonth - 3) active.push(MONTH_CLOSE_CHECKLIST);

  // 四半期末 (3/6/9/12月の末)
  if ([3, 6, 9, 12].includes(month) && day >= lastDayOfMonth - 5) {
    active.push(QUARTERLY_CHECKLIST);
  }

  // 年末 (12月後半)
  if (month === 12 && day >= 15) active.push(YEAR_END_CHECKLIST);

  // 年初 (1月前半)
  if (month === 1 && day <= 15) active.push(YEAR_START_CHECKLIST);

  return active;
}

/**
 * Dawn Brief 自動生成テンプレ
 */
export interface DawnBriefData {
  date: string;
  topThree: { type: 'red' | 'yellow' | 'green'; text: string }[];
  forecastSummary: string;
}

export function renderDawnBrief(data: DawnBriefData): string {
  const lines = [
    `おはようございます ${data.date} 06:00`,
    '',
    '【今日の3つ】',
    ...data.topThree.map(
      (t, i) =>
        `${i + 1}. ${t.text} ${t.type === 'red' ? '⚠️赤' : t.type === 'yellow' ? '⚠️黄' : '✓緑'}`
    ),
    '',
    `今期着地予測: ${data.forecastSummary}`,
    '[詳細は1タップ ▼]',
  ];
  return lines.join('\n');
}
