/**
 * SoloptiLinkAI v2033.0 — Executive UI Patterns 20
 * Phase 45 Executive Cognitive Layer
 *
 * 経営者専用UIパターン20種の仕様データ。
 * 各パターンに「解決する痛み」「必要データ」「技術スタック」「Cowan 4±1チャンク準拠」を内蔵。
 * 生成時、ユーザー指示に応じて適切なUIを自動選定し、コンポーネント生成プロンプトに注入。
 */

export type UIPatternId =
  | 'DAWN_BRIEF' | 'WHAT_IF_SLIDER' | 'EISENHOWER_MATRIX' | 'YOY_OVERLAY'
  | 'DECISION_JOURNAL' | 'ONE_TAP_APPROVAL' | 'BOARD_DECK_AUTOGEN'
  | 'DECISION_BOARD' | 'NARRATIVE_PL' | 'EXECUTIVE_WHITEBOARD'
  | 'YOMI_VIEW' | 'MONTH_OPEN_COCKPIT' | 'ANCHOR_COMPARISON'
  | 'TRAFFIC_LIGHT_QUEUE' | 'MICRO_CARDS' | 'TRAFFIC_LIGHT_DISTRIBUTION'
  | 'QUERY_SUGGEST' | 'NARRATIVE_TIMELINE' | 'BOARD_PACK_PDF'
  | 'EXECUTIVE_CHAT';

export interface UIPattern {
  id: UIPatternId;
  name: string;
  jpName: string;
  pain: string;
  requiredData: string[];
  techStack: string[];
  wireframeAscii: string;
  cowan4Plus1Compliant: boolean;
  primarySurface: 'mobile' | 'desktop' | 'both';
  triggerKeywords: string[];
  componentName: string;
}

export const DAWN_BRIEF: UIPattern = {
  id: 'DAWN_BRIEF',
  name: 'Dawn Brief',
  jpName: '経営早朝ダッシュボード',
  pain: '朝の30分しか集中時間がない、何から見るべきか毎日悩む',
  requiredData: ['PL/CF', 'Pipeline', 'CRM顧客異常', 'HR異常', 'Bヨミ案件'],
  techStack: ['SSR (Next.js App Router)', 'Edge cache (5min)', 'Web Push通知', '06:00自動送信'],
  wireframeAscii: `┌──────────────────────────────────┐
│ おはようございます        2026/5/13 06:00   │
├──────────────────────────────────┤
│ 【今日の3つ】                          │
│ 1. 解約予兆 A社 (要連絡)         ⚠️赤   │
│ 2. 月末資金 安全マージン2.3ヶ月  ✓緑   │
│ 3. Bヨミ案件3件、今週決断必要    ⚠️黄   │
├──────────────────────────────────┤
│ 今期着地予測: +3.2億 (計画比+8%)        │
│ [詳細を1タップ] ▼                       │
└──────────────────────────────────┘`,
  cowan4Plus1Compliant: true,
  primarySurface: 'mobile',
  triggerKeywords: ['朝のダッシュボード', '早朝', 'Dawn Brief', '朝一画面'],
  componentName: 'DawnBrief',
};

export const WHAT_IF_SLIDER: UIPattern = {
  id: 'WHAT_IF_SLIDER',
  name: 'What-If Slider',
  jpName: 'What-Ifスライダー',
  pain: '「あれが悪化したらどうなる?」を即座に試したい',
  requiredData: ['財務モデル(PL/BS/CF)', '感応度パラメータ (売上/原価/人件費)'],
  techStack: ['React + WebWorker計算', 'リアクティブ更新', 'シナリオ保存'],
  wireframeAscii: `┌──────────────────────────────────┐
│ 売上が    [-10% ←━━●━━→ +10%]         │
│ 原価が    [-5%  ←━●━━━━→ +5%]         │
│ 人件費が  [現状 ←●━━━━━→ +20%]        │
├──────────────────────────────────┤
│ 結果:                                  │
│  営業利益: 1.2億 → 0.6億 (▼50%)        │
│  キャッシュ残月: 12 → 7ヶ月            │
│  借入余力到達: 8ヶ月後                 │
└──────────────────────────────────┘`,
  cowan4Plus1Compliant: true,
  primarySurface: 'desktop',
  triggerKeywords: ['What-If', 'シミュレーション', '感応度', 'スライダー', 'もし'],
  componentName: 'WhatIfSlider',
};

export const EISENHOWER_MATRIX: UIPattern = {
  id: 'EISENHOWER_MATRIX',
  name: 'Eisenhower Priority Matrix',
  jpName: '異常通知優先度マトリクス',
  pain: '通知が多すぎて重要なものを見落とす',
  requiredData: ['アラート影響額', '期日', '不可逆性スコア'],
  techStack: ['LLM分類 (Claude)', '4象限マッピング'],
  wireframeAscii: `       緊急
        │
[即対応] │ [深掘り]
─────────────────
 [委任]  │  [後で]
        │
      非緊急
   ←重要──非重要→`,
  cowan4Plus1Compliant: true,
  primarySurface: 'both',
  triggerKeywords: ['優先度', 'マトリクス', 'アイゼンハワー', '緊急重要'],
  componentName: 'EisenhowerMatrix',
};

export const YOY_OVERLAY: UIPattern = {
  id: 'YOY_OVERLAY',
  name: 'YoY + Industry Benchmark Overlay',
  jpName: '前年同月比+業界平均オーバーレイ',
  pain: '数字単体では好調か不調か判断つかない',
  requiredData: ['自社実績', '前年同期', '業界中央値'],
  techStack: ['D3.js / Recharts', 'レイヤード折れ線'],
  wireframeAscii: `売上推移
┌──────────────────────────────────┐
│ ●━━ 今期                              │
│ ●╌╌ 前年同期                          │
│ ●┄┄ 業界平均                          │
│   ↑ ここで業界平均を下回り、即チェック │
└──────────────────────────────────┘`,
  cowan4Plus1Compliant: true,
  primarySurface: 'desktop',
  triggerKeywords: ['前年比', '業界平均', 'ベンチマーク', '比較'],
  componentName: 'YoYOverlay',
};

export const DECISION_JOURNAL: UIPattern = {
  id: 'DECISION_JOURNAL',
  name: 'Decision Journal',
  jpName: '経営判断ログ',
  pain: '何を、なぜ決めたか忘れる。検証ができない',
  requiredData: ['判断理由', '想定影響', 'レビュー期日', '担当者'],
  techStack: ['Append-only log', 'リマインダ機能', '差分検証 (判断時 vs 現状)'],
  wireframeAscii: `┌──────────────────────────────────┐
│ 2026-05-01  値上げ決定      担当:社長   │
│  理由: 原材料15%↑、競合A社も4月実施     │
│  想定: +6%売上、顧客流出≦3%             │
│  Review: 2026-08-01 (3ヶ月後)          │
│  [現状: 顧客流出1.8%、計画内 ✓]         │
├──────────────────────────────────┤
│ 2026-04-15  新工場投資 ¥5億             │
└──────────────────────────────────┘`,
  cowan4Plus1Compliant: true,
  primarySurface: 'desktop',
  triggerKeywords: ['判断ログ', '意思決定記録', 'Decision Journal', '振り返り'],
  componentName: 'DecisionJournal',
};

export const ONE_TAP_APPROVAL: UIPattern = {
  id: 'ONE_TAP_APPROVAL',
  name: 'One-Tap Approval',
  jpName: '決裁待ち最小化',
  pain: '出張中に決裁が滞り、現場が止まる',
  requiredData: ['稟議書', '予算枠', '類似過去案件'],
  techStack: ['Slack Bolt / Teams Adaptive Card', 'DocuSign連携', 'モバイルPush'],
  wireframeAscii: `┌──────────────────────────────┐
│ 稟議: 設備購入 ¥3,200,000        │
│ 起案: 工場長 田中                │
│ 理由: 旧機械故障多発、+30%生産性 │
│ 影響: 投資回収14ヶ月             │
│  [✓承認] [×差戻] [💬質問]       │
└──────────────────────────────┘`,
  cowan4Plus1Compliant: true,
  primarySurface: 'mobile',
  triggerKeywords: ['決裁', '承認', '稟議', 'approval'],
  componentName: 'OneTapApproval',
};

export const BOARD_DECK_AUTOGEN: UIPattern = {
  id: 'BOARD_DECK_AUTOGEN',
  name: 'Board Deck Auto-Generator',
  jpName: '役員会資料即時化',
  pain: '役員会資料作成に毎月8時間かかる',
  requiredData: ['当月実績', 'KPI進捗', '重要トピック', '決議事項'],
  techStack: ['Pyramid Principleテンプレ', 'pptx/PDF生成', 'Claude API要約'],
  wireframeAscii: `[画面右上]
[📊 役員会用PDFに変換]   ← 1クリック
┌──────────────────────────────┐
│ 役員会資料 2026年5月度            │
│ 1. ハイライト  (1p)              │
│ 2. KPI進捗    (3p)              │
│ 3. リスク     (1p)              │
│ 4. 決議事項   (1p)              │
└──────────────────────────────┘`,
  cowan4Plus1Compliant: true,
  primarySurface: 'desktop',
  triggerKeywords: ['役員会', 'Board Deck', '取締役会資料', 'Board Pack'],
  componentName: 'BoardDeckGenerator',
};

export const DECISION_BOARD: UIPattern = {
  id: 'DECISION_BOARD',
  name: 'Meeting Decision Board',
  jpName: '会議意思決定ボード',
  pain: '議論しても誰が何をいつまでにやるか曖昧',
  requiredData: ['議題', '決定', '責任者', '期限'],
  techStack: ['Y.js リアルタイム共同編集'],
  wireframeAscii: `┌──────────────────────────────────┐
│ 役員会  2026/05/13  13:00-14:30        │
├──────────────────────────────────┤
│ 議題1: 値上げ→決定:Yes→社長→6/1       │
│ 議題2: 採用増→保留:再検討→人事部→5/20 │
│ 議題3: A事業撤退→決定:No→-             │
└──────────────────────────────────┘`,
  cowan4Plus1Compliant: true,
  primarySurface: 'desktop',
  triggerKeywords: ['会議', '議事録', '意思決定ボード', 'アクションリスト'],
  componentName: 'DecisionBoard',
};

export const NARRATIVE_PL: UIPattern = {
  id: 'NARRATIVE_PL',
  name: 'Narrative PL Statement',
  jpName: 'ストーリーモードPL',
  pain: '数字の羅列だけでは結局どうなのか分からない',
  requiredData: ['構造化PL', 'LLM要約'],
  techStack: ['Claude API', '信頼度ラベル付与', 'BLUF文体'],
  wireframeAscii: `今月のPLハイライト (3行):
1. 売上 +5% (前月比) 最高。B社大口受注が牽引
2. 粗利率 42.1% (▼1.2pt)。原料高、価格転嫁50%完了
3. 営業利益 1.2億 (計画比+8%)。広告繰延が押上
[詳細PLは1タップ ▼]`,
  cowan4Plus1Compliant: true,
  primarySurface: 'mobile',
  triggerKeywords: ['PLサマリ', 'ナラティブ', '3行要約'],
  componentName: 'NarrativePL',
};

export const EXECUTIVE_WHITEBOARD: UIPattern = {
  id: 'EXECUTIVE_WHITEBOARD',
  name: 'Executive Whiteboard',
  jpName: '経営者ホワイトボード',
  pain: '移動中の思いつきが消える',
  requiredData: ['ボイスメモ', 'テキストメモ', '自動分類タグ'],
  techStack: ['Whisper音声認識', 'Claude分類', 'PWA'],
  wireframeAscii: `┌──────────────────────────────┐
│ 思いついたこと、入れて           │
│ [音声入力▶] [メモ📝]             │
├──────────────────────────────┤
│ 自動分類:                        │
│ ▸ 戦略アイデア(3)               │
│ ▸ 人事課題(2)                   │
│ ▸ 顧客フォロー(5)               │
└──────────────────────────────┘`,
  cowan4Plus1Compliant: true,
  primarySurface: 'mobile',
  triggerKeywords: ['メモ', 'ホワイトボード', '音声メモ', '思いつき'],
  componentName: 'ExecutiveWhiteboard',
};

export const YOMI_VIEW: UIPattern = {
  id: 'YOMI_VIEW',
  name: 'Yomi (Sales Forecast) View',
  jpName: 'ヨミ表ビュー',
  pain: '営業の主観確度を経営目線で見たい',
  requiredData: ['CRM案件', 'Aヨミ/Bヨミ/Cヨミ確度'],
  techStack: ['SFA連携', '確度モデル (A×1.0 + B×0.7 + C×0.3)'],
  wireframeAscii: `営業: 田中    今期目標: 5,000万
┌──────────────────────────────┐
│ Aヨミ(90%以上): 3,200万 ━━━━ 64% │
│ Bヨミ(60-89%): 1,100万 ━━     22% │
│ Cヨミ(30-59%):   400万 ━       8% │
│ ヨミ前:          800万 ━      16% │
├──────────────────────────────┤
│ A+B*0.7予測: 3,970万              │
│ 目標差: -1,030万                  │
└──────────────────────────────┘`,
  cowan4Plus1Compliant: true,
  primarySurface: 'desktop',
  triggerKeywords: ['ヨミ表', 'ヨミ', '営業確度', 'Aヨミ', 'Bヨミ', 'パイプライン'],
  componentName: 'YomiView',
};

export const MONTH_OPEN_COCKPIT: UIPattern = {
  id: 'MONTH_OPEN_COCKPIT',
  name: 'Month Open Cockpit',
  jpName: '月初コックピット',
  pain: '月が変わる瞬間、視座を切り替えたい',
  requiredData: ['前月確定', '今月計画', 'カレンダー重要日'],
  techStack: ['自動切替 (月初5日)', 'カレンダー統合'],
  wireframeAscii: `┌──────────────────────────────────┐
│ 2026年5月開始                          │
│                                        │
│ 先月確定: 売上1.8億, 営業利益1,540万    │
│ ✓計画達成 / ⚠粗利率1.2pt下落           │
│                                        │
│ 今月目標: 売上2.0億 (+12%)             │
│ 今月重要日:                            │
│  ・5/10 役員会                         │
│  ・5/15 取引先A社訪問                  │
│  ・5/31 月末締め                       │
└──────────────────────────────────┘`,
  cowan4Plus1Compliant: true,
  primarySurface: 'both',
  triggerKeywords: ['月初', '月次', 'コックピット', '月開始'],
  componentName: 'MonthOpenCockpit',
};

export const ANCHOR_COMPARISON: UIPattern = {
  id: 'ANCHOR_COMPARISON',
  name: 'Multi-Anchor Comparison',
  jpName: 'アンカー比較ビュー',
  pain: 'アンカリングを意識的に変えて見ないと判断が偏る',
  requiredData: ['自社実績', '競合実績', '業界平均'],
  techStack: ['切替タブ', 'ピン留め'],
  wireframeAscii: `売上 12月 vs 4月 vs 競合A
┌─────┬──────┬──────┬──────┐
│ 当社 │1.2億 │1.8億 │1.8億 │
│ 競合 │1.0億 │1.5億 │2.5億 │
│ 業界 │1.5億 │1.7億 │1.9億 │
└─────┴──────┴──────┴──────┘`,
  cowan4Plus1Compliant: true,
  primarySurface: 'desktop',
  triggerKeywords: ['アンカー', '比較', '競合比較'],
  componentName: 'AnchorComparison',
};

export const TRAFFIC_LIGHT_QUEUE: UIPattern = {
  id: 'TRAFFIC_LIGHT_QUEUE',
  name: 'Traffic Light Alert Queue',
  jpName: 'アラート信号機優先キュー',
  pain: '重大度を一目で見たい',
  requiredData: ['アラート', '重大度分類'],
  techStack: ['WebSocket Push', 'WebPush通知'],
  wireframeAscii: `🔴 即対応(3):
   ・C社解約意向SMS受信(2h前)
   ・支払不能企業の与信急落
   ・サーバ脆弱性CVE-2026-XXXX
🟡 今週中(5): ...
🟢 後で(12): ...`,
  cowan4Plus1Compliant: true,
  primarySurface: 'both',
  triggerKeywords: ['アラート', '信号機', '優先キュー', '緊急'],
  componentName: 'TrafficLightQueue',
};

export const MICRO_CARDS: UIPattern = {
  id: 'MICRO_CARDS',
  name: 'Micro Cards (Mobile)',
  jpName: 'マイクロカード (モバイル特化)',
  pain: '移動中に親指1本で全体を把握',
  requiredData: ['主要KPI 3-5'],
  techStack: ['PWA', 'スワイプジェスチャ', '4±1チャンク強制'],
  wireframeAscii: `┌──┐ ┌──┐ ┌──┐
│売上│ │利益│ │資金│
│1.8│ │15M │ │2.3│
│↑5%│ │→0%│ │↓1%│
└──┘ └──┘ └──┘
[スワイプで詳細]`,
  cowan4Plus1Compliant: true,
  primarySurface: 'mobile',
  triggerKeywords: ['モバイル', 'マイクロカード', 'カード'],
  componentName: 'MicroCards',
};

export const TRAFFIC_LIGHT_DISTRIBUTION: UIPattern = {
  id: 'TRAFFIC_LIGHT_DISTRIBUTION',
  name: 'Traffic Light Distribution',
  jpName: '領域別健全度分布',
  pain: '領域横断で「どこが弱いか」一目で',
  requiredData: ['領域別KPIスコア'],
  techStack: ['重み付け平均', '信号機マップ'],
  wireframeAscii: `領域別 健全度
営業    🟢🟢🟢🟢🟡  80%
財務    🟢🟢🟢🟡🟡  60%
人事    🟢🟡🟡🔴🔴  40% ←要対応
製造    🟢🟢🟢🟢🟢 100%`,
  cowan4Plus1Compliant: true,
  primarySurface: 'desktop',
  triggerKeywords: ['健全度', '領域別', 'スコアカード'],
  componentName: 'TrafficLightDistribution',
};

export const QUERY_SUGGEST: UIPattern = {
  id: 'QUERY_SUGGEST',
  name: 'Query Prompt Suggest',
  jpName: '質問プロンプトサジェスト',
  pain: '何を聞けば答えがあるか分からない',
  requiredData: ['過去のクエリ履歴', '文脈データ'],
  techStack: ['埋め込み検索', '利用頻度ランキング'],
  wireframeAscii: `[検索: 何でも聞いてください]
🔍 今聞かれることが多い質問:
  ・今月の利益どう?
  ・解約予兆顧客は?
  ・採用進捗は?
  [音声で聞く🎤]`,
  cowan4Plus1Compliant: true,
  primarySurface: 'both',
  triggerKeywords: ['サジェスト', '質問候補', 'プロンプト'],
  componentName: 'QuerySuggest',
};

export const NARRATIVE_TIMELINE: UIPattern = {
  id: 'NARRATIVE_TIMELINE',
  name: 'Narrative Timeline',
  jpName: 'ナラティブ・タイムライン',
  pain: 'その日に必要な準備が分散している',
  requiredData: ['カレンダー', '関連データ', '事前準備物'],
  techStack: ['AIエージェント先回り', 'カレンダー統合'],
  wireframeAscii: `[5/13] 朝
  06:00 ☕ Dawn Brief 確認
  09:00 📅 役員会
  13:00 🤝 A社訪問

  ▼自動下書き
  ・役員会用ハイライト 3点
  ・A社向け提案数値 直近版`,
  cowan4Plus1Compliant: true,
  primarySurface: 'both',
  triggerKeywords: ['タイムライン', '本日予定', '準備'],
  componentName: 'NarrativeTimeline',
};

export const BOARD_PACK_PDF: UIPattern = {
  id: 'BOARD_PACK_PDF',
  name: 'Board Pack PDF (SCQA)',
  jpName: 'ボードパックPDF (SCQA構造)',
  pain: '役員会資料が冗長',
  requiredData: ['SCQA要素', 'Pyramid Principle構造'],
  techStack: ['DOCXテンプレ→PDF', 'Pyramid Principle強制'],
  wireframeAscii: `[1ページ目: SCQA]
S: 今四半期売上1.8億
C: 業界全体は3%減
Q: なぜ我々は伸びたか?
A: 新製品Xが30%寄与

[2-5p: 根拠/打ち手/リスク/決議]`,
  cowan4Plus1Compliant: true,
  primarySurface: 'desktop',
  triggerKeywords: ['Board Pack', 'PDF', 'SCQA', '取締役会資料'],
  componentName: 'BoardPackPDF',
};

export const EXECUTIVE_CHAT: UIPattern = {
  id: 'EXECUTIVE_CHAT',
  name: 'Executive AI Co-Pilot Chat',
  jpName: '経営者プライベートチャネル',
  pain: '散在情報をひとつのチャットで完結',
  requiredData: ['全システム横断API', 'RAG'],
  techStack: ['Claude API', 'Function Calling', '信頼度ラベル', 'Hallucination Guard 12層'],
  wireframeAscii: `[経営者専用チャット]
🤖 おはようございます。今朝の異常検知3件です。
   1. 〇〇 [深掘る] [後で] [スルー]
   2. ...
[今日の予定をブリーフィング]
[資金繰り感応度を試算]`,
  cowan4Plus1Compliant: true,
  primarySurface: 'both',
  triggerKeywords: ['AI Co-Pilot', '経営者AI', 'チャット', 'アシスタント'],
  componentName: 'ExecutiveChat',
};

export const ALL_UI_PATTERNS: Record<UIPatternId, UIPattern> = {
  DAWN_BRIEF, WHAT_IF_SLIDER, EISENHOWER_MATRIX, YOY_OVERLAY,
  DECISION_JOURNAL, ONE_TAP_APPROVAL, BOARD_DECK_AUTOGEN,
  DECISION_BOARD, NARRATIVE_PL, EXECUTIVE_WHITEBOARD,
  YOMI_VIEW, MONTH_OPEN_COCKPIT, ANCHOR_COMPARISON,
  TRAFFIC_LIGHT_QUEUE, MICRO_CARDS, TRAFFIC_LIGHT_DISTRIBUTION,
  QUERY_SUGGEST, NARRATIVE_TIMELINE, BOARD_PACK_PDF, EXECUTIVE_CHAT,
};

export function selectUIPatterns(prompt: string): UIPattern[] {
  const text = prompt.toLowerCase();
  return Object.values(ALL_UI_PATTERNS).filter((p) =>
    p.triggerKeywords.some((k) => text.includes(k.toLowerCase()))
  );
}

/**
 * Cowan 4±1チャンク検証: 1画面のKPIが5枚以下か
 */
export function validateChunkLimit(kpiCount: number): { valid: boolean; reason: string } {
  if (kpiCount > 5) {
    return {
      valid: false,
      reason: `Cowan 4±1 違反: KPI ${kpiCount}枚は短期記憶限界を超える。5枚以下に絞ること。`,
    };
  }
  return { valid: true, reason: 'OK' };
}
