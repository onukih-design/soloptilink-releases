/**
 * SoloptiLinkAI v2033.0 — C-Suite Role DNA
 * Phase 45 Executive Cognitive Layer
 *
 * 9 C-Suite ロールごとに「朝のダッシュボード」「意思決定サイクル」「メンタルモデル」
 * 「失敗パターン」「経営会議で問う代表質問」「使うフレームワーク」「認知バイアス」を構造化。
 *
 * BOOST生成時、ターゲット利用者ロールを選択すると本Profileがプロンプト先頭に注入され、
 * UI/レポート/KPI設計が当該ロールのメンタルモデルに即して最適化される。
 */

export type CSuiteRole =
  | 'CEO' | 'CFO' | 'COO' | 'CTO' | 'CHRO' | 'CMO' | 'CSO' | 'CRO' | 'CISO';

export interface CognitiveBias {
  name: string;
  example: string;
  detector: string;
}

export interface CSuiteProfile {
  role: CSuiteRole;
  jpTitle: string;
  accountability: string[];
  primaryKPIs: string[];
  morningDashboard: string[];
  weeklyDecisions: string[];
  monthlyDecisions: string[];
  quarterlyDecisions: string[];
  mentalModels: string[];
  failurePatterns: string[];
  boardQuestions: string[];
  frameworks: string[];
  cognitiveBiases: CognitiveBias[];
}

export const CEO_PROFILE: CSuiteProfile = {
  role: 'CEO',
  jpTitle: '最高経営責任者',
  accountability: ['企業価値 (時価総額/PBR/ROIC)', '中期経営計画達成', '事業ポートフォリオ', '資本配分', '後継者計画'],
  primaryKPIs: ['売上成長率YoY', '営業利益率', 'ROIC', 'ROE', 'PBR', 'NPS', '従業員エンゲージメント'],
  morningDashboard: [
    '前日売上 vs 予算/前年',
    '受注残高 (Backlog)',
    '資金残高 + 短期キャッシュフロー予測',
    '重要顧客の動き (リスク顧客のアラート)',
    '競合ニュース / 業界ヘッドライン',
  ],
  weeklyDecisions: ['経営会議で四半期見込みを確定', '重要案件の Go/No-Go', '幹部 1on1'],
  monthlyDecisions: ['月次業績レビュー', '予算修正', '投資案件の最終承認', '幹部評価フィードバック'],
  quarterlyDecisions: ['取締役会報告', '業績修正発表', '事業ポートフォリオ見直し', '中計進捗レビュー'],
  mentalModels: [
    '3年先のキャッシュ',
    '自分が死んでも会社が回る仕組み',
    '攻めと守りの両利き',
    '30%ルール (1/3は今、1/3は来年、1/3は3年後)',
    'バックキャスト思考 (5-10年後の理想像から逆算)',
  ],
  failurePatterns: [
    '既存事業への固執 (東芝WH/シャープ亀山)',
    'コンコルド効果 (撤退判断の遅れ)',
    '任期内に名を残したい衝動買収',
    'イノベーションのジレンマ (コダック)',
    '同族経営の路線対立 (大塚家具)',
  ],
  boardQuestions: [
    'なぜこの数字が悪いのか? 構造的か一過性か?',
    'このまま3年続けると会社はどうなる?',
    '競合は同じ動きをしているか?',
    'やめる勇気は持てるか? 何を捨てるか?',
    'お客様は今、何に困っているか? (一次情報か?)',
    'このKPIは結果か先行指標か?',
    'もし自分が新任CEOだったら何を一番に変えるか?',
    'この投資のIRRは? Plan B は何か?',
    '退任日にどう評価されたいか?',
    'これを社員が誇りに思うか?',
  ],
  frameworks: ['McKinsey 7S', 'Balanced Scorecard', '両利きの経営', 'Mission-Vision-Values', 'Hoshin Kanri'],
  cognitiveBiases: [
    { name: 'サンクコスト', example: '東芝WH 9000億円超純損失', detector: '既投入額を非表示にして将来価値のみで判断' },
    { name: 'オーバーコンフィデンス', example: '十分な調査なく数十億円投資', detector: '失敗確率必須入力' },
    { name: '確証バイアス', example: '自社戦略を支持する情報のみ収集', detector: '反証データを1ページ目に表示' },
    { name: '正常性バイアス', example: '大丈夫、想定範囲内', detector: '閾値超過時にハイライト' },
    { name: 'ハロー効果', example: '過去成功者の意見を全面採用', detector: '評価項目を独立採点に分割' },
  ],
};

export const CFO_PROFILE: CSuiteProfile = {
  role: 'CFO',
  jpTitle: '最高財務責任者',
  accountability: ['財務報告', '資金調達/資本構成', 'M&A', 'IR', '予算管理', '内部統制 (J-SOX)', '税務'],
  primaryKPIs: ['営業CF', 'FCF', 'DEレシオ', 'ROIC', 'DSO/DIO/DPO (CCC)', 'WACC', 'EVA', 'EBITDA Margin'],
  morningDashboard: [
    '前日資金残高 + 30/60/90日キャッシュ予測',
    '売掛回収状況 (滞留)',
    '為替/金利の変動',
    '予実差異TOP5 (科目別)',
    'コミットメントライン残高',
  ],
  weeklyDecisions: ['資金繰り承認', '支払サイト・与信判断', '予実差異の早期警告'],
  monthlyDecisions: ['月次決算締め', '予算修正', '投資案件NPV/IRRレビュー', '銀行/監査法人MTG'],
  quarterlyDecisions: ['決算開示', '業績予想修正', '配当方針', 'コミットメントライン更新'],
  mentalModels: [
    '資金ショート3ヶ月前',
    '黒字倒産は実在する',
    'PLは意見、CFは事実',
    '翻訳機能 — 戦略と財務指標を現場のコントロール可能な先行指標にブレイクダウン',
    '会計は事業の通訳者',
  ],
  failurePatterns: [
    '利益至上の経営圧力で不正会計 (東芝チャレンジ)',
    '過剰借入と財務硬直化 (シャープ)',
    '税務偏重で経営ナビゲートが弱い',
    'データ品質低くKPIが意思決定に使えない',
    '資金繰り見落としによる黒字倒産',
  ],
  boardQuestions: [
    'このプロジェクトのIRRと回収期間は?',
    '営業利益とCFの差はなぜ生じている?',
    'CCCが前年同月から何日悪化した? 原因は?',
    '借入余力 (コミットメントライン残) はいくら?',
    'もし売上が20%減ったら何ヶ月持つ?',
    'のれん減損リスクは? Trigger Event は?',
    'このKPIは経営判断にどう使われる?',
    '監査法人/銀行から指摘された点で最も重要なのは?',
    '連結ベースで見ると数字は変わるか?',
    '為替/金利変動で年間損益どれだけ動く?',
  ],
  frameworks: ['ROICツリー (デュポン分解)', 'CCC', 'EVA', 'WACC-IRR Spread', '3財務諸表連動モデル'],
  cognitiveBiases: [
    { name: 'アンカリング', example: '前年予算ベースで来期を組む', detector: 'ゼロベース予算シナリオを並列表示' },
    { name: '確認バイアス', example: '自分の予算を支持する数字だけ見る', detector: '計画と実態の乖離を強制可視化' },
    { name: '楽観バイアス', example: '提案計画が楽観的すぎる', detector: 'Pre-mortem「3年後失敗していたら理由は?」自動質問' },
    { name: '集団思考', example: '監査法人/銀行に都合のいい説明のみ', detector: '異論を匿名収集' },
    { name: 'サンクコスト', example: '減損計上を先延ばし', detector: 'Trigger Event 自動判定' },
  ],
};

export const COO_PROFILE: CSuiteProfile = {
  role: 'COO',
  jpTitle: '最高執行責任者',
  accountability: ['事業実行', 'オペレーション最適化', 'ボトルネック解消', '現場の数字'],
  primaryKPIs: ['GP率', '在庫回転', 'リードタイム', '稼働率', '歩留り', 'ボトルネック工程のスループット', 'OEE'],
  morningDashboard: [
    '前日生産/出荷実績 vs 計画',
    'ボトルネック工程の滞留',
    '顧客クレーム/品質異常',
    '労務 (時間外/欠勤/有給消化)',
    '在庫水準 (過剰/不足)',
  ],
  weeklyDecisions: ['生産計画調整', '現場改善承認', '重要顧客のオペレーション課題対応'],
  monthlyDecisions: ['月次オペレーションレビュー', 'どこで流れが詰まっているかを見抜く', '改善PJの優先順位'],
  quarterlyDecisions: ['事業ポートフォリオでのリソース再配置', '中計と現場KPIの整合'],
  mentalModels: [
    'ボトルネック工程がスループットを決める (TOC理論)',
    'フロー × 品質 × 原価 × キャッシュの全体最適',
    'どこで流れが詰まっているか',
    '制約をなくせば隣の制約が顕在化する (5段階集中プロセス)',
  ],
  failurePatterns: [
    '部分最適 (ボトルネック以外を頑張る)',
    '稼働率KPIで在庫が膨らむ',
    '改善活動が一過性で持続しない',
    '現場が報告する数字が信用できない',
    '属人化された業務でリーダー異動で破綻',
  ],
  boardQuestions: [
    'ボトルネックは今どこ?',
    'リードタイムを30%短縮すると何が変わる?',
    '品質不良率が改善した本当の理由は?',
    '在庫はどの工程に何日分滞留しているか?',
    'なぜこの納期遅延が起きた?',
    '重要顧客の声で、現場が動いた事例は?',
    '標準作業からの逸脱はどれだけある?',
    'このKPIは誰がコントロール可能?',
    '改善提案件数は何件あり、何件承認した?',
    '安全 (休業災害度数率) は前年比でどう?',
  ],
  frameworks: ['TOC (制約理論)', 'Lean / Toyota Production System', 'Six Sigma DMAIC', 'バリューチェーン', 'OEE'],
  cognitiveBiases: [
    { name: 'アンカリング', example: '過去の標準時間に固執', detector: '工程ベンチマーク強制比較' },
    { name: '正常性バイアス', example: '予想外データを正常範囲と判断', detector: '異常値即時アラート' },
    { name: '代表性ヒューリスティック', example: '1工場の事例を全社展開', detector: 'サンプルサイズ表示' },
    { name: '後知恵バイアス', example: '結果を見てから予測できたと言う', detector: '判断ログ保存' },
    { name: '権威バイアス', example: '現場の声より本社指示を優先', detector: '匿名フィードバック収集' },
  ],
};

export const CTO_PROFILE: CSuiteProfile = {
  role: 'CTO',
  jpTitle: '最高技術責任者',
  accountability: ['技術戦略', '技術選定', 'エンジニア組織', '技術的負債', '情報システム', '技術R&D'],
  primaryKPIs: ['デプロイ頻度', 'MTTR', 'Change Failure Rate', 'Lead Time for Changes (DORA Four Keys)', '稼働率/SLO', 'エンジニア離職率'],
  morningDashboard: [
    '本番障害 + アラート',
    'デプロイ状況',
    'セキュリティ脅威 (CVE)',
    'クラウドコスト',
    '技術的負債バーンダウン',
  ],
  weeklyDecisions: ['技術選定の最終決裁', 'アーキテクチャレビュー', '重要バグ対応の優先順位'],
  monthlyDecisions: ['エンジニアリングKPIレビュー', '予算/リソース配分', '採用面接'],
  quarterlyDecisions: ['技術戦略の見直し', '新技術評価', '技術組織体制'],
  mentalModels: [
    'コードは負債、サービスはもっと負債',
    '両利き — 既存システム保守 × 新技術探索',
    '経営戦略と技術戦略は不可分',
    'Done is better than perfect',
    '技術選定は経営判断 (10年のロックインを生む)',
  ],
  failurePatterns: [
    'マイクロサービス過信 (GitHub前CTO Jason Warner: 過去10年最大の間違いの1つ)',
    '新技術への流行追従で技術的負債が膨張',
    'エンジニア離職 (評価制度不透明)',
    'セキュリティ後付けでインシデント発生',
    'オンプレ/クラウド選択を経営判断と分離してコスト暴騰',
  ],
  boardQuestions: [
    'このアーキテクチャは10年もつか?',
    '技術的負債の利息は年間いくら?',
    '我々の競争優位の源泉は技術か?',
    'デプロイ失敗率は前期比でどう?',
    '障害復旧時間 (MTTR) を10倍短くするには?',
    'エンジニアの満足度 (eNPS) は?',
    'このベンダーロックインを脱却する手段は?',
    'AI 導入で代替できる業務はどれか?',
    'オープンソースリスク (ライセンス・脆弱性) は?',
    '新規プロダクトの PoC を3ヶ月で出せるか?',
  ],
  frameworks: ['DORA Four Keys', 'SPACE Framework', 'モジュラモノリス', 'Hexagonal Architecture', 'ADR'],
  cognitiveBiases: [
    { name: 'NIH (Not-Invented-Here)', example: '自社開発に固執', detector: '外部ベンダー比較表強制' },
    { name: '流行追従', example: 'マイクロサービス/K8s/Web3', detector: '採用根拠を文書化要求' },
    { name: '過小評価バイアス', example: '移行コストを楽観視', detector: '過去類似PJ実績照会' },
    { name: '権威バイアス', example: 'スター技術者の意見を絶対視', detector: '匿名意見投票' },
    { name: 'サンクコスト', example: '失敗PJを切れない', detector: 'kill criteria 事前登録' },
  ],
};

export const CHRO_PROFILE: CSuiteProfile = {
  role: 'CHRO',
  jpTitle: '最高人事責任者',
  accountability: ['人材戦略', '採用/育成/評価/退職', '人的資本開示', '労務', 'ダイバーシティ', 'エンゲージメント'],
  primaryKPIs: ['離職率', 'eNPS / エンゲージメントスコア', '1人当たり売上/付加価値', '採用充足率', '女性管理職比率', '研修投資/人', '後継者層厚み'],
  morningDashboard: [
    '前日退職届',
    '重要採用の進捗',
    '労務インシデント (ハラスメント/残業)',
    'サーベイ異常値',
    '重要ポジションの空席リスク',
  ],
  weeklyDecisions: ['重要採用の最終承認', '労務トラブル対応'],
  monthlyDecisions: ['離職分析', '評価フィードバック品質チェック', '人件費レビュー'],
  quarterlyDecisions: ['人事制度改定', '人的資本開示数値', '後継者計画レビュー'],
  mentalModels: [
    '人材は資本 (コストではない)',
    '採用は将来5年の生産性を決める',
    '離職者の半分はマネージャーが原因',
    '人的資本開示は IR の延長',
    'エンゲージメントは先行指標、業績は遅行指標',
  ],
  failurePatterns: [
    '人事評価への不満で離職 (不満ある従業員62.3%、最大要因「評価基準不明確」45.2%)',
    'エンゲージメント低水準放置 (日本のエンゲージメント率7%、世界最低水準)',
    '管理職の4割が「評価が部下退職原因」と回答',
    '人事部出身のCHROで事業視点欠落',
    '採用ミスマッチで早期離職連鎖',
  ],
  boardQuestions: [
    '離職率は何%? 部署/職位別の偏りは?',
    'ハイパフォーマーの離職リスクは?',
    '採用1人あたりコストはいくら?',
    'エンゲージメントスコアの推移は?',
    '後継者計画 (Successor Plan) の充足は?',
    '評価制度は社員に納得感あるか?',
    '女性管理職比率の年次推移は?',
    '研修投資のROIを測れているか?',
    'ハラスメント相談件数の推移は?',
    '人的資本開示で投資家が最も気にする項目は?',
  ],
  frameworks: ['人的資本可視化指針 (内閣官房)', 'ISO 30414', '9 Box Grid (Performance × Potential)', 'タレントレビュー', 'EVP'],
  cognitiveBiases: [
    { name: 'ハロー効果', example: '1項目で全体評価を引き上げ/下げる', detector: '評価項目独立採点' },
    { name: '中央化傾向', example: '評価が3に集中', detector: '分布ヒストグラム強制' },
    { name: '対比効果', example: '直前評価対象との比較で歪む', detector: '評価順ランダム化' },
    { name: '類似性バイアス', example: '似た人を高評価', detector: '多様性チェック' },
    { name: '直近バイアス', example: '直近3ヶ月で通年評価', detector: '評価期間全体の証跡要求' },
  ],
};

export const CMO_PROFILE: CSuiteProfile = {
  role: 'CMO',
  jpTitle: '最高マーケティング責任者',
  accountability: ['ブランド', '需要創出', 'デマンドジェネレーション', '顧客理解', 'プロダクト/価格'],
  primaryKPIs: ['LTV', 'CAC', 'LTV/CAC', 'ROAS', 'MQL/SQL conversion', 'NPS', 'Brand awareness', 'Share of Voice', 'Repeat rate', 'Churn rate'],
  morningDashboard: [
    '前日リード/受注',
    '広告CPA/ROAS',
    'Web/SNS 流入',
    '競合の動き',
    '顧客の声 (口コミ/レビュー)',
  ],
  weeklyDecisions: ['キャンペーン Go/No-Go', '予算配分調整'],
  monthlyDecisions: ['マーケファネル分析', 'Win/Loss分析', '予算/ROAS最適化'],
  quarterlyDecisions: ['ブランド戦略', '新製品ローンチ', '顧客セグメント見直し'],
  mentalModels: [
    'LTV/CAC > 3 が事業の健全性',
    '広告は需要を喚起しない、想起を獲得する',
    'ブランドは長期、ダイレクト広告は短期',
    '顧客は3人称で語らない (一次情報を取れ)',
    '事業全体の設計者であれ',
  ],
  failurePatterns: [
    '指名検索の縮小 (ROAS低い広告停止→指名検索減・売上縮小)',
    '新規獲得偏重で収益悪化',
    '計測/LP/条件/粗利のどこかが崩れているのを管理画面ROASだけで判断',
    'ブランド毀損 (低価格転換 — 大塚家具)',
    'CMOが消える日 (旧来型広告偏重)',
  ],
  boardQuestions: [
    'このセグメントの LTV はいくら?',
    'CAC 回収期間は何ヶ月?',
    'オーガニック流入比率の推移は?',
    'NPSの推進者 vs 批判者の声で何が違う?',
    'このキャンペーンが無くなったら売上はどう変わる?',
    'ブランド想起率の推移は?',
    '競合の値下げに追随すべきか?',
    '新規 vs リピートの売上構成は?',
    'このメッセージは顧客の言葉になっているか?',
    '5年後この顧客は何にお金を使う?',
  ],
  frameworks: ['STP', '4P/4C', 'AARRR (Pirate Metrics)', 'Jobs-to-be-Done', 'AIDA/AISAS'],
  cognitiveBiases: [
    { name: '生存者バイアス', example: '既存顧客の声だけで判断', detector: '非顧客リサーチ強制' },
    { name: 'アンカリング', example: '初期広告予算が基準化', detector: 'ゼロベース予算シナリオ' },
    { name: '流行追従', example: 'バズるが定着しない施策', detector: '定着率KPI要求' },
    { name: '確認バイアス', example: '自分の戦略を支持するKPIのみ見る', detector: '反証データ表示' },
    { name: '平均値の誤謬', example: '平均LTVで判断', detector: '分布ヒストグラム表示' },
  ],
};

export const CSO_PROFILE: CSuiteProfile = {
  role: 'CSO',
  jpTitle: '最高戦略責任者',
  accountability: ['中長期戦略', 'M&A', '事業ポートフォリオ', '新規事業', '販売目標達成 (営業兼用時)'],
  primaryKPIs: ['新規事業売上構成比', 'M&A後シナジー実現率', '中計KPI達成率', '受注額/受注確度', '営業生産性'],
  morningDashboard: [
    '市場動向 (業界ニュース)',
    'M&A候補のシグナル',
    '新規事業 PoC 進捗',
    '競合の戦略動向',
    'パイプライン金額・確度',
  ],
  weeklyDecisions: ['戦略案件 Go/No-Go', 'M&A デューデリ進捗', '営業大型商談承認'],
  monthlyDecisions: ['事業ポートフォリオレビュー', '中計KPI進捗', '競合インテリジェンス更新'],
  quarterlyDecisions: ['中計修正', '新規参入/撤退判断', 'M&A候補絞り込み'],
  mentalModels: [
    '現在のマネジメントではなく中長期に焦点',
    '戦略立案だけでなく実行責任',
    'CEOのブレーキ役にもなる',
    'KGI/KPIを定義する権限',
    '全社横断 — どこかの事業部に従属しない',
  ],
  failurePatterns: [
    '戦略のパワポ止まり (実行責任を負わず空中戦)',
    'M&A 後シナジー未実現',
    '撤退判断遅延 (サンクコスト)',
    '新規事業を既存事業の論理で潰す',
    '競合に対する見立てを誤る',
  ],
  boardQuestions: [
    '3年後にこの事業ポートフォリオはどう変わるべきか?',
    'やめる事業は何か? なぜ続けているか?',
    'このM&Aはどんなシナジーで何年で投資回収する?',
    '競合が今動いている本当の意図は?',
    'もし日本市場が10%縮小したら何を変える?',
    'このKPIは中期計画とどう繋がる?',
    '新規事業の判断軸 (Stage Gate) は何か?',
    '撤退基準 (kill criteria) を予め決めているか?',
    '海外進出と国内深耕どちらに投資する?',
    'このパイプラインで来Q受注額確度は?',
  ],
  frameworks: ['ポーターの5フォース', '3C分析', 'PEST/PESTEL', 'VRIO', 'BCG マトリクス', 'Blue Ocean Strategy'],
  cognitiveBiases: [
    { name: '戦略のお祭り化', example: '計画作りが目的化', detector: '実行KPI と紐付け強制' },
    { name: '平均回帰の見落とし', example: '単年好業績を実力と勘違い', detector: '3年平均必須' },
    { name: 'アンカリング', example: '過去中計が基準', detector: 'ゼロベース戦略シナリオ' },
    { name: '確認バイアス', example: '仮説を支持する情報のみ', detector: '反証Pre-mortem実施' },
    { name: '代表性ヒューリスティック', example: '1事例で全体を判断', detector: 'サンプル数明示' },
  ],
};

export const CRO_PROFILE: CSuiteProfile = {
  role: 'CRO',
  jpTitle: '最高リスク責任者',
  accountability: ['全社リスク統合管理 (ERM)', 'リスクアペタイト', '危機管理', 'コンプライアンス連携', 'BCP'],
  primaryKPIs: ['重要リスク件数', '残余リスク水準', 'コンプライアンス違反件数', '監査指摘事項解消率', 'BCP訓練実施率'],
  morningDashboard: [
    '前日インシデント (品質/労務/サイバー/コンプラ)',
    '為替/金利/原材料の急変',
    '規制変更ニュース',
    '訴訟/紛争状況',
    '重要顧客の信用度',
  ],
  weeklyDecisions: ['重大リスクのエスカレーション', '新規事業のリスクアセスメント'],
  monthlyDecisions: ['リスクマップ更新', '重要リスク委員会', '監査指摘へのフォロー'],
  quarterlyDecisions: ['ERM レビュー', 'リスクアペタイト見直し', 'BCP訓練'],
  mentalModels: [
    'CEOのブレーキ役',
    'リスクは取らないこと自体が最大のリスク',
    'ERMは全社横断 — 部門最適のリスク管理は失敗する',
    'リスクとリターンの両方を見る統合者',
    'Trusted Advisor',
  ],
  failurePatterns: [
    'リスク部門が孤立 (戦略と分離)',
    '重要リスクの認識ずれ (CROと取締役会の認識ギャップ EY調査: 顧客需要変化 CRO 62% vs 取締役 48%)',
    '不正検知遅延 (強い権限の経営者の不正は検知困難)',
    '規制対応の後追い',
    'BCP 訓練が形式化',
  ],
  boardQuestions: [
    '我々のトップ5リスクは? 前期から変動したか?',
    'このリスクのリスクオーナーは誰か?',
    '残余リスクは許容範囲か?',
    '重大インシデント発生時の最大損失額は?',
    '危機管理シナリオ訓練の最新は?',
    'ベンダー/サプライチェーンの集中リスクは?',
    '監査指摘で未解消はどれだけ?',
    '内部通報件数の推移とフォロー状況は?',
    '法令改正で新たに生じたリスクは?',
    '経営層自身のリスク (経営者交代/不正) は?',
  ],
  frameworks: ['COSO ERM', 'ISO 31000', 'BowTie 分析', 'リスクヒートマップ', 'シナリオ分析'],
  cognitiveBiases: [
    { name: '正常性バイアス', example: '想定範囲内で見逃す', detector: '異常値即時アラート' },
    { name: '後知恵バイアス', example: '事後に予測できたと判断', detector: '判断時点の根拠を保存' },
    { name: '入手可能性ヒューリスティック', example: '直近の事件のリスクだけ高く評価', detector: '長期ベースレート表示' },
    { name: '集団思考', example: '監査委員会との合意形成優先', detector: '異論ロール強制割当' },
    { name: '自己奉仕バイアス', example: '自部門の責任回避', detector: '責任所在明示要求' },
  ],
};

export const CISO_PROFILE: CSuiteProfile = {
  role: 'CISO',
  jpTitle: '最高情報セキュリティ責任者',
  accountability: ['情報セキュリティ戦略', 'インシデント対応', 'ポリシー', 'SOC/CSIRT 統括', '教育'],
  primaryKPIs: ['MTTD/MTTR', '重大インシデント件数', '脆弱性対応SLA達成率', '教育受講率', '監査指摘解消率', 'サイバー保険適用範囲'],
  morningDashboard: [
    '前夜の SOC アラート',
    '未パッチの重大脆弱性件数',
    'サプライチェーン関連のサイバーニュース',
    '重要システムの稼働状況',
    'フィッシング検知数',
  ],
  weeklyDecisions: ['インシデント対応の最終判断', '重大脆弱性の優先対応'],
  monthlyDecisions: ['セキュリティKPIレビュー', '教育/訓練', 'ベンダー監査'],
  quarterlyDecisions: ['セキュリティ戦略改定', '経営報告', 'サイバー保険更新'],
  mentalModels: [
    '100% 防御は不可能、検知と復旧で勝負',
    '人がいちばん弱い、教育がいちばん効く',
    '平時の演習が有事の質を決める',
    '経営層への翻訳者 — 技術用語をビジネスリスクに変換',
    'インシデント対応はCSIRTが、説明はCISOが',
  ],
  failurePatterns: [
    'CIO 兼任で技術側に偏る',
    'インシデント説明責任の準備不足',
    '教育/訓練の形骸化',
    '脆弱性対応SLAの未管理',
    'サプライチェーン経由の攻撃を見落とし',
  ],
  boardQuestions: [
    'このインシデントの「最悪シナリオ」は何か?',
    'MTTR は前期比でどう?',
    '未パッチの重大脆弱性は何件 / 何日経過?',
    'もし顧客データ全件流出したら? 訓練済か?',
    'サプライチェーンで最も脆弱な事業者は?',
    '経営層のメールフィッシング訓練受講率は?',
    'ランサムウェア対策のバックアップは復元検証済か?',
    'インシデント発生時の広報原稿は準備済か?',
    'サイバー保険の補償範囲は?',
    '監督官庁/JPCERTへの報告フローは?',
  ],
  frameworks: ['NIST CSF 2.0', 'MITRE ATT&CK', 'ISO 27001/27002', 'CIS Controls', 'Zero Trust (NIST SP 800-207)'],
  cognitiveBiases: [
    { name: '正常性バイアス', example: 'うちは狙われない', detector: '業界別攻撃統計表示' },
    { name: 'アンカリング', example: '過去予算に縛られる', detector: 'リスクベース予算試算' },
    { name: '過信', example: '対策済だから安全', detector: 'Red Team 結果常時提示' },
    { name: '入手可能性ヒューリスティック', example: '最近の事件のみ警戒', detector: 'MITRE ATT&CK 全カバー' },
    { name: '集団思考', example: 'ベンダーの言いなり', detector: '第三者監査必須' },
  ],
};

export const CSUITE_PROFILES: Record<CSuiteRole, CSuiteProfile> = {
  CEO: CEO_PROFILE,
  CFO: CFO_PROFILE,
  COO: COO_PROFILE,
  CTO: CTO_PROFILE,
  CHRO: CHRO_PROFILE,
  CMO: CMO_PROFILE,
  CSO: CSO_PROFILE,
  CRO: CRO_PROFILE,
  CISO: CISO_PROFILE,
};

/**
 * ロール推論: ユーザー指示文から関連 C-Suite ロールを推定
 */
export function inferRolesFromPrompt(prompt: string): CSuiteRole[] {
  const text = prompt.toLowerCase();
  const roles: CSuiteRole[] = [];

  const patterns: Record<CSuiteRole, RegExp> = {
    CEO: /ceo|社長|代表|経営者|中期経営計画|事業ポートフォリオ/,
    CFO: /cfo|財務|資金繰り|資金調達|ir|投資家|決算|予算|キャッシュフロー|runway|dscr|ccc/,
    COO: /coo|執行|オペレーション|ボトルネック|工程|現場|生産|稼働率|oee/,
    CTO: /cto|技術|アーキテクチャ|エンジニア|デプロイ|sre|技術的負債/,
    CHRO: /chro|人事|採用|離職|エンゲージメント|評価|報酬|人的資本/,
    CMO: /cmo|マーケ|広告|ブランド|ltv|cac|roas|npr|ファネル/,
    CSO: /cso|戦略|m&a|新規事業|事業開発|パイプライン|営業/,
    CRO: /cro|リスク|erm|bcp|コンプラ|内部統制|危機管理/,
    CISO: /ciso|セキュリティ|脆弱性|インシデント|csirt|ランサム|フィッシング/,
  };

  for (const [role, pattern] of Object.entries(patterns) as [CSuiteRole, RegExp][]) {
    if (pattern.test(text)) roles.push(role);
  }

  return roles.length > 0 ? roles : ['CEO']; // デフォルトCEO
}

/**
 * ロールの組み合わせから「朝のダッシュボード」統合5枚を生成
 * 4±1チャンク (Cowan) に従い 必ず 5枚以下に絞る
 */
export function composeMorningDashboard(roles: CSuiteRole[]): string[] {
  const merged = new Set<string>();
  for (const role of roles) {
    for (const item of CSUITE_PROFILES[role].morningDashboard) {
      merged.add(item);
    }
  }
  const arr = Array.from(merged);
  // 4±1 チャンクに従い5枚以下に絞る
  return arr.slice(0, 5);
}
