/**
 * SoloptiLinkAI v2033.0 — Executive Personal Risk JP
 * Phase 45 Executive Cognitive Layer
 *
 * 役員退職金 (功績倍率法) / 役員報酬 (定期同額/事前確定/業績連動) / 法人保険 /
 * 役員間利益相反 / 反社チェック / 経営者保証解除
 */

// ========== 役員退職金 (功績倍率法) ==========

export interface KoseiBaiInput {
  finalMonthlySalary: number; // 最終月額報酬
  tenureYears: number; // 在任年数
  koseiBai: number; // 功績倍率
}

export interface YakuinTaishokukinResult {
  amount: number;
  formula: string;
  koseiBaiBenchmark: { position: string; rate: string }[];
  taxTreatment: string;
  socialInsurance: string;
}

export const KOSEI_BAI_BENCHMARK = [
  { position: '代表取締役社長', rate: '3.0倍 (上限相場)' },
  { position: '専務取締役', rate: '2.4倍' },
  { position: '常務取締役', rate: '2.2倍' },
  { position: '取締役', rate: '1.8倍' },
  { position: '監査役', rate: '1.5倍' },
];

export function calculateYakuinTaishokukin(input: KoseiBaiInput): YakuinTaishokukinResult {
  const amount = input.finalMonthlySalary * input.tenureYears * input.koseiBai;
  return {
    amount,
    formula: `${input.finalMonthlySalary.toLocaleString()}円 × ${input.tenureYears}年 × ${input.koseiBai} = ${amount.toLocaleString()}円`,
    koseiBaiBenchmark: KOSEI_BAI_BENCHMARK,
    taxTreatment: '退職所得控除後 1/2課税 (在任20年で800万+(年数-20)×70万)',
    socialInsurance: '退職金には社保かからない (節税メリット大)',
  };
}

// ========== 役員報酬 3類型 ==========

export interface YakuinHoshu {
  type: '定期同額給与' | '事前確定届出給与' | '業績連動給与';
  description: string;
  taxRequirements: string[];
  bestFor: string[];
  pitfalls: string[];
}

export const YAKUIN_HOSHU_TYPES: YakuinHoshu[] = [
  {
    type: '定期同額給与',
    description: '毎月同額支給。期中変更不可 (原則)',
    taxRequirements: [
      '事業年度開始から3ヶ月以内に株主総会等で決議',
      '原則 期中増額不可 (業績悪化改定・通常改定は例外)',
    ],
    bestFor: ['一般的な役員報酬', '安定的な経営者'],
    pitfalls: ['期中増額で全額損金不算入リスク', '減額タイミング (4月)'],
  },
  {
    type: '事前確定届出給与',
    description: '所定時期に確定額を支給。賞与的位置付け',
    taxRequirements: [
      '株主総会決議+届出書提出 (期首から4ヶ月以内 or 株主総会決議から1ヶ月以内)',
      '届出通りに支給しないと全額損金不算入',
    ],
    bestFor: ['賞与的支給', '功労金'],
    pitfalls: ['1円でもズレると全額否認', '不支給は届出取下要'],
  },
  {
    type: '業績連動給与',
    description: '業績指標連動 (上場企業中心)',
    taxRequirements: [
      '上場会社等が対象',
      '報酬委員会の決定 + 有報開示',
      '客観的指標 (経常利益/ROE等)',
      '報酬限度額の決定',
    ],
    bestFor: ['上場企業役員', '長期インセンティブ'],
    pitfalls: ['設計が複雑', '非上場では適用不可'],
  },
];

// ========== 法人保険 (節税×保障×退職金準備) ==========

export interface CorporateInsurance {
  type: string;
  purpose: string;
  premiumDeductibility: string;
  payoutTreatment: string;
  bestFor: string[];
  cautions: string[];
}

export const CORPORATE_INSURANCE: CorporateInsurance[] = [
  {
    type: 'キーマン保険 (定期保険)',
    purpose: '経営者死亡時の事業継続資金 / 退職金準備',
    premiumDeductibility: '令和元年7月改正後: 解約返戻率により損金算入率変動 (最大40%損金/60%資産)',
    payoutTreatment: '保険金は雑収入、解約返戻金は受取時益金',
    bestFor: ['キーパーソン依存度高い中小', '退職金準備'],
    cautions: ['節税メリット縮小 (R元改正)', '解約タイミング戦略必要'],
  },
  {
    type: '逓増定期保険',
    purpose: '経営者退職金準備',
    premiumDeductibility: '解約返戻率に応じた損金算入',
    payoutTreatment: '解約返戻金で退職金原資',
    bestFor: ['退職時期確定の経営者'],
    cautions: ['R元改正で節税効果限定'],
  },
  {
    type: '長期平準定期保険',
    purpose: '長期保障 + 退職金準備',
    premiumDeductibility: '解約返戻率次第',
    payoutTreatment: '解約返戻金または保険金',
    bestFor: ['長期視野', '事業承継'],
    cautions: ['流動性低い'],
  },
  {
    type: 'D&O保険 (Directors and Officers)',
    purpose: '役員の対外賠償責任の補填',
    premiumDeductibility: '全額損金算入可',
    payoutTreatment: '賠償金充当',
    bestFor: ['全上場企業必須', '上場準備企業'],
    cautions: ['補償範囲確認 (CGC遵守義務違反等)'],
  },
];

// ========== 役員間 利益相反取引 ==========

export const ROLE_CONFLICT_TRANSACTIONS = {
  legalBasis: '会社法356条 (利益相反取引) + 民法108条 (自己取引)',
  triggerCases: [
    '役員が会社と直接取引',
    '役員所有不動産を会社に貸付',
    '役員個人会社との取引',
    '役員に対する金銭貸付',
    '会社が役員債務を保証',
  ],
  requiredProcedure: [
    '取締役会で重要な事実を開示',
    '取締役会の承認 (利害関係役員は議決権なし)',
    '取引後遅滞なく重要事実報告',
    '議事録に記録',
  ],
  consequenceOfViolation: [
    '取引無効 + 取締役の損害賠償責任',
    '監査役/会計監査人指摘',
    '上場企業は適時開示',
  ],
};

// ========== 反社チェック ==========

export const ANTISOCIAL_CHECK = {
  legalBasis: '暴力団排除条例 (各都道府県) / 暴対法 / 民法90条 (公序良俗)',
  steps: [
    {
      level: 'Level 1 (簡易)',
      method: 'インターネット検索 + 商業データベース (帝国データバンク等)',
      cost: '無料-1万円',
      coverage: '基本',
    },
    {
      level: 'Level 2 (eKYC)',
      method: 'eKYC + 反社チェックサービス (RoboRoboなど)',
      cost: '1社あたり500-3000円',
      coverage: 'スコアリング + 反社該当判定',
    },
    {
      level: 'Level 3 (弁護士会照会)',
      method: '弁護士会照会 (民事訴訟法上の調査嘱託準用)',
      cost: '5-20万円',
      coverage: '警察相談センター情報含む詳細調査',
    },
    {
      level: 'Level 4 (探偵調査)',
      method: '専門調査会社',
      cost: '20-100万円',
      coverage: '実地調査含む徹底調査',
    },
  ],
  contractClauseTemplate: [
    '反社会的勢力でないことの表明保証',
    '反社該当が判明した場合の解除権',
    '損害賠償義務',
    '違約金条項',
  ],
};

// ========== 経営者保証解除 ==========

export const KEIEISHA_HOSHO_KAIJO = {
  basis: '経営者保証ガイドライン R5改訂 (2023-04-01)',
  releaseConditions: [
    '法人と経営者の資産・経理が明確に区分',
    '法人と経営者の間の資金のやり取りが事業上必要な範囲',
    '財務基盤が強化されて法人のみの資産・収益力で借入返済可能',
    '金融機関に対し、適時適切に財務情報等が提供されている',
  ],
  triggersForRequest: [
    '事業承継時 (新経営者への切替時)',
    'M&A実行時 (買収後)',
    '一定の業績改善を達成した後',
    '通常の借換タイミング',
  ],
  alternatives: [
    '経営者保証なし融資制度 (信用保証協会 2024-)',
    '事業承継特別保証制度',
    '一定割合のみ保証 (部分保証)',
    'M&A後の保証解除特約',
  ],
  failureScenarioBenefits: [
    '残存資産: 99万円 + 華美でない自宅を残せる可能性',
    '保証債務の一部免除',
    '個人破産回避',
    '事業再挑戦への道',
  ],
};

/**
 * 役員報酬の損金算入要件チェック
 */
export function checkRoyalmuhoshuTaxCompliance(input: {
  type: '定期同額' | '事前確定' | '業績連動';
  withinPeriodDecision: boolean; // 期首3ヶ月内決議
  notifiedToTaxOffice?: boolean; // 事前確定届出書提出
  isListedCompany?: boolean;
  isPaidAsDeclared?: boolean; // 届出通り支給
}): { compliant: boolean; reasons: string[] } {
  const reasons: string[] = [];

  if (input.type === '定期同額') {
    if (!input.withinPeriodDecision) reasons.push('期首3ヶ月内決議要件未充足');
  }
  if (input.type === '事前確定') {
    if (!input.notifiedToTaxOffice) reasons.push('事前確定届出書未提出');
    if (input.isPaidAsDeclared === false) reasons.push('届出通り支給されていない (全額否認リスク)');
  }
  if (input.type === '業績連動') {
    if (!input.isListedCompany) reasons.push('業績連動給与は上場企業等のみ適用可');
  }

  return { compliant: reasons.length === 0, reasons };
}
