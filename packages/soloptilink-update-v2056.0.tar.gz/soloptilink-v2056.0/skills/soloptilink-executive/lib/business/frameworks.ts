/**
 * SoloptiLinkAI v2033.0 — Strategy Frameworks (40)
 * Phase 45 Executive Cognitive Layer
 *
 * 古典9 / モダン8 / 実行6 / 組織5 / 意思決定8 / 日本式3 / 補強1 = 40フレームワーク
 * 各 { name, category, purpose, whenToUse, inputs, outputs, antiPattern, jpAdapt }
 */

export type FrameworkCategory = 'classic' | 'modern' | 'execution' | 'organization' | 'decision' | 'jp_native';

export interface StrategyFramework {
  id: string;
  name: string;
  jpName: string;
  category: FrameworkCategory;
  purpose: string;
  whenToUse: string[];
  inputs: string[];
  outputs: string[];
  antiPattern: string;
  jpAdapt: string;
  triggerKeywords: string[];
}

// ========== 古典 (Classic Strategy) 9 ==========

const CLASSIC: StrategyFramework[] = [
  {
    id: 'F_SWOT', name: 'SWOT', jpName: 'SWOT分析', category: 'classic',
    purpose: '内部要因(S/W)と外部要因(O/T)で戦略の足場を作る',
    whenToUse: ['年度戦略策定', '新規事業初期', '競合参入時'],
    inputs: ['売上推移', '利益率', '市場成長率', '競合動向', '規制動向'],
    outputs: ['クロスSWOT (SO/ST/WO/WT)', '優先順位スコア'],
    antiPattern: '羅列で終わり戦略に落ちない。SWOT単独使用は失敗の典型',
    jpAdapt: '業種辞書58モジュールから外部脅威 (法改正/競合) を自動引込',
    triggerKeywords: ['SWOT', '強み弱み', '機会脅威'],
  },
  {
    id: 'F_5FORCE', name: '5 Forces', jpName: 'ファイブフォース分析', category: 'classic',
    purpose: '業界収益構造を5つの力で測定',
    whenToUse: ['新規参入判断', '撤退判断', '値決め根拠'],
    inputs: ['業界マルチプル', '業界粗利率', '顧客集中度', 'サプライヤ集中度', '代替品リスト'],
    outputs: ['業界収益性スコア(0-100)', '5力ヒートマップ', 'ボトルネック特定'],
    antiPattern: '静的分析で時間軸を入れない。AI/規制でforce反転を見落とす',
    jpAdapt: '受託SIなら下請法60日支払の売り手力を強制計上',
    triggerKeywords: ['5フォース', 'ファイブフォース', '5Force', 'Porter'],
  },
  {
    id: 'F_PEST', name: 'PEST', jpName: 'PEST分析', category: 'classic',
    purpose: 'Political/Economic/Social/Technologicalマクロ環境を整理',
    whenToUse: ['中期計画', '海外進出', '規制変化対応'],
    inputs: ['法改正一覧', 'GDP/金利/為替', '人口動態', '技術動向'],
    outputs: ['影響度×発生確率マトリクス', 'シナリオA/B/C'],
    antiPattern: '感想文化。インパクト数値化を怠る',
    jpAdapt: '法令DB116モジュールから自動でP/Sを抽出',
    triggerKeywords: ['PEST', 'PESTEL', 'マクロ環境'],
  },
  {
    id: 'F_3C', name: '3C', jpName: '3C分析', category: 'classic',
    purpose: 'Customer/Competitor/Companyで戦略整合性を担保',
    whenToUse: ['マーケ戦略', '新製品投入'],
    inputs: ['顧客セグメント', '競合価格表', '自社強み (VRIO結果)'],
    outputs: ['KSF (Key Success Factor)', '戦略ギャップ'],
    antiPattern: 'Customerをペルソナでなく属性で語る',
    jpAdapt: 'Tenant DNAから顧客発言録を自動引込',
    triggerKeywords: ['3C', '3C分析'],
  },
  {
    id: 'F_4P', name: '4P', jpName: 'マーケティングミックス 4P', category: 'classic',
    purpose: 'Product/Price/Place/Promotionで施策の網羅性チェック',
    whenToUse: ['新製品ローンチ', '値上げ判断', 'チャネル変更'],
    inputs: ['原価率', '競合価格', '販路リスト', '広告予算'],
    outputs: ['4P整合性スコア', 'ボトルネックP'],
    antiPattern: 'B2Bで4Pだけ。7P (+People/Process/Physical) に拡張すべき',
    jpAdapt: 'Place=日本商習慣(eseal/FAX OCR/年度始期4月)を考慮',
    triggerKeywords: ['4P', '7P', 'マーケミックス'],
  },
  {
    id: 'F_VRIO', name: 'VRIO', jpName: 'VRIO分析', category: 'classic',
    purpose: '経営資源が持続的競争優位の源泉になるかを4関門で検証',
    whenToUse: ['M&A評価', 'コア事業特定', '撤退候補絞り込み'],
    inputs: ['保有特許', '顧客LTV', '人材スキル', 'ブランド資産'],
    outputs: ['優位性ランク (競争劣位〜持続的優位)', 'リソース投資優先順位'],
    antiPattern: 'Organizationを過小評価。良い資源でも組織が活かせなければ無価値',
    jpAdapt: 'Tenant DNA命名規則ロック等の組織資産も評価対象',
    triggerKeywords: ['VRIO', '競争優位'],
  },
  {
    id: 'F_VALUE_CHAIN', name: 'Value Chain', jpName: 'バリューチェーン', category: 'classic',
    purpose: '主活動5+支援活動4の各工程で付加価値とコストを分解',
    whenToUse: ['原価低減', 'アウトソース判断', 'DX投資'],
    inputs: ['工程別原価', '工程別不良率', '工程別リードタイム'],
    outputs: ['価値創造ホットスポット', '削減候補'],
    antiPattern: 'サービス業に製造業VCを当てはめる',
    jpAdapt: 'SI受託版VC (提案→要件→設計→実装→テスト→運用) を内蔵',
    triggerKeywords: ['バリューチェーン', 'Value Chain'],
  },
  {
    id: 'F_BCG_PPM', name: 'BCG PPM', jpName: 'BCG プロダクトポートフォリオ', category: 'classic',
    purpose: '市場成長率×相対市場シェアで事業を4象限分類',
    whenToUse: ['複数事業の投資配分', '撤退候補特定'],
    inputs: ['事業別売上成長率', '事業別市場シェア', '事業別CF'],
    outputs: ['4象限マップ (花形/金のなる木/問題児/負け犬)', '資源再配分提案'],
    antiPattern: '市場定義を都合よく狭めて全部花形にする',
    jpAdapt: 'GEのビジネススクリーン9象限版も併設',
    triggerKeywords: ['BCG', 'PPM', 'ポートフォリオ'],
  },
  {
    id: 'F_GE', name: 'GE Matrix', jpName: 'GE/McKinseyビジネススクリーン', category: 'classic',
    purpose: '業界魅力度×事業強度の3x3=9象限',
    whenToUse: ['コングロマリット事業再編', '中期投資配分'],
    inputs: ['業界成長率/規模/収益性/競合数', 'シェア/品質/ブランド/流通'],
    outputs: ['投資/維持/収穫/撤退の4戦略マッピング'],
    antiPattern: '主観的スコアリングで恣意性が高い',
    jpAdapt: '業種辞書から業界魅力度の自動算出ロジックを提供',
    triggerKeywords: ['GEマトリクス', 'ビジネススクリーン'],
  },
];

// ========== モダン (Modern) 8 ==========

const MODERN: StrategyFramework[] = [
  {
    id: 'F_BLUE_OCEAN', name: 'Blue Ocean', jpName: 'ブルーオーシャン戦略', category: 'modern',
    purpose: '競争のない市場を ERRC で創出',
    whenToUse: ['コモディティ脱却', '新規参入', '差別化詰まり'],
    inputs: ['業界標準提供価値リスト', '顧客のpain', '非顧客リスト'],
    outputs: ['戦略キャンバス', 'ERRCグリッド', '新価値曲線'],
    antiPattern: 'Reduce/Eliminate抜きで Raise/Createだけやってコスト爆発',
    jpAdapt: '日本市場で「FAX前提だが本当に要るか」など Eliminate候補リスト内蔵',
    triggerKeywords: ['ブルーオーシャン', 'Blue Ocean', 'ERRC'],
  },
  {
    id: 'F_LEAN_CANVAS', name: 'Lean Canvas', jpName: 'リーンキャンバス', category: 'modern',
    purpose: '1枚A4で事業仮説 (Problem→Solution→UVP→KPI) を可視化',
    whenToUse: ['新規事業企画', 'ピボット判断', '投資家説明'],
    inputs: ['顧客課題仮説', 'MVPアイデア', '想定KPI'],
    outputs: ['9ブロックCanvas', 'リスク順位'],
    antiPattern: 'Solution先行で書く。Problem定義を雑にする',
    jpAdapt: 'JTBD的に「顧客がやとった仕事」を必ず1行書く欄を追加',
    triggerKeywords: ['Lean Canvas', 'リーンキャンバス'],
  },
  {
    id: 'F_BMC', name: 'BMC', jpName: 'ビジネスモデルキャンバス', category: 'modern',
    purpose: '9要素で事業構造化',
    whenToUse: ['既存事業可視化', 'M&A後統合', 'DX設計'],
    inputs: ['全顧客セグメント', '全販路', '全コスト構造'],
    outputs: ['BMC 9 box', '収益エンジン特定'],
    antiPattern: 'Lean Canvasとの混同。BMCは既存向け、Leanは新規向け',
    jpAdapt: 'Key Partners に商社・ベンダー・士業を必ず1枠',
    triggerKeywords: ['BMC', 'Business Model Canvas'],
  },
  {
    id: 'F_JTBD', name: 'JTBD', jpName: 'Jobs-to-be-Done', category: 'modern',
    purpose: '顧客は「仕事を片付けるためにプロダクトを雇う」視点で機能設計',
    whenToUse: ['新製品', '離反原因分析', '値上げ説明'],
    inputs: ['顧客インタビュー', '代替手段リスト', 'non-consumption'],
    outputs: ['Job Statement', '機能仕様', '対立プロダクトリスト'],
    antiPattern: '属性 (40代女性) でセグメント化してJTBDを取り違える',
    jpAdapt: 'Tenant DNA に顧客が口に出した「〇〇したい」を蓄積',
    triggerKeywords: ['JTBD', 'Jobs-to-be-Done'],
  },
  {
    id: 'F_DISRUPTION', name: 'Disruption', jpName: '破壊的イノベーション理論', category: 'modern',
    purpose: 'ローエンド破壊 vs 新市場破壊の2類型で既存崩壊を予測',
    whenToUse: ['脅威評価', '新規参入戦略'],
    inputs: ['既存製品の過剰品質度', 'non-consumption市場'],
    outputs: ['破壊シナリオ', '防御/攻撃戦略'],
    antiPattern: '全部Disruptionとラベル付けして思考停止',
    jpAdapt: 'Claude Code vs SoloptiLinkAI の自己分析にも適用',
    triggerKeywords: ['Disruption', '破壊的イノベーション'],
  },
  {
    id: 'F_CHASM', name: 'Crossing the Chasm', jpName: 'キャズム理論', category: 'modern',
    purpose: 'Early AdopterとEarly Majorityの間の溝を超える',
    whenToUse: ['B2B SaaSの年商1億→10億局面', 'シェア15%付近'],
    inputs: ['既存顧客の Innovator/Early Adopter比率', 'Reference Customer'],
    outputs: ['Beachhead戦略', 'Whole Product定義'],
    antiPattern: 'Early Adopter向けプロダクトのままMajorityに売る',
    jpAdapt: '日本市場は「事例信仰」が強くChasmが他国より深い',
    triggerKeywords: ['キャズム', 'Chasm'],
  },
  {
    id: 'F_PLAYING_TO_WIN', name: 'Playing to Win', jpName: 'プレイング・トゥ・ウィン', category: 'modern',
    purpose: '5問 (勝利の定義/Where/How/ケイパビリティ/システム) で戦略構築',
    whenToUse: ['全社戦略策定', 'M&A後の方向性策定'],
    inputs: ['顧客選択基準', 'コアケイパビリティ', '競合相対比較'],
    outputs: ['5問の答え', '戦略カスケード'],
    antiPattern: 'ビジョンや使命と混同する',
    jpAdapt: '日本SI: Where=日本/中堅/SIer受託, How=日本固有商習慣',
    triggerKeywords: ['Playing to Win'],
  },
  {
    id: 'F_AARRR', name: 'AARRR', jpName: 'パイレートメトリクス', category: 'modern',
    purpose: 'Acquisition/Activation/Retention/Revenue/Referralで成長戦略を分解',
    whenToUse: ['B2C/SaaSグロース戦略'],
    inputs: ['ファネル各ステージCVR', 'コホート別Retention'],
    outputs: ['最大ボトルネック特定', '施策優先順位'],
    antiPattern: 'Acquisition偏重で Activation/Retentionを見落とす',
    jpAdapt: 'AAARRR (Awareness追加6段) も併存。日本B2BではAwarenessが一番弱い',
    triggerKeywords: ['AARRR', 'パイレート'],
  },
];

// ========== 実行 (Execution) 6 ==========

const EXECUTION: StrategyFramework[] = [
  {
    id: 'F_OKR', name: 'OKR', jpName: 'OKR (Objectives & Key Results)', category: 'execution',
    purpose: '野心的Objective + 3-5個の測定可能KRを四半期サイクル',
    whenToUse: ['急成長フェーズ', '全社足並み揃え', '新組織立上げ'],
    inputs: ['年次戦略', '各部門のミッション'],
    outputs: ['四半期OKRツリー', '60-70%達成基準'],
    antiPattern: 'KPIと混同して100%達成を目指す。Stretch goalにならない',
    jpAdapt: '日本企業は60-70%目標に心理的抵抗。最初は80%基準で運用開始を許容',
    triggerKeywords: ['OKR', 'Objectives Key Results'],
  },
  {
    id: 'F_KPI_TREE', name: 'KPI Tree', jpName: 'KPIツリー', category: 'execution',
    purpose: 'KGIを構成要素に分解しドライバー指標を明確化',
    whenToUse: ['KPI設計初期', '改善施策の優先順位付け'],
    inputs: ['KGI数式', '事業構造', 'コスト構造'],
    outputs: ['階層化ツリー', '感度分析'],
    antiPattern: 'ツリーが偏微分で繋がっておらず単なる箇条書きになる',
    jpAdapt: 'ECならGMV=訪問×CVR×AOV、SaaSならARR=新規+拡張-Churn',
    triggerKeywords: ['KPIツリー', 'KPI Tree'],
  },
  {
    id: 'F_BSC', name: 'BSC', jpName: 'バランススコアカード', category: 'execution',
    purpose: '財務/顧客/業務プロセス/学習成長の4視点でKPIを均衡配置',
    whenToUse: ['中期戦略策定', '短期利益偏重の是正'],
    inputs: ['財務KPI', '顧客満足', '業務効率', '人材育成'],
    outputs: ['戦略マップ', '4視点スコアカード'],
    antiPattern: '4視点のKPIが因果連鎖していない',
    jpAdapt: '日本企業は学習成長視点を軽視傾向。AI/データリテラシ指標を強制配置',
    triggerKeywords: ['BSC', 'バランススコアカード', 'Balanced Scorecard'],
  },
  {
    id: 'F_HOSHIN', name: 'Hoshin Kanri', jpName: '方針管理 (トヨタ式)', category: 'execution',
    purpose: '中期重点方針→年度方針→部門方針→個人方針 をキャッチボールで連鎖',
    whenToUse: ['日本製造業', '業績悪化からの立て直し'],
    inputs: ['長期ビジョン', '現場の課題', 'PDCA記録'],
    outputs: ['X-matrix', '年度方針書', '中間レビュー'],
    antiPattern: '上意下達で押し付け。キャッチボールを省略',
    jpAdapt: '日本企業との親和性最高。OKRより導入抵抗低い',
    triggerKeywords: ['方針管理', 'Hoshin Kanri'],
  },
  {
    id: 'F_V2MOM', name: 'V2MOM', jpName: 'V2MOM (Salesforce)', category: 'execution',
    purpose: 'Visionから降ろし障害を明示する5段アライメント',
    whenToUse: ['急成長中の方向性ずれ補正', 'M&A後文化統合'],
    inputs: ['創業者ビジョン', '現場の阻害要因'],
    outputs: ['全社員V2MOM', '障害一覧'],
    antiPattern: 'Obstaclesを書かず楽観論で終わる',
    jpAdapt: '日本ではValues設計が弱いので強化必要',
    triggerKeywords: ['V2MOM'],
  },
  {
    id: 'F_NSM', name: 'North Star Metric', jpName: 'ノーススターメトリック', category: 'execution',
    purpose: 'プロダクトが顧客に提供する価値を1指標に集約',
    whenToUse: ['プロダクト主導成長', '急成長SaaS/EC'],
    inputs: ['全KPI候補', '顧客価値仮説'],
    outputs: ['NSM 1個', 'input metrics 3-5個'],
    antiPattern: '売上やDAUをNSMにする (価値ではなく結果)',
    jpAdapt: '受託SIなら「1案件あたり利益額」ではなく「顧客の年間DX投資ROI」',
    triggerKeywords: ['North Star Metric', 'NSM'],
  },
];

// ========== 組織 (Organization) 5 ==========

const ORGANIZATION: StrategyFramework[] = [
  {
    id: 'F_7S', name: '7S', jpName: 'マッキンゼー7S', category: 'organization',
    purpose: 'Strategy/Structure/System (ハード3S) + Skill/Staff/Style/Shared Values (ソフト4S) の整合性診断',
    whenToUse: ['組織変革', 'M&A後統合', '戦略実行不能の原因究明'],
    inputs: ['全7要素の現状ヒアリング', '目指す姿'],
    outputs: ['7Sギャップ表', '整合性スコア'],
    antiPattern: 'ハードだけ変えてソフトが追従しない。Shared Valuesが空欄',
    jpAdapt: '日本企業はソフト4S強くハード3S弱い傾向',
    triggerKeywords: ['7S', 'マッキンゼー7S'],
  },
  {
    id: 'F_SPOTIFY', name: 'Spotify Model', jpName: 'スポティファイモデル', category: 'organization',
    purpose: '自律的小チーム×横断専門コミュニティで大規模アジャイル',
    whenToUse: ['100人超エンジニア組織', 'プロダクト多数並走'],
    inputs: ['プロダクト数', 'エンジニア数', 'コアスキル分布'],
    outputs: ['Squad構成案', 'Chapter Lead配置'],
    antiPattern: '形だけ真似して権限委譲しない',
    jpAdapt: '中小SIerには重い。20人以下なら不要',
    triggerKeywords: ['Spotify Model', 'Squad', 'Tribe'],
  },
  {
    id: 'F_HOLACRACY', name: 'Holacracy', jpName: 'ホラクラシー', category: 'organization',
    purpose: '役職を廃しロールとサークルで自治',
    whenToUse: ['スタートアップ50人以下', 'イノベーション重視'],
    inputs: ['業務リスト', '意思決定流路'],
    outputs: ['Role/Circle定義', 'Governance Meeting設計'],
    antiPattern: '上司ゼロ=指示ゼロと誤解',
    jpAdapt: '日本企業適合度低い。導入失敗事例多数',
    triggerKeywords: ['Holacracy', 'ホラクラシー'],
  },
  {
    id: 'F_TEAL', name: 'Teal', jpName: 'ティール組織', category: 'organization',
    purpose: '進化型組織。Self-management/Wholeness/Evolutionary Purpose の3原則',
    whenToUse: ['コンサル/NPO/医療'],
    inputs: ['意思決定プロセス', '心理的安全性'],
    outputs: ['3原則の現状診断'],
    antiPattern: '理念だけで運用が伴わない',
    jpAdapt: 'ティール組織を標榜する企業の実態は8割が緑(達成型)止まり',
    triggerKeywords: ['Teal', 'ティール組織'],
  },
  {
    id: 'F_RACI', name: 'RACI', jpName: 'RACI', category: 'organization',
    purpose: 'タスクごとに誰がResponsible/Accountable/Consulted/Informedを明確化',
    whenToUse: ['プロジェクト体制図', 'M&A後の役割整理', 'RFP回答'],
    inputs: ['タスク一覧', 'ステークホルダー一覧'],
    outputs: ['RACIマトリクス'],
    antiPattern: 'Accountable が複数いる (一意性違反)',
    jpAdapt: '稟議文化との橋渡し。日本ではDARCI (Decider追加) も使う',
    triggerKeywords: ['RACI', 'DARCI'],
  },
];

// ========== 意思決定 (Decision) 8 ==========

const DECISION: StrategyFramework[] = [
  {
    id: 'F_REAL_OPTIONS', name: 'Real Options', jpName: 'リアルオプション', category: 'decision',
    purpose: '投資判断を金融オプション理論で評価。延期/拡大/撤退の柔軟性に価値',
    whenToUse: ['不確実性が高いR&D投資', '段階的設備投資'],
    inputs: ['将来CFのボラティリティ', '投資延期コスト', '拡張可能性'],
    outputs: ['NPV + オプション価値'],
    antiPattern: 'ブラックショールズで形だけ計算',
    jpAdapt: '段階的SaaS導入の経営説得に強力',
    triggerKeywords: ['Real Options', 'リアルオプション'],
  },
  {
    id: 'F_WARDLEY', name: 'Wardley Map', jpName: 'ワードリーマップ', category: 'decision',
    purpose: 'Value Chain × Genesis/Custom/Product/Commodity 進化軸の地図',
    whenToUse: ['技術選択', 'build vs buy', 'プラットフォーム戦略'],
    inputs: ['ユーザーニーズ', '依存コンポーネント', '進化段階'],
    outputs: ['Wardley Map', '戦略パターン'],
    antiPattern: '進化軸の評価が主観的',
    jpAdapt: 'AIインフラ判断 (自前GPU vs Bedrock vs API) に最適',
    triggerKeywords: ['Wardley', 'ワードリー'],
  },
  {
    id: 'F_SCENARIO', name: 'Scenario Planning', jpName: 'シナリオプランニング', category: 'decision',
    purpose: '不確実性軸2つで4シナリオを描き戦略のロバスト性を試す',
    whenToUse: ['10年先の構造変化対応', '規制変化対応'],
    inputs: ['最重要不確実要因', 'ドライバー候補'],
    outputs: ['4シナリオ', '全シナリオで耐える戦略 (no regret moves)'],
    antiPattern: 'ベストケース/ワーストケースの2軸で終わる',
    jpAdapt: 'AI規制 × 円安などのマトリクスで日本企業向けシナリオを内蔵',
    triggerKeywords: ['シナリオプランニング', 'Scenario Planning'],
  },
  {
    id: 'F_PREMORTEM', name: 'Pre-mortem', jpName: 'プレモーテム (Gary Klein)', category: 'decision',
    purpose: 'プロジェクト開始前に「1年後に失敗した」と仮定し原因を遡る',
    whenToUse: ['大型投資前', '新規事業ローンチ', 'M&A実行前'],
    inputs: ['プロジェクト計画', 'リスク仮説'],
    outputs: ['失敗シナリオ20件', '回避策'],
    antiPattern: '形式的にやってリスクを過小評価する',
    jpAdapt: 'SoloptiLinkAI Predictive Foresight (PFP-001〜028) は Pre-mortem の自動版',
    triggerKeywords: ['Pre-mortem', 'プレモーテム'],
  },
  {
    id: 'F_OODA', name: 'OODA', jpName: 'OODAループ', category: 'decision',
    purpose: 'Observe/Orient/Decide/Actの速い意思決定サイクル',
    whenToUse: ['危機対応', '競合の急襲対応'],
    inputs: ['現状観察', '状況判断'],
    outputs: ['即時意思決定', 'アクション'],
    antiPattern: 'PDCAと混同してPlan重視になり遅い',
    jpAdapt: '障害対応Runbookと連動',
    triggerKeywords: ['OODA'],
  },
  {
    id: 'F_PORTER_GENERIC', name: 'Porter Generic', jpName: 'ポーター3つの基本戦略', category: 'decision',
    purpose: 'コストリーダーシップ/差別化/集中の3類型から選ぶ',
    whenToUse: ['全社戦略の方向決め', '中小企業の戦略選択'],
    inputs: ['市場サイズ', '自社規模', '顧客セグメント'],
    outputs: ['戦略類型', 'Stuck in the Middle回避策'],
    antiPattern: 'Stuck in the Middle (どっちつかず)',
    jpAdapt: '日本中小は集中戦略 (ニッチ) が9割の正解',
    triggerKeywords: ['ポーター戦略', 'Generic Strategy'],
  },
  {
    id: 'F_ANSOFF', name: 'Ansoff Matrix', jpName: 'アンゾフの成長マトリクス', category: 'decision',
    purpose: '既存/新規製品 × 既存/新規市場 の4象限で成長戦略選択',
    whenToUse: ['中期計画', '新規事業評価'],
    inputs: ['既存事業の成熟度', '新規市場の魅力度'],
    outputs: ['市場浸透/開発/多角化の優先順位'],
    antiPattern: '新規×新規 (多角化) を安易に選ぶ',
    jpAdapt: '日本中小は市場浸透60% / 新製品30% / 新市場10% が標準配分',
    triggerKeywords: ['アンゾフ', 'Ansoff'],
  },
  {
    id: 'F_OPTION_ELIM', name: 'Option Elimination', jpName: '選択肢消去法 (Bain)', category: 'decision',
    purpose: '戦略選択肢を生成→消去基準で絞込→残ったものを精緻化',
    whenToUse: ['大量の戦略候補を絞り込む段階'],
    inputs: ['全戦略候補', 'Must条件/Want条件'],
    outputs: ['残存3-5候補', '詳細分析対象'],
    antiPattern: '最初から好み (Anchor) で1つに決め打ち',
    jpAdapt: 'Generator-Verifier ループでの選択肢生成と連動',
    triggerKeywords: ['選択肢消去', 'Option Elimination'],
  },
];

// ========== 日本式 (JP Native) 4 ==========

const JP_NATIVE: StrategyFramework[] = [
  {
    id: 'F_5WHY', name: '5 Whys', jpName: 'なぜなぜ5回 (トヨタ式)', category: 'jp_native',
    purpose: '根本原因を5回の問いで掘り下げる',
    whenToUse: ['障害分析', '離反原因', '受注失注分析'],
    inputs: ['事象記述'],
    outputs: ['真因', '再発防止策'],
    antiPattern: '1回目で人のせいにして止まる',
    jpAdapt: 'ポストモーテム連動',
    triggerKeywords: ['なぜなぜ', '5 Whys', '5why'],
  },
  {
    id: 'F_3M', name: '3M (Muda/Mura/Muri)', jpName: '3M (トヨタ式)', category: 'jp_native',
    purpose: 'ムダ/ムラ/ムリ の3観点で業務改善',
    whenToUse: ['業務効率化', '原価低減'],
    inputs: ['業務フロー', '工数記録'],
    outputs: ['3M別の改善リスト'],
    antiPattern: 'Mudaだけ見てMura/Muriを見落とす',
    jpAdapt: '日本生まれフレームワーク。海外SaaSにはない優位性',
    triggerKeywords: ['3M', 'ムダムラムリ', 'Muda'],
  },
  {
    id: 'F_8D', name: '8D (8 Disciplines)', jpName: '8D問題解決', category: 'jp_native',
    purpose: '問題解決を8ステップで構造化',
    whenToUse: ['品質クレーム', 'リコール対応'],
    inputs: ['不具合記録', '影響範囲'],
    outputs: ['8D Report'],
    antiPattern: '応急処置 (D3)で終わって恒久対策 (D5-D7)をやらない',
    jpAdapt: '自動車業界では必須',
    triggerKeywords: ['8D', '8 Disciplines'],
  },
  {
    id: 'F_SCQA', name: 'SCQA', jpName: 'SCQA (Pyramid Principle構造)', category: 'jp_native',
    purpose: 'Situation/Complication/Question/Answer で報告構造化',
    whenToUse: ['経営報告', '提案書', 'Board Deck'],
    inputs: ['事実', '課題', '提案'],
    outputs: ['1ページ・サマリ'],
    antiPattern: 'C (Complication) が抜けて状況→提案の唐突さ',
    jpAdapt: 'Pyramid Principle と組合せでBoard Deck標準化',
    triggerKeywords: ['SCQA', 'Pyramid Principle'],
  },
];

// ========== Master ==========

export const ALL_FRAMEWORKS: StrategyFramework[] = [
  ...CLASSIC, ...MODERN, ...EXECUTION, ...ORGANIZATION, ...DECISION, ...JP_NATIVE,
];

export const FRAMEWORKS_BY_CATEGORY: Record<FrameworkCategory, StrategyFramework[]> = {
  classic: CLASSIC,
  modern: MODERN,
  execution: EXECUTION,
  organization: ORGANIZATION,
  decision: DECISION,
  jp_native: JP_NATIVE,
};

/**
 * プロンプトから関連フレームワーク自動選定
 */
export function selectFrameworks(prompt: string): StrategyFramework[] {
  const text = prompt.toLowerCase();
  return ALL_FRAMEWORKS.filter((f) =>
    f.triggerKeywords.some((k) => text.includes(k.toLowerCase()))
  );
}

/**
 * 局面 (新規事業/M&A/危機対応/中期計画 等) から推奨フレームワーク3つ
 */
export function recommendFrameworksForContext(context:
  | 'new_business' | 'm_and_a' | 'crisis_response' | 'mid_term_plan' | 'cost_reduction' | 'organization_change' | 'pricing'
): StrategyFramework[] {
  const contextMap: Record<typeof context, string[]> = {
    new_business: ['F_LEAN_CANVAS', 'F_JTBD', 'F_PREMORTEM'],
    m_and_a: ['F_VRIO', 'F_ANSOFF', 'F_PORTER_GENERIC'],
    crisis_response: ['F_OODA', 'F_5WHY', 'F_SCQA'],
    mid_term_plan: ['F_PEST', 'F_BSC', 'F_HOSHIN'],
    cost_reduction: ['F_3M', 'F_VALUE_CHAIN', 'F_5WHY'],
    organization_change: ['F_7S', 'F_RACI', 'F_V2MOM'],
    pricing: ['F_5FORCE', 'F_BLUE_OCEAN', 'F_4P'],
  };
  const ids = contextMap[context];
  return ALL_FRAMEWORKS.filter((f) => ids.includes(f.id));
}
