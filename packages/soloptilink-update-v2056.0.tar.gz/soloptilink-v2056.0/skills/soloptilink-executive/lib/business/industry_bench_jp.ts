/**
 * SoloptiLinkAI v2033.0 — Industry Benchmarks JP
 * Phase 45 Executive Cognitive Layer
 *
 * 日本15業界 × 経営者朝一画面5指標 + 業界固有1指標。
 * 中小企業庁/TKC/EDINET/帝国データバンク 2024-2026年データを基準値として内蔵。
 *
 * 用途: 経営者画面生成時に「業界平均との比較」を強制表示するための真値DB。
 */

export type IndustryKey =
  | 'saas' | 'ec_dtc' | 'si_contracted' | 'manufacturing_general' | 'manufacturing_machine'
  | 'wholesale' | 'retail' | 'food_service' | 'lodging' | 'logistics'
  | 'real_estate' | 'medical' | 'longterm_care' | 'education' | 'beauty';

export interface BenchmarkValue {
  median: number | string;
  top25: number | string;
  bottom25: number | string;
  alertThreshold: number | string;
  source: string;
}

export interface IndustryBenchmark {
  key: IndustryKey;
  jpName: string;
  morningKPIs: {
    operatingProfitMarginPct: BenchmarkValue;
    grossMarginPct: BenchmarkValue;
    laborShareCostPct: BenchmarkValue;
    ccCycleDays: BenchmarkValue;
    inventoryTurnoverDays: BenchmarkValue;
  };
  industrySpecific: { name: string; value: BenchmarkValue }[];
  topConcerns: string[];
  bankruptcyRate2025?: string;
  notes: string;
}

export const SAAS_BENCH: IndustryBenchmark = {
  key: 'saas',
  jpName: 'SaaS',
  morningKPIs: {
    operatingProfitMarginPct: { median: '5-15%', top25: '25%+', bottom25: '-10%', alertThreshold: '<0% 2Q連続', source: 'SaaS 2026' },
    grossMarginPct: { median: '75-80%', top25: '85%', bottom25: '60% (AI-native許容)', alertThreshold: '<70% (AI除外時)', source: 'SaaS 2026' },
    laborShareCostPct: { median: '50-60% (R&D+S&M+G&A合算)', top25: '40%', bottom25: '70%', alertThreshold: '>75%', source: 'Industry 2026' },
    ccCycleDays: { median: '-30〜30日 (前受モデル)', top25: '-60日', bottom25: '60日', alertThreshold: '>90日', source: 'SaaS 2026' },
    inventoryTurnoverDays: { median: 'N/A (在庫レス)', top25: 'N/A', bottom25: 'N/A', alertThreshold: 'N/A', source: 'SaaS 2026' },
  },
  industrySpecific: [
    { name: 'NRR (Net Revenue Retention)', value: { median: '101%', top25: '130%+', bottom25: '95%', alertThreshold: '<100%', source: 'SaaS Mag 2026' } },
    { name: 'Rule of 40', value: { median: '28', top25: '40+', bottom25: '10', alertThreshold: '<20', source: 'Aventis 2026' } },
  ],
  topConcerns: ['Churn率', 'CAC高騰', 'AI競合の急成長', 'マーケット飽和'],
  notes: 'AI機能搭載で粗利率60%許容ライン下げ。日本SaaSは米国指標から-10%補正',
};

export const SI_CONTRACTED_BENCH: IndustryBenchmark = {
  key: 'si_contracted',
  jpName: 'SI受託開発',
  morningKPIs: {
    operatingProfitMarginPct: { median: 3.8, top25: 8, bottom25: 0, alertThreshold: '<0%', source: 'TKC 2018+ / 推計' },
    grossMarginPct: { median: 50.5, top25: 60, bottom25: 35, alertThreshold: '<40%', source: 'TKC 2018' },
    laborShareCostPct: { median: 65, top25: 55, bottom25: 75, alertThreshold: '>80%', source: '業界推計' },
    ccCycleDays: { median: 60, top25: 45, bottom25: 90, alertThreshold: '>90日', source: '下請法60日基準' },
    inventoryTurnoverDays: { median: 'N/A', top25: 'N/A', bottom25: 'N/A', alertThreshold: 'N/A', source: '無形' },
  },
  industrySpecific: [
    { name: '稼働率 (Utilization)', value: { median: '75%', top25: '85%', bottom25: '60%', alertThreshold: '<60% (赤字) or >90% (品質劣化)', source: '業界推計' } },
    { name: '受注残月数 (Backlog Months)', value: { median: '3-6月', top25: '6月+', bottom25: '<2月', alertThreshold: '<2月', source: '業界推計' } },
  ],
  topConcerns: ['人材確保', '稼働率変動', '下請法60日支払', '多重下請構造', 'デスマーチ案件'],
  notes: '2026年度末 約束手形廃止 → でんさい移行必須',
};

export const MANUFACTURING_MACHINE_BENCH: IndustryBenchmark = {
  key: 'manufacturing_machine',
  jpName: '製造業 (一般機械)',
  morningKPIs: {
    operatingProfitMarginPct: { median: 5.4, top25: 10, bottom25: 1, alertThreshold: '<2%', source: '中小企業庁 2024' },
    grossMarginPct: { median: 25, top25: 35, bottom25: 15, alertThreshold: '<15%', source: '業界推計' },
    laborShareCostPct: { median: 70, top25: 60, bottom25: 80, alertThreshold: '>85%', source: '中小企業庁' },
    ccCycleDays: { median: 80, top25: 60, bottom25: 120, alertThreshold: '>120日', source: 'Zaimani' },
    inventoryTurnoverDays: { median: 60, top25: 30, bottom25: 90, alertThreshold: '>120日', source: '業界推計' },
  },
  industrySpecific: [
    { name: 'OEE (設備総合効率)', value: { median: '60%', top25: '85% (世界クラス)', bottom25: '40%', alertThreshold: '<60%', source: 'Lean Manufacturing' } },
    { name: '不良率', value: { median: '1-3%', top25: '0.5%', bottom25: '5%', alertThreshold: '>5%', source: '業界推計' } },
  ],
  topConcerns: ['原材料高騰', '人手不足', '設備老朽化', '海外競合価格', '為替変動'],
  notes: '日本一般機械は世界中位、原価率管理が利益の鍵',
};

export const WHOLESALE_BENCH: IndustryBenchmark = {
  key: 'wholesale',
  jpName: '卸売業',
  morningKPIs: {
    operatingProfitMarginPct: { median: 1.4, top25: 3, bottom25: 0.5, alertThreshold: '<0.5%', source: '中小企業庁 2024' },
    grossMarginPct: { median: 12, top25: 18, bottom25: 8, alertThreshold: '<8%', source: '業界推計' },
    laborShareCostPct: { median: 55, top25: 45, bottom25: 70, alertThreshold: '>75%', source: '業界推計' },
    ccCycleDays: { median: 70, top25: 45, bottom25: 100, alertThreshold: '>100日', source: '業界推計' },
    inventoryTurnoverDays: { median: 45, top25: 25, bottom25: 75, alertThreshold: '>90日', source: '業界推計' },
  },
  industrySpecific: [
    { name: '商品回転率', value: { median: '8回/年', top25: '15回', bottom25: '4回', alertThreshold: '<3回', source: '業界推計' } },
  ],
  topConcerns: ['薄利化', 'EC直販による中抜き', 'BtoBデジタル化遅れ'],
  notes: '低粗利率の構造、ボリューム勝負',
};

export const RETAIL_BENCH: IndustryBenchmark = {
  key: 'retail',
  jpName: '小売業',
  morningKPIs: {
    operatingProfitMarginPct: { median: 2.5, top25: 5, bottom25: 0.5, alertThreshold: '<0%', source: '中小企業庁 2024' },
    grossMarginPct: { median: 28, top25: 40, bottom25: 18, alertThreshold: '<18%', source: '業界推計' },
    laborShareCostPct: { median: 60, top25: 50, bottom25: 75, alertThreshold: '>80%', source: '業界推計' },
    ccCycleDays: { median: 30, top25: 15, bottom25: 50, alertThreshold: '>60日', source: '業界推計' },
    inventoryTurnoverDays: { median: 60, top25: 30, bottom25: 90, alertThreshold: '>120日', source: '業界推計' },
  },
  industrySpecific: [
    { name: '坪効率 (年間売上/坪)', value: { median: '120万', top25: '300万', bottom25: '60万', alertThreshold: '<50万', source: '業界推計' } },
  ],
  topConcerns: ['EC化対応', '物価高転嫁', '人手不足', '集客'],
  bankruptcyRate2025: '高 (TDB 2025)',
  notes: 'リアル店舗 vs EC ハイブリッドが必須',
};

export const FOOD_SERVICE_BENCH: IndustryBenchmark = {
  key: 'food_service',
  jpName: '飲食業',
  morningKPIs: {
    operatingProfitMarginPct: { median: 3, top25: 8, bottom25: -2, alertThreshold: '<0%', source: '業界推計' },
    grossMarginPct: { median: 65, top25: 75, bottom25: 55, alertThreshold: '<55%', source: '業界推計' },
    laborShareCostPct: { median: 30, top25: 25, bottom25: 40, alertThreshold: '>40%', source: '業界推計' },
    ccCycleDays: { median: 10, top25: 5, bottom25: 20, alertThreshold: '>30日', source: '業界推計' },
    inventoryTurnoverDays: { median: 7, top25: 3, bottom25: 15, alertThreshold: '>20日', source: '業界推計' },
  },
  industrySpecific: [
    { name: 'FLR比率 (Food+Labor+Rent / Sales)', value: { median: '70%', top25: '60%', bottom25: '80%', alertThreshold: '>80%', source: '飲食業ベンチ' } },
    { name: '客単価', value: { median: '業態依存', top25: '-', bottom25: '-', alertThreshold: '前年比-10%', source: '業界推計' } },
  ],
  topConcerns: ['原材料高騰', '人手不足', '光熱費', 'インバウンド回復'],
  bankruptcyRate2025: '過去最多級',
  notes: 'FLR=70%が黒字ライン',
};

export const LOGISTICS_BENCH: IndustryBenchmark = {
  key: 'logistics',
  jpName: '物流・運輸業',
  morningKPIs: {
    operatingProfitMarginPct: { median: 3, top25: 6, bottom25: 1, alertThreshold: '<1%', source: '業界推計' },
    grossMarginPct: { median: 18, top25: 25, bottom25: 12, alertThreshold: '<12%', source: '業界推計' },
    laborShareCostPct: { median: 60, top25: 50, bottom25: 70, alertThreshold: '>75%', source: '業界推計' },
    ccCycleDays: { median: 55, top25: 35, bottom25: 75, alertThreshold: '>80日', source: '業界推計' },
    inventoryTurnoverDays: { median: 'N/A', top25: 'N/A', bottom25: 'N/A', alertThreshold: 'N/A', source: '無在庫' },
  },
  industrySpecific: [
    { name: '実車率 (Loaded Mile)', value: { median: '75%', top25: '90%', bottom25: '60%', alertThreshold: '<60%', source: '業界推計' } },
  ],
  topConcerns: ['2024年問題 ドライバー残業上限', '燃料高', '人手不足'],
  notes: '改善基準告示R6.4対応必須',
};

export const REAL_ESTATE_BENCH: IndustryBenchmark = {
  key: 'real_estate',
  jpName: '不動産業',
  morningKPIs: {
    operatingProfitMarginPct: { median: 8, top25: 15, bottom25: 3, alertThreshold: '<2%', source: '業界推計' },
    grossMarginPct: { median: 25, top25: 40, bottom25: 15, alertThreshold: '<15%', source: '業界推計' },
    laborShareCostPct: { median: 30, top25: 20, bottom25: 45, alertThreshold: '>50%', source: '業界推計' },
    ccCycleDays: { median: 60, top25: 30, bottom25: 120, alertThreshold: '>180日', source: '業界推計' },
    inventoryTurnoverDays: { median: 365, top25: 180, bottom25: 730, alertThreshold: '>730日', source: '物件在庫' },
  },
  industrySpecific: [
    { name: '稼働率 (賃貸)', value: { median: '90%', top25: '98%', bottom25: '80%', alertThreshold: '<85%', source: '業界推計' } },
  ],
  topConcerns: ['金利上昇', '物件価格高騰', '空室率', '相続案件増'],
  notes: '宅建業法+媒介3種+レインズ5-7日',
};

export const MEDICAL_BENCH: IndustryBenchmark = {
  key: 'medical',
  jpName: '医療業',
  morningKPIs: {
    operatingProfitMarginPct: { median: 5, top25: 10, bottom25: 1, alertThreshold: '<0%', source: '医療経済実態調査' },
    grossMarginPct: { median: 'N/A (診療報酬制)', top25: 'N/A', bottom25: 'N/A', alertThreshold: 'N/A', source: '医療業特性' },
    laborShareCostPct: { median: 55, top25: 45, bottom25: 65, alertThreshold: '>70%', source: '医療経済実態調査' },
    ccCycleDays: { median: 60, top25: 50, bottom25: 90, alertThreshold: '>90日', source: '社保支払' },
    inventoryTurnoverDays: { median: 30, top25: 15, bottom25: 60, alertThreshold: '>60日', source: '薬剤在庫' },
  },
  industrySpecific: [
    { name: '外来患者数 / 病床稼働率', value: { median: '85%', top25: '95%', bottom25: '75%', alertThreshold: '<75%', source: '病院ベンチ' } },
  ],
  topConcerns: ['診療報酬改定', '医師不足', '働き方改革 (医師2024)'],
  notes: '医療法+医師法+健保法+診療報酬',
};

export const LONGTERM_CARE_BENCH: IndustryBenchmark = {
  key: 'longterm_care',
  jpName: '介護業',
  morningKPIs: {
    operatingProfitMarginPct: { median: 2, top25: 5, bottom25: -2, alertThreshold: '<0% (倒産危険)', source: '介護経営実態調査 R6' },
    grossMarginPct: { median: 'N/A (介護報酬制)', top25: 'N/A', bottom25: 'N/A', alertThreshold: 'N/A', source: '制度' },
    laborShareCostPct: { median: 70, top25: 60, bottom25: 80, alertThreshold: '>80%', source: '介護経営実態調査' },
    ccCycleDays: { median: 60, top25: 50, bottom25: 90, alertThreshold: '>90日', source: '介護保険支払' },
    inventoryTurnoverDays: { median: 'N/A', top25: 'N/A', bottom25: 'N/A', alertThreshold: 'N/A', source: '無在庫' },
  },
  industrySpecific: [
    { name: '稼働率', value: { median: '90%', top25: '98%', bottom25: '80%', alertThreshold: '<85%', source: '業界推計' } },
  ],
  topConcerns: ['介護報酬2024マイナス改定', '人材不足', '訪問介護倒産過去最多'],
  bankruptcyRate2025: '介護事業者倒産176件 過去最多 / 訪問介護91件',
  notes: 'R6介護報酬改定 + 処遇改善加算',
};

export const BEAUTY_BENCH: IndustryBenchmark = {
  key: 'beauty',
  jpName: '美容業',
  morningKPIs: {
    operatingProfitMarginPct: { median: 3, top25: 10, bottom25: -1, alertThreshold: '<0%', source: '業界推計' },
    grossMarginPct: { median: 75, top25: 85, bottom25: 60, alertThreshold: '<60%', source: '業界推計' },
    laborShareCostPct: { median: 45, top25: 35, bottom25: 55, alertThreshold: '>60%', source: '業界推計' },
    ccCycleDays: { median: 5, top25: 1, bottom25: 15, alertThreshold: '>20日', source: '即金性' },
    inventoryTurnoverDays: { median: 30, top25: 15, bottom25: 60, alertThreshold: '>60日', source: '薬剤等' },
  },
  industrySpecific: [
    { name: '顧客リピート率', value: { median: '60%', top25: '80%', bottom25: '40%', alertThreshold: '<40%', source: '業界推計' } },
    { name: '指名率', value: { median: '40%', top25: '60%', bottom25: '20%', alertThreshold: '<20%', source: '業界推計' } },
  ],
  topConcerns: ['フリーランス化', '人材流出', '人件費高騰'],
  bankruptcyRate2025: '美容室倒産3年連続増',
  notes: '美容師法 + 都道府県条例',
};

export const LODGING_BENCH: IndustryBenchmark = {
  key: 'lodging',
  jpName: '宿泊業',
  morningKPIs: {
    operatingProfitMarginPct: { median: 5, top25: 15, bottom25: -2, alertThreshold: '<0%', source: '業界推計' },
    grossMarginPct: { median: 70, top25: 80, bottom25: 55, alertThreshold: '<55%', source: '業界推計' },
    laborShareCostPct: { median: 35, top25: 25, bottom25: 50, alertThreshold: '>55%', source: '業界推計' },
    ccCycleDays: { median: 30, top25: 15, bottom25: 60, alertThreshold: '>60日', source: 'OTA決済' },
    inventoryTurnoverDays: { median: 'N/A', top25: 'N/A', bottom25: 'N/A', alertThreshold: 'N/A', source: '即時消費' },
  },
  industrySpecific: [
    { name: 'RevPAR (Revenue per Available Room)', value: { median: '業態依存', top25: '-', bottom25: '-', alertThreshold: '前年比-15%', source: '業界推計' } },
    { name: '稼働率', value: { median: '70%', top25: '85%', bottom25: '55%', alertThreshold: '<50%', source: '業界推計' } },
  ],
  topConcerns: ['インバウンド変動', '人手不足', 'OTA手数料', '物価高'],
  notes: '旅館業法 / 民泊180日 / 宿泊税5自治体',
};

export const EDUCATION_BENCH: IndustryBenchmark = {
  key: 'education',
  jpName: '教育業',
  morningKPIs: {
    operatingProfitMarginPct: { median: 8, top25: 20, bottom25: 2, alertThreshold: '<2%', source: '業界推計' },
    grossMarginPct: { median: 55, top25: 70, bottom25: 40, alertThreshold: '<40%', source: '業界推計' },
    laborShareCostPct: { median: 50, top25: 40, bottom25: 60, alertThreshold: '>65%', source: '業界推計' },
    ccCycleDays: { median: 30, top25: 0, bottom25: 60, alertThreshold: '>90日', source: '前受制' },
    inventoryTurnoverDays: { median: 'N/A', top25: 'N/A', bottom25: 'N/A', alertThreshold: 'N/A', source: '無在庫' },
  },
  industrySpecific: [
    { name: '生徒継続率', value: { median: '70%', top25: '90%', bottom25: '50%', alertThreshold: '<60%', source: '業界推計' } },
  ],
  topConcerns: ['少子化', 'オンライン競合', '講師確保'],
  notes: '学習指導要領R2 / 学校教育法',
};

export const EC_DTC_BENCH: IndustryBenchmark = {
  key: 'ec_dtc',
  jpName: 'EC / D2C',
  morningKPIs: {
    operatingProfitMarginPct: { median: 5, top25: 15, bottom25: -3, alertThreshold: '<0%', source: '業界推計' },
    grossMarginPct: { median: 40, top25: 60, bottom25: 25, alertThreshold: '<25%', source: '業界推計' },
    laborShareCostPct: { median: 30, top25: 20, bottom25: 45, alertThreshold: '>50%', source: '業界推計' },
    ccCycleDays: { median: 30, top25: 0, bottom25: 60, alertThreshold: '>60日', source: 'カード決済' },
    inventoryTurnoverDays: { median: 60, top25: 30, bottom25: 120, alertThreshold: '>180日', source: '業界推計' },
  },
  industrySpecific: [
    { name: 'CVR', value: { median: '1.5%', top25: '3%+', bottom25: '0.8%', alertThreshold: '前週比-30%', source: '業界推計' } },
    { name: 'リピート率', value: { median: '40%', top25: '60%', bottom25: '20%', alertThreshold: '<20%', source: '業界推計' } },
  ],
  topConcerns: ['広告ROAS悪化', '物流コスト', '返品率'],
  notes: '特商法 + 景表法 + ステマR5.10',
};

export const MANUFACTURING_GENERAL_BENCH: IndustryBenchmark = {
  key: 'manufacturing_general',
  jpName: '製造業 (全般)',
  morningKPIs: {
    operatingProfitMarginPct: { median: 4, top25: 8, bottom25: 0, alertThreshold: '<0%', source: '中小企業庁 2024' },
    grossMarginPct: { median: 22, top25: 32, bottom25: 12, alertThreshold: '<12%', source: '業界推計' },
    laborShareCostPct: { median: 68, top25: 58, bottom25: 78, alertThreshold: '>80%', source: '中小企業庁' },
    ccCycleDays: { median: 75, top25: 50, bottom25: 110, alertThreshold: '>120日', source: '業界推計' },
    inventoryTurnoverDays: { median: 60, top25: 30, bottom25: 100, alertThreshold: '>120日', source: '業界推計' },
  },
  industrySpecific: [
    { name: '生産性 (一人あたり付加価値)', value: { median: '800万円', top25: '1500万円', bottom25: '500万円', alertThreshold: '<400万円', source: '中小企業庁' } },
  ],
  topConcerns: ['原材料高', '人手不足', '為替', 'サプライチェーン'],
  notes: '製造業中小は人時生産性向上が利益の鍵',
};

export const ALL_INDUSTRY_BENCHMARKS: Record<IndustryKey, IndustryBenchmark> = {
  saas: SAAS_BENCH,
  ec_dtc: EC_DTC_BENCH,
  si_contracted: SI_CONTRACTED_BENCH,
  manufacturing_general: MANUFACTURING_GENERAL_BENCH,
  manufacturing_machine: MANUFACTURING_MACHINE_BENCH,
  wholesale: WHOLESALE_BENCH,
  retail: RETAIL_BENCH,
  food_service: FOOD_SERVICE_BENCH,
  lodging: LODGING_BENCH,
  logistics: LOGISTICS_BENCH,
  real_estate: REAL_ESTATE_BENCH,
  medical: MEDICAL_BENCH,
  longterm_care: LONGTERM_CARE_BENCH,
  education: EDUCATION_BENCH,
  beauty: BEAUTY_BENCH,
};

/**
 * プロンプトから業界を推定
 */
export function inferIndustry(prompt: string): IndustryKey | null {
  const text = prompt.toLowerCase();
  const patterns: Array<[IndustryKey, RegExp]> = [
    ['saas', /saas|サブスク|subscription/],
    ['ec_dtc', /ec|d2c|ネット通販|オンラインショップ/],
    ['si_contracted', /si|受託開発|システム開発/],
    ['manufacturing_machine', /一般機械|工作機械/],
    ['manufacturing_general', /製造業|メーカー|工場/],
    ['wholesale', /卸売|商社/],
    ['retail', /小売|店舗/],
    ['food_service', /飲食|レストラン|居酒屋/],
    ['lodging', /宿泊|ホテル|旅館|民泊/],
    ['logistics', /物流|運送|配送/],
    ['real_estate', /不動産|賃貸|仲介/],
    ['medical', /医療|病院|クリニック/],
    ['longterm_care', /介護|デイサービス|訪問介護/],
    ['education', /教育|塾|スクール/],
    ['beauty', /美容|サロン|エステ/],
  ];
  for (const [key, pattern] of patterns) {
    if (pattern.test(text)) return key;
  }
  return null;
}
