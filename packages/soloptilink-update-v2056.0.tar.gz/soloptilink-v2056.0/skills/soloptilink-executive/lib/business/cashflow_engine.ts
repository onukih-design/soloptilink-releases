/**
 * SoloptiLinkAI v2033.0 — Cashflow Engine JP
 * Phase 45 Executive Cognitive Layer
 *
 * 13週キャッシュフロー予測 / 黒字倒産7予兆 / 銀行格付シミュレータ / 信用保証協会・公庫制度 /
 * 約束手形廃止 2026年度末 → でんさい移行プロトコル
 */

// ========== 13週キャッシュフロー ==========

export interface WeeklyCashflowEntry {
  weekNumber: number; // 1-13
  weekStartDate: string; // ISO
  openingBalance: number;
  inflows: { source: string; amount: number; confidence: 'high' | 'medium' | 'low' }[];
  outflows: { destination: string; amount: number; mandatory: boolean }[];
  endingBalance: number;
  alertFlag?: 'red' | 'yellow' | 'green';
}

export interface ThirteenWeekCashflow {
  generatedAt: string;
  startDate: string;
  entries: WeeklyCashflowEntry[];
  minBalance: number;
  minBalanceWeek: number;
  totalInflow: number;
  totalOutflow: number;
  cashShortageRisk: boolean;
}

/**
 * 13週CF 生成 (与えられた残高+予定入出金から)
 */
export function generate13WeekCashflow(input: {
  startDate: string;
  openingBalance: number;
  scheduledInflows: { weekNumber: number; source: string; amount: number; confidence: 'high' | 'medium' | 'low' }[];
  scheduledOutflows: { weekNumber: number; destination: string; amount: number; mandatory: boolean }[];
  warningThreshold?: number;
}): ThirteenWeekCashflow {
  const threshold = input.warningThreshold ?? 0;
  const entries: WeeklyCashflowEntry[] = [];
  let balance = input.openingBalance;
  const baseDate = new Date(input.startDate);

  for (let w = 1; w <= 13; w++) {
    const inflows = input.scheduledInflows.filter((i) => i.weekNumber === w);
    const outflows = input.scheduledOutflows.filter((o) => o.weekNumber === w);
    const openingBalance = balance;
    const inSum = inflows.reduce((s, i) => s + i.amount, 0);
    const outSum = outflows.reduce((s, o) => s + o.amount, 0);
    balance = balance + inSum - outSum;
    const weekStart = new Date(baseDate);
    weekStart.setDate(weekStart.getDate() + (w - 1) * 7);
    const flag: 'red' | 'yellow' | 'green' =
      balance < threshold ? 'red' : balance < threshold * 1.5 ? 'yellow' : 'green';
    entries.push({
      weekNumber: w,
      weekStartDate: weekStart.toISOString().split('T')[0],
      openingBalance,
      inflows,
      outflows,
      endingBalance: balance,
      alertFlag: flag,
    });
  }

  const minEntry = entries.reduce((min, e) => (e.endingBalance < min.endingBalance ? e : min), entries[0]);
  return {
    generatedAt: new Date().toISOString(),
    startDate: input.startDate,
    entries,
    minBalance: minEntry.endingBalance,
    minBalanceWeek: minEntry.weekNumber,
    totalInflow: entries.reduce((s, e) => s + e.inflows.reduce((a, i) => a + i.amount, 0), 0),
    totalOutflow: entries.reduce((s, e) => s + e.outflows.reduce((a, o) => a + o.amount, 0), 0),
    cashShortageRisk: minEntry.endingBalance < threshold,
  };
}

// ========== 黒字倒産 7予兆 ==========

export interface BlackBankruptcyAssessment {
  signs: {
    name: string;
    detected: boolean;
    detail: string;
  }[];
  triggeredCount: number;
  riskLevel: 'critical' | 'high' | 'medium' | 'low';
  immediateActions: string[];
}

export interface BlackBankruptcyInput {
  operatingCfNegativeQuarters: number;
  receivableDays: number;
  payableDays: number;
  monthlyRepayment: number;
  monthlyOperatingCf: number;
  taxArrears: boolean;
  cashflowForecastExists: boolean;
  noteJump: boolean; // 支払手形のジャンプ
  socialInsuranceArrears: boolean;
}

export function assessBlackBankruptcy(input: BlackBankruptcyInput): BlackBankruptcyAssessment {
  const signs = [
    { name: '営業CFが2四半期連続マイナス', detected: input.operatingCfNegativeQuarters >= 2, detail: `${input.operatingCfNegativeQuarters}四半期連続マイナス` },
    { name: '売掛サイト > 支払サイト', detected: input.receivableDays > input.payableDays, detail: `売掛${input.receivableDays}日 vs 支払${input.payableDays}日` },
    { name: '借入返済額 > 営業CF', detected: input.monthlyRepayment > input.monthlyOperatingCf, detail: `返済${input.monthlyRepayment} vs 営業CF${input.monthlyOperatingCf}` },
    { name: '資金繰り表が未作成', detected: !input.cashflowForecastExists, detail: '13週CF不在' },
    { name: '支払手形のジャンプ (期日延長依頼)', detected: input.noteJump, detail: '手形ジャンプ要請履歴あり' },
    { name: '税金の滞納', detected: input.taxArrears, detail: '税滞納あり' },
    { name: '社会保険料の滞納', detected: input.socialInsuranceArrears, detail: '社保滞納あり' },
  ];
  const triggeredCount = signs.filter((s) => s.detected).length;

  let riskLevel: 'critical' | 'high' | 'medium' | 'low' = 'low';
  let immediateActions: string[] = [];

  if (triggeredCount >= 4) {
    riskLevel = 'critical';
    immediateActions = [
      '【72時間以内】中小企業活性化協議会へ相談',
      '【1週間以内】メインバンク+顧問税理士+弁護士 三者面談セット',
      '【2週間以内】経営者保証GL R5に基づく早期対応申入',
      '【即時】支払優先順位再設計 (税金>社保>労務費>主要仕入先>その他)',
    ];
  } else if (triggeredCount >= 3) {
    riskLevel = 'high';
    immediateActions = [
      '【2週間以内】13週資金繰り表作成',
      '【1ヶ月以内】メインバンク相談アポ取り',
      '【2週間以内】回収遅延顧客 督促強化',
      '滞納の有無確認、即時納付',
    ];
  } else if (triggeredCount >= 2) {
    riskLevel = 'medium';
    immediateActions = [
      '【週次】CF更新+異常検知',
      '回収遅延顧客リスト精査',
      '支払サイト交渉余地検討',
    ];
  } else {
    immediateActions = ['通常モニタリング継続'];
  }

  return { signs, triggeredCount, riskLevel, immediateActions };
}

// ========== 銀行格付シミュレータ ==========

export type BankRatingTier =
  | '正常先' | '要注意先' | '要管理先' | '破綻懸念先' | '実質破綻先' | '破綻先';

export interface BankRatingInput {
  equityRatio: number; // 自己資本比率 %
  dscr: number;
  operatingProfitMargin: number; // %
  debtPaybackYears: number; // 債務償還年数
  businessEvaluationScore: number; // 事業性評価 0-100
}

export interface BankRatingResult {
  rating: BankRatingTier;
  totalScore: number;
  breakdown: { metric: string; score: number; max: number; note: string }[];
  improvementSuggestions: string[];
}

export function simulateBankRating(input: BankRatingInput): BankRatingResult {
  const breakdown: { metric: string; score: number; max: number; note: string }[] = [];
  let total = 0;

  // 自己資本比率
  const eqScore = input.equityRatio >= 30 ? 25 : input.equityRatio >= 15 ? 15 : input.equityRatio >= 5 ? 5 : 0;
  breakdown.push({
    metric: '自己資本比率',
    score: eqScore,
    max: 25,
    note: `${input.equityRatio}% (10%未満で格付下落リスク)`,
  });
  total += eqScore;

  // DSCR
  const dsScore = input.dscr >= 1.5 ? 25 : input.dscr >= 1.2 ? 15 : input.dscr >= 1.0 ? 5 : 0;
  breakdown.push({
    metric: 'DSCR',
    score: dsScore,
    max: 25,
    note: `${input.dscr.toFixed(2)}x (融資審査1.2-1.5以上、1.0未満で返済困難)`,
  });
  total += dsScore;

  // 営業利益率
  const opmScore =
    input.operatingProfitMargin >= 5 ? 20 : input.operatingProfitMargin >= 2 ? 10 : input.operatingProfitMargin >= 0 ? 5 : 0;
  breakdown.push({
    metric: '営業利益率',
    score: opmScore,
    max: 20,
    note: `${input.operatingProfitMargin}%`,
  });
  total += opmScore;

  // 債務償還年数
  const dpScore =
    input.debtPaybackYears <= 10 ? 20 : input.debtPaybackYears <= 20 ? 10 : 0;
  breakdown.push({
    metric: '債務償還年数',
    score: dpScore,
    max: 20,
    note: `${input.debtPaybackYears}年 (20年超で要注意)`,
  });
  total += dpScore;

  // 事業性評価
  const beScore =
    input.businessEvaluationScore >= 70 ? 10 : input.businessEvaluationScore >= 50 ? 5 : 0;
  breakdown.push({
    metric: '事業性評価',
    score: beScore,
    max: 10,
    note: `${input.businessEvaluationScore}/100`,
  });
  total += beScore;

  let rating: BankRatingTier = '破綻先';
  if (total >= 80) rating = '正常先';
  else if (total >= 60) rating = '要注意先';
  else if (total >= 40) rating = '要管理先';
  else if (total >= 25) rating = '破綻懸念先';
  else if (total >= 10) rating = '実質破綻先';

  const suggestions: string[] = [];
  if (eqScore < 15) suggestions.push('自己資本比率を上げる: 利益留保強化/増資検討');
  if (dsScore < 15) suggestions.push('DSCR改善: 営業利益向上/減価償却前利益増/借換で月次返済額抑制');
  if (opmScore < 10) suggestions.push('営業利益率改善: 値上げ/原価低減/低利益案件撤退');
  if (dpScore < 10) suggestions.push('債務償還年数短縮: 一部繰上返済 or 借入額削減');
  if (beScore < 5) suggestions.push('事業性評価点数を上げる: ローカルベンチマーク (経産省) 提出');

  return { rating, totalScore: total, breakdown, improvementSuggestions: suggestions };
}

// ========== 信用保証協会・日本政策金融公庫 制度メニュー ==========

export interface FinancingOption {
  name: string;
  provider: string;
  guarantorRequired: boolean;
  maxAmount: string;
  interestRange: string;
  paybackPeriod: string;
  bestFor: string[];
  notes: string;
}

export const JP_FINANCING_OPTIONS: FinancingOption[] = [
  {
    name: 'プロパー融資',
    provider: '銀行',
    guarantorRequired: false,
    maxAmount: '銀行裁量',
    interestRange: '0.5-2.5%',
    paybackPeriod: '5-15年',
    bestFor: ['信頼関係構築のキー', '担保あり', '優良顧客'],
    notes: '保証料なし。最も信頼の証',
  },
  {
    name: '信用保証協会付き融資',
    provider: '銀行 + 信用保証協会',
    guarantorRequired: false,
    maxAmount: '原則1社あたり 普通保証2.8億 / 無担保8000万 (一般)',
    interestRange: '0.5-3% + 保証料0.45-1.9%',
    paybackPeriod: '5-10年',
    bestFor: ['中小企業の標準', '担保不足'],
    notes: '保証協会80%保証。経営者保証なし制度2024',
  },
  {
    name: '日本政策金融公庫 (一般貸付)',
    provider: '日本政策金融公庫',
    guarantorRequired: false,
    maxAmount: '4800万 (国民生活事業) / 7.2億 (中小事業)',
    interestRange: '基準金利1.0-2.5%',
    paybackPeriod: '設備20年/運転7年',
    bestFor: ['創業融資', '災害融資', '事業承継'],
    notes: '公的バックアップ',
  },
  {
    name: '日本政策金融公庫 (新創業融資制度)',
    provider: '日本政策金融公庫',
    guarantorRequired: false,
    maxAmount: '3000万 (うち運転1500万)',
    interestRange: '2.5%前後',
    paybackPeriod: '設備15年/運転7年',
    bestFor: ['創業2期以内', '担保・保証人不要'],
    notes: '雇用創出条件等',
  },
  {
    name: 'コミットメントライン',
    provider: '銀行',
    guarantorRequired: false,
    maxAmount: '銀行設定',
    interestRange: '基準金利 + 手数料',
    paybackPeriod: '極短期 (1-12ヶ月)',
    bestFor: ['資金繰り安定化', '中堅以上'],
    notes: '未使用部分にも手数料',
  },
  {
    name: 'ファクタリング (2社間/3社間)',
    provider: 'ファクタリング会社',
    guarantorRequired: false,
    maxAmount: '売掛金次第',
    interestRange: '手数料1-20%',
    paybackPeriod: '即時資金化',
    bestFor: ['緊急時のみ'],
    notes: '常用化で財務体質悪化、闇ファクタリング注意',
  },
];

// ========== 約束手形廃止 2026年度末 → でんさい移行 ==========

export const PAYMENT_TRANSITION_2026 = {
  policyName: '約束手形利用廃止 (2026年度末目処)',
  source: '経済産業省 / 金融庁',
  background: '2021年「成長戦略実行計画」 紙の手形を廃止し電子化に統一',
  alternatives: [
    {
      name: 'でんさい (電子記録債権)',
      operator: 'でんさいネット (全銀協)',
      benefits: ['印紙税不要', '分割譲渡可能', '紛失リスクなし', '電子保存'],
      adoption: '2024時点で大企業中心。中小は加速期',
    },
    {
      name: '振込',
      benefits: ['シンプル', '手数料安い'],
      issues: ['資金回転悪化 (支払即時)'],
    },
    {
      name: 'ファクタリング (オンライン)',
      benefits: ['即時資金化'],
      issues: ['手数料高'],
    },
  ],
  preparationChecklist: [
    'メインバンクのでんさい対応確認',
    '取引先 でんさい受領可否ヒアリング',
    '会計システム でんさい連携対応',
    '支払フロー再設計 (支払サイト見直し含む)',
    '緊急時の振込代替フロー整備',
  ],
};
