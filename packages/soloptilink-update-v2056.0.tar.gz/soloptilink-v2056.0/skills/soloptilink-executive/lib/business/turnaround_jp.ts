/**
 * SoloptiLinkAI v2033.0 — Turnaround JP
 * Phase 45 Executive Cognitive Layer
 *
 * Altman Z-Score 中小企業適用版 / 経営者保証GL R5改訂 / 第二会社方式 /
 * 民事再生・会社更生・特別清算 選択フロー / 中小企業活性化協議会 /
 * 2025年度倒産1万425件 (4年連続増)
 */

// ========== Altman Z-Score 倒産予測 ==========

export interface AltmanZInput {
  workingCapital: number; // 運転資本
  totalAssets: number; // 総資産
  retainedEarnings: number; // 利益剰余金
  ebit: number; // 営業利益
  marketValueEquity: number; // 株主資本市場価値 (非上場は簿価)
  bookValueLiabilities: number; // 負債簿価
  sales: number; // 売上高
}

export interface AltmanZResult {
  zScore: number;
  zone: 'safe' | 'gray' | 'distress';
  interpretation: string;
}

/**
 * Altman Z-Score (改訂版: 非製造業向けZ"-Score)
 * Z" = 6.56*A + 3.26*B + 6.72*C + 1.05*D
 *  A = 運転資本/総資産
 *  B = 利益剰余金/総資産
 *  C = EBIT/総資産
 *  D = 株主資本簿価/総負債
 */
export function calcAltmanZScore(input: AltmanZInput): AltmanZResult {
  const a = input.workingCapital / input.totalAssets;
  const b = input.retainedEarnings / input.totalAssets;
  const c = input.ebit / input.totalAssets;
  const d = input.marketValueEquity / input.bookValueLiabilities;
  const z = 6.56 * a + 3.26 * b + 6.72 * c + 1.05 * d;

  let zone: 'safe' | 'gray' | 'distress';
  let interpretation: string;

  if (z > 2.6) {
    zone = 'safe';
    interpretation = '安全圏: 倒産確率低 (1年内倒産確率<10%)';
  } else if (z > 1.1) {
    zone = 'gray';
    interpretation = 'グレーゾーン: 注意要 (1年内倒産確率 30-50%)。経営改善計画着手推奨';
  } else {
    zone = 'distress';
    interpretation = 'ディストレス圏: 倒産危険 (1年内倒産確率 50%+)。緊急対応必須';
  }

  return { zScore: z, zone, interpretation };
}

// ========== 経営者保証ガイドライン R5改訂 ==========

export const KEIEISHA_HOSHO_GUIDELINE_R5 = {
  version: 'R5改訂 (2023-04-01施行)',
  source: '中小企業庁・金融庁・全国銀行協会',
  keyChanges: [
    '主たる債務者と保証人の弁済責任の関係を明確化',
    '廃業時の早期相談で残存資産確保可能性が明文化',
    'インセンティブ拡充: 経営者保証なし融資の選択肢拡大',
    '中小企業活性化協議会等を利用した廃業のサポート強化',
  ],
  conditionsForGuaranteeRelease: [
    '法人と経営者の資産・経理が明確に区分',
    '法人と経営者の間の資金のやり取りが事業上必要な範囲',
    '財務基盤が強化されて法人のみの資産・収益力で借入返済が可能',
    '金融機関に対し、適時適切に財務情報等が提供されている',
    '事業継続に必要な見込みが立つ事業計画書を提示',
  ],
  earlyConsultationBenefits: [
    '残存資産: 一定額 (99万円 + 華美でない自宅) を残せる可能性',
    '保証債務の一部免除',
    '個人破産を回避できる可能性',
    '次の事業再挑戦への足がかり',
  ],
};

// ========== 第二会社方式 ==========

export const SECOND_COMPANY_METHOD = {
  name: '第二会社方式',
  description: '良い事業だけを新会社 (第二会社) に移し、不採算事業や債務を旧会社に残して特別清算する手法',
  mechanism: [
    '1. 会社分割 or 事業譲渡で「良い事業」を新会社へ',
    '2. 旧会社は不採算事業 + 過剰債務を抱えて特別清算',
    '3. 新会社は健全な財務体質で事業継続',
  ],
  prerequisites: [
    '債権者の同意',
    '事業価値が清算価値を上回ること (再生型清算)',
    '中小企業活性化協議会 / REVIC / 中小機構 等の関与推奨',
    '租税回避と認定されないストラクチャ設計',
  ],
  taxConsiderations: [
    '適格分割の要件確認',
    '譲渡損益 (旧会社) の税務処理',
    '繰越欠損金の引継ぎ',
    '消費税 (事業譲渡時に課税)',
  ],
};

// ========== 法的整理 選択フロー ==========

export interface LegalRestructuringOption {
  name: string;
  preserveManagement: boolean;
  timeframe: string;
  applicability: string;
  costApprox: string;
  notes: string;
}

export const LEGAL_RESTRUCTURING: LegalRestructuringOption[] = [
  {
    name: '民事再生',
    preserveManagement: true,
    timeframe: '6ヶ月-2年',
    applicability: '中堅以下、経営陣続投したい',
    costApprox: '500万-数千万 (規模依存)',
    notes: 'DIP型 (Debtor In Possession)。経営権維持。再生計画認可で債務カット',
  },
  {
    name: '会社更生',
    preserveManagement: false,
    timeframe: '1-3年',
    applicability: '大企業、株式会社のみ',
    costApprox: '数千万-数億',
    notes: '管財人就任、経営権喪失。担保権実行制限あり',
  },
  {
    name: '特別清算',
    preserveManagement: false,
    timeframe: '6ヶ月-2年',
    applicability: '株式会社の解散後',
    costApprox: '500万-数千万',
    notes: '裁判所監督下の清算。協定型と和解型',
  },
  {
    name: '破産',
    preserveManagement: false,
    timeframe: '3ヶ月-1年',
    applicability: '再生不能、事業価値喪失',
    costApprox: '100万-500万',
    notes: '管財人による清算。事業終了',
  },
];

// ========== 事業再生 ADR / REVIC / 中小機構 ==========

export const PRIVATE_REORGANIZATION = {
  '中小企業活性化協議会': {
    coverage: '全国47都道府県設置',
    targetCompany: '中小企業',
    process: 'プレ再生計画 → 金融機関調整 → 経営改善計画認定',
    timeframe: '3-12ヶ月',
    benefits: ['公的バックアップ', '無料相談', '専門家派遣'],
  },
  '事業再生ADR': {
    coverage: '全国',
    targetCompany: '中堅・大企業',
    process: '第三者機関 (JATP等) が金融債権者との調整',
    timeframe: '6-12ヶ月',
    benefits: ['法的整理回避', '商取引債権影響なし', '税務メリット'],
  },
  'REVIC (地域経済活性化支援機構)': {
    coverage: '地域中堅企業',
    targetCompany: '地域経済への影響大な企業',
    process: '出資 + 経営支援',
    timeframe: '3-5年',
    benefits: ['資本支援', '専門家派遣', '事業再生'],
  },
  '中小機構 (中小企業基盤整備機構)': {
    coverage: '全国',
    targetCompany: '中小企業',
    process: 'ファンド出資、専門家相談',
    timeframe: '1-3年',
    benefits: ['経営アドバイス', 'ファイナンス'],
  },
};

// ========== 倒産統計 2025 ==========

export const BANKRUPTCY_STATS_2025 = {
  totalCases2025: 10_425,
  yoyChange: '+4年連続増',
  laborShortageBankruptcies: 441,
  laborShortageNote: '過去最多',
  pricesInflationBankruptcies: 963,
  pricesInflationNote: '過去最多',
  industryBreakdown: [
    { industry: '介護事業', cases: 176, note: '過去最多 / 訪問介護91件 (R6マイナス改定影響)' },
    { industry: '美容業 (美容室)', cases: '増加', note: '3年連続増、フリーランス化で構造変化' },
    { industry: '飲食業', cases: '高水準', note: '原材料高+人手不足' },
    { industry: '小売業', cases: '高水準', note: 'EC圧迫' },
  ],
  source: '帝国データバンク / 東京商工リサーチ 2025',
};

// ========== 廃業フロー (廃業税制 + 経営者保証解除) ==========

export const HAIGYO_FLOW = {
  steps: [
    { phase: '検討期 (廃業6ヶ月-1年前)', tasks: ['廃業 vs M&A vs 承継 比較', '中小企業活性化協議会相談', '弁護士・税理士相談'] },
    { phase: '準備期 (廃業6ヶ月-3ヶ月前)', tasks: ['取引先通知', '従業員説明', '在庫処分計画', '債権回収', '資産売却'] },
    { phase: '実行期 (廃業-1ヶ月前 〜 廃業日)', tasks: ['株主総会 解散決議', '清算人選任', '官報公告', '解散登記'] },
    { phase: '清算期 (廃業日 〜 結了)', tasks: ['債権者公告 (2ヶ月以上)', '債権取立', '債務弁済', '残余財産分配', '清算結了登記'] },
    { phase: '事後対応', tasks: ['経営者保証解除 (経営者保証GL R5)', '個人として再出発', '税務申告 (清算事業年度)'] },
  ],
  taxBenefits: [
    '廃業税制: 一定要件で繰越欠損金の使用可',
    '会社清算所得 (旧法) は廃止、通常の法人税課税',
    '個人として: 残存資産確保 (経営者保証GL R5)',
  ],
};

/**
 * 倒産リスクから推奨対応を選定
 */
export function recommendTurnaroundOption(z: AltmanZResult, debtAmount: number): {
  primaryOption: string;
  alternativeOptions: string[];
  urgency: 'immediate' | 'high' | 'medium';
} {
  if (z.zone === 'distress') {
    if (debtAmount > 1_000_000_000) {
      return {
        primaryOption: '事業再生ADR',
        alternativeOptions: ['民事再生', 'スポンサー型再生 (REVIC)'],
        urgency: 'immediate',
      };
    }
    return {
      primaryOption: '中小企業活性化協議会 経由の再生計画',
      alternativeOptions: ['民事再生', '第二会社方式', '廃業 (経営者保証GL R5)'],
      urgency: 'immediate',
    };
  }
  if (z.zone === 'gray') {
    return {
      primaryOption: '経営改善計画 (中小企業活性化協議会)',
      alternativeOptions: ['銀行リスケ交渉', '事業承継・M&A検討'],
      urgency: 'high',
    };
  }
  return {
    primaryOption: '通常モニタリング継続',
    alternativeOptions: ['財務体質強化', '事業承継準備'],
    urgency: 'medium',
  };
}
