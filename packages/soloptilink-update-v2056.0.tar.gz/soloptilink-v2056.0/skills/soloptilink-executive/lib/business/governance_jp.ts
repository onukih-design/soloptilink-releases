/**
 * SoloptiLinkAI v2033.0 — Corporate Governance JP
 * Phase 45 Executive Cognitive Layer
 *
 * コーポレートガバナンスコード R6 改訂版 / 機関設計3類型 / 取締役会12ヶ月年間アジェンダ /
 * 株主総会フロー / Board Deck標準構成 / 中期経営計画策定。
 */

export interface CGCPrinciple {
  number: number;
  name: string;
  summary: string;
}

export const CGC_R6_PRINCIPLES: CGCPrinciple[] = [
  { number: 1, name: '株主の権利・平等性の確保', summary: '少数株主含め権利を実質的に確保。種類株式・買収防衛策の説明責任。' },
  { number: 2, name: '株主以外のステークホルダーとの適切な協働', summary: '従業員・顧客・取引先・地域社会との持続的価値創造。サステナビリティ。' },
  { number: 3, name: '適切な情報開示と透明性の確保', summary: '財務・非財務情報を有用かつ理解しやすく開示。英文開示推進。' },
  { number: 4, name: '取締役会等の責務', summary: '独立社外取締役プライム3分の1以上、過半数選任20.3% (2024)。指名・報酬委員会設置。' },
  { number: 5, name: '株主との対話', summary: '建設的対話の方針。中期経営計画の説明責任。資本コスト・PBR改善開示。' },
];

export interface KikanSekkei {
  type: '監査役会設置会社' | '監査等委員会設置会社' | '指名委員会等設置会社';
  auditBody: string;
  socialDirectorVoteRight: boolean;
  notes: string;
  jpAdoptionRate: string;
}

export const KIKAN_SEKKEI: KikanSekkei[] = [
  {
    type: '監査役会設置会社',
    auditBody: '監査役会 (3名以上、半数以上社外)',
    socialDirectorVoteRight: false,
    notes: '監査と監督が分離。日本に最も多い。',
    jpAdoptionRate: '上場約65%',
  },
  {
    type: '監査等委員会設置会社',
    auditBody: '監査等委員会 (3名以上、過半数社外)',
    socialDirectorVoteRight: true,
    notes: '2015年改正会社法導入。監査と監督を兼任。',
    jpAdoptionRate: '上場約34%',
  },
  {
    type: '指名委員会等設置会社',
    auditBody: '監査委員会含む3委員会 (各3名以上、過半数社外)',
    socialDirectorVoteRight: true,
    notes: '米国型。日本では少数派 (約100社程度)。',
    jpAdoptionRate: '上場約1%',
  },
];

// ========== 取締役会 年間アジェンダ (3月決算上場企業モデル) ==========

export interface BoardAgendaItem {
  month: number;
  topics: string[];
}

export const BOARD_ANNUAL_AGENDA: BoardAgendaItem[] = [
  { month: 4, topics: ['期初取締役会', '前期業績見込みと公表前準備', '新体制', '業務分担'] },
  { month: 5, topics: ['決算取締役会 (計算書類・事業報告承認)', '決算短信', '株主総会議案承認', '有報案'] },
  { month: 6, topics: ['株主総会前後の取締役会 (代表取締役選定、報酬決定、新任役員紹介)', 'Q1着地見通し'] },
  { month: 7, topics: ['Q1決算レビュー', '内部統制報告'] },
  { month: 8, topics: ['Q1決算開示', '夏季リスクモニタリング (天災BCP)'] },
  { month: 9, topics: ['上期見通し', 'サステナビリティ/ESGレビュー'] },
  { month: 10, topics: ['Q2 (上期) 決算取締役会', '中間配当', 'サクセッション議論'] },
  { month: 11, topics: ['Q2決算開示', '来期方針議論開始', '人事/報酬委員会'] },
  { month: 12, topics: ['中間報告書', '内部監査レビュー', '取締役会自己評価'] },
  { month: 1, topics: ['Q3決算速報', '次年度予算編成方針', 'コーポレートアクション検討'] },
  { month: 2, topics: ['Q3決算開示', '中計進捗', '機関設計レビュー'] },
  { month: 3, topics: ['期末対応', '来期事業計画承認', '新人事案', '内部統制システム'] },
];

// ========== Board Deck 標準構成 ==========

export interface BoardDeckSection {
  name: string;
  durationMinutes?: number;
  pages?: number;
  contents: string[];
}

export const MONTHLY_BOARD_DECK: BoardDeckSection[] = [
  { name: 'アジェンダ・前回議事録', durationMinutes: 3, contents: [] },
  { name: 'CEOレビュー', durationMinutes: 10, contents: ['業績ハイライト', '戦略進捗', '外部環境'] },
  { name: '財務レビュー', durationMinutes: 15, contents: ['PL/BS/CF', '予実', '見込み'] },
  { name: '事業セグメント別KPIレビュー', durationMinutes: 30, contents: ['各事業10-15分'] },
  { name: 'リスク・コンプラ報告', durationMinutes: 10, contents: ['インシデント', '監査指摘'] },
  { name: '決議事項', contents: ['個別議題'] },
  { name: '報告事項', contents: [] },
];

export const QUARTERLY_BOARD_DECK: BoardDeckSection[] = [
  { name: 'Executive Summary', pages: 1, contents: ['SCQA 1ページサマリ'] },
  { name: 'Financials', pages: 5, contents: ['PL/BS/CF', 'KPIダッシュボード'] },
  { name: '事業セグメント別レビュー', pages: 15, contents: ['各事業3ページ'] },
  { name: '戦略進捗', pages: 5, contents: ['中計KPI vs Actual'] },
  { name: '市場・競合分析', pages: 3, contents: [] },
  { name: '重要リスク・コンプラ', pages: 3, contents: [] },
  { name: 'ESG/サステナビリティ', pages: 5, contents: ['TCFD', '人的資本'] },
  { name: '人事・組織', pages: 2, contents: ['後継者計画', '離職率'] },
  { name: 'Appendix', pages: 10, contents: ['データ詳細'] },
];

// ========== 株主総会フロー (3月決算上場会社) ==========

export interface ShareholderMeetingMilestone {
  daysFromMeeting: number; // 開催日からの日数 (マイナス=前)
  task: string;
}

export const SHAREHOLDER_MEETING_FLOW: ShareholderMeetingMilestone[] = [
  { daysFromMeeting: -60, task: '計算書類・事業報告作成完了 (4月末目処)' },
  { daysFromMeeting: -45, task: '監査役監査・会計監査人監査完了 (5月中旬)' },
  { daysFromMeeting: -30, task: '決算取締役会で議案決定、計算書類・事業報告確定 (5月下旬)' },
  { daysFromMeeting: -21, task: '招集通知Web開示 (公開会社は2週間前必須、多くは3週間前)' },
  { daysFromMeeting: -14, task: '招集通知発送' },
  { daysFromMeeting: 0, task: '定時株主総会開催 (事業年度終了後3ヶ月以内)' },
  { daysFromMeeting: 7, task: '議事録作成、有価証券報告書提出' },
];

export const STANDARD_MEETING_AGENDA = [
  '議長挨拶',
  '監査報告',
  '事業報告・計算書類の報告',
  '議案上程・質疑応答 (シナリオ・想定問答集)',
  '採決',
];

export const STANDARD_RESOLUTIONS = [
  '計算書類承認',
  '剰余金処分',
  '取締役選任',
  '監査役選任',
  '退任役員退職慰労金',
  '定款変更',
  '株式報酬制度',
];

// ========== 中期経営計画策定 ==========

export const MID_TERM_PLAN_STEPS = [
  { step: 1, name: '長期ビジョン (10年) 策定', detail: 'パーパス、ありたい姿、ミッション' },
  { step: 2, name: 'バックキャスト', detail: '「間違いなくやってくる未来」から逆算' },
  { step: 3, name: '3-5年 KPI 設定', detail: 'ROIC, ROE, EBITDA Margin, 売上, 営業利益' },
  { step: 4, name: 'ROICツリー 分解', detail: '売上高営業利益率 × 投下資本回転率 → 現場KPIへ' },
  { step: 5, name: '投資配分 (Capital Allocation)', detail: '既存深耕/新規探索/M&A/株主還元' },
  { step: 6, name: '事業ポートフォリオ再構築', detail: '事業別ROICで成長/維持/縮小決定' },
  { step: 7, name: '資本コスト超過 (ROIC > WACC) モニタリング指標化', detail: '価値創造判定' },
];

/**
 * 現在月から次の取締役会議題を取得
 */
export function getNextBoardAgenda(currentMonth: number = new Date().getMonth() + 1): BoardAgendaItem {
  return (
    BOARD_ANNUAL_AGENDA.find((a) => a.month === currentMonth) ??
    BOARD_ANNUAL_AGENDA[0]
  );
}

/**
 * Board Deck 自動生成プロンプト
 */
export function generateBoardDeckPrompt(deckType: 'monthly' | 'quarterly'): string {
  const sections = deckType === 'monthly' ? MONTHLY_BOARD_DECK : QUARTERLY_BOARD_DECK;
  return [
    `# Board Deck 自動生成指示 (${deckType})`,
    '',
    '以下の構造で生成。Pyramid Principle (BLUF + 3根拠 + MECE) を厳守:',
    '',
    ...sections.map(
      (s, i) =>
        `${i + 1}. ${s.name}${
          s.durationMinutes ? ` (${s.durationMinutes}分)` : s.pages ? ` (${s.pages}ページ)` : ''
        }: ${s.contents.join(' / ')}`
    ),
    '',
    '**絶対ルール**:',
    '- 1ページ目に必ず Executive Summary (BLUF 50字)',
    '- 数字は「億・万」単位 + 3桁カンマ',
    '- 業界ベンチマーク比較を必ず併記',
    '- 反証データ・リスクシナリオを必ず1セクション含む',
    '- 信頼度ラベル (高/中/低) + 出典 + データ鮮度を全数値に付記',
  ].join('\n');
}
