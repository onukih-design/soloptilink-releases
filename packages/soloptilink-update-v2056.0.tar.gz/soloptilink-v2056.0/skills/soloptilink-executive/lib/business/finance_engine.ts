/**
 * SoloptiLinkAI v2033.0 — Finance Engine
 * Phase 45 Executive Cognitive Layer
 *
 * 経営者必須ファイナンス指標を計算式+2026最新ベンチマーク+警報閾値+日本コンテキストで内蔵。
 * 全指標 `{ name, formula, computeFn, benchmark2026, alertThreshold, jpContext }` 構造。
 */

export interface BenchmarkRange {
  best: string;
  good: string;
  median: string;
  warning: string;
  source: string;
}

export interface FinanceMetric<TIn = Record<string, number>> {
  id: string;
  name: string;
  jpName: string;
  formula: string;
  unit: string;
  computeFn: (input: TIn) => number;
  benchmark2026: Record<string, BenchmarkRange>;
  alertThreshold: { critical: string; warning: string };
  jpContext: string;
}

// ========== Unit Economics ==========

export const LTV: FinanceMetric<{ arpu: number; grossMargin: number; monthlyChurnRate: number }> = {
  id: 'LTV',
  name: 'Customer Lifetime Value',
  jpName: '顧客生涯価値',
  formula: 'LTV = ARPU × Gross Margin / Monthly Churn Rate',
  unit: 'JPY/USD per customer',
  computeFn: ({ arpu, grossMargin, monthlyChurnRate }) =>
    monthlyChurnRate > 0 ? (arpu * grossMargin) / monthlyChurnRate : Infinity,
  benchmark2026: {
    enterprise_saas: { best: '$200K+', good: '$100K', median: '$50K', warning: '<$30K', source: 'SaaS Hero 2026' },
    smb_saas: { best: '$20K+', good: '$10K', median: '$5K', warning: '<$3K', source: 'SaaS Hero 2026' },
    ec_dtc: { best: '4x AOV+', good: '3x AOV', median: '2x AOV', warning: '<1.5x AOV', source: 'Industry 2026' },
  },
  alertThreshold: { critical: 'LTV/CAC < 1', warning: 'LTV/CAC < 3' },
  jpContext: '日本SI受託は Land-and-Expand で LTV を伸ばす。単発受託はLTV計算不能',
};

export const CAC: FinanceMetric<{ smSpend: number; newCustomers: number }> = {
  id: 'CAC',
  name: 'Customer Acquisition Cost',
  jpName: '顧客獲得コスト',
  formula: 'CAC = S&M Total Spend / Number of New Customers',
  unit: 'JPY/USD per customer',
  computeFn: ({ smSpend, newCustomers }) => (newCustomers > 0 ? smSpend / newCustomers : Infinity),
  benchmark2026: {
    enterprise_saas: { best: '$50K-200K (ACV $100K+で許容)', good: '$30K', median: '$50K', warning: '$200K+', source: 'SaaS Hero 2026' },
    smb_saas: { best: '$500-1K', good: '$1K-3K', median: '$3K', warning: '$5K+', source: 'SaaS Hero 2026' },
    blended_b2b_saas: { best: '$1K', good: '$5K', median: '$15K', warning: '$25K+', source: 'SaaS Hero 2026' },
  },
  alertThreshold: { critical: 'CAC が3年で3倍化', warning: 'CAC が前年比1.5倍' },
  jpContext: '日本B2B Enterprise は訪問営業比率高くCAC高め (米国の1.3-1.8倍)',
};

export const CAC_PAYBACK: FinanceMetric<{ cac: number; monthlyGrossMargin: number; monthlyMRRPerCustomer: number }> = {
  id: 'CAC_PAYBACK',
  name: 'CAC Payback Period',
  jpName: 'CAC回収期間',
  formula: 'CAC ÷ (Monthly Gross Margin × Monthly MRR per Customer)',
  unit: 'months',
  computeFn: ({ cac, monthlyGrossMargin, monthlyMRRPerCustomer }) => {
    const denom = monthlyGrossMargin * monthlyMRRPerCustomer;
    return denom > 0 ? cac / denom : Infinity;
  },
  benchmark2026: {
    best_in_class: { best: '<12月', good: '12月', median: '15月', warning: '>18月', source: 'Proven SaaS 2026' },
    saas_median: { best: '12月', good: '15月', median: '18月', warning: '>24月', source: 'Proven SaaS 2026' },
    enterprise: { best: '<18月', good: '18月', median: '21月', warning: '>24月', source: 'Proven SaaS 2026' },
    smb: { best: '<8月', good: '10月', median: '12月', warning: '>18月', source: 'Proven SaaS 2026' },
  },
  alertThreshold: { critical: 'Payback > 24月', warning: 'Payback > 18月' },
  jpContext: '日本Enterprise SaaSは20月超が常態。「6ヶ月で回収」海外基準は適用不可',
};

export const RULE_OF_40: FinanceMetric<{ growthRatePct: number; ebitdaMarginPct: number }> = {
  id: 'RULE_OF_40',
  name: 'Rule of 40',
  jpName: 'ルール・オブ・40',
  formula: 'Growth Rate (%) + EBITDA Margin or FCF Margin (%) ≥ 40',
  unit: 'points',
  computeFn: ({ growthRatePct, ebitdaMarginPct }) => growthRatePct + ebitdaMarginPct,
  benchmark2026: {
    public_saas_median: { best: '>40 (上位20%)', good: '30-40', median: '28', warning: '<20', source: 'Aventis Advisors 2026' },
    private_saas: { best: '>30', good: '20-30', median: '12 (成長10%+EBITDA 6%)', warning: '<10', source: 'Aventis 2026' },
    jp_saas: { best: '>25', good: '20-25', median: '15-20', warning: '<10', source: '日本SaaS 2026推定' },
  },
  alertThreshold: { critical: 'Rule of 40 < 20', warning: 'Rule of 40 < 30' },
  jpContext: 'Rule of 40 達成企業は EV/Revenue 4.8x vs 未達 2.7x (74%バリュエーション・プレミアム)',
};

export const BURN_MULTIPLE: FinanceMetric<{ netBurn: number; netNewARR: number }> = {
  id: 'BURN_MULTIPLE',
  name: 'Burn Multiple',
  jpName: 'バーン・マルチプル',
  formula: 'Net Burn ÷ Net New ARR',
  unit: 'x (multiplier)',
  computeFn: ({ netBurn, netNewARR }) => (netNewARR > 0 ? netBurn / netNewARR : Infinity),
  benchmark2026: {
    amazing: { best: '<1.0x', good: '1.0-1.5x', median: '1.5-2.0x', warning: '2.0-3.0x', source: 'CFI / Bill Gurley' },
    danger: { best: '<1.0x', good: '1.0x', median: '2.0x', warning: '>3.0x (Series B撤退リスク)', source: 'CFI 2026' },
  },
  alertThreshold: { critical: 'Burn Multiple > 3x', warning: 'Burn Multiple > 2x' },
  jpContext: '2026年VC基準: 成長+利益 > 40 AND Burn Multiple < 2x',
};

export const NRR: FinanceMetric<{ startingMRR: number; expansion: number; churn: number; downsell: number }> = {
  id: 'NRR',
  name: 'Net Revenue Retention',
  jpName: '純収益維持率',
  formula: '(Starting MRR + Expansion - Churn - Downsell) / Starting MRR',
  unit: '%',
  computeFn: ({ startingMRR, expansion, churn, downsell }) =>
    startingMRR > 0 ? ((startingMRR + expansion - churn - downsell) / startingMRR) * 100 : 0,
  benchmark2026: {
    enterprise: { best: '>130%', good: '120%', median: '118%', warning: '<110%', source: 'SaaS Mag 2026' },
    mid_market: { best: '>120%', good: '110%', median: '108%', warning: '<100%', source: 'SaaS Mag 2026' },
    smb: { best: '>110%', good: '100%', median: '97%', warning: '<95%', source: 'SaaS Mag 2026' },
    overall_median: { best: '>120%', good: '110%', median: '101% (圧縮中)', warning: '<100%', source: 'SaaS Mag 2026' },
  },
  alertThreshold: { critical: 'NRR < 100% (純減)', warning: 'NRR < 110%' },
  jpContext: 'NRR 10pt 改善 = バリュエーション 20-30% 上昇',
};

export const CHURN_RATE: FinanceMetric<{ churnedCustomers: number; startingCustomers: number }> = {
  id: 'CHURN_RATE',
  name: 'Monthly Churn Rate',
  jpName: '月次解約率',
  formula: 'Churned Customers / Starting Customers (monthly)',
  unit: '%/month',
  computeFn: ({ churnedCustomers, startingCustomers }) =>
    startingCustomers > 0 ? (churnedCustomers / startingCustomers) * 100 : 0,
  benchmark2026: {
    b2b_avg: { best: '<2%', good: '2-3%', median: '3.5%', warning: '>5%', source: 'SaaS 2026' },
    enterprise: { best: '<0.5%', good: '0.5-1%', median: '1%', warning: '>2%', source: 'SaaS 2026' },
    smb_self_serve: { best: '<3%', good: '3-5%', median: '5%', warning: '>7%', source: 'SaaS 2026' },
  },
  alertThreshold: { critical: '月次Churn > 7%', warning: '月次Churn > 5%' },
  jpContext: '日本B2BはChurnが米国の半分 (継続気質)。米国基準そのまま当てはめると過剰反応',
};

export const MAGIC_NUMBER: FinanceMetric<{ netNewARRThisQuarter: number; smSpendLastQuarter: number }> = {
  id: 'MAGIC_NUMBER',
  name: 'Magic Number',
  jpName: 'マジックナンバー',
  formula: 'Net New ARR in Q_N ÷ S&M Spend in Q_{N-1}',
  unit: 'x',
  computeFn: ({ netNewARRThisQuarter, smSpendLastQuarter }) =>
    smSpendLastQuarter > 0 ? netNewARRThisQuarter / smSpendLastQuarter : 0,
  benchmark2026: {
    accelerate: { best: '>1.5', good: '1.0-1.5', median: '0.7-1.0', warning: '<0.5', source: 'Drivetrain 2026' },
  },
  alertThreshold: { critical: 'Magic Number < 0.5 が2Q連続', warning: 'Magic Number < 0.7' },
  jpContext: 'Magic Number < 0.5 で 2四半期連続 → 営業組織再構築シグナル',
};

// ========== Cashflow ==========

export const RUNWAY: FinanceMetric<{ cashBalance: number; monthlyBurn: number }> = {
  id: 'RUNWAY',
  name: 'Cash Runway',
  jpName: '資金持続月数',
  formula: 'Cash Balance ÷ Monthly Net Burn Rate',
  unit: 'months',
  computeFn: ({ cashBalance, monthlyBurn }) => (monthlyBurn > 0 ? cashBalance / monthlyBurn : Infinity),
  benchmark2026: {
    healthy: { best: '>18月', good: '12-18月', median: '12月', warning: '<6月', source: 'VC 2026' },
  },
  alertThreshold: { critical: 'Runway < 6月 (即時調達)', warning: 'Runway < 12月 (調達準備)' },
  jpContext: '日本中小は Runway 半年切ると倒産確率急上昇',
};

export const DSCR: FinanceMetric<{ operatingProfit: number; depreciation: number; principalRepayment: number; interest: number }> = {
  id: 'DSCR',
  name: 'Debt Service Coverage Ratio',
  jpName: '借入返済余裕率',
  formula: '(営業利益 + 減価償却費) ÷ (元金返済額 + 支払利息)',
  unit: 'x',
  computeFn: ({ operatingProfit, depreciation, principalRepayment, interest }) => {
    const ds = principalRepayment + interest;
    return ds > 0 ? (operatingProfit + depreciation) / ds : Infinity;
  },
  benchmark2026: {
    bank_approval: { best: '>2.0', good: '1.5-2.0', median: '1.2-1.5 (融資審査基準)', warning: '<1.0 (返済困難)', source: '日本地銀 2026' },
  },
  alertThreshold: { critical: 'DSCR < 1.0', warning: 'DSCR < 1.3' },
  jpContext: '日本地方銀行は DSCR > 1.3 を融資基準。1.0切ると実質返済原資不足',
};

export const CCC: FinanceMetric<{ dso: number; dio: number; dpo: number }> = {
  id: 'CCC',
  name: 'Cash Conversion Cycle',
  jpName: '現金循環日数',
  formula: 'DSO (売掛回転日数) + DIO (棚卸回転日数) - DPO (買掛回転日数)',
  unit: 'days',
  computeFn: ({ dso, dio, dpo }) => dso + dio - dpo,
  benchmark2026: {
    overall: { best: '<30日', good: '30-55日', median: '55.2日', warning: '>90日', source: 'Zaimani 2026' },
    amazon_reference: { best: '-30日 (買掛>売掛)', good: '0日', median: '55日', warning: '>90日', source: 'Reference' },
  },
  alertThreshold: { critical: 'CCC > 90日', warning: 'CCC が前年比+20日' },
  jpContext: '下請法60日支払で売掛が長い受託SIは CCC 悪化しやすい。2026年度末 約束手形廃止予定',
};

// ========== Valuation ==========

export const WACC: FinanceMetric<{ debt: number; equity: number; costOfDebt: number; costOfEquity: number; taxRate: number }> = {
  id: 'WACC',
  name: 'Weighted Average Cost of Capital',
  jpName: '加重平均資本コスト',
  formula: 'WACC = (D/V × rd × (1-t)) + (E/V × re)',
  unit: '%',
  computeFn: ({ debt, equity, costOfDebt, costOfEquity, taxRate }) => {
    const total = debt + equity;
    if (total <= 0) return 0;
    return ((debt / total) * costOfDebt * (1 - taxRate) + (equity / total) * costOfEquity) * 100;
  },
  benchmark2026: {
    listed_large_jp: { best: '<4%', good: '4-6%', median: '5%', warning: '>8%', source: '日本上場 2026' },
    sme_jp: { best: '<8%', good: '8-10%', median: '10%', warning: '>15%', source: '日本中小 2026' },
    startup_jp: { best: '<20%', good: '20-25%', median: '25-30%', warning: '>35%', source: '日本VC 2026' },
  },
  alertThreshold: { critical: 'ROIC < WACC (価値破壊)', warning: 'ROIC - WACC < 2pt' },
  jpContext: 'rf = 日本10年国債 ~1%、ERP = 5-7%、t = 30-34% (実効税率)',
};

export const ROIC: FinanceMetric<{ nopat: number; investedCapital: number }> = {
  id: 'ROIC',
  name: 'Return on Invested Capital',
  jpName: '投下資本利益率',
  formula: 'NOPAT / Invested Capital',
  unit: '%',
  computeFn: ({ nopat, investedCapital }) => (investedCapital > 0 ? (nopat / investedCapital) * 100 : 0),
  benchmark2026: {
    overall_jp: { best: '>15%', good: '10-15%', median: '5.8%', warning: '<WACC', source: 'EDINET 2026' },
    info_communication_jp: { best: '>20%', good: '15-20%', median: '12%', warning: '<10%', source: 'EDINET 2026' },
  },
  alertThreshold: { critical: 'ROIC < WACC', warning: 'ROIC - WACC < 2pt' },
  jpContext: '東証要請: PBR<1社は資本コスト改善開示義務',
};

export const EV_EBITDA: FinanceMetric<{ marketCap: number; debt: number; cash: number; ebitda: number }> = {
  id: 'EV_EBITDA',
  name: 'EV/EBITDA Multiple',
  jpName: 'EV/EBITDA倍率',
  formula: '(時価総額 + 有利子負債 - 現預金) / EBITDA',
  unit: 'x',
  computeFn: ({ marketCap, debt, cash, ebitda }) =>
    ebitda > 0 ? (marketCap + debt - cash) / ebitda : 0,
  benchmark2026: {
    overall_jp: { best: '6-8x', good: '6x', median: '7x', warning: '<4x or >15x', source: 'Zaimani 2026' },
    transportation_jp: { best: '5.6x', good: '5x', median: '5.6x', warning: '<3x', source: 'Zaimani 2026' },
    steel_jp: { best: '5.7x', good: '5x', median: '5.7x', warning: '<3x', source: 'Zaimani 2026' },
    services_jp: { best: '15.3x (中央値8.0x)', good: '8x', median: '15.3x', warning: '<5x', source: 'Zaimani 2026' },
    info_comm_jp: { best: '17.4x (中央値8.9x)', good: '8.9x', median: '17.4x', warning: '<6x', source: 'Zaimani 2026' },
    sme_mfg_jp: { best: '4x', good: '3x', median: '2-4x', warning: '<2x', source: '中小M&A 2026' },
    sme_it_jp: { best: '8x', good: '6x', median: '4-8x', warning: '<3x', source: '中小M&A 2026' },
  },
  alertThreshold: { critical: 'M&A価格 > 業界中央値1.5x', warning: 'M&A価格 > 業界中央値1.2x' },
  jpContext: '中小M&AはDCFよりEBITDA倍率が主流。2-8倍が現実値',
};

// ========== 黒字倒産予兆 ==========

export interface BlackBankruptcySigns {
  operatingCfNegativeQuarters: number;
  receivableDays: number;
  payableDays: number;
  monthlyRepayment: number;
  monthlyOperatingCf: number;
  taxArrears: boolean;
  cashflowForecastExists: boolean;
  noteJump: boolean;
}

export function detectBlackBankruptcyRisk(signs: BlackBankruptcySigns): {
  riskLevel: 'critical' | 'high' | 'medium' | 'low';
  triggeredSigns: string[];
  recommendation: string;
} {
  const triggered: string[] = [];

  if (signs.operatingCfNegativeQuarters >= 2) triggered.push('営業CFが2四半期連続マイナス');
  if (signs.receivableDays > signs.payableDays) triggered.push('売掛サイト > 支払サイト');
  if (signs.monthlyRepayment > signs.monthlyOperatingCf) triggered.push('借入返済額 > 営業CF');
  if (!signs.cashflowForecastExists) triggered.push('資金繰り表が未作成');
  if (signs.noteJump) triggered.push('支払手形のジャンプ');
  if (signs.taxArrears) triggered.push('税金/社会保険料の滞納');

  let riskLevel: 'critical' | 'high' | 'medium' | 'low' = 'low';
  if (triggered.length >= 4) riskLevel = 'critical';
  else if (triggered.length >= 3) riskLevel = 'high';
  else if (triggered.length >= 2) riskLevel = 'medium';

  const recommendation =
    riskLevel === 'critical'
      ? '【緊急】72時間以内に中小企業活性化協議会へ相談。経営者保証GL早期対応。'
      : riskLevel === 'high'
      ? '【要対応】2週間以内に資金繰り表3ヶ月先まで作成、メインバンク相談アポ取り。'
      : riskLevel === 'medium'
      ? '【注意】月次CFを毎週更新、回収遅延顧客リスト精査。'
      : '【健全】通常モニタリング継続。';

  return { riskLevel, triggeredSigns: triggered, recommendation };
}

// ========== 銀行格付シミュレーター ==========

export interface BankRatingInput {
  equityRatio: number; // 自己資本比率 %
  dscr: number;
  operatingProfitMargin: number; // %
  debtPaybackYears: number; // 債務償還年数
  businessEvaluationScore: number; // 0-100
}

export type BankRating = '正常先' | '要注意先' | '要管理先' | '破綻懸念先' | '実質破綻先' | '破綻先';

export function simulateBankRating(input: BankRatingInput): {
  rating: BankRating;
  confidence: number;
  reason: string[];
} {
  const reasons: string[] = [];
  let score = 0;

  if (input.equityRatio >= 30) score += 25;
  else if (input.equityRatio >= 15) score += 15;
  else if (input.equityRatio >= 5) score += 5;
  else reasons.push(`自己資本比率 ${input.equityRatio}% (10%未満で格付下落)`);

  if (input.dscr >= 1.5) score += 25;
  else if (input.dscr >= 1.2) score += 15;
  else if (input.dscr >= 1.0) score += 5;
  else reasons.push(`DSCR ${input.dscr} (1.0未満で実質返済不能)`);

  if (input.operatingProfitMargin >= 5) score += 20;
  else if (input.operatingProfitMargin >= 2) score += 10;
  else if (input.operatingProfitMargin >= 0) score += 5;
  else reasons.push(`営業利益率 ${input.operatingProfitMargin}% (赤字)`);

  if (input.debtPaybackYears <= 10) score += 20;
  else if (input.debtPaybackYears <= 20) score += 10;
  else reasons.push(`債務償還年数 ${input.debtPaybackYears}年 (20年超で要注意)`);

  if (input.businessEvaluationScore >= 70) score += 10;
  else if (input.businessEvaluationScore >= 50) score += 5;

  let rating: BankRating = '破綻先';
  if (score >= 80) rating = '正常先';
  else if (score >= 60) rating = '要注意先';
  else if (score >= 40) rating = '要管理先';
  else if (score >= 25) rating = '破綻懸念先';
  else if (score >= 10) rating = '実質破綻先';

  return { rating, confidence: Math.min(100, score), reason: reasons };
}

// ========== Export Master ==========

export const FINANCE_METRICS = {
  LTV, CAC, CAC_PAYBACK, RULE_OF_40, BURN_MULTIPLE, NRR, CHURN_RATE, MAGIC_NUMBER,
  RUNWAY, DSCR, CCC, WACC, ROIC, EV_EBITDA,
};

export const FINANCE_TOOLS = {
  detectBlackBankruptcyRisk,
  simulateBankRating,
};
