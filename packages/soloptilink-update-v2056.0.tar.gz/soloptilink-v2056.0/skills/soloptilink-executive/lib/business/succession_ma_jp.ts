/**
 * SoloptiLinkAI v2033.0 — Succession & M&A JP
 * Phase 45 Executive Cognitive Layer
 *
 * 事業承継税制 特例 (R9.3.31期限) / 中小M&Aガイドライン第3版 (R6.8) /
 * バリュエーション3手法 / レーマン方式 / PMI 100日プラン
 */

// ========== 事業承継税制 特例措置 ==========

export const BUSINESS_SUCCESSION_SPECIAL_TAX_REGIME = {
  name: '法人版事業承継税制 特例措置',
  effectivePeriod: '2018-04-01 〜 2027-12-31 (相続/贈与)',
  specialPlanDeadline: '2026-03-31 (特例承継計画提出期限)',
  deadlineUrgency: 'CRITICAL',
  benefits: [
    '対象株式: 全株式',
    '猶予税額: 100% (相続・贈与とも)',
    '雇用要件: 5年平均80%以上 (実質撤廃)',
    '後継者: 最大3人まで',
    '先代経営者: 代表権を有していた者ならOK',
  ],
  generalRegimeComparison: {
    '対象株式': '一般: 発行済議決権株式総数の2/3まで / 特例: 全株式',
    '猶予税額': '一般: 相続80% 贈与100% / 特例: 100%',
    '雇用要件': '一般: 5年平均80% / 特例: 実質撤廃',
    '後継者数': '一般: 1人 / 特例: 最大3人',
  },
  prerequisites: [
    '中小企業基本法上の中小企業者',
    '上場会社・風俗営業会社・資産管理会社でない',
    '常時使用従業員1人以上',
    '特例承継計画を都道府県知事へ2026-03-31までに提出 (出すだけはノーリスク)',
    '認定経営革新等支援機関の指導助言記載',
  ],
  recommendation: '提出だけならコストゼロ。後で使わなくても良い。2026-03-31期限を絶対に逃すな。',
};

// ========== 株式譲渡 vs 事業譲渡 vs 会社分割 ==========

export interface DealStructure {
  type: '株式譲渡' | '事業譲渡' | '会社分割';
  taxToSeller: string;
  taxToBuyer: string;
  liabilitiesAssumed: string;
  consentRequired: string[];
  bestFor: string[];
  notes: string;
}

export const DEAL_STRUCTURES: DealStructure[] = [
  {
    type: '株式譲渡',
    taxToSeller: '譲渡所得 20.315% (個人) / 法人税 (法人)',
    taxToBuyer: 'のれん償却なし',
    liabilitiesAssumed: '全包括承継 (簿外債務含む)',
    consentRequired: ['株主'],
    bestFor: ['シンプル', '事業継続性高', '個人売主'],
    notes: '最も一般的。簿外債務リスクをDDで防御',
  },
  {
    type: '事業譲渡',
    taxToSeller: '法人税 + 消費税課税',
    taxToBuyer: 'のれん償却可 (5年〜)、消費税仕入税額控除',
    liabilitiesAssumed: '個別承継 (選別可)',
    consentRequired: ['株主総会特別決議', '取引先', '従業員 (転籍同意)'],
    bestFor: ['一部事業切り出し', '簿外債務回避', '買主節税'],
    notes: '手続が煩雑、許認可再取得必要',
  },
  {
    type: '会社分割',
    taxToSeller: '適格分割なら課税繰延',
    taxToBuyer: '税制適格要件あり',
    liabilitiesAssumed: '包括承継 (分割計画書記載分)',
    consentRequired: ['株主総会特別決議', '債権者保護手続'],
    bestFor: ['組織再編', '事業切り出し+株式交付'],
    notes: '会社法上の組織再編手続',
  },
];

// ========== M&A手数料 (レーマン方式) ==========

export interface LehmanFeeTier {
  upperLimit: number; // 円
  ratePct: number;
}

export const LEHMAN_FEE_TIERS: LehmanFeeTier[] = [
  { upperLimit: 500_000_000, ratePct: 5 },
  { upperLimit: 1_000_000_000, ratePct: 4 },
  { upperLimit: 5_000_000_000, ratePct: 3 },
  { upperLimit: 10_000_000_000, ratePct: 2 },
  { upperLimit: Infinity, ratePct: 1 },
];

/**
 * レーマン方式による M&A仲介手数料計算
 */
export function calculateLehmanFee(dealValue: number): { totalFee: number; breakdown: { tier: string; amount: number; fee: number }[] } {
  let remaining = dealValue;
  let lower = 0;
  let totalFee = 0;
  const breakdown: { tier: string; amount: number; fee: number }[] = [];

  for (const tier of LEHMAN_FEE_TIERS) {
    if (remaining <= 0) break;
    const tierAmount = Math.min(remaining, tier.upperLimit - lower);
    const tierFee = tierAmount * (tier.ratePct / 100);
    totalFee += tierFee;
    breakdown.push({
      tier: `${(lower / 100_000_000).toFixed(0)}億〜${(Math.min(tier.upperLimit, dealValue) / 100_000_000).toFixed(0)}億`,
      amount: tierAmount,
      fee: tierFee,
    });
    remaining -= tierAmount;
    lower = tier.upperLimit;
  }

  return { totalFee, breakdown };
}

// ========== バリュエーション3手法 ==========

export interface ValuationMethod {
  name: string;
  formula: string;
  bestFor: string[];
  jpAdaptation: string;
  pitfalls: string[];
}

export const VALUATION_METHODS: ValuationMethod[] = [
  {
    name: '純資産+のれん法 (年買法)',
    formula: '時価純資産 + のれん (営業利益 × 3-5年)',
    bestFor: ['中小M&A定番', '簡便'],
    jpAdaptation: '中小M&Aの8割がこの方式。営業利益の2-5年分が中小相場',
    pitfalls: ['のれん年数の主観', '将来性無視'],
  },
  {
    name: 'EBITDAマルチプル法',
    formula: 'EBITDA × 業界マルチプル',
    bestFor: ['中堅以上', '同業上場参照'],
    jpAdaptation: '中小製造2-4x、中小サービス3-6x、中小IT 4-8x',
    pitfalls: ['業界マルチプル参照不適切', '一過性利益混入'],
  },
  {
    name: 'DCF法 (割引キャッシュフロー)',
    formula: 'Σ FCF_t / (1+WACC)^t + 継続価値',
    bestFor: ['大型', '将来CF読みやすい事業'],
    jpAdaptation: '中小ではあまり使われない。WACC算定が難',
    pitfalls: ['永続成長率g過大評価 (日本はg=0-1%)', 'WACC設定主観性'],
  },
];

// ========== DD (Due Diligence) チェックリスト ==========

export interface DDChecklist {
  type: '財務' | '税務' | '法務' | 'ビジネス' | 'IT' | '人事' | '環境';
  items: string[];
  redFlagThresholds: string[];
}

export const DD_CHECKLISTS: DDChecklist[] = [
  {
    type: '財務',
    items: [
      'PL/BS/CF 過去3-5期',
      '月次推移 (季節性)',
      '主要顧客上位10 (依存度)',
      '主要仕入先上位10',
      '在庫評価方法 + 滞留在庫',
      '売掛金エイジング',
      '減損兆候資産',
      '退職給付債務',
      '簿外債務 (リース/保証)',
      '関連当事者取引',
    ],
    redFlagThresholds: ['上位顧客依存度 > 30%', '簿外債務発見', '減損未計上'],
  },
  {
    type: '税務',
    items: [
      '法人税申告書 過去5期',
      '税務調査履歴',
      '繰延税金資産の回収可能性',
      '消費税課税区分',
      '電子帳簿保存法対応',
      '移転価格 (海外取引あり)',
    ],
    redFlagThresholds: ['未申告事案', '租税回避スキーム発覚'],
  },
  {
    type: '法務',
    items: [
      '訴訟・係争中の紛争',
      '契約書一覧 (顧客/仕入/賃貸/銀行)',
      '知的財産 (特許/商標/著作)',
      '許認可一覧',
      '株主構成',
      '反社チェック',
      '労務問題 (未払残業/ハラスメント)',
    ],
    redFlagThresholds: ['未払残業 (簿外債務化)', '反社関係', '主要契約に解約条項'],
  },
  {
    type: 'ビジネス',
    items: [
      '市場ポジション + シェア',
      '主要顧客との関係性',
      '営業組織 + キーパーソン',
      'プロダクトロードマップ',
      '競合分析',
      'マーケティング戦略',
    ],
    redFlagThresholds: ['キーパーソン離脱リスク', '主要顧客の解約予兆'],
  },
  {
    type: 'IT',
    items: [
      'システム構成図',
      'クラウド利用状況',
      'ライセンス遵守状況',
      'セキュリティ対策',
      '個人情報管理',
      'BCP/DR',
    ],
    redFlagThresholds: ['未対応の重大脆弱性', 'ライセンス違反'],
  },
  {
    type: '人事',
    items: [
      '従業員構成 + 給与水準',
      '退職金制度',
      'キーパーソン契約 (ロックアップ可否)',
      '労働組合',
      '人事評価制度',
      '残業実態',
    ],
    redFlagThresholds: ['キーパーソン契約欠落', '労働組合との対立'],
  },
  {
    type: '環境',
    items: ['土壌汚染履歴', 'PCB機器', '産廃処理委託', 'カーボン排出量', '事故履歴'],
    redFlagThresholds: ['土壌汚染', 'PCB機器の不適切処理'],
  },
];

// ========== 契約条件 (SPA) 主要項目 ==========

export const SPA_KEY_TERMS = {
  'SPA定義': 'Stock Purchase Agreement (株式譲渡契約)',
  '表明保証 (R&W)': '売主が一定事実を真実かつ正確と保証。財務/法務/税務/事業 各範囲',
  'アーンアウト': '成果連動型対価。KPI定義+会計方針固定+操作防止が肝。中小日本では浸透途上',
  'Escrow (預託)': '代金の一部を留保 (10-20%が一般的)。表明保証違反時の引当',
  '競業避止義務': '通常2-5年',
  'キーパーソンロックアップ': '経営陣の継続雇用 (2-3年)。報酬+株式インセンティブで設計',
  'MAC条項 (Material Adverse Change)': 'クロージング前の重大悪化で契約撤回権',
  '前提条件 (CP: Conditions Precedent)': 'クロージング前に満たすべき条件 (許認可承継・主要顧客同意等)',
};

// ========== 中小M&Aガイドライン 第3版 (R6.8) ==========

export const SME_MA_GUIDELINE_V3 = {
  effective: '2024-08-01',
  changes: [
    '仲介の規律強化 (FA/仲介の役割明確化)',
    '専門家活用の促進',
    '譲渡側経営者の意思決定支援',
    '譲受側のDD体制整備',
    'PMI重視',
    '不適切仲介事業者の排除',
  ],
  brokerSelectionCriteria: [
    'M&A支援機関登録',
    '中小M&A士育成への取組',
    'コンプライアンス体制',
    '報酬体系の透明性 (テール条項3-5年)',
    '事業承継・引継ぎ補助金 専門家活用枠 対象',
  ],
};

// ========== PMI 100日プラン ==========

export const PMI_100DAY_PLAN = [
  { day: 0, phase: 'Day 0 (Closing)', tasks: ['アナウンスメント (社内/取引先/銀行)', '代表者表敬', 'キーパーソン引止め'] },
  { day: 7, phase: '1週間以内', tasks: ['キーパーソン1on1', '顧客上位10社訪問', 'IT基盤接続検討'] },
  { day: 30, phase: '1ヶ月以内', tasks: ['組織図整理', '権限規程', '会計システム統合計画', '人事制度差異把握'] },
  { day: 60, phase: '2ヶ月以内', tasks: ['シナジー実現プロジェクト立上げ', '統合人事制度設計', 'ブランド整理'] },
  { day: 100, phase: '100日プラン完了', tasks: ['進捗レビュー', '次の100日プラン策定', '株主報告'] },
];

/**
 * 株式譲渡 vs 事業譲渡 推奨ロジック
 */
export function recommendDealStructure(input: {
  hasUnknownLiabilities: boolean;
  buyerWantsTaxBenefit: boolean;
  individualSeller: boolean;
  partialBusiness: boolean;
}): DealStructure {
  if (input.partialBusiness) return DEAL_STRUCTURES[1]; // 事業譲渡
  if (input.hasUnknownLiabilities) return DEAL_STRUCTURES[1]; // 事業譲渡で簿外回避
  if (input.buyerWantsTaxBenefit && !input.individualSeller) return DEAL_STRUCTURES[1]; // 事業譲渡でのれん償却
  return DEAL_STRUCTURES[0]; // 株式譲渡 (一般的)
}
