/**
 * SoloptiLinkAI v2033.0 — Decision Patterns 100
 * Phase 45 Executive Cognitive Layer
 *
 * 経営者の典型的100判断パターンを構造化。BOOST起動時にキーワード検出で関連判断を引込み、
 * 「考えるべき指標」「典型的誤り」「システムが提示すべき支援」を生成プロンプトに注入。
 */

export type DecisionCategory =
  | 'hr_org' | 'pricing_sales' | 'investment' | 'finance' | 'risk_compliance';

export interface DecisionPattern {
  id: string;
  name: string;
  category: DecisionCategory;
  trigger: string;
  keyMetrics: string[];
  commonMistakes: string[];
  systemSupport: string;
  jpContext: string;
  keywords: string[];
}

// ========== D-1. 人事・組織判断 (D001-D020) ==========

const HR_ORG: DecisionPattern[] = [
  {
    id: 'D001',
    name: '人を採用すべきか',
    category: 'hr_org',
    trigger: '現場から増員要求',
    keyMetrics: ['稼働率>85%', '残業時間>45h/月', '新規受注余力', 'Runway>12ヶ月'],
    commonMistakes: ['稼働率瞬間値で判断', '教育コスト3-6ヶ月を見落とす', '採用市場の難易度を過小評価'],
    systemSupport: '需要予測×現有稼働率×採用リードタイム3-6ヶ月でシミュレーション提示',
    jpContext: '正社員は解雇困難 → 業務委託/派遣で段階的に',
    keywords: ['採用', '増員', '人手不足', '人を採る', 'ヒトを増やす'],
  },
  {
    id: 'D002',
    name: '正社員 vs 業務委託 vs 派遣',
    category: 'hr_org',
    trigger: '新規ロール検討時',
    keyMetrics: ['長期確度', 'スキル特殊性', 'コスト比較 (社保込)', '法的リスク (偽装請負)'],
    commonMistakes: ['業務委託でも指揮命令で実態は雇用', '派遣3年ルール失念'],
    systemSupport: '雇用形態別TCO比較表+偽装請負リスク判定',
    jpContext: '労働者派遣法/職安法44条/民法632条',
    keywords: ['業務委託', '派遣', '正社員', '雇用形態', '請負'],
  },
  {
    id: 'D003',
    name: '賞与原資をいくら積むか',
    category: 'hr_org',
    trigger: '決算3ヶ月前',
    keyMetrics: ['労働分配率', '経常利益', '業界水準', '離職リスク'],
    commonMistakes: ['決算間際に決めて社員モチベ低下', '業績連動部分が不透明'],
    systemSupport: '労働分配率シミュレーション (賞与額別)',
    jpContext: '日本は夏冬2回。3-6ヶ月分が一般',
    keywords: ['賞与', 'ボーナス', '原資', '一時金'],
  },
  {
    id: 'D004',
    name: '管理職を増やすか減らすか',
    category: 'hr_org',
    trigger: '組織肥大化サイン',
    keyMetrics: ['スパンオブコントロール', '中間管理職比率', '意思決定速度'],
    commonMistakes: ['ポストで処遇 (no-real-role manager)', '管理職比率 > 20% で硬直化'],
    systemSupport: '組織図フラット化シミュレーション',
    jpContext: '日本企業の年功序列で管理職過多',
    keywords: ['管理職', 'マネージャー', '組織', '中間管理', 'スパン'],
  },
  {
    id: 'D005',
    name: '役員報酬の決定',
    category: 'hr_org',
    trigger: '事業年度開始前',
    keyMetrics: ['業績連動比率', '業界水準', '株主資本構成', '税効果'],
    commonMistakes: ['役員報酬で利益調整 → 否認リスク', '業績悪化期も維持で経営責任不明'],
    systemSupport: '業績連動報酬シミュレーション+定期同額・事前確定ルール照会',
    jpContext: '法人税法34条 (役員給与の損金算入要件)',
    keywords: ['役員報酬', '役員給与', '定期同額', '事前確定', '業績連動'],
  },
  {
    id: 'D006',
    name: '退職金制度の導入/廃止',
    category: 'hr_org',
    trigger: '人件費構造見直し',
    keyMetrics: ['退職給付債務', '勤続年数分布', '中退共加入可否'],
    commonMistakes: ['退職給付債務をBSに認識せず潜在債務化'],
    systemSupport: 'DB→DC移行シミュレーション',
    jpContext: '中退共/特退共/確定拠出年金',
    keywords: ['退職金', '退職給付', '中退共', '企業年金', 'DC'],
  },
  {
    id: 'D007',
    name: 'リモートワーク継続 vs 出社回帰',
    category: 'hr_org',
    trigger: 'コロナ後/オフィス賃料更新',
    keyMetrics: ['生産性', '離職率', 'オフィスコスト', 'イノベーション指標'],
    commonMistakes: ['二項対立で語る (実はハイブリッド)', '管理職の感覚で決める'],
    systemSupport: 'ロール別最適勤務形態マップ',
    jpContext: '2026年は出社回帰トレンド強。柔軟設計でリテンション維持',
    keywords: ['リモートワーク', '在宅', '出社', 'ハイブリッド', 'テレワーク'],
  },
  {
    id: 'D008',
    name: 'ストックオプション付与',
    category: 'hr_org',
    trigger: '採用/重要マイルストン達成',
    keyMetrics: ['希薄化%', 'Pool残量', 'ベスティング期間', '税制適格性'],
    commonMistakes: ['創業時の付与が多すぎて後で枯渇', '税制非適格で50%超課税'],
    systemSupport: '希薄化シミュレーション+税制適格チェック',
    jpContext: '税制適格SO: 権利行使価格≥時価, 年間1200万円以内 (経産省/法務省確認スタートアップは2400万円)',
    keywords: ['ストックオプション', 'SO', '希薄化', '新株予約権'],
  },
  {
    id: 'D009',
    name: '離職率が上がってきた',
    category: 'hr_org',
    trigger: '離職率前年比+30%',
    keyMetrics: ['離職理由', '在籍期間別離職率', 'エンゲージメントスコア', '市場給与水準'],
    commonMistakes: ['給与だけ原因と決めつけ', '退職者ヒアリングをしない'],
    systemSupport: '離職要因分析 (賃金/上司/業務/成長/家庭)',
    jpContext: '日本のエンゲージメント率7%、世界最低水準。離職予兆検知が重要',
    keywords: ['離職', '退職', '辞める', 'リテンション', 'エンゲージメント'],
  },
  {
    id: 'D010',
    name: '1on1/評価制度を変えるか',
    category: 'hr_org',
    trigger: '評価への不満顕在化',
    keyMetrics: ['評価納得度', '等級分布', '上司スキル'],
    commonMistakes: ['制度だけ変えて上司育成しない'],
    systemSupport: 'MBO/OKR/360°/Continuous Feedback の比較表',
    jpContext: '人事評価不満62.3%、最大要因「評価基準不明確」45.2%',
    keywords: ['評価制度', '1on1', 'OKR', 'MBO', '評価面談'],
  },
  {
    id: 'D011',
    name: '新卒採用を続けるか',
    category: 'hr_org',
    trigger: '中途比率増加',
    keyMetrics: ['新卒3年定着率', '新卒/中途の生産性比較', '教育コスト'],
    commonMistakes: ['新卒採用を伝統で継続', '教育投資との比較なし'],
    systemSupport: '新卒・中途TCO比較',
    jpContext: '日本は新卒一括採用慣行。中小は中途が現実的',
    keywords: ['新卒', '中途', '採用戦略'],
  },
  {
    id: 'D012',
    name: '外国人雇用',
    category: 'hr_org',
    trigger: '人手不足深刻化',
    keyMetrics: ['在留資格', '言語要件', '在職者多様性スコア'],
    commonMistakes: ['特定技能/技人国/留学生アルバイトの違いを知らず違法雇用'],
    systemSupport: '在留資格判定+違法雇用チェック',
    jpContext: '出入国管理法/技能実習法/特定技能',
    keywords: ['外国人雇用', '特定技能', '技能実習', '在留資格'],
  },
  {
    id: 'D013',
    name: 'メンタル休職者対応',
    category: 'hr_org',
    trigger: '1名以上の休職',
    keyMetrics: ['復職率', '再休職率', '労災認定可能性'],
    commonMistakes: ['放置で長期化', '復職判定基準が曖昧'],
    systemSupport: '復職プロトコル + 段階的復職プラン',
    jpContext: '労安法/労災保険/障害者雇用促進法',
    keywords: ['メンタル', '休職', '復職', '労災', '産業医'],
  },
  {
    id: 'D014',
    name: 'ハラスメント発生時',
    category: 'hr_org',
    trigger: '通報受領',
    keyMetrics: ['事実認定', '被害者保護', '再発防止策'],
    commonMistakes: ['加害者保護バイアス', '外部通報窓口なし'],
    systemSupport: 'パワハラ調査プロトコル',
    jpContext: 'パワハラ防止法 (2022~中小)/セクハラ/マタハラ',
    keywords: ['ハラスメント', 'パワハラ', 'セクハラ', 'マタハラ', '通報'],
  },
  {
    id: 'D015',
    name: '解雇/退職勧奨',
    category: 'hr_org',
    trigger: '成績/態度問題',
    keyMetrics: ['改善指導記録', '解雇理由相当性', '退職金加算額'],
    commonMistakes: ['即時解雇で不当解雇訴訟'],
    systemSupport: '改善指導記録テンプレ + 退職勧奨フロー',
    jpContext: '労契法16条 (解雇権濫用法理) → 整理解雇4要件',
    keywords: ['解雇', '退職勧奨', 'リストラ', '整理解雇'],
  },
  {
    id: 'D016',
    name: '管理職を抜擢か外部招聘か',
    category: 'hr_org',
    trigger: '重要ポスト空席',
    keyMetrics: ['内部候補スキルGap', '外部市場給与', '組織カルチャー影響'],
    commonMistakes: ['内部優先で実力不足', '外部招聘でカルチャー破壊'],
    systemSupport: '9-Box Grid 候補マップ',
    jpContext: '日本企業はカルチャーフィット重視傾向',
    keywords: ['抜擢', '外部招聘', '後継者', 'サクセッション'],
  },
  {
    id: 'D017',
    name: '副業解禁',
    category: 'hr_org',
    trigger: '従業員要望/採用競争力',
    keyMetrics: ['競業可能性', '労務管理 (労働時間通算)', '情報漏洩リスク'],
    commonMistakes: ['許可制を明文化せず曖昧運用'],
    systemSupport: '副業ルールテンプレ + 競業範囲チェック',
    jpContext: '副業推進政府方針 (働き方改革)',
    keywords: ['副業', '兼業', '複業'],
  },
  {
    id: 'D018',
    name: '賃上げ実施',
    category: 'hr_org',
    trigger: '業績好調/インフレ',
    keyMetrics: ['労働分配率', '業界水準', '持続可能性'],
    commonMistakes: ['業績悪化で減給は不可能 → 賃上げは一方通行'],
    systemSupport: '労分シミュレーション + 賃上げ持続可能性試算',
    jpContext: '業績連動賞与で柔軟性確保。2024-26 賃上げ機運強',
    keywords: ['賃上げ', 'ベースアップ', 'ベア', '昇給'],
  },
  {
    id: 'D019',
    name: '残業ルール改定',
    category: 'hr_org',
    trigger: '労基署是正勧告/働き方改革',
    keyMetrics: ['36協定上限', 'サブロク違反', '労災リスク'],
    commonMistakes: ['特別条項を慢性的に発動'],
    systemSupport: '36協定上限チェッカー + 月次残業ヒートマップ',
    jpContext: '労基法36条/月45h/年360h原則 (特別条項あり)',
    keywords: ['残業', '36協定', 'サブロク', '時間外労働'],
  },
  {
    id: 'D020',
    name: 'M&A後の人事統合 (PMI)',
    category: 'hr_org',
    trigger: 'クロージング前後',
    keyMetrics: ['キーパーソン残留', '等級差異', '退職金移行'],
    commonMistakes: ['処遇差別で文化崩壊', 'キーパーソンロックアップなし'],
    systemSupport: 'PMI 100日プラン + 等級マッピング',
    jpContext: '中小M&Aガイドライン第3版 PMI重視',
    keywords: ['PMI', 'M&A統合', '統合人事', '組織統合'],
  },
];

// ========== D-2. 価格・販売判断 (D021-D040) ==========

const PRICING_SALES: DecisionPattern[] = [
  {
    id: 'D021', name: '値上げすべきか', category: 'pricing_sales',
    trigger: '原価上昇/競合値上げ',
    keyMetrics: ['価格弾性', '競合価格', '顧客LTV', 'Churn予測'],
    commonMistakes: ['一律値上げで重要顧客を失う', '通告タイミング遅延'],
    systemSupport: 'セグメント別 値上げ→Churn確率シミュレーション',
    jpContext: 'BtoB日本は値上げ要請に消極的 → 価格改定理由書添付',
    keywords: ['値上げ', '価格改定', '値段上げ', 'プライス'],
  },
  {
    id: 'D022', name: '値引き要請への対応', category: 'pricing_sales',
    trigger: '大口顧客からの値引き要求',
    keyMetrics: ['案件粗利率', '代替顧客の有無', '戦略的価値'],
    commonMistakes: ['全社方針なく現場が個別判断'],
    systemSupport: '値引き承認ルール (粗利率別decision tree)',
    jpContext: '日本では「アンダー」と呼ばれる非公式値引き多発',
    keywords: ['値引き', 'ディスカウント', 'アンダー'],
  },
  {
    id: 'D023', name: 'プライシングモデル変更 (Subscription化等)', category: 'pricing_sales',
    trigger: 'ビジネスモデル転換',
    keyMetrics: ['NRR', 'Churn', 'CAC Payback'],
    commonMistakes: ['移行期に既存顧客を混乱'],
    systemSupport: '移行シナリオ + 顧客通知計画',
    jpContext: 'サブスク移行は会計税務処理 (繰延収益) も検討',
    keywords: ['サブスク', 'subscription', 'プライシング', '料金体系'],
  },
  {
    id: 'D024', name: '競合の値下げに追随するか', category: 'pricing_sales',
    trigger: '競合の値下げ発表',
    keyMetrics: ['価格弾性', '代替難度', 'ブランド毀損リスク'],
    commonMistakes: ['条件反射で追随 → 価格戦争スパイラル'],
    systemSupport: '価格戦争シミュレーション (3社均衡解)',
    jpContext: '日本市場の価格戦争は値戻し困難',
    keywords: ['価格競争', '値下げ追随', '価格戦争'],
  },
  {
    id: 'D025', name: '新製品の価値ベース価格設定', category: 'pricing_sales',
    trigger: '新製品ローンチ',
    keyMetrics: ['顧客の Willingness to Pay', '競合機能差', '粗利率目標'],
    commonMistakes: ['原価+%だけで決める'],
    systemSupport: 'Van Westendorp PSM 価格感度測定',
    jpContext: '日本市場は機能比較表が刺さる',
    keywords: ['新製品価格', 'プライシング', '価値ベース'],
  },
  {
    id: 'D026', name: '営業の歩合制度を変えるか', category: 'pricing_sales',
    trigger: '営業効率低下',
    keyMetrics: ['Sales Productivity', '離職率', '新規/既存バランス'],
    commonMistakes: ['短期売上のみ評価で長期関係毀損'],
    systemSupport: 'インセンティブ設計シミュレーション',
    jpContext: '日本は歩合制度導入率低い (固定+業績賞与が主)',
    keywords: ['歩合', 'コミッション', '営業インセンティブ', 'SPIFF'],
  },
  {
    id: 'D027', name: '新規顧客 vs 既存深耕', category: 'pricing_sales',
    trigger: '予算配分会議',
    keyMetrics: ['NRR', 'CAC', 'Acquisition vs Expansion ROI'],
    commonMistakes: ['新規偏重で NRR 低下'],
    systemSupport: 'Acquisition/Expansion 投資ROI比較',
    jpContext: '中小は既存深耕6: 新規4 が標準配分',
    keywords: ['新規開拓', '既存顧客', '深耕', 'Land-and-Expand'],
  },
  {
    id: 'D028', name: '販売代理店契約', category: 'pricing_sales',
    trigger: '販路拡大検討',
    keyMetrics: ['代理店マージン', '直販vs代理店ROI', 'ブランドコントロール'],
    commonMistakes: ['契約期間長く解約困難に'],
    systemSupport: '代理店契約テンプレ + 解約条項',
    jpContext: '日本の代理店契約は3-5年が標準',
    keywords: ['代理店', 'パートナー', 'ディストリビューター'],
  },
  { id: 'D029', name: '返品ポリシー変更', category: 'pricing_sales', trigger: '返品率上昇/競合', keyMetrics: ['返品率', '返品コスト', '顧客満足'], commonMistakes: ['返品厳格化で顧客離反'], systemSupport: '返品コスト試算', jpContext: '特商法 通信販売返品ルール', keywords: ['返品', '返金'] },
  { id: 'D030', name: '在庫引当方針', category: 'pricing_sales', trigger: '在庫評価変動', keyMetrics: ['滞留在庫', '評価損'], commonMistakes: ['先入先出と移動平均を混用'], systemSupport: '在庫評価方法選択', jpContext: '会計基準 棚卸資産評価', keywords: ['在庫評価', '棚卸'] },
  { id: 'D031', name: 'サブスク年払い割引 vs 月払い', category: 'pricing_sales', trigger: 'CF改善ニーズ', keyMetrics: ['Annual Churn vs Monthly Churn', 'CAC Payback短縮'], commonMistakes: ['割引大きすぎで利益毀損'], systemSupport: '年払い割引%シミュレーション', jpContext: 'SaaS日本は月払い文化強い', keywords: ['年払い', '月払い', '年契約'] },
  { id: 'D032', name: 'フリーミアム導入', category: 'pricing_sales', trigger: 'PLG戦略検討', keyMetrics: ['Free→Paid転換率', '無料ユーザーコスト'], commonMistakes: ['無料ユーザーがリソースを圧迫'], systemSupport: 'Free-to-Paid転換ファネル', jpContext: '日本B2Bでフリーミアムは限定的に効く', keywords: ['フリーミアム', '無料プラン', 'freemium'] },
  { id: 'D033', name: 'Enterprise向けカスタマイズ受託', category: 'pricing_sales', trigger: '大型案件カスタマイズ要求', keyMetrics: ['プロダクト分岐リスク', '機会費用'], commonMistakes: ['1社向けカスタマイズで本流停滞'], systemSupport: 'カスタマイズ vs プロダクト化判定', jpContext: '日本SI受託は分岐リスク常時', keywords: ['カスタマイズ', 'OEM', '受託開発'] },
  { id: 'D034', name: '支払サイト交渉', category: 'pricing_sales', trigger: 'CCC悪化', keyMetrics: ['DSO/DPO', '取引先パワーバランス'], commonMistakes: ['一律短縮で取引先関係悪化'], systemSupport: '支払サイト交渉シミュレーション', jpContext: '下請法60日上限 / 2026年度末手形廃止', keywords: ['支払サイト', '回収サイト', 'DSO', 'DPO'] },
  { id: 'D035', name: '海外向け価格設定', category: 'pricing_sales', trigger: '輸出開始', keyMetrics: ['為替リスク', '現地競合価格', '輸送コスト'], commonMistakes: ['国内価格をそのまま$換算'], systemSupport: '国別価格戦略', jpContext: 'ASEAN/北米別の現実価格レンジ', keywords: ['海外価格', '輸出価格', '国別価格'] },
  { id: 'D036', name: '為替ヘッジ', category: 'pricing_sales', trigger: '為替変動リスク', keyMetrics: ['輸出入金額', '為替感応度'], commonMistakes: ['投機的ポジション化'], systemSupport: '為替予約 vs オプション比較', jpContext: '中小は1年内予約が現実的', keywords: ['為替ヘッジ', '為替予約', 'FX'] },
  { id: 'D037', name: '競合との価格情報共有許可範囲', category: 'pricing_sales', trigger: '独禁法違反リスク', keyMetrics: ['情報共有の合法性'], commonMistakes: ['業界団体での価格共有でカルテル疑義'], systemSupport: '独禁法 ガイドライン照会', jpContext: '独禁法 課徴金 売上10%', keywords: ['カルテル', '独禁法', '価格共有'] },
  { id: 'D038', name: '顧客満足度低下時の値引き対応', category: 'pricing_sales', trigger: 'クレーム/NPS低下', keyMetrics: ['不満要因', '修復コスト'], commonMistakes: ['値引きで顧客の値引き要求を学習'], systemSupport: '値引き以外の代替提案', jpContext: '日本顧客は誠意ある対応を重視', keywords: ['顧客満足', 'クレーム対応'] },
  { id: 'D039', name: 'アップセル/クロスセル戦略', category: 'pricing_sales', trigger: 'NRR向上ニーズ', keyMetrics: ['セグメント別Expansion確率'], commonMistakes: ['全顧客一律アプローチ'], systemSupport: 'Expansion Playbook 自動生成', jpContext: '日本SI のLand-and-Expand', keywords: ['アップセル', 'クロスセル', 'expansion'] },
  { id: 'D040', name: 'プロダクトアウトvsマーケットインの優先', category: 'pricing_sales', trigger: '製品ロードマップ策定', keyMetrics: ['技術優位 vs 市場ニーズ'], commonMistakes: ['プロダクトアウトに偏り市場乖離'], systemSupport: 'JTBD分析 + 競合機能差', jpContext: '日本製造業 はプロダクトアウト傾向強', keywords: ['プロダクトアウト', 'マーケットイン', 'JTBD'] },
];

// ========== D-3. 投資・撤退判断 (D041-D060) ==========

const INVESTMENT: DecisionPattern[] = [
  {
    id: 'D041', name: '新規事業に投資すべきか', category: 'investment',
    trigger: '事業提案受領',
    keyMetrics: ['NPV', 'IRR vs Hurdle Rate (15-20%)', 'リアルオプション価値', 'コア事業との関連性'],
    commonMistakes: ['熱意で意思決定', '撤退基準を事前に定めない'],
    systemSupport: 'Lean Canvas + NPV シミュレーション + Pre-mortem',
    jpContext: '中小は多角化失敗が9割。本業集中が王道',
    keywords: ['新規事業', '事業投資', '多角化'],
  },
  {
    id: 'D042', name: '赤字部門を畳むか', category: 'investment',
    trigger: '2期連続赤字',
    keyMetrics: ['貢献利益', '撤退コスト (退職金/解約金)', 'シナジー (他事業への影響)'],
    commonMistakes: ['貢献利益でなく営業利益で判断', 'サンクコストに引きずられ撤退遅れ'],
    systemSupport: '貢献利益分析+撤退基準照会',
    jpContext: '中小は3年連続赤字で撤退ルール推奨',
    keywords: ['撤退', '事業撤退', '赤字部門', '事業整理'],
  },
  { id: 'D043', name: '設備投資のタイミング', category: 'investment', trigger: '受注増加/古い設備', keyMetrics: ['稼働率', 'ROI', 'Payback Period', 'Real Option Value'], commonMistakes: ['需要ピークで設備投資 → 後で過剰'], systemSupport: '需要予測+稼働率トレンド', jpContext: 'ものづくり補助金活用 機会', keywords: ['設備投資', 'capex', '機械購入'] },
  { id: 'D044', name: 'M&Aを実行するか', category: 'investment', trigger: '案件持込み', keyMetrics: ['DD結果', 'シナジー定量化', '希薄化', 'PMI実行力'], commonMistakes: ['シナジーを過大評価', 'PMI軽視'], systemSupport: 'DD チェックリスト + シナジー試算', jpContext: '中小M&Aガイドライン第3版 R6.8', keywords: ['M&A', '買収', '合併'] },
  { id: 'D045', name: '海外進出', category: 'investment', trigger: '国内市場頭打ち', keyMetrics: ['現地パートナー', '規制', '為替リスク', '人材'], commonMistakes: ['駐在員任せでガバナンス不在'], systemSupport: '国別進出評価', jpContext: 'ASEAN/北米 が中小日本企業の現実解', keywords: ['海外進出', '海外展開', '進出'] },
  { id: 'D046', name: 'R&D投資配分', category: 'investment', trigger: '年度予算策定', keyMetrics: ['既存改良 vs 新規 (H1/H2/H3)', '技術成熟度'], commonMistakes: ['既存改良に偏り破壊的イノベーションを逃す'], systemSupport: 'H1/H2/H3 配分テンプレ', jpContext: '7:2:1ルール', keywords: ['R&D', '研究開発', '技術投資'] },
  { id: 'D047', name: 'DX投資の優先順位', category: 'investment', trigger: 'DX計画策定', keyMetrics: ['ROI 試算', '現場受容度', 'リスク'], commonMistakes: ['ベンダー丸投げ'], systemSupport: 'DX投資ポートフォリオ', jpContext: 'DX認定/DXセレクション/IT導入補助金', keywords: ['DX', 'デジタル化', 'IT投資'] },
  { id: 'D048', name: 'クラウド移行 vs オンプレ維持', category: 'investment', trigger: 'システム更改時期', keyMetrics: ['5年TCO', 'セキュリティ要件'], commonMistakes: ['クラウド盲信でTCO逆転'], systemSupport: 'TCO 5年シミュレーション', jpContext: '官公庁系はガバメントクラウド', keywords: ['クラウド移行', 'オンプレ', 'TCO'] },
  { id: 'D049', name: 'AI導入投資', category: 'investment', trigger: 'AI業務効率化', keyMetrics: ['業務代替可能性', 'データ品質', '導入工数'], commonMistakes: ['PoCで止まる'], systemSupport: 'AI ROI試算 + データ準備チェック', jpContext: '2026年AI導入加速期', keywords: ['AI導入', 'AI投資', '生成AI'] },
  { id: 'D050', name: '工場移転/閉鎖', category: 'investment', trigger: 'コスト構造見直し', keyMetrics: ['移転コスト', '従業員影響', '取引先影響'], commonMistakes: ['労使協議軽視'], systemSupport: '移転コスト+労使協議プロトコル', jpContext: '労組がある場合は事前協議必須', keywords: ['工場移転', '工場閉鎖', '集約'] },
  { id: 'D051', name: '本社移転', category: 'investment', trigger: '賃料/採用/ブランド', keyMetrics: ['移転コスト', '採用影響'], commonMistakes: ['見栄えだけで判断'], systemSupport: '移転TCO', jpContext: '都心 vs 郊外 採用力比較', keywords: ['本社移転', 'オフィス移転'] },
  { id: 'D052', name: '上場 (IPO) を目指すか', category: 'investment', trigger: '事業成長/資金調達', keyMetrics: ['上場基準', '管理体制', '創業者持株'], commonMistakes: ['管理体制構築コスト軽視'], systemSupport: 'IPOチェックリスト Iの部', jpContext: '東証 グロース/スタンダード/プライム', keywords: ['IPO', '上場', '新規公開'] },
  { id: 'D053', name: '上場廃止 (MBO/TOB)', category: 'investment', trigger: '株価低迷/事業再編', keyMetrics: ['プレミアム', '資金調達', '少数株主対応'], commonMistakes: ['少数株主訴訟リスク'], systemSupport: 'MBO/TOBプロセス', jpContext: 'スクイーズアウト判例蓄積', keywords: ['MBO', 'TOB', '上場廃止', 'going private'] },
  { id: 'D054', name: '事業承継', category: 'investment', trigger: '経営者60歳超', keyMetrics: ['後継者有無', '株式承継', '税負担'], commonMistakes: ['特例承継計画 R9.3.31期限を逃す'], systemSupport: '事業承継税制活用判定', jpContext: '特例承継計画 R9.3.31提出期限 / 中小M&Aガイドライン第3版', keywords: ['事業承継', '後継者', '相続'] },
  { id: 'D055', name: '持株会社化', category: 'investment', trigger: 'グループ再編', keyMetrics: ['税効果', 'ガバナンス', '事業切り出し容易性'], commonMistakes: ['HD化で間接費膨張'], systemSupport: 'HD化シミュレーション', jpContext: '中小企業もHD化メリットあり', keywords: ['持株会社', 'HD', 'ホールディングス'] },
  { id: 'D056', name: '子会社統廃合', category: 'investment', trigger: 'グループ最適化', keyMetrics: ['統合シナジー', '税効果'], commonMistakes: ['統合効果を過大評価'], systemSupport: 'グループ再編シミュレーション', jpContext: '適格合併要件', keywords: ['子会社統合', 'グループ再編'] },
  { id: 'D057', name: 'ベンチャー出資 (CVC)', category: 'investment', trigger: '新規領域探索', keyMetrics: ['戦略リターン vs 財務リターン', 'シナジー期待'], commonMistakes: ['財務リターンばかり追う'], systemSupport: 'CVC投資基準 + Exit試算', jpContext: 'CVC日本2026 増加トレンド', keywords: ['CVC', 'ベンチャー出資'] },
  { id: 'D058', name: '新規プロダクト撤退基準', category: 'investment', trigger: '新製品立ち上げ前', keyMetrics: ['Kill Criteria 事前合意'], commonMistakes: ['事前未定義で撤退できず'], systemSupport: 'Kill Criteria テンプレ', jpContext: 'Stage Gate プロセス', keywords: ['撤退基準', 'kill criteria', 'stage gate'] },
  { id: 'D059', name: '売却 (Carve-out)', category: 'investment', trigger: '事業ポートフォリオ整理', keyMetrics: ['事業価値', 'シナジー喪失'], commonMistakes: ['切り出しで間接費がコア事業に重く残る'], systemSupport: 'カーブアウト試算', jpContext: 'カーブアウトM&A 増加', keywords: ['カーブアウト', '事業売却'] },
  { id: 'D060', name: '事業再生 ADR/民事再生', category: 'investment', trigger: '債務超過/支払不能', keyMetrics: ['再生可能性', '債権者同意'], commonMistakes: ['法的整理を最終手段化しすぎる'], systemSupport: '再生スキーム選択フロー', jpContext: '中小企業活性化協議会経由', keywords: ['事業再生', '民事再生', 'ADR'] },
];

// ========== D-4. 資金・財務判断 (D061-D080) ==========

const FINANCE: DecisionPattern[] = [
  {
    id: 'D061', name: '増資 vs 借入', category: 'finance',
    trigger: '資金調達ニーズ',
    keyMetrics: ['希薄化', 'WACC', 'BS構造', '経営権影響'],
    commonMistakes: ['増資で希薄化過大', '借入で財務体質悪化'],
    systemSupport: '資本構成シミュレーション (借入金利+希薄化%+ROE変化)',
    jpContext: '日本中小はまず借入、エクイティは最後の選択肢が標準',
    keywords: ['増資', '借入', 'デットファイナンス', 'エクイティ'],
  },
  { id: 'D062', name: 'メインバンク変更', category: 'finance', trigger: '条件悪化/担当者交代', keyMetrics: ['金利', '融資枠', '事業性評価', '緊急時対応'], commonMistakes: ['信頼関係を失う'], systemSupport: 'バンク比較', jpContext: 'メインバンク変更は最終手段', keywords: ['メインバンク', '銀行変更'] },
  { id: 'D063', name: 'リスケ申請', category: 'finance', trigger: 'DSCR<1継続', keyMetrics: ['再生計画妥当性', '金融機関調整'], commonMistakes: ['リスケ実施でプロパー枠停止/新規借入困難'], systemSupport: '再生計画書テンプレ', jpContext: '中小企業活性化協議会経由が標準', keywords: ['リスケ', '返済猶予', 'リスケジュール'] },
  { id: 'D064', name: '補助金申請するか', category: 'finance', trigger: '公募開始', keyMetrics: ['採択率', '申請工数', '後払いキャッシュ負担'], commonMistakes: ['補助金頼みの事業設計'], systemSupport: '補助金マッチング + 採択率予測', jpContext: '2026年は新事業進出ものづくり/デジタル化AI/省力化投資が主軸', keywords: ['補助金', '助成金', '事業再構築'] },
  { id: 'D065', name: '資本金変更', category: 'finance', trigger: '中小特例維持/取引先要件', keyMetrics: ['税率変化', '外形標準課税', '公的認可'], commonMistakes: ['資本金1億超で中小特例失効'], systemSupport: '資本金影響シミュレーション', jpContext: '資本金1億円超で大法人扱い', keywords: ['資本金', '増資', '減資'] },
  { id: 'D066', name: 'ファクタリング利用', category: 'finance', trigger: '緊急資金ニーズ', keyMetrics: ['手数料率', '依存リスク'], commonMistakes: ['常用化で財務体質悪化'], systemSupport: '2社間/3社間/オンライン比較', jpContext: '手数料1-20% 緊急時のみ', keywords: ['ファクタリング'] },
  { id: 'D067', name: '為替予約/通貨ヘッジ', category: 'finance', trigger: '為替変動', keyMetrics: ['ヘッジ比率', '機会損失'], commonMistakes: ['100%ヘッジで好機逃す'], systemSupport: 'ヘッジ比率最適化', jpContext: '中小は1年内予約', keywords: ['為替予約', 'ヘッジ'] },
  { id: 'D068', name: '保険加入 (D&O/PL/サイバー)', category: 'finance', trigger: 'リスク移転', keyMetrics: ['補償額', '保険料', '免責'], commonMistakes: ['補償範囲を読まずに加入'], systemSupport: '保険ポートフォリオ', jpContext: 'サイバー保険2026急増', keywords: ['保険', 'D&O', 'PL保険', 'サイバー保険'] },
  { id: 'D069', name: '節税スキーム導入', category: 'finance', trigger: '利益計上見込', keyMetrics: ['税効果', '実態経済性'], commonMistakes: ['過度な節税で税務調査'], systemSupport: '節税ホワイト/グレー判定', jpContext: '租税回避否認リスク', keywords: ['節税', '税務'] },
  { id: 'D070', name: '退職給付制度変更', category: 'finance', trigger: '退職給付債務膨張', keyMetrics: ['債務残高', 'DC移行コスト'], commonMistakes: ['労使協議軽視'], systemSupport: 'DB→DC移行シミュレーション', jpContext: 'DC普及加速', keywords: ['退職給付', 'DB', 'DC'] },
  { id: 'D071', name: '持株会導入', category: 'finance', trigger: '社員エンゲージメント', keyMetrics: ['希薄化', '配当負担'], commonMistakes: ['法令整備不足'], systemSupport: '持株会規約テンプレ', jpContext: '従業員持株会 税制優遇', keywords: ['持株会', '従業員持株'] },
  { id: 'D072', name: '自己株式取得', category: 'finance', trigger: '株主還元/資本効率', keyMetrics: ['1株純資産', 'PBR改善'], commonMistakes: ['資金不足で配当原資毀損'], systemSupport: '自社株買い試算', jpContext: '東証PBR<1要請', keywords: ['自社株買い', '自己株式'] },
  { id: 'D073', name: '配当政策', category: 'finance', trigger: '株主還元方針', keyMetrics: ['配当性向', '配当利回り', 'DOE'], commonMistakes: ['配当を急減して株主訴訟'], systemSupport: '配当シミュレーション', jpContext: '東証配当性向30%目標', keywords: ['配当', '配当性向', 'DOE'] },
  { id: 'D074', name: '予算修正 (期中)', category: 'finance', trigger: '見込乖離20%', keyMetrics: ['乖離原因', '挽回可能性'], commonMistakes: ['楽観修正'], systemSupport: '予算修正テンプレ', jpContext: '上場企業は適時開示判断', keywords: ['予算修正', '見通し修正', 'ガイダンス'] },
  { id: 'D075', name: '会計方針変更', category: 'finance', trigger: '監査法人指摘/制度改正', keyMetrics: ['BS/PL影響', '比較可能性'], commonMistakes: ['遡及修正の重要性軽視'], systemSupport: '影響額シミュレーション', jpContext: 'IFRS 任意適用', keywords: ['会計方針', '監査', 'IFRS'] },
  { id: 'D076', name: '監査法人変更', category: 'finance', trigger: '報酬/方針対立', keyMetrics: ['監査品質', '報酬', '引継ぎ'], commonMistakes: ['期末直前の変更'], systemSupport: '監査法人比較', jpContext: '監査人交代理由開示義務', keywords: ['監査法人', '監査人変更'] },
  { id: 'D077', name: '減損損失計上', category: 'finance', trigger: 'Trigger Event発生', keyMetrics: ['回収可能価額', '兆候判定'], commonMistakes: ['計上先延ばし'], systemSupport: '減損兆候チェック', jpContext: '日本基準とIFRSで処理差異', keywords: ['減損', 'impairment'] },
  { id: 'D078', name: '貸倒引当金積み増し', category: 'finance', trigger: '与信先信用悪化', keyMetrics: ['予想損失率', '担保'], commonMistakes: ['引当不足で粉飾疑義'], systemSupport: '引当金シミュレーション', jpContext: '個別引当 / 一般引当', keywords: ['貸倒引当', '引当金'] },
  { id: 'D079', name: '棚卸資産評価損', category: 'finance', trigger: '滞留在庫/陳腐化', keyMetrics: ['正味売却価額'], commonMistakes: ['評価損計上を先延ばし'], systemSupport: '在庫評価損試算', jpContext: '低価法強制', keywords: ['在庫評価損', '棚卸評価'] },
  { id: 'D080', name: '資産売却 (本業外)', category: 'finance', trigger: 'BS改善/資金捻出', keyMetrics: ['含み益', '売却益課税'], commonMistakes: ['本業必要資産まで売却'], systemSupport: '遊休資産特定', jpContext: '不動産売却 圧縮記帳', keywords: ['資産売却', '遊休資産'] },
];

// ========== D-5. リスク・コンプラ判断 (D081-D100) ==========

const RISK_COMPLIANCE: DecisionPattern[] = [
  {
    id: 'D081', name: '情報漏洩発生時の公表', category: 'risk_compliance',
    trigger: 'インシデント発生',
    keyMetrics: ['影響範囲', '個人情報該当性', '報告義務'],
    commonMistakes: ['公表先延ばしで信頼失墜'],
    systemSupport: '個情委報告フロー + 広報原稿テンプレ',
    jpContext: '個情法R4: 個人情報保護委員会へ速やかに報告 (3-5日)/本人通知',
    keywords: ['情報漏洩', '情報流出', '個人情報', 'インシデント'],
  },
  { id: 'D082', name: 'リコール実施', category: 'risk_compliance', trigger: '品質不具合発覚', keyMetrics: ['危険性', '影響台数', '回収コスト'], commonMistakes: ['初動遅延で消費者庁公表'], systemSupport: 'リコール判定フロー', jpContext: 'PL法/消費生活用製品安全法', keywords: ['リコール', '製品回収'] },
  { id: 'D083', name: '労災発生時対応', category: 'risk_compliance', trigger: '労災発生', keyMetrics: ['死傷者', '労基署届出', '再発防止'], commonMistakes: ['労基署届出遅延'], systemSupport: '労災対応Runbook', jpContext: '労安法 死傷病報告', keywords: ['労災', '労働災害'] },
  { id: 'D084', name: '訴訟提起/受領時', category: 'risk_compliance', trigger: '訴状', keyMetrics: ['勝訴可能性', '和解金額', '風評影響'], commonMistakes: ['弁護士相談前に対応'], systemSupport: '訴訟初動チェックリスト', jpContext: '時効/応訴対応', keywords: ['訴訟', '訴状', '裁判'] },
  { id: 'D085', name: '下請法違反指摘', category: 'risk_compliance', trigger: '公取委調査', keyMetrics: ['違反類型', '是正措置'], commonMistakes: ['書面交付義務軽視'], systemSupport: '下請法チェッカー', jpContext: '下請法60日支払/書面交付義務/減額禁止', keywords: ['下請法', '公取委', '下請取引'] },
  { id: 'D086', name: '独禁法 違反疑義', category: 'risk_compliance', trigger: 'カルテル疑義', keyMetrics: ['課徴金見込', 'リニエンシー可否'], commonMistakes: ['リニエンシー1番取り遅れ'], systemSupport: 'リニエンシー判定', jpContext: '課徴金売上10%', keywords: ['独禁法', 'カルテル', 'リニエンシー'] },
  { id: 'D087', name: '個人情報漏洩', category: 'risk_compliance', trigger: '漏洩発覚', keyMetrics: ['件数', '報告期限'], commonMistakes: ['速やかに(3-5日)報告失念'], systemSupport: '個情委報告書ドラフト', jpContext: '個情法R4 改正', keywords: ['個人情報', '個情法'] },
  { id: 'D088', name: '内部通報 (公益通報) 受領', category: 'risk_compliance', trigger: '通報受領', keyMetrics: ['通報者保護', '事実調査'], commonMistakes: ['通報者特定 (報復禁止違反)'], systemSupport: '公益通報対応プロトコル', jpContext: '公益通報者保護法R4', keywords: ['公益通報', '内部通報', '内部告発'] },
  { id: 'D089', name: '反社チェック陽性', category: 'risk_compliance', trigger: '反社検知', keyMetrics: ['関係解消', '契約解除'], commonMistakes: ['取引継続でレピュテーション失墜'], systemSupport: '反社排除条項発動フロー', jpContext: '暴対法/反社排除条項', keywords: ['反社', '暴力団', '反社チェック'] },
  { id: 'D090', name: '贈収賄/カルテル疑義', category: 'risk_compliance', trigger: '社内通報/外部指摘', keyMetrics: ['事実関係', '海外法令適用'], commonMistakes: ['FCPA/UKBA考慮漏れ'], systemSupport: '社内調査プロトコル', jpContext: '不正競争防止法/外国公務員贈賄罪', keywords: ['贈収賄', 'FCPA', 'カルテル'] },
  { id: 'D091', name: '災害BCP発動', category: 'risk_compliance', trigger: '大規模災害', keyMetrics: ['RTO/RPO', '安否確認'], commonMistakes: ['訓練が形式化で実動不能'], systemSupport: 'BCP発動Runbook', jpContext: '南海トラフ/首都直下', keywords: ['BCP', '事業継続', '災害', '安否確認'] },
  { id: 'D092', name: 'サイバー攻撃 (ランサム) 対応', category: 'risk_compliance', trigger: 'ランサム感染', keyMetrics: ['バックアップ復元', '身代金', 'JPCERT報告'], commonMistakes: ['身代金支払で再感染'], systemSupport: 'ランサム対応Runbook + 復元検証', jpContext: 'JPCERT/NPA 報告フロー', keywords: ['ランサム', 'ランサムウェア', 'サイバー攻撃'] },
  { id: 'D093', name: 'ESG/カーボン報告', category: 'risk_compliance', trigger: '開示要請', keyMetrics: ['Scope1/2/3', 'TCFD'], commonMistakes: ['Scope3を測定せず批判'], systemSupport: 'カーボン算定 + 開示テンプレ', jpContext: 'プライム市場TCFD義務', keywords: ['ESG', 'カーボン', 'TCFD', 'GHG'] },
  { id: 'D094', name: 'ハラスメント告発の処理', category: 'risk_compliance', trigger: '告発受領', keyMetrics: ['調査公平性', '被害者保護'], commonMistakes: ['加害者保護'], systemSupport: '調査プロトコル + 第三者委員会', jpContext: 'パワハラ防止法', keywords: ['ハラスメント', 'パワハラ告発'] },
  { id: 'D095', name: '粉飾疑義 (内部)', category: 'risk_compliance', trigger: '監査人指摘/内部通報', keyMetrics: ['訂正必要性', '開示義務'], commonMistakes: ['隠蔽で課徴金倍増'], systemSupport: '訂正手続チェックリスト', jpContext: '金商法 課徴金/開示義務', keywords: ['粉飾', '不正会計', '訂正'] },
  { id: 'D096', name: '経営者保証解除交渉', category: 'risk_compliance', trigger: '事業承継/M&A前', keyMetrics: ['事業実態と個人資産分離', '財務透明性'], commonMistakes: ['交渉準備不足'], systemSupport: '経営者保証GL R5チェック', jpContext: '経営者保証GL R5改訂', keywords: ['経営者保証', '個人保証', '経営者保証GL'] },
  { id: 'D097', name: '取引先倒産時の債権回収', category: 'risk_compliance', trigger: '与信先倒産', keyMetrics: ['債権額', '担保', '別除権'], commonMistakes: ['法的整理開始後の動産確保失敗'], systemSupport: '債権回収Runbook', jpContext: '破産/民事再生/民事執行', keywords: ['債権回収', '与信先倒産'] },
  { id: 'D098', name: '業界団体加盟 (除名)', category: 'risk_compliance', trigger: '業界活動方針', keyMetrics: ['加盟効果', '会費'], commonMistakes: ['カルテル疑義に巻き込まれる'], systemSupport: '加盟リスク評価', jpContext: '業界団体 独禁法ガイドライン', keywords: ['業界団体', '協会'] },
  { id: 'D099', name: 'メディア対応 (危機広報)', category: 'risk_compliance', trigger: '不祥事報道', keyMetrics: ['初動24時間', 'ステートメント'], commonMistakes: ['ノーコメント連発'], systemSupport: '危機広報テンプレ', jpContext: '黄金の24時間', keywords: ['危機広報', 'メディア対応', 'プレスリリース'] },
  {
    id: 'D100', name: '事業継続/廃業判断', category: 'risk_compliance',
    trigger: '経営者高齢/後継者不在/業績悪化',
    keyMetrics: ['承継候補', 'M&A価値', '廃業コスト'],
    commonMistakes: ['廃業選択の遅延で資産毀損'],
    systemSupport: '廃業 vs 承継 vs M&A 3択シミュレーション',
    jpContext: '2025年問題: 中小経営者の平均年齢60超 / 後継者不在50%超',
    keywords: ['廃業', '事業継続', '事業終了', 'M&A出口'],
  },
];

// ========== Master ==========

export const ALL_DECISIONS: DecisionPattern[] = [
  ...HR_ORG, ...PRICING_SALES, ...INVESTMENT, ...FINANCE, ...RISK_COMPLIANCE,
];

export const DECISIONS_BY_CATEGORY: Record<DecisionCategory, DecisionPattern[]> = {
  hr_org: HR_ORG,
  pricing_sales: PRICING_SALES,
  investment: INVESTMENT,
  finance: FINANCE,
  risk_compliance: RISK_COMPLIANCE,
};

/**
 * 自然言語指示から関連 Decision Pattern を抽出
 */
export function matchDecisions(prompt: string): DecisionPattern[] {
  const text = prompt.toLowerCase();
  return ALL_DECISIONS.filter((d) =>
    d.keywords.some((k) => text.includes(k.toLowerCase()))
  );
}

/**
 * Decision Pattern を生成プロンプトへの注入テキスト形式に変換
 */
export function renderDecisionForPrompt(d: DecisionPattern): string {
  return [
    `### 経営判断パターン: ${d.id} ${d.name}`,
    `- トリガー: ${d.trigger}`,
    `- 確認すべき指標: ${d.keyMetrics.join(' / ')}`,
    `- 典型的な誤り: ${d.commonMistakes.join(' / ')}`,
    `- システム支援: ${d.systemSupport}`,
    `- 日本固有: ${d.jpContext}`,
  ].join('\n');
}
