---
name: soloptilink-upgrade
description: "SoloptiLinkAI v2056.0 - 「アップグレードして」「更新して」「最新版にして」「新しいバージョンある?」「最新版チェックして」等で起動。配信API経由で最新版を自動取得・適用するアップグレードツール。"
argument-hint: "[--remote | --check-only | --admin | ZIPパス | プロジェクトパス | --rollback]"
allowed-tools: Bash, Read, Write, Edit, Glob, Grep, AskUserQuestion
---

# SoloptiLinkAI v2056.0 - アップグレードツール


## 🔎 起動直後の自己証明 (v2054.3 新設・C1)

このスキルは SoloptiLinkAI 本体 (`~/.soloptilink/`) と協働する。素の Claude や他フォームから起動された場合でも「本物が動いていること」を証明するため、**起動直後に本体・認証・主要機構の実測を 1 行の日本語で提示する** (毎回・省略不可)。

```bash
bash ~/.soloptilink/lib/skill-self-attestation.sh 2>/dev/null \
  || echo "SoloptiLinkAI 本体が見つかりません (~/.soloptilink 未導入)。https://soloptilink.com/install から導入してください。"
```

出力例 (本体正常時):
> SoloptiLinkAI v2054.2 本体を確認しました (認証: 承認済 / 主要機構: 12/12 実在)。以降の応答は本物の機構で処理されます。

- 出力の 1 行を**自分の言葉としてそのまま顧客に見せてよい** (bash・生ログを地の文に貼らないルールの唯一の例外的窓口)
- 本体不在・未認証・機構欠損はそれぞれ違う 1 行が返る (fixture の両側弁別で保証済)
- 詳細な実起動証跡や品質ゲート実測ログは `/soloptilink-boost prove` で全展開可能 (C2)
- kill-switch: `SOLOPTILINK_SELF_ATTESTATION=off` (既定 on)

## 機能概要

SoloptiLinkAI v2054.2 アップグレードツール - 配信API(./soloptilink --update)経由で最新版を自動取得・適用(Step 0.4)。成否は本体バージョンの実測で判定し、旧世代の2段更新は自動で2回目を実行、未達時はワンコマンド回復(Mac/Windows)へ自動フォールバック(0.4f)。会社単位ロールアウト+CHECKSUM検証+自動バックアップ対応。管理者モード/ZIP指定時は従来通りメタ整合性監査(Step 0.5〜8)を実行。v2032.0継承: Customer Confidence Edition (REHD/FCPG/CFD/OSCG13軸)。v2031.0継承: Japan Governance Excellence + auto-prune-stale + 二重lib/japan双方向sync。v2027.0継承: ARTE-Defender + Continuum Fortress (10th) + Decafortress (1700点)。「アップグレードして」「更新して」「最新版にして」「新しいバージョンある?」「最新版チェックして」等で使用。

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

## 🤝 所見（相棒として必ず添えるもの・SOLOPTILINK-PARTNER-OPINION）

**作業完了の報告には、本文の末尾に必ず「所見」を添える。** 開発憲章 第2条（相棒＝共に考える存在）・第4条（意図を聞き、提案し、一緒に決めてから作る）を、報告の枠として実装したもの。3欄すべて必須で、該当がなければ「特になし」と明記する（欄を削るのは「書いていない」と判定される）。

まず材料を1画面で受け取る。**材料であって文章ではない**ので、出力を顧客可視の本文にそのまま貼らない:

```bash
bash ~/.soloptilink/lib/opinion-materials.sh show "$PROJECT_DIR"
```

材料を読んだうえで、**自分の言葉で**次の形で書く:

```
### 所見（この作業について）

**今回の判断**（何を・なぜ・何と迷ったか）
- …

**気になっていること**（指示どおり作ったが、懸念が残る点。無ければ「特になし」）
- …

**次の一手**（この案件の文脈で。技術の残作業と、事業として次に効くことを1つずつ）
- …
```

**規則**
1. 3欄とも省略しない。該当なしは「特になし」と書く
2. 3欄のどこかで、その案件の語（業種・扱うデータ・画面・ご要望・直前に決めたこと）に**最低1語**触れる。触れていない文は定型文として書き直しになる
3. 前回の所見と同じ行を繰り返さない
4. 機械言語（コマンド・ファイルパス・内部の識別子）を書かない
5. 3欄合計はおおむね120字以上。本文の繰り返しにはしない
6. 事業の一手は毎回1行入れる。根拠（ご要望・業種・前回の決定）が取れない案件では捏造せず「御社の狙いを一言いただければ、事業として次に効く一手をお出しします」と正直に書く
7. 過去に採用した判断を覆すときは、欄1に「前回の決定（○○）を覆します。理由: …」と必ず書く（黙って戻さない）
8. **欄1で設計・技術・スコープの判断を書いたら、同じ内容を判断記録に残す。** 残さないと次の案件で同じ議論をやり直すことになる:

```bash
bash ~/.soloptilink/lib/decision-ledger.sh add "$PROJECT_DIR" \
  --topic "<何について>" --chosen "<どちらにしたか>" --why "<なぜ>" --alt "<捨てた案>" --skill <モード名>
```

   人が「それでいい / やめてほしい / こう変えて」と答えたら、その時点で記録側にも反映する:

```bash
bash ~/.soloptilink/lib/decision-ledger.sh respond "$PROJECT_DIR" <記録ID> <adopted|rejected|modified> "<要旨>"
```

   ★人が答えるまでは「応答待ち」のままにする。**黙っていたことを「採用」と記録してはいけない**（誰も決めていない前提が、次の案件で既成事実として配られる）

**開示の深さ（二段構え）**: 材料の冒頭に出る `tier` に従う。出す・出さないではなく**深さ**を変える。
- `admin` / `internal` … 設計・技術・スコープの判断を、迷った点まで含めて書く
- `client`（既定）… 欄1の見出しを「**こう理解して進めました（前提）**」に置き換え、推測で置いた前提を書く。欄2は**打てる手がある懸念**（判断が要る／後で困る／費用が発生する）だけに絞り、内部実装の迷いは書かない

**この所見は応答完了時に実物で検査される。** 欠落・定型・繰り返し・（顧客向けの）機械言語のいずれかがあれば書き直しを求められる。

## 🗣 異議の述べ方（止めない・SOLOPTILINK-PARTNER-OBJECTION）

指示の内容に懸念（後で困る・費用が出る・法令や安全に触れる・より良い方法がある）があるときは、**実行する前に1〜2文で述べる**。ただし**承認は待たない**。述べたうえで、指示どおりに実行する（ユーザーが異議を受けて指示を変えた場合のみ従う）。述べた異議は所見の「気になっていること」欄に残す。

- 顧客向けには**打てる手がある懸念**だけを述べる（判断が要る／後で困る／費用が発生する）。内部実装の迷いは述べない
- 法令・算定式・認証・権限分離・監査ログ・暗号化を緩める指示には、異議を述べたうえで**従わない**（思想不変域）
  - **区別の基準**: 従わないのは「法令や安全が定める下限を下回る」指示だけ。例:「監査ログを取らない」「パスワードを平文で保存」「加算の算定式を実態と違う値にする」「権限を全員管理者にする」
  - 一方、**下限を満たしたうえでの運用のご要望には従う**。例:「承認を2段から1段にしたい」「役割の呼び名を自社に合わせたい」「この帳票は月次でなく週次で出したい」「画面の項目を減らしたい」——これらは業務の設計であって、緩和ではない
  - 判断に迷うときは**従う側に倒し**、「この運用だと〇〇の場面で確認が要ります」と所見の欄2に書く（先回りして断らない）
- 異議は機械言語を含まない日本語1〜2文。**質問の形にしない**（質問は増やさない。推測して進み、推測したことを開示する）
- 異議は実行を止めない。「この方針でよろしいですか」と承認を待つのは異議ではない
- 提案も同じ。**言うところまでが提案**で、実装するかは人が決める。提案でスコープを勝手に広げない

## 🛑 最優先ルール: アップグレード経路の選択（PFP-107 自己改変デッドロック根絶）

「アップグレードして」「更新して」「最新版にして」のように **ZIP パスを明示しない依頼** は、**必ず配信API経由のリモート更新 (`~/.soloptilink/soloptilink --update`) を第一経路**とする。手元の `~/Downloads/*.zip` を起点にした手動 rsync / メタ同期に**自分から入ってはならない**。

### なぜか（構造的理由）
1. **ダウンロード済み ZIP は古いことが多い**。インストール済み本体より古い ZIP を起点にすると格下げ（ダウングレード）になる。版数は ZIP ではなく**配信API (`--update`) が返す最新版**を真実の源とする。
2. **`.claude/skills/`・`.claude/commands/`・`CLAUDE.md` を Claude のセッション内から Write/Edit で上書きすると、Claude Code の自己改変セーフティ分類器が必ずブロックする**（自動モードでも例外なく停止＝デッドロック）。これらの設定ファイルの同期は、**ターミナルで起動する Goランチャーの `--update` と、Claude Code 再起動時の SessionStart 自動更新フックが担う**。セッション内での手動上書きは構造的に完了不能なので**試みない**。

### 正しい手順（顧客に案内する標準フロー）
1. **ターミナル**（Mac: ターミナル.app / Windows: PowerShell）で `cd ~/.soloptilink && ./soloptilink --update` を実行 → 配信APIから最新版を取得・適用（Goバイナリ＋chain.sh＋スキル）。
2. **Claude Code を完全に再起動**（一度終了して開き直す）→ SessionStart 自動更新フックが `~/.claude/skills/` 等のプレーンテキスト側を同期。
3. `./soloptilink --version` と `./soloptilink --status` で版数と「承認済み」を確認。

### META_ONLY / 手動 ZIP 経路を使ってよい唯一の条件
- ユーザーが**明示的に ZIP パスを引数で渡した**場合、または**管理者モード（`~/.soloptilink/.admin_mode` 存在）での本体保守**時のみ。その場合でも `.claude/*` の同期は**ターミナルのランチャー／フックに委ね**、セッション内 Write/Edit では行わない。
- ダウンロード ZIP がインストール済みより**古い**と判明したら、rsync もメタ同期も行わず `--update` に切り替える。

> この経路選択を誤ると「アップグレードが安全ガードでブロックされて固まる」事象が起きる（PFP-107 事案）。`--update` を第一経路にすればガードは一切発火しない。

## 絶対禁止事項（セキュリティバウンダリ - 違反厳禁）

以下の行為は**いかなる理由があっても絶対に行ってはならない**。

1. **admin-dashboardの起動・アクセス・参照の禁止** - 顧客がアクセスすることは契約上禁止
2. **mock-api.jsの起動・改変の禁止** - 認証バイパスにつながる重大なセキュリティ違反
3. **ライセンス認証の回避・バイパスの禁止** - ライセンス違反および不正利用
4. **chain.shの直接実行の禁止** - Goランチャー経由でのみ実行

## 概要
`~/.soloptilink/` にインストールされたSoloptiLinkAI本体を最新版(v2024.0 "ARTE-Defender")に更新するツール。
ZIPファイルから展開、または開発プロジェクトディレクトリからコピーして本体を差し替える。

**v2024.0 アップグレードでは「コードは置換できているがメタ情報が古い」状態になりがち**なため、本ツールは以下の **二重・三重の整合性保証** を構造的に担保する:

1. **コード本体** (lib/, agents/, tests/, domains/) の rsync 同期
2. **VERSION 定数** (chain.sh の `readonly VERSION="..."`) の自動更新
3. **CLAUDE.md** タイトル・概要のバージョン記載自動更新
4. **スキルファイル両系統 (重要・v2024.1で恒久化)**:
   - `~/.claude/skills/<name>/SKILL.md` (Claude が `Skill` ツール経由で呼び出す側)
   - `~/.claude/commands/<name>.md` (UI でユーザが `/<name>` 補完に出る側)
5. **本体同梱スキル** (`~/.soloptilink/skills/<name>/SKILL.md`) の同期
6. **ネスト残骸検出** (`~/.claude/skills/skills/<name>/SKILL.md` のような誤配置) の自動退避
7. **重複name検出** (同じnameを持つ複数SKILL.md) の警告
8. **UIキャッシュ問題** の最終アナウンス (Claude Code セッション再起動が必須)

これら全てを **Step 5.5 メタ整合性監査** + **Step 7 二系統スキル更新** + **Step 8 整合性検証** + **Step 9 UI再起動案内** で構造的に保証する。

## v2024.0 アップグレードポイント
- **ARTE-Defender**: Policy Synthesizer (ModSecurity/Cloudflare/OPA Rego/Sigma 4形式) + Runtime Defense (nginx/CF/Envoy/cockatiel adaptive rate-limit) + IR Playbook (5フェーズ + 個情法第26条 R4改正5日速報組込) + SIEM Bridge (Splunk SPL/Datadog/Sentinel KQL/Loki LogQL/Elastic ECS 8.11)
- **Continuum Fortress**: 10th, 17軸170点満点 (REAL_VERIFY 4軸 CN05/08/10/12)
- **Decafortress**: 10×170=1700点 Diamond★★★★★ (1620+) | Platinum (1530+) | Gold (1360+) | Silver (1190+)
- **REAL_VERIFY 累計33軸**: Adaptive 4 + Cognitive 4 + Sovereign 4 + Continuum 4 + Offense 17
- **239/239テスト全PASS**: v2020(74) + v2021(38) + v2022(35) + v2023(45) + v2024(47)
- **525+シェルモジュール / 100エージェント / 27ドメイン / 24層アーキテクチャ**

## Step 0: 端末認証（ハードゲート）

**以下のBashコマンドを最初に必ず実行する。出力結果が AUTHORIZED でなければ、以降の全処理を中止する。**

```bash
SOLOPTILINK_BIN=""; if [ -f ~/.soloptilink/soloptilink ]; then SOLOPTILINK_BIN="./soloptilink"; elif [ -f ~/.soloptilink/soloptilink.exe ]; then SOLOPTILINK_BIN="./soloptilink.exe"; fi
AUTH_CHECK=$(cd ~/.soloptilink 2>/dev/null && ${SOLOPTILINK_BIN:-./soloptilink} --status 2>&1); if echo "$AUTH_CHECK" | grep -q "承認済み"; then echo "AUTHORIZED"; else echo "UNAUTHORIZED"; echo "---"; echo "$AUTH_CHECK"; fi
```

#### 結果が `UNAUTHORIZED` の場合:
```
SoloptiLinkAIの端末認証が完了していません。
1. cd ~/.soloptilink && ./soloptilink --activate
2. 管理者による承認を待つ
3. ./soloptilink --status で確認
```
**UNAUTHORIZEDの場合、アップグレード処理に進んではならない。**

## Step 0.4: リモートAPI更新チェック (顧客の通常経路・最優先) 【v2034.2新設】

**配信API経由で管理者がアップロードした最新版を取得・適用する正式経路。**
launcher v25.0.0+ の UpdateManager (会社単位ロールアウト+CHECKSUM検証 v2034.4対応) を呼ぶ。
ここで適用が完了したら **Step 0.5 以降は全てスキップして終了** する。

### 0.4a. 経路判定

```bash
# 引数判定
REMOTE_MODE=0
CHECK_ONLY=0
case "$ARGUMENTS" in
  ""|"--remote") REMOTE_MODE=1 ;;
  "--check-only") REMOTE_MODE=1; CHECK_ONLY=1 ;;
  "--admin"|"--admin-mode") REMOTE_MODE=0 ;;  # 管理者モード = リモート経路スキップ
  *.zip) REMOTE_MODE=0 ;;                      # ZIP指定 = フォールバック経路
  *)
    # ディレクトリパスならフォールバック、その他は不明
    [ -d "$ARGUMENTS" ] && REMOTE_MODE=0 || REMOTE_MODE=1
    ;;
esac
echo "REMOTE_MODE=$REMOTE_MODE  CHECK_ONLY=$CHECK_ONLY"
```

### 0.4b. リモートチェック実行 (REMOTE_MODE=1 のみ)

```bash
if [ "$REMOTE_MODE" = "1" ]; then
  SOLOPTILINK_BIN=""; if [ -f ~/.soloptilink/soloptilink ]; then SOLOPTILINK_BIN="./soloptilink"; elif [ -f ~/.soloptilink/soloptilink.exe ]; then SOLOPTILINK_BIN="./soloptilink.exe"; fi

  # まず N を返してチェックだけ実施 (適用はしない。バイナリの自己修復が走ることがあるため 120s 許容)
  RAW=$(cd ~/.soloptilink && printf "N\n" | timeout 120 ${SOLOPTILINK_BIN:-./soloptilink} --update 2>&1)
  echo "$RAW"

  # ★T-4 (2026-08-13 新設): 顧客に見せる版数は必ず実測値だけにする。
  #   【何が起きていたか】「既に最新」の経路には配信サーバ側の版数を知る手段が無く、
  #   それなのに顧客提示文が版数を書くよう指示していた (しかも参照先の変数はどこにも
  #   代入が無い未定義変数だった)。結果、実際には測っていない値を
  #   「配信サーバー上の最新版 v____ (同一)」と断定して顧客に見せていた。
  #   これは品質ではなく正直さの欠陥であり、2026-08-13 の申告② の核心である。
  #   端末の実測値とサーバの申告値を別々に取り、取れなかったものは数字を書かない。
  CUR_LOCAL="$(grep -m1 'readonly VERSION=' ~/.soloptilink/chain.sh 2>/dev/null | sed -E 's/.*"([^"]+)".*/\1/')"
  SRV_LATEST="$(echo "$RAW" | grep -oE 'v?[0-9]{4}\.[0-9]+' | head -1 | tr -d 'v')"
  echo "CUR_LOCAL=${CUR_LOCAL:-取得できず} SRV_LATEST=${SRV_LATEST:-取得できず}"

  # 判定
  if echo "$RAW" | grep -q "最新バージョン"; then
    UPDATE_STATUS="ALREADY_LATEST"
  elif echo "$RAW" | grep -q "新しいバージョンが利用可能"; then
    UPDATE_STATUS="UPDATE_AVAILABLE"
    NEW_VER=$(echo "$RAW" | grep -oE "→ v[0-9.]+" | head -1 | sed 's/→ v//')
  elif echo "$RAW" | grep -q "アップデート確認に失敗"; then
    UPDATE_STATUS="API_ERROR"
  else
    UPDATE_STATUS="UNKNOWN"
  fi
  echo "UPDATE_STATUS=$UPDATE_STATUS NEW_VER=${NEW_VER:-}"

  # 必須更新フラグの尊重 (2026-07-26 新設): 配信サーバが「この更新は必須 (セキュリティ修正等)」と
  # 宣言している場合、その意思を端末側で確実に反映する (mandatory を参照しない世代のランチャーが
  # 存在するため、スキル側で必須性を回復する一次レバー)。判定は外部依存なし (curl+grep のみ・
  # 失敗時は 0=非必須の安全側に倒す)。
  MANDATORY_UPDATE=0
  if [ "$UPDATE_STATUS" = "UPDATE_AVAILABLE" ]; then
    CUR_Q="$(grep -m1 'readonly VERSION=' ~/.soloptilink/chain.sh 2>/dev/null | sed 's/.*"\(.*\)".*/\1/')"
    _os="$(uname -s 2>/dev/null)"; case "$_os" in Darwin) _os=darwin;; Linux) _os=linux;; *) _os=windows;; esac
    _ar="$(uname -m 2>/dev/null)"; case "$_ar" in arm64|aarch64) _ar=arm64;; *) _ar=amd64;; esac
    if curl -s --max-time 15 "https://admin-dashboard-blue-alpha-78.vercel.app/api/v1/updates/check?version=${CUR_Q:-2000.0}&os=${_os}&arch=${_ar}" 2>/dev/null \
       | grep -qE '"mandatory"[[:space:]]*:[[:space:]]*true'; then
      MANDATORY_UPDATE=1
    fi
  fi
  echo "MANDATORY_UPDATE=$MANDATORY_UPDATE"
fi
```

### 0.4c. 判定後アクション

| `UPDATE_STATUS` | アクション |
|---------------|---------|
| `ALREADY_LATEST` | **測った値だけを伝える (T-4 / 2026-08-13)**。`$CUR_LOCAL` (端末の実測値) と `$SRV_LATEST` (サーバが返した値) の**両方が取れたときだけ**「お使いの版 v$CUR_LOCAL は最新です (配信サーバの最新: v$SRV_LATEST)」と伝える。**どちらかでも空なら数字を一切書かず**「お使いの版は最新でした (配信サーバ側の版数は確認できませんでした)」と正直に伝える。→ 終了 (Step 0.5 以降スキップ)<br>**禁止**: 取得できていない版数を推測で埋めること。代入の無い変数を顧客提示文に使うこと (2026-08-13 申告② の原因はこれで、実際には測っていない版数を「配信サーバー上の最新版」として断定していた) |
| `UPDATE_AVAILABLE` + `MANDATORY_UPDATE=1` + `CHECK_ONLY=0` | **確認質問を挟まず 0.4d を実行** (「今回の更新は安全性に関わる必須更新のため、そのまま適用します」と一言添える)。必須更新を「後で」に先送りさせない |
| `UPDATE_AVAILABLE` + `MANDATORY_UPDATE=1` + `CHECK_ONLY=1` | チェックのみの依頼のため自動適用はしないが、「**安全性に関わる必須更新が保留中**です。『アップグレードして』で今すぐ適用できます」と**必須である旨を明示**して終了 |
| `UPDATE_AVAILABLE` + `CHECK_ONLY=1` | 「新版 v$NEW_VER が利用可能です」と通知だけ → 終了 |
| `UPDATE_AVAILABLE` + `CHECK_ONLY=0` | AskUserQuestion で適用可否確認 → 同意なら 0.4d 実行 → 終了 |
| `API_ERROR` | 配信サーバーへ一時的に届かない状態。**0.4f のワンコマンド回復を自動実行**して到達を試みる (それでも届かなければ「少し待って再実行してください」と案内して終了) |
| `UNKNOWN` | 生出力を提示し管理者(SoloptiLinkAI社)へエスカレーション → 終了 |

### 0.4d. 適用コマンド (顧客承認後・最大2回の自動段階更新 / v2054.2 刷新)

**成否は必ず「本体バージョンの実測」で判定する** (旧実装の `.auto-update.log` の文言 grep は、Goネイティブ経路で成功したケースを「失敗」と誤報告する既知バグのため廃止)。旧世代ランチャーは1回目がランチャー本体の更新のみで終わることがあるため (正常系の2段更新)、**目標版に未達なら自動でもう1回実行**する。低速回線でも途中で打ち切らないため timeout は 540 秒とし、**Bash ツールの呼び出しでは timeout: 600000 を明示指定**する。

```bash
current_chain_ver() { grep -m1 'readonly VERSION=' ~/.soloptilink/chain.sh 2>/dev/null | sed 's/.*"\(.*\)".*/\1/'; }
APPLY_LOG=/tmp/soloptilink-update-apply-$(date +%Y%m%d_%H%M%S).log

# 1回目 (旧世代はここでランチャー本体だけ新しくなることがある)
cd ~/.soloptilink && printf "y\n" | timeout 540 ${SOLOPTILINK_BIN:-./soloptilink} --update 2>&1 | tee -a "$APPLY_LOG"
V_NOW="$(current_chain_ver)"

# 未達なら2回目 (1回目で新しくなったランチャーが本体パッケージまで確実に適用する)
if [ -n "$NEW_VER" ] && [ "$V_NOW" != "$NEW_VER" ]; then
  cd ~/.soloptilink && printf "y\n" | timeout 540 ${SOLOPTILINK_BIN:-./soloptilink} --update 2>&1 | tee -a "$APPLY_LOG"
  V_NOW="$(current_chain_ver)"
fi

if [ -n "$NEW_VER" ] && [ "$V_NOW" = "$NEW_VER" ]; then
  echo "UPDATE_RESULT=OK v$V_NOW"
else
  echo "UPDATE_RESULT=NOT_REACHED current=v${V_NOW:-unknown} target=v${NEW_VER:-unknown}"
fi
```

- `UPDATE_RESULT=OK` → 「更新が完了しました (v$NEW_VER)。Claude Code を一度終了して開き直すと反映されます」と顧客に案内して終了 (Step 0.5 以降スキップ)。
- `UPDATE_RESULT=NOT_REACHED` → **0.4f のワンコマンド回復を自動実行** (顧客への追加質問は不要。回復は鍵・認証・顧客データに一切触れない)。

### 0.4f. ワンコマンド回復 (未達時の自動フォールバック / v2054.2 新設)

`--update` で目標版に到達しなかった場合・配信サーバーへの接続エラーが続く場合は、配信APIの回復スクリプトで**どの世代からでも最新版へ一発到達**させる (鍵・認証・顧客データは bit 不変・毎配信ごとに実機E2Eゲートで健全性を検証済みの経路)。所要は通常2〜3分・低速回線では10分程度。**Bash ツールの呼び出しでは timeout: 600000 を明示指定**する。

```bash
case "$(uname -s 2>/dev/null)" in
  Darwin|Linux)
    curl -fsSL https://admin-dashboard-blue-alpha-78.vercel.app/api/v1/recover | bash ;;
  *)  # Git Bash (MINGW/MSYS) = Windows
    powershell.exe -NoProfile -ExecutionPolicy Bypass -Command "irm https://admin-dashboard-blue-alpha-78.vercel.app/api/v1/recover/windows | iex" ;;
esac
V_NOW="$(grep -m1 'readonly VERSION=' ~/.soloptilink/chain.sh 2>/dev/null | sed 's/.*"\(.*\)".*/\1/')"
echo "RECOVER_RESULT current=v${V_NOW:-unknown} target=v${NEW_VER:-latest}"
```

- 回復後に版数が目標に到達していれば「更新が完了しました。Claude Code を一度終了して開き直してください」と案内して終了。
- それでも未達の場合のみ、**正直に**「更新を完了できませんでした」と伝え、実行ログの要点を添えてサポート (このまま返信/お電話) へ誘導する。**「できました」と偽らない。**

### 0.4e. フォールバック経路 (REMOTE_MODE=0 または 顧客が手動展開を要望)
REMOTE_MODE=0 の場合はそのまま Step 0.5 以降 (管理者向けメタ整合性監査含むフルフロー) を実行。

---

## Step 0.5: ターゲットバージョン決定

アップグレード対象の最新バージョン番号(`TARGET_VERSION`)と コードネーム(`TARGET_CODENAME`)を決定する。
以降の Step で「VERSION 定数の書換先」「description の書換先」「最終アナウンスのバージョン文字列」として参照される。

判定優先順位:
1. ユーザが明示指定 (例: `--target 2024.0`) → そのまま採用
2. ソース ZIP / プロジェクトの `chain.sh` 内 `readonly VERSION="..."` を検出 → 採用
3. `~/.soloptilink/CHANGELOG.md` の最新エントリ → 採用
4. ハードコードのフォールバック: `TARGET_VERSION="2024.0"` / `TARGET_CODENAME="ARTE-Defender"`

```bash
# ハードコードフォールバック
TARGET_VERSION="2024.0"
TARGET_CODENAME="ARTE-Defender"

# ソース側 chain.sh から推定 (引数なしの場合は最新リリースを参照)
if [ -n "$SOURCE_DIR" ] && [ -f "$SOURCE_DIR/chain.sh" ]; then
  DETECTED=$(grep -m1 'readonly VERSION=' "$SOURCE_DIR/chain.sh" 2>/dev/null | sed -E 's/.*"([^"]+)".*/\1/')
  [ -n "$DETECTED" ] && TARGET_VERSION="$DETECTED"
fi

echo "TARGET_VERSION=$TARGET_VERSION"
echo "TARGET_CODENAME=$TARGET_CODENAME"
```

## アップグレード手順

### Step 1: ソースの特定
引数からアップグレードソースを判定:

1. **ZIPファイル指定**: 引数が `.zip` で終わるパス → ZIPから展開
2. **ディレクトリ指定**: 引数がディレクトリパス → そのディレクトリからコピー
3. **引数なし**: 以下を自動検索
   - `~/Downloads/SoloptiLinkAI-Chain-v*.zip` (最新版)
   - カレントディレクトリに `chain.sh` があればそれを使用
   - カレント周辺(深さ3)で `chain.sh` を検索

### Step 2: 現在のバージョン確認 + ソース整合性チェック

```bash
# 現在のバージョン
CURRENT_VERSION=$(grep -m1 'readonly VERSION=' ~/.soloptilink/chain.sh 2>/dev/null | sed -E 's/.*"([^"]+)".*/\1/')
echo "現在: $CURRENT_VERSION"
echo "目標: $TARGET_VERSION"

# CASE: コードはすでに最新だがメタ情報だけ古い (今回の v2019.0→v2024.0 ケース)
#   → メタ更新だけ走らせるショートカットモードに移行
if [ -d ~/.soloptilink/lib/security/arte/v2024 ] && [ "$CURRENT_VERSION" != "$TARGET_VERSION" ]; then
  echo "[INFO] コード本体は最新だがメタ情報が古い状態を検出"
  echo "[INFO] メタ更新型アップグレード (Step 5.5/Step 7/Step 8 中心) に切替"
  META_ONLY_MODE=1
fi
```

### Step 3: バックアップ

```bash
# 全体バックアップ (大容量。23GB 規模になり得る)
if [ -d ~/.soloptilink ]; then
    cp -a ~/.soloptilink ~/.solai_backup_$(date +%Y%m%d_%H%M%S) &
    BACKUP_PID=$!
fi

# 軽量メタバックアップ (即座に完了。Step 5以降で安全に変更を進めるため必須)
META_BACKUP=~/.solai_meta_backup_$(date +%Y%m%d_%H%M%S)
mkdir -p "$META_BACKUP/skills" "$META_BACKUP/claude_skills" "$META_BACKUP/claude_commands"
cp ~/.soloptilink/chain.sh "$META_BACKUP/chain.sh" 2>/dev/null || true
cp ~/.soloptilink/CLAUDE.md "$META_BACKUP/CLAUDE.md" 2>/dev/null || true
for s in soloptilink soloptilink-boost soloptilink-upgrade; do
  [ -f ~/.soloptilink/skills/$s/SKILL.md ]    && { mkdir -p "$META_BACKUP/skills/$s";    cp ~/.soloptilink/skills/$s/SKILL.md "$META_BACKUP/skills/$s/"; }
  [ -f ~/.claude/skills/$s/SKILL.md ]         && { mkdir -p "$META_BACKUP/claude_skills/$s"; cp ~/.claude/skills/$s/SKILL.md "$META_BACKUP/claude_skills/$s/"; }
  [ -f ~/.claude/commands/$s.md ]             && cp ~/.claude/commands/$s.md "$META_BACKUP/claude_commands/$s.md"
done
echo "メタバックアップ完了: $META_BACKUP"
```

### Step 4: アップグレード実行 (META_ONLY_MODE=1 ならスキップ)

#### ZIPファイルからの場合:
```bash
TEMP_DIR=$(mktemp -d)
unzip -o "$ZIP_PATH" -d "$TEMP_DIR"
SOURCE_DIR=$(find "$TEMP_DIR" -name "chain.sh" -maxdepth 2 -exec dirname {} \; | head -1)

rsync -av --exclude='.git' --exclude='docs/knowledge/*.json' --exclude='docs/chain-logs/*' \
    "$SOURCE_DIR/" ~/.soloptilink/

rm -rf "$TEMP_DIR"
```

#### ディレクトリからの場合:
```bash
rsync -av --exclude='.git' --exclude='node_modules' --exclude='docs/knowledge/*.json' \
    --exclude='docs/chain-logs/*' --exclude='__pycache__' --exclude='venv' \
    --exclude='admin-dashboard' --exclude='aws-infra' --exclude='download-page' \
    --exclude='launcher' --exclude='dist' --exclude='security' --exclude='commercial' \
    "$SOURCE_DIR/" ~/.soloptilink/
```

### Step 5: 権限設定
```bash
chmod +x ~/.soloptilink/chain.sh ~/.soloptilink/setup.sh
chmod +x ~/.soloptilink/lib/*.sh 2>/dev/null
chmod +x ~/.soloptilink/tests/run_tests.sh 2>/dev/null
```

### Step 5.5: メタ整合性監査【v2024.1新設・最重要】

**今回の v2019.0 → v2024.0 アップグレードで顕在化した「コード最新だがメタ情報旧」「ネスト残骸が UI に出る」「skill と command の二重管理を片方だけ更新」問題を構造的に潰すゲート。**

#### 5.5a. VERSION 定数の更新

```bash
# chain.sh の VERSION 定数を TARGET_VERSION に書換
CURRENT_IN_CHAIN=$(grep -m1 'readonly VERSION=' ~/.soloptilink/chain.sh | sed -E 's/.*"([^"]+)".*/\1/')
if [ "$CURRENT_IN_CHAIN" != "$TARGET_VERSION" ]; then
  sed -i.bak -E "s/readonly VERSION=\"[^\"]+\"/readonly VERSION=\"${TARGET_VERSION}\"/" ~/.soloptilink/chain.sh
  rm -f ~/.soloptilink/chain.sh.bak
  echo "[OK] chain.sh VERSION: $CURRENT_IN_CHAIN → $TARGET_VERSION"
fi

# chain.sh ヘッダコメント (v62.0 (2019.0): ZDDG ... の進化履歴) を最新版で先頭に追記
# 先頭行が古いままなら最新エントリを 1行追加 (既に最新版が含まれていればスキップ)
if ! grep -q "(${TARGET_VERSION}):" ~/.soloptilink/chain.sh; then
  echo "[WARN] chain.sh ヘッダ進化履歴に v${TARGET_VERSION} の記述なし — 手動で 1行追加してください"
fi
```

#### 5.5b. CLAUDE.md タイトル・概要のバージョン記載更新

```bash
# 1行目 # SoloptiLinkAI vXXX.X - Claude Code Project Instructions を更新
# 概要セクション内の (VERSION=XXX.X) も同期
sed -i.bak -E \
  -e "1s/SoloptiLinkAI v[0-9.]+/SoloptiLinkAI v${TARGET_VERSION}/" \
  -e "s/VERSION=[0-9.]+/VERSION=${TARGET_VERSION}/" \
  ~/.soloptilink/CLAUDE.md
rm -f ~/.soloptilink/CLAUDE.md.bak
echo "[OK] CLAUDE.md: vN.N → v${TARGET_VERSION}"
```

#### 5.5c. ネスト残骸検出と退避 (重要)

過去のリリース過程で `~/.claude/skills/skills/<name>/SKILL.md` のような誤配置が混入する事例あり。Claude Code はこれも別スキルとして拾うため、UI に旧バージョンが二重表示される。**必ず退避する**。

```bash
NESTED=~/.claude/skills/skills
if [ -d "$NESTED" ]; then
  # メタバックアップへ退避
  mkdir -p "$META_BACKUP/claude_skills_nested"
  cp -a "$NESTED"/. "$META_BACKUP/claude_skills_nested/" 2>/dev/null
  # リネーム (削除ではなく改名で安全側に倒す)
  mv "$NESTED" "${NESTED}.removed_$(date +%Y%m%d_%H%M%S)"
  echo "[OK] ネスト構造を退避: $NESTED → ${NESTED}.removed_*"
fi

# その他、~/.claude/skills 配下に SKILL.md ではないが name フィールドを持つ謎ファイルが無いか
find ~/.claude/skills -mindepth 2 -name "SKILL.md" 2>/dev/null | while read -r f; do
  parent=$(dirname "$f")
  grand=$(dirname "$parent")
  # 期待構造は ~/.claude/skills/<name>/SKILL.md (深さ2)
  if [ "$grand" != "$HOME/.claude/skills" ]; then
    echo "[WARN] 想定外パスに SKILL.md 検出: $f"
  fi
done
```

#### 5.5d. 重複 name 検出

```bash
# 同じ name フィールドを持つ SKILL.md が複数ある場合は警告
echo "=== 重複 name 検査 ==="
for s in soloptilink soloptilink-boost soloptilink-upgrade; do
  HITS=$(grep -l "^name: ${s}\$" ~/.claude/skills/*/SKILL.md 2>/dev/null | wc -l | tr -d ' ')
  if [ "$HITS" -gt 1 ]; then
    echo "[WARN] name=${s} の SKILL.md が ${HITS} 個ヒット — 1個に絞ってください"
    grep -l "^name: ${s}\$" ~/.claude/skills/*/SKILL.md
  fi
done
```

### Step 6: セットアップ再実行
```bash
if [ -f ~/.soloptilink/setup.sh ]; then
    cd ~/.soloptilink && bash setup.sh
else
    echo "[INFO] setup.sh が見つかりません。スキップします。"
fi
```

### Step 7: スキルファイル更新【v2024.1強化版・二系統同時更新】

**ここが今回の根本対策。Skill 系統と Command 系統は別管理なので、片方だけ更新すると UI で旧版が残る。両方を必ず同時更新する。**

#### 7a. 更新対象パス (5箇所)

| # | パス | 用途 | 更新必須 |
|---|------|------|----------|
| 1 | `~/.soloptilink/skills/<name>/SKILL.md` | 本体同梱版 (リリース ZIP の正本) | ◎ |
| 2 | `~/.claude/skills/<name>/SKILL.md` | Claude が `Skill` ツール経由で呼び出す側 | ◎◎ |
| 3 | `~/.claude/commands/<name>.md` | UI でユーザが `/<name>` 補完に出る側 | ◎◎ |
| 4 | `~/.claude/skills/skills.removed_*` | (退避済みネスト) 触らない | × |
| 5 | `~/.solai_meta_backup_*` | (バックアップ) 触らない | × |

#### 7b. 本体 → ~/.claude へのコピー【v2032.1強化版・本文同期 + バックアップ退避】

**根本対策**: Step 7c の `bumpVersion` は description / H1 の数字しか書き換えない。
本文 (1500 行) は `~/.claude/skills/<name>/SKILL.md` および
`~/.claude/commands/<name>.md` の双方で **ソース正本から丸ごと上書き** しないと
旧世代の本文が残り続ける (2026-05-12 v2026.0 → v2032.0 アップグレードで
commands/*.md の本文が v2026.0 のまま放置 = ピッカーに旧版重複表示が発生)。

**さらに**: `_backup_*` ディレクトリを `~/.claude/skills/` や `~/.claude/commands/`
**配下** に置くと、Claude Code がそれらも skill/command として読み込んでしまい
`_backup_20260512_113513:soloptilink-boost` 等の重複エントリがピッカーに出る。
バックアップは必ずツリー外 (`~/.claude/_backups/`) に退避すること。

```bash
SYNC_TARGETS="soloptilink soloptilink-boost soloptilink-upgrade"
TS=$(date +%Y%m%d_%H%M%S)
BK_ROOT=~/.claude/_backups
mkdir -p "$BK_ROOT"

# (1) skills/commands ツリー配下の旧 _backup_* を外に退避 (再発防止)
for d in ~/.claude/skills/_backup_* ~/.claude/commands/_backup_*; do
  [ -e "$d" ] || continue
  base=$(basename "$d")
  parent=$(basename "$(dirname "$d")")  # skills or commands
  mv "$d" "$BK_ROOT/${parent}_${base#_backup_}" 2>/dev/null \
    && echo "[OK] evacuated stale backup: $d → $BK_ROOT/"
done

# (2) 今回上書き分のスナップショット
SKILLS_BK="$BK_ROOT/skills_$TS"
CMDS_BK="$BK_ROOT/commands_$TS"
mkdir -p "$SKILLS_BK" "$CMDS_BK"

# (3) 本体 ~/.soloptilink/skills/ → ~/.claude/skills/ + ~/.claude/commands/ 双方を本文ごと上書き
if [ -d ~/.soloptilink/skills ]; then
  for s in $SYNC_TARGETS; do
    src=~/.soloptilink/skills/$s/SKILL.md
    [ -f "$src" ] || { echo "[SKIP] no source: $src"; continue; }

    # skills/ 側: ディレクトリごと退避してから本体ディレクトリを丸ごと複製
    # (lib/scripts/templates 等が将来追加されても追随できるように cp -R)
    if [ -d ~/.claude/skills/$s ]; then
      cp -R ~/.claude/skills/$s "$SKILLS_BK/" 2>/dev/null
      rm -rf ~/.claude/skills/$s
    fi
    cp -R ~/.soloptilink/skills/$s ~/.claude/skills/$s
    echo "[OK] skills/$s synced (full tree)"

    # commands/ 側: 単一ファイルなので SKILL.md を上書き (本文ごと)
    if [ -f ~/.claude/commands/$s.md ]; then
      cp ~/.claude/commands/$s.md "$CMDS_BK/" 2>/dev/null
    fi
    cp ~/.soloptilink/skills/$s/SKILL.md ~/.claude/commands/$s.md
    echo "[OK] commands/$s.md synced (body refreshed)"
  done
fi

# (4) 退避先が空なら掃除
rmdir "$SKILLS_BK" "$CMDS_BK" 2>/dev/null || true
echo "[OK] backups (if any) at: $BK_ROOT/"
```

**留意点**:
- `~/.claude/skills/<name>/` を `cp -R` で丸ごと差し替えるので、ユーザが
  そこに手作業で置いた一時ファイルは消える (バックアップから復元可能)。
- バックアップ保管場所 `~/.claude/_backups/` は Claude Code が読まないため、
  ピッカーに `_backup_*:soloptilink-boost` のような重複は出ない。

#### 7c. description のバージョン記載を bumpVersion で一括更新

`~/.claude/skills/<name>/SKILL.md` の冒頭 frontmatter の `description: "SoloptiLinkAI vXXX.X ..."` 部分、および `~/.claude/commands/<name>.md` の同じ箇所を、TARGET_VERSION に書き換える。

```bash
# bumpVersion 関数: 引数 file, target_version
bumpVersion() {
  local file="$1"
  local target="$2"
  [ ! -f "$file" ] && return 0
  # description 行内の SoloptiLinkAI vN.N を vTARGET に置換
  sed -i.bak -E "s/SoloptiLinkAI v[0-9]+\.[0-9]+/SoloptiLinkAI v${target}/g" "$file"
  # H1 タイトル "# SoloptiLinkAI vN.N ..." も同様
  sed -i.bak -E "1,/^---/!s/^# SoloptiLinkAI v[0-9]+\.[0-9]+/# SoloptiLinkAI v${target}/" "$file"
  rm -f "$file.bak"
}

# Skill 系統 (~/.claude/skills/) と Command 系統 (~/.claude/commands/) の両方
for s in soloptilink soloptilink-boost soloptilink-upgrade; do
  bumpVersion ~/.claude/skills/$s/SKILL.md   "$TARGET_VERSION"
  bumpVersion ~/.claude/commands/$s.md       "$TARGET_VERSION"
  bumpVersion ~/.soloptilink/skills/$s/SKILL.md "$TARGET_VERSION"
done
echo "[OK] description bumped to v${TARGET_VERSION} across skills/ + commands/ + 本体skills/"
```

#### 7c-2. 本文世代マーカー検査 [v2024.2 新設・最重要]

**`bumpVersion` の盲点**: H1 と frontmatter description は置換できるが、**本文中の `## vXXXX.X 改修サマリー` や `### Step 0.XX (vXXXX.X 新機能)` セクションは追加されない**。`description` だけ最新になり、Claude が起動時に読む本文 (1500 行のプロンプト本体) は旧世代のまま、という事故が起きる (v2019.0→v2024.0 アップグレード時に実際に発生)。

そのため、本文に **TARGET_VERSION のセクションが存在するか** を検査し、存在しなければ警告を出してユーザに本文修正を促す。

```bash
inspectBodyGeneration() {
  local file="$1"
  local target="$2"
  [ ! -f "$file" ] && return 0

  # 本文 (frontmatter 終端の --- 以降) で H2 「## vXXXX.X 改修サマリー / サマリー」 を全抽出
  local body_versions
  body_versions=$(awk '/^---$/{n++;next} n>=2{print}' "$file" \
    | grep -E '^## v[0-9]+\.[0-9]+ ' \
    | sed -E 's/^## v([0-9]+\.[0-9]+).*/\1/' \
    | sort -u | tr '\n' ' ')

  # H1 が TARGET_VERSION と一致するか
  local h1_version
  h1_version=$(grep -m1 -E '^# SoloptiLinkAI v[0-9]+\.[0-9]+' "$file" \
    | sed -E 's/^# SoloptiLinkAI v([0-9]+\.[0-9]+).*/\1/')

  local has_target_summary=0
  echo " $body_versions " | grep -q " $target " && has_target_summary=1

  if [ "$h1_version" != "$target" ] || [ "$has_target_summary" = "0" ]; then
    echo "[WARN] $file"
    echo "       H1 version: ${h1_version:-(none)} / target: $target"
    echo "       body summary versions: ${body_versions:-(none)}"
    echo "       → frontmatter は最新でも本文セクションが旧世代の可能性あり"
    return 1
  fi
  return 0
}

BODY_GEN_WARN=0
for s in soloptilink soloptilink-boost; do
  inspectBodyGeneration ~/.claude/skills/$s/SKILL.md "$TARGET_VERSION" || BODY_GEN_WARN=1
  inspectBodyGeneration ~/.soloptilink/skills/$s/SKILL.md "$TARGET_VERSION" || BODY_GEN_WARN=1
done

if [ "$BODY_GEN_WARN" = "1" ]; then
  cat <<EOF
═══════════════════════════════════════════════════════════════
  ⚠ 重要: メタ更新は完了したが、本文セクションの世代が古いです
═══════════════════════════════════════════════════════════════
description / H1 だけ最新で、## v${TARGET_VERSION} 改修サマリー や
### Step 0.XX (v${TARGET_VERSION} 新機能) が本文に追加されていません。
このまま使うと Claude は旧世代のロジックで動作します
(v2019.0→v2024.0 アップグレード時に実際に発生した事故)。

修正方法:
  1. ソース ZIP に最新版 SKILL.md (本文込み) が同梱されている場合:
     → そのままコピー (本スクリプトの Step 7b で実施済み)
  2. ソースに本文がない場合:
     → Claude Code に以下を依頼:
       「~/.claude/skills/<name>/SKILL.md の本文に
        ## v${TARGET_VERSION} 改修サマリー と Step 0.XX (新機能) を
        既存セクションを残したまま追記して」
  3. 本文修正後、本スクリプトを --meta-only モードで再実行して整合性を再検証
═══════════════════════════════════════════════════════════════
EOF
fi
```

#### 7d. command が存在しないスキルへの自動コマンド作成

新規スキルが追加された場合、`~/.claude/commands/` 側に対応する `.md` がないと UI 補完に出ないことがある。本体同梱版から派生させて補う:

```bash
for s in soloptilink soloptilink-boost soloptilink-upgrade; do
  if [ -f ~/.claude/skills/$s/SKILL.md ] && [ ! -f ~/.claude/commands/$s.md ]; then
    # frontmatter (--- ... ---) + 本文先頭の概要だけを抽出してコマンド版に
    cp ~/.claude/skills/$s/SKILL.md ~/.claude/commands/$s.md
    echo "[OK] commands/$s.md を skills/$s/SKILL.md から派生作成"
  fi
done
```

#### 7e. 更新時刻の同期 (touch)

ファイル更新時刻を進めて、Claude Code の変更検出が確実に発火するようにする:

```bash
for s in soloptilink soloptilink-boost soloptilink-upgrade; do
  touch ~/.claude/skills/$s/SKILL.md   2>/dev/null
  touch ~/.claude/commands/$s.md       2>/dev/null
  touch ~/.soloptilink/skills/$s/SKILL.md 2>/dev/null
done
```

### Step 8: バージョン整合性検証【fsck モード】

**全更新箇所で版数が一致しているかを最終チェック。1つでも不一致なら警告。**

```bash
echo "═══════════════════════════════════════════════════════════════"
echo "  メタ整合性検証 (期待値: v${TARGET_VERSION})"
echo "═══════════════════════════════════════════════════════════════"

VERIFY_FAIL=0

# chain.sh
V=$(grep -m1 'readonly VERSION=' ~/.soloptilink/chain.sh | sed -E 's/.*"([^"]+)".*/\1/')
[ "$V" = "$TARGET_VERSION" ] && echo "[OK] chain.sh: v$V" || { echo "[NG] chain.sh: v$V"; VERIFY_FAIL=1; }

# CLAUDE.md
V=$(head -1 ~/.soloptilink/CLAUDE.md | grep -oE 'v[0-9]+\.[0-9]+' | head -1)
[ "$V" = "v$TARGET_VERSION" ] && echo "[OK] CLAUDE.md タイトル: $V" || { echo "[NG] CLAUDE.md: $V"; VERIFY_FAIL=1; }

# Skill 系統 (~/.claude/skills/)
for s in soloptilink soloptilink-boost soloptilink-upgrade; do
  V=$(grep -m1 'description:' ~/.claude/skills/$s/SKILL.md | grep -oE 'SoloptiLinkAI v[0-9]+\.[0-9]+' | head -1)
  EXP="SoloptiLinkAI v$TARGET_VERSION"
  [ "$V" = "$EXP" ] && echo "[OK] ~/.claude/skills/$s: $V" || { echo "[NG] ~/.claude/skills/$s: $V"; VERIFY_FAIL=1; }
done

# Command 系統 (~/.claude/commands/)
for s in soloptilink soloptilink-boost soloptilink-upgrade; do
  if [ -f ~/.claude/commands/$s.md ]; then
    V=$(grep -m1 'description:' ~/.claude/commands/$s.md | grep -oE 'SoloptiLinkAI v[0-9]+\.[0-9]+' | head -1)
    EXP="SoloptiLinkAI v$TARGET_VERSION"
    [ "$V" = "$EXP" ] && echo "[OK] ~/.claude/commands/$s.md: $V" || { echo "[NG] ~/.claude/commands/$s.md: $V"; VERIFY_FAIL=1; }
  fi
done

# 本体同梱版 (~/.soloptilink/skills/)
for s in soloptilink soloptilink-boost soloptilink-upgrade; do
  if [ -f ~/.soloptilink/skills/$s/SKILL.md ]; then
    V=$(grep -m1 'description:' ~/.soloptilink/skills/$s/SKILL.md | grep -oE 'SoloptiLinkAI v[0-9]+\.[0-9]+' | head -1)
    EXP="SoloptiLinkAI v$TARGET_VERSION"
    [ "$V" = "$EXP" ] && echo "[OK] ~/.soloptilink/skills/$s: $V" || { echo "[NG] ~/.soloptilink/skills/$s: $V"; VERIFY_FAIL=1; }
  fi
done

# ネスト残骸が再発していないか
if [ -d ~/.claude/skills/skills ]; then
  echo "[NG] ネスト構造 ~/.claude/skills/skills が再生 — 退避してください"
  VERIFY_FAIL=1
fi

# 内訳サマリー
echo ""
echo "■ コアモジュール内訳 (v${TARGET_VERSION}):"
echo "  lib/*.sh:           $(ls ~/.soloptilink/lib/*.sh 2>/dev/null | wc -l)"
echo "  agents:             $(ls ~/.soloptilink/.claude/agents/*.md 2>/dev/null | wc -l)"
echo "  tests/unit:         $(ls ~/.soloptilink/tests/unit/*.bats 2>/dev/null | wc -l)"
echo "  domains:            $(ls ~/.soloptilink/domains/*.json 2>/dev/null | wc -l)"
echo "  quality-fortresses: $(ls ~/.soloptilink/lib/quality-fortresses/*.sh 2>/dev/null | wc -l)"

if [ $VERIFY_FAIL -eq 0 ]; then
  echo ""
  echo "═══════════════════════════════════════════════════════════════"
  echo "  ✓ 整合性検証 PASS — 全箇所で v${TARGET_VERSION} に統一"
  echo "═══════════════════════════════════════════════════════════════"
else
  echo ""
  echo "═══════════════════════════════════════════════════════════════"
  echo "  ✗ 整合性検証 FAIL — 上記 [NG] 箇所を手動修正してください"
  echo "═══════════════════════════════════════════════════════════════"
fi
```

### Step 9: UIキャッシュ案内【v2024.1新設・必須アナウンス】

**ファイル更新は完了しても、現セッションは起動時のスキル一覧スナップショットを保持しているため、UI には旧版が残る。これを必ずユーザに伝える。**

完了時に以下を必ず表示する:

```
═══════════════════════════════════════════════════════════════
  ✓ アップグレード完了: v${CURRENT_VERSION} → v${TARGET_VERSION}
═══════════════════════════════════════════════════════════════

【UI への反映について】
ファイル更新は完了しましたが、Claude Code はセッション起動時に
スキル一覧をキャッシュするため、現在のセッションでは引き続き旧版
(v${CURRENT_VERSION}) のスキル説明が UI に表示される可能性があります。

最新版 (v${TARGET_VERSION}) を UI に反映するには、以下のいずれかを
実施してください:

  1. Claude Code を完全に終了して再起動 (推奨)
  2. /clear で新セッションを開始
  3. ターミナルから claude を再実行

新セッションで /soloptilink-boost 等を入力すると、ホバー時の説明文は
v${TARGET_VERSION} ${TARGET_CODENAME} の内容に切り替わります。

【ロールバック】
問題があった場合は以下で復元可能:
  - メタのみロールバック: cp -r ~/.solai_meta_backup_<日付>/* (元の場所)
  - 全体ロールバック:     /soloptilink-upgrade --rollback
═══════════════════════════════════════════════════════════════
```

## アップグレード時の保持項目
以下はアップグレード時に上書きせず保持する:
- `docs/knowledge/` - 学習済みナレッジ
- `docs/chain-logs/` - 過去のセッションログ
- `~/.soloptilink/knowledge/` - RAGインデックス
- `.solai_initialized` - 初期化フラグ

## アップグレード時の更新項目
以下は最新版で上書きする:
- `chain.sh` - メインオーケストレーター + VERSION 定数 + ヘッダ進化履歴
- `setup.sh` - セットアップスクリプト
- `lib/` - 全モジュール (v2024.0 新規: lib/security/arte/v2024/policy-synthesizer/, runtime-defense/, incident-playbooks/, siem-bridge/)
- `lib/quality-fortresses/` - decafortress.sh, continuum-fortress.sh, sovereign-fortress.sh, cognitive-fortress.sh, adaptive-fortress.sh, offense-fortress.sh, hexafortress.sh〜nonafortress.sh, pentafortress.sh など 15 fortress
- `lib/security/arte/` - v2020 base + v2021/v2022/v2023/v2024 進化系列
- `domains/` - 27ドメインJSON
- `tests/` - 累計239テスト (v2020:74 + v2021:38 + v2022:35 + v2023:45 + v2024:47)
- `.claude/agents/` - エージェント定義 50体
- `CLAUDE.md` - プロジェクト指示書 (タイトル・概要のバージョン記載)
- `plugins/` - プラグインテンプレート
- **スキルメタ (二系統同時)**:
  - `~/.claude/skills/<name>/SKILL.md` (Skill 系統)
  - `~/.claude/commands/<name>.md` (Slash Command 系統)
  - `~/.soloptilink/skills/<name>/SKILL.md` (本体同梱)

## ロールバック
アップグレードに問題があった場合:
```bash
# 全体バックアップから復元
LATEST_BACKUP=$(ls -td ~/.solai_backup_* | head -1)
rm -rf ~/.soloptilink
mv "$LATEST_BACKUP" ~/.soloptilink
echo "全体ロールバック完了: $LATEST_BACKUP"

# メタのみロールバック (description が壊れた等の軽微なケース)
LATEST_META=$(ls -td ~/.solai_meta_backup_* | head -1)
cp "$LATEST_META/chain.sh" ~/.soloptilink/chain.sh
cp "$LATEST_META/CLAUDE.md" ~/.soloptilink/CLAUDE.md
for s in soloptilink soloptilink-boost soloptilink-upgrade; do
  [ -f "$LATEST_META/claude_skills/$s/SKILL.md" ] && cp "$LATEST_META/claude_skills/$s/SKILL.md" ~/.claude/skills/$s/SKILL.md
  [ -f "$LATEST_META/claude_commands/$s.md" ]    && cp "$LATEST_META/claude_commands/$s.md"    ~/.claude/commands/$s.md
done
echo "メタロールバック完了: $LATEST_META"
```

## 使用例
```
/soloptilink-upgrade
→ ~/Downloads/から最新ZIPを自動検出してアップグレード

/soloptilink-upgrade ~/Downloads/SoloptiLinkAI-Chain-v2024.0.zip
→ 指定ZIPからアップグレード

/soloptilink-upgrade /path/to/dev/project
→ 開発プロジェクトから直接アップグレード

/soloptilink-upgrade --target 2024.0
→ ターゲットバージョンを明示指定 (メタのみ更新したい場合に便利)

/soloptilink-upgrade --rollback
→ 直近のバックアップから復元
```

## 引数の解釈
- 引数なし → 自動検索 (Downloads ZIP / カレント周辺の chain.sh / メタのみモード)
- `.zip` で終われば ZIPファイルとして処理
- ディレクトリパスなら直接コピー
- `--target X.Y` で TARGET_VERSION を明示
- `--rollback` で直近バックアップから復元
- `--meta-only` で Step 4 (rsync) をスキップして Step 5.5/7/8/9 のみ実行

## 設計理念 (なぜこの構造になっているか)

### 二系統スキル管理問題への構造的解答
Claude Code は履歴的経緯から **Skill (`~/.claude/skills/<name>/SKILL.md`)** と **Slash Command (`~/.claude/commands/<name>.md`)** を別系統で管理している。前者は AI 内部の `Skill` ツールが呼び出し、後者は UI のスラッシュ補完に表示される。**両方の description / H1 を同時に更新しないと UI が古い表示を続ける**。Step 7 で必ず両系統を bumpVersion する。

### ネスト残骸問題への構造的解答
過去のリリース過程で `~/.claude/skills/skills/<name>/` のような誤配置が混入した実例あり。Claude Code はこれも別スキルとして拾うため、UI に旧バージョンが二重表示される。Step 5.5c で必ず検出 → 退避(削除ではなく改名)する。

### コード最新+メタ旧問題への構造的解答
v2024.0 のコード本体 (lib/security/arte/v2024/, lib/quality-fortresses/decafortress.sh 等) は配置済みだが、VERSION 定数や CLAUDE.md タイトルが旧 (v2019.0 等) のまま、というケースが今回発生した。Step 2 で META_ONLY_MODE を自動判定し、Step 5.5/7/8 中心の軽量アップグレードに切り替える。

### UIキャッシュ問題への構造的解答
ファイル更新後も現セッションは起動時のスナップショットを保持するため、ユーザは「変わってない」と報告しやすい。Step 9 で **必ず** Claude Code 再起動を案内する。
