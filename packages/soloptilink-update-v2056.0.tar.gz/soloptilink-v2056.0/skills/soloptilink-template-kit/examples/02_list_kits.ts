/**
 * Example 02: 全 kit の一覧と詳細を markdown で出力
 *
 *   npx tsx examples/02_list_kits.ts
 *   npx tsx examples/02_list_kits.ts > kits.md
 */

import { listKits, describeAllKits } from '../lib';

const summaries = listKits();
console.error(`# Loaded ${summaries.length} kit(s)`);
for (const s of summaries) {
  console.error(`  - ${s.kit_id}: ${s.name_ja} (${s.estimated_completion_percent}%)`);
}

// stdout には markdown を吐く
process.stdout.write(describeAllKits());
process.stdout.write('\n');
