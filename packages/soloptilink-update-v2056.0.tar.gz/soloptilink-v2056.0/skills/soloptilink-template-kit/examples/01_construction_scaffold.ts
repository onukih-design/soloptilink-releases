/**
 * Example 01: 工事台帳キットを /tmp/sample-construction-app/ にスキャフォールド
 *
 *   npx tsx examples/01_construction_scaffold.ts
 */

import { scaffoldKit } from '../lib';

const TARGET_DIR = process.env.TARGET_DIR ?? '/tmp/sample-construction-app';

const report = scaffoldKit('construction', TARGET_DIR);

console.log('-----------------------------------------------------------');
console.log(`✓ kit:        ${report.kit_id}`);
console.log(`✓ target_dir: ${report.target_dir}`);
console.log(`✓ files:      ${report.files_written.length}`);
console.log(`✓ lines:      ${report.total_lines}`);
console.log(`✓ setup:      ${report.setup_minutes} min`);
console.log('-----------------------------------------------------------');
console.log('Next: cd', TARGET_DIR, '&& npm install && npm run dev');
