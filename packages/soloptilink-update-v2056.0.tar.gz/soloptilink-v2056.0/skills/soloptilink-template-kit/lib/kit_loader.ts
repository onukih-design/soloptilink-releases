/**
 * soloptilink-template-kit / kit_loader
 *
 * 業種別 kit 設計図 (kits/*.json) を読み込み、JSON Schema 検証して
 * 後続の scaffolder に渡せる KitDefinition 型に変換する。
 *
 * - loadKit(kit_id)    : 1 つの kit を読み込み + 検証
 * - listKits()         : 全 kit のサマリーを返す
 * - describeKit(kit_id): markdown で詳細を返す
 *
 * 検証エラーは Error を throw する (fail-loud)。
 */

import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

// ---------------------------------------------------------------------------
// 型定義 (KitDefinition)
// ---------------------------------------------------------------------------

export interface KitField {
  name: string;
  type: string;
  required?: boolean;
  unique?: boolean;
  default?: unknown;
  description?: string;
}

export interface KitRelation {
  model: string;
  type: 'one-to-one' | 'one-to-many' | 'many-to-one' | 'many-to-many';
  field?: string;
  back?: string;
}

export interface KitPrismaModel {
  model: string;
  description?: string;
  fields: KitField[];
  relations?: KitRelation[];
}

export interface KitRoute {
  path: string;
  purpose: string;
  type?: 'dashboard' | 'list' | 'detail' | 'new' | 'edit' | 'report' | 'api';
  resource?: string;
  /**
   * この導線が読み書きする Prisma モデル名 (2026-08-06 / T-312 追加)。
   *
   * 資源名とモデル名が対応しない導線 (例: /incidents は IncidentReport、
   * /reports は ExpenseReport) で、**kit 定義側が対応を明示する**ための宣言。
   * 省略時は scaffolder が prisma_models の model 名との突合で解決し、
   * それでも決まらない導線は 501 のまま残して README に理由を開示する
   * (モデル名を推測して、存在しない prisma 呼び出しを埋めることはしない)。
   */
  model?: string;
}

export interface KitStack {
  framework: string;
  ui: string;
  orm: string;
  db: string;
  auth: string;
  test?: string;
  lint?: string;
}

export interface KitScaffoldOutputs {
  files_count: number;
  lines_count_approx: number;
  estimated_setup_minutes: number;
}

export interface KitDefinition {
  kit_id: string;
  name_ja: string;
  name_en?: string;
  industry: string;
  industry_ja?: string;
  description: string;
  use_case: string;
  stack: KitStack;
  domain_dictionary_ref: string;
  applicable_laws: string[];
  terminology?: Record<string, string>;
  mandatory_fields?: Record<string, unknown>;
  legal_rules?: Record<string, unknown>;
  ui_hints?: Record<string, unknown>;
  prisma_models: KitPrismaModel[];
  routes: KitRoute[];
  ui_pages?: number;
  api_routes?: number;
  report_templates: string[];
  dashboard_kpis: string[];
  mobile_priority?: string[];
  integration_hooks?: Record<string, string>;
  estimated_completion_percent: number;
  remaining_customizations?: string[];
  scaffold_outputs: KitScaffoldOutputs;
}

export interface KitSummary {
  kit_id: string;
  name_ja: string;
  industry: string;
  industry_ja?: string;
  description: string;
  estimated_completion_percent: number;
  files_count: number;
  setup_minutes: number;
}

// ---------------------------------------------------------------------------
// パス解決
// ---------------------------------------------------------------------------

/**
 * kit JSON ファイルが置かれているディレクトリを解決する。
 *
 * 1. 環境変数 SOLOPTILINK_TEMPLATE_KIT_DIR
 * 2. このソースファイルの 1 つ上の `kits/`
 * 3. ~/.claude/skills/soloptilink-template-kit/kits/
 */
export function resolveKitsDir(): string {
  const env = process.env.SOLOPTILINK_TEMPLATE_KIT_DIR;
  if (env && existsSync(env)) {
    return env;
  }
  // import.meta.url → このファイルのディレクトリ
  let here: string;
  try {
    here = dirname(fileURLToPath(import.meta.url));
  } catch {
    // CommonJS フォールバック
    here = __dirname;
  }
  const candidate1 = resolve(here, '..', 'kits');
  if (existsSync(candidate1)) return candidate1;
  const home = process.env.HOME || process.env.USERPROFILE || '~';
  const candidate2 = join(home, '.claude', 'skills', 'soloptilink-template-kit', 'kits');
  return candidate2;
}

// ---------------------------------------------------------------------------
// 軽量 JSON Schema バリデータ (ajv 不依存)
// ---------------------------------------------------------------------------

/**
 * KitDefinition 用の軽量バリデータ。
 *
 * schemas/kit.schema.json と整合する範囲で必須項目と最小サイズを検査する。
 * ランタイム依存を増やさないため自前実装。
 */
export function validateKit(kit: unknown): asserts kit is KitDefinition {
  if (!kit || typeof kit !== 'object') {
    throw new Error('kit definition must be an object');
  }
  const k = kit as Record<string, unknown>;

  const requireString = (key: string, minLen = 1) => {
    const v = k[key];
    if (typeof v !== 'string' || v.length < minLen) {
      throw new Error(`kit.${key} must be a string (>= ${minLen} chars)`);
    }
  };

  requireString('kit_id', 2);
  if (!/^[a-z][a-z_]+$/.test(k.kit_id as string)) {
    throw new Error(`kit.kit_id must be snake_case: got "${k.kit_id}"`);
  }
  requireString('name_ja', 2);
  requireString('industry', 2);
  requireString('description', 10);
  requireString('use_case', 10);
  requireString('domain_dictionary_ref', 5);
  if (!/^soloptilink-japan\/domains\/[a-z_]+\.json$/.test(k.domain_dictionary_ref as string)) {
    throw new Error(
      `kit.domain_dictionary_ref must match soloptilink-japan/domains/*.json: got "${k.domain_dictionary_ref}"`,
    );
  }

  // stack
  const stack = k.stack as Record<string, unknown> | undefined;
  if (!stack || typeof stack !== 'object') {
    throw new Error('kit.stack is required');
  }
  for (const f of ['framework', 'ui', 'orm', 'db', 'auth']) {
    if (typeof stack[f] !== 'string' || (stack[f] as string).length === 0) {
      throw new Error(`kit.stack.${f} must be a non-empty string`);
    }
  }

  // applicable_laws
  const laws = k.applicable_laws;
  if (!Array.isArray(laws) || laws.length < 2) {
    throw new Error('kit.applicable_laws must contain >= 2 entries');
  }

  // prisma_models
  const models = k.prisma_models;
  if (!Array.isArray(models) || models.length < 3) {
    throw new Error('kit.prisma_models must contain >= 3 models');
  }
  for (const m of models as KitPrismaModel[]) {
    if (!m.model || !/^[A-Z][A-Za-z0-9]+$/.test(m.model)) {
      throw new Error(`prisma_model.model must be PascalCase: got "${m?.model}"`);
    }
    if (!Array.isArray(m.fields) || m.fields.length < 2) {
      throw new Error(`prisma_model "${m.model}" must have >= 2 fields`);
    }
  }

  // routes
  const routes = k.routes;
  if (!Array.isArray(routes) || routes.length < 5) {
    throw new Error('kit.routes must contain >= 5 entries');
  }
  for (const r of routes as KitRoute[]) {
    if (!r.path?.startsWith('/')) {
      throw new Error(`route.path must start with /: got "${r?.path}"`);
    }
    if (typeof r.purpose !== 'string') {
      throw new Error(`route "${r.path}" missing purpose`);
    }
  }

  // report_templates
  const reports = k.report_templates;
  if (!Array.isArray(reports) || reports.length < 2) {
    throw new Error('kit.report_templates must contain >= 2 entries');
  }

  // dashboard_kpis
  const kpis = k.dashboard_kpis;
  if (!Array.isArray(kpis) || kpis.length < 2) {
    throw new Error('kit.dashboard_kpis must contain >= 2 entries');
  }

  // estimated_completion_percent
  const pct = k.estimated_completion_percent;
  if (typeof pct !== 'number' || pct < 80 || pct > 100) {
    throw new Error(`kit.estimated_completion_percent must be in [80,100]: got ${pct}`);
  }

  // scaffold_outputs
  const out = k.scaffold_outputs as KitScaffoldOutputs | undefined;
  if (!out || typeof out !== 'object') {
    throw new Error('kit.scaffold_outputs is required');
  }
  if (typeof out.files_count !== 'number' || out.files_count < 1) {
    throw new Error('kit.scaffold_outputs.files_count must be >= 1');
  }
  if (typeof out.lines_count_approx !== 'number' || out.lines_count_approx < 1) {
    throw new Error('kit.scaffold_outputs.lines_count_approx must be >= 1');
  }
  if (typeof out.estimated_setup_minutes !== 'number' || out.estimated_setup_minutes < 1) {
    throw new Error('kit.scaffold_outputs.estimated_setup_minutes must be >= 1');
  }
}

// ---------------------------------------------------------------------------
// 公開 API
// ---------------------------------------------------------------------------

/**
 * 1 つの kit を読み込み、検証して返す。
 * 検証失敗時は throw。
 */
export function loadKit(kit_id: string): KitDefinition {
  const dir = resolveKitsDir();
  const file = join(dir, `${kit_id}.json`);
  if (!existsSync(file)) {
    throw new Error(`kit "${kit_id}" not found at ${file}`);
  }
  const raw = readFileSync(file, 'utf8');
  let parsed: unknown;
  try {
    parsed = JSON.parse(raw);
  } catch (e) {
    throw new Error(`kit "${kit_id}" is not valid JSON: ${(e as Error).message}`);
  }
  validateKit(parsed);
  if ((parsed as KitDefinition).kit_id !== kit_id) {
    throw new Error(
      `kit_id mismatch: file "${kit_id}" contains kit_id "${(parsed as KitDefinition).kit_id}"`,
    );
  }
  return parsed as KitDefinition;
}

/**
 * 全 kit のサマリーを返す。
 */
export function listKits(): KitSummary[] {
  const dir = resolveKitsDir();
  if (!existsSync(dir)) return [];
  const files = readdirSync(dir).filter((f) => f.endsWith('.json'));
  const summaries: KitSummary[] = [];
  for (const f of files) {
    const id = f.replace(/\.json$/, '');
    try {
      const k = loadKit(id);
      summaries.push({
        kit_id: k.kit_id,
        name_ja: k.name_ja,
        industry: k.industry,
        industry_ja: k.industry_ja,
        description: k.description,
        estimated_completion_percent: k.estimated_completion_percent,
        files_count: k.scaffold_outputs.files_count,
        setup_minutes: k.scaffold_outputs.estimated_setup_minutes,
      });
    } catch {
      // 不正な kit はスキップ (ただし listKits 全体は壊さない)
    }
  }
  // 安定ソート
  summaries.sort((a, b) => a.kit_id.localeCompare(b.kit_id));
  return summaries;
}

/**
 * kit を markdown 形式で詳述する (営業現場のデモ向け)。
 */
export function describeKit(kit_id: string): string {
  const k = loadKit(kit_id);
  const lines: string[] = [];
  lines.push(`# ${k.name_ja} (${k.kit_id})`);
  lines.push('');
  lines.push(`**業種**: ${k.industry_ja ?? k.industry}`);
  lines.push(`**完成度**: ${k.estimated_completion_percent}%`);
  lines.push(
    `**スキャフォールド規模**: ${k.scaffold_outputs.files_count} files / 約 ${k.scaffold_outputs.lines_count_approx} 行 / セットアップ ${k.scaffold_outputs.estimated_setup_minutes} 分`,
  );
  lines.push('');
  lines.push('## 概要');
  lines.push(k.description);
  lines.push('');
  lines.push('## ユースケース');
  lines.push(k.use_case);
  lines.push('');
  lines.push('## 技術スタック');
  for (const [key, val] of Object.entries(k.stack)) {
    lines.push(`- **${key}**: ${val}`);
  }
  lines.push('');
  lines.push('## 適用法令');
  for (const law of k.applicable_laws) lines.push(`- ${law}`);
  lines.push('');
  lines.push('## Prisma モデル');
  for (const m of k.prisma_models) {
    lines.push(`### ${m.model}${m.description ? ` — ${m.description}` : ''}`);
    lines.push('');
    lines.push('| field | type | required | description |');
    lines.push('|-------|------|----------|-------------|');
    for (const f of m.fields) {
      lines.push(
        `| ${f.name} | ${f.type} | ${f.required ? '✓' : ''} | ${f.description ?? ''} |`,
      );
    }
    lines.push('');
  }
  lines.push('## ルート');
  for (const r of k.routes) {
    lines.push(`- \`${r.path}\` — ${r.purpose}`);
  }
  lines.push('');
  lines.push('## 帳票テンプレート');
  for (const t of k.report_templates) lines.push(`- ${t}`);
  lines.push('');
  lines.push('## ダッシュボード KPI');
  for (const k2 of k.dashboard_kpis) lines.push(`- ${k2}`);
  lines.push('');
  if (k.remaining_customizations && k.remaining_customizations.length > 0) {
    lines.push('## 残り 10% カスタマイズ');
    for (const c of k.remaining_customizations) lines.push(`- ${c}`);
  }
  return lines.join('\n');
}

/**
 * 与えられたファイル/ディレクトリが存在するか確認するユーティリティ
 * (テストで使う)。
 */
export function _statSafe(p: string): boolean {
  try {
    statSync(p);
    return true;
  } catch {
    return false;
  }
}
