/**
 * soloptilink-template-kit - public API
 *
 * 全モジュールをまとめてエクスポート + 一括スキャフォールド helper を提供。
 *
 * ## overlay 対応 (2026-07-09 追加)
 * `scaffoldKit(kit_id, ...)` は kit_overlay_resolver 経由で kit をロードする。
 * base kit_id に対応する overlay kit (overlay_of=<base>) が kits/ に存在すれば
 * 非破壊マージした KitDefinition が scaffolder に渡る。kill-switch は
 * `ENABLE_KIT_OVERLAY=off` で base のみに完全復帰。詳細は kit_overlay_resolver.ts。
 * kit_loader.ts / scaffolder.ts は無編集 (SHA-256 baseline 維持)。
 */

export * from './kit_loader';
export * from './scaffolder';
export * from './kit_overlay_resolver';

import { loadKit, listKits, describeKit, type KitDefinition, type KitSummary } from './kit_loader';
import { scaffold, type ScaffoldOptions, type ScaffoldReport } from './scaffolder';
import { loadKitWithOverlay } from './kit_overlay_resolver';

/**
 * 1 コマンドで kit を targetDir にスキャフォールドする helper.
 *
 * base kit_id を渡すと overlay (overlay_of=<base>) があれば自動適用する。
 * kill-switch `ENABLE_KIT_OVERLAY=off` で従来動作 (base のみ) に完全復帰。
 * overlay 自身の kit_id (例: 'medical_overlay') を直接渡した場合は overlay を
 * base として扱う (silently 昇格しない=呼出側の明示選択)。
 *
 * @param kit_id      kits/<kit_id>.json に対応する識別子
 * @param target_dir  書き出し先ディレクトリ
 * @param options     scaffold オプション
 * @returns           ScaffoldReport (書き出したファイル一覧と行数)
 *
 * @example
 *   const report = scaffoldKit('construction', '/tmp/koji-app');
 *   console.log(`${report.files_written.length} files, ${report.total_lines} lines`);
 */
export function scaffoldKit(
  kit_id: string,
  target_dir: string,
  options: ScaffoldOptions = {},
): ScaffoldReport {
  const kit: KitDefinition = loadKitWithOverlay(kit_id);
  return scaffold(kit, target_dir, options);
}

/**
 * markdown 形式で全 kit を一覧表示する (営業現場のデモ向け).
 */
export function describeAllKits(): string {
  const summaries: KitSummary[] = listKits();
  const lines: string[] = [];
  lines.push('# soloptilink-template-kit - 利用可能な Kit 一覧');
  lines.push('');
  lines.push('| kit_id | 日本語名 | 業種 | 完成度 | files | setup |');
  lines.push('|--------|----------|------|--------|-------|-------|');
  for (const s of summaries) {
    lines.push(
      `| ${s.kit_id} | ${s.name_ja} | ${s.industry_ja ?? s.industry} | ${s.estimated_completion_percent}% | ${s.files_count} | ${s.setup_minutes}分 |`,
    );
  }
  lines.push('');
  lines.push('### 詳細');
  for (const s of summaries) {
    lines.push('');
    lines.push(describeKit(s.kit_id));
    lines.push('');
    lines.push('---');
  }
  return lines.join('\n');
}
