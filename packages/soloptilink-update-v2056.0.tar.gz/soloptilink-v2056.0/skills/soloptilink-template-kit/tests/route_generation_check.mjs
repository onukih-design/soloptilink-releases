#!/usr/bin/env node
/**
 * soloptilink-template-kit / 宣言ルートと生成ファイルの突合ゲート
 *
 * ## なぜ必要か (実測で確認した不具合)
 * 既存 33 軸は kit JSON の**宣言だけ**を検査し、scaffold 実行後の生成物を
 * 1 本も測っていなかった。その結果:
 *   - drawing kit は宣言 23 ルート中 5 本 (/drawings/formats, /drawings/[id]/edit,
 *     /drawings/[id]/revisions, /api/drawings/[id], /api/dashboard/kpi) が
 *     生成されないまま 33/33 PASS
 *   - 全 14 kit の合計では 150 本が未生成
 *   - README.md と docs/DESIGN_CONTRACT.md は kit.routes を無条件に全件列挙する
 *     ため、**存在しない画面を機能一覧としてお客様に約束**していた
 *
 * ## このゲートが測るもの (すべて実 scaffold の生成結果が出典)
 *   A-1: 宣言ルートのうち生成予定のものが実ファイルとして存在する
 *   A-2: README / DESIGN_CONTRACT が列挙した画面に実ファイルが必ず存在する
 *   A-3: 生成された .ts / .tsx が TypeScript で構文エラーなく解析できる
 *   A-4: 同じ階層に別名の可変セグメントが同居していない (Next.js ビルド不能条件)
 *   A-6: 実装していない書き込みを成功として返す API を生成していない
 *        (2026-08-06 新設 — 「保存に成功したのに一覧に出てこない」の床)
 *   B-*: 欠陥側 — 生成物を 1 本壊す/消すと上の軸が確かに落ちること
 *   C-*: kill-switch — TEMPLATE_KIT_DECLARED_ROUTES=off で旧挙動に戻り、
 *        そのときも README は未生成の画面を機能として書かないこと
 *
 * 実行: node tests/route_generation_check.mjs
 * 未測定を合格として記録しない (typescript が無ければ exit 2 で「未測定」を返す)
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  readFileSync, writeFileSync, readdirSync, existsSync, mkdirSync, rmSync,
} from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, join, resolve, sep } from 'node:path';
import { createRequire } from 'node:module';
import { tmpdir } from 'node:os';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '..');
const KITS_DIR = join(ROOT, 'kits');
const WORK = join(tmpdir(), `tk-route-gate-${process.pid}`);

// kit_loader は「自分の置き場の 1 つ上の kits/」を見る。テストは lib を一時
// ディレクトリへ転写して実行するため、**必ずこのリポジトリの kits/ を明示する**。
// これを省くと ~/.claude/skills/... のミラーを測ってしまい、いま直した本体を
// 測っていないのに合格が出る (実測で確認済みの落とし穴)。
process.env.SOLOPTILINK_TEMPLATE_KIT_DIR = KITS_DIR;

const require_ = createRequire(join(ROOT, 'package.json'));
function loadTypeScript() {
  for (const c of ['typescript', '/opt/homebrew/lib/node_modules/typescript',
    '/usr/local/lib/node_modules/typescript']) {
    try { return require_(c); } catch { /* 次の候補 */ }
  }
  return null;
}
const ts = loadTypeScript();
if (!ts) {
  console.error('UNMEASURED: typescript が使えないため、生成ファイルを検査できませんでした。');
  console.error('このゲートは未測定を合格として記録しません。typescript を用意してから再実行してください。');
  process.exit(2);
}

function transpileLib(outDir) {
  mkdirSync(outDir, { recursive: true });
  for (const f of ['kit_loader.ts', 'scaffolder.ts', 'kit_overlay_resolver.ts', 'index.ts']) {
    const src = readFileSync(join(ROOT, 'lib', f), 'utf8');
    const js = ts.transpileModule(src, {
      compilerOptions: {
        module: ts.ModuleKind.ESNext,
        target: ts.ScriptTarget.ES2022,
        isolatedModules: true,
      },
      fileName: f,
    }).outputText.replace(
      /from '\.\/(kit_loader|scaffolder|kit_overlay_resolver)'/g, "from './$1.mjs'");
    writeFileSync(join(outDir, f.replace(/\.ts$/, '.mjs')), js, 'utf8');
  }
  return join(outDir, 'index.mjs');
}

rmSync(WORK, { recursive: true, force: true });
mkdirSync(WORK, { recursive: true });
const kitLib = await import(pathToFileURL(transpileLib(join(WORK, 'lib'))).href);

function walk(dir, base = dir, acc = []) {
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, e.name);
    if (e.isDirectory()) walk(p, base, acc);
    else acc.push(p.slice(base.length + 1));
  }
  return acc;
}

const KIT_IDS = readdirSync(KITS_DIR)
  .filter((f) => f.endsWith('.json'))
  .map((f) => f.replace(/\.json$/, ''))
  .sort();

/** kit を実際に展開して {kit, files, plan, readme, contract} を返す。 */
function scaffoldKit(kitId, label = kitId) {
  const target = join(WORK, 'out', label);
  rmSync(target, { recursive: true, force: true });
  kitLib.scaffoldKit(kitId, target);
  const kit = kitLib.loadKitWithOverlay(kitId);
  return {
    target,
    kit,
    files: new Set(walk(target)),
    plan: kitLib.routePlan(kit),
    readme: readFileSync(join(target, 'README.md'), 'utf8'),
    contract: readFileSync(join(target, 'docs', 'DESIGN_CONTRACT.md'), 'utf8'),
  };
}

/** README / DESIGN_CONTRACT の箇条書きから列挙されたルートを取り出す。 */
function listedRoutes(md) {
  const out = [];
  for (const line of md.split('\n')) {
    const m = /^- `(\/[^`]*)`/.exec(line.trim());
    if (m) out.push(m[1]);
  }
  return out;
}

/** 生成された TypeScript ファイルを構文解析し、エラー件数を返す。 */
function syntaxErrors(target) {
  const bad = [];
  for (const relPath of walk(target)) {
    if (!/\.tsx?$/.test(relPath)) continue;
    const src = readFileSync(join(target, relPath), 'utf8');
    const sf = ts.createSourceFile(
      relPath, src, ts.ScriptTarget.ES2022, true,
      relPath.endsWith('.tsx') ? ts.ScriptKind.TSX : ts.ScriptKind.TS,
    );
    // parseDiagnostics は公開 API ではないが、構文エラーの有無だけを見るのに使う
    const diags = sf.parseDiagnostics ?? [];
    if (diags.length > 0) {
      bad.push(`${relPath}: ${ts.flattenDiagnosticMessageText(diags[0].messageText, ' ')}`);
    }
  }
  return bad;
}

// ---------------------------------------------------------------------------
// 「保存したふり」検出 (2026-08-06 新設 / T-301 追補)
//
// 経緯: コレクション API の POST が prisma 呼び出しをコメントのまま
// `const created = { id: 'demo', ... }` を 201 で返しており、新規作成画面は
// res.ok を見て一覧へ遷移していた。利用者から見ると「保存に成功したのに
// 一覧に出てこない」。A-3 は構文しか見ないため、この嘘は 63/63 PASS を
// すり抜けていた。ここが「実装していない書き込みを成功として返さない」の床。
// ---------------------------------------------------------------------------

const WRITE_METHODS = ['POST', 'PUT', 'PATCH', 'DELETE'];

/** 行コメント / ブロックコメントを落とす (コメント内の prisma を活きた呼び出しと数えないため)。 */
function stripComments(src) {
  return src.replace(/\/\*[\s\S]*?\*\//g, '').replace(/^[ \t]*\/\/.*$/gm, '');
}

/** 文字列リテラルの中身を空白で潰す (中の括弧で対応付けを誤らないため。長さは保つ)。 */
function maskLiterals(src) {
  return src.replace(/'(?:[^'\\\n]|\\.)*'|"(?:[^"\\\n]|\\.)*"|`(?:[^`\\]|\\.)*`/g,
    (s) => s[0] + ' '.repeat(Math.max(0, s.length - 2)) + s[0]);
}

/** open で示した開き括弧に対応する中身を返す。 */
function balanced(src, open, oc, cc) {
  let depth = 0;
  for (let j = open; j < src.length; j += 1) {
    if (src[j] === oc) depth += 1;
    else if (src[j] === cc) { depth -= 1; if (depth === 0) return src.slice(open + 1, j); }
  }
  return '';
}

/** export async function <METHOD> の本体を返す (無ければ null)。 */
function handlerBody(src, method) {
  const m = new RegExp(`export\\s+async\\s+function\\s+${method}\\s*\\(`).exec(src);
  if (!m) return null;
  const open = src.indexOf('{', m.index + m[0].length);
  return open < 0 ? null : balanced(src, open, '{', '}');
}

/** そのハンドラが返す成功ステータス (status 未指定は 200 とみなす)。 */
function successStatusesOf(body) {
  const out = [];
  const re = /return\s+NextResponse\.json\s*\(/g;
  let m;
  while ((m = re.exec(body)) !== null) {
    const open = body.indexOf('(', m.index);
    const args = balanced(body, open, '(', ')');
    const st = /status:\s*(\d{3})/.exec(args);
    const code = st ? Number(st[1]) : 200;
    if (code < 400) out.push(code);
  }
  return out;
}

/**
 * 生成された API のうち、活きた prisma 呼び出しが無いのに成功応答を返す
 * 書き込みハンドラを列挙する。1 件でもあれば「保存したふり」。
 */
function fabricatedWrites(target) {
  const bad = [];
  for (const relPath of walk(target)) {
    if (!relPath.startsWith(join('src', 'app', 'api')) || !relPath.endsWith('route.ts')) continue;
    const src = maskLiterals(stripComments(readFileSync(join(target, relPath), 'utf8')));
    for (const method of WRITE_METHODS) {
      const body = handlerBody(src, method);
      if (body === null) continue;
      if (/\bprisma\.\w+\./.test(body)) continue; // 実際に書いているなら対象外
      const ok = successStatusesOf(body);
      if (ok.length > 0) {
        bad.push(`${relPath}: ${method} が保存せずに ${[...new Set(ok)].join('/')} を返している`);
      }
    }
  }
  return bad;
}

/** 同じ階層に別名の可変セグメントが同居していないか (Next.js ビルド不能条件)。 */
function dynamicSegmentConflicts(files) {
  const claim = new Map();
  const bad = [];
  for (const f of files) {
    const segs = f.split(sep);
    let dir = '';
    for (const s of segs) {
      if (s.startsWith('[') && s.endsWith(']')) {
        const prev = claim.get(dir);
        if (prev && prev !== s) bad.push(`${dir || '/'}: ${prev} と ${s}`);
        else claim.set(dir, s);
      }
      dir = `${dir}/${s}`;
    }
  }
  return bad;
}

// ===========================================================================
// 健全側
// ===========================================================================

test('A-0: kits/ に検体が 10 件以上ある (検体ゼロで空回りしない)', () => {
  assert.ok(KIT_IDS.length >= 10, `kit 検体が少なすぎる: ${KIT_IDS.length}`);
});

for (const kitId of KIT_IDS) {
  test(`A-1: ${kitId} — 生成予定の宣言ルートが実ファイルとして存在する`, () => {
    const r = scaffoldKit(kitId);
    const missing = r.plan
      .filter((e) => e.generated && !r.files.has(e.file))
      .map((e) => `${e.route.path} -> ${e.file}`);
    assert.deepEqual(missing, [],
      `${kitId}: 宣言したのに生成されていない画面がある\n${missing.join('\n')}`);
  });

  test(`A-2: ${kitId} — README / 設計契約が列挙した画面に必ず実ファイルがある`, () => {
    const r = scaffoldKit(kitId);
    const byPath = new Map(r.plan.map((e) => [e.route.path, e]));
    for (const [label, md] of [['README.md', r.readme], ['DESIGN_CONTRACT.md', r.contract]]) {
      // 「未生成」節より前 (=機能として約束している部分) だけを対象にする
      const promised = md.split(/### (?:この版では生成していない画面|宣言はあるが生成していないもの)/)[0];
      for (const p of listedRoutes(promised)) {
        const e = byPath.get(p);
        if (!e) continue;      // routes 由来でない箇条書きは対象外
        assert.ok(e.generated && r.files.has(e.file),
          `${kitId}/${label}: 実体の無い画面 ${p} を機能一覧に載せている`);
      }
    }
  });

  test(`A-3: ${kitId} — 生成された TypeScript に構文エラーが無い`, () => {
    const r = scaffoldKit(kitId);
    const bad = syntaxErrors(r.target);
    assert.deepEqual(bad, [], `${kitId}: 構文エラーのある生成ファイル\n${bad.join('\n')}`);
  });

  test(`A-4: ${kitId} — 同じ階層に別名の可変セグメントが同居していない`, () => {
    const r = scaffoldKit(kitId);
    const bad = dynamicSegmentConflicts([...r.files]);
    assert.deepEqual(bad, [], `${kitId}: Next.js がビルドできない構成\n${bad.join('\n')}`);
  });

  test(`A-6: ${kitId} — 実装していない書き込みを成功として返す API を生成していない`, () => {
    const r = scaffoldKit(kitId);
    const bad = fabricatedWrites(r.target);
    assert.deepEqual(bad, [],
      `${kitId}: 保存していないのに成功を返す API がある (利用者には「保存できたのに一覧に出ない」と見える)\n${bad.join('\n')}`);
  });
}

test('A-5: 図面キットは対応形式の案内ページと施工計画の画面を実際に生成する (T-016 / T-018)', () => {
  const r = scaffoldKit('drawing');
  const must = [
    join('src', 'app', '(domain)', 'drawings', 'formats', 'page.tsx'),
    join('src', 'app', '(domain)', 'drawings', '[id]', 'edit', 'page.tsx'),
    join('src', 'app', '(domain)', 'drawings', '[id]', 'revisions', 'page.tsx'),
    join('src', 'app', 'api', 'drawings', '[id]', 'route.ts'),
    join('src', 'app', 'api', 'dashboard', 'kpi', 'route.ts'),
    join('src', 'app', '(domain)', 'construction-plans', 'page.tsx'),
    join('src', 'app', '(domain)', 'construction-plans', '[id]', 'schedule', 'page.tsx'),
    join('src', 'app', 'api', 'construction-plans', 'route.ts'),
  ];
  const missing = must.filter((m) => !r.files.has(m));
  assert.deepEqual(missing, [], `未生成: ${missing.join(', ')}`);
});

// ===========================================================================
// 欠陥側 (この検査が「常に合格する検査」でないことの実証)
// ===========================================================================

test('B-1: 生成ファイルを 1 本消すと A-1 の突合が確かに落ちる', () => {
  const r = scaffoldKit('drawing', 'drawing_mutated');
  const victim = r.plan.find((e) => e.generated && e.file.endsWith('page.tsx'));
  assert.ok(victim, '検体が取れない');
  rmSync(join(r.target, victim.file));
  const files = new Set(walk(r.target));
  const missing = r.plan.filter((e) => e.generated && !files.has(e.file));
  assert.ok(missing.length === 1 && missing[0].file === victim.file,
    `消したファイルを検出できていない (検出=${missing.length} 件)`);
});

test('B-2: 生成物に構文エラーを仕込むと A-3 が確かに落ちる', () => {
  const r = scaffoldKit('drawing', 'drawing_broken');
  const victim = [...r.files].find((f) => f.endsWith('.tsx'));
  writeFileSync(join(r.target, victim), 'export default function P( { return <div>;\n', 'utf8');
  const bad = syntaxErrors(r.target);
  assert.ok(bad.length >= 1, '構文エラーを検出できていない');
});

test('B-3: 実体の無い画面を README が約束したら A-2 が落ちる (旧挙動の再現)', () => {
  const r = scaffoldKit('drawing', 'drawing_promise');
  // 事故当時の README (kit.routes を無条件に全件列挙) を合成する
  const legacyReadme = r.kit.routes.map((x) => `- \`${x.path}\` — ${x.purpose}`).join('\n');
  // 生成されていない架空のルートを 1 本混ぜる
  const fake = '/drawings/this-page-does-not-exist';
  const md = `${legacyReadme}\n- \`${fake}\` — 実体の無い画面\n`;
  const byPath = new Map(r.plan.map((e) => [e.route.path, e]));
  const promised = listedRoutes(md);
  const liars = promised.filter((p) => {
    const e = byPath.get(p);
    return !e ? !r.files.has(`src/app/(domain)${p}/page.tsx`) : !r.files.has(e.file);
  });
  assert.ok(liars.includes(fake),
    '実体の無い画面を約束しても検出できていない');
});

test('B-4: 旧実装 (保存せずに固定値を 201 で返す) を仕込むと A-6 が確かに落ちる', () => {
  const r = scaffoldKit('drawing', 'drawing_fake_write');
  const victim = [...r.files].find(
    (f) => f.startsWith(join('src', 'app', 'api')) && f.endsWith('route.ts')
      && !f.includes('[') && !f.includes('dashboard'));
  assert.ok(victim, 'コレクション API の検体が取れない');
  // 2026-08-06 以前の buildApiRoute の POST を復元する
  writeFileSync(join(r.target, victim), `import { NextResponse } from 'next/server';
import { z } from 'zod';

const CreateSchema = z.object({ code: z.string(), name: z.string() });

export async function POST(req: Request) {
  const body = await req.json().catch(() => null);
  const parsed = CreateSchema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ error: parsed.error.flatten() }, { status: 400 });
  }
  // const created = await prisma.drawing.create({ data: parsed.data });
  const created = { id: 'demo', ...parsed.data };
  return NextResponse.json({ item: created }, { status: 201 });
}
`, 'utf8');
  const bad = fabricatedWrites(r.target);
  assert.ok(bad.some((b) => b.startsWith(victim) && b.includes('201')),
    `保存したふりを検出できていない (検出=${bad.length} 件: ${bad.join(' / ')})`);
});

test('B-5: 実際に prisma へ書く実装は誤検知しない (A-6 の健全側)', () => {
  const r = scaffoldKit('drawing', 'drawing_real_write');
  const victim = [...r.files].find(
    (f) => f.startsWith(join('src', 'app', 'api')) && f.endsWith('route.ts')
      && !f.includes('[') && !f.includes('dashboard'));
  assert.ok(victim, 'コレクション API の検体が取れない');
  writeFileSync(join(r.target, victim), `import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function POST(req: Request) {
  const data = await req.json();
  const created = await prisma.drawing.create({ data });
  return NextResponse.json({ item: created }, { status: 201 });
}
`, 'utf8');
  const bad = fabricatedWrites(r.target).filter((b) => b.startsWith(victim));
  assert.deepEqual(bad, [], '本当に保存している実装を誤って欠陥と判定している');
});

// ===========================================================================
// kill-switch
// ===========================================================================

test('C-1: TEMPLATE_KIT_DECLARED_ROUTES=off で旧挙動 (resource 展開のみ) に戻る', () => {
  const saved = process.env.TEMPLATE_KIT_DECLARED_ROUTES;
  process.env.TEMPLATE_KIT_DECLARED_ROUTES = 'off';
  try {
    const r = scaffoldKit('drawing', 'drawing_legacy');
    assert.ok(!r.files.has(join('src', 'app', '(domain)', 'drawings', 'formats', 'page.tsx')),
      'off にしても宣言ルートが生成されている');
    // ただし README は「生成されていない画面」を機能として書かない
    const promised = r.readme.split('### この版では生成していない画面')[0];
    const byPath = new Map(r.plan.map((e) => [e.route.path, e]));
    for (const p of listedRoutes(promised)) {
      const e = byPath.get(p);
      if (!e) continue;
      assert.ok(r.files.has(e.file),
        `off のときも実体の無い画面 ${p} を機能一覧に載せてはいけない`);
    }
    assert.match(r.readme, /この版では生成していない画面/,
      'off のとき未生成の画面を正直に開示していない');
  } finally {
    if (saved === undefined) delete process.env.TEMPLATE_KIT_DECLARED_ROUTES;
    else process.env.TEMPLATE_KIT_DECLARED_ROUTES = saved;
  }
});

test('Z: 一時ディレクトリの後始末', () => {
  rmSync(WORK, { recursive: true, force: true });
  assert.ok(!existsSync(WORK));
});
