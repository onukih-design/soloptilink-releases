#!/usr/bin/env node
/**
 * soloptilink-template-kit セルフチェック
 *
 * Node 18+ 標準の node:test を使う。TypeScript ランタイムは不要。
 * 実行:
 *   node tests/template_kit_check.mjs
 *
 * 期待: pass >= 15 / fail = 0
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, existsSync, statSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '..');

const EXPECTED_KIT_IDS = [
  'construction',
  'drawing',               // 2026-08-01 新設 (T-018 図面管理・base とは独立の単独 kit)
  'manufacturing',
  'real_estate',
  'legal',
  'care',
  'medical',
  'medical_overlay',       // 2026-07-09 新設 (Phase B エンジン接地 overlay・base=medical)
  'dispensing_pharmacy',   // 2026-07-09 新設 (調剤薬局)
  'home_nursing',          // 2026-07-09 新設 (訪問看護)
  'education',
  'crm',
  'order',
  'expense',
];

function readJson(path) {
  return JSON.parse(readFileSync(path, 'utf8'));
}

function readText(path) {
  return readFileSync(path, 'utf8');
}

// ---------------------------------------------------------------------------
// 1) スキル必須ファイルの存在
// ---------------------------------------------------------------------------

test('SKILL.md exists with frontmatter', () => {
  const p = join(ROOT, 'SKILL.md');
  assert.ok(existsSync(p), 'SKILL.md must exist');
  const md = readText(p);
  assert.match(md, /^---/, 'frontmatter must start with ---');
  assert.match(md, /name:\s*soloptilink-template-kit/, 'name must be soloptilink-template-kit');
  assert.match(md, /description:/, 'description must be present');
  assert.match(md, /argument-hint:/, 'argument-hint must be present');
  assert.match(md, /allowed-tools:/, 'allowed-tools must be present');
});

test('README.md exists', () => {
  assert.ok(existsSync(join(ROOT, 'README.md')), 'README.md must exist');
});

test('lib/ source files exist', () => {
  for (const f of ['kit_loader.ts', 'scaffolder.ts', 'index.ts']) {
    assert.ok(existsSync(join(ROOT, 'lib', f)), `lib/${f} must exist`);
  }
});

test('schemas/kit.schema.json is valid JSON', () => {
  const p = join(ROOT, 'schemas', 'kit.schema.json');
  assert.ok(existsSync(p), 'schemas/kit.schema.json must exist');
  const schema = readJson(p);
  assert.equal(schema.type, 'object');
  assert.ok(Array.isArray(schema.required), 'required must be an array');
  assert.ok(schema.required.includes('kit_id'));
  assert.ok(schema.required.includes('prisma_models'));
  assert.ok(schema.required.includes('routes'));
});

// ---------------------------------------------------------------------------
// 2) 10種 kits/*.json が揃う
// ---------------------------------------------------------------------------

test('14 kit JSON files exist with expected ids (2026-08-01: 図面管理を追加)', () => {
  const kitsDir = join(ROOT, 'kits');
  assert.ok(existsSync(kitsDir), 'kits/ directory must exist');
  const files = readdirSync(kitsDir).filter((f) => f.endsWith('.json'));
  assert.equal(files.length, 14, `expected 14 kit files, got ${files.length}`);
  for (const id of EXPECTED_KIT_IDS) {
    assert.ok(existsSync(join(kitsDir, `${id}.json`)), `kits/${id}.json missing`);
  }
});

test('all kit_ids are unique', () => {
  const kitsDir = join(ROOT, 'kits');
  const ids = readdirSync(kitsDir)
    .filter((f) => f.endsWith('.json'))
    .map((f) => readJson(join(kitsDir, f)).kit_id);
  const set = new Set(ids);
  assert.equal(set.size, ids.length, 'kit_id must be unique across all kits');
  assert.equal(set.size, 14, 'must have exactly 14 unique kit_ids');
});

// ---------------------------------------------------------------------------
// 3) 各 kit json の構造検証
// ---------------------------------------------------------------------------

const REQUIRED_TOP_KEYS = [
  'kit_id',
  'name_ja',
  'industry',
  'description',
  'use_case',
  'stack',
  'domain_dictionary_ref',
  'applicable_laws',
  'prisma_models',
  'routes',
  'report_templates',
  'dashboard_kpis',
  'estimated_completion_percent',
  'scaffold_outputs',
];

test('every kit has required top-level keys', () => {
  for (const id of EXPECTED_KIT_IDS) {
    const k = readJson(join(ROOT, 'kits', `${id}.json`));
    for (const key of REQUIRED_TOP_KEYS) {
      assert.ok(
        Object.prototype.hasOwnProperty.call(k, key),
        `kit ${id}: missing required key "${key}"`,
      );
    }
  }
});

test('every kit has >= 3 prisma_models', () => {
  for (const id of EXPECTED_KIT_IDS) {
    const k = readJson(join(ROOT, 'kits', `${id}.json`));
    assert.ok(
      Array.isArray(k.prisma_models) && k.prisma_models.length >= 3,
      `kit ${id}: prisma_models must be >= 3, got ${k.prisma_models?.length}`,
    );
    for (const m of k.prisma_models) {
      assert.ok(/^[A-Z][A-Za-z0-9]+$/.test(m.model), `kit ${id}: model "${m.model}" must be PascalCase`);
      assert.ok(Array.isArray(m.fields) && m.fields.length >= 2, `kit ${id}: model ${m.model} must have >=2 fields`);
    }
  }
});

test('every kit has >= 5 routes', () => {
  for (const id of EXPECTED_KIT_IDS) {
    const k = readJson(join(ROOT, 'kits', `${id}.json`));
    assert.ok(
      Array.isArray(k.routes) && k.routes.length >= 5,
      `kit ${id}: routes must be >= 5, got ${k.routes?.length}`,
    );
    for (const r of k.routes) {
      assert.ok(typeof r.path === 'string' && r.path.startsWith('/'), `kit ${id}: route.path must start with /`);
      assert.ok(typeof r.purpose === 'string' && r.purpose.length > 0, `kit ${id}: route ${r.path} missing purpose`);
    }
  }
});

test('every kit has >= 2 applicable_laws', () => {
  for (const id of EXPECTED_KIT_IDS) {
    const k = readJson(join(ROOT, 'kits', `${id}.json`));
    assert.ok(
      Array.isArray(k.applicable_laws) && k.applicable_laws.length >= 2,
      `kit ${id}: applicable_laws must be >= 2, got ${k.applicable_laws?.length}`,
    );
  }
});

test('every kit has >= 2 report_templates and dashboard_kpis', () => {
  for (const id of EXPECTED_KIT_IDS) {
    const k = readJson(join(ROOT, 'kits', `${id}.json`));
    assert.ok(
      Array.isArray(k.report_templates) && k.report_templates.length >= 2,
      `kit ${id}: report_templates must be >= 2`,
    );
    assert.ok(
      Array.isArray(k.dashboard_kpis) && k.dashboard_kpis.length >= 2,
      `kit ${id}: dashboard_kpis must be >= 2`,
    );
  }
});

test('every kit has estimated_completion_percent >= 80', () => {
  for (const id of EXPECTED_KIT_IDS) {
    const k = readJson(join(ROOT, 'kits', `${id}.json`));
    assert.ok(typeof k.estimated_completion_percent === 'number');
    assert.ok(
      k.estimated_completion_percent >= 80 && k.estimated_completion_percent <= 100,
      `kit ${id}: estimated_completion_percent must be in [80,100], got ${k.estimated_completion_percent}`,
    );
  }
});

test('every kit has stack with required fields', () => {
  for (const id of EXPECTED_KIT_IDS) {
    const k = readJson(join(ROOT, 'kits', `${id}.json`));
    assert.ok(k.stack && typeof k.stack === 'object', `kit ${id}: stack must be object`);
    for (const f of ['framework', 'ui', 'orm', 'db', 'auth']) {
      assert.ok(typeof k.stack[f] === 'string' && k.stack[f].length > 0, `kit ${id}: stack.${f} missing`);
    }
  }
});

test('every kit references soloptilink-japan/domains/*.json', () => {
  for (const id of EXPECTED_KIT_IDS) {
    const k = readJson(join(ROOT, 'kits', `${id}.json`));
    assert.ok(typeof k.domain_dictionary_ref === 'string', `kit ${id}: domain_dictionary_ref missing`);
    assert.match(
      k.domain_dictionary_ref,
      /^soloptilink-japan\/domains\/[a-z_]+\.json$/,
      `kit ${id}: domain_dictionary_ref must point to soloptilink-japan/domains/*.json`,
    );
  }
});

test('every kit has scaffold_outputs with required fields', () => {
  for (const id of EXPECTED_KIT_IDS) {
    const k = readJson(join(ROOT, 'kits', `${id}.json`));
    const out = k.scaffold_outputs;
    assert.ok(out && typeof out === 'object', `kit ${id}: scaffold_outputs missing`);
    assert.ok(typeof out.files_count === 'number' && out.files_count >= 1);
    assert.ok(typeof out.lines_count_approx === 'number' && out.lines_count_approx >= 1);
    assert.ok(typeof out.estimated_setup_minutes === 'number' && out.estimated_setup_minutes >= 1);
  }
});

// ---------------------------------------------------------------------------
// 4) lib のシグネチャ確認 (TypeScript ソースを文字列で grep)
// ---------------------------------------------------------------------------

test('kit_loader exports required functions', () => {
  const src = readText(join(ROOT, 'lib', 'kit_loader.ts'));
  assert.match(src, /export function loadKit\s*\(/, 'loadKit must be exported');
  assert.match(src, /export function listKits\s*\(/, 'listKits must be exported');
  assert.match(src, /export function describeKit\s*\(/, 'describeKit must be exported');
  assert.match(src, /export function validateKit\s*\(/, 'validateKit must be exported');
  assert.match(src, /export interface KitDefinition/, 'KitDefinition interface must be exported');
});

test('scaffolder exports required functions', () => {
  const src = readText(join(ROOT, 'lib', 'scaffolder.ts'));
  assert.match(src, /export function scaffold\s*\(/, 'scaffold must be exported');
  assert.match(src, /export interface ScaffoldReport/, 'ScaffoldReport interface must be exported');
  assert.match(src, /export interface ScaffoldOptions/, 'ScaffoldOptions interface must be exported');
});

test('index.ts re-exports and provides scaffoldKit helper', () => {
  const src = readText(join(ROOT, 'lib', 'index.ts'));
  assert.match(src, /export \* from '\.\/kit_loader'/);
  assert.match(src, /export \* from '\.\/scaffolder'/);
  assert.match(src, /export function scaffoldKit\s*\(/, 'scaffoldKit must be exported');
});

// ---------------------------------------------------------------------------
// 5) examples / tests / Node 互換
// ---------------------------------------------------------------------------

test('examples files exist', () => {
  assert.ok(existsSync(join(ROOT, 'examples', '01_construction_scaffold.ts')));
  assert.ok(existsSync(join(ROOT, 'examples', '02_list_kits.ts')));
});

test('Node 18+ compatible (process.version check)', () => {
  const major = Number(process.version.replace(/^v/, '').split('.')[0]);
  assert.ok(major >= 18, `Node >= 18 required, got ${process.version}`);
});

test('no `// TODO` placeholder remaining in lib/ or kits/', () => {
  const targets = [
    join(ROOT, 'lib', 'kit_loader.ts'),
    join(ROOT, 'lib', 'scaffolder.ts'),
    join(ROOT, 'lib', 'index.ts'),
  ];
  for (const id of EXPECTED_KIT_IDS) {
    targets.push(join(ROOT, 'kits', `${id}.json`));
  }
  for (const t of targets) {
    const src = readText(t);
    assert.ok(!/\/\/\s*TODO/.test(src), `${t} contains "// TODO"`);
  }
});

test('every kit JSON file is at least 80 lines (rich content)', () => {
  for (const id of EXPECTED_KIT_IDS) {
    const p = join(ROOT, 'kits', `${id}.json`);
    const lines = readText(p).split('\n').length;
    assert.ok(lines >= 80, `kit ${id}: expected >= 80 lines for rich content, got ${lines}`);
  }
});

test('domain_dictionary_ref points to existing soloptilink-japan domain (when sibling skill exists)', () => {
  const home = process.env.HOME || process.env.USERPROFILE || '';
  const domainsDir = home ? join(home, '.claude', 'skills', 'soloptilink-japan', 'domains') : null;
  if (!domainsDir || !existsSync(domainsDir)) {
    // 環境依存: domains が無ければスキップ判定 (テスト自体は PASS)
    assert.ok(true, 'soloptilink-japan/domains not available in this env; skipping path resolution check');
    return;
  }
  for (const id of EXPECTED_KIT_IDS) {
    const k = readJson(join(ROOT, 'kits', `${id}.json`));
    const ref = k.domain_dictionary_ref;
    const fname = ref.replace('soloptilink-japan/domains/', '');
    const target = join(domainsDir, fname);
    assert.ok(existsSync(target), `kit ${id}: referenced domain dict not found at ${target}`);
  }
});

test('first prisma_model field is "id" with cuid()/uuid()/autoincrement default', () => {
  for (const id of EXPECTED_KIT_IDS) {
    const k = readJson(join(ROOT, 'kits', `${id}.json`));
    for (const m of k.prisma_models) {
      const idField = m.fields.find((f) => f.name === 'id');
      if (!idField) continue; // 一部モデルでは省略可
      assert.equal(idField.type, 'String', `kit ${id} model ${m.model}: id should be String`);
    }
  }
});

// ---------------------------------------------------------------------------
// 6) 生成器契約ガード (scaffolder.ts は SHA-256 baseline 固定のため kit 側で守る)
// ---------------------------------------------------------------------------

const PRISMA_SCALARS = ['DateTime', 'String', 'Int', 'Float', 'Decimal', 'Boolean', 'Json', 'Bytes', 'BigInt'];

test('String 型フィールドに全大文字の既定値を置かない (scaffolder が引用符なし @default を出し Prisma 不正になる)', () => {
  // scaffolder.ts buildPrismaModel: /^[A-Z_]+$/ の既定値は enum 値とみなし引用符なしで出力する。
  // String 型に全大文字既定値を置くと `field String @default(ACTIVE)` となり prisma validate が落ちる。
  for (const id of EXPECTED_KIT_IDS) {
    const k = readJson(join(ROOT, 'kits', `${id}.json`));
    for (const m of k.prisma_models) {
      for (const f of m.fields) {
        if (f.type !== 'String') continue;
        if (typeof f.default !== 'string') continue;
        assert.ok(
          !/^[A-Z_]+$/.test(f.default),
          `kit ${id} model ${m.model}.${f.name}: String 型の既定値 "${f.default}" は引用符なしで出力され Prisma が不正になる`,
        );
      }
    }
  }
});

test('非スカラー型 (enum) フィールドの既定値は enum 値の形 (全大文字) である', () => {
  for (const id of EXPECTED_KIT_IDS) {
    const k = readJson(join(ROOT, 'kits', `${id}.json`));
    for (const m of k.prisma_models) {
      for (const f of m.fields) {
        if (PRISMA_SCALARS.includes(f.type)) continue;
        if (f.default === undefined) continue;
        assert.ok(
          /^[A-Z][A-Z_]*$/.test(String(f.default)),
          `kit ${id} model ${m.model}.${f.name}: enum 型 ${f.type} の既定値 "${f.default}" が enum 値の形ではない`,
        );
      }
    }
  }
});

// ---------------------------------------------------------------------------
// 7) drawing kit (T-018) 固有の不変条件
// ---------------------------------------------------------------------------

const DRAWING_REQUIRED_MODELS = [
  'Drawing',
  'DrawingRevision',
  'DrawingProjectLink',
  'QuantityTakeoff',
  'AreaDiscrepancy',
];

test('drawing kit: 図面案件に必要な 5 モデルが揃う', () => {
  const k = readJson(join(ROOT, 'kits', 'drawing.json'));
  const names = k.prisma_models.map((m) => m.model);
  for (const want of DRAWING_REQUIRED_MODELS) {
    assert.ok(names.includes(want), `drawing kit: モデル ${want} が無い (実際: ${names.join(', ')})`);
  }
});

test('drawing kit: 単価・金額・許容差の閾値に既定値を持たない (単価を製品側で作らない原則)', () => {
  // 図面から決まるのは数量だけ。単価/歩掛り/許容差は利用者入力であり、
  // 製品側が既定値を埋めると「誤った見積がそのまま出る」実害になる。
  const k = readJson(join(ROOT, 'kits', 'drawing.json'));
  const NO_DEFAULT_FIELDS = {
    QuantityTakeoff: ['unitPrice', 'amount'],
    AreaDiscrepancy: ['toleranceRate'],
  };
  for (const [modelName, fieldNames] of Object.entries(NO_DEFAULT_FIELDS)) {
    const m = k.prisma_models.find((x) => x.model === modelName);
    assert.ok(m, `drawing kit: モデル ${modelName} が無い`);
    for (const fname of fieldNames) {
      const f = m.fields.find((x) => x.name === fname);
      assert.ok(f, `drawing kit: ${modelName}.${fname} が無い`);
      assert.ok(
        !Object.prototype.hasOwnProperty.call(f, 'default'),
        `drawing kit: ${modelName}.${fname} に既定値が入っている (利用者入力でなければならない)`,
      );
      assert.equal(f.required, false, `drawing kit: ${modelName}.${fname} は任意 (未入力を許す) でなければならない`);
    }
  }
});

test('drawing kit: 数量フィールドは必須で保持される (数量拾い結果の保持)', () => {
  const k = readJson(join(ROOT, 'kits', 'drawing.json'));
  const m = k.prisma_models.find((x) => x.model === 'QuantityTakeoff');
  const q = m.fields.find((x) => x.name === 'quantity');
  assert.ok(q, 'QuantityTakeoff.quantity が無い');
  assert.equal(q.required, true, 'QuantityTakeoff.quantity は必須');
  const unit = m.fields.find((x) => x.name === 'unit');
  assert.ok(unit && unit.required === true, 'QuantityTakeoff.unit は必須');
});

test('drawing kit: 面積不一致は記載面積と算出面積の両方を保持する', () => {
  const k = readJson(join(ROOT, 'kits', 'drawing.json'));
  const m = k.prisma_models.find((x) => x.model === 'AreaDiscrepancy');
  for (const fname of ['notedArea', 'computedArea', 'differenceValue', 'differenceRate']) {
    const f = m.fields.find((x) => x.name === fname);
    assert.ok(f && f.required === true, `AreaDiscrepancy.${fname} が必須で存在しない`);
  }
});

test('drawing kit: 必須 4 画面のルートが宣言されている', () => {
  const k = readJson(join(ROOT, 'kits', 'drawing.json'));
  const paths = k.routes.map((r) => r.path);
  const REQUIRED_SCREENS = [
    '/drawings',              // 図面台帳 一覧
    '/drawings/[id]',         // 図面 詳細
    '/drawing-revisions',     // 版数履歴
    '/drawing-revisions/[id]', // 読取レポート閲覧
  ];
  for (const p of REQUIRED_SCREENS) {
    assert.ok(paths.includes(p), `drawing kit: 必須画面ルート ${p} が無い`);
  }
});

test('drawing kit: manifest.json の 7 要件すべてが対応表で解決されている', () => {
  const k = readJson(join(ROOT, 'kits', 'drawing.json'));
  const map = k.manifest_requirement_map;
  assert.ok(map && typeof map === 'object', 'drawing kit: manifest_requirement_map が無い');

  const REQUIRED_KEYS = [
    'drawing_registry',
    'revision_control',
    'drawing_project_link',
    'quantity_record',
    'area_discrepancy_alert',
    'drawing_read_view',
    'file_format_guidance',
  ];
  const modelNames = k.prisma_models.map((m) => m.model);
  const routePaths = k.routes.map((r) => r.path);

  for (const key of REQUIRED_KEYS) {
    const entry = map[key];
    assert.ok(entry, `drawing kit: 要件 ${key} が対応表に無い`);
    assert.ok(Array.isArray(entry.models) && entry.models.length >= 1, `要件 ${key}: models が空`);
    assert.ok(Array.isArray(entry.screens) && entry.screens.length >= 1, `要件 ${key}: screens が空`);
    for (const mdl of entry.models) {
      assert.ok(modelNames.includes(mdl), `要件 ${key}: 参照モデル ${mdl} が prisma_models に実在しない`);
    }
    for (const scr of entry.screens) {
      assert.ok(routePaths.includes(scr), `要件 ${key}: 参照画面 ${scr} が routes に実在しない`);
    }
  }
});

test('drawing kit: 対応表が実 manifest.json の要件キーと一致する (本体併設時のみ)', () => {
  const home = process.env.HOME || process.env.USERPROFILE || '';
  const manifestPath = home ? join(home, '.soloptilink', 'lib', 'drawing-link', 'manifest.json') : null;
  if (!manifestPath || !existsSync(manifestPath)) {
    // 顧客配布環境では本体 lib/ が無い場合がある。存在時のみ突き合わせる。
    assert.ok(true, 'drawing-link/manifest.json not available in this env; skipping cross-check');
    return;
  }
  const manifest = readJson(manifestPath);
  const manifestKeys = (manifest.required_features_when_drawings_exist ?? []).map((f) => f.key);
  const k = readJson(join(ROOT, 'kits', 'drawing.json'));
  const mapKeys = Object.keys(k.manifest_requirement_map).filter((x) => x !== 'source');

  for (const key of manifestKeys) {
    assert.ok(mapKeys.includes(key), `manifest 要件 ${key} が drawing kit の対応表に無い`);
  }
  assert.equal(
    manifestKeys.length,
    mapKeys.length,
    `要件数が一致しない: manifest=${manifestKeys.length} kit=${mapKeys.length}`,
  );
});
