#!/usr/bin/env node
/**
 * soloptilink-template-kit / kit_overlay_resolver born-passing 両側弁別テスト
 *
 * ## テスト方針
 *
 * node 18 では TS を直接実行できないため、以下の two-layer 検証を行う:
 *
 * ### Layer 1: 純 JS 参考実装 (`resolverReference`) の挙動テスト
 *   ├─ (a) overlay あり + kill-switch on → merge 結果に engine_refs 上乗せ
 *   ├─ (b) overlay 削除 → base のみ (engine_refs 不在)
 *   ├─ (c) kill-switch off (ENABLE_KIT_OVERLAY=off) → overlay 存在しても base のみ
 *   └─ (d) silently 昇格禁止 → merge 結果の kit_id は常に base の kit_id
 *
 * ### Layer 2: TS 実装 (`lib/kit_overlay_resolver.ts`) と参考実装の等価性 grep
 *   ├─ ENABLE_KIT_OVERLAY 環境変数参照が TS に存在
 *   ├─ overlay_of 判定ロジックが TS に存在
 *   ├─ kit_id / overlay_of の silently 昇格禁止ロジックが TS に存在
 *   └─ overlay off キーワード (off / false / 0 / no) を TS 側も認識
 *
 * ### Layer 3: 統合効果テスト (実 kits/ 上での動線)
 *   ├─ listKits() 相当 (kits/*.json 全走査) で base=medical を必ず含む (industry='medical' 検索の base 動線)
 *   └─ overlay ファイル (medical_overlay.json) 削除→復元の md5 一致確認
 *
 * 実行:
 *   node tests/kit_overlay_check.mjs
 *
 * 期待: pass >= 12 / fail = 0
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, readdirSync, existsSync, writeFileSync, mkdtempSync, rmSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import { createHash } from 'node:crypto';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '..');

// ---------------------------------------------------------------------------
// 純 JS 参考実装 (Layer 1)
// 本ロジックは lib/kit_overlay_resolver.ts の直訳。TS 側を改変する場合は
// 本ファイルも同時に更新すること (Layer 2 の等価性 grep が乖離を検出する)。
// ---------------------------------------------------------------------------

const resolverReference = {
  overlayEnabled(env = process.env) {
    const raw = (env.ENABLE_KIT_OVERLAY ?? '').trim().toLowerCase();
    if (raw === '') return true;
    if (raw === 'off' || raw === 'false' || raw === '0' || raw === 'no') return false;
    return true;
  },
  applyOverlay(base, overlay) {
    const merged = JSON.parse(JSON.stringify(base));
    for (const [key, value] of Object.entries(overlay)) {
      if (key === 'kit_id' || key === 'overlay_of') continue;
      merged[key] = value;
    }
    return merged;
  },
  findOverlayFor(base_kit_id, kitsDir) {
    if (!existsSync(kitsDir)) return null;
    const files = readdirSync(kitsDir);
    for (const f of files) {
      if (!f.endsWith('.json')) continue;
      const path = join(kitsDir, f);
      try {
        const raw = JSON.parse(readFileSync(path, 'utf8'));
        if (raw && typeof raw === 'object' && raw.overlay_of === base_kit_id) {
          return { file: path, raw };
        }
      } catch { /* skip corrupt files */ }
    }
    return null;
  },
  loadKitWithOverlay(base_kit_id, kitsDir, env = process.env) {
    const basePath = join(kitsDir, `${base_kit_id}.json`);
    if (!existsSync(basePath)) throw new Error(`base kit not found: ${basePath}`);
    const base = JSON.parse(readFileSync(basePath, 'utf8'));
    if (!this.overlayEnabled(env)) return base;
    const found = this.findOverlayFor(base_kit_id, kitsDir);
    if (!found) return base;
    return this.applyOverlay(base, found.raw);
  },
};

// ---------------------------------------------------------------------------
// fixture 生成 (tmp ディレクトリに base + overlay を配置)
// ---------------------------------------------------------------------------

function createFixtureKitsDir() {
  const dir = mkdtempSync(join(tmpdir(), 'kit-overlay-test-'));
  // 最小のvalid base kit
  const base = {
    kit_id: 'fixture_base',
    name_ja: 'テスト用ベースキット',
    industry: 'test',
    description: 'born-passing 両側弁別用の fixture ベース kit。',
    use_case: 'テスト専用。実運用kitではない。',
    stack: { framework: 'x', ui: 'x', orm: 'x', db: 'x', auth: 'x' },
    domain_dictionary_ref: 'soloptilink-japan/domains/test.json',
    applicable_laws: ['法1', '法2'],
    prisma_models: [
      { model: 'ModelA', fields: [{ name: 'id', type: 'String' }, { name: 'name', type: 'String' }] },
      { model: 'ModelB', fields: [{ name: 'id', type: 'String' }, { name: 'code', type: 'String' }] },
      { model: 'ModelC', fields: [{ name: 'id', type: 'String' }, { name: 'value', type: 'Int' }] },
    ],
    routes: [
      { path: '/dashboard', purpose: 'dashboard' },
      { path: '/a', purpose: 'a list' },
      { path: '/b', purpose: 'b list' },
      { path: '/c', purpose: 'c list' },
      { path: '/api/a', purpose: 'a api' },
    ],
    report_templates: ['R1', 'R2'],
    dashboard_kpis: ['K1', 'K2'],
    estimated_completion_percent: 90,
    scaffold_outputs: { files_count: 20, lines_count_approx: 2000, estimated_setup_minutes: 3 },
  };
  writeFileSync(join(dir, 'fixture_base.json'), JSON.stringify(base, null, 2));
  // overlay
  const overlay = {
    kit_id: 'fixture_overlay',
    overlay_of: 'fixture_base',
    engine_refs: {
      functions: ['calcFoo', 'calcBar'],
      evidence: '/api/foo → calcFoo / /api/bar → calcBar',
    },
    phase_c_disclosure: {
      scope: ['接続X', '接続Y'],
      disclosure_line: 'Phase C 実接続 (接続X/Y) は接続テストボタンまで実装。実接続は次回リリース時に段階提供。',
    },
    overlay_note: 'テスト用 overlay',
  };
  writeFileSync(join(dir, 'fixture_overlay.json'), JSON.stringify(overlay, null, 2));
  return { dir, base, overlay };
}

function md5(buf) {
  return createHash('md5').update(buf).digest('hex');
}

// ---------------------------------------------------------------------------
// Layer 1: 参考実装の両側弁別
// ---------------------------------------------------------------------------

test('L1-a: overlay あり + kill-switch on → merge 結果に engine_refs / phase_c_disclosure が乗る', () => {
  const { dir } = createFixtureKitsDir();
  try {
    const merged = resolverReference.loadKitWithOverlay('fixture_base', dir, {});
    assert.equal(merged.kit_id, 'fixture_base', 'silently 昇格禁止: kit_id は base のまま');
    assert.ok(merged.engine_refs, 'engine_refs が上乗せされる');
    assert.deepEqual(merged.engine_refs.functions, ['calcFoo', 'calcBar']);
    assert.ok(merged.phase_c_disclosure, 'phase_c_disclosure が上乗せされる');
    assert.equal(merged.phase_c_disclosure.disclosure_line.includes('接続テストボタンまで'), true);
    assert.equal(merged.overlay_of, undefined, 'overlay_of は結果に露出しない');
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('L1-b: overlay ファイル削除 → base のみ (engine_refs 不在)', () => {
  const { dir } = createFixtureKitsDir();
  try {
    rmSync(join(dir, 'fixture_overlay.json'));
    const merged = resolverReference.loadKitWithOverlay('fixture_base', dir, {});
    assert.equal(merged.kit_id, 'fixture_base');
    assert.equal(merged.engine_refs, undefined, 'engine_refs 不在=base のみ');
    assert.equal(merged.phase_c_disclosure, undefined);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('L1-c: kill-switch off (ENABLE_KIT_OVERLAY=off) → overlay 存在しても base のみ', () => {
  const { dir } = createFixtureKitsDir();
  try {
    const merged = resolverReference.loadKitWithOverlay('fixture_base', dir, { ENABLE_KIT_OVERLAY: 'off' });
    assert.equal(merged.kit_id, 'fixture_base');
    assert.equal(merged.engine_refs, undefined, 'kill-switch off で overlay 無視');
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('L1-c-2: kill-switch 各値 (false/0/no) も off として扱う', () => {
  const { dir } = createFixtureKitsDir();
  try {
    for (const v of ['false', '0', 'no', 'FALSE', 'Off']) {
      const merged = resolverReference.loadKitWithOverlay('fixture_base', dir, { ENABLE_KIT_OVERLAY: v });
      assert.equal(merged.engine_refs, undefined, `kill-switch value="${v}" → overlay 無視`);
    }
    // on 側 (未設定含む) は overlay 適用
    for (const v of ['', 'on', 'true', '1', 'yes']) {
      const merged = resolverReference.loadKitWithOverlay('fixture_base', dir, { ENABLE_KIT_OVERLAY: v });
      assert.ok(merged.engine_refs, `kill-switch value="${v}" → overlay 適用`);
    }
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('L1-d: silently 昇格禁止 → merge 結果の kit_id は常に base の kit_id', () => {
  const { dir } = createFixtureKitsDir();
  try {
    const merged = resolverReference.loadKitWithOverlay('fixture_base', dir, {});
    assert.equal(merged.kit_id, 'fixture_base');
    assert.notEqual(merged.kit_id, 'fixture_overlay');
    // 逆に overlay 自身を loadKit した場合は overlay として扱う (silently 昇格ではない=明示選択)
    const overlaySelf = JSON.parse(readFileSync(join(dir, 'fixture_overlay.json'), 'utf8'));
    assert.equal(overlaySelf.kit_id, 'fixture_overlay');
    assert.equal(overlaySelf.overlay_of, 'fixture_base');
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

test('L1-d-2: 空overlay (overlay_of 一致するがフィールド無し) は base をそのまま返す', () => {
  const dir = mkdtempSync(join(tmpdir(), 'kit-overlay-empty-'));
  try {
    const base = {
      kit_id: 'e_base', name_ja: 'x', industry: 'x', description: 'x'.repeat(20), use_case: 'x'.repeat(20),
      stack: { framework: 'x', ui: 'x', orm: 'x', db: 'x', auth: 'x' },
      domain_dictionary_ref: 'soloptilink-japan/domains/test.json',
      applicable_laws: ['x', 'y'],
      prisma_models: [{ model: 'A', fields: [{ name: 'id', type: 'String' }, { name: 'v', type: 'Int' }] }, { model: 'B', fields: [{ name: 'id', type: 'String' }, { name: 'v', type: 'Int' }] }, { model: 'C', fields: [{ name: 'id', type: 'String' }, { name: 'v', type: 'Int' }] }],
      routes: [{ path: '/a', purpose: 'x' }, { path: '/b', purpose: 'x' }, { path: '/c', purpose: 'x' }, { path: '/d', purpose: 'x' }, { path: '/e', purpose: 'x' }],
      report_templates: ['R1', 'R2'], dashboard_kpis: ['K1', 'K2'],
      estimated_completion_percent: 90,
      scaffold_outputs: { files_count: 1, lines_count_approx: 1, estimated_setup_minutes: 1 },
    };
    writeFileSync(join(dir, 'e_base.json'), JSON.stringify(base));
    writeFileSync(join(dir, 'e_overlay.json'), JSON.stringify({ kit_id: 'e_overlay', overlay_of: 'e_base' }));
    const merged = resolverReference.loadKitWithOverlay('e_base', dir, {});
    assert.equal(merged.kit_id, 'e_base');
    assert.equal(merged.engine_refs, undefined);
  } finally {
    rmSync(dir, { recursive: true, force: true });
  }
});

// ---------------------------------------------------------------------------
// Layer 2: TS 実装との等価性 grep
// ---------------------------------------------------------------------------

test('L2-a: TS 実装が ENABLE_KIT_OVERLAY 環境変数を参照する', () => {
  const ts = readFileSync(join(ROOT, 'lib', 'kit_overlay_resolver.ts'), 'utf8');
  assert.match(ts, /ENABLE_KIT_OVERLAY/, 'TS に ENABLE_KIT_OVERLAY 参照');
  assert.match(ts, /overlayEnabled/, 'TS に overlayEnabled 関数定義');
});

test('L2-b: TS 実装が overlay_of 判定と silently 昇格禁止ロジックを持つ', () => {
  const ts = readFileSync(join(ROOT, 'lib', 'kit_overlay_resolver.ts'), 'utf8');
  assert.match(ts, /overlay_of/, 'TS に overlay_of 判定');
  assert.match(ts, /kit_id.*overlay_of|overlay_of.*kit_id/s, 'TS に kit_id と overlay_of の除外');
  assert.match(ts, /applyOverlay/, 'TS に applyOverlay 関数定義');
});

test('L2-c: TS 実装が off/false/0/no を kill-switch off として認識', () => {
  const ts = readFileSync(join(ROOT, 'lib', 'kit_overlay_resolver.ts'), 'utf8');
  for (const kw of ['off', 'false', '0', 'no']) {
    assert.match(ts, new RegExp(`'${kw}'`), `TS に kill-switch value '${kw}' 認識`);
  }
});

test('L2-d: TS 実装が loadKitWithOverlay / findOverlayFor 公開 API を持つ', () => {
  const ts = readFileSync(join(ROOT, 'lib', 'kit_overlay_resolver.ts'), 'utf8');
  assert.match(ts, /export function loadKitWithOverlay/);
  assert.match(ts, /export function findOverlayFor/);
  assert.match(ts, /export function resolveKitWithOverlay/);
});

test('L2-e: index.ts が scaffoldKit 経路で loadKitWithOverlay を呼ぶ (overlay 消費配線)', () => {
  const idx = readFileSync(join(ROOT, 'lib', 'index.ts'), 'utf8');
  assert.match(idx, /loadKitWithOverlay/, 'index.ts が loadKitWithOverlay を import');
  assert.match(idx, /scaffoldKit[\s\S]{0,500}loadKitWithOverlay/, 'scaffoldKit が loadKitWithOverlay を呼ぶ');
});

// ---------------------------------------------------------------------------
// Layer 3: 統合効果テスト (実 kits/ 上での動線)
// ---------------------------------------------------------------------------

test('L3-a: 実 kits/ の base=medical が listKits() 相当で必ず見える (industry=medical 検索の base 動線)', () => {
  const kitsDir = join(ROOT, 'kits');
  const files = readdirSync(kitsDir).filter((f) => f.endsWith('.json'));
  assert.ok(files.includes('medical.json'), 'medical.json が kits/ に存在');
  const raw = JSON.parse(readFileSync(join(kitsDir, 'medical.json'), 'utf8'));
  assert.equal(raw.kit_id, 'medical');
  assert.equal(raw.industry, 'medical', 'industry=medical で hit する');
});

/**
 * baseline 更新履歴 (更新するときは必ず理由を残すこと)
 *
 * - lib/scaffolder.ts : 02c7992e… → 5f969e85… (2026-08-01)
 *   理由: kit 定義の独自型 `EncryptedString` に対する変換が scaffolder に実装されておらず、
 *         型名がそのまま Prisma スキーマへ出力されていた。Prisma に該当型は無いため
 *         medical / medical_overlay の生成物は `prisma validate` を通らなかった
 *         (要配慮個人情報の暗号化という設計意図が実装に未到達)。
 *         保管型を String (暗号文) にマップし、アプリ層の暗号化実装
 *         (src/lib/crypto/*) を生成物へ同梱する変更を入れたため baseline を更新した。
 *         回帰は tests/prisma_schema_validate_check.mjs が実 `prisma validate` で守る
 *         (旧 scaffolder に戻すと同ゲートが 7 件不合格になることを実走で確認済み)。
 *
 * - lib/scaffolder.ts : 5f969e85… → 210f887a… (2026-08-06 / T-301)
 *   理由: 宣言ルート (kit.routes) を「リソース名」に潰してからしか使っておらず、
 *         全 14 kit で宣言 331 ルート中 150 本が生成されないまま、README と
 *         docs/DESIGN_CONTRACT.md は kit.routes を無条件に全件列挙していた
 *         (=実体の無い画面をお客様に「主要ページ」として約束していた)。
 *         routePlan() を新設して宣言 1 本ごとに生成先と生成可否を決め、
 *         scaffold() / buildReadme() / buildDesignContract() をその 1 か所へ寄せた。
 *         生成しないものは「この版では生成していない画面」として理由付きで開示する。
 *         kill-switch は TEMPLATE_KIT_DECLARED_ROUTES=off (旧挙動へ完全復帰)。
 *         回帰は tests/route_generation_check.mjs が実 scaffold の突合で守る
 *         (旧 scaffolder に戻すと 63 件中 61 件不合格になることを実走で確認済み。
 *          実測: 旧=pass 2/fail 61、新=pass 63/fail 0)。
 *
 * - lib/scaffolder.ts : … → 95d53bbe… (2026-08-06 / T-302 blind index)
 *   ★T-301 と同日・同ファイルへの並行改修のため SHA は 1 つに合流している。
 *   理由: dispensing_pharmacy kit は Patient に familyNameIndex / kanaIndex という
 *         索引列を宣言し routes も「氏名検索は blind index 使用」と約束していたが、
 *         索引値を計算する実装をどこも生成していなかった。氏名を暗号化した瞬間に
 *         氏名検索が例外も出さず常に 0 件を返す状態になる (最も気づきにくい壊れ方)。
 *         kit 定義の索引列に `blind_index_of` を宣言すると、
 *         blindIndexMap() / hasBlindIndex() / buildBlindIndexLib() が
 *         src/lib/crypto/blind-index.ts (HMAC-SHA256 + pepper) を生成し、
 *         暗号化 Extension が書込直前に平文から索引を算出して埋める。
 *         宣言不整合 (実在しない列を指す / 暗号化列が 0 件) は scaffold を例外で止める。
 *         回帰は tests/prisma_schema_validate_check.mjs の C-6/C-7/C-8 と、
 *         verify.d/L106-KIT-CRYPTO が守る
 *         (実測: 宣言を String へ戻した検体で C-6/C-7/C-9/C-10 の 4 軸が不合格になる。
 *          C-1〜C-5 は母集団が宣言依存のため落ちない — だから C-9/C-10 を足した)。
 *
 * - lib/scaffolder.ts : 95d53bbe… → 3f6e891b… (2026-08-06 / T-301 追補「保存したふり」根治)
 *   ★注意: 95d53bbe… は T-302 時点の値で、その後 T-301 が同ファイルへ builder 群を
 *   足したのに baseline を更新していなかった (実測: 実体 faef32c2… で L3-b が不合格のまま放置)。
 *   今回の更新はその積み残しも合流して閉じている。
 *   理由: 全 14 kit が生成するコレクション API (src/app/api/<resource>/route.ts) の POST が、
 *         prisma 呼び出しをコメントのまま `const created = { id: 'demo', ... }` を 201 で返し、
 *         新規作成画面は res.ok を見て一覧へ遷移していた。利用者から見ると
 *         「保存に成功したのに一覧に出てこない」。単体 API (buildApiItemRoute) は
 *         同じ場面で 501 を返す方針だったため、コレクション側だけが嘘をついていた。
 *         POST は 501 + 日本語の未実装理由、GET は measured=false を明示する形へ揃え、
 *         新規作成画面 (buildResourceNewPage / buildDeclaredNewPage) も 501 を
 *         成功として扱わず理由を表示するようにした。
 *         一覧画面の空状態も「未取得」と「0 件」を measured で弁別する。
 *   なぜ prisma を有効化しなかったか (実測に基づく判断):
 *         (1) 資源名からモデル名を推測する camelOf の解決成功率は 109 件中 53 件 (49%)。
 *             activities→activitie / properties→propertie / dispensing_record (アンダースコア未対応) など、
 *             残り 51% は実在しないモデルを呼び顧客環境で build が落ちる。
 *         (2) 全 114 モデル中 111 件 (97%) が code/name 以外に必須項目を持ち、
 *             CreateSchema {code, name} だけでは create が型でも実行時でも通らない。
 *         (3) 生成物の検査は構文のみ (A-3) で型検査が無いため、上の破綻をゲートが捕まえられない。
 *         → 実際に保存できる生成器にするには「モデル解決 + 必須項目からのフォーム/スキーマ生成」が要る。
 *           これは別課題として起票する。
 *   回帰: tests/route_generation_check.mjs の A-6 (全 14 kit) が守る。
 *         両側実証済み — 旧実装へ戻すと A-6 が 14 kit すべてで不合格になり (65/79)、
 *         本当に prisma へ書く実装は B-5 で誤検知しないことも確認している。
 *
 * - lib/scaffolder.ts : cc697079… → c2401dc8…
 *   (2026-08-07 / PFP-191〜193 「お客様が実際に見る画面」の 3 点是正)
 *   1) 生成器が自動で埋める列 (blind index の索引列) を入力欄・検証スキーマから外した。
 *      露出していた実測: dispensing_pharmacy の /patients/new と /patient/new に
 *      `<input name="familyNameIndex" required>` など計 4 箇所 + PatientCreateSchema の必須化。
 *      索引はコレクション API の POST が平文から算出して埋める (型の辻褄もここで合う)。
 *   2) 4 点セットの資源名を routes[].resource ではなく「宣言ルートに実在するコレクション URL」
 *      から採るようにし、URL の 2 系統併存 (/patients と /patient) を無くした。
 *      ダッシュボードのクイックリンク・一覧→詳細/新規作成・詳細→子画面の導線は
 *      buildGenerationPlan() が返す uiRoutes だけを見る。入る手段の無い画面は生成しない。
 *      実測: 生成画面/API 556→271 本、宣言由来でない重複 287 本 (51.6 パーセント) → URL 重複 0、
 *      トップからの到達不能 46 → 0。
 *   3) routes[].purpose / fields[].description の設計メモが画面の地の文へ素通ししていたのを止めた。
 *      内部向けの痕跡がある文はその項目ごと画面に出さず、列名は語単位の対訳表で日本語にする。
 *      実測: 顧客画面に出る内部文言・英語識別子 529 → 0。
 *   回帰: verify.d/L124-KIT-CUSTOMER-SCREEN (FORM / REACH / TEXT) が全 14 kit を実 scaffold して守る。
 *         両側実証済み — 索引列の入力欄を復活 + ダッシュボードのリンク削除 +
 *         設計メモの貼付を注入した検体で 26 件を検出し、現行の生成物では 0 件。
 *
 * - lib/scaffolder.ts : 3f6e891b… → cc697079…
 *   lib/kit_loader.ts  : 200a6781… → 90ff4d46…
 *   kits/care.json     : 82a60079… → ab5efbd4…
 *   (2026-08-06 / T-312 「生成直後から本当に保存・取得できる」)
 *   ★直前の T-301 追補が「別課題として起票する」と書き残した宿題を、ここで閉じている。
 *   理由: T-301 追補で「保存したふり」は止まったが (501 + 日本語の理由)、
 *         **本当に保存できる**状態には届いていなかった。原因は 3 つとも実測済み:
 *         (1) 資源名からモデル名を推測する camelOf() の解決成功率 45% (132 件中 59 件)
 *         (2) CreateSchema が {code, name} 固定 — 全 114 モデル中 111 件 (97%) が
 *             それ以外の必須項目を持つため create() が型でも実行時でも通らない
 *         (3) 生成物の検査が構文のみ (A-3) で、(1)(2) の破綻を誰も捕まえられない
 *   入れた変更:
 *         - 推測をやめ、kit 定義の prisma_models を正典に resource → model を解決する
 *           (正規化 + 単数形候補 + 全モデル共通接頭辞の除去。kit 側が routes[].model を
 *            宣言していればそれが最優先)。解決できない資源は 501 のまま残し、
 *            README / 設計契約の「保存・取得を有効にしていない資源」節に理由付きで開示する。
 *           実測: 結線率 45% → 72% (155 資源中 111)。8 kit は 100%。
 *         - モデルの必須項目から zod スキーマ (src/lib/validators.ts / 全モデル) と
 *           入力フォームを生成する。関連 ID は関連先から選択肢を引く選択欄、日付は日付入力、
 *           Decimal / Int は数値入力、enum は選択欄、Json はテキストエリア。
 *         - 一覧・詳細もモデルの実フィールドから列を作り、実際に prisma から取得する
 *           (API は measured=true を返す)。API の例外は src/lib/api-error.ts で
 *           日本語に変換し、内部情報を画面へ出さない。
 *         - kit 定義に既定値の宣言が無い主キー / createdAt / updatedAt (44 モデル) は
 *           生成器が @default(cuid()) / @default(now()) / @updatedAt を補完する
 *           (補完したことは schema の /// 注記に残す)。
 *         - kit 定義の説明文に含まれる波括弧・不等号を JSX 用にエスケープする
 *           (`{draft, finalized, exported}` が「存在しない変数の参照」になっていた)。
 *         - kits/care.json ほか 8 kit に routes[].model を 33 本追加 (資源名とモデル名が
 *           対応しない導線を kit 定義側で明示。例 /incidents → IncidentReport)。
 *   kill-switch: TEMPLATE_KIT_PRISMA_WIRING=off で T-301 時点の挙動 (501 / measured=false) へ復帰。
 *   回帰: tests/generated_typecheck_check.mjs (新設) が実 prisma generate + tsc --noEmit で守る。
 *         両側実証済み — 旧実装へ戻すと 20 軸中 18 軸が不合格 (pass 2 / fail 18)。
 *         旧実装の生成物の型エラー実測: care 21 / construction 18 / crm 18 / drawing 19 /
 *         expense 21 / medical 49 / medical_overlay 49 件。新実装は全 14 kit で 0 件。
 */
test('L3-b: kit_loader.ts / scaffolder.ts / kit.schema.json / skill-sot-guard.sh の SHA-256 baseline 保持', () => {
  const baseline = {
    'lib/kit_loader.ts': '90ff4d469dbb59de9d2520c0dc3a4edac8821e76a167811527619d318eabf3d2',
    // ★2026-08-08 更新: 平文で保管する要配慮関連列の理由を生成物 README へ書き出す節
    //   (buildPlaintextDisclosureReadmeSection) を追加したため基準値を採り直した。
    //   overlay の解決には触れていない (kit_loader / schema / medical.json / care.json は不変)。
    //
    // ★2026-08-17 更新 (署名鍵の置き場所是正) — 記録漏れの是正も兼ねる
    //   ① この基準値は **今日より前から既に実物と食い違っていた**。
    //      2026-08-17 の作業に入る前の scaffolder.ts は 6f39bda4… で、
    //      ここに書かれていた 06ac38… ではない。つまり誰かが scaffolder.ts を
    //      変更した際に、この台帳の更新を飛ばしていた (この検査はその時点から赤)。
    //      今日の作業でこの検査が落ちたわけではないことを記録として残す。
    //   ② 今日の意図した変更:
    //      ログイン状態の署名鍵 (AUTH_SECRET) を、見本ファイル (.env.example) では
    //      空欄にし、本物はこの環境専用の乱数として .env にだけ書き出す形へ変更した。
    //      従来は本物の鍵を .env.example に書いており、そのファイルは除外設定に
    //      載らないため、環境専用の鍵が毎回リポジトリへ載っていた。
    //      あわせて .gitignore に .soloptilink/ と 初回ログイン情報.md を追加した
    //      (初回ログイン検査が資格情報の受け渡し口をそこに作るため)。
    'lib/scaffolder.ts': 'e219d3cbc4cb356a72c823b43609766dff5ed0777624d053dbc770721b5fa9bb',
    'schemas/kit.schema.json': '8e63df136f5426dfaf1e769462b28d026bb4db9ecbf872fc3eab7a1a4daf2699',
    'kits/medical.json': 'ae3362b80d07c12d03d172cfa3ebab241c35e42e9e2330f79870e10259b6d7f6',
    'kits/care.json': 'ab5efbd4b7ef2e7cac8854dbc628a044fa41e557ca2897ebe5165939670d75bb',
  };
  for (const [rel, expected] of Object.entries(baseline)) {
    const path = join(ROOT, rel);
    const buf = readFileSync(path);
    const actual = createHash('sha256').update(buf).digest('hex');
    assert.equal(actual, expected, `${rel} SHA-256 unchanged`);
  }
});

test('L3-c: medical.json 25 キー構造 (実測 baseline) が保持されている', () => {
  const raw = JSON.parse(readFileSync(join(ROOT, 'kits', 'medical.json'), 'utf8'));
  const keys = Object.keys(raw);
  assert.equal(keys.length, 25, `medical.json は 25 キー (実測 baseline)`);
  const expectedKeys = ['kit_id', 'name_ja', 'name_en', 'industry', 'industry_ja', 'description', 'use_case', 'stack', 'domain_dictionary_ref', 'applicable_laws', 'terminology', 'mandatory_fields', 'legal_rules', 'ui_hints', 'prisma_models', 'routes', 'ui_pages', 'api_routes', 'report_templates', 'dashboard_kpis', 'mobile_priority', 'integration_hooks', 'estimated_completion_percent', 'remaining_customizations', 'scaffold_outputs'];
  for (const k of expectedKeys) assert.ok(keys.includes(k), `medical.json に ${k} キー存在`);
});
