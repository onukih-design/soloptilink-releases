#!/usr/bin/env node
/**
 * soloptilink-template-kit / 文書が参照する「本体の実体」パスの実在ゲート
 *
 * ## なぜ必要か (実測で確認した不具合)
 * medical_overlay.json の phase_c_disclosure.disclosure_line — 医療テンプレの免責文言の
 * SoT (唯一の正典) — が「本kitの Phase C 接続テストは lib/japan/phase-c-stubs 配下の
 * mock 応答のみを返す」と記載していたが、当該ディレクトリは本体に実在しなかった。
 * 同種の参照は home_nursing (lib/security/field-crypto.ts / lib/audit/logger.ts) と
 * dispensing_pharmacy (lib/security/*-middleware.ts) にもあり、いずれも実体が無かった。
 *
 * これらの purpose / description は scaffolder が README.md と docs/DESIGN_CONTRACT.md へ
 * **無条件に転記**するため、実在しないパスがそのまま顧客提示文書へ載る。
 * 既存 4 ゲート (33/14/24/63 軸) にこの軸は 1 本も無かった。
 *
 * ## 2026-08-07 の拡張 (T-313) — 生成物側パスまで広げた理由
 * 本ゲートは長らく「本体側パスだけを見る。生成物側 (src/...) は対象外」と自ら宣言して
 * いた。だが実測すると kit JSON の説明文には生成物側パスが 16 箇所書かれており
 * (dispensing_pharmacy / home_nursing の暗号化まわり)、それらも README / 設計契約へ
 * そのまま転記される。つまり「本体に無いパス」と同じ事故が生成物側でも起こりうるのに、
 * それを測る軸が本体側にも突合ゲート側にも存在しなかった。対象外の宣言は
 * 穴の説明であって穴の対策ではないため、ここで塞ぐ。
 *
 * ## このゲートが測るもの
 *   A-1: 各 kit JSON が参照する本体モジュールパスがすべて実在する
 *   A-2: 顧客提示文書の SoT (phase_c_disclosure.disclosure_line) が実在しないパスを含まない
 *   A-3: kit JSON が参照する生成物側パス (src/...) が【実 scaffold の生成物】に実在する
 *   A-4: README / 設計契約が「主要ページ」として列挙した画面に実ファイルが必ず存在する
 *        (= 実体の無い画面をお客様へ約束していない)
 *   A-5: 生成していない宣言ルートは全件が開示節に理由付きで載っている + 本数のラチェット
 *   B-1: [欠陥注入] 実在しないパスを 1 本混ぜると A-1 が確かに落ちる
 *   B-2: [欠陥注入] disclosure_line に実在しないパスを混ぜると A-2 が確かに落ちる
 *   B-4: [欠陥注入] 生成物に無い src/ パスを混ぜると A-3 が確かに落ちる
 *   B-5: [欠陥注入] 生成物を 1 本消すと A-4 が確かに落ちる
 *   B-6: [欠陥注入] 未生成ルートを開示節から取り除くと A-5 が確かに落ちる
 *
 * ## 宣言ルートの整理について採った方針 (2026-08-07 / T-313)
 * 受入基準は「宣言ルート = 生成ルートが一致 (実装しない宣言は削除済)」だったが、
 * **削除は採らず「開示で閉じる」を採る**。理由:
 *   - 宣言は業務要件の記録である。削除すれば数字は一致するが、必要な画面が要件から
 *     消えるだけで、お客様の不利益はむしろ増える (次版で拾えない)。
 *   - 数を合わせるもう一方の手段は「中身の無い画面を生成する」だが、これは
 *     「動いているように見えるだけ」の成果物になり、より重い虚偽になる。
 *   - 実害は「実体の無い画面を主要ページとして約束すること」であり、それは A-4 が
 *     ゼロであることで直接測れる (2026-08-07 実測: 13 kit / 宣言 298 本で 0 件)。
 * 「開示で閉じる」が逃げ道にならないよう、A-5 で (a) 未生成は全件が理由付きで開示節に
 * 載ること (b) 未生成本数が baseline を超えて増えないこと を同時に締める。
 *
 * ## 正直な限界 (測っていないこと)
 *   - パスが実在することだけを測る。中身がその説明どおりに振る舞うかは測っていない。
 *   - 生成物の型検査・ビルド可否は測らない (tests/generated_typecheck_check.mjs の担当)。
 *
 * 実行: node tests/path_reference_check.mjs
 * 未測定を合格として記録しない
 *   (解決起点がひとつも無ければ exit 2 / typescript が無く実 scaffold できなければ exit 2)。
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  readFileSync, writeFileSync, readdirSync, existsSync, mkdirSync, rmSync,
} from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { createRequire } from 'node:module';
import { homedir, tmpdir } from 'node:os';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '..');
const KITS_DIR = process.env.SOLOPTILINK_TEMPLATE_KIT_DIR ?? join(ROOT, 'kits');
const BODY = join(homedir(), '.soloptilink');

/** 本体のモジュール置き場。ここを起点とする表記だけを「本体実体への参照」とみなす。 */
const MODULE_TOPS = ['lib', 'scripts', 'skills', 'tests', 'templates', 'schemas', 'kits'];
const PATH_RE = new RegExp(
  `(?<![\\w/.-])((?:${MODULE_TOPS.join('|')})/[A-Za-z0-9._-]+(?:/[A-Za-z0-9._-]+)*)`, 'g');

/** 拡張子を省いて書かれることがあるため、代表的な拡張子も試す。 */
const SUFFIXES = ['', '.ts', '.tsx', '.js', '.mjs', '.json', '.sh', '.md', '.py'];

const ROOTS = [ROOT, BODY, join(homedir(), '.claude')].filter((p) => existsSync(p));

/** 退役先 (.retired/<日付>-<名>/) — 退役済みモジュールへの履歴参照は欠陥ではない。 */
const RETIRED = existsSync(join(BODY, '.retired'))
  ? readdirSync(join(BODY, '.retired')).map((d) => join(BODY, '.retired', d))
  : [];

if (ROOTS.length === 0) {
  console.error('UNMEASURED: 解決起点 (skill ディレクトリ / ~/.soloptilink / ~/.claude) が'
    + '1 つも見つからないため、パス参照を検査できませんでした。');
  console.error('このゲートは未測定を合格として記録しません。');
  process.exit(2);
}

function resolves(token) {
  for (const r of [...ROOTS, ...RETIRED]) {
    for (const s of SUFFIXES) {
      if (existsSync(join(r, token + s))) return true;
    }
  }
  return false;
}

/** JSON を走査し [jsonPath, 文字列] を列挙する。 */
function* strings(node, path = '') {
  if (node && typeof node === 'object' && !Array.isArray(node)) {
    for (const [k, v] of Object.entries(node)) yield* strings(v, `${path}.${k}`);
  } else if (Array.isArray(node)) {
    for (let i = 0; i < node.length; i += 1) yield* strings(node[i], `${path}[${i}]`);
  } else if (typeof node === 'string') {
    yield [path, node];
  }
}

/** 未解決の参照を [{kit, jsonPath, token}] で返す。 */
function unresolvedRefs(kitId, kit, only = null) {
  const out = [];
  for (const [jsonPath, s] of strings(kit)) {
    if (only && !jsonPath.startsWith(only)) continue;
    // .scaffold.* は生成物側の出力先であり、本体に実在しないのが正常。
    if (jsonPath.startsWith('.scaffold.')) continue;
    for (const m of s.matchAll(PATH_RE)) {
      const token = m[1];
      if (!resolves(token)) out.push({ kit: kitId, jsonPath, token });
    }
  }
  return out;
}

const KIT_IDS = readdirSync(KITS_DIR)
  .filter((f) => f.endsWith('.json'))
  .map((f) => f.replace(/\.json$/, ''))
  .sort();

const KITS = new Map(
  KIT_IDS.map((id) => [id, JSON.parse(readFileSync(join(KITS_DIR, `${id}.json`), 'utf8'))]),
);

function describe(rows) {
  return rows.map((r) => `  ${r.kit}.json ${r.jsonPath} → ${r.token}`).join('\n');
}

test('A-1: 各 kit が参照する本体モジュールパスがすべて実在する', () => {
  assert.ok(KIT_IDS.length > 0, 'kits/ に kit JSON がある');
  const bad = [];
  for (const [id, kit] of KITS) bad.push(...unresolvedRefs(id, kit));
  assert.equal(bad.length, 0,
    `実在しないパスを参照している箇所がある (顧客提示文書へ転記される):\n${describe(bad)}`);
});

test('A-2: 免責文言の SoT (phase_c_disclosure) が実在しないパスを含まない', () => {
  const withDisclosure = [...KITS].filter(([, k]) => k.phase_c_disclosure);
  assert.ok(withDisclosure.length > 0, 'phase_c_disclosure を持つ kit が存在する');
  const bad = [];
  for (const [id, kit] of withDisclosure) {
    bad.push(...unresolvedRefs(id, kit, '.phase_c_disclosure'));
  }
  assert.equal(bad.length, 0,
    `免責文言が実在しないパスを参照している:\n${describe(bad)}`);
});

test('B-1: [欠陥注入] 実在しないパスを混ぜると A-1 が確かに落ちる', () => {
  const probe = {
    description: '検体: lib/japan/this-module-does-not-exist を参照する',
  };
  const bad = unresolvedRefs('__probe__', probe);
  assert.equal(bad.length, 1, '注入した 1 本を検出する');
  assert.equal(bad[0].token, 'lib/japan/this-module-does-not-exist');
});

test('B-2: [欠陥注入] disclosure_line に実在しないパスを混ぜると A-2 が確かに落ちる', () => {
  const probe = {
    phase_c_disclosure: {
      disclosure_line: '本kitの応答は lib/japan/phase-c-stubs 配下の mock のみを返します',
    },
    description: '対象外であることの確認用に lib/japan/another-missing-one も置く',
  };
  const bad = unresolvedRefs('__probe__', probe, '.phase_c_disclosure');
  assert.equal(bad.length, 1, 'disclosure 配下の 1 本だけを検出する (description は対象外)');
  assert.equal(bad[0].token, 'lib/japan/phase-c-stubs');
});

test('B-3: 実在するパスは誤検知しない', () => {
  const real = { description: '本 kit は lib/japan/emr-core を呼ぶ' };
  assert.equal(unresolvedRefs('__probe__', real).length, 0,
    'lib/japan/emr-core は実在するので検出してはならない');
});

// ===========================================================================
// 生成物側パスの実在 (2026-08-07 新設 / T-313)
//
// ここから下は「実 scaffold の生成物」を出典にする。宣言や計画ではなく、
// 実際に書き出されたファイルの有無だけを見る。
// ===========================================================================

/** 生成物側パスの表記。末尾の句読点・閉じ括弧は語に含めない。 */
const SRC_RE = /(?<![\w/.-])(src\/[A-Za-z0-9._-]+(?:\/[A-Za-z0-9._[\]()-]*[A-Za-z0-9._[\]-])*)/g;

/** README / 設計契約で「未生成」を開示する節の見出し (scaffolder と同一文字列)。 */
const UNGENERATED_HEADING = '### この版では生成していない画面';

/** 未生成ルート本数のラチェット基準。増えたら落ちる。 */
const UNGEN_BASELINE_FILE = join(HERE, 'ungenerated_routes.baseline.json');

const require_ = createRequire(join(ROOT, 'package.json'));
function loadTypeScript() {
  for (const c of ['typescript', '/opt/homebrew/lib/node_modules/typescript',
    '/usr/local/lib/node_modules/typescript']) {
    try { return require_(c); } catch { /* 次の候補 */ }
  }
  return null;
}

/**
 * 実 scaffold を 1 度だけ行い、kit ごとの {files, plan, readme, contract} を返す。
 * typescript が無ければ null を返す (呼び出し側が exit 2 = 未測定で倒す)。
 */
function buildScaffoldFixture() {
  const ts = loadTypeScript();
  if (!ts) return null;

  const work = join(tmpdir(), `tk-pathref-${process.pid}`);
  rmSync(work, { recursive: true, force: true });
  mkdirSync(work, { recursive: true });

  // kit_loader は「自分の置き場の 1 つ上の kits/」を見る。lib を一時ディレクトリへ
  // 転写して読み込むため、必ずこのリポジトリの kits/ を明示する。省くとミラー側を
  // 測ってしまい、いま直した本体を測っていないのに合格が出る。
  process.env.SOLOPTILINK_TEMPLATE_KIT_DIR = KITS_DIR;

  const libOut = join(work, 'lib');
  mkdirSync(libOut, { recursive: true });
  for (const f of ['kit_loader.ts', 'scaffolder.ts', 'kit_overlay_resolver.ts', 'index.ts']) {
    const src = readFileSync(join(ROOT, 'lib', f), 'utf8');
    const js = ts.transpileModule(src, {
      compilerOptions: {
        module: ts.ModuleKind.ESNext,
        target: ts.ScriptTarget.ES2022,
        isolatedModules: true,
      },
      fileName: f,
    }).outputText.replace(
      /from '\.\/(kit_loader|scaffolder|kit_overlay_resolver)'/g, "from './$1.mjs'");
    writeFileSync(join(libOut, f.replace(/\.ts$/, '.mjs')), js, 'utf8');
  }
  return { work, entry: join(libOut, 'index.mjs') };
}

function walk(dir, base = dir, acc = []) {
  for (const e of readdirSync(dir, { withFileTypes: true })) {
    const p = join(dir, e.name);
    if (e.isDirectory()) walk(p, base, acc);
    else acc.push(p.slice(base.length + 1));
  }
  return acc;
}

const FIXTURE_SETUP = buildScaffoldFixture();
if (!FIXTURE_SETUP) {
  console.error('UNMEASURED: typescript が使えないため、生成物側パス (A-3〜A-5) を'
    + '実 scaffold で検査できませんでした。');
  console.error('このゲートは未測定を合格として記録しません。typescript を用意して再実行してください。');
  process.exit(2);
}

const kitLib = await import(pathToFileURL(FIXTURE_SETUP.entry).href);

/** 実 scaffold の結果。kit ごとに 1 回だけ展開する。 */
const SCAFFOLDS = new Map();
for (const [id, kit] of KITS) {
  // overlay 定義 (overlay_of を持つ) は base kit へマージされて届くものであり、
  // 単体で顧客へ渡る成果物ではない。単体展開すると base 側と二重に数えることになる
  // ため対象外にする (実測: medical_overlay を単体展開すると未生成が 22 本二重計上された)。
  if (typeof kit.overlay_of === 'string' && kit.overlay_of.length > 0) continue;
  if (!Array.isArray(kit.routes) || kit.routes.length === 0) continue;
  const target = join(FIXTURE_SETUP.work, 'out', id);
  kitLib.scaffoldKit(id, target);
  const merged = kitLib.loadKitWithOverlay(id);
  SCAFFOLDS.set(id, {
    target,
    files: new Set(walk(target)),
    plan: kitLib.routePlan(merged),
    readme: readFileSync(join(target, 'README.md'), 'utf8'),
    contract: readFileSync(join(target, 'docs', 'DESIGN_CONTRACT.md'), 'utf8'),
  });
}

process.on('exit', () => rmSync(FIXTURE_SETUP.work, { recursive: true, force: true }));

/** 生成物ファイル集合に対し token (ファイル / ディレクトリ表記) が解決できるか。 */
function resolvesInScaffold(files, token) {
  const t = token.replace(/\/+$/, '');
  for (const f of files) {
    if (f === t) return true;
    if (f.startsWith(`${t}/`)) return true;              // ディレクトリ表記
    for (const s of ['.ts', '.tsx', '.js', '.mjs', '.json']) if (f === t + s) return true;
  }
  return false;
}

/** kit JSON 内の生成物側パス参照のうち、生成物に無いものを返す。 */
function unresolvedGeneratedRefs(kitId, kit, files) {
  const out = [];
  for (const [jsonPath, s] of strings(kit)) {
    if (jsonPath.startsWith('.scaffold.')) continue;
    for (const m of s.matchAll(SRC_RE)) {
      if (!resolvesInScaffold(files, m[1])) out.push({ kit: kitId, jsonPath, token: m[1] });
    }
  }
  return out;
}

/** 文書のうち「未生成の開示節より前」= お客様に提供物として示す部分。 */
function promisedSection(md) {
  return md.split(UNGENERATED_HEADING)[0];
}

/** 箇条書きから列挙されたルートを取り出す。 */
function listedRoutes(md) {
  const out = [];
  for (const line of md.split('\n')) {
    const m = /^- `(\/[^`]*)`/.exec(line.trim());
    if (m) out.push(m[1]);
  }
  return out;
}

/** 文書が約束した画面のうち、実ファイルが無いものを返す。 */
function emptyPromises(kitId, doc, sc, docLabel) {
  const out = [];
  for (const p of listedRoutes(promisedSection(doc))) {
    const e = sc.plan.find((x) => x.route.path === p);
    if (!e) { out.push(`${kitId} (${docLabel}) ${p} → 生成計画に該当が無い`); continue; }
    if (!e.generated) { out.push(`${kitId} (${docLabel}) ${p} → 生成していない画面を約束している`); continue; }
    if (!sc.files.has(e.file)) out.push(`${kitId} (${docLabel}) ${p} → ${e.file} が生成されていない`);
  }
  return out;
}

test('A-3: kit が参照する生成物側パス (src/...) が実 scaffold の生成物に実在する', () => {
  assert.ok(SCAFFOLDS.size > 0, '実 scaffold できた kit が 1 つ以上ある');
  const bad = [];
  for (const [id, sc] of SCAFFOLDS) {
    bad.push(...unresolvedGeneratedRefs(id, KITS.get(id), sc.files));
  }
  assert.equal(bad.length, 0,
    `生成物に存在しないパスを説明文が参照している (顧客提示文書へ転記される):\n${describe(bad)}`);
});

test('A-4: 文書が主要ページとして列挙した画面に実ファイルが必ず存在する', () => {
  const bad = [];
  for (const [id, sc] of SCAFFOLDS) {
    bad.push(...emptyPromises(id, sc.readme, sc, 'README.md'));
    bad.push(...emptyPromises(id, sc.contract, sc, 'docs/DESIGN_CONTRACT.md'));
  }
  assert.equal(bad.length, 0,
    `実体の無い画面をお客様へ約束している:\n${bad.map((b) => `  ${b}`).join('\n')}`);
});

test('A-5: 未生成の宣言ルートは全件が理由付きで開示され、本数が基準を超えて増えていない', () => {
  const notDisclosed = [];
  let ungenerated = 0;
  for (const [id, sc] of SCAFFOLDS) {
    const section = sc.readme.split(UNGENERATED_HEADING)[1] ?? '';
    for (const e of sc.plan.filter((x) => !x.generated)) {
      ungenerated += 1;
      if (!section.includes(`\`${e.route.path}\``)) {
        notDisclosed.push(`${id} ${e.route.path} → 開示節に載っていない`);
      } else if (!e.reason || e.reason.length === 0) {
        notDisclosed.push(`${id} ${e.route.path} → 生成しない理由が空`);
      }
    }
  }
  assert.equal(notDisclosed.length, 0,
    '生成していない宣言ルートは、README の開示節に理由付きで必ず載せる'
    + ` (「開示で閉じる」方式が成立していない箇所):\n${notDisclosed.map((b) => `  ${b}`).join('\n')}`);

  assert.ok(existsSync(UNGEN_BASELINE_FILE),
    `未生成本数のラチェット基準 ${UNGEN_BASELINE_FILE} が無い (未測定を合格にしない)`);
  const { max_ungenerated: max } = JSON.parse(readFileSync(UNGEN_BASELINE_FILE, 'utf8'));
  assert.equal(typeof max, 'number', 'ラチェット基準 max_ungenerated が数値である');
  assert.ok(ungenerated <= max,
    `未生成の宣言ルートが基準より増えている (実測 ${ungenerated} 本 > 基準 ${max} 本)。`
    + ' 開示節が「実装しない宣言の置き場」になっていないか確認し、実装するか宣言を見直すこと。'
    + ` 意図した増加であれば ${UNGEN_BASELINE_FILE} の max_ungenerated を更新する。`);
});

test('B-4: [欠陥注入] 生成物に無い src/ パスを混ぜると A-3 が確かに落ちる', () => {
  const [, sc] = [...SCAFFOLDS][0];
  const probe = { description: '検体: src/lib/crypto/this-file-does-not-exist.ts を参照する' };
  const bad = unresolvedGeneratedRefs('__probe__', probe, sc.files);
  assert.equal(bad.length, 1, '注入した 1 本を検出する');
  assert.equal(bad[0].token, 'src/lib/crypto/this-file-does-not-exist.ts');
});

test('B-5: [欠陥注入] 生成物を 1 本消すと A-4 が確かに落ちる', () => {
  const [id, sc] = [...SCAFFOLDS][0];
  const victim = sc.plan.find((e) => e.generated && sc.files.has(e.file));
  assert.ok(victim, '削除できる生成済みルートが 1 本以上ある');
  const broken = { ...sc, files: new Set([...sc.files].filter((f) => f !== victim.file)) };
  const bad = emptyPromises(id, sc.readme, broken, 'README.md');
  assert.ok(bad.length >= 1, `${victim.file} を消したら A-4 が検出する`);
  assert.ok(bad.some((b) => b.includes(victim.route.path)), '消した画面が名指しで報告される');
  // 健全側 (消していない状態) では検出しないこと = 誤検知でないことの確認
  assert.equal(emptyPromises(id, sc.readme, sc, 'README.md').length, 0,
    '消していない状態では 1 件も検出しない');
});

test('B-6: [欠陥注入] 未生成ルートを開示節から取り除くと A-5 が確かに落ちる', () => {
  const entry = [...SCAFFOLDS].find(([, sc]) => sc.plan.some((e) => !e.generated));
  assert.ok(entry, '未生成ルートを持つ kit が 1 つ以上ある (この検体が無いと本軸は無意味)');
  const [, sc] = entry;
  const target = sc.plan.find((e) => !e.generated);
  const section = sc.readme.split(UNGENERATED_HEADING)[1] ?? '';
  assert.ok(section.includes(`\`${target.route.path}\``), '健全側では開示節に載っている');
  const stripped = section.split('\n')
    .filter((l) => !l.includes(`\`${target.route.path}\``)).join('\n');
  assert.ok(!stripped.includes(`\`${target.route.path}\``),
    '開示節から取り除いた状態では未開示として検出される');
});
