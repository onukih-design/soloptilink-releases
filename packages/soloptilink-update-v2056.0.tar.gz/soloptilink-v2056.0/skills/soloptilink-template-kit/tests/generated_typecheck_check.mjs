#!/usr/bin/env node
/**
 * soloptilink-template-kit / 生成物の型検査ゲート (2026-08-06 新設 / T-312)
 *
 * ## なぜ必要か (実測で確認した不具合)
 * 既存の route_generation_check の A-3 は **TypeScript の構文解析だけ**を見ており、
 * 型は 1 件も検査していなかった。そのため次の破綻が 79/79 PASS のまま素通りしていた:
 *   - 資源名からモデル名を推測していた camelOf() が `prisma.activitie` /
 *     `prisma.propertie` / `prisma.dispensing_record` のような **存在しない delegate**
 *     を生成物へ埋めていた (実測の解決成功率 132 件中 59 件 = 45%)
 *   - CreateSchema が {code, name} 固定で、全 114 モデル中 111 件 (97%) が持つ
 *     それ以外の必須項目を渡さないため `prisma.create()` が型でも実行時でも通らない
 *   - kit 定義の説明文に含まれる `{draft, finalized, exported}` のような波括弧が
 *     JSX へ素通しされ、**存在しない変数を参照する画面**になっていた
 *   - 主キー / createdAt に既定値の宣言が無い 44 モデルで create() が成立しない
 * いずれも「緑のまま、お客様の手元でビルドが落ちる」形の欠陥である。
 *
 * ## このゲートが測るもの (すべて実 scaffold + 実 prisma generate の結果が出典)
 *   T-1: 各 kit の生成物に対し `prisma generate` を実走し、その出力型を正典として
 *        `tsc --noEmit` が 0 件で通る
 *   B-*: 欠陥側 — 生成物へ「存在しない delegate」「必須項目の欠落」「未エスケープの
 *        波括弧」を仕込むと、このゲートが確かに落ちる (飾りの検査でないことの実証)
 *   C-1: kill-switch TEMPLATE_KIT_PRISMA_WIRING=off の旧挙動でも型が通る
 *
 * ## 測っていないもの (誤解を防ぐため明記する)
 *   next / react / clsx / class-variance-authority は型定義を同梱していない環境でも
 *   走らせるため、**最小の型宣言 (シム) で置き換えて**検査している。したがって
 *   「Next.js の API を正しく使っているか」までは保証しない。このゲートが保証するのは
 *   **Prisma と zod を含むデータ層の型が生成物の中で辻褄が合っていること**である。
 *   Prisma Client の型は毎回 `prisma generate` で作り直した実物、zod も実物を使う。
 *
 * 実行: node tests/generated_typecheck_check.mjs
 * 未測定を合格として記録しない (道具が揃わなければ exit 2 で「未測定」を返す)
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  readFileSync, writeFileSync, readdirSync, existsSync, mkdirSync, rmSync, symlinkSync,
} from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { createRequire } from 'node:module';
import { execFileSync } from 'node:child_process';
import { tmpdir, homedir } from 'node:os';

const HERE = dirname(fileURLToPath(import.meta.url));
const ROOT = resolve(HERE, '..');
const KITS_DIR = join(ROOT, 'kits');
const WORK = join(tmpdir(), `tk-typecheck-gate-${process.pid}`);
const SOLOPTILINK_HOME = process.env.SOLOPTILINK_HOME ?? join(homedir(), '.soloptilink');
/** 型検査だけに使う依存の置き場 (生成物にも配布物にも入れない) */
const GATE_DEPS = join(SOLOPTILINK_HOME, '.gate-deps', 'typecheck');

// 本体の kits/ を測る (ミラーを測って「直したつもり」にならないため)
process.env.SOLOPTILINK_TEMPLATE_KIT_DIR = KITS_DIR;

const require_ = createRequire(join(ROOT, 'package.json'));

function unmeasured(reasonJa) {
  console.error(`UNMEASURED: ${reasonJa}`);
  console.error('このゲートは未測定を合格として記録しません。道具を用意してから再実行してください。');
  process.exit(2);
}

// ---------------------------------------------------------------------------
// 道具の解決 (typescript / prisma CLI / @prisma/client / zod)
// ---------------------------------------------------------------------------

function firstExisting(paths) {
  for (const p of paths) if (existsSync(p)) return p;
  return null;
}

function loadTypeScript() {
  for (const c of ['typescript', '/opt/homebrew/lib/node_modules/typescript',
    '/usr/local/lib/node_modules/typescript']) {
    try { return require_(c); } catch { /* 次の候補 */ }
  }
  return null;
}

const ts = loadTypeScript();
if (!ts) unmeasured('typescript が使えないため、生成物を展開することも型検査することもできませんでした。');

const TSC_BIN = firstExisting([
  join(SOLOPTILINK_HOME, 'node_modules', 'typescript', 'bin', 'tsc'),
  join(ROOT, 'node_modules', 'typescript', 'bin', 'tsc'),
  '/opt/homebrew/lib/node_modules/typescript/bin/tsc',
  '/usr/local/lib/node_modules/typescript/bin/tsc',
]);
if (!TSC_BIN) unmeasured('tsc の実体が見つからないため、生成物の型検査ができませんでした。');

const PRISMA_BIN = firstExisting([
  join(SOLOPTILINK_HOME, 'node_modules', '.bin', 'prisma'),
  join(ROOT, 'node_modules', '.bin', 'prisma'),
]);
const PRISMA_CLIENT_DIR = firstExisting([
  join(SOLOPTILINK_HOME, 'node_modules', '@prisma', 'client'),
  join(ROOT, 'node_modules', '@prisma', 'client'),
]);
if (!PRISMA_BIN || !PRISMA_CLIENT_DIR) {
  unmeasured('prisma CLI / @prisma/client が見つからないため、生成物の型の正典 (Prisma Client の型) を作れませんでした。');
}

const TYPES_DIR = firstExisting([
  join(SOLOPTILINK_HOME, 'node_modules', '@types'),
  join(ROOT, 'node_modules', '@types'),
]);

/** zod の実体。無ければキャッシュ優先で 1 度だけ取り寄せる (取れなければ未測定)。 */
function resolveZodDir() {
  const found = firstExisting([
    join(ROOT, 'node_modules', 'zod'),
    join(SOLOPTILINK_HOME, 'node_modules', 'zod'),
    join(GATE_DEPS, 'node_modules', 'zod'),
  ]);
  if (found) return found;
  try {
    mkdirSync(GATE_DEPS, { recursive: true });
    const pkg = join(GATE_DEPS, 'package.json');
    if (!existsSync(pkg)) {
      writeFileSync(pkg, JSON.stringify({ name: 'soloptilink-gate-deps', private: true, version: '0.0.0' }), 'utf8');
    }
    execFileSync('npm', ['install', '--prefer-offline', '--no-audit', '--no-fund', '--loglevel=error', 'zod@^3.23.0'],
      { cwd: GATE_DEPS, stdio: 'ignore', timeout: 180_000 });
  } catch { /* 取れなければ下で未測定にする */ }
  return firstExisting([join(GATE_DEPS, 'node_modules', 'zod')]);
}

const ZOD_DIR = resolveZodDir();
if (!ZOD_DIR) {
  unmeasured('zod が用意できないため、入力スキーマの型を実物で検査できませんでした (生成物は zod ^3.23 を使います)。');
}

// ---------------------------------------------------------------------------
// 生成物の展開
// ---------------------------------------------------------------------------

function transpileLib(outDir) {
  mkdirSync(outDir, { recursive: true });
  for (const f of ['kit_loader.ts', 'scaffolder.ts', 'kit_overlay_resolver.ts', 'index.ts']) {
    const src = readFileSync(join(ROOT, 'lib', f), 'utf8');
    const js = ts.transpileModule(src, {
      compilerOptions: {
        module: ts.ModuleKind.ESNext,
        target: ts.ScriptTarget.ES2022,
        isolatedModules: true,
      },
      fileName: f,
    }).outputText.replace(
      /from '\.\/(kit_loader|scaffolder|kit_overlay_resolver)'/g, "from './$1.mjs'");
    writeFileSync(join(outDir, f.replace(/\.ts$/, '.mjs')), js, 'utf8');
  }
  return join(outDir, 'index.mjs');
}

rmSync(WORK, { recursive: true, force: true });
mkdirSync(WORK, { recursive: true });
const kitLib = await import(pathToFileURL(transpileLib(join(WORK, 'lib'))).href);

const KIT_IDS = readdirSync(KITS_DIR)
  .filter((f) => f.endsWith('.json'))
  .map((f) => f.replace(/\.json$/, ''))
  .sort();

// ---------------------------------------------------------------------------
// 型検査ハーネス
//
// next / react などは型定義を同梱していない環境でも走らせるため最小のシムで置き換える。
// Prisma Client の型は毎回 prisma generate で作り直した実物、zod も実物を使う
// (ここを偽物にすると、このゲートは「型を測ったふり」になる)。
// ---------------------------------------------------------------------------

const FRAMEWORK_SHIMS = `// 型検査ゲート専用の最小型宣言 (生成物には同梱しない)
declare namespace JSX {
  interface Element {}
  interface ElementClass { render: unknown }
  interface ElementAttributesProperty { props: {} }
  interface ElementChildrenAttribute { children: {} }
  interface IntrinsicAttributes { key?: string | number }
  interface IntrinsicElements { [elemName: string]: Record<string, unknown> }
}
declare namespace React {
  type ReactNode = unknown;
  interface FormEvent<T = Element> { preventDefault(): void; currentTarget: T }
  interface ChangeEvent<T = Element> { target: T; currentTarget: T }
  interface MouseEvent<T = Element> { preventDefault(): void; currentTarget: T }
}
declare module 'react' {
  export type ReactNode = unknown;
  export type FormEvent<T = Element> = React.FormEvent<T>;
  export type ChangeEvent<T = Element> = React.ChangeEvent<T>;
  export function useState<S>(initial: S | (() => S)): [S, (value: S | ((prev: S) => S)) => void];
  export function useEffect(effect: () => void | (() => void), deps?: readonly unknown[]): void;
  export function useMemo<T>(factory: () => T, deps?: readonly unknown[]): T;
  export const Fragment: unknown;
  export type ComponentProps<T> = Record<string, unknown>;
  export type ButtonHTMLAttributes<T> = Record<string, unknown>;
  export type InputHTMLAttributes<T> = Record<string, unknown>;
  export type LabelHTMLAttributes<T> = Record<string, unknown>;
  export type HTMLAttributes<T> = Record<string, unknown>;
  export type TableHTMLAttributes<T> = Record<string, unknown>;
  export type ThHTMLAttributes<T> = Record<string, unknown>;
  export type TdHTMLAttributes<T> = Record<string, unknown>;
  export type ForwardedRef<T> = unknown;
  export interface ForwardRefComponent<P> {
    (props: P): JSX.Element | null;
    displayName?: string;
  }
  export function forwardRef<T, P>(render: (props: P, ref: unknown) => JSX.Element | null): ForwardRefComponent<P>;
  const React: Record<string, unknown>;
  export default React;
}
declare module 'next' { export type Metadata = Record<string, unknown>; }
declare module 'next/link' {
  const Link: (props: { href: string; className?: string; children?: unknown }) => JSX.Element;
  export default Link;
}
declare module 'next/navigation' {
  export function useRouter(): { push(href: string): void; replace(href: string): void; refresh(): void; back(): void };
  export function useParams<T = Record<string, string>>(): T;
  export function useSearchParams(): { get(k: string): string | null };
  export function notFound(): never;
}
declare module 'next/server' {
  export class NextResponse extends Response {
    static json(body: unknown, init?: { status?: number; headers?: Record<string, string> }): NextResponse;
  }
  export type NextRequest = Request;
}
declare module 'clsx' {
  export type ClassValue = unknown;
  export function clsx(...inputs: unknown[]): string;
  export default clsx;
}
declare module 'class-variance-authority' {
  export type VariantProps<T> = Record<string, unknown>;
  export function cva(base: string, config?: unknown): (props?: Record<string, unknown>) => string;
}
`;

function linkInto(target, name, source) {
  const dest = join(target, name);
  if (existsSync(dest)) return;
  mkdirSync(dirname(dest), { recursive: true });
  symlinkSync(source, dest);
}

/** 生成物 1 本を「prisma generate 済み + 型検査できる」状態に整える。 */
function prepareTypecheck(target) {
  const nm = join(target, 'node_modules');
  mkdirSync(join(nm, '@prisma'), { recursive: true });
  // prisma CLI が「依存が入っていない」と判断して npm install を始めないようにする
  linkInto(target, join('node_modules', '@prisma', 'client'), PRISMA_CLIENT_DIR);
  linkInto(target, join('node_modules', 'prisma'), join(SOLOPTILINK_HOME, 'node_modules', 'prisma'));
  linkInto(target, join('node_modules', 'zod'), ZOD_DIR);
  if (TYPES_DIR) linkInto(target, join('node_modules', '@types'), TYPES_DIR);

  // Prisma Client の型を作る。生成物の schema.prisma は書き換えず、出力先だけ変えた複製を使う
  const schema = readFileSync(join(target, 'prisma', 'schema.prisma'), 'utf8');
  const patched = schema.replace(
    /generator client \{\n  provider = "prisma-client-js"\n\}/,
    'generator client {\n  provider = "prisma-client-js"\n  output   = "../gen/client"\n}',
  );
  assert.notEqual(patched, schema, '生成物の prisma スキーマに generator ブロックが見つかりません');
  const schemaPath = join(target, 'prisma', 'schema.typecheck.prisma');
  writeFileSync(schemaPath, patched, 'utf8');
  execFileSync(PRISMA_BIN, ['generate', '--schema', schemaPath], {
    cwd: target, stdio: 'ignore', timeout: 300_000,
  });

  writeFileSync(join(target, 'framework-shims.d.ts'), FRAMEWORK_SHIMS, 'utf8');
  writeFileSync(join(target, 'tsconfig.typecheck.json'), `${JSON.stringify({
    extends: './tsconfig.json',
    compilerOptions: {
      noEmit: true,
      incremental: false,
      plugins: [],
      typeRoots: ['./node_modules/@types'],
      types: ['node'],
      paths: { '@/*': ['./src/*'], '@prisma/client': ['./gen/client/index.d.ts'] },
    },
    include: ['framework-shims.d.ts', 'src/**/*.ts', 'src/**/*.tsx', 'prisma/**/*.ts'],
    exclude: ['node_modules', 'gen'],
  }, null, 2)}\n`, 'utf8');
}

/** tsc --noEmit を実走し、型エラーの行を返す (空配列なら合格)。 */
function typeErrorsOf(target) {
  try {
    execFileSync(process.execPath, [TSC_BIN, '-p', 'tsconfig.typecheck.json'], {
      cwd: target, encoding: 'utf8', timeout: 600_000, stdio: ['ignore', 'pipe', 'pipe'],
    });
    return [];
  } catch (e) {
    const out = `${e.stdout ?? ''}${e.stderr ?? ''}`;
    return out.split('\n').filter((l) => /error TS\d+:/.test(l));
  }
}

/** kit を展開して型検査できる状態にし、{ target } を返す。 */
function scaffoldForTypecheck(kitId, label = kitId) {
  const target = join(WORK, 'out', label);
  rmSync(target, { recursive: true, force: true });
  kitLib.scaffoldKit(kitId, target);
  prepareTypecheck(target);
  return target;
}

// ===========================================================================
// 健全側
// ===========================================================================

test('T-0: kits/ に検体が 10 件以上ある (検体ゼロで空回りしない)', () => {
  assert.ok(KIT_IDS.length >= 10, `kit 検体が少なすぎる: ${KIT_IDS.length}`);
});

for (const kitId of KIT_IDS) {
  test(`T-1: ${kitId} — prisma generate 後の生成物が tsc --noEmit を通る`, () => {
    const target = scaffoldForTypecheck(kitId);
    const errors = typeErrorsOf(target);
    assert.deepEqual(errors, [],
      `${kitId}: 生成物に型エラーがある (お客様の手元でビルドが落ちる)\n${errors.slice(0, 20).join('\n')}`);
  });
}

// ===========================================================================
// 欠陥側 (この検査が「常に合格する検査」でないことの実証)
// ===========================================================================

test('B-1: 存在しない prisma delegate を仕込むと型検査が確かに落ちる', () => {
  const target = scaffoldForTypecheck('construction', 'construction_bad_delegate');
  const victim = join('src', 'app', 'api', 'projects', 'route.ts');
  const src = readFileSync(join(target, victim), 'utf8');
  assert.match(src, /prisma\.project\./, '検体に prisma 呼び出しが無い');
  // 2026-08-06 以前の camelOf() が実際に作っていた形 (複数形の取りこぼし)
  writeFileSync(join(target, victim), src.replace(/prisma\.project\./g, 'prisma.projectt.'), 'utf8');
  const errors = typeErrorsOf(target);
  assert.ok(errors.some((l) => l.includes(victim)),
    `存在しない delegate を検出できていない (検出 ${errors.length} 件)`);
});

test('B-2: create() から必須項目を 1 つ落とすと型検査が確かに落ちる', () => {
  const target = scaffoldForTypecheck('construction', 'construction_missing_field');
  const victim = join('src', 'app', 'api', 'projects', 'route.ts');
  const src = readFileSync(join(target, victim), 'utf8');
  assert.match(src, /siteSupervisor: parsed\.data\.siteSupervisor,/, '検体に必須項目が無い');
  writeFileSync(join(target, victim), src.replace(/\s*siteSupervisor: parsed\.data\.siteSupervisor,/, ''), 'utf8');
  const errors = typeErrorsOf(target);
  assert.ok(errors.some((l) => l.includes(victim)),
    `必須項目の欠落を検出できていない (検出 ${errors.length} 件)`);
});

test('B-3: 説明文の波括弧を JSX へ素通しすると型検査が確かに落ちる', () => {
  const target = scaffoldForTypecheck('construction', 'construction_raw_braces');
  const victim = join('src', 'app', '(domain)', 'projects', 'page.tsx');
  const src = readFileSync(join(target, victim), 'utf8');
  // kit 定義の説明文に実在する形 (medical_overlay / dispensing_pharmacy で実測)
  writeFileSync(join(target, victim),
    src.replace('<h2 className="text-xl font-bold">', '<h2 className="text-xl font-bold">{draft, finalized}'), 'utf8');
  const errors = typeErrorsOf(target);
  assert.ok(errors.some((l) => l.includes('page.tsx')),
    `未エスケープの波括弧を検出できていない (検出 ${errors.length} 件)`);
});

test('B-4: 正しい生成物は誤検知しない (健全側の対照)', () => {
  const target = scaffoldForTypecheck('construction', 'construction_control');
  assert.deepEqual(typeErrorsOf(target), [], '正しい生成物を誤って欠陥と判定している');
});

// ===========================================================================
// kill-switch
// ===========================================================================

test('C-1: TEMPLATE_KIT_PRISMA_WIRING=off の旧挙動でも型が通る', () => {
  const saved = process.env.TEMPLATE_KIT_PRISMA_WIRING;
  process.env.TEMPLATE_KIT_PRISMA_WIRING = 'off';
  try {
    const target = scaffoldForTypecheck('construction', 'construction_wiring_off');
    const errors = typeErrorsOf(target);
    assert.deepEqual(errors, [],
      `kill-switch off の生成物に型エラーがある\n${errors.slice(0, 10).join('\n')}`);
    // off のときは prisma を呼ばない (「保存したふり」も「取得したふり」もしない)
    const api = readFileSync(join(target, 'src', 'app', 'api', 'projects', 'route.ts'), 'utf8');
    assert.doesNotMatch(api, /await prisma\./, 'off にしても prisma を呼んでいる');
    assert.match(api, /501/, 'off のとき書き込みが 501 になっていない');
  } finally {
    if (saved === undefined) delete process.env.TEMPLATE_KIT_PRISMA_WIRING;
    else process.env.TEMPLATE_KIT_PRISMA_WIRING = saved;
  }
});

process.on('exit', () => {
  rmSync(WORK, { recursive: true, force: true });
});
