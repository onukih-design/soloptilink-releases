#!/usr/bin/env node
// @ts-check
/**
 * Phase 14 - パターン蒸留スクリプト
 *
 *   node scripts/distill_patterns.mjs [--input <jsonl>] [--top 20]
 *
 * セッションログ (jsonl) を読み込み、上位パターンを集計して
 * stdout に Markdown で出力する。lib/japan/pattern_library.ts と
 * 同じ蒸留ロジックを呼び出すが、ピュア Node 環境で動くよう自己完結化。
 */

import { readFileSync, existsSync } from 'node:fs';
import { resolve } from 'node:path';

const args = process.argv.slice(2);
function getArg(name, def) {
  const i = args.indexOf(name);
  return i >= 0 ? args[i + 1] : def;
}

const inputPath = resolve(getArg('--input', `${process.env.HOME}/.soloptilink/learning/sessions.jsonl`));
const topN = parseInt(getArg('--top', '20'), 10);

if (!existsSync(inputPath)) {
  console.log(`# Distill 結果 (Phase 14)`);
  console.log(``);
  console.log(`セッションログが見つかりません: ${inputPath}`);
  console.log(``);
  console.log(`SoloptiLinkAI が稼働すると、~/.soloptilink/learning/sessions.jsonl に`);
  console.log(`記録が蓄積されます。蓄積後にもう一度本スクリプトを実行してください。`);
  process.exit(0);
}

const lines = readFileSync(inputPath, 'utf8').split('\n').filter((l) => l.trim().length > 0);
const stats = new Map();
let totalSessions = 0;
for (const line of lines) {
  let log;
  try {
    log = JSON.parse(line);
  } catch {
    continue;
  }
  totalSessions += 1;
  const patterns = Array.isArray(log.patternsUsed) ? log.patternsUsed : [];
  for (const pid of patterns) {
    const e = stats.get(pid) ?? { used: 0, success: 0 };
    e.used += 1;
    if (log.outcome === 'success') e.success += 1;
    stats.set(pid, e);
  }
}

const sorted = Array.from(stats.entries())
  .map(([patternId, s]) => ({
    patternId,
    usageCount: s.used,
    successRate: s.used === 0 ? 0 : Math.round((s.success / s.used) * 1000) / 10,
  }))
  .sort((a, b) => b.successRate - a.successRate || b.usageCount - a.usageCount)
  .slice(0, topN);

console.log(`# Distill 結果 (Phase 14)`);
console.log(``);
console.log(`- 入力: \`${inputPath}\``);
console.log(`- 総セッション数: ${totalSessions}`);
console.log(`- 上位パターン: ${sorted.length} 件`);
console.log(``);
console.log(`| Rank | Pattern ID | 使用回数 | 成功率 |`);
console.log(`| ---- | ---------- | -------- | ------ |`);
sorted.forEach((s, i) => {
  console.log(`| ${i + 1} | ${s.patternId} | ${s.usageCount} | ${s.successRate}% |`);
});
