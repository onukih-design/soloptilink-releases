#!/usr/bin/env bash
# -----------------------------------------------------------------------------
# jp_inject.sh — /soloptilink-japan Phase 8 一括注入ツール
#
# 役割:
#   SoloptiLinkAI で生成された Next.js/Node プロジェクトへ、
#   本スキルの資産 (lib/japan + components/japan + templates/japan + quality + tests)
#   を一括コピーし、package.json に品質スクリプトを注入する。
#
# 使い方:
#   bash scripts/jp_inject.sh <target_project_dir> [--minimal|--full]
#
#   --minimal : lib/japan + tests + quality のみ (最小運用セット / デフォルト)
#   --full    : components/japan + templates/japan + examples も一緒に注入
#
# 注入内容:
#   <target>/src/lib/japan/*         ← lib/japan/*.ts をコピー
#   <target>/scripts/jp_quality.sh   ← quality/jp_quality_fortress.sh を配置
#   <target>/tests/japan/*.mjs       ← tests/*.mjs をコピー
#   <target>/package.json の scripts に以下を追加:
#     "jp:quality"    : "bash scripts/jp_quality.sh ."
#     "jp:self-check" : "node tests/japan/phase6_self_check.mjs"
#
# 冪等性:
#   同じコマンドを複数回実行しても既存コードを破壊しない (ファイル上書きのみ)。
#   package.json scripts は既存キーがあれば上書きし、なければ追記する。
#
# 非破壊:
#   .env / prisma / src/app 等のプロジェクト固有ファイルには一切触れない。
#   注入の取消は rm -rf <target>/src/lib/japan と scripts の手動削除で行う。
# -----------------------------------------------------------------------------
set -euo pipefail

# -----------------------------------------------------------------------------
# 引数解析
# -----------------------------------------------------------------------------
TARGET="${1:-}"
MODE="${2:---minimal}"

if [ -z "$TARGET" ]; then
  echo '{"ok":false,"error":"target_project_dir が指定されていません"}' >&2
  echo '使い方: bash scripts/jp_inject.sh <target> [--minimal|--full]' >&2
  exit 2
fi

if [ ! -d "$TARGET" ]; then
  echo "{\"ok\":false,\"error\":\"対象ディレクトリが存在しない: $TARGET\"}" >&2
  exit 2
fi

TARGET="$(cd "$TARGET" && pwd)"

# スキル自身のパスを自動検出 (このスクリプトの親ディレクトリ = skill root)
SKILL_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [ ! -d "$SKILL_ROOT/lib/japan" ]; then
  echo "{\"ok\":false,\"error\":\"スキルルート不正: $SKILL_ROOT\"}" >&2
  exit 2
fi

# -----------------------------------------------------------------------------
# 事前検証: Node.js プロジェクトか
# -----------------------------------------------------------------------------
if [ ! -f "$TARGET/package.json" ]; then
  echo "{\"ok\":false,\"error\":\"package.json が見つからない (Node.js プロジェクトで実行してください): $TARGET\"}" >&2
  exit 2
fi

# -----------------------------------------------------------------------------
# ファイルコピー (冪等)
# -----------------------------------------------------------------------------
COPIED_COUNT=0

copy_tree() {
  local src="$1"
  local dst="$2"
  if [ ! -d "$src" ]; then return; fi
  mkdir -p "$dst"
  # ファイルごとにコピーして diff を減らす
  while IFS= read -r -d '' f; do
    local rel="${f#$src/}"
    local dst_file="$dst/$rel"
    mkdir -p "$(dirname "$dst_file")"
    cp "$f" "$dst_file"
    COPIED_COUNT=$((COPIED_COUNT + 1))
  done < <(find "$src" -type f -print0)
}

# Minimal: lib/japan + tests + quality
copy_tree "$SKILL_ROOT/lib/japan"       "$TARGET/src/lib/japan"
copy_tree "$SKILL_ROOT/tests"           "$TARGET/tests/japan"
mkdir -p "$TARGET/scripts"
cp "$SKILL_ROOT/quality/jp_quality_fortress.sh" "$TARGET/scripts/jp_quality.sh"
chmod +x "$TARGET/scripts/jp_quality.sh"
COPIED_COUNT=$((COPIED_COUNT + 1))

# Full: components + templates + examples も注入
if [ "$MODE" = "--full" ]; then
  copy_tree "$SKILL_ROOT/components/japan" "$TARGET/src/components/japan"
  copy_tree "$SKILL_ROOT/templates/japan"  "$TARGET/src/templates/japan"
  copy_tree "$SKILL_ROOT/examples"         "$TARGET/examples/japan"
fi

# -----------------------------------------------------------------------------
# package.json の scripts 注入 (node があれば JSON 操作、なければ sed フォールバック)
# -----------------------------------------------------------------------------
SCRIPTS_OK="false"
if command -v node >/dev/null 2>&1; then
  node -e "
    const fs = require('fs');
    const path = '$TARGET/package.json';
    const pkg = JSON.parse(fs.readFileSync(path, 'utf8'));
    pkg.scripts = pkg.scripts || {};
    pkg.scripts['jp:quality'] = 'bash scripts/jp_quality.sh .';
    pkg.scripts['jp:self-check'] = 'node tests/japan/phase6_self_check.mjs';
    pkg.scripts['jp:runtime-check'] = 'node tests/japan/phase7_bug_prevention_runtime.mjs';
    pkg.scripts['jp:verify'] = 'npm run jp:self-check && npm run jp:runtime-check && npm run jp:quality';
    fs.writeFileSync(path, JSON.stringify(pkg, null, 2) + '\n');
  " && SCRIPTS_OK="true"
fi

# -----------------------------------------------------------------------------
# 結果 JSON
# -----------------------------------------------------------------------------
cat <<EOF
{
  "ok": true,
  "mode": "$MODE",
  "skill_root": "$SKILL_ROOT",
  "target": "$TARGET",
  "files_copied": $COPIED_COUNT,
  "scripts_injected": $SCRIPTS_OK,
  "next_steps": [
    "cd $TARGET && npm run jp:self-check  # Phase 6+7 自己検証 (6 tests)",
    "cd $TARGET && npm run jp:quality     # JP-Quality Fortress v4 採点",
    "cd $TARGET && npm run jp:verify      # 上記2つを連続実行"
  ]
}
EOF
