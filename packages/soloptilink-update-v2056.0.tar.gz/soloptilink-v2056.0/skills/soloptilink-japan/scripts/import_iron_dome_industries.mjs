#!/usr/bin/env node
// SoloptiLinkAI v2028.0 — iron-dome industries.ts → DBL Iron-Dome Seed Importer
//
// iron-dome の 44業種探索キー (industries.ts) を DBL に流し込むためのシード生成器。
// 既存 domains/<key>.json を上書きせず、_iron_dome_seed/<key>.seed.json に書き出す。
// 後で運用者が手動で domains/<key>.json にマージする (差分を見ながら確認するため)。
//
// Usage:
//   node ~/.claude/skills/soloptilink-japan/scripts/import_iron_dome_industries.mjs
//   node ~/.claude/skills/soloptilink-japan/scripts/import_iron_dome_industries.mjs --dry-run
//   node ~/.claude/skills/soloptilink-japan/scripts/import_iron_dome_industries.mjs --merge   # 直接マージ (未配線フィールドのみ追加)

import fs from "node:fs";
import path from "node:path";
import os from "node:os";

const HOME = os.homedir();
const IRON_DOME_TS = path.join(HOME, ".soloptilink/.iron-dome-rpb/_common/industries.ts");
const SEED_DIR = path.join(HOME, ".claude/skills/soloptilink-japan/_iron_dome_seed");
const DOMAINS_DIR = path.join(HOME, ".claude/skills/soloptilink-japan/domains");

const args = process.argv.slice(2);
const DRY = args.includes("--dry-run");
const MERGE = args.includes("--merge");

if (!fs.existsSync(IRON_DOME_TS)) {
  console.error(`[import-iron-dome] ERROR: ${IRON_DOME_TS} が存在しません`);
  console.error("  まず ~/.soloptilink/.iron-dome-rpb/_common/industries.ts を配置してください");
  process.exit(1);
}

if (!DRY) {
  fs.mkdirSync(SEED_DIR, { recursive: true });
}

// industries.ts を簡易パース (JSON ではなく TS なので正規表現抽出)
const tsContent = fs.readFileSync(IRON_DOME_TS, "utf8");

// 各エントリ行を抽出
//   { key: "construction", ja: "建設・建築", en: "Construction", phaseId: 1, solaiLib: "architecture.ts", gdeltQuery: "(...)", jpKeywords: [...] },
const ENTRY_REGEX = /\{\s*key:\s*"([^"]+)"\s*,\s*ja:\s*"([^"]+)"\s*,\s*en:\s*"([^"]+)"\s*,\s*phaseId:\s*(\d+)\s*(?:,\s*solaiLib:\s*"([^"]+)")?\s*,\s*gdeltQuery:\s*"([^"]+)"\s*,\s*jpKeywords:\s*\[([^\]]+)\]\s*\}/g;

const seeded = [];
const errors = [];
let match;

while ((match = ENTRY_REGEX.exec(tsContent)) !== null) {
  const [, key, ja, en, phaseIdStr, solaiLib, gdeltQuery, kwRaw] = match;
  const phase_id = Number(phaseIdStr);
  const jp_keywords = kwRaw
    .split(",")
    .map((s) => s.trim().replace(/^"|"$/g, ""))
    .filter(Boolean);

  const seed = {
    industry: key,
    industry_ja: ja,
    industry_en: en,
    phase_id,
    solai_lib: solaiLib || null,
    gdelt_query: gdeltQuery,
    jp_keywords,
    _seed_source: "iron-dome industries.ts",
    _seed_generated_at: new Date().toISOString(),
    _seed_note: "本ファイルは _iron_dome_seed/ に配置されたシードです。domains/<key>.json への merge は --merge オプションか手動で行ってください"
  };

  const seedPath = path.join(SEED_DIR, `${key}.seed.json`);
  if (DRY) {
    console.log(`[dry-run] would write ${seedPath}`);
  } else {
    fs.writeFileSync(seedPath, JSON.stringify(seed, null, 2) + "\n", "utf8");
  }

  seeded.push({ key, ja, phase_id, has_solai_lib: !!solaiLib, kw_count: jp_keywords.length });

  if (MERGE) {
    const targetPath = path.join(DOMAINS_DIR, `${key}.json`);
    if (fs.existsSync(targetPath)) {
      try {
        const existing = JSON.parse(fs.readFileSync(targetPath, "utf8"));
        let dirty = false;

        // 未配線フィールドのみ追加 (既存値は上書きしない)
        const ironDomeFields = {
          phase_id,
          solai_lib: solaiLib || existing.solai_lib,
          gdelt_query: gdeltQuery,
          jp_keywords
        };
        for (const [k, v] of Object.entries(ironDomeFields)) {
          if (existing[k] === undefined || existing[k] === null) {
            existing[k] = v;
            dirty = true;
          }
        }

        if (dirty) {
          fs.writeFileSync(targetPath, JSON.stringify(existing, null, 2) + "\n", "utf8");
          console.log(`[merge] updated ${key}.json with iron-dome探索キー`);
        }
      } catch (e) {
        errors.push({ key, error: String(e) });
      }
    }
  }
}

// レポート出力
const report = {
  generated_at: new Date().toISOString(),
  source: IRON_DOME_TS,
  seeded_count: seeded.length,
  with_solai_lib: seeded.filter((s) => s.has_solai_lib).length,
  without_solai_lib: seeded.filter((s) => !s.has_solai_lib).length,
  industries: seeded,
  errors
};

console.log("\n=== Iron-Dome Industries Import Report ===");
console.log(`Total industries seeded: ${report.seeded_count}`);
console.log(`With solai_lib:        ${report.with_solai_lib}`);
console.log(`Without solai_lib:     ${report.without_solai_lib}`);

if (errors.length > 0) {
  console.log("\n=== Errors ===");
  console.log(JSON.stringify(errors, null, 2));
}

if (!DRY) {
  const reportPath = path.join(SEED_DIR, "_import_report.json");
  fs.writeFileSync(reportPath, JSON.stringify(report, null, 2) + "\n", "utf8");
  console.log(`\nReport: ${reportPath}`);
}

process.exit(errors.length > 0 ? 1 : 0);
