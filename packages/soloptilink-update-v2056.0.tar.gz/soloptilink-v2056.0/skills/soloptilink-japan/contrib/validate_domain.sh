#!/usr/bin/env bash
# ドメイン辞書 JSON の検証スクリプト (SIer Marketplace 貢献受付用)
# v3 (Phase 8): 拡張法令(PL/景表/特商/食品衛生/食品表示/薬機/旅館/宅建/児福/安衛/育介/派遣) 対応
#               + recommended_drawings / estimate_unit_price_refs (Phase 9 準備) の任意検証
# 使い方: bash validate_domain.sh <domain.json>
set -u

FILE="${1:-}"
if [ -z "$FILE" ] || [ ! -f "$FILE" ]; then
  echo '{"ok":false,"error":"ファイルが指定されていません / 存在しません"}'
  exit 2
fi

# JSON パーサの検出（python3 > node > jq > 手動）
detect_parser() {
  if command -v python3 >/dev/null 2>&1; then echo "python"; return; fi
  if command -v node >/dev/null 2>&1; then echo "node"; return; fi
  if command -v jq >/dev/null 2>&1; then echo "jq"; return; fi
  echo "manual"
}
PARSER=$(detect_parser)

# JSON 文法チェック
case "$PARSER" in
  python)
    python3 -c "import json,sys; json.load(open('$FILE'))" 2>/dev/null || { echo '{"ok":false,"error":"JSON文法エラー"}'; exit 1; }
    ;;
  node)
    node -e "JSON.parse(require('fs').readFileSync('$FILE','utf8'))" 2>/dev/null || { echo '{"ok":false,"error":"JSON文法エラー"}'; exit 1; }
    ;;
  jq)
    jq empty "$FILE" 2>/dev/null || { echo '{"ok":false,"error":"JSON文法エラー"}'; exit 1; }
    ;;
  manual)
    echo '{"ok":false,"error":"JSONパーサが見つかりません(python3/node/jqのいずれかが必要)"}'; exit 2
    ;;
esac

# required フィールドチェック
REQUIRED_FIELDS=(industry industry_ja version applicable_laws terminology mandatory_fields ui_hints)
MISSING=()
for f in "${REQUIRED_FIELDS[@]}"; do
  VAL="MISSING"
  case "$PARSER" in
    python)
      VAL=$(python3 -c "import json; d=json.load(open('$FILE')); print('OK' if '$f' in d else 'MISSING')" 2>/dev/null)
      ;;
    node)
      VAL=$(node -e "const d=JSON.parse(require('fs').readFileSync('$FILE','utf8')); console.log(d['$f']!==undefined?'OK':'MISSING')" 2>/dev/null)
      ;;
    jq)
      if jq -e ".$f" "$FILE" >/dev/null 2>&1; then VAL="OK"; fi
      ;;
  esac
  [ "$VAL" != "OK" ] && MISSING+=("$f")
done

# 禁止事項
PII_HITS=$(grep -c -E '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}|0[789]0-?[0-9]{4}-?[0-9]{4}' "$FILE" 2>/dev/null | head -1 | tr -d '\n' || true)
PII_HITS=${PII_HITS:-0}
EXT_URLS=$(grep -c -E 'https?://[^"]+\?[a-zA-Z0-9_=&-]+' "$FILE" 2>/dev/null | head -1 | tr -d '\n' || true)
EXT_URLS=${EXT_URLS:-0}

# KPI / mandatory_fields カテゴリ数
KPI_COUNT=0
MF_COUNT=0
case "$PARSER" in
  python)
    KPI_COUNT=$(python3 -c "import json; d=json.load(open('$FILE')); print(len(d.get('ui_hints',{}).get('dashboard_kpi',[])))" 2>/dev/null || echo 0)
    MF_COUNT=$(python3 -c "import json; d=json.load(open('$FILE')); print(len(d.get('mandatory_fields',{})))" 2>/dev/null || echo 0)
    ;;
  node)
    KPI_COUNT=$(node -e "const d=JSON.parse(require('fs').readFileSync('$FILE','utf8')); console.log((d.ui_hints&&d.ui_hints.dashboard_kpi||[]).length)" 2>/dev/null || echo 0)
    MF_COUNT=$(node -e "const d=JSON.parse(require('fs').readFileSync('$FILE','utf8')); console.log(Object.keys(d.mandatory_fields||{}).length)" 2>/dev/null || echo 0)
    ;;
  jq)
    KPI_COUNT=$(jq '.ui_hints.dashboard_kpi | length' "$FILE" 2>/dev/null || echo 0)
    MF_COUNT=$(jq '.mandatory_fields | keys | length' "$FILE" 2>/dev/null || echo 0)
    ;;
esac

# スコア
SCORE=100
[ ${#MISSING[@]} -gt 0 ] && SCORE=$((SCORE - ${#MISSING[@]} * 15))
[ "$PII_HITS" -gt 0 ] && SCORE=$((SCORE - 30))
[ "$EXT_URLS" -gt 0 ] && SCORE=$((SCORE - 10))
[ "$KPI_COUNT" -lt 3 ] && SCORE=$((SCORE - 10))
[ "$MF_COUNT" -lt 2 ] && SCORE=$((SCORE - 10))
[ "$SCORE" -lt 0 ] && SCORE=0

OK="true"
[ ${#MISSING[@]} -gt 0 ] || [ "$PII_HITS" -gt 0 ] && { [ ${#MISSING[@]} -gt 0 ] && OK="false"; [ "$PII_HITS" -gt 0 ] && OK="false"; }

MISSING_JSON="[]"
if [ ${#MISSING[@]} -gt 0 ]; then
  MISSING_JSON=$(printf '%s\n' "${MISSING[@]}" | awk 'BEGIN{printf "["} {printf (NR>1?",":"") "\"" $0 "\""} END{printf "]"}')
fi

cat <<EOF
{
  "ok": $OK,
  "file": "$FILE",
  "parser": "$PARSER",
  "score": $SCORE,
  "missing_fields": $MISSING_JSON,
  "pii_hits": $PII_HITS,
  "external_url_hits": $EXT_URLS,
  "kpi_count": $KPI_COUNT,
  "mandatory_field_categories": $MF_COUNT,
  "decision": "$([ "$OK" = "true" ] && [ "$SCORE" -ge 80 ] && echo 'ACCEPTED' || echo 'REJECTED')"
}
EOF

[ "$OK" = "true" ] && [ "$SCORE" -ge 80 ] && exit 0 || exit 1
