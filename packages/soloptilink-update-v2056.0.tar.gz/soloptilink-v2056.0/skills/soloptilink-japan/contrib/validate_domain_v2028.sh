#!/usr/bin/env bash
# SoloptiLinkAI v2028.0 — DBL Blueprint Completeness Validator
#
# 各 domains/<key>.json が iron-dome blueprint の探索キーと密度目標を満たすかを採点する。
# v2027 互換 (既存必須フィールド) を維持しつつ、v2028 optional フィールドで Tier (Diamond/Platinum/Gold) を付与。
#
# Usage:
#   bash validate_domain_v2028.sh                         # 全 domains/*.json を採点
#   bash validate_domain_v2028.sh --industry construction # 1業種だけ採点
#   bash validate_domain_v2028.sh --strict                # blueprint < 70 で exit 1 (CI 用)
#   bash validate_domain_v2028.sh --json                  # JSON 結果のみ stdout
#
# 出力: blueprint_completeness スコア (0-100) + Tier (Diamond/Platinum/Gold/Reject)

set -euo pipefail

DOMAINS_DIR="${HOME}/.claude/skills/soloptilink-japan/domains"
TARGET_INDUSTRY=""
STRICT=0
JSON_ONLY=0

while [[ $# -gt 0 ]]; do
  case "$1" in
    --industry) TARGET_INDUSTRY="$2"; shift 2 ;;
    --strict)   STRICT=1; shift ;;
    --json)     JSON_ONLY=1; shift ;;
    *)          shift ;;
  esac
done

if ! command -v jq >/dev/null 2>&1; then
  echo "ERROR: jq is required" >&2
  exit 2
fi

# 1業種採点関数
score_one() {
  local file="$1"
  local industry; industry=$(jq -r '.industry // ""' "$file")
  local score=0
  local missing=()

  # ====== v2027 互換チェック (基礎18点) ======
  local v2027_required=(industry industry_ja version applicable_laws terminology mandatory_fields ui_hints)
  for k in "${v2027_required[@]}"; do
    if [ "$(jq -r --arg k "$k" '.[$k] | if . == null then "null" else "ok" end' "$file")" = "ok" ]; then
      score=$((score + 2))
    else
      missing+=("v2027:$k")
    fi
  done
  # ui_hints の dashboard_kpi / mobile_priority サブチェック
  if [ "$(jq -r '.ui_hints.dashboard_kpi // [] | length' "$file")" -ge 3 ]; then
    score=$((score + 3))
  else
    missing+=("ui_hints.dashboard_kpi (>=3)")
  fi
  if [ "$(jq -r '.ui_hints.mobile_priority // [] | length' "$file")" -ge 2 ]; then
    score=$((score + 1))
  else
    missing+=("ui_hints.mobile_priority (>=2)")
  fi

  # ====== v2028 Iron-Dome 探索キー (47点) ======
  if [ "$(jq -r 'has("phase_id")' "$file")" = "true" ]; then
    score=$((score + 6))
  else
    missing+=("v2028:phase_id")
  fi
  if [ "$(jq -r 'has("solai_lib")' "$file")" = "true" ]; then
    score=$((score + 4))
  else
    missing+=("v2028:solai_lib")
  fi
  if [ "$(jq -r '.gdelt_query // "" | length > 0' "$file")" = "true" ]; then
    if [ "$(jq -r '.gdelt_query // "" | test("\\(Japan AND .+\\)")' "$file")" = "true" ]; then
      score=$((score + 6))
    else
      score=$((score + 4))
      missing+=("v2028:gdelt_query (Japan AND ... 形式推奨)")
    fi
  else
    missing+=("v2028:gdelt_query")
  fi
  local kw_count; kw_count=$(jq -r '.jp_keywords // [] | length' "$file")
  if [ "$kw_count" -ge 5 ]; then
    score=$((score + 6))
  elif [ "$kw_count" -ge 3 ]; then
    score=$((score + 4))
    missing+=("v2028:jp_keywords (>=5 推奨)")
  else
    missing+=("v2028:jp_keywords (>=3 必須)")
  fi
  local grant_count; grant_count=$(jq -r '.related_grant_keywords // [] | length' "$file")
  [ "$grant_count" -ge 2 ] && score=$((score + 5)) || missing+=("v2028:related_grant_keywords (>=2)")
  local law_count; law_count=$(jq -r '.related_law_ids // [] | length' "$file")
  [ "$law_count" -ge 3 ] && score=$((score + 5)) || missing+=("v2028:related_law_ids (>=3)")
  local comp_count; comp_count=$(jq -r '.competitor_products // [] | length' "$file")
  if [ "$comp_count" -ge 3 ]; then
    score=$((score + 6))
  elif [ "$comp_count" -ge 1 ]; then
    score=$((score + 3))
    missing+=("v2028:competitor_products (>=3 推奨)")
  else
    missing+=("v2028:competitor_products (>=1)")
  fi
  local kpi_count; kpi_count=$(jq -r '.standard_dashboard_kpis // [] | length' "$file")
  if [ "$kpi_count" -ge 5 ]; then
    score=$((score + 5))
  elif [ "$kpi_count" -ge 3 ]; then
    score=$((score + 3))
    missing+=("v2028:standard_dashboard_kpis (>=5 推奨)")
  else
    missing+=("v2028:standard_dashboard_kpis (>=3)")
  fi
  # _internal_score 存在で +4 (管理者専用フィールドが整っている)
  if [ "$(jq -r 'has("_internal_score")' "$file")" = "true" ]; then
    score=$((score + 4))
  fi

  # ====== v2028 Iron-Dome 密度+UI雛形 (35点) ======
  local model_count; model_count=$(jq -r '.standard_db_skeleton.models // [] | length' "$file")
  if [ "$model_count" -ge 5 ]; then
    score=$((score + 8))
  elif [ "$model_count" -ge 3 ]; then
    score=$((score + 4))
    missing+=("v2028:standard_db_skeleton.models (>=5 推奨)")
  else
    missing+=("v2028:standard_db_skeleton.models (>=3)")
  fi
  local panel_count; panel_count=$(jq -r '.standard_panels // [] | length' "$file")
  if [ "$panel_count" -ge 6 ]; then
    score=$((score + 8))
  elif [ "$panel_count" -ge 4 ]; then
    score=$((score + 4))
    missing+=("v2028:standard_panels (>=6 推奨)")
  else
    missing+=("v2028:standard_panels (>=4)")
  fi
  if [ "$(jq -r 'has("iron_dome_density_target")' "$file")" = "true" ]; then
    local min_loc; min_loc=$(jq -r '.iron_dome_density_target.min_loc // 0' "$file")
    if [ "$min_loc" -ge 1500 ]; then
      score=$((score + 11))
    else
      score=$((score + 5))
      missing+=("v2028:iron_dome_density_target.min_loc (>=1500)")
    fi
  else
    missing+=("v2028:iron_dome_density_target")
  fi
  local hotspot_count; hotspot_count=$(jq -r '.competitor_hotspots_jp // [] | length' "$file")
  if [ "$hotspot_count" -ge 5 ]; then
    score=$((score + 8))
  elif [ "$hotspot_count" -ge 3 ]; then
    score=$((score + 5))
    missing+=("v2028:competitor_hotspots_jp (>=5 推奨)")
  else
    missing+=("v2028:competitor_hotspots_jp (>=3)")
  fi

  # ====== Tier 判定 ======
  local tier
  if [ "$score" -ge 95 ]; then tier="Diamond"
  elif [ "$score" -ge 85 ]; then tier="Platinum"
  elif [ "$score" -ge 70 ]; then tier="Gold"
  else tier="Reject"
  fi

  # JSON 出力
  jq -nc \
    --arg industry "$industry" \
    --arg tier "$tier" \
    --argjson score "$score" \
    --argjson missing "$(printf '%s\n' "${missing[@]:-}" | jq -R . | jq -s .)" \
    '{industry:$industry, blueprint_completeness:$score, tier:$tier, missing:$missing}'
}

# ====== メインループ ======
results=()
fail_count=0

if [ -n "$TARGET_INDUSTRY" ]; then
  files=("$DOMAINS_DIR/$TARGET_INDUSTRY.json")
else
  mapfile -t files < <(ls "$DOMAINS_DIR"/*.json 2>/dev/null | sort)
fi

for file in "${files[@]}"; do
  [ -f "$file" ] || { echo "WARN: $file が存在しません" >&2; continue; }
  result=$(score_one "$file")
  results+=("$result")
  tier=$(echo "$result" | jq -r '.tier')
  if [ "$tier" = "Reject" ]; then
    fail_count=$((fail_count + 1))
  fi
done

# 集計
summary=$(printf '%s\n' "${results[@]}" | jq -s '{
  total: length,
  diamond: [.[] | select(.tier == "Diamond")] | length,
  platinum: [.[] | select(.tier == "Platinum")] | length,
  gold: [.[] | select(.tier == "Gold")] | length,
  reject: [.[] | select(.tier == "Reject")] | length,
  avg_score: (map(.blueprint_completeness) | add / length),
  details: .
}')

if [ "$JSON_ONLY" -eq 1 ]; then
  echo "$summary"
else
  echo "=== SoloptiLinkAI v2028.0 DBL Blueprint Completeness Validator ==="
  echo ""
  echo "Total domains:    $(echo "$summary" | jq -r '.total')"
  echo "Diamond (>=95):   $(echo "$summary" | jq -r '.diamond')"
  echo "Platinum (>=85):  $(echo "$summary" | jq -r '.platinum')"
  echo "Gold (>=70):      $(echo "$summary" | jq -r '.gold')"
  echo "Reject (<70):     $(echo "$summary" | jq -r '.reject')"
  echo "Avg score:        $(echo "$summary" | jq -r '.avg_score | . * 10 | floor / 10')"
  echo ""
  echo "=== Per-domain detail ==="
  echo "$summary" | jq -r '.details[] | "  [\(.tier | @sh)] \(.industry) — \(.blueprint_completeness)pt" + (if (.missing | length) > 0 then " (missing: \(.missing | join(", ")))" else "" end)' | sed 's/'\''//g'
fi

if [ "$STRICT" -eq 1 ] && [ "$fail_count" -gt 0 ]; then
  echo "" >&2
  echo "STRICT MODE: $fail_count domain(s) below 70 (Reject tier)" >&2
  exit 1
fi

exit 0
