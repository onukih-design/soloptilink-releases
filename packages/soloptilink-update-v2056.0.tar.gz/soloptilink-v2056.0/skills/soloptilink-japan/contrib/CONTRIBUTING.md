# SoloptiLinkAI JAPAN-NATIVE — 貢献ガイド (SIer Marketplace)

`/soloptilink-japan` の **業種ドメイン辞書** と **帳票テンプレート** は、SIer・業界専門家からの貢献を受け付ける仕組みに移行しています（Phase 3〜）。このドキュメントは新しいドメイン辞書を追加したり、既存辞書を改善したりする方のためのガイドです。

---

## 🎯 貢献できるもの

| 種類 | ディレクトリ | 内容 |
|------|-------------|------|
| 業種ドメイン辞書 | `domains/*.json` | 業界用語・法令・帳票・KPI |
| 帳票テンプレート | `templates/japan/*.tsx` | React TSX で印刷最適化されたテンプレ |
| 法令DNA 拡張 | `lib/japan/laws.ts` | 新しい法令モジュールの追加 |
| 日本UX コンポーネント | `components/japan/*.tsx` | 和暦・印影・帳票等の新ウィジェット |
| 翻訳辞書 | `lib/japan/i18n.ts` | 英語/中国語/他言語の追加 |

---

## 📐 ドメイン辞書の要件

### スキーマ遵守
すべての `domains/*.json` は `schemas/domain.schema.json` に準拠する必要があります。

```bash
bash ~/.claude/skills/soloptilink-japan/contrib/validate_domain.sh ./my_new_domain.json
# → { "ok": true, "score": 95, "decision": "ACCEPTED" }
```

**合格条件**:
- JSON文法が正しい
- `required` フィールド（industry / industry_ja / version / applicable_laws / terminology / mandatory_fields / ui_hints）が全て存在
- 個人情報（メール・電話番号）が含まれていない
- 外部URLにクエリパラメータ付きトークンが埋め込まれていない
- `ui_hints.dashboard_kpi` が3件以上
- `mandatory_fields` が2カテゴリ以上

### 品質目標スコア
- **80 点以上** = ACCEPTED（マージ候補）
- **95 点以上** = 公式辞書として採用

---

## 🚀 貢献プロセス

### 1. 既存辞書を参考にひな形を作る

```bash
# 例: 製造業辞書を参考に「印刷業」辞書を作る
cp ~/.claude/skills/soloptilink-japan/domains/manufacturing.json ./printing.json
# 内容を印刷業向けに書き換える
```

### 2. 自動検証

```bash
bash ~/.claude/skills/soloptilink-japan/contrib/validate_domain.sh ./printing.json
```

### 3. Pull Request を投稿

- ブランチ名: `contrib/domain-<業種ID>`
- コミットメッセージ: `feat(domain): add <業種ID>.json (vX.X)`
- PR 説明に以下を含める:
  - 業界経験年数 or 関連資格（例: 行政書士・社労士等）
  - 情報源（法令・業界団体ガイドライン・公式資料のURL）
  - 想定ユースケース3つ以上
  - 既存の他業種辞書との差別化ポイント

### 4. レビュー基準
- [ ] スキーマ合格（validate_domain.sh が ACCEPTED）
- [ ] 情報の正確性（法令条文・根拠の参照明示）
- [ ] 専門用語の一貫性
- [ ] 過度な重複がない（他業種辞書との共通部分は切り出し）
- [ ] 機密情報の非混入（実在する顧客名・個人情報・社内規程等）

---

## ⚖ ライセンスと著作権

- 提出する貢献物は **MIT-like 商用利用可** のライセンスで SoloptiLinkAI に利用許諾されるものとします
- 貢献者リストに記載されます（`contrib/CONTRIBUTORS.md`）
- SoloptiLinkAI 顧客向けに再配布されますが、貢献者の営業秘密・顧客情報を含めることは禁止です

---

## 🚫 禁止事項

1. **顧客データの流用**: 実在する企業名・取引額・契約条項をそのままコピーしない
2. **個人情報の混入**: メール・電話・マイナンバー・本人確認書類の内容
3. **外部認証トークン**: 署名付きURL、API キー、OAuth token
4. **コピペ改変なし**: 他業種辞書を丸ごとコピーして1行書き換えのみの提出
5. **主観的な営業主張**: 「業界No.1」「唯一の」等の誇大表現

---

## 🏆 貢献者ランク

| ランク | 条件 | 特典 |
|-------|------|------|
| Contributor | 1辞書採用 | CONTRIBUTORS.md に記載 |
| Senior Contributor | 3辞書採用 or 法令DNA新規追加 | マーケットプレイスでの紹介 |
| Domain Expert | 10辞書採用 or 1業界で新法対応リード | 公式パートナーSIer認定 |
| Master Contributor | 自作業種Phase合計30件以上 | 有償版への優先アクセス・共同マーケティング |

---

## 📞 質問・サポート

- Issue: https://github.com/soloptilink/japan/issues
- 管理者連絡: contact@soloptilink.com（営業日3日以内に返信）
