'use client';
import React from 'react';
import { toZenkaku, toHankaku, normalizeForJapaneseField, normalizeForNumericField } from '../../lib/japan/kana';

export interface HanzenInputProps {
  value?: string;
  onChange?: (v: string) => void;
  autoNormalize?: 'japanese' | 'numeric' | 'none';
  placeholder?: string;
  className?: string;
  type?: 'text' | 'tel' | 'email';
}

/**
 * 全角半角自動変換入力
 * - autoNormalize="japanese": 氏名・住所用、半角→全角（数値・英字・カナ）
 * - autoNormalize="numeric": 金額・数値用、全角→半角
 * - autoNormalize="none": 変換しない
 */
export function HanzenInput({ value = '', onChange, autoNormalize = 'none', placeholder, className, type = 'text' }: HanzenInputProps) {
  const handleBlur = (e: React.FocusEvent<HTMLInputElement>) => {
    const v = e.target.value;
    const normalized =
      autoNormalize === 'japanese' ? normalizeForJapaneseField(v) :
      autoNormalize === 'numeric' ? normalizeForNumericField(v) :
      v;
    if (normalized !== v) onChange?.(normalized);
  };

  return (
    <input
      type={type}
      value={value}
      onChange={e => onChange?.(e.target.value)}
      onBlur={handleBlur}
      placeholder={placeholder}
      className={`border rounded px-3 py-2 ${className ?? ''}`}
    />
  );
}

export const zenkakuHelpers = { toZenkaku, toHankaku };
