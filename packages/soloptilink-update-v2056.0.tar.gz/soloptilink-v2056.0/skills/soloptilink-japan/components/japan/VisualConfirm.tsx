'use client';
import React, { useState } from 'react';

export interface VisualConfirmProps {
  projectName: string;
  confirmMarkdown: string;            // buildConfirmationDocument で生成したMD
  mermaidDiagrams?: Array<{ title: string; mermaid: string }>;
  svgs?: Array<{ title: string; svg: string }>;
  onApprove?: () => void;
  onReject?: (reason: string) => void;
  onModify?: (instructions: string) => void;
}

/**
 * Visual Confirm Loop 承認UI
 * 設計内容を視覚提示し、「承認/修正/却下」の3択で受け付ける。
 * 無言（タイムアウト）は承認として扱える（親コンポ側で制御）。
 */
export function VisualConfirm({ projectName, confirmMarkdown, mermaidDiagrams = [], svgs = [], onApprove, onReject, onModify }: VisualConfirmProps) {
  const [instructions, setInstructions] = useState('');
  const [status, setStatus] = useState<'pending' | 'approved' | 'modified' | 'rejected'>('pending');

  return (
    <div style={{ maxWidth: '1200px', margin: '0 auto', padding: '24px', fontFamily: "'Noto Sans JP', sans-serif" }}>
      <header style={{ borderBottom: '3px solid #0a7', paddingBottom: '12px', marginBottom: '24px' }}>
        <h1 style={{ margin: 0, fontSize: '24px' }}>🎨 Visual Confirm: {projectName}</h1>
        <p style={{ margin: '4px 0 0', color: '#666', fontSize: '14px' }}>設計内容を確認し、実装を承認してください。修正がある場合は具体的にご指示を。</p>
      </header>

      {/* Mermaid 図一覧 */}
      {mermaidDiagrams.length > 0 && (
        <section style={{ marginBottom: '24px' }}>
          <h2 style={{ fontSize: '18px', borderLeft: '4px solid #0a7', paddingLeft: '8px' }}>設計図（Mermaid）</h2>
          {mermaidDiagrams.map((d, i) => (
            <details key={i} style={{ marginBottom: '12px', padding: '12px', background: '#f9f9f9', border: '1px solid #ddd' }} open>
              <summary style={{ cursor: 'pointer', fontWeight: 'bold' }}>{d.title}</summary>
              <pre style={{ marginTop: '8px', overflow: 'auto', background: 'white', padding: '12px', fontSize: '12px' }}>
                <code>{d.mermaid}</code>
              </pre>
              <div style={{ fontSize: '11px', color: '#888' }}>※ Mermaid Live Editor (https://mermaid.live) に貼り付けると視覚化できます</div>
            </details>
          ))}
        </section>
      )}

      {/* SVG 一覧 */}
      {svgs.length > 0 && (
        <section style={{ marginBottom: '24px' }}>
          <h2 style={{ fontSize: '18px', borderLeft: '4px solid #0a7', paddingLeft: '8px' }}>ワイヤーフレーム</h2>
          {svgs.map((s, i) => (
            <details key={i} style={{ marginBottom: '12px', padding: '12px', background: '#f9f9f9', border: '1px solid #ddd' }} open>
              <summary style={{ cursor: 'pointer', fontWeight: 'bold' }}>{s.title}</summary>
              <div style={{ marginTop: '8px' }} dangerouslySetInnerHTML={{ __html: s.svg }} />
            </details>
          ))}
        </section>
      )}

      {/* 確認ドキュメント */}
      <section style={{ marginBottom: '24px' }}>
        <h2 style={{ fontSize: '18px', borderLeft: '4px solid #0a7', paddingLeft: '8px' }}>設計書</h2>
        <pre style={{ padding: '16px', background: '#fafafa', border: '1px solid #ddd', overflow: 'auto', fontSize: '13px', lineHeight: '1.6', whiteSpace: 'pre-wrap' }}>
          {confirmMarkdown}
        </pre>
      </section>

      {/* 承認アクション */}
      {status === 'pending' && (
        <section style={{ position: 'sticky', bottom: 0, background: 'white', borderTop: '2px solid #0a7', padding: '16px', margin: '24px -24px -24px' }}>
          <h3 style={{ margin: '0 0 12px', fontSize: '16px' }}>⚙ 次のアクションを選んでください</h3>
          <div style={{ display: 'flex', gap: '8px', marginBottom: '12px' }}>
            <button
              onClick={() => { setStatus('approved'); onApprove?.(); }}
              style={{ padding: '10px 24px', background: '#0a7', color: 'white', border: 'none', fontSize: '15px', fontWeight: 'bold', cursor: 'pointer', borderRadius: '4px' }}>
              ✅ この設計で実装開始
            </button>
            <button
              onClick={() => { if (instructions.trim()) { setStatus('modified'); onModify?.(instructions); } }}
              disabled={!instructions.trim()}
              style={{ padding: '10px 24px', background: '#f80', color: 'white', border: 'none', fontSize: '15px', fontWeight: 'bold', cursor: instructions.trim() ? 'pointer' : 'not-allowed', opacity: instructions.trim() ? 1 : 0.5, borderRadius: '4px' }}>
              🔧 修正指示を反映
            </button>
            <button
              onClick={() => { const r = prompt('却下理由'); if (r) { setStatus('rejected'); onReject?.(r); } }}
              style={{ padding: '10px 24px', background: '#c00', color: 'white', border: 'none', fontSize: '15px', cursor: 'pointer', borderRadius: '4px' }}>
              ❌ 却下
            </button>
          </div>
          <textarea
            value={instructions}
            onChange={e => setInstructions(e.target.value)}
            placeholder="修正指示を記入（例: WORKERロールには仕入画面を見せない / 請求書に源泉徴収欄を追加）"
            rows={3}
            style={{ width: '100%', padding: '8px', fontSize: '13px', border: '1px solid #ccc', borderRadius: '4px', resize: 'vertical' }}
          />
        </section>
      )}

      {status === 'approved' && <div style={{ padding: '16px', background: '#e6f7e6', border: '2px solid #0a7', marginTop: '12px' }}>✅ 承認しました。実装を開始します。</div>}
      {status === 'modified' && <div style={{ padding: '16px', background: '#fff8e6', border: '2px solid #f80', marginTop: '12px' }}>🔧 修正指示を反映します: {instructions}</div>}
      {status === 'rejected' && <div style={{ padding: '16px', background: '#fde8e8', border: '2px solid #c00', marginTop: '12px' }}>❌ 却下されました。再設計します。</div>}
    </div>
  );
}
