'use client';
import React from 'react';
import { escalate, BusinessPhrases, type KeigoLevel } from '../../lib/japan/keigo';

export interface KeigoTextProps {
  children: string;
  level?: KeigoLevel;
  prefix?: 'reply' | 'initiate' | 'apology' | 'thanks';
  suffix?: 'standard' | 'formal' | 'urgent';
  className?: string;
}

/**
 * ビジネス敬語で自動変換して表示
 * children: 素の日本語 → escalate() で敬語化
 * prefix/suffix: 挨拶・結びの定型文を付加
 */
export function KeigoText({ children, level = 'polite', prefix, suffix, className }: KeigoTextProps) {
  const body = escalate(children, level);
  const head = prefix ? BusinessPhrases.opening(prefix) + '\n' : '';
  const tail = suffix ? '\n' + BusinessPhrases.closing(suffix) : '';
  return <p className={`whitespace-pre-line ${className ?? ''}`}>{head}{body}{tail}</p>;
}
