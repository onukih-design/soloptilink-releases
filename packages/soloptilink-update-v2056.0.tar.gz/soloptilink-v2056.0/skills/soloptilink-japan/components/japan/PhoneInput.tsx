'use client';
import React from 'react';
import { formatPhone } from '../../lib/japan/kana';

export interface PhoneInputProps {
  value?: string;
  onChange?: (v: string) => void;
  className?: string;
}

export function PhoneInput({ value = '', onChange, className }: PhoneInputProps) {
  const handleBlur = () => {
    const formatted = formatPhone(value);
    if (formatted !== value) onChange?.(formatted);
  };

  return (
    <input
      type="tel"
      value={value}
      onChange={e => onChange?.(e.target.value)}
      onBlur={handleBlur}
      placeholder="03-1234-5678"
      className={`border rounded px-3 py-2 font-mono ${className ?? ''}`}
      aria-label="電話番号"
    />
  );
}
