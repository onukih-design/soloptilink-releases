'use client';
import React from 'react';
import type { TaxRate } from '../../lib/japan/tax';

export interface TaxRateSelectorProps {
  value?: TaxRate;
  onChange?: (r: TaxRate) => void;
  className?: string;
}

const LABELS: Record<TaxRate, string> = {
  standard: '10%（標準税率）',
  reduced: '8%（軽減税率）',
  exempt: '非課税',
  nontaxable: '不課税',
};

const DESCRIPTIONS: Record<TaxRate, string> = {
  standard: '一般の商品・サービス',
  reduced: '飲食料品・新聞定期購読',
  exempt: '商品券・切手・土地売買・住宅家賃など',
  nontaxable: '給与・寄附金・保険金・損害賠償金など',
};

export function TaxRateSelector({ value = 'standard', onChange, className }: TaxRateSelectorProps) {
  return (
    <div className={`inline-block ${className ?? ''}`}>
      <select
        value={value}
        onChange={e => onChange?.(e.target.value as TaxRate)}
        aria-label="消費税区分"
        className="border rounded px-2 py-1"
      >
        {(Object.keys(LABELS) as TaxRate[]).map(k => (
          <option key={k} value={k}>{LABELS[k]}</option>
        ))}
      </select>
      <small className="text-gray-500 ml-2" title={DESCRIPTIONS[value]}>ⓘ {DESCRIPTIONS[value]}</small>
    </div>
  );
}
