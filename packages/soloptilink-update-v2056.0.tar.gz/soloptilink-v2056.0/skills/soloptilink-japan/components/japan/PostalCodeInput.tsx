'use client';
import React, { useState } from 'react';
import { lookup } from '../../lib/japan/postal';
import { formatPostalCode } from '../../lib/japan/kana';

export interface PostalCodeInputProps {
  value?: string;
  onChange?: (v: string) => void;
  onResolve?: (address: { prefecture: string; city: string; town: string }) => void;
  className?: string;
}

export function PostalCodeInput({ value = '', onChange, onResolve, className }: PostalCodeInputProps) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleBlur = async () => {
    const formatted = formatPostalCode(value);
    if (formatted !== value) onChange?.(formatted);
    const digits = formatted.replace(/[^0-9]/g, '');
    if (digits.length !== 7) return;
    setLoading(true);
    setError(null);
    try {
      const addr = await lookup(digits);
      if (addr) {
        onResolve?.({ prefecture: addr.prefecture, city: addr.city, town: addr.town });
      } else {
        setError('該当する住所が見つかりませんでした');
      }
    } catch {
      setError('住所検索に失敗しました');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className={`inline-flex flex-col gap-1 ${className ?? ''}`}>
      <div className="inline-flex items-center gap-2">
        <span>〒</span>
        <input
          type="text"
          value={value}
          onChange={e => onChange?.(e.target.value)}
          onBlur={handleBlur}
          placeholder="123-4567"
          maxLength={8}
          className="border rounded px-3 py-2 font-mono w-32"
          aria-label="郵便番号"
        />
        {loading && <small className="text-gray-500">検索中…</small>}
      </div>
      {error && <small className="text-red-600">{error}</small>}
    </div>
  );
}
