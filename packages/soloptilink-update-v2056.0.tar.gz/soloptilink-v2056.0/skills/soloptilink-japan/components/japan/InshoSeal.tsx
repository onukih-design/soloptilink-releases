'use client';
import React, { useState, useRef } from 'react';

export interface InshoSealProps {
  value?: string;  // data URL or public URL
  onChange?: (dataUrl: string | null) => void;
  size?: number;
  label?: string;
  className?: string;
}

/**
 * 印影コンポーネント
 * - 画像アップロードで印鑑PNGを設定
 * - 帳票上に配置する際は position: absolute で重ねる想定
 * - 印影なしの場合は角印の文字プレースホルダを赤枠で表示
 */
export function InshoSeal({ value, onChange, size = 80, label = '印', className }: InshoSealProps) {
  const [preview, setPreview] = useState(value ?? null);
  const fileRef = useRef<HTMLInputElement>(null);

  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const result = String(reader.result);
      setPreview(result);
      onChange?.(result);
    };
    reader.readAsDataURL(file);
  };

  const clear = () => {
    setPreview(null);
    onChange?.(null);
    if (fileRef.current) fileRef.current.value = '';
  };

  return (
    <div className={`inline-flex flex-col items-center gap-1 ${className ?? ''}`}>
      {preview ? (
        <img
          src={preview}
          alt="印影"
          style={{ width: size, height: size, objectFit: 'contain' }}
          className="rounded"
        />
      ) : (
        <div
          style={{ width: size, height: size, borderColor: '#c53030', color: '#c53030' }}
          className="border-4 rounded-full flex items-center justify-center font-serif text-xl"
        >
          {label}
        </div>
      )}
      <div className="flex gap-2 text-xs">
        <input ref={fileRef} type="file" accept="image/png,image/jpeg" onChange={handleFile} className="hidden" id="insho-upload" />
        <label htmlFor="insho-upload" className="text-blue-600 hover:underline cursor-pointer">変更</label>
        {preview && <button type="button" onClick={clear} className="text-red-600 hover:underline">削除</button>}
      </div>
    </div>
  );
}
