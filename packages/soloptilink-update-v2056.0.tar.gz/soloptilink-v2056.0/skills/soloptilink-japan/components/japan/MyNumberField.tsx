'use client';
import React, { useState } from 'react';
import { MyNumber } from '../../lib/japan/laws';

export interface MyNumberFieldProps {
  value?: string;
  onChange?: (v: string) => void;
  purpose?: 'tax' | 'social_security' | 'disaster';
  onAudit?: (action: 'view' | 'edit' | 'copy', actor: string) => void;
  actorName?: string;
  className?: string;
}

/**
 * マイナンバー入力・表示欄
 * - デフォルトはマスク表示（下4桁のみ）
 * - 表示トグル時にonAuditで監査ログに記録
 * - 利用目的が取扱可能3分野に該当するかチェック
 */
export function MyNumberField({ value = '', onChange, purpose = 'tax', onAudit, actorName = 'system', className }: MyNumberFieldProps) {
  const [visible, setVisible] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (!MyNumber.canHandle(purpose)) {
    return (
      <div className="text-red-600 border border-red-300 bg-red-50 rounded p-3">
        マイナンバーは税・社会保障・災害対策の3分野でのみ取扱可能です。現在の利用目的 "{purpose}" では表示できません。
      </div>
    );
  }

  const handleChange = (v: string) => {
    onChange?.(v);
    if (v.length === 12) {
      setError(MyNumber.validate(v) ? null : 'チェックディジット不一致');
    } else {
      setError(null);
    }
    onAudit?.('edit', actorName);
  };

  const toggleVisible = () => {
    setVisible(v => !v);
    onAudit?.('view', actorName);
  };

  return (
    <div className={`inline-flex flex-col gap-1 ${className ?? ''}`}>
      <div className="inline-flex items-center gap-2">
        <input
          type={visible ? 'text' : 'password'}
          inputMode="numeric"
          maxLength={12}
          value={visible ? value : MyNumber.mask(value)}
          onChange={e => handleChange(e.target.value.replace(/[^0-9]/g, ''))}
          aria-label="個人番号（マイナンバー）"
          className="border rounded px-3 py-2 font-mono tracking-widest w-44"
        />
        <button
          type="button"
          onClick={toggleVisible}
          className="text-sm text-blue-600 hover:underline"
          aria-label={visible ? '個人番号を隠す' : '個人番号を表示'}
        >
          {visible ? '隠す' : '表示'}
        </button>
      </div>
      {error && <small className="text-red-600">⚠ {error}</small>}
      <small className="text-gray-500">※取扱目的: {purpose} / 操作は監査ログに記録されます</small>
    </div>
  );
}
