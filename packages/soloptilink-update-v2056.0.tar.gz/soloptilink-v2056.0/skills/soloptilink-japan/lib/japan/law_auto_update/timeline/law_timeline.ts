/**
 * Phase 46-LU-5 / Law Timeline
 *
 * 法令の公布→国会通過→施行→改正→失効 までの時系列イベントを構造化する。
 * 重要法令の歴史的経緯を可視化し、判例との関係も時系列で並べる。
 */

export type LawEventKind =
  | 'promulgation' // 公布
  | 'enactment' // 国会通過
  | 'effective' // 施行
  | 'amendment' // 改正
  | 'partial_effective' // 一部施行
  | 'sunset' // 失効
  | 'merger' // 統合 (他法律と統合)
  | 'rename' // 名称変更
  | 'judicial_review' // 司法審査 (違憲判断)
  | 'guideline_update'; // ガイドライン改訂

export interface LawTimelineEvent {
  date: string; // ISO YYYY-MM-DD
  law_short: string;
  kind: LawEventKind;
  description: string;
  related_case_ids?: string[];
  source: string;
}

export const LAW_TIMELINE_EVENTS: LawTimelineEvent[] = [
  // ============ 個情法 ============
  {
    date: '2003-05-30',
    law_short: '個情法',
    kind: 'promulgation',
    description: '個人情報保護法 制定',
    source: '平成15年法律57号',
  },
  {
    date: '2005-04-01',
    law_short: '個情法',
    kind: 'effective',
    description: '個情法 全面施行',
    source: '平成17年内閣府告示',
  },
  {
    date: '2015-09-09',
    law_short: '個情法',
    kind: 'amendment',
    description: '平成27年改正 (個人情報保護委員会創設・要配慮個人情報・匿名加工情報)',
    source: '平成27年法律65号',
  },
  {
    date: '2020-06-12',
    law_short: '個情法',
    kind: 'amendment',
    description: '令和2年改正 (仮名加工情報・越境移転規制・個人関連情報・課徴金導入)',
    source: '令和2年法律44号',
  },
  {
    date: '2022-04-01',
    law_short: '個情法',
    kind: 'effective',
    description: 'R2改正 全面施行 (個人関連情報・第26条漏えい報告72h義務)',
    source: '令和4年4月施行',
    related_case_ids: ['benesse_pii'],
  },

  // ============ インボイス制度 ============
  {
    date: '2016-03-31',
    law_short: 'インボイス制度',
    kind: 'amendment',
    description: '消費税法改正 (適格請求書等保存方式 導入決定)',
    source: '平成28年法律15号',
  },
  {
    date: '2023-10-01',
    law_short: 'インボイス制度',
    kind: 'effective',
    description: 'インボイス制度 全面施行',
    source: '令和5年10月施行',
  },

  // ============ 電帳法 ============
  {
    date: '1998-07-01',
    law_short: '電帳法',
    kind: 'promulgation',
    description: '電子帳簿保存法 制定',
    source: '平成10年法律25号',
  },
  {
    date: '2022-01-01',
    law_short: '電帳法',
    kind: 'amendment',
    description: '令和3年改正 (電子取引データ電子保存義務化・タイムスタンプ要件緩和)',
    source: '令和3年法律11号',
  },
  {
    date: '2024-01-01',
    law_short: '電帳法',
    kind: 'effective',
    description: 'R3改正 完全施行 (電子取引データの紙保存禁止・2年宥恕期間終了)',
    source: '令和6年1月施行',
  },

  // ============ 民法 ============
  {
    date: '1896-04-27',
    law_short: '民法',
    kind: 'promulgation',
    description: '民法 公布',
    source: '明治29年法律89号',
  },
  {
    date: '2017-06-02',
    law_short: '民法',
    kind: 'amendment',
    description: '債権法大改正 (R2.4施行) 公布',
    source: '平成29年法律44号',
  },
  {
    date: '2020-04-01',
    law_short: '民法',
    kind: 'effective',
    description: '債権法改正 施行 (消滅時効5/10年・法定利率3%・契約不適合責任)',
    source: '令和2年4月施行',
  },
  {
    date: '2022-04-01',
    law_short: '民法',
    kind: 'effective',
    description: '成年年齢18歳引き下げ',
    source: '平成30年法律59号',
  },

  // ============ 労契法 ============
  {
    date: '2008-03-01',
    law_short: '労契法',
    kind: 'effective',
    description: '労働契約法 施行',
    source: '平成19年法律128号',
  },
  {
    date: '2018-06-01',
    law_short: '労契法',
    kind: 'judicial_review',
    description: '労契法20条 不合理な労働条件の禁止 (ハマキョウレックス事件)',
    source: '最判H30.6.1',
    related_case_ids: ['hamakyo_rex_H30', 'nagasawa_unyu_H30'],
  },
  {
    date: '2020-04-01',
    law_short: '労契法',
    kind: 'amendment',
    description: 'パートタイム・有期雇用労働法施行 (労契法20条移管)',
    source: '令和2年4月施行',
  },

  // ============ 金商法 ============
  {
    date: '2007-09-30',
    law_short: '金商法',
    kind: 'effective',
    description: '金融商品取引法 施行 (旧証券取引法を改正・改称)',
    source: '平成19年9月施行',
  },
  {
    date: '2023-11-29',
    law_short: '金商法',
    kind: 'amendment',
    description: '令和5年改正 (四半期報告書廃止・半期報告書化)',
    source: '令和5年法律79号',
  },

  // ============ 刑法 ============
  {
    date: '1907-04-24',
    law_short: '刑法',
    kind: 'promulgation',
    description: '刑法 公布',
    source: '明治40年法律45号',
  },
  {
    date: '2022-06-17',
    law_short: '刑法',
    kind: 'amendment',
    description: '懲役・禁錮を「拘禁刑」に一本化 (R7.6施行)',
    source: '令和4年法律67号',
  },
  {
    date: '2023-07-13',
    law_short: '刑法',
    kind: 'effective',
    description: '不同意性交等罪・不同意わいせつ罪 新設',
    source: '令和5年7月施行',
  },
  {
    date: '2025-06-01',
    law_short: '刑法',
    kind: 'effective',
    description: '拘禁刑施行 (懲役・禁錮の統合)',
    source: '令和7年6月施行',
  },

  // ============ 建設業法 ============
  {
    date: '2024-06-07',
    law_short: '建設業法',
    kind: 'amendment',
    description: 'R6改正 (著しく短い工期での契約禁止・労務費見積基準・主任技術者要件緩和)',
    source: '令和6年法律51号',
  },

  // ============ フリーランス法 ============
  {
    date: '2023-05-12',
    law_short: 'フリーランス法',
    kind: 'promulgation',
    description: '特定受託事業者に係る取引の適正化等に関する法律 公布',
    source: '令和5年法律25号',
  },
  {
    date: '2024-11-01',
    law_short: 'フリーランス法',
    kind: 'effective',
    description: 'フリーランス法 施行 (取引条件明示義務・60日以内支払・育介配慮)',
    source: '令和6年11月施行',
  },

  // ============ 著作権法 ============
  {
    date: '2018-12-30',
    law_short: '著作権法',
    kind: 'amendment',
    description: 'TPP関連 保護期間50→70年延長',
    source: '平成28年法律108号',
  },
  {
    date: '2023-06-07',
    law_short: '著作権法',
    kind: 'amendment',
    description: 'AI生成物・情報解析関係改正 (30条の4 関連)',
    source: '令和5年法律33号',
  },

  // ============ AI関連 ============
  {
    date: '2024-04-19',
    law_short: 'AI事業者ガイドライン',
    kind: 'guideline_update',
    description: '総務省・経産省「AI事業者ガイドライン Version 1.0」公表',
    source: '令和6年4月',
  },

  // ============ サイバー ============
  {
    date: '2014-11-12',
    law_short: 'サイバーセキュリティ基本法',
    kind: 'promulgation',
    description: '制定',
    source: '平成26年法律104号',
  },
  {
    date: '2025-04-01',
    law_short: '能動的サイバー防御法',
    kind: 'effective',
    description: '能動的サイバー防御法 施行',
    source: '令和6年法律',
  },
];

// ============================================================================
// 検索ユーティリティ
// ============================================================================

export function eventsByLaw(lawShort: string): LawTimelineEvent[] {
  return LAW_TIMELINE_EVENTS.filter((e) => e.law_short === lawShort)
    .sort((a, b) => a.date.localeCompare(b.date));
}

export function eventsByDateRange(from: string, to: string): LawTimelineEvent[] {
  return LAW_TIMELINE_EVENTS.filter((e) => e.date >= from && e.date <= to)
    .sort((a, b) => a.date.localeCompare(b.date));
}

export function eventsByKind(kind: LawEventKind): LawTimelineEvent[] {
  return LAW_TIMELINE_EVENTS.filter((e) => e.kind === kind);
}

export function recentEvents(monthsBack: number, today: Date = new Date()): LawTimelineEvent[] {
  const cut = new Date(today);
  cut.setMonth(cut.getMonth() - monthsBack);
  const iso = cut.toISOString().slice(0, 10);
  return LAW_TIMELINE_EVENTS
    .filter((e) => e.date >= iso)
    .sort((a, b) => b.date.localeCompare(a.date));
}

export function upcomingEvents(monthsAhead: number, today: Date = new Date()): LawTimelineEvent[] {
  const cut = new Date(today);
  cut.setMonth(cut.getMonth() + monthsAhead);
  const iso = cut.toISOString().slice(0, 10);
  const todayIso = today.toISOString().slice(0, 10);
  return LAW_TIMELINE_EVENTS
    .filter((e) => e.date > todayIso && e.date <= iso)
    .sort((a, b) => a.date.localeCompare(b.date));
}

export function buildTimelineMarkdown(lawShort?: string): string {
  const events = lawShort ? eventsByLaw(lawShort) : [...LAW_TIMELINE_EVENTS].sort((a, b) => a.date.localeCompare(b.date));
  const lines: string[] = [];
  lines.push(`# ${lawShort ?? '全法令'} タイムライン`);
  lines.push('');
  for (const e of events) {
    lines.push(`- **${e.date}** [${e.kind}] ${e.law_short}: ${e.description}`);
    lines.push(`  - 出典: ${e.source}`);
    if (e.related_case_ids?.length) {
      lines.push(`  - 関連判例: ${e.related_case_ids.join(', ')}`);
    }
  }
  return lines.join('\n');
}

export function countTimelineEvents(): {
  total: number;
  by_kind: Record<string, number>;
  by_law: Record<string, number>;
} {
  const byKind: Record<string, number> = {};
  const byLaw: Record<string, number> = {};
  for (const e of LAW_TIMELINE_EVENTS) {
    byKind[e.kind] = (byKind[e.kind] ?? 0) + 1;
    byLaw[e.law_short] = (byLaw[e.law_short] ?? 0) + 1;
  }
  return { total: LAW_TIMELINE_EVENTS.length, by_kind: byKind, by_law: byLaw };
}
