/**
 * Phase 46-LU / Legal Update Auto-Learner — public exports
 *
 * 利用例:
 *   import { SourceRegistry, createNodePersistLayer, createNodePreviousVersionLookup } from 'lib/japan/law_auto_update';
 *
 *   const registry = new SourceRegistry();
 *   const persist = await createNodePersistLayer('~/.soloptilink/learning/');
 *   const prev = await createNodePreviousVersionLookup('~/.soloptilink/learning/');
 *   const result = await registry.orchestrate(prev, persist, { target: 'top' });
 *   console.log(`検知された改正: ${result.changesDetected} 件 / ${result.totalChecked} 件中`);
 */

export * from './source_egov_v2';
export * from './source_kanpo';
export * from './source_pubcomment';
export * from './catalog_full';
export * from './change_detector';
export * from './impact_analyzer_v2';
export * from './auto_pr_generator';
export * from './personalized_alert';
export * from './rag_indexer';
export * from './registry';
export * from './attribution';
export {
  rateLimited,
  configureRateLimit,
  snapshotRateLimiter,
} from './rate_limiter';

// Phase 46-LU-2: Full Corpus + Six Codes + Reward Learning
export * from './corpus/six_codes';
export * from './corpus/legal_corpus';
export * from './corpus/tier_classifier';
export * from './corpus/full_corpus_loader';
export * from './corpus/vector_indexer';
export * from './corpus/cross_reference_graph';
export * from './corpus/judiciary_law_link';
export * from './corpus/legal_qa_engine';
export * from './reward/reward_learner';
export * from './reward/reward_storage';
export * from './learning_dashboard';

// Phase 46-LU-3: Knowledge Completeness Edition
export * from './corpus/supplementary_codes';
export * from './corpus/special_criminal_law';
export * from './corpus/international_law';
export * from './gap_analysis/knowledge_gap_analyzer';
export * from './gap_analysis/coverage_matrix';
export * from './gap_analysis/gap_recommendations';
export * from './lawful_tools/time_limit_calculator';
export * from './lawful_tools/penalty_extractor';
export * from './lawful_tools/citation_validator';
export * from './knowledge_completeness_dashboard';

// Phase 46-LU-4: Knowledge Saturation Edition
export * from './corpus/case_law_extended';
export * from './corpus/case_law_supplement';
export * from './corpus/case_dedup';
export * from './corpus/case_law_integrity_report';
export * from './corpus/corpus_saturation_loader';
export * from './comparative_law/gdpr_ccpa';
export * from './comparative_law/us_export_control';
export * from './comparative_law/sox_internal_control';
export * from './comparative_law/anti_bribery_global';
export * from './ordinances/prefecture_ordinances';
export * from './ordinances/municipal_ordinances';
export * from './scholarly/scholarly_doctrines';
export * from './gap_analysis/auto_gap_closer';
export * from './gap_analysis/saturation_dashboard';
export * from './gap_analysis/iterative_completion';

// Phase 46-LU-5: Knowledge Operational Edition (法令RAG/コンプラ/契約/タイムライン/リスク/引用/AI/Omega/CCS/マッピング)
export * from './legal_rag/embedding_index';
export * from './legal_rag/llm_prompt_builder';
export * from './compliance/code_compliance_scanner';
export * from './contracts/contract_clause_generator';
export * from './timeline/law_timeline';
export * from './risk/legal_risk_scoring';
export * from './citation/citation_network';
export * from './advisor/legal_advisor';
export * from './bridge/omega_legal_bridge';
export * from './ccs/legal_axis';
export * from './mapping/case_to_current_law';
export * from './phase46_lu5_dashboard';

// Phase 46-LU-6: Knowledge Productization Edition (SaaS化)
export * from './subscription/plans_catalog';
export * from './api_gateway/legal_api_endpoints';
export * from './rate_limiting/plan_quota';
export * from './audit_log/legal_audit_logger';
export * from './multi_tenant/tenant_isolator';
export * from './export_engine/document_exporter';
export * from './email_alerts/amendment_alert_dispatcher';
export * from './webhook/external_dispatcher';
export * from './billing/usage_metering';
export * from './mobile_sdk/lightweight_client';
export * from './plugin_system/plugin_registry';
export * from './phase46_lu6_dashboard';

export const PHASE_46_LU_VERSION = '6.0.0';
export const PHASE_46_LU_RELEASE_DATE = '2026-05-17';
export const PHASE_46_LU2_VERSION = '2.0.0';
export const PHASE_46_LU2_RELEASE_DATE = '2026-05-15';
export const PHASE_46_LU3_VERSION = '3.0.0';
export const PHASE_46_LU3_RELEASE_DATE = '2026-05-16';
export const PHASE_46_LU4_VERSION = '4.0.0';
export const PHASE_46_LU4_RELEASE_DATE = '2026-05-16';
export const PHASE_46_LU5_VERSION = '5.0.0';
export const PHASE_46_LU5_RELEASE_DATE = '2026-05-17';
export const PHASE_46_LU6_VERSION = '6.0.0';
export const PHASE_46_LU6_RELEASE_DATE = '2026-05-17';

// Phase 46-LU-7: Knowledge Excellence Edition (運用成熟・スケール・規制連携)
export * from './observability/observability_layer';
export * from './incident_response/incident_orchestrator';
export * from './ab_testing/feature_flags';
export * from './growth/user_analytics';
export * from './knowledge_distillation/distillation_pipeline';
export * from './regulatory_radar/amendment_predictor';
export * from './expert_directory/expert_matching';
export * from './white_label/branding_engine';
export * from './api_marketplace/marketplace_registry';
export * from './certification/certification_program';
export * from './regulator_liaison/regulator_reporting';
export * from './phase46_lu7_dashboard';

export const PHASE_46_LU7_VERSION = '7.0.0';
export const PHASE_46_LU7_RELEASE_DATE = '2026-05-17';

// Phase 46-LU-8: Quality Deepening & SIEL Bridge Edition (質的深化＋SIEL Phase 47-50 橋渡し)
export * from './corpus/case_law_v3';
export * from './corpus/catalog_v3';
export * from './historical/historical_amendments';
export * from './regulatory_radar/longterm_predictor';
export * from './siel_bridge/siel_integration_bridge';
export * from './phase46_lu8_dashboard';

export const PHASE_46_LU8_VERSION = '8.0.0';
export const PHASE_46_LU8_RELEASE_DATE = '2026-05-17';
