/**
 * Phase 46-LU-4 supplement / 判例 dedup & 整合性ユーティリティ
 *
 * 複数の判例ソース (LANDMARK / EXTENDED / SUPPLEMENT) を merge する際に、
 *  - case_id 完全一致
 *  - citation の高類似度 (90%以上 char-shared)
 *  - short_name + decision_date 一致
 * の3つの手段で重複を検知する。
 *
 * 判例DBの拡張で重複混入による信頼性低下を防ぐ。
 */

import type { CaseLawRef } from './judiciary_law_link';

export interface DuplicateGroup {
  reason: 'case_id_match' | 'citation_match' | 'name_date_match';
  case_ids: string[];
  representative: CaseLawRef;
}

/**
 * 主キー (case_id) 重複検知
 */
export function detectIdDuplicates(cases: CaseLawRef[]): DuplicateGroup[] {
  const map = new Map<string, CaseLawRef[]>();
  for (const c of cases) {
    if (!map.has(c.case_id)) map.set(c.case_id, []);
    map.get(c.case_id)!.push(c);
  }
  const groups: DuplicateGroup[] = [];
  for (const [id, list] of map) {
    if (list.length > 1) {
      groups.push({
        reason: 'case_id_match',
        case_ids: list.map((_, i) => `${id}#${i}`),
        representative: list[0],
      });
    }
  }
  return groups;
}

/**
 * citation の高類似度判定 (正規化後 Jaccard)
 */
export function detectCitationNearDuplicates(cases: CaseLawRef[], threshold = 0.9): DuplicateGroup[] {
  const groups: DuplicateGroup[] = [];
  const normalize = (s: string) =>
    s.replace(/\s/g, '').replace(/[ーー－-]/g, '-').toLowerCase();
  const norms = cases.map((c) => ({ c, n: normalize(c.citation) }));
  const visited = new Set<number>();
  for (let i = 0; i < norms.length; i++) {
    if (visited.has(i)) continue;
    const group: CaseLawRef[] = [norms[i].c];
    for (let j = i + 1; j < norms.length; j++) {
      if (visited.has(j)) continue;
      const sim = jaccard(norms[i].n, norms[j].n);
      if (sim >= threshold) {
        group.push(norms[j].c);
        visited.add(j);
      }
    }
    if (group.length > 1) {
      groups.push({
        reason: 'citation_match',
        case_ids: group.map((c) => c.case_id),
        representative: group[0],
      });
    }
  }
  return groups;
}

/**
 * 通称 + 判決日 一致判定
 */
export function detectNameDateDuplicates(cases: CaseLawRef[]): DuplicateGroup[] {
  const map = new Map<string, CaseLawRef[]>();
  for (const c of cases) {
    const key = `${normalizeName(c.short_name)}|${c.decision_date}`;
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push(c);
  }
  const groups: DuplicateGroup[] = [];
  for (const [, list] of map) {
    if (list.length > 1) {
      groups.push({
        reason: 'name_date_match',
        case_ids: list.map((c) => c.case_id),
        representative: list[0],
      });
    }
  }
  return groups;
}

function normalizeName(s: string): string {
  return s.replace(/\s/g, '').replace(/[()「」『』【】]/g, '').toLowerCase();
}

function jaccard(a: string, b: string): number {
  if (a === b) return 1;
  if (a.length === 0 || b.length === 0) return 0;
  // 文字 bigram の Jaccard
  const bigrams = (s: string) => {
    const set = new Set<string>();
    for (let i = 0; i < s.length - 1; i++) set.add(s.substring(i, i + 2));
    return set;
  };
  const A = bigrams(a);
  const B = bigrams(b);
  let inter = 0;
  for (const x of A) if (B.has(x)) inter++;
  return inter / (A.size + B.size - inter);
}

/**
 * dedup: 重複検出後、最初に現れたものを残す
 */
export function dedupeCases(cases: CaseLawRef[]): {
  unique: CaseLawRef[];
  removed: number;
  duplicates_summary: DuplicateGroup[];
} {
  const idDups = detectIdDuplicates(cases);
  const nameDateDups = detectNameDateDuplicates(cases);
  const seen = new Set<string>();
  const unique: CaseLawRef[] = [];
  for (const c of cases) {
    if (seen.has(c.case_id)) continue;
    seen.add(c.case_id);
    unique.push(c);
  }
  return {
    unique,
    removed: cases.length - unique.length,
    duplicates_summary: [...idDups, ...nameDateDups],
  };
}

/**
 * citation 完全一致をビルトインで持たせる (純粋関数)
 */
export function detectExactCitationDuplicates(cases: CaseLawRef[]): DuplicateGroup[] {
  const map = new Map<string, CaseLawRef[]>();
  for (const c of cases) {
    const key = c.citation.trim();
    if (!key) continue;
    if (!map.has(key)) map.set(key, []);
    map.get(key)!.push(c);
  }
  const groups: DuplicateGroup[] = [];
  for (const [, list] of map) {
    if (list.length > 1) {
      groups.push({
        reason: 'citation_match',
        case_ids: list.map((c) => c.case_id),
        representative: list[0],
      });
    }
  }
  return groups;
}
