/**
 * Phase 46-LU-4 / Corpus Saturation Loader
 *
 * 9,000 法令の本文を実際に取得し、Tier 別の cron 計画に従って
 * 段階的に corpus.jsonl に飽和させる。Phase 46-LU-2 の FullCorpusLoader を
 * オーケストレーションして「飽和度 100%」を目指す。
 *
 * 設計:
 *  - 1 サイクル = 1 週 = 416 法令取得 (S6+A60+B100+C200+D50)
 *  - 22 週 (約 5 ヶ月) で 9,000 法令完全カバレッジ
 *  - 失敗時のリジューム (各サイクルで進捗を JSONL 永続化)
 *  - スループット監視 (req/sec, success rate, 429回数)
 *  - フェイルセーフ: 連続失敗 5 回でサイクル中断
 */

import type { CorpusEntry, LegalTier } from './legal_corpus';
import { computeCoverage, planNextCron, TIER_FETCH_BUDGET } from './legal_corpus';
import type { CorpusPersistLayer, CorpusLoaderOptions } from './full_corpus_loader';
import { FullCorpusLoader } from './full_corpus_loader';

export interface SaturationCycleResult {
  cycle_id: string;
  started_at: string;
  finished_at: string;
  tiers_processed: LegalTier[];
  total_attempted: number;
  total_succeeded: number;
  total_failed: number;
  rate_limit_hits: number;
  coverage_before_pct: number;
  coverage_after_pct: number;
  duration_ms: number;
  errors_top5: Array<{ law_id: string; error: string }>;
}

export interface SaturationProgressLog {
  cycle_count: number;
  total_attempted_cumulative: number;
  total_succeeded_cumulative: number;
  coverage_pct_history: Array<{ cycle: number; pct: number }>;
  estimated_cycles_remaining: number;
  estimated_completion_date?: string;
}

export class CorpusSaturationLoader {
  private readonly base: FullCorpusLoader;
  private readonly maxConsecutiveFailures: number;

  constructor(opts: { base?: FullCorpusLoader; maxConsecutiveFailures?: number } = {}) {
    this.base = opts.base ?? new FullCorpusLoader();
    this.maxConsecutiveFailures = opts.maxConsecutiveFailures ?? 5;
  }

  /**
   * 1 サイクルを実行 (1 週分の取得 = 416 法令)。
   * 通常は cron で 1 週ごとに呼ばれる。
   */
  async runCycle(
    persist: CorpusPersistLayer,
    opts: CorpusLoaderOptions = {},
  ): Promise<SaturationCycleResult> {
    const cycleId = `cycle_${new Date().toISOString().replace(/[^0-9]/g, '').slice(0, 14)}`;
    const startedAt = new Date().toISOString();
    const t0 = Date.now();

    const beforeEntries = await persist.loadCorpus();
    const coverageBefore = computeCoverage(beforeEntries).coverage_pct;

    // Tier 段階処理: S → A → B → C → D
    const tiers: LegalTier[] = ['S', 'A', 'B', 'C', 'D'];
    let totalAttempted = 0;
    let totalSucceeded = 0;
    let totalFailed = 0;
    let rateLimitHits = 0;
    const errors: Array<{ law_id: string; error: string }> = [];
    let consecutiveFailures = 0;
    const processed: LegalTier[] = [];

    for (const tier of tiers) {
      const budget = TIER_FETCH_BUDGET[tier];
      const r = await this.base.runOnce(persist, {
        ...opts,
        target: 'all',
        maxFetch: budget,
        fetchTextForS_A: tier === 'S' || tier === 'A',
      });
      processed.push(tier);
      totalAttempted += budget;
      totalSucceeded += r.updated;
      totalFailed += r.errors.length;
      for (const e of r.errors) {
        errors.push(e);
        if (/rate limit|429/i.test(e.error)) rateLimitHits++;
      }
      // 連続失敗閾値
      if (r.errors.length >= this.maxConsecutiveFailures) {
        consecutiveFailures++;
        if (consecutiveFailures >= 2) break; // Tier 2連続失敗で中断
      } else {
        consecutiveFailures = 0;
      }
    }

    const afterEntries = await persist.loadCorpus();
    const coverageAfter = computeCoverage(afterEntries).coverage_pct;
    const errorsTop5 = errors.slice(0, 5);

    return {
      cycle_id: cycleId,
      started_at: startedAt,
      finished_at: new Date().toISOString(),
      tiers_processed: processed,
      total_attempted: totalAttempted,
      total_succeeded: totalSucceeded,
      total_failed: totalFailed,
      rate_limit_hits: rateLimitHits,
      coverage_before_pct: coverageBefore,
      coverage_after_pct: coverageAfter,
      duration_ms: Date.now() - t0,
      errors_top5: errorsTop5,
    };
  }

  /**
   * 全体進捗をレポート (cron間で進捗履歴を読みつつ次サイクル予測)
   */
  computeProgress(opts: {
    cycles: SaturationCycleResult[];
    target_coverage_pct: number;
  }): SaturationProgressLog {
    if (opts.cycles.length === 0) {
      return {
        cycle_count: 0,
        total_attempted_cumulative: 0,
        total_succeeded_cumulative: 0,
        coverage_pct_history: [],
        estimated_cycles_remaining: 22,
      };
    }
    const totalAttempted = opts.cycles.reduce((a, c) => a + c.total_attempted, 0);
    const totalSucceeded = opts.cycles.reduce((a, c) => a + c.total_succeeded, 0);
    const history = opts.cycles.map((c, i) => ({ cycle: i + 1, pct: c.coverage_after_pct }));
    const last = opts.cycles[opts.cycles.length - 1];
    const delta = opts.cycles.length >= 2
      ? last.coverage_after_pct - opts.cycles[opts.cycles.length - 2].coverage_after_pct
      : last.coverage_after_pct - last.coverage_before_pct;
    const remainingPct = Math.max(0, opts.target_coverage_pct - last.coverage_after_pct);
    const cyclesRemaining = delta > 0 ? Math.ceil(remainingPct / delta) : 22;

    let estimatedCompletion: string | undefined;
    if (cyclesRemaining > 0 && cyclesRemaining < 100) {
      const future = new Date();
      future.setDate(future.getDate() + cyclesRemaining * 7);
      estimatedCompletion = future.toISOString().slice(0, 10);
    }

    return {
      cycle_count: opts.cycles.length,
      total_attempted_cumulative: totalAttempted,
      total_succeeded_cumulative: totalSucceeded,
      coverage_pct_history: history,
      estimated_cycles_remaining: cyclesRemaining,
      estimated_completion_date: estimatedCompletion,
    };
  }

  /**
   * 次サイクルの優先取得対象 (Tier別)
   */
  planNextCycle(entries: CorpusEntry[]): Array<{ tier: LegalTier; ids: string[] }> {
    return planNextCron(entries);
  }
}

/**
 * 進捗履歴の永続化 (saturation_cycles.jsonl)
 */
export interface SaturationCyclesPersistLayer {
  appendCycle(result: SaturationCycleResult): Promise<void>;
  loadAllCycles(): Promise<SaturationCycleResult[]>;
}

export async function createNodeSaturationPersistLayer(baseDir: string): Promise<SaturationCyclesPersistLayer> {
  const { mkdir, readFile, appendFile } = await import('node:fs/promises');
  const path = await import('node:path');
  const dir = path.join(baseDir, 'legal_corpus', 'saturation');
  await mkdir(dir, { recursive: true });
  const file = path.join(dir, 'cycles.jsonl');
  return {
    async appendCycle(result) {
      await appendFile(file, JSON.stringify(result) + '\n', 'utf8');
    },
    async loadAllCycles() {
      try {
        const txt = await readFile(file, 'utf8');
        return txt.split('\n').filter((l) => l.trim().length > 0).map((l) => JSON.parse(l));
      } catch {
        return [];
      }
    },
  };
}
