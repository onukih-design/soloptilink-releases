/**
 * Phase 46-LU-3 / Citation Validator
 *
 * 引用形式の妥当性を検証する。
 *  - 判例: 「最判S29.8.20 民集8-8-1505」のような正式引用
 *  - 法令: 「民法第415条」「会社法第309条第2項」のような条文引用
 *  - 出典: 政府公開データの出典記載の有無
 *
 * 著作権法32条の引用要件 (主従明瞭/出典明記/改変なし) の自動チェックも兼ねる。
 */

export interface CitationCheck {
  raw: string;
  /** 種別 */
  kind: 'case' | 'statute' | 'unknown';
  /** 認識した正規化済み引用 */
  normalized?: string;
  /** 不備指摘 */
  defects: string[];
  /** 32条引用要件 */
  meets_article32_fair_use: boolean;
}

const CASE_PATTERNS: RegExp[] = [
  // 最判H30.6.1 民集72-2-202
  /最(?:判|決|大判|大決)?(?:S|H|R)\d+\.\d+\.\d+\s*[民刑集判時タ]+\d+[-－]\d+[-－]\d+/,
  // 東京地判H30.4.1
  /(?:東京|大阪|名古屋|札幌|仙台|福岡|広島|高松|高裁|地裁|簡裁)(?:判|決)?(?:S|H|R)?\d+\.\d+\.\d+/,
  // 知財高判R5.6.8
  /知財高(?:判|決)R\d+\.\d+\.\d+/,
];

const STATUTE_PATTERN = /(?:憲法|民法|商法|会社法|刑法|民事訴訟法|民訴|刑事訴訟法|刑訴|労働基準法|労基法|個人情報保護法|個情法|金融商品取引法|金商法|借地借家法|建設業法|宅地建物取引業法|宅建業法|医療法|薬機法|介護保険法|特許法|商標法|意匠法|著作権法|不正競争防止法|不競法|消費者契約法|消契法|特定商取引法|特商法|景品表示法|景表法|国家賠償法|国賠法|行政手続法|行政事件訴訟法|行訴法|地方自治法|破産法|民事再生法|会社更生法|電子帳簿保存法|電帳法)第?\d+(?:の\d+)?条(?:第\d+項)?(?:第\d+号)?/g;

export function validateCitation(input: { text: string }): CitationCheck[] {
  const out: CitationCheck[] = [];
  // 判例引用
  for (const re of CASE_PATTERNS) {
    const g = new RegExp(re.source, 'g');
    let m: RegExpExecArray | null;
    while ((m = g.exec(input.text)) !== null) {
      out.push({
        raw: m[0],
        kind: 'case',
        normalized: m[0].replace(/\s+/g, ' '),
        defects: validateCaseCitationFormat(m[0]),
        meets_article32_fair_use: true, // 引用としては有効
      });
    }
  }
  // 法令引用
  const stReg = new RegExp(STATUTE_PATTERN.source, 'g');
  let sm: RegExpExecArray | null;
  while ((sm = stReg.exec(input.text)) !== null) {
    out.push({
      raw: sm[0],
      kind: 'statute',
      normalized: sm[0],
      defects: [],
      meets_article32_fair_use: true,
    });
  }
  return out;
}

function validateCaseCitationFormat(citation: string): string[] {
  const defects: string[] = [];
  // 判決日が H30.6.1 形式か?
  if (!/[SHR]\d+\.\d+\.\d+/.test(citation)) {
    defects.push('和暦+日付形式 (例: H30.6.1) が認識できない');
  }
  // 判例集の表記があるか?
  if (!/(?:民集|刑集|集民|判時|判タ|労判)/.test(citation)) {
    defects.push('判例集の表記 (民集/刑集/集民/判時/判タ/労判) がない');
  }
  return defects;
}

/**
 * 引用本文の長さチェック (32条 1〜200字推奨)
 */
export function checkQuotationLength(input: { quoted_text: string; surrounding_text: string }): {
  ok: boolean;
  quoted_chars: number;
  surrounding_chars: number;
  ratio: number;
  warnings: string[];
} {
  const q = input.quoted_text.length;
  const s = input.surrounding_text.length;
  const ratio = s > 0 ? q / s : Infinity;
  const warnings: string[] = [];
  if (q > 200) warnings.push('引用が 200 字を超過。著作権法32条の「正当な範囲」を超えるおそれ');
  if (q > 0 && s === 0) warnings.push('引用しかなく、自己の論述 (主) が不在 (主従関係の主が欠落)');
  if (ratio > 1.0) warnings.push('引用が自己の論述より長い (主従明瞭性の疑い)');
  return { ok: warnings.length === 0, quoted_chars: q, surrounding_chars: s, ratio, warnings };
}

/**
 * 出典明記の検査
 */
export function checkSourceAttribution(text: string): {
  has_source: boolean;
  source_kind?: 'gov_data' | 'kanpo' | 'commercial' | 'unknown';
  notes: string[];
} {
  const notes: string[] = [];
  if (/出典:.*e-Gov/i.test(text)) return { has_source: true, source_kind: 'gov_data', notes };
  if (/出典:.*官報/.test(text)) return { has_source: true, source_kind: 'kanpo', notes };
  if (/出典:|参考:|Source:/i.test(text)) return { has_source: true, source_kind: 'unknown', notes };
  notes.push('出典が明記されていません (政府データ・判例本文を含む場合は必須)');
  return { has_source: false, notes };
}
