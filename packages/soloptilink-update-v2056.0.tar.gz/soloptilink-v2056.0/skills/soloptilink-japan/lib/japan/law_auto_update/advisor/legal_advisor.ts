/**
 * Phase 46-LU-5 / Legal Advisor (法務 AI 対話エンジン)
 *
 * Phase 46-LU-2 の legal_qa_engine をベースに、対話セッション化。
 * セッションコンテキスト、フォローアップ質問、複数ターン QA、シナリオ分析を統合。
 *
 *  - 既存の answerLegalQuestion を内包 (六法 + judiciary)
 *  - セッション履歴 (multi-turn)
 *  - シナリオ分析 (リスク評価 + 推奨アクション)
 *  - 関連判例検索 + 改正アラート
 *  - 出典強制付与
 */

import { answerLegalQuestion } from '../corpus/legal_qa_engine';
import type { QaAnswer } from '../corpus/legal_qa_engine';
import { assessLegalRisk, type RiskAssessment } from '../risk/legal_risk_scoring';
import { LANDMARK_CASES_INDEX } from '../corpus/judiciary_law_link';
import { EXTENDED_LANDMARK_CASES } from '../corpus/case_law_extended';
import { SUPPLEMENT_LANDMARK_CASES } from '../corpus/case_law_supplement';

export interface AdvisorTurn {
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  /** assistant ターンに対する関連メタ */
  meta?: {
    intent?: string;
    confidence?: number;
    sources?: string[];
    related_cases?: string[];
  };
}

export interface AdvisorSession {
  session_id: string;
  started_at: string;
  turns: AdvisorTurn[];
  /** セッション全体で蓄積するコンテキスト */
  context: {
    industry?: string;
    customer_type?: 'btob' | 'btoc' | 'btogov';
    international?: boolean;
    detected_topics: string[];
  };
}

export class LegalAdvisor {
  private session: AdvisorSession;

  constructor(opts: { sessionId?: string; industry?: string } = {}) {
    this.session = {
      session_id: opts.sessionId ?? `advisor_${Date.now()}`,
      started_at: new Date().toISOString(),
      turns: [],
      context: { detected_topics: [], industry: opts.industry },
    };
  }

  /** ユーザー質問を受け、AI 回答を生成する */
  ask(userMessage: string): AdvisorTurn {
    this.session.turns.push({
      role: 'user',
      content: userMessage,
      timestamp: new Date().toISOString(),
    });

    const ans = answerLegalQuestion(userMessage);
    this.captureContext(userMessage, ans);
    const assistantContent = this.formatAnswer(ans);
    const turn: AdvisorTurn = {
      role: 'assistant',
      content: assistantContent,
      timestamp: new Date().toISOString(),
      meta: {
        intent: ans.query.intent,
        confidence: ans.confidence,
        sources: ans.sources,
        related_cases: (ans.cases ?? []).map((c) => c.case_id),
      },
    };
    this.session.turns.push(turn);
    return turn;
  }

  /**
   * シナリオ分析 (自然言語シナリオ → リスク評価)
   */
  analyzeScenario(scenario: string, industry?: string): {
    qa: QaAnswer;
    risk: RiskAssessment;
    related_cases: number;
    advisor_summary: string;
  } {
    const qa = answerLegalQuestion(scenario);
    const risk = assessLegalRisk({
      scenario,
      industry: industry ?? this.session.context.industry ?? 'IT',
      customer_type: this.session.context.customer_type,
      international: this.session.context.international,
      pii_volume: this.detectPiiVolumeFromText(scenario),
    });
    const relatedCases = this.findRelatedCases(scenario);
    const lines: string[] = [];
    lines.push(`### シナリオ分析: ${scenario.slice(0, 50)}...`);
    lines.push('');
    lines.push(`**法務 QA 信頼度**: ${qa.confidence}/100`);
    lines.push(`**リスクレベル**: ${risk.level.toUpperCase()} (総合 ${risk.overall_score}/100)`);
    lines.push(`**関連判例**: ${relatedCases.length} 件`);
    lines.push('');
    lines.push('**最優先アクション**:');
    for (const r of risk.recommendations.slice(0, 3)) lines.push(`- ${r}`);
    if (qa.summary) {
      lines.push('');
      lines.push(`**回答**: ${qa.summary}`);
    }
    return {
      qa,
      risk,
      related_cases: relatedCases.length,
      advisor_summary: lines.join('\n'),
    };
  }

  private detectPiiVolumeFromText(text: string): number {
    const m = text.match(/(\d+)\s*[万件人名]/);
    if (!m) return 0;
    const n = parseInt(m[1], 10);
    return text.includes('万') ? n * 10000 : n;
  }

  private findRelatedCases(query: string): string[] {
    const all = [...LANDMARK_CASES_INDEX, ...EXTENDED_LANDMARK_CASES, ...SUPPLEMENT_LANDMARK_CASES];
    const lower = query.toLowerCase();
    return all
      .filter((c) =>
        c.short_name.toLowerCase().includes(lower)
        || (c.summary ?? '').toLowerCase().includes(lower)
        || c.related_laws.some((l) => l.toLowerCase().includes(lower)),
      )
      .map((c) => c.case_id);
  }

  private captureContext(userMessage: string, ans: QaAnswer): void {
    const detect = (kw: string[], target: keyof AdvisorSession['context']) => {
      for (const k of kw) {
        if (userMessage.includes(k)) {
          this.session.context.detected_topics.push(k);
          break;
        }
      }
    };
    detect(['医療', '介護', '金融', '公共', 'IT', '建設', '不動産'], 'industry');
    if (userMessage.match(/消費者|個人|BtoC/i)) this.session.context.customer_type = 'btoc';
    if (userMessage.match(/法人|企業間|BtoB/i)) this.session.context.customer_type = 'btob';
    if (userMessage.match(/海外|国際|GDPR|EU|米国/i)) this.session.context.international = true;
    if (ans.query.law_name) this.session.context.detected_topics.push(ans.query.law_name);
  }

  private formatAnswer(ans: QaAnswer): string {
    const lines: string[] = [];
    if (ans.summary) {
      lines.push(ans.summary);
    } else {
      lines.push('該当する条文・判例が見つかりませんでした。質問を具体化してください。');
    }
    if (ans.cases?.length) {
      lines.push('');
      lines.push(`関連判例 (${ans.cases.length}件):`);
      for (const c of ans.cases.slice(0, 3)) {
        lines.push(`- ${c.short_name} (${c.citation})`);
      }
    }
    if (ans.amendments?.length) {
      lines.push('');
      lines.push('直近改正:');
      for (const a of ans.amendments.slice(0, 3)) {
        lines.push(`- ${a.date}: ${a.summary}`);
      }
    }
    if (ans.related?.length) {
      lines.push('');
      lines.push('関連条文:');
      for (const r of ans.related.slice(0, 3)) {
        lines.push(`- ${r.short_name}: ${r.reason}`);
      }
    }
    lines.push('');
    lines.push(`> 信頼度: ${ans.confidence}/100`);
    lines.push(`> 出典: ${ans.sources.join(', ')}`);
    lines.push('> ※ 本回答は一般情報であり、法的助言ではありません。重要事案は弁護士にご相談ください。');
    return lines.join('\n');
  }

  getSession(): AdvisorSession {
    return this.session;
  }

  exportTranscript(): string {
    const lines: string[] = [];
    lines.push(`# 法務 Advisor セッション ${this.session.session_id}`);
    lines.push(`開始: ${this.session.started_at}`);
    lines.push('');
    for (const t of this.session.turns) {
      lines.push(`## [${t.role}] ${t.timestamp}`);
      lines.push(t.content);
      if (t.meta) {
        lines.push('');
        lines.push(`*intent=${t.meta.intent} / confidence=${t.meta.confidence}*`);
      }
      lines.push('');
    }
    return lines.join('\n');
  }
}

/** ファクトリ */
export function createLegalAdvisor(opts?: { sessionId?: string; industry?: string }): LegalAdvisor {
  return new LegalAdvisor(opts);
}
