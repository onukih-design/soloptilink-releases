/**
 * Phase 46-LU-7 / Certification Program
 *
 * SoloptiLinkAI Legal 認定資格制度。
 * 開発者・SIer・法律事務所スタッフ向けの 3 階層認定:
 *
 *  - Associate: SoloptiLinkAI Legal を基礎レベルで使える (Web試験 20問)
 *  - Professional: API/SDK 使った組込み開発ができる (実装課題 + 試験 50問)
 *  - Expert: 業種固有規制の応用 + 専門家連携設計 (試験 + 面接)
 */

export type CertificationLevel = 'associate' | 'professional' | 'expert';

export type CertificationTrack =
  | 'developer'       // 開発者向け
  | 'legal_admin'     // 法務担当者向け
  | 'sier_consultant' // SIer コンサル向け
  | 'compliance_officer'; // 監査/コンプラ担当向け

export interface CertificationSpec {
  level: CertificationLevel;
  track: CertificationTrack;
  display_name: string;
  prerequisites: string[];
  /** 試験形式 */
  exam_format: {
    multiple_choice: number;
    practical_task: boolean;
    interview: boolean;
    duration_minutes: number;
    passing_score_pct: number;
  };
  /** 有効期間 (年) */
  validity_years: number;
  /** 受験料 (円) */
  exam_fee_jpy: number;
  /** 関連 Phase 46-LU モジュール */
  exam_topics: string[];
}

export const CERTIFICATIONS: CertificationSpec[] = [
  {
    level: 'associate',
    track: 'developer',
    display_name: 'SoloptiLinkAI Legal Developer Associate',
    prerequisites: [],
    exam_format: { multiple_choice: 30, practical_task: false, interview: false, duration_minutes: 60, passing_score_pct: 70 },
    validity_years: 2,
    exam_fee_jpy: 16500,
    exam_topics: ['plans_catalog', 'legal_api_endpoints', 'plan_quota', 'legal_rag', 'compliance_scanner'],
  },
  {
    level: 'professional',
    track: 'developer',
    display_name: 'SoloptiLinkAI Legal Developer Professional',
    prerequisites: ['Associate Developer'],
    exam_format: { multiple_choice: 50, practical_task: true, interview: false, duration_minutes: 180, passing_score_pct: 75 },
    validity_years: 2,
    exam_fee_jpy: 49500,
    exam_fee_jpy_renewal: 16500 as never, // optional ignored
    exam_topics: ['embedding_index', 'llm_prompt_builder', 'omega_legal_bridge', 'webhook', 'mobile_sdk', 'plugin_system'],
  } as CertificationSpec,
  {
    level: 'expert',
    track: 'developer',
    display_name: 'SoloptiLinkAI Legal Developer Expert',
    prerequisites: ['Professional Developer', '実務2年以上'],
    exam_format: { multiple_choice: 50, practical_task: true, interview: true, duration_minutes: 240, passing_score_pct: 80 },
    validity_years: 3,
    exam_fee_jpy: 99000,
    exam_topics: ['custom_compliance_rules', 'multi_tenant', 'incident_response', 'observability', 'amendment_predictor', '業種固有規制 (医療/金融/公共)'],
  },

  {
    level: 'associate',
    track: 'legal_admin',
    display_name: 'SoloptiLinkAI Legal Administrator Associate',
    prerequisites: [],
    exam_format: { multiple_choice: 20, practical_task: false, interview: false, duration_minutes: 40, passing_score_pct: 70 },
    validity_years: 2,
    exam_fee_jpy: 11000,
    exam_topics: ['UI 利用', '判例検索', '契約書生成', 'エクスポート'],
  },
  {
    level: 'professional',
    track: 'legal_admin',
    display_name: 'SoloptiLinkAI Legal Administrator Professional',
    prerequisites: ['Associate Legal Admin'],
    exam_format: { multiple_choice: 40, practical_task: true, interview: false, duration_minutes: 120, passing_score_pct: 75 },
    validity_years: 2,
    exam_fee_jpy: 33000,
    exam_topics: ['Tenant DNA', 'Compliance Officer 機能', 'リスク評価', '改正対応運用'],
  },

  {
    level: 'expert',
    track: 'sier_consultant',
    display_name: 'SoloptiLinkAI Legal SIer Consultant Expert',
    prerequisites: ['SI 実務5年以上'],
    exam_format: { multiple_choice: 60, practical_task: true, interview: true, duration_minutes: 300, passing_score_pct: 80 },
    validity_years: 3,
    exam_fee_jpy: 165000,
    exam_topics: ['提案設計', '契約設計', 'マルチテナント設計', 'コンプライアンス監査', '業種別NFR (Phase 47 SIEL 連携)'],
  },

  {
    level: 'expert',
    track: 'compliance_officer',
    display_name: 'SoloptiLinkAI Legal Compliance Officer Expert',
    prerequisites: ['監査/法務実務5年以上', 'CISA/CIA/CPA いずれか'],
    exam_format: { multiple_choice: 60, practical_task: true, interview: true, duration_minutes: 300, passing_score_pct: 85 },
    validity_years: 3,
    exam_fee_jpy: 198000,
    exam_topics: ['GDPR Art.30', 'J-SOX ITGC', 'Attorney-Client Privilege', 'インシデント対応', '監査ログ運用'],
  },
];

export interface Certificate {
  certificate_id: string;
  candidate_id: string;
  certification: CertificationSpec;
  issued_at: string;
  expires_at: string;
  score_pct: number;
  status: 'valid' | 'expired' | 'revoked';
  /** 発行コード (QR/検証用) */
  verification_code: string;
}

const CERTIFICATES = new Map<string, Certificate>();

export function issueCertificate(input: {
  candidate_id: string;
  level: CertificationLevel;
  track: CertificationTrack;
  score_pct: number;
}): { ok: true; certificate: Certificate } | { ok: false; error: string } {
  const cert = CERTIFICATIONS.find((c) => c.level === input.level && c.track === input.track);
  if (!cert) return { ok: false, error: 'certification spec not found' };
  if (input.score_pct < cert.exam_format.passing_score_pct) {
    return { ok: false, error: `score ${input.score_pct} < passing ${cert.exam_format.passing_score_pct}%` };
  }
  const issuedAt = new Date();
  const expiresAt = new Date(issuedAt);
  expiresAt.setFullYear(expiresAt.getFullYear() + cert.validity_years);
  const certificate: Certificate = {
    certificate_id: `cert_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    candidate_id: input.candidate_id,
    certification: cert,
    issued_at: issuedAt.toISOString(),
    expires_at: expiresAt.toISOString(),
    score_pct: input.score_pct,
    status: 'valid',
    verification_code: generateVerificationCode(),
  };
  CERTIFICATES.set(certificate.certificate_id, certificate);
  return { ok: true, certificate };
}

function generateVerificationCode(): string {
  return [...crypto.getRandomValues(new Uint8Array(8))]
    .map((b) => b.toString(36).padStart(2, '0').toUpperCase())
    .join('-');
}

export function verifyCertificate(verification_code: string): Certificate | undefined {
  for (const c of CERTIFICATES.values()) {
    if (c.verification_code === verification_code) {
      // 期限チェック
      if (new Date(c.expires_at).getTime() < Date.now()) c.status = 'expired';
      return c;
    }
  }
  return undefined;
}

export function revokeCertificate(certificate_id: string, reason: string): boolean {
  const c = CERTIFICATES.get(certificate_id);
  if (!c) return false;
  c.status = 'revoked';
  return true;
}

export function listCertificationsByLevel(level: CertificationLevel): CertificationSpec[] {
  return CERTIFICATIONS.filter((c) => c.level === level);
}

export function listCertificatesByCandidate(candidate_id: string): Certificate[] {
  return [...CERTIFICATES.values()].filter((c) => c.candidate_id === candidate_id);
}

export function countCertifications(): {
  spec_count: number;
  issued_count: number;
  by_level: Record<string, number>;
  by_status: Record<string, number>;
} {
  const byLevel: Record<string, number> = { associate: 0, professional: 0, expert: 0 };
  const byStatus: Record<string, number> = { valid: 0, expired: 0, revoked: 0 };
  for (const c of CERTIFICATES.values()) {
    byLevel[c.certification.level]++;
    byStatus[c.status]++;
  }
  return {
    spec_count: CERTIFICATIONS.length,
    issued_count: CERTIFICATES.size,
    by_level: byLevel,
    by_status: byStatus,
  };
}

export function _resetCertificationsForTests(): void {
  CERTIFICATES.clear();
}
