/**
 * Phase 46-LU-3 / Gap Recommendations
 *
 * 「次に追加すべき法令・判例」を ML 不要のルールベースで推薦する。
 *  - 業種 (Tenant DNA) との関連度
 *  - 既存ドメインのカバレッジ不足度
 *  - 最近の改正活動度 (LawCatalog の lastEffectiveDate)
 */

import { LANDMARK_CASES_INDEX } from '../corpus/judiciary_law_link';
import { EXTENDED_LAW_CATALOG } from '../catalog_full';
import type { GapDomain } from './knowledge_gap_analyzer';
import { analyzeKnowledgeGaps } from './knowledge_gap_analyzer';

export interface GapRecommendation {
  kind: 'case' | 'catalog' | 'supplementary' | 'penalty_table' | 'article_summary';
  domain: GapDomain;
  /** 追加候補の名前 (法令名/判例名) */
  candidate_name: string;
  /** 重要度 (0-100) */
  priority: number;
  /** 推薦理由 */
  reasoning: string[];
}

/**
 * 重要だが未収録の主要判例リスト (拡張候補)
 */
const KNOWN_CANDIDATE_CASES: Array<{
  case_id: string;
  short_name: string;
  domain: GapDomain;
  priority: number;
}> = [
  // 憲法
  { case_id: 'macnan_S53', short_name: 'マクリーン事件 (再掲)', domain: 'constitution', priority: 80 },
  { case_id: 'kobayashi_S55', short_name: '小林勝事件 (法廷メモ事件)', domain: 'constitution', priority: 60 },
  // 民法
  { case_id: 'mortgage_S39', short_name: '抵当権 物上代位 (最判S39)', domain: 'civil', priority: 75 },
  { case_id: 'inheritance_R元', short_name: '配偶者居住権 (R元)', domain: 'civil', priority: 70 },
  // 商事
  { case_id: 'spc_treaty_H26', short_name: '社外取締役 (H26改正)', domain: 'commercial', priority: 65 },
  // 知財
  { case_id: 'genova_H25', short_name: 'ジェネリック医薬品事件', domain: 'ip', priority: 65 },
  { case_id: 'asahi_pen_H22', short_name: '朝日新聞 著作物性事件', domain: 'ip', priority: 60 },
  // 労働
  { case_id: 'metro_commerce_H30', short_name: 'メトロコマース事件 (退職金)', domain: 'labor', priority: 75 },
  // 税務
  { case_id: 'asat_R5', short_name: 'ASAT 暗号資産課税', domain: 'tax', priority: 70 },
];

/**
 * 重要だが未収録の法令リスト (拡張候補)
 */
const KNOWN_CANDIDATE_LAWS: Array<{
  short_name: string;
  domain: GapDomain;
  priority: number;
}> = [
  { short_name: '裁判所法', domain: 'civil_procedure', priority: 60 },
  { short_name: '弁護士法', domain: 'civil_procedure', priority: 55 },
  { short_name: '司法書士法', domain: 'civil_procedure', priority: 50 },
  { short_name: '少年法', domain: 'criminal', priority: 70 },
  { short_name: '組織犯罪処罰法', domain: 'special_criminal', priority: 75 },
  { short_name: '犯罪収益移転防止法', domain: 'finance', priority: 80 },
  { short_name: '行政機関個人情報保護法 統合済', domain: 'cybersecurity', priority: 60 },
  { short_name: '官公需法 (中小企業者に関する官公需確保)', domain: 'administrative', priority: 50 },
  { short_name: '国税徴収法', domain: 'tax', priority: 70 },
  { short_name: '租税特別措置法', domain: 'tax', priority: 75 },
  { short_name: '相続税法施行令', domain: 'tax', priority: 60 },
  { short_name: '会社更生法施行規則', domain: 'insolvency', priority: 55 },
];

export function recommendGaps(opts: { maxItems?: number } = {}): GapRecommendation[] {
  const max = opts.maxItems ?? 20;
  const gap = analyzeKnowledgeGaps();
  const out: GapRecommendation[] = [];

  // 1) 各ドメインで missing/partial なものから推薦
  const sortedDomains = [...gap.domains].sort((a, b) => {
    const aw = a.status === 'missing' ? 2 : a.status === 'partial' ? 1 : 0;
    const bw = b.status === 'missing' ? 2 : b.status === 'partial' ? 1 : 0;
    return bw - aw;
  });

  for (const d of sortedDomains) {
    if (d.status === 'complete') continue;
    // 判例不足ならば候補判例を推薦
    const caseCandidates = KNOWN_CANDIDATE_CASES.filter(
      (c) => c.domain === d.domain && !LANDMARK_CASES_INDEX.some((idx) => idx.case_id === c.case_id),
    );
    for (const c of caseCandidates.slice(0, 3)) {
      out.push({
        kind: 'case',
        domain: d.domain,
        candidate_name: c.short_name,
        priority: c.priority,
        reasoning: [`${d.domain} ドメインの判例数 ${d.case_count} 件 (target ${10})`, `重要度: ${c.priority}/100`],
      });
    }
    // 法令不足
    const lawCandidates = KNOWN_CANDIDATE_LAWS.filter((l) => l.domain === d.domain);
    for (const l of lawCandidates.slice(0, 2)) {
      const exists = EXTENDED_LAW_CATALOG.some((e) => e.shortName === l.short_name);
      if (exists) continue;
      out.push({
        kind: 'catalog',
        domain: d.domain,
        candidate_name: l.short_name,
        priority: l.priority,
        reasoning: [`${d.domain} ドメインの法令カタログ ${d.catalog_count} 件 (target ${5})`, `重要度: ${l.priority}/100`],
      });
    }
  }

  // priority 降順でソート
  out.sort((a, b) => b.priority - a.priority);
  return out.slice(0, max);
}

/**
 * 推薦結果を Markdown レポートに変換
 */
export function renderRecommendationsMarkdown(recommendations: GapRecommendation[]): string {
  const lines: string[] = [];
  lines.push('# 推奨追加項目 (Phase 46-LU-3 Gap Recommendations)');
  lines.push('');
  if (recommendations.length === 0) {
    lines.push('追加項目はありません (網羅性 OK)。');
    return lines.join('\n');
  }
  lines.push(`総推薦数: ${recommendations.length}`);
  lines.push('');
  for (const r of recommendations) {
    lines.push(`## [${r.kind}] ${r.candidate_name} (priority=${r.priority})`);
    lines.push(`- ドメイン: ${r.domain}`);
    lines.push('- 理由:');
    for (const re of r.reasoning) lines.push(`  - ${re}`);
    lines.push('');
  }
  return lines.join('\n');
}
