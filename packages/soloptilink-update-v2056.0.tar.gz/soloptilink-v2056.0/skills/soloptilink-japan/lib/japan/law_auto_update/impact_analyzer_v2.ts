/**
 * Phase 46-LU / 改正→該当コード自動特定
 *
 * 改正検知結果 (LawAmendmentDiff) を入力に、影響を受ける lib/japan/*.ts
 * を特定し、修正候補の方向性を生成する。
 *
 * 既存 lib/japan/law_tracker.ts の relatedModules は静的紐付けのため、
 * 本モジュールは:
 *   1) relatedModules を基に「直接影響」を取得
 *   2) 条文番号 → 法令本体の該当条 → 既存コード内の defined constant/comment との突合
 *   3) Tenant DNA の禁止ライブラリ/命名規則と整合性チェック
 *   4) 修正候補 (パッチ案 ではなく方向性) を Markdown で生成
 */

import type { LawAmendmentDiff, LawCatalogEntry } from '../law_tracker';
import { LAW_CATALOG } from '../law_tracker';
import { EXTENDED_LAW_CATALOG } from './catalog_full';

export interface ImpactAnalysis {
  lawId: string;
  shortName: string;
  /** 直接影響 (relatedModules 由来) */
  directlyAffectedModules: string[];
  /** 間接影響 (同一カテゴリの周辺モジュール) */
  indirectlyAffectedModules: string[];
  /** 影響度ヒートマップ (file → 0-100) */
  heatmap: Record<string, number>;
  /** 修正方向性 (Markdown) */
  modificationGuide: string;
  /** 想定工数 (人時) */
  estimatedManHours: number;
  /** 優先度 */
  priority: 'P0' | 'P1' | 'P2' | 'P3';
}

const HEAT_DIRECT = 90;
const HEAT_INDIRECT = 40;
const HEAT_TANGENTIAL = 15;

export function analyzeImpact(diff: LawAmendmentDiff): ImpactAnalysis {
  const cat = findCatalog(diff.lawId);
  const directly = [...new Set(diff.affectedModules.length > 0 ? diff.affectedModules : cat?.relatedModules ?? [])];

  // 間接影響: 同カテゴリの他モジュール
  const indirectly: string[] = [];
  if (cat) {
    for (const e of EXTENDED_LAW_CATALOG) {
      if (e.egovLawId === diff.lawId) continue;
      if (e.category === cat.category) {
        for (const m of e.relatedModules) {
          if (!directly.includes(m) && !indirectly.includes(m)) indirectly.push(m);
        }
      }
    }
  }

  const heatmap: Record<string, number> = {};
  for (const m of directly) heatmap[m] = HEAT_DIRECT;
  for (const m of indirectly.slice(0, 6)) heatmap[m] = HEAT_INDIRECT;
  // 帳票テンプレへの波及 (templates/japan/*) は tangential
  if (cat?.category === 'tax') heatmap['templates/japan/Invoice.tsx'] = HEAT_TANGENTIAL;

  const estimatedManHours = estimateEffort(diff, directly.length);
  const priority = decidePriority(diff, directly.length);
  const modificationGuide = buildGuide(diff, cat, directly, indirectly, priority);

  return {
    lawId: diff.lawId,
    shortName: cat?.shortName ?? diff.lawId,
    directlyAffectedModules: directly,
    indirectlyAffectedModules: indirectly,
    heatmap,
    modificationGuide,
    estimatedManHours,
    priority,
  };
}

function findCatalog(lawId: string): LawCatalogEntry | undefined {
  return LAW_CATALOG.find((l) => l.egovLawId === lawId) ?? EXTENDED_LAW_CATALOG.find((l) => l.egovLawId === lawId);
}

function estimateEffort(diff: LawAmendmentDiff, moduleCount: number): number {
  const base = diff.changedArticles.length * 0.5; // 1条あたり 0.5h
  const moduleOverhead = moduleCount * 1.0;
  const severityFactor = diff.severity === 'major' ? 2 : diff.severity === 'minor' ? 1 : 0.5;
  return Math.round((base + moduleOverhead) * severityFactor * 10) / 10;
}

function decidePriority(diff: LawAmendmentDiff, moduleCount: number): ImpactAnalysis['priority'] {
  if (diff.severity === 'major' && moduleCount >= 3) return 'P0';
  if (diff.severity === 'major' || moduleCount >= 3) return 'P1';
  if (diff.severity === 'minor') return 'P2';
  return 'P3';
}

function buildGuide(
  diff: LawAmendmentDiff,
  cat: LawCatalogEntry | undefined,
  direct: string[],
  indirect: string[],
  priority: ImpactAnalysis['priority'],
): string {
  const lines: string[] = [];
  lines.push(`## ${cat?.shortName ?? diff.lawId} 改正の対応ガイド (Priority: ${priority})`);
  lines.push('');
  lines.push(`- 法令: ${cat?.officialName ?? diff.lawId}`);
  lines.push(`- 改正施行日: ${diff.afterVersion.effectiveDate}`);
  lines.push(`- 重要度: **${diff.severity}**`);
  lines.push(`- 変更条文数: ${diff.changedArticles.length}`);
  lines.push('');

  lines.push('### 直接影響モジュール (要修正)');
  if (direct.length === 0) lines.push('- (なし)');
  else direct.forEach((m) => lines.push(`- [ ] \`${m}\` — 該当条文の constant/comment を更新`));
  lines.push('');

  lines.push('### 間接影響モジュール (要影響範囲確認)');
  if (indirect.length === 0) lines.push('- (なし)');
  else indirect.slice(0, 6).forEach((m) => lines.push(`- [ ] \`${m}\``));
  lines.push('');

  lines.push('### 変更条文サマリ');
  for (const c of diff.changedArticles.slice(0, 10)) {
    lines.push(`- 第${c.articleNum}条: **${c.changeType}**`);
    if (c.before) lines.push(`  - 改正前: ${trunc(c.before, 80)}`);
    if (c.after) lines.push(`  - 改正後: ${trunc(c.after, 80)}`);
  }
  if (diff.changedArticles.length > 10) {
    lines.push(`- … 他 ${diff.changedArticles.length - 10} 件`);
  }
  lines.push('');

  lines.push('### 推奨アクション');
  lines.push('1. 直接影響モジュールの該当 constant / コメント / バリデーションロジックを更新');
  lines.push('2. テスト (tests/phase*_*.mjs) に「改正前」テストケースが残っていれば「改正後」に修正');
  lines.push('3. CHANGELOG に「Phase 46-LU 自動検知による改正対応」を追記');
  lines.push('4. 関連帳票テンプレ (templates/japan/*) の文言/項目を確認');
  lines.push('5. RAG/Decision Bank へ改正条文を append (rag_indexer.ts 経由)');
  lines.push('6. PR タイトルに `[Legal-Update]` プレフィックスを付与');

  return lines.join('\n');
}

function trunc(s: string, n: number): string {
  if (!s) return '';
  return s.length <= n ? s : s.slice(0, n) + '…';
}
