/**
 * Phase 46-LU-3 / Knowledge Completeness Dashboard
 *
 * Phase 46-LU + 46-LU-2 + 46-LU-3 の全モジュールを統合し、
 * 「現在の知識網羅性」を一画面で可視化する。
 *
 *  - Tier × ドメイン マトリックス
 *  - 判例カバレッジ
 *  - 法令カタログ規模
 *  - 補完法令 / 特別刑法 / 国際法 / 時効計算 のロード状況
 *  - 残ギャップと推奨アクション
 */

import { analyzeKnowledgeGaps, renderGapReport } from './gap_analysis/knowledge_gap_analyzer';
import { buildCoverageMatrix, renderMatrixAsAscii } from './gap_analysis/coverage_matrix';
import { renderDashboard } from './learning_dashboard';
import { buildInitialCorpus } from './corpus/legal_corpus';
import { countCasesByCategory, LANDMARK_CASES_INDEX } from './corpus/judiciary_law_link';
import { countSupplementaryCodes } from './corpus/supplementary_codes';
import { countSpecialCriminalLaws } from './corpus/special_criminal_law';
import { countTreaties } from './corpus/international_law';
import { listAllClaimKinds } from './lawful_tools/time_limit_calculator';

export interface CompletenessSnapshot {
  generated_at: string;
  six_codes_articles: number;
  cases_total: number;
  cases_by_category: Record<string, number>;
  supplementary_codes: number;
  special_criminal_laws: number;
  international_treaties: number;
  time_limit_claims: number;
  catalog_total: number;
  completeness_pct: number;
  diamond_distance_total_items: number;
}

export function buildCompletenessSnapshot(): CompletenessSnapshot {
  const gap = analyzeKnowledgeGaps();
  const supp = countSupplementaryCodes();
  const sclaw = countSpecialCriminalLaws();
  const treaties = countTreaties();
  const claims = listAllClaimKinds();
  return {
    generated_at: new Date().toISOString(),
    six_codes_articles: gap.overall.six_codes_loaded,
    cases_total: gap.overall.cases_loaded,
    cases_by_category: countCasesByCategory(),
    supplementary_codes: supp.total,
    special_criminal_laws: sclaw.total,
    international_treaties: treaties.total,
    time_limit_claims: claims.length,
    catalog_total: gap.overall.catalog_loaded,
    completeness_pct: gap.completeness_pct,
    diamond_distance_total_items:
      gap.diamond_distance.cases_needed +
      gap.diamond_distance.catalog_needed +
      gap.diamond_distance.supplementary_needed,
  };
}

/**
 * 統合ダッシュボード (ASCII)
 */
export function renderCompletenessDashboard(): string {
  const lines: string[] = [];
  const corpus = buildInitialCorpus();

  lines.push('');
  lines.push('████████████████████████████████████████████████████████████████');
  lines.push('███  SoloptiLinkAI Phase 46-LU-3                            ███');
  lines.push('███  Knowledge Completeness Dashboard                       ███');
  lines.push('████████████████████████████████████████████████████████████████');
  lines.push('');

  // 1. レガシー Phase 46-LU-2 ダッシュボード (Corpus + RL)
  lines.push(renderDashboard({ corpus }));
  lines.push('');

  // 2. Knowledge Gap レポート
  const gap = analyzeKnowledgeGaps();
  lines.push(renderGapReport(gap));
  lines.push('');

  // 3. Coverage Matrix
  const matrix = buildCoverageMatrix();
  lines.push(renderMatrixAsAscii(matrix));
  lines.push('');

  // 4. Phase 46-LU-3 新規モジュール統計
  const snapshot = buildCompletenessSnapshot();
  lines.push('======================================================');
  lines.push('  Phase 46-LU-3 補完モジュール ロード状況');
  lines.push('======================================================');
  lines.push(`  判例総数 (LANDMARK_CASES)        : ${snapshot.cases_total}`);
  lines.push('  カテゴリ別判例:');
  for (const c of Object.keys(snapshot.cases_by_category)) {
    lines.push(`    ${c.padEnd(18)}: ${snapshot.cases_by_category[c]}`);
  }
  lines.push(`  補完法令 (行政/倒産/特別民法/私法): ${snapshot.supplementary_codes}`);
  lines.push(`  特別刑法 (道交/銃刀/麻取/DV 等)  : ${snapshot.special_criminal_laws}`);
  lines.push(`  国際法・条約                       : ${snapshot.international_treaties}`);
  lines.push(`  時効・期間計算カテゴリ              : ${snapshot.time_limit_claims}`);
  lines.push('');
  lines.push(`  完成度: ${snapshot.completeness_pct}%`);
  lines.push(`  Diamond までの追加項目: ${snapshot.diamond_distance_total_items}`);
  lines.push('======================================================');
  lines.push('');

  return lines.join('\n');
}

/**
 * JSON サマリ (CI/監視向け)
 */
export function summarizeCompletenessAsJson() {
  const snapshot = buildCompletenessSnapshot();
  const gap = analyzeKnowledgeGaps();
  const matrix = buildCoverageMatrix();
  return {
    ...snapshot,
    gap_count: gap.gap_count,
    top_recommendations: gap.top_recommendations,
    matrix_cells: matrix.cells.length,
    matrix_complete_cells: matrix.cells.filter((c) => c.status === 'complete').length,
  };
}
