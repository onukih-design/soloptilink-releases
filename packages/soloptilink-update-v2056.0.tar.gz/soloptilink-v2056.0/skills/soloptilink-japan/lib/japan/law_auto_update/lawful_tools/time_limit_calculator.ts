/**
 * Phase 46-LU-3 / 時効・期間計算統合エンジン
 *
 * 民法 R2.4 改正後の時効体系 + 商事 + 特別法 + 行政手続の時効・期間を統合計算する。
 *
 *  - 民法 166: 主観 5 年 / 客観 10 年
 *  - 民法 167: 人の生命身体の侵害 → 20 年/5年
 *  - 民法 724: 不法行為 主観 3 年 / 客観 20 年
 *  - 民法 724の2: 人の生命身体の不法行為 主観 5 年
 *  - 商事消滅時効: 民法に統合 (旧商法 522 削除)
 *  - 製造物責任 5 条: 主観 3 年 / 引渡 10 年
 *  - 消費者契約 7 条: 取消権 主観 1 年 / 行為時 5 年
 *  - 国家賠償 4 条: 民法準用
 *  - 行政事件訴訟 14 条: 取消訴訟 主観 6 ヶ月 / 客観 1 年
 *  - 行政不服審査 18 条: 知った日から 3 ヶ月
 *  - 労基法 115: 賃金 5 年 (経過措置で当面3年)
 *  - 労災保険 12 条の8: 給付請求 2 年/5 年
 *  - 相続放棄 915: 知った時から 3 ヶ月
 *  - 遺留分 1048: 知った時から 1 年 / 開始から 10 年
 */

export type ClaimKind =
  | 'civil_general' // 一般債権 民法166
  | 'civil_life_body' // 生命身体 民法167
  | 'tort_general' // 不法行為一般 民法724
  | 'tort_life_body' // 生命身体不法行為 民法724の2
  | 'pl_claim' // 製造物責任 PL5
  | 'consumer_revoke' // 消費者契約取消 消契7
  | 'admin_litigation' // 行政事件訴訟 行訴14
  | 'admin_review' // 行政不服審査 行審18
  | 'labor_wage' // 賃金 労基115
  | 'workers_comp' // 労災 労災12の8
  | 'inheritance_renounce' // 相続放棄 民法915
  | 'forced_share' // 遺留分 民法1048
  | 'criminal_general' // 刑訴 公訴時効
  | 'tax_assessment'; // 税務 国税通則70

export interface TimeLimitResult {
  kind: ClaimKind;
  /** 主観的起算点からの期間 (日) */
  subjective_days?: number;
  /** 客観的起算点からの期間 (日) */
  objective_days?: number;
  /** 主観的起算点 (法令上の表現) */
  subjective_trigger: string;
  /** 客観的起算点 (法令上の表現) */
  objective_trigger: string;
  /** 関連法令条文 */
  related_articles: string[];
  /** 注釈 */
  notes?: string;
  /** 計算結果: 経過日数 から見た残日数 */
  remaining_days?: { from_subjective?: number; from_objective?: number };
}

const TABLE: Record<ClaimKind, Omit<TimeLimitResult, 'remaining_days'>> = {
  civil_general: {
    kind: 'civil_general',
    subjective_days: 5 * 365,
    objective_days: 10 * 365,
    subjective_trigger: '権利行使できることを知った時',
    objective_trigger: '権利行使できる時',
    related_articles: ['民法第166条第1項'],
    notes: 'R2.4 改正で「短期消滅時効」廃止 → 5/10 年統一',
  },
  civil_life_body: {
    kind: 'civil_life_body',
    subjective_days: 5 * 365,
    objective_days: 20 * 365,
    subjective_trigger: '権利行使できることを知った時',
    objective_trigger: '権利行使できる時',
    related_articles: ['民法第167条'],
    notes: '人の生命又は身体侵害の場合の特則',
  },
  tort_general: {
    kind: 'tort_general',
    subjective_days: 3 * 365,
    objective_days: 20 * 365,
    subjective_trigger: '損害及び加害者を知った時',
    objective_trigger: '不法行為時',
    related_articles: ['民法第724条'],
    notes: '原則 3/20 年',
  },
  tort_life_body: {
    kind: 'tort_life_body',
    subjective_days: 5 * 365,
    objective_days: 20 * 365,
    subjective_trigger: '損害及び加害者を知った時',
    objective_trigger: '不法行為時',
    related_articles: ['民法第724条の2'],
    notes: '生命身体の侵害は主観 3 → 5 年に延長 (R2.4)',
  },
  pl_claim: {
    kind: 'pl_claim',
    subjective_days: 3 * 365,
    objective_days: 10 * 365,
    subjective_trigger: '損害及び賠償義務者を知った時',
    objective_trigger: '製造業者等が引き渡した時',
    related_articles: ['製造物責任法第5条'],
    notes: '潜在的損害 (アスベスト等) は損害発生時から起算',
  },
  consumer_revoke: {
    kind: 'consumer_revoke',
    subjective_days: 1 * 365,
    objective_days: 5 * 365,
    subjective_trigger: '追認できる時',
    objective_trigger: '消費者契約締結時',
    related_articles: ['消費者契約法第7条'],
    notes: 'R4 改正で霊感商法等は 3 年/10 年に延長',
  },
  admin_litigation: {
    kind: 'admin_litigation',
    subjective_days: 180,
    objective_days: 365,
    subjective_trigger: '処分があったことを知った日',
    objective_trigger: '処分があった日',
    related_articles: ['行政事件訴訟法第14条'],
    notes: '抗告訴訟の出訴期間',
  },
  admin_review: {
    kind: 'admin_review',
    subjective_days: 90,
    objective_days: 365,
    subjective_trigger: '処分があったことを知った日',
    objective_trigger: '処分があった日',
    related_articles: ['行政不服審査法第18条'],
    notes: '審査請求の期間',
  },
  labor_wage: {
    kind: 'labor_wage',
    subjective_days: 5 * 365,
    objective_days: 5 * 365,
    subjective_trigger: '賃金支払期日',
    objective_trigger: '賃金支払期日',
    related_articles: ['労働基準法第115条'],
    notes: '附則経過措置で当面3年。R7年以降5年に完全移行予定',
  },
  workers_comp: {
    kind: 'workers_comp',
    subjective_days: 2 * 365,
    objective_days: 5 * 365,
    subjective_trigger: '療養補償給付/休業補償給付 → 2 年',
    objective_trigger: '障害補償給付/遺族補償給付 → 5 年',
    related_articles: ['労働者災害補償保険法第42条'],
  },
  inheritance_renounce: {
    kind: 'inheritance_renounce',
    subjective_days: 90,
    objective_days: 90,
    subjective_trigger: '自己のために相続の開始があったことを知った時',
    objective_trigger: '同上',
    related_articles: ['民法第915条第1項'],
    notes: '熟慮期間。家裁での伸長申立可',
  },
  forced_share: {
    kind: 'forced_share',
    subjective_days: 365,
    objective_days: 10 * 365,
    subjective_trigger: '相続開始+遺留分侵害贈与遺贈を知った時',
    objective_trigger: '相続開始時',
    related_articles: ['民法第1048条'],
    notes: '遺留分侵害額請求権 (R元.7.1〜)',
  },
  criminal_general: {
    kind: 'criminal_general',
    subjective_days: 0,
    objective_days: 0,
    subjective_trigger: '犯罪行為終了時',
    objective_trigger: '犯罪行為終了時',
    related_articles: ['刑事訴訟法第250条'],
    notes: '法定刑による (殺人=なし/強盗致死=30年/傷害致死=20年/窃盗=7年 等)',
  },
  tax_assessment: {
    kind: 'tax_assessment',
    subjective_days: 5 * 365,
    objective_days: 7 * 365,
    subjective_trigger: '法定申告期限',
    objective_trigger: '同上 (偽り不正の場合 7 年)',
    related_articles: ['国税通則法第70条'],
    notes: '更正・決定の除斥期間。偽り不正 7 年/移転価格 7 年',
  },
};

/**
 * 時効/期間の計算。日付指定で残日数を返す。
 */
export function calculateTimeLimit(input: {
  kind: ClaimKind;
  /** 主観的起算点 (権利者が知った日 等) */
  subjectiveStartISO?: string;
  /** 客観的起算点 (権利発生日 等) */
  objectiveStartISO?: string;
  /** 評価基準日 (default: 今日) */
  evaluateAtISO?: string;
}): TimeLimitResult {
  const base = TABLE[input.kind];
  if (!base) throw new Error(`Unknown claim kind: ${input.kind}`);

  const evaluateAt = new Date(input.evaluateAtISO ?? new Date().toISOString());
  const result: TimeLimitResult = { ...base, remaining_days: {} };

  if (input.subjectiveStartISO && base.subjective_days !== undefined) {
    const start = new Date(input.subjectiveStartISO);
    const elapsed = Math.floor((evaluateAt.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    result.remaining_days!.from_subjective = base.subjective_days - elapsed;
  }
  if (input.objectiveStartISO && base.objective_days !== undefined) {
    const start = new Date(input.objectiveStartISO);
    const elapsed = Math.floor((evaluateAt.getTime() - start.getTime()) / (1000 * 60 * 60 * 24));
    result.remaining_days!.from_objective = base.objective_days - elapsed;
  }
  return result;
}

/**
 * 時効到来判定
 */
export function isTimeBarred(result: TimeLimitResult): boolean {
  const rd = result.remaining_days;
  if (!rd) return false;
  const subBarred = rd.from_subjective !== undefined && rd.from_subjective < 0;
  const objBarred = rd.from_objective !== undefined && rd.from_objective < 0;
  // 主観・客観どちらかで時効到来していれば消滅
  return subBarred || objBarred;
}

/**
 * 一覧 (UI/ドキュメント用)
 */
export function listAllClaimKinds(): TimeLimitResult[] {
  return Object.values(TABLE).map((t) => ({ ...t }));
}

/**
 * キーワードから候補を抽出
 */
export function findClaimsByKeyword(keyword: string): TimeLimitResult[] {
  const lower = keyword.toLowerCase();
  return Object.values(TABLE).filter((t) =>
    t.related_articles.some((a) => a.toLowerCase().includes(lower))
    || (t.notes ?? '').toLowerCase().includes(lower)
    || t.subjective_trigger.toLowerCase().includes(lower)
    || t.objective_trigger.toLowerCase().includes(lower),
  );
}
