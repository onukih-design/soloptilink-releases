/**
 * Phase 46-LU-2 / Learning Dashboard
 *
 * ASCII ベースの学習進捗ダッシュボード。
 *  - Corpus カバレッジ (Tier S/A/B/C/D × 件数 / 本文学習済%)
 *  - 報酬学習 (episode 数 / 平均報酬 / 重みドリフト)
 *  - 改正検知頻度 (法令別 12ヶ月推移)
 *
 * 出力は CLI 向けの色なし表 (ASCII)。CI ログにもそのまま貼れる。
 */

import { computeCoverage, type CorpusEntry, type LegalTier, ESTIMATED_TOTAL_JAPANESE_LAWS } from './corpus/legal_corpus';
import type { RewardLearner } from './reward/reward_learner';
import { analyzeEpisodes } from './reward/reward_learner';
import type { ChangeLedgerEntry } from './change_detector';

export interface DashboardInput {
  corpus: CorpusEntry[];
  learner?: RewardLearner;
  amendments?: ChangeLedgerEntry[];
}

export function renderDashboard(input: DashboardInput): string {
  const lines: string[] = [];
  lines.push('================================================================');
  lines.push('  SoloptiLinkAI / Phase 46-LU-2 Legal Learning Dashboard');
  lines.push('================================================================');
  lines.push(`  Generated: ${new Date().toISOString()}`);
  lines.push('');

  lines.push('[ Corpus Coverage ]');
  const c = computeCoverage(input.corpus);
  lines.push(`  total registered : ${c.total}`);
  lines.push(`  e-Gov estimated  : ${c.target_total}`);
  lines.push(`  coverage         : ${renderBar(c.coverage_pct, 100, 40)} ${c.coverage_pct}%`);
  lines.push(`  text loaded      : ${renderBar(c.text_loaded_pct, 100, 40)} ${c.text_loaded_pct}% (${c.text_loaded}/${c.total})`);
  lines.push('');
  lines.push('  By Tier:');
  const tiers: LegalTier[] = ['S', 'A', 'B', 'C', 'D'];
  for (const t of tiers) {
    const n = c.by_tier[t];
    lines.push(`    Tier ${t} : ${String(n).padStart(5)}  ${renderBar(n, Math.max(...tiers.map((tt) => c.by_tier[tt])), 30)}`);
  }
  lines.push('');
  lines.push('  By Type:');
  for (const k of Object.keys(c.by_type)) {
    const n = (c.by_type as Record<string, number>)[k];
    lines.push(`    ${k.padEnd(20)} : ${String(n).padStart(5)}`);
  }
  lines.push('');

  if (input.learner) {
    lines.push('[ Reward Learning ]');
    const s = input.learner.getSummary();
    lines.push(`  total episodes     : ${s.episode_count}`);
    lines.push(`  avg reward (100)   : ${s.avg_reward_last_100}`);
    lines.push(`  notify_threshold   : ${s.weights.notify_threshold.toFixed(2)}`);
    lines.push(`  industry_weight    : ${s.weights.industry_match_weight.toFixed(2)}`);
    lines.push(`  module_weight      : ${s.weights.module_match_weight.toFixed(2)}`);
    lines.push(`  severity_critical+ : ${s.weights.severity_critical_boost.toFixed(2)}`);
    lines.push(`  severity_major+    : ${s.weights.severity_major_boost.toFixed(2)}`);
    lines.push('  drift_from_default :');
    for (const k of Object.keys(s.drift_from_default)) {
      const d = s.drift_from_default[k];
      const sign = d >= 0 ? '+' : '';
      lines.push(`    ${k.padEnd(34)} ${sign}${d.toFixed(2)}`);
    }
    lines.push('  tier_weight:');
    for (const t of tiers) {
      lines.push(`    Tier ${t} : ${s.weights.tier_weight[t].toFixed(3)}`);
    }
    const eps = input.learner.exportEpisodes();
    if (eps.length > 0) {
      lines.push('');
      lines.push('  Feedback distribution:');
      const a = analyzeEpisodes(eps);
      for (const k of Object.keys(a.by_feedback)) {
        const n = (a.by_feedback as Record<string, number>)[k];
        lines.push(`    ${k.padEnd(18)} : ${String(n).padStart(5)}`);
      }
      lines.push(`  positive_ratio   : ${a.positive_ratio}%`);
      lines.push(`  total_reward     : ${a.total_reward}`);
    }
    lines.push('');
  }

  if (input.amendments && input.amendments.length > 0) {
    lines.push('[ Amendment Detection (last 12 entries) ]');
    const recent = [...input.amendments].sort((a, b) => b.detectedAt.localeCompare(a.detectedAt)).slice(0, 12);
    for (const a of recent) {
      lines.push(
        `  ${a.detectedAt.slice(0, 10)}  ${a.severity.padEnd(9)}  ${a.shortName.padEnd(20)}  Δarts=${a.changedArticleCount}`,
      );
    }
    lines.push('');
  }

  lines.push('================================================================');
  return lines.join('\n');
}

function renderBar(value: number, max: number, width: number): string {
  if (max <= 0) return '['.padEnd(width + 1) + ']';
  const filled = Math.max(0, Math.min(width, Math.round((value / max) * width)));
  return '[' + '#'.repeat(filled) + '.'.repeat(width - filled) + ']';
}

/**
 * 進捗バー単体取得 (他で再利用可能)
 */
export function renderProgressLine(label: string, value: number, max: number): string {
  return `${label.padEnd(20)} ${renderBar(value, max, 30)} ${value}/${max}`;
}

/**
 * JSON サマリ (CI/監視ツール向け)
 */
export function summarizeAsJson(input: DashboardInput): {
  generated_at: string;
  corpus_total: number;
  corpus_coverage_pct: number;
  reward_avg_last_100?: number;
  amendments_count?: number;
  target_total: number;
} {
  const c = computeCoverage(input.corpus);
  return {
    generated_at: new Date().toISOString(),
    corpus_total: c.total,
    corpus_coverage_pct: c.coverage_pct,
    reward_avg_last_100: input.learner?.movingAverageReward(100),
    amendments_count: input.amendments?.length,
    target_total: ESTIMATED_TOTAL_JAPANESE_LAWS,
  };
}
