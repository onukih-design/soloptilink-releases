/**
 * Phase 46-LU / 官報 (公的引用 専用クライアント)
 *
 * 官報情報検索サービス (https://search.npb.go.jp/) は会員制有料で、
 * スクレイピングは利用規約で禁止されている。本モジュールは:
 *  - 全文取得を行わない (規約遵守)
 *  - 「号番号 / 公布日 / 表題 / 区分(法律/政令/省令/告示)」のメタデータのみを扱う
 *  - 本文引用は短文 (著作権法 32条 引用要件 — 主従明瞭 / 出典明記 / 改変なし) に限定
 *  - 出典は KANPO_ATTRIBUTION で自動付与
 *
 * 取得経路:
 *  - 公開官報 (https://kanpou.npb.go.jp/) の RSS / アーカイブ HTML (規約範囲内)
 *  - 会員サービス (search.npb.go.jp) は ユーザー提供の credential 経由で fetcher を注入
 *
 * 既存 lib/japan/laws.ts と独立。
 */

import type { LawCategory } from '../law_tracker';
import { rateLimited } from './rate_limiter';
import { attachAttribution, KANPO_ATTRIBUTION } from './attribution';

const KANPO_PUBLIC_BASE = 'https://kanpou.npb.go.jp';

export type KanpoNotificationType = 'law' | 'cabinet_order' | 'ministry_ordinance' | 'rule' | 'notice' | 'other';

export interface KanpoEntry {
  /** 号数 (例: '第三百九十二号') */
  issueNumber: string;
  /** 公布日 (YYYY-MM-DD) */
  publicationDate: string;
  /** 公布種別 (本紙/号外) */
  edition: 'main' | 'extra';
  /** 表題 */
  title: string;
  /** 区分 */
  type: KanpoNotificationType;
  /** 主管省庁 (取得可能な場合) */
  competentMinistry?: string;
  /** 関連法令カテゴリ */
  category?: LawCategory;
  /** 短文引用 (著作権法32条範囲内) */
  shortExcerpt?: string;
  /** 出典URL */
  sourceUrl: string;
}

export interface KanpoClientOptions {
  baseUrl?: string;
  fetchImpl?: typeof fetch;
  /** 会員サービスを使う場合の認証付き fetcher (規約遵守はユーザー責任) */
  authenticatedFetcher?: (url: string) => Promise<Response>;
  /** Polite User-Agent */
  userAgent?: string;
  disableRateLimit?: boolean;
}

export class KanpoClient {
  private readonly baseUrl: string;
  private readonly fetchImpl: typeof fetch;
  private readonly authenticatedFetcher?: (url: string) => Promise<Response>;
  private readonly userAgent: string;
  private readonly disableRateLimit: boolean;

  constructor(opts: KanpoClientOptions = {}) {
    this.baseUrl = opts.baseUrl ?? KANPO_PUBLIC_BASE;
    const candidate = opts.fetchImpl ?? (typeof fetch === 'function' ? fetch : undefined);
    if (!candidate) throw new Error('KanpoClient: fetch implementation not available');
    this.fetchImpl = candidate;
    this.authenticatedFetcher = opts.authenticatedFetcher;
    this.userAgent = opts.userAgent ?? 'SoloptiLinkAI-LawAutoUpdate/1.0';
    this.disableRateLimit = opts.disableRateLimit ?? false;
  }

  /**
   * 直近 N 日分の官報メタデータを取得 (公開エリアのみ)。
   * 会員制エリアは authenticatedFetcher 経由でのみ取得可能。
   */
  async listRecentEntries(daysBack: number): Promise<KanpoEntry[]> {
    const exec = async (): Promise<KanpoEntry[]> => {
      const since = new Date();
      since.setDate(since.getDate() - daysBack);
      const url = `${this.baseUrl}/archive`;
      const res = await this.fetchImpl(url, {
        method: 'GET',
        headers: { 'User-Agent': this.userAgent, Accept: 'text/html' },
      });
      if (!res.ok) {
        // 公開アーカイブが存在しない/構造変更時は空配列返却 (フェイルセーフ)
        return [];
      }
      const html = await res.text();
      return this.parsePublicArchiveHtml(html, since);
    };
    if (this.disableRateLimit) return exec();
    return rateLimited('kanpo', exec);
  }

  /**
   * 公開アーカイブHTMLから最低限のメタを抽出。
   * フォーマット変更に強いよう、表題行のみを抽出する。
   */
  parsePublicArchiveHtml(html: string, since: Date): KanpoEntry[] {
    const entries: KanpoEntry[] = [];
    // 厳密な DOM パースを避け、表題と日付の組のみ拾う簡易版
    const reTitle = /<a[^>]+href="(\/\d{4}\/\d{8}\/[^"]+)"[^>]*>([^<]+)<\/a>/g;
    let m: RegExpExecArray | null;
    while ((m = reTitle.exec(html)) !== null) {
      const href = m[1];
      const title = m[2].trim();
      // パスから日付推定: /YYYY/YYYYMMDD/...
      const dateMatch = href.match(/\/(\d{4})\/(\d{8})\//);
      let publicationDate = '';
      if (dateMatch) {
        const ymd = dateMatch[2];
        publicationDate = `${ymd.slice(0, 4)}-${ymd.slice(4, 6)}-${ymd.slice(6, 8)}`;
      }
      if (publicationDate && new Date(publicationDate) < since) continue;
      entries.push({
        issueNumber: '',
        publicationDate,
        edition: href.includes('/extra/') ? 'extra' : 'main',
        title,
        type: this.inferType(title),
        sourceUrl: `${this.baseUrl}${href}`,
      });
    }
    return entries.map((e) => attachAttribution(e, KANPO_ATTRIBUTION) as KanpoEntry);
  }

  private inferType(title: string): KanpoNotificationType {
    if (/法律(?:第|の)/.test(title)) return 'law';
    if (/政令(?:第|の)/.test(title)) return 'cabinet_order';
    if (/省令(?:第|の)/.test(title)) return 'ministry_ordinance';
    if (/規則/.test(title)) return 'rule';
    if (/告示|通知|通達/.test(title)) return 'notice';
    return 'other';
  }

  /**
   * 短文引用の生成 (著作権法32条範囲内 / 最大 200 文字 / 出典必須)。
   * 全文転載防止のため、要件外の入力はエラー。
   */
  buildShortExcerpt(input: { fullText: string; maxChars?: number }): string {
    const max = Math.min(input.maxChars ?? 200, 200);
    if (!input.fullText) return '';
    const cleaned = input.fullText.replace(/\s+/g, ' ').trim();
    return cleaned.length <= max ? cleaned : `${cleaned.slice(0, max)}…`;
  }
}

let _defaultKanpo: KanpoClient | undefined;
export function getDefaultKanpoClient(): KanpoClient {
  if (!_defaultKanpo) _defaultKanpo = new KanpoClient();
  return _defaultKanpo;
}
export function setDefaultKanpoClient(c: KanpoClient): void {
  _defaultKanpo = c;
}
