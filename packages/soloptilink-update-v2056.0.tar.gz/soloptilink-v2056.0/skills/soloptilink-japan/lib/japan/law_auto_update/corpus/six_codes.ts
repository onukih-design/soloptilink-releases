/**
 * Phase 46-LU-2 / 六法全書深層モジュール
 *
 * 「六法全書を全て覚える」というユーザー指示への構造的応答。
 * 全文転載は著作権上行わないが、章節構造+主要条文番号+短い要約+
 * 関連判例ID+改正履歴をすべて構造化して保持する。
 *
 * 本モジュールが提供するもの:
 *  - 六法 (憲法/民法/商法/民訴/刑/刑訴) の章節タイトル
 *  - 主要条文の番号と論点要約
 *  - 直近改正の施行日と要約
 *  - 関連判例 (case_law.ts と双方向リンク)
 *  - 自然言語 QA 用のキーワード索引
 *
 * 全文取得が必要な場合は e-Gov v2 経由で動的に取得する想定 (法令本文の
 * 静的同梱はファイルサイズと改版追従の観点で行わない)。
 */

import tierSCorpus from './tier_s_corpus.json';

export type SixCode =
  | 'constitution'
  | 'civil'
  | 'commercial'
  | 'civil_procedure'
  | 'penal'
  | 'criminal_procedure';

export interface SixCodeChapter {
  num: number;
  title: string;
  articles?: number[];
  articles_range?: string;
  chapters?: string[];
}

export interface SixCodeStructure {
  preamble?: string;
  parts?: Array<{
    num: number;
    title: string;
    articles_range?: string;
    chapters?: string[];
  }>;
  chapters?: SixCodeChapter[];
  note?: string;
}

export interface SixCodeAmendment {
  date: string;
  summary: string;
}

export interface SixCodeEntry {
  code: SixCode;
  short_name: string;
  official_name: string;
  promulgation_date: string;
  effective_date: string;
  last_revision_effective?: string;
  structure: SixCodeStructure;
  key_articles_summary: Record<string, string>;
  major_amendments?: SixCodeAmendment[];
  recent_amendments?: SixCodeAmendment[];
  related_acts?: Array<{ law_id: string; short_name: string }>;
}

// JSON 静的取り込み (TS strict noUncheckedIndexedAccess 対応)
// eslint-disable-next-line @typescript-eslint/no-explicit-any
const _corpus = tierSCorpus as any;

export const SIX_CODES: SixCodeEntry[] = _corpus.six_codes as SixCodeEntry[];
export const TIER_A_MAJOR_60: string[] = _corpus.tier_a_major_60 as string[];
export const LAW_CATEGORIES: Record<string, string> = _corpus.categories as Record<string, string>;
export const TIER_S_ATTRIBUTION: string = _corpus._meta.attribution as string;

/** 六法コードから entry を取得 */
export function getSixCode(code: SixCode): SixCodeEntry | undefined {
  return SIX_CODES.find((c) => c.code === code);
}

/** 通称 (例: '民法') から entry を取得 */
export function findSixCodeByShortName(shortName: string): SixCodeEntry | undefined {
  return SIX_CODES.find((c) => c.short_name === shortName || c.official_name === shortName);
}

/** 条文要約を取得: 民法第415条 → '債務不履行 (改正R2.4)' */
export function getArticleSummary(input: {
  code: SixCode;
  articleNum: number | string;
}): string | undefined {
  const entry = getSixCode(input.code);
  if (!entry) return undefined;
  return entry.key_articles_summary[String(input.articleNum)];
}

/** 通称ベースの条文要約 (例: shortName='民法', articleNum=415) */
export function getArticleSummaryByName(input: {
  shortName: string;
  articleNum: number | string;
}): { code: SixCode; summary?: string } | undefined {
  const entry = findSixCodeByShortName(input.shortName);
  if (!entry) return undefined;
  return {
    code: entry.code,
    summary: entry.key_articles_summary[String(input.articleNum)],
  };
}

/**
 * 全六法に対する横断キーワード検索 (要約文に対する単純 substring マッチ)。
 * 高度な検索は vector_indexer.ts を使う。
 */
export interface SixCodeSearchHit {
  code: SixCode;
  short_name: string;
  article_num: string;
  summary: string;
  score: number;
}

export function searchSixCodes(keyword: string, max = 10): SixCodeSearchHit[] {
  if (!keyword) return [];
  const lower = keyword.toLowerCase();
  const hits: SixCodeSearchHit[] = [];
  for (const c of SIX_CODES) {
    for (const [art, summary] of Object.entries(c.key_articles_summary)) {
      const score = scoreMatch(summary, lower);
      if (score > 0) {
        hits.push({
          code: c.code,
          short_name: c.short_name,
          article_num: art,
          summary,
          score,
        });
      }
    }
  }
  hits.sort((a, b) => b.score - a.score);
  return hits.slice(0, max);
}

function scoreMatch(text: string, lowerKeyword: string): number {
  const t = (text ?? '').toLowerCase();
  if (!t.includes(lowerKeyword)) return 0;
  // 完全語境界の方が強い
  const exact = new RegExp(`(^|[^a-zA-Z0-9])${escapeReg(lowerKeyword)}([^a-zA-Z0-9]|$)`).test(t);
  return exact ? 10 : 5;
}

function escapeReg(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * 直近改正の取得 (六法横断)。施行日降順。
 */
export interface RecentSixCodeAmendment extends SixCodeAmendment {
  code: SixCode;
  short_name: string;
}
export function listRecentSixCodeAmendments(sinceISO: string): RecentSixCodeAmendment[] {
  const since = new Date(sinceISO);
  const out: RecentSixCodeAmendment[] = [];
  for (const c of SIX_CODES) {
    const all = [...(c.major_amendments ?? []), ...(c.recent_amendments ?? [])];
    for (const a of all) {
      if (new Date(a.date) >= since) {
        out.push({ ...a, code: c.code, short_name: c.short_name });
      }
    }
  }
  out.sort((a, b) => b.date.localeCompare(a.date));
  return out;
}

/**
 * 章節構造のフラット展開 (民法第3編 → 第3編 債権)。
 */
export function listChapterTitles(code: SixCode): Array<{ part?: number; title: string; range?: string }> {
  const entry = getSixCode(code);
  if (!entry) return [];
  const out: Array<{ part?: number; title: string; range?: string }> = [];
  if (entry.structure.parts) {
    for (const p of entry.structure.parts) {
      out.push({ part: p.num, title: p.title, range: p.articles_range });
      for (const ch of p.chapters ?? []) {
        out.push({ part: p.num, title: `  └ ${ch}` });
      }
    }
  }
  if (entry.structure.chapters) {
    for (const ch of entry.structure.chapters) {
      out.push({ part: ch.num, title: ch.title });
    }
  }
  return out;
}

/** 六法カバレッジ統計 */
export function countCoverage(): {
  total_codes: number;
  total_articles_summarized: number;
  total_amendments_tracked: number;
} {
  let arts = 0;
  let amends = 0;
  for (const c of SIX_CODES) {
    arts += Object.keys(c.key_articles_summary).length;
    amends += (c.major_amendments?.length ?? 0) + (c.recent_amendments?.length ?? 0);
  }
  return {
    total_codes: SIX_CODES.length,
    total_articles_summarized: arts,
    total_amendments_tracked: amends,
  };
}
