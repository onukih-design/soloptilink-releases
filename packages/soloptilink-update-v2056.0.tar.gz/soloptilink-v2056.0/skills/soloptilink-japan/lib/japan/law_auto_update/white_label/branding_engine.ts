/**
 * Phase 46-LU-7 / White-Label Branding Engine
 *
 * 法律事務所/SIer が自社ブランドで SoloptiLinkAI を再販できるホワイトラベル機能。
 *  - 独自ドメイン/サブドメイン
 *  - ロゴ/カラー/フォントカスタマイズ
 *  - メール送信元
 *  - ドキュメント (PDF/契約書) のヘッダー/フッター差し替え
 *  - 「Powered by SoloptiLinkAI」表記の任意非表示 (Enterprise/LegalFirm 限定)
 */

import type { PlanTier } from '../subscription/plans_catalog';

export interface BrandingConfig {
  brand_id: string;
  tenant_id: string;
  /** ブランド名 (例: 東京リーガル法律事務所) */
  brand_name: string;
  /** カスタムドメイン (例: legal.tokyo-firm.com) */
  custom_domain?: string;
  /** ロゴ URL */
  logo_url?: string;
  logo_dark_url?: string;
  /** カラーパレット */
  colors: {
    primary: string; // #RRGGBB
    secondary: string;
    accent: string;
    background: string;
    text: string;
  };
  /** フォント */
  font_family?: string;
  /** メール送信元 */
  email_from: string;
  email_reply_to?: string;
  /** ドキュメント */
  document_header_html?: string;
  document_footer_html?: string;
  document_watermark?: string;
  /** "Powered by SoloptiLinkAI" 表示 */
  show_powered_by: boolean;
  /** プラン制約 */
  enabled_features: BrandingFeature[];
  status: 'draft' | 'active' | 'suspended';
  created_at: string;
}

export type BrandingFeature =
  | 'custom_domain'
  | 'custom_logo'
  | 'custom_colors'
  | 'custom_email_sender'
  | 'document_header_footer'
  | 'hide_powered_by'
  | 'mobile_app_branding'
  | 'api_subdomain';

/**
 * プラン → 利用可能機能
 */
const BRANDING_FEATURE_BY_PLAN: Record<PlanTier, BrandingFeature[]> = {
  free: [],
  pro: ['custom_logo', 'custom_colors'],
  enterprise: ['custom_logo', 'custom_colors', 'custom_email_sender', 'document_header_footer', 'custom_domain'],
  legal_firm: ['custom_logo', 'custom_colors', 'custom_email_sender', 'document_header_footer', 'custom_domain', 'hide_powered_by', 'mobile_app_branding', 'api_subdomain'],
};

const BRANDING_STORE = new Map<string, BrandingConfig>();

export function createBranding(input: {
  tenant_id: string;
  plan_tier: PlanTier;
  brand_name: string;
  colors: BrandingConfig['colors'];
  email_from: string;
  custom_domain?: string;
  logo_url?: string;
  show_powered_by?: boolean;
}): { ok: true; config: BrandingConfig } | { ok: false; error: string } {
  const enabledFeatures = BRANDING_FEATURE_BY_PLAN[input.plan_tier];

  // プラン制約チェック
  if (input.custom_domain && !enabledFeatures.includes('custom_domain')) {
    return { ok: false, error: 'custom_domain は Enterprise 以上が必要' };
  }
  if (input.show_powered_by === false && !enabledFeatures.includes('hide_powered_by')) {
    return { ok: false, error: 'Powered by 非表示は LegalFirm プラン専用' };
  }

  // カラーバリデーション
  for (const [key, value] of Object.entries(input.colors)) {
    if (!/^#[0-9a-fA-F]{6}$/.test(value)) {
      return { ok: false, error: `colors.${key} は #RRGGBB 形式` };
    }
  }

  const config: BrandingConfig = {
    brand_id: `brand_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    tenant_id: input.tenant_id,
    brand_name: input.brand_name,
    custom_domain: input.custom_domain,
    logo_url: input.logo_url,
    colors: input.colors,
    email_from: input.email_from,
    show_powered_by: input.show_powered_by ?? true,
    enabled_features: enabledFeatures,
    status: 'draft',
    created_at: new Date().toISOString(),
  };
  BRANDING_STORE.set(config.brand_id, config);
  return { ok: true, config };
}

export function activateBranding(brand_id: string): boolean {
  const c = BRANDING_STORE.get(brand_id);
  if (!c) return false;
  c.status = 'active';
  return true;
}

export function getBrandingByTenant(tenant_id: string): BrandingConfig | undefined {
  for (const b of BRANDING_STORE.values()) {
    if (b.tenant_id === tenant_id && b.status === 'active') return b;
  }
  return undefined;
}

/**
 * CSS 変数生成 (フロントエンドに注入)
 */
export function renderBrandingCss(config: BrandingConfig): string {
  return `:root {
  --brand-primary: ${config.colors.primary};
  --brand-secondary: ${config.colors.secondary};
  --brand-accent: ${config.colors.accent};
  --brand-background: ${config.colors.background};
  --brand-text: ${config.colors.text};
  --brand-font: ${config.font_family ?? 'Inter, "Hiragino Sans", sans-serif'};
}
.brand-logo {
  background-image: url("${config.logo_url ?? ''}");
}
${config.show_powered_by ? '' : '.powered-by-soloptilink { display: none !important; }'}
`;
}

/**
 * メール HTML テンプレへの差し込み
 */
export function applyBrandingToEmail(input: { config: BrandingConfig; subject: string; body_html: string }): {
  from: string;
  reply_to?: string;
  subject: string;
  html: string;
} {
  const c = input.config;
  const poweredBy = c.show_powered_by
    ? '<p style="color:#888;font-size:11px;text-align:center;margin-top:20px">Powered by SoloptiLinkAI Legal</p>'
    : '';
  const html = `<html><body style="font-family:${c.font_family ?? 'sans-serif'};color:${c.colors.text};background:${c.colors.background}">
<div style="background:${c.colors.primary};color:white;padding:16px"><strong>${c.brand_name}</strong></div>
<div style="padding:20px">${input.body_html}</div>
${poweredBy}
</body></html>`;
  return {
    from: c.email_from,
    reply_to: c.email_reply_to,
    subject: input.subject,
    html,
  };
}

/**
 * ドキュメント (PDF) ヘッダー/フッター生成
 */
export function buildDocumentHeaderFooter(config: BrandingConfig): { header: string; footer: string; watermark?: string } {
  const header = config.document_header_html ?? `<div style="border-bottom:2px solid ${config.colors.primary};padding:10px"><strong>${config.brand_name}</strong></div>`;
  const footer = config.document_footer_html ?? `<div style="border-top:1px solid #ddd;padding:5px;text-align:center;font-size:10px;color:#666">${config.brand_name}${config.show_powered_by ? ' / Powered by SoloptiLinkAI Legal' : ''}</div>`;
  return { header, footer, watermark: config.document_watermark };
}

export function countBrandings(): { total: number; by_status: Record<string, number>; by_plan_features: Record<string, number> } {
  const byStatus: Record<string, number> = { draft: 0, active: 0, suspended: 0 };
  const byFeat: Record<string, number> = {};
  for (const b of BRANDING_STORE.values()) {
    byStatus[b.status]++;
    for (const f of b.enabled_features) byFeat[f] = (byFeat[f] ?? 0) + 1;
  }
  return { total: BRANDING_STORE.size, by_status: byStatus, by_plan_features: byFeat };
}

export function _resetBrandingForTests(): void {
  BRANDING_STORE.clear();
}
