/**
 * Phase 46-LU-7 / Expert Directory & Matching
 *
 * 弁護士・税理士・社労士・司法書士・会計士のディレクトリ + マッチング。
 * 法務AIアドバイザーが「複雑な事案」と判定した場合に専門家を推奨。
 *
 *  - 専門家プロフィール (専門分野・実績・料金・対応エリア)
 *  - シナリオベースマッチング (個情法漏えい → 個情法専門弁護士)
 *  - レビュー連携 (advisor.ts と統合)
 *  - レーティング (星評価 + コメント)
 */

import type { LawCategory } from '../../law_tracker';

export type ExpertKind = 'lawyer' | 'tax_accountant' | 'social_insurance_labor' | 'judicial_scrivener' | 'cpa' | 'patent_attorney';

export interface ExpertProfile {
  expert_id: string;
  display_name: string;
  kind: ExpertKind;
  specialties: LawCategory[];
  bar_admission_date: string;
  /** 拠点 */
  city: string;
  prefecture: string;
  /** 対応地域 (都道府県コード) */
  service_areas: string[];
  /** 料金 (相談料 円/30分) */
  consultation_fee_30min_jpy: number;
  /** 着手金最低額 */
  retainer_min_jpy: number;
  /** 過去実績 */
  notable_cases?: string[];
  /** 言語対応 */
  languages: Array<'ja' | 'en' | 'zh-CN' | 'zh-TW' | 'ko'>;
  /** 平均評価 0-5 */
  rating_avg?: number;
  rating_count?: number;
  /** プロフィールURL */
  website?: string;
  /** SoloptiLinkAI Certified バッジ */
  soloptilink_certified?: boolean;
}

/**
 * 内蔵専門家サンプル (公開情報 + デモ用ペルソナ)
 */
export const SAMPLE_EXPERTS: ExpertProfile[] = [
  {
    expert_id: 'lawyer_001',
    display_name: 'パーソナル弁護士 (個情法専門)',
    kind: 'lawyer',
    specialties: ['privacy' as LawCategory],
    bar_admission_date: '2012-04-01',
    city: '千代田区',
    prefecture: '東京都',
    service_areas: ['東京都', '神奈川県', '千葉県', '埼玉県'],
    consultation_fee_30min_jpy: 11000,
    retainer_min_jpy: 300000,
    notable_cases: ['SaaS事業者 個情法違反監査対応', 'GDPR 域外適用案件 30社', 'ベネッセ類似事案 損害賠償訴訟'],
    languages: ['ja', 'en'],
    rating_avg: 4.7,
    rating_count: 23,
    soloptilink_certified: true,
  },
  {
    expert_id: 'lawyer_002',
    display_name: 'パーソナル弁護士 (労働法専門)',
    kind: 'lawyer',
    specialties: ['labor' as LawCategory],
    bar_admission_date: '2008-10-01',
    city: '中央区',
    prefecture: '東京都',
    service_areas: ['東京都', '関東全域'],
    consultation_fee_30min_jpy: 13200,
    retainer_min_jpy: 500000,
    notable_cases: ['整理解雇4要件適用 製造業10件', '同一労働同一賃金 (パート有期労働法) 集団訴訟', 'フリーランス法対応コンサル'],
    languages: ['ja'],
    rating_avg: 4.8,
    rating_count: 41,
    soloptilink_certified: true,
  },
  {
    expert_id: 'lawyer_003',
    display_name: 'パーソナル弁護士 (建設業・不動産)',
    kind: 'lawyer',
    specialties: ['construction' as LawCategory, 'real_estate' as LawCategory],
    bar_admission_date: '2015-04-01',
    city: '大阪市',
    prefecture: '大阪府',
    service_areas: ['大阪府', '兵庫県', '京都府', '奈良県'],
    consultation_fee_30min_jpy: 8800,
    retainer_min_jpy: 250000,
    notable_cases: ['建設業法 R6 改正対応', '宅建業法 35条書面 集団研修'],
    languages: ['ja'],
    rating_avg: 4.5,
    rating_count: 15,
    soloptilink_certified: true,
  },
  {
    expert_id: 'tax_001',
    display_name: 'パーソナル税理士 (中小企業税務)',
    kind: 'tax_accountant',
    specialties: ['tax' as LawCategory],
    bar_admission_date: '2010-04-01',
    city: '名古屋市',
    prefecture: '愛知県',
    service_areas: ['愛知県', '岐阜県', '三重県'],
    consultation_fee_30min_jpy: 5500,
    retainer_min_jpy: 100000,
    notable_cases: ['インボイス制度導入支援 300社', '電帳法 R6 対応 + タイムスタンプ運用'],
    languages: ['ja'],
    rating_avg: 4.6,
    rating_count: 89,
    soloptilink_certified: true,
  },
  {
    expert_id: 'sr_001',
    display_name: 'パーソナル社労士 (労務管理)',
    kind: 'social_insurance_labor',
    specialties: ['labor' as LawCategory],
    bar_admission_date: '2014-04-01',
    city: '横浜市',
    prefecture: '神奈川県',
    service_areas: ['神奈川県', '東京都'],
    consultation_fee_30min_jpy: 6600,
    retainer_min_jpy: 50000,
    notable_cases: ['36協定運用支援 200社', '育介法 R6 改正対応 + 規程改定'],
    languages: ['ja'],
    rating_avg: 4.4,
    rating_count: 35,
    soloptilink_certified: true,
  },
  {
    expert_id: 'patent_001',
    display_name: 'パーソナル弁理士 (特許・商標)',
    kind: 'patent_attorney',
    specialties: ['patent' as LawCategory, 'trademark' as LawCategory, 'design' as LawCategory],
    bar_admission_date: '2011-04-01',
    city: '渋谷区',
    prefecture: '東京都',
    service_areas: ['全国'],
    consultation_fee_30min_jpy: 16500,
    retainer_min_jpy: 200000,
    notable_cases: ['SaaS UI特許 30件', 'マドプロ国際商標 80件'],
    languages: ['ja', 'en'],
    rating_avg: 4.9,
    rating_count: 52,
    soloptilink_certified: true,
  },
  {
    expert_id: 'cpa_001',
    display_name: 'パーソナル会計士 (J-SOX/IPO)',
    kind: 'cpa',
    specialties: ['corporate' as LawCategory, 'finance' as LawCategory],
    bar_admission_date: '2009-04-01',
    city: '千代田区',
    prefecture: '東京都',
    service_areas: ['全国'],
    consultation_fee_30min_jpy: 13200,
    retainer_min_jpy: 500000,
    notable_cases: ['J-SOX 内部統制構築 50社', 'IPO 主幹事会計士 8社'],
    languages: ['ja', 'en'],
    rating_avg: 4.8,
    rating_count: 31,
    soloptilink_certified: true,
  },
  {
    expert_id: 'judicial_001',
    display_name: 'パーソナル司法書士 (商業登記)',
    kind: 'judicial_scrivener',
    specialties: ['corporate' as LawCategory, 'real_estate' as LawCategory],
    bar_admission_date: '2013-04-01',
    city: '札幌市',
    prefecture: '北海道',
    service_areas: ['北海道'],
    consultation_fee_30min_jpy: 4400,
    retainer_min_jpy: 30000,
    notable_cases: ['商業登記 1500件', '相続登記 800件'],
    languages: ['ja'],
    rating_avg: 4.5,
    rating_count: 67,
    soloptilink_certified: false,
  },
];

const EXPERT_STORE = new Map<string, ExpertProfile>();

export function registerExpert(profile: ExpertProfile): void {
  EXPERT_STORE.set(profile.expert_id, profile);
}

export function loadSampleExperts(): void {
  for (const e of SAMPLE_EXPERTS) EXPERT_STORE.set(e.expert_id, e);
}

/**
 * シナリオ → 専門家マッチング
 */
export interface ExpertMatchInput {
  scenario: string;
  preferred_prefecture?: string;
  budget_max_jpy?: number;
  required_specialty?: LawCategory;
  language?: 'ja' | 'en' | 'zh-CN';
  prefer_certified?: boolean;
}

export interface ExpertMatchResult {
  expert: ExpertProfile;
  match_score: number;
  reasons: string[];
}

export function matchExperts(input: ExpertMatchInput, top_k = 5): ExpertMatchResult[] {
  const results: ExpertMatchResult[] = [];
  for (const e of EXPERT_STORE.values()) {
    let score = 0;
    const reasons: string[] = [];

    if (input.required_specialty && e.specialties.includes(input.required_specialty)) {
      score += 40;
      reasons.push(`専門分野 ${input.required_specialty} に該当`);
    }
    if (input.preferred_prefecture) {
      if (e.prefecture === input.preferred_prefecture || e.service_areas.includes(input.preferred_prefecture) || e.service_areas.includes('全国')) {
        score += 20;
        reasons.push(`対応地域 (${input.preferred_prefecture}) 該当`);
      }
    }
    // 予算
    if (input.budget_max_jpy && e.consultation_fee_30min_jpy <= input.budget_max_jpy) {
      score += 15;
      reasons.push(`相談料 ¥${e.consultation_fee_30min_jpy}/30分 ≤ ¥${input.budget_max_jpy}`);
    }
    // 言語
    if (input.language && e.languages.includes(input.language)) {
      score += 10;
      reasons.push(`${input.language} 対応`);
    }
    // 評価
    if (e.rating_avg && e.rating_avg >= 4.5) {
      score += 10;
      reasons.push(`評価 ★${e.rating_avg}`);
    }
    // SoloptiLinkAI Certified
    if (input.prefer_certified && e.soloptilink_certified) {
      score += 5;
      reasons.push('SoloptiLinkAI Certified');
    }
    // シナリオキーワードマッチング (簡易)
    const scenarioLower = input.scenario.toLowerCase();
    for (const c of e.notable_cases ?? []) {
      const keywords = c.split(/\s+/);
      for (const kw of keywords) {
        if (kw.length >= 4 && scenarioLower.includes(kw.toLowerCase())) {
          score += 3;
          reasons.push(`過去実績「${c}」が類似`);
          break;
        }
      }
    }

    if (score > 0) results.push({ expert: e, match_score: score, reasons });
  }
  return results.sort((a, b) => b.match_score - a.match_score).slice(0, top_k);
}

/**
 * レーティング記録
 */
export interface ExpertRating {
  expert_id: string;
  user_id: string;
  score: number; // 1-5
  comment?: string;
  consultation_date: string;
  timestamp: string;
}

const RATING_STORE: ExpertRating[] = [];

export function recordRating(input: Omit<ExpertRating, 'timestamp'>): ExpertRating {
  if (input.score < 1 || input.score > 5) throw new Error('rating must be 1-5');
  const r: ExpertRating = { ...input, timestamp: new Date().toISOString() };
  RATING_STORE.push(r);
  // 平均更新
  const expert = EXPERT_STORE.get(input.expert_id);
  if (expert) {
    const myRatings = RATING_STORE.filter((rr) => rr.expert_id === input.expert_id);
    const sum = myRatings.reduce((acc, rr) => acc + rr.score, 0);
    expert.rating_avg = Math.round((sum / myRatings.length) * 10) / 10;
    expert.rating_count = myRatings.length;
  }
  return r;
}

export function getExpert(expert_id: string): ExpertProfile | undefined {
  return EXPERT_STORE.get(expert_id);
}

export function countExperts(): { total: number; by_kind: Record<string, number>; certified: number } {
  const byKind: Record<string, number> = {};
  let cert = 0;
  for (const e of EXPERT_STORE.values()) {
    byKind[e.kind] = (byKind[e.kind] ?? 0) + 1;
    if (e.soloptilink_certified) cert++;
  }
  return { total: EXPERT_STORE.size, by_kind: byKind, certified: cert };
}

export function _resetExpertsForTests(): void {
  EXPERT_STORE.clear();
  RATING_STORE.length = 0;
}
