/**
 * Phase 46-LU-3 / Coverage Matrix
 *
 * Tier (S/A/B/C/D) × ドメイン (民事/刑事/行政/...) の二次元マトリックスを
 * 構築し、それぞれのセルが「完成 / 部分 / 欠落」のいずれかを可視化する。
 *
 * 出力例:
 *  ドメイン      | S    | A    | B   | C   | D
 *  ---------------+------+------+-----+-----+----
 *  民事            | 完成 | 完成 | 部分 | 部分 | 欠
 *  刑事            | 完成 | 部分 | 欠  | 欠  | 欠
 *  ...
 */

import type { LegalTier } from '../corpus/legal_corpus';
import { buildInitialCorpus } from '../corpus/legal_corpus';
import type { GapDomain } from './knowledge_gap_analyzer';

export type CellStatus = 'complete' | 'partial' | 'missing';

export interface MatrixCell {
  domain: GapDomain;
  tier: LegalTier;
  count: number;
  status: CellStatus;
}

export interface CoverageMatrix {
  generated_at: string;
  cells: MatrixCell[];
  by_domain_summary: Record<string, { complete: number; partial: number; missing: number }>;
  by_tier_summary: Record<LegalTier, number>;
  /** ヒートマップ: domain × tier */
  heatmap: Record<string, Record<LegalTier, CellStatus>>;
}

const ALL_TIERS: LegalTier[] = ['S', 'A', 'B', 'C', 'D'];

const DOMAIN_THRESHOLDS = {
  complete: 3,
  partial: 1,
};

const DOMAINS_FOR_MATRIX: GapDomain[] = [
  'constitution', 'civil', 'commercial', 'criminal',
  'administrative', 'tax', 'labor', 'ip',
  'finance', 'consumer', 'real_estate', 'transport',
  'environment', 'medical', 'cybersecurity',
];

const DOMAIN_KEYWORDS: Record<GapDomain, string[]> = {
  constitution: ['憲法'],
  civil: ['民法', '消費者契約', '借地借家'],
  commercial: ['会社法', '商法', '独占禁止', '下請'],
  criminal: ['刑法'],
  civil_procedure: ['民事訴訟'],
  criminal_procedure: ['刑事訴訟'],
  administrative: ['行政手続', '行政事件訴訟', '国家賠償', '地方自治'],
  tax: ['所得税', '法人税', '消費税', '相続税', 'インボイス', '電帳法'],
  labor: ['労働', '労基', '労契', '育介', '派遣', 'フリーランス'],
  ip: ['特許', '商標', '意匠', '著作権', '不正競争'],
  finance: ['金融', '銀行', '保険', '資金決済', '金商'],
  consumer: ['消費者', '景品表示', '特定商取引'],
  real_estate: ['宅地建物', '不動産', '建築'],
  transport: ['道路運送', '貨物自動車', '海上運送', '航空'],
  environment: ['廃棄物', '省エネ', '温対', '環境'],
  medical: ['医療', '薬機', '介護', '健康保険'],
  education: ['学校教育', '私立学校'],
  agriculture: ['農地', '森林', '漁業'],
  cybersecurity: ['サイバー', '不正アクセス'],
  international: ['通商', 'EPA', 'TRIPS', 'WTO'],
  insolvency: ['破産', '民事再生', '会社更生'],
  special_criminal: ['銃刀', '麻取', '覚醒', '暴対', 'DV', 'ストーカー'],
  private_international: ['通則法', '仲裁'],
};

/**
 * カバレッジマトリックスを構築
 */
export function buildCoverageMatrix(): CoverageMatrix {
  const corpus = buildInitialCorpus();
  const cells: MatrixCell[] = [];
  const byDomain: Record<string, { complete: number; partial: number; missing: number }> = {};
  const byTier: Record<LegalTier, number> = { S: 0, A: 0, B: 0, C: 0, D: 0 };
  const heatmap: Record<string, Record<LegalTier, CellStatus>> = {};

  for (const d of DOMAINS_FOR_MATRIX) {
    byDomain[d] = { complete: 0, partial: 0, missing: 0 };
    heatmap[d] = { S: 'missing', A: 'missing', B: 'missing', C: 'missing', D: 'missing' };
    for (const t of ALL_TIERS) {
      const keywords = DOMAIN_KEYWORDS[d] ?? [];
      const matched = corpus.filter((e) =>
        e.tier === t && keywords.some((k) => e.short_name.includes(k) || e.official_name.includes(k)),
      );
      const n = matched.length;
      const status: CellStatus =
        n >= DOMAIN_THRESHOLDS.complete ? 'complete'
        : n >= DOMAIN_THRESHOLDS.partial ? 'partial'
        : 'missing';
      cells.push({ domain: d, tier: t, count: n, status });
      byDomain[d][status]++;
      byTier[t] += n;
      heatmap[d][t] = status;
    }
  }

  return {
    generated_at: new Date().toISOString(),
    cells,
    by_domain_summary: byDomain,
    by_tier_summary: byTier,
    heatmap,
  };
}

/**
 * ASCII テーブルとしてマトリックスをレンダリング
 */
export function renderMatrixAsAscii(matrix: CoverageMatrix): string {
  const lines: string[] = [];
  lines.push('====================================================');
  lines.push('  Coverage Matrix (Domain × Tier)');
  lines.push('====================================================');
  const header = '  ' + 'domain'.padEnd(18) + ALL_TIERS.map((t) => `Tier${t}`.padStart(8)).join(' | ');
  lines.push(header);
  lines.push('  ' + '-'.repeat(header.length - 2));
  for (const d of DOMAINS_FOR_MATRIX) {
    const row = ['  ' + d.padEnd(18)];
    for (const t of ALL_TIERS) {
      const cell = matrix.cells.find((c) => c.domain === d && c.tier === t);
      const sym = cell?.status === 'complete' ? '完成' : cell?.status === 'partial' ? '部分' : '欠';
      const count = cell?.count ?? 0;
      row.push(`${sym}(${count})`.padStart(8));
    }
    lines.push(row.join(' | '));
  }
  lines.push('');
  lines.push('  Tier 別合計:');
  for (const t of ALL_TIERS) {
    lines.push(`    Tier ${t}: ${matrix.by_tier_summary[t]}`);
  }
  lines.push('====================================================');
  return lines.join('\n');
}

/**
 * JSON サマリ (CI/監視向け)
 */
export function summarizeMatrixAsJson(matrix: CoverageMatrix): {
  generated_at: string;
  cells_count: number;
  complete_cells: number;
  partial_cells: number;
  missing_cells: number;
  completeness_pct: number;
} {
  let comp = 0, part = 0, miss = 0;
  for (const c of matrix.cells) {
    if (c.status === 'complete') comp++;
    else if (c.status === 'partial') part++;
    else miss++;
  }
  const total = matrix.cells.length;
  return {
    generated_at: matrix.generated_at,
    cells_count: total,
    complete_cells: comp,
    partial_cells: part,
    missing_cells: miss,
    completeness_pct: total > 0 ? Math.round((comp / total) * 1000) / 10 : 0,
  };
}
