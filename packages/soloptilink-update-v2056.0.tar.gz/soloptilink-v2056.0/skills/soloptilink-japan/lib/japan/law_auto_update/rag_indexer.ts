/**
 * Phase 46-LU / RAG/Decision Bank への改正学習データ取り込み
 *
 * 既存 compliance_decision_bank.ts は判例/通達の構造化 RAG だが、
 * 改正法令の追加はリリースタイミングに依存していた。
 * 本モジュールは:
 *   1) 改正法令本文 (chunks) → DecisionBankEntry 形式に正規化
 *   2) 法令カテゴリ → LawArea (compliance_decision_bank の型) にマッピング
 *   3) hit_keywords を自動抽出 (主要キーワード+条番号)
 *   4) JSONL append-only で永続化 (~/.soloptilink/learning/legal_updates/)
 *
 * 検索は呼出側 (Decision Bank 拡張) が読み込んで全文一致 / RAG embed する想定。
 */

import type { EgovLawTextChunk, LawAmendmentDiff, LawCategory } from '../law_tracker';
import { LAW_CATALOG } from '../law_tracker';
import { EXTENDED_LAW_CATALOG } from './catalog_full';

export interface LegalUpdateRagEntry {
  /** ハッシュベース ID (lawId + articleNum + version) */
  entry_id: string;
  /** 法令 ID */
  law_id: string;
  /** 通称 */
  short_name: string;
  /** 法令カテゴリ */
  category: LawCategory;
  /** 該当条文番号 */
  article_num: string;
  paragraph_num?: string;
  item_num?: string;
  /** 改正前後 */
  before_text?: string;
  after_text?: string;
  /** 変更種別 */
  change_type: 'added' | 'modified' | 'deleted';
  /** 重要度 */
  severity: 'critical' | 'major' | 'minor' | 'editorial';
  /** 施行日 */
  effective_date: string;
  /** 関連 lib/japan/*.ts */
  affected_modules: string[];
  /** RAG 検索用キーワード */
  hit_keywords: string[];
  /** 構造化要約 (~120字) */
  summary: string;
  /** 取り込み日時 (ISO) */
  indexed_at: string;
  /** 出典 */
  source_url: string;
}

const SOURCE_URL_FALLBACK = 'https://laws.e-gov.go.jp/';

export function buildRagEntries(args: {
  diff: LawAmendmentDiff;
  fullChunks?: EgovLawTextChunk[];
}): LegalUpdateRagEntry[] {
  const { diff } = args;
  const cat = LAW_CATALOG.find((l) => l.egovLawId === diff.lawId)
    ?? EXTENDED_LAW_CATALOG.find((l) => l.egovLawId === diff.lawId);
  if (!cat) return [];

  const indexedAt = new Date().toISOString();
  return diff.changedArticles.map((c) => {
    const after = c.after ?? '';
    const before = c.before ?? '';
    const summary = buildSummary(c.changeType, c.articleNum, after || before);
    const keywords = extractKeywords({ articleNum: c.articleNum, text: `${before} ${after}`, shortName: cat.shortName });
    return {
      entry_id: `${diff.lawId}-art${c.articleNum}-${indexedAt.slice(0, 10)}`,
      law_id: diff.lawId,
      short_name: cat.shortName,
      category: cat.category,
      article_num: c.articleNum,
      before_text: before || undefined,
      after_text: after || undefined,
      change_type: c.changeType,
      severity: diff.severity === 'major' ? 'major' : diff.severity === 'minor' ? 'minor' : 'editorial',
      effective_date: diff.afterVersion.effectiveDate,
      affected_modules: diff.affectedModules.length > 0 ? diff.affectedModules : cat.relatedModules,
      hit_keywords: keywords,
      summary,
      indexed_at: indexedAt,
      source_url: SOURCE_URL_FALLBACK,
    };
  });
}

function buildSummary(changeType: string, articleNum: string, body: string): string {
  const prefix = changeType === 'added' ? '【新設】' : changeType === 'deleted' ? '【削除】' : '【改正】';
  const cleaned = body.replace(/\s+/g, ' ').trim();
  return `${prefix}第${articleNum}条: ${cleaned.slice(0, 100)}`;
}

function extractKeywords(input: { articleNum: string; text: string; shortName: string }): string[] {
  const kws = new Set<string>([input.shortName, `第${input.articleNum}条`]);
  // 主要法令用語の鉱脈
  const patterns = [
    '罰則', '懲役', '罰金', '損害賠償', '無効', '解除', '義務', '禁止',
    '責任', '取消', '効力', '失効', '施行', '附則', '届出', '報告', '記録',
    '保存', '開示', '通知', '公表', '同意', '承諾', '契約', '解除',
  ];
  for (const p of patterns) {
    if (input.text.includes(p)) kws.add(p);
  }
  return [...kws];
}

/**
 * JSONL に直列化。1 行 = 1 エントリ。
 */
export function serializeRagEntriesToJsonl(entries: LegalUpdateRagEntry[]): string {
  return entries.map((e) => JSON.stringify(e)).join('\n') + (entries.length > 0 ? '\n' : '');
}

/**
 * 既存 compliance_decision_bank.ts と統合するための形式変換 (任意)。
 * Decision Bank は構造化されたエントリを期待するため、本モジュールから
 * 直接 mutate するのではなく、append 用エクスポートを返す。
 */
export interface DecisionBankAppendPayload {
  source: 'phase46_lu';
  legal_updates: LegalUpdateRagEntry[];
  appended_at: string;
}

export function buildDecisionBankAppend(entries: LegalUpdateRagEntry[]): DecisionBankAppendPayload {
  return {
    source: 'phase46_lu',
    legal_updates: entries,
    appended_at: new Date().toISOString(),
  };
}
