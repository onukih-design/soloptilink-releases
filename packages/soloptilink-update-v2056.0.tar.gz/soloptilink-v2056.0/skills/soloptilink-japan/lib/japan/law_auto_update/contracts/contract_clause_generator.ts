/**
 * Phase 46-LU-5 / Contract Clause Generator
 *
 * 日本の典型契約 8 種類について、各条項の標準テンプレートを生成する。
 * 各条項に「目的・典型表現・代替案・法的根拠」を含む。
 *
 * 対応契約類型:
 *  - NDA (秘密保持契約)
 *  - 業務委託契約 (準委任型)
 *  - 業務委託契約 (請負型)
 *  - 売買基本契約
 *  - 賃貸借契約 (事業用)
 *  - SES契約 (技術者派遣的準委任)
 *  - ライセンス契約
 *  - 株式譲渡契約 (M&A)
 */

export type ContractKind =
  | 'nda'
  | 'consulting_jun_inin'
  | 'consulting_ukeoi'
  | 'sales_basic'
  | 'lease_commercial'
  | 'ses'
  | 'license'
  | 'share_transfer';

export interface ContractClause {
  clause_no: string;
  title: string;
  body: string;
  related_laws: string[];
  risk_notes?: string[];
  alternative_versions?: Array<{ label: string; body: string }>;
}

export interface ContractTemplate {
  kind: ContractKind;
  title: string;
  parties_template: string;
  preamble: string;
  clauses: ContractClause[];
  closing_template: string;
}

// ============================================================================
// NDA
// ============================================================================

const NDA_TEMPLATE: ContractTemplate = {
  kind: 'nda',
  title: '秘密保持契約書',
  parties_template: '甲: ○○株式会社\n乙: ○○株式会社',
  preamble: '甲と乙は、両者間の業務上の協議に関して、相互に開示する秘密情報の取扱いについて、以下のとおり契約する。',
  clauses: [
    {
      clause_no: '第1条',
      title: '秘密情報の定義',
      body: '本契約において「秘密情報」とは、開示当事者が相手方に対し書面・口頭・電磁的記録その他の方法により秘密である旨を明示して開示した情報をいう。ただし以下は除く: (1) 開示時に既に公知のもの (2) 受領後に受領者の責によらず公知となったもの (3) 受領時に既に正当に保有していたもの (4) 第三者から守秘義務なく正当に取得したもの (5) 受領者が独自に開発したもの。',
      related_laws: ['民法第1条第2項 (信義誠実)', '不正競争防止法第2条第6項 (営業秘密)'],
      risk_notes: ['口頭開示の場合は7日以内に書面確認する旨を加えるとより安全'],
    },
    {
      clause_no: '第2条',
      title: '秘密保持義務',
      body: '受領者は、秘密情報を善良な管理者の注意義務をもって取扱い、本契約の目的にのみ使用し、開示者の事前の書面承諾なく第三者に開示・漏えいしてはならない。',
      related_laws: ['民法第415条 (債務不履行)', '不競法第2条第1項第7号 (不正取得)'],
    },
    {
      clause_no: '第3条',
      title: '複製及び保管',
      body: '受領者は秘密情報を本契約の目的の範囲内でのみ複製でき、複製物にも本契約の規定が及ぶ。受領者は受領した秘密情報及び複製物を厳重に保管する。',
      related_laws: ['民法第644条 (善管注意義務)'],
    },
    {
      clause_no: '第4条',
      title: '有効期間',
      body: '本契約の有効期間は契約締結日から○年間とする。ただし秘密保持義務は契約終了後さらに○年間存続する。',
      related_laws: ['民法第167条 (一般時効)'],
      alternative_versions: [
        { label: '永久型', body: '秘密情報の機密性が失われるまで存続する' },
        { label: '5年型', body: '契約終了後5年間存続する' },
      ],
    },
    {
      clause_no: '第5条',
      title: '返還又は廃棄',
      body: '本契約終了時又は開示者の請求があったとき、受領者は秘密情報及びその複製物を開示者の指示に従い返還又は廃棄する。',
      related_laws: ['民法第400条 (特定物の引渡し)'],
    },
    {
      clause_no: '第6条',
      title: '損害賠償',
      body: '受領者が本契約に違反し開示者に損害を与えた場合、受領者はその損害を賠償する責を負う。',
      related_laws: ['民法第415条', '民法第709条'],
    },
    {
      clause_no: '第7条',
      title: '反社会的勢力の排除',
      body: '甲及び乙は、自らが反社会的勢力に該当しないこと、反社会的勢力と関係を有しないことを表明する。違反が判明した場合、相手方は催告なく本契約を解除できる。',
      related_laws: ['暴力団排除条例 (各都道府県)'],
    },
    {
      clause_no: '第8条',
      title: '準拠法及び合意管轄',
      body: '本契約は日本法に準拠する。本契約に関する紛争は東京地方裁判所を第一審の専属的合意管轄裁判所とする。',
      related_laws: ['民事訴訟法第11条 (合意管轄)'],
    },
  ],
  closing_template: '本契約の成立を証するため、本書2通を作成し、甲乙署名捺印の上、各1通を保有する。\n\n令和○年○月○日\n\n甲: ___________\n乙: ___________',
};

// ============================================================================
// 業務委託 (準委任)
// ============================================================================

const CONSULTING_JUN_TEMPLATE: ContractTemplate = {
  kind: 'consulting_jun_inin',
  title: '業務委託契約書 (準委任型)',
  parties_template: '委託者: ○○株式会社\n受託者: ○○株式会社',
  preamble: '委託者は受託者に対し、以下の業務 (以下「本件業務」) を委託し、受託者はこれを受託する。',
  clauses: [
    {
      clause_no: '第1条',
      title: '業務内容',
      body: '受託者は委託者に対し、別紙仕様書記載の業務を実施する。',
      related_laws: ['民法第656条 (準委任)', '民法第643条 (委任)'],
    },
    {
      clause_no: '第2条',
      title: '業務遂行義務',
      body: '受託者は善良な管理者の注意義務をもって本件業務を遂行する。受託者は完成責任を負わず、業務遂行責任のみを負う。',
      related_laws: ['民法第644条 (善管注意義務)', '民法第648条 (受任者の報酬)'],
      risk_notes: ['完成責任を負わない旨を明示することで請負契約との区別を明確化'],
    },
    {
      clause_no: '第3条',
      title: '報酬',
      body: '委託者は受託者に対し、本件業務の対価として月額金○○○○○○円 (税別) を支払う。支払時期は翌月末日とし、振込手数料は委託者負担とする。',
      related_laws: ['民法第648条第2項', '消費税法'],
    },
    {
      clause_no: '第4条',
      title: '報告義務',
      body: '受託者は委託者の請求に応じ、業務の進捗状況を報告する。',
      related_laws: ['民法第645条 (受任者の報告義務)'],
    },
    {
      clause_no: '第5条',
      title: '再委託',
      body: '受託者は委託者の書面による事前承諾なく、本件業務を第三者に再委託してはならない。',
      related_laws: ['民法第644条の2 (準委任の復受任)'],
    },
    {
      clause_no: '第6条',
      title: '個人情報の取扱い',
      body: '受託者は本件業務に関連して取得した個人情報を、個人情報保護法その他関連法令を遵守して取扱う。',
      related_laws: ['個情法第25条 (委託先の監督)', '個情法第26条 (漏えい報告)'],
    },
    {
      clause_no: '第7条',
      title: '解除',
      body: '各当事者は相手方が本契約に違反し、相当期間を定めた催告後もなお是正されない場合、本契約を解除できる。',
      related_laws: ['民法第541条 (催告解除)', '民法第651条 (委任の解除)'],
    },
    {
      clause_no: '第8条',
      title: '損害賠償の上限',
      body: '受託者の責に帰すべき事由による損害賠償の上限は、賠償事由発生の前12か月間に委託者から受託者に対し支払われた報酬の合計額を上限とする。ただし故意又は重過失による場合はこの限りではない。',
      related_laws: ['民法第415条', '消費者契約法第8条 (BtoC 場合は不適用注意)'],
      risk_notes: ['BtoC 契約では消費者契約法8条/8条の2/10条に注意'],
    },
    {
      clause_no: '第9条',
      title: '有効期間',
      body: '本契約の有効期間は契約締結日から1年間とし、双方異議なき場合は1年ごと自動更新する。',
      related_laws: ['民法第604条 (賃貸借期間) 類推'],
    },
    {
      clause_no: '第10条',
      title: '反社会的勢力の排除',
      body: '各当事者は自らが反社会的勢力でないこと、反社会的勢力と関係を有しないことを表明する。',
      related_laws: ['暴排条例 (各都道府県)'],
    },
    {
      clause_no: '第11条',
      title: '準拠法及び管轄',
      body: '本契約は日本法に準拠し、東京地方裁判所を第一審の専属的合意管轄裁判所とする。',
      related_laws: ['民訴法第11条'],
    },
  ],
  closing_template: '本契約の成立を証するため、本書2通を作成し、委託者及び受託者署名捺印の上、各1通を保有する。',
};

// ============================================================================
// SES
// ============================================================================

const SES_TEMPLATE: ContractTemplate = {
  kind: 'ses',
  title: 'システムエンジニアリングサービス契約書 (SES)',
  parties_template: '発注者: ○○株式会社\n受注者: ○○株式会社',
  preamble: '発注者と受注者は、システム開発に関する技術者の業務役務の提供について、以下のとおり契約する。',
  clauses: [
    {
      clause_no: '第1条',
      title: '契約類型',
      body: '本契約は準委任契約 (民法第656条) であり、受注者は完成責任を負わず、業務役務の提供責任のみを負う。',
      related_laws: ['民法第656条', '労働者派遣法 (区別重要)'],
      risk_notes: ['偽装請負と判断されないよう、指揮命令系統の独立性を確保'],
    },
    {
      clause_no: '第2条',
      title: '指揮命令系統',
      body: '本件業務における技術者への指揮命令は、受注者の管理責任者を通じて行う。発注者は技術者に対し直接の指揮命令を行わない。',
      related_laws: ['労働者派遣法第2条', '職業安定法第4条'],
      risk_notes: ['発注者直接指揮は偽装請負として違法 (R4 行政指導強化)'],
    },
    {
      clause_no: '第3条',
      title: '業務内容及び単価',
      body: '本件業務の内容、技術者氏名、単価、稼働時間範囲は別紙の作業要領に定める。',
      related_laws: ['民法第648条'],
    },
    {
      clause_no: '第4条',
      title: '清算方式',
      body: '業務報酬は次のいずれかの方式とする: (a) 完全月額固定方式 (b) 上下限あり清算方式 (140-180h など) (c) 時間清算方式。詳細は別紙作業要領に定める。',
      related_laws: ['民法第648条', '労基法第32条'],
    },
    {
      clause_no: '第5条',
      title: '勤怠管理',
      body: '技術者の勤怠管理は受注者が行う。発注者は作業実施場所及び作業時間の参考データを受注者に提供する。',
      related_laws: ['労基法第32条', '労安衛法'],
    },
    {
      clause_no: '第6条',
      title: '秘密保持',
      body: '受注者及び技術者は、業務上知り得た発注者の秘密情報を厳重に管理し、本件業務以外の目的に使用しない。',
      related_laws: ['不競法第2条第6項'],
    },
    {
      clause_no: '第7条',
      title: '損害賠償',
      body: '受注者の責に帰すべき事由による損害賠償の上限は、賠償事由発生月の委託料を上限とする。',
      related_laws: ['民法第415条'],
    },
    {
      clause_no: '第8条',
      title: '解除',
      body: '相手方が本契約に違反した場合、催告後解除できる。',
      related_laws: ['民法第541条'],
    },
    {
      clause_no: '第9条',
      title: '反社及び準拠法',
      body: '各当事者は反社会的勢力でないことを表明する。本契約は日本法に準拠し、東京地裁を専属合意管轄とする。',
      related_laws: ['暴排条例', '民訴法第11条'],
    },
  ],
  closing_template: '本契約の成立を証するため、本書2通を作成し、各1通を保有する。',
};

// ============================================================================
// 内蔵テンプレート集
// ============================================================================

const TEMPLATES: Partial<Record<ContractKind, ContractTemplate>> = {
  nda: NDA_TEMPLATE,
  consulting_jun_inin: CONSULTING_JUN_TEMPLATE,
  ses: SES_TEMPLATE,
};

export interface GenerateContractInput {
  kind: ContractKind;
  /** 当事者表記をカスタム */
  parties_override?: string;
  /** 一部条項のみ生成 */
  only_clauses?: string[];
  /** 出力フォーマット */
  format?: 'markdown' | 'plain' | 'json';
}

export function generateContractTemplate(input: GenerateContractInput): {
  template: ContractTemplate | undefined;
  rendered: string;
  clauses_used: number;
} {
  const tpl = TEMPLATES[input.kind];
  if (!tpl) {
    return {
      template: undefined,
      rendered: `[Error] テンプレ未対応: ${input.kind}\n対応中: ${Object.keys(TEMPLATES).join(', ')}`,
      clauses_used: 0,
    };
  }
  const clauses = input.only_clauses
    ? tpl.clauses.filter((c) => input.only_clauses!.includes(c.clause_no))
    : tpl.clauses;

  if (input.format === 'json') {
    return {
      template: tpl,
      rendered: JSON.stringify({ ...tpl, clauses }, null, 2),
      clauses_used: clauses.length,
    };
  }

  const lines: string[] = [];
  if (input.format !== 'plain') {
    lines.push(`# ${tpl.title}`);
    lines.push('');
  } else {
    lines.push(tpl.title);
    lines.push('');
  }
  lines.push(input.parties_override ?? tpl.parties_template);
  lines.push('');
  lines.push(tpl.preamble);
  lines.push('');
  for (const c of clauses) {
    lines.push(`## ${c.clause_no} ${c.title}`);
    lines.push('');
    lines.push(c.body);
    lines.push('');
    if (c.related_laws.length > 0) {
      lines.push(`> 関連法令: ${c.related_laws.join(' / ')}`);
      lines.push('');
    }
    if (c.risk_notes?.length) {
      lines.push(`> ⚠️ 注意: ${c.risk_notes.join(' ')}`);
      lines.push('');
    }
  }
  lines.push(tpl.closing_template);
  return {
    template: tpl,
    rendered: lines.join('\n'),
    clauses_used: clauses.length,
  };
}

export function listAvailableContractKinds(): ContractKind[] {
  return Object.keys(TEMPLATES) as ContractKind[];
}

export function findContractByKind(kind: ContractKind): ContractTemplate | undefined {
  return TEMPLATES[kind];
}

export function countContractTemplates(): { total: number; total_clauses: number } {
  let total_clauses = 0;
  for (const t of Object.values(TEMPLATES)) total_clauses += t?.clauses.length ?? 0;
  return { total: Object.keys(TEMPLATES).length, total_clauses };
}
