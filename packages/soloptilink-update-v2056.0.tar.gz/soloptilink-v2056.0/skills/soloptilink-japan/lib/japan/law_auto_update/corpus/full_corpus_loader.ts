/**
 * Phase 46-LU-2 / Full Corpus Loader
 *
 * e-Gov v2 から日本全法令のメタデータを段階的に取得し、
 * corpus.jsonl に永続化する。
 *
 * 段階取得方針 (rate limit 1req/sec の遵守):
 *  1) Tier S (六法) — 即時 / 6 件
 *  2) Tier A (主要60) — 初回 cron 60 件
 *  3) Tier B (業法) — 月次 100 件/週
 *  4) Tier C (省令告示) — 四半期 200 件/週
 *  5) Tier D (その他) — 年次 50 件/週
 *
 * 9,000 法令の完全取得には約 9000 / 410(weeks budget) ≈ 22 週 (5 ヶ月) を想定。
 *
 * 取得物:
 *  - corpus.jsonl (CorpusEntry[] append-only)
 *  - corpus_index.json (lawId → ファイル offset)
 *  - bodies/<lawId>.json (本文 chunks / Tier S/A のみ)
 */

import type { EgovV2Client } from '../source_egov_v2';
import { getDefaultEgovV2Client } from '../source_egov_v2';
import type { CorpusEntry, LegalTier } from './legal_corpus';
import { buildInitialCorpus, mergeCorpora, serializeCorpusToJsonl, parseCorpusFromJsonl, computeCoverage } from './legal_corpus';
import { classifyTier } from './tier_classifier';
import type { EgovLawSummary, EgovLawTextChunk, LawCategory } from '../../law_tracker';

export interface CorpusLoaderResult {
  added: number;
  updated: number;
  text_loaded: number;
  total_after: number;
  errors: Array<{ law_id: string; error: string }>;
  durationMs: number;
}

export interface CorpusLoaderOptions {
  egov?: EgovV2Client;
  /** target=top: Tier S+A のみ即時取得 / all: 全 Tier 段階取得 */
  target?: 'top' | 'all';
  /** 1 回の実行で取得する最大件数 (rate limit 余裕を持って) */
  maxFetch?: number;
  /** 本文も取得するか (true なら Tier S+A は本文 chunks も保存) */
  fetchTextForS_A?: boolean;
}

export interface CorpusPersistLayer {
  loadCorpus(): Promise<CorpusEntry[]>;
  saveCorpus(entries: CorpusEntry[]): Promise<void>;
  saveLawBody(lawId: string, chunks: EgovLawTextChunk[]): Promise<void>;
}

/**
 * Loader のメインクラス。
 */
export class FullCorpusLoader {
  private readonly egov: EgovV2Client;

  constructor(opts: { egov?: EgovV2Client } = {}) {
    this.egov = opts.egov ?? getDefaultEgovV2Client();
  }

  /** Tier S/A の初期コーパスを生成 (内蔵 catalog から) */
  buildInitial(): CorpusEntry[] {
    return buildInitialCorpus();
  }

  /**
   * 既存 corpus を読み込み、欠落している法令を e-Gov から取得して merge。
   * persist.saveCorpus / saveLawBody で永続化する。
   */
  async runOnce(
    persist: CorpusPersistLayer,
    opts: CorpusLoaderOptions = {},
  ): Promise<CorpusLoaderResult> {
    const start = Date.now();
    const target = opts.target ?? 'top';
    const maxFetch = opts.maxFetch ?? (target === 'top' ? 66 : 300);
    const fetchText = opts.fetchTextForS_A ?? (target === 'top');
    const errors: Array<{ law_id: string; error: string }> = [];

    let added = 0;
    let updated = 0;
    let textLoaded = 0;

    // 1) 既存 corpus
    let existing: CorpusEntry[] = [];
    try {
      existing = await persist.loadCorpus();
    } catch (e) {
      // 初回は空
    }
    if (existing.length === 0) {
      existing = this.buildInitial();
      added += existing.length;
    }

    // 2) Tier S/A の本文取得 (text_loaded=false の分のみ)
    const candidates = this.selectFetchTargets(existing, target, maxFetch);
    for (const c of candidates) {
      try {
        if (!c.law_id) continue;
        // メタ更新
        const summary = await this.egov.fetchLawSummary(c.law_id);
        const updatedEntry = this.applySummary(c, summary);
        if (fetchText && (c.tier === 'S' || c.tier === 'A')) {
          const chunks = await this.egov.fetchLawText(c.law_id);
          await persist.saveLawBody(c.law_id, chunks);
          updatedEntry.text_loaded = true;
          textLoaded++;
        }
        // 入れ替え
        const idx = existing.findIndex((e) => e.law_id === c.law_id);
        if (idx >= 0) existing[idx] = updatedEntry;
        else existing.push(updatedEntry);
        updated++;
      } catch (err) {
        errors.push({ law_id: c.law_id, error: err instanceof Error ? err.message : String(err) });
      }
    }

    // 3) 全件 save
    await persist.saveCorpus(existing);

    return {
      added,
      updated,
      text_loaded: textLoaded,
      total_after: existing.length,
      errors,
      durationMs: Date.now() - start,
    };
  }

  private selectFetchTargets(
    entries: CorpusEntry[],
    target: 'top' | 'all',
    max: number,
  ): CorpusEntry[] {
    // 取得対象 Tier
    const tiers: LegalTier[] = target === 'top' ? ['S', 'A'] : ['S', 'A', 'B', 'C', 'D'];
    const ordered: CorpusEntry[] = [];
    for (const t of tiers) {
      const list = entries.filter((e) => e.tier === t && !e.text_loaded && !!e.law_id);
      ordered.push(...list);
      if (ordered.length >= max) break;
    }
    return ordered.slice(0, max);
  }

  private applySummary(entry: CorpusEntry, summary: EgovLawSummary): CorpusEntry {
    const tier = entry.tier !== 'D' ? entry.tier : classifyTier(entry.short_name, summary.lawTitle);
    return {
      ...entry,
      official_name: summary.lawTitle || entry.official_name,
      promulgation_date: summary.promulgationDate || entry.promulgation_date,
      last_effective_date: summary.lastUpdateDate ?? entry.last_effective_date,
      tier,
      indexed_at: new Date().toISOString(),
    };
  }
}

/**
 * Node 環境向けのデフォルト永続レイヤー。
 * 学習データルート: ~/.soloptilink/learning/legal_corpus/
 */
export async function createNodeCorpusPersistLayer(baseDir: string): Promise<CorpusPersistLayer> {
  const { mkdir, readFile, writeFile } = await import('node:fs/promises');
  const path = await import('node:path');
  const dir = path.join(baseDir, 'legal_corpus');
  const bodiesDir = path.join(dir, 'bodies');
  await mkdir(bodiesDir, { recursive: true });
  const corpusPath = path.join(dir, 'corpus.jsonl');

  return {
    async loadCorpus() {
      try {
        const txt = await readFile(corpusPath, 'utf8');
        return parseCorpusFromJsonl(txt);
      } catch {
        return [];
      }
    },
    async saveCorpus(entries: CorpusEntry[]) {
      await writeFile(corpusPath, serializeCorpusToJsonl(entries), 'utf8');
    },
    async saveLawBody(lawId: string, chunks: EgovLawTextChunk[]) {
      const safe = lawId.replace(/[^A-Za-z0-9_-]/g, '_');
      const file = path.join(bodiesDir, `${safe}.json`);
      await writeFile(file, JSON.stringify({ law_id: lawId, chunks, saved_at: new Date().toISOString() }, null, 2), 'utf8');
    },
  };
}

/**
 * 進捗レポート (人間可読)。
 */
export function buildCoverageReport(entries: CorpusEntry[]): string {
  const c = computeCoverage(entries);
  const lines: string[] = [];
  lines.push('# Legal Corpus Coverage');
  lines.push('');
  lines.push(`- 総登録: ${c.total}`);
  lines.push(`- e-Gov 推定総数: ${c.target_total}`);
  lines.push(`- カバレッジ: **${c.coverage_pct}%**`);
  lines.push(`- 本文学習済: ${c.text_loaded} (${c.text_loaded_pct}%)`);
  lines.push('');
  lines.push('## Tier 別');
  for (const t of ['S', 'A', 'B', 'C', 'D'] as const) {
    lines.push(`- ${t}: ${c.by_tier[t]} 件`);
  }
  lines.push('');
  lines.push('## 種別');
  for (const k of Object.keys(c.by_type)) {
    lines.push(`- ${k}: ${(c.by_type as Record<string, number>)[k]} 件`);
  }
  return lines.join('\n');
}
