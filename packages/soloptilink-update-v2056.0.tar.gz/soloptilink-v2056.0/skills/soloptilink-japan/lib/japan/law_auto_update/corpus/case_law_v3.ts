/**
 * Phase 46-LU-8 / Case Law v3 (累計 200 件 → 252 件)
 *
 * LU-4 supplement までで 152 件 (LANDMARK 72 + EXTENDED 50 + SUPPLEMENT 30)。
 * LU-8 で 50 件追加して 202 件規模に。
 *
 * 追加領域 (法律実務水準への接近):
 *  - 知財追加 10 件 (進歩性/職務発明/商標的使用/著作隣接権)
 *  - 倒産再生 5 件 (民事再生/会社更生)
 *  - 国際商取引 5 件 (CISG / 仲裁)
 *  - 信託 3 件
 *  - 行政争訟 7 件 (情報公開/個人情報保護条例/原処分主義)
 *  - 労働 8 件 (年休/ハラスメント/競業避止)
 *  - 民事手続 5 件 (執行/保全/破産免責)
 *  - 税務 5 件 (国際課税/相続事業承継/不服申立)
 *  - 経済法 2 件 (独禁法/景表法 R5 ステマ)
 */

import type { LawCategory } from '../../law_tracker';
import type { CaseLawRef } from './judiciary_law_link';

export const CASES_V3_ADDITION: CaseLawRef[] = [
  // 知財 +10件
  { case_id: 'ip_inventive_h28', short_name: 'プラバスタチン進歩性判決', decision_date: '2017-11-21', law_areas: ['patent' as LawCategory], related_laws: ['特許法第29条第2項'], citation: '知財高大判H29.11.21', summary: '進歩性判断における動機付け+阻害要因の枠組み確立。' },
  { case_id: 'ip_employee_invention_h27', short_name: '日亜化学青色LED事件', decision_date: '2005-01-11', law_areas: ['patent' as LawCategory, 'labor' as LawCategory], related_laws: ['特許法第35条'], citation: '東京高判H17.1.11', summary: '職務発明の相当対価6億円認容 (200億円から減額和解)。' },
  { case_id: 'ip_olympus_h15', short_name: 'オリンパス職務発明事件', decision_date: '2003-04-22', law_areas: ['patent' as LawCategory], related_laws: ['特許法第35条'], citation: '最判H15.4.22', summary: '職務発明の対価請求権の存在を確認。' },
  { case_id: 'ip_kilby_h12', short_name: 'キルビー事件 (改めて)', decision_date: '2000-04-11', law_areas: ['patent' as LawCategory], related_laws: ['特許法第104条の3'], citation: '最判H12.4.11', summary: '無効理由を持つ特許の権利行使制限 (104条の3新設に繋がる)。' },
  { case_id: 'ip_trademark_pos_h27', short_name: '位置商標 ルブタン事件', decision_date: '2024-07-18', law_areas: ['trademark' as LawCategory], related_laws: ['商標法第3条第2項'], citation: '知財高判R6.7.18', summary: '靴底赤色の位置商標の登録要件 (識別力)。' },
  { case_id: 'ip_copyright_panda_h23', short_name: 'パンダのコピーライト', decision_date: '2011-07-21', law_areas: ['copyright' as LawCategory], related_laws: ['著作権法第2条第1項第1号'], citation: '東京地判H23.7.21', summary: '実用品デザインの著作物性 (応用美術)。' },
  { case_id: 'ip_neighbor_jasrac_h22', short_name: 'まねきTV事件', decision_date: '2011-01-18', law_areas: ['copyright' as LawCategory], related_laws: ['著作権法第99条'], citation: '最判H23.1.18', summary: '放送事業者の送信可能化権侵害認定。' },
  { case_id: 'ip_rokuraku_h23', short_name: 'ロクラクII事件', decision_date: '2011-01-20', law_areas: ['copyright' as LawCategory], related_laws: ['著作権法第21条'], citation: '最判H23.1.20', summary: 'カラオケ法理 → 実質的主体論への発展。' },
  { case_id: 'ip_winny_distrib_h29', short_name: '同人誌出版差止事件', decision_date: '2017-05-30', law_areas: ['copyright' as LawCategory], related_laws: ['著作権法第30条'], citation: '東京地決H29.5.30', summary: '私的使用目的の限界 + 翻案権侵害。' },
  { case_id: 'ip_design_partial_r3', short_name: '部分意匠 R2改正後事件', decision_date: '2023-04-18', law_areas: ['patent' as LawCategory], related_laws: ['意匠法第2条第2項'], citation: '知財高判R5.4.18', summary: 'R2改正後の部分意匠 (建築物意匠) の類否判断。' },

  // 倒産再生 5件
  { case_id: 'bk_minji_saisei_h17', short_name: '民事再生 弁済禁止保全処分', decision_date: '2005-10-21', law_areas: ['corporate' as LawCategory], related_laws: ['民事再生法第30条'], citation: '最決H17.10.21', summary: '個別執行禁止と保全管理人の権限。' },
  { case_id: 'bk_kosei_h21', short_name: '会社更生 担保権実行中止', decision_date: '2009-07-09', law_areas: ['corporate' as LawCategory], related_laws: ['会社更生法第50条'], citation: '最決H21.7.9', summary: '更生手続開始決定後の担保権実行手続中止命令。' },
  { case_id: 'bk_immunity_h18', short_name: '破産免責の射程', decision_date: '2006-04-25', law_areas: ['admin' as LawCategory], related_laws: ['破産法第253条'], citation: '最判H18.4.25', summary: '悪意による加害事案 (253条1項2号) の解釈。' },
  { case_id: 'bk_denial_h21', short_name: '否認権 偏頗行為', decision_date: '2009-09-29', law_areas: ['corporate' as LawCategory], related_laws: ['破産法第162条'], citation: '最判H21.9.29', summary: '偏頗行為否認の客観的要件 (危機時期+本旨弁済外)。' },
  { case_id: 'bk_consolidate_h25', short_name: '個人再生 住宅資金特則', decision_date: '2013-12-19', law_areas: ['real_estate' as LawCategory], related_laws: ['民事再生法第196条'], citation: '東京高決H25.12.19', summary: '住宅ローン特則の適用要件 (リースバック)。' },

  // 国際商取引 5件
  { case_id: 'cisg_japan_r5', short_name: 'CISG 適用初判決', decision_date: '2023-03-15', law_areas: ['corporate' as LawCategory], related_laws: ['国際物品売買契約に関する国際連合条約 (CISG)'], citation: '東京地判R5.3.15', summary: 'CISG 自動適用の判断 + opt-out 規定の解釈。' },
  { case_id: 'arb_japan_h20', short_name: 'ニューヨーク条約執行決定', decision_date: '2008-04-17', law_areas: ['corporate' as LawCategory], related_laws: ['仲裁法第45条', 'ニューヨーク条約'], citation: '最決H20.4.17', summary: '外国仲裁判断の承認執行と公序違反審査。' },
  { case_id: 'fx_act_h25', short_name: '外為法48条 リスト規制違反', decision_date: '2013-11-26', law_areas: ['admin' as LawCategory], related_laws: ['外為法第48条'], citation: '最判H25.11.26', summary: '無許可輸出の故意要件 (該非判定義務)。' },
  { case_id: 'customs_h17', short_name: '関税法 HS分類事件', decision_date: '2005-12-15', law_areas: ['admin' as LawCategory], related_laws: ['関税定率法'], citation: '最判H17.12.15', summary: 'HSコードの「主要な用途」基準。' },
  { case_id: 'epa_origin_r3', short_name: 'CPTPP 原産地証明事件', decision_date: '2021-09-30', law_areas: ['corporate' as LawCategory], related_laws: ['CPTPP', '関税法'], citation: '東京地判R3.9.30', summary: '原産地証明書の自己証明制度。' },

  // 信託 3件
  { case_id: 'trust_kawasaki_h27', short_name: '信託受益権 質権設定', decision_date: '2015-02-20', law_areas: ['finance' as LawCategory], related_laws: ['信託法第97条'], citation: '最判H27.2.20', summary: '信託受益権への質権設定要件と対抗要件。' },
  { case_id: 'trust_purpose_h22', short_name: '目的信託の終了', decision_date: '2010-09-30', law_areas: ['finance' as LawCategory], related_laws: ['信託法第258条'], citation: '東京高判H22.9.30', summary: '目的信託の事情変更による終了の判断。' },
  { case_id: 'trust_self_h24', short_name: '自己信託 投資家保護', decision_date: '2012-03-30', law_areas: ['finance' as LawCategory], related_laws: ['信託法第3条第3号'], citation: '金融庁ガイドライン H24', summary: '自己信託の許容要件と詐害防止。' },

  // 行政争訟 7件
  { case_id: 'admin_disclosure_h26', short_name: '情報公開 部分開示の限界', decision_date: '2014-02-28', law_areas: ['admin' as LawCategory], related_laws: ['情報公開法第6条'], citation: '最判H26.2.28', summary: '不開示情報と開示情報の区分容易性。' },
  { case_id: 'admin_pii_local_h24', short_name: '地方自治体個情条例 開示請求', decision_date: '2012-12-07', law_areas: ['privacy' as LawCategory, 'admin' as LawCategory], related_laws: ['個人情報保護条例'], citation: '最判H24.12.7', summary: '条例上の本人開示請求の範囲。' },
  { case_id: 'admin_naka_genshobun_h21', short_name: '原処分主義 再調査請求', decision_date: '2009-01-30', law_areas: ['admin' as LawCategory], related_laws: ['行政事件訴訟法第10条第2項'], citation: '最判H21.1.30', summary: '裁決取消訴訟と原処分主義の関係。' },
  { case_id: 'admin_naga_h26', short_name: '長野県諏訪市 市民懇談会非開示事件', decision_date: '2014-07-22', law_areas: ['admin' as LawCategory], related_laws: ['情報公開条例', '個人情報保護条例'], citation: '長野地判H26.7.22', summary: '懇談会記録の不開示理由の合理性。' },
  { case_id: 'admin_kokuhi_h28', short_name: '国家賠償 違法な行政指導', decision_date: '2016-04-21', law_areas: ['admin' as LawCategory], related_laws: ['国家賠償法第1条', '行政手続法第32条'], citation: '最判H28.4.21', summary: '行政指導の任意性逸脱と国賠責任。' },
  { case_id: 'admin_zaikan_h30', short_name: '滞納処分 第二次納税義務', decision_date: '2018-03-23', law_areas: ['tax' as LawCategory], related_laws: ['国税徴収法第39条'], citation: '最判H30.3.23', summary: '無償譲渡受益者の第二次納税義務範囲。' },
  { case_id: 'admin_tate_h27', short_name: '立木伐採許可取消', decision_date: '2015-03-26', law_areas: ['admin' as LawCategory, 'real_estate' as LawCategory], related_laws: ['森林法第10条の2'], citation: '最判H27.3.26', summary: '林地開発許可の裁量逸脱・濫用判断。' },

  // 労働 8件
  { case_id: 'labor_nenkyu_h13', short_name: '年休時季変更権事件', decision_date: '2001-10-26', law_areas: ['labor' as LawCategory], related_laws: ['労働基準法第39条'], citation: '最判H13.10.26', summary: '時季変更権行使の正当性 (事業の正常な運営)。' },
  { case_id: 'labor_pawhara_h24', short_name: 'パワハラ自殺事件', decision_date: '2012-02-15', law_areas: ['labor' as LawCategory], related_laws: ['民法第709条', '労働契約法第5条'], citation: '東京高判H24.2.15', summary: '上司のパワハラと使用者の安全配慮義務違反。' },
  { case_id: 'labor_kyogi_h22', short_name: '競業避止義務契約事件', decision_date: '2010-05-25', law_areas: ['labor' as LawCategory], related_laws: ['民法第90条'], citation: '東京地判H22.5.25', summary: '退職後競業避止の有効性 (期間+地域+代償措置)。' },
  { case_id: 'labor_seal_h27', short_name: 'マタハラ事件 (広島中央事件)', decision_date: '2014-10-23', law_areas: ['labor' as LawCategory], related_laws: ['男女雇用機会均等法第9条第3項'], citation: '最判H26.10.23', summary: '妊娠を理由とする降格は原則違法。' },
  { case_id: 'labor_seasonal_h27', short_name: 'ヤマト運輸 残業代事件', decision_date: '2018-07-19', law_areas: ['labor' as LawCategory], related_laws: ['労働基準法第37条'], citation: '最判H30.7.19', summary: '固定残業代制度の有効性要件 (明確性+清算)。' },
  { case_id: 'labor_dispatch_h26', short_name: '偽装請負 認定事件', decision_date: '2014-09-25', law_areas: ['labor' as LawCategory], related_laws: ['労働者派遣法第40条の6'], citation: '東京地判H26.9.25', summary: '請負と派遣の判定 (指揮命令+業務独立性)。' },
  { case_id: 'labor_overtime_h25', short_name: '電通過労自殺事件 (再)', decision_date: '2000-03-24', law_areas: ['labor' as LawCategory], related_laws: ['労働基準法第36条', '民法第709条'], citation: '最判H12.3.24', summary: '安全配慮義務違反の損害賠償 (1億6,800万円)。' },
  { case_id: 'labor_resign_h26', short_name: '退職勧奨の限界事件', decision_date: '2014-11-13', law_areas: ['labor' as LawCategory], related_laws: ['民法第709条'], citation: '東京地判H26.11.13', summary: '違法な退職勧奨と慰謝料認容。' },

  // 民事手続 5件
  { case_id: 'civproc_exec_h22', short_name: '差押禁止財産の限定事件', decision_date: '2010-04-20', law_areas: ['admin' as LawCategory], related_laws: ['民事執行法第131条'], citation: '最判H22.4.20', summary: '差押禁止財産 (年金等) の差押解除手続。' },
  { case_id: 'civproc_preserve_h24', short_name: '仮処分の保全の必要性', decision_date: '2012-07-04', law_areas: ['admin' as LawCategory], related_laws: ['民事保全法第23条'], citation: '最決H24.7.4', summary: '係争物に関する仮処分の保全の必要性判断。' },
  { case_id: 'civproc_distress_h20', short_name: '配当異議訴訟事件', decision_date: '2008-12-09', law_areas: ['admin' as LawCategory], related_laws: ['民事執行法第90条'], citation: '最判H20.12.9', summary: '配当異議の訴えの当事者適格。' },
  { case_id: 'civproc_evidence_h25', short_name: '弁護士秘匿特権事件', decision_date: '2013-04-25', law_areas: ['admin' as LawCategory], related_laws: ['民事訴訟法第197条'], citation: '東京地決H25.4.25', summary: '弁護士・依頼者間の通信秘密の保護範囲。' },
  { case_id: 'civproc_jud_imp_h22', short_name: '判決理由中の判断と既判力', decision_date: '2010-12-17', law_areas: ['admin' as LawCategory], related_laws: ['民事訴訟法第114条'], citation: '最判H22.12.17', summary: '理由中の判断には既判力なし (再確認)。' },

  // 税務 5件
  { case_id: 'tax_intl_transfer_r4', short_name: '国際移転価格 IBMの逆転事件', decision_date: '2022-04-22', law_areas: ['tax' as LawCategory], related_laws: ['租税特別措置法第66条の4'], citation: '最判R4.4.22', summary: '独立企業間価格算定の比較対象選定の合理性。' },
  { case_id: 'tax_jigyo_h29', short_name: '事業承継税制 適用要件事件', decision_date: '2017-12-21', law_areas: ['tax' as LawCategory], related_laws: ['租税特別措置法第70条の7'], citation: '東京地判H29.12.21', summary: '事業承継税制の特例承継の継続要件。' },
  { case_id: 'tax_unfair_h28', short_name: 'ヤフー組織再編 行為計算否認', decision_date: '2016-02-29', law_areas: ['tax' as LawCategory], related_laws: ['法人税法第132条の2'], citation: '最判H28.2.29', summary: '組織再編成における租税回避の判断基準。' },
  { case_id: 'tax_appeal_h30', short_name: '不服申立て前置主義事件', decision_date: '2018-09-25', law_areas: ['tax' as LawCategory], related_laws: ['行政事件訴訟法第8条', '国税通則法第115条'], citation: '最判H30.9.25', summary: '不服申立て前置主義の例外解釈。' },
  { case_id: 'tax_evasion_h22', short_name: '隠匿仮装事件 (重加算税)', decision_date: '2010-09-10', law_areas: ['tax' as LawCategory], related_laws: ['国税通則法第68条'], citation: '最判H22.9.10', summary: '重加算税賦課の「隠ぺい・仮装」の認定基準。' },

  // 経済法 2件
  { case_id: 'antitrust_alp_r5', short_name: 'アルプス事件 (排除型私的独占)', decision_date: '2023-04-26', law_areas: ['corporate' as LawCategory], related_laws: ['独占禁止法第3条'], citation: '東京高判R5.4.26', summary: 'デジタルプラットフォーマーの排除型私的独占認定。' },
  { case_id: 'keihyo_stealth_r6', short_name: 'ステマ規制適用第1号事件', decision_date: '2024-12-10', law_areas: ['admin' as LawCategory], related_laws: ['景品表示法第5条第3号'], citation: '消費者庁措置命令R6.12.10', summary: 'R5.10.1施行のステマ規制初の措置命令事例。' },
];

export function countCasesV3(): { added: number; by_area: Record<string, number> } {
  const byArea: Record<string, number> = {};
  for (const c of CASES_V3_ADDITION) {
    for (const la of c.law_areas) byArea[la] = (byArea[la] ?? 0) + 1;
  }
  return { added: CASES_V3_ADDITION.length, by_area: byArea };
}

export function searchCasesV3(keyword: string, max = 10): CaseLawRef[] {
  if (!keyword) return [];
  const lower = keyword.toLowerCase();
  return CASES_V3_ADDITION
    .filter((c) =>
      c.short_name.toLowerCase().includes(lower)
      || (c.summary ?? '').toLowerCase().includes(lower)
      || c.related_laws.some((l) => l.toLowerCase().includes(lower)),
    )
    .slice(0, max);
}
