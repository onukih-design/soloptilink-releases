/**
 * Phase 46-LU-7 / API Marketplace
 *
 * 第三者ベンダーが Phase 46-LU の機能を組み合わせて作った
 * 「アプリ」「データソース」「ワークフロー」「契約テンプレ集」を
 * マーケットプレイスに出品・購入できる機構。
 *
 *  - 出品物の種別 (App / DataSource / Workflow / Template / Industry Pack)
 *  - 価格モデル (買切 / 月額 / 従量)
 *  - 承認フロー (Pending → Approved → Published)
 *  - レビュー・評価
 *  - 売上分配 (Revenue Share = ベンダー 70% / SoloptiLinkAI 30%)
 */

export type ListingKind = 'app' | 'data_source' | 'workflow' | 'template_pack' | 'industry_pack';
export type PriceModel = 'one_time' | 'monthly' | 'usage';

export interface MarketplaceListing {
  listing_id: string;
  vendor_id: string;
  vendor_display_name: string;
  title: string;
  kind: ListingKind;
  description: string;
  /** 価格 */
  price_model: PriceModel;
  price_jpy: number;
  /** 試用期間 (日) */
  trial_days?: number;
  /** カテゴリタグ */
  tags: string[];
  /** 対応プラン */
  supported_plans: Array<'pro' | 'enterprise' | 'legal_firm'>;
  /** 必要権限 */
  required_permissions: string[];
  /** バージョン */
  version: string;
  /** スクリーンショット URL */
  screenshots?: string[];
  /** ドキュメント URL */
  documentation_url?: string;
  /** プライバシーポリシー URL */
  privacy_policy_url: string;
  /** 状態 */
  status: 'draft' | 'pending_review' | 'approved' | 'published' | 'suspended' | 'deprecated';
  /** 出品日 */
  submitted_at: string;
  /** 公開日 */
  published_at?: string;
  /** インストール数 */
  install_count: number;
  /** 評価 */
  rating_avg?: number;
  rating_count?: number;
  /** 売上 (累計) */
  gross_revenue_jpy: number;
}

const LISTINGS = new Map<string, MarketplaceListing>();

/**
 * 出品 (Pending 状態で受付、レビュー後 Approved)
 */
export function submitListing(input: {
  vendor_id: string;
  vendor_display_name: string;
  title: string;
  kind: ListingKind;
  description: string;
  price_model: PriceModel;
  price_jpy: number;
  trial_days?: number;
  tags: string[];
  supported_plans: MarketplaceListing['supported_plans'];
  required_permissions: string[];
  version: string;
  privacy_policy_url: string;
}): MarketplaceListing {
  const listing: MarketplaceListing = {
    listing_id: `lst_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    ...input,
    status: 'pending_review',
    submitted_at: new Date().toISOString(),
    install_count: 0,
    gross_revenue_jpy: 0,
  };
  LISTINGS.set(listing.listing_id, listing);
  return listing;
}

export function approveListing(listing_id: string): boolean {
  const l = LISTINGS.get(listing_id);
  if (!l) return false;
  if (l.status !== 'pending_review') return false;
  l.status = 'approved';
  return true;
}

export function publishListing(listing_id: string): boolean {
  const l = LISTINGS.get(listing_id);
  if (!l) return false;
  if (l.status !== 'approved') return false;
  l.status = 'published';
  l.published_at = new Date().toISOString();
  return true;
}

export function suspendListing(listing_id: string, reason: string): boolean {
  const l = LISTINGS.get(listing_id);
  if (!l) return false;
  l.status = 'suspended';
  return true;
}

/**
 * インストール記録
 */
export interface Installation {
  installation_id: string;
  listing_id: string;
  tenant_id: string;
  installed_at: string;
  status: 'active' | 'trial' | 'cancelled';
  trial_ends_at?: string;
}

const INSTALLATIONS = new Map<string, Installation>();

export function installListing(input: { listing_id: string; tenant_id: string; is_trial?: boolean }): { ok: true; installation: Installation } | { ok: false; error: string } {
  const listing = LISTINGS.get(input.listing_id);
  if (!listing) return { ok: false, error: 'listing not found' };
  if (listing.status !== 'published') return { ok: false, error: `listing status=${listing.status}` };

  const inst: Installation = {
    installation_id: `inst_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    listing_id: input.listing_id,
    tenant_id: input.tenant_id,
    installed_at: new Date().toISOString(),
    status: input.is_trial ? 'trial' : 'active',
  };
  if (input.is_trial && listing.trial_days) {
    const trialEnd = new Date();
    trialEnd.setDate(trialEnd.getDate() + listing.trial_days);
    inst.trial_ends_at = trialEnd.toISOString();
  }
  INSTALLATIONS.set(inst.installation_id, inst);
  listing.install_count++;
  return { ok: true, installation: inst };
}

/**
 * 売上計上 + ベンダー分配計算
 */
export interface RevenueShare {
  listing_id: string;
  gross_jpy: number;
  vendor_payout_jpy: number;
  platform_fee_jpy: number;
  period: string; // YYYY-MM
}

const VENDOR_REVENUE_SHARE_PCT = 70; // ベンダー 70% / プラットフォーム 30%

export function recordRevenue(input: { listing_id: string; amount_jpy: number; period?: string }): RevenueShare | undefined {
  const l = LISTINGS.get(input.listing_id);
  if (!l) return undefined;
  const vendorPayout = Math.floor(input.amount_jpy * VENDOR_REVENUE_SHARE_PCT / 100);
  const platformFee = input.amount_jpy - vendorPayout;
  l.gross_revenue_jpy += input.amount_jpy;
  return {
    listing_id: input.listing_id,
    gross_jpy: input.amount_jpy,
    vendor_payout_jpy: vendorPayout,
    platform_fee_jpy: platformFee,
    period: input.period ?? new Date().toISOString().slice(0, 7),
  };
}

/**
 * 検索・フィルタ
 */
export interface SearchInput {
  query?: string;
  kind?: ListingKind;
  tags?: string[];
  max_price_jpy?: number;
  price_model?: PriceModel;
  supported_plan?: 'pro' | 'enterprise' | 'legal_firm';
}

export function searchListings(input: SearchInput, top_k = 20): MarketplaceListing[] {
  let results = [...LISTINGS.values()].filter((l) => l.status === 'published');
  if (input.kind) results = results.filter((l) => l.kind === input.kind);
  if (input.tags && input.tags.length > 0) {
    results = results.filter((l) => input.tags!.some((t) => l.tags.includes(t)));
  }
  if (input.max_price_jpy !== undefined) results = results.filter((l) => l.price_jpy <= input.max_price_jpy!);
  if (input.price_model) results = results.filter((l) => l.price_model === input.price_model);
  if (input.supported_plan) results = results.filter((l) => l.supported_plans.includes(input.supported_plan!));
  if (input.query) {
    const q = input.query.toLowerCase();
    results = results.filter((l) => l.title.toLowerCase().includes(q) || l.description.toLowerCase().includes(q));
  }
  return results.sort((a, b) => b.install_count - a.install_count).slice(0, top_k);
}

/**
 * 内蔵サンプル出品物
 */
export const FEATURED_LISTINGS: MarketplaceListing[] = [
  {
    listing_id: 'feat_001',
    vendor_id: 'vendor_solinx',
    vendor_display_name: 'SolInx Compliance Inc.',
    title: '医療業界 コンプライアンスパック (3省2GL + 薬機法 + 個情医療例外)',
    kind: 'industry_pack',
    description: '医療法人/医療系SaaS事業者向けに 3省2GL/薬機法/PHR/医療データ越境移転を含む統合パック',
    price_model: 'monthly',
    price_jpy: 49800,
    trial_days: 14,
    tags: ['医療', '3省2GL', '薬機法', 'PHR'],
    supported_plans: ['enterprise', 'legal_firm'],
    required_permissions: ['read:cases', 'invoke:rag', 'write:compliance_rules'],
    version: '1.0.0',
    privacy_policy_url: 'https://solinx.example.com/privacy',
    status: 'published',
    submitted_at: '2026-04-01T00:00:00Z',
    published_at: '2026-04-15T00:00:00Z',
    install_count: 87,
    rating_avg: 4.6,
    rating_count: 23,
    gross_revenue_jpy: 4_330_600,
  },
  {
    listing_id: 'feat_002',
    vendor_id: 'vendor_finguard',
    vendor_display_name: 'FinGuard Co.',
    title: '金融機関向け FISC + 金商法 + 適合性原則 ワークフローパック',
    kind: 'workflow',
    description: 'FISC安全対策基準/金商法適合性原則/AML を統合した金融機関ワークフロー',
    price_model: 'monthly',
    price_jpy: 79800,
    trial_days: 30,
    tags: ['金融', 'FISC', '金商法', 'AML'],
    supported_plans: ['enterprise', 'legal_firm'],
    required_permissions: ['read:cases', 'invoke:rag', 'invoke:risk'],
    version: '2.1.0',
    privacy_policy_url: 'https://finguard.example.com/privacy',
    status: 'published',
    submitted_at: '2026-03-01T00:00:00Z',
    published_at: '2026-03-20T00:00:00Z',
    install_count: 42,
    rating_avg: 4.8,
    rating_count: 18,
    gross_revenue_jpy: 3_351_600,
  },
  {
    listing_id: 'feat_003',
    vendor_id: 'vendor_construct',
    vendor_display_name: 'ConstructLegal LLC',
    title: '建設業 契約書テンプレ集 (元請/下請/JV/業務委託 50テンプレ)',
    kind: 'template_pack',
    description: 'R6 建設業法改正対応の契約書 50 種類',
    price_model: 'one_time',
    price_jpy: 198000,
    tags: ['建設業', 'R6改正', '元請下請', '工期'],
    supported_plans: ['pro', 'enterprise', 'legal_firm'],
    required_permissions: ['read:cases', 'write:contracts'],
    version: '1.2.0',
    privacy_policy_url: 'https://constructlegal.example.com/privacy',
    status: 'published',
    submitted_at: '2026-02-01T00:00:00Z',
    published_at: '2026-02-15T00:00:00Z',
    install_count: 134,
    rating_avg: 4.4,
    rating_count: 51,
    gross_revenue_jpy: 26_532_000,
  },
];

export function loadFeaturedListings(): void {
  for (const l of FEATURED_LISTINGS) LISTINGS.set(l.listing_id, l);
}

export function countListings(): { total: number; by_status: Record<string, number>; by_kind: Record<string, number>; total_gross_jpy: number } {
  const byStatus: Record<string, number> = {};
  const byKind: Record<string, number> = {};
  let gross = 0;
  for (const l of LISTINGS.values()) {
    byStatus[l.status] = (byStatus[l.status] ?? 0) + 1;
    byKind[l.kind] = (byKind[l.kind] ?? 0) + 1;
    gross += l.gross_revenue_jpy;
  }
  return { total: LISTINGS.size, by_status: byStatus, by_kind: byKind, total_gross_jpy: gross };
}

export function _resetMarketplaceForTests(): void {
  LISTINGS.clear();
  INSTALLATIONS.clear();
}
