/**
 * Phase 46-LU-4 / 政令市・中核市 主要条例
 *
 * 政令市20+中核市10+特別区23 から代表条例を抽出。
 * 都道府県条例だけではカバーできない自治体固有規制 (路上喫煙/受動喫煙/民泊上乗せ/景観高度 等)。
 */

export interface MunicipalOrdinance {
  municipality: string;
  rank: 'designated_city' | 'core_city' | 'special_ward' | 'general_city';
  ordinance_name: string;
  short_name: string;
  effective_date: string;
  key_provisions: Record<string, string>;
  typical_penalty: string;
}

export const MUNICIPAL_ORDINANCES: MunicipalOrdinance[] = [
  {
    municipality: '東京都千代田区',
    rank: 'special_ward',
    ordinance_name: '生活環境条例 (路上喫煙禁止)',
    short_name: '千代田区路上喫煙禁止',
    effective_date: '2002-10-01',
    key_provisions: {
      '対象': '路上喫煙禁止地区',
      '違反': '指定地区での歩行喫煙/吸殻投棄',
      '過料': '2,000円',
      '受動喫煙防止強化': 'R元.5 健康増進法改正対応',
    },
    typical_penalty: '路上喫煙: 2,000円の過料',
  },
  {
    municipality: '東京都新宿区',
    rank: 'special_ward',
    ordinance_name: '歌舞伎町クリーン作戦推進条例',
    short_name: '歌舞伎町クリーン作戦',
    effective_date: '2014-04-01',
    key_provisions: {
      '客引き禁止': '飲食店/風俗店の客引き行為禁止',
      '違反者氏名公表': '繰り返し違反者の公表',
      '罰則': '5万円以下の過料',
    },
    typical_penalty: '5万円以下の過料',
  },
  {
    municipality: '京都市',
    rank: 'designated_city',
    ordinance_name: '京都市市街地景観整備条例',
    short_name: '京都市景観条例',
    effective_date: '1972-10-01 (随時改正)',
    key_provisions: {
      '高さ規制': '都心部 31m / 三方斜面 10-15m / 歴史的市街地 12m',
      '色彩基準': 'マンセル彩度4以下推奨',
      '屋外広告物': 'H26.8.31 完全規制 (屋上広告原則禁止)',
      '伝統的建造物群保存地区': '産寧坂・祇園新橋・嵯峨鳥居本・上賀茂',
      '高度地区': '8 種類',
      '事前協議': '届出 30 日前',
    },
    typical_penalty: '是正命令違反: 50万円以下の罰金 / 行政代執行',
  },
  {
    municipality: '大阪市',
    rank: 'designated_city',
    ordinance_name: '大阪市路上喫煙の防止に関する条例',
    short_name: '大阪市路上喫煙禁止',
    effective_date: '2007-10-01',
    key_provisions: {
      '禁止地区': 'JR大阪駅周辺/難波/天王寺等',
      '過料': '1,000円',
    },
    typical_penalty: '1,000円の過料',
  },
  {
    municipality: '横浜市',
    rank: 'designated_city',
    ordinance_name: '横浜市民泊条例',
    short_name: '横浜市民泊上乗せ',
    effective_date: '2018-06-15',
    key_provisions: {
      '住居専用地域 平日上限': '住宅宿泊事業法 180日のうち + 月-木 営業禁止',
      '近隣説明': '事業開始10日前の近隣住民説明義務',
      '管理・苦情対応': '30分以内の駆けつけ義務',
    },
    typical_penalty: '住宅宿泊事業法に準じる',
  },
  {
    municipality: '京都市',
    rank: 'designated_city',
    ordinance_name: '京都市旅館業法施行条例 + 民泊条例',
    short_name: '京都市民泊上乗せ',
    effective_date: '2018-06-15',
    key_provisions: {
      '営業期間制限': '住居専用地域は 1-3月のみ営業可',
      '駆けつけ': '徒歩10分以内',
      '近隣説明': '7日前までの周辺住民通知',
      '宿泊税': '20,000円未満 200円 / 50,000円未満 500円 / 50,000円以上 1,000円',
    },
    typical_penalty: '住宅宿泊事業法+宿泊税条例',
  },
  {
    municipality: '札幌市',
    rank: 'designated_city',
    ordinance_name: '札幌市受動喫煙防止条例',
    short_name: '札幌市受動喫煙防止',
    effective_date: '2017-04-01',
    key_provisions: {
      '官公庁敷地内全面禁煙': 'R元.4 から (健康増進法より先行)',
      '飲食店義務': '原則禁煙 (喫煙専用室の例外あり)',
      '飲食店の表示違反': '5万円以下の過料',
    },
    typical_penalty: '5万円以下の過料',
  },
  {
    municipality: '神戸市',
    rank: 'designated_city',
    ordinance_name: '神戸市路上喫煙の防止等に関する条例',
    short_name: '神戸市路上喫煙禁止',
    effective_date: '2008-07-01',
    key_provisions: {
      '禁止地区': '三宮駅周辺/元町駅周辺',
      '過料': '1,000円',
      '飲食店制限': 'R元.7 受動喫煙防止 (店舗面積30㎡以下飲食店は喫煙可)',
    },
    typical_penalty: '1,000円の過料',
  },
  {
    municipality: '名古屋市',
    rank: 'designated_city',
    ordinance_name: '名古屋市路上喫煙の防止に関する条例',
    short_name: '名古屋市路上喫煙禁止',
    effective_date: '2008-04-01',
    key_provisions: {
      '禁止地区': '名駅・栄・金山駅周辺',
      '過料': '2,000円',
    },
    typical_penalty: '2,000円の過料',
  },
  {
    municipality: '北海道ニセコ町',
    rank: 'general_city',
    ordinance_name: 'ニセコ町まちづくり基本条例',
    short_name: 'ニセコ町まちづくり基本',
    effective_date: '2001-04-01',
    key_provisions: {
      '日本初の自治基本条例': '2001年制定 全国モデル',
      '住民参加': '条例案作成段階からの住民参加権',
      '情報公開': '行政情報の全面公開原則',
      '住民投票': '住民投票制度の設置',
    },
    typical_penalty: 'なし (理念条例)',
  },
];

export const DESIGNATED_CITIES_20 = [
  '札幌市', '仙台市', 'さいたま市', '千葉市', '横浜市', '川崎市', '相模原市',
  '新潟市', '静岡市', '浜松市', '名古屋市', '京都市', '大阪市', '堺市',
  '神戸市', '岡山市', '広島市', '北九州市', '福岡市', '熊本市',
];

export function findOrdinancesByMunicipality(name: string): MunicipalOrdinance[] {
  return MUNICIPAL_ORDINANCES.filter((o) => o.municipality === name);
}

export function findOrdinancesByRank(rank: MunicipalOrdinance['rank']): MunicipalOrdinance[] {
  return MUNICIPAL_ORDINANCES.filter((o) => o.rank === rank);
}

export function countMunicipalOrdinances(): {
  total: number;
  by_rank: Record<string, number>;
  designated_cities: number;
} {
  const byRank: Record<string, number> = {};
  for (const o of MUNICIPAL_ORDINANCES) byRank[o.rank] = (byRank[o.rank] ?? 0) + 1;
  return {
    total: MUNICIPAL_ORDINANCES.length,
    by_rank: byRank,
    designated_cities: DESIGNATED_CITIES_20.length,
  };
}
