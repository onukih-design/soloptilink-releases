/**
 * Phase 46-LU-5 / Case to Current Law Mapping
 *
 * 旧判例 (改正前の法律で判示されたもの) の論点を現行条文にマッピングする。
 * 例: 民法瑕疵担保 (旧562条) → 民法R2.4 契約不適合責任 (現562-572条) への移行
 *
 * 用途:
 *  - 古い判例の現代的射程を把握
 *  - 改正後の新条文に既存判例がどう適用されるか予測
 *  - 教科書記述と現行法のズレを補完
 */

export interface CaseToCurrentLawMapping {
  case_id: string;
  short_name: string;
  /** 判決当時の根拠条文 */
  original_provisions: string[];
  /** 改正後の対応条文 */
  current_provisions: string[];
  /** マッピング種別 */
  mapping_kind: 'direct_renumbering' | 'substantive_change' | 'split' | 'merged' | 'repealed_replaced' | 'unchanged';
  /** 解説 */
  notes: string;
}

export const CASE_TO_CURRENT_LAW_MAPPINGS: CaseToCurrentLawMapping[] = [
  // ============ 民法債権法改正 (R2.4) ============
  {
    case_id: 'civ_construction_h6',
    short_name: '請負契約と契約不適合',
    original_provisions: ['民法旧634条 (瑕疵担保)', '民法旧635条', '民法旧636条', '民法旧637条', '民法旧638条'],
    current_provisions: ['民法第562条 (契約不適合)', '民法第564条 (代金減額)', '民法第636条', '民法第415条 (損害賠償)'],
    mapping_kind: 'substantive_change',
    notes: 'R2.4 改正で瑕疵担保責任は契約不適合責任に統合。判旨の射程は維持されるが、損害賠償・解除の要件が変化。',
  },
  {
    case_id: 'civ_inteki_s51',
    short_name: '消費貸借と相殺事件',
    original_provisions: ['民法旧509条 (差押禁止)'],
    current_provisions: ['民法第509条 (R2.4改正で人身傷害+悪意の不法行為に限定)'],
    mapping_kind: 'substantive_change',
    notes: 'R2.4 改正で509条相殺禁止の範囲が限定。本判例の射程は人身傷害事案に限定的に適用。',
  },
  {
    case_id: 'civ_zeniya_h11',
    short_name: '抵当不動産競売と賃借権',
    original_provisions: ['民法旧395条 (短期賃貸借保護)'],
    current_provisions: ['民法第395条 (R3改正で削除・建物明渡猶予に変更)'],
    mapping_kind: 'repealed_replaced',
    notes: '短期賃貸借保護制度は撤廃。現行は建物明渡猶予制度 (6ヶ月) に変更。',
  },

  // ============ 民法相続法改正 (R元.7) ============
  {
    case_id: 'civ_kahei_h28',
    short_name: '婚姻準正と認知の遡及効',
    original_provisions: ['民法第784条', '国籍法旧3条 (違憲判決前)'],
    current_provisions: ['民法第784条 (変更なし)', '国籍法第3条 (H20改正後)'],
    mapping_kind: 'unchanged',
    notes: '判旨は維持。ただし国籍法3条1項は最大判H20.6.4で違憲判決 → 改正済。',
  },

  // ============ 労契法 → パート有期労働法 ============
  {
    case_id: 'hamakyo_rex_H30',
    short_name: 'ハマキョウレックス事件',
    original_provisions: ['労働契約法旧第20条 (不合理な労働条件の禁止)'],
    current_provisions: ['パートタイム・有期雇用労働法第8条 (均衡待遇)'],
    mapping_kind: 'direct_renumbering',
    notes: 'R2.4 施行のパート有期労働法8条に移管。判旨の判断枠組みは同一。',
  },
  {
    case_id: 'nagasawa_unyu_H30',
    short_name: '長澤運輸事件',
    original_provisions: ['労働契約法旧第20条'],
    current_provisions: ['パートタイム・有期雇用労働法第8条'],
    mapping_kind: 'direct_renumbering',
    notes: 'R2.4 施行で労契法20条 → パート有期労働法8条に移管。',
  },
  {
    case_id: 'osaka_iyaku_R2',
    short_name: '大阪医科薬科事件',
    original_provisions: ['労働契約法旧第20条'],
    current_provisions: ['パートタイム・有期雇用労働法第8条'],
    mapping_kind: 'direct_renumbering',
    notes: '同上。R2.10.13判決は移管直後の重要判例。',
  },

  // ============ 個情法 ============
  {
    case_id: 'benesse_pii',
    short_name: 'ベネッセ事件',
    original_provisions: ['個情法旧第28条 (本人開示請求)', '民法第709条'],
    current_provisions: ['個情法第26条 (R4改正・漏えい等の報告)', '個情法第33-37条 (本人開示)', '民法第709条'],
    mapping_kind: 'split',
    notes: 'R4改正で漏えい報告義務が新設 (26条)。本事案発生時 (H26) は本人通知のみ義務だったが、現在は個情委への72h報告義務が追加。',
  },

  // ============ 刑法 ============
  {
    case_id: 'osumiri_S43',
    short_name: '尊属殺重罰規定違憲訴訟',
    original_provisions: ['刑法旧200条 (尊属殺)'],
    current_provisions: ['刑法第199条 (殺人)'],
    mapping_kind: 'repealed_replaced',
    notes: '違憲判決後、H7改正で200条削除。現行は199条のみで殺人罪を構成。',
  },

  // ============ 会社法 ============
  {
    case_id: 'yawata_seitetsu_S45',
    short_name: '八幡製鉄政治献金事件',
    original_provisions: ['商法旧第43条 (権利能力)', '民法第643条'],
    current_provisions: ['会社法第4条 (権利能力)', '会社法第330条 (取締役善管注意義務)'],
    mapping_kind: 'direct_renumbering',
    notes: 'H17会社法制定で商法分離。会社の権利能力範囲は4条で明文化。',
  },

  // ============ 公務員法 ============
  {
    case_id: 'sarufuto_S49',
    short_name: '猿払事件',
    original_provisions: ['国家公務員法第102条', '人事院規則14-7'],
    current_provisions: ['国家公務員法第102条 (変更なし)'],
    mapping_kind: 'unchanged',
    notes: '102条は変更なし。ただし堀越事件 (H24) で射程が限定的に解釈されている。',
  },
  {
    case_id: 'horikoshi_H24',
    short_name: '堀越事件',
    original_provisions: ['国家公務員法第102条'],
    current_provisions: ['国家公務員法第102条 (変更なし、解釈論で発展)'],
    mapping_kind: 'unchanged',
    notes: '猿払事件の射程を「職務関連性なき政治活動」に限定。条文は同じだが解釈が変化。',
  },

  // ============ 著作権 ============
  {
    case_id: 'ip_winny_h23',
    short_name: 'Winny事件',
    original_provisions: ['著作権法旧第30条', '刑法第62条 (幇助犯)'],
    current_provisions: ['著作権法第30条', '著作権法第30条の4 (H30改正・情報解析)', '刑法第62条'],
    mapping_kind: 'split',
    notes: 'H30改正で「情報解析」目的の利用が30条の4で新設。Winny判決後の立法対応。',
  },

  // ============ 消費者契約法 ============
  {
    case_id: 'koshinryo_H23',
    short_name: '更新料事件',
    original_provisions: ['消費者契約法旧第10条'],
    current_provisions: ['消費者契約法第10条 (H30改正で要件明確化)'],
    mapping_kind: 'substantive_change',
    notes: 'H30改正で10条の要件が明確化 (任意規定との比較)。判旨の射程は維持されるが、判断要素が整理。',
  },

  // ============ 商法 → 会社法分離 ============
  {
    case_id: 'civ_pierce_corporate_S44',
    short_name: '法人格濫用',
    original_provisions: ['商法旧第54条 (会社設立)', '民法第1条第3項'],
    current_provisions: ['会社法第3条', '民法第1条第3項'],
    mapping_kind: 'direct_renumbering',
    notes: 'H17会社法制定で商法から分離。法人格否認の法理自体は判例法理として現在も適用。',
  },

  // ============ 環境法 ============
  {
    case_id: 'env_minamata_S48',
    short_name: '熊本水俣病訴訟',
    original_provisions: ['民法第709条', '公害健康被害補償法 (S48制定)'],
    current_provisions: ['民法第709条 (R2改正で時効起算点明確化)', '公害健康被害補償法 (現行)'],
    mapping_kind: 'substantive_change',
    notes: '時効起算点 (民法724条) がR2改正で明確化。長期20年の起算点問題が解消。',
  },
];

export function findMappingByCase(caseId: string): CaseToCurrentLawMapping | undefined {
  return CASE_TO_CURRENT_LAW_MAPPINGS.find((m) => m.case_id === caseId);
}

export function findMappingsByCurrentProvision(provision: string): CaseToCurrentLawMapping[] {
  const lower = provision.toLowerCase();
  return CASE_TO_CURRENT_LAW_MAPPINGS.filter((m) =>
    m.current_provisions.some((p) => p.toLowerCase().includes(lower)),
  );
}

export function listMappingsByKind(kind: CaseToCurrentLawMapping['mapping_kind']): CaseToCurrentLawMapping[] {
  return CASE_TO_CURRENT_LAW_MAPPINGS.filter((m) => m.mapping_kind === kind);
}

export function countMappings(): {
  total: number;
  by_kind: Record<CaseToCurrentLawMapping['mapping_kind'], number>;
} {
  const byKind: Record<string, number> = {};
  for (const m of CASE_TO_CURRENT_LAW_MAPPINGS) {
    byKind[m.mapping_kind] = (byKind[m.mapping_kind] ?? 0) + 1;
  }
  return {
    total: CASE_TO_CURRENT_LAW_MAPPINGS.length,
    by_kind: byKind as Record<CaseToCurrentLawMapping['mapping_kind'], number>,
  };
}

export function renderMappingReport(): string {
  const lines: string[] = [];
  const c = countMappings();
  lines.push('# 旧判例 → 現行法 マッピング');
  lines.push('');
  lines.push(`総マッピング: ${c.total}件`);
  lines.push('');
  lines.push('## 種別内訳');
  for (const [kind, n] of Object.entries(c.by_kind)) {
    lines.push(`- ${kind}: ${n}件`);
  }
  lines.push('');
  lines.push('## マッピング詳細');
  for (const m of CASE_TO_CURRENT_LAW_MAPPINGS.slice(0, 20)) {
    lines.push(`### ${m.short_name}`);
    lines.push(`- 旧条文: ${m.original_provisions.join(' / ')}`);
    lines.push(`- 現行: ${m.current_provisions.join(' / ')}`);
    lines.push(`- 種別: ${m.mapping_kind}`);
    lines.push(`- 解説: ${m.notes}`);
    lines.push('');
  }
  return lines.join('\n');
}
