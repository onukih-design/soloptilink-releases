/**
 * Phase 46-LU-7 / Regulatory Radar — 法改正予測エンジン
 *
 * パブコメ・規制改革推進会議・与党議連・有識者会議の動向から
 * 「いつ・どの法令が・どう改正されるか」を予測する。
 *
 *  - パブコメ → 公布までの平均期間 (6-12ヶ月)
 *  - 与党議連設置 → 法案提出までの動き
 *  - 有識者会議報告書 → 改正方針確定
 *  - 過去の改正パターン学習で確度推定
 */

export type RegulatorySignalKind =
  | 'public_comment'
  | 'expert_council_report'
  | 'ruling_party_meeting'
  | 'cabinet_decision'
  | 'bill_submitted'
  | 'committee_review'
  | 'enacted'
  | 'effective';

export interface RegulatorySignal {
  signal_id: string;
  signal_kind: RegulatorySignalKind;
  observed_at: string;
  /** 対象法令 (推定) */
  target_laws: string[];
  /** 主管省庁 */
  competent_ministry: string;
  /** 信号源 URL */
  source_url?: string;
  /** タイトル */
  title: string;
  /** 要約 */
  summary?: string;
  /** 改正方向 */
  amendment_direction?: 'strengthening' | 'easing' | 'modernizing' | 'mixed';
}

const SIGNAL_STORE: RegulatorySignal[] = [];

export function recordSignal(input: Omit<RegulatorySignal, 'signal_id'>): RegulatorySignal {
  const s: RegulatorySignal = {
    signal_id: `sig_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    ...input,
  };
  SIGNAL_STORE.push(s);
  return s;
}

/**
 * 改正予測
 */
export interface AmendmentPrediction {
  target_law: string;
  predicted_effective_date_range: { earliest: string; latest: string };
  confidence_pct: number;
  signal_chain: Array<{ kind: RegulatorySignalKind; observed_at: string }>;
  reasoning: string[];
  /** 推奨アクション */
  recommended_actions: string[];
}

/**
 * 平均的な改正リードタイム (日数 / 観測 → 施行)
 */
const AVG_LEADTIME_DAYS: Record<RegulatorySignalKind, [number, number]> = {
  public_comment: [180, 365],
  expert_council_report: [365, 730],
  ruling_party_meeting: [180, 730],
  cabinet_decision: [60, 180],
  bill_submitted: [30, 180],
  committee_review: [14, 90],
  enacted: [60, 365],
  effective: [0, 0],
};

const SIGNAL_WEIGHT: Record<RegulatorySignalKind, number> = {
  public_comment: 30,
  expert_council_report: 25,
  ruling_party_meeting: 15,
  cabinet_decision: 50,
  bill_submitted: 65,
  committee_review: 80,
  enacted: 95,
  effective: 100,
};

export function predictAmendments(): AmendmentPrediction[] {
  const byLaw = new Map<string, RegulatorySignal[]>();
  for (const s of SIGNAL_STORE) {
    for (const law of s.target_laws) {
      if (!byLaw.has(law)) byLaw.set(law, []);
      byLaw.get(law)!.push(s);
    }
  }
  const predictions: AmendmentPrediction[] = [];
  const today = new Date();
  for (const [law, signals] of byLaw) {
    if (signals.length === 0) continue;
    const sortedSignals = [...signals].sort((a, b) => a.observed_at.localeCompare(b.observed_at));
    const latest = sortedSignals[sortedSignals.length - 1];
    const [minDays, maxDays] = AVG_LEADTIME_DAYS[latest.signal_kind];
    const earliestDate = new Date(latest.observed_at);
    earliestDate.setDate(earliestDate.getDate() + minDays);
    const latestDate = new Date(latest.observed_at);
    latestDate.setDate(latestDate.getDate() + maxDays);

    // 信号の段階数で確度上昇
    const stageCount = new Set(signals.map((s) => s.signal_kind)).size;
    const baseConf = SIGNAL_WEIGHT[latest.signal_kind];
    const confidence = Math.min(95, baseConf + (stageCount - 1) * 5);

    const reasoning: string[] = [];
    reasoning.push(`直近観測信号: ${latest.signal_kind} (${latest.observed_at.slice(0, 10)})`);
    reasoning.push(`観測段階数: ${stageCount}`);
    reasoning.push(`過去パターンに基づく改正リードタイム: ${minDays}〜${maxDays}日`);

    const actions: string[] = [];
    if (confidence >= 80) {
      actions.push('🚨 施行までに対応コード/契約書/帳票を改修');
      actions.push('影響範囲分析を Phase 46-LU の impact_analyzer_v2 で実施');
    } else if (confidence >= 60) {
      actions.push('改正案文を Phase 46-LU の change_detector でリアルタイム監視');
      actions.push('社内ステークホルダーへ予告');
    } else {
      actions.push('観測継続。次の段階 (与党合意/閣議決定) を待機');
    }

    predictions.push({
      target_law: law,
      predicted_effective_date_range: {
        earliest: earliestDate.toISOString().slice(0, 10),
        latest: latestDate.toISOString().slice(0, 10),
      },
      confidence_pct: confidence,
      signal_chain: sortedSignals.map((s) => ({ kind: s.signal_kind, observed_at: s.observed_at })),
      reasoning,
      recommended_actions: actions,
    });
  }
  return predictions.sort((a, b) => b.confidence_pct - a.confidence_pct);
}

/**
 * 「次に改正される可能性が高い」上位 N 法令を取得
 */
export function topPredicted(n = 10): AmendmentPrediction[] {
  return predictAmendments().slice(0, n);
}

/**
 * 内蔵 既知シグナル例 (デフォルト)
 */
export const DEFAULT_REGULATORY_SIGNALS: RegulatorySignal[] = [
  {
    signal_id: 'sig_default_1',
    signal_kind: 'expert_council_report',
    observed_at: '2026-04-01',
    target_laws: ['個人情報保護法', 'AI事業者ガイドライン'],
    competent_ministry: '個人情報保護委員会',
    title: 'PPC 3年見直し検討会 報告書',
    summary: '個情法 R2 改正後 3年見直しの中間報告。生成 AI による学習データ利用の規律強化を提言。',
    amendment_direction: 'strengthening',
  },
  {
    signal_id: 'sig_default_2',
    signal_kind: 'public_comment',
    observed_at: '2026-03-15',
    target_laws: ['電気通信事業法', '電気通信事業法施行規則'],
    competent_ministry: '総務省',
    title: '外部送信規律 (改正電気通信事業法 R5.6) フォローアップパブコメ',
    summary: 'cookie 同意制度の対象拡大検討',
    amendment_direction: 'strengthening',
  },
  {
    signal_id: 'sig_default_3',
    signal_kind: 'ruling_party_meeting',
    observed_at: '2026-02-20',
    target_laws: ['労働基準法'],
    competent_ministry: '厚生労働省',
    title: '自民党 労働政策調査会 — 副業・兼業 法整備',
    summary: '副業・兼業時の労働時間通算 の例外規定の創設検討',
    amendment_direction: 'easing',
  },
];

export function loadDefaultSignals(): void {
  for (const s of DEFAULT_REGULATORY_SIGNALS) {
    if (!SIGNAL_STORE.some((existing) => existing.signal_id === s.signal_id)) {
      SIGNAL_STORE.push(s);
    }
  }
}

export function countRegulatorySignals(): { total: number; by_kind: Record<string, number> } {
  const byKind: Record<string, number> = {};
  for (const s of SIGNAL_STORE) byKind[s.signal_kind] = (byKind[s.signal_kind] ?? 0) + 1;
  return { total: SIGNAL_STORE.length, by_kind: byKind };
}

export function _resetRadarForTests(): void {
  SIGNAL_STORE.length = 0;
}
