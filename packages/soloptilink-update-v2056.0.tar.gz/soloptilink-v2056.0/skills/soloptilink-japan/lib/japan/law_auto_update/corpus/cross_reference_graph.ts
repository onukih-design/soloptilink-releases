/**
 * Phase 46-LU-2 / Cross-Reference Graph (法令間相互参照グラフ)
 *
 * 法令本文に頻出する「準用」「適用」「準ずる」「読み替え」「例による」などの
 * 相互参照表現を抽出し、法令間の有向グラフを構築する。
 *
 * 用途:
 *  - 改正影響の波及計算 (法 A の改正で準用先の法 B/C/D も波及)
 *  - 関連法令の推薦 (Tenant DNA × 法令カテゴリ)
 *  - 不整合の検出 (準用先が改正されたのに参照元が更新されていない)
 */

import type { EgovLawTextChunk } from '../../law_tracker';

export interface CrossRefEdge {
  /** 参照元の法令ID (準用する側) */
  source_law_id: string;
  /** 参照元の条文 */
  source_article: string;
  /** 参照先の法令通称 (例: '民法') — 構造化された ID 解決は別途行う */
  target_law_name: string;
  /** 参照先の条文番号 (取得できる場合) */
  target_article?: string;
  /** 参照種別 */
  ref_kind: 'apply' | 'mutatis_mutandis' | 'mutual' | 'override' | 'example';
  /** 抽出元の生文字列 */
  raw_match: string;
}

export interface CrossRefGraph {
  nodes: Map<string, { law_id: string; out_degree: number; in_degree: number }>;
  edges: CrossRefEdge[];
}

const PATTERNS: Array<{ kind: CrossRefEdge['ref_kind']; re: RegExp }> = [
  // 「民法第90条を準用する」
  { kind: 'mutatis_mutandis', re: /([^\s、。()「」]{1,20}(?:法|律|令|則))(?:第([０-９0-9]+(?:の[０-９0-9]+)?)条)?を準用する/g },
  // 「民法第415条を適用する」
  { kind: 'apply', re: /([^\s、。()「」]{1,20}(?:法|律|令|則))(?:第([０-９0-9]+(?:の[０-９0-9]+)?)条)?を適用する/g },
  // 「〜の例による」
  { kind: 'example', re: /([^\s、。()「」]{1,20}(?:法|律|令|則))(?:第([０-９0-9]+(?:の[０-９0-9]+)?)条)?の例による/g },
  // 「〜と読み替える」
  { kind: 'override', re: /([^\s、。()「」]{1,20}(?:法|律|令|則))(?:第([０-９0-9]+(?:の[０-９0-9]+)?)条)?(?:中.+?)?と読み替える/g },
];

export function extractCrossReferences(input: {
  source_law_id: string;
  chunks: EgovLawTextChunk[];
}): CrossRefEdge[] {
  const out: CrossRefEdge[] = [];
  for (const ch of input.chunks) {
    const text = ch.text ?? '';
    for (const p of PATTERNS) {
      const re = new RegExp(p.re.source, 'g');
      let m: RegExpExecArray | null;
      while ((m = re.exec(text)) !== null) {
        out.push({
          source_law_id: input.source_law_id,
          source_article: ch.articleNum,
          target_law_name: m[1],
          target_article: m[2] ? toHalfWidth(m[2]) : undefined,
          ref_kind: p.kind,
          raw_match: m[0],
        });
      }
    }
  }
  return out;
}

function toHalfWidth(s: string): string {
  return s.replace(/[０-９]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0));
}

/**
 * 複数法令から抽出した edges を集計してグラフを構築。
 */
export function buildGraph(edges: CrossRefEdge[]): CrossRefGraph {
  const nodes = new Map<string, { law_id: string; out_degree: number; in_degree: number }>();
  for (const e of edges) {
    if (!nodes.has(e.source_law_id)) {
      nodes.set(e.source_law_id, { law_id: e.source_law_id, out_degree: 0, in_degree: 0 });
    }
    nodes.get(e.source_law_id)!.out_degree++;
    if (!nodes.has(e.target_law_name)) {
      nodes.set(e.target_law_name, { law_id: e.target_law_name, out_degree: 0, in_degree: 0 });
    }
    nodes.get(e.target_law_name)!.in_degree++;
  }
  return { nodes, edges };
}

/**
 * ハブ法令 (in_degree 上位) を抽出。
 * 多くの法令から参照される=改正の波及が大きい。
 */
export function topInboundHubs(graph: CrossRefGraph, k = 10): Array<{ law: string; in_degree: number }> {
  const list = [...graph.nodes.values()]
    .map((n) => ({ law: n.law_id, in_degree: n.in_degree }))
    .sort((a, b) => b.in_degree - a.in_degree);
  return list.slice(0, k);
}

/**
 * 改正影響の伝搬: 指定した法令を起点に、in_degree 経路を BFS で逆辿り。
 * 結果はステップ数 (改正からの距離) 付き。
 */
export function propagateAmendmentImpact(input: {
  graph: CrossRefGraph;
  rootLawNameOrId: string;
  maxDepth?: number;
}): Array<{ law: string; depth: number }> {
  const visited = new Map<string, number>();
  const queue: Array<{ law: string; depth: number }> = [{ law: input.rootLawNameOrId, depth: 0 }];
  const maxDepth = input.maxDepth ?? 3;
  while (queue.length > 0) {
    const cur = queue.shift()!;
    if (visited.has(cur.law)) continue;
    visited.set(cur.law, cur.depth);
    if (cur.depth >= maxDepth) continue;
    for (const e of input.graph.edges) {
      if (e.target_law_name === cur.law && !visited.has(e.source_law_id)) {
        queue.push({ law: e.source_law_id, depth: cur.depth + 1 });
      }
    }
  }
  return [...visited.entries()].map(([law, depth]) => ({ law, depth })).sort((a, b) => a.depth - b.depth);
}

/**
 * 統計サマリ
 */
export function graphStats(graph: CrossRefGraph): {
  node_count: number;
  edge_count: number;
  apply_count: number;
  mutatis_mutandis_count: number;
  example_count: number;
  override_count: number;
} {
  let apply = 0, mm = 0, ex = 0, ov = 0;
  for (const e of graph.edges) {
    if (e.ref_kind === 'apply') apply++;
    else if (e.ref_kind === 'mutatis_mutandis') mm++;
    else if (e.ref_kind === 'example') ex++;
    else if (e.ref_kind === 'override') ov++;
  }
  return {
    node_count: graph.nodes.size,
    edge_count: graph.edges.length,
    apply_count: apply,
    mutatis_mutandis_count: mm,
    example_count: ex,
    override_count: ov,
  };
}
