/**
 * Phase 46-LU / 改正検知エンジン
 *
 * 法令本文の SHA256 ハッシュ全体差分 + 既存 diffLawVersions の条文単位差分 を
 * 組み合わせて、改正の発生・規模・重要度を判定する。
 *
 * - 全文ハッシュ: O(1) で 「変化したかどうか」を即断 (帯域節約)
 * - 条文単位 diff: 変化があった場合のみ実行 (詳細解析)
 * - 重要度判定: changedArticles 数 + 削除条文の有無 + key articles の有無
 * - 履歴台帳: append-only JSONL で全変更を永続化 (監査証跡)
 */

import type { EgovLawTextChunk, LawAmendmentDiff } from '../law_tracker';
import { diffLawVersions, LAW_CATALOG } from '../law_tracker';

// ============================================================================
// 全文ハッシュ
// ============================================================================

/**
 * 法令本文の正規化 SHA256 を返す。
 * 改行・全角空白・連続空白を畳んでから ハッシュ化して、表記揺れに強くする。
 */
export async function computeLawTextHash(chunks: EgovLawTextChunk[]): Promise<string> {
  const normalized = chunks
    .map((c) => `${c.articleNum}|${c.paragraphNum ?? ''}|${c.itemNum ?? ''}|${normalize(c.text)}`)
    .join('\n');
  return await sha256(normalized);
}

function normalize(s: string): string {
  return (s ?? '')
    .replace(/　/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

async function sha256(input: string): Promise<string> {
  // Node 20+ / Bun / Browser 全てで使える Web Crypto API
  const enc = new TextEncoder().encode(input);
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const subtle: SubtleCrypto | undefined = (globalThis as any).crypto?.subtle;
  if (subtle) {
    const buf = await subtle.digest('SHA-256', enc);
    return [...new Uint8Array(buf)].map((b) => b.toString(16).padStart(2, '0')).join('');
  }
  // フォールバック: Node 標準 crypto
  // eslint-disable-next-line @typescript-eslint/no-require-imports
  const { createHash } = await import('node:crypto');
  return createHash('sha256').update(input).digest('hex');
}

// ============================================================================
// 改正検知 (高速 hash 判定 + 詳細 diff)
// ============================================================================

export interface ChangeDetectionResult {
  lawId: string;
  /** 変更があったか */
  hasChange: boolean;
  /** 全文 SHA256 (before / after) */
  beforeHash: string;
  afterHash: string;
  /** 詳細 diff (hasChange = true の場合のみ) */
  diff?: LawAmendmentDiff;
  /** 重要度 (拡張: critical を追加) */
  severity: 'critical' | 'major' | 'minor' | 'editorial' | 'none';
  /** 検知タイムスタンプ (ISO) */
  detectedAt: string;
}

/**
 * 重要条文キーワード — これらが changed/deleted に含まれると critical 扱い
 */
const CRITICAL_KEYWORDS = [
  '罰則',
  '懲役',
  '罰金',
  '損害賠償',
  '無効',
  '解除',
  '義務',
  '禁止',
  '責任',
  '取消',
  '効力',
  '失効',
  '施行',
  '附則',
];

export async function detectChange(input: {
  lawId: string;
  before: { effectiveDate: string; chunks: EgovLawTextChunk[] };
  after: { effectiveDate: string; chunks: EgovLawTextChunk[] };
}): Promise<ChangeDetectionResult> {
  const beforeHash = await computeLawTextHash(input.before.chunks);
  const afterHash = await computeLawTextHash(input.after.chunks);
  const detectedAt = new Date().toISOString();

  if (beforeHash === afterHash) {
    return {
      lawId: input.lawId,
      hasChange: false,
      beforeHash,
      afterHash,
      severity: 'none',
      detectedAt,
    };
  }

  const diff = diffLawVersions(input);
  let severity: ChangeDetectionResult['severity'];
  const hasDeletion = diff.changedArticles.some((c) => c.changeType === 'deleted');
  const hasCritical = diff.changedArticles.some((c) => {
    const blob = `${c.before ?? ''}${c.after ?? ''}`;
    return CRITICAL_KEYWORDS.some((k) => blob.includes(k));
  });
  if (hasDeletion || (hasCritical && diff.changedArticles.length >= 3)) severity = 'critical';
  else if (diff.changedArticles.length > 5) severity = 'major';
  else if (diff.changedArticles.length > 0) severity = 'minor';
  else severity = 'editorial';

  return { lawId: input.lawId, hasChange: true, beforeHash, afterHash, diff, severity, detectedAt };
}

// ============================================================================
// 履歴台帳 (append-only JSONL)
// ============================================================================

export interface ChangeLedgerEntry {
  detectedAt: string;
  lawId: string;
  shortName: string;
  beforeHash: string;
  afterHash: string;
  severity: ChangeDetectionResult['severity'];
  changedArticleCount: number;
  affectedModules: string[];
  effectiveDate: string;
}

export function buildLedgerEntry(result: ChangeDetectionResult): ChangeLedgerEntry {
  const cat = LAW_CATALOG.find((l) => l.egovLawId === result.lawId);
  return {
    detectedAt: result.detectedAt,
    lawId: result.lawId,
    shortName: cat?.shortName ?? result.lawId,
    beforeHash: result.beforeHash,
    afterHash: result.afterHash,
    severity: result.severity,
    changedArticleCount: result.diff?.changedArticles.length ?? 0,
    affectedModules: result.diff?.affectedModules ?? cat?.relatedModules ?? [],
    effectiveDate: result.diff?.afterVersion.effectiveDate ?? '',
  };
}

/**
 * 履歴台帳の JSONL を組み立てて永続化のためのバイト列を返す。
 * 実書き込みは呼出側の registry.appendLedger に任せる。
 */
export function serializeLedgerEntries(entries: ChangeLedgerEntry[]): string {
  return entries.map((e) => JSON.stringify(e)).join('\n') + (entries.length > 0 ? '\n' : '');
}
