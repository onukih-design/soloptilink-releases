/**
 * Phase 46-LU-2 / Tier Classifier
 *
 * 法令名から Tier S / A / B / C / D を機械的に判定する。
 * 「六法 → S / 主要60 → A / 業法 → B / 省令告示 → C / その他 → D」
 * の規則ベース実装。LLM 不使用 (deterministic & 高速)。
 *
 * legal_corpus.ts の classifyTier を独立モジュール化し、テスト容易性を高めた版。
 */

import { TIER_A_MAJOR_60 } from './six_codes';
import type { LegalTier } from './legal_corpus';

const SIX_CODE_NAMES = new Set([
  '憲法', '日本国憲法',
  '民法',
  '商法',
  '民訴', '民事訴訟法',
  '刑法',
  '刑訴', '刑事訴訟法',
]);

const TIER_B_PATTERNS = [
  /業法$/, /建設業法/, /宅地建物取引業法/, /風営法/, /警備業法/, /古物営業法/,
  /医療法/, /介護保険法/, /薬機法/, /医薬品.*法/, /労働者派遣法/,
  /貨物自動車運送事業法/, /海上運送法/, /航空法/,
  /旅館業法/, /住宅宿泊事業法/,
  /宗教法人法/, /学校教育法/, /私立学校法/,
  /農地法/, /森林法/, /漁業法/, /鉱業法/,
  /電気通信事業法/, /放送法/,
  /信託業法/, /貸金業法/, /保険業法/, /銀行法/, /信用金庫法/, /農協法/,
  /消費者契約法/, /特定商取引法/, /景品表示法/,
];

const C_TYPE_PATTERNS = [
  /(?:政令|施行令)$/,
  /(?:省令|施行規則|府令)$/,
  /規則$/,
  /告示$/,
];

export interface TierClassification {
  tier: LegalTier;
  reason: string;
}

export function classifyTierDetailed(input: {
  shortName: string;
  officialName: string;
}): TierClassification {
  const { shortName, officialName } = input;

  // Tier S: 六法
  if (SIX_CODE_NAMES.has(shortName) || SIX_CODE_NAMES.has(officialName)) {
    return { tier: 'S', reason: '六法に該当' };
  }

  // Tier A: 主要60法令
  if (TIER_A_MAJOR_60.includes(shortName) || TIER_A_MAJOR_60.includes(officialName)) {
    return { tier: 'A', reason: '主要60法令に該当' };
  }

  // Tier B: 業法 / 産業法
  for (const re of TIER_B_PATTERNS) {
    if (re.test(officialName)) {
      return { tier: 'B', reason: `業法パターン: ${re.source}` };
    }
  }

  // Tier C: 政令・省令・規則・告示
  for (const re of C_TYPE_PATTERNS) {
    if (re.test(officialName)) {
      return { tier: 'C', reason: `下位法令: ${re.source}` };
    }
  }

  // Tier D: その他
  return { tier: 'D', reason: 'デフォルト (その他)' };
}

export function classifyTier(shortName: string, officialName: string): LegalTier {
  return classifyTierDetailed({ shortName, officialName }).tier;
}

/** Tier 別の説明 */
export const TIER_DESCRIPTIONS: Record<LegalTier, string> = {
  S: '六法 (憲法/民法/商法/民訴/刑/刑訴) — 監視頻度 毎週',
  A: '主要60法令 (会社法/労基法/個情法/金商法/特許法 等) — 監視頻度 毎週',
  B: '業法・産業法 — 監視頻度 月次',
  C: '政令・省令・施行規則・告示 — 監視頻度 四半期',
  D: 'その他 (条例・指針・通達 等) — 監視頻度 年次',
};

/** Tier 別の重み (報酬計算/通知関連度に影響) */
export const TIER_WEIGHTS: Record<LegalTier, number> = {
  S: 1.0,
  A: 0.9,
  B: 0.7,
  C: 0.5,
  D: 0.3,
};
