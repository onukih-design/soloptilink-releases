/**
 * Phase 46-LU-4 / 国際贈収賄規制 (FCPA + UKBA + UNCAC + 不正競争防止法)
 *
 * 海外贈賄: 米国 FCPA / 英国 UKBA / 仏 Sapin II / 中国 反不正当競争法 / 日本 不競法 18条
 * 国連グローバル: UNCAC (国連腐敗防止条約)
 */

export interface AntiBriberyRule {
  jurisdiction: 'US' | 'UK' | 'FR' | 'CN' | 'JP' | 'Global';
  short_name: string;
  full_name: string;
  effective_date: string;
  key_provisions: Record<string, string>;
  penalty_summary: string;
  reach: string;
}

export const ANTI_BRIBERY_RULES: AntiBriberyRule[] = [
  {
    jurisdiction: 'US',
    short_name: 'FCPA',
    full_name: 'Foreign Corrupt Practices Act of 1977 (15 USC §§ 78dd-1 et seq.)',
    effective_date: '1977-12-19 (1998改正で対象拡大)',
    key_provisions: {
      'Anti-Bribery_15-USC-78dd-1': '外国公務員への賄賂提供禁止 (corruptly + offer/pay/promise/authorize + payment + foreign official + business purpose)',
      'Accounting_Provisions': '内部統制要件 + 帳簿の正確性 (issuer 限定)',
      'Facilitating_Payments': 'グリースペイメント例外 (狭い)',
      'Affirmative_Defenses': '現地法適法性/合理的接待広告費',
      'Issuer': '米国上場企業 (ADR含む)',
      'Domestic_Concern': '米国法人/個人',
      'Other_Persons': '米国領内行為者 (外国法人含む)',
    },
    penalty_summary: '法人: 最大200万USD/件 + 利益没収 / 個人: 25万USD + 5年禁錮',
    reach: 'グローバル: 米国上場+米国領内行為+米国通信網経由',
  },
  {
    jurisdiction: 'UK',
    short_name: 'UKBA',
    full_name: 'UK Bribery Act 2010',
    effective_date: '2011-07-01',
    key_provisions: {
      'Section_1': '贈賄罪 (一般)',
      'Section_2': '収賄罪 (一般)',
      'Section_6': '外国公務員贈賄罪',
      'Section_7': '商業組織の贈賄防止義務違反罪 (failure to prevent — 法人責任)',
      'Adequate_Procedures': 'Section 7 抗弁: 6原則 (比例 / 上位コミット / リスク評価 / DD / 伝達 / モニタリング)',
      'Hospitality': '合理的接待は許容 (Section 1 reasonable hospitality)',
      'Facilitating_Payments': '原則禁止 (FCPA より厳しい)',
    },
    penalty_summary: '個人: 無制限罰金 + 10年禁錮 / 法人: 無制限罰金 + DPA (Deferred Prosecution Agreement) 可能',
    reach: 'グローバル: 英国法人/英国上場/英国一部事業 + UK national',
  },
  {
    jurisdiction: 'FR',
    short_name: 'Sapin II',
    full_name: 'Loi Sapin II — Loi n° 2016-1691',
    effective_date: '2017-06-01',
    key_provisions: {
      'AFA': 'Agence Française Anticorruption (フランス汚職防止庁) 創設',
      'Article_17': 'コンプライアンスプログラム義務化 (従業員500人+売上1億EUR超)',
      '8_pillars': '8つの柱 (行動規範/通報窓口/リスクマップ/3者DD/会計統制/研修/制裁/評価)',
      'CJIP': 'Convention judiciaire d\'intérêt public (司法協定 — 米DPA類似)',
      'whistleblower': '内部通報者保護',
    },
    penalty_summary: '法人: 100万EUR / 個人: 10年禁錮 + 100万EUR / AFA 行政罰 100万EUR',
    reach: 'フランス国内活動 + フランス国民/居住者',
  },
  {
    jurisdiction: 'JP',
    short_name: '不競法18条',
    full_name: '不正競争防止法 (外国公務員贈賄罪 第18条)',
    effective_date: '1998-09-25 (OECD条約批准に伴う改正)',
    key_provisions: {
      '18条': '外国公務員等への営業上の不正利益のための贈賄の禁止',
      '21条2項': '罰則: 5年以下の懲役+500万円以下の罰金 (両罰: 法人 3億円以下)',
      '対象者': '日本国民/日本企業/日本法人 (国外犯処罰)',
      '指針R3': '外国公務員贈賄防止指針 (経済産業省 R3年改訂)',
    },
    penalty_summary: '個人: 5年以下の懲役 + 500万円以下の罰金 / 法人: 3億円以下の罰金',
    reach: '日本国民 + 日本法人 (国外犯処罰)',
  },
  {
    jurisdiction: 'Global',
    short_name: 'UNCAC',
    full_name: 'United Nations Convention Against Corruption (国連腐敗防止条約)',
    effective_date: '2005-12-14',
    key_provisions: {
      'Article_15': '国内公務員贈収賄犯罪化',
      'Article_16': '外国公務員/国際機関職員贈収賄犯罪化',
      'Article_17': '公務員横領犯罪化',
      'Article_18': '影響力取引犯罪化',
      'Article_20': '違法蓄財犯罪化 (任意)',
      'Article_31': '没収/差押え',
      'Article_43-50': '国際協力 (引渡し/相互法律支援)',
      'StAR_Initiative': '資産回収イニシアチブ (UNODC/World Bank)',
    },
    penalty_summary: '締約国法令により (各国国内法に転写)',
    reach: '締約国 190+ (日本は2017-07-11批准)',
  },
];

/**
 * FCPA/UKBA 適用判定
 */
export interface AntiBriberyJurisdictionInput {
  /** 取引/支払行為地 */
  act_location?: string;
  /** 行為者の本国/事業地 */
  actor_nationality?: string;
  /** 取引相手 (公務員に該当する場合) */
  recipient_kind?: 'foreign_public_official' | 'domestic_public_official' | 'private';
  /** 米国上場 (FCPA Accounting Provisions) */
  is_us_listed?: boolean;
  /** 英国法人/事業 */
  has_uk_nexus?: boolean;
  /** 日本国民/日本企業 */
  is_japanese?: boolean;
}

export function assessAntiBriberyJurisdiction(input: AntiBriberyJurisdictionInput): {
  fcpa: boolean; ukba: boolean; jp_18jo: boolean; recommendations: string[];
} {
  const recs: string[] = [];
  const fcpa = (input.is_us_listed || input.act_location === 'US' || input.actor_nationality === 'US')
    && input.recipient_kind === 'foreign_public_official';
  const ukba = !!input.has_uk_nexus;
  const jp18jo = !!input.is_japanese && input.recipient_kind === 'foreign_public_official';

  if (fcpa) recs.push('FCPA 適用の可能性 → DOJ/SEC ガイダンス Resource Guide 参照 + DPA 検討');
  if (ukba) recs.push('UKBA Section 7 → Adequate Procedures (6 原則) 整備必須');
  if (jp18jo) recs.push('日本 不競法18条 → 外国公務員贈賄防止指針 R3 準拠 + コンプライアンス研修');
  if (!fcpa && !ukba && !jp18jo) recs.push('国際贈収賄規制の直接適用は限定的 (要内部審査)');

  return { fcpa, ukba, jp_18jo: jp18jo, recommendations: recs };
}

export function countAntiBriberyRules(): { total: number; by_jurisdiction: Record<string, number> } {
  const byJ: Record<string, number> = {};
  for (const r of ANTI_BRIBERY_RULES) byJ[r.jurisdiction] = (byJ[r.jurisdiction] ?? 0) + 1;
  return { total: ANTI_BRIBERY_RULES.length, by_jurisdiction: byJ };
}
