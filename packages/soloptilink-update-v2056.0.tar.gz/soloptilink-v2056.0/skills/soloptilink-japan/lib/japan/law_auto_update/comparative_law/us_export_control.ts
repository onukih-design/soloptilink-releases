/**
 * Phase 46-LU-4 / 米国輸出管理 (ITAR + EAR)
 *
 * 日本企業が米国製技術/部品を使う場合の規制 (再輸出含む)。
 *  - ITAR: 国際武器取引規則 (米国国務省 DDTC)
 *  - EAR: 輸出管理規則 (米国商務省 BIS)
 *  - OFAC: 米国財務省 経済制裁 (Specially Designated Nationals List)
 */

export interface UsExportControlRule {
  agency: 'DDTC' | 'BIS' | 'OFAC';
  short_name: string;
  full_name: string;
  effective_date: string;
  key_provisions: Record<string, string>;
  jp_counterpart: string[];
  penalty_summary: string;
}

export const US_EXPORT_CONTROL_RULES: UsExportControlRule[] = [
  {
    agency: 'DDTC',
    short_name: 'ITAR',
    full_name: 'International Traffic in Arms Regulations (22 CFR Parts 120-130)',
    effective_date: '1976-06-30 (制定) — 直近改正 2023',
    key_provisions: {
      'USML': 'United States Munitions List (Cat I-XXI) 防衛物品/技術',
      '120.10': '輸出 (Export) 定義 (技術データの開示含む)',
      '120.17': '再輸出 (Re-export) 定義',
      '123.1': '永続輸出ライセンス',
      '124.1': 'TAA (Technical Assistance Agreement)',
      '125.4': '免除 (License Exemptions)',
      '126.1': '禁輸国 (China/Cuba/Iran/N.Korea/Russia/Syria 等)',
      'deemed_export': '外国人への米国内技術データ開示も "deemed export"',
      'CJ': 'Commodity Jurisdiction Determination (管轄判定)',
    },
    jp_counterpart: ['外為法第48条', 'リスト規制', 'キャッチオール規制'],
    penalty_summary: '刑事: 1件あたり最大100万USD + 20年禁錮 / 民事: 50万USD/件 + 輸出特権剥奪',
  },
  {
    agency: 'BIS',
    short_name: 'EAR',
    full_name: 'Export Administration Regulations (15 CFR Parts 730-774)',
    effective_date: '2018-11-30 (ECRA法制定) — 直近改正 2024',
    key_provisions: {
      'CCL': 'Commerce Control List (Cat 0-9) — Dual Use 民軍両用',
      'ECCN': 'Export Control Classification Number (5桁) 例: 5A002 = 暗号機器',
      'EAR99': 'CCL 非該当の一般品 (NLR = No License Required)',
      'De_Minimis': 'デミニミス 25% rule (国別 / 禁輸国向け 10%)',
      'FDPR': 'Foreign Direct Product Rule (米国製ソフト/装置で製造された外国品)',
      'Entity_List': '取引制限リスト (1300+ 中華系企業含む)',
      'MEU': 'Military End-Use/End-User Rule',
      '$1000_rule': '$1000超 USPPI届出',
      'License_Exceptions': 'LVS/GBS/TSR/STA/RPL/ENC 等 21類型',
    },
    jp_counterpart: ['外為法第48条', '外国為替令', '貨物等省令'],
    penalty_summary: '刑事: 1件あたり最大100万USD + 20年禁錮 / 民事: 30.8万USD/件 (年改定) + 輸出特権剥奪',
  },
  {
    agency: 'OFAC',
    short_name: 'OFAC Sanctions',
    full_name: 'Office of Foreign Assets Control Sanctions (31 CFR Parts 501-598)',
    effective_date: 'IEEPA 1977 / TWEA 1917 — 大統領令で随時拡大',
    key_provisions: {
      'SDN_List': 'Specially Designated Nationals & Blocked Persons List (1万件+)',
      'Sectoral_Sanctions': 'SSI (Sectoral Sanctions Identifications) ロシア/ベラルーシ等',
      '50_percent_rule': 'SDN保有 50% 以上の関連会社も対象',
      'Comprehensive': 'Cuba/Iran/N.Korea/Syria/Russia (Crimea/DPR/LPR) — 包括禁輸',
      'CISADA': '対イラン制裁 (二次制裁 — 米国外企業も対象)',
      'CAATSA': '対露・対イラン・対朝制裁',
      'License_General': 'General License (一般許可)',
      'License_Specific': 'Specific License (個別許可) ',
      'Reporting': 'SDN拒否取引の OFAC 報告義務 (10日以内)',
    },
    jp_counterpart: ['外為法第10条 (制裁措置)', '国連安保理決議関連'],
    penalty_summary: '刑事: 100万USD + 20年禁錮 / 民事: 364,892USD/件 (2024) — IEEPA',
  },
];

/**
 * 輸出許可必要性の簡易判定
 */
export interface ExportLicenseAssessmentInput {
  /** 仕向国 ISO-2 */
  destination_country: string;
  /** 物品の ECCN または 'EAR99' */
  eccn?: string;
  /** USML 該当か */
  is_usml_item?: boolean;
  /** 軍事用途/エンドユーザーの懸念 */
  military_end_use?: boolean;
}

export interface ExportLicenseAssessment {
  itar_applies: boolean;
  ear_applies: boolean;
  ofac_concern: boolean;
  license_likely_required: boolean;
  recommended_actions: string[];
}

const OFAC_COMPREHENSIVE = ['CU', 'IR', 'KP', 'SY', 'RU']; // 包括対象例 (簡略)
const ITAR_RESTRICTED = [...OFAC_COMPREHENSIVE, 'CN', 'BY', 'MM', 'VE'];

export function assessExportLicense(input: ExportLicenseAssessmentInput): ExportLicenseAssessment {
  const actions: string[] = [];
  const itarApplies = !!input.is_usml_item;
  const earApplies = !itarApplies && !!input.eccn;
  const ofacConcern = OFAC_COMPREHENSIVE.includes(input.destination_country.toUpperCase());
  const restrictedItar = itarApplies && ITAR_RESTRICTED.includes(input.destination_country.toUpperCase());

  let licenseLikelyRequired = false;
  if (ofacConcern) {
    licenseLikelyRequired = true;
    actions.push('OFAC 包括制裁対象国 → 取引前に OFAC ライセンス確認必須');
  }
  if (restrictedItar) {
    licenseLikelyRequired = true;
    actions.push('ITAR 禁輸国 → DDTC ライセンス取得が事実上不可能のため取引中止検討');
  }
  if (itarApplies) {
    licenseLikelyRequired = true;
    actions.push('ITAR該当 → DDTC への許可申請 (DSP-5/DSP-83) 必須');
  }
  if (earApplies) {
    if (input.eccn !== 'EAR99' || input.military_end_use) {
      licenseLikelyRequired = true;
      actions.push(`EAR ${input.eccn} → CCL & Country Chart で許可要件確認`);
    } else {
      actions.push('EAR99 / 民生用 → NLR (No License Required) の可能性');
    }
  }
  if (input.military_end_use && !itarApplies) {
    licenseLikelyRequired = true;
    actions.push('Military End-Use Rule 該当の可能性 → BIS 事前ライセンス確認');
  }
  if (actions.length === 0) actions.push('規制非該当の可能性高い (要内部審査)');
  return {
    itar_applies: itarApplies,
    ear_applies: earApplies,
    ofac_concern: ofacConcern,
    license_likely_required: licenseLikelyRequired,
    recommended_actions: actions,
  };
}

export function countUsExportControlRules(): { total: number; total_provisions: number } {
  let provs = 0;
  for (const r of US_EXPORT_CONTROL_RULES) provs += Object.keys(r.key_provisions).length;
  return { total: US_EXPORT_CONTROL_RULES.length, total_provisions: provs };
}
