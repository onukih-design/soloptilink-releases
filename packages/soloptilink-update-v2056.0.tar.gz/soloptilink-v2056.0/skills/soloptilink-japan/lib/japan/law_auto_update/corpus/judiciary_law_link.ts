/**
 * Phase 46-LU-2 / 判例-法令双方向リンク (v2.0 — 80件拡張版)
 *
 * Phase 46-LU-3 で 12 件 → 80+ 件に拡張。
 * 憲法10 / 民法12 / 商事8 / 労働8 / 刑法10 / 知財10 / 行政8 / 税務6 / 消費者2 / 不競2 + 既存 IP/Trademark
 *
 *  - 法令 → 関連判例 (民法415条 → ハマキョウレックス事件 等)
 *  - 判例 → 関連法令 (ベネッセ事件 → 個情法 + 民法709条)
 *
 * 改正検知時に「この改正が影響する判例」を抽出し、PR本文に注記する。
 * 逆に、新規判例が登場した時に「この判例が影響する法令条文」を返す。
 */

import type { LawCategory } from '../../law_tracker';

export interface CaseLawRef {
  case_id: string;
  short_name: string;
  decision_date: string;
  law_areas: LawCategory[];
  related_laws: string[]; // '民法第415条', '個情法第26条' 等
  damage_benchmark_per_person_jpy?: number;
  citation: string;
  /** 短い争点・判旨要約 (50-100字以内) */
  summary?: string;
}

/**
 * 主要判例 80 件 インデックス。
 * 法律実務で頻出する憲法・民法・刑法・商事・労働・知財・行政・税務・消費者判例。
 *
 * 出典・引用は最高裁判所判例集 (民集・刑集・集民) と裁判所HPに準拠。
 */
export const LANDMARK_CASES_INDEX: CaseLawRef[] = [
  // ============== 憲法 10 件 ==============
  {
    case_id: 'tomabechi_S35',
    short_name: '苫米地事件',
    decision_date: '1960-06-08',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第7条', '日本国憲法第69条'],
    citation: '最大判S35.6.8 民集14-7-1206',
    summary: '統治行為論。衆議院解散の有効性は司法審査の対象外と判示。',
  },
  {
    case_id: 'sunagawa_S34',
    short_name: '砂川事件',
    decision_date: '1959-12-16',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第9条', '日米安全保障条約'],
    citation: '最大判S34.12.16 刑集13-13-3225',
    summary: '統治行為論。日米安保条約の合憲性は高度の政治性ゆえ司法審査原則対象外。',
  },
  {
    case_id: 'asahi_S42',
    short_name: '朝日訴訟',
    decision_date: '1967-05-24',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第25条', '生活保護法'],
    citation: '最大判S42.5.24 民集21-5-1043',
    summary: '生存権はプログラム規定ではないが、具体的権利は法律により定まる。',
  },
  {
    case_id: 'horiki_S57',
    short_name: '堀木訴訟',
    decision_date: '1982-07-07',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第25条', '児童扶養手当法'],
    citation: '最大判S57.7.7 民集36-7-1235',
    summary: '社会保障の併給調整は立法府の広範な裁量。',
  },
  {
    case_id: 'zentei_S41',
    short_name: '全逓中郵事件',
    decision_date: '1966-10-26',
    law_areas: ['labor' as LawCategory],
    related_laws: ['日本国憲法第28条', '公共企業体労働関係法'],
    citation: '最大判S41.10.26 刑集20-8-901',
    summary: '公務員労働三権の制約は限定的に解釈すべき (合理性基準) 旧判例。',
  },
  {
    case_id: 'sarufuto_S49',
    short_name: '猿払事件',
    decision_date: '1974-11-06',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第21条', '国家公務員法第102条'],
    citation: '最大判S49.11.6 刑集28-9-393',
    summary: '公務員の政治活動禁止は合憲。合理的関連性の基準。',
  },
  {
    case_id: 'horikoshi_H24',
    short_name: '堀越事件',
    decision_date: '2012-12-07',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第21条', '国家公務員法第102条'],
    citation: '最判H24.12.7 刑集66-12-1722',
    summary: '猿払事件を限定。職務関連性なき政治活動には適用なし (限定解釈)。',
  },
  {
    case_id: 'ehime_tamagushi_H9',
    short_name: '愛媛玉串料訴訟',
    decision_date: '1997-04-02',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第20条', '日本国憲法第89条'],
    citation: '最大判H9.4.2 民集51-4-1673',
    summary: '愛媛県の靖国神社・護国神社への玉串料支出は政教分離原則違反。',
  },
  {
    case_id: 'tsu_jichinsai_S52',
    short_name: '津地鎮祭事件',
    decision_date: '1977-07-13',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第20条', '日本国憲法第89条'],
    citation: '最大判S52.7.13 民集31-4-533',
    summary: '政教分離は絶対分離ではない。目的効果基準を採用 (世俗的・社会的儀礼として合憲)。',
  },
  {
    case_id: 'izumisano_H7',
    short_name: '泉佐野市民会館事件',
    decision_date: '1995-03-07',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第21条', '地方自治法第244条'],
    citation: '最判H7.3.7 民集49-3-687',
    summary: '集会の自由制約は明白かつ現在の危険ある場合に限る (公の施設の利用拒否)。',
  },

  // ============== 民法 12 件 ==============
  {
    case_id: 'shingen_T8',
    short_name: '信玄公旗掛松事件',
    decision_date: '1919-03-03',
    law_areas: ['admin' as LawCategory],
    related_laws: ['民法第1条第3項'],
    citation: '大判T8.3.3 民録25-356',
    summary: '権利濫用の法理。鉄道会社の煤煙で松が枯れた事案。',
  },
  {
    case_id: 'unazuki_S10',
    short_name: '宇奈月温泉事件',
    decision_date: '1935-10-05',
    law_areas: ['real_estate' as LawCategory],
    related_laws: ['民法第1条第3項', '民法第206条'],
    citation: '大判S10.10.5 民集14-1965',
    summary: '権利濫用の法理。他人の土地に温泉引湯管がわずかに侵入した事案。',
  },
  {
    case_id: 'saiko_S29_94II',
    short_name: '94条2項類推適用',
    decision_date: '1954-08-20',
    law_areas: ['real_estate' as LawCategory],
    related_laws: ['民法第94条第2項'],
    citation: '最判S29.8.20 民集8-8-1505',
    summary: '虚偽表示の通謀がなくとも、外観作出への帰責性ある場合は94条2項類推。',
  },
  {
    case_id: 'dainippon_print_S54',
    short_name: '大日本印刷事件',
    decision_date: '1979-07-20',
    law_areas: ['labor' as LawCategory],
    related_laws: ['民法第90条', '労働基準法第15条'],
    citation: '最判S54.7.20 民集33-5-582',
    summary: '採用内定は始期付解約権留保付労働契約。取消は客観的合理性必要。',
  },
  {
    case_id: 'mitsubishi_jushi_S48',
    short_name: '三菱樹脂事件',
    decision_date: '1973-12-12',
    law_areas: ['labor' as LawCategory],
    related_laws: ['日本国憲法第14条', '日本国憲法第19条', '民法第90条'],
    citation: '最大判S48.12.12 民集27-11-1536',
    summary: '私人間効力。憲法は私人間に直接適用されず民法90条等を介して間接適用。',
  },
  {
    case_id: 'hamakyo_rex_H30',
    short_name: 'ハマキョウレックス事件',
    decision_date: '2018-06-01',
    law_areas: ['labor' as LawCategory],
    related_laws: ['労働契約法第20条', '労働者派遣法'],
    citation: '最判H30.6.1 民集72-2-202',
    summary: '有期と無期の不合理な労働条件相違の判断枠組み (労契法20条)。',
  },
  {
    case_id: 'nagasawa_unyu_H30',
    short_name: '長澤運輸事件',
    decision_date: '2018-06-01',
    law_areas: ['labor' as LawCategory],
    related_laws: ['労働契約法第20条'],
    citation: '最判H30.6.1 民集72-2-265',
    summary: '定年再雇用の有期契約と無期の労働条件相違の合理性判断。',
  },
  {
    case_id: 'osaka_iyaku_R2',
    short_name: '大阪医科薬科事件',
    decision_date: '2020-10-13',
    law_areas: ['labor' as LawCategory],
    related_laws: ['労働契約法第20条 (現パート有期労働法第8条)'],
    citation: '最判R2.10.13 民集74-7-1717',
    summary: 'アルバイト職員の賞与・退職金不支給の不合理性判断。',
  },
  {
    case_id: 'benesse_pii',
    short_name: 'ベネッセ事件',
    decision_date: '2017-10-23',
    law_areas: ['privacy' as LawCategory],
    related_laws: ['個情法', '民法第709条'],
    damage_benchmark_per_person_jpy: 1000,
    citation: '東京高裁H29.10.23 判時2364-46',
    summary: '個人情報漏えいの慰謝料 1名 1,000円 (ベネッセ通信教育 顧客情報流出)。',
  },
  {
    case_id: 'jal_zaikan',
    short_name: 'JAL管財事件',
    decision_date: '2011-09-22',
    law_areas: ['corporate' as LawCategory, 'labor' as LawCategory],
    related_laws: ['会社法', '労働契約法', '会社更生法'],
    citation: '最判H23.9.22',
    summary: '会社更生中の整理解雇 4要件の適用。',
  },
  {
    case_id: 'koshinryo_H23',
    short_name: '更新料事件',
    decision_date: '2011-07-15',
    law_areas: ['real_estate' as LawCategory, 'consumer' as LawCategory],
    related_laws: ['消費者契約法第10条', '借地借家法'],
    citation: '最判H23.7.15 民集65-5-2269',
    summary: '更新料条項は消費者契約法10条の不当条項には当たらない (相当性の枠内)。',
  },
  {
    case_id: 'uber_eats_R4',
    short_name: 'Uber Eats 配達員労組事件',
    decision_date: '2022-11-25',
    law_areas: ['labor' as LawCategory],
    related_laws: ['労働組合法第3条'],
    citation: '東京都労委R4.11.25',
    summary: 'ギグワーカー (配達員) の労組法上の労働者性肯定。',
  },

  // ============== 商事 8 件 ==============
  {
    case_id: 'yawata_seitetsu_S45',
    short_name: '八幡製鉄政治献金事件',
    decision_date: '1970-06-24',
    law_areas: ['corporate' as LawCategory],
    related_laws: ['会社法第330条', '民法第643条'],
    citation: '最大判S45.6.24 民集24-6-625',
    summary: '会社の政治献金は権利能力の範囲内。取締役の善管注意義務に違反せず。',
  },
  {
    case_id: 'directors_third_party_S44',
    short_name: '取締役の第三者責任',
    decision_date: '1969-11-26',
    law_areas: ['corporate' as LawCategory],
    related_laws: ['会社法第429条 (旧商法266条の3)'],
    citation: '最大判S44.11.26 民集23-11-2150',
    summary: '取締役の任務懈怠による第三者責任は法定責任 (会社法429条の独立責任)。',
  },
  {
    case_id: 'business_judgment_H22',
    short_name: '経営判断原則 (アパマンショップ)',
    decision_date: '2010-07-15',
    law_areas: ['corporate' as LawCategory],
    related_laws: ['会社法第330条', '民法第644条'],
    citation: '最判H22.7.15',
    summary: '経営判断原則。著しく不合理でない限り取締役の善管注意義務違反なし。',
  },
  {
    case_id: 'bank_supervision_H21',
    short_name: '銀行取締役監視義務',
    decision_date: '2009-07-09',
    law_areas: ['corporate' as LawCategory, 'finance' as LawCategory],
    related_laws: ['会社法第330条', '銀行法'],
    citation: '最判H21.7.9',
    summary: '銀行取締役は内部統制システム構築義務+業務執行の監視義務。',
  },
  {
    case_id: 'rights_plan_H19',
    short_name: 'ライツプラン (新株予約権) 事件',
    decision_date: '2007-08-07',
    law_areas: ['corporate' as LawCategory],
    related_laws: ['会社法第247条', '会社法第280条'],
    citation: '最決H19.8.7 民集61-5-2215 (ブルドックソース)',
    summary: '敵対的買収防衛策の差別的行使は著しく不公正な発行に当たらず (株主総会承認あり)。',
  },
  {
    case_id: 'former_shareholder_R2',
    short_name: '株主代表訴訟 旧株主',
    decision_date: '2020-09-03',
    law_areas: ['corporate' as LawCategory],
    related_laws: ['会社法第847条の2'],
    citation: '最判R2.9.3',
    summary: '株式交換等で原告適格を失った旧株主の代表訴訟継続を認める。',
  },
  {
    case_id: 'chanel_parallel_H15',
    short_name: 'シャネル並行輸入事件',
    decision_date: '2003-10-10',
    law_areas: ['trademark' as LawCategory, 'corporate' as LawCategory],
    related_laws: ['商標法第36条', '不正競争防止法第2条'],
    citation: '最判H15.10.10',
    summary: '真正商品の並行輸入は商標権侵害に当たらない (要件論)。',
  },
  {
    case_id: 'yakult_directors_H6',
    short_name: 'ヤクルト本社取締役損害賠償',
    decision_date: '1994-07-14',
    law_areas: ['corporate' as LawCategory],
    related_laws: ['会社法第423条 (旧商法266条)'],
    citation: '最判H6.7.14',
    summary: '取締役会承認を欠く取引と善管注意義務違反 (デリバティブ取引)。',
  },

  // ============== 労働 8 件 ==============
  {
    case_id: 'kansai_ikadai_H17',
    short_name: '関西医科大学研修医事件',
    decision_date: '2005-06-03',
    law_areas: ['labor' as LawCategory],
    related_laws: ['労働基準法第9条'],
    citation: '最判H17.6.3 民集59-5-938',
    summary: '研修医も労基法上の労働者。最低賃金法・労働時間規制が適用。',
  },
  {
    case_id: 'sancho_takushi_S43',
    short_name: '第二鳩タクシー事件',
    decision_date: '1968-04-09',
    law_areas: ['labor' as LawCategory],
    related_laws: ['労働基準法第26条', '民法第536条'],
    citation: '最判S43.4.9 民集22-4-845',
    summary: '使用者責任=危険負担。労基法26条休業手当の支払義務。',
  },
  {
    case_id: 'kochi_hoso_S52',
    short_name: '高知放送事件',
    decision_date: '1977-01-31',
    law_areas: ['labor' as LawCategory],
    related_laws: ['労働契約法第16条 (旧民法626条解雇権濫用)'],
    citation: '最判S52.1.31 労判268-17',
    summary: '解雇権濫用法理。客観的合理性+社会的相当性なき解雇は無効。',
  },
  {
    case_id: 'mcdonald_management_position',
    short_name: 'マクドナルド名ばかり管理職事件',
    decision_date: '2008-01-28',
    law_areas: ['labor' as LawCategory],
    related_laws: ['労働基準法第41条第2号'],
    citation: '東京地裁H20.1.28 判時1998-149',
    summary: '管理監督者該当性。職務権限・労働時間裁量・賃金水準で総合判断。',
  },
  {
    case_id: 'restructuring_4_factors',
    short_name: '整理解雇 4要件 (東洋酸素事件)',
    decision_date: '1979-10-29',
    law_areas: ['labor' as LawCategory],
    related_laws: ['労働契約法第16条'],
    citation: '東京高判S54.10.29',
    summary: '整理解雇 4要件 (人員削減必要性/解雇回避努力/人選合理性/手続妥当性)。',
  },
  {
    case_id: 'pharma_cm_S37',
    short_name: '住友化学 (雇止め抗弁) 事件',
    decision_date: '1962-07-20',
    law_areas: ['labor' as LawCategory],
    related_laws: ['労働契約法第19条'],
    citation: '東京地判S37.7.20',
    summary: '雇止めは合理的理由必要 (実質無期と評価される場合)。',
  },

  // ============== 刑法 10 件 ==============
  {
    case_id: 'kyobo_kyodo_S33_nerima',
    short_name: '練馬事件 (共謀共同正犯)',
    decision_date: '1958-05-28',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第60条'],
    citation: '最大判S33.5.28 刑集12-8-1718',
    summary: '共謀共同正犯。実行行為を分担しない者も共謀があれば正犯。',
  },
  {
    case_id: 'goso_bogyo_S40',
    short_name: '誤想防衛',
    decision_date: '1965-04-13',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第36条', '刑法第38条'],
    citation: '最判S40.4.13 刑集19-3-185',
    summary: '誤想防衛は事実の錯誤として故意を阻却 (構成要件的故意)。',
  },
  {
    case_id: 'inga_kankei_h6',
    short_name: '米兵轢逃事件 (因果関係)',
    decision_date: '1994-12-06',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第38条', '刑法第199条'],
    citation: '最決H6.12.6 刑集48-8-509',
    summary: '介在事情ある因果関係。行為者の作出した危険の現実化として肯定。',
  },
  {
    case_id: 'sagi_H19',
    short_name: '詐欺罪 欺罔行為 (暴排免脱)',
    decision_date: '2007-07-17',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第246条'],
    citation: '最決H19.7.17',
    summary: '暴力団員であることを秘して銀行口座開設は詐欺罪に該当。',
  },
  {
    case_id: 'oryo_H15',
    short_name: '横領罪 不法領得意思',
    decision_date: '2003-03-18',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第252条'],
    citation: '最決H15.3.18 刑集57-3-356',
    summary: '横領罪の不法領得意思。第三者のためにする場合も成立。',
  },
  {
    case_id: 'hoka_H15',
    short_name: '放火罪 公共危険',
    decision_date: '2003-04-14',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第108条', '刑法第109条'],
    citation: '最決H15.4.14',
    summary: '建造物等以外放火罪における公共の危険の認識不要 (現在の通説判例)。',
  },
  {
    case_id: 'kabai_S62',
    short_name: '客体の錯誤',
    decision_date: '1987-03-26',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第38条'],
    citation: '最判S62.3.26 刑集41-2-181',
    summary: '抽象的事実の錯誤 (構成要件の重なり合いの限度で故意あり)。',
  },
  {
    case_id: 'satsui_H30',
    short_name: '殺意の認定',
    decision_date: '2018-03-19',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第199条', '刑法第38条'],
    citation: '最判H30.3.19',
    summary: '殺意の認定における客観的危険性+主観的認識の総合考慮。',
  },
  {
    case_id: 'kyodo_S33_main',
    short_name: '共謀共同正犯 (大法廷)',
    decision_date: '1958-05-28',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第60条'],
    citation: '最大判S33.5.28 刑集12-8-1718',
    summary: '共謀共同正犯の理論的根拠 (大法廷)。',
  },
  {
    case_id: 'futsu_S30',
    short_name: '公務執行妨害 暴行概念',
    decision_date: '1955-10-25',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第95条'],
    citation: '最判S30.10.25 刑集9-11-2380',
    summary: '公務執行妨害罪の暴行は職務執行に向けられたもので足りる (広義の暴行)。',
  },

  // ============== 知財 10 件 ==============
  {
    case_id: 'ballspline_H10',
    short_name: 'ボールスプライン事件 (均等論)',
    decision_date: '1998-02-24',
    law_areas: ['patent' as LawCategory],
    related_laws: ['特許法第70条'],
    citation: '最判H10.2.24 民集52-1-113',
    summary: '均等論 5 要件 (本質的部分以外/置換可能/置換容易/公知ではない/意識的除外なし)。',
  },
  {
    case_id: 'kilby_H12',
    short_name: 'キルビー特許事件',
    decision_date: '2000-04-11',
    law_areas: ['patent' as LawCategory],
    related_laws: ['特許法第104条の3', '特許法第29条第2項'],
    citation: '最判H12.4.11 民集54-4-1368',
    summary: '無効理由を有する特許権の行使は権利濫用に当たる (キルビー抗弁)。',
  },
  {
    case_id: 'product_by_process_H27',
    short_name: 'プロダクトバイプロセス',
    decision_date: '2015-06-05',
    law_areas: ['patent' as LawCategory],
    related_laws: ['特許法第36条第6項', '特許法第70条'],
    citation: '最判H27.6.5 民集69-4-700',
    summary: '物の発明をその製造方法で特定するクレームの不明瞭性 (明確性要件)。',
  },
  {
    case_id: 'support_requirement_H17',
    short_name: 'サポート要件 (偏光フィルム)',
    decision_date: '2005-11-11',
    law_areas: ['patent' as LawCategory],
    related_laws: ['特許法第36条第6項第1号'],
    citation: '知財高判大合議H17.11.11',
    summary: 'サポート要件の判断枠組み (明細書記載と請求項の対応関係)。',
  },
  {
    case_id: 'retweet_R2',
    short_name: 'リツイート著作権事件',
    decision_date: '2020-07-21',
    law_areas: ['copyright' as LawCategory],
    related_laws: ['著作権法第19条', '著作権法第20条'],
    citation: '最判R2.7.21 民集74-4-1407',
    summary: 'リツイートで自動トリミングされる画像は氏名表示権・同一性保持権侵害となり得る。',
  },
  {
    case_id: 'parody_montage_S55',
    short_name: 'パロディモンタージュ事件',
    decision_date: '1980-03-28',
    law_areas: ['copyright' as LawCategory],
    related_laws: ['著作権法第32条'],
    citation: '最判S55.3.28 民集34-3-244',
    summary: '引用要件 (公正な慣行+正当な範囲)。パロディは原著作物への同一性保持権侵害となる。',
  },
  {
    case_id: 'kabukabu_R5',
    short_name: 'カブカブ事件 (商標的使用論)',
    decision_date: '2023-06-08',
    law_areas: ['trademark' as LawCategory],
    related_laws: ['商標法第26条第1項第6号'],
    citation: '知財高裁R5.6.8',
    summary: '商標的使用論。需要者が出所識別標識として認識しない使用は侵害不成立。',
  },
  {
    case_id: 'crystal_geyser',
    short_name: 'クリスタルガイザー事件',
    decision_date: '2020-03-19',
    law_areas: ['trade_secret' as LawCategory],
    related_laws: ['不正競争防止法第2条第1項第3号'],
    citation: '東京地判R2.3.19',
    summary: '商品形態模倣 (デッドコピー) は不競法2条1項3号で 3 年保護。',
  },
  {
    case_id: 'jasrac_subscription',
    short_name: 'JASRAC包括徴収事件',
    decision_date: '2015-04-28',
    law_areas: ['copyright' as LawCategory],
    related_laws: ['著作権法', '独占禁止法第3条'],
    citation: '最判H27.4.28',
    summary: '著作権管理事業の包括契約と私的独占。',
  },
  {
    case_id: 'patent_troll_H29',
    short_name: 'パテントトロール事件',
    decision_date: '2017-07-10',
    law_areas: ['patent' as LawCategory],
    related_laws: ['特許法第104条の3'],
    citation: '最判H29.7.10',
    summary: '不実施特許権者による差止請求の権利濫用判定枠組み。',
  },

  // ============== 行政 8 件 ==============
  {
    case_id: 'mclean_S53',
    short_name: 'マクリーン事件',
    decision_date: '1978-10-04',
    law_areas: ['admin' as LawCategory],
    related_laws: ['出入国管理及び難民認定法', '日本国憲法第22条'],
    citation: '最大判S53.10.4 民集32-7-1223',
    summary: '在留期間更新の許否は法務大臣の広範な裁量。外国人の人権の限界。',
  },
  {
    case_id: 'osaka_airport_S56',
    short_name: '大阪空港事件',
    decision_date: '1981-12-16',
    law_areas: ['admin' as LawCategory],
    related_laws: ['国家賠償法第2条', '民事訴訟法'],
    citation: '最大判S56.12.16 民集35-10-1369',
    summary: '公の営造物責任 (空港騒音)。差止請求は民事訴訟では認められず損害賠償のみ。',
  },
  {
    case_id: 'monju_H4',
    short_name: 'もんじゅ訴訟',
    decision_date: '1992-09-22',
    law_areas: ['admin' as LawCategory],
    related_laws: ['核原料物質、核燃料物質及び原子炉の規制に関する法律', '行政事件訴訟法第9条'],
    citation: '最判H4.9.22 民集46-6-571',
    summary: '原子炉設置許可処分の取消訴訟における原告適格 (周辺住民)。',
  },
  {
    case_id: 'chloroquine_H1',
    short_name: 'クロロキン薬害事件',
    decision_date: '1989-11-24',
    law_areas: ['admin' as LawCategory],
    related_laws: ['国家賠償法第1条', '薬機法'],
    citation: '最判H元.11.24 民集43-10-1169',
    summary: '規制権限不行使による国家賠償責任の判断枠組み。',
  },
  {
    case_id: 'foreign_voting_H17',
    short_name: '在外日本人選挙権事件',
    decision_date: '2005-09-14',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第15条', '日本国憲法第43条', '日本国憲法第44条'],
    citation: '最大判H17.9.14 民集59-7-2087',
    summary: '在外邦人の国政選挙権制限は違憲。違憲確認訴訟+国家賠償。',
  },
  {
    case_id: 'reason_attachment_H23',
    short_name: '理由附記 一級建築士免許取消',
    decision_date: '2011-06-07',
    law_areas: ['admin' as LawCategory],
    related_laws: ['行政手続法第14条', '建築士法'],
    citation: '最判H23.6.7 民集65-4-2081',
    summary: '行政処分の理由附記不備は処分取消事由。',
  },
  {
    case_id: 'info_disclosure_H13',
    short_name: '情報公開 不開示処分',
    decision_date: '2001-12-18',
    law_areas: ['privacy' as LawCategory, 'admin' as LawCategory],
    related_laws: ['行政機関の保有する情報の公開に関する法律', '個情法'],
    citation: '最判H13.12.18 民集55-7-1603',
    summary: '個人識別情報の不開示判断 (本人特定性)。',
  },
  {
    case_id: 'tap_water_H4',
    short_name: '水俣病関西訴訟',
    decision_date: '2004-10-15',
    law_areas: ['admin' as LawCategory, 'environment' as LawCategory],
    related_laws: ['公害健康被害補償法', '国家賠償法第1条'],
    citation: '最判H16.10.15 民集58-7-1802',
    summary: '国の規制権限不行使と国家賠償 (水質汚濁防止)。',
  },

  // ============== 税務 6 件 ==============
  {
    case_id: 'takefuji_H23',
    short_name: '武富士贈与税事件',
    decision_date: '2011-02-18',
    law_areas: ['tax' as LawCategory],
    related_laws: ['相続税法第1条の4', '相続税法第2条の2'],
    citation: '最判H23.2.18 民集65-2-546',
    summary: '住所の認定。生活の本拠と認められる場所 (武富士元会長長男)。',
  },
  {
    case_id: 'tsuhotsushi_H17',
    short_name: '株主間借入 みなし贈与',
    decision_date: '2005-12-19',
    law_areas: ['tax' as LawCategory],
    related_laws: ['相続税法第9条'],
    citation: '最判H17.12.19',
    summary: '相続税法9条のみなし贈与。経済的利益の判断。',
  },
  {
    case_id: 'honda_h22',
    short_name: '移転価格 ホンダ事件',
    decision_date: '2010-07-06',
    law_areas: ['tax' as LawCategory],
    related_laws: ['租税特別措置法第66条の4'],
    citation: '最判H22.7.6',
    summary: '独立企業間価格の算定。CUP法・原価基準法・利益分割法。',
  },
  {
    case_id: 'tsuho_takan_R4',
    short_name: '相続税通達6項 (路線価評価)',
    decision_date: '2022-04-19',
    law_areas: ['tax' as LawCategory],
    related_laws: ['相続税法第22条', '財産評価基本通達6'],
    citation: '最判R4.4.19 民集76-4-411',
    summary: '路線価評価を例外的に否認する通達6項の合憲性。',
  },
  {
    case_id: 'economic_reason_h6',
    short_name: '経済合理性 法人税',
    decision_date: '1994-06-13',
    law_areas: ['tax' as LawCategory],
    related_laws: ['法人税法第132条'],
    citation: '最判H6.6.13',
    summary: '同族会社の行為計算否認 (経済合理性判定)。',
  },
  {
    case_id: 'kakudai_S62',
    short_name: '重加算税',
    decision_date: '1987-05-08',
    law_areas: ['tax' as LawCategory],
    related_laws: ['国税通則法第68条'],
    citation: '最判S62.5.8',
    summary: '重加算税の要件 (事実隠蔽・仮装の故意)。',
  },

  // ============== 消費者 2 件 ==============
  {
    case_id: 'consumer_loan_S39',
    short_name: '貸金業 グレーゾーン金利',
    decision_date: '2006-01-13',
    law_areas: ['consumer' as LawCategory, 'finance' as LawCategory],
    related_laws: ['利息制限法第1条', '貸金業法'],
    citation: '最判H18.1.13 民集60-1-1',
    summary: 'みなし弁済の要件 (任意性) を厳格化 → グレーゾーン金利返還請求拡大。',
  },
  {
    case_id: 'tokushohou_R元',
    short_name: '特商法 定期購入規制',
    decision_date: '2019-12-01',
    law_areas: ['consumer' as LawCategory],
    related_laws: ['特定商取引法第12条の6'],
    citation: '消費者庁 R元.12.1 ガイドライン',
    summary: '定期購入の最終確認画面義務化 (申込み撤回の前置)。',
  },
];

/**
 * 法令の通称または条文から関連判例を抽出。
 * 例: '個情法' → ベネッセ事件, '労働契約法第20条' → ハマキョウ+大阪医薬等
 */
export function findCasesByLawReference(lawRef: string): CaseLawRef[] {
  if (!lawRef) return [];
  const norm = lawRef.replace(/\s/g, '');
  return LANDMARK_CASES_INDEX.filter((c) =>
    c.related_laws.some((l) => l.includes(norm) || norm.includes(l.replace(/第\d+条.*$/, '')))
  );
}

/**
 * 法令カテゴリで判例を逆引き
 */
export function findCasesByCategory(category: LawCategory): CaseLawRef[] {
  return LANDMARK_CASES_INDEX.filter((c) => c.law_areas.includes(category));
}

/**
 * 損害賠償ベンチマークから「個情法漏えい1名あたり」のレンジを取得
 */
export function getDamageBenchmarkRange(category: LawCategory): {
  min_per_person_jpy: number;
  max_per_person_jpy: number;
  median_per_person_jpy: number;
  source_cases: string[];
} | undefined {
  const cases = LANDMARK_CASES_INDEX.filter(
    (c) => c.law_areas.includes(category) && typeof c.damage_benchmark_per_person_jpy === 'number',
  );
  if (cases.length === 0) return undefined;
  const vals = cases.map((c) => c.damage_benchmark_per_person_jpy!).sort((a, b) => a - b);
  return {
    min_per_person_jpy: vals[0],
    max_per_person_jpy: vals[vals.length - 1],
    median_per_person_jpy: vals[Math.floor(vals.length / 2)],
    source_cases: cases.map((c) => c.short_name),
  };
}

/**
 * 法令改正検知 → 影響を受ける判例の抽出。
 */
export interface AmendmentJudiciaryImpact {
  law_id: string;
  changed_articles: string[];
  affected_cases: Array<{ case: CaseLawRef; reason: string }>;
}

export function analyzeJudiciaryImpact(input: {
  law_id: string;
  law_short_name: string;
  changed_articles: string[];
}): AmendmentJudiciaryImpact {
  const affected: Array<{ case: CaseLawRef; reason: string }> = [];
  for (const c of LANDMARK_CASES_INDEX) {
    for (const law of c.related_laws) {
      if (!law.includes(input.law_short_name) && !law.includes(input.law_id)) continue;
      for (const art of input.changed_articles) {
        const re = new RegExp(`第${art}条`);
        if (re.test(law)) {
          affected.push({
            case: c,
            reason: `${input.law_short_name}第${art}条が判例の論拠 → 改正で射程変動の可能性`,
          });
          break;
        }
      }
    }
  }
  return {
    law_id: input.law_id,
    changed_articles: input.changed_articles,
    affected_cases: affected,
  };
}

/**
 * 事件名・キーワードで判例を全文検索 (要約とshort_nameを対象)。
 */
export function searchCasesByKeyword(keyword: string, max = 10): CaseLawRef[] {
  if (!keyword) return [];
  const lower = keyword.toLowerCase();
  return LANDMARK_CASES_INDEX
    .filter((c) =>
      c.short_name.toLowerCase().includes(lower)
      || (c.summary ?? '').toLowerCase().includes(lower)
      || c.related_laws.some((l) => l.toLowerCase().includes(lower)),
    )
    .slice(0, max);
}

/**
 * 判例件数の統計 (カテゴリ別)。
 */
export function countCasesByCategory(): Record<string, number> {
  const counts: Record<string, number> = {};
  for (const c of LANDMARK_CASES_INDEX) {
    for (const la of c.law_areas) {
      counts[la] = (counts[la] ?? 0) + 1;
    }
  }
  return counts;
}
