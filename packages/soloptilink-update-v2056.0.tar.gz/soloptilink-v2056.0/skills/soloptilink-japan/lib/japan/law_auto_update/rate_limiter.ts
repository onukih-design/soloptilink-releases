/**
 * Phase 46-LU / レート制限 (Token Bucket per host)
 *
 * 政府API/官報スクレイピング先で 429 を出さないため、
 * ホストごとに 1 req/sec を default で守る簡易 Token Bucket。
 *
 * 既存 lib/japan/*.ts と独立 (副作用最小化)。
 */

interface Bucket {
  /** トークン残数 (浮動小数で時間補間) */
  tokens: number;
  /** 上限 */
  capacity: number;
  /** 1秒あたり補充トークン数 */
  refillPerSec: number;
  /** 最終更新 ms */
  lastRefillMs: number;
  /** 直列化キュー (順序保証) */
  queue: Array<() => void>;
  /** 処理中フラグ */
  draining: boolean;
}

const buckets = new Map<string, Bucket>();

const DEFAULT_REFILL_PER_SEC = 1;
const DEFAULT_CAPACITY = 1;

export interface RateLimitConfig {
  refillPerSec?: number;
  capacity?: number;
}

export function configureRateLimit(host: string, cfg: RateLimitConfig): void {
  const b = ensureBucket(host);
  if (cfg.capacity !== undefined) b.capacity = cfg.capacity;
  if (cfg.refillPerSec !== undefined) b.refillPerSec = cfg.refillPerSec;
}

/**
 * 関数 fn の実行を、host に紐づくレート制限内で順序的に行う。
 * Token が無ければ補充されるまで待機する。
 */
export async function rateLimited<T>(host: string, fn: () => Promise<T>): Promise<T> {
  await acquire(host);
  return await fn();
}

function ensureBucket(host: string): Bucket {
  let b = buckets.get(host);
  if (!b) {
    b = {
      tokens: DEFAULT_CAPACITY,
      capacity: DEFAULT_CAPACITY,
      refillPerSec: DEFAULT_REFILL_PER_SEC,
      lastRefillMs: Date.now(),
      queue: [],
      draining: false,
    };
    buckets.set(host, b);
  }
  return b;
}

function refill(b: Bucket): void {
  const now = Date.now();
  const elapsedSec = (now - b.lastRefillMs) / 1000;
  if (elapsedSec <= 0) return;
  b.tokens = Math.min(b.capacity, b.tokens + elapsedSec * b.refillPerSec);
  b.lastRefillMs = now;
}

async function acquire(host: string): Promise<void> {
  const b = ensureBucket(host);
  return new Promise<void>((resolve) => {
    b.queue.push(resolve);
    drain(b);
  });
}

function drain(b: Bucket): void {
  if (b.draining) return;
  b.draining = true;
  const tick = (): void => {
    refill(b);
    while (b.queue.length > 0 && b.tokens >= 1) {
      b.tokens -= 1;
      const next = b.queue.shift();
      if (next) next();
    }
    if (b.queue.length === 0) {
      b.draining = false;
      return;
    }
    // 1トークン補充までの待ち時間
    const needed = 1 - b.tokens;
    const waitMs = Math.max(10, (needed / b.refillPerSec) * 1000);
    setTimeout(tick, waitMs);
  };
  tick();
}

/** テスト用: バケット状態のリセット */
export function _resetRateLimiterForTests(): void {
  buckets.clear();
}

/** デバッグ用: 現在の状態 */
export function snapshotRateLimiter(): Array<{ host: string; tokens: number; queueLen: number }> {
  return [...buckets.entries()].map(([host, b]) => ({
    host,
    tokens: b.tokens,
    queueLen: b.queue.length,
  }));
}
