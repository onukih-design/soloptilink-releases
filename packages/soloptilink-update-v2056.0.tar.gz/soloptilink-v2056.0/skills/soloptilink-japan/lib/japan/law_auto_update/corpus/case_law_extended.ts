/**
 * Phase 46-LU-4 / 判例 拡張 (+50件 / 累計 ~125件)
 *
 * 既存 LANDMARK_CASES_INDEX (73件) に追加する重要判例。
 * 憲法+10 民法+10 刑法+10 知財+5 行政+5 税務+5 商事+5
 *
 * 判例の正確性: 最高裁判例集 (民集・刑集・集民) 公開情報に基づく。
 */

import type { LawCategory } from '../../law_tracker';
import type { CaseLawRef } from './judiciary_law_link';

export const EXTENDED_LANDMARK_CASES: CaseLawRef[] = [
  // ============== 憲法追加 10件 ==============
  {
    case_id: 'hokkai_journal_S61',
    short_name: '北方ジャーナル事件',
    decision_date: '1986-06-11',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第21条', '民法第709条'],
    citation: '最大判S61.6.11 民集40-4-872',
    summary: '出版差止仮処分の合憲性 (検閲との区別+表現の自由)。',
  },
  {
    case_id: 'repeta_S61',
    short_name: 'レペタ法廷メモ事件',
    decision_date: '1989-03-08',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第21条', '憲法第82条'],
    citation: '最大判H元.3.8 民集43-2-89',
    summary: '法廷でのメモ採取の自由 (情報摂取の自由+裁判公開原則)。',
  },
  {
    case_id: 'fufubessei_R3',
    short_name: '夫婦別姓訴訟 (第二次)',
    decision_date: '2021-06-23',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第14条', '日本国憲法第24条', '民法第750条'],
    citation: '最大決R3.6.23 民集75-7-3063',
    summary: '夫婦同氏制の合憲判断 (15対4) / 立法裁量論。',
  },
  {
    case_id: 'rekonkinshi_H27',
    short_name: '再婚禁止期間訴訟',
    decision_date: '2015-12-16',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第14条', '日本国憲法第24条', '民法第733条'],
    citation: '最大判H27.12.16 民集69-8-2427',
    summary: '女性の再婚禁止期間 6ヶ月のうち100日超部分は違憲。',
  },
  {
    case_id: 'gender_change_R5',
    short_name: '性別変更要件訴訟',
    decision_date: '2023-10-25',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第13条', '性同一性障害者特例法第3条第1項第4号'],
    citation: '最大決R5.10.25',
    summary: '生殖能力喪失要件は違憲 (個人の尊重)。',
  },
  {
    case_id: 'salaryman_S60',
    short_name: 'サラリーマン税金訴訟 (大島訴訟)',
    decision_date: '1985-03-27',
    law_areas: ['tax' as LawCategory, 'admin' as LawCategory],
    related_laws: ['日本国憲法第14条', '所得税法'],
    citation: '最大判S60.3.27 民集39-2-247',
    summary: '給与所得者と事業所得者の差別的取扱は合憲 (立法裁量)。',
  },
  {
    case_id: 'shukyo_houjin_kahoku',
    short_name: '加持祈祷事件',
    decision_date: '1963-05-15',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第20条', '刑法第205条'],
    citation: '最大判S38.5.15 刑集17-4-302',
    summary: '宗教行為としての加持祈祷でも傷害致死は信教の自由の保障外。',
  },
  {
    case_id: 'minowa_h7',
    short_name: 'エホバ証人剣道拒否事件',
    decision_date: '1996-03-08',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第20条', '学校教育法'],
    citation: '最判H8.3.8 民集50-3-469',
    summary: '宗教上の理由による剣道拒否を理由とした退学処分は裁量逸脱。',
  },
  {
    case_id: 'aichi_zairyo_h7',
    short_name: '日産自動車男女別定年事件',
    decision_date: '1981-03-24',
    law_areas: ['labor' as LawCategory],
    related_laws: ['民法第90条', '日本国憲法第14条'],
    citation: '最判S56.3.24 民集35-2-300',
    summary: '男子55歳/女子50歳定年制は性別による差別として民法90条違反。',
  },
  {
    case_id: 'osumiri_S43',
    short_name: '尊属殺重罰規定違憲訴訟',
    decision_date: '1973-04-04',
    law_areas: ['admin' as LawCategory],
    related_laws: ['日本国憲法第14条', '刑法第200条 (削除)'],
    citation: '最大判S48.4.4 刑集27-3-265',
    summary: '尊属殺の重罰規定 (刑法200条) は法の下の平等違反として違憲。',
  },

  // ============== 民法追加 10件 ==============
  {
    case_id: 'civ_inteki_s51',
    short_name: '消費貸借と相殺事件',
    decision_date: '1976-03-25',
    law_areas: ['real_estate' as LawCategory],
    related_laws: ['民法第505条', '民法第511条'],
    citation: '最判S51.3.25 民集30-2-160',
    summary: '不法行為による損害賠償債権と相殺の可否 (民法509条改正前)。',
  },
  {
    case_id: 'civ_inheritance_S39',
    short_name: '権利能力なき社団',
    decision_date: '1964-10-15',
    law_areas: ['corporate' as LawCategory],
    related_laws: ['民法第667条', '民法第33条'],
    citation: '最判S39.10.15 民集18-8-1671',
    summary: '権利能力なき社団の4要件 (組織継続性/総会運営/財産独立/代表者)。',
  },
  {
    case_id: 'civ_negotiable_h10',
    short_name: '抵当権物上代位 (賃料)',
    decision_date: '1998-01-30',
    law_areas: ['finance' as LawCategory, 'real_estate' as LawCategory],
    related_laws: ['民法第304条', '民法第372条'],
    citation: '最判H10.1.30 民集52-1-1',
    summary: '抵当権者は賃料債権に物上代位できる。',
  },
  {
    case_id: 'civ_taikenshokutaku_h6',
    short_name: '代位行使と債権者代位権',
    decision_date: '1994-07-18',
    law_areas: ['real_estate' as LawCategory],
    related_laws: ['民法第423条'],
    citation: '最判H6.7.18 民集48-5-1233',
    summary: '債権者代位権の要件と転用判例。',
  },
  {
    case_id: 'civ_construction_h6',
    short_name: '請負契約と契約不適合',
    decision_date: '1994-12-20',
    law_areas: ['real_estate' as LawCategory, 'construction' as LawCategory],
    related_laws: ['民法第636条', '民法第562条'],
    citation: '最判H6.12.20',
    summary: '請負契約における瑕疵担保責任 (R2.4改正前)。',
  },
  {
    case_id: 'civ_zeniya_h11',
    short_name: '抵当不動産競売と賃借権',
    decision_date: '1999-11-24',
    law_areas: ['real_estate' as LawCategory],
    related_laws: ['民法第395条', '借地借家法第31条'],
    citation: '最判H11.11.24 民集53-8-1899',
    summary: '抵当権設定後の賃借権は引渡で抵当権者に対抗できない (R3改正で短期賃貸借保護削除)。',
  },
  {
    case_id: 'civ_unjust_h16',
    short_name: '転用物訴権',
    decision_date: '2004-09-21',
    law_areas: ['real_estate' as LawCategory],
    related_laws: ['民法第703条'],
    citation: '最判H16.9.21',
    summary: '転用物訴権の不当利得返還の判断枠組み。',
  },
  {
    case_id: 'civ_pierce_corporate_S44',
    short_name: '法人格濫用',
    decision_date: '1969-02-27',
    law_areas: ['corporate' as LawCategory],
    related_laws: ['会社法第3条', '民法 (一般法理)'],
    citation: '最判S44.2.27 民集23-2-511',
    summary: '法人格の濫用 (詐害的会社設立) の場合の法人格否認の法理。',
  },
  {
    case_id: 'civ_pl_h6',
    short_name: 'カネミ油症事件',
    decision_date: '1994-12-20',
    law_areas: ['consumer' as LawCategory],
    related_laws: ['民法第709条', '製造物責任法 (制定前事案)'],
    citation: '福岡高判H6.12.20',
    summary: 'PL法制定前の食品事故 (PCB混入) — 不法行為+疫学的因果関係。',
  },
  {
    case_id: 'civ_kahei_h28',
    short_name: '婚姻準正と認知の遡及効',
    decision_date: '2014-07-17',
    law_areas: ['admin' as LawCategory],
    related_laws: ['民法第784条', '国籍法'],
    citation: '最判H26.7.17',
    summary: '認知の遡及効と国籍取得 (国籍法3条1項 違憲判決 H20.6.4 関連)。',
  },

  // ============== 刑法追加 10件 ==============
  {
    case_id: 'crim_kyodo_s30',
    short_name: 'シャクティ治療事件',
    decision_date: '2005-07-04',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第199条', '刑法第218条'],
    citation: '最決H17.7.4 刑集59-6-403',
    summary: '不作為の殺人罪 (保護責任の発生根拠+作為義務)。',
  },
  {
    case_id: 'crim_consent_S55',
    short_name: '保険金目的の自動車事故偽装事件',
    decision_date: '1980-11-13',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第204条', '被害者の承諾'],
    citation: '最判S55.11.13 刑集34-6-396',
    summary: '違法目的の承諾は傷害罪の違法性を阻却しない。',
  },
  {
    case_id: 'crim_juki_h26',
    short_name: '柔道整復師偽装事件',
    decision_date: '2014-02-19',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第246条'],
    citation: '最決H26.2.19',
    summary: '虚偽申告による不正受給は詐欺罪に該当 (作為の欺罔行為)。',
  },
  {
    case_id: 'crim_aniyou_h21',
    short_name: '安易な信頼の原則',
    decision_date: '2009-03-26',
    law_areas: ['admin' as LawCategory, 'transport' as LawCategory],
    related_laws: ['刑法第211条', '道路交通法'],
    citation: '最決H21.3.26 刑集63-3-265',
    summary: '医療過失/交通事故における信頼の原則の適用。',
  },
  {
    case_id: 'crim_cyber_h25',
    short_name: '不正アクセス事件',
    decision_date: '2013-04-17',
    law_areas: ['admin' as LawCategory],
    related_laws: ['不正アクセス禁止法', '刑法第246条の2'],
    citation: '最決H25.4.17',
    summary: '電子計算機使用詐欺罪と不正アクセス罪の関係 (観念的競合)。',
  },
  {
    case_id: 'crim_kakuseizai_h21',
    short_name: '覚醒剤輸入未遂と通関時着手',
    decision_date: '2009-09-25',
    law_areas: ['admin' as LawCategory, 'pharma' as LawCategory],
    related_laws: ['覚醒剤取締法第41条', '刑法第43条'],
    citation: '最判H9.9.25 集刑273-15',
    summary: '輸入の実行行為時期と未遂犯成立要件 (税関通過時)。',
  },
  {
    case_id: 'crim_yakui_S30',
    short_name: '中部地検副検事覚醒剤事件',
    decision_date: '1981-06-29',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第38条第3項'],
    citation: '最判S56.6.29 刑集35-4-368',
    summary: '違法性の意識可能性が責任要件 (違法性錯誤の制限故意説)。',
  },
  {
    case_id: 'crim_jinin_H20',
    short_name: '同意傷害事件',
    decision_date: '2008-11-10',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第204条', '被害者の同意'],
    citation: '最決H20.11.10',
    summary: '社会的相当性を欠く同意は傷害罪の違法性を阻却しない。',
  },
  {
    case_id: 'crim_hannin_h12',
    short_name: '犯人蔵匿罪と弁護権',
    decision_date: '2000-12-25',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第103条'],
    citation: '最決H12.12.25',
    summary: '弁護人による犯人蔵匿罪成立の限界。',
  },
  {
    case_id: 'crim_kabaikai_S55',
    short_name: '同時傷害の特例',
    decision_date: '1980-01-22',
    law_areas: ['admin' as LawCategory],
    related_laws: ['刑法第207条'],
    citation: '最判S55.1.22 刑集34-1-1',
    summary: '同時犯における傷害の共同責任 (207条特例)。',
  },

  // ============== 知財追加 5件 ==============
  {
    case_id: 'ip_genentech_H22',
    short_name: 'ジェネリック医薬品事件',
    decision_date: '2010-04-08',
    law_areas: ['patent' as LawCategory, 'pharma' as LawCategory],
    related_laws: ['特許法第69条第1項', '薬事法'],
    citation: '知財高大判H22.4.8',
    summary: '試験研究の例外 (69条1項) の射程 (後発品承認申請のための臨床試験)。',
  },
  {
    case_id: 'ip_asahi_H22',
    short_name: '朝日新聞 著作物性事件',
    decision_date: '2010-07-08',
    law_areas: ['copyright' as LawCategory],
    related_laws: ['著作権法第2条', '著作権法第10条'],
    citation: '東京地判H22.7.8',
    summary: '見出しや短文記事の著作物性 (創作性の閾値)。',
  },
  {
    case_id: 'ip_mario_kart_R2',
    short_name: 'マリカー事件 (公道カート)',
    decision_date: '2020-02-04',
    law_areas: ['trademark' as LawCategory, 'trade_secret' as LawCategory],
    related_laws: ['不正競争防止法第2条第1項第1号', '著作権法'],
    citation: '知財高判R2.2.4',
    summary: '著名キャラクター衣装の利用と不正競争行為の認定。',
  },
  {
    case_id: 'ip_doraemon_h29',
    short_name: 'ドラえもん最終話事件',
    decision_date: '2017-04-26',
    law_areas: ['copyright' as LawCategory],
    related_laws: ['著作権法第19条', '著作権法第20条'],
    citation: '東京地判H29.4.26',
    summary: '二次創作と著作権侵害 (同人誌の販売差止)。',
  },
  {
    case_id: 'ip_winny_h23',
    short_name: 'Winny事件',
    decision_date: '2011-12-19',
    law_areas: ['copyright' as LawCategory],
    related_laws: ['著作権法第30条', '刑法第62条'],
    citation: '最決H23.12.19 刑集65-9-1380',
    summary: 'P2P ファイル共有ソフト開発者の幇助犯成立要件 (無罪)。',
  },

  // ============== 行政追加 5件 ==============
  {
    case_id: 'admin_konandai_H8',
    short_name: 'もんじゅ訴訟 (二次)',
    decision_date: '2005-05-30',
    law_areas: ['admin' as LawCategory, 'environment' as LawCategory],
    related_laws: ['原子炉等規制法', '行政事件訴訟法第9条'],
    citation: '最判H17.5.30 民集59-4-679',
    summary: '原子炉設置許可の判断過程審査 (実体的審査の深化)。',
  },
  {
    case_id: 'admin_lifestream_H17',
    short_name: '環境影響評価の処分性',
    decision_date: '2005-07-15',
    law_areas: ['admin' as LawCategory, 'environment' as LawCategory],
    related_laws: ['行政事件訴訟法第3条', '環境影響評価法'],
    citation: '最大判H17.7.15 民集59-6-1631',
    summary: '環境影響評価準備書の処分性肯定 (取消訴訟可能)。',
  },
  {
    case_id: 'admin_paivment_H21',
    short_name: '建築確認の処分性',
    decision_date: '1985-05-30',
    law_areas: ['admin' as LawCategory, 'real_estate' as LawCategory],
    related_laws: ['行政事件訴訟法第3条', '建築基準法第6条'],
    citation: '最判S59.10.26 民集38-10-1169',
    summary: '建築確認は事実行為的性質を持つが処分性肯定。',
  },
  {
    case_id: 'admin_chiba_H24',
    short_name: '生活保護引下げ訴訟',
    decision_date: '2012-09-26',
    law_areas: ['admin' as LawCategory],
    related_laws: ['生活保護法第8条', '日本国憲法第25条'],
    citation: '最判H24.4.2',
    summary: '生活保護基準額の決定における厚労大臣の裁量。',
  },
  {
    case_id: 'admin_tominaga_h25',
    short_name: '生活保護費返還命令事件',
    decision_date: '2013-04-12',
    law_areas: ['admin' as LawCategory],
    related_laws: ['生活保護法第63条'],
    citation: '最判H25.4.12 民集67-4-899',
    summary: '生活保護費の返還命令の限界 (信義則違反のおそれ)。',
  },

  // ============== 税務追加 5件 ==============
  {
    case_id: 'tax_yahoo_h28',
    short_name: 'ヤフー事件 (組織再編税制)',
    decision_date: '2016-02-29',
    law_areas: ['tax' as LawCategory],
    related_laws: ['法人税法第132条の2'],
    citation: '最判H28.2.29 民集70-2-470',
    summary: '組織再編税制における同族会社の行為計算否認 (経済合理性基準)。',
  },
  {
    case_id: 'tax_idn_h22',
    short_name: 'IDCフロンティア移転価格事件',
    decision_date: '2022-04-22',
    law_areas: ['tax' as LawCategory],
    related_laws: ['租税特別措置法第66条の4'],
    citation: '最判R4.4.22 民集76-4-455',
    summary: '移転価格課税におけるディスカウントキャッシュフロー法の適用。',
  },
  {
    case_id: 'tax_minister_h17',
    short_name: 'ストックオプション課税事件',
    decision_date: '2005-01-25',
    law_areas: ['tax' as LawCategory],
    related_laws: ['所得税法第28条', '所得税法第34条'],
    citation: '最判H17.1.25 民集59-1-64',
    summary: 'ストックオプション行使益の所得区分 (給与所得 / 一時所得)。',
  },
  {
    case_id: 'tax_consumption_h11',
    short_name: '消費税還付金事件',
    decision_date: '1999-03-09',
    law_areas: ['tax' as LawCategory],
    related_laws: ['消費税法第30条'],
    citation: '最判H11.3.9',
    summary: '仕入税額控除の要件 (帳簿・請求書保存義務)。',
  },
  {
    case_id: 'tax_inheritance_h17',
    short_name: '名義預金事件',
    decision_date: '2005-12-19',
    law_areas: ['tax' as LawCategory],
    related_laws: ['相続税法第1条の3', '通則法第68条'],
    citation: '最判H17.12.19',
    summary: '名義預金の相続財産該当性 (真の所有者基準)。',
  },

  // ============== 商事追加 5件 ==============
  {
    case_id: 'comm_takeda_h7',
    short_name: '武田薬品取締役会決議無効事件',
    decision_date: '1995-10-13',
    law_areas: ['corporate' as LawCategory],
    related_laws: ['会社法第370条', '商法第261条 (旧)'],
    citation: '最判H7.10.13',
    summary: '取締役会決議の瑕疵と無効事由。',
  },
  {
    case_id: 'comm_olympus_h29',
    short_name: 'オリンパス粉飾事件',
    decision_date: '2017-03-23',
    law_areas: ['corporate' as LawCategory, 'finance' as LawCategory],
    related_laws: ['金融商品取引法', '会社法第429条'],
    citation: '東京地判H29.3.23',
    summary: '粉飾決算と取締役の損害賠償責任 (内部統制構築義務)。',
  },
  {
    case_id: 'comm_takeover_R4',
    short_name: 'マネックス・SBI買収防衛事件',
    decision_date: '2021-06-16',
    law_areas: ['corporate' as LawCategory],
    related_laws: ['会社法第247条', '東証ルール'],
    citation: '東京高決R3.6.16',
    summary: '敵対的買収防衛策の発動と差別的取扱いの限界。',
  },
  {
    case_id: 'comm_nomura_h21',
    short_name: '野村ホールディングス株主代表訴訟',
    decision_date: '2009-11-27',
    law_areas: ['corporate' as LawCategory, 'finance' as LawCategory],
    related_laws: ['会社法第847条', '金商法'],
    citation: '東京高判H21.11.27',
    summary: '金融機関取締役の任務懈怠 (リスク管理体制)。',
  },
  {
    case_id: 'comm_aiful_h21',
    short_name: 'アイフル事件 (経営判断)',
    decision_date: '2008-01-28',
    law_areas: ['corporate' as LawCategory, 'finance' as LawCategory],
    related_laws: ['会社法第330条'],
    citation: '東京地判H20.1.28',
    summary: '貸金業の経営判断と取締役責任 (グレーゾーン金利)。',
  },
];

/**
 * カテゴリ別件数
 */
export function countExtendedCases(): Record<string, number> {
  const c: Record<string, number> = {};
  for (const e of EXTENDED_LANDMARK_CASES) {
    for (const la of e.law_areas) c[la] = (c[la] ?? 0) + 1;
  }
  return c;
}

/**
 * 全 LANDMARK + Extended 結合 (case_id 重複は LANDMARK 側を優先)
 *
 * v2.0 (Phase 46-LU-4 supplement) で dedup を強化:
 *  - case_id をキーに重複排除
 *  - 重複があった場合は LANDMARK_CASES_INDEX 側を採用 (linter 拡張版を尊重)
 *  - 戻り値の安定性 (順序は LANDMARK → Extended)
 */
export async function getAllCases(opts: { includeSupplement?: boolean } = {}): Promise<CaseLawRef[]> {
  const { LANDMARK_CASES_INDEX } = await import('./judiciary_law_link');
  const seen = new Set<string>();
  const out: CaseLawRef[] = [];
  const append = (list: CaseLawRef[]) => {
    for (const c of list) {
      if (seen.has(c.case_id)) continue;
      seen.add(c.case_id);
      out.push(c);
    }
  };
  append(LANDMARK_CASES_INDEX);
  append(EXTENDED_LANDMARK_CASES);
  if (opts.includeSupplement ?? true) {
    try {
      const sup = await import('./case_law_supplement');
      append(sup.SUPPLEMENT_LANDMARK_CASES);
    } catch {
      /* supplement モジュールが未配置でも fallback */
    }
  }
  return out;
}

/**
 * 同期版 (supplement なし — テスト等で await を避けたい場合)
 */
export function getAllCasesSync(landmark: CaseLawRef[]): CaseLawRef[] {
  const seen = new Set<string>();
  const out: CaseLawRef[] = [];
  for (const c of landmark) {
    if (seen.has(c.case_id)) continue;
    seen.add(c.case_id);
    out.push(c);
  }
  for (const c of EXTENDED_LANDMARK_CASES) {
    if (seen.has(c.case_id)) continue;
    seen.add(c.case_id);
    out.push(c);
  }
  return out;
}

/**
 * 拡張判例だけのキーワード検索
 */
export function searchExtendedCases(keyword: string, max = 10): CaseLawRef[] {
  if (!keyword) return [];
  const lower = keyword.toLowerCase();
  return EXTENDED_LANDMARK_CASES
    .filter((c) =>
      c.short_name.toLowerCase().includes(lower)
      || (c.summary ?? '').toLowerCase().includes(lower)
      || c.related_laws.some((l) => l.toLowerCase().includes(lower)),
    )
    .slice(0, max);
}
