/**
 * Phase 46-LU-3 / 補完法令 (行政法・倒産法・特別民法)
 *
 * 六法+主要60の外側にあるが、SI受託で頻出する重要法令カテゴリ。
 *  - 行政法 4 法 (行政手続法/行政事件訴訟法/国家賠償法/地方自治法)
 *  - 倒産法 4 法 (破産法/民事再生法/会社更生法/特定調停法)
 *  - 特別民法 8 法 (借地借家/失火責任/利息制限/出資法/製造物責任/消費者契約 等)
 *  - 国際私法 3 法 (法の適用に関する通則法/外国判決承認/仲裁法)
 */

import type { LawCategory } from '../../law_tracker';

export interface SupplementaryCodeEntry {
  law_id: string;
  short_name: string;
  official_name: string;
  category: LawCategory;
  competent_ministry: string;
  last_effective_date: string;
  key_articles_summary: Record<string, string>;
  /** 関連 lib/japan/*.ts */
  related_modules: string[];
  domain_group: 'administrative' | 'insolvency' | 'special_civil' | 'private_international';
}

export const SUPPLEMENTARY_CODES: SupplementaryCodeEntry[] = [
  // ============== 行政法 4 法 ==============
  {
    law_id: '405AC0000000088',
    short_name: '行政手続法',
    official_name: '行政手続法',
    category: 'admin',
    competent_ministry: '総務省',
    last_effective_date: '2024-04-01',
    key_articles_summary: {
      '1': '目的: 行政運営の公正・透明',
      '5': '審査基準の設定義務 (申請処分)',
      '8': '理由提示義務 (拒否処分)',
      '12': '処分基準の設定 (不利益処分)',
      '13': '弁明・聴聞の機会の付与',
      '14': '理由提示義務 (不利益処分)',
      '32': '行政指導の一般原則',
      '36の2': '行政指導の中止等の求め',
      '36の3': '処分等の求め',
      '37': '届出',
      '38': '命令等を定める場合の意見公募手続 (パブコメ)',
    },
    related_modules: ['lib/japan/public_sector.ts', 'lib/japan/gov_eapps.ts'],
    domain_group: 'administrative',
  },
  {
    law_id: '337AC0000000139',
    short_name: '行訴法',
    official_name: '行政事件訴訟法',
    category: 'admin',
    competent_ministry: '法務省',
    last_effective_date: '2024-04-01',
    key_articles_summary: {
      '3': '抗告訴訟の類型 (処分取消/裁決取消/無効等確認/不作為違法確認/義務付け/差止)',
      '9': '原告適格 (法律上保護された利益)',
      '10の2': '取消の理由制限',
      '14': '出訴期間 (処分知った日から6ヶ月)',
      '25': '執行停止',
      '30': '裁量処分の取消事由 (裁量逸脱・濫用)',
      '37の2': '義務付け訴訟',
      '37の4': '差止訴訟',
    },
    related_modules: ['lib/japan/public_sector.ts'],
    domain_group: 'administrative',
  },
  {
    law_id: '322AC0000000125',
    short_name: '国賠法',
    official_name: '国家賠償法',
    category: 'admin',
    competent_ministry: '法務省',
    last_effective_date: '2024-04-01',
    key_articles_summary: {
      '1': '公権力の行使による損害賠償 (公務員の故意過失)',
      '2': '公の営造物の設置管理瑕疵',
      '3': '費用負担者と設置管理者の異同',
      '4': '民法準用',
      '5': '他の法律の規定',
      '6': '相互保証主義',
    },
    related_modules: ['lib/japan/public_sector.ts'],
    domain_group: 'administrative',
  },
  {
    law_id: '322AC0000000067_local',
    short_name: '地方自治法',
    official_name: '地方自治法',
    category: 'public',
    competent_ministry: '総務省',
    last_effective_date: '2024-10-01',
    key_articles_summary: {
      '2': '地方公共団体の事務 (自治事務/法定受託事務)',
      '14': '条例の制定',
      '74': '直接請求',
      '94': '町村総会',
      '149': '長の担任事務',
      '180の5': '行政委員会',
      '232の2': '寄附又は補助',
      '244': '公の施設の利用',
      '252の19': '指定都市',
    },
    related_modules: ['lib/japan/public_sector.ts'],
    domain_group: 'administrative',
  },

  // ============== 倒産法 4 法 ==============
  {
    law_id: '416AC0000000075',
    short_name: '破産法',
    official_name: '破産法',
    category: 'corporate',
    competent_ministry: '法務省',
    last_effective_date: '2024-04-01',
    key_articles_summary: {
      '15': '破産手続開始原因 (支払不能/債務超過)',
      '30': '破産手続開始決定',
      '47': '破産財団',
      '52': '担保権の取扱い',
      '78': '別除権',
      '97': '破産債権の届出',
      '100': '財団債権',
      '160': '否認権の対象行為',
      '252': '免責許可',
      '253': '免責不許可事由',
    },
    related_modules: ['lib/japan/corporate_law.ts', 'lib/japan/finance.ts'],
    domain_group: 'insolvency',
  },
  {
    law_id: '411AC0000000225',
    short_name: '民再法',
    official_name: '民事再生法',
    category: 'corporate',
    competent_ministry: '法務省',
    last_effective_date: '2024-04-01',
    key_articles_summary: {
      '1': '目的 (経済的窮境からの再建)',
      '21': '再生手続開始決定',
      '38': '別除権',
      '41': '管財人',
      '52': '債権届出',
      '88': '担保権消滅制度',
      '92': '再生計画案の決議',
      '174': '再生計画認可',
      '186': '住宅資金特別条項 (個人再生)',
      '221': '小規模個人再生',
    },
    related_modules: ['lib/japan/corporate_law.ts'],
    domain_group: 'insolvency',
  },
  {
    law_id: '414AC0000000154',
    short_name: '会更法',
    official_name: '会社更生法',
    category: 'corporate',
    competent_ministry: '法務省',
    last_effective_date: '2024-04-01',
    key_articles_summary: {
      '1': '目的 (株式会社の更生)',
      '41': '更生手続開始決定',
      '47': '管財人 (経営権剥奪)',
      '50': '担保権の禁止 (DIPファイナンス基盤)',
      '60': '更生債権',
      '83': '財団債権',
      '167': '更生計画案',
      '199': '更生計画認可',
      '232': '更生計画の遂行',
    },
    related_modules: ['lib/japan/corporate_law.ts'],
    domain_group: 'insolvency',
  },
  {
    law_id: '411AC0000000158',
    short_name: '特定調停法',
    official_name: '特定債務等の調整の促進のための特定調停に関する法律',
    category: 'consumer',
    competent_ministry: '法務省',
    last_effective_date: '2024-04-01',
    key_articles_summary: {
      '1': '目的 (経済的窮境からの調停)',
      '3': '調停手続の特例',
      '17': '調停に代わる決定',
      '24の2': '中小企業向け特定調停',
    },
    related_modules: ['lib/japan/corporate_law.ts'],
    domain_group: 'insolvency',
  },

  // ============== 特別民法 8 法 ==============
  {
    law_id: '403AC0000000090', // 借地借家法 平成三年法律第九十号 (2026-07-31 実測是正: 旧値 316AC…201 は e-Gov に存在しない・課題台帳 Q-04)
    short_name: '借地借家法',
    official_name: '借地借家法',
    category: 'real_estate',
    competent_ministry: '法務省',
    last_effective_date: '2024-04-01',
    key_articles_summary: {
      '3': '借地権の存続期間 (30年)',
      '5': '借地契約の更新',
      '11': '地代等増減請求権',
      '13': '建物買取請求権',
      '22': '定期借地権 (50年)',
      '23': '事業用定期借地権 (10-50年)',
      '26': '建物賃貸借の期間',
      '28': '建物賃貸借の更新拒絶 (正当事由)',
      '32': '借賃増減請求権',
      '38': '定期建物賃貸借',
    },
    related_modules: ['lib/japan/real_estate.ts'],
    domain_group: 'special_civil',
  },
  {
    law_id: 'misc_shikka_M32',
    short_name: '失火責任法',
    official_name: '失火ノ責任ニ関スル法律',
    category: 'consumer',
    competent_ministry: '法務省',
    last_effective_date: '1899-03-08',
    key_articles_summary: {
      '1': '失火による損害賠償責任は重過失ある場合に限る',
    },
    related_modules: [],
    domain_group: 'special_civil',
  },
  {
    law_id: '329AC0000000100',
    short_name: '利息制限法',
    official_name: '利息制限法',
    category: 'finance',
    competent_ministry: '金融庁',
    last_effective_date: '2024-04-01',
    key_articles_summary: {
      '1': '上限利率 (元本10万未満 年20%/10-100万 年18%/100万以上 年15%)',
      '4': '賠償額の予定 (上限利率の1.46倍)',
      '5': '元本に組み入れた損害金',
      '6': '営業的金銭消費貸借の例外',
      '7': '附則改正 (グレーゾーン廃止 H22.6.18)',
    },
    related_modules: ['lib/japan/finance.ts'],
    domain_group: 'special_civil',
  },
  {
    law_id: '329AC0000000195',
    short_name: '出資法',
    official_name: '出資の受入れ、預り金及び金利等の取締りに関する法律',
    category: 'finance',
    competent_ministry: '金融庁',
    last_effective_date: '2024-04-01',
    key_articles_summary: {
      '5': '高金利の罰則 (年109.5%超は刑事罰)',
      '5の2': '貸金業者の上限 (年20%超は刑事罰)',
      '7': '預り金の禁止',
    },
    related_modules: ['lib/japan/finance.ts'],
    domain_group: 'special_civil',
  },
  {
    law_id: '406AC0000000085',
    short_name: 'PL法',
    official_name: '製造物責任法',
    category: 'consumer',
    competent_ministry: '消費者庁',
    last_effective_date: '2024-04-01',
    key_articles_summary: {
      '2': '製造物 (動産) + 欠陥 (通常有すべき安全性欠如)',
      '3': '製造業者等の損害賠償責任 (無過失責任)',
      '4': '免責事由 (開発危険の抗弁 等)',
      '5': '消滅時効 (損害+加害者知った時から3年/引渡から10年)',
    },
    related_modules: ['lib/japan/marketing_compliance.ts'],
    domain_group: 'special_civil',
  },
  {
    law_id: '412AC0000000061',
    short_name: '消契法',
    official_name: '消費者契約法',
    category: 'consumer',
    competent_ministry: '消費者庁',
    last_effective_date: '2023-06-01',
    key_articles_summary: {
      '4': '取消事由 (不実告知/断定的判断/不利益事実不告知/不退去/監禁/勧誘困惑)',
      '8': '損害賠償免責条項の無効',
      '8の2': '解除権放棄条項の無効',
      '9': '違約金等の制限',
      '10': '一般不当条項の無効',
      '12': '差止請求権 (適格消費者団体)',
    },
    related_modules: ['lib/japan/marketing_compliance.ts'],
    domain_group: 'special_civil',
  },
  {
    law_id: '417AC0000000051',
    short_name: '個人情報保護法施行令',
    official_name: '個人情報の保護に関する法律施行令',
    category: 'privacy',
    competent_ministry: '個人情報保護委員会',
    last_effective_date: '2024-04-01',
    key_articles_summary: {
      '2': '個人情報データベース等の定義',
      '5': '匿名加工情報の作成方法',
      '7': '報告対象漏えい (1000人超 等)',
      '10': '本人通知の方法',
    },
    related_modules: ['lib/japan/laws.ts', 'lib/japan/incident.ts'],
    domain_group: 'special_civil',
  },
  {
    law_id: '342AC0000000099',
    short_name: '労働者災害補償保険法',
    official_name: '労働者災害補償保険法',
    category: 'labor',
    competent_ministry: '厚生労働省',
    last_effective_date: '2024-04-01',
    key_articles_summary: {
      '7': '保険給付の種類',
      '12の2の2': '業務上認定基準',
      '12の8': '療養補償給付',
      '14': '休業補償給付 (給付基礎日額の60%)',
      '15': '障害補償給付',
      '16': '遺族補償給付',
      '29': '社会復帰促進事業',
    },
    related_modules: ['lib/japan/hr_payroll.ts'],
    domain_group: 'special_civil',
  },

  // ============== 国際私法 3 法 ==============
  {
    law_id: '418AC0000000078',
    short_name: '通則法',
    official_name: '法の適用に関する通則法',
    category: 'admin',
    competent_ministry: '法務省',
    last_effective_date: '2024-04-01',
    key_articles_summary: {
      '4': '人の能力',
      '7': '法律行為の準拠法 (当事者自治の原則)',
      '8': '当事者自治がない場合の連結点 (最密接関係国)',
      '11': '消費者契約の準拠法',
      '12': '労働契約の準拠法',
      '17': '不法行為の準拠法 (結果発生地)',
      '24': '法定債権の準拠法',
      '36': '相続の準拠法 (被相続人本国法)',
      '42': '公序良俗則 (法定除外)',
    },
    related_modules: [],
    domain_group: 'private_international',
  },
  {
    law_id: '411AC0000000109',
    short_name: '民訴法 外国判決',
    official_name: '民事訴訟法 (118条 外国判決の承認)',
    category: 'admin',
    competent_ministry: '法務省',
    last_effective_date: '2024-04-01',
    key_articles_summary: {
      '118-1': '間接管轄の存在',
      '118-2': '訴訟手続の保障',
      '118-3': '公序則',
      '118-4': '相互保証',
    },
    related_modules: [],
    domain_group: 'private_international',
  },
  {
    law_id: '415AC0000000138',
    short_name: '仲裁法',
    official_name: '仲裁法',
    category: 'corporate',
    competent_ministry: '法務省',
    last_effective_date: '2024-04-01',
    key_articles_summary: {
      '13': '仲裁合意の方式 (書面性)',
      '14': '仲裁付託の合意',
      '36': '仲裁地',
      '37': '審理手続 (当事者自治+UNCITRAL モデル法準拠)',
      '44': '取消事由',
      '45': '承認',
      '46': '執行決定',
    },
    related_modules: [],
    domain_group: 'private_international',
  },
];

/**
 * 主題で補完法令を絞り込む
 */
export function findSupplementaryCodesByDomain(
  domain: SupplementaryCodeEntry['domain_group'],
): SupplementaryCodeEntry[] {
  return SUPPLEMENTARY_CODES.filter((c) => c.domain_group === domain);
}

/**
 * 通称→補完法令の検索
 */
export function findSupplementaryCodeByShortName(shortName: string): SupplementaryCodeEntry | undefined {
  return SUPPLEMENTARY_CODES.find((c) => c.short_name === shortName || c.official_name === shortName);
}

/**
 * 統計サマリ
 */
export function countSupplementaryCodes(): { total: number; by_domain: Record<string, number>; total_articles: number } {
  const byDomain: Record<string, number> = {};
  let totalArts = 0;
  for (const c of SUPPLEMENTARY_CODES) {
    byDomain[c.domain_group] = (byDomain[c.domain_group] ?? 0) + 1;
    totalArts += Object.keys(c.key_articles_summary).length;
  }
  return { total: SUPPLEMENTARY_CODES.length, by_domain: byDomain, total_articles: totalArts };
}
