/**
 * Phase 46-LU-5 / Code Compliance Scanner
 *
 * プロジェクトの TypeScript/JavaScript コードを静的解析し、
 * 日本法 (個情法/PL法/特商法/景表法/薬機法/マイナ法/著作権法) 違反の可能性を検出する。
 *
 * LLM 不使用 (deterministic / 高速 / オフライン動作)。
 * パターンマッチング + コンテキスト解析。
 */

export type ComplianceRuleId =
  | 'PII-001' // 個人情報の同意なき第三者提供
  | 'PII-002' // 個人情報の越境移転 (個情法28条)
  | 'PII-003' // 要配慮個人情報の取得
  | 'PII-004' // マイナンバー不適切露出
  | 'PII-005' // クッキー同意なし (個情法+e-Privacy)
  | 'PII-006' // 第26条 漏えい報告義務漏れ
  | 'TOKUSHO-001' // 特商法 表示義務漏れ
  | 'TOKUSHO-002' // 定期購入規制違反 (誇大宣伝)
  | 'KEIHYO-001' // 景表法 優良誤認
  | 'KEIHYO-002' // ステマ規制違反 (R5.10〜)
  | 'PL-001' // PL法 警告表示不足
  | 'YAKKI-001' // 薬機法 効能効果の誇大表現
  | 'COPYRIGHT-001' // 著作権 引用要件違反
  | 'DENCHO-001' // 電帳法 タイムスタンプ漏れ
  | 'INVOICE-001' // インボイス制度 登録番号未表示
  | 'LABOR-001' // 労基法 36協定/残業表示
  | 'CONSUMER-001'; // 消費者契約法10条 不当条項

export interface ComplianceFinding {
  rule_id: ComplianceRuleId;
  severity: 'critical' | 'high' | 'medium' | 'low' | 'info';
  file_hint?: string;
  line_hint?: number;
  matched_snippet: string;
  related_laws: string[];
  description: string;
  remediation: string;
}

export interface ComplianceRule {
  id: ComplianceRuleId;
  pattern: RegExp;
  severity: ComplianceFinding['severity'];
  related_laws: string[];
  description: string;
  remediation: string;
  /** True positive 確信度向上のため、anti_pattern にマッチしたら除外 */
  anti_pattern?: RegExp;
}

export const COMPLIANCE_RULES: ComplianceRule[] = [
  // ============== 個情法 ==============
  {
    id: 'PII-001',
    pattern: /\.share\(.*personal|sendToThirdParty|export.*pii.*=.*true|thirdParty.*transfer/i,
    severity: 'critical',
    related_laws: ['個情法第27条 (第三者提供)', '個情法第28条 (越境移転)'],
    description: '個人データの第三者提供に該当する可能性。同意取得・オプトアウト・記録保管を確認',
    remediation: 'recordThirdPartyTransfer() を呼び出し、本人同意フラグ + 提供記録3年保管を実装',
    anti_pattern: /comment|test|mock/i,
  },
  {
    id: 'PII-004',
    pattern: /(console\.log|alert|res\.send|return|throw)\s*\(\s*[^)]*?(myNumber|個人番号|マイナンバー|my_number)/i,
    severity: 'critical',
    related_laws: ['マイナンバー法第19条 (利用・提供制限)', '個情法第20条 (適正な取得)'],
    description: 'マイナンバーがログ/レスポンス/エラーに露出する可能性',
    remediation: 'マイナンバーは末尾4桁のみマスク表示し、ログには絶対に出力しない',
  },
  {
    id: 'PII-005',
    pattern: /document\.cookie\s*=|setCookie\(|res\.cookie\(/i,
    severity: 'medium',
    related_laws: ['個情法R4改正 第20条', '電気通信事業法 外部送信規律 R5.6'],
    description: 'クッキー設置あり。本人同意 (オプトイン) 取得を確認',
    remediation: 'CookieConsent コンポーネント実装 + 拒否時のトラッキング停止',
    anti_pattern: /sessionId|csrfToken|authCookie/i,
  },
  {
    id: 'PII-006',
    pattern: /catch\s*\([^)]*\)\s*\{[^}]*(?:console\.error|logger\.error)\s*\([^)]*personal_data/i,
    severity: 'high',
    related_laws: ['個情法第26条 (漏えい等の報告義務 R4改正)'],
    description: '個人データ関連のエラー処理。漏えい検知時の72時間以内 個情委報告フローを確認',
    remediation: 'reportToPpc() の自動呼び出しと内部通報窓口エスカレーションを追加',
  },

  // ============== 特商法 ==============
  {
    id: 'TOKUSHO-001',
    pattern: /<form[^>]*action[^>]*(checkout|purchase|subscribe)|stripe\.com.*createSession/i,
    severity: 'high',
    related_laws: ['特定商取引法第11条 (通信販売の広告)', '特商法施行規則第8条'],
    description: '通販フォームあり。特商法11条 13項目の表示確認必要',
    remediation: '事業者名/住所/電話/代金/送料/返品特約/不良品対応の表示ページを連携',
  },
  {
    id: 'TOKUSHO-002',
    pattern: /subscription|recurring.*billing|every.*month/i,
    severity: 'high',
    related_laws: ['特商法第11条第3号 (定期購入規制)', '景表法第5条第1号 (優良誤認)'],
    description: '定期購入の可能性。R4.6改正の最終確認画面義務を確認',
    remediation: '注文確定前に「定期購入条件・解約方法・期間」を明示する確認画面を実装',
  },

  // ============== 景表法 ==============
  {
    id: 'KEIHYO-001',
    pattern: /(業界最安|No\.?\s*1|日本一|世界初|医師推薦|権威ある.*認定|圧倒的)/i,
    severity: 'high',
    related_laws: ['景表法第5条第1号 (優良誤認)', '景表法第5条第2号 (有利誤認)'],
    description: '景表法上「最大級表現」または「No.1表示」は厳格な根拠資料要',
    remediation: '客観的調査結果 (調査期間・対象・方法) を併記、または表現を削除',
  },
  {
    id: 'KEIHYO-002',
    pattern: /<(span|div)[^>]*hidden[^>]*>\s*(PR|広告|プロモーション|AD)\s*<\/(span|div)>|sponsored.*hidden/i,
    severity: 'critical',
    related_laws: ['景表法第5条第3号 (ステマ規制 R5.10)', '内閣府告示第19号'],
    description: 'ステマ規制違反の可能性。広告であることを明瞭表示',
    remediation: '広告/PR/プロモーション 等の表示を視認可能な位置・サイズで明示',
  },

  // ============== PL法 ==============
  {
    id: 'PL-001',
    pattern: /<(button|input)[^>]*type=["\']?(submit|button)[^>]*>(?:.*高温|.*電源|.*医療|.*飲食)/i,
    severity: 'medium',
    related_laws: ['製造物責任法第3条', '消費者基本法'],
    description: '製品/サービスに警告表示が必要な可能性',
    remediation: '危険性・使用上の注意・年齢制限の表示を製品ページに追加',
  },

  // ============== 薬機法 ==============
  {
    id: 'YAKKI-001',
    pattern: /(治る|治療|医学的効果|症状改善|完治|病気が|医薬品的効能)/,
    severity: 'critical',
    related_laws: ['薬機法第66条 (誇大広告)', '薬機法第68条 (未承認医薬品広告)'],
    description: '薬機法上の医薬品的効能効果表示の可能性 (健康食品/化粧品/雑貨)',
    remediation: '「治る」「効く」を「サポート」「期待」等に修正、または承認を取得',
  },

  // ============== 電帳法 ==============
  {
    id: 'DENCHO-001',
    pattern: /\.(save|create|upload)\s*\(.*(?:invoice|receipt|請求書|領収書)/i,
    severity: 'medium',
    related_laws: ['電子帳簿保存法第7条 (電子取引保存)', '電帳法施行規則第4条'],
    description: '電子帳簿保存対象データ。R6.1施行のタイムスタンプ・検索機能・改ざん防止を確認',
    remediation: 'attachTimestamp() + computeFileHash() + 検索機能 (取引年月日/取引先/金額) 実装',
  },

  // ============== インボイス ==============
  {
    id: 'INVOICE-001',
    pattern: /(invoice|請求書).*template|generateInvoice/i,
    severity: 'medium',
    related_laws: ['消費税法第57条の4 (適格請求書)', 'インボイス制度 R5.10'],
    description: 'インボイス生成。登録番号・税率別・税額・区分記載の必須項目を確認',
    remediation: 'validateRegistrationNumber() + 税率別集計 + 適格請求書フォーマット適用',
  },

  // ============== 労基法 ==============
  {
    id: 'LABOR-001',
    pattern: /overtime\s*=\s*\d+|残業.*?(\d+)/,
    severity: 'medium',
    related_laws: ['労基法第36条 (時間外労働)', '労基法第36条第6項 (上限規制 R元.4)'],
    description: '残業時間処理。36協定の上限 (月45h/年360h、特別条項 月100h未満/年720h以下) を確認',
    remediation: 'checkOvertimeLimits() で月次/年次上限超過警告を実装',
  },

  // ============== 消費者契約法 ==============
  {
    id: 'CONSUMER-001',
    pattern: /(全責任を負わない|免責|loss.*?responsibility\s*=\s*false|consumer.*opt[-_]?out)/i,
    severity: 'high',
    related_laws: ['消費者契約法第10条 (不当条項)', '消費者契約法第8条 (損害賠償免責)'],
    description: '消費者の利益を一方的に害する条項の可能性 (8条/8条の2/9条/10条)',
    remediation: '条項を「重過失/故意に限定」または「上限額設定」に修正',
  },

  // ============== 著作権 ==============
  {
    id: 'COPYRIGHT-001',
    pattern: /(引用|quote).*?{|copy.*?paste|extractText.*?(news|article|wikipedia)/i,
    severity: 'medium',
    related_laws: ['著作権法第32条 (引用)', '著作権法第30条の4 (情報解析)'],
    description: '他者著作物利用の可能性。引用4要件 (公表/主従/明瞭区別/必要性+出典) 確認',
    remediation: '出典明記 + 引用範囲明確化 + 主従関係維持 (引用部 < 自己の文章)',
  },
];

export interface ScanInput {
  code: string;
  file_hint?: string;
}

export function scanCodeForCompliance(input: ScanInput): ComplianceFinding[] {
  const out: ComplianceFinding[] = [];
  const lines = input.code.split('\n');
  for (const rule of COMPLIANCE_RULES) {
    const matches = input.code.matchAll(new RegExp(rule.pattern.source, rule.pattern.flags.replace('g', '') + 'g'));
    for (const m of matches) {
      if (rule.anti_pattern && rule.anti_pattern.test(m[0])) continue;
      // 行番号推定
      const offset = m.index ?? 0;
      let line = 1;
      let cum = 0;
      for (const ln of lines) {
        cum += ln.length + 1;
        if (offset < cum) break;
        line++;
      }
      out.push({
        rule_id: rule.id,
        severity: rule.severity,
        file_hint: input.file_hint,
        line_hint: line,
        matched_snippet: m[0].slice(0, 100),
        related_laws: rule.related_laws,
        description: rule.description,
        remediation: rule.remediation,
      });
    }
  }
  return out;
}

export interface ScanReport {
  generated_at: string;
  total_findings: number;
  by_severity: Record<ComplianceFinding['severity'], number>;
  by_rule: Partial<Record<ComplianceRuleId, number>>;
  findings: ComplianceFinding[];
  compliance_score: number;
}

export function buildScanReport(findings: ComplianceFinding[]): ScanReport {
  const bySev: Record<ComplianceFinding['severity'], number> = {
    critical: 0, high: 0, medium: 0, low: 0, info: 0,
  };
  const byRule: Partial<Record<ComplianceRuleId, number>> = {};
  for (const f of findings) {
    bySev[f.severity]++;
    byRule[f.rule_id] = (byRule[f.rule_id] ?? 0) + 1;
  }
  let score = 100;
  score -= bySev.critical * 15;
  score -= bySev.high * 7;
  score -= bySev.medium * 3;
  score -= bySev.low * 1;
  score = Math.max(0, Math.min(100, score));
  return {
    generated_at: new Date().toISOString(),
    total_findings: findings.length,
    by_severity: bySev,
    by_rule: byRule,
    findings,
    compliance_score: score,
  };
}

export function renderScanReportMarkdown(report: ScanReport): string {
  const lines: string[] = [];
  lines.push('# コンプライアンススキャンレポート');
  lines.push('');
  lines.push(`生成日時: ${report.generated_at}`);
  lines.push(`Compliance Score: **${report.compliance_score}/100**`);
  lines.push('');
  lines.push('## 検出概要');
  for (const [sev, n] of Object.entries(report.by_severity)) {
    if (n > 0) lines.push(`- ${sev}: ${n}件`);
  }
  lines.push('');
  lines.push('## 詳細 (Top 20)');
  for (const f of report.findings.slice(0, 20)) {
    lines.push(`### [${f.severity}] ${f.rule_id}`);
    lines.push(`- 該当: \`${f.matched_snippet}\``);
    lines.push(`- 関連法令: ${f.related_laws.join(' / ')}`);
    lines.push(`- 説明: ${f.description}`);
    lines.push(`- 修正案: ${f.remediation}`);
    lines.push('');
  }
  return lines.join('\n');
}
