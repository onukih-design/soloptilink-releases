/**
 * Phase 46-LU-8 / 5年スパン規制予測エンジン
 *
 * LU-7 の amendment_predictor.ts は短期 (現観測信号→1年以内) の予測。
 * LU-8 では 5年スパン (60ヶ月) の中長期予測に拡張。
 *
 *  - 過去20年改正サイクル (historical_amendments.ts) を活用
 *  - 改正ドライバー別の周期性分析
 *  - 国際動向 (GDPR/EU AI Act 等) 連動予測
 *  - 立法計画情報 (与党重点法案/閣議決定済) との突合
 */

import { HISTORICAL_AMENDMENTS_20Y, analyzeCycle, listAllAmendedLaws } from '../historical/historical_amendments';

export interface LongTermPrediction {
  law_short: string;
  prediction_year: number;
  prediction_quarter: 1 | 2 | 3 | 4;
  amendment_scale: 'major' | 'minor' | 'consolidation';
  confidence_pct: number;
  /** 予測根拠 */
  reasoning: string[];
  /** 想定される改正方向 */
  expected_direction: 'strengthening' | 'easing' | 'modernizing' | 'mixed';
  /** 推奨事業準備期間 (月) */
  prep_lead_months: number;
}

/**
 * 5 年スパン予測
 */
export function predictNext5Years(): LongTermPrediction[] {
  const laws = listAllAmendedLaws();
  const currentYear = new Date().getFullYear();
  const results: LongTermPrediction[] = [];

  for (const law of laws) {
    const cycle = analyzeCycle(law);
    if (!cycle || !cycle.next_predicted_year) continue;
    if (cycle.next_predicted_year < currentYear) continue;
    if (cycle.next_predicted_year > currentYear + 5) continue;

    const reasoning: string[] = [];
    reasoning.push(`過去 ${cycle.amendment_count} 回の改正実績`);
    reasoning.push(`平均改正間隔 ${cycle.avg_interval_years} 年`);
    reasoning.push(`直近改正以来 ${currentYear - new Date(HISTORICAL_AMENDMENTS_20Y.find((h) => h.law_short === law)!.promulgation_date).getFullYear()} 年経過`);

    // 重要度に応じた scale 予測
    const lastAmend = HISTORICAL_AMENDMENTS_20Y.filter((h) => h.law_short === law).sort((a, b) => b.promulgation_date.localeCompare(a.promulgation_date))[0];
    let scale: LongTermPrediction['amendment_scale'] = 'minor';
    if (cycle.major_count > cycle.amendment_count * 0.6) {
      scale = 'major';
      reasoning.push('過去改正の60%以上がmajor → 次回もmajor予測');
    }

    // 改正ドライバー別の信頼度
    let confidence = 40 + Math.min(40, cycle.amendment_count * 5);
    if (lastAmend.driver === 'periodic_review') confidence += 15;
    if (lastAmend.driver === 'international_alignment') confidence += 10;
    if (lastAmend.driver === 'tech_advancement') confidence += 5;
    confidence = Math.min(95, confidence);

    // 改正方向の推定
    let direction: LongTermPrediction['expected_direction'] = 'mixed';
    if (lastAmend.driver === 'crisis_response') direction = 'strengthening';
    else if (lastAmend.driver === 'tech_advancement') direction = 'modernizing';
    else if (lastAmend.driver === 'social_change') direction = 'strengthening';
    else if (lastAmend.driver === 'international_alignment') direction = 'modernizing';

    // 準備期間 (改正規模に応じて)
    const prepMonths = scale === 'major' ? 18 : scale === 'minor' ? 6 : 3;

    results.push({
      law_short: law,
      prediction_year: cycle.next_predicted_year,
      prediction_quarter: 2, // デフォルト Q2 (予算年度準拠)
      amendment_scale: scale,
      confidence_pct: confidence,
      reasoning,
      expected_direction: direction,
      prep_lead_months: prepMonths,
    });
  }

  return results.sort((a, b) => a.prediction_year - b.prediction_year || b.confidence_pct - a.confidence_pct);
}

/**
 * 国際動向連動予測 (GDPR/EU AI Act 等の波及効果)
 */
export interface InternationalDrivenPrediction {
  trigger_law: string; // 'GDPR' / 'EU AI Act' / 'SOX' 等
  expected_jp_response_law: string;
  estimated_jp_amendment_year: number;
  rationale: string;
}

export const INTERNATIONAL_DRIVERS: InternationalDrivenPrediction[] = [
  {
    trigger_law: 'EU AI Act (R6施行)',
    expected_jp_response_law: 'AI事業者ガイドライン → AI規制法 (新法)',
    estimated_jp_amendment_year: 2027,
    rationale: '広島AIプロセス + AI事業者ガイドラインの後継として AI 規制法制定の検討中',
  },
  {
    trigger_law: 'GDPR 5年見直し (2024)',
    expected_jp_response_law: '個情法 3年見直し',
    estimated_jp_amendment_year: 2026,
    rationale: 'PPC 3年見直し検討会 報告書 (2026-04) → 個情法改正法案 提出予想',
  },
  {
    trigger_law: 'NIS2指令 (EU)',
    expected_jp_response_law: 'サイバーセキュリティ基本法 改正',
    estimated_jp_amendment_year: 2026,
    rationale: '能動的サイバー防御法 R7.4 施行後の追加整備',
  },
  {
    trigger_law: 'OECD BEPS 2.0 (デジタル課税)',
    expected_jp_response_law: '法人税法 改正',
    estimated_jp_amendment_year: 2027,
    rationale: 'Pillar1/Pillar2 国内実装 → R9 税制改正大綱で確定見込み',
  },
  {
    trigger_law: 'EU CSRD (持続可能性報告)',
    expected_jp_response_law: 'SSBJ基準 + 金商法改正',
    estimated_jp_amendment_year: 2026,
    rationale: 'SSBJ S1/S2 基準 適用拡大 + 有報での開示義務化',
  },
  {
    trigger_law: 'UK Online Safety Act',
    expected_jp_response_law: 'プロバイダ責任制限法 改正',
    estimated_jp_amendment_year: 2026,
    rationale: '誹謗中傷 開示請求迅速化の議論継続',
  },
  {
    trigger_law: 'EU DMA (Digital Markets Act)',
    expected_jp_response_law: '独占禁止法 + プラットフォーム取引透明化法',
    estimated_jp_amendment_year: 2028,
    rationale: 'デジタルプラットフォーマー規制の継続強化',
  },
];

/**
 * 統合予測サマリ
 */
export interface IntegratedForecast {
  generated_at: string;
  forecast_window_years: 5;
  top_predictions: LongTermPrediction[];
  international_drivers: InternationalDrivenPrediction[];
  /** 高信頼度予測 (>=70%) のみ */
  high_confidence: LongTermPrediction[];
  /** 業種別 推奨準備リスト */
  industry_preparation: Array<{ industry: string; key_laws: string[]; deadline: string }>;
}

export function buildIntegratedForecast(): IntegratedForecast {
  const all = predictNext5Years();
  const high = all.filter((p) => p.confidence_pct >= 70);

  const prepIndustry = [
    { industry: 'IT/SaaS', key_laws: ['個情法', 'サイバーセキュリティ基本法', '電気通信事業法'], deadline: '2026-12' },
    { industry: '金融', key_laws: ['金商法', '銀行法', '資金決済法'], deadline: '2027-03' },
    { industry: '建設/不動産', key_laws: ['建設業法', '宅建業法'], deadline: '2027-06' },
    { industry: '医療', key_laws: ['薬機法', '医療法', '個情法'], deadline: '2026-09' },
    { industry: '小売/EC', key_laws: ['特商法', '景表法', '個情法'], deadline: '2026-12' },
    { industry: '製造', key_laws: ['PL法', '製造物責任', '化審法'], deadline: '2027-12' },
  ];

  return {
    generated_at: new Date().toISOString(),
    forecast_window_years: 5,
    top_predictions: all.slice(0, 20),
    international_drivers: INTERNATIONAL_DRIVERS,
    high_confidence: high,
    industry_preparation: prepIndustry,
  };
}

export function countPredictions(): { total: number; high_confidence: number; international: number } {
  const all = predictNext5Years();
  return {
    total: all.length,
    high_confidence: all.filter((p) => p.confidence_pct >= 70).length,
    international: INTERNATIONAL_DRIVERS.length,
  };
}
