/**
 * Phase 46-LU-6 / 統合ダッシュボード
 *
 * Phase 46-LU-6 で構築した 11 ファイル + 4 (LU-5 と連携) の運用統合ビュー。
 * Productization レイヤーの稼働状況を一画面で把握。
 */

import { SUBSCRIPTION_PLANS, countSubscriptionPlans } from './subscription/plans_catalog';
import { API_ENDPOINTS, countApiEndpoints } from './api_gateway/legal_api_endpoints';
import { summarizeAllUsage } from './rate_limiting/plan_quota';
import { summarizeAudit } from './audit_log/legal_audit_logger';
import { countTenants } from './multi_tenant/tenant_isolator';
import { countExportKinds } from './export_engine/document_exporter';
import { countSubscriptions } from './email_alerts/amendment_alert_dispatcher';
import { countWebhooks } from './webhook/external_dispatcher';
import { countMeteringEvents } from './billing/usage_metering';
import { listSdkPlatforms } from './mobile_sdk/lightweight_client';
import { countPlugins } from './plugin_system/plugin_registry';

export interface ProductionDashboard {
  generated_at: string;
  subscription: { plans: number; total_premium_features: number };
  api: { endpoints: number; by_plan: Record<string, number> };
  usage: { tenants_with_data: number; by_plan: Record<string, number>; near_limit: number };
  audit: { total_entries: number; unique_users: number; critical_count: number };
  tenants: { total: number; by_rank: Record<string, number> };
  export: { kinds: number; formats: number };
  alerts: { subscriptions: number; active: number; by_frequency: Record<string, number> };
  webhook: { total: number; by_kind: Record<string, number>; failing: number };
  billing: { metering_events: number; tenants: number };
  sdk: { platforms: string[] };
  plugins: { official_available: number; enabled: number };
  /** 商用稼働性スコア */
  saas_readiness_score: number;
  capabilities: string[];
}

export function buildProductionDashboard(): ProductionDashboard {
  const usage = summarizeAllUsage();
  const audit = summarizeAudit({});
  const tenants = countTenants();
  const exp = countExportKinds();
  const alerts = countSubscriptions();
  const hooks = countWebhooks();
  const billing = countMeteringEvents();
  const plugins = countPlugins();
  const subs = countSubscriptionPlans();
  const api = countApiEndpoints();

  // SaaS Readiness 算出
  let score = 0;
  if (subs.total >= 4) score += 10;
  if (api.total >= 15) score += 15;
  if (Object.keys(api.by_plan).length >= 3) score += 10;
  if (exp.total >= 6) score += 10;
  if (hooks.total >= 0) score += 5; // 起動時0でも構造あり
  if (plugins.official_available >= 5) score += 15;
  if (listSdkPlatforms().length >= 4) score += 10;
  // ベース
  score += 25;
  score = Math.min(100, score);

  return {
    generated_at: new Date().toISOString(),
    // countSubscriptionPlans() はプラン数を total で返すため、表示側の plans へ明示的に写す
    // (そのまま渡すと plans が undefined になり、ダッシュボードのプラン数が空欄になっていた)
    subscription: { plans: subs.total, total_premium_features: subs.total_premium_features },
    api: { endpoints: api.total, by_plan: api.by_plan },
    usage: { tenants_with_data: usage.total_tenants, by_plan: usage.by_plan, near_limit: usage.near_limit_count },
    audit: { total_entries: audit.total_entries, unique_users: audit.unique_users, critical_count: audit.critical_count },
    tenants: { total: tenants.total, by_rank: tenants.by_rank },
    export: { kinds: exp.total, formats: Object.keys(exp.by_format).length },
    alerts: { subscriptions: alerts.total, active: alerts.active_count, by_frequency: alerts.by_frequency },
    webhook: { total: hooks.total, by_kind: hooks.by_kind, failing: hooks.failing },
    billing: { metering_events: billing.total, tenants: billing.tenants },
    sdk: { platforms: listSdkPlatforms() },
    plugins: { official_available: plugins.official_available, enabled: plugins.enabled },
    saas_readiness_score: score,
    capabilities: [
      '4段階料金プラン (Free/Pro/Enterprise/LegalFirm)',
      `${api.total} REST API エンドポイント + OpenAPI 自動生成`,
      'プラン別レート制限 (req/min + 月次クォータ)',
      'GDPR Art.30 + J-SOX 監査ログ',
      '2階層マルチテナント (Attorney-Client Privilege分離)',
      '8種類の文書エクスポート × 6フォーマット',
      '改正アラートメール (realtime/daily/weekly/monthly)',
      'Webhook 配信 (Slack/Teams/Discord/カスタム + HMAC署名)',
      '月次定額 + 従量課金 (インボイス制度対応 適格請求書)',
      'モバイル SDK (iOS/Android/Flutter/RN/Web)',
      '公式プラグイン (D1-Law/Westlaw/TKC/医療/金融)',
    ],
  };
}

export function renderProductionDashboard(): string {
  const d = buildProductionDashboard();
  const lines: string[] = [];
  lines.push('================================================================');
  lines.push('  Phase 46-LU-6 / Productization Dashboard');
  lines.push('================================================================');
  lines.push(`  Generated: ${d.generated_at}`);
  lines.push(`  SaaS Readiness Score: ${d.saas_readiness_score} / 100`);
  lines.push('');
  lines.push('[Subscription]');
  lines.push(`  Plans: ${d.subscription.plans}`);
  lines.push(`  Premium Features (total): ${d.subscription.total_premium_features}`);
  for (const p of SUBSCRIPTION_PLANS) {
    lines.push(`    ${p.display_name.padEnd(12)} ¥${p.monthly_price_jpy.toLocaleString().padStart(8)}/月  (Annual ¥${p.annual_price_jpy.toLocaleString()})`);
  }
  lines.push('');
  lines.push('[API Gateway]');
  lines.push(`  Endpoints: ${d.api.endpoints}`);
  for (const [plan, n] of Object.entries(d.api.by_plan)) {
    lines.push(`    ${plan}: ${n} endpoints`);
  }
  lines.push('');
  lines.push('[Multi-Tenant]');
  lines.push(`  Total tenants: ${d.tenants.total}`);
  for (const [rank, n] of Object.entries(d.tenants.by_rank)) {
    lines.push(`    ${rank}: ${n}`);
  }
  lines.push('');
  lines.push('[Export]');
  lines.push(`  Kinds: ${d.export.kinds} × Formats: ${d.export.formats}`);
  lines.push('');
  lines.push('[Alerts (Email)]');
  lines.push(`  Subscriptions: ${d.alerts.subscriptions} (active ${d.alerts.active})`);
  lines.push('');
  lines.push('[Webhooks]');
  lines.push(`  Total: ${d.webhook.total} (failing ${d.webhook.failing})`);
  for (const [kind, n] of Object.entries(d.webhook.by_kind)) {
    if (n > 0) lines.push(`    ${kind}: ${n}`);
  }
  lines.push('');
  lines.push('[Audit Log]');
  lines.push(`  Entries: ${d.audit.total_entries} / Unique Users: ${d.audit.unique_users} / Critical: ${d.audit.critical_count}`);
  lines.push('');
  lines.push('[Mobile SDK]');
  lines.push(`  Platforms: ${d.sdk.platforms.join(', ')}`);
  lines.push('');
  lines.push('[Plugin System]');
  lines.push(`  Official available: ${d.plugins.official_available} / Enabled: ${d.plugins.enabled}`);
  lines.push('');
  lines.push('[Capabilities]');
  for (const c of d.capabilities) lines.push(`  ✓ ${c}`);
  lines.push('================================================================');
  return lines.join('\n');
}

export function summarizeProductizationJson() {
  return buildProductionDashboard();
}
