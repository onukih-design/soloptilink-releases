/**
 * Phase 46-LU-6 / Multi-Tenant Isolation
 *
 * 法律事務所 → 顧客テナント の 2階層マルチテナント分離。
 *
 *  - 親テナント (法律事務所) が子テナント (顧客) を作成
 *  - 子テナント間のデータ完全分離
 *  - 弁護士の Attorney-Client Privilege (弁護士秘匿特権) 観点で必須
 *  - 親が子の利用統計を集計可能 (個別の検索内容は閲覧不可)
 */

import type { PlanTier } from '../subscription/plans_catalog';
import { getPlanByTier } from '../subscription/plans_catalog';
import { recordAudit } from '../audit_log/legal_audit_logger';

export type TenantRank = 'parent' | 'child' | 'standalone';

export interface Tenant {
  tenant_id: string;
  display_name: string;
  rank: TenantRank;
  parent_tenant_id?: string;
  plan_tier: PlanTier;
  /** 親→子の関係でのデータ閲覧権限の継承 (デフォルト false: 親は子の生データを見られない) */
  parent_can_view_data: boolean;
  /** 子テナント別の機能制限 (例: 法律事務所が顧客に契約書編集を許可) */
  capabilities: TenantCapability[];
  /** 作成日時 */
  created_at: string;
  /** 状態 */
  status: 'active' | 'suspended' | 'archived';
  /** 専用 API キー (テナント単位) */
  api_keys: string[];
}

export type TenantCapability =
  | 'rag_search'
  | 'compliance_scan'
  | 'contract_generate'
  | 'contract_edit'
  | 'risk_assess'
  | 'advisor_ask'
  | 'export_pdf'
  | 'webhook_register'
  | 'manage_users'
  | 'view_audit';

const TENANT_STORE = new Map<string, Tenant>();

export function createTenant(input: {
  tenant_id: string;
  display_name: string;
  plan_tier: PlanTier;
  parent_tenant_id?: string;
  parent_can_view_data?: boolean;
  capabilities?: TenantCapability[];
}): { ok: true; tenant: Tenant } | { ok: false; error: string } {
  if (TENANT_STORE.has(input.tenant_id)) {
    return { ok: false, error: `tenant_id "${input.tenant_id}" already exists` };
  }
  const parent = input.parent_tenant_id ? TENANT_STORE.get(input.parent_tenant_id) : undefined;
  if (input.parent_tenant_id && !parent) {
    return { ok: false, error: `parent tenant "${input.parent_tenant_id}" not found` };
  }
  // 親プランで child_tenants 上限チェック
  if (parent) {
    const parentPlan = getPlanByTier(parent.plan_tier);
    if (!parentPlan) return { ok: false, error: `parent plan invalid` };
    const childCount = [...TENANT_STORE.values()].filter((t) => t.parent_tenant_id === parent.tenant_id).length;
    if (childCount >= parentPlan.features.child_tenants) {
      return { ok: false, error: `parent tenant exceeded child quota (${childCount}/${parentPlan.features.child_tenants})` };
    }
  }

  const rank: TenantRank = parent ? 'child' : input.plan_tier === 'legal_firm' || input.plan_tier === 'enterprise' ? 'parent' : 'standalone';
  const tenant: Tenant = {
    tenant_id: input.tenant_id,
    display_name: input.display_name,
    rank,
    parent_tenant_id: input.parent_tenant_id,
    plan_tier: input.plan_tier,
    parent_can_view_data: input.parent_can_view_data ?? false,
    capabilities: input.capabilities ?? ['rag_search', 'compliance_scan', 'contract_generate', 'risk_assess', 'advisor_ask'],
    created_at: new Date().toISOString(),
    status: 'active',
    api_keys: [],
  };
  TENANT_STORE.set(input.tenant_id, tenant);

  recordAudit({
    tenant_id: parent?.tenant_id ?? input.tenant_id,
    user_id: 'system',
    action: 'tenant_create_child',
    target: input.tenant_id,
    plan_tier: input.plan_tier,
    severity: 'info',
    result_summary: `tenant created: ${input.tenant_id} (${rank})`,
  });

  return { ok: true, tenant };
}

export function getTenant(tenant_id: string): Tenant | undefined {
  return TENANT_STORE.get(tenant_id);
}

export function listChildTenants(parent_tenant_id: string): Tenant[] {
  return [...TENANT_STORE.values()].filter((t) => t.parent_tenant_id === parent_tenant_id);
}

/**
 * テナント間のデータアクセス可否を判定。
 * 親→子: parent_can_view_data フラグ依存
 * 子→親: 不可
 * 子→兄弟子: 不可
 * 同一テナント: 可
 */
export function canAccessData(input: {
  accessor_tenant_id: string;
  target_tenant_id: string;
}): { allowed: boolean; reason: string } {
  if (input.accessor_tenant_id === input.target_tenant_id) {
    return { allowed: true, reason: 'same tenant' };
  }
  const accessor = TENANT_STORE.get(input.accessor_tenant_id);
  const target = TENANT_STORE.get(input.target_tenant_id);
  if (!accessor || !target) {
    return { allowed: false, reason: 'tenant not found' };
  }
  // 親→子
  if (target.parent_tenant_id === accessor.tenant_id) {
    if (target.parent_can_view_data) {
      return { allowed: true, reason: 'parent has data view permission (granted by child)' };
    }
    return { allowed: false, reason: 'parent cannot view child raw data (Attorney-Client Privilege)' };
  }
  return { allowed: false, reason: 'no relationship' };
}

/**
 * 親テナント向けの子テナント集計 (利用統計のみ、検索内容は含めず)
 */
export interface ChildAggregate {
  child_tenant_id: string;
  display_name: string;
  plan_tier: PlanTier;
  total_actions_this_month: number;
  status: Tenant['status'];
}

export function aggregateChildren(parent_tenant_id: string): ChildAggregate[] {
  const children = listChildTenants(parent_tenant_id);
  return children.map((c) => ({
    child_tenant_id: c.tenant_id,
    display_name: c.display_name,
    plan_tier: c.plan_tier,
    total_actions_this_month: 0, // audit_log と連動して実数化 (このスタブは構造のみ)
    status: c.status,
  }));
}

export function suspendTenant(tenant_id: string, reason: string): boolean {
  const t = TENANT_STORE.get(tenant_id);
  if (!t) return false;
  t.status = 'suspended';
  recordAudit({
    tenant_id,
    user_id: 'system',
    action: 'admin_login',
    severity: 'warn',
    result_summary: `suspended: ${reason}`,
  });
  return true;
}

export function archiveTenant(tenant_id: string): boolean {
  const t = TENANT_STORE.get(tenant_id);
  if (!t) return false;
  t.status = 'archived';
  return true;
}

export function listAllTenants(): Tenant[] {
  return [...TENANT_STORE.values()];
}

export function countTenants(): { total: number; by_rank: Record<TenantRank, number>; by_plan: Record<string, number> } {
  const byRank: Record<string, number> = { parent: 0, child: 0, standalone: 0 };
  const byPlan: Record<string, number> = {};
  for (const t of TENANT_STORE.values()) {
    byRank[t.rank]++;
    byPlan[t.plan_tier] = (byPlan[t.plan_tier] ?? 0) + 1;
  }
  return { total: TENANT_STORE.size, by_rank: byRank as Record<TenantRank, number>, by_plan: byPlan };
}

export function _resetTenantsForTests(): void {
  TENANT_STORE.clear();
}
