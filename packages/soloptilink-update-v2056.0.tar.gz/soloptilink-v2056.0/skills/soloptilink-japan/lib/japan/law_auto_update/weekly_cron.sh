#!/usr/bin/env bash
# Phase 46-LU / 週次法令巡回 cron entrypoint
#
# 用途:
#   - 毎週月曜 03:00 JST に動かす想定 (cron 設定例は SKILL.md 参照)
#   - LAW_CATALOG (top priority) の全件を巡回し、改正があれば
#     ledger.jsonl / rag.jsonl / pr_drafts/ に永続化
#
# 設計指針:
#   - 失敗しても他法令巡回は止めない (個別エラーをログするだけ)
#   - 出力は ~/.soloptilink/learning/legal_updates/ 配下に集約
#   - ライセンス認証チェック (license-guard.sh) を先頭で必ず通す
#
# 実際の起動元 (2026-08-01 実測。以前ここに書かれていた
# 「chain.sh の Layer 0.92 LegalUpdate からも呼ばれる」は**虚偽**だった:
#  chain.sh に legal / law_auto_update / LegalUpdate の参照は 0 件):
#   1) launchd  ~/Library/LaunchAgents/com.soloptilink.primary-source-ingest.plist
#      → lib/japan/primary-source-ingest/scan.sh:63-66 が本スクリプトを起動する
#        (無効化スイッチ: PRIMARY_SOURCE_INGEST_SKIP_LAW=1 / 対象: LAW_TARGET 既定 top)
#   2) lib/aupe/connectors/egov.sh の egov_fetch()
#      → EGOV_RUN_CRON=true のときだけブリッジ起動する (既定 false = 起動しない)
#   3) 手動実行 (bash weekly_cron.sh {top|all})

set -euo pipefail

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
SL_DIR="${SL_DIR:-$HOME/.soloptilink}"
LEARNING_DIR="${SOLOPTILINK_LEARNING_DIR:-$SL_DIR/learning}"
LOG_DIR="$LEARNING_DIR/legal_updates/logs"
mkdir -p "$LOG_DIR"
TS="$(date +%Y%m%d_%H%M%S)"
LOG_FILE="$LOG_DIR/cron_${TS}.log"

# ---------- 1) ライセンス認証 ----------
if [ -f "$SL_DIR/lib/license-guard.sh" ]; then
  # license-guard.sh は AUTHORIZED 時のみ exit 0
  if ! bash "$SL_DIR/lib/license-guard.sh" >/dev/null 2>&1; then
    echo "[phase46-lu] license guard failed — aborting" | tee -a "$LOG_FILE"
    exit 2
  fi
fi

# ---------- 2) Node ランタイム検出 ----------
NODE_BIN="${NODE_BIN:-node}"
if ! command -v "$NODE_BIN" >/dev/null 2>&1; then
  echo "[phase46-lu] node not found in PATH — aborting" | tee -a "$LOG_FILE"
  exit 3
fi

# ---------- 3) target = top/all を判定 ----------
TARGET="${1:-top}"
case "$TARGET" in
  top|all) ;;
  *)
    echo "[phase46-lu] usage: $0 [top|all]" | tee -a "$LOG_FILE"
    exit 4 ;;
esac

# ---------- 4) Node 経由でレジストリ実行 ----------
RUNNER_TSCONFIG="${RUNNER_TSCONFIG:-}"  # 任意で tsconfig 上書き

# TypeScript の実行方式を決める。
#
# ★2026-07-31 是正: 従来は tsx / ts-node が無いと必ず `node --experimental-strip-types` に
#   落ちていたが、このオプションは Node 22.6 以降でしか使えない。実測環境は Node 18 のため
#   「node: bad option」で即死し、週次巡回は一度も走っていなかった (スケジューラにも未登録だった)。
#   本体には esbuild が同梱されているので、それでバンドルして実行する経路を追加する。
#   どの経路も使えないときは黙って落ちず、理由を明示して終了する。
RUNNER_MODE=""
ESBUILD_BIN=""

_probe_esbuild() {
  local c
  for c in "$SL_DIR/node_modules/.bin/esbuild" \
           "$SL_DIR/node_modules/esbuild/bin/esbuild" \
           "/opt/homebrew/lib/node_modules/esbuild/bin/esbuild" \
           "/usr/local/lib/node_modules/esbuild/bin/esbuild" \
           "$(command -v esbuild 2>/dev/null || true)"; do
    [ -n "$c" ] && [ -x "$c" ] && "$c" --version >/dev/null 2>&1 && { ESBUILD_BIN="$c"; return 0; }
  done
  return 1
}

if command -v tsx >/dev/null 2>&1; then
  RUNNER_MODE="tsx"
elif command -v ts-node >/dev/null 2>&1; then
  RUNNER_MODE="tsnode"
elif _probe_esbuild; then
  RUNNER_MODE="esbuild"
elif "$NODE_BIN" --experimental-strip-types -e '' >/dev/null 2>&1; then
  RUNNER_MODE="strip"
else
  echo "[phase46-lu] TypeScript を実行できる環境がありません (tsx / ts-node / esbuild / Node 22.6+ のいずれも不可)" | tee -a "$LOG_FILE"
  echo "[phase46-lu] 対処: 本体に esbuild を導入するか、tsx を入れてください" | tee -a "$LOG_FILE"
  exit 5
fi
echo "[phase46-lu] TypeScript 実行方式: $RUNNER_MODE" | tee -a "$LOG_FILE"

# .ts を含むエントリを実行する。esbuild 経路ではバンドルしてから node で走らせる。
run_ts() {
  local entry="$1"; shift
  case "$RUNNER_MODE" in
    tsx)    tsx "$entry" "$@" ;;
    tsnode) ts-node --esm "$entry" "$@" ;;
    strip)  "$NODE_BIN" --experimental-strip-types "$entry" "$@" ;;
    esbuild)
      local out="${entry%.*}.bundle.${TS}.mjs"
      if ! "$ESBUILD_BIN" "$entry" --bundle --platform=node --format=esm \
             --target=node18 --outfile="$out" --log-level=error; then
        echo "[phase46-lu] バンドルに失敗しました: $entry" >&2
        rm -f "$out"; return 6
      fi
      "$NODE_BIN" "$out" "$@"; local rc=$?
      rm -f "$out"; return $rc ;;
    *) echo "[phase46-lu] 実行方式が未解決です" >&2; return 5 ;;
  esac
}

cd "$SCRIPT_DIR"

# ★エントリは SCRIPT_DIR に置く。/tmp に置くと "./index.ts" の相対 import が解決できず、
#   どの実行方式でも動かない (従来の実装はここでも詰んでいた)。
ENTRY="$SCRIPT_DIR/.phase46_lu_run_${TS}.mjs"
cat > "$ENTRY" <<'MJS'
import { SourceRegistry, createNodePersistLayer, createNodePreviousVersionLookup } from "./index.ts";

const target = process.env.PHASE46_LU_TARGET || "top";
const baseDir = process.env.PHASE46_LU_BASE_DIR || `${process.env.HOME}/.soloptilink/learning`;

(async () => {
  const persist = await createNodePersistLayer(baseDir);
  const prev = await createNodePreviousVersionLookup(baseDir);
  const registry = new SourceRegistry();
  const result = await registry.orchestrate(prev, persist, { target });
  // ★2026-07-30 是正 (課題台帳 Q-04): 従来のログは totalChecked / errors しか出さず、
  //   「カタログの法令IDが別法令を指していて 1 件も取得できていない」事実が
  //   証跡に一切残らなかった (実測 41 件中 20 件が未巡回・6 件がID誤り)。
  //   判定 (verdict) と未巡回・ID不一致を必ずログへ出す = 未測定を成功に見せない。
  console.log(JSON.stringify({
    startedAt: result.startedAt,
    finishedAt: result.finishedAt,
    verdict: result.verdict,
    detail_ja: result.detail_ja,
    targetCount: result.targetCount,
    totalChecked: result.totalChecked,
    titleMismatches: result.titleMismatches,
    unpatrolledLaws: result.unpatrolledLaws,
    resolvedByLookup: result.resolvedByLookup,
    changesDetected: result.changesDetected,
    ragAppended: result.ragAppended,
    prDrafts: result.prDrafts.length,
    errors: result.errors,
  }, null, 2));
})().catch((e) => {
  console.error("[phase46-lu] orchestrate failed:", e?.message ?? e);
  process.exit(1);
});
MJS

PHASE46_LU_TARGET="$TARGET" PHASE46_LU_BASE_DIR="$LEARNING_DIR" \
  run_ts "$ENTRY" 2>&1 | tee -a "$LOG_FILE"

rc=${PIPESTATUS[0]}
echo "[phase46-lu] finished target=$TARGET rc=$rc" | tee -a "$LOG_FILE"

# ---------- 5) 3カレンダー × e-Gov巡回 (S7/L21-WK07・改正検知→PR下書き・非致命) ----------
#   reward/tax/amendment の3カレンダー対象法令を e-Gov法令API v2(鍵不要)で巡回し snapshot/改正検知。
#   改正検知時は PR下書きを learning/legal_updates/calendar_sync/ に生成(カレンダー直書きはしない=owner承認のまま)。
#   非致命: 失敗しても本巡回(orchestrate)の rc は維持する。
if [ -f "$SCRIPT_DIR/calendar_sync.ts" ]; then
  echo "[phase46-lu] calendar_sync (3カレンダー×e-Gov巡回) 開始" | tee -a "$LOG_FILE"
  CALENDAR_SYNC_STAMP="$TS" run_ts "$SCRIPT_DIR/calendar_sync.ts" live "${CALENDAR_SYNC_MAX:-3}" 2>&1 | tee -a "$LOG_FILE" \
    || echo "[phase46-lu] calendar_sync 非致命エラー(巡回継続)" | tee -a "$LOG_FILE"
fi

rm -f "$ENTRY" "${ENTRY%.*}.bundle."*.mjs 2>/dev/null || true
exit "$rc"
