/**
 * Phase 46-LU-8 / Quality Deepening & SIEL Bridge Dashboard
 *
 * LU-8 の 5 サブシステム統合表示。
 */

import { countCasesV3 } from './corpus/case_law_v3';
import { countCatalogV3 } from './corpus/catalog_v3';
import { countHistorical, listAllAmendedLaws } from './historical/historical_amendments';
import { countPredictions, buildIntegratedForecast } from './regulatory_radar/longterm_predictor';
import { summarizeBridge, SIEL_BRIDGE_BINDINGS } from './siel_bridge/siel_integration_bridge';

export interface DeepeningDashboard {
  generated_at: string;
  case_law_v3: { added: number; cumulative: number; by_area: Record<string, number> };
  catalog_v3: { added: number; cumulative: number; by_category: Record<string, number> };
  historical: { total: number; laws_covered: number; major_count: number };
  predictions: { total: number; high_confidence: number; international_drivers: number };
  siel_bridge: { total_bindings: number; by_phase: Record<string, number> };
  deepening_score: number;
  capabilities: string[];
}

export function buildDeepeningDashboard(): DeepeningDashboard {
  const cases = countCasesV3();
  const catalog = countCatalogV3();
  const hist = countHistorical();
  const preds = countPredictions();
  const bridge = summarizeBridge();
  const forecast = buildIntegratedForecast();

  let score = 0;
  if (cases.added >= 50) score += 20;
  if (catalog.added >= 50) score += 20;
  if (hist.total >= 30) score += 20;
  if (preds.total >= 5) score += 15;
  if (bridge.total_bindings >= 8) score += 25;
  score = Math.min(100, score);

  return {
    generated_at: new Date().toISOString(),
    case_law_v3: {
      added: cases.added,
      cumulative: 152 + cases.added, // LU-4 supplement 152 + LU-8 v3
      by_area: cases.by_area,
    },
    catalog_v3: {
      added: catalog.added,
      cumulative: catalog.cumulative_estimate,
      by_category: catalog.by_category,
    },
    historical: {
      total: hist.total,
      laws_covered: listAllAmendedLaws().length,
      major_count: hist.by_kind.major ?? 0,
    },
    predictions: {
      total: preds.total,
      high_confidence: preds.high_confidence,
      international_drivers: preds.international,
    },
    siel_bridge: {
      total_bindings: bridge.total_bindings,
      by_phase: bridge.by_phase,
    },
    deepening_score: score,
    capabilities: [
      `判例 +${cases.added}件 → 累計 ${152 + cases.added} 件 (法律実務水準への接近)`,
      `法令カタログ +${catalog.added}件 → 累計 ${catalog.cumulative_estimate} 件`,
      `過去20年改正履歴 ${hist.total} 件 (${listAllAmendedLaws().length} 法令カバー)`,
      `5年スパン予測 ${preds.total} 件 (高信頼度 ${preds.high_confidence} 件)`,
      `国際動向ドライバー ${preds.international} 件 (GDPR/EU AI Act/SOX/BEPS/CSRD等)`,
      `SIEL Phase 47-50 統合バインディング ${bridge.total_bindings} 件`,
      `業種別準備リスト ${forecast.industry_preparation.length} 業種`,
    ],
  };
}

export function renderDeepeningDashboard(): string {
  const d = buildDeepeningDashboard();
  const lines: string[] = [];
  lines.push('================================================================');
  lines.push('  Phase 46-LU-8 / Quality Deepening & SIEL Bridge Dashboard');
  lines.push('================================================================');
  lines.push(`  Generated: ${d.generated_at}`);
  lines.push(`  Deepening Score: ${d.deepening_score} / 100`);
  lines.push('');
  lines.push('[Case Law v3]');
  lines.push(`  追加: ${d.case_law_v3.added} 件 / 累計: ${d.case_law_v3.cumulative} 件`);
  for (const [area, n] of Object.entries(d.case_law_v3.by_area)) {
    lines.push(`    ${area}: ${n}`);
  }
  lines.push('');
  lines.push('[Catalog v3]');
  lines.push(`  追加: ${d.catalog_v3.added} 件 / 累計: ${d.catalog_v3.cumulative} 件`);
  for (const [cat, n] of Object.entries(d.catalog_v3.by_category)) {
    lines.push(`    ${cat}: ${n}`);
  }
  lines.push('');
  lines.push('[Historical Amendments (20年遡及)]');
  lines.push(`  Total: ${d.historical.total} / Major: ${d.historical.major_count} / 法令カバー: ${d.historical.laws_covered}`);
  lines.push('');
  lines.push('[5-Year Predictions]');
  lines.push(`  Total: ${d.predictions.total} / High Confidence (>=70%): ${d.predictions.high_confidence}`);
  lines.push(`  International Drivers: ${d.predictions.international_drivers}`);
  lines.push('');
  lines.push('[SIEL Bridge (Phase 47-50)]');
  lines.push(`  Total Bindings: ${d.siel_bridge.total_bindings}`);
  for (const [phase, n] of Object.entries(d.siel_bridge.by_phase)) {
    lines.push(`    ${phase}: ${n} 件`);
  }
  lines.push('');
  lines.push('[Capabilities]');
  for (const c of d.capabilities) lines.push(`  ✓ ${c}`);
  lines.push('================================================================');
  return lines.join('\n');
}

export function summarizeDeepeningJson() {
  return buildDeepeningDashboard();
}
