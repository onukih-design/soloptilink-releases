/**
 * Phase 46-LU-5 / LLM Prompt Builder for Legal RAG
 *
 * RAG 検索結果から LLM プロンプトを構築する。
 * LLM (Claude/GPT/Gemini) を呼び出す前段として、文脈・出典を整形する。
 *
 * 設計指針:
 *  - 出典は必ず含める (法的責任の所在を明確化)
 *  - 「該当法令なし」も明示するテンプレ
 *  - 言語ポリシー: 日本語回答前提 (JAPAN-NATIVE Mode 維持)
 *  - 改正リスクを織り込んだ免責文を自動付加
 */

import type { RetrievalResult } from './embedding_index';

export type PromptKind =
  | 'qa' // 一般 QA
  | 'compliance_check' // コンプライアンスチェック
  | 'contract_review' // 契約書レビュー
  | 'incident_response' // インシデント対応
  | 'amendment_summary' // 改正サマリー
  | 'comparative_analysis'; // 比較法分析

export interface PromptBuildInput {
  kind: PromptKind;
  user_query: string;
  retrieved: RetrievalResult[];
  /** Tenant DNA 情報 (業種等) */
  tenant_context?: {
    industries?: string[];
    company_size?: 'small' | 'medium' | 'large' | 'enterprise';
    international?: boolean;
  };
  /** 回答言語 */
  locale?: 'ja' | 'en' | 'zh-CN';
  /** トークン上限 (近似文字数 / 1日本語=2token目安) */
  max_chars?: number;
}

export interface BuiltPrompt {
  system_prompt: string;
  user_prompt: string;
  /** プロンプト全体の概算文字数 */
  estimated_chars: number;
  /** 採用された出典 */
  citations: Array<{ doc_id: string; short_name: string; citation: string }>;
  /** Token budget 警告 */
  warnings: string[];
}

const SYSTEM_PROMPT_BASE_JA = `あなたは日本法を専門とする AI 法務アシスタントです。
以下のルールを厳守してください:
1. 提供された資料 (法令・判例・通達・学説) のみを根拠に回答する
2. 推測や憶測は明示する (「学説の一例として」等)
3. 必ず出典 (引用) を付ける (例: 民法第415条 / 最判H30.6.1)
4. 改正の可能性ある条文は「○年○月時点」と明記する
5. 「法的助言ではなく一般情報」である旨を回答末尾に付す
6. 回答は日本語で、簡潔かつ実務家視点で行う`;

const KIND_INSTRUCTIONS: Record<PromptKind, string> = {
  qa: '質問に対し、提供資料の該当条文を引用しつつ、3-5段落で回答してください。',
  compliance_check: '提供されたコード・契約条項に対し、コンプライアンス違反の有無を判定し、違反箇所と該当法令を列挙してください。',
  contract_review: '契約書条項を法令適合性 (民法・消費者契約法・労働契約法 等) の観点でレビューし、リスクと修正案を提示してください。',
  incident_response: 'インシデントの法的対応手順 (報告義務・通知義務・損害賠償リスク) を法令引用付きで列挙してください。',
  amendment_summary: '法令改正の要点を「改正前/改正後/施行日/実務影響」のフォーマットでまとめてください。',
  comparative_analysis: '日本法と比較法 (GDPR/CCPA/SOX 等) の異同を表形式でまとめてください。',
};

export function buildPrompt(input: PromptBuildInput): BuiltPrompt {
  const locale = input.locale ?? 'ja';
  const maxChars = input.max_chars ?? 12000;
  const kindInstruction = KIND_INSTRUCTIONS[input.kind];
  const warnings: string[] = [];

  // Tenant context
  const ctxLines: string[] = [];
  if (input.tenant_context?.industries?.length) {
    ctxLines.push(`業種: ${input.tenant_context.industries.join('・')}`);
  }
  if (input.tenant_context?.company_size) {
    ctxLines.push(`規模: ${input.tenant_context.company_size}`);
  }
  if (input.tenant_context?.international) {
    ctxLines.push('国際事業: あり (GDPR/SOX/FCPA等の比較法考慮)');
  }
  const tenantCtx = ctxLines.length > 0 ? `\n[テナント情報]\n${ctxLines.join('\n')}\n` : '';

  // Retrieved context (出典付き)
  const citations: BuiltPrompt['citations'] = [];
  const ctxBlocks: string[] = [];
  let acc = 0;
  for (const r of input.retrieved) {
    const block = `[${r.doc.source}] ${r.doc.short_name}
出典: ${r.doc.citation}
内容: ${r.doc.text.slice(0, 600)}
---`;
    if (acc + block.length > maxChars * 0.6) {
      warnings.push(`コンテキスト ${ctxBlocks.length} 件で打ち切り (token 上限)`);
      break;
    }
    ctxBlocks.push(block);
    citations.push({ doc_id: r.doc.doc_id, short_name: r.doc.short_name, citation: r.doc.citation });
    acc += block.length;
  }
  const ctxBody = ctxBlocks.length > 0
    ? `\n[参照資料 ${ctxBlocks.length}件]\n${ctxBlocks.join('\n')}\n`
    : '\n[参照資料]\n(該当資料なし。回答は一般原則に基づいて行うが、信頼度は低い旨を明記)\n';

  const systemPrompt = locale === 'ja' ? SYSTEM_PROMPT_BASE_JA : SYSTEM_PROMPT_BASE_JA;
  const userPrompt = `${tenantCtx}\n${ctxBody}\n[指示]\n${kindInstruction}\n\n[質問]\n${input.user_query}`;

  return {
    system_prompt: systemPrompt,
    user_prompt: userPrompt,
    estimated_chars: systemPrompt.length + userPrompt.length,
    citations,
    warnings,
  };
}

/**
 * HyDE (Hypothetical Document Embeddings) 用の仮想ドキュメント生成プロンプト。
 * 検索精度向上のために、まず LLM に「もし答えがあるとしたらどう書かれるか」を生成させ、
 * その仮想文書で再検索する。
 */
export function buildHydeQuery(userQuery: string): string {
  return `以下の質問に対する日本の法令の典型的な回答を、出典を付けた架空の判例または条文の形式で書いてください (これは検索クエリ生成のための仮想回答であり、事実である必要はありません)。

質問: ${userQuery}

仮想回答:`;
}

/**
 * Few-shot サンプル付き Compliance プロンプト
 */
export function buildComplianceFewShot(input: {
  code_snippet: string;
  retrieved: RetrievalResult[];
}): BuiltPrompt {
  const examples = `[Few-shot 例]
例1: SQL 直書きで個人情報取得 → 個情法第26条 (個人データの第三者提供) + OWASP A03 SQL Injection
例2: console.log(myNumber) → マイナンバー法 (番号法) 第19条違反の可能性
例3: alert('Password incorrect') 詳細露出 → セキュリティ (CWE-209 情報漏洩)
`;

  const base = buildPrompt({
    kind: 'compliance_check',
    user_query: `以下のコードをコンプライアンス違反の観点でレビューしてください:\n\n\`\`\`\n${input.code_snippet}\n\`\`\``,
    retrieved: input.retrieved,
  });

  return {
    ...base,
    user_prompt: examples + '\n' + base.user_prompt,
    estimated_chars: base.estimated_chars + examples.length,
  };
}

/**
 * 出典のみの簡易レンダリング (LLM 不使用時のフォールバック)
 */
export function renderCitationsOnly(retrieved: RetrievalResult[]): string {
  const lines: string[] = ['## 関連法令・判例 (出典)'];
  retrieved.forEach((r, i) => {
    lines.push(`${i + 1}. [${r.doc.source}] **${r.doc.short_name}** — ${r.doc.citation}`);
    lines.push(`   - スコア: ${r.score.toFixed(3)} / マッチ語: ${r.matched_terms.slice(0, 5).join(', ')}`);
  });
  return lines.join('\n');
}
