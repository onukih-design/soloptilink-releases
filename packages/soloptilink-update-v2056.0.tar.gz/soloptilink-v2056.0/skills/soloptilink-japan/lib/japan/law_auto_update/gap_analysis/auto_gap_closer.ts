/**
 * Phase 46-LU-4 / Auto Gap Closer
 *
 * Knowledge Gap Analyzer で検出した抜け漏れを、内蔵候補ライブラリ
 * (KNOWN_CANDIDATE_CASES / KNOWN_CANDIDATE_LAWS) から自動取り込みする。
 *
 * ただし「自動」とは言っても、判例本文や法令本文は LLM 生成ではなく
 * 既知メタデータからの appender に留める (誤った判例を捏造しないため)。
 *
 *  - missing ドメイン → 候補リストから top-N を提案
 *  - partial ドメイン → 残不足を計算 → 追加候補を提案
 *  - complete ドメイン → スキップ
 *
 * 実際の追加は人手承認後に手動実行 (PR レビュー必須)。
 */

import { recommendGaps, type GapRecommendation } from './gap_recommendations';
import { analyzeKnowledgeGaps, type KnowledgeGapReport } from './knowledge_gap_analyzer';
import { EXTENDED_LANDMARK_CASES } from '../corpus/case_law_extended';

export interface ClosurePlan {
  generated_at: string;
  /** 自動取り込み候補 (人手承認待ち) */
  pending_additions: Array<{
    kind: GapRecommendation['kind'];
    candidate_name: string;
    domain: string;
    priority: number;
    auto_addable: boolean;
    reason: string;
  }>;
  /** 既に追加済の候補 (Phase 46-LU-4 で投入された判例50件等) */
  auto_added_in_lu4: Array<{ case_id: string; short_name: string }>;
  /** 残ギャップ */
  remaining_gap_count: number;
  next_action: string;
}

/**
 * クロージャー計画を立てる
 */
export function planGapClosure(opts: { maxRecommendations?: number } = {}): ClosurePlan {
  const max = opts.maxRecommendations ?? 30;
  const recs = recommendGaps({ maxItems: max });
  const report = analyzeKnowledgeGaps();

  // Phase 46-LU-4 で既に追加された判例
  const autoAdded = EXTENDED_LANDMARK_CASES.map((c) => ({
    case_id: c.case_id,
    short_name: c.short_name,
  }));

  const pending = recs.map((r) => ({
    kind: r.kind,
    candidate_name: r.candidate_name,
    domain: r.domain,
    priority: r.priority,
    auto_addable: r.kind === 'case' || r.kind === 'catalog',
    reason: r.reasoning.join(' / '),
  }));

  return {
    generated_at: new Date().toISOString(),
    pending_additions: pending,
    auto_added_in_lu4: autoAdded,
    remaining_gap_count: report.gap_count,
    next_action: pending.length > 0
      ? '人手承認後、最優先 priority 候補から順に追加'
      : 'ギャップなし — Diamond ライン達成済み',
  };
}

/**
 * 反復補完サイクル: 「diff → recommendation → 提案」をループ
 */
export async function iterateClosureCycles(opts: { maxCycles?: number } = {}): Promise<{
  cycles: number;
  final_report: KnowledgeGapReport;
  closure_plans: ClosurePlan[];
}> {
  const max = opts.maxCycles ?? 3;
  const plans: ClosurePlan[] = [];
  for (let i = 0; i < max; i++) {
    plans.push(planGapClosure());
  }
  return {
    cycles: max,
    final_report: analyzeKnowledgeGaps(),
    closure_plans: plans,
  };
}

/**
 * 「自動追加」シミュレーション (実コード変更はせず、追加した場合のシミュレート)。
 */
export function simulateAutoAddition(plan: ClosurePlan): {
  simulated_added: number;
  simulated_remaining_gap: number;
  recommendation_md: string;
} {
  const addable = plan.pending_additions.filter((p) => p.auto_addable);
  const lines: string[] = [];
  lines.push('# Auto-Closure Simulation Report');
  lines.push('');
  lines.push(`生成日時: ${plan.generated_at}`);
  lines.push(`自動追加可能候補: ${addable.length}件`);
  lines.push(`Phase 46-LU-4 で既追加: ${plan.auto_added_in_lu4.length}件`);
  lines.push('');
  lines.push('## 自動追加候補');
  for (const a of addable.slice(0, 15)) {
    lines.push(`- [${a.kind}] ${a.candidate_name} (priority=${a.priority}, ${a.domain})`);
  }
  lines.push('');
  lines.push('## 残ギャップ');
  lines.push(`${plan.remaining_gap_count - addable.length}件 (シミュレーション後)`);
  return {
    simulated_added: addable.length,
    simulated_remaining_gap: Math.max(0, plan.remaining_gap_count - addable.length),
    recommendation_md: lines.join('\n'),
  };
}
