/**
 * Phase 46-LU / e-Gov パブリックコメント ウォッチャー
 *
 * https://public-comment.e-gov.go.jp/ で募集中・終了したパブコメを取得。
 * 法令改正の「予兆」を捉え、施行前に対応コードを準備するための入力源。
 *
 * 取得方式:
 *  - 公開リスト HTML or RSS (実エンドポイントが変更されてもフォールバック可)
 *  - 出典は PUBCOMMENT_ATTRIBUTION で自動付与
 */

import type { LawCategory } from '../law_tracker';
import { rateLimited } from './rate_limiter';
import { attachAttribution, PUBCOMMENT_ATTRIBUTION } from './attribution';

const PUBCOMMENT_BASE = 'https://public-comment.e-gov.go.jp';

export interface PubCommentEntryFull {
  publicCommentId: string;
  title: string;
  competentMinistry: string;
  startDate: string;
  endDate: string;
  /** パブコメ詳細ページURL */
  url: string;
  category?: LawCategory;
  /** 関連法令ID (e-Gov lawId が分かる場合) */
  relatedLawIds: string[];
  /** 募集テーマ概要 (短文) */
  summary?: string;
  /** 状態 */
  status: 'open' | 'closed' | 'reflecting';
}

export interface PubCommentClientOptions {
  baseUrl?: string;
  fetchImpl?: typeof fetch;
  userAgent?: string;
  disableRateLimit?: boolean;
}

export class PubCommentClient {
  private readonly baseUrl: string;
  private readonly fetchImpl: typeof fetch;
  private readonly userAgent: string;
  private readonly disableRateLimit: boolean;

  constructor(opts: PubCommentClientOptions = {}) {
    this.baseUrl = opts.baseUrl ?? PUBCOMMENT_BASE;
    const candidate = opts.fetchImpl ?? (typeof fetch === 'function' ? fetch : undefined);
    if (!candidate) throw new Error('PubCommentClient: fetch implementation not available');
    this.fetchImpl = candidate;
    this.userAgent = opts.userAgent ?? 'SoloptiLinkAI-LawAutoUpdate/1.0';
    this.disableRateLimit = opts.disableRateLimit ?? false;
  }

  async fetchOpenComments(): Promise<PubCommentEntryFull[]> {
    return this.fetchByStatus('open');
  }

  async fetchByCategory(category: LawCategory): Promise<PubCommentEntryFull[]> {
    const all = await this.fetchByStatus('open');
    return all.filter((e) => e.category === category);
  }

  async fetchByStatus(status: 'open' | 'closed' | 'reflecting'): Promise<PubCommentEntryFull[]> {
    const exec = async (): Promise<PubCommentEntryFull[]> => {
      const path =
        status === 'open' ? '/servlet/Public?CLASSNAME=PCMMSTDETAIL'
        : status === 'closed' ? '/servlet/Public?CLASSNAME=PCM1090&id=closed'
        : '/servlet/Public?CLASSNAME=PCM1090&id=reflecting';
      const url = `${this.baseUrl}${path}`;
      const res = await this.fetchImpl(url, {
        method: 'GET',
        headers: { 'User-Agent': this.userAgent, Accept: 'text/html' },
      });
      if (!res.ok) return [];
      const html = await res.text();
      return this.parseListHtml(html, status);
    };
    if (this.disableRateLimit) return exec();
    return rateLimited('public-comment', exec);
  }

  parseListHtml(html: string, status: 'open' | 'closed' | 'reflecting'): PubCommentEntryFull[] {
    const out: PubCommentEntryFull[] = [];
    // 簡易抽出: 詳細ページへのリンクを拾う (構造変更耐性)
    const re = /<a[^>]+href="([^"]*PCMMSTDETAIL[^"]*)"[^>]*>([^<]+)<\/a>/g;
    let m: RegExpExecArray | null;
    while ((m = re.exec(html)) !== null) {
      const href = m[1];
      const title = m[2].trim();
      // ID 推定: id=XXX or CLASSNAME 後ろ
      const idMatch = href.match(/(?:id|publicCommentId)=([\w-]+)/i);
      const publicCommentId = idMatch ? idMatch[1] : `pubc-${out.length + 1}`;
      out.push({
        publicCommentId,
        title,
        competentMinistry: this.inferMinistry(title),
        startDate: '',
        endDate: '',
        url: href.startsWith('http') ? href : `${this.baseUrl}${href.startsWith('/') ? '' : '/'}${href}`,
        category: this.inferCategory(title),
        relatedLawIds: [],
        status,
      });
    }
    return out.map((e) => attachAttribution(e, PUBCOMMENT_ATTRIBUTION) as PubCommentEntryFull);
  }

  private inferMinistry(title: string): string {
    if (/個人情報|個情/.test(title)) return '個人情報保護委員会';
    if (/税|消費税|国税/.test(title)) return '国税庁/財務省';
    if (/労働|雇用|職業安定/.test(title)) return '厚生労働省';
    if (/会社|商事|登記|公証/.test(title)) return '法務省';
    if (/建設|建築|不動産|住宅/.test(title)) return '国土交通省';
    if (/医療|診療|介護|医薬/.test(title)) return '厚生労働省';
    if (/金融|証券|銀行|保険/.test(title)) return '金融庁';
    if (/環境|気候|公害|廃棄物/.test(title)) return '環境省';
    if (/教育|学校|大学/.test(title)) return '文部科学省';
    if (/食品|農業|畜産|水産|林業/.test(title)) return '農林水産省';
    if (/電気通信|放送|郵便/.test(title)) return '総務省';
    return '主管省庁';
  }

  private inferCategory(title: string): LawCategory | undefined {
    if (/税|消費税|国税/.test(title)) return 'tax';
    if (/労働|雇用/.test(title)) return 'labor';
    if (/個人情報|プライバシー/.test(title)) return 'privacy';
    if (/会社|商事/.test(title)) return 'corporate';
    if (/建設|建築/.test(title)) return 'construction';
    if (/医療|診療/.test(title)) return 'medical';
    if (/介護|高齢者/.test(title)) return 'longterm_care';
    if (/金融|証券|銀行/.test(title)) return 'finance';
    if (/環境|公害/.test(title)) return 'environment';
    if (/不動産|宅建/.test(title)) return 'real_estate';
    if (/運輸|物流|車両/.test(title)) return 'transport';
    if (/食品/.test(title)) return 'food';
    if (/薬機|医薬品|医療機器/.test(title)) return 'pharma';
    if (/放送|電気通信/.test(title)) return 'broadcasting';
    return undefined;
  }
}

let _defaultPubc: PubCommentClient | undefined;
export function getDefaultPubCommentClient(): PubCommentClient {
  if (!_defaultPubc) _defaultPubc = new PubCommentClient();
  return _defaultPubc;
}
export function setDefaultPubCommentClient(c: PubCommentClient): void {
  _defaultPubc = c;
}
