/**
 * Phase 46-LU-6 / Amendment Alert Email Dispatcher
 *
 * 法令改正アラートをメールで定期配信する。
 *  - 即時 (realtime): 改正検知直後 (Phase 46-LU の SourceRegistry と連動)
 *  - 日次 (daily): 09:00 JST まとめて配信
 *  - 週次 (weekly): 月曜 08:00 JST
 *  - 月次 (monthly): 月初の月曜
 *
 * 配信内容:
 *  - 改正サマリー
 *  - 該当判例 (引用ネットワーク経由)
 *  - 顧客業種フィルター (Tenant DNA + プラン依存)
 *  - 一斉配信時の SendGrid/SES 経由 (本モジュールは構造定義のみ。実送信はホスト側)
 */

import type { LawCategory } from '../../law_tracker';

export type AlertFrequency = 'realtime' | 'daily' | 'weekly' | 'monthly';

export interface AlertSubscription {
  subscription_id: string;
  tenant_id: string;
  email: string;
  frequency: AlertFrequency;
  /** 関心法令の short_name (空なら全件) */
  law_short_codes: string[];
  /** カテゴリフィルター */
  categories: LawCategory[];
  /** 重要度フィルター (critical only / major+ / all) */
  min_severity: 'critical' | 'major' | 'minor' | 'all';
  /** 業種フィルター (Tenant DNA から自動) */
  industry_tags?: string[];
  /** ローカライズ */
  locale: 'ja' | 'en' | 'zh-CN';
  /** ステータス */
  status: 'active' | 'paused' | 'unsubscribed';
  /** 作成日時 */
  created_at: string;
  /** 直近の配信日時 */
  last_dispatched_at?: string;
  /** 配信成功数 / 失敗数 */
  delivery_stats: { sent: number; failed: number; opened: number; clicked: number };
}

export interface AlertPayload {
  /** 改正検知結果 (Phase 46-LU の ChangeLedgerEntry を変換) */
  law_short: string;
  effective_date: string;
  severity: 'critical' | 'major' | 'minor' | 'editorial';
  changed_article_count: number;
  category: LawCategory;
  description: string;
  /** 関連判例 */
  related_cases?: Array<{ case_id: string; short_name: string }>;
  /** 修正対応ガイド (impact_analyzer 由来) */
  modification_guide?: string;
}

const SUBSCRIPTIONS = new Map<string, AlertSubscription>();

export function subscribe(input: {
  tenant_id: string;
  email: string;
  frequency: AlertFrequency;
  law_short_codes?: string[];
  categories?: LawCategory[];
  min_severity?: AlertSubscription['min_severity'];
  industry_tags?: string[];
  locale?: AlertSubscription['locale'];
}): AlertSubscription {
  const sub: AlertSubscription = {
    subscription_id: `sub_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    tenant_id: input.tenant_id,
    email: input.email,
    frequency: input.frequency,
    law_short_codes: input.law_short_codes ?? [],
    categories: input.categories ?? [],
    min_severity: input.min_severity ?? 'minor',
    industry_tags: input.industry_tags,
    locale: input.locale ?? 'ja',
    status: 'active',
    created_at: new Date().toISOString(),
    delivery_stats: { sent: 0, failed: 0, opened: 0, clicked: 0 },
  };
  SUBSCRIPTIONS.set(sub.subscription_id, sub);
  return sub;
}

export function unsubscribe(subscription_id: string): boolean {
  const sub = SUBSCRIPTIONS.get(subscription_id);
  if (!sub) return false;
  sub.status = 'unsubscribed';
  return true;
}

export function pause(subscription_id: string): boolean {
  const sub = SUBSCRIPTIONS.get(subscription_id);
  if (!sub) return false;
  sub.status = 'paused';
  return true;
}

/**
 * 配信対象を計算する (改正イベント → 該当購読)
 */
export function findRecipients(payload: AlertPayload): AlertSubscription[] {
  const sevRank = { critical: 4, major: 3, minor: 2, editorial: 1 };
  return [...SUBSCRIPTIONS.values()].filter((sub) => {
    if (sub.status !== 'active') return false;
    if (sub.law_short_codes.length > 0 && !sub.law_short_codes.includes(payload.law_short)) return false;
    if (sub.categories.length > 0 && !sub.categories.includes(payload.category)) return false;
    if (sub.min_severity !== 'all') {
      const minRank = sevRank[sub.min_severity as keyof typeof sevRank] ?? 1;
      const payloadRank = sevRank[payload.severity];
      if (payloadRank < minRank) return false;
    }
    return true;
  });
}

/**
 * メール本文を構築 (HTMLとPlain Text 両方)
 */
export interface AlertEmail {
  subject: string;
  text_body: string;
  html_body: string;
  unsubscribe_url: string;
}

export function buildAlertEmail(input: {
  subscription: AlertSubscription;
  payload: AlertPayload;
}): AlertEmail {
  const { subscription: sub, payload } = input;
  const locale = sub.locale;

  const subjectJa = `【法令改正アラート】${payload.law_short} ${payload.severity === 'critical' ? '🚨 重大' : '改正'} (施行 ${payload.effective_date})`;
  const subjectEn = `[Legal Update Alert] ${payload.law_short} — ${payload.severity} (Effective ${payload.effective_date})`;
  const subject = locale === 'en' ? subjectEn : subjectJa;

  const textLines: string[] = [];
  if (locale === 'en') {
    textLines.push(`Legal Update Alert: ${payload.law_short}`);
    textLines.push('');
    textLines.push(`Effective: ${payload.effective_date}`);
    textLines.push(`Severity: ${payload.severity}`);
    textLines.push(`Changed articles: ${payload.changed_article_count}`);
    textLines.push('');
    textLines.push(`Description: ${payload.description}`);
  } else {
    textLines.push(`【${payload.law_short}】 法令改正のお知らせ`);
    textLines.push('');
    textLines.push(`施行日: ${payload.effective_date}`);
    textLines.push(`重要度: ${payload.severity}`);
    textLines.push(`変更条文数: ${payload.changed_article_count}`);
    textLines.push('');
    textLines.push(`内容: ${payload.description}`);
  }
  textLines.push('');
  if (payload.related_cases?.length) {
    textLines.push(locale === 'en' ? '## Related Cases' : '## 関連判例');
    for (const c of payload.related_cases) {
      textLines.push(`- ${c.short_name}`);
    }
    textLines.push('');
  }
  if (payload.modification_guide) {
    textLines.push(locale === 'en' ? '## Action Guide' : '## 対応ガイド');
    textLines.push(payload.modification_guide.slice(0, 1000));
    textLines.push('');
  }

  const unsubUrl = `https://soloptilink.com/legal/alerts/unsubscribe?id=${sub.subscription_id}`;
  textLines.push('---');
  textLines.push(locale === 'en'
    ? `Unsubscribe: ${unsubUrl}\n※ SoloptiLinkAI Legal — This is general information, not legal advice.`
    : `購読解除: ${unsubUrl}\n※ SoloptiLinkAI Legal — 一般情報であり法的助言ではありません。`,
  );

  const textBody = textLines.join('\n');
  const htmlBody = `<!DOCTYPE html><html><body style="font-family:sans-serif">
<h1 style="color:${payload.severity === 'critical' ? '#c00' : '#333'}">${subject}</h1>
<pre style="white-space:pre-wrap">${escapeHtml(textBody)}</pre>
<hr><small><a href="${unsubUrl}">${locale === 'en' ? 'Unsubscribe' : '購読解除'}</a></small>
</body></html>`;

  return { subject, text_body: textBody, html_body: htmlBody, unsubscribe_url: unsubUrl };
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/**
 * 一斉配信ドライラン (実送信は外部 (SendGrid/SES) で行う)
 */
export interface DispatchPlan {
  payload: AlertPayload;
  recipient_count: number;
  recipients: Array<{ subscription_id: string; email: string; locale: string }>;
  estimated_send_duration_sec: number;
}

export function planDispatch(payload: AlertPayload): DispatchPlan {
  const recipients = findRecipients(payload);
  return {
    payload,
    recipient_count: recipients.length,
    recipients: recipients.map((r) => ({
      subscription_id: r.subscription_id,
      email: r.email,
      locale: r.locale,
    })),
    estimated_send_duration_sec: Math.ceil(recipients.length / 100), // 100 emails/sec 想定
  };
}

export function recordDispatch(input: {
  subscription_id: string;
  result: 'sent' | 'failed' | 'opened' | 'clicked';
}): boolean {
  const sub = SUBSCRIPTIONS.get(input.subscription_id);
  if (!sub) return false;
  sub.delivery_stats[input.result]++;
  if (input.result === 'sent') sub.last_dispatched_at = new Date().toISOString();
  return true;
}

export function countSubscriptions(): {
  total: number;
  by_frequency: Record<AlertFrequency, number>;
  by_status: Record<string, number>;
  active_count: number;
} {
  const byFreq: Record<string, number> = { realtime: 0, daily: 0, weekly: 0, monthly: 0 };
  const byStatus: Record<string, number> = { active: 0, paused: 0, unsubscribed: 0 };
  let active = 0;
  for (const s of SUBSCRIPTIONS.values()) {
    byFreq[s.frequency]++;
    byStatus[s.status]++;
    if (s.status === 'active') active++;
  }
  return {
    total: SUBSCRIPTIONS.size,
    by_frequency: byFreq as Record<AlertFrequency, number>,
    by_status: byStatus,
    active_count: active,
  };
}

export function _resetSubscriptionsForTests(): void {
  SUBSCRIPTIONS.clear();
}
