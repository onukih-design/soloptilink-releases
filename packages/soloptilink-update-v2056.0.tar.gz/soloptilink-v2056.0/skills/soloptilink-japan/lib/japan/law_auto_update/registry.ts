/**
 * Phase 46-LU / ソース統合レジストリ
 *
 * 各ソースクライアント (e-Gov / 官報 / パブコメ) を統合し、
 * 週次巡回の orchestration を担う。
 *
 * 設計:
 *  - DI: クライアントは外部から差し替え可能 (テストで mock 注入)
 *  - 永続化先: ~/.soloptilink/learning/legal_updates/{ledger.jsonl, rag.jsonl}
 *  - 失敗時のリトライポリシー: 個別ソース失敗は他に波及させない
 *  - 出力: orchestration 結果サマリー (どの法令をいくつ検知したか)
 */

import { EgovV2Client, getDefaultEgovV2Client } from './source_egov_v2';
import { KanpoClient, getDefaultKanpoClient } from './source_kanpo';
import { PubCommentClient, getDefaultPubCommentClient } from './source_pubcomment';
import { detectChange, buildLedgerEntry, serializeLedgerEntries } from './change_detector';
import type { ChangeLedgerEntry } from './change_detector';
import { analyzeImpact } from './impact_analyzer_v2';
import type { ImpactAnalysis } from './impact_analyzer_v2';
import { buildRagEntries, serializeRagEntriesToJsonl } from './rag_indexer';
import type { LegalUpdateRagEntry } from './rag_indexer';
import { generatePRDraft } from './auto_pr_generator';
import type { PullRequestDraft } from './auto_pr_generator';
import { EXTENDED_LAW_CATALOG, getTopPriorityLaws } from './catalog_full';
import type { ExtendedLawCatalogEntry } from './catalog_full';
import { EGOV_ATTRIBUTION, KANPO_ATTRIBUTION, PUBCOMMENT_ATTRIBUTION } from './attribution';
import type { EgovLawTextChunk, EgovLawSummary } from '../law_tracker';

export interface RegistryClients {
  egov: EgovV2Client;
  kanpo: KanpoClient;
  pubcomment: PubCommentClient;
}

export interface PreviousVersionLookup {
  /**
   * lawId に対する「前回取得時の本文」を返す。
   * 初回巡回時は undefined を返してよい (この場合 detector はスキップ判断)。
   */
  (lawId: string): Promise<
    | { effectiveDate: string; chunks: EgovLawTextChunk[]; hash: string }
    | undefined
  >;
}

export interface PersistLayer {
  /** 改正履歴台帳に append */
  appendLedger(entries: ChangeLedgerEntry[]): Promise<void>;
  /** RAG 取り込み JSONL に append */
  appendRag(entries: LegalUpdateRagEntry[]): Promise<void>;
  /** 前回取得本文の保存 */
  saveLawSnapshot(lawId: string, effectiveDate: string, chunks: EgovLawTextChunk[]): Promise<void>;
  /** PR draft Markdown の保存 */
  savePRDraft(draft: PullRequestDraft): Promise<void>;
  /**
   * 巡回結果レポートの保存 (任意実装・後方互換のため optional)。
   * 実装されていれば「何件を実際に取得できたか / どの法令を巡回できなかったか」を証跡として残す。
   */
  saveRunReport?(report: OrchestrateResult): Promise<void>;
}

/** 巡回できなかった法令の記録 (嘘の集計を残さないための明示記録) */
export interface UnpatrolledLawRecord {
  shortName: string;
  officialName: string;
  /** カタログ上の (仮) e-Gov 法令ID。未設定なら空文字 */
  catalogLawId: string;
  /** 改正監視の優先度 (1=毎週 / 2=月次 / 3=四半期 / 4=年次) */
  monitorPriority?: 1 | 2 | 3 | 4;
  /** 巡回できなかった理由 (日本語・具体的に) */
  reason: string;
}

/** 未確定 e-Gov 法令ID を実際に解決できた記録 (監査証跡) */
export interface ResolvedLawRecord {
  shortName: string;
  lawId: string;
  lawTitle: string;
  /** 解決方法: 'search' = 法令名検索 / 'catalog_id_verified' = カタログ仮IDを法令名照合で検証 */
  method: 'search' | 'catalog_id_verified';
}

/** カタログの法令名と e-Gov 実レスポンスの法令名が食い違った記録 (別の法令を監視してしまう事故の防止) */
export interface LawTitleMismatchRecord {
  shortName: string;
  lawId: string;
  expectedTitle: string;
  actualTitle: string;
}

export interface OrchestrateResult {
  startedAt: string;
  finishedAt: string;
  /** カタログ上の対象法令数 (巡回しようとした件数)。旧実装の totalChecked はこの値だった。 */
  targetCount: number;
  /**
   * ★実際に e-Gov から本文を取得できた法令数。
   * ID 未解決・取得失敗・法令名不一致は含めない (「45件巡回済」と偽らないための分離)。
   */
  totalChecked: number;
  /** 未確定 e-Gov 法令IDを今回の巡回で解決できた件数 */
  resolvedByLookup: number;
  /** 解決できた法令の内訳 (監査証跡) */
  resolvedLaws: ResolvedLawRecord[];
  /** ID 未解決等で 1 バイトも取得できなかった法令 (件数だけでなく法令名を明示) */
  unpatrolledLaws: UnpatrolledLawRecord[];
  /** カタログの法令名と e-Gov 実データの法令名が食い違った法令 (改正検知の対象から除外) */
  titleMismatches: LawTitleMismatchRecord[];
  changesDetected: number;
  ragAppended: number;
  prDrafts: PullRequestDraft[];
  impactAnalyses: ImpactAnalysis[];
  errors: Array<{ lawId: string; error: string }>;
  /**
   * 契約語彙に合わせた判定。
   * PASS = 対象全件を実取得 / PARTIAL = 一部のみ / unmeasurable = 1件も取得できなかった (通信不能等)
   */
  verdict: 'PASS' | 'PARTIAL' | 'unmeasurable';
  /** 日本語の一文サマリ (実測していないことを実測したと書かない) */
  detail_ja: string;
}

/** 法令名の表記ゆれを吸収して比較するための正規化 (空白・括弧書き・記号を除去) */
function normalizeLawTitle(title: string): string {
  return title
    .replace(/[（(][^）)]*[）)]/g, '')
    .replace(/[\s　・,，.。]/g, '')
    .trim();
}

/**
 * 括弧の**中身も**比較対象に含めた別表記を列挙する (完全一致比較専用)。
 *
 * ★2026-07-30 実測で判明した偽陽性 (課題台帳 Q-04):
 *   e-Gov は一部の法令で law_title を『昭和二十二年法律第五十四号（私的独占の禁止及び
 *   公正取引の確保に関する法律）』の形式で返す。normalizeLawTitle は括弧書きを丸ごと
 *   落とすため、カタログの正式名『私的独占の禁止及び公正取引の確保に関する法律』が
 *   一致しないと判定され、**IDは正しいのに「別法令を指している」と誤報**していた。
 *   ここで列挙する別表記は「完全一致」でのみ使い、包含判定には使わない
 *   (包含に使うと『（抄）』のような短い括弧書きで無関係な法令が一致してしまう)。
 */
function lawTitleExactVariants(title: string): string[] {
  const compact = (s: string) => s.replace(/[\s　・,，.。]/g, '').trim();
  const out: string[] = [];
  const push = (s: string) => {
    const v = compact(s);
    if (v && !out.includes(v)) out.push(v);
  };
  push(title.replace(/[（(][^）)]*[）)]/g, ''));      // 括弧書きを除去した形 (従来と同じ)
  push(title.replace(/[（()）]/g, ''));               // 括弧記号だけ外して中身を残した形
  const inner = title.match(/[（(][^）)]*[）)]/g) ?? [];
  for (const m of inner) push(m.replace(/[（()）]/g, '')); // 括弧の中身だけを取り出した形
  return out;
}

/** カタログの法令名と e-Gov 実データの法令名が同一法令とみなせるか (どちらかがどちらかを含めば一致とみなす) */
export function isSameLawTitle(expected: string, actual: string): boolean {
  const e = normalizeLawTitle(expected);
  const a = normalizeLawTitle(actual);
  // 従来判定 (この分岐の挙動は 1 バイトも変えない = 既存の一致が退行しない)
  if (e && a && (e === a || e.includes(a) || a.includes(e))) return true;
  // 追加判定: 括弧の中身を含む別表記どうしの**完全一致**のみを許す (緩めない)
  const ev = lawTitleExactVariants(expected);
  const av = lawTitleExactVariants(actual);
  for (const x of ev) {
    for (const y of av) {
      if (x === y) return true;
    }
  }
  return false;
}

export class SourceRegistry {
  constructor(private readonly clients: Partial<RegistryClients> = {}) {}

  getEgov(): EgovV2Client {
    return this.clients.egov ?? getDefaultEgovV2Client();
  }
  getKanpo(): KanpoClient {
    return this.clients.kanpo ?? getDefaultKanpoClient();
  }
  getPubComment(): PubCommentClient {
    return this.clients.pubcomment ?? getDefaultPubCommentClient();
  }

  /**
   * カタログ上 e-Gov 法令ID が未確定 (pendingLookup / 空) の法令について、
   * e-Gov 法令API v2 の法令名検索で実際の法令IDを解決する。
   *
   * ★カタログの仮ID (例 '335AC0000000145_pharma') から接尾辞を落とした値は
   *   別法令のIDと衝突している実例があるため、そのままでは使わない。
   *   e-Gov から返った法令名がカタログの法令名と一致した場合にのみ採用する。
   */
  async resolveEgovLawId(
    law: ExtendedLawCatalogEntry,
  ): Promise<{ ok: true; lawId: string; lawTitle: string; method: ResolvedLawRecord['method'] } | { ok: false; reason: string }> {
    const egov = this.getEgov();
    const queries = [law.officialName, law.shortName].filter((q): q is string => !!q);
    const searchErrors: string[] = [];

    for (const q of queries) {
      let found: EgovLawSummary[] = [];
      try {
        found = await egov.searchLaws(q);
      } catch (err) {
        searchErrors.push(`法令名検索「${q}」が失敗: ${err instanceof Error ? err.message : String(err)}`);
        continue;
      }
      const hit = found.find((r) => isSameLawTitle(law.officialName, r.lawTitle))
        ?? found.find((r) => isSameLawTitle(law.shortName, r.lawTitle));
      if (hit && hit.lawId) {
        return { ok: true, lawId: hit.lawId, lawTitle: hit.lawTitle, method: 'search' };
      }
      if (found.length > 0) {
        searchErrors.push(`法令名検索「${q}」は ${found.length} 件返したが法令名が一致しなかった`);
      } else {
        searchErrors.push(`法令名検索「${q}」の結果が 0 件`);
      }
    }

    // 次善策: カタログの仮ID から接尾辞を除いた候補を、法令名照合で検証してから採用する。
    const candidate = (law.egovLawId ?? '').split('_')[0];
    if (candidate) {
      try {
        const summary = await egov.fetchLawSummary(candidate);
        if (isSameLawTitle(law.officialName, summary.lawTitle) || isSameLawTitle(law.shortName, summary.lawTitle)) {
          return { ok: true, lawId: candidate, lawTitle: summary.lawTitle, method: 'catalog_id_verified' };
        }
        searchErrors.push(`カタログ仮ID ${candidate} は別法令「${summary.lawTitle}」を指しているため不採用`);
      } catch (err) {
        searchErrors.push(`カタログ仮ID ${candidate} の照会が失敗: ${err instanceof Error ? err.message : String(err)}`);
      }
    }

    return { ok: false, reason: searchErrors.join(' / ') || 'e-Gov 法令IDを特定できる情報が無い' };
  }

  /**
   * 週次巡回のメイン関数。
   *
   * @param prev 前回取得スナップショットの参照関数 (PersistLayer から呼ぶ)
   * @param persist 永続化レイヤー
   * @param opts target=top (週次=Priority1のみ) / all (月次=全件)
   *             resolvePendingIds=false で未確定IDの自動解決を止める (その場合は未巡回として正直に記録する)
   *             verifyLawTitle=false で法令名の照合を止める (既定は照合する)
   */
  async orchestrate(
    prev: PreviousVersionLookup,
    persist: PersistLayer,
    opts: { target: 'top' | 'all'; resolvePendingIds?: boolean; verifyLawTitle?: boolean } = { target: 'top' },
  ): Promise<OrchestrateResult> {
    const startedAt = new Date().toISOString();
    const targets = opts.target === 'top' ? getTopPriorityLaws() : EXTENDED_LAW_CATALOG;
    const resolvePending = opts.resolvePendingIds !== false;
    const verifyTitle = opts.verifyLawTitle !== false;
    const ledger: ChangeLedgerEntry[] = [];
    const allRag: LegalUpdateRagEntry[] = [];
    const prDrafts: PullRequestDraft[] = [];
    const impactAnalyses: ImpactAnalysis[] = [];
    const errors: Array<{ lawId: string; error: string }> = [];
    const unpatrolledLaws: UnpatrolledLawRecord[] = [];
    const resolvedLaws: ResolvedLawRecord[] = [];
    const titleMismatches: LawTitleMismatchRecord[] = [];
    let changesDetected = 0;
    let totalChecked = 0;

    const markUnpatrolled = (law: ExtendedLawCatalogEntry, reason: string) => {
      unpatrolledLaws.push({
        shortName: law.shortName,
        officialName: law.officialName,
        catalogLawId: law.egovLawId ?? '',
        monitorPriority: law.monitorPriority,
        reason,
      });
    };

    for (const law of targets) {
      // --- 1) e-Gov 法令ID の確定 (旧実装はここで黙って continue し「巡回済」に計上していた) ---
      let lawId = law.egovLawId ?? '';
      if (!lawId || law.pendingLookup) {
        if (!resolvePending) {
          markUnpatrolled(law, 'e-Gov 法令ID が未確定で、自動解決が無効化されているため巡回していない');
          continue;
        }
        const resolved = await this.resolveEgovLawId(law);
        if (!resolved.ok) {
          markUnpatrolled(law, `e-Gov 法令ID を解決できなかったため巡回していない (${resolved.reason})`);
          continue;
        }
        lawId = resolved.lawId;
        resolvedLaws.push({ shortName: law.shortName, lawId, lawTitle: resolved.lawTitle, method: resolved.method });
      }

      // --- 2) 実取得 ---
      try {
        const previous = await prev(lawId);
        // current 取得
        const summary = await this.getEgov().fetchLawSummary(lawId);

        // 取得した法令が本当にカタログの法令か照合する (別法令を「巡回済」と記録しないため)
        if (verifyTitle && summary.lawTitle && !isSameLawTitle(law.officialName, summary.lawTitle)
          && !isSameLawTitle(law.shortName, summary.lawTitle)) {
          titleMismatches.push({
            shortName: law.shortName,
            lawId,
            expectedTitle: law.officialName,
            actualTitle: summary.lawTitle,
          });
          markUnpatrolled(
            law,
            `e-Gov 法令ID ${lawId} が別法令「${summary.lawTitle}」を指しているため改正検知を行っていない (カタログのID誤りの疑い)`,
          );
          continue;
        }

        const currentChunks = await this.getEgov().fetchLawText(lawId);
        const currentEffective = summary.lastUpdateDate ?? summary.promulgationDate ?? law.lastEffectiveDate;
        // ここまで到達したものだけを「実際に取得できた」と数える
        totalChecked++;

        if (!previous) {
          // 初回: スナップショットを保存して終了 (次回から比較対象)
          await persist.saveLawSnapshot(lawId, currentEffective, currentChunks);
          continue;
        }

        const result = await detectChange({
          lawId,
          before: { effectiveDate: previous.effectiveDate, chunks: previous.chunks },
          after: { effectiveDate: currentEffective, chunks: currentChunks },
        });

        // 常に最新スナップショットを保存
        await persist.saveLawSnapshot(lawId, currentEffective, currentChunks);

        if (!result.hasChange || !result.diff) continue;
        changesDetected++;
        ledger.push(buildLedgerEntry(result));

        // 影響分析
        const impact = analyzeImpact(result.diff);
        impactAnalyses.push(impact);

        // RAG 取り込み
        const ragEntries = buildRagEntries({ diff: result.diff });
        allRag.push(...ragEntries);

        // PR ドラフト
        const draft = generatePRDraft({
          impact,
          effectiveDate: currentEffective,
          attributions: [EGOV_ATTRIBUTION],
        });
        prDrafts.push(draft);
        await persist.savePRDraft(draft);
      } catch (err) {
        const message = err instanceof Error ? err.message : String(err);
        errors.push({ lawId: lawId || law.shortName, error: message });
        markUnpatrolled(law, `取得に失敗したため巡回できていない (${message})`);
      }
    }

    if (ledger.length > 0) await persist.appendLedger(ledger);
    if (allRag.length > 0) await persist.appendRag(allRag);

    const verdict: OrchestrateResult['verdict'] =
      totalChecked === targets.length ? 'PASS' : totalChecked === 0 ? 'unmeasurable' : 'PARTIAL';
    const unpatrolledNames = unpatrolledLaws.map((u) => u.shortName);
    const detail_ja =
      verdict === 'PASS'
        ? `対象 ${targets.length} 件すべてを e-Gov から実取得し、改正 ${changesDetected} 件を検知しました。`
        : verdict === 'unmeasurable'
          ? `対象 ${targets.length} 件のうち 1 件も e-Gov から取得できませんでした (未巡回: ${unpatrolledNames.join('、') || '不明'})。改正の有無は判定できていません。`
          : `対象 ${targets.length} 件のうち実取得は ${totalChecked} 件です。未巡回 ${unpatrolledLaws.length} 件 (${unpatrolledNames.join('、')}) の改正は検知できていません。`;

    const result: OrchestrateResult = {
      startedAt,
      finishedAt: new Date().toISOString(),
      targetCount: targets.length,
      totalChecked,
      resolvedByLookup: resolvedLaws.length,
      resolvedLaws,
      unpatrolledLaws,
      titleMismatches,
      changesDetected,
      ragAppended: allRag.length,
      prDrafts,
      impactAnalyses,
      errors,
      verdict,
      detail_ja,
    };

    if (typeof persist.saveRunReport === 'function') {
      try {
        await persist.saveRunReport(result);
      } catch {
        // レポート保存の失敗で巡回結果自体を失わない (握り潰しはここだけ・結果は返る)
      }
    }

    return result;
  }

  /** 出典一覧 */
  getAllAttributions() {
    return [EGOV_ATTRIBUTION, KANPO_ATTRIBUTION, PUBCOMMENT_ATTRIBUTION];
  }
}

/**
 * デフォルトのファイルシステム永続化レイヤー (Node 環境)。
 * Browser ではこのエクスポートを使わず、自前で PersistLayer を実装すること。
 */
export async function createNodePersistLayer(baseDir: string): Promise<PersistLayer> {
  const { mkdir, appendFile, writeFile, readFile } = await import('node:fs/promises');
  const path = await import('node:path');

  const updatesDir = path.join(baseDir, 'legal_updates');
  const snapshotDir = path.join(updatesDir, 'snapshots');
  const prDir = path.join(updatesDir, 'pr_drafts');
  const reportDir = path.join(updatesDir, 'run_reports');
  await mkdir(snapshotDir, { recursive: true });
  await mkdir(prDir, { recursive: true });
  await mkdir(reportDir, { recursive: true });

  const ledgerPath = path.join(updatesDir, 'ledger.jsonl');
  const ragPath = path.join(updatesDir, 'rag.jsonl');

  return {
    async appendLedger(entries) {
      if (entries.length === 0) return;
      await appendFile(ledgerPath, serializeLedgerEntries(entries), 'utf8');
    },
    async appendRag(entries) {
      if (entries.length === 0) return;
      await appendFile(ragPath, serializeRagEntriesToJsonl(entries), 'utf8');
    },
    async saveLawSnapshot(lawId, effectiveDate, chunks) {
      const safeLawId = lawId.replace(/[^A-Za-z0-9_-]/g, '_');
      const file = path.join(snapshotDir, `${safeLawId}.json`);
      const payload = {
        lawId,
        effectiveDate,
        chunks,
        savedAt: new Date().toISOString(),
      };
      await writeFile(file, JSON.stringify(payload, null, 2), 'utf8');
    },
    async savePRDraft(draft) {
      const file = path.join(prDir, `${draft.branchName.replace(/\//g, '__')}.md`);
      await writeFile(file, draft.prBody, 'utf8');
    },
    async saveRunReport(report) {
      // 「何件を実際に取得できたか / どの法令を巡回できなかったか」を証跡として残す
      const stamp = report.finishedAt.replace(/[:.]/g, '-');
      const file = path.join(reportDir, `run_${stamp}.json`);
      await writeFile(file, JSON.stringify(report, null, 2), 'utf8');
    },
  };
}

/** 前回スナップショット参照関数のファイルシステム実装 */
export async function createNodePreviousVersionLookup(baseDir: string): Promise<PreviousVersionLookup> {
  const { readFile } = await import('node:fs/promises');
  const path = await import('node:path');
  const snapshotDir = path.join(baseDir, 'legal_updates', 'snapshots');

  return async (lawId: string) => {
    const safeLawId = lawId.replace(/[^A-Za-z0-9_-]/g, '_');
    const file = path.join(snapshotDir, `${safeLawId}.json`);
    try {
      const text = await readFile(file, 'utf8');
      const data = JSON.parse(text) as {
        lawId: string;
        effectiveDate: string;
        chunks: EgovLawTextChunk[];
      };
      return {
        effectiveDate: data.effectiveDate,
        chunks: data.chunks,
        hash: '', // 必要なら detect 内で再計算
      };
    } catch {
      return undefined;
    }
  };
}
