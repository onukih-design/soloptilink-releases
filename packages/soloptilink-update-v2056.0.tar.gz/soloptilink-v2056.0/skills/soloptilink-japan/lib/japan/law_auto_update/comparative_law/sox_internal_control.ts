/**
 * Phase 46-LU-4 / SOX + 内部統制 (米国上場企業向け)
 *
 * Sarbanes-Oxley Act 2002 + PCAOB AS-5 + COSO ERM 2017
 * J-SOX (金商法24条の4の4) との比較も内包。
 */

export interface SoxRule {
  section: string;
  title: string;
  summary: string;
  scope: 'PCAOB' | 'SEC' | 'Both';
  jp_counterpart?: string;
}

export const SOX_KEY_SECTIONS: SoxRule[] = [
  {
    section: 'SOX 302',
    title: 'Corporate Responsibility for Financial Reports',
    summary: 'CEO/CFOは四半期/年次報告書の正確性を証明 (虚偽の場合 個人責任)',
    scope: 'SEC',
    jp_counterpart: '金商法 第24条の4の2 (確認書)',
  },
  {
    section: 'SOX 404(a)',
    title: 'Management Assessment of Internal Controls',
    summary: '経営者は財務報告に係る内部統制の有効性を年次評価し、評価結果を年次報告書に記載',
    scope: 'SEC',
    jp_counterpart: '金商法 第24条の4の4 (J-SOX 内部統制報告)',
  },
  {
    section: 'SOX 404(b)',
    title: 'Auditor Attestation of Internal Controls',
    summary: '監査人は経営者の内部統制評価を監査 (大規模会計事務所のみ)',
    scope: 'PCAOB',
    jp_counterpart: '金商法 第193条の2 (内部統制監査)',
  },
  {
    section: 'SOX 906',
    title: 'Criminal Penalties for CEO/CFO Certifications',
    summary: '故意に虚偽の証明をした CEO/CFO は最大20年禁錮+500万USD罰金',
    scope: 'SEC',
  },
  {
    section: 'SOX 802',
    title: 'Criminal Penalties for Altering Documents',
    summary: '監査関連文書の改変は最大20年禁錮 / 5年文書保存義務 (会計事務所)',
    scope: 'PCAOB',
    jp_counterpart: '金商法 第197条 (虚偽記載)',
  },
  {
    section: 'SOX 301',
    title: 'Audit Committee',
    summary: '監査委員会は全員独立社外取締役 + 1名以上のfinancial expert',
    scope: 'SEC',
    jp_counterpart: '会社法 第400条 (監査等委員会設置会社)',
  },
  {
    section: 'SOX 402',
    title: 'Loans to Executives',
    summary: '取締役・執行役員への会社による貸付を原則禁止',
    scope: 'SEC',
    jp_counterpart: '会社法 第356条 (利益相反取引)',
  },
];

export const COSO_ERM_2017_COMPONENTS = [
  { id: 1, name: 'Governance and Culture', summary: 'ガバナンスとカルチャー' },
  { id: 2, name: 'Strategy and Objective-Setting', summary: '戦略と目標設定' },
  { id: 3, name: 'Performance', summary: 'パフォーマンス (リスク識別/評価/対応)' },
  { id: 4, name: 'Review and Revision', summary: 'レビューと改訂' },
  { id: 5, name: 'Information, Communication, and Reporting', summary: '情報・伝達・報告' },
];

export const COSO_IC_2013_PRINCIPLES = [
  { id: 1, component: 'Control Environment', summary: '誠実性と倫理観の表明' },
  { id: 5, component: 'Control Environment', summary: 'コミットメント' },
  { id: 6, component: 'Risk Assessment', summary: '目標の特定' },
  { id: 7, component: 'Risk Assessment', summary: 'リスクの識別と分析' },
  { id: 10, component: 'Control Activities', summary: '統制活動の選択と整備' },
  { id: 11, component: 'Control Activities', summary: '技術にわたる統制' },
  { id: 13, component: 'Information & Communication', summary: '関連情報の使用' },
  { id: 16, component: 'Monitoring Activities', summary: 'モニタリング活動' },
  { id: 17, component: 'Monitoring Activities', summary: '不備の評価と伝達' },
];

export function findSoxSection(section: string): SoxRule | undefined {
  return SOX_KEY_SECTIONS.find((s) => s.section === section);
}

export function getJpCounterpart(soxSection: string): string | undefined {
  return findSoxSection(soxSection)?.jp_counterpart;
}

/**
 * SOX 適用判定 (米国上場企業, ADR L2/L3, 米国子会社)
 */
export function isSoxApplicable(input: {
  is_us_listed: boolean;
  has_adr_l2_or_l3?: boolean;
  parent_is_us_listed?: boolean;
  /** その他: PCAOB登録監査人を起用しているか */
  pcaob_registered_auditor?: boolean;
}): { applicable: boolean; level: 'full' | 'limited' | 'none'; reason: string } {
  if (input.is_us_listed || input.has_adr_l2_or_l3) {
    return { applicable: true, level: 'full', reason: '米国上場 / ADR L2-L3' };
  }
  if (input.parent_is_us_listed) {
    return { applicable: true, level: 'limited', reason: '親会社が米国上場 (子会社統制テスト対象)' };
  }
  return { applicable: false, level: 'none', reason: 'SOX 直接適用なし (J-SOX の適用余地は別途検討)' };
}

export function countSoxRules(): { total: number; principles: number; erm_components: number } {
  return {
    total: SOX_KEY_SECTIONS.length,
    principles: COSO_IC_2013_PRINCIPLES.length,
    erm_components: COSO_ERM_2017_COMPONENTS.length,
  };
}
