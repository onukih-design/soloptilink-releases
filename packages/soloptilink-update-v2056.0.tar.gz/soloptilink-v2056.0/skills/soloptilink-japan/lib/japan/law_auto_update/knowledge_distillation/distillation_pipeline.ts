/**
 * Phase 46-LU-7 / Knowledge Distillation Pipeline
 *
 * 顧客の検索クエリ・QA 履歴から「よく聞かれる質問」を自動抽出し、
 * FAQ + ナレッジベース + プロンプト改善データセットへ蒸留する。
 *
 *  - クエリクラスタリング (簡易 TF-IDF + cosine 類似度)
 *  - 頻出問い合わせ → FAQ 候補
 *  - 低信頼度回答 → 改善対象 (要・専門家レビュー)
 *  - 自社規程の自動学習 (Tenant DNA と連携)
 */

export interface QueryRecord {
  query_id: string;
  tenant_id: string;
  user_id: string;
  query: string;
  /** 回答信頼度 0-100 */
  answer_confidence: number;
  /** 回答後のフィードバック (👍/👎) */
  feedback?: 'positive' | 'negative' | 'none';
  /** 関連法令 */
  related_laws?: string[];
  timestamp: string;
}

const QUERY_STORE: QueryRecord[] = [];

export function recordQuery(input: Omit<QueryRecord, 'query_id' | 'timestamp'>): QueryRecord {
  const q: QueryRecord = {
    query_id: `q_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    timestamp: new Date().toISOString(),
    ...input,
  };
  QUERY_STORE.push(q);
  return q;
}

/**
 * 単純な TF-IDF + Jaccard で類似クエリをクラスタリング
 */
export interface QueryCluster {
  cluster_id: string;
  representative_query: string;
  member_query_ids: string[];
  member_count: number;
  avg_confidence: number;
  positive_feedback_rate: number;
  negative_feedback_rate: number;
  related_laws_top3: string[];
}

function tokenize(s: string): Set<string> {
  const set = new Set<string>();
  const normalized = s.replace(/[\s　。、・「」（）()]/g, '').toLowerCase();
  for (let i = 0; i < normalized.length - 1; i++) {
    set.add(normalized.substring(i, i + 2));
  }
  return set;
}

function jaccard(a: Set<string>, b: Set<string>): number {
  let inter = 0;
  for (const x of a) if (b.has(x)) inter++;
  return inter / (a.size + b.size - inter);
}

export function clusterQueries(threshold = 0.45): QueryCluster[] {
  const tokens = QUERY_STORE.map((q) => ({ q, tokens: tokenize(q.query) }));
  const visited = new Set<string>();
  const clusters: QueryCluster[] = [];

  for (let i = 0; i < tokens.length; i++) {
    if (visited.has(tokens[i].q.query_id)) continue;
    const members: QueryRecord[] = [tokens[i].q];
    visited.add(tokens[i].q.query_id);
    for (let j = i + 1; j < tokens.length; j++) {
      if (visited.has(tokens[j].q.query_id)) continue;
      if (jaccard(tokens[i].tokens, tokens[j].tokens) >= threshold) {
        members.push(tokens[j].q);
        visited.add(tokens[j].q.query_id);
      }
    }
    if (members.length === 0) continue;
    const avgConf = members.reduce((acc, m) => acc + m.answer_confidence, 0) / members.length;
    const pos = members.filter((m) => m.feedback === 'positive').length;
    const neg = members.filter((m) => m.feedback === 'negative').length;
    const lawCount: Record<string, number> = {};
    for (const m of members) {
      for (const l of m.related_laws ?? []) lawCount[l] = (lawCount[l] ?? 0) + 1;
    }
    const topLaws = Object.entries(lawCount).sort((a, b) => b[1] - a[1]).slice(0, 3).map(([l]) => l);
    clusters.push({
      cluster_id: `cluster_${clusters.length + 1}`,
      representative_query: tokens[i].q.query,
      member_query_ids: members.map((m) => m.query_id),
      member_count: members.length,
      avg_confidence: Math.round(avgConf * 10) / 10,
      positive_feedback_rate: Math.round((pos / members.length) * 1000) / 10,
      negative_feedback_rate: Math.round((neg / members.length) * 1000) / 10,
      related_laws_top3: topLaws,
    });
  }
  return clusters.sort((a, b) => b.member_count - a.member_count);
}

/**
 * FAQ 候補生成 (member_count >=5 + positive >= 70%)
 */
export interface FaqCandidate {
  rank: number;
  question: string;
  estimated_frequency_per_month: number;
  confidence: number;
  recommend_for_publish: boolean;
  related_laws: string[];
  rationale: string;
}

export function generateFaqCandidates(min_members = 5): FaqCandidate[] {
  const clusters = clusterQueries();
  const out: FaqCandidate[] = [];
  let rank = 1;
  for (const c of clusters) {
    if (c.member_count < min_members) continue;
    const recommend = c.positive_feedback_rate >= 70 && c.avg_confidence >= 70;
    out.push({
      rank: rank++,
      question: c.representative_query,
      estimated_frequency_per_month: c.member_count * 4, // クラスタ件数を月次換算 (概算)
      confidence: c.avg_confidence,
      recommend_for_publish: recommend,
      related_laws: c.related_laws_top3,
      rationale: recommend
        ? `頻出 (member=${c.member_count}) + 高評価 (positive=${c.positive_feedback_rate}%)`
        : `要レビュー (confidence=${c.avg_confidence} / negative=${c.negative_feedback_rate}%)`,
    });
  }
  return out;
}

/**
 * 低信頼度回答 → 改善対象 (専門家レビュー必要)
 */
export interface LowConfidenceItem {
  query_id: string;
  query: string;
  confidence: number;
  feedback: string;
  suggestion: string;
}

export function findImprovementTargets(): LowConfidenceItem[] {
  return QUERY_STORE
    .filter((q) => q.answer_confidence < 50 || q.feedback === 'negative')
    .map((q) => ({
      query_id: q.query_id,
      query: q.query,
      confidence: q.answer_confidence,
      feedback: q.feedback ?? 'none',
      suggestion:
        q.answer_confidence < 50
          ? '関連法令データの追加 + RAG索引拡張を検討'
          : '回答テンプレ改善 + 専門家レビューに回す',
    }))
    .sort((a, b) => a.confidence - b.confidence)
    .slice(0, 50);
}

/**
 * LLM ファインチューニング用データセット生成
 */
export interface DistillationDataset {
  format: 'jsonl' | 'parquet' | 'csv';
  records: Array<{ instruction: string; input?: string; output: string; metadata: Record<string, unknown> }>;
  count: number;
  estimated_tokens: number;
}

export function buildDistillationDataset(input: { only_positive?: boolean; min_confidence?: number }): DistillationDataset {
  const targets = QUERY_STORE.filter((q) => {
    if (input.only_positive && q.feedback !== 'positive') return false;
    if (input.min_confidence && q.answer_confidence < input.min_confidence) return false;
    return true;
  });
  const records = targets.map((q) => ({
    instruction: '以下の法務質問に、根拠条文と判例を付けて回答してください。',
    input: q.query,
    output: `(高信頼度回答 confidence=${q.answer_confidence})`,
    metadata: {
      query_id: q.query_id,
      related_laws: q.related_laws,
      tenant_id: q.tenant_id,
    },
  }));
  const estimatedTokens = records.reduce((acc, r) => acc + (r.instruction.length + (r.input?.length ?? 0) + r.output.length), 0) / 3;
  return {
    format: 'jsonl',
    records,
    count: records.length,
    estimated_tokens: Math.round(estimatedTokens),
  };
}

export function countQueries(): { total: number; by_tenant: Record<string, number>; positive_pct: number } {
  const byTenant: Record<string, number> = {};
  let pos = 0;
  for (const q of QUERY_STORE) {
    byTenant[q.tenant_id] = (byTenant[q.tenant_id] ?? 0) + 1;
    if (q.feedback === 'positive') pos++;
  }
  return {
    total: QUERY_STORE.length,
    by_tenant: byTenant,
    positive_pct: QUERY_STORE.length > 0 ? Math.round((pos / QUERY_STORE.length) * 1000) / 10 : 0,
  };
}

export function _resetDistillationForTests(): void {
  QUERY_STORE.length = 0;
}
