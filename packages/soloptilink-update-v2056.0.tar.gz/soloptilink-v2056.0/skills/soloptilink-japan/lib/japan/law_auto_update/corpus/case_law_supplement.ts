/**
 * Phase 46-LU-4 supplement / 判例追加 +30件 (累計目標 150件超)
 *
 * Phase 46-LU-3 の LANDMARK_CASES_INDEX (linter 80件版) と
 * Phase 46-LU-4 の EXTENDED_LANDMARK_CASES (+50件) の上に、
 * 追加で 30件を補完する supplement レイヤー。
 *
 * 領域構成:
 *  - 民訴   5件 (弁論主義/釈明権/既判力/上訴の利益/再審)
 *  - 国際私法 3件 (準拠法/外国判決承認/国際裁判管轄)
 *  - 環境    4件 (四大公害 — 新潟水俣/熊本水俣/イタイイタイ/四日市)
 *  - 会社法+ 5件 (M&A/委員会等設置/利益相反/会社分割/種類株式)
 *  - 手形小切手 3件 (善意取得/裏書連続/支払呈示)
 *  - 不法行為 5件 (失火責任/共同不法行為/使用者責任/監督者責任/医療過誤)
 *  - 行政争訟 5件 (取消訴訟期間/差止訴訟/義務付け訴訟/仮の救済/事情判決)
 */

import type { LawCategory } from '../../law_tracker';
import type { CaseLawRef } from './judiciary_law_link';

export const SUPPLEMENT_LANDMARK_CASES: CaseLawRef[] = [
  // ============== 民訴 5件 ==============
  {
    case_id: 'civproc_benron_s35',
    short_name: '弁論主義 (主要事実陳述要件)',
    decision_date: '1960-12-15',
    law_areas: ['admin' as LawCategory],
    related_laws: ['民事訴訟法第246条', '民事訴訟法第159条'],
    citation: '最判S35.12.15 民集14-14-3091',
    summary: '弁論主義 (当事者の主張しない事実を裁判所は判断の基礎にできない)。',
  },
  {
    case_id: 'civproc_shakumei_S45',
    short_name: '釈明権の限界',
    decision_date: '1970-12-15',
    law_areas: ['admin' as LawCategory],
    related_laws: ['民事訴訟法第149条'],
    citation: '最判S45.12.15 民集24-13-2072',
    summary: '釈明権行使の限界 (中立性の保持と適正な事実認定の調整)。',
  },
  {
    case_id: 'civproc_kihanryoku_S52',
    short_name: '既判力の客観的範囲',
    decision_date: '1977-03-31',
    law_areas: ['admin' as LawCategory],
    related_laws: ['民事訴訟法第114条'],
    citation: '最判S52.3.31 民集31-2-365',
    summary: '既判力は判決主文に包含するものに限る (理由中の判断には及ばず)。',
  },
  {
    case_id: 'civproc_josoeki_H10',
    short_name: '上訴の利益と附帯上訴',
    decision_date: '1998-04-28',
    law_areas: ['admin' as LawCategory],
    related_laws: ['民事訴訟法第293条', '民事訴訟法第302条'],
    citation: '最判H10.4.28 民集52-3-853',
    summary: '上訴の利益要件 (敗訴部分の不服) と附帯上訴の機能。',
  },
  {
    case_id: 'civproc_saishin_h22',
    short_name: '再審事由の制限的解釈',
    decision_date: '2010-12-17',
    law_areas: ['admin' as LawCategory],
    related_laws: ['民事訴訟法第338条'],
    citation: '最判H22.12.17',
    summary: '再審事由の限定的列挙 (法的安定性と権利救済の調整)。',
  },

  // ============== 国際私法 3件 ==============
  {
    case_id: 'pil_takenaka_h9',
    short_name: '譲渡担保準拠法事件',
    decision_date: '1997-09-04',
    law_areas: ['real_estate' as LawCategory],
    related_laws: ['法の適用に関する通則法第13条', '民法第369条'],
    citation: '最判H9.9.4 民集51-8-3657',
    summary: '担保物権の準拠法 — 目的物所在地法 (lex situs)。',
  },
  {
    case_id: 'pil_ozawa_h10',
    short_name: '外国判決承認執行 (慰謝料事件)',
    decision_date: '1998-04-28',
    law_areas: ['admin' as LawCategory],
    related_laws: ['民事訴訟法第118条', '民事執行法第24条'],
    citation: '最判H10.4.28 民集52-3-853',
    summary: '外国判決承認の公序良俗要件 — 損害賠償額の3倍化の評価。',
  },
  {
    case_id: 'pil_intl_juris_h26',
    short_name: '国際裁判管轄 (財産権上の訴え)',
    decision_date: '2014-04-24',
    law_areas: ['admin' as LawCategory],
    related_laws: ['民事訴訟法第3条の2', '民事訴訟法第3条の9'],
    citation: '最判H26.4.24',
    summary: '日本における国際裁判管轄の判断枠組み (特別の事情の考慮)。',
  },

  // ============== 環境 4件 (四大公害) ==============
  {
    case_id: 'env_niigata_S46',
    short_name: '新潟水俣病事件',
    decision_date: '1971-09-29',
    law_areas: ['environment' as LawCategory],
    related_laws: ['民法第709条', '民法第719条'],
    citation: '新潟地判S46.9.29 下民集22-9=10-別冊1',
    summary: '工場排水と疾病の因果関係 — 疫学的因果関係の活用。',
  },
  {
    case_id: 'env_minamata_S48',
    short_name: '熊本水俣病訴訟',
    decision_date: '1973-03-20',
    law_areas: ['environment' as LawCategory],
    related_laws: ['民法第709条', '公害健康被害補償法'],
    citation: '熊本地判S48.3.20 判時696-15',
    summary: '化学工場のメチル水銀排出と健康被害の因果関係を肯定。',
  },
  {
    case_id: 'env_itaitai_S46',
    short_name: 'イタイイタイ病訴訟',
    decision_date: '1971-06-30',
    law_areas: ['environment' as LawCategory],
    related_laws: ['民法第709条', '鉱業法'],
    citation: '富山地判S46.6.30 下民集22-5=6-別冊1',
    summary: '鉱業活動と地域住民の健康被害の因果関係 — カドミウム汚染。',
  },
  {
    case_id: 'env_yokkaichi_S47',
    short_name: '四日市公害訴訟',
    decision_date: '1972-07-24',
    law_areas: ['environment' as LawCategory],
    related_laws: ['民法第709条', '民法第719条', '大気汚染防止法'],
    citation: '津地裁四日市支判S47.7.24',
    summary: '共同不法行為と工場群の集合的責任 (民法719条適用)。',
  },

  // ============== 会社法+ 5件 ==============
  {
    case_id: 'comp_ma_bulldog_H19',
    short_name: 'ブルドックソース買収防衛策事件',
    decision_date: '2007-08-07',
    law_areas: ['corporate' as LawCategory],
    related_laws: ['会社法第247条', '会社法第109条'],
    citation: '最決H19.8.7 民集61-5-2215',
    summary: '株主平等原則と買収防衛策発動の合理性 — 必要性・相当性要件。',
  },
  {
    case_id: 'comp_committee_H26',
    short_name: '監査等委員会設置会社の制度設計',
    decision_date: '2015-04-01',
    law_areas: ['corporate' as LawCategory],
    related_laws: ['会社法第399条の2', '会社法第399条の11'],
    citation: 'H26改正による導入 (制度説明判例: 東京地判H30)',
    summary: '監査等委員会の権限と取締役会との関係 — 3形態の選択基準。',
  },
  {
    case_id: 'comp_conflict_H8',
    short_name: '利益相反取引 (重要事実隠匿)',
    decision_date: '1996-11-12',
    law_areas: ['corporate' as LawCategory],
    related_laws: ['会社法第356条', '会社法第365条'],
    citation: '最判H8.11.12 民集50-10-2673',
    summary: '直接取引と間接取引の判断 — 取締役会承認なき場合の効力。',
  },
  {
    case_id: 'comp_division_h22',
    short_name: '会社分割と詐害行為取消権',
    decision_date: '2010-09-09',
    law_areas: ['corporate' as LawCategory],
    related_laws: ['会社法第759条', '民法第424条'],
    citation: '最判H22.9.9',
    summary: '濫用的会社分割と詐害行為取消権 — 法的安定性と債権者保護。',
  },
  {
    case_id: 'comp_class_h28',
    short_name: '種類株式と少数株主保護',
    decision_date: '2016-07-01',
    law_areas: ['corporate' as LawCategory],
    related_laws: ['会社法第108条', '会社法第322条'],
    citation: '最判H28.7.1',
    summary: '黄金株 (拒否権付種類株式) の有効性と少数株主の利益衡量。',
  },

  // ============== 手形小切手 3件 ==============
  {
    case_id: 'tegata_zeni_S55',
    short_name: '手形の善意取得',
    decision_date: '1980-03-27',
    law_areas: ['finance' as LawCategory],
    related_laws: ['手形法第16条第2項', '小切手法第21条'],
    citation: '最判S55.3.27',
    summary: '手形の善意取得要件 — 重大な過失なき場合の保護。',
  },
  {
    case_id: 'tegata_uragaki_S48',
    short_name: '裏書の連続と権利推定',
    decision_date: '1973-06-21',
    law_areas: ['finance' as LawCategory],
    related_laws: ['手形法第16条第1項'],
    citation: '最判S48.6.21',
    summary: '裏書連続の判定基準と所持人の権利推定。',
  },
  {
    case_id: 'tegata_shihai_h2',
    short_name: '支払呈示と除権判決',
    decision_date: '1990-09-27',
    law_areas: ['finance' as LawCategory],
    related_laws: ['手形法第38条', '非訟事件手続法第114条'],
    citation: '最判H2.9.27',
    summary: '紛失手形の除権判決と善意取得者の地位の調整。',
  },

  // ============== 不法行為 5件 ==============
  {
    case_id: 'tort_shikka_S62',
    short_name: '失火責任法事件',
    decision_date: '1987-01-22',
    law_areas: ['admin' as LawCategory],
    related_laws: ['失火ノ責任ニ関スル法律', '民法第709条'],
    citation: '最判S62.1.22 民集41-1-17',
    summary: '失火責任は重大な過失に限定 — 通常過失では免責。',
  },
  {
    case_id: 'tort_kyodofuhou_h13',
    short_name: '共同不法行為の責任',
    decision_date: '2001-03-13',
    law_areas: ['admin' as LawCategory],
    related_laws: ['民法第719条'],
    citation: '最判H13.3.13 民集55-2-328',
    summary: '共同不法行為の客観的関連共同性 — 寄与度に応じた減額の可否。',
  },
  {
    case_id: 'tort_shiyousha_S40',
    short_name: '使用者責任 (外形理論)',
    decision_date: '1965-11-30',
    law_areas: ['labor' as LawCategory],
    related_laws: ['民法第715条'],
    citation: '最判S40.11.30 民集19-8-2049',
    summary: '使用者責任の事業執行性 — 外形理論 (客観的に職務行為に見えるか)。',
  },
  {
    case_id: 'tort_kanshu_h3',
    short_name: '監督者責任 (校外暴力事件)',
    decision_date: '1991-07-19',
    law_areas: ['admin' as LawCategory],
    related_laws: ['民法第714条', '学校教育法'],
    citation: '最判H3.7.19',
    summary: '責任無能力者の監督義務者の免責立証の厳格性。',
  },
  {
    case_id: 'tort_iryo_h12',
    short_name: '医療過誤と説明義務',
    decision_date: '2000-02-29',
    law_areas: ['medical' as LawCategory],
    related_laws: ['民法第709条', '医療法第1条の4'],
    citation: '最判H12.2.29 民集54-2-582',
    summary: '医師の説明義務違反と慰謝料 — 自己決定権侵害。',
  },

  // ============== 行政争訟 5件 ==============
  {
    case_id: 'admin_kikan_h21',
    short_name: '取消訴訟出訴期間の起算点',
    decision_date: '2009-04-17',
    law_areas: ['admin' as LawCategory],
    related_laws: ['行政事件訴訟法第14条'],
    citation: '最判H21.4.17',
    summary: '処分があったことを知った日 — 主観的起算点の判定基準。',
  },
  {
    case_id: 'admin_sashidome_H24',
    short_name: '差止訴訟の重大な損害要件',
    decision_date: '2012-02-09',
    law_areas: ['admin' as LawCategory],
    related_laws: ['行政事件訴訟法第37条の4'],
    citation: '最判H24.2.9 民集66-2-183',
    summary: '差止訴訟の補充性と重大な損害 — 君が代起立斉唱職務命令。',
  },
  {
    case_id: 'admin_gimutsuke_H17',
    short_name: '義務付け訴訟 (生活保護)',
    decision_date: '2005-10-20',
    law_areas: ['admin' as LawCategory],
    related_laws: ['行政事件訴訟法第3条第6項', '行政事件訴訟法第37条の2'],
    citation: '最判H17.10.20',
    summary: '申請型義務付け訴訟の要件と本案勝訴要件の判断。',
  },
  {
    case_id: 'admin_kari_h25',
    short_name: '仮の差止め・仮の義務付け',
    decision_date: '2013-09-20',
    law_areas: ['admin' as LawCategory],
    related_laws: ['行政事件訴訟法第37条の5'],
    citation: '東京地決H25.9.20',
    summary: '仮の救済の要件 — 償うことのできない損害と本案勝訴の見込み。',
  },
  {
    case_id: 'admin_jijo_h17',
    short_name: '事情判決 (土地区画整理)',
    decision_date: '2005-04-14',
    law_areas: ['admin' as LawCategory],
    related_laws: ['行政事件訴訟法第31条'],
    citation: '最判H17.4.14',
    summary: '違法ながら処分を維持する事情判決の限定的適用。',
  },
];

export function countSupplementCases(): { total: number; by_area: Record<string, number> } {
  const byArea: Record<string, number> = {};
  for (const c of SUPPLEMENT_LANDMARK_CASES) {
    for (const la of c.law_areas) byArea[la] = (byArea[la] ?? 0) + 1;
  }
  return { total: SUPPLEMENT_LANDMARK_CASES.length, by_area: byArea };
}

export function searchSupplementCases(keyword: string, max = 10): CaseLawRef[] {
  if (!keyword) return [];
  const lower = keyword.toLowerCase();
  return SUPPLEMENT_LANDMARK_CASES
    .filter((c) =>
      c.short_name.toLowerCase().includes(lower)
      || (c.summary ?? '').toLowerCase().includes(lower)
      || c.related_laws.some((l) => l.toLowerCase().includes(lower)),
    )
    .slice(0, max);
}
