/**
 * Phase 46-LU-5 / Legal Risk Scoring
 *
 * 取引・契約・新規事業について、法令適合性・損害賠償リスクを
 * 多次元スコアリングする。
 *
 *  - リスク次元: regulatory / civil_liability / criminal / reputation / cross_border
 *  - 業種別係数: 医療/金融/公共/IT 等で重み付け
 *  - 過去判例の損害賠償ベンチマークを参照
 *  - 各次元 0-100、加重平均で総合スコア
 */

import type { LawCategory } from '../../law_tracker';

export type RiskDimension =
  | 'regulatory' // 規制違反 (行政処分・営業停止)
  | 'civil_liability' // 民事責任 (損害賠償)
  | 'criminal' // 刑事責任
  | 'reputation' // レピュテーション
  | 'cross_border'; // 越境規制 (GDPR/CCPA/SOX等)

export interface RiskInput {
  /** 取引/事業の説明 */
  scenario: string;
  /** 業種 */
  industry: string;
  /** 顧客タイプ (BtoB / BtoC / BtoGov) */
  customer_type?: 'btob' | 'btoc' | 'btogov';
  /** 国際性 */
  international?: boolean;
  /** 個人情報取扱量 (件数) */
  pii_volume?: number;
  /** 想定取引金額 (円) */
  transaction_amount_jpy?: number;
  /** 対象法令カテゴリ (検出済) */
  triggered_categories?: LawCategory[];
}

export interface DimensionScore {
  dimension: RiskDimension;
  score: number;
  reasoning: string[];
  related_laws: string[];
}

export interface RiskAssessment {
  scenario: string;
  industry: string;
  generated_at: string;
  dimensions: DimensionScore[];
  /** 0-100 加重平均 */
  overall_score: number;
  level: 'low' | 'medium' | 'high' | 'critical';
  recommendations: string[];
  /** 想定損害賠償額 (中央値) */
  estimated_damage_jpy?: number;
}

const INDUSTRY_RISK_COEFF: Record<string, Partial<Record<RiskDimension, number>>> = {
  '医療': { regulatory: 1.6, criminal: 1.4, civil_liability: 1.3, reputation: 1.4 },
  '介護': { regulatory: 1.4, civil_liability: 1.3 },
  '金融': { regulatory: 1.5, civil_liability: 1.3, criminal: 1.3, cross_border: 1.4 },
  '公共': { regulatory: 1.7, criminal: 1.5, reputation: 1.6 },
  'IT': { regulatory: 1.0, civil_liability: 1.1, cross_border: 1.4 },
  '建設': { regulatory: 1.3, civil_liability: 1.2, criminal: 1.1 },
  '不動産': { regulatory: 1.4, civil_liability: 1.3 },
  '小売': { regulatory: 1.0, civil_liability: 1.0 },
  '飲食': { regulatory: 1.2, civil_liability: 1.0, reputation: 1.2 },
  '物流': { regulatory: 1.1, civil_liability: 1.1 },
  '観光': { regulatory: 1.1, civil_liability: 1.0 },
  '教育': { regulatory: 1.2, reputation: 1.3 },
  '士業': { regulatory: 1.3, reputation: 1.5, criminal: 1.2 },
  '美容': { regulatory: 1.2, civil_liability: 1.1 },
  '製造': { regulatory: 1.2, civil_liability: 1.4 },
};

const DIMENSION_WEIGHTS: Record<RiskDimension, number> = {
  regulatory: 0.25,
  civil_liability: 0.25,
  criminal: 0.20,
  reputation: 0.15,
  cross_border: 0.15,
};

export function assessLegalRisk(input: RiskInput): RiskAssessment {
  const coeff = INDUSTRY_RISK_COEFF[input.industry] ?? {};
  const dimensions: DimensionScore[] = [];

  // Regulatory
  let regulatory = 30;
  const regReasoning: string[] = [];
  const regLaws: string[] = [];
  if (input.industry === '医療' || input.industry === '介護') {
    regulatory += 25;
    regReasoning.push('医療/介護は厳格な業法規制 (医療法/介護保険法)');
    regLaws.push('医療法', '介護保険法', '薬機法');
  }
  if (input.industry === '金融') {
    regulatory += 30;
    regReasoning.push('金商法・銀行法・資金決済法・FSA監督下');
    regLaws.push('金融商品取引法', '銀行法', '資金決済法');
  }
  if (input.industry === '公共') {
    regulatory += 25;
    regReasoning.push('入契法・会計法29条の3・調達ガイドライン');
    regLaws.push('入契法', '会計法29条の3');
  }
  if ((input.pii_volume ?? 0) >= 5000) {
    regulatory += 15;
    regReasoning.push(`個人情報 ${input.pii_volume} 件 — 個情法26条 漏えい報告義務該当`);
    regLaws.push('個人情報保護法');
  }
  regulatory = Math.min(100, regulatory * (coeff.regulatory ?? 1));
  dimensions.push({ dimension: 'regulatory', score: Math.round(regulatory), reasoning: regReasoning, related_laws: regLaws });

  // Civil Liability
  let civil = 30;
  const civilReasoning: string[] = [];
  const civilLaws = ['民法第709条', '民法第415条'];
  if ((input.transaction_amount_jpy ?? 0) >= 1_000_000_000) {
    civil += 35;
    civilReasoning.push(`大型取引 ${(input.transaction_amount_jpy ?? 0) / 1e8}億円 — 損害賠償リスク大`);
  } else if ((input.transaction_amount_jpy ?? 0) >= 100_000_000) {
    civil += 20;
    civilReasoning.push(`中型取引 ${(input.transaction_amount_jpy ?? 0) / 1e8}億円`);
  }
  if (input.customer_type === 'btoc') {
    civil += 15;
    civilReasoning.push('BtoC — 消費者契約法10条等の不当条項規制');
    civilLaws.push('消費者契約法第10条', '消費者契約法第8条');
  }
  civil = Math.min(100, civil * (coeff.civil_liability ?? 1));
  dimensions.push({ dimension: 'civil_liability', score: Math.round(civil), reasoning: civilReasoning, related_laws: civilLaws });

  // Criminal
  let criminal = 15;
  const crimReasoning: string[] = [];
  const crimLaws: string[] = [];
  if (input.industry === '公共' || input.industry === '建設') {
    criminal += 25;
    crimReasoning.push('公共/建設 — 贈賄・談合リスク');
    crimLaws.push('刑法第197条', '独占禁止法', '入札談合等関与行為防止法');
  }
  if (input.international) {
    criminal += 20;
    crimReasoning.push('国際取引 — 外国公務員贈賄 (不競法18条/FCPA/UKBA)');
    crimLaws.push('不正競争防止法第18条', 'FCPA', 'UKBA');
  }
  criminal = Math.min(100, criminal * (coeff.criminal ?? 1));
  dimensions.push({ dimension: 'criminal', score: Math.round(criminal), reasoning: crimReasoning, related_laws: crimLaws });

  // Reputation
  let reputation = 20;
  const repReasoning: string[] = [];
  if ((input.pii_volume ?? 0) >= 100_000) {
    reputation += 30;
    repReasoning.push('大規模個人情報 — 漏えい時メディア露出リスク');
  }
  if (input.industry === '士業') {
    reputation += 25;
    repReasoning.push('士業 — 信用毀損が業務継続に直結');
  }
  reputation = Math.min(100, reputation * (coeff.reputation ?? 1));
  dimensions.push({ dimension: 'reputation', score: Math.round(reputation), reasoning: repReasoning, related_laws: ['民法第709条 (名誉毀損)', '刑法第230条'] });

  // Cross-Border
  let crossBorder = 0;
  const cbReasoning: string[] = [];
  const cbLaws: string[] = [];
  if (input.international) {
    crossBorder = 40;
    cbReasoning.push('国際事業 — GDPR/CCPA/SOX 等比較法適用');
    cbLaws.push('GDPR (EU)', 'CCPA (US-CA)', 'SOX (US)', 'FCPA (US)');
    if ((input.pii_volume ?? 0) > 0) {
      crossBorder += 30;
      cbReasoning.push('EU/加州居住者の個人データ — GDPR Art.3 域外適用');
    }
  }
  crossBorder = Math.min(100, crossBorder * (coeff.cross_border ?? 1));
  dimensions.push({ dimension: 'cross_border', score: Math.round(crossBorder), reasoning: cbReasoning, related_laws: cbLaws });

  // Overall (加重平均)
  let overall = 0;
  for (const d of dimensions) overall += d.score * DIMENSION_WEIGHTS[d.dimension];
  overall = Math.round(overall);

  const level: RiskAssessment['level'] =
    overall >= 75 ? 'critical' : overall >= 55 ? 'high' : overall >= 35 ? 'medium' : 'low';

  const recommendations: string[] = [];
  if (level === 'critical') {
    recommendations.push('🚨 法務部 + 顧問弁護士による事前レビュー必須');
    recommendations.push('リスク保険 (E&O / Cyber Liability) の加入検討');
  }
  if (regulatory >= 60) recommendations.push('規制遵守: コンプライアンスプログラム整備 + 定期監査');
  if (civil >= 60) recommendations.push('民事リスク: 損害賠償上限条項 + 保険 + 契約レビュー');
  if (criminal >= 50) recommendations.push('刑事リスク: 内部通報窓口 + 第三者委員会 + 役員研修');
  if (reputation >= 60) recommendations.push('レピュテーション: 危機管理マニュアル + 広報訓練');
  if (crossBorder >= 50) recommendations.push('越境規制: 国別 DPA / SCC / TIA (Transfer Impact Assessment)');

  return {
    scenario: input.scenario,
    industry: input.industry,
    generated_at: new Date().toISOString(),
    dimensions,
    overall_score: overall,
    level,
    recommendations,
    estimated_damage_jpy: estimateDamage(input, level),
  };
}

function estimateDamage(input: RiskInput, level: RiskAssessment['level']): number | undefined {
  const base = level === 'critical' ? 100_000_000
    : level === 'high' ? 30_000_000
    : level === 'medium' ? 5_000_000
    : 500_000;
  if ((input.pii_volume ?? 0) > 0) {
    // ベネッセ事案 1名 1000円ベース
    return Math.max(base, (input.pii_volume ?? 0) * 1000);
  }
  return base;
}

export function renderRiskReport(r: RiskAssessment): string {
  const lines: string[] = [];
  lines.push('# 法務リスク評価レポート');
  lines.push('');
  lines.push(`生成日時: ${r.generated_at}`);
  lines.push(`シナリオ: ${r.scenario}`);
  lines.push(`業種: ${r.industry}`);
  lines.push('');
  lines.push(`## 総合スコア: **${r.overall_score} / 100 (${r.level.toUpperCase()})**`);
  if (r.estimated_damage_jpy) {
    lines.push(`想定損害額 (中央値): ¥${r.estimated_damage_jpy.toLocaleString()}`);
  }
  lines.push('');
  lines.push('## 次元別');
  for (const d of r.dimensions) {
    lines.push(`### ${d.dimension}: ${d.score}/100`);
    for (const reason of d.reasoning) lines.push(`- ${reason}`);
    if (d.related_laws.length > 0) {
      lines.push(`- 関連法令: ${d.related_laws.join(', ')}`);
    }
    lines.push('');
  }
  lines.push('## 推奨アクション');
  for (const rec of r.recommendations) lines.push(`- ${rec}`);
  return lines.join('\n');
}
