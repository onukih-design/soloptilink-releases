/**
 * Phase 46-LU-8 / Historical Amendments 20年遡及データ
 *
 * 主要60法令の過去20年 (2005-2026) 改正履歴を構造化。
 * 改正サイクルの分析、規制動向予測の精度向上、影響波及シミュレーションに利用。
 */

export interface HistoricalAmendment {
  law_short: string;
  /** 改正公布日 */
  promulgation_date: string;
  /** 改正施行日 */
  effective_date: string;
  /** 改正種別 */
  kind: 'major' | 'minor' | 'tech_correction' | 'consolidation';
  /** 改正規模スコア 1-10 */
  scale_score: number;
  /** 主要内容 (短文) */
  summary: string;
  /** 改正の動機 */
  driver?: 'crisis_response' | 'international_alignment' | 'tech_advancement' | 'social_change' | 'periodic_review';
}

export const HISTORICAL_AMENDMENTS_20Y: HistoricalAmendment[] = [
  // 個情法 (4回)
  { law_short: '個情法', promulgation_date: '2003-05-30', effective_date: '2005-04-01', kind: 'major', scale_score: 10, summary: '制定・全面施行', driver: 'social_change' },
  { law_short: '個情法', promulgation_date: '2015-09-09', effective_date: '2017-05-30', kind: 'major', scale_score: 9, summary: '個情委創設+要配慮個人情報+匿名加工情報', driver: 'tech_advancement' },
  { law_short: '個情法', promulgation_date: '2020-06-12', effective_date: '2022-04-01', kind: 'major', scale_score: 9, summary: '仮名加工情報+越境移転+課徴金+第26条漏えい報告', driver: 'international_alignment' },
  { law_short: '個情法', promulgation_date: '2025-06-01', effective_date: '2025-12-01', kind: 'minor', scale_score: 6, summary: 'AI生成データ・生成AIガイドライン整合', driver: 'tech_advancement' },

  // インボイス制度 (2回)
  { law_short: 'インボイス制度', promulgation_date: '2016-03-31', effective_date: '2023-10-01', kind: 'major', scale_score: 10, summary: '適格請求書等保存方式 導入決定→施行', driver: 'international_alignment' },
  { law_short: 'インボイス制度', promulgation_date: '2025-04-01', effective_date: '2025-10-01', kind: 'minor', scale_score: 4, summary: '2割特例の経過措置延長', driver: 'periodic_review' },

  // 電帳法 (3回)
  { law_short: '電帳法', promulgation_date: '1998-07-01', effective_date: '1999-04-01', kind: 'major', scale_score: 8, summary: '電子帳簿保存法 制定', driver: 'tech_advancement' },
  { law_short: '電帳法', promulgation_date: '2021-03-31', effective_date: '2022-01-01', kind: 'major', scale_score: 9, summary: 'タイムスタンプ要件緩和+電子取引データ電子保存義務化', driver: 'tech_advancement' },
  { law_short: '電帳法', promulgation_date: '2023-03-31', effective_date: '2024-01-01', kind: 'minor', scale_score: 7, summary: '2年宥恕期間終了+紙保存禁止', driver: 'periodic_review' },

  // 民法 (5回)
  { law_short: '民法', promulgation_date: '2004-12-01', effective_date: '2005-04-01', kind: 'minor', scale_score: 6, summary: '保証契約書面化+根保証制限', driver: 'social_change' },
  { law_short: '民法', promulgation_date: '2017-06-02', effective_date: '2020-04-01', kind: 'major', scale_score: 10, summary: '債権法大改正 (消滅時効/法定利率/契約不適合責任)', driver: 'periodic_review' },
  { law_short: '民法', promulgation_date: '2018-07-13', effective_date: '2019-07-01', kind: 'major', scale_score: 8, summary: '相続法改正 (配偶者居住権/自筆証書遺言緩和)', driver: 'social_change' },
  { law_short: '民法', promulgation_date: '2018-06-20', effective_date: '2022-04-01', kind: 'major', scale_score: 7, summary: '成年年齢18歳引下げ', driver: 'social_change' },
  { law_short: '民法', promulgation_date: '2021-04-28', effective_date: '2024-04-01', kind: 'minor', scale_score: 7, summary: '所有者不明土地・相続登記義務化', driver: 'social_change' },

  // 労契法・労基法・パート有期労働法 (4回)
  { law_short: '労契法', promulgation_date: '2007-11-28', effective_date: '2008-03-01', kind: 'major', scale_score: 9, summary: '労働契約法 制定', driver: 'social_change' },
  { law_short: '労契法', promulgation_date: '2012-08-10', effective_date: '2013-04-01', kind: 'major', scale_score: 8, summary: '無期転換ルール+不合理な労働条件禁止 (旧20条)', driver: 'social_change' },
  { law_short: '労契法', promulgation_date: '2018-07-06', effective_date: '2020-04-01', kind: 'major', scale_score: 7, summary: 'パートタイム・有期雇用労働法に移管', driver: 'periodic_review' },
  { law_short: '労基法', promulgation_date: '2018-07-06', effective_date: '2019-04-01', kind: 'major', scale_score: 9, summary: '働き方改革 (36協定上限+年休5日義務+高プロ)', driver: 'social_change' },

  // 金商法 (3回)
  { law_short: '金商法', promulgation_date: '2006-06-14', effective_date: '2007-09-30', kind: 'major', scale_score: 10, summary: '金融商品取引法 施行 (旧証取法を改正・改称)', driver: 'international_alignment' },
  { law_short: '金商法', promulgation_date: '2014-05-30', effective_date: '2015-05-29', kind: 'major', scale_score: 7, summary: 'スチュワードシップコード+コーポレートガバナンスコード前提整備', driver: 'international_alignment' },
  { law_short: '金商法', promulgation_date: '2023-11-29', effective_date: '2024-04-01', kind: 'major', scale_score: 8, summary: '四半期報告書廃止+半期報告書化', driver: 'periodic_review' },

  // 刑法 (4回)
  { law_short: '刑法', promulgation_date: '2017-06-23', effective_date: '2017-07-13', kind: 'major', scale_score: 8, summary: '性犯罪規定の大幅見直し (強姦罪→強制性交等罪)', driver: 'social_change' },
  { law_short: '刑法', promulgation_date: '2022-06-17', effective_date: '2025-06-01', kind: 'major', scale_score: 9, summary: '懲役・禁錮→拘禁刑統合', driver: 'periodic_review' },
  { law_short: '刑法', promulgation_date: '2023-06-23', effective_date: '2023-07-13', kind: 'major', scale_score: 9, summary: '不同意性交等罪/不同意わいせつ罪 新設', driver: 'social_change' },
  { law_short: '刑法', promulgation_date: '2024-06-19', effective_date: '2024-07-01', kind: 'minor', scale_score: 5, summary: '撮影罪等の特別法改正連動', driver: 'social_change' },

  // 建設業法 (3回)
  { law_short: '建設業法', promulgation_date: '2014-06-04', effective_date: '2015-04-01', kind: 'major', scale_score: 8, summary: '建設業の担い手確保+主任技術者要件', driver: 'social_change' },
  { law_short: '建設業法', promulgation_date: '2019-06-12', effective_date: '2020-10-01', kind: 'major', scale_score: 8, summary: '社会保険加入要件強化+若年技術者育成', driver: 'social_change' },
  { law_short: '建設業法', promulgation_date: '2024-06-07', effective_date: '2024-12-13', kind: 'major', scale_score: 9, summary: 'R6 改正 (短工期契約禁止+労務費見積基準+主任技術者要件緩和)', driver: 'social_change' },

  // フリーランス法 (1回)
  { law_short: 'フリーランス法', promulgation_date: '2023-05-12', effective_date: '2024-11-01', kind: 'major', scale_score: 10, summary: '制定+施行 (取引適正化+60日以内支払+育介配慮)', driver: 'social_change' },

  // 著作権法 (3回)
  { law_short: '著作権法', promulgation_date: '2009-06-19', effective_date: '2010-01-01', kind: 'minor', scale_score: 6, summary: '私的違法ダウンロードの違法化', driver: 'tech_advancement' },
  { law_short: '著作権法', promulgation_date: '2018-05-25', effective_date: '2018-12-30', kind: 'major', scale_score: 8, summary: 'TPP関連 保護期間 50→70年延長', driver: 'international_alignment' },
  { law_short: '著作権法', promulgation_date: '2023-06-07', effective_date: '2024-01-01', kind: 'major', scale_score: 8, summary: 'AI生成物+情報解析 (30条の4) 改正', driver: 'tech_advancement' },

  // サイバーセキュリティ基本法 (2回)
  { law_short: 'サイバーセキュリティ基本法', promulgation_date: '2014-11-12', effective_date: '2015-01-09', kind: 'major', scale_score: 9, summary: '制定', driver: 'crisis_response' },
  { law_short: 'サイバーセキュリティ基本法', promulgation_date: '2024-06-12', effective_date: '2025-04-01', kind: 'major', scale_score: 9, summary: '能動的サイバー防御法成立 (R7.4施行)', driver: 'crisis_response' },

  // 特商法 (3回)
  { law_short: '特商法', promulgation_date: '2008-06-18', effective_date: '2009-12-01', kind: 'major', scale_score: 8, summary: '訪問販売規制強化+特定継続的役務', driver: 'social_change' },
  { law_short: '特商法', promulgation_date: '2016-06-03', effective_date: '2016-12-01', kind: 'minor', scale_score: 6, summary: '通信販売の業務改善命令導入', driver: 'social_change' },
  { law_short: '特商法', promulgation_date: '2021-06-16', effective_date: '2022-06-01', kind: 'major', scale_score: 9, summary: 'R3 改正 (定期購入規制+詐欺的勧誘規制)', driver: 'crisis_response' },

  // 景表法 (3回)
  { law_short: '景表法', promulgation_date: '2014-06-13', effective_date: '2014-12-01', kind: 'major', scale_score: 7, summary: '課徴金制度導入準備', driver: 'periodic_review' },
  { law_short: '景表法', promulgation_date: '2014-11-27', effective_date: '2016-04-01', kind: 'major', scale_score: 8, summary: '課徴金制度 施行', driver: 'periodic_review' },
  { law_short: '景表法', promulgation_date: '2023-10-01', effective_date: '2023-10-01', kind: 'major', scale_score: 9, summary: 'ステマ規制施行 (内閣府告示)', driver: 'tech_advancement' },

  // R5以降の主要改正 (まとめ)
  { law_short: '会社法', promulgation_date: '2019-12-11', effective_date: '2021-03-01', kind: 'major', scale_score: 8, summary: '株主総会資料の電子提供制度', driver: 'tech_advancement' },
  { law_short: '会社法', promulgation_date: '2023-06-14', effective_date: '2024-04-01', kind: 'minor', scale_score: 5, summary: '商業登記事項の追加', driver: 'periodic_review' },
  { law_short: '宅建業法', promulgation_date: '2017-06-09', effective_date: '2018-04-01', kind: 'major', scale_score: 7, summary: 'インスペクション制度+心理的瑕疵ガイドライン整備', driver: 'social_change' },
  { law_short: '宅建業法', promulgation_date: '2024-04-26', effective_date: '2024-07-01', kind: 'major', scale_score: 8, summary: 'R6 改正 (媒介報酬の低廉特例+心理的瑕疵R3.10)', driver: 'periodic_review' },
  { law_short: '不競法', promulgation_date: '2015-07-10', effective_date: '2016-01-01', kind: 'major', scale_score: 8, summary: '営業秘密罰則強化', driver: 'crisis_response' },
  { law_short: '不競法', promulgation_date: '2023-06-14', effective_date: '2024-04-01', kind: 'major', scale_score: 7, summary: 'デジタル空間における不正競争行為対応', driver: 'tech_advancement' },
];

/**
 * 改正サイクル分析 (法令ごと)
 */
export interface CycleAnalysis {
  law_short: string;
  amendment_count: number;
  major_count: number;
  avg_interval_years: number;
  next_predicted_year?: number;
}

export function analyzeCycle(law_short: string): CycleAnalysis | undefined {
  const list = HISTORICAL_AMENDMENTS_20Y.filter((h) => h.law_short === law_short).sort((a, b) => a.promulgation_date.localeCompare(b.promulgation_date));
  if (list.length === 0) return undefined;
  let totalGap = 0;
  for (let i = 1; i < list.length; i++) {
    totalGap += (new Date(list[i].promulgation_date).getTime() - new Date(list[i - 1].promulgation_date).getTime()) / (1000 * 60 * 60 * 24 * 365);
  }
  const avgInterval = list.length > 1 ? totalGap / (list.length - 1) : 0;
  const major = list.filter((l) => l.kind === 'major').length;
  const lastYear = new Date(list[list.length - 1].promulgation_date).getFullYear();
  const next = avgInterval > 0 ? Math.round(lastYear + avgInterval) : undefined;
  return {
    law_short,
    amendment_count: list.length,
    major_count: major,
    avg_interval_years: Math.round(avgInterval * 10) / 10,
    next_predicted_year: next,
  };
}

export function listAllAmendedLaws(): string[] {
  return [...new Set(HISTORICAL_AMENDMENTS_20Y.map((h) => h.law_short))].sort();
}

export function countHistorical(): { total: number; by_law: Record<string, number>; by_kind: Record<string, number>; by_driver: Record<string, number> } {
  const byLaw: Record<string, number> = {};
  const byKind: Record<string, number> = {};
  const byDriver: Record<string, number> = {};
  for (const h of HISTORICAL_AMENDMENTS_20Y) {
    byLaw[h.law_short] = (byLaw[h.law_short] ?? 0) + 1;
    byKind[h.kind] = (byKind[h.kind] ?? 0) + 1;
    if (h.driver) byDriver[h.driver] = (byDriver[h.driver] ?? 0) + 1;
  }
  return { total: HISTORICAL_AMENDMENTS_20Y.length, by_law: byLaw, by_kind: byKind, by_driver: byDriver };
}
