/**
 * Phase 46-LU-6 / Mobile SDK Lightweight Client
 *
 * iOS / Android (RN/Flutter) 向け軽量クライアント仕様。
 * バンドル < 50KB を目標、依存ゼロ (fetch のみ)。
 *
 *  - 認証: API Key (Bearer)
 *  - 主要エンドポイント: search / scan / risk / contract / alert
 *  - オフラインキャッシュ (直近の検索結果 24h)
 *  - エラーリトライ (指数バックオフ 最大3回)
 *  - 圧縮: Brotli/gzip 自動判定
 *  - Type-safe レスポンス
 */

export interface SoloptiLinkSdkConfig {
  api_key: string;
  base_url?: string;
  timeout_ms?: number;
  /** オフラインキャッシュを有効化 */
  enable_cache?: boolean;
  /** カスタム fetch (テスト用) */
  fetchImpl?: typeof fetch;
}

export interface SdkRetrievalResult {
  short_name: string;
  citation: string;
  score: number;
  snippet?: string;
}

export interface SdkComplianceFinding {
  rule_id: string;
  severity: string;
  matched_snippet: string;
  related_laws: string[];
  remediation: string;
}

export class SoloptiLinkClient {
  private readonly apiKey: string;
  private readonly baseUrl: string;
  private readonly timeoutMs: number;
  private readonly fetchImpl: typeof fetch;
  private readonly cache: Map<string, { data: unknown; expires: number }>;
  private readonly enableCache: boolean;

  constructor(config: SoloptiLinkSdkConfig) {
    if (!config.api_key) throw new Error('api_key is required');
    this.apiKey = config.api_key;
    this.baseUrl = config.base_url ?? 'https://api.soloptilink.com/api/v1/legal';
    this.timeoutMs = config.timeout_ms ?? 30_000;
    this.enableCache = config.enable_cache ?? true;
    this.cache = new Map();
    const candidate = config.fetchImpl ?? (typeof fetch === 'function' ? fetch : undefined);
    if (!candidate) throw new Error('fetch implementation required');
    this.fetchImpl = candidate;
  }

  async searchLegal(query: string, k = 5): Promise<SdkRetrievalResult[]> {
    const cacheKey = `search:${query}:${k}`;
    const cached = this.getCache<SdkRetrievalResult[]>(cacheKey);
    if (cached) return cached;
    const r = await this.request<{ results: SdkRetrievalResult[] }>('POST', '/rag/search', { query, k });
    const data = r.results ?? [];
    this.setCache(cacheKey, data, 24 * 60 * 60 * 1000);
    return data;
  }

  async scanCompliance(code: string): Promise<{ findings: SdkComplianceFinding[]; score: number }> {
    return this.request('POST', '/compliance/scan', { code });
  }

  async assessRisk(scenario: string, industry: string): Promise<{ overall_score: number; level: string }> {
    return this.request('POST', '/risk/assess', { scenario, industry });
  }

  async generateContract(kind: string): Promise<{ rendered: string }> {
    return this.request('POST', '/contracts/generate', { kind, format: 'markdown' });
  }

  async getCaseDetail(caseId: string): Promise<{ short_name: string; citation: string; summary: string }> {
    return this.request('GET', `/cases/${encodeURIComponent(caseId)}`);
  }

  async subscribeAlert(email: string, frequency: 'realtime' | 'daily' | 'weekly'): Promise<{ subscription_id: string }> {
    return this.request('POST', '/alerts/subscribe', { email, frequency });
  }

  async usage(): Promise<{ tenant_id: string; by_resource: Record<string, number> }> {
    return this.request('GET', '/billing/usage');
  }

  // 内部
  private async request<T>(method: string, path: string, body?: unknown, retries = 3): Promise<T> {
    const url = `${this.baseUrl}${path}`;
    const headers: Record<string, string> = {
      Authorization: `Bearer ${this.apiKey}`,
      'Content-Type': 'application/json',
      'Accept-Encoding': 'br, gzip',
      'User-Agent': `SoloptiLinkAI-SDK/1.0 (${this.detectPlatform()})`,
    };
    for (let attempt = 0; attempt <= retries; attempt++) {
      try {
        const ctrl = new AbortController();
        const tHandle = setTimeout(() => ctrl.abort(), this.timeoutMs);
        const res = await this.fetchImpl(url, {
          method,
          headers,
          body: body ? JSON.stringify(body) : undefined,
          signal: ctrl.signal,
        });
        clearTimeout(tHandle);
        if (res.status === 429 || res.status >= 500) {
          if (attempt < retries) {
            await sleep(Math.min(8000, 1000 * 2 ** attempt));
            continue;
          }
          throw new Error(`HTTP ${res.status}`);
        }
        if (!res.ok) throw new Error(`HTTP ${res.status}: ${await res.text().catch(() => '')}`);
        return (await res.json()) as T;
      } catch (err) {
        if (attempt >= retries) throw err;
        await sleep(Math.min(8000, 1000 * 2 ** attempt));
      }
    }
    throw new Error('max retries exceeded');
  }

  private getCache<T>(key: string): T | undefined {
    if (!this.enableCache) return undefined;
    const v = this.cache.get(key);
    if (!v) return undefined;
    if (v.expires < Date.now()) {
      this.cache.delete(key);
      return undefined;
    }
    return v.data as T;
  }

  private setCache(key: string, data: unknown, ttlMs: number): void {
    if (!this.enableCache) return;
    this.cache.set(key, { data, expires: Date.now() + ttlMs });
  }

  private detectPlatform(): string {
    const ua = typeof navigator !== 'undefined' ? navigator.userAgent : 'node';
    if (/iPhone|iPad|iOS/i.test(ua)) return 'iOS';
    if (/Android/i.test(ua)) return 'Android';
    if (typeof process !== 'undefined') return 'Node';
    return 'Web';
  }

  clearCache(): void {
    this.cache.clear();
  }

  getCacheSize(): number {
    return this.cache.size;
  }
}

function sleep(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

/**
 * iOS Swift / Kotlin / Dart 用のサンプル使用例 (コメントとして)
 */
export const SDK_USAGE_EXAMPLES = {
  typescript: `import { SoloptiLinkClient } from '@soloptilink/legal-sdk';
const client = new SoloptiLinkClient({ api_key: process.env.SLK_KEY! });
const cases = await client.searchLegal('民法415条');`,
  swift: `// iOS Swift
let client = SoloptiLinkClient(apiKey: "YOUR_KEY")
let cases = try await client.searchLegal(query: "民法415条")`,
  kotlin: `// Android Kotlin
val client = SoloptiLinkClient(apiKey = "YOUR_KEY")
val cases = client.searchLegal("民法415条")`,
  flutter: `// Flutter Dart
final client = SoloptiLinkClient(apiKey: 'YOUR_KEY');
final cases = await client.searchLegal('民法415条');`,
  react_native: `// React Native
import { SoloptiLinkClient } from '@soloptilink/legal-sdk-rn';
const client = new SoloptiLinkClient({ apiKey: 'YOUR_KEY' });`,
};

export function listSdkPlatforms(): string[] {
  return Object.keys(SDK_USAGE_EXAMPLES);
}
