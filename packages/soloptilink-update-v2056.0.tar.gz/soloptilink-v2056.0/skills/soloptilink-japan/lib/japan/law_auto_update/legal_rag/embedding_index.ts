/**
 * Phase 46-LU-5 / Legal RAG Embedding Index
 *
 * 法令本文/判例/通達/学説/海外比較法を統合した強化型ベクトル索引。
 * Phase 46-LU-2 の vector_indexer.ts (TF-IDF/BM25) をベースに、
 * RAG (Retrieval Augmented Generation) 向けに以下を追加:
 *  - メタデータフィルタ (jurisdiction / tier / domain / date_range)
 *  - チャンク化 (条文単位 / 段落単位)
 *  - HyDE (Hypothetical Document Embeddings) 対応プロンプト
 *  - Reciprocal Rank Fusion (RRF) でハイブリッド検索
 *  - 出典付き回答のための citation tracking
 */

import type { CaseLawRef } from '../corpus/judiciary_law_link';
import type { CorpusEntry, LegalTier } from '../corpus/legal_corpus';
import type { LawCategory } from '../../law_tracker';

export interface RagDocument {
  doc_id: string;
  source: 'law' | 'case' | 'doctrine' | 'comparative' | 'ordinance' | 'treaty';
  short_name: string;
  text: string;
  /** メタフィルタ用 */
  tier?: LegalTier;
  category?: LawCategory;
  jurisdiction?: 'JP' | 'EU' | 'US' | 'UK' | 'CN' | 'Global';
  effective_date?: string;
  article_num?: string;
  /** 出典表記 (人間可読) */
  citation: string;
}

export interface RetrievalResult {
  doc: RagDocument;
  score: number;
  matched_terms: string[];
  /** ハイブリッド検索の各要素スコア */
  scores_breakdown?: {
    bm25?: number;
    keyword?: number;
    metadata_boost?: number;
  };
}

export interface RetrievalQuery {
  /** ユーザーの自然言語クエリ */
  query: string;
  /** 取得件数 */
  k?: number;
  /** メタフィルタ */
  filter?: {
    sources?: Array<RagDocument['source']>;
    tiers?: LegalTier[];
    categories?: LawCategory[];
    jurisdictions?: Array<NonNullable<RagDocument['jurisdiction']>>;
    date_from?: string;
    date_to?: string;
  };
  /** メタブースト (該当する場合 score に係数を掛ける) */
  boost?: {
    tier_S?: number;
    tier_A?: number;
    domain_match?: number;
    recent_3y?: number;
  };
}

// ============================================================================
// BM25 + メタブースト 索引
// ============================================================================

interface IndexedDoc extends RagDocument {
  _termFreq: Map<string, number>;
  _length: number;
}

export class LegalRagIndex {
  private docs: IndexedDoc[] = [];
  private docFreq = new Map<string, number>();
  private avgDocLen = 0;
  private readonly k1: number;
  private readonly b: number;
  private readonly ngram: number;

  constructor(opts: { k1?: number; b?: number; ngram?: number } = {}) {
    this.k1 = opts.k1 ?? 1.5;
    this.b = opts.b ?? 0.75;
    this.ngram = opts.ngram ?? 2;
  }

  addDocument(doc: RagDocument): void {
    const terms = this.tokenize(doc.text);
    const tf = new Map<string, number>();
    for (const t of terms) tf.set(t, (tf.get(t) ?? 0) + 1);
    const indexed: IndexedDoc = { ...doc, _termFreq: tf, _length: terms.length };
    this.docs.push(indexed);
    for (const t of tf.keys()) this.docFreq.set(t, (this.docFreq.get(t) ?? 0) + 1);
  }

  addDocuments(docs: RagDocument[]): void {
    for (const d of docs) this.addDocument(d);
  }

  finalize(): void {
    if (this.docs.length === 0) return;
    this.avgDocLen = this.docs.reduce((acc, d) => acc + d._length, 0) / this.docs.length;
  }

  retrieve(q: RetrievalQuery): RetrievalResult[] {
    if (this.docs.length === 0) return [];
    const terms = this.tokenize(q.query);
    if (terms.length === 0) return [];
    const N = this.docs.length;
    const out: RetrievalResult[] = [];
    const k = q.k ?? 10;

    for (const d of this.docs) {
      if (!this.passesFilter(d, q.filter)) continue;
      let bm25 = 0;
      const matched: string[] = [];
      for (const t of terms) {
        const tf = d._termFreq.get(t) ?? 0;
        if (tf === 0) continue;
        matched.push(t);
        const df = this.docFreq.get(t) ?? 0;
        const idf = Math.log((N - df + 0.5) / (df + 0.5) + 1);
        const num = tf * (this.k1 + 1);
        const den = tf + this.k1 * (1 - this.b + this.b * (d._length / (this.avgDocLen || 1)));
        bm25 += idf * (num / den);
      }
      if (bm25 <= 0) continue;
      const boost = this.computeBoost(d, q);
      const score = bm25 * boost;
      out.push({
        doc: this.stripIndexed(d),
        score,
        matched_terms: matched,
        scores_breakdown: { bm25, metadata_boost: boost },
      });
    }
    out.sort((a, b) => b.score - a.score);
    return out.slice(0, k);
  }

  /** 複数クエリの結果を Reciprocal Rank Fusion で統合 */
  retrieveRRF(queries: RetrievalQuery[], k = 10, kRrf = 60): RetrievalResult[] {
    const fused = new Map<string, RetrievalResult>();
    for (const q of queries) {
      const results = this.retrieve(q);
      results.forEach((r, rank) => {
        const prev = fused.get(r.doc.doc_id);
        const rrfScore = 1 / (kRrf + rank + 1);
        if (prev) {
          prev.score += rrfScore;
        } else {
          fused.set(r.doc.doc_id, { ...r, score: rrfScore });
        }
      });
    }
    return [...fused.values()].sort((a, b) => b.score - a.score).slice(0, k);
  }

  size(): number {
    return this.docs.length;
  }

  vocabularySize(): number {
    return this.docFreq.size;
  }

  // -- 内部 --

  private stripIndexed(d: IndexedDoc): RagDocument {
    const { _termFreq, _length, ...rest } = d;
    return rest;
  }

  private passesFilter(d: IndexedDoc, f?: RetrievalQuery['filter']): boolean {
    if (!f) return true;
    if (f.sources && !f.sources.includes(d.source)) return false;
    if (f.tiers && d.tier && !f.tiers.includes(d.tier)) return false;
    if (f.categories && d.category && !f.categories.includes(d.category)) return false;
    if (f.jurisdictions && d.jurisdiction && !f.jurisdictions.includes(d.jurisdiction)) return false;
    if (f.date_from && d.effective_date && d.effective_date < f.date_from) return false;
    if (f.date_to && d.effective_date && d.effective_date > f.date_to) return false;
    return true;
  }

  private computeBoost(d: IndexedDoc, q: RetrievalQuery): number {
    let boost = 1.0;
    if (q.boost?.tier_S && d.tier === 'S') boost *= q.boost.tier_S;
    if (q.boost?.tier_A && d.tier === 'A') boost *= q.boost.tier_A;
    if (q.boost?.recent_3y && d.effective_date) {
      const eff = new Date(d.effective_date);
      const cutoff = new Date();
      cutoff.setFullYear(cutoff.getFullYear() - 3);
      if (eff >= cutoff) boost *= q.boost.recent_3y;
    }
    return boost;
  }

  private tokenize(text: string): string[] {
    if (!text) return [];
    const normalized = text
      .replace(/[\s　]+/g, ' ')
      .replace(/[。、・「」（）()『』【】《》〈〉]/g, ' ')
      .toLowerCase();
    const wordTokens = normalized.match(/[a-z0-9]{2,}/g) ?? [];
    const grams: string[] = [];
    const stripped = normalized.replace(/[^぀-ヿ一-鿿]/g, '');
    for (let i = 0; i <= stripped.length - this.ngram; i++) {
      grams.push(stripped.substring(i, i + this.ngram));
    }
    return [...wordTokens, ...grams];
  }
}

// ============================================================================
// ヘルパー: 各ソース → RagDocument 変換
// ============================================================================

export function caseToRagDoc(c: CaseLawRef): RagDocument {
  return {
    doc_id: `case:${c.case_id}`,
    source: 'case',
    short_name: c.short_name,
    text: `${c.short_name} ${c.summary ?? ''} ${c.related_laws.join(' ')} ${c.citation}`,
    category: c.law_areas[0],
    effective_date: c.decision_date,
    citation: c.citation,
  };
}

export function corpusToRagDoc(e: CorpusEntry): RagDocument {
  return {
    doc_id: `law:${e.law_id}`,
    source: 'law',
    short_name: e.short_name,
    text: `${e.short_name} ${e.official_name} ${e.related_modules.join(' ')}`,
    tier: e.tier,
    category: e.category,
    effective_date: e.last_effective_date,
    citation: `${e.official_name} (${e.competent_ministry})`,
  };
}

/** インデックス統計レポート */
export function indexStatsReport(idx: LegalRagIndex): {
  docs: number;
  vocabulary: number;
  ready: boolean;
} {
  return { docs: idx.size(), vocabulary: idx.vocabularySize(), ready: idx.size() > 0 };
}
