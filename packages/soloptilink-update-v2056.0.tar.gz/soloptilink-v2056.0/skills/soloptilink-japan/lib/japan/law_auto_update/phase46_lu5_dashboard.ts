/**
 * Phase 46-LU-5 / 統合ダッシュボード
 *
 * Phase 46-LU-5 で構築した 10 ファイルの統合ビュー。
 * RAG / Compliance / Contracts / Timeline / Risk / Citation / Advisor / Omega Bridge / CCS / Mapping
 */

import { indexStatsReport, LegalRagIndex } from './legal_rag/embedding_index';
import { COMPLIANCE_RULES } from './compliance/code_compliance_scanner';
import { listAvailableContractKinds, countContractTemplates } from './contracts/contract_clause_generator';
import { countTimelineEvents } from './timeline/law_timeline';
import { CITATION_EDGES, countCitationEdges } from './citation/citation_network';
import { countMappings } from './mapping/case_to_current_law';

export interface OperationalDashboard {
  generated_at: string;
  module_counts: {
    rag_index_size: number;
    compliance_rules: number;
    contract_kinds: number;
    contract_clauses: number;
    timeline_events: number;
    citation_edges: number;
    case_law_mappings: number;
  };
  by_section: {
    legal_rag: { rules: string[]; status: string };
    compliance: { rules: number; severity_distribution: Record<string, number> };
    contracts: { kinds: string[]; total_clauses: number };
    timeline: { events: number; recent: number };
    risk: { dimensions: number };
    citation: { edges: number; ancestors_traceable: boolean };
    advisor: { multi_turn: boolean; risk_integration: boolean };
    omega_bridge: { categories: number; agencies_reachable: number };
    ccs: { axis_number: 10; weight: 0.10; sub_dimensions: 5 };
    case_mapping: { mappings: number };
  };
  /** 全体運用性スコア */
  operational_readiness_score: number;
  capabilities: string[];
}

export function buildOperationalDashboard(opts: { idx?: LegalRagIndex } = {}): OperationalDashboard {
  const idx = opts.idx;
  const rag = idx ? indexStatsReport(idx) : { docs: 0, vocabulary: 0, ready: false };
  const contracts = countContractTemplates();
  const timeline = countTimelineEvents();
  const citation = countCitationEdges();
  const mappings = countMappings();

  // Severity分布 (rules メタから)
  const sevDist: Record<string, number> = { critical: 0, high: 0, medium: 0, low: 0, info: 0 };
  for (const r of COMPLIANCE_RULES) sevDist[r.severity] = (sevDist[r.severity] ?? 0) + 1;

  const moduleCounts = {
    rag_index_size: rag.docs,
    compliance_rules: COMPLIANCE_RULES.length,
    contract_kinds: contracts.total,
    contract_clauses: contracts.total_clauses,
    timeline_events: timeline.total,
    citation_edges: citation.total,
    case_law_mappings: mappings.total,
  };

  // 運用性スコア計算 (各モジュールが充実しているか)
  let score = 0;
  if (moduleCounts.compliance_rules >= 15) score += 15;
  if (moduleCounts.contract_kinds >= 3) score += 15;
  if (moduleCounts.contract_clauses >= 20) score += 10;
  if (moduleCounts.timeline_events >= 20) score += 10;
  if (moduleCounts.citation_edges >= 15) score += 15;
  if (moduleCounts.case_law_mappings >= 10) score += 15;
  if (moduleCounts.rag_index_size > 0) score += 10; // index 構築済
  score += 10; // ベースライン (modules 揃っている)

  const capabilities: string[] = [
    '法令RAG (TF-IDF/BM25/RRF/HyDE)',
    'コードコンプライアンススキャン (個情/特商/景表/PL/薬機/電帳/インボイス/労基/消契/著作)',
    '契約書ジェネレーター (NDA/業務委託準委任/SES)',
    '法令タイムライン (公布/施行/改正/失効)',
    'リスクスコアリング (5次元 × 業種別係数)',
    '判例引用ネットワーク + Mermaid可視化',
    '対話型法務AIアドバイザー (multi-turn + シナリオ分析)',
    'ARTE-Omega ↔ 法令ブリッジ (16攻撃面 → 個情委/JPCERT/ACDA報告)',
    'Customer Confidence Score 法令適合性軸 (10/10軸)',
    '旧判例 → 現行法 マッピング (改正後の射程予測)',
  ];

  return {
    generated_at: new Date().toISOString(),
    module_counts: moduleCounts,
    by_section: {
      legal_rag: { rules: ['BM25', 'RRF', 'HyDE', 'metadata_filter'], status: rag.ready ? 'ready' : 'empty' },
      compliance: { rules: COMPLIANCE_RULES.length, severity_distribution: sevDist },
      contracts: { kinds: listAvailableContractKinds(), total_clauses: contracts.total_clauses },
      timeline: { events: timeline.total, recent: 0 },
      risk: { dimensions: 5 },
      citation: { edges: citation.total, ancestors_traceable: true },
      advisor: { multi_turn: true, risk_integration: true },
      omega_bridge: { categories: 16, agencies_reachable: 5 },
      ccs: { axis_number: 10, weight: 0.10, sub_dimensions: 5 },
      case_mapping: { mappings: mappings.total },
    },
    operational_readiness_score: Math.min(100, score),
    capabilities,
  };
}

export function renderOperationalDashboard(opts: { idx?: LegalRagIndex } = {}): string {
  const d = buildOperationalDashboard(opts);
  const lines: string[] = [];
  lines.push('=================================================');
  lines.push('  Phase 46-LU-5 / Operational Dashboard');
  lines.push('=================================================');
  lines.push(`  Generated: ${d.generated_at}`);
  lines.push(`  Operational Readiness: ${d.operational_readiness_score} / 100`);
  lines.push('');
  lines.push('[Module Counts]');
  for (const [k, v] of Object.entries(d.module_counts)) {
    lines.push(`  ${k.padEnd(24)} : ${v}`);
  }
  lines.push('');
  lines.push('[Capabilities]');
  for (const c of d.capabilities) lines.push(`  ✓ ${c}`);
  lines.push('');
  lines.push('[Compliance Rules by Severity]');
  for (const [sev, n] of Object.entries(d.by_section.compliance.severity_distribution)) {
    if (n > 0) lines.push(`  ${sev}: ${n}件`);
  }
  lines.push('');
  lines.push('[Contract Kinds]');
  lines.push(`  ${d.by_section.contracts.kinds.join(' / ')}`);
  lines.push('=================================================');
  return lines.join('\n');
}
