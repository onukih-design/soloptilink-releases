/**
 * Phase 46-LU-5 / Customer Confidence Score - Legal Axis
 *
 * SI Excellence Layer (Phase 47) の Customer Confidence Score (CCS) 10軸の
 * 1軸として「法令適合性 (Legal Compliance)」を組み込む。
 *
 * CCS 10軸 (SIEL):
 *   1. 要件網羅性 / 2. アーキテクチャ妥当性 / 3. テストカバレッジ /
 *   4. UAT エビデンス / 5. セキュリティ / 6. パフォーマンス /
 *   7. 運用品質 / 8. ドキュメント完全性 / 9. UX 一貫性 / 10. **法令適合性** ← 本モジュール
 *
 * 法令適合性軸の判定基準:
 *   - 個情法 (取得・利用・管理・第三者提供・本人権利)
 *   - 特商法 (通信販売 + 定期購入 + 表示義務)
 *   - 景表法 (優良誤認 + ステマ規制 R5.10)
 *   - 業種別法令 (医療3省2GL / 金融FISC / 公共会計法29条の3)
 *   - 改正追従性 (Phase 46-LU との連動)
 */

import { scanCodeForCompliance, buildScanReport, type ComplianceFinding } from '../compliance/code_compliance_scanner';

export interface LegalAxisInput {
  /** プロジェクト中のサンプルコード (TS/JS) */
  code_samples?: Array<{ code: string; file_hint?: string }>;
  /** 業種 */
  industry?: string;
  /** 国際性 (越境移転規制が必要か) */
  international?: boolean;
  /** PII 取扱の有無 */
  pii_handling?: boolean;
  /** 帳票テンプレ (請求書/契約書 等) の整備有無 */
  has_invoice_template?: boolean;
  has_contract_template?: boolean;
  has_consent_form?: boolean;
  /** 改正追従の証跡 (last legal update audit) */
  last_legal_audit_date?: string;
}

export interface LegalAxisResult {
  axis_name: 'legal_compliance';
  /** 0-100 スコア */
  score: number;
  /** 5 サブ次元 */
  sub_scores: {
    pii_compliance: number;
    business_law: number;
    industry_specific: number;
    international: number;
    amendment_currency: number;
  };
  findings: ComplianceFinding[];
  recommendations: string[];
  /** SIEL CCS 連携用 */
  ccs_compatible: {
    axis_number: 10;
    weight: 0.10;
    contribution_to_overall: number;
  };
}

export function computeLegalAxis(input: LegalAxisInput): LegalAxisResult {
  // 1. コードコンプライアンススキャン
  const allFindings: ComplianceFinding[] = [];
  for (const sample of input.code_samples ?? []) {
    allFindings.push(...scanCodeForCompliance(sample));
  }
  const compReport = buildScanReport(allFindings);

  // 2. PII Compliance サブスコア
  let piiScore = 80;
  if (input.pii_handling) {
    const piiFindings = allFindings.filter((f) => f.rule_id.startsWith('PII-'));
    piiScore -= piiFindings.length * 10;
    if (!input.has_consent_form) piiScore -= 15;
  }
  piiScore = Math.max(0, Math.min(100, piiScore));

  // 3. Business Law サブスコア
  let bizScore = 85;
  const bizFindings = allFindings.filter((f) =>
    f.rule_id.startsWith('TOKUSHO-')
    || f.rule_id.startsWith('KEIHYO-')
    || f.rule_id.startsWith('CONSUMER-'),
  );
  bizScore -= bizFindings.length * 8;
  if (!input.has_invoice_template) bizScore -= 10;
  if (!input.has_contract_template) bizScore -= 10;
  bizScore = Math.max(0, Math.min(100, bizScore));

  // 4. Industry Specific サブスコア
  let industryScore = 80;
  if (input.industry === '医療' || input.industry === '介護') {
    industryScore -= 5; // 高ハードル
  }
  if (input.industry === '金融' || input.industry === '公共') {
    industryScore -= 5;
  }
  // 強い加点要素: 業種固有テンプレ整備
  if (input.has_invoice_template) industryScore += 5;
  if (input.has_consent_form) industryScore += 5;
  industryScore = Math.max(0, Math.min(100, industryScore));

  // 5. International サブスコア
  let intlScore = 100;
  if (input.international) {
    intlScore = 70; // ベース下降 (規制が増えるため)
    if (input.pii_handling) intlScore -= 20; // GDPR/CCPA リスク
  }
  intlScore = Math.max(0, Math.min(100, intlScore));

  // 6. Amendment Currency (改正追従性) サブスコア
  let amendmentScore = 50;
  if (input.last_legal_audit_date) {
    const audit = new Date(input.last_legal_audit_date);
    const now = new Date();
    const daysSince = (now.getTime() - audit.getTime()) / (1000 * 60 * 60 * 24);
    if (daysSince < 30) amendmentScore = 95;
    else if (daysSince < 90) amendmentScore = 85;
    else if (daysSince < 180) amendmentScore = 70;
    else if (daysSince < 365) amendmentScore = 50;
    else amendmentScore = 30;
  }

  // 加重合算
  const subScores = {
    pii_compliance: piiScore,
    business_law: bizScore,
    industry_specific: industryScore,
    international: intlScore,
    amendment_currency: amendmentScore,
  };
  const weights = { pii_compliance: 0.30, business_law: 0.25, industry_specific: 0.20, international: 0.10, amendment_currency: 0.15 };
  let overall = 0;
  for (const k of Object.keys(subScores) as Array<keyof typeof subScores>) {
    overall += subScores[k] * weights[k];
  }
  overall = Math.round(overall);

  const recs: string[] = [];
  if (piiScore < 70) recs.push('個人情報取扱フロー (取得→利用→第三者提供→廃棄) の全段階に同意・記録を実装');
  if (bizScore < 70) recs.push('特商法/景表法/消契法の表示義務 (通販ページ・契約書条項) を整備');
  if (industryScore < 70) recs.push('業種固有テンプレ (NDA/業務委託/プライバシーポリシー) を contract_clause_generator.ts で生成');
  if (intlScore < 70) recs.push('GDPR Art.28 DPA + SCC (2021版) または BCR を導入');
  if (amendmentScore < 70) recs.push('Phase 46-LU 週次cron + 法令改正アラート (e-Gov v2) を稼働');
  if (compReport.compliance_score < 70) recs.push(`コードコンプライアンスを ${compReport.compliance_score}/100 から ${70}+ に修正`);

  return {
    axis_name: 'legal_compliance',
    score: overall,
    sub_scores: subScores,
    findings: allFindings,
    recommendations: recs,
    ccs_compatible: {
      axis_number: 10,
      weight: 0.10,
      contribution_to_overall: Math.round(overall * 0.10 * 100) / 100,
    },
  };
}

/**
 * SIEL CCS への JSON エクスポート (siel_validate.sh が読み込める形式)
 */
export function exportLegalAxisToSielJson(result: LegalAxisResult): {
  ccs_axis_10_legal_compliance: number;
  details: LegalAxisResult;
  generated_at: string;
} {
  return {
    ccs_axis_10_legal_compliance: result.score,
    details: result,
    generated_at: new Date().toISOString(),
  };
}

/**
 * CCS Verdict 連動 (Phase 47 SIEL の Reject/Bronze/Silver/Gold/Platinum 5段階)
 */
export function deriveCcsVerdict(score: number): 'reject' | 'bronze' | 'silver' | 'gold' | 'platinum' {
  if (score >= 90) return 'platinum';
  if (score >= 75) return 'gold';
  if (score >= 60) return 'silver';
  if (score >= 40) return 'bronze';
  return 'reject';
}
