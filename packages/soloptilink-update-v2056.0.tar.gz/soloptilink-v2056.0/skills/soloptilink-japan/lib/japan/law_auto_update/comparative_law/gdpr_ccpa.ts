/**
 * Phase 46-LU-4 / GDPR + CCPA/CPRA 比較法
 *
 * EU GDPR (一般データ保護規則 2018-05-25 適用)
 * 米加州 CCPA (2020-01-01) / CPRA (2023-01-01)
 * 日本企業が EU/加州在住者の個人データを扱う場合の主要規定。
 */

export interface ComparativeLawRule {
  jurisdiction: 'EU' | 'US-CA' | 'US-Federal' | 'UK' | 'CN' | 'Global';
  law_short: string;
  law_full: string;
  effective_date: string;
  key_articles: Record<string, string>;
  penalties_summary: string;
  /** 日本法との対応 */
  jp_counterpart?: string[];
}

export const GDPR_CCPA_RULES: ComparativeLawRule[] = [
  {
    jurisdiction: 'EU',
    law_short: 'GDPR',
    law_full: 'Regulation (EU) 2016/679 (General Data Protection Regulation)',
    effective_date: '2018-05-25',
    key_articles: {
      '3': '域外適用 (EU内データ主体の monitoring/offer 関与)',
      '5': '処理原則 (適法性/目的限定/データ最小化/正確性/保存制限/完全性機密性/アカウンタビリティ)',
      '6': '処理の適法性 (同意/契約/法的義務/重要利益/公共/正当利益)',
      '7': '同意の要件 (明確/分離/撤回容易)',
      '9': '特別カテゴリ (人種/政治/宗教/組合/遺伝子/生体/健康/性) — 原則禁止 + 例外10類型',
      '13/14': '情報提供義務 (収集時/間接取得時)',
      '15': 'アクセス権 (本人開示)',
      '17': '消去権 (忘れられる権利)',
      '20': 'データポータビリティ',
      '22': '自動化決定 (プロファイリング含む) — 重要決定への異議',
      '25': 'Privacy by Design + by Default',
      '28': '処理者契約 (Art.28 DPA)',
      '32': 'セキュリティ (TOM 技術的組織的措置)',
      '33': '72時間以内 監督機関通知 (個人データ侵害)',
      '34': 'データ主体への通知 (高リスクの場合)',
      '35': 'DPIA (データ保護影響評価)',
      '37': 'DPO 選任義務 (公的機関/大規模監視/特別カテゴリ)',
      '44-49': '第三国移転 (十分性決定/SCC/BCR/特例)',
      '83': '行政罰 (Art.83 — 2段階)',
    },
    penalties_summary: '上位: グローバル年商4%又は2000万EUR / 下位: 2%又は1000万EUR',
    jp_counterpart: ['個情法', '個情法第26条', '個情法施行令', 'APPI (個人情報保護法)'],
  },
  {
    jurisdiction: 'US-CA',
    law_short: 'CCPA',
    law_full: 'California Consumer Privacy Act of 2018',
    effective_date: '2020-01-01',
    key_articles: {
      '1798.100': '消費者の知る権利',
      '1798.105': '削除請求権',
      '1798.110': '収集情報の開示',
      '1798.115': '販売・共有先の開示',
      '1798.120': '販売拒否権 (Right to Opt-Out)',
      '1798.130': '通知義務 (収集時/プライバシーポリシー)',
      '1798.140': '個人情報定義 (世帯+12 categories)',
      '1798.150': 'プライベート訴権 (データ侵害時 100-750ドル/人)',
      '1798.155': '民事罰 (故意 7,500ドル/件 / 非故意 2,500ドル/件)',
    },
    penalties_summary: '故意違反: 7,500USD/件 / 非故意: 2,500USD/件 + データ侵害民事訴権',
    jp_counterpart: ['個情法第27条 第三者提供', '個情法第28条 オプトアウト'],
  },
  {
    jurisdiction: 'US-CA',
    law_short: 'CPRA',
    law_full: 'California Privacy Rights Act of 2020 (Amends CCPA)',
    effective_date: '2023-01-01',
    key_articles: {
      '1798.121': '機微情報のオプトアウト (Sensitive Personal Information)',
      '1798.125': '差別禁止',
      '1798.135': 'オプトアウト通知 / "Do Not Sell or Share My Personal Information"',
      '1798.185': 'CPPA (加州プライバシー保護機関) の規則制定権',
      '1798.199.10': '監督機関 CPPA 創設',
      'sensitive_categories': '医療/金融/ジオロケ/種族民族/通信内容/性自認/性的指向 11カテゴリ',
    },
    penalties_summary: '故意/未成年違反: 7,500USD/件 (CPPA 行政罰権限)',
    jp_counterpart: ['個情法R4改正 要配慮個人情報'],
  },
  {
    jurisdiction: 'UK',
    law_short: 'UK GDPR',
    law_full: 'UK General Data Protection Regulation (post-Brexit retained EU law)',
    effective_date: '2021-01-01',
    key_articles: {
      'identical': 'EU GDPR と実質同一。ただし監督機関は ICO (Information Commissioner\'s Office)',
      'adequacy': 'EU-UK 十分性決定 (2021-06-28) — 4年で再評価',
      'DPA-2018': '英 Data Protection Act 2018 と組合せ運用',
    },
    penalties_summary: 'GBP 17.5M 又は global turnover 4% (上位)',
    jp_counterpart: ['個情法'],
  },
];

/**
 * 同意要件比較
 */
export const CONSENT_COMPARISON = {
  GDPR: {
    standard: 'opt-in / freely given / specific / informed / unambiguous (Art.4(11))',
    withdrawal: 'as easy as giving (Art.7(3))',
    minors: '16歳未満は親権者同意 (加盟国により13まで引下可)',
  },
  CCPA: {
    standard: 'opt-out (販売拒否) + 16歳未満は opt-in',
    withdrawal: '販売拒否権の行使 (Do Not Sell)',
    minors: '13歳未満は親権者同意必須/13-16歳は本人同意',
  },
  APPI: {
    standard: '原則同意必須 (要配慮個人情報は明示同意)',
    withdrawal: '個別事項',
    minors: '判断能力なき場合は親権者同意',
  },
};

/**
 * データ越境移転規制比較
 */
export const CROSS_BORDER_TRANSFER = {
  GDPR: {
    mechanisms: ['Adequacy Decision', 'SCC (Standard Contractual Clauses) — 2021新版', 'BCR (Binding Corporate Rules)', 'Article 49 derogations'],
    japan_adequacy: '2019-01-23 双方向十分性決定発効',
  },
  CCPA: {
    mechanisms: ['契約で対応 (CCPA は本来 越境移転規制なし)'],
    note: '販売 (sale) の定義に注意',
  },
  APPI: {
    mechanisms: ['本人同意', '基準適合 (基準=GDPR/中国/シンガポール等25国 認定)', '相当措置 (個情委規則)'],
    rule: 'R2 改正 第28条 (越境提供のオプトイン同意)',
  },
};

export function compareJurisdictions(topic: keyof typeof CONSENT_COMPARISON | 'transfer'): unknown {
  if (topic === 'transfer') return CROSS_BORDER_TRANSFER;
  return CONSENT_COMPARISON[topic];
}

export function findRuleByJurisdiction(j: ComparativeLawRule['jurisdiction']): ComparativeLawRule[] {
  return GDPR_CCPA_RULES.filter((r) => r.jurisdiction === j);
}

export function countGdprCcpaRules(): { total: number; by_jurisdiction: Record<string, number>; total_articles: number } {
  const byJ: Record<string, number> = {};
  let arts = 0;
  for (const r of GDPR_CCPA_RULES) {
    byJ[r.jurisdiction] = (byJ[r.jurisdiction] ?? 0) + 1;
    arts += Object.keys(r.key_articles).length;
  }
  return { total: GDPR_CCPA_RULES.length, by_jurisdiction: byJ, total_articles: arts };
}
