/**
 * Phase 46-LU-6 / Legal API Gateway
 *
 * Phase 46-LU 系列の機能を REST API として外部公開するエンドポイント定義。
 * Express / Hono / Fastify など任意のフレームワークから adapt 可能な抽象構造。
 *
 * 認証/認可は別レイヤー (Bearer API Key) で実施。
 */

import type { PlanTier, PremiumFeature } from '../subscription/plans_catalog';

export type HttpMethod = 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH';

export interface ApiEndpoint {
  endpoint_id: string;
  method: HttpMethod;
  path: string;
  description: string;
  request_body_schema?: Record<string, string>; // 型名 (zod スキーマで実装)
  response_schema?: Record<string, string>;
  /** 必要プラン (これ以上必須) */
  min_plan: PlanTier;
  /** 必要プレミアム機能 (あれば) */
  required_feature?: PremiumFeature;
  /** クォータ消費 (該当カウンターに 1 加算) */
  quota_field?:
    | 'rag_queries_per_month'
    | 'compliance_scans_per_month'
    | 'contracts_per_month'
    | 'risk_assessments_per_month'
    | 'exports_per_month';
  /** ドキュメント例 */
  example_request?: object;
  example_response?: object;
  /** 本機能の Phase 46-LU 内対応モジュール */
  underlying_module?: string;
}

export const API_ENDPOINTS: ApiEndpoint[] = [
  // ============ RAG 検索 ============
  {
    endpoint_id: 'rag.search',
    method: 'POST',
    path: '/api/v1/legal/rag/search',
    description: '法令/判例/通達 を BM25+RRF で検索',
    request_body_schema: { query: 'string', k: 'number?', filter: 'object?' },
    response_schema: { results: 'RetrievalResult[]' },
    min_plan: 'free',
    quota_field: 'rag_queries_per_month',
    example_request: { query: '民法415条の判例', k: 5 },
    example_response: { results: [{ doc: { short_name: '民法第415条', citation: '...' }, score: 8.5 }] },
    underlying_module: 'legal_rag/embedding_index.ts',
  },
  {
    endpoint_id: 'rag.qa',
    method: 'POST',
    path: '/api/v1/legal/qa',
    description: '自然言語法務QA (RAG + LLMプロンプト)',
    request_body_schema: { question: 'string', locale: 'ja|en|zh-CN?' },
    response_schema: { answer: 'string', citations: 'Citation[]', confidence: 'number' },
    min_plan: 'pro',
    quota_field: 'rag_queries_per_month',
    underlying_module: 'legal_rag/llm_prompt_builder.ts + corpus/legal_qa_engine.ts',
  },

  // ============ Compliance ============
  {
    endpoint_id: 'compliance.scan_code',
    method: 'POST',
    path: '/api/v1/legal/compliance/scan',
    description: 'TS/JS コードを 17ルールでコンプライアンススキャン',
    request_body_schema: { code: 'string', file_hint: 'string?' },
    response_schema: { findings: 'ComplianceFinding[]', compliance_score: 'number' },
    min_plan: 'free',
    quota_field: 'compliance_scans_per_month',
    example_request: { code: 'console.log(user.myNumber)', file_hint: 'app.tsx' },
    underlying_module: 'compliance/code_compliance_scanner.ts',
  },
  {
    endpoint_id: 'compliance.custom_rule',
    method: 'POST',
    path: '/api/v1/legal/compliance/rules',
    description: 'カスタムコンプラルール登録',
    min_plan: 'enterprise',
    required_feature: 'custom_compliance_rules',
    underlying_module: 'compliance/code_compliance_scanner.ts',
  },

  // ============ Contracts ============
  {
    endpoint_id: 'contracts.generate',
    method: 'POST',
    path: '/api/v1/legal/contracts/generate',
    description: '契約書テンプレ生成 (NDA/業務委託/SES等)',
    request_body_schema: { kind: 'nda|consulting_jun_inin|ses|...', parties_override: 'string?', only_clauses: 'string[]?', format: 'markdown|plain|json?' },
    response_schema: { rendered: 'string', clauses_used: 'number' },
    min_plan: 'pro',
    quota_field: 'contracts_per_month',
    underlying_module: 'contracts/contract_clause_generator.ts',
  },

  // ============ Risk ============
  {
    endpoint_id: 'risk.assess',
    method: 'POST',
    path: '/api/v1/legal/risk/assess',
    description: '法務リスク評価 (5次元 + 業種別係数 + 損害額推定)',
    request_body_schema: { scenario: 'string', industry: 'string', pii_volume: 'number?', international: 'boolean?' },
    response_schema: { overall_score: 'number', level: 'low|medium|high|critical', dimensions: 'DimensionScore[]' },
    min_plan: 'pro',
    quota_field: 'risk_assessments_per_month',
    underlying_module: 'risk/legal_risk_scoring.ts',
  },

  // ============ Citation ============
  {
    endpoint_id: 'citation.network',
    method: 'GET',
    path: '/api/v1/legal/cases/:caseId/citations',
    description: '判例の引用ネットワーク (descendants/ancestors)',
    response_schema: { node: 'CitationNode', descendants: 'CitationNode[]', ancestors: 'CitationNode[]' },
    min_plan: 'pro',
    required_feature: 'citation_network_full',
    underlying_module: 'citation/citation_network.ts',
  },

  // ============ Advisor ============
  {
    endpoint_id: 'advisor.ask',
    method: 'POST',
    path: '/api/v1/legal/advisor/ask',
    description: '法務AIアドバイザー (multi-turn 対応)',
    request_body_schema: { session_id: 'string?', message: 'string', industry: 'string?' },
    response_schema: { turn: 'AdvisorTurn', session_id: 'string' },
    min_plan: 'pro',
    required_feature: 'legal_advisor_multi_turn',
    underlying_module: 'advisor/legal_advisor.ts',
  },

  // ============ Omega Bridge ============
  {
    endpoint_id: 'bridge.omega_to_legal',
    method: 'POST',
    path: '/api/v1/legal/bridge/omega',
    description: 'ARTE-Omega 検出結果 → 法令マッピング + 報告義務',
    request_body_schema: { findings: 'OmegaFinding[]' },
    response_schema: { implications: 'LegalImplication[]', total_estimated_damage_jpy: 'number' },
    min_plan: 'enterprise',
    required_feature: 'omega_legal_bridge',
    underlying_module: 'bridge/omega_legal_bridge.ts',
  },

  // ============ Timeline ============
  {
    endpoint_id: 'timeline.law_events',
    method: 'GET',
    path: '/api/v1/legal/timeline/:lawShort',
    description: '法令の時系列イベント (公布/施行/改正)',
    min_plan: 'free',
    underlying_module: 'timeline/law_timeline.ts',
  },
  {
    endpoint_id: 'timeline.upcoming',
    method: 'GET',
    path: '/api/v1/legal/timeline/upcoming',
    description: '今後施行予定の法令イベント',
    min_plan: 'free',
    underlying_module: 'timeline/law_timeline.ts',
  },

  // ============ Cases (判例) ============
  {
    endpoint_id: 'cases.list',
    method: 'GET',
    path: '/api/v1/legal/cases',
    description: '判例一覧 (LANDMARK + EXTENDED + SUPPLEMENT 152件)',
    min_plan: 'free',
    underlying_module: 'corpus/case_law_extended.ts + supplement',
  },
  {
    endpoint_id: 'cases.detail',
    method: 'GET',
    path: '/api/v1/legal/cases/:caseId',
    description: '判例詳細',
    min_plan: 'free',
    underlying_module: 'corpus/judiciary_law_link.ts',
  },
  {
    endpoint_id: 'cases.mapping_current',
    method: 'GET',
    path: '/api/v1/legal/cases/:caseId/mapping',
    description: '旧判例 → 現行法 マッピング',
    min_plan: 'pro',
    underlying_module: 'mapping/case_to_current_law.ts',
  },

  // ============ Export ============
  {
    endpoint_id: 'export.pdf',
    method: 'POST',
    path: '/api/v1/legal/export/pdf',
    description: '判例/契約書/コンプラレポート PDF エクスポート',
    request_body_schema: { kind: 'case|contract|compliance|risk', payload: 'object' },
    response_schema: { url: 'string', expires_at: 'string' },
    min_plan: 'pro',
    quota_field: 'exports_per_month',
    underlying_module: 'export_engine/document_exporter.ts',
  },

  // ============ Alerts ============
  {
    endpoint_id: 'alerts.subscribe',
    method: 'POST',
    path: '/api/v1/legal/alerts/subscribe',
    description: '改正アラートメール購読',
    request_body_schema: { email: 'string', law_short_codes: 'string[]', frequency: 'realtime|daily|weekly' },
    min_plan: 'pro',
    required_feature: 'amendment_real_time_alert',
    underlying_module: 'email_alerts/amendment_alert_dispatcher.ts',
  },

  // ============ Webhook ============
  {
    endpoint_id: 'webhook.register',
    method: 'POST',
    path: '/api/v1/legal/webhooks',
    description: 'Webhook 登録 (Slack/Teams/Discord/カスタム)',
    request_body_schema: { url: 'string', events: 'string[]', secret: 'string?' },
    min_plan: 'pro',
    underlying_module: 'webhook/external_dispatcher.ts',
  },

  // ============ Admin (テナント管理者) ============
  {
    endpoint_id: 'tenant.create_child',
    method: 'POST',
    path: '/api/v1/legal/tenants/children',
    description: '子テナント作成 (法律事務所が顧客テナントを作る)',
    request_body_schema: { name: 'string', plan_tier: 'PlanTier', max_users: 'number' },
    min_plan: 'enterprise',
    underlying_module: 'multi_tenant/tenant_isolator.ts',
  },

  // ============ Billing ============
  {
    endpoint_id: 'billing.usage',
    method: 'GET',
    path: '/api/v1/legal/billing/usage',
    description: '現在の利用量とプラン上限',
    min_plan: 'free',
    underlying_module: 'billing/usage_metering.ts',
  },
];

export function findEndpoint(endpointId: string): ApiEndpoint | undefined {
  return API_ENDPOINTS.find((e) => e.endpoint_id === endpointId);
}

export function listEndpointsForPlan(plan: PlanTier, features: PremiumFeature[]): ApiEndpoint[] {
  const planOrder: PlanTier[] = ['free', 'pro', 'enterprise', 'legal_firm'];
  const planIdx = planOrder.indexOf(plan);
  return API_ENDPOINTS.filter((e) => {
    const minIdx = planOrder.indexOf(e.min_plan);
    if (planIdx < minIdx) return false;
    if (e.required_feature && !features.includes(e.required_feature)) return false;
    return true;
  });
}

export function generateOpenApiSummary(): {
  openapi: '3.0.3';
  info: { title: string; version: string; description: string };
  paths: Record<string, Record<string, { summary: string; description: string }>>;
} {
  const paths: Record<string, Record<string, { summary: string; description: string }>> = {};
  for (const e of API_ENDPOINTS) {
    if (!paths[e.path]) paths[e.path] = {};
    paths[e.path][e.method.toLowerCase()] = {
      summary: e.endpoint_id,
      description: e.description,
    };
  }
  return {
    openapi: '3.0.3',
    info: {
      title: 'SoloptiLinkAI Legal API',
      version: '1.0.0',
      description: 'Phase 46-LU-6 / Knowledge Productization Edition の REST API',
    },
    paths,
  };
}

export function countApiEndpoints(): { total: number; by_method: Record<HttpMethod, number>; by_plan: Record<PlanTier, number> } {
  const byMethod: Record<string, number> = {};
  const byPlan: Record<string, number> = {};
  for (const e of API_ENDPOINTS) {
    byMethod[e.method] = (byMethod[e.method] ?? 0) + 1;
    byPlan[e.min_plan] = (byPlan[e.min_plan] ?? 0) + 1;
  }
  return {
    total: API_ENDPOINTS.length,
    by_method: byMethod as Record<HttpMethod, number>,
    by_plan: byPlan as Record<PlanTier, number>,
  };
}
