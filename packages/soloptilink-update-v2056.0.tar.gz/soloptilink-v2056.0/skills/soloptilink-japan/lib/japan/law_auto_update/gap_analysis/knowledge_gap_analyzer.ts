/**
 * Phase 46-LU-3 / Knowledge Gap Analyzer
 *
 * 自分の知識網羅性を Tier × ドメイン × 機能のマトリックスで自己診断する。
 * 「抜け漏れはありませんか?」という問いに対し、構造化された答えを返すための核。
 *
 * 出力:
 *  - Tier 別カバレッジ (S/A/B/C/D)
 *  - ドメイン別カバレッジ (民事/刑事/行政/税/労働/知財/環境...)
 *  - 機能別完成度 (本文/判例/罰則/時効/出典/QA/RL)
 *  - 「あと N 件追加すれば Diamond」の推薦
 */

import { SIX_CODES, TIER_A_MAJOR_60 } from '../corpus/six_codes';
import { EXTENDED_LAW_CATALOG } from '../catalog_full';
import { LANDMARK_CASES_INDEX, countCasesByCategory } from '../corpus/judiciary_law_link';
import { SUPPLEMENTARY_CODES, countSupplementaryCodes } from '../corpus/supplementary_codes';
import { SPECIAL_CRIMINAL_LAWS, countSpecialCriminalLaws } from '../corpus/special_criminal_law';
import { INTERNATIONAL_TREATIES, countTreaties } from '../corpus/international_law';

export type GapDomain =
  | 'constitution'
  | 'civil'
  | 'commercial'
  | 'criminal'
  | 'civil_procedure'
  | 'criminal_procedure'
  | 'administrative'
  | 'tax'
  | 'labor'
  | 'ip'
  | 'finance'
  | 'consumer'
  | 'real_estate'
  | 'transport'
  | 'environment'
  | 'medical'
  | 'education'
  | 'agriculture'
  | 'cybersecurity'
  | 'international'
  | 'insolvency'
  | 'special_criminal'
  | 'private_international';

export interface GapAnalysisInput {
  /** 対象ドメインを限定する場合 */
  filterDomains?: GapDomain[];
  /** 目標 (Diamond到達ライン) */
  targetCases?: number;
  targetCatalogLaws?: number;
  targetSupplementary?: number;
}

export interface DomainCoverage {
  domain: GapDomain;
  catalog_count: number;
  case_count: number;
  has_article_summary: boolean;
  has_penalty_table: boolean;
  status: 'complete' | 'partial' | 'missing';
  recommendations: string[];
}

export interface KnowledgeGapReport {
  generated_at: string;
  overall: {
    six_codes_loaded: number;
    tier_a_major_loaded: number;
    catalog_loaded: number;
    supplementary_loaded: number;
    special_criminal_loaded: number;
    treaties_loaded: number;
    cases_loaded: number;
  };
  domains: DomainCoverage[];
  completeness_pct: number;
  gap_count: number;
  diamond_distance: {
    cases_needed: number;
    catalog_needed: number;
    supplementary_needed: number;
  };
  top_recommendations: string[];
}

const DOMAIN_TARGETS: Record<GapDomain, { cases: number; catalog: number; has_summary: boolean; has_penalty: boolean }> = {
  constitution: { cases: 10, catalog: 1, has_summary: true, has_penalty: false },
  civil: { cases: 12, catalog: 1, has_summary: true, has_penalty: false },
  commercial: { cases: 8, catalog: 2, has_summary: true, has_penalty: false },
  criminal: { cases: 10, catalog: 1, has_summary: true, has_penalty: true },
  civil_procedure: { cases: 4, catalog: 1, has_summary: true, has_penalty: false },
  criminal_procedure: { cases: 4, catalog: 1, has_summary: true, has_penalty: false },
  administrative: { cases: 8, catalog: 4, has_summary: true, has_penalty: false },
  tax: { cases: 6, catalog: 5, has_summary: true, has_penalty: true },
  labor: { cases: 8, catalog: 5, has_summary: true, has_penalty: false },
  ip: { cases: 10, catalog: 5, has_summary: true, has_penalty: false },
  finance: { cases: 4, catalog: 5, has_summary: true, has_penalty: true },
  consumer: { cases: 4, catalog: 4, has_summary: true, has_penalty: false },
  real_estate: { cases: 4, catalog: 3, has_summary: true, has_penalty: false },
  transport: { cases: 2, catalog: 2, has_summary: false, has_penalty: true },
  environment: { cases: 2, catalog: 3, has_summary: false, has_penalty: false },
  medical: { cases: 2, catalog: 3, has_summary: false, has_penalty: false },
  education: { cases: 1, catalog: 1, has_summary: false, has_penalty: false },
  agriculture: { cases: 1, catalog: 1, has_summary: false, has_penalty: false },
  cybersecurity: { cases: 1, catalog: 2, has_summary: false, has_penalty: false },
  international: { cases: 0, catalog: 20, has_summary: false, has_penalty: false },
  insolvency: { cases: 1, catalog: 4, has_summary: true, has_penalty: false },
  special_criminal: { cases: 4, catalog: 12, has_summary: false, has_penalty: true },
  private_international: { cases: 0, catalog: 3, has_summary: true, has_penalty: false },
};

const DOMAIN_TO_CATEGORY: Record<GapDomain, string[]> = {
  constitution: ['admin'],
  civil: ['real_estate', 'labor', 'consumer'],
  commercial: ['corporate'],
  criminal: ['admin'],
  civil_procedure: [],
  criminal_procedure: [],
  administrative: ['admin', 'public'],
  tax: ['tax'],
  labor: ['labor'],
  ip: ['patent', 'trademark', 'design', 'copyright', 'trade_secret'],
  finance: ['finance'],
  consumer: ['consumer'],
  real_estate: ['real_estate'],
  transport: ['transport'],
  environment: ['environment'],
  medical: ['medical', 'pharma', 'longterm_care'],
  education: ['admin'],
  agriculture: ['food'],
  cybersecurity: ['privacy'],
  international: [],
  insolvency: ['corporate'],
  special_criminal: ['admin', 'transport', 'pharma', 'privacy'],
  private_international: ['admin'],
};

/**
 * メイン: 知識網羅性を診断
 */
export function analyzeKnowledgeGaps(input: GapAnalysisInput = {}): KnowledgeGapReport {
  const casesCounts = countCasesByCategory();
  const supp = countSupplementaryCodes();
  const sclaw = countSpecialCriminalLaws();
  const treaties = countTreaties();
  const overall = {
    six_codes_loaded: SIX_CODES.length,
    tier_a_major_loaded: TIER_A_MAJOR_60.length,
    catalog_loaded: EXTENDED_LAW_CATALOG.length,
    supplementary_loaded: supp.total,
    special_criminal_loaded: sclaw.total,
    treaties_loaded: treaties.total,
    cases_loaded: LANDMARK_CASES_INDEX.length,
  };

  const domains: DomainCoverage[] = [];
  const filter = input.filterDomains;
  for (const d of Object.keys(DOMAIN_TARGETS) as GapDomain[]) {
    if (filter && !filter.includes(d)) continue;
    const target = DOMAIN_TARGETS[d];
    const cats = DOMAIN_TO_CATEGORY[d];
    let caseCount = 0;
    for (const cat of cats) caseCount += casesCounts[cat] ?? 0;
    const catalogCount = countCatalogLawsForDomain(d);
    const hasSummary = checkHasSummary(d);
    const hasPenalty = checkHasPenalty(d);

    const recommendations: string[] = [];
    let complete = true;
    if (caseCount < target.cases) {
      recommendations.push(`判例を ${target.cases - caseCount} 件追加 (target=${target.cases})`);
      complete = false;
    }
    if (catalogCount < target.catalog) {
      recommendations.push(`法令カタログを ${target.catalog - catalogCount} 件追加 (target=${target.catalog})`);
      complete = false;
    }
    if (target.has_summary && !hasSummary) {
      recommendations.push('主要条文の要約データを追加');
      complete = false;
    }
    if (target.has_penalty && !hasPenalty) {
      recommendations.push('罰則テーブル (penalties[]) を追加');
      complete = false;
    }

    const status: DomainCoverage['status'] =
      complete ? 'complete'
      : caseCount === 0 && catalogCount === 0 ? 'missing'
      : 'partial';

    domains.push({
      domain: d,
      catalog_count: catalogCount,
      case_count: caseCount,
      has_article_summary: hasSummary,
      has_penalty_table: hasPenalty,
      status,
      recommendations,
    });
  }

  const completeCount = domains.filter((d) => d.status === 'complete').length;
  const completenessPct = domains.length > 0 ? Math.round((completeCount / domains.length) * 1000) / 10 : 0;
  const gapCount = domains.reduce((acc, d) => acc + d.recommendations.length, 0);

  // Diamond ライン: 判例 80 / カタログ 60 / 補完 20
  const targetCases = input.targetCases ?? 80;
  const targetCatalog = input.targetCatalogLaws ?? 60;
  const targetSupp = input.targetSupplementary ?? 20;

  const diamondDistance = {
    cases_needed: Math.max(0, targetCases - overall.cases_loaded),
    catalog_needed: Math.max(0, targetCatalog - overall.catalog_loaded),
    supplementary_needed: Math.max(0, targetSupp - overall.supplementary_loaded),
  };

  const topRecs: string[] = [];
  domains
    .filter((d) => d.status !== 'complete')
    .sort((a, b) => b.recommendations.length - a.recommendations.length)
    .slice(0, 5)
    .forEach((d) => {
      topRecs.push(`[${d.domain}] ${d.recommendations.join(' / ')}`);
    });

  return {
    generated_at: new Date().toISOString(),
    overall,
    domains,
    completeness_pct: completenessPct,
    gap_count: gapCount,
    diamond_distance: diamondDistance,
    top_recommendations: topRecs,
  };
}

function countCatalogLawsForDomain(domain: GapDomain): number {
  const cats = DOMAIN_TO_CATEGORY[domain];
  if (cats.length === 0) {
    // 国際法 / 私法は別カウント
    if (domain === 'international') return INTERNATIONAL_TREATIES.length;
    if (domain === 'private_international') {
      return SUPPLEMENTARY_CODES.filter((c) => c.domain_group === 'private_international').length;
    }
    return 0;
  }
  let n = 0;
  for (const c of EXTENDED_LAW_CATALOG) {
    if (cats.includes(c.category as string)) n++;
  }
  // 補完法令も加算
  for (const s of SUPPLEMENTARY_CODES) {
    if (cats.includes(s.category as string)) n++;
  }
  if (domain === 'special_criminal') n += SPECIAL_CRIMINAL_LAWS.length;
  if (domain === 'insolvency') {
    n = SUPPLEMENTARY_CODES.filter((c) => c.domain_group === 'insolvency').length;
  }
  if (domain === 'administrative') {
    n += SUPPLEMENTARY_CODES.filter((c) => c.domain_group === 'administrative').length;
  }
  return n;
}

function checkHasSummary(domain: GapDomain): boolean {
  // 六法の要約は SIX_CODES から
  const sixCodeMap: Partial<Record<GapDomain, string>> = {
    constitution: 'constitution',
    civil: 'civil',
    commercial: 'commercial',
    criminal: 'penal',
    civil_procedure: 'civil_procedure',
    criminal_procedure: 'criminal_procedure',
  };
  const sixCode = sixCodeMap[domain];
  if (sixCode) {
    const entry = SIX_CODES.find((c) => c.code === sixCode);
    if (entry && Object.keys(entry.key_articles_summary).length > 0) return true;
  }
  // 補完法令の要約
  if (domain === 'administrative') {
    return SUPPLEMENTARY_CODES.some((c) => c.domain_group === 'administrative' && Object.keys(c.key_articles_summary).length > 0);
  }
  if (domain === 'insolvency') {
    return SUPPLEMENTARY_CODES.some((c) => c.domain_group === 'insolvency' && Object.keys(c.key_articles_summary).length > 0);
  }
  if (domain === 'private_international') {
    return SUPPLEMENTARY_CODES.some((c) => c.domain_group === 'private_international' && Object.keys(c.key_articles_summary).length > 0);
  }
  if (domain === 'real_estate' || domain === 'consumer' || domain === 'labor' || domain === 'finance') {
    return SUPPLEMENTARY_CODES.some((c) => c.category === domain.replace('_', '') || c.domain_group === 'special_civil');
  }
  return false;
}

function checkHasPenalty(domain: GapDomain): boolean {
  if (domain === 'special_criminal' || domain === 'criminal' || domain === 'transport') {
    return SPECIAL_CRIMINAL_LAWS.some((l) => l.penalties.length > 0);
  }
  return false;
}

/**
 * テキストレポートを生成
 */
export function renderGapReport(report: KnowledgeGapReport): string {
  const lines: string[] = [];
  lines.push('==================================================');
  lines.push('  Knowledge Gap Analysis Report (Phase 46-LU-3)');
  lines.push('==================================================');
  lines.push(`  generated: ${report.generated_at}`);
  lines.push('');
  lines.push('[Overall Loaded]');
  for (const k of Object.keys(report.overall)) {
    lines.push(`  ${k.padEnd(28)} : ${(report.overall as Record<string, number>)[k]}`);
  }
  lines.push('');
  lines.push(`[Completeness] ${report.completeness_pct}% (${report.gap_count} gaps)`);
  lines.push('');
  lines.push('[Domain Breakdown]');
  for (const d of report.domains) {
    const icon = d.status === 'complete' ? '✓' : d.status === 'partial' ? '○' : '×';
    lines.push(`  ${icon} ${d.domain.padEnd(22)} catalog=${String(d.catalog_count).padStart(3)} cases=${String(d.case_count).padStart(3)} summary=${d.has_article_summary ? 'Y' : 'N'} penalty=${d.has_penalty_table ? 'Y' : 'N'}`);
    for (const r of d.recommendations) lines.push(`      → ${r}`);
  }
  lines.push('');
  lines.push('[Diamond Distance]');
  lines.push(`  cases:        +${report.diamond_distance.cases_needed}`);
  lines.push(`  catalog:      +${report.diamond_distance.catalog_needed}`);
  lines.push(`  supplementary:+${report.diamond_distance.supplementary_needed}`);
  lines.push('');
  lines.push('[Top Recommendations]');
  for (const r of report.top_recommendations) lines.push(`  - ${r}`);
  lines.push('==================================================');
  return lines.join('\n');
}
