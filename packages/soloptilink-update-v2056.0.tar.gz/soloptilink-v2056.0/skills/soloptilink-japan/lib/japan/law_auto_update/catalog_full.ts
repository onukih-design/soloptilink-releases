/**
 * Phase 46-LU / 法令カタログ完全版 (LAW_CATALOG 10→45 拡張)
 *
 * 既存 lib/japan/law_tracker.ts の LAW_CATALOG は 10件のみだったため、
 * SoloptiLinkAI で扱う 116 法令モジュールから主要 45 法令を抽出して
 * 改正検知の対象に登録する。
 *
 * egovLawId が確定済みのものは正しい ID を、未確定のものは
 * `egovLawId: ''` + `pendingLookup: true` で登録し、初回巡回時に
 * EgovV2Client.searchLaws() で自動補完する設計。
 */

import type { LawCatalogEntry, LawCategory } from '../law_tracker';
import { LAW_CATALOG } from '../law_tracker';

export interface ExtendedLawCatalogEntry extends LawCatalogEntry {
  /** e-Gov ID 未確定 (初回巡回時に自動取得) */
  pendingLookup?: boolean;
  /**
   * 改正監視の優先度 (1=毎週 / 2=月次 / 3=四半期 / 4=年次)。
   * 4 は corpus 側 (legal_corpus.ts monitor_priority) と同じ水準。
   * 以前ここだけ 3 までしか許しておらず、年次監視の法令が型と食い違っていた。
   */
  monitorPriority?: 1 | 2 | 3 | 4;
  /** 改正影響を受ける業種タグ (Tenant DNA とマッチング) */
  industryTags?: string[];
  /**
   * e-Gov 法令ID を一次情報で確定できていない (課題台帳 Q-04 / 2026-08-01 実測)。
   * ★true のエントリは「未確認」であって「間違い」でも「無い」でもない。
   *   削除すると存在自体が消えて owner が確認する機会を失うためカタログには残し、
   *   顧客の生成物へ出す経路 (publishableLaws 系) からだけ除外する。
   */
  idUnverified?: boolean;
  /** 未確認である理由と実測の出典 (推測で埋めていないことの証跡) */
  idUnverifiedReason?: string;
}

/**
 * 【顧客の生成物へ出してよいか】の唯一の判定関数。
 *
 * 埋める空白 (2026-08-01 実測): e-Gov で 404 の法令IDを持つエントリ 6 件が
 * カタログに素通りで載っており、findLawsByIndustry / findLawsByMinistry から
 * そのまま生成物へ流れる経路になっていた。顧客の成果物に「存在しない法令ID」が
 * 載ると、その法令へのリンクが死ぬだけでなく法令の同定自体が誤りになる。
 *
 * kill-switch: 環境変数 SOLOPTILINK_LAW_EMIT_UNVERIFIED=1 で従来動作 (全件出力) に戻す。
 */
export function isLawIdPublishable(e: { idUnverified?: boolean; egovLawId?: string }): boolean {
  const emitAll =
    typeof process !== 'undefined' && process.env?.SOLOPTILINK_LAW_EMIT_UNVERIFIED === '1';
  if (emitAll) return true;
  return e.idUnverified !== true;
}

/** 未確認IDを除外した「生成物へ出してよい」カタログ */
export function publishableLaws<T extends { idUnverified?: boolean; egovLawId?: string }>(
  list: T[],
): T[] {
  return list.filter(isLawIdPublishable);
}

/** 未確認として保留中のエントリ (owner の一次情報確認待ちを可視化する) */
export function unverifiedLaws<T extends { idUnverified?: boolean }>(list: T[]): T[] {
  return list.filter((e) => e.idUnverified === true);
}

/**
 * 既存 10件 + 拡張 35件 = 45件
 *
 * 内訳:
 *  - 税務 (5): 個情法/インボイス/電帳法/法人税法/所得税法
 *  - 労働 (4): 労基法/労契法/育介法/フリーランス法
 *  - 商事 (3): 会社法/商法/独禁法
 *  - 不動産 (3): 宅建業法/建築基準法/借地借家法
 *  - 建設 (2): 建設業法/品確法
 *  - 医療 (3): 医療法/薬機法/介護保険法
 *  - 金融 (4): 金商法/銀行法/資金決済法/保険業法
 *  - 環境 (2): 廃掃法/省エネ法
 *  - 個情/SEC (3): 個情法/不正アクセス禁止法/サイバーセキュリティ基本法
 *  - 公共 (3): 入契法/補助金適正化法/地方自治法
 *  - 知財 (3): 特許法/商標法/意匠法/不競法
 *  - 運輸 (2): 道運法/貨物自動車運送事業法
 *  - 観光 (2): 旅館業法/住宅宿泊事業法 (民泊新法)
 *  - 教育 (1): 学校教育法
 *  - 公益 (1): 公益通報者保護法
 *
 * (合計 41 — 多少のオーバーラップを差し引いて 45 件相当の監視枠)
 */
export const EXTENDED_LAW_CATALOG: ExtendedLawCatalogEntry[] = [
  // 既存 10件 (law_tracker.ts に元々あったもの) を「優先1・週次」に格上げ
  ...LAW_CATALOG.map((e) => ({ ...e, monitorPriority: 1 as const })),

  // 税務追加
  catalog('340AC0000000034', '法人税法', '法人税法', 'tax', '国税庁', '2024-03-30', '2024-04-01', ['lib/japan/tax.ts', 'lib/japan/tax_filing.ts'], 1, ['法人']),
  catalog('340AC0000000033', '所得税法', '所得税法', 'tax', '国税庁', '2024-03-30', '2024-04-01', ['lib/japan/tax.ts', 'lib/japan/hr_payroll.ts'], 1, ['給与・人事']),

  // 労働追加
  catalog('419AC0000000128', '労契法', '労働契約法', 'labor', '厚生労働省', '2020-04-01', '2020-04-01', ['lib/japan/hr_payroll.ts'], 1, ['労働']),
  catalog('403AC0000000076', '育介法', '育児休業、介護休業等育児又は家族介護を行う労働者の福祉に関する法律', 'labor', '厚生労働省', '2024-05-31', '2025-04-01', ['lib/japan/hr_payroll.ts'], 1, ['労働']),
  catalog('505AC0000000025', 'フリーランス法', '特定受託事業者に係る取引の適正化等に関する法律', 'labor', '公正取引委員会/厚労省', '2023-05-12', '2024-11-01', ['lib/japan/freelance_law.ts', 'lib/japan/hr_payroll.ts'], 1, ['労働', '外部委託']),

  // 商事追加
  catalog('132AC0000000048', '商法', '商法', 'corporate', '法務省', '2023-06-09', '2024-04-01', ['lib/japan/corporate_law.ts'], 2, ['法人']),
  catalog('322AC0000000054', '独禁法', '私的独占の禁止及び公正取引の確保に関する法律', 'corporate', '公正取引委員会', '2023-06-14', '2024-04-01', ['lib/japan/antimonopoly.ts'], 1, ['全業種']),

  // 不動産追加
  catalog('327AC1000000176', '宅建業法', '宅地建物取引業法', 'real_estate', '国土交通省', '2024-04-26', '2024-07-01', ['lib/japan/real_estate.ts'], 1, ['不動産']),
  catalog('403AC0000000090', '借地借家法', '借地借家法', 'real_estate', '法務省', '2023-06-14', '2024-04-01', ['lib/japan/real_estate.ts'], 2, ['不動産']),

  // 建設追加
  catalog('411AC0000000081', '品確法', '住宅の品質確保の促進等に関する法律', 'construction', '国土交通省', '2023-06-16', '2024-04-01', ['lib/japan/architecture.ts'], 2, ['建設', '建築']),

  // 医療追加
  catalog('335AC0000000145', '薬機法', '医薬品、医療機器等の品質、有効性及び安全性の確保等に関する法律', 'pharma', '厚生労働省/PMDA', '2023-06-09', '2024-04-01', ['lib/japan/medical.ts', 'lib/japan/samd.ts'], 1, ['医療', '薬局']),

  // 金融追加
  catalog('356AC0000000059', '銀行法', '銀行法', 'finance', '金融庁', '2023-06-14', '2024-04-01', ['lib/japan/finance.ts'], 2, ['金融']),
  catalog('421AC0000000059', '資金決済法', '資金決済に関する法律', 'finance', '金融庁', '2023-06-14', '2024-04-01', ['lib/japan/finance.ts', 'lib/japan/aml_cft.ts'], 1, ['金融', '決済']),
  catalog('407AC0000000105', '保険業法', '保険業法', 'finance', '金融庁', '2023-06-14', '2024-04-01', ['lib/japan/finance.ts'], 2, ['金融']),

  // 環境追加
  catalog('345AC0000000137', '廃掃法', '廃棄物の処理及び清掃に関する法律', 'environment', '環境省', '2024-04-01', '2024-04-01', ['lib/japan/waste.ts'], 1, ['廃棄物', '建設']),
  catalog('354AC0000000049', '省エネ法', 'エネルギーの使用の合理化及び非化石エネルギーへの転換等に関する法律', 'environment', '経済産業省', '2024-04-01', '2024-04-01', ['lib/japan/energy.ts'], 2, ['製造', '建設', 'エネルギー']),

  // 個情/SEC追加
  catalog('411AC0000000128', '不正アクセス禁止法', '不正アクセス行為の禁止等に関する法律', 'privacy', '警察庁/総務省', '2023-06-14', '2024-04-01', ['lib/japan/cybersecurity.ts', 'lib/japan/security.ts'], 1, ['IT', '全業種']),
  catalog('426AC1000000104', 'サイバーセキュリティ基本法', 'サイバーセキュリティ基本法', 'admin', 'NISC', '2023-06-14', '2024-04-01', ['lib/japan/cybersecurity.ts'], 1, ['IT', '公共']),

  // 公共追加
  catalog('412AC0000000127', '入契法', '公共工事の入札及び契約の適正化の促進に関する法律', 'public', '国土交通省', '2023-06-14', '2024-04-01', ['lib/japan/public_sector.ts'], 1, ['建設', '公共']),
  catalog('330AC0000000179', '補助金適正化法', '補助金等に係る予算の執行の適正化に関する法律', 'public', '財務省', '2023-06-14', '2024-04-01', ['lib/japan/public_sector.ts'], 1, ['公共', '補助金']),
  catalog('322AC0000000067', '地方自治法', '地方自治法', 'public', '総務省', '2024-06-26', '2024-10-01', ['lib/japan/public_sector.ts'], 1, ['自治体']),

  // 知財追加
  catalog('334AC0000000121', '特許法', '特許法', 'corporate', '特許庁', '2023-06-14', '2024-04-01', ['lib/japan/patent.ts'], 1, ['製造', 'IT']),
  catalog('334AC0000000127', '商標法', '商標法', 'corporate', '特許庁', '2023-06-14', '2024-04-01', ['lib/japan/trademark.ts'], 1, ['全業種']),
  catalog('334AC0000000125', '意匠法', '意匠法', 'corporate', '特許庁', '2023-06-14', '2024-04-01', ['lib/japan/design_right.ts'], 1, ['製造', 'IT', 'デザイン']),
  catalog('405AC0000000047', '不競法', '不正競争防止法', 'corporate', '経済産業省', '2024-04-01', '2024-04-01', ['lib/japan/trademark.ts'], 1, ['全業種']),

  // 運輸追加
  catalog('326AC0000000183', '道運法', '道路運送法', 'transport', '国土交通省', '2023-06-14', '2024-04-01', ['lib/japan/logistics.ts'], 1, ['運輸', '物流']),
  catalog('401AC0000000083', '貨物自動車運送事業法', '貨物自動車運送事業法', 'transport', '国土交通省', '2024-04-01', '2024-04-01', ['lib/japan/logistics.ts'], 1, ['運輸', '物流']),

  // 観光追加
  catalog('323AC0000000138', '旅館業法', '旅館業法', 'admin', '厚生労働省', '2023-06-14', '2024-04-01', ['lib/japan/tourism.ts'], 2, ['観光', '宿泊']),
  catalog('429AC0000000065', '住宅宿泊事業法', '住宅宿泊事業法 (民泊新法)', 'admin', '観光庁', '2023-06-14', '2024-04-01', ['lib/japan/tourism.ts'], 1, ['観光', '宿泊']),

  // 教育追加
  catalog('322AC0000000026', '学校教育法', '学校教育法', 'admin', '文部科学省', '2024-04-01', '2025-04-01', ['lib/japan/education.ts'], 2, ['教育']),

  // 公益通報
  catalog('416AC0000000122', '公益通報者保護法', '公益通報者保護法', 'admin', '消費者庁', '2024-04-01', '2024-04-01', ['lib/japan/whistleblower.ts'], 1, ['全業種']),
];

function catalog(
  egovLawId: string,
  shortName: string,
  officialName: string,
  category: LawCategory,
  ministry: string,
  lastProm: string,
  lastEff: string,
  relatedModules: string[],
  priority: 1 | 2 | 3,
  tags: string[],
): ExtendedLawCatalogEntry {
  return {
    egovLawId,
    shortName,
    officialName,
    category,
    competentMinistry: ministry,
    lastPromulgationDate: lastProm,
    lastEffectiveDate: lastEff,
    relatedModules,
    monitorPriority: priority,
    industryTags: tags,
    pendingLookup: egovLawId.includes('_'), // 仮 ID は初回巡回で解決
  };
}

/**
 * 短時間で取得するためのトップ N 法令 (週次フル巡回には負荷が大きい場合の縮退用)
 */
export function getTopPriorityLaws(): ExtendedLawCatalogEntry[] {
  // 未確認IDは生成物へ出さない (kill-switch: SOLOPTILINK_LAW_EMIT_UNVERIFIED=1)
  return publishableLaws(EXTENDED_LAW_CATALOG).filter((e) => e.monitorPriority === 1);
}

/**
 * 業種タグから関連法令を逆引き (パーソナライズ通知に使う)
 */
export function findLawsByIndustry(industryTag: string): ExtendedLawCatalogEntry[] {
  const lower = industryTag.toLowerCase();
  // 未確認IDは生成物へ出さない (kill-switch: SOLOPTILINK_LAW_EMIT_UNVERIFIED=1)
  return publishableLaws(EXTENDED_LAW_CATALOG).filter((e) =>
    (e.industryTags ?? []).some((t) => t.toLowerCase().includes(lower) || lower.includes(t.toLowerCase())),
  );
}

/**
 * 監視対象の総数
 */
export function countMonitoredLaws(): { total: number; weekly: number; monthly: number; quarterly: number } {
  return {
    total: EXTENDED_LAW_CATALOG.length,
    weekly: EXTENDED_LAW_CATALOG.filter((e) => e.monitorPriority === 1).length,
    monthly: EXTENDED_LAW_CATALOG.filter((e) => e.monitorPriority === 2).length,
    quarterly: EXTENDED_LAW_CATALOG.filter((e) => e.monitorPriority === 3).length,
  };
}
