/**
 * Phase 46-LU-7 / Regulator Liaison
 *
 * 規制当局 (個情委 / JPCERT/CC / ACDA / 警察庁 / 金融庁 / 厚労省 / 公取委 etc.)
 * への法定報告書を自動生成する。
 *
 *  - 個情法第26条 漏えい等の報告 (個情委)
 *  - JPCERT/CC 早期警戒情報
 *  - サイバー攻撃インシデント報告 (ACDA / 警察庁)
 *  - 重要インフラ事業者報告 (NISC)
 *  - 金融機関インシデント (金融庁)
 *
 * 出力: 各規制当局の指定書式 (PDF/XML/JSON)
 */

export type RegulatoryAgency =
  | 'ppc'              // 個人情報保護委員会
  | 'jpcert_cc'        // JPCERT/CC
  | 'acda'             // 能動的サイバー防御庁 (R7.4新設)
  | 'nisc'             // NISC
  | 'fsa'              // 金融庁
  | 'mhlw'             // 厚労省
  | 'jftc'             // 公正取引委員会
  | 'mlit'             // 国土交通省
  | 'pmda'             // 医薬品医療機器総合機構
  | 'police_cyber';    // 警察庁サイバー対策係

export interface RegulatoryReport {
  report_id: string;
  agency: RegulatoryAgency;
  category: string;
  /** 提出主体 */
  filer_organization: string;
  filer_contact: { name: string; title: string; email: string; phone: string };
  /** 事案 */
  incident_id?: string;
  incident_summary: string;
  /** 発生・覚知日時 */
  occurred_at: string;
  detected_at: string;
  /** 影響範囲 */
  affected_data_subjects?: number;
  affected_data_categories?: string[];
  /** 対応状況 */
  mitigation_taken: string[];
  /** 再発防止策 */
  preventive_measures: string[];
  /** 法的根拠 */
  legal_basis: string;
  /** 締切 */
  deadline_at: string;
  status: 'draft' | 'submitted' | 'acknowledged';
  /** 添付ファイル */
  attachments?: Array<{ name: string; size_bytes: number }>;
  /** 提出書式 */
  output_format: 'pdf' | 'xml' | 'json' | 'web_form';
  generated_at: string;
}

const REPORTS = new Map<string, RegulatoryReport>();

/**
 * 個情法第26条 漏えい等の報告 (個情委向け 速報 72時間以内 / 確報 30日以内)
 */
export function generatePpcLeakageReport(input: {
  filer_organization: string;
  filer_contact: RegulatoryReport['filer_contact'];
  incident_summary: string;
  occurred_at: string;
  detected_at: string;
  affected_data_subjects: number;
  affected_data_categories: string[];
  is_sensitive_data?: boolean;
  is_initial?: boolean; // 速報 (true) / 確報 (false)
}): RegulatoryReport {
  const isInitial = input.is_initial ?? true;
  const deadlineHours = isInitial ? 72 : 30 * 24;
  const deadline = new Date(input.detected_at);
  deadline.setHours(deadline.getHours() + deadlineHours);

  // 個情法26条 報告対象判定
  const reportable =
    input.affected_data_subjects >= 1000 // 1000人超
    || input.is_sensitive_data === true // 要配慮個人情報
    || input.affected_data_categories.includes('クレジットカード番号')
    || input.affected_data_categories.includes('財産的被害');

  const report: RegulatoryReport = {
    report_id: `ppc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    agency: 'ppc',
    category: isInitial ? '速報 (個情法26条 R4改正)' : '確報 (個情法26条 R4改正)',
    filer_organization: input.filer_organization,
    filer_contact: input.filer_contact,
    incident_summary: input.incident_summary,
    occurred_at: input.occurred_at,
    detected_at: input.detected_at,
    affected_data_subjects: input.affected_data_subjects,
    affected_data_categories: input.affected_data_categories,
    mitigation_taken: ['影響範囲の特定', '不正アクセス経路の遮断', '影響本人への通知準備'],
    preventive_measures: ['アクセス制御の見直し', '監査ログの強化', '従業員教育'],
    legal_basis: `個人情報保護法第26条 R4改正${reportable ? ' (報告対象事案に該当)' : ' (任意報告)'}`,
    deadline_at: deadline.toISOString(),
    status: 'draft',
    output_format: 'web_form', // 個情委は PPC ポータル経由
    generated_at: new Date().toISOString(),
  };
  REPORTS.set(report.report_id, report);
  return report;
}

/**
 * JPCERT/CC 早期警戒情報報告
 */
export function generateJpcertReport(input: {
  filer_organization: string;
  filer_contact: RegulatoryReport['filer_contact'];
  incident_summary: string;
  occurred_at: string;
  detected_at: string;
  attack_vector: string;
  ioc_observed: string[];
}): RegulatoryReport {
  const deadline = new Date(input.detected_at);
  deadline.setHours(deadline.getHours() + 24);
  const report: RegulatoryReport = {
    report_id: `jpcert_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    agency: 'jpcert_cc',
    category: '早期警戒情報',
    filer_organization: input.filer_organization,
    filer_contact: input.filer_contact,
    incident_summary: `${input.incident_summary} / 攻撃ベクター: ${input.attack_vector}`,
    occurred_at: input.occurred_at,
    detected_at: input.detected_at,
    mitigation_taken: ['通信の遮断', '攻撃元のブロック', 'マルウェア駆除'],
    preventive_measures: ['IOC 共有', 'WAF ルール追加', 'EDR シグネチャ更新'],
    legal_basis: 'JPCERT/CC 早期警戒情報運用要綱',
    deadline_at: deadline.toISOString(),
    status: 'draft',
    output_format: 'json',
    attachments: input.ioc_observed.map((ioc) => ({ name: `ioc_${ioc.slice(0, 10)}.txt`, size_bytes: ioc.length })),
    generated_at: new Date().toISOString(),
  };
  REPORTS.set(report.report_id, report);
  return report;
}

/**
 * ACDA 能動的サイバー防御 (R7.4新設)
 */
export function generateAcdaReport(input: {
  filer_organization: string;
  filer_contact: RegulatoryReport['filer_contact'];
  incident_summary: string;
  occurred_at: string;
  detected_at: string;
  is_critical_infrastructure: boolean;
  affected_services: string[];
}): RegulatoryReport {
  const deadline = new Date(input.detected_at);
  // 重要インフラは即時、それ以外は速やかに (48時間目安)
  deadline.setHours(deadline.getHours() + (input.is_critical_infrastructure ? 6 : 48));
  const report: RegulatoryReport = {
    report_id: `acda_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    agency: 'acda',
    category: '能動的サイバー防御法 (R7.4施行)',
    filer_organization: input.filer_organization,
    filer_contact: input.filer_contact,
    incident_summary: input.incident_summary,
    occurred_at: input.occurred_at,
    detected_at: input.detected_at,
    affected_data_categories: input.affected_services,
    mitigation_taken: ['攻撃元の特定', '通信ログの保全', 'ACDA 連携準備'],
    preventive_measures: ['脆弱性パッチ適用', 'NW セグメンテーション強化'],
    legal_basis: '能動的サイバー防御法 (R6 制定 R7.4 施行)',
    deadline_at: deadline.toISOString(),
    status: 'draft',
    output_format: 'xml',
    generated_at: new Date().toISOString(),
  };
  REPORTS.set(report.report_id, report);
  return report;
}

/**
 * 金融庁インシデント報告 (主要行/監督指針)
 */
export function generateFsaReport(input: {
  filer_organization: string;
  filer_contact: RegulatoryReport['filer_contact'];
  incident_summary: string;
  occurred_at: string;
  detected_at: string;
  customer_loss_jpy: number;
}): RegulatoryReport {
  const deadline = new Date(input.detected_at);
  deadline.setHours(deadline.getHours() + 24);
  const report: RegulatoryReport = {
    report_id: `fsa_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    agency: 'fsa',
    category: '金融機関インシデント報告 (主要行向け監督指針)',
    filer_organization: input.filer_organization,
    filer_contact: input.filer_contact,
    incident_summary: `${input.incident_summary} / 顧客損害推計: ¥${input.customer_loss_jpy.toLocaleString()}`,
    occurred_at: input.occurred_at,
    detected_at: input.detected_at,
    mitigation_taken: ['取引停止', '影響顧客への通知', 'システム復旧'],
    preventive_measures: ['FISC 安全対策基準準拠強化', '内部統制 (J-SOX) 強化'],
    legal_basis: '銀行法第26条 + 主要行向け監督指針 III-3 + FISC 安全対策基準',
    deadline_at: deadline.toISOString(),
    status: 'draft',
    output_format: 'pdf',
    generated_at: new Date().toISOString(),
  };
  REPORTS.set(report.report_id, report);
  return report;
}

/**
 * Markdown 形式の報告書出力
 */
export function renderReportMarkdown(report: RegulatoryReport): string {
  const lines: string[] = [];
  lines.push(`# 規制当局報告書: ${report.category}`);
  lines.push('');
  lines.push(`- 報告先: ${agencyName(report.agency)}`);
  lines.push(`- 報告者: ${report.filer_organization}`);
  lines.push(`- 担当: ${report.filer_contact.name} (${report.filer_contact.title}) — ${report.filer_contact.email}`);
  lines.push(`- 発生日時: ${report.occurred_at}`);
  lines.push(`- 覚知日時: ${report.detected_at}`);
  lines.push(`- 締切: ${report.deadline_at}`);
  lines.push(`- 法的根拠: ${report.legal_basis}`);
  lines.push('');
  lines.push('## 事案概要');
  lines.push(report.incident_summary);
  lines.push('');
  if (report.affected_data_subjects) {
    lines.push(`## 影響範囲`);
    lines.push(`- 影響人数: ${report.affected_data_subjects.toLocaleString()} 名`);
    if (report.affected_data_categories) {
      lines.push(`- 影響データ種別: ${report.affected_data_categories.join(' / ')}`);
    }
    lines.push('');
  }
  lines.push('## 実施済み対応');
  for (const m of report.mitigation_taken) lines.push(`- ${m}`);
  lines.push('');
  lines.push('## 再発防止策');
  for (const p of report.preventive_measures) lines.push(`- ${p}`);
  lines.push('');
  lines.push(`> 生成日時: ${report.generated_at}`);
  lines.push(`> 出力形式: ${report.output_format} / 状態: ${report.status}`);
  return lines.join('\n');
}

function agencyName(agency: RegulatoryAgency): string {
  const map: Record<RegulatoryAgency, string> = {
    ppc: '個人情報保護委員会',
    jpcert_cc: 'JPCERT/CC',
    acda: '能動的サイバー防御庁 (ACDA)',
    nisc: '内閣サイバーセキュリティセンター (NISC)',
    fsa: '金融庁',
    mhlw: '厚生労働省',
    jftc: '公正取引委員会',
    mlit: '国土交通省',
    pmda: '医薬品医療機器総合機構 (PMDA)',
    police_cyber: '警察庁サイバー対策係',
  };
  return map[agency];
}

export function submitReport(report_id: string): boolean {
  const r = REPORTS.get(report_id);
  if (!r) return false;
  r.status = 'submitted';
  return true;
}

export function countReports(): { total: number; by_agency: Record<string, number>; by_status: Record<string, number> } {
  const byAgency: Record<string, number> = {};
  const byStatus: Record<string, number> = {};
  for (const r of REPORTS.values()) {
    byAgency[r.agency] = (byAgency[r.agency] ?? 0) + 1;
    byStatus[r.status] = (byStatus[r.status] ?? 0) + 1;
  }
  return { total: REPORTS.size, by_agency: byAgency, by_status: byStatus };
}

export function _resetRegulatorReportsForTests(): void {
  REPORTS.clear();
}
