/**
 * Phase 46-LU-2 / Reward Learner (強化学習エンジン)
 *
 * 「報酬を学習」というユーザー指示への構造的応答。
 * 改正検知 → 通知 → PR提案 → ユーザー応答 のループから
 * 報酬を蓄積し、関連度判定の重みを更新する。
 *
 * 報酬モデル:
 *  - PR がマージされた               +10
 *  - PR が approved 状態になった     +5
 *  - 通知が開封された                 +2
 *  - PR がコメント反応された           +1
 *  - PR が ignored (7日無反応)        -2
 *  - 通知がオプトアウトされた          -5
 *  - PR が rejected された            -3
 *
 * 学習対象:
 *  - industry_match_weight (default 40)
 *  - module_match_weight   (default 30)
 *  - module_match_per_module_weight (default 5, cap 20)
 *  - severity_critical_boost (default 20)
 *  - severity_major_boost    (default 10)
 *  - notify_threshold        (default 30)
 *  - tier_weight: S/A/B/C/D (default {S:1.0, A:0.9, B:0.7, C:0.5, D:0.3})
 *
 * 更新則:
 *  - Online gradient: w := w + α * (reward) * feature(i)
 *  - α = 0.05 (learning rate)
 *  - L2 正則化: w *= (1 - λ), λ = 0.001
 *  - 重みは clamp で [min, max] 範囲に制限
 *  - 過去 100 episode の移動平均で報酬収束を観測
 */

import type { LegalTier } from '../corpus/legal_corpus';

export type FeedbackKind =
  | 'pr_merged'
  | 'pr_approved'
  | 'pr_rejected'
  | 'pr_commented'
  | 'pr_ignored'
  | 'notify_opened'
  | 'notify_optout';

export const REWARD_TABLE: Record<FeedbackKind, number> = {
  pr_merged: 10,
  pr_approved: 5,
  pr_commented: 1,
  pr_ignored: -2,
  pr_rejected: -3,
  notify_opened: 2,
  notify_optout: -5,
};

export interface RewardWeights {
  industry_match_weight: number;
  module_match_weight: number;
  module_match_per_module_weight: number;
  severity_critical_boost: number;
  severity_major_boost: number;
  notify_threshold: number;
  tier_weight: Record<LegalTier, number>;
}

export const DEFAULT_WEIGHTS: RewardWeights = {
  industry_match_weight: 40,
  module_match_weight: 30,
  module_match_per_module_weight: 5,
  severity_critical_boost: 20,
  severity_major_boost: 10,
  notify_threshold: 30,
  tier_weight: { S: 1.0, A: 0.9, B: 0.7, C: 0.5, D: 0.3 },
};

export interface RewardEpisode {
  episode_id: string;
  /** 入力特徴量: どの要素が通知判定に効いたか (0-1 正規化済) */
  features: Partial<Record<keyof RewardWeights, number>> & {
    tier?: LegalTier;
  };
  /** ユーザーフィードバック */
  feedback: FeedbackKind;
  /** 算出された報酬 */
  reward: number;
  /** ターゲット (どのテナント・どの法令か) */
  tenant_id: string;
  law_id: string;
  /** 発生時刻 */
  occurred_at: string;
}

/** clamp ヘルパ */
function clamp(v: number, min: number, max: number): number {
  return Math.max(min, Math.min(max, v));
}

const WEIGHT_BOUNDS: Record<keyof Omit<RewardWeights, 'tier_weight'>, [number, number]> = {
  industry_match_weight: [10, 80],
  module_match_weight: [10, 60],
  module_match_per_module_weight: [1, 12],
  severity_critical_boost: [5, 40],
  severity_major_boost: [0, 25],
  notify_threshold: [10, 80],
};

const TIER_BOUNDS: [number, number] = [0.1, 1.5];

export class RewardLearner {
  private weights: RewardWeights;
  private readonly alpha: number;
  private readonly lambda: number;
  private readonly episodes: RewardEpisode[] = [];

  constructor(opts: {
    initialWeights?: RewardWeights;
    learningRate?: number;
    l2?: number;
  } = {}) {
    this.weights = opts.initialWeights ?? structuredClone(DEFAULT_WEIGHTS);
    this.alpha = opts.learningRate ?? 0.05;
    this.lambda = opts.l2 ?? 0.001;
  }

  getWeights(): RewardWeights {
    return structuredClone(this.weights);
  }

  /**
   * 1 episode 観測して重み更新。
   * 特徴量が正規化済 (0-1) であることを想定。
   */
  observe(input: {
    episode_id: string;
    features: RewardEpisode['features'];
    feedback: FeedbackKind;
    tenant_id: string;
    law_id: string;
  }): RewardEpisode {
    const reward = REWARD_TABLE[input.feedback];
    const episode: RewardEpisode = {
      episode_id: input.episode_id,
      features: input.features,
      feedback: input.feedback,
      reward,
      tenant_id: input.tenant_id,
      law_id: input.law_id,
      occurred_at: new Date().toISOString(),
    };
    this.episodes.push(episode);
    this.updateWeights(input.features, reward);
    return episode;
  }

  /**
   * Online gradient + L2.
   * w' = w * (1 - λ) + α * reward * feature
   */
  private updateWeights(features: RewardEpisode['features'], reward: number): void {
    for (const key of Object.keys(WEIGHT_BOUNDS) as Array<keyof typeof WEIGHT_BOUNDS>) {
      const f = (features as Record<string, number | undefined>)[key];
      if (typeof f !== 'number') continue;
      const w = this.weights[key];
      const updated = w * (1 - this.lambda) + this.alpha * reward * f;
      const [min, max] = WEIGHT_BOUNDS[key];
      this.weights[key] = clamp(updated, min, max);
    }
    // Tier 重みも更新
    if (features.tier) {
      const tw = this.weights.tier_weight[features.tier];
      const updated = tw * (1 - this.lambda) + this.alpha * (reward / 10) * 1.0;
      this.weights.tier_weight[features.tier] = clamp(updated, TIER_BOUNDS[0], TIER_BOUNDS[1]);
    }
  }

  /** 直近 N episode の平均報酬 (収束観測) */
  movingAverageReward(window = 100): number {
    if (this.episodes.length === 0) return 0;
    const slice = this.episodes.slice(-window);
    const sum = slice.reduce((acc, e) => acc + e.reward, 0);
    return Math.round((sum / slice.length) * 100) / 100;
  }

  /** 全 episode (永続化用) */
  exportEpisodes(): RewardEpisode[] {
    return [...this.episodes];
  }

  /** 重み serialize */
  exportWeights(): RewardWeights {
    return this.getWeights();
  }

  /** 重み load (deserialize) */
  importWeights(w: RewardWeights): void {
    this.weights = structuredClone(w);
  }

  /**
   * 現在の重みで personalized_alert の score を再計算するために、
   * notify_threshold / 重み一覧を取得。
   */
  getCurrentScoringRules(): {
    notify_threshold: number;
    industry_match_weight: number;
    module_match_weight: number;
    module_match_per_module_weight: number;
    severity_critical_boost: number;
    severity_major_boost: number;
    tier_weight: Record<LegalTier, number>;
  } {
    return {
      notify_threshold: this.weights.notify_threshold,
      industry_match_weight: this.weights.industry_match_weight,
      module_match_weight: this.weights.module_match_weight,
      module_match_per_module_weight: this.weights.module_match_per_module_weight,
      severity_critical_boost: this.weights.severity_critical_boost,
      severity_major_boost: this.weights.severity_major_boost,
      tier_weight: { ...this.weights.tier_weight },
    };
  }

  /**
   * 学習サマリ: episode 数, 平均報酬, 重みの変化幅
   */
  getSummary(): {
    episode_count: number;
    avg_reward_last_100: number;
    weights: RewardWeights;
    drift_from_default: Record<string, number>;
  } {
    const def = DEFAULT_WEIGHTS;
    const drift: Record<string, number> = {};
    for (const key of Object.keys(WEIGHT_BOUNDS) as Array<keyof typeof WEIGHT_BOUNDS>) {
      drift[key] = Math.round((this.weights[key] - def[key]) * 100) / 100;
    }
    return {
      episode_count: this.episodes.length,
      avg_reward_last_100: this.movingAverageReward(100),
      weights: this.getWeights(),
      drift_from_default: drift,
    };
  }
}

/**
 * 全 episode の集計分析。最頻フィードバックや勝率を返す。
 */
export function analyzeEpisodes(episodes: RewardEpisode[]): {
  total: number;
  by_feedback: Record<FeedbackKind, number>;
  positive_ratio: number;
  total_reward: number;
} {
  const byFeedback: Record<FeedbackKind, number> = {
    pr_merged: 0, pr_approved: 0, pr_commented: 0, pr_ignored: 0, pr_rejected: 0,
    notify_opened: 0, notify_optout: 0,
  };
  let totalReward = 0;
  for (const e of episodes) {
    byFeedback[e.feedback]++;
    totalReward += e.reward;
  }
  const positives = byFeedback.pr_merged + byFeedback.pr_approved + byFeedback.pr_commented + byFeedback.notify_opened;
  return {
    total: episodes.length,
    by_feedback: byFeedback,
    positive_ratio: episodes.length > 0 ? Math.round((positives / episodes.length) * 1000) / 10 : 0,
    total_reward: totalReward,
  };
}
