/**
 * Phase 46-LU-8 / SIEL Phase 47-50 Bridge
 *
 * Phase 46-LU 系列 (LU-1〜LU-7) と本体 SIEL (Phase 47-50) を橋渡しする統合層。
 *
 * SIEL (SI Excellence Layer) との連携ポイント:
 *  - CCS Phase 47 の 10/10軸目「法令適合性」に LU-5 の computeLegalAxis を実注入
 *  - SIEL D2D Pipeline (Phase 48) の Phase F (Legal) に LU の契約書ジェネレータを統合
 *  - SIEL Manual Forge (Phase 49) に LU の法令改正アラート出力を統合
 *  - SIEL Ecosystem Test (Phase 50 ARTE-Omega Bridge) に LU の omega_legal_bridge を連動
 */

export interface SielPhaseBinding {
  siel_phase: 'phase47' | 'phase48' | 'phase49' | 'phase50';
  binding_kind: 'ccs_axis' | 'd2d_pipeline_phase' | 'manual_forge_section' | 'ecosystem_test_assertion' | 'orchestrator_step';
  binding_target: string;
  lu_module: string;
  lu_function: string;
  description: string;
  /** SIEL 側で呼ぶ際のシグネチャ (TS擬似) */
  signature: string;
}

export const SIEL_BRIDGE_BINDINGS: SielPhaseBinding[] = [
  // Phase 47 SIEL: CCS 10/10軸目 = 法令適合性
  {
    siel_phase: 'phase47',
    binding_kind: 'ccs_axis',
    binding_target: 'ccs_axis_10_legal_compliance',
    lu_module: 'lib/japan/law_auto_update/ccs/legal_axis',
    lu_function: 'computeLegalAxis',
    description: 'SIEL CCS の 10 軸目「法令適合性」を LU-5 の実関数で計算',
    signature: 'computeLegalAxis(input: LegalAxisInput): LegalAxisResult',
  },
  {
    siel_phase: 'phase47',
    binding_kind: 'ccs_axis',
    binding_target: 'ccs_axis_10_legal_compliance_export',
    lu_module: 'lib/japan/law_auto_update/ccs/legal_axis',
    lu_function: 'exportLegalAxisToSielJson',
    description: 'SIEL JSON連携用フォーマットへエクスポート',
    signature: 'exportLegalAxisToSielJson(result: LegalAxisResult): SielJsonPayload',
  },

  // Phase 48 SIEL Implementation Layer: D2D Pipeline Phase F (Legal)
  {
    siel_phase: 'phase48',
    binding_kind: 'd2d_pipeline_phase',
    binding_target: 'phase_F_legal_doc_render',
    lu_module: 'lib/japan/law_auto_update/contracts/contract_clause_generator',
    lu_function: 'generateContractTemplate',
    description: 'SIEL D2D Phase F (Legal) で LU-5 契約書テンプレを呼出',
    signature: 'generateContractTemplate(input: GenerateContractInput): { template, rendered, clauses_used }',
  },
  {
    siel_phase: 'phase48',
    binding_kind: 'd2d_pipeline_phase',
    binding_target: 'phase_F_compliance_check',
    lu_module: 'lib/japan/law_auto_update/compliance/code_compliance_scanner',
    lu_function: 'scanCodeForCompliance',
    description: 'SIEL D2D Phase F でコード自動コンプラ検査',
    signature: 'scanCodeForCompliance({ code, file_hint }): ComplianceFinding[]',
  },
  {
    siel_phase: 'phase48',
    binding_kind: 'd2d_pipeline_phase',
    binding_target: 'phase_F_risk_assessment',
    lu_module: 'lib/japan/law_auto_update/risk/legal_risk_scoring',
    lu_function: 'assessLegalRisk',
    description: 'SIEL D2D Phase F でリスク評価実行',
    signature: 'assessLegalRisk(input: RiskInput): RiskAssessment',
  },

  // Phase 49 SIEL Completion Layer: Manual Forge セクション
  {
    siel_phase: 'phase49',
    binding_kind: 'manual_forge_section',
    binding_target: 'manual_section_legal_updates',
    lu_module: 'lib/japan/law_auto_update/email_alerts/amendment_alert_dispatcher',
    lu_function: 'buildAlertEmail',
    description: 'SIEL Manual Forge に「法令改正対応セクション」を自動挿入',
    signature: 'buildAlertEmail({ subscription, payload }): AlertEmail',
  },
  {
    siel_phase: 'phase49',
    binding_kind: 'manual_forge_section',
    binding_target: 'manual_section_legal_qa',
    lu_module: 'lib/japan/law_auto_update/advisor/legal_advisor',
    lu_function: 'createLegalAdvisor',
    description: 'SIEL Manual Forge に「法務FAQ」セクションを自動挿入',
    signature: 'createLegalAdvisor(opts): LegalAdvisor',
  },
  {
    siel_phase: 'phase49',
    binding_kind: 'manual_forge_section',
    binding_target: 'manual_section_timeline',
    lu_module: 'lib/japan/law_auto_update/timeline/law_timeline',
    lu_function: 'buildTimelineMarkdown',
    description: 'SIEL Manual Forge に「業種別法令タイムライン」を挿入',
    signature: 'buildTimelineMarkdown(lawShort?: string): string',
  },

  // Phase 50 SIEL Ecosystem Integration Layer: ARTE-Omega Bridge
  {
    siel_phase: 'phase50',
    binding_kind: 'ecosystem_test_assertion',
    binding_target: 'omega_legal_bridge_assertion',
    lu_module: 'lib/japan/law_auto_update/bridge/omega_legal_bridge',
    lu_function: 'bridgeBatch',
    description: 'SIEL Ecosystem Test で ARTE-Omega → 法令ブリッジを実行',
    signature: 'bridgeBatch(findings: OmegaFinding[]): { implications, total_estimated_damage_jpy, unique_laws, unique_agencies, summary }',
  },
  {
    siel_phase: 'phase50',
    binding_kind: 'orchestrator_step',
    binding_target: 'siel_orchestrator_phase_4_legal',
    lu_module: 'lib/japan/law_auto_update/phase46_lu7_dashboard',
    lu_function: 'buildExcellenceDashboard',
    description: 'SIEL Orchestrator の Phase 4 で LU-7 Excellence Dashboard 評価',
    signature: 'buildExcellenceDashboard(): ExcellenceDashboard',
  },
  {
    siel_phase: 'phase50',
    binding_kind: 'orchestrator_step',
    binding_target: 'siel_orchestrator_legal_predictor',
    lu_module: 'lib/japan/law_auto_update/regulatory_radar/amendment_predictor',
    lu_function: 'topPredicted',
    description: 'SIEL Orchestrator で 5 年規制予測を取得し、設計段階で考慮',
    signature: 'topPredicted(n?: number): AmendmentPrediction[]',
  },
];

/**
 * SIEL ↔ LU の双方向同期チェック
 */
export interface SyncCheck {
  binding_id: string;
  siel_side_implemented: boolean;
  lu_side_implemented: boolean;
  sync_status: 'synced' | 'lu_only' | 'siel_only' | 'missing';
  recommendation: string;
}

export function checkBridgeSyncStatus(): SyncCheck[] {
  return SIEL_BRIDGE_BINDINGS.map((b, i) => ({
    binding_id: `${b.siel_phase}_${b.binding_kind}_${i}`,
    // ★2026-08-01 実測による訂正: 以前ここには「SIEL は本体 chain.sh 側で実装」と書かれていたが
    //   **虚偽**だった (chain.sh に SIEL の参照は 0 件)。SIEL 側の実体は
    //   skills/soloptilink-japan/scripts/ 配下 (下の recommendation が指すファイル群) であり、
    //   本モジュールからは実装有無を検出できないため常に false を返す (未検出であって未実装の断定ではない)。
    siel_side_implemented: false,
    lu_side_implemented: true, // LU 側は既に実装済 (本ファイルが参照可能なため)
    sync_status: 'lu_only',
    recommendation: `SIEL 側 (~/.soloptilink/skills/soloptilink-japan/scripts/${b.binding_kind === 'orchestrator_step' ? 'siel_orchestrator.sh' : b.binding_kind === 'd2d_pipeline_phase' ? 'd2d_run.sh' : b.binding_kind === 'manual_forge_section' ? 'manual_forge.sh' : b.binding_kind === 'ccs_axis' ? 'calc_ccs.sh' : 'ecosystem_integration_test.sh'}) で本バインディングを実装`,
  }));
}

/**
 * SIEL Phase 別バインディング サマリ
 */
export function summarizeBridge(): {
  total_bindings: number;
  by_phase: Record<string, number>;
  by_kind: Record<string, number>;
  sync_summary: { synced: number; lu_only: number; siel_only: number; missing: number };
} {
  const byPhase: Record<string, number> = {};
  const byKind: Record<string, number> = {};
  for (const b of SIEL_BRIDGE_BINDINGS) {
    byPhase[b.siel_phase] = (byPhase[b.siel_phase] ?? 0) + 1;
    byKind[b.binding_kind] = (byKind[b.binding_kind] ?? 0) + 1;
  }
  const checks = checkBridgeSyncStatus();
  const sync = { synced: 0, lu_only: 0, siel_only: 0, missing: 0 };
  for (const c of checks) sync[c.sync_status]++;
  return {
    total_bindings: SIEL_BRIDGE_BINDINGS.length,
    by_phase: byPhase,
    by_kind: byKind,
    sync_summary: sync,
  };
}

/**
 * SIEL Phase 47-50 側に渡す統合 Manifest を生成
 */
export interface SielIntegrationManifest {
  manifest_version: '1.0';
  generated_at: string;
  lu_series_version: 'LU-1 to LU-8';
  bindings: SielPhaseBinding[];
  /** SIEL Phase 47 CCS 連携 */
  ccs_legal_axis_function: string;
  /** SIEL Phase 48 D2D 連携 */
  d2d_phase_F_handlers: string[];
  /** SIEL Phase 49 Manual Forge 連携 */
  manual_forge_sections: string[];
  /** SIEL Phase 50 Ecosystem 連携 */
  orchestrator_step_4_function: string;
}

export function generateSielIntegrationManifest(): SielIntegrationManifest {
  const d2dHandlers = SIEL_BRIDGE_BINDINGS.filter((b) => b.binding_kind === 'd2d_pipeline_phase').map((b) => `${b.lu_module}#${b.lu_function}`);
  const manualSections = SIEL_BRIDGE_BINDINGS.filter((b) => b.binding_kind === 'manual_forge_section').map((b) => `${b.lu_module}#${b.lu_function}`);
  return {
    manifest_version: '1.0',
    generated_at: new Date().toISOString(),
    lu_series_version: 'LU-1 to LU-8',
    bindings: SIEL_BRIDGE_BINDINGS,
    ccs_legal_axis_function: 'lib/japan/law_auto_update/ccs/legal_axis#computeLegalAxis',
    d2d_phase_F_handlers: d2dHandlers,
    manual_forge_sections: manualSections,
    orchestrator_step_4_function: 'lib/japan/law_auto_update/phase46_lu7_dashboard#buildExcellenceDashboard',
  };
}

export function renderBridgeReport(): string {
  const s = summarizeBridge();
  const lines: string[] = [];
  lines.push('# Phase 46-LU-8 / SIEL Phase 47-50 統合ブリッジ レポート');
  lines.push('');
  lines.push(`総バインディング: **${s.total_bindings} 件**`);
  lines.push('');
  lines.push('## SIEL Phase 別');
  for (const [p, n] of Object.entries(s.by_phase)) lines.push(`- ${p}: ${n} 件`);
  lines.push('');
  lines.push('## バインディング種別');
  for (const [k, n] of Object.entries(s.by_kind)) lines.push(`- ${k}: ${n} 件`);
  lines.push('');
  lines.push('## バインディング詳細');
  for (const b of SIEL_BRIDGE_BINDINGS) {
    lines.push(`### [${b.siel_phase}] ${b.binding_target}`);
    lines.push(`- 種別: ${b.binding_kind}`);
    lines.push(`- LU モジュール: ${b.lu_module}`);
    lines.push(`- LU 関数: \`${b.lu_function}\``);
    lines.push(`- 用途: ${b.description}`);
    lines.push(`- シグネチャ: \`${b.signature}\``);
    lines.push('');
  }
  return lines.join('\n');
}
