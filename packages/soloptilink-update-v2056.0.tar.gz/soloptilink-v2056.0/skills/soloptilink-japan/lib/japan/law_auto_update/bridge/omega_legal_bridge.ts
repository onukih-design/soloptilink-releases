/**
 * Phase 46-LU-5 / ARTE-Omega ↔ Legal Bridge
 *
 * v2026.0 ARTE-Omega (BOOST Level 2/3 自動稼働) で検出された脆弱性・違反を、
 * 自動的に該当する日本法令にマッピングする。
 *
 *  - OWASP/MITRE ATLAS の脆弱性ID → 個情法/サイバー基本法/不正アクセス禁止法
 *  - 検出領域 (16攻撃面) → 業種固有規制 (医療/金融/重要インフラ)
 *  - JPCERT/個情委/ACDA への報告義務を自動判定
 */

import type { LawCategory } from '../../law_tracker';
import { scanCodeForCompliance, buildScanReport, type ComplianceFinding } from '../compliance/code_compliance_scanner';

export type OmegaSeverity = 'critical' | 'high' | 'medium' | 'low';

export type OmegaCategory =
  | 'mobile' | 'cloud_k8s' | 'api' | 'ml_llm' | 'devsecops' | 'iot_firmware'
  | 'social_eng' | 'ot_scada' | 'zero_day' | 'apt_chain' | 'browser' | 'identity'
  | 'zero_trust' | 'privacy' | 'blockchain' | 'ai_supply_chain';

export interface OmegaFinding {
  finding_id: string;
  category: OmegaCategory;
  severity: OmegaSeverity;
  title: string;
  description: string;
  cve?: string;
  /** 影響 PII データ件数 */
  affected_pii_count?: number;
}

export interface LegalImplication {
  finding_id: string;
  /** 該当する日本法令 */
  triggered_laws: string[];
  /** 法令カテゴリ */
  categories: LawCategory[];
  /** 報告義務 */
  reporting_obligations: Array<{
    agency: '個情委' | 'JPCERT/CC' | 'ACDA' | '所轄警察' | '所管省庁';
    deadline: string;
    legal_basis: string;
  }>;
  /** 推定損害賠償 (中央値, 円) */
  estimated_civil_damage_jpy?: number;
  /** 推定行政罰 */
  estimated_admin_penalty_jpy?: number;
  /** 推奨アクション (法務観点) */
  legal_actions: string[];
}

const CATEGORY_TO_LAWS: Record<OmegaCategory, { laws: string[]; categories: LawCategory[] }> = {
  privacy: {
    laws: ['個人情報保護法第26条 (漏えい等の報告)', '個情法第20条 (適正な取得)', 'GDPR Art.33 (72h報告)'],
    categories: ['privacy'],
  },
  api: {
    laws: ['個人情報保護法第26条', '不正アクセス禁止法第3条', 'サイバーセキュリティ基本法'],
    categories: ['privacy', 'admin'],
  },
  identity: {
    laws: ['不正アクセス禁止法第2条第4項', '個情法第26条', '電気通信事業法'],
    categories: ['privacy', 'admin'],
  },
  mobile: {
    laws: ['個情法 (位置情報)', '電気通信事業法 外部送信規律 (R5.6)', '青少年保護条例'],
    categories: ['privacy'],
  },
  cloud_k8s: {
    laws: ['個情法第28条 (越境移転)', 'ガバメントクラウド要件', 'FISC安全対策基準'],
    categories: ['privacy', 'finance'],
  },
  ml_llm: {
    laws: ['AI事業者ガイドライン (R6.4)', '個情法第18条', '著作権法第30条の4'],
    categories: ['admin', 'copyright', 'privacy'],
  },
  devsecops: {
    laws: ['J-SOX 内部統制', '金商法第24条の4の4'],
    categories: ['corporate', 'finance'],
  },
  iot_firmware: {
    laws: ['電気通信事業法 (端末認証)', 'NICTER条例', '電気用品安全法'],
    categories: ['admin', 'consumer'],
  },
  social_eng: {
    laws: ['不正アクセス禁止法', '刑法第246条の2 (電子計算機使用詐欺)'],
    categories: ['admin'],
  },
  ot_scada: {
    laws: ['重要インフラ事業者ガイドライン', 'サイバーセキュリティ基本法第14条'],
    categories: ['admin'],
  },
  zero_day: {
    laws: ['JPCERT/CC 早期警戒情報', '個情法第26条'],
    categories: ['admin', 'privacy'],
  },
  apt_chain: {
    laws: ['経済安全保障推進法 第6条', '不正競争防止法 (営業秘密)'],
    categories: ['admin', 'corporate'],
  },
  browser: {
    laws: ['個情法 (cookie同意)', '電気通信事業法 外部送信規律'],
    categories: ['privacy'],
  },
  zero_trust: {
    laws: ['ガバメントクラウドゼロトラスト要件', 'NISC ZTA Reference Architecture'],
    categories: ['admin'],
  },
  blockchain: {
    laws: ['資金決済法 (暗号資産)', '金商法第2条第24項 (電子決済手段)'],
    categories: ['finance'],
  },
  ai_supply_chain: {
    laws: ['経済安全保障推進法', '外為法第48条 (技術輸出)'],
    categories: ['admin', 'corporate'],
  },
};

const SEVERITY_PENALTY: Record<OmegaSeverity, { admin: number; civil: number }> = {
  critical: { admin: 30_000_000, civil: 100_000_000 },
  high: { admin: 10_000_000, civil: 30_000_000 },
  medium: { admin: 3_000_000, civil: 10_000_000 },
  low: { admin: 1_000_000, civil: 3_000_000 },
};

export function mapOmegaToLegal(finding: OmegaFinding): LegalImplication {
  const mapping = CATEGORY_TO_LAWS[finding.category];
  const obligations: LegalImplication['reporting_obligations'] = [];

  // PII 漏えい関連
  if (
    finding.category === 'privacy'
    || finding.category === 'api'
    || finding.category === 'identity'
    || (finding.affected_pii_count ?? 0) > 0
  ) {
    obligations.push({
      agency: '個情委',
      deadline: '72時間以内 (速報) + 30日以内 (確報)',
      legal_basis: '個情法第26条 (R4改正)',
    });
    if ((finding.affected_pii_count ?? 0) >= 1000) {
      obligations.push({
        agency: '所管省庁',
        deadline: '30日以内',
        legal_basis: '業種別ガイドライン (金融 FISC / 医療 3省2GL 等)',
      });
    }
  }

  // サイバーインシデント
  if (
    finding.category === 'apt_chain'
    || finding.category === 'zero_day'
    || finding.category === 'ot_scada'
    || finding.category === 'iot_firmware'
  ) {
    obligations.push({
      agency: 'JPCERT/CC',
      deadline: '速やかに',
      legal_basis: 'JPCERT/CC 早期警戒情報運用要綱',
    });
  }

  // 不正アクセス
  if (finding.category === 'identity' || finding.category === 'social_eng') {
    obligations.push({
      agency: '所轄警察',
      deadline: '速やかに',
      legal_basis: '不正アクセス禁止法 + 都道府県警察サイバー対策係',
    });
  }

  // 能動的サイバー防御
  if (finding.category === 'ot_scada' || finding.category === 'apt_chain') {
    obligations.push({
      agency: 'ACDA',
      deadline: '速やかに',
      legal_basis: '能動的サイバー防御法 (R7.4施行)',
    });
  }

  const penalty = SEVERITY_PENALTY[finding.severity];
  const piiBoost = (finding.affected_pii_count ?? 0) * 1000;

  const legalActions: string[] = [];
  legalActions.push(`72時間以内に個情委への速報を準備 (個情法26条)`);
  legalActions.push(`内部通報窓口 + 第三者委員会の設置検討`);
  if (finding.severity === 'critical') {
    legalActions.push(`🚨 顧問弁護士 + 法務最高責任者 (CLO) への即時エスカレーション`);
    legalActions.push(`プレスリリース原案準備 (incident.ts buildPostMortemSkeleton)`);
  }
  if ((finding.affected_pii_count ?? 0) >= 5000) {
    legalActions.push(`本人通知の準備 (個情法第26条 重大事案)`);
  }
  if (finding.category === 'apt_chain') {
    legalActions.push(`営業秘密の不正取得 — 不競法上の損害賠償請求検討`);
  }

  return {
    finding_id: finding.finding_id,
    triggered_laws: mapping.laws,
    categories: mapping.categories,
    reporting_obligations: obligations,
    estimated_civil_damage_jpy: penalty.civil + piiBoost,
    estimated_admin_penalty_jpy: penalty.admin,
    legal_actions: legalActions,
  };
}

/**
 * ARTE-Omega 検出結果を一括 → 法務サマリー
 */
export function bridgeBatch(findings: OmegaFinding[]): {
  implications: LegalImplication[];
  total_estimated_damage_jpy: number;
  unique_laws: string[];
  unique_agencies: string[];
  summary: string;
} {
  const implications = findings.map(mapOmegaToLegal);
  const totalDamage = implications.reduce((acc, i) => acc + (i.estimated_civil_damage_jpy ?? 0) + (i.estimated_admin_penalty_jpy ?? 0), 0);
  const laws = new Set<string>();
  const agencies = new Set<string>();
  for (const i of implications) {
    i.triggered_laws.forEach((l) => laws.add(l));
    i.reporting_obligations.forEach((o) => agencies.add(o.agency));
  }
  const lines: string[] = [];
  lines.push(`# ARTE-Omega 検出結果 法務インパクト分析`);
  lines.push('');
  lines.push(`総検出: ${findings.length}件`);
  lines.push(`想定総損害 (民事+行政): ¥${totalDamage.toLocaleString()}`);
  lines.push(`該当法令: ${laws.size}件`);
  lines.push(`報告先機関: ${[...agencies].join(', ')}`);
  return {
    implications,
    total_estimated_damage_jpy: totalDamage,
    unique_laws: [...laws],
    unique_agencies: [...agencies],
    summary: lines.join('\n'),
  };
}

/**
 * BOOST 完了時に code_compliance_scanner と組み合わせて
 * セキュリティ&コンプライアンス統合検査を実施
 */
export function runIntegratedSecurityComplianceCheck(input: {
  omega_findings: OmegaFinding[];
  code_samples?: Array<{ code: string; file_hint?: string }>;
}): {
  omega_implications: ReturnType<typeof bridgeBatch>;
  compliance_findings: ComplianceFinding[];
  combined_action_items: string[];
} {
  const omega = bridgeBatch(input.omega_findings);
  const compFindings: ComplianceFinding[] = [];
  for (const sample of input.code_samples ?? []) {
    compFindings.push(...scanCodeForCompliance(sample));
  }
  const actions: string[] = [];
  for (const i of omega.implications) actions.push(...i.legal_actions);
  if (compFindings.length > 0) {
    const compReport = buildScanReport(compFindings);
    actions.push(`コンプライアンススキャン: ${compFindings.length}件検出 (score ${compReport.compliance_score}/100)`);
  }
  return {
    omega_implications: omega,
    compliance_findings: compFindings,
    combined_action_items: [...new Set(actions)],
  };
}
