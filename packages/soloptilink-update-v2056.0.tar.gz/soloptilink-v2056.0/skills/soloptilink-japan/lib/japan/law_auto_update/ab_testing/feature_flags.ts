/**
 * Phase 46-LU-7 / A/B Testing & Feature Flags
 *
 * 機能リリースの段階展開と効果測定:
 *  - フィーチャーフラグ (テナント別 / ユーザー別 / ロールバック可能)
 *  - A/B テスト (variant 割当 + コンバージョン記録)
 *  - 統計的有意性 (Chi-square 簡易検定)
 *  - ガード機能: error rate 上昇時に自動ロールバック
 */

export type FlagStatus = 'off' | 'on' | 'beta' | 'experiment';

export interface FeatureFlag {
  flag_id: string;
  description: string;
  status: FlagStatus;
  /** rollout 比率 0-100 (%) */
  rollout_percentage: number;
  /** 対象テナント (空=全テナント) */
  allowed_tenants: string[];
  /** 対象プラン */
  allowed_plans?: string[];
  /** 開始日 */
  enabled_since?: string;
  /** killswitch: true で即無効 */
  kill_switched: boolean;
  /** A/B テスト variant */
  variants?: VariantConfig[];
}

export interface VariantConfig {
  variant_id: string;
  weight: number; // 0-100
  description: string;
}

const FEATURE_FLAGS = new Map<string, FeatureFlag>();

/** デフォルトフラグ (Phase 46-LU 系の新機能) */
export const DEFAULT_FLAGS: FeatureFlag[] = [
  { flag_id: 'legal_advisor_v2', description: '法務AIアドバイザー v2 (LLM強化)', status: 'beta', rollout_percentage: 25, allowed_tenants: [], kill_switched: false },
  { flag_id: 'amendment_predictor', description: '改正予測エンジン', status: 'experiment', rollout_percentage: 10, allowed_tenants: [], kill_switched: false,
    variants: [
      { variant_id: 'control', weight: 50, description: '従来通り (パブコメ追跡のみ)' },
      { variant_id: 'treatment', weight: 50, description: 'ML 改正予測有効化' },
    ],
  },
  { flag_id: 'mobile_sdk_v2', description: 'モバイル SDK v2 (バンドル削減)', status: 'on', rollout_percentage: 100, allowed_tenants: [], kill_switched: false },
  { flag_id: 'pdf_export_optimized', description: 'PDF エクスポート最適化', status: 'on', rollout_percentage: 100, allowed_tenants: [], kill_switched: false },
  { flag_id: 'omega_auto_integration', description: 'ARTE-Omega 自動連携', status: 'on', rollout_percentage: 100, allowed_tenants: [], allowed_plans: ['enterprise', 'legal_firm'], kill_switched: false },
];

/** 初期化 */
export function initDefaultFlags(): void {
  for (const f of DEFAULT_FLAGS) FEATURE_FLAGS.set(f.flag_id, { ...f });
}

export function setFlag(flag: FeatureFlag): void {
  FEATURE_FLAGS.set(flag.flag_id, flag);
}

export function getFlag(flag_id: string): FeatureFlag | undefined {
  return FEATURE_FLAGS.get(flag_id);
}

/**
 * フラグの有効判定 (テナント別)
 */
export function isFlagEnabled(input: {
  flag_id: string;
  tenant_id: string;
  plan_tier?: string;
}): { enabled: boolean; variant?: string; reason: string } {
  const flag = FEATURE_FLAGS.get(input.flag_id);
  if (!flag) return { enabled: false, reason: 'flag not registered' };
  if (flag.kill_switched) return { enabled: false, reason: 'kill-switched' };
  if (flag.status === 'off') return { enabled: false, reason: 'status=off' };
  if (flag.allowed_plans && input.plan_tier && !flag.allowed_plans.includes(input.plan_tier)) {
    return { enabled: false, reason: 'plan not eligible' };
  }
  if (flag.allowed_tenants.length > 0 && !flag.allowed_tenants.includes(input.tenant_id)) {
    return { enabled: false, reason: 'tenant not in allowlist' };
  }
  // テナントID をシード化して 0-99 にマップ
  const seed = hashStringToInt(input.tenant_id) % 100;
  if (seed >= flag.rollout_percentage) {
    return { enabled: false, reason: `rollout cutoff: tenant in ${seed}/${flag.rollout_percentage}%` };
  }
  // A/B テスト variant 決定
  if (flag.variants && flag.variants.length > 0) {
    const variant = selectVariant(input.tenant_id, flag.variants);
    return { enabled: true, variant, reason: `variant=${variant}` };
  }
  return { enabled: true, reason: 'rollout active' };
}

function selectVariant(tenant_id: string, variants: VariantConfig[]): string {
  const totalWeight = variants.reduce((acc, v) => acc + v.weight, 0);
  const seed = hashStringToInt(tenant_id + 'variant') % totalWeight;
  let cum = 0;
  for (const v of variants) {
    cum += v.weight;
    if (seed < cum) return v.variant_id;
  }
  return variants[0].variant_id;
}

function hashStringToInt(s: string): number {
  let h = 0;
  for (let i = 0; i < s.length; i++) {
    h = ((h << 5) - h + s.charCodeAt(i)) | 0;
  }
  return Math.abs(h);
}

/**
 * 実験イベント記録 (variant 割当 + コンバージョン)
 */
export interface ExperimentEvent {
  flag_id: string;
  variant: string;
  tenant_id: string;
  event_type: 'exposure' | 'conversion' | 'error';
  timestamp: string;
}

const EVENT_STORE: ExperimentEvent[] = [];

export function recordExperimentEvent(input: Omit<ExperimentEvent, 'timestamp'>): ExperimentEvent {
  const e: ExperimentEvent = { ...input, timestamp: new Date().toISOString() };
  EVENT_STORE.push(e);
  return e;
}

export interface ExperimentResult {
  flag_id: string;
  by_variant: Record<string, {
    exposures: number;
    conversions: number;
    errors: number;
    conversion_rate_pct: number;
    error_rate_pct: number;
  }>;
  winner?: string;
  chi_square_significance?: boolean;
}

export function analyzeExperiment(flag_id: string): ExperimentResult {
  const events = EVENT_STORE.filter((e) => e.flag_id === flag_id);
  const byVar: ExperimentResult['by_variant'] = {};
  for (const e of events) {
    if (!byVar[e.variant]) byVar[e.variant] = { exposures: 0, conversions: 0, errors: 0, conversion_rate_pct: 0, error_rate_pct: 0 };
    if (e.event_type === 'exposure') byVar[e.variant].exposures++;
    if (e.event_type === 'conversion') byVar[e.variant].conversions++;
    if (e.event_type === 'error') byVar[e.variant].errors++;
  }
  for (const v of Object.values(byVar)) {
    v.conversion_rate_pct = v.exposures > 0 ? Math.round((v.conversions / v.exposures) * 10000) / 100 : 0;
    v.error_rate_pct = v.exposures > 0 ? Math.round((v.errors / v.exposures) * 10000) / 100 : 0;
  }
  // Winner 判定: コンバージョン率最大
  let winner: string | undefined;
  let max = -1;
  for (const [variant, stats] of Object.entries(byVar)) {
    if (stats.conversion_rate_pct > max && stats.exposures >= 100) {
      max = stats.conversion_rate_pct;
      winner = variant;
    }
  }
  // 簡易 chi-square 有意判定 (df=1, p<0.05 → 3.84)
  let significant = false;
  const variants = Object.entries(byVar);
  if (variants.length === 2) {
    const [vA, sA] = variants[0];
    const [vB, sB] = variants[1];
    if (sA.exposures >= 100 && sB.exposures >= 100) {
      const expectedA = (sA.conversions + sB.conversions) * sA.exposures / (sA.exposures + sB.exposures);
      const expectedB = (sA.conversions + sB.conversions) * sB.exposures / (sA.exposures + sB.exposures);
      if (expectedA > 0 && expectedB > 0) {
        const chiSq =
          ((sA.conversions - expectedA) ** 2 / expectedA)
          + ((sB.conversions - expectedB) ** 2 / expectedB);
        significant = chiSq > 3.84;
      }
    }
  }
  return { flag_id, by_variant: byVar, winner, chi_square_significance: significant };
}

/**
 * 自動ロールバック (エラー率閾値超過時)
 */
export function checkAutoRollback(flag_id: string, error_threshold_pct = 2.0): { triggered: boolean; reason?: string } {
  const result = analyzeExperiment(flag_id);
  for (const [variant, stats] of Object.entries(result.by_variant)) {
    if (variant === 'control') continue;
    if (stats.exposures >= 100 && stats.error_rate_pct > error_threshold_pct) {
      const flag = FEATURE_FLAGS.get(flag_id);
      if (flag) flag.kill_switched = true;
      return { triggered: true, reason: `variant ${variant} error_rate=${stats.error_rate_pct}% > ${error_threshold_pct}% threshold` };
    }
  }
  return { triggered: false };
}

export function countFlags(): { total: number; by_status: Record<FlagStatus, number> } {
  const byStatus: Record<string, number> = { off: 0, on: 0, beta: 0, experiment: 0 };
  for (const f of FEATURE_FLAGS.values()) byStatus[f.status]++;
  return { total: FEATURE_FLAGS.size, by_status: byStatus as Record<FlagStatus, number> };
}

export function _resetFlagsForTests(): void {
  FEATURE_FLAGS.clear();
  EVENT_STORE.length = 0;
}
