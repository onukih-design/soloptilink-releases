/**
 * Phase 46-LU-3 / 罰則自動抽出 (罪刑法定主義チェッカー)
 *
 * 法令本文中の罰則条項 (懲役X年/罰金Y円/拘禁刑/没収/科料/拘留 等) を
 * 構造化抽出し、罪刑法定の観点で妥当性を採点する。
 *
 *  - 懲役: M月/N年以下 → 拘禁刑 (R7.6.1〜)
 *  - 罰金: K円以下 / 円以上円以下
 *  - 没収: 必要的没収/任意的没収
 *  - 拘留: 30日未満
 *  - 科料: 1000円以上1万円未満
 *  - 併科: 上記の組合せ
 *  - 累犯加重 / 法人重科
 */

export type PunishmentKind =
  | 'death' // 死刑
  | 'life_imprisonment' // 無期懲役 (→ R7.6 無期拘禁刑)
  | 'imprisonment' // 懲役 (→ 拘禁刑)
  | 'imprisonment_without_labor' // 禁錮 (→ 廃止 R7.6)
  | 'detention' // 拘禁刑 (R7.6 統合後)
  | 'fine' // 罰金
  | 'minor_fine' // 科料
  | 'detention_minor' // 拘留
  | 'forfeit' // 没収
  | 'cumulative'; // 累犯加重

export interface PenaltyAtom {
  kind: PunishmentKind;
  /** 懲役/禁錮/拘禁刑の上限期間 */
  imprisonment_max_years?: number;
  imprisonment_max_months?: number;
  /** 罰金/科料の金額 (円) */
  fine_max_jpy?: number;
  fine_min_jpy?: number;
  /** 必要的/任意的 */
  obligatory?: boolean;
  /** 法人重科 (両罰規定) */
  juridical_person_aggravation?: boolean;
  /** 元の生文字列 */
  raw_match: string;
}

export interface PenaltyExtractionResult {
  source_law: string;
  source_article?: string;
  atoms: PenaltyAtom[];
  /** 主刑の severity score (0-100, 高いほど重い) */
  severity_score: number;
  /** 罪刑法定 適合性 */
  is_definite: boolean;
  /** 不適合理由 */
  defect_reasons: string[];
}

const PATTERNS: Array<{ kind: PunishmentKind; re: RegExp; extract: (m: RegExpExecArray) => Partial<PenaltyAtom> }> = [
  {
    kind: 'death',
    re: /死刑/g,
    extract: () => ({}),
  },
  {
    kind: 'life_imprisonment',
    re: /無期懲役|無期拘禁刑/g,
    extract: () => ({}),
  },
  {
    kind: 'imprisonment',
    re: /(\d+)年以下の懲役/g,
    extract: (m) => ({ imprisonment_max_years: parseInt(m[1], 10) }),
  },
  {
    kind: 'imprisonment_without_labor',
    re: /(\d+)年以下の禁錮/g,
    extract: (m) => ({ imprisonment_max_years: parseInt(m[1], 10) }),
  },
  {
    kind: 'detention',
    re: /(\d+)年以下の拘禁刑/g,
    extract: (m) => ({ imprisonment_max_years: parseInt(m[1], 10) }),
  },
  {
    kind: 'fine',
    re: /(\d+(?:[,，]\d+)*)万円以下の罰金/g,
    extract: (m) => ({ fine_max_jpy: parseInt(m[1].replace(/[,，]/g, ''), 10) * 10_000 }),
  },
  {
    kind: 'fine',
    re: /(\d+(?:[,，]\d+)*)円以下の罰金/g,
    extract: (m) => ({ fine_max_jpy: parseInt(m[1].replace(/[,，]/g, ''), 10) }),
  },
  {
    kind: 'minor_fine',
    re: /科料/g,
    extract: () => ({}),
  },
  {
    kind: 'detention_minor',
    re: /拘留/g,
    extract: () => ({}),
  },
  {
    kind: 'forfeit',
    re: /没収する/g,
    extract: () => ({ obligatory: true }),
  },
  {
    kind: 'forfeit',
    re: /没収することができる/g,
    extract: () => ({ obligatory: false }),
  },
];

const JURIDICAL_PERSON_RE = /両罰|法人(?:の代表者|の代理人)|前項の罰金/;

/**
 * 罰則条文を抽出
 */
export function extractPenalties(input: {
  source_law: string;
  source_article?: string;
  text: string;
}): PenaltyExtractionResult {
  const atoms: PenaltyAtom[] = [];
  const defects: string[] = [];

  for (const p of PATTERNS) {
    const re = new RegExp(p.re.source, 'g');
    let m: RegExpExecArray | null;
    while ((m = re.exec(input.text)) !== null) {
      const atom: PenaltyAtom = {
        kind: p.kind,
        raw_match: m[0],
        ...p.extract(m),
      };
      // 両罰規定の判定
      if (JURIDICAL_PERSON_RE.test(input.text.substring(Math.max(0, m.index - 100), Math.min(input.text.length, m.index + 200)))) {
        atom.juridical_person_aggravation = true;
      }
      atoms.push(atom);
    }
  }

  // 罪刑法定の適合性
  if (atoms.length === 0 && /禁止する|してはならない|義務|違反/.test(input.text)) {
    defects.push('禁止規定があるが罰則が明示されていない (罪刑法定主義違反のおそれ)');
  }

  // 「処する」「罰する」だけで具体的な刑種金額がない場合
  if (/処する|罰する/.test(input.text) && atoms.length === 0) {
    defects.push('「処する」「罰する」のみで刑種・量刑が不明確');
  }

  // 重複/矛盾
  const hasImprisonment = atoms.some((a) => a.kind === 'imprisonment' || a.kind === 'detention' || a.kind === 'imprisonment_without_labor');
  const hasFine = atoms.some((a) => a.kind === 'fine');
  if (hasImprisonment && hasFine) {
    // 併科の可能性をチェック
    if (!/併科|又は/.test(input.text)) {
      defects.push('懲役と罰金の関係 (択一/併科) が明示されていない');
    }
  }

  const severity = computeSeverity(atoms);
  return {
    source_law: input.source_law,
    source_article: input.source_article,
    atoms,
    severity_score: severity,
    is_definite: defects.length === 0 && atoms.length > 0,
    defect_reasons: defects,
  };
}

function computeSeverity(atoms: PenaltyAtom[]): number {
  let s = 0;
  for (const a of atoms) {
    if (a.kind === 'death') s += 100;
    else if (a.kind === 'life_imprisonment') s += 90;
    else if (a.kind === 'imprisonment' || a.kind === 'detention') {
      s += Math.min(70, (a.imprisonment_max_years ?? 1) * 5);
    } else if (a.kind === 'imprisonment_without_labor') {
      s += Math.min(60, (a.imprisonment_max_years ?? 1) * 4);
    } else if (a.kind === 'fine') {
      s += Math.min(40, Math.log10(Math.max(1, a.fine_max_jpy ?? 1)) * 5);
    } else if (a.kind === 'forfeit') {
      s += a.obligatory ? 20 : 10;
    } else if (a.kind === 'minor_fine' || a.kind === 'detention_minor') {
      s += 5;
    }
  }
  return Math.min(100, Math.round(s));
}

/**
 * 量刑相場のマッチング (検索用)
 */
export function describeSeverity(score: number): string {
  if (score >= 80) return '極重 (死刑・無期級)';
  if (score >= 60) return '重罪 (長期懲役・併科)';
  if (score >= 40) return '中等 (有期懲役)';
  if (score >= 20) return '軽罪 (罰金・短期懲役)';
  return '軽微 (科料・拘留)';
}
