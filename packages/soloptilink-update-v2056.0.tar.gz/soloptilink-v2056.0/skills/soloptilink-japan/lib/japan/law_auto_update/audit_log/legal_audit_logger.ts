/**
 * Phase 46-LU-6 / Legal Audit Logger
 *
 * 法令検索・コンプライアンススキャン・契約書生成 等の全アクションを
 * 監査ログ (append-only) に記録する。
 *
 * 用途:
 *  - 「誰がいつ何を検索したか」を保存 → 内部統制 J-SOX 対応
 *  - GDPR Art.30 処理記録 / 個情法第30条 帳簿準備
 *  - 弁護士情報を保護 (Attorney-Client Privilege 観点) → tenant 分離必須
 *  - インシデント発生時の forensic 用途
 */

export type LegalAction =
  | 'rag_search'
  | 'rag_qa'
  | 'compliance_scan'
  | 'contract_generate'
  | 'risk_assess'
  | 'citation_query'
  | 'advisor_ask'
  | 'omega_bridge'
  | 'export_pdf'
  | 'alert_subscribe'
  | 'webhook_register'
  | 'tenant_create_child'
  | 'plan_upgrade'
  | 'admin_login'
  | 'data_delete';

export interface AuditLogEntry {
  log_id: string;
  timestamp: string;
  tenant_id: string;
  user_id: string;
  action: LegalAction;
  /** 操作対象 (法令ID/判例ID/契約種別等) */
  target?: string;
  /** リクエスト本体のハッシュ (PII を直接保存しない) */
  request_hash?: string;
  /** レスポンス概要 (成功/失敗/件数) */
  result_summary?: string;
  /** クライアント IP (匿名化) */
  client_ip_hash?: string;
  /** プラン */
  plan_tier?: string;
  /** 重大度 */
  severity: 'info' | 'warn' | 'error' | 'critical';
  /** 失敗時のエラーメッセージ */
  error?: string;
}

const AUDIT_STORE: AuditLogEntry[] = [];
const MAX_IN_MEMORY = 10000;

export function recordAudit(entry: Omit<AuditLogEntry, 'log_id' | 'timestamp'>): AuditLogEntry {
  const full: AuditLogEntry = {
    log_id: `audit_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    timestamp: new Date().toISOString(),
    ...entry,
  };
  AUDIT_STORE.push(full);
  if (AUDIT_STORE.length > MAX_IN_MEMORY) {
    AUDIT_STORE.splice(0, AUDIT_STORE.length - MAX_IN_MEMORY);
  }
  return full;
}

export interface AuditQuery {
  tenant_id?: string;
  user_id?: string;
  action?: LegalAction;
  severity?: AuditLogEntry['severity'];
  date_from?: string;
  date_to?: string;
  limit?: number;
}

export function queryAudit(q: AuditQuery): AuditLogEntry[] {
  let results = [...AUDIT_STORE];
  if (q.tenant_id) results = results.filter((r) => r.tenant_id === q.tenant_id);
  if (q.user_id) results = results.filter((r) => r.user_id === q.user_id);
  if (q.action) results = results.filter((r) => r.action === q.action);
  if (q.severity) results = results.filter((r) => r.severity === q.severity);
  if (q.date_from) results = results.filter((r) => r.timestamp >= q.date_from!);
  if (q.date_to) results = results.filter((r) => r.timestamp <= q.date_to!);
  results.sort((a, b) => b.timestamp.localeCompare(a.timestamp));
  return results.slice(0, q.limit ?? 100);
}

export function summarizeAudit(input: { tenant_id?: string; date_from?: string }): {
  total_entries: number;
  by_action: Record<string, number>;
  by_severity: Record<string, number>;
  unique_users: number;
  critical_count: number;
} {
  const filtered = queryAudit({ tenant_id: input.tenant_id, date_from: input.date_from, limit: 10000 });
  const byAction: Record<string, number> = {};
  const bySeverity: Record<string, number> = { info: 0, warn: 0, error: 0, critical: 0 };
  const users = new Set<string>();
  for (const e of filtered) {
    byAction[e.action] = (byAction[e.action] ?? 0) + 1;
    bySeverity[e.severity] = (bySeverity[e.severity] ?? 0) + 1;
    users.add(e.user_id);
  }
  return {
    total_entries: filtered.length,
    by_action: byAction,
    by_severity: bySeverity,
    unique_users: users.size,
    critical_count: bySeverity.critical,
  };
}

/**
 * GDPR Art.30 処理記録 のエクスポート
 */
export interface ProcessingRecord {
  controller: string;
  purpose: string;
  categories_of_data: string[];
  recipients: string[];
  retention_period: string;
  technical_safeguards: string[];
}

export function exportProcessingRecord(tenant_id: string): ProcessingRecord {
  return {
    controller: `Tenant ${tenant_id} via SoloptiLinkAI`,
    purpose: '日本法令検索・コンプライアンス支援・契約書生成 (GDPR Art.6(1)(f) 正当利益)',
    categories_of_data: ['ユーザーID', 'クエリ内容ハッシュ', 'IPアドレスハッシュ', 'アクション種別', 'タイムスタンプ'],
    recipients: ['SoloptiLinkAI内部監査', 'プラン契約管理者'],
    retention_period: '12ヶ月 (Pro) / 60ヶ月 (Enterprise) / 120ヶ月 (LegalFirm)',
    technical_safeguards: [
      'tenant単位の論理分離',
      'リクエスト本体はハッシュ化保存 (raw PII保存なし)',
      'IPアドレスはBcrypt+saltでハッシュ化',
      '監査ログはWORM (Write Once Read Many) 保管',
      'TLS 1.3 in transit / AES-256 at rest',
    ],
  };
}

/**
 * 内部統制 J-SOX ITGC 用エクスポート
 */
export function exportItgcReport(input: { tenant_id: string; period_from: string; period_to: string }): {
  period: string;
  access_control_evidence: number;
  segregation_of_duties_violations: number;
  change_management_records: number;
} {
  const logs = queryAudit({
    tenant_id: input.tenant_id,
    date_from: input.period_from,
    date_to: input.period_to,
    limit: 10000,
  });
  // 同一ユーザーが admin_login と data_delete を両方行った場合 SoD 違反疑い
  const userActions = new Map<string, Set<LegalAction>>();
  for (const l of logs) {
    if (!userActions.has(l.user_id)) userActions.set(l.user_id, new Set());
    userActions.get(l.user_id)!.add(l.action);
  }
  let sodViolations = 0;
  for (const [, actions] of userActions) {
    if (actions.has('admin_login') && actions.has('data_delete')) sodViolations++;
  }
  return {
    period: `${input.period_from} ~ ${input.period_to}`,
    access_control_evidence: logs.filter((l) => l.action === 'admin_login').length,
    segregation_of_duties_violations: sodViolations,
    change_management_records: logs.filter((l) => l.action === 'plan_upgrade').length,
  };
}

export function _resetAuditForTests(): void {
  AUDIT_STORE.length = 0;
}
