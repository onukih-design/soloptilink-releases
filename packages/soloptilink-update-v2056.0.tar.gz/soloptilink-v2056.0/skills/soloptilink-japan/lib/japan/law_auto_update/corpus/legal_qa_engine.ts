/**
 * Phase 46-LU-2 / Legal QA Engine
 *
 * 「労基法第36条は?」「会社法309条の判例は?」「個情法26条の改正は?」
 * のような自然言語クエリに即答するシンプルな QA エンジン。
 *
 * 設計:
 *  - LLM 不使用 (deterministic / 高速 / オフライン動作)
 *  - 入力解析 → 法令名 + 条番号 + 質問種別 を抽出
 *  - 解決順序:
 *    1) 六法 (six_codes.ts) の key_articles_summary
 *    2) EXTENDED_LAW_CATALOG (catalog_full.ts) のメタ
 *    3) cross_reference_graph.ts の関連法令
 *    4) judiciary_law_link.ts の関連判例
 *    5) e-Gov v2 を経由した動的取得 (オプション)
 */

import {
  getArticleSummaryByName,
  findSixCodeByShortName,
  searchSixCodes,
} from './six_codes';
import { findCasesByLawReference, type CaseLawRef } from './judiciary_law_link';
import { EXTENDED_LAW_CATALOG } from '../catalog_full';

export type QaIntent =
  | 'article_content' // 条文内容
  | 'amendment' // 改正履歴
  | 'related_cases' // 関連判例
  | 'related_laws' // 関連法令
  | 'general_lookup' // 法令検索
  | 'unknown';

export interface QaQuery {
  raw: string;
  law_name?: string;
  article_num?: string;
  intent: QaIntent;
}

export interface QaAnswer {
  query: QaQuery;
  summary?: string;
  cases?: CaseLawRef[];
  amendments?: Array<{ date: string; summary: string }>;
  related?: Array<{ short_name: string; reason: string }>;
  /** 自信度 0-100 */
  confidence: number;
  /** 出典 */
  sources: string[];
}

const LAW_PATTERNS = [
  /(?<name>(?:憲法|日本国憲法|民法|商法|会社法|民訴|民事訴訟法|刑法|刑訴|刑事訴訟法|労基法|労働基準法|労契法|労働契約法|個情法|個人情報保護法|金商法|金融商品取引法|建設業法|宅建業法|医療法|薬機法|介護保険法|著作権法|特許法|商標法|意匠法|不競法|不正競争防止法|電帳法|電子帳簿保存法|独禁法|独占禁止法|下請法|消契法|消費者契約法|特商法|特定商取引法|景表法|景品表示法|公益通報者保護法|フリーランス法|育介法))/,
];

const ARTICLE_PATTERN = /第?([０-９0-9]+(?:の[０-９0-9]+)?)条/;

const INTENT_KEYWORDS: Array<{ intent: QaIntent; keywords: string[] }> = [
  { intent: 'amendment', keywords: ['改正', '最新', 'いつ', '施行'] },
  { intent: 'related_cases', keywords: ['判例', '裁判', '事件', '損害賠償'] },
  { intent: 'related_laws', keywords: ['準用', '関連', '近い', '似た', '関係'] },
  { intent: 'article_content', keywords: ['とは', '内容', '何', 'について', '教えて'] },
];

export function parseQuery(input: string): QaQuery {
  const raw = input.trim();
  let name: string | undefined;
  for (const re of LAW_PATTERNS) {
    const m = re.exec(raw);
    if (m?.groups?.name) {
      name = m.groups.name;
      break;
    }
  }
  let article: string | undefined;
  const am = ARTICLE_PATTERN.exec(raw);
  if (am) article = toHalfWidth(am[1]);

  let intent: QaIntent = 'unknown';
  for (const ik of INTENT_KEYWORDS) {
    if (ik.keywords.some((k) => raw.includes(k))) {
      intent = ik.intent;
      break;
    }
  }
  if (intent === 'unknown' && name && article) intent = 'article_content';
  if (intent === 'unknown' && name) intent = 'general_lookup';

  return { raw, law_name: name, article_num: article, intent };
}

function toHalfWidth(s: string): string {
  return s.replace(/[０-９]/g, (c) => String.fromCharCode(c.charCodeAt(0) - 0xfee0));
}

/**
 * 法令 QA を回答する。
 */
export function answerLegalQuestion(input: string): QaAnswer {
  const query = parseQuery(input);
  const sources: string[] = ['lib/japan/law_auto_update/corpus/six_codes.ts'];

  // 条文内容
  if (query.intent === 'article_content' && query.law_name && query.article_num) {
    const r = getArticleSummaryByName({ shortName: query.law_name, articleNum: query.article_num });
    if (r?.summary) {
      sources.push('tier_s_corpus.json');
      return {
        query,
        summary: `${query.law_name}第${query.article_num}条: ${r.summary}`,
        confidence: 90,
        sources,
        related: [],
      };
    }
  }

  // 改正
  if (query.intent === 'amendment' && query.law_name) {
    const entry = findSixCodeByShortName(query.law_name);
    if (entry) {
      const all = [...(entry.major_amendments ?? []), ...(entry.recent_amendments ?? [])].sort(
        (a, b) => b.date.localeCompare(a.date),
      );
      sources.push('tier_s_corpus.json');
      return {
        query,
        summary: `${query.law_name} の最新改正: ${all[0]?.date ?? '(なし)'} — ${all[0]?.summary ?? ''}`,
        amendments: all,
        confidence: 85,
        sources,
      };
    }
    // EXTENDED_LAW_CATALOG fallback
    const catalogEntry = EXTENDED_LAW_CATALOG.find(
      (e) => e.shortName === query.law_name || e.officialName === query.law_name,
    );
    if (catalogEntry) {
      sources.push('catalog_full.ts');
      return {
        query,
        summary: `${query.law_name} の最終施行日: ${catalogEntry.lastEffectiveDate} (公布: ${catalogEntry.lastPromulgationDate})`,
        confidence: 70,
        sources,
      };
    }
  }

  // 判例
  if (query.intent === 'related_cases' && query.law_name) {
    const ref = query.article_num
      ? `${query.law_name}第${query.article_num}条`
      : query.law_name;
    const cases = findCasesByLawReference(ref);
    sources.push('judiciary_law_link.ts');
    return {
      query,
      summary: `${ref} に関連する判例 ${cases.length} 件`,
      cases,
      confidence: cases.length > 0 ? 85 : 30,
      sources,
    };
  }

  // 関連法令
  if (query.intent === 'related_laws' && query.law_name) {
    const hits = searchSixCodes(query.law_name, 5);
    sources.push('six_codes.ts');
    return {
      query,
      summary: `「${query.law_name}」に関連する六法エントリ ${hits.length} 件`,
      related: hits.map((h) => ({
        short_name: `${h.short_name}第${h.article_num}条`,
        reason: h.summary,
      })),
      confidence: hits.length > 0 ? 70 : 30,
      sources,
    };
  }

  // 検索フォールバック
  const fallback = searchSixCodes(query.raw, 5);
  return {
    query,
    summary: fallback.length > 0 ? `関連条文 ${fallback.length} 件ヒット` : '該当なし',
    related: fallback.map((h) => ({
      short_name: `${h.short_name}第${h.article_num}条`,
      reason: h.summary,
    })),
    confidence: fallback.length > 0 ? 50 : 10,
    sources,
  };
}
