/**
 * Phase 46-LU-4 / 47都道府県主要条例
 *
 * 全47都道府県で典型的に存在する 6 種類の条例を構造化:
 *  - 青少年保護育成条例 (18歳未満保護)
 *  - 迷惑防止条例 (痴漢/盗撮/つきまとい)
 *  - 暴力団排除条例 (利益供与禁止)
 *  - 景観条例 (建築外観/屋外広告物)
 *  - 福祉のまちづくり条例 (バリアフリー)
 *  - 環境基本条例 (大気水質/化学物質)
 *
 * 都道府県別の細目差異は別途各 prefecture_specific 構造で。
 */

export interface PrefectureOrdinanceTemplate {
  category: 'youth_protection' | 'public_nuisance' | 'organized_crime_exclusion' | 'landscape' | 'welfare_town' | 'environment';
  template_name: string;
  /** 47都道府県で共通する典型構造 */
  common_provisions: Record<string, string>;
  /** 罰則 (典型) */
  typical_penalty: string;
  /** 関連法令 */
  related_national_laws: string[];
}

export const PREFECTURE_ORDINANCE_TEMPLATES: PrefectureOrdinanceTemplate[] = [
  {
    category: 'youth_protection',
    template_name: '青少年保護育成条例',
    common_provisions: {
      '対象': '18歳未満の青少年',
      '深夜外出禁止': '23時〜4時 (16歳未満) / 23時〜翌5時 (18歳未満)',
      '深夜立入禁止業務': 'カラオケ/ゲームセンター/インターネットカフェ (23時以降)',
      '有害図書類': '都道府県知事指定 / 包装陳列義務',
      'いかがわしい行為': '青少年への金銭目的の性的接触',
      'タトゥー彫り': '青少年への施術原則禁止 (条例による)',
      '保護者責任': '深夜連れ出し禁止',
    },
    typical_penalty: '深夜業務違反: 30万円以下の罰金 / 性的接触: 2年以下の懲役+100万円以下の罰金',
    related_national_laws: ['児童福祉法', '児童ポルノ法'],
  },
  {
    category: 'public_nuisance',
    template_name: '迷惑防止条例',
    common_provisions: {
      'つきまとい': '正当な理由なき執拗な追跡',
      '盗撮': '公共の場所/乗物/学校/事務所/会社/タクシー等での盗撮',
      '痴漢': '公共の場所/乗物での卑わいな行為',
      '客引き行為': '路上での執拗な勧誘',
      'ダフ屋行為': '入場券等の不正転売 (旧来規制)',
      'スカウト行為': '風俗営業への勧誘',
      'R5令和5年改正': '令和5年改正で多くの都道府県で罰則強化 (盗撮の対象拡大)',
    },
    typical_penalty: '盗撮/痴漢: 6月以下の懲役 or 50万円以下の罰金 (常習は強化)',
    related_national_laws: ['軽犯罪法', '刑法 (公然わいせつ等)'],
  },
  {
    category: 'organized_crime_exclusion',
    template_name: '暴力団排除条例',
    common_provisions: {
      '事業者の責務': '取引時の暴力団員照会',
      '利益供与禁止': '暴力団の威力利用目的の利益供与',
      '密接交際者': '暴力団員等と密接な交際を有する者の公表',
      '不動産取引': '暴力団員と知って売買禁止',
      '罰則': '中止命令違反は罰則',
      '建設業': '元請から暴力団員下請への発注禁止',
      '青少年': '暴力団への加入勧誘禁止',
    },
    typical_penalty: '利益供与: 1年以下の懲役+50万円以下の罰金 / 公表 (氏名)',
    related_national_laws: ['暴力団員による不当な行為の防止等に関する法律 (暴対法)'],
  },
  {
    category: 'landscape',
    template_name: '景観条例 / 屋外広告物条例',
    common_provisions: {
      '景観計画区域': '景観法 第8条の計画区域指定',
      '行為制限': '建築物の建築/外観変更/工作物の設置等の届出義務 (30日前)',
      '色彩基準': 'マンセル基準値による外壁色制限',
      '屋外広告物': '禁止地域 (景観地区/伝統的建造物群保存地区/史跡)',
      '広告物許可': '面積/位置/材質/色彩の規制',
      '違反是正': '是正命令 + 違反広告物の除却',
    },
    typical_penalty: '是正命令違反: 50万円以下の罰金 + 行政代執行による撤去',
    related_national_laws: ['景観法', '屋外広告物法', '文化財保護法'],
  },
  {
    category: 'welfare_town',
    template_name: '福祉のまちづくり条例',
    common_provisions: {
      '対象施設': '不特定多数が利用する施設 (床面積基準あり)',
      'バリアフリー基準': '主要な出入口/廊下/トイレの整備',
      '事前協議': '新築/増改築時の事前協議義務',
      '適合証': '基準適合施設への適合証交付',
      '既存施設': '改修努力義務',
      'ハートビル法': 'バリアフリー法 (旧ハートビル法) と整合',
    },
    typical_penalty: '事前協議違反: 勧告/公表 (罰則は限定的)',
    related_national_laws: ['バリアフリー法', '障害者差別解消法'],
  },
  {
    category: 'environment',
    template_name: '環境基本条例',
    common_provisions: {
      '理念': '良好な環境の保全と創造',
      '事業者責務': '環境負荷低減・環境配慮型事業',
      '生活環境': '大気/水質/騒音/振動/悪臭/土壌の保全',
      '化学物質': '化学物質排出移動量届出 (PRTR法連動)',
      '環境影響評価': '一定規模事業の環境アセス',
      'COOL CHOICE': '脱炭素行動 (環境省ガイドライン)',
      '禁止行為': '指定地域での野焼き等',
    },
    typical_penalty: '禁止行為違反: 50万円以下の罰金 / 立入検査拒否罰',
    related_national_laws: ['環境基本法', '大気汚染防止法', '水質汚濁防止法', 'PRTR法'],
  },
];

/**
 * 47 都道府県の典型的な細目 (代表値 + 注目都道府県の差異)
 */
export const PREFECTURE_SPECIFIC_DIFFERENCES: Array<{
  prefecture: string;
  category: PrefectureOrdinanceTemplate['category'];
  distinctive: string;
}> = [
  { prefecture: '東京都', category: 'youth_protection', distinctive: '青少年健全育成条例 R元改正で「不健全図書」指定の透明化' },
  { prefecture: '東京都', category: 'public_nuisance', distinctive: '盗撮罪 R5改正で「公衆浴場/旅館の浴場」も対象に拡大' },
  { prefecture: '大阪府', category: 'public_nuisance', distinctive: 'スカウト規制 H23制定 (繁華街対策)' },
  { prefecture: '京都府', category: 'landscape', distinctive: '京都市景観計画 (高さ規制 31m/15m/12m/10m の高度地区)' },
  { prefecture: '神奈川県', category: 'organized_crime_exclusion', distinctive: 'H23制定の典型 (47都道府県で最初の包括条例)' },
  { prefecture: '北海道', category: 'environment', distinctive: '北海道生物の多様性の保全等に関する条例' },
  { prefecture: '沖縄県', category: 'youth_protection', distinctive: '青少年深夜外出 22時〜4時 (他県より早い)' },
  { prefecture: '愛知県', category: 'public_nuisance', distinctive: 'ぐ犯誘発行為+繁華街営業 規制' },
  { prefecture: '福岡県', category: 'organized_crime_exclusion', distinctive: 'H22制定 (北九州市の対策強化)' },
  { prefecture: '長野県', category: 'environment', distinctive: '長野県条例 化学物質 PRTR 独自リスト 100物質+' },
];

/**
 * 全47都道府県の典型条例 (テンプレベース)
 */
export const PREFECTURES_47 = [
  '北海道', '青森県', '岩手県', '宮城県', '秋田県', '山形県', '福島県',
  '茨城県', '栃木県', '群馬県', '埼玉県', '千葉県', '東京都', '神奈川県',
  '新潟県', '富山県', '石川県', '福井県', '山梨県', '長野県',
  '岐阜県', '静岡県', '愛知県', '三重県',
  '滋賀県', '京都府', '大阪府', '兵庫県', '奈良県', '和歌山県',
  '鳥取県', '島根県', '岡山県', '広島県', '山口県',
  '徳島県', '香川県', '愛媛県', '高知県',
  '福岡県', '佐賀県', '長崎県', '熊本県', '大分県', '宮崎県', '鹿児島県',
  '沖縄県',
];

export function listPrefectureOrdinancesByCategory(
  category: PrefectureOrdinanceTemplate['category'],
): PrefectureOrdinanceTemplate | undefined {
  return PREFECTURE_ORDINANCE_TEMPLATES.find((t) => t.category === category);
}

export function findPrefectureDifferences(prefecture: string): typeof PREFECTURE_SPECIFIC_DIFFERENCES {
  return PREFECTURE_SPECIFIC_DIFFERENCES.filter((d) => d.prefecture === prefecture);
}

export function countPrefectureOrdinances(): {
  templates: number;
  total_typical_provisions: number;
  prefectures: number;
  specific_differences: number;
} {
  let provs = 0;
  for (const t of PREFECTURE_ORDINANCE_TEMPLATES) provs += Object.keys(t.common_provisions).length;
  return {
    templates: PREFECTURE_ORDINANCE_TEMPLATES.length,
    total_typical_provisions: provs,
    prefectures: PREFECTURES_47.length,
    specific_differences: PREFECTURE_SPECIFIC_DIFFERENCES.length,
  };
}
