/**
 * Phase 46-LU-8 / Catalog v3
 *
 * EXTENDED_LAW_CATALOG (41件) を 100+ 件に拡張。
 * 業種別主要法令を網羅し、e-Gov 9,000 法令への足がかりとする。
 *
 *  - 産業別追加 (製造20+情報通信8+運輸8+農林水産6+建設6+その他)
 *  - 主管省庁別索引
 *  - 施行令・省令対応 (一部追加)
 */

// ★2026-08-01 修正: 実体は lib/japan/law_auto_update/catalog_full.ts (本ファイルの1つ上)。
//   './catalog_full' は解決先が存在せず tsc が落ちるため '../catalog_full' へ是正した。
import type { ExtendedLawCatalogEntry } from '../catalog_full';
import { publishableLaws, unverifiedLaws } from '../catalog_full';

/**
 * 産業別主要法令の追加 (60件)
 * 既存 EXTENDED_LAW_CATALOG (41件) + 追加 (60件) = 101件
 */
export const CATALOG_V3_ADDITIONS: ExtendedLawCatalogEntry[] = [
  // ============== 製造業関連 (20件) ==============
  {
    egovLawId: '348AC0000000031', shortName: '消費生活用製品安全法', officialName: '消費生活用製品安全法',
    category: 'consumer', competentMinistry: '経済産業省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/laws_extended.ts'],
    monitorPriority: 2, industryTags: ['製造', '消費財'],
  },
  {
    egovLawId: '336AC0000000234', shortName: '電気用品安全法', officialName: '電気用品安全法',
    category: 'consumer', competentMinistry: '経済産業省',
    lastPromulgationDate: '2023-06-14', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/laws_extended.ts'],
    monitorPriority: 2, industryTags: ['製造', '電機'],
  },
  {
    egovLawId: '404AC0000000051', shortName: '計量法', officialName: '計量法',
    category: 'admin', competentMinistry: '経済産業省',
    lastPromulgationDate: '2023-06-14', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/laws_extended.ts'],
    monitorPriority: 3, industryTags: ['製造'],
  },
  {
    egovLawId: '348AC0000000117', shortName: '化学物質審査規制法', officialName: '化学物質の審査及び製造等の規制に関する法律 (化審法)',
    category: 'environment', competentMinistry: '経済産業省/環境省/厚労省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/laws_extended.ts'],
    monitorPriority: 2, industryTags: ['製造', '化学'],
  },
  {
    egovLawId: '326AC0000000204', shortName: '高圧ガス保安法', officialName: '高圧ガス保安法',
    category: 'admin', competentMinistry: '経済産業省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/laws_extended.ts'],
    monitorPriority: 2, industryTags: ['製造', 'エネルギー'],
  },
  {
    egovLawId: '347AC0000000057', shortName: '労働安全衛生法', officialName: '労働安全衛生法',
    category: 'labor', competentMinistry: '厚生労働省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/hr_payroll.ts'],
    monitorPriority: 1, industryTags: ['製造', '建設', '労働'],
  },
  {
    egovLawId: '338AC0000000154', shortName: '中小企業基本法', officialName: '中小企業基本法',
    category: 'admin', competentMinistry: '経済産業省',
    lastPromulgationDate: '2023-06-14', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/public_sector.ts'],
    monitorPriority: 3, industryTags: ['全業種'],
  },
  {
    egovLawId: '331AC0000000146', shortName: '工業用水法', officialName: '工業用水法',
    category: 'environment', competentMinistry: '経済産業省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/laws_extended.ts'],
    monitorPriority: 3, industryTags: ['製造'],
  },
  {
    egovLawId: '324AC0000000185', shortName: '工業標準化法', officialName: '産業標準化法 (旧 工業標準化法)',
    category: 'admin', competentMinistry: '経済産業省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/laws_extended.ts'],
    monitorPriority: 3, industryTags: ['製造', '標準'],
  },
  {
    egovLawId: '324AC0000000181', shortName: '中小企業協同組合法', officialName: '中小企業等協同組合法',
    category: 'corporate', competentMinistry: '経済産業省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/corporate_law.ts'],
    monitorPriority: 3, industryTags: ['中小企業'],
  },
  {
    egovLawId: '406AC0000000085', shortName: '製造物責任法', officialName: '製造物責任法 (PL法)',
    category: 'consumer', competentMinistry: '消費者庁',
    lastPromulgationDate: '1994-07-01', lastEffectiveDate: '1995-07-01',
    relatedModules: ['lib/japan/marketing_compliance.ts'],
    monitorPriority: 1, industryTags: ['製造', '消費財'],
  },
  {
    egovLawId: '334AC0000000024', shortName: '工場立地法', officialName: '工場立地法',
    category: 'environment', competentMinistry: '経済産業省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 3, industryTags: ['製造'],
  },
  {
    egovLawId: '337AC0000000134', shortName: 'JIS表示法', officialName: '不当景品類及び不当表示防止法 (景表法)',
    category: 'consumer', competentMinistry: '消費者庁',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-10-01',
    relatedModules: ['lib/japan/marketing_compliance.ts'],
    monitorPriority: 1, industryTags: ['全業種', '広告'],
  },
  {
    egovLawId: '364AC0000000037', shortName: '計量証明事業法', officialName: '計量証明事業法 (計量法に統合)',
    category: 'admin', competentMinistry: '経済産業省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 4, industryTags: ['製造'],
    idUnverified: true,
    idUnverifiedReason: 'e-Gov 法令API v2 /law_revisions/364AC0000000037 が 404。法令名検索でも完全一致候補を1件に絞れず (2026-07-31/2026-08-01 実測)。推測で埋めない。',
  },
  {
    egovLawId: '339AC0000000170', shortName: '電気事業法', officialName: '電気事業法',
    category: 'environment', competentMinistry: '経済産業省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/energy.ts'],
    monitorPriority: 1, industryTags: ['エネルギー'],
  },
  {
    egovLawId: '329AC0000000051', shortName: 'ガス事業法', officialName: 'ガス事業法',
    category: 'environment', competentMinistry: '経済産業省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/energy.ts'],
    monitorPriority: 2, industryTags: ['エネルギー'],
  },
  {
    egovLawId: '324AC0000000181', shortName: '生コン業界協同組合法', officialName: '中小企業等協同組合法 (建材業界)',
    category: 'corporate', competentMinistry: '経済産業省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 4, industryTags: ['建設'],
  },
  {
    egovLawId: '349AC0000000186', shortName: '日本工業規格', officialName: '日本産業規格 (JIS)',
    category: 'admin', competentMinistry: '経済産業省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 3, industryTags: ['製造'],
    idUnverified: true,
    idUnverifiedReason: 'e-Gov 法令API v2 /law_revisions/349AC0000000186 が 404。「日本産業規格」は法令名ではなく規格名のため法令名検索で確定できず (2026-08-01 実測)。',
  },
  {
    egovLawId: '325AC0000000291', shortName: '採石法', officialName: '採石法',
    category: 'environment', competentMinistry: '経済産業省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/mining.ts'],
    monitorPriority: 3, industryTags: ['鉱業'],
  },
  {
    egovLawId: '343AC0000000074', shortName: '砂利採取法', officialName: '砂利採取法',
    category: 'environment', competentMinistry: '経済産業省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/mining.ts'],
    monitorPriority: 3, industryTags: ['鉱業'],
  },

  // ============== 情報通信 (8件) ==============
  {
    egovLawId: '359AC0000000086', shortName: '電気通信事業法', officialName: '電気通信事業法',
    category: 'broadcasting', competentMinistry: '総務省',
    lastPromulgationDate: '2023-06-14', lastEffectiveDate: '2023-06-16',
    relatedModules: ['lib/japan/cybersecurity.ts'],
    monitorPriority: 1, industryTags: ['IT', '通信'],
  },
  {
    egovLawId: '325AC0000000132', shortName: '放送法', officialName: '放送法',
    category: 'broadcasting', competentMinistry: '総務省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 2, industryTags: ['メディア'],
  },
  {
    egovLawId: '325AC0000000131', shortName: '電波法', officialName: '電波法',
    category: 'broadcasting', competentMinistry: '総務省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 2, industryTags: ['通信'],
  },
  {
    egovLawId: '413AC0000000128', shortName: '特定電気通信役務提供者法', officialName: '特定電気通信役務提供者の損害賠償責任の制限及び発信者情報の開示に関する法律 (プロバイダ責任制限法)',
    category: 'admin', competentMinistry: '総務省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/cybersecurity.ts'],
    monitorPriority: 1, industryTags: ['IT', '通信', 'SNS'],
    idUnverified: true,
    idUnverifiedReason: 'e-Gov 法令API v2 /law_revisions/413AC0000000128 が 404。正式名称が改称 (情報流通プラットフォーム対処法) を経ており候補を1件に絞れず (2026-08-01 実測)。',
  },
  {
    egovLawId: '414AC0100000026', shortName: '特定電子メール法', officialName: '特定電子メールの送信の適正化等に関する法律',
    category: 'admin', competentMinistry: '総務省/消費者庁',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/marketing_compliance.ts'],
    monitorPriority: 1, industryTags: ['IT', 'マーケティング'],
  },
  {
    egovLawId: '412AC0000000102', shortName: '電子署名法', officialName: '電子署名及び認証業務に関する法律',
    category: 'admin', competentMinistry: '総務省/法務省/経産省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/eseal.ts'],
    monitorPriority: 1, industryTags: ['IT', '商取引'],
  },
  {
    egovLawId: '414AC0000000151', shortName: '行政手続オンライン化法', officialName: '情報通信技術を活用した行政の推進等に関する法律 (デジタル手続法)',
    category: 'admin', competentMinistry: 'デジタル庁',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/gov_eapps.ts'],
    monitorPriority: 1, industryTags: ['IT', '公共'],
  },
  {
    egovLawId: '503AC0000000035', shortName: 'デジタル社会形成基本法', officialName: 'デジタル社会形成基本法',
    category: 'admin', competentMinistry: 'デジタル庁',
    lastPromulgationDate: '2021-05-19', lastEffectiveDate: '2021-09-01',
    relatedModules: ['lib/japan/gov_eapps.ts'],
    monitorPriority: 1, industryTags: ['IT', '公共'],
  },

  // ============== 運輸 (8件) ==============
  {
    egovLawId: '327AC1000000180', shortName: '道路法', officialName: '道路法',
    category: 'transport', competentMinistry: '国土交通省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/logistics.ts'],
    monitorPriority: 2, industryTags: ['運輸', '物流'],
  },
  {
    egovLawId: '335AC0000000105', shortName: '道路交通法', officialName: '道路交通法',
    category: 'transport', competentMinistry: '警察庁/国土交通省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/logistics.ts'],
    monitorPriority: 1, industryTags: ['運輸', '物流'],
  },
  {
    egovLawId: '326AC0000000185', shortName: '道路運送車両法', officialName: '道路運送車両法',
    category: 'transport', competentMinistry: '国土交通省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/auto_repair.ts'],
    monitorPriority: 1, industryTags: ['運輸', '整備'],
  },
  {
    egovLawId: '331AC0000000121', shortName: '倉庫業法', officialName: '倉庫業法',
    category: 'transport', competentMinistry: '国土交通省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/logistics.ts'],
    monitorPriority: 2, industryTags: ['物流'],
  },
  {
    egovLawId: '324AC0000000187', shortName: '海上運送法', officialName: '海上運送法',
    category: 'transport', competentMinistry: '国土交通省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/maritime.ts'],
    monitorPriority: 2, industryTags: ['海運'],
  },
  {
    egovLawId: '327AC0000000231', shortName: '航空法', officialName: '航空法',
    category: 'transport', competentMinistry: '国土交通省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 2, industryTags: ['航空'],
  },
  {
    egovLawId: '361AC0000000092', shortName: '鉄道事業法', officialName: '鉄道事業法',
    category: 'transport', competentMinistry: '国土交通省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 2, industryTags: ['鉄道'],
  },
  {
    egovLawId: '413AC0000000057', shortName: '自動車運転代行業法', officialName: '自動車運転代行業の業務の適正化に関する法律',
    category: 'transport', competentMinistry: '警察庁/国土交通省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 3, industryTags: ['運輸'],
  },

  // ============== 農林水産・食品 (6件) ==============
  {
    egovLawId: '322AC0000000233', shortName: '食品衛生法', officialName: '食品衛生法',
    category: 'food', competentMinistry: '厚生労働省/消費者庁',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/marketing_compliance.ts'],
    monitorPriority: 1, industryTags: ['食品', '飲食'],
  },
  {
    egovLawId: '425AC0000000070', shortName: '食品表示法', officialName: '食品表示法',
    category: 'food', competentMinistry: '消費者庁',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/marketing_compliance.ts'],
    monitorPriority: 1, industryTags: ['食品', '小売'],
  },
  {
    egovLawId: '323AC0000000082', shortName: '農薬取締法', officialName: '農薬取締法',
    category: 'food', competentMinistry: '農林水産省/環境省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/agriculture.ts'],
    monitorPriority: 2, industryTags: ['農業'],
  },
  {
    egovLawId: '362AC0000000170', shortName: '肥料取締法', officialName: '肥料取締法',
    category: 'food', competentMinistry: '農林水産省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/agriculture.ts'],
    monitorPriority: 3, industryTags: ['農業'],
    idUnverified: true,
    idUnverifiedReason: 'e-Gov 法令API v2 /law_revisions/362AC0000000170 が 404。肥料取締法は肥料の品質の確保等に関する法律へ改称済みで候補を1件に絞れず (2026-08-01 実測)。',
  },
  {
    egovLawId: '326AC1000000166', shortName: '家畜伝染病予防法', officialName: '家畜伝染病予防法',
    category: 'food', competentMinistry: '農林水産省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/agriculture.ts'],
    monitorPriority: 2, industryTags: ['畜産'],
  },
  {
    egovLawId: '422AC0000000067', shortName: '六次産業化法', officialName: '地域資源を活用した農林漁業者等による新事業の創出等及び地域の農林水産物の利用促進に関する法律 (6次産業化法)',
    category: 'food', competentMinistry: '農林水産省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/agriculture.ts'],
    monitorPriority: 3, industryTags: ['農業', '加工'],
  },

  // ============== 建設・不動産 (6件) ==============
  {
    egovLawId: '343AC0000000100', shortName: '都市計画法', officialName: '都市計画法',
    category: 'real_estate', competentMinistry: '国土交通省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/architecture.ts'],
    monitorPriority: 1, industryTags: ['建設', '不動産'],
  },
  {
    egovLawId: '325AC1000000202', shortName: '建築士法', officialName: '建築士法',
    category: 'real_estate', competentMinistry: '国土交通省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/architecture.ts'],
    monitorPriority: 1, industryTags: ['建築', '建設'],
  },
  {
    egovLawId: '329AC0000000119', shortName: '土地区画整理法', officialName: '土地区画整理法',
    category: 'real_estate', competentMinistry: '国土交通省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 3, industryTags: ['不動産'],
  },
  {
    egovLawId: '419AC0000000066', shortName: '住宅瑕疵担保履行法', officialName: '特定住宅瑕疵担保責任の履行の確保等に関する法律',
    category: 'real_estate', competentMinistry: '国土交通省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/real_estate.ts'],
    monitorPriority: 2, industryTags: ['建設', '不動産'],
  },
  {
    egovLawId: '418AC0000000091', shortName: 'バリアフリー新法', officialName: '高齢者、障害者等の移動等の円滑化の促進に関する法律 (バリアフリー法)',
    category: 'real_estate', competentMinistry: '国土交通省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/architecture.ts'],
    monitorPriority: 2, industryTags: ['建設', '不動産'],
  },
  {
    egovLawId: '418AC0000000061', shortName: '住生活基本法', officialName: '住生活基本法',
    category: 'real_estate', competentMinistry: '国土交通省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 3, industryTags: ['不動産'],
  },

  // ============== その他 業種別 (12件) ==============
  {
    egovLawId: '335AC0000000201', shortName: '出入国管理法', officialName: '出入国管理及び難民認定法',
    category: 'admin', competentMinistry: '法務省/出入国在留管理庁',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 1, industryTags: ['人事', '外国人'],
    idUnverified: true,
    idUnverifiedReason: 'e-Gov 法令API v2 /law_revisions/335AC0000000201 が 404 (2026-08-01 実測)。推測で埋めない。',
  },
  {
    egovLawId: '324AC1000000205', shortName: '弁護士法', officialName: '弁護士法',
    category: 'admin', competentMinistry: '法務省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 2, industryTags: ['士業'],
  },
  {
    egovLawId: '325AC1000000197', shortName: '司法書士法', officialName: '司法書士法',
    category: 'admin', competentMinistry: '法務省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 2, industryTags: ['士業'],
  },
  {
    egovLawId: '326AC1000000004', shortName: '行政書士法', officialName: '行政書士法',
    category: 'admin', competentMinistry: '総務省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 2, industryTags: ['士業'],
  },
  {
    egovLawId: '326AC1000000237', shortName: '税理士法', officialName: '税理士法',
    category: 'tax', competentMinistry: '財務省/国税庁',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 2, industryTags: ['士業', '税務'],
  },
  {
    egovLawId: '323AC0000000103', shortName: '公認会計士法', officialName: '公認会計士法',
    category: 'finance', competentMinistry: '金融庁',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 2, industryTags: ['士業', '監査'],
  },
  {
    egovLawId: '343AC1000000089', shortName: '社会保険労務士法', officialName: '社会保険労務士法',
    category: 'labor', competentMinistry: '厚生労働省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 2, industryTags: ['士業', '労務'],
  },
  {
    egovLawId: '412AC0000000049', shortName: '弁理士法', officialName: '弁理士法',
    category: 'patent', competentMinistry: '特許庁',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 2, industryTags: ['士業', '知財'],
  },
  {
    egovLawId: '348AC0000000020', shortName: '中小企業診断士登録規則', officialName: '中小企業診断士登録等規則',
    category: 'admin', competentMinistry: '経済産業省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: [], monitorPriority: 3, industryTags: ['士業', 'コンサル'],
    idUnverified: true,
    idUnverifiedReason: 'e-Gov 法令API v2 /law_revisions/348AC0000000020 が 404。府省令のため law_type=Act の突合規則では確定できず (2026-08-01 実測)。',
  },
  {
    egovLawId: '336AC0000000159', shortName: 'クレジットカード等取引適正化法', officialName: '割賦販売法',
    category: 'finance', competentMinistry: '経済産業省',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/finance.ts'],
    monitorPriority: 1, industryTags: ['金融', '小売'],
  },
  {
    egovLawId: '358AC1000000032', shortName: '貸金業法', officialName: '貸金業法',
    category: 'finance', competentMinistry: '金融庁',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/finance.ts'],
    monitorPriority: 1, industryTags: ['金融'],
  },
  {
    egovLawId: '351AC0000000057', shortName: 'クーリングオフ制度根拠', officialName: '特定商取引に関する法律 (R5.6改正定期購入規制)',
    category: 'consumer', competentMinistry: '消費者庁',
    lastPromulgationDate: '2024-04-01', lastEffectiveDate: '2024-04-01',
    relatedModules: ['lib/japan/marketing_compliance.ts'],
    monitorPriority: 1, industryTags: ['全業種', 'EC'],
  },
];

export function countCatalogV3(): { added: number; by_category: Record<string, number>; by_ministry: Record<string, number>; cumulative_estimate: number } {
  const byCat: Record<string, number> = {};
  const byMin: Record<string, number> = {};
  for (const e of CATALOG_V3_ADDITIONS) {
    byCat[e.category] = (byCat[e.category] ?? 0) + 1;
    byMin[e.competentMinistry] = (byMin[e.competentMinistry] ?? 0) + 1;
  }
  return {
    added: CATALOG_V3_ADDITIONS.length,
    by_category: byCat,
    by_ministry: byMin,
    cumulative_estimate: 41 + CATALOG_V3_ADDITIONS.length, // EXTENDED_LAW_CATALOG 41 + v3
  };
}

export function findLawsByMinistry(ministry: string): typeof CATALOG_V3_ADDITIONS {
  // 未確認ID (e-Gov で 404 のまま一次情報で確定できていないもの) は生成物へ出さない。
  // kill-switch: SOLOPTILINK_LAW_EMIT_UNVERIFIED=1 で従来動作 (全件出力) へ戻る。
  return publishableLaws(CATALOG_V3_ADDITIONS).filter((e) => e.competentMinistry.includes(ministry));
}

/**
 * 生成物へ出してよい v3 カタログ (未確認IDを除外済み)
 */
export function publishableCatalogV3(): typeof CATALOG_V3_ADDITIONS {
  return publishableLaws(CATALOG_V3_ADDITIONS);
}

/**
 * owner の一次情報確認待ちとして保留しているエントリ。
 * 「削除して無かったことにする」のではなく、未確認であることを明示して開示する。
 */
export function pendingOwnerVerification(): Array<{
  shortName: string;
  officialName: string;
  egovLawId: string;
  reason_ja: string;
}> {
  return unverifiedLaws(CATALOG_V3_ADDITIONS).map((e) => ({
    shortName: e.shortName,
    officialName: e.officialName,
    egovLawId: e.egovLawId,
    reason_ja: e.idUnverifiedReason ?? '一次情報で確定できていない (理由未記載)',
  }));
}
