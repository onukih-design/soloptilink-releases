/**
 * Phase 46-LU-4 supplement / 判例 DB 整合性レポート
 *
 * 全判例ソース (LANDMARK + EXTENDED + SUPPLEMENT) を統合した後の整合性検証:
 *  - case_id 重複なし
 *  - citation 重複/近接なし
 *  - 通称+判決日 重複なし
 *  - law_areas が空でない
 *  - decision_date が ISO 形式
 *  - related_laws が 1 件以上
 *  - 領域別バランス (1領域に偏っていないか)
 */

import type { CaseLawRef } from './judiciary_law_link';
import { LANDMARK_CASES_INDEX } from './judiciary_law_link';
import { EXTENDED_LANDMARK_CASES } from './case_law_extended';
import { SUPPLEMENT_LANDMARK_CASES } from './case_law_supplement';
import {
  detectIdDuplicates,
  detectExactCitationDuplicates,
  detectNameDateDuplicates,
  detectCitationNearDuplicates,
  dedupeCases,
} from './case_dedup';

export interface IntegrityReport {
  generated_at: string;
  total_count: number;
  by_source: { landmark: number; extended: number; supplement: number };
  unique_after_dedup: number;
  duplicate_count: number;
  duplicate_breakdown: {
    by_id: number;
    by_citation: number;
    by_name_date: number;
    by_near_citation: number;
  };
  validation_errors: Array<{ case_id: string; field: string; reason: string }>;
  area_distribution: Record<string, number>;
  balance_warning: string[];
  /** 0-100 の整合性スコア (高いほど良好) */
  integrity_score: number;
}

export function buildIntegrityReport(): IntegrityReport {
  const all = [
    ...LANDMARK_CASES_INDEX,
    ...EXTENDED_LANDMARK_CASES,
    ...SUPPLEMENT_LANDMARK_CASES,
  ];

  const idDups = detectIdDuplicates(all);
  const exactCitationDups = detectExactCitationDuplicates(all);
  const nameDateDups = detectNameDateDuplicates(all);
  const nearCitationDups = detectCitationNearDuplicates(all, 0.92);

  const dedup = dedupeCases(all);

  const validationErrors: IntegrityReport['validation_errors'] = [];
  for (const c of all) {
    if (!c.law_areas || c.law_areas.length === 0) {
      validationErrors.push({ case_id: c.case_id, field: 'law_areas', reason: 'empty array' });
    }
    if (!/^\d{4}-\d{2}-\d{2}$/.test(c.decision_date)) {
      validationErrors.push({ case_id: c.case_id, field: 'decision_date', reason: `invalid ISO date: ${c.decision_date}` });
    }
    if (!c.related_laws || c.related_laws.length === 0) {
      validationErrors.push({ case_id: c.case_id, field: 'related_laws', reason: 'empty array' });
    }
    if (!c.citation || c.citation.trim().length < 5) {
      validationErrors.push({ case_id: c.case_id, field: 'citation', reason: 'too short' });
    }
  }

  // 領域別カウント
  const areaDist: Record<string, number> = {};
  for (const c of all) {
    for (const la of c.law_areas) areaDist[la] = (areaDist[la] ?? 0) + 1;
  }
  const totalAreaHits = Object.values(areaDist).reduce((a, b) => a + b, 0);
  const balanceWarning: string[] = [];
  for (const [area, n] of Object.entries(areaDist)) {
    const pct = (n / totalAreaHits) * 100;
    if (pct > 40) balanceWarning.push(`${area} が ${pct.toFixed(1)}% を占めており偏りあり`);
  }

  // 整合性スコア計算
  let score = 100;
  score -= idDups.length * 10;
  score -= exactCitationDups.length * 5;
  score -= nameDateDups.length * 5;
  score -= nearCitationDups.length * 2;
  score -= validationErrors.length * 1;
  score -= balanceWarning.length * 3;
  score = Math.max(0, Math.min(100, score));

  return {
    generated_at: new Date().toISOString(),
    total_count: all.length,
    by_source: {
      landmark: LANDMARK_CASES_INDEX.length,
      extended: EXTENDED_LANDMARK_CASES.length,
      supplement: SUPPLEMENT_LANDMARK_CASES.length,
    },
    unique_after_dedup: dedup.unique.length,
    duplicate_count: dedup.removed,
    duplicate_breakdown: {
      by_id: idDups.length,
      by_citation: exactCitationDups.length,
      by_name_date: nameDateDups.length,
      by_near_citation: nearCitationDups.length,
    },
    validation_errors: validationErrors,
    area_distribution: areaDist,
    balance_warning: balanceWarning,
    integrity_score: score,
  };
}

/**
 * テキスト形式の整合性レポート
 */
export function renderIntegrityReport(): string {
  const r = buildIntegrityReport();
  const lines: string[] = [];
  lines.push('=== 判例 DB 整合性レポート ===');
  lines.push(`生成日時: ${r.generated_at}`);
  lines.push('');
  lines.push(`総判例数: ${r.total_count}`);
  lines.push(`  Landmark: ${r.by_source.landmark}`);
  lines.push(`  Extended: ${r.by_source.extended}`);
  lines.push(`  Supplement: ${r.by_source.supplement}`);
  lines.push(`unique (dedup後): ${r.unique_after_dedup}`);
  lines.push(`重複検出: ${r.duplicate_count} 件`);
  lines.push('');
  lines.push('=== 重複内訳 ===');
  lines.push(`  case_id 完全重複: ${r.duplicate_breakdown.by_id}`);
  lines.push(`  citation 完全重複: ${r.duplicate_breakdown.by_citation}`);
  lines.push(`  short_name+decision_date 重複: ${r.duplicate_breakdown.by_name_date}`);
  lines.push(`  citation 近接 (92%): ${r.duplicate_breakdown.by_near_citation}`);
  lines.push('');
  lines.push('=== バリデーションエラー ===');
  if (r.validation_errors.length === 0) lines.push('  なし');
  else for (const e of r.validation_errors.slice(0, 10)) {
    lines.push(`  - ${e.case_id} / ${e.field}: ${e.reason}`);
  }
  lines.push('');
  lines.push('=== 領域別分布 ===');
  for (const [area, n] of Object.entries(r.area_distribution).sort((a, b) => b[1] - a[1])) {
    lines.push(`  ${area.padEnd(20)} ${n}`);
  }
  lines.push('');
  lines.push('=== 偏り警告 ===');
  if (r.balance_warning.length === 0) lines.push('  なし');
  else for (const w of r.balance_warning) lines.push(`  ⚠️ ${w}`);
  lines.push('');
  lines.push(`=== 整合性スコア: ${r.integrity_score} / 100 ===`);
  if (r.integrity_score === 100) lines.push('  ★★★★★ Perfect Integrity (整合性完璧)');
  else if (r.integrity_score >= 95) lines.push('  ★★★★☆ Excellent (修正不要レベル)');
  else if (r.integrity_score >= 80) lines.push('  ★★★☆☆ Good (軽微な修正推奨)');
  else lines.push('  ★★☆☆☆ Needs Improvement (修正必須)');
  return lines.join('\n');
}

/**
 * 数値サマリのみ (JSON 化用)
 */
export function summarizeIntegrity(): {
  total: number;
  unique: number;
  integrity_score: number;
  duplicate_count: number;
  validation_error_count: number;
} {
  const r = buildIntegrityReport();
  return {
    total: r.total_count,
    unique: r.unique_after_dedup,
    integrity_score: r.integrity_score,
    duplicate_count: r.duplicate_count,
    validation_error_count: r.validation_errors.length,
  };
}
