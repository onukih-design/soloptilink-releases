/**
 * Phase 46-LU-7 / Incident Response Orchestrator
 *
 * 法務 SaaS 運用の障害・セキュリティインシデント自動対応。
 * NIST SP 800-61 準拠の Preparation/Detection/Containment/Eradication/Recovery/Lessons の
 * 6 ステップに沿った Runbook + 自動エスカレーション + ポストモーテム生成。
 */

export type IncidentSeverity = 'SEV1' | 'SEV2' | 'SEV3' | 'SEV4';
export type IncidentStatus = 'detected' | 'investigating' | 'mitigating' | 'resolved' | 'postmortem';

export type IncidentCategory =
  | 'service_down'
  | 'data_breach'
  | 'security_attack'
  | 'data_loss'
  | 'performance_degradation'
  | 'integration_failure'
  | 'compliance_violation'
  | 'change_detector_stale'; // 改正検知が止まった

export interface Incident {
  incident_id: string;
  severity: IncidentSeverity;
  category: IncidentCategory;
  title: string;
  description: string;
  detected_at: string;
  status: IncidentStatus;
  /** 影響テナント */
  affected_tenants?: string[];
  /** 影響サービス */
  affected_services: string[];
  /** 関連メトリクス */
  related_metrics?: string[];
  /** タイムライン */
  timeline: Array<{ at: string; actor: string; action: string }>;
  /** 法令通知義務 */
  legal_notifications: Array<{ agency: string; deadline_hours: number; sent: boolean }>;
  /** ポストモーテム */
  postmortem?: PostMortem;
}

export interface PostMortem {
  root_cause: string;
  contributing_factors: string[];
  timeline_summary: string;
  customer_impact: string;
  action_items: Array<{ description: string; owner: string; due_date: string }>;
  blameless: boolean;
}

const INCIDENT_STORE = new Map<string, Incident>();

/**
 * SEV 判定ルール
 */
export function classifyIncidentSeverity(input: {
  affected_users?: number;
  affected_tenants?: number;
  data_breach?: boolean;
  service_downtime_minutes?: number;
}): IncidentSeverity {
  if (input.data_breach) return 'SEV1';
  if ((input.affected_tenants ?? 0) >= 10) return 'SEV1';
  if ((input.affected_users ?? 0) >= 10000) return 'SEV1';
  if ((input.service_downtime_minutes ?? 0) >= 60) return 'SEV2';
  if ((input.affected_users ?? 0) >= 1000) return 'SEV2';
  if ((input.service_downtime_minutes ?? 0) >= 15) return 'SEV3';
  if ((input.affected_users ?? 0) >= 100) return 'SEV3';
  return 'SEV4';
}

/**
 * 法令通知義務の自動判定
 */
export function deriveLegalNotifications(input: {
  category: IncidentCategory;
  affected_pii_count?: number;
}): Incident['legal_notifications'] {
  const out: Incident['legal_notifications'] = [];
  if (input.category === 'data_breach' || (input.affected_pii_count ?? 0) > 0) {
    out.push({ agency: '個情委 (個情法第26条)', deadline_hours: 72, sent: false });
    if ((input.affected_pii_count ?? 0) >= 1000) {
      out.push({ agency: '本人通知 (個情法第26条)', deadline_hours: 30 * 24, sent: false });
    }
  }
  if (input.category === 'security_attack' || input.category === 'data_breach') {
    out.push({ agency: 'JPCERT/CC', deadline_hours: 24, sent: false });
  }
  return out;
}

export function createIncident(input: {
  category: IncidentCategory;
  title: string;
  description: string;
  affected_services: string[];
  affected_tenants?: string[];
  affected_pii_count?: number;
  affected_users?: number;
  service_downtime_minutes?: number;
}): Incident {
  const severity = classifyIncidentSeverity({
    affected_users: input.affected_users,
    affected_tenants: input.affected_tenants?.length,
    data_breach: input.category === 'data_breach',
    service_downtime_minutes: input.service_downtime_minutes,
  });
  const incident: Incident = {
    incident_id: `inc_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    severity,
    category: input.category,
    title: input.title,
    description: input.description,
    detected_at: new Date().toISOString(),
    status: 'detected',
    affected_services: input.affected_services,
    affected_tenants: input.affected_tenants,
    timeline: [{ at: new Date().toISOString(), actor: 'system', action: 'incident detected' }],
    legal_notifications: deriveLegalNotifications({ category: input.category, affected_pii_count: input.affected_pii_count }),
  };
  INCIDENT_STORE.set(incident.incident_id, incident);
  return incident;
}

export function appendTimeline(incident_id: string, entry: { actor: string; action: string }): boolean {
  const inc = INCIDENT_STORE.get(incident_id);
  if (!inc) return false;
  inc.timeline.push({ at: new Date().toISOString(), ...entry });
  return true;
}

export function transitionStatus(incident_id: string, newStatus: IncidentStatus): boolean {
  const inc = INCIDENT_STORE.get(incident_id);
  if (!inc) return false;
  inc.status = newStatus;
  inc.timeline.push({ at: new Date().toISOString(), actor: 'system', action: `status → ${newStatus}` });
  return true;
}

export function buildPostMortem(incident_id: string, input: Omit<PostMortem, 'blameless'>): PostMortem | undefined {
  const inc = INCIDENT_STORE.get(incident_id);
  if (!inc) return undefined;
  const pm: PostMortem = { ...input, blameless: true };
  inc.postmortem = pm;
  inc.status = 'postmortem';
  return pm;
}

/**
 * SEV1 自動エスカレーション (RACI ベース)
 */
export interface EscalationPlan {
  responsible: string[];
  accountable: string;
  consulted: string[];
  informed: string[];
  escalation_minutes: number; // 何分後に上位に上げるか
}

export function deriveEscalation(severity: IncidentSeverity): EscalationPlan {
  switch (severity) {
    case 'SEV1':
      return {
        responsible: ['オンコール SRE', 'セキュリティチーム'],
        accountable: 'CTO',
        consulted: ['法務最高責任者 (CLO)', '広報'],
        informed: ['CEO', '取締役会', '顧客全員'],
        escalation_minutes: 15,
      };
    case 'SEV2':
      return {
        responsible: ['オンコール SRE'],
        accountable: 'エンジニアリングマネージャー',
        consulted: ['プロダクトマネージャー'],
        informed: ['CTO', '影響顧客'],
        escalation_minutes: 30,
      };
    case 'SEV3':
      return {
        responsible: ['担当エンジニア'],
        accountable: 'チームリード',
        consulted: ['QA'],
        informed: ['SRE'],
        escalation_minutes: 120,
      };
    default:
      return {
        responsible: ['担当エンジニア'],
        accountable: '担当エンジニア',
        consulted: [],
        informed: ['チームリード'],
        escalation_minutes: 480,
      };
  }
}

export function getIncident(incident_id: string): Incident | undefined {
  return INCIDENT_STORE.get(incident_id);
}

export function listIncidents(input?: { status?: IncidentStatus; severity?: IncidentSeverity }): Incident[] {
  let r = [...INCIDENT_STORE.values()];
  if (input?.status) r = r.filter((i) => i.status === input.status);
  if (input?.severity) r = r.filter((i) => i.severity === input.severity);
  return r.sort((a, b) => b.detected_at.localeCompare(a.detected_at));
}

export function summarizeIncidents(): { total: number; by_severity: Record<string, number>; open: number } {
  const bySev: Record<string, number> = { SEV1: 0, SEV2: 0, SEV3: 0, SEV4: 0 };
  let open = 0;
  for (const i of INCIDENT_STORE.values()) {
    bySev[i.severity]++;
    if (i.status !== 'resolved' && i.status !== 'postmortem') open++;
  }
  return { total: INCIDENT_STORE.size, by_severity: bySev, open };
}

export function _resetIncidentsForTests(): void {
  INCIDENT_STORE.clear();
}
