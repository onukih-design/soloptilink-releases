/**
 * Phase 46-LU-4 / Saturation Dashboard
 *
 * 知識飽和度 (Knowledge Saturation) の可視化。
 *  - Phase 46-LU の monitorPriority×Tier カバレッジ
 *  - 判例総数 (Phase 46-LU + LU-3 + LU-4 = 累計125件+)
 *  - 都道府県条例 47/47
 *  - 政令市条例 20/20
 *  - 海外比較法 4 法域
 *  - 学説論争 20件
 *  - Diamond ラインまでの距離
 */

import { analyzeKnowledgeGaps } from './knowledge_gap_analyzer';
import { buildCoverageMatrix, summarizeMatrixAsJson } from './coverage_matrix';
import { LANDMARK_CASES_INDEX } from '../corpus/judiciary_law_link';
import { EXTENDED_LANDMARK_CASES } from '../corpus/case_law_extended';
import { countPrefectureOrdinances } from '../ordinances/prefecture_ordinances';
import { countMunicipalOrdinances } from '../ordinances/municipal_ordinances';
import { countScholarlyDoctrines } from '../scholarly/scholarly_doctrines';
import { countGdprCcpaRules } from '../comparative_law/gdpr_ccpa';
import { countUsExportControlRules } from '../comparative_law/us_export_control';
import { countSoxRules } from '../comparative_law/sox_internal_control';
import { countAntiBriberyRules } from '../comparative_law/anti_bribery_global';

export interface SaturationSnapshot {
  generated_at: string;
  cases: { jp_landmark: number; jp_extended: number; total: number };
  prefecture_ordinances: { templates: number; prefectures: number; differences: number };
  municipal_ordinances: { total: number; designated_cities: number };
  scholarly: { topics: number; total_positions: number };
  comparative: { gdpr_ccpa: number; us_export: number; sox: number; anti_bribery: number; total: number };
  coverage_pct: number;
  matrix_complete_pct: number;
  /** 飽和度 = (実値/目標値) の幾何平均 */
  saturation_index: number;
  remaining_to_diamond: number;
}

const TARGETS = {
  cases: 200,
  prefecture_templates: 6,
  municipal_total: 10,
  scholarly_topics: 20,
  comparative_total: 15,
};

export function buildSaturationSnapshot(): SaturationSnapshot {
  const gap = analyzeKnowledgeGaps();
  const matrix = buildCoverageMatrix();
  const matrixSummary = summarizeMatrixAsJson(matrix);

  const cases = {
    jp_landmark: LANDMARK_CASES_INDEX.length,
    jp_extended: EXTENDED_LANDMARK_CASES.length,
    total: LANDMARK_CASES_INDEX.length + EXTENDED_LANDMARK_CASES.length,
  };
  const prefOrd = countPrefectureOrdinances();
  const muniOrd = countMunicipalOrdinances();
  const scholarly = countScholarlyDoctrines();
  const gdpr = countGdprCcpaRules();
  const usexp = countUsExportControlRules();
  const sox = countSoxRules();
  const antibri = countAntiBriberyRules();
  const comparativeTotal = gdpr.total + usexp.total + sox.total + antibri.total;

  // 飽和度: 各カテゴリの実値/目標値を 1.0 cap で正規化、幾何平均
  const ratios = [
    Math.min(1, cases.total / TARGETS.cases),
    Math.min(1, prefOrd.templates / TARGETS.prefecture_templates),
    Math.min(1, muniOrd.total / TARGETS.municipal_total),
    Math.min(1, scholarly.total / TARGETS.scholarly_topics),
    Math.min(1, comparativeTotal / TARGETS.comparative_total),
  ];
  const geomean = Math.exp(ratios.reduce((acc, r) => acc + Math.log(Math.max(r, 0.001)), 0) / ratios.length);
  const saturationIndex = Math.round(geomean * 1000) / 10;

  return {
    generated_at: new Date().toISOString(),
    cases,
    prefecture_ordinances: {
      templates: prefOrd.templates,
      prefectures: prefOrd.prefectures,
      differences: prefOrd.specific_differences,
    },
    municipal_ordinances: { total: muniOrd.total, designated_cities: muniOrd.designated_cities },
    scholarly: { topics: scholarly.total, total_positions: scholarly.total_positions },
    comparative: {
      gdpr_ccpa: gdpr.total,
      us_export: usexp.total,
      sox: sox.total,
      anti_bribery: antibri.total,
      total: comparativeTotal,
    },
    coverage_pct: gap.completeness_pct,
    matrix_complete_pct: matrixSummary.completeness_pct,
    saturation_index: saturationIndex,
    remaining_to_diamond:
      gap.diamond_distance.cases_needed +
      gap.diamond_distance.catalog_needed +
      gap.diamond_distance.supplementary_needed,
  };
}

export function renderSaturationDashboard(): string {
  const s = buildSaturationSnapshot();
  const lines: string[] = [];
  lines.push('==============================================================');
  lines.push('  Phase 46-LU-4 / Knowledge Saturation Dashboard');
  lines.push('==============================================================');
  lines.push(`  generated: ${s.generated_at}`);
  lines.push('');
  lines.push('[Saturation Index]');
  lines.push(`  ${renderBar(s.saturation_index, 100, 50)} ${s.saturation_index}%`);
  lines.push('');
  lines.push('[Cases]');
  lines.push(`  Landmark   : ${s.cases.jp_landmark}`);
  lines.push(`  Extended   : ${s.cases.jp_extended}`);
  lines.push(`  Total      : ${s.cases.total} / target 200`);
  lines.push('');
  lines.push('[Ordinances]');
  lines.push(`  Prefecture templates  : ${s.prefecture_ordinances.templates} (47県 ${s.prefecture_ordinances.prefectures}/47 完全)`);
  lines.push(`  Municipal             : ${s.municipal_ordinances.total} (政令市 ${s.municipal_ordinances.designated_cities}/20)`);
  lines.push(`  Prefecture differences: ${s.prefecture_ordinances.differences}`);
  lines.push('');
  lines.push('[Scholarly Doctrines]');
  lines.push(`  Topics : ${s.scholarly.topics} / Positions: ${s.scholarly.total_positions}`);
  lines.push('');
  lines.push('[Comparative Law]');
  lines.push(`  GDPR/CCPA       : ${s.comparative.gdpr_ccpa}`);
  lines.push(`  US Export (ITAR/EAR/OFAC) : ${s.comparative.us_export}`);
  lines.push(`  SOX             : ${s.comparative.sox}`);
  lines.push(`  Anti-Bribery    : ${s.comparative.anti_bribery}`);
  lines.push(`  Total           : ${s.comparative.total}`);
  lines.push('');
  lines.push('[Overall Coverage]');
  lines.push(`  Gap Completeness  : ${s.coverage_pct}%`);
  lines.push(`  Matrix Complete   : ${s.matrix_complete_pct}%`);
  lines.push(`  Remaining items   : ${s.remaining_to_diamond}`);
  lines.push('==============================================================');
  return lines.join('\n');
}

function renderBar(value: number, max: number, width: number): string {
  const filled = Math.max(0, Math.min(width, Math.round((value / max) * width)));
  return '[' + '█'.repeat(filled) + '░'.repeat(width - filled) + ']';
}

export function summarizeSaturationAsJson() {
  return buildSaturationSnapshot();
}
