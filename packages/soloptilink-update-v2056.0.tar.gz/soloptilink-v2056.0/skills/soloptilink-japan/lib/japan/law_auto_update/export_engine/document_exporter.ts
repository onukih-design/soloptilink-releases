/**
 * Phase 46-LU-6 / Document Exporter
 *
 * 判例レポート / 契約書 / コンプラレポート / リスクレポート を
 * PDF / DOCX / XLSX / Markdown 形式で書き出す。
 *
 * 本モジュールは形式変換の抽象レイヤー。実バイナリ生成は
 * anthropic-skills:pdf, anthropic-skills:docx, anthropic-skills:xlsx
 * の Skill レイヤー、または外部ライブラリ (pdfkit/docx/xlsx) で行う。
 */

export type ExportFormat = 'pdf' | 'docx' | 'xlsx' | 'markdown' | 'html' | 'json';

export type ExportKind =
  | 'case_report' // 判例レポート
  | 'contract' // 契約書
  | 'compliance_report' // コンプラスキャンレポート
  | 'risk_report' // 法務リスク評価
  | 'integrity_report' // 判例DB整合性レポート
  | 'amendment_summary' // 改正サマリー
  | 'compliance_certificate' // コンプライアンス証明書
  | 'audit_log_export'; // 監査ログエクスポート

export interface ExportRequest {
  kind: ExportKind;
  format: ExportFormat;
  payload: unknown;
  /** メタデータ */
  metadata?: {
    requester_tenant_id?: string;
    requester_user_id?: string;
    locale?: 'ja' | 'en' | 'zh-CN';
    /** ヘッダーロゴ */
    logo_url?: string;
    /** Watermark */
    watermark?: string;
    /** 守秘指定 */
    confidentiality?: 'public' | 'internal' | 'confidential' | 'strictly_confidential';
  };
}

export interface ExportResult {
  ok: boolean;
  format: ExportFormat;
  kind: ExportKind;
  /** バイナリ生成は別レイヤーなので、ここではテキスト/Markdown表現と生成計画を返す */
  content?: string;
  /** PDF/DOCX/XLSX の場合、外部ライブラリ呼び出し計画 */
  generation_plan?: {
    library: string;
    structure: ExportStructure;
  };
  /** 保存先パス */
  output_path?: string;
  /** 概算サイズ */
  estimated_size_bytes?: number;
  error?: string;
}

export interface ExportStructure {
  document_type: string;
  sections: ExportSection[];
  metadata: Record<string, unknown>;
}

export interface ExportSection {
  heading: string;
  level: 1 | 2 | 3 | 4;
  paragraphs?: string[];
  table?: { headers: string[]; rows: string[][] };
  bullet_list?: string[];
  numbered_list?: string[];
  page_break_after?: boolean;
}

const SOLOPTILINK_HEADER = 'SoloptiLinkAI Legal — Generated Document';
const CONFIDENTIALITY_NOTICE = '※本書は SoloptiLinkAI により自動生成された法令情報です。一般情報であり法的助言ではありません。';

export function exportDocument(req: ExportRequest): ExportResult {
  const structure = buildStructure(req);
  const md = renderMarkdown(structure, req);

  if (req.format === 'markdown') {
    return {
      ok: true,
      format: 'markdown',
      kind: req.kind,
      content: md,
      estimated_size_bytes: md.length,
    };
  }
  if (req.format === 'html') {
    return {
      ok: true,
      format: 'html',
      kind: req.kind,
      content: markdownToHtml(md),
      estimated_size_bytes: md.length * 1.3,
    };
  }
  if (req.format === 'json') {
    const json = JSON.stringify({ structure, metadata: req.metadata }, null, 2);
    return { ok: true, format: 'json', kind: req.kind, content: json, estimated_size_bytes: json.length };
  }

  const library = req.format === 'pdf' ? 'pdfkit/playwright-pdf' : req.format === 'docx' ? 'docx' : 'xlsx';
  return {
    ok: true,
    format: req.format,
    kind: req.kind,
    content: md, // 一旦 Markdown も同梱
    generation_plan: { library, structure },
    estimated_size_bytes: md.length * (req.format === 'pdf' ? 2 : req.format === 'docx' ? 1.8 : 1.5),
  };
}

function buildStructure(req: ExportRequest): ExportStructure {
  const meta = req.metadata ?? {};
  switch (req.kind) {
    case 'case_report':
      return buildCaseReport(req.payload, meta);
    case 'contract':
      return buildContract(req.payload, meta);
    case 'compliance_report':
      return buildComplianceReport(req.payload, meta);
    case 'risk_report':
      return buildRiskReport(req.payload, meta);
    case 'integrity_report':
      return buildIntegrityReport(req.payload, meta);
    case 'amendment_summary':
      return buildAmendmentSummary(req.payload, meta);
    case 'compliance_certificate':
      return buildComplianceCertificate(req.payload, meta);
    case 'audit_log_export':
      return buildAuditLogExport(req.payload, meta);
    default:
      return { document_type: 'unknown', sections: [], metadata: {} };
  }
}

function buildCaseReport(payload: unknown, meta: ExportRequest['metadata']): ExportStructure {
  const cases = Array.isArray(payload) ? payload : [payload];
  const sections: ExportSection[] = [
    { heading: '判例レポート', level: 1, paragraphs: [`生成: ${new Date().toISOString()}`, CONFIDENTIALITY_NOTICE] },
  ];
  for (const c of cases as Array<Record<string, unknown>>) {
    sections.push({
      heading: String(c.short_name ?? c.case_id ?? '無題'),
      level: 2,
      paragraphs: [
        `判決日: ${c.decision_date ?? '-'}`,
        `出典: ${c.citation ?? '-'}`,
        `論点: ${c.summary ?? '-'}`,
        `関連法令: ${Array.isArray(c.related_laws) ? c.related_laws.join(', ') : '-'}`,
      ],
    });
  }
  return { document_type: 'case_report', sections, metadata: meta ?? {} };
}

function buildContract(payload: unknown, meta: ExportRequest['metadata']): ExportStructure {
  const data = payload as { title?: string; rendered?: string };
  return {
    document_type: 'contract',
    sections: [
      { heading: data.title ?? '契約書', level: 1, paragraphs: [data.rendered ?? '(content)'] },
      { heading: '注意事項', level: 3, bullet_list: ['本契約書は雛形です。実際の締結前に弁護士確認推奨。', CONFIDENTIALITY_NOTICE] },
    ],
    metadata: meta ?? {},
  };
}

function buildComplianceReport(payload: unknown, meta: ExportRequest['metadata']): ExportStructure {
  const r = payload as { total_findings?: number; compliance_score?: number; findings?: unknown[] };
  return {
    document_type: 'compliance_report',
    sections: [
      { heading: 'コンプライアンススキャンレポート', level: 1, paragraphs: [`Score: ${r.compliance_score ?? 0}/100`, `検出: ${r.total_findings ?? 0} 件`] },
      { heading: '検出詳細', level: 2, bullet_list: (r.findings ?? []).slice(0, 30).map((f) => JSON.stringify(f).slice(0, 200)) },
    ],
    metadata: meta ?? {},
  };
}

function buildRiskReport(payload: unknown, meta: ExportRequest['metadata']): ExportStructure {
  const r = payload as { overall_score?: number; level?: string; dimensions?: Array<{ dimension: string; score: number }> };
  return {
    document_type: 'risk_report',
    sections: [
      { heading: '法務リスク評価', level: 1, paragraphs: [`総合スコア: ${r.overall_score ?? 0}/100 (${r.level ?? '-'})`] },
      {
        heading: '次元別',
        level: 2,
        table: {
          headers: ['次元', 'スコア'],
          rows: (r.dimensions ?? []).map((d) => [d.dimension, String(d.score)]),
        },
      },
    ],
    metadata: meta ?? {},
  };
}

function buildIntegrityReport(payload: unknown, meta: ExportRequest['metadata']): ExportStructure {
  const r = payload as { total_count?: number; integrity_score?: number };
  return {
    document_type: 'integrity_report',
    sections: [
      { heading: '判例DB 整合性レポート', level: 1, paragraphs: [`総数: ${r.total_count ?? 0}`, `スコア: ${r.integrity_score ?? 0}/100`] },
    ],
    metadata: meta ?? {},
  };
}

function buildAmendmentSummary(payload: unknown, meta: ExportRequest['metadata']): ExportStructure {
  const r = payload as { law_short?: string; effective_date?: string; description?: string };
  return {
    document_type: 'amendment_summary',
    sections: [
      { heading: `改正サマリー: ${r.law_short ?? '-'}`, level: 1, paragraphs: [`施行日: ${r.effective_date ?? '-'}`, r.description ?? '-'] },
    ],
    metadata: meta ?? {},
  };
}

function buildComplianceCertificate(payload: unknown, meta: ExportRequest['metadata']): ExportStructure {
  const r = payload as { tenant_id?: string; period?: string; score?: number };
  return {
    document_type: 'compliance_certificate',
    sections: [
      {
        heading: 'コンプライアンス証明書',
        level: 1,
        paragraphs: [
          `本書は、テナント ${r.tenant_id ?? '-'} が SoloptiLinkAI のコンプライアンススキャンを ${r.period ?? '-'} 期間で実施し、`,
          `総合スコア ${r.score ?? '-'} を達成したことを証明します。`,
          `発行日: ${new Date().toISOString().slice(0, 10)}`,
        ],
      },
    ],
    metadata: meta ?? {},
  };
}

function buildAuditLogExport(payload: unknown, meta: ExportRequest['metadata']): ExportStructure {
  const r = payload as { entries?: Array<{ timestamp: string; user_id: string; action: string; target?: string }> };
  return {
    document_type: 'audit_log_export',
    sections: [
      { heading: '監査ログ', level: 1, paragraphs: [`エントリ数: ${r.entries?.length ?? 0}`] },
      {
        heading: '詳細',
        level: 2,
        table: {
          headers: ['timestamp', 'user_id', 'action', 'target'],
          rows: (r.entries ?? []).map((e) => [e.timestamp, e.user_id, e.action, e.target ?? '']),
        },
      },
    ],
    metadata: meta ?? {},
  };
}

function renderMarkdown(s: ExportStructure, req: ExportRequest): string {
  const lines: string[] = [];
  lines.push(`<!-- ${SOLOPTILINK_HEADER} -->`);
  if (req.metadata?.confidentiality) {
    lines.push(`<!-- Confidentiality: ${req.metadata.confidentiality} -->`);
  }
  if (req.metadata?.watermark) {
    lines.push(`<!-- Watermark: ${req.metadata.watermark} -->`);
  }
  lines.push('');
  for (const sec of s.sections) {
    lines.push(`${'#'.repeat(sec.level)} ${sec.heading}`);
    lines.push('');
    for (const p of sec.paragraphs ?? []) {
      lines.push(p);
      lines.push('');
    }
    if (sec.bullet_list) {
      for (const b of sec.bullet_list) lines.push(`- ${b}`);
      lines.push('');
    }
    if (sec.numbered_list) {
      sec.numbered_list.forEach((b, i) => lines.push(`${i + 1}. ${b}`));
      lines.push('');
    }
    if (sec.table) {
      lines.push('| ' + sec.table.headers.join(' | ') + ' |');
      lines.push('|' + sec.table.headers.map(() => '---').join('|') + '|');
      for (const row of sec.table.rows) lines.push('| ' + row.join(' | ') + ' |');
      lines.push('');
    }
    if (sec.page_break_after) lines.push('---\n\\pagebreak\n');
  }
  lines.push('');
  lines.push(`---\n${CONFIDENTIALITY_NOTICE}`);
  return lines.join('\n');
}

function markdownToHtml(md: string): string {
  // 最小限の markdown → html (実用は marked/markdown-it)
  return md
    .replace(/^### (.+)$/gm, '<h3>$1</h3>')
    .replace(/^## (.+)$/gm, '<h2>$1</h2>')
    .replace(/^# (.+)$/gm, '<h1>$1</h1>')
    .replace(/^- (.+)$/gm, '<li>$1</li>')
    .replace(/\n\n/g, '</p><p>')
    .replace(/^/, '<html><body><p>')
    .replace(/$/, '</p></body></html>');
}

export function countExportKinds(): { total: number; by_format: Record<string, number> } {
  const kinds: ExportKind[] = ['case_report', 'contract', 'compliance_report', 'risk_report', 'integrity_report', 'amendment_summary', 'compliance_certificate', 'audit_log_export'];
  const formats: ExportFormat[] = ['pdf', 'docx', 'xlsx', 'markdown', 'html', 'json'];
  const byFormat: Record<string, number> = {};
  for (const f of formats) byFormat[f] = kinds.length;
  return { total: kinds.length, by_format: byFormat };
}
