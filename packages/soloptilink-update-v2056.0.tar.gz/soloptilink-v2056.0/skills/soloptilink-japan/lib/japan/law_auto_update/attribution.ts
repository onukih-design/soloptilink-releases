/**
 * Phase 46-LU / 出典記載自動付与
 *
 * 法令データを利用する際に必須の出典明記を、データ取得時点で
 * 自動的にレスポンスへ付与する。e-Gov / 官報 / パブコメ で
 * 出典文言と利用条件が異なるため、ソース別に正規化する。
 *
 * 法的根拠:
 *  - e-Gov: 政府標準利用規約 / 公的データ利用規則 v1.0 → 出典明記が必須条件
 *  - 官報: 著作権内閣府 / 引用範囲限定 / 出典は 「官報 第〇号 令和〇年〇月〇日」
 *  - パブコメ: e-Gov に準拠
 */

export interface Attribution {
  /** 表示用テキスト (UI に出すための一文) */
  text: string;
  /** ソース URL (絶対 URL) */
  sourceUrl: string;
  /** ライセンス識別 (政府データの場合 'gov_data_v1', 引用の場合 'fair_use') */
  license: 'gov_data_v1' | 'fair_use' | 'public_domain' | 'unknown';
  /** 商用利用可否 */
  commercialUse: boolean;
  /** 改変可否 */
  modificationAllowed: boolean;
  /** 取得日時 (ISO 8601) */
  retrievedAt: string;
  /**
   * 利用者側の連絡先 (ライブ巡回時に表示が要求される問い合わせ先)。
   * 未設定のときは **null** であり、空文字やダミーで埋めてはならない。
   */
  contact?: string | null;
}

export const EGOV_ATTRIBUTION: Attribution = {
  text: '出典: e-Gov 法令検索 (https://laws.e-gov.go.jp/) — 政府標準利用規約 / 公的データ利用規則 v1.0 準拠',
  sourceUrl: 'https://laws.e-gov.go.jp/',
  license: 'gov_data_v1',
  commercialUse: true,
  modificationAllowed: true,
  retrievedAt: new Date().toISOString(),
  contact: null,
};

// ============================================================================
// e-Gov ライブ巡回の出典連絡先 (EGOV_LIVE_ATTRIBUTION_CONTACT)
// ============================================================================
/**
 * 【埋める空白 — 2026-08-01 実測】
 *   EGOV_LIVE_ATTRIBUTION_CONTACT は承認まわりの定義側 (owner-GO マニフェスト /
 *   承認判定スクリプト / 隔離キー一覧 / L28 検証軸) にしか存在せず、実際に e-Gov を叩く
 *   source_egov_v2.ts と本ファイルからは **1 箇所も参照されていなかった**。
 *   ※本ファイルは承認まわりの実装へは依存しない (env 変数 1 個だけを見る)。
 *     承認側のスクリプト名をここに書くと「下流へ承認配線が焼き込まれた」と
 *     L28 検証軸が正しく検知してしまうため、名指しはしない。
 *   = 「承認の条件として連絡先を要求する」建て付けなのに、承認して連絡先を入れても
 *     実通信の出典表示には一切載らない死配線だった。
 *
 * 【安全側の設計】
 *   ライブ巡回が有効なのに連絡先が未設定なら、**ダミーで埋めずに停止**する。
 *   (空文字や 'unknown' を注入すると「表示している」体裁だけが成立し、利用規約上の
 *    要求を満たさないまま外向き通信を続けることになるため)
 *
 * 【kill-switch】
 *   SOLOPTILINK_EGOV_ATTRIBUTION_ENFORCE=off → 従来動作 (固定文言のまま・停止しない)
 */
export class EgovAttributionContactMissingError extends Error {
  readonly code = 'EGOV_ATTRIBUTION_CONTACT_MISSING';
  constructor(message: string) {
    super(message);
    this.name = 'EgovAttributionContactMissingError';
  }
}

function env(name: string): string | undefined {
  if (typeof process === 'undefined' || !process.env) return undefined;
  const v = process.env[name];
  return typeof v === 'string' && v.trim() !== '' ? v.trim() : undefined;
}

/** ライブ巡回 (外向きの e-Gov 実通信) が有効か */
export function isEgovLiveCrawlEnabled(): boolean {
  const v = env('SOLOPTILINK_EGOV_LIVE_CRAWL');
  return v === 'on' || v === '1' || v === 'true';
}

/** 出典連絡先の実効値。未設定は null (空文字やダミーに丸めない) */
export function egovAttributionContact(): string | null {
  return env('EGOV_LIVE_ATTRIBUTION_CONTACT') ?? null;
}

/**
 * e-Gov 実通信で使う出典情報を組み立てる。
 *
 * - ライブ巡回が有効 かつ 連絡先が未設定 → EgovAttributionContactMissingError を投げて停止する
 *   (呼出側は通信そのものを行わない)。
 * - ライブ巡回が無効 → 連絡先は null のまま。あるものとして偽らない。
 */
export function buildEgovAttribution(): Attribution {
  const enforce = env('SOLOPTILINK_EGOV_ATTRIBUTION_ENFORCE') !== 'off';
  const contact = egovAttributionContact();
  if (enforce && isEgovLiveCrawlEnabled() && !contact) {
    throw new EgovAttributionContactMissingError(
      'e-Gov ライブ巡回が有効ですが、出典表示に載せる連絡先 (EGOV_LIVE_ATTRIBUTION_CONTACT) が未設定です。' +
        '政府標準利用規約が求める出典表示を満たせないため、e-Gov への実通信を行わず停止しました。' +
        '連絡先を設定するか、SOLOPTILINK_EGOV_LIVE_CRAWL を無効にしてください ' +
        '(緊急時の従来動作: SOLOPTILINK_EGOV_ATTRIBUTION_ENFORCE=off)。',
    );
  }
  return {
    ...EGOV_ATTRIBUTION,
    text: contact
      ? `${EGOV_ATTRIBUTION.text} / 本データ利用に関するお問い合わせ: ${contact}`
      : EGOV_ATTRIBUTION.text,
    contact,
    retrievedAt: new Date().toISOString(),
  };
}

export const KANPO_ATTRIBUTION: Attribution = {
  text: '出典: 官報 (独立行政法人国立印刷局) — 引用は著作権法32条の範囲内に限る',
  sourceUrl: 'https://kanpou.npb.go.jp/',
  license: 'fair_use',
  commercialUse: false, // 全文転載は不可。引用なら条件付き可
  modificationAllowed: false,
  retrievedAt: new Date().toISOString(),
};

export const PUBCOMMENT_ATTRIBUTION: Attribution = {
  text: '出典: e-Gov パブリックコメント (https://public-comment.e-gov.go.jp/) — 政府標準利用規約準拠',
  sourceUrl: 'https://public-comment.e-gov.go.jp/',
  license: 'gov_data_v1',
  commercialUse: true,
  modificationAllowed: true,
  retrievedAt: new Date().toISOString(),
};

export const REGULATORY_REFORM_ATTRIBUTION: Attribution = {
  text: '出典: 内閣府 規制改革推進会議 (https://www8.cao.go.jp/kisei-kaikaku/) — 政府標準利用規約準拠',
  sourceUrl: 'https://www8.cao.go.jp/kisei-kaikaku/',
  license: 'gov_data_v1',
  commercialUse: true,
  modificationAllowed: true,
  retrievedAt: new Date().toISOString(),
};

/**
 * レスポンスオブジェクトに `_attribution` フィールドを付与する。
 * 既存フィールドは上書きしない。
 */
export function attachAttribution<T extends object>(
  payload: T,
  attribution: Attribution,
): T & { _attribution: Attribution } {
  if (payload && typeof payload === 'object' && !Array.isArray(payload)) {
    return { ...payload, _attribution: { ...attribution, retrievedAt: new Date().toISOString() } };
  }
  // 配列・プリミティブはラップ
  return { value: payload, _attribution: { ...attribution, retrievedAt: new Date().toISOString() } } as unknown as T & {
    _attribution: Attribution;
  };
}

/**
 * Markdown / 帳票への出典フッタを生成。
 */
export function renderAttributionMarkdown(attributions: Attribution[]): string {
  if (attributions.length === 0) return '';
  const lines = ['---', '## 出典 (Attribution)'];
  const seen = new Set<string>();
  for (const a of attributions) {
    if (seen.has(a.sourceUrl)) continue;
    seen.add(a.sourceUrl);
    lines.push(`- ${a.text}`);
  }
  return lines.join('\n');
}

/**
 * 商用利用前にライセンスを検証する。違反となる用途では false を返し、
 * 呼出側で「出典明記付き引用に縮退」または「処理拒否」を選べる。
 */
export function isCommercialUseAllowed(attribution: Attribution): boolean {
  return attribution.commercialUse;
}

export function isModificationAllowed(attribution: Attribution): boolean {
  return attribution.modificationAllowed;
}
