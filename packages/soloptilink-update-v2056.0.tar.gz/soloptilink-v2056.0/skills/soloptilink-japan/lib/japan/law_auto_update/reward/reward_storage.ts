/**
 * Phase 46-LU-2 / Reward Storage
 *
 * RewardLearner の永続化レイヤー。
 *  - reward_ledger.jsonl (append-only / 全 episode の生記録)
 *  - reward_weights.json (現在の重みスナップショット)
 *
 * テストでは in-memory stub を注入可能。
 */

import type { RewardEpisode, RewardWeights } from './reward_learner';
import { RewardLearner, DEFAULT_WEIGHTS } from './reward_learner';

export interface RewardPersistLayer {
  loadWeights(): Promise<RewardWeights | undefined>;
  saveWeights(w: RewardWeights): Promise<void>;
  appendEpisodes(episodes: RewardEpisode[]): Promise<void>;
  loadAllEpisodes(): Promise<RewardEpisode[]>;
}

export async function createNodeRewardPersistLayer(baseDir: string): Promise<RewardPersistLayer> {
  const { mkdir, readFile, writeFile, appendFile } = await import('node:fs/promises');
  const path = await import('node:path');
  const dir = path.join(baseDir, 'reward_learning');
  await mkdir(dir, { recursive: true });
  const weightsPath = path.join(dir, 'weights.json');
  const ledgerPath = path.join(dir, 'ledger.jsonl');

  return {
    async loadWeights() {
      try {
        const txt = await readFile(weightsPath, 'utf8');
        return JSON.parse(txt) as RewardWeights;
      } catch {
        return undefined;
      }
    },
    async saveWeights(w: RewardWeights) {
      await writeFile(weightsPath, JSON.stringify(w, null, 2), 'utf8');
    },
    async appendEpisodes(episodes: RewardEpisode[]) {
      if (episodes.length === 0) return;
      const body = episodes.map((e) => JSON.stringify(e)).join('\n') + '\n';
      await appendFile(ledgerPath, body, 'utf8');
    },
    async loadAllEpisodes() {
      try {
        const txt = await readFile(ledgerPath, 'utf8');
        return txt
          .split('\n')
          .filter((l) => l.trim().length > 0)
          .map((l) => JSON.parse(l) as RewardEpisode);
      } catch {
        return [];
      }
    },
  };
}

/**
 * 起動時に過去重みを load して RewardLearner を初期化する Factory。
 */
export async function loadOrInitLearner(persist: RewardPersistLayer): Promise<RewardLearner> {
  const w = await persist.loadWeights();
  return new RewardLearner({ initialWeights: w ?? structuredClone(DEFAULT_WEIGHTS) });
}

/**
 * Learner のスナップショットを保存。
 */
export async function snapshotLearner(persist: RewardPersistLayer, learner: RewardLearner): Promise<void> {
  await persist.saveWeights(learner.exportWeights());
  await persist.appendEpisodes(learner.exportEpisodes());
}

/**
 * In-memory 実装 (テスト用)
 */
export function createInMemoryRewardPersistLayer(): RewardPersistLayer {
  let weights: RewardWeights | undefined;
  const episodes: RewardEpisode[] = [];
  return {
    async loadWeights() {
      return weights ? { ...weights, tier_weight: { ...weights.tier_weight } } : undefined;
    },
    async saveWeights(w: RewardWeights) {
      weights = { ...w, tier_weight: { ...w.tier_weight } };
    },
    async appendEpisodes(eps: RewardEpisode[]) {
      episodes.push(...eps);
    },
    async loadAllEpisodes() {
      return [...episodes];
    },
  };
}
