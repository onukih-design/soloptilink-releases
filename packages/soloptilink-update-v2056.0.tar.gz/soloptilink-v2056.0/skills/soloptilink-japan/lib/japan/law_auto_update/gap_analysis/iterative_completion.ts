/**
 * Phase 46-LU-4 / Iterative Completion Engine
 *
 * 「全て完璧に対応」を反復で達成するためのオーケストレータ。
 * 1 サイクル = (gap_analyze → recommend → simulate_add → 飽和度測定) の繰り返し。
 *
 *  - 終了条件: saturation_index >= 95.0 OR cycles >= maxCycles
 *  - 各サイクルの履歴を ledger に append
 *  - ユーザーへのアクションサマリー Markdown 生成
 */

import { analyzeKnowledgeGaps, renderGapReport } from './knowledge_gap_analyzer';
import { planGapClosure, simulateAutoAddition } from './auto_gap_closer';
import { buildSaturationSnapshot, renderSaturationDashboard } from './saturation_dashboard';
import { recommendGaps } from './gap_recommendations';

export interface CompletionCycleRecord {
  cycle_index: number;
  generated_at: string;
  gap_count: number;
  saturation_index: number;
  closure_pending: number;
  closure_added_simulated: number;
  diamond_distance: number;
}

export interface CompletionResult {
  cycles: CompletionCycleRecord[];
  final_saturation_index: number;
  final_gap_count: number;
  stopped_reason: 'target_reached' | 'max_cycles' | 'no_progress';
  summary_markdown: string;
}

const DEFAULT_TARGET_SATURATION = 95.0;
const DEFAULT_MAX_CYCLES = 5;

export function runIterativeCompletion(opts: {
  targetSaturation?: number;
  maxCycles?: number;
} = {}): CompletionResult {
  const target = opts.targetSaturation ?? DEFAULT_TARGET_SATURATION;
  const max = opts.maxCycles ?? DEFAULT_MAX_CYCLES;
  const records: CompletionCycleRecord[] = [];
  let prevSaturation = 0;
  let stoppedReason: CompletionResult['stopped_reason'] = 'max_cycles';

  for (let i = 0; i < max; i++) {
    const gap = analyzeKnowledgeGaps();
    const plan = planGapClosure({ maxRecommendations: 30 });
    const sim = simulateAutoAddition(plan);
    const snapshot = buildSaturationSnapshot();
    records.push({
      cycle_index: i + 1,
      generated_at: snapshot.generated_at,
      gap_count: gap.gap_count,
      saturation_index: snapshot.saturation_index,
      closure_pending: plan.pending_additions.length,
      closure_added_simulated: sim.simulated_added,
      diamond_distance: snapshot.remaining_to_diamond,
    });

    if (snapshot.saturation_index >= target) {
      stoppedReason = 'target_reached';
      break;
    }
    if (i > 0 && Math.abs(snapshot.saturation_index - prevSaturation) < 0.1) {
      stoppedReason = 'no_progress';
      break;
    }
    prevSaturation = snapshot.saturation_index;
  }

  const final = records[records.length - 1];
  const recs = recommendGaps({ maxItems: 10 });

  const md: string[] = [];
  md.push('# Iterative Completion Result');
  md.push('');
  md.push(`- 開始: ${records[0]?.generated_at}`);
  md.push(`- 終了: ${final?.generated_at}`);
  md.push(`- 終了理由: ${stoppedReason}`);
  md.push(`- サイクル数: ${records.length}`);
  md.push(`- 最終飽和度: **${final?.saturation_index}%**`);
  md.push(`- 最終ギャップ数: ${final?.gap_count}`);
  md.push(`- Diamond までの追加項目: ${final?.diamond_distance}`);
  md.push('');
  md.push('## サイクル履歴');
  md.push('| cycle | gap | saturation | pending | sim_added | diamond_dist |');
  md.push('|------:|----:|-----------:|--------:|----------:|-------------:|');
  for (const r of records) {
    md.push(`| ${r.cycle_index} | ${r.gap_count} | ${r.saturation_index} | ${r.closure_pending} | ${r.closure_added_simulated} | ${r.diamond_distance} |`);
  }
  md.push('');
  md.push('## 推奨アクション (Top 10)');
  for (const r of recs) {
    md.push(`- [${r.kind}] **${r.candidate_name}** — priority=${r.priority} (${r.domain})`);
  }

  return {
    cycles: records,
    final_saturation_index: final?.saturation_index ?? 0,
    final_gap_count: final?.gap_count ?? 0,
    stopped_reason: stoppedReason,
    summary_markdown: md.join('\n'),
  };
}

/**
 * フル完璧化レポート: gap report + saturation dashboard + iterative result を統合
 */
export function renderFullCompletenessReport(): string {
  const lines: string[] = [];
  lines.push('# Phase 46-LU-4 / Full Knowledge Completeness Report');
  lines.push('');
  lines.push('## Saturation Dashboard');
  lines.push('```');
  lines.push(renderSaturationDashboard());
  lines.push('```');
  lines.push('');
  lines.push('## Knowledge Gap Analysis');
  lines.push('```');
  lines.push(renderGapReport(analyzeKnowledgeGaps()));
  lines.push('```');
  lines.push('');
  lines.push('## Iterative Completion');
  const r = runIterativeCompletion();
  lines.push(r.summary_markdown);
  return lines.join('\n');
}
