/**
 * Phase 46-LU-7 / Observability Layer
 *
 * SaaS 運用の可観測性 (SLO/SLI/メトリクス/トレーシング) を提供。
 * Datadog/New Relic/CloudWatch との連携を前提とした抽象構造。
 *
 *  - SLI (Service Level Indicator): 計測対象
 *  - SLO (Service Level Objective): 目標値 (例: 99.9% availability)
 *  - Error Budget: 残り誤差予算
 *  - 4 Golden Signals: Latency / Traffic / Errors / Saturation
 *  - 分散トレーシング: TraceID 伝搬
 */

export type SliKind =
  | 'availability'
  | 'latency_p50'
  | 'latency_p95'
  | 'latency_p99'
  | 'error_rate'
  | 'throughput'
  | 'saturation'
  | 'freshness'; // 改正検知の鮮度

export interface Slo {
  slo_id: string;
  service: string;
  sli: SliKind;
  /** 目標値 (% or ms) */
  target: number;
  /** 計測期間 (日) */
  window_days: number;
  /** Error Budget 残量 (%) */
  remaining_budget_pct?: number;
  /** 現在値 */
  current_value?: number;
}

export const DEFAULT_SLOS: Slo[] = [
  { slo_id: 'api.availability', service: 'api', sli: 'availability', target: 99.9, window_days: 30 },
  { slo_id: 'api.latency_p99', service: 'api', sli: 'latency_p99', target: 500, window_days: 7 },
  { slo_id: 'rag.latency_p95', service: 'rag', sli: 'latency_p95', target: 2000, window_days: 7 },
  { slo_id: 'compliance.error_rate', service: 'compliance', sli: 'error_rate', target: 0.5, window_days: 30 },
  { slo_id: 'amendment.freshness', service: 'change_detector', sli: 'freshness', target: 168, window_days: 30 }, // 168h = 1週間
  { slo_id: 'webhook.delivery_success', service: 'webhook', sli: 'availability', target: 99.0, window_days: 7 },
  { slo_id: 'export.latency_p95', service: 'export', sli: 'latency_p95', target: 5000, window_days: 7 },
];

export interface MetricSample {
  metric: string;
  value: number;
  timestamp: string;
  labels: Record<string, string>;
}

const METRIC_STORE: MetricSample[] = [];

export function recordMetric(input: Omit<MetricSample, 'timestamp'>): MetricSample {
  const m: MetricSample = { ...input, timestamp: new Date().toISOString() };
  METRIC_STORE.push(m);
  // 1万件以上はLRU
  if (METRIC_STORE.length > 10_000) METRIC_STORE.splice(0, METRIC_STORE.length - 10_000);
  return m;
}

export function queryMetric(input: { metric: string; window_minutes?: number }): MetricSample[] {
  const since = new Date(Date.now() - (input.window_minutes ?? 60) * 60_000).toISOString();
  return METRIC_STORE.filter((m) => m.metric === input.metric && m.timestamp >= since);
}

/**
 * 4 Golden Signals サマリ
 */
export interface GoldenSignals {
  latency_p50_ms: number;
  latency_p95_ms: number;
  latency_p99_ms: number;
  traffic_rpm: number; // requests per minute
  error_rate_pct: number;
  saturation_pct: number;
}

export function computeGoldenSignals(input: { service: string; window_minutes?: number }): GoldenSignals {
  const win = input.window_minutes ?? 60;
  const lat = queryMetric({ metric: `${input.service}.latency_ms`, window_minutes: win }).map((m) => m.value).sort((a, b) => a - b);
  const errs = queryMetric({ metric: `${input.service}.errors`, window_minutes: win });
  const reqs = queryMetric({ metric: `${input.service}.requests`, window_minutes: win });
  const sat = queryMetric({ metric: `${input.service}.saturation`, window_minutes: win });

  const pct = (arr: number[], p: number) => arr.length ? arr[Math.min(arr.length - 1, Math.floor(arr.length * p))] : 0;
  const totalReq = reqs.reduce((acc, m) => acc + m.value, 0);
  const totalErr = errs.reduce((acc, m) => acc + m.value, 0);
  const latestSat = sat.length ? sat[sat.length - 1].value : 0;

  return {
    latency_p50_ms: pct(lat, 0.5),
    latency_p95_ms: pct(lat, 0.95),
    latency_p99_ms: pct(lat, 0.99),
    traffic_rpm: Math.round((totalReq / win) * 100) / 100,
    error_rate_pct: totalReq > 0 ? Math.round((totalErr / totalReq) * 10000) / 100 : 0,
    saturation_pct: latestSat,
  };
}

/**
 * Error Budget 計算
 *  - SLO 99.9% → 1ヶ月 (30日) で誤差予算 = 30*24*60 * (1 - 0.999) = 43分
 *  - 消費量から残量を算出
 */
export interface ErrorBudgetReport {
  slo_id: string;
  budget_window_minutes: number;
  budget_consumed_minutes: number;
  remaining_pct: number;
  burn_rate: number; // 直近1hの消費速度
  alert_level: 'green' | 'yellow' | 'orange' | 'red';
}

export function computeErrorBudget(slo: Slo): ErrorBudgetReport {
  const totalMinutes = slo.window_days * 24 * 60;
  const allowance = totalMinutes * (1 - slo.target / 100);
  // ダミー計算: actual値は外部メトリクスから (ここではテスト用に静的)
  const consumed = (slo.current_value !== undefined && slo.current_value < slo.target)
    ? allowance * Math.min(2, (slo.target - slo.current_value) / (100 - slo.target))
    : allowance * 0.2;
  const remainingPct = Math.max(0, 100 - (consumed / allowance) * 100);
  const burnRate = consumed > 0 ? consumed / (totalMinutes / 24) : 0;
  const alert: ErrorBudgetReport['alert_level'] =
    remainingPct > 50 ? 'green' : remainingPct > 25 ? 'yellow' : remainingPct > 10 ? 'orange' : 'red';
  return {
    slo_id: slo.slo_id,
    budget_window_minutes: Math.round(allowance),
    budget_consumed_minutes: Math.round(consumed),
    remaining_pct: Math.round(remainingPct * 10) / 10,
    burn_rate: Math.round(burnRate * 100) / 100,
    alert_level: alert,
  };
}

/**
 * 分散トレーシング (W3C TraceContext 互換)
 */
export interface Span {
  trace_id: string;
  span_id: string;
  parent_span_id?: string;
  service: string;
  operation: string;
  start_time: string;
  end_time?: string;
  duration_ms?: number;
  attributes: Record<string, string | number | boolean>;
  status: 'ok' | 'error';
}

const SPAN_STORE: Span[] = [];

export function startSpan(input: { trace_id?: string; parent_span_id?: string; service: string; operation: string; attributes?: Record<string, string | number | boolean> }): Span {
  const traceId = input.trace_id ?? generateTraceId();
  const spanId = generateSpanId();
  const span: Span = {
    trace_id: traceId,
    span_id: spanId,
    parent_span_id: input.parent_span_id,
    service: input.service,
    operation: input.operation,
    start_time: new Date().toISOString(),
    attributes: input.attributes ?? {},
    status: 'ok',
  };
  SPAN_STORE.push(span);
  return span;
}

export function endSpan(span: Span, status: 'ok' | 'error' = 'ok'): Span {
  span.end_time = new Date().toISOString();
  span.duration_ms = new Date(span.end_time).getTime() - new Date(span.start_time).getTime();
  span.status = status;
  return span;
}

function generateTraceId(): string {
  return [...crypto.getRandomValues(new Uint8Array(16))]
    .map((b) => b.toString(16).padStart(2, '0')).join('');
}

function generateSpanId(): string {
  return [...crypto.getRandomValues(new Uint8Array(8))]
    .map((b) => b.toString(16).padStart(2, '0')).join('');
}

/**
 * SLO ダッシュボード集計
 */
export function summarizeSlos(): Array<{ slo: Slo; budget: ErrorBudgetReport }> {
  return DEFAULT_SLOS.map((slo) => ({ slo, budget: computeErrorBudget(slo) }));
}

export function countObservabilityArtifacts(): {
  slos: number;
  metrics: number;
  spans: number;
  signals: string[];
} {
  return {
    slos: DEFAULT_SLOS.length,
    metrics: METRIC_STORE.length,
    spans: SPAN_STORE.length,
    signals: ['Latency', 'Traffic', 'Errors', 'Saturation'],
  };
}

export function _resetObservabilityForTests(): void {
  METRIC_STORE.length = 0;
  SPAN_STORE.length = 0;
}
