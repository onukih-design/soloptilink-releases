/**
 * Phase 46-LU-6 / Plan Quota & Rate Limiting
 *
 * プラン別のクォータ消費と Token Bucket レート制限。
 *
 *  - 月次クォータ: rag_queries / compliance_scans / contracts / risk / exports
 *  - API レート: req/min (Token Bucket per API key)
 *  - 残量・リセット日・アップグレード推奨
 */

import type { PlanTier } from '../subscription/plans_catalog';
import { getPlanByTier } from '../subscription/plans_catalog';

export type QuotaField =
  | 'rag_queries_per_month'
  | 'compliance_scans_per_month'
  | 'contracts_per_month'
  | 'risk_assessments_per_month'
  | 'exports_per_month';

export interface QuotaUsage {
  tenant_id: string;
  plan_tier: PlanTier;
  period_start: string; // YYYY-MM-01
  /** 各フィールドの使用量 */
  used: Partial<Record<QuotaField, number>>;
}

export interface QuotaCheckResult {
  allowed: boolean;
  remaining: number;
  limit: number;
  used_pct: number;
  reset_at: string; // ISO
  upgrade_suggested?: boolean;
  reason?: string;
}

/**
 * In-memory ストア (本番は Redis or DB)
 */
const QUOTA_STORE = new Map<string, QuotaUsage>();

function getCurrentPeriodStart(): string {
  const now = new Date();
  return `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-01`;
}

function getNextPeriodStart(): string {
  const now = new Date();
  const next = new Date(now.getFullYear(), now.getMonth() + 1, 1);
  return next.toISOString();
}

export function checkQuota(input: {
  tenant_id: string;
  plan_tier: PlanTier;
  field: QuotaField;
  delta?: number;
}): QuotaCheckResult {
  const plan = getPlanByTier(input.plan_tier);
  if (!plan) {
    return { allowed: false, remaining: 0, limit: 0, used_pct: 100, reset_at: getNextPeriodStart(), reason: 'invalid plan' };
  }
  const limit = plan.features[input.field] as number;
  const period = getCurrentPeriodStart();
  const key = `${input.tenant_id}:${period}`;

  let usage = QUOTA_STORE.get(key);
  if (!usage) {
    usage = { tenant_id: input.tenant_id, plan_tier: input.plan_tier, period_start: period, used: {} };
    QUOTA_STORE.set(key, usage);
  }

  const used = usage.used[input.field] ?? 0;
  const delta = input.delta ?? 1;
  const remaining = limit - used;
  const usedPctAfter = Math.round(((used + delta) / limit) * 100);
  const upgradeTrigger = plan.upgrade_triggers.rag_usage_pct;

  if (remaining < delta) {
    return {
      allowed: false,
      remaining: Math.max(0, remaining),
      limit,
      used_pct: 100,
      reset_at: getNextPeriodStart(),
      upgrade_suggested: true,
      reason: `${input.field} 上限超過: ${used}/${limit} (プラン ${input.plan_tier})`,
    };
  }

  return {
    allowed: true,
    remaining: remaining - delta,
    limit,
    used_pct: usedPctAfter,
    reset_at: getNextPeriodStart(),
    upgrade_suggested: usedPctAfter >= upgradeTrigger,
  };
}

/**
 * 実際にクォータを消費する (許可後に呼ぶ)
 */
export function consumeQuota(input: {
  tenant_id: string;
  plan_tier: PlanTier;
  field: QuotaField;
  delta?: number;
}): boolean {
  const check = checkQuota(input);
  if (!check.allowed) return false;
  const period = getCurrentPeriodStart();
  const key = `${input.tenant_id}:${period}`;
  const usage = QUOTA_STORE.get(key)!;
  usage.used[input.field] = (usage.used[input.field] ?? 0) + (input.delta ?? 1);
  return true;
}

export function getTenantUsage(tenant_id: string): QuotaUsage | undefined {
  const period = getCurrentPeriodStart();
  return QUOTA_STORE.get(`${tenant_id}:${period}`);
}

/**
 * Token Bucket per API key (req/min)
 */
interface TokenBucket {
  tokens: number;
  capacity: number;
  refill_per_sec: number;
  last_refill_ms: number;
}

const RATE_BUCKETS = new Map<string, TokenBucket>();

export function checkRateLimit(input: {
  api_key: string;
  plan_tier: PlanTier;
}): { allowed: boolean; remaining: number; retry_after_ms?: number } {
  const plan = getPlanByTier(input.plan_tier);
  if (!plan) return { allowed: false, remaining: 0 };
  const capacity = plan.features.api_rate_per_min;
  const refillPerSec = capacity / 60;

  let bucket = RATE_BUCKETS.get(input.api_key);
  if (!bucket) {
    bucket = { tokens: capacity, capacity, refill_per_sec: refillPerSec, last_refill_ms: Date.now() };
    RATE_BUCKETS.set(input.api_key, bucket);
  }
  // refill
  const now = Date.now();
  const elapsedSec = (now - bucket.last_refill_ms) / 1000;
  bucket.tokens = Math.min(bucket.capacity, bucket.tokens + elapsedSec * bucket.refill_per_sec);
  bucket.last_refill_ms = now;

  if (bucket.tokens < 1) {
    const waitMs = Math.ceil((1 - bucket.tokens) / bucket.refill_per_sec * 1000);
    return { allowed: false, remaining: 0, retry_after_ms: waitMs };
  }
  bucket.tokens -= 1;
  return { allowed: true, remaining: Math.floor(bucket.tokens) };
}

/**
 * 全テナントのクォータ状況サマリ
 */
export function summarizeAllUsage(): {
  total_tenants: number;
  by_plan: Record<string, number>;
  near_limit_count: number;
} {
  const byPlan: Record<string, number> = {};
  let nearLimit = 0;
  for (const u of QUOTA_STORE.values()) {
    byPlan[u.plan_tier] = (byPlan[u.plan_tier] ?? 0) + 1;
    const plan = getPlanByTier(u.plan_tier);
    if (!plan) continue;
    for (const [field, used] of Object.entries(u.used)) {
      const limit = plan.features[field as QuotaField] as number;
      if (limit && used / limit >= 0.8) {
        nearLimit++;
        break;
      }
    }
  }
  return { total_tenants: QUOTA_STORE.size, by_plan: byPlan, near_limit_count: nearLimit };
}

/** テスト用: ストアリセット */
export function _resetQuotaStoreForTests(): void {
  QUOTA_STORE.clear();
  RATE_BUCKETS.clear();
}
