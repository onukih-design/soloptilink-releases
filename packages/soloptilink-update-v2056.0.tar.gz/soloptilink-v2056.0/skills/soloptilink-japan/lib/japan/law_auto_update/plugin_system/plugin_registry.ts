/**
 * Phase 46-LU-6 / Plugin Registry
 *
 * サードパーティが Phase 46-LU システムを拡張できる Plugin 機構。
 *  - カスタムコンプライアンスルール
 *  - カスタム契約書テンプレ
 *  - カスタム判例ソース (D1-Law / Westlaw Japan / TKC との連携想定)
 *  - カスタム RAG ソース (社内規程・通達)
 *  - カスタム Risk Heuristics
 *  - 各種 Webhook 拡張
 *
 * セキュリティ:
 *  - プラグインは sandbox 化 (eval/Function禁止)
 *  - manifest.json で権限明示
 *  - 署名検証 (sha256 + 公開鍵)
 */

export type PluginKind =
  | 'compliance_rule'
  | 'contract_template'
  | 'case_source'
  | 'rag_source'
  | 'risk_heuristic'
  | 'webhook_extension'
  | 'export_format'
  | 'language_pack';

export interface PluginManifest {
  plugin_id: string;
  name: string;
  version: string;
  vendor: string;
  description: string;
  kind: PluginKind;
  /** 必要権限 */
  permissions: PluginPermission[];
  /** 必須最低エンジンバージョン (Phase 46-LU-X) */
  min_engine_version: string;
  /** プラグインエントリ (JS関数名 or URL) */
  entry: string;
  /** 公開鍵 */
  signing_public_key?: string;
  /** sha256 ハッシュ */
  bundle_sha256: string;
  /** 作成日時 */
  registered_at: string;
}

export type PluginPermission =
  | 'read:cases'
  | 'read:laws'
  | 'read:tenants'
  | 'write:compliance_rules'
  | 'write:contracts'
  | 'write:cases'
  | 'invoke:rag'
  | 'invoke:risk'
  | 'invoke:webhook'
  | 'invoke:advisor';

export interface PluginInstance {
  manifest: PluginManifest;
  /** 状態 */
  status: 'installed' | 'enabled' | 'disabled' | 'revoked';
  /** インストール先テナント */
  installed_for_tenant: string;
  /** 直近の実行統計 */
  stats: { invocations: number; errors: number; last_invoked_at?: string };
}

const PLUGIN_STORE = new Map<string, PluginInstance>();

export function registerPlugin(input: {
  manifest: PluginManifest;
  installed_for_tenant: string;
}): { ok: true; instance: PluginInstance } | { ok: false; error: string } {
  if (PLUGIN_STORE.has(input.manifest.plugin_id)) {
    return { ok: false, error: `plugin_id "${input.manifest.plugin_id}" already registered` };
  }
  // 簡易バリデーション
  if (!input.manifest.bundle_sha256 || input.manifest.bundle_sha256.length !== 64) {
    return { ok: false, error: 'invalid bundle_sha256 (must be 64-char hex)' };
  }
  if (!/^\d+\.\d+\.\d+$/.test(input.manifest.version)) {
    return { ok: false, error: 'invalid version (semver required)' };
  }
  const instance: PluginInstance = {
    manifest: input.manifest,
    status: 'installed',
    installed_for_tenant: input.installed_for_tenant,
    stats: { invocations: 0, errors: 0 },
  };
  PLUGIN_STORE.set(input.manifest.plugin_id, instance);
  return { ok: true, instance };
}

export function enablePlugin(plugin_id: string): boolean {
  const p = PLUGIN_STORE.get(plugin_id);
  if (!p) return false;
  if (p.status === 'revoked') return false;
  p.status = 'enabled';
  return true;
}

export function disablePlugin(plugin_id: string): boolean {
  const p = PLUGIN_STORE.get(plugin_id);
  if (!p) return false;
  p.status = 'disabled';
  return true;
}

export function revokePlugin(plugin_id: string, reason: string): boolean {
  const p = PLUGIN_STORE.get(plugin_id);
  if (!p) return false;
  p.status = 'revoked';
  return true;
}

export function listPlugins(input?: { tenant_id?: string; kind?: PluginKind; status?: PluginInstance['status'] }): PluginInstance[] {
  let results = [...PLUGIN_STORE.values()];
  if (input?.tenant_id) results = results.filter((p) => p.installed_for_tenant === input.tenant_id);
  if (input?.kind) results = results.filter((p) => p.manifest.kind === input.kind);
  if (input?.status) results = results.filter((p) => p.status === input.status);
  return results;
}

export function getPlugin(plugin_id: string): PluginInstance | undefined {
  return PLUGIN_STORE.get(plugin_id);
}

export function recordInvocation(plugin_id: string, success: boolean): boolean {
  const p = PLUGIN_STORE.get(plugin_id);
  if (!p) return false;
  p.stats.invocations++;
  if (!success) p.stats.errors++;
  p.stats.last_invoked_at = new Date().toISOString();
  return true;
}

/**
 * 権限チェック
 */
export function hasPermission(plugin_id: string, permission: PluginPermission): boolean {
  const p = PLUGIN_STORE.get(plugin_id);
  if (!p) return false;
  if (p.status !== 'enabled') return false;
  return p.manifest.permissions.includes(permission);
}

/**
 * 内蔵公式プラグイン (例: D1-Law, Westlaw Japan, TKC との連携)
 * これらは内蔵としてリストアップされ、Enterprise/LegalFirm プランで有効化可能。
 */
export const OFFICIAL_PLUGINS_CATALOG: PluginManifest[] = [
  {
    plugin_id: 'official.d1-law',
    name: 'D1-Law 判例DB連携',
    version: '1.0.0',
    vendor: 'SoloptiLinkAI (公式)',
    description: '第一法規 D1-Law (有料DB) との判例検索連携',
    kind: 'case_source',
    permissions: ['read:cases', 'write:cases', 'invoke:rag'],
    min_engine_version: '46.5.0',
    entry: 'plugins/d1-law/adapter.js',
    bundle_sha256: 'a'.repeat(64),
    registered_at: new Date().toISOString(),
  },
  {
    plugin_id: 'official.westlaw-japan',
    name: 'Westlaw Japan 連携',
    version: '1.0.0',
    vendor: 'SoloptiLinkAI (公式)',
    description: 'トムソン・ロイター Westlaw Japan との連携',
    kind: 'case_source',
    permissions: ['read:cases', 'invoke:rag'],
    min_engine_version: '46.5.0',
    entry: 'plugins/westlaw-japan/adapter.js',
    bundle_sha256: 'b'.repeat(64),
    registered_at: new Date().toISOString(),
  },
  {
    plugin_id: 'official.tkc-lex',
    name: 'TKC Lex/DB 連携',
    version: '1.0.0',
    vendor: 'SoloptiLinkAI (公式)',
    description: 'TKC Lex/DB (税務判例DB) との連携',
    kind: 'case_source',
    permissions: ['read:cases'],
    min_engine_version: '46.5.0',
    entry: 'plugins/tkc-lex/adapter.js',
    bundle_sha256: 'c'.repeat(64),
    registered_at: new Date().toISOString(),
  },
  {
    plugin_id: 'official.custom-rules-medical',
    name: '医療業界カスタムコンプラルール',
    version: '1.0.0',
    vendor: 'SoloptiLinkAI (公式)',
    description: '3省2GL / 薬機法 / 個情法医療例外 のカスタムルール',
    kind: 'compliance_rule',
    permissions: ['write:compliance_rules'],
    min_engine_version: '46.5.0',
    entry: 'plugins/medical-rules/rules.js',
    bundle_sha256: 'd'.repeat(64),
    registered_at: new Date().toISOString(),
  },
  {
    plugin_id: 'official.financial-rules',
    name: '金融業界カスタムコンプラルール',
    version: '1.0.0',
    vendor: 'SoloptiLinkAI (公式)',
    description: 'FISC安全対策基準 / 金商法 / 銀行法のカスタムルール',
    kind: 'compliance_rule',
    permissions: ['write:compliance_rules'],
    min_engine_version: '46.5.0',
    entry: 'plugins/financial-rules/rules.js',
    bundle_sha256: 'e'.repeat(64),
    registered_at: new Date().toISOString(),
  },
];

export function listOfficialPlugins(): PluginManifest[] {
  return [...OFFICIAL_PLUGINS_CATALOG];
}

export function countPlugins(): {
  installed: number;
  enabled: number;
  disabled: number;
  revoked: number;
  official_available: number;
} {
  const counts = { installed: 0, enabled: 0, disabled: 0, revoked: 0 };
  for (const p of PLUGIN_STORE.values()) counts[p.status]++;
  return { ...counts, official_available: OFFICIAL_PLUGINS_CATALOG.length };
}

export function _resetPluginsForTests(): void {
  PLUGIN_STORE.clear();
}
