/**
 * Phase 46-LU-2 / Vector Indexer (TF-IDF / BM25 軽量実装)
 *
 * 法令本文を外部依存なしで類似検索可能にするための軽量埋め込み。
 * 大規模 embedding (OpenAI/Cohere) を使わず、TF-IDF と BM25 を
 * 自前実装する (オフライン環境・閉域網対応の要請から)。
 *
 * 用途:
 *  - 「この条文に近い別法令の条文は?」の検索
 *  - 改正影響波及の関連法令ピックアップ
 *  - 法令QAエンジンの検索バックエンド
 *
 * 設計:
 *  - bigram + 単語境界 N-gram 抽出 (日本語/英語混在対応)
 *  - IDF: log((N+1) / (df+1)) + 1
 *  - BM25: k1=1.5, b=0.75
 *  - スコア上位 K 件返却
 *  - 索引は in-memory Map。永続化は JSONL で実装可能。
 */

export interface LawDocument {
  law_id: string;
  short_name: string;
  /** 法令本文を結合した検索用テキスト */
  text: string;
  /** 元の章節番号 (任意) */
  article_num?: string;
}

interface DocStats {
  law_id: string;
  short_name: string;
  article_num?: string;
  termFreq: Map<string, number>;
  length: number;
}

export interface VectorIndexerOptions {
  /** N-gram 長 (default 2) */
  ngram?: number;
  /** BM25 k1 (default 1.5) */
  k1?: number;
  /** BM25 b (default 0.75) */
  b?: number;
}

export class VectorIndexer {
  private readonly docs: DocStats[] = [];
  private readonly docFreq = new Map<string, number>();
  private avgDocLen = 0;
  private readonly ngram: number;
  private readonly k1: number;
  private readonly b: number;

  constructor(opts: VectorIndexerOptions = {}) {
    this.ngram = opts.ngram ?? 2;
    this.k1 = opts.k1 ?? 1.5;
    this.b = opts.b ?? 0.75;
  }

  /** 文書を追加 (バッチ後に finalizeIdf を呼ぶ) */
  addDocument(doc: LawDocument): void {
    const terms = this.tokenize(doc.text);
    const tf = new Map<string, number>();
    for (const t of terms) tf.set(t, (tf.get(t) ?? 0) + 1);
    const stats: DocStats = {
      law_id: doc.law_id,
      short_name: doc.short_name,
      article_num: doc.article_num,
      termFreq: tf,
      length: terms.length,
    };
    this.docs.push(stats);
    for (const term of tf.keys()) {
      this.docFreq.set(term, (this.docFreq.get(term) ?? 0) + 1);
    }
  }

  /** インデックス確定 — addDocument が終わったら呼ぶ */
  finalize(): void {
    if (this.docs.length === 0) return;
    this.avgDocLen = this.docs.reduce((acc, d) => acc + d.length, 0) / this.docs.length;
  }

  /** トップ K の類似文書を返す */
  search(query: string, k = 10): Array<{ law_id: string; short_name: string; article_num?: string; score: number }> {
    if (this.docs.length === 0) return [];
    const qTerms = this.tokenize(query);
    if (qTerms.length === 0) return [];

    const N = this.docs.length;
    const scores: Array<{ law_id: string; short_name: string; article_num?: string; score: number }> = [];

    for (const d of this.docs) {
      let s = 0;
      for (const t of qTerms) {
        const tf = d.termFreq.get(t) ?? 0;
        if (tf === 0) continue;
        const df = this.docFreq.get(t) ?? 0;
        const idf = Math.log((N - df + 0.5) / (df + 0.5) + 1);
        const num = tf * (this.k1 + 1);
        const den = tf + this.k1 * (1 - this.b + this.b * (d.length / this.avgDocLen));
        s += idf * (num / den);
      }
      if (s > 0) {
        scores.push({ law_id: d.law_id, short_name: d.short_name, article_num: d.article_num, score: s });
      }
    }
    scores.sort((a, b) => b.score - a.score);
    return scores.slice(0, k);
  }

  /** インデックス統計 */
  stats(): { documents: number; vocabulary: number; avg_doc_len: number } {
    return {
      documents: this.docs.length,
      vocabulary: this.docFreq.size,
      avg_doc_len: Math.round(this.avgDocLen * 10) / 10,
    };
  }

  /** N-gram + 単語抽出 トークナイザ */
  private tokenize(text: string): string[] {
    if (!text) return [];
    const normalized = text
      .replace(/[\s　]+/g, ' ')
      .replace(/[。、・「」（）()『』【】《》〈〉]/g, ' ')
      .toLowerCase();

    // 英数字単語
    const wordTokens = normalized.match(/[a-z0-9]{2,}/g) ?? [];

    // 日本語 N-gram (連続する非空白2文字)
    const grams: string[] = [];
    const stripped = normalized.replace(/[^぀-ヿ一-鿿]/g, '');
    for (let i = 0; i <= stripped.length - this.ngram; i++) {
      grams.push(stripped.substring(i, i + this.ngram));
    }
    return [...wordTokens, ...grams];
  }
}

/**
 * 既存 EXTENDED_LAW_CATALOG の short_name + officialName を入力に
 * 軽量検索インデックスを構築するユーティリティ。
 */
export function buildIndexFromCatalog(input: {
  entries: Array<{ law_id: string; short_name: string; official_name: string }>;
  opts?: VectorIndexerOptions;
}): VectorIndexer {
  const idx = new VectorIndexer(input.opts);
  for (const e of input.entries) {
    idx.addDocument({
      law_id: e.law_id,
      short_name: e.short_name,
      text: `${e.short_name} ${e.official_name}`,
    });
  }
  idx.finalize();
  return idx;
}
