/**
 * Phase 46-LU-3 / 国際法・条約
 *
 * 日本企業が遵守すべき国際条約 20 件 + メガEPA 4 件。
 *  - 通商: WTO/TRIPS/GATT/CPTPP/RCEP/日EU-EPA/日米貿易協定
 *  - 投資: ICSID/MIGA + 各種BIT
 *  - 知財: パリ条約/PCT/マドプロ/ハーグ協定/TRIPS
 *  - 私法: CISG (ウィーン売買条約)/ハーグ国際私法/NY条約 (仲裁)
 *  - 人権: ICCPR/ICESCR + ILO 中核8条約
 *  - 環境: パリ協定/モントリオール議定書/バーゼル条約
 *  - 租税: OECDモデル租税条約 + 主要租税条約
 */

export type TreatyKind =
  | 'trade'
  | 'investment'
  | 'ip'
  | 'private_law'
  | 'human_rights'
  | 'environment'
  | 'tax'
  | 'arbitration';

export interface TreatyEntry {
  treaty_id: string;
  short_name: string;
  official_name: string;
  kind: TreatyKind;
  parties_count: number;
  effective_date_jp: string;
  summary: string;
  domestic_implementation_law?: string;
}

export const INTERNATIONAL_TREATIES: TreatyEntry[] = [
  // ============ 通商 ============
  {
    treaty_id: 'wto_1994',
    short_name: 'WTO',
    official_name: 'マラケシュ協定 (世界貿易機関を設立する協定)',
    kind: 'trade',
    parties_count: 164,
    effective_date_jp: '1995-01-01',
    summary: 'GATT/GATS/TRIPSを統合する世界貿易機関の設立条約。MFN+内国民待遇+紛争解決手続。',
    domestic_implementation_law: '関税定率法 等',
  },
  {
    treaty_id: 'cptpp',
    short_name: 'CPTPP',
    official_name: '環太平洋パートナーシップに関する包括的及び先進的な協定',
    kind: 'trade',
    parties_count: 12,
    effective_date_jp: '2018-12-30',
    summary: '11ヶ国+英国 (R5年加入)。関税削減+投資保護+知財+電子商取引+労働環境章。',
  },
  {
    treaty_id: 'rcep',
    short_name: 'RCEP',
    official_name: '地域的な包括的経済連携協定',
    kind: 'trade',
    parties_count: 15,
    effective_date_jp: '2022-01-01',
    summary: 'ASEAN10+日中韓豪NZ。世界最大の貿易協定 (世界GDPの3割)。',
  },
  {
    treaty_id: 'jp_eu_epa',
    short_name: '日EU-EPA',
    official_name: '日本国と欧州連合との間の経済連携協定',
    kind: 'trade',
    parties_count: 2,
    effective_date_jp: '2019-02-01',
    summary: '農林水産品+ワイン関税+地理的表示+データ越境移転 (GDPR十分性認定と連動)。',
  },
  {
    treaty_id: 'jp_us_trade',
    short_name: '日米貿易協定',
    official_name: '日本国とアメリカ合衆国との間の貿易協定',
    kind: 'trade',
    parties_count: 2,
    effective_date_jp: '2020-01-01',
    summary: '農産品+工業品 (自動車関税は別途協議)。日米デジタル貿易協定とセット。',
  },
  {
    treaty_id: 'gatt_1947',
    short_name: 'GATT 1947',
    official_name: '関税及び貿易に関する一般協定',
    kind: 'trade',
    parties_count: 164,
    effective_date_jp: '1955-09-10',
    summary: 'WTOの基礎。最恵国待遇 (1条)+内国民待遇 (3条)+数量制限禁止 (11条)+セーフガード (19条)。',
  },

  // ============ 投資 ============
  {
    treaty_id: 'icsid',
    short_name: 'ICSID条約',
    official_name: '国家と他の国家の国民との間の投資紛争の解決に関する条約',
    kind: 'investment',
    parties_count: 165,
    effective_date_jp: '1967-09-16',
    summary: 'ISDS (投資家対国家紛争解決) の主要フォーラム。世界銀行傘下。',
  },
  {
    treaty_id: 'miga',
    short_name: 'MIGA',
    official_name: '多数国間投資保証機関を設立する条約',
    kind: 'investment',
    parties_count: 182,
    effective_date_jp: '1988-04-12',
    summary: '海外投資の非商業的リスク (戦争/収用/外貨送金制限) を保証。',
  },

  // ============ 知財 ============
  {
    treaty_id: 'paris_convention',
    short_name: 'パリ条約',
    official_name: '工業所有権の保護に関するパリ条約',
    kind: 'ip',
    parties_count: 179,
    effective_date_jp: '1899-07-15',
    summary: '優先権 (12ヶ月/6ヶ月)+内国民待遇+特許独立性 (4条) の根本条約。',
    domestic_implementation_law: '特許法第43条 (パリ優先権)',
  },
  {
    treaty_id: 'pct',
    short_name: 'PCT',
    official_name: '特許協力条約',
    kind: 'ip',
    parties_count: 157,
    effective_date_jp: '1978-10-01',
    summary: '国際出願 1 本で複数国 (指定国) に対する出願日確保。国際調査+国際予備審査+各国国内移行 (30/31ヶ月)。',
    domestic_implementation_law: '特許協力条約に基づく国際出願等に関する法律',
  },
  {
    treaty_id: 'madrid_protocol',
    short_name: 'マドプロ',
    official_name: '標章の国際登録に関するマドリッド協定議定書',
    kind: 'ip',
    parties_count: 113,
    effective_date_jp: '2000-03-14',
    summary: '商標国際登録の議定書。1 出願で複数国 (締約国) を指定。',
  },
  {
    treaty_id: 'hague_design',
    short_name: 'ハーグ協定',
    official_name: '意匠の国際登録に関するハーグ協定',
    kind: 'ip',
    parties_count: 79,
    effective_date_jp: '2015-05-13',
    summary: '意匠国際登録。1 出願で複数国 (締約国) を指定。',
  },
  {
    treaty_id: 'trips',
    short_name: 'TRIPS',
    official_name: '知的所有権の貿易関連の側面に関する協定',
    kind: 'ip',
    parties_count: 164,
    effective_date_jp: '1995-01-01',
    summary: '特許 20 年+著作権 50/70 年+商標 7 年+意匠 10 年 等の最低基準。WTO 紛争解決の対象。',
  },

  // ============ 私法 ============
  {
    treaty_id: 'cisg',
    short_name: 'CISG',
    official_name: '国際物品売買契約に関する国際連合条約 (ウィーン売買条約)',
    kind: 'private_law',
    parties_count: 97,
    effective_date_jp: '2009-08-01',
    summary: '国際物品売買のデフォルト準拠法。日本では当事者の選択で適用除外可能 (Art.6)。',
  },

  // ============ 仲裁 ============
  {
    treaty_id: 'ny_convention',
    short_name: 'NY条約',
    official_name: '外国仲裁判断の承認及び執行に関する条約 (ニューヨーク条約)',
    kind: 'arbitration',
    parties_count: 172,
    effective_date_jp: '1961-09-18',
    summary: '外国仲裁判断の承認執行の基礎条約。執行拒否事由は5条に限定列挙。',
    domestic_implementation_law: '仲裁法',
  },

  // ============ 人権 ============
  {
    treaty_id: 'iccpr',
    short_name: 'ICCPR (B規約)',
    official_name: '市民的及び政治的権利に関する国際規約',
    kind: 'human_rights',
    parties_count: 173,
    effective_date_jp: '1979-09-21',
    summary: '人権の国際基準。死刑制度+表現の自由+結社の自由等を規定。第一選択議定書は未批准。',
  },
  {
    treaty_id: 'icescr',
    short_name: 'ICESCR (A規約)',
    official_name: '経済的、社会的及び文化的権利に関する国際規約',
    kind: 'human_rights',
    parties_count: 171,
    effective_date_jp: '1979-09-21',
    summary: '社会権の国際基準。労働権+社会保障+教育権 等。',
  },
  {
    treaty_id: 'ilo_core',
    short_name: 'ILO中核8条約',
    official_name: '結社の自由+強制労働禁止+児童労働撤廃+差別撤廃 関連8条約',
    kind: 'human_rights',
    parties_count: 187,
    effective_date_jp: '段階批准',
    summary: '結社(87/98) + 強制労働(29/105) + 差別(100/111) + 児童労働(138/182)。日本は105号と111号未批准。',
  },

  // ============ 環境 ============
  {
    treaty_id: 'paris_agreement',
    short_name: 'パリ協定',
    official_name: '気候変動に関する国際連合枠組条約の京都議定書に代わる新たな国際的な枠組み',
    kind: 'environment',
    parties_count: 195,
    effective_date_jp: '2016-11-08',
    summary: '世界平均気温上昇 2℃ (努力 1.5℃) 以内。各国 NDC 提出+5年毎見直し。',
    domestic_implementation_law: '地球温暖化対策推進法',
  },
  {
    treaty_id: 'montreal',
    short_name: 'モントリオール議定書',
    official_name: 'オゾン層を破壊する物質に関するモントリオール議定書',
    kind: 'environment',
    parties_count: 198,
    effective_date_jp: '1989-01-01',
    summary: 'CFC/HCFC/HFC等のオゾン層破壊物質の段階削減。Kigali改正で HFC 削減追加。',
    domestic_implementation_law: 'オゾン層保護法 + フロン排出抑制法',
  },
  {
    treaty_id: 'basel',
    short_name: 'バーゼル条約',
    official_name: '有害廃棄物の国境を越える移動及びその処分の規制に関するバーゼル条約',
    kind: 'environment',
    parties_count: 191,
    effective_date_jp: '1993-12-17',
    summary: '有害廃棄物の越境移動規制+事前通告+同意手続。R3年改正でプラスチック廃棄物追加。',
  },

  // ============ 租税 ============
  {
    treaty_id: 'oecd_model_treaty',
    short_name: 'OECDモデル租税条約',
    official_name: 'OECDモデル租税条約 (2017年版)',
    kind: 'tax',
    parties_count: 0,
    effective_date_jp: 'モデル (拘束力なし)',
    summary: '二重課税排除+情報交換+移転価格 (Art.9)+BEPS (PEルール改正)。',
  },
];

/**
 * メガEPA は別途取り扱い (Trade + Investment 横断)
 */
export const MEGA_EPA_TREATIES: TreatyEntry[] = INTERNATIONAL_TREATIES.filter(
  (t) => ['cptpp', 'rcep', 'jp_eu_epa', 'jp_us_trade'].includes(t.treaty_id),
);

/**
 * 種別で条約を絞り込む
 */
export function findTreatiesByKind(kind: TreatyKind): TreatyEntry[] {
  return INTERNATIONAL_TREATIES.filter((t) => t.kind === kind);
}

/**
 * 通称で条約を取得
 */
export function findTreatyByShortName(shortName: string): TreatyEntry | undefined {
  return INTERNATIONAL_TREATIES.find((t) => t.short_name === shortName || t.official_name === shortName);
}

/**
 * 統計
 */
export function countTreaties(): { total: number; by_kind: Record<TreatyKind, number>; mega_epa: number } {
  const byKind: Record<TreatyKind, number> = {
    trade: 0, investment: 0, ip: 0, private_law: 0, human_rights: 0,
    environment: 0, tax: 0, arbitration: 0,
  };
  for (const t of INTERNATIONAL_TREATIES) byKind[t.kind]++;
  return { total: INTERNATIONAL_TREATIES.length, by_kind: byKind, mega_epa: MEGA_EPA_TREATIES.length };
}
