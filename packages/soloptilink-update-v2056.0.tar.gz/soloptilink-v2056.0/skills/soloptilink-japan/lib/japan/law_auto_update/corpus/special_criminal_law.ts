/**
 * Phase 46-LU-3 / 特別刑法
 *
 * 刑法本体の外側で日常的に問題となる主要 12 法。
 *  - 道交法 (運転免許+刑罰+反則金)
 *  - 銃刀法
 *  - 麻薬取締法
 *  - 覚せい剤取締法
 *  - 大麻取締法
 *  - 暴対法 (暴力団員による不当な行為の防止)
 *  - 暴排条例 (各都道府県条例の典型)
 *  - 児童ポルノ禁止法
 *  - ストーカー規制法
 *  - DV防止法 (配偶者暴力)
 *  - リベンジポルノ防止法
 *  - 出入国管理及び難民認定法 (入管法 刑罰部分)
 */

import type { LawCategory } from '../../law_tracker';

export interface SpecialCriminalLawEntry {
  law_id: string;
  short_name: string;
  official_name: string;
  category: LawCategory;
  competent_ministry: string;
  last_effective_date: string;
  key_provisions: Record<string, string>;
  /** 罰則 (刑種+上限) */
  penalties: Array<{ act: string; punishment: string }>;
}

export const SPECIAL_CRIMINAL_LAWS: SpecialCriminalLawEntry[] = [
  {
    law_id: '335AC0000000105',
    short_name: '道交法',
    official_name: '道路交通法',
    category: 'transport',
    competent_ministry: '警察庁',
    last_effective_date: '2024-11-01',
    key_provisions: {
      '64': '無免許運転',
      '65': '酒気帯び運転',
      '66': '過労運転等の禁止',
      '67': '過労運転に係る車両の使用者責任',
      '70': '安全運転義務',
      '103': '免許の取消・停止',
      '125': '反則金 (交通反則通告制度)',
    },
    penalties: [
      { act: '無免許運転 (64条)', punishment: '3年以下の懲役・50万円以下の罰金' },
      { act: '酒気帯び (65条)', punishment: '3年以下の懲役・50万円以下の罰金' },
      { act: '酒酔い (65条1項)', punishment: '5年以下の懲役・100万円以下の罰金' },
      { act: 'ながら運転死傷', punishment: '6月以下の懲役・10万円以下の罰金' },
    ],
  },
  {
    law_id: '333AC0000000006',
    short_name: '銃刀法',
    official_name: '銃砲刀剣類所持等取締法',
    category: 'admin',
    competent_ministry: '警察庁',
    last_effective_date: '2024-04-01',
    key_provisions: {
      '3': '所持禁止',
      '4': '所持許可 (狩猟用銃砲等)',
      '4の2': '空気銃の例外',
      '5': '欠格事由',
      '22': '刃体の長さの制限',
    },
    penalties: [
      { act: '違法所持 (拳銃)', punishment: '1年以上10年以下の懲役' },
      { act: '違法所持 (刀剣)', punishment: '3年以下の懲役・50万円以下の罰金' },
      { act: '正当理由のない刃物携帯', punishment: '2年以下の懲役・30万円以下の罰金' },
    ],
  },
  {
    law_id: '328AC0000000014',
    short_name: '麻取法',
    official_name: '麻薬及び向精神薬取締法',
    category: 'pharma',
    competent_ministry: '厚生労働省',
    last_effective_date: '2024-04-01',
    key_provisions: {
      '12': '麻薬の輸入禁止',
      '13': '麻薬の製造禁止',
      '64': '営利目的輸入',
      '66': '所持・譲渡',
    },
    penalties: [
      { act: '営利目的輸入', punishment: '1年以上の有期懲役+最高1000万円罰金併科' },
      { act: '所持・譲渡', punishment: '7年以下の懲役 (営利目的は1年以上10年以下+500万円)' },
    ],
  },
  {
    law_id: '326AC0000000252',
    short_name: '覚醒剤取締法',
    official_name: '覚醒剤取締法',
    category: 'pharma',
    competent_ministry: '厚生労働省',
    last_effective_date: '2024-04-01',
    key_provisions: {
      '13': '覚醒剤の輸入禁止',
      '14': '覚醒剤の製造禁止',
      '17': '譲渡譲受',
      '19': '使用禁止',
      '41の2': '営利目的所持・譲渡',
    },
    penalties: [
      { act: '営利目的輸入・製造', punishment: '無期又は3年以上の懲役+最高1000万円罰金併科' },
      { act: '所持・譲渡・使用', punishment: '10年以下の懲役 (営利目的は1年以上+500万円)' },
    ],
  },
  {
    law_id: '323AC0000000124',
    short_name: '大麻取締法',
    official_name: '大麻取締法',
    category: 'pharma',
    competent_ministry: '厚生労働省',
    last_effective_date: '2024-12-12',
    key_provisions: {
      '24の2': '所持・譲受・譲渡',
      '24': '栽培・輸入・輸出',
      'R6改正': 'R6年改正で「使用罪」新設・大麻草研究法と分離',
    },
    penalties: [
      { act: '所持・譲渡', punishment: '5年以下の懲役 (営利目的は7年以下+200万円)' },
      { act: '栽培・輸入・輸出', punishment: '7年以下の懲役 (営利目的は10年以下+300万円)' },
      { act: '使用 (R6新設)', punishment: '7年以下の懲役' },
    ],
  },
  {
    law_id: '403AC0000000077',
    short_name: '暴対法',
    official_name: '暴力団員による不当な行為の防止等に関する法律',
    category: 'corporate',
    competent_ministry: '警察庁',
    last_effective_date: '2024-04-01',
    key_provisions: {
      '3': '指定暴力団',
      '9': '不当要求行為',
      '12の6': '指定暴力団員と知ったうえでの取引',
      '15の4': '事業者の損害賠償責任 (代表者責任)',
    },
    penalties: [
      { act: '不当要求行為', punishment: '中止命令違反は1年以下の懲役・100万円以下罰金' },
    ],
  },
  {
    law_id: 'misc_bouhai_pref',
    short_name: '暴排条例 (各都道府県)',
    official_name: '暴力団排除条例',
    category: 'corporate',
    competent_ministry: '都道府県警',
    last_effective_date: '2024-04-01',
    key_provisions: {
      '24': '利益供与禁止',
      '26': '密接交際者公表',
      '27': '罰則 (1年以下の懲役・50万円以下の罰金)',
      'industry_clause': '不動産売買・建設・金融契約に「暴排条項」必須',
    },
    penalties: [
      { act: '密接交際者への利益供与', punishment: '1年以下の懲役・50万円以下の罰金' },
    ],
  },
  {
    law_id: '411AC0000000052',
    short_name: '児童ポルノ法',
    official_name: '児童買春、児童ポルノに係る行為等の規制及び処罰並びに児童の保護等に関する法律',
    category: 'admin',
    competent_ministry: '警察庁/法務省',
    last_effective_date: '2024-04-01',
    key_provisions: {
      '2': '児童ポルノの定義 (18歳未満)',
      '4': '児童買春',
      '7': '児童ポルノ製造・提供',
      '7の3': '盗撮による製造',
    },
    penalties: [
      { act: '児童買春', punishment: '5年以下の懲役・300万円以下の罰金' },
      { act: '児童ポルノ単純所持', punishment: '1年以下の懲役・100万円以下の罰金' },
      { act: '児童ポルノ製造・提供', punishment: '3年以下の懲役・300万円以下の罰金' },
    ],
  },
  {
    law_id: '412AC0000000081',
    short_name: 'ストーカー規制法',
    official_name: 'ストーカー行為等の規制等に関する法律',
    category: 'admin',
    competent_ministry: '警察庁',
    last_effective_date: '2024-04-01',
    key_provisions: {
      '2': 'つきまとい等の定義 (8類型)',
      '3': '禁止命令',
      '4': '警告',
      '5': '禁止命令違反',
      '13': '罰則',
    },
    penalties: [
      { act: 'ストーカー行為', punishment: '1年以下の懲役・100万円以下の罰金' },
      { act: '禁止命令違反', punishment: '2年以下の懲役・200万円以下の罰金' },
    ],
  },
  {
    law_id: '413AC0000000031',
    short_name: 'DV防止法',
    official_name: '配偶者からの暴力の防止及び被害者の保護等に関する法律',
    category: 'admin',
    competent_ministry: '内閣府',
    last_effective_date: '2024-04-01',
    key_provisions: {
      '2': '配偶者からの暴力 (身体・精神・性的)',
      '10': '保護命令 (接近禁止・退去命令)',
      '14': '退去命令 (2ヶ月)',
      '29': '保護命令違反の罰則',
    },
    penalties: [
      { act: '保護命令違反', punishment: '2年以下の懲役・200万円以下の罰金' },
    ],
  },
  {
    law_id: '426AC0000000126',
    short_name: 'リベンジポルノ防止法',
    official_name: '私事性的画像記録の提供等による被害の防止に関する法律',
    category: 'privacy',
    competent_ministry: '警察庁',
    last_effective_date: '2024-04-01',
    key_provisions: {
      '2': '私事性的画像記録の定義',
      '3': '不特定多数への提供罪',
      '4': '提供目的での電気通信',
    },
    penalties: [
      { act: '不特定多数提供', punishment: '3年以下の懲役・50万円以下の罰金' },
      { act: '電気通信による提供', punishment: '1年以下の懲役・30万円以下の罰金' },
    ],
  },
  {
    law_id: '326AC0000000319',
    short_name: '入管法 (刑罰部分)',
    official_name: '出入国管理及び難民認定法',
    category: 'admin',
    competent_ministry: '法務省',
    last_effective_date: '2024-06-10',
    key_provisions: {
      '70': '不法残留',
      '74': '集団密航罪',
      '76の2': '不法就労助長',
      'R5改正': '令和5年改正で送還忌避罪+補完的保護対象者の認定制度を導入',
    },
    penalties: [
      { act: '不法残留', punishment: '3年以下の懲役/禁錮・300万円以下の罰金' },
      { act: '不法就労助長', punishment: '3年以下の懲役・300万円以下の罰金' },
      { act: '集団密航', punishment: '20年以下の懲役・1000万円以下の罰金' },
    ],
  },
];

/**
 * 通称→特別刑法
 */
export function findSpecialCriminalLawByShortName(shortName: string): SpecialCriminalLawEntry | undefined {
  return SPECIAL_CRIMINAL_LAWS.find((l) => l.short_name === shortName || l.official_name === shortName);
}

/**
 * 行為からマッチする罰則を抽出
 */
export function findPenaltiesByAct(actKeyword: string): Array<{ law: string; act: string; punishment: string }> {
  const out: Array<{ law: string; act: string; punishment: string }> = [];
  for (const l of SPECIAL_CRIMINAL_LAWS) {
    for (const p of l.penalties) {
      if (p.act.includes(actKeyword)) {
        out.push({ law: l.short_name, ...p });
      }
    }
  }
  return out;
}

/** 統計 */
export function countSpecialCriminalLaws(): { total: number; total_provisions: number; total_penalties: number } {
  let provs = 0;
  let pens = 0;
  for (const l of SPECIAL_CRIMINAL_LAWS) {
    provs += Object.keys(l.key_provisions).length;
    pens += l.penalties.length;
  }
  return { total: SPECIAL_CRIMINAL_LAWS.length, total_provisions: provs, total_penalties: pens };
}
