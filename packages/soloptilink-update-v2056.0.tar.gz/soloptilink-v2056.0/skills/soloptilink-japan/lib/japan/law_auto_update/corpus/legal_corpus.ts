/**
 * Phase 46-LU-2 / Legal Corpus — 全日本法令メタデータ管理
 *
 * 「日本全ての法令を学習」というユーザー指示への構造的応答。
 * e-Gov 法令検索には約 9,000 法令 (法律2,000 + 政令2,400 + 省令4,000 + 規則500 + その他)
 * が登録されている。本モジュールは:
 *  - メタデータ (lawId, title, type, ministry, lastUpdate) の動的拡張カタログ
 *  - JSONL 永続化レイヤー (corpus.jsonl / corpus_index.json)
 *  - Tier 分類 (S=六法 / A=主要60 / B=専門業法 / C=省令告示 / D=その他)
 *  - 段階的学習: 初回は Tier S/A の本文取得、以降 B→C と段階拡張
 *  - 既存 EXTENDED_LAW_CATALOG とのマージ (重複排除)
 *
 * 本文の同梱はしない (法令改正で陳腐化するため動的取得方式)。
 */

import type { LawCategory, LawCatalogEntry } from '../../law_tracker';
import { LAW_CATALOG } from '../../law_tracker';
import { EXTENDED_LAW_CATALOG, type ExtendedLawCatalogEntry } from '../catalog_full';
import { TIER_A_MAJOR_60 } from './six_codes';

export type LawType = 'Constitution' | 'Act' | 'CabinetOrder' | 'MinisterialOrdinance' | 'Rule' | 'Other';

export type LegalTier = 'S' | 'A' | 'B' | 'C' | 'D';

export interface CorpusEntry {
  law_id: string;
  short_name: string;
  official_name: string;
  law_type: LawType;
  category: LawCategory;
  competent_ministry: string;
  promulgation_date?: string;
  last_effective_date?: string;
  related_modules: string[];
  industry_tags: string[];
  tier: LegalTier;
  /** 監視優先度 (1=毎週 / 2=月次 / 3=四半期 / 4=年次) */
  monitor_priority: 1 | 2 | 3 | 4;
  /** 本文学習済みフラグ */
  text_loaded: boolean;
  /** SHA-256 (本文取得後にセット) */
  text_hash?: string;
  /** 取り込み日時 */
  indexed_at: string;
}

// ---------------------------------------------------------------------------
// 既存カタログを CorpusEntry 形式にアダプタ
// ---------------------------------------------------------------------------

function entryToCorpus(e: LawCatalogEntry | ExtendedLawCatalogEntry): CorpusEntry {
  const ext = e as ExtendedLawCatalogEntry;
  return {
    law_id: e.egovLawId,
    short_name: e.shortName,
    official_name: e.officialName,
    law_type: inferLawType(e.officialName),
    category: e.category,
    competent_ministry: e.competentMinistry,
    promulgation_date: e.lastPromulgationDate,
    last_effective_date: e.lastEffectiveDate,
    related_modules: e.relatedModules ?? [],
    industry_tags: ext.industryTags ?? [],
    tier: classifyTier(e.shortName, e.officialName),
    monitor_priority: ext.monitorPriority ?? 2,
    text_loaded: false,
    indexed_at: new Date().toISOString(),
  };
}

function inferLawType(officialName: string): LawType {
  if (/憲法/.test(officialName)) return 'Constitution';
  if (/(?:政令|施行令)$/.test(officialName)) return 'CabinetOrder';
  if (/(?:省令|施行規則|府令)$/.test(officialName)) return 'MinisterialOrdinance';
  if (/規則$/.test(officialName)) return 'Rule';
  if (/法律|法$/.test(officialName)) return 'Act';
  return 'Other';
}

function classifyTier(shortName: string, officialName: string): LegalTier {
  // Tier S: 六法
  const sixCodes = ['憲法', '民法', '商法', '民訴', '民事訴訟法', '刑法', '刑訴', '刑事訴訟法'];
  if (sixCodes.includes(shortName)) return 'S';
  if (sixCodes.some((s) => officialName === s || officialName.endsWith(s))) return 'S';

  // Tier A: 主要60法令
  if (TIER_A_MAJOR_60.includes(shortName) || TIER_A_MAJOR_60.includes(officialName)) return 'A';

  // Tier B: 専門業法 (許認可+業種固有 — 行政の業法)
  if (/業法$|建設業法|宅地建物取引業法|風営法|警備業法|古物営業法|医療法|介護保険法|薬機法|労働者派遣法|貨物自動車運送事業法|海上運送法|旅館業法|住宅宿泊事業法/.test(officialName)) return 'B';

  // Tier C: 省令・規則・告示
  const type = inferLawType(officialName);
  if (type === 'MinisterialOrdinance' || type === 'Rule') return 'C';

  // Tier D: その他
  return 'D';
}

// ---------------------------------------------------------------------------
// 公開 API
// ---------------------------------------------------------------------------

/** 初期 corpus: 既存 LAW_CATALOG + EXTENDED_LAW_CATALOG をマージ */
export function buildInitialCorpus(): CorpusEntry[] {
  const map = new Map<string, CorpusEntry>();
  for (const e of LAW_CATALOG) {
    map.set(e.egovLawId, entryToCorpus(e));
  }
  for (const e of EXTENDED_LAW_CATALOG) {
    if (!e.egovLawId) continue;
    map.set(e.egovLawId, entryToCorpus(e));
  }
  return [...map.values()];
}

/** Tier 別に分類 */
export function groupByTier(entries: CorpusEntry[]): Record<LegalTier, CorpusEntry[]> {
  const out: Record<LegalTier, CorpusEntry[]> = { S: [], A: [], B: [], C: [], D: [] };
  for (const e of entries) out[e.tier].push(e);
  return out;
}

/** カバレッジ統計 */
export interface CorpusCoverage {
  total: number;
  by_tier: Record<LegalTier, number>;
  by_type: Record<LawType, number>;
  text_loaded: number;
  text_loaded_pct: number;
  target_total: number;
  coverage_pct: number;
}

/** e-Gov v2 の推定登録法令数 (法律2,000 + 政令2,400 + 省令4,000 + 規則500 + その他100 = 約9,000) */
export const ESTIMATED_TOTAL_JAPANESE_LAWS = 9_000;

export function computeCoverage(entries: CorpusEntry[]): CorpusCoverage {
  const byTier: Record<LegalTier, number> = { S: 0, A: 0, B: 0, C: 0, D: 0 };
  const byType: Record<LawType, number> = {
    Constitution: 0, Act: 0, CabinetOrder: 0, MinisterialOrdinance: 0, Rule: 0, Other: 0,
  };
  let textLoaded = 0;
  for (const e of entries) {
    byTier[e.tier] = (byTier[e.tier] ?? 0) + 1;
    byType[e.law_type] = (byType[e.law_type] ?? 0) + 1;
    if (e.text_loaded) textLoaded++;
  }
  const total = entries.length;
  return {
    total,
    by_tier: byTier,
    by_type: byType,
    text_loaded: textLoaded,
    text_loaded_pct: total > 0 ? Math.round((textLoaded / total) * 1000) / 10 : 0,
    target_total: ESTIMATED_TOTAL_JAPANESE_LAWS,
    coverage_pct: Math.round((total / ESTIMATED_TOTAL_JAPANESE_LAWS) * 1000) / 10,
  };
}

/** JSONL 直列化 */
export function serializeCorpusToJsonl(entries: CorpusEntry[]): string {
  return entries.map((e) => JSON.stringify(e)).join('\n') + (entries.length > 0 ? '\n' : '');
}

/** JSONL 逆直列化 */
export function parseCorpusFromJsonl(jsonl: string): CorpusEntry[] {
  return jsonl
    .split('\n')
    .filter((l) => l.trim().length > 0)
    .map((l) => JSON.parse(l) as CorpusEntry);
}

/** マージ (上書き優先) */
export function mergeCorpora(base: CorpusEntry[], additions: CorpusEntry[]): CorpusEntry[] {
  const map = new Map<string, CorpusEntry>();
  for (const e of base) map.set(e.law_id, e);
  for (const e of additions) {
    const prev = map.get(e.law_id);
    map.set(e.law_id, prev ? { ...prev, ...e, indexed_at: new Date().toISOString() } : e);
  }
  return [...map.values()];
}

/** 業種タグから関連法令を逆引き */
export function findByIndustryTag(entries: CorpusEntry[], tag: string): CorpusEntry[] {
  const lower = tag.toLowerCase();
  return entries.filter((e) =>
    e.industry_tags.some((t) => t.toLowerCase().includes(lower) || lower.includes(t.toLowerCase())),
  );
}

/** Tier 別の優先取得対象 */
export function pickPriorityTargets(entries: CorpusEntry[], tier: LegalTier): CorpusEntry[] {
  return entries.filter((e) => e.tier === tier && !e.text_loaded);
}

/** Tier 別の取得上限 (1 回の cron で何件まで取得するか) */
export const TIER_FETCH_BUDGET: Record<LegalTier, number> = {
  S: 6, // 六法 全件
  A: 60, // 主要60 全件
  B: 100, // 専門業法 100件/週
  C: 200, // 省令・規則 200件/週
  D: 50, // その他 50件/週
};

export function planNextCron(entries: CorpusEntry[]): { tier: LegalTier; ids: string[] }[] {
  const plan: { tier: LegalTier; ids: string[] }[] = [];
  for (const t of ['S', 'A', 'B', 'C', 'D'] as LegalTier[]) {
    const pool = pickPriorityTargets(entries, t);
    const take = pool.slice(0, TIER_FETCH_BUDGET[t]);
    if (take.length > 0) plan.push({ tier: t, ids: take.map((e) => e.law_id) });
  }
  return plan;
}
