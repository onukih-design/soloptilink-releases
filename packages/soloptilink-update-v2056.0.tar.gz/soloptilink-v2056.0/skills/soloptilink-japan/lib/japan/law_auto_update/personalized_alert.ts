/**
 * Phase 46-LU / 顧客テナント別パーソナライズ通知
 *
 * Tenant DNA (B-3) と統合する。各テナントの industries /禁止ライブラリ /
 * 命名規則 / 過去の判断 をもとに、改正法令を「その顧客にとって関連あり」と
 * 判定したものだけ通知する。
 *
 * 入力:
 *  - 改正検知結果 (ChangeDetectionResult)
 *  - Tenant DNA Snapshot (industries, products, modules in use)
 *
 * 出力:
 *  - 通知本文 (Markdown / Email-safe HTML / Slack Block Kit JSON)
 *  - 通知チャネル (email / slack / webhook)
 *  - 関連度スコア (0-100, threshold 30 以上のみ送信)
 */

import type { ChangeDetectionResult } from './change_detector';
import { LAW_CATALOG } from '../law_tracker';
import { EXTENDED_LAW_CATALOG, findLawsByIndustry } from './catalog_full';

export interface TenantSnapshot {
  tenantId: string;
  /** 顧客企業の業種タグ群 (Tenant DNA で蓄積) */
  industries: string[];
  /** 顧客が利用中の lib/japan/*.ts モジュール一覧 */
  activeModules?: string[];
  /** 通知先 */
  notificationChannels: Array<
    | { type: 'email'; address: string }
    | { type: 'slack'; webhookUrl: string }
    | { type: 'webhook'; url: string }
  >;
  /** 言語 */
  locale?: 'ja' | 'en' | 'zh-CN';
  /** 通知を受けない法令カテゴリ (オプトアウト) */
  optOutCategories?: string[];
}

export interface PersonalizedAlert {
  tenantId: string;
  lawId: string;
  /** 関連度 (0-100) */
  relevanceScore: number;
  /** 送るべきか */
  shouldNotify: boolean;
  /** 通知本文 (Markdown) */
  bodyMarkdown: string;
  /** Email 件名 */
  emailSubject: string;
  /** 通知チャネル */
  channels: TenantSnapshot['notificationChannels'];
  /** 関連度の根拠 */
  reasons: string[];
}

const NOTIFY_THRESHOLD = 30;

export function buildPersonalizedAlert(input: {
  detection: ChangeDetectionResult;
  tenant: TenantSnapshot;
}): PersonalizedAlert {
  const { detection, tenant } = input;
  const cat = LAW_CATALOG.find((l) => l.egovLawId === detection.lawId)
    ?? EXTENDED_LAW_CATALOG.find((l) => l.egovLawId === detection.lawId);

  let score = 0;
  const reasons: string[] = [];

  // 業種マッチ
  for (const industry of tenant.industries) {
    const lawsForIndustry = findLawsByIndustry(industry);
    if (lawsForIndustry.some((l) => l.egovLawId === detection.lawId)) {
      score += 40;
      reasons.push(`業種「${industry}」が対象法令と一致`);
    }
  }

  // モジュール利用マッチ
  if (tenant.activeModules && cat?.relatedModules) {
    const overlapping = cat.relatedModules.filter((m) => tenant.activeModules!.includes(m));
    if (overlapping.length > 0) {
      score += 30 + Math.min(20, overlapping.length * 5);
      reasons.push(`利用モジュールに ${overlapping.length} 件の影響: ${overlapping.join(', ')}`);
    }
  }

  // 重要度ブースト
  if (detection.severity === 'critical') {
    score += 20;
    reasons.push('改正の重要度が critical');
  } else if (detection.severity === 'major') {
    score += 10;
    reasons.push('改正の重要度が major');
  }

  // オプトアウト
  if (cat && tenant.optOutCategories?.includes(cat.category)) {
    score = 0;
    reasons.push(`オプトアウトカテゴリ: ${cat.category}`);
  }

  score = Math.min(100, score);
  const shouldNotify = score >= NOTIFY_THRESHOLD;
  const locale = tenant.locale ?? 'ja';
  const emailSubject = locale === 'en'
    ? `[Legal Update] ${cat?.shortName ?? detection.lawId} amendment detected`
    : `【法令改正通知】${cat?.shortName ?? detection.lawId} の改正を検知しました`;

  const bodyMarkdown = buildBody({ detection, tenant, cat, score, reasons, locale });

  return {
    tenantId: tenant.tenantId,
    lawId: detection.lawId,
    relevanceScore: score,
    shouldNotify,
    bodyMarkdown,
    emailSubject,
    channels: tenant.notificationChannels,
    reasons,
  };
}

function buildBody(args: {
  detection: ChangeDetectionResult;
  tenant: TenantSnapshot;
  cat: { officialName?: string; shortName?: string; competentMinistry?: string } | undefined;
  score: number;
  reasons: string[];
  locale: 'ja' | 'en' | 'zh-CN';
}): string {
  const { detection, cat, score, reasons, locale } = args;
  const isEn = locale === 'en';
  const lines: string[] = [];
  const title = isEn
    ? `## Legal Update Alert: ${cat?.shortName ?? detection.lawId}`
    : `## ⚖️ 法令改正アラート: ${cat?.shortName ?? detection.lawId}`;
  lines.push(title);
  lines.push('');
  lines.push(isEn ? `- Law: ${cat?.officialName ?? '-'}` : `- 法令: ${cat?.officialName ?? '-'}`);
  lines.push(isEn ? `- Ministry: ${cat?.competentMinistry ?? '-'}` : `- 主管省庁: ${cat?.competentMinistry ?? '-'}`);
  lines.push(isEn ? `- Severity: **${detection.severity}**` : `- 重要度: **${detection.severity}**`);
  lines.push(isEn ? `- Relevance score: ${score}/100` : `- あなたの企業との関連度: ${score}/100`);
  lines.push('');
  if (detection.diff) {
    lines.push(isEn ? `- Changed articles: ${detection.diff.changedArticles.length}` : `- 変更条文数: ${detection.diff.changedArticles.length}`);
    lines.push(isEn ? `- Effective date: ${detection.diff.afterVersion.effectiveDate}` : `- 施行日: ${detection.diff.afterVersion.effectiveDate}`);
    lines.push('');
    lines.push(isEn ? '### Key changes' : '### 主な変更条文');
    for (const c of detection.diff.changedArticles.slice(0, 5)) {
      lines.push(`- 第${c.articleNum}条: ${c.changeType}`);
    }
  }
  lines.push('');
  lines.push(isEn ? '### Why you received this' : '### この通知を受け取った理由');
  for (const r of reasons) lines.push(`- ${r}`);
  lines.push('');
  lines.push(isEn
    ? '> SoloptiLinkAI Phase 46-LU automatically filters legal updates for your industry and modules.'
    : '> SoloptiLinkAI Phase 46-LU は、貴社の業種・利用モジュールに関連する改正のみを自動配信しています。'
  );
  return lines.join('\n');
}

/**
 * 複数テナントへの一括アラート生成。
 * shouldNotify=true のみ返す。
 */
export function buildBulkAlerts(input: {
  detection: ChangeDetectionResult;
  tenants: TenantSnapshot[];
}): PersonalizedAlert[] {
  return input.tenants
    .map((tenant) => buildPersonalizedAlert({ detection: input.detection, tenant }))
    .filter((a) => a.shouldNotify);
}
