#!/usr/bin/env bash
# incident_hash_chain.sh
# Critical-1-3 対応: 個情法第26条 5日速報の「知った時点」立証用ハッシュチェーン記録
#
# 個情法第26条は「報告対象事態を知った時点」から3〜5日以内速報義務を課す。
# 客観的な「知った時点」の立証手段として、改ざんがあれば検知できる(改ざん耐性のある)ハッシュチェーン記録を生成する。
# ※正直性(W6): ハッシュ連鎖は改ざん「検知」であって「完全防止」ではない。最終的な否認防止は運用(独立保管)と法務に委ねる。
#
# 記録方式:
#   1. ローカル: ~/.soloptilink/.incident-log/ にチェーン構造で append-only
#   2. 公開透明性ログ: Sigstore Rekor に SHA-256 ハッシュを記録 (オプション、推奨)
#
# Usage:
#   incident_hash_chain.sh detect <event_type> <description> [evidence_file...]
#   incident_hash_chain.sh verify <log_id>
#   incident_hash_chain.sh export <from_date> <to_date> <output_file>

set -euo pipefail

LOG_DIR="${SOLOPTILINK_INCIDENT_LOG_DIR:-$HOME/.soloptilink/.incident-log}"
CHAIN_FILE="$LOG_DIR/chain.jsonl"
mkdir -p "$LOG_DIR"
chmod 700 "$LOG_DIR"

cmd_detect() {
  local event_type="${1:-}"
  local description="${2:-}"
  shift 2 || true

  if [ -z "$event_type" ] || [ -z "$description" ]; then
    echo "Usage: $0 detect <event_type> <description> [evidence_file...]" >&2
    exit 1
  fi

  local detected_at
  detected_at=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
  local detected_at_jst
  detected_at_jst=$(TZ=Asia/Tokyo date +"%Y-%m-%dT%H:%M:%S+09:00")
  local id
  id="incident_$(date -u +%Y%m%dT%H%M%SZ)_$(printf '%04x' $((RANDOM % 65536)))"

  local prev_hash="GENESIS"
  if [ -s "$CHAIN_FILE" ]; then
    prev_hash=$(tail -1 "$CHAIN_FILE" | sed -n 's/.*"hash":"\([^"]*\)".*/\1/p')
    if [ -z "$prev_hash" ]; then prev_hash="GENESIS"; fi
  fi

  local evidence_hashes="[]"
  if [ "$#" -gt 0 ]; then
    local items=""
    for f in "$@"; do
      if [ -f "$f" ]; then
        local h
        h=$(shasum -a 256 "$f" | awk '{print $1}')
        items+="{\"path\":\"$(escape_json "$f")\",\"sha256\":\"$h\"},"
      fi
    done
    evidence_hashes="[${items%,}]"
  fi

  local record
  record=$(printf '{"id":"%s","detected_at":"%s","detected_at_jst":"%s","event_type":"%s","description":"%s","prev_hash":"%s","evidence":%s}' \
    "$id" "$detected_at" "$detected_at_jst" \
    "$(escape_json "$event_type")" "$(escape_json "$description")" "$prev_hash" "$evidence_hashes")

  local record_hash
  record_hash=$(printf '%s' "$record" | sha256_of_stdin)

  local final
  final=$(printf '%s' "$record" | sed "s/}\$/,\"hash\":\"$record_hash\"}/")
  printf '%s\n' "$final" >> "$CHAIN_FILE"
  chmod 600 "$CHAIN_FILE"

  if command -v cosign >/dev/null 2>&1 && [ "${SOLOPTILINK_REKOR_PUBLISH:-0}" = "1" ]; then
    local tmp
    tmp=$(mktemp)
    printf '%s' "$record_hash" > "$tmp"
    COSIGN_EXPERIMENTAL=1 cosign sign-blob --yes --bundle "$LOG_DIR/${id}.bundle" "$tmp" >/dev/null 2>&1 || true
    rm -f "$tmp"
  fi

  echo "[INCIDENT-LOGGED] id=$id detected_at=$detected_at hash=$record_hash"
  echo "[INCIDENT-LOGGED] file=$CHAIN_FILE"
  echo "$id"
}

cmd_verify() {
  local target_id="${1:-}"
  if [ -z "$target_id" ]; then
    echo "Usage: $0 verify <log_id>" >&2
    exit 1
  fi
  if [ ! -f "$CHAIN_FILE" ]; then
    echo "[ERROR] Chain file missing: $CHAIN_FILE" >&2
    exit 2
  fi

  local prev_hash="GENESIS"
  local found=0
  while IFS= read -r line; do
    local id_in_record
    id_in_record=$(printf '%s' "$line" | sed -n 's/.*"id":"\([^"]*\)".*/\1/p')
    local prev_in_record
    prev_in_record=$(printf '%s' "$line" | sed -n 's/.*"prev_hash":"\([^"]*\)".*/\1/p')
    local hash_in_record
    hash_in_record=$(printf '%s' "$line" | sed -n 's/.*"hash":"\([^"]*\)".*/\1/p')

    if [ "$prev_in_record" != "$prev_hash" ]; then
      echo "[CHAIN-BROKEN] at id=$id_in_record (prev_hash mismatch)" >&2
      exit 3
    fi

    local body
    body=$(printf '%s' "$line" | sed 's/,"hash":"[^"]*"}$/}/')
    local recomputed
    recomputed=$(printf '%s' "$body" | sha256_of_stdin)
    if [ "$recomputed" != "$hash_in_record" ]; then
      echo "[CHAIN-BROKEN] at id=$id_in_record (hash mismatch: expected $hash_in_record got $recomputed)" >&2
      exit 4
    fi

    if [ "$id_in_record" = "$target_id" ]; then
      found=1
      echo "[VERIFIED] $line"
    fi
    prev_hash="$hash_in_record"
  done < "$CHAIN_FILE"

  if [ "$found" -eq 0 ]; then
    echo "[NOT-FOUND] id=$target_id" >&2
    exit 5
  fi
}

cmd_export() {
  local from_date="${1:-}"
  local to_date="${2:-}"
  local output="${3:-}"
  if [ -z "$from_date" ] || [ -z "$to_date" ] || [ -z "$output" ]; then
    echo "Usage: $0 export <from_date YYYY-MM-DD> <to_date YYYY-MM-DD> <output_file>" >&2
    exit 1
  fi
  awk -v from="$from_date" -v to="$to_date" '
    {
      if (match($0, /"detected_at":"[^"]+"/)) {
        d = substr($0, RSTART+15, 10)
        if (d >= from && d <= to) print
      }
    }' "$CHAIN_FILE" > "$output"
  echo "[EXPORTED] $(wc -l < "$output") records to $output"
}

sha256_of_stdin() {
  if command -v shasum >/dev/null 2>&1; then
    shasum -a 256 | awk '{print $1}'
  else
    sha256sum | awk '{print $1}'
  fi
}

escape_json() {
  printf '%s' "$1" | sed 's/\\/\\\\/g; s/"/\\"/g; s/\t/\\t/g' | tr -d '\n'
}

case "${1:-}" in
  detect) shift; cmd_detect "$@" ;;
  verify) shift; cmd_verify "$@" ;;
  export) shift; cmd_export "$@" ;;
  *)
    cat <<EOF >&2
個情法第26条 ハッシュチェーン記録ツール

Commands:
  detect <event_type> <description> [evidence_file...]
      個人情報漏えい等の検知時に「知った時点」を改ざん検知可能(tamper-evident)に記録
      返り値: incident ID (PPC様式第一に転記)

  verify <log_id>
      指定ID のチェーン整合性を検証 (改ざんがあれば exit 3/4)

  export <from> <to> <output>
      指定期間のレコードを export (PPC提出用)

Environment:
  SOLOPTILINK_INCIDENT_LOG_DIR  ログ保存先 (default: ~/.soloptilink/.incident-log)
  SOLOPTILINK_REKOR_PUBLISH=1   Sigstore Rekor 透明性ログ公開を有効化

Example:
  $0 detect "PII_LEAK" "顧客テーブル外部閲覧可能" /var/log/access.log /var/log/db-audit.log
  $0 verify incident_20260510T143000Z_a1b2
EOF
    exit 1
    ;;
esac
