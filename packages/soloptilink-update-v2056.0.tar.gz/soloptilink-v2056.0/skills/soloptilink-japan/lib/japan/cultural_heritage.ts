/**
 * lib/japan/cultural_heritage.ts — 文化財保護DNA
 *
 * 法令カバレッジ:
 *  - 文化財保護法 (S25法律214) 全7類型
 *  - 文化財保護法 R元改正 (登録文化財制度拡充 / 個別保存活用計画 R2.4施行)
 *  - 古都における歴史的風土の保存に関する特別措置法 (古都保存法)
 *  - 歴史まちづくり法 (H20法律40) 歴史的風致維持向上計画
 *  - 屋外広告物法 + 都道府県景観条例
 *  - 伝統的建造物群保存地区 (伝建地区) 制度 (文化財保護法144条)
 *  - 世界遺産条約 + UNESCO 普遍的価値 (OUV) 評価
 *
 * 参考: 文化庁文化資源活用課, 各都道府県教育委員会文化財保護係
 */

// ============================================================================
// 1. 文化財7類型 (文化財保護法2条)
// ============================================================================

export const CULTURAL_PROPERTY_TYPES = {
  tangible: { ja: '有形文化財', law: '法27条以下', examples: ['建造物', '絵画', '彫刻', '工芸品', '書跡', '典籍', '古文書', '考古資料'] },
  intangible: { ja: '無形文化財', law: '法71条以下', examples: ['芸能 (歌舞伎/能/狂言)', '工芸技術 (陶芸/染織)'] },
  folk: { ja: '民俗文化財', law: '法78条以下', examples: ['風俗慣習', '民俗芸能', '民俗技術', '民俗資料'] },
  monument: { ja: '記念物', law: '法109条以下', examples: ['史跡', '名勝', '天然記念物'] },
  cultural_landscape: { ja: '文化的景観', law: '法134条以下', examples: ['棚田', '里山', '漁村'] },
  preservation_district: { ja: '伝統的建造物群保存地区 (伝建地区)', law: '法144条', examples: ['白川郷', '京都産寧坂', '萩'] },
  cultural_heritage_techniques: { ja: '文化財保存技術', law: '法147条', examples: ['檜皮葺', '茅葺', '宮大工'] },
} as const;

export type PropertyType = keyof typeof CULTURAL_PROPERTY_TYPES;

/** 文化財の指定 / 登録 / 認定の階層 */
export type DesignationLevel =
  | 'national_designated' // 国指定文化財
  | 'national_treasure' // 国宝
  | 'important_cultural_property' // 重要文化財
  | 'national_registered' // 国登録文化財 (届出制)
  | 'prefectural_designated' // 都道府県指定
  | 'municipal_designated' // 市町村指定
  | 'unregistered'; // 未指定

// ============================================================================
// 2. 現状変更 / 修理の許可 / 届出
// ============================================================================

export interface ModificationRequest {
  level: DesignationLevel;
  type: PropertyType;
  modificationKind: 'major_repair' | 'minor_repair' | 'relocation' | 'destruction' | 'use_change';
  approvedRestorer?: string; // 文化財選定保存技術保持者など
}

/** 文化財の現状変更等の許可 / 届出義務 (法43条 / 64条 / 81条 / 125条) */
export function requiresPermitForModification(r: ModificationRequest): {
  authority: string;
  procedure: 'permit' | 'notification' | 'none';
  noticeAdvanceDays: number;
  blockerIfMissing: string[];
} {
  const blockers: string[] = [];

  // 国宝・重要文化財・特別史跡名勝天然記念物 = 文化庁長官の許可必要
  if (r.level === 'national_treasure' || r.level === 'important_cultural_property') {
    if (r.modificationKind === 'destruction') {
      blockers.push('国宝/重文の毀損は刑事罰対象 (法195条 5年以下の懲役)');
    }
    if (r.modificationKind === 'major_repair' && !r.approvedRestorer) {
      blockers.push('大規模修理は文化財選定保存技術保持者の関与必須');
    }
    return {
      authority: '文化庁長官',
      procedure: 'permit',
      noticeAdvanceDays: 30,
      blockerIfMissing: blockers,
    };
  }
  if (r.level === 'national_registered') {
    return {
      authority: '文化庁長官 (届出のみ)',
      procedure: 'notification',
      noticeAdvanceDays: 30,
      blockerIfMissing: blockers,
    };
  }
  if (r.level === 'prefectural_designated' || r.level === 'municipal_designated') {
    return {
      authority: '都道府県/市町村教育委員会',
      procedure: 'permit',
      noticeAdvanceDays: 14,
      blockerIfMissing: blockers,
    };
  }
  return {
    authority: '不要',
    procedure: 'none',
    noticeAdvanceDays: 0,
    blockerIfMissing: blockers,
  };
}

// ============================================================================
// 3. 史跡 / 名勝 / 天然記念物 (法109条以下)
// ============================================================================

/** 史跡指定された土地での発掘調査要否 (法92条/93条) */
export function requiresArchaeologicalSurvey(input: {
  isInBuriedRelicArea: boolean; // 周知の埋蔵文化財包蔵地
  constructionAreaM2: number;
  isPublicWork: boolean;
}): { required: boolean; advanceDays: number; cost: 'public' | 'private' } {
  if (!input.isInBuriedRelicArea) return { required: false, advanceDays: 0, cost: 'private' };
  return {
    required: true,
    advanceDays: 60, // 法93条: 工事60日前までに届出
    cost: input.isPublicWork ? 'public' : 'private', // 民間は原則自己負担
  };
}

// ============================================================================
// 4. 伝統的建造物群保存地区 (伝建地区)
// ============================================================================

/** 重要伝統的建造物群保存地区 (重伝建) — 全国126地区 (R6現在) の一部例 */
export const FAMOUS_PRESERVATION_DISTRICTS = [
  { name: '白川村荻町', prefecture: '岐阜県', designated: 1976 },
  { name: '京都市産寧坂', prefecture: '京都府', designated: 1976 },
  { name: '萩市堀内地区', prefecture: '山口県', designated: 1976 },
  { name: '高山市三町', prefecture: '岐阜県', designated: 1979 },
  { name: '倉敷市倉敷川畔', prefecture: '岡山県', designated: 1979 },
  { name: '川越市川越', prefecture: '埼玉県', designated: 1999 },
] as const;

/** 伝建地区内の建築行為制限 */
export function isModificationAllowedInPresDistrict(input: {
  buildingKind: 'traditional' | 'environmental_design' | 'modern';
  modificationKind: 'exterior' | 'paint' | 'roof' | 'demolition' | 'new_construction';
  hasMunicipalApproval: boolean;
}): { allowed: boolean; reason: string } {
  if (input.buildingKind === 'traditional' && input.modificationKind === 'demolition') {
    return { allowed: false, reason: '伝統的建造物の取壊しは原則不可 — 移築復元を検討' };
  }
  if (!input.hasMunicipalApproval) {
    return { allowed: false, reason: '伝建地区内の現状変更は市町村教委の許可必須 (法146条)' };
  }
  if (input.modificationKind === 'paint') {
    return { allowed: true, reason: '色彩は地区計画の色彩基準 (マンセル値) 適合確認のうえ可' };
  }
  return { allowed: true, reason: '事前協議済みなら可' };
}

// ============================================================================
// 5. 古都保存法 / 歴史まちづくり法
// ============================================================================

/** 古都保存法の対象10市町村 (古都として政令指定) */
export const ANCIENT_CAPITAL_CITIES = [
  '京都市', '奈良市', '鎌倉市', '天理市', '橿原市', '桜井市',
  '生駒郡斑鳩町', '高市郡明日香村', '大津市', '逗子市',
] as const;

/** 古都保存法 — 歴史的風土特別保存地区 内の建築制限 */
export function checkAncientCapitalRestriction(input: {
  city: string;
  buildingHeightM: number;
  exteriorColor: string;
}): { restricted: boolean; reason: string } {
  if (!(ANCIENT_CAPITAL_CITIES as readonly string[]).includes(input.city)) {
    return { restricted: false, reason: '古都保存法 対象外' };
  }
  if (input.buildingHeightM > 10) {
    return { restricted: true, reason: '歴史的風土特別保存地区内は概ね高さ10m以下推奨' };
  }
  return { restricted: false, reason: '範囲内 — ただし都市計画法・景観条例の確認推奨' };
}

// ============================================================================
// 6. 補助金 / 税制優遇
// ============================================================================

/** 文化財修復補助金率 (国指定 vs 県指定 vs 登録) */
export function calcCulturalHeritageSubsidy(input: {
  level: DesignationLevel;
  totalRepairCostJpy: number;
}): { subsidyRate: number; subsidyJpy: number; ownerBurdenJpy: number } {
  const r =
    input.level === 'national_treasure'
      ? 0.85
      : input.level === 'important_cultural_property'
        ? 0.5
        : input.level === 'national_registered'
          ? 0.5
          : input.level === 'prefectural_designated'
            ? 0.5
            : input.level === 'municipal_designated'
              ? 0.4
              : 0;
  const subsidy = Math.round(input.totalRepairCostJpy * r);
  return { subsidyRate: r, subsidyJpy: subsidy, ownerBurdenJpy: input.totalRepairCostJpy - subsidy };
}

// ============================================================================
// 7. 世界遺産 (UNESCO) 普遍的価値 (OUV) 評価
// ============================================================================

/** 世界遺産候補の登録基準 (10基準のうち1つ以上満たす必要) */
export const UNESCO_OUV_CRITERIA = {
  i: '人類の創造的才能を表す傑作',
  ii: '文化交流の重要な証拠',
  iii: '文化的伝統または文明の独特な証拠',
  iv: '建築技術の発展段階を示す顕著な見本',
  v: '伝統的人類居住の顕著な見本',
  vi: '出来事や思想・信仰と直接関連',
  vii: '自然美または美的重要性',
  viii: '地球史の主要段階を表す',
  ix: '生態系・生物進化を示す顕著な見本',
  x: '生物多様性の生息地',
} as const;

/** 世界遺産候補としての適合性 (簡易) */
export function evaluateWorldHeritageReadiness(input: {
  ouvCriteriaMet: (keyof typeof UNESCO_OUV_CRITERIA)[];
  hasManagementPlan: boolean;
  hasBufferZone: boolean;
  hasCommunitySupport: boolean;
}): { recommendable: boolean; gaps: string[] } {
  const gaps: string[] = [];
  if (input.ouvCriteriaMet.length === 0) gaps.push('OUV基準1つ以上の証明が必要');
  if (!input.hasManagementPlan) gaps.push('保存管理計画 (Management Plan) が必須');
  if (!input.hasBufferZone) gaps.push('緩衝地帯 (Buffer Zone) の設定が必要');
  if (!input.hasCommunitySupport) gaps.push('地域コミュニティ合意形成が不十分');
  return { recommendable: gaps.length === 0, gaps };
}
