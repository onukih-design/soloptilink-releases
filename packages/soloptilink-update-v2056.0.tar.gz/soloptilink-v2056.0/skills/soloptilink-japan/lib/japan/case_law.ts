/**
 * @fileoverview Phase 13 - 判例 DNA
 *
 * 「最高裁判所 判例検索システム」「下級裁ジュリスト」「労働判例」
 * を統合した実務上のリスク早期警戒モジュール。
 *
 * 法令はあるが「実際の運用で何が違法とされたか」は判例が決める。
 * 本モジュールは:
 *   1. 重要判例カタログ (会社法/労働法/個情法/契約/不法行為)
 *   2. 業務シナリオ → 関連判例ルックアップ
 *   3. リスク評価 (判例ベースの予測スコア)
 *   4. 業界別ベストプラクティスへの落とし込み
 *
 * Claude Code は「判例を確認しましょう」止まり。
 * 本モジュールは具体的な判決年月日 + 結論 + 教訓 + コード上の対応箇所まで提示。
 */

// ============================================================================
// Types
// ============================================================================

export type CourtLevel = 'supreme' | 'high' | 'district' | 'summary' | 'family' | 'admin';
export type CaseDomain = 'labor' | 'corporate' | 'privacy' | 'consumer' | 'antitrust' | 'tort' | 'contract' | 'tax' | 'real_estate' | 'medical' | 'criminal' | 'admin';

export interface CaseLawEntry {
  caseId: string;
  caseName: string;
  court: CourtLevel;
  decisionDate: string;
  domain: CaseDomain;
  /** 事案の概要 */
  summary: string;
  /** 争点 */
  issues: string[];
  /** 裁判所の判断 */
  ruling: 'plaintiff' | 'defendant' | 'partial';
  /** 判決要旨 */
  rulingSummary: string;
  /** 実務上の教訓 */
  practicalLesson: string;
  /** 関連法令ID (e-Gov) */
  relatedLawIds?: string[];
  /** 本ライブラリ内の関連モジュール */
  relatedModules?: string[];
  /** 判例集出典 */
  reporter?: string;
}

// ============================================================================
// 重要判例カタログ (代表サンプル・実運用は判例検索システム参照)
// ============================================================================

export const LANDMARK_CASES: CaseLawEntry[] = [
  // 労働法
  {
    caseId: 'H30.6.1',
    caseName: 'ハマキョウレックス事件',
    court: 'supreme',
    decisionDate: '2018-06-01',
    domain: 'labor',
    summary: '契約社員と正社員の手当格差 (通勤・無事故・作業・給食・皆勤手当) の不合理性が争点',
    issues: ['労働契約法旧20条の不合理性判断'],
    ruling: 'plaintiff',
    rulingSummary: '通勤手当・無事故手当・作業手当・給食手当・皆勤手当の格差は不合理',
    practicalLesson: '正社員と非正規社員の手当・福利厚生は、職務内容・配置変更範囲・その他事情を踏まえ実質的に説明できなければならない',
    relatedLawIds: ['327AC0000000056'],
    relatedModules: ['lib/japan/laws.ts'],
  },
  {
    caseId: 'R2.10.13',
    caseName: '大阪医科薬科大学事件',
    court: 'supreme',
    decisionDate: '2020-10-13',
    domain: 'labor',
    summary: 'アルバイト職員と正職員の賞与・私傷病有給休暇の格差',
    issues: ['労契法旧20条 / パート・有期労働法8条'],
    ruling: 'defendant',
    rulingSummary: '賞与・私傷病有給休暇の格差は不合理ではない (職務内容差 + キャリアパス差を考慮)',
    practicalLesson: '雇用形態間の処遇差には合理的な理由 (職務内容・キャリア)を文書化して残すべき',
    relatedModules: ['lib/japan/ringi.ts'],
  },
  // 個情法
  {
    caseId: 'H29.10.23',
    caseName: 'ベネッセ個人情報漏えい事件',
    court: 'supreme',
    decisionDate: '2017-10-23',
    domain: 'privacy',
    summary: '元委託先業務員による個人情報の不正持ち出し',
    issues: ['個情法上の安全管理措置義務違反 / 不法行為責任'],
    ruling: 'plaintiff',
    rulingSummary: '個別ユーザーへの慰謝料 (1人当たり数百〜数千円) を認定',
    practicalLesson: '委託先の安全管理措置監督 + 監査ログ + アクセス権最小化を必須化。ベネッセ事件以降、漏えい時1人500-3300円が相場',
    // 個人情報の保護に関する法律 平成十五年法律第五十七号
    // (2026-07-31 実測是正: 旧値は e-Gov に存在しないIDだった・課題台帳 Q-04)
    relatedLawIds: ['415AC0000000057'],
    relatedModules: ['lib/japan/incident.ts', 'lib/japan/security_audit.ts'],
  },
  // 会社法
  {
    caseId: 'H22.7.15',
    caseName: '日本航空管財人事件 (取締役の善管注意義務)',
    court: 'supreme',
    decisionDate: '2010-07-15',
    domain: 'corporate',
    summary: '経営判断における取締役の責任',
    issues: ['会社法330条 / 民法644条 善管注意義務'],
    ruling: 'defendant',
    rulingSummary: '経営判断原則: 当時の状況下で著しく不合理でない判断は責任を問わない',
    practicalLesson: '稟議の論拠・調査範囲・代替案検討を文書化することが取締役・執行役員の防御になる',
    relatedModules: ['lib/japan/ringi.ts'],
  },
  // 消費者法
  {
    caseId: 'H22.6.17',
    caseName: '更新料条項事件',
    court: 'supreme',
    decisionDate: '2010-07-15',
    domain: 'consumer',
    summary: '賃貸借契約における更新料条項の有効性',
    issues: ['消費者契約法10条 (信義則違反)'],
    ruling: 'defendant',
    rulingSummary: '更新料条項は直ちに無効ではないが、合理性審査が必要',
    practicalLesson: '消費者向け約款は「合理的説明可能性」を確保。隠れた費用は無効化リスク大',
    relatedModules: ['templates/japan/Contract.tsx'],
  },
  // 不法行為
  {
    caseId: 'R3.7.27',
    caseName: 'ウーバーイーツ配達員 損害賠償事件',
    court: 'district',
    decisionDate: '2021-07-27',
    domain: 'tort',
    summary: 'プラットフォーム事業者の使用者責任',
    issues: ['民法715条 / 委託契約 vs 雇用契約'],
    ruling: 'partial',
    rulingSummary: '実態が雇用契約に近い場合、プラットフォームに使用者責任の余地',
    practicalLesson: 'ギグワーカーとの契約は実態判断に注意。指揮命令性・専属性が高ければ雇用と認定されるリスク',
    relatedModules: ['lib/japan/ringi.ts'],
  },
  // 医療
  {
    caseId: 'H17.9.8',
    caseName: '医療水準論',
    court: 'supreme',
    decisionDate: '2005-09-08',
    domain: 'medical',
    summary: '医師の注意義務の基準',
    issues: ['債務不履行 / 不法行為責任'],
    ruling: 'plaintiff',
    rulingSummary: '医療水準は医療現場で実施されている水準を基準とする',
    practicalLesson: '電子カルテ/医療システムは「業界標準実装」を取り入れていることが訴訟リスク回避の前提',
    relatedModules: ['lib/japan/medical.ts'],
  },
];

// ============================================================================
// シナリオ → 関連判例ルックアップ
// ============================================================================

export function findCasesForScenario(input: {
  domain: CaseDomain;
  keywords?: string[];
  cases?: CaseLawEntry[];
}): CaseLawEntry[] {
  const cases = input.cases ?? LANDMARK_CASES;
  return cases.filter((c) => {
    if (c.domain !== input.domain) return false;
    if (!input.keywords || input.keywords.length === 0) return true;
    const blob = `${c.caseName} ${c.summary} ${c.issues.join(' ')} ${c.rulingSummary} ${c.practicalLesson}`;
    return input.keywords.some((k) => blob.includes(k));
  });
}

// ============================================================================
// 判例ベースのリスク評価
// ============================================================================

export interface CaseLawRiskAssessment {
  scenarioDescription: string;
  relevantCases: CaseLawEntry[];
  /** 0-100 (低いほど安全) */
  riskScore: number;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
  recommendations: string[];
}

export function assessRiskByCaseLaw(input: {
  scenarioDescription: string;
  domain: CaseDomain;
  keywords?: string[];
  /** 推定影響金額 (円) */
  estimatedImpactYen?: number;
}): CaseLawRiskAssessment {
  const cases = findCasesForScenario({ domain: input.domain, keywords: input.keywords });
  let score = 0;
  const recommendations: string[] = [];

  for (const c of cases) {
    if (c.ruling === 'plaintiff') {
      score += c.court === 'supreme' ? 25 : c.court === 'high' ? 15 : 8;
    } else if (c.ruling === 'partial') {
      score += 10;
    }
    recommendations.push(`【${c.caseName}】${c.practicalLesson}`);
  }

  if ((input.estimatedImpactYen ?? 0) > 100_000_000) score += 20;
  else if ((input.estimatedImpactYen ?? 0) > 10_000_000) score += 10;

  score = Math.min(100, score);
  const level: CaseLawRiskAssessment['riskLevel'] = score >= 75 ? 'critical' : score >= 50 ? 'high' : score >= 25 ? 'medium' : 'low';

  return {
    scenarioDescription: input.scenarioDescription,
    relevantCases: cases,
    riskScore: score,
    riskLevel: level,
    recommendations,
  };
}

// ============================================================================
// 損害賠償の相場 (判例ベースの目安)
// ============================================================================

export const DAMAGE_BENCHMARKS = {
  pii_leak_per_person_yen: { min: 500, mode: 1500, max: 35000 },     // ベネッセ系判例
  unfair_dismissal_avg_months: { min: 3, mode: 12, max: 24 },        // 解雇無効後のバックペイ
  defamation_per_post_yen: { min: 100000, mode: 500000, max: 2000000 },
  contract_breach_avg_pct: 0.10,                                      // 契約金額の10%が和解相場
  ip_infringement_avg_yen: { min: 1_000_000, mode: 10_000_000, max: 100_000_000 },
} as const;

export const CASE_LAW_REFS = {
  SUPREME_COURT_SEARCH: 'https://www.courts.go.jp/app/hanrei_jp/search1',
  ROUDOU_HANREI: 'https://www.romukenkyusho.co.jp/',
  WESTLAW_JAPAN: 'https://www.westlawjapan.com/',
};
