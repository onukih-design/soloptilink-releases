/**
 * SoloptiLinkAI Phase 43-IT — 安全保障輸出管理 / 外為法 (Export Control)
 *
 * 外国為替及び外国貿易法 (外為法) に基づく輸出管理。
 * 既存 finance.ts (AML/金商法) との役割分離: export_control = 物品/技術の輸出許可。
 *
 * カバー範囲:
 *  - 外為法 第48条 (安全保障輸出管理)
 *  - リスト規制 (輸出貿易管理令 別表第1) - 16項目+輸出貿易管理規則
 *  - キャッチオール規制 (大量破壊兵器 + 通常兵器) - 該否判定+客観要件
 *  - 輸出許可申請 (個別/包括/特定包括/特別一般) - 経済産業省
 *  - エンドユーザー (許可・要許可・懸念) チェック
 *  - 米国EAR/ITAR 域外適用 (再輸出規制)
 *  - 国連安保理決議 経済制裁 (北朝鮮/イラン/ロシア)
 */

// 輸出貿易管理令 別表第1 リスト規制 (16項目)
export const LIST_CONTROL_CATEGORIES = [
  { id: 1, name: "武器", description: "銃砲、爆発物、戦車、軍艦等" },
  { id: 2, name: "原子力", description: "ウラン、プルトニウム、原子炉、再処理装置" },
  { id: 3, name: "化学兵器", description: "化学剤前駆物質、製造装置" },
  { id: "3-2", name: "生物兵器", description: "病原体、毒素、培養装置" },
  { id: 4, name: "ミサイル", description: "ロケットシステム、推進装置、誘導装置" },
  { id: 5, name: "先端材料", description: "高機能合金、繊維、セラミックス" },
  { id: 6, name: "材料加工", description: "高速工作機械、検査装置" },
  { id: 7, name: "エレクトロニクス", description: "高性能IC、電子計算機部品" },
  { id: 8, name: "電子計算機", description: "高性能サーバ、スパコン (R5改正で対象拡大)" },
  { id: 9, name: "通信", description: "通信機器、暗号装置" },
  { id: 10, name: "センサー/レーザー", description: "光学センサー、レーザー測距装置" },
  { id: 11, name: "航法装置", description: "GPS、慣性航法装置" },
  { id: 12, name: "海洋関連", description: "潜水装置、水中音響" },
  { id: 13, name: "推進装置", description: "ジェットエンジン、ロケットエンジン" },
  { id: 14, name: "その他", description: "毒性化学物質、ロボット" },
  { id: 15, name: "機微汎用品", description: "民生品でも軍事転用可能なもの" },
  { id: 16, name: "AI/半導体製造装置", description: "R5.7追加 経産省告示 23ナノメートル以下" },
] as const;

export type ListControlId = (typeof LIST_CONTROL_CATEGORIES)[number]["id"];

// 該否判定の結果
export type GaihinClassification =
  | "list_controlled" // リスト規制該当 → 個別許可必要
  | "catchall_required" // キャッチオール対象 → 該当性確認
  | "non_controlled"; // 規制外

export interface ItemClassification {
  item_name: string;
  hs_code?: string; // 関税分類HSコード
  classification: GaihinClassification;
  list_category_id?: ListControlId;
  reason: string;
}

// 客観要件 (経産省 大量破壊兵器/通常兵器キャッチオール)
export interface CatchallObjectiveCheck {
  is_user_in_foreign_user_list: boolean; // 外国ユーザーリスト掲載者
  destination_high_risk_country: boolean; // 北朝鮮/イラン/シリア等
  end_use_concern: "wmd" | "conventional_weapons" | "none";
  notice_from_meti: boolean; // インフォーム要件
}

export function evaluateCatchallObligation(check: CatchallObjectiveCheck): {
  permit_required: boolean;
  reason: string;
} {
  if (check.is_user_in_foreign_user_list) {
    return { permit_required: true, reason: "外国ユーザーリスト掲載 → 客観要件該当" };
  }
  if (check.notice_from_meti) {
    return { permit_required: true, reason: "経済産業大臣からのインフォーム通知あり" };
  }
  if (check.end_use_concern === "wmd" || check.end_use_concern === "conventional_weapons") {
    return { permit_required: true, reason: `用途確認: ${check.end_use_concern} → キャッチオール該当` };
  }
  if (check.destination_high_risk_country) {
    return { permit_required: true, reason: "高懸念仕向地 → 厳格審査" };
  }
  return { permit_required: false, reason: "キャッチオール非該当 (該当性確認結果保管 7年)" };
}

// 輸出許可種別 (外為法施行令)
export type ExportPermitType =
  | "individual" // 個別許可 (1取引ごと)
  | "comprehensive" // 包括許可 (バルク)
  | "specific_comprehensive" // 特定包括
  | "general_bulk" // 特別一般包括
  | "special_general"; // 特別一般包括

export interface PermitDecision {
  permit_type: ExportPermitType;
  reason: string;
  estimated_review_days: number;
  applicant_requirements: string[];
}

export function recommendPermitType(input: {
  classification: GaihinClassification;
  list_category_id?: ListControlId;
  destination_country: string;
  has_internal_compliance_program: boolean;
  past_violations: number;
}): PermitDecision {
  // 違反歴ありはすべて個別
  if (input.past_violations > 0) {
    return {
      permit_type: "individual",
      reason: `過去${input.past_violations}件の違反履歴 → 個別許可のみ`,
      estimated_review_days: 90,
      applicant_requirements: ["役員・株主構成", "輸出取引内容", "誓約書"],
    };
  }
  // ICPあり + ホワイト国 (G7+α) は特別一般包括
  const whitelistCountries = ["米国", "英国", "ドイツ", "フランス", "イタリア", "カナダ", "オランダ", "ベルギー", "豪州", "ニュージーランド", "韓国"];
  if (input.has_internal_compliance_program && whitelistCountries.includes(input.destination_country)) {
    return {
      permit_type: "special_general",
      reason: "ICP整備済み + 信頼仕向地 (旧ホワイト国/グループA)",
      estimated_review_days: 30,
      applicant_requirements: ["内部コンプライアンスプログラム (CP) 認定", "輸出管理責任者選任"],
    };
  }
  if (input.classification === "list_controlled") {
    return {
      permit_type: "individual",
      reason: "リスト規制該当",
      estimated_review_days: 90,
      applicant_requirements: ["技術詳細", "エンドユース宣誓書", "需要者確認"],
    };
  }
  return {
    permit_type: "comprehensive",
    reason: "通常案件 → 包括許可",
    estimated_review_days: 60,
    applicant_requirements: ["輸出計画", "需要者リスト"],
  };
}

// エンドユーザーチェック
export type UserStatus = "trusted" | "under_review" | "concerning" | "denied";

export interface EndUserCheckResult {
  user_name: string;
  country: string;
  status: UserStatus;
  flagged_lists: string[]; // 該当する制裁リスト
  recommended_action: "proceed" | "additional_review" | "deny";
  reasoning: string[];
}

// 主要な制裁リスト (2026年4月時点)
export const SANCTION_LISTS = [
  "外国ユーザーリスト (経済産業省)",
  "OFAC SDNリスト (米国財務省)",
  "OFAC Sectoral Sanctions",
  "UK Consolidated List",
  "EU Consolidated Financial Sanctions",
  "国連安保理 制裁リスト",
  "BIS Entity List (米国商務省)",
  "BIS Unverified List",
] as const;

export function checkEndUser(input: {
  user_name: string;
  country: string;
  external_lists_hits: string[];
  is_government_owned: boolean;
  is_military_affiliated: boolean;
}): EndUserCheckResult {
  const reasons: string[] = [];
  let status: UserStatus = "trusted";
  let action: EndUserCheckResult["recommended_action"] = "proceed";

  if (input.external_lists_hits.length > 0) {
    reasons.push(`制裁リスト掲載: ${input.external_lists_hits.join(", ")}`);
    status = "denied";
    action = "deny";
  }
  const sanctionedCountries = ["北朝鮮", "イラン", "シリア", "クリミア", "ロシア (一部)"];
  if (sanctionedCountries.some((s) => input.country.includes(s))) {
    reasons.push(`仕向地が経済制裁対象: ${input.country}`);
    if (status !== "denied") status = "denied";
    action = "deny";
  }
  if (input.is_military_affiliated) {
    reasons.push("軍事関連事業者");
    if (status === "trusted") status = "concerning";
    if (action === "proceed") action = "additional_review";
  }
  if (input.is_government_owned) {
    reasons.push("政府系企業 → 用途確認強化");
    if (status === "trusted") status = "under_review";
    if (action === "proceed") action = "additional_review";
  }

  return {
    user_name: input.user_name,
    country: input.country,
    status,
    flagged_lists: input.external_lists_hits,
    recommended_action: action,
    reasoning: reasons,
  };
}

// 米国 EAR/ITAR 再輸出規制 (域外適用)
export interface ReexportEvaluation {
  is_us_origin: boolean;
  us_content_percentage: number; // De Minimis ルール
  ear_classification?: string; // ECCN (例: 5A002)
  itar_jurisdiction: boolean;
  re_export_license_required: boolean;
  reasoning: string[];
}

export function evaluateReexportLicense(input: {
  product: string;
  contains_us_origin: boolean;
  us_content_percentage: number;
  ear_classification?: string;
  destination_country: string;
}): ReexportEvaluation {
  const reasons: string[] = [];
  let required = false;
  // De Minimis ルール (一般的に 25%、テロ支援国家10%)
  const sanctionedCountries = ["北朝鮮", "イラン", "シリア", "キューバ"];
  const deMinimisThreshold = sanctionedCountries.some((s) => input.destination_country.includes(s)) ? 10 : 25;
  if (input.contains_us_origin && input.us_content_percentage > deMinimisThreshold) {
    reasons.push(`米国原産品比率 ${input.us_content_percentage}% > De Minimis ${deMinimisThreshold}% → 再輸出許可必要`);
    required = true;
  }
  if (input.ear_classification && /^[0-9][A-Z]00[1-9]/.test(input.ear_classification)) {
    reasons.push(`ECCN ${input.ear_classification} は機微品目 → 個別審査`);
    required = true;
  }
  return {
    is_us_origin: input.contains_us_origin,
    us_content_percentage: input.us_content_percentage,
    ear_classification: input.ear_classification,
    itar_jurisdiction: false, // ITAR は別途評価
    re_export_license_required: required,
    reasoning: reasons,
  };
}

// 内部コンプライアンスプログラム (CP) 認定要件
export interface ComplianceProgram {
  has_export_management_basic_policy: boolean;
  has_organization_chart: boolean;
  designated_export_manager: boolean;
  classification_procedure: boolean;
  user_screening_procedure: boolean;
  internal_audit_year: number;
  training_year: number;
  record_retention_years: number; // 法定7年
  annual_report_to_meti: boolean;
}

export function evaluateCp(cp: ComplianceProgram): { certified: boolean; missing: string[] } {
  const missing: string[] = [];
  if (!cp.has_export_management_basic_policy) missing.push("輸出管理基本方針");
  if (!cp.has_organization_chart) missing.push("輸出管理組織図");
  if (!cp.designated_export_manager) missing.push("輸出管理責任者の選任");
  if (!cp.classification_procedure) missing.push("該非判定手続");
  if (!cp.user_screening_procedure) missing.push("需要者・用途確認手続");
  if (cp.internal_audit_year < 1) missing.push("年1回以上の内部監査");
  if (cp.training_year < 1) missing.push("年1回以上の研修");
  if (cp.record_retention_years < 7) missing.push("文書保存7年 (外為法施行規則)");
  if (!cp.annual_report_to_meti) missing.push("経産省への年次報告");
  return { certified: missing.length === 0, missing };
}
