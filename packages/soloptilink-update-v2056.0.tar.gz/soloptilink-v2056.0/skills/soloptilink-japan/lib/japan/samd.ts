/**
 * SoloptiLinkAI Phase 42-HC — Software as a Medical Device (SaMD)
 *
 * 医療機器プログラムの薬機法対応。
 * 既存 medical.ts/longterm_care.ts と完全独立 (医療機器プログラムの製造販売業)。
 *
 * カバー範囲:
 *  - 薬機法 第14条 医療機器プログラム (R3.4施行 改訂)
 *  - IMDRF SaMD 4階層リスク分類 (Class I-IV)
 *  - 薬機法上のクラス分類 (一般/管理/高度管理/特定保守管理)
 *  - QMS省令 (ISO 13485 + JIS Q 13485 適合)
 *  - PMDA 製造販売業/製造業/輸入業 許可
 *  - PMS (市販後調査) + 不具合報告 (薬機法68条の10)
 *  - サイバーセキュリティ ガイダンス (FDA Premarket + 厚労省)
 *  - AI/ML SaMD 継続学習対応 (PCCP / Predetermined Change Control Plan)
 */

// IMDRF SaMD リスク分類 (4階層)
export type ImdrfRiskClass = "I" | "II" | "III" | "IV";

export interface ImdrfClassification {
  health_situation: "non_serious" | "serious" | "critical";
  significance: "treat_diagnose" | "drive_clinical_management" | "inform_clinical_management";
  imdrf_class: ImdrfRiskClass;
}

// IMDRF Risk Categorization Framework Table
const IMDRF_TABLE: Record<string, ImdrfRiskClass> = {
  "non_serious|inform_clinical_management": "I",
  "non_serious|drive_clinical_management": "II",
  "non_serious|treat_diagnose": "II",
  "serious|inform_clinical_management": "II",
  "serious|drive_clinical_management": "III",
  "serious|treat_diagnose": "III",
  "critical|inform_clinical_management": "III",
  "critical|drive_clinical_management": "IV",
  "critical|treat_diagnose": "IV",
};

export function classifyImdrfRisk(
  health_situation: ImdrfClassification["health_situation"],
  significance: ImdrfClassification["significance"],
): ImdrfClassification {
  const key = `${health_situation}|${significance}`;
  return {
    health_situation,
    significance,
    imdrf_class: IMDRF_TABLE[key] ?? "I",
  };
}

// 薬機法上のクラス (日本独自 4区分)
export type YakkihoClass = "general" | "controlled" | "highly_controlled" | "specially_controlled";

export const YAKKIHO_CLASS_DESCRIPTION: Record<YakkihoClass, string> = {
  general: "一般医療機器 (Class I): 不具合発生時のリスクが極めて低い",
  controlled: "管理医療機器 (Class II): 不具合発生時のリスクが比較的低い",
  highly_controlled: "高度管理医療機器 (Class III/IV): 不具合発生時のリスクが比較的高い",
  specially_controlled: "特定保守管理医療機器: 保守点検が必要 (Class III/IV の一部)",
};

// IMDRF Class → 薬機法 Class 対応
export function imdrfToYakkiho(imdrfClass: ImdrfRiskClass): YakkihoClass {
  switch (imdrfClass) {
    case "I": return "general";
    case "II": return "controlled";
    case "III": return "highly_controlled";
    case "IV": return "highly_controlled"; // または specially_controlled
  }
}

// PMDA 製造販売業/製造業/輸入業
export type PmdaLicenseType = "first_class_seller" | "second_class_seller" | "third_class_seller" | "manufacturer" | "importer";

export interface PmdaLicense {
  license_type: PmdaLicenseType;
  license_no: string;
  prefecture: string; // 申請先都道府県
  expiry_date: string;
  responsible_engineer: string; // 製造管理者/品質管理者
  qms_certified: boolean; // ISO 13485 / QMS省令適合
}

// 製造販売承認 / 認証 / 届出
export type RegulatorySubmissionType =
  | "shonin" // 承認 (高度管理)
  | "ninsho" // 認証 (管理 - 第三者認証機関)
  | "todokede"; // 届出 (一般)

export function getRequiredSubmissionType(yakkihoClass: YakkihoClass): RegulatorySubmissionType {
  switch (yakkihoClass) {
    case "general": return "todokede";
    case "controlled": return "ninsho";
    case "highly_controlled":
    case "specially_controlled":
      return "shonin";
  }
}

// QMS (品質マネジメントシステム) 適合性
export interface QmsCompliance {
  iso_13485_certified: boolean;
  jis_q_13485_certified: boolean;
  design_control: boolean;
  document_control: boolean;
  capa: boolean; // Corrective and Preventive Action
  internal_audit_year: number;
  management_review_year: number;
  supplier_qualification: boolean;
  ucan_traceability: boolean; // UDI (Unique Device Identification) 一意機器識別子
}

export function checkQmsCompliance(c: QmsCompliance): { compliant: boolean; missing: string[] } {
  const missing: string[] = [];
  if (!c.iso_13485_certified && !c.jis_q_13485_certified) missing.push("ISO 13485 / JIS Q 13485 認証");
  if (!c.design_control) missing.push("設計管理 (Design Control)");
  if (!c.document_control) missing.push("文書管理");
  if (!c.capa) missing.push("CAPA (是正・予防措置)");
  if (c.internal_audit_year < 1) missing.push("年1回以上の内部監査");
  if (c.management_review_year < 1) missing.push("年1回以上のマネジメントレビュー");
  if (!c.supplier_qualification) missing.push("供給者の力量評価");
  if (!c.ucan_traceability) missing.push("UDI トレーサビリティ");
  return { compliant: missing.length === 0, missing };
}

// PMS (市販後調査) + 不具合報告
export type AdverseEventGrade = "trivial" | "non_severe" | "severe" | "life_threatening" | "death";

export interface AdverseEventReportSamd {
  patient_id: string;
  device_udi: string;
  occurred_at: string;
  reported_at: string;
  description: string;
  grade: AdverseEventGrade;
  causality: "unrelated" | "unlikely" | "possible" | "probable" | "definite";
  pmda_report_due_days?: number;
}

// 薬機法施行規則 第228条の20 不具合報告期限
export function calcPmdaReportDueDays(grade: AdverseEventGrade, isUnknown: boolean = false): number {
  if (grade === "death" || grade === "life_threatening") {
    return isUnknown ? 15 : 30; // 未知=15日、既知=30日
  }
  if (grade === "severe") return isUnknown ? 15 : 30;
  if (grade === "non_severe") return 30;
  return 0; // trivial: 報告不要
}

export function buildAdverseEventReport(
  base: Omit<AdverseEventReportSamd, "pmda_report_due_days">,
  isUnknownEffect: boolean = false,
): AdverseEventReportSamd {
  return {
    ...base,
    pmda_report_due_days: calcPmdaReportDueDays(base.grade, isUnknownEffect),
  };
}

// AI/ML SaMD - PCCP (Predetermined Change Control Plan)
export interface PccpPlan {
  device_id: string;
  baseline_version: string;
  planned_modifications: {
    type: "performance_metric_update" | "input_data_change" | "use_case_expansion" | "use_population_change";
    description: string;
    requires_re_review: boolean;
  }[];
  retraining_frequency: "monthly" | "quarterly" | "yearly" | "event_driven";
  performance_monitoring: {
    metric: string;
    threshold: number;
    alert_action: "log" | "human_review" | "auto_rollback";
  }[];
}

export function evaluatePccpModification(plan: PccpPlan, modificationIndex: number): { allowed: boolean; reason: string } {
  const mod = plan.planned_modifications[modificationIndex];
  if (!mod) return { allowed: false, reason: "計画外の変更" };
  if (mod.requires_re_review) {
    return { allowed: false, reason: "PMDA 再審査が必要 (use_case_expansion / use_population_change 等)" };
  }
  return { allowed: true, reason: "PCCP 計画範囲内" };
}

// サイバーセキュリティ要件 (R5.4 厚労省ガイドライン)
export interface CyberSecurityRequirement {
  threat_modeling: boolean; // STRIDE 等
  vulnerability_disclosure_policy: boolean;
  sbom_provided: boolean;
  patch_management: boolean;
  secure_boot: boolean;
  encrypted_communication: boolean;
  hardcoded_credential_check: boolean;
  pen_test_year: number;
}

export function checkCyberSecurity(c: CyberSecurityRequirement): { score: number; missing: string[] } {
  const missing: string[] = [];
  let score = 0;
  if (c.threat_modeling) score += 15; else missing.push("脅威モデリング (STRIDE等)");
  if (c.vulnerability_disclosure_policy) score += 10; else missing.push("脆弱性開示ポリシー (VDP)");
  if (c.sbom_provided) score += 15; else missing.push("SBOM (Software Bill of Materials)");
  if (c.patch_management) score += 15; else missing.push("パッチ管理プロセス");
  if (c.secure_boot) score += 10; else missing.push("セキュアブート");
  if (c.encrypted_communication) score += 15; else missing.push("通信暗号化 TLS 1.2+");
  if (c.hardcoded_credential_check) score += 10; else missing.push("ハードコード認証情報チェック");
  if (c.pen_test_year >= 1) score += 10; else missing.push("年1回以上のペネトレーションテスト");
  return { score, missing };
}
