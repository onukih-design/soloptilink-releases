/**
 * SoloptiLinkAI Phase 45 — Real-Time Compliance Monitor
 *
 * 既存 law_tracker.ts は 9 法令の e-Gov カタログを保持し diff を計算するだけ。
 * 本モジュールはそれを「リアルタイム改正検出 → 影響アセスメント → 通知ルーター
 * → 是正タスク自動生成 → SLA 駆動エスカレーション」までの完全パイプラインに拡張する。
 *
 * 対応シグナルソース:
 *  1. e-Gov API (法令データ)
 *  2. 各省庁プレスリリース (RSS / アーカイブ JSON)
 *  3. 官報 (国立印刷局)
 *  4. 個情委 / 公取委 / 国税庁の個別通達
 *  5. case_law (新判例追加)
 *
 * 設計思想:
 *  - 入力は JSON 形式の RegulatoryChange[] (外部スクリプトが定期収集)
 *  - 各企業のプロファイル (industry / size / handles_pii / business_segments) と
 *    突合して影響度を算出
 *  - 影響度は 5 段階 (none / minor / moderate / major / critical)
 *  - critical は 24時間以内のエスカレーション通知 (経営層+CISO)
 *
 * なぜClaude Codeに作れないか:
 *  - 日本省庁のプレスリリース監視は Anthropic の事業範囲外
 *  - 各企業の業種・規模・取扱データに応じた「影響度カスタマイズ」が必要
 *  - 通知 SLA は個情法第26条 (5営業日)・金商法 (重要事実は即時)・建設業法 (届出義務14日) と多様
 */

// ───────────────────────────────────────────────
// 入力: 規制変更シグナル
// ───────────────────────────────────────────────

export type ChangeType =
  | "law_amendment" // 法改正
  | "subordinate_regulation" // 政省令
  | "ministerial_guideline" // 省庁ガイドライン
  | "court_precedent" // 判例追加
  | "ppc_alert" // 個情委アラート
  | "jftc_consent_order" // 公取委確約計画
  | "fsa_supervisory_action" // 金融庁業務改善命令
  | "press_release"; // 一般プレスリリース

export type Domain = "personal_info" | "labor" | "consumer" | "ai_governance" | "tax" | "construction" | "medical" | "fiea" | "esg" | "subcontract" | "trade_secret" | "antitrust" | "general";

export interface RegulatoryChange {
  change_id: string;
  change_type: ChangeType;
  title: string;
  source: string; // e-Gov / 個情委 / 公取委 / 厚労省 / 経産省 / 国交省 / 金融庁 / 国税庁
  source_url?: string;
  published_at: string; // ISO8601
  effective_at?: string; // 施行日
  domains: Domain[];
  summary: string;
  full_text_excerpt?: string;
  detected_at: string;
}

// ───────────────────────────────────────────────
// 企業プロファイル (突合用)
// ───────────────────────────────────────────────

export interface ImpactProfile {
  org_name: string;
  industry: string;
  total_employees: number;
  business_segments: string[]; // 例: "BtoC EC" / "建設" / "医療" / "派遣"
  handles_personal_data: boolean;
  handles_my_number: boolean;
  uses_ai_in_decision: boolean;
  is_listed_company: boolean;
  is_subcontractor: boolean;
  is_prime_contractor: boolean;
  trade_secret_classes: ("S" | "A" | "B" | "C")[]; // 営業秘密分類
  jurisdictions: ("jp" | "eu" | "us" | "asean" | "cn")[];
}

// ───────────────────────────────────────────────
// 影響アセスメント
// ───────────────────────────────────────────────

export type ImpactLevel = "none" | "minor" | "moderate" | "major" | "critical";

export interface ImpactAssessment {
  change_id: string;
  org_name: string;
  level: ImpactLevel;
  rationale: string;
  affected_segments: string[];
  affected_modules: string[]; // lib/japan モジュール
  remediation_sla_hours: number;
  legal_deadline?: string; // 法令上の義務期限 (例: 個情法第26条 5営業日)
  notify_roles: ("ceo" | "cfo" | "ciso" | "dpo" | "compliance" | "legal" | "engineering")[];
  recommended_actions: string[];
  detected_at: string;
}

// ───────────────────────────────────────────────
// 影響評価ロジック
// ───────────────────────────────────────────────

const DOMAIN_TO_MODULES: Record<Domain, string[]> = {
  personal_info: ["incident", "compliance_ledger", "security_audit"],
  labor: ["hr_payroll", "dispatch"],
  consumer: ["marketing_compliance", "ai_compliance"],
  ai_governance: ["ai_compliance", "ai_governance_smb"],
  tax: ["tax", "tax_filing"],
  construction: ["compliance_ledger", "estimates"],
  medical: ["medical", "phr", "samd"],
  fiea: ["finance"],
  esg: ["esg_carbon"],
  subcontract: ["compliance_ledger"],
  trade_secret: ["security_audit"],
  antitrust: ["compliance_ledger"],
  general: ["compliance_ledger"],
};

/**
 * 規制変更が特定企業に与える影響を算出する。
 */
export function assessImpact(change: RegulatoryChange, profile: ImpactProfile, now: Date = new Date()): ImpactAssessment {
  let level: ImpactLevel = "none";
  const segments: string[] = [];
  const reasons: string[] = [];
  const modules = new Set<string>();

  for (const dom of change.domains) {
    DOMAIN_TO_MODULES[dom]?.forEach((m) => modules.add(m));
  }

  // 個人情報領域
  if (change.domains.includes("personal_info") && profile.handles_personal_data) {
    level = upgrade(level, "major");
    reasons.push("個人情報を取扱う事業者として直接影響");
    segments.push("個情法対応プロセス全般");
    if (change.change_type === "ppc_alert") {
      level = upgrade(level, "critical");
      reasons.push("個情委アラート: 24時間以内対応推奨");
    }
  }

  // 労働法領域
  if (change.domains.includes("labor") && profile.total_employees > 0) {
    level = upgrade(level, "moderate");
    reasons.push(`従業員 ${profile.total_employees} 名に直接影響`);
    if (profile.total_employees > 300) {
      level = upgrade(level, "major");
      reasons.push("301名以上は内部通報体制義務など追加要件");
    }
    segments.push("就業規則・労働契約・36協定");
  }

  // AI ガバナンス
  if (change.domains.includes("ai_governance") && profile.uses_ai_in_decision) {
    level = upgrade(level, "major");
    reasons.push("AI を意思決定に利用 (高リスク用途相当)");
    segments.push("AI 利用規程・倫理委員会・監査ログ");
    if (profile.jurisdictions.includes("eu")) {
      level = upgrade(level, "critical");
      reasons.push("EU AI Act 域外適用 (GPAI 義務)");
    }
  }

  // 消費者法 (景表法/ステマ規制)
  if (change.domains.includes("consumer") && profile.business_segments.some((s) => /BtoC|EC|広告|マーケ/.test(s))) {
    level = upgrade(level, "major");
    reasons.push("BtoC/広告事業に直接影響");
    segments.push("広告表示・SNS 投稿・口コミ");
  }

  // 税務 (インボイス・電帳法)
  if (change.domains.includes("tax")) {
    level = upgrade(level, "moderate");
    segments.push("経理・請求書・領収書・帳簿");
    reasons.push("経理プロセス見直し");
  }

  // 下請法
  if (change.domains.includes("subcontract")) {
    if (profile.is_prime_contractor) {
      level = upgrade(level, "major");
      reasons.push("親事業者として下請法義務");
      segments.push("発注書面・3条書面・支払サイト60日");
    } else if (profile.is_subcontractor) {
      level = upgrade(level, "moderate");
      reasons.push("下請事業者として権利強化");
    }
  }

  // 業種特化
  if (change.domains.includes("medical") && profile.industry === "医療") {
    level = upgrade(level, "major");
    reasons.push("医療業種・3省2ガイドライン直撃");
    segments.push("HIS/EMR/PHR/院内ネットワーク");
  }
  if (change.domains.includes("construction") && profile.industry === "建設") {
    level = upgrade(level, "major");
    reasons.push("建設業種・建設業法直撃");
    segments.push("建設業許可・施工計画・監理技術者");
  }
  if (change.domains.includes("fiea") && profile.is_listed_company) {
    level = upgrade(level, "critical");
    reasons.push("上場企業・金商法重要事実は即時開示義務");
    segments.push("適時開示・有価証券報告書・四半期報告");
  }

  // 営業秘密
  if (change.domains.includes("trade_secret") && profile.trade_secret_classes.includes("S")) {
    level = upgrade(level, "major");
    reasons.push("Class S 営業秘密保有 (秘密管理性維持が重要)");
  }

  if (segments.length === 0) {
    reasons.push("該当事業セグメントなし");
  }

  // SLA 計算
  const slaHours = slaForLevel(level, change);
  const legalDeadline = computeLegalDeadline(change, now);

  return {
    change_id: change.change_id,
    org_name: profile.org_name,
    level,
    rationale: reasons.join(" / "),
    affected_segments: segments,
    affected_modules: [...modules],
    remediation_sla_hours: slaHours,
    legal_deadline: legalDeadline,
    notify_roles: notifyRolesFor(level, change),
    recommended_actions: recommendedActions(change, profile, level),
    detected_at: now.toISOString(),
  };
}

function upgrade(current: ImpactLevel, candidate: ImpactLevel): ImpactLevel {
  const order: ImpactLevel[] = ["none", "minor", "moderate", "major", "critical"];
  const ci = order.indexOf(current);
  const ni = order.indexOf(candidate);
  return ni > ci ? candidate : current;
}

function slaForLevel(level: ImpactLevel, change: RegulatoryChange): number {
  // 個情委アラートは特例で 24h
  if (change.change_type === "ppc_alert") return 24;
  if (change.change_type === "fsa_supervisory_action") return 48;
  switch (level) {
    case "critical":
      return 24;
    case "major":
      return 72;
    case "moderate":
      return 7 * 24;
    case "minor":
      return 30 * 24;
    default:
      return 0;
  }
}

function computeLegalDeadline(change: RegulatoryChange, now: Date): string | undefined {
  if (change.change_type === "ppc_alert") {
    // 個情法第26条 R4改正: 重大事案は 5 営業日
    const deadline = addBusinessDays(now, 5);
    return deadline.toISOString();
  }
  if (change.effective_at) return change.effective_at;
  return undefined;
}

function notifyRolesFor(level: ImpactLevel, change: RegulatoryChange): ImpactAssessment["notify_roles"] {
  const roles: ImpactAssessment["notify_roles"] = [];
  if (level === "critical") roles.push("ceo", "cfo", "ciso", "dpo", "compliance", "legal");
  else if (level === "major") roles.push("ciso", "dpo", "compliance", "legal");
  else if (level === "moderate") roles.push("compliance", "legal");
  else roles.push("compliance");
  if (change.domains.includes("ai_governance")) roles.push("engineering");
  return [...new Set(roles)];
}

function recommendedActions(change: RegulatoryChange, profile: ImpactProfile, level: ImpactLevel): string[] {
  const actions: string[] = [];
  if (level === "critical") {
    actions.push("経営会議で 24 時間以内に審議 (議事録要件)");
    actions.push("法令対応プロジェクトを起票");
  }
  if (change.domains.includes("personal_info")) {
    actions.push("DPIA 再実施");
    actions.push("プライバシーポリシー改訂");
    actions.push("従業員研修の更新");
  }
  if (change.domains.includes("ai_governance")) {
    actions.push("AI 利用規程の改訂");
    actions.push("倫理委員会の特別開催");
  }
  if (change.domains.includes("labor")) {
    actions.push("就業規則改訂 + 労基署届出");
    actions.push("36 協定の見直し");
  }
  if (change.change_type === "court_precedent") {
    actions.push("既存契約書条項の判例適合性レビュー");
  }
  if (change.change_type === "ministerial_guideline" && profile.is_prime_contractor) {
    actions.push("下請契約書テンプレ更新");
  }
  return actions;
}

function addBusinessDays(start: Date, days: number): Date {
  const d = new Date(start.getTime());
  let added = 0;
  while (added < days) {
    d.setDate(d.getDate() + 1);
    const dow = d.getDay();
    if (dow !== 0 && dow !== 6) added++;
  }
  return d;
}

// ───────────────────────────────────────────────
// 通知ルーター
// ───────────────────────────────────────────────

export interface Notification {
  notification_id: string;
  to_roles: string[];
  channel: "email" | "slack" | "ms_teams" | "incident_pager" | "dashboard";
  subject: string;
  body: string;
  due_at_iso: string;
  priority: "P0" | "P1" | "P2" | "P3";
}

export function buildNotifications(assessment: ImpactAssessment, change: RegulatoryChange, now: Date = new Date()): Notification[] {
  if (assessment.level === "none") return [];
  const dueAt = new Date(now.getTime() + assessment.remediation_sla_hours * 3600_000).toISOString();
  const priority: Notification["priority"] =
    assessment.level === "critical" ? "P0" : assessment.level === "major" ? "P1" : assessment.level === "moderate" ? "P2" : "P3";

  const ch: Notification["channel"][] = [];
  if (priority === "P0") ch.push("incident_pager", "slack", "email");
  else if (priority === "P1") ch.push("slack", "email", "dashboard");
  else ch.push("email", "dashboard");

  return ch.map((c, i) => ({
    notification_id: `notif-${assessment.change_id}-${c}-${i}`,
    to_roles: assessment.notify_roles,
    channel: c,
    subject: `[${priority}] 規制変更通知: ${change.title}`,
    body:
      `規制変更 ID: ${change.change_id}\n` +
      `タイプ: ${change.change_type}\n` +
      `要約: ${change.summary}\n` +
      `影響度: ${assessment.level}\n` +
      `理由: ${assessment.rationale}\n` +
      `推奨アクション:\n - ${assessment.recommended_actions.join("\n - ")}\n` +
      (assessment.legal_deadline ? `法定期限: ${assessment.legal_deadline}\n` : "") +
      `SLA: ${assessment.remediation_sla_hours}h`,
    due_at_iso: dueAt,
    priority,
  }));
}

// ───────────────────────────────────────────────
// バッチ処理 API
// ───────────────────────────────────────────────

export interface MonitorOutput {
  total_changes: number;
  assessments: ImpactAssessment[];
  notifications: Notification[];
  by_level: Record<ImpactLevel, number>;
}

export function runMonitor(changes: RegulatoryChange[], profile: ImpactProfile, now: Date = new Date()): MonitorOutput {
  const assessments: ImpactAssessment[] = [];
  const notifications: Notification[] = [];
  const byLevel: Record<ImpactLevel, number> = { none: 0, minor: 0, moderate: 0, major: 0, critical: 0 };
  for (const c of changes) {
    const a = assessImpact(c, profile, now);
    assessments.push(a);
    byLevel[a.level]++;
    if (a.level !== "none") notifications.push(...buildNotifications(a, c, now));
  }
  return { total_changes: changes.length, assessments, notifications, by_level: byLevel };
}
