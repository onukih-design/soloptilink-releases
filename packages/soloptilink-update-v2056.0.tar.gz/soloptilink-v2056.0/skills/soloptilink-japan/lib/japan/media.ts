/**
 * media.ts — Phase 24 メディア・著作権
 *
 * カバレッジ:
 *   - 著作権法 (R6 改正含む) — 著作物性判定/権利存続/職務著作
 *   - 著作隣接権 — 実演家/レコード製作者/放送事業者/有線放送事業者
 *   - 引用要件 4 要件 (公正な慣行/必要最小限/明瞭区別/主従関係)
 *   - 私的使用 30条 + 30条の2 (写り込み)
 *   - JASRAC / NexTone 信託委託 + 包括契約料率
 *   - 放送法 (NHK/民放/BPO)
 *   - 景表法ステマ規制との連携 (PR表示義務)
 *   - 電子出版権 + 出版権設定契約
 *   - クリエイティブ・コモンズ + パブリックドメイン
 *
 * 主要 export:
 *   - WORK_KINDS / isCopyrightableWork / calcCopyrightExpiry
 *   - JOB_AUTHORSHIP_REQUIREMENTS / isJobAuthored
 *   - CITATION_REQUIREMENTS / isProperCitation
 *   - JASRAC_USAGE_FEES / calcJasracFee
 *   - BROADCAST_LICENSES / requiresBroadcastLicense
 *   - PR_LABEL_RULES / needsPrLabel
 *   - CC_LICENSES / explainCCLicense
 *   - PUBLISHING_RIGHT_TYPES / setupPublishingRight
 */

// ===== 著作権法 =====

export type WorkKind =
  | 'language' // 言語の著作物
  | 'music' // 音楽
  | 'dance' // 舞踊・無言劇
  | 'art' // 美術 (絵画/彫刻/書/建築)
  | 'architecture' // 建築の著作物
  | 'map' // 地図・図形
  | 'cinematographic' // 映画
  | 'photographic' // 写真
  | 'program' // プログラム
  | 'derivative' // 二次的著作物
  | 'compilation' // 編集著作物
  | 'database'; // データベース著作物

export const WORK_KINDS: WorkKind[] = [
  'language', 'music', 'dance', 'art', 'architecture',
  'map', 'cinematographic', 'photographic', 'program',
  'derivative', 'compilation', 'database',
];

/**
 * 著作物の3要件: 思想・感情の表現 / 創作性 / 表現された範囲。
 * 単なる事実・データそのもの・ありふれた表現は対象外。
 */
export function isCopyrightableWork(p: {
  isExpressionOfThoughtOrEmotion: boolean;
  hasCreativity: boolean;
  isMereFactOrIdea: boolean;
}): { copyrightable: boolean; reason: string } {
  if (p.isMereFactOrIdea) return { copyrightable: false, reason: '事実・アイデアそのものは保護対象外' };
  if (!p.isExpressionOfThoughtOrEmotion) return { copyrightable: false, reason: '思想・感情の表現でない' };
  if (!p.hasCreativity) return { copyrightable: false, reason: '創作性が認められない (ありふれた表現)' };
  return { copyrightable: true, reason: '著作物性あり' };
}

/**
 * 著作権存続期間 (R6 時点):
 *   - 個人著作: 著作者の死後 70 年 (TPP 整合 H30 改正以降)
 *   - 法人著作 / 映画: 公表後 70 年
 *   - 無名・変名: 公表後 70 年 (実名登録で死後 70 年)
 * 翌年 1/1 起算で 70 年経過の年末で消滅。
 */
export function calcCopyrightExpiry(p: {
  workKind: WorkKind;
  isCorporateAuthored: boolean;
  authorDeathYear?: number;
  publicationYear?: number;
}): { expiryYear: number; basis: string } {
  const TERM = 70;
  if (p.workKind === 'cinematographic' || p.isCorporateAuthored) {
    if (p.publicationYear === undefined) return { expiryYear: 9999, basis: '公表年不明' };
    return { expiryYear: p.publicationYear + TERM, basis: '公表後70年 (法人著作/映画)' };
  }
  if (p.authorDeathYear === undefined) return { expiryYear: 9999, basis: '死亡年不明' };
  return { expiryYear: p.authorDeathYear + TERM, basis: '死後70年 (個人著作)' };
}

// ===== 職務著作 (15条) =====

export const JOB_AUTHORSHIP_REQUIREMENTS = [
  '法人等の発意に基づき作成',
  '法人等の業務に従事する者が職務上作成',
  '法人等が自己の名義で公表 (プログラムは公表要件不要)',
  '作成時の契約・勤務規則等で別段の定めがない',
] as const;

export function isJobAuthored(p: {
  initiatedByCorp: boolean;
  createdInDuty: boolean;
  publishedAsCorpName: boolean;
  isProgram: boolean;
  hasOverridingContract: boolean;
}): { jobAuthored: boolean; missing: string[] } {
  const m: string[] = [];
  if (!p.initiatedByCorp) m.push('法人発意');
  if (!p.createdInDuty) m.push('職務上の作成');
  if (!p.isProgram && !p.publishedAsCorpName) m.push('法人名義の公表');
  if (p.hasOverridingContract) m.push('別段の定め (契約・規則) を解消');
  return { jobAuthored: m.length === 0, missing: m };
}

// ===== 引用 (32条) =====

export const CITATION_REQUIREMENTS = [
  '公表された著作物であること',
  '公正な慣行に合致 (報道・批評・研究等の正当目的)',
  '引用の目的上、必要最小限であること',
  '引用部分が明瞭に区別されること (カギ括弧/インデント等)',
  '引用部分は従、自分の著作物が主 (主従関係)',
  '出所明示 (著者・タイトル・出典)',
] as const;

export function isProperCitation(p: {
  isPublished: boolean;
  hasJustifiedPurpose: boolean;
  isMinimumNecessary: boolean;
  isClearlyDistinguished: boolean;
  isMainSubServingRelation: boolean;
  hasSourceAttribution: boolean;
}): { ok: boolean; failed: string[] } {
  const f: string[] = [];
  if (!p.isPublished) f.push('未公表著作物は引用不可');
  if (!p.hasJustifiedPurpose) f.push('正当目的 (報道/批評/研究等) なし');
  if (!p.isMinimumNecessary) f.push('引用範囲が必要最小限を超える');
  if (!p.isClearlyDistinguished) f.push('引用部分の明瞭区別が不十分');
  if (!p.isMainSubServingRelation) f.push('主従関係なし (引用が中心)');
  if (!p.hasSourceAttribution) f.push('出所明示 (著者/出典) なし');
  return { ok: f.length === 0, failed: f };
}

// ===== JASRAC / NexTone 使用料 =====

export type JasracUsageKind =
  | 'cafe_bgm_under_500_seats'
  | 'restaurant_bgm_under_500_seats'
  | 'live_concert_paid_under_500'
  | 'youtube_business_channel'
  | 'website_bgm_pageview_low'
  | 'karaoke_box_per_room'
  | 'wedding_party_per_use';

/**
 * 包括契約の参考使用料 (年額/月額/回当たり、2024 概算)。
 * 実額は JASRAC / NexTone 公式表を参照すること。
 */
export const JASRAC_USAGE_FEES: Record<JasracUsageKind, { unit: string; baseFeeJpy: number }> = {
  cafe_bgm_under_500_seats: { unit: '年額', baseFeeJpy: 6000 },
  restaurant_bgm_under_500_seats: { unit: '年額', baseFeeJpy: 6000 },
  live_concert_paid_under_500: { unit: '1回', baseFeeJpy: 5000 },
  youtube_business_channel: { unit: '月額', baseFeeJpy: 5000 },
  website_bgm_pageview_low: { unit: '月額', baseFeeJpy: 500 },
  karaoke_box_per_room: { unit: '月額', baseFeeJpy: 1900 },
  wedding_party_per_use: { unit: '1組', baseFeeJpy: 1500 },
};

export function calcJasracFee(p: {
  usageKind: JasracUsageKind;
  units: number;
}): number {
  const def = JASRAC_USAGE_FEES[p.usageKind];
  return def.baseFeeJpy * p.units;
}

// ===== 放送法 =====

export type BroadcastLicenseKind =
  | 'NHK'
  | 'commercial_terrestrial' // 民放地上波
  | 'commercial_bs' // 民放BS
  | 'commercial_cs' // 民放CS
  | 'cable_tv'
  | 'community_fm'
  | 'internet_simulcast' // 同時配信 (放送法対象外、一部適用)
  | 'youtube_only'; // 放送ではない (放送法対象外)

export const BROADCAST_LICENSES: Record<BroadcastLicenseKind, { needsLicense: boolean; basis: string }> = {
  NHK: { needsLicense: true, basis: '放送法 第6条 特殊法人' },
  commercial_terrestrial: { needsLicense: true, basis: '電波法 第4条 / 放送法 第93条' },
  commercial_bs: { needsLicense: true, basis: '電波法 / 放送法 (基幹放送)' },
  commercial_cs: { needsLicense: true, basis: '電波法 / 放送法 (一般放送)' },
  cable_tv: { needsLicense: true, basis: '有線テレビジョン放送法 → 放送法統合 (登録制)' },
  community_fm: { needsLicense: true, basis: '電波法 (コミュニティ放送局)' },
  internet_simulcast: { needsLicense: false, basis: '同時配信は通信扱いだが番組編集準則は適用範囲議論あり' },
  youtube_only: { needsLicense: false, basis: '放送ではない (通信)' },
};

export function requiresBroadcastLicense(kind: BroadcastLicenseKind): boolean {
  return BROADCAST_LICENSES[kind].needsLicense;
}

// ===== ステマ規制 (景表法 R5.10 施行) との連携 — PR ラベル =====

export const PR_LABEL_RULES = [
  '広告・宣伝主体が事業者であることを消費者が判別困難な場合は表示必須',
  '#PR / #広告 / 「[広告]」等、明瞭に伝達する表記を冒頭付近に',
  '小さい文字・薄い色・他のハッシュタグに紛れる表記は不可',
  '動画は冒頭で口頭+テロップ表示が望ましい',
  'インフルエンサーへの提供品・金銭・無料招待は全て対象',
] as const;

export interface SponsoredPostMeta {
  hasMonetaryCompensation: boolean;
  hasFreeProductSupply: boolean;
  isFromAdvertiser: boolean;
  prLabelText?: string;
  prLabelPosition: 'beginning' | 'middle' | 'end' | 'none';
  prLabelStyle: 'prominent' | 'small_color_blend' | 'inside_other_hashtags';
}

export function needsPrLabel(p: SponsoredPostMeta): { required: boolean; complianceIssues: string[] } {
  const required = p.hasMonetaryCompensation || p.hasFreeProductSupply || p.isFromAdvertiser;
  const issues: string[] = [];
  if (!required) return { required: false, complianceIssues: [] };
  if (!p.prLabelText) issues.push('PRラベル未表記');
  if (p.prLabelPosition !== 'beginning') issues.push('PRラベルは冒頭付近で表記');
  if (p.prLabelStyle !== 'prominent') issues.push('PRラベルが視認困難 (色/サイズ/紛れ)');
  return { required, complianceIssues: issues };
}

// ===== クリエイティブ・コモンズ =====

export type CcLicense = 'CC0' | 'CC-BY' | 'CC-BY-SA' | 'CC-BY-NC' | 'CC-BY-NC-SA' | 'CC-BY-ND' | 'CC-BY-NC-ND';

export const CC_LICENSES: Record<CcLicense, {
  attribution: boolean;
  shareAlike: boolean;
  noncommercial: boolean;
  noDerivatives: boolean;
  summary: string;
}> = {
  'CC0': { attribution: false, shareAlike: false, noncommercial: false, noDerivatives: false, summary: 'パブリックドメインに準ずる (権利放棄)' },
  'CC-BY': { attribution: true, shareAlike: false, noncommercial: false, noDerivatives: false, summary: 'クレジット表示で自由利用' },
  'CC-BY-SA': { attribution: true, shareAlike: true, noncommercial: false, noDerivatives: false, summary: 'クレジット+派生物も同条件で公開' },
  'CC-BY-NC': { attribution: true, shareAlike: false, noncommercial: true, noDerivatives: false, summary: 'クレジット+非営利のみ' },
  'CC-BY-NC-SA': { attribution: true, shareAlike: true, noncommercial: true, noDerivatives: false, summary: 'クレジット+非営利+同条件' },
  'CC-BY-ND': { attribution: true, shareAlike: false, noncommercial: false, noDerivatives: true, summary: 'クレジット+改変禁止' },
  'CC-BY-NC-ND': { attribution: true, shareAlike: false, noncommercial: true, noDerivatives: true, summary: 'クレジット+非営利+改変禁止' },
};

export function explainCCLicense(l: CcLicense): string {
  const d = CC_LICENSES[l];
  return `${l}: ${d.summary}`;
}

// ===== 出版権 (R26 / 79条 -) =====

export type PublishingRightKind = 'paper_only' | 'digital_only' | 'integrated';

export const PUBLISHING_RIGHT_TYPES: Record<PublishingRightKind, string> = {
  paper_only: '紙の出版権 (79条1項)',
  digital_only: '電子出版権 (79条2項) — H26改正',
  integrated: '紙+電子 統合出版権',
};

export interface PublishingRightSetup {
  workTitle: string;
  authorName: string;
  publisherName: string;
  kind: PublishingRightKind;
  /** 出版権存続期間 (年) — 設定なきときは設定後3年 (83条) */
  durationYears?: number;
  /** 6ヶ月以内に出版する義務 (81条) */
  publishWithinMonths: number;
}

export function setupPublishingRight(p: PublishingRightSetup): {
  ok: boolean;
  warnings: string[];
  effectiveDurationYears: number;
} {
  const warnings: string[] = [];
  if (p.publishWithinMonths > 6) warnings.push('原則6ヶ月以内の出版義務 (81条) に違反');
  const dur = p.durationYears ?? 3;
  if (dur > 30) warnings.push('出版権の長期独占はリスク (取消/再出版条項要検討)');
  return { ok: warnings.length === 0, warnings, effectiveDurationYears: dur };
}
