/**
 * energy.ts — Phase 23 エネルギー
 *
 * カバレッジ:
 *   - FIT/FIP (再エネ特措法): 調達価格・FIP プレミアム計算
 *   - RE100 / SBT / TCFD 適合
 *   - J-クレジット (吸収/削減プロジェクト)
 *   - 省エネ法 (エネルギー使用合理化法 / 特定事業者 1,500kL/年)
 *   - 温対法 (温室効果ガス排出量算定・報告・公表制度 / SHK 制度)
 *   - 高度化法 (非化石電源比率 44% 2030)
 *   - カーボンプライシング (GX-ETS / 排出量取引)
 *   - 電気事業法 (一般送配電/小売電気事業者/発電事業者 区分)
 *
 * 主要 export:
 *   - FIT_PRICES_2024 / calcFitRevenue
 *   - FIP_REFERENCE_PRICES_2024 / calcFipPremium
 *   - SBT_TARGET_TYPES / isSbtEligible
 *   - JCREDIT_METHODOLOGIES / calcJCreditEmissionReduction
 *   - SHOENE_LAW_THRESHOLDS / isShoeneSpecifiedBusiness / requireSHKReport
 *   - SHK_EMISSION_FACTORS / calcCo2EmissionsTonnes
 *   - GX_ETS_PHASES / estimateCarbonCost
 *   - ELECTRICITY_BUSINESS_KINDS / classifyElectricityBusiness
 */

// ===== FIT (Feed-in Tariff) =====

export type FitCategory =
  | 'solar_residential_10kw_under'
  | 'solar_business_10_50kw'
  | 'solar_business_50_250kw'
  | 'wind_onshore_under_50kw'
  | 'wind_onshore_50kw_over'
  | 'wind_offshore'
  | 'hydro_under_200kw'
  | 'hydro_200_1000kw'
  | 'biomass_woody_under_2000kw'
  | 'geothermal_under_15000kw';

/**
 * 2024年度 FIT 調達価格 (円/kWh)。経産省告示準拠の参考値。
 * 実運用では年度更新を必ず確認すること。
 */
export const FIT_PRICES_2024: Record<FitCategory, number> = {
  solar_residential_10kw_under: 16, // 10年間
  solar_business_10_50kw: 10,
  solar_business_50_250kw: 9.2,
  wind_onshore_under_50kw: 19, // 20年間
  wind_onshore_50kw_over: 17, // 入札制
  wind_offshore: 18, // 着床式入札
  hydro_under_200kw: 34,
  hydro_200_1000kw: 29,
  biomass_woody_under_2000kw: 40, // 未利用材
  geothermal_under_15000kw: 40,
};

export const FIT_PROCUREMENT_PERIOD_YEARS: Record<FitCategory, number> = {
  solar_residential_10kw_under: 10,
  solar_business_10_50kw: 20,
  solar_business_50_250kw: 20,
  wind_onshore_under_50kw: 20,
  wind_onshore_50kw_over: 20,
  wind_offshore: 20,
  hydro_under_200kw: 20,
  hydro_200_1000kw: 20,
  biomass_woody_under_2000kw: 20,
  geothermal_under_15000kw: 15,
};

/** 単純な FIT 売電収入計算 (税抜) */
export function calcFitRevenue(p: {
  category: FitCategory;
  generatedKwh: number;
}): { revenueJpy: number; periodYears: number } {
  const price = FIT_PRICES_2024[p.category];
  const periodYears = FIT_PROCUREMENT_PERIOD_YEARS[p.category];
  return { revenueJpy: Math.floor(p.generatedKwh * price), periodYears };
}

// ===== FIP (Feed-in Premium) =====

/**
 * FIP 基準価格 (参考値 2024)。
 * プレミアム = 基準価格 - 参照価格 (市場連動)。
 */
export const FIP_REFERENCE_PRICES_2024: Partial<Record<FitCategory, number>> = {
  solar_business_50_250kw: 9.2,
  wind_onshore_50kw_over: 14.0,
  wind_offshore: 11.99, // 入札落札例
  biomass_woody_under_2000kw: 27,
};

export function calcFipPremium(p: {
  category: FitCategory;
  marketPriceYenPerKwh: number;
  generatedKwh: number;
}): { premiumYenPerKwh: number; totalPremiumJpy: number } {
  const ref = FIP_REFERENCE_PRICES_2024[p.category];
  if (ref === undefined) {
    return { premiumYenPerKwh: 0, totalPremiumJpy: 0 };
  }
  // FIP プレミアムは原則 max(基準 - 参照, 0)
  const premiumPerKwh = Math.max(ref - p.marketPriceYenPerKwh, 0);
  return {
    premiumYenPerKwh: premiumPerKwh,
    totalPremiumJpy: Math.floor(premiumPerKwh * p.generatedKwh),
  };
}

// ===== SBT (Science Based Targets) / RE100 / TCFD =====

export type SbtTargetType = 'NearTerm' | 'NetZero' | 'SBTi_FLAG';

export const SBT_TARGET_TYPES: Record<SbtTargetType, string> = {
  NearTerm: '5-10年でScope1+2 を 1.5℃整合 (年4.2%減 等)',
  NetZero: '2050年までに Scope1+2+3 を 90%以上削減 + 残余を除去',
  SBTi_FLAG: 'Forest, Land, Agriculture セクター向け追加要件',
};

export interface SbtSubmission {
  baselineYear: number;
  targetYear: number;
  scope1ReductionPct: number;
  scope2ReductionPct: number;
  scope3ReductionPct?: number;
  /** Scope3 が排出全体の 40% 超なら Scope3 目標必須 */
  scope3SharePct: number;
}

export function isSbtEligible(s: SbtSubmission): { eligible: boolean; reasons: string[] } {
  const r: string[] = [];
  const yearGap = s.targetYear - s.baselineYear;
  if (yearGap < 5 || yearGap > 10) r.push('近期目標は基準年から5-10年');
  // 1.5℃整合: 年 4.2% 直線減 → 5年で約 21%
  const requiredMin = yearGap * 4.2;
  if (s.scope1ReductionPct < requiredMin || s.scope2ReductionPct < requiredMin)
    r.push(`Scope1/2 削減率が1.5℃整合に不足 (要 ${requiredMin.toFixed(1)}%以上)`);
  if (s.scope3SharePct >= 40 && (s.scope3ReductionPct ?? 0) <= 0)
    r.push('Scope3 排出が40%超のためScope3目標必須');
  return { eligible: r.length === 0, reasons: r };
}

// ===== J-クレジット =====

export type JCreditMethodology =
  | 'EN-S-001' // 太陽光発電
  | 'EN-S-016' // バイオマス熱利用
  | 'FO-001' // 森林経営活動
  | 'AG-001' // 茶園における中切り更新
  | 'WA-001' // 廃棄物の埋立処分量削減
  ;

export const JCREDIT_METHODOLOGIES: Record<JCreditMethodology, { kind: 'reduction' | 'absorption'; label: string }> = {
  'EN-S-001': { kind: 'reduction', label: '太陽光発電による系統電力代替' },
  'EN-S-016': { kind: 'reduction', label: 'バイオマス熱利用 (チップ/ペレット等)' },
  'FO-001': { kind: 'absorption', label: '森林経営活動による吸収量' },
  'AG-001': { kind: 'reduction', label: '茶園中切り更新によるN2O削減' },
  'WA-001': { kind: 'reduction', label: '廃棄物の埋立処分量削減' },
};

/** ベースライン排出 - プロジェクト排出 = 削減量 (t-CO2) */
export function calcJCreditEmissionReduction(p: {
  methodology: JCreditMethodology;
  baselineEmissionTCo2: number;
  projectEmissionTCo2: number;
}): { reductionTCo2: number; fee?: number } {
  const reduction = Math.max(p.baselineEmissionTCo2 - p.projectEmissionTCo2, 0);
  // 認証手数料: 削減量 × 数百円相当 (公募/制度で変動) — 試算値として 500 円/t
  return { reductionTCo2: reduction, fee: reduction * 500 };
}

// ===== 省エネ法 (エネルギー使用合理化法) =====

export const SHOENE_LAW_THRESHOLDS = {
  /** 特定事業者: 全社のエネルギー使用量が 1,500 kL (原油換算) 以上 */
  specifiedBusinessKl: 1500,
  /** 特定連鎖化事業者: フランチャイズ加盟店合算で 1,500 kL 以上 */
  specifiedChainKl: 1500,
  /** 中長期計画書の年率改善目標 */
  annualImprovementPct: 1.0,
} as const;

export function isShoeneSpecifiedBusiness(annualEnergyUseKl: number): boolean {
  return annualEnergyUseKl >= SHOENE_LAW_THRESHOLDS.specifiedBusinessKl;
}

// ===== 温対法 SHK 制度 (温室効果ガス算定・報告・公表) =====

export const SHK_EMISSION_FACTORS = {
  /** 電力 kWh あたり t-CO2 (全国平均係数 2022年度実績ベース 0.434 kg-CO2/kWh) */
  electricity_kwh_kgco2: 0.434,
  /** 都市ガス Nm3 あたり kg-CO2 (13A 約 2.234) */
  city_gas_nm3_kgco2: 2.234,
  /** 軽油 L あたり kg-CO2 */
  diesel_l_kgco2: 2.62,
  /** ガソリン L あたり kg-CO2 */
  gasoline_l_kgco2: 2.32,
  /** 灯油 L あたり kg-CO2 */
  kerosene_l_kgco2: 2.49,
  /** A 重油 L あたり kg-CO2 */
  heavy_oil_a_l_kgco2: 2.71,
  /** LPG kg あたり kg-CO2 (約 3.0) */
  lpg_kg_kgco2: 3.0,
} as const;

export interface EnergyConsumption {
  electricityKwh?: number;
  cityGasNm3?: number;
  dieselL?: number;
  gasolineL?: number;
  keroseneL?: number;
  heavyOilAL?: number;
  lpgKg?: number;
}

/** Scope1 + Scope2 (場所基準) の年間排出量を t-CO2 で返す。Scope2 マーケット基準は契約電源係数で別途。 */
export function calcCo2EmissionsTonnes(c: EnergyConsumption): number {
  let kg = 0;
  kg += (c.electricityKwh ?? 0) * SHK_EMISSION_FACTORS.electricity_kwh_kgco2;
  kg += (c.cityGasNm3 ?? 0) * SHK_EMISSION_FACTORS.city_gas_nm3_kgco2;
  kg += (c.dieselL ?? 0) * SHK_EMISSION_FACTORS.diesel_l_kgco2;
  kg += (c.gasolineL ?? 0) * SHK_EMISSION_FACTORS.gasoline_l_kgco2;
  kg += (c.keroseneL ?? 0) * SHK_EMISSION_FACTORS.kerosene_l_kgco2;
  kg += (c.heavyOilAL ?? 0) * SHK_EMISSION_FACTORS.heavy_oil_a_l_kgco2;
  kg += (c.lpgKg ?? 0) * SHK_EMISSION_FACTORS.lpg_kg_kgco2;
  return kg / 1000; // → t-CO2
}

/** SHK 報告対象: エネルギー起源 CO2 で 3,000 t-CO2/年 以上 */
export function requireSHKReport(annualCo2T: number): boolean {
  return annualCo2T >= 3000;
}

// ===== GX-ETS (排出量取引) =====

export const GX_ETS_PHASES = {
  /** 2023-2025: 試行 (任意参加・自主目標) */
  phase1: { fromYear: 2023, toYear: 2025, mandatory: false },
  /** 2026-: 本格稼働 (排出枠割当) — 制度設計中 */
  phase2: { fromYear: 2026, toYear: 2032, mandatory: true },
  /** 2033-: 発電事業者への有償オークション */
  phase3: { fromYear: 2033, toYear: 9999, mandatory: true },
} as const;

export function estimateCarbonCost(p: {
  emissionsTCo2: number;
  /** カーボンプライス (円/t-CO2) — 試行段階目安 1,500-3,000 */
  pricePerTCo2: number;
}): number {
  return Math.floor(p.emissionsTCo2 * p.pricePerTCo2);
}

// ===== 電気事業法 =====

export type ElectricityBusinessKind =
  | 'general_transmission_distribution'
  | 'retail_electricity'
  | 'power_generation'
  | 'specified_transmission'
  | 'specified_supply';

export const ELECTRICITY_BUSINESS_KINDS: Record<ElectricityBusinessKind, string> = {
  general_transmission_distribution: '一般送配電事業者 (10エリア+OCCTO接続)',
  retail_electricity: '小売電気事業者 (登録制)',
  power_generation: '発電事業者 (届出制 1万kW以上)',
  specified_transmission: '特定送配電事業者 (限定エリア配電)',
  specified_supply: '特定供給 (自家発電→グループ会社供給)',
};

export interface ElectricityBusinessProfile {
  hasRetailContracts: boolean;
  generationCapacityKw: number;
  ownsTransmissionLines: boolean;
  isAreaWide: boolean;
}

export function classifyElectricityBusiness(p: ElectricityBusinessProfile): ElectricityBusinessKind[] {
  const k: ElectricityBusinessKind[] = [];
  if (p.hasRetailContracts) k.push('retail_electricity');
  if (p.generationCapacityKw >= 10_000) k.push('power_generation');
  if (p.ownsTransmissionLines && p.isAreaWide) k.push('general_transmission_distribution');
  if (p.ownsTransmissionLines && !p.isAreaWide) k.push('specified_transmission');
  return k;
}

/** 高度化法: 小売電気事業者は 2030 年までに販売電力量の 44% 以上を非化石電源化 */
export const KODOKA_LAW_2030_NONFOSSIL_PCT = 44;
export function checkKodokaCompliance(nonFossilSharePct: number): boolean {
  return nonFossilSharePct >= KODOKA_LAW_2030_NONFOSSIL_PCT;
}
