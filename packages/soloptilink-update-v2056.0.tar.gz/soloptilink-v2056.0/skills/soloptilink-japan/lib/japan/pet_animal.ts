/**
 * lib/japan/pet_animal.ts — ペット・動物業DNA
 *
 * 法令カバレッジ:
 *  - 動物の愛護及び管理に関する法律 (動物愛護法 S48法律105 / R元改正)
 *  - 動物愛護法施行規則 (R元改正 — 飼養基準 + マイクロチップ義務化)
 *  - 第一種動物取扱業 (販売/保管/貸出/訓練/展示/競りあっせん/譲受飼養)
 *  - 第二種動物取扱業 (非営利10頭以上 — 動物愛護団体等)
 *  - 動物の遺棄・虐待罪 (44条) — 1年以下/100万円以下
 *  - マイクロチップ装着 義務化 R4.6施行
 *  - 特定動物 (人の生命・身体・財産に害を加える動物) — 飼育原則禁止
 *  - 狂犬病予防法 (S25法律247)
 *  - 家畜伝染病予防法 (S26法律166)
 *
 * 参考: 環境省自然環境局, 各都道府県 動物愛護センター, 公益社団法人日本獣医師会
 */

// ============================================================================
// 1. 第一種動物取扱業の業種 (動物愛護法10条)
// ============================================================================

export type AnimalHandlerCategory =
  | 'sale' // 販売
  | 'keeping' // 保管 (ペットホテル / トリミング)
  | 'rental' // 貸出 (撮影用 等)
  | 'training' // 訓練 (しつけ / ペット訓練所)
  | 'display' // 展示 (動物園 / ふれあい広場)
  | 'auction_mediation' // 競りあっせん
  | 'transfer_keeping'; // 譲受飼養 (老犬ホーム 等)

export const FIRST_KIND_HANDLER_CATEGORIES = {
  sale: { ja: '販売', validity_y: 5 },
  keeping: { ja: '保管 (ペットホテル/トリミング)', validity_y: 5 },
  rental: { ja: '貸出', validity_y: 5 },
  training: { ja: '訓練', validity_y: 5 },
  display: { ja: '展示', validity_y: 5 },
  auction_mediation: { ja: '競りあっせん', validity_y: 5 },
  transfer_keeping: { ja: '譲受飼養', validity_y: 5 },
} as const;

// ============================================================================
// 2. 第一種動物取扱業の登録要件 (10条 + 12条)
// ============================================================================

export interface FirstKindHandlerApplication {
  category: AnimalHandlerCategory;
  hasResponsibleManager: boolean; // 動物取扱責任者
  responsibleManagerExperienceYears: number; // 動物の販売/保管/貸出/訓練/展示等の実務経験
  hasFacility: boolean; // 飼育施設 (適切な広さ + 衛生 + 温度管理)
  hasInsurance: boolean; // 賠償責任保険 (推奨)
  hasNoCriminalRecord5y: boolean; // 動物愛護法違反/罰金以上 5年以内なし
}

/**
 * 動物取扱責任者の要件 (規則3条 — R元改正で厳格化):
 *   1) 半年以上の実務経験 + 教育機関卒業 / 公的資格保有
 *   2) または1年以上の実務経験 + 公的資格 (愛玩動物飼養管理士1級 等)
 */
export function evaluateResponsibleManagerEligibility(input: {
  experienceMonths: number;
  hasGraduateDegree: boolean; // 動物関連の教育機関卒業
  hasPublicQualification: boolean; // 愛玩動物飼養管理士1級 / 愛玩動物看護師 等
}): { eligible: boolean; reason: string } {
  if (input.experienceMonths >= 6 && (input.hasGraduateDegree || input.hasPublicQualification)) {
    return { eligible: true, reason: '半年以上の実務 + 教育/公的資格 (規則3条1項)' };
  }
  if (input.experienceMonths >= 12 && input.hasPublicQualification) {
    return { eligible: true, reason: '1年以上の実務 + 公的資格 (規則3条2項)' };
  }
  return { eligible: false, reason: '実務経験 + 教育/資格の組合せが不十分 — R元改正で厳格化' };
}

/** 第一種動物取扱業 登録の事前チェック */
export function evaluateFirstKindRegistration(a: FirstKindHandlerApplication): {
  registerable: boolean;
  blockers: string[];
} {
  const blockers: string[] = [];
  if (!a.hasResponsibleManager) blockers.push('動物取扱責任者の選任必須 (法10条+規則8条)');
  if (a.responsibleManagerExperienceYears < 0.5) {
    blockers.push('責任者は半年以上の実務経験 (R元改正で厳格化)');
  }
  if (!a.hasFacility) blockers.push('適切な飼育施設 (規則8条 — 衛生/温度/騒音/逸走防止)');
  if (!a.hasNoCriminalRecord5y) blockers.push('動物愛護法違反等で罰金以上 5年以内 — 欠格事由');
  return { registerable: blockers.length === 0, blockers };
}

// ============================================================================
// 3. 飼養基準 (R元改正 規則8条 — 数値規制)
// ============================================================================

/** ケージ最低面積 / 高さ — 犬種別 (規則別表 R元改正) */
export function getMinimumKennelDimensions(input: {
  animalKind: 'dog' | 'cat';
  bodyLengthCm?: number;
  weightKg?: number;
}): { widthCm: number; depthCm: number; heightCm: number; reason: string } {
  if (input.animalKind === 'dog') {
    const len = input.bodyLengthCm ?? 50;
    return {
      widthCm: len * 2,
      depthCm: len * 1.5,
      heightCm: len * 2,
      reason: '犬: 体長×2 (幅), 体長×1.5 (奥行), 体長×2 (高さ) — 規則別表',
    };
  }
  const len = input.bodyLengthCm ?? 30;
  return {
    widthCm: len * 2,
    depthCm: len * 1.5,
    heightCm: len * 3, // 猫は登坂用に高さ要
    reason: '猫: 体長×2 (幅), 体長×1.5 (奥行), 体長×3 (高さ — 棚段必須)',
  };
}

/** 従業員1人あたり 飼養頭数上限 (R元改正 — 段階施行 R6完了) */
export function getMaxAnimalsPerWorker(input: {
  animalKind: 'dog' | 'cat';
  forBreeding: boolean;
}): { maxCount: number; reason: string } {
  if (input.animalKind === 'dog') {
    return input.forBreeding
      ? { maxCount: 15, reason: '繁殖犬: 1人 15頭以下 (R6.6完了)' }
      : { maxCount: 20, reason: '販売犬: 1人 20頭以下 (R6.6完了)' };
  }
  return input.forBreeding
    ? { maxCount: 25, reason: '繁殖猫: 1人 25頭以下' }
    : { maxCount: 30, reason: '販売猫: 1人 30頭以下' };
}

// ============================================================================
// 4. マイクロチップ装着 (R4.6施行)
// ============================================================================

/** マイクロチップ装着義務 + 環境省データベース登録 */
export function evaluateMicrochipObligation(input: {
  animalKind: 'dog' | 'cat' | 'other';
  isOwnerBusiness: boolean; // 第一種動物取扱業者 = 義務 / 個人 = 努力義務
  acquiredAfter2022Jun: boolean;
}): { obligated: boolean; mustRegister: boolean; deadline: string } {
  // 業者は義務、個人は努力義務 (ただし業者から購入した場合は変更登録義務)
  if (input.animalKind === 'other') {
    return { obligated: false, mustRegister: false, deadline: '対象外 (犬/猫のみ)' };
  }
  if (input.isOwnerBusiness && input.acquiredAfter2022Jun) {
    return {
      obligated: true,
      mustRegister: true,
      deadline: '販売時までにマイクロチップ装着 + 環境省指定登録機関へ情報登録',
    };
  }
  return {
    obligated: false,
    mustRegister: input.acquiredAfter2022Jun,
    deadline: '個人は努力義務 — ただし業者から取得時は所有者変更30日以内に変更登録義務',
  };
}

// ============================================================================
// 5. 特定動物 (法25条の2) — 原則飼育禁止
// ============================================================================

/** 特定動物 主要例 (政令 — 約650種) */
export const SPECIFIED_ANIMALS_EXAMPLES = [
  'ライオン', 'トラ', 'ヒョウ', 'ジャガー', 'チーター',
  'クマ (ヒグマ/ツキノワグマ等)', 'ゾウ', 'カバ', 'サイ',
  'ワニ (1m以上)', 'ニシキヘビ (3m以上)', 'コブラ', 'マムシ',
  '猛禽類 (ハクトウワシ等)', '大型猿類 (ゴリラ/オランウータン)',
] as const;

/** 特定動物の飼育判定 (R2.6改正で愛玩目的の新規飼育は原則禁止) */
export function checkSpecifiedAnimalKeeping(input: {
  speciesName: string;
  purpose: 'business' | 'research' | 'pet' | 'zoo';
  hasPriorPermit?: boolean;
}): { allowed: boolean; reason: string } {
  if (input.purpose === 'pet') {
    return { allowed: false, reason: 'R2.6改正 — 愛玩目的の特定動物の新規飼育は禁止' };
  }
  if (!input.hasPriorPermit) {
    return { allowed: false, reason: '都道府県知事の許可が必要 (法25条の2)' };
  }
  return {
    allowed: true,
    reason: '事業/研究/動物園 + 知事許可済 + 飼育施設基準適合 — 5年ごと更新',
  };
}

// ============================================================================
// 6. 狂犬病予防法 (S25法律247)
// ============================================================================

/** 犬の登録 + 狂犬病予防注射 義務 (狂犬病予防法4条/5条) */
export function checkRabiesObligation(input: {
  hasMunicipalRegistration: boolean;
  vaccinationDate?: Date;
  todayDate: Date;
}): { compliant: boolean; gaps: string[] } {
  const gaps: string[] = [];
  if (!input.hasMunicipalRegistration) gaps.push('市町村への犬の登録 (取得30日以内/生後91日以上)');
  if (!input.vaccinationDate) {
    gaps.push('狂犬病予防注射未接種 — 年1回 (4-6月) 義務');
  } else {
    const ms = input.todayDate.getTime() - input.vaccinationDate.getTime();
    if (ms > 365 * 86400000) gaps.push('狂犬病予防注射 1年経過 — 再接種必要');
  }
  return { compliant: gaps.length === 0, gaps };
}

// ============================================================================
// 7. 動物虐待 / 遺棄罪 (動物愛護法44条)
// ============================================================================

export type AbuseSeverity = 'mild' | 'serious' | 'death';

/** 罰則判定 (44条 — R元改正で厳罰化) */
export function classifyAnimalAbusePenalty(severity: AbuseSeverity): {
  penalty: string;
  article: string;
} {
  if (severity === 'death') {
    return {
      penalty: '5年以下の懲役 or 500万円以下の罰金',
      article: '動物愛護法44条1項 (殺傷)',
    };
  }
  if (severity === 'serious') {
    return {
      penalty: '1年以下の懲役 or 100万円以下の罰金',
      article: '動物愛護法44条2項 (虐待)',
    };
  }
  return {
    penalty: '100万円以下の罰金 (遺棄)',
    article: '動物愛護法44条3項',
  };
}
