/**
 * governance_hub_xphase.ts — Cross-Phase Governance Hub (Phase 46-CC Centurion)
 *
 * Phase 1-44 (soloptilink-japan 既存) + Phase 45 (並行Sessionが追加) + v2036.0 Enterprise Compliance Auto-Audit
 * (J-SOX/SOC2/ISMS/Pマーク/ISMAP) を **横串で統合採点** する Centurion Hub。
 *
 * Claude Code が構造的に到達できない領域:
 *   - 8軸 (J-SOX 12 + SOC2 15 + ISMS 10 + Pマーク 11 + ISMAP 11 + JP固有20) を一画面で経営層向けKPIに変換
 *   - Phase 別スコアの加重平均 (重み付け is configurable per regulator profile)
 *   - "ガバナンス充足率" を SSBJ 基準書 D1/D2 開示要件にマッピング
 *
 * 参照: ~/.soloptilink/lib/compliance-audit/ (v2036.0 既存実装) - 読み取りのみ
 *
 * Author: Session J-INTEGRATE / v2037.0 Governance Centurion
 * License: 配布対象 (顧客環境で動作)
 */

export type RegulatorProfile = 'listed' | 'financial' | 'medical' | 'public' | 'sme' | 'startup';

/** 測定状態。unmeasurable = 測定手段が無く実測できていない (合格でも不合格でもない) */
export type GovernanceMeasurement = 'measured' | 'partial' | 'unmeasurable';

export interface PhaseScore {
  phase: string;            // "phase1" | "phase45-jpgov" | "v2036-jsox" 等
  category: 'foundation' | 'industry' | 'governance' | 'security' | 'finance' | 'integration';
  score: number;            // 0..100 標準化済 (★実測できた Phase のみ生成すること)
  axes: number;             // 軸数 (例: J-SOX = 12)
  passed: number;           // PASS した軸数
  weight: number;           // プロファイル別重み 0..1
  laws: string[];           // 関連法令
  source: 'phase' | 'fortress' | 'compliance' | 'centurion';
  evidence?: string[];      // 根拠ファイルパス (監査用)
}

/**
 * 「採点対象として宣言されているが、実測はできていない」Phase。
 * 軸数や関連法令は定義値であって測定結果ではない (ここに score/passed を持たせない)。
 */
export interface DeclaredPhaseScope {
  phase: string;
  category: PhaseScore['category'];
  /** 宣言された軸数 (定義値。PASS 数ではない) */
  axes_declared: number;
  laws: string[];
  source: PhaseScore['source'];
  evidence?: string[];
  /** 実測できていない理由 (日本語) */
  unmeasurable_reason: string;
}

/** ガバナンス評価が実測不能なときに投げる (架空の数値で判定を出さないための門) */
export class GovernanceUnmeasurableError extends Error {
  constructor(public readonly report: CenturionMeasurementReport) {
    super(
      `ガバナンス集計を算出できません: ${report.reason_ja} ` +
      `(実測できた軸 ${report.measured_axes} / 宣言軸 ${report.declared_axes}。` +
      `断定しない結果が必要な場合は evaluateCenturion() を使ってください)`,
    );
    this.name = 'GovernanceUnmeasurableError';
  }
}

/**
 * ガバナンス評価の測定レポート。
 * 実測できた場合のみ aggregate に集計が入り、実測できなければ null (架空の数値を作らない)。
 */
export interface CenturionMeasurementReport {
  generated_at: string;
  profile: RegulatorProfile;
  measurement: GovernanceMeasurement;
  /** 実測できた軸数 */
  measured_axes: number;
  /** 宣言された軸数 (実測できたことを意味しない) */
  declared_axes: number;
  /** 日本語の一文 (何が無くて測れないかを具体的に書く) */
  reason_ja: string;
  /** 実測できていない Phase の一覧 */
  unmeasured: DeclaredPhaseScope[];
  /** 実測できた Phase のスコア (現状は空) */
  scores: PhaseScore[];
  /** 実測できた場合のみ集計。未測定なら null */
  aggregate: CenturionAggregate | null;
  ssbj_d1_d2_mapping: SsbjMapping;
  cg_code_r6_mapping: CgCodeMapping;
}

export interface CenturionAggregate {
  generated_at: string;
  profile: RegulatorProfile;
  total_axes: number;       // 全軸合計 (Phase 1-44 + Phase 45 + v2036.0 + Phase 46)
  passed_axes: number;
  weighted_score: number;   // 0..100 (プロファイル別重み付け済・★実測値からのみ生成)
  raw_score: number;        // 0..100 (重みなし単純平均)
  /** SSBJ D1/D2 開示要件カバー率 0..100。根拠が無い場合は null (=判定不能) */
  governance_fill_rate: number | null;
  by_category: Record<string, { score: number; axes: number; passed: number }>;
  top_gaps: PhaseScore[];   // スコア低い順 TOP 10 (改善優先)
  ssbj_d1_d2_mapping: SsbjMapping;
  cg_code_r6_mapping: CgCodeMapping;
  jsox_audit_ready: boolean;
}

export interface SsbjMapping {
  // SSBJ (サステナビリティ基準委員会) 適用基準書 D1 / D2 (R8.4.1施行) との対応
  // covered は実査できた項目数。実査していない場合は null (0 とも「不足」とも書かない)
  d1_general: { covered: number | null; total: number; missing: string[]; unverified: string[] }; // 一般開示
  d2_climate: { covered: number | null; total: number; missing: string[]; unverified: string[] }; // 気候関連開示 (TCFD互換)
  /** 開示準備完了か。根拠が無い場合は null = 判定不能 (false=未完了 と区別する) */
  ready_for_disclosure: boolean | null;
  measurement: GovernanceMeasurement;
  /** 判定できない場合の理由 (日本語) */
  reason_ja?: string;
}

export interface CgCodeMapping {
  // コーポレートガバナンス・コード R6 改訂 (PrimeMarket 適用)
  // 'unverified' = 実査していないため comply/explain のいずれとも言えない
  basic_principles: Record<string, 'comply' | 'explain' | 'na' | 'unverified'>; // 5原則
  supplementary: Record<string, 'comply' | 'explain' | 'na' | 'unverified'>;   // 補充原則
  prime_only: Record<string, 'comply' | 'explain' | 'na' | 'unverified'>;      // Prime Market 限定原則
  /** 準拠率 0..100。実査していない場合は null (=判定不能) */
  comply_rate: number | null;
  measurement: GovernanceMeasurement;
  reason_ja?: string;
}

/** Phase 別重み付け - regulator profile によって変わる */
const WEIGHT_MATRIX: Record<RegulatorProfile, Record<string, number>> = {
  listed: {
    foundation: 0.6,
    industry: 0.5,
    governance: 1.0,    // 上場企業は governance 最重要
    security: 0.9,
    finance: 0.95,      // 金商法/J-SOX
    integration: 0.7,
  },
  financial: {
    foundation: 0.7,
    industry: 0.5,
    governance: 0.95,
    security: 1.0,      // 金融機関は security 最重要
    finance: 1.0,       // 金商法/AML
    integration: 0.8,
  },
  medical: {
    foundation: 0.7,
    industry: 1.0,      // 診療報酬等の業界が最重要
    governance: 0.7,
    security: 0.95,     // 3省2GL
    finance: 0.5,
    integration: 0.6,
  },
  public: {
    foundation: 0.8,
    industry: 0.7,
    governance: 0.95,
    security: 1.0,      // ISMAP 最重要
    finance: 0.7,
    integration: 0.7,
  },
  sme: {
    foundation: 0.9,    // 中小企業は基本/業種優先
    industry: 0.95,
    governance: 0.6,
    security: 0.7,
    finance: 0.7,
    integration: 0.5,
  },
  startup: {
    foundation: 0.85,
    industry: 0.8,
    governance: 0.5,
    security: 0.7,
    finance: 0.6,
    integration: 0.4,
  },
};

/** 実測機構が未実装であることの共通理由 (detail に嘘を書かないための単一文言) */
const UNMEASURABLE_REASON =
  '各 Phase / フレームワークが実測結果 (PASS 軸数) を返す仕組みが未実装のため、実測値を取得できていません';

/**
 * 採点対象として **宣言** されている Phase の一覧 (定義であって測定結果ではない)。
 *
 * ★以前はここに 100/95/90/88/85/80 という固定スコアが埋め込まれ、
 *   それが SSBJ 開示準備判定と CG Code 準拠率の唯一の入力になっていた
 *   (=実態と無関係な数値で上場企業がガバナンス報告できてしまう状態)。
 *   実測機構ができるまでは「宣言された対象」と「実測結果」を型で分離し、
 *   スコアは一切生成しない。
 */
export const DECLARED_GOVERNANCE_SCOPE: DeclaredPhaseScope[] = [
  { phase: 'phase1-9-foundation', category: 'foundation', axes_declared: 6, source: 'phase',
    laws: ['民法', '商法', '会社法', '電帳法', 'インボイス', '個情法'], unmeasurable_reason: UNMEASURABLE_REASON },
  { phase: 'phase10-21-industry-core', category: 'industry', axes_declared: 6, source: 'phase',
    laws: ['宅建業法', '旅館業法', '貨物自動車運送事業法', '医療法', '介護保険法'], unmeasurable_reason: UNMEASURABLE_REASON },
  { phase: 'phase22-26-industry-ext', category: 'industry', axes_declared: 5, source: 'phase',
    laws: ['農地法', 'JAS法', 'FIT法', '著作権法', '区分所有法'], unmeasurable_reason: UNMEASURABLE_REASON },
  { phase: 'phase27-31-industry-ultra', category: 'industry', axes_declared: 5, source: 'phase',
    laws: ['森林法', '鉱業法', 'JOC憲章', '文化財保護法', '海上運送法'], unmeasurable_reason: UNMEASURABLE_REASON },
  { phase: 'phase32-41-industry-omni', category: 'industry', axes_declared: 10, source: 'phase',
    laws: ['廃掃法', '警備業法', '道運法', 'リサイクル法', '動物愛護法',
           '美容師法', '風営法', '公衆浴場法', '古物営業法', '労働者派遣法'], unmeasurable_reason: UNMEASURABLE_REASON },
  { phase: 'phase21b-22-governance', category: 'governance', axes_declared: 3, source: 'phase',
    laws: ['公益通報者保護法', 'TCFD', 'AI事業者ガイドライン'], unmeasurable_reason: UNMEASURABLE_REASON },
  { phase: 'phase23-cs-customer', category: 'industry', axes_declared: 3, source: 'phase',
    laws: ['特商法', '景表法', '消費者契約法'], unmeasurable_reason: UNMEASURABLE_REASON },
  { phase: 'phase24-fa-finance', category: 'finance', axes_declared: 3, source: 'phase',
    laws: ['法人税法', '会社法', '日本会計基準'], unmeasurable_reason: UNMEASURABLE_REASON },
  { phase: 'phase32-cs-cybersec', category: 'security', axes_declared: 3, source: 'phase',
    laws: ['不正アクセス禁止法', '個情法第26条', 'サイバーセキュリティ基本法'], unmeasurable_reason: UNMEASURABLE_REASON },
  { phase: 'phase42-hc-healthcare', category: 'industry', axes_declared: 3, source: 'phase',
    laws: ['薬機法', 'GCP省令', '臨床研究法', '次世代医療基盤法'], unmeasurable_reason: UNMEASURABLE_REASON },
  { phase: 'phase43-it-trade', category: 'finance', axes_declared: 3, source: 'phase',
    laws: ['外為法', '関税法', 'Incoterms 2020'], unmeasurable_reason: UNMEASURABLE_REASON },
  { phase: 'phase44-ip-intellectual', category: 'governance', axes_declared: 3, source: 'phase',
    laws: ['特許法', '商標法', '意匠法'], unmeasurable_reason: UNMEASURABLE_REASON },

  { phase: 'phase45-jpgov-J', category: 'governance', axes_declared: 7, source: 'phase',
    laws: ['CG Code R6', '内部統制報告制度', 'AI事業者ガイドライン', '経済安全保障推進法',
           'リース会計ASBJ34', 'サイバーセキュリティ経営ガイド3.0', 'データガバナンス'], unmeasurable_reason: UNMEASURABLE_REASON },
  { phase: 'phase45-49-jpgov-jpgov', category: 'governance', axes_declared: 5, source: 'phase',
    laws: ['犯収法', '金商法R6', 'CG Code R3', 'PPIPA R5', '下請法'], unmeasurable_reason: UNMEASURABLE_REASON },
  { phase: 'phase45-jpgov-G', category: 'governance', axes_declared: 6, source: 'phase',
    laws: ['フリーランス保護法', 'カスハラ防止', 'ステマ規制', 'AI事業者GL', '経安推進法', 'DX認定'], unmeasurable_reason: UNMEASURABLE_REASON },

  // v2036.0 Enterprise Compliance (5フレームワーク 59軸)
  // checker 自体は存在するが、本モジュールから実行して結果を取り込む配線が無い
  { phase: 'v2036-jsox', category: 'governance', axes_declared: 12, source: 'compliance',
    laws: ['会社法', '金商法24条の4の4', 'J-SOX 内部統制報告制度'],
    evidence: ['~/.soloptilink/lib/compliance-audit/frameworks/jsox-checker.mjs'],
    unmeasurable_reason: 'jsox-checker.mjs の実行結果を取り込む配線が無いため、PASS 軸数を実測できていません' },
  { phase: 'v2036-soc2', category: 'security', axes_declared: 15, source: 'compliance',
    laws: ['AICPA TSC 2017'],
    evidence: ['~/.soloptilink/lib/compliance-audit/frameworks/soc2-checker.mjs'],
    unmeasurable_reason: 'soc2-checker.mjs の実行結果を取り込む配線が無いため、PASS 軸数を実測できていません' },
  { phase: 'v2036-isms', category: 'security', axes_declared: 10, source: 'compliance',
    laws: ['ISO/IEC 27001:2022', 'ISO/IEC 27002'],
    evidence: ['~/.soloptilink/lib/compliance-audit/frameworks/isms-checker.mjs'],
    unmeasurable_reason: 'isms-checker.mjs の実行結果を取り込む配線が無いため、PASS 軸数を実測できていません' },
  { phase: 'v2036-pmark', category: 'governance', axes_declared: 11, source: 'compliance',
    laws: ['JIS Q 15001:2017', '個情法'],
    evidence: ['~/.soloptilink/lib/compliance-audit/frameworks/pmark-checker.mjs'],
    unmeasurable_reason: 'pmark-checker.mjs の実行結果を取り込む配線が無いため、PASS 軸数を実測できていません' },
  { phase: 'v2036-ismap', category: 'security', axes_declared: 11, source: 'compliance',
    laws: ['政府情報システムのためのセキュリティ評価制度 ISMAP'],
    evidence: ['~/.soloptilink/lib/compliance-audit/frameworks/ismap-checker.mjs'],
    unmeasurable_reason: 'ismap-checker.mjs の実行結果を取り込む配線が無いため、PASS 軸数を実測できていません' },

  { phase: 'phase46-cc-centurion-cross', category: 'integration', axes_declared: 9, source: 'centurion',
    laws: [],
    evidence: ['lib/japan/governance_hub_xphase.ts', 'lib/japan/audit_as_a_service.ts',
               'lib/japan/law_realtime_tracker.ts', 'lib/japan/learning_data_intelligence.ts',
               'lib/japan/compliance_orchestrator.ts', 'lib/japan/governance_kpi.ts'],
    unmeasurable_reason: UNMEASURABLE_REASON },
];

/** 実測結果の供給元 (実測機構ができたらここに差し込む) */
export type PhaseScoreProvider = (workdir?: string) => Promise<PhaseScore[]> | PhaseScore[];

let phaseScoreProvider: PhaseScoreProvider | null = null;

/**
 * 実測結果の供給元を登録する。
 * 登録されるまで collectPhaseScores() は空を返し、集計は unmeasurable のままになる
 * (=実測できるようになるまで、architecture 上スコアを作れない)。
 */
export function registerPhaseScoreProvider(provider: PhaseScoreProvider | null): void {
  phaseScoreProvider = provider;
}

/**
 * 実測できた Phase スコアを返す。
 *
 * ★実測供給元が未登録なら空配列。各 Phase が実測結果を返す仕組みが未実装のため、
 *   実測していないものを 100/95/90 といった固定値で「採点済み」に見せることをやめた。
 *   宣言された採点対象は DECLARED_GOVERNANCE_SCOPE を、
 *   測定状態を含む結果は evaluateCenturion() を参照すること。
 */
export async function collectPhaseScores(workdir?: string): Promise<PhaseScore[]> {
  if (!phaseScoreProvider) return [];
  const scores = await phaseScoreProvider(workdir);
  return Array.isArray(scores) ? scores : [];
}

/**
 * SSBJ D1/D2 開示要件にマッピング (R8.4.1 上場企業強制適用)
 * D1: 一般要求事項 (8 ガバナンス・戦略・リスク管理・指標目標)
 * D2: 気候関連開示 (TCFD互換 11項目)
 */
function mapToSsbj(scores: PhaseScore[]): SsbjMapping {
  const d1Required = [
    'governance', 'strategy_business_model', 'strategy_risk', 'strategy_metrics',
    'risk_mgmt_process', 'risk_mgmt_integration', 'metrics_targets', 'comparative_period',
  ];
  const d2Required = [
    'climate_governance', 'climate_strategy', 'climate_scenario', 'climate_business_model',
    'climate_risk_mgmt', 'climate_metrics', 'climate_targets', 'climate_scope1', 'climate_scope2',
    'climate_scope3', 'climate_industry_metrics',
  ];

  // 簡易対応: governance category のスコアが SSBJ governance/risk_mgmt をカバー
  // 環境/ESG関連 Phase (esg_carbon, energy) のスコアが climate を満たす
  const govScore = scores.filter(s => s.category === 'governance').reduce((a, b) => a + b.passed, 0);
  const govAxes = scores.filter(s => s.category === 'governance').reduce((a, b) => a + b.axes, 0);

  // ★実測が 1 軸も無い状態で「D1 は7項目カバー済」等と断定しない。
  //   項目単位の実査機構が無いため、比率からの逆算 (旧実装) は根拠にならない。
  if (govAxes === 0) {
    return {
      d1_general: { covered: null, total: d1Required.length, missing: [], unverified: [...d1Required] },
      d2_climate: { covered: null, total: d2Required.length, missing: [], unverified: [...d2Required] },
      ready_for_disclosure: null,
      measurement: 'unmeasurable',
      reason_ja: `SSBJ D1/D2 の項目実査結果が無いため開示準備状況を判定できません (${UNMEASURABLE_REASON})`,
    };
  }

  const govRate = govScore / govAxes;
  const d1Covered = Math.round(d1Required.length * govRate);
  const d2Covered = Math.round(d2Required.length * Math.min(govRate, 0.7)); // 気候は別領域なのでcap

  // ★covered はガバナンス軸の合格率からの【概算】であって、項目単位の実査結果ではない。
  //   したがって個々の項目について「不足している」と断定できる根拠も無いので missing は空にし、
  //   D1/D2 の全項目を unverified (未実査) として返す。
  //   カバー済と数えた項目も実査していない以上、unverified から外してはならない
  //   (外すと「この項目は確認済み」という裏付けの無い主張になる)。
  return {
    d1_general: {
      covered: d1Covered,
      total: d1Required.length,
      missing: [],
      unverified: [...d1Required],
    },
    d2_climate: {
      covered: d2Covered,
      total: d2Required.length,
      missing: [],
      unverified: [...d2Required],
    },
    // ★開示準備の完了は null (判定不能) に倒す。真偽を断定してよいのは
    //   D1/D2 の【項目単位の実査】が入ってからである。
    //   ここでの covered はガバナンス軸の合格率から比率で逆算した概算にすぎず、
    //   ガバナンス3軸を通しただけで「SSBJ 気候関連開示の準備完了」が true になっていた。
    //   有価証券報告書の記載根拠に使われれば虚偽記載に直結するため、概算では true も false も出さない。
    ready_for_disclosure: null,
    // 項目単位の実査ではなくカテゴリ比率からの概算であることを明示する
    measurement: 'partial',
    reason_ja:
      'ガバナンス軸の実測合格率からの概算です (D1/D2 の項目単位の実査ではありません)。' +
      '開示準備の可否は項目単位の実査が入るまで判定できないため ready_for_disclosure は null です',
  };
}

/** CG Code R6 改訂 (Prime Market 適用) との対応 */
function mapToCgCodeR6(scores: PhaseScore[]): CgCodeMapping {
  const govScore = scores.filter(s => s.category === 'governance').reduce((a, b) => a + b.passed, 0);
  const govAxes = scores.filter(s => s.category === 'governance').reduce((a, b) => a + b.axes, 0);

  // ★実測が無いなら comply / explain のどちらとも言えない。全原則を unverified で返す。
  if (govAxes === 0) {
    const unverified = (keys: string[]): Record<string, 'unverified'> =>
      Object.fromEntries(keys.map(k => [k, 'unverified' as const]));
    return {
      basic_principles: unverified([
        'principle_1_shareholder_rights', 'principle_2_stakeholder', 'principle_3_disclosure',
        'principle_4_board', 'principle_5_dialogue',
      ]),
      supplementary: unverified([
        'sup_2_3_1_sustainability', 'sup_3_1_3_climate_disclosure', 'sup_4_2_3_succession',
        'sup_4_8_independent', 'sup_4_10_diversity',
      ]),
      prime_only: unverified([
        'prime_3_1_3_ssbj', 'prime_4_8_one_third_independent', 'prime_4_10_nominating_committee',
      ]),
      comply_rate: null,
      measurement: 'unmeasurable',
      reason_ja: `CG Code 各原則の実査結果が無いため準拠率を算出できません (${UNMEASURABLE_REASON})`,
    };
  }

  const govRate = govScore / govAxes;

  const status = (rate: number): 'comply' | 'explain' | 'na' =>
    rate >= 0.85 ? 'comply' : rate >= 0.6 ? 'explain' : 'na';

  return {
    basic_principles: {
      principle_1_shareholder_rights: status(govRate),
      principle_2_stakeholder: status(govRate * 0.95),
      principle_3_disclosure: status(govRate * 0.9),
      principle_4_board: status(govRate * 0.95),
      principle_5_dialogue: status(govRate * 0.85),
    },
    supplementary: {
      sup_2_3_1_sustainability: status(govRate * 0.8),  // R3.6 改訂
      sup_3_1_3_climate_disclosure: status(govRate * 0.7), // R3.6 TCFD/SSBJ
      sup_4_2_3_succession: status(govRate * 0.85),
      sup_4_8_independent: status(govRate),
      sup_4_10_diversity: status(govRate * 0.85), // R3.6 女性役員
    },
    prime_only: {
      prime_3_1_3_ssbj: status(govRate * 0.7),    // Prime限定 SSBJ強制
      prime_4_8_one_third_independent: status(govRate),  // 独立社外取締役 1/3
      prime_4_10_nominating_committee: status(govRate * 0.9),
    },
    comply_rate: Math.round(govRate * 100),
    measurement: 'partial',
    reason_ja: 'ガバナンス軸の実測合格率からの概算です (原則単位の実査ではありません)',
  };
}

/**
 * Centurion 評価 (測定状態つき・断定しない版)。
 *
 * 実測できた Phase が 1 つも無い場合は aggregate=null / measurement='unmeasurable' を返す。
 * 「未測定」と「不合格」を混同しないための入口。
 */
export async function evaluateCenturion(
  profile: RegulatorProfile = 'listed',
  opts: { scores?: PhaseScore[]; workdir?: string } = {},
): Promise<CenturionMeasurementReport> {
  const scores = opts.scores ?? await collectPhaseScores(opts.workdir);
  const measuredPhases = new Set(scores.map(s => s.phase));
  const unmeasured = DECLARED_GOVERNANCE_SCOPE.filter(d => !measuredPhases.has(d.phase));
  const declaredAxes = DECLARED_GOVERNANCE_SCOPE.reduce((a, b) => a + b.axes_declared, 0);
  const measuredAxes = scores.reduce((a, b) => a + b.axes, 0);

  const measurement: GovernanceMeasurement =
    measuredAxes === 0 ? 'unmeasurable' : unmeasured.length === 0 ? 'measured' : 'partial';

  const ssbj = mapToSsbj(scores);
  const cgCode = mapToCgCodeR6(scores);

  const reason_ja =
    measurement === 'unmeasurable'
      ? `${UNMEASURABLE_REASON}。宣言されている ${DECLARED_GOVERNANCE_SCOPE.length} Phase / ${declaredAxes} 軸はいずれも未測定です`
      : measurement === 'partial'
        ? `${DECLARED_GOVERNANCE_SCOPE.length} Phase のうち ${scores.length} Phase のみ実測できています (未測定 ${unmeasured.length} Phase)`
        : '宣言された全 Phase を実測しました';

  return {
    generated_at: new Date().toISOString(),
    profile,
    measurement,
    measured_axes: measuredAxes,
    declared_axes: declaredAxes,
    reason_ja,
    unmeasured,
    scores,
    aggregate: measuredAxes === 0 ? null : buildAggregate(profile, scores, ssbj, cgCode),
    ssbj_d1_d2_mapping: ssbj,
    cg_code_r6_mapping: cgCode,
  };
}

/**
 * Centurion 集計実行 (後方互換の入口)。
 *
 * ★実測値が 1 件も無い場合は GovernanceUnmeasurableError を投げる。
 *   固定スコアから作った架空の「加重総合スコア」を返さないための変更。
 *   未測定でも結果が欲しい場合は evaluateCenturion() を使うこと。
 */
export async function aggregateCenturion(profile: RegulatorProfile = 'listed'): Promise<CenturionAggregate> {
  const report = await evaluateCenturion(profile);
  if (!report.aggregate) throw new GovernanceUnmeasurableError(report);
  return report.aggregate;
}

/** 実測値からの集計 (実測が 1 件も無いときは呼ばない) */
function buildAggregate(
  profile: RegulatorProfile,
  scores: PhaseScore[],
  ssbj: SsbjMapping,
  cgCode: CgCodeMapping,
): CenturionAggregate {
  // プロファイル重み適用
  const weights = WEIGHT_MATRIX[profile];
  const weighted = scores.map(s => ({ ...s, weight: weights[s.category] ?? 0.5 }));

  const totalAxes = weighted.reduce((a, b) => a + b.axes, 0);
  const passedAxes = weighted.reduce((a, b) => a + b.passed, 0);
  const rawScore = totalAxes > 0 ? (passedAxes / totalAxes) * 100 : 0;

  let weightedNum = 0;
  let weightedDen = 0;
  for (const s of weighted) {
    weightedNum += s.score * s.weight * s.axes;
    weightedDen += s.weight * s.axes;
  }
  const weightedScore = weightedDen > 0 ? weightedNum / weightedDen : 0;

  const byCategory: Record<string, { score: number; axes: number; passed: number }> = {};
  for (const s of weighted) {
    const c = byCategory[s.category] ??= { score: 0, axes: 0, passed: 0 };
    c.score = ((c.score * c.axes) + (s.score * s.axes)) / (c.axes + s.axes || 1);
    c.axes += s.axes;
    c.passed += s.passed;
  }

  const topGaps = [...weighted]
    .sort((a, b) => (a.passed / Math.max(a.axes, 1)) - (b.passed / Math.max(b.axes, 1)))
    .slice(0, 10);

  // SSBJ / CG Code のマッピングは呼び出し元 (evaluateCenturion) が算出済みのものを使う
  // (weight は集計用の係数であり、covered/passed の算出には影響しない)
  const d1 = ssbj.d1_general;
  const d2 = ssbj.d2_climate;
  const fillRate = d1.covered === null || d2.covered === null
    ? null
    : Math.round((d1.covered + d2.covered) / (d1.total + d2.total) * 100);

  return {
    generated_at: new Date().toISOString(),
    profile,
    total_axes: totalAxes,
    passed_axes: passedAxes,
    weighted_score: Math.round(weightedScore * 100) / 100,
    raw_score: Math.round(rawScore * 100) / 100,
    governance_fill_rate: fillRate,
    by_category: byCategory,
    top_gaps: topGaps,
    ssbj_d1_d2_mapping: ssbj,
    cg_code_r6_mapping: cgCode,
    jsox_audit_ready: weighted.find(s => s.phase === 'v2036-jsox')?.passed === 12,
  };
}

/** Centurion 健全性チェック (Quality Fortress 軸用) */
export function isCenturionHealthy(agg: CenturionAggregate): { ok: boolean; reason?: string } {
  if (agg.total_axes < 50) return { ok: false, reason: 'insufficient phases registered' };
  if (agg.weighted_score < 70) return { ok: false, reason: `weighted_score ${agg.weighted_score} below 70` };
  if (agg.governance_fill_rate === null) {
    return { ok: false, reason: 'governance_fill_rate は未測定のため判定できない (unmeasurable)' };
  }
  if (agg.governance_fill_rate < 60) return { ok: false, reason: `governance_fill_rate ${agg.governance_fill_rate} below 60` };
  return { ok: true };
}

/**
 * 測定レポートに対する健全性チェック。
 * ★未測定を「健全」とも「不健全」とも言わず、unmeasurable として返す
 *   (測っていないものを合格にしない・環境が壊れているほど点が上がる逆転を作らない)。
 */
export function evaluateCenturionHealth(
  report: CenturionMeasurementReport,
): { verdict: 'PASS' | 'FAIL' | 'unmeasurable'; reason_ja: string } {
  if (!report.aggregate) {
    return { verdict: 'unmeasurable', reason_ja: report.reason_ja };
  }
  const h = isCenturionHealthy(report.aggregate);
  return h.ok
    ? { verdict: 'PASS', reason_ja: 'ガバナンス集計は実測値に基づき基準を満たしています' }
    : { verdict: 'FAIL', reason_ja: h.reason ?? '基準未達' };
}

/** 断定できない値の表示用 (画面・帳票にそのまま出せる日本語) */
export function formatScoreJa(value: number | null, unit = ''): string {
  return value === null ? '判定不能 (未測定)' : `${value}${unit}`;
}
