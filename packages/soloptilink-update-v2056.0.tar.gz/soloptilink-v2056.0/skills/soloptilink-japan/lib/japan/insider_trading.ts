/**
 * SoloptiLinkAI Phase 45 — インサイダー取引規制 + Fair Disclosure 対応
 *
 * 金融商品取引法 (金商法) におけるインサイダー取引規制の遵守支援:
 *  - 金商法166条 (会社関係者の禁止行為)
 *  - 金商法167条 (公開買付者等関係者の禁止行為)
 *  - 金商法164条 (短期売買利益の返還)
 *  - 金商法27条の36 〜 27条の39 (Fair Disclosure ルール R30.4施行)
 *  - 金商法165条の2 (空売り規制)
 *  - 上場規程 (適時開示 = TDnet)
 *
 * このモジュールが扱うのは事前統制 (内部者リスト管理 / 取引申告承認 / 重要事実判定 / FD確認) であり、
 * 実取引データへのアクセスは想定しない。
 */

export type InsiderRole =
  | "director" // 役員
  | "officer" // 執行役員
  | "employee" // 従業員
  | "auditor" // 監査役
  | "outside_advisor" // 顧問・契約者
  | "major_shareholder" // 主要株主 (10%以上)
  | "tender_offerer"; // 公開買付者

export type MaterialFactCategory =
  | "decision" // 決定事実 (新株発行・自己株取得・合併・分割・株式交換・解散・新製品開発・営業譲渡 等)
  | "occurrence" // 発生事実 (災害・主要株主異動・訴訟・行政処分 等)
  | "financial" // 決算情報 (売上・利益・配当の予想修正)
  | "subsidiary" // 子会社の重要事実
  | "tender_offer" // 公開買付関連
  | "basket"; // バスケット条項 (上記に準ずる重要なもの)

export interface MaterialFact {
  fact_id: string;
  category: MaterialFactCategory;
  decided_at: string; // 決定/発生日時
  publicly_disclosed: boolean;
  disclosed_at?: string;
  description: string; // 内部用
  /** 軽微基準 (金商法施行令28条等) を満たすか */
  meets_minor_threshold?: boolean;
}

export interface InsiderListEntry {
  person_id: string;
  person_name: string;
  role: InsiderRole;
  registered_at: string;
  fact_id: string;
  /** 知った経路 */
  access_route: string;
  removed_at?: string;
}

export interface PrePostTrade {
  person_id: string;
  ticker: string; // 自社株 or 関連子会社
  trade_type: "buy" | "sell";
  quantity: number;
  filed_at: string;
  filed_status: "approved" | "denied" | "pending";
  executed_at?: string;
}

export interface InsiderFinding {
  rule: string;
  severity: "info" | "warning" | "violation" | "criminal_risk";
  hint: string;
}

/** 重要事実が公表前か判定 (公表 = TDnet 12時間経過 or 主要2紙掲載) */
export function isMaterialFactPubliclyAvailable(
  fact: MaterialFact,
  asOf: string,
): boolean {
  if (!fact.publicly_disclosed || !fact.disclosed_at) return false;
  const disclosed = Date.parse(fact.disclosed_at);
  const now = Date.parse(asOf);
  if (Number.isNaN(disclosed) || Number.isNaN(now)) return false;
  const TWELVE_HOURS_MS = 12 * 60 * 60 * 1000;
  return now - disclosed >= TWELVE_HOURS_MS;
}

/** 内部者リスト (法定ではないが実務上の必須統制) の妥当性検証 */
export function validateInsiderList(
  list: InsiderListEntry[],
  facts: MaterialFact[],
): InsiderFinding[] {
  const findings: InsiderFinding[] = [];

  // 各重要事実に少なくとも1名の登録があるか (現実的には複数)
  for (const f of facts) {
    if (f.publicly_disclosed) continue;
    const linked = list.filter((e) => e.fact_id === f.fact_id && !e.removed_at);
    if (linked.length === 0) {
      findings.push({
        rule: "実務統制 (内部者リスト)",
        severity: "warning",
        hint: `重要事実 ${f.fact_id} (${f.category}) に対する内部者リストエントリが0件。意思決定参加者全員の登録漏れ。`,
      });
    }
  }

  // 同一人物が同一事実で重複登録されていないか
  const seen = new Set<string>();
  for (const e of list) {
    const key = `${e.person_id}:${e.fact_id}`;
    if (seen.has(key)) {
      findings.push({
        rule: "実務統制 (内部者リスト一意性)",
        severity: "info",
        hint: `重複登録: ${e.person_name} on fact ${e.fact_id}`,
      });
    }
    seen.add(key);
  }

  return findings;
}

/** 取引申告審査 (会社関係者は事前に取引許可申請が標準実務) */
export function reviewPrePostTrade(
  trade: PrePostTrade,
  asOfFiling: string,
  insiderEntries: InsiderListEntry[],
  facts: MaterialFact[],
): InsiderFinding[] {
  const findings: InsiderFinding[] = [];

  const personEntries = insiderEntries.filter(
    (e) => e.person_id === trade.person_id && !e.removed_at,
  );

  for (const e of personEntries) {
    const fact = facts.find((f) => f.fact_id === e.fact_id);
    if (!fact) continue;
    const isPublic = isMaterialFactPubliclyAvailable(fact, asOfFiling);
    if (!isPublic && !fact.meets_minor_threshold) {
      findings.push({
        rule: "金商法166条 (会社関係者の禁止行為)",
        severity: "criminal_risk",
        hint: `${trade.person_id} は重要事実 ${fact.fact_id} (${fact.category}) を知る立場。公表前の自社株取引は5年以下懲役 or 500万円以下罰金 (両方併科可) + 課徴金。即時取引停止指示。`,
      });
    }
  }

  if (trade.filed_status === "pending" && trade.executed_at) {
    findings.push({
      rule: "実務統制 (取引申告承認前の執行)",
      severity: "warning",
      hint: "申告ステータスが pending のまま執行されている。承認プロセス見直し。",
    });
  }

  return findings;
}

/** 短期売買利益返還 (金商法164条) */
export interface ShortSwingTrade {
  person_id: string;
  role: InsiderRole;
  ticker: string;
  bought_at: string;
  bought_qty: number;
  bought_price: number;
  sold_at: string;
  sold_qty: number;
  sold_price: number;
}

export function checkShortSwingProfit(t: ShortSwingTrade): InsiderFinding[] {
  const findings: InsiderFinding[] = [];
  if (
    !["director", "officer", "auditor", "major_shareholder"].includes(t.role)
  ) {
    return findings;
  }
  const bought = Date.parse(t.bought_at);
  const sold = Date.parse(t.sold_at);
  if (Number.isNaN(bought) || Number.isNaN(sold)) return findings;
  const SIX_MONTHS_MS = 6 * 30.44 * 24 * 60 * 60 * 1000;
  if (Math.abs(sold - bought) <= SIX_MONTHS_MS) {
    const profit = (t.sold_price - t.bought_price) * Math.min(t.bought_qty, t.sold_qty);
    if (profit > 0) {
      findings.push({
        rule: "金商法164条 (短期売買利益返還)",
        severity: "violation",
        hint: `役員/主要株主による6ヶ月以内の反対売買利益 ¥${profit.toLocaleString()}。会社が請求すれば返還義務 (株主代表訴訟可能)。`,
      });
    }
  }
  return findings;
}

/** Fair Disclosure ルール (金商法27条の36) */
export interface FairDisclosureEvent {
  event_id: string;
  recipient_kind: "analyst" | "institutional_investor" | "media_specific" | "general_public";
  disclosed_at: string;
  contained_unpublished_material: boolean;
  general_disclosure_after_hours_ms?: number;
}

export function checkFairDisclosure(
  ev: FairDisclosureEvent,
): InsiderFinding[] {
  const findings: InsiderFinding[] = [];
  if (!ev.contained_unpublished_material) return findings;
  if (
    ev.recipient_kind === "analyst" ||
    ev.recipient_kind === "institutional_investor" ||
    ev.recipient_kind === "media_specific"
  ) {
    // 同時開示 (意図的) or 速やか開示 (非意図的、5営業日以内目安)
    const within = ev.general_disclosure_after_hours_ms ?? Infinity;
    const FIVE_BIZ_DAYS_MS = 5 * 24 * 60 * 60 * 1000;
    if (within > FIVE_BIZ_DAYS_MS) {
      findings.push({
        rule: "金商法27条の36 (Fair Disclosure)",
        severity: "violation",
        hint: `特定者 (${ev.recipient_kind}) への重要情報伝達後、一般開示 (TDnet等) が遅延。意図的伝達は同時、非意図的でも5営業日以内 (R30.4施行)。違反は監視委員会調査対象。`,
      });
    }
  }
  return findings;
}

/** 空売り規制 (金商法165条の2 + 公募・第三者割当時) */
export interface ShortSaleEvent {
  shorted_at: string;
  ticker: string;
  qty: number;
  /** 直前の公募増資 etc が公表されている期間か */
  during_public_offering_window: boolean;
  /** 当該空売り後、その公募で当該銘柄を取得したか */
  acquired_via_offering: boolean;
}

export function checkShortSaleRule(s: ShortSaleEvent): InsiderFinding[] {
  if (s.during_public_offering_window && s.acquired_via_offering) {
    return [
      {
        rule: "金商法165条の2 (公募増資公表後の空売り)",
        severity: "violation",
        hint: "公募増資公表から発行価格決定までの期間に空売りし、その後同公募で取得することは禁止 (アービトラージ阻止)。課徴金対象。",
      },
    ];
  }
  return [];
}

/** 統合判定: 取引が安全に実行可能か */
export function assessTradeSafety(input: {
  person_id: string;
  trade: PrePostTrade;
  insider_entries: InsiderListEntry[];
  facts: MaterialFact[];
  filing_time: string;
}): { safe: boolean; findings: InsiderFinding[] } {
  const findings = reviewPrePostTrade(
    input.trade,
    input.filing_time,
    input.insider_entries,
    input.facts,
  );
  const safe = !findings.some(
    (f) => f.severity === "criminal_risk" || f.severity === "violation",
  );
  return { safe, findings };
}

export function buildInsiderPolicyTemplate(orgName: string): string {
  return `# ${orgName} 内部者取引管理規程

## 第1条 (目的)
本規程は、金商法 166条/167条 等のインサイダー取引規制 + Fair Disclosure (27条の36) を
${orgName} (以下「当社」) において確実に遵守することを目的とする。

## 第2条 (定義)
- 重要事実: 金商法166条2項各号に該当する事実 (決定/発生/決算/子会社/バスケット条項)
- 公表: TDnet 開示後12時間経過 又は 主要2紙以上に掲載

## 第3条 (内部者リスト)
コンプライアンス部は、重要事実が発生・決定した時点で、当該事実を知り得る者を
速やかに「内部者リスト」に登録する。同リストは事案終了後5年保存する。

## 第4条 (取引申告)
役員・執行役員・部長以上 + 重要事実関係者は、自社株 (子会社含む) の取引前に
コンプライアンス部に書面で申告し、承認を得る (公表後は不要)。

## 第5条 (短期売買利益)
役員・主要株主が6ヶ月以内に反対売買で得た利益は、会社の請求により返還する (法164条)。

## 第6条 (Fair Disclosure)
IRイベント・スモールミーティング等で証券アナリスト/機関投資家/特定メディアに対し、
未公表の重要情報を伝達する場合、同時 (意図的) 又は5営業日以内 (非意図的) に TDnet 等で一般開示する。

## 第7条 (違反時の対応)
本規程違反は、就業規則第◯条に基づき懲戒処分とする。
インサイダー取引違反は刑事罰 (5年以下懲役 or 500万円以下罰金) + 課徴金の可能性あり。
`;
}
