/**
 * funeral.ts — 葬祭・宗教法人ドメイン (Phase 26)
 *
 * 対象法令・制度:
 * - 墓地、埋葬等に関する法律 (墓地埋葬法 / S23.5.31 法律第48号)
 * - 宗教法人法 (S26.4.3 法律第126号)
 * - 葬祭ディレクター技能審査制度 (厚労省認定 1級/2級)
 * - 散骨に関するガイドライン (R3.3 厚労省)
 * - 法人税法 (宗教法人の収益事業34業種)
 * - 民法 第897条 (祭祀財産の承継)
 * - 旅行業法・古物営業法 (一部関連)
 *
 * 主要機能:
 * 1. 火葬24時間ルール (墓地埋葬法第3条)
 * 2. 改葬許可申請 (第5条)
 * 3. 墓地・納骨堂・火葬場経営許可 (第10条)
 * 4. 宗教法人設立認証フロー (規則認証 → 登記)
 * 5. 不活動宗教法人判定 (R6 文化庁基準)
 * 6. 葬祭ディレクター技能審査要件
 * 7. 散骨ガイドライン (節度ある方法)
 * 8. 宗教法人の収益事業判定 (法人税法施行令5条 34業種)
 * 9. 永代供養契約・墓地使用契約の標準条項
 */

// ────────────────────────────────────────────────────
// 1. 墓地埋葬法 — 火葬24時間ルール
// ────────────────────────────────────────────────────

export const CREMATION_WAIT_HOURS = 24;
export const CREMATION_WAIT_HOURS_INFECTIOUS = 0; // 一類感染症等は例外

export type DeathCause =
  | "natural"
  | "accident"
  | "infectious_class1" // エボラ・ペスト・痘そう等
  | "infectious_class2" // ジフテリア・SARS・MERS等
  | "stillbirth_after_24w"
  | "stillbirth_under_24w";

/**
 * 火葬可能時刻を計算 (墓地埋葬法第3条)
 * 死亡から24時間経過後でなければ火葬できない（感染症法指定の場合は例外）
 */
export function calcCremationEarliestTime(
  deathAt: Date,
  cause: DeathCause
): Date {
  const waitHours =
    cause === "infectious_class1" || cause === "infectious_class2"
      ? CREMATION_WAIT_HOURS_INFECTIOUS
      : CREMATION_WAIT_HOURS;
  return new Date(deathAt.getTime() + waitHours * 60 * 60 * 1000);
}

/**
 * 妊娠週数から死産届の要否判定
 * 妊娠12週以後の死産は死産届が必要 (死産の届出に関する規程)
 */
export function requiresStillbirthReport(weeksOfPregnancy: number): boolean {
  return weeksOfPregnancy >= 12;
}

// ────────────────────────────────────────────────────
// 2. 改葬許可 (墓地埋葬法第5条)
// ────────────────────────────────────────────────────

export interface KaisoPermitApplication {
  applicantName: string;
  applicantAddressJa: string;
  applicantRelation: string; // 親族関係
  deceasedName: string;
  deceasedDeathDate: Date;
  currentCemetery: { name: string; addressJa: string; managerName: string };
  newCemetery: { name: string; addressJa: string; managerName: string };
  reason: string;
}

export function buildKaisoPermitApplication(
  app: KaisoPermitApplication
): { documentType: "改葬許可申請書"; municipality: string; required: string[] } {
  const required = [
    "改葬許可申請書(原本)",
    "現墓地管理者の埋蔵証明書(または受入証明書)",
    "新墓地管理者の受入証明書",
    "申請者の戸籍謄本(申請者と死亡者の関係証明)",
  ];
  // 申請先は現墓地所在地の市区町村
  const municipality = app.currentCemetery.addressJa.split("市")[0] + "市";
  return { documentType: "改葬許可申請書", municipality, required };
}

// ────────────────────────────────────────────────────
// 3. 墓地・納骨堂・火葬場経営許可 (第10条)
// ────────────────────────────────────────────────────

export type CemeteryFacilityKind = "graveyard" | "ossuary" | "crematorium";

export const CEMETERY_OPERATOR_QUALIFICATION = {
  // 原則: 地方公共団体 > 宗教法人 > 公益法人
  preferred_order: ["municipality", "religious_corp", "public_interest_corp"],
  prohibited: ["individual_for_profit", "ordinary_company"],
  exception_note:
    "個人・営利法人による経営は原則不可。既存施設を承継する場合のみ例外的に検討。",
} as const;

export interface CemeteryPermitCheck {
  applicantType:
    | "municipality"
    | "religious_corp"
    | "public_interest_corp"
    | "individual_for_profit"
    | "ordinary_company";
  facilityKind: CemeteryFacilityKind;
  prefectureGuidelinesMet: boolean;
  residentConsentObtained: boolean; // 周辺住民同意 (条例で要求される自治体多数)
}

export function canOperateCemetery(c: CemeteryPermitCheck): {
  ok: boolean;
  reasons: string[];
} {
  const reasons: string[] = [];
  if (
    c.applicantType === "individual_for_profit" ||
    c.applicantType === "ordinary_company"
  ) {
    reasons.push(
      "申請者が個人または営利法人。墓地埋葬法第10条の運用通達により原則不可"
    );
  }
  if (!c.prefectureGuidelinesMet) {
    reasons.push("都道府県の墓地経営指針(距離制限・面積要件等)を満たしていない");
  }
  if (!c.residentConsentObtained) {
    reasons.push("周辺住民同意未取得(条例要件)");
  }
  return { ok: reasons.length === 0, reasons };
}

// ────────────────────────────────────────────────────
// 4. 宗教法人法 — 設立認証フロー
// ────────────────────────────────────────────────────

export type ReligiousCorpType = "shrine" | "temple" | "church" | "other";

export interface ReligiousCorpRequirements {
  hasReligiousActivity3Years: boolean; // 3年以上の宗教活動実績
  hasFixedFollowers: boolean; // 一定の信者
  hasFacility: boolean; // 礼拝施設
  hasRules: boolean; // 規則案
  hasRepresentative: boolean; // 代表役員
  responsibleOfficersCount: number; // 責任役員 3名以上
}

export const RELIGIOUS_CORP_MIN_RESPONSIBLE_OFFICERS = 3;

export function canEstablishReligiousCorp(
  r: ReligiousCorpRequirements
): { ok: boolean; missing: string[] } {
  const missing: string[] = [];
  if (!r.hasReligiousActivity3Years)
    missing.push("3年以上の宗教活動実績(認証の事実上の運用基準)");
  if (!r.hasFixedFollowers) missing.push("一定数の信者");
  if (!r.hasFacility) missing.push("礼拝施設(本殿・本堂・聖堂等)");
  if (!r.hasRules) missing.push("規則案");
  if (!r.hasRepresentative) missing.push("代表役員");
  if (r.responsibleOfficersCount < RELIGIOUS_CORP_MIN_RESPONSIBLE_OFFICERS) {
    missing.push(
      `責任役員${r.responsibleOfficersCount}名 (最低${RELIGIOUS_CORP_MIN_RESPONSIBLE_OFFICERS}名必要)`
    );
  }
  return { ok: missing.length === 0, missing };
}

export const RELIGIOUS_CORP_AUTH_STEPS = [
  { step: 1, name: "規則案・申請書作成", days: 30 },
  { step: 2, name: "信者その他の利害関係人への公告", days: 30 }, // 1ヶ月以上
  { step: 3, name: "所轄庁(都道府県知事/文部科学大臣)へ認証申請", days: 1 },
  { step: 4, name: "所轄庁による審査", days: 90 }, // 3ヶ月程度
  { step: 5, name: "認証書交付", days: 1 },
  { step: 6, name: "設立登記(認証から2週間以内)", days: 14 },
] as const;

export function estimateAuthLeadtimeDays(): number {
  return RELIGIOUS_CORP_AUTH_STEPS.reduce((s, x) => s + x.days, 0);
}

// ────────────────────────────────────────────────────
// 5. 不活動宗教法人判定 (R6 文化庁通知)
// ────────────────────────────────────────────────────

export interface InactivityCheckInput {
  yearsSinceLastActivity: number; // 最後の宗教活動から経過年数
  filedAnnualReport: boolean; // 役員名簿等の提出
  representativeContactable: boolean;
  facilityExists: boolean;
}

export function judgeInactiveReligiousCorp(
  i: InactivityCheckInput
): {
  inactive: boolean;
  recommendation: "active" | "warning" | "dissolution_candidate";
  reasons: string[];
} {
  const reasons: string[] = [];
  if (i.yearsSinceLastActivity >= 2) reasons.push("2年以上活動実績なし");
  if (!i.filedAnnualReport) reasons.push("役員名簿等の年次提出を怠っている");
  if (!i.representativeContactable) reasons.push("代表役員と連絡が取れない");
  if (!i.facilityExists) reasons.push("礼拝施設が現存しない");

  let recommendation: "active" | "warning" | "dissolution_candidate" = "active";
  if (reasons.length >= 3) recommendation = "dissolution_candidate";
  else if (reasons.length >= 1) recommendation = "warning";
  return {
    inactive: recommendation === "dissolution_candidate",
    recommendation,
    reasons,
  };
}

// ────────────────────────────────────────────────────
// 6. 葬祭ディレクター技能審査制度
// ────────────────────────────────────────────────────

export type DirectorGrade = 1 | 2;

export interface DirectorExamEligibility {
  grade: DirectorGrade;
  experienceYears: number;
  hasGrade2: boolean; // 1級受験時に2級保有か
}

export const DIRECTOR_EXAM_REQUIREMENTS = {
  grade2: { minExperienceYears: 2, requiresGrade2First: false },
  grade1: { minExperienceYears: 5, requiresGrade2First: true },
} as const;

export function canTakeDirectorExam(
  e: DirectorExamEligibility
): { eligible: boolean; reasons: string[] } {
  const reasons: string[] = [];
  if (e.grade === 2) {
    if (e.experienceYears < 2) reasons.push("葬祭実務2年未満");
  } else {
    if (e.experienceYears < 5) reasons.push("葬祭実務5年未満");
    if (!e.hasGrade2)
      reasons.push("1級受験には2級合格(または同等)が必要(原則)");
  }
  return { eligible: reasons.length === 0, reasons };
}

// ────────────────────────────────────────────────────
// 7. 散骨ガイドライン (R3.3 厚労省)
// ────────────────────────────────────────────────────

export interface SankotsuPlan {
  location: "ocean" | "land_owned" | "land_unowned";
  distanceFromShoreKm?: number; // 海洋散骨時
  ashesGroundToPowder: boolean; // 2mm以下の粉末化
  obtainedLandownerConsent: boolean;
  notifyLocalGovernment: boolean;
  observedAreaProhibition: boolean; // 散骨禁止条例の遵守
}

export function evaluateSankotsuLegality(p: SankotsuPlan): {
  ok: boolean;
  warnings: string[];
} {
  const warnings: string[] = [];
  if (!p.ashesGroundToPowder)
    warnings.push("遺骨を2mm以下に粉末化していない(法令上は遺骨と判断され不可)");
  if (p.location === "ocean") {
    if ((p.distanceFromShoreKm ?? 0) < 10)
      warnings.push("沖合10km未満の海洋散骨は不適切(自主基準)");
  }
  if (p.location === "land_unowned")
    warnings.push("他人地・公有地での散骨は原則不可");
  if (p.location === "land_owned" && !p.obtainedLandownerConsent)
    warnings.push("土地所有者の同意なし");
  if (!p.observedAreaProhibition)
    warnings.push("散骨禁止条例(北海道長沼町・七飯町等)違反の可能性");
  if (!p.notifyLocalGovernment)
    warnings.push("地元自治体への事前連絡を推奨(トラブル予防)");
  return { ok: warnings.length === 0, warnings };
}

// ────────────────────────────────────────────────────
// 8. 宗教法人の収益事業判定 (法人税法施行令第5条 34業種)
// ────────────────────────────────────────────────────

export const PROFIT_BUSINESS_34_KINDS = [
  "物品販売業",
  "不動産販売業",
  "金銭貸付業",
  "物品貸付業",
  "不動産貸付業",
  "製造業",
  "通信業",
  "運送業",
  "倉庫業",
  "請負業",
  "印刷業",
  "出版業",
  "写真業",
  "席貸業",
  "旅館業",
  "料理店業",
  "周旋業",
  "代理業",
  "仲立業",
  "問屋業",
  "鉱業",
  "土石採取業",
  "浴場業",
  "理容業",
  "美容業",
  "興行業",
  "遊技所業",
  "遊覧所業",
  "医療保健業",
  "技芸教授業",
  "駐車場業",
  "信用保証業",
  "無体財産権の提供業",
  "労働者派遣業",
] as const;

export type ProfitBusinessKind = (typeof PROFIT_BUSINESS_34_KINDS)[number];

export interface ReligiousActivityClassification {
  activityNameJa: string;
  isContinuous: boolean; // 継続的に行われるか
  hasFacility: boolean; // 事業場を設けて行われるか
  charge: "donation" | "fixed_fee_under_market" | "market_rate";
}

/**
 * 宗教法人の活動が収益事業(法人税課税)に該当するか判定
 * 判定基準: 34業種該当 & 継続性 & 事業場性 & 対価性 (4要件)
 */
export function isTaxableProfitActivity(
  a: ReligiousActivityClassification & { matchedKind?: ProfitBusinessKind }
): { taxable: boolean; reason: string } {
  if (!a.matchedKind) {
    return { taxable: false, reason: "34業種に該当しない(本来の宗教活動)" };
  }
  if (!a.isContinuous) {
    return { taxable: false, reason: "継続性なし(臨時の活動)" };
  }
  if (!a.hasFacility) {
    return { taxable: false, reason: "事業場を設けていない" };
  }
  if (a.charge === "donation") {
    return {
      taxable: false,
      reason: "対価性なし(任意の喜捨・お布施は宗教活動の範疇)",
    };
  }
  if (a.charge === "fixed_fee_under_market") {
    return {
      taxable: false,
      reason: "市場価格を著しく下回る(実費弁償的な性格)",
    };
  }
  return {
    taxable: true,
    reason: `34業種「${a.matchedKind}」に該当し収益事業として法人税課税対象`,
  };
}

// ────────────────────────────────────────────────────
// 9. 永代供養契約 / 墓地使用契約 標準条項
// ────────────────────────────────────────────────────

export interface EternalMemorialContract {
  parties: { facilityName: string; userName: string };
  feeYen: number;
  memorialPeriodYears: number; // 33回忌まで等
  bonePlacement: "individual_grave" | "shared_ossuary_after_period" | "shared";
  cancellationRefundPolicy:
    | "no_refund"
    | "prorated_refund_within_first_year"
    | "case_by_case";
  successorRules: "no_successor_required" | "successor_required";
}

export const ETERNAL_MEMORIAL_REQUIRED_CLAUSES = [
  "供養期間と供養方法の明記",
  "供養期間経過後の遺骨の取扱い(合祀等)",
  "祭祀承継者を必要としない旨",
  "管理者の管理義務範囲",
  "施設廃止時の遺骨の取扱い・移転先",
  "中途解約時の返金規程",
  "管理費の有無と発生時期",
  "宗教・宗派の制限有無",
] as const;

export function auditEternalMemorialContract(c: EternalMemorialContract): {
  complete: boolean;
  missingClauses: string[];
} {
  const missing: string[] = [];
  // 簡易チェック (実運用ではテキスト解析を推奨)
  if (c.memorialPeriodYears <= 0)
    missing.push("供養期間が0年以下(年数明記が必要)");
  if (
    c.bonePlacement === "shared_ossuary_after_period" &&
    c.memorialPeriodYears > 50
  )
    missing.push("供養期間が長すぎる(33回忌=32年が一般的)");
  if (c.cancellationRefundPolicy === "case_by_case")
    missing.push("中途解約時の返金規程が「個別協議」では不適切");
  return { complete: missing.length === 0, missingClauses: missing };
}

// ────────────────────────────────────────────────────
// 10. 葬儀価格表示ガイドライン (景表法・特商法連携)
// ────────────────────────────────────────────────────

export const FUNERAL_PLAN_REQUIRED_DISCLOSURES = [
  "プラン内容(祭壇・棺・骨壷・霊柩車・式場利用料・飲食・返礼品)の有無",
  "追加費用が発生する条件と概算",
  "火葬料・式場使用料・宗教者への謝礼が含まれるか否か",
  "見積書と請求書の差異が出るケースの説明",
  "クーリングオフ非適用の旨(契約締結後の解約条件)",
] as const;

export function auditFuneralPlanDisplay(disclosures: string[]): {
  ok: boolean;
  missing: string[];
} {
  const missing = FUNERAL_PLAN_REQUIRED_DISCLOSURES.filter(
    (req) => !disclosures.some((d) => d.includes(req.split("(")[0]))
  );
  return { ok: missing.length === 0, missing: [...missing] };
}

// ────────────────────────────────────────────────────
// 11. 民法第897条 — 祭祀財産の承継
// ────────────────────────────────────────────────────

export interface SaisiSuccession {
  designatedSuccessor?: string; // 被相続人による指定
  customaryHeir?: string; // 慣習による
  hasFamilyCourtRuling?: boolean; // 家庭裁判所の審判
}

/**
 * 祭祀財産(系譜・祭具・墳墓)の承継者を判定
 * 民法897条: ①被相続人指定 → ②慣習 → ③家庭裁判所審判
 */
export function decideSaisiSuccessor(s: SaisiSuccession): {
  successor: string | null;
  basis: string;
} {
  if (s.designatedSuccessor)
    return { successor: s.designatedSuccessor, basis: "民法897条1項 被相続人指定" };
  if (s.customaryHeir)
    return { successor: s.customaryHeir, basis: "民法897条1項 慣習による承継" };
  if (s.hasFamilyCourtRuling)
    return { successor: null, basis: "民法897条2項 家庭裁判所審判による決定待ち" };
  return { successor: null, basis: "承継者未確定(家裁審判の申立てを推奨)" };
}
