/**
 * @fileoverview Phase 11 - 介護ドメイン DNA
 *
 * 介護保険法 + 介護報酬告示 + LIFE (科学的介護情報システム) +
 * ケアプランデータ連携標準仕様 + 国保連伝送 を実装。
 *
 * Claude Code は「介護報酬は単位制です」で止まる。
 * 本モジュールは:
 *   1. 要介護度 (要支援1,2 + 要介護1〜5) と区分支給限度基準額
 *   2. 介護報酬: 単位 → 円換算 (地域区分 1〜7級地)
 *   3. サービスコード (居宅介護支援/訪問介護/通所介護/短期入所等)
 *   4. ケアプラン (1表/2表/3表/4表/5表/6表/7表) の構造
 *   5. LIFE 提出データ (令和3年度〜)
 *   6. 国保連伝送フォーマット (簡易版)
 *   7. 加算・減算ロジック (処遇改善加算/特定処遇改善加算/夜勤加算等)
 *   8. 給付管理票
 */

// ============================================================================
// Types
// ============================================================================

/** 要介護度 */
export type CareLevel =
  | 'support_1' | 'support_2'
  | 'care_1' | 'care_2' | 'care_3' | 'care_4' | 'care_5';

/** 区分支給限度基準額 (R6改定後・単位/月) */
export const CARE_LIMIT_UNITS: Record<CareLevel, number> = {
  support_1: 5_032,
  support_2: 10_531,
  care_1: 16_765,
  care_2: 19_705,
  care_3: 27_048,
  care_4: 30_938,
  care_5: 36_217,
};

/** 地域区分 (1級地〜7級地 + その他) と単価 (10円基準・サービス区分別) */
export type RegionGrade = '1' | '2' | '3' | '4' | '5' | '6' | '7' | 'other';

/** 居宅サービスの場合の 1単位あたり円 (R6改定後・上乗せ係数) */
export const REGION_UNIT_YEN_HOMECARE: Record<RegionGrade, number> = {
  '1': 11.40,  // 東京特別区など
  '2': 11.12,  // 横浜市・大阪市など
  '3': 11.05,
  '4': 10.84,
  '5': 10.70,
  '6': 10.42,
  '7': 10.21,
  'other': 10.00,
};

/** サービスコード (代表) */
export type ServiceCode =
  | 'home_visit_care'        // 訪問介護 (身体介護/生活援助)
  | 'home_visit_bathing'     // 訪問入浴介護
  | 'home_visit_nursing'     // 訪問看護
  | 'home_visit_rehab'       // 訪問リハビリテーション
  | 'day_service'            // 通所介護 (デイサービス)
  | 'day_rehab'              // 通所リハビリテーション (デイケア)
  | 'short_stay'             // 短期入所生活介護 (ショートステイ)
  | 'group_home'             // 認知症対応型共同生活介護
  | 'special_nursing_home'   // 介護老人福祉施設 (特養)
  | 'health_care_facility'   // 介護老人保健施設 (老健)
  | 'medical_care_facility'  // 介護医療院
  | 'care_management';       // 居宅介護支援 (ケアマネ)

/** 介護報酬テーブルエントリ */
export interface CareFeeItem {
  serviceCode: ServiceCode;
  /** サービス内容コード (10桁) */
  contentCode: string;
  name: string;
  /** 1回/1日あたりの単位 */
  units: number;
  /** 算定要件 */
  requirements?: string;
  revision: 'R3' | 'R6';
}

export const STANDARD_CARE_FEES: CareFeeItem[] = [
  // 訪問介護 (R6改定後)
  { serviceCode: 'home_visit_care', contentCode: '1110', name: '身体介護 20分未満', units: 167, revision: 'R6' },
  { serviceCode: 'home_visit_care', contentCode: '1111', name: '身体介護 20分以上30分未満', units: 250, revision: 'R6' },
  { serviceCode: 'home_visit_care', contentCode: '1112', name: '身体介護 30分以上1時間未満', units: 396, revision: 'R6' },
  { serviceCode: 'home_visit_care', contentCode: '1113', name: '身体介護 1時間以上1時間半未満', units: 579, revision: 'R6' },
  { serviceCode: 'home_visit_care', contentCode: '1211', name: '生活援助 20分以上45分未満', units: 183, revision: 'R6' },
  { serviceCode: 'home_visit_care', contentCode: '1212', name: '生活援助 45分以上', units: 225, revision: 'R6' },

  // 通所介護 (R6改定後・通常規模型・所要時間 7-8時間)
  { serviceCode: 'day_service', contentCode: '5511', name: '通常規模 7-8時間 要介護1', units: 658, revision: 'R6' },
  { serviceCode: 'day_service', contentCode: '5512', name: '通常規模 7-8時間 要介護2', units: 777, revision: 'R6' },
  { serviceCode: 'day_service', contentCode: '5513', name: '通常規模 7-8時間 要介護3', units: 900, revision: 'R6' },
  { serviceCode: 'day_service', contentCode: '5514', name: '通常規模 7-8時間 要介護4', units: 1023, revision: 'R6' },
  { serviceCode: 'day_service', contentCode: '5515', name: '通常規模 7-8時間 要介護5', units: 1148, revision: 'R6' },

  // 短期入所生活介護
  { serviceCode: 'short_stay', contentCode: '2111', name: '短期入所生活介護 (Ⅰ)単独型・従来型個室 要介護1', units: 645, revision: 'R6' },
  { serviceCode: 'short_stay', contentCode: '2112', name: '同 要介護2', units: 715, revision: 'R6' },

  // 居宅介護支援
  { serviceCode: 'care_management', contentCode: '4311', name: '居宅介護支援費(Ⅰ) 要介護1・2', units: 1086, revision: 'R6' },
  { serviceCode: 'care_management', contentCode: '4312', name: '居宅介護支援費(Ⅰ) 要介護3〜5', units: 1411, revision: 'R6' },

  // R6 新設
  { serviceCode: 'home_visit_care', contentCode: '6010', name: '処遇改善加算(Ⅰ) (訪問介護)', units: 245, revision: 'R6', requirements: 'キャリアパス要件 + 職場環境等要件' },
  { serviceCode: 'home_visit_care', contentCode: '6020', name: '特定事業所加算(Ⅰ)', units: 200, revision: 'R6', requirements: '体制要件 + 人材要件 + 重度対応' },
];

// ============================================================================
// 算定: 単位 → 円
// ============================================================================

export function calcCareFeeYen(input: {
  items: { contentCode: string; quantity?: number }[];
  regionGrade: RegionGrade;
  copayRatio: 0.1 | 0.2 | 0.3; // 1割/2割/3割負担
  feeTable?: CareFeeItem[];
  unitYenTable?: Record<RegionGrade, number>;
}): {
  totalUnits: number;
  totalYen: number;
  copayYen: number;
  insurerYen: number;
  unitYen: number;
} {
  const table = input.feeTable ?? STANDARD_CARE_FEES;
  const unitYen = (input.unitYenTable ?? REGION_UNIT_YEN_HOMECARE)[input.regionGrade];
  let totalUnits = 0;
  for (const it of input.items) {
    const fee = table.find((f) => f.contentCode === it.contentCode);
    if (!fee) continue;
    totalUnits += fee.units * (it.quantity ?? 1);
  }
  const totalYen = Math.floor(totalUnits * unitYen);
  const copayYen = Math.round(totalYen * input.copayRatio);
  const insurerYen = totalYen - copayYen;
  return { totalUnits, totalYen, copayYen, insurerYen, unitYen };
}

// ============================================================================
// 区分支給限度額 超過チェック
// ============================================================================

export function checkLimitExcess(input: {
  careLevel: CareLevel;
  plannedUnits: number;
}): { withinLimit: boolean; limitUnits: number; excessUnits: number; excessSelfPayYen: number; excessUnitYen?: number } {
  const limitUnits = CARE_LIMIT_UNITS[input.careLevel];
  const excessUnits = Math.max(0, input.plannedUnits - limitUnits);
  // 限度額超過分は全額自己負担 (10円換算で目安計算)
  const excessSelfPayYen = excessUnits * 10;
  return {
    withinLimit: excessUnits === 0,
    limitUnits,
    excessUnits,
    excessSelfPayYen,
  };
}

// ============================================================================
// ケアプラン (1表〜7表)
// ============================================================================

export interface CarePlanSheet1 {
  /** 1表: 居宅サービス計画書(1) */
  insuredCardNumber: string;
  insuredName: string;
  birthDate: string;
  careLevel: CareLevel;
  certificationDate: string;
  certificationValidStart: string;
  certificationValidEnd: string;
  careManagerId: string;
  careManagerName: string;
  /** 利用者及び家族の生活に対する意向 */
  userAndFamilyIntent: string;
  /** 介護認定審査会の意見 */
  certificationCommitteeOpinion?: string;
  /** 総合的な援助の方針 */
  comprehensivePolicy: string;
  /** 生活援助中心型の算定理由 */
  livingSupportReason?: string;
}

export interface CarePlanSheet2Item {
  /** 2表: 居宅サービス計画書(2) */
  needsCategory: string; // 生活全般の解決すべき課題
  longTermGoal: { goal: string; period: string };
  shortTermGoal: { goal: string; period: string };
  serviceContent: string;
  serviceCode: ServiceCode;
  frequency: string; // 例: 週3回
  period: string;
}

export interface CarePlanSheet3 {
  /** 3表: 週間サービス計画表 */
  /** 24h × 7days のグリッド */
  weeklyGrid: { day: 'mon' | 'tue' | 'wed' | 'thu' | 'fri' | 'sat' | 'sun'; hour: number; serviceCode?: ServiceCode; provider?: string }[];
  /** 主な日常生活上の活動 */
  dailyActivities: string;
  /** 週単位以外のサービス */
  nonWeeklyServices?: string;
}

// ============================================================================
// LIFE (科学的介護情報システム) 提出データ
// ============================================================================

export interface LifeSubmission {
  /** 利用者ID (LIFE 内で発番) */
  lifeUserId: string;
  /** ADL (Barthel Index) */
  barthelIndex: number;
  /** 認知症高齢者の日常生活自立度 */
  dementiaIndependenceLevel: 'Ⅰ' | 'Ⅱa' | 'Ⅱb' | 'Ⅲa' | 'Ⅲb' | 'Ⅳ' | 'M' | 'normal';
  /** 障害高齢者の日常生活自立度 */
  disabilityIndependenceLevel: 'J1' | 'J2' | 'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2' | 'normal';
  /** 栄養状態 (BMI/血清アルブミン値/体重変化率) */
  nutritionStatus: { bmi: number; albumin?: number; weightChangePctMonth?: number };
  /** 提出加算種別 */
  additionType: 'science_care_promotion' | 'adl_maintenance' | 'oral_function' | 'rehab_management';
  /** 提出年月 YYYY-MM */
  submissionMonth: string;
}

// ============================================================================
// 給付管理票 (国保連向け)
// ============================================================================

export interface BenefitManagementSheet {
  insuredCardNumber: string;
  serviceMonth: string; // YYYYMM
  careLevel: CareLevel;
  /** 各サービスの給付管理単位 */
  entries: {
    serviceCode: ServiceCode;
    contentCode: string;
    units: number;
    providerNumber: string; // 事業所番号 10 桁
  }[];
  /** 合計給付管理単位 */
  totalManagedUnits: number;
}

export function buildBenefitManagementSheet(input: {
  insuredCardNumber: string;
  serviceMonth: string;
  careLevel: CareLevel;
  serviceItems: { serviceCode: ServiceCode; contentCode: string; units: number; providerNumber: string }[];
}): BenefitManagementSheet {
  const totalManagedUnits = input.serviceItems.reduce((s, e) => s + e.units, 0);
  return {
    insuredCardNumber: input.insuredCardNumber,
    serviceMonth: input.serviceMonth,
    careLevel: input.careLevel,
    entries: input.serviceItems,
    totalManagedUnits,
  };
}

// ============================================================================
// 加算・減算ロジック
// ============================================================================

export function applyProcessingImprovementAddition(input: {
  baseUnits: number;
  /** 処遇改善加算区分 */
  category: 'I' | 'II' | 'III' | 'IV' | 'none';
  /** サービス区分 */
  serviceCode: ServiceCode;
}): number {
  // R6改定後の処遇改善加算率 (代表値・サービス区分により詳細係数が異なる)
  const coefByCategory: Record<typeof input.category, number> = {
    I: 0.245,
    II: 0.224,
    III: 0.182,
    IV: 0.145,
    none: 0,
  };
  // 訪問介護のみの代表値。実運用はサービス毎に別係数。
  const coef = coefByCategory[input.category];
  return Math.floor(input.baseUnits * coef);
}

// ============================================================================
// Default exports
// ============================================================================

export const CARE_LEVEL_LABELS: Record<CareLevel, string> = {
  support_1: '要支援1',
  support_2: '要支援2',
  care_1: '要介護1',
  care_2: '要介護2',
  care_3: '要介護3',
  care_4: '要介護4',
  care_5: '要介護5',
};

export const SERVICE_CODE_LABELS: Record<ServiceCode, string> = {
  home_visit_care: '訪問介護',
  home_visit_bathing: '訪問入浴介護',
  home_visit_nursing: '訪問看護',
  home_visit_rehab: '訪問リハビリ',
  day_service: '通所介護',
  day_rehab: '通所リハビリ',
  short_stay: '短期入所生活介護',
  group_home: '認知症対応型共同生活介護',
  special_nursing_home: '介護老人福祉施設',
  health_care_facility: '介護老人保健施設',
  medical_care_facility: '介護医療院',
  care_management: '居宅介護支援',
};

export const LONGTERM_CARE_REFS = {
  REVENUE_TABLE_URL: 'https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/0000088373.html',
  LIFE_PORTAL_URL: 'https://life.mhlw.go.jp/',
  CAREPLAN_DATA_LINK_URL: 'https://www.mhlw.go.jp/stf/newpage_22155.html',
};
