/**
 * SoloptiLinkAI Phase 44-IP — 意匠権 (Design Right)
 *
 * 意匠法 (R元改正 + R2.4施行) + ハーグ協定 (国際意匠) + 不正競争防止法形態模倣 と連携。
 *
 * カバー範囲:
 *  - 意匠の種類 (物品 / 部分 / 組物 / 内装 / 動的 / 画像)
 *  - 関連意匠制度 (本意匠+10年関連可)
 *  - 意匠登録要件 (新規性 + 創作非容易性 + 工業上利用可能性)
 *  - 意匠分類 (日本国意匠分類)
 *  - 出願→方式審査→実体審査→登録 (出願日から約8-12ヶ月)
 *  - 存続期間 25年 (R2.4改正で20→25年)
 *  - 意匠権侵害判定 (類否判断: 物品同一・類似 + 形態同一・類似)
 *  - ハーグ協定 (国際意匠登録)
 *  - 秘密意匠制度 (3年以内非公開可)
 */

export type DesignType =
  | "article" // 物品の意匠
  | "partial" // 部分意匠 (R2.4改正で全分野可)
  | "set_of_articles" // 組物意匠
  | "interior" // 内装意匠 (R2.4新設)
  | "dynamic" // 動的意匠
  | "image" // 画像意匠 (R2.4: 物品から独立、ソフト/UI 単体保護可)
  | "building"; // 建築物の意匠 (R2.4新設)

export interface DesignApplication {
  application_no: string;
  registration_no?: string;
  title: string;
  applicant: string;
  designer: string[];
  filing_date: string;
  publication_date?: string;
  registration_date?: string;
  expiry_date?: string;
  design_type: DesignType;
  design_classification?: string; // 日本国意匠分類 (D04 等)
  related_main_design_no?: string; // 関連意匠の場合の本意匠番号
  is_secret?: boolean; // 秘密意匠 (公開を最大3年延期)
  secret_until?: string;
}

// 意匠登録要件 (3条)
export interface DesignRegistrabilityCheck {
  is_industrial: boolean; // 工業上利用可能性
  novelty: boolean; // 新規性 (3条1項各号)
  inventive_step: boolean; // 創作非容易性 (3条2項) - 当業者が容易に創作できないこと
  not_likely_to_confuse: boolean; // 出所混同のおそれなし (3条の2)
  not_against_public_order: boolean; // 公序良俗反しない (5条1号)
  not_excluded_function: boolean; // 物品の機能を確保するために不可欠な形状でない (5条3号)
}

export function evaluateDesignRegistrability(c: DesignRegistrabilityCheck): {
  registrable: boolean;
  rejection_grounds: string[];
} {
  const grounds: string[] = [];
  if (!c.is_industrial) grounds.push("工業上利用可能性なし (3条柱書) - 量産不能");
  if (!c.novelty) grounds.push("新規性なし (3条1項) - 公知/公用/刊行物記載");
  if (!c.inventive_step) grounds.push("創作非容易性なし (3条2項) - 当業者容易創作");
  if (!c.not_likely_to_confuse) grounds.push("出所混同のおそれ (3条の2)");
  if (!c.not_against_public_order) grounds.push("公序良俗違反 (5条1号)");
  if (!c.not_excluded_function) grounds.push("機能確保のための不可欠形状 (5条3号)");
  return { registrable: grounds.length === 0, rejection_grounds: grounds };
}

// 存続期間 (R2.4改正: 20→25年)
export const DESIGN_TERM_YEARS = 25;

export function calcDesignExpiry(filingDate: string): string {
  const filing = new Date(filingDate);
  const expiry = new Date(filing);
  expiry.setFullYear(expiry.getFullYear() + DESIGN_TERM_YEARS);
  return expiry.toISOString().slice(0, 10);
}

// 関連意匠制度 (R2.4改正)
export interface RelatedDesignTimeline {
  main_application_no: string;
  main_filing_date: string;
  related_application_window_end: string; // 本意匠出願日から10年以内
}

export function calcRelatedDesignWindow(mainFilingDate: string): RelatedDesignTimeline {
  const main = new Date(mainFilingDate);
  const end = new Date(main);
  end.setFullYear(end.getFullYear() + 10);
  return {
    main_application_no: "",
    main_filing_date: mainFilingDate,
    related_application_window_end: end.toISOString().slice(0, 10),
  };
}

// 維持年金 (登録料)
export const DESIGN_MAINTENANCE_FEES_R6 = [
  { year_range: [1, 3], per_year_jpy: 8_500 },
  { year_range: [4, 25], per_year_jpy: 16_900 },
];

export function calcDesignMaintenanceFee(year: number): number {
  if (year < 1 || year > DESIGN_TERM_YEARS) return 0;
  const tier = DESIGN_MAINTENANCE_FEES_R6.find((t) => year >= t.year_range[0] && year <= t.year_range[1]);
  return tier ? tier.per_year_jpy : 0;
}

// 意匠権侵害判定 (23条) - 類否判断
export interface DesignInfringementClaim {
  registered_design_no: string;
  registered_article: string;
  registered_classification: string;
  defendant_article: string;
  defendant_classification: string;
  visual_similarity_score: number; // 0-1 (需要者が混同するか)
  is_image_design?: boolean;
  defenses?: ("research" | "exhaustion" | "prior_use" | "non_industrial")[];
}

export function evaluateDesignInfringement(claim: DesignInfringementClaim): {
  infringes: boolean;
  reasoning: string[];
} {
  const reasons: string[] = [];
  // 物品の同一・類似性
  const sameArticle = claim.registered_article === claim.defendant_article;
  const similarArticle = claim.registered_classification === claim.defendant_classification;
  if (!sameArticle && !similarArticle) {
    reasons.push("物品が同一でも類似でもない → 非侵害");
    return { infringes: false, reasoning: reasons };
  }
  reasons.push(sameArticle ? "物品同一" : "物品類似 (同一意匠分類)");
  // 形態の類似性 (一般的に 70% 以上で類似)
  if (claim.visual_similarity_score < 0.7) {
    reasons.push(`形態類似度 ${claim.visual_similarity_score} (70%未満) → 非類似`);
    return { infringes: false, reasoning: reasons };
  }
  reasons.push(`形態類似度 ${claim.visual_similarity_score} → 類似`);
  // 抗弁
  if (claim.defenses?.includes("prior_use")) {
    reasons.push("先使用権 (29条) 主張あり → 詳細審査必要");
  }
  if (claim.defenses?.includes("exhaustion")) {
    reasons.push("意匠権消尽 - 適法販売後の使用");
  }
  return { infringes: true, reasoning: reasons };
}

// ハーグ協定 (国際意匠)
export interface HagueApplication {
  international_registration_no: string;
  designated_countries: string[];
  basic_application?: string;
  filing_date: string;
  expiry_date: string;
}

export const HAGUE_MEMBER_COUNTRIES_2026 = [
  "JP", "US", "EP", "CN", "KR", "DE", "FR", "GB", "IT", "CH", "SG", "VN", "TH", "MX", "RU",
  // 75+カ国
] as const;

export function isHagueMember(country: string): boolean {
  return (HAGUE_MEMBER_COUNTRIES_2026 as readonly string[]).includes(country);
}

// 秘密意匠制度 (14条 - 最大3年公開延期)
export function calcSecretDesignDeadline(registrationDate: string, requestedYears: 1 | 2 | 3): {
  secret_until: string;
  is_valid_request: boolean;
} {
  const reg = new Date(registrationDate);
  const until = new Date(reg);
  until.setFullYear(until.getFullYear() + requestedYears);
  return {
    secret_until: until.toISOString().slice(0, 10),
    is_valid_request: requestedYears >= 1 && requestedYears <= 3,
  };
}

// 不正競争防止法 形態模倣 (2条1項3号) - 商品形態の最初の販売から3年以内
export interface FormImitationClaim {
  product_name: string;
  first_sold_date: string;
  defendant_imitation_date: string;
  has_substantially_same_form: boolean;
  defendant_developed_independently?: boolean;
}

export function evaluateFormImitation(claim: FormImitationClaim): {
  infringes_unfair_competition: boolean;
  reasoning: string[];
} {
  const reasons: string[] = [];
  const firstSold = new Date(claim.first_sold_date);
  const threeYearsLater = new Date(firstSold);
  threeYearsLater.setFullYear(threeYearsLater.getFullYear() + 3);
  if (new Date(claim.defendant_imitation_date) > threeYearsLater) {
    reasons.push("最初の販売から3年経過 → 不競法2条1項3号の保護対象外");
    return { infringes_unfair_competition: false, reasoning: reasons };
  }
  if (!claim.has_substantially_same_form) {
    reasons.push("実質的同一性なし → 形態模倣に該当せず");
    return { infringes_unfair_competition: false, reasoning: reasons };
  }
  if (claim.defendant_developed_independently) {
    reasons.push("被告が独自開発を立証 → 模倣行為該当性に疑義");
  }
  reasons.push("3年以内 + 実質同一形態 → 不正競争防止法 2条1項3号 違反");
  return { infringes_unfair_competition: true, reasoning: reasons };
}
