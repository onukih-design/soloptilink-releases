/**
 * SoloptiLinkAI Phase 16 — Learning Analytics Engine
 *
 * 学習データ (~/.soloptilink/learning/, ~/.soloptilink/memory/) を読み込み、
 * 業種別カバレッジ・成功率・失敗パターン・推奨戦略を抽出する。
 *
 * 入力ソース (NDJSON):
 *  - learning/quality/scores.jsonl       : フェーズ別品質スコア
 *  - learning/errors/patterns.jsonl       : 集約済みエラーパターン
 *  - learning/errors/raw_failures.jsonl   : 個別失敗ログ
 *  - learning/solutions/index.jsonl       : 適用された解決策
 *  - memory/episodic/agent_learning.jsonl : エージェント学習
 *  - memory/fix-history/strategy_scores.jsonl : 修復戦略の成否
 *  - quality-dashboard/sessions.jsonl     : セッション総括
 */

export type StrategyResult = "success" | "failure";

export interface StrategyRecord {
  key: string;
  result: StrategyResult;
  ts: string;
}

export interface ErrorPattern {
  error_type: string;
  domain: string;
  frequency: number;
  fix_success_count: number;
  fix_total_count: number;
  fix_success_rate: number;
  severity: number;
  last_message: string;
}

export interface QualityScore {
  phase: string;
  score: number;
  ts: string;
  domain?: string;
}

export interface SessionRollup {
  session_id: string;
  domain?: string;
  phases?: string[];
  modules_used?: string[];
  outcome: "ok" | "ng";
  duration_ms?: number;
  ts: string;
}

export interface DomainCoverage {
  domain: string;
  session_count: number;
  modules_used: Record<string, number>;
  avg_quality_score: number | null;
  failure_rate: number;
  top_errors: ErrorPattern[];
}

export interface StrategyRanking {
  key: string;
  attempts: number;
  successes: number;
  success_rate: number;
  recommended: boolean;
}

const RECOMMEND_THRESHOLD = 0.7;
const RECOMMEND_MIN_ATTEMPTS = 3;

export function parseStrategyRecords(jsonl: string): StrategyRecord[] {
  const out: StrategyRecord[] = [];
  for (const line of jsonl.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    try {
      const rec = JSON.parse(trimmed) as StrategyRecord;
      if (rec && typeof rec.key === "string" && (rec.result === "success" || rec.result === "failure")) {
        out.push(rec);
      }
    } catch {
      // ignore malformed line
    }
  }
  return out;
}

export function parseErrorPatterns(jsonl: string): ErrorPattern[] {
  const out: ErrorPattern[] = [];
  for (const line of jsonl.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    try {
      const rec = JSON.parse(trimmed);
      if (rec && rec.error_type) {
        out.push({
          error_type: String(rec.error_type),
          domain: String(rec.domain ?? "unknown"),
          frequency: Number(rec.frequency ?? 0),
          fix_success_count: Number(rec.fix_success_count ?? 0),
          fix_total_count: Number(rec.fix_total_count ?? 0),
          fix_success_rate: Number(rec.fix_success_rate ?? 0),
          severity: Number(rec.severity ?? 0),
          last_message: String(rec.last_message ?? ""),
        });
      }
    } catch {
      // ignore
    }
  }
  return out;
}

export function rankStrategies(records: StrategyRecord[]): StrategyRanking[] {
  const agg = new Map<string, { successes: number; attempts: number }>();
  for (const r of records) {
    const cur = agg.get(r.key) ?? { successes: 0, attempts: 0 };
    cur.attempts += 1;
    if (r.result === "success") cur.successes += 1;
    agg.set(r.key, cur);
  }
  const out: StrategyRanking[] = [];
  for (const [key, v] of agg) {
    const rate = v.attempts === 0 ? 0 : v.successes / v.attempts;
    out.push({
      key,
      attempts: v.attempts,
      successes: v.successes,
      success_rate: Number(rate.toFixed(3)),
      recommended: v.attempts >= RECOMMEND_MIN_ATTEMPTS && rate >= RECOMMEND_THRESHOLD,
    });
  }
  out.sort((a, b) => b.success_rate - a.success_rate || b.attempts - a.attempts);
  return out;
}

export function summarizeDomainCoverage(
  sessions: SessionRollup[],
  errors: ErrorPattern[],
  scores: QualityScore[],
): DomainCoverage[] {
  const domains = new Map<string, DomainCoverage>();

  for (const s of sessions) {
    const domain = s.domain ?? "unknown";
    const cur = domains.get(domain) ?? {
      domain,
      session_count: 0,
      modules_used: {},
      avg_quality_score: null,
      failure_rate: 0,
      top_errors: [],
    };
    cur.session_count += 1;
    if (s.outcome === "ng") cur.failure_rate += 1;
    for (const m of s.modules_used ?? []) {
      cur.modules_used[m] = (cur.modules_used[m] ?? 0) + 1;
    }
    domains.set(domain, cur);
  }

  for (const cov of domains.values()) {
    if (cov.session_count > 0) {
      cov.failure_rate = Number((cov.failure_rate / cov.session_count).toFixed(3));
    }
    const domainScores = scores.filter((x) => (x.domain ?? "unknown") === cov.domain);
    if (domainScores.length > 0) {
      const avg = domainScores.reduce((a, b) => a + b.score, 0) / domainScores.length;
      cov.avg_quality_score = Number(avg.toFixed(2));
    }
    cov.top_errors = errors
      .filter((e) => e.domain === cov.domain)
      .sort((a, b) => b.severity * b.frequency - a.severity * a.frequency)
      .slice(0, 5);
  }

  return [...domains.values()].sort((a, b) => b.session_count - a.session_count);
}

export interface NextActionHint {
  domain: string;
  hint: string;
  rationale: string;
}

export function suggestNextActions(coverage: DomainCoverage[]): NextActionHint[] {
  const hints: NextActionHint[] = [];
  for (const c of coverage) {
    if (c.session_count >= 3 && (c.avg_quality_score ?? 100) < 80) {
      hints.push({
        domain: c.domain,
        hint: `${c.domain} 業種の品質スコア平均 ${c.avg_quality_score} は閾値80未満。Quality Fortress 軸25 (Customer Intelligence) で業種別ベンチマークを引き上げよ。`,
        rationale: "low_avg_quality",
      });
    }
    if (c.failure_rate >= 0.3) {
      const top = c.top_errors[0];
      hints.push({
        domain: c.domain,
        hint: top
          ? `${c.domain} 業種の失敗率 ${(c.failure_rate * 100).toFixed(0)}%。最頻 ${top.error_type} に対して save_guarantee.ts / bug_prevention_ext.ts の防御層を追加せよ。`
          : `${c.domain} 業種の失敗率 ${(c.failure_rate * 100).toFixed(0)}%。エラーパターン未集約のため raw_failures.jsonl の集約スクリプトを実行せよ。`,
        rationale: "high_failure_rate",
      });
    }
    const usedModules = Object.keys(c.modules_used);
    if (usedModules.length > 0 && !usedModules.includes("save_guarantee")) {
      hints.push({
        domain: c.domain,
        hint: `${c.domain} 業種で save_guarantee.ts が未適用。Phase 6 バグ予防DNA を全 CRUD に注入せよ。`,
        rationale: "missing_save_guarantee",
      });
    }
  }
  return hints;
}

export interface AnalyticsReport {
  generated_at: string;
  total_sessions: number;
  total_errors: number;
  total_strategies: number;
  top_strategies: StrategyRanking[];
  bottom_strategies: StrategyRanking[];
  coverage: DomainCoverage[];
  next_actions: NextActionHint[];
}

export function buildAnalyticsReport(input: {
  strategyJsonl?: string;
  errorPatternsJsonl?: string;
  qualityScoresJsonl?: string;
  sessionsJsonl?: string;
}): AnalyticsReport {
  const strategies = parseStrategyRecords(input.strategyJsonl ?? "");
  const errors = parseErrorPatterns(input.errorPatternsJsonl ?? "");
  const scores = parseQualityScores(input.qualityScoresJsonl ?? "");
  const sessions = parseSessions(input.sessionsJsonl ?? "");

  const ranked = rankStrategies(strategies);
  const coverage = summarizeDomainCoverage(sessions, errors, scores);

  return {
    generated_at: new Date().toISOString(),
    total_sessions: sessions.length,
    total_errors: errors.length,
    total_strategies: strategies.length,
    top_strategies: ranked.slice(0, 10),
    bottom_strategies: ranked.slice(-5).reverse(),
    coverage,
    next_actions: suggestNextActions(coverage),
  };
}

export function parseQualityScores(jsonl: string): QualityScore[] {
  const out: QualityScore[] = [];
  for (const line of jsonl.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    try {
      const rec = JSON.parse(trimmed);
      if (rec && rec.score !== undefined) {
        out.push({
          phase: String(rec.phase ?? "unknown"),
          score: Number(rec.score),
          ts: String(rec.ts ?? new Date().toISOString()),
          domain: rec.domain ? String(rec.domain) : undefined,
        });
      }
    } catch {
      // ignore
    }
  }
  return out;
}

export function parseSessions(jsonl: string): SessionRollup[] {
  const out: SessionRollup[] = [];
  for (const line of jsonl.split(/\r?\n/)) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    try {
      const rec = JSON.parse(trimmed);
      if (rec && rec.session_id) {
        out.push({
          session_id: String(rec.session_id),
          domain: rec.domain ? String(rec.domain) : undefined,
          phases: Array.isArray(rec.phases) ? rec.phases.map(String) : undefined,
          modules_used: Array.isArray(rec.modules_used) ? rec.modules_used.map(String) : undefined,
          outcome: rec.outcome === "ng" ? "ng" : "ok",
          duration_ms: rec.duration_ms ? Number(rec.duration_ms) : undefined,
          ts: String(rec.ts ?? new Date().toISOString()),
        });
      }
    } catch {
      // ignore
    }
  }
  return out;
}

export function formatReportMarkdown(report: AnalyticsReport): string {
  const lines: string[] = [];
  lines.push(`# SoloptiLinkAI Learning Analytics Report`);
  lines.push(`Generated: ${report.generated_at}`);
  lines.push("");
  lines.push(`- Total sessions: ${report.total_sessions}`);
  lines.push(`- Total error patterns: ${report.total_errors}`);
  lines.push(`- Total strategy records: ${report.total_strategies}`);
  lines.push("");
  lines.push("## Top strategies (by success rate)");
  for (const s of report.top_strategies) {
    lines.push(`- ${s.key} — ${(s.success_rate * 100).toFixed(0)}% (${s.successes}/${s.attempts})${s.recommended ? " ✅" : ""}`);
  }
  if (report.bottom_strategies.length > 0) {
    lines.push("");
    lines.push("## Bottom strategies (avoid or improve)");
    for (const s of report.bottom_strategies) {
      lines.push(`- ${s.key} — ${(s.success_rate * 100).toFixed(0)}% (${s.successes}/${s.attempts})`);
    }
  }
  lines.push("");
  lines.push("## Domain coverage");
  for (const c of report.coverage) {
    lines.push(`### ${c.domain}`);
    lines.push(`- sessions: ${c.session_count}`);
    lines.push(`- avg quality: ${c.avg_quality_score ?? "n/a"}`);
    lines.push(`- failure rate: ${(c.failure_rate * 100).toFixed(0)}%`);
    const mods = Object.entries(c.modules_used).sort((a, b) => b[1] - a[1]).slice(0, 5);
    if (mods.length > 0) {
      lines.push(`- top modules: ${mods.map(([k, v]) => `${k}(${v})`).join(", ")}`);
    }
  }
  if (report.next_actions.length > 0) {
    lines.push("");
    lines.push("## Suggested next actions");
    for (const h of report.next_actions) {
      lines.push(`- [${h.domain}] ${h.hint}`);
    }
  }
  return lines.join("\n");
}
