/**
 * SoloptiLinkAI Phase 42-HC — Personal Health Record (PHR)
 *
 * 患者本人が管理する健康情報の相互運用基盤。
 * 既存 medical.ts (診療報酬R6/UKE/HPKI) との役割分離:
 *   medical.ts = 医療機関側 (診療報酬請求/レセプト)
 *   phr.ts     = 患者側 (PHR/マイナポータル連携/HL7 FHIR JP Core)
 *
 * カバー範囲:
 *  - HL7 FHIR R4 JP Core (Patient/Observation/Condition/Medication/Encounter)
 *  - マイナポータル PHR API (健診結果/薬剤/予防接種)
 *  - 厚労省 PHR ガイドライン (R4告示) + 全国医療情報PF
 *  - 健康スコア (BMI/血圧/血糖) 自動計算
 *  - 服薬リマインダー + 副作用監視
 *  - 個情法 第26条 R4改正 + 医療分野ガイドライン (要配慮個人情報)
 *  - 3省2ガイドライン準拠記録
 */

// FHIR R4 JP Core 主要リソース (簡略型)
export interface FhirPatient {
  resourceType: "Patient";
  id: string;
  identifier?: { system: string; value: string }[]; // マイナンバー / 被保険者番号
  name?: { family: string; given: string[]; family_kana?: string; given_kana?: string[] }[];
  gender?: "male" | "female" | "other" | "unknown";
  birthDate?: string; // YYYY-MM-DD
  address?: { postalCode?: string; prefecture?: string; city?: string; line?: string[] }[];
  telecom?: { system: "phone" | "email"; value: string }[];
}

export interface FhirObservation {
  resourceType: "Observation";
  id: string;
  status: "registered" | "preliminary" | "final" | "amended";
  category: "vital-signs" | "laboratory" | "imaging" | "exam";
  code: { system: string; code: string; display: string }; // LOINC/JLAC10
  subject: { reference: string }; // Patient/123
  effectiveDateTime: string;
  valueQuantity?: { value: number; unit: string };
  interpretation?: "normal" | "high" | "low" | "critical_high" | "critical_low";
}

export interface FhirCondition {
  resourceType: "Condition";
  id: string;
  clinicalStatus: "active" | "recurrence" | "relapse" | "inactive" | "remission" | "resolved";
  category: "problem-list-item" | "encounter-diagnosis";
  code: { system: string; code: string; display: string }; // ICD-10 / ICD-11
  subject: { reference: string };
  onsetDateTime?: string;
  recordedDate: string;
}

export interface FhirMedicationStatement {
  resourceType: "MedicationStatement";
  id: string;
  status: "active" | "completed" | "stopped" | "on-hold";
  medicationCodeableConcept: { system: string; code: string; display: string }; // YJコード
  subject: { reference: string };
  effectivePeriod: { start: string; end?: string };
  dosage?: { text: string; timing?: string }[];
}

// マイナポータル PHR API
export type MynaPortalDataKind =
  | "specific_health_check" // 特定健診
  | "post_specific_health_guidance" // 特定保健指導
  | "school_check_up" // 学校健診
  | "company_check_up" // 事業者健診
  | "medication" // 薬剤情報
  | "vaccination" // 予防接種
  | "medical_treatment_history" // 診療情報
  | "operation_history" // 手術情報
  | "growth_record"; // 乳幼児健診

export interface MynaPortalConsent {
  patient_id: string;
  data_kind: MynaPortalDataKind;
  consent_at: string;
  expires_at: string;
  scope: "self" | "family_caregiver" | "doctor" | "researcher";
  audit_log_id: string;
}

export function isConsentValid(consent: MynaPortalConsent, asOf: Date = new Date()): boolean {
  const exp = new Date(consent.expires_at);
  return asOf < exp;
}

// 健康スコア計算
export interface VitalSigns {
  height_cm?: number;
  weight_kg?: number;
  systolic_bp?: number;
  diastolic_bp?: number;
  hba1c?: number; // %
  ldl_cholesterol?: number; // mg/dL
  hdl_cholesterol?: number; // mg/dL
  triglyceride?: number; // mg/dL
  fasting_glucose?: number; // mg/dL
}

export interface HealthScore {
  bmi: number | null;
  bmi_category: "underweight" | "normal" | "overweight" | "obese_class1" | "obese_class2" | "obese_class3" | null;
  bp_category: "optimal" | "normal" | "high_normal" | "grade1" | "grade2" | "grade3" | null;
  metabolic_syndrome: boolean;
  diabetes_risk: "low" | "borderline" | "diabetes" | null;
  warnings: string[];
}

export function calcHealthScore(vitals: VitalSigns): HealthScore {
  const warnings: string[] = [];
  let bmi: number | null = null;
  let bmiCat: HealthScore["bmi_category"] = null;
  if (vitals.height_cm && vitals.weight_kg) {
    const m = vitals.height_cm / 100;
    bmi = Number((vitals.weight_kg / (m * m)).toFixed(1));
    if (bmi < 18.5) bmiCat = "underweight";
    else if (bmi < 25) bmiCat = "normal";
    else if (bmi < 30) bmiCat = "overweight";
    else if (bmi < 35) bmiCat = "obese_class1";
    else if (bmi < 40) bmiCat = "obese_class2";
    else bmiCat = "obese_class3";
    if (bmi >= 25) warnings.push(`BMI ${bmi} は肥満度I以上 (要保健指導)`);
  }
  // 高血圧学会基準
  let bpCat: HealthScore["bp_category"] = null;
  if (vitals.systolic_bp !== undefined && vitals.diastolic_bp !== undefined) {
    const s = vitals.systolic_bp, d = vitals.diastolic_bp;
    if (s < 120 && d < 80) bpCat = "optimal";
    else if (s < 130 && d < 85) bpCat = "normal";
    else if (s < 140 && d < 90) bpCat = "high_normal";
    else if (s < 160 || d < 100) bpCat = "grade1";
    else if (s < 180 || d < 110) bpCat = "grade2";
    else bpCat = "grade3";
    if (s >= 140 || d >= 90) warnings.push(`血圧 ${s}/${d} mmHg は高血圧 (受診推奨)`);
  }
  // メタボ判定 (簡略: BMI 25以上 + 血圧/血糖/脂質のいずれか異常)
  let metabolic = false;
  if (bmi !== null && bmi >= 25) {
    const abn = (vitals.systolic_bp ?? 0) >= 130
      || (vitals.diastolic_bp ?? 0) >= 85
      || (vitals.fasting_glucose ?? 0) >= 110
      || (vitals.triglyceride ?? 0) >= 150
      || (vitals.hdl_cholesterol ?? 999) < 40;
    metabolic = abn;
    if (metabolic) warnings.push("メタボリックシンドローム該当の可能性 (特定保健指導対象)");
  }
  // 糖尿病リスク (HbA1c)
  let diabRisk: HealthScore["diabetes_risk"] = null;
  if (vitals.hba1c !== undefined) {
    if (vitals.hba1c < 5.6) diabRisk = "low";
    else if (vitals.hba1c < 6.5) diabRisk = "borderline";
    else diabRisk = "diabetes";
    if (diabRisk === "diabetes") warnings.push(`HbA1c ${vitals.hba1c}% は糖尿病型 (受診必要)`);
    else if (diabRisk === "borderline") warnings.push(`HbA1c ${vitals.hba1c}% は境界型 (生活改善推奨)`);
  }
  return { bmi, bmi_category: bmiCat, bp_category: bpCat, metabolic_syndrome: metabolic, diabetes_risk: diabRisk, warnings };
}

// 服薬リマインダー
export interface MedicationSchedule {
  medication_name: string;
  yj_code?: string;
  start_date: string;
  end_date?: string;
  daily_times: string[]; // ["08:00", "20:00"]
  notes?: string;
}

export interface ReminderEvent {
  scheduled_at: string;
  medication_name: string;
  status: "pending" | "taken" | "missed" | "skipped";
}

export function generateRemindersForDay(
  schedules: MedicationSchedule[],
  date: string,
): ReminderEvent[] {
  const out: ReminderEvent[] = [];
  const target = new Date(date);
  for (const s of schedules) {
    const start = new Date(s.start_date);
    const end = s.end_date ? new Date(s.end_date) : null;
    if (target < start) continue;
    if (end && target > end) continue;
    for (const t of s.daily_times) {
      const [h, m] = t.split(":").map(Number);
      const at = new Date(target);
      at.setHours(h, m, 0, 0);
      out.push({ scheduled_at: at.toISOString(), medication_name: s.medication_name, status: "pending" });
    }
  }
  return out.sort((a, b) => Date.parse(a.scheduled_at) - Date.parse(b.scheduled_at));
}

// 副作用監視 (服薬と症状の相関)
export interface AdverseEventReport {
  patient_id: string;
  reported_at: string;
  symptom: string;
  suspected_medication: string;
  severity: "mild" | "moderate" | "severe" | "life_threatening";
  required_pmda_report: boolean; // PMDA医薬品安全性情報報告
}

export function shouldReportToPmda(report: Partial<AdverseEventReport>): boolean {
  // 重篤性「重篤」以上は PMDA への報告対象 (薬機法 第68条の10)
  return report.severity === "severe" || report.severity === "life_threatening";
}

// 3省2ガイドライン準拠記録
export interface ThreeMinTwoGlCompliance {
  electronic_health_info: boolean;
  encryption_at_rest: boolean;
  encryption_in_transit: boolean;
  access_log_worm: boolean;
  hpki_authentication: boolean;
  consent_management: boolean;
  data_retention_policy: boolean; // 5年保存
  audit_frequency_year: number;
}

export function checkThreeMinTwoGl(c: ThreeMinTwoGlCompliance): { compliant: boolean; missing: string[] } {
  const missing: string[] = [];
  if (!c.encryption_at_rest) missing.push("保管時暗号化");
  if (!c.encryption_in_transit) missing.push("通信時暗号化 (TLS 1.2以上)");
  if (!c.access_log_worm) missing.push("アクセスログ WORM 保管");
  if (!c.hpki_authentication) missing.push("HPKI 認証 (医師/薬剤師)");
  if (!c.consent_management) missing.push("同意管理 (本人同意 + 撤回)");
  if (!c.data_retention_policy) missing.push("保存期間ポリシー (診療録5年)");
  if (c.audit_frequency_year < 1) missing.push("年1回以上の監査");
  return { compliant: missing.length === 0, missing };
}
