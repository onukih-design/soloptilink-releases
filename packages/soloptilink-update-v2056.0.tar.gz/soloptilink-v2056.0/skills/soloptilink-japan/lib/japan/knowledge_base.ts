/**
 * SoloptiLinkAI Phase 23 — ナレッジベース / FAQ (Knowledge Base)
 *
 * 顧客サポートと社内向けの両方で使えるナレッジベース基盤。
 * support_ticket.ts と連動し、頻発問い合わせの自動FAQ化や
 * 関連記事推薦による一次回答時間短縮を実現。
 *
 * カバー範囲:
 *  - 記事 (Article) のCRUD + バージョン管理
 *  - タグベース分類 + カテゴリ階層
 *  - 簡易全文検索 (TF-IDF風スコアリング、依存ライブラリなし)
 *  - 関連記事推薦 (Jaccard 係数)
 *  - 公開状態管理 (draft/internal_only/public)
 *  - 役立った/役立たなかったの集計
 *  - 自動FAQ候補抽出 (頻発問い合わせ→記事化提案)
 */

export type ArticleVisibility = "draft" | "internal_only" | "public";

export interface KbArticle {
  article_id: string;
  title: string;
  body: string;
  category: string; // 階層 "billing/refund" 形式
  tags: string[];
  visibility: ArticleVisibility;
  author: string;
  created_at: string;
  updated_at: string;
  version: number;
  view_count: number;
  helpful_count: number;
  not_helpful_count: number;
  related_ticket_ids?: string[];
}

export interface SearchQuery {
  query: string;
  visibility?: ArticleVisibility[];
  tag_filter?: string[];
  category_prefix?: string;
}

export interface SearchResult {
  article_id: string;
  title: string;
  score: number;
  matched_terms: string[];
}

// 簡易トークナイザー (日本語: 文字種別変化を区切りに使う簡易版)
function tokenize(text: string): string[] {
  if (!text) return [];
  return text
    .toLowerCase()
    .replace(/[、。!?！？「」『』（）()\[\]【】<>《》""''\.,]/g, " ")
    .split(/\s+/)
    .filter((t) => t.length >= 2);
}

// TF-IDF スコアリング (依存なしの最小実装)
export function searchArticles(articles: KbArticle[], q: SearchQuery): SearchResult[] {
  const allowed = articles.filter((a) => {
    if (q.visibility && !q.visibility.includes(a.visibility)) return false;
    if (q.category_prefix && !a.category.startsWith(q.category_prefix)) return false;
    if (q.tag_filter && q.tag_filter.length > 0) {
      const hit = q.tag_filter.some((t) => a.tags.includes(t));
      if (!hit) return false;
    }
    return true;
  });

  const queryTerms = tokenize(q.query);
  if (queryTerms.length === 0) return [];

  // DF (各タームを含む記事数)
  const df = new Map<string, number>();
  for (const a of allowed) {
    const terms = new Set(tokenize(`${a.title} ${a.body} ${a.tags.join(" ")}`));
    for (const t of terms) df.set(t, (df.get(t) ?? 0) + 1);
  }

  const totalDocs = allowed.length;
  const results: SearchResult[] = [];

  for (const a of allowed) {
    const text = `${a.title} ${a.title} ${a.body} ${a.tags.join(" ")}`; // タイトル重複でブースト
    const tokens = tokenize(text);
    if (tokens.length === 0) continue;
    const tf = new Map<string, number>();
    for (const t of tokens) tf.set(t, (tf.get(t) ?? 0) + 1);

    let score = 0;
    const matched: string[] = [];
    for (const qt of queryTerms) {
      const tfVal = tf.get(qt) ?? 0;
      if (tfVal === 0) continue;
      const dfVal = df.get(qt) ?? 1;
      const idf = Math.log((totalDocs + 1) / (dfVal + 1)) + 1;
      score += (tfVal / tokens.length) * idf;
      matched.push(qt);
    }
    // 評価ボーナス: 役立った数で軽いブースト
    if (a.helpful_count > 0) {
      const ratio = a.helpful_count / Math.max(1, a.helpful_count + a.not_helpful_count);
      score *= 1 + ratio * 0.2;
    }
    if (score > 0) {
      results.push({ article_id: a.article_id, title: a.title, score: Number(score.toFixed(4)), matched_terms: matched });
    }
  }
  return results.sort((a, b) => b.score - a.score);
}

// Jaccard 係数による関連記事推薦
export function findRelatedArticles(target: KbArticle, others: KbArticle[], topK = 5): { article_id: string; similarity: number }[] {
  const targetTokens = new Set([
    ...target.tags,
    ...tokenize(`${target.title} ${target.body}`),
  ]);
  const out: { article_id: string; similarity: number }[] = [];
  for (const a of others) {
    if (a.article_id === target.article_id) continue;
    const aTokens = new Set([...a.tags, ...tokenize(`${a.title} ${a.body}`)]);
    const intersect = [...targetTokens].filter((t) => aTokens.has(t)).length;
    const union = new Set([...targetTokens, ...aTokens]).size;
    const sim = union === 0 ? 0 : intersect / union;
    if (sim > 0) out.push({ article_id: a.article_id, similarity: Number(sim.toFixed(4)) });
  }
  return out.sort((a, b) => b.similarity - a.similarity).slice(0, topK);
}

// 役立った/役立たなかった
export function recordFeedback(
  article: KbArticle,
  helpful: boolean,
): KbArticle {
  return {
    ...article,
    helpful_count: helpful ? article.helpful_count + 1 : article.helpful_count,
    not_helpful_count: helpful ? article.not_helpful_count : article.not_helpful_count + 1,
    updated_at: new Date().toISOString(),
  };
}

// 頻発問い合わせ → FAQ候補抽出
export interface FaqCandidate {
  representative_subject: string;
  cluster_size: number;
  example_inquiry_ids: string[];
  suggested_tags: string[];
  reason: string;
}

export interface InquirySnapshot {
  inquiry_id: string;
  subject: string;
  body?: string;
  category?: string;
  tags?: string[];
}

// シンプルなクラスタリング: 件名のキーワード一致でグループ化
export function suggestFaqCandidates(
  inquiries: InquirySnapshot[],
  options: { min_cluster_size?: number } = {},
): FaqCandidate[] {
  const minSize = options.min_cluster_size ?? 3;
  const buckets = new Map<string, InquirySnapshot[]>();

  for (const inq of inquiries) {
    const tokens = tokenize(inq.subject).slice(0, 3); // 件名上位3トークン
    const key = tokens.sort().join("|") || "_other";
    const arr = buckets.get(key) ?? [];
    arr.push(inq);
    buckets.set(key, arr);
  }

  const candidates: FaqCandidate[] = [];
  for (const [, items] of buckets) {
    if (items.length < minSize) continue;
    const subjects = items.map((i) => i.subject);
    candidates.push({
      representative_subject: subjects[0],
      cluster_size: items.length,
      example_inquiry_ids: items.slice(0, 5).map((i) => i.inquiry_id),
      suggested_tags: Array.from(new Set(items.flatMap((i) => i.tags ?? []))),
      reason: `直近で ${items.length} 件の類似問い合わせあり`,
    });
  }
  return candidates.sort((a, b) => b.cluster_size - a.cluster_size);
}

// 公開判定: ドラフト→公開時のチェックリスト
export interface PublishReadiness {
  ready: boolean;
  blockers: string[];
  warnings: string[];
}

export function checkPublishReadiness(article: KbArticle): PublishReadiness {
  const blockers: string[] = [];
  const warnings: string[] = [];
  if (article.title.trim().length < 5) blockers.push("タイトルが短すぎる (5文字以上)");
  if (article.body.trim().length < 50) blockers.push("本文が短すぎる (50文字以上)");
  if (article.tags.length === 0) warnings.push("タグが未設定");
  if (article.category.trim().length === 0) blockers.push("カテゴリ未設定");
  if (article.visibility !== "draft") warnings.push("既に draft 以外の状態");
  return { ready: blockers.length === 0, blockers, warnings };
}

// 記事内に PII / シークレットが混入していないか検査
const PII_RE = [
  { name: "メール", re: /\b[\w.+-]+@[\w-]+\.[\w.-]+\b/g },
  { name: "電話", re: /\b0\d{1,4}-?\d{1,4}-?\d{3,4}\b/g },
  { name: "API Key", re: /\b(sk-|xoxb-|ghp_|AKIA)[A-Za-z0-9_-]{16,}\b/g },
];

export function scanArticleForLeak(article: KbArticle): { category: string; matched: string }[] {
  const out: { category: string; matched: string }[] = [];
  const text = `${article.title}\n${article.body}`;
  for (const p of PII_RE) {
    const re = new RegExp(p.re.source, p.re.flags);
    let m: RegExpExecArray | null;
    while ((m = re.exec(text)) !== null) {
      out.push({ category: p.name, matched: m[0] });
      if (m.index === re.lastIndex) re.lastIndex += 1;
    }
  }
  return out;
}
