/**
 * @fileoverview Phase 10 - 電子印鑑 / 電子署名 DNA
 *
 * 日本企業 DX の最大障壁「印鑑文化」を電子署名へブリッジするレイヤ。
 * 電子署名法 (2001) + e-文書法 + 電帳法 (2024年1月強制化) を踏まえ、
 * GMO電子印鑑Agree / クラウドサイン (弁護士ドットコム) / DocuSign / Adobe Acrobat Sign
 * の 4 ベンダ共通インターフェイスを提供する。
 *
 * Claude Code は「電子契約サービスを使えばよい」と一般論を返すのみ。
 * 本モジュールは:
 *   1. 電子署名法 第3条 (推定効) を満たすための要件チェック
 *   2. 立会人型 (事業者署名) と当事者型 (本人署名) の自動判別
 *   3. タイムスタンプ局 (TSA) 連携 + 長期署名 (PAdES-LTV) 生成
 *   4. 電帳法スキャナ保存・電子取引データ保存の要件 (真実性/可視性) 自動チェック
 *   5. 印影 SVG 生成 (角印/丸印/個人印) + 朱肉色 + 文字配置
 *
 * 全て Pure TypeScript / 外部 SDK 不要 (アダプタパターンでベンダ別実装を注入)。
 */

// ============================================================================
// Types
// ============================================================================

/** 電子契約ベンダ */
export type ESealVendor =
  | 'gmo_agree'           // GMO電子印鑑Agree (国内シェアNo.1)
  | 'cloudsign'           // クラウドサイン (弁護士ドットコム)
  | 'docusign'            // DocuSign
  | 'adobe_sign'          // Adobe Acrobat Sign
  | 'freee_sign'          // freeeサイン
  | 'shachihata'          // Shachihata Cloud (旧:パソコン決裁)
  | 'internal';           // 自社内製

/** 署名方式 */
export type SignatureType =
  | 'witness'             // 立会人型 (事業者署名・サービス提供者の電子証明書)
  | 'agent';              // 当事者型 (本人署名・本人の電子証明書)

/** 電子署名法 第3条 推定効 要件 */
export interface Article3RequirementCheck {
  /** 本人による電子署名であること (本人性) */
  identity: boolean;
  /** 改変が行われていないこと (非改ざん性) */
  integrity: boolean;
  /** 暗号その他の措置で本人のみが行えるものであること (固有性) */
  uniqueness: boolean;
  /** 全要件を満たすか */
  satisfied: boolean;
  /** 不足要件 */
  missing: string[];
}

/** 電帳法 真実性確保 要件 (令和3年改正対応) */
export interface DenchoRealityCheck {
  /** タイムスタンプ付与 OR 訂正削除履歴の保存 */
  timestamp_or_history: boolean;
  /** 関係書類 (システム概要書・操作説明書) の備付 */
  documentation: boolean;
  /** 検索機能 (取引年月日・取引金額・取引先) */
  searchability: boolean;
  /** ディスプレイ・プリンタの備付 (可視性) */
  visibility: boolean;
  satisfied: boolean;
  missing: string[];
}

/** 署名対象書類のメタ情報 */
export interface SignableDocument {
  documentId: string;
  documentType:
    | 'contract'        // 契約書
    | 'nda'             // NDA
    | 'order'           // 注文書/発注書
    | 'estimate'        // 見積書
    | 'invoice'         // 請求書
    | 'delivery_note'   // 納品書
    | 'receipt'         // 領収書
    | 'employment'      // 雇用契約書
    | 'consent'         // 同意書
    | 'other';
  title: string;
  /** PDF/HTML/Image の元データ (Base64 or URL) */
  contentRef: string;
  /** SHA-256 ハッシュ (改ざん検知用) */
  contentHash: string;
  signers: Signer[];
  /** 印紙税対象か (1号〜20号文書) */
  stampTaxArticle?: number;
  /** 法定保存年限 (年) */
  retentionYears?: number;
}

export interface Signer {
  signerId: string;
  /** 「甲」「乙」「丙」「丁」「立会人」など */
  partyLabel: string;
  name: string;
  title?: string;
  email: string;
  /** 署名順序 (0-indexed) */
  order: number;
  /** 署名済みか */
  signed: boolean;
  signedAt?: string; // ISO8601
  /** 署名方式 */
  signatureType: SignatureType;
}

/** 印影 SVG オプション */
export interface SealImprintOptions {
  /** 印鑑種別 */
  kind: 'kakuin' | 'maruin' | 'ginkouin' | 'mitomein' | 'jitsuin';
  /** 表示文字 (角印は会社名、丸印は代表者名等) */
  text: string;
  /** 朱肉色 (デフォルト #C8102E - 朱色) */
  color?: string;
  /** サイズ px (デフォルト 96) */
  sizePx?: number;
  /** 縦書き(true)/横書き(false) */
  vertical?: boolean;
  /** 印面の縁の太さ (デフォルト 3) */
  borderWidthPx?: number;
}

// ============================================================================
// 電子署名法 第3条 推定効チェック
// ============================================================================

/**
 * 電子署名法 第3条「電磁的記録の真正な成立の推定」要件を満たすか判定。
 *
 * 判定基準:
 *  - 本人性: 当事者型 (本人の電子証明書) は強い、立会人型は弱い (二要素認証で補完可能)
 *  - 非改ざん性: SHA-256 + タイムスタンプ で確保
 *  - 固有性: PKI 鍵長 RSA-2048 以上 / ECDSA P-256 以上
 */
export function checkArticle3(input: {
  signatureType: SignatureType;
  twoFactorAuth: boolean;
  hashAlgorithm: 'SHA-1' | 'SHA-256' | 'SHA-384' | 'SHA-512';
  timestampApplied: boolean;
  keyAlgorithm: 'RSA-1024' | 'RSA-2048' | 'RSA-4096' | 'ECDSA-P256' | 'ECDSA-P384';
  certifiedTSA: boolean; // 総務大臣認定タイムスタンプ局か
}): Article3RequirementCheck {
  const missing: string[] = [];

  // 本人性
  let identity = false;
  if (input.signatureType === 'agent') {
    identity = true;
  } else if (input.signatureType === 'witness' && input.twoFactorAuth) {
    identity = true; // 立会人型でも 2FA で補強すれば成立 (政府見解 R2.7.17)
  } else {
    missing.push('立会人型は二要素認証 (SMS+メール+生体等) が必要');
  }

  // 非改ざん性
  const integrity = ['SHA-256', 'SHA-384', 'SHA-512'].includes(input.hashAlgorithm)
    && input.timestampApplied
    && input.certifiedTSA;
  if (!integrity) {
    if (input.hashAlgorithm === 'SHA-1') missing.push('SHA-1 は脆弱・SHA-256 以上必須');
    if (!input.timestampApplied) missing.push('タイムスタンプ未付与');
    if (!input.certifiedTSA) missing.push('総務大臣認定タイムスタンプ局を使うこと');
  }

  // 固有性
  const uniqueness = ['RSA-2048', 'RSA-4096', 'ECDSA-P256', 'ECDSA-P384'].includes(input.keyAlgorithm);
  if (!uniqueness) missing.push('RSA-1024 は脆弱・RSA-2048 以上 / ECDSA P-256 以上必須');

  return {
    identity,
    integrity,
    uniqueness,
    satisfied: identity && integrity && uniqueness,
    missing,
  };
}

// ============================================================================
// 電帳法 真実性確保チェック (令和3年改正/令和5年宥恕措置終了対応)
// ============================================================================

/**
 * 電子取引データ保存の要件チェック。
 * 2024年1月から強制化済み。違反は青色申告取消の可能性あり。
 */
export function checkDenchoReality(input: {
  hasTimestamp: boolean;
  hasEditHistory: boolean;
  hasSystemManual: boolean;
  hasOperationManual: boolean;
  searchableByDate: boolean;
  searchableByAmount: boolean;
  searchableByPartner: boolean;
  hasDisplay: boolean;
  hasPrinter: boolean;
}): DenchoRealityCheck {
  const missing: string[] = [];

  const timestamp_or_history = input.hasTimestamp || input.hasEditHistory;
  if (!timestamp_or_history) missing.push('タイムスタンプ または 訂正削除履歴の保存が必須');

  const documentation = input.hasSystemManual && input.hasOperationManual;
  if (!documentation) missing.push('システム概要書・操作説明書の備付が必要');

  const searchability =
    input.searchableByDate && input.searchableByAmount && input.searchableByPartner;
  if (!searchability) missing.push('検索3要件 (取引年月日・取引金額・取引先) が不足');

  const visibility = input.hasDisplay && input.hasPrinter;
  if (!visibility) missing.push('ディスプレイ・プリンタの備付 (可視性) が必要');

  return {
    timestamp_or_history,
    documentation,
    searchability,
    visibility,
    satisfied: timestamp_or_history && documentation && searchability && visibility,
    missing,
  };
}

// ============================================================================
// 電子契約ベンダ アダプタ
// ============================================================================

/** 電子契約ベンダの共通インターフェイス */
export interface ESealAdapter {
  vendor: ESealVendor;
  /** 署名依頼を作成 (各ベンダの API ラッパ) */
  createSigningRequest(doc: SignableDocument): Promise<{ requestId: string; signUrl: string }>;
  /** 署名状況の取得 */
  getStatus(requestId: string): Promise<{
    completed: boolean;
    signedCount: number;
    totalSigners: number;
    signedDocumentUrl?: string;
  }>;
  /** 署名済み PDF の取得 (PAdES-LTV 形式) */
  downloadSigned(requestId: string): Promise<{ pdfBase64: string; certificateChain: string[] }>;
  /** 法的有効性チェック (電子署名法 第3条) */
  legalEffectCheck(): Article3RequirementCheck;
}

/**
 * GMO電子印鑑Agree アダプタ (国内シェアNo.1)
 * - 立会人型 + 当事者型 両対応
 * - 総務大臣認定タイムスタンプ
 * - 電帳法スキャナ保存ソフト法的要件認証
 */
export function createGmoAgreeAdapter(config: {
  apiKey: string;
  apiSecret: string;
  endpoint?: string;
}): ESealAdapter {
  return {
    vendor: 'gmo_agree',
    async createSigningRequest(doc) {
      // NOTE: 実 API 連携時は config.endpoint へ POST
      // モック実装: アダプタ I/F を保証
      return { requestId: `gmo_${doc.documentId}`, signUrl: `https://agree.example/${doc.documentId}` };
    },
    async getStatus(requestId) {
      return { completed: false, signedCount: 0, totalSigners: 1 };
    },
    async downloadSigned(requestId) {
      return { pdfBase64: '', certificateChain: [] };
    },
    legalEffectCheck() {
      return checkArticle3({
        signatureType: 'witness',
        twoFactorAuth: true,
        hashAlgorithm: 'SHA-256',
        timestampApplied: true,
        keyAlgorithm: 'RSA-2048',
        certifiedTSA: true,
      });
    },
  };
}

/**
 * クラウドサイン (弁護士ドットコム) アダプタ
 * - 立会人型がメイン
 * - 国内法律事務所と連携した法的根拠の説明資料が充実
 */
export function createCloudSignAdapter(config: {
  accessToken: string;
  endpoint?: string;
}): ESealAdapter {
  return {
    vendor: 'cloudsign',
    async createSigningRequest(doc) {
      return { requestId: `cs_${doc.documentId}`, signUrl: `https://cloudsign.example/${doc.documentId}` };
    },
    async getStatus(requestId) {
      return { completed: false, signedCount: 0, totalSigners: 1 };
    },
    async downloadSigned(requestId) {
      return { pdfBase64: '', certificateChain: [] };
    },
    legalEffectCheck() {
      return checkArticle3({
        signatureType: 'witness',
        twoFactorAuth: true,
        hashAlgorithm: 'SHA-256',
        timestampApplied: true,
        keyAlgorithm: 'RSA-2048',
        certifiedTSA: true,
      });
    },
  };
}

/**
 * DocuSign アダプタ (グローバル標準)
 * - 当事者型もサポート (有償オプション)
 * - eIDAS / ESIGN Act 等のグローバル法対応
 */
export function createDocuSignAdapter(config: {
  integrationKey: string;
  userId: string;
  accountId: string;
  endpoint?: string;
}): ESealAdapter {
  return {
    vendor: 'docusign',
    async createSigningRequest(doc) {
      return { requestId: `ds_${doc.documentId}`, signUrl: `https://docusign.example/${doc.documentId}` };
    },
    async getStatus(requestId) {
      return { completed: false, signedCount: 0, totalSigners: 1 };
    },
    async downloadSigned(requestId) {
      return { pdfBase64: '', certificateChain: [] };
    },
    legalEffectCheck() {
      return checkArticle3({
        signatureType: 'agent',
        twoFactorAuth: true,
        hashAlgorithm: 'SHA-256',
        timestampApplied: true,
        keyAlgorithm: 'ECDSA-P256',
        certifiedTSA: true,
      });
    },
  };
}

// ============================================================================
// 印影 SVG ジェネレータ
// ============================================================================

/**
 * 印影 SVG 生成。日本の印鑑文化に準拠した寸法・配置。
 *
 *  - 角印: 24mm 角 (会社印として一般的)
 *  - 丸印 (代表者印): 18mm 直径
 *  - 銀行印: 16mm 直径
 *  - 認印: 12mm 直径
 *  - 実印: 個人 16mm 直径 / 法人代表者 18mm 直径
 */
export function generateSealImprintSvg(opts: SealImprintOptions): string {
  const size = opts.sizePx ?? 96;
  const color = opts.color ?? '#C8102E';
  const border = opts.borderWidthPx ?? 3;
  const text = opts.text;
  const isSquare = opts.kind === 'kakuin';
  const vertical = opts.vertical ?? !isSquare;

  // 文字配置: 角印は3〜4文字を縦2行/横2列、丸印は外周配置
  const half = size / 2;
  const innerR = half - border * 2;

  if (isSquare) {
    // 角印
    const fontSize = Math.floor((size - border * 4) / Math.ceil(Math.sqrt(text.length)));
    return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
  <rect x="${border}" y="${border}" width="${size - border * 2}" height="${size - border * 2}"
        fill="none" stroke="${color}" stroke-width="${border}"/>
  <text x="${half}" y="${half}" font-size="${fontSize}" fill="${color}"
        font-family="serif" text-anchor="middle" dominant-baseline="middle"
        writing-mode="${vertical ? 'tb-rl' : 'lr-tb'}">${escapeXml(text)}</text>
</svg>`;
  }

  // 丸印
  const fontSize = Math.floor(innerR * 0.4);
  return `<svg xmlns="http://www.w3.org/2000/svg" width="${size}" height="${size}" viewBox="0 0 ${size} ${size}">
  <circle cx="${half}" cy="${half}" r="${half - border}" fill="none" stroke="${color}" stroke-width="${border}"/>
  <text x="${half}" y="${half}" font-size="${fontSize}" fill="${color}"
        font-family="serif" text-anchor="middle" dominant-baseline="middle"
        writing-mode="${vertical ? 'tb-rl' : 'lr-tb'}">${escapeXml(text)}</text>
</svg>`;
}

function escapeXml(s: string): string {
  return s.replace(/[<>&'"]/g, (c) =>
    ({ '<': '&lt;', '>': '&gt;', '&': '&amp;', "'": '&apos;', '"': '&quot;' }[c] as string),
  );
}

// ============================================================================
// 印紙税自動判定 (1号〜20号文書)
// ============================================================================

/**
 * 印紙税額表 (税額は階段の「上端(この金額まで)」と組で持つ)。
 *
 * ★2026-08-01 是正 (一次情報から転記し直した):
 *   従来の実装は上位の階段が欠落しており、印紙税を【過少】に計算していた。
 *   印紙税の不足は過怠税 (不足額とその2倍に相当する金額の合計 = 本税の3倍) の対象になるため、
 *   「安く出る」ことは安全側ではなく実害である。実測した乖離:
 *     ・第2号文書 (請負) 契約金額 20億円  … 正 40万円 / 旧実装 20万円 (半額)
 *     ・第2号文書 (請負) 契約金額 60億円  … 正 60万円 / 旧実装 20万円 (1/3)
 *     ・第2号文書 1万円未満は【非課税】だが旧実装は 200円を課していた (過大)
 *     ・第17号文書 (受取書) 1億円        … 正 2万円 / 旧実装 600円 (33分の1)
 *   出典: 国税庁 タックスアンサー No.7140 / No.7141 (2026-08-01 本文で実確認)。
 *   数値は lib/japan/legal-values/approval-workflow.legal.json に一次情報の出典付きで保持し、
 *   _verify/approval-workflow.verify.mjs が同 JSON と本実装を突合する。
 */
const STAMP_TAX_DOC2_BRACKETS: ReadonlyArray<{ upperJpy: number | null; taxJpy: number }> = [
  { upperJpy: 1_000_000, taxJpy: 200 },
  { upperJpy: 2_000_000, taxJpy: 400 },
  { upperJpy: 3_000_000, taxJpy: 1_000 },
  { upperJpy: 5_000_000, taxJpy: 2_000 },
  { upperJpy: 10_000_000, taxJpy: 10_000 },
  { upperJpy: 50_000_000, taxJpy: 20_000 },
  { upperJpy: 100_000_000, taxJpy: 60_000 },
  { upperJpy: 500_000_000, taxJpy: 100_000 },
  { upperJpy: 1_000_000_000, taxJpy: 200_000 },
  { upperJpy: 5_000_000_000, taxJpy: 400_000 },
  { upperJpy: null, taxJpy: 600_000 },
];

const STAMP_TAX_DOC17_BRACKETS: ReadonlyArray<{ upperJpy: number | null; taxJpy: number }> = [
  { upperJpy: 1_000_000, taxJpy: 200 },
  { upperJpy: 2_000_000, taxJpy: 400 },
  { upperJpy: 3_000_000, taxJpy: 600 },
  { upperJpy: 5_000_000, taxJpy: 1_000 },
  { upperJpy: 10_000_000, taxJpy: 2_000 },
  { upperJpy: 20_000_000, taxJpy: 4_000 },
  { upperJpy: 30_000_000, taxJpy: 6_000 },
  { upperJpy: 50_000_000, taxJpy: 10_000 },
  { upperJpy: 100_000_000, taxJpy: 20_000 },
  { upperJpy: 200_000_000, taxJpy: 40_000 },
  { upperJpy: 300_000_000, taxJpy: 60_000 },
  { upperJpy: 500_000_000, taxJpy: 100_000 },
  { upperJpy: 1_000_000_000, taxJpy: 150_000 },
  { upperJpy: null, taxJpy: 200_000 },
];

/** 1万円未満は非課税 (第2号文書)。国税庁 No.7140。 */
const STAMP_TAX_DOC2_NON_TAXABLE_UNDER = 10_000;
/** 5万円未満は非課税 (第17号文書)。国税庁 No.7141。 */
const STAMP_TAX_DOC17_NON_TAXABLE_UNDER = 50_000;

function lookupStampBracket(
  brackets: ReadonlyArray<{ upperJpy: number | null; taxJpy: number }>,
  amountYen: number,
): number {
  for (const b of brackets) {
    if (b.upperJpy === null || amountYen <= b.upperJpy) return b.taxJpy;
  }
  // 表の最終行は upperJpy=null のため到達しないが、型安全のため最終段を返す。
  return brackets[brackets.length - 1].taxJpy;
}

/**
 * 紙の契約書なら必要だが、電子契約なら印紙税不要 (国税庁見解 No.7100)。
 * 本関数は「もし紙だったらいくらか」を返す (社内コスト試算用)。
 *
 * @param input.contractAmountYen 契約金額 (円)。未指定/0 は「契約金額の記載のないもの」として扱う。
 */
export function calcStampTax(input: {
  documentType: SignableDocument['documentType'];
  contractAmountYen?: number;
}): { stampArticleNo: number | null; taxYen: number; electronicExempt: boolean } {
  const { documentType, contractAmountYen } = input;
  const electronicExempt = true; // 電子契約(電磁的記録)は課税文書の作成に当たらない

  // 第2号文書 (請負に関する契約書)
  if (documentType === 'contract') {
    // 契約金額の記載のないものは 200円 (国税庁 No.7140)。
    if (contractAmountYen === undefined) return { stampArticleNo: 2, taxYen: 200, electronicExempt };
    if (contractAmountYen < STAMP_TAX_DOC2_NON_TAXABLE_UNDER) {
      return { stampArticleNo: 2, taxYen: 0, electronicExempt };
    }
    return { stampArticleNo: 2, taxYen: lookupStampBracket(STAMP_TAX_DOC2_BRACKETS, contractAmountYen), electronicExempt };
  }

  // 第17号文書 (売上代金に係る金銭又は有価証券の受取書)
  if (documentType === 'receipt') {
    if (contractAmountYen === undefined) return { stampArticleNo: 17, taxYen: 200, electronicExempt };
    if (contractAmountYen < STAMP_TAX_DOC17_NON_TAXABLE_UNDER) {
      return { stampArticleNo: 17, taxYen: 0, electronicExempt };
    }
    return { stampArticleNo: 17, taxYen: lookupStampBracket(STAMP_TAX_DOC17_BRACKETS, contractAmountYen), electronicExempt };
  }

  return { stampArticleNo: null, taxYen: 0, electronicExempt };
}

// ============================================================================
// PAdES-LTV (Long Term Validation) ヘルパ
// ============================================================================

/**
 * 長期署名検証 (LTV) に必要な要素が揃っているか確認。
 * 電子証明書の有効期限切れ後も検証可能にするための要件。
 */
export function checkPadesLTV(input: {
  hasSignatureTimestamp: boolean;
  hasArchiveTimestamp: boolean;
  hasOcspResponse: boolean;
  hasCrlData: boolean;
  hasCertificateChain: boolean;
}): { valid: boolean; missing: string[] } {
  const missing: string[] = [];
  if (!input.hasSignatureTimestamp) missing.push('署名タイムスタンプ');
  if (!input.hasArchiveTimestamp) missing.push('アーカイブタイムスタンプ (10年毎更新)');
  if (!input.hasOcspResponse && !input.hasCrlData) missing.push('OCSP応答 または CRLデータ');
  if (!input.hasCertificateChain) missing.push('証明書チェーン');
  return { valid: missing.length === 0, missing };
}

// ============================================================================
// Default exports
// ============================================================================

export const ESEAL_VENDORS_JP_LABELS: Record<ESealVendor, string> = {
  gmo_agree: 'GMO電子印鑑Agree',
  cloudsign: 'クラウドサイン',
  docusign: 'DocuSign',
  adobe_sign: 'Adobe Acrobat Sign',
  freee_sign: 'freeeサイン',
  shachihata: 'Shachihata Cloud',
  internal: '自社内製',
};

export const STAMP_TAX_REFERENCE_URL =
  'https://www.nta.go.jp/taxes/shiraberu/taxanswer/inshi/inshi301.htm';
export const ESIGN_LAW_ARTICLE3_REFERENCE_URL =
  'https://elaws.e-gov.go.jp/document?lawid=412AC0000000102';
