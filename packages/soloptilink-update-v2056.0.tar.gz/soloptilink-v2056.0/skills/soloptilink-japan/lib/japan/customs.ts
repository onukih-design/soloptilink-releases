/**
 * SoloptiLinkAI Phase 43-IT — 関税法 / 通関手続 (Customs)
 *
 * 関税法 + 関税定率法 + HSコード + NACCS 連携。
 *
 * カバー範囲:
 *  - HSコード (Harmonized System) 6桁/9桁 体系
 *  - 関税率 (基本税率 / 暫定税率 / WTO協定 / EPA)
 *  - 通関手続 (輸入申告/輸出申告/特例輸入)
 *  - AEO (Authorized Economic Operator) 制度
 *  - NACCS (Nippon Automated Cargo and Port Consolidated System)
 *  - 関税課税価格 (CIF + 加算要素)
 *  - 原産地証明 (CO/特定原産地証明書)
 *  - 関税分類事前教示 + アドバンスルーリング
 *  - 不服申立 (税関長 → 審査請求 → 訴訟)
 */

// HSコード (Harmonized System) - 上位レベル抜粋
export const HS_CHAPTERS = [
  { id: "01-05", name: "動物及び動物性生産品" },
  { id: "06-14", name: "植物性生産品" },
  { id: "15", name: "動物性または植物性の油脂" },
  { id: "16-24", name: "調製食料品、飲料、たばこ" },
  { id: "25-27", name: "鉱物性生産品 (原油/天然ガス/鉱石)" },
  { id: "28-38", name: "化学工業生産品" },
  { id: "39-40", name: "プラスチック・ゴム製品" },
  { id: "41-43", name: "皮革・毛皮製品" },
  { id: "44-46", name: "木材・木製品" },
  { id: "47-49", name: "紙・紙製品・印刷物" },
  { id: "50-63", name: "繊維・衣類" },
  { id: "64-67", name: "履物・帽子・傘" },
  { id: "68-70", name: "石材・セメント・ガラス" },
  { id: "71", name: "貴金属・宝石" },
  { id: "72-83", name: "卑金属・金属製品" },
  { id: "84-85", name: "機械・電気機器" },
  { id: "86-89", name: "車両・航空機・船舶" },
  { id: "90-92", name: "光学・医療機器・精密機器" },
  { id: "93", name: "武器・銃砲" },
  { id: "94-96", name: "雑貨" },
  { id: "97", name: "美術品・骨董品" },
] as const;

// 関税率の種類
export type DutyRateKind =
  | "basic" // 基本税率
  | "temporary" // 暫定税率
  | "wto" // WTO協定税率
  | "epa_cptpp" // CPTPP (TPP11)
  | "epa_rcep" // RCEP
  | "epa_japan_eu" // 日EU EPA
  | "epa_japan_us" // 日米貿易協定
  | "epa_japan_uk" // 日英EPA
  | "epa_other" // その他EPA
  | "preferential"; // 一般特恵 (GSP)

export interface DutyRate {
  hs_code: string;
  kind: DutyRateKind;
  rate_percent?: number; // 従価税
  rate_amount?: { yen_per_unit: number; unit: string }; // 従量税
  effective_from: string;
  source: string; // "関税定率法 別表" 等
}

// 課税価格 (CIF) 計算
export interface CifInput {
  fob_amount_jpy: number; // 本船渡し価格
  freight_jpy: number; // 運賃
  insurance_jpy: number; // 保険料
  // 加算要素 (関税定率法 第4条)
  packing_charges?: number;
  selling_commission?: number;
  buyer_supplied_materials?: number; // 買手が無償提供したもの
  royalty_license_fee?: number; // 売手への権利使用料 (条件: 当該輸入貨物の取引に関連)
  proceeds_remitted_to_seller?: number; // 売手への利益分配
  // 控除要素
  inland_transport_after_arrival?: number; // 輸入港到着後の内国運賃
  duty_taxes_in_japan?: number; // 日本国内税
}

export interface CifResult {
  cif_value_jpy: number;
  add_back_total: number;
  deduction_total: number;
  taxable_value_jpy: number;
  breakdown: { item: string; amount: number; sign: "+" | "-" }[];
}

export function calcTaxableValue(input: CifInput): CifResult {
  const breakdown: CifResult["breakdown"] = [];
  let taxable = input.fob_amount_jpy;
  breakdown.push({ item: "FOB価格", amount: input.fob_amount_jpy, sign: "+" });

  taxable += input.freight_jpy;
  breakdown.push({ item: "運賃", amount: input.freight_jpy, sign: "+" });
  taxable += input.insurance_jpy;
  breakdown.push({ item: "保険料", amount: input.insurance_jpy, sign: "+" });

  const cif = taxable;
  const adds = [
    { item: "包装費", amount: input.packing_charges ?? 0 },
    { item: "販売手数料", amount: input.selling_commission ?? 0 },
    { item: "買手提供物品/原材料", amount: input.buyer_supplied_materials ?? 0 },
    { item: "ロイヤルティ等", amount: input.royalty_license_fee ?? 0 },
    { item: "売手への利益分配", amount: input.proceeds_remitted_to_seller ?? 0 },
  ];
  let addTotal = 0;
  for (const a of adds) {
    if (a.amount > 0) {
      taxable += a.amount;
      breakdown.push({ item: a.item, amount: a.amount, sign: "+" });
      addTotal += a.amount;
    }
  }

  const deds = [
    { item: "輸入港到着後の内国運賃", amount: input.inland_transport_after_arrival ?? 0 },
    { item: "日本国内税", amount: input.duty_taxes_in_japan ?? 0 },
  ];
  let dedTotal = 0;
  for (const d of deds) {
    if (d.amount > 0) {
      taxable -= d.amount;
      breakdown.push({ item: d.item, amount: d.amount, sign: "-" });
      dedTotal += d.amount;
    }
  }

  return {
    cif_value_jpy: cif,
    add_back_total: addTotal,
    deduction_total: dedTotal,
    taxable_value_jpy: Math.max(0, taxable),
    breakdown,
  };
}

// 関税 + 消費税 計算
export interface DutyAndTaxResult {
  taxable_value_jpy: number;
  duty_rate_percent: number;
  duty_amount_jpy: number;
  consumption_tax_base: number;
  consumption_tax_amount_jpy: number;
  local_consumption_tax_amount_jpy: number;
  total_tax_jpy: number;
}

export function calcDutyAndTax(taxableValue: number, dutyRatePercent: number): DutyAndTaxResult {
  const duty = Math.floor(taxableValue * (dutyRatePercent / 100) / 100) * 100; // 100円未満切り捨て
  const ctBase = Math.floor((taxableValue + duty) / 1000) * 1000; // 1,000円未満切り捨て
  const ct = Math.floor(ctBase * 0.078); // 国分 7.8%
  const lct = Math.floor(ct * 22 / 78); // 地方分 2.2% (国の22/78)
  return {
    taxable_value_jpy: taxableValue,
    duty_rate_percent: dutyRatePercent,
    duty_amount_jpy: duty,
    consumption_tax_base: ctBase,
    consumption_tax_amount_jpy: ct,
    local_consumption_tax_amount_jpy: lct,
    total_tax_jpy: duty + ct + lct,
  };
}

// 通関業者
export interface CustomsBroker {
  id: string;
  name: string;
  permit_no: string;
  customs_office: string; // 所属税関
  is_aeo_certified: boolean; // AEO 認定
  naccs_code: string;
}

// AEO (Authorized Economic Operator) 制度
export type AeoType =
  | "importer" // 認定通関業者
  | "exporter" // 特定輸出者
  | "customs_broker" // 認定通関業者
  | "warehouse" // 特定保税承認者
  | "manufacturer" // 認定製造者
  | "carrier"; // 認定運送業者

export interface AeoBenefit {
  type: AeoType;
  benefits: string[];
  requirements: string[];
}

export const AEO_BENEFITS: AeoBenefit[] = [
  {
    type: "importer",
    benefits: ["保税地域経由なしで貨物引取可", "納期限延長 (3ヶ月)", "簡易な貨物検査"],
    requirements: ["コンプライアンス・プログラム策定", "貨物のセキュリティ管理", "3年以上の通関実績"],
  },
  {
    type: "exporter",
    benefits: ["保税地域搬入なしで輸出申告可", "船積後申告可"],
    requirements: ["輸出管理体制整備", "セキュリティ体制"],
  },
  {
    type: "customs_broker",
    benefits: ["申告事項簡素化", "事前申告可"],
    requirements: ["通関業の許可", "コンプライアンス体制"],
  },
  {
    type: "warehouse",
    benefits: ["蔵置期間 2年 (通常は2ヶ月)"],
    requirements: ["保税蔵置場の許可", "セキュリティ管理"],
  },
  {
    type: "manufacturer",
    benefits: ["工場で輸入手続完結"],
    requirements: ["保税工場の許可"],
  },
  {
    type: "carrier",
    benefits: ["危険物積込時の手続簡素化"],
    requirements: ["航空/海上運送の許可"],
  },
];

// 原産地証明書
export type CountryOfOrigin = string; // ISO 3166-1 alpha-2 推奨 (JP/CN/US 等)

export interface CertificateOfOrigin {
  certificate_no: string;
  issuer: "JCCI" | "JETRO" | "Customs" | "Self_Certification";
  issue_date: string;
  importer_country: CountryOfOrigin;
  exporter_country: CountryOfOrigin;
  origin_country: CountryOfOrigin;
  hs_code: string;
  goods_description: string;
  rules_of_origin: "wholly_obtained" | "substantial_transformation" | "value_added"; // 原産地規則
  epa_basis?: "RCEP" | "CPTPP" | "JEU" | "JUS" | "JUK" | "ASEAN" | "Other";
  is_valid: boolean;
}

export function isCoValid(co: CertificateOfOrigin, asOf: Date = new Date()): boolean {
  // 原産地証明は通常 1年以内 (発給日から)
  const issued = new Date(co.issue_date);
  const oneYearLater = new Date(issued);
  oneYearLater.setFullYear(oneYearLater.getFullYear() + 1);
  return co.is_valid && asOf < oneYearLater;
}

// 事前教示制度
export interface AdvanceRulingRequest {
  request_id: string;
  applicant: string;
  goods_name: string;
  proposed_hs_code: string;
  goods_description: string;
  product_specifications: string;
  attached_samples: boolean;
  customs_office: string;
}

export interface AdvanceRuling {
  request_id: string;
  ruling_hs_code: string;
  ruling_date: string;
  effective_period_years: 3; // 通常3年
  reasoning: string;
  is_disclosed: boolean; // 公表事例の場合
}

// 不服申立 (関税法 第89条)
export type AppealStage =
  | "office_review" // 税関長に対する審査の請求
  | "national_tax_tribunal" // 国税不服審判所
  | "court"; // 訴訟

export interface AppealDeadline {
  stage: AppealStage;
  deadline_days: number;
}

export const APPEAL_DEADLINES: AppealDeadline[] = [
  { stage: "office_review", deadline_days: 90 }, // 処分を知った日の翌日から3ヶ月
  { stage: "national_tax_tribunal", deadline_days: 90 },
  { stage: "court", deadline_days: 180 }, // 6ヶ月
];

export function calcAppealDueDate(stage: AppealStage, dispositionDate: string): string {
  const days = APPEAL_DEADLINES.find((d) => d.stage === stage)?.deadline_days ?? 90;
  const due = new Date(dispositionDate);
  due.setDate(due.getDate() + days);
  return due.toISOString().slice(0, 10);
}
