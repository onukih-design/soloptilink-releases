/**
 * estimates.ts — 建築概算見積もりエンジン (Phase 9)
 *
 * 用途:
 *   1. 坪単価ベースの粗見積 (初期提案用)
 *   2. 工種別積算 (設計段階の詳細見積)
 *   3. 国交省公共建築工事積算基準に準拠した仮設/共通費算定
 *   4. 消費税 (軽減税率なし = 10% / インボイス登録番号)
 *
 * 単価 DB は estimates/unit_prices.json を fs 経由 or Static import で読む想定。
 * 実ランタイムでは JSON を渡す形にして、Node/Edge/ブラウザを問わず動作するよう設計。
 *
 * 使い方:
 *   import unitPrices from '@/../estimates/unit_prices.json';
 *   import { calcRoughEstimate, calcDetailedEstimate, buildBreakdown } from '@/lib/japan/estimates';
 *   const rough = calcRoughEstimate({ structure: 'wood', floorAreaM2: 120, grade: 'mid' });
 *   const detail = calcDetailedEstimate(unitPrices, [{ category: 'frame_wood', item: 'post_105', qty: 2.5 }, ...]);
 */

// =============================================================================
// 1. 坪単価ベースの粗見積
// =============================================================================

export type StructureKind = 'wood' | 'steel' | 'rc' | 'srcshort';
export type GradeLevel = 'economy' | 'mid' | 'high' | 'luxury';
export type BuildingUse = 'detached' | 'apartment' | 'office' | 'store' | 'warehouse' | 'factory' | 'medical';

/**
 * 坪単価マトリクス (2024年 首都圏平均の参考値)
 *   単位: 円/坪 (1坪 = 3.3057㎡)
 */
export const TSUBO_UNIT_PRICE: Readonly<Record<StructureKind, Readonly<Record<GradeLevel, number>>>> = Object.freeze({
  wood: { economy: 600000, mid: 800000, high: 1100000, luxury: 1500000 },
  steel: { economy: 750000, mid: 950000, high: 1300000, luxury: 1800000 },
  rc: { economy: 900000, mid: 1150000, high: 1500000, luxury: 2200000 },
  srcshort: { economy: 1100000, mid: 1400000, high: 1800000, luxury: 2500000 },
});

/** 用途別の補正係数 (住宅=1.0基準) */
export const USE_COEFFICIENT: Readonly<Record<BuildingUse, number>> = Object.freeze({
  detached: 1.00,
  apartment: 0.95,
  office: 0.90,
  store: 1.10,
  warehouse: 0.60,
  factory: 0.75,
  medical: 1.40,
});

export interface RoughEstimateInput {
  structure: StructureKind;
  use: BuildingUse;
  floorAreaM2: number;
  grade: GradeLevel;
  /** 地域係数 */
  regionCoef?: number;
  /** 設計料率 (0.04〜0.075) - 告示15号 */
  designFeeRate?: number;
  /** 消費税率 (既定 0.10) */
  taxRate?: number;
}

export interface RoughEstimateOutput {
  input: RoughEstimateInput;
  tsubo: number;           // 坪数
  tsuboUnit: number;       // 坪単価
  constructionCost: number;
  designCost: number;
  totalExcludingTax: number;
  tax: number;
  totalIncludingTax: number;
  breakdown: Array<{ label: string; amount: number }>;
}

const TSUBO_M2 = 3.3057851;

export function calcRoughEstimate(input: RoughEstimateInput): RoughEstimateOutput {
  const { structure, use, floorAreaM2, grade, regionCoef = 1.0, designFeeRate = 0.055, taxRate = 0.10 } = input;
  if (!Number.isFinite(floorAreaM2) || floorAreaM2 <= 0) throw new Error('floorAreaM2 は正数でなければならない');
  if (designFeeRate < 0 || designFeeRate > 0.15) throw new Error('designFeeRate は 0〜0.15 の範囲');
  const tsubo = floorAreaM2 / TSUBO_M2;
  const base = TSUBO_UNIT_PRICE[structure][grade];
  const tsuboUnit = Math.round(base * USE_COEFFICIENT[use] * regionCoef);
  const constructionCost = Math.round(tsubo * tsuboUnit);
  const designCost = Math.round(constructionCost * designFeeRate);
  const totalExcludingTax = constructionCost + designCost;
  const tax = Math.round(totalExcludingTax * taxRate);
  const totalIncludingTax = totalExcludingTax + tax;
  return {
    input,
    tsubo: Math.round(tsubo * 100) / 100,
    tsuboUnit,
    constructionCost,
    designCost,
    totalExcludingTax,
    tax,
    totalIncludingTax,
    breakdown: [
      { label: '建築本体工事費', amount: constructionCost },
      { label: '設計監理料', amount: designCost },
      { label: '消費税', amount: tax },
    ],
  };
}

// =============================================================================
// 2. 工種別積算 (JSON 単価 DB ベース)
// =============================================================================

export interface UnitPriceRow {
  name_ja: string;
  unit: string;
  price: number;
  notes?: string;
}

export interface UnitPriceDb {
  schema_version: string;
  source: string;
  effective_date: string;
  note?: string;
  categories: Record<string, {
    label_ja: string;
    items: Record<string, UnitPriceRow>;
  }>;
  overheads?: Record<string, { label_ja: string; rate?: number; rate_low_cost?: number; rate_mid_cost?: number; rate_high_cost?: number; notes?: string }>;
  regional_coef?: Record<string, number | string>;
}

export interface EstimateLineInput {
  category: string;
  item: string;
  qty: number;
  /** 補正 (例: 0.9 で10%引き、1.1 で10%割増) */
  multiplier?: number;
  /** 備考上書き */
  remarks?: string;
}

export interface EstimateLineOutput {
  category: string;
  categoryLabel: string;
  item: string;
  itemLabel: string;
  unit: string;
  qty: number;
  unitPrice: number;
  multiplier: number;
  lineTotal: number;
  remarks?: string;
  warnings?: string[];
}

export interface DetailedEstimateOutput {
  lines: EstimateLineOutput[];
  subtotalByCategory: Array<{ category: string; label: string; subtotal: number }>;
  subtotal: number;
  /** 工事費に対する共通仮設・現場管理費・一般管理費の積上げ */
  overheads: Array<{ label: string; rate: number; amount: number }>;
  taxableTotal: number;
  tax: number;
  grandTotal: number;
  warnings: string[];
}

/**
 * 詳細積算を計算する。
 *  - 単価 DB から品目を引き、数量×単価×補正 で行合計
 *  - 行合計を category で集計
 *  - 共通仮設/現場管理費/一般管理費を工事費に積上げ
 *  - 消費税を計算
 */
export function calcDetailedEstimate(
  db: UnitPriceDb,
  lines: EstimateLineInput[],
  opts: {
    contractorMarginRate?: number; // 既定 0.12
    siteManagementRate?: number;    // 既定 0.07
    commonTemporaryRate?: number;   // 既定 0.05 (line で指定していない場合)
    taxRate?: number;                // 既定 0.10
    regionCoef?: number;             // 既定 1.0
  } = {},
): DetailedEstimateOutput {
  const { contractorMarginRate = 0.12, siteManagementRate = 0.07, commonTemporaryRate = 0.05, taxRate = 0.10, regionCoef = 1.0 } = opts;
  const outLines: EstimateLineOutput[] = [];
  const warnings: string[] = [];

  for (const li of lines) {
    const cat = db.categories[li.category];
    if (!cat) {
      warnings.push(`カテゴリ「${li.category}」が単価DBに存在しない`);
      continue;
    }
    const item = cat.items[li.item];
    if (!item) {
      warnings.push(`品目「${li.category}/${li.item}」が単価DBに存在しない`);
      continue;
    }
    const mul = li.multiplier ?? 1.0;
    if (!Number.isFinite(li.qty) || li.qty < 0) {
      warnings.push(`数量が不正: ${li.category}/${li.item} qty=${li.qty}`);
      continue;
    }
    const unitPrice = Math.round(item.price * regionCoef);
    const lineTotal = Math.round(li.qty * unitPrice * mul);
    const w: string[] = [];
    if (mul < 0.5 || mul > 2.0) w.push(`補正係数 ${mul} が極端。仕様書で理由を明記してください`);
    if (li.qty === 0) w.push('数量0');
    outLines.push({
      category: li.category,
      categoryLabel: cat.label_ja,
      item: li.item,
      itemLabel: item.name_ja,
      unit: item.unit,
      qty: li.qty,
      unitPrice,
      multiplier: mul,
      lineTotal,
      remarks: li.remarks ?? item.notes,
      warnings: w.length ? w : undefined,
    });
  }

  // カテゴリ集計
  const byCatMap = new Map<string, { label: string; subtotal: number }>();
  for (const l of outLines) {
    const prev = byCatMap.get(l.category);
    if (prev) prev.subtotal += l.lineTotal;
    else byCatMap.set(l.category, { label: l.categoryLabel, subtotal: l.lineTotal });
  }
  const subtotalByCategory = Array.from(byCatMap.entries()).map(([category, v]) => ({ category, label: v.label, subtotal: v.subtotal }));
  const subtotal = outLines.reduce((s, l) => s + l.lineTotal, 0);

  // 共通仮設が line に含まれていない場合、subtotal に対して加算
  const hasCommonTempLines = outLines.some(l => l.category === 'common_temporary');
  const overheads: Array<{ label: string; rate: number; amount: number }> = [];
  let taxable = subtotal;
  if (!hasCommonTempLines) {
    const amt = Math.round(subtotal * commonTemporaryRate);
    overheads.push({ label: '共通仮設 (率計)', rate: commonTemporaryRate, amount: amt });
    taxable += amt;
  }
  {
    const amt = Math.round(taxable * siteManagementRate);
    overheads.push({ label: '現場管理費', rate: siteManagementRate, amount: amt });
    taxable += amt;
  }
  {
    const amt = Math.round(taxable * contractorMarginRate);
    overheads.push({ label: '一般管理費 (請負経費)', rate: contractorMarginRate, amount: amt });
    taxable += amt;
  }
  const tax = Math.round(taxable * taxRate);
  const grandTotal = taxable + tax;

  return {
    lines: outLines,
    subtotalByCategory,
    subtotal,
    overheads,
    taxableTotal: taxable,
    tax,
    grandTotal,
    warnings,
  };
}

// =============================================================================
// 3. 建物仕様から標準数量を推定 (粗見積→詳細見積のブリッジ)
// =============================================================================

export interface StandardQuantityInput {
  floorAreaM2: number;
  stories: number;
  structure: StructureKind;
  useType: BuildingUse;
  perimeterM?: number; // 外周 (不明なら sqrt(area)×4 で推定)
  eaveHeightM?: number;
}

/**
 * 建物規模から工種別の標準数量を推定する (±20% の粗推定)
 *   実際の数量は図面から拾い出すのが原則だが、初期提案では本関数の推定値を使う
 */
export function estimateStandardQuantities(input: StandardQuantityInput): EstimateLineInput[] {
  const { floorAreaM2, stories, structure, useType, perimeterM, eaveHeightM = 3 * stories } = input;
  const footprint = floorAreaM2 / stories;
  const peri = perimeterM ?? Math.sqrt(footprint) * 4;
  const wallAreaExt = peri * eaveHeightM;
  const roofArea = footprint * 1.1; // 勾配補正
  const lines: EstimateLineInput[] = [];

  // 共通仮設
  lines.push({ category: 'common_temporary', item: 'scaffold_frame', qty: wallAreaExt });
  if (eaveHeightM > 10) lines.push({ category: 'common_temporary', item: 'safety_net', qty: wallAreaExt * 0.3 });

  // 土工事 + 基礎
  if (structure === 'wood' || structure === 'steel') {
    const foundationConcVol = footprint * 0.15;
    lines.push({ category: 'earthwork', item: 'excavation_backhoe', qty: footprint * 0.5 });
    lines.push({ category: 'earthwork', item: 'backfill', qty: footprint * 0.3 });
    lines.push({ category: 'foundation', item: 'spread_footing_concrete', qty: foundationConcVol });
    lines.push({ category: 'foundation', item: 'rebar_D13', qty: foundationConcVol * 0.08 });
    lines.push({ category: 'foundation', item: 'formwork_foundation', qty: peri * 0.6 * 2 });
  } else {
    // RC/SRC: 杭を想定
    lines.push({ category: 'foundation', item: 'pile_PHC', qty: footprint * 0.3 });
    lines.push({ category: 'foundation', item: 'spread_footing_concrete', qty: footprint * 0.35 });
    lines.push({ category: 'foundation', item: 'rebar_D16', qty: floorAreaM2 * 0.12 });
  }

  // 躯体
  if (structure === 'wood') {
    lines.push({ category: 'frame_wood', item: 'post_105', qty: floorAreaM2 * 0.015 });
    lines.push({ category: 'frame_wood', item: 'beam_sugi', qty: floorAreaM2 * 0.03 });
    lines.push({ category: 'frame_wood', item: 'plywood_12', qty: wallAreaExt + floorAreaM2 });
    lines.push({ category: 'frame_wood', item: 'insulation_wool_100', qty: wallAreaExt + roofArea });
  } else if (structure === 'steel') {
    lines.push({ category: 'frame_steel', item: 'column_H400', qty: floorAreaM2 * 0.05 });
    lines.push({ category: 'frame_steel', item: 'beam_H400', qty: floorAreaM2 * 0.07 });
    lines.push({ category: 'frame_steel', item: 'fireproof_coating', qty: floorAreaM2 * 0.6 });
    lines.push({ category: 'frame_steel', item: 'deck_plate', qty: floorAreaM2 });
  } else {
    lines.push({ category: 'frame_rc', item: 'concrete_fc24', qty: floorAreaM2 * 0.35 });
    lines.push({ category: 'frame_rc', item: 'formwork_column', qty: floorAreaM2 * 0.4 });
    lines.push({ category: 'frame_rc', item: 'formwork_beam', qty: floorAreaM2 * 0.3 });
    lines.push({ category: 'frame_rc', item: 'formwork_slab', qty: floorAreaM2 });
  }

  // 屋根
  lines.push({ category: 'roof', item: 'galvalume', qty: roofArea });
  lines.push({ category: 'roof', item: 'rain_gutter', qty: peri });

  // 外壁
  lines.push({ category: 'exterior', item: 'siding_18mm', qty: wallAreaExt });

  // 建具 (床面積比で推定)
  lines.push({ category: 'windows', item: 'aluminum_window', qty: floorAreaM2 * 0.18 });
  lines.push({ category: 'windows', item: 'steel_door', qty: Math.max(1, Math.floor(floorAreaM2 / 100)) });

  // 内装
  lines.push({ category: 'interior', item: 'plasterboard_12.5', qty: floorAreaM2 * 2.5 });
  lines.push({ category: 'interior', item: 'wallpaper_1000', qty: floorAreaM2 * 2.5 });
  if (useType === 'detached') {
    lines.push({ category: 'interior', item: 'floor_フローリング', qty: floorAreaM2 * 0.7 });
  }

  // 設備 (簡易)
  if (useType === 'detached' || useType === 'apartment') {
    lines.push({ category: 'plumbing', item: 'toilet_tank', qty: stories });
    lines.push({ category: 'plumbing', item: 'bathroom_unit', qty: 1 });
    lines.push({ category: 'plumbing', item: 'kitchen_system', qty: 1 });
    lines.push({ category: 'plumbing', item: 'water_heater_eco', qty: 1 });
  }
  lines.push({ category: 'electrical', item: 'distribution_box', qty: 1 });
  lines.push({ category: 'electrical', item: 'outlet_2p', qty: Math.round(floorAreaM2 * 0.15) });
  lines.push({ category: 'electrical', item: 'led_down', qty: Math.round(floorAreaM2 * 0.10) });
  lines.push({ category: 'electrical', item: 'smoke_detector', qty: stories * 2 });
  lines.push({ category: 'hvac', item: 'ac_wall_4.0kW', qty: stories });
  lines.push({ category: 'hvac', item: 'erv_heat_exchange', qty: 1 });

  return lines;
}

// =============================================================================
// 4. ブレークダウン (グラフ用)
// =============================================================================

export interface BreakdownSlice {
  label: string;
  amount: number;
  percent: number;
}

export function buildBreakdown(estimate: DetailedEstimateOutput): BreakdownSlice[] {
  const total = estimate.grandTotal || 1;
  return [
    ...estimate.subtotalByCategory.map(c => ({ label: c.label, amount: c.subtotal, percent: (c.subtotal / total) * 100 })),
    ...estimate.overheads.map(o => ({ label: o.label, amount: o.amount, percent: (o.amount / total) * 100 })),
    { label: '消費税', amount: estimate.tax, percent: (estimate.tax / total) * 100 },
  ];
}

// =============================================================================
// 5. 単価 DB の健全性チェック (CI/起動時に使う)
// =============================================================================

export function validateUnitPriceDb(db: UnitPriceDb): { ok: boolean; errors: string[]; warnings: string[] } {
  const errors: string[] = [];
  const warnings: string[] = [];
  if (!db.schema_version) errors.push('schema_version 必須');
  if (!db.categories || Object.keys(db.categories).length === 0) errors.push('categories 必須');
  for (const [cat, catDef] of Object.entries(db.categories ?? {})) {
    if (!catDef.label_ja) errors.push(`${cat}.label_ja 必須`);
    if (!catDef.items) { errors.push(`${cat}.items 必須`); continue; }
    for (const [item, itemDef] of Object.entries(catDef.items)) {
      if (!itemDef.name_ja) errors.push(`${cat}/${item}.name_ja 必須`);
      if (!itemDef.unit) errors.push(`${cat}/${item}.unit 必須`);
      if (!Number.isFinite(itemDef.price) || itemDef.price < 0) errors.push(`${cat}/${item}.price 不正: ${itemDef.price}`);
      if (itemDef.price > 10_000_000) warnings.push(`${cat}/${item}.price 異常に高額: ${itemDef.price}`);
    }
  }
  return { ok: errors.length === 0, errors, warnings };
}
