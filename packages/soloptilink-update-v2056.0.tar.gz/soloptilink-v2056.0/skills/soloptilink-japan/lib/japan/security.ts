/**
 * lib/japan/security.ts — 警備業DNA
 *
 * 法令カバレッジ:
 *  - 警備業法 (S47法律117) 認定/教育/服装届出
 *  - 警備業法施行規則
 *  - 警備員指導教育責任者制度 (1号〜4号警備業務 別)
 *  - 警備員等の検定等に関する規則 (国家検定 1級/2級)
 *  - 機械警備業務管理者
 *  - 探偵業法 (H18法律60) — 一部交差
 *
 * 参考: 警察庁生活安全局, 全国警備業協会, 各都道府県警備業協会
 */

// ============================================================================
// 1. 警備業務 4区分 (警備業法2条)
// ============================================================================

export type SecurityBusinessType =
  | 'type1' // 1号: 施設警備 / 巡回警備 / 保安警備
  | 'type2' // 2号: 雑踏警備 / 交通誘導
  | 'type3' // 3号: 貴重品運搬警備 / 核燃料物質等運搬警備
  | 'type4'; // 4号: 身辺警備 (ボディガード)

export const SECURITY_BUSINESS_TYPES = {
  type1: { ja: '1号 施設警備', examples: ['ビル常駐', '巡回', '保安', '空港保安'] },
  type2: { ja: '2号 雑踏・交通誘導', examples: ['工事現場', 'イベント', '駐車場誘導'] },
  type3: { ja: '3号 運搬警備', examples: ['現金輸送', 'ATM保安', '核燃料運搬'] },
  type4: { ja: '4号 身辺警備', examples: ['要人警護', 'ボディガード'] },
} as const;

// ============================================================================
// 2. 認定 (警備業法4条) — 都道府県公安委員会
// ============================================================================

export interface SecurityCompanyAuthorization {
  companyName: string;
  authorizationDate: Date;
  prefecture: string;
  serviceTypes: SecurityBusinessType[];
  // 欠格事由 (警備業法3条) チェック
  isAdult: boolean; // 成年被後見人/被保佐人でない
  hasNoCriminalRecord5y: boolean; // 5年以内に禁錮以上の刑なし
  hasNoSecurityViolation5y: boolean; // 警備業法違反5年以内なし
  hasInsurance: boolean; // 業務災害補償
  hasMinimumCapital: boolean; // 最低資本/契約履行能力
}

/**
 * 警備業認定の事前審査 (警備業法4条 + 3条欠格事由)
 *  認定有効期間: 5年 (警備業法4条 — 5年ごと更新)
 */
export function evaluateSecurityAuthorization(c: SecurityCompanyAuthorization): {
  approvable: boolean;
  blockers: string[];
  validUntil: Date;
} {
  const blockers: string[] = [];
  if (!c.isAdult) blockers.push('成年被後見人/被保佐人 — 警備業法3条1号 欠格');
  if (!c.hasNoCriminalRecord5y) blockers.push('5年以内に禁錮以上の刑 — 3条2号 欠格');
  if (!c.hasNoSecurityViolation5y) blockers.push('5年以内に警備業法違反 — 3条3-5号 欠格');
  if (!c.hasInsurance) blockers.push('業務災害補償 (通常 損害賠償保険) 未加入');
  if (!c.hasMinimumCapital) blockers.push('契約履行能力 (実体審査) 不十分');

  const validUntil = new Date(c.authorizationDate);
  validUntil.setFullYear(validUntil.getFullYear() + 5);

  return { approvable: blockers.length === 0, blockers, validUntil };
}

// ============================================================================
// 3. 警備員指導教育責任者 (警備業法22条)
// ============================================================================

export interface ResponsibleInstructor {
  certifiedTypes: SecurityBusinessType[]; // 警備業務区分別の資格
  certNumber: string;
  appointedAt: Date;
}

/**
 * 各営業所 / 各警備業務区分につき警備員指導教育責任者 1名以上の選任義務 (警備業法22条)
 */
export function checkInstructorAssignment(input: {
  branchName: string;
  serviceTypes: SecurityBusinessType[];
  instructors: ResponsibleInstructor[];
}): { compliant: boolean; gaps: string[] } {
  const gaps: string[] = [];
  for (const t of input.serviceTypes) {
    const has = input.instructors.some((i) => i.certifiedTypes.includes(t));
    if (!has) {
      gaps.push(`${input.branchName}: ${SECURITY_BUSINESS_TYPES[t].ja} の指導教育責任者未選任 (法22条違反)`);
    }
  }
  return { compliant: gaps.length === 0, gaps };
}

// ============================================================================
// 4. 警備員教育 (警備業法21条 + 規則38条)
// ============================================================================

/** 警備員教育: 新任教育 + 現任教育 */
export const SECURITY_TRAINING_HOURS = {
  newcomer: { basic: 15, specific: 15, total: 30 }, // 新任 30時間 (基本15h + 業務別15h)
  current: { basic: 5, specific: 5, total: 10 }, // 現任 年10時間 (基本5h + 業務別5h)
} as const;

export interface SecurityGuard {
  name: string;
  hireDate: Date;
  serviceTypes: SecurityBusinessType[];
  newcomerTrainingHours: { basic: number; specific: number };
  currentTrainingHoursThisYear: { basic: number; specific: number };
  isOver18: boolean;
  hasNoCriminalRecord5y: boolean;
}

/** 警備員配置の適格性チェック */
export function isGuardEligible(g: SecurityGuard): { eligible: boolean; reasons: string[] } {
  const reasons: string[] = [];
  if (!g.isOver18) reasons.push('18歳未満は配置不可 (警備業法14条)');
  if (!g.hasNoCriminalRecord5y) reasons.push('5年以内禁錮以上で配置不可');
  // 新任教育 完了確認
  const t = g.newcomerTrainingHours;
  if (t.basic < 15 || t.specific < 15) {
    reasons.push(`新任教育未了 (基本${t.basic}h/15h, 業務別${t.specific}h/15h)`);
  }
  return { eligible: reasons.length === 0, reasons };
}

/** 現任教育 進捗チェック (年10時間義務) */
export function checkCurrentTrainingProgress(g: SecurityGuard): {
  completed: boolean;
  remainingHours: number;
} {
  const c = g.currentTrainingHoursThisYear;
  const remainingBasic = Math.max(0, 5 - c.basic);
  const remainingSpecific = Math.max(0, 5 - c.specific);
  const total = remainingBasic + remainingSpecific;
  return { completed: total === 0, remainingHours: total };
}

// ============================================================================
// 5. 国家検定 (警備員等の検定 — 警備業法23条)
// ============================================================================

export type CheckedQualification =
  | 'crowd_control_1' | 'crowd_control_2' // 雑踏警備 1級/2級
  | 'traffic_guidance_1' | 'traffic_guidance_2' // 交通誘導 1級/2級
  | 'cash_transport_1' | 'cash_transport_2' // 貴重品運搬 1級/2級
  | 'nuclear_transport_1' | 'nuclear_transport_2' // 核燃料 1級/2級
  | 'airport_security_1' | 'airport_security_2' // 空港保安 1級/2級
  | 'facility_security_1' | 'facility_security_2'; // 施設警備 1級/2級

/** 法令上「検定合格警備員の配置義務」がある現場 */
export function requiresCheckedGuardPlacement(input: {
  serviceType: SecurityBusinessType;
  workSiteKind:
    | 'highway_construction' // 高速道路工事
    | 'large_event' // 大規模雑踏
    | 'airport_terminal'
    | 'cash_transport'
    | 'normal';
}): { required: boolean; minLevel: 1 | 2 | null; reason: string } {
  if (input.workSiteKind === 'highway_construction') {
    return { required: true, minLevel: 1, reason: '高速道路工事 — 交通誘導2級以上1名以上 (規則38条)' };
  }
  if (input.workSiteKind === 'large_event') {
    return { required: true, minLevel: 2, reason: '雑踏警備 (大規模) — 雑踏2級以上配置' };
  }
  if (input.workSiteKind === 'cash_transport') {
    return { required: true, minLevel: 2, reason: '現金輸送 — 貴重品運搬2級以上' };
  }
  if (input.workSiteKind === 'airport_terminal') {
    return { required: true, minLevel: 2, reason: '空港保安 — 空港保安2級以上' };
  }
  return { required: false, minLevel: null, reason: '法令上の配置義務なし (推奨は変動)' };
}

// ============================================================================
// 6. 機械警備業務管理者 (警備業法42条)
// ============================================================================

/** 機械警備業務 (基地局型) を行う場合は管理者選任義務 */
export interface MechanicalSecurityOperator {
  baseStationsCount: number;
  hasManager: boolean;
  managerCertNumber?: string;
  responseDispatchTimeMinPrefecture: number; // 緊急対処従事者の現場到着時間 (規則66条)
}

/** 機械警備業務 体制チェック */
export function checkMechanicalSecurityCompliance(m: MechanicalSecurityOperator): {
  compliant: boolean;
  gaps: string[];
} {
  const gaps: string[] = [];
  if (m.baseStationsCount > 0 && !m.hasManager) {
    gaps.push('機械警備業務管理者未選任 (警備業法42条)');
  }
  if (m.responseDispatchTimeMinPrefecture > 25) {
    gaps.push(`緊急対処時間 ${m.responseDispatchTimeMinPrefecture}分 > 概ね25分以内 (公安委員会指導目安)`);
  }
  return { compliant: gaps.length === 0, gaps };
}

// ============================================================================
// 7. 服装/警備員証 (警備業法16条)
// ============================================================================

export function isUniformPoliceConflict(uniformDescription: string): {
  conflict: boolean;
  reason: string;
} {
  // 警察官/海上保安官/自衛官との制服酷似 — 16条違反 (届出制 + 警察酷似禁止)
  const banned = ['警察官', '警官', 'POLICE', '機動隊', '海上保安官', 'COAST GUARD', '自衛官'];
  for (const b of banned) {
    if (uniformDescription.includes(b)) {
      return { conflict: true, reason: `制服に「${b}」相当の表示は警備業法16条違反 (酷似禁止)` };
    }
  }
  return { conflict: false, reason: '酷似なし — 公安委員会への服装届出は別途必要' };
}
