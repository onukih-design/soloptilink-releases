/**
 * SoloptiLinkAI JAPAN-NATIVE Mode - Bug Prevention DNA (v2015.4 Phase 6)
 *
 * 生成時点で日本の中小企業向け業務システムによく出るバグを未然に封じ込める
 * 「バグ予防DNA」ライブラリ。save_guarantee.ts と一緒に generated project に注入される。
 *
 * 対応領域:
 *   - 数値計算の丸め (消費税端数処理: 切り捨て/切り上げ/四捨五入の混在)
 *   - 金額の int / decimal 誤用
 *   - 電話/郵便番号のフォーマット揺れ
 *   - 和暦/西暦の取り違え
 *   - CSV import/export の BOM と文字コード
 *   - PDF 出力時の A4 はみ出し検知
 *   - お客様からのクレーム頻出ポイント (金額表示/印影位置/送り先住所の敬称)
 */

// =============================================================================
// 消費税端数処理 (インボイス制度: 1 インボイスあたり税率ごとに 1 回)
// =============================================================================

export type RoundingPolicy = 'floor' | 'ceil' | 'round';

/**
 * 消費税計算の端数処理を明示的に指定する。
 * インボイス制度では「1 インボイスあたり税率ごとに 1 回」が原則。
 */
export function calcTax(subtotal: number, rate: 0.1 | 0.08 | 0, policy: RoundingPolicy = 'floor'): number {
  const raw = subtotal * rate;
  switch (policy) {
    case 'floor': return Math.floor(raw);
    case 'ceil': return Math.ceil(raw);
    case 'round': return Math.round(raw);
  }
}

/**
 * 取引明細を税率でグルーピングし、税率ごとに 1 回の端数処理を行う。
 * インボイス要件を満たす税額計算。
 */
export function groupAndCalcTax(
  items: Array<{ amount: number; rate: 'standard' | 'reduced' | 'exempt' }>,
  policy: RoundingPolicy = 'floor',
): { standard: { subtotal: number; tax: number }; reduced: { subtotal: number; tax: number }; exempt: { subtotal: number } } {
  const groups = { standard: 0, reduced: 0, exempt: 0 };
  for (const it of items) groups[it.rate] += it.amount;
  return {
    standard: { subtotal: groups.standard, tax: calcTax(groups.standard, 0.1, policy) },
    reduced: { subtotal: groups.reduced, tax: calcTax(groups.reduced, 0.08, policy) },
    exempt: { subtotal: groups.exempt },
  };
}

// =============================================================================
// 金額表記 (数値フォーマットと型安全)
// =============================================================================

/**
 * 日本の金額表記: カンマ区切り + ¥ 接頭辞。
 * 通貨単位は円のみ (本スキルではマルチ通貨非対応)。
 */
export function formatYen(amount: number, opts: { withSymbol?: boolean } = {}): string {
  const sign = amount < 0 ? '△' : '';
  const n = Math.abs(Math.floor(amount)).toLocaleString('ja-JP');
  return opts.withSymbol === false ? `${sign}${n}` : `¥${sign}${n}`;
}

/**
 * 金額パース: ¥1,234,567 / １２３４ / ￥500 / -1000 等を全て受け付ける。
 * 失敗時は null を返す (NaN 事故防止)。
 */
export function parseYen(input: string | number | null | undefined): number | null {
  if (typeof input === 'number') return Number.isFinite(input) ? input : null;
  if (!input) return null;
  const normalized = input
    .trim()
    .replace(/[￥¥]/g, '')
    .replace(/[０-９]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0xFEE0))
    .replace(/[−ー－]/g, '-')
    .replace(/,/g, '')
    .replace(/△/g, '-');
  const n = Number(normalized);
  return Number.isFinite(n) ? n : null;
}

// =============================================================================
// 電話番号フォーマット (日本固有)
// =============================================================================

/**
 * 国内電話番号の正規化。
 * 入力: 090-1234-5678 / 0901234567 / ０９０−１２３４−５６７８ / +81 90 1234 5678
 * 出力: 09012345678 (ハイフンなし・半角)
 */
export function normalizePhoneJP(input: string): string {
  return input
    .trim()
    .replace(/[０-９]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0xFEE0))
    .replace(/[−ー－\s()（）]/g, '')
    .replace(/^\+?81/, '0');
}

/**
 * 表示用ハイフン付き: 09012345678 → 090-1234-5678
 * 固定電話/携帯/IP電話の桁数に応じて適切に挿入。
 */
export function formatPhoneJP(input: string): string {
  const raw = normalizePhoneJP(input);
  if (/^0[789]0\d{8}$/.test(raw)) return raw.replace(/^(0[789]0)(\d{4})(\d{4})$/, '$1-$2-$3');
  if (/^050\d{8}$/.test(raw)) return raw.replace(/^(050)(\d{4})(\d{4})$/, '$1-$2-$3');
  if (/^0120\d{6}$/.test(raw)) return raw.replace(/^(0120)(\d{3})(\d{3})$/, '$1-$2-$3');
  if (/^03\d{8}$/.test(raw)) return raw.replace(/^(03)(\d{4})(\d{4})$/, '$1-$2-$3');
  if (/^06\d{8}$/.test(raw)) return raw.replace(/^(06)(\d{4})(\d{4})$/, '$1-$2-$3');
  return raw;
}

// =============================================================================
// 郵便番号
// =============================================================================

export function normalizePostalJP(input: string): string {
  return input
    .trim()
    .replace(/[０-９]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0xFEE0))
    .replace(/[−ー－\s]/g, '')
    .replace(/^〒/, '');
}

export function isValidPostalJP(input: string): boolean {
  return /^\d{7}$/.test(normalizePostalJP(input));
}

export function formatPostalJP(input: string): string {
  const raw = normalizePostalJP(input);
  if (!isValidPostalJP(raw)) return input;
  return `〒${raw.slice(0, 3)}-${raw.slice(3)}`;
}

// =============================================================================
// CSV: 日本のビジネスで UTF-8 BOM + Shift_JIS 両対応が必須
// =============================================================================

/**
 * CSV を日本向けに安全に書き出す。
 * - Excel 互換のため UTF-8 BOM を付与
 * - CRLF 改行 (RFC 4180)
 * - ダブルクォート/改行/カンマを含むセルは必ずクォート
 * - 先頭文字が =/+/-/@ の場合は CSV Injection 対策でシングルクォートを付与
 */
export function toCsvJP(rows: Array<Record<string, string | number | null | undefined>>, opts: { bom?: boolean } = {}): string {
  if (rows.length === 0) return opts.bom === false ? '' : '\uFEFF';
  const headers = Object.keys(rows[0]);
  const lines: string[] = [];
  lines.push(headers.map(escape).join(','));
  for (const row of rows) {
    lines.push(headers.map(h => escape(row[h] ?? '')).join(','));
  }
  const body = lines.join('\r\n');
  return (opts.bom === false ? '' : '\uFEFF') + body;
}

function escape(v: string | number | null | undefined): string {
  if (v === null || v === undefined) return '';
  let s = String(v);
  // CSV Injection 対策
  if (/^[=+\-@]/.test(s)) s = `'${s}`;
  if (/[",\r\n]/.test(s)) s = `"${s.replace(/"/g, '""')}"`;
  return s;
}

// =============================================================================
// 敬称 (顧客向け表示)
// =============================================================================

export type HonorificKind = 'company' | 'person' | 'division';

/**
 * 宛先に応じた敬称自動付与。
 * - 個人: 様
 * - 法人: 御中
 * - 部署: 御中
 * - 既に付いていれば二重付与しない
 */
export function attachHonorific(name: string, kind: HonorificKind = 'person'): string {
  const trimmed = name.trim();
  if (/(様|御中|殿|先生)$/.test(trimmed)) return trimmed;
  const suffix = kind === 'person' ? '様' : '御中';
  return `${trimmed} ${suffix}`;
}

// =============================================================================
// 契約日/発行日/支払期日: バリデーションと自動計算
// =============================================================================

/**
 * 月末締翌月末払い等の日本の商慣習日計算。
 * baseDate から指定日数/月末まで計算。
 */
export function calcPaymentDueDate(
  issuedAt: Date,
  policy: { closeDay: number | 'endOfMonth'; payDay: number | 'endOfMonth'; offsetMonths: number },
): Date {
  const d = new Date(issuedAt);
  const closeMonth = new Date(d.getFullYear(), d.getMonth(), 1);
  if (policy.closeDay !== 'endOfMonth' && d.getDate() > policy.closeDay) {
    closeMonth.setMonth(closeMonth.getMonth() + 1);
  }
  const payMonth = new Date(closeMonth.getFullYear(), closeMonth.getMonth() + policy.offsetMonths, 1);
  if (policy.payDay === 'endOfMonth') {
    return new Date(payMonth.getFullYear(), payMonth.getMonth() + 1, 0);
  }
  return new Date(payMonth.getFullYear(), payMonth.getMonth(), policy.payDay);
}

// =============================================================================
// バグ予防アノテーション (開発者向け)
// =============================================================================

/**
 * Prisma/Drizzle スキーマから自動生成された型を「保存時に必ず通すべき関数」に
 * 通していることを静的に強制する型アノテーション。
 *
 * 使用例:
 *   type CustomerSaveInput = Brand<RawCustomerInput, 'SaveGuaranteed'>;
 *   function saveCustomer(input: CustomerSaveInput) { ... }
 */
export type Brand<T, B extends string> = T & { readonly __brand: B };

export function markSaveGuaranteed<T>(value: T): Brand<T, 'SaveGuaranteed'> {
  return value as Brand<T, 'SaveGuaranteed'>;
}
