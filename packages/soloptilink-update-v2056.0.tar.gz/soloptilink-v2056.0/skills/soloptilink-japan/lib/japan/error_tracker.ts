/**
 * SoloptiLinkAI Customer Error Tracker SDK v1.0
 * =============================================================================
 * 顧客プロジェクト (SoloptiLinkAI で生成されたシステム) に組み込み、
 * runtime エラーを admin-dashboard へ自動送信するクライアント。
 *
 * 配線ポイント:
 *   - ブラウザ側 (Next.js client component): app/error.tsx + app/global-error.tsx
 *   - Next.js API route: try/catch の catch で reportApiError を呼ぶ
 *   - Express middleware: app.use(soloptilinkErrorMiddleware)
 *
 * 機能:
 *   - window.onerror / unhandledrejection 自動キャッチ
 *   - バッチ送信 (デフォルト 5秒 or 20件)
 *   - Beacon API でページ離脱時も送信
 *   - 環境別フィルタ (dev/staging/production)
 *   - PII 除去 (email, password, token をマスク)
 *   - rate-limit (同一 fingerprint は 60秒に1件まで)
 *
 * 使い方 (クライアント側):
 *   ```ts
 *   import { initSoloptiLinkErrorTracker } from '@/lib/soloptilink/error_tracker';
 *   initSoloptiLinkErrorTracker({
 *     projectToken: 'pt_xxxxxxxxxxxxxxxxxxxxxxxx',
 *     endpoint: 'https://admin-dashboard-blue-alpha-78.vercel.app',
 *     environment: process.env.NODE_ENV || 'production',
 *     projectName: 'My Project',
 *     projectVersion: '1.0.0',
 *     generatedBySkill: 'soloptilink-boost',
 *     generatedByVersion: 'v2027.0',
 *   });
 *   ```
 *
 * 使い方 (server 側 / Next.js Route Handler):
 *   ```ts
 *   import { reportServerError } from '@/lib/soloptilink/error_tracker';
 *   try { ... }
 *   catch (e) {
 *     await reportServerError(e, { request, route_pattern: '/api/users/[id]' });
 *     throw e;
 *   }
 *   ```
 * =============================================================================
 */

export interface ErrorTrackerConfig {
  /**
   * project_token: pt_xxx (admin-dashboard で発行)
   *
   * ★2026-07-29 変更: 画面側で使う場合は「未設定」でよい（optional）。
   *   画面（ブラウザ）に合言葉を配ると誰でも読める状態になるため、
   *   endpoint に自分のサイト内の窓口（例: '/api/soloptilink/error-report'）を
   *   設定して、そこで合言葉を付けて転送する「窓口経由モード」を使う。
   *
   *   サーバー側（Next.js Route Handler の reportServerError / Express の
   *   ミドルウェア）から直接ダッシュボードへ送る場合は必須。
   */
  projectToken?: string;
  /** endpoint URL: 例 'https://admin-dashboard-blue-alpha-78.vercel.app'
   *  ★2026-07-29: 画面側で使うときは自分のサイト内の窓口パス（'/api/...'）で可。 */
  endpoint: string;
  /** environment: 'production' / 'staging' / 'development' */
  environment?: string;
  projectName?: string;
  projectVersion?: string;
  generatedBySkill?: string;
  generatedByVersion?: string;
  /** バッチ送信間隔 (ms) — デフォルト 5000 */
  flushIntervalMs?: number;
  /** バッチ最大件数 — デフォルト 20 */
  batchSize?: number;
  /** dev 環境では送信しない (デフォルト true) */
  skipInDevelopment?: boolean;
  /** デバッグログ (デフォルト false) */
  debug?: boolean;
}

/**
 * 窓口経由モードかどうかを判定する。
 *
 * ★2026-07-29 新設: 画面側では合言葉を持たない設計を実現するための判定。
 *   endpoint が同一オリジンの窓口を指していて、かつ合言葉が未設定なら
 *   「窓口経由モード」。この場合は endpoint（自サイト内の窓口）へそのまま
 *   POST し、合言葉はサーバー側の窓口が付ける。
 *
 *   同一オリジンの判定は次の 2 パターンを許容する:
 *     1. '/' で始まる相対パス（例: '/api/soloptilink/error-report'）
 *     2. window.location と同じ origin を持つ絶対URL（ブラウザ実行時のみ判定可能）
 */
function _isProxiedMode(config: ErrorTrackerConfig | null): boolean {
  if (!config) return false;
  if (config.projectToken) return false;
  if (!config.endpoint) return false;
  // 相対パス（'/api/...'）は同一オリジン確定。
  // ただし '//host/path' はスキーム相対で別オリジンを指しうるため除外し、下の origin 比較に回す。
  if (config.endpoint.startsWith('/') && !config.endpoint.startsWith('//')) return true;
  if (typeof window !== 'undefined' && window.location && window.location.origin) {
    try {
      const u = new URL(config.endpoint, window.location.href);
      if (u.origin === window.location.origin) return true;
    } catch {
      // 解釈できないURLは proxied 扱いしない（従来どおり直接送信モードに落として早期returnで検知）
    }
  }
  return false;
}

interface ErrorReport {
  error_kind: string;
  error_message: string;
  error_stack?: string;
  file_path?: string;
  line_number?: number;
  column_number?: number;
  url?: string;
  route_pattern?: string;
  http_method?: string;
  http_status?: number;
  user_agent?: string;
  session_id?: string;
  user_role?: string;
  tags?: string[];
  occurred_at?: string;
}

const SDK_VERSION = '1.0.0';

let _config: ErrorTrackerConfig | null = null;
let _queue: ErrorReport[] = [];
let _flushTimer: any = null;
const _seenFingerprints = new Map<string, number>();

/** PII を除去 */
function _scrubPII(text: string): string {
  if (!text) return text;
  let s = text;
  // メールアドレス
  s = s.replace(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g, '[email]');
  // パスワード関連
  s = s.replace(/(password|passwd|pwd|secret|token|api[_-]?key)["'\s:=]+["']?[^"'\s,}]+/gi, '$1=[masked]');
  // クレジットカード番号
  s = s.replace(/\b(?:\d[ -]*?){13,16}\b/g, '[card]');
  // 電話番号
  s = s.replace(/\b\d{3,4}-\d{3,4}-\d{4}\b/g, '[phone]');
  // Bearer トークン
  s = s.replace(/Bearer\s+[A-Za-z0-9._\-+/=]+/g, 'Bearer [masked]');
  return s;
}

/** 簡易 fingerprint (連続送信抑制用) */
function _quickFingerprint(report: ErrorReport): string {
  return `${report.error_kind}|${(report.error_message || '').slice(0, 100)}|${report.route_pattern || ''}`;
}

function _shouldSkip(): boolean {
  if (!_config) return true;
  if (_config.skipInDevelopment !== false) {
    if ((_config.environment || '').toLowerCase() === 'development') return true;
  }
  return false;
}

function _enqueue(report: ErrorReport): void {
  if (!_config || _shouldSkip()) return;

  // PII 除去
  report.error_message = _scrubPII(report.error_message);
  if (report.error_stack) report.error_stack = _scrubPII(report.error_stack);
  if (report.url) report.url = _scrubPII(report.url);

  // rate-limit (同 fingerprint は 60s 内なら 1 件のみ)
  const fp = _quickFingerprint(report);
  const now = Date.now();
  const lastSeen = _seenFingerprints.get(fp);
  if (lastSeen && (now - lastSeen) < 60_000) {
    return;
  }
  _seenFingerprints.set(fp, now);
  // 古いエントリ掃除
  if (_seenFingerprints.size > 1000) {
    for (const [k, v] of _seenFingerprints) {
      if ((now - v) > 600_000) _seenFingerprints.delete(k);
    }
  }

  if (!report.occurred_at) report.occurred_at = new Date().toISOString();
  if (!report.user_agent && typeof navigator !== 'undefined') {
    report.user_agent = navigator.userAgent;
  }

  _queue.push(report);

  const batchSize = _config.batchSize || 20;
  if (_queue.length >= batchSize) {
    _flush(false);
  } else if (!_flushTimer) {
    const interval = _config.flushIntervalMs || 5000;
    _flushTimer = setTimeout(() => _flush(false), interval);
  }
}

async function _flush(useBeacon: boolean): Promise<void> {
  if (_flushTimer) {
    clearTimeout(_flushTimer);
    _flushTimer = null;
  }
  if (!_config || _queue.length === 0) return;

  const batch = _queue.splice(0, _queue.length);
  // ★2026-07-29 変更: 送信先の組み立てを 2 モードに分岐する。
  //   - 窓口経由モード（画面側で合言葉を持たない場合）: endpoint を「そのまま」使う。
  //     endpoint は自サイト内の窓口パス（例: '/api/soloptilink/error-report'）で、
  //     そこに末尾のダッシュボード用パスを付け足すと二重パスになって届かない。
  //   - 直接送信モード（サーバー側から使う場合）: 従来どおり /api/v1/customer-errors を付ける。
  const proxied = _isProxiedMode(_config);
  const url = proxied
    ? _config.endpoint
    : `${_config.endpoint.replace(/\/$/, '')}/api/v1/customer-errors`;
  // 共通フィールドを各レコードに注入
  const enriched = batch.map(b => ({
    ...b,
    project_name: b['project_name' as keyof ErrorReport] || _config!.projectName || '',
    project_version: b['project_version' as keyof ErrorReport] || _config!.projectVersion || '',
    generated_by_skill: b['generated_by_skill' as keyof ErrorReport] || _config!.generatedBySkill || '',
    generated_by_version: b['generated_by_version' as keyof ErrorReport] || _config!.generatedByVersion || '',
    environment: b['environment' as keyof ErrorReport] || _config!.environment || 'production',
  }));

  const body = JSON.stringify(enriched);
  // ★2026-07-29 変更: 合言葉は「持っているときだけ」ヘッダに付ける。
  //   窓口経由モードでは合言葉は画面側に無く、サーバー側の窓口が付けるため
  //   ここでヘッダに載せる値は存在しない。
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  if (_config.projectToken) {
    headers['X-Project-Token'] = _config.projectToken;
  }

  try {
    if (useBeacon && typeof navigator !== 'undefined' && navigator.sendBeacon) {
      // ページ離脱時の信頼送信
      const blob = new Blob([body], { type: 'application/json' });
      navigator.sendBeacon(url, blob);
      return;
    }
    const res = await fetch(url, { method: 'POST', headers, body, keepalive: true });
    if (_config.debug) {
      console.debug('[soloptilink-error-tracker] flush', batch.length, 'items, status', res.status);
    }
  } catch (e) {
    // 送信失敗時は queue に戻す (最大 100 件まで)
    if (_queue.length < 100) {
      _queue.unshift(...batch.slice(0, 100 - _queue.length));
    }
    if (_config.debug) {
      console.warn('[soloptilink-error-tracker] flush failed', e);
    }
  }
}

/**
 * SDK 初期化 — クライアント側 (ブラウザ)
 * Next.js の root layout か _app.tsx で 1 度だけ呼ぶ
 */
export function initSoloptiLinkErrorTracker(config: ErrorTrackerConfig): void {
  // ★2026-07-29 変更: 画面側は合言葉を持たない設計に合わせて、判定を 2 モードに分岐する。
  //   窓口経由モード: endpoint が '/' で始まる（同一オリジンのパス）で合言葉なし。
  //     この場合は「画面のエラー捕捉を登録して、その窓口へ POST する」だけを行う。
  //     合言葉はサーバー側の窓口が付けるため、SDK 側で検査しない。
  //   直接送信モード: endpoint が絶対URLで合言葉あり。
  //     従来どおり合言葉の妥当性（'pt_' で始まるか）を確認する。
  if (!config.endpoint) {
    if (config.debug) console.warn('[soloptilink-error-tracker] endpoint required');
    return;
  }
  const proxied = _isProxiedMode(config);
  if (!proxied) {
    if (!config.projectToken || !config.projectToken.startsWith('pt_')) {
      if (config.debug) console.warn('[soloptilink-error-tracker] invalid projectToken');
      return;
    }
  }
  _config = config;

  if (typeof window === 'undefined') return; // SSR で呼ばれた場合はスキップ

  // window.onerror
  const originalOnError = window.onerror;
  window.onerror = function (message, source, lineno, colno, error) {
    try {
      _enqueue({
        error_kind: error?.name || 'Error',
        error_message: String(message || error?.message || 'Unknown error'),
        error_stack: error?.stack || '',
        file_path: source || '',
        line_number: typeof lineno === 'number' ? lineno : undefined,
        column_number: typeof colno === 'number' ? colno : undefined,
        url: window.location.href,
        route_pattern: window.location.pathname,
      });
    } catch {}
    if (originalOnError) {
      try { return originalOnError.call(window, message, source, lineno, colno, error); } catch {}
    }
    return false;
  };

  // unhandled promise rejection
  window.addEventListener('unhandledrejection', (event) => {
    const reason = event.reason;
    _enqueue({
      error_kind: reason?.name || 'UnhandledRejection',
      error_message: String(reason?.message || reason || 'Unhandled promise rejection'),
      error_stack: reason?.stack || '',
      url: window.location.href,
      route_pattern: window.location.pathname,
    });
  });

  // ページ離脱時 flush
  window.addEventListener('beforeunload', () => _flush(true));
  // visibility change (mobile アプリ切替)
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') _flush(true);
  });

  if (config.debug) {
    // ★2026-07-29 変更: 合言葉が無い（窓口経由モード）でもログを出せるように分岐。
    const label = config.projectToken
      ? `for ${config.projectToken.slice(0, 12)}...`
      : `via proxy endpoint ${config.endpoint}`;
    console.info(`[soloptilink-error-tracker] v${SDK_VERSION} initialized ${label}`);
  }
}

/**
 * 手動でエラーを報告 (任意)
 * 例: try { ... } catch (e) { reportError(e, { tags: ['payment-flow'] }) }
 */
export function reportError(
  error: Error | unknown,
  meta?: {
    tags?: string[];
    user_role?: string;
    session_id?: string;
    route_pattern?: string;
    http_status?: number;
  }
): void {
  if (!_config) return;
  const e = error as any;
  _enqueue({
    error_kind: e?.name || 'ReportedError',
    error_message: String(e?.message || e || 'Manual error report'),
    error_stack: e?.stack || '',
    url: typeof window !== 'undefined' ? window.location.href : '',
    route_pattern: meta?.route_pattern || (typeof window !== 'undefined' ? window.location.pathname : ''),
    user_role: meta?.user_role,
    session_id: meta?.session_id,
    tags: meta?.tags || [],
    http_status: meta?.http_status,
  });
}

/**
 * Server-side エラー報告 (Next.js Route Handler / Express)
 * 例:
 *   import { reportServerError } from '@/lib/soloptilink/error_tracker';
 *   reportServerError(e, { route_pattern: '/api/users/[id]', http_method: 'GET', http_status: 500 });
 */
export async function reportServerError(
  error: Error | unknown,
  meta: {
    route_pattern: string;
    http_method?: string;
    http_status?: number;
    request_url?: string;
    user_role?: string;
    session_id?: string;
    tags?: string[];
  }
): Promise<void> {
  if (!_config) return;
  // ★2026-07-29 変更: サーバー側で使う関数は「合言葉あり + 絶対URL」を必須にする。
  //   窓口経由モード（'/' で始まる endpoint）はサーバーからは使えない
  //   （自分自身の窓口を呼び出す循環になるため）。設定不備は静かに諦めて元例外に任せる。
  //   型ガードを局所変数に固定して、後段のヘッダ組み立てで undefined が混入しないようにする。
  const token = _config.projectToken;
  if (!token || !_config.endpoint || _config.endpoint.startsWith('/')) {
    return;
  }
  const e = error as any;
  // server-side は同期送信(キューに入れず即送信)
  const url = `${_config.endpoint.replace(/\/$/, '')}/api/v1/customer-errors`;
  const body = JSON.stringify([{
    error_kind: e?.name || 'ServerError',
    error_message: _scrubPII(String(e?.message || e || 'Unknown server error')),
    error_stack: _scrubPII(e?.stack || ''),
    url: meta.request_url || '',
    route_pattern: meta.route_pattern,
    http_method: meta.http_method || '',
    http_status: meta.http_status,
    user_role: meta.user_role || '',
    session_id: meta.session_id || '',
    tags: meta.tags || [],
    project_name: _config.projectName || '',
    project_version: _config.projectVersion || '',
    generated_by_skill: _config.generatedBySkill || '',
    generated_by_version: _config.generatedByVersion || '',
    environment: _config.environment || 'production',
    occurred_at: new Date().toISOString(),
  }]);
  try {
    await fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Project-Token': token,
      },
      body,
      keepalive: true,
    });
  } catch {
    // server-side 送信失敗は無視 (元の例外はユーザの try/catch に委ねる)
  }
}

/**
 * Express middleware ファクトリ
 * 使い方: app.use(soloptilinkErrorMiddleware());
 */
export function soloptilinkErrorMiddleware() {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  return function (err: any, req: any, res: any, next: any) {
    try {
      reportServerError(err, {
        route_pattern: req?.route?.path || req?.url || 'unknown',
        http_method: req?.method || 'GET',
        http_status: err?.status || 500,
        request_url: req?.originalUrl || req?.url || '',
        user_role: (req?.user?.role || '').toString(),
      });
    } catch {}
    next(err);
  };
}

/** 手動 flush (テスト用) */
export function flushSoloptiLinkErrors(): Promise<void> {
  return _flush(false);
}

/** SDK バージョン取得 */
export function getSoloptiLinkSdkVersion(): string {
  return SDK_VERSION;
}

/** 現在の queue 件数 (デバッグ用) */
export function getSoloptiLinkQueueSize(): number {
  return _queue.length;
}
