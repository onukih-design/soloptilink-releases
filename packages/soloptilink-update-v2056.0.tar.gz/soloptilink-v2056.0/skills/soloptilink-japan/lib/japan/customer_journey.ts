/**
 * SoloptiLinkAI Phase 16 — Customer Journey Analytics
 *
 * 顧客行動データから RFM分析・LTV予測・離脱予測・セグメント分類を行い、
 * 業種別の打ち手 (リテンション施策) を推薦する。
 *
 * カバー範囲:
 *  - RFM (Recency / Frequency / Monetary) スコアリング
 *  - LTV (Customer Lifetime Value) ヒューリスティック予測
 *  - チャーン (離脱) 予測 (シンプル lapse モデル)
 *  - セグメント分類 (Champion/Loyal/At-Risk/Hibernating/Lost)
 *  - 業種別アクションテンプレ (retail/saas/healthcare/education など)
 */

export interface CustomerEvent {
  customer_id: string;
  event_type: "purchase" | "signup" | "login" | "cancel" | "support_contact";
  amount?: number;
  ts: string; // ISO
}

export interface CustomerProfile {
  customer_id: string;
  signup_date?: string;
  segment?: CustomerSegment;
  industry?: string;
  acquisition_channel?: string;
}

export interface RfmScore {
  customer_id: string;
  recency_days: number;
  frequency: number;
  monetary: number;
  r_score: number; // 1-5
  f_score: number;
  m_score: number;
  rfm_index: number; // r*100 + f*10 + m
}

export type CustomerSegment =
  | "champion"
  | "loyal"
  | "potential_loyalist"
  | "new_customer"
  | "promising"
  | "needs_attention"
  | "about_to_sleep"
  | "at_risk"
  | "cant_lose_them"
  | "hibernating"
  | "lost";

export function calcRfm(events: CustomerEvent[], asOf: Date = new Date()): RfmScore[] {
  const byCust = new Map<string, CustomerEvent[]>();
  for (const e of events) {
    if (e.event_type !== "purchase") continue;
    const arr = byCust.get(e.customer_id) ?? [];
    arr.push(e);
    byCust.set(e.customer_id, arr);
  }
  const raw: { id: string; recency: number; frequency: number; monetary: number }[] = [];
  for (const [id, list] of byCust) {
    const recents = list.map((e) => Date.parse(e.ts)).filter((t) => !Number.isNaN(t));
    if (recents.length === 0) continue;
    const last = Math.max(...recents);
    const recencyDays = Math.floor((asOf.getTime() - last) / (24 * 60 * 60 * 1000));
    const frequency = list.length;
    const monetary = list.reduce((a, b) => a + (b.amount ?? 0), 0);
    raw.push({ id, recency: recencyDays, frequency, monetary });
  }
  return scoreQuintiles(raw);
}

function scoreQuintiles(
  rows: { id: string; recency: number; frequency: number; monetary: number }[],
): RfmScore[] {
  if (rows.length === 0) return [];
  const sortedR = [...rows].sort((a, b) => a.recency - b.recency); // 小さい (最近) ほど高得点
  const sortedF = [...rows].sort((a, b) => b.frequency - a.frequency);
  const sortedM = [...rows].sort((a, b) => b.monetary - a.monetary);
  const rIndex = new Map(sortedR.map((r, i) => [r.id, quintile(i, rows.length)]));
  const fIndex = new Map(sortedF.map((r, i) => [r.id, quintile(i, rows.length)]));
  const mIndex = new Map(sortedM.map((r, i) => [r.id, quintile(i, rows.length)]));
  return rows.map((r) => {
    const rs = rIndex.get(r.id) ?? 1;
    const fs = fIndex.get(r.id) ?? 1;
    const ms = mIndex.get(r.id) ?? 1;
    return {
      customer_id: r.id,
      recency_days: r.recency,
      frequency: r.frequency,
      monetary: r.monetary,
      r_score: rs,
      f_score: fs,
      m_score: ms,
      rfm_index: rs * 100 + fs * 10 + ms,
    };
  });
}

function quintile(rankIndex: number, total: number): number {
  if (total <= 0) return 1;
  const ratio = rankIndex / total;
  if (ratio < 0.2) return 5;
  if (ratio < 0.4) return 4;
  if (ratio < 0.6) return 3;
  if (ratio < 0.8) return 2;
  return 1;
}

export function classifySegment(rfm: RfmScore): CustomerSegment {
  const { r_score: r, f_score: f } = rfm;
  if (r >= 5 && f >= 5) return "champion";
  if (r >= 4 && f >= 4) return "loyal";
  if (r >= 4 && f >= 2) return "potential_loyalist";
  if (r === 5 && f === 1) return "new_customer";
  if (r === 4 && f === 1) return "promising";
  if (r === 3 && f >= 2) return "needs_attention";
  if (r === 3 && f === 1) return "about_to_sleep";
  if (r <= 2 && f >= 4) return "cant_lose_them";
  if (r <= 2 && f >= 2) return "at_risk";
  if (r === 2 && f === 1) return "hibernating";
  return "lost";
}

export interface LtvForecast {
  customer_id: string;
  expected_remaining_purchases: number;
  expected_ltv: number;
  confidence: "low" | "medium" | "high";
}

export function forecastLtv(
  events: CustomerEvent[],
  options: { avg_lifespan_days?: number } = {},
): LtvForecast[] {
  const lifespan = options.avg_lifespan_days ?? 730; // デフォルト2年
  const byCust = new Map<string, CustomerEvent[]>();
  for (const e of events) {
    if (e.event_type !== "purchase") continue;
    const arr = byCust.get(e.customer_id) ?? [];
    arr.push(e);
    byCust.set(e.customer_id, arr);
  }
  const out: LtvForecast[] = [];
  const now = Date.now();
  for (const [id, list] of byCust) {
    const sorted = list.map((e) => ({ ts: Date.parse(e.ts), amt: e.amount ?? 0 }))
      .filter((x) => !Number.isNaN(x.ts))
      .sort((a, b) => a.ts - b.ts);
    if (sorted.length === 0) continue;
    const totalSpent = sorted.reduce((a, b) => a + b.amt, 0);
    const avgOrderValue = totalSpent / sorted.length;
    const tenureDays = (now - sorted[0].ts) / (24 * 60 * 60 * 1000);
    if (tenureDays <= 0) {
      out.push({ customer_id: id, expected_remaining_purchases: 1, expected_ltv: avgOrderValue, confidence: "low" });
      continue;
    }
    const purchasesPerDay = sorted.length / tenureDays;
    const remainingDays = Math.max(0, lifespan - tenureDays);
    const remainingPurchases = purchasesPerDay * remainingDays;
    const ltv = totalSpent + remainingPurchases * avgOrderValue;
    const confidence: "low" | "medium" | "high" = sorted.length >= 8 ? "high" : sorted.length >= 3 ? "medium" : "low";
    out.push({
      customer_id: id,
      expected_remaining_purchases: Number(remainingPurchases.toFixed(1)),
      expected_ltv: Math.round(ltv),
      confidence,
    });
  }
  return out.sort((a, b) => b.expected_ltv - a.expected_ltv);
}

export interface ChurnRisk {
  customer_id: string;
  days_since_last_purchase: number;
  risk: "low" | "medium" | "high";
  recommended_action: string;
}

export function predictChurn(
  rfm: RfmScore[],
  industry?: string,
): ChurnRisk[] {
  const out: ChurnRisk[] = [];
  for (const r of rfm) {
    let risk: "low" | "medium" | "high" = "low";
    if (r.recency_days >= 180) risk = "high";
    else if (r.recency_days >= 90) risk = "medium";
    out.push({
      customer_id: r.customer_id,
      days_since_last_purchase: r.recency_days,
      risk,
      recommended_action: actionFor(risk, classifySegment(r), industry),
    });
  }
  return out;
}

const INDUSTRY_ACTIONS: Record<string, Record<string, string>> = {
  retail: {
    high: "ウィンバックメール+クーポン20%OFF (景表法のクーポン併記要件に注意)",
    medium: "ステップメール (購買後30/60/90日)",
    low: "新作レコメンド+ポイント期間限定通知",
  },
  saas: {
    high: "CS主導の解約防止オンボ (機能未活用箇所のチュートリアル送付)",
    medium: "プロダクト内ナッジ (主要機能の未利用通知)",
    low: "アップセル提案 (上位プランの差分価値訴求)",
  },
  healthcare: {
    high: "リコール案内 (定期検診/薬の在庫切れ通知)",
    medium: "問診票事前記入リマインド",
    low: "健康セミナー/予防接種案内",
  },
  education: {
    high: "学習継続率低下アラート (担任からの個別連絡)",
    medium: "進捗共有 + 達成バッジ送付",
    low: "上位カリキュラム提案",
  },
  default: {
    high: "離脱防止オファー (個別ヒアリング+特別条件)",
    medium: "リエンゲージメント施策 (関心領域別コンテンツ送付)",
    low: "ロイヤルティプログラム招待",
  },
};

function actionFor(risk: "low" | "medium" | "high", segment: CustomerSegment, industry?: string): string {
  const table = INDUSTRY_ACTIONS[industry ?? "default"] ?? INDUSTRY_ACTIONS.default;
  const base = table[risk] ?? "";
  if (segment === "champion") return `${base} (Champion セグメント: VIP対応で優先度↑)`;
  if (segment === "cant_lose_them") return `${base} (Can't Lose Them セグメント: 経営層判断必要)`;
  return base;
}

export function summarizeJourney(
  events: CustomerEvent[],
  industry?: string,
): {
  rfm: RfmScore[];
  segments: Record<CustomerSegment, number>;
  ltv: LtvForecast[];
  churn: ChurnRisk[];
} {
  const rfm = calcRfm(events);
  const segments: Record<string, number> = {};
  for (const r of rfm) {
    const seg = classifySegment(r);
    segments[seg] = (segments[seg] ?? 0) + 1;
  }
  return {
    rfm,
    segments: segments as Record<CustomerSegment, number>,
    ltv: forecastLtv(events),
    churn: predictChurn(rfm, industry),
  };
}
