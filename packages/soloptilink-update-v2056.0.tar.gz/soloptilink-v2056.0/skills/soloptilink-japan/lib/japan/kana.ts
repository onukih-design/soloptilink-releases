/**
 * 全角半角変換ユーティリティ
 */

/**
 * 半角英数字 → 全角
 */
export function toZenkaku(s: string): string {
  return s.replace(/[A-Za-z0-9]/g, ch => String.fromCharCode(ch.charCodeAt(0) + 0xfee0));
}

/**
 * 全角英数字 → 半角
 */
export function toHankaku(s: string): string {
  return s.replace(/[Ａ-Ｚａ-ｚ０-９]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0xfee0));
}

/**
 * カタカナ半角 → 全角
 */
export function hankakuKanaToZenkaku(s: string): string {
  const map: Record<string, string> = {
    'ｱ':'ア','ｲ':'イ','ｳ':'ウ','ｴ':'エ','ｵ':'オ',
    'ｶ':'カ','ｷ':'キ','ｸ':'ク','ｹ':'ケ','ｺ':'コ',
    'ｻ':'サ','ｼ':'シ','ｽ':'ス','ｾ':'セ','ｿ':'ソ',
    'ﾀ':'タ','ﾁ':'チ','ﾂ':'ツ','ﾃ':'テ','ﾄ':'ト',
    'ﾅ':'ナ','ﾆ':'ニ','ﾇ':'ヌ','ﾈ':'ネ','ﾉ':'ノ',
    'ﾊ':'ハ','ﾋ':'ヒ','ﾌ':'フ','ﾍ':'ヘ','ﾎ':'ホ',
    'ﾏ':'マ','ﾐ':'ミ','ﾑ':'ム','ﾒ':'メ','ﾓ':'モ',
    'ﾔ':'ヤ','ﾕ':'ユ','ﾖ':'ヨ',
    'ﾗ':'ラ','ﾘ':'リ','ﾙ':'ル','ﾚ':'レ','ﾛ':'ロ',
    'ﾜ':'ワ','ｦ':'ヲ','ﾝ':'ン',
    'ｧ':'ァ','ｨ':'ィ','ｩ':'ゥ','ｪ':'ェ','ｫ':'ォ',
    'ｬ':'ャ','ｭ':'ュ','ｮ':'ョ','ｯ':'ッ','ｰ':'ー',
    '｡':'。','｢':'「','｣':'」','､':'、','･':'・',
    'ﾞ':'゛','ﾟ':'゜',
  };
  return s.replace(/[\uFF65-\uFF9F]/g, ch => map[ch] || ch);
}

/**
 * カナ → ひらがな
 */
export function katakanaToHiragana(s: string): string {
  return s.replace(/[\u30A1-\u30F6]/g, ch => String.fromCharCode(ch.charCodeAt(0) - 0x60));
}

/**
 * ひらがな → カタカナ
 */
export function hiraganaToKatakana(s: string): string {
  return s.replace(/[\u3041-\u3096]/g, ch => String.fromCharCode(ch.charCodeAt(0) + 0x60));
}

/**
 * 氏名・住所用: 半角→全角 + 半角カナ→全角カナ
 */
export function normalizeForJapaneseField(s: string): string {
  return hankakuKanaToZenkaku(toZenkaku(s));
}

/**
 * 金額・数値用: 全角→半角
 */
export function normalizeForNumericField(s: string): string {
  return toHankaku(s);
}

/**
 * 郵便番号フォーマット (1234567 / 123-4567 → 全角統一)
 */
export function formatPostalCode(s: string): string {
  const hankaku = toHankaku(s).replace(/[^0-9]/g, '');
  if (hankaku.length !== 7) return s;
  return `${hankaku.slice(0, 3)}-${hankaku.slice(3)}`;
}

/**
 * 電話番号フォーマット
 */
export function formatPhone(s: string): string {
  const d = toHankaku(s).replace(/[^0-9]/g, '');
  if (d.length === 10) {
    // 03-1234-5678 / 06-1234-5678
    if (d.startsWith('03') || d.startsWith('06')) return `${d.slice(0,2)}-${d.slice(2,6)}-${d.slice(6)}`;
    // 045-123-4567
    return `${d.slice(0,3)}-${d.slice(3,6)}-${d.slice(6)}`;
  }
  if (d.length === 11) {
    // 090-1234-5678 (携帯)
    return `${d.slice(0,3)}-${d.slice(3,7)}-${d.slice(7)}`;
  }
  return s;
}
