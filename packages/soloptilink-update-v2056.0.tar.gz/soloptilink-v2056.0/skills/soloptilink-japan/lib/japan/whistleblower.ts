/**
 * SoloptiLinkAI Phase 22 — 公益通報者保護法対応
 *
 * 2022年6月施行 改正公益通報者保護法 (通称: 内部通報法) の要件を満たす
 * 内部通報窓口の設計・運用に関する型と検証ロジック。
 *
 * カバー範囲:
 *  - 従業員301人以上 = 内部通報体制整備義務 (法11条)
 *  - 従業員300人以下 = 努力義務 (法11条1項)
 *  - 公益通報対応業務従事者 (法11条2項) の指定義務
 *  - 通報者特定情報の守秘義務 (法12条)
 *  - 通報を理由とする不利益取扱いの禁止 (法5条)
 *  - 退職者・役員も保護対象 (R4改正で拡大)
 *  - 行政通報・外部公益通報の保護要件
 */

export type EmployeeSize = "S" | "M" | "L"; // S: <=300, M: 301-1000, L: >1000

export interface OrgProfile {
  org_name: string;
  total_employees: number; // 従業員数 (役員/退職者含まず)
  has_internal_window: boolean;
  has_external_window: boolean; // 顧問弁護士/外部CSR窓口
  designated_handler_count: number; // 公益通報対応業務従事者として指定された人数
  has_anonymous_channel: boolean;
}

export interface ComplianceFinding {
  rule: string;
  severity: "info" | "warning" | "violation";
  hint: string;
}

export function classifyOrgSize(profile: OrgProfile): EmployeeSize {
  if (profile.total_employees > 1000) return "L";
  if (profile.total_employees >= 301) return "M";
  return "S";
}

export function checkOrgCompliance(profile: OrgProfile): ComplianceFinding[] {
  const findings: ComplianceFinding[] = [];
  const size = classifyOrgSize(profile);

  if ((size === "M" || size === "L") && !profile.has_internal_window) {
    findings.push({
      rule: "公益通報者保護法 第11条 (体制整備義務)",
      severity: "violation",
      hint: "従業員301人以上の事業者は内部通報窓口の設置が義務。50万円以下の過料 (法22条)。",
    });
  }
  if (size === "S" && !profile.has_internal_window) {
    findings.push({
      rule: "公益通報者保護法 第11条1項 (努力義務)",
      severity: "warning",
      hint: "従業員300人以下でも内部通報窓口の設置に努めること。",
    });
  }
  if ((size === "M" || size === "L") && profile.designated_handler_count === 0) {
    findings.push({
      rule: "公益通報者保護法 第11条2項 (公益通報対応業務従事者の指定)",
      severity: "violation",
      hint: "従業員301人以上は通報受付/調査担当者を書面で指定する義務。守秘義務違反は刑事罰 (30万円以下の罰金)。",
    });
  }
  if (!profile.has_external_window) {
    findings.push({
      rule: "消費者庁ガイドライン (推奨)",
      severity: "warning",
      hint: "外部窓口 (顧問弁護士/外部CSR会社) の併設が望ましい (内部のみだと心理的ハードル高)。",
    });
  }
  if (!profile.has_anonymous_channel) {
    findings.push({
      rule: "消費者庁ガイドライン (推奨)",
      severity: "warning",
      hint: "匿名通報チャネルの提供を推奨 (報復リスクへの配慮)。",
    });
  }
  return findings;
}

export type ReporterType =
  | "employee" // 現職労働者
  | "retired_employee" // 退職者 (退職後1年以内、R4改正で保護対象)
  | "officer" // 役員 (R4改正で保護対象)
  | "subcontractor" // 取引先労働者
  | "outside";

export interface WhistleblowerCase {
  case_id: string;
  reported_at: string; // ISO
  reporter_type: ReporterType;
  reporter_anonymity: "named" | "pseudonym" | "anonymous";
  channel: "internal_hr" | "external_lawyer" | "compliance_committee" | "regulatory_authority" | "media";
  category: "labor_violation" | "fraud" | "harassment" | "safety" | "data_breach" | "antitrust" | "other";
  description: string;
  evidence_attached?: boolean;
  status: "received" | "triage" | "investigating" | "concluded" | "rejected";
  protected_under_law?: boolean;
}

export function isProtectedReporter(c: WhistleblowerCase): boolean {
  // R4改正で退職者(退職1年以内)/役員も保護対象に拡大
  return ["employee", "retired_employee", "officer", "subcontractor"].includes(c.reporter_type);
}

export interface ChannelEvaluation {
  channel: WhistleblowerCase["channel"];
  protection_strength: "strong" | "medium" | "weak";
  required_conditions: string[];
}

const CHANNEL_TABLE: ChannelEvaluation[] = [
  {
    channel: "internal_hr",
    protection_strength: "strong",
    required_conditions: ["通報内容に真実相当性あり"],
  },
  {
    channel: "external_lawyer",
    protection_strength: "strong",
    required_conditions: ["事業者外部の通報先(弁護士/外部CSR会社)を事前指定済み"],
  },
  {
    channel: "compliance_committee",
    protection_strength: "strong",
    required_conditions: ["コンプライアンス委員会など独立性のある内部窓口"],
  },
  {
    channel: "regulatory_authority",
    protection_strength: "medium",
    required_conditions: [
      "通報内容が真実であると信じる相当な理由",
      "または書面通報で氏名/連絡先記載 (法3条2号)",
    ],
  },
  {
    channel: "media",
    protection_strength: "weak",
    required_conditions: [
      "内部通報で人身被害発生の差し迫った危険",
      "または内部通報で証拠隠滅の恐れ",
      "または内部通報後20日以内に調査開始されない",
      "通報内容が真実",
    ],
  },
];

export function evaluateChannelProtection(
  channel: WhistleblowerCase["channel"],
): ChannelEvaluation {
  return CHANNEL_TABLE.find((c) => c.channel === channel) ?? {
    channel,
    protection_strength: "weak",
    required_conditions: ["公益通報者保護法の保護要件を充足していること"],
  };
}

export interface RetaliationCheck {
  case_id: string;
  events: { ts: string; type: "demotion" | "salary_cut" | "transfer" | "termination" | "harassment" | "other"; description: string }[];
  is_likely_retaliation: boolean;
  reasoning: string;
}

export function detectRetaliation(
  c: WhistleblowerCase,
  events: RetaliationCheck["events"],
): RetaliationCheck {
  const reportedAt = Date.parse(c.reported_at);
  const within1y = events.filter((e) => {
    const t = Date.parse(e.ts);
    return !Number.isNaN(t) && t > reportedAt && t - reportedAt < 365 * 24 * 60 * 60 * 1000;
  });
  const harshActions = within1y.filter((e) =>
    ["demotion", "salary_cut", "termination"].includes(e.type),
  );
  if (isProtectedReporter(c) && harshActions.length > 0) {
    return {
      case_id: c.case_id,
      events: within1y,
      is_likely_retaliation: true,
      reasoning:
        "保護対象通報者に対して、通報後1年以内に降格/減給/解雇が発生。法5条 (不利益取扱い禁止) 違反の可能性。立証責任は事業者側に転換 (R4改正)。",
    };
  }
  return {
    case_id: c.case_id,
    events: within1y,
    is_likely_retaliation: false,
    reasoning: "通報後の不利益取扱いは検出されていない、または保護対象外。",
  };
}

export interface CaseTimeline {
  received_at: string;
  acknowledged_within_days: number; // 受領通知 (推奨: 20日以内)
  initial_response_within_days: number; // 調査着手 (推奨: 30日以内)
  conclusion_within_days?: number;
  exceeded_recommended_window: boolean;
}

const RECOMMENDED_ACKNOWLEDGE_DAYS = 20;
const RECOMMENDED_INVESTIGATION_START_DAYS = 30;

export function evaluateTimeline(
  receivedAt: string,
  acknowledgedAt: string,
  investigationStartedAt: string,
  concludedAt?: string,
): CaseTimeline {
  const r = Date.parse(receivedAt);
  const a = Date.parse(acknowledgedAt);
  const i = Date.parse(investigationStartedAt);
  const c = concludedAt ? Date.parse(concludedAt) : undefined;
  const ackDays = Math.round((a - r) / (24 * 60 * 60 * 1000));
  const investDays = Math.round((i - r) / (24 * 60 * 60 * 1000));
  const concDays = c ? Math.round((c - r) / (24 * 60 * 60 * 1000)) : undefined;
  return {
    received_at: receivedAt,
    acknowledged_within_days: ackDays,
    initial_response_within_days: investDays,
    conclusion_within_days: concDays,
    exceeded_recommended_window:
      ackDays > RECOMMENDED_ACKNOWLEDGE_DAYS ||
      investDays > RECOMMENDED_INVESTIGATION_START_DAYS,
  };
}

export function buildPolicyTemplate(orgName: string): string {
  return `# ${orgName} 公益通報者保護規程

## 第1条 (目的)
本規程は、公益通報者保護法 (平成16年法律第122号) に基づき、
${orgName} (以下「当社」) における公益通報の処理体制及び公益通報者の保護を定めることを目的とする。

## 第2条 (定義)
1. 「公益通報」とは、労働者・退職者 (退職後1年以内)・役員・取引先労働者が、
   不正の利益を得る目的等でなく、当社又は当社の役員・従業員等の通報対象事実を、
   通報先 (内部窓口/外部窓口/行政機関/その他) に通報することをいう。

## 第3条 (通報窓口)
1. 内部通報窓口: コンプライアンス部
2. 外部通報窓口: 顧問弁護士事務所 (XX法律事務所)
3. 匿名通報も受け付ける。

## 第4条 (公益通報対応業務従事者の指定)
代表取締役は、公益通報対応業務 (受付・調査・是正措置) に従事する者を書面により指定する。
被指定者は刑事罰付き守秘義務 (30万円以下の罰金) を負う。

## 第5条 (不利益取扱いの禁止)
当社は、公益通報を行ったことを理由として、解雇・降格・減給・配置転換・嫌がらせ等の
不利益な取扱いをしてはならない。

## 第6条 (調査・是正)
1. 通報受付後、20日以内に通報者へ受領を通知する。
2. 30日以内に調査に着手する。
3. 是正措置を講じた場合、その内容を通報者に通知する (匿名通報を除く)。

## 第7条 (記録の保存)
通報・調査・処分の記録は3年間 WORM 形式で保管する (個情法 安全管理措置)。
`;
}
