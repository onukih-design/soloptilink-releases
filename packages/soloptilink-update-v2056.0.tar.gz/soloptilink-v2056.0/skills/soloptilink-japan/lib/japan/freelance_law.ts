/**
 * SoloptiLinkAI Phase 45 — フリーランス新法対応
 *
 * 特定受託事業者に係る取引の適正化等に関する法律 (令和5年法律第25号)
 * 通称: フリーランス・事業者間取引適正化等法 / フリーランス新法
 *
 * - 公布: 2023-05-12 (R5.5.12)
 * - 施行: 2024-11-01 (R6.11.1)
 * - ガイドライン: 2024-05-31 公表 / 2025-10-01 改正版 (R7.10.1)
 * - 主管庁: 公正取引委員会・中小企業庁 (取引適正化) / 厚生労働省 (就業環境整備)
 *
 * カバー範囲:
 *  - 第3条 取引条件明示義務 (11項目)
 *  - 第4条 報酬支払期日 (給付受領日 + 60日以内、再委託特則 30日)
 *  - 第5条 禁止行為7類型 (受領拒否/減額/返品/買いたたき/購入強制/利益提供/不当やり直し)
 *  - 第14条 妊娠出産育児介護への配慮 (6ヶ月以上の継続業務委託)
 *  - 第16条 ハラスメント防止体制
 *  - 第18条 中途解除の30日前予告
 *  - 第24-25条 勧告・命令・公表
 *  - 第28条 罰則 (50万円以下の罰金、両罰規定)
 *  - 下請法との二重適用ロジック
 *
 * SoT: https://laws.e-gov.go.jp/law/505AC0000000025
 *      https://www.jftc.go.jp/file/fl_jftcmhlwguidelines.pdf
 */

export const FREELANCE_LAW_VERSION = "R7.10.1";
export const FREELANCE_LAW_EFFECTIVE = "2024-11-01";

export const FREELANCE_LAW_ARTICLES = {
  ART_3: { name: "取引条件明示", method: "書面/電磁的方法", timing: "直ちに" },
  ART_4: { name: "報酬支払期日", limit_days: 60, base: "給付受領日", reconsign_limit_days: 30 },
  ART_5: { name: "禁止行為7類型", scope: "1ヶ月以上の業務委託" },
  ART_14: { name: "妊娠・出産・育児・介護への配慮", scope: "6ヶ月以上の継続業務委託" },
  ART_16: { name: "ハラスメント防止体制" },
  ART_18: { name: "中途解除の事前予告", notice_days: 30, scope: "6ヶ月以上の継続契約" },
  ART_24: { name: "勧告" },
  ART_25: { name: "命令・公表" },
  ART_28: { name: "罰則", fine_jpy: 500_000, dual_liability: true },
} as const;

export const PROHIBITED_ACTS_7 = [
  "RECEIPT_REFUSAL",
  "PAYMENT_REDUCTION",
  "RETURN",
  "BUYING_AT_LOW_PRICE",
  "FORCED_PURCHASE",
  "UNJUST_PROFIT",
  "UNJUST_REWORK",
] as const;
export type ProhibitedAct = (typeof PROHIBITED_ACTS_7)[number];

export const DISCLOSURE_REQUIRED_11 = [
  "ordering_party_name",
  "receiving_party_name",
  "consigned_at",
  "work_description",
  "delivery_received_at",
  "delivery_received_place",
  "inspection_completed_at",
  "remuneration_amount",
  "payment_due_at",
  "payment_method_when_non_cash",
  "electronic_method_designation",
] as const;
export type DisclosureItem = (typeof DISCLOSURE_REQUIRED_11)[number];

export const HARASSMENT_TYPES = ["SEXUAL", "MATERNITY", "POWER"] as const;
export type HarassmentType = (typeof HARASSMENT_TYPES)[number];

export interface ApplicabilityInput {
  receiver: { isIndividual: boolean; isOnePersonCorp: boolean; hasEmployees: boolean };
  commissioner: { hasEmployees: boolean };
  hasLaborSubordination: boolean;
}

export interface DisclosureDoc {
  items_present: ReadonlyArray<DisclosureItem>;
  is_written_or_electronic: boolean;
  delivered_immediately: boolean;
}

export interface PaymentInput {
  receivedAt: Date;
  paymentDueAt: Date;
  isReConsignment: boolean;
  parentPaymentDate?: Date;
}

export interface TransactionEvent {
  kind: ProhibitedAct;
  cause_attributable_to_receiver: boolean;
  agreed_in_advance?: boolean;
  evidence?: string;
}

export interface TerminationInput {
  contractStart: Date;
  contractEnd: Date;
  terminationDate: Date;
  noticeSentAt: Date;
  noticeMethod: "WRITTEN" | "FAX" | "EMAIL" | "VERBAL";
}

export interface HarassmentPolicy {
  has_sop_sexual: boolean;
  has_sop_maternity: boolean;
  has_sop_power: boolean;
  has_consult_desk: boolean;
  has_training_program: boolean;
}

export type ErrorCode =
  | "ART3_MISSING_ITEM"
  | "ART3_NOT_WRITTEN"
  | "ART3_NOT_IMMEDIATE"
  | "ART4_OVER_60D"
  | "ART4_OVER_30D_RECON"
  | "ART4_NO_DUE_DATE"
  | `ART5_${ProhibitedAct}`
  | "ART16_LESS_THAN_30D"
  | "ART16_INVALID_METHOD"
  | "ART16_NOT_APPLICABLE_UNDER_6M"
  | "ART14_MISSING_SOP";

export interface Finding {
  code: ErrorCode;
  rule: string;
  severity: "info" | "warning" | "violation";
  hint: string;
  field?: string;
}

const DAY_MS = 24 * 3600 * 1000;
const diffDays = (a: Date, b: Date) => Math.floor((a.getTime() - b.getTime()) / DAY_MS);

/** 適用判定: フリーランス新法が適用される取引か */
export function isFreelanceLawApplicable(input: ApplicabilityInput): { applies: boolean; reason: string } {
  if (input.hasLaborSubordination) {
    return { applies: false, reason: "労働者性が認められるため労働関係法令が優先" };
  }
  const isFreelance = input.receiver.isIndividual || (input.receiver.isOnePersonCorp && !input.receiver.hasEmployees);
  if (!isFreelance) {
    return { applies: false, reason: "受託者が特定受託事業者に該当しない" };
  }
  if (!input.commissioner.hasEmployees) {
    return { applies: false, reason: "委託者が個人かつ従業員なし → 法対象外 (BtoB除外)" };
  }
  return { applies: true, reason: "特定受託事業者×特定業務委託事業者の構成を満たす" };
}

/** 第3条: 取引条件11項目の明示チェック */
export function validateDisclosure(doc: DisclosureDoc): { ok: boolean; missing: DisclosureItem[]; findings: Finding[] } {
  const findings: Finding[] = [];
  const present = new Set<DisclosureItem>(doc.items_present);
  const missing = DISCLOSURE_REQUIRED_11.filter((k) => !present.has(k)) as DisclosureItem[];

  for (const m of missing) {
    findings.push({
      code: "ART3_MISSING_ITEM",
      rule: "フリーランス新法 第3条 (取引条件明示)",
      severity: "violation",
      hint: `必須項目「${m}」が欠落。書面/電磁的方法での明示が必要。`,
      field: m,
    });
  }
  if (!doc.is_written_or_electronic) {
    findings.push({
      code: "ART3_NOT_WRITTEN",
      rule: "フリーランス新法 第3条",
      severity: "violation",
      hint: "口頭のみの取引条件は違反。書面または電磁的方法で明示すること。",
    });
  }
  if (!doc.delivered_immediately) {
    findings.push({
      code: "ART3_NOT_IMMEDIATE",
      rule: "フリーランス新法 第3条",
      severity: "violation",
      hint: "業務委託をしたとき直ちに明示する必要がある。",
    });
  }
  return { ok: findings.length === 0 && missing.length === 0, missing, findings };
}

/** 第4条: 報酬支払期日 (受領日+60日以内、再委託は親支払日+30日以内) */
export function validatePaymentDeadline(input: PaymentInput): {
  ok: boolean;
  effectiveDueAt: Date;
  daysFromReceived: number;
  findings: Finding[];
} {
  const findings: Finding[] = [];
  const limitDays = input.isReConsignment ? FREELANCE_LAW_ARTICLES.ART_4.reconsign_limit_days : FREELANCE_LAW_ARTICLES.ART_4.limit_days;
  const lawfulMax = new Date(input.receivedAt.getTime() + limitDays * DAY_MS);
  const effectiveDueAt = input.paymentDueAt > lawfulMax ? lawfulMax : input.paymentDueAt;
  const days = diffDays(input.paymentDueAt, input.receivedAt);

  if (days > limitDays) {
    findings.push({
      code: input.isReConsignment ? "ART4_OVER_30D_RECON" : "ART4_OVER_60D",
      rule: "フリーランス新法 第4条 (報酬支払期日)",
      severity: "violation",
      hint: `支払期日が法定上限 (${limitDays}日) を超過 (${days}日)。法定期日に強制丸め。`,
    });
  }
  if (input.isReConsignment && !input.parentPaymentDate) {
    findings.push({
      code: "ART4_NO_DUE_DATE",
      rule: "フリーランス新法 第4条 (再委託特則)",
      severity: "warning",
      hint: "再委託の場合、親事業者の支払日起算で30日以内も検証されるが、親支払日が未設定。",
    });
  }
  return { ok: findings.length === 0, effectiveDueAt, daysFromReceived: days, findings };
}

/** 第5条: 禁止行為7類型の検出 */
export function detectProhibitedActs(events: ReadonlyArray<TransactionEvent>): { findings: Finding[] } {
  const findings: Finding[] = [];
  for (const e of events) {
    if (e.cause_attributable_to_receiver) continue;
    findings.push({
      code: `ART5_${e.kind}` as ErrorCode,
      rule: "フリーランス新法 第5条 (禁止行為)",
      severity: "violation",
      hint: `${e.kind} は受託者の責に帰すべき事由がない場合は禁止。${e.agreed_in_advance ? "事前合意があっても違反。" : ""}${e.evidence ?? ""}`,
    });
  }
  return { findings };
}

/** 第16/18条: 中途解除の30日前予告 (条番号は法版で揺れるため定数で吸収) */
export function validateTerminationNotice(input: TerminationInput): {
  ok: boolean;
  daysAhead: number;
  findings: Finding[];
} {
  const findings: Finding[] = [];
  const contractMonths = (input.contractEnd.getTime() - input.contractStart.getTime()) / (30 * DAY_MS);
  if (contractMonths < 6) {
    findings.push({
      code: "ART16_NOT_APPLICABLE_UNDER_6M",
      rule: "フリーランス新法 第16条/第18条 (中途解除予告)",
      severity: "info",
      hint: "6ヶ月以上の継続契約のみ予告義務あり。本契約は適用外。",
    });
    return { ok: true, daysAhead: 0, findings };
  }
  const daysAhead = diffDays(input.terminationDate, input.noticeSentAt);
  if (daysAhead < 30) {
    findings.push({
      code: "ART16_LESS_THAN_30D",
      rule: "フリーランス新法 第16条/第18条",
      severity: "violation",
      hint: `予告日数 ${daysAhead}日 が法定30日未満。書面/FAX/電子メールでの30日前予告が必須。`,
    });
  }
  if (input.noticeMethod === "VERBAL") {
    findings.push({
      code: "ART16_INVALID_METHOD",
      rule: "フリーランス新法 第16条/第18条",
      severity: "violation",
      hint: "口頭予告は無効。書面・FAX・電子メールのいずれかが必要。",
    });
  }
  return { ok: findings.length === 0, daysAhead, findings };
}

/** 第14/16条: ハラスメント防止体制チェック */
export function validateHarassmentSystem(policy: HarassmentPolicy): { ok: boolean; findings: Finding[] } {
  const findings: Finding[] = [];
  if (!policy.has_sop_sexual) {
    findings.push({ code: "ART14_MISSING_SOP", rule: "フリーランス新法 第14条", severity: "violation", hint: "セクハラ防止規程が未整備。" });
  }
  if (!policy.has_sop_maternity) {
    findings.push({ code: "ART14_MISSING_SOP", rule: "フリーランス新法 第14条", severity: "violation", hint: "マタハラ防止規程が未整備。" });
  }
  if (!policy.has_sop_power) {
    findings.push({ code: "ART14_MISSING_SOP", rule: "フリーランス新法 第14条", severity: "violation", hint: "パワハラ防止規程が未整備。" });
  }
  if (!policy.has_consult_desk) {
    findings.push({ code: "ART14_MISSING_SOP", rule: "フリーランス新法 第14条", severity: "warning", hint: "相談窓口の設置が望ましい。" });
  }
  if (!policy.has_training_program) {
    findings.push({ code: "ART14_MISSING_SOP", rule: "フリーランス新法 第14条", severity: "warning", hint: "教育研修プログラムの整備が望ましい。" });
  }
  return { ok: findings.length === 0, findings };
}

/** 下請法との二重適用判定 */
export function dualLawCompliance(input: { commissioner_capital_jpy: number; subcontract_act_categories_match: boolean }): {
  primary: "FREELANCE_LAW";
  secondary: "SUBCONTRACT_LAW" | "NONE";
  reason: string;
} {
  const apply = input.commissioner_capital_jpy > 10_000_000 && input.subcontract_act_categories_match;
  return {
    primary: "FREELANCE_LAW",
    secondary: apply ? "SUBCONTRACT_LAW" : "NONE",
    reason: apply
      ? "資本金1000万円超 × 4取引類型該当 → 下請法も同時適用。フリーランス新法を優先適用しつつ監査ログには両方記録。"
      : "下請法非該当 → フリーランス新法のみ適用。",
  };
}

/** Phase 45 self check: モジュール健全性 (tests からも呼ばれる) */
export function selfCheck(): { ok: boolean; checks: Array<{ name: string; pass: boolean }> } {
  const checks = [
    { name: "ART_4 60日定数", pass: FREELANCE_LAW_ARTICLES.ART_4.limit_days === 60 },
    { name: "ART_4 再委託30日定数", pass: FREELANCE_LAW_ARTICLES.ART_4.reconsign_limit_days === 30 },
    { name: "禁止行為7類型", pass: PROHIBITED_ACTS_7.length === 7 },
    { name: "明示11項目", pass: DISCLOSURE_REQUIRED_11.length === 11 },
    { name: "罰則50万円", pass: FREELANCE_LAW_ARTICLES.ART_28.fine_jpy === 500_000 },
    {
      name: "60日違反検出",
      pass: validatePaymentDeadline({ receivedAt: new Date("2026-01-01"), paymentDueAt: new Date("2026-04-01"), isReConsignment: false }).ok === false,
    },
    {
      name: "適用判定: 個人×法人発注",
      pass: isFreelanceLawApplicable({ receiver: { isIndividual: true, isOnePersonCorp: false, hasEmployees: false }, commissioner: { hasEmployees: true }, hasLaborSubordination: false }).applies === true,
    },
    {
      name: "適用判定: 労働者性ありで除外",
      pass: isFreelanceLawApplicable({ receiver: { isIndividual: true, isOnePersonCorp: false, hasEmployees: false }, commissioner: { hasEmployees: true }, hasLaborSubordination: true }).applies === false,
    },
  ];
  return { ok: checks.every((c) => c.pass), checks };
}
