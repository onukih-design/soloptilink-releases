/**
 * lib/japan/maritime.ts — 海運・港湾DNA
 *
 * 法令カバレッジ:
 *  - 海上運送法 (S24法律187)
 *  - 内航海運業法 (S27法律151)
 *  - 港湾法 (S25法律218) 港湾分類 / 入出港届
 *  - 港則法 (S23法律174) 特定港の航法
 *  - 船員法 (S22法律100) 労働条件 / 船員手帳
 *  - 船舶法 (M32法律46) 日本船舶 / トン数
 *  - 船舶安全法 (S8法律11) 船舶検査
 *  - 国際条約 SOLAS (海上人命安全条約) / MARPOL (海洋汚染防止) / STCW (船員資格訓練)
 *  - IMO ISM Code (国際安全管理規則)
 *  - SOx規制 0.5% (IMO 2020)
 *
 * 参考: 国土交通省海事局, 海上保安庁, 日本海運会, 船員労働協会
 */

// ============================================================================
// 1. 港湾分類 (港湾法 + 港則法)
// ============================================================================

export type PortClass = 'special_major' | 'major' | 'industrial_specialized' | 'local' | 'minor_57jou';

export const MAJOR_JAPANESE_PORTS: { name: string; class: PortClass; isTokuteiKou: boolean }[] = [
  { name: '東京港', class: 'special_major', isTokuteiKou: true },
  { name: '横浜港', class: 'special_major', isTokuteiKou: true },
  { name: '川崎港', class: 'major', isTokuteiKou: true },
  { name: '名古屋港', class: 'special_major', isTokuteiKou: true },
  { name: '大阪港', class: 'special_major', isTokuteiKou: true },
  { name: '神戸港', class: 'special_major', isTokuteiKou: true },
  { name: '北九州港', class: 'special_major', isTokuteiKou: true },
  { name: '博多港', class: 'major', isTokuteiKou: true },
  { name: '苫小牧港', class: 'major', isTokuteiKou: true },
  { name: '千葉港', class: 'major', isTokuteiKou: true },
];

/** 入出港届 (港則法4条) — 特定港のみ義務 */
export function requiresPortEntryNotification(portName: string): {
  required: boolean;
  reason: string;
  formName: string;
} {
  const port = MAJOR_JAPANESE_PORTS.find((p) => p.name === portName);
  if (port?.isTokuteiKou) {
    return {
      required: true,
      reason: '特定港のため港則法4条により入出港届が必須',
      formName: '入港届 / 出港届',
    };
  }
  return {
    required: false,
    reason: '特定港でないため港則法4条の対象外',
    formName: '不要 (港湾管理者により別途規定あり)',
  };
}

// ============================================================================
// 2. 船舶トン数 + 検査 (船舶法 + 船舶安全法)
// ============================================================================

export type VesselUse = 'cargo' | 'tanker' | 'passenger' | 'fishing' | 'tug' | 'pleasure';

export interface VesselSpec {
  grossTonnage: number; // 総トン数
  netTonnage: number; // 純トン数
  loa: number; // 全長 m
  use: VesselUse;
  isInternational: boolean; // 国際航海
  builtYear: number;
}

/** 船舶検査の周期 (船舶安全法5条) */
export function calcInspectionSchedule(v: VesselSpec): {
  periodicalEveryYears: number; // 定期検査
  intermediateAfterYears: number; // 中間検査
  needsAnnualSurveys: boolean;
} {
  // 旅客船は5年ごと、危険物船は5年、その他は4-5年
  const periodicalEveryYears = v.use === 'passenger' || v.use === 'tanker' ? 5 : 5;
  return {
    periodicalEveryYears,
    intermediateAfterYears: 2.5,
    needsAnnualSurveys: v.grossTonnage >= 500,
  };
}

/** 船舶国籍証書 取得要件 (船舶法1条) — 日本船舶 */
export function isJapaneseVessel(input: {
  ownerNationality: 'JP' | 'foreign';
  ownerKind: 'individual' | 'corporation';
  corporationJapaneseShareRatio?: number;
}): { isJapaneseFlag: boolean; reason: string } {
  if (input.ownerNationality === 'JP' && input.ownerKind === 'individual') {
    return { isJapaneseFlag: true, reason: '日本国民の所有' };
  }
  if (input.ownerKind === 'corporation' && (input.corporationJapaneseShareRatio ?? 0) >= 0.5) {
    return {
      isJapaneseFlag: true,
      reason: '日本法人の所有 (代表者+業務執行取締役の2/3以上が日本国民) — 船舶法1条',
    };
  }
  return { isJapaneseFlag: false, reason: '便宜置籍 (パナマ/リベリア等) または条件未充足' };
}

// ============================================================================
// 3. STCW 船員資格 (Standards of Training, Certification and Watchkeeping)
// ============================================================================

export type StcwCert =
  | 'master' // 船長
  | 'chief_officer' // 一等航海士
  | 'second_officer' // 二等航海士
  | 'third_officer' // 三等航海士
  | 'chief_engineer' // 機関長
  | 'first_engineer'
  | 'second_engineer'
  | 'third_engineer'
  | 'gmdss_radio'; // GMDSS無線

/** STCW 当直要員配置の最低基準 */
export function calcMinimumManning(input: {
  vesselUse: VesselUse;
  grossTonnage: number;
  voyageType: 'international' | 'coastal';
}): { deck: number; engine: number; radio: number; total: number } {
  let deck = 0;
  let engine = 0;
  let radio = 0;

  if (input.grossTonnage >= 5000) {
    deck = 5; // 船長 + 3航海士 + 甲板部員1
    engine = 4; // 機関長 + 3機関士
    radio = 1;
  } else if (input.grossTonnage >= 500) {
    deck = 4;
    engine = 3;
    radio = 1;
  } else {
    deck = 2;
    engine = 1;
    radio = 0;
  }
  if (input.vesselUse === 'passenger') {
    deck += 2; // 旅客対応
  }
  return { deck, engine, radio, total: deck + engine + radio };
}

// ============================================================================
// 4. 船員労働 (船員法)
// ============================================================================

/**
 * 船員法65条以下: 労働時間 1日8時間 / 1週40時間
 * 例外として 1週72時間まで延長可 (有償)
 */
export function checkSeafarerLabourCompliance(input: {
  weeklyWorkingHours: number;
  weeklyRestHours: number;
  daysAtSeaInRow: number;
}): { compliant: boolean; warnings: string[] } {
  const w: string[] = [];
  if (input.weeklyWorkingHours > 72) w.push('週72時間超 — 船員法違反');
  if (input.weeklyRestHours < 77) w.push('週休77時間未満 (STCW準拠 1日10h/週77h)');
  if (input.daysAtSeaInRow > 90) w.push('連続90日超の乗船 — 休暇取得が必要 (船員法73条)');
  return { compliant: w.length === 0, warnings: w };
}

// ============================================================================
// 5. SOLAS / MARPOL / ISM Code
// ============================================================================

/** SOLAS Chapter適用判定 (簡易) */
export const SOLAS_CHAPTERS = {
  I: '一般規定',
  II_1: '構造区画 / 復原性 / 機関 / 電気',
  II_2: '防火 / 火災探知 / 消火',
  III: '救命設備 / 救命艇',
  IV: '無線通信 (GMDSS)',
  V: '航海安全',
  VI: '貨物運送',
  VII: '危険物運送',
  IX: 'ISM Code (国際安全管理規則)',
  XI_1: '海上保安強化措置',
  XI_2: 'ISPS Code (船舶港湾施設保安)',
  XII: 'ばら積み貨物船追加要件',
} as const;

/** ISM Code (SOLAS Ch IX) 適合: SMS (Safety Management System) DOC + SMC */
export function checkIsmCompliance(input: {
  hasDocCertificate: boolean; // Document of Compliance (会社)
  docExpiryDate: Date;
  hasSmcCertificate: boolean; // Safety Management Certificate (船舶)
  smcExpiryDate: Date;
}): { compliant: boolean; expiringSoon: boolean; gaps: string[] } {
  const gaps: string[] = [];
  if (!input.hasDocCertificate) gaps.push('DOC (Document of Compliance) 未取得');
  if (!input.hasSmcCertificate) gaps.push('SMC (Safety Management Certificate) 未取得');
  const ms = 90 * 86400000;
  const expiringSoon =
    input.docExpiryDate.getTime() - Date.now() < ms ||
    input.smcExpiryDate.getTime() - Date.now() < ms;
  return { compliant: gaps.length === 0, expiringSoon, gaps };
}

// ============================================================================
// 6. SOx規制 (IMO 2020) + MARPOL Annex VI
// ============================================================================

/** 一般海域: 0.5%以下、ECA (排出規制海域): 0.10%以下 */
export function checkFuelSulfurCompliance(input: {
  fuelSulfurPercent: number;
  isInEca: boolean; // 排出規制海域内か
}): { compliant: boolean; limit: number; reason: string } {
  const limit = input.isInEca ? 0.1 : 0.5;
  return {
    compliant: input.fuelSulfurPercent <= limit,
    limit,
    reason: input.isInEca
      ? 'ECA (北米/北海/バルト海/カリブ海等) 内 — 0.10%上限'
      : 'IMO 2020 一般海域 — 0.50%上限',
  };
}

// ============================================================================
// 7. 内航海運業法 (船腹調整 + 暫定措置事業)
// ============================================================================

/** 内航海運業の登録要件 */
export function isCabotageEligible(input: {
  isJapaneseFlag: boolean;
  isJapaneseCrew: boolean;
}): { eligible: boolean; reason: string } {
  if (!input.isJapaneseFlag) {
    return {
      eligible: false,
      reason: 'カボタージュ規制 (船舶法3条) — 内航は日本籍船のみ',
    };
  }
  if (!input.isJapaneseCrew) {
    return {
      eligible: false,
      reason: '内航は原則日本人船員乗組み (例外: 外国人船員特例)',
    };
  }
  return { eligible: true, reason: 'カボタージュ要件充足' };
}

// ============================================================================
// 8. 港湾運送事業法
// ============================================================================

export const PORT_TRANSPORT_LICENSES = {
  general: '一般港湾運送事業 (元請)',
  stevedoring: '港湾荷役事業 (船内/沿岸荷役)',
  warehousing: '港湾倉庫事業',
  pilotage: '水先人 (パイロット)',
  ikadanagashi: 'いかだ運送',
  rafting: '艀運送',
} as const;

/** 港湾運送事業免許の必要要件 */
export function evaluatePortTransportLicense(input: {
  capitalJpy: number;
  hasPortFacility: boolean;
  hasQualifiedManager: boolean;
}): { approvable: boolean; gaps: string[] } {
  const gaps: string[] = [];
  if (input.capitalJpy < 30_000_000) gaps.push('一般港湾運送事業は資本金3000万円以上');
  if (!input.hasPortFacility) gaps.push('係留施設 / 倉庫の確保が必要');
  if (!input.hasQualifiedManager) gaps.push('港湾運送事業経営管理者の選任必須');
  return { approvable: gaps.length === 0, gaps };
}
