/**
 * lib/japan/auto_repair.ts — 自動車整備業DNA
 *
 * 法令カバレッジ:
 *  - 道路運送車両法 (S26法律185) 整備事業の認証/指定
 *  - 道路運送車両法施行規則
 *  - 自動車点検基準 (S26運輸省令70号)
 *  - 自動車検査独立行政法人 (車検)
 *  - OBD車検 (R3.10〜R6.10 全車種)
 *  - 特定整備制度 (R2.4施行 — 旧 分解整備 + 電子制御装置整備)
 *  - 自動車整備士技能検定 (1級/2級/3級 + 特殊整備士)
 *  - 自動車リサイクル法 (H14法律87)
 *
 * 参考: 国土交通省自動車局, 日本自動車整備振興会連合会 (JASPA)
 */

// ============================================================================
// 1. 整備事業の区分 (道路運送車両法78条)
// ============================================================================

export type GarageLicense =
  | 'certified' // 認証工場 (78条) — 分解整備 / 特定整備
  | 'designated' // 指定工場 (94条の2) — 民間車検場 (完成検査権限)
  | 'unauthorized'; // 無認証 — 分解整備不可

/** 整備事業の認証要件 (規則57条 — 工員数 / 設備 / 規模) */
export interface GarageRequirements {
  carKind: 'compact' | 'small' | 'large_truck' | 'two_wheel' | 'special';
  workerCount: number; // 整備工員数
  certifiedMechanicCount: number; // 整備士 (2級以上)
  hasInspectionEquipment: boolean; // テスタ + リフト + 計器類
  garageAreaM2: number;
}

/**
 * 認証工場 (78条) の最低要件 — 規則57条
 *  小型自動車: 工員2名以上 + 整備士1名以上 + 規定の設備
 */
export function evaluateCertifiedGarageRequirements(g: GarageRequirements): {
  eligible: boolean;
  blockers: string[];
} {
  const blockers: string[] = [];
  const minWorkers = g.carKind === 'two_wheel' ? 1 : 2;
  if (g.workerCount < minWorkers) blockers.push(`整備工員 ${minWorkers} 名以上必須`);
  if (g.certifiedMechanicCount < 1) {
    blockers.push('2級以上の自動車整備士 1名以上必須 (主任整備士または整備主任者)');
  }
  if (!g.hasInspectionEquipment) {
    blockers.push('テスタ (サイドスリップ/ブレーキ/スピード) + リフト + 工作機器が必要');
  }
  const minArea = g.carKind === 'large_truck' ? 100 : g.carKind === 'two_wheel' ? 30 : 60;
  if (g.garageAreaM2 < minArea) blockers.push(`作業場面積 ${minArea}m² 以上必須`);
  return { eligible: blockers.length === 0, blockers };
}

/**
 * 指定工場 (94条の2 — 民間車検場) — 認証工場の上位。完成検査権限を持つ。
 *  追加要件: 検査主任者 + 完成検査記録簿 + 検査機器の精度維持
 */
export function evaluateDesignatedGarageRequirements(input: {
  isCertifiedGarage: boolean;
  hasInspectionChiefSupervisor: boolean; // 検査主任者 (3年以上の整備主任者経験 + 国交大臣指定講習)
  hasCalibratedTesters: boolean;
  monthlyInspectionVolumePastYear: number;
}): { eligible: boolean; blockers: string[] } {
  const blockers: string[] = [];
  if (!input.isCertifiedGarage) blockers.push('まず認証工場 (78条) 取得が前提');
  if (!input.hasInspectionChiefSupervisor) blockers.push('検査主任者 (国交大臣指定) 選任必須');
  if (!input.hasCalibratedTesters) blockers.push('検査機器の年次校正記録必要');
  if (input.monthlyInspectionVolumePastYear < 50) {
    blockers.push('月間50台以上の整備実績推奨 (運用ガイドライン)');
  }
  return { eligible: blockers.length === 0, blockers };
}

// ============================================================================
// 2. 特定整備制度 (R2.4施行)
// ============================================================================

export type SpecificMaintenanceCategory =
  | 'mechanical' // 旧 分解整備 (制動装置/走行装置/動力伝達装置等)
  | 'electronic_control' // 電子制御装置整備 (自動運転機能/カメラ/レーダー等)
  | 'both';

/** 特定整備の認証要件 (令和2年4月改正) */
export function evaluateSpecificMaintenance(input: {
  category: SpecificMaintenanceCategory;
  hasElectronicTrainedMechanic: boolean; // 電子制御装置整備の整備士 (3級電子整備士相当以上 等)
  hasScannerEquipment: boolean; // OBDスキャンツール (J-OBD2)
  hasWheelAlignmentTester: boolean;
}): { compliant: boolean; gaps: string[] } {
  const gaps: string[] = [];
  if (input.category !== 'mechanical' && !input.hasElectronicTrainedMechanic) {
    gaps.push('電子制御装置整備 — 電子整備士 (1級/2級/3級電子) 配置必須');
  }
  if (input.category !== 'mechanical' && !input.hasScannerEquipment) {
    gaps.push('OBDスキャンツール (J-OBD2) 必須');
  }
  if (input.category !== 'mechanical' && !input.hasWheelAlignmentTester) {
    gaps.push('カメラ・レーダー再エイミングが可能な装置必須');
  }
  return { compliant: gaps.length === 0, gaps };
}

// ============================================================================
// 3. 車検 (継続検査) + OBD車検
// ============================================================================

/** 車検有効期間 (道路運送車両法61条) */
export function calcShakenValidityYears(input: {
  vehicleKind: 'private_passenger' | 'business_passenger' | 'private_truck' | 'business_truck';
  totalWeightKg?: number;
  isFirstInspection: boolean;
  ageYears: number;
}): { years: number; reason: string } {
  // 自家用乗用 (新車3年, 以後2年)
  if (input.vehicleKind === 'private_passenger') {
    return input.isFirstInspection
      ? { years: 3, reason: '自家用乗用 初回 3年 (新車登録から)' }
      : { years: 2, reason: '自家用乗用 継続 2年' };
  }
  // 営業用乗用 (タクシー等) は 1年
  if (input.vehicleKind === 'business_passenger') {
    return { years: 1, reason: '事業用乗用 (タクシー等) 1年' };
  }
  // 自家用トラック (8トン以上は1年, 8トン未満は初回2年/以後1年, 軽は2年)
  if (input.vehicleKind === 'private_truck') {
    if ((input.totalWeightKg ?? 0) >= 8000) return { years: 1, reason: '自家用大型トラック (8t以上) 1年' };
    return input.isFirstInspection
      ? { years: 2, reason: '自家用小型トラック 初回 2年' }
      : { years: 1, reason: '自家用小型トラック 継続 1年' };
  }
  // 事業用トラック
  return { years: 1, reason: '事業用トラック 1年' };
}

/** OBD車検 (R3.10施行 / R6.10全車種義務化) — 実施対象判定 */
export function isObdInspectionRequired(input: {
  registrationYear: number;
  vehicleKind: 'passenger' | 'truck' | 'two_wheel';
  hasOlsda: boolean; // 自動運行装置 (OEDR含む)
}): { required: boolean; reason: string } {
  if (input.vehicleKind === 'two_wheel') return { required: false, reason: '二輪は対象外' };
  if (input.registrationYear < 2021) {
    return { required: false, reason: '2021年10月以前登録車は対象外 (道路運送車両法62条の3)' };
  }
  if (input.hasOlsda) {
    return { required: true, reason: '自動運行装置 (OEDR) 搭載車 — OBD読出義務' };
  }
  return { required: true, reason: 'R6.10以降 全対象車に拡大 — DTC + 法定指定モジュール読出' };
}

// ============================================================================
// 4. 自動車整備士 (技能検定)
// ============================================================================

export type MechanicGrade =
  | 'class1_grand' // 1級大型自動車整備士
  | 'class1_compact' // 1級小型自動車整備士
  | 'class2_gas' // 2級ガソリン
  | 'class2_diesel' // 2級ジーゼル
  | 'class3_gas' // 3級ガソリン
  | 'class3_diesel' // 3級ジーゼル
  | 'electronic'; // 電子制御装置整備士

/** 整備主任者 (規則62条) の要件 — 認証/指定工場の必須要員 */
export function isElegibleAsLeadMechanic(input: { grade: MechanicGrade; experienceYears: number }): {
  eligible: boolean;
  reason: string;
} {
  if (input.grade.startsWith('class1') || input.grade.startsWith('class2')) {
    return {
      eligible: input.experienceYears >= 1,
      reason: '1級または2級整備士 + 認証工場での実務1年以上',
    };
  }
  return { eligible: false, reason: '3級では整備主任者になれない (2級以上が必要)' };
}

// ============================================================================
// 5. 点検整備記録 (道路運送車両法49条)
// ============================================================================

/** 自動車検査証への記録 + 点検整備記録簿 保存期間 */
export function getRecordRetentionYears(vehicleKind: 'passenger' | 'truck' | 'business'): number {
  // 自家用乗用は次の点検まで, 事業用/トラックは1-2年保存
  if (vehicleKind === 'business' || vehicleKind === 'truck') return 2;
  return 1;
}

// ============================================================================
// 6. 自動車リサイクル法 連携
// ============================================================================

/** 使用済自動車 (廃車) の引渡 — フロン類/エアバッグ/シュレッダーダスト 3品目 */
export function calcEndOfLifeRecyclingFee(input: {
  vehicleType: 'passenger_compact' | 'passenger_normal' | 'minivan' | 'truck_2t' | 'truck_4t';
}): { feeJpy: number; breakdown: { item: string; subtotal: number }[] } {
  const fees = {
    passenger_compact: { freon: 1900, airbag: 2000, asr: 6000, info: 130 },
    passenger_normal: { freon: 1900, airbag: 2200, asr: 8000, info: 130 },
    minivan: { freon: 1900, airbag: 2400, asr: 12000, info: 130 },
    truck_2t: { freon: 1900, airbag: 2400, asr: 9000, info: 130 },
    truck_4t: { freon: 1900, airbag: 2600, asr: 14000, info: 130 },
  };
  const f = fees[input.vehicleType];
  const breakdown = [
    { item: 'フロン類料金', subtotal: f.freon },
    { item: 'エアバッグ料金', subtotal: f.airbag },
    { item: 'ASR (シュレッダーダスト)', subtotal: f.asr },
    { item: '情報管理料金', subtotal: f.info },
  ];
  return { feeJpy: breakdown.reduce((s, b) => s + b.subtotal, 0), breakdown };
}
