/**
 * SoloptiLinkAI Phase 43-IT — Incoterms 2020 + 貿易書類 (Incoterms)
 *
 * ICC (国際商業会議所) Incoterms 2020 11規則 + 貿易実務支援。
 *
 * カバー範囲:
 *  - Incoterms 2020 全11規則 (4 + 7 区分)
 *  - 危険負担/費用負担/書類責任の分岐点
 *  - L/C (Letter of Credit) 信用状取引
 *  - B/L (Bill of Lading) 船荷証券 + Sea/Air Waybill
 *  - インボイス (Commercial Invoice) + パッキングリスト
 *  - 海上保険 (Marine Insurance) + ICC 約款
 *  - 仲裁条項 (ICC Arbitration / JCAA)
 */

// Incoterms 2020 11規則
export type IncotermRule =
  | "EXW" // Ex Works
  | "FCA" // Free Carrier
  | "CPT" // Carriage Paid To
  | "CIP" // Carriage and Insurance Paid To
  | "DAP" // Delivered at Place
  | "DPU" // Delivered at Place Unloaded (旧DAT を 2020改訂)
  | "DDP" // Delivered Duty Paid
  | "FAS" // Free Alongside Ship
  | "FOB" // Free on Board
  | "CFR" // Cost and Freight
  | "CIF"; // Cost, Insurance and Freight

export type TransportMode = "any" | "sea_only";

export interface IncotermDefinition {
  rule: IncotermRule;
  full_name_en: string;
  name_ja: string;
  transport_mode: TransportMode;
  risk_transfer: string;
  cost_responsibility_seller: string[];
  cost_responsibility_buyer: string[];
  insurance_required_by_seller: boolean;
  insurance_minimum_coverage?: "ICC_A" | "ICC_C"; // 2020改訂で CIP=ICC(A), CIF=ICC(C)
  customs_export_clearance_by: "seller" | "buyer";
  customs_import_clearance_by: "seller" | "buyer";
  notes: string;
}

export const INCOTERMS_2020: IncotermDefinition[] = [
  {
    rule: "EXW",
    full_name_en: "Ex Works",
    name_ja: "工場渡し",
    transport_mode: "any",
    risk_transfer: "売主の指定場所 (工場/倉庫等) で買主の処分に委ねた時点",
    cost_responsibility_seller: ["商品の指定場所までの運搬"],
    cost_responsibility_buyer: ["積込/輸出通関/運送/保険/輸入通関"],
    insurance_required_by_seller: false,
    customs_export_clearance_by: "buyer",
    customs_import_clearance_by: "buyer",
    notes: "売主負担最少。買主の輸出通関リスクが高い (実務上推奨されない)",
  },
  {
    rule: "FCA",
    full_name_en: "Free Carrier",
    name_ja: "運送人渡し",
    transport_mode: "any",
    risk_transfer: "指定場所で運送人に引渡した時点",
    cost_responsibility_seller: ["輸出通関", "指定場所までの運搬"],
    cost_responsibility_buyer: ["主たる運送", "保険", "輸入通関"],
    insurance_required_by_seller: false,
    customs_export_clearance_by: "seller",
    customs_import_clearance_by: "buyer",
    notes: "2020改訂: 買主の運送人指示によるB/L発行可能",
  },
  {
    rule: "CPT",
    full_name_en: "Carriage Paid To",
    name_ja: "輸送費込み",
    transport_mode: "any",
    risk_transfer: "売主の指定運送人に引渡した時点 (発地)",
    cost_responsibility_seller: ["輸出通関", "目的地までの運送費"],
    cost_responsibility_buyer: ["保険", "目的地以降", "輸入通関"],
    insurance_required_by_seller: false,
    customs_export_clearance_by: "seller",
    customs_import_clearance_by: "buyer",
    notes: "費用と危険の分岐点が異なる",
  },
  {
    rule: "CIP",
    full_name_en: "Carriage and Insurance Paid To",
    name_ja: "輸送費保険料込み",
    transport_mode: "any",
    risk_transfer: "売主の指定運送人に引渡した時点 (発地)",
    cost_responsibility_seller: ["輸出通関", "目的地までの運送費", "保険料 (ICC(A) 拡大担保)"],
    cost_responsibility_buyer: ["目的地以降", "輸入通関"],
    insurance_required_by_seller: true,
    insurance_minimum_coverage: "ICC_A",
    customs_export_clearance_by: "seller",
    customs_import_clearance_by: "buyer",
    notes: "2020改訂: 保険レベル ICC(C)→ICC(A) に引上げ",
  },
  {
    rule: "DAP",
    full_name_en: "Delivered at Place",
    name_ja: "仕向地持込渡し",
    transport_mode: "any",
    risk_transfer: "輸入国の指定場所で荷卸し前の運送手段の上で",
    cost_responsibility_seller: ["輸出通関", "輸入国指定場所までの全費用"],
    cost_responsibility_buyer: ["荷卸し", "輸入通関"],
    insurance_required_by_seller: false,
    customs_export_clearance_by: "seller",
    customs_import_clearance_by: "buyer",
    notes: "DDP との違い: 輸入通関は買主",
  },
  {
    rule: "DPU",
    full_name_en: "Delivered at Place Unloaded",
    name_ja: "荷卸込持込渡し",
    transport_mode: "any",
    risk_transfer: "輸入国の指定場所で荷卸しが完了した時点",
    cost_responsibility_seller: ["輸出通関", "輸入国指定場所まで", "荷卸し"],
    cost_responsibility_buyer: ["輸入通関"],
    insurance_required_by_seller: false,
    customs_export_clearance_by: "seller",
    customs_import_clearance_by: "buyer",
    notes: "2020改訂: 旧DATをDPUに名称変更 (ターミナル限定→任意の場所OK)",
  },
  {
    rule: "DDP",
    full_name_en: "Delivered Duty Paid",
    name_ja: "関税込み持込渡し",
    transport_mode: "any",
    risk_transfer: "輸入国の指定場所で荷卸し前の運送手段の上で",
    cost_responsibility_seller: ["輸出通関", "全費用", "輸入関税/輸入通関"],
    cost_responsibility_buyer: ["荷卸し"],
    insurance_required_by_seller: false,
    customs_export_clearance_by: "seller",
    customs_import_clearance_by: "seller",
    notes: "売主負担最大。輸入国の許可・登録が必要な場合は不向き",
  },
  {
    rule: "FAS",
    full_name_en: "Free Alongside Ship",
    name_ja: "船側渡し",
    transport_mode: "sea_only",
    risk_transfer: "本船の船側に置かれた時点",
    cost_responsibility_seller: ["輸出通関", "船側までの運搬"],
    cost_responsibility_buyer: ["積込", "海上運送", "保険", "輸入通関"],
    insurance_required_by_seller: false,
    customs_export_clearance_by: "seller",
    customs_import_clearance_by: "buyer",
    notes: "海上輸送のみ。バルク貨物に多い",
  },
  {
    rule: "FOB",
    full_name_en: "Free on Board",
    name_ja: "本船渡し",
    transport_mode: "sea_only",
    risk_transfer: "本船上に置かれた時点 (積込完了)",
    cost_responsibility_seller: ["輸出通関", "本船積込まで"],
    cost_responsibility_buyer: ["海上運送", "保険", "輸入通関"],
    insurance_required_by_seller: false,
    customs_export_clearance_by: "seller",
    customs_import_clearance_by: "buyer",
    notes: "海上輸送のみ。コンテナ貨物には FCA が推奨される",
  },
  {
    rule: "CFR",
    full_name_en: "Cost and Freight",
    name_ja: "運賃込み",
    transport_mode: "sea_only",
    risk_transfer: "本船上に置かれた時点 (積込完了)",
    cost_responsibility_seller: ["輸出通関", "本船積込", "海上運送"],
    cost_responsibility_buyer: ["保険", "目的港以降", "輸入通関"],
    insurance_required_by_seller: false,
    customs_export_clearance_by: "seller",
    customs_import_clearance_by: "buyer",
    notes: "海上輸送のみ。費用と危険の分岐点が異なる",
  },
  {
    rule: "CIF",
    full_name_en: "Cost, Insurance and Freight",
    name_ja: "運賃保険料込み",
    transport_mode: "sea_only",
    risk_transfer: "本船上に置かれた時点 (積込完了)",
    cost_responsibility_seller: ["輸出通関", "本船積込", "海上運送", "保険料 (ICC(C) 最低担保)"],
    cost_responsibility_buyer: ["目的港以降", "輸入通関"],
    insurance_required_by_seller: true,
    insurance_minimum_coverage: "ICC_C",
    customs_export_clearance_by: "seller",
    customs_import_clearance_by: "buyer",
    notes: "海上輸送のみ。CIP との違い: 保険レベル ICC(C)",
  },
];

export function getIncotermDefinition(rule: IncotermRule): IncotermDefinition {
  return INCOTERMS_2020.find((i) => i.rule === rule)!;
}

export function recommendIncoterm(input: {
  transport_mode: TransportMode;
  cargo_kind: "container" | "bulk" | "air" | "courier";
  buyer_country_clearance_capability: "high" | "medium" | "low";
  seller_export_capability: "high" | "medium" | "low";
}): { recommended: IncotermRule; alternatives: IncotermRule[]; reasons: string[] } {
  const reasons: string[] = [];
  // 海上限定が前提のときは sea_only グループ
  if (input.transport_mode === "sea_only") {
    if (input.cargo_kind === "container") {
      reasons.push("海上+コンテナ → コンテナはFCA系列推奨だが慣習でFOB/CFR/CIF多用");
      return { recommended: "CIF", alternatives: ["CFR", "FOB"], reasons };
    }
    reasons.push("海上+バルク → FOB/CFR/CIF 慣習的");
    return { recommended: "FOB", alternatives: ["CFR", "CIF", "FAS"], reasons };
  }
  // 輸入側の通関能力が低い → 売主が輸入通関まで負担 (DDP)
  if (input.buyer_country_clearance_capability === "low") {
    reasons.push("買主側通関能力低 → 売主が輸入通関まで負担 (DDP)");
    return { recommended: "DDP", alternatives: ["DAP", "DPU"], reasons };
  }
  // 売主側の輸出通関能力が低い → EXW (買主負担)
  if (input.seller_export_capability === "low") {
    reasons.push("売主側輸出通関能力低 → 買主負担 (EXW)");
    return { recommended: "EXW", alternatives: ["FCA"], reasons };
  }
  // 一般的な複合輸送 (コンテナ/航空)
  reasons.push("複合輸送 (コンテナ/航空) → CIP (保険込) または FCA");
  return { recommended: "CIP", alternatives: ["FCA", "CPT", "DAP"], reasons };
}

// L/C (信用状) UCP 600 準拠
export interface LetterOfCredit {
  lc_no: string;
  issuing_bank: string;
  advising_bank: string;
  applicant: string; // 輸入者
  beneficiary: string; // 輸出者
  amount: number;
  currency: string;
  expiry_date: string;
  latest_shipment_date: string;
  partial_shipment: "allowed" | "not_allowed";
  transshipment: "allowed" | "not_allowed";
  required_documents: string[]; // ["Commercial Invoice", "B/L", "Insurance Certificate", "Packing List", "Certificate of Origin"]
  presentation_period_days: number; // B/L日付から書類呈示まで (通常21日 / UCP 600 14条)
}

// L/C 書類点検 (Discrepancy Check)
export interface DocumentSet {
  commercial_invoice?: { amount: number; description: string; issued_date: string };
  bl_or_awb?: { type: "B/L" | "AWB" | "Sea Waybill"; bl_date: string; vessel?: string };
  insurance_cert?: { coverage: string; amount: number };
  packing_list?: { gross_weight_kg: number; package_count: number };
  co?: { origin_country: string; issued_date: string };
}

export interface DiscrepancyResult {
  is_clean: boolean;
  discrepancies: string[];
}

export function checkLcDocuments(lc: LetterOfCredit, docs: DocumentSet, presentation_date: string): DiscrepancyResult {
  const discrepancies: string[] = [];
  // 必要書類の存在確認
  for (const doc of lc.required_documents) {
    if (doc.includes("Invoice") && !docs.commercial_invoice) discrepancies.push(`必要書類不足: ${doc}`);
    if (doc.includes("B/L") && !docs.bl_or_awb) discrepancies.push(`必要書類不足: ${doc}`);
    if (doc.includes("Insurance") && !docs.insurance_cert) discrepancies.push(`必要書類不足: ${doc}`);
    if (doc.includes("Packing") && !docs.packing_list) discrepancies.push(`必要書類不足: ${doc}`);
    if (doc.includes("Origin") && !docs.co) discrepancies.push(`必要書類不足: ${doc}`);
  }
  // 金額一致 (Invoice ≦ L/C amount)
  if (docs.commercial_invoice && docs.commercial_invoice.amount > lc.amount) {
    discrepancies.push(`Invoice 金額 ${docs.commercial_invoice.amount} > L/C amount ${lc.amount}`);
  }
  // 船積期限 (Latest shipment date)
  if (docs.bl_or_awb && Date.parse(docs.bl_or_awb.bl_date) > Date.parse(lc.latest_shipment_date)) {
    discrepancies.push(`船積遅延: B/L日付 ${docs.bl_or_awb.bl_date} > Latest shipment ${lc.latest_shipment_date}`);
  }
  // 書類呈示期限 (UCP 600 14条: B/L日付から21日以内 + L/C有効期限内)
  if (docs.bl_or_awb) {
    const blDate = Date.parse(docs.bl_or_awb.bl_date);
    const presDate = Date.parse(presentation_date);
    const presDays = (presDate - blDate) / (24 * 60 * 60 * 1000);
    if (presDays > lc.presentation_period_days) {
      discrepancies.push(`書類呈示期限超過: ${presDays.toFixed(0)}日 > ${lc.presentation_period_days}日`);
    }
    if (presDate > Date.parse(lc.expiry_date)) {
      discrepancies.push(`L/C有効期限超過: ${presentation_date} > ${lc.expiry_date}`);
    }
  }
  return { is_clean: discrepancies.length === 0, discrepancies };
}

// 仲裁条項 (国際取引)
export type ArbitrationVenue = "JCAA" | "ICC" | "SIAC" | "HKIAC" | "LCIA" | "ICDR";

export interface ArbitrationClause {
  venue: ArbitrationVenue;
  seat_country: string; // 仲裁地
  language: string;
  governing_law: string;
  number_of_arbitrators: 1 | 3;
}

export const ARBITRATION_VENUES: { id: ArbitrationVenue; name: string; recommended_use: string }[] = [
  { id: "JCAA", name: "日本商事仲裁協会", recommended_use: "日本企業 × アジア企業の取引" },
  { id: "ICC", name: "国際商業会議所 (パリ)", recommended_use: "グローバル取引、欧州企業との取引" },
  { id: "SIAC", name: "シンガポール国際仲裁センター", recommended_use: "東南アジア取引のハブ" },
  { id: "HKIAC", name: "香港国際仲裁センター", recommended_use: "中国本土・香港関連" },
  { id: "LCIA", name: "ロンドン国際仲裁裁判所", recommended_use: "英国法準拠取引" },
  { id: "ICDR", name: "AAA 国際仲裁部門", recommended_use: "米国企業との取引" },
];

export function buildArbitrationClause(
  venue: ArbitrationVenue,
  options: Partial<ArbitrationClause> = {},
): ArbitrationClause {
  const defaults: Record<ArbitrationVenue, Partial<ArbitrationClause>> = {
    JCAA: { seat_country: "Japan", language: "Japanese or English" },
    ICC: { seat_country: "France", language: "English" },
    SIAC: { seat_country: "Singapore", language: "English" },
    HKIAC: { seat_country: "Hong Kong", language: "English" },
    LCIA: { seat_country: "United Kingdom", language: "English", governing_law: "English Law" },
    ICDR: { seat_country: "United States", language: "English" },
  };
  return {
    venue,
    seat_country: options.seat_country ?? defaults[venue].seat_country!,
    language: options.language ?? defaults[venue].language!,
    governing_law: options.governing_law ?? defaults[venue].governing_law ?? "Law of seat",
    number_of_arbitrators: options.number_of_arbitrators ?? 3,
  };
}
