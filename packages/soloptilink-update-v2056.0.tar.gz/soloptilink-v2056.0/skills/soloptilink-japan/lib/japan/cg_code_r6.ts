/**
 * SoloptiLinkAI Phase 45-JG (v2031.0-jpgov) — Corporate Governance Code R6 改訂版
 *
 * 東京証券取引所「コーポレートガバナンス・コード」 (令和6年=2024年6月改訂版)
 *
 * Claude Code が構造的に到達できない領域:
 *   - プライム/スタンダード/グロース 市場別の適用区分の Comply-or-Explain 自動判定
 *   - 人的資本可視化 (女性管理職比率/育休取得率/男女賃金差異/中核人材多様性)
 *   - 気候関連開示 TCFD準拠 (Scope1/2/3 GHG排出量/シナリオ分析/移行リスク評価)
 *   - 英文開示の充実度 (有報/招集通知/CGレポート/IRサイト)
 *   - 5基本原則 + 78補充原則の縦横インデックス
 *
 * 監督: 東京証券取引所 (Self-Regulatory Organization=SRO) + 金融庁 (バックストップ)
 * 適用: 上場会社 全市場 (プライム/スタンダード/グロース)
 * 違反時: 上場規程違反 → 改善報告書/特設注意市場銘柄/上場廃止 (制裁段階)
 *
 * 改訂履歴:
 *   - 2015年6月 初版 (5基本原則)
 *   - 2018年6月 改訂 (政策保有株式・買収防衛策追加)
 *   - 2021年6月 改訂 (プライム上場会社向け +α 強化)
 *   - 2024年6月 改訂 (R6) ← 本ファイル対応版
 *      ・人的資本の可視化義務化 (補充原則 3-1③)
 *      ・気候関連開示 TCFD or 同等基準 (補充原則 3-1③)
 *      ・英文開示義務化 (プライム上場会社・補充原則 3-1③)
 *      ・取締役会のサステナビリティ取組 (補充原則 4-2②)
 *      ・指名委員会等の独立性強化 (補充原則 4-10①)
 *      ・株主との対話ガイドライン (原則 5)
 */

// ───────────────────────────────────────────────
// 型定義
// ───────────────────────────────────────────────

export type Market = "prime" | "standard" | "growth";

export type PrincipleId =
  | "P1"  // 株主の権利・平等性の確保
  | "P2"  // ステークホルダーとの協働
  | "P3"  // 情報開示と透明性
  | "P4"  // 取締役会等の責務
  | "P5"; // 株主との対話

export interface Principle {
  id: PrincipleId;
  title: string;
  market_requirement: Record<Market, "mandatory" | "comply_or_explain" | "best_practice">;
  supplementary: SupplementaryPrinciple[];
}

export interface SupplementaryPrinciple {
  id: string; // e.g. "1-1-1"
  title: string;
  description: string;
  market_applies: Market[];
  added_in?: "2015" | "2018" | "2021" | "2024";
  r6_focus?: boolean; // R6改訂で重点化された項目
}

export interface ComplyOrExplainResult {
  principle_id: string;
  status: "comply" | "explain" | "non_disclosure";
  rationale?: string;
  explanation?: string;
  evidence_url?: string;
  audit_required: boolean;
}

export interface CompanyDisclosure {
  company_name: string;
  market: Market;
  fiscal_year: number;
  cg_report_url?: string;
  yuho_url?: string; // 有価証券報告書
  ir_url?: string;
  en_disclosure: {
    yuho_en: boolean;
    cg_report_en: boolean;
    ir_site_en: boolean;
    invitation_letter_en: boolean;
  };
  human_capital: {
    female_manager_ratio?: number;       // 女性管理職比率 (%)
    male_paternity_leave_rate?: number;  // 男性育児休業取得率 (%)
    wage_gap_male_female?: number;       // 男女間賃金差異 (%, 男性=100)
    core_diversity_targets_set?: boolean;
    midcareer_hire_ratio?: number;       // 中途採用比率
    foreign_executive_count?: number;    // 外国人役員数
  };
  tcfd: {
    governance_disclosed: boolean;
    strategy_scenario_analyzed: boolean;
    risk_management_described: boolean;
    metrics_targets: {
      scope1_disclosed: boolean;
      scope2_disclosed: boolean;
      scope3_disclosed: boolean;
      target_year?: number;
      reduction_target?: number; // %
    };
    tcfd_supporter: boolean;
  };
  policy_holding_stocks: {
    listed_count: number;
    rationale_disclosed: boolean;
    cross_holding_with_top10_clients: boolean;
  };
  board_composition: {
    independent_director_count: number;
    independent_ratio: number;          // %
    female_director_count: number;
    foreign_director_count: number;
    nomination_committee_independent_majority: boolean;
    compensation_committee_independent_majority: boolean;
    skill_matrix_disclosed: boolean;
  };
  shareholder_engagement: {
    irday_held: boolean;
    institutional_investor_dialogue_count: number;
    individual_investor_event_count: number;
    activist_response_protocol_documented: boolean;
  };
}

export interface CGComplianceReport {
  company_name: string;
  market: Market;
  fiscal_year: number;
  total_principles: number;
  comply_count: number;
  explain_count: number;
  non_disclosure_count: number;
  compliance_rate: number;     // %
  r6_focus_compliance: number; // R6改訂項目だけのComply率 %
  weak_points: string[];
  strengths: string[];
  audit_required_items: string[];
  generated_at: string;
}

// ───────────────────────────────────────────────
// 5基本原則 + 主要補充原則 (R6改訂版)
// ───────────────────────────────────────────────

export const CG_CODE_R6: Principle[] = [
  {
    id: "P1",
    title: "株主の権利・平等性の確保",
    market_requirement: { prime: "comply_or_explain", standard: "comply_or_explain", growth: "best_practice" },
    supplementary: [
      { id: "1-1-1", title: "総会決議事項の検討", description: "総会で否決された議案の検討プロセス開示", market_applies: ["prime", "standard"], added_in: "2015" },
      { id: "1-2-4", title: "電子議決権行使プラットフォーム", description: "プライム市場上場会社は電子行使プラットフォーム利用が義務", market_applies: ["prime"], added_in: "2021" },
      { id: "1-4", title: "政策保有株式", description: "縮減方針開示・個別銘柄ごとの保有目的・経済合理性検証", market_applies: ["prime", "standard"], added_in: "2018" },
      { id: "1-5", title: "買収防衛策", description: "経営陣保身目的の買収防衛策の合理性開示", market_applies: ["prime", "standard"], added_in: "2018" },
    ],
  },
  {
    id: "P2",
    title: "株主以外のステークホルダーとの適切な協働",
    market_requirement: { prime: "comply_or_explain", standard: "comply_or_explain", growth: "best_practice" },
    supplementary: [
      { id: "2-3-1", title: "サステナビリティ課題", description: "ESG課題の経営戦略への組込", market_applies: ["prime", "standard", "growth"], added_in: "2018" },
      { id: "2-4-1", title: "中核人材の多様性確保", description: "女性・外国人・中途採用者の中核人材登用 + 自主目標設定 + 進捗開示", market_applies: ["prime", "standard"], added_in: "2021", r6_focus: true },
      { id: "2-5", title: "内部通報", description: "公益通報者保護法 R4改正対応 + 経営陣から独立した窓口設置", market_applies: ["prime", "standard"], added_in: "2018" },
    ],
  },
  {
    id: "P3",
    title: "適切な情報開示と透明性の確保",
    market_requirement: { prime: "comply_or_explain", standard: "comply_or_explain", growth: "comply_or_explain" },
    supplementary: [
      { id: "3-1-1", title: "経営理念・経営戦略", description: "中長期的な経営戦略・経営計画開示", market_applies: ["prime", "standard", "growth"], added_in: "2015" },
      { id: "3-1-3", title: "サステナビリティ・人的資本・知的財産投資", description: "プライム: TCFD or 同等基準 / 人的資本可視化 / 英文開示", market_applies: ["prime", "standard", "growth"], added_in: "2021", r6_focus: true },
      { id: "3-2-2", title: "外部会計監査人", description: "監査報酬の決定方針・監査人交代理由開示", market_applies: ["prime", "standard"], added_in: "2018" },
    ],
  },
  {
    id: "P4",
    title: "取締役会等の責務",
    market_requirement: { prime: "comply_or_explain", standard: "comply_or_explain", growth: "best_practice" },
    supplementary: [
      { id: "4-1-1", title: "経営陣への委任の範囲", description: "取締役会で決定すべき事項と経営陣に委任する事項の明確化", market_applies: ["prime", "standard"], added_in: "2015" },
      { id: "4-2-2", title: "サステナビリティ取組", description: "取締役会によるサステナビリティ基本方針の策定・監督", market_applies: ["prime", "standard"], added_in: "2021", r6_focus: true },
      { id: "4-8", title: "独立社外取締役", description: "プライム: 1/3以上 (議決数の場合は過半数), スタンダード: 2名以上", market_applies: ["prime", "standard"], added_in: "2021" },
      { id: "4-10-1", title: "指名委員会・報酬委員会", description: "プライム: 過半数を独立社外取締役 + 委員長の独立社外取締役選任を Strong Recommendation", market_applies: ["prime"], added_in: "2021", r6_focus: true },
      { id: "4-11-3", title: "取締役会の実効性評価", description: "毎年の自己評価 + 第三者評価の活用", market_applies: ["prime", "standard"], added_in: "2018" },
    ],
  },
  {
    id: "P5",
    title: "株主との対話",
    market_requirement: { prime: "comply_or_explain", standard: "comply_or_explain", growth: "best_practice" },
    supplementary: [
      { id: "5-1", title: "建設的な対話の促進", description: "株主からの対話の申込みへの合理的範囲での応諾", market_applies: ["prime", "standard"], added_in: "2015" },
      { id: "5-2", title: "経営戦略・経営計画の策定・公表", description: "資本コストや株価を意識した経営", market_applies: ["prime", "standard", "growth"], added_in: "2024", r6_focus: true },
    ],
  },
];

// ───────────────────────────────────────────────
// 評価関数
// ───────────────────────────────────────────────

/** 市場別の適用条項を取得 */
export function getApplicablePrinciples(market: Market): SupplementaryPrinciple[] {
  return CG_CODE_R6.flatMap((p) => p.supplementary.filter((sp) => sp.market_applies.includes(market)));
}

/** R6改訂で重点化された項目だけ取得 */
export function getR6FocusPrinciples(): SupplementaryPrinciple[] {
  return CG_CODE_R6.flatMap((p) => p.supplementary.filter((sp) => sp.r6_focus));
}

/** 人的資本可視化のチェック (補充原則 2-4-1, 3-1-3) */
export function checkHumanCapitalDisclosure(d: CompanyDisclosure): {
  passed: boolean;
  score: number;
  missing: string[];
} {
  const missing: string[] = [];
  const hc = d.human_capital;
  if (hc.female_manager_ratio === undefined) missing.push("女性管理職比率");
  if (hc.male_paternity_leave_rate === undefined) missing.push("男性育児休業取得率");
  if (hc.wage_gap_male_female === undefined) missing.push("男女間賃金差異");
  if (!hc.core_diversity_targets_set) missing.push("中核人材多様性 自主目標");
  if (hc.midcareer_hire_ratio === undefined) missing.push("中途採用比率");
  const total = 5;
  const score = ((total - missing.length) / total) * 100;
  return { passed: missing.length === 0, score, missing };
}

/** TCFD気候関連開示のチェック (補充原則 3-1-3) */
export function checkTCFDDisclosure(d: CompanyDisclosure, market: Market): {
  passed: boolean;
  score: number;
  missing: string[];
  prime_required: boolean;
} {
  const missing: string[] = [];
  const t = d.tcfd;
  if (!t.governance_disclosed) missing.push("ガバナンス開示");
  if (!t.strategy_scenario_analyzed) missing.push("シナリオ分析 (1.5度/2度/4度)");
  if (!t.risk_management_described) missing.push("リスク管理プロセス");
  if (!t.metrics_targets.scope1_disclosed) missing.push("Scope1 GHG排出量");
  if (!t.metrics_targets.scope2_disclosed) missing.push("Scope2 GHG排出量");
  if (market === "prime" && !t.metrics_targets.scope3_disclosed) missing.push("Scope3 GHG排出量 (プライム必須)");
  if (!t.metrics_targets.target_year || !t.metrics_targets.reduction_target) missing.push("削減目標");
  const total = market === "prime" ? 7 : 6;
  const passed = market === "prime" ? missing.length === 0 : missing.length <= 1;
  const score = ((total - missing.length) / total) * 100;
  return { passed, score, missing, prime_required: market === "prime" };
}

/** 英文開示のチェック (プライム必須 補充原則 3-1-3) */
export function checkEnglishDisclosure(d: CompanyDisclosure): {
  passed: boolean;
  score: number;
  missing: string[];
  prime_required: boolean;
} {
  const missing: string[] = [];
  const e = d.en_disclosure;
  if (!e.yuho_en) missing.push("有価証券報告書 (英文)");
  if (!e.cg_report_en) missing.push("CGレポート (英文)");
  if (!e.invitation_letter_en) missing.push("招集通知 (英文)");
  if (!e.ir_site_en) missing.push("IRサイト (英文)");
  const score = ((4 - missing.length) / 4) * 100;
  const isPrime = d.market === "prime";
  return { passed: isPrime ? missing.length === 0 : true, score, missing, prime_required: isPrime };
}

/** 取締役会構成のチェック (補充原則 4-8, 4-10) */
export function checkBoardComposition(d: CompanyDisclosure, market: Market): {
  passed: boolean;
  score: number;
  issues: string[];
} {
  const issues: string[] = [];
  const b = d.board_composition;
  if (market === "prime" && b.independent_ratio < 33.4) issues.push(`プライム独立社外比率 ${b.independent_ratio}% < 1/3`);
  if (market === "standard" && b.independent_director_count < 2) issues.push(`スタンダード独立社外 ${b.independent_director_count}名 < 2名`);
  if (market === "prime" && !b.nomination_committee_independent_majority) issues.push("指名委員会の独立社外過半数 (R6補充原則 4-10-1)");
  if (market === "prime" && !b.compensation_committee_independent_majority) issues.push("報酬委員会の独立社外過半数 (R6補充原則 4-10-1)");
  if (b.female_director_count === 0) issues.push("女性取締役ゼロ (中核人材多様性 補充原則 2-4-1)");
  if (!b.skill_matrix_disclosed) issues.push("スキルマトリクス開示 (補充原則 4-11-1)");
  const totalChecks = 6;
  const score = ((totalChecks - issues.length) / totalChecks) * 100;
  return { passed: issues.length === 0, score, issues };
}

/** 政策保有株式のチェック (補充原則 1-4) */
export function checkPolicyHoldingStocks(d: CompanyDisclosure): {
  passed: boolean;
  warnings: string[];
} {
  const warnings: string[] = [];
  const p = d.policy_holding_stocks;
  if (p.listed_count > 30) warnings.push(`政策保有株式 ${p.listed_count}銘柄 — 縮減方針開示 必須`);
  if (!p.rationale_disclosed) warnings.push("個別銘柄の保有目的・経済合理性開示なし (補充原則 1-4)");
  if (p.cross_holding_with_top10_clients) warnings.push("主要取引先との持ち合い — 独立性に懸念");
  return { passed: warnings.length === 0, warnings };
}

/** 株主との対話のチェック (原則 5) */
export function checkShareholderEngagement(d: CompanyDisclosure): {
  passed: boolean;
  score: number;
  weak_points: string[];
} {
  const weak: string[] = [];
  const s = d.shareholder_engagement;
  if (!s.irday_held) weak.push("IR Day 未実施");
  if (s.institutional_investor_dialogue_count < 50) weak.push(`機関投資家対話 ${s.institutional_investor_dialogue_count}件 < 50件 (プライム期待値)`);
  if (!s.activist_response_protocol_documented) weak.push("アクティビスト対応プロトコル未整備");
  const score = (((3 - weak.length) / 3) * 100);
  return { passed: weak.length === 0, score, weak_points: weak };
}

// ───────────────────────────────────────────────
// 統合レポート生成
// ───────────────────────────────────────────────

/** Comply or Explain 全体評価 */
export function evaluateComplyOrExplain(d: CompanyDisclosure): CGComplianceReport {
  const principles = getApplicablePrinciples(d.market);
  const r6Focus = getR6FocusPrinciples().filter((sp) => sp.market_applies.includes(d.market));

  let comply = 0;
  let explain = 0;
  let nonDisclosure = 0;
  const weak: string[] = [];
  const strengths: string[] = [];
  const auditRequired: string[] = [];

  // 各重要観点のチェック
  const hc = checkHumanCapitalDisclosure(d);
  const tcfd = checkTCFDDisclosure(d, d.market);
  const en = checkEnglishDisclosure(d);
  const board = checkBoardComposition(d, d.market);
  const policy = checkPolicyHoldingStocks(d);
  const engagement = checkShareholderEngagement(d);

  // 各観点の判定
  if (hc.passed) { comply++; strengths.push("人的資本可視化 完全対応"); } else { explain += hc.missing.length; weak.push("人的資本可視化: " + hc.missing.join(", ")); }
  if (tcfd.passed) { comply++; strengths.push("TCFD気候関連開示 完全対応"); } else { explain += tcfd.missing.length; weak.push("TCFD: " + tcfd.missing.join(", ")); }
  if (en.passed) { if (d.market === "prime") strengths.push("英文開示 完全対応 (プライム)"); else comply++; } else { weak.push("英文開示: " + en.missing.join(", ")); if (d.market === "prime") auditRequired.push("英文開示 (プライム必須)"); }
  if (board.passed) { comply++; strengths.push("取締役会構成 健全"); } else { weak.push("取締役会: " + board.issues.join(", ")); auditRequired.push("取締役会構成 (R6補充原則 4-8/4-10)"); }
  if (policy.passed) comply++; else { explain += policy.warnings.length; weak.push("政策保有株式: " + policy.warnings.join(", ")); }
  if (engagement.passed) comply++; else { weak.push("株主対話: " + engagement.weak_points.join(", ")); }

  const total = principles.length;
  const r6FocusComply = r6Focus.length > 0 ? Math.round(([hc.passed, tcfd.passed, en.passed, board.passed].filter(Boolean).length / 4) * 100) : 100;

  return {
    company_name: d.company_name,
    market: d.market,
    fiscal_year: d.fiscal_year,
    total_principles: total,
    comply_count: comply,
    explain_count: explain,
    non_disclosure_count: nonDisclosure,
    compliance_rate: Math.round((comply / 6) * 100),
    r6_focus_compliance: r6FocusComply,
    weak_points: weak,
    strengths,
    audit_required_items: auditRequired,
    generated_at: new Date().toISOString(),
  };
}

/** 改訂履歴メタデータ */
export const CG_CODE_REVISION_HISTORY = {
  initial: { date: "2015-06-01", version: "1.0", changes: ["5基本原則制定"] },
  r1: { date: "2018-06-01", version: "1.1", changes: ["政策保有株式", "買収防衛策", "監査人ローテ"] },
  r2: { date: "2021-06-11", version: "2.0", changes: ["プライム上場特則", "人的資本", "取締役会の実効性"] },
  r3: { date: "2024-06-21", version: "3.0", changes: ["人的資本可視化義務化", "TCFD義務化(プライム)", "英文開示義務化(プライム)", "資本コスト経営", "サステナビリティ取締役会監督"] },
} as const;

/** 違反時の制裁段階 */
export const CG_CODE_SANCTIONS = {
  step1: { trigger: "Comply-or-Explain未対応", action: "東証から改善要請 (公表しない)", severity: "low" },
  step2: { trigger: "改善報告書要請拒否/虚偽記載", action: "改善報告書徴求 (公表)", severity: "medium" },
  step3: { trigger: "改善見込みなし", action: "特設注意市場銘柄指定 (1年以内に改善)", severity: "high" },
  step4: { trigger: "特設注意市場銘柄から改善せず", action: "上場廃止", severity: "critical" },
} as const;

// ───────────────────────────────────────────────
// マーカー (テスト用)
// ───────────────────────────────────────────────
export const CG_CODE_R6_MARKER = "JGEL_CG_R6_v2031.0_jpgov" as const;
