/**
 * Phase 15 - 金融機関 / 銀行業務 DNA
 *
 *   Claude Code には存在しない、日本固有の金融標準フォーマット (全銀協制定レコード・フォーマット
 *   120バイト固定長 / 200バイト・262バイト系)、銀行コード/支店コード、
 *   金商法対応、AML/CFT・反社チェック、監督指針、J-CSIP、金融ISAC、
 *   暗号資産業務、決済法 (資金決済法)、振込手数料の扱い、勘定科目体系 を一括収録する。
 *
 * ■ 一次情報 (本ファイルの全銀フォーマット記述の出典)
 *   [S1] 一般社団法人 全国銀行協会
 *        『全銀協パーソナル・コンピュータ用標準通信プロトコル (ベーシック手順)〔別冊〕
 *          適用業務およびレコード・フォーマット』AP-Ⅰ-12 (12版・令和元年12月)
 *        https://www.zenginkyo.or.jp/fileadmin/res/abstract/efforts/system/jba_protocol_pc.pdf
 *        - Ⅱ-4  給与振込(民間)   種別コード 11
 *        - Ⅱ-5  賞与振込(民間)   種別コード 12
 *        - Ⅱ-8  総合振込        種別コード 21
 *        - Ⅱ-15 預金口座振替(依頼明細)   種別コード 91
 *        - Ⅱ-16 預金口座振替(処理結果明細) 振替結果コード
 *        - 付録1 使用文字一覧 (注1〜注7)、付録2 振込依頼人名・受取人名などの記入、付録3 預金種目コード
 *   [S2] 三菱UFJ信託銀行『総合振込 (全銀協規定形式)』
 *        https://www.tr.mufg.jp/houjin/mbd/manual/pdf/manual05.pdf
 *        「レコード長 120バイト / 改行(CR LF)をつける場合 120バイトの後に2バイトで収容する /
 *          文字コード JISコードまたはEBCDICコード」
 *   [S3] 三菱UFJ信託銀行『給与・賞与振込 (全銀協規定形式)』
 *        https://www.tr.mufg.jp/houjin/mbd/manual/pdf/manual06.pdf
 *   [S4] きらぼし銀行『《総合振込》振込依頼ファイル・フォーマット (全銀協規定形式)』(20241202)
 *        https://www.kiraboshibank.co.jp/file.jsp?id=6326
 *        「各120桁(バイト)の4種類(ヘッダ、データ、トレーラ、エンド)の固定長レコードで構成」
 *   [S5] ゆうちょ銀行『振込規定』(Ⅱ-04-202601版)
 *        https://www.jp-bank.japanpost.jp/kitei/pdf/hurikomi.pdf
 *        - 7 依頼内容の変更 (訂正)  - 8 組戻し  - 10 料金
 *
 *   ※ 本ファイルは規定文書との突合までを行ったものであり、
 *     **実際に銀行へ提出して受理された実績を保証するものではない**。
 *     取引銀行ごとに追加の制約 (使用可能記号・改行有無・ファイル名規約) があるため、
 *     初回提出前に必ず取引銀行のフォーマット仕様書と突合すること。
 */

import {
  encodeJis8,
  decodeJis8,
  jis8ByteLength,
  padJis8Left,
  padJis8Zero,
  validateCharset,
  normalizeForZengin,
  CHARSET_NAME_WITH_WO,
  CHARSET_NAME_WITHOUT_WO,
  CHARSET_BRANCH_WITH_WO,
  CHARSET_BRANCH_WITHOUT_WO,
  CHARSET_EDI,
  type ZenginCharset,
  type NormalizeResult,
} from './encoding/jis8';

export {
  encodeJis8,
  decodeJis8,
  jis8ByteLength,
  normalizeForZengin,
  validateCharset,
  CHARSET_NAME_WITH_WO,
  CHARSET_NAME_WITHOUT_WO,
  CHARSET_EDI,
} from './encoding/jis8';

// ───────────────────────────────────────────────
// 型定義
// ───────────────────────────────────────────────

export type BankAccountType = 'ordinary' | 'current' | 'savings' | 'loan' | 'time_deposit'; //  普通/当座/貯蓄/ローン/定期
export type ZenginRecordType = 'header' | 'data' | 'trailer' | 'end';

/**
 * 全銀協制定レコード・フォーマットの業務種別。
 * 種別コードは [S1] Ⅱ-4 / Ⅱ-5 / Ⅱ-8 / Ⅱ-15 による。
 */
export type ZenginBusinessKind =
  | 'sougou_furikomi' //  総合振込      種別コード 21
  | 'kyuyo_furikomi' //  給与振込(民間)  種別コード 11
  | 'shoyo_furikomi' //  賞与振込(民間)  種別コード 12
  | 'kouza_furikae'; //  預金口座振替    種別コード 91

/** 業務種別 → 種別コード ([S1] 各業務のヘッダー・レコード 項番2) */
export const ZENGIN_TYPE_CODES: Readonly<Record<ZenginBusinessKind, string>> = {
  kyuyo_furikomi: '11',
  shoyo_furikomi: '12',
  sougou_furikomi: '21',
  kouza_furikae: '91',
} as const;

/** 種別コード → 日本語名 (画面表示用) */
export const ZENGIN_BUSINESS_LABELS: Readonly<Record<ZenginBusinessKind, string>> = {
  kyuyo_furikomi: '給与振込',
  shoyo_furikomi: '賞与振込',
  sougou_furikomi: '総合振込',
  kouza_furikae: '預金口座振替',
} as const;

/** 全レコード共通のレコード長 (バイト) — [S1] [S2] [S4] */
export const ZENGIN_RECORD_BYTES = 120;

/**
 * 業務ごとに使用できる預金種目コード。
 * [S1] 付録3 預金種目コード + 各業務フォーマット表の限定列挙による。
 */
export const ZENGIN_ALLOWED_ACCOUNT_TYPES: Readonly<Record<ZenginBusinessKind, readonly string[]>> = {
  //  総合振込 データ・レコード 項番7: 1普通 2当座 4貯蓄 9その他
  sougou_furikomi: ['1', '2', '4', '9'],
  //  給与振込 データ・レコード 項番7: 1普通 2当座
  kyuyo_furikomi: ['1', '2'],
  shoyo_furikomi: ['1', '2'],
  //  預金口座振替 データ・レコード 項番7: 1普通 2当座 3納税準備 9その他
  kouza_furikae: ['1', '2', '3', '9'],
} as const;

/** ヘッダーの預金種目 (依頼人・委託者側) の許容値 — [S1] 各業務ヘッダー 項番11 */
export const ZENGIN_ALLOWED_HEADER_ACCOUNT_TYPES: Readonly<Record<ZenginBusinessKind, readonly string[]>> = {
  sougou_furikomi: ['1', '2', '9'],
  kyuyo_furikomi: ['1', '2'],
  shoyo_furikomi: ['1', '2'],
  kouza_furikae: ['1', '2', '9'],
} as const;

export interface BankCode {
  bankCode: string; //  4桁
  bankNameKana: string;
  bankNameKanji: string;
  bankType: 'city' | 'regional1' | 'regional2' | 'trust' | 'shinkin' | 'shinkumi' | 'jp_post' | 'norin' | 'rodo' | 'foreign';
}

export interface BranchCode {
  bankCode: string;
  branchCode: string; //  3桁
  branchNameKana: string;
  branchNameKanji: string;
}

export interface ZenginTransferEntry {
  /** 受取人銀行コード 4桁 */
  bankCode: string;
  /** 受取人支店コード 3桁 */
  branchCode: string;
  /** 預金種目: 1=普通 2=当座 4=貯蓄 9=その他 (業務により許容値が異なる) */
  accountType: '1' | '2' | '3' | '4' | '9';
  /** 口座番号 7桁 (右詰めゼロパディング) */
  accountNumber: string;
  /** 受取人名 (半角カナ・30バイト) */
  recipientNameKana: string;
  /** 振込金額 (円・整数) */
  amountYen: number;
  /** 顧客コード1 (任意・10桁) — 旧名。EDI情報と排他 */
  customerCode?: string;
  /** 顧客コード2 (任意・10桁) — EDI情報と排他 */
  customerCode2?: string;
  /** EDI 情報 (任意・20バイト) — 顧客コード1/2 と排他。設定時は識別表示が 'Y' になる */
  ediInfo?: string;
  /** 新規コード: 0=その他 1=第1回振込分 2=変更分 */
  newChangeCode?: '0' | '1' | '2';
  /** 手形交換所番号 (任意・4桁)。既定は '0000' ([S2]「0（全てゼロとする）」) */
  clearingHouseCode?: string;
  /** 振込指定区分: 7=テレ振込(電信) 8=文書振込 ([S1] 総合振込 項番14) */
  transferCategory?: '7' | '8';
  /** 給与・賞与振込のみ: 社員番号 (任意・10桁) */
  employeeNumber?: string;
  /** 給与・賞与振込のみ: 所属コード (任意・10桁) */
  departmentCode?: string;
  /** 預金口座振替のみ: 顧客番号 (20桁) */
  customerNumber?: string;
  /** 預金口座振替のみ: 振替結果コード。依頼明細では '0' 固定 ([S1] Ⅱ-15 項番13) */
  debitResultCode?: '0' | '1' | '2' | '3' | '4' | '8' | '9';
}

/**
 * 預金口座振替 処理結果明細の振替結果コード ([S1] Ⅱ-16)。
 * 依頼明細では常に '0' を設定する。
 */
export const KOUZA_FURIKAE_RESULT_CODES: Readonly<Record<string, string>> = {
  '0': '振替済',
  '1': '資金不足',
  '2': '取引なし',
  '3': '預金者の都合による振替停止',
  '4': '預金口座振替依頼書なし',
  '8': '委託者の都合による振替停止',
  '9': 'その他',
} as const;

// ───────────────────────────────────────────────
// 主要銀行コード (一部・サンプル)
// ───────────────────────────────────────────────

/**
 * bankNameKana は **全銀フォーマットにそのまま書ける半角カナ** に正規化してある。
 *   旧実装は 'ミズホ' 'ミツビシＵＦＪ' のような全角カナ・全角英字を保持していたが、
 *   これを 15 バイト欄へ入れると JIS X 0201 に変換できず提出できない。
 *   また 'ﾎｯｶｲﾄﾞｳ' 'ﾕｳﾁｮ' の半角カナ小文字 (ｯ ｮ) は
 *   [S1] 付録1 注1 が「カナ (小文字を除く)」としているため使用できないので、
 *   付録2 の記入例 (「トウキヨウシテン」) に倣い大文字表記へ寄せた。
 *   ※ 金融機関コードそのものは金融機関共同コード管理委員会制定の統一コードであり、
 *     本ファイルはサンプルとしてのみ保持する。実運用では最新の金融機関コード一覧を参照すること。
 */
export const MAJOR_BANK_CODES: readonly BankCode[] = [
  { bankCode: '0001', bankNameKana: 'ﾐｽﾞﾎ', bankNameKanji: 'みずほ銀行', bankType: 'city' },
  { bankCode: '0005', bankNameKana: 'ﾐﾂﾋﾞｼUFJ', bankNameKanji: '三菱UFJ銀行', bankType: 'city' },
  { bankCode: '0009', bankNameKana: 'ﾐﾂｲｽﾐﾄﾓ', bankNameKanji: '三井住友銀行', bankType: 'city' },
  { bankCode: '0010', bankNameKana: 'ﾘｿﾅ', bankNameKanji: 'りそな銀行', bankType: 'city' },
  { bankCode: '0017', bankNameKana: 'ｻｲﾀﾏﾘｿﾅ', bankNameKanji: '埼玉りそな銀行', bankType: 'city' },
  { bankCode: '0033', bankNameKana: 'ﾍﾟｲﾍﾟｲ', bankNameKanji: 'PayPay銀行', bankType: 'city' },
  { bankCode: '0034', bankNameKana: 'ｾﾌﾞﾝ', bankNameKanji: 'セブン銀行', bankType: 'city' },
  { bankCode: '0035', bankNameKana: 'ｿﾆｰ', bankNameKanji: 'ソニー銀行', bankType: 'city' },
  { bankCode: '0036', bankNameKana: 'ﾗｸﾃﾝ', bankNameKanji: '楽天銀行', bankType: 'city' },
  { bankCode: '0038', bankNameKana: 'ｽﾐｼﾝｴｽﾋﾞｰｱｲ', bankNameKanji: '住信SBIネット銀行', bankType: 'city' },
  { bankCode: '0039', bankNameKana: 'ｼﾞﾊﾞﾝ', bankNameKanji: 'GMOあおぞらネット銀行', bankType: 'city' },
  { bankCode: '0040', bankNameKana: 'ｱｵｿﾞﾗ', bankNameKanji: 'あおぞら銀行', bankType: 'city' },
  { bankCode: '0116', bankNameKana: 'ﾎﾂｶｲﾄﾞｳ', bankNameKanji: '北海道銀行', bankType: 'regional1' },
  { bankCode: '0149', bankNameKana: 'ｼﾖｳﾅｲ', bankNameKanji: '荘内銀行', bankType: 'regional2' },
  { bankCode: '9900', bankNameKana: 'ﾕｳﾁﾖ', bankNameKanji: 'ゆうちょ銀行', bankType: 'jp_post' },
] as const;

// ───────────────────────────────────────────────
// 文字幅・パディング・整形ヘルパ (すべて **バイト** 基準)
// ───────────────────────────────────────────────

/**
 * 半角カナを含む全銀準拠の文字列バリデーション。
 *
 *   旧実装は正規表現 `/^[ｦ-ﾟ0-9A-Z\s.()\-\/¥]+$/` を用いており、
 *   全銀協 付録1 注1 が許していない `/` や `¥`、半角カナ小文字 (ｧ〜ｯ) を通してしまっていた。
 *   本実装は [S1] 付録1 注1 の列挙 (カナ・濁点・半濁点・英大文字・数字・SP・記号4種類 ( ) - . )
 *   に厳密に従い、桁数も **バイト数** で判定する。
 *
 * @param name   検査する文字列
 * @param maxBytes 上限バイト数 (既定 40 = 委託者名/振込依頼人名の桁数)
 */
export function isValidZenginName(name: string, maxBytes = 40): boolean {
  if (name.length === 0) return false;
  let bytes: number;
  try {
    bytes = jis8ByteLength(name);
  } catch {
    return false; //  JIS X 0201 に無い文字 (漢字・全角) が含まれている
  }
  if (bytes > maxBytes) return false;
  return validateCharset(name, CHARSET_NAME_WITH_WO).ok;
}

/**
 * 数値を桁数指定でゼロパディング (右詰め)。桁数は **バイト数**。
 * @deprecated padJis8Zero (encoding/jis8) を直接使うこと。
 */
export function padNumber(value: number | string, digits: number): string {
  return padJis8Zero(value, digits);
}

/**
 * 文字列を桁数指定で空白パディング (左詰め)。桁数は **バイト数**。
 * @deprecated padJis8Left (encoding/jis8) を直接使うこと。
 */
export function padString(value: string, digits: number, alignRight = false): string {
  const len = jis8ByteLength(value);
  if (len > digits) throw new Error(`桁数オーバー: "${value}" は ${len} バイトで、上限 ${digits} バイトを超えています`);
  return alignRight ? ' '.repeat(digits - len) + value : padJis8Left(value, digits);
}

/** 指定フィールドを文字集合と桁数で検証し、違反があれば日本語の例外を投げる */
function assertField(value: string, charset: ZenginCharset, maxBytes: number, fieldLabel: string): void {
  let bytes: number;
  try {
    bytes = jis8ByteLength(value);
  } catch (e) {
    throw new Error(`${fieldLabel}: ${(e as Error).message}`);
  }
  if (bytes > maxBytes) {
    throw new Error(`${fieldLabel}が桁数を超えています: "${value}" は ${bytes} バイトで、上限 ${maxBytes} バイトを超えています`);
  }
  const v = validateCharset(value, charset);
  if (!v.ok) throw new Error(`${fieldLabel} — ${v.message}`);
}

/** MMDD 形式の日付を検証する ([S1] 取組日/引落日 N(4)) */
function assertMMDD(value: string, fieldLabel: string): void {
  if (!/^[0-9]{4}$/.test(value)) throw new Error(`${fieldLabel}は MMDD の4桁数字で指定してください (受け取った値: "${value}")`);
  const mm = Number(value.slice(0, 2));
  const dd = Number(value.slice(2, 4));
  if (mm < 1 || mm > 12) throw new Error(`${fieldLabel}の月が不正です: "${value}"`);
  if (dd < 1 || dd > 31) throw new Error(`${fieldLabel}の日が不正です: "${value}"`);
}

/**
 * レコードが全銀協規定の 120 **バイト** 固定長であることを機械検証する。
 * 文字数ではなくバイト数で判定する点が本関数の要件 ([S2]「レコード長 120バイト」)。
 */
export function assertZenginRecordBytes(record: string, recordLabel: string): string {
  const bytes = jis8ByteLength(record);
  if (bytes !== ZENGIN_RECORD_BYTES) {
    throw new Error(`${recordLabel}は ${ZENGIN_RECORD_BYTES} バイト固定長である必要がありますが ${bytes} バイトになりました (文字数 ${record.length})`);
  }
  return record;
}

/** レコード文字列を JIS8 (JIS X 0201) バイト列へ符号化する */
export function encodeZenginRecord(record: string): Uint8Array {
  const encoded = encodeJis8(record, { strict: true });
  if (encoded.bytes.length !== ZENGIN_RECORD_BYTES) {
    throw new Error(`符号化後のレコード長が ${encoded.bytes.length} バイトです (${ZENGIN_RECORD_BYTES} バイトである必要があります)`);
  }
  return encoded.bytes;
}

// ───────────────────────────────────────────────
// 全銀フォーマット ヘッダー・レコード (120バイト)
// ───────────────────────────────────────────────

/**
 * ヘッダー・レコード (120バイト) — [S1] Ⅱ-4 / Ⅱ-8 / Ⅱ-15、[S2] [S3] [S4]
 *
 *   1     : データ区分 = '1'
 *   2-3   : 種別コード (11/12/21/91)
 *   4     : コード区分 '0'=JIS / '1'=EBCDIC
 *   5-14  : 委託者コード (振込依頼人コード/会社コード) N(10)
 *   15-54 : 委託者名 (振込依頼人名/会社名) C(40)
 *   55-58 : 取組日 (振込指定日/引落日) N(4) MMDD
 *   59-62 : 仕向 (取引) 銀行番号 N(4)
 *   63-77 : 仕向 (取引) 銀行名 C(15)
 *   78-80 : 仕向 (取引) 支店番号 N(3)
 *   81-95 : 仕向 (取引) 支店名 C(15)
 *   96    : 預金種目 N(1)
 *   97-103: 口座番号 N(7)
 *  104-120: ダミー C(17)
 *          計 120
 */
export interface ZenginHeader {
  consignorCode: string; //  10桁
  consignorName: string; //  半角カナ40バイト
  transferDate: string; //  MMDD
  originBankCode: string; //  4桁
  originBankName: string; //  半角カナ15バイト
  originBranchCode: string; //  3桁
  originBranchName: string; //  半角カナ15バイト
  originAccountType: '1' | '2' | '9';
  originAccountNumber: string; //  7桁
  /** 業務種別。既定は総合振込 (種別コード 21) */
  businessKind?: ZenginBusinessKind;
  /** コード区分。既定 '0' (JIS)。EBCDIC を選ぶ場合は取引銀行と要調整 */
  codeDivision?: '0' | '1';
}

export function buildZenginHeaderRecord(h: ZenginHeader): string {
  const kind: ZenginBusinessKind = h.businessKind ?? 'sougou_furikomi';
  const label = ZENGIN_BUSINESS_LABELS[kind];
  const nameCharset = kind === 'sougou_furikomi' ? CHARSET_NAME_WITH_WO : CHARSET_NAME_WITHOUT_WO;
  const branchCharset = kind === 'sougou_furikomi' ? CHARSET_BRANCH_WITH_WO : CHARSET_BRANCH_WITHOUT_WO;

  assertMMDD(h.transferDate, kind === 'kouza_furikae' ? '引落日' : '取組日');
  assertField(h.consignorName, nameCharset, 40, `${label} 委託者名`);
  assertField(h.originBankName, branchCharset, 15, `${label} 仕向銀行名`);
  assertField(h.originBranchName, branchCharset, 15, `${label} 仕向支店名`);

  const allowedHeaderTypes = ZENGIN_ALLOWED_HEADER_ACCOUNT_TYPES[kind];
  if (!allowedHeaderTypes.includes(h.originAccountType)) {
    throw new Error(`${label}のヘッダー預金種目に使用できるのは ${allowedHeaderTypes.join('/')} です (受け取った値: "${h.originAccountType}")`);
  }

  const parts = [
    '1', //   1     データ区分
    ZENGIN_TYPE_CODES[kind], //   2-3   種別コード
    h.codeDivision ?? '0', //   4     コード区分 (0=JIS)
    padJis8Zero(h.consignorCode, 10), //   5-14  委託者コード
    padJis8Left(h.consignorName, 40), //  15-54  委託者名
    h.transferDate, //  55-58  取組日 (MMDD)
    padJis8Zero(h.originBankCode, 4), //  59-62  仕向銀行番号
    padJis8Left(h.originBankName, 15), //  63-77  仕向銀行名
    padJis8Zero(h.originBranchCode, 3), //  78-80  仕向支店番号
    padJis8Left(h.originBranchName, 15), //  81-95  仕向支店名
    h.originAccountType, //  96     預金種目
    padJis8Zero(h.originAccountNumber, 7), //  97-103 口座番号
    ' '.repeat(17), // 104-120 ダミー
  ];
  return assertZenginRecordBytes(parts.join(''), `${label} ヘッダー・レコード`);
}

// ───────────────────────────────────────────────
// 全銀フォーマット データ・レコード (120バイト・業務別)
// ───────────────────────────────────────────────

type DataRecordEntry = ZenginTransferEntry & { recipientBankNameKana: string; recipientBranchNameKana: string };

/** データ・レコードの共通先頭 50 バイト (項番1〜8) を組み立てる */
function buildDataRecordPrefix(entry: DataRecordEntry, kind: ZenginBusinessKind): string {
  const label = ZENGIN_BUSINESS_LABELS[kind];
  const branchCharset = kind === 'sougou_furikomi' ? CHARSET_BRANCH_WITH_WO : CHARSET_BRANCH_WITHOUT_WO;

  assertField(entry.recipientBankNameKana, branchCharset, 15, `${label} 被仕向銀行名`);
  assertField(entry.recipientBranchNameKana, branchCharset, 15, `${label} 被仕向支店名`);

  const allowed = ZENGIN_ALLOWED_ACCOUNT_TYPES[kind];
  if (!allowed.includes(entry.accountType)) {
    throw new Error(`${label}の預金種目に使用できるのは ${allowed.join('/')} です (受け取った値: "${entry.accountType}")`);
  }
  if (!Number.isInteger(entry.amountYen) || entry.amountYen < 0) {
    throw new Error(`${label}の金額は0以上の整数 (円) で指定してください (受け取った値: ${entry.amountYen})`);
  }

  //  預金口座振替の項番6 はダミー C(4)、振込系の項番6 は手形交換所番号 N(4)
  const field6 = kind === 'kouza_furikae' ? ' '.repeat(4) : padJis8Zero(entry.clearingHouseCode ?? '0', 4);

  return [
    '2', //   1     データ区分
    padJis8Zero(entry.bankCode, 4), //   2-5   被仕向 (引落) 銀行番号
    padJis8Left(entry.recipientBankNameKana, 15), //   6-20  被仕向 (引落) 銀行名
    padJis8Zero(entry.branchCode, 3), //  21-23  被仕向 (引落) 支店番号
    padJis8Left(entry.recipientBranchNameKana, 15), //  24-38  被仕向 (引落) 支店名
    field6, //  39-42  手形交換所番号 / ダミー
    entry.accountType, //  43     預金種目
    padJis8Zero(entry.accountNumber, 7), //  44-50  口座番号
  ].join('');
}

/**
 * 総合振込 データ・レコード (120バイト) — [S1] Ⅱ-8 ②、[S2] [S4]
 *
 *   1     : データ区分 '2'
 *   2-5   : 被仕向銀行番号 N(4)
 *   6-20  : 被仕向銀行名 C(15)
 *   21-23 : 被仕向支店番号 N(3)
 *   24-38 : 被仕向支店名 C(15)
 *   39-42 : 手形交換所番号 N(4)
 *   43    : 預金種目 N(1)
 *   44-50 : 口座番号 N(7)
 *   51-80 : 受取人名 C(30)
 *   81-90 : 振込金額 N(10)
 *   91    : 新規コード N(1)
 *   92-111: 顧客コード1 N(10) + 顧客コード2 N(10)  … 識別表示がスペースのとき
 *           EDI情報 C(20)                        … 識別表示が 'Y' のとき
 *   112   : 振込指定区分 N(1) 7=テレ振込 8=文書振込
 *   113   : 識別表示 C(1) 'Y' or SP
 *   114-120: ダミー C(7)
 *          計 120
 *
 *   ※ 旧実装は 91 の後に「顧客コード(10) + EDI情報(20) + SP(1)」を **両方** 連結しており、
 *     常に 122 文字となって `record.length !== 120` で必ず例外になっていた。
 *     顧客コード1/2 と EDI 情報は同一エリアの排他利用である ([S1] 項番12・13 の併記、
 *     [S4]「『項番15.識別表示』で『Y』を入力した場合 / 入力しない場合」)。
 */
export function buildZenginDataRecord(entry: DataRecordEntry, kind: ZenginBusinessKind = 'sougou_furikomi'): string {
  if (kind === 'kyuyo_furikomi' || kind === 'shoyo_furikomi') return buildZenginPayrollDataRecord(entry, kind);
  if (kind === 'kouza_furikae') return buildZenginDirectDebitDataRecord(entry);

  const label = ZENGIN_BUSINESS_LABELS[kind];
  assertField(entry.recipientNameKana, CHARSET_NAME_WITH_WO, 30, `${label} 受取人名`);

  const useEdi = entry.ediInfo !== undefined && entry.ediInfo !== '';
  if (useEdi && (entry.customerCode || entry.customerCode2)) {
    throw new Error('EDI情報と顧客コード1/2 は同一エリアの排他利用です。どちらか一方だけを指定してください ([S1] 総合振込 項番12・13)');
  }
  if (useEdi) assertField(entry.ediInfo!, CHARSET_EDI, 20, `${label} EDI情報`);

  const codeArea = useEdi
    ? padJis8Left(entry.ediInfo!, 20)
    : padJis8Zero(entry.customerCode ?? '', 10) + padJis8Zero(entry.customerCode2 ?? '', 10);

  const parts = [
    buildDataRecordPrefix(entry, kind), //   1-50
    padJis8Left(entry.recipientNameKana, 30), //  51-80  受取人名
    padJis8Zero(entry.amountYen, 10), //  81-90  振込金額
    entry.newChangeCode ?? '0', //  91     新規コード
    codeArea, //  92-111 顧客コード1/2 または EDI情報
    entry.transferCategory ?? '7', // 112     振込指定区分 (7=テレ振込)
    useEdi ? 'Y' : ' ', // 113     識別表示
    ' '.repeat(7), // 114-120 ダミー
  ];
  return assertZenginRecordBytes(parts.join(''), `${label} データ・レコード`);
}

/**
 * 給与振込 / 賞与振込 データ・レコード (120バイト) — [S1] Ⅱ-4 ②、[S3]
 *
 *   … 項番1〜11 は総合振込と同一 …
 *   92-101 : 社員番号 N(10)
 *   102-111: 所属コード N(10)
 *   112-120: ダミー C(9)
 *          計 120
 *
 *   総合振込との差異: 振込指定区分・識別表示・EDI情報が **無く**、
 *   代わりに社員番号・所属コードが入り、ダミーが 7 → 9 バイトになる。
 *   預金種目も 1(普通) / 2(当座) の 2 種類のみ。
 */
export function buildZenginPayrollDataRecord(entry: DataRecordEntry, kind: 'kyuyo_furikomi' | 'shoyo_furikomi' = 'kyuyo_furikomi'): string {
  const label = ZENGIN_BUSINESS_LABELS[kind];
  //  給与・賞与振込の預金者名は ヲ 不可 ([S1] 付録1 注1 の但し書きに給与・賞与振込は含まれない)
  assertField(entry.recipientNameKana, CHARSET_NAME_WITHOUT_WO, 30, `${label} 預金者名`);
  if (entry.ediInfo) throw new Error(`${label}には EDI情報欄がありません ([S1] Ⅱ-4 ②)`);

  const parts = [
    buildDataRecordPrefix(entry, kind), //   1-50
    padJis8Left(entry.recipientNameKana, 30), //  51-80  預金者名
    padJis8Zero(entry.amountYen, 10), //  81-90  振込金額
    entry.newChangeCode ?? '0', //  91     新規コード
    padJis8Zero(entry.employeeNumber ?? '', 10), //  92-101 社員番号
    padJis8Zero(entry.departmentCode ?? '', 10), // 102-111 所属コード
    ' '.repeat(9), // 112-120 ダミー
  ];
  return assertZenginRecordBytes(parts.join(''), `${label} データ・レコード`);
}

/**
 * 預金口座振替 (依頼明細) データ・レコード (120バイト) — [S1] Ⅱ-15 ②
 *
 *   1     : データ区分 '2'
 *   2-5   : 引落銀行番号 N(4)
 *   6-20  : 引落銀行名 C(15)
 *   21-23 : 引落支店番号 N(3)
 *   24-38 : 引落支店名 C(15)
 *   39-42 : ダミー C(4)          ← 振込系の「手形交換所番号」ではない
 *   43    : 預金種目 N(1) 1/2/3/9
 *   44-50 : 口座番号 N(7)
 *   51-80 : 預金者名 C(30)
 *   81-90 : 引落金額 N(10)
 *   91    : 新規コード N(1)
 *   92-111: 顧客番号 N(20)
 *   112   : 振替結果コード N(1)  ← 依頼明細では '0'
 *   113-120: ダミー C(8)
 *          計 120
 */
export function buildZenginDirectDebitDataRecord(entry: DataRecordEntry): string {
  const kind: ZenginBusinessKind = 'kouza_furikae';
  const label = ZENGIN_BUSINESS_LABELS[kind];
  assertField(entry.recipientNameKana, CHARSET_NAME_WITHOUT_WO, 30, `${label} 預金者名`);

  const parts = [
    buildDataRecordPrefix(entry, kind), //   1-50
    padJis8Left(entry.recipientNameKana, 30), //  51-80  預金者名
    padJis8Zero(entry.amountYen, 10), //  81-90  引落金額
    entry.newChangeCode ?? '0', //  91     新規コード
    padJis8Zero(entry.customerNumber ?? entry.customerCode ?? '', 20), //  92-111 顧客番号
    entry.debitResultCode ?? '0', // 112     振替結果コード (依頼明細は '0')
    ' '.repeat(8), // 113-120 ダミー
  ];
  return assertZenginRecordBytes(parts.join(''), `${label} データ・レコード`);
}

// ───────────────────────────────────────────────
// トレーラ / エンド・レコード (120バイト)
// ───────────────────────────────────────────────

/**
 * トレーラ・レコード (120バイト)
 *   振込系 ([S1] Ⅱ-4 ③ / Ⅱ-8 ③): 1 データ区分 '8' + 6 合計件数 + 12 合計金額 + 101 ダミー
 *   預金口座振替 ([S1] Ⅱ-15 ③)  : 1 + 6 合計件数 + 12 合計金額 + 6 振替済件数 + 12 振替済金額
 *                                  + 6 振替不能件数 + 12 振替不能金額 + 65 ダミー
 *                                  (依頼明細では振替済/振替不能は全て 0)
 */
export function buildZenginTrailerRecord(
  input: { totalCount: number; totalAmountYen: number; settledCount?: number; settledAmountYen?: number; failedCount?: number; failedAmountYen?: number },
  kind: ZenginBusinessKind = 'sougou_furikomi',
): string {
  const label = ZENGIN_BUSINESS_LABELS[kind];
  if (kind === 'kouza_furikae') {
    const parts = [
      '8',
      padJis8Zero(input.totalCount, 6),
      padJis8Zero(input.totalAmountYen, 12),
      padJis8Zero(input.settledCount ?? 0, 6),
      padJis8Zero(input.settledAmountYen ?? 0, 12),
      padJis8Zero(input.failedCount ?? 0, 6),
      padJis8Zero(input.failedAmountYen ?? 0, 12),
      ' '.repeat(65),
    ];
    return assertZenginRecordBytes(parts.join(''), `${label} トレーラ・レコード`);
  }
  const parts = ['8', padJis8Zero(input.totalCount, 6), padJis8Zero(input.totalAmountYen, 12), ' '.repeat(101)];
  return assertZenginRecordBytes(parts.join(''), `${label} トレーラ・レコード`);
}

/** エンド・レコード (120バイト) — データ区分 '9' + ダミー C(119) */
export function buildZenginEndRecord(): string {
  return assertZenginRecordBytes('9' + ' '.repeat(119), 'エンド・レコード');
}

// ───────────────────────────────────────────────
// ファイル生成
// ───────────────────────────────────────────────

export interface ZenginFileInput {
  header: ZenginHeader;
  entries: Array<DataRecordEntry>;
  /**
   * 改行の付与方式。
   * [S2]「改行 (CR LF) をつける場合 120バイトの後に2バイトで収容する」
   * [S4]「レコードごとの改行コードの有無は任意」「改行コードは CR+LF / CR / LF」
   * 既定は 'crlf'。取引銀行が改行なしを要求する場合は 'none' を選ぶ。
   */
  lineEnding?: 'crlf' | 'cr' | 'lf' | 'none';
  /** 末尾 (エンド・レコードの後) にも改行を付けるか。既定 true */
  trailingLineEnding?: boolean;
}

/** 全銀ファイルを構成する 120 バイトレコードの配列を返す */
export function buildZenginRecords(input: ZenginFileInput): string[] {
  const kind: ZenginBusinessKind = input.header.businessKind ?? 'sougou_furikomi';
  const records = [buildZenginHeaderRecord(input.header)];
  let total = 0;
  for (const e of input.entries) {
    records.push(buildZenginDataRecord(e, kind));
    total += e.amountYen;
  }
  records.push(buildZenginTrailerRecord({ totalCount: input.entries.length, totalAmountYen: total }, kind));
  records.push(buildZenginEndRecord());
  return records;
}

function lineEndingOf(mode: ZenginFileInput['lineEnding']): string {
  switch (mode ?? 'crlf') {
    case 'none':
      return '';
    case 'cr':
      return '\r';
    case 'lf':
      return '\n';
    default:
      return '\r\n';
  }
}

/**
 * 完全な全銀ファイル文字列を生成する。
 *
 *   返り値は「1文字 = JIS8 1バイト」となる文字列であり、
 *   **実提出用のバイト列は必ず {@link buildZenginTransferFileBytes} で取得すること**。
 *   UTF-8 のまま保存すると半角カナが 3 バイトになり 120 バイト固定長が崩れる。
 */
export function buildZenginTransferFile(input: ZenginFileInput): string {
  const eol = lineEndingOf(input.lineEnding);
  const records = buildZenginRecords(input);
  const body = records.join(eol);
  return body + ((input.trailingLineEnding ?? true) ? eol : '');
}

/**
 * 実提出用の全銀ファイル **バイト列** (JIS8 = JIS X 0201) を生成する。
 * 各レコードが 120 バイトであることを 1 本ずつ機械検証したうえで連結する。
 */
export function buildZenginTransferFileBytes(input: ZenginFileInput): Uint8Array {
  const eol = lineEndingOf(input.lineEnding);
  //  CR (0x0D) / LF (0x0A) は JIS X 0201 の図形文字ではなく制御コードなので、
  //  encodeJis8 (図形文字のみを通す fail-closed エンコーダ) には通さず直接バイト化する。
  const eolRaw: number[] = [];
  for (const c of eol) eolRaw.push(c.charCodeAt(0));

  const records = buildZenginRecords(input);
  const out: number[] = [];
  records.forEach((r, i) => {
    const b = encodeZenginRecord(r);
    out.push(...b);
    const isLast = i === records.length - 1;
    if (!isLast || (input.trailingLineEnding ?? true)) out.push(...eolRaw);
  });
  return Uint8Array.from(out);
}

/**
 * 生成済みの全銀ファイル (バイト列) が 120 バイト固定長構成になっているかを検証する。
 * 提出前の最終ゲートとして使う。
 */
export function verifyZenginFileBytes(bytes: Uint8Array, lineEnding: ZenginFileInput['lineEnding'] = 'crlf'): { ok: boolean; recordCount: number; problems: string[] } {
  const eolLen = lineEndingOf(lineEnding).length;
  const stride = ZENGIN_RECORD_BYTES + eolLen;
  const problems: string[] = [];
  let offset = 0;
  let count = 0;
  while (offset < bytes.length) {
    const remaining = bytes.length - offset;
    const take = remaining >= stride ? stride : remaining;
    if (take !== stride && take !== ZENGIN_RECORD_BYTES) {
      problems.push(`${count + 1}件目のレコード長が ${take} バイトです (${ZENGIN_RECORD_BYTES} バイトである必要があります)`);
      break;
    }
    const rec = bytes.slice(offset, offset + ZENGIN_RECORD_BYTES);
    try {
      decodeJis8(rec);
    } catch (e) {
      problems.push(`${count + 1}件目: ${(e as Error).message}`);
    }
    const kindByte = rec[0]!;
    if (![0x31, 0x32, 0x38, 0x39].includes(kindByte)) {
      problems.push(`${count + 1}件目のデータ区分が不正です: 0x${kindByte.toString(16)}`);
    }
    offset += take;
    count++;
  }
  return { ok: problems.length === 0, recordCount: count, problems };
}

/**
 * 提出前に受取人名等を全銀提出形式へ正規化し、変更点を利用者へ申告するためのヘルパ。
 * **黙って変えない**: 変更した箇所は必ず changes として返る。
 */
export function normalizeZenginName(name: string): NormalizeResult {
  return normalizeForZengin(name);
}

// ───────────────────────────────────────────────
// 組戻し (くみもどし) / 訂正 / 取消
// ───────────────────────────────────────────────

/**
 * ■ 組戻しの位置づけ (重要)
 *
 *   組戻しは **全銀協制定レコード・フォーマットの業務ではない**。
 *   [S1] AP-Ⅰ-12 の適用業務一覧に内国為替の組戻し業務は存在せず、
 *   企業から銀行への依頼は「組戻依頼書」または EB 画面で行い、
 *   銀行が被仕向金融機関へ **組戻依頼電文** を発信する
 *   ([S5] 8(1)③「当行は、…当行所定の書類に記載された内容に従って、
 *    組戻依頼電文を振込先の金融機関に発信します」)。
 *   したがって本モジュールが生成するのは「組戻依頼の内容」であり、
 *   全銀 120 バイトレコードではない。
 *
 * ■ 訂正 (依頼内容の変更) との切り分け — [S5] 7(1)但書
 *   「ただし、振込先の金融機関若しくは店舗名又は振込金額を変更する場合には、
 *     …組戻しの手続により取り扱います」
 *   → 金融機関・店舗・金額の変更は訂正では不可。組戻し。
 *
 * ■ 受取人の承諾 — [S5] 7(3) / 8(3)
 *   「振込先の金融機関が既に振込通知を受信しているときは、訂正 (組戻し) ができないことがあります。
 *     この場合には、受取人との間で協議してください」
 *
 * ■ 資金の戻し入れ — [S5] 8(1)④
 *   「組戻しされた振込資金は、振込資金を払い出した振替口座に戻し入れます」
 *
 * ■ 料金 — [S5] 10(2)
 *   「訂正又は組戻しの依頼に当たっては、当行所定の訂正又は組戻しの料金を…いただきます。
 *     この場合、訂正又は組戻しの成否にかかわらず、振込の料金及び訂正又は組戻しの料金は返却しません」
 *   → **成否にかかわらず振込手数料も組戻手数料も返還されない**。
 *     金額は銀行所定 (各行で異なる) のため、本モジュールは確定値を持たない。
 */
export const KUMIMODOSHI_SOURCES: readonly string[] = [
  'ゆうちょ銀行 振込規定 (Ⅱ-04-202601版) 7 依頼内容の変更 / 8 組戻し / 10 料金 — https://www.jp-bank.japanpost.jp/kitei/pdf/hurikomi.pdf',
  '全国銀行協会 全銀協パーソナル・コンピュータ用標準通信プロトコル〔別冊〕適用業務およびレコード・フォーマット AP-Ⅰ-12 (令和元年12月) — 内国為替の組戻しは適用業務に含まれない — https://www.zenginkyo.or.jp/fileadmin/res/abstract/efforts/system/jba_protocol_pc.pdf',
] as const;

/** 変更したい対象 */
export type TransferAmendmentField =
  | 'recipient_bank' //  振込先金融機関
  | 'recipient_branch' //  振込先店舗
  | 'amount' //  振込金額
  | 'account_type' //  預金種目
  | 'account_number' //  口座番号
  | 'recipient_name' //  受取人名
  | 'edi_info' //  EDI情報・顧客コード
  | 'cancel_entirely'; //  振込そのものの取りやめ

export type TransferAmendmentProcedure =
  | 'cancel_before_send' //  銀行へ送信 (承認) 前の取消 — 依頼データの削除
  | 'correction' //  依頼内容の変更 (訂正依頼電文)
  | 'kumimodoshi'; //  組戻し (組戻依頼電文)

export interface TransferAmendmentContext {
  /** 銀行への依頼データ送信 (承認) が完了しているか */
  sentToBank: boolean;
  /** 被仕向金融機関が既に振込通知を受信しているか。不明な場合は undefined のままにする */
  recipientBankNotified?: boolean;
  /** 変更したい対象 */
  fields: TransferAmendmentField[];
}

export interface TransferAmendmentDecision {
  procedure: TransferAmendmentProcedure;
  /** 手続名 (日本語) */
  procedureLabel: string;
  /** 受取人の承諾 (協議) が必要か */
  requiresRecipientConsent: boolean;
  /** なぜ承諾が必要か / 不要かの説明 */
  recipientConsentNote: string;
  /** 銀行所定の手数料が発生するか */
  feeApplies: boolean;
  /** 既に負担した振込手数料が返還されるか */
  transferFeeRefundable: boolean;
  /** 利用者へ提示する手順 */
  steps: string[];
  sources: readonly string[];
}

/** 組戻しでしか変更できない項目 — [S5] 7(1)但書 */
const KUMIMODOSHI_ONLY_FIELDS: readonly TransferAmendmentField[] = ['recipient_bank', 'recipient_branch', 'amount', 'cancel_entirely'];

/**
 * 「取消 / 訂正 / 組戻し」のどの手続になるかを判定する。
 * 判定の根拠は {@link KUMIMODOSHI_SOURCES} に記載した振込規定の条文。
 */
export function decideTransferAmendment(ctx: TransferAmendmentContext): TransferAmendmentDecision {
  if (ctx.fields.length === 0) throw new Error('変更したい対象 (fields) を1つ以上指定してください');

  //  ① 銀行へ送信 (承認) 前 — 依頼データを削除すればよく、振込契約が成立していないため手数料も承諾も不要
  if (!ctx.sentToBank) {
    return {
      procedure: 'cancel_before_send',
      procedureLabel: '取消 (銀行へ送信する前の依頼データ削除)',
      requiresRecipientConsent: false,
      recipientConsentNote: 'まだ銀行へ依頼を送信していないため、受取人の承諾は不要です。',
      feeApplies: false,
      transferFeeRefundable: true,
      steps: [
        '振込データの状態が「未送信 (承認前・予約中)」であることを確認します。',
        '該当の振込明細を削除、または依頼全体を取り消します。',
        '取消後、振込予定一覧に該当明細が残っていないことを確認します。',
      ],
      sources: KUMIMODOSHI_SOURCES,
    };
  }

  //  ② 送信済み — 変更対象により訂正か組戻しかが決まる
  const needsKumimodoshi = ctx.fields.some((f) => KUMIMODOSHI_ONLY_FIELDS.includes(f));
  const notified = ctx.recipientBankNotified;
  const consentNote =
    notified === true
      ? '振込先の金融機関が既に振込通知を受信しているため、受取人との協議 (承諾) が必要です。承諾が得られない場合、資金は戻りません。'
      : notified === false
        ? '振込先の金融機関がまだ振込通知を受信していないため、受取人の承諾なしに手続できる可能性があります。ただし最終判断は取引銀行が行います。'
        : '振込先の金融機関が振込通知を受信済みかどうかが不明です。受信済みの場合は受取人との協議 (承諾) が必要になるため、承諾が必要な前提で進めてください。';

  if (needsKumimodoshi) {
    return {
      procedure: 'kumimodoshi',
      procedureLabel: '組戻し',
      requiresRecipientConsent: notified !== false,
      recipientConsentNote: consentNote,
      feeApplies: true,
      transferFeeRefundable: false,
      steps: [
        '取引銀行所定の組戻依頼書に必要事項を記入し、記名押印 (または署名) のうえ、依頼書控等とともに提出します。',
        '銀行が組戻依頼電文を振込先の金融機関へ発信します。',
        '振込先の金融機関が既に振込通知を受信している場合は、受取人との協議 (承諾) が必要になります。',
        '組戻しが成立した場合、振込資金は振込資金を引き落とした依頼人口座へ戻し入れられます。',
        '組戻しの成否にかかわらず、振込手数料および組戻手数料は返還されません。',
      ],
      sources: KUMIMODOSHI_SOURCES,
    };
  }

  return {
    procedure: 'correction',
    procedureLabel: '訂正 (依頼内容の変更)',
    requiresRecipientConsent: notified !== false,
    recipientConsentNote: consentNote,
    feeApplies: true,
    transferFeeRefundable: false,
    steps: [
      '取引銀行所定の訂正依頼書に必要事項を記入し、記名押印 (または署名) のうえ提出します。',
      '銀行が訂正依頼電文を振込先の金融機関へ発信します。',
      '振込先の金融機関が既に振込通知を受信している場合は、受取人との協議が必要になります。',
      '訂正の成否にかかわらず、振込手数料および訂正手数料は返還されません。',
      '振込先の金融機関・店舗・金額を変更する場合は訂正では取り扱えず、組戻しの手続になります。',
    ],
    sources: KUMIMODOSHI_SOURCES,
  };
}

/** 組戻しの依頼事由 */
export type KumimodoshiReason =
  | 'wrong_account' //  口座相違 (誤入力)
  | 'wrong_amount' //  金額相違
  | 'duplicate_transfer' //  二重振込
  | 'contract_cancelled' //  取引解消・発注取消
  | 'fraud_suspected' //  詐欺被害の疑い
  | 'other';

export const KUMIMODOSHI_REASON_LABELS: Readonly<Record<KumimodoshiReason, string>> = {
  wrong_account: '振込先口座の相違',
  wrong_amount: '振込金額の相違',
  duplicate_transfer: '二重振込',
  contract_cancelled: '取引の解消・発注の取消',
  fraud_suspected: '詐欺被害の疑い',
  other: 'その他',
} as const;

export interface KumimodoshiInput {
  /** 組戻し対象となった振込の内容 */
  original: {
    /** 取組日 MMDD */
    transferDate: string;
    /** 被仕向銀行コード 4桁 */
    bankCode: string;
    /** 被仕向支店コード 3桁 */
    branchCode: string;
    accountType: '1' | '2' | '4' | '9';
    accountNumber: string;
    recipientNameKana: string;
    amountYen: number;
    /** 委託者コード (総合振込の場合) */
    consignorCode?: string;
    /** 依頼時に付与した顧客コード */
    customerCode?: string;
  };
  reason: KumimodoshiReason;
  /** 事由の補足 (自由記述) */
  reasonDetail?: string;
  requestedBy: { name: string; department?: string; phone?: string };
  /** 依頼日 (YYYY-MM-DD) */
  requestedAt: string;
  /** 被仕向金融機関が既に振込通知を受信しているか (不明なら undefined) */
  recipientBankNotified?: boolean;
  /**
   * 取引銀行と約定している組戻手数料 (円・税込)。
   * **本モジュールは確定値を持たない**。未設定の場合は「取引銀行に要確認」として返す。
   */
  kumimodoshiFeeYen?: number | null;
  /** 既に負担済みの振込手数料 (円) */
  paidTransferFeeYen?: number | null;
}

export interface KumimodoshiRequest {
  procedure: 'kumimodoshi';
  procedureLabel: string;
  original: KumimodoshiInput['original'];
  reason: KumimodoshiReason;
  reasonLabel: string;
  reasonDetail?: string;
  requestedBy: KumimodoshiInput['requestedBy'];
  requestedAt: string;
  /** 受取人の承諾 (協議) が必要か */
  requiresRecipientConsent: boolean;
  recipientConsentNote: string;
  /** 資金の戻し入れ先 */
  fundsReturnedTo: string;
  fee: {
    /** 組戻手数料 (円)。取引銀行と約定した値。不明なら null */
    kumimodoshiFeeYen: number | null;
    /** 既に負担済みの振込手数料 (円)。不明なら null */
    paidTransferFeeYen: number | null;
    /** 組戻しの成否にかかわらず組戻手数料は返還されない */
    kumimodoshiFeeRefundable: false;
    /** 組戻しの成否にかかわらず振込手数料は返還されない */
    transferFeeRefundable: false;
    /** 手数料額を取引銀行に確認する必要があるか */
    requiresBankConfirmation: boolean;
    /** 利用者へそのまま提示する日本語の注意書き */
    disclaimer: string;
  };
  /** 全銀レコードで送れるか (送れない) */
  transmission: { viaZenginRecord: false; note: string };
  /** 依頼書に記載/添付する内容のチェックリスト */
  checklist: string[];
  sources: readonly string[];
}

/**
 * 組戻依頼の内容を組み立てる。
 *
 *   手数料は **銀行ごとに異なり、本モジュールは確定値を持たない**。
 *   `kumimodoshiFeeYen` が未設定の場合、requiresBankConfirmation = true とし、
 *   金額欄は null のまま返す (勝手な数値を作らない)。
 */
export function buildKumimodoshiRequest(input: KumimodoshiInput): KumimodoshiRequest {
  const decision = decideTransferAmendment({
    sentToBank: true,
    recipientBankNotified: input.recipientBankNotified,
    fields: ['cancel_entirely'],
  });

  const feeKnown = typeof input.kumimodoshiFeeYen === 'number' && Number.isFinite(input.kumimodoshiFeeYen);

  return {
    procedure: 'kumimodoshi',
    procedureLabel: '組戻し',
    original: input.original,
    reason: input.reason,
    reasonLabel: KUMIMODOSHI_REASON_LABELS[input.reason],
    reasonDetail: input.reasonDetail,
    requestedBy: input.requestedBy,
    requestedAt: input.requestedAt,
    requiresRecipientConsent: decision.requiresRecipientConsent,
    recipientConsentNote: decision.recipientConsentNote,
    fundsReturnedTo: '振込資金を引き落とした依頼人名義の口座',
    fee: {
      kumimodoshiFeeYen: feeKnown ? (input.kumimodoshiFeeYen as number) : null,
      paidTransferFeeYen: typeof input.paidTransferFeeYen === 'number' ? input.paidTransferFeeYen : null,
      kumimodoshiFeeRefundable: false,
      transferFeeRefundable: false,
      requiresBankConfirmation: !feeKnown,
      disclaimer: feeKnown
        ? '組戻しの成否にかかわらず、振込手数料および組戻手数料は返還されません。表示している組戻手数料はご登録いただいた約定値です。'
        : '組戻手数料は取引銀行ごとに異なるため、本システムでは金額を保持していません。実際の金額は取引銀行にご確認ください。なお、組戻しの成否にかかわらず、振込手数料および組戻手数料は返還されません。',
    },
    transmission: {
      viaZenginRecord: false,
      note: '組戻しは全銀協制定レコード・フォーマットの適用業務ではありません。取引銀行所定の組戻依頼書または EB 画面から依頼し、銀行が組戻依頼電文を振込先の金融機関へ発信します。',
    },
    checklist: [
      '組戻し対象の振込明細 (取組日・被仕向金融機関・支店・口座番号・受取人名・金額) を依頼書へ正確に転記する',
      '依頼書控 (振込を依頼したときの控) を添付する',
      '記名押印 (または署名) が届出印と一致しているか確認する',
      '振込先の金融機関が既に振込通知を受信している場合は、受取人へ連絡し返金の承諾を得る',
      '組戻手数料および既払いの振込手数料が返還されないことを申請者へ周知する',
    ],
    sources: KUMIMODOSHI_SOURCES,
  };
}

// ───────────────────────────────────────────────
// 振込手数料の扱い
// ───────────────────────────────────────────────

/**
 * ■ 設計方針 (なぜ確定値を持たないか)
 *
 *   振込手数料は
 *     ① 銀行ごとに異なる
 *     ② 同じ銀行でもチャネル (窓口 / ATM / 個人IB / 法人IB) ごとに異なる
 *     ③ 法人の EB 契約では契約単位の個別料率になることがある
 *     ④ 料金体系そのものが行によって違う
 *        (例: 三井住友銀行の EB サービスは他行あてが金額区分によらない定額体系の商品がある。
 *         「3万円未満 / 3万円以上」という区分を全行に当てはめるモデル自体が誤り)
 *     ⑤ 改定が頻繁 (2021年・2023年・2026年にも各行で改定が入っている)
 *   という性質を持つ。単価表と同じく、**製品が確定値を持つと必ず古くなり、
 *   その古い値で請求書が作られる** ため、本モジュールは確定値を持たない設計とした。
 *
 *   運用は次の3層とする:
 *     1. 顧客が取引銀行と約定した手数料表を {@link TransferFeeTable} として登録する (これが正)
 *     2. 未登録の場合、{@link estimateTransferFee} は金額を返さず「取引銀行に要確認」を返す
 *     3. {@link STANDARD_TRANSFER_FEES} は出所と時点を明記した **参考値** であり、
 *        画面や帳票に出す際は必ず {@link TRANSFER_FEE_DISCLAIMER} を併記する
 */

/** 手数料の区分 */
export interface TransferFeeBracket {
  /** 閾値未満の手数料 (円) */
  underThreshold: number;
  /** 閾値以上の手数料 (円) */
  aboveThreshold: number;
  /** 金額の閾値 (円)。金額区分がない定額体系の場合は 0 を指定し、両者に同じ値を入れる */
  thresholdYen: number;
}

/** 手数料表の出所 (何をいつどこから取ったか) */
export interface TransferFeeProvenance {
  /** 一次情報 (銀行公表) で確認できたか */
  verified: boolean;
  /** 出典 URL。確認できていない場合は null */
  sourceUrl: string | null;
  /** 出典に記載された適用時点 */
  asOf: string;
  /** どのチャネルの手数料か */
  channel: 'window' | 'atm' | 'personal_ib' | 'corporate_ib' | 'unknown';
  /** 税の扱い */
  taxTreatment: 'tax_included' | 'tax_excluded' | 'unknown';
  /** 補足 */
  note: string;
}

export interface TransferFeeRule {
  bankCode: string;
  /** 同行同支店 */
  sameBankSameBranch: TransferFeeBracket;
  /** 同行他支店 */
  sameBankOtherBranch: TransferFeeBracket;
  /** 他行宛 */
  otherBank: TransferFeeBracket;
  /** 出所 */
  provenance: TransferFeeProvenance;
}

/** 顧客が登録する手数料表 (これが正) */
export interface TransferFeeTable {
  /** 誰の契約か (画面表示用) */
  label: string;
  /** 顧客が取引銀行と約定した内容であることの確認日 */
  confirmedAt: string;
  rules: readonly TransferFeeRule[];
}

/** 画面・帳票へ必ず併記する注意書き */
export const TRANSFER_FEE_DISCLAIMER =
  '振込手数料は取引銀行・チャネル・契約内容により異なり、改定も頻繁に行われます。ここに表示している金額は参考値です。実際に請求・支払に用いる金額は必ず取引銀行にご確認のうえ、手数料マスタへご登録ください。';

/**
 * 参考値としてのみ保持する手数料 (**確定値ではない**)。
 *
 *   旧実装は「メガバンク振込手数料 (令和6年度参考値・税抜)」として
 *   0001 / 0005 / 0009 の 3 行分を保持していたが、
 *   一次情報 (銀行公表ページ) との突合で次の誤りが判明したため、
 *   出所メタデータ (provenance) を必須にしたうえで内容を是正した:
 *
 *   - 「税抜」と表記されていたが 484 / 495 は税込相当の数値であり、内部矛盾していた
 *   - 三菱UFJ銀行 (0005) の同行他支店は 110 / 220 とされていたが、
 *     公表値 (法人IB BizSTATION) は 110 / 330 だった
 *   - チャネル (窓口 / ATM / 個人IB / 法人IB) の区別が無かった。
 *     同じ銀行でも他行宛は 990円 (窓口) / 220円 (個人IB) / 660円 (法人IB) と大きく異なる
 *   - みずほ銀行 (0001) / 三井住友銀行 (0009) の値は出所が特定できなかったため
 *     verified: false とし、金額は旧実装からの引継ぎであることを明記した。
 *     特に三井住友銀行の EB サービスは金額区分によらない定額体系の商品があり、
 *     「3万円未満 / 3万円以上」というモデル自体が当てはまらない可能性がある。
 */
export const STANDARD_TRANSFER_FEES: readonly TransferFeeRule[] = [
  {
    bankCode: '0001',
    sameBankSameBranch: { underThreshold: 0, aboveThreshold: 0, thresholdYen: 30000 },
    sameBankOtherBranch: { underThreshold: 110, aboveThreshold: 220, thresholdYen: 30000 },
    otherBank: { underThreshold: 480, aboveThreshold: 660, thresholdYen: 30000 },
    provenance: {
      verified: false,
      sourceUrl: null,
      asOf: '不明 (旧実装は「令和6年度参考値・税抜」と記載していたが出所の記録なし)',
      channel: 'unknown',
      taxTreatment: 'unknown',
      note: 'みずほ銀行。一次情報未確認のため請求・支払には使用しないこと。最新値は https://www.mizuhobank.co.jp/rate_fee/fee_furikomi.html を参照。',
    },
  },
  {
    bankCode: '0005',
    sameBankSameBranch: { underThreshold: 0, aboveThreshold: 0, thresholdYen: 30000 },
    sameBankOtherBranch: { underThreshold: 110, aboveThreshold: 330, thresholdYen: 30000 },
    otherBank: { underThreshold: 484, aboveThreshold: 660, thresholdYen: 30000 },
    provenance: {
      verified: true,
      sourceUrl: 'https://www.bk.mufg.jp/tesuuryou/furikomi.html',
      asOf: '2023-10-02 適用 (2026-08-01 参照時点で当該ページに掲載)',
      channel: 'corporate_ib',
      taxTreatment: 'tax_included',
      note: '三菱UFJ銀行 法人向けインターネットバンキング BizSTATION の当行宛/他行宛。窓口・ATM・個人IB は別料金体系。',
    },
  },
  {
    bankCode: '0009',
    sameBankSameBranch: { underThreshold: 0, aboveThreshold: 0, thresholdYen: 30000 },
    sameBankOtherBranch: { underThreshold: 110, aboveThreshold: 220, thresholdYen: 30000 },
    otherBank: { underThreshold: 495, aboveThreshold: 660, thresholdYen: 30000 },
    provenance: {
      verified: false,
      sourceUrl: null,
      asOf: '不明 (旧実装からの引継ぎ)',
      channel: 'unknown',
      taxTreatment: 'unknown',
      note: '三井住友銀行。EBサービスの他行あて振込手数料は金額区分によらない定額体系の商品があり、本表の閾値モデル自体が当てはまらない可能性がある。最新値は https://www.smbc.co.jp/hojin/fee/furikomi.html を参照。',
    },
  },
] as const;

export interface TransferFeeInput {
  fromBankCode: string;
  fromBranchCode: string;
  toBankCode: string;
  toBranchCode: string;
  amountYen: number;
  /** 顧客が取引銀行と約定した手数料表。指定された場合はこちらが優先される */
  feeTable?: TransferFeeTable;
}

export interface TransferFeeEstimate {
  /** 手数料 (円)。根拠が無い場合は null (勝手な数値を作らない) */
  feeYen: number | null;
  /** 値の確からしさ */
  confidence: 'contracted' | 'reference_verified' | 'reference_unverified' | 'unknown';
  /** 適用した区分 */
  category: 'same_bank_same_branch' | 'same_bank_other_branch' | 'other_bank';
  /** 出所 */
  provenance: TransferFeeProvenance | null;
  /** 取引銀行への確認が必要か */
  requiresBankConfirmation: boolean;
  /** 画面・帳票へ併記する注意書き */
  disclaimer: string;
}

function pickBracket(rule: TransferFeeRule, input: TransferFeeInput): { bracket: TransferFeeBracket; category: TransferFeeEstimate['category'] } {
  const isSameBank = input.fromBankCode === input.toBankCode;
  const isSameBranch = isSameBank && input.fromBranchCode === input.toBranchCode;
  if (isSameBranch) return { bracket: rule.sameBankSameBranch, category: 'same_bank_same_branch' };
  if (isSameBank) return { bracket: rule.sameBankOtherBranch, category: 'same_bank_other_branch' };
  return { bracket: rule.otherBank, category: 'other_bank' };
}

/**
 * 振込手数料を「根拠つきで」求める。**推奨API**。
 *
 *   - 顧客登録の手数料表があればそれを使う (confidence = 'contracted')
 *   - 無ければ参考表を引くが、必ず requiresBankConfirmation = true を返す
 *   - 参考表にも無ければ **金額を作らず null を返す** (旧実装は 660 円を捏造していた)
 */
export function estimateTransferFee(input: TransferFeeInput): TransferFeeEstimate {
  const contracted = input.feeTable?.rules.find((r) => r.bankCode === input.fromBankCode);
  if (contracted) {
    const { bracket, category } = pickBracket(contracted, input);
    return {
      feeYen: input.amountYen >= bracket.thresholdYen ? bracket.aboveThreshold : bracket.underThreshold,
      confidence: 'contracted',
      category,
      provenance: contracted.provenance,
      requiresBankConfirmation: false,
      disclaimer: `手数料マスタ「${input.feeTable!.label}」(確認日 ${input.feeTable!.confirmedAt}) に登録された約定値です。`,
    };
  }

  const reference = STANDARD_TRANSFER_FEES.find((r) => r.bankCode === input.fromBankCode);
  if (!reference) {
    return {
      feeYen: null,
      confidence: 'unknown',
      category: input.fromBankCode === input.toBankCode ? (input.fromBranchCode === input.toBranchCode ? 'same_bank_same_branch' : 'same_bank_other_branch') : 'other_bank',
      provenance: null,
      requiresBankConfirmation: true,
      disclaimer: `金融機関コード ${input.fromBankCode} の手数料は登録されていません。${TRANSFER_FEE_DISCLAIMER}`,
    };
  }

  const { bracket, category } = pickBracket(reference, input);
  return {
    feeYen: input.amountYen >= bracket.thresholdYen ? bracket.aboveThreshold : bracket.underThreshold,
    confidence: reference.provenance.verified ? 'reference_verified' : 'reference_unverified',
    category,
    provenance: reference.provenance,
    requiresBankConfirmation: true,
    disclaimer: TRANSFER_FEE_DISCLAIMER,
  };
}

/**
 * 振込手数料を計算する。
 *
 * @deprecated 数値だけを返すため「参考値なのか約定値なのか」が呼び出し側に伝わらない。
 *   請求・支払に用いる場合は必ず {@link estimateTransferFee} を使うこと。
 *   旧実装は未登録の金融機関に対して 660 円という根拠のない値を返していたが、
 *   捏造値で請求が組まれる事故を防ぐため、本実装では例外を投げる (fail-closed)。
 */
export function calcTransferFee(input: TransferFeeInput): number {
  const estimate = estimateTransferFee(input);
  if (estimate.feeYen === null) {
    throw new Error(`金融機関コード ${input.fromBankCode} の振込手数料が登録されていません。${TRANSFER_FEE_DISCLAIMER}`);
  }
  return estimate.feeYen;
}

// ───────────────────────────────────────────────
// 反社チェック / AML-CFT
// ───────────────────────────────────────────────

export interface AMLCheckSubject {
  type: 'individual' | 'corporation';
  name: string;
  nameKana?: string;
  birthDate?: string; //  YYYY-MM-DD (個人時)
  corporateNumber?: string; //  13桁 (法人時)
  address?: string;
  /** 国籍 (個人時) */
  nationality?: string;
}

export interface AMLCheckResult {
  subject: AMLCheckSubject;
  riskScore: number; //  0-100 (高いほどリスク)
  hits: Array<{ list: 'antisocial' | 'fatf_high_risk' | 'sanction_japan' | 'sanction_un' | 'pep' | 'adverse_media'; reason: string; severity: 'high' | 'medium' | 'low' }>;
  recommendation: 'reject' | 'enhanced_due_diligence' | 'standard_due_diligence' | 'accept';
}

/**
 * 簡易反社・AMLチェック (本番ではJDD/RDC/世界銀行等の外部APIを呼び出す)
 *
 *   JFSA (金融庁) の主要対応:
 *   - 反社会的勢力データベース
 *   - FATF "高リスク国・地域" (北朝鮮 / イラン / ミャンマー)
 *   - 経済制裁対象 (財務省 外為法・テロ資金供与防止法)
 *   - PEPs (Politically Exposed Persons)
 */
export function checkAML(input: { subject: AMLCheckSubject; mockHits?: AMLCheckResult['hits'] }): AMLCheckResult {
  const hits = input.mockHits ?? [];
  const riskScore = hits.reduce((acc, h) => acc + (h.severity === 'high' ? 40 : h.severity === 'medium' ? 20 : 5), 0);
  const recommendation: AMLCheckResult['recommendation'] = riskScore >= 80 ? 'reject' : riskScore >= 40 ? 'enhanced_due_diligence' : riskScore >= 10 ? 'standard_due_diligence' : 'accept';
  return { subject: input.subject, riskScore: Math.min(100, riskScore), hits, recommendation };
}

// ───────────────────────────────────────────────
// 金商法対応 (有価証券・投資商品・適合性原則)
// ───────────────────────────────────────────────

export type InvestmentProductCategory =
  | 'stock' //  株式
  | 'bond' //  債券
  | 'investment_trust' //  投資信託
  | 'reit' //  REIT
  | 'derivative' //  デリバティブ
  | 'fx_margin' //  FX 証拠金取引
  | 'crypto_asset' //  暗号資産
  | 'structured_bond' //  仕組債
  | 'private_placement' //  私募ファンド
  | 'unlisted_equity'; //  未公開株

export interface InvestorProfile {
  age: number;
  /** 職業 */
  occupation: string;
  /** 年収 (円) */
  annualIncomeYen: number;
  /** 純金融資産 (円) */
  netFinancialAssetsYen: number;
  /** 投資経験 */
  investmentExperienceYears: number;
  /** リスク許容度 */
  riskTolerance: 'conservative' | 'moderate' | 'aggressive';
  /** 投資目的 */
  investmentObjective: 'capital_preservation' | 'income' | 'growth' | 'speculation';
}

export interface SuitabilityResult {
  product: InvestmentProductCategory;
  suitable: boolean;
  reason: string;
  warnings: string[];
}

/**
 * 適合性原則チェック (金商法第40条)
 *
 *   高齢者 (75歳以上) + 仕組債 / 暗号資産 / FX → 原則不適合 (75歳ルール)
 *   投資経験ゼロ + デリバティブ → 不適合
 *   年収 < 500万円 + 純資産 < 1000万円 + 私募ファンド → 不適合 (特定投資家以外への勧誘禁止)
 */
export function checkSuitability(input: { investor: InvestorProfile; product: InvestmentProductCategory }): SuitabilityResult {
  const { investor, product } = input;
  const warnings: string[] = [];

  if (investor.age >= 75 && (product === 'structured_bond' || product === 'crypto_asset' || product === 'fx_margin' || product === 'derivative')) {
    return { product, suitable: false, reason: '75歳以上の高齢者への高リスク商品勧誘は原則禁止 (金商法ガイドライン)', warnings: ['親族同席が必須', '社内承認(役席者)が必要'] };
  }

  if (investor.investmentExperienceYears < 1 && (product === 'derivative' || product === 'structured_bond' || product === 'fx_margin')) {
    return { product, suitable: false, reason: '投資経験不足のためデリバティブ商品は不適合', warnings: [] };
  }

  if (product === 'private_placement') {
    if (investor.netFinancialAssetsYen < 30_000_000) {
      return { product, suitable: false, reason: '私募ファンドは特定投資家 (純資産3000万円以上) への限定勧誘', warnings: [] };
    }
  }

  if (investor.riskTolerance === 'conservative' && (product === 'derivative' || product === 'crypto_asset' || product === 'fx_margin')) {
    warnings.push('リスク許容度が保守的なため、商品リスクを十分説明する必要あり');
  }

  if (investor.investmentObjective === 'capital_preservation' && product !== 'bond' && product !== 'investment_trust') {
    warnings.push('投資目的が元本保全のため、推奨商品との不一致を検討');
  }

  return { product, suitable: true, reason: '適合性チェック合格', warnings };
}

// ───────────────────────────────────────────────
// 金融機関セキュリティ (J-CSIP / 金融ISAC)
// ───────────────────────────────────────────────

/** 金融機関必須セキュリティコントロール */
export const FINANCIAL_SECURITY_CONTROLS = [
  { id: 'fisc-1', name: 'FISC安全対策基準 (技術基準)', description: '金融機関等コンピュータシステムの安全対策基準・解説書 第10版令和6年改訂版' },
  { id: 'jcsip', name: 'J-CSIP 金融分野', description: '金融分野におけるサイバー攻撃情報共有・分析' },
  { id: 'finance-isac', name: '金融ISAC', description: '日本の金融機関のサイバーセキュリティ協議体' },
  { id: 'cbest', name: 'CBEST型脅威ベース侵入テスト (TLPT)', description: '金融庁が義務化を進める脅威ベース侵入テスト' },
  { id: 'cyber-resilience', name: '金融分野におけるサイバーセキュリティ強化に向けた取組方針', description: '金融庁2024年版' },
] as const;

/** 暗号資産業務関連法 */
export const CRYPTO_ASSET_REGULATIONS = [
  { id: 'fundsettlement-2', name: '改正資金決済法 (令和元年改正)', description: '暗号資産交換業者の登録・分別管理・コールドウォレット95%義務化' },
  { id: 'fiea-amend', name: '改正金商法 (デリバティブ規制)', description: '暗号資産のデリバティブ取引を金商法の規制対象に' },
  { id: 'travel-rule', name: 'トラベルルール', description: 'FATF勧告に基づく送付者・受取人情報の通知義務 (10万円相当超)' },
  { id: 'jvcea-rules', name: 'JVCEA自主規制規則', description: '日本暗号資産取引業協会の自主規制規則' },
] as const;

// ───────────────────────────────────────────────
// 勘定科目体系 (会社法・企業会計原則)
// ───────────────────────────────────────────────

export const STANDARD_ACCOUNT_CODES = {
  assets: {
    current: ['現金', '当座預金', '普通預金', '定期預金', '受取手形', '売掛金', '電子記録債権', '有価証券', '商品', '製品', '仕掛品', '原材料', '前渡金', '前払費用', '未収収益', '短期貸付金', '仮払金', '立替金', '貸倒引当金'],
    fixed: ['建物', '建物附属設備', '構築物', '機械装置', '車両運搬具', '工具器具備品', '土地', '建設仮勘定', '無形固定資産 (ソフトウェア/特許権/商標権)', '投資有価証券', '関係会社株式', '長期貸付金', '繰延税金資産'],
  },
  liabilities: {
    current: ['支払手形', '買掛金', '電子記録債務', '短期借入金', '未払金', '未払費用', '前受金', '預り金', '前受収益', '仮受金', '未払法人税等', '未払消費税等', '賞与引当金'],
    fixed: ['長期借入金', '社債', '退職給付引当金', '繰延税金負債', '長期未払金', '資産除去債務'],
  },
  equity: ['資本金', '資本準備金', 'その他資本剰余金', '利益準備金', '別途積立金', '繰越利益剰余金', '自己株式', 'その他有価証券評価差額金'],
  income: ['売上高', '売上値引', '売上割戻'],
  costs: ['期首商品棚卸高', '当期商品仕入高', '期末商品棚卸高'],
  sga: ['給料手当', '法定福利費', '福利厚生費', '旅費交通費', '通信費', '消耗品費', '水道光熱費', '租税公課', '地代家賃', '保険料', '減価償却費', '貸倒損失', '雑費'],
  nonOp: ['受取利息', '受取配当金', '為替差益', '雑収入', '支払利息', '為替差損', '雑損失'],
  extraordinary: ['固定資産売却益', '投資有価証券売却益', '固定資産売却損', '災害損失', '減損損失'],
} as const;
