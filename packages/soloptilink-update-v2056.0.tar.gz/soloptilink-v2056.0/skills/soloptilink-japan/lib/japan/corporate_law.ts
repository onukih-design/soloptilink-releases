/**
 * SoloptiLinkAI Phase 24-FA — 会社法・商業登記・取締役会運営 (Corporate Law)
 *
 * 株式会社のガバナンス機関 (株主総会/取締役会/監査役) と商業登記の
 * 必須手続をコード化した支援モジュール。
 *
 * カバー範囲:
 *  - 株主総会 (定時/臨時) の招集通知 + 議題区分
 *  - 普通決議 / 特別決議 / 特殊決議 の判定
 *  - 取締役会の招集通知 + 定足数 + 決議
 *  - 商業登記事項 (本店移転/役員変更/募集株式発行 等の申請期限)
 *  - 株主名簿 + 議決権行使
 *  - 自己株式取得 (会社法155条/156条/160条/175条等)
 *  - 配当 (会社法453条) + 分配可能額の上限
 */

export type CompanyForm = "kk" | "godo" | "godo_kabushiki";

export interface CompanyProfile {
  company_name: string;
  form: CompanyForm;
  corporate_number?: string; // 法人番号13桁
  capital_yen: number;
  fiscal_year_end: string; // MM-DD
  is_listed: boolean;
  has_audit_committee: boolean;
  has_board_of_directors: boolean;
  number_of_directors: number;
}

// =====================
// 株主総会
// =====================

export type ShareholderMeetingKind = "regular" | "extraordinary";
export type ResolutionKind = "ordinary" | "special" | "exceptional"; // 普通/特別/特殊

export interface AgendaItem {
  no: number;
  title: string;
  resolution_kind: ResolutionKind;
  description?: string;
}

// 招集通知期限 (会社法299条)
//   公開会社/書面投票: 14日前まで (会社法299条1項)
//   非公開会社: 7日前まで (会社法299条1項括弧書き)
//   非公開会社+書面投票なし: 定款で7日を下回る期間に短縮可能 (例: 1日前)
const NOTIFICATION_DAYS_LISTED_PUBLIC = 14; // 上場/公開会社 14日
const NOTIFICATION_DAYS_NON_PUBLIC = 7; // 非公開会社 7日
const NOTIFICATION_DAYS_NON_PUBLIC_GODO = 1; // 同意で短縮可

export function calcMeetingNotificationDeadline(
  meetingDate: string,
  profile: CompanyProfile,
  withWrittenVoting: boolean = false,
): { deadline: string; required_days: number } {
  const days = profile.is_listed || withWrittenVoting
    ? NOTIFICATION_DAYS_LISTED_PUBLIC
    : NOTIFICATION_DAYS_NON_PUBLIC;
  const meeting = new Date(meetingDate);
  const deadline = new Date(meeting.getTime() - days * 24 * 60 * 60 * 1000);
  return { deadline: deadline.toISOString().slice(0, 10), required_days: days };
}

// 議題分類: 普通/特別/特殊決議
export const ORDINARY_RESOLUTIONS = [
  "計算書類の承認", // 438条
  "剰余金の配当", // 454条1項
  "役員報酬の決定", // 361条1項
  "取締役の選任", // 329条1項
  "監査役の選任",
  "会計監査人の選任",
];

export const SPECIAL_RESOLUTIONS = [
  "定款変更", // 466条
  "事業譲渡", // 467条
  "合併", // 783条
  "会社分割",
  "株式交換",
  "解散", // 471条1号
  "募集株式の発行(有利発行)", // 199条2項+201条
  "資本金の減少", // 447条
  "全部取得条項付株式の取得", // 171条
  "監査等委員会設置会社への移行",
  "種類株主総会の特別決議事項",
];

export const EXCEPTIONAL_RESOLUTIONS = [
  "公開会社→非公開会社への変更", // 466条/107条
  "種類株式の内容変更",
  "他人による株式買取請求への応諾",
];

export function classifyAgendaResolution(title: string): ResolutionKind {
  if (EXCEPTIONAL_RESOLUTIONS.some((r) => title.includes(r))) return "exceptional";
  if (SPECIAL_RESOLUTIONS.some((r) => title.includes(r))) return "special";
  return "ordinary";
}

// 決議要件
export interface ResolutionRequirement {
  kind: ResolutionKind;
  quorum: string;
  required_majority: string;
  legal_basis: string;
}

export const RESOLUTION_REQUIREMENTS: Record<ResolutionKind, ResolutionRequirement> = {
  ordinary: {
    kind: "ordinary",
    quorum: "議決権を行使できる株主の議決権の過半数 (定款で1/3以上に引下可、取締役選任は1/3未満不可)",
    required_majority: "出席株主の議決権の過半数",
    legal_basis: "会社法309条1項",
  },
  special: {
    kind: "special",
    quorum: "議決権を行使できる株主の議決権の過半数 (定款で1/3以上に引下可)",
    required_majority: "出席株主の議決権の2/3以上",
    legal_basis: "会社法309条2項",
  },
  exceptional: {
    kind: "exceptional",
    quorum: "総株主の半数以上 (頭数)",
    required_majority: "総株主の議決権の2/3以上",
    legal_basis: "会社法309条3項",
  },
};

export interface VoteCountInput {
  total_voting_rights: number; // 議決権総数
  attended_voting_rights: number; // 出席株主の議決権数
  for_votes: number; // 賛成
  against_votes: number; // 反対
  abstain_votes: number; // 棄権
}

export interface ResolutionResult {
  passed: boolean;
  quorum_met: boolean;
  majority_met: boolean;
  reason: string;
}

export function evaluateResolution(item: AgendaItem, vote: VoteCountInput): ResolutionResult {
  const req = RESOLUTION_REQUIREMENTS[item.resolution_kind];
  const quorumMet = vote.attended_voting_rights >= vote.total_voting_rights * 0.5;
  let majorityMet = false;
  if (item.resolution_kind === "ordinary") {
    majorityMet = vote.for_votes > vote.attended_voting_rights / 2;
  } else if (item.resolution_kind === "special") {
    majorityMet = vote.for_votes >= (vote.attended_voting_rights * 2) / 3;
  } else if (item.resolution_kind === "exceptional") {
    majorityMet = vote.for_votes >= (vote.total_voting_rights * 2) / 3;
  }
  return {
    passed: quorumMet && majorityMet,
    quorum_met: quorumMet,
    majority_met: majorityMet,
    reason: quorumMet && majorityMet
      ? `${req.legal_basis} 充足`
      : `定足数: ${quorumMet ? "OK" : "NG"} / 多数決: ${majorityMet ? "OK" : "NG"} (${req.required_majority})`,
  };
}

// =====================
// 取締役会
// =====================

export interface BoardMeetingInput {
  total_directors: number;
  attended_directors: number;
  for_votes: number;
  against_votes: number;
  abstain_votes: number;
  conflict_of_interest_directors: string[]; // 特別利害関係人 (369条2項)
}

export function evaluateBoardResolution(input: BoardMeetingInput): ResolutionResult {
  // 定足数: 議決に加わることができる取締役の過半数 (定款で加重可)
  const eligible = input.total_directors - input.conflict_of_interest_directors.length;
  const quorumMet = input.attended_directors >= eligible / 2;
  // 多数決: 出席取締役の過半数
  const majorityMet = input.for_votes > input.attended_directors / 2;
  return {
    passed: quorumMet && majorityMet,
    quorum_met: quorumMet,
    majority_met: majorityMet,
    reason: quorumMet && majorityMet
      ? "会社法369条1項 充足"
      : `定足数: ${quorumMet ? "OK" : "NG"} / 多数決: ${majorityMet ? "OK" : "NG"}`,
  };
}

// =====================
// 商業登記
// =====================

export type RegistrationKind =
  | "incorporation" // 設立
  | "head_office_relocation" // 本店移転
  | "officer_change" // 役員変更
  | "capital_increase" // 増資
  | "capital_decrease" // 減資
  | "objects_change" // 目的変更
  | "trade_name_change" // 商号変更
  | "share_split" // 株式分割
  | "issue_new_shares" // 募集株式の発行
  | "merger" // 合併
  | "company_split" // 会社分割
  | "dissolution"; // 解散

// 登記期限 (会社法915条/911条等)
export const REGISTRATION_DEADLINES_DAYS: Record<RegistrationKind, number> = {
  incorporation: 14, // 設立後2週間
  head_office_relocation: 14,
  officer_change: 14, // 変更後2週間
  capital_increase: 14, // 払込期日後2週間
  capital_decrease: 14,
  objects_change: 14,
  trade_name_change: 14,
  share_split: 14,
  issue_new_shares: 14,
  merger: 14, // 効力発生日後2週間
  company_split: 14,
  dissolution: 14,
};

export interface RegistrationDeadline {
  kind: RegistrationKind;
  effective_date: string;
  registration_deadline: string;
  days_remaining: number;
  overdue: boolean;
}

export function calcRegistrationDeadline(
  kind: RegistrationKind,
  effectiveDate: string,
  asOf: Date = new Date(),
): RegistrationDeadline {
  const days = REGISTRATION_DEADLINES_DAYS[kind];
  const eff = new Date(effectiveDate);
  const deadline = new Date(eff.getTime() + days * 24 * 60 * 60 * 1000);
  const remaining = Math.ceil((deadline.getTime() - asOf.getTime()) / (24 * 60 * 60 * 1000));
  return {
    kind,
    effective_date: effectiveDate,
    registration_deadline: deadline.toISOString().slice(0, 10),
    days_remaining: remaining,
    overdue: remaining < 0,
  };
}

// =====================
// 配当 (会社法453条/461条)
// =====================

export interface DividendCapacityInput {
  retained_earnings: number; // その他資本剰余金 + その他利益剰余金
  treasury_stock_book_value: number; // 自己株式の帳簿価額
  capital_reserve: number; // 資本準備金
  earned_reserve: number; // 利益準備金
  goodwill_capital_excess: number; // のれん等調整額の超過部分
}

export interface DividendCapacityResult {
  distributable_amount: number;
  reasoning: string[];
}

export function calcDistributableAmount(input: DividendCapacityInput): DividendCapacityResult {
  // 簡略式 (会社法461条 + 計算規則158条等の概念のみ):
  //   分配可能額 ≒ その他剰余金 - 自己株式 - のれん等調整超過額
  const reasoning: string[] = [];
  reasoning.push("会社法461条 + 計算規則158条 (簡略式)");
  const distributable = Math.max(
    0,
    input.retained_earnings -
      input.treasury_stock_book_value -
      input.goodwill_capital_excess,
  );
  reasoning.push(
    `その他剰余金 ${input.retained_earnings.toLocaleString()} - 自己株式 ${input.treasury_stock_book_value.toLocaleString()} - のれん超過 ${input.goodwill_capital_excess.toLocaleString()} = ${distributable.toLocaleString()}`,
  );
  return { distributable_amount: distributable, reasoning };
}

// =====================
// 株主名簿
// =====================

export interface ShareholderRecord {
  shareholder_id: string;
  name: string;
  address?: string;
  shares: number;
  acquired_date: string;
  is_beneficial_owner?: boolean; // 実質株主
}

export function calcVotingRights(
  shareholders: ShareholderRecord[],
  oneShareOneVote: boolean = true,
): { total: number; per_shareholder: { shareholder_id: string; rights: number }[] } {
  if (oneShareOneVote) {
    const per = shareholders.map((s) => ({ shareholder_id: s.shareholder_id, rights: s.shares }));
    return { total: per.reduce((a, b) => a + b.rights, 0), per_shareholder: per };
  }
  // 単元株制度: 1単元 = 100株 等 (簡略実装は省略)
  const per = shareholders.map((s) => ({ shareholder_id: s.shareholder_id, rights: Math.floor(s.shares / 100) }));
  return { total: per.reduce((a, b) => a + b.rights, 0), per_shareholder: per };
}

// 招集通知の雛形生成
export function buildMeetingNotification(input: {
  company: CompanyProfile;
  meeting_date: string;
  meeting_kind: ShareholderMeetingKind;
  agenda: AgendaItem[];
  venue: string;
  start_time: string;
}): string {
  const lines: string[] = [];
  lines.push(`株主各位`);
  lines.push("");
  lines.push(`${input.company.company_name}`);
  lines.push(`代表取締役`);
  lines.push("");
  lines.push(
    `第${input.meeting_kind === "regular" ? "" : "臨時"}株主総会招集ご通知`,
  );
  lines.push("");
  lines.push(`拝啓 平素は格別のご高配を賜り、厚く御礼申し上げます。`);
  lines.push(
    `当社${input.meeting_kind === "regular" ? "定時" : "臨時"}株主総会を下記のとおり開催いたしますので、ご出席くださいますようご通知申し上げます。`,
  );
  lines.push("");
  lines.push(`記`);
  lines.push("");
  lines.push(`1. 日時   ${input.meeting_date} ${input.start_time}`);
  lines.push(`2. 場所   ${input.venue}`);
  lines.push(`3. 議題`);
  for (const a of input.agenda) {
    const reqLabel = a.resolution_kind === "special" ? " (特別決議事項)" : a.resolution_kind === "exceptional" ? " (特殊決議事項)" : "";
    lines.push(`   第${a.no}号議案: ${a.title}${reqLabel}`);
  }
  lines.push("");
  lines.push(`敬具`);
  return lines.join("\n");
}
