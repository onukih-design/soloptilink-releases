/**
 * @fileoverview Phase 12 - 事業継続計画 (BCP) DNA
 *
 * 内閣府「事業継続ガイドライン」+ ISO 22301 + 日本特有のリスクシナリオ:
 *   - 地震 (首都直下/南海トラフ/各地震動予測)
 *   - 津波 (東日本大震災教訓・浸水想定区域)
 *   - 豪雨/洪水 (河川氾濫・内水)
 *   - 火山噴火 (富士山降灰想定)
 *   - 台風 (停電 + 通信途絶)
 *   - パンデミック (新型インフル等対策行動計画)
 *   - サイバー攻撃 (重要インフラ事案)
 *
 * RTO/RPO/MTPD 計算 + 重要業務優先順位付け + 代替拠点設計 + 訓練計画。
 */

// ============================================================================
// Types
// ============================================================================

export type DisasterScenario =
  | 'earthquake_metropolitan'   // 首都直下地震
  | 'earthquake_nankai'         // 南海トラフ巨大地震
  | 'earthquake_regional'       // 地域地震 (内陸活断層)
  | 'tsunami'                   // 津波
  | 'flood_river'               // 河川氾濫
  | 'flood_inland'              // 内水氾濫
  | 'volcano_eruption'          // 火山噴火 (降灰)
  | 'typhoon'                   // 台風
  | 'heavy_snow'                // 豪雪
  | 'pandemic'                  // パンデミック
  | 'cyber_attack'              // サイバー攻撃
  | 'power_outage_wide'         // 広域停電
  | 'supply_chain_disruption'   // サプライチェーン途絶
  | 'pandemic_employee'         // 社員多数感染
  | 'data_center_loss';         // データセンター喪失

export interface CriticalBusinessFunction {
  /** 重要業務 ID */
  id: string;
  /** 業務名 */
  name: string;
  /** 業務概要 */
  description: string;
  /** 復旧目標時間 (時間単位) */
  rtoHours: number;
  /** 復旧目標時点 (時間単位) */
  rpoHours: number;
  /** 最大許容停止時間 (時間単位) */
  mtpdHours: number;
  /** 優先度: 1=最重要 / 2=重要 / 3=通常 */
  priority: 1 | 2 | 3;
  /** 業務担当部門 */
  ownerDepartment: string;
  /** 依存システム */
  dependsOnSystems: string[];
  /** 依存外部サービス */
  dependsOnExternalServices: string[];
}

// ============================================================================
// 災害シナリオの想定影響度 (政府想定値・代表値)
// ============================================================================

export interface DisasterImpactProfile {
  scenario: DisasterScenario;
  /** 想定発生確率 (今後30年以内) */
  probability30yPct?: number;
  /** 推定死者数 */
  casualtiesEst?: number;
  /** 経済被害額 (兆円) */
  economicDamageTrillionYen?: number;
  /** 業務停止期間 (日) */
  downtimeDays: number;
  /** 通信途絶日数 */
  comDowntimeDays: number;
  /** 停電日数 */
  powerOutageDays: number;
  /** 主要対策 */
  mitigations: string[];
}

export const DISASTER_PROFILES: DisasterImpactProfile[] = [
  {
    scenario: 'earthquake_metropolitan',
    probability30yPct: 70,
    casualtiesEst: 23000,
    economicDamageTrillionYen: 95,
    downtimeDays: 30,
    comDowntimeDays: 7,
    powerOutageDays: 7,
    mitigations: ['代替拠点 (関西圏推奨)', '在宅勤務体制', '重要データの遠隔バックアップ', '従業員安否確認システム'],
  },
  {
    scenario: 'earthquake_nankai',
    probability30yPct: 80,
    casualtiesEst: 323000,
    economicDamageTrillionYen: 220,
    downtimeDays: 60,
    comDowntimeDays: 14,
    powerOutageDays: 14,
    mitigations: ['東日本に冗長拠点', '津波浸水域からの拠点移転', '燃料・食料の3日分備蓄'],
  },
  {
    scenario: 'tsunami',
    casualtiesEst: 200000,
    downtimeDays: 90,
    comDowntimeDays: 14,
    powerOutageDays: 14,
    mitigations: ['浸水想定区域からの移転', '高所避難経路の確保', '津波警報連動の自動データ退避'],
  },
  {
    scenario: 'pandemic',
    casualtiesEst: 64000,
    economicDamageTrillionYen: 30,
    downtimeDays: 60,
    comDowntimeDays: 0,
    powerOutageDays: 0,
    mitigations: ['全社在宅勤務体制', '感染症対策BCP発動基準明文化', '出社必要業務の特定と最小化'],
  },
  {
    scenario: 'cyber_attack',
    downtimeDays: 14,
    comDowntimeDays: 14,
    powerOutageDays: 0,
    mitigations: ['EDR/XDR導入', 'バックアップの3-2-1ルール', 'インシデント対応チーム (CSIRT)', '外部脅威インテリジェンス'],
  },
  {
    scenario: 'data_center_loss',
    downtimeDays: 7,
    comDowntimeDays: 7,
    powerOutageDays: 0,
    mitigations: ['マルチリージョン (Tokyo + Osaka)', 'マルチクラウド (AWS + Azure等)', 'コールドスタンバイの定期検証'],
  },
];

// ============================================================================
// RTO/RPO 評価 + 必要対策ギャップ分析
// ============================================================================

export interface RecoveryGapAnalysis {
  function: CriticalBusinessFunction;
  scenario: DisasterScenario;
  expectedDowntimeDays: number;
  expectedDowntimeHours: number;
  meetsRTO: boolean;
  rtoGapHours: number;
  recommendedMitigations: string[];
}

export function analyzeRecoveryGap(input: {
  function: CriticalBusinessFunction;
  scenario: DisasterScenario;
  profiles?: DisasterImpactProfile[];
}): RecoveryGapAnalysis {
  const profiles = input.profiles ?? DISASTER_PROFILES;
  const profile = profiles.find((p) => p.scenario === input.scenario);
  const downDays = profile?.downtimeDays ?? 0;
  const downHours = downDays * 24;
  const meets = downHours <= input.function.rtoHours;
  return {
    function: input.function,
    scenario: input.scenario,
    expectedDowntimeDays: downDays,
    expectedDowntimeHours: downHours,
    meetsRTO: meets,
    rtoGapHours: Math.max(0, downHours - input.function.rtoHours),
    recommendedMitigations: profile?.mitigations ?? [],
  };
}

// ============================================================================
// 安否確認 + 連絡網
// ============================================================================

export interface SafetyConfirmation {
  employeeId: string;
  employeeName: string;
  status: 'safe' | 'injured' | 'cannot_contact' | 'evacuated' | 'unknown';
  location?: string;
  contactedAt: string;
  comment?: string;
}

export function summarizeSafety(confirmations: SafetyConfirmation[]): {
  total: number;
  safe: number;
  injured: number;
  cannotContact: number;
  evacuated: number;
  unknown: number;
  responseRate: number;
} {
  const total = confirmations.length;
  const safe = confirmations.filter((c) => c.status === 'safe').length;
  const injured = confirmations.filter((c) => c.status === 'injured').length;
  const cannotContact = confirmations.filter((c) => c.status === 'cannot_contact').length;
  const evacuated = confirmations.filter((c) => c.status === 'evacuated').length;
  const unknown = confirmations.filter((c) => c.status === 'unknown').length;
  const responded = total - unknown;
  return {
    total,
    safe,
    injured,
    cannotContact,
    evacuated,
    unknown,
    responseRate: total === 0 ? 0 : Math.round((responded / total) * 1000) / 10,
  };
}

// ============================================================================
// BCP 訓練計画
// ============================================================================

export type DrillType = 'tabletop' | 'walkthrough' | 'functional' | 'fullscale';

export interface BcpDrillPlan {
  drillId: string;
  scenario: DisasterScenario;
  type: DrillType;
  scheduledDate: string;
  duration: string;
  participants: string[];
  objectives: string[];
  evaluationCriteria: string[];
}

export function suggestDrillFrequency(priority: 1 | 2 | 3, type: DrillType): { perYear: number } {
  // 優先度1の業務 + 全規模訓練 = 年1回最低
  const matrix: Record<DrillType, Record<1 | 2 | 3, number>> = {
    tabletop: { 1: 4, 2: 2, 3: 1 },
    walkthrough: { 1: 2, 2: 1, 3: 0.5 },
    functional: { 1: 2, 2: 1, 3: 0 },
    fullscale: { 1: 1, 2: 0.5, 3: 0 },
  };
  return { perYear: matrix[type][priority] };
}

// ============================================================================
// 内閣府・各省庁 BCP 関連リンク
// ============================================================================

export const BCP_REFS = {
  CABINET_OFFICE_GUIDELINE: 'https://www.bousai.go.jp/kyoiku/kigyou/keizoku/sk_03.html',
  ISO22301: 'https://www.iso.org/standard/75106.html',
  CHUUKIBO_BCP: 'https://www.chusho.meti.go.jp/bcp/',
  NISC_CRITICAL_INFRA: 'https://www.nisc.go.jp/active/infra/',
  PANDEMIC_PLAN: 'https://www.cas.go.jp/jp/seisaku/ful/keikaku.html',
};
