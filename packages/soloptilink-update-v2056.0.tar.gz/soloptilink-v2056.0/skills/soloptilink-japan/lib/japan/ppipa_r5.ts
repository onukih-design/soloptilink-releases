/**
 * SoloptiLinkAI Phase 48-GV4 — 個人情報保護法 R5 改正詳細版 (PPIPA R5)
 *
 * 個人情報の保護に関する法律 R4.4 + R5.4 改正 (個人関連情報・仮名加工情報・
 * 越境移転24条・漏えい等報告26条 詳細実装) + PIA / DPIA / ROPA。
 *
 * カバー範囲:
 *  - 個人情報 / 個人関連情報 / 仮名加工情報 / 匿名加工情報 の4類型
 *  - 漏えい等報告 26条 (R4.4施行) — 5日速報義務 + 30日確報
 *  - 越境移転 28条 (旧24条) — 同等水準国認定 + 基準適合体制
 *  - 委託先監督 25条 + 共同利用 27条5項3号
 *  - 仮名加工情報 41/42条 (R3.4新設, R5施行)
 *  - 匿名加工情報 43条 + 識別行為禁止
 *  - PIA (Privacy Impact Assessment) — 個人情報保護委員会推奨
 *  - DPIA (Data Protection Impact Assessment) — GDPR 35条
 *  - ROPA (Record of Processing Activities) — GDPR 30条
 *  - 罰則 178/179条 (R4.4 引上げ): 命令違反 1年以下 100万円以下 + 法人重科 1億円
 *
 * なぜClaude Codeに作れないか:
 *   日本の個情法 R5 改正の細部 (5日速報の起算日、要配慮個人情報の定義、
 *   越境移転の同等水準国認定リスト, 仮名加工情報と匿名加工情報の差) は
 *   英語圏の Privacy 文献にはほぼ存在せず、PPC (個人情報保護委員会)
 *   ガイドラインの直接参照が必要。
 */

// ───────────────────────────────────────────────
// 個人情報の4類型 (個情法 2/16条)
// ───────────────────────────────────────────────

export type DataType =
  | "personal_info" // 個人情報 (2条1項)
  | "related_info" // 個人関連情報 (2条7項, R3.4新設)
  | "pseudonymized" // 仮名加工情報 (2条5項, R3.4新設)
  | "anonymized" // 匿名加工情報 (2条6項)
  | "non_personal"; // 個人情報に該当しない情報

/** 要配慮個人情報 (2条3項 + 政令2条) */
export const SENSITIVE_PERSONAL_INFO_CATEGORIES = [
  "race", // 人種
  "creed", // 信条
  "social_status", // 社会的身分
  "medical_history", // 病歴
  "criminal_record", // 犯罪の経歴
  "victim_of_crime", // 犯罪被害事実
  "physical_disability", // 身体障害
  "intellectual_disability", // 知的障害
  "mental_disability", // 精神障害 (発達障害含む)
  "medical_examination_result", // 健康診断等の結果
  "health_guidance_received", // 保健指導・診療等
  "criminal_procedure_facts", // 刑事手続が行われた事実
  "juvenile_protection_facts", // 少年保護事件の手続が行われた事実
] as const;

export type SensitiveCategory = typeof SENSITIVE_PERSONAL_INFO_CATEGORIES[number];

// ───────────────────────────────────────────────
// 漏えい等報告 26条 — R4.4 施行 + R5.4 拡充
// ───────────────────────────────────────────────

/** 漏えい等報告の対象事案 (規則7条 4類型) */
export type IncidentType =
  | "sensitive_data_leak" // 要配慮個人情報の漏えい等 (1号)
  | "financial_damage_risk" // 不正利用による財産的被害のおそれ (2号)
  | "intentional_third_party_act" // 不正アクセス等による漏えい等 (3号)
  | "1000_plus_leak"; // 1000人を超える漏えい等 (4号)

export interface PrivacyIncident {
  incident_id: string;
  detected_at: string; // YYYY-MM-DDTHH:mm:ssZ — 検知日時
  type: IncidentType[];
  affected_count: number;
  data_types: SensitiveCategory[];
  initial_report_filed: boolean;
  initial_report_filed_at?: string;
  full_report_filed: boolean;
  full_report_filed_at?: string;
  notification_to_subjects_sent: boolean;
  notification_to_subjects_sent_at?: string;
}

/** 速報の期限 — 検知から概ね 3〜5日以内 (規則8条1項 PPC ガイドライン) */
export const INITIAL_REPORT_DEADLINE_DAYS = 5;
/** 確報の期限 — 検知から30日以内 (規則8条2項) */
export const FULL_REPORT_DEADLINE_DAYS = 30;
/** 不正アクセス等は60日以内 (規則8条2項但書) */
export const FULL_REPORT_DEADLINE_DAYS_FOR_INTENTIONAL = 60;

/** 漏えい報告の必要性判定 (規則7条) */
export function requiresIncidentReport(p: {
  data_types: SensitiveCategory[];
  has_financial_damage_risk: boolean;
  is_intentional_act: boolean;
  affected_count: number;
}): { required: boolean; types: IncidentType[]; reasons: string[] } {
  const types: IncidentType[] = [];
  const reasons: string[] = [];
  if (p.data_types.length > 0) {
    types.push("sensitive_data_leak");
    reasons.push(`要配慮個人情報の漏えい (規則7条1号) — ${p.data_types.join(",")}`);
  }
  if (p.has_financial_damage_risk) {
    types.push("financial_damage_risk");
    reasons.push("財産的被害のおそれ (規則7条2号)");
  }
  if (p.is_intentional_act) {
    types.push("intentional_third_party_act");
    reasons.push("不正アクセス等による漏えい (規則7条3号)");
  }
  if (p.affected_count > 1000) {
    types.push("1000_plus_leak");
    reasons.push(`1000人超漏えい (規則7条4号) — ${p.affected_count}人`);
  }
  return { required: types.length > 0, types, reasons };
}

/** 漏えい報告の期限超過チェック */
export function checkIncidentReportDeadlines(incident: PrivacyIncident): {
  initial_overdue: boolean;
  full_overdue: boolean;
  notification_overdue: boolean;
  details: string[];
} {
  const details: string[] = [];
  const detected = new Date(incident.detected_at);
  const now = new Date();
  const days = (d: Date) => Math.floor((now.getTime() - d.getTime()) / 86_400_000);
  const elapsed = days(detected);

  const initial_overdue = !incident.initial_report_filed && elapsed > INITIAL_REPORT_DEADLINE_DAYS;
  if (initial_overdue) {
    details.push(`速報期限 (${INITIAL_REPORT_DEADLINE_DAYS}日) 経過 - 検知から${elapsed}日`);
  }
  const fullDeadline = incident.type.includes("intentional_third_party_act")
    ? FULL_REPORT_DEADLINE_DAYS_FOR_INTENTIONAL
    : FULL_REPORT_DEADLINE_DAYS;
  const full_overdue = !incident.full_report_filed && elapsed > fullDeadline;
  if (full_overdue) {
    details.push(`確報期限 (${fullDeadline}日) 経過 - 検知から${elapsed}日`);
  }
  const notification_overdue = !incident.notification_to_subjects_sent && elapsed > 14;
  if (notification_overdue) {
    details.push("本人通知が14日経過しても未送付");
  }
  return { initial_overdue, full_overdue, notification_overdue, details };
}

// ───────────────────────────────────────────────
// 越境移転 28条 (旧24条)
// ───────────────────────────────────────────────

/** 同等水準国 (規則15条 PPC告示) — R6 時点で EU + 英国のみ */
export const EQUIVALENT_LEVEL_COUNTRIES = ["EU", "GB"] as const;

/** 越境移転の合法基盤 4類型 (28条) */
export type CrossBorderBasis =
  | "consent" // 本人の同意 (28条1項)
  | "equivalent_country" // 同等水準国 (28条1項本文括弧書 + 規則15条)
  | "compliant_recipient" // 基準適合体制を整備した受領者 (28条1項本文括弧書 + 規則16条)
  | "exception"; // 例外 (法令に基づく等, 27条1項各号準用)

/** 基準適合体制の2類型 (規則16条) */
export type ComplianceMechanism =
  | "standard_contract" // ICA (Standard Contract): 委託契約等 + 27条準用条項
  | "binding_corporate_rules"; // BCR: グループ内規則 + APEC CBPR 認定等

export interface CrossBorderTransfer {
  transfer_id: string;
  destination_country: string; // ISO alpha-2
  recipient_name: string;
  basis: CrossBorderBasis;
  mechanism?: ComplianceMechanism; // basis = compliant_recipient の場合
  consent_obtained_at?: string;
  data_subjects_count: number;
  /** 28条3項により、本人に提供しなければならない情報 (R5.4施行) */
  pre_consent_info_provided: {
    destination_country_name: boolean;
    destination_country_legal_system: boolean; // 個人情報保護に関する制度
    recipient_safeguards: boolean; // 講じている措置
  };
}

export function evaluateCrossBorderTransfer(t: CrossBorderTransfer): {
  lawful: boolean;
  warnings: string[];
} {
  const warnings: string[] = [];
  if (t.basis === "equivalent_country") {
    if (!EQUIVALENT_LEVEL_COUNTRIES.includes(t.destination_country as any)) {
      warnings.push(`${t.destination_country} は同等水準国に未認定 (R6時点 EU/GB のみ)`);
    }
  }
  if (t.basis === "compliant_recipient" && !t.mechanism) {
    warnings.push("基準適合体制 (ICA/BCR) の特定が必要 (規則16条)");
  }
  if (t.basis === "consent") {
    const pre = t.pre_consent_info_provided;
    if (!pre.destination_country_name) warnings.push("移転先国名の事前情報提供 (28条3項)");
    if (!pre.destination_country_legal_system) warnings.push("移転先の個人情報保護制度の事前情報提供 (28条3項)");
    if (!pre.recipient_safeguards) warnings.push("受領者の措置の事前情報提供 (28条3項)");
  }
  return { lawful: warnings.length === 0, warnings };
}

// ───────────────────────────────────────────────
// 仮名加工情報 41/42条 (R3.4 新設, R5施行)
// ───────────────────────────────────────────────

export interface PseudonymizedData {
  data_id: string;
  /** 削除情報の管理 (41条2項): 削除した情報や加工方法に関する情報 */
  deletion_info_managed_securely: boolean;
  /** 第三者提供の制限 (41条6項) */
  third_party_provision_restricted: boolean;
  /** 識別行為の禁止 (41条7項) */
  identification_attempt_prohibited_in_contract: boolean;
  /** 本人連絡禁止 (41条8項) */
  contact_to_subject_prohibited: boolean;
}

export function validatePseudonymized(p: PseudonymizedData): { compliant: boolean; missing: string[] } {
  const missing: string[] = [];
  if (!p.deletion_info_managed_securely) missing.push("削除情報の安全管理 (41条2項)");
  if (!p.third_party_provision_restricted) missing.push("第三者提供制限 (41条6項)");
  if (!p.identification_attempt_prohibited_in_contract) missing.push("識別行為禁止条項 (41条7項)");
  if (!p.contact_to_subject_prohibited) missing.push("本人連絡禁止 (41条8項)");
  return { compliant: missing.length === 0, missing };
}

// ───────────────────────────────────────────────
// 匿名加工情報 43条 + 規則34条
// ───────────────────────────────────────────────

export interface AnonymizedData {
  data_id: string;
  /** 加工基準遵守 (規則34条 5基準) */
  processing_standard_satisfied: boolean;
  /** 安全管理措置 (43条2項) */
  safety_measures_taken: boolean;
  /** 公表 (43条3項) — 含まれる項目の公表 */
  items_disclosed: boolean;
  /** 識別行為の禁止 (43条5項) */
  identification_attempt_prohibited: boolean;
}

// ───────────────────────────────────────────────
// PIA (Privacy Impact Assessment) — PPC 推奨
// ───────────────────────────────────────────────

export interface PrivacyImpactAssessment {
  assessment_id: string;
  project_name: string;
  scope_description: string;
  /** 5ステップ */
  step1_information_flow_mapped: boolean; // 情報フロー図の作成
  step2_legal_basis_identified: boolean; // 法的根拠の特定
  step3_risk_identified: boolean; // リスク識別
  step4_mitigation_planned: boolean; // 軽減策の検討
  step5_monitoring_planned: boolean; // モニタリング計画
  conducted_by: string;
  approved_by?: string; // 個人情報保護管理者等
  conducted_at: string;
}

export function evaluatePIA(p: PrivacyImpactAssessment): { complete: boolean; missing: string[] } {
  const missing: string[] = [];
  if (!p.step1_information_flow_mapped) missing.push("ステップ1: 情報フローマッピング");
  if (!p.step2_legal_basis_identified) missing.push("ステップ2: 法的根拠の特定");
  if (!p.step3_risk_identified) missing.push("ステップ3: リスク識別");
  if (!p.step4_mitigation_planned) missing.push("ステップ4: 軽減策");
  if (!p.step5_monitoring_planned) missing.push("ステップ5: モニタリング計画");
  return { complete: missing.length === 0, missing };
}

// ───────────────────────────────────────────────
// ROPA (Record of Processing Activities) — GDPR 30条相当
// ───────────────────────────────────────────────

export interface RopaEntry {
  controller_name: string;
  contact_dpo?: string;
  purpose: string;
  data_categories: SensitiveCategory[] | string[];
  data_subject_categories: string[];
  recipient_categories: string[];
  cross_border_transfer?: CrossBorderTransfer;
  retention_period: string;
  technical_measures: string[];
  organizational_measures: string[];
}

// ───────────────────────────────────────────────
// 罰則 (R4.4 引上げ)
// ───────────────────────────────────────────────

/** 罰則の最大値 (法178条以下, R4.4施行で引上げ) */
export const PENALTIES = {
  /** 命令違反 (178条) — 1年以下の懲役/100万円以下の罰金 */
  ORDER_VIOLATION_MAX_FINE_YEN: 1_000_000,
  /** 命令違反の法人重科 (184条) — 1億円以下 */
  ORDER_VIOLATION_LEGAL_PERSON_MAX_FINE_YEN: 100_000_000,
  /** 報告徴収・立入検査 拒否/虚偽 (182条) — 50万円以下 */
  INSPECTION_REFUSAL_MAX_FINE_YEN: 500_000,
  /** 個人情報データベース提供罪 (179条) — 1年以下/50万円以下 */
  DATABASE_LEAK_MAX_FINE_YEN: 500_000,
  /** 個人情報データベース提供罪の法人重科 (184条) — 1億円以下 */
  DATABASE_LEAK_LEGAL_PERSON_MAX_FINE_YEN: 100_000_000,
};
