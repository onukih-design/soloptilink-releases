/**
 * SoloptiLinkAI Phase 49-GV5 — 独占禁止法 + 下請法 + 不正競争防止法 + フリーランス保護新法
 *
 * 私的独占の禁止及び公正取引の確保に関する法律 (独禁法) +
 * 下請代金支払遅延等防止法 (下請法) +
 * 不正競争防止法 (不競法) +
 * フリーランス・事業者間取引適正化等法 (R6.11.1 施行)
 *
 * カバー範囲:
 *  - 独禁法: 私的独占3条 / 不当な取引制限3条 / 不公正な取引方法19条 (16類型)
 *  - 課徴金 7条の2 (S52年導入 + R元改正で繰り返し違反加算25%)
 *  - 課徴金減免制度 (リーニエンシー) 7条の4 (1番目100% / 2-5番目段階, R元改正)
 *  - 企業結合審査 15-2条 (届出基準: 国内売上合計200億+50億超)
 *  - 確約手続 H30導入
 *  - 下請法: 親事業者の義務4類型 (3-5条) + 禁止11類型 (4条) + 60日支払
 *  - 不競法: 営業秘密3要件 + 限定提供データ (R元改正) + 形態模倣3年保護
 *  - フリーランス新法 R6.11: 書面交付義務 + 60日支払 + 7類型禁止 + ハラスメント防止
 *
 * なぜClaude Codeに作れないか:
 *   日本の下請法 11類型 + 60日支払ルール + 不競法 営業秘密3要件 + フリーランス新法は
 *   日本独自の法制度。特にフリーランス新法 (R6.11.1施行) は最新でClaude Codeの
 *   学習データに存在しない。
 */

// ───────────────────────────────────────────────
// 独占禁止法 — 違反類型
// ───────────────────────────────────────────────

export type AntitrustViolation =
  | "private_monopolization" // 私的独占 (3条前段)
  | "unreasonable_restraint" // 不当な取引制限 (3条後段) = カルテル/談合
  | "international_unreasonable_restraint" // 国際的協定 (6条)
  | "unfair_trade_practice"; // 不公正な取引方法 (19条)

/** 不公正な取引方法 16類型 (一般指定 + 法定5類型) */
export const UNFAIR_TRADE_PRACTICES = [
  // 法定5類型 (2条9項)
  { no: 1, name: "共同の取引拒絶", category: "boycott" },
  { no: 2, name: "差別対価", category: "discriminatory_pricing" },
  { no: 3, name: "不当廉売", category: "predatory_pricing" },
  { no: 4, name: "再販売価格の拘束", category: "rpm" },
  { no: 5, name: "優越的地位の濫用", category: "superior_position" },
  // 一般指定 (公取委告示)
  { no: 6, name: "共同の取引拒絶 (一般)", category: "boycott_general" },
  { no: 7, name: "その他の取引拒絶", category: "other_refusal" },
  { no: 8, name: "差別対価 (一般)", category: "discriminatory_pricing_general" },
  { no: 9, name: "取引条件等の差別取扱い", category: "discriminatory_terms" },
  { no: 10, name: "事業者団体における差別取扱い", category: "trade_assoc_discrimination" },
  { no: 11, name: "不当廉売 (一般)", category: "predatory_pricing_general" },
  { no: 12, name: "不当高価購入", category: "unfair_purchase" },
  { no: 13, name: "ぎまん的顧客誘引", category: "deceptive_solicitation" },
  { no: 14, name: "不当な利益による顧客誘引", category: "inducement_by_benefits" },
  { no: 15, name: "抱き合わせ販売等", category: "tying" },
  { no: 16, name: "排他条件付取引", category: "exclusive_dealing" },
] as const;

// ───────────────────────────────────────────────
// 課徴金 (7条の2) + リーニエンシー (7条の4)
// ───────────────────────────────────────────────

/** 課徴金算定基礎 = 違反対象期間中の売上 (最長10年) */
export const SURCHARGE_LOOKBACK_YEARS_MAX = 10;

/** 業種別 課徴金率 (R元改正 7条の2) */
export const SURCHARGE_RATES: Record<string, number> = {
  default: 0.10, // 製造業等 10%
  retail: 0.03, // 小売業 3%
  wholesale: 0.02, // 卸売業 2%
  small_medium_default: 0.04, // 中小事業者 4%
  small_medium_retail: 0.012, // 中小小売 1.2%
  small_medium_wholesale: 0.01, // 中小卸売 1%
};

/** 加算: 繰り返し違反 +50% (10年内再犯) / 主導的役割 +50% — R元改正で重畳適用可能 */
export const SURCHARGE_REPEAT_OFFENDER_ADDITION = 0.5;
export const SURCHARGE_LEADER_ROLE_ADDITION = 0.5;
/** 早期離脱: -20% / 早期協力: -10% (R元改正) */
export const SURCHARGE_EARLY_EXIT_REDUCTION = 0.2;

/** リーニエンシー減免率 (7条の4 + R元改正) */
export const LENIENCY_REDUCTION_RATES = [
  { rank: 1, reduction: 1.0, condition: "立入検査前1番目" }, // 100%免除
  { rank: 2, reduction: 0.20, condition: "立入検査前2番目" }, // 20% (旧 50%)
  { rank: 3, reduction: 0.10, condition: "立入検査前3-5番目 (3番目以降)" }, // 10%
  { rank: 4, reduction: 0.10, condition: "立入検査前3-5番目 (4番目)" },
  { rank: 5, reduction: 0.10, condition: "立入検査前3-5番目 (5番目)" },
  { rank: 6, reduction: 0.05, condition: "立入検査後 (最大3社まで)" }, // 5%
];

/** 協力減算 (R元改正で別途最大40%) */
export const COOPERATION_REDUCTION_MAX = 0.40;

export function calcSurcharge(p: {
  affected_revenue_yen: number;
  industry: keyof typeof SURCHARGE_RATES;
  is_small_medium: boolean;
  is_repeat_offender: boolean;
  is_leader: boolean;
  leniency_rank?: 1 | 2 | 3 | 4 | 5 | 6;
  cooperation_reduction_rate?: number;
}): { surcharge_yen: number; breakdown: string[] } {
  const breakdown: string[] = [];
  const rateKey = p.is_small_medium ? `small_medium_${p.industry}` : p.industry;
  let rate = SURCHARGE_RATES[rateKey] ?? SURCHARGE_RATES.default;
  breakdown.push(`基本課徴金率: ${(rate * 100).toFixed(1)}% (${rateKey})`);
  if (p.is_repeat_offender) {
    rate *= 1 + SURCHARGE_REPEAT_OFFENDER_ADDITION;
    breakdown.push(`繰り返し違反 +50% → ${(rate * 100).toFixed(2)}%`);
  }
  if (p.is_leader) {
    rate *= 1 + SURCHARGE_LEADER_ROLE_ADDITION;
    breakdown.push(`主導的役割 +50% → ${(rate * 100).toFixed(2)}%`);
  }
  let surcharge = p.affected_revenue_yen * rate;
  breakdown.push(`課徴金 (基本) = ${surcharge.toLocaleString()} 円`);
  if (p.leniency_rank) {
    const r = LENIENCY_REDUCTION_RATES.find((x) => x.rank === p.leniency_rank);
    if (r) {
      surcharge *= 1 - r.reduction;
      breakdown.push(`リーニエンシー${p.leniency_rank}位 ${(r.reduction * 100).toFixed(0)}%減免 → ${surcharge.toLocaleString()} 円`);
    }
  }
  if (p.cooperation_reduction_rate) {
    const reduce = Math.min(p.cooperation_reduction_rate, COOPERATION_REDUCTION_MAX);
    surcharge *= 1 - reduce;
    breakdown.push(`協力減算 ${(reduce * 100).toFixed(0)}% → ${surcharge.toLocaleString()} 円`);
  }
  return { surcharge_yen: Math.floor(surcharge), breakdown };
}

// ───────────────────────────────────────────────
// 企業結合審査 — 届出基準 (15条の2 + 規則)
// ───────────────────────────────────────────────

/** 株式取得の届出基準 (10条2項) */
export const SHARE_ACQUISITION_NOTIFICATION_THRESHOLD = {
  /** 取得会社の国内売上合計が 200億円超 */
  acquirer_domestic_revenue_yen: 20_000_000_000,
  /** 被取得会社の国内売上合計が 50億円超 */
  target_domestic_revenue_yen: 5_000_000_000,
  /** かつ取得後の議決権比率が 20%/50% を超える */
  voting_ratios_to_check: [0.20, 0.50],
};

export function requiresMergerFiling(p: {
  acquirer_revenue_yen: number;
  target_revenue_yen: number;
  voting_ratio_after: number;
}): { required: boolean; reasons: string[] } {
  const reasons: string[] = [];
  const t = SHARE_ACQUISITION_NOTIFICATION_THRESHOLD;
  if (p.acquirer_revenue_yen <= t.acquirer_domestic_revenue_yen) {
    return { required: false, reasons: ["取得会社の国内売上が200億円以下"] };
  }
  if (p.target_revenue_yen <= t.target_domestic_revenue_yen) {
    return { required: false, reasons: ["被取得会社の国内売上が50億円以下"] };
  }
  const matched = t.voting_ratios_to_check.find((r) => p.voting_ratio_after > r);
  if (!matched) {
    return { required: false, reasons: ["20%/50%閾値超えなし"] };
  }
  reasons.push(`売上要件OK + 議決権比率 ${(p.voting_ratio_after * 100).toFixed(1)}% > ${(matched * 100).toFixed(0)}%`);
  return { required: true, reasons };
}

// ───────────────────────────────────────────────
// 下請代金支払遅延等防止法 (下請法)
// ───────────────────────────────────────────────

/** 親事業者の義務4類型 (3-5条) */
export const PRIME_CONTRACTOR_DUTIES = [
  "書面交付義務 (3条)",
  "支払期日決定義務 (2条の2) — 物品等の受領日から60日以内",
  "書類作成・保存義務 (5条) — 2年間保存",
  "遅延利息支払義務 (4条の2) — 年14.6%",
] as const;

/** 親事業者の禁止行為 11類型 (4条) */
export const PRIME_CONTRACTOR_PROHIBITIONS = [
  { no: 1, name: "受領拒否", article: "4条1項1号" },
  { no: 2, name: "下請代金の支払遅延", article: "4条1項2号" },
  { no: 3, name: "下請代金の減額", article: "4条1項3号" },
  { no: 4, name: "返品", article: "4条1項4号" },
  { no: 5, name: "買いたたき", article: "4条1項5号" },
  { no: 6, name: "購入・利用強制", article: "4条1項6号" },
  { no: 7, name: "報復措置", article: "4条1項7号" },
  { no: 8, name: "有償支給原材料等の対価の早期決済", article: "4条2項1号" },
  { no: 9, name: "割引困難な手形の交付", article: "4条2項2号" },
  { no: 10, name: "不当な経済上の利益の提供要請", article: "4条2項3号" },
  { no: 11, name: "不当な給付内容の変更・やり直し", article: "4条2項4号" },
] as const;

/** 下請法の支払期日 (受領日から60日以内) */
export const SUBCONTRACT_PAYMENT_DEADLINE_DAYS = 60;
/** 遅延利息 年14.6% (4条の2 + 規則) */
export const SUBCONTRACT_LATE_PAYMENT_INTEREST_RATE = 0.146;

export function calcLatePaymentInterest(p: {
  amount_yen: number;
  delivery_date: string;
  payment_due_date?: string;
  actual_payment_date: string;
}): { interest_yen: number; days_overdue: number; due_date: Date } {
  const delivery = new Date(p.delivery_date);
  const due = p.payment_due_date
    ? new Date(p.payment_due_date)
    : new Date(delivery.getTime() + SUBCONTRACT_PAYMENT_DEADLINE_DAYS * 86_400_000);
  const actual = new Date(p.actual_payment_date);
  const daysOverdue = Math.max(
    0,
    Math.floor((actual.getTime() - due.getTime()) / 86_400_000),
  );
  const interest = (p.amount_yen * SUBCONTRACT_LATE_PAYMENT_INTEREST_RATE * daysOverdue) / 365;
  return { interest_yen: Math.floor(interest), days_overdue: daysOverdue, due_date: due };
}

// ───────────────────────────────────────────────
// 不正競争防止法 (不競法) — 営業秘密 + 形態模倣 + 限定提供データ
// ───────────────────────────────────────────────

export type UnfairCompetitionType =
  | "well_known_indication" // 1号: 周知商品等表示混同惹起
  | "famous_indication" // 2号: 著名商品等表示冒用
  | "form_imitation" // 3号: 商品形態模倣 (3年間保護)
  | "trade_secret_acquisition" // 4号: 営業秘密の不正取得
  | "trade_secret_use_disclosure" // 5-9号: 営業秘密の使用/開示
  | "limited_data_acquisition" // 11-16号: 限定提供データ (R元改正)
  | "tech_protection_circumvention" // 17/18号: 技術的制限手段の効果妨害
  | "domain_squatting" // 19号: ドメイン名不正取得
  | "false_indication" // 20号: 商品/役務の品質誤認表示
  | "credit_damage" // 21号: 競争関係にある他人の営業上の信用毀損
  | "agent_misuse"; // 22号: 代理人等による商標冒用

/** 営業秘密の3要件 (2条6項) */
export interface TradeSecret {
  /** 秘密管理性: 秘密として管理されていること */
  secrecy_managed: boolean;
  /** 有用性: 事業活動に有用な技術上又は営業上の情報 */
  usefulness: boolean;
  /** 非公知性: 公然と知られていないこと */
  non_public: boolean;
  /** アクセス制御 (例): パスワード/権限/秘密表示 */
  access_controls: string[];
  /** 秘密表示 (㊙ マーク等) */
  marked_as_secret: boolean;
}

export function isTradeSecret(t: TradeSecret): { qualifies: boolean; missing: string[] } {
  const missing: string[] = [];
  if (!t.secrecy_managed) missing.push("秘密管理性 (アクセス制御 + 秘密表示)");
  if (!t.usefulness) missing.push("有用性 (事業上有用な情報)");
  if (!t.non_public) missing.push("非公知性 (公然と知られていない)");
  if (t.secrecy_managed && t.access_controls.length === 0) {
    missing.push("秘密管理性の具体的措置 (アクセス制御の例)");
  }
  return { qualifies: missing.length === 0, missing };
}

/** 形態模倣の保護期間 (2条1項3号) — 日本国内で最初に販売されてから3年 */
export const FORM_IMITATION_PROTECTION_YEARS = 3;

/** 不競法 損害額推定 (5条) — 譲渡数量 × 単位利益 */
export interface DamageEstimation {
  infringer_sold_units: number;
  legitimate_unit_profit_yen: number;
  legitimate_capacity_units?: number; // 事情がある場合上限
}

export function estimateUnfairCompetitionDamage(d: DamageEstimation): {
  damage_yen: number;
  formula: string;
} {
  const units = d.legitimate_capacity_units != null
    ? Math.min(d.infringer_sold_units, d.legitimate_capacity_units)
    : d.infringer_sold_units;
  const damage = units * d.legitimate_unit_profit_yen;
  return {
    damage_yen: damage,
    formula: `${units}単位 × ${d.legitimate_unit_profit_yen.toLocaleString()}円 = ${damage.toLocaleString()}円 (5条1項)`,
  };
}

// ───────────────────────────────────────────────
// フリーランス・事業者間取引適正化等法 (R6.11.1 施行)
// ───────────────────────────────────────────────

/** フリーランス新法 施行日 — R6.11.1 */
export const FREELANCE_LAW_EFFECTIVE_DATE = "2024-11-01";

/** 7類型禁止行為 (法5条) */
export const FREELANCE_LAW_PROHIBITIONS = [
  "受領拒否 (5条1項1号)",
  "報酬の減額 (5条1項2号)",
  "返品 (5条1項3号)",
  "買いたたき (5条1項4号)",
  "購入・利用強制 (5条1項5号)",
  "不当な経済上の利益の提供要請 (5条2項1号)",
  "不当な給付内容の変更・やり直し (5条2項2号)",
] as const;

/** 60日以内支払 (法4条1項) */
export const FREELANCE_PAYMENT_DEADLINE_DAYS = 60;

/** 書面 (電磁的方法を含む) 交付義務 — 法3条1項12項目 */
export const FREELANCE_REQUIRED_DISCLOSURE_ITEMS = [
  "業務委託事業者の氏名又は名称",
  "特定受託事業者の氏名又は名称",
  "業務委託の期間",
  "給付の内容",
  "給付を受領する期日",
  "給付を受領する場所",
  "検査をする場合は検査完了期日",
  "報酬の額",
  "支払期日",
  "現金以外の方法で支払う場合の事項",
  "電子記録債権で支払う場合の事項",
  "ファクタリング等で支払う場合の事項",
] as const;

export interface FreelanceContract {
  contract_id: string;
  client_type: "specified_business" | "individual_freelance";
  freelance_id: string;
  agreed_amount_yen: number;
  delivery_due_date: string;
  payment_due_date: string;
  written_disclosure_provided: boolean;
  has_employees: boolean; // 業務委託事業者が従業員を雇用しているか (法2条6項)
}

export function evaluateFreelanceContract(c: FreelanceContract): {
  compliant: boolean;
  violations: string[];
} {
  const violations: string[] = [];
  if (!c.written_disclosure_provided) violations.push("書面交付義務違反 (3条1項)");
  const delivery = new Date(c.delivery_due_date);
  const due = new Date(c.payment_due_date);
  const daysToPay = Math.floor((due.getTime() - delivery.getTime()) / 86_400_000);
  if (daysToPay > FREELANCE_PAYMENT_DEADLINE_DAYS) {
    violations.push(
      `支払期日 ${daysToPay}日 > ${FREELANCE_PAYMENT_DEADLINE_DAYS}日 (4条1項違反)`,
    );
  }
  return { compliant: violations.length === 0, violations };
}

// ───────────────────────────────────────────────
// 確約手続 (H30.12 導入, 48条の2-9)
// ───────────────────────────────────────────────

export interface CommitmentProcedure {
  /** 公取委による確約計画認定の要件 */
  case_id: string;
  notice_received: boolean; // 公取委から通知 (48条の2)
  commitment_plan_filed: boolean; // 確約計画提出 (48条の3, 通知から60日以内)
  filed_within_60_days: boolean;
  plan_includes_corrective_measures: boolean;
  plan_includes_implementation_period: boolean;
  approved_by_jftc: boolean;
}

export function evaluateCommitmentProcedure(c: CommitmentProcedure): {
  approval_likely: boolean;
  reasons: string[];
} {
  const reasons: string[] = [];
  if (!c.commitment_plan_filed) reasons.push("確約計画未提出");
  if (!c.filed_within_60_days) reasons.push("通知から60日以内提出 (48条の3)");
  if (!c.plan_includes_corrective_measures) reasons.push("是正措置の不記載");
  if (!c.plan_includes_implementation_period) reasons.push("実施期間の不記載");
  return { approval_likely: reasons.length === 0, reasons };
}
