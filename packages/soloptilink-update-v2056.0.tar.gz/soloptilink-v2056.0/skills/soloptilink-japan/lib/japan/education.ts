// @ts-check
/**
 * 教育機関 DNA (Phase 17)
 *
 * Claude Code がカバーしない日本の教育セクターを完全カバー。
 *
 *  - 学校教育法 (1947) / 学校教育法施行規則
 *  - 学習指導要領 (R2 改訂 / R5 改訂中)
 *  - 指導要録 (校長作成義務 / 保存期間 学籍 20 年・指導 5 年)
 *  - 通知表 (法的様式なし、各校独自)
 *  - 観点別評価 + 評定 (3 観点: 知識・技能 / 思考・判断・表現 / 主体的態度)
 *  - 出席管理 (出席日数 / 欠席 / 早退 / 遅刻 / 出席停止 / 忌引 / 公欠)
 *  - 履修管理 (単位制高校・通信制高校・科目等履修生)
 *  - eラーニング規格 (SCORM 1.2/2004 + xAPI/Tin Can + LTI 1.3 + JIS X 8341)
 *  - IRT (項目反応理論) 1PL/2PL/3PL
 *  - 学校段階 (幼稚園/小/中/中等/高/特支/高専/短大/大学/大学院)
 */

// =============================================================================
// 学校段階定義
// =============================================================================

export type SchoolLevel =
  | 'kindergarten' // 幼稚園 (3-5歳)
  | 'elementary' // 小学校 (6年)
  | 'lower_secondary' // 中学校 (3年)
  | 'secondary_school' // 中等教育学校 (前期3+後期3)
  | 'upper_secondary' // 高等学校 (3年, 全日/定時/通信)
  | 'special_needs' // 特別支援学校 (幼/小/中/高)
  | 'kosen' // 高等専門学校 (5年)
  | 'junior_college' // 短期大学 (2-3年)
  | 'university' // 大学 (4年, 医歯薬獣6年)
  | 'graduate_school'; // 大学院

export interface SchoolGradeRange {
  level: SchoolLevel;
  min_grade: number;
  max_grade: number;
  /** 学年呼称 (1年, 1年生, 等) */
  grade_label_jp: string;
  /** 1学年の標準授業時数 (年間) */
  standard_hours_per_year: number;
}

export const SCHOOL_LEVELS: SchoolGradeRange[] = [
  { level: 'kindergarten', min_grade: 1, max_grade: 3, grade_label_jp: '年少/年中/年長', standard_hours_per_year: 0 },
  { level: 'elementary', min_grade: 1, max_grade: 6, grade_label_jp: '年生', standard_hours_per_year: 980 },
  { level: 'lower_secondary', min_grade: 1, max_grade: 3, grade_label_jp: '年生', standard_hours_per_year: 1015 },
  { level: 'upper_secondary', min_grade: 1, max_grade: 3, grade_label_jp: '年生', standard_hours_per_year: 1050 },
  { level: 'secondary_school', min_grade: 1, max_grade: 6, grade_label_jp: '年生', standard_hours_per_year: 1015 },
  { level: 'special_needs', min_grade: 1, max_grade: 12, grade_label_jp: '部・年生', standard_hours_per_year: 980 },
  { level: 'kosen', min_grade: 1, max_grade: 5, grade_label_jp: '学年', standard_hours_per_year: 1100 },
  { level: 'junior_college', min_grade: 1, max_grade: 2, grade_label_jp: '回生', standard_hours_per_year: 0 },
  { level: 'university', min_grade: 1, max_grade: 6, grade_label_jp: '回生', standard_hours_per_year: 0 },
  { level: 'graduate_school', min_grade: 1, max_grade: 5, grade_label_jp: '回生', standard_hours_per_year: 0 },
];

// =============================================================================
// 出席管理 (学校教育法施行規則 第28条 出席簿)
// =============================================================================

export type AttendanceStatus =
  | 'present' // 出席
  | 'absent' // 欠席
  | 'late' // 遅刻
  | 'early_leave' // 早退
  | 'suspension_of_attendance' // 出席停止 (学校保健安全法19条 インフル等)
  | 'mourning_leave' // 忌引 (慣行)
  | 'public_absence' // 公欠 (大会出場等)
  | 'unauthorized_absence'; // 不登校扱い (連続30日以上等)

export interface AttendanceRecord {
  student_id: string;
  date: string; // YYYY-MM-DD
  am_pm: 'AM' | 'PM' | 'ALL';
  status: AttendanceStatus;
  reason?: string;
  /** 教科担当者承認 (出席簿は校長保管) */
  approved_by?: string;
}

/**
 * 不登校判定 (文科省定義: 年間 30 日以上の欠席, 病気等を除く)
 */
export function isFutoukou(records: AttendanceRecord[], schoolYear: number): boolean {
  const yearStart = new Date(`${schoolYear}-04-01`);
  const yearEnd = new Date(`${schoolYear + 1}-03-31`);
  let absentDays = 0;
  for (const r of records) {
    const d = new Date(r.date);
    if (d < yearStart || d > yearEnd) continue;
    if (r.status === 'absent' || r.status === 'unauthorized_absence') {
      absentDays += r.am_pm === 'ALL' ? 1 : 0.5;
    }
  }
  return absentDays >= 30;
}

// =============================================================================
// 指導要録 (学校教育法施行規則 第24条)
// =============================================================================

export interface ShidoYoroku {
  /** 学籍に関する記録 (保存 20 年) */
  gakuseki: {
    student_id: string;
    name: string;
    name_kana: string;
    sex: 'male' | 'female' | 'other';
    birth_date: string;
    address: string;
    parent_name: string;
    enrollment_date: string;
    /** 卒業/転出/休学 */
    leaving_date?: string;
    leaving_reason?: string;
  };
  /** 指導に関する記録 (保存 5 年) */
  shido: ShidoYearRecord[];
}

export interface ShidoYearRecord {
  school_year: number;
  grade: number;
  homeroom_teacher: string;
  /** 教科の評価: 観点別 (A/B/C) + 評定 (1-5 段階) */
  subjects: SubjectAssessment[];
  /** 行動の記録 */
  conduct_record: string;
  /** 総合所見 */
  overall_remarks: string;
  /** 出欠の記録 */
  attendance_summary: AttendanceSummary;
}

export interface SubjectAssessment {
  subject: string; // 国語/算数/理科/社会/英語/体育/音楽/図画工作/家庭/技術/道徳/特別活動/総合的な学習
  /** 観点 1: 知識・技能 */
  knowledge_skill: 'A' | 'B' | 'C' | null;
  /** 観点 2: 思考・判断・表現 */
  thinking: 'A' | 'B' | 'C' | null;
  /** 観点 3: 主体的に学習に取り組む態度 */
  attitude: 'A' | 'B' | 'C' | null;
  /** 評定 (小学校3年〜): 1-5 (高校), 1-5 (中学), 3-1 段階 (小) */
  hyotei?: 1 | 2 | 3 | 4 | 5;
}

export interface AttendanceSummary {
  required_days: number; // 出席しなければならない日数
  absence_days: number;
  attendance_days: number;
  late_count: number;
  early_leave_count: number;
}

/**
 * 観点別評価から評定を自動算出 (中学校の標準ロジック)
 *  - A=3点, B=2点, C=1点 の合計 (最大9点)
 *    9 → 5, 7-8 → 4, 5-6 → 3, 3-4 → 2, 1-2 → 1
 */
export function calcHyoteiFromKantenbetsu(s: SubjectAssessment): SubjectAssessment {
  const points: Record<'A' | 'B' | 'C', number> = { A: 3, B: 2, C: 1 };
  const score =
    (s.knowledge_skill ? points[s.knowledge_skill] : 0) +
    (s.thinking ? points[s.thinking] : 0) +
    (s.attitude ? points[s.attitude] : 0);
  let hyotei: 1 | 2 | 3 | 4 | 5 | undefined;
  if (score === 9) hyotei = 5;
  else if (score >= 7) hyotei = 4;
  else if (score >= 5) hyotei = 3;
  else if (score >= 3) hyotei = 2;
  else if (score >= 1) hyotei = 1;
  return { ...s, hyotei };
}

// =============================================================================
// 学習指導要領 (R2 改訂 - 育成すべき資質・能力 3 つの柱)
// =============================================================================

export const COURSE_OF_STUDY_PILLARS = [
  '知識及び技能の習得',
  '思考力・判断力・表現力等の育成',
  '学びに向かう力・人間性等の涵養',
] as const;

export const ELEMENTARY_SUBJECTS = [
  { subject: '国語', total_hours_6yr: 1461 },
  { subject: '社会', total_hours_6yr: 365 },
  { subject: '算数', total_hours_6yr: 1011 },
  { subject: '理科', total_hours_6yr: 405 },
  { subject: '生活', total_hours_6yr: 207 },
  { subject: '音楽', total_hours_6yr: 358 },
  { subject: '図画工作', total_hours_6yr: 358 },
  { subject: '家庭', total_hours_6yr: 115 },
  { subject: '体育', total_hours_6yr: 597 },
  { subject: '外国語', total_hours_6yr: 210 }, // 5,6年
  { subject: '外国語活動', total_hours_6yr: 70 }, // 3,4年
  { subject: '特別の教科 道徳', total_hours_6yr: 209 },
  { subject: '総合的な学習の時間', total_hours_6yr: 280 }, // 3-6年
  { subject: '特別活動', total_hours_6yr: 209 },
] as const;

// =============================================================================
// eラーニング規格
// =============================================================================

export type ELearningStandard = 'SCORM_1.2' | 'SCORM_2004' | 'xAPI' | 'cmi5' | 'LTI_1.3';

export interface ELearningCourse {
  course_id: string;
  title_jp: string;
  title_en?: string;
  standard: ELearningStandard;
  /** SCORM パッケージのマニフェスト or LTI 設定 URL */
  manifest_path?: string;
  /** 単位数 (大学), 時数 (高校) */
  credits?: number;
  /** JIS X 8341-3 (アクセシビリティ) 達成等級 */
  accessibility_level?: 'A' | 'AA' | 'AAA';
}

export interface ELearningProgress {
  learner_id: string;
  course_id: string;
  /** SCORM の場合: completion_status / xAPI の場合: verb */
  status: 'not_attempted' | 'incomplete' | 'completed' | 'passed' | 'failed';
  /** 進捗率 0-100 */
  progress_percent: number;
  /** スコア (0-100) */
  score?: number;
  /** 学習時間 (秒) */
  time_spent_sec: number;
  last_accessed: string;
}

/**
 * SCORM 完了判定: completion + (passing_score 以上)
 */
export function isScormCompleted(p: ELearningProgress, passingScore = 60): boolean {
  if (p.status === 'completed' || p.status === 'passed') return true;
  if (p.score !== undefined && p.score >= passingScore && p.progress_percent >= 100) {
    return true;
  }
  return false;
}

// =============================================================================
// IRT (項目反応理論)
// =============================================================================

/**
 * 1PL モデル (Rasch モデル): P(θ) = 1 / (1 + exp(-(θ - b)))
 *  - θ: 受検者能力
 *  - b: 項目困難度
 */
export function irtProb1PL(theta: number, b: number): number {
  return 1 / (1 + Math.exp(-(theta - b)));
}

/**
 * 2PL モデル: P(θ) = 1 / (1 + exp(-a(θ - b)))
 *  - a: 項目識別力
 */
export function irtProb2PL(theta: number, a: number, b: number): number {
  return 1 / (1 + Math.exp(-a * (theta - b)));
}

/**
 * 3PL モデル: P(θ) = c + (1 - c) / (1 + exp(-a(θ - b)))
 *  - c: 当て推量パラメータ (4 択なら ~0.25)
 */
export function irtProb3PL(theta: number, a: number, b: number, c: number): number {
  return c + (1 - c) / (1 + Math.exp(-a * (theta - b)));
}

export interface IRTItem {
  item_id: string;
  /** 項目困難度 (-3 〜 +3) */
  b: number;
  /** 項目識別力 (0.5 〜 2.5) */
  a?: number;
  /** 当て推量 */
  c?: number;
  model: '1PL' | '2PL' | '3PL';
}

/**
 * 受検者の能力推定 (簡易 EAP: 等差グリッド + 一様事前)
 */
export function estimateTheta(items: IRTItem[], responses: (0 | 1)[], gridStep = 0.1): number {
  if (items.length !== responses.length) {
    throw new Error('items と responses の長さが一致しません');
  }
  let bestTheta = 0;
  let bestLogLik = -Infinity;
  for (let theta = -3; theta <= 3; theta += gridStep) {
    let logLik = 0;
    for (let i = 0; i < items.length; i++) {
      const it = items[i];
      const a = it.a ?? 1.0;
      const c = it.c ?? 0.0;
      const p = it.model === '1PL'
        ? irtProb1PL(theta, it.b)
        : it.model === '2PL'
          ? irtProb2PL(theta, a, it.b)
          : irtProb3PL(theta, a, it.b, c);
      const r = responses[i];
      logLik += Math.log(r === 1 ? p : 1 - p);
    }
    if (logLik > bestLogLik) {
      bestLogLik = logLik;
      bestTheta = theta;
    }
  }
  return Math.round(bestTheta * 1000) / 1000;
}

// =============================================================================
// 通知表生成 (各校独自様式 - 共通フィールドのみ)
// =============================================================================

export interface NotificationCard {
  student_id: string;
  student_name: string;
  school_name: string;
  grade: number;
  /** 学期 */
  term: '1学期' | '2学期' | '3学期' | '前期' | '後期';
  subjects: SubjectAssessment[];
  /** 行動の記録 (◎/○/△ など) */
  conduct: Record<string, '◎' | '○' | '△'>;
  /** 担任所見 */
  homeroom_remarks: string;
  /** 出欠 */
  attendance_summary: AttendanceSummary;
  /** 校長印 (デジタル印影 / ファイル参照) */
  principal_seal?: string;
}

/**
 * 全教科 A 評価で皆勤の場合に「特に優秀」フラグを返す
 */
export function isOutstanding(card: NotificationCard): boolean {
  const allA = card.subjects.every(
    (s) => s.knowledge_skill === 'A' && s.thinking === 'A' && s.attitude === 'A',
  );
  const perfectAttendance = card.attendance_summary.absence_days === 0;
  return allA && perfectAttendance;
}
