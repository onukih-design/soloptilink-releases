/**
 * SoloptiLinkAI JAPAN-NATIVE Mode - 拡張法令DNA Library (v2015.4 Phase 6)
 *
 * 既存 laws.ts (8法令) を補完する +12 法令。合計 20 法令。
 *
 *   9.  PL法 (製造物責任法)
 *   10. 景品表示法 (景表法)
 *   11. 特定商取引法 (特商法)
 *   12. 食品衛生法
 *   13. 食品表示法
 *   14. 薬機法 (旧 薬事法)
 *   15. 旅館業法
 *   16. 宅地建物取引業法 (宅建業法)
 *   17. 児童福祉法
 *   18. 労働安全衛生法 (安衛法)
 *   19. 育児介護休業法 (育介法)
 *   20. 労働者派遣法
 *
 * 使い方:
 *   import { PL, KeihyoHo, TokushoHo, FoodSanitation, FoodLabeling, Yakkiho,
 *            RyokanGyo, TakkenGyo, JidoFukushi, AnzenEisei, IkujiKaigo, HakenHou } from './laws_extended';
 */

// =============================================================================
// 9. PL法 (製造物責任法)
// =============================================================================
export const PL = {
  /**
   * 製造業者等への責任が問われる「製造物」の判定。
   * 加工/非加工の動産が対象。不動産・電気は原則対象外。
   */
  isProductLiable(item: { type: 'movable' | 'realestate' | 'electricity' | 'service'; processed?: boolean }): boolean {
    if (item.type !== 'movable') return false;
    return true;
  },

  /**
   * 時効期間: 損害および加害者を知った時から3年、製造物を引き渡した時から10年。
   */
  limitationPeriod(): { knowledge_years: 3; absolute_years: 10 } {
    return { knowledge_years: 3, absolute_years: 10 };
  },

  /**
   * 表示義務 (取扱説明書等)
   */
  requiredLabels(): string[] {
    return ['製造業者氏名・住所', '製造年月日', '使用上の注意', '警告表示 (危険箇所)', 'PL適合マーク (任意)'];
  },
};

// =============================================================================
// 10. 景品表示法 (景表法)
// =============================================================================
export const KeihyoHo = {
  /**
   * 一般懸賞の景品上限額計算。
   * 取引価額 5000円未満: 取引価額の20倍まで、最高 10万円
   * 取引価額 5000円以上: 一律 10万円
   */
  maxPrizeAmount(transactionAmount: number): number {
    if (transactionAmount < 5000) return Math.min(transactionAmount * 20, 100000);
    return 100000;
  },

  /**
   * 共同懸賞: 取引価額に関わらず最高 30万円
   */
  maxJointPrizeAmount(): number {
    return 300000;
  },

  /**
   * 総付景品の上限額。
   * 取引価額 1000円未満: 200円
   * 取引価額 1000円以上: 取引価額の2/10
   */
  maxBundledPrize(transactionAmount: number): number {
    if (transactionAmount < 1000) return 200;
    return Math.floor(transactionAmount * 0.2);
  },

  /**
   * 不当表示の3類型
   */
  unfairDisplayTypes(): string[] {
    return ['優良誤認表示', '有利誤認表示', 'その他誤認させるおそれのある表示'];
  },

  /**
   * 二重価格表示が許される条件
   */
  isDualPriceAllowed(comparison: { type: 'past_self' | 'competitor' | 'manufacturer_suggested'; basisDays: number; isCurrentlyShownClearly: boolean }): boolean {
    if (!comparison.isCurrentlyShownClearly) return false;
    if (comparison.type === 'past_self' && comparison.basisDays < 8) return false;
    return true;
  },
};

// =============================================================================
// 11. 特定商取引法 (特商法)
// =============================================================================
export const TokushoHo = {
  /**
   * クーリングオフ期間 (取引類型別)
   */
  coolingOffPeriod(transactionType: 'door_to_door' | 'tel_marketing' | 'mail_order' | 'multi_level' | 'specified_continuous' | 'business_opportunity'): number {
    switch (transactionType) {
      case 'door_to_door':
      case 'tel_marketing':
      case 'specified_continuous':
        return 8;
      case 'multi_level':
      case 'business_opportunity':
        return 20;
      case 'mail_order':
        return 0;
      default:
        return 0;
    }
  },

  /**
   * 通信販売の表示義務 (特定商取引法に基づく表記)
   */
  mailOrderRequiredFields(): string[] {
    return [
      '販売価格',
      '送料その他の負担金',
      '代金支払時期と方法',
      '商品引渡時期',
      '返品特約 (有無・条件)',
      '事業者の氏名・住所・電話番号',
      '事業者の代表者氏名',
      'お問い合わせ窓口',
    ];
  },

  /**
   * 不実告知/事実不告知に該当するか
   */
  isMisrepresentation(claim: string, reality: string): boolean {
    return claim !== reality;
  },
};

// =============================================================================
// 12. 食品衛生法
// =============================================================================
export const FoodSanitation = {
  /**
   * HACCP導入義務対象事業者か
   */
  requiresHACCP(business: { isFoodBusiness: boolean; smallScale: boolean }): boolean {
    return business.isFoodBusiness;
  },

  /**
   * 営業許可業種 (32業種) の例
   */
  permitRequiredCategories(): string[] {
    return [
      '飲食店営業', '調理の機能を有する自動販売機', '食肉販売業', '魚介類販売業',
      'コップ式自動販売機', '集乳業', '乳処理業', '特別牛乳搾取処理業', '食肉処理業',
      '食品の放射線照射業', '菓子製造業', 'アイスクリーム類製造業', '乳製品製造業',
      '清涼飲料水製造業', '食肉製品製造業', '水産製品製造業', '氷雪製造業',
      '液卵製造業', '食用油脂製造業', 'みそ又はしょうゆ製造業', '酒類製造業',
      '豆腐製造業', '納豆製造業', '麺類製造業', 'そうざい製造業', '冷凍食品製造業',
      '漬物製造業', '密封包装食品製造業', '食品の小分け業', '添加物製造業',
    ];
  },

  /**
   * 食中毒発生時の届出義務 (24時間以内)
   */
  poisoningReportDeadlineHours(): 24 {
    return 24;
  },
};

// =============================================================================
// 13. 食品表示法
// =============================================================================
export const FoodLabeling = {
  /**
   * 加工食品の必須表示項目
   */
  processedFoodRequiredFields(): string[] {
    return [
      '名称', '原材料名', '添加物', '原料原産地名', '内容量',
      '消費期限または賞味期限', '保存方法', '原産国名 (輸入品)',
      '製造者氏名・住所', '栄養成分表示',
    ];
  },

  /**
   * アレルゲン特定原材料 (8品目) - 表示義務
   */
  mandatoryAllergens(): string[] {
    return ['えび', 'かに', 'くるみ', '小麦', 'そば', '卵', '乳', '落花生'];
  },

  /**
   * アレルゲン特定原材料に準ずるもの (20品目) - 表示推奨
   */
  recommendedAllergens(): string[] {
    return [
      'アーモンド', 'あわび', 'いか', 'いくら', 'オレンジ', 'カシューナッツ',
      'キウイフルーツ', '牛肉', 'ごま', 'さけ', 'さば', '大豆', '鶏肉',
      'バナナ', '豚肉', 'まつたけ', 'もも', 'やまいも', 'りんご', 'ゼラチン',
    ];
  },

  /**
   * 栄養成分表示の義務項目 (5項目)
   */
  mandatoryNutritionItems(): string[] {
    return ['熱量', 'たんぱく質', '脂質', '炭水化物', '食塩相当量'];
  },
};

// =============================================================================
// 14. 薬機法 (旧 薬事法)
// =============================================================================
export const Yakkiho = {
  /**
   * 化粧品の効能効果 56 範囲のうち、広告でうたって良い表現か
   */
  isAllowedCosmeticClaim(claim: string): boolean {
    const allowedKeywords = [
      '汚れを落とす', '清浄にする', '皮膚を保護', '肌のキメを整える',
      '皮膚をなめらかにする', '日焼けによるシミ・ソバカスを防ぐ',
    ];
    return allowedKeywords.some(k => claim.includes(k));
  },

  /**
   * 医薬品的な効能効果の表現 (薬機法違反となる典型例)
   */
  forbiddenMedicalClaims(): string[] {
    return [
      '治る', '治療', '効く', '改善', '予防', '回復',
      '〜病に効果', '医師推奨', '副作用なし', '即効性',
    ];
  },

  /**
   * 一般用医薬品の区分
   */
  otcCategories(): Array<{ category: string; risk: string; sellRequirement: string }> {
    return [
      { category: '第1類医薬品', risk: '特に注意が必要', sellRequirement: '薬剤師の対面販売' },
      { category: '第2類医薬品', risk: 'リスクが比較的高い', sellRequirement: '薬剤師または登録販売者' },
      { category: '指定第2類医薬品', risk: '第2類のうち特に注意', sellRequirement: '薬剤師または登録販売者 + 確認' },
      { category: '第3類医薬品', risk: '比較的リスクが低い', sellRequirement: '薬剤師または登録販売者' },
    ];
  },
};

// =============================================================================
// 15. 旅館業法
// =============================================================================
export const RyokanGyo = {
  /**
   * 営業形態の区分
   */
  businessTypes(): string[] {
    return ['旅館・ホテル営業', '簡易宿所営業', '下宿営業'];
  },

  /**
   * 宿泊者名簿の記載義務項目
   */
  guestRegisterFields(): string[] {
    return ['氏名', '住所', '職業', '宿泊日'];
  },

  /**
   * 外国人宿泊者の追加記載義務
   */
  foreignGuestExtraFields(): string[] {
    return ['国籍', '旅券番号'];
  },

  /**
   * 名簿保存期間 (3年)
   */
  registerRetentionYears(): 3 {
    return 3;
  },

  /**
   * 民泊 (住宅宿泊事業法) との区別: 年間営業日数 180 日以下
   */
  isMinpaku(annualBusinessDays: number): boolean {
    return annualBusinessDays <= 180;
  },
};

// =============================================================================
// 16. 宅地建物取引業法 (宅建業法)
// =============================================================================
export const TakkenGyo = {
  /**
   * 重要事項説明の記載必須項目 (一部抜粋)
   */
  importantMatterFields(): string[] {
    return [
      '対象物件の表示', '登記事項', '法令上の制限', '私道負担',
      '飲用水・電気・ガス供給と排水施設', '完成時の形状・構造',
      '代金以外の授受金銭', '契約解除', '損害賠償額予定・違約金',
      '手付金等の保全措置', '支払金・預り金の保全措置',
      'ローンあっせんの内容と不成立時の措置', '瑕疵担保責任 (契約不適合責任)',
      '建物状況調査の結果概要', 'アスベスト調査結果',
    ];
  },

  /**
   * 媒介契約の3種類
   */
  brokerageTypes(): Array<{ type: string; canMultipleBrokers: boolean; mustReport: string }> {
    return [
      { type: '一般媒介契約', canMultipleBrokers: true, mustReport: '法令上の義務なし' },
      { type: '専任媒介契約', canMultipleBrokers: false, mustReport: '2週間に1回以上' },
      { type: '専属専任媒介契約', canMultipleBrokers: false, mustReport: '1週間に1回以上' },
    ];
  },

  /**
   * 報酬上限の計算 (200万円以下: 5%, 200〜400万円: 4%+2万, 400万円超: 3%+6万)
   */
  maxBrokerageFee(salePrice: number): number {
    if (salePrice <= 2_000_000) return Math.floor(salePrice * 0.05);
    if (salePrice <= 4_000_000) return Math.floor(salePrice * 0.04 + 20_000);
    return Math.floor(salePrice * 0.03 + 60_000);
  },
};

// =============================================================================
// 17. 児童福祉法
// =============================================================================
/* -----------------------------------------------------------------------------
 * 2026-08-17 L-H2 是正 — 保育所の職員配置基準に施行日分岐と経過措置を入れる
 *
 * 【是正前の欠陥】
 *   staffRatio(ageMonths) は施行日を受け取らず、3歳児=20:1 / 4歳以上=30:1 を無条件で返した。
 *   これは令和6年4月1日改正前の値であり、現行条文 (15:1 / 25:1) より緩い。
 *   4歳以上児60人の園で必要保育士数が 2人 と表示され (現行は 3人)、1人不足の状態を
 *   「基準充足」と見せる。辞書 domains/nursery-school.json は改正後の 15 / 25 を宣言しており、
 *   同一画面に2つの必要保育士数が出る原因にもなっていた。
 *
 * 【一次情報】(いずれも本文を実際に取得して条文を確認。確認日 2026-08-17)
 *   [S1] 児童福祉施設の設備及び運営に関する基準 (昭和23年厚生省令第63号) 第33条第2項 現行条文
 *        e-Gov法令検索 API  https://laws.e-gov.go.jp/api/1/lawdata/323M40000100063
 *        画面 https://laws.e-gov.go.jp/law/323M40000100063
 *        原文:「保育士の数は、乳児おおむね三人につき一人以上、満一歳以上満三歳に満たない幼児
 *              おおむね六人につき一人以上、満三歳以上満四歳に満たない幼児おおむね十五人につき
 *              一人以上、満四歳以上の幼児おおむね二十五人につき一人以上とする。
 *              ただし、保育所一につき二人を下ることはできない。」
 *   [S2] 同基準 2024-03-31 時点 (改正前) の第33条第2項
 *        e-Gov法令検索 API  https://laws.e-gov.go.jp/api/2/law_data/323M40000100063?asof=2024-03-31
 *        原文:「…満三歳以上満四歳に満たない幼児おおむね二十人につき一人以上、
 *              満四歳以上の幼児おおむね三十人につき一人以上とする。」
 *   [S3] 改正令 = 児童福祉施設の設備及び運営に関する基準及び家庭的保育事業等の設備及び運営に
 *        関する基準の一部を改正する内閣府令 (令和6年内閣府令第18号)
 *        公布 2024-03-13 / 施行 2024-04-01
 *        e-Gov法令検索 API  https://laws.e-gov.go.jp/api/2/law_data/323M40000100063?asof=2024-04-01
 *        (revision_info.amendment_law_num = 「令和六年内閣府令第十八号」)
 *   [S4] 同府令 附則 (経過措置) — [S1] の附則として e-Gov 本文に収載。原文抜粋:
 *        「２ 保育士及び保育従事者の配置の状況に鑑み、保育の提供に支障を及ぼすおそれがあるときは、
 *          令和十年三月三十一日までの間、…第三十三条第二項…の規定 (満三歳以上満四歳に満たない
 *          児童に対し保育を提供する保育士…の数に関する部分に限る。) は、適用しない。この場合において、
 *          …改正前の…第三十三条第二項…の規定は、この府令の施行の日以後においても、なおその効力を有する。」
 *        「３ …当分の間、設備運営基準第三十三条第二項…の規定 (満四歳以上の児童に対し保育を提供する
 *          保育士…の数に関する部分に限る。) は、適用しない。この場合において、…改正前の…規定は、
 *          この府令の施行の日以後においても、なおその効力を有する。」
 *
 * 【設計上の約束 — 甘い側へ倒さない】
 *   経過措置は「保育の提供に支障を及ぼすおそれがあるとき」という要件付きの任意適用であり、
 *   常に使えるものではない。よって transitional の既定値は false (= 本則の 15:1 / 25:1) とする。
 *   経過措置を使う園は明示的に transitional:true を渡す。既定で従前値を返すと、
 *   要件を満たさない園まで 30:1 で「充足」と表示され、是正前と同じ害が残る。
 *   3歳児の経過措置は令和10年3月31日 (2028-03-31) で終期があるため、それ以降は
 *   transitional:true でも本則 15:1 を返す ([S4] 附則第2項)。
 *   4歳以上児の経過措置は「当分の間」で終期の定めが無いため、終期は実装しない (推測で日付を置かない)。
 *
 * 【未実装 / 未確認】
 *   ・第33条第2項ただし書「保育所一につき二人を下ることはできない」および附則第94条の特例 (当分の間、
 *     ただし書を適用しないことができる) は、人数の下限であって比率ではないため本関数の外にある。
 *     本関数は比率のみを返す。園単位の下限判定はここでは行わない。
 *   ・地方公共団体の条例による上乗せ基準 (法第45条第1項) は自治体ごとに異なり、一次情報を
 *     全自治体分は確認していないため実装しない。
 * ---------------------------------------------------------------------------*/

/** 令和6年内閣府令第18号の施行日 ([S3]) */
const JIDO_FUKUSHI_R6_AMENDMENT_EFFECTIVE = '2024-04-01';
/** 満3歳以上満4歳未満に係る経過措置の終期 ([S4] 附則第2項「令和十年三月三十一日までの間」) */
const JIDO_FUKUSHI_AGE3_TRANSITION_LAST_DAY = '2028-03-31';

/** 年齢区分 (第33条第2項の区切りをそのまま名前にする) */
export type NurseryAgeClass = 'infant' | 'age1to2' | 'age3' | 'age4plus';

export interface StaffRatioOptions {
  /** 判定の基準日 (YYYY-MM-DD または Date)。既定は実行時の現在日。 */
  asOf?: string | Date;
  /**
   * 経過措置 ([S4] 附則第2項・第3項) を適用するか。既定 false (本則)。
   * 「保育士及び保育従事者の配置の状況に鑑み、保育の提供に支障を及ぼすおそれがあるとき」に限り
   * 適用できる任意規定であるため、既定では適用しない。
   */
  transitional?: boolean;
}

export interface StaffRatioBasis {
  /** 児童 N 人につき保育士 1 人以上の N */
  ratio: number;
  ageClass: NurseryAgeClass;
  /** 判定に使った基準日 (YYYY-MM-DD) */
  asOf: string;
  /** 'main' = 本則 (改正後) / 'pre-amendment' = 改正前 / 'transitional' = 経過措置により改正前の値 */
  appliedRule: 'main' | 'pre-amendment' | 'transitional';
  /** 経過措置を実際に適用したか */
  transitionalApplied: boolean;
  /** 経過措置の終期 (定めが無い区分は null) */
  transitionalLastDay: string | null;
  /** 根拠条文 */
  article: string;
  /** 一次情報の所在 */
  source: string;
}

/** YYYY-MM-DD へ正規化する (文字列比較で日付の前後を判定するため) */
function toIsoDay(v: string | Date | undefined): string {
  if (v === undefined || v === null) {
    const now = new Date();
    return toIsoDay(now);
  }
  if (v instanceof Date) {
    if (Number.isNaN(v.getTime())) throw new TypeError('asOf に不正な Date が渡された');
    const y = v.getFullYear();
    const m = String(v.getMonth() + 1).padStart(2, '0');
    const d = String(v.getDate()).padStart(2, '0');
    return `${y}-${m}-${d}`;
  }
  const s = String(v).trim();
  if (!/^\d{4}-\d{2}-\d{2}/.test(s)) throw new TypeError(`asOf は YYYY-MM-DD で渡す (受領: ${s})`);
  return s.slice(0, 10);
}

function nurseryAgeClass(ageMonths: number): NurseryAgeClass {
  if (!Number.isFinite(ageMonths)) {
    // 是正前は NaN が全ての比較を素通りして最も緩い 30 を返していた。数えられない入力は止める。
    throw new TypeError(`staffRatio: ageMonths が数値でない (受領: ${String(ageMonths)})`);
  }
  if (ageMonths < 0) throw new TypeError(`staffRatio: ageMonths が負値 (受領: ${ageMonths})`);
  if (ageMonths < 12) return 'infant';   // 乳児 = 満1歳に満たない者
  if (ageMonths < 36) return 'age1to2';  // 満1歳以上満3歳に満たない幼児
  if (ageMonths < 48) return 'age3';     // 満3歳以上満4歳に満たない幼児
  return 'age4plus';                     // 満4歳以上の幼児
}

export const JidoFukushi = {
  /**
   * 保育所の保育士配置基準 (児童 N人 : 保育士 1人) — 児童福祉施設の設備及び運営に関する基準 第33条第2項。
   *
   * 施行日で分岐する。既定は実行時の現在日・本則 (経過措置なし)。
   *   ・2024-04-01 より前 … 乳児3 / 1〜2歳6 / 3歳20 / 4歳以上30 ([S2])
   *   ・2024-04-01 以後 … 乳児3 / 1〜2歳6 / 3歳15 / 4歳以上25 ([S1])
   *   ・transitional:true … 3歳は 2028-03-31 まで 20、4歳以上は当分の間 30 ([S4])
   */
  staffRatio(ageMonths: number, opts?: StaffRatioOptions): number {
    return JidoFukushi.staffRatioBasis(ageMonths, opts).ratio;
  },

  /** 配置基準と、その根拠 (適用した規定・基準日・出典) を返す。画面に根拠を出すための口。 */
  staffRatioBasis(ageMonths: number, opts?: StaffRatioOptions): StaffRatioBasis {
    const ageClass = nurseryAgeClass(ageMonths);
    const asOf = toIsoDay(opts?.asOf);
    const transitionalRequested = opts?.transitional === true;
    const afterAmendment = asOf >= JIDO_FUKUSHI_R6_AMENDMENT_EFFECTIVE;

    const base: Omit<StaffRatioBasis, 'ratio' | 'appliedRule' | 'transitionalApplied' | 'transitionalLastDay'> = {
      ageClass,
      asOf,
      article: '児童福祉施設の設備及び運営に関する基準 (昭和23年厚生省令第63号) 第33条第2項',
      source: 'e-Gov法令検索 https://laws.e-gov.go.jp/law/323M40000100063 (確認日 2026-08-17)',
    };

    // 乳児・1〜2歳児は令和6年改正で動いていない ([S1][S2] の双方で 3 / 6)。
    if (ageClass === 'infant') {
      return { ...base, ratio: 3, appliedRule: afterAmendment ? 'main' : 'pre-amendment', transitionalApplied: false, transitionalLastDay: null };
    }
    if (ageClass === 'age1to2') {
      return { ...base, ratio: 6, appliedRule: afterAmendment ? 'main' : 'pre-amendment', transitionalApplied: false, transitionalLastDay: null };
    }

    if (!afterAmendment) {
      // 改正前。経過措置はまだ存在しない。
      return {
        ...base,
        ratio: ageClass === 'age3' ? 20 : 30,
        appliedRule: 'pre-amendment',
        transitionalApplied: false,
        transitionalLastDay: null,
      };
    }

    if (ageClass === 'age3') {
      // 附則第2項: 令和10年3月31日までの間に限り、改正前 (20:1) がなお効力を有する。
      const withinTransition = asOf <= JIDO_FUKUSHI_AGE3_TRANSITION_LAST_DAY;
      if (transitionalRequested && withinTransition) {
        return { ...base, ratio: 20, appliedRule: 'transitional', transitionalApplied: true, transitionalLastDay: JIDO_FUKUSHI_AGE3_TRANSITION_LAST_DAY };
      }
      return { ...base, ratio: 15, appliedRule: 'main', transitionalApplied: false, transitionalLastDay: JIDO_FUKUSHI_AGE3_TRANSITION_LAST_DAY };
    }

    // 附則第3項: 満4歳以上は「当分の間」改正前 (30:1) がなお効力を有する。終期の定めは無い。
    if (transitionalRequested) {
      return { ...base, ratio: 30, appliedRule: 'transitional', transitionalApplied: true, transitionalLastDay: null };
    }
    return { ...base, ratio: 25, appliedRule: 'main', transitionalApplied: false, transitionalLastDay: null };
  },

  /**
   * 児童虐待 (4類型)
   */
  abuseTypes(): string[] {
    return ['身体的虐待', '性的虐待', 'ネグレクト', '心理的虐待'];
  },

  /**
   * 通告義務: 児童虐待を発見した者は速やかに市町村等に通告
   */
  reportingObligation(): { applies_to: 'all_persons'; deadline: 'without_delay' } {
    return { applies_to: 'all_persons', deadline: 'without_delay' };
  },
};

// =============================================================================
// 18. 労働安全衛生法 (安衛法)
// =============================================================================
export const AnzenEisei = {
  /**
   * 産業医選任義務: 50人以上の事業場
   */
  requiresOccupationalPhysician(workerCount: number): boolean {
    return workerCount >= 50;
  },

  /**
   * ストレスチェック実施義務: 50人以上
   */
  requiresStressCheck(workerCount: number): boolean {
    return workerCount >= 50;
  },

  /**
   * 安全管理者選任業種
   */
  safetyManagerRequiredIndustries(): string[] {
    return ['製造業', '建設業', '運輸業', '鉱業', '電気業', 'ガス業', '熱供給業',
            '通信業', '各種商品卸売業', '家具・建具・じゅう器等卸売業',
            '各種商品小売業', '家具・建具・じゅう器小売業', '燃料小売業',
            '旅館業', 'ゴルフ場業', '自動車整備業', '機械修理業'];
  },

  /**
   * 健康診断の実施頻度: 一般定期健康診断は1年に1回
   */
  generalHealthCheckFrequency(): { perYear: 1 } {
    return { perYear: 1 };
  },
};

// =============================================================================
// 19. 育児介護休業法 (育介法)
// =============================================================================
export const IkujiKaigo = {
  /**
   * 育児休業: 子が1歳に達するまで (一定要件で2歳まで延長可)
   */
  childcareLeaveDefaultMaxAgeMonths(): 12 {
    return 12;
  },

  /**
   * 出生時育児休業 (産後パパ育休): 出生後8週間以内に4週間まで
   */
  postBirthLeaveMaxDays(): 28 {
    return 28;
  },

  /**
   * 介護休業: 対象家族1人につき通算93日まで、3回まで分割可
   */
  caregiverLeaveMaxDays(): 93 {
    return 93;
  },

  /**
   * 子の看護休暇: 小学校就学前まで、1年に5日 (子が2人以上は10日)
   */
  childCareDaysPerYear(numberOfChildren: number): number {
    return Math.min(numberOfChildren, 2) * 5;
  },
};

// =============================================================================
// 20. 労働者派遣法
// =============================================================================
export const HakenHou = {
  /**
   * 派遣禁止業務
   */
  prohibitedJobs(): string[] {
    return ['港湾運送業務', '建設業務', '警備業務', '医療関連業務 (一部例外あり)', '弁護士・社労士等の士業'];
  },

  /**
   * 同一の派遣先への派遣可能期間 (個人単位): 3年
   */
  individualMaxYears(): 3 {
    return 3;
  },

  /**
   * 同一の派遣先事業所単位の派遣可能期間: 3年 (過半数組合の意見聴取で延長可)
   */
  workplaceMaxYears(): 3 {
    return 3;
  },

  /**
   * 同一労働同一賃金: 派遣先均等均衡方式 or 労使協定方式
   */
  equalPayMethods(): string[] {
    return ['派遣先均等・均衡方式', '労使協定方式'];
  },
};

// =============================================================================
// 統合判定: 業種から拡張法令を推定 (laws.ts の recommendLaws と併用)
// =============================================================================
/**
 * 業種キーから拡張法令を返す。
 *
 * 【引数は「正規化済みの分岐キー」であって業種辞書の名前ではない】
 *   業種辞書の名前 (kebab-case の具体名: beauty-salon / hotel-ryokan …) は
 *   laws.ts の normalizeIndustryKey() が分岐キーへ寄せる。対応表は laws.ts の
 *   1 箇所だけが持つ (2 箇所に置くと片方だけが古くなる)。
 *   本関数を直接呼ぶ場合は、先に normalizeIndustryKey() を通すこと。
 *   通さずに辞書の名前で呼ぶと、下の分岐に当たらず 0 件が返る。
 *
 * 【★2026-08-14 実測で直した欠陥 — 「分岐は在るのに一度も発火しない」】
 *   分岐は 15 件あるのに、114 業種を全通しで呼んで実際に発火したのは 6 件だけだった。
 *   下記の「到達する業種名」に印を付けてある 9 件は、その分岐名に寄せる業種名が
 *   対応表に無かったために **一度も発火しない死んだ分岐** で、美容室・不動産・宿泊・
 *   保育・学童・広告・物流・運送・IT では、その業種でいちばん外せない業法が
 *   生成物の「該当法令」から丸ごと落ちていた。
 *   是正は laws.ts の INDUSTRY_KEY_ALIASES への追加で行い、本関数の返す法令は
 *   1 件も変えていない (法令の中身は一次情報に基づく別の判断であるため)。
 *
 * 【この一覧を更新するときの規律】
 *   分岐を足す/変えるときは、その分岐へ到達する業種名を必ず対応表にも足すこと。
 *   足さないと、実装だけが増えて誰にも届かない分岐がまた生まれる。
 *   発火状況は 114 業種を全通しで呼んで数える (分岐の本数を数えても分からない)。
 */
export function recommendExtendedLaws(industry: string): string[] {
  // 到達する業種名 (2026-08-14 実測。左が業種辞書の名前、右が下の分岐キー)
  //   construction        → construction          (辞書の名前がそのまま分岐キー)
  //   printing            → manufacturing         (対応表)
  //   food-service        → food_service          (対応表)
  //   healthcare          → healthcare            (辞書の名前がそのまま分岐キー)
  //   retail-pos          → retail                (対応表)
  //   bridal              → bridal                (辞書の名前がそのまま分岐キー)
  //   beauty-salon        → beauty          ★2026-08-14 に到達 (それ以前は死に分岐)
  //   real-estate         → real_estate     ★同上
  //   hotel-ryokan        → hotel           ★同上
  //   nursery-school      → childcare       ★同上
  //   after-school-care   → education       ★同上
  //   sns-marketing-agency→ advertising     ★同上
  //   logistics-trucking  → logistics       ★同上
  //   trucking-transport  → transport       ★同上
  //   project-management  → it              ★同上
  switch (industry) {
    case 'construction':
      // 建設業の労働・環境・周辺法令. コア12法は laws.ts の recommendLaws('construction') に集約 (消防法は H3 でコア移動).
      return [
        '労働安全衛生法',
        '労働安全衛生規則第88条', // H2: 機械等設置届 (足場高さ10m以上60日以上/型枠支保工) と 建設工事計画届 (高さ31m超建物/掘削深10m以上)
        '廃棄物処理法',
        '大気汚染防止法', // 石綿飛散防止 (アスベスト事前調査結果報告制度)
        '労働者派遣法', // 建設業務労働者派遣事業は原則禁止 (適正な請負区分)
        '電気事業法',
        '水道法',
        'ガス事業法', // 建設現場のガス管接続
        '道路法', // 道路占用許可 (仮設・足場が公道に張り出す時)
      ];
    case 'manufacturing':
      return ['PL法', '労働安全衛生法'];
    case 'food_service':
      return ['食品衛生法', '食品表示法', 'PL法'];
    case 'healthcare':
      return ['薬機法', '労働安全衛生法'];
    case 'beauty':
      return ['薬機法', '景品表示法'];
    case 'real_estate':
      return ['宅地建物取引業法'];
    case 'hotel':
    case 'bridal':
      return ['旅館業法', '食品衛生法'];
    case 'childcare':
    case 'education':
      return ['児童福祉法'];
    case 'retail':
      return ['景品表示法', '特定商取引法', 'PL法'];
    case 'advertising':
      return ['景品表示法', '薬機法'];
    case 'logistics':
    case 'transport':
      return ['労働安全衛生法'];
    case 'it':
      return ['労働者派遣法'];
    default:
      return [];
  }
}

/* =============================================================================
 * 自己検査 (両側判定) — JidoFukushi.staffRatio 保育所職員配置基準
 *
 *   2026-08-17 L-H2 で追加。健全側 (現行実装) が合格し、欠陥側 (壊した検体) が
 *   同一実行で必ず不合格になることを示す。片側しか出さない検査は何も検査していない。
 *
 *   期待値は実装の出力を写したものではなく、一次情報の条文から先に確定させたものである
 *   (出典は JidoFukushi 直前の [S1]〜[S4] コメントに全文引用がある)。
 *
 *   実行: node ~/.soloptilink/lib/japan/laws_extended.ts --selftest-jidofukushi
 * ===========================================================================*/

/** 期待値表 — 一次情報の条文から先に確定させた値 (実装の出力を写していない) */
interface StaffRatioOracleRow {
  asOf: string;
  ageMonths: number;
  transitional: boolean;
  /** 期待する比率。'throws' は「入力を数えられないので止まること」を期待する行。 */
  expect: number | 'throws';
  why: string;
}

const STAFF_RATIO_ORACLE: StaffRatioOracleRow[] = [
  // --- 改正前 (〜2024-03-31) [S2] ---
  { asOf: '2024-03-31', ageMonths: 40, transitional: false, expect: 20, why: '改正前 満三歳以上満四歳未満 二十人につき一人以上' },
  { asOf: '2024-03-31', ageMonths: 52, transitional: false, expect: 30, why: '改正前 満四歳以上 三十人につき一人以上' },
  // --- 改正後 本則 (2024-04-01〜) [S1][S3] ---
  { asOf: '2024-04-01', ageMonths: 40, transitional: false, expect: 15, why: '施行日当日から本則 十五人につき一人以上' },
  { asOf: '2024-04-01', ageMonths: 52, transitional: false, expect: 25, why: '施行日当日から本則 二十五人につき一人以上' },
  { asOf: '2026-08-17', ageMonths: 40, transitional: false, expect: 15, why: '現在日・経過措置を使わない園は本則' },
  { asOf: '2026-08-17', ageMonths: 52, transitional: false, expect: 25, why: '現在日・経過措置を使わない園は本則' },
  // --- 経過措置 [S4] ---
  { asOf: '2026-08-17', ageMonths: 40, transitional: true, expect: 20, why: '附則2項 令和10年3月31日までの間は改正前(20:1)がなお効力' },
  { asOf: '2026-08-17', ageMonths: 52, transitional: true, expect: 30, why: '附則3項 当分の間は改正前(30:1)がなお効力' },
  { asOf: '2028-03-31', ageMonths: 40, transitional: true, expect: 20, why: '附則2項の終期当日はまだ経過措置の範囲内' },
  { asOf: '2028-04-01', ageMonths: 40, transitional: true, expect: 15, why: '附則2項の終期の翌日からは本則へ戻る' },
  { asOf: '2028-04-01', ageMonths: 52, transitional: true, expect: 30, why: '附則3項に終期の定めは無い (当分の間)' },
  // --- 改正で動いていない区分 (改正前後・経過措置の有無で不変) [S1][S2] ---
  { asOf: '2024-03-31', ageMonths: 6, transitional: false, expect: 3, why: '乳児 三人につき一人以上 (改正なし)' },
  { asOf: '2026-08-17', ageMonths: 6, transitional: true, expect: 3, why: '乳児は経過措置の対象外' },
  { asOf: '2026-08-17', ageMonths: 18, transitional: true, expect: 6, why: '満一歳以上満三歳未満は経過措置の対象外' },
  { asOf: '2026-08-17', ageMonths: 30, transitional: true, expect: 6, why: '満二歳も同区分 (満三歳未満)' },
  // --- 年齢区分の境界 (第33条第2項の区切りそのもの) ---
  { asOf: '2026-08-17', ageMonths: 11, transitional: false, expect: 3, why: '満1歳未満の上限' },
  { asOf: '2026-08-17', ageMonths: 12, transitional: false, expect: 6, why: '満1歳ちょうど' },
  { asOf: '2026-08-17', ageMonths: 35, transitional: false, expect: 6, why: '満3歳未満の上限' },
  { asOf: '2026-08-17', ageMonths: 36, transitional: false, expect: 15, why: '満3歳ちょうど' },
  { asOf: '2026-08-17', ageMonths: 47, transitional: false, expect: 15, why: '満4歳未満の上限' },
  { asOf: '2026-08-17', ageMonths: 48, transitional: false, expect: 25, why: '満4歳ちょうど' },
  // --- 数えられない入力 (是正前は NaN が最も緩い 30 を返していた) ---
  { asOf: '2026-08-17', ageMonths: Number.NaN, transitional: false, expect: 'throws', why: '月齢が数値でないときに最も緩い値を返さない' },
  { asOf: '2026-08-17', ageMonths: -1, transitional: false, expect: 'throws', why: '負の月齢を黙って乳児扱いにしない' },
];

type StaffRatioImpl = (ageMonths: number, opts?: StaffRatioOptions) => number;

/** 期待値表を任意の実装へ当てて、食い違いの一覧を返す */
function runStaffRatioOracle(impl: StaffRatioImpl): string[] {
  const bad: string[] = [];
  for (const r of STAFF_RATIO_ORACLE) {
    let actual: number | 'throws';
    try {
      actual = impl(r.ageMonths, { asOf: r.asOf, transitional: r.transitional });
    } catch {
      actual = 'throws';
    }
    if (actual !== r.expect) {
      bad.push(
        `asOf=${r.asOf} 月齢=${String(r.ageMonths)} 経過措置=${r.transitional ? 'あり' : 'なし'}` +
        ` 期待=${String(r.expect)} 実際=${String(actual)}  (${r.why})`,
      );
    }
  }
  return bad;
}

/** 欠陥検体 — わざと壊した実装。これで不合格が出せない検査は検出能力ゼロである。 */
const STAFF_RATIO_DEFECT_SPECIMENS: Array<{ name: string; impl: StaffRatioImpl }> = [
  {
    name: 'D1 是正前の実装 (施行日分岐が無く改正前の 20:1 / 30:1 を無条件で返す)',
    impl: (ageMonths: number): number => {
      if (ageMonths < 12) return 3;
      if (ageMonths < 24) return 6;
      if (ageMonths < 36) return 6;
      if (ageMonths < 48) return 20;
      return 30;
    },
  },
  {
    name: 'D2 経過措置を既定で適用する (要件を満たさない園まで従前値で「充足」と表示する甘い側の欠陥)',
    impl: (ageMonths: number, opts?: StaffRatioOptions): number =>
      JidoFukushi.staffRatio(ageMonths, { asOf: opts?.asOf, transitional: true }),
  },
  {
    name: 'D3 3歳児の経過措置の終期 (令和10年3月31日) を無視して以後も 20:1 を返す',
    impl: (ageMonths: number, opts?: StaffRatioOptions): number => {
      if (opts?.transitional === true && ageMonths >= 36 && ageMonths < 48) return 20;
      return JidoFukushi.staffRatio(ageMonths, opts);
    },
  },
  {
    name: 'D4 施行日を無視して常に本則を返す (改正前の期間まで 15:1 / 25:1 と表示する)',
    impl: (ageMonths: number, opts?: StaffRatioOptions): number =>
      JidoFukushi.staffRatio(ageMonths, { asOf: '2026-08-17', transitional: opts?.transitional }),
  },
];

export function __selftestJidoFukushiStaffRatio(): { pass: boolean; lines: string[] } {
  const lines: string[] = [];
  lines.push('=== 自己検査: JidoFukushi.staffRatio (保育所 職員配置基準) ===');
  lines.push(`期待値の件数: ${STAFF_RATIO_ORACLE.length} 件 (一次情報 = 児童福祉施設の設備及び運営に関する基準 第33条第2項 および 令和6年内閣府令第18号 附則)`);
  lines.push('');

  // --- 健全側 ---
  const healthyBad = runStaffRatioOracle((m, o) => JidoFukushi.staffRatio(m, o));
  const healthyOk = healthyBad.length === 0;
  lines.push(`[健全側] 現行実装 … ${healthyOk ? 'PASS' : 'FAIL'} (食い違い ${healthyBad.length} 件)`);
  for (const b of healthyBad) lines.push(`         × ${b}`);
  lines.push('');

  // --- 欠陥側 ---
  lines.push('[欠陥側] 壊した検体で必ず不合格が出ること');
  let allDetected = true;
  for (const sp of STAFF_RATIO_DEFECT_SPECIMENS) {
    const bad = runStaffRatioOracle(sp.impl);
    const detected = bad.length > 0;
    if (!detected) allDetected = false;
    lines.push(`         ${detected ? 'FAIL を検出 (期待どおり)' : '★空振り (検出できず)'} — ${sp.name}`);
    lines.push(`            食い違い ${bad.length} 件${bad.length ? ': ' + bad[0] : ''}`);
  }
  lines.push('');

  const pass = healthyOk && allDetected;
  lines.push(`総合: ${pass ? 'PASS' : 'FAIL'} — 健全側=${healthyOk ? 'PASS' : 'FAIL'} / 欠陥側の検出=${allDetected ? '全件' : '空振りあり'}`);
  return { pass, lines };
}

// 自己検査の起動口。import しただけでは走らない (この旗が argv に無ければ何もしない)。
// import.meta / node: 組込みモジュールを使わないので、ブラウザ向けバンドルでも無害である。
if (
  typeof process !== 'undefined' &&
  process &&
  Array.isArray((process as unknown as { argv?: string[] }).argv) &&
  (process as unknown as { argv: string[] }).argv.includes('--selftest-jidofukushi')
) {
  const __r = __selftestJidoFukushiStaffRatio();
  for (const __l of __r.lines) console.log(__l);
  const __p = process as unknown as { exit?: (c: number) => void };
  if (typeof __p.exit === 'function') __p.exit(__r.pass ? 0 : 1);
}
