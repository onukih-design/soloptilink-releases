/**
 * lib/japan/mining.ts — 鉱業・採石・砂利採取DNA
 *
 * 法令カバレッジ:
 *  - 鉱業法 (S25法律289) 鉱区/試掘権/採掘権
 *  - 採石法 (S25法律291) 岩石採取認可
 *  - 砂利採取法 (S43法律74) 砂利採取業の登録/採取計画認可
 *  - 鉱山保安法 (S24法律70 / 全部改正S29) 鉱山保安監督
 *  - 火薬類取締法 (S25法律149) 発破作業
 *  - 鉱業等に係る土地利用の調整手続等に関する法律
 *  - 環境影響評価法 (鉱区面積100ha以上)
 *
 * 参考: 経済産業省 鉱物資源課, 都道府県 商工労働部 採石係
 */

// ============================================================================
// 1. 法定鉱物 (鉱業法3条)
// ============================================================================

/** 鉱業法3条で定められた法定鉱物 (40種以上の代表) */
export const LEGAL_MINERALS = [
  '金鉱', '銀鉱', '銅鉱', '鉛鉱', 'ビスマス鉱', '錫鉱', 'アンチモニー鉱',
  '水銀鉱', '亜鉛鉱', '鉄鉱', '硫化鉄鉱', 'クローム鉄鉱', 'マンガン鉱',
  'タングステン鉱', 'モリブデン鉱', 'ニッケル鉱', 'コバルト鉱',
  'ウラン鉱', 'トリウム鉱', '砒鉱', '燐鉱', '黒鉛',
  '石炭', '亜炭', '石油', '天然ガス', 'アスファルト',
  '硫黄', '石膏', '重晶石', '明礬石', '蛍石',
  '石綿', '石灰石', 'ドロマイト', '珪石', '長石', '滑石',
  '耐火粘土', '砂鉱', // 砂金/砂錫など
] as const;

export type LegalMineral = typeof LEGAL_MINERALS[number];

/** 採取対象が鉱業法 / 採石法 / 砂利採取法のどれに該当するか判定 */
export function classifyMineralLaw(material: string): {
  law: 'mining_law' | 'quarry_law' | 'gravel_law' | 'unknown';
  reason: string;
} {
  if ((LEGAL_MINERALS as readonly string[]).includes(material)) {
    return { law: 'mining_law', reason: '鉱業法3条の法定鉱物 — 鉱業権 (試掘権/採掘権) 必須' };
  }
  if (['花崗岩', '安山岩', '玄武岩', '凝灰岩', '砂岩', '頁岩'].includes(material)) {
    return { law: 'quarry_law', reason: '採石法2条の岩石 — 採取場ごとに採取計画認可' };
  }
  if (['砂利', '玉石', '砂', '川砂', '海砂'].includes(material)) {
    return { law: 'gravel_law', reason: '砂利採取法 — 業登録 + 採取計画認可' };
  }
  return { law: 'unknown', reason: '法定対象外 — 個別協議' };
}

// ============================================================================
// 2. 鉱業権 (鉱業法5条)
// ============================================================================

export type MiningRightKind = 'exploration' | 'extraction'; // 試掘権 / 採掘権

export interface MiningRight {
  kind: MiningRightKind;
  areaHa: number; // 鉱区面積
  registeredAt: Date;
  mineral: LegalMineral;
}

/**
 * 試掘権存続期間 (鉱業法18条): 2年 (1回のみ2年延長可)
 * 採掘権存続期間 (鉱業法19条): 無期限 (実体的存続条件あり)
 */
export function calcMiningRightExpiry(r: MiningRight): {
  expiresAt: Date | null;
  remainingDays: number | null;
  warning: string | null;
} {
  if (r.kind === 'extraction') {
    return { expiresAt: null, remainingDays: null, warning: null }; // 無期限
  }
  // 試掘権: 2年
  const expiresAt = new Date(r.registeredAt);
  expiresAt.setFullYear(expiresAt.getFullYear() + 2);
  const remainingDays = Math.ceil((expiresAt.getTime() - Date.now()) / 86400000);
  const warning =
    remainingDays < 90 ? `試掘権満了まで${remainingDays}日 — 延長申請または採掘権申請を準備` : null;
  return { expiresAt, remainingDays, warning };
}

/** 鉱区面積制限 (鉱業法14条): 1鉱区につき350ha以内 (石炭・原油等は3500ha) */
export function isValidMiningAreaSize(input: {
  mineral: LegalMineral;
  areaHa: number;
}): { valid: boolean; maxHa: number } {
  const isLargeAllowed = ['石炭', '亜炭', '石油', '天然ガス'].includes(input.mineral as string);
  const maxHa = isLargeAllowed ? 3500 : 350;
  return { valid: input.areaHa <= maxHa, maxHa };
}

// ============================================================================
// 3. 採石業 (採石法)
// ============================================================================

export interface QuarryPlan {
  operatorRegistered: boolean; // 採石業者登録 (採石法32条)
  hasRockPickerLicense: boolean; // 採石業務管理者選任 (採石法32条の3)
  planAreaHa: number;
  hasEia: boolean; // 環境影響評価
  hasReclamationPlan: boolean; // 災害防止 + 復旧計画
  hasInsurance: boolean; // 災害補償
}

/** 採石計画認可 (採石法33条) の事前チェック */
export function checkQuarryPlanReadiness(p: QuarryPlan): {
  ready: boolean;
  blockers: string[];
} {
  const b: string[] = [];
  if (!p.operatorRegistered) b.push('採石業者登録が未完了 (採石法32条)');
  if (!p.hasRockPickerLicense) b.push('採石業務管理者選任義務違反 (採石法32条の3)');
  if (!p.hasReclamationPlan) b.push('災害防止 + 採取跡地復旧計画が必要');
  if (!p.hasInsurance) b.push('災害補償措置 (賠償保険) 未加入');
  if (p.planAreaHa >= 50 && !p.hasEia) {
    b.push('50ha以上は環境影響評価必須 (環境アセスメント条例)');
  }
  return { ready: b.length === 0, blockers: b };
}

// ============================================================================
// 4. 砂利採取業 (砂利採取法)
// ============================================================================

/** 砂利採取業者の登録区分 */
export const GRAVEL_REGISTRATION_TYPES = {
  river: { law: '河川法 + 砂利採取法', authority: '河川管理者', scope: '河川区域' },
  sea: { law: '海岸法 + 砂利採取法', authority: '海岸管理者', scope: '海岸区域' },
  land: { law: '砂利採取法', authority: '都道府県知事', scope: '陸砂利' },
} as const;

export interface GravelExtractionPlan {
  registrationType: keyof typeof GRAVEL_REGISTRATION_TYPES;
  hasGravelEngineer: boolean; // 砂利採取業務主任者 (砂利採取法21条)
  annualVolumeM3: number;
  hasFloodControlMeasures: boolean; // 河川の場合の治水措置
}

/** 砂利採取計画認可 (砂利採取法16条) */
export function evaluateGravelPlan(p: GravelExtractionPlan): {
  approvable: boolean;
  warnings: string[];
} {
  const w: string[] = [];
  if (!p.hasGravelEngineer) w.push('砂利採取業務主任者 (国家資格) の選任必須');
  if (p.registrationType === 'river' && !p.hasFloodControlMeasures) {
    w.push('河川区域の砂利採取は治水措置 (河積確保 / 護岸保全) を計画書に明記');
  }
  if (p.annualVolumeM3 > 50_000) {
    w.push('年間5万m³超は環境負荷大 — 都道府県の事前協議推奨');
  }
  return { approvable: p.hasGravelEngineer && w.length <= 1, warnings: w };
}

// ============================================================================
// 5. 鉱山保安法 (S29全部改正)
// ============================================================================

/** 鉱山保安監督員の選任義務 */
export interface SafetySupervisor {
  rank: 'chief' | 'subchief' | 'engineer'; // 統括/副統括/保安技術職員
  certNumber: string;
  validUntil: Date;
}

/** 鉱山保安法に基づく保安体制チェック */
export function checkMineSafety(input: {
  workersCount: number;
  hasHighPressureGas: boolean;
  supervisors: SafetySupervisor[];
}): { compliant: boolean; gaps: string[] } {
  const gaps: string[] = [];
  const hasChief = input.supervisors.some((s) => s.rank === 'chief');
  if (!hasChief) gaps.push('統括保安監督員の選任が必要');
  if (input.workersCount > 50 && !input.supervisors.some((s) => s.rank === 'subchief')) {
    gaps.push('労働者50人超は副統括の選任が必要');
  }
  if (input.hasHighPressureGas && !input.supervisors.some((s) => s.rank === 'engineer')) {
    gaps.push('高圧ガス使用鉱山は保安技術職員 (ガス担当) が必須');
  }
  // 資格期限切れ
  for (const s of input.supervisors) {
    if (s.validUntil.getTime() < Date.now()) {
      gaps.push(`保安監督員 ${s.certNumber} の資格が期限切れ`);
    }
  }
  return { compliant: gaps.length === 0, gaps };
}

// ============================================================================
// 6. 火薬類取締法 (発破作業)
// ============================================================================

/** 発破作業の安全距離 (火薬類取締法施行規則 + 鉱山保安法) */
export function calcBlastingSafeDistanceM(chargeWeightKg: number): {
  flyRockMinM: number; // 飛石防止
  vibrationOkAt500mGal: number; // 振動許容
  pressureOkAt: number; // 騒音許容
} {
  // 経験式: D = K × W^(1/3)  (K=10〜30 m/kg^(1/3))
  return {
    flyRockMinM: 30 * Math.cbrt(chargeWeightKg),
    vibrationOkAt500mGal: 100 * Math.cbrt(chargeWeightKg),
    pressureOkAt: 50 * Math.cbrt(chargeWeightKg),
  };
}

// ============================================================================
// 7. 環境影響評価法 (鉱業)
// ============================================================================

/** 鉱区面積による環境影響評価対象判定 */
export function requiresEnvironmentalAssessment(input: {
  miningAreaHa: number;
  isFirstClassMineral: boolean; // 1種事業 (法定対象)
}): {
  required: boolean;
  classification: '第1種' | '第2種' | '対象外';
  scopingRequired: boolean;
} {
  if (input.miningAreaHa >= 100 && input.isFirstClassMineral) {
    return { required: true, classification: '第1種', scopingRequired: true };
  }
  if (input.miningAreaHa >= 75) {
    return { required: true, classification: '第2種', scopingRequired: true };
  }
  return { required: false, classification: '対象外', scopingRequired: false };
}
