/**
 * lib/japan/welfare_transport.ts — 介護タクシー・福祉輸送DNA
 *
 * 法令カバレッジ:
 *  - 道路運送法 (S26法律183) 4条一般旅客 / 43条特定旅客 / 78条自家用有償
 *  - 道路運送法施行規則
 *  - 高齢者・障害者等の移動等の円滑化の促進に関する法律 (バリアフリー法 H18法律91)
 *  - 障害者基本法 (S45法律84)
 *  - 介護保険法 (H9法律123) — 介護タクシー報酬連携
 *  - 障害者総合支援法 (H17法律123) — 移動支援サービス
 *  - 民間救急 (消防庁通知) — Patient Transport
 *
 * 参考: 国土交通省自動車局, 全国福祉輸送サービス協会, 福祉輸送事業限定許可
 */

// ============================================================================
// 1. 旅客自動車運送事業の区分 (道路運送法3条)
// ============================================================================

export type TransportLicenseKind =
  | 'general_passenger' // 一般旅客自動車運送事業 (4条)
  | 'special_passenger' // 特定旅客自動車運送事業 (43条 — 介護施設送迎等)
  | 'private_paid' // 自家用有償旅客運送 (78条 — 福祉有償運送 / 公共交通空白地)
  | 'welfare_limited'; // 福祉輸送事業限定許可 (4条+規則第3条の2)

/** 介護タクシー / 福祉輸送 の事業形態判定 */
export function classifyWelfareTransport(input: {
  vehicleHasWheelchairLift: boolean;
  driverHasUmaiClass2License: boolean; // 普通二種免許
  servesNonContractedClients: boolean; // 不特定多数 vs 契約者のみ
  isNpoOrSocialWelfareCorp: boolean;
}): { license: TransportLicenseKind; reason: string } {
  if (input.servesNonContractedClients && input.driverHasUmaiClass2License) {
    return {
      license: 'welfare_limited',
      reason: '4条一般旅客の福祉輸送事業限定許可 — 福祉車両 + 二種免許 + 介護資格',
    };
  }
  if (!input.servesNonContractedClients && input.driverHasUmaiClass2License) {
    return {
      license: 'special_passenger',
      reason: '43条特定旅客 — 特定の老人ホーム等の入居者のみ送迎',
    };
  }
  if (input.isNpoOrSocialWelfareCorp && !input.driverHasUmaiClass2License) {
    return {
      license: 'private_paid',
      reason: '78条 自家用有償旅客運送 (福祉有償運送) — NPO/社福法人 + 一種免許 + 認定講習',
    };
  }
  return {
    license: 'general_passenger',
    reason: '通常タクシー (4条一般旅客) — 福祉車両がなくても可',
  };
}

// ============================================================================
// 2. 介護タクシー運転者の資格 (規則第48条 + 通達)
// ============================================================================

export type DriverQualification =
  | 'class2_license_only' // 普通二種のみ
  | 'class2_plus_kaigo_initial' // 二種 + 介護職員初任者研修
  | 'class2_plus_kaigo_practical' // 二種 + 実務者研修
  | 'class2_plus_care_worker' // 二種 + 介護福祉士
  | 'class2_plus_homehelper'; // 二種 + ホームヘルパー2級相当

/** 介護タクシー運転者の介助行為の可否判定 */
export function canPerformCareAssistance(q: DriverQualification): {
  vehicleAssistance: boolean; // 乗降介助
  bodyAssistance: boolean; // 身体介護
  reason: string;
} {
  if (q === 'class2_license_only') {
    return { vehicleAssistance: true, bodyAssistance: false, reason: '乗降介助のみ可 — 介助技術未取得' };
  }
  return {
    vehicleAssistance: true,
    bodyAssistance: true,
    reason: '介護資格保有 — 乗降介助 + 身体介護可',
  };
}

// ============================================================================
// 3. バリアフリー法 (H18法律91) 車両基準
// ============================================================================

/** 福祉車両 (バリアフリー法移動等円滑化基準) 適合性 */
export function checkAccessibleVehicleCompliance(input: {
  vehicleType: 'sedan' | 'wagon' | 'minibus' | 'bus';
  hasWheelchairLift: boolean;
  hasSwivelSeat: boolean; // 回転シート
  hasRamp: boolean; // スロープ
  wheelchairFixingType: 'belt' | '4-point' | 'none';
}): {
  qualifyAsAccessible: boolean;
  notes: string[];
} {
  const notes: string[] = [];
  if (!input.hasWheelchairLift && !input.hasRamp) {
    return {
      qualifyAsAccessible: false,
      notes: ['車椅子リフトまたはスロープが必要 (バリアフリー法移動等円滑化基準)'],
    };
  }
  if (input.wheelchairFixingType === 'none' && input.hasWheelchairLift) {
    notes.push('車椅子固定装置が必要 — 4点固定推奨');
  }
  if (input.vehicleType === 'bus' && !input.hasSwivelSeat) {
    notes.push('福祉バスは回転シート1席以上が望ましい');
  }
  return { qualifyAsAccessible: true, notes };
}

// ============================================================================
// 4. 介護保険連携 (介護タクシー = 通院等乗降介助)
// ============================================================================

/** 通院等乗降介助 R6介護報酬: 1回 99単位 (前後の身体介護加算可) */
export const TSUUIN_TOUJOSHA_FEE_R6 = 99; // 単位

/** ケアプラン位置づけ + 算定要件チェック */
export function evaluateTsuuinTouToshaCharging(input: {
  isInCarePlan: boolean;
  hasDoctorReferralOrHospitalVisit: boolean;
  driverIsCertifiedHelper: boolean; // 初任者研修以上
  pickupAndDropoffSeparate: boolean; // 行き帰り別算定
}): { algoritmable: boolean; unitsPerService: number; reasons: string[] } {
  const reasons: string[] = [];
  if (!input.isInCarePlan) reasons.push('ケアプランに位置づけが必要 (居宅サービス計画書)');
  if (!input.hasDoctorReferralOrHospitalVisit) reasons.push('通院 / 官公署 / 預貯金引出し等の必要事由');
  if (!input.driverIsCertifiedHelper) reasons.push('運転者は介護職員初任者研修以上必須');
  return {
    algoritmable: reasons.length === 0,
    unitsPerService: TSUUIN_TOUJOSHA_FEE_R6 * (input.pickupAndDropoffSeparate ? 2 : 1),
    reasons,
  };
}

// ============================================================================
// 5. 福祉有償運送 (78条 自家用有償)
// ============================================================================

export interface PrivatePaidTransportOperator {
  organizationKind: 'npo' | 'social_welfare_corp' | 'commerce_corp_with_municipality_authorization';
  driversWithCertifiedTraining: number; // 大臣認定講習修了者数
  driversTotal: number;
  hasMunicipalRunningCommittee: boolean; // 市町村運営協議会の協議
  vehiclesAccessibleCount: number;
}

/** 78条 自家用有償旅客運送 (福祉有償運送) 登録要件 */
export function evaluatePrivatePaidTransportEligibility(o: PrivatePaidTransportOperator): {
  registerable: boolean;
  blockers: string[];
} {
  const blockers: string[] = [];
  if (!o.hasMunicipalRunningCommittee) {
    blockers.push('市町村運営協議会での協議が必須 (道路運送法施行規則49条)');
  }
  if (o.vehiclesAccessibleCount < 1) blockers.push('福祉車両 1台以上必須');
  if (o.driversWithCertifiedTraining < o.driversTotal) {
    blockers.push(
      `運転者全員に大臣認定講習修了義務 — 未修了 ${o.driversTotal - o.driversWithCertifiedTraining} 名`
    );
  }
  return { registerable: blockers.length === 0, blockers };
}

// ============================================================================
// 6. 移動支援サービス (障害者総合支援法 — 地域生活支援事業)
// ============================================================================

/** 移動支援対象者の判定 */
export function isMobilitySupportEligible(input: {
  disabilityCategory: 'physical' | 'intellectual' | 'mental' | 'developmental';
  disabilityGrade?: 1 | 2 | 3 | 4 | 5 | 6;
  age: number;
  isMunicipalityResident: boolean;
}): { eligible: boolean; reason: string } {
  if (!input.isMunicipalityResident) {
    return { eligible: false, reason: '実施主体は市町村 — 居住地申請が必要' };
  }
  if (input.disabilityCategory === 'physical' && (input.disabilityGrade ?? 7) > 3) {
    return { eligible: false, reason: '身体障害は1-3級が目安 (市町村裁量)' };
  }
  return { eligible: true, reason: '対象 — 市町村窓口で申請 + 受給者証発行' };
}

// ============================================================================
// 7. 民間救急 (Patient Transport)
// ============================================================================

/** 民間救急車両の認定 (消防庁通知) */
export function checkPrivateAmbulanceRequirements(input: {
  hasMedicalEquipment: boolean; // AED/酸素吸入器/担架
  driverHasFirstAid: boolean; // 応急手当普及員以上
  hasHospitalCoordinationProtocol: boolean; // 病院連携手順書
}): { recognizable: boolean; gaps: string[] } {
  const gaps: string[] = [];
  if (!input.hasMedicalEquipment) gaps.push('AED / 酸素吸入器 / 担架の搭載必須');
  if (!input.driverHasFirstAid) gaps.push('応急手当普及員以上の資格 (消防庁認定)');
  if (!input.hasHospitalCoordinationProtocol) gaps.push('病院連携手順書 (拒否時の代替先含む)');
  return { recognizable: gaps.length === 0, gaps };
}
