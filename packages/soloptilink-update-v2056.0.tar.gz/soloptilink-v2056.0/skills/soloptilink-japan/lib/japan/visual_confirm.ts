/**
 * Visual Confirm Loop - 視覚確認モジュール
 *
 * ER図・画面遷移図・ワイヤーフレーム・面積表・データフロー図を SVG / Mermaid で自動生成し、
 * ユーザー承認を得てから実装に進めるワークフローを提供する。
 *
 * 「作りたいものをしっかり作り込む」の核。意図を視覚化してフィードバックループを閉じる。
 */

// =============================================================================
// 型定義
// =============================================================================
export interface ERDiagramInput {
  entities: Array<{
    name: string;
    ja?: string;                       // 日本語名
    fields: Array<{ name: string; type: string; pk?: boolean; fk?: string; nullable?: boolean; ja?: string }>;
  }>;
  relations: Array<{
    from: string;
    to: string;
    cardinality: '1-1' | '1-n' | 'n-n';
    label?: string;
  }>;
}

export interface ScreenFlowInput {
  screens: Array<{ id: string; name: string; role?: 'OWNER' | 'MANAGER' | 'WORKER' | 'ACCOUNTANT' | 'GUEST' }>;
  transitions: Array<{ from: string; to: string; trigger: string; guard?: string }>;
}

export interface WireframeInput {
  screenName: string;
  sections: Array<{
    type: 'header' | 'sidebar' | 'main' | 'footer' | 'toolbar' | 'form' | 'table' | 'card' | 'chart';
    title?: string;
    items?: string[];
    width?: string;
    height?: string;
  }>;
}

export interface DataFlowInput {
  nodes: Array<{ id: string; label: string; type: 'client' | 'api' | 'db' | 'external' | 'queue' }>;
  flows: Array<{ from: string; to: string; label: string; method?: string }>;
}

// =============================================================================
// ER図生成 (Mermaid形式)
// =============================================================================
export function generateERDiagram(input: ERDiagramInput): string {
  const lines: string[] = ['erDiagram'];

  for (const ent of input.entities) {
    lines.push(`  ${ent.name} {`);
    for (const f of ent.fields) {
      const mods: string[] = [];
      if (f.pk) mods.push('PK');
      if (f.fk) mods.push(`FK`);
      const mod = mods.length > 0 ? ` ${mods.join(',')}` : '';
      const note = f.ja ? ` "${f.ja}"` : '';
      lines.push(`    ${f.type} ${f.name}${mod}${note}`);
    }
    lines.push(`  }`);
  }

  for (const r of input.relations) {
    const card = r.cardinality === '1-1' ? '||--||' : r.cardinality === '1-n' ? '||--o{' : '}o--o{';
    lines.push(`  ${r.from} ${card} ${r.to} : "${r.label ?? ''}"`);
  }

  return lines.join('\n');
}

// =============================================================================
// 画面遷移図生成 (Mermaid flowchart)
// =============================================================================
export function generateScreenFlow(input: ScreenFlowInput): string {
  const lines: string[] = ['flowchart TD'];
  const roleColors: Record<string, string> = {
    OWNER: '#ffcccc', MANAGER: '#ffddaa', WORKER: '#ccffcc', ACCOUNTANT: '#ccddff', GUEST: '#eeeeee',
  };

  for (const s of input.screens) {
    lines.push(`  ${s.id}["${s.name}"]`);
    if (s.role) lines.push(`  style ${s.id} fill:${roleColors[s.role] || '#fff'}`);
  }

  for (const t of input.transitions) {
    const label = t.guard ? `${t.trigger} [${t.guard}]` : t.trigger;
    lines.push(`  ${t.from} -->|${label}| ${t.to}`);
  }

  return lines.join('\n');
}

// =============================================================================
// ワイヤーフレームSVG生成
// =============================================================================
export function generateWireframeSVG(input: WireframeInput): string {
  const W = 1200, H = 800;
  const parts: string[] = [
    `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${W} ${H}" width="${W}" height="${H}">`,
    `<rect width="${W}" height="${H}" fill="#fafafa" stroke="#333" stroke-width="2"/>`,
    `<text x="${W / 2}" y="30" text-anchor="middle" font-size="20" font-weight="bold" font-family="sans-serif">${input.screenName}</text>`,
  ];

  let y = 50;
  const sidebarWidth = 200;
  const mainX = sidebarWidth + 20;
  const mainW = W - sidebarWidth - 40;

  for (const s of input.sections) {
    const h = parseInt(s.height ?? '80');
    switch (s.type) {
      case 'header':
        parts.push(`<rect x="20" y="${y}" width="${W - 40}" height="${h}" fill="#333" />`);
        parts.push(`<text x="40" y="${y + h / 2 + 6}" fill="white" font-size="16" font-family="sans-serif">${s.title ?? 'ヘッダー'}</text>`);
        y += h + 10;
        break;
      case 'sidebar':
        parts.push(`<rect x="20" y="${y}" width="${sidebarWidth}" height="${H - y - 50}" fill="#e0e0e0" stroke="#999"/>`);
        parts.push(`<text x="30" y="${y + 20}" font-size="14" font-weight="bold" font-family="sans-serif">${s.title ?? 'サイドバー'}</text>`);
        (s.items ?? []).forEach((it, i) => {
          parts.push(`<text x="30" y="${y + 45 + i * 24}" font-size="12" font-family="sans-serif">▸ ${it}</text>`);
        });
        break;
      case 'main':
        parts.push(`<rect x="${mainX}" y="${y}" width="${mainW}" height="${h}" fill="white" stroke="#ccc"/>`);
        parts.push(`<text x="${mainX + 10}" y="${y + 20}" font-size="14" font-weight="bold" font-family="sans-serif">${s.title ?? 'メインコンテンツ'}</text>`);
        y += h + 10;
        break;
      case 'table':
        parts.push(`<rect x="${mainX}" y="${y}" width="${mainW}" height="${h}" fill="white" stroke="#ccc"/>`);
        parts.push(`<text x="${mainX + 10}" y="${y + 20}" font-size="14" font-weight="bold" font-family="sans-serif">${s.title ?? 'テーブル'}</text>`);
        parts.push(`<line x1="${mainX}" y1="${y + 30}" x2="${mainX + mainW}" y2="${y + 30}" stroke="#333"/>`);
        (s.items ?? []).slice(0, 5).forEach((it, i) => {
          parts.push(`<text x="${mainX + 10}" y="${y + 55 + i * 20}" font-size="11" font-family="sans-serif">${it}</text>`);
        });
        y += h + 10;
        break;
      case 'form':
        parts.push(`<rect x="${mainX}" y="${y}" width="${mainW}" height="${h}" fill="#f5f5f5" stroke="#ccc"/>`);
        parts.push(`<text x="${mainX + 10}" y="${y + 20}" font-size="14" font-weight="bold" font-family="sans-serif">${s.title ?? 'フォーム'}</text>`);
        (s.items ?? []).forEach((it, i) => {
          const fy = y + 40 + i * 35;
          parts.push(`<text x="${mainX + 10}" y="${fy + 15}" font-size="11" font-family="sans-serif">${it}</text>`);
          parts.push(`<rect x="${mainX + 200}" y="${fy}" width="${mainW - 220}" height="25" fill="white" stroke="#999"/>`);
        });
        y += h + 10;
        break;
      case 'card':
        parts.push(`<rect x="${mainX}" y="${y}" width="${mainW}" height="${h}" fill="white" stroke="#0a7" stroke-width="2"/>`);
        parts.push(`<text x="${mainX + 10}" y="${y + 24}" font-size="14" font-weight="bold" font-family="sans-serif" fill="#0a7">${s.title ?? 'カード'}</text>`);
        y += h + 10;
        break;
      case 'chart':
        parts.push(`<rect x="${mainX}" y="${y}" width="${mainW}" height="${h}" fill="white" stroke="#ccc"/>`);
        parts.push(`<text x="${mainX + 10}" y="${y + 20}" font-size="14" font-weight="bold" font-family="sans-serif">${s.title ?? 'グラフ'}</text>`);
        // ダミーのバー
        [60, 80, 40, 90, 70].forEach((v, i) => {
          parts.push(`<rect x="${mainX + 40 + i * 50}" y="${y + h - v - 5}" width="30" height="${v}" fill="#0077cc"/>`);
        });
        y += h + 10;
        break;
      case 'footer':
        parts.push(`<rect x="20" y="${H - 50}" width="${W - 40}" height="40" fill="#eee" stroke="#ccc"/>`);
        parts.push(`<text x="${W / 2}" y="${H - 25}" text-anchor="middle" font-size="11" font-family="sans-serif">${s.title ?? 'フッター'}</text>`);
        break;
    }
  }

  parts.push('</svg>');
  return parts.join('\n');
}

// =============================================================================
// データフロー図生成 (Mermaid)
// =============================================================================
export function generateDataFlow(input: DataFlowInput): string {
  const lines: string[] = ['flowchart LR'];
  const shapes: Record<string, (id: string, label: string) => string> = {
    client: (id, label) => `  ${id}([${label}])`,
    api: (id, label) => `  ${id}[${label}]`,
    db: (id, label) => `  ${id}[(${label})]`,
    external: (id, label) => `  ${id}{{${label}}}`,
    queue: (id, label) => `  ${id}>${label}]`,
  };

  for (const n of input.nodes) lines.push(shapes[n.type](n.id, n.label));
  for (const f of input.flows) {
    const label = f.method ? `${f.method} ${f.label}` : f.label;
    lines.push(`  ${f.from} -->|${label}| ${f.to}`);
  }
  return lines.join('\n');
}

// =============================================================================
// 統合: 設計確認ドキュメント生成
// =============================================================================
export interface DesignPackage {
  projectName: string;
  er?: ERDiagramInput;
  screenFlow?: ScreenFlowInput;
  wireframes?: WireframeInput[];
  dataFlow?: DataFlowInput;
}

export interface ConfirmationDocument {
  markdown: string;
  artifacts: {
    'er.mmd'?: string;
    'flow.mmd'?: string;
    'dataflow.mmd'?: string;
    [key: `wireframe_${string}.svg`]: string;
  };
}

export function buildConfirmationDocument(pkg: DesignPackage): ConfirmationDocument {
  const artifacts: ConfirmationDocument['artifacts'] = {};
  const sections: string[] = [`# ${pkg.projectName} 設計確認書`, '', '生成日時: ' + new Date().toISOString(), ''];

  if (pkg.er) {
    artifacts['er.mmd'] = generateERDiagram(pkg.er);
    sections.push('## 📊 ER図', '```mermaid', artifacts['er.mmd'], '```', '');
    sections.push(`### エンティティ一覧 (${pkg.er.entities.length}件)`);
    for (const e of pkg.er.entities) {
      sections.push(`- **${e.name}**${e.ja ? ` (${e.ja})` : ''}: ${e.fields.map(f => f.name).join(', ')}`);
    }
    sections.push('');
  }

  if (pkg.screenFlow) {
    artifacts['flow.mmd'] = generateScreenFlow(pkg.screenFlow);
    sections.push('## 🗺 画面遷移図', '```mermaid', artifacts['flow.mmd'], '```', '');
    sections.push(`### 画面一覧 (${pkg.screenFlow.screens.length}画面)`);
    for (const s of pkg.screenFlow.screens) {
      sections.push(`- **${s.name}** (${s.id})${s.role ? ` [${s.role}]` : ''}`);
    }
    sections.push('');
  }

  if (pkg.wireframes) {
    sections.push('## 🖼 ワイヤーフレーム', '');
    for (const wf of pkg.wireframes) {
      const key = `wireframe_${wf.screenName}.svg`;
      artifacts[key as `wireframe_${string}.svg`] = generateWireframeSVG(wf);
      sections.push(`### ${wf.screenName}`, `![${wf.screenName}](./${key})`, '');
    }
  }

  if (pkg.dataFlow) {
    artifacts['dataflow.mmd'] = generateDataFlow(pkg.dataFlow);
    sections.push('## 🔀 データフロー', '```mermaid', artifacts['dataflow.mmd'], '```', '');
  }

  sections.push('---', '## ✅ 承認確認', '', '以下の設計で実装を開始します。修正があれば具体的にご指示ください（無言=承認）。', '');
  sections.push('- [ ] ER図は妥当か');
  sections.push('- [ ] 画面遷移は網羅されているか');
  sections.push('- [ ] 権限（ロール）設計は正しいか');
  sections.push('- [ ] ワイヤーフレームの粒度は十分か');
  sections.push('- [ ] 日本法令・業種要件が反映されているか');

  return { markdown: sections.join('\n'), artifacts };
}

// =============================================================================
// ユーティリティ: ドメイン辞書から ER を推論
// =============================================================================
export function inferEROfromDomain(domain: { mandatory_fields?: Record<string, string[]>; terminology?: Record<string, string> }): ERDiagramInput {
  const entities: ERDiagramInput['entities'] = [];
  const mf = domain.mandatory_fields ?? {};

  for (const [name, fields] of Object.entries(mf)) {
    entities.push({
      name: name.replace(/[^a-z_]/gi, '_'),
      ja: name,
      fields: [
        { name: 'id', type: 'string', pk: true },
        ...fields.map(f => ({ name: f.replace(/[^a-z_0-9]/gi, '_').toLowerCase(), type: 'string', ja: f })),
        { name: 'created_at', type: 'datetime' },
        { name: 'updated_at', type: 'datetime' },
      ],
    });
  }

  return { entities, relations: [] };
}
