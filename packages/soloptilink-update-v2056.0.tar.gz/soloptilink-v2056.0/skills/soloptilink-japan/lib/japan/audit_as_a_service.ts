/**
 * audit_as_a_service.ts — Audit-as-a-Service (Phase 46-CC Centurion)
 *
 * 顧客企業ごとに 年次/四半期/月次 の自動監査レポート (.md / .json / 取締役会PDF素材) を生成する。
 * Claude Code が構造的に作れない領域:
 *   - スケジュール契約 (年次=決算月起点 / 四半期=四半期末+5営業日 / 月次=月初3営業日)
 *   - 上場企業の有価証券報告書添付想定の証跡フォーマット
 *   - 監査委員会/監査役会への提出フォーマット (会社法 381条/399条の2)
 *   - 内部統制報告書 (J-SOX) との整合確認
 *
 * Author: Session J-INTEGRATE / v2037.0 Governance Centurion
 * License: 配布対象
 */

import { aggregateCenturion, type CenturionAggregate, type RegulatorProfile } from './governance_hub_xphase';

export type AuditFrequency = 'annual' | 'quarterly' | 'monthly' | 'on_demand';

export interface AuditContract {
  customer_id: string;
  company_name: string;
  fiscal_year_end: string;        // "03-31" 等 (MM-DD)
  profile: RegulatorProfile;
  frequency: AuditFrequency;
  recipient_type: 'audit_committee' | 'kansa_yaku' | 'board' | 'kansa_iin'; // 監査委員会/監査役会/取締役会
  start_date: string;             // ISO date
  notification_email?: string;
  output_dir?: string;
}

export interface AuditReport {
  report_id: string;
  contract: AuditContract;
  period: { from: string; to: string };
  generated_at: string;
  summary: {
    overall_score: number;
    overall_status: 'pass' | 'warning' | 'fail';
    critical_gaps: number;
    laws_changed_in_period: string[];
  };
  centurion: CenturionAggregate;
  exec_summary_md: string;        // 経営層向け 1ページ
  detail_md: string;              // 監査部門向け 詳細
  evidence_paths: string[];       // 根拠ファイル一覧
  next_action_items: ActionItem[];
}

export interface ActionItem {
  id: string;
  severity: 'critical' | 'high' | 'medium' | 'low';
  category: string;
  title: string;
  due_date: string;
  responsible_role: string;
  related_law?: string;
}

/** 営業日計算 (日本祝日簡易考慮: ±なし、土日のみskip) */
function addBusinessDays(date: Date, days: number): Date {
  const result = new Date(date);
  let added = 0;
  while (added < days) {
    result.setDate(result.getDate() + 1);
    const dow = result.getDay();
    if (dow !== 0 && dow !== 6) added++;
  }
  return result;
}

/** 監査契約の次回実行日を算出 */
export function nextAuditRun(contract: AuditContract, basis = new Date()): Date {
  switch (contract.frequency) {
    case 'annual': {
      const [mm, dd] = contract.fiscal_year_end.split('-').map(Number);
      const yr = basis.getMonth() + 1 > mm ? basis.getFullYear() + 1 : basis.getFullYear();
      const fyEnd = new Date(yr, mm - 1, dd);
      return addBusinessDays(fyEnd, 30); // 決算30営業日後
    }
    case 'quarterly': {
      const month = basis.getMonth();
      const qEndMonth = Math.floor(month / 3) * 3 + 2; // 0,3,6,9 → 2,5,8,11
      const qEnd = new Date(basis.getFullYear(), qEndMonth + 1, 0); // 月末
      return addBusinessDays(qEnd, 5);
    }
    case 'monthly': {
      const monthStart = new Date(basis.getFullYear(), basis.getMonth() + 1, 1);
      return addBusinessDays(monthStart, 3);
    }
    case 'on_demand':
      return basis;
  }
}

/** 監査期間の算出 */
function auditPeriod(contract: AuditContract, runDate: Date): { from: string; to: string } {
  const to = new Date(runDate);
  const from = new Date(runDate);
  switch (contract.frequency) {
    case 'annual': from.setFullYear(from.getFullYear() - 1); break;
    case 'quarterly': from.setMonth(from.getMonth() - 3); break;
    case 'monthly': from.setMonth(from.getMonth() - 1); break;
    case 'on_demand': from.setDate(from.getDate() - 1); break;
  }
  return { from: from.toISOString().slice(0, 10), to: to.toISOString().slice(0, 10) };
}

/** 経営層向け1ページサマリ Markdown 生成 (取締役会・監査委員会への提出用) */
function renderExecSummary(contract: AuditContract, agg: CenturionAggregate, period: { from: string; to: string }, gaps: number): string {
  const status = agg.weighted_score >= 90 ? '✅ 良好' : agg.weighted_score >= 75 ? '⚠️ 要改善' : '🚨 重大不備';
  const recipientName = {
    audit_committee: '監査等委員会',
    kansa_yaku: '監査役会',
    board: '取締役会',
    kansa_iin: '監査委員会',
  }[contract.recipient_type];

  return `# ${contract.company_name} - ガバナンス監査結果報告

**提出先**: ${recipientName}
**監査期間**: ${period.from} 〜 ${period.to}
**プロファイル**: ${contract.profile}
**監査実施**: SoloptiLinkAI Centurion (v2037.0)

## 総合評価: ${status}

| 指標 | 値 | 基準 |
|---|---:|---:|
| 加重総合スコア | **${agg.weighted_score} / 100** | 90以上で良好 |
| 単純総合スコア | ${agg.raw_score} / 100 | - |
| 軸合格率 | ${agg.passed_axes} / ${agg.total_axes} 軸 | - |
| ガバナンス充足率 (SSBJ) | **${agg.governance_fill_rate}%** | 80%以上で開示準備完了 |
| CG Code R6 準拠率 | **${agg.cg_code_r6_mapping.comply_rate}%** | Prime Market 80%以上推奨 |
| J-SOX 監査対応 | ${agg.jsox_audit_ready ? '✅ 準備完了' : '⚠️ 未対応軸あり'} | - |
| 重大ギャップ件数 | ${gaps} 件 | 0件目標 |

## SSBJ 開示準備状況

- D1 (一般要求事項): ${agg.ssbj_d1_d2_mapping.d1_general.covered ?? '判定不能'} / ${agg.ssbj_d1_d2_mapping.d1_general.total} 項目カバー
- D2 (気候関連): ${agg.ssbj_d1_d2_mapping.d2_climate.covered ?? '判定不能'} / ${agg.ssbj_d1_d2_mapping.d2_climate.total} 項目カバー
- 開示準備: **${
  agg.ssbj_d1_d2_mapping.ready_for_disclosure === null
    ? '判定不能 (未完了と断定できるものではありません)'
    : agg.ssbj_d1_d2_mapping.ready_for_disclosure ? '完了' : '未完了'
}**${agg.ssbj_d1_d2_mapping.reason_ja ? `\n- 判定の但し書き: ${agg.ssbj_d1_d2_mapping.reason_ja}` : ''}

${agg.ssbj_d1_d2_mapping.ready_for_disclosure === true ? '' : `### ${
  agg.ssbj_d1_d2_mapping.ready_for_disclosure === null ? '未確認項目 (不足と確定したものではありません)' : '不足項目'
}
${(agg.ssbj_d1_d2_mapping.ready_for_disclosure === null
    ? agg.ssbj_d1_d2_mapping.d1_general.unverified
    : agg.ssbj_d1_d2_mapping.d1_general.missing).map(m => `- D1: ${m}`).join('\n')}
${(agg.ssbj_d1_d2_mapping.ready_for_disclosure === null
    ? agg.ssbj_d1_d2_mapping.d2_climate.unverified
    : agg.ssbj_d1_d2_mapping.d2_climate.missing).map(m => `- D2: ${m}`).join('\n')}`}

## 改善優先 TOP 5

${agg.top_gaps.slice(0, 5).map((g, i) =>
  `${i + 1}. **${g.phase}** (${g.category}) — ${g.passed}/${g.axes} 軸PASS / 関連法令: ${g.laws.slice(0, 3).join('・') || '-'}`).join('\n')}

## 法的根拠

- 会社法 第381条 (監査役の権限) / 第399条の2 (監査等委員会)
- 金融商品取引法 第24条の4の4 (内部統制報告書)
- コーポレートガバナンス・コード R6 改訂版 (2024年6月)
- SSBJ 適用基準書 D1/D2 (R8.4.1施行)

---

*本報告書は SoloptiLinkAI Audit-as-a-Service v2037.0 により自動生成。*
*改ざん検知: SHA-256 (出力時に追記)。*
`;
}

/** 詳細レポート Markdown 生成 (監査部門/内部監査室向け) */
function renderDetailReport(agg: CenturionAggregate, items: ActionItem[]): string {
  return `## カテゴリ別詳細

| カテゴリ | スコア | 軸PASS率 |
|---|---:|---:|
${Object.entries(agg.by_category).map(([k, v]) =>
  `| ${k} | ${Math.round(v.score)}/100 | ${v.passed}/${v.axes} (${Math.round(v.passed / v.axes * 100)}%) |`).join('\n')}

## CG Code R6 詳細マッピング

### 5原則
${Object.entries(agg.cg_code_r6_mapping.basic_principles)
  .map(([k, v]) => `- ${k}: **${v}**`).join('\n')}

### 補充原則 (2021/2024 改訂)
${Object.entries(agg.cg_code_r6_mapping.supplementary)
  .map(([k, v]) => `- ${k}: **${v}**`).join('\n')}

### Prime Market 限定原則
${Object.entries(agg.cg_code_r6_mapping.prime_only)
  .map(([k, v]) => `- ${k}: **${v}**`).join('\n')}

## アクションアイテム

| # | 重要度 | カテゴリ | タイトル | 期限 | 責任者 | 関連法令 |
|---|---|---|---|---|---|---|
${items.map((it, i) =>
  `| ${i + 1} | ${it.severity} | ${it.category} | ${it.title} | ${it.due_date} | ${it.responsible_role} | ${it.related_law ?? '-'} |`).join('\n')}

## ギャップ分析 全件

${agg.top_gaps.map(g => `### ${g.phase}
- カテゴリ: ${g.category}
- スコア: ${g.score}/100
- 軸: ${g.passed}/${g.axes}
- 関連法令: ${g.laws.join('、')}
- 根拠ファイル: ${(g.evidence ?? []).join(', ') || '-'}
`).join('\n')}
`;
}

/** Top gaps からアクションアイテムを生成 */
function deriveActionItems(agg: CenturionAggregate, runDate: Date): ActionItem[] {
  const due90 = addBusinessDays(runDate, 90 * 5 / 7).toISOString().slice(0, 10);
  const due30 = addBusinessDays(runDate, 30 * 5 / 7).toISOString().slice(0, 10);

  return agg.top_gaps.slice(0, 10).map((g, i) => {
    const passRate = g.passed / Math.max(g.axes, 1);
    const severity: ActionItem['severity'] =
      passRate < 0.5 ? 'critical' : passRate < 0.75 ? 'high' : passRate < 0.9 ? 'medium' : 'low';
    return {
      id: `aim-${runDate.getTime()}-${i}`,
      severity,
      category: g.category,
      title: `${g.phase} 軸不足 (${g.axes - g.passed}件) の解消`,
      due_date: severity === 'critical' ? due30 : due90,
      responsible_role: g.category === 'governance' ? '内部統制責任者' :
                        g.category === 'security' ? 'CISO' :
                        g.category === 'finance' ? 'CFO' : '担当事業部長',
      related_law: g.laws[0],
    };
  });
}

/** 監査レポート1件を生成 */
export async function runAudit(contract: AuditContract, runDate = new Date()): Promise<AuditReport> {
  const agg = await aggregateCenturion(contract.profile);
  const period = auditPeriod(contract, runDate);
  const items = deriveActionItems(agg, runDate);
  const criticalGaps = items.filter(i => i.severity === 'critical' || i.severity === 'high').length;
  const status: 'pass' | 'warning' | 'fail' =
    agg.weighted_score >= 90 ? 'pass' :
    agg.weighted_score >= 75 ? 'warning' : 'fail';

  const evidencePaths = agg.top_gaps.flatMap(g => g.evidence ?? []);

  return {
    report_id: `audit-${contract.customer_id}-${runDate.getTime()}`,
    contract,
    period,
    generated_at: runDate.toISOString(),
    summary: {
      overall_score: agg.weighted_score,
      overall_status: status,
      critical_gaps: criticalGaps,
      laws_changed_in_period: [], // law_realtime_tracker から注入される (cross-call)
    },
    centurion: agg,
    exec_summary_md: renderExecSummary(contract, agg, period, criticalGaps),
    detail_md: renderDetailReport(agg, items),
    evidence_paths: evidencePaths,
    next_action_items: items,
  };
}

/** 監査スケジュールリストを契約から導出 (12ヶ月分先読み) */
export function scheduleAudits(contract: AuditContract, monthsAhead = 12): Date[] {
  const out: Date[] = [];
  let cursor = new Date();
  for (let i = 0; i < monthsAhead && out.length < 24; i++) {
    cursor = nextAuditRun(contract, cursor);
    out.push(new Date(cursor));
    cursor.setDate(cursor.getDate() + 1); // 次回計算用に1日進める
  }
  return out;
}
