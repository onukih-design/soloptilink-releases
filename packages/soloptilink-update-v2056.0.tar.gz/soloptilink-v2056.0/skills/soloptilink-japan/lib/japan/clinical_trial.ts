/**
 * SoloptiLinkAI Phase 42-HC — Clinical Trial Data Management (治験データ管理)
 *
 * GCP (Good Clinical Practice) 準拠の治験データ管理基盤。
 *
 * カバー範囲:
 *  - GCP / J-GCP 基本原則
 *  - ICH-GCP E6(R3) 13原則
 *  - 治験届 + IRB (治験審査委員会) 承認フロー
 *  - 同意取得 (IC: Informed Consent) - 撤回可能性
 *  - EDC (Electronic Data Capture) + e-CRF (Case Report Form)
 *  - SDV (Source Data Verification) サンプリング
 *  - 治験薬管理 (受領/保管/払出/回収/廃棄)
 *  - 重篤な有害事象 (SAE) 報告 (24時間 / 7日 / 15日)
 *  - 監査証跡 (21 CFR Part 11 + ER/ES指針)
 *  - 治験終了 + 総括報告書 (CSR)
 */

// GCP 13原則 (ICH-GCP E6(R3))
export const GCP_PRINCIPLES = [
  "GCP 1. ヘルシンキ宣言準拠",
  "GCP 2. 試験実施前のリスクベネフィット評価",
  "GCP 3. 被験者の権利・安全・福祉が最優先",
  "GCP 4. 治験薬の十分な情報",
  "GCP 5. 科学的に妥当なプロトコル",
  "GCP 6. IRB承認後実施",
  "GCP 7. 医学的判断は医師が担当",
  "GCP 8. 業務遂行能力のある実施者",
  "GCP 9. インフォームドコンセント",
  "GCP 10. データ正確性 + 検証可能性",
  "GCP 11. 機密保持",
  "GCP 12. GMP準拠の治験薬",
  "GCP 13. QMS (Quality Management System) 構築",
] as const;

// 治験フェーズ
export type TrialPhase = "preclinical" | "phase1" | "phase2" | "phase3" | "phase4" | "post_marketing";

export interface ClinicalTrialProtocol {
  protocol_id: string;
  title: string;
  phase: TrialPhase;
  sponsor: string;
  cro?: string; // Contract Research Organization
  sites: { site_id: string; name: string; pi: string }[]; // 治験責任医師
  target_indication: string;
  primary_endpoint: string;
  secondary_endpoints: string[];
  target_subjects: number;
  inclusion_criteria: string[];
  exclusion_criteria: string[];
  duration_weeks: number;
  irb_approved: boolean;
  pmda_filed: boolean;
}

// IRB (治験審査委員会) 審査
export type IrbDecision = "approved" | "conditionally_approved" | "rejected" | "deferred";

export interface IrbReview {
  protocol_id: string;
  review_date: string;
  members_attended: number;
  members_total: number;
  external_member_attended: boolean; // 外部委員の出席必須
  decision: IrbDecision;
  conditions?: string[];
  next_review_date: string;
}

export function isIrbReviewValid(review: IrbReview): { valid: boolean; reasons: string[] } {
  const reasons: string[] = [];
  if (review.members_attended < 5) reasons.push("出席委員5名未満 (定足数不足)");
  if (review.members_attended < review.members_total / 2) reasons.push("過半数未出席");
  if (!review.external_member_attended) reasons.push("外部委員不在 (1名以上必須)");
  return { valid: reasons.length === 0, reasons };
}

// インフォームドコンセント (IC)
export interface InformedConsent {
  subject_id: string;
  consent_at: string;
  consent_version: string;
  signature_method: "wet_ink" | "electronic" | "biometric";
  witness_id?: string; // 同席者
  withdrawn?: boolean;
  withdrawal_at?: string;
  withdrawal_reason?: string;
}

export function isConsentValidNow(consent: InformedConsent): boolean {
  if (consent.withdrawn) return false;
  return true;
}

// EDC + e-CRF
export interface CrfEntry {
  crf_id: string;
  subject_id: string;
  visit: string; // "Screening" | "Day 1" | "Week 4" | ...
  collected_at: string;
  collected_by: string;
  data: Record<string, unknown>;
  is_locked: boolean;
  edit_history: { ts: string; actor: string; before: unknown; after: unknown; reason: string }[];
}

// データ修正は必ず理由付き履歴 (ALCOA+ 原則)
export class CrfLockedError extends Error {
  constructor(crf_id: string) {
    super(`CRF ${crf_id} is locked, modifications not allowed`);
    this.name = "CrfLockedError";
  }
}

export function editCrfField(
  crf: CrfEntry,
  field: string,
  newValue: unknown,
  actor: string,
  reason: string,
): CrfEntry {
  if (crf.is_locked) throw new CrfLockedError(crf.crf_id);
  const before = crf.data[field];
  return {
    ...crf,
    data: { ...crf.data, [field]: newValue },
    edit_history: [
      ...crf.edit_history,
      { ts: new Date().toISOString(), actor, before, after: newValue, reason },
    ],
  };
}

// SDV (Source Data Verification) サンプリング
export interface SdvPlan {
  protocol_id: string;
  sampling_strategy: "100_percent" | "key_data_only" | "risk_based";
  key_fields: string[]; // 主要評価項目関連フィールド
  sampling_rate?: number; // risk_based の場合 0-1
}

export function selectSdvTargets(crfs: CrfEntry[], plan: SdvPlan): CrfEntry[] {
  if (plan.sampling_strategy === "100_percent") return crfs;
  if (plan.sampling_strategy === "key_data_only") {
    return crfs.filter((c) => plan.key_fields.some((f) => c.data[f] !== undefined));
  }
  // risk_based
  const rate = plan.sampling_rate ?? 0.2;
  const target = Math.ceil(crfs.length * rate);
  return crfs.slice(0, target);
}

// 治験薬管理
export type IpStatus = "shipped" | "received" | "stored" | "dispensed" | "returned" | "destroyed";

export interface InvestigationalProductLot {
  ip_lot_no: string;
  protocol_id: string;
  site_id: string;
  expiry_date: string;
  storage_temp_required: { min_celsius: number; max_celsius: number };
  current_temperature_log?: { ts: string; celsius: number }[];
}

export function detectTemperatureExcursion(
  lot: InvestigationalProductLot,
): { excursions: { ts: string; celsius: number; deviation: number }[]; total_hours_out_of_range: number } {
  const excursions: { ts: string; celsius: number; deviation: number }[] = [];
  let totalMinutesOOR = 0;
  const log = lot.current_temperature_log ?? [];
  for (let i = 0; i < log.length; i++) {
    const r = log[i];
    let dev = 0;
    if (r.celsius < lot.storage_temp_required.min_celsius) dev = r.celsius - lot.storage_temp_required.min_celsius;
    else if (r.celsius > lot.storage_temp_required.max_celsius) dev = r.celsius - lot.storage_temp_required.max_celsius;
    if (dev !== 0) {
      excursions.push({ ts: r.ts, celsius: r.celsius, deviation: dev });
      // 簡略: 各サンプル間隔を 60分とみなす
      if (i > 0) totalMinutesOOR += 60;
    }
  }
  return { excursions, total_hours_out_of_range: Math.round(totalMinutesOOR / 60) };
}

// 重篤な有害事象 (SAE: Serious Adverse Event) 報告
export type SaeOutcome = "death" | "life_threatening" | "hospitalization" | "disability" | "congenital_anomaly" | "other_significant";

export interface SeriousAdverseEvent {
  sae_id: string;
  subject_id: string;
  protocol_id: string;
  occurred_at: string;
  reported_at: string;
  outcome: SaeOutcome;
  causality: "unrelated" | "unlikely" | "possible" | "probable" | "definite";
  is_unexpected: boolean; // プロトコルや治験薬概要書に記載なし
  pmda_report_deadline_days: number;
  irb_report_deadline_days: number;
  sponsor_notification_hours: number;
}

export function classifySaeReporting(input: {
  outcome: SaeOutcome;
  is_unexpected: boolean;
  causality: SeriousAdverseEvent["causality"];
}): { pmda_days: number; irb_days: number; sponsor_hours: number; reasoning: string[] } {
  const reasons: string[] = [];
  // SUSAR (Suspected Unexpected Serious Adverse Reaction)
  const isSusar = input.is_unexpected
    && (input.causality === "possible" || input.causality === "probable" || input.causality === "definite");

  if (input.outcome === "death" || input.outcome === "life_threatening") {
    reasons.push("死亡 / 生命の危機 → PMDA 7日以内 (国内) / 15日以内 (海外)");
    return {
      pmda_days: 7,
      irb_days: 15,
      sponsor_hours: 24,
      reasoning: reasons,
    };
  }
  if (isSusar) {
    reasons.push("SUSAR (未知 + 関連性あり) → PMDA 15日以内");
    return { pmda_days: 15, irb_days: 30, sponsor_hours: 24, reasoning: reasons };
  }
  reasons.push("既知のSAE → 定期報告 (年1回)");
  return { pmda_days: 365, irb_days: 30, sponsor_hours: 168, reasoning: reasons };
}

// 21 CFR Part 11 / ER/ES 指針 監査証跡
export interface AuditTrailEntry {
  entry_id: string;
  ts: string;
  actor: string;
  action: "create" | "read" | "update" | "delete" | "lock" | "unlock" | "sign";
  entity_type: string; // "CRF" | "Subject" | "Protocol"
  entity_id: string;
  before?: unknown;
  after?: unknown;
  reason?: string; // 変更理由 (Part 11 必須)
  electronic_signature?: { user_id: string; meaning: string; ts: string };
}

export function isPart11Compliant(entries: AuditTrailEntry[]): { compliant: boolean; missing: string[] } {
  const missing: string[] = [];
  const updates = entries.filter((e) => e.action === "update" || e.action === "delete");
  const updatesWithoutReason = updates.filter((e) => !e.reason);
  if (updatesWithoutReason.length > 0) {
    missing.push(`理由未記載の変更/削除: ${updatesWithoutReason.length}件 (Part 11違反)`);
  }
  const signs = entries.filter((e) => e.action === "sign");
  const signsWithoutMeaning = signs.filter((e) => !e.electronic_signature?.meaning);
  if (signsWithoutMeaning.length > 0) {
    missing.push(`署名意味未記載: ${signsWithoutMeaning.length}件`);
  }
  return { compliant: missing.length === 0, missing };
}
