/**
 * i18n - 多言語化レイヤー (Phase 3)
 *
 * JAPAN-NATIVE Mode の成果物を英語・中国語（簡体字）にも対応させる。
 * 日本語をプライマリとしつつ、翻訳辞書で他言語を提供。
 */

export type Locale = 'ja' | 'en' | 'zh-CN';

export interface TranslationSet {
  // 帳票タイトル
  invoice: string;
  estimate: string;
  purchase_order: string;
  delivery_note: string;
  receipt: string;
  inspection_report: string;
  payment_notice: string;
  withholding_slip: string;
  payment_report: string;
  contract: string;
  nda: string;
  service_agreement: string;
  memorandum: string;
  notification: string;
  application: string;
  report: string;
  meeting_minutes: string;
  internal_notice: string;
  quotation: string;
  requisition: string;

  // 共通ラベル
  issue_date: string;
  due_date: string;
  subject: string;
  amount: string;
  subtotal: string;
  tax: string;
  total: string;
  honorific_company: string;        // 御中 / Messrs.
  honorific_person: string;         // 様 / Mr./Ms.
  quantity: string;
  unit_price: string;
  description: string;
  remarks: string;
  date_of_issue: string;
  registration_number: string;

  // 税率区分
  tax_standard: string;
  tax_reduced: string;
  tax_exempt: string;
  tax_nontaxable: string;

  // 敬語挨拶
  greeting_customer: string;
  closing_formal: string;
  thanks_patronage: string;

  // 帳票本文 (Phase 6 追加)
  invoice_intro: string;           // 請求書冒頭: いつも格別のお引き立て…
  estimate_intro: string;          // 見積書冒頭: 下記の通りお見積り…
  delivery_intro: string;          // 納品書冒頭: 下記の通り納品…
  payment_notice_intro: string;    // 支払通知冒頭
  order_confirmation: string;      // 請書文面: ご注文ありがとうございます…

  // 契約本文
  contract_parties_intro: string;  // "甲と乙は、以下のとおり契約を締結する"
  contract_execution_clause: string; // "本契約の成立を証するため、本書2通を作成し…"
  jurisdiction_label: string;      // 管轄裁判所
  contract_period_label: string;   // 契約期間
  contract_value_label: string;    // 契約金額
  stamp_duty_notice: string;       // "本契約書は印紙税法により…"

  // 通知・申請系
  notice_action_required: string;  // 必要対応
  notice_effective_date: string;   // 発効日
  notice_contact: string;          // お問い合わせ先
  approval_matrix_header: string;  // 承認欄

  // 共通ステータス
  approved: string;
  rejected: string;
  pending: string;
  received_stamp: string;          // 受領印
  seal_mark: string;               // 印
  closing_kashiko: string;         // "以上"
}

const ja: TranslationSet = {
  invoice: '請求書',
  estimate: '御見積書',
  purchase_order: '注文書',
  delivery_note: '納品書',
  receipt: '領収書',
  inspection_report: '検収書',
  payment_notice: '支払通知書',
  withholding_slip: '源泉徴収票',
  payment_report: '支払調書',
  contract: '契約書',
  nda: '秘密保持契約書',
  service_agreement: '業務委託契約書',
  memorandum: '覚書',
  notification: '通知書',
  application: '申請書',
  report: '報告書',
  meeting_minutes: '議事録',
  internal_notice: '社内通達',
  quotation: '請書',
  requisition: '稟議書',
  issue_date: '発行日',
  due_date: 'お支払期日',
  subject: '件名',
  amount: '金額',
  subtotal: '小計',
  tax: '消費税',
  total: '合計',
  honorific_company: '御中',
  honorific_person: '様',
  quantity: '数量',
  unit_price: '単価',
  description: '品目',
  remarks: '備考',
  date_of_issue: '発行日',
  registration_number: '登録番号',
  tax_standard: '10%（標準税率）',
  tax_reduced: '8%（軽減税率）',
  tax_exempt: '非課税',
  tax_nontaxable: '不課税',
  greeting_customer: '平素より格別のお引き立てを賜り、厚く御礼申し上げます。',
  closing_formal: '今後とも倍旧のお引き立てのほど、よろしくお願い申し上げます。',
  thanks_patronage: 'いつも格別のお引き立てを賜り、厚く御礼申し上げます。',
  invoice_intro: 'いつも格別のお引き立てを賜り、厚く御礼申し上げます。\n下記の通りご請求申し上げますので、お支払いくださいますようお願い申し上げます。',
  estimate_intro: '下記の通りお見積り申し上げます。\nご検討のほど、よろしくお願い申し上げます。',
  delivery_intro: '下記の通り納品いたしましたので、ご査収のほどお願い申し上げます。',
  payment_notice_intro: '平素よりお引き立ていただきありがとうございます。下記の通りお支払いいたしますのでご確認ください。',
  order_confirmation: 'ご注文ありがとうございます。下記の通りご注文をお受けいたしますので、ご確認の程よろしくお願い申し上げます。',
  contract_parties_intro: '甲と乙は、以下のとおり契約を締結する。',
  contract_execution_clause: '本契約の成立を証するため、本書2通を作成し、甲乙各自記名押印の上、各1通を保有する。',
  jurisdiction_label: '管轄裁判所',
  contract_period_label: '契約期間',
  contract_value_label: '契約金額',
  stamp_duty_notice: '本契約書は印紙税法により収入印紙貼付が必要です。',
  notice_action_required: '必要対応',
  notice_effective_date: '発効日',
  notice_contact: 'お問い合わせ先',
  approval_matrix_header: '承認',
  approved: '承認',
  rejected: '却下',
  pending: '保留',
  received_stamp: '受領印',
  seal_mark: '印',
  closing_kashiko: '以 上',
};

const en: TranslationSet = {
  invoice: 'INVOICE',
  estimate: 'QUOTATION',
  purchase_order: 'PURCHASE ORDER',
  delivery_note: 'DELIVERY NOTE',
  receipt: 'RECEIPT',
  inspection_report: 'INSPECTION REPORT',
  payment_notice: 'PAYMENT NOTICE',
  withholding_slip: 'WITHHOLDING TAX STATEMENT',
  payment_report: 'PAYMENT REPORT',
  contract: 'CONTRACT',
  nda: 'NON-DISCLOSURE AGREEMENT',
  service_agreement: 'SERVICE AGREEMENT',
  memorandum: 'MEMORANDUM',
  notification: 'NOTIFICATION',
  application: 'APPLICATION',
  report: 'REPORT',
  meeting_minutes: 'MEETING MINUTES',
  internal_notice: 'INTERNAL NOTICE',
  quotation: 'CONFIRMATION OF ORDER',
  requisition: 'PURCHASE REQUISITION',
  issue_date: 'Issue Date',
  due_date: 'Due Date',
  subject: 'Subject',
  amount: 'Amount',
  subtotal: 'Subtotal',
  tax: 'Tax',
  total: 'Total',
  honorific_company: 'Messrs.',
  honorific_person: 'Mr./Ms.',
  quantity: 'Qty',
  unit_price: 'Unit Price',
  description: 'Description',
  remarks: 'Remarks',
  date_of_issue: 'Date of Issue',
  registration_number: 'Registration No.',
  tax_standard: '10% (Standard)',
  tax_reduced: '8% (Reduced)',
  tax_exempt: 'Tax Exempt',
  tax_nontaxable: 'Non-taxable',
  greeting_customer: 'Thank you for your continued patronage.',
  closing_formal: 'We look forward to your continued support.',
  thanks_patronage: 'We sincerely appreciate your business.',
  invoice_intro: 'Thank you for your continued patronage.\nPlease find our invoice below and kindly arrange payment by the due date.',
  estimate_intro: 'Please find our quotation as detailed below.\nWe look forward to your favorable consideration.',
  delivery_intro: 'We hereby confirm that the following items have been delivered. Please verify receipt.',
  payment_notice_intro: 'Thank you for your continued patronage. We hereby notify you of the payment as detailed below.',
  order_confirmation: 'Thank you for your order. We hereby confirm acceptance of your order as detailed below.',
  contract_parties_intro: 'Party A and Party B hereby enter into this agreement as follows.',
  contract_execution_clause: 'In witness whereof, two copies of this agreement have been prepared, signed, and sealed by both parties, each retaining one copy.',
  jurisdiction_label: 'Jurisdiction',
  contract_period_label: 'Contract Period',
  contract_value_label: 'Contract Value',
  stamp_duty_notice: 'This contract requires a revenue stamp under Japanese Stamp Tax Act.',
  notice_action_required: 'Action Required',
  notice_effective_date: 'Effective Date',
  notice_contact: 'Contact',
  approval_matrix_header: 'Approval',
  approved: 'Approved',
  rejected: 'Rejected',
  pending: 'Pending',
  received_stamp: 'Received',
  seal_mark: 'Seal',
  closing_kashiko: '— End —',
};

const zh: TranslationSet = {
  invoice: '发票',
  estimate: '报价单',
  purchase_order: '订单',
  delivery_note: '送货单',
  receipt: '收据',
  inspection_report: '验收报告',
  payment_notice: '付款通知书',
  withholding_slip: '源泉扣缴票',
  payment_report: '支付报告',
  contract: '合同',
  nda: '保密协议',
  service_agreement: '业务委托合同',
  memorandum: '备忘录',
  notification: '通知书',
  application: '申请书',
  report: '报告书',
  meeting_minutes: '会议纪要',
  internal_notice: '内部通告',
  quotation: '接受订单确认书',
  requisition: '采购申请',
  issue_date: '发行日',
  due_date: '付款日期',
  subject: '主题',
  amount: '金额',
  subtotal: '小计',
  tax: '消费税',
  total: '合计',
  honorific_company: '敬启',
  honorific_person: '先生/女士',
  quantity: '数量',
  unit_price: '单价',
  description: '项目',
  remarks: '备注',
  date_of_issue: '发行日期',
  registration_number: '登记号',
  tax_standard: '10%（标准税率）',
  tax_reduced: '8%（减税率）',
  tax_exempt: '免税',
  tax_nontaxable: '非课税',
  greeting_customer: '衷心感谢您一直以来的支持与厚爱。',
  closing_formal: '今后恳请继续赐予支持和合作。',
  thanks_patronage: '衷心感谢您一直以来的惠顾。',
  invoice_intro: '衷心感谢您一直以来的惠顾。\n现将账单明细列示如下，敬请按期支付。',
  estimate_intro: '现将报价明细列示如下。\n敬请审阅，恳请惠予考虑。',
  delivery_intro: '现送交下列物品，敬请查收确认。',
  payment_notice_intro: '衷心感谢您一直以来的惠顾。现将付款明细通知如下，敬请确认。',
  order_confirmation: '衷心感谢您的订购。现将订单明细确认如下，敬请核实。',
  contract_parties_intro: '甲方与乙方根据以下条款订立本合同。',
  contract_execution_clause: '为证明本合同的成立，特制作本合同一式两份，甲乙双方各执一份，均经签字盖章后生效。',
  jurisdiction_label: '管辖法院',
  contract_period_label: '合同期限',
  contract_value_label: '合同金额',
  stamp_duty_notice: '本合同根据日本印花税法需要贴付印花。',
  notice_action_required: '需要的处置',
  notice_effective_date: '生效日',
  notice_contact: '联系方式',
  approval_matrix_header: '审批',
  approved: '已批准',
  rejected: '已拒绝',
  pending: '待处理',
  received_stamp: '签收',
  seal_mark: '印',
  closing_kashiko: '— 以上 —',
};

const TRANSLATIONS: Record<Locale, TranslationSet> = { ja, en, 'zh-CN': zh };

/**
 * 翻訳取得
 */
export function t(key: keyof TranslationSet, locale: Locale = 'ja'): string {
  return TRANSLATIONS[locale][key] ?? TRANSLATIONS.ja[key];
}

/**
 * 現在のロケールで翻訳辞書全体を取得
 */
export function getTranslations(locale: Locale = 'ja'): TranslationSet {
  return TRANSLATIONS[locale];
}

/**
 * 数値フォーマット（通貨・桁区切り・ロケール対応）
 */
export function formatCurrency(amount: number, locale: Locale = 'ja'): string {
  const intl = locale === 'ja' ? 'ja-JP' : locale === 'en' ? 'en-US' : 'zh-CN';
  const currency = locale === 'en' ? 'USD' : 'JPY';
  // デフォルトは円。USD表示は実際の換算が必要なため、ここでは単位の違いだけ。
  return new Intl.NumberFormat(intl, { style: 'currency', currency, maximumFractionDigits: 0 }).format(amount);
}

/**
 * ロケール判定（Accept-Language や cookie から）
 */
export function detectLocale(acceptLanguage?: string): Locale {
  if (!acceptLanguage) return 'ja';
  const lower = acceptLanguage.toLowerCase();
  if (lower.includes('ja')) return 'ja';
  if (lower.includes('zh')) return 'zh-CN';
  if (lower.includes('en')) return 'en';
  return 'ja';
}

/**
 * React Context 向けヘルパー（Hook は別ファイル）
 */
export interface I18nContext {
  locale: Locale;
  t: (key: keyof TranslationSet) => string;
  setLocale: (l: Locale) => void;
}
