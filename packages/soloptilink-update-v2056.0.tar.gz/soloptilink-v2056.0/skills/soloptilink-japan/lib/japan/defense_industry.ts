/**
 * SoloptiLinkAI Phase 45-DEF — 防衛産業 / 防衛装備移転三原則 / 防衛産業基盤強靭化法
 *
 * 既存 export_control.ts (Phase 43-IT 安全保障輸出管理) との役割分離:
 *   export_control = 民生品+デュアルユース品の輸出許可フロー (外為法48条)
 *   defense_industry = 防衛装備品そのもの (殺傷能力含む) の移転判定 + 防衛省特化サプライチェーン保護
 *
 * カバー範囲:
 *  - 防衛装備移転三原則 (H26.4.1 閣議決定 → R4.12.16/R5.12.22 運用指針改定)
 *      H26: 武器輸出三原則の代替/移転禁止例外3類型
 *      R5: 殺傷能力を有する装備品の例外輸出 (国際共同開発+OSA: 政府安全保障能力強化支援)
 *  - 防衛産業基盤強靭化法 (R5.6.7 公布 / R5.10.1 施行)
 *      契約制度4類型 (装備移転仕様変更/サイバーセキュリティ/サプライチェーン/製造施設) の財政支援
 *      指定金融機関による資金繰り支援 + 製造施設の国有化措置 (法22-25条)
 *  - 防衛省 サイバーセキュリティ確保のための統一基準 (R5.4 施行 NIST SP 800-171相当)
 *      防衛調達における情報セキュリティ確保契約条項 16ファミリー110統制項目
 *      Class I/II 区分 (CUI/Non-CUI 相当)
 *  - 特定秘密の保護に関する法律 (H25法108号) 4分野: 防衛/外交/特定有害活動防止/テロリズム防止
 *  - ITAR (22 CFR §120-130) / EAR Cat I-XXI 域外適用 + 海外移転報告
 *  - 防衛省装備庁 ALIS (装備品ライフサイクル管理システム)
 *
 * 出典:
 *  - 防衛省 https://www.mod.go.jp/j/approach/agenda/meeting/equipment_transfer/
 *  - 経産省 安全保障貿易管理 https://www.meti.go.jp/policy/anpo/
 *  - 装備庁 https://www.mod.go.jp/atla/
 */

// ----------------------------------------------------------------------
// 1) 防衛装備移転三原則 (Three Principles on Transfer of Defense Equipment)
// ----------------------------------------------------------------------

/**
 * 三原則の三本柱 (R5.12.22 改定運用指針時点)
 */
export const TRANSFER_PRINCIPLES = {
  prohibited: [
    "国連安保理決議違反の移転",
    "条約・国際約束違反の移転",
    "紛争当事国 (現に武力紛争が発生または認定された国) への移転",
  ],
  permitted_categories: [
    "平和貢献・国際協力の積極的な推進に資する場合",
    "我が国の安全保障に資する場合",
  ],
  strict_review: "目的外使用・第三国移転について我が国の事前同意を相手国政府に義務付ける",
} as const;

/**
 * 移転類型 (R5.12.22 運用指針改定で追加された5類型)
 */
export type TransferCategory =
  | "rescue" // 救難
  | "transport" // 輸送
  | "warning" // 警戒
  | "surveillance" // 監視
  | "minesweeping" // 機雷掃海
  | "license_production" // ライセンス生産品 (R5.12 解禁: 殺傷能力含む)
  | "international_codev" // 国際共同開発・生産品 (F-35/GCAP等)
  | "osa_provision" // 政府安全保障能力強化支援 (OSA) R5.4 創設
  | "ukraine_non_lethal"; // ウクライナ向け非殺傷装備 (R5.4 例外)

export interface TransferEvaluationInput {
  destination_country: string;
  is_un_member: boolean;
  is_armed_conflict_party: boolean; // 紛争当事国 = 武力攻撃が発生または認定された国
  un_arms_embargo_target: boolean; // 国連武器禁輸対象国
  transfer_category: TransferCategory;
  end_use: string; // エンドユース記述
  has_prior_consent_clause: boolean; // 事前同意条項 (目的外使用/第三国移転)
  is_lethal_weapon: boolean; // 殺傷能力を有するか
  is_japan_security_relevant: boolean; // 日本の安全保障に資するか
}

export type TransferDecision =
  | "approved"
  | "approved_with_conditions"
  | "denied_principle_violation"
  | "denied_third_country_concern"
  | "needs_nss_review"; // 国家安全保障会議審議必要

export interface TransferEvaluationResult {
  decision: TransferDecision;
  reason: string;
  required_actions: string[];
  applicable_law_refs: string[]; // 法令参照
}

/**
 * 防衛装備移転三原則の判定エンジン
 * 「武器」概念を「防衛装備」に置換 (H26.4)、移転可能要件を厳格に判定
 */
export function evaluateTransfer(input: TransferEvaluationInput): TransferEvaluationResult {
  // 三原則 第1項: 移転禁止類型
  if (input.un_arms_embargo_target) {
    return {
      decision: "denied_principle_violation",
      reason: "国連安保理決議に基づく武器禁輸対象国 (移転禁止三類型①)",
      required_actions: [],
      applicable_law_refs: ["防衛装備移転三原則 1項①", "外為法48条"],
    };
  }
  if (input.is_armed_conflict_party) {
    return {
      decision: "denied_principle_violation",
      reason: "紛争当事国 (武力攻撃が発生・認定) → 移転禁止 (三原則 1項③)",
      required_actions: [],
      applicable_law_refs: ["防衛装備移転三原則 1項③"],
    };
  }
  // 殺傷能力品 + ライセンス国以外への移転 → R5.12 改定後でも厳格審査
  if (input.is_lethal_weapon && input.transfer_category !== "license_production" && input.transfer_category !== "international_codev") {
    return {
      decision: "needs_nss_review",
      reason: "殺傷能力品の単独移転は国家安全保障会議 (NSS) の個別審議を要する (R5.12 運用指針改定後も例外的取扱)",
      required_actions: [
        "案件単位で国家安全保障会議 (NSS) 9大臣会合での個別審議",
        "外交防衛両大臣による審議経過の国会報告",
      ],
      applicable_law_refs: ["国家安全保障会議設置法", "防衛装備移転三原則 運用指針 R5.12.22"],
    };
  }
  // 目的外使用・第三国移転 事前同意条項なし → 認められない
  if (!input.has_prior_consent_clause) {
    return {
      decision: "denied_third_country_concern",
      reason: "目的外使用・第三国移転に係る事前同意条項が政府間取極に含まれていない",
      required_actions: [
        "相手国政府との取極に事前同意条項を追加 (再輸出規制ITARと同等水準)",
        "End Use Monitoring (EUM) 体制構築",
      ],
      applicable_law_refs: ["防衛装備移転三原則 3項", "運用指針 第3 (適正管理の確保)"],
    };
  }
  // 平和貢献・国際協力 OR 安全保障に資する場合 → 条件付承認
  if (!input.is_japan_security_relevant) {
    return {
      decision: "needs_nss_review",
      reason: "日本の安全保障への寄与が立証されていないため、平和貢献カテゴリでの個別審議が必要",
      required_actions: ["NSC 9大臣会合の審議付議", "経済産業省への個別輸出許可申請"],
      applicable_law_refs: ["防衛装備移転三原則 2項", "外為法48条1項"],
    };
  }
  return {
    decision: "approved_with_conditions",
    reason: "三原則の許容類型に該当 + 適正管理確保",
    required_actions: [
      "経済産業大臣への外為法48条個別輸出許可申請",
      "End Use Monitoring (EUM) 報告 年次",
      "情報公開 (個別案件の概要を防衛省HPで公表)",
    ],
    applicable_law_refs: ["防衛装備移転三原則 2項", "外為法48条1項", "輸出貿易管理令1条"],
  };
}

// ----------------------------------------------------------------------
// 2) 防衛省サイバーセキュリティ統一基準 (NIST SP 800-171相当)
// ----------------------------------------------------------------------

/**
 * 16ファミリー (NIST SP 800-171 r2 と整合)
 *  R5.4 施行の防衛調達における情報セキュリティ確保契約条項
 */
export const MOD_CYBER_FAMILIES = [
  "アクセス制御 (AC)",
  "意識向上・訓練 (AT)",
  "監査・アカウンタビリティ (AU)",
  "構成管理 (CM)",
  "識別・認証 (IA)",
  "インシデント対応 (IR)",
  "保守 (MA)",
  "媒体保護 (MP)",
  "人的セキュリティ (PS)",
  "物理保護 (PE)",
  "リスクアセスメント (RA)",
  "セキュリティアセスメント (CA)",
  "システム・通信保護 (SC)",
  "システム・情報の完全性 (SI)",
  "サプライチェーンリスク管理 (SR)",
  "供給網事故対応 (PL)",
] as const;

export type ModCyberClass = "class_i" | "class_ii";

/**
 * Class I = 防衛省・自衛隊が「保護すべき情報 (CUI相当)」を取扱う契約
 *   全16ファミリー110統制項目への準拠 + 自己評価 SCRM 必須 + 1年毎の再認定
 * Class II = それ以外の防衛調達 (Non-CUI 相当)
 *   基本12統制項目のみ
 */
export interface ModCyberAssessment {
  contract_class: ModCyberClass;
  controls_implemented: number;
  total_required: number;
  compliance_pct: number; // 0-100
  pass: boolean;
  next_recertification_due: string; // ISO date
}

export function assessModCyber(input: {
  contract_class: ModCyberClass;
  implemented_controls: number;
  last_assessment_date: string; // ISO date
}): ModCyberAssessment {
  const required = input.contract_class === "class_i" ? 110 : 12;
  const pct = Math.round((input.implemented_controls / required) * 100);
  // Class I は 95%以上で PASS、Class II は 100%必須
  const pass = input.contract_class === "class_i" ? pct >= 95 : pct === 100;
  // 再認定: Class I = 1年、Class II = 3年
  const monthsUntilNext = input.contract_class === "class_i" ? 12 : 36;
  const last = new Date(input.last_assessment_date);
  last.setMonth(last.getMonth() + monthsUntilNext);
  return {
    contract_class: input.contract_class,
    controls_implemented: input.implemented_controls,
    total_required: required,
    compliance_pct: pct,
    pass,
    next_recertification_due: last.toISOString().slice(0, 10),
  };
}

// ----------------------------------------------------------------------
// 3) 防衛産業基盤強靭化法 (R5.6.7 公布 / R5.10.1 施行)
// ----------------------------------------------------------------------

/**
 * 4類型の財政支援 (法6-9条)
 */
export type ResilienceSupportType =
  | "spec_change" // 装備移転仕様変更 (海外仕様改修)
  | "cyber" // サイバーセキュリティ強化措置
  | "supply_chain" // サプライチェーン (代替部品開発/在庫積増し)
  | "production_facility"; // 製造施設整備 (新ライン構築)

export interface ResilienceApplication {
  contractor: string;
  support_type: ResilienceSupportType;
  defense_relevance_pct: number; // 防衛関連売上比率 (>=10%が目安)
  small_medium_enterprise: boolean; // 中小企業
  proposed_budget_jpy: number;
}

export interface ResilienceDecision {
  approval: "recommended" | "conditional" | "rejected";
  estimated_subsidy_jpy: number; // 財政支援額目安 (定額補助 1/2 〜 2/3)
  reason: string;
  applicable_articles: string[];
}

export function evaluateResilienceApplication(app: ResilienceApplication): ResilienceDecision {
  if (app.defense_relevance_pct < 10) {
    return {
      approval: "rejected",
      estimated_subsidy_jpy: 0,
      reason: "防衛関連売上比率が10%未満のため、装備品安定的な製造能力との関連性低",
      applicable_articles: ["防衛産業基盤強靭化法 第3条 (定義)"],
    };
  }
  // 中小企業 & 製造施設は2/3 補助 (法6条)
  const ratio = app.small_medium_enterprise && app.support_type === "production_facility" ? 2 / 3 : 1 / 2;
  const subsidy = Math.floor(app.proposed_budget_jpy * ratio);
  // サイバーセキュリティは原則 全件採択 (国家戦略上の優先)
  if (app.support_type === "cyber") {
    return {
      approval: "recommended",
      estimated_subsidy_jpy: subsidy,
      reason: "サイバーセキュリティ強化措置は防衛省統一基準遵守の前提として優先採択",
      applicable_articles: ["防衛産業基盤強靭化法 第7条", "防衛省サイバーセキュリティ統一基準 R5.4"],
    };
  }
  return {
    approval: "conditional",
    estimated_subsidy_jpy: subsidy,
    reason: `${app.support_type} 類型として採択候補。装備庁との個別協議を要する`,
    applicable_articles: ["防衛産業基盤強靭化法 第6-9条"],
  };
}

// ----------------------------------------------------------------------
// 4) 特定秘密保護法 (H25法108号) — 4分野×3区分
// ----------------------------------------------------------------------

export type TokuteiHimitsuField = "defense" | "diplomacy" | "harmful_activity_prevention" | "terrorism_prevention";
export type ClearanceLevel = "kihi" /* 機密 */ | "gokuhi" /* 極秘 */ | "hi" /* 秘 */;

export interface ClearanceCheck {
  staff_id: string;
  field: TokuteiHimitsuField;
  required_level: ClearanceLevel;
  /** 適性評価 7項目 */
  assessments: {
    foreign_country_relation: boolean; // 外国の利益代表との関係
    crime_history: boolean;
    psychiatric_history: boolean;
    drug_alcohol_misuse: boolean;
    debt_history: boolean;
    family_relation: boolean; // 家族・同居人の身分
    confidentiality_history: boolean; // 過去の秘密取扱い記録
  };
  cleared: boolean;
  re_evaluation_due: string; // ISO date (5年に1回)
}

export function buildClearanceCheck(input: {
  staff_id: string;
  field: TokuteiHimitsuField;
  required_level: ClearanceLevel;
  assessments: ClearanceCheck["assessments"];
  evaluated_on: string; // ISO date
}): ClearanceCheck {
  const issues = Object.values(input.assessments).filter(Boolean).length;
  const cleared = issues === 0; // 7項目全クリアで適性あり
  const next = new Date(input.evaluated_on);
  next.setFullYear(next.getFullYear() + 5);
  return {
    staff_id: input.staff_id,
    field: input.field,
    required_level: input.required_level,
    assessments: input.assessments,
    cleared,
    re_evaluation_due: next.toISOString().slice(0, 10),
  };
}

// ----------------------------------------------------------------------
// 5) ITAR/EAR 域外適用 (米国規制の防衛品目)
// ----------------------------------------------------------------------

export const ITAR_USML_CATEGORIES = [
  { id: "I", name: "Firearms, Close Assault Weapons" },
  { id: "II", name: "Guns and Armament" },
  { id: "III", name: "Ammunition / Ordnance" },
  { id: "IV", name: "Launch Vehicles, Missiles, Rockets, Torpedoes" },
  { id: "V", name: "Explosives, Energetic Materials" },
  { id: "VI", name: "Surface Vessels of War" },
  { id: "VII", name: "Ground Vehicles" },
  { id: "VIII", name: "Aircraft and Related Articles" },
  { id: "IX", name: "Military Training Equipment" },
  { id: "X", name: "Personal Protective Equipment" },
  { id: "XI", name: "Military Electronics" },
  { id: "XII", name: "Fire Control, Laser, Imaging Equipment" },
  { id: "XIII", name: "Materials and Miscellaneous Articles" },
  { id: "XIV", name: "Toxicological Agents, including Chemical / Biological Agents" },
  { id: "XV", name: "Spacecraft and Related Articles" },
  { id: "XVI", name: "Nuclear Weapons Related Articles" },
  { id: "XVII", name: "Classified Articles" },
  { id: "XVIII", name: "Directed Energy Weapons" },
  { id: "XIX", name: "Gas Turbine Engines and Associated Equipment" },
  { id: "XX", name: "Submersible Vessels and Related Articles" },
  { id: "XXI", name: "Articles, Technical Data, Defense Services Not Otherwise Enumerated" },
] as const;

export interface ItarReExportCheck {
  has_us_origin_content: boolean;
  de_minimis_pct: number; // 米国原産品の割合 (≧25% でITAR域外適用)
  destination_proscribed: boolean; // 22 CFR §126.1 制限国
  authorization_form: "DSP-5" | "DSP-73" | "DSP-85" | "TAA" | "MLA" | "none";
  allowed: boolean;
  blocking_reason?: string;
}

export function checkItarReExport(input: Omit<ItarReExportCheck, "allowed" | "blocking_reason">): ItarReExportCheck {
  if (input.destination_proscribed) {
    return { ...input, allowed: false, blocking_reason: "22 CFR §126.1 Proscribed Country" };
  }
  if (input.has_us_origin_content && input.de_minimis_pct >= 25 && input.authorization_form === "none") {
    return {
      ...input,
      allowed: false,
      blocking_reason: "ITAR de minimis ≥25% かつ USDOS DDTC 認可なし",
    };
  }
  return { ...input, allowed: true };
}

// ----------------------------------------------------------------------
// 6) 装備品ライフサイクル管理 (ALIS / PLM)
// ----------------------------------------------------------------------

export type LifecycleStage = "planning" | "rd" | "procurement" | "operation" | "disposal";

export interface LifecycleRecord {
  equipment_id: string;
  stage: LifecycleStage;
  acquired_at?: string; // ISO date
  expected_eol_at?: string; // 期待退役日
  total_cost_jpy: number; // ライフサイクルコスト (LCC)
  obsolescence_risk: "low" | "medium" | "high";
  next_action: string;
}

/** 「装備品の取得から廃棄までの一気通貫管理」(プロジェクト管理重点施策 R3) */
export function recommendLifecycleAction(rec: Omit<LifecycleRecord, "next_action">): LifecycleRecord {
  let action = "—";
  switch (rec.stage) {
    case "planning":
      action = "DOTMLPF-P 検討 + 要求性能の確定";
      break;
    case "rd":
      action = "技術成熟度 (TRL) 評価 + プロトタイプ試験";
      break;
    case "procurement":
      action = "中央調達 (装備庁) / 一般競争入札 / 随意契約 の選定";
      break;
    case "operation":
      action = rec.obsolescence_risk === "high" ? "後継機種選定の前倒し開始" : "定期整備 + ILS 維持";
      break;
    case "disposal":
      action = "技術情報抹消 + リユース/スクラップ判定 + 環境配慮処分";
      break;
  }
  return { ...rec, next_action: action };
}
