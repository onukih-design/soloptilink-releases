/**
 * SoloptiLinkAI Phase 46-GV2 — 金商法 R6 改正 + 内部統制報告制度 (J-SOX)
 *
 * 金融商品取引法 R6.4施行 (四半期報告書廃止 + 半期報告書統合) + 内部統制報告制度。
 *
 * カバー範囲:
 *  - 金商法 R6.4 改正: 24条 有価証券報告書 + 24条の4の2 確認書 + 24条の4の4 内部統制報告書
 *  - 半期報告書 (R6.4新設) — 第2四半期報告書を半期報告書に統合
 *  - 適時開示 (TDnet) — 決定事実 + 発生事実 + 決算情報
 *  - 内部統制報告制度 (J-SOX) — 4階層統制 (全社/業務プロセス/IT全般/決算財務報告)
 *  - COSO Framework 2013年版 (5要素 17原則)
 *  - 重要な事業拠点選定 (連結売上の概ね2/3カバー)
 *  - 開示すべき重要な不備 (Material Weakness)
 *  - ITGC (IT全般統制) 4領域: 開発・変更・運用・アクセス
 *  - 監査基準委員会報告書 (KAM: Key Audit Matters)
 *
 * なぜClaude Codeに作れないか:
 *   J-SOX は米国 SOX を日本特有の連結ベースで再設計したもので、
 *   重要な事業拠点 2/3 ルール / IT 全般統制 4領域 / 開示すべき重要な不備の判定基準
 *   は日本企業会計基準・監査基準委員会報告書 No.82 を参照する必要がある。
 *   これは Anthropic の英文学習データには存在しない。
 */

// ───────────────────────────────────────────────
// 金商法 R6 改正
// ───────────────────────────────────────────────

/** 上場区分 (東証 R4.4 区分再編) */
export type ListingMarket = "prime" | "standard" | "growth" | "tokyopro";

/** 開示書類の種類 */
export type DisclosureDocument =
  | "annual_report" // 有価証券報告書 (24条)
  | "semi_annual_report" // 半期報告書 (R6.4 新設)
  | "extraordinary_report" // 臨時報告書 (24条の5)
  | "confirmation_letter" // 確認書 (24条の4の2)
  | "internal_control_report" // 内部統制報告書 (24条の4の4)
  | "tender_offer_report" // 公開買付届出書 (27条の3)
  | "large_holdings_report"; // 大量保有報告書 (27条の23)

/** 開示書類の提出期限 (金商法 + 内閣府令) */
export const DISCLOSURE_DEADLINES: Record<DisclosureDocument, { months_after_period_end: number; days?: number }> = {
  annual_report: { months_after_period_end: 3 }, // 期末から3ヶ月以内
  semi_annual_report: { months_after_period_end: 3 }, // 半期末から3ヶ月以内
  extraordinary_report: { months_after_period_end: 0, days: 0 }, // 即時 (発生事実発生後遅滞なく)
  confirmation_letter: { months_after_period_end: 3 }, // 有報と同時
  internal_control_report: { months_after_period_end: 3 }, // 有報と同時
  tender_offer_report: { months_after_period_end: 0 }, // 公開買付開始日
  large_holdings_report: { months_after_period_end: 0, days: 5 }, // 5営業日以内
};

/** 提出期限を計算 (営業日対応簡易版) */
export function calcDisclosureDeadline(
  doc: DisclosureDocument,
  periodEnd: Date,
): { deadline: Date; rule: string } {
  const d = DISCLOSURE_DEADLINES[doc];
  const deadline = new Date(periodEnd);
  if (d.months_after_period_end > 0) {
    deadline.setMonth(deadline.getMonth() + d.months_after_period_end);
  }
  if (d.days != null) {
    deadline.setDate(deadline.getDate() + d.days);
  }
  return { deadline, rule: `${doc}: ${d.months_after_period_end}ヶ月${d.days ? `+${d.days}日` : ""} (R6改正)` };
}

// ───────────────────────────────────────────────
// 適時開示 (TDnet)
// ───────────────────────────────────────────────

/** 適時開示の3類型 (東証 適時開示規則) */
export type TimelyDisclosureCategory =
  | "decided_fact" // 決定事実 — 取締役会決議が必要な重要事項
  | "occurred_fact" // 発生事実 — 災害/訴訟/業務提携解消等
  | "earnings_summary"; // 決算情報

/** 決定事実 — 軽微基準を超えれば即日開示 */
export type DecidedFactType =
  | "share_split"
  | "share_buyback"
  | "treasury_disposal"
  | "merger"
  | "share_exchange"
  | "share_transfer"
  | "company_split"
  | "business_transfer"
  | "dividend"
  | "capital_increase"
  | "bond_issuance"
  | "subsidiary_acquisition"
  | "subsidiary_disposal"
  | "audit_change"
  | "directors_change";

/** 発生事実 — 軽微基準を超えれば即日開示 */
export type OccurredFactType =
  | "disaster_loss" // 災害損失
  | "lawsuit_filed"
  | "lawsuit_judgment"
  | "main_creditor_change"
  | "main_shareholder_change"
  | "going_concern_doubt"
  | "going_concern_resolved"
  | "secondary_offering"
  | "credit_rating_change"
  | "antitrust_investigation"
  | "tax_audit_correction"
  | "subsidiary_disaster";

export interface MaterialityThreshold {
  /** 純資産の % (例: 30%) — 軽微基準 */
  net_asset_percent?: number;
  /** 売上の % (例: 10%) */
  net_sales_percent?: number;
  /** 経常利益の % (例: 30%) */
  ordinary_income_percent?: number;
  /** 当期純利益の % (例: 30%) */
  net_income_percent?: number;
}

/** 軽微基準 (適時開示規則施行規則 各号) — 抜粋 */
export const MATERIALITY_THRESHOLDS: Partial<Record<DecidedFactType | OccurredFactType, MaterialityThreshold>> = {
  share_buyback: { net_asset_percent: 5 },
  capital_increase: { net_asset_percent: 10 },
  merger: { net_sales_percent: 10, net_asset_percent: 30 },
  business_transfer: { net_sales_percent: 10 },
  subsidiary_acquisition: { net_sales_percent: 10 },
  disaster_loss: { net_asset_percent: 3 },
  lawsuit_filed: { net_asset_percent: 15 },
};

// ───────────────────────────────────────────────
// 内部統制報告制度 (J-SOX) — 24条の4の4
// ───────────────────────────────────────────────

/** 内部統制 4階層 (実施基準) */
export type ControlLayer =
  | "company_level" // 全社的な内部統制 (Entity-Level Controls)
  | "process_level" // 業務プロセスに係る内部統制 (Process-Level Controls)
  | "it_general" // IT全般統制 (ITGC: IT General Controls)
  | "financial_close"; // 決算財務報告プロセス (Financial Close & Reporting Process)

/** COSO 2013 5要素 + 17原則 */
export type CosoComponent =
  | "control_environment" // 統制環境 (5原則)
  | "risk_assessment" // リスク評価 (4原則)
  | "control_activities" // 統制活動 (3原則)
  | "information_communication" // 情報と伝達 (3原則)
  | "monitoring"; // モニタリング (2原則)

/** COSO 2013 17原則のラベル */
export const COSO_PRINCIPLES: Array<{ no: number; component: CosoComponent; title: string }> = [
  { no: 1, component: "control_environment", title: "誠実性と倫理観へのコミットメント" },
  { no: 2, component: "control_environment", title: "取締役会の独立性とモニタリング責任" },
  { no: 3, component: "control_environment", title: "組織構造、権限、責任の確立" },
  { no: 4, component: "control_environment", title: "コンピテンス (能力) の確立とコミットメント" },
  { no: 5, component: "control_environment", title: "個人の説明責任の確立" },
  { no: 6, component: "risk_assessment", title: "明確な目標の特定" },
  { no: 7, component: "risk_assessment", title: "リスクの識別と分析" },
  { no: 8, component: "risk_assessment", title: "不正リスクの評価" },
  { no: 9, component: "risk_assessment", title: "重要な変化の識別と評価" },
  { no: 10, component: "control_activities", title: "統制活動の選択と整備" },
  { no: 11, component: "control_activities", title: "ITに対する全般統制活動の選択と整備" },
  { no: 12, component: "control_activities", title: "方針と手続による統制活動の展開" },
  { no: 13, component: "information_communication", title: "関連性ある情報の利用" },
  { no: 14, component: "information_communication", title: "内部への伝達" },
  { no: 15, component: "information_communication", title: "外部への伝達" },
  { no: 16, component: "monitoring", title: "継続的および/または個別の評価の実施" },
  { no: 17, component: "monitoring", title: "不備の評価とコミュニケーション" },
];

// ───────────────────────────────────────────────
// 重要な事業拠点選定 — 実施基準 II.2 (1)
// ───────────────────────────────────────────────

/** 重要な事業拠点の選定基準: 連結売上の概ね2/3 をカバー */
export const IMPORTANT_SITE_COVERAGE_RATIO = 2 / 3;

export interface BusinessSite {
  site_id: string;
  site_name: string;
  consolidated_revenue: number; // 連結ベースの売上 (円)
  region?: string;
}

/**
 * 売上が大きい順に並べ、累計が連結売上の 2/3 を超えるまで選定
 */
export function selectImportantSites(sites: BusinessSite[]): {
  selected: BusinessSite[];
  coverage: number;
  threshold: number;
} {
  const total = sites.reduce((s, x) => s + x.consolidated_revenue, 0);
  const sorted = [...sites].sort((a, b) => b.consolidated_revenue - a.consolidated_revenue);
  const selected: BusinessSite[] = [];
  let acc = 0;
  for (const s of sorted) {
    selected.push(s);
    acc += s.consolidated_revenue;
    if (acc / total >= IMPORTANT_SITE_COVERAGE_RATIO) break;
  }
  return { selected, coverage: total === 0 ? 0 : acc / total, threshold: IMPORTANT_SITE_COVERAGE_RATIO };
}

// ───────────────────────────────────────────────
// IT全般統制 (ITGC) 4領域 — 実施基準 II.3 (4)
// ───────────────────────────────────────────────

export type ItgcDomain = "development" | "change_management" | "operations" | "access_control";

export const ITGC_KEY_CONTROLS: Record<ItgcDomain, string[]> = {
  development: [
    "システム開発に係る承認手続",
    "テスト計画と実施記録",
    "本番移行前のユーザー受入テスト (UAT)",
    "リリース承認とロールバック計画",
  ],
  change_management: [
    "変更要求の起票と承認",
    "本番環境への変更の分離 (開発者と承認者の職務分離)",
    "緊急変更の事後承認手続",
    "変更履歴の保管",
  ],
  operations: [
    "バッチ処理のスケジューリングと例外監視",
    "バックアップとリストアテスト",
    "障害管理 (インシデント記録と再発防止)",
    "ジョブ実行ログの保全",
  ],
  access_control: [
    "ユーザーID 申請・承認・棚卸",
    "特権ID (システム管理者) の付与制限",
    "退職者・異動者のアクセス権削除",
    "パスワードポリシー (複雑性 + 期限) と多要素認証",
  ],
};

// ───────────────────────────────────────────────
// 開示すべき重要な不備 (Material Weakness)
// ───────────────────────────────────────────────

/** 開示すべき重要な不備の判定基準 — 実施基準 III.4 */
export interface DeficiencyEvaluation {
  affects_financial_statements: boolean; // 財務諸表への影響
  /** 重要性の金額 (連結税前利益の 5% 等) を超えるか */
  exceeds_quantitative_threshold: boolean;
  /** 質的影響: 経営者不正可能性 / 取締役会への報告漏れ等 */
  qualitative_concern: boolean;
}

export function isMaterialWeakness(d: DeficiencyEvaluation): {
  is_material: boolean;
  reasons: string[];
} {
  const reasons: string[] = [];
  if (!d.affects_financial_statements) {
    return { is_material: false, reasons: ["財務諸表に影響しない"] };
  }
  if (d.exceeds_quantitative_threshold) reasons.push("量的重要性 (連結税前利益5%等) 超過");
  if (d.qualitative_concern) reasons.push("質的重要性 (経営者不正/取締役会報告漏れ)");
  return { is_material: reasons.length > 0, reasons };
}

// ───────────────────────────────────────────────
// 監査基準委員会報告書 No.82 — KAM (Key Audit Matters)
// ───────────────────────────────────────────────

/** KAM 開示は R3.3 期から強制 (上場会社の監査報告書) */
export const KAM_MANDATORY_FROM = "2021-03-31";

export interface AuditReport {
  fiscal_year_end: string; // YYYY-MM-DD
  auditor_firm: string;
  opinion: "unqualified" | "qualified" | "adverse" | "disclaimer";
  kam_items: Array<{
    title: string;
    why_significant: string;
    how_addressed: string;
  }>;
  going_concern_paragraph?: string;
}

export function isKamRequired(fiscalYearEnd: string): boolean {
  return fiscalYearEnd >= KAM_MANDATORY_FROM;
}

// ───────────────────────────────────────────────
// 確認書 (24条の4の2) — 経営者確認
// ───────────────────────────────────────────────

export interface ConfirmationLetter {
  doc_id: string;
  fiscal_year_end: string;
  ceo_signature: boolean;
  cfo_signature: boolean;
  declares_disclosure_complete: boolean; // 「記載内容が金商法に基づき適正である」
  declares_internal_control_effective: boolean;
  filed_with: ("annual_report" | "semi_annual_report")[];
}

export function validateConfirmationLetter(c: ConfirmationLetter): {
  valid: boolean;
  missing: string[];
} {
  const missing: string[] = [];
  if (!c.ceo_signature) missing.push("CEO署名");
  if (!c.cfo_signature) missing.push("CFO署名");
  if (!c.declares_disclosure_complete) missing.push("開示適正性宣言");
  if (!c.declares_internal_control_effective) missing.push("内部統制有効性宣言");
  return { valid: missing.length === 0, missing };
}
