/**
 * lib/japan/observability.ts — Observability Pack (v2.0 Phase 5)
 *
 * 柱5 OPERATIONAL EXCELLENCE の中核モジュール。
 * Prometheus/Grafana/Alertmanager を「日本の中小企業がそのまま使える」
 * 設定ファイルに落とし込む。JST固定、日本語アラート、祝日カレンダー対応。
 *
 * なぜClaude Codeに作れないか:
 *   汎用 Prometheus 設定は書けるが、「JST」「日本の祝日」「LINE通知」
 *   「営業時間外の緊急度自動判定」まで日本文化込みで設計されたパックは
 *   日本運用現場の蓄積が必要。中小企業は担当者1人で全システム見るので、
 *   「アラート過多で無視されない」ロジックまで落とし込む必要がある。
 */

// ───────────────────────────────────────────────
// 型定義
// ───────────────────────────────────────────────

/** アラート重大度 */
export type Severity = "critical" | "warning" | "info";

/** 通知チャネル */
export type NotificationChannel = "email" | "slack" | "line" | "teams" | "webhook" | "pager";

/** 勤務時間ポリシー */
export interface WorkingHoursPolicy {
  timezone: "Asia/Tokyo";
  weekdays: { start: string; end: string }; // "09:00" - "18:00"
  saturday?: { start: string; end: string };
  sunday?: { start: string; end: string };
  holidays: string[]; // YYYY-MM-DD
  holidayBehavior: "silent" | "critical_only" | "all";
}

/** アラート定義 */
export interface AlertRule {
  name: string; // 例: "HighCPUUsage"
  nameJa: string; // 例: "CPU使用率が高い"
  expr: string; // Prometheus式
  forDuration: string; // 例: "5m"
  severity: Severity;
  summary: string; // 日本語サマリ
  runbook?: string; // Runbook URL
  channels: NotificationChannel[];
  workingHoursOnly?: boolean;
}

/** Prometheus ジョブ */
export interface PromJob {
  job_name: string;
  scrape_interval: string;
  metrics_path?: string;
  static_configs: Array<{ targets: string[]; labels?: Record<string, string> }>;
}

/** 生成結果 */
export interface ObservabilityPack {
  prometheus: { yml: string; rules: string };
  alertmanager: { yml: string };
  grafana: { dashboards: GrafanaDashboard[] };
  deadMansSwitch: { yml: string };
}

export interface GrafanaDashboard {
  title: string;
  uid: string;
  panels: Array<{ title: string; expr: string; unit?: string }>;
}

// ───────────────────────────────────────────────
// 日本の祝日カレンダー (2026-2027)
// ───────────────────────────────────────────────

const JAPAN_HOLIDAYS_2026_2027: string[] = [
  "2026-01-01", // 元日
  "2026-01-12", // 成人の日
  "2026-02-11", // 建国記念の日
  "2026-02-23", // 天皇誕生日
  "2026-03-20", // 春分の日
  "2026-04-29", // 昭和の日
  "2026-05-03", // 憲法記念日
  "2026-05-04", // みどりの日
  "2026-05-05", // こどもの日
  "2026-05-06", // 振替休日
  "2026-07-20", // 海の日
  "2026-08-11", // 山の日
  "2026-09-21", // 敬老の日
  "2026-09-23", // 秋分の日
  "2026-10-12", // スポーツの日
  "2026-11-03", // 文化の日
  "2026-11-23", // 勤労感謝の日
  "2027-01-01",
  "2027-01-11",
  "2027-02-11",
  "2027-02-23",
  "2027-03-21",
  "2027-03-22",
  "2027-04-29",
  "2027-05-03",
  "2027-05-04",
  "2027-05-05",
  "2027-07-19",
  "2027-08-11",
  "2027-09-20",
  "2027-09-23",
  "2027-10-11",
  "2027-11-03",
  "2027-11-23",
];

// ───────────────────────────────────────────────
// デフォルト設定
// ───────────────────────────────────────────────

export const DEFAULT_WORKING_HOURS: WorkingHoursPolicy = {
  timezone: "Asia/Tokyo",
  weekdays: { start: "09:00", end: "18:00" },
  saturday: undefined,
  sunday: undefined,
  holidays: JAPAN_HOLIDAYS_2026_2027,
  holidayBehavior: "critical_only",
};

/** 日本中小企業が必ず入れるべき必須アラート (15個) */
export const DEFAULT_ALERT_RULES: AlertRule[] = [
  {
    name: "InstanceDown",
    nameJa: "サーバー応答なし",
    expr: 'up == 0',
    forDuration: "2m",
    severity: "critical",
    summary: "{{ $labels.instance }} が {{ $value }} 分以上応答していません",
    runbook: "/runbook/instance_down.md",
    channels: ["line", "slack", "email"],
  },
  {
    name: "HighCPUUsage",
    nameJa: "CPU使用率が高い",
    expr: '100 - (avg by (instance) (irate(node_cpu_seconds_total{mode="idle"}[5m])) * 100) > 85',
    forDuration: "10m",
    severity: "warning",
    summary: "{{ $labels.instance }} の CPU 使用率が 85% を超過しました",
    channels: ["slack"],
    workingHoursOnly: true,
  },
  {
    name: "HighMemoryUsage",
    nameJa: "メモリ使用率が高い",
    expr: "(1 - (node_memory_MemAvailable_bytes / node_memory_MemTotal_bytes)) * 100 > 90",
    forDuration: "10m",
    severity: "warning",
    summary: "{{ $labels.instance }} のメモリ使用率が 90% を超過しました",
    channels: ["slack"],
    workingHoursOnly: true,
  },
  {
    name: "DiskSpaceLow",
    nameJa: "ディスク空き容量不足",
    expr: '(node_filesystem_avail_bytes{mountpoint="/"} / node_filesystem_size_bytes{mountpoint="/"}) * 100 < 15',
    forDuration: "30m",
    severity: "warning",
    summary: "ディスク空き容量が 15% を下回りました",
    channels: ["slack", "email"],
  },
  {
    name: "DiskSpaceCritical",
    nameJa: "ディスク空き容量逼迫",
    expr: '(node_filesystem_avail_bytes{mountpoint="/"} / node_filesystem_size_bytes{mountpoint="/"}) * 100 < 5',
    forDuration: "5m",
    severity: "critical",
    summary: "ディスク空き容量が 5% を下回りました (緊急対応)",
    runbook: "/runbook/disk_full.md",
    channels: ["line", "slack", "email", "pager"],
  },
  {
    name: "HighErrorRate5xx",
    nameJa: "API 5xx エラー多発",
    expr: 'sum(rate(http_requests_total{status=~"5.."}[5m])) / sum(rate(http_requests_total[5m])) > 0.05',
    forDuration: "5m",
    severity: "critical",
    summary: "5xx エラー率が 5% を超過しました",
    runbook: "/runbook/high_error_rate.md",
    channels: ["line", "slack", "email"],
  },
  {
    name: "SlowResponse",
    nameJa: "レスポンスが遅い",
    expr: "histogram_quantile(0.95, sum(rate(http_request_duration_seconds_bucket[5m])) by (le)) > 2",
    forDuration: "10m",
    severity: "warning",
    summary: "API の p95 レスポンス時間が 2 秒を超過しました",
    channels: ["slack"],
    workingHoursOnly: true,
  },
  {
    name: "DatabaseConnectionPoolExhausted",
    nameJa: "DBコネクションプール枯渇",
    expr: "database_connections_active / database_connections_max > 0.9",
    forDuration: "3m",
    severity: "critical",
    summary: "DB コネクションプールが 90% に達しています",
    runbook: "/runbook/db_pool_exhausted.md",
    channels: ["line", "slack", "email"],
  },
  {
    name: "SSLCertExpiry30Days",
    nameJa: "SSL証明書の有効期限30日以内",
    expr: "(probe_ssl_earliest_cert_expiry - time()) / 86400 < 30",
    forDuration: "1h",
    severity: "warning",
    summary: "SSL 証明書の有効期限まで {{ $value }} 日",
    runbook: "/runbook/ssl_renewal.md",
    channels: ["email", "slack"],
  },
  {
    name: "SSLCertExpiry7Days",
    nameJa: "SSL証明書の有効期限7日以内",
    expr: "(probe_ssl_earliest_cert_expiry - time()) / 86400 < 7",
    forDuration: "10m",
    severity: "critical",
    summary: "SSL 証明書の有効期限まで {{ $value }} 日 (緊急更新)",
    channels: ["line", "slack", "email", "pager"],
  },
  {
    name: "BackupFailed",
    nameJa: "バックアップ失敗",
    expr: "backup_last_success_timestamp_seconds < (time() - 86400)",
    forDuration: "30m",
    severity: "critical",
    summary: "過去 24 時間以内にバックアップが成功していません",
    runbook: "/runbook/backup_failed.md",
    channels: ["line", "slack", "email"],
  },
  {
    name: "LicenseServerUnreachable",
    nameJa: "ライセンスサーバー疎通不可",
    expr: 'probe_success{job="license"} == 0',
    forDuration: "10m",
    severity: "critical",
    summary: "ライセンスサーバーに接続できません",
    runbook: "/runbook/license_unreachable.md",
    channels: ["line", "slack", "email"],
  },
  {
    name: "UnusualAuthFailures",
    nameJa: "不審なログイン失敗多発",
    expr: "sum(rate(auth_failures_total[5m])) > 10",
    forDuration: "3m",
    severity: "warning",
    summary: "ログイン失敗が急増しています (ブルートフォース疑い)",
    runbook: "/runbook/auth_brute_force.md",
    channels: ["slack", "email"],
  },
  {
    name: "ComplianceCertExpiring",
    nameJa: "法令準拠証明書の期限切れ接近",
    expr: "compliance_cert_days_until_expiry < 30",
    forDuration: "1h",
    severity: "warning",
    summary: "法令準拠証明書の有効期限まで {{ $value }} 日",
    channels: ["email"],
    workingHoursOnly: true,
  },
  {
    name: "DeadMansSwitch",
    nameJa: "Dead Man's Switch",
    expr: "absent(up{job=\"pingdom\"})",
    forDuration: "5m",
    severity: "critical",
    summary: "監視システム自体が停止しています (外部から疎通不可)",
    runbook: "/runbook/dead_mans_switch.md",
    channels: ["line", "email", "pager"],
  },
];

// ───────────────────────────────────────────────
// Prometheus 設定生成
// ───────────────────────────────────────────────

export function generatePrometheusConfig(
  jobs: PromJob[] = DEFAULT_JOBS,
): string {
  return `# Prometheus 設定 (SoloptiLinkAI Observability Pack v2.0)
# 生成日時: ${new Date().toISOString()}
# タイムゾーン: Asia/Tokyo (JST)

global:
  scrape_interval: 15s
  evaluation_interval: 15s
  external_labels:
    region: "jp-tokyo"
    generator: "soloptilink-japan/v2.0"

rule_files:
  - "alert_rules.yml"

alerting:
  alertmanagers:
    - static_configs:
        - targets:
            - alertmanager:9093

scrape_configs:
${jobs
  .map(
    (j) => `  - job_name: "${j.job_name}"
    scrape_interval: ${j.scrape_interval}
${j.metrics_path ? `    metrics_path: "${j.metrics_path}"\n` : ""}    static_configs:
${j.static_configs
  .map(
    (sc) =>
      `      - targets: [${sc.targets.map((t) => `"${t}"`).join(", ")}]${
        sc.labels
          ? `\n        labels:\n${Object.entries(sc.labels)
              .map(([k, v]) => `          ${k}: "${v}"`)
              .join("\n")}`
          : ""
      }`,
  )
  .join("\n")}`,
  )
  .join("\n")}
`;
}

const DEFAULT_JOBS: PromJob[] = [
  {
    job_name: "app",
    scrape_interval: "15s",
    metrics_path: "/metrics",
    static_configs: [{ targets: ["app:3000"], labels: { env: "prod" } }],
  },
  {
    job_name: "node",
    scrape_interval: "30s",
    static_configs: [{ targets: ["node-exporter:9100"] }],
  },
  {
    job_name: "db",
    scrape_interval: "30s",
    static_configs: [{ targets: ["postgres-exporter:9187"] }],
  },
  {
    job_name: "license",
    scrape_interval: "60s",
    metrics_path: "/api/health",
    static_configs: [{ targets: ["license.soloptilinkai.com:443"] }],
  },
];

/** アラートルール YAML 生成 */
export function generateAlertRules(
  rules: AlertRule[] = DEFAULT_ALERT_RULES,
  policy: WorkingHoursPolicy = DEFAULT_WORKING_HOURS,
): string {
  const jstComment = `# Generated by SoloptiLinkAI Observability Pack v2.0
# タイムゾーン: ${policy.timezone}
# 営業時間: 平日 ${policy.weekdays.start}-${policy.weekdays.end}
# 祝日ポリシー: ${policy.holidayBehavior === "silent" ? "祝日はサイレント" : policy.holidayBehavior === "critical_only" ? "祝日はcriticalのみ" : "祝日も通常通知"}

`;
  const groups = `groups:
  - name: soloptilink_japan_default
    rules:
${rules
  .map(
    (r) => `      - alert: ${r.name}
        expr: ${r.expr}
        for: ${r.forDuration}
        labels:
          severity: ${r.severity}
          name_ja: "${r.nameJa}"
          channels: "${r.channels.join(",")}"
${r.workingHoursOnly ? '          working_hours_only: "true"\n' : ""}        annotations:
          summary: "${r.summary}"
${r.runbook ? `          runbook: "${r.runbook}"\n` : ""}`,
  )
  .join("\n")}
`;
  return jstComment + groups;
}

// ───────────────────────────────────────────────
// Alertmanager 設定 (LINE/Slack/Email/Teams)
// ───────────────────────────────────────────────

export function generateAlertmanagerConfig(params: {
  slackWebhook?: string;
  lineToken?: string;
  emailTo?: string;
  teamsWebhook?: string;
}): string {
  return `# Alertmanager 設定 (SoloptiLinkAI Observability Pack v2.0)
# LINE通知は https://notify-bot.line.me/ 経由 (無料枠)

global:
  resolve_timeout: 5m

route:
  receiver: default
  group_by: ["alertname", "severity"]
  group_wait: 30s
  group_interval: 5m
  repeat_interval: 4h
  routes:
    - match:
        severity: critical
      receiver: critical_jp
      continue: true
    - match:
        severity: warning
      receiver: warning_jp

receivers:
  - name: default
    email_configs:
      - to: "${params.emailTo ?? "ops@example.jp"}"
        send_resolved: true
        headers:
          Subject: "[SoloptiLinkAI] {{ .GroupLabels.alertname }}"

  - name: critical_jp
${
  params.lineToken
    ? `    webhook_configs:
      - url: "https://notify-api.line.me/api/notify"
        send_resolved: true
        http_config:
          bearer_token: "${params.lineToken}"
`
    : ""
}${
    params.slackWebhook
      ? `    slack_configs:
      - api_url: "${params.slackWebhook}"
        channel: "#alerts-critical"
        send_resolved: true
        title: "🚨 {{ .GroupLabels.name_ja | default .GroupLabels.alertname }}"
        text: "{{ range .Alerts }}{{ .Annotations.summary }}{{ if .Annotations.runbook }}\\n対応手順: {{ .Annotations.runbook }}{{ end }}\\n{{ end }}"
`
      : ""
  }${
    params.emailTo
      ? `    email_configs:
      - to: "${params.emailTo}"
        send_resolved: true
`
      : ""
  }
  - name: warning_jp
${
  params.slackWebhook
    ? `    slack_configs:
      - api_url: "${params.slackWebhook}"
        channel: "#alerts-warning"
        send_resolved: true
        title: "⚠️ {{ .GroupLabels.name_ja | default .GroupLabels.alertname }}"
`
    : ""
}${
    params.teamsWebhook
      ? `    webhook_configs:
      - url: "${params.teamsWebhook}"
        send_resolved: true
`
      : ""
  }

inhibit_rules:
  - source_match:
      severity: critical
    target_match:
      severity: warning
    equal: ["alertname", "instance"]
`;
}

// ───────────────────────────────────────────────
// Grafana ダッシュボード (標準3枚)
// ───────────────────────────────────────────────

export const DEFAULT_DASHBOARDS: GrafanaDashboard[] = [
  {
    title: "システム健全性 (JST)",
    uid: "system-health-jp",
    panels: [
      { title: "CPU 使用率 (%)", expr: '100 - (avg by (instance) (irate(node_cpu_seconds_total{mode="idle"}[5m])) * 100)', unit: "percent" },
      { title: "メモリ使用率 (%)", expr: "(1 - (node_memory_MemAvailable_bytes / node_memory_MemTotal_bytes)) * 100", unit: "percent" },
      { title: "ディスク空き容量 (%)", expr: '(node_filesystem_avail_bytes{mountpoint="/"} / node_filesystem_size_bytes{mountpoint="/"}) * 100', unit: "percent" },
      { title: "ネットワーク送受信 (B/s)", expr: "rate(node_network_receive_bytes_total[5m])", unit: "Bps" },
    ],
  },
  {
    title: "APIパフォーマンス (JST)",
    uid: "api-performance-jp",
    panels: [
      { title: "リクエスト数/秒", expr: "sum(rate(http_requests_total[1m]))", unit: "reqps" },
      { title: "5xx エラー率 (%)", expr: 'sum(rate(http_requests_total{status=~"5.."}[5m])) / sum(rate(http_requests_total[5m])) * 100', unit: "percent" },
      { title: "p95 レスポンス時間 (秒)", expr: "histogram_quantile(0.95, sum(rate(http_request_duration_seconds_bucket[5m])) by (le))", unit: "s" },
      { title: "同時接続数", expr: "http_active_connections", unit: "short" },
    ],
  },
  {
    title: "業務KPI (日本語)",
    uid: "business-kpi-jp",
    panels: [
      { title: "本日の受注件数", expr: "sum(business_orders_total{date=~\"今日\"})", unit: "short" },
      { title: "本日の請求額 (円)", expr: "sum(business_invoice_amount_jpy)", unit: "currencyJPY" },
      { title: "未承認稟議数", expr: "sum(workflow_pending_approvals)", unit: "short" },
      { title: "法令準拠証明書 残日数", expr: "compliance_cert_days_until_expiry", unit: "d" },
    ],
  },
];

// ───────────────────────────────────────────────
// Dead Man's Switch
// ───────────────────────────────────────────────

export function generateDeadMansSwitchConfig(): string {
  return `# Dead Man's Switch (SoloptiLinkAI Observability Pack v2.0)
# 外部監視サービス (UptimeRobot 等) から /ping を 5 分おきに叩き、
# 30 分以内に疎通がなければ 監視システム自体のダウンを通知

pings:
  - name: primary
    url: "https://your-app.example.jp/ping"
    interval: 5m
    timeout: 30s
    on_failure:
      after_minutes: 30
      notify:
        - channel: line
          message: "SoloptiLinkAI 監視システムが応答しません。ご確認ください。"
        - channel: email
          to: "ops@example.jp"
`;
}

// ───────────────────────────────────────────────
// 一括生成 (BOOST からの呼び出し)
// ───────────────────────────────────────────────

export function buildObservabilityPack(params: {
  slackWebhook?: string;
  lineToken?: string;
  emailTo?: string;
  teamsWebhook?: string;
  jobs?: PromJob[];
  rules?: AlertRule[];
  policy?: WorkingHoursPolicy;
} = {}): ObservabilityPack {
  return {
    prometheus: {
      yml: generatePrometheusConfig(params.jobs),
      rules: generateAlertRules(params.rules, params.policy),
    },
    alertmanager: {
      yml: generateAlertmanagerConfig(params),
    },
    grafana: {
      dashboards: DEFAULT_DASHBOARDS,
    },
    deadMansSwitch: {
      yml: generateDeadMansSwitchConfig(),
    },
  };
}

/** 祝日判定 (JST) */
export function isHoliday(date: Date, policy: WorkingHoursPolicy = DEFAULT_WORKING_HOURS): boolean {
  const jstDate = toJST(date);
  const iso = jstDate.toISOString().slice(0, 10);
  return policy.holidays.includes(iso);
}

/** 営業時間内判定 (JST) */
export function isWithinWorkingHours(date: Date, policy: WorkingHoursPolicy = DEFAULT_WORKING_HOURS): boolean {
  const jst = toJST(date);
  const day = jst.getUTCDay(); // 0=日, 6=土
  const time = jst.getUTCHours() * 100 + jst.getUTCMinutes();
  if (isHoliday(date, policy)) return false;
  if (day === 0 && !policy.sunday) return false;
  if (day === 6 && !policy.saturday) return false;
  const range =
    day === 0
      ? policy.sunday
      : day === 6
        ? policy.saturday
        : policy.weekdays;
  if (!range) return false;
  const start = parseTime(range.start);
  const end = parseTime(range.end);
  return time >= start && time < end;
}

function toJST(d: Date): Date {
  return new Date(d.getTime() + 9 * 60 * 60 * 1000);
}

function parseTime(s: string): number {
  const [h, m] = s.split(":").map((n) => parseInt(n, 10));
  return h * 100 + m;
}
