/**
 * lib/japan/sports.ts — スポーツビジネスDNA
 *
 * カバレッジ:
 *  - スポーツ基本法 (H23法律78)
 *  - Jリーグ クラブライセンス制度 (FFP相当 — Financial Fair Play)
 *  - 日本野球協約 (NPB) — 統一契約書 / 保留制度 / FAランク
 *  - JOC加盟競技団体 (NF) ガバナンスコード (R1.6)
 *  - スポーツインテグリティ ユニット (JSPO/JADA)
 *  - WADA禁止表 / アンチドーピング規程
 *  - 興行場法 (S23法律137) — スタジアム/アリーナ
 *  - 公益社団 / 公益財団法人法 — スポーツ団体の法人格
 *  - 著作権法92条 (放映権) / 不正競争防止法 (チケット転売規制 H30)
 *
 * 参考: スポーツ庁, JFA/Jリーグ, NPB, JOC, JSPO, JADA
 */

// ============================================================================
// 1. Jリーグ クラブライセンス制度 (5領域)
// ============================================================================

export type LicenseCategory = 'sporting' | 'infrastructure' | 'personnel' | 'legal' | 'financial';

export interface ClubLicenseAudit {
  // Sporting
  hasU18Academy: boolean;
  hasU15Academy: boolean;
  // Infrastructure
  stadiumCapacity: number;
  pitchSizeM: { length: number; width: number };
  hasFloodlight1500lux: boolean;
  // Personnel
  headCoachLicense: 'S' | 'A' | 'B' | 'C' | 'none';
  hasMedicalDoctor: boolean;
  hasAthleticTrainer: boolean;
  // Legal
  isCorporateEntity: boolean; // 株式会社 or 公益法人
  // Financial
  netDebtJpy: number;
  totalRevenueJpy: number;
  delinquentTaxJpy: number;
}

export type LicenseTier = 'J1' | 'J2' | 'J3' | 'rejected';

/** Jリーグ クラブライセンス判定 (簡易ロジック) */
export function evaluateClubLicense(a: ClubLicenseAudit): {
  tier: LicenseTier;
  failures: { category: LicenseCategory; issue: string }[];
} {
  const failures: { category: LicenseCategory; issue: string }[] = [];

  // J1要件
  const j1Capacity = a.stadiumCapacity >= 15_000;
  const j2Capacity = a.stadiumCapacity >= 10_000;
  const j3Capacity = a.stadiumCapacity >= 5_000;

  if (!a.hasU18Academy) failures.push({ category: 'sporting', issue: 'U-18アカデミーが必要 (J1/J2)' });
  if (!a.hasU15Academy) failures.push({ category: 'sporting', issue: 'U-15アカデミーが必要 (J1/J2)' });
  if (!j3Capacity) failures.push({ category: 'infrastructure', issue: 'スタジアム5000席未満' });
  if (a.pitchSizeM.length < 105 || a.pitchSizeM.width < 68) {
    failures.push({ category: 'infrastructure', issue: 'ピッチサイズ要件 105×68m を満たさない' });
  }
  if (!a.hasFloodlight1500lux) {
    failures.push({ category: 'infrastructure', issue: '照明1500ルクス基準 (J1) を満たさない' });
  }
  if (a.headCoachLicense !== 'S' && a.headCoachLicense !== 'A') {
    failures.push({ category: 'personnel', issue: 'JFA監督ライセンスS or A級が必要' });
  }
  if (!a.hasMedicalDoctor) failures.push({ category: 'personnel', issue: 'チームドクター登録必須' });
  if (!a.isCorporateEntity) failures.push({ category: 'legal', issue: '株式会社 or 公益法人格が必須' });
  if (a.delinquentTaxJpy > 0) failures.push({ category: 'financial', issue: '税滞納あり — ライセンス取消事由' });

  // 3期連続債務超過チェック (FFP相当): netDebt > totalRevenue
  if (a.netDebtJpy > a.totalRevenueJpy) {
    failures.push({ category: 'financial', issue: 'FFP違反: 純負債が総収入を超過' });
  }

  // 階層判定
  const finOk = !failures.some((f) => f.category === 'financial');
  const legalOk = !failures.some((f) => f.category === 'legal');
  if (!finOk || !legalOk) return { tier: 'rejected', failures };

  if (j1Capacity && a.hasFloodlight1500lux && a.hasU18Academy && a.headCoachLicense === 'S') return { tier: 'J1', failures };
  if (j2Capacity && a.hasU18Academy) return { tier: 'J2', failures };
  if (j3Capacity) return { tier: 'J3', failures };
  return { tier: 'rejected', failures };
}

// ============================================================================
// 2. NPB (日本プロ野球) 統一契約書 / 保留制度 / FAランク
// ============================================================================

export interface NpbPlayerContract {
  signedYear: number;
  annualSalaryJpy: number;
  servicesYears: number; // 一軍登録累計
}

/** NPB FAランク (国内FA + 海外FA): A/B/C */
export function classifyNpbFaRank(top3SalariesJpy: number[], myRankInTeam: number): 'A' | 'B' | 'C' {
  // FAランクは旧年俸を基にA/B/Cで分類 (2022年以降のルール簡略)
  // チーム順位3位以内 → A, 4-10位 → B, 11位以下 → C
  if (myRankInTeam <= 3) return 'A';
  if (myRankInTeam <= 10) return 'B';
  return 'C';
}

/** 国内FA権取得年数 (2008年以降ドラフト指名選手は8年/高卒+大卒) */
export function isNpbDomesticFaEligible(c: NpbPlayerContract & { isHighSchoolDraft: boolean }): boolean {
  return c.servicesYears >= (c.isHighSchoolDraft ? 8 : 7);
}

/** 海外FA権 (国内FA取得後さらに1シーズン経過 = 一軍登録9年/8年) */
export function isNpbOverseasFaEligible(c: NpbPlayerContract & { isHighSchoolDraft: boolean }): boolean {
  return c.servicesYears >= (c.isHighSchoolDraft ? 9 : 8);
}

/** NPB保留制度: 12月2日以降の保留者名簿に記載されると他球団交渉禁止 */
export function isPlayerProtected(input: { reservedListYear: number; checkDate: Date }): boolean {
  const reserveDeadline = new Date(`${input.reservedListYear}-12-02`);
  return input.checkDate >= reserveDeadline;
}

// ============================================================================
// 3. JSC ガバナンスコード (R1.6 中央競技団体向け 13原則)
// ============================================================================

export const NF_GOVERNANCE_PRINCIPLES = [
  '組織運営等に関するガバナンスコード策定',
  '法人格を有すること (公益・一般)',
  '理事会の機能発揮 — 外部理事25%以上 / 女性理事40%以上',
  '理事の在任期間 — 原則10年以内',
  'コンプライアンス委員会設置',
  '危機管理体制 (不祥事対応規程)',
  '財務情報の開示 — 直近3期分',
  '懲罰制度の整備 (ハラスメント / ドーピング)',
  '指導者資格制度 (公認スポーツ指導者)',
  '法人運営基盤の強化 (会計士による監査)',
  'ステークホルダーへの開示 (HP/SNS)',
  '相談窓口設置 — 内部/外部',
  '評価とPDCAサイクル運用',
] as const;

/** NF (Nationals Federations) ガバナンスコード適合度 */
export function evaluateNfGovernance(input: {
  hasGovernanceCode: boolean;
  legalEntityKind: 'public_interest' | 'general' | 'voluntary';
  externalDirectorRatio: number;
  femaleDirectorRatio: number;
  longestDirectorTenureYears: number;
  hasComplianceCommittee: boolean;
  hasAuditByCpa: boolean;
  hasReportingChannel: boolean;
}): { score: number; max: number; gaps: string[] } {
  const gaps: string[] = [];
  let s = 0;
  const max = 8;
  if (input.hasGovernanceCode) s++; else gaps.push('ガバナンスコード未策定');
  if (input.legalEntityKind !== 'voluntary') s++; else gaps.push('法人格を取得すべき');
  if (input.externalDirectorRatio >= 0.25) s++; else gaps.push('外部理事25%未満');
  if (input.femaleDirectorRatio >= 0.4) s++; else gaps.push('女性理事40%未満');
  if (input.longestDirectorTenureYears <= 10) s++; else gaps.push('理事在任10年超');
  if (input.hasComplianceCommittee) s++; else gaps.push('コンプライアンス委員会未設置');
  if (input.hasAuditByCpa) s++; else gaps.push('公認会計士監査なし');
  if (input.hasReportingChannel) s++; else gaps.push('内部通報窓口なし');
  return { score: s, max, gaps };
}

// ============================================================================
// 4. アンチドーピング (WADA禁止表 + JADA)
// ============================================================================

/** WADA Code 禁止物質カテゴリ (主要グループ) */
export const WADA_PROHIBITED_CLASSES = {
  S0: '未承認物質',
  S1: '蛋白同化薬 (アナボリックステロイド)',
  S2: 'ペプチドホルモン / 成長因子',
  S3: 'β2作用薬',
  S4: 'ホルモン代謝調節薬',
  S5: '利尿薬 / 隠蔽薬',
  S6: '興奮薬',
  S7: '麻薬',
  S8: 'カンナビノイド',
  S9: 'グルココルチコイド',
  M1: '血液ドーピング',
  M2: '化学的・物理的操作',
  M3: '遺伝子・細胞ドーピング',
} as const;

/** TUE (治療使用特例) 申請の必要性判定 */
export function requiresTUE(input: {
  substance: string;
  substanceClass: keyof typeof WADA_PROHIBITED_CLASSES;
  isCompetitionPeriod: boolean;
  athleteLevel: 'international' | 'national' | 'recreational';
}): { needed: boolean; deadline: string } {
  // S6/S7/S8/S9 は競技会時のみ禁止
  const competitionOnly = ['S6', 'S7', 'S8', 'S9'].includes(input.substanceClass);
  if (competitionOnly && !input.isCompetitionPeriod) {
    return { needed: false, deadline: '競技会時のみ禁止のため、競技外使用はTUE不要' };
  }
  if (input.athleteLevel === 'international' || input.athleteLevel === 'national') {
    return { needed: true, deadline: '使用開始の30日前までにJADAへ申請 (緊急時は事後申請可)' };
  }
  return { needed: false, deadline: '一般競技者はTUE不要 — 通常医療として記録保管' };
}

// ============================================================================
// 5. チケット転売規制 (チケット不正転売禁止法 H30法律103)
// ============================================================================

/** 特定興行入場券の不正転売禁止 (H30.6施行) */
export function isIllegalResale(input: {
  ticketType: 'specified' | 'general'; // 特定興行入場券 (氏名/座席指定/同意)
  resalePriceJpy: number;
  faceValueJpy: number;
  isBusiness: boolean; // 反復継続の業として
  hasOrganizerConsent: boolean;
}): {
  illegal: boolean;
  reason: string;
  penalty: string;
} {
  if (input.ticketType !== 'specified') {
    return { illegal: false, reason: '一般チケット (特定興行入場券に該当しない)', penalty: '対象外' };
  }
  if (input.hasOrganizerConsent) {
    return { illegal: false, reason: '主催者同意あり (公式リセール)', penalty: '対象外' };
  }
  if (input.resalePriceJpy > input.faceValueJpy && input.isBusiness) {
    return {
      illegal: true,
      reason: '特定興行入場券を業として定価超で転売 — 不正転売禁止法3条違反',
      penalty: '1年以下の懲役 or 100万円以下の罰金 (法6条)',
    };
  }
  return { illegal: false, reason: '定価以下 or 非業 — 違法ではない', penalty: '対象外' };
}

// ============================================================================
// 6. 興行場法 + スタジアム / アリーナ
// ============================================================================

export interface VenueLicense {
  capacity: number;
  hasFireSafetyCert: boolean;
  hasMedicalRoom: boolean;
  emergencyExitsCount: number;
  toiletsPerCapacity1000: { male: number; female: number; multipurpose: number };
}

/** 興行場法 (S23法律137) 営業許可の事前チェック */
export function checkVenueLicenseReadiness(v: VenueLicense): {
  approvable: boolean;
  gaps: string[];
} {
  const gaps: string[] = [];
  if (!v.hasFireSafetyCert) gaps.push('消防法 検査済証が必要');
  if (!v.hasMedicalRoom) gaps.push('救護室設置 (5000人以上は医師常駐推奨)');
  if (v.emergencyExitsCount < Math.ceil(v.capacity / 1000)) {
    gaps.push(`非常口数不足 — ${Math.ceil(v.capacity / 1000)}カ所必要`);
  }
  // バリアフリー法 + 都市計画法
  if (v.toiletsPerCapacity1000.multipurpose < 1) {
    gaps.push('多目的トイレ最低1カ所必須 (バリアフリー法)');
  }
  return { approvable: gaps.length === 0, gaps };
}
