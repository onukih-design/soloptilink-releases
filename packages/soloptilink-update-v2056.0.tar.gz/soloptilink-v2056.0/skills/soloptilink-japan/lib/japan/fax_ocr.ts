/**
 * @fileoverview Phase 10 - FAX/紙書類 OCR ブリッジ
 *
 * 日本企業の現場では未だに「FAX で発注書」「紙の納品書」が残る。
 * 本モジュールは:
 *   1. FAX/スキャン画像 → OCR 結果 (テキスト + 座標) を入力として受け取る抽象 I/F
 *   2. 典型帳票 (注文書/納品書/請求書) のレイアウトテンプレートに照合して構造化
 *   3. 半角/全角/旧字体/罫線ノイズの正規化
 *   4. Excel 列名 (A1, B2 ...) へのマッピング (顧客現場の Excel 帳簿との突合用)
 *   5. 信頼度スコア + 不確実フィールドのハイライト出力
 *   6. 電帳法スキャナ保存要件 (解像度・カラー・タイムスタンプ) のチェック
 *
 * 実 OCR エンジン (Google Vision / Azure Form Recognizer / AWS Textract / 国内 Tegaki) は
 * アダプタとして注入可能。本モジュール自体は Pure TypeScript。
 */

// ============================================================================
// Types
// ============================================================================

/** OCR 結果のセル (テキスト + バウンディングボックス) */
export interface OcrCell {
  text: string;
  /** 0-1 の信頼度 */
  confidence: number;
  /** ピクセル単位の座標 (左上原点) */
  bbox: { x: number; y: number; width: number; height: number };
}

/** OCR 結果ページ */
export interface OcrPage {
  pageIndex: number;
  widthPx: number;
  heightPx: number;
  dpi: number;
  cells: OcrCell[];
  /** カラーモード */
  colorMode: 'mono' | 'gray' | 'color';
}

/** 帳票レイアウト定義 */
export interface DocumentLayout {
  layoutId: string;
  documentType: 'order' | 'delivery_note' | 'invoice' | 'receipt' | 'estimate' | 'unknown';
  /** A4 縦/横 を想定した相対座標で定義 (0-1) */
  fields: LayoutField[];
  /** ヘッダ判定キーワード (このどれかが含まれていれば該当レイアウト) */
  headerKeywords: string[];
}

export interface LayoutField {
  fieldName: string;
  /** 0-1 の相対座標 */
  rect: { xPct: number; yPct: number; widthPct: number; heightPct: number };
  /** 期待するデータ型 */
  expectedType: 'text' | 'number' | 'date' | 'amount' | 'kana' | 'kanji' | 'address' | 'phone';
  /** Excel 上の列名 (顧客の Excel 帳簿の列にマップする際) */
  excelColumn?: string;
  required: boolean;
}

/** 抽出結果 */
export interface ExtractedDocument {
  layoutId: string;
  documentType: DocumentLayout['documentType'];
  fields: ExtractedField[];
  /** 帳票全体の信頼度 (0-1) */
  overallConfidence: number;
  /** 注意警告 (低信頼度フィールド等) */
  warnings: string[];
}

export interface ExtractedField {
  fieldName: string;
  rawText: string;
  normalizedValue: string | number | null;
  confidence: number;
  /** 人間レビューが必要か */
  needsHumanReview: boolean;
}

// ============================================================================
// 標準レイアウトテンプレ (注文書/納品書/請求書)
// ============================================================================

export const STANDARD_LAYOUTS: DocumentLayout[] = [
  {
    layoutId: 'jp_order_a4_v1',
    documentType: 'order',
    headerKeywords: ['注文書', '発注書', 'ご注文', 'PURCHASE ORDER'],
    fields: [
      { fieldName: 'order_no', rect: { xPct: 0.7, yPct: 0.05, widthPct: 0.25, heightPct: 0.04 }, expectedType: 'text', excelColumn: 'A', required: true },
      { fieldName: 'order_date', rect: { xPct: 0.7, yPct: 0.10, widthPct: 0.25, heightPct: 0.04 }, expectedType: 'date', excelColumn: 'B', required: true },
      { fieldName: 'supplier_name', rect: { xPct: 0.05, yPct: 0.10, widthPct: 0.4, heightPct: 0.04 }, expectedType: 'text', excelColumn: 'C', required: true },
      { fieldName: 'orderer_name', rect: { xPct: 0.55, yPct: 0.20, widthPct: 0.4, heightPct: 0.04 }, expectedType: 'text', excelColumn: 'D', required: true },
      { fieldName: 'total_amount', rect: { xPct: 0.6, yPct: 0.85, widthPct: 0.35, heightPct: 0.05 }, expectedType: 'amount', excelColumn: 'E', required: true },
      { fieldName: 'tax', rect: { xPct: 0.6, yPct: 0.78, widthPct: 0.35, heightPct: 0.04 }, expectedType: 'amount', excelColumn: 'F', required: false },
      { fieldName: 'delivery_date', rect: { xPct: 0.05, yPct: 0.20, widthPct: 0.4, heightPct: 0.04 }, expectedType: 'date', excelColumn: 'G', required: true },
    ],
  },
  {
    layoutId: 'jp_invoice_a4_v1',
    documentType: 'invoice',
    headerKeywords: ['請求書', '御請求書', 'INVOICE', '適格請求書'],
    fields: [
      { fieldName: 'invoice_no', rect: { xPct: 0.7, yPct: 0.05, widthPct: 0.25, heightPct: 0.04 }, expectedType: 'text', excelColumn: 'A', required: true },
      { fieldName: 'invoice_date', rect: { xPct: 0.7, yPct: 0.10, widthPct: 0.25, heightPct: 0.04 }, expectedType: 'date', excelColumn: 'B', required: true },
      { fieldName: 'registration_no', rect: { xPct: 0.05, yPct: 0.15, widthPct: 0.4, heightPct: 0.04 }, expectedType: 'text', excelColumn: 'C', required: true /* インボイス制度 */ },
      { fieldName: 'subtotal_8', rect: { xPct: 0.6, yPct: 0.75, widthPct: 0.35, heightPct: 0.04 }, expectedType: 'amount', excelColumn: 'D', required: false },
      { fieldName: 'subtotal_10', rect: { xPct: 0.6, yPct: 0.79, widthPct: 0.35, heightPct: 0.04 }, expectedType: 'amount', excelColumn: 'E', required: false },
      { fieldName: 'tax_total', rect: { xPct: 0.6, yPct: 0.83, widthPct: 0.35, heightPct: 0.04 }, expectedType: 'amount', excelColumn: 'F', required: true },
      { fieldName: 'grand_total', rect: { xPct: 0.6, yPct: 0.88, widthPct: 0.35, heightPct: 0.05 }, expectedType: 'amount', excelColumn: 'G', required: true },
      { fieldName: 'bank_account', rect: { xPct: 0.05, yPct: 0.85, widthPct: 0.5, heightPct: 0.10 }, expectedType: 'text', excelColumn: 'H', required: false },
    ],
  },
  {
    layoutId: 'jp_delivery_note_a4_v1',
    documentType: 'delivery_note',
    headerKeywords: ['納品書', '納品控', 'DELIVERY NOTE'],
    fields: [
      { fieldName: 'delivery_no', rect: { xPct: 0.7, yPct: 0.05, widthPct: 0.25, heightPct: 0.04 }, expectedType: 'text', excelColumn: 'A', required: true },
      { fieldName: 'delivery_date', rect: { xPct: 0.7, yPct: 0.10, widthPct: 0.25, heightPct: 0.04 }, expectedType: 'date', excelColumn: 'B', required: true },
      { fieldName: 'recipient', rect: { xPct: 0.05, yPct: 0.10, widthPct: 0.4, heightPct: 0.04 }, expectedType: 'text', excelColumn: 'C', required: true },
      { fieldName: 'sender', rect: { xPct: 0.55, yPct: 0.20, widthPct: 0.4, heightPct: 0.04 }, expectedType: 'text', excelColumn: 'D', required: true },
      { fieldName: 'item_count', rect: { xPct: 0.05, yPct: 0.40, widthPct: 0.9, heightPct: 0.04 }, expectedType: 'number', excelColumn: 'E', required: true },
    ],
  },
];

// ============================================================================
// レイアウト判定 (ヘッダキーワードから)
// ============================================================================

export function detectLayout(page: OcrPage, layouts = STANDARD_LAYOUTS): DocumentLayout | null {
  // ページ上部 1/4 のテキストを連結
  const topText = page.cells
    .filter((c) => c.bbox.y < page.heightPx * 0.25)
    .map((c) => c.text)
    .join(' ');
  for (const layout of layouts) {
    for (const kw of layout.headerKeywords) {
      if (topText.includes(kw)) return layout;
    }
  }
  return null;
}

// ============================================================================
// セル抽出 (相対座標 → cells フィルタ)
// ============================================================================

export function extractField(page: OcrPage, field: LayoutField): { text: string; confidence: number } {
  const xMin = page.widthPx * field.rect.xPct;
  const yMin = page.heightPx * field.rect.yPct;
  const xMax = xMin + page.widthPx * field.rect.widthPct;
  const yMax = yMin + page.heightPx * field.rect.heightPct;

  const inside = page.cells.filter(
    (c) => c.bbox.x >= xMin && c.bbox.x <= xMax && c.bbox.y >= yMin && c.bbox.y <= yMax,
  );

  if (inside.length === 0) return { text: '', confidence: 0 };

  const text = inside.map((c) => c.text).join('');
  const confidence = inside.reduce((s, c) => s + c.confidence, 0) / inside.length;
  return { text, confidence };
}

// ============================================================================
// 値の正規化
// ============================================================================

/** 全角→半角 (英数字・記号) */
export function toHalfWidth(s: string): string {
  return s.replace(/[\uFF01-\uFF5E]/g, (ch) => String.fromCharCode(ch.charCodeAt(0) - 0xfee0))
    .replace(/\u3000/g, ' ');
}

/** 「\u00a51,234,567」「1,234,567円」「金壱百万円也」(漢数字) → 1234567 */
export function parseAmount(raw: string): number | null {
  const cleaned = toHalfWidth(raw)
    .replace(/[¥￥,，円也金\s]/g, '')
    .replace(/[円也]/g, '');
  if (!cleaned) return null;

  // 半角数字のみ
  if (/^\d+$/.test(cleaned)) return parseInt(cleaned, 10);

  // 小数点付き
  if (/^\d+\.\d+$/.test(cleaned)) return parseFloat(cleaned);

  // 漢数字 (簡易: 一二三四五六七八九十百千万億)
  const kanjiNum = parseKanjiNumber(cleaned);
  if (kanjiNum !== null) return kanjiNum;

  return null;
}

const KANJI_DIGITS: Record<string, number> = {
  零: 0, 一: 1, 壱: 1, 二: 2, 弐: 2, 三: 3, 参: 3, 四: 4, 五: 5, 六: 6, 七: 7, 八: 8, 九: 9,
};
const KANJI_UNITS: Record<string, number> = {
  十: 10, 拾: 10, 百: 100, 千: 1000, 万: 10000, 億: 100000000, 兆: 1000000000000,
};

function parseKanjiNumber(s: string): number | null {
  let result = 0;
  let current = 0;
  for (const ch of s) {
    if (ch in KANJI_DIGITS) {
      current = current * 10 + KANJI_DIGITS[ch];
    } else if (ch in KANJI_UNITS) {
      const unit = KANJI_UNITS[ch];
      if (unit >= 10000) {
        result = (result + (current || 1)) * unit;
        current = 0;
      } else {
        current = (current || 1) * unit;
        result += current;
        current = 0;
      }
    } else {
      return null;
    }
  }
  return result + current;
}

/**
 * 「令和6年4月23日」「R6.4.23」「2026/04/23」「26-4-23」 → ISO8601 (YYYY-MM-DD)
 */
export function parseJpDate(raw: string): string | null {
  const s = toHalfWidth(raw).replace(/\s/g, '');

  // 和暦
  const wareki = /(令和|平成|昭和|大正|明治|R|H|S|T|M)(\d+)[年./-](\d+)[月./-](\d+)/.exec(s);
  if (wareki) {
    const eraName = wareki[1];
    const yy = parseInt(wareki[2], 10);
    const mm = parseInt(wareki[3], 10);
    const dd = parseInt(wareki[4], 10);
    const eraOffset: Record<string, number> = { 令和: 2018, R: 2018, 平成: 1988, H: 1988, 昭和: 1925, S: 1925, 大正: 1911, T: 1911, 明治: 1867, M: 1867 };
    const yyyy = eraOffset[eraName] + yy;
    return `${yyyy}-${String(mm).padStart(2, '0')}-${String(dd).padStart(2, '0')}`;
  }

  // 西暦
  const seireki = /(\d{4})[年./-](\d{1,2})[月./-](\d{1,2})/.exec(s);
  if (seireki) {
    const yyyy = parseInt(seireki[1], 10);
    const mm = parseInt(seireki[2], 10);
    const dd = parseInt(seireki[3], 10);
    return `${yyyy}-${String(mm).padStart(2, '0')}-${String(dd).padStart(2, '0')}`;
  }

  return null;
}

// ============================================================================
// メインパイプライン
// ============================================================================

export function extractDocument(page: OcrPage, layouts = STANDARD_LAYOUTS): ExtractedDocument {
  const layout = detectLayout(page, layouts);
  if (!layout) {
    return {
      layoutId: 'unknown',
      documentType: 'unknown',
      fields: [],
      overallConfidence: 0,
      warnings: ['レイアウト判定失敗: ヘッダキーワード未検出'],
    };
  }

  const fields: ExtractedField[] = [];
  const warnings: string[] = [];
  let totalConfidence = 0;
  let counted = 0;

  for (const field of layout.fields) {
    const { text, confidence } = extractField(page, field);
    let normalized: string | number | null = text;
    if (text) {
      switch (field.expectedType) {
        case 'amount':
        case 'number':
          normalized = parseAmount(text);
          break;
        case 'date':
          normalized = parseJpDate(text);
          break;
        case 'address':
        case 'phone':
        case 'kana':
        case 'kanji':
        case 'text':
          normalized = toHalfWidth(text).trim();
          break;
      }
    }

    const needsReview = confidence < 0.85 || (field.required && !normalized);
    if (needsReview) {
      warnings.push(`要レビュー: ${field.fieldName} (信頼度=${confidence.toFixed(2)} / 値=${String(normalized) || '空'})`);
    }
    if (field.required && !normalized) {
      warnings.push(`必須欠落: ${field.fieldName}`);
    }

    fields.push({
      fieldName: field.fieldName,
      rawText: text,
      normalizedValue: normalized,
      confidence,
      needsHumanReview: needsReview,
    });
    totalConfidence += confidence;
    counted++;
  }

  return {
    layoutId: layout.layoutId,
    documentType: layout.documentType,
    fields,
    overallConfidence: counted > 0 ? totalConfidence / counted : 0,
    warnings,
  };
}

// ============================================================================
// 電帳法スキャナ保存要件チェック
// ============================================================================

/**
 * 電帳法スキャナ保存の最低要件 (令和3年改正後):
 *   - 解像度 200dpi 以上
 *   - カラー 256階調以上 (※重要書類は必須、一般書類はグレー OK)
 *   - タイムスタンプ付与
 */
export function checkScannerStorageCompliance(input: {
  dpi: number;
  colorMode: 'mono' | 'gray' | 'color';
  timestampApplied: boolean;
  isImportantDocument: boolean; // 契約書/領収書/請求書 等
}): { ok: boolean; missing: string[] } {
  const missing: string[] = [];
  if (input.dpi < 200) missing.push(`解像度 ${input.dpi}dpi: 200dpi 以上必要`);
  if (input.isImportantDocument && input.colorMode !== 'color') {
    missing.push('重要書類はカラー (256階調以上) 必須');
  }
  if (!input.timestampApplied) missing.push('タイムスタンプ未付与');
  return { ok: missing.length === 0, missing };
}

// ============================================================================
// Excel マッピング
// ============================================================================

/**
 * 抽出結果を顧客の Excel 帳簿の列にマップ。
 * 結果は Excel に直接ペーストできる行データ (object) を返す。
 */
export function toExcelRow(extracted: ExtractedDocument, layout: DocumentLayout): Record<string, string | number | null> {
  const row: Record<string, string | number | null> = {};
  for (const field of extracted.fields) {
    const layoutField = layout.fields.find((f) => f.fieldName === field.fieldName);
    if (layoutField?.excelColumn) {
      row[layoutField.excelColumn] = field.normalizedValue;
    }
  }
  return row;
}

// ============================================================================
// Default exports
// ============================================================================

export const FAX_OCR_QUALITY_THRESHOLDS = {
  MIN_DPI: 200,
  MIN_FIELD_CONFIDENCE: 0.85,
  MIN_OVERALL_CONFIDENCE: 0.80,
};
