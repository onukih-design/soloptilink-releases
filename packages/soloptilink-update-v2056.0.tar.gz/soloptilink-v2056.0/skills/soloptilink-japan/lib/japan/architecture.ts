/**
 * architecture.ts — 1級建築士レベル建築知識DB (Phase 9)
 *
 * Claude Code が絶対に持たない「日本の建築実務に刺さる」知識を
 * コードから import で参照できる静的 DB として凝集する。
 *
 * カバー領域:
 *   1. 建築基準法 (集団規定 / 単体規定 / 構造 / 防火 / 避難 / 日影 / 斜線)
 *   2. 建築士法 (業務範囲 / 一級・二級・木造の扱える規模)
 *   3. 構造設計 (木造 / S造 / RC造 / SRC造 + 壁量計算 / 4号特例)
 *   4. 省エネ基準 (外皮 UA/ηAC / 一次エネルギー消費量)
 *   5. 都市計画法 (用途地域 13種 + 容積率 / 建ぺい率 / 高度地区)
 *   6. 確認申請・完了検査フロー
 *   7. 設備 (給排水・電気・空調・ガス) の日本基準
 *   8. バリアフリー法 / 品確法 / 瑕疵担保 / 住宅瑕疵担保履行法
 *   9. JIS / JAS 規格参照
 *  10. 積算の構造 (仮設 / 土工 / 躯体 / 仕上 / 設備 / 外構 / 共通仮設 / 諸経費)
 *
 * 使い方:
 *   import { getBuildingCode, calcFloorAreaRatio, useDistricts, checkStructureFeasibility } from '@/lib/japan/architecture';
 *
 * 注意: 本 DB は 2024〜2026 年時点の法令を基準とする。
 *       改正がある場合は `effective_until` フィールドで新旧を切り替える運用。
 *       実プロジェクトでは最新の官報・国交省告示を必ず確認すること。
 */

// =============================================================================
// 1. 用途地域 13種 (都市計画法 第8条)
// =============================================================================

export type UseDistrictCode =
  | 'Category1LowRise'        // 第一種低層住居専用地域
  | 'Category2LowRise'        // 第二種低層住居専用地域
  | 'Category1MidHighRise'    // 第一種中高層住居専用地域
  | 'Category2MidHighRise'    // 第二種中高層住居専用地域
  | 'Category1Residential'    // 第一種住居地域
  | 'Category2Residential'    // 第二種住居地域
  | 'QuasiResidential'        // 準住居地域
  | 'RuralResidential'        // 田園住居地域
  | 'Neighborhood'            // 近隣商業地域
  | 'Commercial'              // 商業地域
  | 'QuasiIndustrial'         // 準工業地域
  | 'Industrial'              // 工業地域
  | 'IndustrialExclusive';    // 工業専用地域

export interface UseDistrict {
  code: UseDistrictCode;
  name_ja: string;
  abbr: string;
  /** 建ぺい率の上限範囲(%) */
  buildingCoverageRange: [number, number];
  /** 容積率の上限範囲(%) */
  floorAreaRatioRange: [number, number];
  /** 北側斜線 規制 */
  northernSlopeRestriction: boolean;
  /** 絶対高さ制限 (m) - null の場合は地区による */
  absoluteHeightLimit: number | null;
  /** 日影規制 適用地域 */
  shadowRegulationApplicable: boolean;
  allowedUses: string[];
  prohibitedUses: string[];
}

export const USE_DISTRICTS: Readonly<Record<UseDistrictCode, UseDistrict>> = Object.freeze({
  Category1LowRise: {
    code: 'Category1LowRise',
    name_ja: '第一種低層住居専用地域',
    abbr: '1低',
    buildingCoverageRange: [30, 60],
    floorAreaRatioRange: [50, 200],
    northernSlopeRestriction: true,
    absoluteHeightLimit: 12, // 10m or 12m (地区指定)
    shadowRegulationApplicable: true,
    allowedUses: ['戸建住宅', '共同住宅', '小規模店舗(兼用住宅で50㎡以下)', '診療所', '保育所', '小中学校'],
    prohibitedUses: ['店舗(50㎡超)', '事務所', '工場', 'カラオケ', 'パチンコ', '風俗営業'],
  },
  Category2LowRise: {
    code: 'Category2LowRise',
    name_ja: '第二種低層住居専用地域',
    abbr: '2低',
    buildingCoverageRange: [30, 60],
    floorAreaRatioRange: [50, 200],
    northernSlopeRestriction: true,
    absoluteHeightLimit: 12,
    shadowRegulationApplicable: true,
    allowedUses: ['戸建住宅', '共同住宅', '150㎡以下の店舗', '小中学校'],
    prohibitedUses: ['大規模店舗', '工場', 'カラオケ', 'パチンコ'],
  },
  Category1MidHighRise: {
    code: 'Category1MidHighRise',
    name_ja: '第一種中高層住居専用地域',
    abbr: '1中高',
    buildingCoverageRange: [30, 60],
    floorAreaRatioRange: [100, 500],
    northernSlopeRestriction: true,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: true,
    allowedUses: ['住宅', '共同住宅', '500㎡以下の店舗', '病院', '大学'],
    prohibitedUses: ['工場', 'カラオケ', 'パチンコ'],
  },
  Category2MidHighRise: {
    code: 'Category2MidHighRise',
    name_ja: '第二種中高層住居専用地域',
    abbr: '2中高',
    buildingCoverageRange: [30, 60],
    floorAreaRatioRange: [100, 500],
    northernSlopeRestriction: true,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: true,
    allowedUses: ['住宅', '1500㎡以下の店舗', '事務所'],
    prohibitedUses: ['工場', 'パチンコ'],
  },
  Category1Residential: {
    code: 'Category1Residential',
    name_ja: '第一種住居地域',
    abbr: '1住',
    buildingCoverageRange: [50, 80],
    floorAreaRatioRange: [100, 500],
    northernSlopeRestriction: false,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: true,
    allowedUses: ['住宅', '3000㎡以下の店舗', 'ホテル'],
    prohibitedUses: ['風俗', 'カラオケ(特定条件)'],
  },
  Category2Residential: {
    code: 'Category2Residential',
    name_ja: '第二種住居地域',
    abbr: '2住',
    buildingCoverageRange: [50, 80],
    floorAreaRatioRange: [100, 500],
    northernSlopeRestriction: false,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: true,
    allowedUses: ['住宅', '10000㎡以下の店舗', 'パチンコ', 'カラオケ'],
    prohibitedUses: ['大規模工場'],
  },
  QuasiResidential: {
    code: 'QuasiResidential',
    name_ja: '準住居地域',
    abbr: '準住',
    buildingCoverageRange: [50, 80],
    floorAreaRatioRange: [100, 500],
    northernSlopeRestriction: false,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: true,
    allowedUses: ['住宅', '店舗', '小規模自動車関連施設'],
    prohibitedUses: ['大規模工場'],
  },
  RuralResidential: {
    code: 'RuralResidential',
    name_ja: '田園住居地域',
    abbr: '田住',
    buildingCoverageRange: [30, 60],
    floorAreaRatioRange: [50, 200],
    northernSlopeRestriction: true,
    absoluteHeightLimit: 12,
    shadowRegulationApplicable: true,
    allowedUses: ['住宅', '農産物直売所', '農家レストラン(500㎡以下)'],
    prohibitedUses: ['大規模店舗', '工場'],
  },
  Neighborhood: {
    code: 'Neighborhood',
    name_ja: '近隣商業地域',
    abbr: '近商',
    buildingCoverageRange: [60, 80],
    floorAreaRatioRange: [100, 500],
    northernSlopeRestriction: false,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: false,
    allowedUses: ['店舗', '事務所', '住宅', '小規模工場'],
    prohibitedUses: ['危険工場'],
  },
  Commercial: {
    code: 'Commercial',
    name_ja: '商業地域',
    abbr: '商',
    buildingCoverageRange: [80, 80],
    floorAreaRatioRange: [200, 1300],
    northernSlopeRestriction: false,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: false,
    allowedUses: ['店舗', '事務所', 'ホテル', '住宅', '映画館', '風俗(一部)'],
    prohibitedUses: ['危険工場'],
  },
  QuasiIndustrial: {
    code: 'QuasiIndustrial',
    name_ja: '準工業地域',
    abbr: '準工',
    buildingCoverageRange: [50, 80],
    floorAreaRatioRange: [100, 500],
    northernSlopeRestriction: false,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: false,
    allowedUses: ['住宅', '店舗', '工場(軽工業)'],
    prohibitedUses: ['危険工場', '風俗(一部)'],
  },
  Industrial: {
    code: 'Industrial',
    name_ja: '工業地域',
    abbr: '工',
    buildingCoverageRange: [50, 60],
    floorAreaRatioRange: [100, 400],
    northernSlopeRestriction: false,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: false,
    allowedUses: ['工場', '住宅', '店舗(10000㎡以下)'],
    prohibitedUses: ['病院', '学校', 'ホテル'],
  },
  IndustrialExclusive: {
    code: 'IndustrialExclusive',
    name_ja: '工業専用地域',
    abbr: '工専',
    buildingCoverageRange: [30, 60],
    floorAreaRatioRange: [100, 400],
    northernSlopeRestriction: false,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: false,
    allowedUses: ['工場全般'],
    prohibitedUses: ['住宅', '病院', '学校', '店舗', 'ホテル'],
  },
});

/** 13用途地域を配列で取得 */
export function listUseDistricts(): UseDistrict[] {
  return Object.values(USE_DISTRICTS);
}

/** 用途地域から特定用途が建てられるか判定 (概算判定。最終判断は特定行政庁) */
export function canBuildUse(district: UseDistrictCode, useType: string): {
  allowed: boolean;
  reason: string;
  suggestion?: string;
} {
  const d = USE_DISTRICTS[district];
  const prohibited = d.prohibitedUses.find(u => useType.includes(u) || u.includes(useType));
  if (prohibited) {
    return { allowed: false, reason: `${d.name_ja}では「${prohibited}」は原則不可`, suggestion: '用途地域を確認し、可能な地域を選定してください' };
  }
  const allowed = d.allowedUses.find(u => useType.includes(u) || u.includes(useType));
  if (allowed) {
    return { allowed: true, reason: `${d.name_ja}で「${allowed}」は許容` };
  }
  return { allowed: false, reason: `${d.name_ja}では「${useType}」の可否を個別判断要(特定行政庁確認)`, suggestion: '建築士に相談してください' };
}

// =============================================================================
// 2. 建築基準法 集団規定
// =============================================================================

/** 前面道路幅員による容積率制限 (建基法52条2項) */
export function calcFloorAreaRatioByRoad(
  frontRoadWidthM: number,
  district: UseDistrictCode,
  zonedFar: number, // 都市計画で指定された容積率(%)
): number {
  // 住居系: 前面道路幅員 × 0.4 (商業系は × 0.6)
  const isResidential = [
    'Category1LowRise', 'Category2LowRise',
    'Category1MidHighRise', 'Category2MidHighRise',
    'Category1Residential', 'Category2Residential',
    'QuasiResidential', 'RuralResidential',
  ].includes(district);
  const coef = isResidential ? 0.4 : 0.6;
  const roadFar = frontRoadWidthM * coef * 100;
  return Math.min(zonedFar, roadFar);
}

/** 建ぺい率の緩和 (角地 +10%, 防火地域内の耐火建築物 +10%) */
export function calcBuildingCoverageWithRelief(
  baseCoverage: number,
  opts: { corner?: boolean; fireResistant?: boolean; fireZone?: 'fire' | 'quasi' | 'none' } = {},
): number {
  let coverage = baseCoverage;
  if (opts.corner) coverage += 10;
  if (opts.fireResistant && opts.fireZone === 'fire') coverage += 10;
  // 角地 + 防火地域耐火で +20% (建基法53条3項)
  return Math.min(100, coverage);
}

/** 絶対高さ制限(低層専用地域)を確認 */
export function checkAbsoluteHeight(
  proposedHeightM: number,
  district: UseDistrictCode,
): { ok: boolean; limit: number | null; overM: number } {
  const d = USE_DISTRICTS[district];
  if (d.absoluteHeightLimit == null) return { ok: true, limit: null, overM: 0 };
  const over = proposedHeightM - d.absoluteHeightLimit;
  return { ok: over <= 0, limit: d.absoluteHeightLimit, overM: Math.max(0, over) };
}

/**
 * 北側斜線 (建基法56条): 隣地境界から真北に向かって高さ制限
 * 低層専用: 5m + 1.25×距離、中高層専用: 10m + 1.25×距離
 */
export function calcNorthernSlopeLimit(
  distanceFromNorthBoundaryM: number,
  district: UseDistrictCode,
): { applies: boolean; heightLimitM: number } {
  const d = USE_DISTRICTS[district];
  if (!d.northernSlopeRestriction) return { applies: false, heightLimitM: Infinity };
  const base = district === 'Category1LowRise' || district === 'Category2LowRise' || district === 'RuralResidential' ? 5 : 10;
  return { applies: true, heightLimitM: base + 1.25 * distanceFromNorthBoundaryM };
}

/**
 * 道路斜線 (建基法56条1項1号): 前面道路の反対側境界線から1.25 or 1.5の勾配
 */
export function calcRoadSlopeLimit(
  distanceFromOppositeRoadM: number,
  district: UseDistrictCode,
): number {
  const isResidential = [
    'Category1LowRise', 'Category2LowRise',
    'Category1MidHighRise', 'Category2MidHighRise',
    'Category1Residential', 'Category2Residential',
    'QuasiResidential', 'RuralResidential',
  ].includes(district);
  const coef = isResidential ? 1.25 : 1.5;
  return distanceFromOppositeRoadM * coef;
}

/**
 * 隣地斜線 (建基法56条1項2号): 隣地境界から20m(住居系) or 31m(その他) 上で1.25 or 2.5
 */
export function calcAdjacentSlopeLimit(
  distanceFromAdjacentBoundaryM: number,
  district: UseDistrictCode,
): number {
  const isResidential = [
    'Category1MidHighRise', 'Category2MidHighRise',
    'Category1Residential', 'Category2Residential',
    'QuasiResidential',
  ].includes(district);
  const isLowRise = district === 'Category1LowRise' || district === 'Category2LowRise' || district === 'RuralResidential';
  if (isLowRise) return 0; // 低層専用は絶対高さで規制される
  const base = isResidential ? 20 : 31;
  const coef = isResidential ? 1.25 : 2.5;
  return base + distanceFromAdjacentBoundaryM * coef;
}

/**
 * 日影規制 (建基法56条の2): 冬至日 8:00〜16:00 の日影時間規制
 */
export function getShadowRegulation(district: UseDistrictCode): {
  applies: boolean;
  measurementHeightM: number;
  tiers: { range: '5mLine' | '10mLine'; maxHours: number[] }[];
} {
  const d = USE_DISTRICTS[district];
  if (!d.shadowRegulationApplicable) {
    return { applies: false, measurementHeightM: 0, tiers: [] };
  }
  const isLowRise = district === 'Category1LowRise' || district === 'Category2LowRise' || district === 'RuralResidential';
  const height = isLowRise ? 1.5 : 4.0; // 平均地盤面からの測定面高さ
  return {
    applies: true,
    measurementHeightM: height,
    tiers: [
      { range: '5mLine', maxHours: [3, 4, 5] },   // 境界から 5m超〜10m: 3h/4h/5h (地区指定)
      { range: '10mLine', maxHours: [2, 2.5, 3] }, // 10m超: 2h/2.5h/3h
    ],
  };
}

// =============================================================================
// 3. 構造設計 (建築基準法施行令 + 告示)
// =============================================================================

export type StructureType = 'wood' | 'steel' | 'rc' | 'src' | 'clt' | 'mixed';

export interface StructureSpec {
  type: StructureType;
  /** 4号建築物特例の対象か */
  exemption4go: boolean;
  /** 構造計算ルート */
  calcRoute: 'route1' | 'route2' | 'route3' | 'timeHistory';
  /** 必要な構造計算 */
  requiredCalcs: string[];
}

/**
 * 構造計算ルート判定 (建基法20条 + 令81条)
 *   木造: 2階以下 かつ 延床 500㎡以下 かつ 高さ 13m以下 かつ 軒高 9m以下 → 4号特例
 *   ただし 2025年4月以降は 4号特例縮小予定 (2階建て木造は全て構造計算必要になる方向)
 */
export function determineStructureRoute(opts: {
  type: StructureType;
  stories: number;
  floorArea: number;
  heightM: number;
  eaveHeightM?: number;
  hasSoftStory?: boolean;
  spanM?: number;
}): StructureSpec {
  const { type, stories, floorArea, heightM, eaveHeightM = heightM, hasSoftStory, spanM } = opts;

  // 4号建築物特例 (〜2025/3末)
  if (type === 'wood' && stories <= 2 && floorArea <= 500 && heightM <= 13 && eaveHeightM <= 9) {
    return {
      type,
      exemption4go: true,
      calcRoute: 'route1',
      requiredCalcs: ['壁量計算(令46条)', '壁配置バランス(四分割法)', 'N値計算(柱頭柱脚金物)'],
    };
  }

  // 超高層 (60m超) → 時刻歴応答解析
  if (heightM > 60) {
    return {
      type,
      exemption4go: false,
      calcRoute: 'timeHistory',
      requiredCalcs: ['時刻歴応答解析(告示1461号)', '大臣認定取得必要'],
    };
  }

  // ルート3 (保有水平耐力計算)
  if (hasSoftStory || (type === 'steel' && stories >= 4) || heightM > 31) {
    return {
      type,
      exemption4go: false,
      calcRoute: 'route3',
      requiredCalcs: ['一次設計(許容応力度)', '保有水平耐力計算(令82条の3)', 'Ds値算定', '偏心率/剛性率検証'],
    };
  }

  // ルート2 (許容応力度等計算 + 剛性率/偏心率)
  if (heightM > 20 || (spanM != null && spanM >= 6)) {
    return {
      type,
      exemption4go: false,
      calcRoute: 'route2',
      requiredCalcs: ['許容応力度計算', '層間変形角≤1/200', '剛性率≥0.6', '偏心率≤0.15'],
    };
  }

  // ルート1 (許容応力度のみ)
  return {
    type,
    exemption4go: false,
    calcRoute: 'route1',
    requiredCalcs: ['許容応力度計算(令82条)', '長期荷重 + 短期荷重(地震/風)'],
  };
}

/**
 * 木造壁量計算 (令46条): 地震力用 + 風圧力用
 *   必要壁量 = 床面積 × 係数 (cm/㎡)
 */
export function calcRequiredWallQuantityWood(opts: {
  floorAreaM2: number;
  stories: number;
  targetStory: number;  // 1F or 2F
  roofWeight: 'light' | 'heavy'; // 金属屋根=light, 瓦=heavy
  windAreaM2: number; // 見付面積
}): { earthquake_cm: number; wind_cm: number; required_cm: number } {
  const { floorAreaM2, stories, targetStory, roofWeight, windAreaM2 } = opts;
  // 地震力用係数 (cm/㎡) — 軽い屋根 2F建ての1F は 29, 重い屋根は 33 等 (令46条別表)
  const earthquakeCoef: Record<string, number> = {
    'light_2s_1f': 29, 'light_2s_2f': 15, 'light_1s_1f': 11,
    'heavy_2s_1f': 33, 'heavy_2s_2f': 21, 'heavy_1s_1f': 15,
  };
  const key = `${roofWeight}_${stories}s_${targetStory}f`;
  const eqCoef = earthquakeCoef[key] ?? 29;
  const earthquake_cm = floorAreaM2 * eqCoef;
  // 風圧力用 = 見付面積 × 50cm/㎡ (一般地域)
  const wind_cm = windAreaM2 * 50;
  return {
    earthquake_cm,
    wind_cm,
    required_cm: Math.max(earthquake_cm, wind_cm),
  };
}

// =============================================================================
// 4. 防火・避難 (建築基準法 21条〜27条 + 令112〜129条)
// =============================================================================

export type FireZone = 'fire' | 'quasi' | 'none';

export interface FireResistantSpec {
  /** 耐火建築物相当 */
  fireResistant: boolean;
  /** 準耐火建築物相当 */
  quasiFireResistant: boolean;
  /** 求められる壁・柱・床・梁・屋根・階段の構造等級 */
  requirements: { part: string; duration: string }[];
}

/** 用途・階数・延床から耐火要求を判定 */
export function requiredFireResistance(opts: {
  fireZone: FireZone;
  buildingType: 'residential' | 'detached' | 'store' | 'hotel' | 'hospital' | 'school' | 'factory';
  stories: number;
  floorAreaM2: number;
}): FireResistantSpec {
  const { fireZone, buildingType, stories, floorAreaM2 } = opts;

  // 防火地域 3階以上 or 延床100㎡超 → 耐火建築物
  if (fireZone === 'fire' && (stories >= 3 || floorAreaM2 > 100)) {
    return {
      fireResistant: true,
      quasiFireResistant: false,
      requirements: [
        { part: '主要構造部(柱/梁/壁/床/屋根/階段)', duration: '1〜3時間耐火' },
        { part: '外壁(延焼のおそれのある部分)', duration: '1時間耐火 + 防火設備' },
      ],
    };
  }

  // 準防火地域 4階以上 or 延床1500㎡超 → 耐火建築物
  if (fireZone === 'quasi' && (stories >= 4 || floorAreaM2 > 1500)) {
    return {
      fireResistant: true,
      quasiFireResistant: false,
      requirements: [
        { part: '主要構造部', duration: '1〜3時間耐火' },
      ],
    };
  }

  // 準防火地域 3階建て or 延床500㎡超 → 準耐火建築物
  if (fireZone === 'quasi' && (stories === 3 || floorAreaM2 > 500)) {
    return {
      fireResistant: false,
      quasiFireResistant: true,
      requirements: [
        { part: '主要構造部', duration: '45分準耐火 or 1時間準耐火' },
      ],
    };
  }

  // 特殊建築物 (ホテル/病院/学校) は規模別に耐火要求
  if (['hotel', 'hospital', 'school'].includes(buildingType) && floorAreaM2 > 200) {
    return {
      fireResistant: floorAreaM2 > 3000,
      quasiFireResistant: floorAreaM2 <= 3000,
      requirements: [{ part: '主要構造部', duration: floorAreaM2 > 3000 ? '1時間耐火' : '45分準耐火' }],
    };
  }

  return {
    fireResistant: false,
    quasiFireResistant: false,
    requirements: [{ part: '原則', duration: '一般構造で可(ただし延焼のおそれのある部分は防火設備)' }],
  };
}

/**
 * 避難 2方向避難の要否 (令121条)
 * 共同住宅/ホテル/病院/物販で床面積超過 or 階上避難距離30m超
 */
export function requires2WayEvacuation(opts: {
  buildingType: 'apartment' | 'hotel' | 'hospital' | 'store' | 'office' | 'school';
  storyFloorArea: number;
  evacuationDistanceM: number;
  isFireResistant: boolean;
}): boolean {
  const { buildingType, storyFloorArea, evacuationDistanceM, isFireResistant } = opts;
  if (evacuationDistanceM > 30) return true;
  if (buildingType === 'apartment' && storyFloorArea > 100) return true;
  if (['hotel', 'hospital'].includes(buildingType) && storyFloorArea > 100) return true;
  if (buildingType === 'store' && storyFloorArea > 1500 && !isFireResistant) return true;
  return false;
}

/** 直通階段までの歩行距離 (令120条) */
export function maxEvacuationDistanceM(opts: {
  buildingType: string;
  isFireResistant: boolean;
  isMajorStruct: boolean;
}): number {
  const { isFireResistant, isMajorStruct } = opts;
  // 耐火 + 主要構造部が準不燃以上 = 50m, 耐火のみ = 40m, その他 = 30m
  if (isFireResistant && isMajorStruct) return 50;
  if (isFireResistant) return 40;
  return 30;
}

// =============================================================================
// 5. 建築士法 (設計・監理ができる規模)
// =============================================================================

export type ArchitectLicense = 'first' | 'second' | 'wood' | 'none';

/** 設計可能か判定 (建築士法3条〜3条の3) */
export function canDesign(
  license: ArchitectLicense,
  opts: { type: StructureType; stories: number; heightM: number; eaveHeightM: number; floorAreaM2: number; specialUse?: boolean },
): { allowed: boolean; reason: string } {
  const { type, stories, heightM, eaveHeightM, floorAreaM2, specialUse } = opts;

  // 1級建築士専属範囲 (建築士法3条)
  const requiresFirst =
    (type !== 'wood' && floorAreaM2 > 300) ||
    stories >= 3 ||
    heightM > 13 ||
    eaveHeightM > 9 ||
    floorAreaM2 > 1000 ||
    specialUse;

  if (requiresFirst) {
    if (license === 'first') return { allowed: true, reason: '1級建築士範囲' };
    return { allowed: false, reason: '1級建築士の業務独占範囲です(建築士法3条)' };
  }

  // 2級建築士範囲
  if (license === 'first' || license === 'second') {
    return { allowed: true, reason: '2級建築士以上で設計可' };
  }

  // 木造建築士範囲 (2階以下/延床100㎡超300㎡以下の木造)
  if (type === 'wood' && stories <= 2 && floorAreaM2 > 100 && floorAreaM2 <= 300) {
    if (license === 'wood') return { allowed: true, reason: '木造建築士範囲' };
    return { allowed: false, reason: '木造建築士以上が必要' };
  }

  // 小規模 (100㎡以下 木造 1〜2階) は無資格可
  if (type === 'wood' && stories <= 2 && floorAreaM2 <= 100) {
    return { allowed: true, reason: '無資格でも設計可(建築士法3条の3)' };
  }

  return { allowed: false, reason: '適切な建築士資格が必要' };
}

// =============================================================================
// 6. 確認申請フロー
// =============================================================================

export type PermitStage = '事前協議' | '確認申請' | '中間検査' | '完了検査' | '検査済証交付';

export interface PermitFlow {
  stages: PermitStage[];
  estimatedDays: number;
  requiredDocs: string[];
  submitTo: '特定行政庁' | '指定確認検査機関';
}

export function buildPermitFlow(opts: { type: StructureType; stories: number; floorAreaM2: number; specialUse: boolean }): PermitFlow {
  const { stories, floorAreaM2, specialUse } = opts;
  const needsIntermediate = stories >= 3 || floorAreaM2 > 500 || specialUse;
  const stages: PermitStage[] = ['事前協議', '確認申請'];
  if (needsIntermediate) stages.push('中間検査');
  stages.push('完了検査', '検査済証交付');

  const docs = [
    '確認申請書(第1〜6面)',
    '付近見取図', '配置図', '各階平面図', '立面図(4面)', '断面図(2面以上)',
    '面積表(建築面積/延床面積/用途別)',
    '仕様書', '構造図(軸組図/基礎伏図/床伏図/小屋伏図)',
    '構造計算書', '設備図(給排水衛生/電気/空調/換気)',
    '省エネ計算書(外皮/一次エネ)',
    '敷地求積図', 'シックハウス対策資料(24時間換気 + F☆☆☆☆)',
  ];
  if (specialUse) docs.push('特殊建築物定期報告書', '防災計画書');

  return {
    stages,
    estimatedDays: floorAreaM2 > 500 ? 35 : 14,
    requiredDocs: docs,
    submitTo: floorAreaM2 > 10000 ? '特定行政庁' : '指定確認検査機関',
  };
}

// =============================================================================
// 7. 省エネ基準 (建築物省エネ法 — 2025年4月 全建築物義務化)
// =============================================================================

export interface EnergyPerformance {
  /** 外皮平均熱貫流率 W/(㎡·K) */
  ua: number;
  /** 冷房期の平均日射熱取得率 */
  etaAC: number;
  /** 一次エネルギー消費量基準値に対する比率 (BEI, 1.0以下が基準適合) */
  bei: number;
}

/** 地域区分 1〜8 (北から南) と UA 基準値 */
export const ENERGY_REGIONS: Readonly<{ region: number; representative_city: string; ua_threshold: number; etaAC_threshold: number }[]> = Object.freeze([
  { region: 1, representative_city: '旭川', ua_threshold: 0.46, etaAC_threshold: Infinity },
  { region: 2, representative_city: '札幌', ua_threshold: 0.46, etaAC_threshold: Infinity },
  { region: 3, representative_city: '盛岡', ua_threshold: 0.56, etaAC_threshold: Infinity },
  { region: 4, representative_city: '仙台', ua_threshold: 0.75, etaAC_threshold: Infinity },
  { region: 5, representative_city: '宇都宮', ua_threshold: 0.87, etaAC_threshold: 3.0 },
  { region: 6, representative_city: '東京', ua_threshold: 0.87, etaAC_threshold: 2.8 },
  { region: 7, representative_city: '鹿児島', ua_threshold: 0.87, etaAC_threshold: 2.7 },
  { region: 8, representative_city: '那覇', ua_threshold: Infinity, etaAC_threshold: 6.7 },
]);

export function checkEnergyCompliance(perf: EnergyPerformance, region: number): { ua_ok: boolean; etaAC_ok: boolean; bei_ok: boolean; overall: boolean } {
  const r = ENERGY_REGIONS.find(x => x.region === region);
  if (!r) throw new Error(`地域区分 ${region} は 1〜8 でなければならない`);
  const ua_ok = perf.ua <= r.ua_threshold;
  const etaAC_ok = perf.etaAC <= r.etaAC_threshold;
  const bei_ok = perf.bei <= 1.0;
  return { ua_ok, etaAC_ok, bei_ok, overall: ua_ok && etaAC_ok && bei_ok };
}

// =============================================================================
// 8. JIS 主要規格 (設計・施工・材料)
// =============================================================================

export const JIS_STANDARDS: Readonly<Record<string, { code: string; title: string; category: string }>> = Object.freeze({
  A5308: { code: 'JIS A 5308', title: 'レディーミクストコンクリート', category: 'concrete' },
  G3101: { code: 'JIS G 3101', title: '一般構造用圧延鋼材(SS材)', category: 'steel' },
  G3106: { code: 'JIS G 3106', title: '溶接構造用圧延鋼材(SM材)', category: 'steel' },
  G3136: { code: 'JIS G 3136', title: '建築構造用圧延鋼材(SN材)', category: 'steel' },
  Z3211: { code: 'JIS Z 3211', title: '軟鋼用被覆アーク溶接棒', category: 'weld' },
  A1107: { code: 'JIS A 1107', title: 'コンクリートからのコアの採取方法及び圧縮強度試験方法', category: 'test' },
  A5430: { code: 'JIS A 5430', title: '繊維強化セメント板', category: 'finish' },
  A6909: { code: 'JIS A 6909', title: '建築用仕上塗材', category: 'finish' },
  A4706: { code: 'JIS A 4706', title: 'サッシ', category: 'opening' },
  A6519: { code: 'JIS A 6519', title: '建築用鋼製床下地材', category: 'structure' },
  F7001: { code: 'JAS 合板', title: '構造用合板', category: 'wood' },
});

// =============================================================================
// 9. 総合ヘルパー: 敷地概要から「建てられる建物の上限」を推論
// =============================================================================

export interface SiteAnalysis {
  district: UseDistrictCode;
  siteAreaM2: number;
  frontRoadWidthM: number;
  fireZone: FireZone;
  zonedCoverage: number;
  zonedFar: number;
  corner?: boolean;
}

export interface BuildableEnvelope {
  maxBuildingArea: number;
  maxFloorArea: number;
  estimatedMaxStories: number;
  restrictions: string[];
  recommendedStructure: StructureType;
  cautions: string[];
}

export function analyzeSiteBuildable(site: SiteAnalysis): BuildableEnvelope {
  const effectiveFar = calcFloorAreaRatioByRoad(site.frontRoadWidthM, site.district, site.zonedFar);
  const effectiveCoverage = calcBuildingCoverageWithRelief(site.zonedCoverage, { corner: site.corner, fireZone: site.fireZone, fireResistant: site.fireZone === 'fire' });
  const maxBuildingArea = site.siteAreaM2 * effectiveCoverage / 100;
  const maxFloorArea = site.siteAreaM2 * effectiveFar / 100;
  const estimatedMaxStories = Math.max(1, Math.floor(maxFloorArea / maxBuildingArea));
  const restrictions: string[] = [
    `建ぺい率 ${effectiveCoverage}% → 建築面積上限 ${Math.floor(maxBuildingArea * 100) / 100}㎡`,
    `容積率 ${effectiveFar}% → 延床上限 ${Math.floor(maxFloorArea * 100) / 100}㎡`,
  ];
  if (site.frontRoadWidthM < 4) restrictions.push('⚠ 前面道路4m未満。42条2項道路(セットバック)の可能性あり');
  const d = USE_DISTRICTS[site.district];
  if (d.absoluteHeightLimit) restrictions.push(`絶対高さ制限 ${d.absoluteHeightLimit}m`);
  if (d.northernSlopeRestriction) restrictions.push('北側斜線制限あり');
  if (d.shadowRegulationApplicable) restrictions.push('日影規制の地区指定あり(自治体確認)');
  const cautions: string[] = [
    '確認申請前に特定行政庁の事前協議を強く推奨',
    '地盤調査(SWS/ボーリング)は必須',
    '既存道路後退 + 越境物確認',
  ];
  const recommendedStructure: StructureType =
    estimatedMaxStories <= 2 && maxFloorArea <= 300 ? 'wood' :
    estimatedMaxStories <= 4 ? 'steel' : 'rc';
  return { maxBuildingArea, maxFloorArea, estimatedMaxStories, restrictions, recommendedStructure, cautions };
}
