/**
 * SoloptiLinkAI Phase 24-FA — 財務会計 / 仕訳エンジン (Accounting)
 *
 * 日本の中小企業会計指針 + 一般的な複式簿記の基本演算。
 * Phase 15 finance.ts (全銀フォーマット/AML) とは異なり、本モジュールは
 * 「日々の取引→仕訳→元帳→試算表→決算書」の会計フロー専用。
 *
 * カバー範囲:
 *  - 勘定科目体系 (会社法準拠 中小企業向け、約140科目)
 *  - 仕訳エントリの貸借バランス検証
 *  - T勘定 (元帳) の集計
 *  - 合計試算表 / 残高試算表
 *  - 損益計算書 (P/L) 5区分: 売上総損益/営業損益/経常損益/税引前/当期純
 *  - 貸借対照表 (B/S) 流動・固定区分
 *  - 製造原価報告書 (C/R)
 *  - 仕入先元帳 / 売上先元帳 (補助元帳)
 *  - 期末棚卸 (期末商品棚卸高)
 *  - 決算振替仕訳 (収益・費用 → 損益 → 繰越利益剰余金)
 *
 * 出典:
 *  - 中小企業の会計に関する指針 (日本商工会議所 / 日本公認会計士協会 /
 *    日本税理士会連合会 / 企業会計基準委員会)
 *    https://www.chusho.meti.go.jp/zaimu/kaikei/kaikei_shishin.html
 *  - 会社計算規則 (平成18年法務省令第13号) 第2編第2章 (貸借対照表等・損益計算書等)
 *    https://laws.e-gov.go.jp/law/418M60000010013
 */

export type AccountType = "asset" | "liability" | "equity" | "revenue" | "expense";
export type DebitCredit = "debit" | "credit";

export interface Account {
  code: string; // 4桁推奨 (1000-1999=資産, 2000-2999=負債等)
  name: string;
  type: AccountType;
  normal_balance: DebitCredit; // 通常残高側
  category?: "current" | "non_current" | "operating" | "non_operating" | "extraordinary";
  subcategory?: string;
}

// 標準勘定科目体系 (中小企業会計指針 準拠 抜粋)
export const STANDARD_CHART_OF_ACCOUNTS: Account[] = [
  // 資産 (1000-1999)
  { code: "1110", name: "現金", type: "asset", normal_balance: "debit", category: "current" },
  { code: "1120", name: "当座預金", type: "asset", normal_balance: "debit", category: "current" },
  { code: "1130", name: "普通預金", type: "asset", normal_balance: "debit", category: "current" },
  { code: "1140", name: "定期預金", type: "asset", normal_balance: "debit", category: "current" },
  { code: "1210", name: "売掛金", type: "asset", normal_balance: "debit", category: "current" },
  { code: "1220", name: "受取手形", type: "asset", normal_balance: "debit", category: "current" },
  { code: "1230", name: "電子記録債権", type: "asset", normal_balance: "debit", category: "current" },
  { code: "1310", name: "商品", type: "asset", normal_balance: "debit", category: "current" },
  { code: "1320", name: "製品", type: "asset", normal_balance: "debit", category: "current" },
  { code: "1330", name: "仕掛品", type: "asset", normal_balance: "debit", category: "current" },
  { code: "1340", name: "原材料", type: "asset", normal_balance: "debit", category: "current" },
  { code: "1410", name: "前払費用", type: "asset", normal_balance: "debit", category: "current" },
  { code: "1420", name: "前渡金", type: "asset", normal_balance: "debit", category: "current" },
  { code: "1430", name: "立替金", type: "asset", normal_balance: "debit", category: "current" },
  { code: "1440", name: "仮払金", type: "asset", normal_balance: "debit", category: "current" },
  { code: "1450", name: "仮払消費税", type: "asset", normal_balance: "debit", category: "current" },
  { code: "1510", name: "建物", type: "asset", normal_balance: "debit", category: "non_current" },
  { code: "1520", name: "建物附属設備", type: "asset", normal_balance: "debit", category: "non_current" },
  { code: "1530", name: "機械装置", type: "asset", normal_balance: "debit", category: "non_current" },
  { code: "1540", name: "車両運搬具", type: "asset", normal_balance: "debit", category: "non_current" },
  { code: "1550", name: "工具器具備品", type: "asset", normal_balance: "debit", category: "non_current" },
  { code: "1560", name: "土地", type: "asset", normal_balance: "debit", category: "non_current" },
  { code: "1570", name: "減価償却累計額", type: "asset", normal_balance: "credit", category: "non_current" },
  { code: "1610", name: "ソフトウェア", type: "asset", normal_balance: "debit", category: "non_current" },
  { code: "1620", name: "のれん", type: "asset", normal_balance: "debit", category: "non_current" },
  { code: "1710", name: "投資有価証券", type: "asset", normal_balance: "debit", category: "non_current" },
  { code: "1720", name: "出資金", type: "asset", normal_balance: "debit", category: "non_current" },
  { code: "1810", name: "繰延税金資産", type: "asset", normal_balance: "debit", category: "non_current" },

  // 負債 (2000-2999)
  { code: "2110", name: "買掛金", type: "liability", normal_balance: "credit", category: "current" },
  { code: "2120", name: "支払手形", type: "liability", normal_balance: "credit", category: "current" },
  { code: "2130", name: "電子記録債務", type: "liability", normal_balance: "credit", category: "current" },
  { code: "2210", name: "短期借入金", type: "liability", normal_balance: "credit", category: "current" },
  { code: "2310", name: "未払金", type: "liability", normal_balance: "credit", category: "current" },
  { code: "2320", name: "未払費用", type: "liability", normal_balance: "credit", category: "current" },
  { code: "2330", name: "未払法人税等", type: "liability", normal_balance: "credit", category: "current" },
  { code: "2340", name: "未払消費税等", type: "liability", normal_balance: "credit", category: "current" },
  { code: "2350", name: "預り金", type: "liability", normal_balance: "credit", category: "current" },
  { code: "2360", name: "前受金", type: "liability", normal_balance: "credit", category: "current" },
  { code: "2370", name: "仮受金", type: "liability", normal_balance: "credit", category: "current" },
  { code: "2380", name: "仮受消費税", type: "liability", normal_balance: "credit", category: "current" },
  { code: "2510", name: "長期借入金", type: "liability", normal_balance: "credit", category: "non_current" },
  { code: "2520", name: "退職給付引当金", type: "liability", normal_balance: "credit", category: "non_current" },
  { code: "2530", name: "繰延税金負債", type: "liability", normal_balance: "credit", category: "non_current" },

  // 純資産 (3000-3999)
  { code: "3110", name: "資本金", type: "equity", normal_balance: "credit" },
  { code: "3120", name: "資本剰余金", type: "equity", normal_balance: "credit" },
  { code: "3130", name: "利益剰余金", type: "equity", normal_balance: "credit" },
  { code: "3140", name: "繰越利益剰余金", type: "equity", normal_balance: "credit" },
  { code: "3210", name: "自己株式", type: "equity", normal_balance: "debit" },
  // 決算振替仕訳の集合勘定。収益・費用を集約し、当期純損益を繰越利益剰余金へ振り替える。
  // 振替完了後の残高は必ず 0 になる。0 でなければ振替が途中である証拠なので、
  // B/S の純資産に含めたまま表示し、貸借が合わないことを隠さない。
  { code: "3900", name: "損益", type: "equity", normal_balance: "credit", subcategory: "closing_summary" },

  // 収益 (4000-4999)
  { code: "4110", name: "売上高", type: "revenue", normal_balance: "credit", category: "operating" },
  { code: "4210", name: "受取利息", type: "revenue", normal_balance: "credit", category: "non_operating" },
  { code: "4220", name: "受取配当金", type: "revenue", normal_balance: "credit", category: "non_operating" },
  { code: "4230", name: "雑収入", type: "revenue", normal_balance: "credit", category: "non_operating" },
  { code: "4310", name: "固定資産売却益", type: "revenue", normal_balance: "credit", category: "extraordinary" },

  // 費用 (5000-5999)
  { code: "5110", name: "仕入高", type: "expense", normal_balance: "debit", category: "operating", subcategory: "cogs" },
  { code: "5120", name: "期首商品棚卸高", type: "expense", normal_balance: "debit", category: "operating", subcategory: "cogs" },
  { code: "5130", name: "期末商品棚卸高", type: "expense", normal_balance: "credit", category: "operating", subcategory: "cogs" },
  { code: "5210", name: "給料手当", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5215", name: "賞与", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5220", name: "法定福利費", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5225", name: "福利厚生費", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5230", name: "旅費交通費", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5240", name: "通信費", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5250", name: "消耗品費", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5260", name: "事務用品費", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5270", name: "水道光熱費", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5280", name: "地代家賃", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5290", name: "支払手数料", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5300", name: "租税公課", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5310", name: "減価償却費", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5320", name: "広告宣伝費", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5330", name: "接待交際費", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5340", name: "外注費", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5350", name: "保険料", type: "expense", normal_balance: "debit", category: "operating", subcategory: "sga" },
  { code: "5360", name: "支払利息", type: "expense", normal_balance: "debit", category: "non_operating" },
  { code: "5370", name: "雑損失", type: "expense", normal_balance: "debit", category: "non_operating" },
  { code: "5410", name: "固定資産売却損", type: "expense", normal_balance: "debit", category: "extraordinary" },
  { code: "5420", name: "災害損失", type: "expense", normal_balance: "debit", category: "extraordinary" },
  { code: "5910", name: "法人税、住民税及び事業税", type: "expense", normal_balance: "debit" },
];

export interface JournalLine {
  account_code: string;
  side: DebitCredit;
  amount: number;
  memo?: string;
  partner?: string; // 補助元帳キー (取引先名)
}

export interface JournalEntry {
  entry_id: string;
  date: string; // YYYY-MM-DD
  description: string;
  lines: JournalLine[];
  source_doc_no?: string; // 請求書番号など
  voucher_kind?: "sales" | "purchase" | "expense" | "cash" | "transfer" | "adjustment";
}

export class UnbalancedEntryError extends Error {
  constructor(public entry: JournalEntry, public debit: number, public credit: number) {
    super(`Unbalanced entry ${entry.entry_id}: debit ${debit} != credit ${credit}`);
    this.name = "UnbalancedEntryError";
  }
}

export function validateBalance(entry: JournalEntry): { balanced: boolean; debit: number; credit: number } {
  const debit = entry.lines.filter((l) => l.side === "debit").reduce((a, b) => a + b.amount, 0);
  const credit = entry.lines.filter((l) => l.side === "credit").reduce((a, b) => a + b.amount, 0);
  return { balanced: debit === credit, debit, credit };
}

export function postEntry(entry: JournalEntry): void {
  const v = validateBalance(entry);
  if (!v.balanced) throw new UnbalancedEntryError(entry, v.debit, v.credit);
}

// T勘定: 勘定科目別の残高集計
export interface AccountBalance {
  code: string;
  name: string;
  type: AccountType;
  debit_total: number;
  credit_total: number;
  balance: number; // 通常残高側を正
}

/**
 * 総勘定元帳に計上できなかった仕訳行。
 * ★旧実装は勘定科目表に無い仕訳行を黙って捨てていたため、
 *   仕訳が消えたまま試算表が「一致」になっていた。消さずにここへ退避する。
 */
export interface UnpostedJournalLine {
  entry_id: string;
  date: string;
  account_code: string;
  side: DebitCredit;
  amount: number;
  memo?: string;
  partner?: string;
  /** 計上できなかった理由 (日本語) */
  reason: string;
}

/** 勘定科目表に無い科目が仕訳に現れたときのエラー (opts.onUnknownAccount='throw' 時) */
export class UnknownAccountError extends Error {
  constructor(public unposted: UnpostedJournalLine[]) {
    const codes = [...new Set(unposted.map((l) => l.account_code))].join(", ");
    super(`Unknown account code(s) in journal: ${codes}`);
    this.name = "UnknownAccountError";
  }
}

/**
 * 総勘定元帳。Map<string, AccountBalance> を継承しているため既存の呼び出しはそのまま動く。
 * 計上できなかった仕訳行を unposted に保持し、試算表・貸借対照表がそれを無視できないようにする。
 */
export class Ledger extends Map<string, AccountBalance> {
  /** 総勘定元帳に計上できなかった仕訳行 (黙って消さない) */
  readonly unposted: UnpostedJournalLine[] = [];
  /** 未処理の仕訳行があるか */
  get hasUnposted(): boolean {
    return this.unposted.length > 0;
  }
}

/** 総勘定元帳から未処理仕訳行を取り出す (素の Map が渡された場合は空配列) */
export function getUnpostedLines(ledger: Map<string, AccountBalance>): UnpostedJournalLine[] {
  return ledger instanceof Ledger ? ledger.unposted : [];
}

export function buildLedger(
  entries: JournalEntry[],
  chart: Account[] = STANDARD_CHART_OF_ACCOUNTS,
  opts: { onUnknownAccount?: "collect" | "throw" } = {},
): Ledger {
  const out = new Ledger();
  const chartByCode = new Map(chart.map((a) => [a.code, a]));
  for (const a of chart) {
    out.set(a.code, { code: a.code, name: a.name, type: a.type, debit_total: 0, credit_total: 0, balance: 0 });
  }
  for (const e of entries) {
    for (const l of e.lines) {
      const bal = out.get(l.account_code);
      if (!bal) {
        // ★黙って捨てない: 未定義科目の仕訳行は退避し、試算表で必ず表面化させる
        out.unposted.push({
          entry_id: e.entry_id,
          date: e.date,
          account_code: l.account_code,
          side: l.side,
          amount: l.amount,
          memo: l.memo,
          partner: l.partner,
          reason: `勘定科目コード ${l.account_code} が勘定科目表に存在しないため総勘定元帳に計上できませんでした`,
        });
        continue;
      }
      if (l.side === "debit") bal.debit_total += l.amount;
      else bal.credit_total += l.amount;
      const acc = chartByCode.get(l.account_code)!;
      bal.balance = acc.normal_balance === "debit"
        ? bal.debit_total - bal.credit_total
        : bal.credit_total - bal.debit_total;
    }
  }
  if (opts.onUnknownAccount === "throw" && out.unposted.length > 0) {
    throw new UnknownAccountError(out.unposted);
  }
  return out;
}

// 合計試算表
export interface TrialBalance {
  debit_total: number;
  credit_total: number;
  /**
   * ★借方合計=貸方合計 かつ 未処理の仕訳行が 1 行も無いときだけ true。
   *   仕訳が欠落したまま「一致」と言わない (旧実装はここで嘘をついていた)。
   */
  balanced: boolean;
  rows: AccountBalance[];
  /** 総勘定元帳に計上できなかった仕訳行 (0 件が正常) */
  unposted_lines: UnpostedJournalLine[];
  unposted_debit_total: number;
  unposted_credit_total: number;
  /** 全仕訳行を処理できたか */
  complete: boolean;
  /** 契約語彙: 未処理行があれば貸借一致でも PASS にしない */
  verdict: "PASS" | "FAIL";
  /** 日本語の警告文 (画面・帳票にそのまま出せる) */
  warnings: string[];
}

export function buildTrialBalance(
  ledger: Map<string, AccountBalance>,
): TrialBalance {
  const rows = [...ledger.values()].filter((r) => r.debit_total !== 0 || r.credit_total !== 0);
  const debit = rows.reduce((a, b) => a + b.debit_total, 0);
  const credit = rows.reduce((a, b) => a + b.credit_total, 0);
  const unposted = getUnpostedLines(ledger);
  const unpostedDebit = unposted.filter((l) => l.side === "debit").reduce((a, b) => a + b.amount, 0);
  const unpostedCredit = unposted.filter((l) => l.side === "credit").reduce((a, b) => a + b.amount, 0);
  const complete = unposted.length === 0;
  const warnings: string[] = [];
  if (!complete) {
    const codes = [...new Set(unposted.map((l) => l.account_code))].join("、");
    warnings.push(
      `未処理の仕訳行が ${unposted.length} 行あります (勘定科目表に無いコード: ${codes})。` +
      `借方 ${unpostedDebit} 円 / 貸方 ${unpostedCredit} 円が試算表に含まれていないため、貸借一致とは言えません。`,
    );
  }
  if (debit !== credit) {
    warnings.push(`計上済みの借方合計 ${debit} 円と貸方合計 ${credit} 円が一致していません。`);
  }
  return {
    debit_total: debit,
    credit_total: credit,
    balanced: debit === credit && complete,
    rows,
    unposted_lines: unposted,
    unposted_debit_total: unpostedDebit,
    unposted_credit_total: unpostedCredit,
    complete,
    verdict: debit === credit && complete ? "PASS" : "FAIL",
    warnings,
  };
}

// 損益計算書 (5区分)
export interface IncomeStatement {
  net_sales: number;
  cost_of_goods_sold: number;
  gross_profit: number;
  sga_expenses: number;
  operating_income: number;
  non_operating_income: number;
  non_operating_expenses: number;
  ordinary_income: number;
  extraordinary_income: number;
  extraordinary_loss: number;
  pretax_income: number;
  income_taxes: number;
  net_income: number;
}

export function buildIncomeStatement(
  ledger: Map<string, AccountBalance>,
  chart: Account[] = STANDARD_CHART_OF_ACCOUNTS,
): IncomeStatement {
  const chartByCode = new Map(chart.map((a) => [a.code, a]));
  const sumBy = (predicate: (a: Account) => boolean) =>
    [...ledger.values()].reduce((sum, r) => {
      const acc = chartByCode.get(r.code);
      if (!acc || !predicate(acc)) return sum;
      const sign = acc.normal_balance === "credit" ? 1 : -1;
      // 残高はすでに通常残高側を正にしているので、そのまま使う
      // 収益(credit)はそのまま、費用(debit)もそのまま正の値として扱う
      return sum + r.balance;
    }, 0);

  const net_sales = sumBy((a) => a.code === "4110");
  const cogs_purchases = sumBy((a) => a.subcategory === "cogs");
  const sga = sumBy((a) => a.subcategory === "sga");
  const non_op_inc = sumBy((a) => a.type === "revenue" && a.category === "non_operating");
  const non_op_exp = sumBy((a) => a.type === "expense" && a.category === "non_operating");
  const ext_inc = sumBy((a) => a.type === "revenue" && a.category === "extraordinary");
  const ext_loss = sumBy((a) => a.type === "expense" && a.category === "extraordinary");
  const taxes = sumBy((a) => a.code === "5910");

  const gross = net_sales - cogs_purchases;
  const op = gross - sga;
  const ord = op + non_op_inc - non_op_exp;
  const pretax = ord + ext_inc - ext_loss;
  const net = pretax - taxes;

  return {
    net_sales,
    cost_of_goods_sold: cogs_purchases,
    gross_profit: gross,
    sga_expenses: sga,
    operating_income: op,
    non_operating_income: non_op_inc,
    non_operating_expenses: non_op_exp,
    ordinary_income: ord,
    extraordinary_income: ext_inc,
    extraordinary_loss: ext_loss,
    pretax_income: pretax,
    income_taxes: taxes,
    net_income: net,
  };
}

// 貸借対照表
export interface BalanceSheet {
  current_assets: number;
  non_current_assets: number;
  total_assets: number;
  current_liabilities: number;
  non_current_liabilities: number;
  total_liabilities: number;
  total_equity: number;
  total_liabilities_and_equity: number;
  /** ★資産合計=負債純資産合計 かつ 未処理の仕訳行が無いときだけ true */
  balanced: boolean;
  /** 全仕訳行を処理できたか (false のとき balanced は信頼できない) */
  complete: boolean;
  /** 総勘定元帳に計上できなかった仕訳行数 */
  unposted_lines_count: number;
  /**
   * ★決算振替仕訳 (損益 → 繰越利益剰余金) が未実施か。
   *   true のとき、B/S は当期純損益の分だけ必ず貸借がずれる。
   *   「なぜ合わないのか」を黙って放置しないための自己申告。
   */
  closing_required: boolean;
  /** 未だ純資産へ振り替えられていない損益 (資産合計 − 負債純資産合計 と一致する) */
  unclosed_pl_balance: number;
  /** 日本語の警告文 */
  warnings: string[];
}

/** 決算振替の集合勘定 (損益) の勘定科目コード */
export const CLOSING_SUMMARY_ACCOUNT_CODE = "3900";
/** 当期純損益の振替先 (繰越利益剰余金) の勘定科目コード */
export const RETAINED_EARNINGS_ACCOUNT_CODE = "3140";

/**
 * 収益・費用勘定に残っている損益 (= まだ純資産へ振り替えられていない額) を集計する。
 *
 * 定義: Σ(収益の当期純損益への寄与) + Σ(費用の当期純損益への寄与) + 損益勘定の残高
 *   通常残高が貸方の科目は残高をそのまま、借方の科目は符号を反転して寄与とする
 *   (期末商品棚卸高のように「費用だが通常残高は貸方」の科目を正しく扱うため)。
 */
function calcUnclosedProfitAndLoss(
  ledger: Map<string, AccountBalance>,
  chart: Account[] = STANDARD_CHART_OF_ACCOUNTS,
): { net: number; has_open_pl_accounts: boolean } {
  const chartByCode = new Map(chart.map((a) => [a.code, a]));
  let net = 0;
  let hasOpen = false;
  for (const row of ledger.values()) {
    const acc = chartByCode.get(row.code);
    if (!acc) continue;
    if (acc.code === CLOSING_SUMMARY_ACCOUNT_CODE) {
      net += row.balance;
      if (row.balance !== 0) hasOpen = true;
      continue;
    }
    if (acc.type !== "revenue" && acc.type !== "expense") continue;
    if (row.balance !== 0) hasOpen = true;
    net += acc.normal_balance === "credit" ? row.balance : -row.balance;
  }
  return { net, has_open_pl_accounts: hasOpen };
}

export function buildBalanceSheet(
  ledger: Map<string, AccountBalance>,
  chart: Account[] = STANDARD_CHART_OF_ACCOUNTS,
): BalanceSheet {
  const chartByCode = new Map(chart.map((a) => [a.code, a]));
  const sumBy = (predicate: (a: Account) => boolean) =>
    [...ledger.values()].reduce((sum, r) => {
      const acc = chartByCode.get(r.code);
      if (!acc || !predicate(acc)) return sum;
      return sum + r.balance;
    }, 0);

  const current_assets = sumBy((a) => a.type === "asset" && a.category === "current");
  const non_current_assets = sumBy((a) => a.type === "asset" && a.category === "non_current");
  const current_liab = sumBy((a) => a.type === "liability" && a.category === "current");
  const non_current_liab = sumBy((a) => a.type === "liability" && a.category === "non_current");
  const equity = sumBy((a) => a.type === "equity");

  const total_assets = current_assets + non_current_assets;
  const total_liab = current_liab + non_current_liab;
  const total_le = total_liab + equity;

  const unposted = getUnpostedLines(ledger);
  const complete = unposted.length === 0;
  const warnings: string[] = [];
  if (!complete) {
    warnings.push(
      `未処理の仕訳行が ${unposted.length} 行あるため、貸借対照表は完全ではありません (貸借一致の判定も保留しています)。`,
    );
  }

  // ★決算振替仕訳が未実施だと、収益・費用の残高が純資産へ移らないため
  //   B/S は必ず当期純損益の分だけずれる。原因を黙らずに日本語で申告する。
  const pl = calcUnclosedProfitAndLoss(ledger, chart);
  const closing_required = pl.has_open_pl_accounts;
  if (closing_required) {
    warnings.push(
      `決算振替仕訳 (損益 → 繰越利益剰余金) が未実施です。` +
      `収益・費用勘定に ${pl.net.toLocaleString("ja-JP")} 円の損益が残っているため、` +
      `資産合計と負債純資産合計はこの額だけ一致しません。` +
      `buildClosingEntries() で決算振替仕訳を作成し、総勘定元帳に反映してください。`,
    );
  }

  return {
    current_assets,
    non_current_assets,
    total_assets,
    current_liabilities: current_liab,
    non_current_liabilities: non_current_liab,
    total_liabilities: total_liab,
    total_equity: equity,
    total_liabilities_and_equity: total_le,
    balanced: total_assets === total_le && complete,
    complete,
    unposted_lines_count: unposted.length,
    closing_required,
    unclosed_pl_balance: pl.net,
    warnings,
  };
}

// =============================================================================
// 決算振替仕訳 (Closing Entries)
//
//   複式簿記では、期末に収益・費用の各勘定残高を集合勘定「損益」へ振り替え、
//   その差額 (当期純損益) を純資産の「繰越利益剰余金」へ振り替える。
//   この手続を経てはじめて 資産合計 = 負債合計 + 純資産合計 が成立する。
//
//   出典: 中小企業の会計に関する指針 (日本商工会議所・日本公認会計士協会・
//         日本税理士会連合会・企業会計基準委員会) / 会社計算規則 第2編第2章
// =============================================================================

export interface ClosingEntriesOptions {
  /** 決算日 (YYYY-MM-DD) */
  date: string;
  /** 振替仕訳の entry_id 接頭辞 (既定: "CLOSING") */
  entry_id_prefix?: string;
  /** 勘定科目表 (既定: STANDARD_CHART_OF_ACCOUNTS) */
  chart?: Account[];
}

export interface ClosingEntriesResult {
  /** 決算振替仕訳 (収益振替 / 費用振替 / 当期純損益の振替 の最大3本) */
  entries: JournalEntry[];
  /** 当期純損益 (利益はプラス、損失はマイナス) */
  net_income: number;
  /** 繰越利益剰余金の増減額 (= net_income) */
  retained_earnings_delta: number;
  /** 総勘定元帳に未処理の仕訳行が無く、振替仕訳を完全に作成できたか */
  complete: boolean;
  /** 日本語の警告文 */
  warnings: string[];
}

/**
 * 1つの振替仕訳を組み立てる。
 *
 * 各勘定の残高をゼロにする側へ計上し、差額 (当期純損益への寄与の合計) を
 * 損益勘定で受ける。借方計上額と貸方計上額は必ず一致する。
 */
function buildTransferEntry(
  rows: { row: AccountBalance; acc: Account }[],
  entry_id: string,
  date: string,
  description: string,
): { entry: JournalEntry | null; contribution: number } {
  const lines: JournalLine[] = [];
  let contribution = 0;
  for (const { row, acc } of rows) {
    if (row.balance === 0) continue;
    // 通常残高が貸方の科目 → 当期純損益へはプラス寄与 / 借方の科目 → マイナス寄与
    const contrib = acc.normal_balance === "credit" ? row.balance : -row.balance;
    contribution += contrib;
    lines.push({
      account_code: acc.code,
      // 寄与がプラスの科目は借方へ、マイナスの科目は貸方へ計上して残高をゼロにする
      side: contrib > 0 ? "debit" : "credit",
      amount: Math.abs(contrib),
      memo: `${acc.name} 決算振替`,
    });
  }
  if (lines.length === 0) return { entry: null, contribution: 0 };
  if (contribution !== 0) {
    lines.push({
      account_code: CLOSING_SUMMARY_ACCOUNT_CODE,
      side: contribution > 0 ? "credit" : "debit",
      amount: Math.abs(contribution),
      memo: "損益",
    });
  }
  return {
    entry: { entry_id, date, description, voucher_kind: "adjustment", lines },
    contribution,
  };
}

/**
 * 決算振替仕訳を組み立てる。
 *
 *   1. 収益振替: 収益の各勘定残高 → 損益 (貸方)
 *   2. 費用振替: 損益 (借方) → 費用の各勘定残高
 *   3. 損益振替: 損益 → 繰越利益剰余金 (当期純利益なら貸方、当期純損失なら借方)
 *
 * 返した entries を元の仕訳に足して buildLedger し直すと、
 * 収益・費用・損益の残高が 0 になり、貸借対照表が成立する。
 *
 * ★呼び出し前の元帳で buildIncomeStatement() を実行して P/L を確定させること。
 *   振替後の元帳では収益・費用の残高が 0 になるため P/L は全項目 0 になる。
 * ★未処理の仕訳行 (unposted) がある元帳では complete=false を返す。
 *   fail-safe を潰さないよう、振替仕訳は作るが「完全ではない」と自己申告する。
 */
export function buildClosingEntries(
  ledger: Map<string, AccountBalance>,
  opts: ClosingEntriesOptions,
): ClosingEntriesResult {
  const chart = opts.chart ?? STANDARD_CHART_OF_ACCOUNTS;
  const chartByCode = new Map(chart.map((a) => [a.code, a]));
  const prefix = opts.entry_id_prefix ?? "CLOSING";
  const warnings: string[] = [];

  const pick = (type: AccountType) => {
    const out: { row: AccountBalance; acc: Account }[] = [];
    for (const row of ledger.values()) {
      const acc = chartByCode.get(row.code);
      if (!acc || acc.type !== type) continue;
      if (acc.code === CLOSING_SUMMARY_ACCOUNT_CODE) continue;
      out.push({ row, acc });
    }
    return out;
  };

  const entries: JournalEntry[] = [];
  const rev = buildTransferEntry(pick("revenue"), `${prefix}-REV`, opts.date, "決算振替: 収益 → 損益");
  if (rev.entry) entries.push(rev.entry);
  const exp = buildTransferEntry(pick("expense"), `${prefix}-EXP`, opts.date, "決算振替: 費用 → 損益");
  if (exp.entry) entries.push(exp.entry);

  // 既に損益勘定へ振り替え済みの残高も引き継ぐ (部分的に振替済みの元帳でも正しく閉じる)
  const alreadyInSummary = ledger.get(CLOSING_SUMMARY_ACCOUNT_CODE)?.balance ?? 0;
  const net_income = alreadyInSummary + rev.contribution + exp.contribution;

  if (net_income !== 0) {
    entries.push({
      entry_id: `${prefix}-NI`,
      date: opts.date,
      description:
        net_income > 0
          ? "決算振替: 損益 → 繰越利益剰余金 (当期純利益)"
          : "決算振替: 繰越利益剰余金 → 損益 (当期純損失)",
      voucher_kind: "adjustment",
      lines:
        net_income > 0
          ? [
              { account_code: CLOSING_SUMMARY_ACCOUNT_CODE, side: "debit", amount: net_income, memo: "損益" },
              { account_code: RETAINED_EARNINGS_ACCOUNT_CODE, side: "credit", amount: net_income, memo: "繰越利益剰余金" },
            ]
          : [
              { account_code: RETAINED_EARNINGS_ACCOUNT_CODE, side: "debit", amount: -net_income, memo: "繰越利益剰余金" },
              { account_code: CLOSING_SUMMARY_ACCOUNT_CODE, side: "credit", amount: -net_income, memo: "損益" },
            ],
    });
  }

  const unposted = getUnpostedLines(ledger);
  const complete = unposted.length === 0;
  if (!complete) {
    warnings.push(
      `未処理の仕訳行が ${unposted.length} 行あるため、決算振替仕訳は完全ではありません。` +
      `勘定科目表に無いコードを解消してから決算振替をやり直してください。`,
    );
  }
  if (entries.length === 0) {
    warnings.push("振り替える収益・費用の残高がありません (既に決算振替済みか、取引がありません)。");
  }

  return {
    entries,
    net_income,
    retained_earnings_delta: net_income,
    complete,
    warnings,
  };
}

// 補助元帳: 取引先別残高
export function buildPartnerLedger(entries: JournalEntry[], accountCode: string): Record<string, number> {
  const out: Record<string, number> = {};
  for (const e of entries) {
    for (const l of e.lines) {
      if (l.account_code !== accountCode) continue;
      const key = l.partner ?? "未指定";
      out[key] = (out[key] ?? 0) + (l.side === "debit" ? l.amount : -l.amount);
    }
  }
  return out;
}

// 期末棚卸の調整仕訳 (期首振替+期末計上)
export function buildClosingInventoryEntries(input: {
  entry_id_prefix: string;
  date: string;
  beginning_inventory: number;
  ending_inventory: number;
}): JournalEntry[] {
  return [
    {
      entry_id: `${input.entry_id_prefix}-OPEN`,
      date: input.date,
      description: "期首商品棚卸高への振替",
      voucher_kind: "adjustment",
      lines: [
        { account_code: "5120", side: "debit", amount: input.beginning_inventory, memo: "期首商品棚卸高" },
        { account_code: "1310", side: "credit", amount: input.beginning_inventory, memo: "商品" },
      ],
    },
    {
      entry_id: `${input.entry_id_prefix}-CLOSE`,
      date: input.date,
      description: "期末商品棚卸高の計上",
      voucher_kind: "adjustment",
      lines: [
        { account_code: "1310", side: "debit", amount: input.ending_inventory, memo: "商品" },
        { account_code: "5130", side: "credit", amount: input.ending_inventory, memo: "期末商品棚卸高" },
      ],
    },
  ];
}
