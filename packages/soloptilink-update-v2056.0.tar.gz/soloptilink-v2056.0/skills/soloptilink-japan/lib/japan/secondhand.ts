/**
 * lib/japan/secondhand.ts — 古物商/質屋DNA
 *
 * 法令カバレッジ:
 *  - 古物営業法 (S24法律108)
 *  - 古物営業法施行規則 (古物台帳/HP届出/非対面取引時の本人確認)
 *  - 質屋営業法 (S25法律158)
 *  - 質屋営業法施行規則
 *  - 犯罪収益移転防止法 (古物商も対象 — 200万円超現金取引時)
 *  - 国家公安委員会規則 (古物の品目13区分)
 *  - 古物市場主許可
 *
 * 参考: 警察庁生活安全局, 全日本古物商連合会, 全国質屋組合連合会
 */

// ============================================================================
// 1. 古物 13区分 (古物営業法施行規則2条)
// ============================================================================

export const KOBUTSU_CATEGORIES = [
  { code: '01', ja: '美術品類', examples: ['書画', '彫刻', '骨董'] },
  { code: '02', ja: '衣類', examples: ['古着', '織物', 'ビンテージ'] },
  { code: '03', ja: '時計・宝飾品類', examples: ['ロレックス', 'ダイヤ', '指輪'] },
  { code: '04', ja: '自動車', examples: ['中古車'] },
  { code: '05', ja: '自動二輪車及び原動機付自転車', examples: ['バイク', '原付'] },
  { code: '06', ja: '自転車類', examples: ['中古自転車'] },
  { code: '07', ja: '写真機類', examples: ['カメラ', 'レンズ'] },
  { code: '08', ja: '事務機器類', examples: ['PC', 'コピー機', 'プリンタ'] },
  { code: '09', ja: '機械工具類', examples: ['電動工具', '農機具'] },
  { code: '10', ja: '道具類', examples: ['家具', '楽器', 'スポーツ用品', 'CD/DVD'] },
  { code: '11', ja: '皮革・ゴム製品類', examples: ['ブランドバッグ', '靴'] },
  { code: '12', ja: '書籍', examples: ['古本', '中古教科書'] },
  { code: '13', ja: '金券類', examples: ['商品券', 'チケット', '株主優待券'] },
] as const;

export type KobutsuCategory = typeof KOBUTSU_CATEGORIES[number]['code'];

// ============================================================================
// 2. 古物商許可 (古物営業法3条)
// ============================================================================

export interface KobutsuPermitApplication {
  applicantKind: 'individual' | 'corporation';
  hasResponsibleManager: boolean; // 営業所管理者 (古物営業法13条)
  managerHasNoCriminalRecord5y: boolean; // 5年以内に古物営業法違反/刑法違反等なし
  isAdult: boolean;
  hasFixedBusinessLocation: boolean;
  primaryCategories: KobutsuCategory[]; // 主として扱う品目
  hasPlateAtSite: boolean; // 標識掲示
  hasURL?: string; // ネット上で取引する場合は届出
  hasNonFaceToFaceVerificationProcess: boolean; // 非対面本人確認手順
}

/** 古物商許可 事前審査 */
export function evaluateKobutsuPermit(a: KobutsuPermitApplication): {
  approvable: boolean;
  blockers: string[];
} {
  const blockers: string[] = [];
  if (!a.isAdult) blockers.push('成年被後見人/被保佐人 — 欠格事由 (4条1号)');
  if (!a.managerHasNoCriminalRecord5y) {
    blockers.push('5年以内に禁錮以上 or 古物営業法違反 — 欠格 (4条2-3号)');
  }
  if (!a.hasResponsibleManager) blockers.push('営業所管理者必須 (法13条)');
  if (!a.hasFixedBusinessLocation) blockers.push('営業所所在地 (固定) 必須');
  if (a.primaryCategories.length === 0) blockers.push('主として扱う品目を1つ以上指定');
  if (a.hasURL && !a.hasNonFaceToFaceVerificationProcess) {
    blockers.push('HP取引 — 非対面本人確認手順 必須 (規則15条 H30改正)');
  }
  if (!a.hasPlateAtSite) blockers.push('営業所に標識掲示必須 (法12条)');
  return { approvable: blockers.length === 0, blockers };
}

// ============================================================================
// 3. 古物台帳 (法16条) — 取引記録義務
// ============================================================================

export interface KobutsuTransactionEntry {
  transactionDate: Date;
  transactionType: 'buy' | 'sell' | 'swap' | 'consignment'; // 買受/売却/交換/委託
  itemDescription: string;
  itemCategory: KobutsuCategory;
  itemPriceJpy: number;
  serialOrFeature: string; // 製造番号 or 特徴
  // 相手方情報
  counterpartyName: string;
  counterpartyAddress: string;
  counterpartyAge?: number;
  counterpartyOccupation?: string;
  identityVerifiedBy: 'driver_license' | 'passport' | 'mynumber_card' | 'health_insurance' | 'foreign_id';
}

/** 取引記録義務の判定 (法16条) — 1万円未満の一部例外あり */
export function requiresLedgerEntry(input: {
  transactionType: KobutsuTransactionEntry['transactionType'];
  itemPriceJpy: number;
  itemCategory: KobutsuCategory;
}): { required: boolean; reason: string } {
  // 1万円未満の小額取引は一部品目で記録省略可 (規則16条)
  // ただし以下品目は金額に関わらず記録必須:
  //   01 美術品類 / 03 時計宝飾品類 / 04 自動車 / 05 二輪車 / 09 機械工具類 / 13 金券類
  const mandatoryCategories: KobutsuCategory[] = ['01', '03', '04', '05', '09', '13'];
  if (mandatoryCategories.includes(input.itemCategory)) {
    return { required: true, reason: `品目 ${input.itemCategory} — 金額に関わらず記録必須 (規則16条)` };
  }
  if (input.itemPriceJpy >= 10_000) {
    return { required: true, reason: '1万円以上 — 記録必須' };
  }
  return { required: false, reason: '1万円未満 + 例外品目 — 記録省略可 (但し推奨)' };
}

/** 古物台帳 保存期間: 最終記入日から3年 (規則18条) */
export const KOBUTSU_LEDGER_RETENTION_YEARS = 3;

// ============================================================================
// 4. 犯罪収益移転防止法 — 古物商も対象 (200万円超現金取引時)
// ============================================================================

/** 200万円超の現金取引で本人確認+取引記録+疑わしい取引届出 (犯収法4条/8条) */
export function requiresAmlVerification(input: {
  transactionPriceJpy: number;
  isCashTransaction: boolean;
  itemCategory: KobutsuCategory;
}): { required: boolean; reason: string } {
  if (input.transactionPriceJpy > 2_000_000 && input.isCashTransaction) {
    return {
      required: true,
      reason: '犯収法4条 — 200万円超現金取引で本人確認+取引記録 7年保存',
    };
  }
  // 貴金属 (金/プラチナ) は更に厳格 — 200万円超で本人確認 (犯収法施行令)
  if (input.itemCategory === '03' && input.transactionPriceJpy > 2_000_000) {
    return {
      required: true,
      reason: '時計宝飾品類 200万円超 — 犯収法本人確認',
    };
  }
  return { required: false, reason: '閾値以下' };
}

// ============================================================================
// 5. 質屋営業法 (S25法律158)
// ============================================================================

export interface ShichiyaPermitApplication {
  hasPermit: boolean; // 都道府県公安委員会許可 (法2条)
  hasFireResistantStorage: boolean; // 質物保管施設 (耐火構造)
  storageM2: number;
  hasResponsibleManager: boolean;
  managerHasNoCriminalRecord5y: boolean;
}

/** 質屋営業 許可審査 */
export function evaluateShichiyaPermit(a: ShichiyaPermitApplication): {
  approvable: boolean;
  blockers: string[];
} {
  const blockers: string[] = [];
  if (!a.hasFireResistantStorage) blockers.push('耐火構造の質物保管庫必須 (規則4条)');
  if (a.storageM2 < 5) blockers.push('保管庫 5m²以上が目安');
  if (!a.hasResponsibleManager) blockers.push('営業所管理者必須');
  if (!a.managerHasNoCriminalRecord5y) blockers.push('管理者の欠格事由なきこと');
  return { approvable: blockers.length === 0, blockers };
}

// ============================================================================
// 6. 質屋利息制限 (質屋営業法 36条 + 利息制限法 連動)
// ============================================================================

/** 質屋営業法36条 — 上限利率 月8% (年109.5%) — 利息制限法より緩和 */
export function calcMaxShichiyaInterest(input: {
  principalJpy: number;
  loanPeriodDays: number;
}): { maxInterestJpy: number; maxRatePerMonthPct: number; reason: string } {
  // 質屋営業法36条: 月8%以内
  const monthlyRate = 0.08;
  const periodMonths = input.loanPeriodDays / 30;
  const maxInterest = input.principalJpy * monthlyRate * periodMonths;
  return {
    maxInterestJpy: Math.floor(maxInterest),
    maxRatePerMonthPct: 8.0,
    reason: '質屋営業法36条 月8% (年109.5%相当 — 利息制限法より緩和)',
  };
}

/** 質物の流質期限 — 弁済期日から3ヶ月 (法18条) */
export function calcShichiyaForfeitureDate(loanDate: Date, loanPeriodDays: number): {
  redemptionDeadline: Date;
  forfeitureDate: Date;
} {
  const redemptionDeadline = new Date(loanDate);
  redemptionDeadline.setDate(redemptionDeadline.getDate() + loanPeriodDays);
  const forfeitureDate = new Date(redemptionDeadline);
  forfeitureDate.setMonth(forfeitureDate.getMonth() + 3);
  return { redemptionDeadline, forfeitureDate };
}

// ============================================================================
// 7. 質物台帳 (法11条 — 古物台帳と類似)
// ============================================================================

/** 質物台帳 保存期間: 最終記入日から3年 */
export const SHICHIYA_LEDGER_RETENTION_YEARS = 3;

// ============================================================================
// 8. 古物市場主許可 (古物営業法2条2項3号)
// ============================================================================

/** 古物市場主 (古物商間の取引市場を主催) の許可要件 */
export function evaluateKobutsuMarketPermit(input: {
  hasMarketRules: boolean; // 市場規程
  hasMemberAuthenticationProcess: boolean; // 会員古物商の許可番号確認
  hasTransactionLogPersistence: boolean; // 落札記録の永続保存
}): { approvable: boolean; blockers: string[] } {
  const blockers: string[] = [];
  if (!input.hasMarketRules) blockers.push('市場規程の制定必須');
  if (!input.hasMemberAuthenticationProcess) {
    blockers.push('会員古物商の古物商許可番号確認手順必須');
  }
  if (!input.hasTransactionLogPersistence) {
    blockers.push('市場での落札記録の永続保存 (3年以上)');
  }
  return { approvable: blockers.length === 0, blockers };
}
