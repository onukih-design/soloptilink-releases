/**
 * @fileoverview Phase 13 - 法令ライブ追跡 DNA
 *
 * 「e-Gov 法令API」「官報」「政府規制改革推進会議」「省庁パブコメ」
 * を統合監視し、法令改正をリアルタイム検知 → 影響評価 → コード上の修正箇所
 * を自動特定する仕組み。
 *
 * Claude Code は静的な法令知識のみで、改正があっても気付かない。
 * 本モジュールは:
 *   1. 監視対象法令カタログ
 *   2. e-Gov 法令API (https://laws.e-gov.go.jp/api/) クライアント I/F
 *   3. 官報 (https://kanpou.npb.go.jp/) スクレイピング I/F
 *   4. パブコメ (https://public-comment.e-gov.go.jp/) ウォッチャー
 *   5. 改正影響分析 (Diff計算 → 該当条文 → モジュール一覧)
 *   6. 「直近3年で改正された法令」リスト
 *   7. 法令通知のチャネル (Slack/Email/Webhook)
 */

// ============================================================================
// Types
// ============================================================================

export type LawCategory =
  | 'tax'         // 税
  | 'labor'       // 労働
  | 'corporate'   // 商事/会社
  | 'consumer'    // 消費者
  | 'privacy'     // 個人情報
  | 'construction'// 建設
  | 'medical'     // 医療
  | 'longterm_care' // 介護
  | 'finance'     // 金融
  | 'environment' // 環境
  | 'real_estate' // 不動産
  | 'transport'   // 運輸
  | 'food'        // 食品
  | 'pharma'      // 薬機
  | 'broadcasting'// 放送通信
  | 'public'      // 公共
  | 'admin'       // 行政手続
  | 'copyright'   // 著作権
  | 'patent'      // 産業財産権 (特許・実用新案・意匠・商標)
  | 'other';

export interface LawCatalogEntry {
  /**
   * e-Gov 法令ID (例: 415AC0000000057 = 個人情報の保護に関する法律 / 平成十五年法律第五十七号)
   *
   * ★推測で書かないこと (2026-07-31 実測・課題台帳 Q-04)。
   *   本欄はかつて「元号年 + AC + 番号ゼロ詰め」の手書き推測値で埋められており、
   *   e-Gov 実IDは [5:8] に '000'/'100'/'010' の区分を持つため機械生成では当たらず、
   *   101 エントリ中 72 件が「存在しないID」または「別法令を指すID」だった。
   *   値の追加・変更は必ず lib/japan/law_auto_update/law-catalog-id-audit.sh の
   *   verify → apply (法令名で e-Gov を検索して裏取りした値だけを焼き付ける) で行う。
   */
  egovLawId: string;
  /** 通称 */
  shortName: string;
  /** 正式名称 */
  officialName: string;
  category: LawCategory;
  /** 主管省庁 */
  competentMinistry: string;
  /** 最終公布日 */
  lastPromulgationDate: string;
  /** 最終施行日 */
  lastEffectiveDate: string;
  /** 関連モジュール (本ライブラリ内) */
  relatedModules: string[];
}

/** 監視対象法令カタログ */
export const LAW_CATALOG: LawCatalogEntry[] = [
  { egovLawId: '415AC0000000057', shortName: '個情法', officialName: '個人情報の保護に関する法律', category: 'privacy', competentMinistry: '個人情報保護委員会', lastPromulgationDate: '2023-06-16', lastEffectiveDate: '2024-04-01', relatedModules: ['lib/japan/laws.ts', 'lib/japan/incident.ts'] },
  { egovLawId: '363AC0000000108', shortName: 'インボイス制度', officialName: '消費税法 (適格請求書等保存方式)', category: 'tax', competentMinistry: '国税庁', lastPromulgationDate: '2023-09-30', lastEffectiveDate: '2023-10-01', relatedModules: ['lib/japan/laws.ts', 'lib/japan/bug_prevention.ts', 'templates/japan/Invoice.tsx'] },
  { egovLawId: '410AC0000000025', shortName: '電帳法', officialName: '電子計算機を使用して作成する国税関係帳簿書類の保存方法等の特例に関する法律', category: 'tax', competentMinistry: '国税庁', lastPromulgationDate: '2023-12-22', lastEffectiveDate: '2024-01-01', relatedModules: ['lib/japan/laws.ts', 'lib/japan/eseal.ts', 'lib/japan/fax_ocr.ts'] },
  { egovLawId: '322AC0000000049', shortName: '労基法', officialName: '労働基準法', category: 'labor', competentMinistry: '厚生労働省', lastPromulgationDate: '2023-06-09', lastEffectiveDate: '2024-04-01', relatedModules: ['lib/japan/laws.ts'] },
  { egovLawId: '417AC0000000086', shortName: '会社法', officialName: '会社法', category: 'corporate', competentMinistry: '法務省', lastPromulgationDate: '2023-12-13', lastEffectiveDate: '2024-04-01', relatedModules: ['lib/japan/ringi.ts'] },
  { egovLawId: '324AC0000000100', shortName: '建設業法', officialName: '建設業法', category: 'construction', competentMinistry: '国土交通省', lastPromulgationDate: '2023-06-16', lastEffectiveDate: '2024-04-01', relatedModules: ['lib/japan/laws_extended.ts', 'lib/japan/architecture.ts'] },
  { egovLawId: '325AC0000000201', shortName: '建築基準法', officialName: '建築基準法', category: 'construction', competentMinistry: '国土交通省', lastPromulgationDate: '2023-06-16', lastEffectiveDate: '2025-04-01', relatedModules: ['lib/japan/architecture.ts', 'lib/japan/regional_laws.ts'] },
  { egovLawId: '409AC0000000123', shortName: '介護保険法', officialName: '介護保険法', category: 'longterm_care', competentMinistry: '厚生労働省', lastPromulgationDate: '2023-12-22', lastEffectiveDate: '2024-04-01', relatedModules: ['lib/japan/longterm_care.ts'] },
  { egovLawId: '323AC0000000205', shortName: '医療法', officialName: '医療法', category: 'medical', competentMinistry: '厚生労働省', lastPromulgationDate: '2023-06-09', lastEffectiveDate: '2024-04-01', relatedModules: ['lib/japan/medical.ts'] },
  { egovLawId: '323AC0000000025', shortName: '金商法', officialName: '金融商品取引法', category: 'finance', competentMinistry: '金融庁', lastPromulgationDate: '2024-05-22', lastEffectiveDate: '2024-12-25', relatedModules: ['lib/japan/security_audit.ts', 'lib/japan/finance.ts'] },
];

// ============================================================================
// e-Gov 法令API クライアント (I/F のみ・実通信は呼出側で実装)
// ============================================================================

export interface EgovLawSummary {
  lawId: string;
  lawTitle: string;
  lawNum: string;
  promulgationDate: string;
  lastUpdateDate?: string;
}

export interface EgovLawTextChunk {
  articleNum: string;
  paragraphNum?: string;
  itemNum?: string;
  text: string;
}

export interface EgovApiClient {
  fetchLawSummary(lawId: string): Promise<EgovLawSummary>;
  fetchLawText(lawId: string): Promise<EgovLawTextChunk[]>;
  searchLaws(keyword: string, category?: LawCategory): Promise<EgovLawSummary[]>;
}

/** モック実装: 単体テスト用 */
export function createMockEgovClient(): EgovApiClient {
  return {
    async fetchLawSummary(lawId) {
      const entry = LAW_CATALOG.find((l) => l.egovLawId === lawId);
      if (!entry) throw new Error(`Unknown law: ${lawId}`);
      return { lawId, lawTitle: entry.officialName, lawNum: entry.egovLawId, promulgationDate: entry.lastPromulgationDate };
    },
    async fetchLawText() {
      return [{ articleNum: '1', text: '（モック条文）' }];
    },
    async searchLaws(keyword) {
      return LAW_CATALOG.filter((l) => l.shortName.includes(keyword) || l.officialName.includes(keyword)).map((l) => ({
        lawId: l.egovLawId, lawTitle: l.officialName, lawNum: l.egovLawId, promulgationDate: l.lastPromulgationDate,
      }));
    },
  };
}

// ============================================================================
// 改正検知 (Diff)
// ============================================================================

export interface LawAmendmentDiff {
  lawId: string;
  beforeVersion: { effectiveDate: string; chunks: EgovLawTextChunk[] };
  afterVersion: { effectiveDate: string; chunks: EgovLawTextChunk[] };
  /** 変更があった条文 */
  changedArticles: { articleNum: string; changeType: 'added' | 'modified' | 'deleted'; before?: string; after?: string }[];
  /** 影響を受ける本ライブラリのモジュール */
  affectedModules: string[];
  severity: 'major' | 'minor' | 'editorial';
}

export function diffLawVersions(input: {
  lawId: string;
  before: { effectiveDate: string; chunks: EgovLawTextChunk[] };
  after: { effectiveDate: string; chunks: EgovLawTextChunk[] };
}): LawAmendmentDiff {
  const beforeMap = new Map(input.before.chunks.map((c) => [`${c.articleNum}-${c.paragraphNum ?? ''}-${c.itemNum ?? ''}`, c]));
  const afterMap = new Map(input.after.chunks.map((c) => [`${c.articleNum}-${c.paragraphNum ?? ''}-${c.itemNum ?? ''}`, c]));
  const changes: LawAmendmentDiff['changedArticles'] = [];
  for (const [k, a] of afterMap) {
    const b = beforeMap.get(k);
    if (!b) {
      changes.push({ articleNum: a.articleNum, changeType: 'added', after: a.text });
    } else if (b.text !== a.text) {
      changes.push({ articleNum: a.articleNum, changeType: 'modified', before: b.text, after: a.text });
    }
  }
  for (const [k, b] of beforeMap) {
    if (!afterMap.has(k)) changes.push({ articleNum: b.articleNum, changeType: 'deleted', before: b.text });
  }
  const entry = LAW_CATALOG.find((l) => l.egovLawId === input.lawId);
  const severity: LawAmendmentDiff['severity'] = changes.length > 5 ? 'major' : changes.length > 0 ? 'minor' : 'editorial';
  return {
    lawId: input.lawId,
    beforeVersion: input.before,
    afterVersion: input.after,
    changedArticles: changes,
    affectedModules: entry?.relatedModules ?? [],
    severity,
  };
}

// ============================================================================
// パブコメ ウォッチャー
// ============================================================================

export interface PublicCommentItem {
  publicCommentId: string;
  title: string;
  competentMinistry: string;
  startDate: string;
  endDate: string;
  url: string;
  category?: LawCategory;
  /** 関連法令ID */
  relatedLawIds?: string[];
}

export interface PublicCommentWatcher {
  fetchOpenComments(): Promise<PublicCommentItem[]>;
  fetchByCategory(c: LawCategory): Promise<PublicCommentItem[]>;
}

// ============================================================================
// 改正通知チャネル
// ============================================================================

export type NotificationChannel = 'slack' | 'email' | 'teams' | 'webhook' | 'github_issue';

export interface AmendmentNotification {
  channel: NotificationChannel;
  /** 通知本文 (Markdown) */
  body: string;
  severity: 'major' | 'minor' | 'editorial';
  recipients: string[];
}

export function buildAmendmentNotification(input: {
  diff: LawAmendmentDiff;
  channel: NotificationChannel;
  recipients: string[];
}): AmendmentNotification {
  const entry = LAW_CATALOG.find((l) => l.egovLawId === input.diff.lawId);
  const lines: string[] = [];
  lines.push(`## ⚖️ 法令改正検知: ${entry?.shortName ?? input.diff.lawId}`);
  lines.push('');
  lines.push(`- 法令: ${entry?.officialName ?? '-'}`);
  lines.push(`- 改正日: ${input.diff.afterVersion.effectiveDate}`);
  lines.push(`- 重要度: **${input.diff.severity}**`);
  lines.push(`- 変更条文数: ${input.diff.changedArticles.length}`);
  lines.push('');
  lines.push('### 影響モジュール');
  input.diff.affectedModules.forEach((m) => lines.push(`- \`${m}\``));
  lines.push('');
  lines.push('### 主要変更');
  input.diff.changedArticles.slice(0, 5).forEach((c) => {
    lines.push(`- 第${c.articleNum}条: ${c.changeType}`);
  });
  return { channel: input.channel, body: lines.join('\n'), severity: input.diff.severity, recipients: input.recipients };
}

// ============================================================================
// 直近改正法令リスト
// ============================================================================

export function recentlyAmendedLaws(monthsBack: number, today: Date = new Date()): LawCatalogEntry[] {
  const threshold = new Date(today);
  threshold.setMonth(threshold.getMonth() - monthsBack);
  return LAW_CATALOG.filter((l) => new Date(l.lastEffectiveDate) >= threshold)
    .sort((a, b) => b.lastEffectiveDate.localeCompare(a.lastEffectiveDate));
}

export const LAW_TRACKER_REFS = {
  EGOV_API: 'https://laws.e-gov.go.jp/api/',
  KANPOU: 'https://kanpou.npb.go.jp/',
  PUBLIC_COMMENT: 'https://public-comment.e-gov.go.jp/',
  REGULATORY_REFORM: 'https://www8.cao.go.jp/kisei-kaikaku/',
};
