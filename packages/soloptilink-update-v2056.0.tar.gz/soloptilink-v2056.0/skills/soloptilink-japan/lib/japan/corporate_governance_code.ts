/**
 * SoloptiLinkAI Phase 47-GV3 — コーポレートガバナンスコード R3.6 改訂版 + 東証 PBR 1倍割れ要請
 *
 * 東証コーポレートガバナンスコード R3.6.11 改訂 (5原則 31項目) +
 * 東証 R5.3.31「資本コストや株価を意識した経営の実現に向けた対応」 (PBR1倍割れ要請) +
 * スチュワードシップコード R2.3 改訂版。
 *
 * カバー範囲:
 *  - CG コード 5基本原則 + 31原則 + 47補充原則
 *  - プライム/スタンダード/グロース 区分基準と追加要件
 *  - 独立社外取締役 (プライム1/3以上 + 過半数推奨)
 *  - PBR 1倍割れ対応 (ROE / ROIC / WACC 比較 + 開示)
 *  - 政策保有株式の縮減 (経済合理性検証 + 5%超開示)
 *  - スチュワードシップコード (機関投資家の責任)
 *  - 監査等委員会設置会社 (会社法399条の13)
 *  - サステナビリティ基本方針 (TCFD/TNFD/ISSB)
 *  - 人的資本可視化 (女性管理職比率 + 男性育休取得率)
 *
 * なぜClaude Codeに作れないか:
 *   東証 R5.3 PBR 要請は **日本固有** (世界初) の上場規則であり、
 *   Anthropic の英文学習データには「PBR 1倍割れ要請」「資本コストや株価を意識した経営」
 *   というキーワード自体が存在しない。スチュワードシップコードも日本独自。
 */

// ───────────────────────────────────────────────
// 上場区分 (東証 R4.4 区分再編)
// ───────────────────────────────────────────────

export type ListingMarket = "prime" | "standard" | "growth" | "tokyopro";

/** 上場区分別の流通株式時価総額基準 (R4.4 再編後) */
export const LISTING_MARKET_REQUIREMENTS: Record<ListingMarket, {
  tradable_share_market_cap_min_yen: number;
  tradable_share_ratio_min_percent: number;
  shareholder_count_min: number;
  description: string;
}> = {
  prime: {
    tradable_share_market_cap_min_yen: 10_000_000_000, // 100億円
    tradable_share_ratio_min_percent: 35,
    shareholder_count_min: 800,
    description: "グローバルな投資家との建設的対話を中心に置く市場",
  },
  standard: {
    tradable_share_market_cap_min_yen: 1_000_000_000, // 10億円
    tradable_share_ratio_min_percent: 25,
    shareholder_count_min: 400,
    description: "公開された市場における投資対象として十分な流動性とガバナンスを備えた市場",
  },
  growth: {
    tradable_share_market_cap_min_yen: 500_000_000, // 5億円
    tradable_share_ratio_min_percent: 25,
    shareholder_count_min: 150,
    description: "高い成長可能性を実現するための事業計画と相応のリスク",
  },
  tokyopro: {
    tradable_share_market_cap_min_yen: 0, // プロ向け市場のため流動性要件は限定的
    tradable_share_ratio_min_percent: 0,
    shareholder_count_min: 0,
    description: "特定投資家向け市場 (J-Adviser 制度)",
  },
};

// ───────────────────────────────────────────────
// CG コード R3.6 改訂版 — 5基本原則
// ───────────────────────────────────────────────

export type CgCodeChapter =
  | "ch1_shareholders_rights" // 株主の権利・平等性の確保
  | "ch2_stakeholder_collaboration" // 株主以外のステークホルダーとの適切な協働
  | "ch3_disclosure_transparency" // 適切な情報開示と透明性の確保
  | "ch4_board_responsibility" // 取締役会等の責務
  | "ch5_dialogue_with_shareholders"; // 株主との対話

/** 各章の原則・補充原則の数 (R3.6改訂版) */
export const CG_CODE_PRINCIPLE_COUNT: Record<CgCodeChapter, { principles: number; supplementary: number }> = {
  ch1_shareholders_rights: { principles: 7, supplementary: 5 },
  ch2_stakeholder_collaboration: { principles: 6, supplementary: 1 },
  ch3_disclosure_transparency: { principles: 2, supplementary: 3 },
  ch4_board_responsibility: { principles: 14, supplementary: 32 },
  ch5_dialogue_with_shareholders: { principles: 2, supplementary: 6 },
};

/** プライム市場上場企業に対する追加要件 (R3.6改訂で強化) */
export const PRIME_ADDITIONAL_REQUIREMENTS = {
  /** 独立社外取締役 1/3以上 (4-8) — 必要と考える企業は過半数選任 */
  independent_directors_min_ratio: 1 / 3,
  /** プライムは過半数推奨 */
  independent_directors_recommended: 0.5,
  /** 指名委員会・報酬委員会の独立社外取締役の過半数 */
  nomination_remuneration_committee_independent_majority: true,
  /** TCFD またはそれと同等の枠組みに基づく気候関連情報開示 (3-1③) */
  climate_disclosure_tcfd_required: true,
  /** 重要書類の英文開示 (有報・招集通知・適時開示等) */
  english_disclosure_required: true,
  /** スキル・マトリックスの開示 (4-11①) */
  skills_matrix_required: true,
  /** 女性・外国人・中途採用者の管理職への登用 (2-4①) */
  diversity_management_disclosure: true,
};

// ───────────────────────────────────────────────
// 東証 R5.3 PBR 1倍割れ要請 — 「資本コストや株価を意識した経営」
// ───────────────────────────────────────────────

/** R5.3.31 東証発出の要請に基づく対応開示 */
export interface PbrAction {
  fiscal_year_end: string; // YYYY-MM-DD
  market: ListingMarket;
  pbr_at_period_end: number; // 例: 0.85
  roe_at_period_end_percent: number; // 例: 6.5
  wacc_estimate_percent?: number; // 推定 WACC (任意)
  cost_of_equity_estimate_percent?: number; // 推定資本コスト
  /** 現状分析: 自社の現状をどう認識しているか */
  current_situation_analysis: string;
  /** 方針・目標: ROE/ROIC > WACC を実現する具体目標 */
  policy_and_goals: string;
  /** 取り組み: 資本効率改善、成長投資、株主還元、IR など */
  initiatives: string[];
  /** 進捗評価: 過去施策のレビュー */
  progress_review?: string;
  disclosure_in_corp_governance_report: boolean;
  disclosure_in_annual_report: boolean;
}

/**
 * PBR 対応開示の必要性判定 — PBR 1倍割れまたはROE < WACC で要対応
 */
export function isPbrActionRequired(p: {
  pbr: number;
  roe_percent: number;
  wacc_percent: number;
}): { required: boolean; severity: "critical" | "warning" | "ok"; reasons: string[] } {
  const reasons: string[] = [];
  let severity: "critical" | "warning" | "ok" = "ok";

  if (p.pbr < 1.0) {
    reasons.push(`PBR ${p.pbr.toFixed(2)} < 1.0 (純資産割れ)`);
    severity = "critical";
  }
  if (p.roe_percent < p.wacc_percent) {
    reasons.push(`ROE ${p.roe_percent}% < WACC ${p.wacc_percent}% (資本コスト割れ)`);
    if (severity !== "critical") severity = "warning";
  }
  if (p.pbr < 0.7) {
    reasons.push("PBR 0.7未満 — 解散価値を市場が織り込み済");
    severity = "critical";
  }
  return { required: severity !== "ok", severity, reasons };
}

/** PBR 対応開示の必須項目チェック */
export function validatePbrDisclosure(action: PbrAction): { valid: boolean; missing: string[] } {
  const missing: string[] = [];
  if (!action.current_situation_analysis || action.current_situation_analysis.length < 50) {
    missing.push("現状分析 (50文字以上)");
  }
  if (!action.policy_and_goals || action.policy_and_goals.length < 50) {
    missing.push("方針・目標 (50文字以上)");
  }
  if (action.initiatives.length < 1) missing.push("具体的な取組み (1つ以上)");
  if (!action.disclosure_in_corp_governance_report) missing.push("コーポレートガバナンス報告書での開示");
  return { valid: missing.length === 0, missing };
}

// ───────────────────────────────────────────────
// 政策保有株式 — 経済合理性検証
// ───────────────────────────────────────────────

/** 政策保有株式の有報開示閾値: 上位 60銘柄 (内閣府令第8号様式 第二号様式) */
export const POLICY_HOLDING_DISCLOSURE_TOP_N = 60;

/** 政策保有株式 5%超 開示義務 (有価証券報告書) */
export const POLICY_HOLDING_DISCLOSURE_RATIO_THRESHOLD = 0.05;

export interface PolicyHolding {
  issuer_name: string;
  shares_held: number;
  book_value_yen: number; // 簿価
  market_value_yen: number; // 時価
  ownership_ratio: number; // 持株比率 (0-1)
  /** 経済合理性: 5要素 */
  economic_rationale: {
    cooperation_value: string; // 協業による価値
    risk_reduction_value: string; // リスク低減
    return_estimation: number; // 想定リターン (年率%)
    cost_of_capital_check: boolean; // 資本コスト超過確認済か
    annual_review_done: boolean; // 個別銘柄毎の取締役会等での検証済か
  };
  /** 議決権行使方針 */
  voting_policy: string;
}

export function evaluatePolicyHolding(h: PolicyHolding): {
  retain: boolean;
  reasons: string[];
} {
  const reasons: string[] = [];
  if (!h.economic_rationale.cost_of_capital_check) {
    reasons.push("資本コスト超過の検証なし");
  }
  if (!h.economic_rationale.annual_review_done) {
    reasons.push("取締役会等での年次検証なし — CGコード1-4不適合");
  }
  if (h.economic_rationale.return_estimation < 0) {
    reasons.push("想定リターンがマイナス — 経済合理性なし");
  }
  if (h.market_value_yen < h.book_value_yen * 0.7) {
    reasons.push("時価が簿価70%未満 — 含み損");
  }
  return { retain: reasons.length === 0, reasons };
}

// ───────────────────────────────────────────────
// 監査等委員会設置会社 — 会社法399条の13
// ───────────────────────────────────────────────

export type BoardCommitteeStructure =
  | "company_with_kansayaku" // 監査役会設置会社 (伝統的)
  | "company_with_audit_committee" // 監査等委員会設置会社 (H27改正)
  | "company_with_three_committees"; // 指名委員会等設置会社 (H14改正)

export interface BoardComposition {
  total_directors: number;
  outside_directors: number;
  independent_directors: number;
  female_directors: number;
  foreign_directors: number;
  structure: BoardCommitteeStructure;
}

/** 取締役会構成の CGコード 適合性チェック */
export function evaluateBoardComposition(
  c: BoardComposition,
  market: ListingMarket,
): { compliant: boolean; warnings: string[] } {
  const warnings: string[] = [];
  const reqs = PRIME_ADDITIONAL_REQUIREMENTS;
  const indep_ratio = c.independent_directors / c.total_directors;

  if (market === "prime" && indep_ratio < reqs.independent_directors_min_ratio) {
    warnings.push(
      `プライム独立社外取締役比率 ${(indep_ratio * 100).toFixed(1)}% < 1/3 (CG 4-8 不適合)`,
    );
  }
  if (market === "standard" && c.independent_directors < 2) {
    warnings.push("スタンダード独立社外取締役 2名以上 (CG 4-8 不適合)");
  }
  if (c.female_directors === 0) {
    warnings.push("女性取締役不在 — CG 2-4①ダイバーシティ確保の趣旨に反する可能性");
  }
  return { compliant: warnings.length === 0, warnings };
}

// ───────────────────────────────────────────────
// サステナビリティ開示 — 有報「サステナビリティに関する考え方及び取組」(R5.3 内閣府令)
// ───────────────────────────────────────────────

/** 有報サステナ開示の4要素 (R5.3 内閣府令第28号) */
export const SUSTAINABILITY_DISCLOSURE_PILLARS = [
  "governance", // ガバナンス
  "strategy", // 戦略
  "risk_management", // リスク管理
  "metrics_and_targets", // 指標と目標
] as const;

/** 人的資本可視化の必須開示項目 */
export interface HumanCapitalDisclosure {
  female_managers_ratio_percent: number; // 女性管理職比率
  male_paternity_leave_uptake_percent: number; // 男性育休取得率
  pay_gap_male_female_percent?: number; // 男女賃金差異 (女性 ÷ 男性 × 100, 高いほどよい)
  training_investment_per_employee_yen?: number; // 一人当たり教育投資
  turnover_rate_percent?: number; // 離職率
  female_managers_target_percent?: number; // 目標
  /** 女性活躍推進法に基づく開示 (常時 301人以上) */
  womens_advancement_act_applicable: boolean;
}

export function evaluateHumanCapitalDisclosure(d: HumanCapitalDisclosure): {
  complete: boolean;
  missing: string[];
} {
  const missing: string[] = [];
  if (d.womens_advancement_act_applicable) {
    if (d.pay_gap_male_female_percent == null) {
      missing.push("男女賃金差異 (R4.7 義務化, 常時301人以上)");
    }
  }
  if (d.female_managers_target_percent == null) {
    missing.push("女性管理職比率の目標値");
  }
  return { complete: missing.length === 0, missing };
}

// ───────────────────────────────────────────────
// スチュワードシップコード R2.3 改訂版
// ───────────────────────────────────────────────

/** スチュワードシップコード 8原則 (機関投資家の責任) */
export const STEWARDSHIP_CODE_PRINCIPLES = [
  "1. スチュワードシップ責任の方針策定・公表",
  "2. 利益相反管理 (R2.3 強化)",
  "3. 投資先のモニタリング",
  "4. 建設的対話 (Engagement)",
  "5. 議決権行使方針と結果の公表",
  "6. 顧客・受益者への報告",
  "7. 実力向上",
  "8. サービス・プロバイダー (議決権行使助言会社等) の役割 (R2.3 新設)",
] as const;

export const STEWARDSHIP_CODE_REVISION = "R2.3.24"; // 2020-03-24 改訂
