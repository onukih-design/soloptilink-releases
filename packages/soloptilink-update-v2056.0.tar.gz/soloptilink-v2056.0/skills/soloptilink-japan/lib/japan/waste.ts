/**
 * lib/japan/waste.ts — 廃棄物処理・リサイクルDNA
 *
 * 法令カバレッジ:
 *  - 廃棄物処理法 (廃掃法 S45法律137) 一般廃棄物/産業廃棄物/特別管理
 *  - 産業廃棄物管理票 (マニフェスト) 制度 (廃掃法12条の3)
 *  - 電子マニフェスト (JWNET 公益財団法人日本産業廃棄物処理振興センター)
 *  - 容器包装リサイクル法 (H7法律112)
 *  - 家電リサイクル法 (家リ法 H10法律97 — エアコン/TV/冷蔵庫/洗濯機)
 *  - 自動車リサイクル法 (H14法律87)
 *  - 食品リサイクル法 (H12法律116)
 *  - 建設リサイクル法 (建リ法 H12法律104 — 80m²以上)
 *  - 小型家電リサイクル法 (H24法律57)
 *  - フロン排出抑制法 (H13法律64 / H27改正)
 *  - 資源有効利用促進法 (H3法律48)
 *
 * 参考: 環境省 環境再生・資源循環局, JWNET (sjc.or.jp), 産廃情報ネット
 */

// ============================================================================
// 1. 廃棄物の分類 (廃掃法2条)
// ============================================================================

export type WasteCategory =
  | 'general_household' // 一般廃棄物 (家庭系)
  | 'general_business' // 一般廃棄物 (事業系)
  | 'industrial' // 産業廃棄物
  | 'industrial_special' // 特別管理産業廃棄物
  | 'general_special'; // 特別管理一般廃棄物

/** 産業廃棄物 20種 (廃掃法施行令2条) */
export const INDUSTRIAL_WASTE_TYPES = [
  '燃え殻', '汚泥', '廃油', '廃酸', '廃アルカリ',
  '廃プラスチック類', '紙くず', '木くず', '繊維くず', '動植物性残さ',
  '動物系固形不要物', 'ゴムくず', '金属くず', 'ガラスくず・コンクリートくず・陶磁器くず',
  '鉱さい', 'がれき類', '動物のふん尿', '動物の死体', 'ばいじん',
  '13号廃棄物', // 政令で定める産業廃棄物を処分するために処理したもの
] as const;

/** 特別管理産業廃棄物 (廃掃法2条の4) */
export const SPECIAL_INDUSTRIAL_WASTE = [
  '廃油 (引火点70℃未満)', '廃酸 (pH≤2.0)', '廃アルカリ (pH≥12.5)',
  '感染性産業廃棄物', '廃PCB等', 'PCB汚染物', 'PCB処理物',
  '廃水銀等', '指定下水汚泥', '鉱さい (有害物質基準超)',
  '廃石綿等', '燃え殻 (有害物質基準超)', 'ばいじん (有害物質基準超)',
] as const;

/** 廃棄物分類の自動判定 */
export function classifyWaste(input: {
  source: 'household' | 'business';
  contents: string[];
  hasInfectious?: boolean;
  hasPCB?: boolean;
  hasAsbestos?: boolean;
  oilFlashPointC?: number;
  pH?: number;
}): { category: WasteCategory; reason: string; needsManifest: boolean } {
  // 特別管理判定
  if (input.hasInfectious || input.hasPCB || input.hasAsbestos) {
    return {
      category: 'industrial_special',
      reason: `特別管理 (${input.hasInfectious ? '感染性' : input.hasPCB ? 'PCB' : '石綿'})`,
      needsManifest: true,
    };
  }
  if (input.oilFlashPointC !== undefined && input.oilFlashPointC < 70) {
    return { category: 'industrial_special', reason: '廃油 引火点70℃未満', needsManifest: true };
  }
  if (input.pH !== undefined && (input.pH <= 2.0 || input.pH >= 12.5)) {
    return { category: 'industrial_special', reason: 'pH 2.0以下 or 12.5以上 (廃酸/廃アルカリ)', needsManifest: true };
  }

  // 産業廃棄物判定
  const isIndustrial =
    input.source === 'business' &&
    input.contents.some((c) =>
      (INDUSTRIAL_WASTE_TYPES as readonly string[]).some((t) => c.includes(t.replace(/くず|類| 等/g, '')))
    );
  if (isIndustrial) {
    return { category: 'industrial', reason: '事業活動由来 + 政令20種該当', needsManifest: true };
  }

  // 一般廃棄物
  return {
    category: input.source === 'household' ? 'general_household' : 'general_business',
    reason: input.source === 'household' ? '家庭系一般廃棄物 (市町村処理責務)' : '事業系一般廃棄物',
    needsManifest: false,
  };
}

// ============================================================================
// 2. マニフェスト制度 (廃掃法12条の3 + JWNET 電子マニフェスト)
// ============================================================================

export type ManifestKind = 'paper' | 'electronic'; // 紙マニフェスト / 電子マニフェスト

export interface Manifest {
  kind: ManifestKind;
  manifestNumber: string; // 11桁 紙 / 12桁 電子
  issueDate: Date;
  exhauster: string; // 排出事業者
  collector: string; // 収集運搬業者
  disposer: string; // 処分業者
  finalDisposalSite: string;
  wasteType: string;
  weightKg: number;
  // フロー追跡
  a_collected?: Date; // A票: 排出事業者控
  b1_to_collector?: Date;
  b2_to_disposer?: Date;
  c1_to_disposer?: Date;
  c2_to_collector?: Date;
  d_to_exhauster?: Date; // D票: 処分終了 — 90日以内に返送必須
  e_final_disposal?: Date; // E票: 最終処分終了 — 180日以内
}

/** マニフェストの 90/180 日ルール検証 (廃掃法12条の3) */
export function validateManifestFlow(m: Manifest, today: Date = new Date()): {
  compliant: boolean;
  alerts: string[];
} {
  const alerts: string[] = [];
  const ms90 = 90 * 86400000;
  const ms180 = 180 * 86400000;
  const issuedMs = today.getTime() - m.issueDate.getTime();

  if (!m.d_to_exhauster && issuedMs > ms90) {
    alerts.push('D票 90日経過: 処分終了通知未受領 — 都道府県知事へ報告義務 (12条の3 第8項)');
  }
  if (!m.e_final_disposal && issuedMs > ms180) {
    alerts.push('E票 180日経過: 最終処分終了通知未受領 — 都道府県知事へ報告義務');
  }
  if (m.kind === 'paper') {
    alerts.push('紙マニフェスト: 5年間保存義務 (規則8条の26)');
  }
  return { compliant: alerts.length === 0, alerts };
}

/** 電子マニフェスト (JWNET) 義務化対象 (R2.4施行) */
export function isJwnetMandatory(annualSpecialWasteWeightTon: number): boolean {
  // 前々年度に特別管理産業廃棄物を 50t 以上発生させた多量排出事業者は電子マニフェスト義務化
  return annualSpecialWasteWeightTon >= 50;
}

// ============================================================================
// 3. 家電リサイクル法 (H10法律97)
// ============================================================================

/** 家電4品目 + リサイクル料金 (R6目安) */
export const HOME_APPLIANCE_RECYCLING_FEES = {
  air_conditioner: { ja: 'エアコン', feeJpy: 990, code: '01' },
  tv_crt: { ja: 'ブラウン管TV (15型以下)', feeJpy: 1320, code: '02' },
  tv_lcd_small: { ja: '液晶/プラズマTV (15型以下)', feeJpy: 1870, code: '02' },
  tv_lcd_large: { ja: '液晶/プラズマTV (16型以上)', feeJpy: 2970, code: '02' },
  refrigerator_small: { ja: '冷蔵庫 (170L以下)', feeJpy: 3740, code: '03' },
  refrigerator_large: { ja: '冷蔵庫 (171L以上)', feeJpy: 4730, code: '03' },
  washer_dryer: { ja: '洗濯機/衣類乾燥機', feeJpy: 2530, code: '04' },
} as const;

export function calcApplianceRecyclingFee(
  items: { type: keyof typeof HOME_APPLIANCE_RECYCLING_FEES; qty: number }[]
): { totalJpy: number; breakdown: { item: string; subtotal: number }[] } {
  const breakdown = items.map((i) => ({
    item: HOME_APPLIANCE_RECYCLING_FEES[i.type].ja,
    subtotal: HOME_APPLIANCE_RECYCLING_FEES[i.type].feeJpy * i.qty,
  }));
  return {
    totalJpy: breakdown.reduce((s, b) => s + b.subtotal, 0),
    breakdown,
  };
}

// ============================================================================
// 4. 建設リサイクル法 (H12法律104)
// ============================================================================

/** 建設リサイクル法 対象工事の判定 (建リ法9条) */
export function requiresConstructionRecyclingNotice(input: {
  workType: 'new_build' | 'demolition' | 'renovation' | 'civil';
  floorAreaM2?: number;
  contractValueJpy?: number;
}): { required: boolean; reason: string } {
  switch (input.workType) {
    case 'demolition':
      if ((input.floorAreaM2 ?? 0) >= 80) {
        return { required: true, reason: '解体工事 80m²以上 — 工事7日前までに知事届出' };
      }
      break;
    case 'new_build':
      if ((input.floorAreaM2 ?? 0) >= 500) {
        return { required: true, reason: '新築工事 500m²以上 — 知事届出' };
      }
      break;
    case 'renovation':
      if ((input.contractValueJpy ?? 0) >= 100_000_000) {
        return { required: true, reason: '修繕模様替 1億円以上 — 知事届出' };
      }
      break;
    case 'civil':
      if ((input.contractValueJpy ?? 0) >= 5_000_000) {
        return { required: true, reason: '土木工事 500万円以上 — 知事届出' };
      }
      break;
  }
  return { required: false, reason: '対象外規模' };
}

// ============================================================================
// 5. フロン排出抑制法 (H13法律64 + H27改正)
// ============================================================================

export type FluorocarbonEquipmentKind = 'commercial_ac' | 'commercial_refrigeration' | 'industrial_chiller';

/** フロン排出抑制法 第一種特定製品の点検頻度 */
export function getFluorocarbonInspectionInterval(input: {
  kind: FluorocarbonEquipmentKind;
  ratedKw: number;
}): { intervalMonths: number; reason: string } {
  // エアコン: 7.5kW未満 = 簡易点検3月毎 / 7.5kW以上 = 定期点検1年毎
  // 冷凍冷蔵: 7.5kW以上50kW未満 = 1年, 50kW以上 = 1年
  if (input.kind === 'commercial_ac') {
    if (input.ratedKw < 7.5) return { intervalMonths: 3, reason: '簡易点検 3月毎 (7.5kW未満)' };
    if (input.ratedKw < 50) return { intervalMonths: 12, reason: '定期点検 1年毎 (7.5-50kW)' };
    return { intervalMonths: 12, reason: '定期点検 1年毎 (50kW以上 — 専門技術者)' };
  }
  if (input.ratedKw >= 7.5 && input.ratedKw < 50) return { intervalMonths: 12, reason: '冷凍冷蔵 1年毎' };
  if (input.ratedKw >= 50) return { intervalMonths: 6, reason: '冷凍冷蔵 大型 6月毎' };
  return { intervalMonths: 3, reason: '簡易点検 3月毎' };
}

/** フロン算定漏えい量報告 (年間1000t-CO2換算以上で報告義務) */
export function requiresFluorocarbonLeakReport(annualLeakageTCO2: number): {
  required: boolean;
  reason: string;
} {
  if (annualLeakageTCO2 >= 1000) {
    return { required: true, reason: '事業所からの算定漏えい量1000t-CO2/年以上 — 国へ報告義務' };
  }
  return { required: false, reason: '報告閾値未満' };
}

// ============================================================================
// 6. 容器包装リサイクル法 (H7法律112)
// ============================================================================

/** 特定事業者の再商品化義務 — 規模別 */
export function isPackagingRecyclingObligated(input: {
  industry: 'manufacturing' | 'commerce' | 'others';
  annualSalesJpy: number;
  employeeCount: number;
}): { obligated: boolean; reason: string } {
  // 小規模事業者除外: 製造業 売上2.4億以下 + 従業員20人以下 / 商業 売上7000万以下 + 5人以下
  if (input.industry === 'manufacturing') {
    if (input.annualSalesJpy <= 240_000_000 && input.employeeCount <= 20) {
      return { obligated: false, reason: '小規模事業者 (製造業 売上2.4億+従業員20人以下) 適用除外' };
    }
  } else {
    if (input.annualSalesJpy <= 70_000_000 && input.employeeCount <= 5) {
      return { obligated: false, reason: '小規模事業者 (商業 売上7000万+5人以下) 適用除外' };
    }
  }
  return { obligated: true, reason: '特定事業者 — 日本容器包装リサイクル協会経由で再商品化義務' };
}

// ============================================================================
// 7. 廃棄物処理業 許可
// ============================================================================

export interface DisposalLicense {
  kind: 'collection_transport' | 'intermediate' | 'final_disposal';
  prefecture: string; // 許可は都道府県/政令市単位
  validUntil: Date;
  scope: WasteCategory[];
}

/** 廃棄物処理業許可の有効期限チェック (廃掃法14条 — 5年更新) */
export function checkDisposalLicenseExpiry(license: DisposalLicense, today: Date = new Date()): {
  active: boolean;
  daysRemaining: number;
  warning: string | null;
} {
  const daysRemaining = Math.ceil((license.validUntil.getTime() - today.getTime()) / 86400000);
  return {
    active: daysRemaining > 0,
    daysRemaining,
    warning: daysRemaining < 90 ? `${license.kind} 許可の有効期限まで${daysRemaining}日 — 更新申請を` : null,
  };
}
