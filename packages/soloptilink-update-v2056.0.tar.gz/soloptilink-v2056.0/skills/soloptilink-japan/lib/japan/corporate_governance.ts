/**
 * SoloptiLinkAI Phase 45 — コーポレートガバナンス・コード対応
 *
 * 東証上場企業 (プライム/スタンダード/グロース) に求められる
 * コーポレートガバナンス・コード (CGC) 2024年改訂版および
 * Stewardship Code (機関投資家側) 統合対応モジュール。
 *
 * カバー範囲:
 *  - CGC 2024年改訂 (基本原則5本柱 + 原則 + 補充原則 / Comply or Explain)
 *  - 東証「資本コストや株価を意識した経営の実現に向けた対応」R5.3 (PB1割れ対策)
 *  - 機関設計3形態 (監査役会設置/監査等委員会設置/指名委員会等設置)
 *  - 社外取締役: プライム1/3以上 + 過半数推奨
 *  - 取締役会の多様性 (女性30%目標 — R7.4政府方針)
 *  - 株主総会 (会社法296条 / 招集通知 R3年早期発送)
 *  - 政策保有株式の縮減 (R5.3東証要請)
 *  - Stewardship Code 8原則 (R7改訂)
 *  - 統合報告書 / コーポレートガバナンス報告書 (CG報告書)
 */

export type ListingTier = "prime" | "standard" | "growth" | "unlisted";
export type BoardStructure =
  | "kansayaku" // 監査役会設置会社 (旧来型)
  | "audit_committee" // 監査等委員会設置会社 (2015年新設)
  | "three_committees"; // 指名委員会等設置会社 (グローバル型)

export interface CompanyProfile {
  company_name: string;
  listing_tier: ListingTier;
  board_structure: BoardStructure;
  total_directors: number;
  outside_directors: number; // 社外取締役
  independent_directors: number; // 独立社外取締役
  female_directors: number;
  pb_ratio: number; // PBR (簿価純資産倍率)
  roe_3y_avg: number; // 直近3期平均ROE %
  cross_holdings_book_value_ratio: number; // 政策保有株 / 純資産 %
  has_cg_report: boolean;
  cg_report_year?: number;
}

export interface CgFinding {
  rule: string;
  principle?: string; // CGC 原則番号 (例: "原則4-8")
  severity: "info" | "advice" | "warning" | "violation";
  hint: string;
}

/** 機関設計に関する制約 (会社法327条の2 / CGC原則4-8) */
export function checkBoardStructure(p: CompanyProfile): CgFinding[] {
  const findings: CgFinding[] = [];
  if (p.listing_tier === "unlisted") return findings;

  const independentRatio = p.independent_directors / Math.max(1, p.total_directors);

  // プライム: 独立社外取締役 1/3 以上 (CGC補充原則4-8①)
  if (p.listing_tier === "prime" && independentRatio < 1 / 3) {
    findings.push({
      rule: "CGC 補充原則4-8① (プライム市場)",
      principle: "原則4-8",
      severity: "violation",
      hint: `プライム市場上場会社は独立社外取締役を全体の1/3以上選任すべき (現状 ${(independentRatio * 100).toFixed(1)}%)。CG報告書で Comply or Explain。`,
    });
  }

  // プライム特有: 過半数推奨 (補充原則4-8②)
  if (p.listing_tier === "prime" && independentRatio < 0.5) {
    findings.push({
      rule: "CGC 補充原則4-8② (プライム市場)",
      principle: "原則4-8",
      severity: "advice",
      hint: "プライム市場では過半数の独立社外取締役選任が推奨される。スキルマトリクス公表とセットで検討。",
    });
  }

  // スタンダード/グロース: 2名以上 (補充原則4-8原則)
  if (p.listing_tier !== "prime" && p.independent_directors < 2) {
    findings.push({
      rule: "CGC 原則4-8",
      principle: "原則4-8",
      severity: "violation",
      hint: "上場会社は独立社外取締役を最低2名以上選任すべき。",
    });
  }

  return findings;
}

/** 取締役会のジェンダー多様性 (CGC補充原則2-4① + R7.4政府方針) */
export function checkDiversity(p: CompanyProfile): CgFinding[] {
  const findings: CgFinding[] = [];
  const femaleRatio = p.female_directors / Math.max(1, p.total_directors);

  if (p.listing_tier === "prime" && femaleRatio < 0.3) {
    findings.push({
      rule: "CGC 補充原則2-4① + R7.4政府方針 (女性役員比率30%目標)",
      principle: "原則2-4",
      severity: femaleRatio < 0.1 ? "warning" : "advice",
      hint: `プライム上場会社は2030年までに女性役員30%以上が政府目標 (現状 ${(femaleRatio * 100).toFixed(1)}%)。多様性方針 + 育成計画 + 数値目標を CG報告書で開示。`,
    });
  }

  if (p.listing_tier === "prime" && p.female_directors === 0) {
    findings.push({
      rule: "R7.4政府方針 (女性役員0社の解消)",
      principle: "原則2-4",
      severity: "warning",
      hint: "プライム上場で女性役員0は政府方針上の解消対象。2025年中に最低1名選任を計画。",
    });
  }

  return findings;
}

/** PB1割れ対策 (東証 R5.3要請: 「資本コストや株価を意識した経営」) */
export function checkPbrCapitalEfficiency(p: CompanyProfile): CgFinding[] {
  const findings: CgFinding[] = [];
  if (p.listing_tier !== "prime" && p.listing_tier !== "standard") return findings;

  if (p.pb_ratio < 1.0) {
    findings.push({
      rule: "東証要請 R5.3 (PB1割れ対策)",
      severity: "warning",
      hint: `PBR ${p.pb_ratio.toFixed(2)} (1割れ)。東証要請に基づき「現状分析」「方針・目標」「具体的取組」「進捗状況」を CG報告書 + IR資料 で開示すべき。ROE改善 + 政策保有株縮減 + 自己株取得 + 配当性向UP の組合せが標準処方。`,
    });
  }

  if (p.roe_3y_avg < 8.0) {
    findings.push({
      rule: "伊藤レポート (ROE 8% 目標)",
      severity: "advice",
      hint: `直近3期平均ROE ${p.roe_3y_avg.toFixed(1)}%。「伊藤レポート」が示す資本コストを上回る ROE 8% 以上が国際的な投資家期待値。中期計画で達成パスを示す。`,
    });
  }

  return findings;
}

/** 政策保有株式の縮減 (CGC原則1-4 + 東証 R5.3要請) */
export function checkCrossHoldings(p: CompanyProfile): CgFinding[] {
  const findings: CgFinding[] = [];
  if (p.cross_holdings_book_value_ratio > 20) {
    findings.push({
      rule: "CGC 原則1-4 (政策保有株式)",
      principle: "原則1-4",
      severity: "warning",
      hint: `政策保有株/純資産比 ${p.cross_holdings_book_value_ratio.toFixed(1)}% > 20%。経済合理性検証 + 縮減方針 + 議決権行使基準 を CG報告書で開示すべき。R5.3東証要請で削減プレッシャー強。`,
    });
  } else if (p.cross_holdings_book_value_ratio > 10) {
    findings.push({
      rule: "CGC 原則1-4 (政策保有株式)",
      principle: "原則1-4",
      severity: "advice",
      hint: "政策保有株比率10〜20%。中期で半減目標を立てる企業が増加 (例: 三菱UFJ/トヨタが減らした)。",
    });
  }
  return findings;
}

/** 統合チェック関数 */
export function auditCorporateGovernance(p: CompanyProfile): CgFinding[] {
  return [
    ...checkBoardStructure(p),
    ...checkDiversity(p),
    ...checkPbrCapitalEfficiency(p),
    ...checkCrossHoldings(p),
  ];
}

/** スキルマトリクス (CGC補充原則4-11①) */
export interface SkillMatrixRow {
  director_name: string;
  is_independent: boolean;
  skills: {
    management: boolean; // 経営
    finance: boolean; // 財務会計
    legal_compliance: boolean; // 法務コンプライアンス
    international: boolean; // 国際性
    industry: boolean; // 業界経験
    technology: boolean; // 技術 IT
    esg_sustainability: boolean; // ESG
    hr_diversity: boolean; // 人事 多様性
  };
}

export function validateSkillMatrix(rows: SkillMatrixRow[]): CgFinding[] {
  const findings: CgFinding[] = [];
  const skillKeys = Object.keys(rows[0]?.skills ?? {}) as (keyof SkillMatrixRow["skills"])[];

  // 各スキル領域に最低1人いるか (CGC補充原則4-11①)
  for (const k of skillKeys) {
    const count = rows.filter((r) => r.skills[k]).length;
    if (count === 0) {
      findings.push({
        rule: `CGC 補充原則4-11① (スキルマトリクス) - ${k}`,
        principle: "原則4-11",
        severity: "warning",
        hint: `「${k}」のスキルを保有する取締役が不在。当該スキルが取締役会に必要な理由 or 不要な理由を CG報告書で説明。`,
      });
    }
  }

  // 監査機能 (財務会計+法務) を持つ独立社外がいるか
  const hasIndependentAuditCapable = rows.some(
    (r) => r.is_independent && (r.skills.finance || r.skills.legal_compliance),
  );
  if (!hasIndependentAuditCapable) {
    findings.push({
      rule: "CGC 補充原則4-11① (監査スキル)",
      principle: "原則4-11",
      severity: "warning",
      hint: "財務会計 or 法務スキルを持つ独立社外取締役が不在。監査機能の実効性に懸念。",
    });
  }

  return findings;
}

/** Stewardship Code R7.4改訂 8原則対応 (機関投資家側) */
export type StewardshipPrinciple =
  | "scope_definition" // 1: スチュワードシップ責任の方針
  | "conflict_of_interest" // 2: 利益相反管理
  | "investee_monitoring" // 3: 投資先のモニタリング
  | "engagement" // 4: 建設的エンゲージメント
  | "voting_disclosure" // 5: 議決権行使方針 + 個別開示
  | "regular_report" // 6: 顧客・受益者への定期報告
  | "skill_capability" // 7: 実力 (人材育成)
  | "sustainability"; // 8: サステナビリティ (R2追加)

export interface StewardshipPolicy {
  signed: boolean;
  reviewed_at?: string;
  principles_complied: StewardshipPrinciple[];
}

export function checkStewardshipCompliance(s: StewardshipPolicy): CgFinding[] {
  const findings: CgFinding[] = [];
  const required: StewardshipPrinciple[] = [
    "scope_definition",
    "conflict_of_interest",
    "investee_monitoring",
    "engagement",
    "voting_disclosure",
    "regular_report",
    "skill_capability",
    "sustainability",
  ];
  const missing = required.filter((p) => !s.principles_complied.includes(p));
  if (s.signed && missing.length > 0) {
    findings.push({
      rule: "Stewardship Code R7.4改訂",
      severity: "advice",
      hint: `Stewardship Code 受入機関は8原則すべての遵守 or 説明が必要。未遵守: ${missing.join(", ")}`,
    });
  }
  return findings;
}

export function buildCgReportTemplate(p: CompanyProfile): string {
  const ind = p.independent_directors;
  const tier = p.listing_tier;
  return `# ${p.company_name} コーポレートガバナンス報告書

## I. コーポレートガバナンスに関する基本的な考え方
- 当社は CGC (2024改訂) の各原則を真摯に受け止め、Comply or Explain で対応する。

## II. 機関設計
- 機関形態: ${
    p.board_structure === "kansayaku"
      ? "監査役会設置会社"
      : p.board_structure === "audit_committee"
        ? "監査等委員会設置会社"
        : "指名委員会等設置会社"
  }
- 取締役: ${p.total_directors} 名 (うち社外 ${p.outside_directors}, 独立社外 ${ind})
- 上場区分: ${tier}

## III. 政策保有株式
- 純資産比: ${p.cross_holdings_book_value_ratio.toFixed(1)}%
- 縮減方針: 経済合理性が確認できないものから順次売却

## IV. 資本コスト・株価意識経営 (東証R5.3要請)
- PBR: ${p.pb_ratio.toFixed(2)}
- ROE 3年平均: ${p.roe_3y_avg.toFixed(1)}%
${
  p.pb_ratio < 1.0
    ? "- PB1割れ対策: ROE改善 + 政策保有株縮減 + 自己株取得 + 配当性向UP を中期計画で実行"
    : "- 継続して資本効率の維持向上を図る"
}

## V. ジェンダー多様性
- 女性役員: ${p.female_directors} 名 (${((p.female_directors / Math.max(1, p.total_directors)) * 100).toFixed(1)}%)
- 2030年までに女性役員30%以上を目指す (R7.4政府方針)
`;
}
