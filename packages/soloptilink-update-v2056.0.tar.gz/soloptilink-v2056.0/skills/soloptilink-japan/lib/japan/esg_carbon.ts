/**
 * SoloptiLinkAI Phase 22 — ESG / カーボンアカウンティング
 *
 * 日本における ESG 開示・温室効果ガス算定・サステナビリティ報告の要件:
 *  - TCFD (Task Force on Climate-related Financial Disclosures): プライム市場上場企業に開示必須 (2022年4月)
 *  - SSBJ (サステナビリティ基準委員会): IFRS S1/S2 を日本基準化 (2025年3月策定)
 *  - GHG プロトコル Scope 1/2/3
 *  - 温対法 (温室効果ガス算定報告公表制度): 特定排出者 (CO2換算3000t/年以上) は報告義務
 *  - 省エネ法: 特定事業者 (1500kL/年以上) は報告義務
 *  - GRI Standards (Global Reporting Initiative)
 *  - SASB (業種別開示基準)
 */

export type GhgScope = "scope1" | "scope2" | "scope3";

export interface EmissionRecord {
  source: string; // ガソリン使用/電力購入/出張等
  scope: GhgScope;
  scope3_category?: number; // Scope 3 の場合 1〜15
  activity_amount: number;
  unit: "L" | "kWh" | "Nm3" | "GJ" | "kg" | "km" | "yen" | "person";
  emission_factor: number; // tCO2e/unit
  emission_tco2e: number; // = activity_amount * emission_factor
  ts: string;
}

// Scope 1: 燃料燃焼/工程排出
// Scope 2: 購入電力/熱の間接排出
// Scope 3: その他間接排出 (15カテゴリ)
export const SCOPE3_CATEGORIES = [
  { id: 1, name: "購入した製品・サービス" },
  { id: 2, name: "資本財" },
  { id: 3, name: "Scope 1,2 に含まれない燃料及びエネルギー関連活動" },
  { id: 4, name: "輸送 / 配送 (上流)" },
  { id: 5, name: "事業から出る廃棄物" },
  { id: 6, name: "出張" },
  { id: 7, name: "雇用者の通勤" },
  { id: 8, name: "リース資産 (上流)" },
  { id: 9, name: "輸送 / 配送 (下流)" },
  { id: 10, name: "販売した製品の加工" },
  { id: 11, name: "販売した製品の使用" },
  { id: 12, name: "販売した製品の廃棄" },
  { id: 13, name: "リース資産 (下流)" },
  { id: 14, name: "フランチャイズ" },
  { id: 15, name: "投資" },
] as const;

// 環境省 排出係数 (代表的なもの 2024年度版)
export const STANDARD_EMISSION_FACTORS: Record<string, { unit: string; factor: number; source: string }> = {
  gasoline: { unit: "L", factor: 0.00232, source: "環境省 算定省令 別表第1" }, // tCO2/L
  diesel: { unit: "L", factor: 0.00258, source: "環境省 算定省令 別表第1" },
  city_gas_13a: { unit: "Nm3", factor: 0.00224, source: "環境省 算定省令" },
  electricity_jp_avg: { unit: "kWh", factor: 0.000434, source: "環境省 R6 全国平均 調整後" }, // 0.434 kg-CO2/kWh
  electricity_renewable: { unit: "kWh", factor: 0, source: "再エネ100%電源" },
  business_trip_jr: { unit: "km", factor: 0.0000186, source: "JR東日本 旅客原単位" },
  business_trip_air_domestic: { unit: "km", factor: 0.000098, source: "国交省 旅客原単位" },
  business_trip_taxi: { unit: "km", factor: 0.000130, source: "環境省" },
};

export function calcEmission(activity: number, factorKey: keyof typeof STANDARD_EMISSION_FACTORS): number {
  const f = STANDARD_EMISSION_FACTORS[factorKey];
  if (!f) throw new Error(`unknown factor: ${factorKey}`);
  return activity * f.factor;
}

export interface ScopeAggregation {
  scope1_tco2e: number;
  scope2_tco2e: number;
  scope3_tco2e: number;
  scope3_by_category: Record<number, number>;
  total_tco2e: number;
}

export function aggregateByScope(records: EmissionRecord[]): ScopeAggregation {
  const out: ScopeAggregation = {
    scope1_tco2e: 0,
    scope2_tco2e: 0,
    scope3_tco2e: 0,
    scope3_by_category: {},
    total_tco2e: 0,
  };
  for (const r of records) {
    if (r.scope === "scope1") out.scope1_tco2e += r.emission_tco2e;
    if (r.scope === "scope2") out.scope2_tco2e += r.emission_tco2e;
    if (r.scope === "scope3") {
      out.scope3_tco2e += r.emission_tco2e;
      const cat = r.scope3_category ?? 0;
      out.scope3_by_category[cat] = (out.scope3_by_category[cat] ?? 0) + r.emission_tco2e;
    }
  }
  out.total_tco2e = out.scope1_tco2e + out.scope2_tco2e + out.scope3_tco2e;
  return out;
}

// 温対法: 特定排出者 = CO2換算3000t/年以上 → 報告義務
const ONDANKA_REPORTING_THRESHOLD_TCO2 = 3_000;
// 省エネ法: 特定事業者 = エネルギー使用量1500kL原油換算/年以上 → 報告義務
const SAVING_ENERGY_THRESHOLD_KL = 1_500;

export interface RegulatoryReporting {
  must_report_under_ondanka: boolean;
  must_report_under_saving_energy: boolean;
  reasons: string[];
}

export function evaluateReportingObligation(input: {
  total_co2_tco2e: number;
  total_energy_kl_oil_equivalent: number;
}): RegulatoryReporting {
  const reasons: string[] = [];
  const ondanka = input.total_co2_tco2e >= ONDANKA_REPORTING_THRESHOLD_TCO2;
  const saving = input.total_energy_kl_oil_equivalent >= SAVING_ENERGY_THRESHOLD_KL;
  if (ondanka) reasons.push(`温対法: CO2換算 ${input.total_co2_tco2e.toFixed(1)} t/年 ≥ 3,000 t → 特定排出者として翌年7月末までに報告`);
  if (saving) reasons.push(`省エネ法: エネルギー使用量 ${input.total_energy_kl_oil_equivalent.toFixed(0)} kL ≥ 1,500 kL → 特定事業者として中長期計画書/定期報告書を提出`);
  if (!ondanka && !saving) reasons.push("温対法/省エネ法の報告閾値未満 (任意開示は推奨)");
  return { must_report_under_ondanka: ondanka, must_report_under_saving_energy: saving, reasons };
}

// TCFD 4本柱
export const TCFD_PILLARS = [
  "ガバナンス",
  "戦略",
  "リスク管理",
  "指標と目標",
] as const;

export interface TcfdDisclosure {
  governance: string[];
  strategy: string[];
  risk_management: string[];
  metrics_targets: { name: string; unit: string; target: number; baseline_year: number; target_year: number }[];
}

export interface TcfdReadiness {
  pillar: typeof TCFD_PILLARS[number];
  status: "ok" | "partial" | "missing";
  hint: string;
}

export function checkTcfdReadiness(d: TcfdDisclosure): TcfdReadiness[] {
  return [
    {
      pillar: "ガバナンス",
      status: d.governance.length === 0 ? "missing" : d.governance.length < 2 ? "partial" : "ok",
      hint: "気候関連リスク/機会に対する取締役会の監視と経営者の役割を最低2項目以上明示",
    },
    {
      pillar: "戦略",
      status: d.strategy.length === 0 ? "missing" : d.strategy.length < 3 ? "partial" : "ok",
      hint: "短期/中期/長期の3シナリオ (1.5℃ / 2℃ / 4℃) でリスク機会を分析",
    },
    {
      pillar: "リスク管理",
      status: d.risk_management.length === 0 ? "missing" : d.risk_management.length < 2 ? "partial" : "ok",
      hint: "気候リスクの識別/評価/管理プロセスと、全社リスク管理への統合を記述",
    },
    {
      pillar: "指標と目標",
      status: d.metrics_targets.length === 0 ? "missing" : d.metrics_targets.length < 2 ? "partial" : "ok",
      hint: "Scope 1/2 排出量と削減目標 (例: 2030年▲46% vs 2013年) を必ず開示",
    },
  ];
}

// 削減目標達成率
export interface ReductionTarget {
  baseline_year: number;
  baseline_tco2e: number;
  target_year: number;
  target_reduction_rate: number; // 0-1 (例: 0.46 = ▲46%)
}

export function calcReductionProgress(target: ReductionTarget, currentTotalTco2e: number, currentYear: number): {
  expected_reduction_tco2e: number;
  achieved_reduction_tco2e: number;
  achievement_rate: number; // 0-1
  on_track: boolean;
} {
  const expectedFinal = target.baseline_tco2e * (1 - target.target_reduction_rate);
  const totalYears = target.target_year - target.baseline_year;
  const elapsed = currentYear - target.baseline_year;
  const linearTarget = target.baseline_tco2e - (target.baseline_tco2e - expectedFinal) * (elapsed / totalYears);
  const actualReduction = target.baseline_tco2e - currentTotalTco2e;
  const expectedReduction = target.baseline_tco2e - linearTarget;
  return {
    expected_reduction_tco2e: Math.max(0, expectedReduction),
    achieved_reduction_tco2e: Math.max(0, actualReduction),
    achievement_rate: expectedReduction > 0 ? actualReduction / expectedReduction : 0,
    on_track: actualReduction >= expectedReduction,
  };
}

export function buildSustainabilityReportSkeleton(orgName: string, fy: number): string {
  return `# ${orgName} サステナビリティレポート FY${fy}

## 1. CEO メッセージ

## 2. ESG ガバナンス
- 取締役会のサステナビリティ監視体制
- サステナビリティ委員会の構成

## 3. 環境 (E)
### 3.1 TCFD 開示
- ガバナンス / 戦略 / リスク管理 / 指標と目標
### 3.2 GHG 排出量
- Scope 1 / Scope 2 / Scope 3 (15カテゴリ)
### 3.3 削減目標と進捗
### 3.4 環境法令対応 (温対法/省エネ法/フロン排出抑制法/廃棄物処理法)

## 4. 社会 (S)
- 人権/労働慣行/D&I/社会貢献

## 5. ガバナンス (G)
- 取締役会構成/独立性
- 内部統制/コンプライアンス
- リスク管理

## 6. 第三者保証
- 限定的保証 / 合理的保証 (ISAE 3000 / ISAE 3410)

## 7. データ集
- TCFD 推奨開示項目との対照表
- GRI Content Index
- SASB Index
`;
}
