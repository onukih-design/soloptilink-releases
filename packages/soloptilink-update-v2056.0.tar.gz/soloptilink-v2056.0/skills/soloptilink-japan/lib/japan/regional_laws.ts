/**
 * regional_laws.ts — 全国47都道府県 + 主要市町村の地域条例ルーター (Phase 9)
 *
 * 国法 (建築基準法 / 建築士法 / 都市計画法 / 屋外広告物法) の上に各都道府県・
 * 市町村が上乗せしている条例/要綱を索引化し、プロジェクトの所在地から
 * 関連条例を自動で引き出す。
 *
 * 使い方:
 *   import { getPrefectureLaws, resolveApplicableOrdinances, checkLocationCompliance } from '@/lib/japan/regional_laws';
 *   import prefectures from '@/../regions/47prefectures/index.json';
 *   const laws = getPrefectureLaws(prefectures, '京都府');
 *   const check = checkLocationCompliance({
 *     db: prefectures,
 *     prefecture: '京都府', city: '京都市',
 *     proposedHeightM: 31, proposedColors: ['#FF6600'],
 *     siteCategory: 'historic_district',
 *   });
 */

export interface PrefectureEntry {
  code: string;
  name_ja: string;
  name_en: string;
  capital: string;
  key_ordinances: string[];
  climate_region: number;    // 省エネ 地域区分 1-8
  snow_load_kN_m2: number;
  notes?: string;
}

export interface PrefectureDb {
  schema_version: string;
  source: string;
  note?: string;
  prefectures: PrefectureEntry[];
}

// =============================================================================
// 基本ルックアップ
// =============================================================================

export function getPrefectureByName(db: PrefectureDb, name: string): PrefectureEntry | null {
  return db.prefectures.find(p => p.name_ja === name || p.name_en.toLowerCase() === name.toLowerCase()) ?? null;
}

export function getPrefectureByCode(db: PrefectureDb, code: string): PrefectureEntry | null {
  const c = code.padStart(2, '0');
  return db.prefectures.find(p => p.code === c) ?? null;
}

export function getPrefectureLaws(db: PrefectureDb, nameOrCode: string): string[] {
  const p = /^\d+$/.test(nameOrCode) ? getPrefectureByCode(db, nameOrCode) : getPrefectureByName(db, nameOrCode);
  return p?.key_ordinances ?? [];
}

// =============================================================================
// 主要市町村レベルの追加規制 (手動整備)
// =============================================================================

export interface CityOrdinance {
  city: string;
  prefecture: string;
  ordinances: string[];
  notes?: string;
}

export const MAJOR_CITY_ORDINANCES: ReadonlyArray<CityOrdinance> = Object.freeze([
  // 東京都特別区 (景観色彩規制)
  { city: '千代田区', prefecture: '東京都', ordinances: ['千代田区景観まちづくり条例', '千代田区屋外広告物条例'], notes: '丸の内は眺望景観重要地区' },
  { city: '中央区', prefecture: '東京都', ordinances: ['中央区景観計画', '中央区中高層建築物条例'], notes: '銀座は色彩規制厳格' },
  { city: '港区', prefecture: '東京都', ordinances: ['港区景観計画', '港区ワンルームマンション条例'], notes: '青山/表参道は景観規制' },
  { city: '渋谷区', prefecture: '東京都', ordinances: ['渋谷区景観計画', '渋谷区中高層建築物紛争予防条例'] },
  { city: '世田谷区', prefecture: '東京都', ordinances: ['世田谷区街づくり条例', '世田谷区地区計画'] },
  // 京都市: 日本一厳格
  { city: '京都市', prefecture: '京都府', ordinances: [
    '京都市市街地景観整備条例',
    '京都市屋外広告物条例',
    '京都市眺望景観創生条例',
    '京都市歴史都市景観創生条例',
    '京都市建築物高さの最高限度指定',
    '京都市伝統的建造物群保存地区条例(産寧坂/祇園新橋/上賀茂/嵯峨鳥居本)',
  ], notes: '屋上看板禁止/点滅禁止/赤・紫色の高彩度禁止/瓦葺き指定区域あり' },
  // 金沢市
  { city: '金沢市', prefecture: '石川県', ordinances: [
    '金沢市景観条例',
    '金沢市伝統環境保全条例',
    '金沢市旧町名復活推進条例',
    '金沢市屋外広告物条例',
  ], notes: '茶屋街は色彩/高さ厳格' },
  // 鎌倉市
  { city: '鎌倉市', prefecture: '神奈川県', ordinances: [
    '鎌倉市景観計画',
    '古都における歴史的風土の保存に関する特別措置法(古都保存法)',
    '鎌倉市屋外広告物条例',
  ], notes: '歴史的風土特別保存地区は建築制限厳格' },
  // 奈良市
  { city: '奈良市', prefecture: '奈良県', ordinances: [
    '奈良市景観計画',
    '古都保存法',
    '奈良市屋外広告物条例',
  ] },
  // 軽井沢
  { city: '軽井沢町', prefecture: '長野県', ordinances: [
    '軽井沢町自然保護対策要綱',
    '軽井沢町景観育成条例',
  ], notes: '別荘地は建ぺい率20%/高さ10m厳格/色彩 3色以内' },
  // 富士山周辺
  { city: '富士河口湖町', prefecture: '山梨県', ordinances: [
    '富士河口湖町景観計画',
    '富士山世界遺産緩衝地帯ガイドライン',
  ] },
  // 白川村
  { city: '白川村', prefecture: '岐阜県', ordinances: [
    '白川村伝統的建造物群保存地区条例(合掌造り集落)',
    '白川村景観条例',
  ], notes: '合掌造り地区は外観改変禁止' },
  // 倉敷市
  { city: '倉敷市', prefecture: '岡山県', ordinances: [
    '倉敷市美観地区景観条例',
    '倉敷市屋外広告物条例',
  ], notes: '美観地区は瓦葺き/白漆喰指定' },
  // 神戸市
  { city: '神戸市', prefecture: '兵庫県', ordinances: [
    '神戸市都市景観条例',
    '神戸市人と自然との共生ゾーンの指定等に関する条例',
    '神戸市北野町山本通伝建地区条例',
  ] },
  // 沖縄
  { city: '那覇市', prefecture: '沖縄県', ordinances: [
    '那覇市景観計画',
    '那覇市屋外広告物条例',
    '米軍進入表面規制(航空法)',
  ], notes: '米軍基地進入表面によりエリア別高さ規制' },
  // 札幌
  { city: '札幌市', prefecture: '北海道', ordinances: [
    '札幌市都市景観条例',
    '札幌市屋外広告物条例',
  ], notes: '積雪荷重考慮/歩道屋根規制' },
  // 横浜市
  { city: '横浜市', prefecture: '神奈川県', ordinances: [
    '横浜市景観ビジョン',
    '横浜市歴史を生かしたまちづくり要綱',
    '横浜市中高層建築物の建築に係る紛争の予防と調整等に関する条例',
  ] },
  // 名古屋
  { city: '名古屋市', prefecture: '愛知県', ordinances: [
    '名古屋市都市景観条例',
    '名古屋市中高層建築物の建築に関する指導要綱',
    '名古屋市屋外広告物条例',
  ] },
  // 福岡
  { city: '福岡市', prefecture: '福岡県', ordinances: [
    '福岡市都市景観条例',
    '福岡市屋外広告物条例',
    '福岡市建築基準法施行条例',
  ] },
  // 大阪
  { city: '大阪市', prefecture: '大阪府', ordinances: [
    '大阪市都市景観条例',
    '大阪市屋外広告物条例',
    '大阪市中高層建築物の建築に係る紛争の予防と調整に関する条例',
  ] },
]);

export function getCityOrdinances(city: string, prefecture?: string): CityOrdinance | null {
  const hit = MAJOR_CITY_ORDINANCES.find(c =>
    c.city === city && (!prefecture || c.prefecture === prefecture),
  );
  return hit ?? null;
}

// =============================================================================
// 条例分類 & プロジェクト適用条例の解決
// =============================================================================

export type OrdinanceCategory =
  | 'building_standard_extension' // 建築基準法施行条例 (上乗せ)
  | 'landscape'                   // 景観条例
  | 'outdoor_advertisement'        // 屋外広告物条例
  | 'environment'                  // 環境影響評価条例
  | 'midrise'                      // 中高層建築物紛争予防条例
  | 'historical_preservation'      // 伝建地区/古都保存
  | 'snow_load'                    // 積雪荷重条例 (寒冷地)
  | 'wind_load'                    // 強風対策 (台風常襲)
  | 'volcanic_ash'                 // 火山灰対策 (桜島等)
  | 'military_clearance'           // 米軍進入表面規制
  | 'color_restriction'            // 色彩規制
  | 'tsunami'                      // 津波対策
  | 'other';

export function categorizeOrdinance(name: string): OrdinanceCategory {
  if (name.includes('建築基準法施行条例')) return 'building_standard_extension';
  if (name.includes('景観')) return 'landscape';
  if (name.includes('屋外広告物')) return 'outdoor_advertisement';
  if (name.includes('環境影響評価')) return 'environment';
  if (name.includes('中高層')) return 'midrise';
  if (name.includes('伝建') || name.includes('古都保存') || name.includes('歴史')) return 'historical_preservation';
  if (name.includes('積雪') || name.includes('寒冷')) return 'snow_load';
  if (name.includes('台風') || name.includes('強風')) return 'wind_load';
  if (name.includes('火山灰')) return 'volcanic_ash';
  if (name.includes('米軍') || name.includes('進入表面')) return 'military_clearance';
  if (name.includes('色彩')) return 'color_restriction';
  if (name.includes('津波')) return 'tsunami';
  return 'other';
}

export interface ApplicableOrdinances {
  prefecture: string | null;
  city: string | null;
  prefecture_ordinances: string[];
  city_ordinances: string[];
  categorized: Partial<Record<OrdinanceCategory, string[]>>;
  climate_region: number | null;
  snow_load_kN_m2: number | null;
}

export function resolveApplicableOrdinances(opts: {
  db: PrefectureDb;
  prefecture: string;
  city?: string;
}): ApplicableOrdinances {
  const p = getPrefectureByName(opts.db, opts.prefecture);
  const c = opts.city ? getCityOrdinances(opts.city, p?.name_ja) : null;
  const all: string[] = [...(p?.key_ordinances ?? []), ...(c?.ordinances ?? [])];
  const categorized: Partial<Record<OrdinanceCategory, string[]>> = {};
  for (const n of all) {
    const cat = categorizeOrdinance(n);
    (categorized[cat] ??= []).push(n);
  }
  return {
    prefecture: p?.name_ja ?? null,
    city: c?.city ?? null,
    prefecture_ordinances: p?.key_ordinances ?? [],
    city_ordinances: c?.ordinances ?? [],
    categorized,
    climate_region: p?.climate_region ?? null,
    snow_load_kN_m2: p?.snow_load_kN_m2 ?? null,
  };
}

// =============================================================================
// 所在地から設計への影響をチェック
// =============================================================================

export type SiteCategory = 'general' | 'historic_district' | 'landscape_zone' | 'world_heritage_buffer' | 'specific_height_limit';

export interface LocationComplianceInput {
  db: PrefectureDb;
  prefecture: string;
  city?: string;
  proposedHeightM: number;
  proposedColors?: string[]; // HEX カラー一覧
  siteCategory?: SiteCategory;
  hasSignage?: boolean;
  roofFinish?: 'japanese_tile' | 'metal' | 'other';
}

export interface ComplianceWarning {
  severity: 'info' | 'warn' | 'error';
  ordinance: string;
  message: string;
}

export interface LocationComplianceResult {
  applicable: ApplicableOrdinances;
  warnings: ComplianceWarning[];
  mustDo: string[];
  shouldDo: string[];
}

/** HEX の彩度を計算 (0..100) */
function hexToSaturation(hex: string): number {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex);
  if (!m) return 0;
  const r = parseInt(m[1].slice(0, 2), 16) / 255;
  const g = parseInt(m[1].slice(2, 4), 16) / 255;
  const b = parseInt(m[1].slice(4, 6), 16) / 255;
  const max = Math.max(r, g, b), min = Math.min(r, g, b);
  if (max === 0) return 0;
  return ((max - min) / max) * 100;
}

export function checkLocationCompliance(input: LocationComplianceInput): LocationComplianceResult {
  const applicable = resolveApplicableOrdinances({ db: input.db, prefecture: input.prefecture, city: input.city });
  const warnings: ComplianceWarning[] = [];
  const mustDo: string[] = [];
  const shouldDo: string[] = [];

  // 京都市 / 奈良市 / 軽井沢 / 伝建地区: 高さと色彩
  const isRestricted =
    input.city === '京都市' ||
    input.city === '奈良市' ||
    input.city === '軽井沢町' ||
    input.city === '白川村' ||
    input.city === '鎌倉市' ||
    input.city === '倉敷市' ||
    input.siteCategory === 'historic_district' ||
    input.siteCategory === 'world_heritage_buffer';

  if (isRestricted) {
    if (input.proposedHeightM > 15) {
      warnings.push({
        severity: 'error',
        ordinance: applicable.city_ordinances.find(n => n.includes('景観') || n.includes('伝建')) ?? '景観条例',
        message: `歴史的景観地区/伝建地区で高さ ${input.proposedHeightM}m は超過の可能性大(15m基準)。事前に市と個別協議必須`,
      });
      mustDo.push('景観審議会への付議/事前協議');
    }
    // 色彩: 高彩度 NG
    for (const c of input.proposedColors ?? []) {
      const s = hexToSaturation(c);
      if (s > 50) {
        warnings.push({
          severity: 'warn',
          ordinance: '色彩規制ガイドライン',
          message: `色 ${c} は彩度 ${s.toFixed(0)}% で高め。地域の彩度基準(一般 20-40%)に適合するか確認`,
        });
      }
    }
    if (input.roofFinish !== 'japanese_tile' && (input.city === '京都市' || input.city === '倉敷市')) {
      shouldDo.push('瓦葺きまたは瓦風金属屋根の採用を景観条例として強く推奨');
    }
  }

  // 屋外広告物条例 - 看板がある場合
  if (input.hasSignage && applicable.categorized.outdoor_advertisement?.length) {
    mustDo.push(`屋外広告物許可申請: ${applicable.categorized.outdoor_advertisement.join(' / ')}`);
    if (input.city === '京都市') {
      warnings.push({
        severity: 'warn',
        ordinance: '京都市屋外広告物条例',
        message: '屋上看板禁止/点滅禁止/赤・紫色の高彩度禁止。看板設計は条例対応必須',
      });
    }
  }

  // 沖縄: 米軍進入表面
  if (input.prefecture === '沖縄県' && input.proposedHeightM > 20) {
    warnings.push({
      severity: 'warn',
      ordinance: '米軍進入表面規制 (航空法関連)',
      message: '沖縄は基地周辺で進入表面により高さ制限あり。国交省・防衛省協議確認必須',
    });
    mustDo.push('航空法・防衛省との高さ事前確認');
  }

  // 豪雪地域
  if (applicable.snow_load_kN_m2 && applicable.snow_load_kN_m2 >= 2.0) {
    mustDo.push(`多雪区域: 積雪荷重 ${applicable.snow_load_kN_m2} kN/㎡ 以上で構造計算`);
  }

  // 震災リスク (南海トラフ/東海地震)
  const tsunamiRisk = ['宮城県', '高知県', '静岡県', '和歌山県', '三重県'];
  if (tsunamiRisk.includes(input.prefecture)) {
    shouldDo.push('津波避難経路・津波避難ビル指定の確認 / 1F ピロティ化・2F以上の避難階設計');
  }

  // 中高層建築物条例 (都市部 3階以上)
  if (input.proposedHeightM >= 10 && applicable.categorized.midrise?.length) {
    mustDo.push(`中高層建築物条例: 近隣説明会開催 + 標識設置が必要 (${applicable.categorized.midrise.join(' / ')})`);
  }

  return { applicable, warnings, mustDo, shouldDo };
}

// =============================================================================
// 省エネ地域区分から基準UA値を返す
// =============================================================================

export function getClimateRegionUAThreshold(region: number): { region: number; ua_max: number; etaAC_max: number } | null {
  const table = [
    { region: 1, ua_max: 0.46, etaAC_max: Infinity },
    { region: 2, ua_max: 0.46, etaAC_max: Infinity },
    { region: 3, ua_max: 0.56, etaAC_max: Infinity },
    { region: 4, ua_max: 0.75, etaAC_max: Infinity },
    { region: 5, ua_max: 0.87, etaAC_max: 3.0 },
    { region: 6, ua_max: 0.87, etaAC_max: 2.8 },
    { region: 7, ua_max: 0.87, etaAC_max: 2.7 },
    { region: 8, ua_max: Infinity, etaAC_max: 6.7 },
  ];
  return table.find(t => t.region === region) ?? null;
}
