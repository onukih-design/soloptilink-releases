/**
 * SoloptiLinkAI Phase 45 — ステマ規制対応
 *
 * 不当景品類及び不当表示防止法 (景表法) 第5条第3号告示
 * 通称: ステルスマーケティング規制 / ステマ規制
 *
 * - 告示: 内閣府告示第19号 (R5.3.28) 「一般消費者が事業者の表示であることを判別することが困難である表示」
 * - 施行: 2023-10-01 (R5.10.1)
 * - 運用基準: 消費者庁長官 R5.3.28 公表
 * - 措置命令: 法第7条 / 違反主体は広告主のみ (インフルエンサー本人は対象外)
 * - 課徴金: 法第8条 3% / ただし指定告示は対象外
 * - 業界自主ルール: WOMJガイドライン / JIAA / IAB Japan / JAO
 *
 * SoT:
 *  - https://www.caa.go.jp/policies/policy/representation/fair_labeling/stealth_marketing
 *  - https://www.caa.go.jp/policies/policy/representation/fair_labeling/faq/stealth_marketing/
 */

export const STEALTH_REGULATION_VERSION = "R5.10.1";
export const STEALTH_REGULATION_EFFECTIVE = "2023-10-01";
export const STEALTH_REGULATION_LAW = "景品表示法 第5条第3号 (内閣府告示第19号)";

export const VIOLATION_TYPES = [
  "EMPLOYEE_NO_DISCLOSURE",
  "PAID_THIRD_PARTY",
  "AFFILIATE_NO_DISCLOSURE",
  "REVERSE_STEMA",
  "GIFTING_INVOLVED",
  "EC_REVIEW_PAID",
  "TIE_UP_NO_LABEL",
  "MONITOR_NO_DISCLOSURE",
  "INFLUENCER_NO_PR",
  "EMPLOYEE_PERSONAL_ACCOUNT",
  "GROUP_COMPANY_NO_DISCLOSURE",
  "BROKER_REQUEST",
  "COMPETITOR_LOW_REVIEW",
  "VIDEO_NO_OPENING_LABEL",
  "ARTICLE_AD_NO_LABEL",
  "FAKE_USER_REVIEW",
] as const;
export type ViolationType = (typeof VIOLATION_TYPES)[number];

export const VALID_PR_LABELS = [
  "PR",
  "広告",
  "提供",
  "プロモーション",
  "タイアップ",
  "#PR",
  "#広告",
  "#提供",
  "#プロモーション",
  "#タイアップ",
  "Sponsored",
  "Sponsored by",
  "[広告]",
  "［PR］",
] as const;

export const AMBIGUOUS_LABELS = ["アンバサダー", "モニター", "体験", "#ad", "Ambassador", "@brand"] as const;

export const PROHIBITED_PLACEMENTS = [
  "末尾埋もれ",
  "もっと見る以降",
  "極小フォント",
  "ハッシュタグ羅列内",
  "色コントラスト不足",
] as const;

export interface PostInput {
  body: string;
  pr_label?: string;
  pr_label_position?: "head" | "before_more" | "after_more" | "tail" | "in_hashtag_array";
  font_size_relative?: "same" | "smaller" | "tiny";
  contrast_ratio?: number;
  is_video?: boolean;
  video_opening_seconds_label?: boolean;
}

export interface ContractInput {
  has_pr_label_clause: boolean;
  has_compliance_oath: boolean;
  has_secondary_use_scope: boolean;
  has_instruction_history_retention: boolean;
  has_disclosure_obligation: boolean;
}

export interface BusinessRelationInput {
  monetary_compensation: boolean;
  product_provision: boolean;
  post_involvement: boolean;
  pre_approval_required: boolean;
  re_post_required: boolean;
}

export type StealthErrorCode =
  | `LABEL_${ViolationType}`
  | "LABEL_MISSING"
  | "LABEL_AMBIGUOUS"
  | "LABEL_BURIED_IN_TAIL"
  | "LABEL_TINY_FONT"
  | "LABEL_LOW_CONTRAST"
  | "VIDEO_NO_OPENING_DISCLOSURE"
  | "CONTRACT_MISSING_CLAUSE";

export interface Finding {
  code: StealthErrorCode;
  rule: string;
  severity: "info" | "warning" | "violation";
  hint: string;
  reference_url?: string;
}

export const VIOLATION_EXAMPLES_16: Record<ViolationType, string> = {
  EMPLOYEE_NO_DISCLOSURE: "従業員が個人アカウントで自社商品を投稿し関係性を開示しない (運用基準 例1)",
  PAID_THIRD_PARTY: "第三者へ対価提供しSNS投稿させ関係性を開示しない (運用基準 例2)",
  AFFILIATE_NO_DISCLOSURE: "アフィリエイト成果報酬の表示でPR表記なし (運用基準 例3)",
  REVERSE_STEMA: "競合の低評価を第三者へ依頼 (運用基準 例4)",
  GIFTING_INVOLVED: "ギフティングで投稿関与あり関係性未開示 (運用基準 例5)",
  EC_REVIEW_PAID: "ECサイトレビューに対価支払い関係性未開示 (運用基準 例6)",
  TIE_UP_NO_LABEL: "記事広告/タイアップで広告表記なし (運用基準 例7)",
  MONITOR_NO_DISCLOSURE: "モニター投稿で対価あり関係性未開示 (運用基準 例8)",
  INFLUENCER_NO_PR: "インフルエンサー投稿でPR表記なし (運用基準 例9)",
  EMPLOYEE_PERSONAL_ACCOUNT: "従業員が個人を装い投稿 (運用基準 例10)",
  GROUP_COMPANY_NO_DISCLOSURE: "子会社・代理店投稿で関係性未開示 (運用基準 例11)",
  BROKER_REQUEST: "ブローカー経由で第三者へ投稿依頼 (運用基準 例12)",
  COMPETITOR_LOW_REVIEW: "競合への低評価投稿を依頼 (運用基準 例13)",
  VIDEO_NO_OPENING_LABEL: "動画広告で冒頭明示なし (運用基準 例14)",
  ARTICLE_AD_NO_LABEL: "記事広告で広告表記なし (運用基準 例15)",
  FAKE_USER_REVIEW: "第三者を装う偽レビュー (運用基準 例16)",
};

const DAY_MS = 24 * 3600 * 1000;
void DAY_MS;

/** PR表記の有効性検証 */
export function validatePRLabel(post: PostInput): { ok: boolean; findings: Finding[] } {
  const findings: Finding[] = [];

  const hasValid = post.pr_label && (VALID_PR_LABELS as readonly string[]).includes(post.pr_label);
  const hasAmbiguous = post.pr_label && (AMBIGUOUS_LABELS as readonly string[]).includes(post.pr_label);

  if (!post.pr_label) {
    findings.push({
      code: "LABEL_MISSING",
      rule: STEALTH_REGULATION_LAW,
      severity: "violation",
      hint: "PR/広告/提供 等のラベルが完全に欠落。一般消費者が事業者の表示と判別できない。",
    });
  } else if (hasAmbiguous && !hasValid) {
    findings.push({
      code: "LABEL_AMBIGUOUS",
      rule: STEALTH_REGULATION_LAW,
      severity: "violation",
      hint: `「${post.pr_label}」は明瞭性に疑義 (運用基準: 一般消費者の認識基準)。「PR」「広告」「提供」等の明確な表記を使用すること。`,
    });
  }

  if (post.pr_label_position === "tail" || post.pr_label_position === "after_more") {
    findings.push({
      code: "LABEL_BURIED_IN_TAIL",
      rule: STEALTH_REGULATION_LAW,
      severity: "violation",
      hint: "PR表記が末尾/「もっと見る」以降に埋もれている。冒頭500文字以内/「もっと見る」前に配置すること。",
    });
  }
  if (post.pr_label_position === "in_hashtag_array") {
    findings.push({
      code: "LABEL_BURIED_IN_TAIL",
      rule: STEALTH_REGULATION_LAW,
      severity: "violation",
      hint: "ハッシュタグ羅列内に埋まっている。単独行 or 本文冒頭に配置すること。",
    });
  }
  if (post.font_size_relative === "tiny" || post.font_size_relative === "smaller") {
    findings.push({
      code: "LABEL_TINY_FONT",
      rule: STEALTH_REGULATION_LAW,
      severity: "warning",
      hint: "PR表記のフォントサイズが本文より小さい。本文と同等以上のサイズで表示すること。",
    });
  }
  if ((post.contrast_ratio ?? 21) < 4.5) {
    findings.push({
      code: "LABEL_LOW_CONTRAST",
      rule: STEALTH_REGULATION_LAW,
      severity: "warning",
      hint: "コントラスト比が WCAG AA (4.5:1) 未満。視認可能な配色で表示すること。",
    });
  }
  if (post.is_video && post.video_opening_seconds_label !== true) {
    findings.push({
      code: "VIDEO_NO_OPENING_DISCLOSURE",
      rule: STEALTH_REGULATION_LAW,
      severity: "violation",
      hint: "動画広告は冒頭5秒以内に明示が必要。概要欄ダブル表示も推奨。",
    });
  }

  return { ok: findings.length === 0, findings };
}

/** 表示主体性: 事業者表示と判定されるか */
export function detectBusinessRelation(b: BusinessRelationInput): { isBusinessDisplay: boolean; reason: string; score: number } {
  const factors = [b.monetary_compensation, b.product_provision, b.post_involvement, b.pre_approval_required, b.re_post_required];
  const score = factors.filter(Boolean).length;
  const isBusinessDisplay = b.post_involvement || b.pre_approval_required || (b.monetary_compensation && b.product_provision);
  return {
    isBusinessDisplay,
    score,
    reason: isBusinessDisplay
      ? "投稿関与/事前承認/対価+商品提供 のいずれか該当 → 事業者表示と判定"
      : "投稿関与なし → 第三者表示と判定 (景表法対象外)",
  };
}

/** インフルエンサー契約書の景表法遵守チェック */
export function validateInfluencerContract(c: ContractInput): { ok: boolean; missing: string[]; findings: Finding[] } {
  const missing: string[] = [];
  if (!c.has_pr_label_clause) missing.push("PR表記義務条項");
  if (!c.has_compliance_oath) missing.push("景表法遵守誓約");
  if (!c.has_secondary_use_scope) missing.push("二次利用範囲");
  if (!c.has_instruction_history_retention) missing.push("指示書履歴保存");
  if (!c.has_disclosure_obligation) missing.push("開示義務条項");

  const findings: Finding[] = missing.map((m) => ({
    code: "CONTRACT_MISSING_CLAUSE" as StealthErrorCode,
    rule: STEALTH_REGULATION_LAW,
    severity: "violation",
    hint: `インフルエンサー契約書に「${m}」が不足。`,
  }));
  return { ok: missing.length === 0, missing, findings };
}

/** 違反事例マッチング (テキスト分析) */
export function classifyViolation(input: { has_disclosure: boolean; relation: BusinessRelationInput; medium: "sns" | "blog" | "ec_review" | "video" | "article" }): ViolationType[] {
  const types: ViolationType[] = [];
  if (input.has_disclosure) return types;

  if (input.relation.post_involvement && input.relation.monetary_compensation) {
    if (input.medium === "ec_review") types.push("EC_REVIEW_PAID");
    if (input.medium === "blog") types.push("AFFILIATE_NO_DISCLOSURE");
    if (input.medium === "sns") types.push("INFLUENCER_NO_PR");
    if (input.medium === "video") types.push("VIDEO_NO_OPENING_LABEL");
    if (input.medium === "article") types.push("ARTICLE_AD_NO_LABEL");
  }
  if (input.relation.product_provision && input.relation.post_involvement) {
    types.push("GIFTING_INVOLVED");
  }
  return types;
}

export function selfCheck(): { ok: boolean; checks: Array<{ name: string; pass: boolean }> } {
  const noLabel = validatePRLabel({ body: "この商品最高！" });
  const validLabel = validatePRLabel({ body: "#PR この商品最高！", pr_label: "#PR", pr_label_position: "head", contrast_ratio: 7 });
  const tailLabel = validatePRLabel({ body: "...省略...", pr_label: "PR", pr_label_position: "tail", contrast_ratio: 7 });
  const videoNoOpen = validatePRLabel({ body: "動画", pr_label: "PR", pr_label_position: "head", contrast_ratio: 7, is_video: true, video_opening_seconds_label: false });

  const checks = [
    { name: "違反16事例定数", pass: VIOLATION_TYPES.length === 16 },
    { name: "PR表記なし → violation", pass: noLabel.ok === false },
    { name: "正規PR表記 → ok", pass: validLabel.ok === true },
    { name: "末尾配置 → violation", pass: tailLabel.findings.some((f) => f.code === "LABEL_BURIED_IN_TAIL") },
    { name: "動画冒頭明示なし → violation", pass: videoNoOpen.findings.some((f) => f.code === "VIDEO_NO_OPENING_DISCLOSURE") },
    {
      name: "投稿関与+対価 → 事業者表示",
      pass: detectBusinessRelation({ monetary_compensation: true, product_provision: true, post_involvement: true, pre_approval_required: false, re_post_required: false }).isBusinessDisplay,
    },
    { name: "施行日定数", pass: STEALTH_REGULATION_EFFECTIVE === "2023-10-01" },
  ];
  return { ok: checks.every((c) => c.pass), checks };
}
