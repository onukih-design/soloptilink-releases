/**
 * SoloptiLinkAI Phase 22 — AI生成物コンプライアンス
 *
 * 日本における生成AI利用・生成物公開に関するコンプライアンス検証:
 *  - 経済産業省/総務省「AI事業者ガイドライン」(2024年4月版)
 *  - 個人情報保護委員会「OpenAI 注意喚起」(2023年6月)
 *  - 文化庁「AIと著作権に関する考え方」(2024年3月)
 *  - 内閣府「広島AIプロセス 国際指針/行動規範」
 *  - EU AI Act 域外適用 (2024年8月発効)
 *  - 公正取引委員会 ステマ規制 (生成コンテンツに関する明示)
 *  - 不正競争防止法 (AI生成物の出所表示)
 */

export type AiUseCase =
  | "text_generation"
  | "image_generation"
  | "code_generation"
  | "decision_making"
  | "personal_data_processing"
  | "biometric"
  | "credit_scoring"
  | "recruitment"
  | "education"
  | "healthcare"
  | "other";

export type RiskLevel = "minimal" | "limited" | "high" | "unacceptable";

// EU AI Act / AI事業者ガイドライン に基づくリスク分類
export const RISK_CLASSIFICATION: Record<AiUseCase, RiskLevel> = {
  text_generation: "limited",
  image_generation: "limited",
  code_generation: "limited",
  decision_making: "high", // 行政手続/雇用/与信判断
  personal_data_processing: "high",
  biometric: "high", // 顔認証/指紋
  credit_scoring: "high",
  recruitment: "high",
  education: "high",
  healthcare: "high",
  other: "minimal",
};

export interface AiSystemProfile {
  system_name: string;
  use_case: AiUseCase;
  llm_provider?: string; // openai / anthropic / google / aws_bedrock / azure_openai
  llm_model?: string; // gpt-4o / claude-opus-4-7 / gemini-2-5
  data_residency?: "jp" | "us" | "eu" | "unknown";
  uses_personal_data: boolean;
  has_human_oversight: boolean; // 人間による最終判断あり
  has_explainability: boolean; // 説明性あり
  has_audit_log: boolean;
  has_user_consent: boolean;
  output_disclosure: "always_visible" | "implicit" | "hidden"; // AI生成である旨の明示
}

export interface ComplianceFinding {
  rule: string;
  severity: "info" | "warning" | "violation";
  hint: string;
}

export function classifyRisk(profile: AiSystemProfile): RiskLevel {
  return RISK_CLASSIFICATION[profile.use_case];
}

export function checkAiSystemCompliance(profile: AiSystemProfile): ComplianceFinding[] {
  const findings: ComplianceFinding[] = [];
  const risk = classifyRisk(profile);

  // 高リスクシステムの最低要件
  if (risk === "high") {
    if (!profile.has_human_oversight) {
      findings.push({
        rule: "AI事業者ガイドライン (高リスク用途の人間関与)",
        severity: "violation",
        hint: "高リスク用途では人間による最終判断 (Human-in-the-loop) が必須。",
      });
    }
    if (!profile.has_explainability) {
      findings.push({
        rule: "AI事業者ガイドライン (透明性/説明可能性)",
        severity: "warning",
        hint: "重要な意思決定への AI 利用は、判断根拠の説明性が求められる。",
      });
    }
    if (!profile.has_audit_log) {
      findings.push({
        rule: "AI事業者ガイドライン (アカウンタビリティ)",
        severity: "violation",
        hint: "高リスク用途では AI 入出力の監査ログが必須 (WORM 保管推奨)。",
      });
    }
  }

  // 個人情報処理
  if (profile.uses_personal_data) {
    if (!profile.has_user_consent) {
      findings.push({
        rule: "個情法 / 個人情報保護委員会 OpenAI 注意喚起 (2023年6月)",
        severity: "violation",
        hint: "AI への個人情報入力は本人同意が必要。要配慮個人情報は明示的同意。",
      });
    }
    if (profile.data_residency === "us" || profile.data_residency === "unknown") {
      findings.push({
        rule: "個情法 第28条 (外国にある第三者への提供)",
        severity: "warning",
        hint: "海外サーバへの送信を伴う場合、本人同意 + 越境移転先の安全管理状況の情報提供義務。",
      });
    }
  }

  // 出力の明示
  if (profile.output_disclosure !== "always_visible") {
    findings.push({
      rule: "ステマ規制 (景表法 2023年10月) + AI事業者ガイドライン",
      severity: "warning",
      hint: "AI 生成物であることを利用者に明示 (#AI / 「AIが生成」など)。",
    });
  }

  return findings;
}

// プロンプトに個人情報/機密情報が混入していないかスキャン
export interface PromptScanFinding {
  category: "pii" | "secret" | "confidential";
  matched: string;
  hint: string;
}

const PII_PATTERNS: { name: string; re: RegExp; hint: string }[] = [
  { name: "マイナンバー (12桁)", re: /\b\d{4}\s?\d{4}\s?\d{4}\b/g, hint: "マイナンバーをLLMに送信することは原則禁止 (個人情報保護委員会注意喚起)" },
  { name: "クレジットカード番号", re: /\b(?:\d{4}[-\s]?){3}\d{4}\b/g, hint: "PCI DSS 違反の可能性。マスクして送信" },
  { name: "メールアドレス", re: /\b[\w.+-]+@[\w-]+\.[\w.-]+\b/g, hint: "個人情報。仮名化を検討" },
  { name: "電話番号 (日本)", re: /\b0\d{1,4}-?\d{1,4}-?\d{3,4}\b/g, hint: "個人情報。マスク推奨" },
  { name: "API Key (汎用)", re: /\b(sk-|xoxb-|xoxp-|ghp_|github_pat_|AKIA)[A-Za-z0-9_-]{16,}\b/g, hint: "シークレットの漏えい。即時ローテート" },
];

export function scanPromptForPii(prompt: string): PromptScanFinding[] {
  const findings: PromptScanFinding[] = [];
  for (const p of PII_PATTERNS) {
    const re = new RegExp(p.re.source, p.re.flags);
    let m: RegExpExecArray | null;
    while ((m = re.exec(prompt)) !== null) {
      findings.push({
        category: p.name.includes("API") ? "secret" : "pii",
        matched: m[0],
        hint: `${p.name} → ${p.hint}`,
      });
      if (m.index === re.lastIndex) re.lastIndex += 1;
    }
  }
  return findings;
}

// 著作権チェック (文化庁「AIと著作権に関する考え方」2024年3月)
export interface CopyrightAssessment {
  use_phase: "learning" | "generation" | "use";
  used_works_kind: "public_domain" | "open_license" | "third_party_with_consent" | "third_party_without_consent" | "auto_collected_web";
  output_purpose: "personal" | "internal_research" | "commercial_publication" | "training_data";
  similarity_to_existing_work: "low" | "medium" | "high";
}

export interface CopyrightFinding {
  rule: string;
  severity: "info" | "warning" | "violation";
  hint: string;
}

export function assessCopyrightRisk(a: CopyrightAssessment): CopyrightFinding[] {
  const findings: CopyrightFinding[] = [];

  // 学習段階 (著作権法30条の4)
  if (a.use_phase === "learning") {
    if (a.used_works_kind === "third_party_without_consent" || a.used_works_kind === "auto_collected_web") {
      findings.push({
        rule: "著作権法 30条の4 (情報解析のための利用)",
        severity: "info",
        hint: "原則として権利制限の対象 (非享受目的)。ただし「著作権者の利益を不当に害する場合」は例外 (例: 専ら学習目的のデータベース)。",
      });
    }
  }

  // 生成段階
  if (a.use_phase === "generation") {
    if (a.similarity_to_existing_work === "high") {
      findings.push({
        rule: "著作権侵害 (依拠性 + 類似性)",
        severity: "violation",
        hint: "既存著作物との類似性が高く、依拠性も認定される場合は著作権侵害。",
      });
    }
  }

  // 利用段階
  if (a.use_phase === "use") {
    if (a.output_purpose === "commercial_publication" && a.similarity_to_existing_work !== "low") {
      findings.push({
        rule: "著作権法 (利用段階)",
        severity: "warning",
        hint: "商用利用前に類似性チェック (TinEye/Google Image 等) 必須。生成元プロンプト/モデル/シードを記録。",
      });
    }
  }

  return findings;
}

// EU AI Act 域外適用判定
export interface EuAiActApplicability {
  applies: boolean;
  reasons: string[];
  obligations: string[];
}

export function evaluateEuAiActApplicability(input: {
  has_eu_users: boolean;
  output_used_in_eu: boolean;
  use_case: AiUseCase;
}): EuAiActApplicability {
  const applies = input.has_eu_users || input.output_used_in_eu;
  const reasons: string[] = [];
  const obligations: string[] = [];
  if (!applies) {
    reasons.push("EU 域内ユーザ/利用なし → EU AI Act 適用外");
    return { applies: false, reasons, obligations };
  }
  reasons.push("EU AI Act の域外適用条件を満たす (EU 域内のユーザ又は出力利用)");
  const risk = RISK_CLASSIFICATION[input.use_case];
  if (risk === "high") {
    obligations.push("リスク管理システム / 高品質データガバナンス / 詳細な技術文書 / 透明性 / 人間監視 / 高い精度・堅牢性 (Article 8-15)");
    obligations.push("EU市場投入前の適合性評価 + CE マーキング");
  }
  if (risk === "limited") {
    obligations.push("透明性義務: AI とのやり取り/合成コンテンツであることの明示 (Article 50)");
  }
  obligations.push("AI Act 適用開始: 一般原則 2026年2月、高リスク 2027年8月");
  return { applies: true, reasons, obligations };
}

export function buildAiPolicyTemplate(orgName: string): string {
  return `# ${orgName} 生成AI利用ガイドライン

## 1. 目的
本ガイドラインは、${orgName} における生成AI (LLM/画像生成AI 等) の利用にあたり、
AI事業者ガイドライン・個情法・著作権法・特定商取引法等の遵守を確保することを目的とする。

## 2. 利用可能な AI サービス
- 業務利用許可済み: Anthropic Claude (法人契約) / Microsoft Azure OpenAI Service
- 利用禁止: 個人アカウントでの ChatGPT 等 (データの学習利用拒否設定が確認できないもの)

## 3. 入力禁止事項
- マイナンバー (12桁数字)
- 顧客の個人情報 (本人同意なしの場合)
- 機密情報 (社外秘・営業秘密)
- API キー / パスワード等のシークレット
- 第三者の著作物の全文 (要約や抜粋は OK)

## 4. 高リスク用途の追加要件
以下の用途では Human-in-the-loop / 監査ログ / 説明性の確保が必須。
- 採用候補者の評価/選別
- 与信判断
- 教育評価
- 医療診断補助
- 行政手続の意思決定

## 5. AI 生成物の取扱い
- 商用公開時は「AI 生成」を明示 (ステマ規制対応)
- 既存著作物との類似性チェック (商用公開前)
- プロンプト/モデル/出力の記録 (3年保存)

## 6. 違反時の対応
本ガイドライン違反は、就業規則第◯条に基づき懲戒処分の対象となる。
`;
}
