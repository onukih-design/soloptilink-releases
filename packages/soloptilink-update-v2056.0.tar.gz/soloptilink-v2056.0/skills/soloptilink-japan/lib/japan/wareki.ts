/**
 * 和暦変換ユーティリティ
 * 令和/平成/昭和/大正/明治 ⇔ 西暦の相互変換と書式化
 */

type Era = { name: string; short: string; startYear: number; startMonth: number; startDay: number };

const ERAS: Era[] = [
  { name: '令和', short: 'R', startYear: 2019, startMonth: 5, startDay: 1 },
  { name: '平成', short: 'H', startYear: 1989, startMonth: 1, startDay: 8 },
  { name: '昭和', short: 'S', startYear: 1926, startMonth: 12, startDay: 25 },
  { name: '大正', short: 'T', startYear: 1912, startMonth: 7, startDay: 30 },
  { name: '明治', short: 'M', startYear: 1868, startMonth: 1, startDay: 25 },
];

export interface WarekiDate {
  era: string;
  eraShort: string;
  year: number;
  month: number;
  day: number;
}

/**
 * 西暦 → 和暦
 */
export function toWareki(date: Date): WarekiDate {
  const y = date.getFullYear();
  const m = date.getMonth() + 1;
  const d = date.getDate();
  for (const e of ERAS) {
    if (y > e.startYear || (y === e.startYear && (m > e.startMonth || (m === e.startMonth && d >= e.startDay)))) {
      return {
        era: e.name,
        eraShort: e.short,
        year: y - e.startYear + 1,
        month: m,
        day: d,
      };
    }
  }
  throw new Error(`明治より前の日付には対応していません: ${date.toISOString()}`);
}

/**
 * 和暦 → 西暦
 */
export function toSeireki(wareki: Omit<WarekiDate, 'eraShort'>): Date {
  const era = ERAS.find(e => e.name === wareki.era || e.short === wareki.era);
  if (!era) throw new Error(`未知の元号: ${wareki.era}`);
  return new Date(era.startYear + wareki.year - 1, wareki.month - 1, wareki.day);
}

/**
 * 和暦フォーマット (令和6年4月21日 / R6.4.21 / 令和6-04-21)
 */
export function formatWareki(
  date: Date,
  format: 'long' | 'short' | 'iso' | 'ja_full' = 'ja_full'
): string {
  const w = toWareki(date);
  const y = w.year === 1 ? '元' : String(w.year);
  switch (format) {
    case 'long':
      return `${w.era}${y}年${w.month}月${w.day}日`;
    case 'short':
      return `${w.eraShort}${y}.${w.month}.${w.day}`;
    case 'iso':
      return `${w.eraShort}${String(w.year).padStart(2, '0')}-${String(w.month).padStart(2, '0')}-${String(w.day).padStart(2, '0')}`;
    case 'ja_full':
    default:
      return `${w.era}${y}年${w.month}月${w.day}日 (${date.getFullYear()}年)`;
  }
}

/**
 * 和暦・西暦の併記 (帳票用)
 */
export function formatBoth(date: Date): string {
  const w = toWareki(date);
  const y = w.year === 1 ? '元' : String(w.year);
  return `${date.getFullYear()}年${date.getMonth() + 1}月${date.getDate()}日 (${w.era}${y}年)`;
}
