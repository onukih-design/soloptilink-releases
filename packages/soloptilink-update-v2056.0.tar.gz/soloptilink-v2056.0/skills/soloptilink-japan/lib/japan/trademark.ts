/**
 * SoloptiLinkAI Phase 44-IP — 商標 (Trademark)
 *
 * 商標法 + マドリッド協定議定書 + 商標審査基準 + 不正競争防止法 (商品等表示・形態模倣) と連携。
 *
 * カバー範囲:
 *  - 商標の種類 (文字 / 図形 / 立体 / 色彩 / 音 / 動き / ホログラム / 位置)
 *  - ニース分類 (国際分類 第12版/45区分)
 *  - 識別性 (商標法3条) + 不登録事由 (4条)
 *  - 出願→方式審査→実体審査→出願公開→登録 (出願日から約1年)
 *  - 存続期間10年 + 更新 (永続可能)
 *  - 商標権侵害判定 + 商標的使用論
 *  - マドプロ (国際登録) - 60+カ国
 *  - 防護標章登録
 *  - 不使用取消審判 (50条 - 3年継続不使用)
 */

// ニース分類 (第12版 / 45区分)
export const NICE_CLASSES = [
  { class: 1, kind: "goods", name_ja: "化学品" }, { class: 2, kind: "goods", name_ja: "塗料・着色料" },
  { class: 3, kind: "goods", name_ja: "化粧品・洗浄剤" }, { class: 4, kind: "goods", name_ja: "工業用油・燃料" },
  { class: 5, kind: "goods", name_ja: "薬剤" }, { class: 6, kind: "goods", name_ja: "金属製品" },
  { class: 7, kind: "goods", name_ja: "機械・工具" }, { class: 8, kind: "goods", name_ja: "手動工具・刃物" },
  { class: 9, kind: "goods", name_ja: "電気・科学機器・ソフトウェア" }, { class: 10, kind: "goods", name_ja: "医療用機器" },
  { class: 11, kind: "goods", name_ja: "照明・空調機器" }, { class: 12, kind: "goods", name_ja: "輸送機械" },
  { class: 13, kind: "goods", name_ja: "火器・火薬" }, { class: 14, kind: "goods", name_ja: "貴金属・宝石" },
  { class: 15, kind: "goods", name_ja: "楽器" }, { class: 16, kind: "goods", name_ja: "紙製品・印刷物" },
  { class: 17, kind: "goods", name_ja: "ゴム・プラスチック原料" }, { class: 18, kind: "goods", name_ja: "革製品" },
  { class: 19, kind: "goods", name_ja: "建築材料" }, { class: 20, kind: "goods", name_ja: "家具・木製品" },
  { class: 21, kind: "goods", name_ja: "家庭用具" }, { class: 22, kind: "goods", name_ja: "ロープ・テント" },
  { class: 23, kind: "goods", name_ja: "糸" }, { class: 24, kind: "goods", name_ja: "織物" },
  { class: 25, kind: "goods", name_ja: "被服・履物" }, { class: 26, kind: "goods", name_ja: "ボタン・装飾品" },
  { class: 27, kind: "goods", name_ja: "じゅうたん・敷物" }, { class: 28, kind: "goods", name_ja: "玩具・運動用具" },
  { class: 29, kind: "goods", name_ja: "肉・乳製品・加工食品" }, { class: 30, kind: "goods", name_ja: "コーヒー・菓子・調味料" },
  { class: 31, kind: "goods", name_ja: "農産物・園芸用品" }, { class: 32, kind: "goods", name_ja: "ビール・清涼飲料" },
  { class: 33, kind: "goods", name_ja: "アルコール飲料" }, { class: 34, kind: "goods", name_ja: "たばこ" },
  { class: 35, kind: "service", name_ja: "広告・小売" }, { class: 36, kind: "service", name_ja: "金融・不動産" },
  { class: 37, kind: "service", name_ja: "建築・修理" }, { class: 38, kind: "service", name_ja: "電気通信" },
  { class: 39, kind: "service", name_ja: "輸送・旅行" }, { class: 40, kind: "service", name_ja: "材料処理" },
  { class: 41, kind: "service", name_ja: "教育・娯楽" }, { class: 42, kind: "service", name_ja: "科学技術・SaaS" },
  { class: 43, kind: "service", name_ja: "飲食・宿泊" }, { class: 44, kind: "service", name_ja: "医療・美容" },
  { class: 45, kind: "service", name_ja: "法律・警備" },
] as const;

// 商標の種類 (新タイプ商標)
export type TrademarkType =
  | "character" // 文字
  | "figure" // 図形
  | "combined" // 文字+図形
  | "three_dimensional" // 立体
  | "color" // 色彩
  | "sound" // 音
  | "motion" // 動き
  | "hologram" // ホログラム
  | "position"; // 位置

export interface TrademarkApplication {
  application_no: string;
  registration_no?: string;
  trademark_text?: string;
  trademark_type: TrademarkType;
  applicant: string;
  filing_date: string;
  publication_date?: string;
  registration_date?: string;
  next_renewal_due?: string;
  designated_classes: number[]; // ニース分類複数指定可
  designated_goods_services: { class: number; items: string[] }[];
}

// 識別性チェック (3条) + 不登録事由 (4条)
export interface TrademarkRegistrabilityCheck {
  has_distinctive_character: boolean; // 識別力 (3条1項各号該当しない)
  not_descriptive: boolean; // 普通名称/慣用商標/品質記述でない
  not_misleading: boolean; // 品質誤認なし (4条1項16号)
  not_against_public_order: boolean; // 公序良俗反しない (4条1項7号)
  not_likely_to_confuse: boolean; // 混同のおそれなし (4条1項11号 - 先願先登録商標と同一/類似)
  no_famous_mark_conflict: boolean; // 他人の著名商標 (4条1項8号)
  not_state_emblem: boolean; // 国旗・国章でない (4条1項1-5号)
}

export function evaluateRegistrability(c: TrademarkRegistrabilityCheck): {
  registrable: boolean;
  rejection_grounds: string[];
} {
  const grounds: string[] = [];
  if (!c.has_distinctive_character || !c.not_descriptive) grounds.push("識別力欠如 (3条1項) - 普通名称/慣用/記述的");
  if (!c.not_misleading) grounds.push("品質誤認のおそれ (4条1項16号)");
  if (!c.not_against_public_order) grounds.push("公序良俗違反 (4条1項7号)");
  if (!c.not_likely_to_confuse) grounds.push("先願先登録商標と類似 (4条1項11号)");
  if (!c.no_famous_mark_conflict) grounds.push("他人の著名商標 (4条1項8号/19号)");
  if (!c.not_state_emblem) grounds.push("国旗・国章等に類似 (4条1項1-5号)");
  return { registrable: grounds.length === 0, rejection_grounds: grounds };
}

// 商標権存続期間 + 更新
export const TRADEMARK_TERM_YEARS = 10;

export function calcRenewalDue(registrationDate: string): { current_term_end: string; renewal_window_start: string; renewal_window_end: string } {
  const reg = new Date(registrationDate);
  const end = new Date(reg);
  end.setFullYear(end.getFullYear() + TRADEMARK_TERM_YEARS);
  const winStart = new Date(end);
  winStart.setMonth(winStart.getMonth() - 6); // 6ヶ月前から更新申請可
  // 期間満了後6ヶ月以内なら追納 + 倍額
  return {
    current_term_end: end.toISOString().slice(0, 10),
    renewal_window_start: winStart.toISOString().slice(0, 10),
    renewal_window_end: end.toISOString().slice(0, 10),
  };
}

// 不使用取消審判 (50条 - 3年継続不使用)
export interface UseRecord {
  trademark_no: string;
  class: number;
  used_at: string;
  evidence_url?: string;
}

export function isVulnerableToCancellation(records: UseRecord[], asOf: Date = new Date()): boolean {
  if (records.length === 0) return true;
  const threeYearsAgo = new Date(asOf);
  threeYearsAgo.setFullYear(threeYearsAgo.getFullYear() - 3);
  const recent = records.some((r) => new Date(r.used_at) >= threeYearsAgo);
  return !recent; // 3年以内に1度も使われていなければ取消対象
}

// 商標権侵害判定 (商標法36条/37条)
export interface TrademarkInfringementClaim {
  registered_mark: string;
  registered_classes: number[];
  defendant_mark: string;
  defendant_goods_services: { class: number; item: string }[];
  similarity_text: number; // 0-1 (称呼/外観/観念の類似度)
  similarity_goods: boolean; // 同一・類似商品役務
  is_trademark_use: boolean; // 商標的使用 (商標法2条3項)
  defenses?: ("fair_use" | "prior_use" | "exhaustion" | "comparative_advertising")[];
}

export function evaluateTrademarkInfringement(claim: TrademarkInfringementClaim): {
  infringes: boolean;
  reasoning: string[];
} {
  const reasons: string[] = [];
  if (!claim.is_trademark_use) {
    reasons.push("商標的使用に該当しない (記述的使用/装飾的使用) → 非侵害");
    return { infringes: false, reasoning: reasons };
  }
  if (!claim.similarity_goods) {
    reasons.push("商品役務が類似しない → 非侵害");
    return { infringes: false, reasoning: reasons };
  }
  if (claim.similarity_text < 0.6) {
    reasons.push(`類似度 ${claim.similarity_text} (60%未満) → 称呼/外観/観念のいずれも非類似`);
    return { infringes: false, reasoning: reasons };
  }
  if (claim.defenses?.includes("prior_use")) {
    reasons.push("先使用権 (32条) 主張あり → 詳細審査必要");
  }
  if (claim.defenses?.includes("exhaustion")) {
    reasons.push("商標権消尽 (BBS事件) - 並行輸入");
  }
  reasons.push(`類似度 ${claim.similarity_text}, 同一類似区分 → 侵害成立`);
  return { infringes: true, reasoning: reasons };
}

// マドリッド協定議定書 (国際登録)
export interface MadridApplication {
  international_registration_no: string;
  basic_application: string; // 基礎出願 (日本特許庁)
  designated_countries: string[]; // ISO 3166-1 alpha-2
  filing_date: string;
  individual_fee_per_country: { country: string; chf: number }[]; // CHF (スイスフラン)
}

export const MADRID_MEMBER_COUNTRIES_2026 = [
  "AU", "BR", "CA", "CN", "DE", "ES", "FR", "GB", "IN", "IT", "JP", "KR", "MX", "RU", "SG", "TH", "US", "VN", "ID", "PH", "MY",
  // 全60+カ国の代表
] as const;

export function isMadridMember(country: string): boolean {
  return (MADRID_MEMBER_COUNTRIES_2026 as readonly string[]).includes(country);
}

// 防護標章登録 (商標法64条)
export function isEligibleForDefensiveMark(input: {
  is_famous: boolean; // 著名商標
  goods_services_to_extend: number[]; // 防護を拡げたい区分
}): { eligible: boolean; reason: string } {
  if (!input.is_famous) {
    return { eligible: false, reason: "防護標章登録は著名商標のみ (64条)" };
  }
  return {
    eligible: true,
    reason: `著名商標として ${input.goods_services_to_extend.length} 区分への防護登録が可能 (64条)`,
  };
}
