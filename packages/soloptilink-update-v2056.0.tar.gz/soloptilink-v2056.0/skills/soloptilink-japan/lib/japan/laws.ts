/**
 * SoloptiLinkAI JAPAN-NATIVE Mode - 法令DNA Library
 * 8法令を網羅し、アプリケーションに直接注入できる判定・計算ユーティリティ群。
 *
 * 対応法令:
 *   1. インボイス制度 (消費税法 適格請求書等保存方式)
 *   2. 電子帳簿保存法 (電帳法)
 *   3. 個人情報保護法 (個情法)
 *   4. マイナンバー法 (番号法)
 *   5. 労働基準法 (労基法)
 *   6. 下請代金支払遅延等防止法 (下請法)
 *   7. 建設業法
 *   8. 金融商品取引法 (金商法)
 *
 * 使い方:
 *   import { Invoice, DenchoHo, PersonalInfo, MyNumber, LaborStd, Subcontract, Construction, FIEA } from './laws';
 *
 *   if (!Invoice.validateRegistrationNumber(supplier.invoiceNo)) throw new Error('登録番号不正');
 *   const tax = Invoice.calcTaxBreakdown(items); // { reduced8: 2400, standard10: 5000 }
 *   const violation = LaborStd.check36Agreement(monthlyOvertime);
 */

// 業種キーの正規化と「基本3法だけに落ちたか」の開示は、拡張法令側にしか分岐が無いキー
// (bridal / beauty / real_estate 等) も見なければ正しく判定できない。分岐キーの一覧を
// こちら側へ書き写すと片方だけが古くなるため、分岐そのものを呼んで確かめる。
// ★依存は laws.ts → laws_extended.ts の一方向のみ (laws_extended.ts は import を持たない)。
import { recommendExtendedLaws } from './laws_extended';

// =============================================================================
// Invoice: インボイス制度 (適格請求書等保存方式)
// =============================================================================
export const Invoice = {
  /**
   * 適格請求書発行事業者の登録番号検証
   * フォーマット: "T" + 13桁の数字 (法人番号と同じ桁数)
   */
  validateRegistrationNumber(no: string): boolean {
    if (!no) return false;
    return /^T\d{13}$/.test(no.trim());
  },

  /**
   * 税率別集計 (10% / 軽減8% / 非課税)
   */
  calcTaxBreakdown(items: Array<{ price: number; qty: number; rate: 'standard' | 'reduced' | 'exempt' }>): {
    subtotal: { standard: number; reduced: number; exempt: number };
    tax: { standard: number; reduced: number };
    total: number;
  } {
    const subtotal = { standard: 0, reduced: 0, exempt: 0 };
    for (const it of items) {
      const amount = it.price * it.qty;
      if (it.rate === 'standard') subtotal.standard += amount;
      else if (it.rate === 'reduced') subtotal.reduced += amount;
      else subtotal.exempt += amount;
    }
    const tax = {
      standard: Math.floor(subtotal.standard * 0.10),
      reduced: Math.floor(subtotal.reduced * 0.08),
    };
    const total = subtotal.standard + subtotal.reduced + subtotal.exempt + tax.standard + tax.reduced;
    return { subtotal, tax, total };
  },

  /**
   * 適格簡易請求書の発行可否判定 (小売/飲食/写真/旅行/タクシー/駐車場)
   */
  canIssueSimplified(industry: string): boolean {
    // ★2026-08-11 (全結線計画 BLK-2): 業種辞書の名前で呼ばれても正しく判定できるよう
    //   キーを正規化する。従来は 'retail-pos' が false になり、小売業なのに
    //   適格簡易請求書を発行できないと判定していた (消費税法第57条の4第2項が
    //   小売業に認めた特例を、システムが自ら捨てていた)。
    return ['retail', 'food_service', 'photo', 'travel', 'taxi', 'parking']
      .includes(normalizeIndustryKey(industry));
  },

  /**
   * 必須記載事項のチェック (適格請求書)
   */
  requiredFields(): string[] {
    return [
      '発行者の氏名または名称',
      '登録番号 (T + 13桁)',
      '取引年月日',
      '取引内容 (軽減税率対象である旨)',
      '税率ごとに区分した合計額',
      '税率ごとに区分した消費税額',
      '受領者の氏名または名称',
    ];
  },
};

// =============================================================================
// DenchoHo: 電子帳簿保存法
// =============================================================================
export const DenchoHo = {
  /**
   * 電子取引データの3要件検索キー生成 (取引年月日/取引金額/取引先)
   */
  buildSearchKeys(transaction: { date: string; amount: number; partner: string }): string[] {
    return [
      `date:${transaction.date}`,
      `amount:${transaction.amount}`,
      `partner:${transaction.partner}`,
    ];
  },

  /**
   * タイムスタンプ付与要件 (JIIMA認定タイムスタンプが必要)
   * スキャナ保存: おおむね7営業日以内
   * 電子取引: 法令遵守のため取引後速やかに
   */
  timestampDeadline(kind: 'scanner' | 'e_transaction'): number {
    return kind === 'scanner' ? 7 : 2; // 営業日
  },

  /**
   * 改ざん防止のためのハッシュ計算 (SHA-256 を推奨)
   */
  async computeFileHash(file: Uint8Array): Promise<string> {
    if (typeof crypto !== 'undefined' && crypto.subtle) {
      const buf = await crypto.subtle.digest('SHA-256', new Uint8Array(file));
      return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('');
    }
    throw new Error('Crypto API 利用不可。server-side で node:crypto を利用してください。');
  },

  /**
   * スキャナ保存要件 (解像度/階調)
   */
  scannerRequirements(): { dpi: number; colorDepth: number; fileFormat: string[] } {
    return { dpi: 200, colorDepth: 24, fileFormat: ['pdf', 'jpeg', 'png', 'tiff'] };
  },
};

// =============================================================================
// PersonalInfo: 個人情報保護法
// =============================================================================
export const PersonalInfo = {
  /**
   * 要配慮個人情報の分類 (医療/犯罪歴/人種/信条/社会的身分等)
   */
  isSensitive(field: string): boolean {
    const sensitive = [
      '病歴', '診療履歴', '服薬', '障害', '精神状態',
      '犯罪歴', '犯罪被害',
      '人種', '信条', '社会的身分', '国籍',
      '遺伝情報', '生体情報',
    ];
    return sensitive.some(s => field.includes(s));
  },

  /**
   * 利用目的通知文の雛形生成
   */
  generatePurposeNotice(params: { purposes: string[]; company: string; contact: string }): string {
    return [
      `${params.company} 個人情報の利用目的のお知らせ`,
      '',
      '当社では、以下の目的でお客さまの個人情報を取扱います:',
      ...params.purposes.map(p => `・${p}`),
      '',
      '上記目的の範囲を超えて利用することはございません。',
      '個人情報保護に関するお問い合わせ:',
      params.contact,
    ].join('\n');
  },

  /**
   * 第三者提供時の記録項目 (名簿屋規制対応)
   */
  thirdPartyRecordFields(): string[] {
    return ['提供年月日', '提供先の名称', '本人氏名', '提供した項目', '本人同意の有無'];
  },

  /**
   * 保有個人データの開示請求対応チェック (30日以内)
   */
  disclosureDeadlineDays(): number {
    return 30;
  },
};

// =============================================================================
// MyNumber: マイナンバー法
// =============================================================================
export const MyNumber = {
  /**
   * マイナンバーの形式検証 (12桁の数字 + チェックディジット)
   */
  validate(no: string): boolean {
    if (!/^\d{12}$/.test(no)) return false;
    const digits = no.split('').map(Number);
    const check = digits[11];
    const body = digits.slice(0, 11);
    // チェックディジット計算 (国税庁公表仕様)
    const weights = [6, 5, 4, 3, 2, 7, 6, 5, 4, 3, 2];
    let sum = 0;
    for (let i = 0; i < 11; i++) sum += body[i] * weights[i];
    const rem = sum % 11;
    const cd = rem <= 1 ? 0 : 11 - rem;
    return cd === check;
  },

  /**
   * 表示用マスク (下4桁以外を * に)
   */
  mask(no: string): string {
    if (!no || no.length < 4) return '************';
    return '*'.repeat(no.length - 4) + no.slice(-4);
  },

  /**
   * 取扱可能業務の判定 (税・社保・災害対策の3分野のみ)
   */
  canHandle(purpose: 'tax' | 'social_security' | 'disaster' | string): boolean {
    return ['tax', 'social_security', 'disaster'].includes(purpose);
  },

  /**
   * 廃棄記録のフィールド
   */
  disposalRecordFields(): string[] {
    return ['廃棄年月日', '廃棄方法', '対象件数', '廃棄責任者', '立会者'];
  },
};

// =============================================================================
// LaborStd: 労働基準法
// =============================================================================
export const LaborStd = {
  /**
   * 36協定違反検知 (月45時間/年360時間の原則、特別条項で月100h/年720h上限)
   */
  check36Agreement(monthly: number[], yearly: number, hasSpecial: boolean): Array<{ month: number; hours: number; rule: string }> {
    const violations: Array<{ month: number; hours: number; rule: string }> = [];
    const monthLimit = hasSpecial ? 100 : 45;
    const yearLimit = hasSpecial ? 720 : 360;
    monthly.forEach((h, i) => {
      if (h > monthLimit) violations.push({ month: i + 1, hours: h, rule: `月${monthLimit}時間超過` });
    });
    if (yearly > yearLimit) violations.push({ month: 0, hours: yearly, rule: `年${yearLimit}時間超過` });
    // 特別条項ありでも、複数月平均80時間は違反
    if (hasSpecial) {
      for (let i = 2; i < monthly.length; i++) {
        const avg3 = (monthly[i - 2] + monthly[i - 1] + monthly[i]) / 3;
        if (avg3 > 80) violations.push({ month: i + 1, hours: Math.round(avg3), rule: '3ヶ月平均80時間超過' });
      }
    }
    return violations;
  },

  /**
   * 割増賃金率の算出 (時間外25%, 深夜25%, 法定休日35%, 月60h超50%)
   */
  overtimeRate(params: { overtimeHoursInMonth: number; isNight: boolean; isLegalHoliday: boolean }): number {
    let rate = 0;
    if (params.isLegalHoliday) rate = 0.35;
    else if (params.overtimeHoursInMonth > 60) rate = 0.50;
    else rate = 0.25;
    if (params.isNight) rate += 0.25;
    return rate;
  },

  /**
   * 有給休暇5日取得義務チェック (年10日付与される労働者対象)
   */
  check5DaysPaidLeave(annualPaidDays: number, takenDays: number): boolean {
    if (annualPaidDays < 10) return true; // 対象外
    return takenDays >= 5;
  },
};

// =============================================================================
// Subcontract: 下請代金支払遅延等防止法 (下請法)
// =============================================================================
export const Subcontract = {
  /**
   * 3条書面の必須記載事項
   */
  required3jouFields(): string[] {
    return [
      '発注者・受注者の名称',
      '発注日',
      '給付内容',
      '給付を受領する期日',
      '代金の額',
      '代金の支払期日',
      '代金の支払方法',
      '有償支給原材料等があるときはその内容',
    ];
  },

  /**
   * 支払遅延チェック (受領後60日以内が上限)
   */
  checkPaymentDeadline(receivedDate: Date, paymentDate: Date): { ok: boolean; days: number } {
    const days = Math.floor((paymentDate.getTime() - receivedDate.getTime()) / 86400000);
    return { ok: days <= 60, days };
  },

  /**
   * 下請法適用範囲判定 (資本金要件)
   */
  applies(parentCapital: number, childCapital: number, kind: 'manufacturing' | 'service'): boolean {
    if (kind === 'manufacturing') {
      if (parentCapital > 300_000_000 && childCapital <= 300_000_000) return true;
      if (parentCapital > 10_000_000 && parentCapital <= 300_000_000 && childCapital <= 10_000_000) return true;
    } else {
      if (parentCapital > 50_000_000 && childCapital <= 50_000_000) return true;
      if (parentCapital > 10_000_000 && parentCapital <= 50_000_000 && childCapital <= 10_000_000) return true;
    }
    return false;
  },

  /**
   * 禁止行為11類型
   */
  prohibitedActs(): string[] {
    return [
      '受領拒否', '下請代金の支払遅延', '下請代金の減額', '返品',
      '買いたたき', '購入・利用強制', '報復措置', '有償支給原材料等の対価の早期決済',
      '割引困難な手形の交付', '不当な経済上の利益の提供要請', '不当な給付内容の変更および不当なやり直し',
    ];
  },
};

// =============================================================================
// Construction: 建設業法
// =============================================================================
export const Construction = {
  /**
   * 建設業許可番号のフォーマット検証
   * 例: "国土交通大臣 特-30 第00001号" / "東京都知事 般-02 第000001号"
   */
  validateLicenseNumber(no: string): boolean {
    const pattern = /^(国土交通大臣|[都道府県]{2,3}知事)\s+(特|般)-\d{2}\s+第\d{5,6}号$/;
    return pattern.test(no.trim());
  },

  /**
   * 主任技術者/監理技術者の配置要件
   * 元請: 4500万円以上 (建築一式は7000万円以上) は監理技術者
   */
  requiredEngineer(contractAmount: number, isArchitecture: boolean, isPrime: boolean): 'chief' | 'supervisor' {
    const threshold = isArchitecture ? 70_000_000 : 45_000_000;
    if (isPrime && contractAmount >= threshold) return 'supervisor'; // 監理技術者
    return 'chief'; // 主任技術者
  },

  /**
   * 一括下請負の禁止 (公共工事は全面禁止、民間も原則禁止)
   */
  checkLumpSubcontracting(isPublic: boolean, hasConsent: boolean): { ok: boolean; reason?: string } {
    if (isPublic) return { ok: false, reason: '公共工事は一括下請負全面禁止' };
    if (!hasConsent) return { ok: false, reason: '民間工事でも書面承諾が必要' };
    return { ok: true };
  },

  /**
   * 建退共証紙の計算 (掛金日額310円 × 就労日数)
   */
  calcTaishokusho(workDays: number): number {
    return workDays * 310;
  },

  /**
   * 29業種の一覧
   */
  specialties(): string[] {
    return [
      '土木', '建築', '大工', '左官', 'とび・土工・コンクリート',
      '石', '屋根', '電気', '管', 'タイル・れんが・ブロック',
      '鋼構造物', '鉄筋', '舗装', 'しゅんせつ', '板金',
      'ガラス', '塗装', '防水', '内装仕上', '機械器具設置',
      '熱絶縁', '電気通信', '造園', 'さく井', '建具',
      '水道施設', '消防施設', '清掃施設', '解体',
    ];
  },
};

// =============================================================================
// FIEA: 金融商品取引法 (Financial Instruments and Exchange Act)
// =============================================================================
export const FIEA = {
  /**
   * 広告規制: 誇大表示禁止項目
   */
  prohibitedAdTerms(): string[] {
    return ['絶対', '必ず儲かる', '元本保証', '損失なし', '確実に'];
  },

  /**
   * 適合性の原則チェック (顧客属性と商品の適合)
   */
  checkSuitability(customer: { age: number; experience: number; income: number; assets: number }, product: { riskLevel: 1 | 2 | 3 | 4 | 5 }): { ok: boolean; reason?: string } {
    if (product.riskLevel >= 4 && customer.experience < 3) {
      return { ok: false, reason: '投資経験不足 (3年未満)' };
    }
    if (product.riskLevel === 5 && customer.age >= 75) {
      return { ok: false, reason: '75歳以上への高リスク商品勧誘制限' };
    }
    if (customer.assets < product.riskLevel * 1_000_000) {
      return { ok: false, reason: '必要金融資産不足' };
    }
    return { ok: true };
  },

  /**
   * 契約締結前交付書面の必須記載事項
   */
  preContractDocRequiredFields(): string[] {
    return [
      '手数料・報酬・費用',
      '元本欠損のおそれ',
      '金利変動・相場変動リスク',
      'クーリングオフの有無',
      '取扱業者の商号・登録番号',
      '指定紛争解決機関',
    ];
  },
};

// =============================================================================
// 統合判定: 業種から必要法令を推定
// =============================================================================
// =============================================================================
// 業種キーの正規化 (2026-08-11 / 全結線計画 BLK-2)
// =============================================================================
/**
 * 業種辞書の slug を、法令判定が分岐に使うキーへ寄せる。
 *
 * 【なぜ要るか — 実測で確かめた欠陥】
 *   法令判定の分岐キーはカテゴリ単位 (construction / manufacturing / healthcare /
 *   professional / retail / food_service / finance) だが、業種辞書の名前は具体名の
 *   kebab-case (retail-pos / food-service / printing …) である。両者が一致しないため、
 *   業種辞書の名前でそのまま呼ぶと **既定の基本3法しか返らない**。しかも
 *   「該当法令なし」として画面に出るだけで、欠落したこと自体が表示されない。
 *     実測: applicableLawsFor('retail-pos') → 基本3法 / 'retail' → 景品表示法・特定商取引法を含む
 *           canIssueSimplified('retail-pos') → false (小売業なのに適格簡易請求書が発行できない判定)
 *
 * 【機械的に寄せてはいけない — 実測で確かめた反例】
 *   業種辞書の category 宣言を機械的に使うと誤る。
 *     ・veterinary-clinic の category は healthcare だが、動物病院に医療法・介護保険法は
 *       当たらない (獣医師法・獣医療法は本ライブラリに実装が無い)。
 *     ・retail-pos / food-service は category を宣言していない。
 *   よって本表は **根拠のあるものだけ** を1件ずつ載せる。載っていない業種は
 *   従来どおり既定 (基本3法) に落ちる = 挙動は変わらない。
 *
 * 【この表に足すときの条件】
 *   ① 業種辞書が自らその category を宣言している、または
 *   ② 返る法令が、その業種辞書の regulations に書かれた法令名・数値と一致することを
 *      実装を読んで確認した
 *   どちらも満たさないものを推測で足さない。足すと、その業種に無関係な法令が
 *   「該当法令」として顧客の画面に出る。
 */
const INDUSTRY_KEY_ALIASES: Record<string, string> = {
  // ---------------------------------------------------------------------------
  // (a) コア法 (laws.ts recommendLaws) の分岐へ寄せるもの
  // ---------------------------------------------------------------------------
  // 小売POS: 景品表示法 (景品額の上限)・特定商取引法第11条の8項目・製造物責任法第5条の
  //   3年/10年・薬機法第36条の8/9の販売区分が、業種辞書の regulations の記載値と
  //   一致することを確認済 (2026-08-11)
  'retail-pos': 'retail',
  // 飲食: 食品衛生法の営業許可業種と食中毒24時間届出・食品表示法のアレルゲン義務8品目/
  //   推奨20品目/栄養5項目が実装に実在し、業種辞書の要求と一致することを確認済
  'food-service': 'food_service',
  // 印刷: 業種辞書が category=manufacturing を宣言。かつ下請法の条文・数値
  //   (第2条の資本金区分・第2条の2の60日・第3条の三条書面・第4条の禁止行為) が
  //   実装 API と逐語で対応することを確認済
  printing: 'manufacturing',
  // 産業廃棄物処理: 廃棄物処理法 (S45法律137) の産廃20種・特別管理の性状判定・
  //   12条の3のマニフェスト・14条の許可5年更新が実装に実在することを確認済
  'industrial-waste': 'industrial_waste',
  // 士業事務所 (2026-08-15 / 13業種結線): 辞書 regulations の 税理士法・弁護士法・公認会計士法・
  //   社会保険労務士法・行政書士法 は、実装分岐 'professional' が返す『士業法』の総称に対応する。
  //   keywords に 士業事務所・マイナンバー・就業規則 が実在し、返る マイナンバー法・労働基準法 と
  //   対応する (士業は特定個人情報の取扱者・雇用主として両法の名宛人)。
  //   ★辞書 regulations の 犯罪収益移転防止法 は本ライブラリに実装が無く返らない。
  //     網羅ではないことを判定台帳 industry-lane-judgment.json に開示している (owner 再判断用)。
  'professional-firm': 'professional',

  // ---------------------------------------------------------------------------
  // (b) 拡張法令 (laws_extended.ts recommendExtendedLaws) の分岐へ寄せるもの
  //     ★2026-08-14 追加。
  //
  //     【直した欠陥 — 直す前の実測】
  //       拡張法令の分岐は 15 件あるのに、114 業種を全通しで呼んで実際に発火したのは
  //       6 件だけだった (construction / manufacturing / food_service / healthcare /
  //       retail / bridal)。残る 9 件 (beauty / real_estate / hotel / childcare /
  //       education / advertising / logistics / transport / it) は、その分岐名に
  //       当たる業種名が本表に無いため **一度も発火しない死んだ分岐** だった。
  //       業種辞書には美容室も不動産も宿泊も保育も実在するのに、その業種で
  //       いちばん外せない業法 (薬機法・宅建業法・旅館業法・児童福祉法) が
  //       生成物の「該当法令」から丸ごと落ちていた。
  //
  //     【足す条件は (a) と同じ。推測で足さない】
  //       返る法令が業種辞書の regulations の記載と一致するか、返る実体の実装が
  //       その業種を名指ししていることを 1 件ずつ確認した。確認できない業種は
  //       足していない (足すと無関係な法令が顧客の画面に「該当法令」として出る)。
  //       ★本表に足しても KNOWN_INDUSTRY_KEYS には入らないため、コア法
  //         (recommendLaws) と適格簡易請求書 (canIssueSimplified) の判定は
  //         いずれも従来どおり (基本3法 / false) で変わらない。変わるのは
  //         拡張法令が返るようになる点と、その結果 fallsBackToBaseLaws が
  //         「基本3法だけ」ではなくなる点だけである。
  //
  // 美容室: 辞書の regulations に「医薬品医療機器等法 (薬機法)」「不当景品類及び
  //   不当表示防止法 (景品表示法)」を明記。分岐が返す2法と逐語で一致する。
  //   ★beauty-clinic (美容クリニック) は足さない。辞書の regulations は医療法
  //     (医療広告ガイドライン)・医師法であり、景品表示法の記載が無い。医療機関の
  //     広告規制は医療法側であって、機械的に寄せると誤った規制を提示する。
  'beauty-salon': 'beauty',
  // 不動産: 辞書の regulations 筆頭が「宅地建物取引業法」。分岐が返す法令と一致する。
  //   ★real-estate-portal / property-management も同法を掲げており同様に寄せられるが、
  //     本回は死んだ分岐の解消に必要な 1 件ずつに留めた (未追加であって不適格ではない)。
  'real-estate': 'real_estate',
  // 宿泊 (ホテル・旅館): 辞書の regulations に「旅館業法」「食品衛生法」を明記し、
  //   分岐が返す2法と一致する。「住宅宿泊事業法 (民泊新法)」も掲げており、
  //   実装側の RyokanGyo.isMinpaku (年間営業日数 180 日) と対応する。
  'hotel-ryokan': 'hotel',
  // 保育所: 辞書の regulations 筆頭が「児童福祉法」。分岐が返す法令と一致する。
  'nursery-school': 'childcare',
  // 学童保育 (放課後児童健全育成事業): 辞書の regulations 筆頭が
  //   「児童福祉法(放課後児童健全育成事業)」、category も education-welfare。
  //   ★childcare と education は同一の分岐 (どちらも児童福祉法だけを返す) であり、
  //     どちらの札に寄せても返る法令は変わらない。両業種とも辞書に児童福祉法がある。
  //   ★学校 (school)・学習塾 (cram-school)・語学学校 (language-school) は足さない。
  //     いずれも辞書の regulations に児童福祉法が無く (学校教育法・特定商取引法)、
  //     寄せると学校に児童福祉法を「該当法令」として提示することになる。
  'after-school-care': 'education',
  // SNSマーケティング代理店: 景品表示法は辞書の regulations に「景品表示法 (ステマ規制)
  //   第5条第3号・令和5年告示第19号」として明記されており一致する。
  //   ★薬機法は辞書の regulations に記載が無い。寄せる根拠は、薬機法第66条 (誇大広告等)
  //     が「何人も」を名宛人とし広告を作成・依頼する事業者を直接規制すること、および
  //     分岐が返す実体 Yakkiho.forbiddenMedicalClaims() が広告表現の禁止例そのもので
  //     あることによる。★辞書側に記載が無い点は隠さずここに残す (owner 再判断用)。
  'sns-marketing-agency': 'advertising',
  // 物流 (運送): 辞書の regulations は貨物自動車運送事業法・改善基準告示等であり、
  //   労働安全衛生法の記載は無い。寄せる根拠は、分岐が返す実体
  //   AnzenEisei.safetyManagerRequiredIndustries() が「運輸業」を安全管理者選任業種
  //   として明記していること (安衛法施行令第2条)。産業医・ストレスチェックの
  //   50人以上要件は業種を問わず全事業場に及ぶため、誤った義務の提示にはならない。
  'logistics-trucking': 'logistics',
  // 運送 (トラック運送): 上と同じ根拠。
  //   ★moving-company / taxi-operator は category=transport を自ら宣言しており
  //     同様に寄せられるが、本回は 1 件ずつに留めた (未追加であって不適格ではない)。
  'trucking-transport': 'transport',
  // IT (プロジェクト管理・SES): 辞書の regulations に「労働者派遣事業の適正な運営の
  //   確保等に関する法律(労働者派遣法)」を明記し、その key_articles の
  //   「派遣期間制限 … 原則3年 (事業所単位・個人単位)」が実装の
  //   HakenHou.individualMaxYears() / workplaceMaxYears() = 3 と数値まで一致する。
  'project-management': 'it',
};

/** 法令判定が実際に分岐するキー。★この集合と下の switch を必ず一致させること。 */
const KNOWN_INDUSTRY_KEYS = new Set([
  'construction', 'manufacturing', 'healthcare', 'professional',
  'retail', 'food_service', 'finance', 'industrial_waste',
]);

export function normalizeIndustryKey(industry: string): string {
  if (!industry) return industry;
  const raw = industry.trim();
  // ★2026-08-13 是正: 別名表の参照を小文字化していなかったため、'Retail-POS' は
  //   別名に当たらず既定 (基本3法) へ落ち、一方 'FOOD-SERVICE' は下の snake 化経路で
  //   正しく当たっていた。同じ大文字混在なのに寄せ先が別名か分岐キー本体かで結果が
  //   変わる不一致になっており、簡易課税セレクタ (slug を小文字化する) との間でも
  //   同じ業種名の判定が食い違っていた。
  const alias = INDUSTRY_KEY_ALIASES[raw.toLowerCase()];
  if (alias) return alias;
  // 表記ゆれだけの不一致 (kebab-case ↔ snake_case) は寄せる。
  //   ★寄せた先が実在する分岐キーのときだけ採用する。実在しないキーへ寄せると、
  //     既定へ落ちるのと同じでありながら「寄せた」ように見えて紛らわしい。
  const snake = raw.toLowerCase().replace(/-/g, '_');
  if (KNOWN_INDUSTRY_KEYS.has(snake)) return snake;
  // ★2026-08-14 是正 (2026-08-13 の是正の残り半分):
  //   上の集合はコア法 (recommendLaws) の分岐キーだけを持つため、拡張法令にしか
  //   分岐が無いキー (bridal 等) はここを素通りし、生の表記のまま返っていた。
  //   その結果 'bridal' は旅館業法・食品衛生法を返すのに 'Bridal' は 0 件という、
  //   2026-08-13 に直したのと同型の「大文字小文字で結果が変わる」不一致が残っていた。
  //   ★キーの一覧をここに書き写さない。分岐そのものを呼んで実在を確かめる
  //     (一覧を二重に持つと、片方だけが古くなって同じ死に方をする)。
  if (recommendExtendedLaws(snake).length > 0) return snake;
  return raw;
}

/**
 * 正規化しても既定 (基本3法) に落ちる業種かどうか。画面での開示に使う。
 *
 * ★2026-08-14 是正: 従来はコア法の分岐キー集合だけを見ていたため、拡張法令が
 *   実際に返っている業種まで「未登録 (基本3法だけ)」と申告していた
 *   (実測: bridal は旅館業法・食品衛生法の2法が返るのに true)。
 *   コア法と拡張法令の両方が空振りしたときだけが「基本3法だけ」である。
 *
 * ★この値が false でも「その業種の法令を網羅している」意味ではない。
 *   意味するのは「基本3法に加えて業種固有の法令が最低1件は返っている」ことだけで、
 *   本ライブラリに実装が無い業法 (例: 美容師法・獣医師法) は返らないままである。
 */
export function fallsBackToBaseLaws(industry: string): boolean {
  const key = normalizeIndustryKey(industry);
  return !KNOWN_INDUSTRY_KEYS.has(key) && recommendExtendedLaws(key).length === 0;
}

export function recommendLaws(industry: string): string[] {
  const base = ['インボイス制度', '電子帳簿保存法', '個人情報保護法'];
  switch (normalizeIndustryKey(industry)) {
    case 'construction':
      // 建設業界コア3法 (建築士法/建築基準法/建設業法) + 拡張8法 (下請法/建築物省エネ法/都市計画法/耐震改修促進法/バリアフリー法/建設リサイクル法/住宅品質確保促進法/消防法) + 労基法.
      // 消防法は H3 で追加 (第17条 消防用設備等 + 第8条 防火管理者. 設備図・防火区画設計の前提法令).
      // 建築物省エネ法は 2025年4月改正で全新築 (原則 10 ㎡超) 適合義務化.
      // 各法令の条文番号・規模閾値・工程フェーズとの対応は construction-knowledge レーンに集約.
      return [
        ...base,
        '建築士法',
        '建築基準法',
        '建設業法',
        '下請法',
        '労働基準法',
        '建築物省エネ法',
        '都市計画法',
        '耐震改修促進法',
        'バリアフリー法',
        '建設リサイクル法',
        '住宅品質確保促進法',
        '消防法',
      ];
    case 'manufacturing':
      return [...base, '下請法', 'PL法', '労働基準法'];
    case 'healthcare':
      return [...base, 'マイナンバー法', '医療法', '介護保険法'];
    case 'professional':
      return [...base, 'マイナンバー法', '士業法', '労働基準法'];
    case 'retail':
      return [...base, '景品表示法', '特定商取引法'];
    case 'food_service':
      return [...base, '食品衛生法', '景品表示法'];
    case 'finance':
      return [...base, '金融商品取引法', '貸金業法', '資金決済法'];
    // ★2026-08-11 追加 (全結線計画 第3群)。lib/japan/waste.ts が廃棄物処理法
    //   (S45法律137) の産廃20種・特別管理の性状判定・12条の3のマニフェスト90日/180日・
    //   14条の許可5年更新を実装しており、業種辞書 industrial-waste の regulations と
    //   直接対応することを確認したうえで追加した。
    //   ★確認していない法令 (建設リサイクル法・フロン排出抑制法) はここに書かない。
    //     解体工事や第一種特定製品を扱うかは事業者ごとに異なり、一律に「該当法令」として
    //     出すと誤った義務を提示することになる。
    case 'industrial_waste':
      return [...base, '廃棄物処理法'];
    default:
      return base;
  }
}
