/**
 * agriculture.ts — Phase 22 農林水産業
 *
 * カバレッジ:
 *   - 農地法 (3条/4条/5条 許可) + 農業委員会
 *   - JAS法 (有機JAS/特色JAS/特定JAS) + 表示マーク
 *   - 食品衛生法 HACCP 水産加工
 *   - 森林法 (保安林/林地開発許可1ha超)
 *   - 漁業法 (定置/区画/共同漁業権)
 *   - みどりの食料システム法 (R4施行 化学農薬30%減/有機25%)
 *   - 農薬取締法 (登録/使用基準/食品残留農薬基準)
 *   - 飼料安全法 + GAP (Good Agricultural Practice)
 *   - 6次産業化法 + 農商工連携
 *
 * 主要 export:
 *   - FARMLAND_PERMIT_TYPES / requireFarmlandPermit / calcFarmlandTaxReduction
 *   - JAS_CATEGORIES / validateJasOrganicLabel / verifyJasMark
 *   - HACCP_CCP_FISHERY / checkHaccpFishery
 *   - FOREST_PROTECTION_TYPES / requireForestDevelopmentPermit
 *   - FISHERY_RIGHT_TYPES / canExerciseFisheryRight
 *   - MIDORI_TARGETS_2050 / calcReductionProgress
 *   - PESTICIDE_RESIDUE_DEFAULT / checkPesticideUsage
 *   - GAP_LEVELS / certifyGap
 *   - SIXTH_INDUSTRY_PLAN_REQS / build6thIndustryPlan
 */

// ===== 農地法 =====

export type FarmlandPermitType = '3jo' | '4jo' | '5jo';

export interface FarmlandPermitDef {
  /** 法令上の条文 */
  article: FarmlandPermitType;
  /** 概要 */
  description: string;
  /** 許可権者 */
  authority: '農業委員会' | '都道府県知事';
  /** 4ha 超は農林水産大臣協議 (R5法改正で原則権限委譲、ただし例外あり) */
  ministryConsultThresholdHa?: number;
}

export const FARMLAND_PERMIT_TYPES: Record<FarmlandPermitType, FarmlandPermitDef> = {
  '3jo': {
    article: '3jo',
    description: '農地のまま所有権・賃借権を移転(売買/贈与/交換/賃貸)',
    authority: '農業委員会',
  },
  '4jo': {
    article: '4jo',
    description: '農地を農地以外に転用 (自己所有地)',
    authority: '都道府県知事',
    ministryConsultThresholdHa: 4,
  },
  '5jo': {
    article: '5jo',
    description: '農地を農地以外に転用するための権利移転 (他人へ売って転用)',
    authority: '都道府県知事',
    ministryConsultThresholdHa: 4,
  },
};

export interface FarmlandTransaction {
  kind: 'transfer_keep_farmland' | 'self_convert' | 'transfer_and_convert';
  areaHa: number;
}

/** 農地法上必要な許可種別を判定 */
export function requireFarmlandPermit(t: FarmlandTransaction): FarmlandPermitType {
  switch (t.kind) {
    case 'transfer_keep_farmland':
      return '3jo';
    case 'self_convert':
      return '4jo';
    case 'transfer_and_convert':
      return '5jo';
  }
}

/** 4ha 超の場合は大臣協議が必要かを返す */
export function needsMinisterConsult(t: FarmlandTransaction): boolean {
  const def = FARMLAND_PERMIT_TYPES[requireFarmlandPermit(t)];
  return !!def.ministryConsultThresholdHa && t.areaHa > def.ministryConsultThresholdHa;
}

/** 農業経営基盤強化促進法 — 認定農業者の固定資産税軽減 (R6: 1/2 軽減目安) */
export function calcFarmlandTaxReduction(taxBase: number, certified: boolean): number {
  return certified ? Math.floor(taxBase * 0.5) : taxBase;
}

// ===== JAS 法 (Japanese Agricultural Standards) =====

export type JasCategory = 'organic' | 'special_jas' | 'specific_jas' | 'standard';

export const JAS_CATEGORIES: Record<JasCategory, { label: string; markRequired: boolean }> = {
  organic: { label: '有機JAS (化学合成農薬・化学肥料原則不使用 2年以上)', markRequired: true },
  special_jas: { label: '特色JAS (生産情報公表/熟成ハム等)', markRequired: true },
  specific_jas: { label: '特定JAS (地鶏肉/手延べ干し麺等)', markRequired: true },
  standard: { label: '一般JAS (JAS規格適合品)', markRequired: true },
};

export interface JasOrganicProduct {
  category: JasCategory;
  /** 有機転換期間 (月) */
  conversionMonths: number;
  /** 化学合成農薬を使用したか */
  usedSyntheticPesticides: boolean;
  /** 化学肥料を使用したか */
  usedSyntheticFertilizer: boolean;
  /** 認定機関名 (登録認証機関) */
  certifyingBody?: string;
  /** マーク添付 */
  markAttached: boolean;
}

export interface JasValidationResult {
  isValid: boolean;
  errors: string[];
}

/**
 * 有機JAS 表示の適合判定。
 * - 多年生作物以外は転換期間 24ヶ月以上、多年生は 36ヶ月以上が原則。
 * - 化学合成農薬/化学肥料は原則禁止 (例外資材を除く)。
 * - 登録認証機関による認定が必要。
 */
export function validateJasOrganicLabel(p: JasOrganicProduct): JasValidationResult {
  const errors: string[] = [];
  if (p.category !== 'organic') {
    errors.push('有機JAS以外のカテゴリには本検証を適用しないでください');
    return { isValid: false, errors };
  }
  if (p.conversionMonths < 24) errors.push('有機転換期間が24ヶ月未満 (多年生は36ヶ月)');
  if (p.usedSyntheticPesticides) errors.push('化学合成農薬の使用が記録されています');
  if (p.usedSyntheticFertilizer) errors.push('化学肥料の使用が記録されています');
  if (!p.certifyingBody) errors.push('登録認証機関の認定がありません');
  if (!p.markAttached) errors.push('有機JASマークが添付されていません');
  return { isValid: errors.length === 0, errors };
}

/** 偽装表示禁止: 「有機」「オーガニック」「organic」等は認定なしには表示不可 */
export function isOrganicTermAllowed(text: string, certified: boolean): boolean {
  const banned = /(有機|オーガニック|organic|無農薬)/i;
  return certified || !banned.test(text);
}

// ===== HACCP (水産加工) =====

export const HACCP_CCP_FISHERY = [
  'CCP1: 受入時の鮮度確認 (K値/官能検査)',
  'CCP2: 解凍工程の温度管理 (中心温度 +10℃以下)',
  'CCP3: 加熱工程 (中心温度 75℃ 1分以上 or 同等)',
  'CCP4: 冷却 (90分以内に+10℃以下、最終-18℃以下)',
  'CCP5: 金属検出器通過 (Fe φ2.0 / SUS φ2.5)',
  'CCP6: 出荷前ヒスタミン検査 (50mg/kg未満)',
] as const;

export interface HaccpFisheryRecord {
  productKind: 'fresh' | 'frozen' | 'processed';
  thawCenterTempC?: number;
  heatCenterTempC?: number;
  heatHoldSeconds?: number;
  postCoolMinutes?: number;
  postCoolTempC?: number;
  metalDetected?: boolean;
  histamineMgPerKg?: number;
}

export function checkHaccpFishery(r: HaccpFisheryRecord): { ok: boolean; failedCcp: string[] } {
  const failed: string[] = [];
  if (r.thawCenterTempC !== undefined && r.thawCenterTempC > 10) failed.push('CCP2');
  if (r.productKind === 'processed') {
    if ((r.heatCenterTempC ?? 0) < 75) failed.push('CCP3 (加熱温度)');
    if ((r.heatHoldSeconds ?? 0) < 60) failed.push('CCP3 (加熱時間)');
    if ((r.postCoolMinutes ?? 0) > 90) failed.push('CCP4 (冷却時間)');
    if ((r.postCoolTempC ?? 99) > 10) failed.push('CCP4 (冷却温度)');
  }
  if (r.metalDetected) failed.push('CCP5');
  if ((r.histamineMgPerKg ?? 0) >= 50) failed.push('CCP6');
  return { ok: failed.length === 0, failedCcp: failed };
}

// ===== 森林法 =====

export type ForestProtectionKind =
  | '水源かん養'
  | '土砂流出防備'
  | '土砂崩壊防備'
  | '飛砂防備'
  | '防風'
  | '水害防備'
  | '潮害防備'
  | '干害防備'
  | '防雪'
  | '防霧'
  | '雪崩防止'
  | '落石防止'
  | '防火'
  | '魚つき'
  | '航行目標'
  | '保健'
  | '風致';

export const FOREST_PROTECTION_TYPES: ForestProtectionKind[] = [
  '水源かん養', '土砂流出防備', '土砂崩壊防備', '飛砂防備',
  '防風', '水害防備', '潮害防備', '干害防備', '防雪', '防霧',
  '雪崩防止', '落石防止', '防火', '魚つき', '航行目標', '保健', '風致',
];

export interface ForestDevelopment {
  /** 開発面積 (ha) */
  areaHa: number;
  /** 保安林指定 */
  protectionKind?: ForestProtectionKind;
  /** 国有林か */
  isNationalForest: boolean;
}

/**
 * 森林法 10条の2: 1ha 超の林地開発は都道府県知事の許可が必要。
 * 保安林は 0ha 含めて常に許可制 (森林法 27条 解除許可)。
 */
export function requireForestDevelopmentPermit(d: ForestDevelopment): {
  required: boolean;
  basis: string;
} {
  if (d.protectionKind) {
    return { required: true, basis: '保安林解除許可 (森林法27条)' };
  }
  if (d.areaHa > 1) {
    return { required: true, basis: '林地開発許可 (森林法10条の2: 1ha超)' };
  }
  return { required: false, basis: '許可不要 (1ha以下かつ保安林外)' };
}

// ===== 漁業法 =====

export type FisheryRightKind = 'teichi' | 'kukaku' | 'kyodo';

export interface FisheryRightDef {
  kind: FisheryRightKind;
  label: string;
  durationYears: number;
}

export const FISHERY_RIGHT_TYPES: Record<FisheryRightKind, FisheryRightDef> = {
  teichi: { kind: 'teichi', label: '定置漁業権 (大型定置網)', durationYears: 5 },
  kukaku: { kind: 'kukaku', label: '区画漁業権 (養殖)', durationYears: 5 },
  kyodo: { kind: 'kyodo', label: '共同漁業権 (採貝採藻等)', durationYears: 10 },
};

export function canExerciseFisheryRight(p: {
  rightKind: FisheryRightKind;
  isMember: boolean;
  hasGovernorPermission: boolean;
}): boolean {
  if (p.rightKind === 'kyodo') return p.isMember; // 漁協組合員のみ
  return p.hasGovernorPermission;
}

// ===== みどりの食料システム法 (R4施行) =====

export const MIDORI_TARGETS_2050 = {
  organicAreaPct: 25, // 耕地面積に占める有機農業 25%
  pesticideReductionPct: 50, // 化学農薬使用量 (リスク換算) 50%減
  fertilizerReductionPct: 30, // 化学肥料使用量 30%減
  foodLossReductionPct: 50, // 食品ロス 50%削減 (家庭由来)
  forestThinning: '主伐後再造林率 90%',
} as const;

export const MIDORI_TARGETS_2030 = {
  organicAreaPct: 6.3, // 中間目標
  pesticideReductionPct: 10,
  fertilizerReductionPct: 20,
} as const;

export function calcReductionProgress(p: {
  baselineKg: number;
  currentKg: number;
}): { reductionPct: number; achievedMidori2030: boolean } {
  if (p.baselineKg <= 0) return { reductionPct: 0, achievedMidori2030: false };
  const reductionPct = ((p.baselineKg - p.currentKg) / p.baselineKg) * 100;
  return { reductionPct, achievedMidori2030: reductionPct >= 10 };
}

// ===== 農薬取締法 =====

/** 食品衛生法に基づく一律基準 (登録外農薬の残留): 0.01 ppm */
export const PESTICIDE_RESIDUE_DEFAULT = 0.01;

export interface PesticideUsage {
  cropName: string;
  pesticideName: string;
  /** 散布回数 */
  applications: number;
  /** ラベル記載の最大散布回数 */
  labelMaxApplications: number;
  /** 収穫前日数 (実績) */
  preHarvestDays: number;
  /** ラベル記載の収穫前日数 */
  labelPreHarvestDays: number;
  /** 残留量 (ppm) */
  residuePpm: number;
  /** 食品衛生法に基づく作物-農薬別残留基準値 (ppm)。未登録なら undefined → 一律 0.01 ppm 適用 */
  mrlPpm?: number;
}

export function checkPesticideUsage(u: PesticideUsage): { compliant: boolean; violations: string[] } {
  const v: string[] = [];
  if (u.applications > u.labelMaxApplications) v.push('ラベル記載の最大散布回数超過');
  if (u.preHarvestDays < u.labelPreHarvestDays) v.push('収穫前日数 (PHI) 未達');
  const mrl = u.mrlPpm ?? PESTICIDE_RESIDUE_DEFAULT;
  if (u.residuePpm > mrl) v.push(`残留農薬基準超過 (${u.residuePpm} > ${mrl} ppm)`);
  return { compliant: v.length === 0, violations: v };
}

// ===== GAP (Good Agricultural Practice) =====

export type GapLevel = 'JGAP' | 'ASIAGAP' | 'GLOBALG.A.P';

export const GAP_LEVELS: Record<GapLevel, { label: string; scope: string }> = {
  JGAP: { label: '日本GAP', scope: '国内向け' },
  ASIAGAP: { label: 'アジアGAP', scope: 'アジア圏輸出' },
  'GLOBALG.A.P': { label: 'グローバルGAP', scope: '世界120カ国以上' },
};

export interface GapAudit {
  level: GapLevel;
  score: number; // 0-100
  /** 重大不適合 (Major) の件数 */
  majorNonconformities: number;
  /** 軽微不適合 (Minor) の件数 */
  minorNonconformities: number;
}

/**
 * 簡易判定: Major 0件 + 必須項目スコア >= 90 で認証相当。
 * 実際の認証は審査機関による。
 */
export function certifyGap(a: GapAudit): { certified: boolean; reason: string } {
  if (a.majorNonconformities > 0) return { certified: false, reason: '重大不適合あり (Major > 0)' };
  if (a.score < 90) return { certified: false, reason: `スコア不足 (${a.score} < 90)` };
  return { certified: true, reason: `${a.level} 認証相当` };
}

// ===== 6次産業化法 + 農商工連携 =====

export const SIXTH_INDUSTRY_PLAN_REQS = [
  '農林漁業者主体 (農林漁業者が主体的に関与)',
  '新商品開発・販路開拓・加工施設整備のいずれか',
  '農林水産物等を原材料として使用',
  '5年以内の事業計画 (収支見込み・売上目標含む)',
  '雇用増・所得増の目標 (定量的指標)',
] as const;

export interface SixthIndustryPlan {
  applicantKind: 'farmer' | 'fisher' | 'forester' | 'cooperative';
  productKinds: string[]; // 取扱う農林水産物
  newProductsPlanned: boolean;
  marketExpansionPlanned: boolean;
  facilityInvestmentJpy: number;
  planYears: number;
  expectedSalesGrowthPct: number;
  expectedJobsAdded: number;
}

export function build6thIndustryPlan(p: SixthIndustryPlan): {
  eligible: boolean;
  reasons: string[];
  estimatedSubsidyJpy: number;
} {
  const reasons: string[] = [];
  if (p.productKinds.length === 0) reasons.push('農林水産物の指定が必要');
  if (!p.newProductsPlanned && !p.marketExpansionPlanned && p.facilityInvestmentJpy <= 0)
    reasons.push('新商品/販路/施設整備のいずれか必須');
  if (p.planYears > 5) reasons.push('事業計画は5年以内');
  if (p.expectedSalesGrowthPct <= 0 || p.expectedJobsAdded < 0)
    reasons.push('売上・雇用の定量目標が必要');
  // 6次産業化補助金の概算 (1/2 補助、上限 5,000 万円: 公募により異なる)
  const estimated = Math.min(Math.floor(p.facilityInvestmentJpy / 2), 50_000_000);
  return { eligible: reasons.length === 0, reasons, estimatedSubsidyJpy: estimated };
}
