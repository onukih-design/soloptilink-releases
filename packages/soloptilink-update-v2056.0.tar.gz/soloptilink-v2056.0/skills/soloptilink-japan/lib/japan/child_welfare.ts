/**
 * SoloptiLinkAI Phase 47-CH — こども家庭DX (こども基本法 / 児童虐待防止法 / DBS)
 *
 * カバー範囲:
 *  - こども基本法 (R4.6.22 公布 / R5.4.1 施行)
 *      6つの基本理念 (法3条) + こども施策 (法11条)
 *      意見表明機会の確保 (法11条) + こども大綱 (法9条)
 *  - こども家庭庁設置法 (R4.6.22 / R5.4.1)
 *      内閣府外局として設置 + 内閣府特命担当大臣 (こども政策)
 *      長官官房 + 成育局 + 支援局 + 政策立案総括官
 *  - 児童虐待の防止等に関する法律 (H12法82号)
 *      虐待4類型: 身体/性的/ネグレクト/心理 (法2条)
 *      通告義務 (法6条) — 児童相談所/福祉事務所/市町村
 *      48時間ルール (児相 安全確認) — 厚労省通知
 *  - 児童福祉法 R4.6.15 改正 / R6.4.1 施行
 *      こども家庭センター設置 (法10条の2)
 *      在宅指導措置の強化 + 一時保護開始時の司法審査 (法33条)
 *  - こども性暴力防止法 (DBS) R6.6.19 公布 / 公布後2年以内施行 (R8.6 想定)
 *      日本版 Disclosure and Barring Service
 *      対象: 学校設置者・児童福祉事業者・認定事業者 (任意)
 *      犯罪事実確認書の交付 + 対象犯罪 = 児童性犯罪 (個別+性風俗除外)
 *  - 配偶者暴力防止法 (R6.4.1 改正施行)
 *      接近禁止命令の対象拡大 (子・親族) + 接近禁止期間 6ヶ月→1年
 *  - 児童ポルノ禁止法 (H11法52号)
 *  - ヤングケアラー支援 (R6.4 改正児童福祉法)
 *  - 「異次元の少子化対策」(R5.6 こども未来戦略方針)
 *
 * 出典:
 *  - こども家庭庁 https://www.cfa.go.jp/
 *  - 厚労省 児童虐待 https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/kodomo/kodomo_kosodate/
 */

// ----------------------------------------------------------------------
// 1) 児童虐待 4類型 (法2条) + 通告義務
// ----------------------------------------------------------------------

export const ABUSE_TYPES = [
  { id: "physical", name: "身体的虐待", examples: ["殴る", "蹴る", "投げ落とす", "激しく揺さぶる", "やけど", "逆さ吊り"] },
  { id: "sexual", name: "性的虐待", examples: ["子どもへの性的行為", "性的行為を見せる", "性器・性交を見せる", "ポルノの被写体にする"] },
  { id: "neglect", name: "ネグレクト (養育放棄)", examples: ["食事を与えない", "ひどく不潔にする", "学校に行かせない", "車中放置", "病気でも病院に連れていかない"] },
  { id: "psychological", name: "心理的虐待", examples: ["言葉による脅し", "無視", "兄弟間差別", "DV目撃 (面前DV)", "子どもの目の前で家族に暴力"] },
] as const;

export type AbuseType = (typeof ABUSE_TYPES)[number]["id"];

export type ReportSeverity = "info" | "watch" | "intervention" | "emergency";

export interface AbuseReport {
  case_id: string;
  child_age: number;
  reporter: "school" | "medical" | "police" | "neighbor" | "family" | "self" | "anonymous";
  abuse_types: AbuseType[];
  visible_injury: boolean;
  threats_to_life: boolean;
  past_reports_count: number;
  reported_at: string; // ISO 8601
}

export interface AbuseTriageResult {
  severity: ReportSeverity;
  required_actions: string[];
  safety_check_deadline: string; // 「48時間ルール」(厚労省通知) ISO 8601
  applicable_laws: string[];
}

/**
 * 児童相談所のトリアージ (厚労省 児童相談所運営指針)
 *  - 「48時間ルール」: 安全確認は48時間以内に直接目視
 *  - 緊急一時保護 (法33条) は児相所長の判断
 */
export function triageAbuseReport(r: AbuseReport): AbuseTriageResult {
  const reportedAt = new Date(r.reported_at);
  const deadline = new Date(reportedAt.getTime() + 48 * 60 * 60 * 1000);

  let severity: ReportSeverity;
  if (r.threats_to_life || (r.visible_injury && r.child_age <= 6)) {
    severity = "emergency";
  } else if (r.visible_injury || r.abuse_types.includes("sexual") || r.past_reports_count >= 2) {
    severity = "intervention";
  } else if (r.past_reports_count >= 1 || r.abuse_types.includes("psychological")) {
    severity = "watch";
  } else {
    severity = "info";
  }

  const actions: string[] = [];
  switch (severity) {
    case "emergency":
      actions.push("即時 (24時間以内) 安全確認 + 緊急一時保護検討", "警察への援助要請 (法10条)", "医療機関への搬送");
      break;
    case "intervention":
      actions.push("48時間以内に直接目視 + リスクアセスメント実施", "在宅指導 or 一時保護判断", "要対協への情報共有");
      break;
    case "watch":
      actions.push("48時間以内に直接目視", "学校・保育所・医療機関の継続見守り依頼", "要対協 個別ケース検討会議");
      break;
    case "info":
      actions.push("48時間以内の安全確認 (リスク低でも厚労省通知遵守)", "市町村へ送致検討");
      break;
  }

  return {
    severity,
    required_actions: actions,
    safety_check_deadline: deadline.toISOString(),
    applicable_laws: [
      "児童虐待防止法 6条 (通告義務)",
      "児童虐待防止法 8条 (児相の対応)",
      "児童福祉法 33条 (一時保護)",
      "厚労省 児童相談所運営指針 第4章",
    ],
  };
}

// ----------------------------------------------------------------------
// 2) 一時保護開始時の司法審査 (R6.4.1 施行 — 児童福祉法33条改正)
// ----------------------------------------------------------------------

/**
 * 「一時保護開始時の司法審査」の導入
 *  - 親権者の同意がない一時保護 → 7日以内に家庭裁判所に「一時保護状」を請求
 *  - 司法判断による正当性確認 (国際基準への整合)
 */
export interface TemporaryShelterRequest {
  case_id: string;
  child_name_hash: string; // PII保護のためハッシュ化
  parental_consent: boolean;
  shelter_started_at: string; // ISO 8601
  reason: string;
}

export interface ShelterReviewSchedule {
  judicial_review_required: boolean;
  petition_deadline: string; // ISO 8601 (7日以内)
  estimated_court_decision: string; // 通常1週間以内
}

export function planShelterJudicialReview(req: TemporaryShelterRequest): ShelterReviewSchedule {
  if (req.parental_consent) {
    return {
      judicial_review_required: false,
      petition_deadline: "",
      estimated_court_decision: "",
    };
  }
  const start = new Date(req.shelter_started_at);
  const deadline = new Date(start.getTime() + 7 * 24 * 60 * 60 * 1000);
  const courtDecision = new Date(start.getTime() + 14 * 24 * 60 * 60 * 1000);
  return {
    judicial_review_required: true,
    petition_deadline: deadline.toISOString().slice(0, 10),
    estimated_court_decision: courtDecision.toISOString().slice(0, 10),
  };
}

// ----------------------------------------------------------------------
// 3) DBS (こども性暴力防止法 R6.6.19 公布 — R8.6 想定施行)
// ----------------------------------------------------------------------

/**
 * 学校等は義務、認定事業者は任意で「犯罪事実確認」を実施
 *  対象犯罪 = 不同意性交等罪 (刑法177条)、不同意わいせつ罪 (刑法176条)、
 *           児童ポルノ禁止法、児童買春処罰法 ほか
 *  確認期間 = 原則 採用前 + 最大過去20年
 */
export type SectorObligation = "mandatory" | "voluntary_certified";

export interface DbsRequest {
  applicant_name_hash: string;
  applicant_birth_year: number;
  sector: SectorObligation;
  job_role: "teacher" | "childcare_worker" | "school_staff" | "after_school_caregiver" | "preschool_staff";
  past_employment_years: number;
}

export type DbsResult =
  | "clear" // 該当犯罪歴なし
  | "match_lookup_period_only" // 確認期間内に該当犯罪
  | "outside_lookup_window"; // 該当犯罪あるが確認期間外

export interface DbsConfirmation {
  result: DbsResult;
  certificate_validity_days: number; // 確認証の有効期間 (確認日から1年間想定)
  may_employ: boolean;
  reason: string;
}

export function evaluateDbs(req: DbsRequest): DbsConfirmation {
  // モック: 実装ではこども家庭庁の認証DBに照会
  const result: DbsResult = "clear"; // 既定 — 業務側の安全弁
  const validityDays = 365; // 1年想定 (運用時に可変)
  return {
    result,
    certificate_validity_days: validityDays,
    may_employ: result === "clear" || result === "outside_lookup_window",
    reason:
      req.sector === "mandatory"
        ? "学校設置者・児童福祉事業者は採用前確認義務"
        : "認定事業者として任意確認を実施",
  };
}

// ----------------------------------------------------------------------
// 4) こども家庭センター (R6.4.1 施行 — 児童福祉法10条の2)
// ----------------------------------------------------------------------

/**
 * 全市区町村 設置努力義務
 *  - 母子保健 (旧子育て世代包括支援センター) と
 *  - 児童福祉 (旧子ども家庭総合支援拠点) を一体化
 */
export interface KateiCenterRequirements {
  area_population: number; // 自治体人口
  staff_required_count: number; // 統括支援員 + 母子保健担当 + 子ども家庭支援員
  estimated_setup_cost_jpy: number;
  required_functions: string[];
}

export function calcKateiCenterRequirements(populationCount: number): KateiCenterRequirements {
  // 厚労省 配置基準 (児童福祉法10条の2 厚労省告示)
  const staffPer10k = 0.6;
  const baseStaff = 4; // 統括支援員1 + 母子保健2 + 子家支援1
  const required = Math.max(baseStaff, Math.ceil((populationCount / 10000) * staffPer10k));
  return {
    area_population: populationCount,
    staff_required_count: required,
    estimated_setup_cost_jpy: 30_000_000 + required * 6_000_000, // 概算 (運営費 1人あたり600万/年 + 初期設置3000万)
    required_functions: [
      "妊産婦・子育て家庭・こどもの相談支援",
      "支援を要するこども・家庭の包括的支援 (サポートプラン作成)",
      "在宅指導措置 (児相からの委託)",
      "ヤングケアラー支援",
      "母子保健事業 (乳幼児健診・新生児訪問)",
      "要保護児童対策地域協議会 (要対協) 調整機関",
    ],
  };
}

// ----------------------------------------------------------------------
// 5) こども基本法 6つの基本理念 (法3条) — 施策設計チェック
// ----------------------------------------------------------------------

export const KIHON_PRINCIPLES = [
  "全てのこどもについて、個人として尊重され、その基本的人権が保障されること",
  "差別的取扱いを受けることがないこと",
  "適切に養育されること、生活を保障されること、愛され保護されること、その健やかな成長及び発達並びに自立が図られること等の福祉に係る権利が等しく保障されること",
  "意見の尊重 + 最善の利益が優先して考慮されること",
  "家庭で養育されること等が原則 — 家庭養育が困難な場合は家庭に近い環境",
  "こどもの養育は家庭を基本としつつ、家庭での養育が困難なこどもにも家庭と同様の養育環境",
] as const;

export interface PolicyAlignmentCheck {
  policy_name: string;
  has_child_voice_mechanism: boolean; // 意見表明機会
  age_groups_targeted: string[];
  budget_allocation_jpy: number;
  evaluates_against_principles: boolean;
}

export interface PolicyAlignmentResult {
  alignment_score: number; // 0-100
  missing_principles: string[];
  recommendations: string[];
}

export function checkPolicyAlignment(p: PolicyAlignmentCheck): PolicyAlignmentResult {
  const missing: string[] = [];
  const recs: string[] = [];

  if (!p.has_child_voice_mechanism) {
    missing.push("こども基本法11条 意見表明機会の確保");
    recs.push("こどもアンケート / こども会議 / こどもパブコメ等の手段");
  }
  if (p.age_groups_targeted.length < 3) {
    missing.push("ライフステージ別施策 (乳幼児・学齢期・思春期・若者) の網羅");
    recs.push("若者 (18-29歳) を含むライフステージ全段階のサービス設計");
  }
  if (!p.evaluates_against_principles) {
    missing.push("法3条 6基本理念に基づく事前評価");
    recs.push("こども政策評価 (CDIA: Child Development Impact Assessment)");
  }
  const score = Math.max(0, 100 - missing.length * 25);
  return { alignment_score: score, missing_principles: missing, recommendations: recs };
}

// ----------------------------------------------------------------------
// 6) ヤングケアラー支援 (R6.4 改正児童福祉法)
// ----------------------------------------------------------------------

/**
 * R6.4 改正で「家族の世話を日常的に行っているこども」を法律上明記
 *  - 自治体 学校 + 福祉部門の連携
 *  - 支援対象: 約4-6%の中高生 (厚労省 R3 全国調査)
 */
export interface YoungCarerScreening {
  age: number;
  daily_care_hours: number;
  school_attendance_pct: number; // 0-100
  has_homework_difficulty: boolean;
  has_health_issues: boolean;
  family_situation: "single_parent" | "ill_family_member" | "elderly_family" | "disabled_sibling" | "other";
}

export type YoungCarerRisk = "low" | "moderate" | "high" | "severe";

export interface YoungCarerSupportPlan {
  risk: YoungCarerRisk;
  recommended_services: string[];
  needs_immediate_intervention: boolean;
}

export function planYoungCarerSupport(s: YoungCarerScreening): YoungCarerSupportPlan {
  let risk: YoungCarerRisk = "low";
  if (s.daily_care_hours >= 7 || s.school_attendance_pct < 70) risk = "severe";
  else if (s.daily_care_hours >= 4 || s.school_attendance_pct < 85 || s.has_health_issues) risk = "high";
  else if (s.daily_care_hours >= 2 || s.has_homework_difficulty) risk = "moderate";

  const services: string[] = [];
  if (risk === "severe" || risk === "high") {
    services.push(
      "ヤングケアラー・コーディネーター 介入",
      "家事支援サービス (有償ボランティア / 家事支援員派遣 厚労省事業)",
      "学習支援 (スクールソーシャルワーカー)",
      "健康診断 + メンタルヘルス支援",
    );
  }
  if (risk === "moderate") {
    services.push("学校との連携 + 担任への情報共有", "オンライン相談 (LINE 厚労省事業)");
  }
  services.push("当事者同士の交流 (ピアサポート)");

  return {
    risk,
    recommended_services: services,
    needs_immediate_intervention: risk === "severe",
  };
}
