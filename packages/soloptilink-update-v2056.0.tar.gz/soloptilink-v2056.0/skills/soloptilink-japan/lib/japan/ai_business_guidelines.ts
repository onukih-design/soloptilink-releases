/**
 * SoloptiLinkAI Phase 45 — AI事業者ガイドライン対応
 *
 * - 経産省・総務省「AI事業者ガイドライン」第1.0版 (R6.4.19) / 第1.1版 (R7.3.28)
 * - 広島AIプロセス成果物 (G7 R5.10.30 / R5.12.1 最終 / R7.2 報告枠組み運用)
 * - AI法 (人工知能関連技術の研究開発及び活用の推進に関する法律)
 *   - 公布: R7.6.4 / 全面施行: R7.9.1 / 罰則無 (基本法)
 * - AI戦略本部 → AI戦略専門調査会
 * - 既存法整合: 個情法R5改正 / 著作権法30条の4 / 不競法 / PL法
 *
 * EU AI Act 4段階リスク準拠 (国内整合):
 *  - unacceptable / high / limited / minimal
 *
 * SoT:
 *  - https://www.meti.go.jp/shingikai/mono_info_service/ai_shakai_jisso/pdf/20240419_1.pdf
 *  - https://www.soumu.go.jp/main_sosiki/kenkyu/ai_network/02ryutsu20_04000019.html
 */

export const AI_GUIDELINE_VERSION = "v1.1";
export const AI_GUIDELINE_PUBLISHED = "2025-03-28";
export const AI_LAW_EFFECTIVE = "2025-09-01";

export const AI_SUBJECTS = ["developer", "provider", "business_user", "operational_user", "end_user"] as const;
export type AISubject = (typeof AI_SUBJECTS)[number];

export const COMMON_PRINCIPLES = [
  "human_centric",
  "safety",
  "fairness",
  "privacy",
  "security",
  "transparency",
  "accountability",
  "education",
  "fair_competition",
  "innovation",
] as const;
export type Principle = (typeof COMMON_PRINCIPLES)[number];

export const RISK_LEVELS = ["minimal", "limited", "high", "unacceptable"] as const;
export type RiskLevel = (typeof RISK_LEVELS)[number];

export const HIROSHIMA_PROCESS_ITEMS = 12;

export const HIGH_RISK_DOMAINS = [
  "employment",
  "education",
  "healthcare",
  "judiciary",
  "law_enforcement",
  "critical_infrastructure",
  "credit_scoring",
  "social_welfare",
  "biometric_id",
  "border_management",
  "elections",
  "public_safety",
] as const;
export type HighRiskDomain = (typeof HIGH_RISK_DOMAINS)[number];

export const UNACCEPTABLE_USES = [
  "subliminal_manipulation",
  "social_scoring_government",
  "exploiting_vulnerabilities",
  "biometric_categorization_protected",
  "real_time_biometric_public_space_law_enforcement",
  "untargeted_facial_db_scraping",
  "emotion_recognition_workplace_education",
  "predictive_policing_individual",
] as const;
export type UnacceptableUse = (typeof UNACCEPTABLE_USES)[number];

export interface UseCase {
  purpose: string;
  domain: HighRiskDomain | "general";
  data_types: ("personal" | "sensitive" | "biometric" | "anonymized")[];
  decision_impact: "advisory" | "automated_human_review" | "fully_automated";
  affects_rights: boolean;
  prohibited_use?: UnacceptableUse;
}

export interface AIIADocument {
  purpose_described: boolean;
  data_described: boolean;
  model_described: boolean;
  output_described: boolean;
  affected_persons_described: boolean;
  rights_impact_assessed: boolean;
  misjudgment_impact_assessed: boolean;
  monitoring_plan: boolean;
  complaint_window: boolean;
  retraining_policy: boolean;
  vendor_management: boolean;
  incident_response: boolean;
  disposal_policy: boolean;
}
export const AIIA_REQUIRED_13 = [
  "purpose_described",
  "data_described",
  "model_described",
  "output_described",
  "affected_persons_described",
  "rights_impact_assessed",
  "misjudgment_impact_assessed",
  "monitoring_plan",
  "complaint_window",
  "retraining_policy",
  "vendor_management",
  "incident_response",
  "disposal_policy",
] as const;

export interface DatasetStats {
  gender_skew_pct: number;
  age_skew_pct: number;
  region_skew_pct: number;
  attribute_skew_pct: number;
}

export interface ModelCardInput {
  name: string;
  version: string;
  training_data_summary: string;
  evaluation_metrics: Record<string, number>;
  bias_check: DatasetStats;
  intended_use: string;
  limitations: string;
  contact: string;
  updated_at: string;
  copyright_30_4_compliance: boolean;
  pii_compliance: boolean;
  hiroshima_process_checklist: boolean[];
}

export type AIErrorCode =
  | "AIIA_INCOMPLETE"
  | "RISK_UNACCEPTABLE_USE"
  | "BIAS_FAIL_30PCT"
  | "BIAS_WARN_15PCT"
  | "MODEL_CARD_MISSING_FIELD"
  | "HIROSHIMA_INCOMPLETE";

export interface Finding {
  code: AIErrorCode;
  rule: string;
  severity: "info" | "warning" | "violation";
  hint: string;
}

/** リスク4段階分類 */
export function assessAIRisk(useCase: UseCase): { level: RiskLevel; reason: string } {
  if (useCase.prohibited_use) {
    return { level: "unacceptable", reason: `禁止用途 (${useCase.prohibited_use})。EU AI Act準拠で許容不可。` };
  }
  if (useCase.affects_rights || (HIGH_RISK_DOMAINS as readonly string[]).includes(useCase.domain)) {
    return { level: "high", reason: `権利影響あり or 高リスク領域 (${useCase.domain})。適合性評価+AIIA+モデルカード必須。` };
  }
  if (useCase.decision_impact === "fully_automated" || useCase.data_types.includes("personal")) {
    return { level: "limited", reason: "完全自動化判断 or 個人データ利用。透明性義務あり。" };
  }
  return { level: "minimal", reason: "極小リスク。自主管理。" };
}

/** AI影響度評価 (AIIA) 13項目チェック */
export function validateAIIA(doc: AIIADocument): { ok: boolean; missing: string[]; findings: Finding[] } {
  const missing: string[] = [];
  for (const k of AIIA_REQUIRED_13) {
    if (!doc[k as keyof AIIADocument]) missing.push(k);
  }
  const findings: Finding[] = missing.length
    ? [
        {
          code: "AIIA_INCOMPLETE",
          rule: "AI事業者ガイドライン v1.1 (経産省・総務省 R7.3.28)",
          severity: "violation",
          hint: `AI影響度評価 13項目のうち未記載: ${missing.join(", ")}`,
        },
      ]
    : [];
  return { ok: missing.length === 0, missing, findings };
}

/** データセットバイアス検査 */
export function checkBiasDataset(s: DatasetStats): { level: "ok" | "warn" | "fail"; findings: Finding[] } {
  const max = Math.max(s.gender_skew_pct, s.age_skew_pct, s.region_skew_pct, s.attribute_skew_pct);
  const findings: Finding[] = [];
  if (max > 30) {
    findings.push({
      code: "BIAS_FAIL_30PCT",
      rule: "AI事業者ガイドライン 共通指針③公平性",
      severity: "violation",
      hint: `データセット属性偏差 ${max}% > 30%。リバランス or サブグループ評価必須。`,
    });
    return { level: "fail", findings };
  }
  if (max > 15) {
    findings.push({
      code: "BIAS_WARN_15PCT",
      rule: "AI事業者ガイドライン 共通指針③公平性",
      severity: "warning",
      hint: `データセット属性偏差 ${max}% > 15%。バイアス低減策検討推奨。`,
    });
    return { level: "warn", findings };
  }
  return { level: "ok", findings };
}

/** モデルカード生成と検証 */
export function generateModelCard(m: ModelCardInput): { ok: boolean; card: string; findings: Finding[] } {
  const findings: Finding[] = [];
  const missingFields: string[] = [];

  if (!m.name) missingFields.push("name");
  if (!m.version) missingFields.push("version");
  if (!m.training_data_summary) missingFields.push("training_data_summary");
  if (!m.intended_use) missingFields.push("intended_use");
  if (!m.limitations) missingFields.push("limitations");
  if (!m.contact) missingFields.push("contact");
  if (!m.copyright_30_4_compliance) missingFields.push("copyright_30_4_compliance");
  if (!m.pii_compliance) missingFields.push("pii_compliance");

  const hiroshimaCount = (m.hiroshima_process_checklist || []).filter(Boolean).length;
  if (hiroshimaCount < HIROSHIMA_PROCESS_ITEMS) {
    findings.push({
      code: "HIROSHIMA_INCOMPLETE",
      rule: "広島AIプロセス国際指針 (G7 R5.12.1最終)",
      severity: "warning",
      hint: `広島プロセス12項目のうち ${hiroshimaCount}/12 のみ充足。残り ${HIROSHIMA_PROCESS_ITEMS - hiroshimaCount}項目を点検。`,
    });
  }

  for (const f of missingFields) {
    findings.push({
      code: "MODEL_CARD_MISSING_FIELD",
      rule: "AI事業者ガイドライン v1.1 (モデルカード推奨フォーマット)",
      severity: "violation",
      hint: `モデルカード必須項目「${f}」が欠落。`,
    });
  }

  const card = [
    `# Model Card: ${m.name} (${m.version})`,
    `## Training Data\n${m.training_data_summary}`,
    `## Evaluation Metrics\n${JSON.stringify(m.evaluation_metrics, null, 2)}`,
    `## Bias Check\n${JSON.stringify(m.bias_check, null, 2)}`,
    `## Intended Use\n${m.intended_use}`,
    `## Limitations\n${m.limitations}`,
    `## Contact\n${m.contact}`,
    `## Updated\n${m.updated_at}`,
    `## Copyright (著作権法30条の4) Compliance: ${m.copyright_30_4_compliance ? "YES" : "NO"}`,
    `## PII (個情法R5改正) Compliance: ${m.pii_compliance ? "YES" : "NO"}`,
    `## Hiroshima Process: ${hiroshimaCount}/12`,
  ].join("\n\n");

  return { ok: findings.length === 0, card, findings };
}

/** 広島AIプロセス12項目の確認 */
export function validateHiroshimaProcess(checklist: boolean[]): { ok: boolean; satisfied: number; total: number } {
  const satisfied = checklist.filter(Boolean).length;
  return { ok: satisfied === HIROSHIMA_PROCESS_ITEMS, satisfied, total: HIROSHIMA_PROCESS_ITEMS };
}

/** 関連法令との整合チェック */
export function checkLegalAlignment(input: {
  uses_personal_data: boolean;
  has_pii_consent: boolean;
  uses_copyrighted_for_training: boolean;
  uses_30_4_exception: boolean;
  has_pl_safety_doc: boolean;
}): { ok: boolean; issues: string[] } {
  const issues: string[] = [];
  if (input.uses_personal_data && !input.has_pii_consent) issues.push("個情法R5改正: 個人データ利用に同意/法的根拠不足");
  if (input.uses_copyrighted_for_training && !input.uses_30_4_exception) issues.push("著作権法30条の4: 非享受目的の機械学習例外要件未確認");
  if (!input.has_pl_safety_doc) issues.push("製造物責任 (PL): AI組込み製品の欠陥責任ドキュメント未整備");
  return { ok: issues.length === 0, issues };
}

export function selfCheck(): { ok: boolean; checks: Array<{ name: string; pass: boolean }> } {
  const high = assessAIRisk({ purpose: "採用スクリーニング", domain: "employment", data_types: ["personal"], decision_impact: "fully_automated", affects_rights: true });
  const minimal = assessAIRisk({ purpose: "社内文書要約", domain: "general", data_types: [], decision_impact: "advisory", affects_rights: false });
  const unacc = assessAIRisk({ purpose: "サブリミナル広告", domain: "general", data_types: [], decision_impact: "fully_automated", affects_rights: false, prohibited_use: "subliminal_manipulation" });

  const aiia = validateAIIA({
    purpose_described: true, data_described: true, model_described: true, output_described: true,
    affected_persons_described: true, rights_impact_assessed: true, misjudgment_impact_assessed: true,
    monitoring_plan: true, complaint_window: true, retraining_policy: true,
    vendor_management: true, incident_response: true, disposal_policy: true,
  });
  const aiiaMissing = validateAIIA({
    purpose_described: true, data_described: false, model_described: true, output_described: true,
    affected_persons_described: true, rights_impact_assessed: true, misjudgment_impact_assessed: true,
    monitoring_plan: true, complaint_window: true, retraining_policy: true,
    vendor_management: true, incident_response: true, disposal_policy: false,
  });

  const checks = [
    { name: "5主体定数", pass: AI_SUBJECTS.length === 5 },
    { name: "10共通指針", pass: COMMON_PRINCIPLES.length === 10 },
    { name: "リスク4段階", pass: RISK_LEVELS.length === 4 },
    { name: "高リスク雇用 → high", pass: high.level === "high" },
    { name: "minimal判定", pass: minimal.level === "minimal" },
    { name: "禁止用途 → unacceptable", pass: unacc.level === "unacceptable" },
    { name: "AIIA13項目満点", pass: aiia.ok === true },
    { name: "AIIA欠落検出", pass: aiiaMissing.ok === false && aiiaMissing.missing.length === 2 },
    { name: "バイアス30%超 fail", pass: checkBiasDataset({ gender_skew_pct: 35, age_skew_pct: 5, region_skew_pct: 10, attribute_skew_pct: 5 }).level === "fail" },
    { name: "AI法施行日", pass: AI_LAW_EFFECTIVE === "2025-09-01" },
  ];
  return { ok: checks.every((c) => c.pass), checks };
}
