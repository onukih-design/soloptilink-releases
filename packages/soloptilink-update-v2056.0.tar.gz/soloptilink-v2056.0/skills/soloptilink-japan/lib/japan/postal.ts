/**
 * 郵便番号 → 住所補完ユーティリティ
 * 日本郵便公開CSV (KEN_ALL) 由来のデータで補完できる薄いラッパー。
 * 実運用では api.zipcode-jp.com や zipcloud を利用するか、KEN_ALL.csv を同梱する。
 */

export interface Address {
  postalCode: string;
  prefecture: string;
  city: string;
  town: string;
}

/**
 * 郵便番号APIを呼び出す (zipcloud の互換エンドポイントを想定)
 */
export async function lookup(postalCode: string): Promise<Address | null> {
  const normalized = postalCode.replace(/[^0-9]/g, '');
  if (normalized.length !== 7) return null;
  try {
    const res = await fetch(`https://zipcloud.ibsnet.co.jp/api/search?zipcode=${normalized}`);
    const data = await res.json();
    if (!data.results || data.results.length === 0) return null;
    const r = data.results[0];
    return {
      postalCode: `${normalized.slice(0, 3)}-${normalized.slice(3)}`,
      prefecture: r.address1,
      city: r.address2,
      town: r.address3,
    };
  } catch {
    return null;
  }
}

/**
 * 都道府県コード ↔ 名称
 */
export const PREFECTURES = [
  '北海道', '青森県', '岩手県', '宮城県', '秋田県', '山形県', '福島県',
  '茨城県', '栃木県', '群馬県', '埼玉県', '千葉県', '東京都', '神奈川県',
  '新潟県', '富山県', '石川県', '福井県', '山梨県', '長野県',
  '岐阜県', '静岡県', '愛知県', '三重県',
  '滋賀県', '京都府', '大阪府', '兵庫県', '奈良県', '和歌山県',
  '鳥取県', '島根県', '岡山県', '広島県', '山口県',
  '徳島県', '香川県', '愛媛県', '高知県',
  '福岡県', '佐賀県', '長崎県', '熊本県', '大分県', '宮崎県', '鹿児島県', '沖縄県',
];

export function prefectureCode(name: string): number {
  return PREFECTURES.indexOf(name) + 1;
}

export function prefectureName(code: number): string | null {
  return PREFECTURES[code - 1] || null;
}
