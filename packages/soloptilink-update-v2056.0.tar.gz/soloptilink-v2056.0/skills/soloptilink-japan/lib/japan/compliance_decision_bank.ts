/**
 * SoloptiLinkAI Phase 45 — Compliance Decision Bank (判例・通達・ガイドラインRAG)
 *
 * 既存 case_law.ts は判例 7 件 (ハマキョウレックス・大阪医科薬科・ベネッセ等) のみ。
 * 本モジュールはそれを拡張し、以下を統合 RAG-ready 形式で提供する:
 *  - 重要判例 30 件 (労働法 / 個情法 / 下請法 / 著作権 / 知財 / 公正取引)
 *  - 行政通達・ガイドライン (個情法委員会 / 公取委 / 厚労省 / 経産省 / 総務省 / 国交省)
 *  - 業種別解釈通達 (建設 / 医療 / 介護 / 金融 / 物流 / 教育)
 *  - 内部統制ベストプラクティス (J-SOX / Pマーク / ISMS)
 *
 * 設計思想:
 *  - 判例ID は事件番号 (最高裁/高裁/地裁) ベース、検索可能
 *  - 各エントリは 「事案 → 争点 → 判旨 → 実務影響 → 関連法令」 の固定構造
 *  - シナリオ→該当判例マッチング (ユーザー: "派遣社員の同一労働同一賃金" → 該当判例3件)
 *  - 損害賠償ベンチマーク (個情法漏えい1名500-3000円, ベネッセ500円事案 等)
 *
 * なぜClaude Codeに作れないか:
 *  - 日本判例DB (D1-Law / Westlaw Japan / TKC) は有償・日本語専用
 *  - 行政通達は省庁ごとに分散・PDFで非構造化
 *  - 本モジュールは「日本実務家が日常で使う重要判例30件」を厳選し、
 *    実務影響と損害賠償相場を含めて構造化済
 */

// ───────────────────────────────────────────────
// 型定義
// ───────────────────────────────────────────────

export type LawArea =
  | "labor" // 労働法
  | "personal_info" // 個情法
  | "subcontract" // 下請法
  | "copyright" // 著作権
  | "trademark" // 商標
  | "patent" // 特許
  | "design" // 意匠
  | "antitrust" // 独禁法
  | "consumer" // 消費者法
  | "construction" // 建設業法
  | "medical" // 医療法
  | "tax" // 税務
  | "fiea" // 金商法
  | "ai_governance" // AI 関連
  | "trade_secret"; // 不競法

export type CourtLevel = "supreme" | "high" | "district" | "summary" | "tribunal";

export interface CaseLawEntry {
  case_id: string; // 例: "saikoH28-O-2076" or "tokyoH30-Wa-12345"
  short_name: string; // 通称 (ハマキョウレックス事件 等)
  court: CourtLevel;
  decision_date: string; // YYYY-MM-DD
  law_areas: LawArea[];
  facts: string; // 事案概要 (200-500字)
  issues: string[]; // 争点
  ruling: string; // 判旨 (判決の核心)
  practical_impact: string; // 実務への影響
  related_laws: string[]; // 関連法令
  damage_benchmark?: {
    per_person_jpy: number; // 1名あたり損害賠償額 (個情法漏えい等)
    total_jpy?: number;
    note: string;
  };
  citation: string; // 出典 (民集/集民/判時/判タ/裁判所HP)
  hit_keywords: string[]; // 検索用キーワード
}

export interface AdministrativeGuideline {
  guideline_id: string;
  title: string;
  issuer: "ppc" | "jftc" | "mhlw" | "meti" | "mlit" | "mof" | "fsa" | "mext" | "soumu" | "ministry_other";
  issued_date: string;
  last_revised?: string;
  law_areas: LawArea[];
  summary: string;
  key_provisions: string[];
  url_official?: string;
  binding_strength: "binding" | "guidance" | "advisory";
}

// ───────────────────────────────────────────────
// 判例データ (重要 30 件 厳選)
// ───────────────────────────────────────────────

export const KEY_JP_CASES: CaseLawEntry[] = [
  // ─── 労働法 ───
  {
    case_id: "saikoH30-O-1768",
    short_name: "ハマキョウレックス事件",
    court: "supreme",
    decision_date: "2018-06-01",
    law_areas: ["labor"],
    facts:
      "有期契約のドライバーが、無期契約ドライバーとの間の労働条件 (無事故手当・作業手当・通勤手当等) の相違が 旧労契法20条 (現パート有期法8条) に違反するとして提訴。",
    issues: ["有期労働者と無期労働者の労働条件相違が「不合理」と認められるか"],
    ruling:
      "労働条件の相違は、職務内容・人材活用の仕組み・その他の事情を考慮して判断。無事故手当・作業手当・給食手当・通勤手当の相違は不合理。住宅手当・皆勤手当の相違は合理的。",
    practical_impact:
      "賃金項目ごとに「制度趣旨」を明確化し、有期/無期で支給差を設ける場合は趣旨に沿う合理的理由が必要。手当別個別判断アプローチ。",
    related_laws: ["パート有期法8条", "労契法20条 (旧)"],
    citation: "最判平30・6・1 民集72巻2号88頁",
    hit_keywords: ["同一労働同一賃金", "有期", "無期", "手当", "ドライバー", "通勤手当"],
  },
  {
    case_id: "saikoH30-O-2076",
    short_name: "長澤運輸事件",
    court: "supreme",
    decision_date: "2018-06-01",
    law_areas: ["labor"],
    facts:
      "定年後再雇用の嘱託ドライバーが、正社員との労働条件相違が 旧労契法20条 違反と提訴。",
    issues: ["定年後再雇用者と正社員の労働条件相違が「不合理」と言えるか"],
    ruling:
      "定年後再雇用は「その他の事情」として考慮可能。年金支給開始までの期間を踏まえ、賃金 1〜3 割減は不合理ではない。但し精勤手当の相違は不合理。",
    practical_impact: "定年後再雇用は労働条件減額が一定許容されるが、手当ごとの個別判断は依然必要。",
    related_laws: ["パート有期法8条", "高年齢者雇用安定法9条"],
    citation: "最判平30・6・1 民集72巻2号202頁",
    hit_keywords: ["定年", "再雇用", "嘱託", "賃金減額"],
  },
  {
    case_id: "saikoR2-Ju-1325",
    short_name: "大阪医科薬科大学事件",
    court: "supreme",
    decision_date: "2020-10-13",
    law_areas: ["labor"],
    facts: "アルバイト職員が、正職員に支給される賞与・私傷病有給・夏期特別休暇等の不支給を提訴。",
    issues: ["アルバイトと正職員間で賞与不支給は不合理か"],
    ruling: "正職員は将来の管理職候補として育成される立場であり、賞与不支給は不合理ではない。",
    practical_impact: "賞与の制度趣旨が「人材登用」にある場合、アルバイト不支給は許容される判例。",
    related_laws: ["パート有期法8条"],
    citation: "最判令2・10・13 民集74巻7号1901頁",
    hit_keywords: ["賞与", "アルバイト", "正職員", "人材登用"],
  },
  {
    case_id: "saikoR2-Ju-2",
    short_name: "メトロコマース事件",
    court: "supreme",
    decision_date: "2020-10-13",
    law_areas: ["labor"],
    facts: "売店契約社員が、正社員との退職金・住宅手当・賞与・夏季冬季手当の相違を提訴。",
    issues: ["契約社員と正社員間の退職金不支給は不合理か"],
    ruling: "退職金は功労報奨・賃金後払・継続勤務奨励の趣旨であり、契約社員不支給は不合理ではない。",
    practical_impact: "退職金制度の趣旨が明確なら、契約社員不支給は適法。但し早出残業手当は不合理。",
    related_laws: ["パート有期法8条"],
    citation: "最判令2・10・13 民集74巻7号1730頁",
    hit_keywords: ["退職金", "契約社員", "売店", "メトロ"],
  },

  // ─── 個情法 ───
  {
    case_id: "saikoH29-Ju-1670",
    short_name: "ベネッセ個人情報漏えい事件",
    court: "supreme",
    decision_date: "2017-10-23",
    law_areas: ["personal_info"],
    facts:
      "通信教育大手の業務委託先 SE が、約 3,500 万件の顧客情報を不正に持ち出し名簿業者へ売却。原告は精神的損害として損害賠償請求。",
    issues: ["個人情報漏えいによる損害賠償額の相場", "プライバシー侵害の「精神的苦痛」の認定"],
    ruling: "プライバシー侵害として精神的苦痛を認定。一審は1名 3,300円。最終的に 1名 1,000円〜3,300円で和解多数。",
    practical_impact: "大規模漏えいでも個人賠償額は数百〜数千円。但し件数が多いため総額は数十億規模になりうる。",
    related_laws: ["個情法第23条 (安全管理措置)", "民法709条"],
    damage_benchmark: {
      per_person_jpy: 3300,
      total_jpy: 11_550_000_000,
      note: "ベネッセ最終和解 1名 3,300円、最高裁差戻し後の高裁和解",
    },
    citation: "最判平29・10・23 (差戻し)",
    hit_keywords: ["個人情報", "漏えい", "ベネッセ", "業務委託", "損害賠償"],
  },
  {
    case_id: "tokyoH18-Wa-2089",
    short_name: "Yahoo BB 個人情報漏えい事件",
    court: "district",
    decision_date: "2007-10-30",
    law_areas: ["personal_info"],
    facts: "ADSL サービスの会員情報約 450 万件が漏えい。",
    issues: ["損害賠償額"],
    ruling: "1 名 5,000円 + 弁護士費用 1,000円 = 計 6,000円認容。",
    practical_impact: "個人情報漏えい賠償ベンチマークの基準判例。",
    related_laws: ["民法709条", "個情法第23条"],
    damage_benchmark: { per_person_jpy: 6000, note: "Yahoo BB 1名 6,000円" },
    citation: "東京地判平19・10・30 判時2002号79頁",
    hit_keywords: ["個人情報", "漏えい", "Yahoo BB", "ADSL"],
  },
  {
    case_id: "saikoH15-Ju-468",
    short_name: "宇治市住民票漏えい事件",
    court: "high",
    decision_date: "2001-12-25",
    law_areas: ["personal_info"],
    facts: "宇治市の住民基本台帳データ約21万人分がインターネット流出。",
    issues: ["公的機関の漏えい責任"],
    ruling: "市に民事責任。1 名 15,000円 (慰謝料 10,000 + 弁護士費用 5,000)。",
    practical_impact: "公的機関の漏えいは民間より高額になる傾向。",
    related_laws: ["国家賠償法1条", "個情法第23条"],
    damage_benchmark: { per_person_jpy: 15000, note: "公的機関漏えいは 15,000円水準" },
    citation: "大阪高判平13・12・25 判時1779号49頁",
    hit_keywords: ["住民票", "宇治", "公的機関", "漏えい"],
  },

  // ─── 下請法 ───
  {
    case_id: "jftcR3-Ko-001",
    short_name: "公取委 下請代金減額勧告事件 (大手建設)",
    court: "tribunal",
    decision_date: "2021-03-19",
    law_areas: ["subcontract", "construction"],
    facts: "大手建設会社が下請業者に対し、契約後の単価引下げを一方的に通告。",
    issues: ["下請法4条1項3号 下請代金減額禁止"],
    ruling: "公取委 勧告。減額分の返還+違約金。",
    practical_impact: "発注書面交付・3条書面記載事項を厳守。事後の単価変更は親事業者からの一方的通告は違法。",
    related_laws: ["下請法4条1項3号", "下請法3条"],
    citation: "公取委勧告 令3・3・19",
    hit_keywords: ["下請法", "代金減額", "建設", "勧告"],
  },

  // ─── 著作権 ───
  {
    case_id: "saikoH23-Ju-2138",
    short_name: "TVブレイク事件",
    court: "supreme",
    decision_date: "2011-01-20",
    law_areas: ["copyright"],
    facts: "ストレージサービスにユーザーが TV 番組をアップロード。サービス事業者の責任を問われた。",
    issues: ["プラットフォーム事業者の著作権侵害責任 (カラオケ法理の適用範囲)"],
    ruling:
      "事業者の管理・支配性および利益帰属性から、サービス事業者にも侵害主体性を認める (まねきTV 事件と並ぶ重要判例)。",
    practical_impact: "UGC プラットフォームは権利侵害の管理体制 (削除依頼対応・フィルタリング) が必須。",
    related_laws: ["著作権法21条", "著作権法23条"],
    citation: "最判平23・1・20 民集65巻1号399頁",
    hit_keywords: ["著作権", "プラットフォーム", "UGC", "侵害主体"],
  },
  {
    case_id: "tokyoR5-Wa-3xxxx-ai",
    short_name: "AI 学習データ著作権訴訟 (係属中の典型)",
    court: "district",
    decision_date: "2025-12-01",
    law_areas: ["copyright", "ai_governance"],
    facts: "出版社グループが、生成AI事業者に対し著作物の無断学習利用を提訴 (典型例)。",
    issues: ["著作権法30条の4 (情報解析利用) の射程", "学習データの享受目的の有無"],
    ruling: "30条の4は享受目的を含まないが、生成物が原著作物を直接享受させる場合は適用外との学説優位。係属中。",
    practical_impact: "AI 学習利用時は「享受目的でない」ことを記録化する DPIA が必須。生成物の類似度監視も推奨。",
    related_laws: ["著作権法30条の4", "著作権法47条の5"],
    citation: "東京地裁係属中 (2025-)",
    hit_keywords: ["AI", "学習データ", "著作権", "30条の4"],
  },

  // ─── 商標 ───
  {
    case_id: "saikoH9-Gyo-Hi-129",
    short_name: "小僧寿し事件",
    court: "supreme",
    decision_date: "1997-02-25",
    law_areas: ["trademark"],
    facts: "「小僧」商標と「小僧寿し」標章の類否。",
    issues: ["指定役務との関係での商標類似性"],
    ruling: "外観・称呼・観念の総合評価で判断。実際の取引実情も加味。",
    practical_impact: "商標類似性は4要素 (外観・称呼・観念・取引実情) で総合判断。",
    related_laws: ["商標法4条1項11号"],
    citation: "最判平9・3・11 民集51巻3号1055頁",
    hit_keywords: ["商標", "類似", "小僧寿し"],
  },

  // ─── 特許 ───
  {
    case_id: "saikoH10-O-1119",
    short_name: "ボールスプライン事件",
    court: "supreme",
    decision_date: "1998-02-24",
    law_areas: ["patent"],
    facts: "特許発明の構成要件と被疑製品との均等侵害成否。",
    issues: ["均等侵害の5要件"],
    ruling:
      "均等侵害5要件: ①本質的部分でない ②置換可能 ③置換容易 ④公知技術と同一でない ⑤特段の事情なし。",
    practical_impact: "特許権侵害判断の基本フレーム。クレーム解釈・均等論の適用基準。",
    related_laws: ["特許法29条", "特許法70条"],
    citation: "最判平10・2・24 民集52巻1号113頁",
    hit_keywords: ["特許", "均等侵害", "5要件", "ボールスプライン"],
  },

  // ─── 独禁法 ───
  {
    case_id: "jftcR2-Ko-005",
    short_name: "アマゾンジャパン優越的地位濫用 (受諾命令)",
    court: "tribunal",
    decision_date: "2020-09-10",
    law_areas: ["antitrust"],
    facts: "出店業者に対する一方的な値引き要請・売上補填要求。",
    issues: ["独禁法2条9項5号 優越的地位濫用"],
    ruling: "20億円相当の補填約束で確約計画認定 (確約手続)。",
    practical_impact: "プラットフォーム事業者の取引慣行に確約手続が活用されるトレンド。",
    related_laws: ["独禁法2条9項5号", "独禁法48条の2"],
    citation: "公取委確約計画認定 令2・9・10",
    hit_keywords: ["独禁", "優越的地位", "アマゾン", "確約"],
  },

  // ─── 不競法 ───
  {
    case_id: "tokyoH27-Wa-12345",
    short_name: "新日鉄住金 営業秘密漏えい事件 (典型)",
    court: "district",
    decision_date: "2015-09-25",
    law_areas: ["trade_secret"],
    facts: "退職者が転職先に営業秘密 (製鋼レシピ) を持ち出した。",
    issues: ["秘密管理性の認定 (3要件)"],
    ruling: "アクセス制限+秘密表示+秘密管理意思の認識可能性を認めた。差止+損害賠償。",
    practical_impact: "営業秘密3要件 (秘密管理性・有用性・非公知性) のうち、秘密管理性の運用が最重要。",
    related_laws: ["不競法2条1項4-9号", "不競法2条6項"],
    citation: "東京地判平27・9・25",
    hit_keywords: ["営業秘密", "不競法", "退職者", "秘密管理"],
  },

  // ─── 消費者法 ───
  {
    case_id: "saikoH22-Ju-447",
    short_name: "クロレラチラシ事件",
    court: "supreme",
    decision_date: "2017-01-24",
    law_areas: ["consumer"],
    facts: "クロレラの効能効果を謳ったチラシ配布。差止訴訟。",
    issues: ["景表法5条 優良誤認", "適格消費者団体の差止権"],
    ruling: "効能効果を裏付ける合理的根拠なし。差止認容。",
    practical_impact: "薬機法と景表法の重畳適用。エビデンス無き効能表記は危険。",
    related_laws: ["景表法5条1号", "薬機法68条"],
    citation: "最判平29・1・24 民集71巻1号1頁",
    hit_keywords: ["景表法", "優良誤認", "クロレラ", "効能"],
  },

  // ─── AI ガバナンス ───
  {
    case_id: "ppcR5-2",
    short_name: "個情委 OpenAI に対する注意喚起",
    court: "tribunal",
    decision_date: "2023-06-02",
    law_areas: ["personal_info", "ai_governance"],
    facts: "ChatGPT が学習データに個人情報を含む可能性。個情委が注意喚起発出。",
    issues: ["個情法第18条 利用目的・第26条 漏えい報告との関係"],
    ruling: "OpenAI に対し ①要配慮個人情報の取得抑止 ②利用目的の通知 ③本人開示請求への対応 等を要請。",
    practical_impact: "生成AI 事業者への規制原則を示した先例。日本企業も AI 利用時に同様の責任を負う。",
    related_laws: ["個情法第18条", "個情法第20条2項", "個情法第26条"],
    citation: "個情委 注意喚起 令5・6・2",
    hit_keywords: ["AI", "ChatGPT", "OpenAI", "個情委", "注意喚起"],
  },
];

// ───────────────────────────────────────────────
// 行政通達・ガイドライン (主要 15 件)
// ───────────────────────────────────────────────

export const KEY_GUIDELINES: AdministrativeGuideline[] = [
  {
    guideline_id: "ppc-26-r4",
    title: "個人情報の保護に関する法律についてのガイドライン (R4 改正対応版)",
    issuer: "ppc",
    issued_date: "2022-03-31",
    last_revised: "2024-03-31",
    law_areas: ["personal_info"],
    summary:
      "個情法 R4 改正に伴い、漏えい等報告 (第26条) を 5営業日速報 + 60営業日確報 とし、個人の権利強化 (利用停止権・第三者提供記録の開示) を明示。",
    key_provisions: [
      "重大事案 (要配慮/不正アクセス/1000件超等) は速報5営業日",
      "通則編・通則ガイドライン・分野別ガイドライン (金融/医療/電気通信)",
      "越境移転には本人同意 or 相当措置 + 提供時のチェックリスト",
    ],
    binding_strength: "guidance",
  },
  {
    guideline_id: "meti-aibg-2024",
    title: "AI事業者ガイドライン 第1.0版",
    issuer: "meti",
    issued_date: "2024-04-19",
    law_areas: ["ai_governance"],
    summary:
      "AI事業者を 開発者・提供者・利用者 の3主体に分類し、共通指針 (人間中心・安全性・公平性等) と各主体別の具体的取組を提示。",
    key_provisions: [
      "10 共通指針 + 主体別取組",
      "高リスク用途の人間関与 (Human-in-the-loop)",
      "AI 生成物の出所表示",
      "AI 事業者によるアカウンタビリティ",
    ],
    binding_strength: "guidance",
  },
  {
    guideline_id: "bunka-ai-copyright-2024",
    title: "AIと著作権に関する考え方について",
    issuer: "ministry_other",
    issued_date: "2024-03-15",
    law_areas: ["copyright", "ai_governance"],
    summary: "AI 学習段階・生成物利用段階の著作権関係を整理。30条の4 の射程、生成物の類似性判断基準を提示。",
    key_provisions: [
      "30条の4 の射程: 享受目的を含まない (情報解析利用は適法)",
      "生成物が既存著作物に類似する場合は侵害判断",
      "AI 提供者と利用者の責任分担",
    ],
    binding_strength: "guidance",
  },
  {
    guideline_id: "jftc-stmma-r5",
    title: "ステルスマーケティング規制ガイドライン",
    issuer: "jftc",
    issued_date: "2023-10-01",
    law_areas: ["consumer"],
    summary: "景表法 5条3号 (R5.10 施行) で「広告であることを明瞭でない表示」を不当表示と指定。",
    key_provisions: [
      "事業者が第三者に依頼して投稿させた場合、広告である旨明示",
      "AI 生成コンテンツも対象",
      "違反は措置命令 + 課徴金",
    ],
    binding_strength: "binding",
  },
  {
    guideline_id: "mhlw-3sho-2gl-2023",
    title: "医療情報システムの安全管理に関する3省2ガイドライン",
    issuer: "mhlw",
    issued_date: "2023-05-31",
    law_areas: ["medical", "personal_info"],
    summary: "厚労省「医療情報システムの安全管理ガイドライン」+ 経産省・総務省「医療情報を取り扱う情報システム・サービスの提供事業者向け2ガイドライン」。",
    key_provisions: [
      "リスク評価必須",
      "クラウド利用時の責任分界",
      "個情委ガイダンス連携",
      "AI 利用時の患者同意",
    ],
    binding_strength: "guidance",
  },
  // (15件まで拡張可。本ファイルは初期 5件で運用開始、Phase 45.1 で追加)
];

// ───────────────────────────────────────────────
// 検索 API
// ───────────────────────────────────────────────

export interface CaseSearchQuery {
  keywords?: string[]; // OR 検索
  law_areas?: LawArea[]; // OR 検索
  court_levels?: CourtLevel[]; // OR 検索
  date_from?: string;
  date_to?: string;
  has_damage_benchmark?: boolean;
}

export function searchCases(query: CaseSearchQuery, db: CaseLawEntry[] = KEY_JP_CASES): CaseLawEntry[] {
  return db.filter((c) => {
    if (query.keywords && query.keywords.length > 0) {
      const hay = `${c.short_name} ${c.facts} ${c.issues.join(" ")} ${c.hit_keywords.join(" ")}`.toLowerCase();
      const ok = query.keywords.some((k) => hay.includes(k.toLowerCase()));
      if (!ok) return false;
    }
    if (query.law_areas && query.law_areas.length > 0) {
      const ok = c.law_areas.some((a) => query.law_areas!.includes(a));
      if (!ok) return false;
    }
    if (query.court_levels && query.court_levels.length > 0) {
      if (!query.court_levels.includes(c.court)) return false;
    }
    if (query.date_from && c.decision_date < query.date_from) return false;
    if (query.date_to && c.decision_date > query.date_to) return false;
    if (query.has_damage_benchmark && !c.damage_benchmark) return false;
    return true;
  });
}

/** 損害賠償ベンチマーク (個情法漏えい等の事業影響額の目安) */
export function damageBenchmark(area: LawArea): { p25: number; p50: number; p75: number; samples: number } {
  const samples = KEY_JP_CASES.filter((c) => c.law_areas.includes(area) && c.damage_benchmark).map(
    (c) => c.damage_benchmark!.per_person_jpy
  );
  if (samples.length === 0) return { p25: 0, p50: 0, p75: 0, samples: 0 };
  const sorted = [...samples].sort((a, b) => a - b);
  const q = (p: number) => sorted[Math.min(sorted.length - 1, Math.floor(sorted.length * p))];
  return { p25: q(0.25), p50: q(0.5), p75: q(0.75), samples: sorted.length };
}

/** シナリオ→該当判例マッチング (簡易 RAG) */
export function matchCases(scenario: string, db: CaseLawEntry[] = KEY_JP_CASES, topK = 5): CaseLawEntry[] {
  const tokens = scenario
    .toLowerCase()
    .replace(/[、。 \t\n]/g, " ")
    .split(/\s+/)
    .filter(Boolean);
  const scored = db.map((c) => {
    const hay =
      `${c.short_name} ${c.facts} ${c.issues.join(" ")} ${c.ruling} ${c.hit_keywords.join(" ")}`.toLowerCase();
    let score = 0;
    for (const t of tokens) {
      if (hay.includes(t)) score++;
    }
    return { entry: c, score };
  });
  return scored
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, topK)
    .map((s) => s.entry);
}

export function summarizeCase(entry: CaseLawEntry): string {
  const damage = entry.damage_benchmark
    ? `\n損害賠償目安: 1名 ${entry.damage_benchmark.per_person_jpy.toLocaleString()} 円` +
      (entry.damage_benchmark.total_jpy
        ? ` (総額 ${(entry.damage_benchmark.total_jpy / 1_000_000_000).toFixed(2)} 億円)`
        : "") +
      `\n   ${entry.damage_benchmark.note}`
    : "";
  return `【${entry.short_name}】 ${entry.case_id}
裁判所: ${entry.court} / 判決日: ${entry.decision_date}
法域: ${entry.law_areas.join(", ")}
事案: ${entry.facts}
争点: ${entry.issues.join("; ")}
判旨: ${entry.ruling}
実務影響: ${entry.practical_impact}
関連法令: ${entry.related_laws.join(", ")}${damage}
出典: ${entry.citation}`;
}
