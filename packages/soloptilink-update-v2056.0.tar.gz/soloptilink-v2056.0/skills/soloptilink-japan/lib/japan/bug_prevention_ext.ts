/**
 * SoloptiLinkAI JAPAN-NATIVE Mode - Bug Prevention DNA Extended (v2015.5 Phase 7)
 *
 * Phase 6 の save_guarantee.ts / bug_prevention.ts で P1-P15 をカバーした。
 * Phase 7 では「Phase 6 で拾い切れなかった頻出クレーム型」を P16-P25 で追加する。
 *
 * 実戦で踏まれるパターン:
 *   P16 二重送信 (onSubmit 連打 / fetch AbortController 欠如)
 *   P17 レースコンディション (在庫/予約の同時押し)
 *   P18 CSRF トークン検証漏れ
 *   P19 ファイルアップロード (拡張子偽装 / MIME 不一致 / サイズ)
 *   P20 ページング境界 (offset + limit >= MAX_SAFE_INTEGER / limit 0)
 *   P21 検索 N+1 (include 漏れ)
 *   P22 レート制限 (per-user / per-IP)
 *   P23 全角スペース U+3000 の不可視分離 (検索ヒットしない)
 *   P24 PDF A4 はみ出し (印刷プレビュー欠落)
 *   P25 メール二重配信 (onSuccess の送信トリガ重複)
 */

// =============================================================================
// P16: 二重送信防止 — AbortController + in-flight guard
// =============================================================================

/**
 * onSubmit / onClick で fetch を呼ぶ際の二重送信ガード。
 * 同じキーで発火した進行中リクエストは abort し、最新のみ生かす。
 *
 * 使用例:
 *   const guard = createSubmitGuard();
 *   async function onSubmit() {
 *     const { signal, done } = guard('save-customer');
 *     try {
 *       const res = await fetch('/api/customers', { method: 'POST', body, signal });
 *     } finally { done(); }
 *   }
 */
export function createSubmitGuard() {
  const inflight = new Map<string, AbortController>();
  return function guard(key: string): { signal: AbortSignal; done: () => void } {
    const prev = inflight.get(key);
    if (prev) prev.abort();
    const controller = new AbortController();
    inflight.set(key, controller);
    return {
      signal: controller.signal,
      done: () => {
        if (inflight.get(key) === controller) inflight.delete(key);
      },
    };
  };
}

// =============================================================================
// P17: レースコンディション — 在庫/予約の楽観的取得 + 悲観ロック フォールバック
// =============================================================================

export interface StockReservation {
  productId: string;
  quantity: number;
  version: number;
}

/**
 * 在庫/予約リソースの楽観ロック取得。version 不一致時は最新を再読み込みして再試行。
 * 3 回失敗で "RESOURCE_CONFLICT" を返す。
 *
 * tx は Prisma.TransactionClient 想定だが、ここでは unknown で受け、呼び出し側で型キャストする。
 */
export async function acquireStockOptimistic<T extends StockReservation>(
  tx: unknown,
  current: T,
  delta: number,
  updateFn: (tx: unknown, next: T) => Promise<T | null>,
): Promise<{ ok: true; reserved: T } | { ok: false; reason: 'OUT_OF_STOCK' | 'RESOURCE_CONFLICT' }> {
  const desired = { ...current, quantity: current.quantity - delta, version: current.version + 1 };
  if (desired.quantity < 0) return { ok: false, reason: 'OUT_OF_STOCK' };

  for (let attempt = 0; attempt < 3; attempt++) {
    const updated = await updateFn(tx, desired);
    if (updated) return { ok: true, reserved: updated };
    // version 不一致: 再試行
  }
  return { ok: false, reason: 'RESOURCE_CONFLICT' };
}

// =============================================================================
// P18: CSRF — ダブルサブミットクッキー + SameSite=Strict チェッカ
// =============================================================================

/**
 * ダブルサブミットクッキーパターンの検証ヘルパ。
 * Cookie の csrf-token と Request Header X-CSRF-Token が一致するかチェック。
 *
 * Next.js Route Handler で使用:
 *   if (!verifyCsrf(req)) return new Response('CSRF', { status: 403 });
 */
export function verifyCsrf(req: {
  headers: { get(name: string): string | null };
  cookies: { get(name: string): { value: string } | undefined };
}): boolean {
  const headerToken = req.headers.get('x-csrf-token');
  const cookieToken = req.cookies.get('csrf-token')?.value;
  if (!headerToken || !cookieToken) return false;
  if (headerToken.length !== cookieToken.length) return false;
  // timing-safe 比較
  let mismatch = 0;
  for (let i = 0; i < headerToken.length; i++) {
    mismatch |= headerToken.charCodeAt(i) ^ cookieToken.charCodeAt(i);
  }
  return mismatch === 0;
}

export function generateCsrfToken(): string {
  const bytes = new Uint8Array(32);
  if (typeof crypto !== 'undefined' && 'getRandomValues' in crypto) {
    crypto.getRandomValues(bytes);
  } else {
    for (let i = 0; i < 32; i++) bytes[i] = Math.floor(Math.random() * 256);
  }
  return Array.from(bytes, b => b.toString(16).padStart(2, '0')).join('');
}

// =============================================================================
// P19: ファイルアップロード検証 — Magic Number + 拡張子 + サイズ
// =============================================================================

export type AllowedFileKind = 'pdf' | 'jpeg' | 'png' | 'excel' | 'csv';

const MAGIC: Record<AllowedFileKind, number[][]> = {
  pdf: [[0x25, 0x50, 0x44, 0x46]], // %PDF
  jpeg: [[0xff, 0xd8, 0xff]],
  png: [[0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]],
  excel: [[0x50, 0x4b, 0x03, 0x04], [0xd0, 0xcf, 0x11, 0xe0]], // xlsx (zip) / xls (ole2)
  csv: [], // CSV は magic number なし、後段で別判定
};

export interface FileValidationResult {
  ok: boolean;
  reason?: 'EMPTY' | 'TOO_LARGE' | 'MIME_MISMATCH' | 'EXT_MISMATCH' | 'KIND_NOT_ALLOWED';
  detected?: AllowedFileKind;
}

/**
 * アップロードファイルを Magic Number / サイズ / 拡張子で検証。
 * 拡張子偽装 (.exe → .pdf) を検出可能。
 */
export function validateUploadFile(
  file: { name: string; size: number; type: string; bytes: Uint8Array },
  opts: { allowed: AllowedFileKind[]; maxBytes: number },
): FileValidationResult {
  if (file.size === 0) return { ok: false, reason: 'EMPTY' };
  if (file.size > opts.maxBytes) return { ok: false, reason: 'TOO_LARGE' };

  const ext = file.name.split('.').pop()?.toLowerCase() ?? '';
  const extMap: Record<string, AllowedFileKind> = {
    pdf: 'pdf', jpg: 'jpeg', jpeg: 'jpeg', png: 'png',
    xlsx: 'excel', xls: 'excel', csv: 'csv',
  };
  const kindByExt = extMap[ext];
  if (!kindByExt || !opts.allowed.includes(kindByExt)) {
    return { ok: false, reason: 'KIND_NOT_ALLOWED' };
  }

  if (kindByExt === 'csv') {
    // CSV は MIME が不安定なので拡張子のみ信頼 + UTF-8/CRLF 軽チェック
    return { ok: true, detected: 'csv' };
  }

  const sigs = MAGIC[kindByExt];
  const matches = sigs.some(sig => sig.every((b, i) => file.bytes[i] === b));
  if (!matches) return { ok: false, reason: 'MIME_MISMATCH' };

  return { ok: true, detected: kindByExt };
}

// =============================================================================
// P20: ページング境界
// =============================================================================

export interface PagingParams {
  page: number;
  pageSize: number;
}

/**
 * ページング入力をサニタイズ。limit=0 / 負数 / オーバーフローを全て防ぐ。
 */
export function sanitizePaging(
  input: { page?: number | string | null; pageSize?: number | string | null },
  opts: { defaultPageSize?: number; maxPageSize?: number } = {},
): PagingParams {
  const defaultSize = opts.defaultPageSize ?? 20;
  const maxSize = opts.maxPageSize ?? 200;
  const rawPage = Number(input.page);
  const rawSize = Number(input.pageSize);
  const page = Number.isFinite(rawPage) && rawPage >= 1 ? Math.floor(rawPage) : 1;
  const pageSize = Number.isFinite(rawSize) && rawSize >= 1
    ? Math.min(Math.floor(rawSize), maxSize)
    : defaultSize;
  return { page, pageSize };
}

/** offset 計算。ページングサニタイズ済みの前提。 */
export function pagingToOffset(p: PagingParams): { skip: number; take: number } {
  return { skip: (p.page - 1) * p.pageSize, take: p.pageSize };
}

// =============================================================================
// P21: 検索 N+1 検出用ヒント
// =============================================================================

/**
 * Prisma include が必要な関連フィールド名を集計し、クエリ設計時の指針として返す。
 * 実行時チェックではなく、テスト/開発時の静的ヒント用。
 */
export function hintRequiredIncludes(accessPatterns: string[]): string[] {
  const set = new Set<string>();
  for (const pattern of accessPatterns) {
    // "customer.contacts.phone" → "contacts" を include 候補に
    const parts = pattern.split('.');
    if (parts.length >= 2) set.add(parts[1]);
  }
  return Array.from(set);
}

// =============================================================================
// P22: レート制限 (インメモリ簡易版 - 本番は Redis を推奨)
// =============================================================================

export interface RateLimitBucket {
  count: number;
  windowStart: number;
}

/**
 * per-key (user id / IP) のスライディングウィンドウ的カウンタ。
 * Vercel Edge で使う場合は KV 等の永続ストアに差し替える。
 */
export class RateLimiter {
  private readonly buckets = new Map<string, RateLimitBucket>();
  constructor(private readonly limit: number, private readonly windowMs: number) {}

  check(key: string, now: number = Date.now()): { allowed: boolean; retryAfterMs: number } {
    const bucket = this.buckets.get(key);
    if (!bucket || now - bucket.windowStart > this.windowMs) {
      this.buckets.set(key, { count: 1, windowStart: now });
      return { allowed: true, retryAfterMs: 0 };
    }
    if (bucket.count < this.limit) {
      bucket.count++;
      return { allowed: true, retryAfterMs: 0 };
    }
    return { allowed: false, retryAfterMs: this.windowMs - (now - bucket.windowStart) };
  }
}

// =============================================================================
// P23: 全角スペース U+3000 の不可視分離対策
// =============================================================================

/**
 * 検索キーワード用の正規化。全角空白/ゼロ幅/前後空白を統合。
 * 「山田 太郎」と「山田 太郎」を同一扱いにする。
 */
export function normalizeSearchKeyword(raw: string): string {
  return raw
    .replace(/[\u3000\u00A0\u200B\u200C\u200D\uFEFF]/g, ' ') // 全角SP/NBSP/ZWSP等→半角SP
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * 検索クエリ分割。空白/全角空白/カンマで区切り、AND 検索用の配列を返す。
 */
export function splitSearchTokens(raw: string, opts: { max?: number } = {}): string[] {
  const max = opts.max ?? 10;
  return normalizeSearchKeyword(raw)
    .split(/[\s,，、]+/)
    .filter(Boolean)
    .slice(0, max);
}

// =============================================================================
// P24: PDF A4 はみ出し検知 (軽量ヒューリスティック)
// =============================================================================

export interface A4SafetyCheck {
  safe: boolean;
  warnings: string[];
}

/**
 * A4 縦向きの安全領域に収まるかチェック。
 * - ページ幅 210mm / 高さ 297mm
 * - 推奨余白: 上下 20mm / 左右 15mm
 * 入力は mm 単位。超過時は警告を返す。
 */
export function checkA4Safety(content: { width: number; height: number; rows?: number }): A4SafetyCheck {
  const warnings: string[] = [];
  const SAFE_W = 210 - 15 * 2;
  const SAFE_H = 297 - 20 * 2;
  if (content.width > SAFE_W) warnings.push(`幅超過: ${content.width}mm > ${SAFE_W}mm`);
  if (content.height > SAFE_H) warnings.push(`高さ超過: ${content.height}mm > ${SAFE_H}mm`);
  if (content.rows && content.rows > 40) {
    warnings.push(`行数多い (${content.rows}行): 分割印刷を推奨`);
  }
  return { safe: warnings.length === 0, warnings };
}

// =============================================================================
// P25: メール二重配信ガード (onSuccess 重複発火対策)
// =============================================================================

/**
 * メール送信のベキ等性保証。
 * messageKey (例: "invoice-sent:123") をキーに、既に送信済みなら再送しない。
 *
 * 永続ストアが必要 (DB の sent_emails テーブル等)。
 */
export interface SentEmailStore {
  hasBeenSent(key: string): Promise<boolean>;
  recordSent(key: string, meta: { to: string; subject: string; sentAt: Date }): Promise<void>;
}

export async function sendEmailOnce(
  store: SentEmailStore,
  messageKey: string,
  send: () => Promise<void>,
  meta: { to: string; subject: string },
): Promise<{ sent: boolean; reason?: 'ALREADY_SENT' }> {
  const already = await store.hasBeenSent(messageKey);
  if (already) return { sent: false, reason: 'ALREADY_SENT' };
  await send();
  await store.recordSent(messageKey, { ...meta, sentAt: new Date() });
  return { sent: true };
}
