/**
 * lib/japan/handoff_plus.ts — Handoff Plus (Runbook自動生成) (v2.0 Phase 5)
 *
 * 柱5 OPERATIONAL EXCELLENCE の中核モジュール。
 * Runbook (運用手順書) を 3 種類 (定期保守/緊急対応/障害復旧) で自動生成。
 *
 * なぜClaude Codeに作れないか:
 *   Claude Code は GitHub の README 風ドキュメントは書けるが、
 *   「中小企業の IT 担当 (情シス) 1 人で回す運用」に特化した Runbook
 *   (日本語・電話連絡網・休日エスカレーション・JISQ27001 監査対応) は
 *   日本の運用現場の長年の知見がないと書けない。
 *
 * 出力先:
 *   生成プロジェクトの `docs/runbook/` 配下に Markdown 形式で配置
 *   - 01_daily_maintenance.md
 *   - 02_weekly_maintenance.md
 *   - 03_monthly_maintenance.md
 *   - 10_incident_response.md
 *   - 11_escalation_matrix.md
 *   - 20_disaster_recovery.md
 */

// ───────────────────────────────────────────────
// 型定義
// ───────────────────────────────────────────────

export type RunbookKind = "daily" | "weekly" | "monthly" | "incident" | "disaster" | "escalation";

export interface Step {
  order: number;
  title: string;
  description: string;
  command?: string;
  expected?: string;
  owner?: string;
  durationMinutes?: number;
}

export interface Runbook {
  id: string;
  kind: RunbookKind;
  title: string;
  version: string;
  lastUpdated: string;
  targetSystem: string;
  owner: string;
  reviewers: string[];
  overview: string;
  prerequisites: string[];
  steps: Step[];
  rollback?: Step[];
  successCriteria: string[];
  notes?: string[];
}

export interface EscalationContact {
  name: string;
  role: string;
  email: string;
  phone?: string;
  line?: string;
  availableHours: string; // 例: "平日 9:00-18:00"
}

export interface EscalationMatrix {
  firstResponder: EscalationContact;
  secondary: EscalationContact;
  tertiary?: EscalationContact;
  businessOwner: EscalationContact;
  vendorSupport?: EscalationContact;
}

export interface ProjectMetadata {
  projectName: string;
  environmentUrl?: string;
  repositoryUrl?: string;
  productionHost?: string;
  dbType?: "postgresql" | "mysql" | "sqlite" | "mongodb";
  deployTarget?: "vercel" | "aws" | "gcp" | "azure" | "onprem";
}

// ───────────────────────────────────────────────
// 定型 Runbook テンプレート
// ───────────────────────────────────────────────

export function generateDailyMaintenanceRunbook(meta: ProjectMetadata, matrix: EscalationMatrix): Runbook {
  return {
    id: "RB-DAILY-001",
    kind: "daily",
    title: "日次保守 Runbook",
    version: "1.0",
    lastUpdated: new Date().toISOString(),
    targetSystem: meta.projectName,
    owner: matrix.firstResponder.name,
    reviewers: [matrix.secondary.name, matrix.businessOwner.name],
    overview:
      "毎営業日朝 9:00 までに実施する点検手順。過去 24 時間のシステム稼働状態を確認し、異常があればエスカレーションする。",
    prerequisites: [
      "SSH公開鍵または VPN 接続が有効であること",
      "Grafana ダッシュボードにアクセスできること",
      "LINE/Slack 通知チャネルに参加していること",
    ],
    steps: [
      {
        order: 1,
        title: "アラート未処理分を確認",
        description: "Alertmanager の未解決アラートを確認し、重大度 critical があれば即対応に入る。",
        command: "open https://alertmanager.example.jp/",
        expected: "未解決 critical = 0",
        durationMinutes: 5,
      },
      {
        order: 2,
        title: "Grafana システム健全性ダッシュボードを目視",
        description:
          "過去 24 時間の CPU/メモリ/ディスク/5xx率 を確認。異常値 (CPU>85%, 5xx>5%) があれば原因調査。",
        command: "open https://grafana.example.jp/d/system-health-jp",
        expected: "全パネルが閾値内",
        durationMinutes: 5,
      },
      {
        order: 3,
        title: "バックアップの完了確認",
        description: "昨夜のバックアップジョブが成功しているか確認。失敗時は 10_incident_response.md を参照。",
        command: "curl -s https://app.example.jp/api/health/backup | jq .last_backup",
        expected: '"status": "success", "timestamp" が直近 24 時間以内',
        durationMinutes: 3,
      },
      {
        order: 4,
        title: "ライセンスサーバー疎通確認",
        description: "SoloptiLinkAI ライセンス認証サーバーとの疎通を確認。",
        command: "curl -s https://license.soloptilinkai.com/api/health",
        expected: "HTTP 200, {\"status\":\"ok\"}",
        durationMinutes: 2,
      },
      {
        order: 5,
        title: "日次チェックログ提出",
        description:
          "#ops-daily Slack チャンネルに実施報告を投稿。テンプレ: 『日次保守 実施者: X / 異常: なし or 詳細』",
        durationMinutes: 2,
      },
    ],
    successCriteria: [
      "全ステップが 20 分以内に完了",
      "未解決 critical = 0",
      "バックアップ = success",
      "Slack 報告済み",
    ],
    notes: [
      "祝日・年末年始は当直担当が実施。シフト表は `docs/runbook/shift_calendar.md` 参照",
      "20 分を超えた場合は次ステップをスキップし、1次対応者にエスカレーション",
    ],
  };
}

export function generateWeeklyMaintenanceRunbook(meta: ProjectMetadata, matrix: EscalationMatrix): Runbook {
  return {
    id: "RB-WEEKLY-001",
    kind: "weekly",
    title: "週次保守 Runbook",
    version: "1.0",
    lastUpdated: new Date().toISOString(),
    targetSystem: meta.projectName,
    owner: matrix.firstResponder.name,
    reviewers: [matrix.secondary.name],
    overview: "毎週月曜 10:00 に実施する保守作業。定常メンテナンス・脆弱性アップデート・バックアップ整合性検証。",
    prerequisites: [
      "本番環境への書き込み権限 (ユーザー: deploy)",
      "メンテナンス告知が 3 日前に出ていること",
    ],
    steps: [
      {
        order: 1,
        title: "依存関係アップデートチェック",
        description: "npm / bundler / pip 等の依存を確認。脆弱性パッチは即反映。",
        command: meta.dbType === "postgresql" ? "npm outdated --depth=0" : "npm outdated",
        durationMinutes: 10,
      },
      {
        order: 2,
        title: "バックアップ整合性検証",
        description: "先週のバックアップから任意の1日分を検証環境にリストアし、正常に起動することを確認。",
        command: `psql -U verify -d verify_db -f /backups/weekly_$(date +%Y%m%d).sql`,
        expected: "リストア成功 + サンプルクエリ PASS",
        durationMinutes: 30,
      },
      {
        order: 3,
        title: "ログ・監査ログのアーカイブ",
        description: "7 日以上経過したログを S3/Azure Blob 等にアーカイブ。監査ログは 7 年保存義務。",
        durationMinutes: 10,
      },
      {
        order: 4,
        title: "SSL 証明書・ドメイン有効期限の目視",
        description: "30 日以内に期限切れがないか確認。あれば更新作業を `11_escalation_matrix.md` のベンダーに依頼。",
        durationMinutes: 5,
      },
    ],
    successCriteria: ["依存関係 脆弱性なし", "バックアップ検証 PASS", "ログアーカイブ完了"],
  };
}

export function generateMonthlyMaintenanceRunbook(meta: ProjectMetadata, matrix: EscalationMatrix): Runbook {
  return {
    id: "RB-MONTHLY-001",
    kind: "monthly",
    title: "月次保守 Runbook",
    version: "1.0",
    lastUpdated: new Date().toISOString(),
    targetSystem: meta.projectName,
    owner: matrix.firstResponder.name,
    reviewers: [matrix.businessOwner.name],
    overview: "毎月第1営業日に実施する中規模保守。SLA 集計・法令改正チェック・容量予測・セキュリティレビュー。",
    prerequisites: ["月次集計権限", "法令マスター最新版の取得 (Compliance Ledger 連携)"],
    steps: [
      {
        order: 1,
        title: "SLA 遵守率 集計",
        description: "先月の稼働率・応答時間 p95 を集計しレポート化。",
        command: "scripts/sla_report.sh previous_month",
        durationMinutes: 30,
      },
      {
        order: 2,
        title: "Compliance Ledger 差分確認",
        description:
          "Compliance Ledger の detectLawDiffs() を実行し、改正法令があれば影響範囲を確認。重大な改正は稟議起票。",
        command: "npx tsx scripts/compliance_check.ts",
        expected: "差分なし or 差分レビュー済み",
        durationMinutes: 20,
      },
      {
        order: 3,
        title: "容量予測",
        description:
          "DB・ストレージの使用量推移から 3 ヶ月後の予測値を算出。閾値到達なら増設稟議を起票。",
        durationMinutes: 30,
      },
      {
        order: 4,
        title: "セキュリティ脆弱性スキャン",
        description: "npm audit / Dependabot / Snyk 等で critical/high をゼロに保つ。",
        command: "npm audit --audit-level=high",
        durationMinutes: 20,
      },
      {
        order: 5,
        title: "パスワード・アクセスキーローテーション確認",
        description: "90 日を超える資格情報があればローテーション。",
        durationMinutes: 15,
      },
    ],
    successCriteria: [
      "SLA レポート提出",
      "Compliance Ledger 差分対応完了",
      "容量予測レポート提出",
      "脆弱性 critical/high = 0",
      "資格情報ローテーション完了",
    ],
  };
}

// ───────────────────────────────────────────────
// 障害対応 Runbook (インシデント対応)
// ───────────────────────────────────────────────

export function generateIncidentResponseRunbook(
  meta: ProjectMetadata,
  matrix: EscalationMatrix,
): Runbook {
  return {
    id: "RB-INCIDENT-001",
    kind: "incident",
    title: "障害対応 Runbook",
    version: "1.0",
    lastUpdated: new Date().toISOString(),
    targetSystem: meta.projectName,
    owner: matrix.firstResponder.name,
    reviewers: [matrix.secondary.name, matrix.businessOwner.name, ...(matrix.tertiary ? [matrix.tertiary.name] : [])],
    overview:
      "critical アラート発火時・顧客からの障害連絡時の初動手順。5 分以内の一次受付 / 15 分以内の影響特定 / 60 分以内の復旧または回避策適用 を目標とする。",
    prerequisites: [
      "VPN 接続が可能",
      "本番への読み取り権限",
      "ステータスページ更新権限",
    ],
    steps: [
      {
        order: 1,
        title: "インシデント受付 (5分以内)",
        description:
          "① アラート内容を確認 ② #incidents Slack に受付メッセージを投稿 ③ ステータスページで「調査中」に切替え",
        command: "scripts/incident_open.sh \"障害内容要約\"",
        durationMinutes: 5,
      },
      {
        order: 2,
        title: "影響範囲の特定 (15分以内)",
        description:
          "Grafana ダッシュボードで影響を受けている機能を特定。DB / API / フロントのどこが落ちているかを切り分け。",
        command: "open https://grafana.example.jp/d/api-performance-jp",
        durationMinutes: 10,
      },
      {
        order: 3,
        title: "一次復旧 or 回避策 (60分以内)",
        description:
          "A) 既知の障害であれば該当の個別 Runbook へ B) 未知の障害であれば直近のデプロイをロールバック C) それでも復旧しない場合は 2 次対応者にエスカレーション",
        command: "scripts/rollback.sh $(git log --oneline -n 5)",
        durationMinutes: 30,
      },
      {
        order: 4,
        title: "顧客連絡",
        description:
          "ステータスページを最新化し、重大度 critical かつ顧客影響ありなら メール / LINE で個別連絡。金融・医療等の業種は 電話連絡必須。",
        durationMinutes: 15,
      },
      {
        order: 5,
        title: "ポストモーテム起票",
        description:
          "復旧後 3 営業日以内にポストモーテムを起票。`docs/postmortem/YYYY-MM-DD_slug.md` テンプレを使用。",
        durationMinutes: 60,
      },
    ],
    rollback: [
      {
        order: 1,
        title: "デプロイロールバック",
        description: "直前のデプロイ前のコミットに戻す。",
        command: "git revert HEAD && npm run build && npm run deploy",
      },
      {
        order: 2,
        title: "DB ロールバック",
        description: "スキーマ変更が絡む場合は migration を down させる。データ消失の可能性があるため慎重に。",
        command: meta.dbType === "postgresql" ? "npx prisma migrate resolve --rolled-back" : "flask db downgrade",
      },
    ],
    successCriteria: [
      "5分以内の一次受付",
      "15分以内の影響範囲特定",
      "60分以内の一次復旧 or 回避策",
      "ポストモーテム起票",
    ],
    notes: [
      "critical の場合は営業時間外でも LINE で即通知される",
      "個人情報漏洩の疑いがあれば 72時間以内に個情委へ報告 (個情法 v2022)",
    ],
  };
}

export function generateDisasterRecoveryRunbook(
  meta: ProjectMetadata,
  matrix: EscalationMatrix,
): Runbook {
  return {
    id: "RB-DR-001",
    kind: "disaster",
    title: "災害復旧 (DR) Runbook",
    version: "1.0",
    lastUpdated: new Date().toISOString(),
    targetSystem: meta.projectName,
    owner: matrix.businessOwner.name,
    reviewers: [matrix.firstResponder.name, matrix.secondary.name],
    overview:
      "データセンター被災・リージョン全停止等の広域障害時の復旧手順。RTO 4 時間 / RPO 24 時間を目標とする。",
    prerequisites: [
      "DR サイト (別リージョン) のインフラが稼働可能",
      "バックアップデータが DR サイトに複製されていること",
      "経営判断 (事業継続責任者) の同意",
    ],
    steps: [
      {
        order: 1,
        title: "DR 発動判断",
        description:
          "メインサイトの復旧見込みが 2 時間以内に立たない場合、事業継続責任者が DR 発動を決定。",
        owner: matrix.businessOwner.name,
        durationMinutes: 30,
      },
      {
        order: 2,
        title: "DR サイトの稼働開始",
        description: "Terraform/CloudFormation で DR 環境を起動。",
        command: "cd infrastructure/dr && terraform apply -auto-approve",
        durationMinutes: 60,
      },
      {
        order: 3,
        title: "最新バックアップからのリストア",
        description: "S3/Azure Blob の DR リージョン複製からデータベースをリストア。",
        command: "scripts/dr_restore.sh --target dr-region --source-backup latest",
        durationMinutes: 120,
      },
      {
        order: 4,
        title: "DNS 切替",
        description: "Route53 / Cloud DNS の加重ルーティングを DR サイトに 100% 振り替え。",
        command: "scripts/dns_failover.sh --to dr",
        durationMinutes: 15,
      },
      {
        order: 5,
        title: "疎通確認 + 顧客通知",
        description: "主要エンドポイントの疎通を確認し、顧客にサービス継続を通知。",
        durationMinutes: 30,
      },
    ],
    successCriteria: [
      "RTO 4 時間以内に DR サイト稼働",
      "RPO 24 時間以内のデータで復旧",
      "顧客通知完了",
    ],
    notes: [
      "年1回、DR 訓練を実施し本 Runbook を検証すること",
      "金融・医療・公共案件は DR 要件が業法で決まっているため別途確認",
    ],
  };
}

// ───────────────────────────────────────────────
// エスカレーション表
// ───────────────────────────────────────────────

export function generateEscalationMatrix(matrix: EscalationMatrix): string {
  return `# エスカレーション表 (SoloptiLinkAI Observability Pack v2.0)

最終更新: ${new Date().toISOString()}

障害発生時は以下の順で連絡します。前段が **15分** 以内に返信しない場合、次段へ繰り上げてください。

## 1次対応者 (First Responder)
- 氏名: ${matrix.firstResponder.name}
- 役割: ${matrix.firstResponder.role}
- Email: ${matrix.firstResponder.email}
${matrix.firstResponder.phone ? `- 電話: ${matrix.firstResponder.phone}\n` : ""}${matrix.firstResponder.line ? `- LINE: ${matrix.firstResponder.line}\n` : ""}- 対応可能時間: ${matrix.firstResponder.availableHours}

## 2次対応者 (Secondary)
- 氏名: ${matrix.secondary.name}
- 役割: ${matrix.secondary.role}
- Email: ${matrix.secondary.email}
${matrix.secondary.phone ? `- 電話: ${matrix.secondary.phone}\n` : ""}- 対応可能時間: ${matrix.secondary.availableHours}

${
  matrix.tertiary
    ? `## 3次対応者 (Tertiary)
- 氏名: ${matrix.tertiary.name}
- 役割: ${matrix.tertiary.role}
- Email: ${matrix.tertiary.email}
${matrix.tertiary.phone ? `- 電話: ${matrix.tertiary.phone}\n` : ""}- 対応可能時間: ${matrix.tertiary.availableHours}

`
    : ""
}## 事業継続責任者 (Business Owner)
- 氏名: ${matrix.businessOwner.name}
- 役割: ${matrix.businessOwner.role}
- Email: ${matrix.businessOwner.email}
${matrix.businessOwner.phone ? `- 電話: ${matrix.businessOwner.phone}\n` : ""}- 対応可能時間: ${matrix.businessOwner.availableHours}

${
  matrix.vendorSupport
    ? `## ベンダーサポート (SoloptiLinkAI社)
- 窓口: ${matrix.vendorSupport.name}
- Email: ${matrix.vendorSupport.email}
${matrix.vendorSupport.phone ? `- 電話: ${matrix.vendorSupport.phone}\n` : ""}- 対応可能時間: ${matrix.vendorSupport.availableHours}
`
    : ""
}

## エスカレーションルール
- **Critical アラート**: 1次対応者に即 LINE 通知 → 5 分で返信なし → 2 次対応者へ自動繰り上げ
- **Warning アラート**: 1 次対応者へ Slack 通知のみ。営業時間外は翌営業日対応
- **顧客からの直接連絡**: 1 次対応者が一次受付 → 15 分以内に折り返し

## 年末年始・GW・お盆の当直表
\`docs/runbook/shift_calendar.md\` を参照してください。
`;
}

// ───────────────────────────────────────────────
// Markdown 出力
// ───────────────────────────────────────────────

export function runbookToMarkdown(rb: Runbook): string {
  let md = `# ${rb.title}\n\n`;
  md += `**ID**: ${rb.id}  **版**: ${rb.version}  **最終更新**: ${rb.lastUpdated}\n\n`;
  md += `**対象システム**: ${rb.targetSystem}  **主担当**: ${rb.owner}\n`;
  md += `**レビュアー**: ${rb.reviewers.join(", ")}\n\n`;
  md += `## 概要\n\n${rb.overview}\n\n`;
  md += `## 事前条件\n\n${rb.prerequisites.map((p) => `- ${p}`).join("\n")}\n\n`;
  md += `## 手順\n\n`;
  for (const s of rb.steps) {
    md += `### ${s.order}. ${s.title}${s.durationMinutes ? ` (想定 ${s.durationMinutes}分)` : ""}\n\n`;
    md += `${s.description}\n\n`;
    if (s.command) md += `\`\`\`bash\n${s.command}\n\`\`\`\n\n`;
    if (s.expected) md += `**期待される結果**: ${s.expected}\n\n`;
    if (s.owner) md += `**担当**: ${s.owner}\n\n`;
  }
  if (rb.rollback && rb.rollback.length > 0) {
    md += `## ロールバック手順\n\n`;
    for (const s of rb.rollback) {
      md += `### ${s.order}. ${s.title}\n\n${s.description}\n\n`;
      if (s.command) md += `\`\`\`bash\n${s.command}\n\`\`\`\n\n`;
    }
  }
  md += `## 成功判定\n\n${rb.successCriteria.map((c) => `- ${c}`).join("\n")}\n\n`;
  if (rb.notes && rb.notes.length > 0) {
    md += `## 補足\n\n${rb.notes.map((n) => `- ${n}`).join("\n")}\n`;
  }
  return md;
}

// ───────────────────────────────────────────────
// 一括生成
// ───────────────────────────────────────────────

export function buildRunbookSet(meta: ProjectMetadata, matrix: EscalationMatrix): Runbook[] {
  return [
    generateDailyMaintenanceRunbook(meta, matrix),
    generateWeeklyMaintenanceRunbook(meta, matrix),
    generateMonthlyMaintenanceRunbook(meta, matrix),
    generateIncidentResponseRunbook(meta, matrix),
    generateDisasterRecoveryRunbook(meta, matrix),
  ];
}
