/**
 * lib/japan/amusement.ts — 風営法/深夜酒類提供/特定遊興飲食店DNA
 *
 * 法令カバレッジ:
 *  - 風俗営業等の規制及び業務の適正化等に関する法律 (風営法 S23法律122)
 *  - 風営法施行令 / 施行規則
 *  - 深夜における酒類提供飲食店営業 (風営法33条)
 *  - 特定遊興飲食店営業 (風営法 H28施行 — 31条の22)
 *  - 性風俗関連特殊営業 (店舗型/無店舗型/映像送信型)
 *  - 営業所周辺地域基準 (学校/病院/児童福祉施設からの距離)
 *  - 食品衛生法 (飲食店営業許可)
 *
 * 参考: 警察庁生活安全局保安課, 各都道府県警察 生活安全課
 */

// ============================================================================
// 1. 風俗営業 5区分 (風営法2条1項)
// ============================================================================

export type FuzokuKind =
  | 'type1' // 1号: 接待飲食 — キャバレー/料理店/カフェー (接待+酒類)
  | 'type2' // 2号: 低照度飲食 — 喫茶店/料理店等で照度10ルクス以下
  | 'type3' // 3号: 区画席飲食 — 5m²以下の客席+他の客席から見通し困難
  | 'type4' // 4号: 麻雀屋/パチンコ屋/スロット
  | 'type5'; // 5号: ゲームセンター (5割以上の機械賭博性 — TVゲーム/メダルゲーム等)

export const FUZOKU_BUSINESS_TYPES = {
  type1: { ja: '接待飲食 (1号)', examples: ['キャバレー', 'クラブ', 'スナック+接待', 'ホストクラブ'] },
  type2: { ja: '低照度飲食 (2号)', examples: ['暗いバー', 'ムード喫茶 (10lx以下)'] },
  type3: { ja: '区画席飲食 (3号)', examples: ['個室型バー (5m²以下区画+見通し困難)'] },
  type4: { ja: 'ぱちんこ・麻雀 (4号)', examples: ['パチンコ', 'パチスロ', '麻雀店'] },
  type5: { ja: 'ゲームセンター (5号)', examples: ['ゲームセンター', 'メダルゲーム場'] },
} as const;

// ============================================================================
// 2. 深夜営業 (午前0時以降) の判定
// ============================================================================

/** 風営法上の営業時間制限 */
export function getOperatingHourLimit(input: {
  category: FuzokuKind | 'late_night_alcohol' | 'special_entertainment';
  prefecture?: string;
}): {
  earliestStart: string;
  latestEnd: string;
  needsLateNightNotice: boolean;
  reason: string;
} {
  // 風俗営業 (1-5号): 原則午前0時まで (条例で1時まで延長可の自治体あり)
  if (input.category.startsWith('type')) {
    return {
      earliestStart: '06:00',
      latestEnd: '24:00 (24:00以降は風営法違反)',
      needsLateNightNotice: false,
      reason: '風営法13条 — 深夜0時以降は営業禁止 (条例で1時まで延長可)',
    };
  }
  // 深夜酒類提供飲食店 (33条): 午前0時以降に酒類提供 — 接待行為禁止
  if (input.category === 'late_night_alcohol') {
    return {
      earliestStart: '06:00',
      latestEnd: '06:00 (24時間営業可、但し接待禁止)',
      needsLateNightNotice: true,
      reason: '風営法33条 深夜酒類提供飲食店 — 警察署長へ届出 + 接待禁止',
    };
  }
  // 特定遊興飲食店 (31条の22 H28施行): クラブ等の深夜営業
  if (input.category === 'special_entertainment') {
    return {
      earliestStart: '06:00',
      latestEnd: '06:00 (24時間営業可、許可制)',
      needsLateNightNotice: false,
      reason: '風営法31条の22 特定遊興飲食店営業 — 公安委員会許可制',
    };
  }
  return { earliestStart: '06:00', latestEnd: '24:00', needsLateNightNotice: false, reason: '不明' };
}

// ============================================================================
// 3. 営業所所在地 規制 (周辺地域基準)
// ============================================================================

/** 風営法施行令6条 — 学校/病院/児童福祉施設等からの距離規制 (都道府県条例で具体化) */
export function checkSiteRestriction(input: {
  category: FuzokuKind | 'late_night_alcohol' | 'special_entertainment';
  distanceToSchoolM: number;
  distanceToHospitalM: number;
  distanceToChildcareM: number;
  zoning: 'commercial' | 'neutral' | 'residential' | 'mixed';
}): { restricted: boolean; reason: string } {
  // 住居系用途地域では風俗営業不可
  if (input.zoning === 'residential' && input.category.startsWith('type')) {
    return { restricted: true, reason: '住居系用途地域では風俗営業不可 (条例)' };
  }
  // 学校/病院/児童福祉施設から100m以内 (条例で50-200m変動)
  const minDistance = 100;
  if (
    input.distanceToSchoolM < minDistance ||
    input.distanceToHospitalM < minDistance ||
    input.distanceToChildcareM < minDistance
  ) {
    return {
      restricted: true,
      reason: `保全対象施設 (学校/病院/児童福祉) から${minDistance}m以内のため不可`,
    };
  }
  return { restricted: false, reason: '距離・用途地域条件充足' };
}

// ============================================================================
// 4. 風俗営業 許可申請 (風営法3条)
// ============================================================================

export interface FuzokuApplication {
  category: FuzokuKind;
  hasResponsibleManager: boolean; // 営業所管理者
  managerHasNoCriminalRecord: boolean; // 5年以内に風営法違反/暴対法違反等なし
  hasAdvancePermit: boolean; // 公安委員会許可
  hasFloorPlan: boolean;
  hasBuildingFireSafetyCert: boolean;
}

/** 風営法3条 許可の事前審査 */
export function evaluateFuzokuPermission(a: FuzokuApplication): {
  approvable: boolean;
  blockers: string[];
} {
  const blockers: string[] = [];
  if (!a.hasResponsibleManager) blockers.push('営業所管理者の選任必須 (風営法24条)');
  if (!a.managerHasNoCriminalRecord) {
    blockers.push('管理者は5年以内に風営法/暴対法違反 罰金以上なきこと');
  }
  if (!a.hasAdvancePermit) blockers.push('公安委員会の許可が必要 (風営法3条)');
  if (!a.hasFloorPlan) blockers.push('営業所の構造図面 + 客室面積算定書 必須');
  if (!a.hasBuildingFireSafetyCert) blockers.push('消防法 防火対象物点検報告書 必須');
  return { approvable: blockers.length === 0, blockers };
}

// ============================================================================
// 5. 接待行為の判定 (風営法2条3項)
// ============================================================================

/**
 * 接待行為: 「歓楽的雰囲気を醸し出す方法により客をもてなすこと」
 * 例: 隣に座って談笑/歌唱/手拍子・ショーダンス出演・客の身体に触れる等
 */
export function isHospitalityActPresent(input: {
  staffSittingNextToClient: boolean; // 従業員が客の隣に座る
  staffSinging: boolean; // カラオケで一緒に歌う
  staffDancing: boolean;
  staffPouringAlcohol: boolean; // お酌
  staffPlayingGame: boolean;
}): { isHospitality: boolean; matchedPatterns: string[] } {
  const m: string[] = [];
  if (input.staffSittingNextToClient) m.push('隣席接客 — 接待行為');
  if (input.staffSinging) m.push('歌唱接客 — 接待行為');
  if (input.staffDancing) m.push('踊り接客 — 接待行為');
  if (input.staffPlayingGame) m.push('ゲーム接客 — 接待行為');
  // お酌のみは接待にあたらない場合あり (個別判断)
  return { isHospitality: m.length > 0, matchedPatterns: m };
}

// ============================================================================
// 6. パチンコ店 (4号営業) — 出玉規制
// ============================================================================

/** パチンコ機の射幸性規制 (規則8条 + 公安委員会規則) */
export function checkPachinkoMachineCompliance(input: {
  isPachinko: boolean; // パチンコ機 (true) / パチスロ (false)
  maxPayoutPer4HoursMedals?: number; // 4時間最大出玉 (メダル)
  maxBalls10minTimes?: number; // 10分間最高 (発射玉数)
}): { compliant: boolean; reason: string } {
  // 出玉規制 (国家公安委員会規則): パチンコ4時間最大5万玉
  if (input.isPachinko && (input.maxBalls10minTimes ?? 0) > 100) {
    return { compliant: false, reason: 'パチンコ 10分100発を超過 (発射規制)' };
  }
  // パチスロ4時間最大2万枚 (5号機規制)
  if (!input.isPachinko && (input.maxPayoutPer4HoursMedals ?? 0) > 20_000) {
    return { compliant: false, reason: 'パチスロ 4時間2万枚超過 (5号機規制違反)' };
  }
  return { compliant: true, reason: '射幸性規制内' };
}

// ============================================================================
// 7. 特定遊興飲食店営業 (H28施行 — 31条の22)
// ============================================================================

/** クラブ等が午前0時以降も営業するための新カテゴリ (公安委員会許可制) */
export interface SpecialEntertainmentApplication {
  hasResponsibleManager: boolean;
  hasMandatoryNoise減: boolean; // 騒音漏出防止措置 (区画/防音)
  hasIDCheckSystem: boolean; // 身分証チェック (青少年立入禁止)
  zoningType: 'commercial' | 'neutral' | 'mixed';
}

export function evaluateSpecialEntertainmentPermission(a: SpecialEntertainmentApplication): {
  approvable: boolean;
  blockers: string[];
} {
  const blockers: string[] = [];
  if (a.zoningType !== 'commercial') {
    blockers.push('特定遊興飲食店営業は商業地域内のみ可 (条例)');
  }
  if (!a.hasResponsibleManager) blockers.push('営業所管理者必須');
  if (!a.hasMandatoryNoise減) blockers.push('騒音漏出防止 区画/防音設備必須');
  if (!a.hasIDCheckSystem) blockers.push('青少年 (18歳未満) 立入禁止 — 身分証チェック必須');
  return { approvable: blockers.length === 0, blockers };
}
