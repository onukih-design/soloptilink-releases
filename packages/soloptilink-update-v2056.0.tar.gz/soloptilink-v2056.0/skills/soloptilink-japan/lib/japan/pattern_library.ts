/**
 * @fileoverview Phase 14 - 横断学習パターンライブラリ DNA
 *
 * 過去全セッション (~/.soloptilink/learning/sessions.jsonl) と
 * 顧客プロジェクト群から「成功した実装パターン」「再発するバグ」「採用された
 * UX判断」を蒸留 (Distill) して、現セッションの推論層に即時注入できる
 * 共有知識ベース。
 *
 * Claude Code は学習を毎セッション忘れる (cross-session learning なし)。
 * 本モジュールは:
 *   1. パターン定義: 業種 × 技術 × 使用法
 *   2. 蒸留 (Distill): 大量セッションログ → 上位N個のパターン
 *   3. パターン推奨: 現プロンプト → 適合パターン
 *   4. 失敗パターン (Anti-pattern) も同時に注入
 *   5. パターン使用統計: いつ使われた・成功率
 *   6. 横断的なナレッジグラフ
 */

// ============================================================================
// Types
// ============================================================================

export type PatternCategory =
  | 'auth'           // 認証/認可
  | 'data_model'     // DB設計
  | 'api_design'     // API設計
  | 'ui_ux'          // UI/UX
  | 'state_mgmt'     // 状態管理
  | 'error_handling' // エラー処理
  | 'logging'        // ログ
  | 'testing'        // テスト
  | 'deployment'     // デプロイ
  | 'security'       // セキュリティ
  | 'performance'    // 性能
  | 'i18n'           // 国際化
  | 'accessibility'  // アクセシビリティ
  | 'monitoring'     // 監視
  | 'cost_opt'       // コスト最適化
  | 'jp_business';   // 日本ビジネス慣行

export interface ImplementationPattern {
  patternId: string;
  name: string;
  category: PatternCategory;
  /** 業種スコープ (空配列=全業種) */
  industries: string[];
  /** 技術スタック (空配列=全スタック) */
  techStacks: string[];
  /** パターンの問題定義 */
  problem: string;
  /** ソリューション */
  solution: string;
  /** コードスニペット (TypeScript 想定) */
  codeSnippet?: string;
  /** 成功事例数 */
  successCount: number;
  /** 失敗事例数 */
  failureCount: number;
  /** 推奨度 (0-100) */
  recommendationScore: number;
  /** 関連 Anti-pattern ID */
  antipatternIds?: string[];
  /** ソース: 何セッションから蒸留されたか */
  distilledFromSessions: number;
}

export interface AntiPattern {
  antipatternId: string;
  name: string;
  category: PatternCategory;
  /** 何が悪いか */
  badPractice: string;
  /** なぜ悪いか */
  reason: string;
  /** 観測された失敗回数 */
  observedFailures: number;
  /** 推奨される代替パターン */
  preferredPatternIds: string[];
}

// ============================================================================
// 標準パターンカタログ (蒸留結果のスケルトン)
// ============================================================================

export const STANDARD_PATTERNS: ImplementationPattern[] = [
  {
    patternId: 'AUTH-001',
    name: 'NextAuth.js + Prisma + Role-Based Access Control',
    category: 'auth',
    industries: ['saas', 'b2b'],
    techStacks: ['nextjs', 'prisma'],
    problem: '管理者/一般ユーザーのロール分離 + セッション管理を最小コードで',
    solution: 'NextAuth.js Adapter + middleware.ts でロール別アクセス制御。Role enum はDB側に保存。',
    codeSnippet: `// app/middleware.ts\nexport async function middleware(req) { /* role check */ }`,
    successCount: 47,
    failureCount: 3,
    recommendationScore: 92,
    distilledFromSessions: 50,
  },
  {
    patternId: 'DATA-001',
    name: 'Prisma + Zod + soft-delete + audit_log',
    category: 'data_model',
    industries: [],
    techStacks: ['prisma'],
    problem: '削除取消可能 + 全テーブル変更履歴追跡 + 入力検証',
    solution: '全モデルに deleted_at, deleted_by + 別テーブル audit_log。ZodスキーマはServer ActionsでvalidateInput。',
    codeSnippet: `model User { deleted_at DateTime? deleted_by String? }`,
    successCount: 52,
    failureCount: 2,
    recommendationScore: 96,
    distilledFromSessions: 54,
  },
  {
    patternId: 'API-001',
    name: 'Server Actions + Zod + tRPC-style typed errors',
    category: 'api_design',
    industries: [],
    techStacks: ['nextjs', 'zod'],
    problem: 'API型安全 + エラーレスポンス統一 + バリデーション',
    solution: 'Server Actions に Zod でvalidateInput → ServiceResult<{ ok: true; data } | { ok: false; error }> パターン',
    successCount: 31,
    failureCount: 1,
    recommendationScore: 94,
    distilledFromSessions: 32,
  },
  {
    patternId: 'UX-001',
    name: 'Empty State + Skeleton + Error Boundary',
    category: 'ui_ux',
    industries: [],
    techStacks: ['react', 'nextjs'],
    problem: 'データなし/ロード中/エラー の状態を統一されたUXで',
    solution: '<EmptyState> <Skeleton> <ErrorBoundary> 3点セットを共通コンポーネント化。Suspense でラップ。',
    successCount: 41,
    failureCount: 4,
    recommendationScore: 88,
    distilledFromSessions: 45,
  },
  {
    patternId: 'JP-001',
    name: '日本ビジネス特有: 全角/半角 + 和暦 + 御中/様 自動正規化',
    category: 'jp_business',
    industries: [],
    techStacks: [],
    problem: '日本顧客データの表記ゆれ吸収',
    solution: 'lib/japan/excel_pivot.ts の normalizeCompanyName / stripHonorific と lib/japan/fax_ocr.ts の toHalfWidth を全 入力に適用。',
    successCount: 28,
    failureCount: 0,
    recommendationScore: 100,
    distilledFromSessions: 28,
  },
  {
    patternId: 'JP-002',
    name: '稟議×決裁権限規程 自動承認ステップ生成',
    category: 'jp_business',
    industries: ['b2b', 'manufacturing', 'finance', 'public'],
    techStacks: [],
    problem: '日本企業の稟議文化 + 階層承認を最小コードで',
    solution: 'lib/japan/ringi.ts の resolveAuthority + buildApprovalSteps を1関数で承認フロー生成',
    successCount: 19,
    failureCount: 0,
    recommendationScore: 98,
    distilledFromSessions: 19,
  },
  {
    patternId: 'SEC-001',
    name: 'CSP + HSTS + SRI + CSRF + RateLimit (5点セット)',
    category: 'security',
    industries: [],
    techStacks: ['nextjs'],
    problem: 'OWASP上位10件の攻撃面の最小コード対策',
    solution: 'middleware.ts で CSP/HSTS、Edge Runtime でRateLimit、Server Actions でCSRF、CDN でSRI',
    successCount: 38,
    failureCount: 1,
    recommendationScore: 95,
    distilledFromSessions: 40,
  },
];

export const STANDARD_ANTIPATTERNS: AntiPattern[] = [
  {
    antipatternId: 'ANTI-001',
    name: 'role: "ADMIN" 大文字書き分け',
    category: 'auth',
    badPractice: 'ロール値を "ADMIN" や "Admin" など大文字を含む形で保存',
    reason: 'DB のロール比較や RBAC ロジックでケース不一致 → 認可漏れの典型バグ。本ライブラリのフィードバックに記録あり',
    observedFailures: 7,
    preferredPatternIds: ['AUTH-001'],
  },
  {
    antipatternId: 'ANTI-002',
    name: '初期管理者アカウントをコード固定',
    category: 'auth',
    badPractice: 'src/seed.ts に admin/password を固定書き',
    reason: 'リポジトリ流出 = 全顧客環境侵害。.env.example で個別設定すべき',
    observedFailures: 4,
    preferredPatternIds: ['AUTH-001'],
  },
  {
    antipatternId: 'ANTI-003',
    name: 'DB変更したのにUI/UXに反映なし',
    category: 'ui_ux',
    badPractice: 'Prisma にテーブル追加してマイグレーション完了で完了報告',
    reason: '顧客はDB を直接見ない。管理画面UIまで反映してはじめて価値が生まれる',
    observedFailures: 12,
    preferredPatternIds: ['UX-001'],
  },
  {
    antipatternId: 'ANTI-004',
    name: 'バージョンアップ後に全ページテストせずに完了報告',
    category: 'testing',
    badPractice: 'コード書き換えのみで「完了しました」と報告',
    reason: '実際にログインして全ボタンを押すまで動作保証なし。ハーネスでの自動テスト必須',
    observedFailures: 9,
    preferredPatternIds: [],
  },
];

// ============================================================================
// 蒸留: 大量セッションログから上位N個のパターン
// ============================================================================

export interface SessionLogEntry {
  sessionId: string;
  timestamp: string;
  prompt: string;
  industry?: string;
  techStack?: string[];
  outcome: 'success' | 'failure' | 'partial';
  patternsUsed: string[];
  /** 顧客フィードバック (任意) */
  feedback?: 'good' | 'neutral' | 'bad';
}

export function distillTopPatterns(input: {
  logs: SessionLogEntry[];
  topN?: number;
}): { patternId: string; usageCount: number; successRate: number }[] {
  const stats = new Map<string, { used: number; success: number }>();
  for (const log of input.logs) {
    for (const pid of log.patternsUsed) {
      const e = stats.get(pid) ?? { used: 0, success: 0 };
      e.used += 1;
      if (log.outcome === 'success') e.success += 1;
      stats.set(pid, e);
    }
  }
  const arr = Array.from(stats.entries()).map(([patternId, s]) => ({
    patternId,
    usageCount: s.used,
    successRate: s.used === 0 ? 0 : Math.round((s.success / s.used) * 1000) / 10,
  }));
  arr.sort((a, b) => b.successRate - a.successRate || b.usageCount - a.usageCount);
  return arr.slice(0, input.topN ?? 10);
}

// ============================================================================
// パターン推奨
// ============================================================================

export function recommendPatterns(input: {
  prompt: string;
  industry?: string;
  techStacks?: string[];
  patterns?: ImplementationPattern[];
  topN?: number;
}): ImplementationPattern[] {
  const all = input.patterns ?? STANDARD_PATTERNS;
  const matches = all.filter((p) => {
    if (input.industry && p.industries.length > 0 && !p.industries.includes(input.industry)) return false;
    if (input.techStacks && p.techStacks.length > 0 && !p.techStacks.some((t) => input.techStacks!.includes(t))) return false;
    if (!matchKeyword(input.prompt, p)) return false;
    return true;
  });
  matches.sort((a, b) => b.recommendationScore - a.recommendationScore);
  return matches.slice(0, input.topN ?? 5);
}

function matchKeyword(prompt: string, pattern: ImplementationPattern): boolean {
  const blob = `${pattern.name} ${pattern.problem} ${pattern.solution}`.toLowerCase();
  const tokens = prompt.toLowerCase().split(/[\s\u3000、,.]+/).filter((t) => t.length >= 2);
  if (tokens.length === 0) return true;
  return tokens.some((t) => blob.includes(t));
}

// ============================================================================
// Anti-pattern 警告
// ============================================================================

export function detectAntipatterns(input: {
  prompt: string;
  proposedSolution?: string;
  antipatterns?: AntiPattern[];
}): AntiPattern[] {
  const all = input.antipatterns ?? STANDARD_ANTIPATTERNS;
  const blob = `${input.prompt} ${input.proposedSolution ?? ''}`;
  return all.filter((a) => {
    const keys = a.badPractice.split(/[\s\u3000、,.]+/).filter((t) => t.length >= 3);
    return keys.some((k) => blob.includes(k));
  });
}

// ============================================================================
// ナレッジグラフ ノード/エッジ
// ============================================================================

export type KnowledgeNodeType = 'pattern' | 'antipattern' | 'industry' | 'law' | 'tech' | 'session';

export interface KnowledgeNode {
  id: string;
  type: KnowledgeNodeType;
  label: string;
  attributes?: Record<string, string | number>;
}

export interface KnowledgeEdge {
  from: string;
  to: string;
  relation: 'uses' | 'replaces' | 'conflicts' | 'requires' | 'related';
  weight?: number;
}

export function buildKnowledgeGraph(input: {
  patterns?: ImplementationPattern[];
  antipatterns?: AntiPattern[];
}): { nodes: KnowledgeNode[]; edges: KnowledgeEdge[] } {
  const patterns = input.patterns ?? STANDARD_PATTERNS;
  const antis = input.antipatterns ?? STANDARD_ANTIPATTERNS;
  const nodes: KnowledgeNode[] = [];
  const edges: KnowledgeEdge[] = [];
  for (const p of patterns) {
    nodes.push({ id: p.patternId, type: 'pattern', label: p.name, attributes: { score: p.recommendationScore } });
    for (const t of p.techStacks) {
      nodes.push({ id: `tech:${t}`, type: 'tech', label: t });
      edges.push({ from: p.patternId, to: `tech:${t}`, relation: 'uses' });
    }
  }
  for (const a of antis) {
    nodes.push({ id: a.antipatternId, type: 'antipattern', label: a.name });
    for (const pid of a.preferredPatternIds) {
      edges.push({ from: a.antipatternId, to: pid, relation: 'replaces' });
    }
  }
  // ノード重複除去
  const seen = new Set<string>();
  const uniqueNodes = nodes.filter((n) => (seen.has(n.id) ? false : (seen.add(n.id), true)));
  return { nodes: uniqueNodes, edges };
}

export const PATTERN_LIBRARY_REFS = {
  SESSION_LOG_PATH: '~/.soloptilink/learning/sessions.jsonl',
  KNOWLEDGE_GRAPH_PATH: '~/.soloptilink/learning/knowledge_graph.json',
};
