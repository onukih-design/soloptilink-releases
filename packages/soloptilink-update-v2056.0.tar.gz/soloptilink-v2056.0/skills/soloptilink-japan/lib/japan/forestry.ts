/**
 * lib/japan/forestry.ts — 林業・木材流通DNA
 *
 * 法令カバレッジ:
 *  - 森林法 (S26法律249) 森林経営計画 / 1ha超林地開発許可
 *  - クリーンウッド法 (合法伐採木材等流通利用促進法 R3.5施行 + R7.4改正)
 *  - 森林経営管理法 (R1.4施行)
 *  - 木材利用促進法 (R3.10改正 / 公共建築物等木材利用促進法→脱炭素社会木材利用促進法)
 *  - 国有林野管理経営法
 *  - 建築基準法 CLT (Cross Laminated Timber) H28告示611号
 *
 * 参考: 林野庁HP, クリーンウッド法登録事業者リスト, FSC/PEFC/SGEC認証スキーム
 */

// ============================================================================
// 1. 樹種・材積・歩留り
// ============================================================================

export type TreeSpecies =
  | 'sugi' // 杉
  | 'hinoki' // 桧
  | 'akamatsu' // 赤松
  | 'karamatsu' // 唐松
  | 'todomatsu' // トドマツ
  | 'ezomatsu' // エゾマツ
  | 'buna' // ブナ
  | 'nara' // ナラ
  | 'keyaki' // ケヤキ
  | 'douglas_fir' // ベイマツ (輸入)
  | 'spf'; // SPF (輸入)

/** 樹種別 標準密度 (kg/m³ 気乾比重) */
export const TIMBER_DENSITY: Record<TreeSpecies, number> = {
  sugi: 380,
  hinoki: 410,
  akamatsu: 530,
  karamatsu: 530,
  todomatsu: 400,
  ezomatsu: 430,
  buna: 650,
  nara: 670,
  keyaki: 690,
  douglas_fir: 480,
  spf: 420,
};

/**
 * 立木材積計算 (Pressler の片対数式の簡易版)
 *  V = (D/100)^2 × π/4 × H × f
 *    D: 胸高直径 cm, H: 樹高 m, f: 形状係数 (杉0.42 / 桧0.45 / 広葉樹0.50)
 */
export function calcStandingVolumeM3(input: {
  dbhCm: number; // 胸高直径
  heightM: number; // 樹高
  species: TreeSpecies;
}): number {
  const f =
    input.species === 'sugi'
      ? 0.42
      : input.species === 'hinoki'
        ? 0.45
        : input.species === 'akamatsu' || input.species === 'karamatsu'
          ? 0.44
          : 0.5;
  return ((input.dbhCm / 100) ** 2 * Math.PI) / 4 * input.heightM * f;
}

/** 製材歩留り (素材丸太 → 製材品) 目安 50-65% */
export function calcLumberYield(roughM3: number, species: TreeSpecies): number {
  const yieldRate =
    species === 'sugi' || species === 'hinoki'
      ? 0.6
      : species === 'spf' || species === 'douglas_fir'
        ? 0.62
        : 0.5;
  return roughM3 * yieldRate;
}

// ============================================================================
// 2. 森林経営計画 / 林地開発
// ============================================================================

/** 森林経営計画の認定要件 (森林法11条) */
export interface ForestPlan {
  ownerHa: number; // 所有森林面積
  planAreaHa: number; // 計画対象面積
  isContiguous: boolean; // 集約化されているか
  hasManagementPath: boolean; // 路網整備
}

/** 森林法11条: 30ha以上 (個人) / 100ha以上 (一体) で認定対象 */
export function isForestPlanEligible(p: ForestPlan): {
  eligible: boolean;
  reason: string[];
} {
  const r: string[] = [];
  if (p.planAreaHa < 30 && !p.isContiguous) r.push('30ha未満かつ集約化なし');
  if (!p.hasManagementPath) r.push('路網整備が必要');
  return { eligible: r.length === 0, reason: r };
}

/** 林地開発許可 (森林法10条の2) */
export function requiresForestDevelopmentPermit(input: {
  developmentHa: number;
  isProtectedForest: boolean; // 保安林か
}): { permitRequired: boolean; authority: string; reason: string } {
  if (input.isProtectedForest) {
    return {
      permitRequired: true,
      authority: '都道府県知事 (保安林解除)',
      reason: '保安林指定区域内のため、まず保安林解除が必要 (森林法27条)',
    };
  }
  if (input.developmentHa > 1.0) {
    return {
      permitRequired: true,
      authority: '都道府県知事',
      reason: '森林法10条の2 — 1ha超の林地開発は知事許可必須',
    };
  }
  return {
    permitRequired: false,
    authority: '不要',
    reason: '1ha以下のため許可不要 (要事前相談)',
  };
}

// ============================================================================
// 3. クリーンウッド法 (合法伐採木材等流通利用促進法 R3.5 + R7.4改正)
// ============================================================================

export type CleanWoodTier =
  | 'first_distributor' // 第一種登録木材関連事業者 (素材生産・輸入)
  | 'second_distributor' // 第二種登録木材関連事業者 (流通・加工)
  | 'unregistered'; // 未登録

export interface CleanWoodCheck {
  tier: CleanWoodTier;
  hasLegalityProof: boolean; // 合法性確認書類
  countryOfOrigin: string; // 伐採国
  hasFscOrPefc: boolean; // FSC/PEFC認証
  hasDueDiligence: boolean; // R7.4改正で義務化された確認措置
}

export interface CleanWoodResult {
  compliant: boolean;
  level: 'A' | 'B' | 'C' | 'X';
  riskScore: number; // 0(低) - 100(高)
  recommendations: string[];
}

/**
 * クリーンウッド法 適合性判定 (R7.4改正で第一種事業者は確認義務化)
 */
export function evaluateCleanWoodCompliance(c: CleanWoodCheck): CleanWoodResult {
  const recs: string[] = [];
  let risk = 0;

  // 高リスク国 (UNEP/UNODC 違法伐採率高)
  const HIGH_RISK_COUNTRIES = ['Myanmar', 'Cambodia', 'Laos', 'PNG', 'Russia', 'Mozambique'];
  if (HIGH_RISK_COUNTRIES.includes(c.countryOfOrigin)) {
    risk += 50;
    recs.push(`高リスク産地 (${c.countryOfOrigin}) — 第三者監査必須`);
  }

  if (!c.hasLegalityProof) {
    risk += 40;
    recs.push('合法性証明書類が不足 (伐採届出受理通知書 / 森林経営計画認定書など)');
  }
  if (!c.hasDueDiligence && c.tier === 'first_distributor') {
    risk += 30;
    recs.push('R7.4改正: 第一種事業者は確認措置 (Due Diligence) が義務化');
  }
  if (!c.hasFscOrPefc) {
    risk += 10;
    recs.push('FSC / PEFC / SGEC認証取得を推奨 (法的要件ではないが調達優位)');
  }

  let level: CleanWoodResult['level'];
  if (risk >= 80) level = 'X';
  else if (risk >= 50) level = 'C';
  else if (risk >= 20) level = 'B';
  else level = 'A';

  return {
    compliant: risk < 50 && c.hasLegalityProof,
    level,
    riskScore: Math.min(100, risk),
    recommendations: recs,
  };
}

// ============================================================================
// 4. CLT (Cross Laminated Timber) 構造設計
// ============================================================================

/** CLT 強度等級 (JAS 3079:2014) */
export const CLT_GRADES = {
  Mx60: { fc: 21.6, fb: 25.2, E: 6000 }, // 杉ベース
  Mx90: { fc: 27.0, fb: 31.5, E: 7000 },
  Mx120: { fc: 32.4, fb: 37.8, E: 9000 }, // 唐松/桧
  S60: { fc: 19.2, fb: 23.4, E: 5500 },
  S90: { fc: 24.0, fb: 27.0, E: 6500 },
} as const;

/** CLT パネル設計判定 (建築基準法 H28告示611号) */
export function checkCltDesign(input: {
  spanM: number;
  panelThicknessMm: number;
  grade: keyof typeof CLT_GRADES;
  loadKnPerM2: number;
  isFireZone: boolean; // 防火地域か
}): { ok: boolean; deflectionMm: number; warnings: string[] } {
  const g = CLT_GRADES[input.grade];
  const I = (1000 * input.panelThicknessMm ** 3) / 12; // 単位幅あたり断面二次モーメント (mm^4/m)
  const w = input.loadKnPerM2; // kN/m²
  const L = input.spanM * 1000; // mm
  // たわみ δ = 5wL^4 / (384 EI)  (簡略)
  const deflectionMm = (5 * (w / 1000) * L ** 4) / (384 * g.E * I);

  const warnings: string[] = [];
  if (deflectionMm > L / 250) warnings.push(`たわみ過大 (許容 L/250 = ${(L / 250).toFixed(1)}mm)`);
  if (input.isFireZone && input.panelThicknessMm < 150) {
    warnings.push('防火地域内では45分準耐火を満たすため150mm以上推奨');
  }
  return { ok: warnings.length === 0, deflectionMm, warnings };
}

// ============================================================================
// 5. 森林経営管理法 (R1.4施行) 集積計画
// ============================================================================

export interface ManagementConsignment {
  ownerName: string;
  forestAreaHa: number;
  consignTo: 'municipality' | 'private_operator';
  termYears: number; // 経営管理権の存続期間
}

/** 森林経営管理法: 経営管理権集積計画の妥当性チェック */
export function validateConsignmentPlan(c: ManagementConsignment): {
  valid: boolean;
  errors: string[];
} {
  const e: string[] = [];
  if (c.forestAreaHa <= 0) e.push('森林面積は正の値');
  if (c.termYears < 5 || c.termYears > 50) e.push('経営管理権の存続期間は5-50年');
  return { valid: e.length === 0, errors: e };
}

// ============================================================================
// 6. 木材利用促進法 (R3.10改正 — 脱炭素社会木材利用促進法)
// ============================================================================

/** 公共建築物の木造化率目標: R12までに低層公共建築物の木造化100% */
export function evaluateWoodUtilizationTarget(input: {
  buildingType: 'low_rise_public' | 'mid_rise_public' | 'high_rise' | 'private';
  storeys: number;
  woodVolumeM3: number;
  totalFloorAreaM2: number;
}): {
  targetMet: boolean;
  recommendation: string;
  carbonStorageTon: number; // 炭素貯蔵量 (CO2換算)
} {
  // 木材1m³あたり約0.25 t-C ≒ 0.92 t-CO2
  const carbonStorageTon = input.woodVolumeM3 * 0.92;

  if (input.buildingType === 'low_rise_public' && input.storeys <= 3) {
    const woodPerArea = input.woodVolumeM3 / input.totalFloorAreaM2;
    const targetMet = woodPerArea >= 0.15; // 0.15 m³/m² が目安
    return {
      targetMet,
      recommendation: targetMet
        ? '木材利用促進法の目標を達成'
        : `木材使用量が目安 (0.15 m³/m²) を下回る — 現在 ${woodPerArea.toFixed(3)}`,
      carbonStorageTon,
    };
  }
  return {
    targetMet: input.woodVolumeM3 > 0,
    recommendation: '中高層・民間建築物も改正法の対象 — 木造ハイブリッド化を検討',
    carbonStorageTon,
  };
}

// ============================================================================
// 7. 認証スキーム比較
// ============================================================================

export const FOREST_CERTIFICATION_SCHEMES = {
  FSC: { fullName: 'Forest Stewardship Council', global: true, costJpyPerYear: 500_000 },
  PEFC: { fullName: 'Programme for Endorsement of Forest Certification', global: true, costJpyPerYear: 350_000 },
  SGEC: { fullName: 'Sustainable Green Ecosystem Council (緑の循環認証)', global: false, costJpyPerYear: 200_000 },
} as const;

/** 認証スキームのレコメンド */
export function recommendForestCert(input: {
  exportTarget: 'EU' | 'US' | 'domestic';
  budgetJpy: number;
  forestAreaHa: number;
}): keyof typeof FOREST_CERTIFICATION_SCHEMES {
  if (input.exportTarget === 'EU' && input.budgetJpy >= 500_000) return 'FSC';
  if (input.exportTarget === 'US') return 'PEFC';
  return 'SGEC'; // 国内向け / 中小規模
}
