/**
 * SoloptiLinkAI Phase 45 — 税務ガバナンス + 国際租税対応
 *
 * 多国籍企業グループ向けの税務ガバナンス・移転価格・グローバルミニマムタックスを統合。
 *
 * カバー範囲:
 *  - OECD/G20 BEPS 行動計画 (Action 1〜15)
 *  - Pillar Two: グローバルミニマムタックス 15% (R6.4 国内法施行 / IIR 開始)
 *  - 移転価格税制 (措置法66条の4)
 *  - CbCR (Country-by-Country Report) 措置法66条の4の4 (連結売上高 1,000億円以上)
 *  - マスターファイル / ローカルファイル (連結売上高 100億円以上)
 *  - 事前確認制度 APA (Advance Pricing Arrangement)
 *  - CFC (Controlled Foreign Company) 措置法66条の6 (タックスヘイブン対策)
 *  - 過少資本税制 (措置法66条の5) / 過大支払利子税制 (措置法66条の5の2)
 *  - 移転価格文書化 (3 tier: master / local / CbCR)
 *  - 税務 CG の実務 (NTA Tax Corporate Governance)
 */

export type EntityRole = "ultimate_parent" | "intermediate" | "subsidiary" | "permanent_establishment";

export interface GroupEntity {
  entity_id: string;
  entity_name: string;
  jurisdiction: string; // ISO 3166 alpha-2
  role: EntityRole;
  effective_tax_rate: number; // 実効税率 %
  revenue_jpy: number;
  profit_before_tax_jpy: number;
  employees: number;
  tangible_assets_jpy: number;
}

export interface TaxFinding {
  rule: string;
  severity: "info" | "advice" | "warning" | "violation" | "audit_risk";
  hint: string;
}

/** Pillar Two GMT 15% 適用判定 (OECD GloBE Rules + R6改正法人税法)
 * 連結売上 7.5億ユーロ (約1,200億円) 以上の多国籍グループに適用
 */
export interface GroupConsolidatedFigures {
  consolidated_revenue_eur: number;
  fiscal_years_in_scope: number; // 過去4年中2年以上で7.5億EUR超
}

export function isGmtScope(g: GroupConsolidatedFigures): boolean {
  return g.consolidated_revenue_eur >= 750_000_000 && g.fiscal_years_in_scope >= 2;
}

export function checkPillarTwo(
  g: GroupConsolidatedFigures,
  entities: GroupEntity[],
): TaxFinding[] {
  const findings: TaxFinding[] = [];
  if (!isGmtScope(g)) {
    findings.push({
      rule: "OECD Pillar Two (GMT 15%)",
      severity: "info",
      hint: "連結売上 7.5億EUR未満 → GMT適用外。ただし将来超過時に備え情報基盤整備推奨。",
    });
    return findings;
  }

  const lowTaxEntities = entities.filter((e) => e.effective_tax_rate < 15);
  if (lowTaxEntities.length > 0) {
    findings.push({
      rule: "OECD Pillar Two GloBE Rules (IIR 2024〜)",
      severity: "audit_risk",
      hint: `実効税率15%未満の構成会社が ${lowTaxEntities.length} 社: ${lowTaxEntities
        .map((e) => `${e.entity_name}(${e.jurisdiction}, ${e.effective_tax_rate.toFixed(1)}%)`)
        .join(", ")}。Top-up Tax (15%差分) を IIR で UPE 国に納付。R6.4日本国内法施行済 (法人税法82条の2)。GIR (GloBE Information Return) 提出義務。`,
    });
  }

  return findings;
}

/** 移転価格税制 (措置法66条の4) */
export interface RelatedPartyTransaction {
  transaction_id: string;
  jp_party: string;
  foreign_party: string;
  foreign_country: string;
  transaction_type: "tangible_goods" | "services" | "intangibles" | "loans" | "cost_sharing";
  amount_jpy: number;
  pricing_method: "CUP" | "RP" | "CP" | "TNMM" | "PSM" | "other";
  has_apa: boolean;
}

export function checkTransferPricing(
  txs: RelatedPartyTransaction[],
  consolidatedRevenueJpy: number,
): TaxFinding[] {
  const findings: TaxFinding[] = [];

  // CbCR 義務 (措置法66条の4の4) — 連結売上 1,000億円以上
  if (consolidatedRevenueJpy >= 100_000_000_000) {
    findings.push({
      rule: "措置法66条の4の4 (CbCR)",
      severity: "warning",
      hint: "連結売上1,000億円以上 → CbCR 提出義務 (会計年度末翌日から1年以内)。e-Tax で UPE が提出 + 各構成会社が Master File / Local File 同時整備。違反30万円以下罰金 + 推定課税リスク。",
    });
  }

  // Master/Local File (措置法66条の4の5)
  if (consolidatedRevenueJpy >= 10_000_000_000) {
    findings.push({
      rule: "措置法66条の4の5 (マスターファイル + ローカルファイル)",
      severity: "warning",
      hint: "連結売上100億円以上 → Master/Local File整備義務 (確定申告期限+45日以内提示)。R5以降の調査で電子化 + 英語版併記がデフォルト要求。",
    });
  }

  // 高額単発取引 (50億円以上 or 無形資産)
  for (const tx of txs) {
    if (tx.transaction_type === "intangibles" && tx.amount_jpy >= 1_000_000_000) {
      findings.push({
        rule: "措置法66条の4 (無形資産取引)",
        severity: "audit_risk",
        hint: `${tx.transaction_id}: 高額無形資産取引 ¥${tx.amount_jpy.toLocaleString()}。BEPS Action 8-10 + DEMPE 機能分析 (Development/Enhancement/Maintenance/Protection/Exploitation) 文書化。${tx.has_apa ? "APAで保護" : "APAなし → 事前確認推奨"}.`,
      });
    }
    if (tx.amount_jpy >= 5_000_000_000 && !tx.has_apa) {
      findings.push({
        rule: "措置法66条の4 (高額関連者取引)",
        severity: "advice",
        hint: `${tx.transaction_id}: ¥${tx.amount_jpy.toLocaleString()} は更正リスク。事前確認 (APA) 申請で予測可能性を確保。`,
      });
    }
  }

  return findings;
}

/** タックスヘイブン対策税制 / CFC (措置法66条の6) */
export interface CfcAssessment {
  foreign_subsidiary: string;
  jurisdiction: string;
  effective_tax_rate: number; // %
  passive_income_ratio: number; // 受動的所得 / 総所得 %
  has_substantial_business: boolean; // 事業実体テスト (経済活動基準)
  has_qualified_employees: boolean;
}

export function checkCfcRule(c: CfcAssessment): TaxFinding[] {
  const findings: TaxFinding[] = [];
  // 法定実体基準 (経済活動基準) 4要件のうち実態テスト + 管理支配テストが核心
  const isLowTax = c.effective_tax_rate < 20; // 軽課税国の閾値 (旧トリガー税率)
  if (!isLowTax) return findings;

  if (!c.has_substantial_business) {
    findings.push({
      rule: "措置法66条の6 (CFC ペーパーカンパニー認定)",
      severity: "violation",
      hint: `${c.foreign_subsidiary} (${c.jurisdiction}, ETR ${c.effective_tax_rate.toFixed(1)}%): 事業実体テスト failed → ペーパーカンパニー認定 → 全所得を日本親会社に合算課税。`,
    });
  } else if (c.passive_income_ratio > 50) {
    findings.push({
      rule: "措置法66条の6 (受動的所得 部分合算)",
      severity: "warning",
      hint: `受動的所得比率 ${c.passive_income_ratio.toFixed(0)}% > 50% → 部分合算課税対象。R6改正で資産性所得の定義拡大。`,
    });
  }

  return findings;
}

/** 過大支払利子税制 (措置法66条の5の2) — Earnings Stripping Rule */
export interface InterestExpense {
  net_interest_jpy: number;
  ebitda_adjusted_jpy: number;
}

export function checkEarningsStripping(e: InterestExpense): TaxFinding[] {
  const findings: TaxFinding[] = [];
  if (e.ebitda_adjusted_jpy <= 0) return findings;
  const ratio = e.net_interest_jpy / e.ebitda_adjusted_jpy;
  if (ratio > 0.2) {
    findings.push({
      rule: "措置法66条の5の2 (過大支払利子)",
      severity: "warning",
      hint: `純支払利子 / 調整後EBITDA = ${(ratio * 100).toFixed(1)}% > 20% → R2改正で超過分損金不算入 (繰越7年)。BEPS Action 4 整合。`,
    });
  }
  return findings;
}

/** 過少資本税制 (措置法66条の5) */
export interface ThinCapitalization {
  related_party_debt_jpy: number;
  net_equity_jpy: number;
}

export function checkThinCapitalization(
  t: ThinCapitalization,
): TaxFinding[] {
  const findings: TaxFinding[] = [];
  if (t.net_equity_jpy <= 0) return findings;
  const ratio = t.related_party_debt_jpy / t.net_equity_jpy;
  if (ratio > 3.0) {
    findings.push({
      rule: "措置法66条の5 (過少資本)",
      severity: "warning",
      hint: `関連者負債 / 自己資本 = ${ratio.toFixed(2)} > 3:1 → 超過分の利子は損金不算入。`,
    });
  }
  return findings;
}

/** Tax Corporate Governance (NTA 取り組み) 成熟度 */
export interface TaxCgMaturity {
  has_tax_policy: boolean;
  policy_board_approved: boolean;
  has_tax_risk_register: boolean;
  has_tax_audit_committee_report: boolean;
  uses_horizontal_monitoring: boolean; // NTA 大規模法人向け協力的コンプライアンス
}

export function evaluateTaxCgMaturity(
  m: TaxCgMaturity,
): TaxFinding[] {
  const findings: TaxFinding[] = [];
  if (!m.has_tax_policy) {
    findings.push({
      rule: "NTA 税務 CG (税務方針)",
      severity: "advice",
      hint: "税務方針 (Tax Policy / Tax Strategy) 未策定。プライム上場+海外展開なら必須実務。GRI 207 + UK Tax Strategy 公開法 を参考に策定。",
    });
  }
  if (!m.uses_horizontal_monitoring) {
    findings.push({
      rule: "NTA 税務に関するコーポレートガバナンスの充実 (R3〜)",
      severity: "info",
      hint: "NTA との協力的コンプライアンス (大規模法人向け定期協議) 未活用。税務調査負担軽減 + 予測可能性向上。",
    });
  }
  return findings;
}

/** 統合 Tax Risk アセスメント */
export function assessTaxRisk(input: {
  group_figures: GroupConsolidatedFigures;
  entities: GroupEntity[];
  related_party_txs: RelatedPartyTransaction[];
  consolidated_revenue_jpy: number;
  cfcs: CfcAssessment[];
  interest_exp?: InterestExpense;
  thin_cap?: ThinCapitalization;
  cg_maturity: TaxCgMaturity;
}): TaxFinding[] {
  return [
    ...checkPillarTwo(input.group_figures, input.entities),
    ...checkTransferPricing(input.related_party_txs, input.consolidated_revenue_jpy),
    ...input.cfcs.flatMap(checkCfcRule),
    ...(input.interest_exp ? checkEarningsStripping(input.interest_exp) : []),
    ...(input.thin_cap ? checkThinCapitalization(input.thin_cap) : []),
    ...evaluateTaxCgMaturity(input.cg_maturity),
  ];
}

export function buildTaxStrategyTemplate(orgName: string): string {
  return `# ${orgName} 税務戦略

## 1. 基本方針
${orgName} (以下「当社」) は、事業を行うすべての国・地域において、各国税法 + 租税条約 + OECD ガイドラインに従い、適正な税務処理を行う。

## 2. ガバナンス
- 税務統括責任者: CFO
- 取締役会への定期報告 (年2回): 税務リスク + 主要係争状況 + 実効税率推移

## 3. 移転価格
- 関連者取引はすべて Arm's Length Principle に従う
- 連結売上 1,000億円以上時は CbCR を、100億円以上時は Master/Local File を整備
- 大型かつ継続性のある取引は事前確認制度 (APA) を活用

## 4. グローバルミニマムタックス (Pillar Two)
- 連結売上 7.5億EUR以上時は GMT 15% 対応 (IIR/UTPR/QDMTT)
- 各国構成会社の実効税率を四半期モニタリング

## 5. タックスヘイブン
- 軽課税国子会社は事業実体テスト (経済活動基準) を毎年検証
- ペーパーカンパニー化を防止する組織体制

## 6. 透明性
- 国別税負担を統合報告書で開示 (GRI 207-4 準拠)
- 取引相手国の政府との対話を尊重

## 7. 違反時の対応
重大な税務リスクを発見した場合、CFO は速やかに監査委員会・取締役会に報告し、是正計画を策定する。
`;
}
