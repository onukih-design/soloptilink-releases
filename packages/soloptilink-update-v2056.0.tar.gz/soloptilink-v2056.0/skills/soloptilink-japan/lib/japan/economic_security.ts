/**
 * SoloptiLinkAI Phase 49-ES — 経済安全保障推進法 (令和4年法律第43号)
 *
 * 「経済施策を一体的に講ずることによる安全保障の確保の推進に関する法律」
 *  R4.5.18 公布 / R4.8.1 一部施行 / R5.4 サプライチェーン本格運用 /
 *  R5.5 基幹インフラ事前審査運用 / R6.5.1 特許出願非公開制度 施行
 *
 * 4本柱:
 *  ① サプライチェーン強靭化 (法6-48条)            — 特定重要物資 12品目 + 基金1兆円超
 *  ② 基幹インフラ役務の安定的提供 (法49-59条)        — 14業種315事業者 事前審査
 *  ③ 先端的な重要技術の開発支援 (法60-78条)          — K Program (5,000億円基金)
 *  ④ 特許出願の非公開 (法65-85条 R6.5.1施行)         — 25カテゴリ + 1次/2次審査
 *
 * 関連改正:
 *  - 外為法27条 (対内直接投資審査) と連動
 *  - 重要土地等調査法 (R3.6施行) との運用整合
 *  - 「機微技術指定」(METI 告示)
 *
 * 出典:
 *  - 内閣府 経済安全保障 https://www.cao.go.jp/keizai_anzen_hosho/
 *  - 特許庁 特許出願非公開 https://www.jpo.go.jp/
 */

// ----------------------------------------------------------------------
// 1) 特定重要物資 (12 品目) — サプライチェーン本柱
// ----------------------------------------------------------------------

/**
 * 特定重要物資 一覧 (R4.12 政令指定 + R5.6 追加 + R6 追加)
 *  指定すると ① 計画認定 ② 助成金 ③ 政府調達優遇 が動く
 */
export const CRITICAL_GOODS = [
  { id: "semiconductor", name: "半導体" },
  { id: "battery", name: "蓄電池 (車載用 + 定置用)" },
  { id: "pharmaceutical", name: "医薬品 (抗菌薬・原薬・経口血糖降下薬等)" },
  { id: "critical_minerals", name: "重要鉱物 (リチウム・ニッケル・コバルト・希土類等)" },
  { id: "lng", name: "天然ガス (LNG調達)" },
  { id: "ship_parts", name: "船舶部品 (低速舶用ディーゼルエンジン等)" },
  { id: "aircraft_parts", name: "航空機部品 (機体構造部品等)" },
  { id: "machine_tools_robots", name: "工作機械・産業用ロボット" },
  { id: "cloud_program", name: "クラウドプログラム (パブリッククラウド)" },
  { id: "fertilizer", name: "肥料 (尿素・りん安・塩化加里等)" },
  { id: "permanent_magnet", name: "永久磁石 (Nd磁石・SmCo磁石)" },
  { id: "industrial_gas", name: "工業用ガス (希ガス・特殊ガス)" },
] as const;

export type CriticalGoodId = (typeof CRITICAL_GOODS)[number]["id"];

// ----------------------------------------------------------------------
// 2) 基幹インフラ役務 — 14 業種事前審査
// ----------------------------------------------------------------------

/**
 * 基幹インフラ役務 (R5.5.17 政令施行)
 *  指定事業者の重要設備の導入・維持管理委託について、内閣総理大臣への事前届出
 *  → 排除すべき事項を勧告 → 命令違反: 2年以下の懲役/100万円以下の罰金 (法91-92条)
 */
export const CORE_INFRA_SECTORS = [
  { id: "electricity", name: "電気事業", regulator: "経産省" },
  { id: "gas", name: "ガス事業", regulator: "経産省" },
  { id: "petroleum", name: "石油" /* R6.5 追加 */, regulator: "経産省" },
  { id: "water", name: "水道事業", regulator: "国交省/厚労省" },
  { id: "railway", name: "鉄道事業", regulator: "国交省" },
  { id: "freight_truck", name: "貨物自動車運送", regulator: "国交省" },
  { id: "international_freight", name: "外航貨物海運", regulator: "国交省" },
  { id: "aviation", name: "航空", regulator: "国交省" },
  { id: "airport", name: "空港", regulator: "国交省" },
  { id: "telecom", name: "電気通信", regulator: "総務省" },
  { id: "broadcasting", name: "放送", regulator: "総務省" },
  { id: "postal", name: "郵便", regulator: "総務省" },
  { id: "finance", name: "金融 (銀行・証券・保険等)", regulator: "金融庁" },
  { id: "credit_card", name: "クレジットカード (包括信用購入あっせん)", regulator: "経産省" },
  { id: "port", name: "港湾運送" /* R6.5 追加 */, regulator: "国交省" },
] as const;

export type CoreInfraSectorId = (typeof CORE_INFRA_SECTORS)[number]["id"];

export interface CoreInfraNotificationInput {
  sector: CoreInfraSectorId;
  business_size_top10: boolean; // 業界上位事業者 (政令で指定)
  equipment_critical: boolean; // 「特定重要設備」該当
  vendor_country: string;
  vendor_state_owned: boolean; // 国有企業
  has_remote_management_clause: boolean; // 海外からの遠隔管理可能か
  has_supplychain_disclosure: boolean; // サプライチェーン開示
}

export type CoreInfraDecision =
  | "ok_no_review_needed"
  | "needs_prior_notification"
  | "high_risk_recommend_change"
  | "denial_likely";

export interface CoreInfraAssessment {
  decision: CoreInfraDecision;
  reason: string;
  required_actions: string[];
  estimated_review_days: number; // 30日が原則 (法52条) / 延長可
}

export function assessCoreInfraNotification(input: CoreInfraNotificationInput): CoreInfraAssessment {
  if (!input.business_size_top10 || !input.equipment_critical) {
    return {
      decision: "ok_no_review_needed",
      reason: "指定事業者または特定重要設備に該当せず、事前届出義務外",
      required_actions: [],
      estimated_review_days: 0,
    };
  }
  // 国有企業 + 遠隔管理可 = 排除勧告リスク高
  if (input.vendor_state_owned && input.has_remote_management_clause) {
    return {
      decision: "denial_likely",
      reason: "外国国有企業による遠隔管理可能設備 → 重大なリスク",
      required_actions: [
        "ベンダー変更を検討",
        "遠隔管理を物理的に遮断する技術措置 + 代替契約条項",
        "サプライチェーン代替案の準備",
      ],
      estimated_review_days: 60,
    };
  }
  if (!input.has_supplychain_disclosure) {
    return {
      decision: "high_risk_recommend_change",
      reason: "サプライチェーン開示が不十分 → 内閣府の勧告対象になりうる",
      required_actions: ["Tier 2 までのサプライヤー開示", "重要部品の原産国一覧"],
      estimated_review_days: 45,
    };
  }
  return {
    decision: "needs_prior_notification",
    reason: "通常の事前届出として処理 (法52条)",
    required_actions: ["内閣府への事前届出 (導入30日前まで)", "答申後に契約締結"],
    estimated_review_days: 30,
  };
}

// ----------------------------------------------------------------------
// 3) 先端的な重要技術 (K Program — 経済安全保障重要技術育成プログラム)
// ----------------------------------------------------------------------

/**
 * 「特定重要技術」 (法60条 + 内閣府告示)
 *  R5 時点 27 領域 → R6 拡張 50 領域超
 *  K Program = 5000億円規模 + 機微情報扱いのため Cleared Researcher 制度導入
 */
export const CRITICAL_TECH_DOMAINS = [
  "AI/機械学習",
  "量子情報",
  "ロボット工学",
  "先端センサー",
  "先端エネルギー",
  "サイバーセキュリティ",
  "宇宙",
  "海洋",
  "極超音速 (ハイパーソニック)",
  "化学・生物・放射性物質防護",
  "先端材料",
  "先端製造",
  "ナノテクノロジー",
  "通信ネットワーク",
  "データ分析",
  "ヘルスケア・バイオテクノロジー",
  "Position・Navigation・Timing (PNT)",
  "電源・エネルギー貯蔵",
  "輸送 (自律航行/モビリティ)",
  "気候・環境",
  "農業・食料",
  "Web3",
  "脳科学・ヒューマンインターフェイス",
  "光通信",
  "アディティブ・マニュファクチャリング",
  "5G/6G",
  "半導体製造装置",
] as const;

export interface KProgramApplicationInput {
  technology_domain: (typeof CRITICAL_TECH_DOMAINS)[number] | string;
  researcher_count: number;
  has_security_clearance_program: boolean; // 適格性 (Cleared Researcher) 整備
  partner_countries: string[]; // 共同研究相手国
  has_export_compliance: boolean; // 輸出管理プログラム
  proposed_budget_jpy: number;
}

export interface KProgramDecision {
  approval: "recommended" | "conditional" | "rejected";
  estimated_grant_jpy: number;
  reasons: string[];
  required_safeguards: string[];
}

export function evaluateKProgram(app: KProgramApplicationInput): KProgramDecision {
  const reasons: string[] = [];
  const safeguards: string[] = [];

  if (!app.has_security_clearance_program) {
    reasons.push("Cleared Researcher 制度が未整備 (法65条 機微情報扱い)");
    safeguards.push("適性評価 7項目 (特定秘密保護法と整合) を整備");
  }
  if (!app.has_export_compliance) {
    reasons.push("輸出管理プログラム (CP) が未整備");
    safeguards.push("外為法48条 に基づく内部取引管理規程");
  }
  // 共同研究相手国に懸念国 (北朝鮮/イラン/シリア等) があれば自動拒否
  const concernedCountries = ["北朝鮮", "イラン", "シリア", "キューバ"];
  if (app.partner_countries.some((c) => concernedCountries.includes(c))) {
    return {
      approval: "rejected",
      estimated_grant_jpy: 0,
      reasons: ["共同研究相手国に懸念国を含む"],
      required_safeguards: [],
    };
  }

  if (reasons.length === 0) {
    return {
      approval: "recommended",
      estimated_grant_jpy: app.proposed_budget_jpy, // 100% 助成 (R&D基金)
      reasons: ["安全保障要件を充足"],
      required_safeguards: ["年次セキュリティ監査", "技術成果の事前共有 (Pre-publication review)"],
    };
  }
  return {
    approval: "conditional",
    estimated_grant_jpy: Math.floor(app.proposed_budget_jpy * 0.5),
    reasons,
    required_safeguards: safeguards,
  };
}

// ----------------------------------------------------------------------
// 4) 特許出願非公開制度 (R6.5.1 施行 — 法65-85条)
// ----------------------------------------------------------------------

/**
 * 1次審査 (特許庁) → 国家及び国民の安全を損なう事態を生ずる恐れの大きい発明 → 内閣府送付
 * 2次審査 (内閣府) → 「保全指定」 → 出願公開停止 + 実施制限 + 補償金
 *
 * 特定技術分野 25 カテゴリ (R6 政令 別表)
 */
export const SECRET_PATENT_CATEGORIES = [
  "核兵器の研究、開発、製造に用いられる発明",
  "ガス弾頭の発明",
  "核燃料物質の濃縮 (5%以上)",
  "潜水船の航行", // 特に深度・耐圧
  "潜水船発進装置",
  "音波・電波・磁界・重力波の精密検出 (PNT)",
  "無人航空機 (一定要件)",
  "対潜水艦戦システム",
  "電子戦システム",
  "対艦ミサイル",
  "対戦車ミサイル",
  "弾道ミサイル",
  "極超音速飛翔体",
  "宇宙航行体 (一定要件)",
  "対宇宙物体システム",
  "暗号 (一部の量子暗号)",
  "電磁パルス兵器",
  "指向性エネルギー兵器",
  "生物剤・化学剤の製造",
  "毒素",
  "原子力電池",
  "極超音速エンジン",
  "対衛星兵器",
  "対迫撃砲レーダー",
  "電磁波吸収体 (ステルス)",
] as const;

export type SecretPatentCategory = (typeof SECRET_PATENT_CATEGORIES)[number];

export interface SecretPatentScreening {
  filing_id: string;
  technical_field_match: boolean; // 25カテゴリ該当
  has_dual_use_explanation: boolean; // 民生用途説明
  applicant_is_japanese: boolean;
  /** 「政令で定める要件」充足 — 例: 米国・欧州先願ありで本件後願 */
  has_overseas_prior_filing: boolean;
}

export type SecretPatentDecision =
  | "no_review" // カテゴリ非該当
  | "first_review" // 1次審査 (特許庁) のみで終了
  | "send_to_cabinet" // 2次審査 (内閣府) 送付
  | "designation_likely"; // 保全指定がほぼ確実

export interface SecretPatentResult {
  decision: SecretPatentDecision;
  reason: string;
  estimated_review_days: number; // 1次=3-9ヶ月、2次=最大10ヶ月
  applicant_obligations: string[];
}

export function screenSecretPatent(s: SecretPatentScreening): SecretPatentResult {
  if (!s.technical_field_match) {
    return {
      decision: "no_review",
      reason: "政令別表の特定技術分野に該当しない",
      estimated_review_days: 0,
      applicant_obligations: [],
    };
  }
  // 海外先願ありの場合は外為法 25条 役務取引で別経路。本制度は対象外運用
  if (s.has_overseas_prior_filing) {
    return {
      decision: "first_review",
      reason: "海外先願あり → 既に保全意義喪失。1次審査終了で公開",
      estimated_review_days: 90,
      applicant_obligations: ["外国出願時の役務取引許可確認 (外為法25条)"],
    };
  }
  if (s.has_dual_use_explanation) {
    return {
      decision: "first_review",
      reason: "民生用途中心 → 1次審査で公開判断の可能性",
      estimated_review_days: 180,
      applicant_obligations: ["1次審査結果通知の受領 + 公開特例3年遵守"],
    };
  }
  return {
    decision: "send_to_cabinet",
    reason: "特定技術分野に該当 + 軍事転用懸念 → 2次審査 (内閣府)",
    estimated_review_days: 270,
    applicant_obligations: [
      "保全指定通知の受領",
      "保全期間中の出願公開停止 (10年単位で更新)",
      "発明の実施には内閣総理大臣の許可必要 (法73条)",
      "海外出願は禁止 (法78条)",
      "損失補償金の請求権 (法80-82条)",
    ],
  };
}

// ----------------------------------------------------------------------
// 5) 対内直接投資審査 (FIRB相当 — 外為法27条改正)
// ----------------------------------------------------------------------

export type CoreSectorRisk = "low" | "medium" | "high";

export interface InboundInvestmentInput {
  investor_country: string;
  acquisition_pct: number; // 取得議決権割合
  target_industry: string;
  is_core_sector: boolean; // コア業種 (武器/航空機/原子力/サイバーセキュリティ等)
  is_listed: boolean;
  has_govt_link: boolean; // 投資家側政府との関係
}

export interface InboundDecision {
  filing_required: boolean;
  filing_type: "post_facto" | "advance_notification" | "exempt";
  exemption_eligible: boolean;
  estimated_review_days: number;
}

export function assessInboundInvestment(input: InboundInvestmentInput): InboundDecision {
  // コア業種 + 1%以上 取得 → 事前届出
  if (input.is_core_sector && input.acquisition_pct >= 1) {
    return {
      filing_required: true,
      filing_type: "advance_notification",
      exemption_eligible: false,
      estimated_review_days: 30, // 法27条 5項 標準
    };
  }
  // 一般業種 + 10%以上 取得 → 事前届出 (上場 + 外国金融機関は免除)
  if (!input.is_core_sector && input.acquisition_pct >= 10) {
    const exempt = input.is_listed && !input.has_govt_link;
    return {
      filing_required: !exempt,
      filing_type: exempt ? "post_facto" : "advance_notification",
      exemption_eligible: exempt,
      estimated_review_days: exempt ? 0 : 30,
    };
  }
  return {
    filing_required: false,
    filing_type: "exempt",
    exemption_eligible: true,
    estimated_review_days: 0,
  };
}
