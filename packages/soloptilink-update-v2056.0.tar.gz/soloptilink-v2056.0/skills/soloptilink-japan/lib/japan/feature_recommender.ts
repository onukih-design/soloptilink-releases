/**
 * SoloptiLinkAI Phase 16 — Feature Recommender
 *
 * Silent Inference Engine の推論結果と過去セッションのパターンから、
 * 「次に作るべき機能」「優先実装すべきモジュール」「投入すべき法令/帳票」を推薦する。
 *
 * 入力:
 *   - 推論サマリー (Silent Inference Engine の出力)
 *   - DomainCoverage (learning_analytics)
 *   - ModuleUsage (usage_insights)
 *
 * 出力:
 *   - FeatureRecommendation[] (優先順位つき)
 */

import type { DomainCoverage } from "./learning_analytics.ts";
import type { ModuleUsage } from "./usage_insights.ts";

export interface InferenceSummary {
  industry?: string;
  roles?: string[];
  features?: string[];
  tech_stack?: string;
  deployment_target?: string;
  scope?: "new" | "modify" | "integrate";
  workspace_hints?: string[];
}

export interface FeatureRecommendation {
  feature: string;
  rationale: string;
  priority: "P0" | "P1" | "P2";
  required_modules: string[];
  required_dictionaries: string[];
  required_templates: string[];
  estimated_quality_lift: number;
}

const INDUSTRY_FEATURE_BUNDLE: Record<string, FeatureRecommendation[]> = {
  construction: [
    {
      feature: "概算見積エンジン (坪単価→数量拾い→詳細)",
      rationale: "建設業の80%が初回問い合わせ時に概算見積を要求 (業種ヒアリング集計)",
      priority: "P0",
      required_modules: ["estimates", "architecture", "regional_laws"],
      required_dictionaries: ["construction"],
      required_templates: ["Estimate", "Invoice"],
      estimated_quality_lift: 8,
    },
    {
      feature: "建設業法準拠 受注台帳",
      rationale: "下請法+建設業法 19条の3 の罰則回避が最重要",
      priority: "P0",
      required_modules: ["laws", "save_guarantee"],
      required_dictionaries: ["construction"],
      required_templates: ["PurchaseOrder", "DeliveryNote"],
      estimated_quality_lift: 6,
    },
  ],
  healthcare: [
    {
      feature: "診療報酬計算 + UKEレセプト電算処理",
      rationale: "医療機関では月初のレセプト提出が法定義務 (R6改定対応必須)",
      priority: "P0",
      required_modules: ["medical", "law_tracker"],
      required_dictionaries: ["healthcare"],
      required_templates: ["Invoice", "Receipt"],
      estimated_quality_lift: 10,
    },
    {
      feature: "HPKI 電子署名 (3省2ガイドライン準拠)",
      rationale: "電子カルテ/処方箋の本人認証で必須",
      priority: "P1",
      required_modules: ["medical", "eseal"],
      required_dictionaries: ["healthcare"],
      required_templates: [],
      estimated_quality_lift: 5,
    },
  ],
  longterm_care: [
    {
      feature: "介護報酬計算 + LIFE 科学的介護情報アップロード",
      rationale: "R6改定で処遇改善加算が一本化、LIFE提出は加算要件",
      priority: "P0",
      required_modules: ["longterm_care"],
      required_dictionaries: ["healthcare"],
      required_templates: ["Invoice"],
      estimated_quality_lift: 9,
    },
    {
      feature: "ケアプラン1〜7表 自動生成",
      rationale: "居宅介護支援事業所の必須帳票",
      priority: "P0",
      required_modules: ["longterm_care"],
      required_dictionaries: ["healthcare"],
      required_templates: ["Report"],
      estimated_quality_lift: 7,
    },
  ],
  finance: [
    {
      feature: "全銀フォーマット 120バイト固定長振込ファイル生成",
      rationale: "金融機関連携の事実上のデファクト",
      priority: "P0",
      required_modules: ["finance"],
      required_dictionaries: ["finance"],
      required_templates: [],
      estimated_quality_lift: 8,
    },
    {
      feature: "金商法適合性原則 自動チェック (75歳/投資経験/純資産)",
      rationale: "金融商品取引業の説明責任で必須",
      priority: "P1",
      required_modules: ["finance", "laws_extended"],
      required_dictionaries: ["finance"],
      required_templates: ["Contract"],
      estimated_quality_lift: 6,
    },
  ],
  retail: [
    {
      feature: "景表法 + 特商法 マーケコピー検証",
      rationale: "EC/小売の販促文言は景表法第5条 (優良誤認/有利誤認) 違反リスク",
      priority: "P0",
      required_modules: ["marketing_compliance"],
      required_dictionaries: ["retail"],
      required_templates: [],
      estimated_quality_lift: 7,
    },
    {
      feature: "RFM分析 + LTV予測",
      rationale: "顧客セグメント別の打ち手の根拠付け",
      priority: "P1",
      required_modules: ["customer_journey"],
      required_dictionaries: ["retail"],
      required_templates: ["Report"],
      estimated_quality_lift: 5,
    },
  ],
  it: [
    {
      feature: "SES契約書 + 36協定 自動チェック",
      rationale: "労基法+派遣法のリスクが集中する業種",
      priority: "P1",
      required_modules: ["laws", "hr_payroll"],
      required_dictionaries: ["it"],
      required_templates: ["Contract"],
      estimated_quality_lift: 6,
    },
  ],
};

const COMMON_BACKBONE: FeatureRecommendation[] = [
  {
    feature: "save_guarantee.ts による全 CRUD 防御層",
    rationale: "Phase 6 バグ予防DNA: 23502/UNIQUE/FK/楽観ロック 多発防止",
    priority: "P0",
    required_modules: ["save_guarantee", "bug_prevention"],
    required_dictionaries: [],
    required_templates: [],
    estimated_quality_lift: 8,
  },
  {
    feature: "ロール設計 (admin/user 小文字統一) + RBAC",
    rationale: "過去事例: ロール大文字混入で SSO/RBAC 誤動作多発",
    priority: "P0",
    required_modules: [],
    required_dictionaries: [],
    required_templates: [],
    estimated_quality_lift: 5,
  },
  {
    feature: "監査ログ + WORM保管",
    rationale: "個情法第26条 R4改正対応 + J-SOX ITGC",
    priority: "P1",
    required_modules: ["security_audit", "incident"],
    required_dictionaries: [],
    required_templates: [],
    estimated_quality_lift: 6,
  },
];

export function recommendFeatures(
  inference: InferenceSummary,
  coverage: DomainCoverage[] = [],
  usage: ModuleUsage[] = [],
): FeatureRecommendation[] {
  const out: FeatureRecommendation[] = [];

  if (inference.industry) {
    const bundle = INDUSTRY_FEATURE_BUNDLE[inference.industry];
    if (bundle) out.push(...bundle);
  }

  out.push(...COMMON_BACKBONE);

  const lowQualityDomain = coverage.find(
    (c) => c.domain === inference.industry && (c.avg_quality_score ?? 100) < 80,
  );
  if (lowQualityDomain) {
    out.push({
      feature: `${inference.industry} 業種の品質ベンチマーク強化 (現状 ${lowQualityDomain.avg_quality_score})`,
      rationale: "過去セッションの平均品質スコアが閾値未満",
      priority: "P0",
      required_modules: ["learning_analytics", "usage_insights"],
      required_dictionaries: inference.industry ? [inference.industry] : [],
      required_templates: [],
      estimated_quality_lift: 10,
    });
  }

  if (usage.some((u) => u.module === "marketing_compliance" && u.trend_30d === "rising")) {
    out.push({
      feature: "marketing_compliance.ts による景表法バナー検証",
      rationale: "直近30日で利用率上昇中の人気モジュール",
      priority: "P1",
      required_modules: ["marketing_compliance"],
      required_dictionaries: [],
      required_templates: [],
      estimated_quality_lift: 4,
    });
  }

  return dedupePreservingOrder(out);
}

function dedupePreservingOrder(arr: FeatureRecommendation[]): FeatureRecommendation[] {
  const seen = new Set<string>();
  const out: FeatureRecommendation[] = [];
  for (const r of arr) {
    if (seen.has(r.feature)) continue;
    seen.add(r.feature);
    out.push(r);
  }
  return out;
}

export function explainRecommendations(recs: FeatureRecommendation[]): string {
  const lines: string[] = [];
  lines.push("# Feature Recommendation Report");
  for (const r of recs) {
    lines.push(`## [${r.priority}] ${r.feature}`);
    lines.push(`- 根拠: ${r.rationale}`);
    if (r.required_modules.length) lines.push(`- 必要モジュール: ${r.required_modules.join(", ")}`);
    if (r.required_dictionaries.length) lines.push(`- 必要辞書: ${r.required_dictionaries.join(", ")}`);
    if (r.required_templates.length) lines.push(`- 必要帳票: ${r.required_templates.join(", ")}`);
    lines.push(`- 品質スコア期待向上: +${r.estimated_quality_lift}`);
    lines.push("");
  }
  return lines.join("\n");
}

export function selectTopRecommendations(
  recs: FeatureRecommendation[],
  options: { maxP0?: number; maxP1?: number; maxP2?: number } = {},
): FeatureRecommendation[] {
  const { maxP0 = 5, maxP1 = 5, maxP2 = 3 } = options;
  const p0 = recs.filter((r) => r.priority === "P0").slice(0, maxP0);
  const p1 = recs.filter((r) => r.priority === "P1").slice(0, maxP1);
  const p2 = recs.filter((r) => r.priority === "P2").slice(0, maxP2);
  return [...p0, ...p1, ...p2];
}
