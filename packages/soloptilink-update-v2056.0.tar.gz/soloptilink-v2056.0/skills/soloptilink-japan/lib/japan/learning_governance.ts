/**
 * SoloptiLinkAI Phase 45 — Learning-Driven Governance Engine
 *
 * 過去6,000+件のAI実利用データ (sessions / errors / strategies / quality scores) から
 * 「日本企業のガバナンス上の課題」を構造的に抽出し、関連法令にマップして
 * 実行可能なアクションプランを生成する横断学習エンジン。
 *
 * なぜClaude Codeに作れないか:
 *   - Anthropic は顧客の利用ログを保管しない方針 (cross-session learning なし)
 *   - 日本特有のガバナンス指標 (個情法第26条報告期限・電帳法保存要件・
 *     インボイス登録番号・公益通報体制義務) を持たない
 *   - 本モジュールは ~/.soloptilink/learning/ の永続データを Read-only で
 *     横断分析し、ガバナンス監査のための CSV/Markdown レポートを生成する
 *
 * 入力ソース:
 *  - learning/sessions.jsonl (セッション総括 NDJSON)
 *  - learning/distilled_patterns.jsonl (蒸留済みパターン NDJSON)
 *  - learning/errors/patterns.jsonl (エラー集約)
 *  - learning/quality/scores.jsonl (フェーズ別品質スコア)
 *  - learning/telemetry/* (テレメトリ)
 *
 * 出力:
 *  - GovernanceIssue[] (重大度付きガバナンス課題)
 *  - ActionItem[] (期日付き是正計画)
 *  - GovernanceReport (Markdown 監査レポート)
 *
 * 連携 lib/japan モジュール:
 *  - laws / laws_extended (法令ID 解決)
 *  - case_law (判例適用)
 *  - compliance_ledger (台帳エントリ作成)
 *  - learning_analytics / usage_insights (基底データ集計)
 */

import type { SessionRollup, ErrorPattern, StrategyRecord } from "./learning_analytics";

// ───────────────────────────────────────────────
// 型定義
// ───────────────────────────────────────────────

/** ガバナンス領域 (日本企業がカバーすべき主要9領域) */
export type GovernanceDomain =
  | "personal_info" // 個情法 / マイナンバー
  | "security" // 不正アクセス禁止法 / 標的型攻撃
  | "compliance" // 電帳法 / インボイス / 業法
  | "labor" // 労基法 / 36協定 / 派遣法
  | "subcontract" // 下請法 / 建設業法
  | "ai_ethics" // AI事業者ガイドライン / EU AI Act
  | "finance" // 金商法 / 全銀フォーマット / AML
  | "esg_sustainability" // TCFD / SSBJ / 温対法
  | "whistleblower"; // 公益通報者保護法

/** 重大度 (個情法第26条 R4改正の漏えい区分に準拠) */
export type Severity = "critical" | "high" | "medium" | "low";

/** ガバナンス課題 */
export interface GovernanceIssue {
  issue_id: string;
  domain: GovernanceDomain;
  severity: Severity;
  title: string;
  evidence: GovernanceEvidence;
  related_laws: string[]; // "individual_protection_law_26" など
  related_cases?: string[]; // case_law.ts の case_id
  detected_at: string; // ISO8601
  recurrence_count: number; // 過去90日の発生回数
}

/** 検出根拠 */
export interface GovernanceEvidence {
  source:
    | "session_failure"
    | "error_pattern"
    | "low_quality_score"
    | "strategy_failure"
    | "missing_module"
    | "law_violation_signal";
  failed_session_count?: number;
  failure_rate?: number;
  quality_score_avg?: number;
  failed_strategy_keys?: string[];
  domains_affected?: string[];
  modules_missing?: string[];
  raw_signal_excerpt?: string;
}

/** 是正アクション (期日・優先度付き) */
export interface ActionItem {
  action_id: string;
  issue_id: string;
  priority: "P0" | "P1" | "P2" | "P3";
  due_in_days: number; // 期日 (検出日からの相対日数)
  due_date_iso: string; // 計算済み絶対期日
  description: string;
  owner_role: "ciso" | "dpo" | "compliance" | "legal" | "engineering" | "executive";
  ref_lib_modules: string[]; // 推奨される lib/japan モジュール
  estimated_hours: number;
  status: "open" | "in_progress" | "blocked" | "done";
}

/** 監査レポート (Markdown 形式の構造化テキスト) */
export interface GovernanceReport {
  generated_at: string;
  org_name: string;
  period_from: string;
  period_to: string;
  total_sessions_analyzed: number;
  total_issues: number;
  by_severity: Record<Severity, number>;
  by_domain: Record<GovernanceDomain, number>;
  top_issues: GovernanceIssue[];
  action_plan: ActionItem[];
  markdown: string;
}

// ───────────────────────────────────────────────
// 内部しきい値・期限テーブル
// ───────────────────────────────────────────────

/** 個情法第26条 R4改正: 重大事案は 5 営業日 (速報) / 60 営業日 (確報) */
const PRIORITY_DUE_DAYS: Record<"P0" | "P1" | "P2" | "P3", number> = {
  P0: 3, // 個情法第26条速報相当
  P1: 14,
  P2: 60, // 個情法第26条確報相当
  P3: 180,
};

/** ドメイン別最低期待品質スコア */
const DOMAIN_QUALITY_FLOOR: Record<GovernanceDomain, number> = {
  personal_info: 90,
  security: 85,
  compliance: 80,
  labor: 75,
  subcontract: 75,
  ai_ethics: 80,
  finance: 90,
  esg_sustainability: 70,
  whistleblower: 75,
};

/** ドメイン × エラーキーワード 対応表 (学習データ raw signal → ドメイン推定) */
const DOMAIN_KEYWORD_MAP: Record<GovernanceDomain, string[]> = {
  personal_info: ["personal_data", "pii", "個人情報", "マイナンバー", "leak", "漏えい"],
  security: ["unauthorized", "csrf", "xss", "sql", "injection", "auth", "セッション"],
  compliance: ["invoice", "電帳法", "tax", "登録番号", "適格請求書"],
  labor: ["overtime", "36協定", "勤怠", "残業", "派遣"],
  subcontract: ["下請", "委託", "subcontract", "buyout", "見積依頼"],
  ai_ethics: ["llm", "openai", "anthropic", "deepfake", "stmma", "ステマ"],
  finance: ["zengin", "全銀", "wire", "aml", "金商"],
  esg_sustainability: ["scope1", "scope2", "scope3", "ghg", "tcfd", "ssbj"],
  whistleblower: ["公益通報", "whistleblow", "内部通報"],
};

// ───────────────────────────────────────────────
// パブリック関数
// ───────────────────────────────────────────────

/**
 * セッション+エラー+戦略データから GovernanceIssue を抽出する。
 * 検出ロジック:
 *   1. ドメイン別 失敗率 > 30% → severity = high
 *   2. ドメイン別 失敗率 > 50% → severity = critical
 *   3. 品質スコア < DOMAIN_QUALITY_FLOOR → severity = high
 *   4. 同一エラー >= 5回再発 → severity = critical
 *   5. 個情法/金商法ドメインは critical 閾値を厳しく (失敗率 > 20%)
 */
export function extractGovernanceIssues(input: {
  sessions: SessionRollup[];
  errors: ErrorPattern[];
  strategies: StrategyRecord[];
  qualityScores?: Array<{ phase: string; score: number; ts: string; domain?: string }>;
  now?: Date;
}): GovernanceIssue[] {
  const now = input.now ?? new Date();
  const out: GovernanceIssue[] = [];
  const sessions = input.sessions ?? [];
  const errors = input.errors ?? [];
  const strategies = input.strategies ?? [];
  const qualityScores = input.qualityScores ?? [];

  // 1. ドメイン別 失敗率分析
  const domainStats = aggregateByDomain(sessions);
  for (const [dom, stat] of Object.entries(domainStats)) {
    if (stat.total === 0) continue;
    const fr = stat.fail / stat.total;
    const isHighStakes = dom === "personal_info" || dom === "finance" || dom === "security";
    const criticalThreshold = isHighStakes ? 0.2 : 0.5;
    const highThreshold = isHighStakes ? 0.1 : 0.3;
    let sev: Severity | null = null;
    if (fr > criticalThreshold) sev = "critical";
    else if (fr > highThreshold) sev = "high";
    if (!sev) continue;
    out.push({
      issue_id: `gov-fr-${dom}-${now.getTime()}`,
      domain: dom as GovernanceDomain,
      severity: sev,
      title: `[${dom}] 失敗率 ${(fr * 100).toFixed(1)}% (${stat.fail}/${stat.total} セッション)`,
      evidence: {
        source: "session_failure",
        failed_session_count: stat.fail,
        failure_rate: fr,
        domains_affected: [dom],
      },
      related_laws: relatedLawsFor(dom as GovernanceDomain),
      detected_at: now.toISOString(),
      recurrence_count: stat.fail,
    });
  }

  // 2. エラーパターン再発検出
  for (const e of errors) {
    if (e.frequency < 5) continue;
    const dom = inferDomainFromText(`${e.error_type} ${e.last_message}`);
    const sev: Severity = e.frequency >= 20 ? "critical" : e.frequency >= 10 ? "high" : "medium";
    out.push({
      issue_id: `gov-err-${e.error_type}-${now.getTime()}`,
      domain: dom,
      severity: sev,
      title: `[${dom}] エラー再発 ${e.frequency} 回: ${e.error_type}`,
      evidence: {
        source: "error_pattern",
        domains_affected: [dom],
        raw_signal_excerpt: e.last_message?.slice(0, 240),
      },
      related_laws: relatedLawsFor(dom),
      detected_at: now.toISOString(),
      recurrence_count: e.frequency,
    });
  }

  // 3. 品質スコア低下検出
  const qualityByDomain = new Map<string, number[]>();
  for (const q of qualityScores) {
    const dom = q.domain ?? "unknown";
    if (!qualityByDomain.has(dom)) qualityByDomain.set(dom, []);
    qualityByDomain.get(dom)!.push(q.score);
  }
  for (const [dom, scores] of qualityByDomain.entries()) {
    if (!isGovernanceDomain(dom)) continue;
    const avg = scores.reduce((a, b) => a + b, 0) / scores.length;
    const floor = DOMAIN_QUALITY_FLOOR[dom as GovernanceDomain];
    if (avg < floor) {
      out.push({
        issue_id: `gov-q-${dom}-${now.getTime()}`,
        domain: dom as GovernanceDomain,
        severity: avg < floor - 15 ? "critical" : "high",
        title: `[${dom}] 平均品質スコア ${avg.toFixed(1)} (基準 ${floor})`,
        evidence: {
          source: "low_quality_score",
          quality_score_avg: avg,
          domains_affected: [dom],
        },
        related_laws: relatedLawsFor(dom as GovernanceDomain),
        detected_at: now.toISOString(),
        recurrence_count: scores.length,
      });
    }
  }

  // 4. 修復戦略の慢性失敗
  const stratFail = new Map<string, number>();
  for (const s of strategies) {
    if (s.result === "failure") stratFail.set(s.key, (stratFail.get(s.key) ?? 0) + 1);
  }
  for (const [key, count] of stratFail) {
    if (count < 3) continue;
    const dom = inferDomainFromText(key);
    out.push({
      issue_id: `gov-st-${key}-${now.getTime()}`,
      domain: dom,
      severity: count >= 10 ? "critical" : "high",
      title: `[${dom}] 修復戦略連続失敗 ${count} 回: ${key}`,
      evidence: {
        source: "strategy_failure",
        failed_strategy_keys: [key],
      },
      related_laws: relatedLawsFor(dom),
      detected_at: now.toISOString(),
      recurrence_count: count,
    });
  }

  return out;
}

/**
 * GovernanceIssue 群から ActionItem を生成する。
 * - critical → P0 (3日以内) / 個情法26条速報相当
 * - high     → P1 (14日以内)
 * - medium   → P2 (60日以内) / 個情法26条確報相当
 * - low      → P3 (180日以内)
 */
export function generateActionPlan(issues: GovernanceIssue[], now: Date = new Date()): ActionItem[] {
  const out: ActionItem[] = [];
  for (const issue of issues) {
    const priority: "P0" | "P1" | "P2" | "P3" =
      issue.severity === "critical"
        ? "P0"
        : issue.severity === "high"
        ? "P1"
        : issue.severity === "medium"
        ? "P2"
        : "P3";
    const dueDays = PRIORITY_DUE_DAYS[priority];
    const due = new Date(now.getTime() + dueDays * 86400_000);
    const owner = ownerRoleFor(issue.domain);
    out.push({
      action_id: `act-${issue.issue_id}`,
      issue_id: issue.issue_id,
      priority,
      due_in_days: dueDays,
      due_date_iso: due.toISOString(),
      description: actionDescription(issue),
      owner_role: owner,
      ref_lib_modules: refModulesFor(issue.domain),
      estimated_hours: estimateEffort(issue),
      status: "open",
    });
  }
  return out;
}

/**
 * ガバナンス監査用の Markdown レポートを生成する。
 * 監査担当者がそのままドキュメントとして提出可能な構造。
 */
export function buildGovernanceReport(input: {
  org_name: string;
  period_from: string;
  period_to: string;
  total_sessions_analyzed: number;
  issues: GovernanceIssue[];
  actions: ActionItem[];
  now?: Date;
}): GovernanceReport {
  const now = input.now ?? new Date();
  const bySeverity: Record<Severity, number> = { critical: 0, high: 0, medium: 0, low: 0 };
  const byDomain: Record<GovernanceDomain, number> = {
    personal_info: 0,
    security: 0,
    compliance: 0,
    labor: 0,
    subcontract: 0,
    ai_ethics: 0,
    finance: 0,
    esg_sustainability: 0,
    whistleblower: 0,
  };
  for (const i of input.issues) {
    bySeverity[i.severity]++;
    byDomain[i.domain]++;
  }
  const top = [...input.issues]
    .sort((a, b) => severityRank(b.severity) - severityRank(a.severity) || b.recurrence_count - a.recurrence_count)
    .slice(0, 10);

  const md = renderMarkdown({
    org: input.org_name,
    from: input.period_from,
    to: input.period_to,
    totalSessions: input.total_sessions_analyzed,
    issues: input.issues,
    top,
    actions: input.actions,
    bySeverity,
    byDomain,
    generatedAt: now.toISOString(),
  });

  return {
    generated_at: now.toISOString(),
    org_name: input.org_name,
    period_from: input.period_from,
    period_to: input.period_to,
    total_sessions_analyzed: input.total_sessions_analyzed,
    total_issues: input.issues.length,
    by_severity: bySeverity,
    by_domain: byDomain,
    top_issues: top,
    action_plan: input.actions,
    markdown: md,
  };
}

/**
 * NDJSON 学習ログを安全にパースする (1 行壊れていても続行)。
 */
export function parseNdjson<T>(raw: string): T[] {
  const out: T[] = [];
  for (const line of raw.split(/\r?\n/)) {
    const t = line.trim();
    if (!t) continue;
    try {
      out.push(JSON.parse(t) as T);
    } catch {
      // 1 行壊れでも全体停止しない (学習ログは追記専用で末尾欠ける可能性)
      continue;
    }
  }
  return out;
}

// ───────────────────────────────────────────────
// 内部関数
// ───────────────────────────────────────────────

function aggregateByDomain(sessions: SessionRollup[]): Record<string, { total: number; fail: number }> {
  const out: Record<string, { total: number; fail: number }> = {};
  for (const s of sessions) {
    const dom = s.domain ?? "unknown";
    if (!out[dom]) out[dom] = { total: 0, fail: 0 };
    out[dom].total++;
    if (s.outcome === "ng") out[dom].fail++;
  }
  return out;
}

function inferDomainFromText(text: string): GovernanceDomain {
  const lower = (text ?? "").toLowerCase();
  for (const [dom, kws] of Object.entries(DOMAIN_KEYWORD_MAP)) {
    for (const k of kws) {
      if (lower.includes(k.toLowerCase())) return dom as GovernanceDomain;
    }
  }
  return "compliance";
}

function isGovernanceDomain(s: string): boolean {
  return s in DOMAIN_QUALITY_FLOOR;
}

function relatedLawsFor(d: GovernanceDomain): string[] {
  const map: Record<GovernanceDomain, string[]> = {
    personal_info: ["personal_info_law_26", "personal_info_law_general", "my_number_law"],
    security: ["unauthorized_access_law", "personal_info_law_safety_management"],
    compliance: ["invoice_law", "dencho_ho", "subcontract_law"],
    labor: ["labor_standard_law", "dispatch_law", "fair_pay_law"],
    subcontract: ["subcontract_law", "construction_law"],
    ai_ethics: ["ai_business_guideline_2024", "eu_ai_act_extraterritorial", "stmma_regulation"],
    finance: ["fiea", "aml_act", "zengin_format"],
    esg_sustainability: ["tcfd_disclosure", "ssbj_standard", "act_on_promoting_warming_countermeasures"],
    whistleblower: ["whistleblower_protection_law_2022"],
  };
  return map[d];
}

function refModulesFor(d: GovernanceDomain): string[] {
  const map: Record<GovernanceDomain, string[]> = {
    personal_info: ["incident", "compliance_ledger", "security_audit"],
    security: ["security", "security_audit", "vulnerability", "incident_response"],
    compliance: ["compliance_ledger", "law_tracker", "tax", "tax_filing"],
    labor: ["hr_payroll", "dispatch"],
    subcontract: ["compliance_ledger", "estimates"],
    ai_ethics: ["ai_compliance", "marketing_compliance"],
    finance: ["finance", "incident_response"],
    esg_sustainability: ["esg_carbon", "compliance_ledger"],
    whistleblower: ["whistleblower"],
  };
  return map[d];
}

function ownerRoleFor(d: GovernanceDomain): ActionItem["owner_role"] {
  switch (d) {
    case "personal_info":
      return "dpo";
    case "security":
      return "ciso";
    case "compliance":
    case "subcontract":
      return "compliance";
    case "labor":
    case "whistleblower":
      return "legal";
    case "ai_ethics":
      return "compliance";
    case "finance":
      return "executive";
    case "esg_sustainability":
      return "executive";
    default:
      return "compliance";
  }
}

function actionDescription(issue: GovernanceIssue): string {
  const head = `[${issue.severity.toUpperCase()}] ${issue.title}`;
  const tail = `関連法令: ${issue.related_laws.join(", ")}。推奨対応モジュール: ${refModulesFor(issue.domain).join(", ")}。`;
  return `${head} — ${tail}`;
}

function estimateEffort(issue: GovernanceIssue): number {
  const base: Record<Severity, number> = { critical: 16, high: 8, medium: 4, low: 2 };
  return base[issue.severity] + Math.min(8, issue.recurrence_count);
}

function severityRank(s: Severity): number {
  return { critical: 4, high: 3, medium: 2, low: 1 }[s];
}

function renderMarkdown(args: {
  org: string;
  from: string;
  to: string;
  totalSessions: number;
  issues: GovernanceIssue[];
  top: GovernanceIssue[];
  actions: ActionItem[];
  bySeverity: Record<Severity, number>;
  byDomain: Record<GovernanceDomain, number>;
  generatedAt: string;
}): string {
  const lines: string[] = [];
  lines.push(`# ガバナンス監査レポート — ${args.org}`);
  lines.push(``);
  lines.push(`- 対象期間: ${args.from} 〜 ${args.to}`);
  lines.push(`- 解析セッション総数: ${args.totalSessions}`);
  lines.push(`- 検出された課題: ${args.issues.length}`);
  lines.push(`- 生成日時: ${args.generatedAt}`);
  lines.push(``);
  lines.push(`## 重大度別サマリ`);
  lines.push(``);
  lines.push(`| 重大度 | 件数 | 標準対応期限 |`);
  lines.push(`|--------|------|--------------|`);
  lines.push(`| Critical | ${args.bySeverity.critical} | 3 営業日以内 (個情法第26条 速報相当) |`);
  lines.push(`| High     | ${args.bySeverity.high} | 14 営業日以内 |`);
  lines.push(`| Medium   | ${args.bySeverity.medium} | 60 営業日以内 (個情法第26条 確報相当) |`);
  lines.push(`| Low      | ${args.bySeverity.low} | 180 営業日以内 |`);
  lines.push(``);
  lines.push(`## 領域別件数`);
  lines.push(``);
  for (const [dom, n] of Object.entries(args.byDomain)) {
    if (n === 0) continue;
    lines.push(`- **${dom}**: ${n} 件`);
  }
  lines.push(``);
  lines.push(`## トップ10 重大課題`);
  lines.push(``);
  for (let i = 0; i < args.top.length; i++) {
    const t = args.top[i];
    lines.push(`### ${i + 1}. ${t.title}`);
    lines.push(``);
    lines.push(`- 重大度: \`${t.severity}\``);
    lines.push(`- 領域: \`${t.domain}\``);
    lines.push(`- 関連法令: ${t.related_laws.join(", ")}`);
    lines.push(`- 再発回数: ${t.recurrence_count}`);
    lines.push(`- 検出根拠: \`${t.evidence.source}\``);
    if (t.evidence.raw_signal_excerpt) {
      lines.push(`- 抜粋: \`${t.evidence.raw_signal_excerpt}\``);
    }
    lines.push(``);
  }
  lines.push(`## 是正アクションプラン`);
  lines.push(``);
  lines.push(`| 優先 | 期日 | オーナー | 概要 | 推奨モジュール |`);
  lines.push(`|------|------|----------|------|----------------|`);
  for (const a of args.actions.slice(0, 30)) {
    lines.push(
      `| ${a.priority} | ${a.due_date_iso.slice(0, 10)} | ${a.owner_role} | ${a.description.slice(0, 100)}... | ${a.ref_lib_modules.join(", ")} |`
    );
  }
  lines.push(``);
  lines.push(`---`);
  lines.push(`生成: SoloptiLinkAI v2026.0 / Phase 45 Learning-Driven Governance Engine`);
  return lines.join("\n");
}
