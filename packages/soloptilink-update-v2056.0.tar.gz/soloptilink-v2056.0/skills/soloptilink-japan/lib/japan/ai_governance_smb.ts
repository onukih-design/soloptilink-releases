/**
 * SoloptiLinkAI Phase 45 — AI Governance for Japanese SMB (中小企業向け)
 *
 * 既存 ai_compliance.ts は大企業・高リスク用途中心の EU AI Act 整合モジュール。
 * 本モジュールは「従業員300人以下・専任DPO不在・予算制約あり」の日本中小企業が
 * AI ツール (Claude / ChatGPT / Gemini / Copilot 等) を業務に導入する際の
 * 現実的なガバナンス統制を実装する。
 *
 * 法的根拠:
 *  - 経済産業省/総務省 「AI事業者ガイドライン 第1.0版」(2024年4月)
 *  - 個人情報保護委員会 「OpenAI注意喚起」(2023年6月) / R6改正
 *  - 文化庁 「AIと著作権に関する考え方」(2024年3月)
 *  - 著作権法 30条の4 (情報解析利用) / 47条の5 (軽微利用)
 *  - 公益通報者保護法 (R4改正) — AI 関連内部通報も保護対象
 *  - 不競法 2条1項 (営業秘密のAI入力時取扱い)
 *  - 公正取引委員会 ステマ規制 (R5.10) — AI 生成コンテンツ表示義務
 *
 * なぜClaude Codeに作れないか:
 *  - 中小企業の現実 (人手不足・予算制約・兼任DPO) を理解しない
 *  - 日本の AI 利用実務 (議事録要約・メール生成・契約書レビュー等) のリスク
 *    マッピングを持たない
 *  - 日本特有のリスク (ステマ規制・職務著作・営業秘密3要件) を把握していない
 */

// ───────────────────────────────────────────────
// 中小企業プロファイル
// ───────────────────────────────────────────────

export interface SmbProfile {
  org_name: string;
  total_employees: number; // 1〜300想定 (>300 は ai_compliance.ts 推奨)
  industry: string; // 建設 / 医療 / 介護 / 飲食 / 小売 / 士業 / 製造 / IT / その他
  has_dpo: boolean; // 専任 DPO の有無 (中小はほぼ false)
  dpo_concurrent_role?: string; // 兼任の場合の本務 (例: "総務部長")
  monthly_ai_budget_jpy?: number;
  uses_consumer_ai: boolean; // ChatGPT 個人版・Claude 個人版を業務利用しているか
  has_ai_usage_policy: boolean; // 社内 AI 利用規程の有無
  has_review_committee: boolean; // AI 倫理委員会の有無
  handles_personal_data: boolean;
  handles_trade_secret: boolean; // 営業秘密 (3要件: 秘密管理性・有用性・非公知性)
}

// ───────────────────────────────────────────────
// AI 利用ユースケース (中小現実版)
// ───────────────────────────────────────────────

/** 日本中小企業で実際に多発する AI 利用ユースケース 24 種 */
export type SmbAiUseCase =
  | "meeting_minutes_summary" // 議事録要約
  | "email_draft" // メール下書き
  | "proposal_writing" // 提案書作成
  | "contract_review" // 契約書レビュー
  | "code_generation" // コード生成
  | "translation" // 翻訳
  | "transcription" // 音声→テキスト
  | "image_generation" // 画像生成 (チラシ等)
  | "marketing_copy" // 広告コピー
  | "sns_post" // SNS 投稿生成
  | "customer_response" // 顧客対応 (チャット/メール)
  | "interview_screening" // 採用書類スクリーニング (※高リスク)
  | "performance_review" // 人事評価補助 (※高リスク)
  | "credit_check" // 与信判定 (※高リスク)
  | "medical_summary" // 診療記録要約 (※高リスク要配慮)
  | "legal_research" // 判例調査 (士業)
  | "tax_advisory" // 税務相談 (※税理士法 2 条)
  | "analytics_query" // データ分析クエリ
  | "code_review" // コードレビュー
  | "schedule_planning" // スケジュール策定
  | "training_material" // 教材作成
  | "press_release" // プレスリリース
  | "incident_report" // 事故報告書ドラフト
  | "design_iteration"; // UI/UX デザイン案

/** ユースケース別リスクマップ */
export const SMB_USE_CASE_RISK: Record<SmbAiUseCase, {
  risk: "low" | "medium" | "high" | "prohibited";
  jp_concerns: string[]; // 日本法/慣行上の留意点
  required_safeguards: string[];
}> = {
  meeting_minutes_summary: {
    risk: "medium",
    jp_concerns: ["参加者の同意 (個情法第18条)", "社外秘情報の混入"],
    required_safeguards: ["参加者事前通知", "音声→AI送信の同意", "ログ保管 (社内)"],
  },
  email_draft: {
    risk: "low",
    jp_concerns: ["顧客個人名・連絡先のAI送信"],
    required_safeguards: ["匿名化テンプレ利用", "送信前の人間レビュー必須"],
  },
  proposal_writing: {
    risk: "medium",
    jp_concerns: ["他社提案書からの剽窃 (著作権法32条)", "顧客機密の流用"],
    required_safeguards: ["引用元明記", "顧客機密のマスキング"],
  },
  contract_review: {
    risk: "high",
    jp_concerns: ["弁護士法72条 (非弁活動)", "ハルシネーションによる重要条項見落とし"],
    required_safeguards: ["弁護士最終レビュー", "条項単位の人間チェック", "免責条項の明示"],
  },
  code_generation: {
    risk: "medium",
    jp_concerns: ["GPLライセンス汚染", "既存コードからの剽窃 (著作権法10条)"],
    required_safeguards: ["License Scan", "Copyleft検出", "テストカバレッジ80%"],
  },
  translation: {
    risk: "low",
    jp_concerns: ["契約書原文のAI送信", "業界専門用語の誤訳"],
    required_safeguards: ["二重訳 (AI→人間)", "重要書類は機械翻訳禁止"],
  },
  transcription: {
    risk: "medium",
    jp_concerns: ["参加者の同意", "会議内秘密情報"],
    required_safeguards: ["事前同意取得", "オンプレ/閉域網優先"],
  },
  image_generation: {
    risk: "medium",
    jp_concerns: ["著作権侵害 (学習データ由来)", "実在人物との酷似 (パブリシティ権)"],
    required_safeguards: ["生成画像のリバース画像検索", "実在人物プロンプト禁止"],
  },
  marketing_copy: {
    risk: "high",
    jp_concerns: ["景表法5条 (優良誤認・有利誤認)", "ステマ規制R5.10 (AI生成明示)"],
    required_safeguards: ["事実確認チェック", "AI生成である旨の表示", "薬機法/食品表示法チェック"],
  },
  sns_post: {
    risk: "medium",
    jp_concerns: ["ステマ規制 (#PR必須)", "誤情報拡散"],
    required_safeguards: ["#AI または #PR の付記", "事実確認"],
  },
  customer_response: {
    risk: "high",
    jp_concerns: ["顧客個人情報のAI送信", "ハルシネーション回答による苦情"],
    required_safeguards: ["人間最終確認", "AI応答である旨の表示"],
  },
  interview_screening: {
    risk: "high",
    jp_concerns: ["職業安定法 (差別的取扱い)", "AI事業者ガイドライン (高リスク)"],
    required_safeguards: ["人間最終決定", "差別的特徴 (性別/年齢/居住地) の除外", "監査ログ"],
  },
  performance_review: {
    risk: "high",
    jp_concerns: ["労働契約法 (公正評価義務)", "AI事業者ガイドライン"],
    required_safeguards: ["最終決定は人間", "本人開示権", "異議申立てプロセス"],
  },
  credit_check: {
    risk: "prohibited",
    jp_concerns: ["割賦販売法 / 貸金業法", "AI事業者ガイドライン (高リスク用途)"],
    required_safeguards: ["人間レビュー必須", "説明可能性必須", "EU AI Act 域外適用"],
  },
  medical_summary: {
    risk: "high",
    jp_concerns: ["要配慮個人情報 (個情法2条3項)", "3省2ガイドライン", "医師法17条"],
    required_safeguards: ["閉域網/院内サーバー", "医師最終確認", "HPKI 連携"],
  },
  legal_research: {
    risk: "medium",
    jp_concerns: ["弁護士法72条", "判例の正確性"],
    required_safeguards: ["弁護士最終確認", "判例原典との突合"],
  },
  tax_advisory: {
    risk: "high",
    jp_concerns: ["税理士法2条 (税理士業務制限)", "誤指導による税務リスク"],
    required_safeguards: ["税理士最終確認", "AI回答の参考扱い明示"],
  },
  analytics_query: {
    risk: "medium",
    jp_concerns: ["DB 内個人情報のAI送信"],
    required_safeguards: ["匿名化", "サンプリング", "結果検証"],
  },
  code_review: {
    risk: "low",
    jp_concerns: ["プロプライエタリコードの外部送信"],
    required_safeguards: ["公開済みコード優先", "機密ロジックは送信禁止"],
  },
  schedule_planning: {
    risk: "low",
    jp_concerns: ["参加者の予定 (個情法上の取扱い)"],
    required_safeguards: ["最低限の情報のみ", "氏名イニシャル化"],
  },
  training_material: {
    risk: "medium",
    jp_concerns: ["著作権法32条 (引用)", "教育目的の例外規定"],
    required_safeguards: ["引用元明記", "学校教育以外は通常許諾"],
  },
  press_release: {
    risk: "high",
    jp_concerns: ["金商法 (上場企業の重要事実)", "誤った数値拡散"],
    required_safeguards: ["広報部門承認", "数値の二重チェック"],
  },
  incident_report: {
    risk: "high",
    jp_concerns: ["個情法第26条 (5営業日報告)", "事実認定の正確性"],
    required_safeguards: ["事実関係の確認", "法務最終確認", "ログ保管"],
  },
  design_iteration: {
    risk: "low",
    jp_concerns: ["既存意匠との類似 (意匠法 / 類否70%閾値)"],
    required_safeguards: ["意匠検索", "公知デザインとの照合"],
  },
};

// ───────────────────────────────────────────────
// 社内 AI 利用規程 DSL
// ───────────────────────────────────────────────

export type RuleEffect = "allow" | "allow_with_conditions" | "review_required" | "prohibit";

export interface AiUsageRule {
  rule_id: string;
  use_case: SmbAiUseCase;
  effect: RuleEffect;
  conditions?: string[]; // allow_with_conditions / review_required の場合の条件
  approver_role?: "department_head" | "ciso" | "legal" | "executive" | "committee";
  log_retention_months: number; // ログ保存期間 (個情法は「合理的な期間」、通常24ヶ月推奨)
  applies_to_consumer_ai: boolean; // 個人版 ChatGPT/Claude にも適用するか
}

/** 中小企業向けデフォルト AI 利用規程 (24 ユースケース全カバー) */
export function defaultSmbPolicy(): AiUsageRule[] {
  const rules: AiUsageRule[] = [];
  const useCases = Object.keys(SMB_USE_CASE_RISK) as SmbAiUseCase[];
  for (const uc of useCases) {
    const r = SMB_USE_CASE_RISK[uc];
    let effect: RuleEffect;
    let approver: AiUsageRule["approver_role"] | undefined;
    switch (r.risk) {
      case "low":
        effect = "allow_with_conditions";
        break;
      case "medium":
        effect = "review_required";
        approver = "department_head";
        break;
      case "high":
        effect = "review_required";
        approver = "committee";
        break;
      case "prohibited":
        effect = "prohibit";
        approver = "executive";
        break;
    }
    rules.push({
      rule_id: `smb-rule-${uc}`,
      use_case: uc,
      effect,
      conditions: r.required_safeguards,
      approver_role: approver,
      log_retention_months: r.risk === "high" || r.risk === "prohibited" ? 60 : 24,
      applies_to_consumer_ai: true,
    });
  }
  return rules;
}

// ───────────────────────────────────────────────
// AI 倫理委員会
// ───────────────────────────────────────────────

export interface EthicsCommitteeMember {
  name: string;
  role: "chair" | "secretary" | "internal_member" | "external_advisor";
  background: string; // 法務 / 技術 / 業務 / 外部弁護士
}

export interface EthicsCommittee {
  org_name: string;
  members: EthicsCommitteeMember[];
  meeting_cadence: "weekly" | "biweekly" | "monthly" | "quarterly";
  quorum_min: number; // 定足数
  charter_url?: string;
}

/** 中小企業向け推奨委員会構成 (3〜5名・月1回・定足3名) */
export function recommendCommittee(profile: SmbProfile): EthicsCommittee {
  const members: EthicsCommitteeMember[] = [
    { name: "代表取締役 (議長)", role: "chair", background: "経営" },
    { name: "総務 / 法務担当 (兼任DPO)", role: "secretary", background: "法務・個情法対応" },
    { name: "情報システム担当", role: "internal_member", background: "技術・セキュリティ" },
  ];
  if (profile.total_employees > 100 || profile.handles_personal_data) {
    members.push({ name: "外部弁護士 (顧問)", role: "external_advisor", background: "個情法・労働法" });
  }
  if (profile.industry === "医療" || profile.industry === "介護") {
    members.push({ name: "医療情報技師 / 看護管理者", role: "internal_member", background: "医療現場" });
  }
  return {
    org_name: profile.org_name,
    members,
    meeting_cadence: "monthly",
    quorum_min: Math.max(3, Math.ceil(members.length * 0.6)),
  };
}

// ───────────────────────────────────────────────
// 規程適合性チェック
// ───────────────────────────────────────────────

export interface PolicyFinding {
  rule_id?: string;
  severity: "info" | "warning" | "violation";
  message: string;
  remediation: string;
}

export function checkPolicyConsistency(profile: SmbProfile, rules: AiUsageRule[]): PolicyFinding[] {
  const findings: PolicyFinding[] = [];

  if (!profile.has_ai_usage_policy) {
    findings.push({
      severity: "violation",
      message: "AI利用規程が未整備 (AI事業者ガイドライン 1.4 ガバナンス基本要素)",
      remediation: "defaultSmbPolicy() の出力を就業規則別表として制定する。",
    });
  }

  if (!profile.has_dpo) {
    findings.push({
      severity: "warning",
      message: "専任 DPO 不在 (個情法第40条 個人情報保護管理者推奨)",
      remediation: "総務部長等の兼任 DPO を任命し、社内通知書に明記する。",
    });
  }

  if (profile.uses_consumer_ai && !rules.some((r) => r.applies_to_consumer_ai)) {
    findings.push({
      severity: "violation",
      message: "個人版 AI 業務利用が規程適用範囲外 (情報漏えいリスク)",
      remediation: "applies_to_consumer_ai=true の規程に変更し、業務契約版への移行ロードマップを策定。",
    });
  }

  if (profile.handles_trade_secret) {
    const hasSecretRule = rules.some(
      (r) => r.effect !== "allow" && r.conditions?.some((c) => /秘密|機密|オンプレ|閉域/.test(c))
    );
    if (!hasSecretRule) {
      findings.push({
        severity: "violation",
        message: "営業秘密取扱い時の AI 制限規程なし (不競法2条1項 秘密管理性が損なわれる)",
        remediation: "営業秘密分類ラベル (Class S/A/B/C) を導入し、Class S 以上は AI 入力禁止とする。",
      });
    }
  }

  if (profile.handles_personal_data) {
    const piiRule = rules.find((r) => r.use_case === "customer_response" || r.use_case === "interview_screening");
    if (piiRule && piiRule.effect === "allow") {
      findings.push({
        severity: "violation",
        message: "個人情報を扱うユースケースが無条件許可 (個情法第18条 利用目的)",
        remediation: "review_required または allow_with_conditions に変更し、利用目的を本人に通知。",
      });
    }
  }

  return findings;
}

// ───────────────────────────────────────────────
// AI ベンダー評価
// ───────────────────────────────────────────────

export interface AiVendorEvaluation {
  vendor: string;
  product: string; // claude-opus-4-7 / gpt-4o / gemini-2-5 等
  data_residency: "jp" | "us" | "eu" | "unknown";
  enterprise_plan_available: boolean; // 業務契約版があるか
  no_training_default: boolean; // デフォルトで「学習に使わない」設定か
  scc_offered: boolean; // 標準契約条項 (個情法第27条)
  iso27001: boolean;
  iso27017: boolean; // クラウドセキュリティ
  iso27018: boolean; // 個人情報保護 (クラウド)
  pci_dss: boolean;
  soc2_type2: boolean;
  isms_p_mark: boolean; // 日本国内認証
  has_jp_support: boolean; // 日本語サポート
  has_breach_notification: boolean; // 漏えい通知合意
  total_score: number; // 0-100
  recommendation: "preferred" | "acceptable" | "conditional" | "not_recommended";
}

export function evaluateAiVendor(input: Omit<AiVendorEvaluation, "total_score" | "recommendation">): AiVendorEvaluation {
  let score = 0;
  if (input.enterprise_plan_available) score += 20;
  if (input.no_training_default) score += 20;
  if (input.scc_offered) score += 10;
  if (input.iso27001) score += 8;
  if (input.iso27017) score += 6;
  if (input.iso27018) score += 6;
  if (input.soc2_type2) score += 8;
  if (input.isms_p_mark) score += 6;
  if (input.has_jp_support) score += 6;
  if (input.has_breach_notification) score += 8;
  if (input.data_residency === "jp") score += 2;

  let rec: AiVendorEvaluation["recommendation"];
  if (score >= 80) rec = "preferred";
  else if (score >= 60) rec = "acceptable";
  else if (score >= 40) rec = "conditional";
  else rec = "not_recommended";

  return { ...input, total_score: score, recommendation: rec };
}

// ───────────────────────────────────────────────
// 利用申請ワークフロー
// ───────────────────────────────────────────────

export interface AiUsageRequest {
  request_id: string;
  requester: string;
  use_case: SmbAiUseCase;
  vendor: string;
  data_classes: ("personal_info" | "trade_secret" | "public" | "internal" | "confidential")[];
  purpose: string;
  expected_volume_per_month: number; // リクエスト数想定
  retention_period_days: number;
  has_dpia: boolean; // データ保護影響評価
}

export interface AiUsageDecision {
  request_id: string;
  decision: "approved" | "approved_with_conditions" | "rejected" | "needs_committee";
  rationale: string;
  conditions?: string[];
  reviewer_role: AiUsageRule["approver_role"];
  reviewed_at: string;
}

export function reviewUsageRequest(
  req: AiUsageRequest,
  rules: AiUsageRule[],
  vendorEval?: AiVendorEvaluation,
  now: Date = new Date()
): AiUsageDecision {
  const rule = rules.find((r) => r.use_case === req.use_case);
  const reviewer = rule?.approver_role ?? "legal";
  if (!rule) {
    return {
      request_id: req.request_id,
      decision: "needs_committee",
      rationale: `規程未定義のユースケース (${req.use_case})。委員会判断が必要。`,
      reviewer_role: "committee",
      reviewed_at: now.toISOString(),
    };
  }
  if (rule.effect === "prohibit") {
    return {
      request_id: req.request_id,
      decision: "rejected",
      rationale: `規程により禁止用途 (rule_id=${rule.rule_id})。EU AI Act / AI事業者ガイドライン 高リスク。`,
      reviewer_role: reviewer,
      reviewed_at: now.toISOString(),
    };
  }
  if (req.data_classes.includes("trade_secret") && !req.has_dpia) {
    return {
      request_id: req.request_id,
      decision: "rejected",
      rationale: "営業秘密入力にDPIA未実施 (不競法2条1項 秘密管理性喪失リスク)",
      reviewer_role: reviewer,
      reviewed_at: now.toISOString(),
    };
  }
  if (vendorEval && vendorEval.recommendation === "not_recommended") {
    return {
      request_id: req.request_id,
      decision: "rejected",
      rationale: `ベンダー評価スコア ${vendorEval.total_score}/100 — Not Recommended (データ管理基準未達)`,
      reviewer_role: reviewer,
      reviewed_at: now.toISOString(),
    };
  }
  const conditions: string[] = [...(rule.conditions ?? [])];
  if (req.data_classes.includes("personal_info")) {
    conditions.push("個情法第18条 利用目的の本人通知");
    conditions.push("個情法第26条 漏えい時5営業日報告フロー整備");
  }
  if (req.expected_volume_per_month > 10_000) {
    conditions.push("月次レビュー (実績/インシデント有無)");
  }
  return {
    request_id: req.request_id,
    decision: rule.effect === "review_required" ? "approved_with_conditions" : "approved",
    rationale: `規程 ${rule.rule_id} に従う。条件付き承認。`,
    conditions,
    reviewer_role: reviewer,
    reviewed_at: now.toISOString(),
  };
}
