/**
 * @fileoverview Phase 12 - セキュリティ監査 DNA (日本基準)
 *
 * ISMS (ISO27001) + Pマーク + SOC2 + 金商法 J-SOX + NIST CSF + CIS Controls
 * の監査要件を統合し、日本企業向けにマッピング:
 *   - ISMS-AC 認証維持監査
 *   - Pマーク (JIS Q 15001:2017)
 *   - 金商法 内部統制報告書 (J-SOX) IT全般統制 + 業務処理統制
 *   - 政府情報システムのためのセキュリティ評価制度 (ISMAP)
 *   - 監査ログ要件 + 改ざん検知
 */

// ============================================================================
// Types
// ============================================================================

export type SecurityFramework = 'isms' | 'pmark' | 'soc2' | 'jsox' | 'ismap' | 'nist_csf' | 'cis_controls' | 'cmmc';

export type AuditControlCategory =
  | 'access_control'      // アクセス制御
  | 'cryptography'        // 暗号化
  | 'physical_security'   // 物理セキュリティ
  | 'operations_security' // 運用セキュリティ
  | 'communications'      // 通信
  | 'acquisition'         // システム取得・開発
  | 'supplier'            // 供給者関係
  | 'incident_management' // インシデント管理
  | 'business_continuity' // 事業継続
  | 'compliance'          // 法令遵守
  | 'organization'        // 組織体制
  | 'human_resources'     // 人的資源
  | 'asset_management'    // 資産管理
  | 'risk_assessment';    // リスクアセスメント

export interface AuditControl {
  id: string;
  framework: SecurityFramework;
  category: AuditControlCategory;
  /** 統制の名称 */
  name: string;
  /** 統制の目的 */
  objective: string;
  /** 評価レベル */
  level: 'mandatory' | 'recommended' | 'optional';
  /** 監査エビデンス例 */
  evidenceExamples: string[];
}

// ============================================================================
// 主要統制 (代表サンプル・実運用は規格本文を参照)
// ============================================================================

export const STANDARD_AUDIT_CONTROLS: AuditControl[] = [
  // ISMS (ISO/IEC 27001:2022 附属書A)
  { id: 'A.5.1', framework: 'isms', category: 'organization', name: '情報セキュリティ方針', objective: '経営者による方針表明と承認', level: 'mandatory', evidenceExamples: ['情報セキュリティ基本方針 文書', '取締役会議事録'] },
  { id: 'A.8.2', framework: 'isms', category: 'asset_management', name: '情報の分類', objective: '機密性の重要度に応じた分類', level: 'mandatory', evidenceExamples: ['情報資産台帳', '分類ラベリング手順'] },
  { id: 'A.5.15', framework: 'isms', category: 'access_control', name: 'アクセス制御', objective: 'Need-to-know 原則の徹底', level: 'mandatory', evidenceExamples: ['アクセス権限申請ワークフロー', 'IDマネジメント運用記録'] },
  { id: 'A.8.24', framework: 'isms', category: 'cryptography', name: '暗号の利用', objective: '保存・通信時の暗号化', level: 'mandatory', evidenceExamples: ['暗号アルゴリズム選定基準', '鍵管理手順', 'TLS設定スキャン結果'] },
  { id: 'A.5.30', framework: 'isms', category: 'business_continuity', name: '事業継続のためのICT', objective: '災害時のICT継続性', level: 'mandatory', evidenceExamples: ['BCP', '復旧テスト結果'] },

  // Pマーク (JIS Q 15001:2017)
  { id: 'P.1', framework: 'pmark', category: 'compliance', name: '個人情報保護方針', objective: '個情法+JIS適合の方針', level: 'mandatory', evidenceExamples: ['個人情報保護方針', '掲示証跡'] },
  { id: 'P.2', framework: 'pmark', category: 'asset_management', name: '個人情報の特定', objective: '取扱う個人情報の網羅的特定', level: 'mandatory', evidenceExamples: ['個人情報管理台帳'] },
  { id: 'P.3', framework: 'pmark', category: 'risk_assessment', name: 'リスクアセスメント', objective: '個人情報のリスク分析', level: 'mandatory', evidenceExamples: ['リスクアセスメント記録'] },

  // 金商法 J-SOX (IT全般統制)
  { id: 'JSOX-IT-1', framework: 'jsox', category: 'access_control', name: 'IT全般統制 - アクセス管理', objective: '財務報告に重要な影響を与える ITシステムへのアクセス管理', level: 'mandatory', evidenceExamples: ['特権ID管理記録', '退職者ID削除手順'] },
  { id: 'JSOX-IT-2', framework: 'jsox', category: 'operations_security', name: 'IT全般統制 - 変更管理', objective: '本番環境への変更承認', level: 'mandatory', evidenceExamples: ['変更管理ワークフロー', '本番リリース承認記録'] },
  { id: 'JSOX-IT-3', framework: 'jsox', category: 'operations_security', name: 'IT全般統制 - 運用管理', objective: 'バッチ処理・バックアップ・障害対応', level: 'mandatory', evidenceExamples: ['ジョブスケジュール', 'バックアップ証跡', '障害対応記録'] },

  // SOC2 (Trust Services Criteria)
  { id: 'CC6.1', framework: 'soc2', category: 'access_control', name: '論理アクセス', objective: '論理アクセスの制限', level: 'mandatory', evidenceExamples: ['IAMポリシー', 'MFA有効化証跡'] },
  { id: 'CC7.2', framework: 'soc2', category: 'incident_management', name: 'システム監視', objective: '異常検知と対応', level: 'mandatory', evidenceExamples: ['SIEMアラート', 'インシデント記録'] },

  // ISMAP
  { id: 'ISMAP-01', framework: 'ismap', category: 'compliance', name: 'クラウドサービス認定', objective: '政府調達向けクラウドの認定', level: 'mandatory', evidenceExamples: ['ISMAP認定証', '管理基準適合報告書'] },
];

// ============================================================================
// J-SOX IT全般統制チェックリスト
// ============================================================================

export interface JSOXItgcCheckResult {
  category: '社内システム整備' | 'システム運用' | 'プログラム変更管理' | 'アクセス管理' | '外部委託管理';
  checks: { item: string; passed: boolean; remarks?: string }[];
  passedRate: number;
}

export function checkJSOXITGC(input: {
  hasChangeApprovalWorkflow: boolean;
  hasPrivilegedIdMonitoring: boolean;
  hasJobSchedulingDocumented: boolean;
  hasBackupVerification: boolean;
  hasIncidentLog: boolean;
  hasVendorControlAgreement: boolean;
  hasAccessReviewQuarterly: boolean;
  hasSeparationOfDuties: boolean;
}): JSOXItgcCheckResult[] {
  const results: JSOXItgcCheckResult[] = [];
  const change: JSOXItgcCheckResult = {
    category: 'プログラム変更管理',
    checks: [
      { item: '変更承認ワークフローが存在', passed: input.hasChangeApprovalWorkflow },
      { item: 'リリース時のテスト記録', passed: input.hasJobSchedulingDocumented, remarks: 'ジョブスケジュール文書化兼用' },
    ],
    passedRate: 0,
  };
  change.passedRate = pct(change.checks);
  results.push(change);

  const access: JSOXItgcCheckResult = {
    category: 'アクセス管理',
    checks: [
      { item: '特権IDの監視', passed: input.hasPrivilegedIdMonitoring },
      { item: '四半期ごとのアクセスレビュー', passed: input.hasAccessReviewQuarterly },
      { item: '職務分掌の徹底', passed: input.hasSeparationOfDuties },
    ],
    passedRate: 0,
  };
  access.passedRate = pct(access.checks);
  results.push(access);

  const ops: JSOXItgcCheckResult = {
    category: 'システム運用',
    checks: [
      { item: 'バックアップ検証記録', passed: input.hasBackupVerification },
      { item: 'インシデントログ', passed: input.hasIncidentLog },
    ],
    passedRate: 0,
  };
  ops.passedRate = pct(ops.checks);
  results.push(ops);

  const vendor: JSOXItgcCheckResult = {
    category: '外部委託管理',
    checks: [
      { item: '委託先管理契約 (再委託含む)', passed: input.hasVendorControlAgreement },
    ],
    passedRate: 0,
  };
  vendor.passedRate = pct(vendor.checks);
  results.push(vendor);

  return results;
}
function pct(checks: { passed: boolean }[]): number {
  if (checks.length === 0) return 0;
  return Math.round((checks.filter((c) => c.passed).length / checks.length) * 100);
}

// ============================================================================
// 監査ログ要件 (改ざん検知 + 保管)
// ============================================================================

export interface AuditLogRequirement {
  framework: SecurityFramework;
  /** 保管期間 (年) */
  retentionYears: number;
  /** 改ざん検知 */
  tamperDetection: boolean;
  /** WORM ストレージ要件 */
  wormRequired: boolean;
  /** 監査ログ項目 */
  requiredFields: string[];
}

export const AUDIT_LOG_REQUIREMENTS: AuditLogRequirement[] = [
  { framework: 'isms', retentionYears: 3, tamperDetection: true, wormRequired: false, requiredFields: ['actor', 'action', 'target', 'timestamp', 'result'] },
  { framework: 'pmark', retentionYears: 3, tamperDetection: true, wormRequired: false, requiredFields: ['actor', 'action', 'target', 'timestamp', 'result', 'pii_category'] },
  { framework: 'jsox', retentionYears: 7, tamperDetection: true, wormRequired: true, requiredFields: ['actor', 'action', 'target', 'timestamp', 'before', 'after', 'approver'] },
  { framework: 'ismap', retentionYears: 5, tamperDetection: true, wormRequired: true, requiredFields: ['actor', 'action', 'target', 'timestamp', 'result', 'source_ip'] },
];

// ============================================================================
// セキュリティ監査スコア算出
// ============================================================================

export function scoreSecurityPosture(input: {
  isms: { passedControls: number; totalControls: number };
  pmark: { passedControls: number; totalControls: number };
  jsox: { passedControls: number; totalControls: number };
  vulnerabilities: { critical: number; high: number; medium: number };
  encryptionAtRest: boolean;
  encryptionInTransit: boolean;
  mfaCoverage: number; // %
  patchSlaDays: number;
}): { score: number; grade: 'A+' | 'A' | 'B' | 'C' | 'D' | 'F'; findings: string[] } {
  let score = 100;
  const findings: string[] = [];

  const ismsRate = input.isms.totalControls > 0 ? input.isms.passedControls / input.isms.totalControls : 1;
  const pmRate = input.pmark.totalControls > 0 ? input.pmark.passedControls / input.pmark.totalControls : 1;
  const jsoxRate = input.jsox.totalControls > 0 ? input.jsox.passedControls / input.jsox.totalControls : 1;

  if (ismsRate < 0.9) { score -= (0.9 - ismsRate) * 100; findings.push('ISMS統制達成率不足'); }
  if (pmRate < 0.9) { score -= (0.9 - pmRate) * 100; findings.push('Pマーク統制達成率不足'); }
  if (jsoxRate < 0.95) { score -= (0.95 - jsoxRate) * 200; findings.push('J-SOX統制達成率不足 (重要不備)'); }

  if (input.vulnerabilities.critical > 0) { score -= input.vulnerabilities.critical * 10; findings.push(`Critical脆弱性 ${input.vulnerabilities.critical} 件`); }
  if (input.vulnerabilities.high > 5) { score -= (input.vulnerabilities.high - 5) * 2; findings.push(`High脆弱性多数`); }

  if (!input.encryptionAtRest) { score -= 15; findings.push('保存時暗号化未実装'); }
  if (!input.encryptionInTransit) { score -= 15; findings.push('通信時暗号化未実装'); }
  if (input.mfaCoverage < 95) { score -= (95 - input.mfaCoverage) / 2; findings.push(`MFAカバレッジ不足 (${input.mfaCoverage}%)`); }
  if (input.patchSlaDays > 30) { score -= (input.patchSlaDays - 30) / 2; findings.push(`パッチ適用SLA超過 (${input.patchSlaDays}日)`); }

  score = Math.max(0, Math.round(score));
  const grade = score >= 95 ? 'A+' : score >= 85 ? 'A' : score >= 75 ? 'B' : score >= 60 ? 'C' : score >= 40 ? 'D' : 'F';
  return { score, grade, findings };
}

export const SECURITY_AUDIT_REFS = {
  ISMS_AC: 'https://isms.jp/',
  PMARK: 'https://privacymark.jp/',
  ISMAP: 'https://www.ismap.go.jp/',
  JSOX: 'https://www.fsa.go.jp/news/30/sonota/20180516.html',
};
