/**
 * SoloptiLinkAI JAPAN-NATIVE Mode - Save Guarantee Library (v2015.4 Phase 6)
 *
 * 「一箇所だけ保存できない」系バグを生成時点で根絶するためのバグ予防DNA。
 * 顧客管理/業務系アプリで最も頻出する「保存エラー」のパターンを封じ込める。
 *
 * 対応する既知のバグパターン:
 *   P1: CSRF トークン欠落 → 403 保存失敗
 *   P2: サーバ側 zod スキーマ不一致 → 422 Unprocessable Entity
 *   P3: Prisma の unique 制約違反を握り潰す → ユーザに「保存できない」だけ表示
 *   P4: トランザクション外での複数テーブル書込 → 途中失敗で孤児レコード
 *   P5: 楽観ロックなしでの同時編集 → 片方の変更が消失
 *   P6: FormData/JSON の取り違え → Content-Type 不一致で 400
 *   P7: Date/Decimal のシリアライズ欠落 → Invalid Date / NaN
 *   P8: NOT NULL カラムへの undefined → 23502
 *   P9: Foreign Key 違反の人間可読化なし
 *   P10: 非同期 onClick の多重発火
 *   P11: エラー発生時に loading state が解除されず永遠のスピナー
 *   P12: バリデーションエラーを field レベルで返さない
 *   P13: 日本語文字列の truncate/絵文字 surrogate 半分切れ
 *   P14: タイムゾーン混在 (UTC 保存 / JST 表示のズレで過去日扱い)
 *   P15: 楽観更新で失敗時のロールバック欠落
 *
 * 使い方:
 *   import { SaveGuarantee } from './save_guarantee';
 *   await SaveGuarantee.ensure(async (tx) => { ... });
 */

// =============================================================================
// Error classification (人間可読なエラーメッセージ生成)
// =============================================================================

export type SaveFailureReason =
  | 'CSRF_MISSING'
  | 'VALIDATION_FAILED'
  | 'UNIQUE_VIOLATION'
  | 'FK_VIOLATION'
  | 'NOT_NULL_VIOLATION'
  | 'TIMEOUT'
  | 'NETWORK'
  | 'OPTIMISTIC_LOCK'
  | 'SERIALIZATION'
  | 'UNKNOWN';

export interface SaveFailureDiagnosis {
  reason: SaveFailureReason;
  userMessage: string;       // 日本語、敬体、顧客向け
  developerMessage: string;  // スタッフ向け英語 + 技術詳細
  fieldErrors?: Record<string, string>;
  retryable: boolean;
  suggestedAction?: string;  // 「入力を見直す」「しばらく待って再試行」等
}

const PRISMA_CODE_MAP: Record<string, SaveFailureReason> = {
  P2002: 'UNIQUE_VIOLATION',
  P2003: 'FK_VIOLATION',
  P2011: 'NOT_NULL_VIOLATION',
  P2024: 'TIMEOUT',
  P2034: 'OPTIMISTIC_LOCK',
};

const PG_CODE_MAP: Record<string, SaveFailureReason> = {
  '23505': 'UNIQUE_VIOLATION',
  '23503': 'FK_VIOLATION',
  '23502': 'NOT_NULL_VIOLATION',
  '40001': 'OPTIMISTIC_LOCK',
  '57014': 'TIMEOUT',
};

/**
 * エラーを診断し、顧客向けの日本語メッセージを構築する。
 */
export function diagnoseSaveFailure(err: unknown): SaveFailureDiagnosis {
  // Prisma KnownRequestError
  const anyErr = err as { code?: string; meta?: { target?: string[]; field_name?: string }; name?: string; message?: string };

  if (anyErr?.code && PRISMA_CODE_MAP[anyErr.code]) {
    const reason = PRISMA_CODE_MAP[anyErr.code];
    return buildDiagnosis(reason, anyErr);
  }

  if (anyErr?.code && PG_CODE_MAP[anyErr.code]) {
    const reason = PG_CODE_MAP[anyErr.code];
    return buildDiagnosis(reason, anyErr);
  }

  if (anyErr?.name === 'ZodError') {
    const zodIssues = (anyErr as unknown as { issues: Array<{ path: (string | number)[]; message: string }> }).issues ?? [];
    const fieldErrors: Record<string, string> = {};
    for (const issue of zodIssues) {
      fieldErrors[issue.path.join('.')] = localizeZodMessage(issue.message);
    }
    return {
      reason: 'VALIDATION_FAILED',
      userMessage: '入力内容に誤りがあります。赤く表示されている項目をご確認ください。',
      developerMessage: `ZodError: ${JSON.stringify(zodIssues)}`,
      fieldErrors,
      retryable: true,
      suggestedAction: '該当項目を修正してから再度保存してください',
    };
  }

  if (anyErr?.name === 'AbortError' || anyErr?.message?.includes('fetch failed')) {
    return {
      reason: 'NETWORK',
      userMessage: '通信が不安定なため保存できませんでした。電波状況をご確認の上、もう一度お試しください。',
      developerMessage: `Network error: ${anyErr?.message ?? 'unknown'}`,
      retryable: true,
      suggestedAction: 'しばらく待ってから再試行',
    };
  }

  return {
    reason: 'UNKNOWN',
    userMessage: '保存中に予期しない問題が発生しました。恐れ入りますが、時間を置いて再度お試しください。',
    developerMessage: `Unhandled: ${anyErr?.message ?? String(err)}`,
    retryable: true,
  };
}

function buildDiagnosis(reason: SaveFailureReason, err: { meta?: { target?: string[]; field_name?: string }; message?: string }): SaveFailureDiagnosis {
  switch (reason) {
    case 'UNIQUE_VIOLATION': {
      const fields = err.meta?.target ?? [];
      const jpField = fields.map(f => localizeFieldName(f)).join('・');
      return {
        reason,
        userMessage: jpField
          ? `${jpField} はすでに登録されています。別の値でお試しください。`
          : '同じ内容がすでに登録されています。別の値でお試しください。',
        developerMessage: `Unique constraint violated on: ${fields.join(',')}`,
        retryable: true,
        suggestedAction: '重複しない値に変更',
      };
    }
    case 'FK_VIOLATION': {
      const fn = err.meta?.field_name ?? 'relation';
      return {
        reason,
        userMessage: '関連する項目が見つかりません。該当項目を再選択してください。',
        developerMessage: `Foreign key violation: ${fn}`,
        retryable: true,
        suggestedAction: '関連データを再選択',
      };
    }
    case 'NOT_NULL_VIOLATION': {
      const fn = err.meta?.field_name ?? 'field';
      return {
        reason,
        userMessage: `${localizeFieldName(fn)} は必須項目です。入力してください。`,
        developerMessage: `NOT NULL violation: ${fn}`,
        fieldErrors: { [fn]: '必須項目です' },
        retryable: true,
      };
    }
    case 'TIMEOUT':
      return {
        reason,
        userMessage: '保存に時間がかかっています。しばらく待ってから再度お試しください。',
        developerMessage: 'Query timeout',
        retryable: true,
      };
    case 'OPTIMISTIC_LOCK':
      return {
        reason,
        userMessage: 'このデータは他の画面で更新されました。最新の内容を読み込んでから再度お試しください。',
        developerMessage: 'Optimistic concurrency conflict',
        retryable: true,
        suggestedAction: 'ページを更新して再編集',
      };
    default:
      return {
        reason: 'UNKNOWN',
        userMessage: '保存中に問題が発生しました。',
        developerMessage: `Unhandled reason: ${reason}`,
        retryable: true,
      };
  }
}

// =============================================================================
// Field name localization (DB カラム名 → 日本語ラベル)
// =============================================================================

const FIELD_LABELS: Record<string, string> = {
  email: 'メールアドレス',
  phone: '電話番号',
  name: '氏名',
  company_name: '会社名',
  customer_name: '顧客名',
  password: 'パスワード',
  postal_code: '郵便番号',
  address: '住所',
  invoice_number: 'インボイス登録番号',
  tax_rate: '税率',
  amount: '金額',
  issued_at: '発行日',
  due_at: '支払期日',
  contract_date: '契約日',
};

export function localizeFieldName(name: string): string {
  if (FIELD_LABELS[name]) return FIELD_LABELS[name];
  // snake_case → Title Case → 最後の手段として原文返却
  return name.replace(/_/g, ' ');
}

const ZOD_MESSAGE_MAP: Record<string, string> = {
  'Required': '必須項目です',
  'Invalid email': 'メールアドレスの形式が正しくありません',
  'String must contain at least 1 character(s)': '1文字以上で入力してください',
  'Invalid url': 'URL の形式が正しくありません',
  'Invalid date': '日付の形式が正しくありません',
};

function localizeZodMessage(msg: string): string {
  return ZOD_MESSAGE_MAP[msg] ?? msg;
}

// =============================================================================
// Transactional save wrapper (P4 対策: 孤児レコード防止)
// =============================================================================

export interface SaveGuaranteeOptions {
  maxRetries?: number;
  retryDelayMs?: number;
  idempotencyKey?: string;
  auditLog?: (entry: {
    ts: string;
    action: string;
    actor?: string;
    outcome: 'success' | 'failure';
    reason?: SaveFailureReason;
  }) => Promise<void> | void;
}

/**
 * 複数テーブルへの書込をトランザクションで保護し、失敗時は顧客向けメッセージを生成する。
 *
 * 使用例:
 *   const result = await SaveGuarantee.ensure(async (tx) => {
 *     const customer = await tx.customer.create({ data: input });
 *     await tx.contactHistory.create({ data: { customerId: customer.id, ... } });
 *     return customer;
 *   }, { auditLog: writeAudit });
 *
 *   if (!result.ok) {
 *     return NextResponse.json({ error: result.diagnosis.userMessage, fields: result.diagnosis.fieldErrors }, { status: 400 });
 *   }
 */
export const SaveGuarantee = {
  async ensure<T>(
    operation: (tx: unknown) => Promise<T>,
    opts: SaveGuaranteeOptions & { transaction?: (fn: (tx: unknown) => Promise<T>) => Promise<T> } = {},
  ): Promise<
    | { ok: true; data: T }
    | { ok: false; diagnosis: SaveFailureDiagnosis }
  > {
    const maxRetries = opts.maxRetries ?? 2;
    const retryDelay = opts.retryDelayMs ?? 200;
    const run = opts.transaction ?? ((fn: (tx: unknown) => Promise<T>) => fn(null));

    let lastErr: unknown;
    for (let attempt = 0; attempt <= maxRetries; attempt++) {
      try {
        const data = await run(operation);
        await opts.auditLog?.({
          ts: new Date().toISOString(),
          action: 'save',
          outcome: 'success',
        });
        return { ok: true, data };
      } catch (err) {
        lastErr = err;
        const diagnosis = diagnoseSaveFailure(err);
        if (!diagnosis.retryable || diagnosis.reason === 'VALIDATION_FAILED' || diagnosis.reason === 'UNIQUE_VIOLATION') {
          await opts.auditLog?.({
            ts: new Date().toISOString(),
            action: 'save',
            outcome: 'failure',
            reason: diagnosis.reason,
          });
          return { ok: false, diagnosis };
        }
        if (attempt < maxRetries) {
          await new Promise(r => setTimeout(r, retryDelay * Math.pow(2, attempt)));
        }
      }
    }

    const finalDiagnosis = diagnoseSaveFailure(lastErr);
    await opts.auditLog?.({
      ts: new Date().toISOString(),
      action: 'save',
      outcome: 'failure',
      reason: finalDiagnosis.reason,
    });
    return { ok: false, diagnosis: finalDiagnosis };
  },
};

// =============================================================================
// Optimistic lock helper (P5 対策: 同時編集消失防止)
// =============================================================================

export interface OptimisticLockFields {
  updated_at: Date | string;
  version?: number;
}

/**
 * 楽観ロックに必要な WHERE 条件を生成する。
 * Prisma の update where に `{ id, updated_at: snapshot.updated_at }` として使う想定。
 */
export function buildOptimisticWhere(id: string | number, snapshot: OptimisticLockFields): Record<string, unknown> {
  const where: Record<string, unknown> = { id };
  if (snapshot.version !== undefined) {
    where.version = snapshot.version;
  } else {
    where.updated_at = snapshot.updated_at;
  }
  return where;
}

// =============================================================================
// CSRF / Idempotency helpers (P1 / P10 対策)
// =============================================================================

/**
 * Idempotency-Key ヘッダを同期発行するユーティリティ。
 * フロント側でフォーム送信前に1回だけ生成し、再送時も同じキーを使う。
 */
export function generateIdempotencyKey(): string {
  if (typeof crypto !== 'undefined' && 'randomUUID' in crypto) {
    return crypto.randomUUID();
  }
  const rand = Math.random().toString(16).slice(2) + Date.now().toString(16);
  return rand.padEnd(32, '0').slice(0, 32);
}

/**
 * サーバ側で Idempotency-Key の再実行を防止する。
 * メモリ内 Set 等ではなく、必ず永続化されたストア (Redis/DB) を渡すこと。
 */
export async function withIdempotency<T>(
  key: string | null | undefined,
  store: {
    get: (k: string) => Promise<{ payload: unknown } | null>;
    set: (k: string, payload: unknown, ttlSec: number) => Promise<void>;
  },
  operation: () => Promise<T>,
  ttlSec = 24 * 60 * 60,
): Promise<T> {
  if (!key) return operation();
  const existing = await store.get(key);
  if (existing) return existing.payload as T;
  const result = await operation();
  await store.set(key, result, ttlSec);
  return result;
}

// =============================================================================
// Japanese-safe string truncation (P13 対策)
// =============================================================================

/**
 * サロゲートペアと IVS を壊さずに文字列を truncate する。
 * DB の varchar(N) 格納前に必ず通す。
 */
export function truncateSafe(s: string, maxCodeUnits: number): string {
  if (!s) return s;
  const normalized = s.normalize('NFC');
  if (normalized.length <= maxCodeUnits) return normalized;
  // Array.from で code point 単位に切る (サロゲートペアを壊さない)
  const cps = Array.from(normalized);
  return cps.slice(0, maxCodeUnits).join('');
}

// =============================================================================
// Date/Timezone helpers (P7 / P14 対策)
// =============================================================================

/**
 * 画面入力の日本時間文字列 (YYYY-MM-DD HH:mm) を UTC ISO8601 に変換する。
 * タイムゾーン不一致で「翌日になる」「前日になる」バグを根絶。
 */
export function jstToUtcIso(jstDateTime: string): string {
  const [datePart, timePart = '00:00'] = jstDateTime.trim().split(/[\sT]/);
  const [y, m, d] = datePart.split('-').map(Number);
  const [hh, mm] = timePart.split(':').map(Number);
  // JST = UTC+9
  const date = new Date(Date.UTC(y, m - 1, d, hh - 9, mm, 0, 0));
  return date.toISOString();
}

/**
 * UTC ISO8601 を JST 表示用文字列に変換する。
 */
export function utcToJstDisplay(iso: string, opts: { withSeconds?: boolean } = {}): string {
  const d = new Date(iso);
  const jst = new Date(d.getTime() + 9 * 60 * 60 * 1000);
  const pad = (n: number) => n.toString().padStart(2, '0');
  const base = `${jst.getUTCFullYear()}-${pad(jst.getUTCMonth() + 1)}-${pad(jst.getUTCDate())} ${pad(jst.getUTCHours())}:${pad(jst.getUTCMinutes())}`;
  return opts.withSeconds ? `${base}:${pad(jst.getUTCSeconds())}` : base;
}
