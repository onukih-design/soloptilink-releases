/**
 * SoloptiLinkAI Phase 16 — Marketing Compliance (Japan)
 *
 * 景品表示法 / 特定商取引法 / 個人情報保護法 / 薬機法 / 健康増進法 等の
 * 広告・販促コピーに関するコンプライアンス検証。
 *
 * カバー範囲:
 *  - 景表法第5条 (優良誤認表示・有利誤認表示)
 *  - ステマ規制 2023年10月施行 (景表法告示)
 *  - 特商法 通信販売の表示義務 (12条の表示事項)
 *  - 薬機法 66条 (虚偽誇大広告の禁止)
 *  - 健康増進法 65条 (誇大表示の禁止)
 *  - 食品表示法 (アレルゲン・原産地)
 *  - 個情法 26条 R4改正 (漏えい時5日速報)
 *  - メールマーケ: 特電法 (オプトイン必須)
 */

export type ViolationSeverity = "info" | "warning" | "violation";

export interface ComplianceFinding {
  rule: string; // 法令名 + 条項
  matched: string; // 引っかかった文字列
  position?: { start: number; end: number };
  severity: ViolationSeverity;
  hint: string;
}

interface PatternRule {
  rule: string;
  pattern: RegExp;
  severity: ViolationSeverity;
  hint: string;
}

const KEISHO_FORBIDDEN: PatternRule[] = [
  {
    rule: "景表法第5条1号 優良誤認表示の疑い",
    pattern: /(完全に|絶対に|100%|必ず|間違いなく|誰でも)(治る|痩せる|稼げる|当たる|成功)/g,
    severity: "violation",
    hint: "効果断言は優良誤認表示に該当しうる。合理的根拠資料 (措置命令対象) を要する。",
  },
  {
    rule: "景表法第5条1号 No.1表示",
    pattern: /(業界|国内|世界|日本)?[NnＮｎ]o\.?1|ナンバーワン|第一位|シェア[NnＮｎ]o\.?1/g,
    severity: "warning",
    hint: "No.1表示には客観的調査結果と調査期間・対象・出典の併記が必要 (公正取引委員会ガイドライン)。",
  },
  {
    rule: "景表法第5条2号 有利誤認表示の疑い (二重価格)",
    pattern: /通常価格.*?(円|￥|¥)|定価.*?(円|￥|¥).{0,40}(値引|割引|OFF)/g,
    severity: "warning",
    hint: "二重価格表示は最近相当期間の販売実績が必要。架空の通常価格は有利誤認に該当。",
  },
  {
    rule: "ステマ規制 2023年10月告示",
    pattern: /広告ではありません|これはPRではない|純粋な感想です/g,
    severity: "violation",
    hint: "事業者の依頼/提供がある場合は #PR / #広告 等の明示が必須。",
  },
];

const TOKUSHO_REQUIRED_PHRASES = [
  "事業者名",
  "所在地",
  "電話番号",
  "代表者",
  "販売価格",
  "送料",
  "支払方法",
  "引渡時期",
  "返品",
];

const YAKKIHO_FORBIDDEN: PatternRule[] = [
  {
    rule: "薬機法66条 虚偽誇大広告 (医薬品的効能効果)",
    pattern: /(治る|完治|根治|疾病の予防|症状の改善|病気が治癒)/g,
    severity: "violation",
    hint: "化粧品/食品/雑貨が医薬品的効能を標榜することは禁止。措置命令+刑事罰の可能性。",
  },
  {
    rule: "健康増進法65条 誇大表示 (健康保持増進)",
    pattern: /(必ず痩せる|脂肪が燃焼|血糖値が下がる|血圧を下げる)/g,
    severity: "violation",
    hint: "機能性表示食品/特保以外で生理機能を断言する表現は禁止。",
  },
];

const FOOD_LABEL_REQUIRED = ["原材料名", "アレルゲン", "賞味期限", "保存方法", "製造者"];

export function scanText(text: string): ComplianceFinding[] {
  const findings: ComplianceFinding[] = [];
  for (const r of [...KEISHO_FORBIDDEN, ...YAKKIHO_FORBIDDEN]) {
    let m: RegExpExecArray | null;
    const re = new RegExp(r.pattern.source, r.pattern.flags);
    while ((m = re.exec(text)) !== null) {
      findings.push({
        rule: r.rule,
        matched: m[0],
        position: { start: m.index, end: m.index + m[0].length },
        severity: r.severity,
        hint: r.hint,
      });
      if (m.index === re.lastIndex) re.lastIndex += 1;
    }
  }
  return findings;
}

export interface TokushoPageInput {
  html_or_text: string;
  channel: "ec" | "subscription" | "telemarketing" | "auction";
  has_recurring_charge?: boolean;
}

export function checkTokushoLawDisplay(input: TokushoPageInput): ComplianceFinding[] {
  const findings: ComplianceFinding[] = [];
  for (const phrase of TOKUSHO_REQUIRED_PHRASES) {
    if (!input.html_or_text.includes(phrase)) {
      findings.push({
        rule: "特商法11条 通信販売の表示事項",
        matched: phrase,
        severity: "violation",
        hint: `特定商取引法に基づく表記に「${phrase}」が必須。`,
      });
    }
  }
  if (input.has_recurring_charge && !/解約|定期|サブスク/.test(input.html_or_text)) {
    findings.push({
      rule: "特商法 改正(2022年6月) 定期購入規制",
      matched: "解約方法/最終確認画面",
      severity: "violation",
      hint: "定期購入では最終確認画面に総支払額・解約条件を表示する義務あり。",
    });
  }
  return findings;
}

export interface FoodLabelInput {
  display_text: string;
  has_specified_raw_materials?: boolean;
  contains_allergens?: string[];
}

const STANDARD_ALLERGENS = ["卵", "乳", "小麦", "そば", "落花生", "えび", "かに", "くるみ"];

export function checkFoodLabel(input: FoodLabelInput): ComplianceFinding[] {
  const findings: ComplianceFinding[] = [];
  for (const key of FOOD_LABEL_REQUIRED) {
    if (!input.display_text.includes(key)) {
      findings.push({
        rule: "食品表示法 食品表示基準",
        matched: key,
        severity: "violation",
        hint: `「${key}」の表示が義務。`,
      });
    }
  }
  for (const a of input.contains_allergens ?? []) {
    if (STANDARD_ALLERGENS.includes(a) && !input.display_text.includes(a)) {
      findings.push({
        rule: "食品表示法 特定原材料 (8品目)",
        matched: a,
        severity: "violation",
        hint: `特定原材料 ${a} は表示義務 (くるみは2025年4月から義務化)。`,
      });
    }
  }
  return findings;
}

// メールマーケティング 特電法 (特定電子メールの送信の適正化等に関する法律)
export interface EmailCampaign {
  recipient_consent: "opt-in" | "opt-out" | "unknown";
  sender_name?: string;
  sender_address?: string;
  unsubscribe_link?: boolean;
  subject?: string;
}

export function checkEmailLaw(campaign: EmailCampaign): ComplianceFinding[] {
  const findings: ComplianceFinding[] = [];
  if (campaign.recipient_consent !== "opt-in") {
    findings.push({
      rule: "特電法 オプトイン規制",
      matched: "consent: " + campaign.recipient_consent,
      severity: "violation",
      hint: "原則として事前同意 (オプトイン) を得た受信者にのみ配信可能。",
    });
  }
  if (!campaign.sender_name) {
    findings.push({
      rule: "特電法 送信者情報の表示義務",
      matched: "sender_name 欠落",
      severity: "violation",
      hint: "送信者の氏名/名称を本文に明記。",
    });
  }
  if (!campaign.unsubscribe_link) {
    findings.push({
      rule: "特電法 受信拒否の通知方法",
      matched: "unsubscribe_link 欠落",
      severity: "violation",
      hint: "受信拒否のための連絡先 (URL/メールアドレス) を本文に明記。",
    });
  }
  if (campaign.subject && /(緊急|重要|未承諾)/.test(campaign.subject)) {
    findings.push({
      rule: "特電法 件名表示の表示誤認",
      matched: campaign.subject,
      severity: "warning",
      hint: "未承諾広告※の表示などは紛らわしい。広告である旨を冒頭に。",
    });
  }
  return findings;
}

// 個情法 第26条 R4改正 (漏えい等の報告) — 内容紹介
export interface IncidentTriage {
  category: "leakage" | "unauthorized_access" | "unknown";
  pii_count?: number;
  contains_sensitive?: boolean;
  cause?: "human_error" | "system_failure" | "malicious";
}

export function evaluatePiiBreachReport(triage: IncidentTriage): {
  must_report_speedy: boolean; // 5日以内
  must_report_definite: boolean; // 30日以内 (60日: 不正アクセス)
  reasoning: string[];
} {
  const reasons: string[] = [];
  let speedy = false;
  let definite = true;

  if (triage.contains_sensitive) {
    speedy = true;
    reasons.push("要配慮個人情報を含む → 5日速報義務");
  }
  if ((triage.pii_count ?? 0) >= 1000) {
    speedy = true;
    reasons.push("漏えい本人数 1,000人超 → 5日速報義務");
  }
  if (triage.cause === "malicious") {
    speedy = true;
    reasons.push("不正アクセス/標的型 → 5日速報義務 + 60日確報");
  }
  if (!speedy) {
    reasons.push("該当条件なし → 確報義務 (30日 / 不正アクセス60日)");
  }
  return { must_report_speedy: speedy, must_report_definite: definite, reasoning: reasons };
}

export function buildComplianceReport(findings: ComplianceFinding[]): string {
  const grouped: Record<string, ComplianceFinding[]> = {};
  for (const f of findings) {
    grouped[f.rule] = grouped[f.rule] ?? [];
    grouped[f.rule].push(f);
  }
  const lines: string[] = ["# Marketing Compliance Report"];
  if (findings.length === 0) lines.push("✅ 違反検出なし");
  for (const [rule, items] of Object.entries(grouped)) {
    lines.push(`## ${rule} (${items.length}件)`);
    for (const i of items) {
      lines.push(`- [${i.severity}] "${i.matched}" — ${i.hint}`);
    }
  }
  return lines.join("\n");
}
