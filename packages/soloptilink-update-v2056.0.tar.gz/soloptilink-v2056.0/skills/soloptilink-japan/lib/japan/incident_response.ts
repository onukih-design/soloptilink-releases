/**
 * SoloptiLinkAI Phase 32-CS — インシデントレスポンス (Incident Response)
 *
 * CSIRT 運用のプレイブック実行支援。
 * 既存 incident.ts (個情法第26条 R4改正報告判定) との役割分離:
 *   incident.ts          = 個情法 第26条 漏えい報告フロー (5日速報/30日確報)
 *   incident_response.ts = NIST SP 800-61 6段階 + ランサムウェア・標的型・DoS のプレイブック
 *
 * カバー範囲:
 *  - NIST SP 800-61 R2: Preparation/Detection/Containment/Eradication/Recovery/Post-Incident
 *  - インシデント分類 (8カテゴリ + 重大度判定)
 *  - 封じ込めアクション (ネットワーク分離/アカウント停止/フォレンジック保全)
 *  - 復旧優先度 (BCP RTO/RPO 連動)
 *  - 関係者通知 (経営層/CSIRT/法務/広報/警察/JPCERT/個情委)
 *  - エビデンス保全チェーン (chain of custody)
 *  - ポストモーテム (Blameless 5 Whys + アクションアイテム)
 */

export type IncidentCategory =
  | "ransomware"
  | "data_breach"
  | "ddos"
  | "phishing"
  | "malware"
  | "insider_threat"
  | "supply_chain"
  | "unauthorized_access"
  | "service_disruption"
  | "other";

export type IncidentSev = "SEV1" | "SEV2" | "SEV3" | "SEV4";

// NIST SP 800-61 R2 6 phases
export type NistPhase =
  | "preparation"
  | "detection_analysis"
  | "containment"
  | "eradication"
  | "recovery"
  | "post_incident";

export interface IncidentRecord {
  incident_id: string;
  detected_at: string;
  reported_by: string;
  category: IncidentCategory;
  severity: IncidentSev;
  current_phase: NistPhase;
  affected_systems: string[];
  affected_pii_count?: number;
  contains_sensitive_pii?: boolean; // 要配慮個人情報
  attack_vector?: string;
  ttps?: string[]; // MITRE ATT&CK Technique IDs
  status: "open" | "in_progress" | "contained" | "resolved" | "closed";
  commander?: string; // インシデント司令官
  scribe?: string;
}

// 重大度判定
export function classifyIncidentSeverity(input: {
  affected_users?: number;
  affected_systems_count?: number;
  service_impact?: "none" | "degraded" | "outage";
  data_exposed?: boolean;
  contains_sensitive_pii?: boolean;
  is_critical_infrastructure?: boolean;
}): IncidentSev {
  if (
    (input.affected_users ?? 0) >= 100_000 ||
    input.is_critical_infrastructure ||
    input.contains_sensitive_pii ||
    input.service_impact === "outage"
  ) {
    return "SEV1";
  }
  if (
    (input.affected_users ?? 0) >= 10_000 ||
    (input.affected_systems_count ?? 0) >= 5 ||
    input.service_impact === "degraded" ||
    input.data_exposed
  ) {
    return "SEV2";
  }
  if ((input.affected_users ?? 0) >= 100 || (input.affected_systems_count ?? 0) >= 1) {
    return "SEV3";
  }
  return "SEV4";
}

// プレイブック (NIST 6段階)
export interface PlaybookStep {
  phase: NistPhase;
  step_no: number;
  title: string;
  owner: string; // CSIRT_LEAD / IT_OPS / LEGAL / PR / EXEC
  estimated_minutes: number;
  required: boolean;
  description: string;
}

export const RANSOMWARE_PLAYBOOK: PlaybookStep[] = [
  // Detection & Analysis
  { phase: "detection_analysis", step_no: 1, title: "感染経路の特定 (initial access)", owner: "CSIRT_LEAD", estimated_minutes: 60, required: true, description: "EDRログ + メールゲートウェイログ + 認証ログを横断調査" },
  { phase: "detection_analysis", step_no: 2, title: "影響範囲の特定 (lateral movement)", owner: "CSIRT_LEAD", estimated_minutes: 120, required: true, description: "感染ホストの特定 + 暗号化対象ファイル一覧" },
  // Containment
  { phase: "containment", step_no: 3, title: "感染ホストのネットワーク分離", owner: "IT_OPS", estimated_minutes: 30, required: true, description: "EDRの隔離機能 / VLAN/SWポート停止 / VPN切断" },
  { phase: "containment", step_no: 4, title: "管理者アカウント全パスワード変更", owner: "IT_OPS", estimated_minutes: 60, required: true, description: "AD管理者 + クラウド管理者 + サービスアカウント" },
  { phase: "containment", step_no: 5, title: "バックアップの隔離 + 健全性確認", owner: "IT_OPS", estimated_minutes: 60, required: true, description: "オフラインバックアップを物理的に分離、暗号化されていないか確認" },
  // Eradication
  { phase: "eradication", step_no: 6, title: "C2サーバ通信先のブロック", owner: "IT_OPS", estimated_minutes: 30, required: true, description: "Firewall + Proxy + DNS でブロック" },
  { phase: "eradication", step_no: 7, title: "永続化機構の削除", owner: "CSIRT_LEAD", estimated_minutes: 120, required: true, description: "スケジュールタスク / レジストリRun / サービス" },
  // Recovery
  { phase: "recovery", step_no: 8, title: "クリーンインストール + バックアップ復旧", owner: "IT_OPS", estimated_minutes: 480, required: true, description: "OS再インストール → パッチ適用 → バックアップ復元 (ランサムノートより前)" },
  { phase: "recovery", step_no: 9, title: "監視強化期間 (30日間)", owner: "CSIRT_LEAD", estimated_minutes: 0, required: true, description: "再感染検知のため EDR + SIEM ルール強化" },
  // Post-Incident
  { phase: "post_incident", step_no: 10, title: "ポストモーテム (Blameless)", owner: "CSIRT_LEAD", estimated_minutes: 120, required: true, description: "5 Whys + アクションアイテム + ナレッジ化" },
  { phase: "post_incident", step_no: 11, title: "経営層への最終報告", owner: "CSIRT_LEAD", estimated_minutes: 60, required: true, description: "原因 + 影響 + 対策費用 + 再発防止" },
];

// 通知マトリクス
export type NotifyAudience =
  | "exec" // 経営層
  | "csirt"
  | "legal"
  | "pr"
  | "police" // 警察 (脅迫罪/不正アクセス禁止法違反)
  | "jpcert"
  | "ppc" // 個人情報保護委員会
  | "fsa" // 金融庁 (金融機関の場合)
  | "subject_individuals" // 本人通知
  | "customers"
  | "partners";

export interface NotificationDecision {
  audience: NotifyAudience;
  required: boolean;
  deadline?: string;
  rationale: string;
}

export function decideNotifications(incident: IncidentRecord, asOf: Date = new Date()): NotificationDecision[] {
  const out: NotificationDecision[] = [];
  const detected = new Date(incident.detected_at);

  // 経営層 (SEV1/SEV2 必須、即時)
  if (incident.severity === "SEV1" || incident.severity === "SEV2") {
    out.push({
      audience: "exec",
      required: true,
      deadline: new Date(detected.getTime() + 60 * 60 * 1000).toISOString(),
      rationale: `${incident.severity} は経営層への即時報告 (1時間以内)`,
    });
  }

  // CSIRT (常に必須)
  out.push({
    audience: "csirt",
    required: true,
    rationale: "全インシデントは CSIRT 招集",
  });

  // 法務 (個情漏えい/契約違反/訴訟リスク)
  if (incident.category === "data_breach" || incident.affected_pii_count !== undefined) {
    out.push({
      audience: "legal",
      required: true,
      rationale: "個人情報漏えい疑いは法務確認必須",
    });
  }

  // 個情委 (個情法第26条)
  if (incident.contains_sensitive_pii || (incident.affected_pii_count ?? 0) >= 1) {
    const speedy = incident.contains_sensitive_pii || (incident.affected_pii_count ?? 0) >= 1000 || incident.attack_vector?.includes("malicious");
    out.push({
      audience: "ppc",
      required: true,
      deadline: new Date(detected.getTime() + (speedy ? 5 : 30) * 24 * 60 * 60 * 1000).toISOString(),
      rationale: speedy
        ? "個情法第26条 R4改正: 5日以内速報 (要配慮 or 1000人超 or 不正アクセス)"
        : "個情法第26条 R4改正: 30日以内確報",
    });
  }

  // 本人通知
  if ((incident.affected_pii_count ?? 0) >= 1 && incident.contains_sensitive_pii) {
    out.push({
      audience: "subject_individuals",
      required: true,
      rationale: "個情法第26条 R4改正: 本人への通知義務 (例外: 通知困難で代替措置)",
    });
  }

  // 警察 (脅迫/不正アクセス)
  if (incident.category === "ransomware" || incident.category === "unauthorized_access") {
    out.push({
      audience: "police",
      required: false,
      rationale: "不正アクセス禁止法違反 / 脅迫罪 / 電子計算機損壊等業務妨害罪 で告訴可能",
    });
  }

  // JPCERT/CC
  if (incident.severity === "SEV1" || incident.severity === "SEV2") {
    out.push({
      audience: "jpcert",
      required: false,
      rationale: "JPCERT/CC への情報提供 (任意だが対応支援が得られる)",
    });
  }

  return out;
}

// エビデンス保全 (Chain of Custody)
export interface EvidenceItem {
  evidence_id: string;
  type: "disk_image" | "memory_dump" | "log" | "network_capture" | "physical" | "screenshot";
  collected_at: string;
  collected_by: string;
  source_system: string;
  hash_algorithm: "sha256" | "sha512";
  hash_value: string;
  storage_location: string;
  chain_of_custody: { ts: string; actor: string; action: "collected" | "transferred" | "analyzed" | "returned" | "destroyed"; notes?: string }[];
}

export function appendCustodyEvent(
  evidence: EvidenceItem,
  actor: string,
  action: EvidenceItem["chain_of_custody"][number]["action"],
  notes?: string,
): EvidenceItem {
  return {
    ...evidence,
    chain_of_custody: [
      ...evidence.chain_of_custody,
      { ts: new Date().toISOString(), actor, action, notes },
    ],
  };
}

// ポストモーテム
export interface PostMortem {
  incident_id: string;
  what_happened: string;
  timeline: { ts: string; event: string }[];
  root_causes: { description: string; why_layer: number }[]; // 5 Whys
  contributing_factors: string[];
  what_went_well: string[];
  what_went_poorly: string[];
  action_items: { id: string; description: string; owner: string; due_date: string; status: "open" | "in_progress" | "done" }[];
}

export function buildPostMortemTemplate(incident: IncidentRecord): PostMortem {
  return {
    incident_id: incident.incident_id,
    what_happened: "[1〜2文で要約]",
    timeline: [
      { ts: incident.detected_at, event: "検知" },
    ],
    root_causes: [
      { description: "[Why 1]", why_layer: 1 },
      { description: "[Why 2: なぜ Why 1 が起きたか]", why_layer: 2 },
      { description: "[Why 3]", why_layer: 3 },
      { description: "[Why 4]", why_layer: 4 },
      { description: "[Why 5: 真の根本原因]", why_layer: 5 },
    ],
    contributing_factors: [],
    what_went_well: [],
    what_went_poorly: [],
    action_items: [],
  };
}
