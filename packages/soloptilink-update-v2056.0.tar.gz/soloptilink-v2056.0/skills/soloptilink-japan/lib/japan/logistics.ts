// @ts-check
/**
 * 物流運輸 DNA (Phase 19)
 *
 * Claude Code がカバーしない日本の物流・運輸業を完全カバー。
 *
 *  - 貨物自動車運送事業法 (一般貨物 / 特定貨物 / 貨物軽自動車)
 *  - 改善基準告示 (R6.4 改正) - 拘束時間 / 休息期間 / 連続運転時間
 *  - 2024年問題 (時間外労働の上限規制 年960時間)
 *  - 標準的な運賃 (国交省告示 R2 / R6改訂)
 *  - 運行管理者 (旅客 / 貨物)
 *  - 点呼 (始業 / 終業 / 中間 IT点呼)
 *  - デジタコ (タコグラフ) - 速度/距離/時間
 *  - 運送状 (国際: B/L 国内: 配達伝票)
 *  - 燃料サーチャージ
 *  - 3PL / 4PL ロジスティクス
 *  - 倉庫業法 (1類 / 2類 / 3類 / 危険品)
 *  - 標準引越運送約款
 *
 * 出典 (一次情報):
 *   - 自動車運転者の労働時間等の改善のための基準 (改善基準告示)
 *     平成元年労働省告示第7号 / 令和4年12月23日厚生労働省告示第367号による改正
 *     令和6年4月1日適用
 *     https://www.mhlw.go.jp/stf/seisakunitsuite/bunya/koyou_roudou/roudoukijun/gyosyu/roudoujouken05/index.html
 *   - 全日本トラック協会/国土交通省「トラック運転者の改善基準告示 ー2024年4月適用ー 解説」
 *     https://wwwtb.mlit.go.jp/kinki/content/000306033.pdf
 *   - 標準的な運賃 (国交省) https://www.mlit.go.jp/jidosha/jidosha_tk1_000094.html
 */

// =============================================================================
// 改善基準告示 (令和6年4月1日適用)
// =============================================================================

/**
 * 改善基準告示 第4条 に定めるトラック運転者の基準値 (一次情報から転記)。
 *
 * 【出典】全日本トラック協会/国土交通省「トラック運転者の改善基準告示 解説」
 *   https://wwwtb.mlit.go.jp/kinki/content/000306033.pdf
 *
 *   第4条第1項第1号 1年の拘束時間   : 3,300時間以内 (労使協定により 3,400時間まで延長可)
 *   第4条第1項第2号 1か月の拘束時間 : 284時間以内 (労使協定により年6か月まで 310時間まで延長可)
 *                                     ただし284時間超が4か月連続することは認められない
 *   第4条第1項第3号/第4号 1日の拘束時間: 原則13時間以内 / 上限15時間
 *                                     (14時間超は1週間で2回以内が目安)
 *                                     宿泊を伴う長距離貨物運送の特例に限り週2回まで16時間
 *   第4条第1項第5号 1日の休息期間   : 継続11時間以上となるよう努めることを基本とし、
 *                                     継続9時間を下回ってはならない
 *                                     長距離特例時は週2回に限り継続8時間以上
 *                                     (その場合は運行終了後に継続12時間以上の休息期間が必要)
 *   第4条第1項第6号 運転時間         : 2日平均1日9時間以内 / 2週平均1週44時間以内
 *   第4条第1項第7号/第8号 連続運転時間: 4時間以内 (やむを得ない場合は4時間30分まで延長可)
 *                                     運転の中断は1回おおむね10分以上で合計30分以上
 *   第4条第4項第1号 分割休息の特例   : 1回3時間以上。2分割で合計10時間以上 /
 *                                     3分割で合計12時間以上。分割休息の日は1か月の2分の1が限度
 */
export const KAIZEN_KIJUN_KOKUJI = {
  /** 1日の拘束時間 原則 (13時間) */
  daily_binding_principle_minutes: 13 * 60,
  /** 1日の拘束時間 上限 (15時間) — 改正前は16時間だった */
  daily_binding_max_minutes: 15 * 60,
  /** 14時間超は1週間で2回以内が目安 */
  daily_binding_weekly_caution_minutes: 14 * 60,
  /** 宿泊を伴う長距離貨物運送の特例における1日の拘束時間の上限 (16時間・週2回まで) */
  daily_binding_long_haul_special_minutes: 16 * 60,
  /** 休息期間の努力義務 (継続11時間以上) */
  rest_effort_min_minutes: 11 * 60,
  /** 休息期間の絶対的下限 (継続9時間) */
  rest_absolute_min_minutes: 9 * 60,
  /** 宿泊を伴う長距離貨物運送の特例における休息期間の下限 (継続8時間・週2回まで) */
  rest_long_haul_special_min_minutes: 8 * 60,
  /** 分割休息: 1回あたりの下限 (3時間) */
  split_rest_each_min_minutes: 3 * 60,
  /** 分割休息: 2分割の合計下限 (10時間) */
  split_rest_total_2_min_minutes: 10 * 60,
  /** 分割休息: 3分割の合計下限 (12時間) */
  split_rest_total_3_min_minutes: 12 * 60,
  /** 連続運転時間の原則 (4時間) */
  continuous_driving_principle_minutes: 4 * 60,
  /** 連続運転時間のやむを得ない場合の上限 (4時間30分) */
  continuous_driving_max_minutes: 4 * 60 + 30,
  /** 連続運転の中断に必要な合計休憩 (30分) */
  driving_break_required_minutes: 30,
  /** 1か月の拘束時間 原則 (284時間) */
  monthly_binding_principle_hours: 284,
  /** 1か月の拘束時間 労使協定時 (310時間・年6か月まで) */
  monthly_binding_agreement_hours: 310,
  /** 1年の拘束時間 原則 (3,300時間) */
  annual_binding_principle_hours: 3300,
  /** 1年の拘束時間 労使協定時 (3,400時間) */
  annual_binding_agreement_hours: 3400,
  /** 労使協定で月284時間を超えられるのは年6か月まで */
  monthly_over_principle_max_months: 6,
  /** 月284時間超が連続してよいのは3か月まで (4か月連続は不可) */
  monthly_over_principle_max_consecutive_months: 3,
  /** 労働基準法上のドライバーの時間外労働の上限 (年960時間) */
  annual_overtime_limit_hours: 960,
} as const;

export interface DriverWorkRecord {
  driver_id: string;
  date: string; // YYYY-MM-DD
  /** 拘束時間 (始業から終業まで) - 分 */
  binding_minutes: number;
  /** 運転時間 - 分 */
  driving_minutes: number;
  /** 休息期間 (前日終業〜当日始業) - 分 */
  rest_minutes: number;
  /** 連続運転時間 (4 時間連続超で休憩必要) - 分 */
  max_continuous_driving_minutes: number;
  /** 休憩時間 (4時間運転で30分以上 等) - 分 */
  break_minutes: number;
  /** 分割休息の特例を適用しているか (第4条第4項第1号) */
  uses_split_rest: boolean;
  /** 分割休息の分割数 (2 または 3。省略時は 2 とみなす) */
  rest_split_count?: number;
  /** 分割休息の各回の長さ - 分 (与えられた場合は1回3時間以上を検査する) */
  rest_split_minutes?: number[];
  /**
   * 宿泊を伴う長距離貨物運送の特例を適用しているか (第4条第1項第4号)。
   *
   * ★適用要件: 1週間における運行が全て一の運行 450km 以上の長距離輸送であり、
   *   かつその間の休息期間が運転者の住所地以外の場所となること。1週間に2回まで。
   *   16時間まで延長した場合は、一の運行終了後に継続12時間以上の休息期間が必要。
   *   要件充足の確認は運行計画側の責務であり、本関数は上限値のみを切り替える。
   */
  long_haul_lodging_special?: boolean;
}

/**
 * 改善基準告示 (令和6年4月1日適用) の1日単位の違反チェック (貨物自動車運送業)
 *
 *  - 拘束時間 : 原則13時間以内 / 上限15時間 (長距離特例時のみ16時間)
 *  - 休息期間 : 継続11時間以上に努める (努力義務) / 継続9時間が絶対的下限
 *  - 連続運転 : 4時間以内 (やむを得ない場合4時間30分まで)、中断は合計30分以上
 *  - 月次・年次の拘束時間は checkMonthlyAggregation / checkAnnualAggregation を使う
 */
export interface DriverComplianceResult {
  date: string;
  driver_id: string;
  violations: string[];
  warnings: string[];
  ok: boolean;
}

export function checkDriverCompliance(rec: DriverWorkRecord): DriverComplianceResult {
  const K = KAIZEN_KIJUN_KOKUJI;
  const violations: string[] = [];
  const warnings: string[] = [];
  const h = (min: number) => (min / 60).toFixed(1);
  const longHaul = rec.long_haul_lodging_special === true;

  // --- 1日の拘束時間 (第4条第1項第3号・第4号) ---
  // ★改正後の上限は15時間。16時間は「宿泊を伴う長距離貨物運送の特例」を
  //   適用する場合に限り、1週間に2回まで認められる値であり、既定の上限ではない。
  const bindingMax = longHaul ? K.daily_binding_long_haul_special_minutes : K.daily_binding_max_minutes;
  if (rec.binding_minutes > bindingMax) {
    violations.push(
      `1日拘束時間が上限${bindingMax / 60}時間を超過: ${h(rec.binding_minutes)}時間` +
      (longHaul ? ' (宿泊を伴う長距離貨物運送の特例適用中)' : ''),
    );
  } else if (longHaul && rec.binding_minutes > K.daily_binding_max_minutes) {
    warnings.push(
      `1日拘束時間が15時間超: ${h(rec.binding_minutes)}時間。` +
      '宿泊を伴う長距離貨物運送の特例 (1週間に2回まで/一の運行450km以上/住所地以外での休息) の' +
      '要件充足と、運行終了後の継続12時間以上の休息期間を確認してください。',
    );
  } else if (rec.binding_minutes > K.daily_binding_weekly_caution_minutes) {
    warnings.push(
      `1日拘束時間が原則13時間超: ${h(rec.binding_minutes)}時間。` +
      '14時間超は1週間で2回以内が目安とされています。',
    );
  } else if (rec.binding_minutes > K.daily_binding_principle_minutes) {
    warnings.push(`1日拘束時間が原則13時間超: ${h(rec.binding_minutes)}時間 (上限15時間)`);
  }

  // --- 1日の休息期間 (第4条第1項第5号 / 第4項第1号) ---
  if (rec.uses_split_rest) {
    // 分割休息の特例: 1回3時間以上、2分割で合計10時間以上 / 3分割で合計12時間以上
    const splitCount = rec.rest_split_count ?? 2;
    const requiredTotal =
      splitCount >= 3 ? K.split_rest_total_3_min_minutes : K.split_rest_total_2_min_minutes;
    if (rec.rest_minutes < requiredTotal) {
      violations.push(
        `分割休息の合計が不足: ${h(rec.rest_minutes)}時間 ` +
        `(${splitCount}分割は合計${requiredTotal / 60}時間以上が必要)`,
      );
    }
    if (splitCount > 3) {
      violations.push(`休息期間の分割は3分割までです (${splitCount}分割)`);
    }
    for (const piece of rec.rest_split_minutes ?? []) {
      if (piece < K.split_rest_each_min_minutes) {
        violations.push(`分割休息の1回が3時間未満: ${h(piece)}時間`);
        break;
      }
    }
    if (splitCount >= 3) {
      warnings.push('3分割となる日が連続しないよう努める必要があります。分割休息の日は1か月の勤務回数の2分の1が限度です。');
    }
  } else {
    const restMin = longHaul ? K.rest_long_haul_special_min_minutes : K.rest_absolute_min_minutes;
    if (rec.rest_minutes < restMin) {
      violations.push(
        `休息期間が継続${restMin / 60}時間を下回る: ${h(rec.rest_minutes)}時間` +
        (longHaul ? ' (宿泊を伴う長距離貨物運送の特例適用中)' : ''),
      );
    } else if (longHaul && rec.rest_minutes < K.rest_absolute_min_minutes) {
      warnings.push(
        `休息期間が継続9時間未満: ${h(rec.rest_minutes)}時間。` +
        '長距離特例 (1週間に2回まで) の要件と、運行終了後の継続12時間以上の休息期間を確認してください。',
      );
    } else if (rec.rest_minutes < K.rest_effort_min_minutes) {
      // 継続11時間は努力義務。9時間以上あれば告示違反ではないため警告に留める。
      warnings.push(
        `休息期間が継続11時間未満: ${h(rec.rest_minutes)}時間。` +
        '告示は継続11時間以上を与えるよう努めることを基本としています (絶対的下限は継続9時間)。',
      );
    }
  }

  // --- 連続運転時間 (第4条第1項第7号・第8号) ---
  if (rec.max_continuous_driving_minutes > K.continuous_driving_max_minutes) {
    violations.push(
      `連続運転時間が4時間30分超: ${h(rec.max_continuous_driving_minutes)}時間`,
    );
  } else if (rec.max_continuous_driving_minutes > K.continuous_driving_principle_minutes) {
    if (rec.break_minutes < K.driving_break_required_minutes) {
      violations.push('連続運転の中断 (合計30分以上の休憩) が不足しています');
    } else {
      warnings.push(
        `連続運転時間が原則4時間超: ${h(rec.max_continuous_driving_minutes)}時間。` +
        '4時間30分までの延長はSA・PA等に駐停車できない等やむを得ない場合に限られます。',
      );
    }
  }

  return {
    date: rec.date,
    driver_id: rec.driver_id,
    violations,
    warnings,
    ok: violations.length === 0,
  };
}

export interface BindingAggregationOptions {
  /**
   * 労使協定 (改善基準告示第4条第1項第1号ただし書・第2号ただし書) を締結しているか。
   * 締結時のみ 1か月310時間 / 1年3,400時間まで延長できる。
   * ★既定は false。協定がないのに例外値で判定すると、原則超過の違反を見逃す。
   */
  has_labor_agreement?: boolean;
}

export interface MonthlyBindingResult {
  total_binding_hours: number;
  total_driving_hours: number;
  /** 適用した1か月の拘束時間の上限 (284 または 310) */
  limit_hours: number;
  /** 原則284時間を超えているか (労使協定の有無に関わらず) */
  exceeds_principle: boolean;
  /** 適用上限を超えているか = 告示違反 */
  monthly_binding_violation: boolean;
  warnings: string[];
}

/**
 * 1か月の拘束時間の集計と判定 (改善基準告示 第4条第1項第2号)
 *
 *  - 原則 284時間以内
 *  - 労使協定を締結した場合に限り、年6か月までは 310時間まで延長可
 *    (ただし284時間を超える月が4か月連続することは認められない)
 *
 * ★旧実装は労使協定の有無を問わず 310時間のみで判定していたため、
 *   協定がない事業者の 300時間 (原則284時間超) を違反として検出できなかった。
 */
export function checkMonthlyAggregation(
  records: DriverWorkRecord[],
  opts: BindingAggregationOptions = {},
): MonthlyBindingResult {
  const K = KAIZEN_KIJUN_KOKUJI;
  const hasAgreement = opts.has_labor_agreement === true;
  const total_binding_minutes = records.reduce((s, r) => s + r.binding_minutes, 0);
  const total_driving_minutes = records.reduce((s, r) => s + r.driving_minutes, 0);
  const total_binding_hours = Math.round((total_binding_minutes / 60) * 10) / 10;
  const total_driving_hours = Math.round((total_driving_minutes / 60) * 10) / 10;

  const limit_hours = hasAgreement
    ? K.monthly_binding_agreement_hours
    : K.monthly_binding_principle_hours;
  const exceeds_principle = total_binding_hours > K.monthly_binding_principle_hours;
  const warnings: string[] = [];
  if (exceeds_principle && hasAgreement && total_binding_hours <= limit_hours) {
    warnings.push(
      `1か月の拘束時間が原則284時間を超えています (${total_binding_hours}時間)。` +
      '労使協定により310時間まで延長できるのは年6か月までです。' +
      'また284時間を超える月が4か月連続することは認められません。' +
      '1か月の時間外・休日労働時間数が100時間未満となるよう努めてください。',
    );
  }
  if (exceeds_principle && !hasAgreement) {
    warnings.push(
      '労使協定の締結が確認できないため原則284時間で判定しました。' +
      '協定を締結している場合は has_labor_agreement を指定してください。',
    );
  }

  return {
    total_binding_hours,
    total_driving_hours,
    limit_hours,
    exceeds_principle,
    monthly_binding_violation: total_binding_hours > limit_hours,
    warnings,
  };
}

export interface AnnualBindingResult {
  total_binding_hours: number;
  total_driving_hours: number;
  /** 適用した1年の拘束時間の上限 (3,300 または 3,400) */
  limit_hours: number;
  /** 原則3,300時間を超えているか */
  exceeds_principle: boolean;
  /** 適用上限を超えているか = 告示違反 */
  annual_binding_violation: boolean;
  warnings: string[];
}

/**
 * 1年の拘束時間の集計と判定 (改善基準告示 第4条第1項第1号)
 *
 *  - 原則 3,300時間以内
 *  - 労使協定を締結した場合に限り 3,400時間まで延長可
 *
 * ★旧実装では年間の上限判定が存在せず、月次関数の説明文に「年960時間」と
 *   書かれているだけで実装されていなかった (関数名だけの死配線)。
 *   なお年960時間は労働基準法上の「時間外労働」の上限であり、
 *   ここで扱う「拘束時間」とは別物なので混同しないこと。
 */
export function checkAnnualAggregation(
  records: DriverWorkRecord[],
  opts: BindingAggregationOptions = {},
): AnnualBindingResult {
  const K = KAIZEN_KIJUN_KOKUJI;
  const hasAgreement = opts.has_labor_agreement === true;
  const total_binding_minutes = records.reduce((s, r) => s + r.binding_minutes, 0);
  const total_driving_minutes = records.reduce((s, r) => s + r.driving_minutes, 0);
  const total_binding_hours = Math.round((total_binding_minutes / 60) * 10) / 10;
  const total_driving_hours = Math.round((total_driving_minutes / 60) * 10) / 10;

  const limit_hours = hasAgreement
    ? K.annual_binding_agreement_hours
    : K.annual_binding_principle_hours;
  const exceeds_principle = total_binding_hours > K.annual_binding_principle_hours;
  const warnings: string[] = [];
  if (exceeds_principle && hasAgreement && total_binding_hours <= limit_hours) {
    warnings.push(
      `1年の拘束時間が原則3,300時間を超えています (${total_binding_hours}時間)。` +
      '労使協定により3,400時間まで延長できますが、月284時間超は年6か月までである点も併せて確認してください。',
    );
  }
  if (exceeds_principle && !hasAgreement) {
    warnings.push(
      '労使協定の締結が確認できないため原則3,300時間で判定しました。' +
      '協定を締結している場合は has_labor_agreement を指定してください。',
    );
  }

  return {
    total_binding_hours,
    total_driving_hours,
    limit_hours,
    exceeds_principle,
    annual_binding_violation: total_binding_hours > limit_hours,
    warnings,
  };
}

// =============================================================================
// 運行管理者 (Operations Manager)
// =============================================================================

export type OperationsManagerKind = 'cargo' | 'passenger';

export interface OperationsManagerCertification {
  manager_id: string;
  name: string;
  kind: OperationsManagerKind;
  /** 国家試験合格番号 */
  certification_no: string;
  /** 講習受講日 (5年に1回) */
  last_training_date: string;
  /** 営業所名 (選任は営業所単位。必要人数は floor(両数/30)+1 — 輸送安全規則第18条第1項) */
  branch_name: string;
}

/**
 * 運行管理者の法定選任人数 = floor(事業用自動車の数 / 30) + 1
 *
 * 【出典 — 一次情報】貨物自動車運送事業輸送安全規則 (平成2年運輸省令第22号)
 *   第18条第1項 (運行管理者等の選任) — e-Gov 法令検索で原文確認
 *   https://laws.e-gov.go.jp/law/402M50000800022
 *
 *   「…当該営業所が運行を管理する事業用自動車の数を三十で除して得た数
 *     （その数に一未満の端数があるときは、これを切り捨てるものとする。）に
 *     一を加算して得た数以上の運行管理者を選任しなければならない。」
 *
 * ★「30両ごとに1名」= ceil(n/30) と読むのは誤り。法定式は floor(n/30) + 1 である。
 *   両者は【30の倍数のときだけ】食い違い、常に法定人数を1名下回る:
 *     29両 → ceil 1 / 法定 1 (一致)   ← ここだけ検査すると欠陥が素通りする
 *     30両 → ceil 1 / 法定 2 (不足)
 *     60両 → ceil 2 / 法定 3 (不足)
 *   選任数の不足は貨物自動車運送事業法上の行政処分の対象となるため、
 *   切り上げ方式へ戻してはならない。
 *
 * ★判定は【営業所ごと】。被けん引自動車は両数に算入しない (同項かっこ書き)。
 * ★同項ただし書き: 5両未満の事業用自動車を管理する営業所であって、地方運輸局長が
 *   運行の安全確保に支障を生ずるおそれがないと認めたものは選任を要しない。
 *   ただしこれは個別認定が前提であり、5両未満なら自動的に不要になるわけではないため、
 *   本関数は既定では認定なし (=選任必要) として法定人数を返す。
 * ★1営業所で複数名を選任する場合は統括運行管理者の選任も必要 (同条第2項)。
 *
 * @param vehicle_count 当該営業所が運行を管理する事業用自動車の数 (被けん引自動車を除く)
 */
export function getRequiredOperationsManagerCount(vehicle_count: number): number {
  if (vehicle_count <= 0) return 0;
  return Math.floor(vehicle_count / 30) + 1;
}

// =============================================================================
// 点呼 (Tenko)
// =============================================================================

export type TenkoKind = 'start' | 'end' | 'middle' | 'it_tenko';

export interface TenkoRecord {
  driver_id: string;
  manager_id: string;
  kind: TenkoKind;
  ts: string;
  /** アルコール検知器の測定値 (呼気 mg/L)。0 を超えれば「酒気を帯びた状態」= 乗務不可 */
  alcohol_mg_per_l: number;
  /** 健康状態確認 */
  health_check_passed: boolean;
  /** 車両点検確認 */
  vehicle_check_passed: boolean;
  remarks?: string;
}

/**
 * 点呼における酒気帯びの判定閾値 (mg/L)。
 *
 * 【出典 — 一次情報】
 *   (1) 貨物自動車運送事業輸送安全規則 第3条第5項 — e-Gov 法令検索で原文確認
 *       https://laws.e-gov.go.jp/law/402M50000800022
 *       「貨物自動車運送事業者は、酒気を帯びた状態にある乗務員等を
 *         事業用自動車の運行の業務に従事させてはならない。」
 *       → 条文に mg/L 等の数値基準は【存在しない】。
 *   (2) 国土交通省通達「貨物自動車運送事業輸送安全規則の解釈及び運用について」
 *       (平成15年3月10日 国自総第510号ほか) 第3条第5項関係
 *       https://www.mlit.go.jp/jidosha/anzen/03safety/resourse/data/construction_kamotsu.pdf
 *       「『酒気を帯びた状態』とは、道路交通法施行令第44条の3に規定する
 *         血液中のアルコール濃度0.3mg/mℓ又は呼気中のアルコール濃度0.15mg/ℓ以上で
 *         あるか否かを問わないものである。」
 *       → 監督官庁が明文で「0.15mg/L 以上か否かは問わない」と declare している。
 *
 * ★0.15mg/L は道路交通法施行令第44条の3が定める【酒気帯び運転の検挙基準】であり、
 *   運送事業の点呼基準ではない。これを点呼の合否閾値に流用すると、
 *   0.14mg/L の運転者を「乗務可」と判定して乗務させることになり、輸送安全規則違反
 *   (および事業者に対する行政処分) を実装が誘発する。検挙基準を業務基準に転用しないこと。
 *
 * ★したがって閾値は 0。検知器が微量でも検知したら乗務不可とする。
 */
export const TENKO_ALCOHOL_THRESHOLD_MG_PER_L = 0;

/**
 * 点呼の合否判定。
 *
 * 酒気帯びの有無・疾病/疲労等の有無・日常点検の実施を確認する
 * (輸送安全規則 第7条第1項各号)。酒気帯びの確認は目視等に加え、営業所に備えた
 * アルコール検知器を用いて行わなければならない (同条第4項)。
 *
 * ★アルコールは「検知されないこと」が条件であり、数値の大小比較で
 *   一定量までを許容してはならない (上記 TENKO_ALCOHOL_THRESHOLD_MG_PER_L の出典を参照)。
 *   NaN 等の不正な測定値は比較が false となり、安全側 (不合格) に倒れる。
 */
export function isTenkoPassed(rec: TenkoRecord): boolean {
  const alcoholClear = rec.alcohol_mg_per_l <= TENKO_ALCOHOL_THRESHOLD_MG_PER_L;
  return alcoholClear && rec.health_check_passed && rec.vehicle_check_passed;
}

// =============================================================================
// 標準的な運賃 (国交省告示 R6改訂)
// =============================================================================

/**
 * 標準的な運賃 = 距離制運賃 + 時間制運賃 + 待機時間料 + 高速料 + 燃料サーチャージ
 *
 * 簡易計算 (4t車 関東発の例):
 *   - 距離制: 100km まで 30,000円, 以降 km あたり 250円
 *   - 時間制: 1時間あたり 5,500円 (8時間まで)
 *   - 待機時間: 30 分超で 2,500円/30分
 */
export function calcStandardFreight(args: {
  vehicle_class: '2t' | '4t' | '10t' | '20t';
  distance_km: number;
  hours: number;
  waiting_minutes?: number;
  highway_fee?: number;
  fuel_surcharge_rate?: number; // 0.0〜0.2 程度
}): { distance_fee: number; time_fee: number; waiting_fee: number; highway_fee: number; fuel_surcharge: number; total: number } {
  const baseRate = { '2t': 1.0, '4t': 1.0, '10t': 1.4, '20t': 1.8 }[args.vehicle_class];
  const distance_fee =
    args.distance_km <= 100
      ? 30_000 * baseRate
      : (30_000 + (args.distance_km - 100) * 250) * baseRate;
  const time_fee = Math.min(args.hours, 8) * 5_500 * baseRate;
  const waiting_fee = args.waiting_minutes && args.waiting_minutes > 30
    ? Math.ceil((args.waiting_minutes - 30) / 30) * 2_500
    : 0;
  const highway_fee = args.highway_fee ?? 0;
  const fuel_surcharge = (distance_fee + time_fee) * (args.fuel_surcharge_rate ?? 0);
  const total = Math.floor(distance_fee + time_fee + waiting_fee + highway_fee + fuel_surcharge);
  return {
    distance_fee: Math.floor(distance_fee),
    time_fee: Math.floor(time_fee),
    waiting_fee,
    highway_fee,
    fuel_surcharge: Math.floor(fuel_surcharge),
    total,
  };
}

// =============================================================================
// 倉庫業法 (倉庫種別)
// =============================================================================

export const WAREHOUSE_CLASSES = [
  { class: '1類', desc: '通常品 (常温品全般)', requirements: ['防火壁', '防湿', '防鼠', '耐震', '床荷重'] },
  { class: '2類', desc: '燃えにくい品 (金属/陶磁器)', requirements: ['防湿', '防鼠'] },
  { class: '3類', desc: '燃えにくく湿気にも強い品 (鉱物)', requirements: ['防鼠'] },
  { class: '野積', desc: '原木/タイヤ/車両', requirements: ['周囲塀', '滅火設備'] },
  { class: '貯蔵槽', desc: '穀物/食用油 (タンク)', requirements: ['気密性', '害虫'] },
  { class: '危険品', desc: '消防法/高圧ガス保安法 危険物', requirements: ['消防適合', '保安距離', '避難計画'] },
  { class: '冷蔵', desc: '10℃以下', requirements: ['断熱', '冷却', '温度記録'] },
] as const;

// =============================================================================
// 配車最適化 (TSP/VRP の Greedy 最適化)
// =============================================================================

export interface DeliveryStop {
  stop_id: string;
  /** 緯度経度 (簡易距離計算用) */
  lat: number;
  lng: number;
  /** 配達指定時間帯 (開始) */
  window_start?: string;
  /** 配達指定時間帯 (終了) */
  window_end?: string;
  /** 重量 (kg) */
  weight_kg: number;
}

/**
 * Haversine 距離 (km)
 */
export function distanceKm(lat1: number, lng1: number, lat2: number, lng2: number): number {
  const R = 6371;
  const toRad = (d: number) => (d * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLng = toRad(lng2 - lng1);
  const a =
    Math.sin(dLat / 2) ** 2 +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLng / 2) ** 2;
  return 2 * R * Math.asin(Math.sqrt(a));
}

/**
 * Greedy Nearest Neighbor で配車順を決定 (簡易)
 *  - 始点から最も近い未訪問先を順次選択
 */
export function greedyTSP(
  startLat: number,
  startLng: number,
  stops: DeliveryStop[],
): DeliveryStop[] {
  const remaining = [...stops];
  const route: DeliveryStop[] = [];
  let curLat = startLat;
  let curLng = startLng;
  while (remaining.length > 0) {
    let bestIdx = 0;
    let bestDist = Infinity;
    for (let i = 0; i < remaining.length; i++) {
      const d = distanceKm(curLat, curLng, remaining[i].lat, remaining[i].lng);
      if (d < bestDist) {
        bestDist = d;
        bestIdx = i;
      }
    }
    const next = remaining.splice(bestIdx, 1)[0];
    route.push(next);
    curLat = next.lat;
    curLng = next.lng;
  }
  return route;
}

/**
 * 積載量超過チェック
 */
export function isOverloaded(stops: DeliveryStop[], vehicle_max_kg: number): boolean {
  const total = stops.reduce((s, x) => s + x.weight_kg, 0);
  return total > vehicle_max_kg;
}
