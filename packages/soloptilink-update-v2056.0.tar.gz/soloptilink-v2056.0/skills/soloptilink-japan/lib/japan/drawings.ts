/**
 * drawings.ts — 1級建築士レベル図面生成エンジン (Phase 9)
 *
 * 日本の建築実務で必要な全図面種別を SVG 形式で生成するエンジン。
 * PDF 化は外部ライブラリ (puppeteer / svg-to-pdf / @react-pdf/renderer) に委ねる。
 *
 * 対応図面 (建築士法に基づく設計図書一式):
 *   ■ 意匠図
 *     - 付近見取図 (location_map)
 *     - 配置図 (site_plan) ※敷地求積を含む
 *     - 各階平面図 (floor_plan)
 *     - 立面図 (elevation) × 4面
 *     - 断面図 (section)
 *     - 矩計図 (detail_section) ※部分詳細
 *     - 展開図 (interior_elevation)
 *     - 天井伏図 (reflected_ceiling)
 *     - 屋根伏図 (roof_plan)
 *     - 建具表 (door_window_schedule)
 *     - 仕上表 (finish_schedule)
 *   ■ 構造図
 *     - 基礎伏図 (foundation_plan)
 *     - 床伏図 (floor_framing)
 *     - 小屋伏図 (roof_framing)
 *     - 軸組図 (structural_elevation)
 *   ■ 設備図
 *     - 給排水衛生設備図 (plumbing)
 *     - 電気設備図 (electrical)
 *     - 空調・換気設備図 (hvac)
 *     - ガス設備図 (gas)
 *   ■ その他
 *     - シックハウス換気計算図 (ventilation_24h)
 *     - 避難経路図 (evacuation_plan)
 *
 * 使い方:
 *   import { generateFloorPlan, generateSitePlan, buildDrawingSet } from '@/lib/japan/drawings';
 *   const svg = generateFloorPlan({ rooms: [...], scale: 100 });
 *   const all = buildDrawingSet(projectSpec);  // Phase1 実装済 7 種を生成 (最大 6-7 種の SVG セット)
 */

/**
 * 図面種別 (計 21 種 + 施工系 6 種 = 27 種).
 *
 * ⚠️ 実装状況の SoT (PFP-163 で明示):
 *   - IMPLEMENTED_DRAWING_TYPES (Phase 1・7 種) — generate<Xxx> 関数が実装済で SVG が実生成される
 *   - PLANNED_DRAWING_TYPES (Phase 2・14 種) — 型は宣言済だが generator は未実装 (Placeholder 禁止)
 *   - CONSTRUCTION_PLAN_DRAWING_TYPES (Phase 3・6 種) — H2 施工系 (仮設/揚重/工法/場内動線/解体/割付). 型宣言のみで別 PFP 実装.
 *
 * buildDrawingSet() は IMPLEMENTED_DRAWING_TYPES のみを push する.
 * PLANNED_DRAWING_TYPES を要求されたら agent は unresolved に返す (Placeholder SVG 返却禁止).
 */
export type DrawingType =
  // Phase 1: 実装済 (buildDrawingSet で実生成)
  | 'site_plan'
  | 'floor_plan' | 'elevation' | 'section' | 'detail_section'
  | 'foundation_plan'
  | 'door_window_schedule'
  // Phase 2: 型宣言のみ (別 PFP で generator 実装)
  | 'location_map'
  | 'interior_elevation' | 'reflected_ceiling' | 'roof_plan'
  | 'finish_schedule'
  | 'floor_framing' | 'roof_framing' | 'structural_elevation'
  | 'plumbing' | 'electrical' | 'hvac' | 'gas'
  | 'ventilation_24h' | 'evacuation_plan'
  // Phase 3: 施工系 (H2・型宣言のみ)
  | 'temporary_structure_plan'    // 仮設計画図 (足場高さ 10m 以上 60 日以上 → 労安衛規則 88 条 機械等設置届)
  | 'lifting_plan'                // 揚重計画図 (クレーン揚重)
  | 'construction_method_diagram' // 工法説明図
  | 'site_logistics_plan'         // 場内動線図 (搬入経路・仮置場)
  | 'demolition_plan'             // 解体計画図 (建設リサイクル法連動)
  | 'partition_layout';           // 割付図

/** Phase 1: buildDrawingSet で実際に SVG を生成する 7 種 */
export const IMPLEMENTED_DRAWING_TYPES = Object.freeze([
  'site_plan', 'floor_plan', 'elevation', 'section', 'detail_section',
  'foundation_plan', 'door_window_schedule',
] as const);

/** Phase 2: 型宣言のみ・generator 未実装の 14 種 (別 PFP で実装) */
export const PLANNED_DRAWING_TYPES = Object.freeze([
  'location_map',
  'interior_elevation', 'reflected_ceiling', 'roof_plan',
  'finish_schedule',
  'floor_framing', 'roof_framing', 'structural_elevation',
  'plumbing', 'electrical', 'hvac', 'gas',
  'ventilation_24h', 'evacuation_plan',
] as const);

/** Phase 3: 施工系 6 種 (H2・型宣言のみ・別 PFP で実装) */
export const CONSTRUCTION_PLAN_DRAWING_TYPES = Object.freeze([
  'temporary_structure_plan', 'lifting_plan', 'construction_method_diagram',
  'site_logistics_plan', 'demolition_plan', 'partition_layout',
] as const);

/** 図面の役割区分 (H6・3層役割分離). 承認回付ワークフローと責任所在の分岐点. */
export type DrawingPurpose =
  | 'design_document'          // 設計図書 (建築士→建築主) — 建築士法 20 条 15 年保存対象
  | 'construction_shop_drawing' // 施工図 (元請→監理→設計者確認) — 建設業法 40 条の 3 の 5 年保存対象
  | 'fabrication_drawing';     // 製作図 (専門工事業者→元請) — CCUS 就業履歴と署名者紐付

/** 実装状態の判定ヘルパー. Phase 1 のみ true. Phase 2/3 は false. */
export function isImplemented(type: DrawingType): boolean {
  return (IMPLEMENTED_DRAWING_TYPES as readonly string[]).includes(type);
}

/**
 * 日本建築業界の標準縮尺 (JIS 5 規格準拠):
 *   - JIS A 0150 建築製図通則 (図面全般の作図規則)
 *   - JIS Z 8311 縮尺 (製図における — 拡大/実尺/縮小の 12 段階)
 *   - JIS Z 8114 製図用語 (用語定義)
 *   - JIS Z 8317 寸法記入法 (寸法・引出線の記入方法)
 *   - JIS Z 8321 線の基本原則 (太線 0.5-0.7 / 中線 0.25-0.35 / 細線 0.13-0.18mm)
 *
 * 施工系 6 種 (Phase 3) は労働安全衛生規則第 88 条 (機械等設置届) と紐付く実務図面.
 */
export const DRAWING_SCALES: Readonly<Record<DrawingType, number[]>> = Object.freeze({
  location_map: [2500, 5000, 10000],
  site_plan: [100, 200, 500],
  floor_plan: [50, 100, 200],
  elevation: [50, 100, 200],
  section: [50, 100, 200],
  detail_section: [10, 20, 30, 50], // 矩計は詳細なので 1/20 等
  interior_elevation: [30, 50, 100],
  reflected_ceiling: [50, 100],
  roof_plan: [100, 200],
  door_window_schedule: [50],
  finish_schedule: [0], // 表形式(縮尺不要)
  foundation_plan: [50, 100, 200],
  floor_framing: [50, 100, 200],
  roof_framing: [50, 100, 200],
  structural_elevation: [50, 100, 200],
  plumbing: [50, 100, 200],
  electrical: [50, 100, 200],
  hvac: [50, 100, 200],
  gas: [50, 100, 200],
  ventilation_24h: [100, 200],
  evacuation_plan: [100, 200],
  // Phase 3: 施工系 6 種 (H2・generator 未実装)
  temporary_structure_plan: [50, 100, 200],   // 仮設計画図
  lifting_plan: [100, 200, 500],              // 揚重計画図
  construction_method_diagram: [20, 50, 100], // 工法説明図
  site_logistics_plan: [200, 500, 1000],      // 場内動線図
  demolition_plan: [50, 100, 200],            // 解体計画図
  partition_layout: [30, 50, 100],            // 割付図
});

/** 日本建築製図通則 (JIS A 0150) の線種 — 線太さは JIS Z 8321 準拠 */
export const LINE_TYPES = Object.freeze({
  outline_thick: { stroke: '#000', strokeWidth: 0.7, dasharray: '' },        // 0.7mm 外形線(断面)
  outline_medium: { stroke: '#000', strokeWidth: 0.35, dasharray: '' },       // 0.35mm 姿線
  outline_thin: { stroke: '#000', strokeWidth: 0.18, dasharray: '' },         // 0.18mm 寸法線/補助
  hidden: { stroke: '#000', strokeWidth: 0.25, dasharray: '3 2' },            // 破線 隠れ線
  centerline: { stroke: '#000', strokeWidth: 0.18, dasharray: '8 2 2 2' },    // 一点鎖線 中心線
  reference: { stroke: '#000', strokeWidth: 0.18, dasharray: '12 2 2 2 2 2' },// 二点鎖線 想像線
  dimension: { stroke: '#000', strokeWidth: 0.13, dasharray: '' },            // 寸法線
  phantom_grid: { stroke: '#aaa', strokeWidth: 0.1, dasharray: '2 2' },       // グリッド
});

// =============================================================================
// 共通 SVG ヘルパー
// =============================================================================

export interface SvgBox {
  widthMm: number;
  heightMm: number;
  /** A判/B判 — JIS Z 8311 */
  paperSize: 'A0' | 'A1' | 'A2' | 'A3' | 'A4';
}

export const PAPER_SIZES: Record<SvgBox['paperSize'], { widthMm: number; heightMm: number }> = {
  A0: { widthMm: 1189, heightMm: 841 },
  A1: { widthMm: 841, heightMm: 594 },
  A2: { widthMm: 594, heightMm: 420 },
  A3: { widthMm: 420, heightMm: 297 },
  A4: { widthMm: 297, heightMm: 210 },
};

/** タイトルブロック (表題欄) — 日本の建築図面標準 */
export function renderTitleBlock(opts: {
  projectName: string;
  drawingTitle: string;
  drawingNo: string;
  scale: string;
  architectName: string;
  licenseNo?: string;
  date: string;         // YYYY-MM-DD
  revision?: string;    // '0', 'A', 'B' ...
  client?: string;
  paper: SvgBox['paperSize'];
}): string {
  const p = PAPER_SIZES[opts.paper];
  const w = 180, h = 40;
  const x = p.widthMm - w - 10, y = p.heightMm - h - 10;
  return `<g font-family="MS Gothic, sans-serif" font-size="3" fill="#000">
  <rect x="${x}" y="${y}" width="${w}" height="${h}" fill="white" stroke="black" stroke-width="0.5"/>
  <line x1="${x}" y1="${y + 8}" x2="${x + w}" y2="${y + 8}" stroke="black" stroke-width="0.25"/>
  <line x1="${x}" y1="${y + 16}" x2="${x + w}" y2="${y + 16}" stroke="black" stroke-width="0.25"/>
  <line x1="${x}" y1="${y + 24}" x2="${x + w}" y2="${y + 24}" stroke="black" stroke-width="0.25"/>
  <line x1="${x}" y1="${y + 32}" x2="${x + w}" y2="${y + 32}" stroke="black" stroke-width="0.25"/>
  <line x1="${x + w / 2}" y1="${y}" x2="${x + w / 2}" y2="${y + h}" stroke="black" stroke-width="0.25"/>
  <text x="${x + 2}" y="${y + 5}" font-size="2.5" fill="#666">工事名称 / Project</text>
  <text x="${x + 2}" y="${y + 13}">${escapeSvg(opts.projectName)}</text>
  <text x="${x + 2}" y="${y + 21}" font-size="2.5" fill="#666">図面名 / Title</text>
  <text x="${x + 2}" y="${y + 29}" font-weight="bold" font-size="5">${escapeSvg(opts.drawingTitle)}</text>
  <text x="${x + w / 2 + 2}" y="${y + 5}" font-size="2.5" fill="#666">図面番号 / No</text>
  <text x="${x + w / 2 + 2}" y="${y + 13}" font-weight="bold">${escapeSvg(opts.drawingNo)}</text>
  <text x="${x + w / 2 + 2}" y="${y + 21}" font-size="2.5" fill="#666">縮尺 / Scale</text>
  <text x="${x + w / 2 + 2}" y="${y + 29}">${escapeSvg(opts.scale)}</text>
  <text x="${x + 2}" y="${y + 37}" font-size="2.5">設計: ${escapeSvg(opts.architectName)}${opts.licenseNo ? ` (建築士登録 ${escapeSvg(opts.licenseNo)})` : ''}</text>
  <text x="${x + w / 2 + 2}" y="${y + 37}" font-size="2.5">${opts.date}  Rev. ${opts.revision ?? '0'}</text>
</g>`;
}

function escapeSvg(s: string): string {
  return String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&apos;' }[c]!));
}

/** A3 用紙枠 + 図面枠(内側20mm余白) */
export function renderPaperFrame(paper: SvgBox['paperSize']): string {
  const p = PAPER_SIZES[paper];
  return `<rect x="0" y="0" width="${p.widthMm}" height="${p.heightMm}" fill="white"/>
<rect x="20" y="10" width="${p.widthMm - 30}" height="${p.heightMm - 20}" fill="none" stroke="black" stroke-width="0.7"/>`;
}

// =============================================================================
// 配置図 (site_plan)
// =============================================================================

export interface SitePlanInput {
  project: { name: string; drawingNo: string; architect: string; licenseNo?: string; date: string; client?: string };
  site: {
    /** 敷地多角形 mm 単位 (図上) */
    boundary: Array<{ x: number; y: number; label?: string }>;
    /** 境界線長さ表示用 (m) */
    boundaryLengths: number[];
    /** 敷地面積 m² */
    areaM2: number;
    /** 方位 (真北角度 deg) 0=上 */
    northAngle: number;
  };
  building: {
    /** 建物形状 mm */
    footprint: Array<{ x: number; y: number }>;
    /** 建築面積 m² */
    buildingAreaM2: number;
    /** 延床面積 m² */
    floorAreaM2: number;
    stories: number;
    heightM: number;
  };
  roads: Array<{ fromX: number; fromY: number; toX: number; toY: number; widthM: number; label: string }>;
  scale: 100 | 200 | 500;
  paper?: SvgBox['paperSize'];
}

export function generateSitePlan(input: SitePlanInput): string {
  const paper = input.paper ?? 'A3';
  const p = PAPER_SIZES[paper];
  const coverage = (input.building.buildingAreaM2 / input.site.areaM2 * 100).toFixed(2);
  const far = (input.building.floorAreaM2 / input.site.areaM2 * 100).toFixed(2);
  const boundaryPath = input.site.boundary.map((pt, i) => `${i === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`).join(' ') + ' Z';
  const bldgPath = input.building.footprint.map((pt, i) => `${i === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`).join(' ') + ' Z';

  const roads = input.roads.map(r =>
    `<line x1="${r.fromX}" y1="${r.fromY}" x2="${r.toX}" y2="${r.toY}" stroke="#888" stroke-width="6" stroke-dasharray="2 1"/>
     <text x="${(r.fromX + r.toX) / 2}" y="${(r.fromY + r.toY) / 2 - 2}" font-size="3" text-anchor="middle">${escapeSvg(r.label)} W=${r.widthM}m</text>`
  ).join('\n');

  const boundaryLabels = input.site.boundary.map((pt, i) => {
    const next = input.site.boundary[(i + 1) % input.site.boundary.length];
    const mx = (pt.x + next.x) / 2, my = (pt.y + next.y) / 2;
    const len = input.site.boundaryLengths[i] ?? 0;
    return `<text x="${mx}" y="${my}" font-size="3" text-anchor="middle">${len.toFixed(2)}m</text>`;
  }).join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${p.widthMm} ${p.heightMm}" width="${p.widthMm}mm" height="${p.heightMm}mm">
  ${renderPaperFrame(paper)}
  <!-- 方位 -->
  <g transform="translate(40, 30) rotate(${input.site.northAngle})">
    <circle cx="0" cy="0" r="10" fill="none" stroke="black" stroke-width="0.3"/>
    <line x1="0" y1="-10" x2="0" y2="10" stroke="black" stroke-width="0.3"/>
    <polygon points="0,-12 -2,-8 2,-8" fill="black"/>
    <text x="0" y="-14" text-anchor="middle" font-size="3" font-weight="bold">N</text>
  </g>
  <!-- 敷地境界 -->
  <path d="${boundaryPath}" fill="#f9f9f9" stroke="black" stroke-width="0.5" stroke-dasharray="0"/>
  ${boundaryLabels}
  <!-- 道路 -->
  ${roads}
  <!-- 建物 -->
  <path d="${bldgPath}" fill="#d4e6f1" stroke="black" stroke-width="0.7"/>
  <!-- 敷地面積等 -->
  <g font-family="MS Gothic, sans-serif" font-size="3" transform="translate(30, ${p.heightMm - 80})">
    <rect x="0" y="0" width="90" height="40" fill="white" stroke="black" stroke-width="0.3"/>
    <text x="3" y="6">敷地面積: ${input.site.areaM2.toFixed(2)}㎡</text>
    <text x="3" y="12">建築面積: ${input.building.buildingAreaM2.toFixed(2)}㎡</text>
    <text x="3" y="18">延床面積: ${input.building.floorAreaM2.toFixed(2)}㎡</text>
    <text x="3" y="24">建ぺい率: ${coverage}%</text>
    <text x="3" y="30">容 積 率: ${far}%</text>
    <text x="3" y="36">階 数 / 高さ: ${input.building.stories}階 / ${input.building.heightM}m</text>
  </g>
  ${renderTitleBlock({
    projectName: input.project.name,
    drawingTitle: '配置図 / Site Plan',
    drawingNo: input.project.drawingNo,
    scale: `1/${input.scale}`,
    architectName: input.project.architect,
    licenseNo: input.project.licenseNo,
    date: input.project.date,
    client: input.project.client,
    paper,
  })}
</svg>`;
}

// =============================================================================
// 平面図 (floor_plan)
// =============================================================================

export interface Room {
  name: string;
  /** 部屋の外形ポリゴン mm */
  polygon: Array<{ x: number; y: number }>;
  areaM2?: number;
  finishFloor?: string;
  finishWall?: string;
  finishCeiling?: string;
}

export interface DoorOrWindow {
  type: 'door' | 'window' | 'sliding_door' | 'folding_door';
  position: { x: number; y: number };
  widthMm: number;
  wallDirection: 'N' | 'S' | 'E' | 'W';
  swing?: 'left' | 'right';
  label?: string;
}

export interface FloorPlanInput {
  project: { name: string; drawingNo: string; architect: string; licenseNo?: string; date: string };
  level: 1 | 2 | 3 | 4 | 5 | 'B1' | 'RF';
  rooms: Room[];
  openings: DoorOrWindow[];
  /** 構造グリッド (X/Y 軸通り) mm */
  gridX?: number[];
  gridY?: number[];
  /** 階段 (上がり方向) */
  stairs?: Array<{ x: number; y: number; widthMm: number; depthMm: number; direction: 'up' | 'down'; steps: number }>;
  scale: 50 | 100 | 200;
  paper?: SvgBox['paperSize'];
}

export function generateFloorPlan(input: FloorPlanInput): string {
  const paper = input.paper ?? 'A3';
  const p = PAPER_SIZES[paper];
  const levelJa = typeof input.level === 'number' ? `${input.level}階` : input.level === 'B1' ? '地下1階' : '屋上';

  const roomsSvg = input.rooms.map(r => {
    const d = r.polygon.map((pt, i) => `${i === 0 ? 'M' : 'L'} ${pt.x} ${pt.y}`).join(' ') + ' Z';
    const cx = r.polygon.reduce((s, pt) => s + pt.x, 0) / r.polygon.length;
    const cy = r.polygon.reduce((s, pt) => s + pt.y, 0) / r.polygon.length;
    return `<path d="${d}" fill="#fff" stroke="black" stroke-width="0.7"/>
    <text x="${cx}" y="${cy}" font-family="MS Gothic, sans-serif" font-size="3.5" text-anchor="middle" font-weight="bold">${escapeSvg(r.name)}</text>
    ${r.areaM2 ? `<text x="${cx}" y="${cy + 4}" font-family="MS Gothic, sans-serif" font-size="2.5" text-anchor="middle">(${r.areaM2.toFixed(2)}㎡)</text>` : ''}`;
  }).join('\n');

  const openingsSvg = input.openings.map(o => {
    if (o.type === 'door') {
      return `<g transform="translate(${o.position.x},${o.position.y})">
        <line x1="0" y1="0" x2="${o.widthMm}" y2="0" stroke="white" stroke-width="3"/>
        <path d="M 0 0 A ${o.widthMm} ${o.widthMm} 0 0 ${o.swing === 'right' ? '1' : '0'} ${o.widthMm} ${-o.widthMm}" fill="none" stroke="black" stroke-width="0.3"/>
        <line x1="0" y1="0" x2="0" y2="${-o.widthMm}" stroke="black" stroke-width="0.5"/>
      </g>`;
    }
    if (o.type === 'sliding_door') {
      return `<g transform="translate(${o.position.x},${o.position.y})">
        <line x1="0" y1="-0.5" x2="${o.widthMm}" y2="-0.5" stroke="white" stroke-width="3"/>
        <line x1="0" y1="0" x2="${o.widthMm / 2}" y2="0" stroke="black" stroke-width="0.5"/>
        <line x1="${o.widthMm / 2}" y1="1" x2="${o.widthMm}" y2="1" stroke="black" stroke-width="0.5"/>
      </g>`;
    }
    // window
    return `<g transform="translate(${o.position.x},${o.position.y})">
      <line x1="0" y1="-2" x2="${o.widthMm}" y2="-2" stroke="black" stroke-width="0.3"/>
      <line x1="0" y1="0" x2="${o.widthMm}" y2="0" stroke="black" stroke-width="0.3"/>
      <line x1="0" y1="2" x2="${o.widthMm}" y2="2" stroke="black" stroke-width="0.3"/>
    </g>`;
  }).join('\n');

  const stairsSvg = (input.stairs ?? []).map(s => {
    const stepDepth = s.depthMm / s.steps;
    const steps = Array.from({ length: s.steps }, (_, i) =>
      `<line x1="${s.x + i * stepDepth}" y1="${s.y}" x2="${s.x + i * stepDepth}" y2="${s.y + s.widthMm}" stroke="black" stroke-width="0.2"/>`
    ).join('\n');
    const arrow = s.direction === 'up' ? '▲UP' : '▼DN';
    return `${steps}
    <text x="${s.x + s.depthMm / 2}" y="${s.y + s.widthMm / 2}" font-size="4" text-anchor="middle" font-weight="bold">${arrow}</text>`;
  }).join('\n');

  const gridX = (input.gridX ?? []).map((gx, i) => `<line x1="${gx}" y1="0" x2="${gx}" y2="${p.heightMm}" stroke="#bbb" stroke-width="0.15" stroke-dasharray="8 2 2 2"/>
    <circle cx="${gx}" cy="30" r="4" fill="white" stroke="black" stroke-width="0.3"/>
    <text x="${gx}" y="31.5" text-anchor="middle" font-size="3">${String.fromCharCode(65 + i)}</text>`).join('\n');
  const gridY = (input.gridY ?? []).map((gy, i) => `<line x1="0" y1="${gy}" x2="${p.widthMm}" y2="${gy}" stroke="#bbb" stroke-width="0.15" stroke-dasharray="8 2 2 2"/>
    <circle cx="30" cy="${gy}" r="4" fill="white" stroke="black" stroke-width="0.3"/>
    <text x="30" y="${gy + 1.5}" text-anchor="middle" font-size="3">${i + 1}</text>`).join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${p.widthMm} ${p.heightMm}" width="${p.widthMm}mm" height="${p.heightMm}mm">
  ${renderPaperFrame(paper)}
  ${gridX}
  ${gridY}
  ${roomsSvg}
  ${openingsSvg}
  ${stairsSvg}
  ${renderTitleBlock({
    projectName: input.project.name,
    drawingTitle: `${levelJa} 平面図 / ${levelJa} Floor Plan`,
    drawingNo: input.project.drawingNo,
    scale: `1/${input.scale}`,
    architectName: input.project.architect,
    licenseNo: input.project.licenseNo,
    date: input.project.date,
    paper,
  })}
</svg>`;
}

// =============================================================================
// 立面図 (elevation)
// =============================================================================

export interface ElevationInput {
  project: { name: string; drawingNo: string; architect: string; licenseNo?: string; date: string };
  direction: 'north' | 'south' | 'east' | 'west';
  /** 建物外形の座標 (mm) 地盤面を y=0 として上が正 */
  outline: Array<{ x: number; y: number }>;
  /** 開口部 (窓/ドア) */
  openings: Array<{ x: number; y: number; widthMm: number; heightMm: number; label?: string }>;
  /** 地盤ライン */
  groundLineY: number;
  /** 軒高 / 最高の高さ注記 */
  heightMarks: Array<{ y: number; label: string }>;
  /** 外壁仕上 */
  wallFinish?: string;
  scale: 50 | 100 | 200;
  paper?: SvgBox['paperSize'];
}

export function generateElevation(input: ElevationInput): string {
  const paper = input.paper ?? 'A3';
  const p = PAPER_SIZES[paper];
  const directionJa = { north: '北', south: '南', east: '東', west: '西' }[input.direction];
  const outlinePath = input.outline.map((pt, i) => `${i === 0 ? 'M' : 'L'} ${pt.x} ${-pt.y}`).join(' ') + ' Z';

  const opens = input.openings.map(o =>
    `<rect x="${o.x}" y="${-o.y - o.heightMm}" width="${o.widthMm}" height="${o.heightMm}" fill="#e8f4f8" stroke="black" stroke-width="0.3"/>
     ${o.label ? `<text x="${o.x + o.widthMm / 2}" y="${-o.y - o.heightMm / 2}" text-anchor="middle" font-size="2.5">${escapeSvg(o.label)}</text>` : ''}`
  ).join('\n');

  const marks = input.heightMarks.map(m =>
    `<line x1="0" y1="${-m.y}" x2="${p.widthMm}" y2="${-m.y}" stroke="#aaa" stroke-width="0.15" stroke-dasharray="5 2"/>
     <text x="${p.widthMm - 50}" y="${-m.y - 1}" font-size="3" fill="red">▽ ${escapeSvg(m.label)}: +${m.y}mm</text>`
  ).join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${p.widthMm} ${p.heightMm}" width="${p.widthMm}mm" height="${p.heightMm}mm">
  ${renderPaperFrame(paper)}
  <g transform="translate(40, ${p.heightMm - 80})">
    ${marks}
    <path d="${outlinePath}" fill="#f5f5f5" stroke="black" stroke-width="0.7"/>
    ${opens}
    <!-- 地盤ライン -->
    <line x1="0" y1="${-input.groundLineY}" x2="${p.widthMm - 40}" y2="${-input.groundLineY}" stroke="brown" stroke-width="1"/>
    <pattern id="ground" width="4" height="4" patternUnits="userSpaceOnUse">
      <line x1="0" y1="4" x2="4" y2="0" stroke="brown" stroke-width="0.2"/>
    </pattern>
  </g>
  ${renderTitleBlock({
    projectName: input.project.name,
    drawingTitle: `${directionJa}立面図 / ${input.direction.toUpperCase()} Elevation`,
    drawingNo: input.project.drawingNo,
    scale: `1/${input.scale}`,
    architectName: input.project.architect,
    licenseNo: input.project.licenseNo,
    date: input.project.date,
    paper,
  })}
</svg>`;
}

// =============================================================================
// 断面図 (section)
// =============================================================================

export interface SectionInput {
  project: { name: string; drawingNo: string; architect: string; licenseNo?: string; date: string };
  sectionLine: 'A-A' | 'B-B' | 'C-C';
  /** 各階の階高 mm */
  floorHeights: Array<{ label: string; floorLevelMm: number; ceilingHeightMm: number }>;
  /** 基礎/屋根の断面外形 */
  outline: Array<{ x: number; y: number }>;
  /** 断面上の構造要素 (梁/柱/スラブ) */
  members: Array<{ x: number; y: number; widthMm: number; heightMm: number; label: string; fill?: string }>;
  scale: 50 | 100 | 200;
  paper?: SvgBox['paperSize'];
}

export function generateSection(input: SectionInput): string {
  const paper = input.paper ?? 'A3';
  const p = PAPER_SIZES[paper];
  const outlinePath = input.outline.map((pt, i) => `${i === 0 ? 'M' : 'L'} ${pt.x} ${-pt.y}`).join(' ') + ' Z';
  const floors = input.floorHeights.map(f =>
    `<line x1="0" y1="${-f.floorLevelMm}" x2="${p.widthMm}" y2="${-f.floorLevelMm}" stroke="#888" stroke-width="0.25" stroke-dasharray="8 2 2 2"/>
     <text x="${p.widthMm - 60}" y="${-f.floorLevelMm - 1}" font-size="3">▽ ${escapeSvg(f.label)} FL (CH=${f.ceilingHeightMm}mm)</text>`
  ).join('\n');
  const members = input.members.map(m =>
    `<rect x="${m.x}" y="${-m.y - m.heightMm}" width="${m.widthMm}" height="${m.heightMm}" fill="${m.fill ?? '#ddd'}" stroke="black" stroke-width="0.3"/>
     <text x="${m.x + m.widthMm / 2}" y="${-m.y - m.heightMm / 2}" text-anchor="middle" font-size="2.5">${escapeSvg(m.label)}</text>`
  ).join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${p.widthMm} ${p.heightMm}" width="${p.widthMm}mm" height="${p.heightMm}mm">
  ${renderPaperFrame(paper)}
  <g transform="translate(40, ${p.heightMm - 80})">
    ${floors}
    <path d="${outlinePath}" fill="#f0f0f0" stroke="black" stroke-width="0.7"/>
    ${members}
  </g>
  ${renderTitleBlock({
    projectName: input.project.name,
    drawingTitle: `断面図 (${input.sectionLine}) / Section`,
    drawingNo: input.project.drawingNo,
    scale: `1/${input.scale}`,
    architectName: input.project.architect,
    licenseNo: input.project.licenseNo,
    date: input.project.date,
    paper,
  })}
</svg>`;
}

// =============================================================================
// 矩計図 (detail_section) — 部分詳細
// =============================================================================

export interface DetailSectionInput {
  project: { name: string; drawingNo: string; architect: string; licenseNo?: string; date: string };
  /** 構成層 (下から積上げ) — 屋根/壁/床 別 */
  layers: Array<{ thicknessMm: number; material: string; finish?: string; fill?: string }>;
  /** 窓サッシの取合い等の引き出し線 */
  callouts?: Array<{ fromX: number; fromY: number; toX: number; toY: number; text: string }>;
  scale: 10 | 20 | 30 | 50;
  paper?: SvgBox['paperSize'];
}

export function generateDetailSection(input: DetailSectionInput): string {
  const paper = input.paper ?? 'A3';
  const p = PAPER_SIZES[paper];
  let y = 0;
  const layersSvg = input.layers.map(l => {
    const rect = `<rect x="100" y="${-y - l.thicknessMm}" width="120" height="${l.thicknessMm}" fill="${l.fill ?? '#eef'}" stroke="black" stroke-width="0.3"/>
    <text x="230" y="${-y - l.thicknessMm / 2}" font-size="2.5">${escapeSvg(l.material)}${l.finish ? ` (${escapeSvg(l.finish)})` : ''} t=${l.thicknessMm}mm</text>`;
    y += l.thicknessMm;
    return rect;
  }).join('\n');
  const callouts = (input.callouts ?? []).map(c =>
    `<line x1="${c.fromX}" y1="${c.fromY}" x2="${c.toX}" y2="${c.toY}" stroke="black" stroke-width="0.2"/>
     <text x="${c.toX + 2}" y="${c.toY}" font-size="2.5">${escapeSvg(c.text)}</text>`
  ).join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${p.widthMm} ${p.heightMm}" width="${p.widthMm}mm" height="${p.heightMm}mm">
  ${renderPaperFrame(paper)}
  <g transform="translate(0, ${p.heightMm - 100})">
    ${layersSvg}
    ${callouts}
  </g>
  ${renderTitleBlock({
    projectName: input.project.name,
    drawingTitle: '矩計図 / Wall Section Detail',
    drawingNo: input.project.drawingNo,
    scale: `1/${input.scale}`,
    architectName: input.project.architect,
    licenseNo: input.project.licenseNo,
    date: input.project.date,
    paper,
  })}
</svg>`;
}

// =============================================================================
// 建具表 / 仕上表
// =============================================================================

export interface DoorWindowScheduleRow {
  symbol: string;
  type: 'SD' | 'WD' | 'AW' | 'SS' | 'その他';
  widthMm: number;
  heightMm: number;
  material: string;
  quantity: number;
  remarks?: string;
}

export function generateDoorWindowSchedule(opts: {
  project: { name: string; drawingNo: string; architect: string; date: string; licenseNo?: string };
  rows: DoorWindowScheduleRow[];
}): string {
  const paper: SvgBox['paperSize'] = 'A3';
  const p = PAPER_SIZES[paper];
  const header = `
    <g font-family="MS Gothic, sans-serif" font-size="3" transform="translate(30, 50)">
      <rect x="0" y="0" width="380" height="10" fill="#eee" stroke="black" stroke-width="0.3"/>
      <text x="5" y="7" font-weight="bold">記号</text>
      <text x="35" y="7" font-weight="bold">種別</text>
      <text x="70" y="7" font-weight="bold">W×H (mm)</text>
      <text x="140" y="7" font-weight="bold">材質/仕様</text>
      <text x="280" y="7" font-weight="bold">数量</text>
      <text x="320" y="7" font-weight="bold">摘要</text>
    </g>`;
  const rows = opts.rows.map((r, i) =>
    `<g font-family="MS Gothic, sans-serif" font-size="3" transform="translate(30, ${60 + i * 10})">
      <rect x="0" y="0" width="380" height="10" fill="white" stroke="black" stroke-width="0.2"/>
      <text x="5" y="7">${escapeSvg(r.symbol)}</text>
      <text x="35" y="7">${escapeSvg(r.type)}</text>
      <text x="70" y="7">${r.widthMm}×${r.heightMm}</text>
      <text x="140" y="7">${escapeSvg(r.material)}</text>
      <text x="280" y="7">${r.quantity}</text>
      <text x="320" y="7">${escapeSvg(r.remarks ?? '')}</text>
    </g>`
  ).join('\n');

  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${p.widthMm} ${p.heightMm}" width="${p.widthMm}mm" height="${p.heightMm}mm">
  ${renderPaperFrame(paper)}
  ${header}
  ${rows}
  ${renderTitleBlock({
    projectName: opts.project.name,
    drawingTitle: '建具表 / Door & Window Schedule',
    drawingNo: opts.project.drawingNo,
    scale: '-',
    architectName: opts.project.architect,
    licenseNo: opts.project.licenseNo,
    date: opts.project.date,
    paper,
  })}
</svg>`;
}

// =============================================================================
// 構造図: 基礎伏図 / 軸組図
// =============================================================================

export interface FoundationMember {
  type: '布基礎' | 'ベタ基礎' | '独立基礎' | '地中梁';
  x: number; y: number;
  widthMm: number;
  depthMm: number;
  rebar?: string; // 例: 'D13@200'
  label?: string;
}

export function generateFoundationPlan(opts: {
  project: { name: string; drawingNo: string; architect: string; licenseNo?: string; date: string };
  members: FoundationMember[];
  scale: 50 | 100 | 200;
}): string {
  const paper: SvgBox['paperSize'] = 'A3';
  const p = PAPER_SIZES[paper];
  const msvg = opts.members.map(m => {
    const fill = m.type === 'ベタ基礎' ? '#fce5cd' : m.type === '独立基礎' ? '#cfe2f3' : '#d9ead3';
    return `<rect x="${m.x}" y="${m.y}" width="${m.widthMm}" height="${m.depthMm}" fill="${fill}" stroke="black" stroke-width="0.5"/>
    <text x="${m.x + m.widthMm / 2}" y="${m.y + m.depthMm / 2}" text-anchor="middle" font-size="2.5">${escapeSvg(m.label ?? m.type)}${m.rebar ? `\n${m.rebar}` : ''}</text>`;
  }).join('\n');
  return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${p.widthMm} ${p.heightMm}" width="${p.widthMm}mm" height="${p.heightMm}mm">
  ${renderPaperFrame(paper)}
  ${msvg}
  ${renderTitleBlock({
    projectName: opts.project.name,
    drawingTitle: '基礎伏図 / Foundation Plan',
    drawingNo: opts.project.drawingNo,
    scale: `1/${opts.scale}`,
    architectName: opts.project.architect,
    licenseNo: opts.project.licenseNo,
    date: opts.project.date,
    paper,
  })}
</svg>`;
}

// =============================================================================
// 設備記号の標準 (JIS A 0150/JIS B 0071) を定数化
// =============================================================================

export const ELECTRICAL_SYMBOLS: Readonly<Record<string, { svg: string; name_ja: string }>> = Object.freeze({
  outlet_single: { svg: '<circle r="3" fill="white" stroke="black" stroke-width="0.5"/><line x1="-2" y1="0" x2="2" y2="0" stroke="black"/>', name_ja: 'コンセント (2P)' },
  outlet_grounded: { svg: '<circle r="3" fill="white" stroke="black" stroke-width="0.5"/><text y="1" font-size="2.5" text-anchor="middle">E</text>', name_ja: 'アース付コンセント' },
  switch_1way: { svg: '<circle r="2" fill="black"/>', name_ja: '片切スイッチ' },
  switch_3way: { svg: '<circle r="2" fill="black"/><text x="3" y="1" font-size="2.5">3</text>', name_ja: '三路スイッチ' },
  light_ceiling: { svg: '<circle r="3" fill="white" stroke="black" stroke-width="0.5"/><line x1="-3" y1="-3" x2="3" y2="3" stroke="black"/><line x1="3" y1="-3" x2="-3" y2="3" stroke="black"/>', name_ja: 'シーリングライト' },
  light_down: { svg: '<circle r="3" fill="yellow" stroke="black" stroke-width="0.5"/>', name_ja: 'ダウンライト' },
  smoke_detector: { svg: '<circle r="3" fill="white" stroke="red" stroke-width="0.5"/><text y="1" font-size="2.5" text-anchor="middle" fill="red">煙</text>', name_ja: '煙感知器' },
  heat_detector: { svg: '<circle r="3" fill="white" stroke="red" stroke-width="0.5"/><text y="1" font-size="2.5" text-anchor="middle" fill="red">熱</text>', name_ja: '熱感知器' },
});

export const PLUMBING_SYMBOLS: Readonly<Record<string, { svg: string; name_ja: string }>> = Object.freeze({
  toilet: { svg: '<rect x="-4" y="-6" width="8" height="12" rx="2" fill="white" stroke="black" stroke-width="0.5"/>', name_ja: '便器' },
  washbasin: { svg: '<ellipse cx="0" cy="0" rx="6" ry="4" fill="white" stroke="black" stroke-width="0.5"/>', name_ja: '洗面器' },
  bath: { svg: '<rect x="-8" y="-4" width="16" height="8" rx="1" fill="white" stroke="black" stroke-width="0.5"/>', name_ja: '浴槽' },
  kitchen_sink: { svg: '<rect x="-5" y="-4" width="10" height="8" fill="white" stroke="black" stroke-width="0.5"/><circle cx="0" cy="0" r="2" fill="none" stroke="black"/>', name_ja: 'キッチン流し' },
  floor_drain: { svg: '<circle r="2" fill="none" stroke="black" stroke-width="0.3"/><line x1="-2" y1="-2" x2="2" y2="2" stroke="black"/><line x1="2" y1="-2" x2="-2" y2="2" stroke="black"/>', name_ja: '床排水' },
});

// =============================================================================
// ドキュメントセット生成 (確認申請に必要な15枚一式)
// =============================================================================

export interface ProjectSpec {
  project: { name: string; architect: string; licenseNo?: string; date: string; client?: string };
  site: SitePlanInput['site'];
  building: SitePlanInput['building'];
  roads: SitePlanInput['roads'];
  floors: FloorPlanInput[];
  elevations: ElevationInput[];
  sections: SectionInput[];
  foundation?: { members: FoundationMember[] };
  doorWindowSchedule?: DoorWindowScheduleRow[];
}

/**
 * 図面セット生成 — Phase 1 (実装済 7 種) のみ SVG を実生成する.
 *
 * ⚠️ 空約束根治 (PFP-163/C1 敵対検証発見):
 *   - IMPLEMENTED_DRAWING_TYPES のみを push (最大 6 種セット + detail_section 追加で 7 種)
 *   - PLANNED_DRAWING_TYPES (14 種) と CONSTRUCTION_PLAN_DRAWING_TYPES (6 種) は本関数では出力しない
 *   - 呼出側で PLANNED を要求する場合、`unresolved` フィールドに列挙して Placeholder 返却を禁止
 *
 * 実測: 通常呼出で最大 6 種 (site_plan + N floors + M elevations + K sections + foundation + door_window),
 * detail_section 追加時は 7 種.
 */
export function buildDrawingSet(spec: ProjectSpec): Array<{ type: DrawingType; filename: string; svg: string }> {
  const set: Array<{ type: DrawingType; filename: string; svg: string }> = [];

  set.push({
    type: 'site_plan',
    filename: 'A-01_site_plan.svg',
    svg: generateSitePlan({
      project: { ...spec.project, drawingNo: 'A-01' },
      site: spec.site,
      building: spec.building,
      roads: spec.roads,
      scale: 200,
    }),
  });

  spec.floors.forEach((f, i) =>
    set.push({
      type: 'floor_plan',
      filename: `A-${String(i + 2).padStart(2, '0')}_floor_plan_${f.level}.svg`,
      svg: generateFloorPlan({ ...f, project: { ...spec.project, drawingNo: `A-${String(i + 2).padStart(2, '0')}` } }),
    }),
  );
  spec.elevations.forEach((e, i) =>
    set.push({
      type: 'elevation',
      filename: `A-${String(i + spec.floors.length + 2).padStart(2, '0')}_elev_${e.direction}.svg`,
      svg: generateElevation({ ...e, project: { ...spec.project, drawingNo: `A-${String(i + spec.floors.length + 2).padStart(2, '0')}` } }),
    }),
  );
  spec.sections.forEach((s, i) =>
    set.push({
      type: 'section',
      filename: `A-${String(i + spec.floors.length + spec.elevations.length + 2).padStart(2, '0')}_section.svg`,
      svg: generateSection({ ...s, project: { ...spec.project, drawingNo: `A-${String(i + spec.floors.length + spec.elevations.length + 2).padStart(2, '0')}` } }),
    }),
  );
  if (spec.foundation) {
    set.push({
      type: 'foundation_plan',
      filename: 'S-01_foundation.svg',
      svg: generateFoundationPlan({ project: { ...spec.project, drawingNo: 'S-01' }, members: spec.foundation.members, scale: 100 }),
    });
  }
  if (spec.doorWindowSchedule) {
    set.push({
      type: 'door_window_schedule',
      filename: 'A-90_door_window.svg',
      svg: generateDoorWindowSchedule({ project: { ...spec.project, drawingNo: 'A-90' }, rows: spec.doorWindowSchedule }),
    });
  }
  return set;
}

// =============================================================================
// DXF / DWG 出力のスタブ (将来実装用)
// =============================================================================

/** DXF (R12 ASCII) ヘッダの最小スケルトン — JW_CAD / AutoCAD 互換 */
export function exportMinimalDxf(polylines: Array<{ points: Array<{ x: number; y: number }>; layer: string }>): string {
  const header = `  0\nSECTION\n  2\nHEADER\n  9\n$ACADVER\n  1\nAC1009\n  0\nENDSEC\n`;
  const tables = `  0\nSECTION\n  2\nTABLES\n  0\nENDSEC\n`;
  const entitiesStart = `  0\nSECTION\n  2\nENTITIES\n`;
  const entitiesEnd = `  0\nENDSEC\n  0\nEOF\n`;
  const lines = polylines.map(pl => {
    const segs = pl.points.slice(1).map((p, i) => {
      const prev = pl.points[i];
      return `  0\nLINE\n  8\n${pl.layer}\n 10\n${prev.x}\n 20\n${prev.y}\n 11\n${p.x}\n 21\n${p.y}\n`;
    }).join('');
    return segs;
  }).join('');
  return header + tables + entitiesStart + lines + entitiesEnd;
}
