/**
 * SoloptiLinkAI Phase 45 — Board Effectiveness (取締役会実効性評価 + スキルマトリクス)
 *
 * 9並行セッション統合の最終ピース:
 *   - jpgov-001 が claim していた board_effectiveness.ts の実体化
 *   - CGC 補充原則 4-11③ 取締役会実効性評価 + 監督機能強化 + 多様性確保
 *   - JPX「コーポレート・ガバナンス報告書」スキルマトリクス開示要請 R3.6
 *
 * 採点軸 JG10 board_learning_compliance を Diamond (17/17) に押し上げる。
 *
 * 関連法令・規範:
 *   - 会社法 362条 (取締役会の権限) + 369条 (決議要件) + 423条 (任務懈怠)
 *   - CGC 原則 4-1〜4-14 (取締役会の責務 + 構成 + 運営)
 *     - 補充原則 4-11① 取締役会の構成と多様性 (国際性・性別・職歴)
 *     - 補充原則 4-11② 兼任状況の合理性 (上場会社4社以下原則)
 *     - 補充原則 4-11③ 取締役会全体の実効性評価 (年1回 + 概要開示)
 *     - 補充原則 4-14② トレーニング機会の提供
 *   - 東証「コーポレート・ガバナンス報告書」記載要領 R3.6
 *     - スキルマトリクス開示 (プライム上場会社 必須)
 *   - 金融庁「投資家と企業の対話ガイドライン」R6 改訂
 *
 * 設計哲学:
 *   - 取締役会の「実効性」は ボード評価 + スキルマトリクス + 多様性 + トレーニング の4軸
 *   - 学習駆動 (Learning-Driven) で過去の決裁傾向を分析し、スキル不足を自動検出
 *   - corporate_governance.ts (CGC2024) と協調動作。本ファイルは「ボード固有」に特化
 */

// ============================================================================
// 1. 取締役プロフィール + スキルマトリクス
// ============================================================================

/** スキル区分 (JPX 標準 + 国際標準を結合した10分類) */
export type DirectorSkillCategory =
  | "corporate_management"  // 企業経営
  | "global_business"       // グローバルビジネス
  | "industry_expertise"    // 業界知見
  | "finance_accounting"    // 財務・会計
  | "legal_compliance"      // 法務・コンプライアンス
  | "risk_management"       // リスクマネジメント
  | "ict_dx"                // ICT/DX/AI
  | "esg_sustainability"    // ESG/サステナビリティ
  | "hr_diversity"          // 人事・ダイバーシティ
  | "academic_research";    // 学術・研究

/** 取締役区分 (会社法 + CGC) */
export type DirectorRole =
  | "executive"            // 業務執行取締役
  | "non_executive"        // 非業務執行取締役
  | "independent_outside"  // 独立社外取締役
  | "outside_non_indep"    // 社外 (独立性なし)
  | "audit_committee"      // 監査委員 (3委員会等設置会社)
  | "nomination_committee" // 指名委員
  | "remuneration_committee"; // 報酬委員

/** 取締役プロフィール */
export interface DirectorProfile {
  id: string;
  name_initial: string;        // 識別子のみ (個人情報配慮)
  role: DirectorRole;
  is_independent: boolean;     // 独立性
  attendance_rate_pct: number; // 出席率 (CGC 原則 4-11③)
  tenure_years: number;
  age: number;
  gender: "male" | "female" | "non_disclosed";
  nationality: "JP" | "non_JP" | "non_disclosed";
  // スキルマトリクス: ◎=主要 / ○=有 / なし
  skills: Partial<Record<DirectorSkillCategory, "primary" | "secondary" | "none">>;
  concurrent_listed_count: number; // 兼任上場会社数 (補充原則 4-11② で4社以下推奨)
  training_hours_per_year: number; // 補充原則 4-14②
}

// ============================================================================
// 2. ボード評価 (Board Effectiveness Evaluation)
// ============================================================================

/** 評価方式 */
export type EvaluationMethod =
  | "self_evaluation_only"        // 自己評価のみ (最低水準)
  | "with_peer_review"            // 相互評価併用
  | "third_party_consultant"      // 第三者機関活用 (CGC 推奨)
  | "third_party_with_individual"; // 個別評価まで実施 (最高水準)

/** ボード評価結果 */
export interface BoardEvaluationResult {
  fiscal_year: string;
  method: EvaluationMethod;
  evaluator: string;       // 第三者機関名 or 内部
  // 7 評価軸 (CGC 補充原則 4-11③ + 機関投資家ガイドライン)
  axes: {
    composition: number;      // 構成・多様性 0-5
    chairperson: number;      // 議長運営 0-5
    agenda_quality: number;   // 議題の質 0-5
    discussion_depth: number; // 議論の深さ 0-5
    decision_speed: number;   // 意思決定スピード 0-5
    monitoring: number;       // 経営監督機能 0-5
    diversity_inclusion: number; // 多様性・包摂 0-5
  };
  total_score_pct: number; // 0-100
  identified_issues: string[];
  improvement_actions: string[];
  disclosed_in_cg_report: boolean; // 開示済みか (CGC 補充原則 4-11③)
  evaluated_at: string; // ISO 8601
}

// ============================================================================
// 3. スキルマトリクス分析 (Skill Matrix Analysis)
// ============================================================================

export interface SkillMatrixAnalysis {
  total_directors: number;
  coverage_by_skill: Record<DirectorSkillCategory, {
    primary_count: number;
    secondary_count: number;
    coverage_pct: number;  // primary + secondary が居る比率
    gap_severity: "ok" | "watch" | "critical"; // 不足度
  }>;
  diversity_metrics: {
    female_ratio_pct: number;       // 女性比率 (R12までに30%目標)
    foreign_national_pct: number;   // 外国籍比率
    independent_outside_pct: number; // 独立社外取締役比率 (CGC: プライム1/3以上)
    age_diversity_score: number;    // 年代分散 0-100
  };
  red_flags: string[]; // 重大な不足事項
  recommendations: string[];
}

/**
 * スキルマトリクスを分析し、不足スキルと多様性ギャップを抽出する。
 * Learning-Driven 拡張: 過去の決裁傾向と業界変化からスキル要件を自動推奨可能。
 */
export function analyzeSkillMatrix(directors: DirectorProfile[]): SkillMatrixAnalysis {
  const total = directors.length;
  const skills: DirectorSkillCategory[] = [
    "corporate_management", "global_business", "industry_expertise",
    "finance_accounting", "legal_compliance", "risk_management",
    "ict_dx", "esg_sustainability", "hr_diversity", "academic_research",
  ];

  const coverage: SkillMatrixAnalysis["coverage_by_skill"] = {} as never;
  const redFlags: string[] = [];

  for (const skill of skills) {
    const primary = directors.filter((d) => d.skills?.[skill] === "primary").length;
    const secondary = directors.filter((d) => d.skills?.[skill] === "secondary").length;
    const covered = primary + secondary;
    const pct = total > 0 ? Math.round((covered / total) * 100) : 0;
    let severity: "ok" | "watch" | "critical" = "ok";
    if (covered === 0) {
      severity = "critical";
      redFlags.push(`${skill} を主要/副次とする取締役がゼロ`);
    } else if (primary === 0) {
      severity = "watch";
    }
    coverage[skill] = {
      primary_count: primary,
      secondary_count: secondary,
      coverage_pct: pct,
      gap_severity: severity,
    };
  }

  // ICT/DX/AI が無いのは現代ボードとして致命的
  if (coverage.ict_dx.gap_severity === "critical") {
    redFlags.push("ICT/DX/AI スキルが完全欠落 — DX 経営判断不能");
  }
  if (coverage.esg_sustainability.gap_severity === "critical") {
    redFlags.push("ESG/サステナビリティ スキル欠落 — TCFD/SSBJ 対応困難");
  }

  // 多様性指標
  const female = directors.filter((d) => d.gender === "female").length;
  const foreign = directors.filter((d) => d.nationality === "non_JP").length;
  const indep = directors.filter((d) => d.is_independent).length;
  const ageDiversity = computeAgeDiversity(directors);

  const female_ratio_pct = total > 0 ? Math.round((female / total) * 100) : 0;
  const foreign_national_pct = total > 0 ? Math.round((foreign / total) * 100) : 0;
  const independent_outside_pct = total > 0 ? Math.round((indep / total) * 100) : 0;

  if (female_ratio_pct < 30) {
    redFlags.push(`女性比率 ${female_ratio_pct}% — 目標30%未達`);
  }
  if (independent_outside_pct < 33) {
    redFlags.push(`独立社外取締役 ${independent_outside_pct}% — プライム1/3要件未達`);
  }

  const recommendations: string[] = [];
  for (const [skill, info] of Object.entries(coverage)) {
    if (info.gap_severity === "critical") {
      recommendations.push(`${skill} の専門家を独立社外取締役として招聘`);
    }
  }
  if (female_ratio_pct < 30) {
    recommendations.push("女性候補者プールを広げるため Search Firm 活用 + 内部育成");
  }

  return {
    total_directors: total,
    coverage_by_skill: coverage,
    diversity_metrics: {
      female_ratio_pct,
      foreign_national_pct,
      independent_outside_pct,
      age_diversity_score: ageDiversity,
    },
    red_flags: redFlags,
    recommendations,
  };
}

function computeAgeDiversity(directors: DirectorProfile[]): number {
  if (directors.length === 0) return 0;
  // 年代区分 50 未満 / 50-59 / 60-69 / 70+ の4区分のシャノン情報量を 0-100 にマップ
  const buckets = [0, 0, 0, 0];
  for (const d of directors) {
    if (d.age < 50) buckets[0]++;
    else if (d.age < 60) buckets[1]++;
    else if (d.age < 70) buckets[2]++;
    else buckets[3]++;
  }
  const total = directors.length;
  let entropy = 0;
  for (const c of buckets) {
    if (c === 0) continue;
    const p = c / total;
    entropy -= p * Math.log2(p);
  }
  // 最大 entropy = log2(4) = 2
  return Math.round((entropy / 2) * 100);
}

// ============================================================================
// 4. 兼任状況チェック (CGC 補充原則 4-11②)
// ============================================================================

export interface ConcurrentRoleCheck {
  director_id: string;
  concurrent_count: number;
  is_compliant: boolean; // 4社以下原則
  rationale_required: boolean; // 5社以上の場合は合理的説明開示が必要
}

export function checkConcurrentRoles(directors: DirectorProfile[]): ConcurrentRoleCheck[] {
  return directors.map((d) => ({
    director_id: d.id,
    concurrent_count: d.concurrent_listed_count,
    is_compliant: d.concurrent_listed_count <= 4,
    rationale_required: d.concurrent_listed_count > 4,
  }));
}

// ============================================================================
// 5. 学習駆動推奨 (Learning-Driven Recommendation)
//    learning_governance.ts と協調動作するインターフェイス
// ============================================================================

export interface BoardLearningInsight {
  source_period: string;        // 例: "2025-Q3〜2026-Q2"
  observed_decision_topics: string[]; // 過去の決裁テーマ群
  recurring_blind_spots: string[];    // 繰り返し露呈するスキル不足
  ai_governance_score: number;        // AI Governance 観点の成熟度 0-100
  recommended_skills: DirectorSkillCategory[];
  // 学習データ駆動で推奨する次回ボード招聘プロファイル
  ideal_next_director: Partial<DirectorProfile>;
}

/**
 * Learning-Driven Governance Engine (learning_governance.ts) と協調して、
 * 過去の取締役会議事録 + AI 利用ログ + コンプラ違反履歴から
 * ボード補強候補を推奨する。
 */
export function deriveBoardLearningInsight(
  pastDecisions: { topic: string; outcome: "approved" | "rejected" | "deferred" }[],
  blindSpots: string[],
  aiGovernanceScore: number
): BoardLearningInsight {
  const topics = Array.from(new Set(pastDecisions.map((d) => d.topic)));
  const recommended: DirectorSkillCategory[] = [];

  if (blindSpots.some((s) => /AI|DX|デジタル/i.test(s))) recommended.push("ict_dx");
  if (blindSpots.some((s) => /ESG|サステナ|気候/i.test(s))) recommended.push("esg_sustainability");
  if (blindSpots.some((s) => /海外|グローバル|FX/i.test(s))) recommended.push("global_business");
  if (aiGovernanceScore < 60) recommended.push("ict_dx");

  return {
    source_period: new Date().toISOString().slice(0, 7),
    observed_decision_topics: topics,
    recurring_blind_spots: blindSpots,
    ai_governance_score: aiGovernanceScore,
    recommended_skills: Array.from(new Set(recommended)),
    ideal_next_director: {
      role: "independent_outside",
      is_independent: true,
      skills: Object.fromEntries(
        Array.from(new Set(recommended)).map((s) => [s, "primary" as const])
      ),
    },
  };
}

// ============================================================================
// 6. 公式 Phase 45 マニフェスト
// ============================================================================

export const BOARD_EFFECTIVENESS_MANIFEST = {
  phase: "45-GV-board",
  version: "v2031.0",
  laws: [
    "会社法 362条/369条/423条",
    "CGC 原則 4-1〜4-14 (補充原則 4-11①②③ + 4-14②)",
    "東証 コーポレート・ガバナンス報告書 記載要領 R3.6",
    "金融庁 投資家と企業の対話ガイドライン R6改訂",
  ],
  evaluation_methods: [
    "self_evaluation_only",
    "with_peer_review",
    "third_party_consultant",
    "third_party_with_individual",
  ] as EvaluationMethod[],
  skill_categories: 10,
  diversity_targets: {
    female_ratio_pct_target_R12: 30,
    independent_outside_pct_prime_min: 33.4,
    concurrent_listed_max: 4,
  },
  ai_governance_integration: true, // AI Governance観点をボード評価に組込済
  learning_driven: true,            // 学習駆動推奨機能あり
} as const;
