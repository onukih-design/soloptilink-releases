// @ts-check
/**
 * 観光宿泊 DNA (Phase 20)
 *
 * Claude Code がカバーしない日本の観光・宿泊業を完全カバー。
 *
 *  - 旅館業法 (旅館・ホテル / 簡易宿所 / 下宿)
 *  - 住宅宿泊事業法 (民泊新法 - 年180日上限)
 *  - 国家戦略特区民泊 (特区民泊 - 2泊3日以上)
 *  - 旅行業法 (1種 / 2種 / 3種 / 地域限定 / 旅行業者代理業)
 *  - 観光庁 宿泊旅行統計調査
 *  - 入湯税 (普通税150円 + 自治体条例)
 *  - 宿泊税 (東京 / 大阪 / 京都 / 福岡市 / 北海道倶知安町 等)
 *  - 旅館宿泊約款 (モデル約款)
 *  - 標準旅行業約款
 *  - 訪日外国人観光客 (インバウンド) 対応 (TIC / 多言語表示)
 *  - 通訳案内士法
 *  - 国際観光振興機構 (JNTO)
 *  - QRコード決済 / 免税対応 (税抜5,000円〜 一般物品 / 5,000〜500,000円 消耗品)
 *
 * 参考:
 *   - 旅館業法 https://elaws.e-gov.go.jp/document?lawid=323AC0000000138
 *   - 住宅宿泊事業法 https://elaws.e-gov.go.jp/document?lawid=429AC0000000065
 *   - 旅行業法 https://elaws.e-gov.go.jp/document?lawid=327AC0000000239
 */

// =============================================================================
// 宿泊事業 種別
// =============================================================================

export type AccommodationKind =
  | 'ryokan_hotel' // 旅館・ホテル営業 (旅館業法)
  | 'kani_shukusho' // 簡易宿所営業 (旅館業法)
  | 'geshuku' // 下宿営業 (1ヶ月以上の営業)
  | 'minpaku_jutaku' // 住宅宿泊事業 (民泊新法 / 180日上限)
  | 'minpaku_tokku' // 特区民泊 (国家戦略特区 / 2泊3日以上)
  | 'others'; // その他

export interface AccommodationFacility {
  facility_id: string;
  name: string;
  kind: AccommodationKind;
  /** 営業許可番号 (旅館業) or 届出番号 (民泊) */
  license_no: string;
  /** 客室数 */
  guest_room_count: number;
  /** 延床面積 (㎡) */
  total_floor_area_sqm: number;
  /** 浴室付き客室か (旅館業) */
  has_bath_per_room?: boolean;
  /** 民泊の場合: 当年累計営業日数 */
  minpaku_year_days?: number;
}

/**
 * 民泊新法 180 日上限チェック
 */
export function isMinpaku180LimitReached(facility: AccommodationFacility): boolean {
  if (facility.kind !== 'minpaku_jutaku') return false;
  return (facility.minpaku_year_days ?? 0) >= 180;
}

/**
 * 旅館業法 客室数最低基準
 *  - 旅館・ホテル営業: 制限なし (S30改正で5室以上規制撤廃)
 *  - 簡易宿所: 33㎡以上 (10人未満は10倍以上)
 */
export function isFacilityLegallyOk(f: AccommodationFacility): { ok: boolean; reason?: string } {
  if (f.kind === 'kani_shukusho' && f.total_floor_area_sqm < 33) {
    return { ok: false, reason: '簡易宿所は33㎡以上必要' };
  }
  return { ok: true };
}

// =============================================================================
// 宿泊予約
// =============================================================================

export interface AccommodationBooking {
  booking_id: string;
  facility_id: string;
  /** 宿泊者 (代表) */
  guest_name: string;
  guest_address: string;
  guest_phone: string;
  /** 国籍 (外国人は本籍地・パスポート番号必須 - 旅館業法6条) */
  guest_nationality: string;
  guest_passport_no?: string;
  guest_count: number;
  check_in: string;
  check_out: string;
  room_type: string;
  /** 1人1泊あたりの宿泊料 (税抜) */
  rate_per_person_jpy: number;
  /** 食事条件 */
  meal_plan: 'no_meal' | 'breakfast' | 'two_meals'; // 素泊/朝食付/2食付
}

/**
 * 旅館業法 6条 宿泊者名簿の必須項目チェック
 *  - 氏名・住所・職業 (国籍/旅券番号は外国人のみ)
 */
export function validateGuestRecord(b: AccommodationBooking): { ok: boolean; missing: string[] } {
  const missing: string[] = [];
  if (!b.guest_name) missing.push('氏名');
  if (!b.guest_address) missing.push('住所');
  if (b.guest_nationality !== 'JP' && !b.guest_passport_no) {
    missing.push('外国人のパスポート番号');
  }
  return { ok: missing.length === 0, missing };
}

// =============================================================================
// 宿泊料計算 + 入湯税 + 宿泊税
// =============================================================================

export interface BillingBreakdown {
  base_amount: number; // 宿泊料 (税抜)
  consumption_tax: number; // 消費税 (10%)
  bath_tax: number; // 入湯税 (1人1泊150円が基本)
  accommodation_tax: number; // 宿泊税 (自治体条例)
  service_charge: number; // サービス料 (10〜15%が一般的)
  total: number;
}

/**
 * 主要自治体の宿泊税
 */
export const ACCOMMODATION_TAX_TABLE: Record<string, (rate: number) => number> = {
  // 東京都: 1万円〜1.5万円未満 100円, 1.5万円以上 200円
  '東京都': (r: number) => (r < 10_000 ? 0 : r < 15_000 ? 100 : 200),
  // 大阪府: 7千円〜1.5万円未満 100円, 1.5万円〜2万円未満 200円, 2万円以上 300円
  '大阪府': (r: number) =>
    r < 7_000 ? 0 : r < 15_000 ? 100 : r < 20_000 ? 200 : 300,
  // 京都市: 2万円未満 200円, 2万円〜5万円未満 500円, 5万円以上 1000円
  '京都市': (r: number) => (r < 20_000 ? 200 : r < 50_000 ? 500 : 1_000),
  // 福岡市: 2万円未満 200円, 2万円以上 500円
  '福岡市': (r: number) => (r < 20_000 ? 200 : 500),
  // 倶知安町 (北海道): 宿泊料金の 2%
  '倶知安町': (r: number) => Math.floor(r * 0.02),
};

export function calcAccommodationTax(municipality: string, rate_per_night_per_person: number): number {
  const fn = ACCOMMODATION_TAX_TABLE[municipality];
  return fn ? fn(rate_per_night_per_person) : 0;
}

/**
 * 宿泊料の総合計算
 */
export function calcBilling(args: {
  rate_per_person_jpy: number;
  guest_count: number;
  nights: number;
  has_onsen: boolean;
  bath_tax_jpy?: number; // 入湯税 (デフォルト 150)
  municipality?: string;
  service_charge_rate?: number; // 0.10〜0.15
}): BillingBreakdown {
  const base_amount = args.rate_per_person_jpy * args.guest_count * args.nights;
  const consumption_tax = Math.floor(base_amount * 0.1);
  const bath_tax = args.has_onsen ? (args.bath_tax_jpy ?? 150) * args.guest_count * args.nights : 0;
  const acc_per = args.municipality ? calcAccommodationTax(args.municipality, args.rate_per_person_jpy) : 0;
  const accommodation_tax = acc_per * args.guest_count * args.nights;
  const service_charge = args.service_charge_rate ? Math.floor(base_amount * args.service_charge_rate) : 0;
  const total = base_amount + consumption_tax + bath_tax + accommodation_tax + service_charge;
  return { base_amount, consumption_tax, bath_tax, accommodation_tax, service_charge, total };
}

// =============================================================================
// 旅行業法
// =============================================================================

export type TravelAgencyKind =
  | 'type1' // 第1種旅行業 (海外/国内 募集型企画) - 営業保証金1億円
  | 'type2' // 第2種旅行業 (国内 募集型企画) - 営業保証金1100万円
  | 'type3' // 第3種旅行業 (国内手配旅行 / 隣接区域募集型)- 営業保証金300万円
  | 'regional' // 地域限定旅行業 - 営業保証金100万円
  | 'agent'; // 旅行業者代理業

export const TRAVEL_AGENCY_BOND_TABLE: Record<TravelAgencyKind, number> = {
  type1: 100_000_000,
  type2: 11_000_000,
  type3: 3_000_000,
  regional: 1_000_000,
  agent: 0,
};

/**
 * 旅程管理主任者の必要性 (募集型企画旅行 + 国内 = 国内旅程管理 / 海外 = 総合旅程管理)
 */
export type ItineraryManagerKind = 'domestic' | 'overall';

export function getRequiredItineraryManagerKind(
  agency: TravelAgencyKind,
  hasOverseas: boolean,
): ItineraryManagerKind | null {
  if (agency === 'type1' && hasOverseas) return 'overall';
  if (agency === 'type2' || agency === 'regional') return 'domestic';
  return null;
}

// =============================================================================
// 免税販売 (輸出物品販売場 - 消費税免税)
// =============================================================================

export type DutyFreeProductKind = 'general_goods' | 'consumables';

/**
 * 免税の最低購入金額
 *  - 一般物品: 5,000円以上 (上限なし)
 *  - 消耗品: 5,000円〜500,000円 (専用包装が条件)
 *  - 一般物品 + 消耗品の合計: 5,000円以上 (専用包装で消耗品扱い)
 */
export function isDutyFreeEligible(
  amount: number,
  kind: DutyFreeProductKind,
): { eligible: boolean; reason: string } {
  if (kind === 'general_goods') {
    if (amount < 5_000) return { eligible: false, reason: '一般物品は5,000円以上必要' };
    return { eligible: true, reason: 'OK 一般物品' };
  }
  // consumables
  if (amount < 5_000) return { eligible: false, reason: '消耗品は5,000円以上必要' };
  if (amount > 500_000) return { eligible: false, reason: '消耗品は500,000円以下のみ' };
  return { eligible: true, reason: 'OK 消耗品 (専用包装必要)' };
}

// =============================================================================
// 多言語対応 (インバウンド)
// =============================================================================

export const SUPPORTED_TOURIST_LANGUAGES = [
  { code: 'ja', label: '日本語', priority: 1 },
  { code: 'en', label: 'English', priority: 2 },
  { code: 'zh-CN', label: '简体中文', priority: 3 },
  { code: 'zh-TW', label: '繁體中文', priority: 4 },
  { code: 'ko', label: '한국어', priority: 5 },
  { code: 'th', label: 'ไทย', priority: 6 },
  { code: 'fr', label: 'Français', priority: 7 },
  { code: 'es', label: 'Español', priority: 8 },
] as const;

export const TIC_LOCATIONS = [
  { code: 'TIC-NARITA', name: '成田空港 観光案内所', open: '07:00-21:00' },
  { code: 'TIC-HANEDA', name: '羽田空港 観光案内所', open: '24:00' },
  { code: 'TIC-KIX', name: '関西国際空港 観光案内所', open: '07:00-22:00' },
  { code: 'TIC-TOKYO', name: '東京観光情報センター', open: '09:30-18:30' },
  { code: 'TIC-KYOTO', name: '京都総合観光案内所 京なび', open: '08:30-19:00' },
] as const;

// =============================================================================
// JNTO 統計
// =============================================================================

export interface InboundStat {
  year: number;
  month: number;
  /** 国/地域 */
  origin: string;
  /** 訪日外客数 */
  arrivals: number;
  /** 平均滞在日数 */
  avg_stay_days: number;
  /** 1人1回あたり旅行支出 (円) */
  spending_per_visit_jpy: number;
}

/**
 * 観光収入の試算
 */
export function estimateTourismRevenue(stats: InboundStat[]): number {
  return stats.reduce((sum, s) => sum + s.arrivals * s.spending_per_visit_jpy, 0);
}
