/**
 * SoloptiLinkAI Phase 24-FA — 確定申告 / 法人税申告 / 消費税申告 (Tax Filing)
 *
 * 日本の主要な税務申告書の計算ロジック骨子。
 * Phase 16 gov_eapps.ts (e-Tax 提出フロー) と組み合わせて使う前段の数値計算。
 *
 * カバー範囲:
 *  - 個人事業主の確定申告 (青色申告: 65万/55万/10万円控除 + 白色申告)
 *  - 所得税の累進税率 (5%〜45%)
 *  - 復興特別所得税 (基準所得税額の2.1%)
 *  - 法人税申告 (中小法人: 800万円以下15%/超19% R6時点)
 *  - 法人住民税 (均等割 + 法人税割)
 *  - 法人事業税 (所得割)
 *  - 消費税申告 (一般課税 / 簡易課税 / インボイス2割特例 / 少額特例)
 *  - 消費税 8% / 10% 区分集計
 */

// ★2026-08-11 (owner 決定 束E-2): 年分別 税マスタを計算へ接続する。
//   これまで基礎控除 480,000 円と法人税率は本ファイルに直書きされており、
//   一次情報から取り込んだ令和8年分マスタは **どの計算からも読まれていなかった** (実測)。
//   ここから読込口を通して実際に使う。ただし査読前の値を黙って確定値にはしない:
//   年分を明示した呼び出しだけがマスタを使い、その結果には必ず査読状態と注意書きが付く。
import {
  resolveBasicDeduction,
  resolveCorporateTaxBrackets,
  calcCorporateTaxFromBrackets,
  TaxMasterUnavailableError,
} from "./tax-engine/year-value-loader.js";

// ===================
// 個人事業主 確定申告
// ===================

export type FilingType = "blue65" | "blue55" | "blue10" | "white";

export interface IndividualFilingInput {
  business_income: number; // 事業収入
  business_expenses: number; // 事業必要経費
  filing_type: FilingType;
  // 所得控除
  social_insurance_premiums: number; // 国民年金/国民健康保険等
  small_business_mutual_aid: number; // 小規模企業共済
  ideco: number; // iDeCo
  life_insurance_deduction?: number; // 最大4万 (新生命保険料)
  earthquake_insurance_deduction?: number; // 最大5万
  medical_expense_deduction?: number; // 医療費控除 (10万円超 or 所得5%)
  donation_deduction?: number; // 寄附金 (ふるさと納税等)
  spouse_deduction?: number; // 配偶者控除/特別控除
  dependent_deduction?: number; // 扶養控除
  basic_deduction?: number; // 基礎控除 (金額を明示するとき。省略時は下の tax_year で解決)
  /**
   * 年分 (西暦。令和8年分なら 2026)。
   * 指定すると基礎控除を年分マスタ (lib/japan/tax-values/) から解決する。
   * 省略すると従来どおり令和6年分の固定値を使い、結果にその旨を明示する。
   */
  tax_year?: number;
}

export const BLUE_FILING_DEDUCTION: Record<FilingType, number> = {
  blue65: 650_000, // e-Tax提出 + 電子帳簿保存
  blue55: 550_000, // 複式簿記 + 期限内提出 (紙)
  blue10: 100_000, // 簡易簿記 (現金主義含む)
  white: 0,
};

export const DEFAULT_BASIC_DEDUCTION = 480_000; // R6 基礎控除

// 所得税 累進税率 (R6)
export const INCOME_TAX_BRACKETS = [
  { up_to: 1_950_000, rate: 0.05, deduction: 0 },
  { up_to: 3_300_000, rate: 0.10, deduction: 97_500 },
  { up_to: 6_950_000, rate: 0.20, deduction: 427_500 },
  { up_to: 9_000_000, rate: 0.23, deduction: 636_000 },
  { up_to: 18_000_000, rate: 0.33, deduction: 1_536_000 },
  { up_to: 40_000_000, rate: 0.40, deduction: 2_796_000 },
  { up_to: Infinity, rate: 0.45, deduction: 4_796_000 },
] as const;

export function calcIncomeTax(taxableIncome: number): number {
  if (taxableIncome <= 0) return 0;
  // 千円未満切り捨て
  const taxable = Math.floor(taxableIncome / 1000) * 1000;
  for (const b of INCOME_TAX_BRACKETS) {
    if (taxable <= b.up_to) {
      return Math.floor(taxable * b.rate - b.deduction);
    }
  }
  return 0;
}

// 復興特別所得税 (基準所得税額の2.1%)
export function calcReconstructionSurtax(baseIncomeTax: number): number {
  return Math.floor(baseIncomeTax * 0.021);
}

export interface IndividualFilingResult {
  business_income: number;
  business_expenses: number;
  blue_filing_deduction: number;
  net_business_income: number;
  total_deductions: number;
  taxable_income: number;
  income_tax_base: number;
  reconstruction_surtax: number;
  total_tax: number;
  /** 基礎控除をどこから取ったか (お客様への説明にそのまま使える日本語) */
  basic_deduction_source_ja: string;
  /** 基礎控除の値の査読状態 */
  basic_deduction_review_status: string;
  /** その値を確定値として業務に使ってよいか */
  basic_deduction_confirmed: boolean;
  /** 確定でないときの注意書き (確定なら空文字) */
  basic_deduction_caution_ja: string;
}

/**
 * 基礎控除の既定値を決める。
 *  ・呼び出し側が金額を明示した   → その金額 (従来どおり)
 *  ・年分 (tax_year) が指定された → 年分マスタから解決する (査読状態を必ず返す)
 *  ・年分の指定が無い             → 従来の固定値。ただし「令和6年分の固定値」と明示する
 * ★年分を指定したのにマスタが読めない/範囲外のときは、黙って固定値へ倒さず例外にする。
 *   「読めなかったので古い控除額で計算しました」は、誤った税額を静かに出す経路そのもの。
 */
function resolveBasicDeductionForFiling(input: IndividualFilingInput): {
  amount: number;
  source_ja: string;
  review_status: string;
  confirmed: boolean;
  caution_ja: string;
} {
  if (input.basic_deduction !== undefined && input.basic_deduction !== null) {
    return {
      amount: input.basic_deduction,
      source_ja: "呼び出し側が指定した金額",
      review_status: "caller-specified",
      confirmed: true,
      caution_ja: "",
    };
  }
  if (input.tax_year !== undefined && input.tax_year !== null) {
    const totalIncome = Math.max(
      0,
      input.business_income - input.business_expenses - BLUE_FILING_DEDUCTION[input.filing_type]
    );
    const r = resolveBasicDeduction(input.tax_year, totalIncome);
    return {
      amount: r.value,
      source_ja: `${r.wareki} の年分マスタ (${r.source_file})`,
      review_status: r.review_status,
      confirmed: r.confirmed,
      caution_ja: r.caution_ja,
    };
  }
  return {
    amount: DEFAULT_BASIC_DEDUCTION,
    source_ja: "令和6年分の固定値 (年分の指定が無いため)",
    review_status: "legacy-fixed-r6",
    confirmed: false,
    caution_ja:
      "年分の指定が無いため、令和6年分の基礎控除額で計算しています。" +
      "令和7年分以降は金額が変わっているため、年分を指定してください。",
  };
}

export function calcIndividualFiling(input: IndividualFilingInput): IndividualFilingResult {
  const blueDeduction = BLUE_FILING_DEDUCTION[input.filing_type];
  const netBusiness = Math.max(0, input.business_income - input.business_expenses - blueDeduction);
  const basic = resolveBasicDeductionForFiling(input);
  const deductions =
    basic.amount +
    input.social_insurance_premiums +
    input.small_business_mutual_aid +
    input.ideco +
    (input.life_insurance_deduction ?? 0) +
    (input.earthquake_insurance_deduction ?? 0) +
    (input.medical_expense_deduction ?? 0) +
    (input.donation_deduction ?? 0) +
    (input.spouse_deduction ?? 0) +
    (input.dependent_deduction ?? 0);
  const taxable = Math.max(0, netBusiness - deductions);
  const tax = calcIncomeTax(taxable);
  const reconstruction = calcReconstructionSurtax(tax);
  return {
    business_income: input.business_income,
    business_expenses: input.business_expenses,
    blue_filing_deduction: blueDeduction,
    net_business_income: netBusiness,
    total_deductions: deductions,
    taxable_income: taxable,
    income_tax_base: tax,
    reconstruction_surtax: reconstruction,
    total_tax: tax + reconstruction,
    basic_deduction_source_ja: basic.source_ja,
    basic_deduction_review_status: basic.review_status,
    basic_deduction_confirmed: basic.confirmed,
    basic_deduction_caution_ja: basic.caution_ja,
  };
}

// ===================
// 法人税申告
// ===================

export interface CorporateFilingInput {
  taxable_income: number; // 所得金額
  is_smb: boolean; // 中小法人 (期末資本金1億円以下)
  prefecture?: string; // 法人住民税の地域差
  capital_yen: number; // 期末資本金
  number_of_employees?: number; // 均等割計算用
  /**
   * 事業年度の開始日 'YYYY-MM-DD'。
   * 指定すると法人税率を年分マスタ (lib/japan/tax-values/) から解決する。
   * 省略すると従来どおり R6 の固定税率で計算する (挙動は変わらない)。
   */
  fiscal_year_start?: string;
}

// 法人税率 (R6時点 中小法人)
const CORPORATE_TAX_THRESHOLD_SMB = 8_000_000;
const CORPORATE_TAX_RATE_SMB_LOW = 0.15; // 800万円以下
const CORPORATE_TAX_RATE_SMB_HIGH = 0.232; // 超過部分 (中小軽減後 19% + 地方法人税)
const CORPORATE_TAX_RATE_LARGE = 0.232; // 大法人

export function calcCorporateTax(input: CorporateFilingInput): number {
  if (input.taxable_income <= 0) return 0;
  // ★2026-08-11 (束E-2): 事業年度の開始日が渡されたら年分マスタで解決する。
  //   直書きの R6 税率には、令和7年4月1日以後開始事業年度の条件付税率
  //   (所得が年10億円超のとき 800 万円以下の部分が 17%) が存在しなかった。
  //   開始日が渡されないときは従来どおり (挙動を一切変えない)。
  if (input.fiscal_year_start) {
    const category = input.is_smb ? "普通法人 (資本金1億円以下" : "上記以外の普通法人";
    const r = resolveCorporateTaxBrackets(input.fiscal_year_start, category, input.taxable_income);
    return calcCorporateTaxFromBrackets(r.value, input.taxable_income);
  }
  if (input.is_smb) {
    const low = Math.min(input.taxable_income, CORPORATE_TAX_THRESHOLD_SMB);
    const high = Math.max(0, input.taxable_income - CORPORATE_TAX_THRESHOLD_SMB);
    return Math.floor(low * CORPORATE_TAX_RATE_SMB_LOW + high * CORPORATE_TAX_RATE_SMB_HIGH);
  }
  return Math.floor(input.taxable_income * CORPORATE_TAX_RATE_LARGE);
}

// 地方法人税 (法人税額の10.3%)
export function calcLocalCorporateTax(corporateTax: number): number {
  return Math.floor(corporateTax * 0.103);
}

// 法人住民税 (均等割: 資本金+従業員数) — 標準税率
export interface MunicipalEqualPortion {
  prefectural: number; // 道府県民税
  municipal: number; // 市町村民税
  total: number;
}

export function calcMunicipalEqualPortion(input: CorporateFilingInput): MunicipalEqualPortion {
  const cap = input.capital_yen;
  const emp = input.number_of_employees ?? 0;
  // 道府県民税均等割 (5段階)
  let pref = 20_000;
  if (cap > 50_000_000_000) pref = 800_000;
  else if (cap > 10_000_000_000) pref = 540_000;
  else if (cap > 1_000_000_000) pref = 130_000;
  else if (cap > 100_000_000) pref = 50_000;
  // 市町村民税均等割 (資本金+従業員50人超で増額)
  let muni = 50_000;
  if (cap > 50_000_000_000 && emp > 50) muni = 3_000_000;
  else if (cap > 10_000_000_000 && emp > 50) muni = 1_750_000;
  else if (cap > 1_000_000_000 && emp > 50) muni = 400_000;
  else if (cap > 100_000_000 && emp > 50) muni = 150_000;
  else if (cap > 100_000_000) muni = 120_000;
  return { prefectural: pref, municipal: muni, total: pref + muni };
}

// 法人住民税 法人税割 (法人税額×標準税率10.4%)
export function calcMunicipalIncomePortion(corporateTax: number): number {
  return Math.floor(corporateTax * 0.104);
}

// 法人事業税 (所得割: 中小=外形非対象として簡易)
const BUSINESS_TAX_BRACKETS = [
  { up_to: 4_000_000, rate: 0.035 }, // 軽減税率 (R6 中小)
  { up_to: 8_000_000, rate: 0.053 },
  { up_to: Infinity, rate: 0.07 },
];
export function calcBusinessTax(taxableIncome: number, isSmb: boolean): number {
  if (taxableIncome <= 0) return 0;
  if (!isSmb) return Math.floor(taxableIncome * 0.07);
  let tax = 0;
  let remaining = taxableIncome;
  let prev = 0;
  for (const b of BUSINESS_TAX_BRACKETS) {
    const span = Math.min(remaining, b.up_to - prev);
    if (span <= 0) break;
    tax += span * b.rate;
    remaining -= span;
    prev = b.up_to;
  }
  return Math.floor(tax);
}

export interface CorporateFilingResult {
  corporate_tax: number;
  local_corporate_tax: number;
  municipal_equal: MunicipalEqualPortion;
  municipal_income_portion: number;
  business_tax: number;
  total_tax: number;
}

export function calcCorporateFiling(input: CorporateFilingInput): CorporateFilingResult {
  const cTax = calcCorporateTax(input);
  const localC = calcLocalCorporateTax(cTax);
  const muniEq = calcMunicipalEqualPortion(input);
  const muniInc = calcMunicipalIncomePortion(cTax);
  const biz = calcBusinessTax(input.taxable_income, input.is_smb);
  return {
    corporate_tax: cTax,
    local_corporate_tax: localC,
    municipal_equal: muniEq,
    municipal_income_portion: muniInc,
    business_tax: biz,
    total_tax: cTax + localC + muniEq.total + muniInc + biz,
  };
}

// ===================
// 消費税申告
// ===================

export type ConsumptionTaxRate = "10%" | "8%" | "exempt";
export type ConsumptionTaxMethod = "general" | "simplified" | "two_percent_special";

export interface ConsumptionTaxLine {
  amount_excl: number; // 税抜
  rate: ConsumptionTaxRate;
}

export interface ConsumptionTaxInput {
  sales: ConsumptionTaxLine[];
  purchases: ConsumptionTaxLine[];
  method: ConsumptionTaxMethod;
  business_category?: 1 | 2 | 3 | 4 | 5 | 6; // 簡易課税の事業区分 (1=卸売 90% 〜 6=不動産 40%)
  is_invoice_registered?: boolean; // 適格請求書発行事業者
  is_two_percent_eligible?: boolean; // インボイス制度2割特例 (R5.10〜R8.9)
}

const CONSUMPTION_RATE_VAT: Record<ConsumptionTaxRate, number> = {
  "10%": 0.10,
  "8%": 0.08,
  "exempt": 0,
};

const SIMPLIFIED_DEEMED_RATE: Record<1 | 2 | 3 | 4 | 5 | 6, number> = {
  1: 0.90, // 卸売業
  2: 0.80, // 小売業
  3: 0.70, // 製造業等
  4: 0.60, // その他 (飲食店等)
  5: 0.50, // サービス業等
  6: 0.40, // 不動産業
};

export interface ConsumptionTaxResult {
  total_sales_excl: number;
  total_purchases_excl: number;
  output_tax: number; // 売上に係る消費税
  input_tax: number; // 仕入に係る消費税控除
  net_tax: number;
  method_used: ConsumptionTaxMethod;
  notes: string[];
}

export function calcConsumptionTax(input: ConsumptionTaxInput): ConsumptionTaxResult {
  const notes: string[] = [];
  const totalSales = input.sales.reduce((a, b) => a + b.amount_excl, 0);
  const totalPurchases = input.purchases.reduce((a, b) => a + b.amount_excl, 0);
  const outputTax = input.sales.reduce(
    (a, b) => a + b.amount_excl * CONSUMPTION_RATE_VAT[b.rate],
    0,
  );

  let inputTax = 0;
  let methodUsed = input.method;

  if (input.method === "simplified") {
    if (!input.business_category) {
      notes.push("簡易課税は事業区分が必要。一般課税にフォールバック");
      methodUsed = "general";
    } else {
      const deemedRate = SIMPLIFIED_DEEMED_RATE[input.business_category];
      inputTax = outputTax * deemedRate;
      notes.push(`簡易課税 区分${input.business_category} みなし仕入率 ${(deemedRate * 100).toFixed(0)}%`);
    }
  }

  if (input.method === "two_percent_special") {
    if (!input.is_two_percent_eligible || !input.is_invoice_registered) {
      notes.push("2割特例: インボイス登録 + 免税事業者からの転換等の要件未充足、一般課税にフォールバック");
      methodUsed = "general";
    } else {
      // 売上税額の8割を仕入税額控除と看做す = 納税は売上税額の2割
      inputTax = outputTax * 0.8;
      notes.push("インボイス制度2割特例 (R5.10〜R8.9) 適用");
    }
  }

  if (methodUsed === "general") {
    inputTax = input.purchases.reduce(
      (a, b) => a + b.amount_excl * CONSUMPTION_RATE_VAT[b.rate],
      0,
    );
    if (!input.is_invoice_registered) {
      notes.push("免税事業者: 仕入税額控除に経過措置 (R5.10〜R8.9: 80%, R8.10〜R11.9: 50%) を別途適用");
    }
  }

  const net = Math.max(0, Math.floor(outputTax - inputTax));
  return {
    total_sales_excl: totalSales,
    total_purchases_excl: totalPurchases,
    output_tax: Math.floor(outputTax),
    input_tax: Math.floor(inputTax),
    net_tax: net,
    method_used: methodUsed,
    notes,
  };
}

// 少額特例: 1万円未満の取引はインボイス保存不要 (R5.10〜R11.9 / 課税売上1億円以下 or 特定期間5000万円以下)
export function isShougakuTokureiEligible(
  amountExcl: number,
  baseTaxableSales: number,
  specialPeriodSales?: number,
): boolean {
  if (amountExcl >= 10_000) return false;
  if (baseTaxableSales <= 100_000_000) return true;
  if (specialPeriodSales !== undefined && specialPeriodSales <= 50_000_000) return true;
  return false;
}

// ============================================================
// [L7/v2043 橋渡し] インボイス経過措置の実行可能化 (wave2-tax-edit.lock mkdir原子で追記)
// ------------------------------------------------------------
// 上記 calcConsumptionTax の notes は免税事業者からの仕入について
// 「経過措置 (R5.10〜R8.9: 80%, R8.10〜R11.9: 50%) を別途適用」と案内するのみで、
// 実際の控除額計算は持っていなかった(片肺)。その実計算(施行日境界での 80→50→0% 解決)は
// tax-engine/consumption-tax-calculator.ts に年度キー(tax-calendar.json)方式で実装済み。
// 既存利用側がそのまま到達できるよう re-export する(既存 export は無改変・追加のみ)。
export {
  calcInvoiceTransitionalCredit,
  calcConsumptionTaxWithTransitional,
  resolveInvoiceTransitional,
} from "./tax-engine/consumption-tax-calculator.js";
