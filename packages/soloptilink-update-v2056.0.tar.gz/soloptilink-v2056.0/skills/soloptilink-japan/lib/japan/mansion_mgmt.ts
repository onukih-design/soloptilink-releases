/**
 * mansion_mgmt.ts — Phase 25 マンション管理
 *
 * カバレッジ:
 *   - 区分所有法 (建物の区分所有等に関する法律)
 *   - マンション管理適正化法 (R2 改正: 管理計画認定制度)
 *   - マンション建替え円滑化法 (老朽化マンション特措)
 *   - 標準管理規約 (国土交通省)
 *   - 長期修繕計画 (30年/12年大規模修繕周期)
 *   - 修繕積立金 (専有面積×単価方式 ガイドライン R3)
 *   - 総会決議要件 (普通決議/特別決議4分の3/建替え5分の4)
 *   - 管理業務主任者 + マンション管理士
 *   - 滞納督促 (5年消滅時効/弁護士法72条 非弁行為)
 *
 * 主要 export:
 *   - RESOLUTION_THRESHOLDS / classifyResolutionType / canPassResolution
 *   - LONG_TERM_REPAIR_CYCLES / buildLongTermRepairPlan
 *   - REPAIR_FUND_GUIDE_R3 / calcRecommendedRepairFundJpyPerM2Month
 *   - MANAGEMENT_PLAN_CERT_CRITERIA / canCertifyManagementPlan
 *   - DELINQUENCY_PROCEDURES / nextDelinquencyAction
 *   - MANAGER_QUALIFICATIONS / requireManagerQualification
 *   - REBUILD_CONSENT_THRESHOLD / canRebuildAged
 */

// ===== 区分所有法 — 決議要件 =====

export type ResolutionKind =
  | 'ordinary' // 普通決議
  | 'special_3_4' // 特別決議 3/4
  | 'rebuild_4_5' // 建替え 4/5
  | 'demolition_4_5' // 取壊し決議 4/5 (R3 改正建替え円滑化法)
  ;

export interface ResolutionThreshold {
  kind: ResolutionKind;
  ownersThreshold: number; // 区分所有者数の比率
  votesThreshold: number; // 議決権の比率
  examples: string[];
}

export const RESOLUTION_THRESHOLDS: Record<ResolutionKind, ResolutionThreshold> = {
  ordinary: {
    kind: 'ordinary',
    ownersThreshold: 0.5,
    votesThreshold: 0.5,
    examples: ['通常の管理事項', '理事選任', '通常の修繕'],
  },
  special_3_4: {
    kind: 'special_3_4',
    ownersThreshold: 0.75,
    votesThreshold: 0.75,
    examples: ['規約の変更', '共用部分の変更 (重大)', '管理組合法人化', '違反者への措置'],
  },
  rebuild_4_5: {
    kind: 'rebuild_4_5',
    ownersThreshold: 0.8,
    votesThreshold: 0.8,
    examples: ['マンション建替え (62条)'],
  },
  demolition_4_5: {
    kind: 'demolition_4_5',
    ownersThreshold: 0.8,
    votesThreshold: 0.8,
    examples: ['老朽化マンションの取壊し決議 (建替え円滑化法 R3改正)'],
  },
};

export type ProposedResolution =
  | 'change_rule'
  | 'major_common_change'
  | 'rebuild'
  | 'demolish_aged'
  | 'normal_repair'
  | 'elect_director';

/** 議案を必要決議要件にマッピング */
export function classifyResolutionType(p: ProposedResolution): ResolutionKind {
  switch (p) {
    case 'rebuild':
      return 'rebuild_4_5';
    case 'demolish_aged':
      return 'demolition_4_5';
    case 'change_rule':
    case 'major_common_change':
      return 'special_3_4';
    default:
      return 'ordinary';
  }
}

/** 出席者比率と賛成比率から議案が成立するかを判定 */
export function canPassResolution(p: {
  proposed: ProposedResolution;
  ownersForRatio: number;
  votesForRatio: number;
}): { passed: boolean; required: ResolutionKind; reason: string } {
  const required = classifyResolutionType(p.proposed);
  const t = RESOLUTION_THRESHOLDS[required];
  const passed = p.ownersForRatio >= t.ownersThreshold && p.votesForRatio >= t.votesThreshold;
  return {
    passed,
    required,
    reason: passed
      ? `成立 (要 区分所有者${t.ownersThreshold * 100}% & 議決権${t.votesThreshold * 100}%)`
      : `不成立 (要 ${t.ownersThreshold * 100}% / ${t.votesThreshold * 100}% を下回る)`,
  };
}

// ===== 長期修繕計画 + 大規模修繕周期 =====

export const LONG_TERM_REPAIR_CYCLES = {
  /** 計画期間 (国交省ガイドライン): 30 年以上 */
  planHorizonYears: 30,
  /** 大規模修繕の標準的な周期 (年) */
  largeScaleRepairCycleYears: 12,
  /** 計画見直し周期: 5年程度 */
  reviewCycleYears: 5,
  /** 主要部位ごとの修繕周期 (年) — 標準ガイドライン */
  partsCycle: {
    '屋根防水': 12,
    '外壁塗装': 12,
    '鉄部塗装': 4,
    '給水管(更生)': 15,
    '給水管(更新)': 30,
    '排水管(更新)': 30,
    'エレベーター(更新)': 25,
    '機械式駐車場(更新)': 20,
    'インターホン(更新)': 15,
  } as Record<string, number>,
} as const;

export interface RepairPlanItem {
  part: string;
  /** 前回実施年 */
  lastYear: number;
  /** 1回あたり概算費用 (円) */
  estimatedCostJpy: number;
}

export interface LongTermRepairPlan {
  baseYear: number;
  horizonYears: number;
  schedule: { year: number; part: string; estimatedCostJpy: number }[];
  totalCostJpy: number;
}

export function buildLongTermRepairPlan(p: {
  baseYear: number;
  items: RepairPlanItem[];
  horizonYears?: number;
}): LongTermRepairPlan {
  const horizon = p.horizonYears ?? LONG_TERM_REPAIR_CYCLES.planHorizonYears;
  const cycles = LONG_TERM_REPAIR_CYCLES.partsCycle;
  const schedule: LongTermRepairPlan['schedule'] = [];
  let total = 0;
  for (const it of p.items) {
    const cycleYears = cycles[it.part] ?? LONG_TERM_REPAIR_CYCLES.largeScaleRepairCycleYears;
    let year = it.lastYear + cycleYears;
    while (year < p.baseYear + horizon) {
      schedule.push({ year, part: it.part, estimatedCostJpy: it.estimatedCostJpy });
      total += it.estimatedCostJpy;
      year += cycleYears;
    }
  }
  schedule.sort((a, b) => a.year - b.year);
  return { baseYear: p.baseYear, horizonYears: horizon, schedule, totalCostJpy: total };
}

// ===== 修繕積立金 (R3 ガイドライン) =====

/**
 * R3 国交省ガイドライン: 専有面積 1m2 月額 (単位: 円)。
 * 機械式駐車場ありは別途加算。
 *
 * 階数 / 延床面積 区分の代表値:
 */
export const REPAIR_FUND_GUIDE_R3 = {
  /** 15階未満 / 5,000m2未満: 235円/m2/月 (中央値) */
  low_rise_small: 235,
  /** 15階未満 / 5,000-10,000m2: 252円/m2/月 */
  low_rise_medium: 252,
  /** 15階未満 / 10,000-20,000m2: 271円/m2/月 */
  low_rise_large: 271,
  /** 15階未満 / 20,000m2以上: 255円/m2/月 */
  low_rise_xlarge: 255,
  /** 20階以上: 338円/m2/月 */
  high_rise: 338,
} as const;

export type BuildingProfile = 'low_rise_small' | 'low_rise_medium' | 'low_rise_large' | 'low_rise_xlarge' | 'high_rise';

export function calcRecommendedRepairFundJpyPerM2Month(p: {
  profile: BuildingProfile;
  /** 機械式駐車場の台数 (1台あたり加算 7,085 円/月の想定 ÷ 専有面積分配) */
  mechanicalParkingUnits?: number;
  /** 全体の専有面積合計 (m2) — 駐車場按分計算用 */
  totalPrivateAreaM2?: number;
}): number {
  const base = REPAIR_FUND_GUIDE_R3[p.profile];
  if (!p.mechanicalParkingUnits || !p.totalPrivateAreaM2) return base;
  const parkingMonthlyTotal = p.mechanicalParkingUnits * 7085;
  const perM2Add = parkingMonthlyTotal / p.totalPrivateAreaM2;
  return Math.round(base + perM2Add);
}

// ===== マンション管理計画認定制度 (R4.4 施行) =====

export const MANAGEMENT_PLAN_CERT_CRITERIA = [
  '管理組合の運営が適正に行われている (理事会開催/総会決議)',
  '管理規約が標準管理規約に概ね沿っている',
  '管理組合の経理が区分経理されている',
  '長期修繕計画が30年以上 + 5年以内に見直し',
  '修繕積立金が長期修繕計画に基づき積み立てられている',
  '組合員名簿/居住者名簿が適切に整備されている',
] as const;

export interface ManagementPlanProfile {
  hasRegularBoardMeeting: boolean;
  hasStandardRule: boolean;
  hasSeparatedAccounting: boolean;
  longTermPlanYears: number;
  longTermPlanReviewedWithinYears: number;
  monthlyRepairFundPerM2: number;
  recommendedRepairFundPerM2: number;
  hasMemberRegister: boolean;
  hasResidentRegister: boolean;
}

export function canCertifyManagementPlan(p: ManagementPlanProfile): {
  certifiable: boolean;
  failedCriteria: string[];
} {
  const f: string[] = [];
  if (!p.hasRegularBoardMeeting) f.push('理事会・総会の運営');
  if (!p.hasStandardRule) f.push('標準管理規約準拠');
  if (!p.hasSeparatedAccounting) f.push('区分経理');
  if (p.longTermPlanYears < 30) f.push('長期修繕計画 30年以上');
  if (p.longTermPlanReviewedWithinYears > 5) f.push('長期修繕計画 5年以内見直し');
  if (p.monthlyRepairFundPerM2 < p.recommendedRepairFundPerM2 * 0.7)
    f.push('修繕積立金がガイドライン下限を下回る');
  if (!p.hasMemberRegister || !p.hasResidentRegister) f.push('組合員/居住者名簿整備');
  return { certifiable: f.length === 0, failedCriteria: f };
}

// ===== 滞納督促 (区分所有費・修繕積立金) =====

export const DELINQUENCY_PROCEDURES = [
  { stageMonths: 1, action: '電話・口頭での催促' },
  { stageMonths: 2, action: '督促状送付 (内容証明準備)' },
  { stageMonths: 3, action: '内容証明郵便で督促 + 配達証明' },
  { stageMonths: 6, action: '管理組合理事会で対応決議 + 弁護士相談' },
  { stageMonths: 12, action: '支払督促 / 少額訴訟 / 通常訴訟の検討' },
  { stageMonths: 24, action: '区分所有法59条の競売請求 (特別決議)' },
] as const;

export function nextDelinquencyAction(monthsOverdue: number): string {
  for (let i = DELINQUENCY_PROCEDURES.length - 1; i >= 0; i--) {
    if (monthsOverdue >= DELINQUENCY_PROCEDURES[i].stageMonths) {
      return DELINQUENCY_PROCEDURES[i].action;
    }
  }
  return '当月催告 (新規滞納)';
}

/** 管理費・修繕積立金の消滅時効: 民法改正 (R2.4) 後 5 年。承認・督促で時効更新。 */
export const DELINQUENCY_PRESCRIPTION_YEARS = 5;

// ===== 管理業務主任者 + マンション管理士 =====

export type ManagerQualification = 'management_business_manager' | 'mansion_management_consultant';

export const MANAGER_QUALIFICATIONS: Record<ManagerQualification, {
  label: string;
  legalDuty: string;
}> = {
  management_business_manager: {
    label: '管理業務主任者',
    legalDuty: '管理委託契約の重要事項説明・記名押印 (適正化法72条)',
  },
  mansion_management_consultant: {
    label: 'マンション管理士',
    legalDuty: '管理組合からの相談助言 (国家資格 / 登録制)',
  },
};

/** マンション管理業者は管理組合 30 組合に1名以上の管理業務主任者を設置 */
export function requireManagerQualification(p: { managedAssociations: number }): {
  required: number;
  qualification: ManagerQualification;
} {
  const required = Math.max(1, Math.ceil(p.managedAssociations / 30));
  return { required, qualification: 'management_business_manager' };
}

// ===== 建替え (62条) + 取壊し決議 =====

/** 建替え決議の同意要件 (区分所有者数+議決権 各 4/5 以上) */
export const REBUILD_CONSENT_THRESHOLD = { ownersRatio: 0.8, votesRatio: 0.8 };

export function canRebuildAged(p: {
  ownersForRatio: number;
  votesForRatio: number;
  isAgedOrIllegal: boolean;
  earthquakeRisk: boolean;
}): { passed: boolean; reason: string } {
  if (
    p.ownersForRatio >= REBUILD_CONSENT_THRESHOLD.ownersRatio &&
    p.votesForRatio >= REBUILD_CONSENT_THRESHOLD.votesRatio
  ) {
    return { passed: true, reason: '通常の建替え決議 (4/5)' };
  }
  // R3 改正建替え円滑化法: 耐震性不足 / 火災安全性不足 / 外壁剥離等で 4/5 (緩和議論あり、現行は 4/5)
  if ((p.isAgedOrIllegal || p.earthquakeRisk) && p.ownersForRatio >= 0.8 && p.votesForRatio >= 0.8) {
    return { passed: true, reason: '老朽化特例による建替え (R3 改正)' };
  }
  return { passed: false, reason: '4/5 未達 — 同意取得を継続' };
}
