/**
 * SoloptiLinkAI Phase 23 — サポートチケット管理 (Support Ticket)
 *
 * 問い合わせを起点とするチケットのライフサイクル管理。
 * inquiry_management.ts と組み合わせて、受付→チケット化→対応→クローズまで一気通貫。
 *
 * カバー範囲:
 *  - ステータス遷移マシン (state machine + 不正遷移防止)
 *  - 担当者アサイン + 工数記録
 *  - 顧客通知 (RFC2822 メール骨子 + 件名テンプレ)
 *  - SLA 連動 (inquiry_management の SlaStatus を取り込み)
 *  - 関連チケット (parent / linked)
 *  - 内部メモ vs 顧客向け返信の分離
 *  - 監査ログ (誰がいつ何を変更したか) — WORM 推奨
 */

import type { InquiryCategory, Priority, SlaStatus } from "./inquiry_management.ts";

export type TicketStatus =
  | "new"
  | "open"
  | "pending_customer"
  | "pending_internal"
  | "resolved"
  | "closed"
  | "reopened";

// 状態遷移表 (許可される次状態のみ列挙)
const TICKET_TRANSITIONS: Record<TicketStatus, TicketStatus[]> = {
  new: ["open", "closed"], // クローズ = スパム判定
  open: ["pending_customer", "pending_internal", "resolved", "closed"],
  pending_customer: ["open", "resolved", "closed"],
  pending_internal: ["open", "resolved"],
  resolved: ["reopened", "closed"],
  closed: ["reopened"],
  reopened: ["open", "resolved", "closed"],
};

export function canTransition(from: TicketStatus, to: TicketStatus): boolean {
  return TICKET_TRANSITIONS[from].includes(to);
}

export interface SupportTicket {
  ticket_id: string;
  inquiry_id: string;
  status: TicketStatus;
  priority: Priority;
  category: InquiryCategory;
  subject: string;
  customer_id?: string;
  customer_email?: string;
  assignee?: string;
  team?: "tier1" | "tier2" | "tier3" | "engineering" | "sales" | "billing";
  created_at: string;
  updated_at: string;
  resolved_at?: string;
  closed_at?: string;
  parent_ticket_id?: string;
  linked_ticket_ids?: string[];
  effort_hours?: number; // 累積工数
  csat_after_close?: 1 | 2 | 3 | 4 | 5;
}

export interface TicketMessage {
  message_id: string;
  ticket_id: string;
  author: string; // user_id or "system"
  audience: "internal" | "customer";
  body: string;
  ts: string;
  attachments?: { name: string; url: string }[];
}

export interface TicketEvent {
  event_id: string;
  ticket_id: string;
  actor: string;
  event_type: "status_change" | "assigned" | "priority_change" | "category_change" | "comment_added" | "csat_recorded";
  before?: unknown;
  after?: unknown;
  ts: string;
}

export class TicketTransitionError extends Error {
  constructor(public from: TicketStatus, public to: TicketStatus) {
    super(`Invalid transition: ${from} → ${to}`);
    this.name = "TicketTransitionError";
  }
}

export function applyTransition(
  ticket: SupportTicket,
  to: TicketStatus,
  actor: string,
  options: { reason?: string; ts?: string } = {},
): { ticket: SupportTicket; event: TicketEvent } {
  if (!canTransition(ticket.status, to)) {
    throw new TicketTransitionError(ticket.status, to);
  }
  const ts = options.ts ?? new Date().toISOString();
  const next: SupportTicket = {
    ...ticket,
    status: to,
    updated_at: ts,
    resolved_at: to === "resolved" ? ts : ticket.resolved_at,
    closed_at: to === "closed" ? ts : ticket.closed_at,
  };
  const event: TicketEvent = {
    event_id: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    ticket_id: ticket.ticket_id,
    actor,
    event_type: "status_change",
    before: ticket.status,
    after: to,
    ts,
  };
  return { ticket: next, event };
}

export function assign(
  ticket: SupportTicket,
  assignee: string,
  team: SupportTicket["team"],
  actor: string,
): { ticket: SupportTicket; event: TicketEvent } {
  const ts = new Date().toISOString();
  const next: SupportTicket = { ...ticket, assignee, team, updated_at: ts };
  const event: TicketEvent = {
    event_id: `evt_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    ticket_id: ticket.ticket_id,
    actor,
    event_type: "assigned",
    before: { assignee: ticket.assignee, team: ticket.team },
    after: { assignee, team },
    ts,
  };
  return { ticket: next, event };
}

export function addEffort(ticket: SupportTicket, hours: number): SupportTicket {
  return { ...ticket, effort_hours: (ticket.effort_hours ?? 0) + hours, updated_at: new Date().toISOString() };
}

// 顧客向けメール骨子 (RFC2822 ヘッダ風)
export interface OutboundEmail {
  to: string;
  from: string;
  subject: string;
  body: string;
  headers: Record<string, string>;
}

export const SUBJECT_TEMPLATES: Record<string, string> = {
  acknowledged: "【{company}】お問い合わせを受け付けました (#{ticket_id})",
  in_progress: "【{company}】お問い合わせの調査状況のご連絡 (#{ticket_id})",
  resolved: "【{company}】お問い合わせ解決のご報告 (#{ticket_id})",
  closed: "【{company}】お問い合わせクローズのご連絡 (#{ticket_id})",
  csat_request: "【{company}】お問い合わせ対応に関するご感想 (#{ticket_id})",
};

export function buildAcknowledgmentEmail(input: {
  ticket: SupportTicket;
  company_name: string;
  from_email: string;
  expected_first_response_iso?: string;
}): OutboundEmail {
  const subject = SUBJECT_TEMPLATES.acknowledged
    .replace("{company}", input.company_name)
    .replace("{ticket_id}", input.ticket.ticket_id);
  const expected = input.expected_first_response_iso
    ? `担当者から ${formatJpDateTime(input.expected_first_response_iso)} までにご連絡いたします。`
    : `担当者から順次ご連絡いたします。`;
  const body =
    `${input.ticket.customer_email} 様\n\n` +
    `お問い合わせいただきありがとうございます。\n` +
    `下記内容で受付いたしました。\n\n` +
    `■ チケット番号: ${input.ticket.ticket_id}\n` +
    `■ 件名: ${input.ticket.subject}\n` +
    `■ 受付日時: ${formatJpDateTime(input.ticket.created_at)}\n\n` +
    `${expected}\n\n` +
    `本メールへの返信は、本チケットへのコメントとして記録されます。\n` +
    `--\n${input.company_name} カスタマーサポート\n`;
  return {
    to: input.ticket.customer_email ?? "",
    from: input.from_email,
    subject,
    body,
    headers: {
      "Message-ID": `<${input.ticket.ticket_id}@${input.company_name.toLowerCase().replace(/\s+/g, "-")}>`,
      "X-SoloptiLinkAI-Ticket": input.ticket.ticket_id,
      "X-Auto-Response-Suppress": "OOF, AutoReply",
      "References": `<inquiry-${input.ticket.inquiry_id}@${input.company_name.toLowerCase().replace(/\s+/g, "-")}>`,
    },
  };
}

function formatJpDateTime(iso: string): string {
  const d = new Date(iso);
  return `${d.getFullYear()}年${d.getMonth() + 1}月${d.getDate()}日 ${String(d.getHours()).padStart(2, "0")}:${String(d.getMinutes()).padStart(2, "0")}`;
}

// 関連チケット解決: 親チケットが resolved で子チケット未解決があれば警告
export function checkParentChildConsistency(
  parent: SupportTicket,
  children: SupportTicket[],
): { consistent: boolean; warnings: string[] } {
  const warnings: string[] = [];
  if (parent.status === "resolved" || parent.status === "closed") {
    const open = children.filter((c) => !["resolved", "closed"].includes(c.status));
    if (open.length > 0) {
      warnings.push(`親 ${parent.ticket_id} は ${parent.status} だが、子 ${open.length} 件が未解決: ${open.map((c) => c.ticket_id).join(", ")}`);
    }
  }
  return { consistent: warnings.length === 0, warnings };
}

// チケット集計: 担当者別/カテゴリ別のSLA達成率
export interface TicketAggregation {
  total: number;
  by_status: Record<TicketStatus, number>;
  by_priority: Record<Priority, number>;
  resolved_within_sla: number;
  resolved_breach: number;
  sla_attainment_rate: number; // 0-1
  avg_resolution_hours: number | null;
}

export function aggregateTickets(
  tickets: SupportTicket[],
  slaLookup: (ticket: SupportTicket) => SlaStatus,
): TicketAggregation {
  const byStatus: Record<string, number> = {};
  const byPriority: Record<string, number> = {};
  let resolvedWithinSla = 0;
  let resolvedBreach = 0;
  let resolutionHoursSum = 0;
  let resolvedCount = 0;

  for (const t of tickets) {
    byStatus[t.status] = (byStatus[t.status] ?? 0) + 1;
    byPriority[t.priority] = (byPriority[t.priority] ?? 0) + 1;
    if (t.resolved_at) {
      resolvedCount += 1;
      const hours = (Date.parse(t.resolved_at) - Date.parse(t.created_at)) / (60 * 60 * 1000);
      resolutionHoursSum += hours;
      const sla = slaLookup(t);
      if (sla.breach === "none" || sla.breach === "warning") resolvedWithinSla += 1;
      else resolvedBreach += 1;
    }
  }

  const totalResolved = resolvedWithinSla + resolvedBreach;
  return {
    total: tickets.length,
    by_status: byStatus as Record<TicketStatus, number>,
    by_priority: byPriority as Record<Priority, number>,
    resolved_within_sla: resolvedWithinSla,
    resolved_breach: resolvedBreach,
    sla_attainment_rate: totalResolved === 0 ? 0 : Number((resolvedWithinSla / totalResolved).toFixed(3)),
    avg_resolution_hours: resolvedCount > 0 ? Number((resolutionHoursSum / resolvedCount).toFixed(1)) : null,
  };
}
