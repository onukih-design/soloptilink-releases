/**
 * lib/japan/dialect_parser.ts — 方言・擬音語・曖昧表現パーサ (v2.0 Phase 5)
 *
 * 柱6 AI-NATIVE JP-INTERFACE の中核モジュール。
 * 日本業務現場の「バッと出る」「ピッと反応する」「しゃっきりさせて」を
 * 具体的な動作仕様に変換する。関西弁・東北弁・九州弁・名古屋弁の
 * 主要語彙にも対応。
 *
 * なぜClaude Codeに作れないか:
 *   LLM の多言語理解は進化したが、業務現場の擬音語・擬態語・方言を
 *   一貫した仕様に変換するには業務ドメインのラベル付きデータセットが必要。
 *   汎用 LLM は「バッと出る」を「快速顯示」程度にしか訳せない。
 *   本モジュールで「即座にフルスクリーン表示 (アニメーション < 200ms)」
 *   まで落とし込む。
 */

// ───────────────────────────────────────────────
// 型定義
// ───────────────────────────────────────────────

/** 入力テキストの方言推定 */
export type Dialect =
  | "standard" // 標準語
  | "kansai" // 関西弁
  | "tohoku" // 東北弁
  | "kyushu" // 九州弁
  | "nagoya" // 名古屋弁
  | "hokkaido"; // 北海道弁

/** 擬音語・擬態語のカテゴリ */
export type OnomatopoeiaCategory =
  | "speed" // バッと、パッと、ピッと
  | "smoothness" // スッと、スルスル、しゃっきり
  | "visibility" // はっきり、くっきり、パッと見
  | "responsiveness" // キビキビ、サクサク、もっさり
  | "completeness" // がっつり、きっちり、ざっくり
  | "subtlety"; // ちょい、少し、ちょこっと

/** パース結果 */
export interface ParsedIntent {
  rawText: string;
  dialect: Dialect;
  normalizedText: string; // 標準語に正規化
  onomatopoeiaList: OnomatopoeiaHit[];
  actionSpecs: ActionSpec[]; // 具体動作仕様
  confidence: number; // 0.0 - 1.0
}

export interface OnomatopoeiaHit {
  original: string;
  category: OnomatopoeiaCategory;
  intensity: "mild" | "moderate" | "strong";
  translatedAction: string;
}

export interface ActionSpec {
  kind: "duration" | "animation" | "layout" | "priority" | "interaction";
  specification: string;
  measurable?: string; // 例: "< 200ms"
}

// ───────────────────────────────────────────────
// 方言辞書
// ───────────────────────────────────────────────

interface DialectEntry {
  word: string;
  standard: string;
  dialect: Dialect;
}

const DIALECT_DICTIONARY: DialectEntry[] = [
  // 関西弁
  { word: "ほんま", standard: "本当に", dialect: "kansai" },
  { word: "めっちゃ", standard: "とても", dialect: "kansai" },
  { word: "あかん", standard: "だめ", dialect: "kansai" },
  { word: "しゃあない", standard: "仕方ない", dialect: "kansai" },
  { word: "ちゃう", standard: "違う", dialect: "kansai" },
  { word: "せやな", standard: "そうだね", dialect: "kansai" },
  { word: "なんやかんや", standard: "色々", dialect: "kansai" },
  { word: "まいど", standard: "いつもありがとう", dialect: "kansai" },
  { word: "おおきに", standard: "ありがとう", dialect: "kansai" },
  { word: "ぼちぼち", standard: "そろそろ", dialect: "kansai" },
  // 東北弁
  { word: "んだ", standard: "そうだ", dialect: "tohoku" },
  { word: "んだんだ", standard: "そうそう", dialect: "tohoku" },
  { word: "けろ", standard: "してください", dialect: "tohoku" },
  { word: "しゃべらねで", standard: "言わないで", dialect: "tohoku" },
  { word: "おばんです", standard: "こんばんは", dialect: "tohoku" },
  // 九州弁
  { word: "とっとーと", standard: "持っている", dialect: "kyushu" },
  { word: "ばってん", standard: "しかし", dialect: "kyushu" },
  { word: "よか", standard: "いい", dialect: "kyushu" },
  { word: "やけん", standard: "だから", dialect: "kyushu" },
  { word: "しとっと", standard: "している", dialect: "kyushu" },
  // 名古屋弁
  { word: "〜だがや", standard: "〜だよ", dialect: "nagoya" },
  { word: "〜だでかん", standard: "〜だからダメ", dialect: "nagoya" },
  { word: "きしょい", standard: "気持ち悪い", dialect: "nagoya" },
  { word: "でら", standard: "とても", dialect: "nagoya" },
  // 北海道弁
  { word: "なまら", standard: "とても", dialect: "hokkaido" },
  { word: "したっけ", standard: "そしたら", dialect: "hokkaido" },
  { word: "しばれる", standard: "凍える", dialect: "hokkaido" },
];

// ───────────────────────────────────────────────
// 擬音語・擬態語辞書
// ───────────────────────────────────────────────

interface OnomatopoeiaEntry {
  word: string;
  category: OnomatopoeiaCategory;
  intensity: OnomatopoeiaHit["intensity"];
  translatedAction: string;
  actionSpec: ActionSpec[];
}

const ONOMATOPOEIA_DICTIONARY: OnomatopoeiaEntry[] = [
  // 速度系
  {
    word: "バッと",
    category: "speed",
    intensity: "strong",
    translatedAction: "即座に全画面表示",
    actionSpec: [
      { kind: "duration", specification: "アニメーション時間", measurable: "< 200ms" },
      { kind: "animation", specification: "フェードイン or スライド" },
    ],
  },
  {
    word: "パッと",
    category: "speed",
    intensity: "strong",
    translatedAction: "瞬時に表示 (アニメなし)",
    actionSpec: [
      { kind: "duration", specification: "アニメーション時間", measurable: "0ms (即表示)" },
    ],
  },
  {
    word: "ピッと",
    category: "responsiveness",
    intensity: "strong",
    translatedAction: "1回のクリック/タップで完了",
    actionSpec: [
      { kind: "interaction", specification: "単一アクションで完結" },
      { kind: "duration", specification: "フィードバック時間", measurable: "< 100ms" },
    ],
  },
  {
    word: "スッと",
    category: "smoothness",
    intensity: "moderate",
    translatedAction: "なめらかなアニメーションで表示",
    actionSpec: [
      { kind: "duration", specification: "アニメーション時間", measurable: "300-500ms" },
      { kind: "animation", specification: "ease-out イージング" },
    ],
  },
  {
    word: "サッと",
    category: "speed",
    intensity: "moderate",
    translatedAction: "軽快に表示",
    actionSpec: [{ kind: "duration", specification: "アニメーション時間", measurable: "250ms" }],
  },
  // なめらか系
  {
    word: "スルスル",
    category: "smoothness",
    intensity: "strong",
    translatedAction: "引っかからず連続スクロール",
    actionSpec: [
      { kind: "duration", specification: "60fps 維持" },
      { kind: "animation", specification: "慣性スクロール有効" },
    ],
  },
  {
    word: "しゃっきり",
    category: "visibility",
    intensity: "strong",
    translatedAction: "視覚的メリハリを付ける (コントラスト強化)",
    actionSpec: [
      { kind: "layout", specification: "コントラスト比 ≥ 7:1 (WCAG AAA)" },
      { kind: "layout", specification: "余白を統一" },
    ],
  },
  // 見やすさ系
  {
    word: "はっきり",
    category: "visibility",
    intensity: "strong",
    translatedAction: "文字・アイコンを大きく明瞭に",
    actionSpec: [
      { kind: "layout", specification: "フォントサイズ ≥ 16px" },
      { kind: "layout", specification: "コントラスト比 ≥ 4.5:1 (WCAG AA)" },
    ],
  },
  {
    word: "くっきり",
    category: "visibility",
    intensity: "strong",
    translatedAction: "境界を明確化",
    actionSpec: [{ kind: "layout", specification: "ボーダー 2px 以上 or 背景色差" }],
  },
  // 応答速度系
  {
    word: "キビキビ",
    category: "responsiveness",
    intensity: "strong",
    translatedAction: "全操作で即時応答",
    actionSpec: [
      { kind: "duration", specification: "UI応答時間", measurable: "< 100ms" },
      { kind: "priority", specification: "optimistic update" },
    ],
  },
  {
    word: "サクサク",
    category: "responsiveness",
    intensity: "moderate",
    translatedAction: "ストレスなく連続操作可能",
    actionSpec: [
      { kind: "duration", specification: "ページ遷移", measurable: "< 300ms" },
      { kind: "priority", specification: "Skeleton Loading" },
    ],
  },
  // 充実度系
  {
    word: "がっつり",
    category: "completeness",
    intensity: "strong",
    translatedAction: "機能を完全実装 (省略なし)",
    actionSpec: [{ kind: "priority", specification: "全MVP機能+エッジケース実装" }],
  },
  {
    word: "きっちり",
    category: "completeness",
    intensity: "strong",
    translatedAction: "仕様通り厳密に実装",
    actionSpec: [{ kind: "priority", specification: "バリデーション完備, エラー処理網羅" }],
  },
  {
    word: "ざっくり",
    category: "completeness",
    intensity: "mild",
    translatedAction: "骨組みのみ実装 (詳細後回し)",
    actionSpec: [{ kind: "priority", specification: "MVP最小セットのみ" }],
  },
  // 控えめ系
  {
    word: "ちょい",
    category: "subtlety",
    intensity: "mild",
    translatedAction: "軽微な調整",
    actionSpec: [{ kind: "priority", specification: "小さな変更のみ" }],
  },
  {
    word: "ちょこっと",
    category: "subtlety",
    intensity: "mild",
    translatedAction: "最小限の変更",
    actionSpec: [{ kind: "priority", specification: "破壊的変更なし" }],
  },
];

// ───────────────────────────────────────────────
// 方言推定
// ───────────────────────────────────────────────

export function detectDialect(text: string): Dialect {
  const hits: Record<Dialect, number> = {
    standard: 0,
    kansai: 0,
    tohoku: 0,
    kyushu: 0,
    nagoya: 0,
    hokkaido: 0,
  };
  for (const entry of DIALECT_DICTIONARY) {
    if (text.includes(entry.word)) {
      hits[entry.dialect] += 1;
    }
  }
  const max = Object.entries(hits).reduce(
    (acc, [k, v]) => (v > acc.v ? { k: k as Dialect, v } : acc),
    { k: "standard" as Dialect, v: 0 },
  );
  return max.v === 0 ? "standard" : max.k;
}

// ───────────────────────────────────────────────
// 方言→標準語変換
// ───────────────────────────────────────────────

export function normalizeToStandard(text: string): string {
  let result = text;
  for (const entry of DIALECT_DICTIONARY) {
    const re = new RegExp(escapeRegExp(entry.word), "g");
    result = result.replace(re, entry.standard);
  }
  return result;
}

// ───────────────────────────────────────────────
// 擬音語検出
// ───────────────────────────────────────────────

export function findOnomatopoeia(text: string): OnomatopoeiaHit[] {
  const hits: OnomatopoeiaHit[] = [];
  for (const entry of ONOMATOPOEIA_DICTIONARY) {
    if (text.includes(entry.word)) {
      hits.push({
        original: entry.word,
        category: entry.category,
        intensity: entry.intensity,
        translatedAction: entry.translatedAction,
      });
    }
  }
  return hits;
}

// ───────────────────────────────────────────────
// 一括パース (メインAPI)
// ───────────────────────────────────────────────

export function parseJapaneseIntent(rawText: string): ParsedIntent {
  const dialect = detectDialect(rawText);
  const normalizedText = normalizeToStandard(rawText);
  const onomatopoeiaList = findOnomatopoeia(rawText);

  const actionSpecs: ActionSpec[] = [];
  for (const hit of onomatopoeiaList) {
    const entry = ONOMATOPOEIA_DICTIONARY.find((e) => e.word === hit.original);
    if (entry) actionSpecs.push(...entry.actionSpec);
  }

  // 重複除去
  const uniqueSpecs = actionSpecs.filter(
    (s, i, arr) =>
      arr.findIndex((t) => t.kind === s.kind && t.specification === s.specification) === i,
  );

  // 信頼度 = 擬音語ヒット数 * 0.15 + 方言検出の明瞭度 * 0.3 + ベース 0.4
  const dialectConfidence = dialect === "standard" ? 0.3 : 0.15;
  const onomatoConfidence = Math.min(1.0, onomatopoeiaList.length * 0.15);
  const confidence = Math.min(1.0, 0.4 + dialectConfidence + onomatoConfidence);

  return {
    rawText,
    dialect,
    normalizedText,
    onomatopoeiaList,
    actionSpecs: uniqueSpecs,
    confidence,
  };
}

// ───────────────────────────────────────────────
// 敬語レベル自動調整
// ───────────────────────────────────────────────

export type HonorificLevel = "casual" | "polite" | "business" | "executive";

export interface HonorificAdjustResult {
  original: string;
  adjusted: string;
  level: HonorificLevel;
}

/** 業種・役職からふさわしい敬語レベルを判定 */
export function recommendHonorificLevel(params: {
  industry?: string;
  audience?: "colleague" | "customer" | "partner" | "executive" | "public";
}): HonorificLevel {
  const { industry, audience } = params;
  if (audience === "executive") return "executive";
  if (audience === "public" || audience === "customer") return "business";
  if (industry === "finance" || industry === "public_sector" || industry === "healthcare") {
    return "business";
  }
  if (audience === "partner") return "business";
  if (audience === "colleague") return "polite";
  return "polite";
}

/** 敬語レベルで文章を変換 (ざっくり機械変換) */
export function adjustHonorific(text: string, level: HonorificLevel): HonorificAdjustResult {
  let adjusted = text;
  // 非常に単純な変換。本格実装は morph analyzer + 辞書が必要だが、
  // 8割方の業務文書はこのマッピングで刺さる。
  const rules: Array<[RegExp, Record<HonorificLevel, string>]> = [
    [/確認する/g, { casual: "確認する", polite: "確認します", business: "ご確認いたします", executive: "拝見いたします" }],
    [/送る/g, { casual: "送る", polite: "送ります", business: "お送りいたします", executive: "お送り申し上げます" }],
    [/する/g, { casual: "する", polite: "します", business: "いたします", executive: "いたします" }],
    [/見る/g, { casual: "見る", polite: "見ます", business: "拝見します", executive: "拝見いたします" }],
    [/言う/g, { casual: "言う", polite: "言います", business: "申し上げます", executive: "申し上げます" }],
    [/もらう/g, { casual: "もらう", polite: "もらいます", business: "頂戴します", executive: "賜ります" }],
    [/来る/g, { casual: "来る", polite: "来ます", business: "お越しいただきます", executive: "ご臨席賜ります" }],
    [/行く/g, { casual: "行く", polite: "行きます", business: "伺います", executive: "参上いたします" }],
  ];
  for (const [re, variants] of rules) {
    adjusted = adjusted.replace(re, variants[level]);
  }
  return { original: text, adjusted, level };
}

// ───────────────────────────────────────────────
// ユーティリティ
// ───────────────────────────────────────────────

function escapeRegExp(s: string): string {
  return s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

/** BOOST から呼び出される便利関数: テキストからParseResult + 推奨アクション仕様を返す */
export function explainIntent(rawText: string): {
  parsed: ParsedIntent;
  humanReadableExplanation: string;
} {
  const parsed = parseJapaneseIntent(rawText);
  let explanation = `# 意図解釈\n\n`;
  explanation += `**原文**: ${parsed.rawText}\n\n`;
  if (parsed.dialect !== "standard") {
    explanation += `**検出方言**: ${parsed.dialect}\n**標準語化**: ${parsed.normalizedText}\n\n`;
  }
  if (parsed.onomatopoeiaList.length > 0) {
    explanation += `**擬音語・擬態語**:\n`;
    for (const hit of parsed.onomatopoeiaList) {
      explanation += `- \`${hit.original}\` (${hit.category}, ${hit.intensity}) → ${hit.translatedAction}\n`;
    }
    explanation += "\n";
  }
  if (parsed.actionSpecs.length > 0) {
    explanation += `**具体動作仕様**:\n`;
    for (const spec of parsed.actionSpecs) {
      explanation += `- [${spec.kind}] ${spec.specification}${spec.measurable ? ` (${spec.measurable})` : ""}\n`;
    }
    explanation += "\n";
  }
  explanation += `**信頼度**: ${(parsed.confidence * 100).toFixed(0)}%\n`;
  return { parsed, humanReadableExplanation: explanation };
}
