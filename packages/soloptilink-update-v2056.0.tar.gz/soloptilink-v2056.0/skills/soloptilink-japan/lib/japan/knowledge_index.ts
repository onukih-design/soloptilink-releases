/**
 * knowledge_index.ts — 日本全知識インデックス (Phase 9)
 *
 * 「日本のすべての知識が入っている状態」を実現するための索引。
 * 建築/法令/帳票/業界慣行/技術標準/季節行事/敬語/歴史等、
 * 別モジュールに分散されている日本土着知識を 1 ファイルから辿れるようにする。
 *
 * 使い方:
 *   import { KNOWLEDGE_INDEX, listKnowledgeByTopic, lookupTerminology } from '@/lib/japan/knowledge_index';
 *   const drawing = KNOWLEDGE_INDEX.find(k => k.topic === 'drawings');
 *   const kyoto = lookupTerminology('京町家');
 */

export type KnowledgeTopic =
  | 'laws_20'                // 20法令DNA (laws.ts + laws_extended.ts)
  | 'drawings'               // 建築図面 (drawings.ts)
  | 'architecture'           // 建築知識 (architecture.ts)
  | 'estimates'              // 概算見積もり (estimates.ts)
  | 'regional_laws'          // 全国地域条例 (regional_laws.ts)
  | 'tax'                    // 税制 (消費税/インボイス/電帳法)
  | 'bug_prevention'         // バグ予防DNA P1-P25
  | 'reports'                // 20帳票 (templates/japan)
  | 'industries'             // 20業種ドメイン辞書 (domains)
  | 'keigo'                  // 敬語/御中/様/殿
  | 'calendar'               // 和暦/元号/祝祭日/二十四節気
  | 'ui'                     // 日本UX (半角全角/印影/封筒窓/郵便番号)
  | 'business_custom'        // 印鑑/決裁/稟議/株主総会/社内通達
  | 'construction_custom'    // 建設業慣行 (下請け構造/着工式/上棟式)
  | 'food_custom'            // 飲食業慣行 (HACCP/アレルゲン/食品表示)
  | 'medical_custom'         // 医療慣行 (レセプト/電子カルテ/介護給付)
  | 'retail_custom'          // 小売慣行 (ポイント/景品/ECモール)
  | 'logistics_custom'       // 物流慣行 (運賃タリフ/特積/貸切/積荷保険)
  | 'real_estate_custom'     // 不動産慣行 (重説/媒介/35条/37条書面/公取)
  | 'finance_custom'         // 金融慣行 (金商法/電帳法/監査対応)
  | 'hr_custom'              // 人事労務慣行 (36協定/就業規則/育介/派遣)
  | 'seasonal'               // 季節行事 (お盆/正月/お中元/お歳暮)
  | 'jis_jas'                // JIS/JAS規格
  | 'postal_address';        // 郵便番号/住所表記

export interface KnowledgeRef {
  topic: KnowledgeTopic;
  label_ja: string;
  /** 実体ファイル (相対パス) */
  source: string;
  /** 参照 API / export */
  api?: string[];
  /** 対 Claude Code 差別化ポイント */
  edge: string;
}

export const KNOWLEDGE_INDEX: ReadonlyArray<KnowledgeRef> = Object.freeze([
  { topic: 'laws_20', label_ja: '20法令DNA', source: 'lib/japan/laws.ts + lib/japan/laws_extended.ts',
    api: ['Invoice', 'EBook', 'APPI', 'MyNumber', 'LaborStandards', 'Shitauke', 'Kenchiku', 'FIEA', 'PL', 'KeihyoHo', 'TokushoHo', 'FoodSanitation', 'FoodLabeling', 'Yakkiho', 'RyokanGyo', 'TakkenGyo', 'JidoFukushi', 'AnzenEisei', 'IkujiKaigo', 'HakenHou'],
    edge: 'Claude Code は各業界の法令を個別に説明できるが、業務コードに自動統合する DNA として提供しない' },
  { topic: 'drawings', label_ja: '建築図面 (1級建築士級)', source: 'lib/japan/drawings.ts + drawings/',
    api: ['generateSitePlan', 'generateFloorPlan', 'generateElevation', 'generateSection', 'generateDetailSection', 'generateFoundationPlan', 'generateDoorWindowSchedule', 'buildDrawingSet', 'exportMinimalDxf'],
    edge: '配置図/平面図/立面図/断面図/矩計図/建具表/基礎伏図を SVG (JIS A 0150 線種準拠) で生成。Claude Code は 1 枚も書けない' },
  { topic: 'architecture', label_ja: '建築知識 (建築基準法/建築士法/構造/省エネ)', source: 'lib/japan/architecture.ts',
    api: ['USE_DISTRICTS', 'canBuildUse', 'calcFloorAreaRatioByRoad', 'calcBuildingCoverageWithRelief', 'checkAbsoluteHeight', 'calcNorthernSlopeLimit', 'calcRoadSlopeLimit', 'calcAdjacentSlopeLimit', 'getShadowRegulation', 'determineStructureRoute', 'calcRequiredWallQuantityWood', 'requiredFireResistance', 'requires2WayEvacuation', 'maxEvacuationDistanceM', 'canDesign', 'buildPermitFlow', 'checkEnergyCompliance', 'analyzeSiteBuildable', 'JIS_STANDARDS'],
    edge: '用途地域13種×建ぺい率×容積率×斜線×日影×構造ルート×省エネ地域区分を型付きで判定。建築士の実務知識' },
  { topic: 'estimates', label_ja: '概算見積もりエンジン', source: 'lib/japan/estimates.ts + estimates/unit_prices.json',
    api: ['calcRoughEstimate', 'calcDetailedEstimate', 'estimateStandardQuantities', 'buildBreakdown', 'validateUnitPriceDb', 'TSUBO_UNIT_PRICE', 'USE_COEFFICIENT'],
    edge: '坪単価マトリクス×用途係数×地域係数×詳細積算(13カテゴリ×80+品目)×共通仮設/現場管理/一般管理/消費税まで一気通貫' },
  { topic: 'regional_laws', label_ja: '全国47都道府県+主要市町村条例', source: 'lib/japan/regional_laws.ts + regions/47prefectures/index.json',
    api: ['getPrefectureLaws', 'resolveApplicableOrdinances', 'checkLocationCompliance', 'categorizeOrdinance', 'MAJOR_CITY_ORDINANCES'],
    edge: '47都道府県×20+主要市町村の景観/伝建/屋外広告/米軍進入表面/豪雪/火山灰/津波対策を所在地から自動引き当て' },
  { topic: 'tax', label_ja: '消費税/インボイス/電帳法', source: 'lib/japan/bug_prevention.ts + lib/japan/laws.ts',
    api: ['calcTax', 'groupAndCalcTax', 'formatYen', 'parseYen', 'Invoice', 'EBook'],
    edge: '税率ごと1回丸め、軽減税率8%/標準10%の区分、インボイス登録番号T+13桁、電帳法タイムスタンプをコードレベルで統合' },
  { topic: 'bug_prevention', label_ja: 'バグ予防DNA 25パターン (P1-P25)', source: 'lib/japan/save_guarantee.ts + bug_prevention.ts + bug_prevention_ext.ts',
    api: ['SaveGuarantee', 'diagnoseSaveFailure', 'buildOptimisticWhere', 'generateIdempotencyKey', 'truncateSafe', 'jstToUtcIso', 'calcTax', 'groupAndCalcTax', 'toCsvJP', 'normalizePhoneJP', 'formatPhoneJP', 'normalizePostalJP', 'attachHonorific', 'calcPaymentDueDate', 'createSubmitGuard', 'acquireStockOptimistic', 'verifyCsrf', 'validateUploadFile', 'sanitizePaging', 'hintRequiredIncludes', 'RateLimiter', 'normalizeSearchKeyword', 'checkA4Safety', 'sendEmailOnce'],
    edge: '日本の業務バグ頻発25パターン (保存失敗/二重送信/在庫/CSRF/アップロード/検索/A4/メール重送) の予防を型で強制' },
  { topic: 'reports', label_ja: '20種帳票テンプレ', source: 'templates/japan/',
    api: ['Invoice', 'Estimate', 'PurchaseOrder', 'DeliveryNote', 'Receipt', 'InspectionReport', 'WorkOrder', 'PaymentNotice', 'WithholdingSlip', 'PaymentStatement', 'Contract', 'NDA', 'OutsourcingAgreement', 'Memorandum', 'Notification', 'ConfirmationLetter', 'Application', 'Report', 'Minutes', 'InternalNotice'],
    edge: 'A4 縦横/封筒窓位置/印影/御中/様/殿/インボイス番号/軽減税率記載を JIS 準拠で即出力' },
  { topic: 'industries', label_ja: '20業種ドメイン辞書', source: 'domains/',
    api: ['construction', 'manufacturing', 'medical', 'care', 'dental', 'legal', 'tax_accountant', 'retail', 'restaurant', 'logistics', 'real_estate', 'it_ses', 'salon', 'gym', 'education', 'childcare', 'agriculture', 'hotel', 'wedding', 'printing'],
    edge: '業界用語/必須項目/典型KPI/推奨帳票/適用法令まで辞書化' },
  { topic: 'keigo', label_ja: '敬語/宛名表記', source: 'lib/japan/keigo.ts',
    api: ['attachHonorific', 'organizationHonorific'],
    edge: '会社名→御中、個人名→様、役職宛→殿、故人→故○○様の書き分け' },
  { topic: 'calendar', label_ja: '和暦/元号/祝祭日/二十四節気', source: 'lib/japan/wareki.ts',
    api: ['toWareki', 'fromWareki', 'NationalHolidays', 'isBusinessDay', 'Sekki24'],
    edge: '令和/平成/昭和変換、祝日/振替休日/国民の休日、月の異名(睦月〜師走)' },
  { topic: 'ui', label_ja: '日本UX (半角全角/印影/郵便/封筒窓)', source: 'components/japan/ + lib/japan/hanzen.ts, postal.ts',
    api: ['HanzenInput', 'InshoRenderer', 'PostalInput', 'EnvelopeWindow', 'normalizePostalJP'],
    edge: 'カタカナ全角→半角、〒郵便番号検索連動、窓付封筒位置合わせ' },
  { topic: 'business_custom', label_ja: '日本商習慣 (印鑑/稟議/決裁/社内通達)', source: 'templates/japan/Ringi.tsx + InternalNotice.tsx',
    api: ['RingiTemplate', 'InternalNoticeTemplate', 'StampPlacement'],
    edge: '稟議書は A4 縦/承認欄 5 列 (起案-係長-課長-部長-役員)、社内通達は発信元+受信対象区分' },
  { topic: 'construction_custom', label_ja: '建設業慣行', source: 'domains/construction.json + lib/japan/laws.ts::Kenchiku',
    api: ['constructionDomain', 'Shitauke', 'Kenchiku', 'AnzenEisei'],
    edge: '元請-一次-二次-三次の多層下請け、下請法 60 日ルール、着工祭・上棟式、JV 協定、共同企業体' },
  { topic: 'food_custom', label_ja: '飲食業慣行 (HACCP/アレルゲン/食品表示)', source: 'lib/japan/laws_extended.ts::FoodSanitation + FoodLabeling + domains/food-service.json',
    api: ['FoodSanitation', 'FoodLabeling', 'checkMenuCompliance'],
    edge: '特定原材料8品目/特定原材料に準ずるもの20品目/栄養成分表示/原料原産地/機能性表示' },
  { topic: 'medical_custom', label_ja: '医療慣行 (レセプト/電子カルテ/診療報酬)', source: 'domains/medical.json + lib/japan/laws.ts::APPI',
    api: ['medicalDomain', 'APPI'],
    edge: '診療報酬点数 2 年改定、DPC/PDPS、レセプト電子請求、オンライン資格確認' },
  { topic: 'retail_custom', label_ja: '小売慣行 (ポイント/景品/ECモール)', source: 'domains/retail.json + lib/japan/laws_extended.ts::KeihyoHo',
    api: ['retailDomain', 'KeihyoHo', 'checkCampaignPrize'],
    edge: '一般懸賞 / 総付景品 / 共同懸賞の上限額、景表法優良誤認/有利誤認、ポイント返還規程' },
  { topic: 'logistics_custom', label_ja: '物流慣行 (運賃タリフ/特積/貸切)', source: 'domains/logistics.json',
    api: ['logisticsDomain'],
    edge: '一般貨物自動車運送事業/貸切/特別積合せ/宅配便、運賃タリフ (距離制・重量制)、改善基準告示' },
  { topic: 'real_estate_custom', label_ja: '不動産慣行 (重説/35条/37条/媒介)', source: 'domains/real_estate.json + lib/japan/laws_extended.ts::TakkenGyo',
    api: ['realEstateDomain', 'TakkenGyo'],
    edge: '重要事項説明書(35条書面)/契約書(37条書面)、媒介契約 3 種(一般/専任/専属専任)、報酬規定 3%+6万円' },
  { topic: 'finance_custom', label_ja: '金融慣行 (金商法/電帳法)', source: 'lib/japan/laws.ts::FIEA + EBook',
    api: ['FIEA', 'EBook'],
    edge: '内部統制報告(J-SOX)、有価証券報告書、適時開示、電帳法タイムスタンプ要件' },
  { topic: 'hr_custom', label_ja: '人事労務慣行 (36協定/就業規則/育介/派遣)', source: 'lib/japan/laws.ts::LaborStandards + laws_extended.ts::IkujiKaigo + HakenHou',
    api: ['LaborStandards', 'IkujiKaigo', 'HakenHou'],
    edge: '36協定限度時間/特別条項、フレックス/みなし労働、育児休業/介護休業、派遣 3 年ルール' },
  { topic: 'seasonal', label_ja: '季節行事 (お盆/正月/お中元/お歳暮)', source: 'lib/japan/wareki.ts',
    api: ['isNationalHoliday', 'SeasonalEvents'],
    edge: 'お盆8/13-16、お正月休業1/1-3、お中元/お歳暮時期、年度替わり3月末/4月、冬至/夏至' },
  { topic: 'jis_jas', label_ja: 'JIS/JAS規格索引', source: 'lib/japan/architecture.ts::JIS_STANDARDS',
    api: ['JIS_STANDARDS'],
    edge: 'コンクリート/鋼材/サッシ/合板/仕上塗材 の JIS 主要規格 を 1 行で引ける' },
  { topic: 'postal_address', label_ja: '郵便番号/住所表記', source: 'lib/japan/postal.ts',
    api: ['normalizePostalJP', 'lookupAddress'],
    edge: '〒123-4567 正規化、都道府県-市区町村-町丁字-番地-号、ビル名別行、半角/全角統一' },
]);

export interface TerminologyEntry {
  term: string;
  reading?: string;
  category: string;
  definition: string;
  edge?: string;
}

/**
 * 主要日本用語辞書 (抜粋)。実際の domains/ には業種別にもっと詳細な用語DB がある。
 * ここは横断的によく問合せられるものを索引化。
 */
export const JAPAN_TERMINOLOGY: ReadonlyArray<TerminologyEntry> = Object.freeze([
  { term: '御中', reading: 'おんちゅう', category: 'keigo', definition: '組織宛ての敬称。「○○会社御中」のように使う。個人宛ては「様」' },
  { term: '様', reading: 'さま', category: 'keigo', definition: '個人宛の一般的敬称' },
  { term: '殿', reading: 'どの', category: 'keigo', definition: '役職宛や目下の相手への文書的敬称。「部長殿」等' },
  { term: '貴社', reading: 'きしゃ', category: 'keigo', definition: '書面で相手方の会社を敬って指す (口語は「御社」)' },
  { term: '御社', reading: 'おんしゃ', category: 'keigo', definition: '口頭で相手方の会社を敬って指す (書面は「貴社」)' },
  { term: 'インボイス', reading: 'いんぼいす', category: 'tax', definition: '適格請求書。2023/10 から登録番号 T+13桁が必要' },
  { term: '電帳法', reading: 'でんちょうほう', category: 'tax', definition: '電子帳簿保存法。2024/1 から電子取引データは電子のまま保存必須' },
  { term: 'マイナンバー', reading: 'まいなんばー', category: 'privacy', definition: '個人番号。利用目的を法定事由に限定 + 取扱規程必須' },
  { term: '36協定', reading: 'さぶろくきょうてい', category: 'labor', definition: '労基法36条に基づく時間外労働協定。限度時間あり (月45h/年360h)' },
  { term: '稟議書', reading: 'りんぎしょ', category: 'business', definition: '組織内承認文書。起案→係長→課長→部長→役員の順で押印/電子承認' },
  { term: '着工式', reading: 'ちゃっこうしき', category: 'construction', definition: '工事着手前の神事(地鎮祭と類似)。施主・施工者・設計者参列' },
  { term: '上棟式', reading: 'じょうとうしき', category: 'construction', definition: '棟木を上げる際の祝儀。木造/鉄骨の骨組みが組まれた時点' },
  { term: '御祝儀', reading: 'ごしゅうぎ', category: 'construction', definition: '上棟式で大工衆に渡す金銭。棟梁/職長で差をつけるのが慣例' },
  { term: '坪', reading: 'つぼ', category: 'construction', definition: '約3.3058㎡。一坪=1.8m×1.8m (2間×1間)。坪単価で建築費を見積' },
  { term: '畳', reading: 'じょう', category: 'construction', definition: '部屋の広さ単位。江戸間(約1.548㎡) / 京間(約1.824㎡) / 団地間など地域差あり' },
  { term: '間', reading: 'けん', category: 'construction', definition: '長さの単位。1間=1.818m(6尺)。柱間スパンの基準' },
  { term: '尺', reading: 'しゃく', category: 'construction', definition: '長さの単位。1尺=303mm(10寸)。木造では尺モジュールが主流' },
  { term: '確認申請', reading: 'かくにんしんせい', category: 'construction', definition: '建築基準法6条に基づく事前審査。特定行政庁/指定確認検査機関に提出' },
  { term: '完了検査', reading: 'かんりょうけんさ', category: 'construction', definition: '工事完了後の適法検査。検査済証が交付されないと使用不可' },
  { term: '建ぺい率', reading: 'けんぺいりつ', category: 'construction', definition: '敷地面積に対する建築面積の割合。用途地域で上限指定' },
  { term: '容積率', reading: 'ようせきりつ', category: 'construction', definition: '敷地面積に対する延床面積の割合。前面道路幅員で制限' },
  { term: '北側斜線', reading: 'きたがわしゃせん', category: 'construction', definition: '低層/中高層住居専用地域で隣地日照を守る高さ制限' },
  { term: '日影規制', reading: 'ひかげきせい', category: 'construction', definition: '冬至日 8:00-16:00 の日影時間を地区指定で規制' },
  { term: '重要事項説明', reading: 'じゅうようじこうせつめい', category: 'real_estate', definition: '宅建業法35条。契約前に宅建士が説明する義務項目(権利関係/法令制限/設備/代金等)' },
  { term: '媒介契約', reading: 'ばいかいけいやく', category: 'real_estate', definition: '不動産仲介契約。一般/専任/専属専任の 3 種' },
  { term: 'クーリングオフ', reading: 'くーりんぐおふ', category: 'retail', definition: '特商法で消費者が一定期間内に無条件解約できる制度。訪販8日/通販対象外 等' },
  { term: '景表法', reading: 'けいひょうほう', category: 'retail', definition: '不当景品類及び不当表示防止法。優良誤認/有利誤認/景品上限額を規制' },
  { term: '下請法', reading: 'したうけほう', category: 'construction', definition: '下請代金支払遅延等防止法。60 日以内支払/書面交付義務等' },
  { term: 'HACCP', reading: 'はさっぷ', category: 'food', definition: '2021 年義務化の食品衛生管理手法。危害要因分析 + 重要管理点監視' },
  { term: 'アレルゲン', reading: 'あれるげん', category: 'food', definition: '食品表示法の特定原材料8+20品目。献立/パッケージに明記義務' },
  { term: 'レセプト', reading: 'れせぷと', category: 'medical', definition: '診療報酬明細書。電子請求で保険請求' },
  { term: 'J-SOX', reading: 'じぇいそっくす', category: 'finance', definition: '金商法上場企業の内部統制報告制度。年次で評価と監査が必要' },
  { term: '京町家', reading: 'きょうまちや', category: 'architecture', definition: '京都の伝統的木造町家。うなぎの寝床と呼ばれる間口狭/奥行深のプラン' },
  { term: '合掌造り', reading: 'がっしょうづくり', category: 'architecture', definition: '白川郷/五箇山の急勾配茅葺屋根。世界遺産/伝建地区で改変不可' },
  { term: '武家屋敷', reading: 'ぶけやしき', category: 'architecture', definition: '江戸期の武士住居。金沢/萩/知覧等に残存。書院造/茶室/門構え' },
  { term: '数寄屋造り', reading: 'すきやづくり', category: 'architecture', definition: '茶室建築から派生した簡素優美な和風様式。床の間/付書院/土壁' },
]);

export function listKnowledgeByTopic(topic: KnowledgeTopic): KnowledgeRef | null {
  return KNOWLEDGE_INDEX.find(k => k.topic === topic) ?? null;
}

export function lookupTerminology(term: string): TerminologyEntry | null {
  return JAPAN_TERMINOLOGY.find(t => t.term === term || t.reading === term) ?? null;
}

export function searchTerminology(query: string): TerminologyEntry[] {
  const q = query.toLowerCase();
  return JAPAN_TERMINOLOGY.filter(t =>
    t.term.toLowerCase().includes(q) ||
    (t.reading ?? '').toLowerCase().includes(q) ||
    t.definition.toLowerCase().includes(q),
  );
}

/** 知識ドメインの集計 (Quality Fortress v5 で使用) */
export function knowledgeCoverageStats(): {
  total_topics: number;
  total_apis: number;
  total_terminology: number;
  by_category: Record<string, number>;
} {
  const byCategory: Record<string, number> = {};
  for (const t of JAPAN_TERMINOLOGY) {
    byCategory[t.category] = (byCategory[t.category] ?? 0) + 1;
  }
  return {
    total_topics: KNOWLEDGE_INDEX.length,
    total_apis: KNOWLEDGE_INDEX.reduce((s, k) => s + (k.api?.length ?? 0), 0),
    total_terminology: JAPAN_TERMINOLOGY.length,
    by_category: byCategory,
  };
}
