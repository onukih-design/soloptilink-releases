/**
 * @fileoverview Phase 12 - インシデント管理 DNA
 *
 * 日本企業のインシデント運用を完全パッケージ化:
 *   1. ITIL v4 準拠 (Incident/Problem/Change/Service Request)
 *   2. 個情法 第26条 漏えい等報告 (個人情報保護委員会 + 本人通知)
 *   3. NISC GSOC / IPA 重要インフラ事案報告
 *   4. JPCERT/CC + JVN 連携 (脆弱性報告)
 *   5. 金商法 内部統制報告書 / J-SOX 重要不備対応
 *   6. 個人情報漏えい時の72時間以内報告ワークフロー
 *   7. 顧客/取引先向け謝罪文 + プレスリリーステンプレート
 *
 * Claude Code は「インシデントを管理しましょう」で止まる。
 * 本モジュールは ITIL + 日本の各種法令報告義務を一体化。
 */

// ============================================================================
// Types
// ============================================================================

export type IncidentSeverity = 'sev1' | 'sev2' | 'sev3' | 'sev4' | 'sev5';
export type IncidentStatus = 'detected' | 'triaging' | 'investigating' | 'mitigating' | 'resolved' | 'post_mortem' | 'closed';

export type IncidentCategory =
  | 'system_outage'           // システム障害
  | 'performance_degradation' // 性能劣化
  | 'data_breach'             // 個人情報漏えい
  | 'unauthorized_access'     // 不正アクセス
  | 'malware'                 // マルウェア感染
  | 'ransomware'              // ランサムウェア
  | 'ddos'                    // DDoS
  | 'misconfiguration'        // 設定ミス
  | 'human_error'             // 操作ミス
  | 'natural_disaster'        // 自然災害
  | 'physical_security'       // 物理セキュリティ
  | 'supply_chain'            // サプライチェーン
  | 'phishing'                // フィッシング
  | 'insider_threat'          // 内部不正
  | 'compliance_violation';   // コンプライアンス違反

export interface IncidentRecord {
  incidentId: string;
  title: string;
  severity: IncidentSeverity;
  category: IncidentCategory;
  status: IncidentStatus;
  detectedAt: string;
  detectedBy: string;
  affectedSystems: string[];
  affectedUsersCount?: number;
  /** 個人情報漏えいの場合の漏えい人数・件数 */
  leakedRecordsCount?: number;
  /** 漏えいした個人情報の種別 */
  leakedDataTypes?: ('name' | 'address' | 'phone' | 'email' | 'birthdate' | 'mynumber' | 'health' | 'creditcard' | 'bank' | 'biometric' | 'other')[];
  /** 業務影響度 (RTO/RPO 比較用) */
  businessImpactYenPerHour?: number;
  description: string;
  rootCause?: string;
  mitigation?: string;
  resolvedAt?: string;
  postMortemUrl?: string;
}

// ============================================================================
// SEV 判定 (FRAP - Facebook/Google 等の業界標準を日本企業向けに調整)
// ============================================================================

export function classifySeverity(input: {
  affectedUsersCount?: number;
  affectedRevenueYenPerHour?: number;
  isDataBreach?: boolean;
  leakedRecordsCount?: number;
  isExternalCustomerVisible?: boolean;
  isComplianceViolation?: boolean;
}): { severity: IncidentSeverity; reasons: string[] } {
  const reasons: string[] = [];

  // SEV1: 大規模障害 / 個人情報漏えい / コンプライアンス違反
  if (input.isDataBreach && (input.leakedRecordsCount ?? 0) >= 1000) {
    reasons.push('個人情報1,000件以上の漏えい (個情法 漏えい等報告 義務発生)');
    return { severity: 'sev1', reasons };
  }
  if ((input.affectedUsersCount ?? 0) >= 10000) {
    reasons.push('1万ユーザー以上に影響');
    return { severity: 'sev1', reasons };
  }
  if ((input.affectedRevenueYenPerHour ?? 0) >= 10_000_000) {
    reasons.push('時間あたり1000万円以上の損失');
    return { severity: 'sev1', reasons };
  }
  if (input.isComplianceViolation) {
    reasons.push('コンプライアンス違反 (取締役会報告必須)');
    return { severity: 'sev1', reasons };
  }

  // SEV2: 顧客可視 / 中規模影響
  if (input.isExternalCustomerVisible || (input.affectedUsersCount ?? 0) >= 1000) {
    reasons.push('顧客可視の障害 / 1,000ユーザー以上');
    return { severity: 'sev2', reasons };
  }
  if ((input.affectedRevenueYenPerHour ?? 0) >= 1_000_000) {
    reasons.push('時間あたり100万円以上の損失');
    return { severity: 'sev2', reasons };
  }

  // SEV3: 部分機能障害
  if ((input.affectedUsersCount ?? 0) >= 100) {
    reasons.push('100ユーザー以上に影響');
    return { severity: 'sev3', reasons };
  }

  // SEV4: 内部影響のみ / SEV5: ログ記録のみ
  if ((input.affectedUsersCount ?? 0) >= 10) {
    reasons.push('10ユーザー以上に影響');
    return { severity: 'sev4', reasons };
  }
  reasons.push('影響軽微 (記録のみ)');
  return { severity: 'sev5', reasons };
}

// ============================================================================
// 個情法 第26条 漏えい等報告 (R4 改正後)
// ============================================================================

/**
 * 個情法 第26条: 個人データの漏えい等が生じたときは「速やかに」
 * 個人情報保護委員会へ報告し、本人へ通知する義務。
 *
 * 報告対象:
 *   - 要配慮個人情報を含む漏えい等
 *   - 1,000件超の個人データの漏えい等
 *   - 不正アクセス等故意による漏えい等
 *   - 財産的被害が発生するおそれがある漏えい等
 *
 * 期限:
 *   - 速報: 概ね3〜5日以内
 *   - 確報: 30日以内 (不正アクセス等は60日以内)
 */
export interface PII26Report {
  reportType: 'preliminary' | 'final';
  isReportRequired: boolean;
  reasonsForRequirement: string[];
  preliminaryDeadline: string;
  finalDeadline: string;
  ppcSubmissionUrl: string;
  notifySubjectsRequired: boolean;
  notifySubjectsMethod: ('individual_letter' | 'email' | 'website_notice' | 'press_release')[];
}

export function evaluatePII26Report(input: {
  detectedAt: string;
  containsSensitiveData: boolean;
  recordsCount: number;
  isUnauthorizedAccess: boolean;
  hasFinancialDamageRisk: boolean;
}): PII26Report {
  const reasons: string[] = [];
  if (input.containsSensitiveData) reasons.push('要配慮個人情報を含む');
  if (input.recordsCount > 1000) reasons.push('1,000件超の個人データ');
  if (input.isUnauthorizedAccess) reasons.push('不正アクセス等故意による漏えい');
  if (input.hasFinancialDamageRisk) reasons.push('財産的被害が発生するおそれ');
  const isReportRequired = reasons.length > 0;

  const detectedDate = new Date(input.detectedAt);
  // 速報 = 5日後、確報 = 30日後 (不正アクセスは60日)
  const prelim = new Date(detectedDate);
  prelim.setDate(prelim.getDate() + 5);
  const finalDays = input.isUnauthorizedAccess ? 60 : 30;
  const final = new Date(detectedDate);
  final.setDate(final.getDate() + finalDays);

  const notifyMethods: PII26Report['notifySubjectsMethod'] = [];
  if (input.recordsCount <= 100) notifyMethods.push('individual_letter');
  else notifyMethods.push('email', 'website_notice');
  if (input.recordsCount >= 10000) notifyMethods.push('press_release');

  return {
    reportType: isReportRequired ? 'preliminary' : 'final',
    isReportRequired,
    reasonsForRequirement: reasons,
    preliminaryDeadline: prelim.toISOString(),
    finalDeadline: final.toISOString(),
    ppcSubmissionUrl: 'https://www.ppc.go.jp/personalinfo/legal/leakAction/',
    notifySubjectsRequired: isReportRequired,
    notifySubjectsMethod: notifyMethods,
  };
}

// ============================================================================
// JPCERT/CC + JVN 脆弱性報告
// ============================================================================

export interface VulnerabilityReport {
  cveId?: string;
  cvssScore?: number; // 0-10
  affectedProduct: string;
  affectedVersionRange: string;
  vulnerabilityType: string;
  reporterContact: string;
  jpcertSubmissionUrl: string;
  jvnSubmissionUrl: string;
  recommendedDisclosureDays: number;
}

export function buildVulnerabilityReport(input: {
  product: string;
  versionRange: string;
  type: string;
  cvss?: number;
  reporterContact: string;
}): VulnerabilityReport {
  const cvss = input.cvss ?? 0;
  const days = cvss >= 9.0 ? 7 : cvss >= 7.0 ? 14 : cvss >= 4.0 ? 30 : 90;
  return {
    affectedProduct: input.product,
    affectedVersionRange: input.versionRange,
    vulnerabilityType: input.type,
    cvssScore: cvss,
    reporterContact: input.reporterContact,
    jpcertSubmissionUrl: 'https://www.ipa.go.jp/security/vuln/report/index.html',
    jvnSubmissionUrl: 'https://jvn.jp/',
    recommendedDisclosureDays: days,
  };
}

// ============================================================================
// 謝罪文 / プレスリリーステンプレート
// ============================================================================

export function generateApologyLetter(input: {
  companyName: string;
  representativeName: string;
  incidentDate: string;
  incidentSummary: string;
  affectedScope: string;
  rootCause: string;
  countermeasures: string[];
  contactDeskName: string;
  contactDeskEmail: string;
  contactDeskPhone: string;
}): string {
  const today = new Date().toISOString().slice(0, 10);
  const measures = input.countermeasures.map((m, i) => `${i + 1}. ${m}`).join('\n');
  return `\
${today}

お客様各位

${input.companyName}
代表取締役 ${input.representativeName}

【お詫び】${input.incidentSummary} に関するお知らせ

平素は格別のご高配を賜り、厚く御礼申し上げます。
このたび、${input.incidentDate} に発生いたしました${input.incidentSummary}に
つきまして、お客様には多大なるご迷惑とご心配をおかけしましたことを、
心より深くお詫び申し上げます。

【影響範囲】
${input.affectedScope}

【原因】
${input.rootCause}

【再発防止策】
${measures}

【お問い合わせ窓口】
${input.contactDeskName}
TEL: ${input.contactDeskPhone}
Mail: ${input.contactDeskEmail}

今後は、再発防止策を徹底し、信頼回復に全力で取り組んでまいります。
重ねて深くお詫び申し上げます。

以上`;
}

// ============================================================================
// ポストモーテム (Blameless Post-mortem テンプレ)
// ============================================================================

export interface PostMortem {
  incidentId: string;
  title: string;
  authors: string[];
  status: 'draft' | 'in_review' | 'finalized';
  summary: string;
  impact: string;
  rootCauses: string[];
  triggers: string[];
  detection: string;
  resolution: string;
  timeline: { time: string; event: string }[];
  lessonsLearned: string[];
  actionItems: { item: string; owner: string; dueDate: string; priority: 'P0' | 'P1' | 'P2' | 'P3' }[];
}

export function buildPostMortemSkeleton(incident: IncidentRecord, authors: string[]): PostMortem {
  return {
    incidentId: incident.incidentId,
    title: `[Post-Mortem] ${incident.title}`,
    authors,
    status: 'draft',
    summary: `${incident.detectedAt} に発生した ${incident.title}。SEV: ${incident.severity}`,
    impact: incident.description,
    rootCauses: incident.rootCause ? [incident.rootCause] : ['（要分析）'],
    triggers: ['（要分析）'],
    detection: `${incident.detectedBy} が ${incident.detectedAt} に検知`,
    resolution: incident.mitigation ?? '（要記述）',
    timeline: [
      { time: incident.detectedAt, event: '検知' },
      ...(incident.resolvedAt ? [{ time: incident.resolvedAt, event: '復旧' }] : []),
    ],
    lessonsLearned: [],
    actionItems: [],
  };
}

// ============================================================================
// 規制当局報告マッピング
// ============================================================================

export const REGULATORY_REPORTING_MAP = {
  pii_breach: { authority: '個人情報保護委員会 (PPC)', law: '個人情報保護法 第26条', deadline: '速報5日 / 確報30日 (不正アクセスは60日)' },
  fsa_breach: { authority: '金融庁', law: '金融商品取引法・銀行法', deadline: '即時 (重大事態は当日)' },
  meti_breach: { authority: '経済産業省', law: '不正競争防止法 / 安全管理基準', deadline: '速やかに' },
  mhlw_breach: { authority: '厚生労働省', law: '医療情報安全管理ガイドライン', deadline: '速やかに' },
  nisc_breach: { authority: '内閣サイバーセキュリティセンター (NISC)', law: '重要インフラ事案報告', deadline: '24時間以内' },
  ipa_vuln: { authority: 'IPA / JPCERT/CC', law: '情報セキュリティ早期警戒パートナーシップ', deadline: '発見後 速やかに' },
} as const;

export const INCIDENT_REFS = {
  PPC_BREACH_REPORT: 'https://www.ppc.go.jp/personalinfo/legal/leakAction/',
  JPCERT_INCIDENT: 'https://www.jpcert.or.jp/form/',
  IPA_VULN: 'https://www.ipa.go.jp/security/vuln/report/',
  NISC_REPORT: 'https://www.nisc.go.jp/',
};
