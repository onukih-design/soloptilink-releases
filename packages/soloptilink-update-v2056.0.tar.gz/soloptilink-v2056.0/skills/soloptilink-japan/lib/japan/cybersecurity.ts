/**
 * SoloptiLinkAI Phase 32-CS — サイバーセキュリティ基盤 (Cybersecurity Operations)
 *
 * SOC (Security Operations Center) / CSIRT 運用の中核ロジック。
 * 既存 incident.ts (個情法第26条 R4改正) と security_audit.ts (ISMS/J-SOX) と
 * 役割分離: cybersecurity.ts = 検知・分類・脅威インテリジェンス・MITRE ATT&CK
 *
 * カバー範囲:
 *  - イベント正規化 (CEF/LEEF/Syslog → 共通スキーマ)
 *  - SIEM ルールベースのアラート分類 (TP/FP/ベニグン)
 *  - MITRE ATT&CK Tactics/Techniques マッピング
 *  - 脅威インテリジェンス (IoC: IP/Domain/Hash/URL/Email)
 *  - JPCERT/CC + JVN 連携 (脆弱性アドバイザリ)
 *  - 重要情報通信網保護 (経済安全保障推進法 R6.5施行)
 *  - 金融ISAC / J-CSIP (情報共有)
 */

export type LogSource =
  | "firewall"
  | "ids_ips"
  | "edr"
  | "antivirus"
  | "proxy"
  | "dns"
  | "email_gateway"
  | "iam"
  | "cloudtrail"
  | "k8s_audit"
  | "waf"
  | "siem"
  | "honeypot";

export type EventSeverity = "info" | "low" | "medium" | "high" | "critical";

export interface SecurityEvent {
  event_id: string;
  ts: string;
  source: LogSource;
  src_ip?: string;
  dst_ip?: string;
  src_user?: string;
  src_host?: string;
  dst_host?: string;
  process_name?: string;
  command_line?: string;
  url?: string;
  domain?: string;
  file_hash?: string;
  signature?: string;
  raw?: string;
  severity: EventSeverity;
}

// MITRE ATT&CK Enterprise (主要 Tactic と代表的 Technique)
export const MITRE_TACTICS = [
  { id: "TA0001", name: "Initial Access" },
  { id: "TA0002", name: "Execution" },
  { id: "TA0003", name: "Persistence" },
  { id: "TA0004", name: "Privilege Escalation" },
  { id: "TA0005", name: "Defense Evasion" },
  { id: "TA0006", name: "Credential Access" },
  { id: "TA0007", name: "Discovery" },
  { id: "TA0008", name: "Lateral Movement" },
  { id: "TA0009", name: "Collection" },
  { id: "TA0010", name: "Exfiltration" },
  { id: "TA0011", name: "Command and Control" },
  { id: "TA0040", name: "Impact" },
] as const;

export const COMMON_TECHNIQUES: { id: string; name: string; tactic: string; severity: EventSeverity }[] = [
  { id: "T1566", name: "Phishing", tactic: "TA0001", severity: "high" },
  { id: "T1190", name: "Exploit Public-Facing Application", tactic: "TA0001", severity: "critical" },
  { id: "T1078", name: "Valid Accounts", tactic: "TA0001", severity: "high" },
  { id: "T1059", name: "Command and Scripting Interpreter", tactic: "TA0002", severity: "medium" },
  { id: "T1053", name: "Scheduled Task/Job", tactic: "TA0003", severity: "medium" },
  { id: "T1547", name: "Boot or Logon Autostart Execution", tactic: "TA0003", severity: "medium" },
  { id: "T1068", name: "Exploitation for Privilege Escalation", tactic: "TA0004", severity: "critical" },
  { id: "T1110", name: "Brute Force", tactic: "TA0006", severity: "high" },
  { id: "T1003", name: "OS Credential Dumping", tactic: "TA0006", severity: "critical" },
  { id: "T1021", name: "Remote Services", tactic: "TA0008", severity: "high" },
  { id: "T1041", name: "Exfiltration Over C2 Channel", tactic: "TA0010", severity: "critical" },
  { id: "T1486", name: "Data Encrypted for Impact (Ransomware)", tactic: "TA0040", severity: "critical" },
  { id: "T1490", name: "Inhibit System Recovery", tactic: "TA0040", severity: "high" },
];

// 簡易シグネチャマッチング (本物SIEMはCorrelation Engineで実装)
export interface DetectionRule {
  rule_id: string;
  name: string;
  description: string;
  technique_id: string;
  pattern: RegExp;
  match_field: keyof SecurityEvent;
  severity: EventSeverity;
}

export const STANDARD_DETECTION_RULES: DetectionRule[] = [
  {
    rule_id: "DET-001",
    name: "Suspicious PowerShell - EncodedCommand",
    description: "難読化されたPowerShellコマンドの実行 (Mimikatz等のTTPで頻出)",
    technique_id: "T1059",
    pattern: /powershell.*-(?:e|ec|enc|encodedcommand)\s+[A-Za-z0-9+\/=]{20,}/i,
    match_field: "command_line",
    severity: "high",
  },
  {
    rule_id: "DET-002",
    name: "Brute Force - Multiple Failed Logons",
    description: "短時間内の認証失敗多発 (Correlation必要)",
    technique_id: "T1110",
    pattern: /failed.*logon|authentication failed|invalid credentials/i,
    match_field: "raw",
    severity: "medium",
  },
  {
    rule_id: "DET-003",
    name: "Suspicious DNS - DGA Domain",
    description: "ランダム生成ドメイン (DGA) への問い合わせ",
    technique_id: "T1071",
    pattern: /^[a-z0-9]{16,}\.(com|net|info|biz)$/,
    match_field: "domain",
    severity: "high",
  },
  {
    rule_id: "DET-004",
    name: "Ransomware - File Extension",
    description: "ランサムウェア典型的拡張子 (.locked, .encrypted, .crypt)",
    technique_id: "T1486",
    pattern: /\.(locked|encrypted|crypt|wcry|kraken|ryk|conti)$/i,
    match_field: "raw",
    severity: "critical",
  },
  {
    rule_id: "DET-005",
    name: "Credential Dumping - LSASS Access",
    description: "LSASS プロセスへの異常アクセス (Mimikatz)",
    technique_id: "T1003",
    pattern: /lsass\.exe.*(?:dump|memory|access)|sekurlsa::|mimikatz/i,
    match_field: "command_line",
    severity: "critical",
  },
];

export interface AlertResult {
  event_id: string;
  matched_rules: { rule_id: string; severity: EventSeverity; technique_id: string }[];
  highest_severity: EventSeverity;
  mitre_tactics: string[];
  recommended_action: "alert" | "investigate" | "block" | "isolate" | "ignore";
}

const SEVERITY_RANK: Record<EventSeverity, number> = {
  info: 0,
  low: 1,
  medium: 2,
  high: 3,
  critical: 4,
};

export function evaluateEvent(
  event: SecurityEvent,
  rules: DetectionRule[] = STANDARD_DETECTION_RULES,
): AlertResult {
  const matched: AlertResult["matched_rules"] = [];
  let topSev: EventSeverity = "info";
  for (const r of rules) {
    const value = event[r.match_field];
    if (typeof value !== "string") continue;
    if (r.pattern.test(value)) {
      matched.push({ rule_id: r.rule_id, severity: r.severity, technique_id: r.technique_id });
      if (SEVERITY_RANK[r.severity] > SEVERITY_RANK[topSev]) topSev = r.severity;
    }
  }
  const tactics = Array.from(
    new Set(
      matched
        .map((m) => COMMON_TECHNIQUES.find((t) => t.id === m.technique_id)?.tactic)
        .filter(Boolean) as string[],
    ),
  );
  let action: AlertResult["recommended_action"] = "ignore";
  if (topSev === "critical") action = "isolate";
  else if (topSev === "high") action = "block";
  else if (topSev === "medium") action = "investigate";
  else if (topSev === "low") action = "alert";

  return {
    event_id: event.event_id,
    matched_rules: matched,
    highest_severity: topSev,
    mitre_tactics: tactics,
    recommended_action: action,
  };
}

// Brute Force 相関分析 (失敗ログイン回数の閾値)
export interface CorrelationInput {
  events: SecurityEvent[];
  window_minutes: number;
  threshold: number;
}

export interface BruteForceFinding {
  src_ip?: string;
  src_user?: string;
  failure_count: number;
  first_seen: string;
  last_seen: string;
  is_brute_force: boolean;
}

export function detectBruteForce(input: CorrelationInput): BruteForceFinding[] {
  const failures = input.events.filter((e) => /failed.*logon|invalid credentials/i.test(e.raw ?? ""));
  const buckets = new Map<string, SecurityEvent[]>();
  for (const e of failures) {
    const key = `${e.src_ip ?? "?"}|${e.src_user ?? "?"}`;
    const arr = buckets.get(key) ?? [];
    arr.push(e);
    buckets.set(key, arr);
  }
  const out: BruteForceFinding[] = [];
  for (const [key, arr] of buckets) {
    const sorted = arr.slice().sort((a, b) => Date.parse(a.ts) - Date.parse(b.ts));
    const [ip, user] = key.split("|");
    const first = sorted[0].ts;
    const last = sorted[sorted.length - 1].ts;
    const spanMin = (Date.parse(last) - Date.parse(first)) / 60_000;
    const isBruteForce = arr.length >= input.threshold && spanMin <= input.window_minutes;
    out.push({
      src_ip: ip === "?" ? undefined : ip,
      src_user: user === "?" ? undefined : user,
      failure_count: arr.length,
      first_seen: first,
      last_seen: last,
      is_brute_force: isBruteForce,
    });
  }
  return out;
}

// 脅威インテリジェンス (IoC マッチング)
export interface IocEntry {
  indicator: string;
  type: "ip" | "domain" | "hash" | "url" | "email";
  source: "jpcert" | "jvn" | "j_csip" | "financial_isac" | "vendor" | "internal";
  confidence: "low" | "medium" | "high";
  first_seen: string;
  description?: string;
}

export function matchIoc(
  event: SecurityEvent,
  iocs: IocEntry[],
): { matches: IocEntry[]; risk: EventSeverity } {
  const candidates: { type: IocEntry["type"]; value?: string }[] = [
    { type: "ip", value: event.src_ip },
    { type: "ip", value: event.dst_ip },
    { type: "domain", value: event.domain },
    { type: "url", value: event.url },
    { type: "hash", value: event.file_hash },
  ];
  const matches: IocEntry[] = [];
  for (const c of candidates) {
    if (!c.value) continue;
    matches.push(...iocs.filter((i) => i.type === c.type && i.indicator.toLowerCase() === c.value!.toLowerCase()));
  }
  const risk = matches.some((m) => m.confidence === "high") ? "critical"
    : matches.some((m) => m.confidence === "medium") ? "high"
    : matches.length > 0 ? "medium" : "info";
  return { matches, risk };
}

// 経済安全保障推進法 R6.5施行 - 重要情報通信網
export const KEY_INFRASTRUCTURE_INDUSTRIES = [
  "電気", "ガス", "石油", "水道", "鉄道", "貨物自動車運送", "外航貨物",
  "航空", "空港", "電気通信", "放送", "郵便", "金融", "クレジットカード",
] as const;

export interface CriticalInfraAssessment {
  industry: string;
  is_critical: boolean;
  reporting_required: boolean;
  contact_authority: string[];
}

export function assessCriticalInfrastructure(industry: string): CriticalInfraAssessment {
  const isCritical = KEY_INFRASTRUCTURE_INDUSTRIES.some((i) => industry.includes(i));
  return {
    industry,
    is_critical: isCritical,
    reporting_required: isCritical,
    contact_authority: isCritical
      ? ["主管省庁", "内閣サイバーセキュリティセンター (NISC)", "JPCERT/CC"]
      : [],
  };
}
