// @ts-check
/**
 * 不動産業 DNA (Phase 18)
 *
 * Claude Code がカバーしない日本の不動産業を完全カバー。
 *
 *  - 宅地建物取引業法 (宅建業法)
 *  - 重要事項説明書 (35条書面) - 21 必須記載項目
 *  - 契約書 (37条書面)
 *  - 媒介契約 (一般 / 専任 / 専属専任) と業務報告義務
 *  - レインズ (REINS - 指定流通機構) 登録義務日数
 *  - 報酬規程 (報酬告示) - 売買仲介 5%/4%+2万/3%+6万 / 賃貸 1ヶ月分上限
 *  - 物件種別と用途
 *  - 重要事項説明 IT重説 (オンライン化)
 *  - 心理的瑕疵 / 物理的瑕疵 / 法的瑕疵
 *  - インスペクション (建物状況調査) - 媒介契約時の説明義務
 *
 * 出典 (一次情報):
 *   - 宅地建物取引業法 https://laws.e-gov.go.jp/law/327AC1000000176
 *   - 昭和45年建設省告示第1552号 (報酬告示)
 *     最終改正 令和6年国土交通省告示第949号 / 令和6年7月1日施行
 *   - 国土交通省「宅地建物取引業法の解釈・運用の考え方」改正 (令和6年7月1日施行)
 *     https://www.mlit.go.jp/tochi_fudousan_kensetsugyo/const/content/001750144.pdf
 *   - 重要事項の説明 (国交省) https://www.mlit.go.jp/totikensangyo/const/sosei_const_tk2_000061.html
 */

// =============================================================================
// 物件種別
// =============================================================================

export type PropertyKind =
  | 'land' // 土地
  | 'detached_house' // 戸建住宅
  | 'condominium' // 区分所有マンション
  | 'apartment_building' // 一棟アパート/マンション
  | 'office' // 事務所
  | 'retail_shop' // 店舗
  | 'warehouse' // 倉庫
  | 'factory' // 工場
  | 'parking_lot'; // 駐車場

export type TransactionType =
  | 'sale' // 売買
  | 'lease_residential' // 居住用賃貸
  | 'lease_commercial'; // 事業用賃貸

// =============================================================================
// 媒介契約
// =============================================================================

export type MediationContractKind =
  | 'general' // 一般媒介契約: 他社にも依頼可、レインズ登録任意、業務報告任意
  | 'exclusive' // 専任媒介契約: 他社禁止 (自己発見可), レインズ7日以内, 報告2週に1回以上
  | 'exclusive_right_to_sell'; // 専属専任媒介: 他社禁止 (自己発見も禁止), レインズ5日以内, 報告1週に1回以上

export interface MediationContract {
  kind: MediationContractKind;
  /** 契約日 */
  contracted_at: string;
  /** 有効期限 (専任系は 3 ヶ月以内) */
  expires_at: string;
  /** 報酬 (上限) */
  fee_jpy: number;
  /** レインズ登録予定日 */
  reins_registration_due?: string;
  /** 報告義務 */
  report_interval_days?: number;
}

/**
 * 媒介契約の業務義務を取得
 */
export function getMediationObligations(kind: MediationContractKind): {
  reins_within_days: number | null;
  report_interval_days: number | null;
  contract_max_months: number | null;
} {
  switch (kind) {
    case 'general':
      return { reins_within_days: null, report_interval_days: null, contract_max_months: null };
    case 'exclusive':
      return { reins_within_days: 7, report_interval_days: 14, contract_max_months: 3 };
    case 'exclusive_right_to_sell':
      return { reins_within_days: 5, report_interval_days: 7, contract_max_months: 3 };
  }
}

/**
 * 媒介契約有効期限の妥当性 (専任系は契約日から 3 ヶ月以内)
 */
export function isValidMediationExpiry(c: MediationContract): boolean {
  const obl = getMediationObligations(c.kind);
  if (obl.contract_max_months === null) return true;
  const start = new Date(c.contracted_at);
  const limit = new Date(start);
  limit.setMonth(limit.getMonth() + obl.contract_max_months);
  return new Date(c.expires_at) <= limit;
}

// =============================================================================
// 報酬規程 (宅地建物取引業法 第46条 / 報酬告示)
//
// 【出典 — 一次情報】
//   - 宅地建物取引業法 第46条 (報酬)
//     https://laws.e-gov.go.jp/law/327AC1000000176
//   - 昭和45年10月23日建設省告示第1552号
//     「宅地建物取引業者が宅地又は建物の売買等に関して受けることができる報酬の額」
//     最終改正: 令和6年6月21日 国土交通省告示第949号 (令和6年7月1日施行)
//   - 国土交通省「宅地建物取引業法の解釈・運用の考え方」改正 (令和6年7月1日施行)
//     https://www.mlit.go.jp/tochi_fudousan_kensetsugyo/const/content/001750144.pdf
//   - 東京都住宅政策本部「宅地建物取引業法等の改正について (空き家対策推進のための報酬告示改正等)」
//     https://www.juutakuseisaku.metro.tokyo.lg.jp/juutaku_seisaku/pdf/tokyo_douga_2410_04.pdf
// =============================================================================

/** 報酬告示 第二 (売買・交換の媒介) の速算式区分。取引価額 (税抜) の境界。 */
export const SALES_COMMISSION_BRACKETS = {
  /** 200万円以下: 取引価額の 5% (税込 5.5%) */
  tier1_upto_jpy: 2_000_000,
  tier1_rate: 0.05,
  /** 200万円超 400万円以下: 取引価額の 4% + 2万円 (税込 4.4%) */
  tier2_upto_jpy: 4_000_000,
  tier2_rate: 0.04,
  tier2_add_jpy: 20_000,
  /** 400万円超: 取引価額の 3% + 6万円 (税込 3.3%) */
  tier3_rate: 0.03,
  tier3_add_jpy: 60_000,
  /** 低廉な空家等の特例 (R6.7.1施行): 価格 800万円以下の宅地建物が対象。使用の状態は不問。 */
  low_value_special_price_ceiling_jpy: 8_000_000,
  /** 特例の報酬上限 (税抜)。税込では 30万円 × 1.1 = 33万円。 */
  low_value_special_commission_jpy: 300_000,
  /** 消費税率 (10%) */
  consumption_tax_rate: 0.1,
} as const;

export interface SalesCommissionOptions {
  /**
   * 低廉な空家等の特例について、媒介・代理契約の締結に際し「あらかじめ」
   * 依頼者に報酬額を説明し、**合意を得ている**か。
   *
   * ★宅地建物取引業法第46条第1項関係。国交省「解釈・運用の考え方」は
   *   「媒介・代理契約の締結に際し、あらかじめ、特例で定める上限の範囲内で、
   *     報酬額について依頼者に説明し、合意する必要があることに特に留意」
   *   と明記している。合意がないまま特例額を請求すると報酬額制限違反となるため、
   *   既定値は false (= 原則計算) とし、合意があるときだけ引き上げる。
   */
  low_value_special_agreed?: boolean;
}

export interface SalesCommissionResult {
  /** 報酬額の上限 (税抜) */
  commission: number;
  /** 消費税額 */
  tax: number;
  /** 税込の報酬額上限 */
  total: number;
  /** 適用した区分 */
  rule:
    | 'no_transaction'
    | 'standard_5pct'
    | 'standard_4pct'
    | 'standard_3pct'
    | 'r6_low_value_30man_special';
  /** 原則計算 (特例を使わない場合) の報酬額 (税抜) */
  standard_commission: number;
  /** 低廉な空家等の特例を使える価格帯か (800万円以下) */
  low_value_special_applicable: boolean;
  /** 実際に特例を適用したか (適用余地があり、かつ依頼者との事前合意がある場合のみ true) */
  low_value_special_applied: boolean;
  /** 画面・書面にそのまま出せる日本語の注意書き */
  notes: string[];
}

/**
 * 売買・交換の媒介における報酬額の上限を算出する (依頼者の一方から受領できる額)。
 *
 * 【原則 — 報酬告示 第二】(取引価額は税抜)
 *   - 200万円以下          : 取引価額 × 5%
 *   - 200万円超 400万円以下 : 取引価額 × 4% + 2万円
 *   - 400万円超            : 取引価額 × 3% + 6万円
 *
 * 【低廉な空家等の媒介の特例 — 令和6年7月1日施行】
 *   価格 800万円以下の宅地建物については、当該媒介に要する費用を勘案して、
 *   原則による上限を超えて報酬を受領できる (30万円の1.1倍 = 税込33万円 が上限)。
 *   ★要件: 媒介・代理契約の締結に際し、あらかじめ依頼者に説明し合意すること。
 *
 * ★注意: 代理の場合は媒介の2倍が上限 (報酬告示 第三)。本関数は媒介を返す。
 * ★注意: 特例の上限はあくまで「上限」であり、実際に請求できるのは
 *         当該媒介に要する費用を勘案した額。上限を機械的に請求してよい意味ではない。
 */
export function calcSalesCommissionMax(
  price_jpy: number,
  opts: SalesCommissionOptions = {},
): SalesCommissionResult {
  const B = SALES_COMMISSION_BRACKETS;
  if (price_jpy <= 0) {
    return {
      commission: 0, tax: 0, total: 0, rule: 'no_transaction',
      standard_commission: 0,
      low_value_special_applicable: false,
      low_value_special_applied: false,
      notes: ['取引価額が0円以下のため報酬は発生しません。'],
    };
  }

  // --- 原則計算 (速算式) ---
  // ★分岐は必ず「小さい額から」判定する。旧実装は 800万円以下を先に判定していたため
  //   200万円以下 5% / 400万円以下 4%+2万 の分岐が到達不能になり、
  //   100万円の物件に 30万円 (法定 5万円の6倍) を返していた。
  let standard: number;
  let rule: SalesCommissionResult['rule'];
  if (price_jpy <= B.tier1_upto_jpy) {
    standard = price_jpy * B.tier1_rate;
    rule = 'standard_5pct';
  } else if (price_jpy <= B.tier2_upto_jpy) {
    standard = price_jpy * B.tier2_rate + B.tier2_add_jpy;
    rule = 'standard_4pct';
  } else {
    standard = price_jpy * B.tier3_rate + B.tier3_add_jpy;
    rule = 'standard_3pct';
  }
  standard = Math.floor(standard);

  // --- 低廉な空家等の特例 ---
  const applicable = price_jpy <= B.low_value_special_price_ceiling_jpy;
  const agreed = opts.low_value_special_agreed === true;
  // 特例は原則の上限を「超えて」受領できる制度。原則額のほうが大きい場合は引き上げが起きない。
  const uplift = applicable && agreed && B.low_value_special_commission_jpy > standard;

  let commission = standard;
  const notes: string[] = [];
  if (uplift) {
    commission = B.low_value_special_commission_jpy;
    rule = 'r6_low_value_30man_special';
    notes.push(
      '低廉な空家等の媒介の特例 (令和6年7月1日施行) を適用しています。' +
      '上限は30万円 (税込33万円) です。実際の請求額は当該媒介に要する費用を勘案して決めてください。',
    );
  } else if (applicable && !agreed) {
    notes.push(
      '価格800万円以下のため低廉な空家等の特例を使える余地がありますが、' +
      '依頼者との事前の説明・合意が確認できないため原則の上限で計算しています ' +
      '(宅地建物取引業法第46条第1項関係)。',
    );
  }
  notes.push('この額は依頼者の一方から受領できる上限です。代理の場合は媒介の2倍が上限となります (報酬告示 第三)。');

  const tax = Math.floor(commission * B.consumption_tax_rate);
  return {
    commission,
    tax,
    total: commission + tax,
    rule,
    standard_commission: standard,
    low_value_special_applicable: applicable,
    low_value_special_applied: uplift,
    notes,
  };
}

/**
 * 賃貸借の媒介における報酬額の上限 (報酬告示 第四)
 *
 * 【出典 — 一次情報】報酬告示 第四 / 国交省「解釈・運用の考え方」(R6.7.1施行)
 *  - 原則: 依頼者の双方から受けられる報酬の額の合計額は、1ヶ月分の借賃に 1.1 を乗じた金額以内
 *  - 居住用建物の場合、依頼者の一方からは 1ヶ月分の借賃に 0.55 を乗じた金額以内
 *    (媒介の依頼を受けるに当たって依頼者の承諾を得ている場合を除く)
 *
 * ★承諾は「媒介の依頼を受けるに当たって」得ている必要がある (事後承諾は不可)。
 * ★長期の空家等の媒介の特例 (R6.7.1施行): 現に長期間使用されておらず、又は将来にわたり
 *   使用の見込みがない宅地建物については、貸主である依頼者から 1ヶ月分の 2.2 倍を上限として
 *   受領できる。本関数は原則のみを返す (特例は個別要件の確認が必要なため)。
 */
export function calcLeaseCommissionMax(
  monthly_rent: number,
  txnType: 'lease_residential' | 'lease_commercial',
  client_consent: boolean,
): { commission: number; tax: number; total: number; rule: string } {
  let commission: number;
  let rule: string;
  if (txnType === 'lease_residential') {
    if (client_consent) {
      commission = monthly_rent;
      rule = 'residential_1month_with_consent';
    } else {
      commission = monthly_rent * 0.5;
      rule = 'residential_half_month';
    }
  } else {
    commission = monthly_rent;
    rule = 'commercial_1month';
  }
  const tax = Math.floor(commission * 0.1);
  return { commission: Math.floor(commission), tax, total: Math.floor(commission) + tax, rule };
}

// =============================================================================
// 重要事項説明書 (35条書面) - 21 必須記載項目
// =============================================================================

export interface ImportantMattersExplanation {
  property_id: string;
  /** 取引の対象 */
  property_kind: PropertyKind;
  txn_type: TransactionType;
  /** 取引主任者 */
  takken_holder: { name: string; license_no: string };
  /** 説明の方法 */
  explanation_method: 'in_person' | 'it_juusetsu'; // IT重説可
  /** 説明実施日時 */
  explained_at: string;
  /** 21項目チェック */
  items: ImportantMatterItem[];
  /** 顧客署名/記名押印 */
  customer_signed: boolean;
}

/**
 * 35 条書面 必須記載 21 項目 (居住用売買の場合の代表例)
 */
export const REQUIRED_35_ITEMS: { id: number; label: string; required_for: TransactionType[] }[] = [
  { id: 1, label: '登記簿に記載された事項 (所有権/抵当権/賃借権)', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 2, label: '都市計画法・建築基準法等の制限の概要', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 3, label: '私道に関する負担', required_for: ['sale'] },
  { id: 4, label: '飲用水・電気・ガスの供給施設', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 5, label: '宅地造成又は建築の工事完了時の形状・構造', required_for: ['sale'] },
  { id: 6, label: '区分所有建物の場合の規約等', required_for: ['sale'] },
  { id: 7, label: '代金以外に授受される金銭', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 8, label: '契約解除に関する事項', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 9, label: '損害賠償額の予定・違約金に関する事項', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 10, label: '手付金等の保全措置の概要 (売主が宅建業者の場合)', required_for: ['sale'] },
  { id: 11, label: '支払金等の保全措置 (50万円以上)', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 12, label: '金銭の貸借のあっせん (ローン特約)', required_for: ['sale'] },
  { id: 13, label: '瑕疵担保責任の履行措置 (新築住宅10年保証)', required_for: ['sale'] },
  { id: 14, label: '割賦販売の場合の現金販売価格', required_for: ['sale'] },
  { id: 15, label: '建物の構造耐力上主要部分等の状況 (インスペクション結果)', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 16, label: '台帳記載の事項 (建築物の検査済証)', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 17, label: '津波災害警戒区域内か', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 18, label: '土砂災害警戒区域内か', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 19, label: '石綿 (アスベスト) 使用の有無', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 20, label: '耐震診断の内容 (S56年5月以前建築の場合)', required_for: ['sale', 'lease_residential', 'lease_commercial'] },
  { id: 21, label: '住宅性能評価を受けた新築住宅であるか', required_for: ['sale'] },
];

export interface ImportantMatterItem {
  id: number;
  explained: boolean;
  remarks?: string;
}

/**
 * 35条書面の不備チェック
 */
export function validate35Items(
  items: ImportantMatterItem[],
  txnType: TransactionType,
): { ok: boolean; missing: number[] } {
  const required = REQUIRED_35_ITEMS.filter((r) => r.required_for.includes(txnType)).map((r) => r.id);
  const explainedIds = new Set(items.filter((i) => i.explained).map((i) => i.id));
  const missing = required.filter((id) => !explainedIds.has(id));
  return { ok: missing.length === 0, missing };
}

// =============================================================================
// 心理的瑕疵 / 物理的瑕疵
// =============================================================================

export type DefectKind =
  | 'physical' // 物理的瑕疵 (雨漏り/シロアリ/傾き)
  | 'legal' // 法的瑕疵 (建ぺい率違反/接道不良)
  | 'environmental' // 環境瑕疵 (騒音/悪臭/嫌悪施設)
  | 'psychological'; // 心理的瑕疵 (殺人/自殺/孤独死)

export interface PropertyDefect {
  kind: DefectKind;
  description: string;
  /** 発覚日 */
  discovered_at: string;
  /** 説明義務の有無 (心理的瑕疵は概ね 3 年と判例で示されているが個別判断) */
  must_disclose: boolean;
}

/**
 * 心理的瑕疵の告知義務判定 (国交省ガイドライン R3年10月)
 *  - 売買: 原則 全件告知 (期間制限なし)
 *  - 賃貸: 概ね 3 年経過で告知不要 (但し殺人等の社会的影響大は要告知)
 *  - 隣接住戸/同一マンション: 原則告知不要
 */
export function shouldDiscloseSinriKashi(d: PropertyDefect, txnType: TransactionType): boolean {
  if (d.kind !== 'psychological') return d.must_disclose;
  if (txnType === 'sale') return true;
  // 賃貸: 3年ルール
  const discovered = new Date(d.discovered_at);
  const threeYearsAgo = new Date();
  threeYearsAgo.setFullYear(threeYearsAgo.getFullYear() - 3);
  return discovered >= threeYearsAgo;
}

// =============================================================================
// インスペクション (既存住宅状況調査)
// =============================================================================

export interface BuildingInspectionReport {
  property_id: string;
  /** 既存住宅状況調査技術者 (建築士+講習修了) */
  inspector_name: string;
  inspector_license_no: string;
  inspected_at: string;
  /** 主要構造部 */
  structure_findings: string;
  /** 雨水浸入防止部分 */
  waterproof_findings: string;
  /** 給排水管 */
  plumbing_findings: string;
  /** 過去 5 年以内の有効性 */
  valid_until: string;
}

// =============================================================================
// レインズ (指定流通機構) 登録
// =============================================================================

export interface ReinsRegistration {
  property_id: string;
  contract_id: string;
  registered_at: string;
  /** REINS 登録番号 */
  reins_no: string;
  status: 'registered' | 'business_negotiating' | 'sold' | 'withdrawn';
}

/**
 * 媒介契約成立日からレインズ登録までの日数を判定
 */
export function isReinsRegistrationOnTime(
  contract: MediationContract,
  registration: ReinsRegistration,
): boolean {
  const obl = getMediationObligations(contract.kind);
  if (obl.reins_within_days === null) return true;
  const start = new Date(contract.contracted_at);
  const reg = new Date(registration.registered_at);
  const diffDays = Math.floor((reg.getTime() - start.getTime()) / (24 * 60 * 60 * 1000));
  // 休業日除外は簡易: 7/5 営業日換算で判定
  return diffDays <= obl.reins_within_days + 2;
}
