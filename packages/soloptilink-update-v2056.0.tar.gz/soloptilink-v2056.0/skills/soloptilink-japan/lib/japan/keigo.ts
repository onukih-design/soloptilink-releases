/**
 * 敬語変換ユーティリティ
 * 丁寧語・尊敬語・謙譲語の変換、ビジネス文書の定型文生成
 */

export type KeigoLevel = 'plain' | 'polite' | 'respectful' | 'humble';

const VERB_MAP: Array<{ plain: string; polite: string; respectful: string; humble: string }> = [
  { plain: '言う', polite: '言います', respectful: 'おっしゃる', humble: '申し上げる' },
  { plain: '見る', polite: '見ます', respectful: 'ご覧になる', humble: '拝見する' },
  { plain: '行く', polite: '行きます', respectful: 'いらっしゃる', humble: '伺う' },
  { plain: '来る', polite: '来ます', respectful: 'いらっしゃる', humble: '参る' },
  { plain: 'いる', polite: 'います', respectful: 'いらっしゃる', humble: 'おる' },
  { plain: 'する', polite: 'します', respectful: 'なさる', humble: 'いたす' },
  { plain: '食べる', polite: '食べます', respectful: '召し上がる', humble: 'いただく' },
  { plain: '知る', polite: '知っています', respectful: 'ご存じ', humble: '存じ上げる' },
  { plain: 'くれる', polite: 'くれます', respectful: 'くださる', humble: '' },
  { plain: 'もらう', polite: 'もらいます', respectful: '', humble: 'いただく' },
  { plain: '会う', polite: '会います', respectful: '', humble: 'お目にかかる' },
  { plain: '聞く', polite: '聞きます', respectful: '', humble: '伺う' },
];

/**
 * 基本動詞の敬語変換
 */
export function convertVerb(verb: string, level: KeigoLevel): string {
  const entry = VERB_MAP.find(e => e.plain === verb || e.polite === verb);
  if (!entry) return verb;
  return entry[level] || entry.polite || verb;
}

/**
 * ビジネス定型文の生成
 */
export const BusinessPhrases = {
  greeting(time: 'morning' | 'day' | 'evening' | 'formal'): string {
    return {
      morning: 'おはようございます。',
      day: 'お世話になっております。',
      evening: '夜分失礼いたします。',
      formal: '拝啓 時下ますますご清栄のこととお慶び申し上げます。',
    }[time];
  },

  opening(context: 'reply' | 'initiate' | 'apology' | 'thanks'): string {
    return {
      reply: 'ご連絡いただき誠にありがとうございます。',
      initiate: '突然のご連絡失礼いたします。',
      apology: 'このたびはご迷惑をおかけし、誠に申し訳ございません。',
      thanks: '平素より格別のお引き立てを賜り、厚く御礼申し上げます。',
    }[context];
  },

  closing(level: 'standard' | 'formal' | 'urgent'): string {
    return {
      standard: '何卒よろしくお願い申し上げます。',
      formal: '今後とも倍旧のお引き立てのほど、よろしくお願い申し上げます。敬具',
      urgent: 'お忙しいところ恐縮ですが、何卒よろしくお願い申し上げます。',
    }[level];
  },

  invoiceNote(): string {
    return 'いつも格別のお引き立てを賜り、厚く御礼申し上げます。\n下記の通りご請求申し上げますので、お支払いくださいますようお願い申し上げます。';
  },

  estimateNote(): string {
    return '下記の通りお見積り申し上げます。\nご検討のほど、よろしくお願い申し上げます。';
  },
};

/**
 * 相手への呼称変換
 */
export function companyHonorific(name: string, relationship: 'customer' | 'partner' | 'vendor' | 'self'): string {
  if (relationship === 'self') return `当社 (${name})`;
  return `${name} 御中`;
}

export function personHonorific(name: string, title?: string): string {
  return title ? `${name} ${title}` : `${name} 様`;
}

/**
 * メッセージを敬語レベルに変換 (簡易版、内部で辞書置換)
 */
export function escalate(text: string, level: KeigoLevel = 'polite'): string {
  let result = text;
  const casualReplacements: Array<[string, string]> = [
    ['だ。', 'です。'], ['だよ。', 'です。'], ['だね。', 'ですね。'],
    ['する', 'いたす'], ['します', 'いたします'],
    ['思う', '存じます'], ['分かった', 'かしこまりました'],
    ['ありがとう', 'ありがとうございます'],
  ];
  for (const [from, to] of casualReplacements) {
    result = result.replaceAll(from, to);
  }
  if (level === 'respectful' || level === 'humble') {
    result = result.replaceAll('言う', level === 'respectful' ? 'おっしゃる' : '申し上げる');
    result = result.replaceAll('する', level === 'respectful' ? 'なさる' : 'いたす');
  }
  return result;
}
