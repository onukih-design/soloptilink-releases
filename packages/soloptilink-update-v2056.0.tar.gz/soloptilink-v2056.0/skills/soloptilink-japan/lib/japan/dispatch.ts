/**
 * lib/japan/dispatch.ts — 労働者派遣/職業紹介DNA
 *
 * 法令カバレッジ:
 *  - 労働者派遣法 (S60法律88) H27改正 (3年ルール) + R2改正 (同一労働同一賃金)
 *  - 労働者派遣事業の適正な運営の確保及び派遣労働者の保護等に関する法律施行規則
 *  - 職業安定法 (S22法律141) — 有料職業紹介/無料職業紹介
 *  - 職業安定法施行規則
 *  - 同一労働同一賃金ガイドライン (H30告示)
 *  - 労使協定方式 / 派遣先均等均衡方式
 *  - 派遣禁止業務 (港湾運送/建設/警備/医療等)
 *  - 雇用保険法 / 労災保険法 (派遣元責任)
 *
 * 参考: 厚生労働省職業安定局, 一般社団法人日本人材派遣協会 (JASSA)
 */

// ============================================================================
// 1. 派遣禁止業務 (派遣法4条)
// ============================================================================

export const DISPATCH_PROHIBITED_BUSINESSES = [
  { kind: 'port_transport', ja: '港湾運送業務', law: '派遣法4条1項1号' },
  { kind: 'construction', ja: '建設業務', law: '派遣法4条1項2号' },
  { kind: 'security', ja: '警備業務', law: '派遣法4条1項3号' },
  { kind: 'medical_at_hospital', ja: '医療関係業務 (病院・診療所内)', law: '施行令2条' },
  { kind: 'lawyer', ja: '弁護士・司法書士・税理士等の士業', law: '施行令2条' },
] as const;

export type ProhibitedKind = typeof DISPATCH_PROHIBITED_BUSINESSES[number]['kind'];

/** 派遣可否判定 */
export function isDispatchAllowed(input: { businessDescription: string; isAtHospital?: boolean }): {
  allowed: boolean;
  reason: string;
} {
  const desc = input.businessDescription.toLowerCase();
  if (desc.includes('港湾') || desc.includes('港運')) {
    return { allowed: false, reason: '港湾運送業務は派遣禁止 (派遣法4条1項1号)' };
  }
  if (desc.includes('建設') || desc.includes('土工') || desc.includes('左官')) {
    return { allowed: false, reason: '建設業務は派遣禁止 (派遣法4条1項2号)' };
  }
  if (desc.includes('警備') || desc.includes('巡回保安')) {
    return { allowed: false, reason: '警備業務は派遣禁止 (派遣法4条1項3号)' };
  }
  if (input.isAtHospital && (desc.includes('看護') || desc.includes('診療補助'))) {
    return { allowed: false, reason: '病院内の医療関係業務は派遣禁止 (施行令2条)' };
  }
  return { allowed: true, reason: '派遣可能業務' };
}

// ============================================================================
// 2. 派遣事業の許可 (派遣法5条 H27改正 — 一般+特定の区分廃止)
// ============================================================================

export interface DispatchBusinessApplication {
  hasPermit: boolean; // 厚生労働大臣許可 (5年/3年更新)
  // 財産的基礎要件 (規則1条の4)
  baseCapitalJpy: number; // 基準資産額 2000万円以上
  baseCapitalPerOfficeJpy: number; // 1事業所当たり 2000万円以上
  cashHoldingJpy: number; // 現金預金 1500万円以上
  // 適正運営要件
  hasResponsibleManager: boolean; // 派遣元責任者
  responsibleManagerHasTrainingCert: boolean; // 派遣元責任者講習修了
  hasOfficeFloorM2: number; // 事業所面積 20m²以上
  hasComplianceProgram: boolean; // 派遣労働者教育訓練計画
  hasSocialInsuranceEnrollment: boolean; // 社保加入
}

/** 派遣事業許可の事前審査 */
export function evaluateDispatchPermit(a: DispatchBusinessApplication): {
  approvable: boolean;
  blockers: string[];
} {
  const blockers: string[] = [];
  if (a.baseCapitalJpy < 20_000_000) blockers.push('基準資産 2000万円以上必須 (規則1条の4)');
  if (a.cashHoldingJpy < 15_000_000) blockers.push('現金預金 1500万円以上必須');
  if (a.baseCapitalPerOfficeJpy < 20_000_000) blockers.push('1事業所当たり基準資産 2000万円以上必須');
  if (!a.hasResponsibleManager) blockers.push('派遣元責任者の選任必須 (法36条)');
  if (!a.responsibleManagerHasTrainingCert) {
    blockers.push('派遣元責任者講習 (3年以内に受講) 修了証必須');
  }
  if (a.hasOfficeFloorM2 < 20) blockers.push('事業所面積 20m²以上必須');
  if (!a.hasSocialInsuranceEnrollment) blockers.push('派遣労働者の社会保険加入義務 — 未加入は許可不可');
  if (!a.hasComplianceProgram) blockers.push('派遣労働者教育訓練計画 必須 (法30条の2)');
  return { approvable: blockers.length === 0, blockers };
}

// ============================================================================
// 3. 3年ルール (派遣法 H27改正)
// ============================================================================

/** 個人単位 3年 + 事業所単位 3年 (過半数労組意見聴取で延長可) */
export interface DispatchAssignment {
  workerName: string;
  startDate: Date;
  organizationUnit: string; // 課/部署
  hasMajorityUnionConsultation: boolean; // 過半数労組意見聴取
  hasUnionExtensionOk: boolean;
}

export function checkThreeYearRule(input: DispatchAssignment, today: Date = new Date()): {
  exceedsLimit: boolean;
  remainingDays: number;
  recommendation: string;
} {
  const limitMs = 3 * 365 * 86400000;
  const elapsedMs = today.getTime() - input.startDate.getTime();
  const remainingDays = Math.ceil((limitMs - elapsedMs) / 86400000);

  if (elapsedMs >= limitMs) {
    if (input.hasUnionExtensionOk) {
      return {
        exceedsLimit: false,
        remainingDays: 0,
        recommendation: '事業所単位で過半数労組意見聴取済 — 延長可、ただし個人単位3年は別途判定',
      };
    }
    return {
      exceedsLimit: true,
      remainingDays: 0,
      recommendation: '3年経過 — 直接雇用申込み or 別の組織単位への異動 or 派遣終了',
    };
  }
  return {
    exceedsLimit: false,
    remainingDays,
    recommendation:
      remainingDays < 90
        ? `残り${remainingDays}日 — 過半数労組意見聴取の手続を開始 (満了1ヶ月前まで)`
        : '通常運用可',
  };
}

// ============================================================================
// 4. 同一労働同一賃金 (R2.4施行)
// ============================================================================

export type WageDetermineMethod = 'labor_management_agreement' | 'dispatching_destination_balance';

/** 派遣労働者の賃金決定方式 */
export interface SameWorkSameWageScheme {
  method: WageDetermineMethod;
  // 労使協定方式 (一般賃金水準以上)
  hasLaborManagementAgreement?: boolean;
  laborMgmtAgreementValidThroughMar31: boolean; // 毎年4/1更新
  generalWageDataReferenceYear?: number; // 統計データ年度
  // 派遣先均等均衡方式
  destinationCompanyComparableWageJpy?: number; // 派遣先同種業務の賃金
  ourWorkerWageJpy?: number;
  benefitsParityWithDestination: boolean; // 教育訓練/福利厚生の均衡
}

/** 同一労働同一賃金 (R2.4) のコンプライアンスチェック */
export function checkEqualPayCompliance(s: SameWorkSameWageScheme): {
  compliant: boolean;
  alerts: string[];
} {
  const alerts: string[] = [];
  if (s.method === 'labor_management_agreement') {
    if (!s.hasLaborManagementAgreement) alerts.push('労使協定書面 必須');
    if (!s.laborMgmtAgreementValidThroughMar31) {
      alerts.push('労使協定 毎年3/31満了 — 4/1更新確認必須');
    }
    if (!s.generalWageDataReferenceYear || s.generalWageDataReferenceYear < new Date().getFullYear() - 1) {
      alerts.push('一般賃金水準データ — 直近年度のもの参照必須 (賃金構造基本統計調査)');
    }
  } else {
    // 派遣先均等均衡方式
    if (!s.destinationCompanyComparableWageJpy || !s.ourWorkerWageJpy) {
      alerts.push('派遣先同種業務の賃金比較データ必須');
    } else if (s.ourWorkerWageJpy < s.destinationCompanyComparableWageJpy * 0.95) {
      alerts.push(
        `均等均衡違反: 派遣先${s.destinationCompanyComparableWageJpy}円 > 自社${s.ourWorkerWageJpy}円 (5%超下回る)`
      );
    }
    if (!s.benefitsParityWithDestination) {
      alerts.push('教育訓練/福利厚生の均衡 必須');
    }
  }
  return { compliant: alerts.length === 0, alerts };
}

// ============================================================================
// 5. 有料職業紹介 (職業安定法30条)
// ============================================================================

export interface JobPlacementApplication {
  isProfit: boolean; // 有料 (true) / 無料 (false)
  hasPermit: boolean; // 厚生労働大臣許可
  baseCapitalJpy: number;
  cashHoldingJpy: number;
  hasResponsibleManager: boolean;
  responsibleManagerHasTrainingCert: boolean; // 職業紹介責任者講習
  servesProhibitedJobs: boolean; // 港湾運送/建設の紹介 (有料禁止)
}

/** 有料職業紹介 許可審査 */
export function evaluateJobPlacementPermit(a: JobPlacementApplication): {
  approvable: boolean;
  blockers: string[];
} {
  const blockers: string[] = [];
  if (a.isProfit && a.servesProhibitedJobs) {
    blockers.push('港湾運送・建設業務は有料職業紹介禁止 (職安法32条の11)');
  }
  if (a.isProfit) {
    if (a.baseCapitalJpy < 5_000_000) blockers.push('有料職業紹介 — 基準資産 500万円以上');
    if (a.cashHoldingJpy < 1_500_000) blockers.push('現金預金 150万円以上必須');
  }
  if (!a.hasResponsibleManager) blockers.push('職業紹介責任者の選任必須');
  if (!a.responsibleManagerHasTrainingCert) {
    blockers.push('職業紹介責任者講習 (5年以内に受講) 必須');
  }
  return { approvable: blockers.length === 0, blockers };
}

// ============================================================================
// 6. 紹介手数料の上限 (職業安定法32条の3)
// ============================================================================

/** 紹介手数料: 上限制 (規則20条) — 通常 求人受付手数料+成功報酬 */
export function calcJobPlacementMaxFee(input: {
  annualSalaryJpy: number;
  feeKind: 'fixed_table' | 'percentage_consent'; // 上限届出手数料/上限規定額方式
}): { maxFeeJpy: number; reason: string } {
  if (input.feeKind === 'percentage_consent') {
    // 上限規定額方式: 10.8% (税込) — 求人者から
    return {
      maxFeeJpy: Math.floor(input.annualSalaryJpy * 0.108),
      reason: '上限規定額方式 — 年収の10.8%まで',
    };
  }
  // 上限届出手数料方式 (規則20条 別表): 上限なし (届出制) - 一般慣行は30-35%
  return {
    maxFeeJpy: Math.floor(input.annualSalaryJpy * 0.35),
    reason: '上限届出手数料方式 — 厚労省への届出による (慣行 30-35%)',
  };
}

// ============================================================================
// 7. 紹介予定派遣 (法2条4号) — 派遣→直接雇用切替
// ============================================================================

/**
 * 紹介予定派遣: 派遣期間最長6ヶ月、その後直接雇用
 * 直接雇用採用に至らなかった場合、派遣元/派遣先双方に理由開示義務
 */
export function evaluateIntroductionDispatch(input: {
  dispatchPeriodMonths: number;
  hasInterviewBeforeDispatch: boolean; // 派遣前面接 (派遣法ではNGだが紹介予定はOK)
  hasFinalDecisionRecorded: boolean;
  hadDirectEmploymentOffer: boolean;
  hasReasonDisclosure: boolean; // 採用しない場合の理由開示
}): { compliant: boolean; alerts: string[] } {
  const alerts: string[] = [];
  if (input.dispatchPeriodMonths > 6) {
    alerts.push('紹介予定派遣の派遣期間は最長6ヶ月');
  }
  if (!input.hadDirectEmploymentOffer && !input.hasReasonDisclosure) {
    alerts.push('採用に至らなかった場合 — 派遣元・派遣先双方に理由開示義務');
  }
  return { compliant: alerts.length === 0, alerts };
}
