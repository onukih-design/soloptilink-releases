/**
 * SoloptiLinkAI Phase 23 — 顧客問い合わせ管理 (Inquiry Management)
 *
 * 顧客からの問い合わせの受付・分類・SLA管理・CSAT測定の中核ロジック。
 * 業種を問わず使える共通バックボーン。
 *
 * カバー範囲:
 *  - チャネル別受付 (フォーム/メール/電話/チャット/SNS/LINE)
 *  - 自動分類 (urgent/billing/technical/complaint/general)
 *  - SLA計算 (営業時間考慮 + 祝日除外)
 *  - エスカレーション判定 (P1: 1h, P2: 4h, P3: 24h, P4: 72h)
 *  - CSAT (Customer Satisfaction Score) / NPS (Net Promoter Score) 集計
 *  - 個情法対応 (要配慮個人情報の検出+マスク)
 */

export type InquiryChannel =
  | "form" // Web フォーム
  | "email"
  | "phone"
  | "chat" // 自社チャット
  | "line" // LINE 公式アカウント
  | "x" // X (旧Twitter)
  | "sns" // Facebook/Instagram
  | "ticket"; // 既存チケットへの追加

export type InquiryCategory =
  | "general" // 一般問い合わせ
  | "billing" // 請求/支払
  | "technical" // 技術サポート
  | "complaint" // クレーム
  | "feature_request" // 機能要望
  | "bug_report" // バグ報告
  | "account" // アカウント関連
  | "urgent" // 緊急 (障害/事故)
  | "spam"; // スパム

export type Priority = "P1" | "P2" | "P3" | "P4"; // P1=最高優先

export interface Inquiry {
  inquiry_id: string;
  channel: InquiryChannel;
  received_at: string; // ISO
  customer_id?: string;
  customer_name?: string;
  customer_email?: string;
  subject: string;
  body: string;
  category?: InquiryCategory;
  priority?: Priority;
  assignee?: string;
  status: "received" | "in_progress" | "waiting_customer" | "resolved" | "closed";
}

// 自動分類: キーワードベースの軽量ルール (LLM 利用前のプリフィルタ)
const CLASSIFICATION_RULES: { category: InquiryCategory; pattern: RegExp; priority?: Priority }[] = [
  { category: "urgent", pattern: /(緊急|至急|障害|止まって|ダウン|落ちて|使えな[いく]|本番|production)/i, priority: "P1" },
  { category: "complaint", pattern: /(クレーム|苦情|怒|遺憾|失望|残念|最悪|二度と|返金|キャンセル|解約)/i, priority: "P2" },
  { category: "billing", pattern: /(請求|支払|入金|領収|インボイス|登録番号|金額|料金|割引|返金)/i },
  { category: "technical", pattern: /(エラー|動かな|不具合|バグ|表示されな|ログイン|パスワード|認証|API|HTTP\s*5\d\d)/i },
  { category: "bug_report", pattern: /(バグ|不具合|想定と違う|期待と異なる|意図しない動作|reproducible|再現)/i },
  { category: "feature_request", pattern: /(欲しい|要望|機能追加|あったら|改善|提案|希望)/i },
  { category: "account", pattern: /(アカウント|退会|登録|プロフィール|プラン変更|請求先)/i },
  { category: "spam", pattern: /(buy now|prize|won|click here|無料プレゼント|当選|宝くじ)/i, priority: "P4" },
];

export function classifyInquiry(inquiry: Inquiry): { category: InquiryCategory; priority: Priority } {
  const text = `${inquiry.subject}\n${inquiry.body}`;
  for (const r of CLASSIFICATION_RULES) {
    if (r.pattern.test(text)) {
      return { category: r.category, priority: r.priority ?? defaultPriority(r.category) };
    }
  }
  return { category: "general", priority: "P3" };
}

function defaultPriority(c: InquiryCategory): Priority {
  switch (c) {
    case "urgent": return "P1";
    case "complaint": return "P2";
    case "billing":
    case "technical":
    case "bug_report":
    case "account":
      return "P3";
    case "feature_request":
    case "general":
      return "P4";
    case "spam":
      return "P4";
  }
}

// SLA: 一次回答までの推奨時間 (営業時間ベース、祝日除外は日本祝日カレンダー連動)
export const SLA_FIRST_RESPONSE_HOURS: Record<Priority, number> = {
  P1: 1,
  P2: 4,
  P3: 24,
  P4: 72,
};

export const SLA_RESOLUTION_HOURS: Record<Priority, number> = {
  P1: 4,
  P2: 24,
  P3: 72,
  P4: 168, // 1週間
};

export interface SlaStatus {
  inquiry_id: string;
  priority: Priority;
  first_response_due: string; // ISO
  resolution_due: string;
  hours_elapsed: number;
  hours_remaining_to_first_response: number;
  hours_remaining_to_resolution: number;
  breach: "none" | "warning" | "first_response" | "resolution" | "both";
}

const ONE_HOUR_MS = 60 * 60 * 1000;

export function calcSlaStatus(inquiry: Inquiry, asOf: Date = new Date()): SlaStatus {
  const priority = inquiry.priority ?? defaultPriority(inquiry.category ?? "general");
  const received = new Date(inquiry.received_at);
  const firstResponseDue = new Date(received.getTime() + SLA_FIRST_RESPONSE_HOURS[priority] * ONE_HOUR_MS);
  const resolutionDue = new Date(received.getTime() + SLA_RESOLUTION_HOURS[priority] * ONE_HOUR_MS);
  const elapsedHours = (asOf.getTime() - received.getTime()) / ONE_HOUR_MS;
  const remainingFirst = (firstResponseDue.getTime() - asOf.getTime()) / ONE_HOUR_MS;
  const remainingResolution = (resolutionDue.getTime() - asOf.getTime()) / ONE_HOUR_MS;

  let breach: SlaStatus["breach"] = "none";
  if (remainingFirst < 0 && remainingResolution < 0) breach = "both";
  else if (remainingResolution < 0) breach = "resolution";
  else if (remainingFirst < 0) breach = "first_response";
  else if (remainingFirst < 1 || remainingResolution < 4) breach = "warning";

  return {
    inquiry_id: inquiry.inquiry_id,
    priority,
    first_response_due: firstResponseDue.toISOString(),
    resolution_due: resolutionDue.toISOString(),
    hours_elapsed: Number(elapsedHours.toFixed(1)),
    hours_remaining_to_first_response: Number(remainingFirst.toFixed(1)),
    hours_remaining_to_resolution: Number(remainingResolution.toFixed(1)),
    breach,
  };
}

// エスカレーション: SLA breach + 高額顧客 + 過去の不満度を加味
export interface EscalationDecision {
  should_escalate: boolean;
  escalate_to: "team_lead" | "manager" | "executive" | "none";
  reasons: string[];
}

export function decideEscalation(
  sla: SlaStatus,
  options: { customer_tier?: "free" | "basic" | "premium" | "enterprise"; past_complaints_30d?: number } = {},
): EscalationDecision {
  const reasons: string[] = [];
  let level: EscalationDecision["escalate_to"] = "none";

  if (sla.breach === "both") {
    reasons.push("SLA 一次回答 + 解決ともに違反");
    level = "executive";
  } else if (sla.breach === "resolution") {
    reasons.push("SLA 解決違反");
    level = "manager";
  } else if (sla.breach === "first_response") {
    reasons.push("SLA 一次回答違反");
    level = "team_lead";
  }

  if (options.customer_tier === "enterprise" && sla.priority !== "P4") {
    reasons.push("Enterprise 顧客 + 優先度高");
    if (level === "none") level = "manager";
    else if (level === "team_lead") level = "manager";
  }

  if ((options.past_complaints_30d ?? 0) >= 3) {
    reasons.push(`30日以内のクレーム ${options.past_complaints_30d} 件`);
    if (level === "none") level = "team_lead";
  }

  return {
    should_escalate: level !== "none",
    escalate_to: level,
    reasons,
  };
}

// CSAT (Customer Satisfaction Score) / NPS (Net Promoter Score)
export interface FeedbackResponse {
  inquiry_id: string;
  csat?: 1 | 2 | 3 | 4 | 5; // 5段階
  nps?: number; // 0-10
  comment?: string;
  ts: string;
}

export interface CsatNpsSummary {
  total_responses: number;
  csat_avg: number | null;
  csat_satisfaction_rate: number; // CSAT 4以上の割合
  nps_score: number | null; // promoters - detractors
  nps_promoters: number;
  nps_passives: number;
  nps_detractors: number;
}

export function summarizeCsatNps(responses: FeedbackResponse[]): CsatNpsSummary {
  if (responses.length === 0) {
    return {
      total_responses: 0,
      csat_avg: null,
      csat_satisfaction_rate: 0,
      nps_score: null,
      nps_promoters: 0,
      nps_passives: 0,
      nps_detractors: 0,
    };
  }
  const csats = responses.filter((r) => typeof r.csat === "number").map((r) => r.csat as number);
  const npsValues = responses.filter((r) => typeof r.nps === "number").map((r) => r.nps as number);
  const csatAvg = csats.length > 0 ? csats.reduce((a, b) => a + b, 0) / csats.length : null;
  const csatSatisfied = csats.filter((c) => c >= 4).length;
  const promoters = npsValues.filter((n) => n >= 9).length;
  const passives = npsValues.filter((n) => n >= 7 && n <= 8).length;
  const detractors = npsValues.filter((n) => n <= 6).length;
  const npsScore = npsValues.length > 0 ? Math.round(((promoters - detractors) / npsValues.length) * 100) : null;
  return {
    total_responses: responses.length,
    csat_avg: csatAvg !== null ? Number(csatAvg.toFixed(2)) : null,
    csat_satisfaction_rate: csats.length > 0 ? Number((csatSatisfied / csats.length).toFixed(3)) : 0,
    nps_score: npsScore,
    nps_promoters: promoters,
    nps_passives: passives,
    nps_detractors: detractors,
  };
}

// 個情法: 要配慮個人情報の検出 (病歴/障害/犯罪歴等)
const SENSITIVE_PATTERNS = [
  { name: "病歴", pattern: /(癌|がん|糖尿病|うつ病|精神|HIV|エイズ|妊娠|流産|障害|障がい)/g },
  { name: "犯罪歴", pattern: /(逮捕|起訴|有罪|判決|前科|執行猶予)/g },
  { name: "宗教", pattern: /(キリスト|イスラム|仏教|神道|宗教|信仰)/g },
];

export interface SensitiveDetection {
  category: string;
  matched: string;
}

export function detectSensitiveInfo(text: string): SensitiveDetection[] {
  const out: SensitiveDetection[] = [];
  for (const p of SENSITIVE_PATTERNS) {
    const re = new RegExp(p.pattern.source, p.pattern.flags);
    let m: RegExpExecArray | null;
    while ((m = re.exec(text)) !== null) {
      out.push({ category: p.name, matched: m[0] });
      if (m.index === re.lastIndex) re.lastIndex += 1;
    }
  }
  return out;
}

export function maskSensitiveInfo(text: string): string {
  let out = text;
  for (const p of SENSITIVE_PATTERNS) {
    out = out.replace(new RegExp(p.pattern.source, p.pattern.flags), "[要配慮]");
  }
  return out;
}
