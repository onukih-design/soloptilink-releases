// @ts-check
/**
 * 政府電子申請統合 DNA (Phase 16)
 *
 * Claude Code がカバーしない日本の政府電子申請プラットフォームを
 * 一つのライブラリで完全カバー。
 *
 *  - e-Gov 電子申請 (各省庁横断)
 *  - e-Tax (国税庁: 法人税/消費税/源泉所得税)
 *  - eLTAX (地方税: 法人住民税/事業税/固定資産税)
 *  - GビズID (gBizID Prime/Member/Entry シングルサインオン)
 *  - GビズインフォAPI (法人番号公表サイト連携)
 *  - 法人番号 13桁 検証
 *  - 各種電子申請のスケジュール (法定提出期限)
 *
 * 設計方針:
 *  - e-Tax / eLTAX の共通 XML スキーマ参考 (CSV → XML 変換のスケルトン)
 *  - GビズID の認可ロール判定 (Prime/Member/Entry)
 *  - 法人番号は 13桁 (1桁チェックデジット + 12桁基礎番号)
 *
 * 参考:
 *   - e-Gov 電子申請 https://shinsei.e-gov.go.jp/
 *   - e-Tax https://www.e-tax.nta.go.jp/
 *   - eLTAX https://www.eltax.lta.go.jp/
 *   - GビズID https://gbiz-id.go.jp/
 *   - 法人番号公表サイト https://www.houjin-bangou.nta.go.jp/
 */

// =============================================================================
// 法人番号 (国税庁) 13桁 検証
// =============================================================================

/**
 * 法人番号の妥当性検証 (13桁)
 *  - 1桁目: チェックデジット
 *  - 2-13桁目: 基礎番号 (12桁)
 *
 * チェックデジット計算式:
 *   9 - ( Σ(i=1..12) Pn × Qn ) mod 9
 *   - Pn: 基礎番号の n桁目の数字
 *   - Qn: n が偶数のとき 1, 奇数のとき 2
 */
export function isValidHoujinBangou(num: string): boolean {
  if (!/^\d{13}$/.test(num)) return false;
  const checkDigit = Number(num[0]);
  const basis = num.slice(1); // 12桁
  let sum = 0;
  for (let i = 0; i < 12; i++) {
    const digit = Number(basis[11 - i]); // n=1 (右端) から計算
    const n = i + 1;
    const Q = n % 2 === 0 ? 1 : 2;
    sum += digit * Q;
  }
  const expected = 9 - (sum % 9);
  return checkDigit === expected;
}

// =============================================================================
// GビズID
// =============================================================================

export type GBizIdRole = 'gBizID_Prime' | 'gBizID_Member' | 'gBizID_Entry';

export interface GBizIdProfile {
  /** GビズID (メールアドレス) */
  account_id: string;
  /** ロール */
  role: GBizIdRole;
  /** 法人番号 (Prime/Member は必須、Entry は任意) */
  houjin_bangou?: string;
  /** 代表者氏名 */
  rep_name?: string;
  /** 屋号 (個人事業主の場合) */
  sole_prop_name?: string;
  /** 多要素認証済み */
  mfa_enabled: boolean;
}

/**
 * GビズIDの利用可能サービス判定
 *
 * - Prime: 全電子申請+法人代表者専用 (e-Gov全/jGrants/社会保険手続き等)
 * - Member: Primeから委任された従業員 (Prime同等の手続きのうち委任分のみ)
 * - Entry: 個人事業主含む (限定的な電子申請のみ)
 */
export function listGBizIdAvailableServices(role: GBizIdRole): string[] {
  switch (role) {
    case 'gBizID_Prime':
      return [
        'jGrants (補助金電子申請)',
        '社会保険手続き (e-Gov 健康保険/厚生年金/雇用保険/労災)',
        'GビズフォームDB',
        'gBizINFO API (拡張アクセス)',
        '中小企業庁 ミラサポplus',
        '農林水産省共通申請サービス eMAFF',
        '中小企業基盤整備機構 J-Net21 各種申請',
      ];
    case 'gBizID_Member':
      return [
        'Primeから委任された範囲のみ',
        'jGrants (Primeから委任時のみ)',
        '社会保険手続き (Primeから委任時のみ)',
      ];
    case 'gBizID_Entry':
      return [
        '一部のjGrants (個人事業主向け補助金)',
        'eMAFF (個人事業主農業者の一部申請)',
      ];
  }
}

// =============================================================================
// GビズインフォAPI (法人番号公表サイト)
// =============================================================================

export interface CorporationInfo {
  houjin_bangou: string;
  name: string;
  /** 法人区分 (101=株式会社/201=有限会社/301=合名会社/302=合資会社/303=合同会社/...) */
  kind: string;
  postal_code?: string;
  prefecture?: string;
  city?: string;
  address?: string;
  /** 設立年月日 (YYYY-MM-DD) */
  founded_date?: string;
  /** 資本金 (円) */
  capital?: number;
  /** 従業員数 */
  employees?: number;
}

/**
 * GビズインフォAPI モック
 *
 * 本番では https://info.gbiz.go.jp/hojin/v1/hojin/{法人番号} を fetch
 */
export function mockGBizInfoLookup(houjin_bangou: string): CorporationInfo | null {
  if (!isValidHoujinBangou(houjin_bangou)) return null;
  return {
    houjin_bangou,
    name: '株式会社サンプル',
    kind: '101',
    postal_code: '100-0001',
    prefecture: '東京都',
    city: '千代田区',
    address: '千代田1-1-1',
    founded_date: '2020-04-01',
    capital: 10_000_000,
    employees: 50,
  };
}

// =============================================================================
// e-Tax (国税庁)
// =============================================================================

export type EtaxFormType =
  | 'corporate_tax_return' // 法人税確定申告書
  | 'consumption_tax_return' // 消費税確定申告書
  | 'withholding_income_tax' // 源泉所得税納付書
  | 'final_tax_return' // 所得税確定申告書
  | 'qualified_invoice_registration' // 適格請求書発行事業者登録申請
  | 'inhabitants_tax_payment_record'; // 給与支払報告書

export interface EtaxFiling {
  form_type: EtaxFormType;
  /** 法人番号 or 個人番号 (マイナンバー) */
  taxpayer_id: string;
  /** 課税期間 (YYYY-MM 〜 YYYY-MM) */
  period_from: string;
  period_to: string;
  /** 申告データ (フォーム種別ごとに構造が異なる) */
  data: Record<string, unknown>;
  /** 電子署名 (ICカードリーダ + マイナンバーカード or 商業登記電子証明書) */
  digital_signature?: string;
}

/**
 * 法定提出期限の判定
 *
 *  - 法人税: 事業年度終了の翌日から2ヶ月以内
 *  - 消費税: 課税期間終了の翌日から2ヶ月以内
 *  - 源泉所得税: 翌月10日まで (納期特例承認の場合は半年に1回)
 *  - 確定申告: 翌年2/16〜3/15
 */
export function getEtaxDeadline(formType: EtaxFormType, periodEndYmd: string): Date {
  const end = new Date(periodEndYmd);
  switch (formType) {
    case 'corporate_tax_return':
    case 'consumption_tax_return': {
      const d = new Date(end);
      d.setMonth(d.getMonth() + 2);
      return d;
    }
    case 'withholding_income_tax': {
      const d = new Date(end);
      d.setMonth(d.getMonth() + 1);
      d.setDate(10);
      return d;
    }
    case 'final_tax_return': {
      const d = new Date(end.getFullYear() + 1, 2, 15); // 翌年3/15
      return d;
    }
    default: {
      const d = new Date(end);
      d.setMonth(d.getMonth() + 1);
      return d;
    }
  }
}

/**
 * e-Tax 申告データ → XML スケルトン (実際の XSD は国税庁公開)
 */
export function buildEtaxXmlSkeleton(filing: EtaxFiling): string {
  const dataXml = Object.entries(filing.data)
    .map(([k, v]) => `    <${k}>${escapeXml(String(v))}</${k}>`)
    .join('\n');
  return `<?xml version="1.0" encoding="UTF-8"?>
<EtaxFiling xmlns="http://www.nta.go.jp/etax/v1">
  <FormType>${filing.form_type}</FormType>
  <TaxpayerID>${escapeXml(filing.taxpayer_id)}</TaxpayerID>
  <PeriodFrom>${filing.period_from}</PeriodFrom>
  <PeriodTo>${filing.period_to}</PeriodTo>
  <Data>
${dataXml}
  </Data>
${filing.digital_signature ? `  <DigitalSignature>${escapeXml(filing.digital_signature)}</DigitalSignature>` : ''}
</EtaxFiling>`;
}

function escapeXml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

// =============================================================================
// eLTAX (地方税)
// =============================================================================

export type EltaxFormType =
  | 'corporate_inhabitant_tax' // 法人住民税申告
  | 'corporate_business_tax' // 法人事業税申告
  | 'fixed_asset_tax' // 固定資産税申告
  | 'individual_inhabitant_tax_payment_record' // 給与支払報告書
  | 'electronic_tax_payment'; // 電子納税

export interface EltaxFiling {
  form_type: EltaxFormType;
  taxpayer_id: string; // 法人番号
  /** 提出先自治体コード (JIS X 0401 都道府県コード + JIS X 0402 市区町村コード) */
  municipality_code: string;
  period_from: string;
  period_to: string;
  data: Record<string, unknown>;
  /** PCdesk (eLTAX 共通納税ポータル) 経由の納税フラグ */
  via_pcdesk: boolean;
}

/**
 * eLTAX 提出 → 共通納税対応自治体一覧 (主要 50 自治体例)
 */
export const ELTAX_MAJOR_MUNICIPALITIES = [
  { code: '131016', name: '東京都千代田区' },
  { code: '131024', name: '東京都中央区' },
  { code: '131032', name: '東京都港区' },
  { code: '141003', name: '神奈川県横浜市' },
  { code: '141500', name: '神奈川県川崎市' },
  { code: '231002', name: '愛知県名古屋市' },
  { code: '271004', name: '大阪府大阪市' },
  { code: '281000', name: '兵庫県神戸市' },
  { code: '401307', name: '福岡県福岡市' },
  { code: '011002', name: '北海道札幌市' },
  // ... 1700+ 全自治体は eLTAX 公開コード表参照
] as const;

/**
 * eLTAX 共通納税で支払える税目
 */
export const PCDESK_PAYABLE_TAXES = [
  '個人住民税 (特別徴収)',
  '法人都道府県民税',
  '法人事業税',
  '法人市町村民税',
  '事業所税',
  '固定資産税 (償却資産)',
] as const;

// =============================================================================
// 社会保険手続き (e-Gov 経由)
// =============================================================================

export type SocialInsuranceFormType =
  | 'health_insurance_acquisition' // 健康保険・厚生年金保険 被保険者資格取得届
  | 'health_insurance_loss' // 同 喪失届
  | 'employment_insurance_acquisition' // 雇用保険 被保険者資格取得届
  | 'employment_insurance_loss' // 同 喪失届
  | 'labor_insurance_annual_renewal' // 労働保険 年度更新
  | 'monthly_remuneration_revision' // 月額変更届
  | 'standard_remuneration_decision'; // 算定基礎届

export interface SocialInsuranceFiling {
  form_type: SocialInsuranceFormType;
  /** 事業所整理記号 (健保: 都道府県+記号 / 雇用: 11桁) */
  office_id: string;
  /** 被保険者番号 */
  insured_id?: string;
  data: Record<string, unknown>;
  /** GビズID Prime/Member 経由フラグ */
  gbiz_id_authenticated: boolean;
}

/**
 * 社会保険手続きの提出期限
 *  - 資格取得: 事実発生から 5 日以内 (健保) / 翌月 10 日まで (雇用)
 *  - 算定基礎届: 7/10
 *  - 月額変更届: 該当発覚から速やかに
 *  - 年度更新: 6/1 〜 7/10
 */
export function getSocialInsuranceDeadline(
  formType: SocialInsuranceFormType,
  eventYmd: string,
): Date {
  const event = new Date(eventYmd);
  switch (formType) {
    case 'health_insurance_acquisition':
    case 'health_insurance_loss': {
      const d = new Date(event);
      d.setDate(d.getDate() + 5);
      return d;
    }
    case 'employment_insurance_acquisition': {
      const d = new Date(event.getFullYear(), event.getMonth() + 1, 10);
      return d;
    }
    case 'standard_remuneration_decision': {
      return new Date(event.getFullYear(), 6, 10); // 7月10日
    }
    case 'labor_insurance_annual_renewal': {
      return new Date(event.getFullYear(), 6, 10);
    }
    default: {
      const d = new Date(event);
      d.setDate(d.getDate() + 14);
      return d;
    }
  }
}

// =============================================================================
// 政府共通電子申請 統一インターフェース
// =============================================================================

export interface EAppsSubmission {
  service: 'e-Gov' | 'e-Tax' | 'eLTAX' | 'jGrants' | 'eMAFF';
  filing_id: string;
  submitted_at: string; // ISO 8601
  /** 受付番号 (各システムから払い出し) */
  receipt_no?: string;
  status: 'queued' | 'submitted' | 'accepted' | 'rejected' | 'withdrawn';
  /** リジェクト理由 */
  reject_reason?: string;
}

export interface EAppsAuditEntry {
  filing_id: string;
  service: EAppsSubmission['service'];
  taxpayer_id: string;
  /** 認証手段 */
  auth_method: 'gBizID_Prime' | 'gBizID_Member' | 'mynumber_card' | 'commerce_cert';
  /** 操作 */
  action: 'create' | 'sign' | 'submit' | 'withdraw' | 'view' | 'download_receipt';
  ip_address?: string;
  user_agent?: string;
  ts: string;
}

/**
 * 電子申請 監査ログ生成 (個情法/会社法/法人税法 帳簿要件すべてに対応)
 */
export function buildEAppsAuditEntry(
  base: Omit<EAppsAuditEntry, 'ts'>,
): EAppsAuditEntry {
  return { ...base, ts: new Date().toISOString() };
}
