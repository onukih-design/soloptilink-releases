/**
 * SoloptiLinkAI Phase 45 — 反社会的勢力排除条例対応
 *
 * 47都道府県暴力団排除条例 (2011年〜全国施行) + 警察庁「企業が反社会的勢力による
 * 被害を防止するための指針」(平成19年6月19日) + 全銀協モデル + 経団連企業行動憲章
 * を統合した反社チェック・契約管理モジュール。
 *
 * カバー範囲:
 *  - 暴力団員 (暴力団員による不当な行為の防止等に関する法律2条6号)
 *  - 暴力団準構成員・元暴力団員 (離脱後5年経過しないもの)
 *  - 共生者・密接交際者
 *  - 都道府県暴排条例 (利益供与禁止 + 契約除外義務)
 *  - 反社契約条項 (排除条項 + 暴力団員等関係先取引拒絶)
 *  - 株主からの排除 (株主代表訴訟リスク)
 *  - 反社チェックサービス (RoboRobo / Reuters World-Check / Chiba警察 等)
 */

export type AntisocialCategory =
  | "boryokudan_active" // 暴力団員 (現役)
  | "boryokudan_quasi" // 準構成員
  | "boryokudan_ex_within5y" // 離脱後5年以内
  | "boryokudan_kyousei" // 共生者
  | "boryokudan_kinmitsu" // 密接交際者
  | "sokaiya" // 総会屋
  | "shakai_undo_hyobosha" // 社会運動標榜ゴロ
  | "tokushu_chinou_hanzai"; // 特殊知能暴力集団

export interface AntisocialEntity {
  entity_id: string;
  entity_name: string;
  kana_name?: string; // カナ氏名 (突合用)
  birth_date?: string;
  category: AntisocialCategory;
  source: string; // データソース (警察庁通知/RoboRobo/契約済DB 等)
  registered_at: string;
}

export interface PartyProfile {
  party_id: string;
  party_kind: "individual" | "company" | "shareholder" | "vendor" | "customer";
  full_name: string;
  kana_name?: string;
  birth_date?: string;
  representative_name?: string; // 法人の場合
  address?: string;
  prefecture?: string;
  ownership_pct?: number; // 株主の場合
}

export interface AsCheckFinding {
  rule: string;
  severity: "info" | "watch" | "warning" | "violation" | "block";
  hint: string;
}

/** 反社DBとの突合 (氏名+生年月日 完全一致 / カナ氏名 部分一致) */
export function matchAgainstAntisocialDb(
  party: PartyProfile,
  db: AntisocialEntity[],
): AntisocialEntity[] {
  const norm = (s: string | undefined) =>
    (s ?? "").replace(/\s/g, "").toLowerCase();
  const matches: AntisocialEntity[] = [];
  for (const e of db) {
    const nameMatch =
      norm(e.entity_name) === norm(party.full_name) ||
      (e.kana_name && party.kana_name && norm(e.kana_name) === norm(party.kana_name));
    const dobMatch =
      !e.birth_date ||
      !party.birth_date ||
      e.birth_date === party.birth_date;
    if (nameMatch && dobMatch) matches.push(e);
  }
  return matches;
}

/** 取引可否判定 (排除条項の発動) */
export function judgeTransactionEligibility(
  party: PartyProfile,
  matches: AntisocialEntity[],
): AsCheckFinding[] {
  const findings: AsCheckFinding[] = [];

  if (matches.length === 0) {
    findings.push({
      rule: "反社チェック (一次スクリーニング)",
      severity: "info",
      hint: "反社DB との一致なし。ただし完全保証ではない。継続モニタリング推奨。",
    });
    return findings;
  }

  for (const m of matches) {
    const isHard =
      m.category === "boryokudan_active" ||
      m.category === "boryokudan_quasi" ||
      m.category === "boryokudan_ex_within5y" ||
      m.category === "boryokudan_kyousei" ||
      m.category === "sokaiya";

    findings.push({
      rule: `反社該当 (${m.category}) - ${m.source}`,
      severity: isHard ? "block" : "warning",
      hint: isHard
        ? `${party.full_name} は ${m.category} と判定 → 即時取引拒絶。既存契約は反社排除条項に基づき即解約。利益供与は条例違反 (50万円以下過料)。`
        : `${party.full_name} は ${m.category} に該当する疑い。反社2次調査 + 顧問弁護士相談を実施。`,
    });
  }

  return findings;
}

/** 株主排除 (5%超の場合は特に注意) */
export function judgeShareholderExclusion(
  party: PartyProfile,
  matches: AntisocialEntity[],
): AsCheckFinding[] {
  if (party.party_kind !== "shareholder") return [];
  const findings: AsCheckFinding[] = [];
  const pct = party.ownership_pct ?? 0;
  if (matches.length > 0 && pct > 0) {
    findings.push({
      rule: "株主排除 (反社株主)",
      severity: pct >= 5 ? "block" : "warning",
      hint:
        pct >= 5
          ? `反社株主が ${pct}% 保有。会社法210条 (募集株式買戻し) / 自己株取得 / 特別決議による排除を検討。株主代表訴訟リスクあり。`
          : `反社株主 ${pct}% を確認。少額でも継続保有は信用毀損リスク。買取交渉。`,
    });
  }
  return findings;
}

/** 契約書 反社排除条項 (通称: 反社条項) のテンプレ */
export function buildAntisocialClause(): string {
  return `## 第◯条 (反社会的勢力の排除)
1. 甲及び乙は、それぞれ相手方に対して、自己 (法人にあってはその役員) 及び自己の関係者が、
   現在及び将来にわたり、次の各号に該当しないことを表明し保証する。
   (1) 暴力団、暴力団員、暴力団員でなくなった時から 5 年を経過しない者、暴力団準構成員、
       暴力団関係企業、総会屋等、社会運動等標榜ゴロ又は特殊知能暴力集団等、その他これらに準ずる者
   (2) 役員等が反社会的勢力と社会的に非難されるべき関係を有していること
   (3) 反社会的勢力に対して資金等を提供し、又は便宜を供与する等の関与をしていること
   (4) 自ら又は第三者を利用して、相手方に対し、暴力的な要求行為、法的責任を超えた不当な要求行為、
       取引に関して脅迫的な言動・暴力を用いる行為、風説の流布・偽計・威力を用いて相手方の信用を
       毀損し、又は業務を妨害する行為、その他これらに準ずる行為

2. 甲又は乙の一方が前項の表明保証に違反したことが判明した場合、相手方は何らの催告を要することなく、
   本契約を直ちに解除することができる。この場合、解除を行った当事者は相手方に対し、これにより
   生じた損害の賠償義務を負わない。

3. 解除された当事者は、解除を行った当事者に対し、その被った損害を賠償する責任を負う。
`;
}

/** 都道府県暴排条例の利益供与禁止 (条例ごとに微差あり) */
export interface BenefitProvisionAssessment {
  prefecture: string;
  recipient_known_to_be_antisocial: boolean;
  benefit_amount_yen: number;
  purpose_legitimate: boolean; // 通常の取引としての対価か
}

export function assessBenefitProvision(
  a: BenefitProvisionAssessment,
): AsCheckFinding[] {
  const findings: AsCheckFinding[] = [];
  if (a.recipient_known_to_be_antisocial && !a.purpose_legitimate) {
    findings.push({
      rule: `${a.prefecture} 暴力団排除条例 (利益供与禁止)`,
      severity: "violation",
      hint: `相手方が反社と知りつつ、正当な対価関係なく ¥${a.benefit_amount_yen.toLocaleString()} を供与。条例違反: 公表 + 50万円以下過料。事業者氏名公表は信用毀損 (上場会社は IR 影響大)。`,
    });
  }
  return findings;
}

/** 反社チェックフロー (新規取引前) */
export interface NewVendorOnboardingCheck {
  vendor: PartyProfile;
  representative: PartyProfile;
  major_shareholders: PartyProfile[];
  conducted_db_matching: boolean;
  conducted_web_search: boolean;
  conducted_field_visit: boolean;
}

export function evaluateOnboardingProcess(
  c: NewVendorOnboardingCheck,
): AsCheckFinding[] {
  const findings: AsCheckFinding[] = [];
  if (!c.conducted_db_matching) {
    findings.push({
      rule: "実務統制 (反社チェック)",
      severity: "warning",
      hint: "反社DB照合未実施。RoboRobo/反社チェック.com/警察庁通報DB等での照合を必須化。",
    });
  }
  if (!c.conducted_web_search) {
    findings.push({
      rule: "実務統制 (Webスクリーニング)",
      severity: "info",
      hint: "Web検索 (代表者氏名+逮捕/暴力団) 未実施。RoboRobo + Google Search の二段構えが標準。",
    });
  }
  return findings;
}

export function buildAntisocialPolicyTemplate(orgName: string): string {
  return `# ${orgName} 反社会的勢力排除規程

## 第1条 (目的)
本規程は、政府指針 (平成19年6月19日) 及び都道府県暴排条例に基づき、
${orgName} (以下「当社」) が反社会的勢力との関係を一切持たないことを宣言し、
取引・採用・株主構成において反社会的勢力を排除することを目的とする。

## 第2条 (基本方針)
当社は、反社会的勢力に対し、以下を堅持する。
(1) 不当要求の拒絶
(2) 利益供与の禁止
(3) 警察・弁護士等の外部専門家との連携
(4) 民事・刑事の法的対応の徹底

## 第3条 (反社チェック)
新規取引・新規採用・新規株主受入時は、反社DBによる照合 + Webスクリーニング + 必要に応じ実地調査を行う。

## 第4条 (反社条項)
すべての契約書に反社排除条項を組み込み、違反判明時は即解除する。

## 第5条 (株主排除)
株主に反社該当者が含まれる場合、自己株取得 + 特別決議 + 買取請求等で排除する。

## 第6条 (社内体制)
反社対応統括責任者: 取締役管理本部長
特殊暴力防止対策連絡協議会 (特防協) に加入し、警察情報を活用する。

## 第7条 (役員・従業員の責務)
役員・従業員は、業務上反社の疑いがある者と接触した場合、直ちに上長に報告する。
独断で交渉してはならない。
`;
}
