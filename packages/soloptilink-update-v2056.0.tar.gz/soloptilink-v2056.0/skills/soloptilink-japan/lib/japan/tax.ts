/**
 * 消費税・源泉徴収計算ユーティリティ
 */

export type TaxRate = 'standard' | 'reduced' | 'exempt' | 'nontaxable';

/**
 * 消費税額の計算 (税抜→税込 / 税込→税抜)
 */
export function calcTax(
  amount: number,
  rate: TaxRate,
  mode: 'exclusive' | 'inclusive' = 'exclusive'
): { base: number; tax: number; total: number } {
  const rateValue = rate === 'standard' ? 0.10 : rate === 'reduced' ? 0.08 : 0;
  if (mode === 'exclusive') {
    const tax = Math.floor(amount * rateValue);
    return { base: amount, tax, total: amount + tax };
  } else {
    const base = Math.floor(amount / (1 + rateValue));
    const tax = amount - base;
    return { base, tax, total: amount };
  }
}

/** 報酬・料金等の源泉徴収の区分 (所得税法 第204条第1項) */
export type RewardWithholdingType = 'creative' | 'judicial' | 'hostess';

const REWARD_WITHHOLDING_TYPES: readonly RewardWithholdingType[] = ['creative', 'judicial', 'hostess'];

/**
 * 【報酬・料金等】の源泉徴収税額の計算 (所得税法 第204条第1項)。
 *
 * ★これは「報酬・料金・契約金及び賞金」に対する源泉徴収であり、
 *   【給与】の源泉徴収ではない。給与の源泉徴収は月額表 (国税庁告示別表第一) を引く
 *   `hr_payroll.calcWithholdingTax()` を使うこと。両者は同じ支給額でも税額が全く違う
 *   (例: 300,000円 → 報酬 30,630円 / 給与 (甲欄・扶養0人) 7,930円)。
 *   取り違えると静かに約4倍の誤額が出るため、本関数は用途が名前に出る
 *   `calcRewardWithholdingTax` を正式名とする。
 *
 * - デザイン・原稿料・講演料等: 100万円以下 → 10.21% / 100万円超 → (額-100万)×20.42%+102,100円
 * - 司法書士等: 1万円控除後 × 10.21%
 * - ホステス等: 控除後 × 10.21%
 *
 * @param amount 支払金額 (税抜)
 * @param type   報酬・料金の区分
 * @throws 区分が不正な場合。★旧実装はどの区分にも当たらないと黙って源泉徴収0円を返していたため、
 *         給与の月額表と取り違えて `calcWithholdingTax(300000, 2)` のように呼ぶと
 *         「源泉徴収0円」の支払調書が正常に出力されていた。0円で通さず例外で顕在化させる。
 */
export function calcRewardWithholdingTax(
  amount: number,
  type: RewardWithholdingType
): { withholding: number; netPayment: number } {
  if (!REWARD_WITHHOLDING_TYPES.includes(type)) {
    throw new Error(
      `報酬・料金の区分が不正です (受け取った値: ${JSON.stringify(type)})。` +
      `'creative' | 'judicial' | 'hostess' のいずれかを指定してください。` +
      `給与の源泉徴収を求めたい場合は、本関数ではなく給与所得の源泉徴収税額表 (月額表) を引く ` +
      `hr_payroll.calcWithholdingTax(課税対象額, 扶養親族等の数) を使ってください。`
    );
  }
  let withholding = 0;
  if (type === 'creative') {
    if (amount <= 1_000_000) withholding = Math.floor(amount * 0.1021);
    else withholding = Math.floor((amount - 1_000_000) * 0.2042 + 102_100);
  } else if (type === 'judicial') {
    withholding = Math.floor(Math.max(0, amount - 10_000) * 0.1021);
  } else if (type === 'hostess') {
    const deduction = 5_000; // 日額控除
    withholding = Math.floor(Math.max(0, amount - deduction) * 0.1021);
  }
  return { withholding, netPayment: amount - withholding };
}

/**
 * @deprecated 旧名。`hr_payroll.ts` の【給与】用 `calcWithholdingTax()` と同名で紛らわしいため、
 *   報酬・料金であることが名前に出る {@link calcRewardWithholdingTax} へ移行すること。
 *   後方互換のために残しているだけで、中身は同一。新規のコードで使わないこと。
 */
export const calcWithholdingTax = calcRewardWithholdingTax;

/*
 * 【削除済み】calcSalaryWithholding(monthlySalary, dependents)
 *
 *   給与の源泉徴収を「社会保険料を一律15%と仮定」した近似式で求めていた旧世代の実装。
 *   国税庁の月額表を引く hr_payroll.calcWithholdingTax() と同一入力で最大 13,290円/月 食い違い
 *   (低額帯は過少・高額帯は過大)、そのまま納付すると不足税額が生じていた。
 *   ~/.soloptilink 配下を全数調査したところ生きた呼び出し元が 0 件だったため、
 *   近似式が二度と使われないよう本体ごと削除した (2026-08-14)。
 *
 *   給与の源泉徴収は必ず実表を引くこと:
 *     import { calcWithholdingTax } from './hr_payroll';   // 令和8年分 月額表 (甲欄/乙欄)
 *     import { calcBonusWithholdingTax } from './gensen_bonus_rate_r8'; // 賞与の算出率の表
 */

/**
 * インボイス方式の税率別集計
 */
export function summarizeByRate(
  items: Array<{ amount: number; rate: TaxRate }>
): Record<TaxRate, { subtotal: number; tax: number }> {
  const summary: Record<TaxRate, { subtotal: number; tax: number }> = {
    standard: { subtotal: 0, tax: 0 },
    reduced: { subtotal: 0, tax: 0 },
    exempt: { subtotal: 0, tax: 0 },
    nontaxable: { subtotal: 0, tax: 0 },
  };
  for (const it of items) {
    summary[it.rate].subtotal += it.amount;
  }
  summary.standard.tax = Math.floor(summary.standard.subtotal * 0.10);
  summary.reduced.tax = Math.floor(summary.reduced.subtotal * 0.08);
  return summary;
}
