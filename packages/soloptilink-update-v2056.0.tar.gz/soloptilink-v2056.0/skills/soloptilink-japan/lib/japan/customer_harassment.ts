/**
 * SoloptiLinkAI Phase 45 — カスタマーハラスメント対応
 *
 * - 東京都カスタマー・ハラスメント防止条例 (R6.10.4 公布 / R7.4.1 施行 / 罰則無 / 理念条例)
 * - 北海道・群馬県カスハラ条例 (R7.4.1 施行)
 * - 三重県条例 (R8年度成立予定 / 全国初の罰則付き)
 * - 三重県桑名市条例 (R6.4 施行 / 加害者氏名公表)
 * - 改正労働施策総合推進法 (R7.6.11 改正 / R8.10.1 施行 / 全事業主に措置義務)
 * - 厚労省「カスタマーハラスメント対策企業マニュアル」(R4 初版 / R6 改訂)
 * - 個情法 R5改正 第21条4項3号 (録音録画の利用目的通知例外)
 * - 労契法 第5条 (安全配慮義務)
 *
 * カスハラ判断3要素 (法/条例/マニュアル共通):
 *  1. 顧客等の言動
 *  2. 社会通念上相当な範囲を超える
 *  3. 就業環境を害する
 *
 * SoT:
 *  - https://www.reiki.metro.tokyo.lg.jp/reiki/reiki_honbun/g101RG00005328.html
 *  - https://www.mhlw.go.jp/content/11921000/000894063.pdf
 */

export const KASUHARA_VERSION = "R7.4.1-tokyo,R8.10.1-national";
export const KASUHARA_NATIONAL_EFFECTIVE = "2026-10-01"; // 改正労働施策総合推進法
export const KASUHARA_TOKYO_EFFECTIVE = "2025-04-01"; // 東京都条例

export const KASUHARA_TYPES = {
  TIME_RESTRAINT: "時間拘束型",
  REPEAT: "リピート型",
  ABUSIVE_LANGUAGE: "暴言型",
  UNREASONABLE_DEMAND: "不当要求型",
  PHYSICAL_VIOLENCE: "暴力身体接触型",
  THREAT_INTIMIDATION: "威嚇脅迫型",
  SEXUAL_DISCRIMINATORY: "性的差別言動型",
  PRIVACY_INVASION: "SNS録画拡散型",
} as const;
export type KasuharaType = keyof typeof KASUHARA_TYPES;

export const ESCALATION_LEVELS = {
  L1_PRIMARY: "現場一次対応",
  L2_SUPERVISOR: "上長介入",
  L3_DEDICATED: "カスハラ相談窓口/法務",
  L4_POLICE: "警察通報",
  L5_CARE: "被害従業員ケア",
} as const;
export type EscalationLevel = keyof typeof ESCALATION_LEVELS;

export const SEVERITY = ["low", "mid", "high", "critical"] as const;
export type Severity = (typeof SEVERITY)[number];

export const INDUSTRY_RISK_WEIGHTS = {
  medical_welfare: { rate_pct: 29.9, weight: "high" },
  public_admin: { rate_pct: 29.4, weight: "high" },
  transport_postal: { rate_pct: 26.5, weight: "mid" },
  hospitality_food: { rate_pct: 31.2, weight: "high" },
  retail_wholesale: { rate_pct: 35.0, weight: "high" },
  longterm_care: { rate_pct: 34.5, weight: "critical" },
} as const;
export type IndustryCode = keyof typeof INDUSTRY_RISK_WEIGHTS;

export interface KasuharaIncident {
  occurredAt: Date;
  customerType: "consumer" | "b2b" | "public_user";
  utterances: string[];
  durationMinutes?: number;
  recordedMedia?: "audio" | "video" | "none";
  staffId: string;
  industry: IndustryCode;
  physicalContact?: boolean;
  weaponPresented?: boolean;
  refusedToLeave?: boolean;
  snsThreat?: boolean;
  monetaryDemand?: boolean;
}

export interface ThreeFactorScore {
  customerLanguage: boolean;
  exceedsSocialNorm: boolean;
  harmsWorkEnv: boolean;
  isKasuhara: boolean;
}

export interface KasuharaClassification {
  types: KasuharaType[];
  threeFactor: ThreeFactorScore;
  severity: Severity;
  escalation: EscalationLevel;
  needsImmediatePolice: boolean;
  reasons: string[];
}

const ABUSE_KEYWORDS = ["殺す", "死ね", "馬鹿", "クズ", "ふざけるな", "土下座", "晒す", "二度と"];
const SEXUAL_KEYWORDS = ["セクハラ", "胸", "下半身", "セックス", "デート"];
const DISCRIM_KEYWORDS = ["外人", "黒人", "差別", "国に帰れ", "オカマ"];
const THREAT_KEYWORDS = ["殺す", "晒す", "潰す", "燃やす", "復讐", "訴える"];

function detectKeywords(utterances: string[], keywords: string[]): boolean {
  const text = utterances.join(" ");
  return keywords.some((k) => text.includes(k));
}

/** カスハラ3要素検証 */
export function validateThreeFactors(i: KasuharaIncident): ThreeFactorScore {
  const customerLanguage = i.utterances.length > 0 || !!i.physicalContact;
  const exceedsSocialNorm =
    detectKeywords(i.utterances, ABUSE_KEYWORDS) ||
    detectKeywords(i.utterances, SEXUAL_KEYWORDS) ||
    detectKeywords(i.utterances, DISCRIM_KEYWORDS) ||
    detectKeywords(i.utterances, THREAT_KEYWORDS) ||
    !!i.physicalContact ||
    !!i.weaponPresented ||
    !!i.refusedToLeave ||
    !!i.snsThreat ||
    (i.durationMinutes ?? 0) > 30;
  const harmsWorkEnv = exceedsSocialNorm;
  return {
    customerLanguage,
    exceedsSocialNorm,
    harmsWorkEnv,
    isKasuhara: customerLanguage && exceedsSocialNorm && harmsWorkEnv,
  };
}

/** 8類型の自動分類 */
export function classifyKasuhara(i: KasuharaIncident): KasuharaClassification {
  const types: KasuharaType[] = [];
  const reasons: string[] = [];

  if ((i.durationMinutes ?? 0) > 30) {
    types.push("TIME_RESTRAINT");
    reasons.push(`時間拘束 ${i.durationMinutes}分 > 30分閾値`);
  }
  if (detectKeywords(i.utterances, ABUSE_KEYWORDS)) {
    types.push("ABUSIVE_LANGUAGE");
    reasons.push("暴言キーワード検出");
  }
  if (i.physicalContact) {
    types.push("PHYSICAL_VIOLENCE");
    reasons.push("身体的接触あり");
  }
  if (i.weaponPresented || detectKeywords(i.utterances, THREAT_KEYWORDS)) {
    types.push("THREAT_INTIMIDATION");
    reasons.push("脅迫/威嚇言動");
  }
  if (detectKeywords(i.utterances, SEXUAL_KEYWORDS) || detectKeywords(i.utterances, DISCRIM_KEYWORDS)) {
    types.push("SEXUAL_DISCRIMINATORY");
    reasons.push("性的/差別言動");
  }
  if (i.snsThreat) {
    types.push("PRIVACY_INVASION");
    reasons.push("SNS拡散威嚇");
  }
  if (i.monetaryDemand) {
    types.push("UNREASONABLE_DEMAND");
    reasons.push("金銭/不当要求");
  }
  if (i.refusedToLeave) {
    types.push("REPEAT");
    reasons.push("退去拒否/居座り");
  }

  const threeFactor = validateThreeFactors(i);
  const needsImmediatePolice =
    !!i.physicalContact || !!i.weaponPresented || !!i.refusedToLeave || (i.snsThreat && detectKeywords(i.utterances, THREAT_KEYWORDS)) || !!i.monetaryDemand;

  let severity: Severity = "low";
  let escalation: EscalationLevel = "L1_PRIMARY";

  if (needsImmediatePolice) {
    severity = "critical";
    escalation = "L4_POLICE";
  } else if (types.length >= 3 || (i.durationMinutes ?? 0) > 60) {
    severity = "high";
    escalation = "L3_DEDICATED";
  } else if (threeFactor.isKasuhara) {
    severity = "mid";
    escalation = "L2_SUPERVISOR";
  }

  return { types, threeFactor, severity, escalation, needsImmediatePolice, reasons };
}

export interface EscalationPlan {
  level: EscalationLevel;
  responder: string;
  actions: string[];
  legalBasis: string[];
  policeCall: boolean;
}

const PLANS: Record<EscalationLevel, Omit<EscalationPlan, "policeCall">> = {
  L1_PRIMARY: {
    level: "L1_PRIMARY",
    responder: "現場担当",
    actions: ["傾聴", "事実確認", "5分以内のメモ"],
    legalBasis: ["通常CS範囲"],
  },
  L2_SUPERVISOR: {
    level: "L2_SUPERVISOR",
    responder: "店長/課長",
    actions: ["担当交代", "録音開始通知", "記録作成"],
    legalBasis: ["東京都カスハラ条例 第8-9条 (事業者措置義務)", "改正労働施策総合推進法 第32条の2"],
  },
  L3_DEDICATED: {
    level: "L3_DEDICATED",
    responder: "カスハラ相談窓口/法務",
    actions: ["対応打ち切り通告書交付", "出禁措置検討", "弁護士相談"],
    legalBasis: ["改正労施法 第32条の2", "民法709条 (不法行為)"],
  },
  L4_POLICE: {
    level: "L4_POLICE",
    responder: "法務+警備",
    actions: ["110番通報", "現認証拠保全", "店内退避誘導"],
    legalBasis: ["刑法208条 (暴行)", "刑法222条 (脅迫)", "刑法130条 (不退去)", "刑法249条 (恐喝)", "刑法261条 (器物損壊)"],
  },
  L5_CARE: {
    level: "L5_CARE",
    responder: "産業医/EAP",
    actions: ["心身ケア面談", "休職判定", "労災申請支援"],
    legalBasis: ["労働契約法 第5条 (安全配慮義務)", "労働者災害補償保険法"],
  },
};

export function buildEscalationPlan(c: KasuharaClassification): EscalationPlan {
  const base = PLANS[c.escalation];
  return { ...base, policeCall: c.needsImmediatePolice };
}

/** 録音録画の同意通知文 (個情法21条4項3号適用) */
export function generateRecordingConsentNotice(): string {
  return [
    "【録音・録画に関するお知らせ】",
    "従業員及び他のお客様の安全確保並びにサービス品質向上のため、",
    "店舗内・お問合せ窓口における会話を録音・録画する場合がございます。",
    "個人情報保護法第21条第4項第3号に基づき本人への利用目的通知を要しない場合に該当します。",
    "取得した記録は (a) 証拠保全 (b) 教育研修 (c) 警察等関係機関への提供 のみに利用し、",
    "目的外利用は致しません。",
  ].join("\n");
}

export interface EmployerAction {
  has_kasuhara_manual: boolean;
  has_consult_desk: boolean;
  conducts_training: boolean;
  has_post_incident_care: boolean;
  has_response_flow_doc: boolean;
}

export interface ComplianceReport {
  ok: boolean;
  missing: string[];
  rule: string;
  hint: string;
}

/** 事業者の安全配慮義務 + 改正労施法措置義務チェック */
export function checkSafetyDutyCompliance(actions: EmployerAction): ComplianceReport {
  const missing: string[] = [];
  if (!actions.has_kasuhara_manual) missing.push("カスハラ対応マニュアル");
  if (!actions.has_consult_desk) missing.push("相談窓口");
  if (!actions.conducts_training) missing.push("教育研修");
  if (!actions.has_post_incident_care) missing.push("被害者ケア体制");
  if (!actions.has_response_flow_doc) missing.push("対応フロー文書");

  return {
    ok: missing.length === 0,
    missing,
    rule: "改正労働施策総合推進法 第32条の2 (R8.10.1施行) + 労契法第5条 (安全配慮義務)",
    hint: missing.length === 0 ? "措置義務充足。" : `R8.10.1までに整備必須: ${missing.join(", ")}`,
  };
}

/** 該当条例の取得 (47都道府県別) */
export function getApplicableOrdinance(prefecture: string): { name: string; effective: string; punitive: boolean } | null {
  const map: Record<string, { name: string; effective: string; punitive: boolean }> = {
    東京都: { name: "東京都カスタマー・ハラスメント防止条例", effective: "2025-04-01", punitive: false },
    北海道: { name: "北海道カスタマーハラスメント防止条例", effective: "2025-04-01", punitive: false },
    群馬県: { name: "群馬県カスタマーハラスメント防止条例", effective: "2025-04-01", punitive: false },
    三重県: { name: "三重県カスタマーハラスメント防止条例 (制定中)", effective: "2026-04-01", punitive: true },
  };
  return map[prefecture] ?? null;
}

export function selfCheck(): { ok: boolean; checks: Array<{ name: string; pass: boolean }> } {
  const tokyoIncident: KasuharaIncident = {
    occurredAt: new Date("2026-05-01"),
    customerType: "consumer",
    utterances: ["殺すぞ", "土下座しろ"],
    durationMinutes: 45,
    recordedMedia: "audio",
    staffId: "S001",
    industry: "retail_wholesale",
    refusedToLeave: true,
  };
  const cls = classifyKasuhara(tokyoIncident);
  const checks = [
    { name: "8類型定数", pass: Object.keys(KASUHARA_TYPES).length === 8 },
    { name: "5段階エスカレーション", pass: Object.keys(ESCALATION_LEVELS).length === 5 },
    { name: "東京都施行日", pass: KASUHARA_TOKYO_EFFECTIVE === "2025-04-01" },
    { name: "国施行日 (改正労施法)", pass: KASUHARA_NATIONAL_EFFECTIVE === "2026-10-01" },
    { name: "暴言+居座り → critical L4", pass: cls.severity === "critical" && cls.escalation === "L4_POLICE" },
    { name: "3要素全充足", pass: cls.threeFactor.isKasuhara === true },
    { name: "対応プラン警察通報", pass: buildEscalationPlan(cls).policeCall === true },
    { name: "録音同意通知生成", pass: generateRecordingConsentNotice().includes("第21条第4項第3号") },
  ];
  return { ok: checks.every((c) => c.pass), checks };
}
