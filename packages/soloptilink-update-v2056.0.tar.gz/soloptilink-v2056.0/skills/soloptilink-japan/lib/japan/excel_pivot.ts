/**
 * @fileoverview Phase 10 - Excel 職人 → Web アシスタント
 *
 * 「経理部の山田さんが 20 年磨いた Excel ピボット」を
 * Next.js のダッシュボード/集計画面に変換するための知識層。
 *
 * Claude Code は「Excel から Web に移行しましょう」と一般論を返すのみ。
 * 本モジュールは:
 *   1. VLOOKUP / INDEX-MATCH / SUMIFS / COUNTIFS の式 → SQL/Prisma クエリ変換
 *   2. ピボットテーブル設定 → 集計関数 (groupBy + agg) 変換
 *   3. 名前付き範囲 / 構造化参照の解決
 *   4. マクロ (VBA) の典型パターン → API エンドポイント雛形
 *   5. 表記ゆれ吸収 (御中/様/㈱/(株)/全角半角)
 *   6. 移行リスク評価 (循環参照/外部リンク/隠しシート/列依存)
 *
 * 全て Pure TypeScript。Excel ファイルパースは別レイヤ (xlsx パッケージ等) を使う前提。
 */

// ============================================================================
// Types
// ============================================================================

/** Excel セル位置 */
export interface CellRef {
  sheet: string;
  row: number; // 1-indexed
  col: number; // 1-indexed (A=1)
}

/** Excel 範囲 */
export interface RangeRef {
  sheet: string;
  startRow: number;
  startCol: number;
  endRow: number;
  endCol: number;
}

/** 関数呼び出しの解析結果 */
export interface FormulaParse {
  functionName: string;
  args: string[];
  /** 解析できたか */
  parsed: boolean;
  warnings: string[];
}

/** ピボット設定 */
export interface PivotConfig {
  sourceTable: string; // テーブル名 (or DB テーブル名)
  rowFields: string[];
  colFields: string[];
  valueFields: { field: string; agg: 'sum' | 'count' | 'avg' | 'min' | 'max' | 'distinct_count' }[];
  filters?: { field: string; op: string; value: unknown }[];
}

/** SQL 変換結果 */
export interface SqlTranslation {
  sql: string;
  prismaSnippet?: string;
  warnings: string[];
}

/** Excel 移行リスク */
export interface MigrationRisk {
  level: 'low' | 'medium' | 'high' | 'critical';
  category: 'circular' | 'external_link' | 'hidden_sheet' | 'volatile' | 'macro' | 'manual_input' | 'name_collision';
  cellOrSheet?: string;
  message: string;
  /** 移行コスト見積り (人日) */
  manDays?: number;
}

// ============================================================================
// Excel 列名 ↔ 数値
// ============================================================================

/** "A" -> 1, "Z" -> 26, "AA" -> 27 */
export function colToNumber(col: string): number {
  let n = 0;
  for (const ch of col.toUpperCase()) {
    n = n * 26 + (ch.charCodeAt(0) - 64);
  }
  return n;
}

/** 1 -> "A", 27 -> "AA" */
export function numberToCol(n: number): string {
  let s = '';
  while (n > 0) {
    n--;
    s = String.fromCharCode(65 + (n % 26)) + s;
    n = Math.floor(n / 26);
  }
  return s;
}

/** "Sheet1!A1:B10" → RangeRef */
export function parseRange(s: string): RangeRef | null {
  const m = /^(?:'([^']+)'|([A-Za-z0-9_]+))!\$?([A-Z]+)\$?(\d+):\$?([A-Z]+)\$?(\d+)$/.exec(s);
  if (!m) {
    // シート名なしバージョン
    const m2 = /^\$?([A-Z]+)\$?(\d+):\$?([A-Z]+)\$?(\d+)$/.exec(s);
    if (!m2) return null;
    return {
      sheet: '',
      startCol: colToNumber(m2[1]),
      startRow: parseInt(m2[2], 10),
      endCol: colToNumber(m2[3]),
      endRow: parseInt(m2[4], 10),
    };
  }
  return {
    sheet: m[1] || m[2],
    startCol: colToNumber(m[3]),
    startRow: parseInt(m[4], 10),
    endCol: colToNumber(m[5]),
    endRow: parseInt(m[6], 10),
  };
}

// ============================================================================
// 関数解析
// ============================================================================

/**
 * VLOOKUP/INDEX/MATCH/SUMIFS/COUNTIFS 等の式を解析。
 * ネスト関数も簡易的にハンドリング。
 */
export function parseFormula(formula: string): FormulaParse {
  const warnings: string[] = [];
  const trimmed = formula.replace(/^=/, '').trim();

  // 関数名
  const funcMatch = /^([A-Z_]+)\s*\((.*)\)$/.exec(trimmed);
  if (!funcMatch) {
    return { functionName: '', args: [], parsed: false, warnings: ['式の関数解析に失敗'] };
  }

  const functionName = funcMatch[1];
  const argStr = funcMatch[2];
  const args = splitArgs(argStr);

  return { functionName, args, parsed: true, warnings };
}

/** 引数分割 (括弧と引用符をネスト対応) */
function splitArgs(s: string): string[] {
  const args: string[] = [];
  let depth = 0;
  let inQuote = false;
  let buf = '';
  for (const ch of s) {
    if (ch === '"') inQuote = !inQuote;
    if (!inQuote) {
      if (ch === '(') depth++;
      else if (ch === ')') depth--;
      else if (ch === ',' && depth === 0) {
        args.push(buf.trim());
        buf = '';
        continue;
      }
    }
    buf += ch;
  }
  if (buf.trim()) args.push(buf.trim());
  return args;
}

// ============================================================================
// VLOOKUP → SQL 変換
// ============================================================================

/**
 * VLOOKUP(検索値, 範囲, 列番号, 検索の型) → JOIN/SELECT
 * 例: VLOOKUP(A2, '商品マスタ'!A:D, 3, FALSE)
 *  → SELECT t.col3 FROM 商品マスタ t WHERE t.col1 = <A2> LIMIT 1
 */
export function vlookupToSql(args: string[], options: {
  sourceTable: string; // 検索値が含まれるテーブル
  searchKeyColumn: string; // <A2> に対応する列
}): SqlTranslation {
  const warnings: string[] = [];
  if (args.length < 3) return { sql: '', warnings: ['VLOOKUP は引数 3〜4 個必要'] };

  const range = parseRange(args[1]);
  const colIndex = parseInt(args[2], 10);
  const exactMatch = args[3]?.toUpperCase() !== 'TRUE';

  if (!range) {
    warnings.push('範囲が解析できなかった');
    return { sql: '', warnings };
  }
  if (!exactMatch) warnings.push('近似一致 (TRUE) は SQL では DESC + LIMIT 1 で代替');

  const lookupTable = range.sheet || 'master';
  const lookupKeyCol = numberToCol(range.startCol).toLowerCase();
  const lookupReturnCol = numberToCol(range.startCol + colIndex - 1).toLowerCase();

  const sql = `SELECT lkp.${lookupReturnCol}\n  FROM ${lookupTable} lkp\n  WHERE lkp.${lookupKeyCol} = src.${options.searchKeyColumn}\n  LIMIT 1`;

  const prismaSnippet = `// Prisma 例: マスタを include して取得\nconst rows = await prisma.${options.sourceTable}.findMany({\n  include: { ${lookupTable}: true },\n});\n// rows[i].${lookupTable}.${lookupReturnCol} が VLOOKUP の戻り値`;

  return { sql, prismaSnippet, warnings };
}

// ============================================================================
// SUMIFS / COUNTIFS → SQL 変換
// ============================================================================

/**
 * SUMIFS(合計範囲, 条件範囲1, 条件1, 条件範囲2, 条件2, ...) → SQL SUM + WHERE
 */
export function sumIfsToSql(args: string[], tableName: string): SqlTranslation {
  const warnings: string[] = [];
  if (args.length < 3 || (args.length - 1) % 2 !== 0) {
    return { sql: '', warnings: ['SUMIFS の引数数が不正'] };
  }

  const sumRange = parseRange(args[0]);
  if (!sumRange) return { sql: '', warnings: ['合計範囲が解析できなかった'] };
  const sumCol = numberToCol(sumRange.startCol).toLowerCase();

  const wheres: string[] = [];
  for (let i = 1; i < args.length; i += 2) {
    const condRange = parseRange(args[i]);
    const condValue = args[i + 1].replace(/^"|"$/g, '');
    if (!condRange) {
      warnings.push(`条件範囲 ${i} 解析失敗`);
      continue;
    }
    const col = numberToCol(condRange.startCol).toLowerCase();
    const op = parseConditionOperator(condValue);
    wheres.push(`${col} ${op.op} '${op.val}'`);
  }

  const sql = `SELECT SUM(${sumCol}) AS sum_${sumCol}\n  FROM ${tableName}\n  WHERE ${wheres.join(' AND ')}`;
  return { sql, warnings };
}

function parseConditionOperator(s: string): { op: string; val: string } {
  if (s.startsWith('>=')) return { op: '>=', val: s.slice(2) };
  if (s.startsWith('<=')) return { op: '<=', val: s.slice(2) };
  if (s.startsWith('<>')) return { op: '!=', val: s.slice(2) };
  if (s.startsWith('>')) return { op: '>', val: s.slice(1) };
  if (s.startsWith('<')) return { op: '<', val: s.slice(1) };
  return { op: '=', val: s };
}

// ============================================================================
// ピボット → SQL
// ============================================================================

/**
 * Excel ピボットテーブル設定を SQL に変換 (GROUP BY + 集計)。
 */
export function pivotToSql(config: PivotConfig): SqlTranslation {
  const warnings: string[] = [];
  const groupCols = [...config.rowFields, ...config.colFields];

  const valueCols = config.valueFields.map((vf) => {
    const aggSql = vf.agg === 'distinct_count' ? `COUNT(DISTINCT ${vf.field})` : `${vf.agg.toUpperCase()}(${vf.field})`;
    return `${aggSql} AS ${vf.agg}_${vf.field}`;
  });

  const wheres = (config.filters ?? []).map((f) => {
    if (Array.isArray(f.value)) {
      return `${f.field} IN (${f.value.map((v) => `'${v}'`).join(', ')})`;
    }
    return `${f.field} ${f.op} '${String(f.value)}'`;
  });

  let sql = `SELECT ${groupCols.join(', ')}, ${valueCols.join(', ')}\n  FROM ${config.sourceTable}`;
  if (wheres.length > 0) sql += `\n  WHERE ${wheres.join(' AND ')}`;
  if (groupCols.length > 0) sql += `\n  GROUP BY ${groupCols.join(', ')}\n  ORDER BY ${groupCols.join(', ')}`;

  if (config.colFields.length > 0) {
    warnings.push('列ピボット (colFields) は表示時に CROSSTAB で展開する必要あり (PostgreSQL: tablefunc / アプリ側変換推奨)');
  }

  return { sql, warnings };
}

// ============================================================================
// 表記ゆれ吸収
// ============================================================================

/** 株式会社/(株)/㈱ など */
const COMPANY_SUFFIX_VARIANTS = [
  '株式会社', '\\(株\\)', '\u3231', '㈱', '有限会社', '\\(有\\)', '\u3230', '㈲', '合同会社', '\\(合\\)', '合資会社', '合名会社',
];

export function normalizeCompanyName(name: string): string {
  let s = name;
  for (const v of COMPANY_SUFFIX_VARIANTS) {
    s = s.replace(new RegExp(v, 'g'), '');
  }
  return s.trim();
}

/** 御中・様・殿 などの敬称除去 */
export function stripHonorific(name: string): string {
  return name.replace(/(御中|様|殿|氏|君|さん|くん)$/u, '').trim();
}

// ============================================================================
// 移行リスク評価
// ============================================================================

export interface WorkbookSummary {
  sheets: { name: string; hidden: boolean; cellCount: number }[];
  externalLinks: number;
  circularRefs: { cell: string }[];
  volatileFunctionCount: number; // NOW(), TODAY(), RAND(), INDIRECT(), OFFSET()
  macros: number;
  manualInputCells: number;
  namedRanges: number;
}

export function evaluateMigrationRisks(summary: WorkbookSummary): MigrationRisk[] {
  const risks: MigrationRisk[] = [];

  if (summary.circularRefs.length > 0) {
    risks.push({
      level: 'critical',
      category: 'circular',
      message: `循環参照 ${summary.circularRefs.length} 件: ロジック書き換え必須`,
      manDays: summary.circularRefs.length * 0.5,
    });
  }
  if (summary.externalLinks > 0) {
    risks.push({
      level: 'high',
      category: 'external_link',
      message: `外部リンク ${summary.externalLinks} 件: API 連携 or データ移管が必要`,
      manDays: summary.externalLinks * 1,
    });
  }
  const hidden = summary.sheets.filter((s) => s.hidden);
  if (hidden.length > 0) {
    risks.push({
      level: 'medium',
      category: 'hidden_sheet',
      message: `非表示シート ${hidden.length} 件: 隠しロジック調査必要 (${hidden.map((s) => s.name).join(', ')})`,
      manDays: hidden.length * 0.5,
    });
  }
  if (summary.volatileFunctionCount > 0) {
    risks.push({
      level: 'medium',
      category: 'volatile',
      message: `揮発性関数 ${summary.volatileFunctionCount} 件: パフォーマンス劣化, 再計算依存に注意`,
      manDays: summary.volatileFunctionCount * 0.1,
    });
  }
  if (summary.macros > 0) {
    risks.push({
      level: 'high',
      category: 'macro',
      message: `VBA マクロ ${summary.macros} 件: API/サーバ処理に書き換え`,
      manDays: summary.macros * 1.5,
    });
  }
  if (summary.manualInputCells > 1000) {
    risks.push({
      level: 'medium',
      category: 'manual_input',
      message: `手入力セル ${summary.manualInputCells} 件: 入力 UI 設計が大規模`,
      manDays: Math.ceil(summary.manualInputCells / 200),
    });
  }
  return risks;
}

// ============================================================================
// 集計テンプレ (経理部典型例)
// ============================================================================

/**
 * 月次売上集計 (得意先 × 月) ピボットの SQL テンプレ
 */
export function buildMonthlySalesPivot(tableName: string, dateColumn: string, customerColumn: string, amountColumn: string): SqlTranslation {
  return pivotToSql({
    sourceTable: tableName,
    rowFields: [customerColumn],
    colFields: [`STRFTIME('%Y-%m', ${dateColumn})`],
    valueFields: [{ field: amountColumn, agg: 'sum' }],
  });
}

/**
 * 商品別月次原価率
 */
export function buildCostRatioPivot(tableName: string, productColumn: string, amountColumn: string, costColumn: string): SqlTranslation {
  const sql = `SELECT ${productColumn},\n  SUM(${amountColumn}) AS sales,\n  SUM(${costColumn}) AS cost,\n  ROUND(SUM(${costColumn}) * 1.0 / NULLIF(SUM(${amountColumn}), 0), 4) AS cost_ratio\n  FROM ${tableName}\n  GROUP BY ${productColumn}\n  ORDER BY cost_ratio DESC`;
  return { sql, warnings: [] };
}

// ============================================================================
// Default exports
// ============================================================================

export const EXCEL_VOLATILE_FUNCTIONS = ['NOW', 'TODAY', 'RAND', 'RANDBETWEEN', 'INDIRECT', 'OFFSET', 'CELL', 'INFO'];
