/**
 * lib/japan/bath_spa.ts — 公衆浴場/温泉DNA
 *
 * 法令カバレッジ:
 *  - 公衆浴場法 (S23法律139)
 *  - 公衆浴場の確保のための特別措置に関する法律 (公衆浴場確保法 S56)
 *  - 温泉法 (S23法律125)
 *  - 温泉法施行規則 (温泉成分分析+掲示+登録分析機関)
 *  - レジオネラ症対策 (公衆浴場におけるレジオネラ症発生防止対策マニュアル H15通達)
 *  - 公衆浴場における衛生等管理要領 (S60通達)
 *  - 浴場業の運営の適正化に関する法律 (環境衛生関係営業)
 *
 * 参考: 厚生労働省生活衛生課, 全国公衆浴場業生活衛生同業組合連合会, 環境省自然環境局
 */

// ============================================================================
// 1. 公衆浴場 2区分 (公衆浴場法2条)
// ============================================================================

export type BathHouseKind =
  | 'general' // 一般公衆浴場 — 銭湯 (物価統制令の入浴料金制限あり)
  | 'other'; // その他の公衆浴場 — スーパー銭湯/サウナ/健康ランド/温浴施設

export const BATH_HOUSE_TYPES = {
  general: { ja: '一般公衆浴場 (銭湯)', priceControlled: true, opening: '営業許可' },
  other: { ja: 'その他公衆浴場 (スーパー銭湯/サウナ等)', priceControlled: false, opening: '営業許可' },
} as const;

/** 物価統制令: 銭湯 (一般公衆浴場) の入浴料金は都道府県知事が告示 (R6 東京 大人550円) */
export const SENTOH_PRICE_LIMIT_R6: Record<string, number> = {
  '東京都': 550,
  '大阪府': 510,
  '京都府': 490,
  '神奈川県': 530,
  '愛知県': 500,
  '北海道': 460,
  // ...都道府県別告示
};

// ============================================================================
// 2. 公衆浴場 営業許可 + 構造設備
// ============================================================================

export interface BathHouseOpeningApplication {
  kind: BathHouseKind;
  hasOpeningPermit: boolean; // 都道府県知事許可
  bathTubCount: number;
  showerHeadCount: number;
  totalAreaM2: number;
  hasFullBathExchangeSystem: boolean; // 完全換水
  isCirculationFiltrationSystem: boolean; // 循環ろ過 (毎日完全換水できない場合)
  hasChlorinationSystem: boolean; // 塩素消毒設備
  freeChlorineRangePpm?: { min: number; max: number };
  hasLegionellaTesting: boolean; // レジオネラ属菌検査
  testingFrequencyPerYear: number;
  separateMaleFemaleBath: boolean;
  hasPrivateBathFacility: boolean;
}

/** 公衆浴場法3条 営業許可の事前審査 + レジオネラ対策 */
export function evaluateBathHouseOpening(a: BathHouseOpeningApplication): {
  approvable: boolean;
  blockers: string[];
} {
  const blockers: string[] = [];
  if (!a.hasOpeningPermit) blockers.push('都道府県知事の営業許可必須 (公衆浴場法2条)');
  if (a.bathTubCount < 1) blockers.push('浴槽 1基以上必要');
  if (!a.separateMaleFemaleBath) blockers.push('男女別浴室 (混浴は7歳以上不可・条例)');
  if (!a.hasChlorinationSystem) {
    blockers.push('遊離残留塩素 0.4mg/L以上 (温泉等は条例で例外あり) — 塩素消毒設備必須');
  }
  if (!a.hasLegionellaTesting) {
    blockers.push('レジオネラ属菌検査必須 (年1回以上 — H15通達)');
  } else if (a.testingFrequencyPerYear < 1) {
    blockers.push('レジオネラ検査 年1回以上必要');
  }
  // 循環式の場合は塩素濃度範囲チェック
  if (a.isCirculationFiltrationSystem && a.freeChlorineRangePpm) {
    if (a.freeChlorineRangePpm.min < 0.4) {
      blockers.push('循環式 遊離塩素 0.4mg/L未満 — レジオネラリスク');
    }
  }
  return { approvable: blockers.length === 0, blockers };
}

// ============================================================================
// 3. レジオネラ症対策 (H15通達)
// ============================================================================

/** レジオネラ属菌検査 — 培養法 100mL中10CFU以下 */
export function evaluateLegionellaTestResult(input: {
  measuredCfuPer100mL: number;
  facilityKind: 'circulation' | 'flow_through' | 'spa';
}): { passed: boolean; alert: string | null; mustClose: boolean } {
  // 検出限界 10 CFU/100mL 以下が原則
  if (input.measuredCfuPer100mL >= 100) {
    return {
      passed: false,
      alert: `レジオネラ属菌 ${input.measuredCfuPer100mL} CFU/100mL — 緊急休業+保健所報告`,
      mustClose: true,
    };
  }
  if (input.measuredCfuPer100mL >= 10) {
    return {
      passed: false,
      alert: `レジオネラ属菌 ${input.measuredCfuPer100mL} CFU/100mL — 検出限界超過、塩素濃度見直し+再検査`,
      mustClose: false,
    };
  }
  return { passed: true, alert: null, mustClose: false };
}

// ============================================================================
// 4. 温泉法 (S23法律125)
// ============================================================================

/** 温泉法2条 「温泉」定義: 25℃以上 or 18物質のいずれか1つ以上含有 */
export const ONSEN_DEFINITION_THRESHOLDS = {
  temperatureC: 25, // 25℃以上
  qualifyingComponents: [
    { name: '溶存物質', minMgPerKg: 1000 },
    { name: '遊離二酸化炭素', minMgPerKg: 250 },
    { name: 'リチウムイオン', minMgPerKg: 1 },
    { name: 'ストロンチウムイオン', minMgPerKg: 10 },
    { name: 'バリウムイオン', minMgPerKg: 5 },
    { name: 'フェロ又はフェリイオン', minMgPerKg: 10 },
    { name: '第一マンガンイオン', minMgPerKg: 10 },
    { name: '水素イオン', minMgPerKg: 1 },
    { name: '臭素イオン', minMgPerKg: 5 },
    { name: 'ヨウ素イオン', minMgPerKg: 1 },
    { name: 'フッ素イオン', minMgPerKg: 2 },
    { name: 'ヒドロひ酸イオン', minMgPerKg: 1.3 },
    { name: 'メタ亜ひ酸', minMgPerKg: 1 },
    { name: '総硫黄', minMgPerKg: 1 },
    { name: 'メタほう酸', minMgPerKg: 5 },
    { name: 'メタけい酸', minMgPerKg: 50 },
    { name: '重炭酸そうだ', minMgPerKg: 340 },
    { name: 'ラドン', minBecquerelPerKg: 74, isRadon: true }, // 30×10⁻¹⁰キュリー
    { name: 'ラジウム塩', minMgPerKg: 0.000001 },
  ],
} as const;

/** 温泉法上の温泉に該当するか判定 */
export function qualifiesAsOnsen(input: {
  temperatureC: number;
  componentsMgPerKg: Record<string, number>;
  radonBqPerKg?: number;
}): { isOnsen: boolean; reason: string } {
  if (input.temperatureC >= ONSEN_DEFINITION_THRESHOLDS.temperatureC) {
    return { isOnsen: true, reason: `源泉温度 ${input.temperatureC}℃ ≥ 25℃ — 温泉に該当` };
  }
  for (const c of ONSEN_DEFINITION_THRESHOLDS.qualifyingComponents) {
    // ラドンだけ単位が Bq/kg なので、その要素かどうかを項目の有無で判別する
    // (isRadon を直接読むと、持っていない要素まで読もうとして型が合わなくなる)
    if ('isRadon' in c) {
      if ((input.radonBqPerKg ?? 0) >= c.minBecquerelPerKg) {
        return { isOnsen: true, reason: `ラドン ${input.radonBqPerKg} Bq/kg ≥ ${c.minBecquerelPerKg} — 温泉に該当` };
      }
      continue;
    }
    if ((input.componentsMgPerKg[c.name] ?? 0) >= c.minMgPerKg) {
      return { isOnsen: true, reason: `${c.name} ${input.componentsMgPerKg[c.name]} mg/kg — 温泉に該当` };
    }
  }
  return { isOnsen: false, reason: '温度+成分いずれも基準未達 — 温泉法上の温泉に該当しない' };
}

// ============================================================================
// 5. 温泉成分分析書 + 掲示義務 (温泉法 18条)
// ============================================================================

/** 登録分析機関による分析必須 (温泉法 19条) — 10年ごと再分析推奨 */
export interface OnsenAnalysisCertificate {
  registeredLabName: string; // 登録分析機関
  issueDate: Date;
  springName: string;
  springTemperatureC: number;
  pH: number;
  qualityClassification: string; // 泉質名 (e.g. ナトリウム-塩化物泉)
  contraindications: string[]; // 禁忌症
  benefits: string[]; // 適応症
}

/** 温泉法18条 — 浴用に供する場合は成分分析書 + 適応症/禁忌症/源泉温度を掲示 */
export function checkOnsenPostingCompliance(input: {
  hasAnalysisCertificate: boolean;
  certificateAgeYears: number;
  hasContraindicationPosted: boolean;
  hasBenefitPosted: boolean;
  hasSourceTemperaturePosted: boolean;
  hasAdditiveDisclosed: boolean; // 加水/加温/循環/塩素消毒の有無を掲示 (H17改正)
}): { compliant: boolean; alerts: string[] } {
  const alerts: string[] = [];
  if (!input.hasAnalysisCertificate) alerts.push('登録分析機関による成分分析書が必要');
  if (input.certificateAgeYears > 10) alerts.push('分析書 10年経過 — 再分析推奨 (法的義務はなし)');
  if (!input.hasContraindicationPosted) alerts.push('禁忌症の掲示必須');
  if (!input.hasBenefitPosted) alerts.push('適応症の掲示必須');
  if (!input.hasSourceTemperaturePosted) alerts.push('源泉温度の掲示必須');
  if (!input.hasAdditiveDisclosed) {
    alerts.push('H17改正: 加水/加温/循環/塩素消毒/入浴剤添加の有無を掲示必須');
  }
  return { compliant: alerts.length === 0, alerts };
}

// ============================================================================
// 6. 温泉採取許可 (温泉法 14条の2 — 可燃性天然ガス)
// ============================================================================

/** 温泉掘削/採取に関する許可制度 */
export function requiresOnsenExcavationPermit(input: {
  isExcavating: boolean; // 新規掘削
  isAlreadyExtracting: boolean; // 既存採取
  containsCombustibleGas: boolean;
}): { required: boolean; reason: string } {
  if (input.isExcavating) {
    return { required: true, reason: '温泉法3条 — 掘削許可 (都道府県知事) 必須' };
  }
  if (input.containsCombustibleGas) {
    return {
      required: true,
      reason: '温泉法14条の2 — 可燃性天然ガス含有時の温泉採取許可 (H19新設)',
    };
  }
  if (input.isAlreadyExtracting) {
    return { required: false, reason: '既存採取 — 既得権 (但し動力装置設置時は別途許可)' };
  }
  return { required: false, reason: '対象外' };
}

// ============================================================================
// 7. 公衆浴場確保法 (S56) — 銭湯転廃業時の措置
// ============================================================================

/** 銭湯 (一般公衆浴場) の転廃業時の地域住民への影響評価 */
export function evaluateSentohClosure(input: {
  populationWithin500m: number;
  alternativeBathDistanceM: number;
  isElderlyHeavy: boolean; // 高齢者世帯多い地域
}): { requiresConsultation: boolean; reason: string } {
  // 公衆浴場確保法: 地域住民の入浴の機会確保
  if (
    input.populationWithin500m >= 1000 &&
    input.alternativeBathDistanceM >= 1000 &&
    input.isElderlyHeavy
  ) {
    return {
      requiresConsultation: true,
      reason: '近隣 1000人以上 + 代替浴場 1km以上 + 高齢者多 — 自治体協議+説明会推奨',
    };
  }
  return { requiresConsultation: false, reason: '影響限定的' };
}
