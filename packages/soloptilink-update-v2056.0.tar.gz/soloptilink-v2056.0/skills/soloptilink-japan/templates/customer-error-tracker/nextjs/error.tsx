'use client';

/**
 * Next.js App Router 用エラーページ
 * --------------------------------------------------------------------------
 * SoloptiLinkAI が生成したシステムで runtime エラーが発生した際に
 * このコンポーネントがレンダリングされる。
 *
 * 【2026-08-01 G-22 是正】外部送信の呼び出しを削除しました。
 *   - 旧実装は error_tracker から `reportClientError` を import していましたが、
 *     SDK にその export は存在せず (実在するのは reportError / reportServerError)、
 *     常に TypeError となって try/catch に握り潰されていました。
 *     = 一度も送信できていない「存在しない関数への配線」でした。
 *   - 既定OFF方針に合わせ、実在する関数へ繋ぎ直すのではなく呼び出し自体を
 *     削除しました。
 *   - あわせて、送っていないのに「自動的に報告されました」と表示していた
 *     案内文も事実に合わせて修正しました。
 *
 * このファイルは TWL (Telemetry Wiring Layer) により自動配置された。
 * 既存の app/error.tsx がある場合は上書きされない。
 */
export default function Error({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  return (
    <div
      role="alert"
      style={{
        padding: '2rem',
        maxWidth: '40rem',
        margin: '4rem auto',
        fontFamily: 'system-ui, -apple-system, sans-serif',
      }}
    >
      <h2 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>
        申し訳ございません。エラーが発生しました
      </h2>
      <p style={{ color: '#6b7280', marginBottom: '1.5rem' }}>
        下のボタンから再試行してください。
        {error?.digest ? (
          <>
            <br />
            サポートへお問い合わせの際は、次の識別子をお伝えください: {error.digest}
          </>
        ) : null}
      </p>
      <button
        onClick={() => reset()}
        style={{
          padding: '0.5rem 1rem',
          background: '#e11d48',
          color: 'white',
          border: 'none',
          borderRadius: '0.375rem',
          cursor: 'pointer',
        }}
      >
        再試行する
      </button>
    </div>
  );
}
