'use client';

/**
 * Next.js App Router 用グローバルエラーページ
 * --------------------------------------------------------------------------
 * layout.tsx 自体で発生したエラーをキャッチする最後の砦。
 *
 * 【2026-08-01 G-22 是正】外部送信の呼び出しを削除しました。
 *   - 旧実装は error_tracker から `reportClientError` を import していましたが、
 *     SDK にその export は存在せず (実在するのは reportError / reportServerError)、
 *     常に TypeError となって try/catch に握り潰されていました。
 *     = 一度も送信できていない「存在しない関数への配線」でした。
 *   - 既定OFF方針に合わせ、実在する関数へ繋ぎ直すのではなく呼び出し自体を
 *     削除しました。繋ぎ直すと「これまで送っていなかった経路を新たに有効化する」
 *     ことになり、方針と逆になるためです。
 *   - 送信が必要なお客様は SDK の initSoloptiLinkErrorTracker() を明示的に
 *     初期化してご利用ください (既定では初期化されません)。
 *
 * このファイルは TWL (Telemetry Wiring Layer) により自動配置された。
 */
export default function GlobalError({
  error,
}: {
  error: Error & { digest?: string };
}) {
  return (
    <html lang="ja">
      <body
        style={{
          padding: '2rem',
          maxWidth: '40rem',
          margin: '4rem auto',
          fontFamily: 'system-ui, -apple-system, sans-serif',
        }}
      >
        <h1 style={{ fontSize: '1.5rem', marginBottom: '1rem' }}>
          重大なエラーが発生しました
        </h1>
        <p style={{ color: '#6b7280' }}>
          時間をおいてもう一度お試しください。
          {error?.digest ? (
            <>
              <br />
              サポートへお問い合わせの際は、次の識別子をお伝えください: {error.digest}
            </>
          ) : null}
        </p>
      </body>
    </html>
  );
}
