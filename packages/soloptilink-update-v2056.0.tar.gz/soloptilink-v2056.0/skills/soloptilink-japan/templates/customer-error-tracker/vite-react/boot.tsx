/**
 * Vite + React 用エラートラッカーブートストラップ
 * --------------------------------------------------------------------------
 * src/main.tsx の冒頭で読み込む:
 *   import './soloptilink-boot';
 *   import { createRoot } from 'react-dom/client';
 *   ...
 *
 * 【2026-08-01 G-22 既定OFF化】
 *   送信先のハードコード既定値を削除しました。トークンと送信先の **両方** が
 *   環境変数で明示設定されたときだけ初期化します。どちらかが未設定・空文字なら
 *   トラッカーは初期化されず、外部送信は一切行いません。
 *
 * このファイルは TWL (Telemetry Wiring Layer) により自動配置された。
 */
import { initSoloptiLinkErrorTracker } from '../lib/soloptilink/error_tracker';

const token = (import.meta.env.VITE_SOLOPTILINK_PROJECT_TOKEN as string | undefined)?.trim();
const endpoint = (import.meta.env.VITE_SOLOPTILINK_ENDPOINT as string | undefined)?.trim();

// トークンと送信先が両方そろっている場合のみ有効 (既定OFF / 既定URLへ戻らない)
if (token && token.startsWith('pt_') && endpoint && /^https:\/\//.test(endpoint)) {
  try {
    initSoloptiLinkErrorTracker({
      projectToken: token,
      endpoint,
      environment: import.meta.env.MODE || 'production',
      projectName: import.meta.env.VITE_APP_NAME || 'vite-app',
      projectVersion: import.meta.env.VITE_APP_VERSION || '1.0.0',
      generatedBySkill: 'soloptilink-boost',
      generatedByVersion: 'v2028.0',
    });
  } catch (e) {
    // SDK 初期化失敗はアプリ本体の起動を阻害しない
    if (import.meta.env.DEV) {
      console.warn('[SoloptiLink Tracker] init failed:', e);
    }
  }
}
