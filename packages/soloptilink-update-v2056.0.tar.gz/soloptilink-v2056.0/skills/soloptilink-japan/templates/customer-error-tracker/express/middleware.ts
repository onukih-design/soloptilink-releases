import type { Request, Response, NextFunction, ErrorRequestHandler } from 'express';

/**
 * Express 用エラーミドルウェア
 * --------------------------------------------------------------------------
 * Express アプリの最後尾に登録する:
 *   import { soloptilinkErrorMiddleware } from './middleware/soloptilink-error';
 *   app.use(soloptilinkErrorMiddleware);
 *
 * このファイルは TWL (Telemetry Wiring Layer) v2028.0 により自動配置された。
 * SDK 本体は ../../lib/soloptilink/error_tracker.ts (TS) または
 * インストール時に同梱されている JS ビルドを参照する。
 */
export const soloptilinkErrorMiddleware: ErrorRequestHandler = async (
  err: any,
  req: Request,
  res: Response,
  next: NextFunction,
) => {
  // ヘッダー送信済みなら何もできない
  if (res.headersSent) {
    return next(err);
  }

  // SDK を遅延読み込み (SDK 自体のエラーで二重失敗しないため)
  try {
    const sdk = await import('../../lib/soloptilink/error_tracker');
    if (typeof (sdk as any).reportServerError === 'function') {
      await (sdk as any).reportServerError(err, {
        request: {
          method: req.method,
          url: req.originalUrl,
          headers: req.headers,
        },
        route_pattern: req.route?.path || req.path,
        http_status: 500,
      });
    }
  } catch {
    // 送信失敗してもユーザー応答は返す
  }

  res.status(500).json({
    error: 'サーバー内部エラー',
    message: process.env.NODE_ENV === 'development' ? err?.message : undefined,
  });
};
