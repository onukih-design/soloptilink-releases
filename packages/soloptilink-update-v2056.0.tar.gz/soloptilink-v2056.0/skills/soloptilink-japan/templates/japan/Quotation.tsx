/**
 * 請書テンプレート (発注者への受注回答)
 * 発注書を受けて、受注者が「承諾」を示す書面
 */
import React from 'react';
import { Party, docPageStyle, DocTitle, PartyBlock, IssuerBlock, MetaRow, formatJP, printStyle } from './_common';
import { BusinessPhrases } from '../../lib/japan/keigo';
import { t, type Locale } from '../../lib/japan/i18n';

export interface QuotationLine {
  description: string;
  qty: number;
  unit?: string;
  unitPrice: number;
  deliveryDate?: string;
}

export interface QuotationProps {
  issuer: Party;                 // 受注者（自社）
  client: Party;                 // 発注者
  quotationNo: string;
  issueDate: Date;
  orderNo: string;               // 対応する注文書番号
  subject: string;
  lines: QuotationLine[];
  deliveryLocation: string;
  deliveryDate: string;
  paymentTerms: string;
  sealDataUrl?: string;
  remarks?: string;
  locale?: Locale;
}

export function Quotation({ issuer, client, quotationNo, issueDate, orderNo, subject, lines, deliveryLocation, deliveryDate, paymentTerms, sealDataUrl, remarks, locale = 'ja' }: QuotationProps) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  const subtotal = lines.reduce((s, l) => s + l.qty * l.unitPrice, 0);
  const tax = Math.floor(subtotal * 0.10);
  const total = subtotal + tax;

  return (
    <div className="quotation-doc" style={docPageStyle}>
      <DocTitle>{locale === 'ja' ? '請　書' : L('quotation')}</DocTitle>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8mm' }}>
        <div style={{ flex: 1 }}>
          <PartyBlock party={client} />
        </div>
        <div style={{ flex: 1 }}><IssuerBlock party={issuer} sealDataUrl={sealDataUrl} /></div>
      </div>

      <MetaRow items={[
        { label: '請書番号', value: quotationNo },
        { label: '発行日', value: formatJP(issueDate) },
        { label: '対応注文書', value: orderNo },
      ]} />

      <div style={{ marginBottom: '6mm', fontSize: '12pt', textAlign: 'center' }}>件名: {subject}</div>

      <p style={{ marginBottom: '6mm' }}>{BusinessPhrases.opening('reply')}ご注文ありがとうございます。下記の通りご注文をお受けいたしますので、ご確認の程よろしくお願い申し上げます。</p>

      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '6mm', fontSize: '10pt' }}>
        <thead>
          <tr style={{ background: '#333', color: 'white' }}>
            <th style={{ padding: '4px 8px', textAlign: 'left' }}>品目</th>
            <th style={{ padding: '4px 8px', textAlign: 'right' }}>数量</th>
            <th style={{ padding: '4px 8px' }}>単位</th>
            <th style={{ padding: '4px 8px', textAlign: 'right' }}>単価</th>
            <th style={{ padding: '4px 8px', textAlign: 'right' }}>金額</th>
            <th style={{ padding: '4px 8px' }}>納期</th>
          </tr>
        </thead>
        <tbody>
          {lines.map((l, i) => (
            <tr key={i} style={{ borderBottom: '1px solid #ddd' }}>
              <td style={{ padding: '4px 8px' }}>{l.description}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>{l.qty}</td>
              <td style={{ padding: '4px 8px' }}>{l.unit ?? ''}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>¥{l.unitPrice.toLocaleString()}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>¥{(l.qty * l.unitPrice).toLocaleString()}</td>
              <td style={{ padding: '4px 8px' }}>{l.deliveryDate ?? deliveryDate}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div style={{ marginLeft: 'auto', width: '80mm', fontSize: '10pt', marginBottom: '6mm' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>小計</span><span>¥{subtotal.toLocaleString()}</span></div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>消費税(10%)</span><span>¥{tax.toLocaleString()}</span></div>
        <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '2px solid #333', paddingTop: '4px', fontWeight: 'bold', fontSize: '12pt' }}><span>合計</span><span>¥{total.toLocaleString()}</span></div>
      </div>

      <table style={{ width: '100%', marginBottom: '6mm', fontSize: '10pt', borderCollapse: 'collapse' }}>
        <tbody>
          <tr><th style={{ background: '#eee', padding: '4px', textAlign: 'left', border: '1px solid #ccc', width: '30mm' }}>納入場所</th><td style={{ padding: '4px', border: '1px solid #ccc' }}>{deliveryLocation}</td></tr>
          <tr><th style={{ background: '#eee', padding: '4px', textAlign: 'left', border: '1px solid #ccc' }}>納期</th><td style={{ padding: '4px', border: '1px solid #ccc' }}>{deliveryDate}</td></tr>
          <tr><th style={{ background: '#eee', padding: '4px', textAlign: 'left', border: '1px solid #ccc' }}>お支払条件</th><td style={{ padding: '4px', border: '1px solid #ccc' }}>{paymentTerms}</td></tr>
        </tbody>
      </table>

      {remarks && <div style={{ fontSize: '9pt', marginBottom: '6mm' }}>備考: {remarks}</div>}

      <p style={{ textAlign: 'right', marginTop: '8mm' }}>{BusinessPhrases.closing('formal')}</p>

      <style>{printStyle}</style>
    </div>
  );
}
