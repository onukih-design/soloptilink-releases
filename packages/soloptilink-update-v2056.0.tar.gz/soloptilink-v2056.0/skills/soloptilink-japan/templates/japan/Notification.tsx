/**
 * 通知書テンプレート (対外)
 * 契約解除/値上げ/代表者変更等の正式通知
 */
import React from 'react';
import { Party, docPageStyle, MetaRow, formatJP, printStyle, IssuerBlock } from './_common';
import { BusinessPhrases } from '../../lib/japan/keigo';
import { t, type Locale } from '../../lib/japan/i18n';

export interface NotificationProps {
  issuer: Party;
  recipient: Party;
  noticeNo: string;
  issueDate: Date;
  subject: string;                 // 件名
  notificationType?: '契約解除' | '契約終了' | '値上げ通知' | '代表者変更' | '移転通知' | '営業時間変更' | '商号変更' | 'その他';
  body: string;                    // 通知本文
  effectiveDate?: Date;            // 発効日
  contact?: string;                // 問い合わせ先
  sealDataUrl?: string;
  locale?: Locale;
}

export function Notification({ issuer, recipient, noticeNo, issueDate, subject, notificationType = 'その他', body, effectiveDate, contact, sealDataUrl, locale = 'ja' }: NotificationProps) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  return (
    <div className="notification-doc" style={docPageStyle}>
      <div style={{ textAlign: 'right', fontSize: '9pt', marginBottom: '6mm' }}>
        文書番号: {noticeNo}<br />
        {formatJP(issueDate)}
      </div>

      {/* 宛先・発行者 */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8mm' }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: '12pt', borderBottom: '1px solid #222', paddingBottom: '3mm' }}>
            {recipient.companyName} 御中
          </div>
        </div>
        <div style={{ flex: 1 }}><IssuerBlock party={issuer} sealDataUrl={sealDataUrl} /></div>
      </div>

      <h2 style={{ textAlign: 'center', fontSize: '16pt', margin: '6mm 0', padding: '4mm', background: '#f5f5f5', border: '1px solid #333' }}>
        {subject}
      </h2>

      <p style={{ marginBottom: '6mm' }}>{BusinessPhrases.opening('thanks')}</p>

      <p style={{ marginBottom: '6mm' }}>さて、このたび弊社は下記の通り <strong>{notificationType}</strong> をいたしましたので、謹んでお知らせ申し上げます。</p>

      <div style={{ padding: '6mm', background: '#fafafa', border: '2px solid #333', marginBottom: '6mm' }}>
        <div style={{ textAlign: 'center', fontSize: '14pt', marginBottom: '4mm' }}>記</div>
        <div style={{ whiteSpace: 'pre-line', lineHeight: '1.8' }}>{body}</div>
        {effectiveDate && <div style={{ marginTop: '4mm', fontWeight: 'bold' }}>発効日: {formatJP(effectiveDate)}</div>}
        <div style={{ textAlign: 'center', marginTop: '6mm' }}>以上</div>
      </div>

      {contact && (
        <div style={{ padding: '4mm', background: '#f9f9f9', fontSize: '9pt' }}>
          <strong>【お問い合わせ先】</strong>{contact}
        </div>
      )}

      <p style={{ marginTop: '6mm' }}>{BusinessPhrases.closing('formal')}</p>

      <style>{printStyle}</style>
    </div>
  );
}
