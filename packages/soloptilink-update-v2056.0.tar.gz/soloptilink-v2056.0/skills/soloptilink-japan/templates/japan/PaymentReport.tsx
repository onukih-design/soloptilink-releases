/**
 * 支払調書テンプレート (個人事業主/フリーランスへの支払)
 * 5万円超の支払 or 弁護士・税理士等への支払は税務署提出義務
 */
import React from 'react';
import { Party, docPageStyle, printStyle } from './_common';
import { formatBoth } from '../../lib/japan/wareki';
import { t, type Locale } from '../../lib/japan/i18n';

export interface PaymentReportProps {
  issuer: Party;                 // 支払者
  recipient: {
    name: string;
    postalCode: string;
    address: string;
    myNumberMasked?: string;     // マスク済みマイナ
  };
  fiscalYear: number;
  category: '報酬・料金' | '広告宣伝' | '不動産使用料' | '原稿料・講演料' | 'その他';
  detail: string;                // 支払内容詳細
  totalPayment: number;          // 支払金額
  withholdingTax: number;        // 源泉徴収税額
  sealDataUrl?: string;
  locale?: Locale;
}

export function PaymentReport({ issuer, recipient, fiscalYear, category, detail, totalPayment, withholdingTax, sealDataUrl, locale = 'ja' }: PaymentReportProps) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  return (
    <div className="payment-report-doc" style={{ ...docPageStyle, fontSize: '9pt' }}>
      <h1 style={{ textAlign: 'center', fontSize: '16pt', margin: '0 0 2mm 0' }}>{locale === 'ja' ? `${fiscalYear}年 ${category}等の支払調書` : `${fiscalYear} ${L('payment_report')}`}</h1>
      <div style={{ textAlign: 'right', fontSize: '7pt', color: '#888', marginBottom: '4mm' }}>国税庁様式 (簡易版)</div>

      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '3mm' }}>
        <tbody>
          <tr>
            <td style={{ border: '1px solid #333', padding: '2mm', width: '20%', background: '#eee' }}>支払を受ける者 住所</td>
            <td style={{ border: '1px solid #333', padding: '2mm' }}>〒{recipient.postalCode} {recipient.address}</td>
            <td style={{ border: '1px solid #333', padding: '2mm', width: '15%', background: '#eee' }}>個人番号</td>
            <td style={{ border: '1px solid #333', padding: '2mm', fontFamily: 'monospace' }}>{recipient.myNumberMasked ?? '************'}</td>
          </tr>
          <tr>
            <td style={{ border: '1px solid #333', padding: '2mm', background: '#eee' }}>氏名・名称</td>
            <td colSpan={3} style={{ border: '1px solid #333', padding: '2mm', fontSize: '12pt', fontWeight: 'bold' }}>{recipient.name}</td>
          </tr>
        </tbody>
      </table>

      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '3mm' }}>
        <thead>
          <tr style={{ background: '#333', color: 'white' }}>
            <th style={{ padding: '2mm', border: '1px solid #333' }}>区分</th>
            <th style={{ padding: '2mm', border: '1px solid #333' }}>細目</th>
            <th style={{ padding: '2mm', border: '1px solid #333' }}>支払金額</th>
            <th style={{ padding: '2mm', border: '1px solid #333' }}>源泉徴収税額</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style={{ padding: '2mm', border: '1px solid #333' }}>{category}</td>
            <td style={{ padding: '2mm', border: '1px solid #333' }}>{detail}</td>
            <td style={{ padding: '2mm', border: '1px solid #333', textAlign: 'right', fontWeight: 'bold' }}>¥{totalPayment.toLocaleString()}</td>
            <td style={{ padding: '2mm', border: '1px solid #333', textAlign: 'right', fontWeight: 'bold', color: '#c00' }}>¥{withholdingTax.toLocaleString()}</td>
          </tr>
        </tbody>
      </table>

      <div style={{ fontSize: '8pt', marginBottom: '8mm', color: '#666' }}>
        ※年間支払金額が5万円を超える場合、税務署への提出義務があります（所得税法第225条）。
        ※支払を受ける者にも同内容の写しを交付してください。
      </div>

      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '8pt' }}>
        <tbody>
          <tr>
            <td style={{ border: '1px solid #333', padding: '2mm', background: '#eee', width: '20%' }}>支払者</td>
            <td style={{ border: '1px solid #333', padding: '2mm' }}>
              {issuer.postalCode && `〒${issuer.postalCode}　`}{issuer.address}<br />
              <strong>{issuer.companyName}</strong>{issuer.phone && `　TEL: ${issuer.phone}`}
              {issuer.registrationNumber && <div style={{ fontSize: '7pt' }}>法人番号/登録番号: {issuer.registrationNumber}</div>}
            </td>
            <td style={{ border: '1px solid #333', padding: '2mm', textAlign: 'center', width: '15%' }}>
              {sealDataUrl && <img src={sealDataUrl} alt="印" style={{ width: '18mm', height: '18mm' }} />}
            </td>
          </tr>
        </tbody>
      </table>

      <div style={{ marginTop: '4mm', fontSize: '7pt' }}>
        交付日: {formatBoth(new Date())}
      </div>

      <style>{printStyle}</style>
    </div>
  );
}
