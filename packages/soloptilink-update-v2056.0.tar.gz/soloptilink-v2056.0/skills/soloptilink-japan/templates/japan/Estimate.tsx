/**
 * 見積書テンプレート（Phase 3 i18n統合版 - ja/en/zh-CN対応）
 */
import React from 'react';
import { formatBoth } from '../../lib/japan/wareki';
import { summarizeByRate, type TaxRate } from '../../lib/japan/tax';
import { BusinessPhrases } from '../../lib/japan/keigo';
import { t, type Locale } from '../../lib/japan/i18n';

export interface EstimateLine {
  description: string;
  qty: number;
  unit?: string;
  unitPrice: number;
  rate: TaxRate;
}

export interface EstimateProps {
  issuer: { companyName: string; registrationNumber?: string; postalCode: string; address: string; phone: string };
  recipient: { companyName: string; honorific?: '御中' | '様' };
  estimateNo: string;
  issueDate: Date;
  validUntil: Date;
  subject: string;
  deliveryLocation?: string;
  deliveryDate?: string;
  paymentTerms?: string;
  lines: EstimateLine[];
  sealDataUrl?: string;
  remarks?: string;
  locale?: Locale;
}

export function Estimate({ issuer, recipient, estimateNo, issueDate, validUntil, subject, deliveryLocation, deliveryDate, paymentTerms, lines, sealDataUrl, remarks, locale = 'ja' }: EstimateProps) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  const summary = summarizeByRate(lines.map(l => ({ amount: l.qty * l.unitPrice, rate: l.rate })));
  const subtotal = summary.standard.subtotal + summary.reduced.subtotal + summary.exempt.subtotal;
  const tax = summary.standard.tax + summary.reduced.tax;
  const total = subtotal + tax;

  return (
    <div className="estimate-doc" style={{ width: '210mm', minHeight: '297mm', padding: '20mm', fontFamily: "'Noto Sans JP', sans-serif", background: 'white', fontSize: '10pt', color: '#222' }}>
      <h1 style={{ textAlign: 'center', fontSize: '24pt', letterSpacing: locale === 'ja' ? '16pt' : '4pt', margin: '0 0 16mm 0' }}>{locale === 'ja' ? '御　見　積　書' : L('estimate')}</h1>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8mm' }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: '14pt', borderBottom: '1px solid #222', paddingBottom: '4px' }}>
            {recipient.companyName} {recipient.honorific ?? '御中'}
          </div>
        </div>
        <div style={{ flex: 1, textAlign: 'right', position: 'relative' }}>
          <div style={{ fontWeight: 'bold', fontSize: '12pt' }}>{issuer.companyName}</div>
          {issuer.registrationNumber && <div style={{ fontSize: '9pt' }}>登録番号: {issuer.registrationNumber}</div>}
          <div style={{ fontSize: '9pt' }}>〒{issuer.postalCode} {issuer.address}</div>
          <div style={{ fontSize: '9pt' }}>TEL: {issuer.phone}</div>
          {sealDataUrl && <img src={sealDataUrl} alt="印影" style={{ position: 'absolute', top: '10mm', right: '5mm', width: '20mm', height: '20mm' }} />}
        </div>
      </div>

      <div style={{ display: 'flex', gap: '8mm', marginBottom: '6mm', fontSize: '10pt' }}>
        <div>見積番号: {estimateNo}</div>
        <div>発行日: {formatBoth(issueDate)}</div>
        <div>有効期限: {formatBoth(validUntil)}</div>
      </div>

      <div style={{ textAlign: 'center', marginBottom: '4mm' }}>
        <div style={{ fontSize: '12pt' }}>件名: {subject}</div>
      </div>
      <div style={{ background: '#f5f5f5', padding: '6mm', textAlign: 'center', marginBottom: '8mm', border: '1px solid #ccc' }}>
        <div style={{ fontSize: '10pt', color: '#555' }}>お見積金額（税込）</div>
        <div style={{ fontSize: '24pt', fontWeight: 'bold' }}>¥{total.toLocaleString()}</div>
      </div>

      <p style={{ marginBottom: '6mm' }}>{BusinessPhrases.estimateNote()}</p>

      {/* 納入条件 */}
      <table style={{ width: '100%', marginBottom: '6mm', fontSize: '10pt' }}>
        <tbody>
          {deliveryLocation && <tr><th style={{ textAlign: 'left', padding: '4px', background: '#eee', width: '30mm' }}>納入場所</th><td style={{ padding: '4px' }}>{deliveryLocation}</td></tr>}
          {deliveryDate && <tr><th style={{ textAlign: 'left', padding: '4px', background: '#eee' }}>納期</th><td style={{ padding: '4px' }}>{deliveryDate}</td></tr>}
          {paymentTerms && <tr><th style={{ textAlign: 'left', padding: '4px', background: '#eee' }}>お支払条件</th><td style={{ padding: '4px' }}>{paymentTerms}</td></tr>}
        </tbody>
      </table>

      {/* 明細 */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '6mm', fontSize: '10pt' }}>
        <thead>
          <tr style={{ background: '#333', color: 'white' }}>
            <th style={{ padding: '4px 8px', textAlign: 'left' }}>品目・仕様</th>
            <th style={{ padding: '4px 8px', textAlign: 'right' }}>数量</th>
            <th style={{ padding: '4px 8px', textAlign: 'left' }}>単位</th>
            <th style={{ padding: '4px 8px', textAlign: 'right' }}>単価</th>
            <th style={{ padding: '4px 8px', textAlign: 'right' }}>金額</th>
          </tr>
        </thead>
        <tbody>
          {lines.map((l, i) => (
            <tr key={i} style={{ borderBottom: '1px solid #ddd' }}>
              <td style={{ padding: '4px 8px' }}>{l.description}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>{l.qty.toLocaleString()}</td>
              <td style={{ padding: '4px 8px' }}>{l.unit ?? ''}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>¥{l.unitPrice.toLocaleString()}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>¥{(l.qty * l.unitPrice).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div style={{ marginLeft: 'auto', width: '80mm', fontSize: '10pt' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0' }}><span>小計</span><span>¥{subtotal.toLocaleString()}</span></div>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '2px 0' }}><span>消費税</span><span>¥{tax.toLocaleString()}</span></div>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderTop: '2px solid #333', fontWeight: 'bold', fontSize: '12pt' }}><span>合計</span><span>¥{total.toLocaleString()}</span></div>
      </div>

      {remarks && <div style={{ marginTop: '8mm', fontSize: '9pt' }}><strong>備考:</strong> {remarks}</div>}

      <style>{`@media print { @page { size: A4; margin: 0; } }`}</style>
    </div>
  );
}
