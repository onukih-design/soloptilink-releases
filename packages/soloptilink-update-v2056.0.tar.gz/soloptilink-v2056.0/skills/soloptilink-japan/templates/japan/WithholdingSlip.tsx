/**
 * 源泉徴収票テンプレート (給与所得者向け)
 * 国税庁様式に準拠した簡易版
 */
import React from 'react';
import { Party, docPageStyle, printStyle } from './_common';
import { formatBoth, formatWareki } from '../../lib/japan/wareki';
import { t, type Locale } from '../../lib/japan/i18n';

export interface WithholdingSlipProps {
  issuer: Party;               // 支払者（会社）
  recipient: {
    name: string;
    nameKana?: string;
    postalCode: string;
    address: string;
    myNumberMasked?: string;   // マスク済みマイナンバー表示用
    birthDate?: Date;
    jobTitle?: string;
  };
  fiscalYear: number;           // 対象年 (西暦)
  salary: {
    totalPayment: number;       // 支払金額
    deduction: number;          // 給与所得控除後の金額
    employmentIncomeDeduction: number; // 所得控除の額の合計
    withholdingTax: number;     // 源泉徴収税額
  };
  dependents: {
    spouse: boolean;
    dependents: number;         // 扶養親族数
    under16: number;            // 16歳未満扶養親族数
    disabled: number;
  };
  socialInsurance: number;      // 社会保険料等の金額
  lifeInsurance?: number;
  housingLoanDeduction?: number;
  sealDataUrl?: string;
  locale?: Locale;
}

export function WithholdingSlip({ issuer, recipient, fiscalYear, salary, dependents, socialInsurance, lifeInsurance = 0, housingLoanDeduction = 0, sealDataUrl, locale = 'ja' }: WithholdingSlipProps) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  const warekiYear = formatWareki(new Date(fiscalYear, 11, 31), 'long').match(/(令和|平成)(\S+?)年/);

  return (
    <div className="withholding-doc" style={{ ...docPageStyle, fontSize: '8pt' }}>
      <h1 style={{ textAlign: 'center', fontSize: '16pt', margin: '0 0 2mm 0' }}>{locale === 'ja' ? `${warekiYear ? warekiYear[0] : fiscalYear + '年'} 給与所得の源泉徴収票` : `${fiscalYear} ${L('withholding_slip')}`}</h1>
      <div style={{ textAlign: 'right', fontSize: '7pt', color: '#888', marginBottom: '4mm' }}>国税庁様式 (簡易版)</div>

      {/* 受給者情報 */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '2mm', fontSize: '8pt' }}>
        <tbody>
          <tr>
            <td style={{ border: '1px solid #333', padding: '2mm', width: '30%', background: '#eee' }}>住所又は居所</td>
            <td style={{ border: '1px solid #333', padding: '2mm' }}>〒{recipient.postalCode}<br />{recipient.address}</td>
            <td style={{ border: '1px solid #333', padding: '2mm', width: '20%', background: '#eee' }}>個人番号</td>
            <td style={{ border: '1px solid #333', padding: '2mm', fontFamily: 'monospace' }}>{recipient.myNumberMasked ?? '************'}</td>
          </tr>
          <tr>
            <td style={{ border: '1px solid #333', padding: '2mm', background: '#eee' }}>氏名 ({recipient.nameKana ?? ''})</td>
            <td style={{ border: '1px solid #333', padding: '2mm', fontSize: '12pt' }}>{recipient.name}</td>
            <td style={{ border: '1px solid #333', padding: '2mm', background: '#eee' }}>役職/職務</td>
            <td style={{ border: '1px solid #333', padding: '2mm' }}>{recipient.jobTitle ?? ''}</td>
          </tr>
        </tbody>
      </table>

      {/* 給与額 */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '2mm' }}>
        <thead>
          <tr style={{ background: '#333', color: 'white' }}>
            <th style={{ padding: '2mm', border: '1px solid #333' }}>種別</th>
            <th style={{ padding: '2mm', border: '1px solid #333' }}>支払金額</th>
            <th style={{ padding: '2mm', border: '1px solid #333' }}>給与所得控除後の金額</th>
            <th style={{ padding: '2mm', border: '1px solid #333' }}>所得控除の額の合計</th>
            <th style={{ padding: '2mm', border: '1px solid #333' }}>源泉徴収税額</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style={{ padding: '2mm', border: '1px solid #333', textAlign: 'center' }}>給与・賞与</td>
            <td style={{ padding: '2mm', border: '1px solid #333', textAlign: 'right' }}>¥{salary.totalPayment.toLocaleString()}</td>
            <td style={{ padding: '2mm', border: '1px solid #333', textAlign: 'right' }}>¥{salary.deduction.toLocaleString()}</td>
            <td style={{ padding: '2mm', border: '1px solid #333', textAlign: 'right' }}>¥{salary.employmentIncomeDeduction.toLocaleString()}</td>
            <td style={{ padding: '2mm', border: '1px solid #333', textAlign: 'right', fontWeight: 'bold' }}>¥{salary.withholdingTax.toLocaleString()}</td>
          </tr>
        </tbody>
      </table>

      {/* 扶養・控除 */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '2mm', fontSize: '8pt' }}>
        <thead>
          <tr style={{ background: '#eee' }}>
            <th style={{ border: '1px solid #333', padding: '2mm' }}>控除対象配偶者</th>
            <th style={{ border: '1px solid #333', padding: '2mm' }}>扶養親族数</th>
            <th style={{ border: '1px solid #333', padding: '2mm' }}>16歳未満扶養親族</th>
            <th style={{ border: '1px solid #333', padding: '2mm' }}>障害者</th>
            <th style={{ border: '1px solid #333', padding: '2mm' }}>社会保険料等</th>
            <th style={{ border: '1px solid #333', padding: '2mm' }}>生命保険料</th>
            <th style={{ border: '1px solid #333', padding: '2mm' }}>住宅借入金等特別控除</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td style={{ border: '1px solid #333', padding: '2mm', textAlign: 'center' }}>{dependents.spouse ? '有' : '無'}</td>
            <td style={{ border: '1px solid #333', padding: '2mm', textAlign: 'right' }}>{dependents.dependents} 人</td>
            <td style={{ border: '1px solid #333', padding: '2mm', textAlign: 'right' }}>{dependents.under16} 人</td>
            <td style={{ border: '1px solid #333', padding: '2mm', textAlign: 'right' }}>{dependents.disabled} 人</td>
            <td style={{ border: '1px solid #333', padding: '2mm', textAlign: 'right' }}>¥{socialInsurance.toLocaleString()}</td>
            <td style={{ border: '1px solid #333', padding: '2mm', textAlign: 'right' }}>¥{lifeInsurance.toLocaleString()}</td>
            <td style={{ border: '1px solid #333', padding: '2mm', textAlign: 'right' }}>¥{housingLoanDeduction.toLocaleString()}</td>
          </tr>
        </tbody>
      </table>

      {/* 支払者 */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '2mm', fontSize: '8pt' }}>
        <tbody>
          <tr>
            <td style={{ border: '1px solid #333', padding: '2mm', background: '#eee', width: '20%' }}>支払者</td>
            <td style={{ border: '1px solid #333', padding: '2mm' }}>
              {issuer.postalCode && `〒${issuer.postalCode}　`}{issuer.address}<br />
              <strong>{issuer.companyName}</strong>{issuer.phone && `　TEL: ${issuer.phone}`}
              {issuer.registrationNumber && <div style={{ fontSize: '7pt' }}>法人番号: {issuer.registrationNumber}</div>}
            </td>
            <td style={{ border: '1px solid #333', padding: '2mm', textAlign: 'center', width: '15%', verticalAlign: 'middle' }}>
              {sealDataUrl && <img src={sealDataUrl} alt="印" style={{ width: '18mm', height: '18mm' }} />}
            </td>
          </tr>
        </tbody>
      </table>

      <div style={{ marginTop: '8mm', fontSize: '7pt', color: '#888' }}>
        ※この源泉徴収票は電子交付又は書面交付されます。e-Tax・税務署での確認用にご活用ください。
      </div>

      <style>{printStyle}</style>
    </div>
  );
}
