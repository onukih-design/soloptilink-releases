/**
 * 検収書テンプレート
 * 下請法の「受領」明確化、検収判定（OK/NG/保留）記録用
 */
import React from 'react';
import { Party, docPageStyle, DocTitle, PartyBlock, IssuerBlock, MetaRow, formatJP, printStyle, SealStamp } from './_common';
import { t, type Locale } from '../../lib/japan/i18n';

export interface InspectionLine {
  description: string;
  orderNo?: string;
  qtyDelivered: number;
  qtyAccepted: number;
  qtyRejected: number;
  unit?: string;
  result: 'OK' | 'NG' | 'HOLD';
  defectReason?: string;
}

export interface InspectionReportProps {
  issuer: Party;            // 検収者（発注側）
  supplier: Party;          // 納入者（受注側）
  reportNo: string;
  inspectionDate: Date;
  orderNo?: string;
  deliveryDate?: Date;
  lines: InspectionLine[];
  overallResult: 'ACCEPTED' | 'REJECTED' | 'PARTIAL';
  inspector: string;
  sealDataUrl?: string;
  remarks?: string;
  locale?: Locale;
}

export function InspectionReport({ issuer, supplier, reportNo, inspectionDate, orderNo, deliveryDate, lines, overallResult, inspector, sealDataUrl, remarks, locale = 'ja' }: InspectionReportProps) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  const totalDelivered = lines.reduce((s, l) => s + l.qtyDelivered, 0);
  const totalAccepted = lines.reduce((s, l) => s + l.qtyAccepted, 0);
  const totalRejected = lines.reduce((s, l) => s + l.qtyRejected, 0);
  const resultLabel = overallResult === 'ACCEPTED' ? '検収合格' : overallResult === 'REJECTED' ? '検収不合格' : '一部合格';
  const resultColor = overallResult === 'ACCEPTED' ? '#0a7' : overallResult === 'REJECTED' ? '#c00' : '#f80';

  return (
    <div className="inspection-doc" style={docPageStyle}>
      <DocTitle>{locale === 'ja' ? '検　収　書' : L('inspection_report')}</DocTitle>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8mm' }}>
        <div style={{ flex: 1 }}>
          <PartyBlock party={supplier} />
          <div style={{ fontSize: '9pt', marginTop: '2mm' }}>下記の通り検収いたしましたのでご確認ください。</div>
        </div>
        <div style={{ flex: 1 }}><IssuerBlock party={issuer} sealDataUrl={sealDataUrl} /></div>
      </div>

      <MetaRow items={[
        { label: '検収書番号', value: reportNo },
        { label: '検収日', value: formatJP(inspectionDate) },
        ...(orderNo ? [{ label: '注文番号', value: orderNo }] : []),
        ...(deliveryDate ? [{ label: '納入日', value: formatJP(deliveryDate) }] : []),
      ]} />

      {/* 総合判定 */}
      <div style={{ textAlign: 'center', padding: '4mm', border: `3px solid ${resultColor}`, color: resultColor, fontWeight: 'bold', fontSize: '16pt', margin: '4mm 0' }}>
        総合判定: {resultLabel}
      </div>

      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '6mm', fontSize: '9pt' }}>
        <thead>
          <tr style={{ background: '#333', color: 'white' }}>
            <th style={{ padding: '4px 6px', textAlign: 'left' }}>品目</th>
            <th style={{ padding: '4px 6px', textAlign: 'right' }}>納入数</th>
            <th style={{ padding: '4px 6px', textAlign: 'right' }}>合格</th>
            <th style={{ padding: '4px 6px', textAlign: 'right' }}>不合格</th>
            <th style={{ padding: '4px 6px' }}>単位</th>
            <th style={{ padding: '4px 6px' }}>判定</th>
            <th style={{ padding: '4px 6px' }}>不具合内容</th>
          </tr>
        </thead>
        <tbody>
          {lines.map((l, i) => (
            <tr key={i} style={{ borderBottom: '1px solid #ddd' }}>
              <td style={{ padding: '4px 6px' }}>{l.description}</td>
              <td style={{ padding: '4px 6px', textAlign: 'right' }}>{l.qtyDelivered}</td>
              <td style={{ padding: '4px 6px', textAlign: 'right', color: '#0a7' }}>{l.qtyAccepted}</td>
              <td style={{ padding: '4px 6px', textAlign: 'right', color: l.qtyRejected > 0 ? '#c00' : '#222' }}>{l.qtyRejected}</td>
              <td style={{ padding: '4px 6px' }}>{l.unit ?? ''}</td>
              <td style={{ padding: '4px 6px', fontWeight: 'bold', color: l.result === 'OK' ? '#0a7' : l.result === 'NG' ? '#c00' : '#f80' }}>{l.result}</td>
              <td style={{ padding: '4px 6px', fontSize: '8pt' }}>{l.defectReason ?? ''}</td>
            </tr>
          ))}
          <tr style={{ background: '#f5f5f5', fontWeight: 'bold' }}>
            <td style={{ padding: '4px 6px' }}>合計</td>
            <td style={{ padding: '4px 6px', textAlign: 'right' }}>{totalDelivered}</td>
            <td style={{ padding: '4px 6px', textAlign: 'right' }}>{totalAccepted}</td>
            <td style={{ padding: '4px 6px', textAlign: 'right' }}>{totalRejected}</td>
            <td colSpan={3}></td>
          </tr>
        </tbody>
      </table>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end', marginTop: '12mm' }}>
        <div>
          <div>検収担当者: <strong>{inspector}</strong></div>
          {remarks && <div style={{ marginTop: '4mm', fontSize: '9pt' }}>備考: {remarks}</div>}
        </div>
        <div style={{ display: 'flex', gap: '4mm' }}>
          <div style={{ textAlign: 'center' }}><div style={{ fontSize: '8pt' }}>検収</div><SealStamp label="検収" /></div>
          <div style={{ textAlign: 'center' }}><div style={{ fontSize: '8pt' }}>承認</div><SealStamp label="承認" /></div>
        </div>
      </div>

      <style>{printStyle}</style>
    </div>
  );
}
