/**
 * 注文書（発注書）テンプレート - 下請法3条書面対応 (Phase 5 i18n統合版)
 * ja / en / zh-CN 3言語対応
 */
import React from 'react';
import { formatBoth } from '../../lib/japan/wareki';
import { Subcontract } from '../../lib/japan/laws';
import { t, type Locale } from '../../lib/japan/i18n';

export interface OrderLine {
  description: string;
  qty: number;
  unit?: string;
  unitPrice: number;
  deliveryDate?: string;
}

export interface PurchaseOrderProps {
  issuer: { companyName: string; postalCode: string; address: string; phone: string };
  recipient: { companyName: string; honorific?: '御中' | '様' };
  orderNo: string;
  orderDate: Date;
  subject: string;
  deliveryLocation: string;
  deliveryDate: string;
  paymentMethod: string;           // 例: 末日締め翌月末払い（銀行振込）
  paymentDate: string;              // 代金支払期日
  lines: OrderLine[];
  isSubcontracting?: boolean;       // 下請法対象取引
  sealDataUrl?: string;
  remarks?: string;
}

export function PurchaseOrder({ issuer, recipient, orderNo, orderDate, subject, deliveryLocation, deliveryDate, paymentMethod, paymentDate, lines, isSubcontracting, sealDataUrl, remarks, locale = 'ja' }: PurchaseOrderProps & { locale?: Locale }) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  const subtotal = lines.reduce((s, l) => s + l.qty * l.unitPrice, 0);
  const tax = Math.floor(subtotal * 0.10);
  const total = subtotal + tax;

  // 下請法対象の場合、3条書面必須事項のチェック
  const required = Subcontract.required3jouFields();

  return (
    <div className="order-doc" style={{ width: '210mm', minHeight: '297mm', padding: '20mm', fontFamily: "'Noto Sans JP', sans-serif", background: 'white', fontSize: '10pt', color: '#222' }}>
      <h1 style={{ textAlign: 'center', fontSize: '24pt', letterSpacing: locale === 'ja' ? '16pt' : '4pt', margin: '0 0 8mm 0' }}>{locale === 'ja' ? '注　文　書' : L('purchase_order')}</h1>
      {isSubcontracting && <div style={{ textAlign: 'right', fontSize: '8pt', color: '#c00', marginBottom: '4mm' }}>※本書面は下請法3条書面を兼ねます</div>}

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8mm' }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: '14pt', borderBottom: '1px solid #222', paddingBottom: '4px' }}>
            {recipient.companyName} {recipient.honorific ?? '御中'}
          </div>
        </div>
        <div style={{ flex: 1, textAlign: 'right', position: 'relative' }}>
          <div style={{ fontWeight: 'bold', fontSize: '12pt' }}>{issuer.companyName}</div>
          <div style={{ fontSize: '9pt' }}>〒{issuer.postalCode} {issuer.address}</div>
          <div style={{ fontSize: '9pt' }}>TEL: {issuer.phone}</div>
          {sealDataUrl && <img src={sealDataUrl} alt="印影" style={{ position: 'absolute', top: '10mm', right: '5mm', width: '20mm', height: '20mm' }} />}
        </div>
      </div>

      <div style={{ display: 'flex', gap: '8mm', marginBottom: '6mm' }}>
        <div>注文番号: {orderNo}</div>
        <div>発注日: {formatBoth(orderDate)}</div>
      </div>

      <div style={{ marginBottom: '6mm', fontSize: '12pt', textAlign: 'center' }}>件名: {subject}</div>

      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '6mm', fontSize: '10pt' }}>
        <thead>
          <tr style={{ background: '#333', color: 'white' }}>
            <th style={{ padding: '4px 8px', textAlign: 'left' }}>品目</th>
            <th style={{ padding: '4px 8px', textAlign: 'right' }}>数量</th>
            <th style={{ padding: '4px 8px' }}>単位</th>
            <th style={{ padding: '4px 8px', textAlign: 'right' }}>単価</th>
            <th style={{ padding: '4px 8px', textAlign: 'right' }}>金額</th>
            <th style={{ padding: '4px 8px' }}>納期</th>
          </tr>
        </thead>
        <tbody>
          {lines.map((l, i) => (
            <tr key={i} style={{ borderBottom: '1px solid #ddd' }}>
              <td style={{ padding: '4px 8px' }}>{l.description}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>{l.qty}</td>
              <td style={{ padding: '4px 8px' }}>{l.unit ?? ''}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>¥{l.unitPrice.toLocaleString()}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>¥{(l.qty * l.unitPrice).toLocaleString()}</td>
              <td style={{ padding: '4px 8px' }}>{l.deliveryDate ?? deliveryDate}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div style={{ marginLeft: 'auto', width: '80mm', fontSize: '10pt', marginBottom: '6mm' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>小計</span><span>¥{subtotal.toLocaleString()}</span></div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>消費税(10%)</span><span>¥{tax.toLocaleString()}</span></div>
        <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '2px solid #333', paddingTop: '4px', fontWeight: 'bold', fontSize: '12pt' }}><span>合計</span><span>¥{total.toLocaleString()}</span></div>
      </div>

      {/* 下請法3条書面必須事項 */}
      <table style={{ width: '100%', marginBottom: '6mm', fontSize: '10pt', borderCollapse: 'collapse' }}>
        <tbody>
          <tr><th style={{ background: '#eee', padding: '4px', textAlign: 'left', border: '1px solid #ccc' }}>納入場所</th><td style={{ padding: '4px', border: '1px solid #ccc' }}>{deliveryLocation}</td></tr>
          <tr><th style={{ background: '#eee', padding: '4px', textAlign: 'left', border: '1px solid #ccc' }}>納入期日</th><td style={{ padding: '4px', border: '1px solid #ccc' }}>{deliveryDate}</td></tr>
          <tr><th style={{ background: '#eee', padding: '4px', textAlign: 'left', border: '1px solid #ccc' }}>支払方法</th><td style={{ padding: '4px', border: '1px solid #ccc' }}>{paymentMethod}</td></tr>
          <tr><th style={{ background: '#eee', padding: '4px', textAlign: 'left', border: '1px solid #ccc' }}>支払期日</th><td style={{ padding: '4px', border: '1px solid #ccc' }}>{paymentDate}</td></tr>
        </tbody>
      </table>

      {isSubcontracting && (
        <div style={{ fontSize: '8pt', color: '#555', border: '1px solid #ccc', padding: '3mm', marginBottom: '6mm' }}>
          <strong>下請法3条書面必須事項:</strong> {required.join(' / ')}
        </div>
      )}

      {remarks && <div style={{ fontSize: '9pt' }}><strong>備考:</strong> {remarks}</div>}

      <style>{`@media print { @page { size: A4; margin: 0; } }`}</style>
    </div>
  );
}
