/**
 * 議事録テンプレート
 * 会議の決定事項/ToDo/次回予定を構造化
 */
import React from 'react';
import { docPageStyle, printStyle, formatJP } from './_common';
import { t, type Locale } from '../../lib/japan/i18n';

export interface MinutesDecision {
  topic: string;
  decision: string;
  dissent?: string;            // 反対意見
}

export interface MinutesAction {
  task: string;
  owner: string;
  due: Date | string;
  priority?: 'high' | 'medium' | 'low';
}

export interface MeetingMinutesProps {
  meetingTitle: string;
  meetingNo?: string;
  meetingDate: Date;
  meetingTime: string;          // 例: 14:00〜15:30
  location: string;
  organizer: string;
  attendees: Array<{ name: string; org?: string; title?: string }>;
  absentees?: Array<{ name: string; reason?: string }>;
  agenda: string[];
  discussions: Array<{ topic: string; summary: string }>;
  decisions: MinutesDecision[];
  actions: MinutesAction[];
  nextMeeting?: { date: Date; location?: string };
  minutesTakerName: string;
  approvedBy?: string;
  locale?: Locale;
}

export function MeetingMinutes({ meetingTitle, meetingNo, meetingDate, meetingTime, location, organizer, attendees, absentees = [], agenda, discussions, decisions, actions, nextMeeting, minutesTakerName, approvedBy, locale = 'ja' }: MeetingMinutesProps) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  return (
    <div className="minutes-doc" style={docPageStyle}>
      <h1 style={{ textAlign: 'center', fontSize: '18pt', margin: '0 0 4mm 0' }}>{locale === 'ja' ? '議　事　録' : L('meeting_minutes')}</h1>
      {meetingNo && <div style={{ textAlign: 'right', fontSize: '9pt' }}>議事録番号: {meetingNo}</div>}

      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '4mm', fontSize: '10pt' }}>
        <tbody>
          <tr>
            <th style={{ background: '#eee', padding: '2mm', border: '1px solid #ccc', width: '15%', textAlign: 'left' }}>会議名</th>
            <td style={{ border: '1px solid #ccc', padding: '2mm' }} colSpan={3}><strong>{meetingTitle}</strong></td>
          </tr>
          <tr>
            <th style={{ background: '#eee', padding: '2mm', border: '1px solid #ccc', textAlign: 'left' }}>日時</th>
            <td style={{ border: '1px solid #ccc', padding: '2mm' }}>{formatJP(meetingDate)} {meetingTime}</td>
            <th style={{ background: '#eee', padding: '2mm', border: '1px solid #ccc', textAlign: 'left' }}>場所</th>
            <td style={{ border: '1px solid #ccc', padding: '2mm' }}>{location}</td>
          </tr>
          <tr>
            <th style={{ background: '#eee', padding: '2mm', border: '1px solid #ccc', textAlign: 'left' }}>主催</th>
            <td style={{ border: '1px solid #ccc', padding: '2mm' }} colSpan={3}>{organizer}</td>
          </tr>
          <tr>
            <th style={{ background: '#eee', padding: '2mm', border: '1px solid #ccc', textAlign: 'left' }}>出席者</th>
            <td style={{ border: '1px solid #ccc', padding: '2mm' }} colSpan={3}>
              {attendees.map(a => `${a.name}${a.title ? ` (${a.title})` : ''}${a.org ? ` [${a.org}]` : ''}`).join('、')}
            </td>
          </tr>
          {absentees.length > 0 && (
            <tr>
              <th style={{ background: '#eee', padding: '2mm', border: '1px solid #ccc', textAlign: 'left' }}>欠席者</th>
              <td style={{ border: '1px solid #ccc', padding: '2mm' }} colSpan={3}>
                {absentees.map(a => `${a.name}${a.reason ? ` (${a.reason})` : ''}`).join('、')}
              </td>
            </tr>
          )}
        </tbody>
      </table>

      <h2 style={{ fontSize: '12pt', background: '#333', color: 'white', padding: '2mm 3mm', margin: '4mm 0 2mm' }}>1. 議題</h2>
      <ol style={{ paddingLeft: '8mm' }}>
        {agenda.map((a, i) => <li key={i}>{a}</li>)}
      </ol>

      <h2 style={{ fontSize: '12pt', background: '#333', color: 'white', padding: '2mm 3mm', margin: '4mm 0 2mm' }}>2. 議論の内容</h2>
      {discussions.map((d, i) => (
        <div key={i} style={{ marginBottom: '3mm' }}>
          <strong>{i + 1}. {d.topic}</strong>
          <div style={{ paddingLeft: '6mm', marginTop: '1mm', whiteSpace: 'pre-line' }}>{d.summary}</div>
        </div>
      ))}

      <h2 style={{ fontSize: '12pt', background: '#c00', color: 'white', padding: '2mm 3mm', margin: '4mm 0 2mm' }}>3. 決定事項</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '10pt', marginBottom: '4mm' }}>
        <thead>
          <tr style={{ background: '#eee' }}>
            <th style={{ border: '1px solid #ccc', padding: '2mm' }}>議題</th>
            <th style={{ border: '1px solid #ccc', padding: '2mm' }}>決定内容</th>
            <th style={{ border: '1px solid #ccc', padding: '2mm' }}>反対意見</th>
          </tr>
        </thead>
        <tbody>
          {decisions.map((d, i) => (
            <tr key={i}>
              <td style={{ border: '1px solid #ccc', padding: '2mm' }}>{d.topic}</td>
              <td style={{ border: '1px solid #ccc', padding: '2mm' }}><strong>{d.decision}</strong></td>
              <td style={{ border: '1px solid #ccc', padding: '2mm' }}>{d.dissent ?? '-'}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <h2 style={{ fontSize: '12pt', background: '#0a7', color: 'white', padding: '2mm 3mm', margin: '4mm 0 2mm' }}>4. アクションアイテム</h2>
      <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: '10pt', marginBottom: '4mm' }}>
        <thead>
          <tr style={{ background: '#eee' }}>
            <th style={{ border: '1px solid #ccc', padding: '2mm' }}>タスク</th>
            <th style={{ border: '1px solid #ccc', padding: '2mm' }}>担当</th>
            <th style={{ border: '1px solid #ccc', padding: '2mm' }}>期限</th>
            <th style={{ border: '1px solid #ccc', padding: '2mm' }}>優先度</th>
          </tr>
        </thead>
        <tbody>
          {actions.map((a, i) => (
            <tr key={i}>
              <td style={{ border: '1px solid #ccc', padding: '2mm' }}>{a.task}</td>
              <td style={{ border: '1px solid #ccc', padding: '2mm' }}>{a.owner}</td>
              <td style={{ border: '1px solid #ccc', padding: '2mm' }}>{typeof a.due === 'string' ? a.due : formatJP(a.due)}</td>
              <td style={{ border: '1px solid #ccc', padding: '2mm', textAlign: 'center', color: a.priority === 'high' ? '#c00' : a.priority === 'low' ? '#888' : '#222' }}>
                {a.priority === 'high' ? '高' : a.priority === 'low' ? '低' : '中'}
              </td>
            </tr>
          ))}
        </tbody>
      </table>

      {nextMeeting && (
        <div style={{ padding: '3mm', background: '#fffbe6', marginBottom: '4mm', fontSize: '10pt' }}>
          <strong>次回会議:</strong> {formatJP(nextMeeting.date)}{nextMeeting.location && ` @ ${nextMeeting.location}`}
        </div>
      )}

      <div style={{ marginTop: '8mm', textAlign: 'right', fontSize: '10pt' }}>
        <div>議事録作成: {minutesTakerName}</div>
        {approvedBy && <div>承認: {approvedBy}</div>}
      </div>

      <style>{printStyle}</style>
    </div>
  );
}
