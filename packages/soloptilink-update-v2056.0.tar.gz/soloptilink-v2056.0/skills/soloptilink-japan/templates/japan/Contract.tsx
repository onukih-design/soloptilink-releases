/**
 * 契約書テンプレート (汎用)
 * 契約期間/解除条項/管轄裁判所/印紙税対応
 */
import React from 'react';
import { Party, docPageStyle, printStyle, SealStamp } from './_common';
import { formatBoth, formatWareki } from '../../lib/japan/wareki';
import { t, type Locale } from '../../lib/japan/i18n';

export interface ContractClause {
  title: string;
  body: string;
}

export interface ContractProps {
  title: string;                  // 契約書名
  partyA: Party & { role?: string };  // 甲
  partyB: Party & { role?: string };  // 乙
  executionDate: Date;            // 締結日
  startDate: Date;
  endDate?: Date;
  autoRenewal?: boolean;
  contractValue?: number;         // 契約金額（印紙税計算用）
  clauses: ContractClause[];
  jurisdiction?: string;          // 管轄裁判所
  partyASealUrl?: string;
  partyBSealUrl?: string;
  locale?: Locale;
}

/**
 * 印紙税額表 第2号文書 (請負に関する契約書) ── 本則
 *
 * ★正典 (SoT): 本体 lib/japan/eseal.ts の STAMP_TAX_DOC2_BRACKETS /
 *   STAMP_TAX_DOC2_NON_TAXABLE_UNDER。数値の一次情報は
 *   lib/japan/legal-values/approval-workflow.legal.json に
 *   国税庁 タックスアンサー No.7140 の出典付きで保持されている。
 *
 * ★なぜ import せず「転記」しているか:
 *   本テンプレートは顧客プロジェクトへ丸ごとコピーされる独立ファイルであり、
 *   本体 lib への import は移送先で解決できない。やむを得ず転記している。
 *   転記である以上ドリフトが起こりうるので、SoT / 法定値との一致は
 *   lib/japan/_verify/stamp-templates.verify.mjs (STPL レーン) が常時実走で突合する。
 *   ★この表を直すときは必ず SoT を先に直し、STPL レーンを通すこと。
 *
 * ★本則であり、建設工事請負契約の軽減措置ではない。
 *   本テンプレートは汎用の契約書なので、軽減対象外の契約に軽減額を当てると【過少】になり
 *   過怠税の対象になる。軽減対象の契約であれば実際の納付が本則より少なくて済むだけなので、
 *   本則を当てておくことが安全側である。
 *
 * ★引き方: 「上端 (この金額まで)」と税額の組で持ち、value <= upperJpy で引く
 *   (法令の「○○円以下」と一致させるため)。
 */
export const STAMP_DUTY_DOC2_BRACKETS: ReadonlyArray<{ upperJpy: number | null; taxJpy: number }> = [
  { upperJpy: 1_000_000, taxJpy: 200 },
  { upperJpy: 2_000_000, taxJpy: 400 },
  { upperJpy: 3_000_000, taxJpy: 1_000 },
  { upperJpy: 5_000_000, taxJpy: 2_000 },
  { upperJpy: 10_000_000, taxJpy: 10_000 },
  { upperJpy: 50_000_000, taxJpy: 20_000 },
  { upperJpy: 100_000_000, taxJpy: 60_000 },
  { upperJpy: 500_000_000, taxJpy: 100_000 },
  { upperJpy: 1_000_000_000, taxJpy: 200_000 },
  { upperJpy: 5_000_000_000, taxJpy: 400_000 },
  { upperJpy: null, taxJpy: 600_000 },
];

/** 1万円未満は非課税 (第2号文書)。国税庁 No.7140。 */
export const STAMP_DUTY_DOC2_NON_TAXABLE_UNDER = 10_000;

/**
 * 契約金額 (円) から第2号文書の印紙税額を求める。
 *
 * ★印紙税の不足は過怠税 (不足額とその2倍に相当する金額の合計 = 本税の3倍) の対象。
 *   「安く出る」ことは安全側ではないため、上位の階段を頭打ちにしてはならない。
 */
export function stampDuty(value: number): number {
  if (!Number.isFinite(value) || value < STAMP_DUTY_DOC2_NON_TAXABLE_UNDER) return 0;
  for (const b of STAMP_DUTY_DOC2_BRACKETS) {
    if (b.upperJpy === null || value <= b.upperJpy) return b.taxJpy;
  }
  return STAMP_DUTY_DOC2_BRACKETS[STAMP_DUTY_DOC2_BRACKETS.length - 1].taxJpy;
}

export function Contract({ title, partyA, partyB, executionDate, startDate, endDate, autoRenewal, contractValue, clauses, jurisdiction = '東京地方裁判所', partyASealUrl, partyBSealUrl, locale = 'ja' }: ContractProps) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  // title prop が明示されない場合は i18n から取得
  const displayTitle = title || L('contract');
  const duty = contractValue ? stampDuty(contractValue) : 0;

  return (
    <div className="contract-doc" style={docPageStyle}>
      <h1 style={{ textAlign: 'center', fontSize: '20pt', margin: '0 0 10mm 0', letterSpacing: locale === 'ja' ? '6pt' : '2pt' }}>{displayTitle}</h1>

      <p style={{ marginBottom: '4mm' }}>
        <strong>{partyA.companyName}</strong>（以下「甲」という。）と <strong>{partyB.companyName}</strong>（以下「乙」という。）は、以下のとおり契約を締結する。
      </p>

      {/* 条項 */}
      {clauses.map((c, i) => (
        <div key={i} style={{ marginBottom: '5mm' }}>
          <div style={{ fontWeight: 'bold', marginBottom: '2mm' }}>第{i + 1}条（{c.title}）</div>
          <div style={{ whiteSpace: 'pre-line', textAlign: 'justify', paddingLeft: '4mm' }}>{c.body}</div>
        </div>
      ))}

      {/* 期間・金額・管轄 */}
      <div style={{ marginTop: '6mm', padding: '4mm', background: '#f9f9f9', border: '1px solid #ccc', fontSize: '9pt' }}>
        <div>契約期間: {formatBoth(startDate)} 〜 {endDate ? formatBoth(endDate) : '（定めなし）'}{autoRenewal && '（自動更新条項あり）'}</div>
        {contractValue && <div>契約金額: ¥{contractValue.toLocaleString()}（印紙税: ¥{duty.toLocaleString()}）</div>}
        <div>管轄裁判所: {jurisdiction}</div>
      </div>

      {/* 署名欄 */}
      <p style={{ marginTop: '8mm' }}>本契約の成立を証するため、本書2通を作成し、甲乙各自記名押印の上、各1通を保有する。</p>

      <div style={{ textAlign: 'right', marginTop: '4mm' }}>{formatBoth(executionDate)}</div>

      <div style={{ display: 'flex', gap: '8mm', marginTop: '10mm' }}>
        {[{ party: partyA, seal: partyASealUrl, label: '甲' }, { party: partyB, seal: partyBSealUrl, label: '乙' }].map((p, i) => (
          <div key={i} style={{ flex: 1, padding: '4mm', border: '1px solid #333' }}>
            <div style={{ fontSize: '12pt', marginBottom: '2mm' }}>{p.label}: </div>
            <div>{p.party.postalCode && `〒${p.party.postalCode}`}</div>
            <div>{p.party.address}</div>
            <div style={{ fontSize: '12pt', fontWeight: 'bold', marginTop: '4mm' }}>{p.party.companyName}</div>
            {p.party.role && <div>{p.party.role}</div>}
            {p.party.personName && <div>{p.party.personName} {p.party.title ?? '代表取締役'}</div>}
            <div style={{ marginTop: '6mm', textAlign: 'right' }}>
              {p.seal ? <img src={p.seal} alt="印" style={{ width: '22mm', height: '22mm' }} /> : <SealStamp label="印" size={22} />}
            </div>
          </div>
        ))}
      </div>

      {duty > 0 && (
        <div style={{ marginTop: '6mm', fontSize: '8pt', color: '#c00', border: '1px dashed #c00', padding: '3mm', display: 'inline-block' }}>
          ※本契約書は印紙税法により ¥{duty.toLocaleString()} の収入印紙貼付が必要です。
        </div>
      )}

      <style>{printStyle}</style>
    </div>
  );
}
