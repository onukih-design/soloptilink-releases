/**
 * 支払通知書テンプレート
 * 下請法対応: 支払予定日、控除額、源泉徴収額を明示
 */
import React from 'react';
import { Party, docPageStyle, DocTitle, PartyBlock, IssuerBlock, MetaRow, formatJP, printStyle } from './_common';
import { t, type Locale } from '../../lib/japan/i18n';

export interface PaymentLine {
  invoiceNo?: string;
  description: string;
  amount: number;
  date?: Date;
}

export interface PaymentNoticeProps {
  issuer: Party;
  supplier: Party;
  noticeNo: string;
  issueDate: Date;
  paymentDate: Date;          // 実際の支払日
  lines: PaymentLine[];
  withholdingTax?: number;
  deductions?: Array<{ label: string; amount: number }>;
  bankInfo?: string;
  sealDataUrl?: string;
  remarks?: string;
  locale?: Locale;
}

export function PaymentNotice({ issuer, supplier, noticeNo, issueDate, paymentDate, lines, withholdingTax = 0, deductions = [], bankInfo, sealDataUrl, remarks, locale = 'ja' }: PaymentNoticeProps) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  const gross = lines.reduce((s, l) => s + l.amount, 0);
  const totalDeduction = deductions.reduce((s, d) => s + d.amount, 0);
  const net = gross - withholdingTax - totalDeduction;

  return (
    <div className="payment-notice-doc" style={docPageStyle}>
      <DocTitle>{locale === 'ja' ? '支　払　通　知　書' : L('payment_notice')}</DocTitle>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8mm' }}>
        <div style={{ flex: 1 }}>
          <PartyBlock party={supplier} />
          <div style={{ fontSize: '9pt', marginTop: '2mm' }}>平素よりお引き立ていただきありがとうございます。下記の通りお支払いいたしますのでご確認ください。</div>
        </div>
        <div style={{ flex: 1 }}><IssuerBlock party={issuer} sealDataUrl={sealDataUrl} /></div>
      </div>

      <MetaRow items={[
        { label: '通知書番号', value: noticeNo },
        { label: '通知日', value: formatJP(issueDate) },
        { label: 'お支払日', value: formatJP(paymentDate) },
      ]} />

      <div style={{ background: '#f5f5f5', padding: '6mm', textAlign: 'center', margin: '8mm 0', border: '1px solid #ccc' }}>
        <div style={{ fontSize: '10pt', color: '#555' }}>お支払金額（手取）</div>
        <div style={{ fontSize: '24pt', fontWeight: 'bold' }}>¥{net.toLocaleString()}</div>
      </div>

      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '6mm', fontSize: '10pt' }}>
        <thead>
          <tr style={{ background: '#333', color: 'white' }}>
            <th style={{ padding: '4px 8px', textAlign: 'left' }}>請求書番号</th>
            <th style={{ padding: '4px 8px', textAlign: 'left' }}>件名</th>
            <th style={{ padding: '4px 8px', textAlign: 'right' }}>金額</th>
            <th style={{ padding: '4px 8px' }}>発生日</th>
          </tr>
        </thead>
        <tbody>
          {lines.map((l, i) => (
            <tr key={i} style={{ borderBottom: '1px solid #ddd' }}>
              <td style={{ padding: '4px 8px' }}>{l.invoiceNo ?? '-'}</td>
              <td style={{ padding: '4px 8px' }}>{l.description}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>¥{l.amount.toLocaleString()}</td>
              <td style={{ padding: '4px 8px' }}>{l.date ? formatJP(l.date) : '-'}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div style={{ marginLeft: 'auto', width: '85mm', fontSize: '10pt' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '2px 0' }}><span>総支給額</span><span>¥{gross.toLocaleString()}</span></div>
        {deductions.map((d, i) => (
          <div key={i} style={{ display: 'flex', justifyContent: 'space-between', padding: '2px 0', color: '#c00' }}><span>{d.label}</span><span>-¥{d.amount.toLocaleString()}</span></div>
        ))}
        {withholdingTax > 0 && (
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '2px 0', color: '#c00' }}><span>源泉徴収税額</span><span>-¥{withholdingTax.toLocaleString()}</span></div>
        )}
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderTop: '2px solid #333', fontWeight: 'bold', fontSize: '12pt' }}><span>差引支給額</span><span>¥{net.toLocaleString()}</span></div>
      </div>

      {bankInfo && (
        <div style={{ marginTop: '8mm', padding: '4mm', background: '#f9f9f9', border: '1px solid #ddd' }}>
          <strong>お振込先:</strong> {bankInfo}
        </div>
      )}
      {remarks && <div style={{ marginTop: '4mm', fontSize: '9pt' }}>備考: {remarks}</div>}

      <style>{printStyle}</style>
    </div>
  );
}
