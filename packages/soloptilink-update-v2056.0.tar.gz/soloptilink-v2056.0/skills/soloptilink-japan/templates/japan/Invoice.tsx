/**
 * 適格請求書テンプレート（Phase 3 i18n統合版）
 * - インボイス登録番号欄
 * - 税率別集計 (10% / 軽減8% / 非課税)
 * - 源泉徴収対応 (個人事業主の場合)
 * - 振込先・印影配置
 * - A4 印刷最適化
 * - ja/en/zh-CN の3言語対応 (locale prop)
 */
import React from 'react';
import { formatBoth } from '../../lib/japan/wareki';
import { summarizeByRate, type TaxRate } from '../../lib/japan/tax';
import { BusinessPhrases } from '../../lib/japan/keigo';
import { t, type Locale } from '../../lib/japan/i18n';

export interface InvoiceLine {
  description: string;
  qty: number;
  unit?: string;
  unitPrice: number;
  rate: TaxRate;
  note?: string;
}

export interface InvoiceProps {
  // 発行者
  issuer: { companyName: string; registrationNumber: string; postalCode: string; address: string; phone: string; email?: string; bankInfo?: string };
  // 宛先
  recipient: { companyName: string; honorific?: '御中' | '様'; address?: string };
  // メタ
  invoiceNo: string;
  issueDate: Date;
  dueDate: Date;
  subject: string;
  // 明細
  lines: InvoiceLine[];
  // 源泉徴収 (個人事業主向け)
  withholdingTax?: number;
  // 印影
  sealDataUrl?: string;
  // 備考
  remarks?: string;
  // 言語（デフォルト: ja）
  locale?: Locale;
}

export function Invoice({ issuer, recipient, invoiceNo, issueDate, dueDate, subject, lines, withholdingTax = 0, sealDataUrl, remarks, locale = 'ja' }: InvoiceProps) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  const summary = summarizeByRate(lines.map(l => ({ amount: l.qty * l.unitPrice, rate: l.rate })));
  const totalBeforeTax = summary.standard.subtotal + summary.reduced.subtotal + summary.exempt.subtotal + summary.nontaxable.subtotal;
  const totalTax = summary.standard.tax + summary.reduced.tax;
  const grandTotal = totalBeforeTax + totalTax - withholdingTax;

  return (
    <div className="invoice-doc" style={{ width: '210mm', minHeight: '297mm', padding: '20mm', fontFamily: "'Noto Sans JP', 'Hiragino Sans', sans-serif", background: 'white', color: '#222', fontSize: '10pt' }}>
      {/* タイトル (i18n) */}
      <h1 style={{ textAlign: 'center', fontSize: '24pt', letterSpacing: locale === 'ja' ? '16pt' : '4pt', margin: '0 0 16mm 0' }}>{locale === 'ja' ? '請　求　書' : L('invoice')}</h1>

      {/* 宛先 + 発行者 */}
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8mm' }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: '14pt', borderBottom: '1px solid #222', paddingBottom: '4px', marginBottom: '4px' }}>
            {recipient.companyName} {recipient.honorific ?? L('honorific_company')}
          </div>
          {recipient.address && <div style={{ fontSize: '9pt', color: '#666' }}>{recipient.address}</div>}
        </div>
        <div style={{ flex: 1, textAlign: 'right', position: 'relative' }}>
          <div style={{ fontWeight: 'bold', fontSize: '12pt' }}>{issuer.companyName}</div>
          <div style={{ fontSize: '9pt' }}>{L('registration_number')}: {issuer.registrationNumber}</div>
          <div style={{ fontSize: '9pt' }}>〒{issuer.postalCode} {issuer.address}</div>
          <div style={{ fontSize: '9pt' }}>TEL: {issuer.phone}{issuer.email && ` / ${issuer.email}`}</div>
          {sealDataUrl && <img src={sealDataUrl} alt="印影" style={{ position: 'absolute', top: '10mm', right: '5mm', width: '20mm', height: '20mm', objectFit: 'contain' }} />}
        </div>
      </div>

      {/* メタ (i18n) */}
      <div style={{ display: 'flex', gap: '8mm', marginBottom: '8mm', fontSize: '10pt' }}>
        <div>{locale === 'ja' ? '請求書番号' : 'Invoice No.'}: {invoiceNo}</div>
        <div>{L('issue_date')}: {locale === 'ja' ? formatBoth(issueDate) : issueDate.toLocaleDateString(locale === 'en' ? 'en-US' : 'zh-CN')}</div>
        <div>{L('due_date')}: {locale === 'ja' ? formatBoth(dueDate) : dueDate.toLocaleDateString(locale === 'en' ? 'en-US' : 'zh-CN')}</div>
      </div>

      {/* 件名・合計 (i18n) */}
      <div style={{ textAlign: 'center', marginBottom: '4mm' }}>
        <div style={{ fontSize: '12pt' }}>{L('subject')}: {subject}</div>
      </div>
      <div style={{ background: '#f5f5f5', padding: '6mm', textAlign: 'center', marginBottom: '8mm', border: '1px solid #ccc' }}>
        <div style={{ fontSize: '10pt', color: '#555' }}>{locale === 'ja' ? 'ご請求金額' : L('total')}</div>
        <div style={{ fontSize: '24pt', fontWeight: 'bold' }}>¥{grandTotal.toLocaleString()}</div>
      </div>

      {/* 挨拶文 */}
      <p style={{ marginBottom: '6mm', fontSize: '10pt' }}>{locale === 'ja' ? BusinessPhrases.invoiceNote() : L('thanks_patronage')}</p>

      {/* 明細 (i18n) */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '4mm', fontSize: '10pt' }}>
        <thead>
          <tr style={{ background: '#333', color: 'white' }}>
            <th style={{ padding: '4px 8px', textAlign: 'left' }}>{L('description')}</th>
            <th style={{ padding: '4px 8px', textAlign: 'right', width: '15mm' }}>{L('quantity')}</th>
            <th style={{ padding: '4px 8px', textAlign: 'left', width: '12mm' }}>{locale === 'ja' ? '単位' : 'Unit'}</th>
            <th style={{ padding: '4px 8px', textAlign: 'right', width: '25mm' }}>{L('unit_price')}</th>
            <th style={{ padding: '4px 8px', textAlign: 'right', width: '12mm' }}>{locale === 'ja' ? '税率' : 'Tax'}</th>
            <th style={{ padding: '4px 8px', textAlign: 'right', width: '28mm' }}>{L('amount')}</th>
          </tr>
        </thead>
        <tbody>
          {lines.map((l, i) => (
            <tr key={i} style={{ borderBottom: '1px solid #ddd' }}>
              <td style={{ padding: '4px 8px' }}>{l.description}{l.rate === 'reduced' && ' ※'}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>{l.qty.toLocaleString()}</td>
              <td style={{ padding: '4px 8px' }}>{l.unit ?? ''}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>¥{l.unitPrice.toLocaleString()}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>{l.rate === 'standard' ? '10%' : l.rate === 'reduced' ? '8%' : l.rate === 'exempt' ? '非課税' : '不課税'}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>¥{(l.qty * l.unitPrice).toLocaleString()}</td>
            </tr>
          ))}
        </tbody>
      </table>
      <div style={{ fontSize: '9pt', color: '#666', marginBottom: '6mm' }}>※は軽減税率（8%）対象品目</div>

      {/* 合計 */}
      <div style={{ marginLeft: 'auto', width: '80mm', fontSize: '10pt' }}>
        {summary.standard.subtotal > 0 && (
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '2px 0' }}>
            <span>10%対象</span><span>¥{summary.standard.subtotal.toLocaleString()} (税 ¥{summary.standard.tax.toLocaleString()})</span>
          </div>
        )}
        {summary.reduced.subtotal > 0 && (
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '2px 0' }}>
            <span>8%対象</span><span>¥{summary.reduced.subtotal.toLocaleString()} (税 ¥{summary.reduced.tax.toLocaleString()})</span>
          </div>
        )}
        {summary.exempt.subtotal > 0 && (
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '2px 0' }}>
            <span>非課税</span><span>¥{summary.exempt.subtotal.toLocaleString()}</span>
          </div>
        )}
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '4px 0', borderTop: '1px solid #333' }}>
          <span>{L('subtotal')}</span><span>¥{totalBeforeTax.toLocaleString()}</span>
        </div>
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '2px 0' }}>
          <span>{L('tax')}</span><span>¥{totalTax.toLocaleString()}</span>
        </div>
        {withholdingTax > 0 && (
          <div style={{ display: 'flex', justifyContent: 'space-between', padding: '2px 0', color: '#c00' }}>
            <span>{locale === 'ja' ? '源泉徴収税額' : 'Withholding Tax'}</span><span>-¥{withholdingTax.toLocaleString()}</span>
          </div>
        )}
        <div style={{ display: 'flex', justifyContent: 'space-between', padding: '6px 0', borderTop: '2px solid #333', fontWeight: 'bold', fontSize: '12pt' }}>
          <span>{L('total')}</span><span>¥{grandTotal.toLocaleString()}</span>
        </div>
      </div>

      {/* 振込先・備考 */}
      {issuer.bankInfo && (
        <div style={{ marginTop: '8mm', padding: '4mm', background: '#f9f9f9', border: '1px solid #ddd', fontSize: '10pt' }}>
          <strong>お振込先:</strong> {issuer.bankInfo}
        </div>
      )}
      {remarks && (
        <div style={{ marginTop: '4mm', fontSize: '9pt', color: '#555' }}>
          <strong>備考:</strong> {remarks}
        </div>
      )}

      {/* 印刷CSS */}
      <style>{`@media print { @page { size: A4; margin: 0; } .invoice-doc { box-shadow: none !important; } }`}</style>
    </div>
  );
}
