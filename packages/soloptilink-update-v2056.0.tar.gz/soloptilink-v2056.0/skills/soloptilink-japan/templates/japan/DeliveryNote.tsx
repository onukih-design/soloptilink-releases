/**
 * 納品書テンプレート (Phase 5 i18n統合版 - ja/en/zh-CN)
 */
import React from 'react';
import { formatBoth } from '../../lib/japan/wareki';
import { summarizeByRate, type TaxRate } from '../../lib/japan/tax';
import { t, type Locale } from '../../lib/japan/i18n';

export interface DeliveryLine {
  description: string;
  qty: number;
  unit?: string;
  unitPrice: number;
  rate: TaxRate;
  lot?: string;
}

export interface DeliveryNoteProps {
  issuer: { companyName: string; registrationNumber?: string; postalCode: string; address: string; phone: string };
  recipient: { companyName: string; honorific?: '御中' | '様' };
  deliveryNo: string;
  deliveryDate: Date;
  orderNo?: string;
  subject: string;
  lines: DeliveryLine[];
  sealDataUrl?: string;
  remarks?: string;
  locale?: Locale;
}

export function DeliveryNote({ issuer, recipient, deliveryNo, deliveryDate, orderNo, subject, lines, sealDataUrl, remarks, locale = 'ja' }: DeliveryNoteProps) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  const summary = summarizeByRate(lines.map(l => ({ amount: l.qty * l.unitPrice, rate: l.rate })));
  const subtotal = summary.standard.subtotal + summary.reduced.subtotal + summary.exempt.subtotal;
  const tax = summary.standard.tax + summary.reduced.tax;
  const total = subtotal + tax;

  return (
    <div className="delivery-doc" style={{ width: '210mm', minHeight: '297mm', padding: '20mm', fontFamily: "'Noto Sans JP', sans-serif", background: 'white', fontSize: '10pt', color: '#222' }}>
      <h1 style={{ textAlign: 'center', fontSize: '24pt', letterSpacing: locale === 'ja' ? '16pt' : '4pt', margin: '0 0 16mm 0' }}>{locale === 'ja' ? '納　品　書' : L('delivery_note')}</h1>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '8mm' }}>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: '14pt', borderBottom: '1px solid #222', paddingBottom: '4px' }}>
            {recipient.companyName} {recipient.honorific ?? '御中'}
          </div>
          <div style={{ fontSize: '9pt', marginTop: '4mm' }}>下記の通り納品いたしましたので、ご査収のほどお願い申し上げます。</div>
        </div>
        <div style={{ flex: 1, textAlign: 'right', position: 'relative' }}>
          <div style={{ fontWeight: 'bold', fontSize: '12pt' }}>{issuer.companyName}</div>
          {issuer.registrationNumber && <div style={{ fontSize: '9pt' }}>登録番号: {issuer.registrationNumber}</div>}
          <div style={{ fontSize: '9pt' }}>〒{issuer.postalCode} {issuer.address}</div>
          <div style={{ fontSize: '9pt' }}>TEL: {issuer.phone}</div>
          {sealDataUrl && <img src={sealDataUrl} alt="印影" style={{ position: 'absolute', top: '10mm', right: '5mm', width: '20mm', height: '20mm' }} />}
        </div>
      </div>

      <div style={{ display: 'flex', gap: '8mm', marginBottom: '6mm' }}>
        <div>納品書番号: {deliveryNo}</div>
        <div>納品日: {formatBoth(deliveryDate)}</div>
        {orderNo && <div>注文番号: {orderNo}</div>}
      </div>

      <div style={{ marginBottom: '6mm', textAlign: 'center', fontSize: '12pt' }}>件名: {subject}</div>

      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '6mm', fontSize: '10pt' }}>
        <thead>
          <tr style={{ background: '#333', color: 'white' }}>
            <th style={{ padding: '4px 8px', textAlign: 'left' }}>品目</th>
            <th style={{ padding: '4px 8px', textAlign: 'right' }}>数量</th>
            <th style={{ padding: '4px 8px' }}>単位</th>
            <th style={{ padding: '4px 8px', textAlign: 'right' }}>単価</th>
            <th style={{ padding: '4px 8px', textAlign: 'right' }}>税率</th>
            <th style={{ padding: '4px 8px', textAlign: 'right' }}>金額</th>
            <th style={{ padding: '4px 8px' }}>ロット</th>
          </tr>
        </thead>
        <tbody>
          {lines.map((l, i) => (
            <tr key={i} style={{ borderBottom: '1px solid #ddd' }}>
              <td style={{ padding: '4px 8px' }}>{l.description}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>{l.qty}</td>
              <td style={{ padding: '4px 8px' }}>{l.unit ?? ''}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>¥{l.unitPrice.toLocaleString()}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>{l.rate === 'standard' ? '10%' : l.rate === 'reduced' ? '8%' : l.rate === 'exempt' ? '非課税' : '-'}</td>
              <td style={{ padding: '4px 8px', textAlign: 'right' }}>¥{(l.qty * l.unitPrice).toLocaleString()}</td>
              <td style={{ padding: '4px 8px' }}>{l.lot ?? ''}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div style={{ marginLeft: 'auto', width: '80mm', fontSize: '10pt' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>小計</span><span>¥{subtotal.toLocaleString()}</span></div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>消費税</span><span>¥{tax.toLocaleString()}</span></div>
        <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '2px solid #333', paddingTop: '4px', fontWeight: 'bold', fontSize: '12pt' }}><span>合計</span><span>¥{total.toLocaleString()}</span></div>
      </div>

      {remarks && <div style={{ marginTop: '8mm', fontSize: '9pt' }}><strong>備考:</strong> {remarks}</div>}

      {/* 受領印欄 */}
      <div style={{ marginTop: '12mm', display: 'flex', justifyContent: 'flex-end', gap: '4mm' }}>
        <div style={{ border: '1px solid #999', width: '25mm', height: '25mm', display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: '8pt', color: '#999' }}>受領印</div>
      </div>

      <style>{`@media print { @page { size: A4; margin: 0; } }`}</style>
    </div>
  );
}
