/**
 * 申請書テンプレート (汎用)
 * 有給・社内稟議・各種申請に対応
 */
import React from 'react';
import { docPageStyle, printStyle, ApprovalMatrix, formatJP } from './_common';
import { t, type Locale } from '../../lib/japan/i18n';

export interface ApplicationField {
  label: string;
  value: string;
  multiline?: boolean;
}

export interface ApplicationProps {
  applicationType: string;         // 例: 有給休暇申請書 / 経費精算申請書
  applicationNo?: string;
  applicant: { name: string; department: string; employeeNo?: string };
  applicationDate: Date;
  subject: string;
  fields: ApplicationField[];
  approvers: Array<{ role: string; name?: string }>;
  attachments?: string[];
  remarks?: string;
  locale?: Locale;
}

export function Application({ applicationType, applicationNo, applicant, applicationDate, subject, fields, approvers, attachments = [], remarks, locale = 'ja' }: ApplicationProps) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  const typeLabel = locale === 'ja' ? applicationType : applicationType || L('application');
  return (
    <div className="application-doc" style={docPageStyle}>
      <h1 style={{ textAlign: 'center', fontSize: '20pt', margin: '0 0 6mm 0' }}>{typeLabel}</h1>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '6mm' }}>
        <div style={{ fontSize: '10pt' }}>
          {applicationNo && <>申請番号: {applicationNo}　</>}申請日: {formatJP(applicationDate)}
        </div>
        <ApprovalMatrix approvers={approvers} />
      </div>

      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '6mm', fontSize: '10pt' }}>
        <tbody>
          <tr>
            <th style={{ background: '#eee', padding: '3mm', border: '1px solid #ccc', textAlign: 'left', width: '20%' }}>申請者</th>
            <td style={{ border: '1px solid #ccc', padding: '3mm' }}>{applicant.department} / {applicant.name}{applicant.employeeNo && ` (社員番号: ${applicant.employeeNo})`}</td>
          </tr>
          <tr>
            <th style={{ background: '#eee', padding: '3mm', border: '1px solid #ccc', textAlign: 'left' }}>件名</th>
            <td style={{ border: '1px solid #ccc', padding: '3mm' }}>{subject}</td>
          </tr>
          {fields.map((f, i) => (
            <tr key={i}>
              <th style={{ background: '#eee', padding: '3mm', border: '1px solid #ccc', textAlign: 'left' }}>{f.label}</th>
              <td style={{ border: '1px solid #ccc', padding: '3mm', whiteSpace: f.multiline ? 'pre-line' : 'normal', minHeight: f.multiline ? '20mm' : 'auto' }}>{f.value}</td>
            </tr>
          ))}
        </tbody>
      </table>

      {attachments.length > 0 && (
        <div style={{ marginBottom: '4mm', fontSize: '10pt' }}>
          <strong>添付書類:</strong>
          <ul style={{ margin: '2mm 0', paddingLeft: '6mm' }}>
            {attachments.map((a, i) => <li key={i}>{a}</li>)}
          </ul>
        </div>
      )}

      {remarks && <div style={{ fontSize: '9pt', padding: '3mm', background: '#fafafa', border: '1px solid #ddd' }}>備考: {remarks}</div>}

      <style>{printStyle}</style>
    </div>
  );
}
