/**
 * 発注書テンプレート (社内稟議用途の発注依頼)
 * PurchaseOrderとの違い: 社内承認フロー(稟議)が組み込まれている
 */
import React from 'react';
import { Party, docPageStyle, DocTitle, MetaRow, formatJP, printStyle, ApprovalMatrix } from './_common';
import { t, type Locale } from '../../lib/japan/i18n';

export interface RequisitionLine {
  description: string;
  qty: number;
  unit?: string;
  unitPrice: number;
  supplierCandidate?: string;
  justification?: string;
}

export interface PurchaseRequisitionProps {
  requisitionNo: string;
  requestDate: Date;
  requester: { name: string; department: string };
  purpose: string;                // 購入目的
  budget?: { account: string; remaining?: number };
  lines: RequisitionLine[];
  requiredDate: Date;             // 必要日
  deliveryLocation: string;
  approvers: Array<{ role: string; name?: string }>;   // 稟議承認者
  remarks?: string;
  locale?: Locale;
}

export function PurchaseRequisition({ requisitionNo, requestDate, requester, purpose, budget, lines, requiredDate, deliveryLocation, approvers, remarks, locale = 'ja' }: PurchaseRequisitionProps) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  const total = lines.reduce((s, l) => s + l.qty * l.unitPrice, 0);
  const tax = Math.floor(total * 0.10);

  return (
    <div className="requisition-doc" style={docPageStyle}>
      <DocTitle>{locale === 'ja' ? '購　買　稟　議　書（発注書）' : L('requisition')}</DocTitle>

      <div style={{ marginBottom: '6mm', display: 'flex', justifyContent: 'space-between' }}>
        <MetaRow items={[
          { label: '稟議番号', value: requisitionNo },
          { label: '起案日', value: formatJP(requestDate) },
        ]} />
        <ApprovalMatrix approvers={approvers} />
      </div>

      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '4mm', fontSize: '10pt' }}>
        <tbody>
          <tr><th style={{ background: '#eee', padding: '3mm', border: '1px solid #ccc', width: '20%', textAlign: 'left' }}>起案者</th><td style={{ border: '1px solid #ccc', padding: '3mm' }}>{requester.department} / {requester.name}</td></tr>
          <tr><th style={{ background: '#eee', padding: '3mm', border: '1px solid #ccc', textAlign: 'left' }}>購入目的</th><td style={{ border: '1px solid #ccc', padding: '3mm' }}>{purpose}</td></tr>
          {budget && <tr><th style={{ background: '#eee', padding: '3mm', border: '1px solid #ccc', textAlign: 'left' }}>予算科目</th><td style={{ border: '1px solid #ccc', padding: '3mm' }}>{budget.account}{budget.remaining !== undefined && ` (残額: ¥${budget.remaining.toLocaleString()})`}</td></tr>}
          <tr><th style={{ background: '#eee', padding: '3mm', border: '1px solid #ccc', textAlign: 'left' }}>必要日</th><td style={{ border: '1px solid #ccc', padding: '3mm' }}>{formatJP(requiredDate)}</td></tr>
          <tr><th style={{ background: '#eee', padding: '3mm', border: '1px solid #ccc', textAlign: 'left' }}>納入場所</th><td style={{ border: '1px solid #ccc', padding: '3mm' }}>{deliveryLocation}</td></tr>
        </tbody>
      </table>

      <table style={{ width: '100%', borderCollapse: 'collapse', marginBottom: '4mm', fontSize: '10pt' }}>
        <thead>
          <tr style={{ background: '#333', color: 'white' }}>
            <th style={{ padding: '4px' }}>品目・仕様</th>
            <th style={{ padding: '4px' }}>数量</th>
            <th style={{ padding: '4px' }}>単位</th>
            <th style={{ padding: '4px' }}>単価</th>
            <th style={{ padding: '4px' }}>金額</th>
            <th style={{ padding: '4px' }}>取引先候補</th>
            <th style={{ padding: '4px' }}>必要理由</th>
          </tr>
        </thead>
        <tbody>
          {lines.map((l, i) => (
            <tr key={i} style={{ borderBottom: '1px solid #ddd' }}>
              <td style={{ padding: '4px' }}>{l.description}</td>
              <td style={{ padding: '4px', textAlign: 'right' }}>{l.qty}</td>
              <td style={{ padding: '4px' }}>{l.unit ?? ''}</td>
              <td style={{ padding: '4px', textAlign: 'right' }}>¥{l.unitPrice.toLocaleString()}</td>
              <td style={{ padding: '4px', textAlign: 'right' }}>¥{(l.qty * l.unitPrice).toLocaleString()}</td>
              <td style={{ padding: '4px', fontSize: '8pt' }}>{l.supplierCandidate ?? ''}</td>
              <td style={{ padding: '4px', fontSize: '8pt' }}>{l.justification ?? ''}</td>
            </tr>
          ))}
        </tbody>
      </table>

      <div style={{ marginLeft: 'auto', width: '80mm' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>小計</span><span>¥{total.toLocaleString()}</span></div>
        <div style={{ display: 'flex', justifyContent: 'space-between' }}><span>消費税</span><span>¥{tax.toLocaleString()}</span></div>
        <div style={{ display: 'flex', justifyContent: 'space-between', borderTop: '2px solid #333', paddingTop: '4px', fontWeight: 'bold' }}><span>合計</span><span>¥{(total + tax).toLocaleString()}</span></div>
      </div>

      {remarks && <div style={{ marginTop: '6mm', fontSize: '9pt' }}>備考: {remarks}</div>}

      <style>{printStyle}</style>
    </div>
  );
}
