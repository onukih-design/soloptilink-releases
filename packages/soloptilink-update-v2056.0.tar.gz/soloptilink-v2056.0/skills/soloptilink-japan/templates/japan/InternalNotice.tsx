/**
 * 社内通達テンプレート
 * 人事異動・規程改定・緊急連絡等の社内周知
 */
import React from 'react';
import { docPageStyle, printStyle, formatJP } from './_common';
import { t, type Locale } from '../../lib/japan/i18n';

export interface InternalNoticeProps {
  noticeNo: string;                 // 通達番号 (例: 2026-HR-001)
  issuedBy: { department: string; personName?: string };   // 発令部署
  issueDate: Date;
  addressedTo: string;              // 宛先 (例: 全社員各位 / 営業部各位)
  subject: string;                  // 件名
  category?: '人事異動' | '規程改定' | '安全衛生' | '情報セキュリティ' | '緊急連絡' | '業務通達' | 'その他';
  urgency?: 'high' | 'medium' | 'low';
  effectiveDate?: Date;             // 発効日
  body: string;                     // 本文
  actionRequired?: string;           // 必要対応
  contactPerson?: string;            // 問い合わせ先
  relatedDocuments?: string[];
  locale?: Locale;
}

export function InternalNotice({ noticeNo, issuedBy, issueDate, addressedTo, subject, category = '業務通達', urgency = 'medium', effectiveDate, body, actionRequired, contactPerson, relatedDocuments = [], locale = 'ja' }: InternalNoticeProps) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  const urgencyColor = urgency === 'high' ? '#c00' : urgency === 'low' ? '#888' : '#333';
  const urgencyLabel = urgency === 'high' ? '【緊急】' : urgency === 'low' ? '' : '';

  return (
    <div className="internal-notice-doc" style={docPageStyle}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4mm', fontSize: '9pt' }}>
        <div>通達番号: <strong>{noticeNo}</strong></div>
        <div>{formatJP(issueDate)}</div>
      </div>

      <div style={{ fontSize: '11pt', marginBottom: '2mm' }}>{addressedTo}</div>
      <div style={{ textAlign: 'right', fontSize: '10pt', marginBottom: '6mm' }}>
        <div>{issuedBy.department}</div>
        {issuedBy.personName && <div>{issuedBy.personName}</div>}
      </div>

      <div style={{ textAlign: 'center', marginBottom: '4mm' }}>
        <span style={{ display: 'inline-block', padding: '2mm 4mm', background: '#333', color: 'white', fontSize: '9pt', marginRight: '2mm' }}>{category}</span>
        {urgencyLabel && <span style={{ display: 'inline-block', padding: '2mm 4mm', background: urgencyColor, color: 'white', fontSize: '9pt' }}>{urgencyLabel}</span>}
      </div>

      <h2 style={{ textAlign: 'center', fontSize: '16pt', margin: '4mm 0 6mm', padding: '4mm', background: '#f5f5f5', border: `3px solid ${urgencyColor}` }}>
        {subject}
      </h2>

      {effectiveDate && (
        <div style={{ textAlign: 'center', marginBottom: '4mm', padding: '2mm', background: '#fffbe6', border: '1px solid #fd0' }}>
          <strong>発効日: {formatJP(effectiveDate)}</strong>
        </div>
      )}

      <div style={{ padding: '6mm', background: '#fafafa', border: '1px solid #ccc', marginBottom: '6mm', whiteSpace: 'pre-line', lineHeight: '1.8' }}>
        {body}
      </div>

      {actionRequired && (
        <div style={{ padding: '4mm', background: '#e6f7ff', border: '2px solid #0a7', marginBottom: '4mm' }}>
          <strong>必要対応:</strong>
          <div style={{ marginTop: '2mm', whiteSpace: 'pre-line' }}>{actionRequired}</div>
        </div>
      )}

      {relatedDocuments.length > 0 && (
        <div style={{ fontSize: '9pt', marginBottom: '4mm' }}>
          <strong>関連文書:</strong>
          <ul style={{ margin: '2mm 0', paddingLeft: '6mm' }}>
            {relatedDocuments.map((d, i) => <li key={i}>{d}</li>)}
          </ul>
        </div>
      )}

      {contactPerson && (
        <div style={{ marginTop: '6mm', padding: '3mm', background: '#f9f9f9', fontSize: '9pt' }}>
          <strong>本件に関するお問い合わせ:</strong> {contactPerson}
        </div>
      )}

      <div style={{ textAlign: 'center', marginTop: '8mm', fontSize: '10pt' }}>以 上</div>

      <style>{printStyle}</style>
    </div>
  );
}
