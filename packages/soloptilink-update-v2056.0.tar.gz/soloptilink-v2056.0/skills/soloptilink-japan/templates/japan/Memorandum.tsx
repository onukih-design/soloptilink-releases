/**
 * 覚書テンプレート
 * 既存契約の変更・追加・補足を目的とする
 */
import React from 'react';
import { Party, docPageStyle, printStyle, SealStamp } from './_common';
import { formatBoth } from '../../lib/japan/wareki';
import { t, type Locale } from '../../lib/japan/i18n';

export interface MemorandumProps {
  title?: string;                    // 覚書の件名
  partyA: Party & { role?: string };
  partyB: Party & { role?: string };
  executionDate: Date;
  parentContract?: {                 // 紐付く契約書
    title: string;
    executionDate: Date;
  };
  background: string;                 // 背景・経緯
  agreements: string[];               // 合意事項（第1条, 第2条...）
  partyASealUrl?: string;
  partyBSealUrl?: string;
  locale?: Locale;
}

export function Memorandum({ title, partyA, partyB, executionDate, parentContract, background, agreements, partyASealUrl, partyBSealUrl, locale = 'ja' }: MemorandumProps) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  const displayTitle = title || (locale === 'ja' ? '覚書' : L('memorandum'));
  return (
    <div className="memorandum-doc" style={docPageStyle}>
      <h1 style={{ textAlign: 'center', fontSize: '20pt', margin: '0 0 10mm 0', letterSpacing: locale === 'ja' ? '6pt' : '2pt' }}>{displayTitle}</h1>

      <p style={{ marginBottom: '4mm' }}>
        <strong>{partyA.companyName}</strong>（以下「甲」という。）と <strong>{partyB.companyName}</strong>（以下「乙」という。）は、
        {parentContract && `${formatBoth(parentContract.executionDate)}に締結した「${parentContract.title}」（以下「原契約」という。）に関し、`}
        以下のとおり合意した。
      </p>

      <div style={{ marginBottom: '6mm', padding: '3mm', background: '#f9f9f9', border: '1px solid #ccc' }}>
        <strong>背景・経緯</strong>
        <div style={{ marginTop: '2mm', whiteSpace: 'pre-line' }}>{background}</div>
      </div>

      {agreements.map((a, i) => (
        <div key={i} style={{ marginBottom: '4mm' }}>
          <div style={{ fontWeight: 'bold', marginBottom: '2mm' }}>第{i + 1}条</div>
          <div style={{ paddingLeft: '4mm', whiteSpace: 'pre-line' }}>{a}</div>
        </div>
      ))}

      <div style={{ marginTop: '6mm' }}>
        <p>本覚書に定めのない事項については{parentContract ? '原契約' : '別途甲乙協議の上'}決定する。</p>
        <p>本覚書の成立を証するため、本書2通を作成し、甲乙各自記名押印の上、各1通を保有する。</p>
      </div>

      <div style={{ textAlign: 'right', margin: '6mm 0' }}>{formatBoth(executionDate)}</div>

      <div style={{ display: 'flex', gap: '8mm', marginTop: '6mm' }}>
        {[{ party: partyA, seal: partyASealUrl, label: '甲' }, { party: partyB, seal: partyBSealUrl, label: '乙' }].map((p, i) => (
          <div key={i} style={{ flex: 1, padding: '3mm', border: '1px solid #666' }}>
            <div style={{ fontSize: '11pt' }}>{p.label}: </div>
            <div style={{ fontSize: '9pt' }}>{p.party.postalCode && `〒${p.party.postalCode}`}</div>
            <div style={{ fontSize: '9pt' }}>{p.party.address}</div>
            <div style={{ fontSize: '11pt', fontWeight: 'bold', marginTop: '2mm' }}>{p.party.companyName}</div>
            {p.party.personName && <div style={{ fontSize: '10pt' }}>{p.party.personName} {p.party.title ?? ''}</div>}
            <div style={{ textAlign: 'right', marginTop: '4mm' }}>
              {p.seal ? <img src={p.seal} alt="印" style={{ width: '18mm', height: '18mm' }} /> : <SealStamp label="印" size={18} />}
            </div>
          </div>
        ))}
      </div>

      <style>{printStyle}</style>
    </div>
  );
}
