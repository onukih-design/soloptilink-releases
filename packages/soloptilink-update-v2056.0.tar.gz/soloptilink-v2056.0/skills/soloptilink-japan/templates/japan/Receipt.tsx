/**
 * 領収書テンプレート (印紙税対応・Phase 5 i18n統合版)
 * 5万円以上は印紙貼付欄表示、ja/en/zh-CN 対応
 */
import React from 'react';
import { formatBoth } from '../../lib/japan/wareki';
import type { TaxRate } from '../../lib/japan/tax';
import { t, type Locale } from '../../lib/japan/i18n';

export interface ReceiptProps {
  issuer: { companyName: string; registrationNumber?: string; postalCode: string; address: string; phone: string };
  recipient: string;                   // ○○様
  receiptNo: string;
  issueDate: Date;
  amount: number;                      // 税込金額
  taxBreakdown?: { rate: TaxRate; amount: number }[]; // 内訳
  purpose: string;                     // 但し書き
  paymentMethod?: 'cash' | 'transfer' | 'card' | 'other';
  sealDataUrl?: string;
  remarks?: string;
}

/**
 * 印紙税額表 第17号文書 (売上代金に係る金銭又は有価証券の受取書)
 *
 * ★正典 (SoT): 本体 lib/japan/eseal.ts の STAMP_TAX_DOC17_BRACKETS /
 *   STAMP_TAX_DOC17_NON_TAXABLE_UNDER。数値の一次情報は
 *   lib/japan/legal-values/approval-workflow.legal.json に
 *   国税庁 タックスアンサー No.7141 の出典付きで保持されている。
 *
 * ★なぜ import せず「転記」しているか:
 *   本テンプレートは顧客プロジェクトへ丸ごとコピーされる独立ファイルであり、
 *   本体 lib への import は移送先で解決できない。やむを得ず転記している。
 *   転記である以上ドリフトが起こりうるので、SoT / 法定値との一致は
 *   lib/japan/_verify/stamp-templates.verify.mjs (STPL レーン) が常時実走で突合する。
 *   ★この表を直すときは必ず SoT を先に直し、STPL レーンを通すこと。
 *
 * ★引き方: 「上端 (この金額まで)」と税額の組で持ち、amountYen <= upperJpy で引く。
 *   法令は「○○円以下」なので、`< max` で引くと階段が1段ずれる
 *   (例: ちょうど100万円が400円になる。正は200円)。
 */
export const STAMP_DUTY_DOC17_BRACKETS: ReadonlyArray<{ upperJpy: number | null; taxJpy: number }> = [
  { upperJpy: 1_000_000, taxJpy: 200 },
  { upperJpy: 2_000_000, taxJpy: 400 },
  { upperJpy: 3_000_000, taxJpy: 600 },
  { upperJpy: 5_000_000, taxJpy: 1_000 },
  { upperJpy: 10_000_000, taxJpy: 2_000 },
  { upperJpy: 20_000_000, taxJpy: 4_000 },
  { upperJpy: 30_000_000, taxJpy: 6_000 },
  { upperJpy: 50_000_000, taxJpy: 10_000 },
  { upperJpy: 100_000_000, taxJpy: 20_000 },
  { upperJpy: 200_000_000, taxJpy: 40_000 },
  { upperJpy: 300_000_000, taxJpy: 60_000 },
  { upperJpy: 500_000_000, taxJpy: 100_000 },
  { upperJpy: 1_000_000_000, taxJpy: 150_000 },
  { upperJpy: null, taxJpy: 200_000 },
];

/** 5万円未満は非課税 (第17号文書)。国税庁 No.7141。 */
export const STAMP_DUTY_DOC17_NON_TAXABLE_UNDER = 50_000;

/**
 * 受取金額 (円) から第17号文書の印紙税額を求める。
 *
 * ★印紙税の不足は過怠税 (不足額とその2倍に相当する金額の合計 = 本税の3倍) の対象。
 *   「安く出る」ことは安全側ではないため、上位の階段を頭打ちにしてはならない。
 */
export function calcStampDuty(amountYen: number): number {
  if (!Number.isFinite(amountYen) || amountYen < STAMP_DUTY_DOC17_NON_TAXABLE_UNDER) return 0;
  for (const b of STAMP_DUTY_DOC17_BRACKETS) {
    if (b.upperJpy === null || amountYen <= b.upperJpy) return b.taxJpy;
  }
  return STAMP_DUTY_DOC17_BRACKETS[STAMP_DUTY_DOC17_BRACKETS.length - 1].taxJpy;
}

export function Receipt({ issuer, recipient, receiptNo, issueDate, amount, taxBreakdown, purpose, paymentMethod = 'cash', sealDataUrl, remarks, locale = 'ja' }: ReceiptProps & { locale?: Locale }) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  const stampDuty = calcStampDuty(amount);

  return (
    <div className="receipt-doc" style={{ width: '148mm', minHeight: '105mm', padding: '10mm', fontFamily: "'Noto Sans JP', sans-serif", background: 'white', fontSize: '10pt', color: '#222', border: '2px solid #222' }}>
      <h1 style={{ textAlign: 'center', fontSize: '18pt', letterSpacing: locale === 'ja' ? '8pt' : '2pt', margin: '0 0 6mm 0' }}>{locale === 'ja' ? '領　収　書' : L('receipt')}</h1>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4mm', fontSize: '9pt' }}>
        <div>No. {receiptNo}</div>
        <div>{formatBoth(issueDate)}</div>
      </div>

      <div style={{ fontSize: '12pt', marginBottom: '4mm' }}>
        {recipient} 様
      </div>

      {/* 金額 */}
      <div style={{ background: '#f5f5f5', padding: '4mm', textAlign: 'center', marginBottom: '4mm', border: '2px solid #333' }}>
        <div style={{ fontSize: '20pt', fontWeight: 'bold' }}>¥{amount.toLocaleString()}-</div>
      </div>

      <div style={{ fontSize: '10pt', marginBottom: '4mm' }}>
        但し、<strong>{purpose}</strong> として 上記の金額を正に領収いたしました。
      </div>

      {/* 税額内訳 (インボイス対応) */}
      {taxBreakdown && taxBreakdown.length > 0 && (
        <div style={{ fontSize: '8pt', background: '#fafafa', padding: '2mm', marginBottom: '4mm', border: '1px solid #ddd' }}>
          <strong>税率別内訳:</strong>
          {taxBreakdown.map((t, i) => (
            <span key={i} style={{ marginLeft: '4mm' }}>
              {t.rate === 'standard' ? '10%' : t.rate === 'reduced' ? '8%' : t.rate}: ¥{t.amount.toLocaleString()}
            </span>
          ))}
        </div>
      )}

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
        <div style={{ fontSize: '8pt' }}>
          <div>支払方法: {paymentMethod === 'cash' ? '現金' : paymentMethod === 'transfer' ? '振込' : paymentMethod === 'card' ? 'クレジットカード' : 'その他'}</div>
          {stampDuty > 0 && (
            <div style={{ marginTop: '2mm', border: '1px dashed #c00', padding: '2mm', color: '#c00' }}>
              ※印紙 ¥{stampDuty.toLocaleString()} 貼付欄 (5万円以上)
            </div>
          )}
        </div>
        <div style={{ textAlign: 'right', position: 'relative' }}>
          <div style={{ fontWeight: 'bold' }}>{issuer.companyName}</div>
          {issuer.registrationNumber && <div style={{ fontSize: '8pt' }}>登録番号: {issuer.registrationNumber}</div>}
          <div style={{ fontSize: '8pt' }}>〒{issuer.postalCode} {issuer.address}</div>
          <div style={{ fontSize: '8pt' }}>TEL: {issuer.phone}</div>
          {sealDataUrl && <img src={sealDataUrl} alt="印影" style={{ position: 'absolute', top: '-4mm', right: '-4mm', width: '18mm', height: '18mm' }} />}
        </div>
      </div>

      {remarks && <div style={{ marginTop: '4mm', fontSize: '8pt', color: '#555' }}>{remarks}</div>}

      <style>{`@media print { @page { size: A5; margin: 0; } }`}</style>
    </div>
  );
}
