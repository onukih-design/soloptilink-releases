/**
 * 秘密保持契約書（NDA）テンプレート
 */
import React from 'react';
import { Contract, ContractProps } from './Contract';
import { t, type Locale } from '../../lib/japan/i18n';

type NDAProps = Omit<ContractProps, 'title' | 'clauses'> & {
  purpose: string;                 // 開示目的
  periodYears: number;             // 秘密保持期間（年）
  additionalClauses?: ContractProps['clauses'];
  locale?: Locale;
};

export function NDA({ purpose, periodYears, additionalClauses = [], locale = 'ja', ...rest }: NDAProps) {
  const title = locale === 'ja' ? '秘密保持契約書（NDA）' : t('nda', locale);
  const clauses: ContractProps['clauses'] = [
    {
      title: '秘密情報',
      body: `本契約において「秘密情報」とは、甲乙が相互に開示する一切の情報であって、書面、電磁的記録、口頭その他の方法によって開示され、かつ秘密である旨が明示されたもの、または合理的に秘密と認識されるものをいう。`,
    },
    {
      title: '目的外使用の禁止',
      body: `甲乙は、相手方から開示された秘密情報を、「${purpose}」の目的（以下「本目的」という。）以外に使用してはならない。`,
    },
    {
      title: '第三者への開示禁止',
      body: `甲乙は、相手方の事前の書面による同意なく、秘密情報を第三者に開示、漏洩、公表してはならない。ただし、本目的の遂行に必要な役員及び従業員であって、本契約と同等以上の秘密保持義務を負う者に限り、必要な範囲で開示できる。`,
    },
    {
      title: '複製の制限',
      body: `甲乙は、本目的に必要な範囲を超えて秘密情報を複製してはならない。複製物についても、原本と同等の秘密保持義務を負う。`,
    },
    {
      title: '契約終了時の措置',
      body: `本契約が終了した場合、又は相手方から要求があった場合、甲乙は秘密情報及びその複製物を相手方に返還又は破棄し、破棄した場合はその旨を書面で証明する。`,
    },
    {
      title: '有効期間',
      body: `本契約の有効期間は締結日より${periodYears}年間とし、期間終了後も本契約に基づく秘密保持義務は${periodYears}年間存続する。`,
    },
    {
      title: '損害賠償',
      body: `本契約に違反した当事者は、相手方に生じた損害（逸失利益・弁護士費用を含む）を賠償する責任を負う。`,
    },
    ...additionalClauses,
  ];

  return <Contract title={title} clauses={clauses} locale={locale} {...rest} />;
}
