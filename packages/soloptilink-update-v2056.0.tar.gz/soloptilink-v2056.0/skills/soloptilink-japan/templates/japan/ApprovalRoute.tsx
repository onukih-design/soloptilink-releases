/**
 * templates/japan/ApprovalRoute.tsx — 稟議書・承認経路表 (v2.0 Phase 5)
 *
 * 日本企業の標準稟議書レイアウト。金額別・業種別の承認経路を可視化。
 * `lib/japan/workflow_engine.ts` の ApprovalRoute / ApprovalRequest を描画。
 *
 * 使用例:
 *   <ApprovalRoute route={route} request={request} locale="ja" />
 */
import React from "react";

export type Locale = "ja" | "en" | "zh-CN";

interface ApprovalNodeView {
  id: string;
  label: string;
  position: string;
  required: boolean;
  parallel?: boolean;
  escalationDays?: number;
}

interface ApprovalActionView {
  nodeId: string;
  actorName: string;
  action: "approve" | "reject" | "return" | "delegate" | "pending";
  comment?: string;
  actedAt?: string;
}

export interface ApprovalRouteProps {
  routeName: string;
  requester: { id: string; name: string; department?: string };
  subject: string;
  amount?: number;
  currency?: "JPY" | "USD" | "EUR" | "CNY";
  nodes: ApprovalNodeView[];
  actions: ApprovalActionView[];
  submittedAt: string;
  status: "draft" | "in_review" | "approved" | "rejected" | "returned";
  locale?: Locale;
  showStamps?: boolean;
}

const LABELS = {
  ja: {
    title: "稟議書",
    subjectLabel: "件名",
    requesterLabel: "起案者",
    departmentLabel: "所属",
    amountLabel: "金額",
    dateLabel: "起案日",
    statusLabel: "状態",
    routeHeading: "承認経路",
    actionHeading: "承認履歴",
    statusMap: {
      draft: "下書き",
      in_review: "審査中",
      approved: "承認済",
      rejected: "否認",
      returned: "差戻し",
    },
    actionMap: {
      approve: "承認",
      reject: "否認",
      return: "差戻",
      delegate: "代理",
      pending: "未決",
    },
    sealLabel: "印",
  },
  en: {
    title: "Approval Request",
    subjectLabel: "Subject",
    requesterLabel: "Requester",
    departmentLabel: "Department",
    amountLabel: "Amount",
    dateLabel: "Submitted",
    statusLabel: "Status",
    routeHeading: "Approval Route",
    actionHeading: "History",
    statusMap: {
      draft: "Draft",
      in_review: "In Review",
      approved: "Approved",
      rejected: "Rejected",
      returned: "Returned",
    },
    actionMap: {
      approve: "Approved",
      reject: "Rejected",
      return: "Returned",
      delegate: "Delegated",
      pending: "Pending",
    },
    sealLabel: "Seal",
  },
  "zh-CN": {
    title: "审批申请",
    subjectLabel: "事由",
    requesterLabel: "申请人",
    departmentLabel: "部门",
    amountLabel: "金额",
    dateLabel: "申请日",
    statusLabel: "状态",
    routeHeading: "审批路径",
    actionHeading: "审批记录",
    statusMap: {
      draft: "草稿",
      in_review: "审批中",
      approved: "已批准",
      rejected: "已驳回",
      returned: "退回",
    },
    actionMap: {
      approve: "批准",
      reject: "驳回",
      return: "退回",
      delegate: "代批",
      pending: "待处理",
    },
    sealLabel: "印",
  },
} as const;

function formatAmount(value: number, currency: "JPY" | "USD" | "EUR" | "CNY"): string {
  const formatter = new Intl.NumberFormat(
    currency === "JPY" ? "ja-JP" : currency === "CNY" ? "zh-CN" : "en-US",
    {
      style: "currency",
      currency,
      maximumFractionDigits: currency === "JPY" ? 0 : 2,
    },
  );
  return formatter.format(value);
}

export const ApprovalRoute: React.FC<ApprovalRouteProps> = ({
  routeName,
  requester,
  subject,
  amount,
  currency = "JPY",
  nodes,
  actions,
  submittedAt,
  status,
  locale = "ja",
  showStamps = true,
}) => {
  const t = LABELS[locale];
  return (
    <div
      className="approval-route"
      style={{
        width: "210mm",
        minHeight: "297mm",
        padding: "20mm",
        fontFamily: "'Noto Sans JP', 'Hiragino Sans', sans-serif",
        fontSize: "12px",
        color: "#111",
        background: "#fff",
      }}
    >
      <header style={{ textAlign: "center", marginBottom: "12mm" }}>
        <h1 style={{ fontSize: "22px", fontWeight: 700, letterSpacing: "0.2em", margin: 0 }}>
          {t.title}
        </h1>
        <div style={{ fontSize: "14px", marginTop: "4px" }}>{routeName}</div>
      </header>

      <section style={{ marginBottom: "8mm" }}>
        <table style={{ width: "100%", borderCollapse: "collapse", border: "1px solid #444" }}>
          <tbody>
            <tr>
              <th style={cellHead}>{t.subjectLabel}</th>
              <td style={cellBody} colSpan={3}>
                {subject}
              </td>
            </tr>
            <tr>
              <th style={cellHead}>{t.requesterLabel}</th>
              <td style={cellBody}>{requester.name}</td>
              <th style={cellHead}>{t.departmentLabel}</th>
              <td style={cellBody}>{requester.department ?? "-"}</td>
            </tr>
            <tr>
              <th style={cellHead}>{t.dateLabel}</th>
              <td style={cellBody}>{submittedAt}</td>
              <th style={cellHead}>{t.statusLabel}</th>
              <td style={cellBody}>{t.statusMap[status]}</td>
            </tr>
            {typeof amount === "number" && (
              <tr>
                <th style={cellHead}>{t.amountLabel}</th>
                <td style={cellBody} colSpan={3}>
                  {formatAmount(amount, currency)}
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </section>

      <section style={{ marginBottom: "8mm" }}>
        <h2 style={{ fontSize: "16px", margin: "0 0 6px", borderBottom: "2px solid #111" }}>
          {t.routeHeading}
        </h2>
        <table style={{ width: "100%", borderCollapse: "collapse", border: "1px solid #444" }}>
          <thead>
            <tr>
              <th style={cellHead}>#</th>
              <th style={cellHead}>{locale === "ja" ? "承認者" : locale === "en" ? "Approver" : "审批人"}</th>
              <th style={cellHead}>{locale === "ja" ? "役職" : locale === "en" ? "Position" : "职位"}</th>
              <th style={cellHead}>{locale === "ja" ? "必須" : locale === "en" ? "Required" : "必选"}</th>
              {showStamps && <th style={cellHead}>{t.sealLabel}</th>}
            </tr>
          </thead>
          <tbody>
            {nodes.map((n, i) => {
              const action = actions.find((a) => a.nodeId === n.id);
              return (
                <tr key={n.id}>
                  <td style={{ ...cellBody, textAlign: "center" }}>{i + 1}</td>
                  <td style={cellBody}>{n.label}</td>
                  <td style={cellBody}>{n.position}</td>
                  <td style={{ ...cellBody, textAlign: "center" }}>{n.required ? "◎" : "○"}</td>
                  {showStamps && (
                    <td style={{ ...cellBody, height: "18mm", textAlign: "center", verticalAlign: "middle" }}>
                      {action && action.action === "approve" ? (
                        <div
                          style={{
                            display: "inline-block",
                            width: "14mm",
                            height: "14mm",
                            lineHeight: "14mm",
                            borderRadius: "50%",
                            border: "2px solid #c00",
                            color: "#c00",
                            fontSize: "10px",
                          }}
                        >
                          {action.actorName.slice(0, 2)}
                        </div>
                      ) : (
                        <span style={{ color: "#999" }}>-</span>
                      )}
                    </td>
                  )}
                </tr>
              );
            })}
          </tbody>
        </table>
      </section>

      {actions.length > 0 && (
        <section>
          <h2 style={{ fontSize: "16px", margin: "0 0 6px", borderBottom: "2px solid #111" }}>
            {t.actionHeading}
          </h2>
          <table style={{ width: "100%", borderCollapse: "collapse", border: "1px solid #444" }}>
            <thead>
              <tr>
                <th style={cellHead}>{locale === "ja" ? "日時" : locale === "en" ? "Date/Time" : "日期"}</th>
                <th style={cellHead}>{locale === "ja" ? "承認者" : locale === "en" ? "Actor" : "审批人"}</th>
                <th style={cellHead}>{locale === "ja" ? "アクション" : locale === "en" ? "Action" : "动作"}</th>
                <th style={cellHead}>{locale === "ja" ? "コメント" : locale === "en" ? "Comment" : "意见"}</th>
              </tr>
            </thead>
            <tbody>
              {actions.map((a, i) => (
                <tr key={i}>
                  <td style={cellBody}>{a.actedAt ?? "-"}</td>
                  <td style={cellBody}>{a.actorName}</td>
                  <td style={cellBody}>{t.actionMap[a.action]}</td>
                  <td style={cellBody}>{a.comment ?? ""}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      )}
    </div>
  );
};

const cellHead: React.CSSProperties = {
  border: "1px solid #444",
  padding: "4mm",
  background: "#f0f0f0",
  textAlign: "left",
  fontWeight: 700,
  whiteSpace: "nowrap",
};

const cellBody: React.CSSProperties = {
  border: "1px solid #444",
  padding: "4mm",
  verticalAlign: "top",
};

export default ApprovalRoute;
