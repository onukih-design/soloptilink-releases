/**
 * 業務委託契約書テンプレート
 * 下請法該当時の必須記載事項も含める
 */
import React from 'react';
import { Contract, ContractProps } from './Contract';
import { t, type Locale } from '../../lib/japan/i18n';

type ServiceAgreementProps = Omit<ContractProps, 'title' | 'clauses'> & {
  serviceDescription: string;    // 委託業務内容
  fee: number;                   // 委託料（税抜）
  paymentSchedule: string;       // 支払スケジュール
  deliveryLocation?: string;     // 納入場所
  deliveryDate?: string;         // 納入期日
  isSubcontracting?: boolean;    // 下請法対象
  additionalClauses?: ContractProps['clauses'];
  locale?: Locale;
};

export function ServiceAgreement({ serviceDescription, fee, paymentSchedule, deliveryLocation, deliveryDate, isSubcontracting, additionalClauses = [], locale = 'ja', ...rest }: ServiceAgreementProps) {
  const title = locale === 'ja' ? '業務委託契約書' : t('service_agreement', locale);
  const tax = Math.floor(fee * 0.10);

  const clauses: ContractProps['clauses'] = [
    {
      title: '業務内容',
      body: `甲は乙に対し、次の業務（以下「本業務」という。）を委託し、乙はこれを受託する。\n\n${serviceDescription}`,
    },
    {
      title: '委託料',
      body: `本業務の委託料は、金 ¥${fee.toLocaleString()}（税抜）＋消費税 ¥${tax.toLocaleString()} の合計 ¥${(fee + tax).toLocaleString()} とする。`,
    },
    {
      title: '支払方法',
      body: `甲は乙に対し、${paymentSchedule} に基づき委託料を支払う。振込手数料は甲の負担とする。`,
    },
    ...(deliveryLocation || deliveryDate ? [{
      title: '納入',
      body: `${deliveryLocation ? `納入場所: ${deliveryLocation}\n` : ''}${deliveryDate ? `納入期日: ${deliveryDate}` : ''}`,
    }] : []),
    {
      title: '再委託の制限',
      body: `乙は、甲の事前の書面による承諾なく、本業務の全部又は一部を第三者に再委託してはならない。`,
    },
    {
      title: '成果物の権利帰属',
      body: `本業務の遂行により生じた成果物に関する知的財産権（著作権を含む。）は、甲の検収完了及び委託料の支払と引換に乙から甲に移転する。乙は甲に対し、著作者人格権を行使しない。`,
    },
    {
      title: '秘密保持',
      body: `甲乙は、本契約に関連して知り得た相手方の秘密情報を、本契約の目的以外に使用せず、第三者に開示しない。この義務は本契約終了後も3年間存続する。`,
    },
    {
      title: '契約不適合責任',
      body: `成果物に契約不適合があった場合、甲は乙に対し、検収完了から1年以内に限り、修補・代金減額・損害賠償・契約解除を請求できる。`,
    },
    {
      title: '反社会的勢力の排除',
      body: `甲乙は、自己及び自己の役員・従業員が暴力団、暴力団員、その他反社会的勢力に該当しないことを表明し、これに違反した場合、相手方は本契約を無催告解除できる。`,
    },
    ...(isSubcontracting ? [{
      title: '下請法に関する特則',
      body: `本契約は下請代金支払遅延等防止法の対象取引に該当する。甲は同法第3条の書面交付義務、同法第5条の書類作成保存義務を履行する。代金支払は成果物受領後60日以内に行う。`,
    }] : []),
    ...additionalClauses,
  ];

  return <Contract title={title} clauses={clauses} locale={locale} {...rest} />;
}
