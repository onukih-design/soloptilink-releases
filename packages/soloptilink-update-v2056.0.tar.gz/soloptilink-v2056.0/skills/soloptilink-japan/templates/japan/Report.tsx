/**
 * 報告書テンプレート (汎用)
 * 出張報告/業務報告/月次レポート等
 */
import React from 'react';
import { docPageStyle, printStyle, formatJP, ApprovalMatrix } from './_common';
import { t, type Locale } from '../../lib/japan/i18n';

export interface ReportSection {
  heading: string;
  body: string;
  bullets?: string[];
}

export interface ReportProps {
  reportType: string;              // 例: 出張報告書 / 月次業務報告
  reportNo?: string;
  reporter: { name: string; department: string };
  reportDate: Date;
  period?: { from: Date; to: Date };
  subject: string;
  summary?: string;                 // 要約
  sections: ReportSection[];        // 本文セクション
  conclusions?: string[];           // 結論・所見
  nextActions?: string[];           // 次アクション
  attachments?: string[];
  approvers?: Array<{ role: string; name?: string }>;
  locale?: Locale;
}

export function Report({ reportType, reportNo, reporter, reportDate, period, subject, summary, sections, conclusions = [], nextActions = [], attachments = [], approvers = [], locale = 'ja' }: ReportProps) {
  const L = (key: Parameters<typeof t>[0]) => t(key, locale);
  const typeLabel = locale === 'ja' ? reportType : reportType || L('report');
  return (
    <div className="report-doc" style={docPageStyle}>
      <h1 style={{ textAlign: 'center', fontSize: '20pt', margin: '0 0 6mm 0' }}>{typeLabel}</h1>

      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '4mm' }}>
        <div style={{ fontSize: '10pt' }}>
          {reportNo && <>報告書番号: {reportNo}<br /></>}
          報告日: {formatJP(reportDate)}<br />
          報告者: {reporter.department} / {reporter.name}
          {period && <div>対象期間: {formatJP(period.from)} 〜 {formatJP(period.to)}</div>}
        </div>
        {approvers.length > 0 && <ApprovalMatrix approvers={approvers} />}
      </div>

      <h2 style={{ fontSize: '14pt', padding: '3mm', background: '#333', color: 'white', margin: '6mm 0 3mm' }}>件名: {subject}</h2>

      {summary && (
        <div style={{ padding: '4mm', background: '#f5f5f5', border: '1px solid #ccc', marginBottom: '6mm' }}>
          <strong>要約:</strong>
          <div style={{ marginTop: '2mm', whiteSpace: 'pre-line' }}>{summary}</div>
        </div>
      )}

      {sections.map((s, i) => (
        <div key={i} style={{ marginBottom: '5mm' }}>
          <h3 style={{ fontSize: '12pt', borderLeft: '4px solid #333', paddingLeft: '3mm', marginBottom: '2mm' }}>{i + 1}. {s.heading}</h3>
          <div style={{ paddingLeft: '6mm', whiteSpace: 'pre-line', textAlign: 'justify' }}>{s.body}</div>
          {s.bullets && s.bullets.length > 0 && (
            <ul style={{ paddingLeft: '12mm', margin: '2mm 0' }}>
              {s.bullets.map((b, j) => <li key={j}>{b}</li>)}
            </ul>
          )}
        </div>
      ))}

      {conclusions.length > 0 && (
        <div style={{ marginTop: '6mm', padding: '4mm', background: '#fffbe6', border: '1px solid #fd0' }}>
          <strong>結論・所見:</strong>
          <ul style={{ margin: '2mm 0', paddingLeft: '6mm' }}>
            {conclusions.map((c, i) => <li key={i}>{c}</li>)}
          </ul>
        </div>
      )}

      {nextActions.length > 0 && (
        <div style={{ marginTop: '4mm', padding: '4mm', background: '#e6f7ff', border: '1px solid #0a7' }}>
          <strong>次アクション:</strong>
          <ul style={{ margin: '2mm 0', paddingLeft: '6mm' }}>
            {nextActions.map((a, i) => <li key={i}>{a}</li>)}
          </ul>
        </div>
      )}

      {attachments.length > 0 && (
        <div style={{ marginTop: '4mm', fontSize: '9pt' }}>
          <strong>添付資料:</strong> {attachments.join(' / ')}
        </div>
      )}

      <style>{printStyle}</style>
    </div>
  );
}
