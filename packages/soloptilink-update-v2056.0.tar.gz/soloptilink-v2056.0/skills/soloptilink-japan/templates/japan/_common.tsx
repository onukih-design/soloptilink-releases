/**
 * 帳票共通コンポーネント
 * - 発行者/宛先ヘッダー
 * - 印影配置
 * - A4印刷最適化ラッパー
 */
import React from 'react';
import { formatBoth } from '../../lib/japan/wareki';

export interface Party {
  companyName: string;
  personName?: string;
  title?: string;
  registrationNumber?: string;
  postalCode?: string;
  address?: string;
  phone?: string;
  email?: string;
}

export const docPageStyle: React.CSSProperties = {
  width: '210mm',
  minHeight: '297mm',
  padding: '20mm',
  fontFamily: "'Noto Sans JP', 'Hiragino Sans', sans-serif",
  background: 'white',
  color: '#222',
  fontSize: '10pt',
};

export function DocTitle({ children, letterSpacing = '16pt' }: { children: React.ReactNode; letterSpacing?: string }) {
  return (
    <h1 style={{ textAlign: 'center', fontSize: '24pt', letterSpacing, margin: '0 0 16mm 0' }}>{children}</h1>
  );
}

export function PartyBlock({ party, honorific = '御中' }: { party: Party; honorific?: string }) {
  return (
    <div style={{ fontSize: '14pt', borderBottom: '1px solid #222', paddingBottom: '4px', marginBottom: '4mm' }}>
      {party.companyName} {honorific}
      {party.personName && <div style={{ fontSize: '10pt', marginTop: '2mm' }}>{party.personName} {party.title ?? '様'}</div>}
    </div>
  );
}

export function IssuerBlock({ party, sealDataUrl }: { party: Party; sealDataUrl?: string }) {
  return (
    <div style={{ textAlign: 'right', position: 'relative' }}>
      <div style={{ fontWeight: 'bold', fontSize: '12pt' }}>{party.companyName}</div>
      {party.registrationNumber && <div style={{ fontSize: '9pt' }}>登録番号: {party.registrationNumber}</div>}
      {party.postalCode && party.address && <div style={{ fontSize: '9pt' }}>〒{party.postalCode} {party.address}</div>}
      {party.phone && <div style={{ fontSize: '9pt' }}>TEL: {party.phone}{party.email && ` / ${party.email}`}</div>}
      {sealDataUrl && (
        <img src={sealDataUrl} alt="印影" style={{ position: 'absolute', top: '10mm', right: '5mm', width: '20mm', height: '20mm', objectFit: 'contain' }} />
      )}
    </div>
  );
}

export function MetaRow({ items }: { items: Array<{ label: string; value: string }> }) {
  return (
    <div style={{ display: 'flex', gap: '8mm', marginBottom: '6mm', fontSize: '10pt' }}>
      {items.map((it, i) => <div key={i}>{it.label}: {it.value}</div>)}
    </div>
  );
}

export function formatJP(d: Date): string {
  return formatBoth(d);
}

export const printStyle = `@media print { @page { size: A4; margin: 0; } }`;

export function SealStamp({ label = '印', size = 22 }: { label?: string; size?: number }) {
  const mm = `${size}mm`;
  return (
    <div style={{
      width: mm, height: mm, border: '3px solid #c53030', color: '#c53030',
      borderRadius: '50%', display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      fontFamily: 'serif', fontSize: `${size * 0.5}pt`,
    }}>{label}</div>
  );
}

export function ApprovalMatrix({ approvers }: { approvers: Array<{ role: string; name?: string }> }) {
  return (
    <table style={{ marginLeft: 'auto', borderCollapse: 'collapse', fontSize: '9pt' }}>
      <tbody>
        <tr>
          {approvers.map((a, i) => (
            <td key={i} style={{ border: '1px solid #666', width: '18mm', height: '18mm', textAlign: 'center', verticalAlign: 'top', padding: '1mm' }}>
              <div>{a.role}</div>
              <div style={{ marginTop: '2mm', color: '#888' }}>{a.name ?? ''}</div>
            </td>
          ))}
        </tr>
      </tbody>
    </table>
  );
}
