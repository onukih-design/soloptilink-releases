/**
 * Runbookテンプレート (印刷可能な .pdf 出力想定)
 *
 * 責務:
 *   オンコールエンジニアが現場で参照することを想定した縦書き型レイアウト。
 *   SEV分類表 / Mermaidフロー / シナリオ別チェックリスト / 連絡先のクイックリファレンスを
 *   1ページ1シナリオで折り返し表示する想定。
 */

import type { Runbook } from '../lib/runbook_generator';

export interface RunbookTemplateProps {
  runbook: Runbook;
  locale?: 'ja' | 'en';
}

export function RunbookTemplate({ runbook, locale = 'ja' }: RunbookTemplateProps): JSX.Element {
  return (
    <article className="runbook" lang={locale}>
      <header>
        <h1>障害対応Runbook - {runbook.meta.system_name}</h1>
        <small>v{runbook.meta.version} / {runbook.meta.generated_at.slice(0, 10)}</small>
      </header>
      <SeverityTable severity={runbook.severity_table} />
      <FlowChart mermaid={runbook.mermaid_flowchart} />
      {runbook.scenarios.map((s) => (
        <section key={s.scenario_id} className="scenario page-break">
          <h2>{s.title_ja}</h2>
          <p>
            <strong>デフォルトSeverity</strong>: {s.default_severity} /
            <strong> ポストモーテム</strong>: {s.postmortem_required ? '必須' : '任意'}
          </p>
          <h3>検知方法</h3>
          <ul>
            {s.detection.map((d, i) => <li key={i}>{d}</li>)}
          </ul>
          <h3>一次対応</h3>
          <ol>
            {s.primary_response.map((d, i) => <li key={i}>{d}</li>)}
          </ol>
          <h3>二次対応</h3>
          <ol>
            {s.secondary_response.map((d, i) => <li key={i}>{d}</li>)}
          </ol>
          <h3>エスカレーション</h3>
          <ul>
            {s.escalation.map((d, i) => <li key={i}>{d}</li>)}
          </ul>
          <h3>復旧確認</h3>
          <ul>
            {s.recovery_check.map((d, i) => <li key={i}>{d}</li>)}
          </ul>
          <p className="metrics">
            関連メトリクス: <code>{s.related_metrics.join(', ')}</code>
          </p>
        </section>
      ))}
      <ContactCard contacts={runbook.contacts} />
    </article>
  );
}

function SeverityTable({ severity }: { severity: Runbook['severity_table'] }): JSX.Element {
  return (
    <table className="severity-table">
      <thead>
        <tr>
          <th>Level</th>
          <th>判定基準</th>
          <th>応答SLA (分)</th>
          <th>復旧目標 (分)</th>
          <th>ポストモーテム</th>
        </tr>
      </thead>
      <tbody>
        {severity.map((s) => (
          <tr key={s.level}>
            <td>{s.level}</td>
            <td>{s.criteria_ja}</td>
            <td>{s.response_sla_min}</td>
            <td>{s.recovery_target_min}</td>
            <td>{s.postmortem_required ? '必須' : '任意'}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}

function FlowChart({ mermaid }: { mermaid: string }): JSX.Element {
  return (
    <section className="flowchart">
      <h2>エスカレーションフロー</h2>
      <pre className="mermaid">{mermaid}</pre>
    </section>
  );
}

function ContactCard({ contacts }: { contacts: Runbook['contacts'] }): JSX.Element {
  return (
    <section className="contacts">
      <h2>クイック連絡先</h2>
      <ul>
        <li>Primary: {contacts.primary.name} ({contacts.primary.phone ?? '-'})</li>
        <li>Secondary: {contacts.secondary.name} ({contacts.secondary.phone ?? '-'})</li>
        <li>Manager: {contacts.manager_escalation.name}</li>
        <li>Vendor: {contacts.vendor_support.name}</li>
      </ul>
    </section>
  );
}
