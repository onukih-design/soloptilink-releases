/**
 * SLAテンプレート (.docx別紙想定)
 *
 * 責務:
 *   契約書の別紙として綴じる前提で、可用性・応答時間SLA・サービスクレジット・
 *   エラーバジェット・除外事項・計測方法・レポーティングを表形式で示す。
 */

import type { Sla } from '../lib/sla_generator';

export interface SlaTemplateProps {
  sla: Sla;
  vendor_name: string;
  client_name: string;
  locale?: 'ja' | 'en';
}

export function SlaTemplate({ sla, vendor_name, client_name, locale = 'ja' }: SlaTemplateProps): JSX.Element {
  return (
    <article className="sla" lang={locale}>
      <header>
        <h1>サービスレベル合意書 (SLA) - {sla.meta.system_name}</h1>
        <p>
          発行: {vendor_name} 宛: {client_name} 発行日: {sla.meta.generated_at.slice(0, 10)} v{sla.meta.version}
        </p>
      </header>

      <section className="availability">
        <h2>1. 可用性目標</h2>
        <table>
          <tbody>
            <tr><th>稼働率目標</th><td>{(sla.meta.availability_target * 100).toFixed(2)}%</td></tr>
            <tr><th>サービス時間</th><td>{sla.meta.coverage}</td></tr>
            <tr><th>評価期間</th><td>{sla.meta.evaluation_period_days}日</td></tr>
            <tr><th>月間許容ダウンタイム</th><td>{sla.monthly_allowed_downtime_min}分 (エラーバジェット)</td></tr>
            <tr><th>RTO</th><td>{sla.rto_minutes}分以内</td></tr>
            <tr><th>RPO</th><td>{sla.rpo_minutes}分以内</td></tr>
          </tbody>
        </table>
      </section>

      <section className="response">
        <h2>2. 応答時間SLA</h2>
        <table>
          <thead>
            <tr><th>Severity</th><th>応答 (分)</th><th>復旧目標 (分)</th><th>営業日カウント</th></tr>
          </thead>
          <tbody>
            {sla.response_table.map((r) => (
              <tr key={r.level}>
                <td>{r.level}</td>
                <td>{r.response_sla_min}</td>
                <td>{r.recovery_target_min}</td>
                <td>{r.business_day_only ? '営業日のみ' : '24h連続'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>

      <section className="credit">
        <h2>3. サービスクレジット</h2>
        <p>月間稼働率がしきい値 ({(sla.service_credit.threshold_availability * 100).toFixed(0)}%) を下回った場合、翌月保守料金から返金。</p>
        <ul>
          {sla.service_credit.credits.map((c, i) => (
            <li key={i}>
              稼働率 &lt; {(c.availability_below * 100).toFixed(0)}% → {c.credit_percent}% サービスクレジット
            </li>
          ))}
        </ul>
        <small>{sla.service_credit.note}</small>
      </section>

      <section className="exclusions">
        <h2>4. 除外事項</h2>
        <ul>
          {sla.exclusions.map((e, i) => <li key={i}>{e}</li>)}
        </ul>
      </section>

      <section className="measurement">
        <h2>5. 計測方法</h2>
        <ul>
          {sla.measurement.map((m, i) => <li key={i}>{m}</li>)}
        </ul>
      </section>

      <section className="reporting">
        <h2>6. レポーティング</h2>
        <ul>
          {sla.reporting.map((r, i) => <li key={i}>{r}</li>)}
        </ul>
      </section>
    </article>
  );
}
