/**
 * 引継書テンプレート (.docx 製本想定)
 *
 * 責務:
 *   表紙→目次→8章 (エグゼクティブサマリ〜付録) を順番にレンダリング。
 *   双方向 (受託者→顧客 OR 顧客→新ベンダー) に対応する。
 */

import type { HandoverDoc } from '../lib/handover_doc';

export interface HandoverTemplateProps {
  handover: HandoverDoc;
  cover: {
    issuer_name: string;
    receiver_name: string;
    project_code?: string;
  };
  locale?: 'ja' | 'en';
}

export function HandoverTemplate({ handover, cover, locale = 'ja' }: HandoverTemplateProps): JSX.Element {
  const directionLabel =
    handover.meta.direction === 'sier_to_client'
      ? '受託者 (SIer) → 顧客運用部門'
      : '顧客運用部門 → 新運用ベンダー';
  return (
    <article className="handover" lang={locale}>
      <section className="cover">
        <h1>運用引継書 - {handover.meta.system_name}</h1>
        <dl>
          <dt>引継ぎ方向</dt>
          <dd>{directionLabel}</dd>
          <dt>引継ぎ期間</dt>
          <dd>{handover.meta.handover_period_start} 〜 {handover.meta.handover_period_end}</dd>
          <dt>発行</dt>
          <dd>{cover.issuer_name}</dd>
          <dt>受領</dt>
          <dd>{cover.receiver_name}</dd>
          {cover.project_code ? (
            <>
              <dt>プロジェクトコード</dt>
              <dd>{cover.project_code}</dd>
            </>
          ) : null}
          <dt>発行日</dt>
          <dd>{handover.meta.generated_at.slice(0, 10)}</dd>
          <dt>版数</dt>
          <dd>{handover.meta.version}</dd>
        </dl>
      </section>

      <nav className="toc">
        <h2>目次</h2>
        <ol>
          {handover.chapters.map((c) => (
            <li key={c.chapter_no}>
              {c.chapter_no}. {c.title_ja}
            </li>
          ))}
        </ol>
      </nav>

      {handover.chapters.map((c) => (
        <section key={c.chapter_no} className="chapter" data-chapter={c.chapter_no}>
          <h2>第{c.chapter_no}章 {c.title_ja}</h2>
          <pre className="markdown-body">{c.body_md}</pre>
        </section>
      ))}

      <section className="acknowledgement">
        <h2>受領確認</h2>
        <table>
          <thead>
            <tr><th>項目</th><th>確認</th><th>署名</th><th>日付</th></tr>
          </thead>
          <tbody>
            <tr>
              <td>本引継書の全章レビュー完了</td>
              <td>完了 / 未了</td>
              <td>__________</td>
              <td>__________</td>
            </tr>
            <tr>
              <td>単独運用2週間後の自走対応確認</td>
              <td>完了 / 未了</td>
              <td>__________</td>
              <td>__________</td>
            </tr>
            <tr>
              <td>月次運用報告の自律提出開始</td>
              <td>完了 / 未了</td>
              <td>__________</td>
              <td>__________</td>
            </tr>
          </tbody>
        </table>
      </section>
    </article>
  );
}
