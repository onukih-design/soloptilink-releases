/**
 * 障害対応Runbookジェネレータ
 *
 * 責務:
 *   SEV1〜SEV4の重大度分類に基づき、検知/一次対応/二次対応/エスカレーション/
 *   復旧確認/ポストモーテム要否までの一連のフローを生成。代表シナリオ6種
 *   (DB接続不可/API遅延/認証失敗多発/バッチ失敗/容量逼迫/不正アクセス疑い) に
 *   対する具体的Runbookと、Mermaid graph によるエスカレーションフローを出力する。
 *
 * 入力: RunbookGeneratorInput
 * 出力: Runbook (シナリオ群 + Mermaidフローチャート + Markdown整形)
 */

import type { OperationsContacts } from './operations_manual';

export type SeverityLevel = 'SEV1' | 'SEV2' | 'SEV3' | 'SEV4';

export interface SeverityDefinition {
  level: SeverityLevel;
  criteria_ja: string;
  response_sla_min: number;
  recovery_target_min: number;
  escalation_step: 'manager_immediate' | 'manager_notify' | 'team_lead_notify' | 'weekly_meeting';
  postmortem_required: boolean;
}

export const SEVERITY_DEFINITIONS: Record<SeverityLevel, SeverityDefinition> = {
  SEV1: {
    level: 'SEV1',
    criteria_ja: 'システム全停止または全業務影響。基幹機能が完全に利用不能。',
    response_sla_min: 15,
    recovery_target_min: 240,
    escalation_step: 'manager_immediate',
    postmortem_required: true,
  },
  SEV2: {
    level: 'SEV2',
    criteria_ja: '主要機能停止または複数部門が影響を受ける状態。代替手段は限定的。',
    response_sla_min: 60,
    recovery_target_min: 1440,
    escalation_step: 'manager_notify',
    postmortem_required: true,
  },
  SEV3: {
    level: 'SEV3',
    criteria_ja: '一部機能停止または性能劣化。代替手段あり。業務継続は可能。',
    response_sla_min: 240,
    recovery_target_min: 10080,
    escalation_step: 'team_lead_notify',
    postmortem_required: false,
  },
  SEV4: {
    level: 'SEV4',
    criteria_ja: '軽微な不具合。運用回避可能。改善要望レベル。',
    response_sla_min: 1440,
    recovery_target_min: 43200,
    escalation_step: 'weekly_meeting',
    postmortem_required: false,
  },
};

export type ScenarioId =
  | 'db_unreachable'
  | 'api_slow'
  | 'auth_failure_spike'
  | 'batch_failure'
  | 'capacity_exhaustion'
  | 'unauthorized_access';

export interface RunbookScenario {
  scenario_id: ScenarioId;
  title_ja: string;
  default_severity: SeverityLevel;
  detection: string[];
  primary_response: string[];
  secondary_response: string[];
  escalation: string[];
  recovery_check: string[];
  postmortem_required: boolean;
  related_metrics: string[];
}

export interface RunbookGeneratorInput {
  system_name: string;
  contacts: OperationsContacts;
  scenarios?: ScenarioId[];
  custom_severity?: SeverityLevel[];
}

export interface Runbook {
  meta: {
    system_name: string;
    generated_at: string;
    version: string;
  };
  severity_table: SeverityDefinition[];
  scenarios: RunbookScenario[];
  mermaid_flowchart: string;
  contacts: OperationsContacts;
}

const SCENARIO_DEFINITIONS: Record<ScenarioId, RunbookScenario> = {
  db_unreachable: {
    scenario_id: 'db_unreachable',
    title_ja: 'DB接続不可 (PostgreSQL/MySQL/Oracle接続喪失)',
    default_severity: 'SEV1',
    detection: [
      'アプリ側 5xx エラー多発 (errors.connection_refused)',
      'DBコネクションプール枯渇アラート',
      'ヘルスチェックエンドポイント /api/health が DB.connected=false を返す',
    ],
    primary_response: [
      'DB稼働状態を確認 (RDSコンソール / ssh + ps -ef | grep postgres)',
      'DBサーバの CPU・メモリ・ディスクを確認',
      'ネットワーク疎通を確認 (telnet 5432 / セキュリティグループ)',
      'pg_stat_activity で長時間トランザクションを確認',
    ],
    secondary_response: [
      'スレーブDBへのフェイルオーバを判断',
      'コネクションプール設定を見直し (max_connections / pool_size)',
      'DB再起動 (最終手段)',
    ],
    escalation: [
      '15分で復旧見込みが立たない場合、マネージャ + DBA に連絡',
      'クラウド事業者サポート (AWS/Azure/GCP) に Critical チケット起票',
    ],
    recovery_check: [
      'ヘルスチェック /api/health が DB.connected=true を返すこと',
      '代表3画面のスモークテスト',
      '影響を受けたトランザクションのロールバック/再実行確認',
    ],
    postmortem_required: true,
    related_metrics: ['db_connection_count', 'db_pool_wait_time', 'db_cpu', 'db_disk_iops'],
  },
  api_slow: {
    scenario_id: 'api_slow',
    title_ja: 'API応答遅延 (p95 > 3秒)',
    default_severity: 'SEV2',
    detection: [
      '外形監視 (Synthetic) アラート',
      'p95レイテンシ > 3秒 が5分間継続',
      'タイムアウトエラー多発',
    ],
    primary_response: [
      'APMダッシュボードでスロークエリ・スローエンドポイントを特定',
      'DB側スロークエリ ログを確認',
      '直近のデプロイ有無を確認',
    ],
    secondary_response: [
      '直近のデプロイをロールバック',
      'スケールアウト (オートスケール手動トリガ)',
      'キャッシュ層 (Redis) のヒット率を確認',
    ],
    escalation: [
      '1時間で改善が見られない場合マネージャ通知',
      'スケールアウト後も継続する場合はベンダーサポート連絡',
    ],
    recovery_check: [
      'p95応答時間 < 3秒 が30分継続',
      '外形監視のすべてのチェックが正常',
    ],
    postmortem_required: true,
    related_metrics: ['p95_latency', 'p99_latency', 'error_rate', 'throughput_rps'],
  },
  auth_failure_spike: {
    scenario_id: 'auth_failure_spike',
    title_ja: '認証失敗多発 (ブルートフォース疑い)',
    default_severity: 'SEV2',
    detection: [
      '認証失敗ログが過去比10倍以上',
      '同一IPからの認証試行が10回/分以上',
      'WAF (CloudFlare/AWS WAF) アラート',
    ],
    primary_response: [
      '失敗元IPを特定し、WAFで一時ブロック',
      '対象アカウントの所有者に確認',
      '監査ログを過去24時間分エクスポート',
    ],
    secondary_response: [
      '対象アカウントを一時ロック',
      'パスワードリセットを促すメール送信',
      'MFA未設定アカウントを洗い出し',
    ],
    escalation: [
      '個人情報漏えいの兆候があれば DPO + 情シス役員に即時連絡',
      '個情法第26条に基づき5日以内に個人情報保護委員会へ報告判断',
    ],
    recovery_check: [
      '認証失敗率が通常範囲に戻る',
      '不審IPからのトラフィックが停止',
      '監査ログ上、不正ログイン成功がないことを確認',
    ],
    postmortem_required: true,
    related_metrics: ['auth_failure_rate', 'unique_failed_ips', 'mfa_coverage'],
  },
  batch_failure: {
    scenario_id: 'batch_failure',
    title_ja: '夜間バッチ失敗',
    default_severity: 'SEV2',
    detection: [
      'バッチジョブ ステータス FAILED アラート',
      '翌朝のレポートメールが配信されない',
      '関連テーブルのデータ更新が止まっている',
    ],
    primary_response: [
      'バッチジョブログ (stdout/stderr) を確認',
      'DBの対象テーブル状態を確認',
      'リトライ可能か判断',
    ],
    secondary_response: [
      '部分実行できる場合は範囲指定で再実行',
      '依存ジョブとの順序確認',
      'データ不整合があれば修復スクリプトを実行',
    ],
    escalation: [
      '業務開始時刻 (9:00) までに完了見込みが立たない場合、業務部門に遅延連絡',
      '帳票・支払関連の場合は経理部門へ即時連絡',
    ],
    recovery_check: [
      'バッチが SUCCESS で完了',
      '対象データの件数が想定範囲',
      '関連レポートが配信される',
    ],
    postmortem_required: true,
    related_metrics: ['batch_duration', 'batch_record_count', 'batch_failure_rate'],
  },
  capacity_exhaustion: {
    scenario_id: 'capacity_exhaustion',
    title_ja: '容量逼迫 (ディスク>85% / メモリ>90%)',
    default_severity: 'SEV2',
    detection: [
      'ディスク使用率 > 85% アラート',
      'メモリ使用率 > 90% アラート',
      'DBテーブル使用容量 > 80%',
    ],
    primary_response: [
      '不要なログ/古いバックアップを削除',
      'OOM Killer 履歴を確認',
      '一時的な容量を確保 (extentボリューム拡張)',
    ],
    secondary_response: [
      '永続的な容量拡張 (RDSストレージ拡張 / EBS拡張)',
      '古いデータをアーカイブストレージへ移動',
      'ログローテート方針見直し',
    ],
    escalation: [
      '空き容量0% が30分以内に予測される場合、SEV1 へ昇格',
      'インフラ責任者 + ベンダーサポートを巻き込む',
    ],
    recovery_check: [
      'ディスク使用率 < 70%',
      'メモリ使用率 < 80%',
      '24時間以上、再発しない',
    ],
    postmortem_required: false,
    related_metrics: ['disk_used_percent', 'memory_used_percent', 'inode_used'],
  },
  unauthorized_access: {
    scenario_id: 'unauthorized_access',
    title_ja: '不正アクセス疑い (不審IP / 特権操作 / SQLi痕跡)',
    default_severity: 'SEV1',
    detection: [
      'WAFが SQLi/XSS/Path Traversal を検出',
      '深夜帯の特権操作ログ',
      '海外IPからの管理画面アクセス',
    ],
    primary_response: [
      '該当IPを即時ブロック (WAFブロック + EC2 SecurityGroup)',
      '影響範囲調査 (アクセスログ + DB変更ログ)',
      'マネージャ + 情シス役員 + 法務に同時連絡',
    ],
    secondary_response: [
      '該当アカウントを無効化',
      'パスワード強制リセット (全特権ユーザ)',
      'インシデント対応フォレンジック (ログ保全)',
    ],
    escalation: [
      '個人情報漏えいの可能性ありの場合、個人情報保護委員会への5日以内の報告を判断',
      '法務 + 広報 + DPOで連携、ステークホルダ通知方針を決定',
    ],
    recovery_check: [
      '攻撃元IPからのアクセスが停止',
      '不正に変更されたデータの復旧確認',
      '監査ログのフォレンジック分析が完了',
    ],
    postmortem_required: true,
    related_metrics: ['waf_blocks', 'admin_actions_after_hours', 'foreign_ip_access'],
  },
};

export function generateRunbook(input: RunbookGeneratorInput): Runbook {
  const scenarios = (input.scenarios ?? Object.keys(SCENARIO_DEFINITIONS) as ScenarioId[]).map(
    (id) => SCENARIO_DEFINITIONS[id]
  );
  return {
    meta: {
      system_name: input.system_name,
      generated_at: new Date().toISOString(),
      version: '1.0.0',
    },
    severity_table: Object.values(SEVERITY_DEFINITIONS),
    scenarios,
    mermaid_flowchart: buildMermaidFlowchart(),
    contacts: input.contacts,
  };
}

function buildMermaidFlowchart(): string {
  const lines: string[] = [];
  lines.push('```mermaid');
  lines.push('graph TD');
  lines.push('  A[アラート検知] --> B{SEV判定}');
  lines.push('  B -- SEV1 --> C[即時電話: PRIMARY + マネージャ]');
  lines.push('  B -- SEV2 --> D[Slack/メール: PRIMARY]');
  lines.push('  B -- SEV3 --> E[チケット起票: チームリード通知]');
  lines.push('  B -- SEV4 --> F[週次定例で報告]');
  lines.push('  C --> G[15分以内応答]');
  lines.push('  D --> H[1時間以内応答]');
  lines.push('  E --> I[4時間以内応答]');
  lines.push('  G --> J[一次対応: 検知ログ確認]');
  lines.push('  H --> J');
  lines.push('  I --> J');
  lines.push('  J --> K{解決?}');
  lines.push('  K -- Yes --> L[復旧確認]');
  lines.push('  K -- No --> M[二次対応 + マネージャエスカレーション]');
  lines.push('  M --> N[ベンダーサポート連絡]');
  lines.push('  N --> L');
  lines.push('  L --> O{ポストモーテム要?}');
  lines.push('  O -- Yes --> P[5営業日以内にポストモーテム作成]');
  lines.push('  O -- No --> Q[チケットクローズ]');
  lines.push('  P --> Q');
  lines.push('```');
  return lines.join('\n');
}

/** RunbookをMarkdownとして整形 */
export function formatRunbookAsMarkdown(rb: Runbook): string {
  const lines: string[] = [];
  lines.push(`# 障害対応Runbook ${rb.meta.system_name}`);
  lines.push('');
  lines.push(`発行日: ${rb.meta.generated_at.slice(0, 10)} / 版数: ${rb.meta.version}`);
  lines.push('');
  lines.push('## 1. 重大度 (Severity) 定義');
  lines.push('');
  lines.push('| Level | 判定基準 | 応答SLA | 復旧目標 | エスカレーション | ポストモーテム |');
  lines.push('|-------|---------|--------|---------|----------------|---------------|');
  for (const s of rb.severity_table) {
    lines.push(
      `| ${s.level} | ${s.criteria_ja} | ${formatMinutes(s.response_sla_min)} | ${formatMinutes(s.recovery_target_min)} | ${formatEscalationStep(s.escalation_step)} | ${s.postmortem_required ? '必須' : '任意'} |`
    );
  }
  lines.push('');
  lines.push('## 2. エスカレーションフロー');
  lines.push('');
  lines.push(rb.mermaid_flowchart);
  lines.push('');
  lines.push('## 3. 代表シナリオRunbook');
  lines.push('');
  for (const sc of rb.scenarios) {
    lines.push(`### ${sc.title_ja}`);
    lines.push(`- デフォルトSeverity: **${sc.default_severity}**`);
    lines.push(`- ポストモーテム: ${sc.postmortem_required ? '必須' : '任意'}`);
    lines.push('');
    lines.push('**検知方法**');
    sc.detection.forEach((d) => lines.push(`- ${d}`));
    lines.push('');
    lines.push('**一次対応**');
    sc.primary_response.forEach((s, i) => lines.push(`${i + 1}. ${s}`));
    lines.push('');
    lines.push('**二次対応**');
    sc.secondary_response.forEach((s, i) => lines.push(`${i + 1}. ${s}`));
    lines.push('');
    lines.push('**エスカレーション**');
    sc.escalation.forEach((e) => lines.push(`- ${e}`));
    lines.push('');
    lines.push('**復旧確認**');
    sc.recovery_check.forEach((r) => lines.push(`- ${r}`));
    lines.push('');
    lines.push(`**関連メトリクス**: ${sc.related_metrics.join(', ')}`);
    lines.push('');
  }
  lines.push('## 4. 連絡先');
  const c = rb.contacts;
  lines.push(`- Primary: ${c.primary.name} (${c.primary.role}) ${c.primary.phone ?? ''}`);
  lines.push(`- Secondary: ${c.secondary.name} (${c.secondary.role}) ${c.secondary.phone ?? ''}`);
  lines.push(`- Manager Escalation: ${c.manager_escalation.name} (${c.manager_escalation.role})`);
  lines.push(`- Vendor Support: ${c.vendor_support.name} (${c.vendor_support.role})`);
  return lines.join('\n');
}

function formatMinutes(min: number): string {
  if (min < 60) return `${min}分`;
  if (min < 1440) return `${Math.floor(min / 60)}時間`;
  return `${Math.floor(min / 1440)}営業日`;
}

function formatEscalationStep(step: SeverityDefinition['escalation_step']): string {
  switch (step) {
    case 'manager_immediate': return '即時マネージャ + 1h以内役員';
    case 'manager_notify': return 'マネージャ通知';
    case 'team_lead_notify': return 'チームリード通知';
    case 'weekly_meeting': return '週次定例で報告';
  }
}
