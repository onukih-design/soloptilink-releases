/**
 * 引継書ジェネレータ
 *
 * 責務:
 *   日本SI標準8章の引継書を生成。受託者→顧客運用部門 (sier_to_client)、または
 *   顧客運用部門→新運用ベンダー (client_to_new_vendor) の双方向対応。
 *   システム概要、資産一覧 (サーバ/ライセンス/アカウント/ドメイン/証明書)、
 *   既知の問題と回避策、変更履歴、将来の改善提案、付録 (パスワード保管場所/
 *   契約書類) までを網羅する。
 *
 * 入力: HandoverDocInput
 * 出力: HandoverDoc (8章 + Markdown整形)
 */

import type { ClientType, IndustryKey, OperationsContacts } from './operations_manual';

export type HandoverDirection = 'sier_to_client' | 'client_to_new_vendor';

export interface AssetServer {
  hostname: string;
  role: string;
  spec: string;
  cloud_provider: string;
  region: string;
  cost_jpy_monthly?: number;
}

export interface AssetLicense {
  software_name: string;
  vendor: string;
  license_count: number;
  expiry_date: string;
  contact: string;
}

export interface AssetAccount {
  service: string;
  account_id: string;
  owner: string;
  permission_level: string;
  storage_location: string;
}

export interface AssetCertificate {
  domain: string;
  issuer: string;
  issued_at: string;
  expires_at: string;
  auto_renew: boolean;
}

export interface KnownIssue {
  issue_id: string;
  severity: '高' | '中' | '低';
  summary: string;
  workaround: string;
  fix_plan?: string;
}

export interface ChangeHistoryItem {
  date: string;
  type: '機能追加' | '機能改修' | 'バグ修正' | 'パフォーマンス' | '法令対応' | 'セキュリティ' | 'その他';
  summary: string;
  ticket?: string;
}

export interface ImprovementProposal {
  category: '技術的負債' | '性能向上' | 'セキュリティ強化' | '運用改善' | 'コスト削減';
  description: string;
  estimated_pd: number;
  expected_benefit: string;
}

export interface HandoverDocInput {
  direction: HandoverDirection;
  system_name: string;
  client_type?: ClientType;
  industry?: IndustryKey;
  contacts: OperationsContacts;
  servers: AssetServer[];
  licenses: AssetLicense[];
  accounts: AssetAccount[];
  certificates: AssetCertificate[];
  known_issues: KnownIssue[];
  change_history: ChangeHistoryItem[];
  improvement_proposals: ImprovementProposal[];
  password_storage_locations: string[];
  contract_documents: { title: string; storage_url_or_path: string }[];
  handover_period_start?: string;
  handover_period_end?: string;
}

export interface HandoverChapter {
  chapter_no: number;
  title_ja: string;
  body_md: string;
}

export interface HandoverDoc {
  meta: {
    direction: HandoverDirection;
    system_name: string;
    client_type: ClientType;
    industry: IndustryKey;
    handover_period_start: string;
    handover_period_end: string;
    generated_at: string;
    version: string;
  };
  chapters: HandoverChapter[];
}

export function generateHandoverDoc(input: HandoverDocInput): HandoverDoc {
  const client_type: ClientType = input.client_type ?? '民間';
  const industry: IndustryKey = input.industry ?? 'default';
  const today = new Date();
  const handover_period_start = input.handover_period_start ?? formatDate(today);
  const handover_period_end =
    input.handover_period_end ??
    formatDate(new Date(today.getTime() + 90 * 24 * 60 * 60 * 1000));

  const chapters: HandoverChapter[] = [
    buildExecutiveSummary(input, client_type, industry, handover_period_start, handover_period_end),
    buildSystemOverviewChapter(input),
    buildAssetsChapter(input),
    buildOperationsSummary(input),
    buildKnownIssuesChapter(input.known_issues),
    buildContactsChapter(input.contacts),
    buildChangeHistoryChapter(input.change_history),
    buildImprovementChapter(input.improvement_proposals),
    buildAppendixChapter(input.password_storage_locations, input.contract_documents),
  ];

  return {
    meta: {
      direction: input.direction,
      system_name: input.system_name,
      client_type,
      industry,
      handover_period_start,
      handover_period_end,
      generated_at: new Date().toISOString(),
      version: '1.0.0',
    },
    chapters,
  };
}

function buildExecutiveSummary(
  input: HandoverDocInput,
  client_type: ClientType,
  industry: IndustryKey,
  start: string,
  end: string
): HandoverChapter {
  const direction =
    input.direction === 'sier_to_client'
      ? '受託者 (SIer) → 顧客運用部門'
      : '顧客運用部門 → 新運用ベンダー';
  const lines = [
    `本書は「${input.system_name}」の運用引継ぎを目的とする。`,
    '',
    `- **引継ぎ方向**: ${direction}`,
    `- **引継ぎ期間**: ${start} 〜 ${end}`,
    `- **顧客タイプ**: ${client_type}`,
    `- **業種**: ${industry}`,
    `- **対象範囲**: 本番運用 + ステージング + バックアップ環境`,
    `- **想定体制**: 旧体制から新体制への完全移管 (3段階: シャドーイング → 並走 → 単独運用)`,
    '',
    '**引継ぎ完了基準**',
    '1. 全章のレビューが完了し、新体制から質疑応答がない',
    '2. 単独運用2週間で SEV1/SEV2 の自走対応が確認できる',
    '3. 月次運用報告が新体制から自律的に提出される',
  ];
  return { chapter_no: 0, title_ja: 'エグゼクティブサマリ', body_md: lines.join('\n') };
}

function buildSystemOverviewChapter(input: HandoverDocInput): HandoverChapter {
  const lines = [
    `本システム「${input.system_name}」の概要を以下に示す。詳細は運用手順書を参照すること。`,
    '',
    '### 主要構成',
    '- フロントエンド (Web)',
    '- バックエンドAPI',
    '- データベース (マスタ + キャッシュ)',
    '- バッチ処理基盤',
    '- 監視 + ログ集約',
    '',
    '### 業務範囲',
    '本書「資産一覧」を参照のこと。',
  ];
  return { chapter_no: 1, title_ja: 'システム概要', body_md: lines.join('\n') };
}

function buildAssetsChapter(input: HandoverDocInput): HandoverChapter {
  const lines: string[] = [];
  lines.push('### サーバ資産');
  lines.push('');
  lines.push('| ホスト名 | 役割 | スペック | クラウド | リージョン | 月額(円) |');
  lines.push('|---------|------|---------|---------|-----------|---------|');
  for (const s of input.servers) {
    lines.push(`| ${s.hostname} | ${s.role} | ${s.spec} | ${s.cloud_provider} | ${s.region} | ${s.cost_jpy_monthly?.toLocaleString() ?? '-'} |`);
  }
  lines.push('');
  lines.push('### ライセンス資産');
  lines.push('');
  lines.push('| ソフトウェア | ベンダー | 数 | 期限 | 連絡先 |');
  lines.push('|------------|---------|----|------|--------|');
  for (const l of input.licenses) {
    lines.push(`| ${l.software_name} | ${l.vendor} | ${l.license_count} | ${l.expiry_date} | ${l.contact} |`);
  }
  lines.push('');
  lines.push('### アカウント資産');
  lines.push('');
  lines.push('| サービス | アカウントID | オーナー | 権限 | 認証情報保管場所 |');
  lines.push('|---------|------------|---------|------|----------------|');
  for (const a of input.accounts) {
    lines.push(`| ${a.service} | ${a.account_id} | ${a.owner} | ${a.permission_level} | ${a.storage_location} |`);
  }
  lines.push('');
  lines.push('### 証明書 / ドメイン');
  lines.push('');
  lines.push('| ドメイン | 発行者 | 発行日 | 有効期限 | 自動更新 |');
  lines.push('|---------|-------|-------|---------|---------|');
  for (const c of input.certificates) {
    lines.push(`| ${c.domain} | ${c.issuer} | ${c.issued_at} | ${c.expires_at} | ${c.auto_renew ? 'あり' : 'なし'} |`);
  }
  return { chapter_no: 2, title_ja: '資産一覧', body_md: lines.join('\n') };
}

function buildOperationsSummary(input: HandoverDocInput): HandoverChapter {
  const lines = [
    '日次/週次/月次/年次の運用作業の詳細は別冊「運用手順書」を参照。',
    '',
    '### 重要ポイント',
    '- **日次**: ヘルスチェック / バックアップ確認 / エラーログ確認 (毎営業日 9:30まで)',
    '- **週次**: 週次バッチ確認 / 容量レポート',
    '- **月次**: 月次集計バッチ / 容量・性能レポート / 監査ログレビュー',
    '- **年次**: BCP訓練 / リストア訓練 / 脆弱性診断 / SLA見直し / 契約更新',
    '',
    '### 月次運用報告の提出',
    '- 翌月 10営業日以内に提出',
    '- フォーマット: 別添「月次運用報告テンプレート」',
  ];
  return { chapter_no: 3, title_ja: '運用手順', body_md: lines.join('\n') };
}

function buildKnownIssuesChapter(issues: KnownIssue[]): HandoverChapter {
  const lines: string[] = [];
  if (issues.length === 0) {
    lines.push('現時点で引継ぎ対象の既知の問題はない。');
  } else {
    lines.push('| Issue ID | 重要度 | 概要 | 回避策 | 修正計画 |');
    lines.push('|----------|--------|------|--------|---------|');
    for (const i of issues) {
      lines.push(`| ${i.issue_id} | ${i.severity} | ${i.summary} | ${i.workaround} | ${i.fix_plan ?? '未定'} |`);
    }
  }
  return { chapter_no: 4, title_ja: '既知の問題と回避策', body_md: lines.join('\n') };
}

function buildContactsChapter(c: OperationsContacts): HandoverChapter {
  const lines: string[] = [];
  lines.push('### ステークホルダ + サポート');
  lines.push('');
  lines.push('| 役割 | 氏名 | 連絡先 | 対応時間 |');
  lines.push('|------|------|--------|---------|');
  lines.push(formatRow('一次対応 (Primary)', c.primary));
  lines.push(formatRow('二次対応 (Secondary)', c.secondary));
  lines.push(formatRow('三次対応 (Manager Escalation)', c.manager_escalation));
  lines.push(formatRow('ベンダーサポート', c.vendor_support));
  if (c.data_protection_officer) {
    lines.push(formatRow('個人情報保護管理者 (DPO)', c.data_protection_officer));
  }
  return { chapter_no: 5, title_ja: '連絡先', body_md: lines.join('\n') };
}

function formatRow(label: string, c: { name: string; role: string; phone?: string; email?: string; hours?: string }): string {
  const contact = [c.phone, c.email].filter(Boolean).join(' / ') || '-';
  return `| ${label} | ${c.name} (${c.role}) | ${contact} | ${c.hours ?? '-'} |`;
}

function buildChangeHistoryChapter(history: ChangeHistoryItem[]): HandoverChapter {
  const lines: string[] = [];
  if (history.length === 0) {
    lines.push('過去12ヶ月の主要変更はない。');
  } else {
    lines.push('| 日付 | 種別 | 概要 | チケット |');
    lines.push('|------|------|------|---------|');
    for (const h of history) {
      lines.push(`| ${h.date} | ${h.type} | ${h.summary} | ${h.ticket ?? '-'} |`);
    }
  }
  return { chapter_no: 6, title_ja: '変更履歴', body_md: lines.join('\n') };
}

function buildImprovementChapter(props: ImprovementProposal[]): HandoverChapter {
  const lines: string[] = [];
  if (props.length === 0) {
    lines.push('現時点で記載すべき改善提案はない。');
  } else {
    lines.push('| カテゴリ | 提案内容 | 想定工数 (人日) | 期待効果 |');
    lines.push('|---------|---------|----------------|----------|');
    for (const p of props) {
      lines.push(`| ${p.category} | ${p.description} | ${p.estimated_pd} | ${p.expected_benefit} |`);
    }
  }
  return { chapter_no: 7, title_ja: '将来の改善提案', body_md: lines.join('\n') };
}

function buildAppendixChapter(
  passwords: string[],
  docs: { title: string; storage_url_or_path: string }[]
): HandoverChapter {
  const lines: string[] = [];
  lines.push('### A. パスワード保管場所');
  lines.push('');
  if (passwords.length === 0) {
    lines.push('- (未登録)');
  } else {
    for (const p of passwords) lines.push(`- ${p}`);
  }
  lines.push('');
  lines.push('### B. 契約書類');
  lines.push('');
  if (docs.length === 0) {
    lines.push('- (未登録)');
  } else {
    lines.push('| 書類名 | 保管場所 |');
    lines.push('|--------|---------|');
    for (const d of docs) {
      lines.push(`| ${d.title} | ${d.storage_url_or_path} |`);
    }
  }
  return { chapter_no: 8, title_ja: '付録', body_md: lines.join('\n') };
}

function formatDate(d: Date): string {
  return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
}

/** 引継書をMarkdownとして整形 */
export function formatHandoverDocAsMarkdown(h: HandoverDoc): string {
  const lines: string[] = [];
  lines.push(`# 運用引継書 ${h.meta.system_name}`);
  lines.push('');
  lines.push(`発行日: ${h.meta.generated_at.slice(0, 10)} / 版数: ${h.meta.version}`);
  lines.push(`引継ぎ方向: ${h.meta.direction === 'sier_to_client' ? '受託者→顧客' : '顧客→新ベンダー'}`);
  lines.push(`引継ぎ期間: ${h.meta.handover_period_start} 〜 ${h.meta.handover_period_end}`);
  lines.push('');
  for (const c of h.chapters) {
    lines.push(`## ${c.chapter_no}. ${c.title_ja}`);
    lines.push('');
    lines.push(c.body_md);
    lines.push('');
  }
  return lines.join('\n');
}
