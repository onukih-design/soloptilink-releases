/**
 * SLAジェネレータ (Service Level Agreement)
 *
 * 責務:
 *   サービス時間 (24x365 / business-hours / extended)、可用性目標
 *   (99.9% / 99.95% / 99.99%)、応答時間SLA、RTO/RPO、エラーバジェット計算、
 *   ペナルティ条項 (サービスクレジット)、日本祝日カレンダー (2024-2026) 連動の
 *   営業日除外計算 を含む SLA文書を生成する。
 *
 * 日本祝日: 2024〜2026年分を内蔵。本モジュールは姉妹スキルの jp-sre モジュールに
 *   依存せず、独立に動作する。営業日定義の整合性は意識して合わせている。
 *
 * 入力: SlaInput
 * 出力: Sla (条項一覧 + Markdown整形 + isBusinessDay/エラーバジェット計算)
 */

import type { CoverageWindow, ClientType, IndustryKey } from './operations_manual';
import { SEVERITY_DEFINITIONS, type SeverityLevel } from './runbook_generator';

export type AvailabilityTier = 0.999 | 0.9995 | 0.9999;

export interface SlaResponseRow {
  level: SeverityLevel;
  response_sla_min: number;
  recovery_target_min: number;
  business_day_only: boolean;
}

export interface SlaInput {
  system_name: string;
  coverage?: CoverageWindow;
  availability_target?: AvailabilityTier;
  rto_minutes?: number;
  rpo_minutes?: number;
  client_type?: ClientType;
  industry?: IndustryKey;
  service_credit_threshold?: number;
  evaluation_period_days?: number;
}

export interface Sla {
  meta: {
    system_name: string;
    coverage: CoverageWindow;
    availability_target: AvailabilityTier;
    evaluation_period_days: number;
    generated_at: string;
    version: string;
    client_type: ClientType;
    industry: IndustryKey;
  };
  monthly_allowed_downtime_min: number;
  error_budget_min: number;
  rto_minutes: number;
  rpo_minutes: number;
  response_table: SlaResponseRow[];
  service_credit: {
    threshold_availability: number;
    credits: { availability_below: number; credit_percent: number }[];
    note: string;
  };
  exclusions: string[];
  reporting: string[];
  measurement: string[];
}

/** 日本祝日 2024-2026 (元日/成人/建国/天皇誕生/春分/昭和/憲法/みどり/こどもの/海/山/敬老/秋分/スポーツ/文化/勤労感謝) */
const JAPANESE_HOLIDAYS: Record<string, string> = {
  // 2024年
  '2024-01-01': '元日',
  '2024-01-08': '成人の日',
  '2024-02-11': '建国記念の日',
  '2024-02-12': '振替休日',
  '2024-02-23': '天皇誕生日',
  '2024-03-20': '春分の日',
  '2024-04-29': '昭和の日',
  '2024-05-03': '憲法記念日',
  '2024-05-04': 'みどりの日',
  '2024-05-05': 'こどもの日',
  '2024-05-06': '振替休日',
  '2024-07-15': '海の日',
  '2024-08-11': '山の日',
  '2024-08-12': '振替休日',
  '2024-09-16': '敬老の日',
  '2024-09-22': '秋分の日',
  '2024-09-23': '振替休日',
  '2024-10-14': 'スポーツの日',
  '2024-11-03': '文化の日',
  '2024-11-04': '振替休日',
  '2024-11-23': '勤労感謝の日',
  // 2025年
  '2025-01-01': '元日',
  '2025-01-13': '成人の日',
  '2025-02-11': '建国記念の日',
  '2025-02-23': '天皇誕生日',
  '2025-02-24': '振替休日',
  '2025-03-20': '春分の日',
  '2025-04-29': '昭和の日',
  '2025-05-03': '憲法記念日',
  '2025-05-04': 'みどりの日',
  '2025-05-05': 'こどもの日',
  '2025-05-06': '振替休日',
  '2025-07-21': '海の日',
  '2025-08-11': '山の日',
  '2025-09-15': '敬老の日',
  '2025-09-23': '秋分の日',
  '2025-10-13': 'スポーツの日',
  '2025-11-03': '文化の日',
  '2025-11-23': '勤労感謝の日',
  '2025-11-24': '振替休日',
  // 2026年
  '2026-01-01': '元日',
  '2026-01-12': '成人の日',
  '2026-02-11': '建国記念の日',
  '2026-02-23': '天皇誕生日',
  '2026-03-20': '春分の日',
  '2026-04-29': '昭和の日',
  '2026-05-03': '憲法記念日',
  '2026-05-04': 'みどりの日',
  '2026-05-05': 'こどもの日',
  '2026-05-06': '振替休日',
  '2026-07-20': '海の日',
  '2026-08-11': '山の日',
  '2026-09-21': '敬老の日',
  '2026-09-22': '国民の休日',
  '2026-09-23': '秋分の日',
  '2026-10-12': 'スポーツの日',
  '2026-11-03': '文化の日',
  '2026-11-23': '勤労感謝の日',
};

export function isJapaneseHoliday(d: Date): boolean {
  const key = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
  return key in JAPANESE_HOLIDAYS;
}

export function holidayNameOf(d: Date): string | null {
  const key = `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, '0')}-${String(d.getUTCDate()).padStart(2, '0')}`;
  return JAPANESE_HOLIDAYS[key] ?? null;
}

export function isBusinessDay(d: Date): boolean {
  const day = d.getUTCDay();
  if (day === 0 || day === 6) return false;
  if (isJapaneseHoliday(d)) return false;
  return true;
}

/** 開始日から `n営業日後` を返す (Excel WORKDAY 互換) */
export function addBusinessDays(start: Date, n: number): Date {
  const d = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth(), start.getUTCDate()));
  let added = 0;
  while (added < n) {
    d.setUTCDate(d.getUTCDate() + 1);
    if (isBusinessDay(d)) added += 1;
  }
  return d;
}

export function generateSla(input: SlaInput): Sla {
  const coverage: CoverageWindow = input.coverage ?? '24x365';
  const client_type: ClientType = input.client_type ?? '民間';
  const industry: IndustryKey = input.industry ?? 'default';
  const availability_target: AvailabilityTier = input.availability_target ?? defaultAvailability(client_type, industry);
  const evaluation_period_days = input.evaluation_period_days ?? 30;
  const rto_minutes = input.rto_minutes ?? defaultRto(availability_target);
  const rpo_minutes = input.rpo_minutes ?? defaultRpo(industry);

  const monthly_allowed_downtime_min = computeMonthlyAllowedDowntimeMin(coverage, availability_target, evaluation_period_days);
  const error_budget_min = monthly_allowed_downtime_min;

  const response_table: SlaResponseRow[] = (Object.keys(SEVERITY_DEFINITIONS) as SeverityLevel[]).map((lv) => {
    const def = SEVERITY_DEFINITIONS[lv];
    return {
      level: lv,
      response_sla_min: def.response_sla_min,
      recovery_target_min: def.recovery_target_min,
      business_day_only: coverage !== '24x365' && lv !== 'SEV1',
    };
  });

  const service_credit_threshold = input.service_credit_threshold ?? 0.99;

  return {
    meta: {
      system_name: input.system_name,
      coverage,
      availability_target,
      evaluation_period_days,
      generated_at: new Date().toISOString(),
      version: '1.0.0',
      client_type,
      industry,
    },
    monthly_allowed_downtime_min,
    error_budget_min,
    rto_minutes,
    rpo_minutes,
    response_table,
    service_credit: buildServiceCredit(service_credit_threshold),
    exclusions: buildExclusions(coverage),
    reporting: buildReporting(),
    measurement: buildMeasurement(coverage),
  };
}

function defaultAvailability(client_type: ClientType, industry: IndustryKey): AvailabilityTier {
  if (client_type === '公共' || client_type === '自治体' || industry === 'public_sector') return 0.9999;
  if (industry === 'finance' || industry === 'healthcare') return 0.9999;
  return 0.999;
}

function defaultRto(target: AvailabilityTier): number {
  switch (target) {
    case 0.9999: return 30;
    case 0.9995: return 60;
    default: return 240;
  }
}

function defaultRpo(industry: IndustryKey): number {
  if (industry === 'finance' || industry === 'public_sector') return 5;
  if (industry === 'healthcare' || industry === 'longterm_care') return 15;
  return 60;
}

function computeMonthlyAllowedDowntimeMin(
  coverage: CoverageWindow,
  availability: AvailabilityTier,
  days: number
): number {
  let serviceMinutesPerDay: number;
  switch (coverage) {
    case '24x365': serviceMinutesPerDay = 24 * 60; break;
    case 'business-hours': serviceMinutesPerDay = 9 * 60; break;
    case 'extended': serviceMinutesPerDay = 14 * 60; break;
  }
  const total = serviceMinutesPerDay * days;
  const allowed = total * (1 - availability);
  return Math.round(allowed * 100) / 100;
}

function buildServiceCredit(threshold: number): Sla['service_credit'] {
  return {
    threshold_availability: threshold,
    credits: [
      { availability_below: 0.99, credit_percent: 5 },
      { availability_below: 0.95, credit_percent: 15 },
      { availability_below: 0.90, credit_percent: 30 },
    ],
    note: '月間稼働率がしきい値を下回った場合、翌月の保守料金から記載比率を返金 (サービスクレジット)。',
  };
}

function buildExclusions(coverage: CoverageWindow): string[] {
  const list: string[] = [
    '計画停止 (事前7営業日以上の通知): SLA計算から除外',
    '不可抗力 (天災/戦争/通信事業者障害): SLA計算から除外',
    '顧客起因 (顧客作業ミス/権限不正使用): SLA計算から除外',
    '顧客指定の第三者サービス障害: 一次切り分けまで提供',
  ];
  if (coverage === 'business-hours') {
    list.push('土日祝・年末年始: SLA計算対象外 (緊急時連絡先は別途規定)');
  }
  if (coverage === 'extended') {
    list.push('深夜帯 (22:00〜8:00) の対応: ベストエフォート (24x365契約は除く)');
  }
  return list;
}

function buildReporting(): string[] {
  return [
    '月次運用報告書: 稼働率/SLA達成率/インシデント件数/Toil率を毎月10営業日以内に提出',
    '四半期レビュー: 改善提案 + 課題整理 + 翌四半期計画',
    '年次レビュー: SLA見直し協議 / 契約条件改定協議',
  ];
}

function buildMeasurement(coverage: CoverageWindow): string[] {
  const list: string[] = [
    '稼働率 = (サービス時間 - ダウンタイム) / サービス時間',
    'ダウンタイムは外形監視 (Synthetic) のFAIL時間を採用',
    '外形監視は最低5分間隔、3拠点 (東京/大阪/シンガポール) から同時計測',
  ];
  if (coverage === '24x365') list.push('サービス時間: 24時間×日数');
  if (coverage === 'business-hours') list.push('サービス時間: 平日9:00〜18:00 (祝日除外)');
  if (coverage === 'extended') list.push('サービス時間: 平日8:00〜22:00 + 土日祝は要相談');
  return list;
}

/** SLAをMarkdownとして整形 */
export function formatSlaAsMarkdown(s: Sla): string {
  const lines: string[] = [];
  lines.push(`# サービスレベル合意書 (SLA) - ${s.meta.system_name}`);
  lines.push('');
  lines.push(`発行日: ${s.meta.generated_at.slice(0, 10)} / 版数: ${s.meta.version}`);
  lines.push(`サービス時間: **${formatCoverage(s.meta.coverage)}** / 評価期間: ${s.meta.evaluation_period_days}日`);
  lines.push(`顧客タイプ: ${s.meta.client_type}`);
  lines.push('');
  lines.push('## 1. 可用性目標 (Availability Target)');
  lines.push('');
  lines.push(`- 目標稼働率: **${(s.meta.availability_target * 100).toFixed(2)}%**`);
  lines.push(`- 月間許容ダウンタイム: **${s.monthly_allowed_downtime_min}分** (エラーバジェット)`);
  lines.push(`- RTO (復旧時間目標): **${s.rto_minutes}分以内**`);
  lines.push(`- RPO (復旧地点目標): **${s.rpo_minutes}分以内**`);
  lines.push('');
  lines.push('## 2. 応答時間 (Response SLA)');
  lines.push('');
  lines.push('| Severity | 応答時間 | 復旧目標 | 営業日カウント |');
  lines.push('|----------|---------|---------|---------------|');
  for (const r of s.response_table) {
    lines.push(
      `| ${r.level} | ${formatMin(r.response_sla_min)} | ${formatMin(r.recovery_target_min)} | ${r.business_day_only ? '営業日のみ (祝日除外)' : '24h連続カウント'} |`
    );
  }
  lines.push('');
  lines.push('## 3. ペナルティ (Service Credit)');
  lines.push(`月間稼働率が${(s.service_credit.threshold_availability * 100).toFixed(0)}%を下回った場合、翌月保守料金から返金:`);
  lines.push('');
  for (const c of s.service_credit.credits) {
    lines.push(`- 稼働率 < ${(c.availability_below * 100).toFixed(0)}% → ${c.credit_percent}% サービスクレジット`);
  }
  lines.push('');
  lines.push(`> ${s.service_credit.note}`);
  lines.push('');
  lines.push('## 4. 除外事項');
  for (const e of s.exclusions) lines.push(`- ${e}`);
  lines.push('');
  lines.push('## 5. 計測方法');
  for (const m of s.measurement) lines.push(`- ${m}`);
  lines.push('');
  lines.push('## 6. レポーティング');
  for (const r of s.reporting) lines.push(`- ${r}`);
  lines.push('');
  lines.push('## 7. 営業日定義');
  lines.push('日本の祝日 (元日/成人/建国/天皇誕生/春分/昭和/憲法/みどり/こども/海/山/敬老/秋分/スポーツ/文化/勤労感謝) を除外。');
  lines.push('土日祝・年末年始 (12/29-1/3) は非営業日として扱う。');
  return lines.join('\n');
}

function formatCoverage(c: CoverageWindow): string {
  if (c === '24x365') return '24時間365日';
  if (c === 'business-hours') return '平日 9:00〜18:00 (土日祝除外)';
  return '平日 8:00〜22:00 + 土日祝要相談';
}

function formatMin(m: number): string {
  if (m < 60) return `${m}分以内`;
  if (m < 1440) return `${Math.floor(m / 60)}時間以内`;
  return `${Math.floor(m / 1440)}営業日以内`;
}
