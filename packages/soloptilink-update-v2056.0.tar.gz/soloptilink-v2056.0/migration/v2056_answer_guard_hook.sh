#!/usr/bin/env bash
# ============================================================
# v2056.0 全モード応答ガード (PFP-093 answer-guard-direct) の顧客端末登録 (2026-08-20)
# ------------------------------------------------------------
# 【何が壊れていたか (実測 2026-08-20)】
#   lib/hooks/centuria-answer-guard-direct.sh (PFP-093 全モード直接発火ラッパー・v2052.0) は
#   「boost 以外のモード経由の応答が answer-guard を素通りする」単一障害点を閉じるために
#   Stop hook へ直接配線する設計だった。開発機の ~/.claude/settings.json には登録されて
#   実発火していたが、【顧客端末へ登録する経路がどこにも無かった】
#   (migration/*.sh と installer/ を answer-guard で検索してヒット 0 件)。
#   v2055_reliability_hooks.sh で実測された「開発機でしか動いていない」型の再来。
#
# 【本 migration がすること】
#   ~/.claude/settings.json の Stop hook へ次の 1 エントリを冪等に登録する
#   (実体ファイルが存在するときだけ。存在しなければ何もせず、後で再試行できる)。
#     Stop  *  bash "$HOME/.soloptilink/lib/hooks/centuria-answer-guard-direct.sh"  (timeout 8)
#   ※ 配線表 (WIRINGS) は行を足すだけで増やせる形にしてある。相棒化計画 (10_配信計画 §0 /
#     owner 判断 D-05) で予定されている opinion-guard-direct は、実体ができた時点で
#     WIRINGS に 1 行足せば同じ migration で届く (2 本目の migration を書かない)。
#
# 【既存顧客への遡及】
#   auto-update.sh が起動のたびに migration/v*.sh を state 参照つきで実行するため、
#   本ファイルが配布物に含まれれば導入済み端末にも自動で行き渡る (1回だけ適用)。
#   新規導入は installer/SoloptiLinkAI-Setup.command / soloptilink-install.ps1 が
#   migration/ 配下を全実行することで登録される。
#
# 【安全側の原則】
#   - 冪等: 同じフック本体を指す登録が既にあれば何もしない (表記が $HOME/絶対パスで違っても二重登録しない)
#   - 必ずバックアップを取る (~/.claude/.backups/)
#   - 実体ファイル不在なら登録しない (存在しないフックを登録して毎回エラーを出させない)
#   - settings.json が JSON として読めないときは触らない (壊れた設定を {} で上書きしない)
#   - 追加が無いときは settings.json に一切書かない (顧客が手で整えた書式・並びを動かさない)
#   - python3 が無ければ何もせず正常終了 (state を書かない = 再試行可能)
#   - 失敗しても導入・更新そのものは絶対に止めない (exit 0)
#
# 【顧客端末での挙動】
#   登録される hook (answer-guard-direct → centuria-answer-guard.sh) は管理者端末
#   (~/.soloptilink/.admin_mode) では作動しない設計のため、開発機では顧客端末の挙動を
#   直接は見られない。SOLOPTILINK_CUSTOMER_SESSION=1 で強制有効化して良性応答が
#   素通りし・貶め応答だけが block されることを確認済み (2026-08-20)。
#   なお answer-guard 本体は v2038 登録の boost-completion-gate-hook.sh からも毎 Stop で
#   呼ばれており、顧客端末で「初めて作動する」わけではない (本 migration は二重化)。
#
# 【kill-switch】
#   SOLOPTILINK_ANSWER_GUARD_HOOK_INSTALL=off … 本 migration を no-op にする
#     (state を書かないので、外せば次回起動で適用される)
#   登録後にガードの働きを止めたい場合は hook 側の kill-switch を使う:
#     SOLOPTILINK_ANSWER_GUARD=off (centuria-answer-guard.sh が即 exit)
#
# CLI:
#   bash ~/.soloptilink/migration/v2056_answer_guard_hook.sh            (適用)
#   bash ~/.soloptilink/migration/v2056_answer_guard_hook.sh selftest   (両側判定)
# ============================================================
set -u

MIG_NAME="v2056_answer_guard_hook.r2"
SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
CLAUDE_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
SETTINGS_FILE="$CLAUDE_DIR/settings.json"
BACKUP_DIR="$CLAUDE_DIR/.backups"
LOG_FILE="$SL_DIR/.migration.log"
STATE_FILE="$SL_DIR/.migration-state.json"
HOOK_REL="lib/hooks/centuria-answer-guard-direct.sh"
# r2 の前提: どちらか一方でも実体があれば適用する (両方無ければ再試行可能なまま終了)
HOOK_REL2="lib/hooks/opinion-guard-direct.sh"

mig_log() {
    echo "$(date '+%Y-%m-%dT%H:%M:%S') [${MIG_NAME}] $1" >> "$LOG_FILE" 2>/dev/null || true
}

mig_apply() {
    mkdir -p "$SL_DIR" "$CLAUDE_DIR" "$BACKUP_DIR" 2>/dev/null || true
    mig_log "START"

    # kill-switch (state を書かない = 解除すれば次回適用される)
    case "$(printf '%s' "${SOLOPTILINK_ANSWER_GUARD_HOOK_INSTALL:-on}" | tr 'A-Z' 'a-z')" in
        off|0|false|no|disabled)
            mig_log "KILL_SWITCH SOLOPTILINK_ANSWER_GUARD_HOOK_INSTALL=off -> NOOP (retryable)"
            return 0
            ;;
    esac

    # 冪等: 適用済みなら NOOP
    if [ -f "$STATE_FILE" ] && grep -q "\"${MIG_NAME}\"" "$STATE_FILE" 2>/dev/null; then
        mig_log "ALREADY_APPLIED -> NOOP"
        return 0
    fi

    # 前提: フック実体があること (無いものを登録して毎回エラーを出させない)
    if [ ! -f "$SL_DIR/$HOOK_REL" ] && [ ! -f "$SL_DIR/$HOOK_REL2" ]; then
        mig_log "PRECONDITION_FAILED $HOOK_REL / $HOOK_REL2 not found (retryable)"
        return 0
    fi

    # 前提: python3 (無ければ再試行可能なまま終了)
    if ! command -v python3 >/dev/null 2>&1; then
        mig_log "PRECONDITION_FAILED python3 not found (retryable)"
        return 0
    fi

    # バックアップ
    TS="$(date +%Y%m%dT%H%M%S)"
    if [ -f "$SETTINGS_FILE" ]; then
        cp -p "$SETTINGS_FILE" "$BACKUP_DIR/settings.json.pre-${MIG_NAME}-${TS}" 2>/dev/null || true
        mig_log "BACKUP $BACKUP_DIR/settings.json.pre-${MIG_NAME}-${TS}"
    fi

    WIRE_RESULT="$(SETTINGS_FILE="$SETTINGS_FILE" SL_DIR="$SL_DIR" python3 - <<'PYEOF' 2>>"$LOG_FILE"
import json, os, sys, shutil

sp = os.environ["SETTINGS_FILE"]
sl_dir = os.environ["SL_DIR"]

# フック本体の場所は $HOME 直下の既定配置のときだけ "$HOME/..." 表記を使う。
# ★開発機に既に入っている表記 (settings.json の Stop 配下) と完全一致させることが冪等性の要。
home = os.path.expanduser("~")
default_sl = os.path.join(home, ".soloptilink")
def ref_for(rel):
    p = os.path.join(sl_dir, rel)
    if os.path.abspath(p) == os.path.abspath(os.path.join(default_sl, rel)):
        return '"$HOME/.soloptilink/%s"' % rel
    return '"%s"' % p

# 配線表: (event, matcher, 相対パス, 冪等判定に使うファイル名, timeout 秒)
#   ★冪等判定のファイル名は「-direct.sh」まで含める。"centuria-answer-guard.sh" だけで見ると
#     boost-completion-gate-hook 等の別 hook に含まれる同名断片を誤って「登録済み」と数える。
WIRINGS = [
    ("Stop", "*", "lib/hooks/centuria-answer-guard-direct.sh", "centuria-answer-guard-direct.sh", 8),
    # ★2026-08-20 相棒化 P1: 所見ガード (作業報告に判断・懸念・次の一手が添えられているかを見る)。
    #   実体が届くまでは os.path.isfile で黙って待つため、先に行を足しておいても安全。
    ("Stop", "*", "lib/hooks/opinion-guard-direct.sh", "opinion-guard-direct.sh", 10),
]

exists = os.path.isfile(sp) and os.path.getsize(sp) > 0
if exists:
    try:
        with open(sp) as f:
            data = json.load(f)
    except Exception:
        # 読めない設定を {} で上書きしない (壊れた設定を消して顧客の他設定を失わせない)
        print("ABORT_PARSE_FAIL")
        sys.exit(0)
else:
    data = {}
if not isinstance(data, dict):
    print("ABORT_NOT_DICT")
    sys.exit(0)

hooks = data.setdefault("hooks", {})
if not isinstance(hooks, dict):
    print("ABORT_HOOKS_NOT_DICT")
    sys.exit(0)

added = 0
pending = 0
for event, matcher, rel, key, timeout in WIRINGS:
    # 実体が無い行は登録しない (WIRINGS に将来行を足しても、実体が届くまでは黙って待つ)
    if not os.path.isfile(os.path.join(sl_dir, rel)):
        # ★2026-08-20 是正: 実体待ちの行があるまま「適用済み」を書くと、
        #   実体が後から届いてもこの migration は二度と走らず、永久に配線されない。
        pending += 1
        continue
    cmd = "bash %s" % ref_for(rel)
    arr = hooks.setdefault(event, [])
    if not isinstance(arr, list):
        arr = []
        hooks[event] = arr
    # 冪等判定: 「同じフック本体を呼ぶ登録」が既にあるか
    # (完全一致だけで見ると、絶対パス表記/$HOME 表記の違いで二重登録になる)
    found = False
    for entry in arr:
        if not isinstance(entry, dict):
            continue
        for h in (entry.get("hooks") or []):
            if not isinstance(h, dict):
                continue
            if key in (h.get("command") or ""):
                found = True
                break
        if found:
            break
    if found:
        continue
    arr.append({
        "matcher": matcher,
        "hooks": [{"type": "command", "command": cmd, "timeout": timeout}],
    })
    added += 1

# 追加が無いなら settings.json には一切書かない
# (顧客が手で整えた書式・並びを、意味の変わらない書き換えで動かさない)
if added == 0:
    print("WIRED added=0 pending=%d (already-wired / no write)" % pending)
    sys.exit(0)

tmp = sp + ".tmp.%d" % os.getpid()
with open(tmp, "w") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
    f.write("\n")
if exists:
    try:
        shutil.copymode(sp, tmp)   # 権限ビットを引き継ぐ (0600 で運用している端末を 0644 にしない)
    except Exception:
        pass
os.replace(tmp, sp)
print("WIRED added=%d pending=%d" % (added, pending))
PYEOF
)"

    case "$WIRE_RESULT" in
        WIRED*)
            mig_log "WIRE_SUCCESS ($WIRE_RESULT)"
            # ★実体待ちの配線が残っている間は state を書かない (次回の起動で再試行する)。
            #   書いてしまうと、後から実体が届いてもこの migration は二度と走らない。
            case "$WIRE_RESULT" in
                *"pending=0"*) : ;;
                *)
                    mig_log "PARTIAL ($WIRE_RESULT) -> state を書かず再試行可能にします"
                    return 0
                    ;;
            esac
            ;;
        *)
            mig_log "WIRE_FAILED ($WIRE_RESULT) -> state を書かず再試行可能にします"
            return 0
            ;;
    esac

    # state 追記 (atomic)
    APPLIED_AT="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
    STATE_FILE="$STATE_FILE" MIG_NAME="$MIG_NAME" APPLIED_AT="$APPLIED_AT" python3 - <<'PYEOF' 2>>"$LOG_FILE"
import json, os
sf = os.environ['STATE_FILE']
try:
    with open(sf) as f:
        data = json.load(f)
except Exception:
    data = {}
if not isinstance(data, dict):
    data = {}
data[os.environ['MIG_NAME']] = {"applied_at": os.environ['APPLIED_AT']}
tmp = sf + ".tmp.%d" % os.getpid()
with open(tmp, "w") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
os.replace(tmp, sf)
PYEOF

    mig_log "DONE applied_at=${APPLIED_AT} ($WIRE_RESULT)"
    return 0
}

# ------------------------------------------------------------
# selftest: 両側判定 (隔離した仮想 HOME で実走・実際の ~/.claude は触らない)
#   H1 健全側: 未登録の settings.json へ Stop 1 エントリ (timeout 8) が登録される
#   H2 冪等  : 2回目で追加ゼロ (state を消しても二重登録しない)
#   H3 冪等  : 絶対パス表記で先に入っていても二重登録しない
#   H4 欠陥側: フック実体が無ければ登録しない (存在しないフックを登録しない)
#   H5 kill-switch: SOLOPTILINK_ANSWER_GUARD_HOOK_INSTALL=off で何も登録しない
#   H6 誤認防止: 別 hook (boost-completion-gate / centuria-answer-guard.sh 直呼び) が
#               既に入っていても「登録済み」と誤認せず、direct を登録する
#   H7 非破壊 : settings.json が壊れた JSON なら 1 バイトも書き換えない
#   H8 保全  : 既存の他キー (permissions 等) と他フックを一切失わない
# ------------------------------------------------------------
mig_selftest() {
    local self rc=0
    self="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
    # ★root は意図的にグローバル: EXIT トラップは関数 return 後(スクリプト終了時)にも
    #   発火するため local にすると set -u で unbound になる (既知の罠)
    root="$(mktemp -d "${TMPDIR:-/tmp}/v2056aghook.XXXXXX")" || return 1
    trap 'rm -rf "$root" 2>/dev/null || true' EXIT INT TERM

    _mk_env() { # $1=name  → SL_DIR/CLAUDE_DIR を用意し、フック実体も置く
        mkdir -p "$root/$1/sl/lib/hooks" "$root/$1/claude"
        printf '#!/usr/bin/env bash\nexit 0\n' > "$root/$1/sl/lib/hooks/centuria-answer-guard-direct.sh"
        printf '{}\n' > "$root/$1/claude/settings.json"
    }
    _add_opinion() { # $1=name → 所見ガードの実体も置く (r2 の 2 本目)
        printf '#!/usr/bin/env bash\nexit 0\n' > "$root/$1/sl/lib/hooks/opinion-guard-direct.sh"
    }
    _count_op() { # $1=settings.json → 所見ガードを指す登録の件数
        python3 - "$1" <<'PY2'
import json, sys
try:
    d = json.load(open(sys.argv[1]))
except Exception:
    print(0); raise SystemExit(0)
n = 0
for _ev, arr in (d.get("hooks") or {}).items():
    for m in (arr or []):
        for h in (m.get("hooks") or []):
            if "opinion-guard-direct.sh" in (h.get("command") or ""):
                n += 1
print(n)
PY2
    }
    _count() { # $1=settings.json → direct ラッパーを指す Stop 登録の件数
        python3 - "$1" <<'PY'
import json, sys
try:
    d = json.load(open(sys.argv[1]))
except Exception:
    print(0); raise SystemExit(0)
n = 0
for _ev, arr in (d.get("hooks") or {}).items():
    for m in (arr or []):
        for h in (m.get("hooks") or []):
            if "centuria-answer-guard-direct.sh" in (h.get("command") or ""):
                n += 1
print(n)
PY
    }
    _timeout_ok() { # $1=settings.json → 登録の timeout が 8 で Stop 配下にあるか
        python3 - "$1" <<'PY'
import json, sys
try:
    d = json.load(open(sys.argv[1]))
except Exception:
    print("no"); raise SystemExit(0)
ok = False
for m in (d.get("hooks") or {}).get("Stop") or []:
    for h in (m.get("hooks") or []):
        if "centuria-answer-guard-direct.sh" in (h.get("command") or "") and h.get("timeout") == 8:
            ok = True
print("yes" if ok else "no")
PY
    }
    _run() { # $1=name, 残りは追加 env
        local name="$1"; shift
        env "$@" SOLOPTILINK_DIR="$root/$name/sl" CLAUDE_CONFIG_DIR="$root/$name/claude" \
            bash "$self" >/dev/null 2>&1
    }

    # H1 健全側
    _mk_env h1; _run h1
    local n1 t1; n1="$(_count "$root/h1/claude/settings.json")"; t1="$(_timeout_ok "$root/h1/claude/settings.json")"
    if [ "$n1" = "1" ] && [ "$t1" = "yes" ]; then echo "  [OK] 健全側: Stop へ 1 エントリ (timeout 8) を登録"; else echo "  [FAIL] 健全側: 登録数=$n1 timeout8=$t1 (期待 1/yes)"; rc=1; fi

    # H2 冪等 (2回目)
    rm -f "$root/h1/sl/.migration-state.json"   # state を消しても二重登録しないこと
    _run h1
    local n2; n2="$(_count "$root/h1/claude/settings.json")"
    if [ "$n2" = "1" ]; then echo "  [OK] 冪等: 再実行しても 1 のまま (二重登録なし)"; else echo "  [FAIL] 冪等性違反: 登録数=$n2"; rc=1; fi

    # H3 表記違い (絶対パス) が先に入っていても二重登録しない
    _mk_env h3
    python3 - "$root/h3/claude/settings.json" "$root/h3/sl/lib/hooks/centuria-answer-guard-direct.sh" <<'PY'
import json, sys
p, hp = sys.argv[1], sys.argv[2]
d = {"hooks": {"Stop": [{"matcher": "*", "hooks": [
    {"type": "command", "command": 'bash "%s"' % hp, "timeout": 8}]}]}}
json.dump(d, open(p, "w"), indent=2, ensure_ascii=False)
PY
    _run h3
    local n3; n3="$(_count "$root/h3/claude/settings.json")"
    if [ "$n3" = "1" ]; then echo "  [OK] 表記違い: 既存の絶対パス登録を重複させない (合計1)"; else echo "  [FAIL] 表記違いで二重登録: 登録数=$n3 (期待1)"; rc=1; fi

    # H4 欠陥側: フック実体が無ければ登録しない
    _mk_env h4; rm -f "$root/h4/sl/lib/hooks/centuria-answer-guard-direct.sh"
    _run h4
    local n4; n4="$(_count "$root/h4/claude/settings.json")"
    if [ "$n4" = "0" ]; then echo "  [OK] 欠陥側: 実体が無ければ登録しない (存在しないフックを登録しない)"; else echo "  [FAIL] 実体不在でも登録した: 登録数=$n4"; rc=1; fi

    # H5 kill-switch
    _mk_env h5
    _run h5 SOLOPTILINK_ANSWER_GUARD_HOOK_INSTALL=off
    local n5; n5="$(_count "$root/h5/claude/settings.json")"
    if [ "$n5" = "0" ]; then echo "  [OK] kill-switch: off で何も登録しない (従来動作)"; else echo "  [FAIL] kill-switch off でも登録した: 登録数=$n5"; rc=1; fi

    # H6 誤認防止: 別 hook が Stop に入っていても「登録済み」と誤認しない
    _mk_env h6
    python3 - "$root/h6/claude/settings.json" <<'PY'
import json, sys
p = sys.argv[1]
d = {"hooks": {"Stop": [
    {"matcher": "*", "hooks": [{"type": "command", "command": 'bash "$HOME/.soloptilink/lib/hooks/boost-completion-gate-hook.sh"', "timeout": 360}]},
    {"matcher": "*", "hooks": [{"type": "command", "command": 'bash "$HOME/.soloptilink/lib/hooks/centuria-answer-guard.sh" /tmp/x.jsonl'}]},
]}}
json.dump(d, open(p, "w"), indent=2, ensure_ascii=False)
PY
    _run h6
    local n6 o6; n6="$(_count "$root/h6/claude/settings.json")"
    o6="$(python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(len(d["hooks"]["Stop"]))' "$root/h6/claude/settings.json" 2>/dev/null)"
    if [ "$n6" = "1" ] && [ "$o6" = "3" ]; then echo "  [OK] 誤認防止: 別 hook (cgate / answer-guard.sh 直呼び) を登録済みと数えず direct を追加 (Stop=3件)"; else echo "  [FAIL] 誤認防止: direct=$n6 Stop総数=$o6 (期待 1/3)"; rc=1; fi

    # H7 非破壊: 壊れた JSON は 1 バイトも書き換えない
    _mk_env h7
    printf '{ "hooks": { "Stop": [ ] }, \n' > "$root/h7/claude/settings.json"   # 閉じていない
    local b7; b7="$(cksum < "$root/h7/claude/settings.json")"
    _run h7
    local a7; a7="$(cksum < "$root/h7/claude/settings.json")"
    local s7=no; [ -f "$root/h7/sl/.migration-state.json" ] && s7=yes
    if [ "$b7" = "$a7" ] && [ "$s7" = "no" ]; then echo "  [OK] 非破壊: 壊れた JSON は書き換えず state も書かない (再試行可能)"; else echo "  [FAIL] 非破壊: 壊れた JSON を書き換えた/state を書いた (same=$([ "$b7" = "$a7" ] && echo yes || echo no) state=$s7)"; rc=1; fi

    # H8 保全: 既存の他キー・他フックを失わない
    _mk_env h8
    python3 - "$root/h8/claude/settings.json" <<'PY'
import json, sys
p = sys.argv[1]
d = {"permissions": {"allow": ["Bash(ls:*)"]}, "env": {"FOO": "bar"},
     "hooks": {"SessionStart": [{"matcher": "*", "hooks": [{"type": "command", "command": "bash ~/.soloptilink/auto-update.sh"}]}],
               "Stop": [{"matcher": "*", "hooks": [{"type": "command", "command": 'bash "$HOME/.soloptilink/lib/hooks/boost-completion-gate-hook.sh"', "timeout": 360}]}]}}
json.dump(d, open(p, "w"), indent=2, ensure_ascii=False)
PY
    _run h8
    local k8; k8="$(python3 - "$root/h8/claude/settings.json" <<'PY'
import json, sys
try:
    d = json.load(open(sys.argv[1]))
    ok = (d.get("permissions", {}).get("allow") == ["Bash(ls:*)"]
          and d.get("env", {}).get("FOO") == "bar"
          and "auto-update.sh" in json.dumps(d["hooks"]["SessionStart"])
          and "boost-completion-gate-hook.sh" in json.dumps(d["hooks"]["Stop"])
          and "centuria-answer-guard-direct.sh" in json.dumps(d["hooks"]["Stop"]))
    print("yes" if ok else "no")
except Exception:
    print("no")
PY
)"
    if [ "$k8" = "yes" ]; then echo "  [OK] 保全: permissions/env/他フックを失わずに追加 (JSON 妥当)"; else echo "  [FAIL] 保全: 既存キー/フックが失われた or JSON 不正"; rc=1; fi

    # H9 (r2) 所見ガードも同じ 1 本の migration で届く / 冪等 / 実体不在なら登録しない
    _mk_env h9; _add_opinion h9; _run h9
    local n9a n9b; n9a="$(_count "$root/h9/claude/settings.json")"; n9b="$(_count_op "$root/h9/claude/settings.json")"
    rm -f "$root/h9/sl/.migration-state.json"; _run h9
    local n9c; n9c="$(_count_op "$root/h9/claude/settings.json")"
    if [ "$n9a" = "1" ] && [ "$n9b" = "1" ] && [ "$n9c" = "1" ]; then
        echo "  [OK] r2: 応答ガードと所見ガードの 2 本を 1 つの migration で登録・冪等"
    else echo "  [FAIL] r2: 登録数 answer=$n9a opinion=$n9b 再実行後=$n9c (期待 1/1/1)"; rc=1; fi
    # H10 (r2) 所見ガードの実体だけが無い端末では、応答ガードだけを登録して黙って待つ
    _mk_env h10; _run h10
    local n10; n10="$(_count_op "$root/h10/claude/settings.json")"
    if [ "$n10" = "0" ]; then echo "  [OK] r2: 実体が届いていない所見ガードは登録せず待つ"; else echo "  [FAIL] r2: 実体不在の所見ガードを登録した"; rc=1; fi

    # H11 (r2) 部分適用では state を書かない = 実体が後から届けば必ず配線される
    _mk_env h11; _run h11
    local s11=no; [ -f "$root/h11/sl/.migration-state.json" ] && s11=yes
    _add_opinion h11; _run h11
    local n11; n11="$(_count_op "$root/h11/claude/settings.json")"
    local s11b=no; [ -f "$root/h11/sl/.migration-state.json" ] && s11b=yes
    if [ "$s11" = "no" ] && [ "$n11" = "1" ] && [ "$s11b" = "yes" ]; then
        echo "  [OK] r2: 実体待ちの間は適用済みにせず、届いた時点で配線して適用済みにする"
    else echo "  [FAIL] r2: 部分適用で適用済みにした (待ち中state=$s11 後の登録=$n11 完了state=$s11b)"; rc=1; fi

    local proven=false; [ "$rc" -eq 0 ] && proven=true
    printf '{"tool":"%s","healthy_registers_1":%s,"idempotent":%s,"no_dup_on_pathform":%s,"absent_hook_not_registered":%s,"killswitch_noop":%s,"no_false_already_wired":%s,"broken_json_untouched":%s,"other_keys_preserved":%s,"discrimination_proven":%s}\n' \
        "$MIG_NAME" \
        "$([ "$n1" = 1 ] && [ "$t1" = yes ] && echo true || echo false)" \
        "$([ "$n2" = 1 ] && echo true || echo false)" \
        "$([ "$n3" = 1 ] && echo true || echo false)" \
        "$([ "$n4" = 0 ] && echo true || echo false)" \
        "$([ "$n5" = 0 ] && echo true || echo false)" \
        "$([ "$n6" = 1 ] && [ "$o6" = 3 ] && echo true || echo false)" \
        "$([ "$b7" = "$a7" ] && [ "$s7" = no ] && echo true || echo false)" \
        "$([ "$k8" = yes ] && echo true || echo false)" \
        "$proven"
    # verify.d 審査#6 (両側判定の機械判定) 向け 1 行
    if [ "$proven" = true ]; then
        echo "BOTHSIDED_SELFTEST:${MIG_NAME}:PASS:FAIL:健全側=未登録へ1件登録・冪等 / 欠陥側=実体不在・kill-switch・壊れたJSONで登録せず"
    else
        echo "BOTHSIDED_SELFTEST:${MIG_NAME}:UNMEASURED:UNMEASURED:両側判定のいずれかが不成立 (上の [FAIL] 行を参照)"
    fi
    return $rc
}

case "${1:-apply}" in
    selftest|--bothsided-selftest) mig_selftest; exit $? ;;
    apply|"") mig_apply; exit 0 ;;
    *)        mig_apply; exit 0 ;;
esac
