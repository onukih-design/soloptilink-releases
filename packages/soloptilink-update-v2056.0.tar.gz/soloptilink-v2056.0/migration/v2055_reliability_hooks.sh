#!/usr/bin/env bash
# ============================================================
# v2055.0 エラーゼロ化4本柱 ライフサイクル結線の顧客端末登録 (2026-08-01)
# ------------------------------------------------------------
# 【何が壊れていたか (実測)】
#   エラーゼロ化4本柱 (見張り番 / 資源ガバナー / 完成宣言 / デモ前チェック) を
#   Claude Code のライフサイクルへ載せる唯一の結線層
#   lib/hooks/reliability-lifecycle-hook.sh は、開発機の ~/.claude/settings.json には
#   7エントリ登録されて実発火していたが、【顧客端末へ登録する経路がどこにも無かった】。
#   installer/SoloptiLinkAI-Setup.command は自動更新フック (v2027) しか登録せず、
#   migration にも自動更新経路にも本フックの登録は存在しなかった。
#   つまり柱2 (資源ガバナー) と柱4 (完成宣言) は【開発機でしか動いていなかった】。
#
# 【本 migration がすること】
#   ~/.claude/settings.json へ次の7エントリを冪等に登録する
#   (実体ファイルが存在するときだけ。存在しなければ何もせず、後で再試行できる)。
#     UserPromptSubmit  *          prompt      lease延命 + デモ前チェック自動実行
#     PreToolUse        Task|Agent govern      並列起動前の資源チェック
#     PostToolUse       Bash       adopt       devサーバー起動検知 → 見張り番起動
#     Stop              *          declare     完成宣言の自動生成
#     SessionStart      *          sweep       前回セッションの見張り番の後始末
#     SessionEnd        *          release     このセッションの見張り番を停止
#     SubagentStop      *          agent_done  並列エージェント終了の反映
#
# 【既存顧客への遡及】
#   auto-update.sh が起動のたびに migration/v*.sh を state 参照つきで実行するため、
#   本ファイルが配布物に含まれれば導入済み端末にも自動で行き渡る (1回だけ適用)。
#   新規導入は installer/SoloptiLinkAI-Setup.command の STEP 5.5 が全 migration を
#   実行することで登録される。
#
# 【安全側の原則】
#   - 冪等: コマンド文字列が既に配線済みなら何もしない (二重登録しない)
#   - 必ずバックアップを取る (~/.claude/.backups/)
#   - 実体ファイル不在なら登録しない (存在しないフックを登録して毎回エラーを出させない)
#   - python3 が無ければ何もせず正常終了 (state を書かない = 再試行可能)
#   - 失敗しても導入・更新そのものは絶対に止めない (exit 0)
#
# 【kill-switch】
#   SOLOPTILINK_RELIABILITY_HOOK_INSTALL=off … 本 migration を no-op にする
#     (state を書かないので、外せば次回起動で適用される)
#   登録後にフックの働きを止めたい場合は結線層側の kill-switch を使う:
#     ENABLE_RELIABILITY_WIRING=off (結線層まるごと従来動作へ)
#
# CLI:
#   bash ~/.soloptilink/migration/v2055_reliability_hooks.sh            (適用)
#   bash ~/.soloptilink/migration/v2055_reliability_hooks.sh selftest   (両側判定)
# ============================================================
set -u

MIG_NAME="v2055_reliability_hooks"
SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
CLAUDE_DIR="${CLAUDE_CONFIG_DIR:-$HOME/.claude}"
SETTINGS_FILE="$CLAUDE_DIR/settings.json"
BACKUP_DIR="$CLAUDE_DIR/.backups"
LOG_FILE="$SL_DIR/.migration.log"
STATE_FILE="$SL_DIR/.migration-state.json"
HOOK_REL="lib/hooks/reliability-lifecycle-hook.sh"

mig_log() {
    echo "$(date '+%Y-%m-%dT%H:%M:%S') [${MIG_NAME}] $1" >> "$LOG_FILE" 2>/dev/null || true
}

mig_apply() {
    mkdir -p "$SL_DIR" "$CLAUDE_DIR" "$BACKUP_DIR" 2>/dev/null || true
    mig_log "START"

    # kill-switch (state を書かない = 解除すれば次回適用される)
    case "$(printf '%s' "${SOLOPTILINK_RELIABILITY_HOOK_INSTALL:-on}" | tr 'A-Z' 'a-z')" in
        off|0|false|no|disabled)
            mig_log "KILL_SWITCH SOLOPTILINK_RELIABILITY_HOOK_INSTALL=off -> NOOP (retryable)"
            return 0
            ;;
    esac

    # 冪等: 適用済みなら NOOP
    if [ -f "$STATE_FILE" ] && grep -q "\"${MIG_NAME}\"" "$STATE_FILE" 2>/dev/null; then
        mig_log "ALREADY_APPLIED -> NOOP"
        return 0
    fi

    # 前提: 結線層の実体があること (無いものを登録して毎回エラーを出させない)
    if [ ! -f "$SL_DIR/$HOOK_REL" ]; then
        mig_log "PRECONDITION_FAILED $HOOK_REL not found (retryable)"
        return 0
    fi

    # 前提: python3 (無ければ再試行可能なまま終了)
    if ! command -v python3 >/dev/null 2>&1; then
        mig_log "PRECONDITION_FAILED python3 not found (retryable)"
        return 0
    fi

    # バックアップ
    TS="$(date +%Y%m%dT%H%M%S)"
    if [ -f "$SETTINGS_FILE" ]; then
        cp -p "$SETTINGS_FILE" "$BACKUP_DIR/settings.json.pre-${MIG_NAME}-${TS}" 2>/dev/null || true
        mig_log "BACKUP $BACKUP_DIR/settings.json.pre-${MIG_NAME}-${TS}"
    fi

    WIRE_RESULT="$(SETTINGS_FILE="$SETTINGS_FILE" HOOK_PATH="$SL_DIR/$HOOK_REL" python3 - <<'PYEOF' 2>>"$LOG_FILE"
import json, os, sys, tempfile

sp = os.environ["SETTINGS_FILE"]
hook_path = os.environ["HOOK_PATH"]

# フック本体の場所は $HOME 直下の既定配置のときだけ "$HOME/..." 表記を使う。
# ★開発機に既に入っている表記と完全一致させることが冪等性の要 (表記が違うと二重登録になる)。
home = os.path.expanduser("~")
default = os.path.join(home, ".soloptilink", "lib", "hooks", "reliability-lifecycle-hook.sh")
if os.path.abspath(hook_path) == os.path.abspath(default):
    ref = '"$HOME/.soloptilink/lib/hooks/reliability-lifecycle-hook.sh"'
else:
    ref = '"%s"' % hook_path

WIRINGS = [
    ("UserPromptSubmit", "*",          "prompt",     30),
    ("PreToolUse",       "Task|Agent", "govern",     20),
    ("PostToolUse",      "Bash",       "adopt",      30),
    ("Stop",             "*",          "declare",    60),
    ("SessionStart",     "*",          "sweep",      30),
    ("SessionEnd",       "*",          "release",    30),
    ("SubagentStop",     "*",          "agent_done", 15),
]

try:
    with open(sp) as f:
        data = json.load(f)
except Exception:
    data = {}
if not isinstance(data, dict):
    print("ABORT_NOT_DICT")
    sys.exit(0)

hooks = data.setdefault("hooks", {})
if not isinstance(hooks, dict):
    print("ABORT_HOOKS_NOT_DICT")
    sys.exit(0)

added = 0
for event, matcher, mode, timeout in WIRINGS:
    cmd = "bash %s %s" % (ref, mode)
    arr = hooks.setdefault(event, [])
    if not isinstance(arr, list):
        arr = []
        hooks[event] = arr
    # 冪等判定: 「同じフック本体を同じモードで呼ぶ登録」が既にあるか
    # (完全一致だけで見ると、絶対パス表記/$HOME 表記の違いで二重登録になる)
    found = False
    for entry in arr:
        if not isinstance(entry, dict):
            continue
        for h in (entry.get("hooks") or []):
            if not isinstance(h, dict):
                continue
            c = h.get("command") or ""
            if "reliability-lifecycle-hook.sh" in c and c.rstrip().endswith(" " + mode):
                found = True
                break
        if found:
            break
    if found:
        continue
    arr.append({
        "matcher": matcher,
        "hooks": [{"type": "command", "command": cmd, "timeout": timeout}],
    })
    added += 1

# 追加が無いなら settings.json には一切書かない
# (顧客が手で整えた書式・並びを、意味の変わらない書き換えで動かさない)
if added == 0:
    print("WIRED added=0 (already-wired / no write)")
    sys.exit(0)

tmp = sp + ".tmp.%d" % os.getpid()
with open(tmp, "w") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
os.replace(tmp, sp)
print("WIRED added=%d" % added)
PYEOF
)"

    case "$WIRE_RESULT" in
        WIRED*)
            mig_log "WIRE_SUCCESS ($WIRE_RESULT)"
            ;;
        *)
            mig_log "WIRE_FAILED ($WIRE_RESULT) -> state を書かず再試行可能にします"
            return 0
            ;;
    esac

    # state 追記 (atomic)
    APPLIED_AT="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
    STATE_FILE="$STATE_FILE" MIG_NAME="$MIG_NAME" APPLIED_AT="$APPLIED_AT" python3 - <<'PYEOF' 2>>"$LOG_FILE"
import json, os
sf = os.environ['STATE_FILE']
try:
    with open(sf) as f:
        data = json.load(f)
except Exception:
    data = {}
if not isinstance(data, dict):
    data = {}
data[os.environ['MIG_NAME']] = {"applied_at": os.environ['APPLIED_AT']}
tmp = sf + ".tmp.%d" % os.getpid()
with open(tmp, "w") as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
os.replace(tmp, sf)
PYEOF

    mig_log "DONE applied_at=${APPLIED_AT} ($WIRE_RESULT)"
    return 0
}

# ------------------------------------------------------------
# selftest: 両側判定 (隔離した仮想 HOME で実走)
#   H1 健全側: 未登録の settings.json へ 7エントリが登録される
#   H2 冪等  : 2回目で追加ゼロ (二重登録しない)
#   H3 冪等  : 絶対パス表記で先に入っていても二重登録しない
#   H4 欠陥側: 結線層の実体が無ければ登録しない (存在しないフックを登録しない)
#   H5 kill-switch: SOLOPTILINK_RELIABILITY_HOOK_INSTALL=off で何も登録しない
# ------------------------------------------------------------
mig_selftest() {
    local self rc=0
    self="$(cd "$(dirname "$0")" && pwd)/$(basename "$0")"
    # ★root は意図的にグローバル: EXIT トラップは関数 return 後(スクリプト終了時)にも
    #   発火するため local にすると set -u で unbound になる (既知の罠)
    root="$(mktemp -d "${TMPDIR:-/tmp}/v2055hook.XXXXXX")" || return 1
    trap 'rm -rf "$root" 2>/dev/null || true' EXIT INT TERM

    _mk_env() { # $1=name  → SL_DIR/CLAUDE_DIR を用意し、結線層の実体も置く
        mkdir -p "$root/$1/sl/lib/hooks" "$root/$1/claude"
        printf '#!/usr/bin/env bash\nexit 0\n' > "$root/$1/sl/lib/hooks/reliability-lifecycle-hook.sh"
        printf '{}\n' > "$root/$1/claude/settings.json"
    }
    _count() { # $1=settings.json → 結線層を指す登録の件数
        python3 - "$1" <<'PY'
import json, sys
try:
    d = json.load(open(sys.argv[1]))
except Exception:
    print(0); raise SystemExit(0)
n = 0
for _ev, arr in (d.get("hooks") or {}).items():
    for m in (arr or []):
        for h in (m.get("hooks") or []):
            if "reliability-lifecycle-hook.sh" in (h.get("command") or ""):
                n += 1
print(n)
PY
    }
    _run() { # $1=name, 残りは追加 env
        local name="$1"; shift
        env "$@" SOLOPTILINK_DIR="$root/$name/sl" CLAUDE_CONFIG_DIR="$root/$name/claude" \
            bash "$self" >/dev/null 2>&1
    }

    # H1 健全側
    _mk_env h1; _run h1
    local n1; n1="$(_count "$root/h1/claude/settings.json")"
    if [ "$n1" = "7" ]; then echo "  [OK] 健全側: 7エントリを登録"; else echo "  [FAIL] 健全側: 登録数=$n1 (期待7)"; rc=1; fi

    # H2 冪等 (2回目)
    rm -f "$root/h1/sl/.migration-state.json"   # state を消しても二重登録しないこと
    _run h1
    local n2; n2="$(_count "$root/h1/claude/settings.json")"
    if [ "$n2" = "7" ]; then echo "  [OK] 冪等: 再実行しても 7 のまま (二重登録なし)"; else echo "  [FAIL] 冪等性違反: 登録数=$n2"; rc=1; fi

    # H3 表記違い (絶対パス) が先に入っていても二重登録しない
    _mk_env h3
    python3 - "$root/h3/claude/settings.json" "$root/h3/sl/lib/hooks/reliability-lifecycle-hook.sh" <<'PY'
import json, sys
p, hp = sys.argv[1], sys.argv[2]
d = {"hooks": {"Stop": [{"matcher": "*", "hooks": [
    {"type": "command", "command": 'bash "%s" declare' % hp, "timeout": 60}]}]}}
json.dump(d, open(p, "w"), indent=2, ensure_ascii=False)
PY
    _run h3
    local n3; n3="$(_count "$root/h3/claude/settings.json")"
    if [ "$n3" = "7" ]; then echo "  [OK] 表記違い: 既存の絶対パス登録を重複させない (合計7)"; else echo "  [FAIL] 表記違いで二重登録: 登録数=$n3 (期待7)"; rc=1; fi

    # H4 欠陥側: 結線層の実体が無ければ登録しない
    _mk_env h4; rm -f "$root/h4/sl/lib/hooks/reliability-lifecycle-hook.sh"
    _run h4
    local n4; n4="$(_count "$root/h4/claude/settings.json")"
    if [ "$n4" = "0" ]; then echo "  [OK] 欠陥側: 実体が無ければ登録しない (存在しないフックを登録しない)"; else echo "  [FAIL] 実体不在でも登録した: 登録数=$n4"; rc=1; fi

    # H5 kill-switch
    _mk_env h5
    _run h5 SOLOPTILINK_RELIABILITY_HOOK_INSTALL=off
    local n5; n5="$(_count "$root/h5/claude/settings.json")"
    if [ "$n5" = "0" ]; then echo "  [OK] kill-switch: off で何も登録しない (従来動作)"; else echo "  [FAIL] kill-switch off でも登録した: 登録数=$n5"; rc=1; fi

    local proven=false; [ "$rc" -eq 0 ] && proven=true
    printf '{"tool":"%s","healthy_registers_7":%s,"idempotent":%s,"no_dup_on_pathform":%s,"absent_hook_not_registered":%s,"killswitch_noop":%s,"discrimination_proven":%s}\n' \
        "$MIG_NAME" \
        "$([ "$n1" = 7 ] && echo true || echo false)" \
        "$([ "$n2" = 7 ] && echo true || echo false)" \
        "$([ "$n3" = 7 ] && echo true || echo false)" \
        "$([ "$n4" = 0 ] && echo true || echo false)" \
        "$([ "$n5" = 0 ] && echo true || echo false)" \
        "$proven"
    return $rc
}

case "${1:-apply}" in
    selftest) mig_selftest; exit $? ;;
    apply|"") mig_apply; exit 0 ;;
    *)        mig_apply; exit 0 ;;
esac
