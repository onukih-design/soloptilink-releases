#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI — Mac ダブルクリック起動インストーラ (.command)
# =============================================================================
# 顧客は Finder からこのファイルをダブルクリックするだけで:
#   1. Terminal.app が自動起動
#   2. 同梱パッケージ本体を ~/.soloptilink へ配置 (自己完結ZIP)
#      ※ 本体が無い場合のみ tar.gz / ネットワークから自動取得
#   3. アーキ(arm64/Intel)に合った Go ランチャーを配置
#   4. Claude Desktop の MCP サーバー設定を自動登録
#   5. 端末認証 (--activate) を自動チェーン
#   6. 完了画面まで自動誘導
#
# 配布レイアウト対応:
#   現行の per-platform ZIP (SoloptiLinkAI_vX.Y_Mac-*.zip) は
#   「展開済みパッケージ本体 + soloptilink バイナリ + この .command」が
#   同一フォルダに並ぶ自己完結キット。本スクリプトはそのレイアウトを
#   第一に検出して動作する (旧 .command は tar.gz 同梱前提で現行ZIPでは
#   動かなかった)。tar.gz 同梱キット / ネットワーク取得にもフォールバックする。
#
# Compliance:
#   - PFP-029 (cmd 窓即閉じ事案) 同等の堅牢設計: STEP マーカー / END_PAUSE 必須
#   - PFP-044 (AppleDouble 事案) AppleDouble セルフクリーンアップ
#   - PFP-101 (0 バイト取得事案) ネットワーク取得は -L で 302 追従 / updates/check 経由
#   - macOS Gatekeeper 対応: xattr -d com.apple.quarantine で隔離属性除去
# =============================================================================
set -e
# 失敗時に Terminal を即閉じさせない (お客様が次の一手を読めるように)
# ★従来はここで行番号・終了コード・失敗したコマンド文字列を
#   そのまま画面に出していた。お客様には意味が伝わらず、何をすればよいかも
#   分からない行き止まりになっていた (顧客可視出力の方針にも反する)。
#   画面には「起きたこと」と「次にすること」だけを日本語で出し、
#   調査に要る技術的な内容は控えのファイルへ回す。
#   ★どの工程で止まったかを必ず伝える (2026-08-15 追加)
#     従来この画面は「予期しない問題が発生しました」としか言えなかった。工程名は
#     画面に【表示】されるだけで、どこまで進んだかを【保持する変数がどこにも無かった】ため、
#     異常終了時に工程を名指しできなかった。お客様は自分がどこで止まったのか分からず、
#     次の一手も分からないまま放置される (過去の導入失敗では、お客様が
#     自力で回避策を探すことになった)。工程名と「その工程で次にすること」を保持し、
#     この画面で必ず日本語で伝える。
trap '_EC=$?; _CMD="$BASH_COMMAND"; _LN=$LINENO; _LOGD="$HOME/.soloptilink/logs"; mkdir -p "$_LOGD" 2>/dev/null || _LOGD="${TMPDIR:-/tmp}"; printf "%s installer-failure phase=%s line=%s exit=%s cmd=%s\n" "$(date +%Y-%m-%dT%H:%M:%S)" "${SETUP_PHASE:-準備中}" "$_LN" "$_EC" "$_CMD" >> "$_LOGD/setup-error.log" 2>/dev/null || true; _RPT="$HOME/.soloptilink/lib/cognitive/customer-error-reporter.sh"; [ -f "$_RPT" ] && bash "$_RPT" "installer-failure" "Mac .command セットアップ失敗 phase=${SETUP_PHASE:-準備中} line=$_LN exit=$_EC cmd=$_CMD" 2>/dev/null; echo ""; echo "==============================================================="; echo " ⚠️  予期しない問題が発生しました"; echo ""; echo "     セットアップを最後まで進められませんでした。"; echo ""; echo "     止まったところ: ${SETUP_PHASE:-準備中}"; echo ""; echo "     次にしていただくこと:"; echo "       ${SETUP_PHASE_NEXT:-このファイルをもう一度ダブルクリックして、はじめからやり直してください。}"; echo ""; echo "     それでも同じところで止まる場合は、この画面の写真を撮って、"; echo "     nomura.y@soloptilink.com までお送りください。"; echo "     こちらで原因をお調べして、ご連絡いたします。"; echo ""; echo "     お急ぎの場合も、まずはこの画面の写真をお送りください。"; echo "==============================================================="; echo "[Enterキーで閉じます]"; read -r _ || true; exit 1' ERR

# ── いま実行中の工程 (異常終了画面が「どこで止まったか」を言えるようにするための状態) ──
#   ★表示だけでは足りない。表示は流れて消えるが、この変数は失敗の瞬間まで残る。
#   無効化スイッチは設けない (状態を持つだけで挙動を変えないため)。
SETUP_PHASE="準備中"
SETUP_PHASE_NEXT="このファイルをもう一度ダブルクリックして、はじめからやり直してください。"
set_phase() { SETUP_PHASE="$1"; SETUP_PHASE_NEXT="$2"; }

clear 2>/dev/null || true
KIT_DIR="$(cd "$(dirname "$0")" && pwd)"
TS=$(date +%Y%m%d_%H%M%S)
API_BASE="https://admin.soloptilink.com/api/v1"

cat <<'BANNER'

  ╔════════════════════════════════════════════════════════════════╗
  ║         SoloptiLinkAI Setup (Mac版)                            ║
  ║         自動セットアップを開始します                          ║
  ║         (このウィンドウは自動で進みます。閉じずにお待ちください) ║
  ╚════════════════════════════════════════════════════════════════╝

BANNER

# ---------------------------------------------------------------------------
# STEP 0/6: 管理者端末の保護 (この .command は顧客用インストーラ)
# ---------------------------------------------------------------------------
if [ -f "$HOME/.soloptilink/.admin_mode" ]; then
    echo "  ⚠️  この端末は SoloptiLinkAI 管理者端末です。"
    echo "      顧客用インストーラの実行は中止しました (開発環境を保護)。"
    echo ""
    echo "[Enterキーで閉じます]"
    read -r _ || true
    exit 0
fi

# ---------------------------------------------------------------------------
# STEP 1/6: macOS Gatekeeper 隔離属性の除去 (ダウンロードファイル特有)
# ---------------------------------------------------------------------------
set_phase "受け取ったファイルの安全確認" "受け取った書庫 (ZIP) をデスクトップなど分かりやすい場所に展開し直してから、もう一度ダブルクリックしてください。"
echo "[STEP 1/6] セキュリティ属性のクリーンアップ"
find "$KIT_DIR" -name "*.command" -exec xattr -d com.apple.quarantine {} \; 2>/dev/null || true
find "$KIT_DIR" -name "*.sh" -exec xattr -d com.apple.quarantine {} \; 2>/dev/null || true
xattr -dr com.apple.quarantine "$KIT_DIR" 2>/dev/null || true
echo "  ✅ 完了"
echo ""

# ---------------------------------------------------------------------------
# STEP 2/6: AppleDouble (._*) / .DS_Store の除去 (PFP-044)
# ---------------------------------------------------------------------------
set_phase "不要ファイルの整理" "受け取った書庫 (ZIP) をもう一度展開し直してから、ダブルクリックしてください。"
echo "[STEP 2/6] macOS メタデータの除去"
find "$KIT_DIR" -name '._*' -delete 2>/dev/null || true
find "$KIT_DIR" -name '.DS_Store' -delete 2>/dev/null || true
echo "  ✅ 完了"
echo ""

# ---------------------------------------------------------------------------
# [前提ソフト] Git / Node.js / Claude Code の確認と導入 (本体配置に先立って)
#   利用に必要な前提ソフトを、SoloptiLink 本体の配置の前に自動導入する。
#   各ソフトは「先に検出し、在ればスキップ」する冪等設計 (再実行しても無害)。
#     - Claude Code : 公式ネイティブインストーラ (curl | bash) で導入 (sudo不要・背景自動更新)
#     - Node.js     : 生成される業務システムの実行・ビルド検証に必要 (Claude Code 自体は Node 不要)
#     - Git         : SoloptiLink の bash 製 lib / chain.sh の動作に必要 (macOS は通常導入済み)
#   ★失敗しても中断しない: このフェーズだけ set +e で ERR トラップを抑止し、
#     未完了は「要対応」へ集約して完了画面で案内する (Windows 版と対称)。
# ---------------------------------------------------------------------------
set_phase "このパソコンの準備状況の確認" "画面に出ている『準備がととのっていない項目』を解消してから、このファイルをもう一度ダブルクリックしてください。"
echo "[準備状況の確認] 導入をはじめる前に、このパソコンの状態をまとめて確認します"
# ★実行順の注意 (T-017a):
#   この前提ソフト工程は STEP 3 (既存環境の退避) より前に走る。Node 自動導入モジュールは
#   ③経路のとき ~/.soloptilink/runtime/node/ へ Node 本体を展開するため、
#   「既存環境の有無」をここで先に確定しておかないと、
#   【いま自動導入が作ったばかりの ~/.soloptilink】を STEP 3 が「既存環境」と誤認して
#   退避してしまい、新規導入なのに .bak が出来て Node も一緒に消える。
HAD_EXISTING_SOLOPTILINK=0
if [ -d "$HOME/.soloptilink" ]; then HAD_EXISTING_SOLOPTILINK=1; fi
PREREQ_ISSUES=()
add_issue() { PREREQ_ISSUES+=("$1|$2"); }   # "項目|対処"
set +e   # このフェーズは失敗しても中断しない
# ★実走で判明した落とし穴: set +e だけでは ERR トラップは止まらない
#   (bash では errexit と ERR トラップは別の仕組み)。この工程で外部コマンドが 1 つでも
#   非ゼロで終わると、「失敗しても中断しない」という宣言に反して異常終了画面が出る。
#   そのため、この工程の外部コマンドはすべて || で受けて ERR トラップの発火条件から外す。

# 公式ネイティブ Claude Code は ~/.local/bin に入るため、現セッション PATH へ前置き
export PATH="$HOME/.local/bin:$PATH"

# --- 前提ソフトの判定 (実行可否ベースの判定) --------------------------------
#   【この判定が必要な理由】判定が command -v (存在確認) だけで、
#     「実際に動くか」を見ていなかった。macOS は開発ツール (Command Line Tools) が
#     未導入でも /usr/bin/git ・ /usr/bin/python3 が【入口 (シム) として実在する】ため、
#     command -v は成功し、実行すると失敗する。実際の導入画面には
#       [skip] Git ()            ← 版数が空 = 存在するが動かない動かぬ証拠
#       xcode-select: No developer tools were found
#     が出ており、この状態で Node 判定まで巻き込まれて「Node.js を用意できませんでした」
#     と誤報告する経路があった。
#   【方針】存在確認だけで合格にしない。版数の取得まで実行し、期待する形の出力が
#     返ったときにだけ「使える」と判定する。Windows 側 (soloptilink-install.ps1) は
# 先に同じ規律で是正済みで、本変更は Mac 側をそれに揃えるもの。
#   【判定は 3 値】absent (入口ごと無い) / present_but_broken (入口はあるが動かない) /
#     available (実際に動く)。この 3 値を区別しないと、お客様に出す案内文が
#     「導入してください」に丸まり、既に入っているものを入れ直させることになる。
prereq_probe() {
    # $1 = コマンド名 / $2 = 版数取得の引数 / $3 = 期待する版数の形 (grep -E のパターン)
    # 標準出力: absent | present_but_broken | available
    # 標準エラー: 何も出さない (呼び出し側が表示を決める)
    # ★判定は PREREQ_VERDICT にも入れる。版数は PREREQ_VER に入れる。
    #   【なぜ両方が要るか / 2026-08-15 実測で判明した表示の欠陥】
    #   呼び出し側が case "$(prereq_probe ...)" と書くと、判定は取れるが
    #   関数の中で入れた版数は【別のシェルの中で消える】ため親には届かない。
    #   その結果、正常に動く Git でも画面には「[skip] Git ()」と出て、
    #   版数が空 = 壊れている端末の見分けがつかなくなっていた (実走で再現済み)。
    #   標準出力の答え方は変えない (既存の検査がこの形を見ている) ので、
    #   受け取り口だけを増やし、呼び出し側はこちらを読む。
    local _cmd="$1" _verarg="$2" _pat="$3" _out=""
    PREREQ_VERDICT=""
    command -v "$_cmd" >/dev/null 2>&1 || { PREREQ_VERDICT="absent"; printf 'absent'; return 0; }
    _out="$("$_cmd" "$_verarg" 2>/dev/null | head -1 | tr -d '\r')" || _out=""
    if [ -z "$_out" ]; then PREREQ_VERDICT="present_but_broken"; printf 'present_but_broken'; return 0; fi
    if printf '%s' "$_out" | grep -Eq "$_pat"; then
        PREREQ_VER="$_out"; PREREQ_VERDICT="available"; printf 'available'; return 0
    fi
    PREREQ_VERDICT="present_but_broken"; printf 'present_but_broken'; return 0
}
PREREQ_VERDICT=""
# 開発ツール未導入は Git / Python 3 に同時に効くため、案内は 1 回だけ出す
DEVTOOLS_PROMPTED=0
prompt_devtools() {
    [ "$DEVTOOLS_PROMPTED" = "1" ] && return 0
    DEVTOOLS_PROMPTED=1
    xcode-select --install >/dev/null 2>&1 || true
}
DEVTOOLS_ISSUE="画面に表示される『コマンドラインデベロッパツール』の導入を完了してください (Git と Python 3 が含まれます)。導入が終わったら、この .command をもう一度ダブルクリックしてください。導入は途中まで完了しています"

# >>> PREFLIGHT-LIB-BEGIN (この範囲は両側検証が切り出して単体で実行する。境界を消さないこと) >>>
# ---------------------------------------------------------------------------
# 準備状況の一括診断 (2026-08-15 新設)
#
# 【なぜ要るか】導入が途中まで進んでから失敗し、お客様は
#   「どこまで進んだのか」「何をすればよいのか」が分からない状態に置かれた。
#   足りないものがあるなら、作業を始める前に【まとめて一度に】お伝えするべきである。
#
# 【設計】
#   ・判定器は作らない。既にある 3 値判定 (prereq_probe) をそのまま呼ぶ。
#     ここで新しく足すのは、どのインストーラにも無かった 3 つだけ:
#       空き容量 / インターネット接続 / 基本ソフト (macOS) の版
#   ・全部そろっているときは一覧を出さない (毎回長い一覧が出るのは邪魔になる)。
#   ・足りないときは【自動導入を始める前に】1 画面で示し、続けるか中断するかを尋ねる。
#   ・確認できなかった項目は「問題なし」に丸めない。確認できなかったと出す。
#     ("確認できないので通す" は禁止。素通りの分岐には入れない)
#
# 無効化: SOLOPTILINK_PREFLIGHT=off (無効化した事実を控えのファイルに残して通過する)
# 調整  : SOLOPTILINK_MIN_FREE_MB (既定 2048) / SOLOPTILINK_MIN_MACOS (既定 12)
#         SOLOPTILINK_PREFLIGHT_NET_TIMEOUT (既定 6 秒) / SOLOPTILINK_PREFLIGHT_WAIT (既定 120 秒)
# ---------------------------------------------------------------------------
PREFLIGHT_ROWS=()
PREFLIGHT_NEED=0      # お客様の操作が要る項目
PREFLIGHT_AUTO=0      # このあと自動で用意する項目 (お客様の操作は不要)
PREFLIGHT_UNKNOWN=0   # 確認できなかった項目 (合格に数えない)
PREFLIGHT_OSVER=""
PREFLIGHT_MIN_FREE_MB="${SOLOPTILINK_MIN_FREE_MB:-2048}"
PREFLIGHT_MIN_MACOS="${SOLOPTILINK_MIN_MACOS:-12}"
# 空き容量の下限の根拠: 本体の展開分に加え、Node.js のランタイム (約 100MB) と、
# これから作る業務システムの部品置き場 (1 件あたり数百 MB) を見込んだ最低限。
PREFLIGHT_DEVTOOLS="Apple の『コマンドラインデベロッパツール』の導入が必要です (Git と Python 3 が含まれます)。このあと Apple の確認画面をお出ししますので、[インストール] を押して、終わるまでお待ちください"

_pf_row() {
    # $1=項目名 $2=判定(ok|auto|need|unknown) $3=お客様への案内 $4=完了画面へ持ち越すか(yes|no)
    # 案内文に縦棒は使わない (項目の区切りに使っているため)
    PREFLIGHT_ROWS+=("$1|$2|$3|${4:-no}")
    case "$2" in
        need)    PREFLIGHT_NEED=$((PREFLIGHT_NEED+1)) ;;
        auto)    PREFLIGHT_AUTO=$((PREFLIGHT_AUTO+1)) ;;
        unknown) PREFLIGHT_UNKNOWN=$((PREFLIGHT_UNKNOWN+1)) ;;
    esac
}

# 空き容量 (MB)。取れなければ空文字を返す (呼び出し側で「確認できなかった」にする)
_pf_free_mb() {
    local _kb=""
    _kb="$(df -Pk "$HOME" 2>/dev/null | awk 'NR==2 {print $4}' 2>/dev/null)" || _kb=""
    case "${_kb:-x}" in ''|*[!0-9]*) printf ''; return 0 ;; esac
    printf '%s' $(( _kb / 1024 ))
}

# 接続確認。0=つながる / 1=つながらない / 2=確かめる手段が無い
#   応答の中身は見ない。何らかの応答が返ること自体が「そこへ届いた」証拠になる。
_pf_net() {
    command -v curl >/dev/null 2>&1 || return 2
    local _code=""
    _code="$(curl -sS -o /dev/null -w '%{http_code}' \
        --max-time "${SOLOPTILINK_PREFLIGHT_NET_TIMEOUT:-6}" "$1" 2>/dev/null)" || _code="000"
    case "${_code:-000}" in
        ''|000) return 1 ;;
        *)      return 0 ;;
    esac
}

# 基本ソフトの版。0=対応範囲 / 1=古すぎる / 2=確かめられない
_pf_macos() {
    PREFLIGHT_OSVER=""
    command -v sw_vers >/dev/null 2>&1 || return 2
    PREFLIGHT_OSVER="$(sw_vers -productVersion 2>/dev/null | head -1 | tr -d '\r')" || PREFLIGHT_OSVER=""
    [ -n "$PREFLIGHT_OSVER" ] || return 2
    local _maj="${PREFLIGHT_OSVER%%.*}"
    case "${_maj:-x}" in ''|*[!0-9]*) return 2 ;; esac
    [ "$_maj" -ge "$PREFLIGHT_MIN_MACOS" ] 2>/dev/null && return 0
    return 1
}

preflight_collect() {
    local _rc=0 _free="" _net_admin=0 _net_claude=0 _major=""
    PREFLIGHT_ROWS=(); PREFLIGHT_NEED=0; PREFLIGHT_AUTO=0; PREFLIGHT_UNKNOWN=0

    # ① パソコンの基本ソフト
    _pf_macos; _rc=$?
    case "$_rc" in
        0) _pf_row "パソコンの基本ソフト" ok "macOS ${PREFLIGHT_OSVER} — 対応しています" no ;;
        1) _pf_row "パソコンの基本ソフト" need "この Mac の macOS ${PREFLIGHT_OSVER} は、当社が動作を確認している範囲より古いものです。macOS ${PREFLIGHT_MIN_MACOS} 以降へ更新していただくか、nomura.y@soloptilink.com までご相談ください" yes ;;
        *) _pf_row "パソコンの基本ソフト" unknown "基本ソフトの版を確認できませんでした (確認できなかっただけで、問題があると判断したわけではありません)" yes ;;
    esac

    # ② 空き容量
    _free="$(_pf_free_mb)"
    if [ -z "$_free" ]; then
        _pf_row "ディスクの空き容量" unknown "空き容量を確認できませんでした (確認できなかっただけで、足りないと判断したわけではありません)" yes
    elif [ "$_free" -lt "$PREFLIGHT_MIN_FREE_MB" ] 2>/dev/null; then
        _pf_row "ディスクの空き容量" need "空きが ${_free} MB しかありません。導入と、これから作る業務システムのために ${PREFLIGHT_MIN_FREE_MB} MB 以上の空きをご用意ください (使っていないファイルをゴミ箱へ移し、ゴミ箱を空にすると増えます)" yes
    else
        _pf_row "ディスクの空き容量" ok "${_free} MB の空きがあります" no
    fi

    # ③ インターネット接続 (本体の受け取り先と、前提ソフトの配布元)
    _pf_net "https://admin.soloptilink.com/"; _net_admin=$?
    _pf_net "https://claude.ai/"; _net_claude=$?
    if [ "$_net_admin" -eq 2 ] || [ "$_net_claude" -eq 2 ]; then
        _pf_row "インターネット接続" unknown "接続を確認する手段がこのパソコンにありませんでした (確認できなかっただけで、つながっていないと判断したわけではありません)" yes
    elif [ "$_net_admin" -eq 0 ] && [ "$_net_claude" -eq 0 ]; then
        _pf_row "インターネット接続" ok "必要な接続先につながります" no
    else
        _pf_row "インターネット接続" need "必要な接続先につながりませんでした。Wi-Fi や有線の接続をご確認ください。社内のネットワーク制限 (プロキシ / VPN) が原因のこともありますので、その場合はネットワーク管理者に接続の許可をご依頼ください" yes
    fi

    # ④ Git (既存の 3 値判定をそのまま使う)
    PREREQ_VER=""
    prereq_probe git --version 'git version [0-9]' >/dev/null
    case "$PREREQ_VERDICT" in
        available) _pf_row "Git" ok "使えます (${PREREQ_VER})" no ;;
        *)         _pf_row "Git" need "$PREFLIGHT_DEVTOOLS" no ;;
    esac

    # ⑤ Python 3 (同じ開発ツールに含まれる)
    PREREQ_VER=""
    prereq_probe python3 --version 'Python 3\.' >/dev/null
    case "$PREREQ_VERDICT" in
        available) _pf_row "Python 3" ok "使えます (${PREREQ_VER})" no ;;
        *)         _pf_row "Python 3" need "$PREFLIGHT_DEVTOOLS" no ;;
    esac

    # ⑥ Node.js (無ければ当社側で自動的に用意するため、お客様の操作は要らない)
    PREREQ_VER=""
    prereq_probe node -v 'v[0-9]' >/dev/null
    if [ "$PREREQ_VERDICT" = "available" ]; then
        _major="${PREREQ_VER#v}"; _major="${_major%%.*}"
        case "${_major:-x}" in
            ''|*[!0-9]*)
                _pf_row "Node.js" unknown "入っていますが版を読み取れませんでした (${PREREQ_VER})" no ;;
            *)
                if [ "$_major" -ge 18 ] 2>/dev/null; then
                    _pf_row "Node.js" ok "使えます (${PREREQ_VER})" no
                else
                    _pf_row "Node.js" auto "入っている ${PREREQ_VER} は古いため、このあと新しいものを用意します (お客様の操作は不要です)" no
                fi ;;
        esac
    else
        _pf_row "Node.js" auto "このあと自動で用意します (お客様の操作は不要です)" no
    fi

    # ⑦ Claude Code (無ければ当社側で自動的に用意する)
    PREREQ_VER=""
    prereq_probe claude --version '[0-9]' >/dev/null
    case "$PREREQ_VERDICT" in
        available) _pf_row "Claude Code" ok "使えます (${PREREQ_VER})" no ;;
        *)         _pf_row "Claude Code" auto "このあと自動で用意します (お客様の操作は不要です)" no ;;
    esac
}

# 一覧を出すか、出さずに素通りするかを決めて表示する。
#   戻り値 0 = このまま導入へ進む / 1 = お客様が「中断する」を選んだ
preflight_present() {
    local _row="" _name="" _verdict="" _msg="" _rest="" _ans=""
    if [ "$PREFLIGHT_NEED" -eq 0 ] && [ "$PREFLIGHT_AUTO" -eq 0 ] && [ "$PREFLIGHT_UNKNOWN" -eq 0 ]; then
        # ★全部そろっているときは一覧を出さない (毎回の長い一覧はかえって読まれなくなる)
        echo "  ✅ 準備はととのっています (${#PREFLIGHT_ROWS[@]} 項目すべて確認しました)。このまま導入を進めます"
        return 0
    fi
    echo ""
    echo "  ───────────────────────────────────────────────"
    echo "   導入をはじめる前に、次の点をご確認ください"
    echo "  ───────────────────────────────────────────────"
    for _row in "${PREFLIGHT_ROWS[@]}"; do
        _name="${_row%%|*}"; _rest="${_row#*|}"
        _verdict="${_rest%%|*}"; _rest="${_rest#*|}"
        _msg="${_rest%%|*}"
        case "$_verdict" in
            ok)      printf '    [ 済 ] %s\n' "$_name" ;;
            auto)    printf '    [自動] %s\n           %s\n' "$_name" "$_msg" ;;
            need)    printf '    [ご確認] %s\n           %s\n' "$_name" "$_msg" ;;
            unknown) printf '    [未確認] %s\n           %s\n' "$_name" "$_msg" ;;
        esac
    done
    echo "  ───────────────────────────────────────────────"
    echo ""
    if [ "$PREFLIGHT_NEED" -eq 0 ] && [ "$PREFLIGHT_UNKNOWN" -eq 0 ]; then
        echo "   お客様の操作が必要な項目はありません。[自動] の項目はこのあと当社側で用意します。"
        echo "   そのままお待ちください。"
        echo ""
        return 0
    fi
    echo "   このまま進めることもできます (進んだ分はそのまま残ります)。"
    echo "   [ご確認] [未確認] の項目は、最後にもう一度まとめてお伝えします。"
    echo ""
    echo "     このまま進める場合   … そのまま Enter キーを押してください"
    echo "     いったん中断する場合 … 半角の n を入力して Enter キーを押してください"
    echo ""
    printf '   どちらになさいますか? (何も押さない場合はこのまま進みます) '
    _ans=""
    read -r -t "${SOLOPTILINK_PREFLIGHT_WAIT:-120}" _ans || _ans=""
    echo ""
    case "$(printf '%s' "$_ans" | tr '[:upper:]' '[:lower:]')" in
        n|no|いいえ|ちゅうだん|中断)
            return 1 ;;
    esac
    echo "  このまま導入を進めます。"
    echo ""
    return 0
}
# <<< PREFLIGHT-LIB-END <<<

# --- 準備状況の一括診断をここで実走する (自動導入より前・本体の配置より前) -----
if [ "$(printf '%s' "${SOLOPTILINK_PREFLIGHT:-on}" | tr '[:upper:]' '[:lower:]')" = "off" ]; then
    echo "  ℹ️  準備状況の確認は無効化されています (確認していません。問題が無いという意味ではありません)"
    _PF_LOGD="$HOME/.soloptilink/logs"
    mkdir -p "$_PF_LOGD" 2>/dev/null || _PF_LOGD="${TMPDIR:-/tmp}"
    printf '%s\tSOLOPTILINK_PREFLIGHT=off\t準備状況の一括確認を実行せず通過\n' \
        "$(date +%Y-%m-%dT%H:%M:%S)" >> "$_PF_LOGD/preflight.log" 2>/dev/null || true
else
    preflight_collect
    if ! preflight_present; then
        echo "  いったん中断しました。"
        echo "  上の [ご確認] の項目を解消してから、このファイルをもう一度ダブルクリックしてください。"
        echo "  SoloptiLinkAI 本体はまだ入れていませんので、はじめからやり直していただけます。"
        echo ""
        echo "[Enterキーで閉じます]"
        read -r _ || true
        exit 0
    fi
    # 解消されないまま進んだ環境面の項目は、最後の「要対応」にも必ず残す
    # (お伝えしたことを、完了画面で無かったことにしない)
    for _pf_carry in "${PREFLIGHT_ROWS[@]}"; do
        _pf_c_name="${_pf_carry%%|*}"; _pf_c_rest="${_pf_carry#*|}"
        _pf_c_rest="${_pf_c_rest#*|}"
        _pf_c_msg="${_pf_c_rest%%|*}"; _pf_c_flag="${_pf_c_rest#*|}"
        if [ "$_pf_c_flag" = "yes" ]; then add_issue "$_pf_c_name" "$_pf_c_msg"; fi
    done
fi
echo ""

set_phase "前提ソフト (Git / Node.js / Claude Code) の確認と導入" "画面に出ている『要対応』の項目を解消してから、このファイルをもう一度ダブルクリックしてください。ここまでの導入内容はそのまま残っています。"
echo "[前提ソフト] Git / Node.js / Claude Code を確認・導入"

# --- Git (macOS は Command Line Tools 同梱で通常導入済み) ---
PREREQ_VER=""
prereq_probe git --version 'git version [0-9]' >/dev/null
case "$PREREQ_VERDICT" in
    available)
        echo "  [skip] Git ($PREREQ_VER)" ;;
    present_but_broken)
        # 入口はあるが動かない = 開発ツールが未導入。「未導入」と同じ案内にしない
        echo "  Git: 開発ツールの導入が必要です (コマンドはありますが実行できません)"
        prompt_devtools
        add_issue "Git" "$DEVTOOLS_ISSUE" ;;
    *)
        echo "  Git: 未導入 → コマンドラインデベロッパツールの導入を案内します"
        prompt_devtools
        add_issue "Git" "$DEVTOOLS_ISSUE" ;;
esac

# --- Node.js (v18 以上) — 自動導入モジュール AC-I06 への結線 (T-017a) ---
#   【この実装が必要な理由】ここは長らく「既存 node があれば skip → brew があれば brew install →
#     brew が無ければ自動導入をスキップして nodejs.org を手動案内」だった。
#     同梱している installer/lib/node-provision.sh (公式 tar.xz をユーザー領域へ展開する
#     ③経路を実装済み) を【一度も呼んでいなかった】= 呼出元ゼロの死配線。
#     その結果、brew 不在の端末では自動導入が発火せず、公式 pkg インストーラの
#     「★PCのパスワード」入力で顧客の手が止まる 74 分事案の経路がそのまま残っていた。
#     配布物に同梱されていることは build-update-package.sh の HARDGATE が毎回守っていたため、
#     「入っているから直った」と誤認しやすい状態だった。
#   【この結線の役割】判定順 (①既存 ②brew ③公式tar.xz展開) と SHA-256 照合・kill-switch は
#     すべてモジュール側が実装済みなので、ここは薄い結線に留める:
#       モジュールを読み込む → node_provision_ensure → 結果 verdict を add_issue へ流す。
#     モジュールが見つからない場合に旧 brew 経路へ黙って戻さないこと。戻すと
#     「部品が落ちても従来どおり動く」= 死配線に戻ったことを誰も検出できなくなる。
NODE_PROVISION_SH=""
for _np_cand in \
    "$KIT_DIR/installer/lib/node-provision.sh" \
    "$KIT_DIR/lib/node-provision.sh" \
    "$HOME/.soloptilink/installer/lib/node-provision.sh"; do
    if [ -f "$_np_cand" ]; then NODE_PROVISION_SH="$_np_cand"; break; fi
done
if [ -n "$NODE_PROVISION_SH" ]; then
    # shellcheck disable=SC1090
    . "$NODE_PROVISION_SH"
    node_provision_ensure || true
    # 当社の現セッション PATH にのみ前置き (~/.zshrc は書き換えない)
    node_provision_path_prepend >/dev/null 2>&1 || true
    case "${NODE_PROVISION_VERDICT:-}" in
        PASS)
            echo "  ✅ Node.js: 使える状態です (${NODE_PROVISION_VERSION:-版数不明})" ;;
        WARN)
            echo "  ⚠️  Node.js: 使えますが確認事項があります"
            add_issue "Node.js" "${NODE_PROVISION_ISSUE_JA:-Node.js の状態に確認事項があります。nomura.y@soloptilink.com へご連絡ください}" ;;
        not_applicable)
            echo "  ℹ️  Node.js: このパソコンでは自動導入の対象外です"
            add_issue "Node.js" "このパソコンの種類では Node.js の自動導入に対応していません。https://nodejs.org/ja から LTS 版を導入してください" ;;
        "")
            # 【T-03 /  是正】判定そのものが返らなかった場合。
            #   この事象への対処。
            #   ここが空になった。従来はこの空が下の「用意できませんでした」に落ち、
            #   さらに案内文まで既定値に置き換わって【既に入っている Node.js を
            #   入れ直してください】という誤案内が出た。お客様は打つ手を失う。
            #   「用意できなかった」と「判定できなかった」は、お客様が取るべき行動が違う。
            #   判定不能は判定不能として出し、既定の導入案内へ落とさない。
            if [ -n "${NODE_PROVISION_VERSION:-}" ]; then
                echo "  ⚠️  Node.js: 導入済みですが状態を確認できませんでした (${NODE_PROVISION_VERSION})"
            else
                echo "  ⚠️  Node.js: 状態を判定できませんでした"
            fi
            add_issue "Node.js" "Node.js の状態を判定できませんでした。開発ツール (コマンドラインデベロッパツール) が未導入の場合は、その導入を終えてからこの .command をもう一度実行してください。解消しない場合は nomura.y@soloptilink.com へご連絡ください (Node.js を入れ直す必要はありません)" ;;
        *)
            echo "  ⚠️  Node.js: 自動で用意できませんでした (要対応一覧に集約します)"
            add_issue "Node.js" "${NODE_PROVISION_ISSUE_JA:-https://nodejs.org/ja から LTS 版を導入してください}" ;;
    esac
else
    echo "  ⚠️  Node.js: 自動導入に必要な部品が見つかりません"
    add_issue "Node.js" "自動導入に必要な部品が配布物の中に見当たりません。ZIP をもう一度展開し直してから再実行するか、nomura.y@soloptilink.com へご連絡ください"
fi

# --- Claude Code (公式ネイティブインストーラ = sudo 不要・背景自動更新) ---
if command -v claude >/dev/null 2>&1; then
    echo "  [skip] Claude Code ($(claude --version 2>/dev/null | head -1))"
else
    echo "  Claude Code: 未導入 → 公式ネイティブインストーラで導入します (自動更新あり)"
    curl -fsSL https://claude.ai/install.sh | bash >/dev/null 2>&1 || true
    export PATH="$HOME/.local/bin:$PATH"
    if command -v claude >/dev/null 2>&1; then
        echo "  ✅ Claude Code 導入完了 ($(claude --version 2>/dev/null | head -1))"
    else
        add_issue "Claude Code" "自動導入に失敗しました。ネットワーク(社内プロキシ/オフライン)をご確認のうえ再実行するか、nomura.y@soloptilink.com へご連絡ください"
    fi
fi

# --- Python 3 (T-702 新設) ---
#   【なぜここに足したか / 実測】
#     このインストーラ自身が STEP 6 で Claude Desktop の設定を python3 で書き換え、
#     生成物の品質点検も 138 本中 107 本が python3 を呼ぶ。つまり導入の前提なのに、
#     お客様向けの手順書 7 本すべてに記載が 0 件で、前提ソフトの確認対象にも
#     入っていなかった (実測)。
#     python3 が無い状態で同じ組み立て (set -e + ERR トラップ + python3 のヒアドキュメント)
#     を走らせると、終了コード 127 で ERR トラップが発火し、導入がそこで止まる。
#     実際の品質点検も、判定が全て「-」になり合否を出せなくなることを実走で確認した。
#   【方針】自動導入はしない (Apple の開発ツール導入は同意画面を伴い、無人では進まない)。
#     ここでは検出だけ行い、無い場合は導入の案内を「要対応」へ集約する。
#   ★macOS には python3 の「入口」が開発ツール未導入でも実在する。
#     コマンドがあることだけを見ると入っている扱いになるため、版の表示まで確かめる
#     (Windows 側の python3.exe = ストアへ誘導するだけの入口と同じ構造)。
PREREQ_VER=""
prereq_probe python3 --version 'Python 3\.' >/dev/null
case "$PREREQ_VERDICT" in
    available)
        echo "  [skip] Python 3 ($PREREQ_VER)" ;;
    present_but_broken)
        echo "  Python 3: 開発ツールの導入が必要です (コマンドはありますが実行できません)"
        prompt_devtools
        add_issue "Python 3" "${DEVTOOLS_ISSUE}。導入せずに進めると、Claude Desktop の設定登録と、生成した業務システムの品質点検が行えません" ;;
    *)
        echo "  Python 3: 未導入 → 開発ツール一式の導入を案内します"
        prompt_devtools
        add_issue "Python 3" "${DEVTOOLS_ISSUE}。導入せずに進めると、Claude Desktop の設定登録と、生成した業務システムの品質点検が行えません" ;;
esac

set -e   # 以降は通常のエラー検出に戻す
echo ""

# ---------------------------------------------------------------------------
# STEP 3/6: 既存環境のバックアップ
# ---------------------------------------------------------------------------
set_phase "すでに入っているものの控え取り" "パソコンの空き容量をご確認のうえ、このファイルをもう一度ダブルクリックしてください。"
echo "[STEP 3/6] 既存環境のバックアップ"
if [ "$HAD_EXISTING_SOLOPTILINK" -eq 1 ] && [ -d "$HOME/.soloptilink" ]; then
    BK="$HOME/.soloptilink.bak.$TS"
    echo "  すでに入っているものを控えとして取っておきます"
    mv "$HOME/.soloptilink" "$BK"
    echo "  ✅ 控えを取りました (元に戻したいときは、この控えを使って戻せます)"
else
    echo "  既存環境なし (新規インストール)"
fi
mkdir -p "$HOME/.soloptilink"

# ── 再インストール時の認証引継ぎ (PFP-119) ──
# 退避した旧環境から認証系3ファイル (端末認証 activation.json / 端末識別
# .device_identity.json / ライセンスキャッシュ license.json) を新環境へ
# 自動コピー戻しし、再インストール後の再認証 (--activate やり直し) を不要にする。
# 配布物にはこれらの認証ファイルが含まれないため、後続の本体配置で上書きされない。
#
# ★引き継げた数と「登録が済んでいる証拠」は別物である (2026-08-17 是正)
#   .device_identity.json (端末の指紋) は、登録に成功したかどうかに関係なく作られる。
#   したがって「1つでも引き継げた」ことは、登録が済んだ証拠にはならない。
#   登録が済んだと言えるのは activation.json と license.json がそろっている場合だけ。
#   この2つを AUTH_PROOF として別に数える (誤判定の詳細は後段 STEP 8 の注記を参照)。
AUTH_CARRIED=0
AUTH_PROOF=0
if [ -n "${BK:-}" ] && [ -d "${BK:-}" ]; then
    for AUTH_FILE in activation.json .device_identity.json license.json; do
        if [ -f "$BK/$AUTH_FILE" ]; then
            if cp -p "$BK/$AUTH_FILE" "$HOME/.soloptilink/$AUTH_FILE" 2>/dev/null; then
                AUTH_CARRIED=$((AUTH_CARRIED+1))
                case "$AUTH_FILE" in
                    activation.json|license.json) AUTH_PROOF=$((AUTH_PROOF+1)) ;;
                esac
            fi
        fi
    done
fi
if [ "$AUTH_PROOF" -ge 2 ]; then
    echo "  ✅ 認証情報は引き継ぎました (再認証は不要です)"
elif [ "$AUTH_CARRIED" -gt 0 ]; then
    # 指紋だけを引き継いだ状態。登録はこれから行うため、済んだかのように言わない。
    echo "  ℹ️  この端末の情報を引き継ぎました (ご登録はこのあと行います)"
fi

# ── Node ランタイムと導入記録の引継ぎ (T-017a) ──
# 前提ソフト工程で自動導入した Node 本体 (runtime/node/) と、その判定記録
# (var/node-provision-*) は退避先に入ってしまう。同じ絶対パスへ戻さないと
# runtime/node/env.sh が指す先が消え、せっかく導入した Node が使えなくなる。
# 退避元は消さない (コピーで戻す = 元に戻せる状態を保つ)。
if [ -n "${BK:-}" ] && [ -d "${BK:-}" ]; then
    if [ -d "$BK/runtime/node" ]; then
        mkdir -p "$HOME/.soloptilink/runtime" 2>/dev/null || true
        cp -R "$BK/runtime/node" "$HOME/.soloptilink/runtime/" 2>/dev/null || true
    fi
    for NP_FILE in node-provision-results.json node-provision-refiner.json node-provision.log; do
        if [ -f "$BK/var/$NP_FILE" ]; then
            mkdir -p "$HOME/.soloptilink/var" 2>/dev/null || true
            cp -p "$BK/var/$NP_FILE" "$HOME/.soloptilink/var/$NP_FILE" 2>/dev/null || true
        fi
    done
fi
echo ""

# ---------------------------------------------------------------------------
# STEP 4/6: パッケージ本体の配置 (自己完結ZIP → tar.gz → ネットワークの順)
# ---------------------------------------------------------------------------
set_phase "SoloptiLinkAI 本体の配置" "インターネットの接続と空き容量をご確認のうえ、このファイルをもう一度ダブルクリックしてください。"
echo "[STEP 4/6] SoloptiLinkAI 本体を配置中..."

if [ -f "$KIT_DIR/chain.sh" ] && [ -d "$KIT_DIR/lib" ]; then
    # ── モードA: 自己完結ZIP (現行 per-platform ZIP の既定レイアウト) ──
    echo "  自己完結キットを検出 (展開済みパッケージ本体)"
    # この .command 自身と Mac専用補助ファイルは除外して本体をコピー
    ( cd "$KIT_DIR" && \
      find . -mindepth 1 -maxdepth 1 \
        ! -name 'SoloptiLinkAI-Setup.command' \
        ! -name 'はじめに_Mac.txt' \
        ! -name '.DS_Store' \
        -exec cp -R {} "$HOME/.soloptilink/" \; )
    echo "  ✅ 本体の配置が完了しました"
else
    # ── モードB: tar.gz 同梱キット ──
    PAYLOAD_TGZ=$(ls "$KIT_DIR"/../soloptilink-update-v*.tar.gz "$KIT_DIR"/soloptilink-update-v*.tar.gz 2>/dev/null | sort -V | tail -1)
    if [ -n "$PAYLOAD_TGZ" ] && [ -f "$PAYLOAD_TGZ" ]; then
        echo "  オフライン配布物を検出: $(basename "$PAYLOAD_TGZ")"
        tar xzf "$PAYLOAD_TGZ" -C "$HOME/.soloptilink" --strip-components=1
        echo "  ✅ 展開完了"
    else
        # ── モードC: ネットワーク取得 (最終手段 / PFP-101: -L で302追従) ──
        echo "  本体が見つからないため、ネットワーク経由で取得します..."
        # HTTP status と本文を分離取得。stderr は退避して顧客可視に出さない。
        _NET_TMP=$(mktemp -t solai_net.XXXXXX 2>/dev/null || echo "/tmp/solai_net.$$")
        _NET_ERR="${_NET_TMP}.err"
        HTTP_CODE=$(curl -sSL --max-time 30 -o "$_NET_TMP" -w "%{http_code}" \
            "$API_BASE/updates/check?version=0&os=darwin&arch=$(uname -m | sed 's/x86_64/amd64/')" \
            2>"$_NET_ERR" || echo "000")
        LATEST_JSON=$(cat "$_NET_TMP" 2>/dev/null || echo "")
        TAR_URL=$(echo "$LATEST_JSON" | python3 -c "import json,sys; d=json.load(sys.stdin); print(d.get('package_url') or '')" 2>/dev/null || echo "")
        rm -f "$_NET_TMP" "$_NET_ERR" 2>/dev/null || true
        if [ -z "$TAR_URL" ]; then
            echo ""
            echo "  ⚠️  本体を取得できませんでした。"
            if [ "$HTTP_CODE" = "000" ]; then
                echo "      インターネットに接続できていない可能性があります。"
                echo "      Wi-Fi や有線接続、社内プロキシ / VPN の設定をご確認のうえ、"
                echo "      再度 SoloptiLinkAI-Setup.command を実行してください。"
            elif [ "$HTTP_CODE" -ge 500 ] 2>/dev/null; then
                echo "      配信サーバー側で一時的な問題が発生している可能性があります (応答コード: $HTTP_CODE)。"
                echo "      数分おいて再度実行してください。解消しない場合は下記までご連絡ください。"
            elif [ "$HTTP_CODE" -ge 400 ] 2>/dev/null; then
                echo "      配信サーバーへのアクセスが許可されていません (応答コード: $HTTP_CODE)。"
                echo "      ご契約状況の確認が必要な可能性があります。下記までご連絡ください。"
            elif [ "$HTTP_CODE" = "200" ]; then
                echo "      配信情報の読み取りに失敗しました (応答: $HTTP_CODE / 本体パッケージ URL 未指定)。"
                echo "      配信側の準備が完了していない可能性があります。下記までご連絡ください。"
            else
                echo "      配信サーバーから想定外の応答を受け取りました (応答コード: $HTTP_CODE)。"
                echo "      下記までご連絡ください。"
            fi
            echo ""
            echo "      連絡先: nomura.y@soloptilink.com"
            echo "      お手数ですが上記の応答コードを本文にお書き添えください。"
            exit 1
        fi
        echo "  ダウンロード: $TAR_URL"
        curl -fsSL --max-time 300 -o "$HOME/.soloptilink/_latest.tar.gz" "$TAR_URL"
        tar xzf "$HOME/.soloptilink/_latest.tar.gz" -C "$HOME/.soloptilink" --strip-components=1
        rm -f "$HOME/.soloptilink/_latest.tar.gz"
        echo "  ✅ ダウンロード+展開完了"
    fi
fi

# AppleDouble 再除去 + 実行権限付与
find "$HOME/.soloptilink" -name '._*' -delete 2>/dev/null || true
find "$HOME/.soloptilink" -name '.DS_Store' -delete 2>/dev/null || true
chmod +x "$HOME/.soloptilink"/chain.sh 2>/dev/null || true
chmod +x "$HOME/.soloptilink"/*.sh 2>/dev/null || true
echo ""

# ---------------------------------------------------------------------------
# STEP 5/6: Goランチャーの配置 (アーキ自動判定)
# ---------------------------------------------------------------------------
set_phase "このパソコン用の起動プログラムの配置" "インターネットの接続をご確認のうえ、このファイルをもう一度ダブルクリックしてください。"
echo "[STEP 5/6] Goランチャーを配置"
ARCH=$(uname -m)
case "$ARCH" in
    arm64)  LAUNCHER_NAME="soloptilink-darwin-arm64" ;;
    x86_64) LAUNCHER_NAME="soloptilink-darwin-amd64" ;;
    *) echo "  ⚠️  未対応のアーキ: $ARCH"; exit 1 ;;
esac

if [ -f "$HOME/.soloptilink/soloptilink" ]; then
    # 自己完結ZIP は arch 専用バイナリを soloptilink として同梱済み
    :
elif [ -f "$KIT_DIR/$LAUNCHER_NAME" ]; then
    cp "$KIT_DIR/$LAUNCHER_NAME" "$HOME/.soloptilink/soloptilink"
elif [ -f "$KIT_DIR/Mac/$LAUNCHER_NAME" ]; then
    cp "$KIT_DIR/Mac/$LAUNCHER_NAME" "$HOME/.soloptilink/soloptilink"
else
    LAUNCHER_URL="https://github.com/onukih-design/soloptilink-releases/releases/latest/download/${LAUNCHER_NAME}"
    echo "  ダウンロード: $LAUNCHER_URL"
    curl -fsSL --max-time 120 -o "$HOME/.soloptilink/soloptilink" "$LAUNCHER_URL"
fi
chmod +x "$HOME/.soloptilink/soloptilink"
xattr -d com.apple.quarantine "$HOME/.soloptilink/soloptilink" 2>/dev/null || true
echo "  ✅ アーキ: $ARCH 用バイナリを配置"
echo ""

# ---------------------------------------------------------------------------
# STEP 5.5/6: 自動更新フックの登録 (更新が自動で届かない状態を防ぐ)
# ---------------------------------------------------------------------------
# 【鶏卵デッドロックの解消】従来、自動更新フック (~/.claude/settings.json) を
# 登録するのは移行スクリプト 1本だけで、それを呼ぶのは「フックで起動される
# auto-update.sh 自身」だった。そのため新規導入時は誰もフックを登録せず、
# 一度も手動更新しない限り自動更新が永遠に始まらなかった。
# → 導入のこの瞬間にフックを登録し、自動更新の点火を保証する。冪等。
set_phase "自動更新の設定" "このファイルをもう一度ダブルクリックしてください。設定だけをやり直します。"
echo "[STEP 5.5/6] 自動更新を有効化"
_HOOK_OK=0
# ★「登録を実行した」ではなく「登録が効いた」で判定する。
#   【この実装が必要な理由】従来は登録コマンドの終了コードだけを見て成功としていた。
#   これは今日の前提ソフト事案とまったく同じ誤り (実行したことと、効いたことを混同する)。
#   登録が効いていないまま「以降は自動で最新版を取得します」と表示すると、
#   お客様は更新されていることを前提に使い続け、何世代も古いまま気づけない。
#   実際 一部の環境で導入・更新が完了しない事象が確認されたため。
#   そこで登録後に設定ファイルを実際に読み、自動更新の登録が入っているかを確かめる。
#   ★この確認は python3 を使わない (開発ツール未導入の端末でも必ず動く必要があるため)。
_hook_is_registered() {
    local _st="$HOME/.claude/settings.json"
    [ -f "$_st" ] || return 1
    # 自動更新の登録行が実在するかだけを見る (整形の違いに強い素朴な検索)
    grep -q 'auto-update.sh' "$_st" 2>/dev/null || return 1
    grep -q 'SessionStart' "$_st" 2>/dev/null || return 1
    return 0
}
# 第一経路: ランチャー経由の冪等登録 (全OS共通・テスト済みの単一実装・python3 非依存)
if [ -x "$HOME/.soloptilink/soloptilink" ]; then
    "$HOME/.soloptilink/soloptilink" --register-autoupdate-hook >/dev/null 2>&1 || true
    _hook_is_registered && _HOOK_OK=1
fi
# 第二経路 (保険): 移行スクリプト直接実行
if [ "$_HOOK_OK" -eq 0 ] && [ -f "$HOME/.soloptilink/migration/v2027_hook_install.sh" ]; then
    bash "$HOME/.soloptilink/migration/v2027_hook_install.sh" >/dev/null 2>&1 || true
    _hook_is_registered && _HOOK_OK=1
fi
# ★メニュー(スキル)の修復フックも登録する。
#   【この実装が必要な理由】このフックは「顧客端末で毎回確実に動く経路は自分だけである」と
#   自ら宣言しているのに、顧客の設定へ登録する処理が本体のどこにも存在しなかった
#   (全数検索してヒットしたのは同梱リスト・存在検査・資産台帳だけで、登録は 0 件)。
#   そのため、メニューが古い版のまま取り残されても直る機会が無く、
#   さらにこのフックだけが呼び出し元である「新しい版が出ています」の通知も
#   顧客端末で一度も出ていなかった。一部の環境で導入・更新が完了しない事象が確認されたため。
#   15 世代前の版が出続けたのは、この経路が繋がっていなかったためでもある。
#   ★python3 を使わずに登録する (開発ツール未導入の端末でも必ず動く必要があるため)。
_SKILL_HEAL="$HOME/.soloptilink/lib/hooks/session-start-skill-heal.sh"
_ST_JSON="$HOME/.claude/settings.json"
if [ -f "$_SKILL_HEAL" ] && [ -f "$_ST_JSON" ]; then
    if ! grep -q 'session-start-skill-heal.sh' "$_ST_JSON" 2>/dev/null; then
        # 自動更新の登録行に相乗りする形で 1 行だけ足す (既存の構造を壊さない)
        _tmp_st="$_ST_JSON.tmp.$$"
        sed 's|\(bash [^"]*auto-update\.sh\)|\1\&\& bash ~/.soloptilink/lib/hooks/session-start-skill-heal.sh >/dev/null 2>\&1 \|\| true|' \
            "$_ST_JSON" > "$_tmp_st" 2>/dev/null
        # 壊れた設定を残さない: 書けた場合のみ差し替え、登録できたかを必ず確かめる
        if [ -s "$_tmp_st" ] && grep -q 'session-start-skill-heal.sh' "$_tmp_st" 2>/dev/null; then
            cp "$_ST_JSON" "$_ST_JSON.bak.$TS" 2>/dev/null || true
            mv "$_tmp_st" "$_ST_JSON" 2>/dev/null || rm -f "$_tmp_st" 2>/dev/null
        else
            rm -f "$_tmp_st" 2>/dev/null || true
        fi
    fi
fi

if [ "$_HOOK_OK" -eq 1 ]; then
    echo "  ✅ 以降 Claude Code 起動時に自動で最新版を取得します (登録を確認済み)"
else
    # ★従来の案内は「チャット欄に『最新版にして』とお伝えください」
    #   だったが、これは効かない。チャットの中からは設定ファイルを書き換えられない
    #   仕組み (自己改変の防止) になっており、お客様が案内どおりにしても状況が変わらない。
    #   実際に効く手段だけを案内する。
    echo "  ⚠️  自動更新の設定を完了できませんでした (このままだと最新版が自動で届きません)"
    echo "      お手数ですが、この画面のあとに表示される案内に沿って"
    echo "      『コマンドラインデベロッパツール』の導入を完了し、"
    echo "      もう一度このセットアップをダブルクリックしてください。"
    echo "      解消しない場合は nomura.y@soloptilink.com へご連絡ください (端末の状態を確認します)。"
    add_issue "自動更新" "自動更新の設定が完了していません。このままでは最新版が自動で届きません。『コマンドラインデベロッパツール』の導入を終えてから、このセットアップをもう一度実行してください。解消しない場合は nomura.y@soloptilink.com までご連絡ください"
fi

# ---------------------------------------------------------------------------
# STEP 5.6/6: 品質・信頼性フックの登録
# ---------------------------------------------------------------------------
# 【この実装が必要な理由】ここで名指しで実行していたのは v2027 (自動更新) の1本だけだった。
#   そのため v2027 以降に追加された遡及配線 (品質ゲート・エラーゼロ化4本柱の結線層など) は
#   【新規導入の端末に一度も適用されない】。実測で、4本柱の結線層 7エントリが顧客端末の
#   ~/.claude/settings.json に一つも入っていないことが判明した (開発機でしか動いていなかった)。
#   名指し列挙は「今後増えるもの」を必ず取りこぼす構造なので、ここは列挙をやめて
#   migration/ 配下の全スクリプトを実行する (各スクリプトが自前で冪等性を保証している)。
set_phase "品質チェックの設定" "このファイルをもう一度ダブルクリックしてください。設定だけをやり直します。"
echo "[STEP 5.6/6] 品質・信頼性フックを登録"
# 【P3 是正 2026-08-17】設定用スクリプトの置き場所は 2 か所ある
# ------------------------------------------------------------
# 何が起きていたか:
#   設定用スクリプトは migration/ と lib/migration/ の 2 か所に分かれて同梱
#   されているが、ここは前者しか走査していなかった。そのため Mac のお客様は
#   「本番モードの封緘」と「常駐チェック機能の登録」の 2 件が一度も適用されない。
#   Linux の入口はこの 2 件を名指しで実行していたので、入口によって端末の
#   状態が食い違っていた。両方の置き場所を走査して揃える。
# 【P3 是正 (第2波) 2026-08-17】走査条件を 3 つの入口で v*.sh に統一する。
#   lib/migration/ 側だけ *.sh にしていたため、社内ツリーでは自己実証用の
#   テストスクリプトまで「設定」として実行・計上される作りだった。
#   適用できなかった件数も数え、成功したことにしない。
_MIG_N=0
_MIG_NG=0
# >>> SOLOPTILINK-MIGRATION-SCAN-BEGIN
#   ★ここから END までが「設定用スクリプトの走査条件」の正体。
#     3 つの入口 (Mac / Windows / Linux) で同じ条件になっているかを、
#     常設検査 L233-INSTALL-ENTRY-PARITY がこの区間だけを実際に走らせて確かめる。
#     区間の外へ条件を書くと、入口ごとの食い違いが再発しても検査に映らない。
for _migdir in "$HOME/.soloptilink/migration" "$HOME/.soloptilink/lib/migration"; do
    [ -d "$_migdir" ] || continue
    for _mig in "$_migdir/"v*.sh; do
        [ -f "$_mig" ] || continue
        # v2027 は直前で実行済み (二重実行しても冪等だが、無駄な処理を避ける)
        case "$_mig" in *v2027_hook_install.sh) continue ;; esac
        if bash "$_mig" >/dev/null 2>&1; then
            _MIG_N=$((_MIG_N + 1))
        else
            _MIG_NG=$((_MIG_NG + 1))
        fi
    done
done
# <<< SOLOPTILINK-MIGRATION-SCAN-END
if [ "$((_MIG_N + _MIG_NG))" -gt 0 ]; then
    echo "  ✅ 品質・信頼性の自動チェックを有効化しました (${_MIG_N} 項目)"
    if [ "$_MIG_NG" -gt 0 ]; then
        echo "  ⚠️  ${_MIG_NG} 件は適用できませんでした (ご利用は始められます)"
        echo "     次にしていただくこと: このファイルをもう一度ダブルクリックしてください。それでも同じ表示が続く場合は、この画面を添えて nomura.y@soloptilink.com までご連絡ください。"
    fi
else
    echo "  ℹ️  追加で有効化する項目はありませんでした"
fi
echo ""

# ---------------------------------------------------------------------------
# STEP 6/6: Claude Desktop MCP 設定 + 端末認証起動
# ---------------------------------------------------------------------------
# ★見出しの「MCP」はお客様には通じない内部用語だった
set_phase "Claude Desktop との連携設定と端末のご登録" "インターネットの接続をご確認のうえ、このファイルをもう一度ダブルクリックしてください。二重にご登録されることはありません。"
echo "[STEP 6/6] Claude Desktop との連携設定 + 端末の登録"

CLAUDE_CONFIG="$HOME/Library/Application Support/Claude/claude_desktop_config.json"
mkdir -p "$(dirname "$CLAUDE_CONFIG")"
if [ -f "$CLAUDE_CONFIG" ]; then
    cp "$CLAUDE_CONFIG" "$CLAUDE_CONFIG.bak.$TS"
    echo "  既存 claude_desktop_config.json をバックアップ: $CLAUDE_CONFIG.bak.$TS"
fi

# python3 で安全に MERGE (既存 mcpServers を保持)
# ★python3 が無い場合の扱い (T-702)
#   従来はここで終了コード 127 になり、ERR トラップが発火して導入が丸ごと中断していた。
#   その結果、直後にある端末認証まで到達できず、お客様は登録すらできないまま終わる。
#   設定の書き換えは「検査」ではなく「作業」なので、行えなかった事実を要対応へ
#   集約したうえで、端末認証へは進む (前提ソフト工程と同じ fail-open の作法)。
# ★ここも「在るか」ではなく「動くか」で判定する。
#   開発ツール未導入の macOS では python3 の入口だけが実在するため、
#   存在確認だけだと先へ進んでしまい、設定の書き込みが途中で失敗する。
if ! { command -v python3 >/dev/null 2>&1 && python3 --version >/dev/null 2>&1; }; then
    echo "  ⚠️  Claude Desktop への登録は行えませんでした (Python 3 がこの端末で動きません)"
    # ★2026-08-15 是正: ここには「ターミナルを開いて 1 行を貼り付ける」手順と、
    #   その打ち込む内容そのものが書かれていた。開く場所まで書いてあっても、
    #   ターミナルを使ったことのないお客様には荷が重く、打ち間違いの余地も残る。
    #   このセットアップは実行のたびに Apple の導入画面を自分で呼び出しているので、
    #   「もう一度ダブルクリックすれば、その画面がまた出る」だけを案内すれば足りる。
    #   打ち込みを求めない案内に統一する (お客様の画面に打ち込むものを出さない)。
    add_issue "Claude Desktop への登録" "$(cat <<'PY3ISSUE'
Python 3 を導入したあと、このファイルをもう一度ダブルクリックしてください。
Python 3 の入れかた:
  1. 画面に『コマンドラインデベロッパツールをインストールしますか?』という
     Apple の確認画面が出ていれば、[インストール] を押して終わるまでお待ちください
     (Python 3 はこの中に含まれます)。
  2. その画面が見当たらないときは、このファイルをもう一度ダブルクリックしてください。
     Apple の確認画面をあらためてお出しします。
  3. 導入が終わったら、このファイルをもう一度ダブルクリックしてください。
うまくいかないときは nomura.y@soloptilink.com までご連絡ください。
PY3ISSUE
)"
else
SOLOPTILINK_BIN="$HOME/.soloptilink/soloptilink" python3 - "$CLAUDE_CONFIG" <<'PYEOF'
import json, sys, os
cfg_path = sys.argv[1]
bin_path = os.environ['SOLOPTILINK_BIN']
if os.path.exists(cfg_path) and os.path.getsize(cfg_path) > 0:
    try:
        with open(cfg_path) as f:
            cfg = json.load(f)
    except Exception:
        cfg = {}
else:
    cfg = {}
cfg.setdefault('mcpServers', {})
cfg['mcpServers']['soloptilink'] = {'command': bin_path, 'args': ['--mcp-server']}
with open(cfg_path, 'w') as f:
    json.dump(cfg, f, indent=2, ensure_ascii=False)
# ★「MCP サーバー」はお客様には通じない内部用語だった
print("  ✅ Claude Desktop との連携を登録しました")
PYEOF
fi

# ★すでに登録済みなら、入力を求めずに飛ばす。
#   【なぜ要るか】案内はどれも「もう一度ダブルクリックしてください」で終わるが、
#   Mac 側にはこの事前確認が無かったため、再実行するたびに必ず入力待ちへ戻っていた。
#   お客様が席を離れていると、そこで止まったまま完了しない (申告①の「放置したが
#   完了しなかった」に直結する)。Windows 側には同等の確認が実装済みで、
#   これも Mac だけが取り残されていた片側実装である。
#
# ★★ 登録済みと判断してよい条件 (2026-08-17 是正 / 株式会社NEW CAREER 様事案) ★★
#   【起きたこと】一度目の登録に失敗したあと、何度セットアップをやり直しても
#   「すでに登録済みです」と表示され、メールアドレスの入力を二度と求められない。
#   申請が一件も送られないため、お客様は「申請したのに承認されない」、
#   当社は「申請が届いていない」という食い違いのまま止まっていた。
#   【原因】従来はここで「認証系ファイルを1つでも引き継げたか (AUTH_CARRIED)」を
#   登録済みの根拠にしていた。しかし .device_identity.json (端末の指紋) は
#   登録の成否によらず作られるため、登録に失敗した端末でも必ず条件を満たす。
#   一度失敗すると二度と登録できない、出口のない状態に入る。
#   【是正】登録が済んだ証拠は activation.json と license.json がそろっていること。
#   その上で本体自身に状態を尋ね、肯定が取れたときにだけ入力を省く。
#   証拠が無いときは必ず登録工程へ進む (飛ばして完了に見せることを禁ずる)。
#   【判断の材料をサーバ照会にしない理由】
#   登録の有無をサーバへの問い合わせ結果で決めると、接続が不調なだけの端末を
#   「未登録」と読み、逆に問い合わせが通らないときの既定値しだいでは未登録の端末を
#   「登録済み」と読む。どちらも接続状態しだいで結論が変わってしまう。
#   端末に残る登録の記録 (license.json の状態) で判断すれば、接続に左右されない。
#   これは診断 (self-check) が使っている基準と同じものであり、
#   「診断は未登録と言うのにセットアップは登録済みと言う」食い違いも同時に無くなる。
cd "$HOME/.soloptilink"
_ALREADY_REGISTERED=0
if [ -f "$HOME/.soloptilink/activation.json" ] && [ -f "$HOME/.soloptilink/license.json" ]; then
    if LC_ALL=C grep -Eq '"status"[[:space:]]*:[[:space:]]*"(approved|pending|waiting)"' \
        "$HOME/.soloptilink/license.json" 2>/dev/null; then
        _ALREADY_REGISTERED=1
    fi
fi

if [ "$_ALREADY_REGISTERED" -eq 1 ]; then
    echo ""
    echo "  ✅ この端末はすでに登録済みです (入力は不要です)"
    echo ""
else

echo ""
echo "  ── この端末のご登録 ──"
echo ""
echo "  このあと、メールアドレスとパスワードの入力をお願いします。"
echo "  当社からお送りしたご案内メールをお手元にご用意ください。"
echo ""
echo "  ※ パスワードは、安全のため入力しても画面には表示されません。"
echo "     これは正常な動作です。そのまま最後まで入力してください。"
echo ""
sleep 3

# 端末認証を自動チェーン
# 承認待ちポーリング(最大30分)はインストーラ内では行わない
# (登録だけ行い即座に完了画面へ。承認後は自動で有効になる)。
SOLOPTILINK_ACTIVATE_NO_WAIT=1 ./soloptilink --activate || {
    # ★従来はここに打ち込むコマンドを並べていたが、
    #   ターミナルを使わないお客様には実行できない案内だった。
    #   もう一度ダブルクリックすれば同じ登録がやり直せるので、それだけを案内する。
    # ★ここで打ち切らない。
    #   【この実装が必要な理由】従来はここで導入そのものを終了していた。そのため、
    #   前提ソフトの工程が積み上げた「要対応一覧」も、導入の自己診断も、完了画面も
    #   一つも表示されないまま終わっていた。お客様の画面には「登録できませんでした」
    #   だけが残り、他に何が終わっていて何が残っているのかが分からない。
    #   Windows 側は同じ場面で続行し、要対応をまとめて出してから終わる。
    #   ここも同じ形に揃え、最後まで進んでから未完了をまとめてお伝えする。
    echo ""
    echo "  ⚠️  ご登録が完了しませんでした (この後の案内をあわせてご確認ください)"
    echo ""
    # ★案内の順番を、実際に多い原因の順に改めた (2026-08-17)
    #   従来は「インターネット接続をご確認ください」を先頭に置いていたが、
    #   ここまでの工程 (本体の取得・前提ソフトの導入) が終わっている時点で
    #   接続はほぼ確実に生きている。実際に多いのは入力のつまずきであり、
    #   先頭の一文が当たらないと、お客様は確かめようのない項目から順に試すことになる。
    add_issue "端末の登録" "端末のご登録が完了していません。当社からお送りしたご案内メールに記載のメールアドレスとパスワードをご確認のうえ、このファイルをもう一度ダブルクリックしてください (二重に登録されることはありません)。パスワードは入力しても画面に表示されませんが、正しく受け付けています。パスワードが分からない場合や、解消しない場合は、この画面の写真を撮って nomura.y@soloptilink.com までお送りください"
    ACTIVATION_FAILED=1
}
fi   # ★T-3: 登録済み事前確認の分岐ここまで

# ---------------------------------------------------------------------------
# 仕上げの実測 (「完了」と表示してよいかを、表示する前に確かめる)
# ---------------------------------------------------------------------------
# ★順序の是正 (2026-08-15)
#   従来は「セットアップ完了!」の額を先に出し、そのあとで動作確認と自己診断を走らせ、
#   要対応を後ろに並べていた。要対応が残っている端末にも先に「完了」と言い切るため、
#   お客様は完了したものと受け取ってそのまま使い始めてしまう。
#   実測と診断を先に済ませ、その結果で見出しを決める。
set_phase "導入内容の確認" "このファイルをもう一度ダブルクリックしてください。確認からやり直します。ここまでの導入内容はそのまま残っています。"

# 動作確認 (各前提ソフトのバージョンを実測表示)
echo "  ── 動作確認 ──"
export PATH="$HOME/.local/bin:$PATH"
for c in git node npm claude python3; do
    if command -v "$c" >/dev/null 2>&1; then
        printf "    [ OK ] %-7s: %s\n" "$c" "$($c --version 2>/dev/null | head -1)"
    else
        printf "    [要対応] %-7s: 確認できません (再起動後に再確認してください)\n" "$c"
    fi
done
echo ""

# ---------------------------------------------------------------------------
# 導入自己診断 (AC-I08) — 「最後まで走った」ではなく「診断が通った」を完了とする
# ---------------------------------------------------------------------------
# 【何が壊れていたか (T-017e)】installer/self-check.sh は 12 項目の自己診断を
#   実装し配布物にも同梱されているのに、Mac/Windows どちらのインストーラからも
#   呼ばれていなかった (呼出元は社内テストの台帳行と同梱必須リストだけ)。
#   そのため従来の完了画面は「セットアップが最後まで走った」ことしか示さず、
#   スキル未配置・フック未登録のまま「完了」と表示していた。
# 【契約】診断は fail-open。× があってもここで導入を中断しない (要対応一覧へ集約する)。
#   無効化: SOLOPTILINK_SELF_CHECK=off (診断側が「無効化した事実」を記録して終了する)
SELF_CHECK_SH=""
for _sc_cand in \
    "$HOME/.soloptilink/installer/self-check.sh" \
    "$KIT_DIR/installer/self-check.sh" \
    "$KIT_DIR/self-check.sh"; do
    if [ -f "$_sc_cand" ]; then SELF_CHECK_SH="$_sc_cand"; break; fi
done
if [ -n "$SELF_CHECK_SH" ]; then
    echo "  ── 導入の自己診断 ──"
    # ★ERR トラップの落とし穴:
    #   set +e は ERR トラップを抑止しない (bash では errexit と ERR トラップは別物)。
    #   診断が × を返した瞬間に「エラーが発生しました」の異常終了画面が出て、
    #   せっかく印字した診断結果の意味が顧客に伝わらなくなる。
    #   || で受けることで ERR トラップの発火条件から外し、rc だけを回収する。
    SELF_CHECK_RC=0
    bash "$SELF_CHECK_SH" run || SELF_CHECK_RC=$?
    if [ "$SELF_CHECK_RC" -ne 0 ]; then
        add_issue "導入の自己診断" "診断で確認が必要な項目が見つかりました。上の診断結果に表示された「お客様がすること」を実施してから、もう一度このファイルをダブルクリックしてください"
    fi
    echo ""
else
    echo "  ⚠️  導入の自己診断を実施できませんでした (診断の部品が見つかりません)"
    add_issue "導入の自己診断" "自己診断に必要な部品が配布物の中に見当たりません。ZIP をもう一度展開し直してから再実行するか、nomura.y@soloptilink.com へご連絡ください"
fi

# ---------------------------------------------------------------------------
# 完了画面 (要対応が 1 件でも残っていれば「完了」とは表示しない)
# ---------------------------------------------------------------------------
# 【なぜ分けるか】「完了」は、お客様がこの先の作業を安心して始めてよいという合図である。
#   要対応が残ったまま同じ合図を出すと、直っていないものを直ったと受け取らせてしまう。
if [ "${#PREREQ_ISSUES[@]}" -gt 0 ]; then
cat <<'DONE'

  ╔════════════════════════════════════════════════════════════════╗
  ║                                                                ║
  ║      ⚠️  セットアップは一部が未完了です                         ║
  ║                                                                ║
  ╚════════════════════════════════════════════════════════════════╝

DONE
    printf '  【要対応】以下は自動で完了できませんでした (%s 件):\n' "${#PREREQ_ISSUES[@]}"
    # 対処が複数行になる項目 (手順つきの案内) は 2 行目以降も字下げして読めるようにする
    for it in "${PREREQ_ISSUES[@]}"; do
        printf '    ・%s: %s\n' "${it%%|*}" "${it#*|}" | sed '2,$s/^/      /'
    done
    echo ""
    echo "  ※ まず上記を解消し、このファイルをもう一度ダブルクリックしてください。"
    echo "     解消したところから続きが進みます (はじめからやり直しにはなりません)。"
    echo ""
else
cat <<'DONE'

  ╔════════════════════════════════════════════════════════════════╗
  ║                                                                ║
  ║      ✅ SoloptiLinkAI セットアップ完了！                        ║
  ║                                                                ║
  ╚════════════════════════════════════════════════════════════════╝

DONE
fi

cat <<'DONE'
  次のステップ:

    1. Claude Desktop / Claude Code を一度終了して、再起動してください
       (SoloptiLinkAI との連携を読み込むため)

    2. 起動後、チャット欄に /soloptilink-boost と入力し、
       続けてお仕事の内容をそのままお伝えください

DONE

# ★例示とご利用開始の案内は正典 (lib/onboarding-canon.sh) から取り出して表示する
#   (T-703 / T-706)。ここに文面を書き写すと、手順書・同梱案内・
#   ランチャーの案内と必ずどこか 1 箇所だけが古くなる。実測でも、手順書 3 本は
#   「最大で1〜2営業日」、この完了画面は「通常1営業日以内」と食い違っていた。
_OBC="$HOME/.soloptilink/lib/onboarding-canon.sh"
if [ -f "$_OBC" ]; then
    bash "$_OBC" emit starter 2>/dev/null | sed 's/^/    /' || true
    echo ""
    bash "$_OBC" emit wait 2>/dev/null | sed 's/^/    /' || true
else
    echo "    ご利用開始のタイミングは、同梱の手順書をご覧ください。"
fi

# ★従来はここに打ち込むコマンドを 1 行そのまま出していた
#   (ご登録の状態を確かめる 1 行)。ターミナルを開いたことのないお客様には実行できず、
#   「自分の端末が使える状態か」を自力で確かめる手段が無くなっていた。ご登録の状態を
#   確かめる道順は正典 (上の「ご利用開始のタイミングについて」) が持っているので、
#   ここでは書き写さない。
cat <<'DONE'

  サポート: nomura.y@soloptilink.com

DONE

# Claude Code ログインと有料プランの注意
# ★従来は「またはターミナルで claude」と併記していたが、
#   打ち込む場所も手順も書かれておらず、Claude Desktop を使わないお客様が
#   そこで止まっていた。画面上で完結する Claude Desktop の道順だけを案内する。
echo "  ── Claude Code のログイン ──"
echo "    初回のみログインが必要です。Claude Desktop を起動し、画面の案内にしたがって"
echo "    ログインしてください (すでにログイン済みの場合はそのままお使いいただけます)。"
echo "    ※ ご利用には有料の Claude プラン (Pro / Max / Team / Enterprise) または"
echo "      API のご契約が必要です。無料プランでは Claude Code は使えません。"
echo ""

# ★キー入力を待てない状況 (入力が閉じられた状態で起動された等) でも、
#   ここで異常終了させない。実走で確認: この read が失敗すると ERR トラップが
#   発火し、正常に終わった直後のお客様の画面に「予期しない問題が発生しました」が
#   出てしまう (導入は成功しているのに失敗したと受け取られる)。
echo "[Enterキーで閉じます]"
read -r _ || true
exit 0
