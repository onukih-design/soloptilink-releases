@echo off
setlocal EnableExtensions
set "RC=1"
rem ---------------------------------------------------------------
rem  SoloptiLinkAI Windows setup launcher
rem  PFP-108 invariant: this .bat MUST stay ASCII-only / CRLF / no BOM.
rem  Japanese guidance is delegated to PowerShell -EncodedCommand
rem  (UTF-16LE base64), never written as raw Japanese bytes in this file.
rem  Kill-switch: set SOLOPTILINK_BAT_JA=0 to fall back to English-only
rem  output (the behaviour this file had before 2026-08-06 / T-370).
rem ---------------------------------------------------------------

set "PSOK=0"
where powershell >nul 2>&1 && set "PSOK=1"
set "JA=1"
if "%SOLOPTILINK_BAT_JA%"=="0" set "JA=0"
if "%PSOK%"=="0" set "JA=0"

echo.
echo =================================================================
echo  SoloptiLinkAI  Windows Setup
echo  (Please wait - this window proceeds automatically)
echo =================================================================
echo.

echo [STEP 1/3] Checking PowerShell
if "%PSOK%"=="0" (
  echo  [FAIL] PowerShell not found. Windows 10 or later is required.
  rem  PowerShell is missing here, so the EncodedCommand fallback used
  rem  elsewhere in this file cannot run. ASCII romaji is the only way
  rem  to reach a Japanese reader on this path without breaking PFP-108.
  echo  [ERROR] PowerShell ga mitsukarimasen.
  echo          Windows 10 ijou no PC de jikkou shite kudasai.
  echo          Osore irimasu ga, support made go-renraku kudasai:
  echo          nomura.y@soloptilink.com
  goto END_PAUSE
)
echo  [ OK ] PowerShell is available

echo.
echo [STEP 2/3] Launching installer (Japanese guidance appears below)
if "%JA%"=="1" powershell -NoProfile -EncodedCommand VwByAGkAdABlAC0ASABvAHMAdAAgACcAJwAKAFcAcgBpAHQAZQAtAEgAbwBzAHQAIAAnACAAUwBvAGwAbwBwAHQAaQBMAGkAbgBrAEEASQAgALswwzDIMKIwwzDXMCAAKABXAGkAbgBkAG8AdwBzACkAJwAKAFcAcgBpAHQAZQAtAEgAbwBzAHQAIAAnACAAUzBuMDt1YpdvMOqB1VJnMDKQfzB+MFkwAjCJlVgwWjBrMF0wbjB+MH4wSjCFX2EwTzBgMFUwRDACMCcACgBXAHIAaQB0AGUALQBIAG8AcwB0ACAAJwAnAAoAVwByAGkAdABlAC0ASABvAHMAdAAgACcAIABbAEtiBpggADEALwAzAF0AIABQAG8AdwBlAHIAUwBoAGUAbABsACAAkjC6eI2KVzB+MFcwXzACMCcACgBXAHIAaQB0AGUALQBIAG8AcwB0ACAAJwAgAFsAS2IGmCAAMgAvADMAXQAgAKQw8zC5MMgw/DDpMPwwLGdTT5Iwd43VUlcwfjBZMAIwUzBTMEswiTBIUW8w5WUsZ56KZzBUMEhohVFXMH4wWTACMCcA
set "PS1=%~dp0soloptilink-install.ps1"
if not exist "%PS1%" (
  echo [FAIL] soloptilink-install.ps1 was not found next to this file.
  echo        Please keep this .bat and soloptilink-install.ps1 in the same folder.
  rem Japanese guidance is rendered via PowerShell EncodedCommand.
  rem This .bat must stay ASCII-only (PFP-108 bat hygiene invariant).
  powershell -NoProfile -EncodedCommand VwByAGkAdABlAC0ASABvAHMAdAAgACcAJwAKAFcAcgBpAHQAZQAtAEgAbwBzAHQAIAAnAFsAqDDpMPwwXQAgAKQw8zC5MMgw/DDpMPwwLGdTTyAAKABzAG8AbABvAHAAdABpAGwAaQBuAGsALQBpAG4AcwB0AGEAbABsAC4AcABzADEAKQAgAEwwi4lkMEswijB+MFswkzACMCcACgBXAHIAaQB0AGUALQBIAG8AcwB0ACAAJwBaAEkAUAAgANUwoTCkMOswkjDzU68w6jDDMK8wVzBmMAwwWTB5MGYwVVyLlQ0wkjB4kHMwATBVXIuVjF9uMNUwqTDrMMAwbjAtTmcwJwAKAFcAcgBpAHQAZQAtAEgAbwBzAHQAIAAnAFMwbjDVMKEwpDDrMJIwgjBGMABOpl7AMNYw6zCvMOowwzCvMFcwZjBPMGAwVTBEMAIwJwAKAFcAcgBpAHQAZQAtAEgAbwBzAHQAIAAnAEow8FaKMG4wNFgIVG8wtTDdMPwwyDCTeuNTeDA6ACAAcwB1AHAAcABvAHIAdABAAHMAbwBsAG8AcAB0AGkAbABpAG4AawAuAGMAbwBtACcA
  goto END_PAUSE
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" %*
set "RC=%ERRORLEVEL%"

echo.
echo [STEP 3/3] Finished (exit code = %RC%)
if "%JA%"=="1" powershell -NoProfile -EncodedCommand VwByAGkAdABlAC0ASABvAHMAdAAgACcAIABbAEtiBpggADMALwAzAF0AIAC7MMMwyDCiMMMw1zDmUQZ0TDBCfYZOVzB+MFcwXzACMEJ9hk6zMPwwyTBvMApObjBMiGswaIg6eVcwZjBEMH4wWTACMCcA

:END_PAUSE
echo.
echo =================================================================
echo  Press any key to close this window...
where powershell >nul 2>&1 && powershell -NoProfile -EncodedCommand VwByAGkAdABlAC0ASABvAHMAdAAgACcAIABTMG4wpjCjMPMwyTCmMJIwiZVYMIswazBvMAEwRDBaMIwwSzBuMK0w/DCSMLxiVzBmME8wYDBVMEQwLgAuAC4AJwA=
echo =================================================================
pause >nul
endlocal
exit /b %RC%
