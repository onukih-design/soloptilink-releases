﻿# =============================================================================
# SoloptiLinkAI v2038.2 - Windows PowerShell Installer
# =============================================================================
# Built: 2026-06-11 (Nomura incident response - ZIP配布形式対応)
# Purpose: 配布物の自動配置 + lib/ 完整性検証 + Goランチャー認証起動
#   モードA (ZIP配布 / 主経路): 解凍済み配布フォルダ (installer の親) を
#     ~\.soloptilink へ配置する。顧客ZIP (SoloptiLinkAI_vX.Y_Windows.zip) は
#     展開済みフォルダ形式のため tar.gz は同梱されない。
#   モードB (tar.gz / 保守経路): soloptilink-update-*.tar.gz を検出して展開する。
# Compliance: WCG-2 (critical files), WCG-5 (LF guard), WCG-11 (tar)
# Hinoue-incident compliant: no cls / no findstr / END_PAUSE / STEP markers
# =============================================================================

[CmdletBinding()]
param(
    [string]$TarballPath = "",
    # 2026-07-13: $HOME (HOMEDRIVE+HOMEPATH 由来) ではなく %USERPROFILE% を既定にする。
    # Goランチャー/自動更新フックは os.UserHomeDir()=%USERPROFILE% を参照するため、
    # AD ホームフォルダリダイレクトのある企業PCで導入先と参照先が分裂する事故を防ぐ。
    [string]$InstallDir = $(if ($env:USERPROFILE) { Join-Path $env:USERPROFILE '.soloptilink' } else { "$HOME\.soloptilink" }),
    [switch]$SkipExtract,
    [switch]$Force,
    [switch]$Verify,
    [switch]$NoActivate
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

# -----------------------------------------------------------------------------
# Colored output (Hinoue-incident compliant: no cls, no findstr)
# -----------------------------------------------------------------------------
# いま実行中の工程 (異常終了画面が「どこで止まったか」を言えるようにするための状態)
#   ★2026-08-15 新設。従来 Write-Step は工程名を【表示】するだけで、どこまで進んだかを
#     保持する場所がどこにも無かった。そのため最上位 trap は「予期しない問題が発生しました」
#     としか言えず、お客様は止まった場所も次の一手も分からないまま放置された
#     (過去の導入失敗と同じ構造)。工程名と、その工程で次にすることを保持する。
$script:CurrentStep     = '準備中'
$script:CurrentStepNext = 'このファイルをもう一度実行して、はじめからやり直してください。'
function Write-Step($msg, $next) {
    $script:CurrentStep = $msg
    if ($next) { $script:CurrentStepNext = $next }
    else { $script:CurrentStepNext = 'このファイルをもう一度実行してください。ここまでの導入内容はそのまま残っています。' }
    Write-Host "[STEP] $msg" -ForegroundColor Cyan
}
function Write-Ok($msg)   { Write-Host "[ OK ] $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "[WARN] $msg" -ForegroundColor Yellow }
function Write-Err($msg)  { Write-Host "[FAIL] $msg" -ForegroundColor Red }
function Write-Skip($msg) { Write-Host "[SKIP] $msg" -ForegroundColor DarkGreen }

# 前提ソフト導入の「要対応一覧」を集約する collector (StrictMode 対策で先に初期化)
$script:Issues    = @()
$script:HasWinget = $false
$script:LogPath   = ""
function Add-Issue($item, $detail, $remedy) {
    $script:Issues += [PSCustomObject]@{ Item = $item; Detail = $detail; Remedy = $remedy }
}
function Test-CommandExists($name) {
    return [bool](Get-Command $name -ErrorAction SilentlyContinue)
}
# 前提ソフトの 3 値判定 (Mac 側 prereq_probe と同じ規律を Windows でも用いる)
#   absent = 入口ごと無い / present_but_broken = 入口はあるが動かない / available = 実際に動く
#   ★存在確認だけで合格にしない。Windows には python3.exe のように「ストアへ誘導するだけの
#     入口」が既定で置かれており、在ることと使えることは別である。
$script:PrereqVersion = ''
function Get-PrereqVerdict($cmd, $verArg, $pattern) {
    $script:PrereqVersion = ''
    if (-not (Test-CommandExists $cmd)) { return 'absent' }
    $out = ''
    try { $out = ((& $cmd $verArg 2>&1 | Select-Object -First 1 | Out-String)).Trim() } catch { $out = '' }
    if (-not $out) { return 'present_but_broken' }
    if ($out -match $pattern) { $script:PrereqVersion = $out; return 'available' }
    return 'present_but_broken'
}
# 現セッションの PATH をマシン+ユーザー+既知の claude 配置先から再構築する。
# (winget / ネイティブインストーラ導入直後は現セッションに PATH 未反映のため必須)
#
# ★ ~/.local\bin を固定合成している理由 (重要・既知バグ #21365 への対処):
#   Claude Code 公式ネイティブインストーラ (irm https://claude.ai/install.ps1 | iex) は
#   claude.exe を ~/.local\bin (C:\Users\<user>\.local\bin) へ配置するが、
#   ユーザー PATH レジストリ (HKCU Environment の Path) を更新しない既知バグがある
#   (anthropics/claude-code #21365 / #14902)。このため「Installation complete!」と
#   表示されても claude が CommandNotFoundException で即失敗する。本関数が ~/.local\bin
#   を固定で合成することで、レジストリ未更新でも現セッションから claude を発見でき、
#   この既知バグを回避している。
#   ※ 配置先 ~/.local\bin はハードコード前提。将来インストーラの配置先が変われば
#     この固定合成は追従しない。配信前に必ず実機で最新の配置先を確認すること。
function Update-SessionPath {
    $machine  = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $user     = [Environment]::GetEnvironmentVariable('Path', 'User')
    # 既知バグ #21365 への対処 (上記コメント参照): 公式配置先を固定で合成する。要実機確認。
    $localbin = Join-Path $HOME '.local\bin'
    $parts = @()
    foreach ($p in @($machine, $user, $localbin)) { if ($p) { $parts += ([string]$p).TrimEnd(';') } }

    # 配置先変更耐性 (任意・低優先): 他の既知候補に claude 実体があれば、その親ディレクトリも
    #   セッション PATH へ合成する。where / Get-ChildItem の再帰探索はレジストリ PATH 未更新下では
    #   空振りしうるため、ここでは "候補ディレクトリ内に claude.exe / claude.cmd が実在するか" を
    #   Test-Path でピンポイント確認し、見つかった親ディレクトリだけを足すに留める (探索しない)。
    #   ↓の候補は ~/.local\bin 以外まだ未確認。実機で実際の配置先が判明したら整理・追加すること。
    $binCandidates = @(
        $localbin,
        (Join-Path $env:LOCALAPPDATA 'Programs\claude')
    )
    foreach ($dir in $binCandidates) {
        if (-not $dir) { continue }
        $hit = (Test-Path (Join-Path $dir 'claude.exe')) -or (Test-Path (Join-Path $dir 'claude.cmd'))
        $norm = ([string]$dir).TrimEnd(';')
        if ($hit -and ($parts -notcontains $norm)) { $parts += $norm }
    }

    $env:Path = ($parts -join ';')
}
# 技術的な内容 (英文の例外メッセージ・終了コード) を控えのログにだけ残す
# ★2026-08-10 新設: これらを画面に出しても、お使いになる方には意味が伝わらず、
#   次に何をすればよいかも分からない。原因調査に要る情報は setup_log.txt へ回し、
#   画面には日本語の案内だけを出す。ログが取れない環境でも黙って続行する。
function Write-DetailToLog($detail) {
    try {
        if ($script:LogPath -and $detail) {
            Add-Content -Path $script:LogPath -Value ([string]$detail) -Encoding UTF8
        }
    } catch { }
}

# 外部プロセスを看視付きで実行する。timeoutSec を超えたら強制終了し $null を返す
# (前提ソフトの導入が応答しなくなったとき、セットアップ全体が止まらないようにするための処理)。
function Invoke-WithTimeout($file, $argList, $timeoutSec, $label) {
    # 2026-07-13 敵対検証で確証: Start-Process -NoNewWindow の子プロセス出力はコンソール
    # 直書きとなり Start-Transcript (setup_log.txt) に一切残らない。最も失敗しやすい
    # 前提ソフト導入工程 (winget/公式インストーラ) のエラー詳細がサポートに届かなくなる
    # ため、ファイルへリダイレクトし完了後に転写する (転写は Write-Host 経由なので
    # Transcript に確実に載る)。
    # GetTempFileName は TEMP 不在/tmp枯渇(65535個)で IOException を投げ、EAP=Continue でも
    # 最上位 trap に到達してインストーラ全体を落とすため try 内で確保し、失敗時は
    # リダイレクトなし(転写なし)で続行するフォールバックにする。
    $outFile = $null; $errFile = $null
    try {
        $outFile = [System.IO.Path]::GetTempFileName()
        $errFile = [System.IO.Path]::GetTempFileName()
    } catch {
        if ($outFile) { Remove-Item $outFile -ErrorAction SilentlyContinue }
        $outFile = $null; $errFile = $null
        Write-Warn "  (一時ファイルを確保できないため $label の出力転写を省略します)"
    }
    try {
        if ($outFile) {
            $proc = Start-Process -FilePath $file -ArgumentList $argList -NoNewWindow -PassThru `
                -RedirectStandardOutput $outFile -RedirectStandardError $errFile
        } else {
            $proc = Start-Process -FilePath $file -ArgumentList $argList -NoNewWindow -PassThru
        }
    } catch {
        Write-DetailToLog ("launch-failure label={0} message={1}" -f $label, $_.Exception.Message)
        Write-Err "  $label を開始できませんでした (この工程は飛ばして続けます)"
        if ($outFile) { Remove-Item $outFile, $errFile -ErrorAction SilentlyContinue }
        return $null
    }
    # PS 5.1 既知問題: Handle に触れておかないと WaitForExit 後の ExitCode が $null になる
    # (プロセスハンドル未キャッシュ)。終了コードによる成否二分判定の生命線なので必須。
    $null = $proc.Handle
    $timedOut = $false
    if (-not $proc.WaitForExit($timeoutSec * 1000)) {
        $timedOut = $true
        Write-Warn "  $label が $timeoutSec 秒以内に完了しなかったため中断して次へ進みます。"
        # PS 5.1 の $proc.Kill() は子プロセスツリーを殺せない (winget の実インストーラが残る)
        # ため taskkill /T /F でツリーごと終了する。失敗時のみ Kill() にフォールバック。
        try { & taskkill /PID $proc.Id /T /F 2>$null | Out-Null } catch { try { $proc.Kill() } catch { } }
        try { $proc.WaitForExit(10000) | Out-Null } catch { }
        Add-Issue $label "導入処理が $timeoutSec 秒でタイムアウトしました (ネットワーク遅延またはハング)" '通信環境の良い状態で本インストーラを再実行するか、公式サイトから手動導入してください。導入済みの SoloptiLinkAI 本体はそのまま利用できます。'
    }
    # 子プロセス出力の転写 (タイムアウト時も途中までの出力を残す)。長大な場合は末尾のみ。
    # winget はリダイレクト時 BOM なし UTF-8 固定出力のため -Encoding UTF8 で読む
    # (PS 5.1 の既定は ANSI=CP932 で日本語エラーメッセージが化ける)。コンソールを
    # UTF-8 へ統一済みのため他の子プロセス (powershell 等) も UTF-8 で出力する。
    foreach ($f in @($outFile, $errFile)) {
        if (-not $f) { continue }
        try {
            if ((Test-Path $f) -and ((Get-Item $f).Length -gt 0)) {
                $lines = @(Get-Content $f -Encoding UTF8 -ErrorAction SilentlyContinue)
                if ($lines.Count -gt 120) {
                    $lines = @("... ($($lines.Count - 120) 行省略) ...") + $lines[-120..-1]
                }
                $lines | ForEach-Object { Write-Host "    | $_" -ForegroundColor DarkGray }
            }
        } catch { }
        Remove-Item $f -ErrorAction SilentlyContinue
    }
    if ($timedOut) { return $null }
    return $proc.ExitCode
}

# winget で1パッケージを導入 → PATH 再構築 → コマンド再検出で成否判定 (失敗は記録して継続)
#   ★winget の終了コードを捕捉し「導入失敗(ネット/権限/ソース)」と「要再起動(PATH未反映)」を二分する。
#     これをしないと、社内プロキシ遮断・ストアソース無効・管理者権限不足での失敗時に
#     『PC再起動で直る』という再起動では直らない誤った対処を要対応一覧に出してしまう
#     (日本の管理された Windows 端末で発火確度が高い)。
function Install-ViaWinget($packageId, $displayName, $verifyCommand, $officialUrl) {
    if (-not $script:HasWinget) {
        Write-Err "$displayName を自動導入できません (winget 非搭載)"
        Add-Issue $displayName 'winget (アプリ インストーラー) がこの PC に無いため自動導入できませんでした' "Microsoft Store から「アプリ インストーラー」を導入して再実行するか、公式サイト ($officialUrl) から手動で導入してください。企業管理 PC でストアが使えない場合は社内 IT 部門へ導入をご依頼ください。"
        return $false
    }
    Write-Host "  $displayName を導入中... (winget: $packageId)"
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    # ハング対策 (2026-07-13): winget が応答しなくなっても最大10分で打ち切り、
    # セットアップ全体を巻き込まない (要対応一覧に集約して続行)。
    $code = Invoke-WithTimeout 'winget' @('install','--id',$packageId,'-e','--source','winget','--accept-source-agreements','--accept-package-agreements','--silent') 600 $displayName
    if ($null -eq $code) { $code = -1 }
    $ErrorActionPreference = $prev
    Update-SessionPath
    if (Test-CommandExists $verifyCommand) {
        Write-Ok "  $displayName 導入完了"
        return $true
    }
    # winget は走ったがコマンド未検出 → 終了コードで「成功(要再起動)」と「導入失敗」を二分する。
    #   0 / 既導入 (-1978335189 = 0x8A15002B) = 導入は成功扱い → PATH 反映待ち (再起動で直る)
    #   それ以外 = 導入そのものが失敗 (ネット遮断 / ソース無効 / 権限不足) → 再起動では直らない
    if ($code -eq 0 -or $code -eq -1978335189) {
        Write-Warn "  $displayName を導入しましたが、このセッションでは確認できませんでした (PC 再起動後に反映)"
        Add-Issue $displayName '導入は成功しましたが PATH の反映に再起動が必要な可能性があります' 'PC を再起動後、新しいウィンドウで動作確認してください'
    } else {
        Write-DetailToLog ("winget-exit displayName={0} code={1}" -f $displayName, $code)
        Write-Err "  $displayName の自動導入に失敗しました"
        Add-Issue $displayName "自動導入に失敗しました。社内のネットワーク制限による配信先の遮断、社内ポリシーによる導入元の無効化、または権限の不足が考えられます" "ネットワーク管理者に winget 配信先 (cdn.winget.microsoft.com 等) の許可を依頼するか、公式サイト ($officialUrl) のインストーラを IT 部門経由で導入してください。管理者権限が必要な場合があります。"
    }
    return $false
}

# Hinoue-incident: always pause at the end so cmd window does not vanish
function End-Pause {
    Write-Host ""
    Write-Host "==============================================================="
    Write-Host " 何かキーを押すとウィンドウを閉じます。"
    Write-Host "==============================================================="
    if ($Host.Name -eq "ConsoleHost") {
        [void][System.Console]::ReadKey($true)
    }
}

trap {
    # ★2026-08-10 是正: 従来は英文の例外メッセージをそのまま画面へ出していた。
    #   お客様には意味が伝わらず、次に何をすればよいかも分からない行き止まりだった。
    #   技術的な内容は控えのログへ回し、画面には日本語の案内だけを出す。
    $detail = "installer-failure step={0} line={1} message={2}" -f `
        $script:CurrentStep, $_.InvocationInfo.ScriptLineNumber, $_.Exception.Message
    try {
        if ($script:LogPath) { Add-Content -Path $script:LogPath -Value $detail -Encoding UTF8 }
    } catch { }
    Write-Err "予期しない問題が発生しました"
    Write-Host ""
    Write-Host "  セットアップを最後まで進められませんでした。"
    Write-Host ""
    Write-Host ("  止まったところ: {0}" -f $script:CurrentStep)
    Write-Host ""
    Write-Host "  次にしていただくこと:"
    Write-Host ("    {0}" -f $script:CurrentStepNext)
    Write-Host ""
    Write-Host "  それでも同じところで止まる場合は、この画面の写真を撮って、"
    Write-Host "  nomura.y@soloptilink.com までお送りください。"
    Write-Host "  こちらで原因をお調べして、ご連絡いたします。"
    try { Stop-Transcript | Out-Null } catch { }
    End-Pause
    exit 1
}

# -----------------------------------------------------------------------------
# Banner
# -----------------------------------------------------------------------------
Write-Host ""
Write-Host "================================================================="
Write-Host " SoloptiLinkAI  Windows セットアップ"
Write-Host "================================================================="
Write-Host ""

# 実行ログを setup_log.txt に保存 (うまくいかない時の原因切り分け用)
try {
    if (-not (Test-Path $InstallDir)) { New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null }
    $script:LogPath = Join-Path $InstallDir 'setup_log.txt'
    Start-Transcript -Path $script:LogPath -Append | Out-Null
} catch {
    $script:LogPath = ""
    Write-Host "  (ログの保存に失敗しました。環境ポリシーの可能性があります。処理は続行します。)" -ForegroundColor DarkGray
}

# 2026-07-13 敵対検証で確証: Goランチャーは日本語をUTF-8で出力するが、日本語Windowsの
# コンソール既定はCP932のため、PS 5.1がネイティブ出力をキャプチャすると文字化けし、
# 「承認済み」「登録しました」等の成否判定matchが恒常的に不成立になる(承認済み端末への
# 再認証強要・フック登録の偽警告)。コンソールをUTF-8へ統一して出力側の化けを根治する。
try {
    [Console]::OutputEncoding = [System.Text.Encoding]::UTF8
    $OutputEncoding = [System.Text.Encoding]::UTF8
} catch {
    Write-Host "  (コンソールのUTF-8切替に失敗しました。処理は続行します。)" -ForegroundColor DarkGray
}

# -----------------------------------------------------------------------------
# STEP 1: PowerShell / Windows 環境チェック
# -----------------------------------------------------------------------------
Write-Step "1/11 環境チェック"

$psVer = $PSVersionTable.PSVersion
Write-Host "  PowerShell: $psVer"
if ($psVer.Major -lt 5) {
    Write-Err "PowerShell 5.0+ が必要です。Windows Update を適用してください。"
    End-Pause; exit 1
}

$winVer = [System.Environment]::OSVersion.Version
Write-Host "  Windows:    $winVer"

# Long path support check
try {
    $longPath = Get-ItemPropertyValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem" -Name "LongPathsEnabled" -ErrorAction SilentlyContinue
    if ($longPath -eq 1) {
        Write-Ok "  ロングパス対応: 有効"
    } else {
        # ★2026-08-15 是正: ここには打ち込むコマンドとレジストリの場所がそのまま出ていた。
        #   お使いになる方には意味が伝わらず、打ち間違えると PC の設定を壊しかねない。
        #   何が起きるかと、誰に頼めばよいかだけを日本語で伝える。
        Write-Warn "  長いファイル名に対応する設定が有効になっていません"
        Write-Host "     (置き場所が深いフォルダで不具合が出ることがあります。導入はこのまま続けられます)"
        Write-Host "     設定の変更にはパソコンの管理者権限が必要です。社内の情報システム担当の方"
        Write-Host "     または nomura.y@soloptilink.com までご相談ください。"
    }
} catch {
    Write-Warn "  長いファイル名に対応する設定は確認できませんでした (確認できなかっただけで、問題があると判断したわけではありません)"
}

# -----------------------------------------------------------------------------
# STEP 1.1: 準備状況の一括確認 (2026-08-15 新設)
#
# 【なぜここに在るか】前提ソフトの導入工程は STEP 11 (最後) にある。これは
#   「winget が固まっても本体だけは必ず入れ切る」ための正しい順序であり、動かさない。
#   ところが【判定】まで最後にあったため、足りないものがあってもお客様が知るのは
#   すべて終わってからだった。過去の導入失敗では、途中まで進んでから失敗し、
#   お客様は何をすればよいか分からないまま自力で回避策を探すことになった。
#   そこで「判定と提示」だけをここへ切り出す (導入する工程は STEP 11 のまま)。
#
# 【この工程がすること / しないこと】
#   する  : 見るだけ。空き容量・接続・基本ソフトの版・前提ソフトの実行可否を測って一覧にする。
#   しない: 導入・設定変更・ダウンロード。一切行わない (だから安全に先頭へ置ける)。
#
# 全部そろっていれば一覧を出さずに素通りする。足りなければ 1 画面で示し、
# 続けるか中断するかをお尋ねする。確認できなかった項目は「問題なし」に丸めない。
#
# 無効化: SOLOPTILINK_PREFLIGHT=off (無効化した事実を控えのログに残して通過する)
# 調整  : SOLOPTILINK_MIN_FREE_MB (既定 2048) / SOLOPTILINK_PREFLIGHT_NET_TIMEOUT (既定 6 秒)
# -----------------------------------------------------------------------------
$script:PfRows    = @()
$script:PfNeed    = 0
$script:PfAuto    = 0
$script:PfUnknown = 0
function Add-PfRow($item, $verdict, $message, $carry) {
    $script:PfRows += [PSCustomObject]@{ Item = $item; Verdict = $verdict; Message = $message; Carry = $carry }
    if ($verdict -eq 'need')    { $script:PfNeed++ }
    if ($verdict -eq 'auto')    { $script:PfAuto++ }
    if ($verdict -eq 'unknown') { $script:PfUnknown++ }
}
# 空き容量 (MB)。取れなければ $null (呼び出し側で「確認できなかった」にする)
function Get-PfFreeMb($path) {
    try {
        $root = [System.IO.Path]::GetPathRoot($path)
        if (-not $root) { return $null }
        $drive = New-Object System.IO.DriveInfo($root)
        if (-not $drive.IsReady) { return $null }
        return [int64]($drive.AvailableFreeSpace / 1MB)
    } catch { return $null }
}
# 接続確認。0=つながる / 1=つながらない / 2=確かめる手段が無い
#   応答の中身は見ない。何らかの応答が返ること自体が「そこへ届いた」証拠になる。
function Test-PfNet($url, $timeoutSec) {
    try {
        $req = [System.Net.HttpWebRequest]::Create($url)
        $req.Method  = 'HEAD'
        $req.Timeout = $timeoutSec * 1000
        $resp = $req.GetResponse()
        $resp.Close()
        return 0
    } catch [System.Net.WebException] {
        if ($_.Exception.Response) { return 0 }
        return 1
    } catch { return 2 }
}

Write-Step "1.1/11 準備状況の一括確認 (見るだけ。ここでは何も導入しません)" `
    '画面に出ている「ご確認」の項目を解消してから、このファイルをもう一度実行してください。'
if ("$($env:SOLOPTILINK_PREFLIGHT)".ToLower() -eq 'off') {
    Write-Host "  準備状況の確認は無効化されています (確認していません。問題が無いという意味ではありません)" -ForegroundColor DarkGray
    Write-DetailToLog ("preflight-skipped SOLOPTILINK_PREFLIGHT=off at {0}" -f (Get-Date -Format 's'))
} else {
    $pfEAP = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }

    # ① パソコンの基本ソフト
    #   下限の根拠: 顧客向け利用ガイドの動作環境表 (Windows 10 の 2018 年春の更新 = ビルド 17134 以降、
    #   または Windows 11)。ここを独自に決めると案内と食い違うため、その表に合わせる。
    $pfMinBuild = 17134
    if ($winVer -and $winVer.Build -gt 0) {
        if ($winVer.Build -ge $pfMinBuild) {
            Add-PfRow 'パソコンの基本ソフト' 'ok' ("Windows {0} — 対応しています" -f $winVer) $false
        } else {
            Add-PfRow 'パソコンの基本ソフト' 'need' 'この Windows は当社が動作を確認している範囲より古いものです。Windows Update を適用して最新の状態にしていただくか、nomura.y@soloptilink.com までご相談ください' $true
        }
    } else {
        Add-PfRow 'パソコンの基本ソフト' 'unknown' '基本ソフトの版を確認できませんでした (確認できなかっただけで、問題があると判断したわけではありません)' $true
    }

    # ② 空き容量
    #   下限の根拠: 本体の展開分に加え、Node.js のランタイムと、これから作る業務システムの
    #   部品置き場 (1 件あたり数百 MB) を見込んだ最低限。
    $pfMinFree = 2048
    if ($env:SOLOPTILINK_MIN_FREE_MB) { try { $pfMinFree = [int]$env:SOLOPTILINK_MIN_FREE_MB } catch { $pfMinFree = 2048 } }
    $pfFree = Get-PfFreeMb $InstallDir
    if ($null -eq $pfFree) {
        Add-PfRow 'ディスクの空き容量' 'unknown' '空き容量を確認できませんでした (確認できなかっただけで、足りないと判断したわけではありません)' $true
    } elseif ($pfFree -lt $pfMinFree) {
        Add-PfRow 'ディスクの空き容量' 'need' ("空きが {0} MB しかありません。導入と、これから作る業務システムのために {1} MB 以上の空きをご用意ください (使っていないファイルをごみ箱へ移し、ごみ箱を空にすると増えます)" -f $pfFree, $pfMinFree) $true
    } else {
        Add-PfRow 'ディスクの空き容量' 'ok' ("{0} MB の空きがあります" -f $pfFree) $false
    }

    # ③ インターネット接続 (本体の受け取り先と、前提ソフトの配布元)
    $pfNetTimeout = 6
    if ($env:SOLOPTILINK_PREFLIGHT_NET_TIMEOUT) { try { $pfNetTimeout = [int]$env:SOLOPTILINK_PREFLIGHT_NET_TIMEOUT } catch { $pfNetTimeout = 6 } }
    $pfNetAdmin  = Test-PfNet 'https://admin.soloptilink.com/' $pfNetTimeout
    $pfNetClaude = Test-PfNet 'https://claude.ai/' $pfNetTimeout
    if ($pfNetAdmin -eq 2 -or $pfNetClaude -eq 2) {
        Add-PfRow 'インターネット接続' 'unknown' '接続を確認できませんでした (確認できなかっただけで、つながっていないと判断したわけではありません)' $true
    } elseif ($pfNetAdmin -eq 0 -and $pfNetClaude -eq 0) {
        Add-PfRow 'インターネット接続' 'ok' '必要な接続先につながります' $false
    } else {
        Add-PfRow 'インターネット接続' 'need' '必要な接続先につながりませんでした。ネットワークの接続をご確認ください。社内のネットワーク制限 (プロキシ / ファイアウォール) が原因のこともありますので、その場合はネットワーク管理者に接続の許可をご依頼ください' $true
    }

    # ④⑤⑥⑦ 前提ソフト (この工程では導入しない。STEP 11 で導入する)
    $pfWinget = Test-CommandExists 'winget'
    $pfAutoNote = 'このあと自動で用意します (お客様の操作は不要です)'
    if (-not $pfWinget) { $pfAutoNote = 'このあと自動で用意します。うまくいかない場合は最後の【要対応】でご案内します' }

    if ((Get-PrereqVerdict 'git' '--version' 'git version [0-9]') -eq 'available') {
        Add-PfRow 'Git' 'ok' ("使えます ({0})" -f $script:PrereqVersion) $false
    } else {
        Add-PfRow 'Git' 'auto' $pfAutoNote $false
    }
    $pfNodeV = Get-PrereqVerdict 'node' '-v' '^v[0-9]'
    if ($pfNodeV -eq 'available' -and $script:PrereqVersion -match '^v(\d+)\.' -and [int]$matches[1] -ge 18) {
        Add-PfRow 'Node.js' 'ok' ("使えます ({0})" -f $script:PrereqVersion) $false
    } else {
        Add-PfRow 'Node.js' 'auto' $pfAutoNote $false
    }
    if ((Get-PrereqVerdict 'claude' '--version' '[0-9]') -eq 'available') {
        Add-PfRow 'Claude Code' 'ok' ("使えます ({0})" -f $script:PrereqVersion) $false
    } else {
        Add-PfRow 'Claude Code' 'auto' $pfAutoNote $false
    }
    # Python 3 は自動導入しない (ストアの同意画面を伴い無人では進まないため) = お客様の操作が要る
    if ((Get-PrereqVerdict 'python3' '--version' 'Python\s+3\.') -eq 'available') {
        Add-PfRow 'Python 3' 'ok' ("使えます ({0})" -f $script:PrereqVersion) $false
    } else {
        Add-PfRow 'Python 3' 'need' 'Microsoft Store で「Python 3」を検索して導入してください。社内の決まりで Store が使えない場合は、社内の情報システム担当の方にご相談ください。無いままでも導入は進みますが、作った業務システムの品質点検が行えません' $false
    }

    # --- 提示 (全部そろっていれば一覧を出さずに素通りする) ---
    if ($script:PfNeed -eq 0 -and $script:PfAuto -eq 0 -and $script:PfUnknown -eq 0) {
        Write-Ok ("  準備はととのっています ({0} 項目すべて確認しました)。このまま導入を進めます" -f $script:PfRows.Count)
    } else {
        Write-Host ""
        Write-Host "  ---------------------------------------------------------------"
        Write-Host "   導入をはじめる前に、次の点をご確認ください"
        Write-Host "  ---------------------------------------------------------------"
        foreach ($r in $script:PfRows) {
            switch ($r.Verdict) {
                'ok'      { Write-Host ("    [ 済 ] {0}" -f $r.Item) -ForegroundColor DarkGreen }
                'auto'    { Write-Host ("    [自動] {0}" -f $r.Item); Write-Host ("           {0}" -f $r.Message) }
                'need'    { Write-Host ("    [ご確認] {0}" -f $r.Item) -ForegroundColor Yellow; Write-Host ("           {0}" -f $r.Message) }
                'unknown' { Write-Host ("    [未確認] {0}" -f $r.Item) -ForegroundColor Yellow; Write-Host ("           {0}" -f $r.Message) }
            }
        }
        Write-Host "  ---------------------------------------------------------------"
        Write-Host ""
        if ($script:PfNeed -eq 0 -and $script:PfUnknown -eq 0) {
            Write-Host "   お客様の操作が必要な項目はありません。[自動] の項目はこのあと当社側で用意します。"
            Write-Host "   そのままお待ちください。"
            Write-Host ""
        } else {
            Write-Host "   このまま進めることもできます (進んだ分はそのまま残ります)。"
            Write-Host "   [ご確認] [未確認] の項目は、最後にもう一度まとめてお伝えします。"
            Write-Host ""
            $pfAns = ''
            if ($Host.Name -eq 'ConsoleHost') {
                try { $pfAns = Read-Host '   このまま進める場合はそのまま Enter、いったん中断する場合は半角の n を入力して Enter' } catch { $pfAns = '' }
            } else {
                Write-Host "   (この画面では入力を受け取れないため、このまま進みます)"
            }
            if ($pfAns -and (@('n','no','いいえ','中断') -contains "$pfAns".Trim().ToLower())) {
                Write-Host ""
                Write-Host "  いったん中断しました。"
                Write-Host "  上の [ご確認] の項目を解消してから、このファイルをもう一度実行してください。"
                Write-Host "  SoloptiLinkAI 本体はまだ入れていませんので、はじめからやり直していただけます。"
                try { Stop-Transcript | Out-Null } catch { }
                End-Pause
                exit 0
            }
            Write-Host "   このまま導入を進めます。"
            Write-Host ""
        }
        # 解消されないまま進んだ環境面の項目は、最後の【要対応】にも必ず残す
        # (お伝えしたことを、完了画面で無かったことにしない)
        foreach ($r in $script:PfRows) {
            if ($r.Carry -and ($r.Verdict -eq 'need' -or $r.Verdict -eq 'unknown')) {
                Add-Issue $r.Item '導入をはじめる前の確認で、そのままになっている点です' $r.Message
            }
        }
    }
    $ErrorActionPreference = $pfEAP
}

# -----------------------------------------------------------------------------
# STEP 1.2: スマート アプリ コントロール (SAC) の検知 + ダウンロード印 (MotW) の解除
#           導入時に実際に発生した停止パターンへの対策
# -----------------------------------------------------------------------------
# 【この処理の位置づけ — 主たる解決策ではない】
#   Windows 11 の スマート アプリ コントロール (SAC) は、ダウンロード由来の印 (MotW) が
#   付いた「未署名の .bat / .ps1」を実行される前に遮断する。SmartScreen と違い
#   「それでも実行」の選択肢が無く、Microsoft は個別アプリの許可手段を提供していない。
#   つまり SAC が発火する主経路では soloptilink-install.bat 自体が起動せず、
#   この PowerShell スクリプトまで到達しない。したがって本処理は保険であり、効くのは:
#     ・2 回目以降の実行 (顧客が文書どおり対処した後の再実行)
#     ・評価モード等で .bat の遮断をすり抜けた場合
#     ・同梱の運用ファイル (バックアップ.cmd / 診断.cmd / 元に戻す.cmd) が
#       後日ダブルクリックされた際に遮断されるのを未然に防ぐ (下の MotW 解除)
#   主たる解決は docs\SETUP_WINDOWS_*.md と docs\TROUBLESHOOT_COMMON.md の文書化、
#   および将来的な Authenticode コード署名の取得である。
#
# 【実機未確認 — 正直な記録】
#   SAC 状態の判定に使うレジストリ値
#     HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy
#       → VerifiedAndReputablePolicyState  (0=オフ / 1=オン(強制) / 2=評価モード)
#   は公開情報に基づく。2026-08-07 時点で、SAC が有効な実機での動作確認は取れていない。
#   このため判定失敗を異常扱いせず、必ず「不明」として処理を続行する
#   (誤判定でインストールを止めないことを最優先とする)。
Write-Step "1.2/11 保護機能の確認 (スマート アプリ コントロール)"

$script:SacState = "unknown"
try {
    $sacVal = Get-ItemPropertyValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy" `
                                    -Name "VerifiedAndReputablePolicyState" -ErrorAction Stop
    switch ([int]$sacVal) {
        0       { $script:SacState = "off";        Write-Ok   "  スマート アプリ コントロール: オフ" }
        1       { $script:SacState = "on";         Write-Warn "  スマート アプリ コントロール: オン (有効)" }
        2       { $script:SacState = "evaluation"; Write-Warn "  スマート アプリ コントロール: 評価モード" }
        default { Write-Host  "  スマート アプリ コントロール: 判定できませんでした (値=$sacVal)" }
    }
} catch {
    # 値が無い = SAC 非対応の Windows (10 等) か参照権限なし。どちらも正常系として扱う。
    Write-Skip "  スマート アプリ コントロール: 該当する設定なし (この PC は対象外と判断)"
}

# ダウンロード由来の印 (MotW) を配布物から取り除く。
# これにより 2 回目以降の .bat 起動と、同梱の運用ファイル (.cmd) のダブルクリック実行が
# SAC / SmartScreen に遮断されなくなる。印が無いファイルには何も起きない (冪等)。
$unblockRoot = Split-Path -Parent $PSScriptRoot
if ([string]::IsNullOrEmpty($unblockRoot) -or -not (Test-Path $unblockRoot)) { $unblockRoot = $PSScriptRoot }
try {
    $unblockExts = @('*.bat', '*.cmd', '*.ps1', '*.psm1', '*.exe', '*.msi', '*.js', '*.vbs', '*.wsf', '*.lnk', '*.reg')
    $unblockHits = 0
    $unblockTargets = @(Get-ChildItem -Path $unblockRoot -Recurse -File -Include $unblockExts -ErrorAction SilentlyContinue)
    foreach ($uf in $unblockTargets) {
        # 1 ファイルの失敗で解除処理全体が止まらないよう、ファイル単位で保護する
        try {
            $zone = Get-Item -LiteralPath $uf.FullName -Stream 'Zone.Identifier' -ErrorAction SilentlyContinue
            if ($zone) {
                Unblock-File -LiteralPath $uf.FullName -ErrorAction SilentlyContinue
                $unblockHits++
            }
        } catch {
            continue
        }
    }
    if ($unblockHits -gt 0) {
        Write-Ok "  ダウンロード由来の印を解除しました: $unblockHits 件 (次回以降の起動と運用ファイルの実行を保護)"
    } else {
        Write-Skip "  ダウンロード由来の印: 対象なし"
    }
} catch {
    Write-Warn "  ダウンロード由来の印の解除をスキップしました (処理は続行します)"
}

if ($script:SacState -eq "on" -or $script:SacState -eq "evaluation") {
    Write-Host ""
    Write-Host "  ---------------------------------------------------------------" -ForegroundColor Yellow
    Write-Host "  この PC ではスマート アプリ コントロールが有効です。" -ForegroundColor Yellow
    Write-Host "  今回のセットアップはこのまま進みます。"
    Write-Host "  今後 soloptilink-install.bat をダブルクリックしても何も起きない場合は、"
    Write-Host "  この保護機能が原因です。対処手順は次の資料に記載しています:"
    Write-Host "    docs\SETUP_WINDOWS.md / docs\TROUBLESHOOT_COMMON.md"
    Write-Host "  ZIP を解凍する前に『プロパティ→全般→許可する』を行う方法が最も安全です。"
    Write-Host "  お困りの際は nomura.y@soloptilink.com までご連絡ください。"
    Write-Host "  ---------------------------------------------------------------" -ForegroundColor Yellow
    Write-Host ""
}

# -----------------------------------------------------------------------------
# STEP 2: インストール先確認
# -----------------------------------------------------------------------------
Write-Step "2/11 インストール先確認: $InstallDir"

if (-not (Test-Path $InstallDir)) {
    Write-Host "  ディレクトリを作成します。"
    New-Item -ItemType Directory -Path $InstallDir | Out-Null
}
Write-Ok "  インストール先 OK"

# -----------------------------------------------------------------------------
# STEP 3: 配布物の検出 (モードA: ZIP展開済みフォルダ / モードB: tar.gz)
# -----------------------------------------------------------------------------
Write-Step "3/11 配布物を検出" `
    '受け取った書庫 (ZIP) をデスクトップなど分かりやすい場所に展開し直してから、このファイルをもう一度実行してください。'

# モードA: このスクリプトの親フォルダ = 解凍済み配布フォルダか?
#   顧客ZIP の構造: SoloptiLinkAI_vX.Y_Windows\installer\soloptilink-install.ps1
#   → 親フォルダに chain.sh + lib\ が居れば配布フォルダと判定
$PkgRoot = Split-Path -Parent $PSScriptRoot
$IsZipMode = $false
if ((Test-Path (Join-Path $PkgRoot "chain.sh")) -and (Test-Path (Join-Path $PkgRoot "lib"))) {
    $IsZipMode = $true
    Write-Ok "  解凍済み配布フォルダを検出: $PkgRoot"
}

# モードB: tar.gz 検索 (ZIPフォルダが見つからない場合のみ)
if (-not $IsZipMode) {
    if (-not $TarballPath) {
        $candidates = @(
            "$InstallDir\soloptilink-update-*.tar.gz",
            "$HOME\Downloads\soloptilink-update-*.tar.gz",
            "$PSScriptRoot\soloptilink-update-*.tar.gz"
        )
        foreach ($pat in $candidates) {
            $found = Get-ChildItem $pat -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
            if ($found) {
                $TarballPath = $found.FullName
                break
            }
        }
    }
    if (-not $TarballPath -or -not (Test-Path $TarballPath)) {
        Write-Err "  配布物が見つかりません。"
        Write-Host ""
        Write-Host "  以下のいずれかをお試しください:"
        Write-Host "   1. ダウンロードした SoloptiLinkAI_v*_Windows.zip を右クリック →「すべて展開」"
        Write-Host "      で解凍し、その中の installer\soloptilink-install.bat を実行する"
        Write-Host "   2. (保守用) soloptilink-update-v*.tar.gz を ~\Downloads に置いて再実行する"
        End-Pause; exit 1
    }
    Write-Ok "  検出 (tar.gz): $TarballPath"
}

# -----------------------------------------------------------------------------
# STEP 4: 既存インストールのバックアップ
# -----------------------------------------------------------------------------
Write-Step "4/11 既存ファイルのバックアップ"

# PFP-119: 認証引継ぎ用にバックアップ先を後続ステップでも参照できるよう初期化
$backupDir = ""

# ZIPモードで既に ~\.soloptilink 内から実行されている場合は配置不要
$SamePlace = $false
if ($IsZipMode) {
    try {
        $a = (Resolve-Path $PkgRoot).Path.TrimEnd('\')
        $b = (Resolve-Path $InstallDir).Path.TrimEnd('\')
        if ($a -ieq $b) { $SamePlace = $true }
    } catch { }
}

if (-not $SkipExtract -and -not $SamePlace) {
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $backupDir = "$InstallDir\.backups\pre-install-$stamp"
    New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

    # PFP-119: 認証系3ファイル (activation.json / .device_identity.json / license.json) も退避対象に含める
    foreach ($item in @("lib", "chain.sh", "VERSION", "VERSION.txt", "activation.json", ".device_identity.json", "license.json")) {
        $src = Join-Path $InstallDir $item
        if (Test-Path $src) {
            Copy-Item $src $backupDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
    Write-Ok "  バックアップ: $backupDir"
} else {
    Write-Warn "  バックアップをスキップ"
}

# -----------------------------------------------------------------------------
# STEP 5: 配布物の配置 (モードA: コピー / モードB: tar.gz 展開)
# -----------------------------------------------------------------------------
Write-Step "5/11 配布物の配置" `
    'ディスクの空き容量をご確認のうえ、このファイルをもう一度実行してください。'

if ($SkipExtract) {
    Write-Warn "  -SkipExtract 指定により配置をスキップ"
} elseif ($IsZipMode) {
    if ($SamePlace) {
        Write-Ok "  既に $InstallDir に展開済みのため配置をスキップ"
    } else {
        # 解凍済みフォルダの中身を丸ごと InstallDir へ上書きコピー
        # robocopy exit code: 0-7 = 成功 (8+ が失敗)
        & robocopy "$PkgRoot" "$InstallDir" /E /NFL /NDL /NJH /NJS /R:2 /W:2 | Out-Null
        $rc = $LASTEXITCODE
        if ($rc -ge 8) {
            Write-DetailToLog ("copy-failure robocopy exit={0}" -f $rc)
            Write-Err "  本体ファイルのコピーに失敗しました"
            Write-Host "  ヒント: Claude Desktop / Claude Code が起動中だと本体ファイルがロックされ" -ForegroundColor Yellow
            Write-Host "         コピーに失敗することがあります。両方を終了してから再実行してください。" -ForegroundColor Yellow
            End-Pause; exit 1
        }
        Write-Ok "  配置完了: $PkgRoot → $InstallDir"
    }
} else {
    # tar (Windows 10 1803+ で標準搭載)
    if (-not (Get-Command tar -ErrorAction SilentlyContinue)) {
        Write-Err "  このパソコンでは本体ファイルを展開できません (Windows 10 1803 以降が必要です)"
        Write-Host "  お手数ですが nomura.y@soloptilink.com へご連絡ください。" -ForegroundColor Yellow
        End-Pause; exit 1
    }
    Push-Location $InstallDir
    try {
        # --strip-components=1 でトップディレクトリ (soloptilink-vX.Y.Z/) を剥がす
        & tar -xzf $TarballPath --strip-components=1
        if ($LASTEXITCODE -ne 0) {
            Write-DetailToLog ("extract-failure exit={0}" -f $LASTEXITCODE)
            Write-Err "  本体ファイルの展開に失敗しました"
            Write-Host "  ダウンロードしたファイルが途中で切れている可能性があります。" -ForegroundColor Yellow
            Write-Host "  もう一度ダウンロードし直してからお試しください。" -ForegroundColor Yellow
            End-Pause; exit 1
        }
        Write-Ok "  展開完了"
    } finally {
        Pop-Location
    }
}

# -----------------------------------------------------------------------------
# 再インストール時の認証引継ぎ (PFP-119 / 2026-06-12)
# 認証系3ファイル (activation.json / .device_identity.json / license.json) は
# 配布物に含まれないため、上書き配置後もそのまま残る設計。万一消えていた場合は
# STEP 4 のバックアップから自動で書き戻し、再インストール後の再認証を不要にする。
# -----------------------------------------------------------------------------
$authFiles = @("activation.json", ".device_identity.json", "license.json")
$authCarried = 0
foreach ($af in $authFiles) {
    $dst = Join-Path $InstallDir $af
    if (-not (Test-Path $dst) -and $backupDir -and (Test-Path (Join-Path $backupDir $af))) {
        Copy-Item (Join-Path $backupDir $af) $dst -Force -ErrorAction SilentlyContinue
    }
    if (Test-Path $dst) { $authCarried++ }
}
if ($authCarried -gt 0) {
    Write-Ok "  認証情報は引き継ぎました (再認証は不要です)"
}

# -----------------------------------------------------------------------------
# STEP 6: CRLF -> LF 正規化 (Windows 標準展開で CRLF が混入することがある)
# -----------------------------------------------------------------------------
Write-Step "6/11 改行コード正規化 (.sh ファイル)"

$shFiles = Get-ChildItem -Path $InstallDir -Filter "*.sh" -Recurse -ErrorAction SilentlyContinue
$fixedCount = 0
foreach ($f in $shFiles) {
    try {
        $bytes = [System.IO.File]::ReadAllBytes($f.FullName)
        if ($bytes -contains 13) {
            $text = [System.IO.File]::ReadAllText($f.FullName)
            $text = $text -replace "`r`n", "`n" -replace "`r", "`n"
            [System.IO.File]::WriteAllText($f.FullName, $text, [System.Text.UTF8Encoding]::new($false))
            $fixedCount++
        }
    } catch {
        # skip
    }
}
Write-Ok "  CRLF 正規化: $fixedCount ファイル修正"

# -----------------------------------------------------------------------------
# STEP 7: WCG-2 lib/ 完整性検証 (林事案の直接ガード)
# -----------------------------------------------------------------------------
Write-Step "7/11 lib/ 完整性検証 (WCG-2)"

$required = @(
    "lib\license-guard.sh",
    "lib\core\layer-loader.sh",
    "chain.sh"
)
$missing = @()
foreach ($r in $required) {
    $p = Join-Path $InstallDir $r
    if (-not (Test-Path $p)) { $missing += $r }
}

if ($missing.Count -gt 0) {
    Write-Err "  必須ファイルが不足しています:"
    foreach ($m in $missing) { Write-Host "     - $m" -ForegroundColor Red }
    Write-Host ""
    Write-Host "  配布物が破損している可能性があります。nomura.y@soloptilink.com にお問い合わせください。"
    End-Pause; exit 1
}
Write-Ok "  lib/license-guard.sh, lib/core/layer-loader.sh, chain.sh すべて存在"

# -----------------------------------------------------------------------------
# STEP 8: Goランチャー検出 + 端末認証 (アクティベーション)
# -----------------------------------------------------------------------------
Write-Step "8/11 Goランチャー検出 + 端末認証" `
    'ネットワークの接続をご確認のうえ、このファイルをもう一度実行してください。二重にご登録されることはありません。'

$launcher = $null
$candidates = @("soloptilink.exe", "soloptilink-windows-amd64.exe", "soloptilink-windows-arm64.exe")
foreach ($c in $candidates) {
    $p = Join-Path $InstallDir $c
    if (Test-Path $p) { $launcher = $p; break }
}

$activated = $false
# 復旧案内は実検出したランチャー名で示す (soloptilink.exe 固定だと、アーキ名 exe のみの
# 環境で案内どおり実行しても CommandNotFound になり自力復旧できない — 2026-07-13 敵対検証)
$script:LauncherLeaf = 'soloptilink.exe'
if (-not $launcher) {
    Write-Warn "  soloptilink.exe が見つかりません。"
    Write-Host "  nomura.y@soloptilink.com に Windows 用ランチャーをご請求ください。"
} else {
    Write-Ok "  検出: $launcher"
    $script:LauncherLeaf = Split-Path $launcher -Leaf

    if ($Verify) {
        Write-Host ""
        Write-Step "認証ステータス確認"
        # ネイティブコマンドの stderr が Stop で例外化する PS 5.1 の罠を避ける
        # (自動更新直後の初回 --status やオフライン時の警告が stderr に出ると
        #  NativeCommandError へ昇格し最上位 trap に捕捉されてしまう)
        $prevEAP = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        try { & $launcher --status 2>&1 | Out-Host } catch { }
        $ErrorActionPreference = $prevEAP
    }

    # 端末認証 (登録済みなら自動スキップ / -NoActivate で抑止)
    if (-not $NoActivate) {
        # ★登録済みかどうかは端末に残る登録の記録で判断する (2026-08-17 / Mac 側と同一基準)
        #   従来はサーバへの問い合わせ結果の文言 ("承認済み") だけを見ていた。
        #   これだと接続が不調なときや、承認待ちの端末で毎回入力を求めることになる。
        #   逆に、引き継げたファイルの数を根拠にすると (Mac 側で起きた事故)、
        #   登録の成否によらず作られる端末の指紋まで「登録済みの証拠」に数えてしまい、
        #   一度失敗した端末が二度と登録できなくなる。
        #   登録が済んだと言えるのは activation.json と license.json がそろい、
        #   license.json の状態が有効なときだけ。診断 (self-check) と同じ基準に揃える。
        $alreadyRegistered = $false
        $actPath = Join-Path $InstallDir 'activation.json'
        $licPath = Join-Path $InstallDir 'license.json'
        if ((Test-Path $actPath) -and (Test-Path $licPath)) {
            try {
                $licObj = Get-Content -Path $licPath -Raw -Encoding UTF8 | ConvertFrom-Json
                if (@('approved','pending','waiting') -contains [string]$licObj.status) {
                    $alreadyRegistered = $true
                }
            } catch { $alreadyRegistered = $false }
        }
        if ($alreadyRegistered) {
            Write-Ok "  この端末はすでに登録済みです (入力は不要です)。"
            $activated = $true
        } else {
            Write-Host ""
            Write-Host "  ── この端末のご登録 ──"
            Write-Host ""
            Write-Host "  このあと、メールアドレスとパスワードの入力をお願いします。"
            Write-Host "  当社からお送りしたご案内メールをお手元にご用意ください。"
            Write-Host ""
            # ★パスワードが画面に出ないことを、入力前に必ずお伝えする (2026-08-17)
            #   安全のためパスワードは一文字も表示されない。その説明が無いと
            #   「入力を受け付けていない」と受け取られ、そのまま中断されてしまう。
            Write-Host "  ※ パスワードは、安全のため入力しても画面には表示されません。"
            Write-Host "     これは正常な動作です。そのまま最後まで入力してください。"
            Write-Host ""
            try {
                # 2026-07-13 敵対検証で確証: 承認待ちポーリング (最大30分) をインストーラ内で
                # 同期実行すると、ランチャー自身が案内する Ctrl+C がコンソール全体に配送されて
                # 本インストーラごと停止し、後続工程 (MCP登録/自動更新フック/前提ソフト) が
                # 全滅する。登録だけ行い、承認待ちはスキップして次の工程へ進む。
                $env:SOLOPTILINK_ACTIVATE_NO_WAIT = '1'
                & $launcher --activate
                # 2026-07-13 敵対検証で確証: ネイティブ exe の非0終了は EAP=Continue では
                # catch に入らないため、終了コードで成否を二分する (認証失敗の偽成功防止)。
                if ($LASTEXITCODE -eq 0) {
                    $activated = $true
                } else {
                    # ★2026-08-10 是正: 終了コードと打ち込むコマンドを画面に出していたが、
                    #   お客様には実行できない案内だった。もう一度ダブルクリックすれば
                    #   同じ登録がやり直せるので、それだけを日本語で案内する。
                    #   終了コードは控えのログにだけ残す。
                    try {
                        if ($script:LogPath) {
                            Add-Content -Path $script:LogPath -Encoding UTF8 `
                                -Value ("activation-failure exit={0}" -f $LASTEXITCODE)
                        }
                    } catch { }
                    Write-Warn "  ご登録が完了しませんでした"
                    Write-Host "    インターネットの接続をご確認のうえ、このファイルをもう一度実行してください。"
                    Write-Host "    同じ手順を繰り返しても、二重に登録されることはありません。"
                    Write-Host "    解消しない場合は、この画面の写真を nomura.y@soloptilink.com へお送りください。"
                }
            } catch {
                Write-Warn "  ご登録が完了しませんでした"
                Write-Host "    インターネットの接続をご確認のうえ、このファイルをもう一度実行してください。"
                Write-Host "    同じ手順を繰り返しても、二重に登録されることはありません。"
                Write-Host "    解消しない場合は、この画面の写真を nomura.y@soloptilink.com へお送りください。"
            } finally {
                Remove-Item Env:SOLOPTILINK_ACTIVATE_NO_WAIT -ErrorAction SilentlyContinue
            }
        }
        $ErrorActionPreference = $prevEAP
    }
}

# -----------------------------------------------------------------------------
# STEP 9: Claude Desktop MCP 自動登録 (PFP-119 / 2026-06-12)
# %APPDATA%\Claude\claude_desktop_config.json へ soloptilink MCP サーバーを
# マージ登録する (ConvertFrom-Json/ConvertTo-Json で既存の mcpServers 設定は保持)。
# 登録に失敗してもセットアップ全体は続行する (後から手動登録可能)。
# -----------------------------------------------------------------------------
Write-Step "9/11 Claude Desktop との連携を登録" `
    'Claude Desktop を終了した状態で、このファイルをもう一度実行してください。'

if (-not $launcher) {
    Write-Warn "  本体の準備が整っていないため、Claude Desktop との連携登録を行えませんでした。"
    Write-Host "  このファイルをもう一度実行してください。解消しない場合は nomura.y@soloptilink.com へご連絡ください。"
} else {
    try {
        $cfgDir = Join-Path $env:APPDATA "Claude"
        $cfgPath = Join-Path $cfgDir "claude_desktop_config.json"
        if (-not (Test-Path $cfgDir)) {
            New-Item -ItemType Directory -Path $cfgDir -Force | Out-Null
            Write-Warn "  Claude Desktop が未インストールの可能性があります (設定フォルダを新規作成)"
        }

        # 既存設定の読み込み + バックアップ (壊れていても新規作成にフォールバック)
        $mcpStamp = Get-Date -Format "yyyyMMdd-HHmmss"
        $cfg = $null
        if (Test-Path $cfgPath) {
            Copy-Item $cfgPath "$cfgPath.bak.$mcpStamp" -Force -ErrorAction SilentlyContinue
            try { $cfg = Get-Content $cfgPath -Raw | ConvertFrom-Json } catch { $cfg = $null }
        }
        if ($null -eq $cfg) { $cfg = [PSCustomObject]@{} }

        # mcpServers プロパティが無い/null なら作成 (既存エントリは保持)
        if (-not ($cfg.PSObject.Properties.Name -contains "mcpServers")) {
            $cfg | Add-Member -MemberType NoteProperty -Name "mcpServers" -Value ([PSCustomObject]@{})
        }
        if ($null -eq $cfg.mcpServers) { $cfg.mcpServers = [PSCustomObject]@{} }

        # soloptilink エントリを登録 (既存なら上書き)
        $entry = [PSCustomObject]@{
            command = $launcher.Replace("\", "/")
            args    = @("--mcp-server")
        }
        if ($cfg.mcpServers.PSObject.Properties.Name -contains "soloptilink") {
            $cfg.mcpServers.soloptilink = $entry
        } else {
            $cfg.mcpServers | Add-Member -MemberType NoteProperty -Name "soloptilink" -Value $entry
        }

        # JSON 書き戻し (UTF-8 BOM なし)
        $json = $cfg | ConvertTo-Json -Depth 20
        [System.IO.File]::WriteAllText($cfgPath, $json, [System.Text.UTF8Encoding]::new($false))
        Write-Ok "  Claude Desktop との連携を登録しました"
        Write-Host "  (反映には Claude Desktop の完全終了 → 再起動が必要です)"
    } catch {
        Write-DetailToLog ("mcp-register-failure message={0}" -f $_.Exception.Message)
        Write-Warn "  Claude Desktop への登録を完了できませんでした (要対応一覧にまとめます)"
        Write-Host "  後で installer\install-claude-desktop-mcp.ps1 を実行してください。"
    }
}

# -----------------------------------------------------------------------------
# STEP 10: Claude Code 自動更新フックの登録 (Windows 導入時に更新が届かない状態を防ぐ)
# -----------------------------------------------------------------------------
# 【鶏卵デッドロックの解消 + Windows bash 非依存化】
# 従来 Windows では「自動更新フックを誰も登録しない」かつ「フック本体が bash 依存で
# 起動できない」ため、自動更新が一度も走らなかった。ここで導入時点で、ランチャー
# (.exe) 経由のフック (`"<exe>" --hook-autoupdate`) を ~/.claude/settings.json へ
# 冪等登録する。JSON マージは Go 実装に委譲し、PowerShell の配列直列化事故を避ける。
Write-Step "10/11 自動更新を有効化 (Claude Code フック登録)"

if (-not $launcher) {
    Write-Warn "  本体の準備が整っていないため、自動更新の設定を行えませんでした。"
    Write-Host "  最新版にしたいときは、チャット欄に「最新版にして」とお伝えください。"
} else {
    $prevEAP2 = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $hookOut = ""
    try { $hookOut = (& $launcher --register-autoupdate-hook 2>&1 | Out-String) } catch { }
    $ErrorActionPreference = $prevEAP2
    # 2026-07-13 敵対検証で確証: 旧判定 (-match "登録") は失敗メッセージ
    # 「自動更新フックの登録に失敗」にもマッチして偽成功になる。成功文言に限定する。
    if ($hookOut -match "登録しました|既に登録済み") {
        Write-Ok "  自動更新フックを登録しました (以降 Claude Code 起動時に最新版を自動取得)"
    } else {
        # ★2026-08-10 是正: 打ち込むコマンドではなく、チャットからできる案内に変える
        Write-Warn "  自動更新の登録結果を確認できませんでした。"
        Write-Host "  最新版にしたいときは、チャット欄に「最新版にして」とお伝えください。"
    }
}

# -----------------------------------------------------------------------------
# STEP 10.5: 品質・信頼性フックの登録 (2026-08-01 実測監査 指摘1 の恒久対策)
# -----------------------------------------------------------------------------
# 【何が壊れていたか】Windows 導入経路では migration/ を一度も実行していなかった。
#   そのため v2027 (自動更新) 以降に追加された遡及配線 — 品質ゲートや
#   エラーゼロ化4本柱の結線層 (lib/hooks/reliability-lifecycle-hook.sh の7エントリ) — が
#   Windows 端末には一切入らなかった。macOS 側 (.command) と同様に、
#   migration/ 配下を列挙せず全実行する (各スクリプトが自前で冪等)。
#   bash が見つからない環境では黙って諦めず、後で自動更新経路が拾えるよう案内だけ出す
#   (Git for Windows は STEP 11 で導入されるため、次回起動時に適用される)。
Write-Step "10.5/11 品質・信頼性フックを登録"
$migBash = $null
$bashCmd = Get-Command bash -ErrorAction SilentlyContinue
if ($bashCmd) { $migBash = $bashCmd.Source }
if (-not $migBash) {
    foreach ($cand in @("$env:ProgramFiles\Git\bin\bash.exe", "${env:ProgramFiles(x86)}\Git\bin\bash.exe", "$env:LOCALAPPDATA\Programs\Git\bin\bash.exe")) {
        if ($cand -and (Test-Path $cand)) { $migBash = $cand; break }
    }
}
# 【P3 是正 (第2波) 2026-08-17】設定用スクリプトの置き場所は 2 か所ある
# ------------------------------------------------------------
# 何が起きていたか:
#   設定用スクリプトは migration\ と lib\migration\ の 2 か所に分かれて同梱されて
#   いるが、Windows 導入経路は前者しか走査していなかった。そのため Windows の
#   お客様は「本番モードの封緘」と「常駐チェック機能の登録」の 2 件が一度も
#   適用されない。入口 (Mac / Windows / Linux) の 3 つで端末の状態が食い違う。
# どう直したか:
#   両方の置き場所を走査する。走査条件は 3 つの入口で v*.sh に統一する
#   (自己実証用のテストスクリプトを「設定」として実行・計上しないため)。
#   適用できた件数と適用できなかった件数を両方とも表示し、成功したことにしない。
if (-not $migBash) {
    Write-Warn "  この時点では実行環境が揃っていないため、次回 Claude Code 起動時に自動で有効化します。"
} else {
    $migCount = 0
    $migNg = 0
    # >>> SOLOPTILINK-MIGRATION-SCAN-BEGIN
    #   ★ここから END までが「設定用スクリプトの走査条件」の正体。
    #     3 つの入口 (Mac / Windows / Linux) で同じ条件になっているかを、
    #     常設検査 L233-INSTALL-ENTRY-PARITY がこの区間だけを実際に走らせて確かめる。
    #     区間の外へ条件を書くと、入口ごとの食い違いが再発しても検査に映らない。
    $migDirs = @(
        (Join-Path $env:USERPROFILE ".soloptilink\migration"),
        (Join-Path $env:USERPROFILE ".soloptilink\lib\migration")
    )
    foreach ($migDir in $migDirs) {
        if (-not (Test-Path $migDir)) { continue }
        foreach ($m in (Get-ChildItem -Path $migDir -Filter "v*.sh" -File -ErrorAction SilentlyContinue)) {
            $prevEAP3 = $ErrorActionPreference
            $ErrorActionPreference = 'Continue'
            $migRc = 1
            try { & $migBash $m.FullName 2>&1 | Out-Null; $migRc = $LASTEXITCODE } catch { $migRc = 1 }
            $ErrorActionPreference = $prevEAP3
            if ($migRc -eq 0) { $migCount++ } else { $migNg++ }
        }
    }
    # <<< SOLOPTILINK-MIGRATION-SCAN-END
    if (($migCount + $migNg) -eq 0) {
        Write-Host "  追加で有効化する項目はありませんでした。" -ForegroundColor DarkGray
    } else {
        Write-Ok "  品質・信頼性の自動チェックを有効化しました ($migCount 項目)"
        if ($migNg -gt 0) {
            Write-Warn "  $migNg 件は適用できませんでした (ご利用は始められます)。"
            Write-Host "     次にしていただくこと: このセットアップをもう一度実行してください。それでも同じ表示が続く場合は、この画面を添えて nomura.y@soloptilink.com までご連絡ください。" -ForegroundColor DarkGray
        }
    }
}

# -----------------------------------------------------------------------------
# STEP 11: 前提ソフト (Git / Node.js / Claude Code) の確認と導入 — 必ず最後に実行する
#   【順序の設計意図 — この順でないと導入が途中で止まる】
#   旧実装はこの前提ソフト導入を本体配置より前 (STEP 1.5) に実行しており、
#   winget が固まる・ウィンドウが閉じられる等で死ぬと SoloptiLink 本体が
#   1 ファイルも配置されないまま導入失敗になっていた (実事案: Git 導入中に
#   トランスクリプトが途絶し ~/.soloptilink が空のまま)。
#   本体配置・端末認証・MCP 登録・自動更新フックはいずれも Git/Node に依存
#   しないため、先に本体導入を完遂し、前提ソフトは最後に看視付きで導入する。
#   各ソフトは「先に検出し、在ればスキップ」する冪等設計 (再実行しても無害)。
#     - Git for Windows : SoloptiLink の bash 製 lib / chain.sh の動作に必要
#     - Node.js (LTS)   : 生成される業務システムの実行・ビルド検証に必要 (Claude Code 自体は Node 不要)
#     - Claude Code     : 公式ネイティブインストーラで導入 (背景で自動更新)
#   途中で失敗しても終了せず、最後に「要対応一覧」へ集約する。
# -----------------------------------------------------------------------------
Write-Step "11/11 前提ソフト (Git / Node.js / Claude Code) を確認・導入" `
    'SoloptiLinkAI 本体の導入はすでに終わっています。画面に出ている【要対応】を解消してから、このファイルをもう一度実行してください。'
Write-Host "  ※ SoloptiLinkAI 本体の導入・端末認証はすでに完了しています。" -ForegroundColor DarkGray
Write-Host "  ※ ここから先は補助ソフトの導入です。数分かかることがありますが、" -ForegroundColor DarkGray
Write-Host "     このウィンドウを閉じずにお待ちください (各ソフト最大10分で自動的に次へ進みます)。" -ForegroundColor DarkGray

# winget (アプリ インストーラー) の有無 = 前提ソフト導入の主手段
$script:HasWinget = Test-CommandExists 'winget'
if ($script:HasWinget) { Write-Ok "  winget (アプリ インストーラー) 検出" }
else { Write-Warn "  winget が見つかりません。前提ソフトの自動導入が制限されます (要対応に集約します)。" }

# 管理者権限の状況を通知 (昇格は強制しない = UAC 摩擦を最小化)。ソフト導入時に winget/MSI が
# 個別に昇格を求めることがあるため、その際の操作を事前に案内する。
try {
    $IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $IsAdmin) {
        Write-Warn "  一般ユーザーで実行中です。ソフト導入時に管理者の許可 (UAC) を求められたら「はい」を選んでください。企業管理 PC では IT 部門の協力が必要な場合があります。"
    }
} catch { }

# 失敗してもセットアップ全体を止めないため、このフェーズ中は継続モードにする
$prereqEAP = $ErrorActionPreference
$ErrorActionPreference = 'Continue'

# --- Git for Windows ---
if (Test-CommandExists 'git') {
    Write-Skip ("Git ({0})" -f (& git --version 2>&1 | Select-Object -First 1))
} else {
    Write-Host "  Git: 未導入 → 導入します"
    Install-ViaWinget 'Git.Git' 'Git for Windows' 'git' 'https://git-scm.com/download/win' | Out-Null
}

# --- Node.js (LTS / v18 以上) ---
$needNode = $true
if (Test-CommandExists 'node') {
    $nodeVer = (& node -v 2>&1 | Select-Object -First 1)
    $nodeMajor = 0
    if ($nodeVer -match '^v(\d+)\.') { $nodeMajor = [int]$matches[1] }
    if ($nodeMajor -ge 18) {
        Write-Skip ("Node.js ({0})" -f $nodeVer)
        $needNode = $false
    } else {
        Write-Warn ("  Node.js ({0}) は古いため最新 LTS へ更新します (必要: v18 以上)" -f $nodeVer)
    }
} else {
    Write-Host "  Node.js: 未導入 → 導入します"
}
if ($needNode) {
    # ② winget 経路 (既存)。ここは二重実装しない = 判定順4の②はこの1行だけが担当する。
    Install-ViaWinget 'OpenJS.NodeJS.LTS' 'Node.js (LTS)' 'node' 'https://nodejs.org/en/download' | Out-Null

    # ③ winget 不在 / winget 失敗 → 公式 zip をユーザー領域へ展開 (T-017b / 2026-08-10)
    #   【何が壊れていたか】ここは winget の 1 行だけで、同梱している
    #     installer\lib\node-provision.ps1 (Invoke-NodeProvision) を一度も呼んでいなかった。
    #     モジュール冒頭には「あるべき結線 3 行」が使用例として書かれているのに、その 3 行が
    #     本体のどこにも存在しない状態 = 呼出元ゼロの死配線だった。
    #     winget はストアが使えない企業管理 PC・ソース無効化ポリシー・プロキシ遮断で普通に失敗する。
    #     その先に受け皿が無いと、顧客は公式インストーラの管理者権限入力へ誘導されて手が止まる。
    #   【契約】管理者権限 (UAC) を要求しない。展開先は %USERPROFILE%\.soloptilink\runtime\node。
    #     失敗しても導入全体は止めず、要対応一覧へ集約する。
    if (-not (Test-CommandExists 'node')) {
        $npModule = Join-Path $PSScriptRoot 'lib\node-provision.ps1'
        if (Test-Path $npModule) {
            Write-Host '  Node.js: 公式の配布物から用意します (管理者権限の確認画面は出ません)'
            try {
                . $npModule
                $npResult = Invoke-NodeProvision -Mode ensure
                Save-NodeProvisionResult -Result $npResult
                # 当社の起動経路にのみ PATH を前置き (ユーザーの環境変数は変更しない)
                if ($npResult.env_file -and (Test-Path $npResult.env_file)) {
                    . $npResult.env_file
                }
                if ($npResult.verdict -eq 'PASS') {
                    Write-Ok ('  Node.js 導入完了 (' + $npResult.node_version + ')')
                    # winget 経路が積んだ「Node.js (LTS)」の要対応は解消済みなので取り下げる
                    # (直っている項目を要対応に残すと、顧客が不要な作業をしてしまう)
                    $script:Issues = @($script:Issues | Where-Object { $_.Item -ne 'Node.js (LTS)' })
                } else {
                    Write-Warn '  Node.js を自動で用意できませんでした (要対応一覧に集約します)'
                    Add-Issue 'Node.js' $npResult.reason $npResult.issue_ja
                }
            } catch {
                Write-DetailToLog ("node-provision-failure message={0}" -f $_.Exception.Message)
                Write-Err "  Node.js の自動導入を完了できませんでした"
                Add-Issue 'Node.js' '自動導入の途中で想定外の問題が発生しました' 'https://nodejs.org/ja から LTS 版を導入したうえで、このセットアップをもう一度実行してください。解消しない場合は nomura.y@soloptilink.com へご連絡ください。'
            }
        } else {
            Write-Warn '  Node.js: 自動導入に必要な部品が見つかりません'
            Add-Issue 'Node.js' '自動導入に必要な部品が配布物の中に見当たりません' 'ZIP をもう一度展開し直してからセットアップを実行してください。解消しない場合は nomura.y@soloptilink.com へご連絡ください。'
        }
    }
}

# --- Claude Code (公式ネイティブインストーラ = 背景で自動更新) ---
if (Test-CommandExists 'claude') {
    Write-Skip ("Claude Code ({0})" -f (& claude --version 2>&1 | Select-Object -First 1))
} else {
    Write-Host "  Claude Code: 未導入 → 導入します (公式ネイティブインストーラ / 自動更新あり)"
    # iex が exit を呼んでも本インストーラを巻き込まないよう、子 PowerShell で実行する。
    # ハング対策: 看視付き (Invoke-WithTimeout)。固まっても最大10分で次へ進む。
    # 注: PS 5.1 の Start-Process は配列引数を引用符なしで空白結合するため、
    #     空白を含む -Command は単一文字列で渡す (二重引用符を明示)。
    $claudeCode = Invoke-WithTimeout 'powershell' '-NoProfile -ExecutionPolicy Bypass -Command "irm https://claude.ai/install.ps1 | iex"' 600 'Claude Code (公式インストーラ)'
    if ($null -eq $claudeCode) { $claudeCode = -1 }
    Update-SessionPath
    # ネイティブで入らなければ winget 版へフォールバック (自動更新は環境変数で補う)
    if (-not (Test-CommandExists 'claude') -and $script:HasWinget) {
        Write-Warn "  winget 経由での導入に切り替えます"
        try {
            [Environment]::SetEnvironmentVariable('CLAUDE_CODE_PACKAGE_MANAGER_AUTO_UPDATE', '1', 'User')
            $claudeCode = Invoke-WithTimeout 'winget' @('install','--id','Anthropic.ClaudeCode','-e','--source','winget','--accept-source-agreements','--accept-package-agreements','--silent') 600 'Claude Code (winget)'
            if ($null -eq $claudeCode) { $claudeCode = -1 }
        } catch {
            Write-DetailToLog ("winget-install-failure message={0}" -f $_.Exception.Message)
            Write-Err "  別の方法でも導入を完了できませんでした"
            $claudeCode = -1
        }
        Update-SessionPath
    }
    if (Test-CommandExists 'claude') {
        Write-Ok "  Claude Code 導入完了"
    } elseif ($claudeCode -eq 0 -or $claudeCode -eq -1978335189) {
        # 導入は成功した形跡 → PATH 未反映 (公式インストーラがレジストリ PATH を更新しない既知事象 #21365 を含む。再起動で直る)
        Write-Warn "  Claude Code を導入しましたが、このセッションでは確認できませんでした (PC 再起動後に反映)"
        # ★2026-08-10 是正: 「新しいウィンドウで claude --version を実行」は
        #   打ち込む場所の説明が無く行き止まりだった。画面操作だけの確認方法に変える。
        Add-Issue 'Claude Code' '導入は成功しましたが、反映に PC の再起動が必要な可能性があります' 'PC を再起動したあと、このファイルをもう一度実行してください。それでも変わらない場合は、この画面の写真を nomura.y@soloptilink.com へお送りください。'
    } else {
        # 導入そのものが失敗 → ネットワーク / プロキシ / SmartScreen / オフライン
        Write-DetailToLog ("claude-install-exit code={0}" -f $claudeCode)
        Write-Err "  Claude Code の自動導入に失敗しました"
        Add-Issue 'Claude Code' "自動導入に失敗しました。配信元への接続不可 (社内のネットワーク制限)、Windows の実行ブロック、またはインターネットに繋がっていないことが考えられます" 'ネットワーク管理者に claude.ai および Anthropic 配信ドメインの許可を依頼してください。SmartScreen の警告画面でブロックされた場合は「詳細情報」→「実行」を選択するか、IT 部門に実行許可を依頼してください。オフライン環境では、別のオンライン端末で導入した Claude Code を持ち込むか、サポートへご連絡ください。'
    }
}

# --- Python 3 (T-702 / 2026-08-10 新設) ---
#   【なぜ足したか / 実測】生成物の品質点検は 138 本中 107 本が python3 を呼ぶ。
#     つまり導入の前提なのに、お客様向けの手順書 7 本すべてに記載が 0 件で、
#     前提ソフトの確認対象にも入っていなかった (実測 2026-08-10)。
#     python3 が無いまま点検を走らせると、判定が全て「-」になり合否を出せなくなることを
#     実走で確認した (Mac ではさらに設定登録の段階で導入が止まる)。
#   【方針】自動導入はしない。Windows の Python は Microsoft Store 経由が主で、
#     無人導入は同意画面とストアのサインインを伴い、途中で止まる危険が高い。
#     ここでは検出だけ行い、無い場合は導入の案内を「要対応」へ集約する。
#   ★Windows には python3.exe という「ストアへ誘導するだけの入口」が既定で置かれている。
#     コマンドがあることだけを見ると入っている扱いになるため、版の表示まで確かめる。
$pyOk = $false
if (Test-CommandExists 'python3') {
    try {
        $pyVer = (& python3 --version 2>&1 | Select-Object -First 1)
        if ("$pyVer" -match 'Python\s+3\.') { $pyOk = $true }
    } catch { $pyOk = $false }
}
if ($pyOk) {
    Write-Ok "  Python 3 は導入済みです ($pyVer)"
} else {
    Write-Warn "  Python 3 が確認できません (品質点検の判定が行えません)"
    Add-Issue 'Python 3' '生成した業務システムの品質点検に Python 3 が必要ですが、この PC では確認できませんでした' 'Microsoft Store で「Python 3」を検索して導入してください。社内ポリシーで Store が使えない場合は https://www.python.org/downloads/windows/ から導入し、導入時に「Add python.exe to PATH」にチェックを入れてください。'
}

$ErrorActionPreference = $prereqEAP

# -----------------------------------------------------------------------------
# 動作確認 (各前提ソフトのバージョンを実測表示)
# -----------------------------------------------------------------------------
Write-Step "動作確認 (バージョン表示)"
$verEAP = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
function Show-Ver($label, $cmd, $verArg) {
    if (Test-CommandExists $cmd) {
        $out = (& $cmd $verArg 2>&1 | Select-Object -First 1)
        Write-Host ("  [ OK ] {0,-12}: {1}" -f $label, $out) -ForegroundColor Green
    } else {
        Write-Host ("  [FAIL] {0,-12}: 確認できません (PC 再起動後に再確認してください)" -f $label) -ForegroundColor Red
    }
}
Show-Ver 'Git'         'git'    '--version'
Show-Ver 'Node.js'     'node'   '-v'
Show-Ver 'npm'         'npm'    '-v'
Show-Ver 'Claude Code' 'claude' '--version'
Show-Ver 'Python 3'    'python3' '--version'
$ErrorActionPreference = $verEAP

# -----------------------------------------------------------------------------
# 導入自己診断 (AC-I08) — 「最後まで走った」ではなく「診断が通った」を完了とする
# -----------------------------------------------------------------------------
# 【何が壊れていたか (T-017e / 2026-08-10)】installer\self-check.sh は 12 項目の自己診断を
#   実装し配布物にも同梱されているのに、Mac/Windows どちらのインストーラからも
#   呼ばれていなかった (呼出元は社内テストの台帳行と同梱必須リストだけ)。
# 【Windows 固有の限界 = 正直に「未測定」と出す】診断本体は bash と python3 に依存する。
#   Git for Windows の bash があれば実行できるが、python3 が無い PC では診断そのものが
#   実行できない。その場合は「合格」でも「不合格」でもなく【未測定】として表示し、
#   お客様に不要な作業を求めない (未測定を合格として数えない・偽の要対応を作らない)。
# 【契約】fail-open。診断の結果がどうであれ、ここで導入を中断しない。
#   無効化: SOLOPTILINK_SELF_CHECK=off
$selfCheckSh = Join-Path $PSScriptRoot 'self-check.sh'
if (Test-Path $selfCheckSh) {
    Write-Step '導入の自己診断'
    $bashExe = $null
    if (Test-CommandExists 'bash') {
        $bashExe = 'bash'
    } else {
        foreach ($cand in @("$env:ProgramFiles\Git\bin\bash.exe", "${env:ProgramFiles(x86)}\Git\bin\bash.exe", "$env:LOCALAPPDATA\Programs\Git\bin\bash.exe")) {
            if ($cand -and (Test-Path $cand)) { $bashExe = $cand; break }
        }
    }
    if ($null -eq $bashExe) {
        Write-Host '  [未測定] 自己診断を実行できる環境がこの PC にありません (診断は未実施です。合格という意味ではありません)'
    } else {
        $scEAP = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        $scRc = Invoke-WithTimeout $bashExe @($selfCheckSh, 'run') 300 '導入の自己診断'
        $ErrorActionPreference = $scEAP
        if ($null -eq $scRc) { $scRc = -1 }
        if ($scRc -eq 0) {
            Write-Ok '  自己診断は問題なく完了しました'
        } elseif ($scRc -eq 1) {
            Write-Warn '  自己診断で確認が必要な項目が見つかりました'
            Add-Issue '導入の自己診断' '診断で確認が必要な項目が見つかりました' '上の診断結果に表示された「お客様がすること」を実施してから、セットアップをもう一度実行してください。'
        } else {
            Write-Host '  [未測定] 自己診断を最後まで実行できませんでした (診断は未実施です。合格という意味ではありません)'
        }
    }
} else {
    Write-Warn '  自己診断に必要な部品が見つかりません'
    Add-Issue '導入の自己診断' '自己診断に必要な部品が配布物の中に見当たりません' 'ZIP をもう一度展開し直してからセットアップを実行してください。解消しない場合は nomura.y@soloptilink.com へご連絡ください。'
}

# -----------------------------------------------------------------------------
# Finish
# -----------------------------------------------------------------------------
Write-Host ""
Write-Host "================================================================="
# ★2026-08-15 是正: ここは要対応が残っていても必ず「セットアップ完了」と出していた。
#   「完了」は、この先の作業を安心して始めてよいという合図である。直っていないものが
#   残ったまま同じ合図を出すと、お客様は直ったものと受け取って使い始めてしまう。
#   1 件でも要対応があるなら、完了とは名乗らない。
if ($script:Issues.Count -gt 0) {
    Write-Host " セットアップは一部が未完了です" -ForegroundColor Yellow
} else {
    Write-Host " セットアップ完了" -ForegroundColor Green
}
Write-Host "================================================================="
Write-Host ""
# 要対応一覧 (前提ソフトで自動完了できなかったもの)
if ($script:Issues.Count -gt 0) {
    Write-Host (" 【要対応】以下は自動で完了できませんでした ({0} 件):" -f $script:Issues.Count) -ForegroundColor Yellow
    $idx = 1
    foreach ($iss in $script:Issues) {
        Write-Host ("   {0}. {1}" -f $idx, $iss.Item) -ForegroundColor Yellow
        Write-Host ("      原因 : {0}" -f $iss.Detail)
        Write-Host ("      対処 : {0}" -f $iss.Remedy)
        $idx++
    }
    Write-Host "   ※ まず上記の【要対応】を解消してから、下の「次のステップ」へお進みください。" -ForegroundColor Yellow
    Write-Host ""
}

Write-Host " 次のステップ:"
Write-Host ""
# ★2026-08-10 是正: 従来は端末登録のやり直しに打ち込むコマンドを 2 行そのまま出し、
#   ログインも「新しいウィンドウで claude と入力」とだけ書いていた。
#   どちらも打ち込む場所の説明がなく、お使いになる方はそこで止まる。
#   画面の操作だけで完結する道順に書き換える。
if (-not $activated) {
    Write-Host "   1. ご登録がまだ完了していません。"
    Write-Host "      このファイルをもう一度実行してください (二重に登録されることはありません)。"
    Write-Host ""
    Write-Host "   2. 弊社での確認が必要な場合は、終わりしだいメールでご連絡します"
    Write-Host ""
    Write-Host "   3. Claude Desktop を起動し、画面の案内にしたがってログインしてください"
    Write-Host "      ※ ご利用には有料の Claude プラン (Pro / Max / Team / Enterprise) または" -ForegroundColor DarkYellow
    Write-Host "        API のご契約が必要です。無料プランでは Claude Code は使えません。" -ForegroundColor DarkYellow
    Write-Host ""
    Write-Host "   4. チャット欄に /soloptilink-boost と入力し、続けてお仕事の内容をお伝えください"
} else {
    Write-Host "   1. 弊社での確認が必要な場合は、終わりしだいメールでご連絡します"
    Write-Host ""
    Write-Host "   2. Claude Desktop を起動し、画面の案内にしたがってログインしてください"
    Write-Host "      ※ ご利用には有料の Claude プラン (Pro / Max / Team / Enterprise) または" -ForegroundColor DarkYellow
    Write-Host "        API のご契約が必要です。無料プランでは Claude Code は使えません。" -ForegroundColor DarkYellow
    Write-Host ""
    Write-Host "   3. チャット欄に /soloptilink-boost と入力し、続けてお仕事の内容をお伝えください"
}
Write-Host ""
# ★例示とご利用開始の案内は正典 (lib/onboarding-canon.sh) から取り出して表示する
#   (T-703 / T-706 / 2026-08-10)。ここに文面を書き写すと、手順書・同梱案内・
#   ランチャーの案内と必ずどこか 1 箇所だけが古くなる。実測でも、手順書 3 本は
#   「最大で1〜2営業日」、Mac の完了画面は「通常1営業日以内」と食い違っていた。
$obcPath = Join-Path $InstallDir 'lib\onboarding-canon.sh'
$obcBash = Get-Command bash -ErrorAction SilentlyContinue
if ((Test-Path $obcPath) -and $obcBash) {
    foreach ($what in @('starter', 'wait')) {
        try {
            $block = & $obcBash.Source "$obcPath" emit $what 2>$null
            if ($block) { $block | ForEach-Object { Write-Host ("   " + $_) } ; Write-Host "" }
        } catch { }
    }
} else {
    Write-Host "   最初の一言の例と、ご利用開始のタイミングは、同梱の手順書をご覧ください。"
    Write-Host ""
}
Write-Host "   すでに前提ソフトを導入済みの方は、導入工程は自動でスキップされています (再実行しても無害)。" -ForegroundColor DarkGray
if ($script:LogPath) { Write-Host ("   実行ログ: {0}" -f $script:LogPath) -ForegroundColor DarkGray }
Write-Host ""

try { Stop-Transcript | Out-Null } catch { }
End-Pause
exit 0
