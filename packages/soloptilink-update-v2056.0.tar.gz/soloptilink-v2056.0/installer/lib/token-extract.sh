#!/usr/bin/env bash
# =============================================================================
# token-extract.sh — 導入ワンタイムトークンの寛容抽出部品
#   基本設計書 04「導入オートパイロット」 §4.2 / §4.3 / §11.1 準拠
#   レーン: 本体側 (installer)。サーバ側 (発行・検証) は別レーン。
# =============================================================================
# 役割:
#   顧客が受け取った ZIP のファイル名
#     例) SoloptiLinkAI_v2056_Mac__act-<26字>.zip
#   および、その展開フォルダ名から導入トークンを取り出す。
#   これが成立すると顧客の手入力は 0 回になる。読めない場合は「静かに空を返す」
#   ことで、上位のフォールバック連鎖(ペアリングコード → メール/パスワード)へ
#   自動的に道を譲る。
#
# 契約 (呼び出し側はこれに依存してよい):
#   1. 公開関数はすべて **常に終了コード 0** を返す。set -e で走るインストーラに
#      source されても、抽出失敗でセットアップを止めない。
#   2. 抽出できたときだけ標準出力へトークンを出す(改行なし)。
#      抽出できないときは **何も出さない**。空文字列 = 未検出。
#   3. 標準出力にはトークン以外を絶対に出さない。診断は SOLOPTILINK_TOKEN_DEBUG=1
#      のときの stderr のみ(トークンは必ずマスクする)。
#      ※ 変数 SOLOPTILINK_TOKEN_SOURCE は「どこから採れたか」を保持するが、
#        TOKEN=$(token_extract_auto) のようにコマンド置換で呼ぶと副シェルで
#        設定されるため呼び出し元へは伝播しない。経路の確認は DEBUG=1 で行うこと。
#   4. 依存は bash 3.2 (macOS 既定) + POSIX コマンドのみ。python3 は必須にしない。
#      (顧客の素の macOS には python3 が入っていないことがあるため)
#
# 寛容パース (§4.3 U3) で吸収する崩れ:
#   - ブラウザの重複ダウンロード装飾   「... (1).zip」「...(2).zip」「...-1.zip」
#   - macOS/Windows の複製装飾         「... のコピー」「... - コピー」「... copy」
#   - 全角化された名前                 「＿＿ａｃｔ－ｘｘｘ」
#   - NFC / NFD の違い                 「のコピー」の NFD 分解形
#   - 部分ダウンロード残骸の拡張子     「.download」「.crdownload」「.part」
#
# 誤検出防止:
#   マーカー直後の英数字の連なりが **ちょうど規定長** のときだけ採用する。
#   長すぎ・短すぎ・マーカー無しはすべて未検出(空)として扱う。
#
# セキュリティ上の注意:
#   トークンは単回使用の資格情報である。ログ・画面へ素で出さないこと。
#   出す必要がある場合は token_mask を通す。set -x のまま呼ばないこと。
# =============================================================================

# 二重 source の抑止 (source されていない実行時は exit 0)
if [ -n "${_SOLOPTILINK_TOKEN_EXTRACT_LOADED:-}" ]; then
    return 0 2>/dev/null || exit 0
fi
_SOLOPTILINK_TOKEN_EXTRACT_LOADED=1

# -----------------------------------------------------------------------------
# 既定値 (呼び出し側が環境変数で上書き可能)
# -----------------------------------------------------------------------------
: "${SOLOPTILINK_TOKEN_MARKER:=__act-}"    # ファイル名に埋め込むマーカー
: "${SOLOPTILINK_TOKEN_LEN:=26}"           # トークン長 (128bit base32 = 26字)
: "${SOLOPTILINK_TOKEN_CHARSET:=a-z0-9}"   # 許容文字クラス(角括弧の中身)
: "${SOLOPTILINK_TOKEN_AUTH:=on}"          # off = キルスイッチ(旧フローへ退避)
: "${SOLOPTILINK_TOKEN_NORMALIZE:=auto}"   # off = 正規化を行わない(切り分け用)
: "${SOLOPTILINK_TOKEN_DEBUG:=0}"          # 1 = 診断を stderr へ(トークンはマスク)

# 直近の抽出がどこから採れたか (診断用・トークンそのものは入れない)
SOLOPTILINK_TOKEN_SOURCE=""

# -----------------------------------------------------------------------------
# 内部ユーティリティ
# -----------------------------------------------------------------------------

_ta_have() { command -v "$1" >/dev/null 2>&1; }

_ta_dbg() {
    [ "${SOLOPTILINK_TOKEN_DEBUG:-0}" = "1" ] || return 0
    printf '[token-extract] %s\n' "$1" >&2
    return 0
}

# トークンをログ表示用にマスクする (先頭4字のみ残す)
# 使い方: token_mask "$TOKEN"
token_mask() {
    local t="${1:-}"
    if [ -z "$t" ]; then
        printf '(なし)'
        return 0
    fi
    if [ ${#t} -le 6 ]; then
        printf '****'
        return 0
    fi
    printf '%s****(%d字)' "$(printf '%s' "$t" | cut -c1-4)" "${#t}"
    return 0
}

# ASCII 英大文字のみ小文字化 (多バイト文字は壊さない)
_ta_lower() {
    printf '%s' "${1:-}" | LC_ALL=C tr 'A-Z' 'a-z'
    return 0
}

# ERE メタ文字のエスケープ
_ta_regex_quote() {
    printf '%s' "${1:-}" | LC_ALL=C sed 's/[][(){}.*+?^$|\\/]/\\&/g'
    return 0
}

# ファイル/ディレクトリの mtime(エポック秒)。取れないときは 0。
_ta_mtime() {
    local p="${1:-}" m=""
    m=$(stat -f '%m' "$p" 2>/dev/null || true)          # BSD (macOS)
    if [ -z "$m" ]; then
        m=$(stat -c '%Y' "$p" 2>/dev/null || true)      # GNU (Linux)
    fi
    case "$m" in
        ''|*[!0-9]*) m=0 ;;
    esac
    printf '%s' "$m"
    return 0
}

# -----------------------------------------------------------------------------
# 正規化: 全角→半角 / NFC・NFD 差の吸収
#   perl (macOS 標準搭載) → python3 → 純 bash の表引き、の順に試す。
#   どれも使えなくても必ず何かを返す(致命化しない)。
# -----------------------------------------------------------------------------

# 純 bash 版フォールバック: 本件で必要な範囲(英数字・アンダースコア・ハイフン・空白)
# の全角文字だけを半角へ畳む。NFD の合成は行えないため、装飾語の NFD 形は
# _ta_strip_decorations 側で literal として個別に処理する。
_ta_fold_fullwidth_fallback() {
    local s="${1:-}" i=0 ch="" fw="" hex=""

    # 全角数字 U+FF10..FF19 (EF BC 90..99)
    i=0
    for ch in 0 1 2 3 4 5 6 7 8 9; do
        hex=$(printf '%02x' $((0x90 + i)))
        fw=$(printf "\xef\xbc\x${hex}")
        s="${s//$fw/$ch}"
        i=$((i + 1))
    done

    # 全角英小文字 U+FF41..FF5A (EF BD 81..9A)
    i=0
    for ch in a b c d e f g h i j k l m n o p q r s t u v w x y z; do
        hex=$(printf '%02x' $((0x81 + i)))
        fw=$(printf "\xef\xbd\x${hex}")
        s="${s//$fw/$ch}"
        i=$((i + 1))
    done

    # 全角英大文字 U+FF21..FF3A (EF BC A1..BA)
    i=0
    for ch in A B C D E F G H I J K L M N O P Q R S T U V W X Y Z; do
        hex=$(printf '%02x' $((0xa1 + i)))
        fw=$(printf "\xef\xbc\x${hex}")
        s="${s//$fw/$ch}"
        i=$((i + 1))
    done

    # 全角記号: ＿(U+FF3F) －(U+FF0D) ．(U+FF0E) （(U+FF08) ）(U+FF09) 　(U+3000)
    fw=$(printf '\xef\xbc\xbf'); s="${s//$fw/_}"
    fw=$(printf '\xef\xbc\x8d'); s="${s//$fw/-}"
    fw=$(printf '\xef\xbc\x8e'); s="${s//$fw/.}"
    fw=$(printf '\xef\xbc\x88'); s="${s//$fw/(}"
    fw=$(printf '\xef\xbc\x89'); s="${s//$fw/)}"
    fw=$(printf '\xe3\x80\x80'); s="${s//$fw/ }"
    # 全角長音符に似た罫線などは対象外(トークン文字ではないため実害なし)

    printf '%s' "$s"
    return 0
}

_ta_nfkc() {
    local s="${1:-}" out=""

    if [ "${SOLOPTILINK_TOKEN_NORMALIZE:-auto}" = "off" ] || [ -z "$s" ]; then
        printf '%s' "$s"
        return 0
    fi

    # 1) perl (macOS に標準搭載。Unicode::Normalize も同梱)
    if _ta_have perl; then
        out=$(printf '%s' "$s" | perl -CSDA -MUnicode::Normalize \
              -e 'local $/; my $t = <STDIN>; $t = "" unless defined $t; print NFKC($t);' 2>/dev/null || true)
        if [ -n "$out" ]; then
            printf '%s' "$out"
            return 0
        fi
    fi

    # 2) python3 (入っていれば使う。素の macOS には無いことがある)
    if _ta_have python3; then
        out=$(printf '%s' "$s" | python3 -c \
              'import sys,unicodedata; d=sys.stdin.buffer.read().decode("utf-8","ignore"); sys.stdout.write(unicodedata.normalize("NFKC", d))' 2>/dev/null || true)
        if [ -n "$out" ]; then
            printf '%s' "$out"
            return 0
        fi
    fi

    # 3) 純 bash の表引き
    _ta_fold_fullwidth_fallback "$s"
    return 0
}

# -----------------------------------------------------------------------------
# 装飾除去
#   末尾(拡張子の直前)にしか現れない装飾だけを、末尾から順に剥がす。
#   ※ 文字列の途中を触らないのが安全上の要。マーカーは "__act-" のように
#     ハイフンで終わるため、「-1 を無条件に消す」ような実装をすると
#     "__act-1xxxx" のトークン先頭を削る事故が起きる。
# -----------------------------------------------------------------------------

# 複製装飾の literal (NFC / NFD 両方)
_TA_COPY_JA_NFC=$(printf '\xe3\x82\xb3\xe3\x83\x94\xe3\x83\xbc')                 # コピー (NFC)
_TA_COPY_JA_NFD=$(printf '\xe3\x82\xb3\xe3\x83\x92\xe3\x82\x9a\xe3\x83\xbc')     # コピー (NFD: ヒ + U+309A)
_TA_NO_JA=$(printf '\xe3\x81\xae')                                               # の

_ta_rtrim_space() {
    printf '%s' "${1:-}" | LC_ALL=C sed -e 's/[[:space:]]*$//'
    return 0
}

_ta_strip_one_round() {
    local s="${1:-}"

    # a) 末尾空白
    s=$(_ta_rtrim_space "$s")

    # b) 拡張子・部分ダウンロード残骸 (1 ラウンドにつき 1 つ)
    case "$s" in
        *.zip|*.ZIP|*.Zip)         s="${s%.*}" ;;
        *.download|*.crdownload)   s="${s%.*}" ;;
        *.part|*.partial|*.tmp)    s="${s%.*}" ;;
        *.tar|*.tgz)               s="${s%.*}" ;;
    esac

    # c) ブラウザの重複ダウンロード装飾  " (1)" / "(12)"
    s=$(printf '%s' "$s" | LC_ALL=C sed -E 's/[[:space:]]*\([0-9]{1,3}\)[[:space:]]*$//')

    # d) Safari 系の連番  "-1" / "_2" (末尾限定。トークン文字集合に - _ は無いので安全)
    s=$(printf '%s' "$s" | LC_ALL=C sed -E 's/[-_][0-9]{1,3}$//')

    # e) 複製装飾 (英語)  " copy" / " copy 2"  ※ 呼び出し前に小文字化済み
    s=$(printf '%s' "$s" | LC_ALL=C sed -E 's/[[:space:]]+copy([[:space:]]+[0-9]{1,3})?$//')

    # f) 複製装飾 (日本語)  "のコピー" / "コピー" (NFC / NFD 両方)
    s="${s%$_TA_COPY_JA_NFC}"
    s="${s%$_TA_COPY_JA_NFD}"
    s=$(_ta_rtrim_space "$s")
    s="${s%$_TA_NO_JA}"
    s=$(_ta_rtrim_space "$s")
    s="${s%-}"                       # Windows の「名前 - コピー」の残り
    s=$(_ta_rtrim_space "$s")

    printf '%s' "$s"
    return 0
}

_ta_strip_decorations() {
    local s="${1:-}" prev="" n=0
    while [ $n -lt 6 ]; do
        prev="$s"
        s=$(_ta_strip_one_round "$s")
        [ "$s" = "$prev" ] && break
        n=$((n + 1))
    done
    printf '%s' "$s"
    return 0
}

# -----------------------------------------------------------------------------
# 公開関数
# -----------------------------------------------------------------------------

# 名前を照合可能な形へ正規化する (全角→半角 / NFC・NFD 吸収 / 小文字化 / 装飾除去)
token_normalize_name() {
    local s="${1:-}"
    s=$(_ta_nfkc "$s")
    s=$(_ta_lower "$s")
    s=$(_ta_strip_decorations "$s")
    printf '%s' "$s"
    return 0
}

# トークン書式の妥当性判定 (この関数だけは真偽を終了コードで返す)
#   0 = 妥当 / 1 = 不当
token_is_valid_format() {
    local t="${1:-}"
    local len="${SOLOPTILINK_TOKEN_LEN:-26}"
    local cls="${SOLOPTILINK_TOKEN_CHARSET:-a-z0-9}"
    [ -n "$t" ] || return 1
    [ "${#t}" -eq "$len" ] || return 1
    printf '%s' "$t" | LC_ALL=C grep -qE "^[${cls}]{${len}}\$" || return 1
    return 0
}

# 任意の文字列(ファイル名・フォルダ名・パス)からトークンを抽出する
#   出力: トークン or 空。終了コードは常に 0。
token_extract_from_string() {
    local raw="${1:-}"
    [ -n "$raw" ] || return 0
    [ "${SOLOPTILINK_TOKEN_AUTH:-on}" != "off" ] || return 0

    local norm="" marker="" marker_re="" cls="" hits="" line="" cand=""
    norm=$(token_normalize_name "$raw")
    marker=$(_ta_lower "${SOLOPTILINK_TOKEN_MARKER:-__act-}")
    marker_re=$(_ta_regex_quote "$marker")
    cls="${SOLOPTILINK_TOKEN_CHARSET:-a-z0-9}"

    hits=$(printf '%s\n' "$norm" | LC_ALL=C grep -oE "${marker_re}[${cls}]+" 2>/dev/null || true)
    [ -n "$hits" ] || return 0

    while IFS= read -r line; do
        [ -n "$line" ] || continue
        cand="${line#"$marker"}"
        # ちょうど規定長のときだけ採用する(長すぎ・短すぎは誤検出として捨てる)
        if token_is_valid_format "$cand"; then
            printf '%s' "$cand"
            return 0
        fi
    done <<TA_HITS_EOF
$hits
TA_HITS_EOF

    return 0
}

# パスからトークンを抽出する
#   ベース名 → 上位フォルダ名を順に遡る → パス全体、の順で試す。
#   出力: トークン or 空。終了コードは常に 0。
token_extract_from_path() {
    local p="${1:-}"
    [ -n "$p" ] || return 0

    local cur="$p" base="" t="" guard=0
    while [ -n "$cur" ] && [ "$cur" != "/" ] && [ "$cur" != "." ] && [ $guard -lt 24 ]; do
        base=$(basename "$cur")
        t=$(token_extract_from_string "$base")
        if [ -n "$t" ]; then
            SOLOPTILINK_TOKEN_SOURCE="path:$(basename "$cur" | cut -c1-24)"
            printf '%s' "$t"
            return 0
        fi
        cur=$(dirname "$cur")
        guard=$((guard + 1))
    done

    # 最後にパス全体で 1 回試す(区切りをまたいだ崩れの保険)
    t=$(token_extract_from_string "$p")
    if [ -n "$t" ]; then
        SOLOPTILINK_TOKEN_SOURCE="path-whole"
        printf '%s' "$t"
        return 0
    fi
    return 0
}

# ディレクトリ直下(1階層のみ)を走査して、トークンを含む名前から抽出する
#   複数見つかった場合は mtime が最も新しいものを採用する。
#   出力: トークン or 空。終了コードは常に 0。
token_extract_from_dir() {
    local dir="${1:-}"
    [ -n "$dir" ] || return 0
    [ -d "$dir" ] || return 0
    [ "${SOLOPTILINK_TOKEN_AUTH:-on}" != "off" ] || return 0

    local entry="" base="" cand="" m=0
    local best_t="" best_m=-1 best_name=""

    for entry in "$dir"/*; do
        [ -e "$entry" ] || continue
        base=$(basename "$entry")
        cand=$(token_extract_from_string "$base")
        [ -n "$cand" ] || continue
        m=$(_ta_mtime "$entry")
        if [ "$m" -gt "$best_m" ]; then
            best_m="$m"
            best_t="$cand"
            best_name="$base"
        fi
    done

    if [ -n "$best_t" ]; then
        SOLOPTILINK_TOKEN_SOURCE="dir:$(printf '%s' "$dir" | sed "s|^$HOME|~|")"
        _ta_dbg "候補を採用: $(printf '%s' "$best_name" | cut -c1-20)... token=$(token_mask "$best_t")"
        printf '%s' "$best_t"
        return 0
    fi
    return 0
}

# 自動探索 (設計書 §4.3 の優先順)
#   1. 環境変数 SOLOPTILINK_ACTIVATION_TOKEN (既知の値・書式検査は行う)
#   2. 引数で渡されたパス/ディレクトリ
#   3. セットアップキットのフォルダ名 (SOLOPTILINK_KIT_DIR / 第2引数以降)
#   4. キットの親フォルダ / ダウンロード / デスクトップ / カレント の走査
#   出力: トークン or 空。終了コードは常に 0。
token_extract_auto() {
    [ "${SOLOPTILINK_TOKEN_AUTH:-on}" != "off" ] || return 0

    local t="" arg="" d=""
    SOLOPTILINK_TOKEN_SOURCE=""

    # 1) 明示指定 (呼び出し側が既に知っている場合)
    if [ -n "${SOLOPTILINK_ACTIVATION_TOKEN:-}" ]; then
        if token_is_valid_format "${SOLOPTILINK_ACTIVATION_TOKEN}"; then
            SOLOPTILINK_TOKEN_SOURCE="env"
            printf '%s' "${SOLOPTILINK_ACTIVATION_TOKEN}"
            return 0
        fi
    fi

    # 2) 引数(ファイル・ディレクトリ・任意文字列)
    for arg in "$@"; do
        [ -n "$arg" ] || continue
        if [ -d "$arg" ]; then
            t=$(token_extract_from_path "$arg")
            [ -n "$t" ] || t=$(token_extract_from_dir "$arg")
        else
            t=$(token_extract_from_path "$arg")
        fi
        if [ -n "$t" ]; then
            printf '%s' "$t"
            return 0
        fi
    done

    # 3) キットフォルダ自身の名前
    if [ -n "${SOLOPTILINK_KIT_DIR:-}" ]; then
        t=$(token_extract_from_path "${SOLOPTILINK_KIT_DIR}")
        if [ -n "$t" ]; then
            printf '%s' "$t"
            return 0
        fi
    fi

    # 4) 近傍ディレクトリの走査
    #    キットフォルダ自身 → その親 → ダウンロード → デスクトップ → カレント
    #    (キット内に ZIP を置いたまま展開する顧客が居るため、自身も走査対象にする)
    for d in \
        "${SOLOPTILINK_KIT_DIR:-}" \
        "${SOLOPTILINK_KIT_DIR:+$(dirname "${SOLOPTILINK_KIT_DIR}")}" \
        "$HOME/Downloads" \
        "$HOME/Desktop" \
        "$PWD"
    do
        [ -n "$d" ] || continue
        [ -d "$d" ] || continue
        t=$(token_extract_from_dir "$d")
        if [ -n "$t" ]; then
            printf '%s' "$t"
            return 0
        fi
    done

    _ta_dbg "トークンは見つかりませんでした(フォールバックへ)"
    return 0
}

# -----------------------------------------------------------------------------
# 直接実行時のコマンドライン interface
#   使い方:
#     token-extract.sh                 … 自動探索
#     token-extract.sh <パス> [...]    … 指定パスから抽出
#   終了コードは既定で常に 0 (未検出でもインストーラを止めないため)。
#   SOLOPTILINK_TOKEN_STRICT_RC=1 のときだけ未検出で 1 を返す。
# -----------------------------------------------------------------------------
if [ "${BASH_SOURCE[0]:-$0}" = "$0" ]; then
    _ta_cli_out=$(token_extract_auto "$@")
    if [ -n "$_ta_cli_out" ]; then
        printf '%s\n' "$_ta_cli_out"
        exit 0
    fi
    if [ "${SOLOPTILINK_TOKEN_STRICT_RC:-0}" = "1" ]; then
        exit 1
    fi
    exit 0
fi
