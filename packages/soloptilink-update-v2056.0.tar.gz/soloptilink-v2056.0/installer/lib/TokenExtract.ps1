﻿# =============================================================================
# TokenExtract.ps1 — 導入ワンタイムトークンの寛容抽出 + 痕跡無害化 (Windows 版)
#   基本設計書 04「導入オートパイロット」 §4.3 / §4.4 / §11.1 準拠
#   Mac 版 (token-extract.sh / token-sanitize.sh) と同じ契約・同じ検体で動く。
# =============================================================================
# 契約:
#   1. すべての関数は **例外を投げない**。失敗は空文字列 / 元の値で返す。
#      呼び出し元 (soloptilink-install.ps1) の $ErrorActionPreference が Stop でも
#      導入を止めない。
#   2. 見つからない場合は空文字列を返す。空 = 未検出 = 上位のフォールバックへ。
#   3. トークンをコンソールへ素で出さない (Format-SolTokenMask を使う)。
#   4. 削除は行わない。無害化はリネームのみ。
#
# 使い方:
#   . "$PSScriptRoot\lib\TokenExtract.ps1"
#   $token = Get-SolActivationToken -KitDir $KitDir
#   if ($token) { & $launcher --activate --token $token }
#   Clear-SolTokenTraceAuto -Token $token -KitDir $KitDir
# =============================================================================

$script:SolTokenMarker  = if ($env:SOLOPTILINK_TOKEN_MARKER)  { $env:SOLOPTILINK_TOKEN_MARKER }  else { '__act-' }
$script:SolTokenLength  = if ($env:SOLOPTILINK_TOKEN_LEN)     { [int]$env:SOLOPTILINK_TOKEN_LEN } else { 26 }
$script:SolTokenCharset = if ($env:SOLOPTILINK_TOKEN_CHARSET) { $env:SOLOPTILINK_TOKEN_CHARSET } else { 'a-z0-9' }
$script:SolTokenAuth    = if ($env:SOLOPTILINK_TOKEN_AUTH)    { $env:SOLOPTILINK_TOKEN_AUTH }    else { 'on' }
$script:SolTokenSanit   = if ($env:SOLOPTILINK_TOKEN_SANITIZE){ $env:SOLOPTILINK_TOKEN_SANITIZE }else { 'on' }
$script:SolNeutralName  = 'SoloptiLinkAI_setup'

function Format-SolTokenMask {
    param([string]$Token)
    if ([string]::IsNullOrEmpty($Token)) { return '(なし)' }
    if ($Token.Length -le 6) { return '****' }
    return ($Token.Substring(0,4) + '****(' + $Token.Length + '字)')
}

# 全角→半角 / NFC・NFD 差の吸収 (.NET の互換合成正規化) + 小文字化 + 装飾除去
function Get-SolTokenNormalizedName {
    param([string]$Name)
    if ([string]::IsNullOrEmpty($Name)) { return '' }
    $s = $Name
    try { $s = $s.Normalize([System.Text.NormalizationForm]::FormKC) } catch { }
    $s = $s.ToLowerInvariant()

    # 末尾装飾を安定するまで剥がす (途中は触らない = マーカー直後を壊さないため)
    for ($i = 0; $i -lt 6; $i++) {
        $prev = $s
        $s = $s -replace '\s+$', ''
        $s = $s -replace '\.(zip|download|crdownload|part|partial|tmp|tar|tgz)$', ''
        $s = $s -replace '\s*\(\d{1,3}\)\s*$', ''      # ブラウザの重複DL装飾
        $s = $s -replace '[-_]\d{1,3}$', ''            # Safari 系連番
        $s = $s -replace '\s+copy(\s+\d{1,3})?$', ''   # 英語の複製装飾
        $s = $s -replace '\s*の?コピー$', ''            # 日本語の複製装飾
        $s = $s -replace '\s*-\s*$', ''                # 「名前 - コピー」の残り
        $s = $s -replace '\s+$', ''
        if ($s -eq $prev) { break }
    }
    return $s
}

function Test-SolTokenFormat {
    param([string]$Token)
    if ([string]::IsNullOrEmpty($Token)) { return $false }
    if ($Token.Length -ne $script:SolTokenLength) { return $false }
    return ($Token -match ('^[' + $script:SolTokenCharset + ']{' + $script:SolTokenLength + '}$'))
}

function Get-SolTokenFromString {
    param([string]$Name)
    if ($script:SolTokenAuth -eq 'off') { return '' }
    if ([string]::IsNullOrEmpty($Name)) { return '' }
    try {
        $norm = Get-SolTokenNormalizedName -Name $Name
        $marker = [regex]::Escape($script:SolTokenMarker.ToLowerInvariant())
        $rx = [regex]("$marker([" + $script:SolTokenCharset + "]+)")
        foreach ($m in $rx.Matches($norm)) {
            $cand = $m.Groups[1].Value
            # ちょうど規定長のときだけ採用する (長すぎ・短すぎは誤検出として捨てる)
            if (Test-SolTokenFormat -Token $cand) { return $cand }
        }
    } catch { }
    return ''
}

function Get-SolTokenFromPath {
    param([string]$Path)
    if ([string]::IsNullOrEmpty($Path)) { return '' }
    try {
        $cur = $Path
        for ($i = 0; $i -lt 24; $i++) {
            if ([string]::IsNullOrEmpty($cur)) { break }
            $leaf = Split-Path -Leaf $cur
            if ([string]::IsNullOrEmpty($leaf)) { break }
            $t = Get-SolTokenFromString -Name $leaf
            if ($t) { return $t }
            $parent = Split-Path -Parent $cur
            if ($parent -eq $cur) { break }
            $cur = $parent
        }
        return (Get-SolTokenFromString -Name $Path)
    } catch { }
    return ''
}

function Get-SolTokenFromDirectory {
    param([string]$Dir)
    if ([string]::IsNullOrEmpty($Dir)) { return '' }
    if (-not (Test-Path -LiteralPath $Dir)) { return '' }
    try {
        $best = $null; $bestTime = [datetime]::MinValue
        foreach ($e in (Get-ChildItem -LiteralPath $Dir -Force -ErrorAction SilentlyContinue)) {
            $t = Get-SolTokenFromString -Name $e.Name
            if (-not $t) { continue }
            if ($e.LastWriteTimeUtc -gt $bestTime) { $bestTime = $e.LastWriteTimeUtc; $best = $t }
        }
        if ($best) { return $best }
    } catch { }
    return ''
}

# 自動探索 (Mac 版 token_extract_auto と同じ優先順)
function Get-SolActivationToken {
    param([string]$KitDir, [string[]]$Candidates)
    if ($script:SolTokenAuth -eq 'off') { return '' }
    try {
        if ($env:SOLOPTILINK_ACTIVATION_TOKEN -and (Test-SolTokenFormat -Token $env:SOLOPTILINK_ACTIVATION_TOKEN)) {
            return $env:SOLOPTILINK_ACTIVATION_TOKEN
        }
        foreach ($c in $Candidates) {
            if (-not $c) { continue }
            $t = Get-SolTokenFromPath -Path $c
            if (-not $t -and (Test-Path -LiteralPath $c -PathType Container)) { $t = Get-SolTokenFromDirectory -Dir $c }
            if ($t) { return $t }
        }
        if ($KitDir) {
            $t = Get-SolTokenFromPath -Path $KitDir
            if ($t) { return $t }
        }
        $dirs = @()
        if ($KitDir) { $dirs += $KitDir; $dirs += (Split-Path -Parent $KitDir) }
        if ($env:USERPROFILE) { $dirs += (Join-Path $env:USERPROFILE 'Downloads'); $dirs += (Join-Path $env:USERPROFILE 'Desktop') }
        $dirs += (Get-Location).Path
        foreach ($d in $dirs) {
            if (-not $d) { continue }
            $t = Get-SolTokenFromDirectory -Dir $d
            if ($t) { return $t }
        }
    } catch { }
    return ''
}

# ---------------------------------------------------------------------------
# 無害化 (リネームのみ・削除は行わない)
# ---------------------------------------------------------------------------

function Test-SolTokenTrace {
    param([string]$Name)
    if ([string]::IsNullOrEmpty($Name)) { return $false }
    $marker = $script:SolTokenMarker.ToLowerInvariant()
    if ((Get-SolTokenNormalizedName -Name $Name).Contains($marker)) { return $true }
    return ($Name.ToLowerInvariant().Contains($marker))
}

function Get-SolCleanBaseName {
    param([string]$BaseName, [string]$Token)
    $ext = [System.IO.Path]::GetExtension($BaseName)
    if ($ext -and ($ext -notmatch '^\.[A-Za-z0-9]{1,5}$')) { $ext = '' }
    $stem = if ($ext) { $BaseName.Substring(0, $BaseName.Length - $ext.Length) } else { $BaseName }

    if ($Token) {
        $stem = $stem.Replace(($script:SolTokenMarker + $Token), '')
        $stem = $stem.Replace($Token, '')
    }
    $marker = [regex]::Escape($script:SolTokenMarker)
    $stem = $stem -replace ($marker + '[A-Za-z0-9]*'), ''
    $stem = $stem -replace '_{3,}', '__'
    $stem = $stem -replace '\s+', ' '
    $stem = $stem -replace '^[\s._-]+', ''
    $stem = $stem -replace '[\s._-]+$', ''
    if (-not $stem -or (Test-SolTokenTrace -Name $stem)) { $stem = $script:SolNeutralName }
    return ($stem + $ext)
}

function Clear-SolTokenTrace {
    param([string]$Path, [string]$Token)
    if ($script:SolTokenSanit -eq 'off') { return $Path }
    if ([string]::IsNullOrEmpty($Path)) { return $Path }
    try {
        if (-not (Test-Path -LiteralPath $Path)) { return $Path }
        $parent = Split-Path -Parent $Path
        $base   = Split-Path -Leaf $Path
        if (-not $parent -or -not $base) { return $Path }
        if (-not (Test-SolTokenTrace -Name $base)) { return $Path }

        $newBase = Get-SolCleanBaseName -BaseName $base -Token $Token
        if (-not $newBase -or ($newBase -eq $base)) { return $Path }

        $cand = $newBase; $i = 1
        $cext = [System.IO.Path]::GetExtension($newBase)
        $cstem = if ($cext) { $newBase.Substring(0, $newBase.Length - $cext.Length) } else { $newBase }
        while ((Test-Path -LiteralPath (Join-Path $parent $cand)) -and ($i -le 20)) {
            $cand = ($cstem + '-' + $i + $cext); $i++
        }
        if (Test-Path -LiteralPath (Join-Path $parent $cand)) { return $Path }

        Rename-Item -LiteralPath $Path -NewName $cand -ErrorAction SilentlyContinue
        $newPath = Join-Path $parent $cand
        if (Test-Path -LiteralPath $newPath) { return $newPath }
    } catch { }
    return $Path   # 失敗しても導入は止めない
}

function Clear-SolTokenTraceInDirectory {
    param([string]$Dir, [string]$Token)
    if ($script:SolTokenSanit -eq 'off') { return }
    if (-not $Dir -or -not (Test-Path -LiteralPath $Dir)) { return }
    try {
        foreach ($e in (Get-ChildItem -LiteralPath $Dir -Force -ErrorAction SilentlyContinue)) {
            if (-not (Test-SolTokenTrace -Name $e.Name)) { continue }
            # トークン指定時は、そのトークンの痕跡だけを対象にする
            # (同じ端末に別端末用の未使用キットが置かれている場合を壊さないため)
            if ($Token) {
                $got = Get-SolTokenFromString -Name $e.Name
                if ($got -ne $Token) { continue }
            }
            [void](Clear-SolTokenTrace -Path $e.FullName -Token $Token)
        }
    } catch { }
}

function Clear-SolTokenTraceAuto {
    param([string]$Token, [string]$KitDir, [string[]]$ExtraDirs)
    if ($script:SolTokenSanit -eq 'off') { return }
    try {
        $dirs = @()
        if ($env:USERPROFILE) { $dirs += (Join-Path $env:USERPROFILE 'Downloads'); $dirs += (Join-Path $env:USERPROFILE 'Desktop') }
        if ($KitDir) { $dirs += (Split-Path -Parent $KitDir) }
        if ($ExtraDirs) { $dirs += $ExtraDirs }
        foreach ($d in $dirs) {
            if (-not $d -or -not (Test-Path -LiteralPath $d)) { continue }
            foreach ($e in (Get-ChildItem -LiteralPath $d -Force -ErrorAction SilentlyContinue)) {
                if ($KitDir -and ($e.FullName -eq $KitDir)) { continue }   # 実行中のキットは最後に別途
                if (-not (Test-SolTokenTrace -Name $e.Name)) { continue }
                if ($Token) {
                    $got = Get-SolTokenFromString -Name $e.Name
                    if ($got -ne $Token) { continue }
                }
                [void](Clear-SolTokenTrace -Path $e.FullName -Token $Token)
            }
        }
    } catch { }
}
