#!/usr/bin/env bash
# =============================================================================
# token-sanitize.sh — 導入トークン痕跡の無害化(リネーム)部品
#   基本設計書 04「導入オートパイロット」 §4.3 (末尾) / §4.4 準拠
#   レーン: 本体側 (installer)。サーバ側の失効処理は別レーン。
# =============================================================================
# 役割:
#   端末登録が成功した後、ダウンロードフォルダや展開フォルダに残る
#   ファイル名のトークン痕跡 (…__act-<26字>…) を **リネームで** 消す。
#   使用済みトークンは単回使用で無価値になるが、名前として残り続けると
#   画面共有・スクリーンショット・サポート問い合わせの添付で露出するため、
#   成功直後に自分で片付ける。
#
# 契約 (呼び出し側はこれに依存してよい):
#   1. 公開関数はすべて **常に終了コード 0** を返す。リネームに失敗しても
#      導入は止めない(fail-open)。顧客への「要対応」表示も出さない。
#   2. **削除は一切行わない**。行うのはリネームのみ。
#      (顧客の手元の資料を消さない。失敗しても最悪「名前が古いまま」で済む)
#   3. token_sanitize_path / token_sanitize_self は結果のパスを標準出力へ返す。
#      リネームできなかった場合は元のパスをそのまま返す。
#   4. 依存は bash 3.2 (macOS 既定) + POSIX コマンドのみ。
#
# 安全弁:
#   - 対象は「名前に痕跡を含むもの」だけ。痕跡が無ければ何もしない。
#   - 走査(token_sanitize_dir / token_sanitize_auto)でトークンを指定した場合は、
#     **そのトークンの痕跡だけ**を対象にする。1台の端末に2台分のキットが
#     置かれている場合に、まだ使っていない別端末用の名前を壊さないため。
#   - ルート直下・ホーム直下そのもの・親を持たないパスは対象外。
#   - リネーム先が既に存在する場合は連番を付ける。20 回試して駄目なら諦める。
#   - 走査は各ルートの 1 階層のみ。ホーム全体を再帰的に漁らない。
#
# 使い方(概略):
#   source token-extract.sh
#   source token-sanitize.sh
#   token_sanitize_auto "$TOKEN"                 # ZIP など周辺の痕跡を消す
#   KIT_DIR="$(token_sanitize_self "$KIT_DIR")"  # 実行中のキットは最後に
# =============================================================================

if [ -n "${_SOLOPTILINK_TOKEN_SANITIZE_LOADED:-}" ]; then
    return 0 2>/dev/null || exit 0
fi
_SOLOPTILINK_TOKEN_SANITIZE_LOADED=1

# token-extract.sh の正規化・書式判定を利用する(未ロードなら同階層から読む)
if ! command -v token_normalize_name >/dev/null 2>&1; then
    _ts_self_dir=$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd)
    if [ -f "${_ts_self_dir}/token-extract.sh" ]; then
        # shellcheck source=/dev/null
        . "${_ts_self_dir}/token-extract.sh"
    fi
fi

: "${SOLOPTILINK_TOKEN_MARKER:=__act-}"
: "${SOLOPTILINK_TOKEN_SANITIZE:=on}"        # off = キルスイッチ(何もしない)
: "${SOLOPTILINK_TOKEN_SANITIZE_XATTR:=0}"   # 1 = ダウンロード由来メタデータも消す
: "${SOLOPTILINK_TOKEN_NEUTRAL_NAME:=SoloptiLinkAI_setup}"

# -----------------------------------------------------------------------------
# 内部ユーティリティ
# -----------------------------------------------------------------------------

_ts_dbg() {
    [ "${SOLOPTILINK_TOKEN_DEBUG:-0}" = "1" ] || return 0
    printf '[token-sanitize] %s\n' "$1" >&2
    return 0
}

# 監査用の控え(トークンは残さない・失敗しても無視)
_ts_log() {
    local line="$1" logdir="$HOME/.soloptilink/logs"
    mkdir -p "$logdir" 2>/dev/null || return 0
    printf '%s %s\n' "$(date -u '+%Y-%m-%dT%H:%M:%SZ' 2>/dev/null || echo '-')" "$line" \
        >> "$logdir/token-sanitize.log" 2>/dev/null || true
    return 0
}

# 名前に痕跡があるか (正規化してから判定するので全角・NFD・装飾付きでも拾える)
#   0 = 痕跡あり / 1 = 無し
_ts_has_trace() {
    local name="${1:-}" norm="" marker=""
    [ -n "$name" ] || return 1
    marker="${SOLOPTILINK_TOKEN_MARKER:-__act-}"
    if command -v token_normalize_name >/dev/null 2>&1; then
        norm=$(token_normalize_name "$name")
    else
        norm=$(printf '%s' "$name" | LC_ALL=C tr 'A-Z' 'a-z')
    fi
    case "$norm" in
        *"$marker"*) return 0 ;;
    esac
    # 装飾除去で拡張子ごと落ちた場合の保険として素の名前でも見る
    case "$(printf '%s' "$name" | LC_ALL=C tr 'A-Z' 'a-z')" in
        *"$marker"*) return 0 ;;
    esac
    return 1
}

# 走査時に触ってよい相手かを判定する
#   使用済みトークンが分かっている場合、**そのトークンの痕跡だけ**を対象にする。
#   1台の端末で2台分のキットをダウンロードしている場合(管理者がまとめて落とす等)、
#   まだ使っていない別端末用トークンまで消してしまうのを防ぐための安全弁。
#   トークン未指定のときは痕跡すべてを対象にする。
#   0 = 触ってよい / 1 = 触らない
_ts_should_touch() {
    local base="${1:-}" token="${2:-}" got=""
    [ -n "$token" ] || return 0
    if command -v token_extract_from_string >/dev/null 2>&1; then
        got=$(token_extract_from_string "$base")
    fi
    [ "$got" = "$token" ] && return 0
    _ts_dbg "別トークンの痕跡のため対象外にしました: $(printf '%s' "$base" | cut -c1-16)..."
    return 1
}

# 拡張子(短い英数字のみ)を取り出す。無ければ空。
_ts_ext_of() {
    local b="${1:-}" ext=""
    case "$b" in
        *.*) ext="${b##*.}" ;;
        *)   ext="" ;;
    esac
    case "$ext" in
        ''|*[!A-Za-z0-9]*) ext="" ;;
    esac
    if [ -n "$ext" ] && [ ${#ext} -le 5 ]; then
        printf '.%s' "$ext"
    fi
    return 0
}

# ベース名から痕跡を取り除いた新しいベース名を組み立てる
#   $1 = 元のベース名 / $2 = 既知のトークン(空可)
_ts_clean_base() {
    local raw="${1:-}" token="${2:-}" ext="" stem="" marker="" marker_re=""
    marker="${SOLOPTILINK_TOKEN_MARKER:-__act-}"

    # 0) 拡張子は先に分離しておく(整形で巻き添えにしないため)
    ext=$(_ts_ext_of "$raw")
    if [ -n "$ext" ]; then
        stem="${raw%$ext}"
    else
        stem="$raw"
    fi

    # 1) 既知トークンの literal 除去 (マーカー付きの素直な形)
    if [ -n "$token" ]; then
        stem="${stem//${marker}${token}/}"
        stem="${stem//${token}/}"
    fi

    # 2) マーカー + それに続く英数字の連なりを除去 (途中で切れた痕跡も拾う)
    if command -v _ta_regex_quote >/dev/null 2>&1; then
        marker_re=$(_ta_regex_quote "$marker")
    else
        marker_re=$(printf '%s' "$marker" | LC_ALL=C sed 's/[][(){}.*+?^$|\\/]/\\&/g')
    fi
    stem=$(printf '%s' "$stem" | LC_ALL=C sed -E "s/${marker_re}[A-Za-z0-9]*//g")

    # 3) 残骸の整形 (区切り記号の重なり・端の区切り記号)
    stem=$(printf '%s' "$stem" | LC_ALL=C sed -E \
        -e 's/_{3,}/__/g' \
        -e 's/[[:space:]]+/ /g' \
        -e 's/^[[:space:]._-]+//' \
        -e 's/[[:space:]._-]+$//')

    # 4) 空になった / まだ痕跡が残る 場合は中立名へ差し替える
    if [ -z "$stem" ] || _ts_has_trace "$stem"; then
        stem="${SOLOPTILINK_TOKEN_NEUTRAL_NAME:-SoloptiLinkAI_setup}"
    fi

    printf '%s%s' "$stem" "$ext"
    return 0
}

# 衝突しないリネーム先のベース名を返す
_ts_unique_base() {
    local parent="${1:-}" base="${2:-}" stem="" ext="" i=1 cand="$base"
    if [ ! -e "$parent/$cand" ]; then
        printf '%s' "$cand"
        return 0
    fi
    ext=$(_ts_ext_of "$base")
    if [ -n "$ext" ]; then
        stem="${base%$ext}"
    else
        stem="$base"
    fi
    while [ $i -le 20 ]; do
        cand="${stem}-${i}${ext}"
        if [ ! -e "$parent/$cand" ]; then
            printf '%s' "$cand"
            return 0
        fi
        i=$((i + 1))
    done
    printf ''
    return 0
}

# ダウンロード由来メタデータ(どこから落としたか)の除去。既定では行わない。
_ts_scrub_xattr() {
    local p="${1:-}"
    [ "${SOLOPTILINK_TOKEN_SANITIZE_XATTR:-0}" = "1" ] || return 0
    command -v xattr >/dev/null 2>&1 || return 0
    xattr -d com.apple.metadata:kMDItemWhereFroms "$p" >/dev/null 2>&1 || true
    xattr -d com.apple.quarantine "$p" >/dev/null 2>&1 || true
    return 0
}

# -----------------------------------------------------------------------------
# 公開関数
# -----------------------------------------------------------------------------

# 単一のファイル/フォルダの名前から痕跡を消す
#   $1 = パス / $2 = 既知のトークン(空可)
#   出力: 処理後のパス(失敗時は元のパス)。終了コードは常に 0。
token_sanitize_path() {
    local p="${1:-}" token="${2:-}"
    [ -n "$p" ] || return 0
    [ "${SOLOPTILINK_TOKEN_SANITIZE:-on}" != "off" ] || { printf '%s' "$p"; return 0; }

    if [ ! -e "$p" ] && [ ! -L "$p" ]; then
        printf '%s' "$p"
        return 0
    fi

    local parent="" base="" newbase="" target=""
    parent=$(dirname "$p")
    base=$(basename "$p")

    # 安全弁: ルート直下・ホームそのもの・親の無いパスは触らない
    case "$parent" in
        ''|'.'|'/') printf '%s' "$p"; return 0 ;;
    esac
    if [ "$p" = "$HOME" ] || [ "$p" = "/" ]; then
        printf '%s' "$p"
        return 0
    fi

    if ! _ts_has_trace "$base"; then
        printf '%s' "$p"    # 痕跡なし = 何もしない(冪等)
        return 0
    fi

    newbase=$(_ts_clean_base "$base" "$token")
    if [ -z "$newbase" ] || [ "$newbase" = "$base" ]; then
        printf '%s' "$p"
        return 0
    fi

    newbase=$(_ts_unique_base "$parent" "$newbase")
    if [ -z "$newbase" ]; then
        _ts_dbg "リネーム先が確保できませんでした(処理を飛ばします)"
        printf '%s' "$p"
        return 0
    fi

    target="$parent/$newbase"
    if mv -- "$p" "$target" 2>/dev/null; then
        _ts_scrub_xattr "$target"
        _ts_log "renamed ok: $(basename "$target")"
        _ts_dbg "無害化しました: $(basename "$target")"
        printf '%s' "$target"
        return 0
    fi

    # 失敗しても導入は止めない (書込権限なし・使用中・読み取り専用ボリューム等)
    _ts_log "rename failed (無視して続行): $(basename "$p" | cut -c1-12)..."
    _ts_dbg "リネームできませんでしたが、導入は続行します"
    printf '%s' "$p"
    return 0
}

# ディレクトリ直下(1階層のみ)を走査して痕跡を消す
#   $1 = ディレクトリ / $2 = 既知のトークン(空可)
#   終了コードは常に 0。
token_sanitize_dir() {
    local dir="${1:-}" token="${2:-}"
    [ -n "$dir" ] || return 0
    [ -d "$dir" ] || return 0
    [ "${SOLOPTILINK_TOKEN_SANITIZE:-on}" != "off" ] || return 0

    local entry="" base=""
    for entry in "$dir"/*; do
        [ -e "$entry" ] || continue
        base=$(basename "$entry")
        _ts_has_trace "$base" || continue
        _ts_should_touch "$base" "$token" || continue
        token_sanitize_path "$entry" "$token" >/dev/null
    done
    return 0
}

# 既定のルート群 + 追加ディレクトリの痕跡を消す
#   $1 = 既知のトークン(空可) / $2 以降 = 追加で走査するディレクトリ
#   ※ 実行中のキットフォルダ自身は対象にしない (パスが変わると後続工程が壊れるため)。
#      キット自身は token_sanitize_self を最後に呼ぶこと。
#   終了コードは常に 0。
token_sanitize_auto() {
    local token="${1:-}"
    shift 2>/dev/null || true
    [ "${SOLOPTILINK_TOKEN_SANITIZE:-on}" != "off" ] || return 0

    local kit="${SOLOPTILINK_KIT_DIR:-}" d="" entry=""
    for d in \
        "$HOME/Downloads" \
        "$HOME/Desktop" \
        "${kit:+$(dirname "$kit")}" \
        "$@"
    do
        [ -n "$d" ] || continue
        [ -d "$d" ] || continue
        for entry in "$d"/*; do
            [ -e "$entry" ] || continue
            # 実行中のキットフォルダ自身は除外
            if [ -n "$kit" ] && [ "$entry" = "$kit" ]; then
                continue
            fi
            _ts_has_trace "$(basename "$entry")" || continue
            _ts_should_touch "$(basename "$entry")" "$token" || continue
            token_sanitize_path "$entry" "$token" >/dev/null
        done
    done
    return 0
}

# 実行中のキットフォルダ自身をリネームする(必ず最後に呼ぶこと)
#   $1 = キットフォルダ / $2 = 既知のトークン(空可)
#   出力: 処理後のパス(失敗時は元のパス)。終了コードは常に 0。
#   呼び出し側は  KIT_DIR="$(token_sanitize_self "$KIT_DIR")"  のように
#   戻り値でパスを更新すること(更新しないと以降の相対参照が古いパスを指す)。
token_sanitize_self() {
    local kit="${1:-}" token="${2:-}" newpath="" oldpwd=""
    [ -n "$kit" ] || return 0
    [ -d "$kit" ] || { printf '%s' "$kit"; return 0; }

    oldpwd="$PWD"
    newpath=$(token_sanitize_path "$kit" "$token")

    # 自分がリネーム対象の中に居た場合はカレントを新しいパスへ追随させる
    if [ "$newpath" != "$kit" ]; then
        case "$oldpwd" in
            "$kit"|"$kit"/*)
                cd "$newpath${oldpwd#$kit}" 2>/dev/null || cd "$newpath" 2>/dev/null || true
                ;;
        esac
    fi

    printf '%s' "$newpath"
    return 0
}

# -----------------------------------------------------------------------------
# 直接実行時のコマンドライン interface
#   使い方:
#     token-sanitize.sh                 … 既定ルートを走査して無害化
#     token-sanitize.sh <トークン>      … 既知トークンを指定して無害化
#     token-sanitize.sh --path <パス>   … 指定パス 1 件だけ無害化
#   終了コードは常に 0。
# -----------------------------------------------------------------------------
if [ "${BASH_SOURCE[0]:-$0}" = "$0" ]; then
    if [ "${1:-}" = "--path" ]; then
        shift
        token_sanitize_path "${1:-}" "${2:-}" >/dev/null
    else
        token_sanitize_auto "${1:-}"
    fi
    exit 0
fi
