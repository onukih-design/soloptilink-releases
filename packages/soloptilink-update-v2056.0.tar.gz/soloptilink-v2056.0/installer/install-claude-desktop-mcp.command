#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2034.5 - Claude Desktop MCP 自動登録 (Mac)
# =============================================================================
# SoloptiLinkAI-Setup.command 内でも実行されますが、後から単体で再登録する
# 場合のためにこのファイルを残してあります。ダブルクリック実行で動作。
# =============================================================================
set -e
trap 'echo ""; echo "⚠️ エラー。Enterキーで閉じます。"; read -r _; exit 1' ERR

clear 2>/dev/null || true

cat <<'BANNER'

  ╔════════════════════════════════════════════════════════════════╗
  ║    SoloptiLinkAI Claude Desktop MCP 自動登録 (Mac)            ║
  ╚════════════════════════════════════════════════════════════════╝

BANNER

LAUNCHER="$HOME/.soloptilink/soloptilink"
CLAUDE_CONFIG="$HOME/Library/Application Support/Claude/claude_desktop_config.json"
TS=$(date +%Y%m%d_%H%M%S)

# STEP 1: Goランチャー検出
echo "[STEP 1/3] Goランチャー検出"
if [ ! -f "$LAUNCHER" ]; then
    echo "  ⚠️  $LAUNCHER が見つかりません。"
    echo "  先に SoloptiLinkAI-Setup.command を実行してください。"
    echo "[Enterキーで閉じます]"
    read -r _
    exit 1
fi
echo "  ✅ $LAUNCHER"
echo ""

# STEP 2: 既存設定バックアップ
echo "[STEP 2/3] Claude Desktop 設定確認"
mkdir -p "$(dirname "$CLAUDE_CONFIG")"
if [ -f "$CLAUDE_CONFIG" ]; then
    cp "$CLAUDE_CONFIG" "$CLAUDE_CONFIG.bak.$TS"
    echo "  ✅ バックアップ: $CLAUDE_CONFIG.bak.$TS"
else
    echo "  既存設定なし (新規作成)"
fi
echo ""

# STEP 3: soloptilink MCP サーバー登録 (既存 mcpServers 保持)
echo "[STEP 3/3] soloptilink MCP サーバーを登録"
SOLOPTILINK_BIN="$LAUNCHER" python3 - "$CLAUDE_CONFIG" <<'PYEOF'
import json, sys, os
cfg_path = sys.argv[1]
bin_path = os.environ['SOLOPTILINK_BIN']

if os.path.exists(cfg_path) and os.path.getsize(cfg_path) > 0:
    try:
        with open(cfg_path) as f:
            cfg = json.load(f)
    except Exception:
        cfg = {}
else:
    cfg = {}

cfg.setdefault('mcpServers', {})
cfg['mcpServers']['soloptilink'] = {
    'command': bin_path,
    'args': ['--mcp-server']
}

with open(cfg_path, 'w') as f:
    json.dump(cfg, f, indent=2, ensure_ascii=False)
print(f"  ✅ 登録完了")
print(f"     mcpServers.soloptilink.command = {bin_path}")
print(f"     mcpServers.soloptilink.args    = [\"--mcp-server\"]")
PYEOF

cat <<'DONE'

  ╔════════════════════════════════════════════════════════════════╗
  ║      ✅ Claude Desktop MCP 登録 完了                          ║
  ╚════════════════════════════════════════════════════════════════╝

  次のステップ:

    1. Claude Desktop を一度完全終了 (⌘+Q)
    2. Claude Desktop を再起動
    3. チャット欄で /soloptilink-boost が使えるようになります

  サポート: nomura.y@soloptilink.com

DONE

echo "[Enterキーで閉じます]"
read -r _
exit 0
