#!/usr/bin/env bash
# ╔═══════════════════════════════════════════════════════════╗
# ║  SoloptiLink Chain v51.0 - iOS Native Support               ║
# ║  iOSネイティブアプリ自動生成 × 32エージェント × 21層      ║
# ║  全モジュール実接続 × Grand Unification × Living System    ║
# ╚═══════════════════════════════════════════════════════════╝
set -euo pipefail

readonly VERSION="51.0"
readonly SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ============================================================
# v2034.5 / PFP-044: AppleDouble セルフクリーンアップ (起動時防御)
# モジュール整合性検証より前に macOS メタデータを削除する
# これを怠ると status=failed で 11秒以内に落ちる (mayu9 端末 2026-05-19 事案)
# ============================================================
find "$SCRIPT_DIR" -name '._*' -delete 2>/dev/null || true
find "$SCRIPT_DIR" -name '.DS_Store' -delete 2>/dev/null || true

# カラー定義
readonly RED='\033[0;31m' GREEN='\033[0;32m' YELLOW='\033[0;33m'
readonly BLUE='\033[0;34m' PURPLE='\033[0;35m' CYAN='\033[0;36m'
readonly BOLD='\033[1m' DIM='\033[2m' NC='\033[0m'

# ============================================================
# v2008.5: --register-license / --set-server 特殊コマンド
# ============================================================
if [[ "${1:-}" == "--register-license" ]]; then
    local_key="${2:-}"
    if [[ -z "$local_key" ]]; then
        echo -e "${RED}エラー: ライセンスキーを指定してください${NC}" >&2
        echo -e "  使い方: ./setup.sh --register-license SLA-STD-CUSTOMER001-a1b2-20270331-abcd1234" >&2
        exit 1
    fi
    # license-guard.sh を読み込んでキー登録
    if [[ -f "${SCRIPT_DIR}/lib/license-guard.sh" ]]; then
        source "${SCRIPT_DIR}/lib/license-guard.sh"
        lg_register_license "$local_key"
        exit $?
    else
        echo -e "${RED}エラー: lib/license-guard.sh が見つかりません${NC}" >&2
        exit 1
    fi
fi

if [[ "${1:-}" == "--set-server" ]]; then
    local_url="${2:-}"
    if [[ -z "$local_url" ]]; then
        echo -e "${RED}エラー: サーバーURLを指定してください${NC}" >&2
        echo -e "  使い方: ./setup.sh --set-server https://admin.soloptilinkai.com" >&2
        exit 1
    fi
    if [[ -f "${SCRIPT_DIR}/lib/license-guard.sh" ]]; then
        source "${SCRIPT_DIR}/lib/license-guard.sh"
        lg_set_server_url "$local_url"
        exit $?
    else
        echo -e "${RED}エラー: lib/license-guard.sh が見つかりません${NC}" >&2
        exit 1
    fi
fi

if [[ "${1:-}" == "--machine-hash" ]]; then
    if [[ -f "${SCRIPT_DIR}/lib/license-guard.sh" ]]; then
        source "${SCRIPT_DIR}/lib/license-guard.sh"
        echo -e "${BOLD}この端末のマシンハッシュ:${NC}"
        echo -e "  ${CYAN}$(lg_get_machine_hash)${NC}"
        echo ""
        echo -e "  ${DIM}このハッシュを管理者に伝えてライセンスキーを発行してもらってください${NC}"
        exit 0
    else
        echo -e "${RED}エラー: lib/license-guard.sh が見つかりません${NC}" >&2
        exit 1
    fi
fi

# 結果トラッカー
declare -a CHECK_RESULTS=()
WARN_COUNT=0; FAIL_COUNT=0

_result_ok()   { CHECK_RESULTS+=("${GREEN}OK${NC}  $1"); }
_result_warn() { CHECK_RESULTS+=("${YELLOW}WARN${NC} $1"); WARN_COUNT=$((WARN_COUNT + 1)); }
_result_fail() { CHECK_RESULTS+=("${RED}FAIL${NC} $1"); FAIL_COUNT=$((FAIL_COUNT + 1)); }

# バナー
echo ""
echo -e "${BOLD}${PURPLE}"
echo "  ╔════════════════════════════════════════════════════════╗"
echo "  ║                                                        ║"
echo "  ║   SoloptiLink Chain v${VERSION} - iOS Native Support         ║"
echo "  ║   一言で完璧なシステムを自律構築する                  ║"
echo "  ║   32エージェント × 21層アーキテクチャ × iOS自動生成    ║"
echo "  ║                                                        ║"
echo "  ╚════════════════════════════════════════════════════════╝"
echo -e "${NC}"

# =============================================================================
# v29.1: macOS TCC 権限プリウォーム
# Python/Terminal権限ダイアログを一括で処理し、以降の重複を防止
# =============================================================================
if [[ "$(uname -s)" == "Darwin" ]]; then
    echo ""
    echo -e "${BOLD}macOS セキュリティ設定:${NC}"
    echo -e "  ${DIM}Python権限の確認中... 許可ダイアログが表示されたら「はい」を押してください${NC}"
    echo -e "  ${DIM}（この操作は初回のみです）${NC}"
    echo ""
    # TCC権限を一括取得: ファイルアクセス + ネットワーク + プロセス
    python3 -c "
import os, sys, subprocess
# ホームディレクトリアクセス（TCC: Files and Folders）
os.listdir(os.path.expanduser('~'))
# ドキュメントアクセス
docs = os.path.expanduser('~/Documents')
if os.path.exists(docs): os.listdir(docs)
# /tmp アクセス
os.listdir('/tmp')
print('OK')
" > /dev/null 2>&1 || true
    echo -e "  ${GREEN}✓${NC} Python権限の確認完了"
    echo ""
    echo -e "  ${YELLOW}ヒント:${NC} ターミナルに「フルディスクアクセス」を付与すると、"
    echo -e "  ${DIM}今後の権限ダイアログが表示されなくなります:${NC}"
    echo -e "  ${DIM}  → システム設定 → プライバシーとセキュリティ → フルディスクアクセス${NC}"
    echo -e "  ${DIM}  → Terminal.app（またはiTerm2）を追加${NC}"
    echo ""
fi

# [1/15] Claude Code CLI チェック
echo -e "${BOLD}[1/15] Claude Code CLI チェック...${NC}"
if command -v claude &>/dev/null; then
    claude_ver=$(claude --version 2>/dev/null || echo "installed")
    echo -e "  ${GREEN}OK${NC} Claude Code: ${claude_ver}"
    _result_ok "Claude Code CLI"
else
    echo -e "  ${YELLOW}WARN${NC} Claude Code CLI が見つかりません"
    echo -e "  ${DIM}  インストール: npm install -g @anthropic-ai/claude-code${NC}"
    _result_warn "Claude Code CLI (未インストール)"
fi

# [2/15] Python3 チェック
echo -e "${BOLD}[2/15] Python3 チェック...${NC}"
if command -v python3 &>/dev/null; then
    py_ver=$(python3 --version 2>&1 | awk '{print $2}')
    py_major=$(echo "$py_ver" | cut -d. -f1)
    py_minor=$(echo "$py_ver" | cut -d. -f2)
    if (( py_major >= 3 && py_minor >= 8 )); then
        echo -e "  ${GREEN}OK${NC} Python ${py_ver}"
        _result_ok "Python3 (${py_ver})"
    else
        echo -e "  ${YELLOW}WARN${NC} Python ${py_ver} (3.8+ 推奨)"
        _result_warn "Python3 (${py_ver}, 3.8+ 推奨)"
    fi
else
    echo -e "  ${YELLOW}WARN${NC} Python3 未検出 (RAGエンジンに必要)"
    echo -e "  ${DIM}  --no-rag モードで動作可能${NC}"
    _result_warn "Python3 (未インストール)"
fi

# [3/15] Git チェック
echo -e "${BOLD}[3/15] Git チェック...${NC}"
if command -v git &>/dev/null; then
    git_ver=$(git --version | head -1)
    echo -e "  ${GREEN}OK${NC} ${git_ver}"
    _result_ok "Git"
else
    echo -e "  ${RED}FAIL${NC} Git が見つかりません (必須)"
    _result_fail "Git (未インストール)"
fi

# [4/15] Bash バージョンチェック
echo -e "${BOLD}[4/15] Bash バージョンチェック...${NC}"
bash_ver="${BASH_VERSINFO[0]}.${BASH_VERSINFO[1]}"
if (( BASH_VERSINFO[0] >= 4 )); then
    echo -e "  ${GREEN}OK${NC} Bash ${bash_ver}"
    _result_ok "Bash (${bash_ver})"
else
    echo -e "  ${YELLOW}WARN${NC} Bash ${bash_ver} (4.0+ 推奨)"
    if [[ -x /opt/homebrew/bin/bash ]]; then
        hb_ver=$(/opt/homebrew/bin/bash --version | head -1 | grep -oE '[0-9]+\.[0-9]+' | head -1)
        echo -e "  ${CYAN}TIP${NC}  /opt/homebrew/bin/bash (${hb_ver}) が利用可能です"
        echo -e "  ${DIM}  /opt/homebrew/bin/bash ./chain.sh で実行してください${NC}"
    else
        echo -e "  ${DIM}  アップグレード: brew install bash${NC}"
    fi
    _result_warn "Bash (${bash_ver}, 4.0+ 推奨)"
fi

# [5/15] Node.js チェック
echo -e "${BOLD}[5/15] Node.js チェック...${NC}"
if command -v node &>/dev/null; then
    node_ver=$(node --version 2>/dev/null)
    echo -e "  ${GREEN}OK${NC} Node.js ${node_ver}"
    _result_ok "Node.js (${node_ver})"
else
    echo -e "  ${YELLOW}WARN${NC} Node.js 未検出 (Web開発プロジェクトで推奨)"
    _result_warn "Node.js (未インストール)"
fi
if command -v npm &>/dev/null; then
    npm_ver=$(npm --version 2>/dev/null)
    echo -e "  ${GREEN}OK${NC} npm ${npm_ver}"
    _result_ok "npm (${npm_ver})"
else
    echo -e "  ${YELLOW}WARN${NC} npm 未検出"
    _result_warn "npm (未インストール)"
fi

# [6/15] ディレクトリ構造の初期化
echo -e "${BOLD}[6/15] ディレクトリ構造の初期化...${NC}"
dirs_created=0
for dir in docs/knowledge docs/chain-logs docs/chain-logs/checkpoints \
    plugins/agents plugins/rules plugins/hooks plugins/templates plugins/pipelines; do
    if [[ ! -d "${SCRIPT_DIR}/${dir}" ]]; then
        mkdir -p "${SCRIPT_DIR}/${dir}"
        dirs_created=$((dirs_created + 1))
    fi
done
# グローバル設定ディレクトリ
for gdir in "${HOME}/.soloptilink/knowledge" "${HOME}/.soloptilink/memory" \
    "${HOME}/.soloptilink/templates"; do
    if [[ ! -d "$gdir" ]]; then
        mkdir -p "$gdir"
        dirs_created=$((dirs_created + 1))
    fi
done
if (( dirs_created > 0 )); then
    echo -e "  ${GREEN}OK${NC} ${dirs_created} ディレクトリ作成"
else
    echo -e "  ${GREEN}OK${NC} ディレクトリ構造は既存"
fi
_result_ok "ディレクトリ構造"

# [7/15] 実行権限の設定
echo -e "${BOLD}[7/15] 実行権限の設定...${NC}"
[[ -f "${SCRIPT_DIR}/chain.sh" ]] && chmod +x "${SCRIPT_DIR}/chain.sh"
[[ -f "${SCRIPT_DIR}/setup.sh" ]] && chmod +x "${SCRIPT_DIR}/setup.sh"
chmod +x "${SCRIPT_DIR}"/tools/*.py 2>/dev/null || true
chmod +x "${SCRIPT_DIR}"/lib/*.sh   2>/dev/null || true
chmod +x "${SCRIPT_DIR}"/lib/core/*.sh   2>/dev/null || true
chmod +x "${SCRIPT_DIR}"/lib/common/*.sh 2>/dev/null || true
chmod +x "${SCRIPT_DIR}"/tests/run_tests.sh 2>/dev/null || true
echo -e "  ${GREEN}OK${NC} chain.sh, setup.sh, tools/*.py, lib/**/*.sh, tests/run_tests.sh"
_result_ok "実行権限"

# [8/15] Git リポジトリ チェック
echo -e "${BOLD}[8/15] Git リポジトリ チェック...${NC}"
cd "${SCRIPT_DIR}"
if [[ ! -d ".git" ]]; then
    git init -q
    git add -A
    git commit -q -m "initial: SoloptiLink Chain v${VERSION} setup" --allow-empty
    echo -e "  ${GREEN}OK${NC} Git リポジトリを初期化しました"
    _result_ok "Git リポジトリ (新規初期化)"
else
    echo -e "  ${GREEN}OK${NC} Git リポジトリ既存"
    _result_ok "Git リポジトリ (既存)"
fi

# [9/15] RAG初期インデックス構築
echo -e "${BOLD}[9/15] RAG初期インデックス構築...${NC}"
if command -v python3 &>/dev/null && [[ -f "${SCRIPT_DIR}/tools/rag-engine.py" ]]; then
    if python3 "${SCRIPT_DIR}/tools/rag-engine.py" index 2>/dev/null; then
        echo -e "  ${GREEN}OK${NC} RAGインデックス構築完了"
        _result_ok "RAGインデックス"
    else
        echo -e "  ${YELLOW}WARN${NC} RAGインデックス構築スキップ (後で --rag-index で実行可能)"
        _result_warn "RAGインデックス"
    fi
else
    echo -e "  ${YELLOW}WARN${NC} Python3 または rag-engine.py 未検出 → RAG無効"
    _result_warn "RAGインデックス (スキップ)"
fi
if [[ -n "${DEEPSEEK_API_KEY:-}" ]]; then
    echo -e "  ${GREEN}OK${NC} DEEPSEEK_API_KEY: 設定済み (ベクトル検索有効)"
else
    echo -e "  ${DIM}  DEEPSEEK_API_KEY 未設定 → BM25フォールバック検索${NC}"
    echo -e "  ${DIM}  有効化: export DEEPSEEK_API_KEY=your_key${NC}"
fi

# [10/15] 21層アーキテクチャ全モジュール検証 (v51.0)
echo -e "${BOLD}[10/15] v51.0 21層アーキテクチャ全モジュール検証...${NC}"

# --- Layer 1: Common ユーティリティ ---
echo -e "  ${BOLD}[Layer 1] Common ユーティリティ:${NC}"
common_modules=(
    "common/colors.sh:カラー定義"
    "common/logger.sh:統一ログフレームワーク"
    "common/error-handler.sh:統一エラーハンドラー (v23.0)"
    "common/json-utils.sh:JSON処理ユーティリティ"
    "common/timeout-utils.sh:タイムアウトユーティリティ"
)
layer1_ok=0; layer1_fail=0
for entry in "${common_modules[@]}"; do
    IFS=':' read -r file label <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} ${label} (${file})"
        layer1_ok=$((layer1_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} ${label} (${file})"
        layer1_fail=$((layer1_fail + 1))
    fi
done

# --- Layer 2: Core インフラ ---
echo -e "  ${BOLD}[Layer 2] Core インフラ:${NC}"
core_modules=(
    "core/cli-parser.sh:CLI引数パーサー"
    "core/session.sh:セッション管理"
    "core/phase-executor.sh:フェーズ実行エンジン"
    "core/report.sh:レポートジェネレーター"
    "core/permissions.sh:権限管理"
    "core/layer-loader.sh:11層モジュールローダー"
    "core/config-validator.sh:設定バリデーター (v24.0)"
)
for entry in "${core_modules[@]}"; do
    IFS=':' read -r file label <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} ${label} (${file})"
        layer1_ok=$((layer1_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} ${label} (${file})"
        layer1_fail=$((layer1_fail + 1))
    fi
done
if (( layer1_fail == 0 )); then
    _result_ok "Layer 1-2: Common/Core (${layer1_ok}/${layer1_ok})"
else
    _result_warn "Layer 1-2: Common/Core (${layer1_ok}/$((layer1_ok + layer1_fail)))"
fi

# --- Layer 3: Observatory 可観測性 ---
echo -e "  ${BOLD}[Layer 3] Observatory 可観測性 (v14.0):${NC}"
obs_modules=(
    "observatory.sh:統合可観測性ダッシュボード:v14.0"
    "trace-propagator.sh:分散トレーシング:v14.0"
    "cost-engine.sh:コスト帰属エンジン:v15.0"
    "perf-baseline.sh:パフォーマンスベースライン:v14.0"
    "coverage-gate.sh:カバレッジゲート:v14.0"
    "file-writer-v3.sh:ファイルライターv3 (3-way merge):v14.0"
)
obs_ok=0; obs_fail=0
for entry in "${obs_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        obs_ok=$((obs_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        obs_fail=$((obs_fail + 1))
    fi
done
if (( obs_fail == 0 )); then
    _result_ok "Layer 3: Observatory (${obs_ok}/${obs_ok})"
else
    _result_warn "Layer 3: Observatory (${obs_ok}/$((obs_ok + obs_fail)))"
fi

# --- Layer 4: Feature エンジン ---
echo -e "  ${BOLD}[Layer 4] Feature エンジン (v7-v12):${NC}"
feat_modules=(
    "dag-pipeline.sh:DAG動的パイプライン:v7.0"
    "realtime-learn.sh:リアルタイム学習:v7.0"
    "url-analyzer.sh:URL解析エンジン:v8.0"
    "validator.sh:5層バリデーション:v8.0"
    "qa-engine.sh:網羅的QAエンジン:v8.0"
    "healer.sh:継続的自動修復:v8.0"
    "checkpoint.sh:チェックポイント管理:v8.0"
    "consultant-engine.sh:Consultant Engine (コンサル対話):v28.0"
    "prompt-expander.sh:スマートプロンプト展開:v9.0"
    "scaffolder.sh:プロジェクトスキャフォルダー:v9.0"
    "file-writer.sh:ファイルライターv1:v9.0"
    "file-writer-v2.sh:ファイルライターv2:v12.0"
    "parallel-exec.sh:並列実行エンジン:v10.0"
    "browser-test.sh:ブラウザテスト:v10.0"
    "auto-deploy.sh:自動デプロイ:v10.0"
    "security-guard.sh:Security Guard (OWASP):v11.0"
    "dep-audit.sh:依存関係セキュリティ監査:v11.0"
    "context-engine.sh:コンテキストエンジン:v12.0"
    "agent-orchestrator.sh:マルチエージェントオーケストレーター:v12.0"
    "agent-protocol.sh:エージェント間通信:v12.0"
    "knowledge-graph.sh:ナレッジグラフ:v12.0"
    "dev-server.sh:開発サーバー:v12.0"
    "build-verifier.sh:ビルド検証:v12.0"
    "env-manager.sh:.env管理:v12.0"
    "infra-provisioner.sh:インフラプロビジョニング:v12.0"
    "test-runner.sh:テストランナー:v12.0"
    "ui-engine.sh:UIエンジン:v12.0"
    "visual-review.sh:ビジュアルレビュー:v12.0"
    "prompt-optimizer.sh:プロンプト最適化:v12.0"
)
feat_ok=0; feat_fail=0
for entry in "${feat_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        feat_ok=$((feat_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        feat_fail=$((feat_fail + 1))
    fi
done
if (( feat_fail == 0 )); then
    _result_ok "Layer 4: Feature (${feat_ok}/${feat_ok})"
else
    _result_warn "Layer 4: Feature (${feat_ok}/$((feat_ok + feat_fail)))"
fi

# --- Layer 5: Runtime エージェント ---
echo -e "  ${BOLD}[Layer 5] Runtime エージェント (v15.0):${NC}"
rt_modules=(
    "agent-runtime.sh:エージェントランタイム:v15.0"
    "plugin-loader.sh:プラグインローダー:v15.0"
    "structured-output.sh:構造化出力:v15.0"
    "session-state.sh:セッション状態永続化:v15.0"
    "log-rotation.sh:ログローテーション:v15.0"
)
rt_ok=0; rt_fail=0
for entry in "${rt_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        rt_ok=$((rt_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        rt_fail=$((rt_fail + 1))
    fi
done
if (( rt_fail == 0 )); then
    _result_ok "Layer 5: Runtime (${rt_ok}/${rt_ok})"
else
    _result_warn "Layer 5: Runtime (${rt_ok}/$((rt_ok + rt_fail)))"
fi

# --- Layer 6: Intelligence 知的オーケストレーション ---
echo -e "  ${BOLD}[Layer 6] Intelligence 知的オーケストレーション (v16.0):${NC}"
intel_modules=(
    "planner-judge.sh:Planner-Worker-Judge:v16.0"
    "model-router.sh:モデルルーター (Opus/Sonnet/Haiku):v16.0"
    "memory-manager.sh:3層メモリマネージャ:v16.0"
    "context-budget.sh:コンテキスト予算管理:v16.0"
)
intel_ok=0; intel_fail=0
for entry in "${intel_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        intel_ok=$((intel_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        intel_fail=$((intel_fail + 1))
    fi
done
if (( intel_fail == 0 )); then
    _result_ok "Layer 6: Intelligence (${intel_ok}/${intel_ok})"
else
    _result_warn "Layer 6: Intelligence (${intel_ok}/$((intel_ok + intel_fail)))"
fi

# --- Layer 7: Enterprise 基幹基盤 ---
echo -e "  ${BOLD}[Layer 7] Enterprise 基幹基盤 (v17.0):${NC}"
ent_modules=(
    "data-integrity.sh:データ整合性エンジン:v17.0"
    "audit-logger.sh:監査ログエンジン:v17.0"
    "e2e-pipeline.sh:E2Eパイプライン:v17.0"
    "agent-scaler.sh:エージェントスケーラー (20体):v27.0"
)
ent_ok=0; ent_fail=0
for entry in "${ent_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        ent_ok=$((ent_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        ent_fail=$((ent_fail + 1))
    fi
done
if (( ent_fail == 0 )); then
    _result_ok "Layer 7: Enterprise (${ent_ok}/${ent_ok})"
else
    _result_warn "Layer 7: Enterprise (${ent_ok}/$((ent_ok + ent_fail)))"
fi

# --- Layer 8: Platform インテリジェントプラットフォーム ---
echo -e "  ${BOLD}[Layer 8] Platform インテリジェントプラットフォーム (v18.0):${NC}"
plat_modules=(
    "data-intelligence.sh:Data Intelligence Engine:v18.0"
    "saas-builder.sh:Multi-Tenant SaaS Builder:v18.0"
    "ai-integration.sh:AI Integration Layer:v18.0"
)
plat_ok=0; plat_fail=0
for entry in "${plat_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        plat_ok=$((plat_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        plat_fail=$((plat_fail + 1))
    fi
done
if (( plat_fail == 0 )); then
    _result_ok "Layer 8: Platform (${plat_ok}/${plat_ok})"
else
    _result_warn "Layer 8: Platform (${plat_ok}/$((plat_ok + plat_fail)))"
fi

# --- Layer 9: Automation Gateway ---
echo -e "  ${BOLD}[Layer 9] Automation Gateway (v19.0):${NC}"
gw_modules=(
    "workflow-engine.sh:ワークフローエンジン:v19.0"
    "cost-dashboard.sh:コストダッシュボード:v19.0"
    "template-registry.sh:テンプレートレジストリ:v19.0"
)
gw_ok=0; gw_fail=0
for entry in "${gw_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        gw_ok=$((gw_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        gw_fail=$((gw_fail + 1))
    fi
done
if (( gw_fail == 0 )); then
    _result_ok "Layer 9: Automation Gateway (${gw_ok}/${gw_ok})"
else
    _result_warn "Layer 9: Automation Gateway (${gw_ok}/$((gw_ok + gw_fail)))"
fi

# --- Layer 10: Quality Fortress 品質要塞 ---
echo -e "  ${BOLD}[Layer 10] Quality Fortress 品質要塞 (v20.0):${NC}"
qf_modules=(
    "quality-gate.sh:品質ゲート (6軸品質検証):v20.0"
    "functional-healer.sh:機能修復エンジン:v20.0"
    "smoke-test-runner.sh:スモークテストランナー:v20.0"
    "real-data-connector.sh:Real Data Connector:v20.0"
)
qf_ok=0; qf_fail=0
for entry in "${qf_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        qf_ok=$((qf_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        qf_fail=$((qf_fail + 1))
    fi
done
if (( qf_fail == 0 )); then
    _result_ok "Layer 10: Quality Fortress (${qf_ok}/${qf_ok})"
else
    _result_warn "Layer 10: Quality Fortress (${qf_ok}/$((qf_ok + qf_fail)))"
fi

# --- Layer 11: Adaptive Intelligence 適応型インテリジェンス ---
echo -e "  ${BOLD}[Layer 11] Adaptive Intelligence 適応型インテリジェンス (v25.0/v27.0):${NC}"
ai_modules=(
    "dependency-resolver.sh:Dependency Resolver (依存関係解決):v25.0"
    "performance-profiler.sh:Performance Profiler (パフォーマンス分析):v25.0"
    "api-contract-validator.sh:API Contract Validator (API契約検証):v25.0"
)
ai_ok=0; ai_fail=0
for entry in "${ai_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        ai_ok=$((ai_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        ai_fail=$((ai_fail + 1))
    fi
done
if (( ai_fail == 0 )); then
    _result_ok "Layer 11: Adaptive Intelligence (${ai_ok}/${ai_ok})"
else
    _result_warn "Layer 11: Adaptive Intelligence (${ai_ok}/$((ai_ok + ai_fail)))"
fi

# --- Layer 12: Deep Fix Engine (v26.0) ---
echo -e "  ${BOLD}[Layer 12] Deep Fix Engine - 20体多角的調査×協調実装 (v26.0):${NC}"
df_modules=(
    "deep-fix-engine.sh:Deep Fix Engine (20体多角的調査×協調実装×全方位検証):v27.0"
)
df_ok=0; df_fail=0
for entry in "${df_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        df_ok=$((df_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        df_fail=$((df_fail + 1))
    fi
done
if (( df_fail == 0 )); then
    _result_ok "Layer 12: Deep Fix Engine (${df_ok}/${df_ok})"
else
    _result_warn "Layer 12: Deep Fix Engine (${df_ok}/$((df_ok + df_fail)))"
fi

# --- Layer 13: Precision Prompt Engine (v27.0) ---
echo -e "  ${BOLD}[Layer 13] Precision Prompt Engine - ドメイン知識×設計図×プロンプト最適化 (v27.0):${NC}"
pp_modules=(
    "domain-knowledge.sh:Domain Knowledge Injector (10ドメインの業界標準モデル注入):v27.0"
    "blueprint-generator.sh:Blueprint Generator (ファイルパス×関数シグネチャ×ロジック手順):v27.0"
    "prompt-compiler.sh:Prompt Compiler (Domain Knowledge + Blueprint → 最適プロンプト):v27.0"
    "tech-stack-resolver.sh:Tech Stack Resolver (バージョン固定package.json/tsconfig/tailwind):v27.0"
)
pp_ok=0; pp_fail=0
for entry in "${pp_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        pp_ok=$((pp_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        pp_fail=$((pp_fail + 1))
    fi
done
if (( pp_fail == 0 )); then
    _result_ok "Layer 13: Precision Prompt Engine (${pp_ok}/${pp_ok})"
else
    _result_warn "Layer 13: Precision Prompt Engine (${pp_ok}/$((pp_ok + pp_fail)))"
fi

# --- Layer 14: Follow-up Intelligence (v28.0) ---
echo -e "  ${BOLD}[Layer 14] Follow-up Intelligence - 2回目以降の指示精度向上 (v28.0):${NC}"
fi_modules=(
    "followup-context.sh:Follow-up Context (プロジェクトGenome管理・リクエスト分類):v28.0"
    "code-scanner.sh:Code Scanner (プロジェクト構造スキャン・Genome生成):v28.0"
    "incremental-analyzer.sh:Incremental Analyzer (差分分析・変更計画生成):v28.0"
    "targeted-compiler.sh:Targeted Compiler (Follow-up用プロンプトコンパイル):v28.0"
    "delta-applier.sh:Delta Applier (差分適用・バックアップ・検証):v28.0"
)
fi_ok=0; fi_fail=0
for entry in "${fi_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        fi_ok=$((fi_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        fi_fail=$((fi_fail + 1))
    fi
done
if (( fi_fail == 0 )); then
    _result_ok "Layer 14: Follow-up Intelligence (${fi_ok}/${fi_ok})"
else
    _result_warn "Layer 14: Follow-up Intelligence (${fi_ok}/$((fi_ok + fi_fail)))"
fi

# --- Layer 15: Swarm Coordination (v30.0) ---
echo -e "  ${BOLD}[Layer 15] Swarm Coordination - 30体群知能協調×投票メカニズム (v30.0):${NC}"
sw_modules=(
    "swarm-coordinator.sh:Swarm Coordinator (群知能コーディネーター):v30.0"
    "voting-engine.sh:Voting Engine (投票エンジン):v30.0"
)
sw_ok=0; sw_fail=0
for entry in "${sw_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        sw_ok=$((sw_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        sw_fail=$((sw_fail + 1))
    fi
done
if (( sw_fail == 0 )); then
    _result_ok "Layer 15: Swarm Coordination (${sw_ok}/${sw_ok})"
else
    _result_warn "Layer 15: Swarm Coordination (${sw_ok}/$((sw_ok + sw_fail)))"
fi

# --- Layer 16: Autonomous Governance (v30.0) ---
echo -e "  ${BOLD}[Layer 16] Autonomous Governance - コード規約×技術的負債×一貫性検証 (v30.0):${NC}"
gov_modules=(
    "governance-engine.sh:Governance Engine (ガバナンスエンジン):v30.0"
)
gov_ok=0; gov_fail=0
for entry in "${gov_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        gov_ok=$((gov_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        gov_fail=$((gov_fail + 1))
    fi
done
if (( gov_fail == 0 )); then
    _result_ok "Layer 16: Autonomous Governance (${gov_ok}/${gov_ok})"
else
    _result_warn "Layer 16: Autonomous Governance (${gov_ok}/$((gov_ok + gov_fail)))"
fi

# --- Layer 17: Enterprise Forge (v31.0) ---
echo -e "  ${BOLD}[Layer 17] Enterprise Forge - コストゲート×エンプラパターン×コード検証 (v31.0):${NC}"
ef_modules=(
    "cost-gate.sh:Cost Gate (事前コスト見積もり・承認・予算管理):v31.0"
    "enterprise-patterns.sh:Enterprise Patterns (参照実装注入・テンプレート生成):v31.0"
    "code-validator.sh:Code Validator (書込前検証・アンチパターン・自動修正):v31.0"
)
ef_ok=0; ef_fail=0
for entry in "${ef_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        ef_ok=$((ef_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        ef_fail=$((ef_fail + 1))
    fi
done
if (( ef_fail == 0 )); then
    _result_ok "Layer 17: Enterprise Forge (${ef_ok}/${ef_ok})"
else
    _result_warn "Layer 17: Enterprise Forge (${ef_ok}/$((ef_ok + ef_fail)))"
fi

# --- Layer 18: Living System (v40.0) ---
echo -e "  ${BOLD}[Layer 18] Living System - 自己学習×最適化×統合知能 (v36.0-v40.0):${NC}"
ls_modules=(
    "smart-retry.sh:Smart Retry Engine (インテリジェントリトライ):v36.0"
    "prompt-memory.sh:Prompt Memory Engine (成功/失敗パターン記憶):v37.0"
    "phase-optimizer.sh:Phase Optimizer Engine (不要フェーズ自動スキップ):v38.0"
    "output-analyzer.sh:Output Analyzer Engine (Claude出力品質スコアリング):v39.0"
    "living-system.sh:Living System Engine (全学習データ統合知能):v40.0"
)
ls_ok=0; ls_fail=0
for entry in "${ls_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        ls_ok=$((ls_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        ls_fail=$((ls_fail + 1))
    fi
done
if (( ls_fail == 0 )); then
    _result_ok "Layer 18: Living System (${ls_ok}/${ls_ok})"
else
    _result_warn "Layer 18: Living System (${ls_ok}/$((ls_ok + ls_fail)))"
fi

# --- Layer 19: Unified Intelligence (v45.0) ---
echo -e "  ${BOLD}[Layer 19] Unified Intelligence - 統合知性 (v41.0-v45.0):${NC}"
ui_modules=(
    "dep-sync.sh:Dependency Sync Engine (依存関係リアルタイム同期):v41.0"
    "prompt-fusion.sh:Prompt Fusion Engine (最適プロンプト自動合成):v42.0"
    "health-monitor.sh:Health Monitor Engine (システムヘルス監視):v43.0"
    "cross-session.sh:Cross-Session Intelligence (セッション間学習横断分析):v44.0"
    "unified-dashboard.sh:Unified Dashboard Engine (統合ASCIIダッシュボード):v45.0"
)
ui_ok=0; ui_fail=0
for entry in "${ui_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        ui_ok=$((ui_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        ui_fail=$((ui_fail + 1))
    fi
done
if (( ui_fail == 0 )); then
    _result_ok "Layer 19: Unified Intelligence (${ui_ok}/${ui_ok})"
else
    _result_warn "Layer 19: Unified Intelligence (${ui_ok}/$((ui_ok + ui_fail)))"
fi

# --- Layer 20: Grand Unification (v50.0) ---
echo -e "  ${BOLD}[Layer 20] Grand Unification - 全統合 (v46.0-v50.0):${NC}"
gu_modules=(
    "scaffolder-v2.sh:Scaffolder v2 Engine (動的テンプレート選択):v46.0"
    "error-chain.sh:Error Chain Analysis Engine (エラー因果連鎖解析):v47.0"
    "agent-protocol-v2.sh:Agent Protocol v2 Engine (イベント駆動通信):v48.0"
    "self-tuning.sh:Self-Tuning Engine (全パラメータ自動チューニング):v49.0"
    "grand-unifier.sh:Grand Unifier Engine (全モジュール統合):v50.0"
)
gu_ok=0; gu_fail=0
for entry in "${gu_modules[@]}"; do
    IFS=':' read -r file label ver <<< "$entry"
    filepath="${SCRIPT_DIR}/lib/${file}"
    if [[ -f "$filepath" ]] && bash -n "$filepath" 2>/dev/null; then
        echo -e "    ${GREEN}OK${NC} [${ver}] ${label}"
        gu_ok=$((gu_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [${ver}] ${label}"
        gu_fail=$((gu_fail + 1))
    fi
done
if (( gu_fail == 0 )); then
    _result_ok "Layer 20: Grand Unification (${gu_ok}/${gu_ok})"
else
    _result_warn "Layer 20: Grand Unification (${gu_ok}/$((gu_ok + gu_fail)))"
fi

# --- Layer 21: iOS Native Support (v51.0) ---
echo -e "  ${BOLD}[Layer 21] iOS Native Support - iOSネイティブアプリ自動生成 (v51.0):${NC}"
echo -e "    ${DIM}(iOS対応はchain.sh/scaffolder/enterprise-patterns/quality-gate/code-validator内に統合)${NC}"
ios_checks=0; ios_ok=0
# iOS domain
if [[ -f "${SCRIPT_DIR}/domains/ios-app.json" ]]; then
    echo -e "    ${GREEN}OK${NC} [v51.0] ios-app ドメイン定義"
    ios_ok=$((ios_ok + 1))
else
    echo -e "    ${RED}FAIL${NC} [v51.0] ios-app ドメイン定義"
fi
ios_checks=$((ios_checks + 1))
# iOS agents
for agent_file in ios-dev.md mobile-architect.md; do
    if [[ -f "${SCRIPT_DIR}/.claude/agents/${agent_file}" ]]; then
        echo -e "    ${GREEN}OK${NC} [v51.0] ${agent_file}"
        ios_ok=$((ios_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} [v51.0] ${agent_file}"
    fi
    ios_checks=$((ios_checks + 1))
done
if (( ios_ok == ios_checks )); then
    _result_ok "Layer 21: iOS Native Support (${ios_ok}/${ios_checks})"
else
    _result_warn "Layer 21: iOS Native Support (${ios_ok}/${ios_checks})"
fi

# モジュール総計
total_ok=$((layer1_ok + obs_ok + feat_ok + rt_ok + intel_ok + ent_ok + plat_ok + gw_ok + qf_ok + ai_ok + df_ok + pp_ok + fi_ok + sw_ok + gov_ok + ef_ok + ls_ok + ui_ok + gu_ok + ios_ok))
total_fail=$((layer1_fail + obs_fail + feat_fail + rt_fail + intel_fail + ent_fail + plat_fail + gw_fail + qf_fail + ai_fail + df_fail + pp_fail + fi_fail + sw_fail + gov_fail + ef_fail + ls_fail + ui_fail + gu_fail + (ios_checks - ios_ok)))
total_all=$((total_ok + total_fail))
echo ""
echo -e "  ${BOLD}モジュール総計: ${total_ok}/${total_all} 正常${NC}"

# [11/15] 32エージェント定義検証 (v51.0)
echo -e "${BOLD}[11/15] 32エージェント定義検証...${NC}"
agents=(
    "pm.md:プロジェクトマネージャー"
    "backend-dev.md:バックエンド開発者"
    "frontend-dev.md:フロントエンド開発者"
    "designer.md:デザイナー"
    "qa-engineer.md:QAエンジニア"
    "devops.md:DevOpsエンジニア"
    "cost-optimizer.md:コスト最適化"
    "db-architect.md:DBアーキテクト"
    "security-auditor.md:セキュリティ監査員"
    "api-designer.md:API設計者"
    "test-architect.md:テストアーキテクト"
    "performance-engineer.md:パフォーマンスエンジニア"
    "documentation-writer.md:ドキュメントライター"
    "migration-engineer.md:マイグレーションエンジニア"
    "integration-engineer.md:インテグレーションエンジニア"
    "data-analyst.md:データアナリスト"
    "saas-architect.md:SaaSアーキテクト"
    "ai-engineer.md:AIエンジニア"
    "workflow-designer.md:ワークフローデザイナー"
    "dependency-manager.md:依存関係マネージャー (v25.0)"
    "follow-up-analyst.md:フォローアップアナリスト (v28.0)"
    "consultant.md:ITコンサルタント (v28.0)"
    "ux-researcher.md:UXリサーチャー (v30.0)"
    "i18n-engineer.md:国際化エンジニア (v30.0)"
    "cache-strategist.md:キャッシュ戦略家 (v30.0)"
    "accessibility-auditor.md:アクセシビリティ監査員 (v30.0)"
    "state-architect.md:状態管理アーキテクト (v30.0)"
    "error-recovery-agent.md:エラー回復エージェント (v30.0)"
    "swarm-coordinator.md:群知能コーディネーター (v30.0)"
    "governance-agent.md:ガバナンスエージェント (v30.0)"
    "ios-dev.md:iOS開発者 (v51.0)"
    "mobile-architect.md:モバイルアーキテクト (v51.0)"
)
agent_ok=0; agent_fail=0
for entry in "${agents[@]}"; do
    IFS=':' read -r file label <<< "$entry"
    filepath="${SCRIPT_DIR}/.claude/agents/${file}"
    if [[ -f "$filepath" ]]; then
        echo -e "    ${GREEN}OK${NC} ${label} (${file})"
        agent_ok=$((agent_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} ${label} (${file})"
        agent_fail=$((agent_fail + 1))
    fi
done
if (( agent_fail == 0 )); then
    echo -e "  ${GREEN}全 ${agent_ok} エージェント定義正常${NC}"
    _result_ok "32エージェント定義 (${agent_ok}/${agent_ok})"
else
    echo -e "  ${YELLOW}${agent_ok} 正常 / ${agent_fail} 未検出${NC}"
    _result_warn "エージェント定義 (${agent_ok}/$((agent_ok + agent_fail)))"
fi

# [12/15] v51.0 ドメイン知識ファイル検証
echo -e "${BOLD}[12/15] ドメイン知識ファイル検証 (v51.0 / 22ドメイン)...${NC}"
domain_files=(
    "_base.json:共通ベースモデル（User/Session/AuditLog）"
    "crm.json:CRM（顧客管理・商談・パイプライン）"
    "ecommerce.json:ECサイト（商品・カート・注文・決済）"
    "task-management.json:タスク管理（カンバン・プロジェクト）"
    "inventory.json:在庫管理（商品・入出庫・棚卸）"
    "hr.json:人事管理（従業員・勤怠・給与）"
    "accounting.json:会計管理（仕訳・請求・経費）"
    "blog.json:ブログ（記事・カテゴリ・タグ）"
    "chat.json:チャット（ルーム・メッセージ・リアルタイム）"
    "booking.json:予約管理（施設・予約・カレンダー）"
    "lms.json:学習管理（コース・レッスン・進捗）"
    "healthcare.json:医療管理 (v31.0)"
    "real-estate.json:不動産管理 (v31.0)"
    "restaurant.json:飲食店管理 (v31.0)"
    "project-management.json:プロジェクト管理 (v31.0)"
    "helpdesk.json:ヘルプデスク (v31.0)"
    "fitness.json:フィットネス (v31.0)"
    "survey.json:アンケート (v31.0)"
    "school.json:学校管理 (v31.0)"
    "event-management.json:イベント管理 (v31.0)"
    "analytics-dashboard.json:分析ダッシュボード (v31.0)"
    "ios-app.json:iOSアプリ (v51.0)"
)
domain_ok=0; domain_fail=0
for entry in "${domain_files[@]}"; do
    IFS=':' read -r file label <<< "$entry"
    filepath="${SCRIPT_DIR}/domains/${file}"
    if [[ -f "$filepath" ]]; then
        echo -e "    ${GREEN}OK${NC} ${label} (${file})"
        domain_ok=$((domain_ok + 1))
    else
        echo -e "    ${RED}FAIL${NC} ${label} (${file})"
        domain_fail=$((domain_fail + 1))
    fi
done
if (( domain_fail == 0 )); then
    echo -e "  ${GREEN}全 ${domain_ok} ドメインファイル正常${NC}"
    _result_ok "ドメイン知識 (${domain_ok}/${domain_ok})"
else
    echo -e "  ${YELLOW}${domain_ok} 正常 / ${domain_fail} 未検出${NC}"
    _result_warn "ドメイン知識 (${domain_ok}/$((domain_ok + domain_fail)))"
fi

# [13/15] ユニットテスト検証
echo -e "${BOLD}[13/15] ユニットテスト検証...${NC}"
test_files=(
    "test_v14_observatory.bats:Observatory:9"
    "test_v14_trace.bats:分散トレーシング:7"
    "test_v14_cost.bats:コスト帰属:7"
    "test_v14_coverage_gate.bats:カバレッジゲート:6"
    "test_v14_perf_baseline.bats:パフォーマンスベースライン:6"
    "test_v14_file_writer_v3.bats:ファイルライターv3:8"
    "test_v15_agent_runtime.bats:エージェントランタイム:10"
    "test_v15_plugin_loader.bats:プラグインローダー:8"
    "test_v15_structured_output.bats:構造化出力:7"
    "test_v15_session_state.bats:セッション状態:7"
    "test_v15_log_rotation.bats:ログローテーション:6"
    "test_v16_context_budget.bats:コンテキスト予算:14"
    "test_v16_memory_manager.bats:メモリマネージャ:14"
    "test_v16_model_router.bats:モデルルーター:18"
    "test_v16_planner_judge.bats:Planner-Judge:11"
    "test_v17_agent_scaler.bats:エージェントスケーラー:27"
    "test_v17_audit_logger.bats:監査ログ:19"
    "test_v17_data_integrity.bats:データ整合性:13"
    "test_v17_e2e_pipeline.bats:E2Eパイプライン:13"
    "test_v18_data_intelligence.bats:Data Intelligence:20"
    "test_v18_saas_builder.bats:SaaS Builder:22"
    "test_v18_ai_integration.bats:AI Integration:18"
    "test_v19_workflow_engine.bats:Workflow Engine:22"
    "test_v19_cost_dashboard.bats:Cost Dashboard:18"
    "test_v19_template_registry.bats:Template Registry:20"
    "test_v20_quality_gate.bats:Quality Gate:20"
    "test_v20_functional_healer.bats:Functional Healer:15"
    "test_v20_smoke_test_runner.bats:Smoke Test Runner:15"
    "test_v22_integration_weaver.bats:Integration Weaver (統合テスト):29"
    "test_v23_error_guardian.bats:Error Guardian (エラーハンドラー):28"
    "test_v24_config_validator.bats:Config Validator (設定検証):26"
    "test_v25_dependency_resolver.bats:Dependency Resolver (依存関係解決):20"
    "test_v25_performance_profiler.bats:Performance Profiler (パフォーマンス分析):18"
    "test_v25_api_contract_validator.bats:API Contract Validator (API契約検証):20"
    "test_v27_domain_knowledge.bats:Domain Knowledge Injector (ドメイン知識注入):20"
    "test_v27_blueprint_generator.bats:Blueprint Generator (設計図生成):15"
    "test_v27_prompt_compiler.bats:Prompt Compiler (プロンプトコンパイル):18"
    "test_v27_tech_stack_resolver.bats:Tech Stack Resolver (技術スタック解決):20"
    "test_v28_consultant_engine.bats:Consultant Engine (コンサル対話):22"
    "test_v30_swarm_coordinator.bats:Swarm Coordinator (群知能協調):25"
    "test_v30_voting_engine.bats:Voting Engine (投票メカニズム):20"
    "test_v30_governance_engine.bats:Governance Engine (ガバナンス検証):22"
    "test_v31_cost_gate.bats:Cost Gate (コストゲート):20"
    "test_v31_enterprise_patterns.bats:Enterprise Patterns (エンタープライズパターン):20"
    "test_v31_code_validator.bats:Code Validator (コードバリデーター):15"
    "test_v35_actually_connected.bats:Actually Connected (全部品実接続):15"
    "test_v40_living_system.bats:Living System (自己学習×統合知能):30"
    "test_v45_unified_intelligence.bats:Unified Intelligence (統合知性):37"
    "test_v50_grand_unification.bats:Grand Unification (全統合):40"
    "test_v51_ios_support.bats:iOS Native Support (iOSネイティブ):35"
)
test_ok=0; test_fail=0; total_tests=0
for entry in "${test_files[@]}"; do
    IFS=':' read -r file label count <<< "$entry"
    filepath="${SCRIPT_DIR}/tests/unit/${file}"
    if [[ -f "$filepath" ]]; then
        echo -e "    ${GREEN}OK${NC} ${label} (${count}件) - ${file}"
        test_ok=$((test_ok + 1))
        total_tests=$((total_tests + count))
    else
        echo -e "    ${RED}FAIL${NC} ${label} - ${file} 未検出"
        test_fail=$((test_fail + 1))
    fi
done
if (( test_fail == 0 )); then
    echo -e "  ${GREEN}全 ${test_ok} テストファイル (計${total_tests}件) 正常${NC}"
    _result_ok "ユニットテスト (${test_ok}ファイル / 計${total_tests}件)"
else
    echo -e "  ${YELLOW}${test_ok} 正常 / ${test_fail} 未検出${NC}"
    _result_warn "ユニットテスト (${test_ok}/$((test_ok + test_fail)))"
fi

# [14/15] セキュリティモジュール & オプショナルツール検証
echo -e "${BOLD}[14/15] セキュリティ & オプショナルツール検出...${NC}"
sec_tools_found=0; sec_tools_total=3
if command -v npm &>/dev/null; then
    echo -e "  ${GREEN}OK${NC} npm audit 利用可能"
    sec_tools_found=$((sec_tools_found + 1))
else
    echo -e "  ${YELLOW}WARN${NC} npm 未検出 → npm audit 無効"
fi
if command -v pip-audit &>/dev/null; then
    echo -e "  ${GREEN}OK${NC} pip-audit 利用可能"
    sec_tools_found=$((sec_tools_found + 1))
elif command -v safety &>/dev/null; then
    echo -e "  ${GREEN}OK${NC} safety 利用可能 (pip-audit の代替)"
    sec_tools_found=$((sec_tools_found + 1))
else
    echo -e "  ${YELLOW}WARN${NC} pip-audit / safety 未検出"
    echo -e "  ${DIM}  インストール: pip install pip-audit${NC}"
fi
if command -v npx &>/dev/null && npx playwright --version &>/dev/null 2>&1; then
    pw_ver=$(npx playwright --version 2>/dev/null || echo "installed")
    echo -e "  ${GREEN}OK${NC} Playwright ${pw_ver}"
    sec_tools_found=$((sec_tools_found + 1))
elif command -v playwright &>/dev/null; then
    pw_ver=$(playwright --version 2>/dev/null || echo "installed")
    echo -e "  ${GREEN}OK${NC} Playwright ${pw_ver}"
    sec_tools_found=$((sec_tools_found + 1))
else
    echo -e "  ${YELLOW}WARN${NC} Playwright 未検出 → ブラウザテストはcurlフォールバック"
    echo -e "  ${DIM}  インストール: npm install -g playwright && npx playwright install${NC}"
fi
if (( sec_tools_found == sec_tools_total )); then
    _result_ok "オプショナルツール (${sec_tools_found}/${sec_tools_total})"
else
    _result_warn "オプショナルツール (${sec_tools_found}/${sec_tools_total})"
fi

# [15/15] bats テストフレームワーク検出
echo -e "${BOLD}[15/15] テストフレームワーク検出...${NC}"
if command -v bats &>/dev/null; then
    bats_ver=$(bats --version 2>/dev/null || echo "installed")
    echo -e "  ${GREEN}OK${NC} bats ${bats_ver}"
    _result_ok "bats テストフレームワーク"
else
    echo -e "  ${YELLOW}WARN${NC} bats 未検出 → ユニットテスト実行不可"
    echo -e "  ${DIM}  インストール: brew install bats-core (macOS) / npm install -g bats${NC}"
    _result_warn "bats (未インストール)"
fi

# 最終サマリー
echo ""
echo -e "${BOLD}${PURPLE}╔════════════════════════════════════════════════════════════╗${NC}"
echo -e "${BOLD}${PURPLE}║     SoloptiLink Chain v${VERSION} - iOS Native Support             ║${NC}"
echo -e "${BOLD}${PURPLE}║                   Setup Result                              ║${NC}"
echo -e "${BOLD}${PURPLE}╠════════════════════════════════════════════════════════════╣${NC}"
for r in "${CHECK_RESULTS[@]}"; do
    printf "  ${PURPLE}║${NC} %-62b${PURPLE}║${NC}\n" "$r"
done
echo -e "${BOLD}${PURPLE}╠════════════════════════════════════════════════════════════╣${NC}"
if (( FAIL_COUNT == 0 && WARN_COUNT == 0 )); then
    echo -e "${BOLD}${PURPLE}║${NC}  ${GREEN}ALL CLEAR - v51.0 セットアップ完了${NC}                       ${PURPLE}║${NC}"
elif (( FAIL_COUNT == 0 )); then
    echo -e "${BOLD}${PURPLE}║${NC}  ${YELLOW}WARN x${WARN_COUNT} - 一部警告あり（動作可能）${NC}                   ${PURPLE}║${NC}"
else
    echo -e "${BOLD}${PURPLE}║${NC}  ${RED}FAIL x${FAIL_COUNT} / WARN x${WARN_COUNT} - 要確認${NC}                        ${PURPLE}║${NC}"
fi
echo -e "${BOLD}${PURPLE}╚════════════════════════════════════════════════════════════╝${NC}"
echo ""
echo -e "${BOLD}v51.0 使い方:${NC}"
echo ""
echo -e "  ${CYAN}# 一言で完璧構築 (メイン機能)${NC}"
echo -e "  ./chain.sh \"CRM作って\""
echo -e "  ./chain.sh \"家計簿アプリ作って\""
echo -e "  ./chain.sh \"タスク管理ツール\" --deploy"
echo ""
echo -e "  ${CYAN}# v51.0 iOS Native Support - iOSネイティブアプリ自動生成${NC}"
echo -e "  ./chain.sh \"家計簿iOSアプリ作って\"                              # iOS自動検出"
echo -e "  ./chain.sh \"タスク管理iOSアプリ\" --with-backend                 # iOS + APIサーバー"
echo -e "  ./chain.sh \"チャットiOSアプリ\" --uikit                          # UIKit指定"
echo ""
echo -e "  ${CYAN}# v31.0 Enterprise Forge - 基盤システム品質${NC}"
echo -e "  ./chain.sh \"SaaS ERP\" --auto-approve --hard-budget 10          # コストゲート+予算制限"
echo -e "  ./chain.sh \"CRM\" --cost-estimate-only                          # コスト見積もりのみ"
echo ""
echo -e "  ${CYAN}# v30.0 Swarm Autonomy - 32体群知能自律開発${NC}"
echo -e "  ./chain.sh \"SaaS CRM\" --swarm                                 # 群知能協調モード"
echo -e "  ./chain.sh \"SaaS\" --swarm --governance --deploy                # 群知能+ガバナンス"
echo ""
echo -e "  ${CYAN}# v20.0 Quality Fortress + v25.0 Adaptive Intelligence${NC}"
echo -e "  ./chain.sh \"SaaS CRM\" --quality-gate --smoke-test             # 品質ゲート+スモークテスト"
echo -e "  ./chain.sh \"SaaS\" --dep-resolve --perf-profile --api-contract  # 依存解決+性能+API検証"
echo ""
echo -e "  ${CYAN}# v18.0-v19.0 Intelligent Platform + Automation Gateway${NC}"
echo -e "  ./chain.sh \"CRM\" --data-file data.csv                          # CSVからスキーマ推論"
echo -e "  ./chain.sh \"SaaS\" --saas --billing                             # SaaS+課金"
echo -e "  ./chain.sh \"AIチャット\" --ai-integration --rag                  # AI統合+RAG"
echo ""
echo -e "  ${CYAN}# v51.0 全部盛り (32体群知能 + iOS + 全品質保証)${NC}"
echo -e "  ./chain.sh \"エンタープライズSaaS\" --swarm --governance --saas --ai-integration --quality-gate --smoke-test --deploy"
echo ""
echo -e "  ${CYAN}# セキュリティ・バリデーション${NC}"
echo -e "  ./chain.sh --security-scan ./myproject"
echo -e "  ./chain.sh --validate ./src --auto-fix"
echo ""
echo -e "  ${CYAN}# ヘルプ${NC}"
echo -e "  ./chain.sh --help"
echo ""
echo -e "${PURPLE}SoloptiLink Chain v${VERSION} iOS Native Support${NC} | ${DIM}32エージェント × 21層アーキテクチャ × iOSネイティブアプリ自動生成${NC}"
echo ""

# セットアップ完了マーカーを作成
if (( FAIL_COUNT == 0 )); then
    echo "v${VERSION} $(date '+%Y-%m-%d %H:%M:%S')" > "${SCRIPT_DIR}/.soloptilink_initialized" 2>/dev/null || true
fi

# ------------------------------------------------------------
# 自動更新フックの登録 (2026-06-15 野村Windows事案 恒久対策・鶏卵デッドロック解消)
# ------------------------------------------------------------
# 従来 setup.sh は自動更新フックを登録しなかったため、setup.sh 経由の導入では
# 自動更新が始まらなかった。ランチャーが配置済みなら導入時点で冪等登録する (保険経路)。
if [ -x "$HOME/.soloptilink/soloptilink" ]; then
    "$HOME/.soloptilink/soloptilink" --register-autoupdate-hook >/dev/null 2>&1 || true
elif [ -f "$HOME/.soloptilink/migration/v2027_hook_install.sh" ]; then
    bash "$HOME/.soloptilink/migration/v2027_hook_install.sh" >/dev/null 2>&1 || true
fi
