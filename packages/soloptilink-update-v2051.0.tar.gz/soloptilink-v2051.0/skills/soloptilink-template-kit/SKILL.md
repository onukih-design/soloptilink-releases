---
name: soloptilink-template-kit
description: "「テンプレ」「ひな形」「90%完成」「工事台帳」「物件管理」「介護記録」「レセプト」「学籍管理」「経費精算」「kit」等で起動。中小企業の基幹システム10種を90%完成テンプレで3分立ち上げする。"
argument-hint: "[--kit construction|manufacturing|real_estate|legal|care|medical|education|crm|order|expense] [--target-dir <dir>] [--list] [--describe <kit>] [--locale ja|en]"
allowed-tools: "Bash, Read, Write, Edit, Glob, Grep, Agent"
---

# SoloptiLinkAI v1.0 - Template Kit (90%完成スキャフォールドエンジン)

## 機能概要

SoloptiLinkAI v1.0 Template Kit - 日本の中小企業がよく作る基幹システム10種を「90%完成テンプレ」として3分でスキャフォールド。Claude Code が毎回フルスクラッチで生成するのに対し、本スキルは業種別の「あと10%だけカスタマイズすれば動く」プロジェクトを即座に立ち上げる。10種kit: 工事台帳/受発注台帳/物件管理/案件管理/介護記録/レセプト管理/学籍管理/顧客管理/受注管理/経費精算。「テンプレ」「スキャフォールド」「ひな形」「90%完成」「3分で立ち上げ」「工事台帳」「物件管理」「介護記録」「レセプト」「学籍管理」「受発注台帳」「案件管理」「顧客管理」「経費精算」「受注管理」「kit」「ベース作って」等で起動。営業現場で『これすぐ使えます』と言える瞬間を作る対 Claude Code 差別化スキル。

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

Claude Code が毎回フルスクラッチでコード生成するのに対して、本スキルは**日本の中小企業がよく作る基幹システム**を業種別 90% 完成テンプレとして即座に立ち上げる。3分後には `npm install && npm run dev` で動くプロジェクトが手に入る。営業現場で「これすぐ使えます」と言える瞬間を作る、対 Claude Code 差別化戦略の中核施策。

## 対 Claude Code 差別化

| 観点 | Claude Code | SoloptiLinkAI Template Kit |
|------|-------------|---------------------------|
| 業種知識 | 一般論 | ✅ 日本の業種辞書 (建設業法/宅建業法/介護保険法...) を埋め込み済み |
| 起動速度 | フルスクラッチ毎回数十分 | ✅ 3分で 30+ ファイル生成 |
| 法令適合 | 都度プロンプトで指示 | ✅ kit 設計時に法令ルール反映済 |
| 帳票テンプレ | 都度生成 | ✅ 工事日報/レセプト/ケアプラン等を最初から内蔵 |
| ダッシュボード KPI | 都度議論 | ✅ 業種別 KPI を最初から配線 |
| 残作業 | 全工程 | ✅ ロゴ/カラー/勘定科目連携先 等の 10% のみ |

## 利用可能な10種 Kit

| kit_id | 日本語名 | 業種 | 想定ユーザー |
|--------|---------|------|-------------|
| construction | 工事台帳キット | 建設業 | 工務店/建設会社 |
| manufacturing | 受発注台帳キット | 製造業 | 中小製造業/部品メーカー |
| real_estate | 物件管理キット | 不動産業 | 賃貸/売買仲介/管理会社 |
| legal | 案件管理キット | 士業 | 税理士/社労士/行政書士/弁護士事務所 |
| care | 介護記録キット | 介護 | 訪問介護/居宅介護支援/特養 |
| medical | レセプト管理キット | 医療 | 診療所/クリニック/薬局 |
| education | 学籍管理キット | 教育 | 学習塾/予備校/家庭教師 |
| crm | 顧客管理キット | B2B営業 | 中小SaaS/SIer/卸売 |
| order | 受注管理キット | 一般 | 小売/卸売/EC |
| expense | 経費精算キット | 一般 | バックオフィス共通 |

## コマンド

```bash
# 1. 全 kit を一覧
/soloptilink-template-kit --list

# 2. kit の詳細を見る
/soloptilink-template-kit --describe construction

# 3. 工事台帳キットを /tmp/my-app/ にスキャフォールド
/soloptilink-template-kit --kit construction --target-dir /tmp/my-app

# 4. 多言語化 (英語UI)
/soloptilink-template-kit --kit crm --target-dir /tmp/my-crm --locale en
```

## 各 kit に含まれるもの

```
my-app/
├── package.json                     # Next.js 15 + Prisma 5 + Tailwind v4 + shadcn/ui v2 + Auth.js v5 + zod
├── tsconfig.json
├── next.config.ts
├── tailwind.config.ts
├── postcss.config.mjs
├── prisma/
│   ├── schema.prisma                # kit の prisma_models から生成
│   └── seed.ts                      # サンプルデータ 3件以上
├── src/
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── page.tsx                 # ダッシュボード (業種別 KPI)
│   │   ├── (domain)/<resource>/page.tsx          # 一覧
│   │   ├── (domain)/<resource>/[id]/page.tsx     # 詳細
│   │   ├── (domain)/<resource>/new/page.tsx      # 新規作成
│   │   └── api/<resource>/route.ts               # CRUD API
│   ├── lib/
│   │   ├── db.ts                    # Prisma client
│   │   └── validators.ts            # zod
│   └── components/
│       └── ui/                      # shadcn/ui v2
├── docs/
│   └── DESIGN_CONTRACT.md           # 機能一覧/適用法令/残り10%
├── README.md                        # セットアップ手順
└── .env.example
```

## 出力規模 (例: 工事台帳キット)

- ファイル数: 30+
- 行数: ~4500
- セットアップ時間: 3分
- 完成度: 90% (残作業: ロゴ/カラー/勘定科目連携先)

## 内部アーキテクチャ

```
soloptilink-template-kit/
├── SKILL.md                       # 本ファイル
├── README.md                      # スキル概要
├── kits/                          # 10種 kit 設計図
│   ├── construction.json
│   ├── manufacturing.json
│   ├── real_estate.json
│   ├── legal.json
│   ├── care.json
│   ├── medical.json
│   ├── education.json
│   ├── crm.json
│   ├── order.json
│   └── expense.json
├── lib/
│   ├── kit_loader.ts              # JSON Schema 検証 + 一覧/詳細
│   ├── scaffolder.ts              # ディレクトリ生成エンジン
│   └── index.ts                   # 公開API: scaffoldKit()
├── schemas/
│   └── kit.schema.json            # KitDefinition の JSON Schema
├── examples/
│   ├── 01_construction_scaffold.ts
│   └── 02_list_kits.ts
└── tests/
    └── template_kit_check.mjs     # node:test (15+ ケース)
```

## ドメイン辞書連携

各 kit は `~/.claude/skills/soloptilink-japan/domains/` の業種辞書を参照:

| kit_id | 参照辞書 |
|--------|---------|
| construction | construction.json |
| manufacturing | manufacturing.json |
| real_estate | real_estate.json |
| legal | professional.json |
| care | healthcare.json + longterm_care |
| medical | healthcare.json + pharmacy.json |
| education | education.json |
| crm | retail.json (顧客管理参考) |
| order | retail.json + manufacturing.json |
| expense | hr.json (経費精算は人事労務領域) |

これにより、用語/必須フィールド/法令ルール/帳票テンプレが日本のリアルな業務に合致する。

## 実行例

```bash
# 工事台帳キットを生成
$ /soloptilink-template-kit --kit construction --target-dir /tmp/koji-daicho-app

✓ kit 読み込み: construction (建設業)
✓ ターゲット作成: /tmp/koji-daicho-app/
✓ package.json 書き出し
✓ Prisma スキーマ生成 (5 models: Project/Estimate/PurchaseOrder/Invoice/DailyReport)
✓ ダッシュボード生成 (KPI: 進行中工事/粗利率/キャッシュフロー/次回検査日)
✓ 一覧/詳細/新規ページ生成 (12 routes)
✓ API ルート生成 (28 routes)
✓ 帳票テンプレ生成 (工事日報/週報/月次出来高/見積書/注文書/請求書)
✓ DESIGN_CONTRACT.md 書き出し
✓ README.md 書き出し
✓ .env.example 書き出し

完了: 48 files, 4500 lines, 3 min setup
残り10%: ロゴ・カラー、勘定科目連携先(奉行/freee)、建設業許可番号
```

## セルフチェック

```bash
cd ~/.claude/skills/soloptilink-template-kit
node tests/template_kit_check.mjs
# 期待: 全 15+ ケース PASS
```

## 認証

```bash
SOLOPTILINK_BIN=""
if [ -f ~/.soloptilink/soloptilink ]; then SOLOPTILINK_BIN="./soloptilink"
elif [ -f ~/.soloptilink/soloptilink.exe ]; then SOLOPTILINK_BIN="./soloptilink.exe"
fi
AUTH_CHECK=$(cd ~/.soloptilink 2>/dev/null && ${SOLOPTILINK_BIN:-./soloptilink} --status 2>&1)
if echo "$AUTH_CHECK" | grep -q "承認済み"; then
  echo "AUTHORIZED"
else
  echo "UNAUTHORIZED"
fi
```
