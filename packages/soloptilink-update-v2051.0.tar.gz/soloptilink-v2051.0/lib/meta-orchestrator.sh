#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v130.0 - Meta Orchestrator (Intelligence Engine)
# =============================================================================
# v100.0: keyword grepベースの推薦
# v130.0: 構造的解析ベースの智能モジュール選択
#
# プロジェクトの実際の構造（package.json, schema, ファイル構成）を解析し、
# 必要なモジュールを選択的に有効化する。
# =============================================================================
[[ -n "${_MO_LOADED:-}" ]] && return 0; _MO_LOADED=1

MO_VERSION="130.0"
MO_GENERATED=0
MO_ERRORS=0
MO_ACTIVATED_MODULES=()
MO_PHASE="meta_orchestrate"

mo_init() {
    MO_GENERATED=0
    MO_ERRORS=0
    MO_ACTIVATED_MODULES=()
    return 0
}

# =============================================================================
# v130.0: 構造的プロジェクト解析
# keyword grepではなく、実際のファイル構造と依存関係を解析
# =============================================================================
mo_analyze_project() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local recommendations=()

    # v173: Structural project analysis (not keyword grep)

    # 1. Database detection
    [[ -f "$project_dir/prisma/schema.prisma" ]] && {
        recommendations+=("migration-engine" "data-seed-gen" "backup-recovery")
        # Check model count for complexity
        local model_count
        model_count=$(grep -c "^model " "$project_dir/prisma/schema.prisma" 2>/dev/null || echo "0")
        [[ "$model_count" -gt 5 ]] && recommendations+=("type-safety-enforcer")
        # Userモデルあり → auth系推奨
        grep -q "^model User" "$project_dir/prisma/schema.prisma" 2>/dev/null && recommendations+=("auth-scaffold")
        # @@index多数 → monitoring推奨
        local index_count
        index_count=$(grep -c "@@index" "$project_dir/prisma/schema.prisma" 2>/dev/null || echo "0")
        [[ "$index_count" -ge 3 ]] && recommendations+=("monitoring-setup")
    }

    # 2. Auth detection
    [[ -d "$project_dir/app/api/auth" || -d "$project_dir/src/app/api/auth" ]] && {
        recommendations+=("auth-scaffold" "rate-limiter-gen")
    }
    grep -rql "JWT\|jsonwebtoken\|bcrypt\|next-auth" "$project_dir/package.json" 2>/dev/null && {
        recommendations+=("auth-scaffold")
    }

    # 3. File structure analysis
    local tsx_count
    tsx_count=$(find "$project_dir/app" "$project_dir/src" -name "*.tsx" 2>/dev/null | wc -l | tr -d ' ')
    [[ "${tsx_count:-0}" -gt 10 ]] && recommendations+=("i18n-engine" "doc-generator")

    # 4. API route detection
    local api_count
    api_count=$(find "$project_dir/app/api" "$project_dir/src/app/api" -name "route.ts" 2>/dev/null | wc -l | tr -d ' ')
    [[ "${api_count:-0}" -gt 5 ]] && recommendations+=("api-versioning" "monitoring-setup" "cache-strategy")

    # 5. Real-time detection
    grep -rql "socket\|Socket\|ws\|WebSocket\|SSE\|EventSource" "$project_dir/package.json" "$project_dir/src" "$project_dir/app" 2>/dev/null && {
        recommendations+=("realtime-sync" "notification-engine")
    }

    # 6. Payment/SaaS detection
    [[ -d "$project_dir/app/api/webhook" || -d "$project_dir/app/api/stripe" ]] && {
        recommendations+=("webhook-engine" "multi-tenant-engine")
    }
    grep -rql '"stripe"\|"@stripe/"' "$project_dir/package.json" 2>/dev/null && {
        recommendations+=("saas-builder")
    }

    # 7. CI/CD detection
    [[ ! -d "$project_dir/.github" ]] && recommendations+=("cicd-generator")
    [[ ! -f "$project_dir/Dockerfile" ]] && recommendations+=("cicd-generator")

    # 8. Upload detection
    grep -rql "upload\|multer\|formidable\|sharp" "$project_dir/package.json" 2>/dev/null && {
        recommendations+=("file-upload-engine")
    }

    # 9. Email/Notification detection
    grep -rql '"nodemailer"\|"resend"\|"@sendgrid/"' "$project_dir/package.json" 2>/dev/null && {
        recommendations+=("notification-engine")
    }

    # 10. Cache detection
    grep -rql '"redis"\|"ioredis"' "$project_dir/package.json" 2>/dev/null && {
        recommendations+=("cache-strategy")
    }

    # Deduplicate
    local unique_recs
    if [[ ${#recommendations[@]} -gt 0 ]]; then
        unique_recs=$(printf '%s\n' "${recommendations[@]}" | sort -u)
    else
        unique_recs=""
    fi
    MO_RECOMMENDATIONS=()
    while IFS= read -r rec; do
        [[ -n "$rec" ]] && MO_RECOMMENDATIONS+=("$rec")
    done <<< "$unique_recs"

    echo -e "  [v173] Meta Orchestrator構造解析: ${#MO_RECOMMENDATIONS[@]}モジュール推奨" >&2
    echo "$unique_recs"
}

# =============================================================================
# v130.0: 智能モジュール有効化
# =============================================================================
mo_activate_modules() {
    local modules="$1"
    for mod in $modules; do
        local upper
        upper=$(echo "$mod" | tr '[:lower:]-' '[:upper:]_')
        eval "ENABLE_${upper}=true" 2>/dev/null || true
        MO_ACTIVATED_MODULES+=("$mod")
    done
}

# =============================================================================
# v130.0: メインオーケストレーション
# Claude呼出しではなく、構造解析→モジュール選択→有効化
# =============================================================================
mo_orchestrate() {
    local project_dir="${PROJECT_DIR:-./output}"
    local domain="${DOMAIN_TYPE:-general}"

    echo -e "  ${CYAN:-\033[0;36m}[MO v130.0] 智能モジュール選択開始${NC:-\033[0m}" >&2

    # 1. プロジェクト構造解析
    local recommended_modules
    recommended_modules=$(mo_analyze_project)

    # 2. ドメイン固有の追加推薦
    case "$domain" in
        crm|sales)
            recommended_modules+=$'\n'"notification-engine"
            recommended_modules+=$'\n'"analytics-tracker"
            ;;
        ec|ecommerce|shop)
            recommended_modules+=$'\n'"cache-strategy"
            recommended_modules+=$'\n'"search-engine-setup"
            ;;
        saas|multi-tenant)
            recommended_modules+=$'\n'"multi-tenant-engine"
            recommended_modules+=$'\n'"saas-builder"
            ;;
        chat|messaging)
            recommended_modules+=$'\n'"realtime-sync"
            recommended_modules+=$'\n'"notification-engine"
            ;;
    esac

    # v2003.1: Layer 30 Domain Intelligence - 業界テンプレート+日本業務パターン
    # 日本語タスクは常に日本業務パターンを有効化
    if type -t _jbp_generate_all &>/dev/null; then
        recommended_modules+=$'\n'"japanese-business-patterns"
    fi

    # ドメイン別業界テンプレート
    case "$domain" in
        saas) type -t _its_generate_saas &>/dev/null && recommended_modules+=$'\n'"industry-template-saas" ;;
        ec|ecommerce) type -t _ite_generate_ec &>/dev/null && recommended_modules+=$'\n'"industry-template-ec" ;;
        medical|healthcare) recommended_modules+=$'\n'"industry-template-medical" ;;
        education) recommended_modules+=$'\n'"industry-template-education" ;;
        finance) recommended_modules+=$'\n'"industry-template-finance" ;;
        realestate) recommended_modules+=$'\n'"industry-template-realestate" ;;
        restaurant|food) recommended_modules+=$'\n'"industry-template-restaurant" ;;
    esac

    # 3. 重複除去 + 有効化
    local unique_modules
    unique_modules=$(echo "$recommended_modules" | sort -u | grep -v '^$')
    local count=0
    while IFS= read -r mod; do
        [[ -z "$mod" ]] && continue
        count=$((count + 1))
    done <<< "$unique_modules"

    if [[ $count -gt 0 ]]; then
        echo -e "  ${CYAN:-\033[0;36m}[MO] ${count}モジュールを有効化:${NC:-\033[0m}" >&2
        while IFS= read -r mod; do
            [[ -z "$mod" ]] && continue
            local upper
            upper=$(echo "$mod" | tr '[:lower:]-' '[:upper:]_')
            eval "ENABLE_${upper}=true" 2>/dev/null || true
            MO_ACTIVATED_MODULES+=("$mod")
            echo -e "    ✓ ${mod}" >&2
        done <<< "$unique_modules"
        MO_GENERATED=$count
    else
        echo -e "  ${CYAN:-\033[0;36m}[MO] 追加モジュール推薦なし（基本構成で十分）${NC:-\033[0m}" >&2
    fi

    # 4. Voting Engine / Swarm Coordinator の初期化
    if type -t vt_init &>/dev/null && [[ "${VT_ENABLED:-true}" == "true" ]]; then
        vt_init "${SESSION_ID:-mo_session}" 2>/dev/null || true
    fi
    if type -t sw_init &>/dev/null; then
        sw_init "${SESSION_ID:-mo_session}" 2>/dev/null || true
    fi

    # v2003.1: 活性化モジュールの実行フック
    # ENABLE_XXX=trueをセットするだけでなく、実際のscaffold/generate関数を呼ぶ
    mo_execute_activated "$project_dir" 2>/dev/null || true

    return 0
}

# =============================================================================
# v2003.1: 活性化モジュールの実行
# mo_activate_modulesでENABLE_XXX=trueにしたモジュールの
# scaffold/generate関数を実際に呼び出す
# =============================================================================
mo_execute_activated() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    [[ ${#MO_ACTIVATED_MODULES[@]} -eq 0 ]] && return 0

    echo -e "  ${CYAN:-\033[0;36m}[MO v2003.1] 活性化モジュール実行開始${NC:-\033[0m}" >&2

    for mod in "${MO_ACTIVATED_MODULES[@]}"; do
        case "$mod" in
            auth-scaffold)
                if type -t as_scaffold_auth &>/dev/null; then
                    echo -e "    🔐 認証基盤をスキャフォルド中..." >&2
                    as_scaffold_auth "$project_dir" 2>/dev/null || true
                fi
                ;;
            cache-strategy)
                if type -t cache_scaffold &>/dev/null; then
                    echo -e "    ⚡ キャッシュ戦略を適用中..." >&2
                    cache_scaffold "$project_dir" 2>/dev/null || true
                fi
                ;;
            monitoring-setup)
                if type -t mon_scaffold &>/dev/null; then
                    echo -e "    📊 監視基盤をセットアップ中..." >&2
                    mon_scaffold "$project_dir" 2>/dev/null || true
                fi
                ;;
            notification-engine)
                if type -t ne_scaffold &>/dev/null; then
                    echo -e "    🔔 通知基盤をセットアップ中..." >&2
                    ne_scaffold "$project_dir" 2>/dev/null || true
                fi
                ;;
            search-engine-setup)
                if type -t ses_scaffold &>/dev/null; then
                    echo -e "    🔍 検索基盤をセットアップ中..." >&2
                    ses_scaffold "$project_dir" 2>/dev/null || true
                fi
                ;;
            migration-engine)
                if type -t mig_scaffold &>/dev/null; then
                    echo -e "    🗄️ マイグレーション基盤をセットアップ中..." >&2
                    mig_scaffold "$project_dir" 2>/dev/null || true
                fi
                ;;
            multi-tenant-engine)
                if type -t mt_scaffold &>/dev/null; then
                    echo -e "    🏢 マルチテナント基盤を適用中..." >&2
                    mt_scaffold "$project_dir" 2>/dev/null || true
                fi
                ;;
            realtime-sync)
                if type -t rs_scaffold &>/dev/null; then
                    echo -e "    📡 リアルタイム基盤を適用中..." >&2
                    rs_scaffold "$project_dir" 2>/dev/null || true
                fi
                ;;
            analytics-tracker)
                if type -t at_scaffold &>/dev/null; then
                    echo -e "    📈 アナリティクス基盤を適用中..." >&2
                    at_scaffold "$project_dir" 2>/dev/null || true
                fi
                ;;
            # v2003.1: Layer 28 Multi-System Architecture モジュール群
            admin-panel|admin-panel-generator)
                if type -t _apg_generate_panel &>/dev/null; then
                    echo -e "    🏗️ 管理パネルを生成中..." >&2
                    _apg_generate_panel "$project_dir" 2>/dev/null || true
                fi
                ;;
            ecommerce|ecommerce-engine)
                if type -t _ee_generate_storefront &>/dev/null; then
                    echo -e "    🛒 EC基盤を生成中..." >&2
                    _ee_generate_storefront "$project_dir" 2>/dev/null || true
                fi
                ;;
            crm|crm-generator)
                if type -t _crm_generate_core &>/dev/null; then
                    echo -e "    👥 CRM基盤を生成中..." >&2
                    _crm_generate_core "$project_dir" 2>/dev/null || true
                fi
                ;;
            chat-system|chat-system-generator)
                if type -t _chsg_generate_core &>/dev/null; then
                    echo -e "    💬 チャット基盤を生成中..." >&2
                    _chsg_generate_core "$project_dir" 2>/dev/null || true
                fi
                ;;
            payment|payment-integration)
                if type -t pi_generate_stripe &>/dev/null; then
                    echo -e "    💳 決済基盤を生成中..." >&2
                    pi_generate_stripe "$project_dir" 2>/dev/null || true
                fi
                ;;
            hr-system|hr-system-generator)
                if type -t _hsg_generate_core &>/dev/null; then
                    echo -e "    👔 HR基盤を生成中..." >&2
                    _hsg_generate_core "$project_dir" 2>/dev/null || true
                fi
                ;;
            inventory|inventory-system-generator)
                if type -t _isg_generate_core &>/dev/null; then
                    echo -e "    📦 在庫管理基盤を生成中..." >&2
                    _isg_generate_core "$project_dir" 2>/dev/null || true
                fi
                ;;
            accounting|accounting-system-generator)
                if type -t _asg_generate_core &>/dev/null; then
                    echo -e "    📊 会計基盤を生成中..." >&2
                    _asg_generate_core "$project_dir" 2>/dev/null || true
                fi
                ;;
            reservation|reservation-system-generator)
                if type -t _rsg_generate_core &>/dev/null; then
                    echo -e "    📅 予約基盤を生成中..." >&2
                    _rsg_generate_core "$project_dir" 2>/dev/null || true
                fi
                ;;
            lp|lp-marketing-generator)
                if type -t _lmg_generate_lp &>/dev/null; then
                    echo -e "    🎯 LP基盤を生成中..." >&2
                    _lmg_generate_lp "$project_dir" 2>/dev/null || true
                fi
                ;;
            *)
                # 汎用: xxx_scaffold() が存在すれば呼ぶ
                local func_name="${mod//-/_}_scaffold"
                if type -t "$func_name" &>/dev/null; then
                    echo -e "    ⚙️ ${mod} をスキャフォルド中..." >&2
                    "$func_name" "$project_dir" 2>/dev/null || true
                fi
                ;;
        esac
    done

    echo -e "  ${GREEN:-\033[0;32m}[MO v2003.1] ${#MO_ACTIVATED_MODULES[@]}モジュールの実行完了${NC:-\033[0m}" >&2
}

# =============================================================================
# レポート
# =============================================================================
mo_report() {
    echo -e "\n  ${BOLD:-}=== Meta Orchestrator v${MO_VERSION} ===${NC:-}"
    echo -e "  有効化モジュール数: ${MO_GENERATED}"
    if [[ ${#MO_ACTIVATED_MODULES[@]} -gt 0 ]]; then
        echo -e "  有効化リスト: ${MO_ACTIVATED_MODULES[*]}"
    fi
    echo -e "  エラー: ${MO_ERRORS}"
}

mo_report_json() {
    local mods_json="["
    local first=true
    for mod in "${MO_ACTIVATED_MODULES[@]}"; do
        [[ "$first" != "true" ]] && mods_json+=","
        mods_json+="\"$mod\""
        first=false
    done
    mods_json+="]"
    cat <<EOF
{"module":"meta-orchestrator","version":"${MO_VERSION}","activated":${MO_GENERATED},"modules":${mods_json},"errors":${MO_ERRORS}}
EOF
}

mo_score() {
    if [[ ${MO_GENERATED} -gt 0 ]] && [[ ${MO_ERRORS} -eq 0 ]]; then
        echo "90"
    elif [[ ${MO_GENERATED} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# v59.0: Module Registry 自己登録
if type -t _mr_register &>/dev/null; then
    _mr_register --name "meta-orchestrator" --version "130.0" \
        --description "智能モジュール選択×構造解析ベース有効化" \
        --init "mo_init" --report "mo_report" --score "mo_score" \
        --enable-var "ENABLE_META_ORCHESTRATOR" --cli-flags "--meta-orchestrator:--no-meta-orchestrator"
fi

# v2003.1: source時のexit codeを確実に0にする
true
