#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v31.0 - Domain Knowledge Injector
# =============================================================================
# ドメインごとの業界標準データモデル・機能・UIパターン・ビジネスルールを
# Claudeプロンプトに注入し、一発出し精度を飛躍的に向上させる。
#
# 機能:
#   - ドメイン自動判定（キーワードマッチング + Claude分類）
#   - ドメイン知識JSON読み込み・解析
#   - Prismaスキーマ自動生成（ドメインモデル → schema.prisma）
#   - APIエンドポイント仕様生成
#   - UIページ構成仕様生成
#   - ビジネスルール注入テキスト生成
#   - ベースモデル（User, Session, AuditLog）との自動マージ
#
# 依存: common/json-utils.sh (オプション)
# =============================================================================

[[ -n "${_DOMAIN_KNOWLEDGE_LOADED:-}" ]] && return 0
_DOMAIN_KNOWLEDGE_LOADED=1

# =============================================================================
# 設定
# =============================================================================
DK_VERSION="31.0"

# v31.0: コンプライアンスディレクトリ
DK_COMPLIANCE_DIR=""  # 初期化時に設定
DK_DOMAINS_DIR="${SCRIPT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/domains"
DK_WORK_DIR="${HOME}/.soloptilink/domain-knowledge"

# 出力変数（他モジュールから参照）
DK_DETECTED_DOMAIN=""
DK_PRISMA_SCHEMA=""
DK_API_SPEC=""
DK_PAGE_SPEC=""
DK_BUSINESS_RULES=""
DK_MODELS_SUMMARY=""
DK_ENUMS_BLOCK=""
DK_SEED_DATA=""

# カラー
DK_GREEN='\033[0;32m'
DK_YELLOW='\033[0;33m'
DK_RED='\033[0;31m'
DK_BLUE='\033[0;34m'
DK_CYAN='\033[0;36m'
DK_BOLD='\033[1m'
DK_DIM='\033[2m'
DK_NC='\033[0m'

# =============================================================================
# 初期化
# =============================================================================
dk_init() {
    mkdir -p "${DK_WORK_DIR}" 2>/dev/null || true
    if [[ ! -d "${DK_DOMAINS_DIR}" ]]; then
        echo -e "  ${DK_YELLOW}WARN${DK_NC} ドメイン知識ディレクトリ未検出: ${DK_DOMAINS_DIR}"
        return 1
    fi
    # v31.0: コンプライアンスディレクトリ設定
    DK_COMPLIANCE_DIR="${DK_DOMAINS_DIR}/_compliance"
    local count compliance_count=0
    count=$(find "${DK_DOMAINS_DIR}" -maxdepth 1 -name "*.json" -not -name "_base.json" | wc -l | tr -d ' ')
    if [[ -d "${DK_COMPLIANCE_DIR}" ]]; then
        compliance_count=$(find "${DK_COMPLIANCE_DIR}" -name "*.json" 2>/dev/null | wc -l | tr -d ' ')
    fi
    echo -e "  ${DK_GREEN}OK${DK_NC} Domain Knowledge Injector v${DK_VERSION} (${count} ドメイン, ${compliance_count} コンプライアンス)"
    return 0
}

# =============================================================================
# ログ
# =============================================================================
_dk_log() {
    local level="$1" msg="$2"
    local color="${DK_NC}"
    case "$level" in
        INFO)  color="${DK_GREEN}" ;;
        WARN)  color="${DK_YELLOW}" ;;
        ERROR) color="${DK_RED}" ;;
        DEBUG) color="${DK_DIM}" ;;
    esac
    echo -e "  ${color}[DK/${level}]${DK_NC} ${msg}" >&2
}

# =============================================================================
# ドメイン一覧取得
# =============================================================================
dk_list_domains() {
    local domains_dir="${DK_DOMAINS_DIR}"
    if [[ ! -d "$domains_dir" ]]; then
        echo ""
        return 1
    fi
    local domains=()
    local f
    for f in "${domains_dir}"/*.json; do
        [[ ! -f "$f" ]] && continue
        local basename
        basename=$(basename "$f" .json)
        [[ "$basename" == "_base" ]] && continue
        domains+=("$basename")
    done
    echo "${domains[*]}"
}

# =============================================================================
# ドメイン自動判定
# =============================================================================
# ユーザー入力（タスク記述）からドメインを判定する。
# キーワードマッチングで高速判定。マッチしない場合はgenericを返す。
# =============================================================================
dk_detect_domain() {
    local task_desc="$1"
    local task_lower
    task_lower=$(echo "$task_desc" | tr '[:upper:]' '[:lower:]')

    # 各ドメインJSONのkeywordsフィールドとマッチング
    local best_domain="generic"
    local best_score=0

    local f
    for f in "${DK_DOMAINS_DIR}"/*.json; do
        [[ ! -f "$f" ]] && continue
        local basename
        basename=$(basename "$f" .json)
        [[ "$basename" == "_base" ]] && continue

        # keywordsを抽出（簡易パーサー: "keywords": [...] の中身）
        local keywords_line
        keywords_line=$(grep -o '"keywords"[[:space:]]*:[[:space:]]*\[.*\]' "$f" 2>/dev/null | head -1)
        if [[ -z "$keywords_line" ]]; then
            continue
        fi

        # キーワードを個別に抽出してマッチング
        local score=0
        local kw
        while IFS= read -r kw; do
            kw=$(echo "$kw" | tr -d '"' | tr -d ' ')
            [[ -z "$kw" ]] && continue
            if echo "$task_lower" | grep -qi "$kw" 2>/dev/null; then
                score=$((score + 1))
            fi
        done < <(echo "$keywords_line" | grep -oE '"[^"]*"' | tr -d '"')

        if (( score > best_score )); then
            best_score=$score
            best_domain="$basename"
        fi
    done

    DK_DETECTED_DOMAIN="$best_domain"
    if (( best_score > 0 )); then
        _dk_log "INFO" "ドメイン判定: ${DK_BOLD}${best_domain}${DK_NC} (スコア: ${best_score})"
    else
        _dk_log "WARN" "ドメイン判定: generic（キーワードマッチなし）"
    fi
    echo "$best_domain"
}

# =============================================================================
# ドメインJSON読み込み
# =============================================================================
_dk_read_domain_json() {
    local domain="$1"
    local json_path="${DK_DOMAINS_DIR}/${domain}.json"
    if [[ ! -f "$json_path" ]]; then
        _dk_log "WARN" "ドメインファイル未検出: ${json_path}"
        return 1
    fi
    cat "$json_path"
}

_dk_read_base_json() {
    local json_path="${DK_DOMAINS_DIR}/_base.json"
    if [[ ! -f "$json_path" ]]; then
        _dk_log "WARN" "ベースファイル未検出: ${json_path}"
        return 1
    fi
    cat "$json_path"
}

# =============================================================================
# JSON値抽出ヘルパー（jq不要の簡易実装）
# =============================================================================
_dk_extract_string() {
    local json="$1" key="$2"
    echo "$json" | grep -oE "\"${key}\"[[:space:]]*:[[:space:]]*\"[^\"]*\"" | head -1 | sed -E "s/\"${key}\"[[:space:]]*:[[:space:]]*\"([^\"]*)\"/\1/"
}

_dk_extract_array_strings() {
    local json="$1" key="$2"
    # キーに対応する配列の中の文字列を1行ずつ出力
    echo "$json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
key = '$key'
keys = key.split('.')
obj = data
for k in keys:
    if isinstance(obj, dict) and k in obj:
        obj = obj[k]
    else:
        sys.exit(0)
if isinstance(obj, list):
    for item in obj:
        if isinstance(item, str):
            print(item)
        elif isinstance(item, dict):
            print(json.dumps(item, ensure_ascii=False))
" 2>/dev/null
}

# =============================================================================
# Prismaスキーマ生成
# =============================================================================
# ベースモデル + ドメインモデルを結合してschema.prismaを生成
# =============================================================================
dk_generate_prisma_schema() {
    local domain="$1"

    local base_json domain_json
    base_json=$(_dk_read_base_json) || return 1

    local schema=""
    schema+="// =============================================================================\n"
    schema+="// Prisma Schema - Auto-generated by SoloptiLink Domain Knowledge v${DK_VERSION}\n"
    schema+="// Domain: ${domain}\n"
    schema+="// =============================================================================\n\n"
    schema+="generator client {\n"
    schema+="  provider = \"prisma-client-js\"\n"
    schema+="}\n\n"
    schema+="datasource db {\n"
    schema+="  provider = \"postgresql\"\n"
    schema+="  url      = env(\"DATABASE_URL\")\n"
    schema+="}\n\n"

    # ベースenums生成
    local base_enums
    base_enums=$(echo "$base_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
enums = data.get('enums', {})
for name, values in enums.items():
    print(f'enum {name} {{')
    for v in values:
        print(f'  {v}')
    print('}')
    print()
" 2>/dev/null)
    schema+="${base_enums}\n"

    # ドメインenums生成
    if [[ "$domain" != "generic" ]]; then
        domain_json=$(_dk_read_domain_json "$domain") || true
        if [[ -n "$domain_json" ]]; then
            local domain_enums
            domain_enums=$(echo "$domain_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
enums = data.get('enums', {})
for name, values in enums.items():
    print(f'enum {name} {{')
    for v in values:
        print(f'  {v}')
    print('}')
    print()
" 2>/dev/null)
            schema+="${domain_enums}\n"
        fi
    fi

    # ベースモデル生成
    local base_models
    base_models=$(echo "$base_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
models = data.get('models', {})
for model_name, model_def in models.items():
    fields = model_def.get('fields', {})
    indexes = model_def.get('indexes', [])
    relations = model_def.get('relations', [])

    print(f'model {model_name} {{')
    for fname, fdef in fields.items():
        ftype = fdef.get('type', 'String')
        prisma_attrs = fdef.get('prisma', '')
        desc = fdef.get('description', '')
        line = f'  {fname:<20} {ftype:<15}'
        if prisma_attrs:
            line += f' {prisma_attrs}'
        if desc:
            line += f'  // {desc}'
        print(line)

    # Relations
    for rel in relations:
        rfield = rel.get('field', '')
        rmodel = rel.get('model', '')
        rtype = rel.get('type', '')
        rfk = rel.get('foreignKey', '')
        ropt = rel.get('optional', False)
        if rtype == 'belongsTo':
            ref_field = rfk if rfk else rfield + 'Id'
            opt_mark = '?' if ropt else ''
            print(f'  {rfield:<20} {rmodel}{opt_mark:<14} @relation(fields: [{ref_field}], references: [id])')
        elif rtype == 'hasMany':
            print(f'  {rfield:<20} {rmodel}[]')

    print()
    for idx in indexes:
        print(f'  {idx}')
    print('}')
    print()
" 2>/dev/null)
    schema+="${base_models}\n"

    # ドメインモデル生成
    if [[ "$domain" != "generic" ]] && [[ -n "${domain_json:-}" ]]; then
        local domain_models
        domain_models=$(echo "$domain_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
models = data.get('models', {})
for model_name, model_def in models.items():
    fields = model_def.get('fields', {})
    indexes = model_def.get('indexes', [])
    relations = model_def.get('relations', [])

    print(f'model {model_name} {{')
    for fname, fdef in fields.items():
        ftype = fdef.get('type', 'String')
        prisma_attrs = fdef.get('prisma', '')
        desc = fdef.get('description', '')
        line = f'  {fname:<20} {ftype:<15}'
        if prisma_attrs:
            line += f' {prisma_attrs}'
        if desc:
            line += f'  // {desc}'
        print(line)

    # Relations
    for rel in relations:
        rfield = rel.get('field', '')
        rmodel = rel.get('model', '')
        rtype = rel.get('type', '')
        rfk = rel.get('foreignKey', '')
        ropt = rel.get('optional', False)
        on_del = rel.get('onDelete', '')
        if rtype == 'belongsTo':
            ref_field = rfk if rfk else rfield + 'Id'
            del_clause = f', onDelete: {on_del}' if on_del else ''
            opt_mark = '?' if ropt else ''
            print(f'  {rfield:<20} {rmodel}{opt_mark:<14} @relation(fields: [{ref_field}], references: [id]{del_clause})')
        elif rtype == 'hasMany':
            fk_clause = ''
            if rfk:
                fk_clause = f' // via {rfk}'
            print(f'  {rfield:<20} {rmodel}[]{fk_clause}')

    print()
    for idx in indexes:
        print(f'  {idx}')
    print('}')
    print()
" 2>/dev/null)
        schema+="${domain_models}"
    fi

    DK_PRISMA_SCHEMA="$schema"
    DK_ENUMS_BLOCK=$(echo "$base_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
enums = data.get('enums', {})
print(', '.join(enums.keys()))
" 2>/dev/null)
    if [[ -n "${domain_json:-}" ]]; then
        local domain_enum_names
        domain_enum_names=$(echo "$domain_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
enums = data.get('enums', {})
print(', '.join(enums.keys()))
" 2>/dev/null)
        DK_ENUMS_BLOCK="${DK_ENUMS_BLOCK}, ${domain_enum_names}"
    fi

    echo "$schema"
}

# =============================================================================
# APIエンドポイント仕様生成
# =============================================================================
dk_generate_api_spec() {
    local domain="$1"

    local spec=""
    spec+="## API Endpoints\n\n"

    # ベースAPI（認証）
    local base_json
    base_json=$(_dk_read_base_json) || return 1
    spec+="### 認証API（共通）\n"
    spec+=$(echo "$base_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
auth = data.get('common_features', {}).get('auth', {})
endpoints = auth.get('endpoints', [])
for ep in endpoints:
    method = ep.get('method', '')
    path = ep.get('path', '')
    desc = ep.get('description', '')
    print(f'| \`{method}\` | \`{path}\` | {desc} |')
" 2>/dev/null)
    spec+="\n\n"

    # ドメインAPI
    if [[ "$domain" != "generic" ]]; then
        local domain_json
        domain_json=$(_dk_read_domain_json "$domain") || return 1
        spec+="### ドメインAPI\n"
        spec+="| Method | Path | Description |\n"
        spec+="|--------|------|-------------|\n"
        spec+=$(echo "$domain_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
endpoints = data.get('api_endpoints', [])
for ep in endpoints:
    method = ep.get('method', '')
    path = ep.get('path', '')
    desc = ep.get('description', '')
    print(f'| \`{method}\` | \`{path}\` | {desc} |')
" 2>/dev/null)
        spec+="\n"
    fi

    # ページネーション仕様
    spec+="\n### ページネーション共通仕様\n"
    spec+="- クエリパラメータ: \`?page=1&limit=20&sort=createdAt&order=desc\`\n"
    spec+="- レスポンス: \`{ data: T[], meta: { total, page, limit, totalPages } }\`\n"

    DK_API_SPEC="$spec"
    echo "$spec"
}

# =============================================================================
# ページ構成仕様生成
# =============================================================================
dk_generate_page_spec() {
    local domain="$1"

    if [[ "$domain" == "generic" ]]; then
        DK_PAGE_SPEC=""
        return 0
    fi

    local domain_json
    domain_json=$(_dk_read_domain_json "$domain") || return 1

    local spec=""
    spec+="## ページ構成\n\n"
    spec+=$(echo "$domain_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
pages = data.get('pages', {})
for path, page_def in pages.items():
    title = page_def.get('title', '')
    components = page_def.get('components', [])
    icon = page_def.get('icon', '')
    sidebar_order = page_def.get('sidebar_order', '')

    print(f'### \`{path}\` - {title}')
    if icon:
        print(f'- アイコン: {icon}')
    if sidebar_order:
        print(f'- サイドバー順序: {sidebar_order}')
    print(f'- コンポーネント:')
    for comp in components:
        print(f'  - {comp}')
    print()
" 2>/dev/null)

    DK_PAGE_SPEC="$spec"
    echo "$spec"
}

# =============================================================================
# ビジネスルール生成
# =============================================================================
dk_generate_business_rules() {
    local domain="$1"

    if [[ "$domain" == "generic" ]]; then
        DK_BUSINESS_RULES=""
        return 0
    fi

    local domain_json
    domain_json=$(_dk_read_domain_json "$domain") || return 1

    local rules=""
    rules+="## ビジネスルール（実装必須）\n\n"
    rules+="以下のビジネスルールは必ず実装してください。違反はQuality Gate減点対象です。\n\n"

    local idx=1
    while IFS= read -r rule; do
        [[ -z "$rule" ]] && continue
        rules+="${idx}. ${rule}\n"
        idx=$((idx + 1))
    done < <(echo "$domain_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
rules = data.get('business_rules', [])
for r in rules:
    print(r)
" 2>/dev/null)

    DK_BUSINESS_RULES="$rules"
    echo "$rules"
}

# =============================================================================
# ドメイン機能仕様生成
# =============================================================================
dk_generate_features_spec() {
    local domain="$1"

    if [[ "$domain" == "generic" ]]; then
        echo ""
        return 0
    fi

    local domain_json
    domain_json=$(_dk_read_domain_json "$domain") || return 1

    local spec=""
    spec+="## ドメイン固有機能\n\n"
    spec+=$(echo "$domain_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
features = data.get('domain_features', {})
for fname, fdef in features.items():
    desc = fdef.get('description', '')
    impl = fdef.get('implementation', '')
    ui_type = fdef.get('ui_type', '')
    metrics = fdef.get('metrics', [])

    print(f'### {fname}: {desc}')
    if impl:
        print(f'- 実装方針: {impl}')
    if ui_type:
        print(f'- UIタイプ: {ui_type}')
    if metrics:
        print('- メトリクス:')
        for m in metrics:
            if isinstance(m, dict):
                name = m.get('name', '')
                query = m.get('query', '')
                fmt = m.get('format', '')
                print(f'  - {name}: \`{query}\` ({fmt})')
            else:
                print(f'  - {m}')
    print()
" 2>/dev/null)

    echo "$spec"
}

# =============================================================================
# シードデータ生成
# =============================================================================
dk_generate_seed_data() {
    local domain="$1"

    if [[ "$domain" == "generic" ]]; then
        DK_SEED_DATA=""
        return 0
    fi

    local domain_json
    domain_json=$(_dk_read_domain_json "$domain") || return 1

    local seed
    seed=$(echo "$domain_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
models = data.get('models', {})
seed_lines = []
for model_name, model_def in models.items():
    seed = model_def.get('seed_data', [])
    if seed:
        seed_lines.append(f'// {model_name} seed data')
        for item in seed:
            seed_lines.append(f'await prisma.{model_name[0].lower() + model_name[1:]}.create({{ data: {json.dumps(item, ensure_ascii=False)} }});')
        seed_lines.append('')
if seed_lines:
    print('\n'.join(seed_lines))
" 2>/dev/null)

    DK_SEED_DATA="$seed"
    echo "$seed"
}

# =============================================================================
# 統合: ドメイン知識フルパッケージ生成
# =============================================================================
# メインエントリポイント: タスク記述からドメインを判定し、
# Prismaスキーマ・API仕様・ページ構成・ビジネスルール・シードデータを一括生成
# =============================================================================
dk_generate_full_knowledge() {
    local task_desc="$1"
    local output_dir="${2:-${DK_WORK_DIR}}"

    mkdir -p "$output_dir" 2>/dev/null || true

    _dk_log "INFO" "ドメイン知識生成開始..."

    # 1. ドメイン判定
    local domain
    domain=$(dk_detect_domain "$task_desc")

    # 2. Prismaスキーマ生成
    _dk_log "INFO" "Prismaスキーマ生成中..."
    local prisma_schema
    prisma_schema=$(dk_generate_prisma_schema "$domain")
    echo -e "$prisma_schema" > "${output_dir}/domain_prisma_schema.prisma"
    _dk_log "INFO" "Prismaスキーマ: ${output_dir}/domain_prisma_schema.prisma"

    # 3. API仕様生成
    _dk_log "INFO" "API仕様生成中..."
    local api_spec
    api_spec=$(dk_generate_api_spec "$domain")
    echo -e "$api_spec" > "${output_dir}/domain_api_spec.md"

    # 4. ページ構成生成
    _dk_log "INFO" "ページ構成仕様生成中..."
    local page_spec
    page_spec=$(dk_generate_page_spec "$domain")
    echo -e "$page_spec" > "${output_dir}/domain_page_spec.md"

    # 5. ビジネスルール生成
    _dk_log "INFO" "ビジネスルール生成中..."
    local business_rules
    business_rules=$(dk_generate_business_rules "$domain")
    echo -e "$business_rules" > "${output_dir}/domain_business_rules.md"

    # 6. 機能仕様生成
    _dk_log "INFO" "ドメイン機能仕様生成中..."
    local features_spec
    features_spec=$(dk_generate_features_spec "$domain")
    echo -e "$features_spec" > "${output_dir}/domain_features_spec.md"

    # 7. シードデータ生成
    _dk_log "INFO" "シードデータ生成中..."
    local seed_data
    seed_data=$(dk_generate_seed_data "$domain")
    if [[ -n "$seed_data" ]]; then
        echo -e "$seed_data" > "${output_dir}/domain_seed_data.ts"
    fi

    # モデルサマリー生成
    DK_MODELS_SUMMARY=$(echo "$domain" | python3 -c "
import sys, json, os
domain = sys.stdin.read().strip()
domains_dir = '${DK_DOMAINS_DIR}'
base_path = os.path.join(domains_dir, '_base.json')
domain_path = os.path.join(domains_dir, f'{domain}.json')

models = []
if os.path.exists(base_path):
    with open(base_path) as f:
        base = json.load(f)
    models.extend(base.get('models', {}).keys())

if domain != 'generic' and os.path.exists(domain_path):
    with open(domain_path) as f:
        d = json.load(f)
    models.extend(d.get('models', {}).keys())

print(', '.join(models))
" 2>/dev/null)

    _dk_log "INFO" "ドメイン知識生成完了"
    _dk_log "INFO" "ドメイン: ${DK_BOLD}${domain}${DK_NC}"
    _dk_log "INFO" "モデル: ${DK_MODELS_SUMMARY}"
    _dk_log "INFO" "出力先: ${output_dir}"

    echo "$domain"
}

# =============================================================================
# プロンプト注入用テキスト生成
# =============================================================================
# call_claude() に注入するドメイン知識テキストを生成
# =============================================================================
dk_get_injection_text() {
    local domain="${1:-${DK_DETECTED_DOMAIN}}"
    local output_dir="${2:-${DK_WORK_DIR}}"

    local injection=""
    injection+="\n\n# ===== DOMAIN KNOWLEDGE (v31.0) =====\n"
    injection+="# 以下はドメイン知識エンジンが生成した業界標準仕様です。\n"
    injection+="# これに従って実装してください。\n\n"

    # Prismaスキーマ
    if [[ -f "${output_dir}/domain_prisma_schema.prisma" ]]; then
        injection+="## 確定済みPrismaスキーマ（変更禁止）\n"
        injection+="\`\`\`prisma\n"
        injection+=$(cat "${output_dir}/domain_prisma_schema.prisma")
        injection+="\n\`\`\`\n\n"
    fi

    # API仕様
    if [[ -f "${output_dir}/domain_api_spec.md" ]]; then
        injection+=$(cat "${output_dir}/domain_api_spec.md")
        injection+="\n\n"
    fi

    # ページ構成
    if [[ -f "${output_dir}/domain_page_spec.md" ]]; then
        injection+=$(cat "${output_dir}/domain_page_spec.md")
        injection+="\n\n"
    fi

    # ビジネスルール
    if [[ -f "${output_dir}/domain_business_rules.md" ]]; then
        injection+=$(cat "${output_dir}/domain_business_rules.md")
        injection+="\n\n"
    fi

    # 機能仕様
    if [[ -f "${output_dir}/domain_features_spec.md" ]]; then
        injection+=$(cat "${output_dir}/domain_features_spec.md")
        injection+="\n\n"
    fi

    # シードデータ
    if [[ -f "${output_dir}/domain_seed_data.ts" ]]; then
        injection+="## シードデータ（prisma/seed.ts に実装）\n"
        injection+="\`\`\`typescript\n"
        injection+=$(cat "${output_dir}/domain_seed_data.ts")
        injection+="\n\`\`\`\n\n"
    fi

    injection+="# ===== END DOMAIN KNOWLEDGE =====\n"

    echo "$injection"
}

# =============================================================================
# v31.0: コンプライアンス要件自動検出
# =============================================================================
# ドメインに応じてHIPAA/GDPR/PCI-DSSなどのコンプライアンス要件を自動検出し、
# プロンプトに注入するテキストを生成する。
# =============================================================================
dk_detect_compliance_requirements() {
    local domain="$1"
    local compliance_dir="${DK_COMPLIANCE_DIR:-${DK_DOMAINS_DIR}/_compliance}"

    if [[ ! -d "$compliance_dir" ]]; then
        return 0
    fi

    local domain_json=""
    if [[ -f "${DK_DOMAINS_DIR}/${domain}.json" ]]; then
        domain_json=$(cat "${DK_DOMAINS_DIR}/${domain}.json")
    fi

    local applicable_compliances=()

    # ドメインJSONからcompliance_requirementsフィールドを抽出
    if [[ -n "$domain_json" ]]; then
        local compliance_list
        compliance_list=$(echo "$domain_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
reqs = data.get('compliance_requirements', [])
for r in reqs:
    print(r)
" 2>/dev/null)
        while IFS= read -r comp; do
            [[ -z "$comp" ]] && continue
            if [[ -f "${compliance_dir}/${comp}.json" ]]; then
                applicable_compliances+=("$comp")
            fi
        done <<< "$compliance_list"
    fi

    # ドメインベースの自動推定（compliance_requirementsが未定義の場合）
    if [[ ${#applicable_compliances[@]} -eq 0 ]]; then
        case "$domain" in
            healthcare|medical|clinic|pharmacy)
                [[ -f "${compliance_dir}/hipaa.json" ]] && applicable_compliances+=("hipaa")
                [[ -f "${compliance_dir}/gdpr.json" ]] && applicable_compliances+=("gdpr")
                ;;
            ecommerce|payment|billing|subscription)
                [[ -f "${compliance_dir}/pci-dss.json" ]] && applicable_compliances+=("pci-dss")
                [[ -f "${compliance_dir}/gdpr.json" ]] && applicable_compliances+=("gdpr")
                ;;
            crm|hr|school|survey|fitness)
                [[ -f "${compliance_dir}/gdpr.json" ]] && applicable_compliances+=("gdpr")
                ;;
        esac
    fi

    if [[ ${#applicable_compliances[@]} -eq 0 ]]; then
        _dk_log "INFO" "コンプライアンス: 追加要件なし"
        return 0
    fi

    _dk_log "INFO" "コンプライアンス検出: ${applicable_compliances[*]}"
    echo "${applicable_compliances[*]}"
}

# =============================================================================
# v31.0: コンプライアンス要件テキスト生成
# =============================================================================
dk_generate_compliance_text() {
    local domain="$1"
    local compliance_dir="${DK_COMPLIANCE_DIR:-${DK_DOMAINS_DIR}/_compliance}"

    local compliances
    compliances=$(dk_detect_compliance_requirements "$domain")
    [[ -z "$compliances" ]] && return 0

    local text=""
    text+="# ===== COMPLIANCE REQUIREMENTS (v31.0) =====\n"
    text+="# 以下のコンプライアンス要件は法的義務です。必ず全要件を実装してください。\n\n"

    for comp_name in $compliances; do
        local comp_file="${compliance_dir}/${comp_name}.json"
        [[ ! -f "$comp_file" ]] && continue

        local comp_json
        comp_json=$(cat "$comp_file")

        # コンプライアンス名と説明
        local full_name description
        full_name=$(echo "$comp_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
print(data.get('name', ''))
" 2>/dev/null)
        description=$(echo "$comp_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
print(data.get('description', ''))
" 2>/dev/null)

        text+="## ${full_name}\n"
        text+="${description}\n\n"

        # 要件リスト
        text+="### 実装必須要件\n"
        local req_text
        req_text=$(echo "$comp_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
requirements = data.get('requirements', [])
for i, req in enumerate(requirements, 1):
    title = req.get('title', '')
    desc = req.get('description', '')
    impl = req.get('implementation', '')
    print(f'{i}. **{title}**: {desc}')
    if impl:
        print(f'   - 実装: {impl}')
" 2>/dev/null)
        text+="${req_text}\n\n"

        # Prisma追加フィールド
        local prisma_additions
        prisma_additions=$(echo "$comp_json" | python3 -c "
import sys, json
data = json.load(sys.stdin)
pa = data.get('prisma_additions', {})
if pa:
    models = pa.get('models', {})
    for model_name, model_def in models.items():
        fields = model_def.get('fields', {})
        print(f'#### {model_name} 追加フィールド')
        for fname, fdef in fields.items():
            ftype = fdef.get('type', 'String')
            desc = fdef.get('description', '')
            print(f'- {fname}: {ftype} // {desc}')
        print()
" 2>/dev/null)
        if [[ -n "$prisma_additions" ]]; then
            text+="### Prismaスキーマ追加\n"
            text+="${prisma_additions}\n"
        fi
    done

    text+="# ===== END COMPLIANCE REQUIREMENTS =====\n"
    echo -e "$text"
}

# =============================================================================
# v31.0: コンプライアンス付きドメイン知識フルパッケージ生成
# =============================================================================
dk_generate_full_knowledge_with_compliance() {
    local task_desc="$1"
    local output_dir="${2:-${DK_WORK_DIR}}"

    # 通常のフル知識生成
    local domain
    domain=$(dk_generate_full_knowledge "$task_desc" "$output_dir")

    # コンプライアンス要件生成
    local compliance_text
    compliance_text=$(dk_generate_compliance_text "$domain")
    if [[ -n "$compliance_text" ]]; then
        echo -e "$compliance_text" > "${output_dir}/domain_compliance.md"
        _dk_log "INFO" "コンプライアンス要件: ${output_dir}/domain_compliance.md"
    fi

    echo "$domain"
}

# =============================================================================
# プロンプト注入用テキスト生成（v31.0 コンプライアンス付き）
# =============================================================================
dk_get_injection_text_with_compliance() {
    local domain="${1:-${DK_DETECTED_DOMAIN}}"
    local output_dir="${2:-${DK_WORK_DIR}}"

    # 通常のドメイン知識注入
    local injection
    injection=$(dk_get_injection_text "$domain" "$output_dir")

    # コンプライアンス要件注入
    if [[ -f "${output_dir}/domain_compliance.md" ]]; then
        injection+="\n"
        injection+=$(cat "${output_dir}/domain_compliance.md")
        injection+="\n"
    fi

    echo "$injection"
}

# =============================================================================
# ドメイン知識の有効性チェック
# =============================================================================
dk_is_domain_available() {
    local domain="$1"
    [[ -f "${DK_DOMAINS_DIR}/${domain}.json" ]]
}

# =============================================================================
# バージョン情報
# =============================================================================
dk_version() {
    echo "Domain Knowledge Injector v${DK_VERSION}"
}
