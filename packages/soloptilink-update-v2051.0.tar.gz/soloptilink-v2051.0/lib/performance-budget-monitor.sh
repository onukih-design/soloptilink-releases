#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v414.0 - Performance Budget Monitor
# =============================================================================
# バンドルサイズ・ロード時間・API応答時間の予算設定・継続監視・
# 違反アラート生成を統合する。
#
# Functions:
#   _pbm_init              - 初期化
#   _pbm_set_budgets       - パフォーマンス予算設定
#   _pbm_continuous_check  - 継続チェック実行
#   _pbm_alert_violations  - 違反アラート生成
#   _pbm_report            - レポート出力
#   _pbm_score             - モジュールスコア(0-100)
#
# All globals use the PBM_ prefix.
# =============================================================================

[[ -n "${_PERF_BUDGET_MONITOR_LOADED:-}" ]] && return 0
_PERF_BUDGET_MONITOR_LOADED=1

declare -g PBM_VERSION="414.0"
declare -g PBM_INITIALIZED=false
declare -g PBM_STORE_DIR=""
declare -g PBM_CHECK_COUNT=0
declare -g PBM_VIOLATIONS=0
declare -g PBM_PASS_COUNT=0

declare -g -A _PBM_BUDGETS=()          # metric_name → max_value
declare -g -A _PBM_CURRENT=()          # metric_name → current_value
declare -g -A _PBM_HISTORY=()          # metric_name → "val1,val2,val3"
declare -g -a _PBM_ALERTS=()

# =============================================================================
_pbm_init() {
    local project_dir="${PROJECT_DIR:-.}"
    PBM_STORE_DIR="${project_dir}/.soloptilink/perf-budget"
    mkdir -p "${PBM_STORE_DIR}/reports" "${PBM_STORE_DIR}/history"

    # Default budgets
    _PBM_BUDGETS["bundle_size_kb"]=500
    _PBM_BUDGETS["first_load_js_kb"]=200
    _PBM_BUDGETS["api_response_ms"]=500
    _PBM_BUDGETS["page_load_ms"]=3000
    _PBM_BUDGETS["largest_contentful_paint_ms"]=2500
    _PBM_BUDGETS["first_input_delay_ms"]=100
    _PBM_BUDGETS["cumulative_layout_shift"]=10  # * 100 to avoid decimals
    _PBM_BUDGETS["total_blocking_time_ms"]=300
    _PBM_BUDGETS["image_total_kb"]=1000
    _PBM_BUDGETS["css_total_kb"]=100
    _PBM_BUDGETS["font_total_kb"]=200
    _PBM_BUDGETS["third_party_kb"]=300

    # Load custom budgets from config
    local config_file="${project_dir}/.soloptilink/perf-budget.json"
    if [[ -f "$config_file" ]]; then
        while IFS= read -r line; do
            local key value
            key=$(echo "$line" | grep -oE '"[^"]+":' | tr -d '":')
            value=$(echo "$line" | grep -oE ':\s*[0-9]+' | tr -d ': ')
            [[ -n "$key" && -n "$value" ]] && _PBM_BUDGETS["$key"]=$value
        done < "$config_file"
    fi

    PBM_INITIALIZED=true
    return 0
}

# =============================================================================
# _pbm_set_budgets - Set or update performance budgets
# =============================================================================
_pbm_set_budgets() {
    local budget_spec="$1"  # "metric:value,metric:value,..."

    [[ "$PBM_INITIALIZED" != "true" ]] && { echo "ERROR: PBM not initialized" >&2; return 1; }

    IFS=',' read -ra budget_pairs <<< "$budget_spec"
    for pair in "${budget_pairs[@]}"; do
        local metric="${pair%%:*}"
        local value="${pair##*:}"
        if [[ -n "$metric" && -n "$value" ]]; then
            _PBM_BUDGETS["$metric"]=$value
            echo "Budget set: ${metric} = ${value}" >&2
        fi
    done

    # Save to config
    local config_file="${PBM_STORE_DIR}/budgets.json"
    echo "{" > "$config_file" 2>/dev/null
    local first=true
    for metric in "${!_PBM_BUDGETS[@]}"; do
        [[ "$first" != "true" ]] && echo "," >> "$config_file" 2>/dev/null
        echo "  \"${metric}\": ${_PBM_BUDGETS[$metric]}" >> "$config_file" 2>/dev/null
        first=false
    done
    echo "}" >> "$config_file" 2>/dev/null

    echo "${#_PBM_BUDGETS[@]} budgets configured"
    return 0
}

# =============================================================================
# _pbm_continuous_check - Run continuous performance check
# =============================================================================
_pbm_continuous_check() {
    local project_dir="${1:-${PROJECT_DIR:-.}}"

    [[ "$PBM_INITIALIZED" != "true" ]] && { echo "ERROR: PBM not initialized" >&2; return 1; }
    PBM_CHECK_COUNT=$((PBM_CHECK_COUNT + 1))

    local violations=()
    local passes=()

    # Check 1: Bundle size (check .next/static or dist)
    local bundle_dir=""
    for candidate in "${project_dir}/.next/static" "${project_dir}/dist" "${project_dir}/build"; do
        [[ -d "$candidate" ]] && { bundle_dir="$candidate"; break; }
    done

    if [[ -n "$bundle_dir" ]]; then
        local total_kb
        total_kb=$(du -sk "$bundle_dir" 2>/dev/null | awk '{print $1}')
        total_kb=${total_kb:-0}
        _PBM_CURRENT["bundle_size_kb"]=$total_kb
        local budget="${_PBM_BUDGETS[bundle_size_kb]:-500}"
        if [[ $total_kb -gt $budget ]]; then
            violations+=("bundle_size_kb:${total_kb}>${budget}")
        else
            passes+=("bundle_size_kb:${total_kb}<=${budget}")
        fi
    fi

    # Check 2: JS file sizes
    if [[ -n "$bundle_dir" ]]; then
        local js_total=0
        while IFS= read -r js_file; do
            [[ -z "$js_file" ]] && continue
            local file_kb
            file_kb=$(du -k "$js_file" 2>/dev/null | awk '{print $1}')
            js_total=$((js_total + ${file_kb:-0}))
        done < <(find "$bundle_dir" -name "*.js" 2>/dev/null | head -50)
        _PBM_CURRENT["first_load_js_kb"]=$js_total
        local budget="${_PBM_BUDGETS[first_load_js_kb]:-200}"
        if [[ $js_total -gt $budget ]]; then
            violations+=("first_load_js_kb:${js_total}>${budget}")
        else
            passes+=("first_load_js_kb:${js_total}<=${budget}")
        fi
    fi

    # Check 3: CSS total size
    local css_total=0
    while IFS= read -r css_file; do
        [[ -z "$css_file" ]] && continue
        local file_kb
        file_kb=$(du -k "$css_file" 2>/dev/null | awk '{print $1}')
        css_total=$((css_total + ${file_kb:-0}))
    done < <(find "$project_dir" -name "*.css" -not -path "*/node_modules/*" 2>/dev/null | head -30)
    if [[ $css_total -gt 0 ]]; then
        _PBM_CURRENT["css_total_kb"]=$css_total
        local budget="${_PBM_BUDGETS[css_total_kb]:-100}"
        if [[ $css_total -gt $budget ]]; then
            violations+=("css_total_kb:${css_total}>${budget}")
        else
            passes+=("css_total_kb:${css_total}<=${budget}")
        fi
    fi

    # Check 4: Image total size
    local img_total=0
    while IFS= read -r img_file; do
        [[ -z "$img_file" ]] && continue
        local file_kb
        file_kb=$(du -k "$img_file" 2>/dev/null | awk '{print $1}')
        img_total=$((img_total + ${file_kb:-0}))
    done < <(find "$project_dir" \( -name "*.png" -o -name "*.jpg" -o -name "*.jpeg" -o -name "*.gif" -o -name "*.svg" -o -name "*.webp" \) -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null | head -50)
    if [[ $img_total -gt 0 ]]; then
        _PBM_CURRENT["image_total_kb"]=$img_total
        local budget="${_PBM_BUDGETS[image_total_kb]:-1000}"
        if [[ $img_total -gt $budget ]]; then
            violations+=("image_total_kb:${img_total}>${budget}")
        else
            passes+=("image_total_kb:${img_total}<=${budget}")
        fi
    fi

    # Check 5: Package count (proxy for third-party size)
    if [[ -f "${project_dir}/package.json" ]]; then
        local dep_count
        dep_count=$(grep -c '"[^"]*":' "${project_dir}/package.json" 2>/dev/null || echo "0")
        _PBM_CURRENT["dependency_count"]=$dep_count
    fi

    PBM_VIOLATIONS=$((PBM_VIOLATIONS + ${#violations[@]}))
    PBM_PASS_COUNT=$((PBM_PASS_COUNT + ${#passes[@]}))

    # Record history
    local timestamp
    timestamp=$(date +%s 2>/dev/null || echo "0")
    for metric in "${!_PBM_CURRENT[@]}"; do
        local val="${_PBM_CURRENT[$metric]}"
        local hist="${_PBM_HISTORY[$metric]:-}"
        _PBM_HISTORY["$metric"]="${hist:+${hist},}${val}"
    done

    # Output results
    local total_checks=$(( ${#violations[@]} + ${#passes[@]} ))
    cat <<CHECKEOF
{"checks":${total_checks},"violations":${#violations[@]},"passes":${#passes[@]},"timestamp":${timestamp}}
CHECKEOF

    for v in "${violations[@]}"; do
        echo "  VIOLATION: ${v}" >&2
    done

    return 0
}

# =============================================================================
# _pbm_alert_violations - Generate violation alerts
# =============================================================================
_pbm_alert_violations() {
    local format="${1:-text}"

    [[ "$PBM_INITIALIZED" != "true" ]] && return 1

    case "$format" in
        json)
            echo "["
            local first=true
            for metric in "${!_PBM_CURRENT[@]}"; do
                local current="${_PBM_CURRENT[$metric]}"
                local budget="${_PBM_BUDGETS[$metric]:-0}"
                if [[ $budget -gt 0 && $current -gt $budget ]]; then
                    [[ "$first" != "true" ]] && echo ","
                    local overage=$(( current - budget ))
                    local pct=$(( (overage * 100) / budget ))
                    echo "{\"metric\":\"${metric}\",\"current\":${current},\"budget\":${budget},\"overage\":${overage},\"overage_pct\":${pct}}"
                    first=false
                fi
            done
            echo "]"
            ;;
        text|*)
            echo "=== Performance Budget Violations ==="
            local has_violations=false
            for metric in "${!_PBM_CURRENT[@]}"; do
                local current="${_PBM_CURRENT[$metric]}"
                local budget="${_PBM_BUDGETS[$metric]:-0}"
                if [[ $budget -gt 0 && $current -gt $budget ]]; then
                    has_violations=true
                    local overage=$(( current - budget ))
                    echo "  [VIOLATION] ${metric}: ${current} (budget: ${budget}, over by ${overage})"
                fi
            done
            [[ "$has_violations" != "true" ]] && echo "  All metrics within budget."
            ;;
    esac
    return 0
}

# =============================================================================
# Report / Score
# =============================================================================
_pbm_report() {
    echo -e "\n  ${BOLD:-}=== Performance Budget Monitor v${PBM_VERSION} ===${NC:-}"
    echo -e "  Checks Run      : ${PBM_CHECK_COUNT}"
    echo -e "  Violations      : ${PBM_VIOLATIONS}"
    echo -e "  Passes          : ${PBM_PASS_COUNT}"
    echo -e "  Budgets Defined : ${#_PBM_BUDGETS[@]}"
}

_pbm_score() {
    local score=30
    [[ "$PBM_INITIALIZED" == "true" ]] && score=$((score + 20))
    [[ $PBM_CHECK_COUNT -gt 0 ]] && score=$((score + 20))
    [[ $PBM_VIOLATIONS -eq 0 && $PBM_PASS_COUNT -gt 0 ]] && score=$((score + 20))
    [[ $PBM_VIOLATIONS -gt 0 ]] && score=$((score + 10))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "performance-budget-monitor" \
        --version "414.0" \
        --description "パフォーマンス予算設定・継続監視・違反アラート" \
        --init "_pbm_init" \
        --report "_pbm_report" \
        --score "_pbm_score" \
        --enable-var "ENABLE_PBM" \
        --cli-flags "--perf-budget:--no-perf-budget"
fi

# v2003.1: source時のexit codeを確実に0にする
true
