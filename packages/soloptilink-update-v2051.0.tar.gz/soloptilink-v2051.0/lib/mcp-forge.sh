#!/usr/bin/env bash
# ============================================================
# SoloptiLink MCP Forge - CLI v0.1
# (c) 2026 SoloptiLink Inc. - All rights reserved. 営業秘密 / 不正競争防止法・著作権法で保護
#
# IBL辞書(integrations/*.json) を Claude Code の MCP ツールとして
# 「一言で」繋ぐための操作層。汎用ランタイム(generic-ibl-mcp-server.mjs)を駆動する。
#
# 使い方:
#   mcp-forge.sh list                         登録済み辞書を一覧
#   mcp-forge.sh inspect <id>                 1辞書の要約 + 生成されるツール名を表示
#   mcp-forge.sh doctor  <id>                 ランタイムを起動し initialize+tools/list を実測
#   mcp-forge.sh connect [<id>]               日本語オンボ: 選択→トークン入力→vault保管→登録→検証
#   mcp-forge.sh wire    <id> [--global|--project <dir>] [--vault-ref <ref>|--token <値>] [--token-env <NAME>]
#                                             Claude Code に MCP サーバとして登録(推奨は --vault-ref で平文回避)
#   mcp-forge.sh unwire  <id> [--global|--project <dir>]
#                                             登録を解除
#   mcp-forge.sh serve   [--port <N>]         ホスト型(リモートHTTP/SSE)バックエンドを起動
#
# 設計: 既存本体ファイルを一切編集しない「追加方式」。配信は管理者判断。
# ============================================================
set -uo pipefail

SL="${HOME}/.soloptilink"
FORGE_DIR="${SL}/lib/mcp-forge"
RUNTIME="${FORGE_DIR}/generic-ibl-mcp-server.mjs"
HTTP_RUNTIME="${FORGE_DIR}/http-ibl-mcp-server.mjs"
INTEG="${SL}/integrations"
SHIELD="${SL}/lib/security/local-prompt-shield"
LOCALVAULT="${SHIELD}/lib/local-vault.js"

c_red()   { printf '\033[31m%s\033[0m\n' "$*"; }
c_grn()   { printf '\033[32m%s\033[0m\n' "$*"; }
c_dim()   { printf '\033[2m%s\033[0m\n'  "$*"; }

dict_path() { echo "${INTEG}/$1.json"; }

ensure_deps() {
  if [[ ! -d "${FORGE_DIR}/node_modules/@modelcontextprotocol" ]]; then
    c_dim "依存をインストールしています (@modelcontextprotocol/sdk, zod) ..."
    ( cd "${FORGE_DIR}" && npm install --silent ) || { c_red "依存インストールに失敗しました"; return 1; }
  fi
  return 0
}

# 辞書からトークン環境変数名を解決(ランタイムと同じ規約)
token_env_of() {
  local id="$1" dp; dp="$(dict_path "$id")"
  python3 - "$dp" "$id" <<'PY'
import json,sys
dp,cid=sys.argv[1],sys.argv[2]
try: d=json.load(open(dp))
except Exception: print(""); sys.exit()
ak=(d.get("auth") or {}).get("api_key") or {}
if ak.get("env"): print(ak["env"])
else: print(cid.upper().replace("-","_").replace(".","_")+"_TOKEN")
PY
}

cmd_list() {
  [[ -d "$INTEG" ]] || { c_red "辞書ディレクトリがありません: $INTEG"; return 1; }
  python3 - "$INTEG" <<'PY'
import json,glob,os
for f in sorted(glob.glob(os.path.join(__import__("sys").argv[1],"*.json"))):
    b=os.path.basename(f)
    if b.startswith("_"): continue
    try: d=json.load(open(f))
    except Exception: continue
    cid=d.get("connector") or os.path.splitext(b)[0]
    nm=d.get("display_name") or cid
    cat=d.get("category") or "-"
    ap=(d.get("auth") or {}).get("primary") or "-"
    eps=len(d.get("endpoints") or [])
    print(f"{cid:24} {nm:22} {cat:16} auth={ap:22} endpoints={eps}")
PY
}

cmd_inspect() {
  local id="$1" dp; dp="$(dict_path "$id")"
  [[ -f "$dp" ]] || { c_red "辞書が見つかりません: $id ($dp)"; return 1; }
  python3 - "$dp" "$id" <<'PY'
import json,sys,re
dp,cid=sys.argv[1],sys.argv[2]
d=json.load(open(dp))
cid=d.get("connector") or cid
print("連携先   :", d.get("display_name") or cid, f"({cid})")
print("分類     :", d.get("category"))
print("base_url :", d.get("base_url"))
auth=d.get("auth") or {}
ak=auth.get("api_key") or {}
print("認証     :", auth.get("primary"), "| header=", ak.get("header","Authorization"), "scheme=", ak.get("scheme","bearer"))
used=set()
def tn(method,path):
    p=re.sub(r'\{[^}]+\}','',path); p=re.sub(r'[^a-zA-Z0-9]+','_',p).strip('_')
    n=re.sub(r'_+','_',f"{cid}_{method.lower()}_{p}")[:60]
    x=n;i=2
    while x in used: x=f"{n}_{i}"; i+=1
    used.add(x); return x
print("--- 生成されるツール ---")
for ep in (d.get("endpoints") or []):
    if not ep.get("path") or not ep.get("method"): continue
    print(f"  {tn(ep['method'],ep['path']):44} {ep['method']:6} {ep['path']}")
PY
  echo ""
  c_dim "トークン環境変数: $(token_env_of "$id")"
}

cmd_doctor() {
  local id="$1" dp; dp="$(dict_path "$id")"
  [[ -f "$dp" ]] || { c_red "辞書が見つかりません: $id"; return 1; }
  ensure_deps || return 1
  # 専用プローブ(.mjs)でランタイムを実起動しハンドシェイクを実測
  IBL_DICT="$dp" node "${FORGE_DIR}/doctor-probe.mjs" "$RUNTIME"
}

# トークンを OS Keychain(LocalVault)へ保管し、vault参照ハンドルを stdout に返す。
# 平文はargvに乗せず環境変数 SLK_TOKEN 経由で node に渡す。keyId 規約は shield と一致。
vault_store_token() {
  local provider="$1" token="$2"
  [[ -f "$LOCALVAULT" ]] || { c_red "local-prompt-shield が見つかりません: $LOCALVAULT"; return 1; }
  SLK_TOKEN="$token" SLK_PROVIDER="$provider" SLK_VAULT="$LOCALVAULT" node - <<'JS'
const { createRequire } = require('node:module');
const crypto = require('node:crypto');
const { LocalVault } = require(process.env.SLK_VAULT);
const token = process.env.SLK_TOKEN, provider = process.env.SLK_PROVIDER;
const keyId = `${provider}-${crypto.createHash('sha256').update(token).digest('hex').slice(0,12)}`;
new LocalVault().put(keyId, Buffer.from(token, 'utf8'), { provider });
process.stdout.write(`vault://soloptilink/${provider}/${keyId}`);
JS
}

cmd_wire() {
  local id="$1"; shift
  local scope="global" projdir="" token="" tokenenv="" vaultref=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --global) scope="global";;
      --project) scope="project"; projdir="${2:-$PWD}"; shift;;
      --token) token="${2:-}"; shift;;
      --token-env) tokenenv="${2:-}"; shift;;
      --vault-ref) vaultref="${2:-}"; shift;;
      *) c_red "不明なオプション: $1"; return 1;;
    esac; shift
  done
  local dp; dp="$(dict_path "$id")"
  [[ -f "$dp" ]] || { c_red "辞書が見つかりません: $id"; return 1; }
  ensure_deps || return 1
  [[ -z "$tokenenv" ]] && tokenenv="$(token_env_of "$id")"

  local target
  if [[ "$scope" == "global" ]]; then target="${HOME}/.claude.json"; else target="${projdir}/.mcp.json"; fi

  # 平文トークンは argv(ps で露出)に乗せず環境変数 SLK_WIRE_TOKEN 経由で渡す
  SLK_WIRE_TOKEN="$token" python3 - "$target" "$scope" "$id" "$RUNTIME" "$dp" "$tokenenv" "$vaultref" <<'PY'
import json,sys,os
target,scope,cid,runtime,dp,tenv,vaultref=sys.argv[1:8]
token=os.environ.get("SLK_WIRE_TOKEN","")
data={}
if os.path.exists(target):
    try: data=json.load(open(target))
    except Exception: data={}
# mcpServers の置き場所: global(~/.claude.json) も project(.mcp.json) も top-level mcpServers
data.setdefault("mcpServers",{})
env={"IBL_DICT":dp}
if vaultref:                       # 推奨: 平文を書かず vault 参照ハンドルのみ
    env["IBL_VAULT_REF"]=vaultref
    env["IBL_TOKEN_ENV"]=tenv
elif token:                        # 後方互換: 平文埋め込み(非推奨)
    env[tenv]=token
data["mcpServers"][cid]={"command":"node","args":[runtime],"env":env}
os.makedirs(os.path.dirname(target) or ".",exist_ok=True)
json.dump(data,open(target,"w"),ensure_ascii=False,indent=2)
print("WROTE",target)
print("TOKEN", "VAULT_REF" if vaultref else ("EMBEDDED_PLAINTEXT" if token else "NOT_SET"))
PY
  c_grn "✓ ${id} を Claude Code に登録しました (${target})"
  if [[ -n "$vaultref" ]]; then
    c_dim "トークンは OS Keychain に暗号保管され、設定ファイルには参照のみ記録(平文なし)。"
  elif [[ -n "$token" ]]; then
    c_red "⚠️ 平文トークンを設定ファイルに埋め込みました(非推奨)。connect ウィザード(vault保管)の利用を推奨します。"
  else
    c_dim "トークン未設定です。connect ウィザードで安全に設定できます:  mcp-forge.sh connect ${id}"
  fi
  c_dim "Claude Code を再起動すると ${id} のツールが使えます。"
}

cmd_unwire() {
  local id="$1"; shift
  local scope="global" projdir=""
  while [[ $# -gt 0 ]]; do
    case "$1" in
      --global) scope="global";;
      --project) scope="project"; projdir="${2:-$PWD}"; shift;;
    esac; shift
  done
  local target
  if [[ "$scope" == "global" ]]; then target="${HOME}/.claude.json"; else target="${projdir}/.mcp.json"; fi
  [[ -f "$target" ]] || { c_red "設定ファイルがありません: $target"; return 1; }
  python3 - "$target" "$id" <<'PY'
import json,sys
target,cid=sys.argv[1],sys.argv[2]
d=json.load(open(target))
ms=d.get("mcpServers") or {}
if cid in ms: del ms[cid]; json.dump(d,open(target,"w"),ensure_ascii=False,indent=2); print("REMOVED",cid)
else: print("NOTFOUND",cid)
PY
  c_grn "✓ ${id} の登録を解除しました (${target})"
}

# 日本語オンボーディング・ウィザード: サービス選択 → トークン非表示入力 → vault保管 → wire → 検証
cmd_connect() {
  local id="${1:-}"; shift || true
  local passthru=("$@")

  if [[ -z "$id" ]]; then
    if [[ ! -t 0 ]]; then
      c_red "接続するサービスIDを指定してください(対話端末でない場合)。"
      c_dim "例: ~/.soloptilink/soloptilink --connect-mcp chatwork"
      c_dim "一覧: mcp-forge.sh list"
      return 1
    fi
    echo "接続できる主なサービス:"
    bash "$0" list | grep -iE "chatwork|slack|line-messaging|discord|microsoft-teams|line-works" || true
    printf "接続するサービスID> "
    read -r id
    [[ -z "$id" ]] && { c_red "未入力のため中止しました。"; return 1; }
  fi

  # Google(Gmail/カレンダー/ドライブ)は OAuth で短命トークンのため、静的トークン方式の
  # 汎用ランタイムには不向き。ハイブリッド方針どおり Anthropic 純正コネクタへ案内する。
  case "$id" in
    google|gmail|google-mail|googlemail|google-calendar|calendar|google-workspace*|google-drive|gdrive|google-oauth)
      c_grn "=== Google 連携のご案内 ==="
      echo "Gmail / Google カレンダー / ドライブは、SoloptiLink の MCP ではなく"
      echo "Claude 純正コネクタ(Anthropic 提供)を有効化するのが最も簡単・安全です。"
      echo "  理由: Google は短時間で失効するOAuthトークンを使うため、純正コネクタが自動更新を担います。"
      echo ""
      echo "手順(Claude Desktop / claude.ai):"
      echo "  1. 設定 → コネクタ(Connectors) を開く"
      echo "  2. 『Gmail』『Google Calendar』を選んで連携(Googleアカウントでログイン許可)"
      echo "  3. 連携後、Claude から『未読メールを要約して』『今日の予定を見せて』等が使えます"
      echo ""
      c_dim "詳細手順: ~/.soloptilink/docs/mcp-forge/google-connector-guide.md"
      c_dim "(Chatwork / LINE公式 / Slack 等の SoloptiLink 製 MCP は connect <id> でそのまま接続できます)"
      return 0;;
  esac

  local dp; dp="$(dict_path "$id")"
  [[ -f "$dp" ]] || { c_red "辞書が見つかりません: $id (一覧: mcp-forge.sh list)"; return 1; }
  ensure_deps || return 1

  echo ""
  c_grn "=== ${id} 接続ウィザード ==="
  python3 - "$dp" <<'PY'
import json,sys
d=json.load(open(sys.argv[1]))
print("  サービス:", d.get("display_name"))
print("  概要    :", (d.get("description_ja") or "")[:160])
ak=(d.get("auth") or {}).get("api_key") or {}
w=ak.get("where_to_get_ja") or ""
if w: print("  取得先  :", w[:320])
PY
  echo ""

  if [[ ! -t 0 ]]; then
    c_red "対話端末でないためトークンを安全に入力できません。実ターミナルで実行してください。"
    c_dim "(Claude Code のチャット内ではなく、Mac/Windows のターミナルで ~/.soloptilink/soloptilink --connect-mcp ${id})"
    return 1
  fi
  local token=""
  printf "APIトークンを貼り付けてEnter(入力は非表示)> "
  read -r -s token; echo ""
  [[ -z "$token" ]] && { c_red "トークン未入力のため中止しました。"; return 1; }

  c_dim "OS Keychain に暗号保管しています..."
  local ref; ref="$(vault_store_token "$id" "$token")" || { c_red "vault保管に失敗しました。"; return 1; }
  token=""
  [[ "$ref" == vault://* ]] || { c_red "vault参照の生成に失敗しました。"; return 1; }

  local has_scope=0
  for a in ${passthru[@]+"${passthru[@]}"}; do [[ "$a" == "--global" || "$a" == "--project" ]] && has_scope=1; done
  [[ $has_scope -eq 0 ]] && passthru+=("--global")

  cmd_wire "$id" --vault-ref "$ref" ${passthru[@]+"${passthru[@]}"}

  echo ""
  c_dim "接続を検証しています(ツール一覧 + vault復号)..."
  IBL_DICT="$dp" IBL_VAULT_REF="$ref" node "${FORGE_DIR}/doctor-probe.mjs" "$RUNTIME" || true
  echo ""
  c_grn "✓ ${id} の接続が完了しました。Claude Code を再起動するとツールが使えます。"
}

# ホスト型(リモート HTTP/SSE)バックエンドを起動する
cmd_serve() {
  local port="8787"
  while [[ $# -gt 0 ]]; do
    case "$1" in --port) port="${2:-8787}"; shift;; esac; shift
  done
  ensure_deps || return 1
  c_grn "ホスト型 MCP サーバを起動します (port=${port})"
  c_dim "各サービス: http://localhost:${port}/mcp/<id>  (HTTPヘッダ Authorization: Bearer <トークン>)"
  c_dim "疎通確認 : curl http://localhost:${port}/health"
  PORT="$port" node "$HTTP_RUNTIME"
}

usage() {
  sed -n '2,32p' "$0" | sed 's/^# \{0,1\}//'
}

main() {
  local cmd="${1:-}"; shift || true
  case "$cmd" in
    list)    cmd_list "$@";;
    inspect) [[ $# -ge 1 ]] || { c_red "使い方: inspect <id>"; exit 1; }; cmd_inspect "$@";;
    doctor)  [[ $# -ge 1 ]] || { c_red "使い方: doctor <id>"; exit 1; }; cmd_doctor "$@";;
    connect) cmd_connect "$@";;
    serve)   cmd_serve "$@";;
    wire)    [[ $# -ge 1 ]] || { c_red "使い方: wire <id> [--global|--project <dir>] [--token <値>|--vault-ref <ref>]"; exit 1; }; cmd_wire "$@";;
    unwire)  [[ $# -ge 1 ]] || { c_red "使い方: unwire <id> [--global|--project <dir>]"; exit 1; }; cmd_unwire "$@";;
    ""|-h|--help|help) usage;;
    *) c_red "不明なコマンド: $cmd"; usage; exit 1;;
  esac
}
main "$@"
