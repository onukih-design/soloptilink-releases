#!/bin/bash
# Idempotent NOOP migration — v2032
# このバージョンには構造変更がないため、適用済みマークのみ残す。
# 顧客の auto-update.sh が一度実行すれば .migration-state.json に記録され、二度と走らない。
set -e
SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
STATE="$SL_DIR/.migration-state.json"
NAME="v2032_noop"
mkdir -p "$(dirname "$STATE")"
if [ -f "$STATE" ] && grep -q "\"$NAME\"" "$STATE" 2>/dev/null; then
  exit 0
fi
# 既存 state があれば追記、なければ新規作成
if [ -f "$STATE" ]; then
  python3 -c "
import json,os,sys
with open('$STATE') as f:
    d=json.load(f) if os.path.getsize('$STATE')>0 else {}
d.setdefault('applied',[]).append('$NAME')
with open('$STATE','w') as f:
    json.dump(d,f,ensure_ascii=False,indent=2)
" 2>/dev/null || echo '{"applied":["'$NAME'"]}' > "$STATE"
else
  echo '{"applied":["'$NAME'"]}' > "$STATE"
fi
echo "[migration] $NAME applied (noop)"
