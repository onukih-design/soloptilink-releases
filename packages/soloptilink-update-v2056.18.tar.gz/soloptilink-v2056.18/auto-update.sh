#!/bin/bash

# ── 文字の扱いを固定する (2026-09-03 新設) ──────────────────────────
# 日本語環境の Windows では、Python が既定 (cp932) で画面へ書き出すため、
# 説明文に含まれる全角ダッシュ (—) などを書き出せずに途中で停止します。
# お客様の端末で実際に自己診断がこれで落ち、「セットアップは一部が未完了です」
# と表示されていました。Mac では既定が UTF-8 のため一度も現れませんでした。
# UTF-8 に固定し、変換できない文字があっても止まらないようにします。
export PYTHONIOENCODING="utf-8:replace"
export PYTHONUTF8=1

# ============================================================
# SoloptiLinkAI Auto-Update v2009.4
#
# Claude Code起動時にバックグラウンドで実行される。
# お客さんは何もしなくても常に最新版になる。
#
# 仕組み:
#   1. 24時間キャッシュで頻度制限
#   2. 排他ロック（複数Claude Codeウィンドウ対策）
#   3. APIに最新バージョンを問い合わせ
#   4. 更新があればパッケージをダウンロード
#   5. SHA256検証後、全ファイルを安全に更新
#   6. skills/agents/hooks も含めて完全更新
#   7. 更新後検証ステータスを記録
#
# 配置: ~/.soloptilink/auto-update.sh
# フック: ~/.claude/settings.json の UserPromptSubmit
# ============================================================

# ============================================================
# PFP-101 自己上書き安全化 (2026-06-10): 更新処理は auto-update.sh 自身も
# 置換する。bash は実行中ファイルが置換されると以降を誤読し
# 「command not found / 構文エラー」を吐く (実測: v2034.4→v2038.2 更新時)。
# → 起動直後に一時コピーへ退避し、そちらを再実行することで根絶する。
# ============================================================
# --- SOLOPTILINK-EVICT-GUARD (RQ-409) 退去済み端末では何も書かず無出力で終了 ---
[ -f "${HOME}/.claude/.soloptilink-evicted.json" ] && [ "${SOLOPTILINK_EVICT_GUARD:-on}" != "off" ] && exit 0
# --- /SOLOPTILINK-EVICT-GUARD -------------------------------------------------
if [ -z "${SOLOPTILINK_AUTOUPDATE_REEXEC:-}" ]; then
    _self_tmp=$(mktemp "${TMPDIR:-/tmp}/sl-autoupdate.XXXXXX" 2>/dev/null) || exit 0
    cat "$0" > "$_self_tmp" 2>/dev/null || { rm -f "$_self_tmp"; exit 0; }
    SOLOPTILINK_AUTOUPDATE_REEXEC=1 exec bash "$_self_tmp" "$@"
fi
# ★2026-09-30: 終了時に消してよいのは「起動直後に作った一時写し」だけにする。
#   SOLOPTILINK_AUTOUPDATE_REEXEC を外から付けて本物を直接走らせると $0 が本物を指し、
#   下の終了時の掃除 (trap) が本物の auto-update.sh を消していた
#   (2026-09-30 砂箱の検査で ~/.soloptilink/auto-update.sh が実際に消えた。一時写しで復元済み)。
#   一時写しは上の mktemp が作る sl-autoupdate.* という名前なので、それで見分ける。
case "$0" in */sl-autoupdate.*) _SL_SELF_COPY="$0" ;; *) _SL_SELF_COPY="" ;; esac

SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
CLAUDE_DIR="$HOME/.claude"
CACHE_FILE="$SL_DIR/.last_auto_update_check"
API_BASE="${SOLOPTILINK_API_URL:-https://admin-dashboard-blue-alpha-78.vercel.app/api/v1}"
CHECK_INTERVAL=86400  # 24時間
LOG_FILE="$SL_DIR/.auto-update.log"
LOCK_DIR="$SL_DIR/.auto-update.lock"
STATUS_FILE="$SL_DIR/.auto-update-status.json"

log() { echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> "$LOG_FILE" 2>/dev/null; }

# ============================================================
# 導入台帳への記録 (RQ-405 / 2026-09-13 新設)
# ------------------------------------------------------------
# 【なぜ要るか】
#   退去 (ご解約の端末から当社の構成要素を取り除く処理) は「台帳に載っている
#   ものだけ」を消す。このファイルはお客様の端末へ実際に物を置く経路を
#   4 つ持っている (呼び出し口の配置・記憶フックの再登録・鮮度パス・担当定義の配置)。
#   置いたことを台帳へ書かないと、退去しても当社のファイルが端末に残る。
#   反証で「台帳の書き手が本体に 0 件」と実測されたのがこの欠けである。
#
# 【source ではなくサブコマンドで呼ぶ理由】
#   lib/evict/manifest.sh は先頭で `set -uo pipefail` を立てている。
#   source するとこのファイルの残り全部がその設定下で動くことになり、
#   既往事故「pipefail で printf | grep -q が並列時に偽不合格」と同型の
#   事故を持ち込む。別プロセスで呼べばこのファイルの挙動は 1 ミリも変わらない。
#
# 【記録の失敗は配置の成否に影響させない】
#   python3 が無い端末では記録できない (manifest.sh の仕様)。
#   そのときでも配置は成功として扱う。必ず `|| true` で受ける。
#   ただし黙って 0 件にはせず、記録できなかったことをログに残す。
#
# kill-switch: SOLOPTILINK_INSTALL_MANIFEST=off (既定 on)
# ============================================================
_sl_manifest_note() {
    [ "${SOLOPTILINK_INSTALL_MANIFEST:-on}" = "off" ] && return 0
    local mf="$SL_DIR/lib/evict/manifest.sh"
    [ -f "$mf" ] || return 0
    if bash "$mf" add "$@" >/dev/null 2>&1; then
        return 0
    fi
    log "MANIFEST_RECORD_FAILED $*"
    return 0
}

# ★ファイル単位の台帳 (退去の権威①) へ、いま置いた 1 件を足す (2026-09-17)
#   既にその根の記録があるときだけ足す。無いときに 1 件だけ書くと、
#   「載っていない＝お客様のもの」と読まれて当社のファイルが控えへ渡る。
#   根の記録そのものを作るのは setup.sh (置いた直後で中身が当社のものだけ) の役。
_sl_file_manifest_note_file() {
    [ "${SOLOPTILINK_INSTALL_MANIFEST:-on}" = "off" ] && return 0
    local mf="$SL_DIR/lib/evict/manifest.sh"
    [ -f "$mf" ] || return 0
    bash "$mf" record-file "${1:-}" "${2:-}" auto-update >/dev/null 2>&1 || true
    return 0
}

_sl_manifest_note_settings_hooks() {
    [ "${SOLOPTILINK_INSTALL_MANIFEST:-on}" = "off" ] && return 0
    local mf="$SL_DIR/lib/evict/manifest.sh" n
    [ -f "$mf" ] || return 0
    n="$(bash "$mf" add-settings-hooks "${1:-auto-update}" 2>/dev/null)" || n=""
    if [ -n "$n" ]; then log "MANIFEST_SETTINGS_HOOKS ${n} 件"; else log "MANIFEST_RECORD_FAILED settings-hooks"; fi
    return 0
}

# ============================================================
# 背面実行の切り離し (2026-09-02 新設)
# ------------------------------------------------------------
# 【なぜ必要か / 実測して確かめたこと】
#   自動更新はエディタのフックから呼ばれ、その実行には 30 秒の制限があります。
#   従来は ( … ) & で背面へ回していましたが、背面に回しただけでは呼び出し元と
#   同じ「まとまり」に属したままです。時間切れのときはこのまとまりごと停止
#   されるため、更新が毎回途中で止まっていました。
#   2026-09-02 に macOS で実測した結果:
#     ( … ) &   … 停止された (完了せず)
#     nohup     … 停止された (完了せず)
#     新しいまとまりを作る (setsid 相当) … 生き残って完了した
#   Windows 側の起動プログラムは既に同じ対策 (Setsid) を持っており、
#   Mac / Linux だけがこの対策から取り残されていました。
#   なお macOS には setsid コマンドが無いため、python3 / perl で代替します。
# ============================================================
# ★2026-10-22 是正: 「入口だけの python3」で切り離さない。
# 【なぜ要るか — 実測】
#   開発用の道具 (Command Line Tools) を入れていない普通の Mac では、/usr/bin/python3 は
#   導入を促すための入口 (git と同じ中身の小さなプログラム) で、実行しても失敗して終わる。
#   従来は「python3 という名前がある」だけで切り離しに使っていたため、
#   親は「DETACHED via python3」と書いて終わり、続きの処理 (更新の確認・適用) は
#   一度も走らなかった。エラーも外へ届かないので、黙って古いままになる。
#   2026-10-22 の本番台帳: 公開後に使われた Mac 27 台のうち最新版に上がったのは 6 台
#   (Windows は 33 台中 25 台)。砂箱で 2056.8 を再現し、道具の有無だけを変えて
#   「ある=続きが走る / ない=1 行書いて終わる」を確かめた。
#   この手順の下の方 (_py3_usable) は同じ落とし穴を既に避けていたが、切り離しだけが漏れていた。
# 判定は python3 を起動せずに行う (入口だけの python3 は起動するたびに導入の画面を出すため)。
_sl_py3_can_detach() {
    local p
    # 試験の差し替え口: 本物の入口 (/usr/bin/python3) と道具の所在の確かめ方を、
    # 砂箱でだけ別の場所に向ける (砂箱では /usr/bin を書き換えられないため)。
    local stub="${SOLOPTILINK_TEST_PY3_STUB_PATH:-/usr/bin/python3}"
    local xsel="${SOLOPTILINK_TEST_XCODE_SELECT:-/usr/bin/xcode-select}"
    p="$(command -v python3 2>/dev/null)" || return 1
    [ -n "$p" ] || return 1
    case "$(uname -s 2>/dev/null)" in
        Darwin)
            # 開発用の道具が無いとき、/usr/bin/python3 は入口だけ
            if [ "$p" = "$stub" ] && ! "$xsel" -p >/dev/null 2>&1; then
                return 1
            fi ;;
        MINGW*|MSYS*|CYGWIN*)
            # Windows の「アプリ実行エイリアス」も入口だけ (起動するとストアを開いて失敗する)
            case "$p" in *WindowsApps*) return 1 ;; esac ;;
    esac
    return 0
}
_sl_detach_self() {   # $1 = 自分自身のパス, 以降 = 元の引数
    local self="$1"; shift
    if command -v setsid >/dev/null 2>&1; then
        SOLOPTILINK_AU_DETACHED=1 SOLOPTILINK_AUTOUPDATE_REEXEC=1 \
            setsid bash "$self" "$@" >> "$LOG_FILE" 2>&1 &
        log "DETACHED via setsid"
        return 0
    fi
    if command -v python3 >/dev/null 2>&1 && ! _sl_py3_can_detach; then
        log "DETACH_SKIP_PY3_STUB python3 は入口だけのため使いません ($(command -v python3 2>/dev/null))"
    fi
    if _sl_py3_can_detach; then
        SOLOPTILINK_AU_DETACHED=1 SOLOPTILINK_AUTOUPDATE_REEXEC=1 \
            python3 -c 'import os,sys; os.setsid(); os.execvp(sys.argv[1], sys.argv[1:])' \
            bash "$self" "$@" >> "$LOG_FILE" 2>&1 &
        log "DETACHED via python3"
        return 0
    fi
    if command -v perl >/dev/null 2>&1; then
        SOLOPTILINK_AU_DETACHED=1 SOLOPTILINK_AUTOUPDATE_REEXEC=1 \
            perl -e 'use POSIX qw(setsid); setsid(); exec @ARGV' \
            bash "$self" "$@" >> "$LOG_FILE" 2>&1 &
        log "DETACHED via perl"
        return 0
    fi
    # 切り離す手段が無い端末。従来どおり続けるが、途中で止まりうることを記録に残す
    # (「完了しなかった」を「問題なし」に丸めないため)。
    log "DETACH_UNAVAILABLE 切り離す手段(setsid/python3/perl)が無いため、時間切れで中断される可能性があります"
    return 1
}

# ── フック経由なら、ここで新しいまとまりへ移してから続きを行う (2026-09-02 新設) ──
# ★ この判定は「ロックを取る前」かつ「終了時の後始末を仕掛ける前」に置くこと。
#   後ろに置くと、親が役目を終えて閉じるときの後始末が、切り離した先が今まさに
#   実行している自分自身のコピーを消してしまいます (実装時に一度踏みかけました)。
# --force での実行と、既に切り離した先での実行は、そのまま前景で最後まで進みます。
if [ "${1:-}" != "--force" ] \
   && [ "${SOLOPTILINK_FORCE_UPDATE:-${SOLAI_FORCE_UPDATE:-0}}" != "1" ] \
   && [ "${SOLOPTILINK_AU_DETACHED:-}" != "1" ]; then
    if _sl_detach_self "$0" "$@"; then
        exit 0
    fi
fi

# ============================================================
# 呼び出し口 (スラッシュで呼ぶ機能) を、足りていなければ配置する (2026-09-06 新設)
# ------------------------------------------------------------
# ★なぜここか:
#   すでにお使いのお客様は、導入プログラムをもう一度動かすことがない。
#   本体だけ新しくなっても ~/.claude/skills に呼び出し口が無ければ、
#   お客様が /soloptilink-boost と打っても何も起きない。そのとき応答するのは
#   素の Claude であり、「これを入れる意味は?」に「意味がない」と答える事故が
#   実際に起きた (配置処理は v2056.3 まで Mac/Windows とも 0 箇所だった)。
# ★下方にある配置処理 (_sl_skill_freshness_pass) では救えない — 実測で確認:
#   あれは「更新の確認間隔 (CHECK_INTERVAL=24時間) を過ぎたか」の判定より後ろに
#   置かれており、間隔内の実行はその手前で終了するため到達しない。
#   つまり 1 日 1 回しか走らず、その回に置けなかった端末は翌日まで直らない。
#   お客様側の自己修復 (skill-sot-guard の heal) でも救えない。あれは
#   「1 件も置かれていない端末では差分 0 件 = 正常」と判定して何もしないため。
# ★ここは毎回のセッション開始で必ず走る。ただし正確には「切り離した先 (背景の子)」で走る:
#   上の detach ブロックで親は exit 0 するため、この行に到達するのは背景実行された
#   自分自身のコピーか、--force / AU_DETACHED=1 での実行である。背景で走るので
#   セッション開始を待たせない。足りない分だけを補い、足りていれば何もしない
#   (揃っている端末での実測 0.5 秒以内)。既にあるものには触れない。
# ============================================================
if [ "${SOLOPTILINK_ENTRYPOINT_BOOTSTRAP:-on}" != "off" ]; then
    _SL_EPB="$SL_DIR/lib/entrypoint-bootstrap.sh"
    [ -f "$_SL_EPB" ] && bash "$_SL_EPB" place --silent >/dev/null 2>&1 || true
fi

# ============================================================
# 退去指示の受信 (2026-09-12 新設 / RQ-202・RQ-203・RQ-204・RQ-205・RQ-211)
# ------------------------------------------------------------
# ★なぜここか (実測に基づく):
#   ご解約が確定したお客様の端末から当社の構成要素を取り除く「退去」の指示は、
#   既にサーバーへ届いている通信の応答に相乗りして届く。新しい常駐処理は作らない。
#   その受け口をここに置く理由は、この直上のブロックに書かれている先例と同じ:
#   更新の確認間隔 (24時間) の判定より **後ろ** に置くと、1 日 1 回しか走らない。
#
# ★2026-09-12 に実測して分かったこと (設計書の記述と食い違う):
#   設計書は「bash の稼働確認は毎セッション開始・毎メッセージ走る」と書いているが、
#   実物の稼働確認 (_sl_report_version) の呼び出しはこのファイルの 1 か所だけで、
#   その位置は 24 時間判定より後ろにある。つまり実際には 24 時間に 1 回しか走らない。
#   「毎回届く経路が応答を捨てている」ではなく「毎回届く経路が無かった」。
#   よってここへ独立した受信を置く。既存の版報告 (_sl_report_version) には
#   1 バイトも手を入れない (テレメトリの外形を変えないため)。
#
# ★判定は action が evict であることの単独条件 (RQ-204)。
#   失効しただけ (S2) の応答では絶対に起動しない。混ぜた瞬間が誤爆の型になる。
#
# ★python3 に依存しない (RQ-205)。
#   更新確認の資格提示は python3 が無いと空になるため、python3 の無い端末が
#   S2 に入った瞬間から退去指示を受け取れなくなる。稼働確認は端末 ID を本文で
#   送るので python3 に依らない。ここは sed と grep だけで書く。
#
# 受信の要否: SOLOPTILINK_EVICT_POLL=on|off (★2026-09-30 から既定 off)
#   ★2026-09-30 (案A・遠隔削除を載せない便): 既定を on → off に改めた。
#     理由① この便は退去の本体 (lib/evict/evict.sh 等) を配布物に載せない。受けても起こす先が無い。
#     理由② 受信はお客様の送信のたびに稼働確認を 1 本 (最大 5 秒) 送っていた。起こす先の無い受信の
#            ために毎回待たせない。
#     理由③ お客様の端末へ実際に出ている状態 (v2056.8 の配布物) は受信 0 件。既定 off はそれと同じ。
#     遠隔削除を載せる便で on に戻す。on に戻した便は焼成の便の判定 (evict-defer-lane.sh) が
#     退去便へ倒すため、退去便の 12 条件を通らない限り焼けない。
#   明示的に off を指定したときだけ、その事実を .evict-poll.log に残す (既定の off では毎回書かない。
#   送信のたびに 1 行ずつ増え続けるため)。
# 受信の間隔: SOLOPTILINK_EVICT_POLL_INTERVAL 秒 (既定 0 = 毎回)
#             失効マーカーがある端末 (S2) は 24 時間に 1 回に絞る (RQ-211)
# ============================================================
# ============================================================
# 完全停止のご指定 (ライセンス確認の通信も止める) を読む (2026-09-25)
# ------------------------------------------------------------
# この台本は生存確認 (/devices/heartbeat) を 2 本送る (下の退去照会と版報告)。
# 取り決め (lib/telemetry-consent.contract) は「稼働の確認」を完全停止の対象と
# 定めているが、印を読んでいたのは実行本体 (Go) だけで、この台本は完全停止を
# 選んだ端末からも送っていた。判定は同意の層 (telemetry-consent.sh auth-egress)
# に 1 つだけ置き、ここでは別の処理として呼ぶ (印の名前をここへ書き写さない)。
#
# ★お知らせの停止 (品質統計・エラー報告の停止) では生存確認は止めない。
#   ご契約の確認に必要な経路として「停止できません」と開示しているため。
# ★確かめられないときは送る側へ倒す (実行本体と同じ)。その事実は記録に残す。
# ★更新の確認・取得はこの判定の対象外 (完全停止でも止めない)。台帳に明記済み。
# 戻り値: 0=止める / 1=送ってよい
_sl_auth_egress_stopped() {
    local consent="${SL_DIR}/lib/telemetry-consent.sh" reason=""
    if [ -f "$consent" ]; then
        reason=$(bash "$consent" auth-egress 2>/dev/null | head -1)
    fi
    case "$reason" in
        auth-stopped-by-env|auth-stopped-by-file)
            log "AUTH_EGRESS_STOPPED heartbeat skipped reason=${reason}"
            return 0 ;;
        auth-sending) return 1 ;;
    esac
    log "AUTH_EGRESS_NOT_DETERMINABLE heartbeat continues reason=${reason:-consent-layer-absent}"
    return 1
}
_sl_evict_jfield() {   # $1=JSON文字列 $2=キー
    printf '%s' "$1" | sed -n 's/.*"'"$2"'"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1
}
_sl_evict_ffield() {   # $1=JSONファイル $2=キー
    [ -f "$1" ] || return 0
    sed -n 's/.*"'"$2"'"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$1" | head -1
}
_sl_evict_version() {
    local v=""
    [ -f "${SL_DIR}/chain.sh" ] && v=$(grep 'readonly VERSION=' "${SL_DIR}/chain.sh" 2>/dev/null | head -1 | grep -o '"[^"]*"' | tr -d '"')
    [ -z "$v" ] && [ -f "${SL_DIR}/VERSION" ] && v=$(tr -d '[:space:]' < "${SL_DIR}/VERSION" 2>/dev/null)
    [ -z "$v" ] && v="0.0.0"
    printf '%s' "$v" | sed 's/^v//'
}
# 稼働確認の本文を組む (python3 非依存・既存の sed 経路と同じ作り)
_sl_evict_hb_body() {
    local act="${SL_DIR}/activation.json" lic="${SL_DIR}/license.json"
    local did tok fp em ver body
    did=$(_sl_evict_ffield "$lic" device_id); [ -n "$did" ] || did=$(_sl_evict_ffield "$act" device_id)
    tok=$(_sl_evict_ffield "$lic" token);     [ -n "$tok" ] || tok=$(_sl_evict_ffield "$act" token)
    [ -n "$did" ] && [ -n "$tok" ] || return 1
    fp=$(_sl_evict_ffield "$act" fingerprint)
    em=$(_sl_evict_ffield "$act" email)
    ver=$(_sl_evict_version)
    body=$(printf '{"device_id":"%s","token":"%s","current_version":"%s","app_version":"%s"' "$did" "$tok" "$ver" "$ver")
    [ -n "$fp" ] && body="${body},\"fingerprint\":\"${fp}\""
    [ -n "$em" ] && body="${body},\"email\":\"${em}\""
    printf '%s}' "$body"
}
# 受信してよいか (間隔の判定)。0=受信する 1=見送る
_sl_evict_due() {
    local stamp="${SL_DIR}/.evict-poll-stamp" interval now last
    interval="${SOLOPTILINK_EVICT_POLL_INTERVAL:-0}"
    # 失効マーカーがある端末 (S2) は照会を退去指示の受信だけ・1 日 1 回に絞る (RQ-211)
    [ -f "${SL_DIR}/.license-revoked" ] && interval=86400
    case "$interval" in ''|*[!0-9]*) interval=0 ;; esac
    [ "$interval" -eq 0 ] && return 0
    [ -f "$stamp" ] || return 0
    now=$(date +%s)
    last=$(cat "$stamp" 2>/dev/null); case "$last" in ''|*[!0-9]*) last=0 ;; esac
    [ $((now - last)) -ge "$interval" ]
}
# ------------------------------------------------------------
# 退去をフックから切り離して起こす (2026-09-25)
#   ★このファイルは打ち切り 30 秒のフックとして呼ばれるが、退去は実物大で 11〜23 分かかる。
#     同期で呼ぶと段 2 の途中で止まり、次のセッションでも同じ所で止まって永久に終わらなかった。
#   ★Claude Code はフックを打ち切るとき、フックの子孫と、フックと同じ処理群をまとめて止める
#     (別 HOME ではなく本物の claude で実測。nohup だけ・別セッション化だけの子は止まった)。
#     生き残るのは「間の親が先に終わって子孫から外れ、かつ別の処理群にいる」子だけ。
#     → ( set -m; nohup … & ) で二重に起こす。set -m で別の処理群になり、( ) がすぐ終わって子孫から外れる。
#   ★入出力はすべて切る (握ったままだとフックが終わらず打ち切りを待つことになる)。
#     報告は退去側が記録の置き場 (~/.claude/.soloptilink-evict-report.txt) へ書く。
# ------------------------------------------------------------
# 錠の場所。★evict.sh sl_evict_lock_path と同じ式 (変えるときは両方)
_sl_evict_lock_path() {
    local h
    h=$(printf '%s' "$HOME" | /usr/bin/cksum 2>/dev/null | /usr/bin/cut -d' ' -f1)
    printf '%s/.soloptilink-evict-%s-%s.lock' "${SL_EVICT_LOCK_BASE:-/tmp}" "$(/usr/bin/id -u 2>/dev/null)" "${h:-0}"
}
# 退去が走っているか (0=走っている)。持ち主の番号が生きていて、それが退去であること
_sl_evict_running() {
    local d pid cmd mt
    d=$(_sl_evict_lock_path)
    [ -d "$d" ] || return 1
    pid=$(cat "$d/pid" 2>/dev/null)
    case "$pid" in
        ''|*[!0-9]*)
            # 取った直後 (番号を書く前) は走っている側に倒す。10 秒を過ぎたら古い錠
            # (ここで永久に「走っている」と見ると、退去が二度と起こされない)
            mt=$(/usr/bin/stat -f %m "$d" 2>/dev/null || /usr/bin/stat -c %Y "$d" 2>/dev/null)
            case "$mt" in ''|*[!0-9]*) return 1 ;; esac
            [ $(( $(date +%s) - mt )) -lt 10 ]
            return ;;
    esac
    kill -0 "$pid" 2>/dev/null || return 1
    cmd=$(/bin/ps -p "$pid" -o command= 2>/dev/null)
    case "$cmd" in *evict*) return 0 ;; esac
    return 1
}
# 再開の印 (本体フォルダ直下 .evict-progress) の欄を読む
_sl_evict_progress() {   # $1=キー
    sed -n "s/^$1=//p" "${SL_DIR}/.evict-progress" 2>/dev/null | head -1
}
# $1=事由 $2=指示ファイル
_sl_evict_spawn() {
    if [ -f "${SL_DIR}/lib/evict/evict.sh" ]; then
        ( set -m
          nohup bash "${SL_DIR}/lib/evict/evict.sh" --execute --detached \
              --reason "$1" --order-file "$2" </dev/null >/dev/null 2>&1 & ) 2>/dev/null
        log "EVICT_SPAWNED engine=bash reason=$1"
        return 0
    fi
    # bash 版が無い端末ではランチャーの副命令へ回す (bash 不在の Windows と同じ口)
    if [ -x "${SL_DIR}/soloptilink" ]; then
        ( set -m
          nohup "${SL_DIR}/soloptilink" --evict --execute \
              --reason "$1" --order-file "$2" </dev/null >/dev/null 2>&1 & ) 2>/dev/null
        log "EVICT_SPAWNED engine=launcher reason=$1"
        return 0
    fi
    return 1
}
_sl_evict_check() {
    # ★既定 off (2026-09-30)。on のときだけ受信する。on / off 以外の値は off として扱う。
    #   焼成の便の判定はこの行の既定値 (SOLOPTILINK_EVICT_POLL:-off) を字面で読む。書き方を変えないこと。
    if [ "${SOLOPTILINK_EVICT_POLL:-off}" != "on" ]; then
        if [ -n "${SOLOPTILINK_EVICT_POLL+set}" ]; then
            printf '%s off\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ)" >> "${SL_DIR}/.evict-poll.log" 2>/dev/null
        fi
        return 0
    fi
    # ★退去が走っているあいだは何もしない (照会も、指示ファイルの書き直しもしない)。
    #   退去は段 5b で指示ファイルを消し、段 7 で本体フォルダを空にして消す。
    #   ここで書き直すと本体フォルダが空にならず残る。以後の更新処理も走らせない
    #   (退去が消している最中の本体へ、更新が部品を書き戻すため)。
    if _sl_evict_running; then
        log "EVICT_RUNNING skip"
        exit 0
    fi
    local order="${SL_DIR}/.evict-order.json" pstate pepoch now retry
    pstate=$(_sl_evict_progress state)
    # 前回の退去が失敗で終わってから間もなければ見送る。切り離した退去は毎回最後まで走るため、
    # 見送らないと送信のたびに控えZIPが増える (中断の理由は報告と記録に残っている)
    if [ "$pstate" = "failed" ]; then
        pepoch=$(_sl_evict_progress epoch); now=$(date +%s)
        retry="${SOLOPTILINK_EVICT_RETRY_AFTER:-21600}"
        case "$pepoch" in ''|*[!0-9]*) pepoch=0 ;; esac
        case "$retry" in ''|*[!0-9]*) retry=21600 ;; esac
        if [ $((now - pepoch)) -lt "$retry" ]; then
            log "EVICT_RETRY_WAIT since=${pepoch}"
            return 0
        fi
    fi
    # 途中で止まった退去 (印が running のまま・持ち主はもういない) は、照会なしで起こし直す。
    # ★段 3 より前に止まった場合だけここへ来る (段 3 の後はフックが外れていて呼ばれない)。
    #   指示の新しさ (72 時間) と解約の確定は退去側の三重ゲートが改めて確かめる。
    if [ "$pstate" = "running" ] && [ -f "$order" ]; then
        _sl_evict_spawn "$(_sl_evict_progress reason)" "$order" && exit 0
    fi
    command -v curl >/dev/null 2>&1 || return 0
    # 完全停止のご指定があれば照会しない (退去指示も受け取らない = ご指定どおり)
    _sl_auth_egress_stopped && return 0
    _sl_evict_due || return 0
    local body resp reason
    body="$(_sl_evict_hb_body)" || return 0
    [ -n "$body" ] || return 0
    date +%s > "${SL_DIR}/.evict-poll-stamp" 2>/dev/null
    # ★-f / --fail を付けないこと。付けると 403 の本文が捨てられ、
    #   解約で 403 を返される端末 (まさに退去の対象) に指示が届かなくなる。
    resp=$(curl -s -L --max-time 5 --connect-timeout 3 \
        -X POST -H "Content-Type: application/json" \
        -d "$body" "${API_BASE}/devices/heartbeat" 2>/dev/null)
    [ -n "$resp" ] || return 0
    printf '%s' "$resp" | grep -q '"action"[[:space:]]*:[[:space:]]*"evict"' || return 0
    reason=$(_sl_evict_jfield "$resp" evict_reason)
    [ -n "$reason" ] || reason="contract_ended"
    # 指示ファイルを書いてから起こす (台本側は指示が無ければ何もしない)
    printf '%s' "$resp" > "$order" 2>/dev/null || return 0
    # ★同期で呼ばない (打ち切り 30 秒で止まる)。切り離して起こし、以後の更新処理は走らせない
    _sl_evict_spawn "$reason" "$order" && exit 0
    return 0
}
_sl_evict_check

# ============================================================
# 長期記憶の呼び出し口を、足りていなければ登録し直す (2026-08-27 新設)
# ------------------------------------------------------------
# ★なぜここか:
#   すでにお使いのお客様は、導入プログラムをもう一度動かすことがない。
#   本体だけ新しくなっても、呼び出し口が端末側の設定に無ければ
#   **長期記憶は一度も動かない**。この処理は毎回のセッション開始で走るため、
#   ここで足りない分だけを補う。足りているときは何もしない (増えない)。
_heal_memory_hooks() {
    local inst="$SL_DIR/lib/memory/memory-hooks-install.sh"
    [ -f "$inst" ] || return 0
    bash "$inst" check >/dev/null 2>&1 && return 0
    if bash "$inst" install >/dev/null 2>&1 && bash "$inst" check >/dev/null 2>&1; then
        log "MEMORY_HOOKS_INSTALLED"
        # RQ-405: 置いた設定フックの位置を台帳へ (登録した側は自分の位置を知らないため
        #         settings.json を読み直して確定する)
        _sl_manifest_note_settings_hooks "auto-update:memory-hooks"
    else
        log "MEMORY_HOOKS_INSTALL_FAILED"
    fi
    return 0
}
_heal_memory_hooks

# ============================================================
# 更新の問い合わせ先を、許可した宛先だけに限る
# ------------------------------------------------------------
# この経路には端末情報と版数が流れ、受け取った内容に従って本体一式を
# 置き換える。宛先を環境変数で自由に差し替えられる状態は、
# 「更新の配布元をあとから乗っ取れる」ことと同じである。
# 暗号化されていない通信（http://）と、許可していない宛先のときは、
# 何も送らず、何も取得せずに終了する。
# ============================================================
_sl_api_base_allowed() {
    case "$1" in
        https://admin-dashboard-blue-alpha-78.vercel.app|https://admin-dashboard-blue-alpha-78.vercel.app/*) return 0 ;;
        https://localhost|https://localhost/*|https://localhost:*) return 0 ;;
        https://127.0.0.1|https://127.0.0.1/*|https://127.0.0.1:*) return 0 ;;
        *) return 1 ;;
    esac
}
if ! _sl_api_base_allowed "$API_BASE"; then
    log "API_BASE_REJECTED base=$API_BASE"
    echo "更新の接続先として許可されていない宛先が指定されていたため、更新を行いませんでした。" >&2
    exit 0
fi

# ============================================================
# スラッシュメニューから boost が消える不具合の恒久対策:
# スキル/コマンドのアトミック置換 helper
# - 従来の `cp src dst` は truncate→write の非アトミック更新で、書込中に
#   Claude Code がスキル走査すると SKILL.md が「空/途中」に見えてメニュー脱落した。
# - _sl_atomic_cp: 同ディレクトリの一時名に cp してから mv (rename は原子的)。
# - _sl_atomic_dir_replace: references 等のディレクトリを「新を横に展開→旧を退け→即 mv」
#   で置換する (従来の rm -rf → cp -R は cp の間ずっと欠落窓が開いていた)。
# ============================================================
_sl_atomic_cp() {
    local src="$1" dst="$2" tmp
    [ -f "$src" ] || return 1
    mkdir -p "$(dirname "$dst")" 2>/dev/null
    tmp="${dst}.slnew.$$"
    if cp "$src" "$tmp" 2>/dev/null && mv -f "$tmp" "$dst" 2>/dev/null; then
        return 0
    fi
    rm -f "$tmp" 2>/dev/null
    # rename 不能環境のみ従来コピーへフォールバック (無いよりまし)
    cp "$src" "$dst" 2>/dev/null
}
_sl_atomic_dir_replace() {
    local srcdir="$1" dstdir="$2" tmp old
    [ -d "$srcdir" ] || return 1
    mkdir -p "$(dirname "$dstdir")" 2>/dev/null
    tmp="${dstdir}.slnew.$$"
    old="${dstdir}.slold.$$"
    rm -rf "$tmp" 2>/dev/null
    cp -R "$srcdir" "$tmp" 2>/dev/null || { rm -rf "$tmp"; return 1; }
    if [ -d "$dstdir" ]; then
        mv "$dstdir" "$old" 2>/dev/null || { rm -rf "$dstdir" 2>/dev/null; }
    fi
    mv "$tmp" "$dstdir" 2>/dev/null || { rm -rf "$tmp"; [ -d "$old" ] && mv "$old" "$dstdir" 2>/dev/null; return 1; }
    rm -rf "$old" 2>/dev/null
    return 0
}

# ============================================================
# ★2026-08-01 PFP-201: スキル同梱資産 (SKILL.md / references/ 以外) を適用する
# ============================================================
# 事案: soloptilink-boost/SKILL.md は Step 0.55/0.65/0.88/0.95 で
#   node ~/.claude/skills/soloptilink-boost/<name>-link/<name>-bridge.mjs
# の実行を指示しているのに、更新の適用側 (do_update / heal_skill_drift) は
# SKILL.md と references/ しか名指しで複製していなかった。パッケージに資産が
# 入っていても顧客端末には置かれず、存在しないファイルを叩く宙吊り参照になる。
# 名指しの列挙は「新しく増えた資産」を構造的に取りこぼす。ここでは何が入って
# いるかを判断せず、パッケージに在るものをそのまま運ぶ (詰める側で選別済み)。
_sl_copy_skill_extras() {
    local srcdir="$1" dstdir="$2" entry name
    [ -d "$srcdir" ] || return 0
    for entry in "$srcdir"/* "$srcdir"/.[!.]*; do
        [ -e "$entry" ] || continue
        name="$(basename "$entry")"
        # SKILL.md と references/ は呼び出し側がアトミック置換で先に処理済み
        case "$name" in SKILL.md|references) continue ;; esac
        if [ -d "$entry" ]; then
            _sl_atomic_dir_replace "$entry" "$dstdir/$name" || true
        else
            mkdir -p "$dstdir" 2>/dev/null
            _sl_atomic_cp "$entry" "$dstdir/$name" || true
        fi
    done
    return 0
}

# ============================================================
# PFP-177: 管理者専用スキルの顧客端末残存を自己修復
# 2026-04-16〜07-20 の payload に soloptilink-release が混入し、旧バイナリは
# 実行毎にそれを ~/.claude/skills へ書き戻す。本フックはセッション開始毎に
# 走るため、ここでの除去が旧バイナリ端末の恒常的な救済層になる。
# 管理者端末 (.admin_mode あり) では SoT (~/.claude) を温存し配信ソース側のみ浄化。
# ============================================================
_sl_is_admin_only_skill() {
    case "$1" in soloptilink-release|soloptilink-deploy|soloptilink-doctor) return 0 ;; esac
    return 1
}
_sl_purge_admin_skills() {
    local _n _purged=0
    for _n in soloptilink-release soloptilink-deploy soloptilink-doctor; do
        for _t in "$SL_DIR/skills/$_n" "$SL_DIR/launcher/skills/$_n"; do
            [ -e "$_t" ] && rm -rf "$_t" 2>/dev/null && _purged=$((_purged + 1))
        done
        if [ ! -f "$SL_DIR/.admin_mode" ]; then
            [ -e "$CLAUDE_DIR/skills/$_n" ] && rm -rf "$CLAUDE_DIR/skills/$_n" 2>/dev/null && _purged=$((_purged + 1))
            [ -f "$CLAUDE_DIR/commands/$_n.md" ] && rm -f "$CLAUDE_DIR/commands/$_n.md" 2>/dev/null && _purged=$((_purged + 1))
        fi
    done
    [ "$_purged" -gt 0 ] && log "ADMIN_SKILL_PURGED count=$_purged (PFP-177)"
    return 0
}
_sl_purge_admin_skills 2>/dev/null || true

# ============================================================
# v2034.2 で堅牢化: 共通 curl helper
# - stderr を .error-log に集約 (黙殺禁止)
# - リトライ 3回 / 接続タイムアウト 10秒 / 全体タイムアウト引数化
# - --fail-with-body で HTTP エラー時もボディ取得
# - rc != 0 の時のみ error-log に記録 (成功時はノイズ無し)
# ============================================================
# ------------------------------------------------------------------
# 更新経路の認可 (N-03 / Q-19) — 端末資格の提示  2026-08-02
# ------------------------------------------------------------------
# 配信サーバ側は更新経路の認可を段階導入している (①記録 → ②警告 → ③遮断)。
# ③へ上げたとき、資格を提示しない端末は更新できなくなり、更新できない端末は
# 自力で新しい版へ上がれない = 恒久ブリックになる。だからここで先に提示側を揃える。
#
# 資格の解決は本体の唯一の実装 (lib/update-authz/device-credentials.sh) に任せる。
# 各スクリプトへ書き写すと、片方だけ直されてもう片方が古いまま残るため。
# ★読み込めない世代でも従来どおり動く (資格を添えないだけ) 。ここで失敗させると
#   更新経路そのものを失い、更新で直すという道が塞がる。
_UA_CRED_LIB="$SL_DIR/lib/update-authz/device-credentials.sh"
# shellcheck source=/dev/null
[ -f "$_UA_CRED_LIB" ] && . "$_UA_CRED_LIB" 2>/dev/null || true

_sl_curl() {
    local method="$1" url="$2" outfile="${3:-}" timeout="${4:-15}"
    local error_log="$SL_DIR/.error-log"
    # 更新経路 (updates/check・updates/download) にだけ端末資格を添える。
    # 他の宛先へ資格を配らないため、URL で対象を限定する。
    local -a _ua_hdrs=()
    case "$url" in
        */updates/check*|*/updates/download*)
            if type ua_have_device_credentials >/dev/null 2>&1 && ua_have_device_credentials; then
                _ua_hdrs=(-H "X-Soloptilink-Device-Id: $(ua_device_id)" \
                          -H "X-Soloptilink-Fingerprint: $(ua_device_fingerprint)")
            fi
            ;;
    esac
    # PFP-101 (2026-06-10): -L 必須。GitHub Releases 等の 302 リダイレクト配信で
    # 追従しないと空ボディ (0バイト) を保存し DOWNLOAD_TOO_SMALL で全更新が失敗する
    # --fail-with-body は curl 7.76 未満 (旧 macOS 標準等) に存在せず、付けると
    # 全呼び出しが「未知のオプション」で即失敗する。一度だけ機能検出して使い分ける。
    if [ -z "${_SL_CURL_FWB_CHECKED:-}" ]; then
        _SL_CURL_FWB=""
        curl --fail-with-body --version >/dev/null 2>&1 && _SL_CURL_FWB="--fail-with-body"
        _SL_CURL_FWB_CHECKED=1
    fi
    local curl_args=(-s -L --max-redirs 5 --connect-timeout 5 --retry 1 --retry-delay 1)
    [ -n "${_SL_CURL_FWB}" ] && curl_args+=("${_SL_CURL_FWB}")
    if [ -n "$outfile" ]; then
        # ファイルDL (大容量): 絶対期限を課さず「停滞」だけで中断する。
        # 低速回線での取得失敗への対策: 絶対 --max-time (90/120s) が低速回線の
        # 大容量DL (11〜19MB) を構造的に失敗させていた。--speed-limit/--speed-time は
        # 「120秒間 実効1B/s未満 = 停滞」のみを異常とみなす (完走時間は無制限に近い保険値)。
        curl_args+=(--speed-limit 1 --speed-time 120 --max-time 7200 -o "$outfile")
    else
        # 小さな API 呼び出し: 従来どおり短い絶対期限
        curl_args+=(--max-time "$timeout")
    fi
    local stderr_capture
    stderr_capture=$(mktemp)
    local response rc
    # ★空配列の展開は bash 3.2 + set -u で "unbound variable" になる。
    #   ${arr[@]+"${arr[@]}"} で「空なら何も展開しない」形にする。
    if [ "$method" = "GET" ]; then
        response=$(curl "${curl_args[@]}" ${_ua_hdrs[@]+"${_ua_hdrs[@]}"} "$url" 2>"$stderr_capture")
        rc=$?
    else
        response=$(curl "${curl_args[@]}" ${_ua_hdrs[@]+"${_ua_hdrs[@]}"} -X "$method" "$url" 2>"$stderr_capture")
        rc=$?
    fi
    if [ $rc -ne 0 ]; then
        echo "$(date '+%Y-%m-%dT%H:%M:%S') [curl] FAIL rc=$rc url=$url $(cat "$stderr_capture" | tr '\n' ' ' | head -c 200)" >> "$error_log" 2>/dev/null
    fi
    rm -f "$stderr_capture"
    [ $rc -eq 0 ] && echo "$response"
    return $rc
}

# ========================================
# 排他ロック（複数ウィンドウ同時実行防止）
# ========================================
# mkdir はアトミック操作 → 安全なロック
if ! mkdir "$LOCK_DIR" 2>/dev/null; then
    # ロックが存在 → 別インスタンスが実行中
    # ただし5分以上経過したロックはスタール（古い）とみなす
    if [ -d "$LOCK_DIR" ]; then
        LOCK_MTIME=$(stat -f %m "$LOCK_DIR" 2>/dev/null || stat -c %Y "$LOCK_DIR" 2>/dev/null || echo 0)
        NOW_TS=$(date +%s)
        LOCK_AGE=$((NOW_TS - LOCK_MTIME))
        if [ "$LOCK_AGE" -gt 300 ]; then
            rmdir "$LOCK_DIR" 2>/dev/null
            mkdir "$LOCK_DIR" 2>/dev/null || exit 0
        else
            exit 0
        fi
    else
        exit 0
    fi
fi
# ロック解除のtrap（親プロセス終了時）+ 自己コピー掃除 (PFP-101)
trap "rmdir '$LOCK_DIR' 2>/dev/null; [ -n '$_SL_SELF_COPY' ] && rm -f '$_SL_SELF_COPY' 2>/dev/null" EXIT

# ========================================
# 強制更新フラグ（--force または SOLOPTILINK_FORCE_UPDATE=1）
# ========================================
FORCE_UPDATE=false
if [ "${1:-}" = "--force" ] || [ "${SOLOPTILINK_FORCE_UPDATE:-${SOLAI_FORCE_UPDATE:-0}}" = "1" ]; then
    FORCE_UPDATE=true
fi

# ========================================
# 頻度チェック（24時間以内ならスキップ、--force時は無視）
# ========================================
if [ "$FORCE_UPDATE" = false ] && [ -f "$CACHE_FILE" ]; then
    LAST_CHECK=$(cat "$CACHE_FILE" 2>/dev/null || echo "0")
    # 数値チェック
    case "$LAST_CHECK" in
        ''|*[!0-9]*) LAST_CHECK=0 ;;
    esac
    NOW=$(date +%s)
    ELAPSED=$((NOW - LAST_CHECK))
    if [ "$ELAPSED" -lt "$CHECK_INTERVAL" ]; then
        exit 0
    fi
fi

# ========================================
# 現在のバージョンを取得
# ========================================
CURRENT_VERSION=""
if [ -f "$SL_DIR/chain.sh" ]; then
    CURRENT_VERSION=$(grep 'readonly VERSION=' "$SL_DIR/chain.sh" 2>/dev/null | head -1 | grep -o '"[^"]*"' | tr -d '"')
elif [ -f "$SL_DIR/VERSION" ]; then
    CURRENT_VERSION=$(cat "$SL_DIR/VERSION" 2>/dev/null | tr -d '[:space:]')
fi
# chain.sh も VERSION も無い → 初回インストール扱い（バージョン0.0.0として更新チェック）
[ -z "$CURRENT_VERSION" ] && CURRENT_VERSION="0.0.0"

# ========================================
# Migration 自動適用 (idempotent / NOOP if applied)
# v2027.0+ 既存顧客遡及配線レーン
# ========================================
if [ -d "$SL_DIR/migration" ]; then
    # ★2026-10-26: 並び順を言語設定に左右させない (導入台本と同じ理由・C の順 = . が _ より前)
    _au_saved_lc_collate="${LC_COLLATE-}"
    LC_COLLATE=C
    for mig in "$SL_DIR/migration/"v*.sh; do
        [ -f "$mig" ] || continue
        mig_name=$(basename "$mig" .sh)
        # state ファイルを読み、既に適用済みの migration はスキップ
        if [ -f "$SL_DIR/.migration-state.json" ] && grep -q "\"${mig_name}\"" "$SL_DIR/.migration-state.json" 2>/dev/null; then
            continue
        fi
        bash "$mig" >> "$SL_DIR/.migration.log" 2>&1 || true
    done
    if [ -n "$_au_saved_lc_collate" ]; then LC_COLLATE="$_au_saved_lc_collate"; else unset LC_COLLATE; fi
fi

# ========================================
# PFP-064b (2026-07-06): スキル表記の毎回追従パス (every-run / idempotent / 軽量)
# ----------------------------------------
# 実欠陥: SoT (~/.claude/commands/<skill>.md) は導入時版のまま更新対象になっておらず、
# 更新直後の heal が新 SKILL.md を旧版へ巻き戻し「本体は最新・表記は導入時版」に固着した
# (実例: 本体 v2050.1 で picker 表記 v2038.0)。本パスは毎回の起動で
# 「本体側 skills (配布で更新済) の版 > SoT/picker の版」の時だけ追従コピーする。
# 版数が取れない・同版・SoT が新しい場合は無操作 (管理者の正典編集を壊さない)。
# ========================================
_sl_skill_ver_num() {
    local v
    v=$(head -15 "$1" 2>/dev/null | grep -oE 'v20[0-9][0-9]\.[0-9][0-9]*' | head -1)
    [ -z "$v" ] && return 0
    local major="${v#v}"; major="${major%%.*}"
    local minor="${v##*.}"
    echo $(( major * 1000 + minor ))
}
_sl_skill_freshness_pass() {
    local sdir sname body_md target bv cv
    for sdir in "$SL_DIR/skills/soloptilink"*/; do
        [ -d "$sdir" ] || continue
        sname=$(basename "$sdir")
        # PFP-177: 管理者専用スキルは SoT/picker へ絶対に伝播させない
        _sl_is_admin_only_skill "$sname" && continue
        body_md="$sdir/SKILL.md"
        [ -f "$body_md" ] || continue
        bv=$(_sl_skill_ver_num "$body_md")
        [ -n "$bv" ] || continue
        for target in "$CLAUDE_DIR/commands/${sname}.md" "$CLAUDE_DIR/skills/$sname/SKILL.md"; do
            # ★ 2026-09-02 是正: まだ置かれていない場合に「何もしない」のをやめた。
            #   従来は既に在るファイルしか新しくしなかったため、最新版を新規導入した
            #   端末では呼び出し口が永久に作られなかった (砂箱で実測: 導入直後に
            #   自動更新を走らせても 0 件のまま)。お客様からは「導入できたのに
            #   何も起きない」という形で現れる。無ければここで作る。
            if [ ! -f "$target" ]; then
                mkdir -p "$(dirname "$target")" 2>/dev/null
                if _sl_atomic_cp "$body_md" "$target"; then
                    log "SKILL_PLACED $target (呼び出し口が無かったため新規配置)"
                    # 付随する資料は「機能の置き場」にだけ入れる。
                    # ★スラッシュ入力の置き場へ入れると、機能の中身のフォルダが
                    #   その直下に散らばる (実装時に一度やってしまい、18 件が
                    #   commands 直下に並んだ)。入れ先を必ず確かめてから運ぶ。
                    case "$target" in
                        */skills/*/SKILL.md)
                            _sl_copy_skill_extras "$sdir" "$(dirname "$target")" 2>/dev/null || true ;;
                    esac
                    # RQ-405: 置いたものを台帳へ。commands 側は 1 ファイル、
                    #   skills 側はフォルダごと (SKILL.md の親) を 1 接地点として記録する。
                    # ★付随資料を運んだ「後」に記録する。先に書くとフォルダの sha256 が
                    #   中身と食い違い、退去のとき「お客様が変えた」と誤判定されて消し残る。
                    case "$target" in
                        */commands/*.md)      _sl_manifest_note --canonical "cmd:${sname}.md" --current "${sname}.md" --kind file --path "$target" --by auto-update ;;
                        */skills/*/SKILL.md)  _sl_manifest_note --canonical "$sname" --current "$sname" --kind dir --path "$(dirname "$target")" --by auto-update
                                              _sl_file_manifest_note_file "$(dirname "$target")" "$target" ;;
                    esac
                fi
                continue
            fi
            cv=$(_sl_skill_ver_num "$target")
            if [ -n "$cv" ] && [ "$bv" -gt "$cv" ] 2>/dev/null; then
                if _sl_atomic_cp "$body_md" "$target"; then
                    log "SKILL_FRESHENED $target (→ body版)"
                    # RQ-405: 中身を新しくした行も台帳を更新する。ここを飛ばすと
                    #   台帳の sha256 が古いままになり、退去のとき当社のファイルが
                    #   「お客様が変えたもの」と判定されて消し残る。
                    case "$target" in
                        */commands/*.md)      _sl_manifest_note --canonical "cmd:${sname}.md" --current "${sname}.md" --kind file --path "$target" --by auto-update ;;
                        */skills/*/SKILL.md)  _sl_manifest_note --canonical "$sname" --current "$sname" --kind dir --path "$(dirname "$target")" --by auto-update
                                              _sl_file_manifest_note_file "$(dirname "$target")" "$target" ;;
                    esac
                fi
            fi
        done
    done
    return 0
}
_sl_skill_freshness_pass 2>/dev/null || true

# ★ 2026-09-02 新設: 専門の担当の定義が置かれていなければ配置する。
#   これが無いと編成が組めず、依頼しても担当が一体も動かない。
_sl_agents_presence_pass() {
    local src="$SL_DIR/agents" dst="$CLAUDE_DIR/agents" f n=0
    [ -d "$src" ] || return 0
    mkdir -p "$dst" 2>/dev/null || return 0
    for f in "$src"/*.md; do
        [ -f "$f" ] || continue
        [ -f "$dst/$(basename "$f")" ] && continue
        if cp "$f" "$dst/" 2>/dev/null; then
            n=$((n+1))
            # RQ-405: 置いた担当定義を台帳へ (退去はここに載っているものだけを消す)
            _sl_manifest_note --canonical "agent:$(basename "$f")" --current "$(basename "$f")" \
                              --kind file --path "$dst/$(basename "$f")" --by auto-update
        fi
    done
    [ "$n" -gt 0 ] && log "AGENTS_PLACED ${n} 件 (呼び出し口が無かったため新規配置)"
    return 0
}
_sl_agents_presence_pass 2>/dev/null || true

# バージョン文字列をサニタイズ（URL安全化）
SAFE_VERSION=$(echo "$CURRENT_VERSION" | tr -cd '0-9.')
[ -z "$SAFE_VERSION" ] && exit 0

# ========================================
# APIで最新バージョンをチェック
# ========================================
OS=$(uname -s | tr '[:upper:]' '[:lower:]')
ARCH=$(uname -m)
case "$ARCH" in
    x86_64)        ARCH="amd64" ;;
    aarch64|arm64) ARCH="arm64" ;;
esac

# OS 正規化 (2026-06-16): Git Bash/MSYS/Cygwin の uname は mingw64_nt-... 等になる。
# updates/check の os パラメータ・/updates/download・ランチャー実体名は windows で扱う必要がある。
API_OS="$OS"
LAUNCHER_NAME="soloptilink"
case "$OS" in
    mingw*|msys*|cygwin*|windows*) API_OS="windows"; LAUNCHER_NAME="soloptilink.exe" ;;
esac

# ========================================
# python3 非依存 JSON フィールド抽出 (低速回線での取得失敗への恒久対策)
# ----------------------------------------
# 従来は「python3 がなければ exit 0 (静かに何もしない)」だったため、python3 を持たない
# 標準的な Windows + Git Bash 端末では本体更新が永遠に走らず、しかも exit 0 のため
# ランチャー側は成功と誤認していた (v2040 固着デッドロックの根因)。
# 配信 API の応答はフラット JSON かつキー既知なので、python3 不在時は sed 抽出に
# フォールバックする。python3 がある環境では従来通り python3 を優先 (厳密解析)。
# ========================================
HAS_PY3=0
# ★存在確認だけでは「入口はあるが動かない」端末を弁別できない。
#   【この実装が必要な理由】macOS は開発ツール (Command Line Tools) 未導入でも
#   /usr/bin/python3 が入口 (シム) として実在する。command -v は成功するため
#   HAS_PY3=1 となり、せっかく用意した sed フォールバックへ到達しないまま
#   python3 経路を選び、実行時に失敗して更新が黙って止まる。
#   つまり【フォールバックは実装済みなのに、その入口の判定が誤っているせいで
#   一度も使われない】状態だった。上のコメントが根因と呼ぶ v2040 固着デッドロックは、
#   この経路で再発する (一部の環境で導入・更新が完了しない事象が確認されたため。
#   版数の表示まで実行して初めて「使える」と判定する。
# 素の macOS では /usr/bin/python3 が開発ツール導入用の入口 (シム) として実在し、
# 実行するたびに導入を促す画面が出る。実行せずに判定できる材料 (開発ツールの所在) を
# 先に見て、未導入なら python3 を一度も起動しない (毎メッセージの画面出現を防ぐ)。
_py3_usable=1
if [ "$(uname -s 2>/dev/null)" = "Darwin" ] && ! /usr/bin/xcode-select -p >/dev/null 2>&1; then
    case "$(command -v python3 2>/dev/null)" in
        /usr/bin/python3|"") _py3_usable=0 ;;   # シムのみ or 不在 → 起動しない
    esac
fi
if [ "$_py3_usable" -eq 1 ] && command -v python3 >/dev/null 2>&1 && python3 --version >/dev/null 2>&1; then
    HAS_PY3=1
fi

# フラット JSON から文字列フィールドを 1 つ取り出す: _sl_json_field "$json" key
_sl_json_field() {
    printf '%s' "$1" | sed -n 's/.*"'"$2"'"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' | head -1
}
# フラット JSON の boolean が true か: _sl_json_true "$json" key
_sl_json_true() {
    printf '%s' "$1" | grep -q '"'"$2"'"[[:space:]]*:[[:space:]]*true'
}
# ローカル JSON ファイルから文字列フィールド抽出: _sl_jfile_field file key
_sl_jfile_field() {
    [ -f "$1" ] || return 0
    sed -n 's/.*"'"$2"'"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/p' "$1" | head -1
}

# ========================================
# Windows (Git Bash) 非互換コマンドのフォールバック (2026-07-13 恒久対策)
# ----------------------------------------
# Git for Windows には rsync が存在せず、shasum (perl) も構成により欠落する。
# 従来は rsync 失敗 = ステージング失敗、shasum 欠落 = チェックサム空で不一致扱い、
# となり Windows 端末の本体更新を構造的に破壊していた。
# ========================================
# SHA-256 計算: shasum → sha256sum → openssl の順で試行
_sl_sha256() {
    if command -v shasum >/dev/null 2>&1; then
        shasum -a 256 "$1" 2>/dev/null | cut -d' ' -f1
    elif command -v sha256sum >/dev/null 2>&1; then
        sha256sum "$1" 2>/dev/null | cut -d' ' -f1
    elif command -v openssl >/dev/null 2>&1; then
        openssl dgst -sha256 "$1" 2>/dev/null | awk '{print $NF}'
    fi
}

# ========================================
# 更新物の署名検証（配信元と独立した改竄検知）
# ----------------------------------------
# 照合値（SHA-256）は、更新物と同じ配信元から一緒に配られる。
# 配信経路を握られた場合、更新物と照合値をまとめて差し替えれば照合は必ず通る。
# つまり照合値では「途中で壊れていないか」しか分からず、「すり替えられていないか」
# は分からない。ここでは、配信側だけが作れる署名を別に確かめる。
#
# 検証に使う公開鍵は、お手元のランチャー本体から取り出す。公開鍵は差し替えの
# できない形で本体に組み込まれており、通信経路からは変更できない。
#
# 署名が無い・壊れている・検証の道具がそろわない場合は、更新を行わない。
# 「確認できなかったので、とりあえず適用する」ことはしない。
# ========================================
_sl_update_pubkey_file() {
    local launcher="$SL_DIR/$LAUNCHER_NAME" out
    [ -x "$launcher" ] || return 1
    out=$(mktemp "${TMPDIR:-/tmp}/sl-updkey.XXXXXX" 2>/dev/null) || return 1
    if "$launcher" --print-update-pubkey > "$out" 2>/dev/null && grep -q "BEGIN PUBLIC KEY" "$out" 2>/dev/null; then
        printf '%s' "$out"
        return 0
    fi
    rm -f "$out"
    return 1
}

# _sl_verify_artifact_signature <検証したいファイル> <配布元URL> <応答に載っていた署名(base64・無ければ空)>
# 本体の実行ファイルが署名検証の委譲に対応している世代か (2026-09-07 新設)
#   引数不足で終了コード 2 を返せば対応世代。古い世代は未知の引数として別の値を返す。
_sl_launcher_can_verify() {
    [ -x "$SL_DIR/$LAUNCHER_NAME" ] || return 1
    "$SL_DIR/$LAUNCHER_NAME" --verify-artifact >/dev/null 2>&1
    [ "$?" = "2" ]
}

_sl_verify_artifact_signature() {
    local target="$1" url="$2" inline="$3"
    local pubkey sigfile rc=1 decoded
    local _has_openssl=0
    # ★2026-09-20 是正: 失敗の理由を呼び出し元へ渡す。
    # 【なぜ要るか — 実測】
    #   失敗の理由が「署名が偽物」でも「お手元の本体が古くて確かめられない」でも、
    #   お客様と管理画面に届く文言が同じ「発行元を確認できなかった」だった。
    #   そのため、本体が古いだけで止まっている端末を 6 週間ぶん切り分けられず、
    #   同じ 1 行のまま 297 回積み上がった。判定そのものは一切変えず、理由だけ残す。
    SL_SIG_FAIL_REASON=""
    command -v openssl >/dev/null 2>&1 && _has_openssl=1

    # ★2026-09-07 是正: openssl が無くても本体の実行ファイルへ検証を委譲する。
    # 【なぜ要るか — 実測】
    #   従来はここで必ず失敗し、本体更新・バイナリ更新・メニュー修復がすべて中止された。
    #   Windows は Go 経路 (内蔵鍵) へ落ちるため詰まないが、Mac には落ち先が無く、
    #   openssl が無いだけで更新が全面停止する。導入時に openssl の有無を確かめる処理も無い。
    #   検証そのものは本体が内蔵鍵で行えるので、そちらへ渡す。
    #   ★どちらでも検証できないときは、従来どおり失敗にする (検証を省いて通さない)。
    if [ "$_has_openssl" = "0" ]; then
        if ! _sl_launcher_can_verify; then
            SL_SIG_FAIL_REASON="no_verifier"
            log "SIG_NO_OPENSSL launcher_cannot_verify (署名を確かめられないため更新しません)"
            return 1
        fi
        log "SIG_DELEGATE_TO_LAUNCHER (openssl 不在のため本体で検証)"
    fi

    if [ "$_has_openssl" = "1" ] && ! pubkey=$(_sl_update_pubkey_file); then
        # 世代差の切り分けを残す。お手元のランチャー本体が古い世代だと
        # 検証用の公開鍵を取り出せず、更新が進まない状態になるため、
        # 運用側からその状況を見分けられるようにしておく。
        if [ -x "$SL_DIR/$LAUNCHER_NAME" ]; then
            SL_SIG_FAIL_REASON="launcher_too_old"
            log "SIG_NO_PUBKEY launcher_too_old (公開鍵の取り出しに未対応の世代)"
        else
            SL_SIG_FAIL_REASON="launcher_missing"
            log "SIG_NO_PUBKEY launcher_missing"
        fi
        return 1
    fi
    sigfile=$(mktemp "${TMPDIR:-/tmp}/sl-updsig.XXXXXX" 2>/dev/null) || { rm -f "$pubkey"; return 1; }

    if [ -n "$inline" ]; then
        printf '%s' "$inline" | base64 -d > "$sigfile" 2>/dev/null || : > "$sigfile"
    else
        # 配布物と同じ場所に置かれた署名ファイル（末尾に .sig）を取りに行く
        case "$url" in
            https://*\?*) log "SIG_NO_SOURCE url_has_query" ;;
            https://*)    _sl_curl GET "${url}.sig" "$sigfile" 30 >/dev/null 2>&1 || : ;;
            *)            log "SIG_NO_SOURCE url_not_https" ;;
        esac
        # base64 のテキストで置かれている場合も受け付ける
        if [ -s "$sigfile" ] && LC_ALL=C grep -qI . "$sigfile" 2>/dev/null; then
            decoded=$(mktemp "${TMPDIR:-/tmp}/sl-updsig2.XXXXXX" 2>/dev/null)
            if [ -n "$decoded" ] && base64 -d < "$sigfile" > "$decoded" 2>/dev/null && [ -s "$decoded" ]; then
                mv -f "$decoded" "$sigfile"
            else
                rm -f "$decoded"
            fi
        fi
    fi

    if [ ! -s "$sigfile" ]; then
        SL_SIG_FAIL_REASON="sig_missing"
        log "SIG_MISSING url=$url"
        rm -f "$pubkey" "$sigfile"
        return 1
    fi

    if [ "$_has_openssl" = "1" ]; then
        openssl dgst -sha256 -verify "$pubkey" -signature "$sigfile" "$target" >/dev/null 2>&1
        rc=$?
    else
        "$SL_DIR/$LAUNCHER_NAME" --verify-artifact "$target" "$sigfile" >/dev/null 2>&1
        rc=$?
    fi
    rm -f "$pubkey" "$sigfile"
    if [ $rc -ne 0 ]; then
        SL_SIG_FAIL_REASON="sig_invalid"
        log "SIG_INVALID url=$url"
        return 1
    fi
    log "SIG_VERIFIED url=$url"
    return 0
}
# 削除同期で消えるファイルだけを控える (2026-09-07 新設)
# 【なぜ要るか — 実測】
#   更新時の控えは chain.sh / setup.sh / メニューの本文だけで、部品一式 (lib) は控えない。
#   ところが lib は削除同期 (新版に無い旧ファイルを消す) の対象である。
#   つまり更新で消えたものは、どこにも残らない。更新が途中で壊れたお客様は自力で戻せない。
#
# 【なぜ全部を控えないか】
#   部品一式は 223MB / 3,969 ファイルあり、毎回まるごと控えるとお客様の空き容量を削る
#   (既存の控えだけで 570MB を使っている端末がある)。
#   一方、更新で失われるのは「新版に無い旧ファイル」だけなので、それだけ控えれば戻せる。
#   通常は数件〜数十件で済む。
_sl_stash_removed() {   # <新版のlib> <現行のlib> <控え先>
    local newlib="${1%/}" curlib="${2%/}" stash="${3%/}"
    [ -d "$curlib" ] && [ -d "$newlib" ] || return 0
    mkdir -p "$stash" 2>/dev/null || return 0
    local a b rel n=0
    a="$(mktemp "${TMPDIR:-/tmp}/sl-cur.XXXXXX")" || return 0
    b="$(mktemp "${TMPDIR:-/tmp}/sl-new.XXXXXX")" || { rm -f "$a"; return 0; }
    ( cd "$curlib" && find . -type f 2>/dev/null | LC_ALL=C sort ) > "$a" 2>/dev/null
    ( cd "$newlib" && find . -type f 2>/dev/null | LC_ALL=C sort ) > "$b" 2>/dev/null
    # 現行にあって新版に無いもの = この更新で消えるもの
    while IFS= read -r rel; do
        [ -n "$rel" ] || continue
        mkdir -p "$stash/$(dirname "$rel")" 2>/dev/null
        cp -p "$curlib/$rel" "$stash/$rel" 2>/dev/null && n=$((n + 1))
    done < <(LC_ALL=C comm -23 "$a" "$b")
    rm -f "$a" "$b"
    if [ "$n" -gt 0 ]; then
        log "STASH_REMOVED ${n} files -> ${stash}"
    else
        log "STASH_REMOVED none (この更新で消えるファイルはありません)"
    fi
    return 0
}

# ミラー同期 (rsync -a --delete 相当): _sl_mirror_dir src/ dst/
# rsync 不在時は「隣に新ツリーを構築 → アトミックに近い swap」で行う。
# (旧実装の「稼働中 dst を rm -rf してから cp」は、cp 途中失敗で dst 全損の
#  非アトミック窓が生じるため禁止 — 2026-07-13 敵対検証で確証)
_sl_mirror_dir() {
    local src="$1" dst="$2"
    if command -v rsync >/dev/null 2>&1; then
        rsync -a --delete "$src" "$dst"
        return $?
    fi
    local dst_norm="${dst%/}"
    local tmp_new="${dst_norm}.new.$$" tmp_old="${dst_norm}.old.$$"
    rm -rf "$tmp_new" "$tmp_old" 2>/dev/null
    mkdir -p "$tmp_new" || return 1
    if ! cp -R "${src%/}/." "$tmp_new/"; then
        rm -rf "$tmp_new" 2>/dev/null
        return 1   # コピー失敗 → 稼働中の dst は無傷のまま中止
    fi
    if [ -d "$dst_norm" ]; then
        mv "$dst_norm" "$tmp_old" || { rm -rf "$tmp_new"; return 1; }
    fi
    if mv "$tmp_new" "$dst_norm"; then
        rm -rf "$tmp_old" 2>/dev/null
        return 0
    fi
    # swap 失敗 → 旧ツリーを復元
    [ -d "$tmp_old" ] && mv "$tmp_old" "$dst_norm" 2>/dev/null
    rm -rf "$tmp_new" 2>/dev/null
    return 1
}
# ============================================================
# 【2026-08-16 / 削除同期からの社内専用資産の保護】
# 事故の実測: 2026-08-15 17:43 の焼成パッケージ適用で lib/ のミラー同期
# (rsync -a --delete) が走り、パッケージに含まれない社内専用の内部統制資産が
# 全消失した。同じ危険は domains/integrations について既に overlay 化で
# 対処済みだが (下記 PFP-122 の注記参照)、lib/ 本体だけがミラーのまま残っていた。
#
# 方式: 保護対象を同期前に退避し、同期後に「不在のものだけ」戻す。
#   - rsync の --filter / --exclude に依存しない (macOS 標準は openrsync で
#     フィルタ仕様が異なるため、実装差の影響を受けない書き方にする)。
#   - パッケージが新版を配ってきた場合は新版を優先する (戻さない)。
#   - 保護対象の目録は lib/ の外に置く。lib/ の中に置くと目録自身が
#     同じ削除同期で消え、保護機構が自分を守れなくなる。
#   - 目録が無い環境 (顧客) では保護対象ゼロ = 従来と完全に同じ挙動。
#     社内専用資産の名前を配布物に埋め込まないため、既定値も空にしている。
_sl_protect_manifest() {
    printf '%s' "${SOLOPTILINK_PROTECT_MANIFEST:-$SL_DIR/audits/internal-control/protected-lib-paths.txt}"
}
_sl_protect_list() {
    local mf; mf="$(_sl_protect_manifest)"
    # 目録が無ければ保護対象ゼロ (顧客環境の通常状態)。ただし「静かに無効化された」
    # 状態を後から追えるよう記録だけは残す。
    if [ ! -f "$mf" ]; then
        log "LIB_PROTECT_NO_MANIFEST path=$mf"
        # ★2026-08-16 是正 (E9):
        #   目録が失われても記録が 1 行増えるだけで、保護は無言で全部切れていた。
        #   誰も気づかないまま更新が走り、社内専用資産が丸ごと消える (2026-08-15 の事故と同型)。
        #   ここで異常終了させると、目録を持たない【お客様の端末では更新そのものが止まる】ため
        #   止めない。代わりに「守るべき資産が在るのに目録が無い」端末 = 社内機だけを見分けて
        #   画面にも警告を出す。lib/internal-control は配布物に一切含まれない社内専用資産であり、
        #   お客様の端末には存在しないため、この警告がお客様に出ることはない。
        #   (異常終了させるかどうかの線引きは owner 判断として別に立てている)
        if [ -d "${SL_DIR:-$HOME/.soloptilink}/lib/internal-control" ]; then
            printf '%s\n' "警告: 社内専用資産を更新から守るための目録が見つかりません ($mf)" >&2
            printf '%s\n' "      このまま更新すると、配布物に含まれない社内専用資産が消えます。" >&2
            printf '%s\n' "      目録を復旧してから更新してください (控え: audits/e2e-backups/)。" >&2
            log "LIB_PROTECT_NO_MANIFEST_ON_ADMIN path=$mf"
        fi
        return 0
    fi
    # コメント行と空行を除き、末尾空白を落とす
    sed -e 's/[[:space:]]*$//' -e '/^[[:space:]]*#/d' -e '/^$/d' "$mf" 2>/dev/null
}
# 実在判定: 通常ファイル/ディレクトリだけでなく【リンク切れのシンボリックリンク】も
# 「在る」と見なす。-e はリンク先を辿るため、退役資産を指すリンクを取りこぼす。
_sl_protect_exists() { [ -e "$1" ] || [ -L "$1" ]; }
# 1件複製: _sl_protect_copy_one <src> <dst>
# ★2026-08-16 是正 (敵対検証の指摘): 以前は復帰に cp -p だけを使っていたため、
#   シンボリックリンクが【リンク先の実体を持つ通常ファイル】へ化けて戻っていた。
#   内容が同一なので指紋照合も孤児率も緑のまま素通りし、検査では捕まらない劣化だった。
#   リンクはリンクとして戻す。あわせて退避も cp -Rp にし、更新日時を当日へ書き換えない。
_sl_protect_copy_one() {
    local src="$1" dst="$2" tgt
    if [ -L "$src" ]; then
        tgt="$(readlink "$src" 2>/dev/null)" || return 1
        [ -n "$tgt" ] || return 1
        rm -f "$dst" 2>/dev/null
        ln -s "$tgt" "$dst" 2>/dev/null || return 1
        return 0
    fi
    cp -p "$src" "$dst" 2>/dev/null || return 1
    return 0
}
# 退避: _sl_protect_stash <lib_root> <stash_dir>
_sl_protect_stash() {
    local root="${1%/}" stash="${2%/}" rel listf
    listf="$(mktemp -t slprot 2>/dev/null)" || return 0
    _sl_protect_list > "$listf" 2>/dev/null
    mkdir -p "$stash" 2>/dev/null || { rm -f "$listf"; return 0; }
    while IFS= read -r rel; do
        [ -z "$rel" ] && continue
        case "$rel" in /*|*..*) continue ;; esac      # 木の外を指す指定は無視
        _sl_protect_exists "$root/$rel" || continue
        # ★2026-08-16 是正 (敵対検証の指摘 / 実走で再現):
        #   以前は種別を見ずに cp -Rp "$root/$rel" "$stash/$rel" としていた。cp は
        #   複製先が既存ディレクトリだと【その中へ】入れるため、目録に同じ名前の
        #   ファイル登録 (quality-fortresses/novemdecafortress.sh) とディレクトリ登録
        #   (quality-fortresses) が併存すると、退避先が
        #   stash/quality-fortresses/quality-fortresses/... という入れ子になった。
        #   入れ子はそのまま本体 lib/ へ書き戻され、次の焼成で配布物に載る。
        #   目録の書き方に依存せず壊れないよう、ディレクトリは「中身を入れる」形で退避する。
        if [ -d "$root/$rel" ] && [ ! -L "$root/$rel" ]; then
            mkdir -p "$stash/$rel" 2>/dev/null
            # -R はリンクをリンクのまま複製し、-p で更新日時・権限を保つ
            cp -Rp "$root/$rel/." "$stash/$rel/" 2>/dev/null
        else
            mkdir -p "$stash/$(dirname "$rel")" 2>/dev/null
            cp -Rp "$root/$rel" "$stash/$rel" 2>/dev/null
        fi
    done < "$listf"
    rm -f "$listf"
    return 0
}
# 復帰: _sl_protect_restore <lib_root> <stash_dir> — 同期後に不在のものだけ戻す
_sl_protect_restore() {
    local root="${1%/}" stash="${2%/}" rel sub f n=0 listf filef
    [ -d "$stash" ] || return 0
    listf="$(mktemp -t slprot 2>/dev/null)" || return 0
    filef="$(mktemp -t slprotf 2>/dev/null)" || { rm -f "$listf"; return 0; }
    _sl_protect_list > "$listf" 2>/dev/null
    while IFS= read -r rel; do
        [ -z "$rel" ] && continue
        case "$rel" in /*|*..*) continue ;; esac
        _sl_protect_exists "$stash/$rel" || continue
        if [ -d "$stash/$rel" ] && [ ! -L "$stash/$rel" ]; then
            # ★-type l を足す: 以前は -type f だけだったためディレクトリ登録の配下に
            #   在るシンボリックリンクは【一件も戻らなかった】(静かな取りこぼし)。
            find "$stash/$rel" \( -type f -o -type l \) > "$filef" 2>/dev/null
            while IFS= read -r f; do
                sub="${f#$stash/}"
                _sl_protect_exists "$root/$sub" && continue   # 新版が配られていれば新版を優先
                mkdir -p "$root/$(dirname "$sub")" 2>/dev/null
                _sl_protect_copy_one "$f" "$root/$sub" && n=$((n+1))
            done < "$filef"
        else
            _sl_protect_exists "$root/$rel" && continue
            mkdir -p "$root/$(dirname "$rel")" 2>/dev/null
            _sl_protect_copy_one "$stash/$rel" "$root/$rel" && n=$((n+1))
        fi
    done < "$listf"
    rm -f "$listf" "$filef"
    [ "$n" -gt 0 ] && log "LIB_PROTECT_RESTORED count=$n manifest=$(_sl_protect_manifest)"
    return 0
}
# ============================================================
# 【2026-10-28 / 管理者の端末で、配布物より新しい開発中の作業を消さない・上書きしない】
# 事故の実測: do_update は管理者の端末でも lib/ を配布物へ削除同期し、最上位の台本や scripts/ を
#   配布物の版で上書きしていた。管理者の端末の本体は開発の作業の木なので、焼いた後に作った
#   記録していない部品は消え、記録していない直しは配布物の版へ黙って巻き戻った
#   (10-21 に 988 件・10-23 に 414 件・10-27 に 1,024 件を lib-removed へ移し、10-27 は
#   lib/deliver-pdf とお客様の歩みの台帳 6 本が戻らなかった)。上の保護目録は手で足す方式で、
#   新しい部品の登録漏れを防げない。
# 方式:
#   - 何が開発中の作業かの判定は scripts/distribution/devwork-guard.sh の 1 本だけが持つ
#     (ここに同じ規則を書かない。2 か所に持つと必ず食い違う)。ここは呼ぶだけ。
#   - 本体へ書く前に退避し、書き終えた後に【上書きして】戻す。保護目録は「無いものだけ戻す=新版優先」
#     だが、開発中の作業は配布物より新しいので作業を優先する。上書きされかけた配布物の版は控えに残す。
#   - お客様の端末 (.admin_mode も本体直下の .git も無い) では判定が空を返し、従来と完全に同じ動きになる。
#   - 管理者の開発の木なのに判定できないときは 3 を返す。呼び出し側は本体の入れ替えを見送る (消すより止める)。
_sl_protect_devwork_guard() {   # 判定の台本の置き場 (lib/ の外 = 削除同期で消えない)
    printf '%s' "${SL_DIR:-$HOME/.soloptilink}/scripts/distribution/devwork-guard.sh"
}
# 退避: _sl_protect_devwork_stash <退避先> <対象 (本体からの相対)>...  戻り値 0 / 3=判定できない
_sl_protect_devwork_stash() {
    local stash="${1%/}" g out rc
    shift
    g="$(_sl_protect_devwork_guard)"
    if [ ! -f "$g" ]; then
        # 判定の台本が無い = 守りが静かに外れている。お客様の端末には .admin_mode が無いので出ない
        if [ -f "${SL_DIR:-$HOME/.soloptilink}/.admin_mode" ]; then
            log "DEVWORK_GUARD_MISSING path=$g"
            printf '%s\n' "警告: 開発中の作業を更新から守る判定が見つかりません ($g)" >&2
        fi
        return 0
    fi
    out="$(bash "$g" stash "${SL_DIR:-$HOME/.soloptilink}" "$stash" "$@" 2>/dev/null)"; rc=$?
    if [ "$rc" -eq 3 ]; then
        log "DEVWORK_UNSURE ${out}"
        return 3
    fi
    [ "$rc" -eq 0 ] || log "DEVWORK_GUARD_ERROR rc=$rc ${out}"
    [ -s "$stash/list" ] && log "DEVWORK_STASHED ${out}"
    return 0
}
# 戻す: _sl_protect_devwork_restore <退避先> [<配布物の版の控え先>]
_sl_protect_devwork_restore() {
    local stash="${1%/}" keep="${2:-}" g out
    [ -s "$stash/list" ] || return 0
    # 退避のときに写した判定の台本で戻す (更新の途中で台本自身が配布物の版に置き換わっても、同じ手順で戻すため)
    g="$stash/devwork-guard.sh"
    [ -f "$g" ] || g="$(_sl_protect_devwork_guard)"
    if out="$(bash "$g" restore "${SL_DIR:-$HOME/.soloptilink}" "$stash" ${keep:+"$keep"} 2>/dev/null)"; then
        log "DEVWORK_KEPT ${out}${keep:+ 配布物の版の控え=$keep}"
    else
        log "DEVWORK_RESTORE_INCOMPLETE ${out}${keep:+ 配布物の版の控え=$keep} 退避の写し=$stash"
    fi
    return 0
}
# ============================================================
# オーバーレイ同期 (rsync -a 相当・既存保全): _sl_overlay_dir src/ dst/
_sl_overlay_dir() {
    local src="$1" dst="$2"
    if command -v rsync >/dev/null 2>&1; then
        rsync -a "$src" "$dst"
    else
        mkdir -p "$dst" || return 1
        cp -R "${src%/}/." "${dst%/}/"
    fi
}

# タイムスタンプ更新（失敗しても24時間待つ）
date +%s > "$CACHE_FILE"

# ========================================
# v2038.4: 軽量バージョン報告 (テレメトリ盲点の補完 / PFP-telemetry)
# ----------------------------------------
# ランチャー (./soloptilink <task>) を起動しない Desktop / 休眠端末は heartbeat を
# 送らず版数が届かない盲点があった。Claude Code セッションごとに必ず走る本スクリプト
# から直接 heartbeat を送り、版数を届ける。非ブロッキング (起動を遅延させない)・失敗黙殺。
# サーバ世代差の保険として current_version と app_version を両キー送信する。
# ========================================
_sl_report_version() {
    command -v curl >/dev/null 2>&1 || return 0
    # 完全停止のご指定があれば送らない (生存確認は完全停止の対象 / 取り決めどおり)
    _sl_auth_egress_stopped && return 0
    local act="$SL_DIR/activation.json" lic="$SL_DIR/license.json"
    [ -f "$act" ] && [ -f "$lic" ] || return 0
    local hb_json
    if [ "$HAS_PY3" != "1" ]; then
        # python3 不在時フォールバック (sed 抽出 + printf 構築)。
        # 値は device_id / token / fingerprint / email = 引用符・バックスラッシュを含まない
        # 単純文字列のため、この構築で JSON として安全。
        # v2054 (skeptic 指摘 1a 対処): fingerprint を持たない超旧世代 (v2000系) 端末でも
        # 版数を管理画面の到達 KPI に計上できるよう fp は必須にしない。recover.sh と同じ流儀で
        # device_id + token が揃えば送信し、fp があれば含める (列挙防止はサーバ側 token 検証で維持)。
        local did tok fp em ver
        did=$(_sl_jfile_field "$lic" device_id); [ -n "$did" ] || did=$(_sl_jfile_field "$act" device_id)
        tok=$(_sl_jfile_field "$lic" token); [ -n "$tok" ] || tok=$(_sl_jfile_field "$act" token)
        fp=$(_sl_jfile_field "$act" fingerprint)
        [ -n "$did" ] && [ -n "$tok" ] || return 0
        ver=$(printf '%s' "$CURRENT_VERSION" | sed 's/^v//')
        em=$(_sl_jfile_field "$act" email)
        hb_json=$(printf '{"device_id":"%s","token":"%s","current_version":"%s","app_version":"%s"' "$did" "$tok" "$ver" "$ver")
        [ -n "$fp" ] && hb_json="${hb_json},\"fingerprint\":\"${fp}\""
        [ -n "$em" ] && hb_json="${hb_json},\"email\":\"${em}\""
        hb_json="${hb_json}}"
        curl -s -L --max-time 8 --connect-timeout 5 \
            -X POST -H "Content-Type: application/json" \
            -d "$hb_json" "${API_BASE}/devices/heartbeat" >/dev/null 2>&1 || true
        return 0
    fi
    hb_json=$(CUR_VER="$CURRENT_VERSION" ACT="$act" LIC="$lic" python3 -c "
import json, os
try:
    act = json.load(open(os.environ['ACT']))
    try:
        lic = json.load(open(os.environ['LIC']))
    except Exception:
        lic = {}
    did = lic.get('device_id') or act.get('device_id') or ''
    tok = lic.get('token') or act.get('token') or ''
    fp  = act.get('fingerprint') or ''
    # v2054 (skeptic 指摘 1a 対処): fingerprint を持たない超旧世代 (v2000系) 端末でも
    # 版数を管理画面の到達 KPI に計上できるよう fp は必須にしない (recover.sh と同流儀)。
    # device_id + token が揃えば送信し、fp があれば含める。列挙防止はサーバ側 token 検証で維持。
    if not (did and tok):
        raise SystemExit(0)
    ver = (os.environ.get('CUR_VER','') or '').lstrip('v')
    body = {'device_id': did, 'token': tok,
            'current_version': ver, 'app_version': ver}
    # 後付けの項目も 'キー': の形で書く (送信項目の台帳照合器が読めるように / 内容は不変)
    if fp:
        body.update({'fingerprint': fp})
    em = act.get('email')
    if em:
        body.update({'email': em})
    print(json.dumps(body))
except Exception:
    pass
" 2>/dev/null)
    [ -n "$hb_json" ] || return 0
    curl -s -L --max-time 8 --connect-timeout 5 \
        -X POST -H "Content-Type: application/json" \
        -d "$hb_json" "${API_BASE}/devices/heartbeat" >/dev/null 2>&1 || true
}
# 非ブロッキングで実行 (更新有無に依存せず毎回・親の exit を待たせない)
( _sl_report_version ) >/dev/null 2>&1 &

# APIに問い合わせ (v2034.2 堅牢化: _sl_curl で 15s/retry3/error-log 集約)
UPDATE_RESPONSE=$(_sl_curl GET "${API_BASE}/updates/check?version=${SAFE_VERSION}&os=${API_OS}&arch=${ARCH}" || echo "")

[ -z "$UPDATE_RESPONSE" ] && exit 0

# python3 が無くても続行する (2026-07-13 恒久対策)。
# 旧実装はここで exit 0 しており、python3 の無い Windows + Git Bash 端末では
# 「成功終了なのに何もしない」= ランチャーが成功と誤認する静かなデッドロックだった。
[ "$HAS_PY3" = "1" ] || log "PY3_ABSENT fallback-parser engaged"

# ========================================
# Goランチャーバイナリの SHA ベース更新 (2026-06-16 全顧客自動更新到達保証)
# ----------------------------------------
# 課題(version-coupling): バイナリの版は chain.sh から動的取得されるため、平文が
# 新版に上がるとバイナリも新版を名乗り、updates/check が available=false を返して
# バイナリが永遠に更新されない。これを断つため、版の available 判定とは独立に
# 「配信バイナリの sha256」と「ローカルバイナリの sha256」を比較し、異なれば
# /updates/download から取得して置換する (updates/check は available=false でも
# sha256 を返すため成立)。これによりフック稼働中の既存端末にも、自己回復を備えた
# 新ランチャーが平文更新の次サイクルで自動的に届く。
# 管理者端末 (.admin_mode) は dev ビルド保護のためスキップ。
# ========================================
# 版文字列を比較可能な整数へ (2040.0 -> 2040000000)。BSD/GNU 両対応。
_sl_vernum() {
    printf '%s' "${1#v}" | awk -F. '{printf "%d%06d%06d\n", ($1+0), ($2+0), ($3+0)}' 2>/dev/null
}
# 構造的未対応プラットフォーム判定 (2026-07-23 v2054.4):
# 配信APIは未対応 os/arch に HTTP 400 + 小さな JSON エラーボディを返す
# (--fail-with-body のためボディは outfile に残る)。これはバイナリ破損や回線障害では
# なく「配信側がこのプラットフォームに未対応」の合図。この場合に .binupdate-failed-sha を
# 武装させると、配信側が対応した後も同一 sha のまま最大7日更新が止まるため、武装させない。
_sl_is_platform_reject() {
    local f="$1" sz
    [ -f "$f" ] || return 1
    sz=$(wc -c < "$f" 2>/dev/null | tr -d ' ')
    [ "${sz:-0}" -gt 0 ] && [ "${sz:-0}" -lt 4096 ] || return 1
    head -c 1 "$f" 2>/dev/null | grep -q '{' || return 1
    grep -q 'error' "$f" 2>/dev/null
}
_sl_update_binary_if_sha_differs() {
    [ -f "$SL_DIR/.admin_mode" ] && return 0
    # ランチャー実体名は OS 依存 (Windows=soloptilink.exe)。実行中でない名前を対象にする。
    local launcher="$SL_DIR/$LAUNCHER_NAME"
    [ -f "$launcher" ] || return 0
    local served_sha served_ver
    if [ "$HAS_PY3" = "1" ]; then
        served_sha=$(UPDATE_RESPONSE="$UPDATE_RESPONSE" python3 -c "
import json,os
try:
    print((json.loads(os.environ['UPDATE_RESPONSE']).get('sha256') or '').strip())
except Exception:
    pass
" 2>/dev/null)
        served_ver=$(UPDATE_RESPONSE="$UPDATE_RESPONSE" python3 -c "
import json,os
try:
    print((json.loads(os.environ['UPDATE_RESPONSE']).get('version') or '').strip())
except Exception:
    pass
" 2>/dev/null)
    else
        served_sha=$(_sl_json_field "$UPDATE_RESPONSE" sha256)
        served_ver=$(_sl_json_field "$UPDATE_RESPONSE" version)
    fi
    [ -n "$served_sha" ] || return 0
    # 単調前進ガード(ダウングレード防止): ローカル版が配信版より新しければ置換しない。
    if [ -n "$served_ver" ]; then
        local lv sv
        lv=$(_sl_vernum "$CURRENT_VERSION"); sv=$(_sl_vernum "$served_ver")
        if [ -n "$lv" ] && [ -n "$sv" ] && [ "$lv" -gt "$sv" ] 2>/dev/null; then
            return 0
        fi
    fi
    local local_sha
    local_sha=$(_sl_sha256 "$launcher")
    [ -n "$local_sha" ] || return 0
    served_sha=$(printf '%s' "$served_sha" | tr 'A-Z' 'a-z')
    if [ "$served_sha" = "$(printf '%s' "$local_sha" | tr 'A-Z' 'a-z')" ]; then
        rm -f "$SL_DIR/.binupdate-failed-sha" 2>/dev/null   # 一致=最新→失敗マーカー解除
        return 0
    fi
    # 無限DL防止: この配信 sha で前回失敗(7日以内)ならスキップ
    local fail_marker="$SL_DIR/.binupdate-failed-sha"
    if [ -f "$fail_marker" ]; then
        local f_sha f_ts now
        f_sha=$(cut -d'|' -f1 "$fail_marker" 2>/dev/null | tr 'A-Z' 'a-z' | tr -d ' ')
        f_ts=$(cut -d'|' -f2 "$fail_marker" 2>/dev/null | tr -d ' ')
        now=$(date +%s)
        if [ "$f_sha" = "$served_sha" ] && [ -n "$f_ts" ] && [ $((now - f_ts)) -lt 604800 ] 2>/dev/null; then
            return 0
        fi
    fi
    local bin_url="${API_BASE}/updates/download?os=${API_OS}&arch=${ARCH}"
    local tmp_bin
    tmp_bin=$(mktemp "${TMPDIR:-/tmp}/sl-bin.XXXXXX") || return 0
    if ! _sl_curl GET "$bin_url" "$tmp_bin" 120 >/dev/null; then
        if _sl_is_platform_reject "$tmp_bin"; then
            log "BINARY_UPDATE_PLATFORM_UNSUPPORTED os=${API_OS} arch=${ARCH} (failマーカー非武装)"
            rm -f "$tmp_bin"; return 0
        fi
        printf '%s|%s' "$served_sha" "$(date +%s)" > "$fail_marker" 2>/dev/null
        rm -f "$tmp_bin"; return 0
    fi
    local got_sha got_size
    got_size=$(wc -c < "$tmp_bin" | tr -d ' ')
    if [ "${got_size:-0}" -lt 1048576 ]; then  # 1MB未満は不完全DL
        if _sl_is_platform_reject "$tmp_bin"; then
            log "BINARY_UPDATE_PLATFORM_UNSUPPORTED os=${API_OS} arch=${ARCH} (failマーカー非武装)"
            rm -f "$tmp_bin"; return 0
        fi
        printf '%s|%s' "$served_sha" "$(date +%s)" > "$fail_marker" 2>/dev/null
        rm -f "$tmp_bin"; return 0
    fi
    got_sha=$(_sl_sha256 "$tmp_bin" | tr 'A-Z' 'a-z')
    if [ "$got_sha" != "$served_sha" ]; then
        log "BINARY_SHA_MISMATCH served=$served_sha got=$got_sha"
        printf '%s|%s' "$served_sha" "$(date +%s)" > "$fail_marker" 2>/dev/null
        rm -f "$tmp_bin"; return 0
    fi
    # 照合値だけでは差し替えを見抜けないため、配信側だけが作れる署名も確かめる。
    # 問い合わせ形式の URL には .sig を付け足せないので、応答に載っている署名を使う。
    local served_sig
    served_sig=$(_sl_json_field "$UPDATE_RESPONSE" signature)
    if ! _sl_verify_artifact_signature "$tmp_bin" "$bin_url" "$served_sig"; then
        log "BINARY_SIGNATURE_FAILED served=$served_sha"
        printf '%s|%s' "$served_sha" "$(date +%s)" > "$fail_marker" 2>/dev/null
        rm -f "$tmp_bin"; return 0
    fi
    rm -f "$fail_marker" 2>/dev/null
    # rename-backup 方式で置換 (実行中.exeのロック時も .backup から復元可能)
    chmod +x "$tmp_bin" 2>/dev/null || true
    local backup="${launcher}.backup"
    rm -f "$backup" 2>/dev/null
    if mv "$launcher" "$backup" 2>/dev/null; then
        if mv "$tmp_bin" "$launcher" 2>/dev/null; then
            chmod +x "$launcher" 2>/dev/null || true
            rm -f "$backup" 2>/dev/null
            log "BINARY_UPDATED_BY_SHA ($LAUNCHER_NAME) -> $served_sha"
        else
            mv "$backup" "$launcher" 2>/dev/null   # 復元
            rm -f "$tmp_bin"
        fi
    else
        # rename 不可(実行中ロック等) → 直接上書きを試行、不可なら次サイクルへ
        if cp "$tmp_bin" "$launcher" 2>/dev/null; then
            chmod +x "$launcher" 2>/dev/null || true
            log "BINARY_UPDATED_BY_SHA_CP ($LAUNCHER_NAME) -> $served_sha"
        fi
        rm -f "$tmp_bin"
    fi
}
# 版の available 判定より前に実行 (平文が最新でもバイナリだけ古いケースを救う)
# 2026-07-13 敵対検証で確証: フック経由 (非 force) の実行予算は 30 秒であり、
# 大容量バイナリDLを前景で行うと低速回線で毎回途中 kill され永遠に完遂しない。
# フック経由ではバックグラウンドで実行し、フック本体は即座に先へ進む。
if [ "$FORCE_UPDATE" = true ] || [ "${SOLOPTILINK_AU_DETACHED:-}" = "1" ]; then
    # 切り離し済みなら、もう時間切れで止められないので前景で最後まで行う
    _sl_update_binary_if_sha_differs
else
    ( _sl_update_binary_if_sha_differs ) >> "$LOG_FILE" 2>&1 &
fi

# レスポンス解析（環境変数経由で安全に渡す、改行区切りで出力）
# package_url を優先使用（skills/agents/hooks パッケージ用）
# package_url がない場合は download_url にフォールバック
if [ "$HAS_PY3" = "1" ]; then
PARSE_RESULT=$(UPDATE_RESPONSE="$UPDATE_RESPONSE" python3 -c "
import json, os, re, sys
try:
    d = json.loads(os.environ['UPDATE_RESPONSE'])
    if not d.get('available', False):
        sys.exit(0)
    ver = d.get('version', '')
    # package_url を優先、なければ download_url
    url = d.get('package_url', '') or d.get('download_url', '')
    sha = d.get('package_sha256', '') or d.get('sha256', '')
    # 配信側だけが作れる署名（あれば使う。無ければ .sig ファイルを取りに行く）
    sig = (d.get('package_signature', '') or d.get('signature', '')).replace('\n', '')
    # バージョン形式検証
    if not re.match(r'^[0-9]+\.[0-9]+(\.[0-9]+)?$', ver):
        sys.exit(0)
    # URL検証（httpsのみ許可）
    if not url.startswith('https://'):
        sys.exit(0)
    # 改行区切りで出力（URLにパイプが含まれても安全）
    print(ver)
    print(url)
    print(sha)
    print(sig)
except (json.JSONDecodeError, KeyError, TypeError):
    pass
" 2>/dev/null)
else
    # python3 不在時フォールバック (sed 抽出 + シェル検証。検証内容は python3 経路と同一)
    PARSE_RESULT=""
    if _sl_json_true "$UPDATE_RESPONSE" available; then
        _fb_ver=$(_sl_json_field "$UPDATE_RESPONSE" version)
        _fb_url=$(_sl_json_field "$UPDATE_RESPONSE" package_url)
        [ -n "$_fb_url" ] || _fb_url=$(_sl_json_field "$UPDATE_RESPONSE" download_url)
        _fb_sha=$(_sl_json_field "$UPDATE_RESPONSE" package_sha256)
        [ -n "$_fb_sha" ] || _fb_sha=$(_sl_json_field "$UPDATE_RESPONSE" sha256)
        _fb_sig=$(_sl_json_field "$UPDATE_RESPONSE" package_signature)
        [ -n "$_fb_sig" ] || _fb_sig=$(_sl_json_field "$UPDATE_RESPONSE" signature)
        # バージョン形式検証 + https 検証 (python3 経路と同一基準)
        if printf '%s' "$_fb_ver" | grep -Eq '^[0-9]+\.[0-9]+(\.[0-9]+)?$'; then
            case "$_fb_url" in
                https://*) PARSE_RESULT=$(printf '%s\n%s\n%s\n%s' "$_fb_ver" "$_fb_url" "$_fb_sha" "$_fb_sig") ;;
            esac
        fi
    fi
fi

# ========================================
# スキル乖離 自己修復 (2026-07-13 v2040発E2Eで実証した固着の根治)
# 旧世代 do_update はスキルSoTミラー (~/.soloptilink/skills) を更新しないため、
# 「本体は最新版・スキルは旧版に巻き戻り」の乖離が恒久化する。版一致で更新が
# 走らない時にも乖離を検知し、配信中パッケージからスキル群のみ再適用する。
# ========================================
_sl_skill_drift_detected() {
    local probe="$SL_DIR/skills/soloptilink-boost/SKILL.md"
    [ -f "$probe" ] || return 0          # ミラー不在 = 乖離扱い (修復対象)
    grep -q "v${CURRENT_VERSION}" "$probe" 2>/dev/null && return 1   # 追従済み
    return 0
}
heal_skill_drift() {
    _sl_skill_drift_detected || return 0
    log "SKILL_DRIFT_DETECTED chain=v${CURRENT_VERSION} mirror=$(grep -m1 -o 'v[0-9][0-9.]*' "$SL_DIR/skills/soloptilink-boost/SKILL.md" 2>/dev/null | head -1)"
    local latest_json latest_ver latest_url latest_sha
    latest_json=$(_sl_curl GET "${API_BASE}/releases/latest" "" 20) || return 0
    latest_ver=$(_sl_json_field "$latest_json" version)
    latest_url=$(_sl_json_field "$latest_json" package_url)
    latest_sha=$(_sl_json_field "$latest_json" package_sha256)
    case "$latest_url" in https://*) ;; *) return 0 ;; esac
    # 現行本体より古いパッケージでの修復は行わない (ダウングレード防止)
    [ "$(printf '%s\n%s' "$latest_ver" "$CURRENT_VERSION" | sort -V | tail -1)" = "$CURRENT_VERSION" ] && [ "$latest_ver" != "$CURRENT_VERSION" ] && return 0
    local hdir hpkg
    hdir=$(mktemp -d) || return 0
    hpkg="$hdir/pkg.tar.gz"
    if ! _sl_curl GET "$latest_url" "$hpkg" >/dev/null; then rm -rf "$hdir"; return 0; fi
    # 照合値が無いまま展開すると、無検査の配布物からスキル一式を上書きすることになる。
    # 照合値と署名の両方が確認できたときだけ先へ進む。
    if [ -z "$latest_sha" ]; then
        log "SKILL_HEAL_NO_SHA"; rm -rf "$hdir"; return 0
    fi
    local actual; actual=$(_sl_sha256 "$hpkg" | tr 'A-Z' 'a-z')
    [ "$actual" != "$(printf '%s' "$latest_sha" | tr 'A-Z' 'a-z')" ] && { log "SKILL_HEAL_SHA_MISMATCH"; rm -rf "$hdir"; return 0; }
    if ! _sl_verify_artifact_signature "$hpkg" "$latest_url" "$(_sl_json_field "$latest_json" package_signature)"; then
        log "SKILL_HEAL_SIG_FAILED"; rm -rf "$hdir"; return 0
    fi
    tar -xzf "$hpkg" -C "$hdir" 2>/dev/null || { rm -rf "$hdir"; return 0; }
    local root; root=$(ls -d "$hdir"/soloptilink-v*/ 2>/dev/null | head -1)
    [ -d "${root}skills" ] || { rm -rf "$hdir"; return 0; }
    local healed=0 sdir sname
    for sdir in "${root}skills/"*/; do
        [ -d "$sdir" ] || continue
        sname=$(basename "$sdir")
        # PFP-177: パッケージに万一混入していても管理者専用スキルは適用しない
        _sl_is_admin_only_skill "$sname" && continue
        [ -f "$sdir/SKILL.md" ] || continue
        mkdir -p "$SL_DIR/skills/$sname" "$CLAUDE_DIR/skills/$sname"
        # 2026-07-15: アトミック置換 (書込途中の SKILL.md をスキル走査に見せない)
        _sl_atomic_cp "$sdir/SKILL.md" "$SL_DIR/skills/$sname/SKILL.md" || true
        _sl_atomic_cp "$sdir/SKILL.md" "$CLAUDE_DIR/skills/$sname/SKILL.md" || true
        if [ -d "$sdir/references" ]; then
            _sl_atomic_dir_replace "$sdir/references" "$SL_DIR/skills/$sname/references" || true
            _sl_atomic_dir_replace "$sdir/references" "$CLAUDE_DIR/skills/$sname/references" || true
        fi
        # ★PFP-201: SKILL.md/references 以外の同梱資産 (連携ブリッジ等) も運ぶ
        _sl_copy_skill_extras "$sdir" "$SL_DIR/skills/$sname"
        _sl_copy_skill_extras "$sdir" "$CLAUDE_DIR/skills/$sname"
        case "$sname" in soloptilink*)
            mkdir -p "$CLAUDE_DIR/commands"
            _sl_atomic_cp "$sdir/SKILL.md" "$CLAUDE_DIR/commands/${sname}.md" || true ;;
        esac
        healed=$((healed + 1))
    done
    rm -rf "$hdir"
    log "SKILL_DRIFT_HEALED count=$healed package=v${latest_ver}"
}

if [ -z "$PARSE_RESULT" ]; then
    # 更新なし — スキル乖離だけ確認して自己修復する。
    # フック経由は実行予算 30 秒のため背面実行、--force は前景で完遂する。
    if [ "$FORCE_UPDATE" = true ]; then
        heal_skill_drift
    else
        ( heal_skill_drift ) >> "$LOG_FILE" 2>&1 &
    fi
    exit 0
fi

# パース結果を分解（改行区切り）
NEW_VERSION=$(echo "$PARSE_RESULT" | sed -n '1p')
DOWNLOAD_URL=$(echo "$PARSE_RESULT" | sed -n '2p')
EXPECTED_SHA256=$(echo "$PARSE_RESULT" | sed -n '3p')
EXPECTED_SIGNATURE=$(echo "$PARSE_RESULT" | sed -n '4p')

[ -z "$NEW_VERSION" ] && exit 0
[ -z "$DOWNLOAD_URL" ] && exit 0

log "UPDATE_AVAILABLE v${CURRENT_VERSION} -> v${NEW_VERSION}"

# ========================================
# 更新処理関数
# ========================================
do_update() {
    TEMP_DIR=$(mktemp -d)
    # PFP-101: do_update 内の trap はグローバル EXIT trap を置換するため、
    # ロック解除 + 自己コピー掃除も合わせて引き継ぐ (trap 上書き事故の根絶)
    trap "rm -rf '$TEMP_DIR'; rmdir '$LOCK_DIR' 2>/dev/null; [ -n '$_SL_SELF_COPY' ] && rm -f '$_SL_SELF_COPY' 2>/dev/null" EXIT
    PACKAGE_FILE="$TEMP_DIR/solai-update.tar.gz"

    write_status() {
        local status="$1" message="$2"
        cat > "$STATUS_FILE" << STATUSEOF
{"status":"${status}","version":"${NEW_VERSION}","from":"${CURRENT_VERSION}","message":"${message}","timestamp":"$(date -u '+%Y-%m-%dT%H:%M:%SZ')"}
STATUSEOF
        # [PFP-117] 更新失敗を管理ダッシュボードへ自動報告 (silent / 非ブロッキング)
        if [ "$status" = "failed" ] && [ -f "$SL_DIR/lib/cognitive/customer-error-reporter.sh" ]; then
            bash "$SL_DIR/lib/cognitive/customer-error-reporter.sh" "auto-update-failure" "v${CURRENT_VERSION:-unknown} -> v${NEW_VERSION:-unknown}: ${message:-}" 2>/dev/null || true
        fi
    }

    # v2034.2 堅牢化: append-only 履歴 (途中過程を全て保持 / status.json の上書き喪失問題を解消)
    _append_history() {
        local status="$1" version="$2" message="$3"
        local history="$SL_DIR/.auto-update-history.jsonl"
        echo "{\"ts\":\"$(date -u '+%Y-%m-%dT%H:%M:%SZ')\",\"status\":\"$status\",\"from\":\"$CURRENT_VERSION\",\"version\":\"$version\",\"message\":\"$message\"}" >> "$history" 2>/dev/null
    }

    write_status "downloading" "パッケージダウンロード中"
    _append_history "downloading" "${NEW_VERSION:-$CURRENT_VERSION}" "パッケージダウンロード中"

    # v2034.8 / PFP-057 + PFP-080: DOWNLOAD_TOO_SMALL リトライロジック (下限引き上げ)
    # transient 障害 (release 直後の asset upload race / CDN cold cache) を救う
    # 最大4回、5分間隔で再試行 (合計15分以内に復旧する transient 障害をカバー)
    DOWNLOAD_RETRY_MAX=4
    DOWNLOAD_RETRY_INTERVAL=300  # 5分
    # PFP-080 (v2034.8 2026-05-27): 100bytes → 10240bytes (10KB)
    # 正規の tar.gz は MB 単位なので 10KB 未満は確実に不完全ダウンロード。
    # 監査C指摘の「5KB未満の不完全ダウンロードが漏れる」可能性を構造的根絶。
    # 環境変数 SL_DOWNLOAD_MIN_SIZE で上書き可能 (将来 release asset metadata 動的読取に発展)。
    DOWNLOAD_MIN_SIZE="${SL_DOWNLOAD_MIN_SIZE:-10240}"
    DOWNLOAD_ATTEMPT=0
    DOWNLOAD_SUCCESS=0

    while [ "$DOWNLOAD_ATTEMPT" -lt "$DOWNLOAD_RETRY_MAX" ]; do
        DOWNLOAD_ATTEMPT=$((DOWNLOAD_ATTEMPT + 1))

        # v2034.2 堅牢化: 90秒 / retry3 / connect-timeout 10s / stderr→error-log
        if ! _sl_curl GET "$DOWNLOAD_URL" "$PACKAGE_FILE" 90 >/dev/null; then
            log "DOWNLOAD_FAILED attempt=${DOWNLOAD_ATTEMPT}/${DOWNLOAD_RETRY_MAX} $DOWNLOAD_URL"
            if [ "$DOWNLOAD_ATTEMPT" -lt "$DOWNLOAD_RETRY_MAX" ]; then
                log "DOWNLOAD_RETRY_WAIT ${DOWNLOAD_RETRY_INTERVAL}s (next attempt=$((DOWNLOAD_ATTEMPT + 1)))"
                sleep "$DOWNLOAD_RETRY_INTERVAL"
                continue
            fi
            write_status "failed" "ダウンロード失敗 (${DOWNLOAD_RETRY_MAX}回試行)"
            _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "ダウンロード失敗 (curl rc != 0, ${DOWNLOAD_RETRY_MAX}回試行)"
            return 1
        fi

        FILE_SIZE=$(wc -c < "$PACKAGE_FILE" | tr -d ' ')
        if [ "$FILE_SIZE" -lt "$DOWNLOAD_MIN_SIZE" ]; then
            log "DOWNLOAD_TOO_SMALL attempt=${DOWNLOAD_ATTEMPT}/${DOWNLOAD_RETRY_MAX} ${FILE_SIZE}bytes"
            if [ "$DOWNLOAD_ATTEMPT" -lt "$DOWNLOAD_RETRY_MAX" ]; then
                log "DOWNLOAD_RETRY_WAIT ${DOWNLOAD_RETRY_INTERVAL}s (transient障害可能性: CDN cold cache or asset upload race)"
                write_status "retrying" "ダウンロードサイズ異常 (${FILE_SIZE}bytes) - ${DOWNLOAD_RETRY_INTERVAL}秒後にリトライ (${DOWNLOAD_ATTEMPT}/${DOWNLOAD_RETRY_MAX})"
                sleep "$DOWNLOAD_RETRY_INTERVAL"
                continue
            fi
            log "DOWNLOAD_TOO_SMALL_FINAL ${FILE_SIZE}bytes after ${DOWNLOAD_RETRY_MAX} attempts"
            write_status "failed" "ダウンロードサイズ異常 (${FILE_SIZE}bytes, ${DOWNLOAD_RETRY_MAX}回試行)"
            _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "ダウンロードサイズ異常 (${FILE_SIZE}bytes, ${DOWNLOAD_RETRY_MAX}回試行)"
            return 1
        fi

        # サイズOK → 抜ける
        DOWNLOAD_SUCCESS=1
        if [ "$DOWNLOAD_ATTEMPT" -gt 1 ]; then
            log "DOWNLOAD_RETRY_SUCCESS attempt=${DOWNLOAD_ATTEMPT} size=${FILE_SIZE}bytes"
        fi
        break
    done

    # 照合値が提供されていない場合、以前は検証そのものを飛ばしていた。
    # これは「照合できない配布物を無検査で受け入れる」ことと同じであり、
    # 配信側の設定漏れがそのまま無防備な更新に化ける。判定できないときは止める。
    if [ -z "$EXPECTED_SHA256" ]; then
        log "CHECKSUM_MISSING url=$DOWNLOAD_URL"
        write_status "failed" "配布物の照合情報が得られなかったため更新を中止しました"
        _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "照合値未提供のため中止 (無検査適用の防止)"
        return 1
    fi

    if [ -n "$EXPECTED_SHA256" ]; then
        ACTUAL_SHA256=$(_sl_sha256 "$PACKAGE_FILE")
        # 大文字/小文字を正規化して比較 (登録側が大文字SHAでも恒久不一致にしない)
        ACTUAL_SHA256=$(printf '%s' "$ACTUAL_SHA256" | tr 'A-Z' 'a-z')
        EXPECTED_SHA256=$(printf '%s' "$EXPECTED_SHA256" | tr 'A-Z' 'a-z')
        if [ "$ACTUAL_SHA256" != "$EXPECTED_SHA256" ]; then
            log "CHECKSUM_MISMATCH expected=$EXPECTED_SHA256 actual=$ACTUAL_SHA256"
            write_status "failed" "チェックサム不一致"
            _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "チェックサム不一致 expected=$EXPECTED_SHA256 actual=$ACTUAL_SHA256"
            return 1
        fi
        log "CHECKSUM_VERIFIED $ACTUAL_SHA256"
    fi

    # 照合値は配布物と同じ経路で届くため、まとめて差し替えられると見抜けない。
    # 配信側だけが作れる署名を別に確かめる。確認できない場合は適用しない。
    if ! _sl_verify_artifact_signature "$PACKAGE_FILE" "$DOWNLOAD_URL" "$EXPECTED_SIGNATURE"; then
        # ★2026-09-20 是正: 止める判断は一切変えない。止めた理由だけを分けて伝える。
        #   「署名が合わない(すり替えの疑い)」と「こちらの本体が古くて確かめられない」は
        #   打つ手がまったく違うのに、同じ文言で報告されていた。
        SIG_FAIL_MSG="配布物の発行元を確認できなかったため更新を中止しました"
        case "${SL_SIG_FAIL_REASON:-}" in
            launcher_too_old|launcher_missing|no_verifier)
                SIG_FAIL_MSG="お手元の本体が古く署名を確認できないため更新を中止しました。本体の入れ替えが必要です"
                ;;
        esac
        write_status "failed" "$SIG_FAIL_MSG"
        _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "署名検証に失敗したため中止 reason=${SL_SIG_FAIL_REASON:-unknown}"
        return 1
    fi

    write_status "extracting" "パッケージ展開中"
    _append_history "extracting" "${NEW_VERSION:-$CURRENT_VERSION}" "パッケージ展開中"

    EXTRACT_DIR="$TEMP_DIR/extracted"
    mkdir -p "$EXTRACT_DIR"

    if file "$PACKAGE_FILE" 2>/dev/null | grep -q "gzip"; then
        tar xzf "$PACKAGE_FILE" -C "$EXTRACT_DIR" 2>/dev/null
    elif file "$PACKAGE_FILE" 2>/dev/null | grep -q "Zip"; then
        unzip -qo "$PACKAGE_FILE" -d "$EXTRACT_DIR" 2>/dev/null
    else
        case "$PACKAGE_FILE" in
            *.tar.gz|*.tgz) tar xzf "$PACKAGE_FILE" -C "$EXTRACT_DIR" 2>/dev/null ;;
            *.zip) unzip -qo "$PACKAGE_FILE" -d "$EXTRACT_DIR" 2>/dev/null ;;
            *) tar xzf "$PACKAGE_FILE" -C "$EXTRACT_DIR" 2>/dev/null || unzip -qo "$PACKAGE_FILE" -d "$EXTRACT_DIR" 2>/dev/null ;;
        esac
    fi

    if [ ! "$(ls -A "$EXTRACT_DIR" 2>/dev/null)" ]; then
        log "EXTRACT_FAILED"
        write_status "failed" "パッケージ展開失敗"
        _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "パッケージ展開失敗 (empty extract dir)"
        return 1
    fi

    SUBDIRS=$(find "$EXTRACT_DIR" -mindepth 1 -maxdepth 1 -type d 2>/dev/null)
    # grep -c は 0 件時に exit 1 を返すため `|| echo 0` だと "0\n0" になる (整数比較が壊れる)
    SUBDIR_COUNT=$(printf '%s' "$SUBDIRS" | grep -c '.')
    case "$SUBDIR_COUNT" in ''|*[!0-9]*) SUBDIR_COUNT=0 ;; esac
    if [ "$SUBDIR_COUNT" -eq 1 ] && [ ! -f "$EXTRACT_DIR/chain.sh" ]; then
        EXTRACT_DIR="$SUBDIRS"
    fi

    write_status "applying" "更新適用中"
    _append_history "applying" "${NEW_VERSION:-$CURRENT_VERSION}" "更新適用中"

    # バックアップ
    SAFE_CUR=$(echo "$CURRENT_VERSION" | tr -cd '0-9.')
    BACKUP_DIR="$SL_DIR/.backups/v${SAFE_CUR}_$(date +%Y%m%d%H%M%S)"
    mkdir -p "$BACKUP_DIR"
    cp "$SL_DIR/chain.sh" "$BACKUP_DIR/" 2>/dev/null || true
    cp "$SL_DIR/setup.sh" "$BACKUP_DIR/" 2>/dev/null || true
    if [ -d "$CLAUDE_DIR/skills" ]; then
        mkdir -p "$BACKUP_DIR/skills"
        for skill_dir in "$CLAUDE_DIR/skills/soloptilink"*/; do
            [ ! -d "$skill_dir" ] && continue
            skill_name=$(basename "$skill_dir")
            mkdir -p "$BACKUP_DIR/skills/$skill_name"
            cp "$skill_dir/SKILL.md" "$BACKUP_DIR/skills/$skill_name/" 2>/dev/null || true
        done
    fi

    log "BACKUP $BACKUP_DIR"

    # ステージング
    STAGE_DIR="$TEMP_DIR/staging"
    mkdir -p "$STAGE_DIR"
    UPDATE_COUNT=0
    STAGE_OK=true

    [ -f "$EXTRACT_DIR/chain.sh" ] && { cp "$EXTRACT_DIR/chain.sh" "$STAGE_DIR/chain.sh" || STAGE_OK=false; UPDATE_COUNT=$((UPDATE_COUNT + 1)); }
    [ -f "$EXTRACT_DIR/setup.sh" ] && { cp "$EXTRACT_DIR/setup.sh" "$STAGE_DIR/setup.sh" || STAGE_OK=false; UPDATE_COUNT=$((UPDATE_COUNT + 1)); }
    [ -f "$EXTRACT_DIR/VERSION" ] && { cp "$EXTRACT_DIR/VERSION" "$STAGE_DIR/VERSION" || STAGE_OK=false; UPDATE_COUNT=$((UPDATE_COUNT + 1)); }
    if [ -d "$EXTRACT_DIR/lib" ]; then
        mkdir -p "$STAGE_DIR/lib"
        _sl_mirror_dir "$EXTRACT_DIR/lib/" "$STAGE_DIR/lib/" || STAGE_OK=false
        UPDATE_COUNT=$((UPDATE_COUNT + 1))
    fi

    if [ "$STAGE_OK" = false ]; then
        log "STAGING_FAILED"
        write_status "failed" "ステージング失敗"
        _append_history "failed" "${NEW_VERSION:-$CURRENT_VERSION}" "ステージング失敗 (cp / rsync エラー)"
        return 1
    fi

    # ★2026-10-28: 管理者の開発の木では、配布物より新しい開発中の作業 (git で記録していない・記録と違う)
    #   を消さない・上書きしない。ここで退避し、本体へ書き終えた後に上書きして戻す (下の「開発中の作業を戻す」)。
    #   対象は、この先で本体へ書く場所すべて。お客様の端末では判定が空を返すため、従来と完全に同じ動きになる。
    _SL_DEVWORK_STASH="${TMPDIR:-/tmp}/sl-devwork.$$"
    _SL_DEVWORK_LIST=""
    _SL_DEVWORK_NOTE=""
    rm -rf "$_SL_DEVWORK_STASH" 2>/dev/null
    if ! _sl_protect_devwork_stash "$_SL_DEVWORK_STASH" chain.sh setup.sh VERSION auto-update.sh \
            version-manifest.json "$LAUNCHER_NAME" lib scripts migration domains integrations skills; then
        # 管理者の開発の木なのに判定できない → 本体の入れ替えを見送る (消すより止める)。
        # ★「失敗」と記録すると、起動用プログラムが自前の適用で続けてしまい、そちらにはこの守りが無い
        #   (launcher/hook_autoupdate.go の waitBashDelegation は failed を見ると続ける)。
        #   そのため状態の語は success のまま、文面と履歴に「見送り」と書く。
        rm -rf "$_SL_DEVWORK_STASH" 2>/dev/null
        _SL_DEVWORK_HELD=1
        log "DEVWORK_HOLD 管理者の開発の木の作業を判定できないため、v${NEW_VERSION} の本体への適用を見送りました"
        write_status "success" "見送り: 開発中の作業を判定できないため本体の部品を入れ替えていません (v${CURRENT_VERSION} のまま)"
        _append_history "held" "$CURRENT_VERSION" "開発中の作業を判定できないため v${NEW_VERSION} の適用を見送り"
        return 0
    fi

    # 本適用
    [ -f "$STAGE_DIR/chain.sh" ] && { cp "$STAGE_DIR/chain.sh" "$SL_DIR/chain.sh"; chmod +x "$SL_DIR/chain.sh"; }
    [ -f "$STAGE_DIR/setup.sh" ] && { cp "$STAGE_DIR/setup.sh" "$SL_DIR/setup.sh"; chmod +x "$SL_DIR/setup.sh"; }
    [ -f "$STAGE_DIR/VERSION" ] && cp "$STAGE_DIR/VERSION" "$SL_DIR/VERSION"
    if [ -d "$STAGE_DIR/lib" ]; then
        # 削除同期の射程から社内専用資産を守る (2026-08-15 の全消失事故の再発防止)。
        # 目録が無い環境では退避も復帰も何もしないため、従来と同じ挙動になる。
        _SL_LIB_PROTECT_STASH="${TMPDIR:-/tmp}/sl-libprotect.$$"
        rm -rf "$_SL_LIB_PROTECT_STASH" 2>/dev/null
        _sl_protect_stash "$SL_DIR/lib" "$_SL_LIB_PROTECT_STASH"
        # ★2026-09-07 新設: 消えるファイルだけを控えてから同期する
        _sl_stash_removed "$STAGE_DIR/lib" "$SL_DIR/lib" "$BACKUP_DIR/lib-removed"
        _sl_mirror_dir "$STAGE_DIR/lib/" "$SL_DIR/lib/"
        _sl_protect_restore "$SL_DIR/lib" "$_SL_LIB_PROTECT_STASH"
        rm -rf "$_SL_LIB_PROTECT_STASH" 2>/dev/null
        find "$SL_DIR/lib/" -name '*.sh' -exec chmod +x {} + 2>/dev/null
    fi
    # ========================================
    # v2041.0 / PFP-122 (2026-06-13): DBL業種辞書 domains/ + IBL連携辞書 integrations/ を同期。
    # 【重大欠陥の修正】従来 do_update は domains/integrations を一切同期せず、
    # 業種辞書・連携辞書の追加/更新が既存顧客の自動更新で永遠に届かなかった。
    # パッケージに含まれる場合のみ rsync (含まれない旧パッケージで顧客の既存辞書を
    # 消さないよう、ディレクトリ存在を条件にする = 後方互換)。
    # ========================================
    # 重要: --delete を使わず overlay 同期にする。boost(Step 0.8)は未登録業種の DBL を、
    # Connector Forge(Step 0.9)は未登録サービスの連携辞書を顧客の domains//integrations/ に
    # 作成するため、--delete だと更新のたびに顧客/FDE が作った辞書を消してしまう(データ消失)。
    # overlay なら公式辞書は新版で上書き更新しつつ、顧客作成辞書を保全できる。
    for kb in domains integrations; do
        if [ -d "$EXTRACT_DIR/$kb" ] && [ -n "$(ls -A "$EXTRACT_DIR/$kb" 2>/dev/null)" ]; then
            mkdir -p "$SL_DIR/$kb"
            if _sl_overlay_dir "$EXTRACT_DIR/$kb/" "$SL_DIR/$kb/" 2>/dev/null; then
                kb_n=$(find "$SL_DIR/$kb" -name '*.json' 2>/dev/null | wc -l | tr -d ' ')
                UPDATE_COUNT=$((UPDATE_COUNT + 1))
                log "KB_SYNCED $kb ($kb_n dictionaries, overlay)"
            fi
        fi
    done
    [ -f "$EXTRACT_DIR/version-manifest.json" ] && cp "$EXTRACT_DIR/version-manifest.json" "$SL_DIR/version-manifest.json"
    [ -f "$EXTRACT_DIR/auto-update.sh" ] && { cp "$EXTRACT_DIR/auto-update.sh" "$SL_DIR/auto-update.sh"; chmod +x "$SL_DIR/auto-update.sh"; }

    # PFP-064b (2026-07-06): scripts/ (skill-sot-guard 等の構造防御) と migration/ (遡及配線) を同期する。
    # 従来はどちらも導入時のまま更新されず、①旧 skill-sot-guard が更新直後の heal で新表記を
    # 旧 SoT へ巻き戻す ②新規 migration が既存顧客に一切届かない、の2欠陥があった。
    # tar に同梱済みの内容をそのまま反映する (--delete はしない: 顧客側の状態ファイルを保全)。
    for sync_dir in scripts migration; do
        if [ -d "$EXTRACT_DIR/$sync_dir" ] && [ -n "$(ls -A "$EXTRACT_DIR/$sync_dir" 2>/dev/null)" ]; then
            mkdir -p "$SL_DIR/$sync_dir"
            if _sl_overlay_dir "$EXTRACT_DIR/$sync_dir/" "$SL_DIR/$sync_dir/" 2>/dev/null; then
                UPDATE_COUNT=$((UPDATE_COUNT + 1))
                log "DIR_SYNCED $sync_dir"
            fi
        fi
    done

    # ========================================
    # Goランチャーバイナリの配布
    # パッケージ内の bin/ ディレクトリからOS/Arch一致バイナリを配置
    # ========================================
    BIN_DEPLOYED=false
    # 配置先はランチャー実体名 (Windows=soloptilink.exe / それ以外=soloptilink)。
    BIN_TARGET="$SL_DIR/$LAUNCHER_NAME"
    if [ -d "$EXTRACT_DIR/bin" ]; then
        # OS/Archに合ったバイナリを選択 (Windows は .exe サフィックス)
        BIN_NAME="soloptilink-${API_OS}-${ARCH}"
        [ "$API_OS" = "windows" ] && BIN_NAME="soloptilink-windows-${ARCH}.exe"
        if [ -f "$EXTRACT_DIR/bin/$BIN_NAME" ]; then
            # ★2026-09-07 是正: コピーの成否を見てから「置いた」と記録する。
            #   従来は cp の戻り値を見ずに BINARY_DEPLOYED を記録していた。
            #   いまは bin/ に本体の実行ファイルが入っていないため一度も通らないが、
            #   将来ここへ実行ファイルを載せた瞬間、コピーに失敗しても
            #   「置きました」と記録が残る (実行中のファイルは置き換えに失敗しうる)。
            #   置いたつもりで置けていない状態を、成功と言わない。
            if cp "$EXTRACT_DIR/bin/$BIN_NAME" "$BIN_TARGET" 2>/dev/null; then
                chmod +x "$BIN_TARGET" 2>/dev/null || true
                BIN_DEPLOYED=true
                UPDATE_COUNT=$((UPDATE_COUNT + 1))
                log "BINARY_DEPLOYED $BIN_NAME -> $BIN_TARGET"
            else
                log "BINARY_DEPLOY_FAILED $BIN_NAME -> $BIN_TARGET (置けませんでした)"
            fi
        fi
    fi
    # フォールバック: パッケージ直下の soloptilink バイナリ
    if [ "$BIN_DEPLOYED" = false ] && [ -f "$EXTRACT_DIR/soloptilink" ]; then
        # ★2026-09-07 是正: 上と同じ理由でコピーの成否を見る
        if cp "$EXTRACT_DIR/soloptilink" "$BIN_TARGET" 2>/dev/null; then
            chmod +x "$BIN_TARGET" 2>/dev/null || true
            UPDATE_COUNT=$((UPDATE_COUNT + 1))
            log "BINARY_DEPLOYED soloptilink -> $BIN_TARGET"
        else
            log "BINARY_DEPLOY_FAILED soloptilink -> $BIN_TARGET (置けませんでした)"
        fi
    fi

    # skills/agents/hooks → ~/.claude/
    if [ -d "$EXTRACT_DIR/skills" ]; then
        for skill_dir in "$EXTRACT_DIR/skills/"*/; do
            [ ! -d "$skill_dir" ] && continue
            skill_name=$(basename "$skill_dir")
            mkdir -p "$CLAUDE_DIR/skills/$skill_name"
            # 2026-07-15: アトミック置換 (書込途中の SKILL.md をスキル走査に見せない=メニュー脱落根絶)
            [ -f "$skill_dir/SKILL.md" ] && { _sl_atomic_cp "$skill_dir/SKILL.md" "$CLAUDE_DIR/skills/$skill_name/SKILL.md"; UPDATE_COUNT=$((UPDATE_COUNT + 1)); }
            if [ -d "$skill_dir/references" ]; then
                _sl_atomic_dir_replace "$skill_dir/references" "$CLAUDE_DIR/skills/$skill_name/references" || true
            fi
            # 本体同梱ミラー (~/.soloptilink/skills/<name>/) も必ず更新する (2026-07-13 v2040発E2Eで実証)。
            # Goランチャーの writeback heal はこのミラーを SoT として ~/.claude/skills を修復するため、
            # ここが旧版のままだと更新直後にスキルが旧版へ巻き戻される (Goネイティブ経路と同等化)。
            if [ -f "$skill_dir/SKILL.md" ]; then
                mkdir -p "$SL_DIR/skills/$skill_name"
                _sl_atomic_cp "$skill_dir/SKILL.md" "$SL_DIR/skills/$skill_name/SKILL.md" || true
                if [ -d "$skill_dir/references" ]; then
                    _sl_atomic_dir_replace "$skill_dir/references" "$SL_DIR/skills/$skill_name/references" || true
                fi
            fi
            # ★PFP-201: SKILL.md/references 以外の同梱資産 (連携ブリッジ等) も運ぶ。
            # ここが無いと、パッケージに資産が入っていても顧客端末には置かれず、
            # SKILL.md が指示する node 実行が「存在しないファイル」を叩く。
            _sl_copy_skill_extras "$skill_dir" "$CLAUDE_DIR/skills/$skill_name"
            _sl_copy_skill_extras "$skill_dir" "$SL_DIR/skills/$skill_name"
            # PFP-064b (2026-07-06): SoT (~/.claude/commands/<name>.md) も同時更新する。
            # 従来は SoT が導入時版のまま残り、直後の skill-sot-guard heal が新 SKILL.md を
            # 旧版へ巻き戻して「本体は最新・表記は旧版」に固着した (実例: 本体 v2050.1 で表記 v2038.0)。
            # soloptilink* のみ対象 = 顧客が自作した commands を上書きしない。
            case "$skill_name" in
                soloptilink*)
                    if [ -f "$skill_dir/SKILL.md" ]; then
                        mkdir -p "$CLAUDE_DIR/commands"
                        _sl_atomic_cp "$skill_dir/SKILL.md" "$CLAUDE_DIR/commands/${skill_name}.md"
                        UPDATE_COUNT=$((UPDATE_COUNT + 1))
                        log "SOT_REFRESHED commands/${skill_name}.md"
                    fi
                    ;;
            esac
        done
    fi
    if [ -d "$EXTRACT_DIR/agents" ]; then
        mkdir -p "$CLAUDE_DIR/agents"
        for agent_file in "$EXTRACT_DIR/agents/"*.md; do
            [ ! -f "$agent_file" ] && continue
            cp "$agent_file" "$CLAUDE_DIR/agents/"
            UPDATE_COUNT=$((UPDATE_COUNT + 1))
        done
    fi
    if [ -f "$EXTRACT_DIR/hooks/soloptilink-session-guard.sh" ]; then
        mkdir -p "$CLAUDE_DIR/hooks"
        cp "$EXTRACT_DIR/hooks/soloptilink-session-guard.sh" "$CLAUDE_DIR/hooks/"
        chmod +x "$CLAUDE_DIR/hooks/soloptilink-session-guard.sh"
        UPDATE_COUNT=$((UPDATE_COUNT + 1))
    fi

    # ★2026-10-28: 開発中の作業を戻す (上の退避と対)。本体へ書き終えたここで、配布物の版で上書き・削除された
    #   作業を上書きして戻し、上書きされかけた配布物の版は控え (devwork-package-versions) に残す。
    #   お客様の端末では退避が空なので何もしない。
    _sl_protect_devwork_restore "$_SL_DEVWORK_STASH" "$BACKUP_DIR/devwork-package-versions"
    _SL_DEVWORK_LIST="$(cat "$_SL_DEVWORK_STASH/list" 2>/dev/null)"
    rm -rf "$_SL_DEVWORK_STASH" 2>/dev/null

    # クリーンアップ
    if [ -d "$SL_DIR/.backups" ]; then
        ls -td "$SL_DIR/.backups/"*/ 2>/dev/null | tail -n +6 | while IFS= read -r old_dir; do
            rm -rf "$old_dir"
        done
    fi

    # ========================================
    # 適用後検証 (2026-07-13 恒久対策): 「成功」を宣言する前に、chain.sh の版が
    # 実際に目標版へ進んだことを実測する。従来は UPDATE_COUNT=0 (何も適用されず) でも
    # UPDATE_COMPLETE を書いており、ランチャー/顧客が偽成功を信じるデッドロックを生んだ。
    # ========================================
    APPLIED_VERSION=$(grep 'readonly VERSION=' "$SL_DIR/chain.sh" 2>/dev/null | head -1 | grep -o '"[^"]*"' | tr -d '"')
    # ★2026-10-28: 管理者の開発の木で chain.sh を開発中の作業として残した場合、版は開発中の版のまま
    #   (配布物より新しい) で正しい。これを失敗と記録すると、起動用プログラムが守りの無い自前の適用で続けてしまう。
    if [ "$APPLIED_VERSION" != "$NEW_VERSION" ] && printf '%s\n' "$_SL_DEVWORK_LIST" | grep -qxF 'chain.sh'; then
        log "APPLY_VERIFY_DEVWORK chain.sh は開発中の版を残しました applied=${APPLIED_VERSION:-none} package=$NEW_VERSION"
        _SL_DEVWORK_NOTE=" 開発中の chain.sh (v${APPLIED_VERSION:-不明}) を残しました"
    elif [ "$APPLIED_VERSION" != "$NEW_VERSION" ]; then
        log "APPLY_VERIFY_FAILED applied=${APPLIED_VERSION:-none} expected=$NEW_VERSION files=$UPDATE_COUNT"
        write_status "failed" "適用後検証失敗 (適用版=${APPLIED_VERSION:-不明} 期待版=${NEW_VERSION})"
        _append_history "failed" "$NEW_VERSION" "適用後検証失敗 applied=${APPLIED_VERSION:-none} files=$UPDATE_COUNT"
        return 1
    fi

    # (お客様の端末では _SL_DEVWORK_NOTE は空 = 従来と同じ文面)
    write_status "success" "v${CURRENT_VERSION} -> v${NEW_VERSION} (${UPDATE_COUNT} files)${_SL_DEVWORK_NOTE:-}"
    _append_history "success" "${NEW_VERSION:-$CURRENT_VERSION}" "v${CURRENT_VERSION} -> v${NEW_VERSION} (${UPDATE_COUNT} files)${_SL_DEVWORK_NOTE:-}"
    log "UPDATE_COMPLETE v${CURRENT_VERSION} -> v${NEW_VERSION} (${UPDATE_COUNT} files)${_SL_DEVWORK_NOTE:-}"

    # PFP-064: do_update が Go embed writeback で ~/.claude/skills/ を古いバージョンに
    # 書き戻してしまった場合、即座に SoT (~/.claude/commands/<name>.md) から修復する。
    # 失敗しても無視 (do_update の成功 status を上書きしない)。
    if [ -x "${HOME}/.soloptilink/scripts/structural-defenses/skill-sot-guard.sh" ]; then
        bash "${HOME}/.soloptilink/scripts/structural-defenses/skill-sot-guard.sh" heal --silent 2>&1 >> "$LOG_FILE" || true
    fi

    # PFP-093: 顧客端末で Centuria ロスター (105体実起動エンジンの依存) を確実に生成する。
    # 配信される ~/.claude/agents/*.md (118体) から centuria-roster.json を再構築し、
    # 「105体が本物として動く」エンジンが顧客端末で初回から成立する状態を保証する。
    if [ -x "${HOME}/.soloptilink/lib/centuria-roster.sh" ]; then
        bash "${HOME}/.soloptilink/lib/centuria-roster.sh" build 2>&1 >> "$LOG_FILE" || true
    fi

    # v2052.3 fleet-wide: production_gate 自動 arm (既存 60 顧客 instance への遡及配布経路)。
    # 冪等 — 既に arm 済みなら skip。失敗しても更新完了ステータスを落とさない (fail-silent)。
    # ~/.soloptilink/.production_gate が armed 状態なら env override 攻撃を全排除する。
    if [ -x "${HOME}/.soloptilink/lib/migration/v2052.3-production-gate-arm.sh" ]; then
        SOLOPTILINK_MIGRATION_LOG="$LOG_FILE" \
            bash "${HOME}/.soloptilink/lib/migration/v2052.3-production-gate-arm.sh" >> "$LOG_FILE" 2>&1 || true
    fi

    # v2052.6 fleet-wide: semantic-detector daemon 常駐化 (PFP-165 cold-start 根治)。
    # 既存 60 顧客 instance に launchd/systemd 常駐設定を遡及配布し、hook 8 秒
    # timeout 内で socket 応答を保証する (fail-open 窓の構造的根絶)。
    # 冪等 — 既に load 済みなら unload → reload で最新テンプレートに更新。
    # 失敗しても更新完了ステータスを落とさない (fail-silent)。
    if [ -x "${HOME}/.soloptilink/lib/migration/v2052.6-semantic-daemon-install.sh" ]; then
        SOLOPTILINK_MIGRATION_LOG="$LOG_FILE" \
            bash "${HOME}/.soloptilink/lib/migration/v2052.6-semantic-daemon-install.sh" >> "$LOG_FILE" 2>&1 || true
    fi

    # ============================================================
    # 【IP-030 / IP-031 結線 2026-09-20】更新でも導入台帳を取り直す
    # ------------------------------------------------------------
    # なぜ更新の経路にも要るか (実測):
    #   お客様のほぼ全員が通るのは新規導入ではなく更新導入であり、
    #   自動更新は setup.sh を通らない。この 1 行が無いと台帳が
    #   導入時のまま古くなり、更新で中身が変わったファイルが
    #   sha256 不一致 → 判別不能 → 当社が置いたものが
    #   「お客様のもの」として端末に残る。
    #   実物規模の砂箱 (台帳 6,505 行) で、中身が変わった 30 件と
    #   増えた 10 件を当てて測った結果:
    #     この呼び出しが無い  … 40 件すべて判別不能 (消えずに残る)
    #     この呼び出しが有る  … 40 件すべて当社のものと判定 (sha256 一致)
    # 置き場所の理由:
    #   本体・スキル・命令ファイル・担当定義・移行処理まで
    #   すべて置き終えた後でなければ、後から置かれたものを取りこぼす。
    #   そのため do_update の最後尾に置く。
    # ★更新の完了を絶対に妨げない (fail-open):
    #   部品が無ければ何もしない。失敗しても `|| true` で握りつぶす。
    #   ここは write_status "success" より後なので、仮にこの呼び出しが
    #   丸ごと失敗しても更新の成否判定には一切影響しない。
    #   ★source (.) ではなく別プロセス (bash) で呼ぶ。
    #     source にすると、部品の中の exit が do_update ごと、
    #     前面実行のときはこの更新処理ごと終わらせてしまう
    #     (砂箱で実際に壊して確認した)。
    # ★お客様の画面を乱さないため無言で動かす (SL_IH_QUIET=1)。
    #   記録は ~/.claude/.soloptilink-install-ledger.jsonl に残る。
    # ============================================================
    if [ -f "${HOME}/.soloptilink/lib/evict-delivery/install-hook.sh" ]; then
        SL_IH_EVENT=update SL_IH_QUIET=1 bash "${HOME}/.soloptilink/lib/evict-delivery/install-hook.sh" || true
        _SL_LEDGER_LINES=$(wc -l < "${HOME}/.claude/.soloptilink-file-manifest.jsonl" 2>/dev/null | tr -d ' ')
        log "INSTALL_LEDGER_REFRESHED event=update version=${NEW_VERSION:-unknown} lines=${_SL_LEDGER_LINES:-0}"
    else
        log "INSTALL_LEDGER_SKIPPED reason=hook_missing version=${NEW_VERSION:-unknown}"
    fi

    # ============================================================
    # 【穴4 是正 2026-09-21】更新で中身が変わったので、目録を作り直して封印し直す
    # ------------------------------------------------------------
    # なぜ更新の経路にも要るか:
    #   お客様のほぼ全員が通るのは新規導入ではなく更新導入であり、
    #   自動更新は setup.sh を通らない。封印し直さないと、当社が正規に
    #   配信した新しいエンジンが「書き換えられた」と出てしまい、
    #   恒常的に赤い照合は本物の改ざんを埋もれさせる。
    #   逆に、ここで封印し直すことで「正規の更新後は一致・第三者の
    #   書き換えだけが不一致」という弁別が成り立つ。
    # 置き場所の理由:
    #   本体・スキル・命令ファイル・担当定義・移行処理まですべて置き終え、
    #   導入台帳の記録も済んだ後でなければ、目録が実物と食い違う。
    #   そのため do_update の最後尾、配達口の直後に置く。
    # ★更新の完了を絶対に妨げない (fail-open):
    #   部品が無ければ何もしない。失敗しても `|| true` で握りつぶす。
    #   ここは write_status "success" より後なので、仮に丸ごと失敗しても
    #   更新の成否判定には一切影響しない。
    #   ★source (.) ではなく別プロセス (bash) で呼ぶ
    #     (source だと部品の中の exit が更新処理ごと終わらせる)。
    # ★お客様の画面を乱さないため無言で動かす (--quiet)。記録は
    #   ~/.soloptilink/logs/tamper-guard.jsonl と更新ログに残る。
    # ============================================================
    if [ -f "${HOME}/.soloptilink/lib/tamper-guard/install-seal.sh" ]; then
        _SL_SEAL_RC=0
        bash "${HOME}/.soloptilink/lib/tamper-guard/install-seal.sh" --reason update --quiet || _SL_SEAL_RC=$?
        log "TAMPER_SEAL_REFRESHED event=update version=${NEW_VERSION:-unknown} rc=${_SL_SEAL_RC}"
    else
        log "TAMPER_SEAL_SKIPPED reason=component_missing version=${NEW_VERSION:-unknown}"
    fi
}

# ========================================
# 実行モード分岐
# ========================================
if [ "$FORCE_UPDATE" = true ]; then
    # フォアグラウンド実行（Goランチャーの --update から呼ばれる）
    # 2026-07-13 敵対検証で確証: 旧実装は do_update 失敗 (適用後検証 failed 含む) でも
    # 無条件に「完了」を出力して exit 0 していた (偽成功)。結果を正直に返す。
    if do_update; then
        if [ "${_SL_DEVWORK_HELD:-0}" = 1 ]; then
            # 管理者の開発の木で判定できず見送った (完了と言わない)
            echo "[SoloptiLinkAI] 開発中の作業を判定できないため、v${NEW_VERSION} の本体への適用を見送りました (v${CURRENT_VERSION} のまま)"
        else
            echo "[SoloptiLinkAI] v${CURRENT_VERSION} → v${NEW_VERSION} パッケージ更新完了"
        fi
    else
        echo "[SoloptiLinkAI] 更新の適用に失敗しました。もう一度お試しいただくか、サポートへご連絡ください。" >&2
        exit 1
    fi
else
    # 背面実行（フック経由・切り離す手段が無い端末のみここへ来る）
    ( do_update ) >> "$LOG_FILE" 2>&1 &
    # ★2026-08-27 (REQ-EX-08): 自作の擬似タグを外した。当版 (2.1.150) の実測では
    #   UserPromptSubmit の標準出力はタグ無しでも文脈に入り、可視エントリも作らない。
    #   タグはそのまま顧客へ転載される露出源にしかならない。
    cat << EOF
[SoloptiLinkAI] v${NEW_VERSION} への自動更新をバックグラウンドで開始しました。
完了後、次のセッションから新バージョンが適用されます。
EOF
fi

exit 0
