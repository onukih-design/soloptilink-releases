﻿# =============================================================================
# SoloptiLinkAI v2038.2 - Windows PowerShell Installer
# =============================================================================
# Built: 2026-06-11 (Nomura incident response - ZIP配布形式対応)
# Purpose: 配布物の自動配置 + lib/ 完整性検証 + Goランチャー認証起動
#   モードA (ZIP配布 / 主経路): 解凍済み配布フォルダ (installer の親) を
#     ~\.soloptilink へ配置する。顧客ZIP (SoloptiLinkAI_vX.Y_Windows.zip) は
#     展開済みフォルダ形式のため tar.gz は同梱されない。
#   モードB (tar.gz / 保守経路): soloptilink-update-*.tar.gz を検出して展開する。
# Compliance: WCG-2 (critical files), WCG-5 (LF guard), WCG-11 (tar)
# Hinoue-incident compliant: no cls / no findstr / END_PAUSE / STEP markers
# =============================================================================

[CmdletBinding()]
param(
    [string]$TarballPath = "",
    # 2026-07-13: $HOME (HOMEDRIVE+HOMEPATH 由来) ではなく %USERPROFILE% を既定にする。
    # Goランチャー/自動更新フックは os.UserHomeDir()=%USERPROFILE% を参照するため、
    # AD ホームフォルダリダイレクトのある企業PCで導入先と参照先が分裂する事故を防ぐ。
    [string]$InstallDir = $(if ($env:USERPROFILE) { Join-Path $env:USERPROFILE '.soloptilink' } else { "$HOME\.soloptilink" }),
    [switch]$SkipExtract,
    [switch]$Force,
    [switch]$Verify,
    [switch]$NoActivate
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

# ★2026-09-29: お客様と同じ「まず最初にこれを実行.bat」から起動する実証 (CI) では、.bat を経由するため
#   -NoActivate を渡せない。環境変数でも端末のご登録を行わない指定を受け付ける (登録を省くだけで、
#   ほかの工程・判定は変えない)。
if ($env:SOLOPTILINK_INSTALL_NO_ACTIVATE -eq '1') { $NoActivate = $true }

# -----------------------------------------------------------------------------
# 進捗バー (Write-Progress) の全面停止
# -----------------------------------------------------------------------------
# 2026-09-02: 実機 (Windows 10.0.26200 / PowerShell 5.1) で日本語が二重に描かれる
#   現象を再現・特定した。Test-NetConnection 等のコマンドが出す進捗バーは、
#   コンソールの可視領域を繰り返し上書きして描き直す。chcp 65001 (UTF-8) の
#   従来コンソールでは、この上書き描画で全角文字だけが二重化し、
#   「イインンスストトーールル先先確確認認」のように崩れる (半角英数字は無傷)。
#   実機ログでは、崩れの開始・終了が進捗バーの生存区間と完全に一致していた。
#   本設定は表示の抑止のみで、機能・戻り値・ログ内容には一切影響しない。
$ProgressPreference = 'SilentlyContinue'

# -----------------------------------------------------------------------------
# Colored output (Hinoue-incident compliant: no cls, no findstr)
# -----------------------------------------------------------------------------
# いま実行中の工程 (異常終了画面が「どこで止まったか」を言えるようにするための状態)
#   ★2026-08-15 新設。従来 Write-Step は工程名を【表示】するだけで、どこまで進んだかを
#     保持する場所がどこにも無かった。そのため最上位 trap は「予期しない問題が発生しました」
#     としか言えず、お客様は止まった場所も次の一手も分からないまま放置された
#     (過去の導入失敗と同じ構造)。工程名と、その工程で次にすることを保持する。
$script:CurrentStep     = '準備中'
$script:CurrentStepNext = 'このファイルをもう一度実行して、はじめからやり直してください。'
function Write-Step($msg, $next) {
    $script:CurrentStep = $msg
    if ($next) { $script:CurrentStepNext = $next }
    else { $script:CurrentStepNext = 'このファイルをもう一度実行してください。ここまでの導入内容はそのまま残っています。' }
    Write-Host "[STEP] $msg" -ForegroundColor Cyan
}
function Write-Ok($msg)   { Write-Host "[ OK ] $msg" -ForegroundColor Green }
function Write-Warn($msg) { Write-Host "[WARN] $msg" -ForegroundColor Yellow }
function Write-Err($msg)  { Write-Host "[FAIL] $msg" -ForegroundColor Red }
function Write-Skip($msg) { Write-Host "[SKIP] $msg" -ForegroundColor DarkGreen }

# 前提ソフト導入の「要対応一覧」を集約する collector (StrictMode 対策で先に初期化)
$script:Issues    = @()
$script:HasWinget = $false
$script:LogPath   = ""
$script:DetailPath = ""
function Add-Issue($item, $detail, $remedy) {
    $script:Issues += [PSCustomObject]@{ Item = $item; Detail = $detail; Remedy = $remedy }
}
function Test-CommandExists($name) {
    return [bool](Get-Command $name -ErrorAction SilentlyContinue)
}
# 前提ソフトの 3 値判定 (Mac 側 prereq_probe と同じ規律を Windows でも用いる)
#   absent = 入口ごと無い / present_but_broken = 入口はあるが動かない / available = 実際に動く
#   ★存在確認だけで合格にしない。Windows には python3.exe のように「ストアへ誘導するだけの
#     入口」が既定で置かれており、在ることと使えることは別である。
$script:PrereqVersion = ''
function Get-PrereqVerdict($cmd, $verArg, $pattern) {
    $script:PrereqVersion = ''
    if (-not (Test-CommandExists $cmd)) { return 'absent' }
    $out = ''
    try { $out = ((& $cmd $verArg 2>&1 | Select-Object -First 1 | Out-String)).Trim() } catch { $out = '' }
    if (-not $out) { return 'present_but_broken' }
    if ($out -match $pattern) { $script:PrereqVersion = $out; return 'available' }
    return 'present_but_broken'
}

# ★2026-09-02 是正 (T-702c): Windows での Python の呼び名は 1 つに決まらない。
#   ・python.org 版を導入しても増えるのは python.exe と py.exe で、python3 は作られない
#   ・既定で置かれている python3.exe は Microsoft Store へ誘導するだけの入口で、
#     存在はする (Test-CommandExists は真を返す) が実行しても Python は動かない
#   そのため「python3 が在るか」だけで判定すると、Python を導入済みの PC でも「無い」と
#   判定してしまう。導入前の注意書き・要対応・バージョン表示の 3 か所が別々に
#   python3 を決め打っていたため、同じ誤判定が 3 か所に出ていた。ここに 1 本化する。
#   見つかった呼び名は $script:PyCmd / $script:PyArgs に残し、呼び出し側が再利用する。
#   PATH は導入の途中で変わるため、都度探し直す (結果を使い回さない)。
$script:PyCmd     = ''
$script:PyArgs    = @()
$script:PyVersion = ''
function Resolve-Python {
    $script:PyCmd = ''
    $script:PyArgs = @()
    $script:PyVersion = ''
    foreach ($cand in @('python3|', 'python|', 'py|-3')) {
        $parts = $cand.Split('|')
        $exe = $parts[0]
        $pre = $parts[1]
        if (-not (Test-CommandExists $exe)) { continue }
        $out = ''
        try {
            if ($pre) { $out = ((& $exe $pre '--version' 2>&1 | Select-Object -First 1 | Out-String)).Trim() }
            else      { $out = ((& $exe '--version'      2>&1 | Select-Object -First 1 | Out-String)).Trim() }
        } catch { $out = '' }
        if ($out -match 'Python\s+3\.') {
            $script:PyCmd = $exe
            if ($pre) { $script:PyArgs = @($pre) } else { $script:PyArgs = @() }
            $script:PyVersion = $out
            return $true
        }
    }
    # ★2026-09-02 追加 (T-702e): 呼び名がどれも通らないときは、公式インストーラの既定の
    #   配置先を直接調べる。次の 2 つの PC では「入っているのに無い」と判定されるため。
    #     (1) 導入時に「Add python.exe to PATH」を付けなかった PC
    #     (2) いま winget で導入した直後で、PATH がまだこのウィンドウに反映されていない PC
    #   見つかった実体は絶対パスのまま $script:PyCmd に残す (呼び出し側は & で実行するため
    #   空白を含むパスでもそのまま動く)。ここで見つからなければ従来どおり false を返す。
    $pyRoots = @()
    if ($env:LOCALAPPDATA) { $pyRoots += (Join-Path $env:LOCALAPPDATA 'Programs\Python') }
    if ($env:ProgramFiles)  { $pyRoots += $env:ProgramFiles }
    if (${env:ProgramFiles(x86)}) { $pyRoots += ${env:ProgramFiles(x86)} }
    foreach ($pyRoot in $pyRoots) {
        if (-not (Test-Path $pyRoot)) { continue }
        $pyDirs = @()
        try {
            $pyDirs = @(Get-ChildItem -LiteralPath $pyRoot -Directory -ErrorAction SilentlyContinue |
                        Where-Object { $_.Name -match '^Python3\d+$' } |
                        Sort-Object { [int]($_.Name -replace '^Python', '') } -Descending)
        } catch { $pyDirs = @() }
        foreach ($pyDir in $pyDirs) {
            $pyExe = Join-Path $pyDir.FullName 'python.exe'
            if (-not (Test-Path $pyExe)) { continue }
            $out = ''
            try { $out = ((& $pyExe '--version' 2>&1 | Select-Object -First 1 | Out-String)).Trim() } catch { $out = '' }
            if ($out -match 'Python\s+3\.') {
                $script:PyCmd = $pyExe
                $script:PyArgs = @()
                $script:PyVersion = $out
                return $true
            }
        }
    }
    return $false
}
# 現セッションの PATH をマシン+ユーザー+既知の claude 配置先から再構築する。
# (winget / ネイティブインストーラ導入直後は現セッションに PATH 未反映のため必須)
#
# ★ ~/.local\bin を固定合成している理由 (重要・既知バグ #21365 への対処):
#   Claude Code 公式ネイティブインストーラ (irm https://claude.ai/install.ps1 | iex) は
#   claude.exe を ~/.local\bin (C:\Users\<user>\.local\bin) へ配置するが、
#   ユーザー PATH レジストリ (HKCU Environment の Path) を更新しない既知バグがある
#   (anthropics/claude-code #21365 / #14902)。このため「Installation complete!」と
#   表示されても claude が CommandNotFoundException で即失敗する。本関数が ~/.local\bin
#   を固定で合成することで、レジストリ未更新でも現セッションから claude を発見でき、
#   この既知バグを回避している。
#   ※ 配置先 ~/.local\bin はハードコード前提。将来インストーラの配置先が変われば
#     この固定合成は追従しない。配信前に必ず実機で最新の配置先を確認すること。
# ★2026-09-29: Claude Code の置き場所を「利用者の PATH」へ恒久登録する。
#   公式インストーラが PATH を登録しない既知事象 (#21365) があり、従来はこのセッションの中だけ
#   PATH を足していた。そのため別の画面から claude を打つと見つからず、しかも案内は
#   「PC 再起動後に反映」だったが、登録が無い以上は再起動しても直らない (v2056.8 の実証記録で確認)。
#   既に含まれていれば何もしない。登録値の種類 (展開形式) は保ったまま末尾に足す。
#   失敗してもセットアップは止めない (このセッションの PATH 合成は従来どおり効く)。
function Register-ClaudeUserPath {
    try {
        $upBase = $env:USERPROFILE
        if (-not $upBase) { $upBase = $HOME }
        $binDir = Join-Path $upBase '.local\bin'
        $hasClaude = (Test-Path (Join-Path $binDir 'claude.exe')) -or (Test-Path (Join-Path $binDir 'claude.cmd'))
        if (-not $hasClaude) { return $false }
        $key = [Microsoft.Win32.Registry]::CurrentUser.OpenSubKey('Environment', $true)
        if (-not $key) { return $false }
        try {
            $raw = [string]$key.GetValue('Path', '', [Microsoft.Win32.RegistryValueOptions]::DoNotExpandEnvironmentNames)
            $kind = [Microsoft.Win32.RegistryValueKind]::ExpandString
            try { if ($raw) { $kind = $key.GetValueKind('Path') } } catch { }
            $entries = @($raw -split ';' | Where-Object { $_ })
            foreach ($e in $entries) {
                $exp = [Environment]::ExpandEnvironmentVariables($e).TrimEnd('\')
                if ($exp -ieq $binDir.TrimEnd('\')) { return $true }
            }
            $newVal = (@($entries) + $binDir) -join ';'
            $key.SetValue('Path', $newVal, $kind)
            Write-DetailToLog ("user-path: registered {0}" -f $binDir)
        } finally { $key.Close() }
        # 変更をほかの画面へ知らせる (設定変更の通知を出すための一時変数を立てて消す)
        try {
            [Environment]::SetEnvironmentVariable('SOLOPTILINK_PATH_NOTIFY', '1', 'User')
            [Environment]::SetEnvironmentVariable('SOLOPTILINK_PATH_NOTIFY', $null, 'User')
        } catch { }
        return $true
    } catch {
        Write-DetailToLog ("user-path: failed {0}" -f $_.Exception.Message)
        return $false
    }
}

function Update-SessionPath {
    $machine  = [Environment]::GetEnvironmentVariable('Path', 'Machine')
    $user     = [Environment]::GetEnvironmentVariable('Path', 'User')
    # 既知バグ #21365 への対処 (上記コメント参照): 公式配置先を固定で合成する。要実機確認。
    $upBase = $env:USERPROFILE
    if (-not $upBase) { $upBase = $HOME }
    $localbin = Join-Path $upBase '.local\bin'
    $parts = @()
    foreach ($p in @($machine, $user, $localbin)) { if ($p) { $parts += ([string]$p).TrimEnd(';') } }

    # 配置先変更耐性 (任意・低優先): 他の既知候補に claude 実体があれば、その親ディレクトリも
    #   セッション PATH へ合成する。where / Get-ChildItem の再帰探索はレジストリ PATH 未更新下では
    #   空振りしうるため、ここでは "候補ディレクトリ内に claude.exe / claude.cmd が実在するか" を
    #   Test-Path でピンポイント確認し、見つかった親ディレクトリだけを足すに留める (探索しない)。
    #   ↓の候補は ~/.local\bin 以外まだ未確認。実機で実際の配置先が判明したら整理・追加すること。
    $binCandidates = @(
        $localbin,
        (Join-Path $env:LOCALAPPDATA 'Programs\claude')
    )
    foreach ($dir in $binCandidates) {
        if (-not $dir) { continue }
        $hit = (Test-Path (Join-Path $dir 'claude.exe')) -or (Test-Path (Join-Path $dir 'claude.cmd'))
        $norm = ([string]$dir).TrimEnd(';')
        if ($hit -and ($parts -notcontains $norm)) { $parts += $norm }
    }

    $env:Path = ($parts -join ';')
}
# 技術的な内容 (英文の例外メッセージ・終了コード) を控えのログにだけ残す
# ★2026-08-10 新設: これらを画面に出しても、お使いになる方には意味が伝わらず、
#   次に何をすればよいかも分からない。原因調査に要る情報は setup_log.txt へ回し、
#   画面には日本語の案内だけを出す。ログが取れない環境でも黙って続行する。
# ★2026-09-03 是正 (実機ログで確認): 控えの書き先が setup_log.txt のままだった。
#   このファイルは画面記録の機能が実行中ずっと握っているため、同じファイルへ
#   書き足そうとすると毎回失敗し、しかもその失敗を握りつぶしていた。結果として
#   「どこで何が起きたか」がどこにも残らず、原因の分からない未完了が出続けていた。
#   控えは別ファイル (setup_detail.txt) に書く。
function Write-DetailToLog($detail) {
    try {
        if ($script:DetailPath -and $detail) {
            Add-Content -Path $script:DetailPath -Value ([string]$detail) -Encoding UTF8
        }
    } catch { }
}

# ★修正F (2026-09-03): オブジェクトに指定の項目があるかを安全に調べる。
#   Set-StrictMode -Version Latest の下では、要素が 0 件のコレクションから
#   名前をまとめて取り出すと「このオブジェクトにプロパティ 'Name' が
#   見つかりません」で停止する。設定ファイルがまだ無い端末では中身が必ず
#   0 件になるため、PSObject の項目名を一括で取り出して -contains で調べる
#   書き方は、その端末では必ず失敗する。
#   実測 (2026-09-03 Windows 実機): claude_desktop_config.json が無い状態で
#   STEP 9 が mcp-register-failure message=... プロパティ 'Name' が
#   見つかりません で停止し、「一部が未完了」の要対応1件目になっていた。
#   foreach は 0 件でも安全に回るため、必ずこの関数を通すこと。
function Test-HasProperty($obj, $name) {
    if ($null -eq $obj) { return $false }
    foreach ($p in $obj.PSObject.Properties) {
        if ($p.Name -eq $name) { return $true }
    }
    return $false
}

# 外部プロセスを看視付きで実行する。timeoutSec を超えたら強制終了し $null を返す
# (前提ソフトの導入が応答しなくなったとき、セットアップ全体が止まらないようにするための処理)。
# >>> sl-safe-settings-write-ps v1 (2026-10-28) >>>
# お客様の設定の全文の控えは作らない (Python の sl-safe-settings-write v1 と同じ考え方の PowerShell 版)。
# 控えには環境変数や許可の設定、接続の鍵がそのまま写り、消す処理がどこにも無いまま残り続けていた。
# 読めた設定だけを一時ファイルに書き、JSON として読み直してから置き換える。
# 読んでから置き換えるまでに別の処理が設定を書いていたら、上書きせずに $false を返す。
# $Json は書く中身そのまま (改行も含めて呼ぶ側が決める)。$Before は読む前に取った
# Get-Item の結果 (設定が無かったときは $null)。置き換えは同じフォルダの中で行うため、
# Windows では置き換え先の権限 (ACL) がそのまま残る。
function Write-SlSettingsSafely {
    param([string]$Path, [string]$Json, $Before)
    $folder = Split-Path -Parent $Path
    if (-not $folder) { $folder = '.' }
    $tmp = Join-Path $folder ('.' + (Split-Path -Leaf $Path) + '.sl-new.' + $PID)
    $stream = $null
    try {
        $stream = [System.IO.File]::Open($tmp, [System.IO.FileMode]::CreateNew, [System.IO.FileAccess]::Write, [System.IO.FileShare]::None)
    } catch {
        return $false
    }
    try {
        if ($null -ne $Before -and [System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Unix) {
            try { [System.IO.File]::SetUnixFileMode($tmp, [System.IO.File]::GetUnixFileMode($Path)) } catch { }
        }
        $bytes = (New-Object System.Text.UTF8Encoding($false)).GetBytes($Json)
        $stream.Write($bytes, 0, $bytes.Length)
        $stream.Flush($true)
        $stream.Dispose()
        $stream = $null
        $back = [System.IO.File]::ReadAllText($tmp, (New-Object System.Text.UTF8Encoding($false))) | ConvertFrom-Json
        if ($null -eq $back -or -not ($back -is [System.Management.Automation.PSCustomObject])) { return $false }
        if ($null -ne $Before) {
            $now = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
            if ($now.Length -ne $Before.Length -or $now.LastWriteTimeUtc.Ticks -ne $Before.LastWriteTimeUtc.Ticks) { return $false }
            [System.IO.File]::Replace($tmp, $Path, [NullString]::Value)
        } else {
            if (Test-Path -LiteralPath $Path) { return $false }
            [System.IO.File]::Move($tmp, $Path)
        }
        return $true
    } catch {
        return $false
    } finally {
        if ($null -ne $stream) { try { $stream.Dispose() } catch { } }
        if (Test-Path -LiteralPath $tmp) { Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue }
    }
}
# <<< sl-safe-settings-write-ps v1 <<<

# >>> sl-desktop-mcp-entry-ps v1 (2026-10-28) >>>
# Claude Desktop の設定 (claude_desktop_config.json) へ当社の連携 (mcpServers.soloptilink) を足す。
# 全文の控えは作らない (控えには他社の接続先の鍵などがそのまま写り、消されずに残り続けていた)。
# 読めない・想定外の形の設定は 1 バイトも書き換えない (以前は空とみなして当社の登録だけで上書きし、
# ほかの連携の登録を消していた)。置き換えは Write-SlSettingsSafely で読み直して確かめてから行う。
# 戻り値: 'ok' = 登録した / 'unreadable' = 読めない・想定外の形のため書き換えていない / 'failed' = 置き換えられなかった
function Set-SlDesktopMcpEntry {
    param([string]$Path, $Entry)
    $before = $null
    $cfg = $null
    if (Test-Path -LiteralPath $Path) {
        try {
            $before = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
            $raw = [System.IO.File]::ReadAllText($Path, (New-Object System.Text.UTF8Encoding($false)))
            if (-not [string]::IsNullOrWhiteSpace($raw)) { $cfg = $raw | ConvertFrom-Json -ErrorAction Stop }
        } catch {
            return 'unreadable'
        }
        if ($null -ne $cfg -and -not ($cfg -is [System.Management.Automation.PSCustomObject])) { return 'unreadable' }
    }
    if ($null -eq $cfg) { $cfg = [PSCustomObject]@{} }
    $hasServers = $false
    foreach ($p in $cfg.PSObject.Properties) { if ($p.Name -eq 'mcpServers') { $hasServers = $true } }
    if (-not $hasServers) {
        $cfg | Add-Member -MemberType NoteProperty -Name 'mcpServers' -Value ([PSCustomObject]@{})
    } elseif ($null -eq $cfg.mcpServers) {
        $cfg.mcpServers = [PSCustomObject]@{}
    } elseif (-not ($cfg.mcpServers -is [System.Management.Automation.PSCustomObject])) {
        return 'unreadable'
    }
    $hasMine = $false
    foreach ($p in $cfg.mcpServers.PSObject.Properties) { if ($p.Name -eq 'soloptilink') { $hasMine = $true } }
    if ($hasMine) { $cfg.mcpServers.soloptilink = $Entry }
    else { $cfg.mcpServers | Add-Member -MemberType NoteProperty -Name 'soloptilink' -Value $Entry }
    $json = (ConvertTo-Json -InputObject $cfg -Depth 20) + "`n"
    if (Write-SlSettingsSafely -Path $Path -Json $json -Before $before) { return 'ok' }
    return 'failed'
}
# <<< sl-desktop-mcp-entry-ps v1 <<<

function Invoke-WithTimeout($file, $argList, $timeoutSec, $label) {
    # 2026-07-13 敵対検証で確証: Start-Process -NoNewWindow の子プロセス出力はコンソール
    # 直書きとなり Start-Transcript (setup_log.txt) に一切残らない。最も失敗しやすい
    # 前提ソフト導入工程 (winget/公式インストーラ) のエラー詳細がサポートに届かなくなる
    # ため、ファイルへリダイレクトし完了後に転写する (転写は Write-Host 経由なので
    # Transcript に確実に載る)。
    # GetTempFileName は TEMP 不在/tmp枯渇(65535個)で IOException を投げ、EAP=Continue でも
    # 最上位 trap に到達してインストーラ全体を落とすため try 内で確保し、失敗時は
    # リダイレクトなし(転写なし)で続行するフォールバックにする。
    # ★2026-09-29: Windows PowerShell 5.1 の Start-Process は配列の引数を空白で連結するだけで
    #   引用符を付けない。展開先に空白があると (再ダウンロードで付く「 (1)」等)、自己診断の
    #   パスが途中で切れて毎回「一部が未完了」で終わっていた (pwsh で exit 127 を再現)。
    #   空白か引用符を含む要素だけを "…" で包んでから渡す。既に包まれている要素は触らない。
    if ($argList -is [array]) {
        $argList = @($argList | ForEach-Object {
            $s = [string]$_
            if ($s -match '[\s"]' -and -not ($s.StartsWith('"') -and $s.EndsWith('"'))) {
                '"' + ($s -replace '"', '\"') + '"'
            } else { $s }
        }) -join ' '
    }
    $outFile = $null; $errFile = $null
    try {
        $outFile = [System.IO.Path]::GetTempFileName()
        $errFile = [System.IO.Path]::GetTempFileName()
    } catch {
        if ($outFile) { Remove-Item $outFile -ErrorAction SilentlyContinue }
        $outFile = $null; $errFile = $null
        Write-Warn "  (一時ファイルを確保できないため $label の出力転写を省略します)"
    }
    try {
        if ($outFile) {
            $proc = Start-Process -FilePath $file -ArgumentList $argList -NoNewWindow -PassThru `
                -RedirectStandardOutput $outFile -RedirectStandardError $errFile
        } else {
            $proc = Start-Process -FilePath $file -ArgumentList $argList -NoNewWindow -PassThru
        }
    } catch {
        Write-DetailToLog ("launch-failure label={0} message={1}" -f $label, $_.Exception.Message)
        Write-Err "  $label を開始できませんでした (この工程は飛ばして続けます)"
        if ($outFile) { Remove-Item $outFile, $errFile -ErrorAction SilentlyContinue }
        return $null
    }
    # PS 5.1 既知問題: Handle に触れておかないと WaitForExit 後の ExitCode が $null になる
    # (プロセスハンドル未キャッシュ)。終了コードによる成否二分判定の生命線なので必須。
    $null = $proc.Handle
    $timedOut = $false
    if (-not $proc.WaitForExit($timeoutSec * 1000)) {
        $timedOut = $true
        Write-Warn "  $label が $timeoutSec 秒以内に完了しなかったため中断して次へ進みます。"
        # PS 5.1 の $proc.Kill() は子プロセスツリーを殺せない (winget の実インストーラが残る)
        # ため taskkill /T /F でツリーごと終了する。失敗時のみ Kill() にフォールバック。
        try { & taskkill /PID $proc.Id /T /F 2>$null | Out-Null } catch { try { $proc.Kill() } catch { } }
        try { $proc.WaitForExit(10000) | Out-Null } catch { }
        Add-Issue $label "導入処理が $timeoutSec 秒でタイムアウトしました (ネットワーク遅延またはハング)" '通信環境の良い状態で本インストーラを再実行するか、公式サイトから手動導入してください。導入済みの SoloptiLinkAI 本体はそのまま利用できます。'
    }
    # 子プロセス出力の転写 (タイムアウト時も途中までの出力を残す)。長大な場合は末尾のみ。
    # winget はリダイレクト時 BOM なし UTF-8 固定出力のため -Encoding UTF8 で読む
    # (PS 5.1 の既定は ANSI=CP932 で日本語エラーメッセージが化ける)。コンソールを
    # UTF-8 へ統一済みのため他の子プロセス (powershell 等) も UTF-8 で出力する。
    foreach ($f in @($outFile, $errFile)) {
        if (-not $f) { continue }
        try {
            if ((Test-Path $f) -and ((Get-Item $f).Length -gt 0)) {
                $lines = @(Get-Content $f -Encoding UTF8 -ErrorAction SilentlyContinue)
                if ($lines.Count -gt 120) {
                    $lines = @("... ($($lines.Count - 120) 行省略) ...") + $lines[-120..-1]
                }
                $lines | ForEach-Object { Write-Host "    | $_" -ForegroundColor DarkGray }
            }
        } catch { }
        Remove-Item $f -ErrorAction SilentlyContinue
    }
    if ($timedOut) { return $null }
    return $proc.ExitCode
}

# winget で1パッケージを導入 → PATH 再構築 → コマンド再検出で成否判定 (失敗は記録して継続)
#   ★winget の終了コードを捕捉し「導入失敗(ネット/権限/ソース)」と「要再起動(PATH未反映)」を二分する。
#     これをしないと、社内プロキシ遮断・ストアソース無効・管理者権限不足での失敗時に
#     『PC再起動で直る』という再起動では直らない誤った対処を要対応一覧に出してしまう
#     (日本の管理された Windows 端末で発火確度が高い)。
function Install-ViaWinget($packageId, $displayName, $verifyCommand, $officialUrl) {
    if (-not $script:HasWinget) {
        Write-Err "$displayName を自動導入できません (winget 非搭載)"
        Add-Issue $displayName 'winget (アプリ インストーラー) がこの PC に無いため自動導入できませんでした' "Microsoft Store から「アプリ インストーラー」を導入して再実行するか、公式サイト ($officialUrl) から手動で導入してください。企業管理 PC でストアが使えない場合は社内 IT 部門へ導入をご依頼ください。"
        return $false
    }
    Write-Host "  $displayName を導入中... (winget: $packageId)"
    $prev = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    # ハング対策 (2026-07-13): winget が応答しなくなっても最大10分で打ち切り、
    # セットアップ全体を巻き込まない (要対応一覧に集約して続行)。
    $code = Invoke-WithTimeout 'winget' @('install','--id',$packageId,'-e','--source','winget','--accept-source-agreements','--accept-package-agreements','--silent') 600 $displayName
    if ($null -eq $code) { $code = -1 }
    $ErrorActionPreference = $prev
    Update-SessionPath
    if (Test-CommandExists $verifyCommand) {
        Write-Ok "  $displayName 導入完了"
        return $true
    }
    # winget は走ったがコマンド未検出 → 終了コードで「成功(要再起動)」と「導入失敗」を二分する。
    #   0 / 既導入 (-1978335189 = 0x8A15002B) = 導入は成功扱い → PATH 反映待ち (再起動で直る)
    #   それ以外 = 導入そのものが失敗 (ネット遮断 / ソース無効 / 権限不足) → 再起動では直らない
    if ($code -eq 0 -or $code -eq -1978335189) {
        Write-Warn "  $displayName を導入しましたが、このセッションでは確認できませんでした (PC 再起動後に反映)"
        Add-Issue $displayName '導入は成功しましたが PATH の反映に再起動が必要な可能性があります' 'PC を再起動後、新しいウィンドウで動作確認してください'
    } else {
        Write-DetailToLog ("winget-exit displayName={0} code={1}" -f $displayName, $code)
        Write-Err "  $displayName の自動導入に失敗しました"
        Add-Issue $displayName "自動導入に失敗しました。社内のネットワーク制限による配信先の遮断、社内ポリシーによる導入元の無効化、または権限の不足が考えられます" "ネットワーク管理者に winget 配信先 (cdn.winget.microsoft.com 等) の許可を依頼するか、公式サイト ($officialUrl) のインストーラを IT 部門経由で導入してください。管理者権限が必要な場合があります。"
    }
    return $false
}

# Hinoue-incident: always pause at the end so cmd window does not vanish
function End-Pause {
    # ★2026-09-03 是正: 回収ツール (fix.ps1) から呼ばれたときは、ここで止めない。
    #   実測: このキー待ちを通過しないと、記録ファイルと診断レポートを
    #   デスクトップへ回収する処理まで到達しない。実際に「デスクトップに
    #   記録が無い」事象が発生した (キー待ちの時点で窓を閉じたため未回収)。
    #   回収ツール側が最後に必ず停止するので、ここで止めなくても窓は消えない。
    if ($env:SOLOPTILINK_NO_END_PAUSE -eq '1') { return }
    Write-Host ""
    Write-Host "==============================================================="
    Write-Host " 何かキーを押すとウィンドウを閉じます。"
    Write-Host "==============================================================="
    if ($Host.Name -eq "ConsoleHost") {
        [void][System.Console]::ReadKey($true)
    }
}

trap {
    # ★2026-08-10 是正: 従来は英文の例外メッセージをそのまま画面へ出していた。
    #   お客様には意味が伝わらず、次に何をすればよいかも分からない行き止まりだった。
    #   技術的な内容は控えのログへ回し、画面には日本語の案内だけを出す。
    $detail = "installer-failure step={0} line={1} message={2}" -f `
        $script:CurrentStep, $_.InvocationInfo.ScriptLineNumber, $_.Exception.Message
    try { Write-DetailToLog $detail } catch { }
    Write-Err "予期しない問題が発生しました"
    Write-Host ""
    Write-Host "  セットアップを最後まで進められませんでした。"
    Write-Host ""
    Write-Host ("  止まったところ: {0}" -f $script:CurrentStep)
    Write-Host ""
    Write-Host "  次にしていただくこと:"
    Write-Host ("    {0}" -f $script:CurrentStepNext)
    Write-Host ""
    Write-Host "  それでも同じところで止まる場合は、この画面の写真を撮って、"
    Write-Host "  nomura.y@soloptilink.com までお送りください。"
    Write-Host "  こちらで原因をお調べして、ご連絡いたします。"
    try { Stop-Transcript | Out-Null } catch { }
    End-Pause
    exit 1
}

# -----------------------------------------------------------------------------
# 画面の文字コードを UTF-8 に統一する (★画面に何かを書く前に必ず実行する)
# -----------------------------------------------------------------------------
# 2026-07-13 敵対検証で確証: Goランチャーは日本語をUTF-8で出力するが、日本語Windowsの
# コンソール既定はCP932のため、PS 5.1がネイティブ出力をキャプチャすると文字化けし、
# 「承認済み」「登録しました」等の成否判定matchが恒常的に不成立になる(承認済み端末への
# 再認証強要・フック登録の偽警告)。コンソールをUTF-8へ統一して出力側の化けを根治する。
#
# 2026-09-02 是正 (日本語Windowsで全角文字が二重に見える事象への対処):
#   ・切替の位置を、バナー表示とログ開始の「後」から「前」へ移した。
#     文字を出した後で出力コードページを 932 から 65001 に変えると、全角文字が
#     占める2セル分の管理状態が画面側でずれ、全角だけが二重に見えることがある
#     (半角は1セルなので影響を受けない)。従来はこの条件に該当していた。
#   ・BOM を付けない UTF8Encoding を使う。[Text.Encoding]::UTF8 は先頭に不可視の
#     3バイトを付ける実装で、画面やパイプの先頭に混入する。本スクリプトの
#     ファイル出力側は既に BOM なし版を使っており、そちらに揃えた。
#   ※この2点は Windows 実機での再現確認が取れていない。実機のログ (setup_log.txt)
#     で文字が二重になっていれば書き出し側、なっていなければ画面側と切り分けられる。
#
# 2026-09-03 v2056.5 の是正を取り込み (製品側で特定された真因への対処):
#   全角が二重に見えた直接の原因は「画面本体の文字コードは 932 のまま、.NET 側の
#   出力設定だけを UTF-8 に切り替えていた」不一致にあった。画面本体が 932 のままだと
#   全角1文字が占める幅の数え方が食い違い、「導導入入済済みみでですす」のように
#   全角だけが重なって見える。chcp で画面本体そのものを UTF-8 (65001) に変えて解消する。
#   入力側 (InputEncoding) も同時にそろえる。
#   ※上の「切替の位置を前に移す」是正と両立する。位置を前にしたうえで、画面本体の
#     文字コードも切り替える。どちらか一方では足りない。
try { $null = & chcp.com 65001 2>$null } catch { }
try {
    $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
    [Console]::OutputEncoding = $utf8NoBom
    $OutputEncoding = $utf8NoBom
    try { [Console]::InputEncoding = $utf8NoBom } catch { }
} catch {
    Write-Host "  (コンソールのUTF-8切替に失敗しました。処理は続行します。)" -ForegroundColor DarkGray
}

# 子プロセスの Python にも UTF-8 を渡す (導入の自己診断が途中で落ちる事象の是正)。
# 自己診断は判定をパイプで受け渡すため、Windows の Python は画面の文字コード設定では
# なく端末の既定 (日本語Windowsは cp932) で書き出そうとする。判定記号の一つ「—」が
# cp932 に無いため書き出しに失敗し、診断が最後まで走らずに終わっていた。
#
# 2026-09-03 v2056.5 の是正を取り込み: 'utf-8' ではなく 'utf-8:replace' を渡す。
#   厳格な 'utf-8' だと、表せない文字が一つでも来た時点でそこで止まってしまう。
#   :replace を付けると、表せない文字を代替文字に置き換えて処理を続ける。
#   診断が途中で止まらないことを優先する。
$env:PYTHONUTF8 = '1'
$env:PYTHONIOENCODING = 'utf-8:replace'

# -----------------------------------------------------------------------------
# Banner
# -----------------------------------------------------------------------------
Write-Host ""
Write-Host "================================================================="
Write-Host " SoloptiLinkAI  Windows セットアップ"
Write-Host "================================================================="
Write-Host ""

# 実行ログを setup_log.txt に保存 (うまくいかない時の原因切り分け用)
try {
    if (-not (Test-Path $InstallDir)) { New-Item -ItemType Directory -Path $InstallDir -Force | Out-Null }
    $script:LogPath = Join-Path $InstallDir 'setup_log.txt'
    Start-Transcript -Path $script:LogPath -Append | Out-Null
} catch {
    $script:LogPath = ""
    Write-Host "  (ログの保存に失敗しました。環境ポリシーの可能性があります。処理は続行します。)" -ForegroundColor DarkGray
}

# 技術的な控え (英文の例外・終了コード) の置き場所。setup_log.txt とは分ける。
# 上の記録機能がそのファイルを実行中ずっと握っており、同じファイルへ書き足すことは
# できないため (2026-09-03 実機ログで確認)。毎回この実行の分だけを残す。
try {
    if (Test-Path $InstallDir) {
        $script:DetailPath = Join-Path $InstallDir 'setup_detail.txt'
        Set-Content -Path $script:DetailPath -Encoding UTF8 `
            -Value ("=== 実行開始 {0} ===" -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'))
    }
} catch { $script:DetailPath = "" }

# -----------------------------------------------------------------------------
# STEP 1: PowerShell / Windows 環境チェック
# -----------------------------------------------------------------------------
Write-Step "1/11 環境チェック"

$psVer = $PSVersionTable.PSVersion
Write-Host "  PowerShell: $psVer"
if ($psVer.Major -lt 5) {
    Write-Err "PowerShell 5.0+ が必要です。Windows Update を適用してください。"
    End-Pause; exit 1
}

$winVer = [System.Environment]::OSVersion.Version
Write-Host "  Windows:    $winVer"

# Long path support check
try {
    $longPath = Get-ItemPropertyValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem" -Name "LongPathsEnabled" -ErrorAction SilentlyContinue
    if ($longPath -eq 1) {
        Write-Ok "  ロングパス対応: 有効"
    } else {
        # ★2026-08-15 是正: ここには打ち込むコマンドとレジストリの場所がそのまま出ていた。
        #   お使いになる方には意味が伝わらず、打ち間違えると PC の設定を壊しかねない。
        #   何が起きるかと、誰に頼めばよいかだけを日本語で伝える。
        Write-Warn "  長いファイル名に対応する設定が有効になっていません"
        Write-Host "     (置き場所が深いフォルダで不具合が出ることがあります。導入はこのまま続けられます)"
        Write-Host "     設定の変更にはパソコンの管理者権限が必要です。社内の情報システム担当の方"
        Write-Host "     または nomura.y@soloptilink.com までご相談ください。"
    }
} catch {
    Write-Warn "  長いファイル名に対応する設定は確認できませんでした (確認できなかっただけで、問題があると判断したわけではありません)"
}

# -----------------------------------------------------------------------------
# STEP 1.1: 準備状況の一括確認 (2026-08-15 新設)
#
# 【なぜここに在るか】前提ソフトの導入工程は STEP 11 (最後) にある。これは
#   「winget が固まっても本体だけは必ず入れ切る」ための正しい順序であり、動かさない。
#   ところが【判定】まで最後にあったため、足りないものがあってもお客様が知るのは
#   すべて終わってからだった。過去の導入失敗では、途中まで進んでから失敗し、
#   お客様は何をすればよいか分からないまま自力で回避策を探すことになった。
#   そこで「判定と提示」だけをここへ切り出す (導入する工程は STEP 11 のまま)。
#
# 【この工程がすること / しないこと】
#   する  : 見るだけ。空き容量・接続・基本ソフトの版・前提ソフトの実行可否を測って一覧にする。
#   しない: 導入・設定変更・ダウンロード。一切行わない (だから安全に先頭へ置ける)。
#
# 全部そろっていれば一覧を出さずに素通りする。足りなければ 1 画面で示し、
# 続けるか中断するかをお尋ねする。確認できなかった項目は「問題なし」に丸めない。
#
# 無効化: SOLOPTILINK_PREFLIGHT=off (無効化した事実を控えのログに残して通過する)
# 調整  : SOLOPTILINK_MIN_FREE_MB (既定 2048) / SOLOPTILINK_PREFLIGHT_NET_TIMEOUT (既定 6 秒)
# -----------------------------------------------------------------------------
$script:PfRows    = @()
$script:PfNeed    = 0
$script:PfAuto    = 0
$script:PfUnknown = 0
function Add-PfRow($item, $verdict, $message, $carry) {
    $script:PfRows += [PSCustomObject]@{ Item = $item; Verdict = $verdict; Message = $message; Carry = $carry }
    if ($verdict -eq 'need')    { $script:PfNeed++ }
    if ($verdict -eq 'auto')    { $script:PfAuto++ }
    if ($verdict -eq 'unknown') { $script:PfUnknown++ }
}
# 空き容量 (MB)。取れなければ $null (呼び出し側で「確認できなかった」にする)
function Get-PfFreeMb($path) {
    try {
        $root = [System.IO.Path]::GetPathRoot($path)
        if (-not $root) { return $null }
        $drive = New-Object System.IO.DriveInfo($root)
        if (-not $drive.IsReady) { return $null }
        return [int64]($drive.AvailableFreeSpace / 1MB)
    } catch { return $null }
}
# 接続確認。0=つながる / 1=つながらない / 2=確かめる手段が無い
#   応答の中身は見ない。何らかの応答が返ること自体が「そこへ届いた」証拠になる。
function Test-PfNet($url, $timeoutSec) {
    try {
        $req = [System.Net.HttpWebRequest]::Create($url)
        $req.Method  = 'HEAD'
        $req.Timeout = $timeoutSec * 1000
        $resp = $req.GetResponse()
        $resp.Close()
        return 0
    } catch [System.Net.WebException] {
        if ($_.Exception.Response) { return 0 }
        return 1
    } catch { return 2 }
}

Write-Step "1.1/11 準備状況の一括確認 (見るだけ。ここでは何も導入しません)" `
    '画面に出ている「ご確認」の項目を解消してから、このファイルをもう一度実行してください。'
if ("$($env:SOLOPTILINK_PREFLIGHT)".ToLower() -eq 'off') {
    Write-Host "  準備状況の確認は無効化されています (確認していません。問題が無いという意味ではありません)" -ForegroundColor DarkGray
    Write-DetailToLog ("preflight-skipped SOLOPTILINK_PREFLIGHT=off at {0}" -f (Get-Date -Format 's'))
} else {
    $pfEAP = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor [Net.SecurityProtocolType]::Tls12 } catch { }

    # ① パソコンの基本ソフト
    #   下限の根拠: 顧客向け利用ガイドの動作環境表 (Windows 10 の 2018 年春の更新 = ビルド 17134 以降、
    #   または Windows 11)。ここを独自に決めると案内と食い違うため、その表に合わせる。
    $pfMinBuild = 17134
    if ($winVer -and $winVer.Build -gt 0) {
        if ($winVer.Build -ge $pfMinBuild) {
            Add-PfRow 'パソコンの基本ソフト' 'ok' ("Windows {0} — 対応しています" -f $winVer) $false
        } else {
            Add-PfRow 'パソコンの基本ソフト' 'need' 'この Windows は当社が動作を確認している範囲より古いものです。Windows Update を適用して最新の状態にしていただくか、nomura.y@soloptilink.com までご相談ください' $true
        }
    } else {
        Add-PfRow 'パソコンの基本ソフト' 'unknown' '基本ソフトの版を確認できませんでした (確認できなかっただけで、問題があると判断したわけではありません)' $true
    }

    # ② 空き容量
    #   下限の根拠: 本体の展開分に加え、Node.js のランタイムと、これから作る業務システムの
    #   部品置き場 (1 件あたり数百 MB) を見込んだ最低限。
    $pfMinFree = 2048
    if ($env:SOLOPTILINK_MIN_FREE_MB) { try { $pfMinFree = [int]$env:SOLOPTILINK_MIN_FREE_MB } catch { $pfMinFree = 2048 } }
    $pfFree = Get-PfFreeMb $InstallDir
    if ($null -eq $pfFree) {
        Add-PfRow 'ディスクの空き容量' 'unknown' '空き容量を確認できませんでした (確認できなかっただけで、足りないと判断したわけではありません)' $true
    } elseif ($pfFree -lt $pfMinFree) {
        Add-PfRow 'ディスクの空き容量' 'need' ("空きが {0} MB しかありません。導入と、これから作る業務システムのために {1} MB 以上の空きをご用意ください (使っていないファイルをごみ箱へ移し、ごみ箱を空にすると増えます)" -f $pfFree, $pfMinFree) $true
    } else {
        Add-PfRow 'ディスクの空き容量' 'ok' ("{0} MB の空きがあります" -f $pfFree) $false
    }

    # ③ インターネット接続 (本体の受け取り先と、前提ソフトの配布元)
    $pfNetTimeout = 6
    if ($env:SOLOPTILINK_PREFLIGHT_NET_TIMEOUT) { try { $pfNetTimeout = [int]$env:SOLOPTILINK_PREFLIGHT_NET_TIMEOUT } catch { $pfNetTimeout = 6 } }
    $pfNetAdmin  = Test-PfNet 'https://admin-dashboard-blue-alpha-78.vercel.app/' $pfNetTimeout
    $pfNetClaude = Test-PfNet 'https://claude.ai/' $pfNetTimeout
    if ($pfNetAdmin -eq 2 -or $pfNetClaude -eq 2) {
        Add-PfRow 'インターネット接続' 'unknown' '接続を確認できませんでした (確認できなかっただけで、つながっていないと判断したわけではありません)' $true
    } elseif ($pfNetAdmin -eq 0 -and $pfNetClaude -eq 0) {
        Add-PfRow 'インターネット接続' 'ok' '必要な接続先につながります' $false
    } else {
        Add-PfRow 'インターネット接続' 'need' '必要な接続先につながりませんでした。ネットワークの接続をご確認ください。社内のネットワーク制限 (プロキシ / ファイアウォール) が原因のこともありますので、その場合はネットワーク管理者に接続の許可をご依頼ください' $true
    }

    # ④⑤⑥⑦ 前提ソフト (この工程では導入しない。STEP 11 で導入する)
    $pfWinget = Test-CommandExists 'winget'
    $pfAutoNote = 'このあと自動で用意します (お客様の操作は不要です)'
    if (-not $pfWinget) { $pfAutoNote = 'このあと自動で用意します。うまくいかない場合は最後の【要対応】でご案内します' }

    if ((Get-PrereqVerdict 'git' '--version' 'git version [0-9]') -eq 'available') {
        Add-PfRow 'Git' 'ok' ("使えます ({0})" -f $script:PrereqVersion) $false
    } else {
        Add-PfRow 'Git' 'auto' $pfAutoNote $false
    }
    $pfNodeV = Get-PrereqVerdict 'node' '-v' '^v[0-9]'
    if ($pfNodeV -eq 'available' -and $script:PrereqVersion -match '^v(\d+)\.' -and [int]$matches[1] -ge 18) {
        Add-PfRow 'Node.js' 'ok' ("使えます ({0})" -f $script:PrereqVersion) $false
    } else {
        Add-PfRow 'Node.js' 'auto' $pfAutoNote $false
    }
    if ((Get-PrereqVerdict 'claude' '--version' '[0-9]') -eq 'available') {
        Add-PfRow 'Claude Code' 'ok' ("使えます ({0})" -f $script:PrereqVersion) $false
    } else {
        Add-PfRow 'Claude Code' 'auto' $pfAutoNote $false
    }
    # ★2026-09-02 変更 (T-702e): Python 3 も Git / Node.js と同じく自動導入の対象にしたため
    #   「お客様の操作が要る」ではなく「これから入れます」に変わった。
    if (Resolve-Python) {
        Add-PfRow 'Python 3' 'ok' ("使えます ({0})" -f $script:PyVersion) $false
    } else {
        Add-PfRow 'Python 3' 'auto' $pfAutoNote $false
    }

    # --- 提示 (全部そろっていれば一覧を出さずに素通りする) ---
    if ($script:PfNeed -eq 0 -and $script:PfAuto -eq 0 -and $script:PfUnknown -eq 0) {
        Write-Ok ("  準備はととのっています ({0} 項目すべて確認しました)。このまま導入を進めます" -f $script:PfRows.Count)
    } else {
        Write-Host ""
        Write-Host "  ---------------------------------------------------------------"
        Write-Host "   導入をはじめる前に、次の点をご確認ください"
        Write-Host "  ---------------------------------------------------------------"
        foreach ($r in $script:PfRows) {
            switch ($r.Verdict) {
                'ok'      { Write-Host ("    [ 済 ] {0}" -f $r.Item) -ForegroundColor DarkGreen }
                'auto'    { Write-Host ("    [自動] {0}" -f $r.Item); Write-Host ("           {0}" -f $r.Message) }
                'need'    { Write-Host ("    [ご確認] {0}" -f $r.Item) -ForegroundColor Yellow; Write-Host ("           {0}" -f $r.Message) }
                'unknown' { Write-Host ("    [未確認] {0}" -f $r.Item) -ForegroundColor Yellow; Write-Host ("           {0}" -f $r.Message) }
            }
        }
        Write-Host "  ---------------------------------------------------------------"
        Write-Host ""
        if ($script:PfNeed -eq 0 -and $script:PfUnknown -eq 0) {
            Write-Host "   お客様の操作が必要な項目はありません。[自動] の項目はこのあと当社側で用意します。"
            Write-Host "   そのままお待ちください。"
            Write-Host ""
        } else {
            Write-Host "   このまま進めることもできます (進んだ分はそのまま残ります)。"
            Write-Host "   [ご確認] [未確認] の項目は、最後にもう一度まとめてお伝えします。"
            Write-Host ""
            $pfAns = ''
            if ($Host.Name -eq 'ConsoleHost') {
                # ★2026-10-26: Read-Host は時間切れが無く、席を外すと導入がここで止まったままになっていた
                #   (Mac 側は read -t 120 で打ち切って進む)。Mac と同じく既定 120 秒で打ち切って進める。
                $pfWait = 120
                if ($env:SOLOPTILINK_PREFLIGHT_WAIT) { [int]::TryParse($env:SOLOPTILINK_PREFLIGHT_WAIT, [ref]$pfWait) | Out-Null }
                Write-Host '   このまま進める場合はそのまま Enter、いったん中断する場合は半角の n を入力して Enter'
                Write-Host ("   (何も押さない場合は {0} 秒後にこのまま進みます)" -f $pfWait)
                try {
                    $pfDeadline = (Get-Date).AddSeconds($pfWait)
                    while ((Get-Date) -lt $pfDeadline) {
                        if ([Console]::KeyAvailable) { $pfAns = [Console]::ReadLine(); break }
                        Start-Sleep -Milliseconds 200
                    }
                } catch { $pfAns = '' }
            } else {
                Write-Host "   (この画面では入力を受け取れないため、このまま進みます)"
            }
            if ($pfAns -and (@('n','no','いいえ','中断') -contains "$pfAns".Trim().ToLower())) {
                Write-Host ""
                Write-Host "  いったん中断しました。"
                Write-Host "  上の [ご確認] の項目を解消してから、このファイルをもう一度実行してください。"
                Write-Host "  SoloptiLinkAI 本体はまだ入れていませんので、はじめからやり直していただけます。"
                try { Stop-Transcript | Out-Null } catch { }
                End-Pause
                exit 0
            }
            Write-Host "   このまま導入を進めます。"
            Write-Host ""
        }
        # 解消されないまま進んだ環境面の項目は、最後の【要対応】にも必ず残す
        # (お伝えしたことを、完了画面で無かったことにしない)
        foreach ($r in $script:PfRows) {
            if ($r.Carry -and ($r.Verdict -eq 'need' -or $r.Verdict -eq 'unknown')) {
                Add-Issue $r.Item '導入をはじめる前の確認で、そのままになっている点です' $r.Message
            }
        }
    }
    $ErrorActionPreference = $pfEAP
}

# -----------------------------------------------------------------------------
# STEP 1.2: スマート アプリ コントロール (SAC) の検知 + ダウンロード印 (MotW) の解除
#           導入時に実際に発生した停止パターンへの対策
# -----------------------------------------------------------------------------
# 【この処理の位置づけ — 主たる解決策ではない】
#   Windows 11 の スマート アプリ コントロール (SAC) は、ダウンロード由来の印 (MotW) が
#   付いた「未署名の .bat / .ps1」を実行される前に遮断する。SmartScreen と違い
#   「それでも実行」の選択肢が無く、Microsoft は個別アプリの許可手段を提供していない。
#   つまり SAC が発火する主経路では soloptilink-install.bat 自体が起動せず、
#   この PowerShell スクリプトまで到達しない。したがって本処理は保険であり、効くのは:
#     ・2 回目以降の実行 (顧客が文書どおり対処した後の再実行)
#     ・評価モード等で .bat の遮断をすり抜けた場合
#     ・同梱の運用ファイル (バックアップ.cmd / 診断.cmd / 元に戻す.cmd) が
#       後日ダブルクリックされた際に遮断されるのを未然に防ぐ (下の MotW 解除)
#   主たる解決は docs\SETUP_WINDOWS_*.md と docs\TROUBLESHOOT_COMMON.md の文書化、
#   および将来的な Authenticode コード署名の取得である。
#
# 【実機未確認 — 正直な記録】
#   SAC 状態の判定に使うレジストリ値
#     HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy
#       → VerifiedAndReputablePolicyState  (0=オフ / 1=オン(強制) / 2=評価モード)
#   は公開情報に基づく。2026-08-07 時点で、SAC が有効な実機での動作確認は取れていない。
#   このため判定失敗を異常扱いせず、必ず「不明」として処理を続行する
#   (誤判定でインストールを止めないことを最優先とする)。
Write-Step "1.2/11 保護機能の確認 (スマート アプリ コントロール)"

$script:SacState = "unknown"
try {
    $sacVal = Get-ItemPropertyValue -Path "HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy" `
                                    -Name "VerifiedAndReputablePolicyState" -ErrorAction Stop
    switch ([int]$sacVal) {
        0       { $script:SacState = "off";        Write-Ok   "  スマート アプリ コントロール: オフ" }
        1       { $script:SacState = "on";         Write-Warn "  スマート アプリ コントロール: オン (有効)" }
        2       { $script:SacState = "evaluation"; Write-Warn "  スマート アプリ コントロール: 評価モード" }
        default { Write-Host  "  スマート アプリ コントロール: 判定できませんでした (値=$sacVal)" }
    }
} catch {
    # 値が無い = SAC 非対応の Windows (10 等) か参照権限なし。どちらも正常系として扱う。
    Write-Skip "  スマート アプリ コントロール: 該当する設定なし (この PC は対象外と判断)"
}

# ダウンロード由来の印 (MotW) を配布物から取り除く。
# これにより 2 回目以降の .bat 起動と、同梱の運用ファイル (.cmd) のダブルクリック実行が
# SAC / SmartScreen に遮断されなくなる。印が無いファイルには何も起きない (冪等)。
$unblockRoot = Split-Path -Parent $PSScriptRoot
if ([string]::IsNullOrEmpty($unblockRoot) -or -not (Test-Path $unblockRoot)) { $unblockRoot = $PSScriptRoot }
try {
    $unblockExts = @('*.bat', '*.cmd', '*.ps1', '*.psm1', '*.exe', '*.msi', '*.js', '*.vbs', '*.wsf', '*.lnk', '*.reg')
    $unblockHits = 0
    $unblockTargets = @(Get-ChildItem -Path $unblockRoot -Recurse -File -Include $unblockExts -ErrorAction SilentlyContinue)
    foreach ($uf in $unblockTargets) {
        # 1 ファイルの失敗で解除処理全体が止まらないよう、ファイル単位で保護する
        try {
            $zone = Get-Item -LiteralPath $uf.FullName -Stream 'Zone.Identifier' -ErrorAction SilentlyContinue
            if ($zone) {
                Unblock-File -LiteralPath $uf.FullName -ErrorAction SilentlyContinue
                $unblockHits++
            }
        } catch {
            continue
        }
    }
    if ($unblockHits -gt 0) {
        Write-Ok "  ダウンロード由来の印を解除しました: $unblockHits 件 (次回以降の起動と運用ファイルの実行を保護)"
    } else {
        Write-Skip "  ダウンロード由来の印: 対象なし"
    }
} catch {
    Write-Warn "  ダウンロード由来の印の解除をスキップしました (処理は続行します)"
}

if ($script:SacState -eq "on" -or $script:SacState -eq "evaluation") {
    Write-Host ""
    Write-Host "  ---------------------------------------------------------------" -ForegroundColor Yellow
    Write-Host "  この PC ではスマート アプリ コントロールが有効です。" -ForegroundColor Yellow
    Write-Host "  今回のセットアップはこのまま進みます。"
    Write-Host "  今後 soloptilink-install.bat をダブルクリックしても何も起きない場合は、"
    Write-Host "  この保護機能が原因です。対処手順は次の資料に記載しています:"
    Write-Host "    docs\SETUP_WINDOWS.md / docs\TROUBLESHOOT_COMMON.md"
    Write-Host "  ZIP を解凍する前に『プロパティ→全般→許可する』を行う方法が最も安全です。"
    Write-Host "  お困りの際は nomura.y@soloptilink.com までご連絡ください。"
    Write-Host "  ---------------------------------------------------------------" -ForegroundColor Yellow
    Write-Host ""
}

# -----------------------------------------------------------------------------
# STEP 2: インストール先確認
# -----------------------------------------------------------------------------
Write-Step "2/11 インストール先確認: $InstallDir"

if (-not (Test-Path $InstallDir)) {
    Write-Host "  ディレクトリを作成します。"
    New-Item -ItemType Directory -Path $InstallDir | Out-Null
}
Write-Ok "  インストール先 OK"

# -----------------------------------------------------------------------------
# STEP 3: 配布物の検出 (モードA: ZIP展開済みフォルダ / モードB: tar.gz)
# -----------------------------------------------------------------------------
Write-Step "3/11 配布物を検出" `
    '受け取った書庫 (ZIP) をデスクトップなど分かりやすい場所に展開し直してから、このファイルをもう一度実行してください。'

# モードA: このスクリプトの親フォルダ = 解凍済み配布フォルダか?
#   顧客ZIP の構造: SoloptiLinkAI_vX.Y_Windows\installer\soloptilink-install.ps1
#   → 親フォルダに chain.sh + lib\ が居れば配布フォルダと判定
$PkgRoot = Split-Path -Parent $PSScriptRoot
$IsZipMode = $false
if ((Test-Path (Join-Path $PkgRoot "chain.sh")) -and (Test-Path (Join-Path $PkgRoot "lib"))) {
    $IsZipMode = $true
    Write-Ok "  解凍済み配布フォルダを検出: $PkgRoot"
}

# モードB: tar.gz 検索 (ZIPフォルダが見つからない場合のみ)
if (-not $IsZipMode) {
    if (-not $TarballPath) {
        $candidates = @(
            "$InstallDir\soloptilink-update-*.tar.gz",
            "$env:USERPROFILE\Downloads\soloptilink-update-*.tar.gz",
            "$PSScriptRoot\soloptilink-update-*.tar.gz"
        )
        foreach ($pat in $candidates) {
            $found = Get-ChildItem $pat -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
            if ($found) {
                $TarballPath = $found.FullName
                break
            }
        }
    }
    if (-not $TarballPath -or -not (Test-Path $TarballPath)) {
        Write-Err "  配布物が見つかりません。"
        Write-Host ""
        Write-Host "  以下のいずれかをお試しください:"
        Write-Host "   1. ダウンロードした SoloptiLinkAI_v*_Windows.zip を右クリック →「すべて展開」"
        Write-Host "      で解凍し、その中の installer\soloptilink-install.bat を実行する"
        Write-Host "   2. (保守用) soloptilink-update-v*.tar.gz を ~\Downloads に置いて再実行する"
        End-Pause; exit 1
    }
    Write-Ok "  検出 (tar.gz): $TarballPath"
}

# -----------------------------------------------------------------------------
# STEP 4: 既存インストールのバックアップ
# -----------------------------------------------------------------------------
Write-Step "4/11 既存ファイルのバックアップ"

# PFP-119: 認証引継ぎ用にバックアップ先を後続ステップでも参照できるよう初期化
$backupDir = ""

# ZIPモードで既に ~\.soloptilink 内から実行されている場合は配置不要
$SamePlace = $false
if ($IsZipMode) {
    try {
        $a = (Resolve-Path $PkgRoot).Path.TrimEnd('\')
        $b = (Resolve-Path $InstallDir).Path.TrimEnd('\')
        if ($a -ieq $b) { $SamePlace = $true }
    } catch { }
}

if (-not $SkipExtract -and -not $SamePlace) {
    $stamp = Get-Date -Format "yyyyMMdd-HHmmss"
    $backupDir = "$InstallDir\.backups\pre-install-$stamp"
    New-Item -ItemType Directory -Path $backupDir -Force | Out-Null

    # PFP-119: 認証系3ファイル (activation.json / .device_identity.json / license.json) も退避対象に含める
    foreach ($item in @("lib", "chain.sh", "VERSION", "VERSION.txt", "activation.json", ".device_identity.json", "license.json")) {
        $src = Join-Path $InstallDir $item
        if (Test-Path $src) {
            Copy-Item $src $backupDir -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
    Write-Ok "  バックアップ: $backupDir"
} else {
    Write-Warn "  バックアップをスキップ"
}

# -----------------------------------------------------------------------------
# STEP 5: 配布物の配置 (モードA: コピー / モードB: tar.gz 展開)
# -----------------------------------------------------------------------------
Write-Step "5/11 配布物の配置" `
    'ディスクの空き容量をご確認のうえ、このファイルをもう一度実行してください。'

if ($SkipExtract) {
    Write-Warn "  -SkipExtract 指定により配置をスキップ"
} elseif ($IsZipMode) {
    if ($SamePlace) {
        Write-Ok "  既に $InstallDir に展開済みのため配置をスキップ"
    } else {
        # 解凍済みフォルダの中身を丸ごと InstallDir へ上書きコピー
        # robocopy exit code: 0-7 = 成功 (8+ が失敗)
        & robocopy "$PkgRoot" "$InstallDir" /E /NFL /NDL /NJH /NJS /R:2 /W:2 | Out-Null
        $rc = $LASTEXITCODE
        if ($rc -ge 8) {
            Write-DetailToLog ("copy-failure robocopy exit={0}" -f $rc)
            Write-Err "  本体ファイルのコピーに失敗しました"
            Write-Host "  ヒント: Claude Desktop / Claude Code が起動中だと本体ファイルがロックされ" -ForegroundColor Yellow
            Write-Host "         コピーに失敗することがあります。両方を終了してから再実行してください。" -ForegroundColor Yellow
            End-Pause; exit 1
        }
        Write-Ok "  配置完了: $PkgRoot → $InstallDir"
    }
} else {
    # tar (Windows 10 1803+ で標準搭載)
    if (-not (Get-Command tar -ErrorAction SilentlyContinue)) {
        Write-Err "  このパソコンでは本体ファイルを展開できません (Windows 10 1803 以降が必要です)"
        Write-Host "  お手数ですが nomura.y@soloptilink.com へご連絡ください。" -ForegroundColor Yellow
        End-Pause; exit 1
    }
    Push-Location $InstallDir
    try {
        # --strip-components=1 でトップディレクトリ (soloptilink-vX.Y.Z/) を剥がす
        & tar -xzf $TarballPath --strip-components=1
        if ($LASTEXITCODE -ne 0) {
            Write-DetailToLog ("extract-failure exit={0}" -f $LASTEXITCODE)
            Write-Err "  本体ファイルの展開に失敗しました"
            Write-Host "  ダウンロードしたファイルが途中で切れている可能性があります。" -ForegroundColor Yellow
            Write-Host "  もう一度ダウンロードし直してからお試しください。" -ForegroundColor Yellow
            End-Pause; exit 1
        }
        Write-Ok "  展開完了"
    } finally {
        Pop-Location
    }
}

# -----------------------------------------------------------------------------
# 再インストール時の認証引継ぎ (PFP-119 / 2026-06-12)
# 認証系3ファイル (activation.json / .device_identity.json / license.json) は
# 配布物に含まれないため、上書き配置後もそのまま残る設計。万一消えていた場合は
# STEP 4 のバックアップから自動で書き戻し、再インストール後の再認証を不要にする。
# -----------------------------------------------------------------------------
$authFiles = @("activation.json", ".device_identity.json", "license.json")
$authCarried = 0
foreach ($af in $authFiles) {
    $dst = Join-Path $InstallDir $af
    if (-not (Test-Path $dst) -and $backupDir -and (Test-Path (Join-Path $backupDir $af))) {
        Copy-Item (Join-Path $backupDir $af) $dst -Force -ErrorAction SilentlyContinue
    }
    if (Test-Path $dst) { $authCarried++ }
}
if ($authCarried -gt 0) {
    Write-Ok "  認証情報は引き継ぎました (再認証は不要です)"
}

# -----------------------------------------------------------------------------
# 「停止した状態での導入」(法人のお客様向け / 2026-09-25)
# ZIP に telemetry-off.flag を同梱して渡すと (または導入時に停止の環境変数を
# 指定すると)、初回の登録・起動より前に、動作状況のお知らせの停止の印を置く。
# 印と環境変数の名前はここへ書き写さず、取り決め (lib\telemetry-consent.contract) から読む。
# 再インストールは上書き配置のため、以前に置かれた印はそのまま残る (引継ぎ不要)。
# 手順は docs\ENTERPRISE_TELEMETRY_OFF.md。
# -----------------------------------------------------------------------------
$wantTelemetryOff = $false
foreach ($fc in @((Join-Path $PkgRoot 'telemetry-off.flag'), (Join-Path $PSScriptRoot 'telemetry-off.flag'))) {
    if (Test-Path -LiteralPath $fc) { $wantTelemetryOff = $true }
}
$tcContract = Join-Path $InstallDir 'lib\telemetry-consent.contract'
$tcMarkName = ''
$tcEnvName = ''
if (Test-Path -LiteralPath $tcContract) {
    foreach ($tcLine in (Get-Content -LiteralPath $tcContract -Encoding UTF8)) {
        if ($tcLine -match '^\s*TELEMETRY_OPTOUT_FILE_NAME\s*=\s*(\S+)\s*$') { $tcMarkName = $Matches[1] }
        if ($tcLine -match '^\s*TELEMETRY_OPTOUT_ENV_NAME\s*=\s*(\S+)\s*$') { $tcEnvName = $Matches[1] }
    }
}
if ($tcEnvName) {
    $tcEnvVal = [Environment]::GetEnvironmentVariable($tcEnvName)
    if (@('1', 'true', 'yes') -contains ("$tcEnvVal".ToLower())) { $wantTelemetryOff = $true }
}
# 配置で写った指定書きは設定フォルダに残さない
Remove-Item -LiteralPath (Join-Path $InstallDir 'telemetry-off.flag') -Force -ErrorAction SilentlyContinue
if ($wantTelemetryOff) {
    $tcMarkPath = $null
    if ($tcMarkName -and ($tcMarkName -notmatch '[\\/]')) {
        $tcMarkPath = Join-Path $InstallDir $tcMarkName
        try { New-Item -ItemType File -Path $tcMarkPath -Force -ErrorAction Stop | Out-Null } catch { }
    }
    # 書けたかどうかは、置いた結果を確かめてから伝える
    if ($tcMarkPath -and (Test-Path -LiteralPath $tcMarkPath)) {
        Write-Ok "  ご指定どおり、動作状況のお知らせ (品質統計・エラー報告) を停止した状態で導入しました"
    } else {
        Write-Warn "  動作状況のお知らせを停止する設定を書き込めませんでした"
        Write-Host "  導入後に nomura.y@soloptilink.com へご連絡ください。停止の手順をご案内します。" -ForegroundColor Yellow
    }
}

# -----------------------------------------------------------------------------
# STEP 6: CRLF -> LF 正規化 (Windows 標準展開で CRLF が混入することがある)
# -----------------------------------------------------------------------------
Write-Step "6/11 改行コード正規化 (.sh ファイル)"

$shFiles = Get-ChildItem -Path $InstallDir -Filter "*.sh" -Recurse -ErrorAction SilentlyContinue
$fixedCount = 0
foreach ($f in $shFiles) {
    try {
        $bytes = [System.IO.File]::ReadAllBytes($f.FullName)
        if ($bytes -contains 13) {
            $text = [System.IO.File]::ReadAllText($f.FullName)
            $text = $text -replace "`r`n", "`n" -replace "`r", "`n"
            [System.IO.File]::WriteAllText($f.FullName, $text, [System.Text.UTF8Encoding]::new($false))
            $fixedCount++
        }
    } catch {
        # skip
    }
}
Write-Ok "  CRLF 正規化: $fixedCount ファイル修正"

# -----------------------------------------------------------------------------
# STEP 7: WCG-2 lib/ 完整性検証 (林事案の直接ガード)
# -----------------------------------------------------------------------------
Write-Step "7/11 lib/ 完整性検証 (WCG-2)"

$required = @(
    "lib\license-guard.sh",
    "lib\core\layer-loader.sh",
    "chain.sh"
)
$missing = @()
foreach ($r in $required) {
    $p = Join-Path $InstallDir $r
    if (-not (Test-Path $p)) { $missing += $r }
}

if ($missing.Count -gt 0) {
    Write-Err "  必須ファイルが不足しています:"
    foreach ($m in $missing) { Write-Host "     - $m" -ForegroundColor Red }
    Write-Host ""
    Write-Host "  配布物が破損している可能性があります。nomura.y@soloptilink.com にお問い合わせください。"
    End-Pause; exit 1
}
Write-Ok "  lib/license-guard.sh, lib/core/layer-loader.sh, chain.sh すべて存在"

# -----------------------------------------------------------------------------
#     区間の内側だけを常設検査 L237 が実際に走らせ、最後まで到達するかを確かめる。
#     この印の外へ処理を書くと、止まった箇所の再発が検査に映らなくなる。
# >>> SOLOPTILINK-ACTIVATION-SECTION-BEGIN
# STEP 8: Goランチャー検出 + 端末認証 (アクティベーション)
# -----------------------------------------------------------------------------
Write-Step "8/11 Goランチャー検出 + 端末認証" `
    'ネットワークの接続をご確認のうえ、このファイルをもう一度実行してください。二重にご登録されることはありません。'

$launcher = $null
$candidates = @("soloptilink.exe", "soloptilink-windows-amd64.exe", "soloptilink-windows-arm64.exe")
foreach ($c in $candidates) {
    $p = Join-Path $InstallDir $c
    if (Test-Path $p) { $launcher = $p; break }
}

$activated = $false
# 復旧案内は実検出したランチャー名で示す (soloptilink.exe 固定だと、アーキ名 exe のみの
# 環境で案内どおり実行しても CommandNotFound になり自力復旧できない — 2026-07-13 敵対検証)
$script:LauncherLeaf = 'soloptilink.exe'

# ── ご利用資格の記録 (license.json) の取り寄せ (2026-09-25 / 1 か所にまとめた) ──
# 【何が起きていたか】登録 (--activate) が保存するのはお申し込みの記録 (activation.json)
#   だけで、ご利用資格の記録 (license.json) は状態の確認 (--status) をしたときにしか
#   作られない。再実行時の取り寄せ (2026-09-03) はあったが、新規登録の直後には
#   状態の確認を呼んでいなかったため、サーバー側で承認済みでも直後の導入診断は
#   「5 ご契約端末としての登録」が × になっていた (Mac 側も同じ欠陥を同日に是正)。
# 【結果の 1 語】 approved … license.json が承認済みで作られたことを実物で確かめた
#                pending  … サーバーが承認待ちと答えた (承認待ちの端末に license.json は作られない)
#                unknown  … それ以外 (通信できない・時間切れ・その他の回答)
#   結果は導入診断へ渡し、承認待ちを × ではなく「手続き中」と表示させる。
#   ★承認済みかどうかは必ず license.json の実物で判断する (画面の文言だけで承認済みと言わない)。
#   ★承認待ちは、ランチャーの状態表示の「ステータス: … 承認待ち」の行を読む
#     (launcher/main.go runStatusCheck)。読めなくなっても unknown に倒れ、従来どおりの × に戻るだけ。
# 【止めない】失敗しても時間切れでも導入は続ける。画面の出力は見せない
#   (状態表示には打ち込み命令の案内が含まれるため。控えのログにだけ終了の様子を残す)。
$script:RegSyncStatus = ''
function Invoke-SlLicenseSync([string]$Launcher, [int]$TimeoutMs) {
    $licPath = Join-Path $InstallDir 'license.json'
    $syncEAP = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    # 承認待ちの端末で待ち合わせに入らせない (入るとセットアップ全体が止まる)。
    $env:SOLOPTILINK_ACTIVATE_NO_WAIT = '1'
    $syncBase = Join-Path ([System.IO.Path]::GetTempPath()) ("soloptilink-status-{0}" -f $PID)
    $syncOut = "$syncBase.out"
    $syncErr = "$syncBase.err"
    $said = ''
    try {
        # 万一この確認が応答しない場合でも、セットアップ全体が止まらないように
        # 時間の上限を設ける (上限に達したら打ち切って次の工程へ進む)。
        $sp = Start-Process -FilePath $Launcher -ArgumentList '--status' `
                -NoNewWindow -PassThru `
                -RedirectStandardOutput $syncOut -RedirectStandardError $syncErr
        if (-not $sp.WaitForExit($TimeoutMs)) {
            try { $sp.Kill() } catch { }
            Write-DetailToLog ("license-sync: timeout ({0}s)" -f [int]($TimeoutMs / 1000))
        } else {
            Write-DetailToLog ("license-sync: exit={0}" -f $sp.ExitCode)
        }
        if (Test-Path $syncOut) {
            $said = [string](Get-Content -LiteralPath $syncOut -Raw -Encoding UTF8 -ErrorAction SilentlyContinue)
        }
    } catch {
        Write-DetailToLog ("license-sync: error {0}" -f $_.Exception.Message)
    } finally {
        Remove-Item Env:SOLOPTILINK_ACTIVATE_NO_WAIT -ErrorAction SilentlyContinue
        Remove-Item $syncOut -ErrorAction SilentlyContinue
        Remove-Item $syncErr -ErrorAction SilentlyContinue
        $ErrorActionPreference = $syncEAP
    }
    if (Test-Path $licPath) {
        try {
            $licObj = Get-Content -Path $licPath -Raw -Encoding UTF8 | ConvertFrom-Json
            if ([string]$licObj.status -eq 'approved') { return 'approved' }
        } catch { }
    }
    if ($said -match 'ステータス:[^\r\n]*承認待ち') { return 'pending' }
    # ★2026-09-29: ランチャーは拒否・取り消し・契約終了・一時停止・未登録をはっきり表示するが、
    #   従来はそれを読み分けず 'unknown' に丸めていたため、画面は必ず「インターネットの接続を
    #   ご確認ください」になり、何度やり直しても抜けられない行き止まりになっていた。
    if ($said -match 'ステータス:[^\r\n]*拒否') { return 'rejected' }
    if ($said -match 'ステータス:[^\r\n]*取り消し') { return 'revoked' }
    if ($said -match 'ステータス:[^\r\n]*ご契約期間が終了') { return 'contract_ended' }
    if ($said -match 'ステータス:[^\r\n]*一時停止') { return 'suspended' }
    if ($said -match 'ステータス:[^\r\n]*ご契約端末として登録されていません') { return 'unregistered' }
    return 'unknown'
}

# 登録の状態が「通信の問題ではない」ときの案内を 1 か所にまとめる (2026-09-29)。
#   返り値: 案内を出したら $true (呼び出し側は通信の案内を出さない)
function Show-SlRegistrationStateGuide([string]$State) {
    $contact = 'nomura.y@soloptilink.com'
    switch ($State) {
        'rejected' {
            Write-Warn "  この端末のご登録は、弊社で承認できない状態になっています。"
            Write-Host "    セットアップをやり直しても状態は変わりません。お手数ですが $contact までご連絡ください。"
            Add-Issue "端末のご登録" "ご登録が承認されていません" "セットアップのやり直しでは解消しません。$contact までご連絡ください。"
            return $true
        }
        'revoked' {
            Write-Warn "  この端末のご利用は、弊社側で取り消されています。"
            Write-Host "    セットアップをやり直しても状態は変わりません。お心当たりがない場合は $contact までご連絡ください。"
            Add-Issue "端末のご登録" "この端末のご利用が取り消されています" "セットアップのやり直しでは解消しません。$contact までご連絡ください。"
            return $true
        }
        'contract_ended' {
            Write-Warn "  ご契約期間が終了しているため、専用機能はお休みしています。"
            Write-Host "    通常の Claude Code としてはこのままお使いいただけます。ご継続をご希望の場合は $contact までご連絡ください。"
            Add-Issue "ご契約" "ご契約期間が終了しています" "ご継続をご希望の場合は $contact までご連絡ください。"
            return $true
        }
        'suspended' {
            Write-Warn "  ご利用を一時停止している状態です。"
            Write-Host "    通常の Claude Code としてはこのままお使いいただけます。お心当たりがない場合は $contact までご連絡ください。"
            Add-Issue "ご契約" "ご利用を一時停止しています" "お心当たりがない場合は $contact までご連絡ください。"
            return $true
        }
        'unregistered' {
            Write-Warn "  この端末のご登録の記録が、弊社のサーバーで見つかりませんでした。"
            Write-Host "    セットアップをやり直しても状態は変わりません。お手数ですが $contact までご連絡ください。"
            Add-Issue "端末のご登録" "ご登録の記録がサーバーで見つかりません" "セットアップのやり直しでは解消しません。$contact までご連絡ください。"
            return $true
        }
    }
    return $false
}
if (-not $launcher) {
    Write-Warn "  soloptilink.exe が見つかりません。"
    Write-Host "  nomura.y@soloptilink.com に Windows 用ランチャーをご請求ください。"
} else {
    Write-Ok "  検出: $launcher"
    $script:LauncherLeaf = Split-Path $launcher -Leaf

    # ★2026-09-29: 本体 (soloptilink.exe) が Windows に起動を止められていないかを先に確かめる。
    #   スマート アプリ コントロール (SAC)・組織のアプリ制御・ウイルス対策に止められると、
    #   以前はご登録の失敗として「インターネットの接続をご確認ください」と案内していた。
    #   原因が違うため、何度やり直しても抜けられない行き止まりになっていた。
    #   ここで試しに版数だけを尋ね、止められた場合は原因別の案内を出してご登録を試みない。
    $script:LauncherBlocked = ''
    $probeEAP = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        $null = & $launcher --version 2>&1
    } catch {
        $probeCode = 0
        $probeEx = $_.Exception
        while ($probeEx) {
            if ($probeEx -is [System.ComponentModel.Win32Exception]) { $probeCode = $probeEx.NativeErrorCode; break }
            $probeEx = $probeEx.InnerException
        }
        $probeMsg = [string]$_.Exception.Message
        if ($probeCode -eq 4551 -or $probeMsg -match 'Application Control|アプリケーション制御|アプリ制御') {
            $script:LauncherBlocked = 'appcontrol'
        } elseif ($probeCode -eq 1260 -or $probeMsg -match 'group policy|グループ ?ポリシー|AppLocker') {
            $script:LauncherBlocked = 'policy'
        } elseif ($probeCode -eq 225 -or $probeCode -eq 226 -or $probeMsg -match 'virus|ウイルス') {
            $script:LauncherBlocked = 'antivirus'
        } else {
            $script:LauncherBlocked = 'unknown'
        }
        Write-DetailToLog ("launcher-probe blocked={0} code={1} message={2}" -f $script:LauncherBlocked, $probeCode, $probeMsg)
    } finally {
        $ErrorActionPreference = $probeEAP
    }
    # 配置した直後に本体が消えている = ウイルス対策に隔離された疑い
    if (-not $script:LauncherBlocked -and -not (Test-Path $launcher)) { $script:LauncherBlocked = 'antivirus' }
    if ($script:LauncherBlocked) {
        Write-Warn "  SoloptiLinkAI の本体 (soloptilink.exe) を、この PC が起動させませんでした。"
        switch ($script:LauncherBlocked) {
            'appcontrol' {
                Write-Host "    原因: Windows の「スマート アプリ コントロール」または組織のアプリ制御が止めています。"
                Write-Host "    本体には現在デジタル署名が付いていないため、この機能が有効な PC では起動できません。"
                Write-Host "    この機能の設定を変えるかどうかは、御社の IT ご担当の方のご判断になります。"
                Add-Issue "本体の起動" "Windows のアプリ制御 (スマート アプリ コントロール等) が本体の起動を止めています" "セットアップのやり直しでは解消しません。御社の IT ご担当の方と相談のうえ、nomura.y@soloptilink.com までご連絡ください。"
            }
            'policy' {
                Write-Host "    原因: 組織のグループ ポリシー (AppLocker 等) が止めています。"
                Add-Issue "本体の起動" "組織のポリシーが本体の起動を止めています" "御社の IT ご担当の方に、SoloptiLinkAI の導入フォルダの実行許可をご相談ください。そのうえで、このファイルをもう一度実行してください。"
            }
            'antivirus' {
                Write-Host "    原因: ウイルス対策ソフトが本体を隔離した可能性があります。"
                Add-Issue "本体の起動" "ウイルス対策ソフトが本体を隔離した可能性があります" "ウイルス対策ソフトの隔離一覧に soloptilink.exe が無いかをご確認のうえ、nomura.y@soloptilink.com までご連絡ください。"
            }
            default {
                Write-Host "    原因をこの場で特定できませんでした。"
                Add-Issue "本体の起動" "本体を起動できませんでした" "この画面の写真と、導入フォルダの setup_log.txt を nomura.y@soloptilink.com へお送りください。"
            }
        }
        Write-Host "    この状態ではご登録ができないため、ご登録の工程は行いません。"
    }

    if ($Verify) {
        Write-Host ""
        Write-Step "認証ステータス確認"
        # ネイティブコマンドの stderr が Stop で例外化する PS 5.1 の罠を避ける
        # (自動更新直後の初回 --status やオフライン時の警告が stderr に出ると
        #  NativeCommandError へ昇格し最上位 trap に捕捉されてしまう)
        $prevEAP = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        try { & $launcher --status 2>&1 | Out-Host } catch { }
        $ErrorActionPreference = $prevEAP
    }

    # 端末認証 (登録済みなら自動スキップ / -NoActivate で抑止)
    # 本体が起動を止められているときは登録を試みない (試みても通信の失敗に見えるだけ)
    if (-not $NoActivate -and -not $script:LauncherBlocked) {
        # ★2026-08-26 是正: この区間は「今の設定を控える → 一時的に緩める → 元に戻す」の
        #   三点が揃って初めて成立するが、控える処理と緩める処理が欠落し、末尾の戻す処理だけが
        #   残っていた。厳格モードでは控えていない値の参照が例外になるため、端末のご登録に
        #   成功した直後に異常終了扱いとなり、画面には「予期しない問題が発生しました」と
        #   表示され、しかも 9/11 以降 (Claude Desktop 連携・自動更新・前提ソフト確認) が
        #   丸ごと実行されないまま終了していた。三点を揃えて根治する。
        $actEAP = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        # ★登録済みかどうかは端末に残る登録の記録で判断する (2026-08-17 / Mac 側と同一基準)
        #   従来はサーバへの問い合わせ結果の文言 ("承認済み") だけを見ていた。
        #   これだと接続が不調なときや、承認待ちの端末で毎回入力を求めることになる。
        #   逆に、引き継げたファイルの数を根拠にすると (Mac 側で起きた事故)、
        #   登録の成否によらず作られる端末の指紋まで「登録済みの証拠」に数えてしまい、
        #   一度失敗した端末が二度と登録できなくなる。
        #   登録が済んだと言えるのは activation.json と license.json がそろい、
        #   license.json の状態が有効なときだけ。診断 (self-check) と同じ基準に揃える。
        # ★2026-09-01 是正: license.json は「承認後にサーバーと通信できて初めて」作られる
        #   記録であり、承認待ちの端末には存在しない。そこまで要求すると、承認待ちの
        #   端末が再実行のたびにメールとパスワードを求められる堂々巡りになる (実欠陥)。
        #   登録の記録は activation.json (登録成功時のみ作られ device_id を含む) を根拠にし、
        #   端末の指紋ファイル (.device_identity.json / 登録の成否によらず作られる) は
        #   従来どおり根拠に数えない。
        $alreadyRegistered = $false
        $actPath = Join-Path $InstallDir 'activation.json'
        if (Test-Path $actPath) {
            try {
                $actObj = Get-Content -Path $actPath -Raw -Encoding UTF8 | ConvertFrom-Json
                if ([string]$actObj.device_id -match '^dev_') {
                    $alreadyRegistered = $true
                }
            } catch { $alreadyRegistered = $false }
        }
        if ($alreadyRegistered) {
            Write-Ok "  この端末はすでに登録済みです (入力は不要です)。"
            $activated = $true
            # ★2026-09-03 是正: ご登録の「お申し込み」と「ご利用開始」は別の出来事である。
            #   activation.json はお申し込みが届いた時点で作られる。一方、この端末が実際に
            #   使える状態であることを示す license.json は【承認されたあとに、サーバーと
            #   通信できて初めて】作られる。
            #   承認がお申し込みより後になった端末では、この通信が一度も行われない。
            #   その結果、画面には「すでに登録済みです」と出るのに、診断では
            #   「ご契約端末としての登録」が不合格のまま、という食い違いが残る。
            #   しかも診断の案内は「セットアップをやり直してください」なので、
            #   お客様は何度やり直してもここで必ず素通りし、状態が一切変わらない
            #   (実際に 1 日で 5 回繰り返しても変化しなかった実例がある)。
            #   ここで最新のご登録状態をサーバーへ確認し、足りない記録を取り寄せる。
            #     ・お客様の入力は要らない (メールアドレスもパスワードも尋ねない)
            #     ・承認がまだの端末では何も作られない。待ち合わせもしない
            #     ・すでに記録がそろっている端末では、通信そのものを行わない
            $licPath = Join-Path $InstallDir 'license.json'
            $licOk = $false
            if (Test-Path $licPath) {
                try {
                    $licObj = Get-Content -Path $licPath -Raw -Encoding UTF8 | ConvertFrom-Json
                    if ([string]$licObj.status -eq 'approved') { $licOk = $true }
                } catch { $licOk = $false }
            }
            if (-not $licOk) {
                Write-Host "  ご登録の状態を確認しています..."
                # 休止明けのサーバーは最初の応答に時間がかかることがあるため、60 秒まで待つ。
                $script:RegSyncStatus = Invoke-SlLicenseSync $launcher 60000
                if ($script:RegSyncStatus -eq 'approved') {
                    Write-Ok "  ご登録の状態を最新にしました。"
                } elseif ($script:RegSyncStatus -eq 'pending') {
                    Write-Host "    ご登録は受け付け済みで、弊社の承認をお待ちいただいている状態です。"
                    Write-Host "    承認のご連絡を受け取ったあとに、このファイルをもう一度実行してください (入力は不要です)。"
                } elseif (Show-SlRegistrationStateGuide $script:RegSyncStatus) {
                    # 通信の問題ではない状態 (拒否・取り消し・契約終了など)。案内は関数の中で済ませた
                } else {
                    Write-Host "    ご登録の状態を、いまは確認できませんでした。"
                    Write-Host "    インターネットの接続をご確認のうえ、しばらくしてからこのファイルをもう一度実行してください (入力は不要です)。"
                    Write-Host "    何度やり直しても変わらない場合は、この画面の写真を撮って nomura.y@soloptilink.com へお送りください。"
                }
            }
        } else {
            Write-Host ""
            Write-Host "  ── この端末のご登録 ──"
            Write-Host ""
            Write-Host "  このあと、メールアドレスとパスワードの入力をお願いします。"
            Write-Host "  当社からお送りしたご案内メールをお手元にご用意ください。"
            Write-Host ""
            # ★パスワードが画面に出ないことを、入力前に必ずお伝えする (2026-08-17)
            #   安全のためパスワードは一文字も表示されない。その説明が無いと
            #   「入力を受け付けていない」と受け取られ、そのまま中断されてしまう。
            Write-Host "  ※ パスワードは、安全のため入力しても画面には表示されません。"
            Write-Host "     これは正常な動作です。そのまま最後まで入力してください。"
            Write-Host ""
            try {
                # 2026-07-13 敵対検証で確証: 承認待ちポーリング (最大30分) をインストーラ内で
                # 同期実行すると、ランチャー自身が案内する Ctrl+C がコンソール全体に配送されて
                # 本インストーラごと停止し、後続工程 (MCP登録/自動更新フック/前提ソフト) が
                # 全滅する。登録だけ行い、承認待ちはスキップして次の工程へ進む。
                $env:SOLOPTILINK_ACTIVATE_NO_WAIT = '1'
                & $launcher --activate
                # 2026-07-13 敵対検証で確証: ネイティブ exe の非0終了は EAP=Continue では
                # catch に入らないため、終了コードで成否を二分する (認証失敗の偽成功防止)。
                if ($LASTEXITCODE -eq 0) {
                    $activated = $true
                    # ★2026-09-25 新設: 登録が通ったら、その場でご利用資格の記録を取り寄せる
                    #   (理由と結果の読み方は区間冒頭の Invoke-SlLicenseSync の注記を参照)。
                    #   登録の直後はサーバーが応答できる状態にあるため、待つ上限は 20 秒にとどめる。
                    Write-Host ""
                    Write-Host "  ご登録の状態を確認しています..."
                    $script:RegSyncStatus = Invoke-SlLicenseSync $launcher 20000
                    if ($script:RegSyncStatus -eq 'approved') {
                        Write-Ok "  ご登録が承認済みであることを確認しました。このままお使いいただけます。"
                    } elseif ($script:RegSyncStatus -eq 'pending') {
                        Write-Ok "  ご登録を受け付けました。弊社の承認が済みしだい、お使いいただけるようになります。"
                    } elseif (Show-SlRegistrationStateGuide $script:RegSyncStatus) {
                        # 通信の問題ではない状態。案内は関数の中で済ませた
                    } else {
                        Write-Host "    ご登録は受け付けましたが、承認の状態はこの場では確認できませんでした。"
                        Write-Host "    承認のご連絡を受け取ったあとに、このファイルをもう一度実行すると確認できます (入力は不要です)。"
                    }
                } else {
                    # ★2026-08-10 是正: 終了コードと打ち込むコマンドを画面に出していたが、
                    #   お客様には実行できない案内だった。もう一度ダブルクリックすれば
                    #   同じ登録がやり直せるので、それだけを日本語で案内する。
                    #   終了コードは控えのログにだけ残す。
                    Write-DetailToLog ("activation-failure exit={0}" -f $LASTEXITCODE)
                    Write-Warn "  ご登録が完了しませんでした"
                    Write-Host "    インターネットの接続をご確認のうえ、このファイルをもう一度実行してください。"
                    Write-Host "    同じ手順を繰り返しても、二重に登録されることはありません。"
                    Write-Host "    解消しない場合は、この画面の写真を nomura.y@soloptilink.com へお送りください。"
                    Add-Issue "端末のご登録" "ご登録の通信が完了しませんでした" "インターネットの接続をご確認のうえ、このファイルをもう一度実行してください (二重登録はされません)。"
                }
            } catch {
                Write-Warn "  ご登録が完了しませんでした"
                Write-Host "    インターネットの接続をご確認のうえ、このファイルをもう一度実行してください。"
                Write-Host "    同じ手順を繰り返しても、二重に登録されることはありません。"
                Write-Host "    解消しない場合は、この画面の写真を nomura.y@soloptilink.com へお送りください。"
                Add-Issue "端末のご登録" "ご登録の処理が途中で止まりました" "インターネットの接続をご確認のうえ、このファイルをもう一度実行してください (二重登録はされません)。"
            } finally {
                Remove-Item Env:SOLOPTILINK_ACTIVATE_NO_WAIT -ErrorAction SilentlyContinue
            }
        }
        $ErrorActionPreference = $actEAP
    }
}
# <<< SOLOPTILINK-ACTIVATION-SECTION-END

# -----------------------------------------------------------------------------
# STEP 8.5: メニュー (スキル) の配置
# -----------------------------------------------------------------------------
# 【何が壊れていたか (2026-09-03)】
#   メニューは 2 か所に置かれて初めて画面に出る。
#     (1) $InstallDir\skills          … 配布物の中身。STEP 5 で必ず置かれる
#     (2) %USERPROFILE%\.claude\skills … お客様の画面が実際に読む場所
#   ところが (2) を作る処理は【端末のご登録の中にしか無かった】。
#   一度ご登録が済んだ端末では、このファイルを何度実行してもご登録の工程が
#   丸ごと省略されるため、(2) は永久に作られない。その結果、
#     ・メニューが画面に出てこない
#     ・最後の自己点検が「配置が完了していない」を出し続ける
#   という 2 つの症状が同時に起き、しかもその案内は「やり直してください」
#   だったので、やり直しても何も変わらないまま繰り返すことになっていた
#   (実際に 1 日で 5 回繰り返しても変化しなかった実例がある)。
#   → ご登録の有無と切り離し、毎回ここで (1) から (2) へ配置する。
# -----------------------------------------------------------------------------
Write-Step "8.5/11 メニュー (スキル) を配置"

# >>> SOLOPTILINK-SKILL-PLACE-BEGIN
#   ★この印の内側が「メニュー (スキル) をお客様の画面が読む場所へ置く」処理の全体である。
#     3 つの入口 (Mac / Windows / Linux) が同じ働きをするかを、常設検査が
#     この印の内側だけを実際に走らせて確かめる。印を消すと検査は測れなくなり、
#     「測れていない」= 合格ではない、として扱われる。
#   【なぜ印が要るか (2026-09-04)】v2056.5 以前の Windows 入口には、この処理が
#     1 行も存在しなかった。配布物にメニュー 20 件が正しく同梱されているのに
#     置く処理だけが無く、お客様の端末では永久に配置されなかった。それでも
#     入口の常設検査は緑のままだった — 検査が設定用スクリプトの顔ぶれしか
#     見ておらず、メニュー配置を一度も照合していなかったため。
$skillsSrc  = Join-Path $InstallDir 'skills'
$claudeRoot = Join-Path $env:USERPROFILE '.claude'
$skillsDst  = Join-Path $claudeRoot 'skills'
$cmdsDst    = Join-Path $claudeRoot 'commands'

if (-not (Test-Path $skillsSrc)) {
    Write-Warn "  メニューの元ファイルが見つかりませんでした。"
    Write-Host "  このファイルをもう一度実行してください。解消しない場合は nomura.y@soloptilink.com へご連絡ください。"
    Add-Issue "メニュー (スキル)" "メニューの元ファイルが配布物の中に見つかりませんでした" "このファイルをもう一度実行してください。解消しない場合はサポートへご連絡ください。"
} else {
    try {
        if (-not (Test-Path $skillsDst)) { New-Item -ItemType Directory -Path $skillsDst -Force | Out-Null }
        if (-not (Test-Path $cmdsDst))   { New-Item -ItemType Directory -Path $cmdsDst   -Force | Out-Null }

        # 入れ替える前の控えを 1 か所にまとめて取る (お客様が手を入れていた場合の保険)。
        $skStamp = Get-Date -Format "yyyyMMdd-HHmmss"
        $skBkRoot = Join-Path $claudeRoot ("_backups\skills_{0}" -f $skStamp)

        $placed = 0
        $failed = @()
        foreach ($d in (Get-ChildItem -Path $skillsSrc -Directory -ErrorAction SilentlyContinue)) {
            $name = $d.Name
            if (-not (Test-Path (Join-Path $d.FullName 'SKILL.md'))) { continue }
            $tgt = Join-Path $skillsDst $name
            try {
                if (Test-Path $tgt) {
                    if (-not (Test-Path $skBkRoot)) { New-Item -ItemType Directory -Path $skBkRoot -Force | Out-Null }
                    & robocopy "$tgt" (Join-Path $skBkRoot $name) /E /NFL /NDL /NJH /NJS /R:1 /W:1 | Out-Null
                    Remove-Item -Path $tgt -Recurse -Force -ErrorAction SilentlyContinue
                }
                # /IS = 中身が同じに見えるファイルも必ず書き換える。
                #   これが無いと、本体だけ新しくメニューが古いまま残る状態を直せない。
                & robocopy "$($d.FullName)" "$tgt" /E /IS /NFL /NDL /NJH /NJS /R:2 /W:2 | Out-Null
                if ($LASTEXITCODE -ge 8) { throw ("robocopy rc={0}" -f $LASTEXITCODE) }

                # 画面から呼び出すための対応表も同じ内容で置き直す。
                $cmdFile = Join-Path $cmdsDst ("{0}.md" -f $name)
                if (Test-Path $cmdFile) {
                    if (-not (Test-Path $skBkRoot)) { New-Item -ItemType Directory -Path $skBkRoot -Force | Out-Null }
                    Copy-Item $cmdFile (Join-Path $skBkRoot ("{0}.md" -f $name)) -Force -ErrorAction SilentlyContinue
                }
                Copy-Item (Join-Path $d.FullName 'SKILL.md') $cmdFile -Force
                $placed++
            } catch {
                $failed += $name
                Write-DetailToLog ("skill-place: {0} failed: {1}" -f $name, $_.Exception.Message)
            }
        }
        $LASTEXITCODE = 0

        # ---------------------------------------------------------------------
        # ★修正D (2026-09-03): 以前の導入で残った【配布物に無い】メニューを取り除く
        #   上の置き換えは名前ごとに行うため、今回の配布物に含まれない
        #   メニューはそのまま残る。その中に当社社内向けのものがあると、
        #   導入診断 #6 が「社内向けメニューが混ざっている」として不合格になり、
        #   お客様の画面に「一部が未完了」と出続ける。
        #   実測 (2026-09-03 Windows 実機): 20 件を配置した直後でも
        #   .claude\skills は 21 件で、差分の 1 件が社内向けメニューだった。
        #   → 消す前に必ず控えを取る。管理者端末 (.admin_mode あり) では取り除かない。
        # ---------------------------------------------------------------------
        $adminNames = @('soloptilink-deploy', 'soloptilink-release', 'soloptilink-doctor', 'soloptilink-arte')
        # ★2026-10-26: 名前の手書き一覧だけでは、新しく作った管理者専用のメニューを取りこぼす。
        #   配布物の SKILL.md の先頭 (frontmatter) に admin_only: true があるものも除外に加える。
        foreach ($d2 in (Get-ChildItem -Path $skillsSrc -Directory -ErrorAction SilentlyContinue)) {
            $sk2 = Join-Path $d2.FullName 'SKILL.md'
            if (Test-Path $sk2) {
                $head2 = (Get-Content -LiteralPath $sk2 -TotalCount 30 -Encoding UTF8 -ErrorAction SilentlyContinue) -join "`n"
                if ($head2 -match '(?m)^admin_only:\s*true\s*$' -and ($adminNames -notcontains $d2.Name)) { $adminNames += $d2.Name }
            }
        }
        if (-not (Test-Path (Join-Path $InstallDir '.admin_mode'))) {
            $swept = 0
            foreach ($an in $adminNames) {
                try {
                    $adDir = Join-Path $skillsDst $an
                    if (Test-Path $adDir) {
                        if (-not (Test-Path $skBkRoot)) { New-Item -ItemType Directory -Path $skBkRoot -Force | Out-Null }
                        & robocopy "$adDir" (Join-Path $skBkRoot $an) /E /NFL /NDL /NJH /NJS /R:1 /W:1 | Out-Null
                        Remove-Item -Path $adDir -Recurse -Force -ErrorAction SilentlyContinue
                        $swept++
                    }
                    $adMd = Join-Path $cmdsDst ("{0}.md" -f $an)
                    if (Test-Path $adMd) {
                        if (-not (Test-Path $skBkRoot)) { New-Item -ItemType Directory -Path $skBkRoot -Force | Out-Null }
                        Copy-Item $adMd (Join-Path $skBkRoot ("{0}.md" -f $an)) -Force -ErrorAction SilentlyContinue
                        Remove-Item -Path $adMd -Force -ErrorAction SilentlyContinue
                        $swept++
                    }
                } catch {
                    Write-DetailToLog ("skill-sweep: {0} failed: {1}" -f $an, $_.Exception.Message)
                }
            }
            $LASTEXITCODE = 0
            if ($swept -gt 0) {
                Write-Ok ("  以前の導入で残っていた不要なメニューを {0} 件取り除きました (控えを保存済み)。" -f $swept)
            }
            Write-DetailToLog ("skill-sweep: swept={0}" -f $swept)
        } else {
            Write-DetailToLog "skill-sweep: skipped (admin mode)"
        }

        if ($placed -gt 0 -and $failed.Count -eq 0) {
            Write-Ok ("  メニューを {0} 件配置しました。" -f $placed)
        } elseif ($placed -gt 0) {
            Write-Warn ("  メニューを {0} 件配置しましたが、{1} 件は配置できませんでした。" -f $placed, $failed.Count)
            Write-Host "  Claude Desktop と Claude Code を終了した状態で、このファイルをもう一度実行してください。"
            Add-Issue "メニュー (スキル)" ("{0} 件のメニューを配置できませんでした" -f $failed.Count) "Claude Desktop と Claude Code を終了した状態で、このファイルをもう一度実行してください。"
        } else {
            Write-Warn "  メニューを配置できませんでした。"
            Write-Host "  Claude Desktop と Claude Code を終了した状態で、このファイルをもう一度実行してください。"
            Add-Issue "メニュー (スキル)" "メニューを 1 件も配置できませんでした" "Claude Desktop と Claude Code を終了した状態で、このファイルをもう一度実行してください。"
        }
        Write-DetailToLog ("skill-place: placed={0} failed={1}" -f $placed, ($failed -join ','))
    } catch {
        Write-Warn "  メニューの配置中に問題が起きました。"
        Write-Host "  このファイルをもう一度実行してください。解消しない場合は nomura.y@soloptilink.com へご連絡ください。"
        Write-DetailToLog ("skill-place: error {0}" -f $_.Exception.Message)
        Add-Issue "メニュー (スキル)" "メニューの配置が完了しませんでした" "このファイルをもう一度実行してください。解消しない場合はサポートへご連絡ください。"
    }
}

    # ---- 担当ロールの配置 (2026-09-08 新設) ----------------------------------
    # 【なぜ要るか — 実測】
    #   配布物には担当ロールの定義が 183 件同梱されているのに、Windows の入口だけ
    #   それを置く処理が 1 行も無かった (Mac / Linux / Web の入口はいずれも置いている)。
    #   結果、Windows のお客様の端末では専門の担当が呼び出せず、
    #   Mac のお客様と編成の規模が違う成果物になっていた。それでも導入は「完了」と表示される。
    #   横並びの検査が 5 観点しか持たず、この観点が無かったため一度も映らなかった。
    $agentsSrc = Join-Path $InstallDir 'agents'
    $agentsDst = Join-Path $claudeRoot 'agents'
    if (-not (Test-Path $agentsSrc)) {
        Write-DetailToLog "agents-place: source not found (skip)"
    } else {
        try {
            if (-not (Test-Path $agentsDst)) { New-Item -ItemType Directory -Path $agentsDst -Force | Out-Null }
            $agPlaced = 0; $agFailed = 0
            foreach ($f in (Get-ChildItem -Path $agentsSrc -Filter *.md -File -ErrorAction SilentlyContinue)) {
                try {
                    Copy-Item -LiteralPath $f.FullName -Destination (Join-Path $agentsDst $f.Name) -Force -ErrorAction Stop
                    $agPlaced++
                } catch { $agFailed++ }
            }
            if ($agPlaced -gt 0 -and $agFailed -eq 0) {
                Write-Host ("  専門の担当を {0} 件配置しました。" -f $agPlaced)
            } elseif ($agPlaced -gt 0) {
                Write-Warn ("  専門の担当を {0} 件配置しましたが、{1} 件は配置できませんでした。" -f $agPlaced, $agFailed)
                Add-Issue "担当ロール" ("{0} 件を配置できませんでした" -f $agFailed) "Claude Desktop と Claude Code を終了した状態で、このファイルをもう一度実行してください。"
            } else {
                Write-Warn "  専門の担当を配置できませんでした。"
                Add-Issue "担当ロール" "担当ロールを 1 件も配置できませんでした" "Claude Desktop と Claude Code を終了した状態で、このファイルをもう一度実行してください。"
            }
            Write-DetailToLog ("agents-place: placed={0} failed={1}" -f $agPlaced, $agFailed)
        } catch {
            Write-Warn "  専門の担当の配置中に問題が起きました。"
            Write-DetailToLog ("agents-place: error {0}" -f $_.Exception.Message)
            Add-Issue "担当ロール" "担当ロールの配置が完了しませんでした" "このファイルをもう一度実行してください。解消しない場合はサポートへご連絡ください。"
        }
    }
# <<< SOLOPTILINK-SKILL-PLACE-END

# -----------------------------------------------------------------------------
# STEP 9: Claude Desktop MCP 自動登録 (PFP-119 / 2026-06-12)
# %APPDATA%\Claude\claude_desktop_config.json へ soloptilink MCP サーバーを
# マージ登録する (ConvertFrom-Json/ConvertTo-Json で既存の mcpServers 設定は保持)。
# 登録に失敗してもセットアップ全体は続行する (後から手動登録可能)。
# -----------------------------------------------------------------------------
Write-Step "9/11 Claude Desktop との連携を登録" `
    'Claude Desktop を終了した状態で、このファイルをもう一度実行してください。'

# >>> SOLOPTILINK-DESKTOP-MCP-BEGIN
if (-not $launcher) {
    Write-Warn "  本体の準備が整っていないため、Claude Desktop との連携登録を行えませんでした。"
    Write-Host "  このファイルをもう一度実行してください。解消しない場合は nomura.y@soloptilink.com へご連絡ください。"
} else {
    try {
        $cfgDir = Join-Path $env:APPDATA "Claude"
        $cfgPath = Join-Path $cfgDir "claude_desktop_config.json"
        if (-not (Test-Path $cfgDir)) {
            New-Item -ItemType Directory -Path $cfgDir -Force | Out-Null
            Write-Warn "  Claude Desktop が未インストールの可能性があります (設定フォルダを新規作成)"
        }

        # ★2026-10-28: 既存の設定の全文の控え (claude_desktop_config.json.bak.<日時>) は作らない。
        #   控えには他社の接続先の鍵などがそのまま写り、消す処理がどこにも無いまま残り続けていた。
        #   また、読めない設定を空とみなして当社の登録だけで上書きしていた (ほかの連携の登録が消える)。
        #   読めない・想定外の形の設定は 1 バイトも書き換えずに要対応へ回す (Set-SlDesktopMcpEntry)。
        $entry = [PSCustomObject]@{
            command = $launcher.Replace("\", "/")
            args    = @("--mcp-server")
        }
        $mcpState = Set-SlDesktopMcpEntry -Path $cfgPath -Entry $entry
        if ($mcpState -eq 'failed') { throw "Claude Desktop の設定を置き換えられませんでした (設定は元のままです)" }

        # ★2026-09-29: パッケージ形式 (MSIX / ストア版) の Claude Desktop は、%APPDATA% ではなく
        #   %LOCALAPPDATA%\Packages\Claude_*\LocalCache\Roaming\Claude の設定を読む。
        #   その端末では上の登録が読まれず、連携が効かないままになる。在る場合だけ同じ登録を足す。
        #   (既存の設定は保持する。ここの失敗は上の登録の成否に影響させない)
        $storeUnreadable = @()
        if ($env:LOCALAPPDATA) {
            $pkgRoot = Join-Path $env:LOCALAPPDATA 'Packages'
            $pkgDirs = @()
            try { $pkgDirs = @(Get-ChildItem -Path $pkgRoot -Directory -Filter 'Claude_*' -ErrorAction SilentlyContinue) } catch { }
            foreach ($pd in $pkgDirs) {
                try {
                    $vDir = Join-Path (Join-Path (Join-Path $pd.FullName 'LocalCache') 'Roaming') 'Claude'
                    if (-not (Test-Path $vDir)) { continue }
                    $vPath = Join-Path $vDir 'claude_desktop_config.json'
                    $vState = Set-SlDesktopMcpEntry -Path $vPath -Entry $entry
                    if ($vState -eq 'unreadable') { $storeUnreadable += $vPath }
                    Write-DetailToLog ("mcp-register: packaged desktop config {0} {1}" -f $vState, $vPath)
                } catch {
                    Write-DetailToLog ("mcp-register: packaged desktop config failed {0}" -f $_.Exception.Message)
                }
            }
        }
        if ($mcpState -eq 'unreadable' -or $storeUnreadable.Count -gt 0) {
            $mcpWhich = if ($mcpState -eq 'unreadable') { 'Claude Desktop' } else { 'ストア版の Claude Desktop' }
            Write-Warn ("  {0} の設定ファイルを読み取れないため、そちらへの連携の登録を見送りました。" -f $mcpWhich)
            Write-Host "     お客様の設定は一切書き換えていません。" -ForegroundColor DarkGray
            Add-Issue "Claude Desktop との連携" ("{0} の設定ファイル (claude_desktop_config.json) を読み取れないため、連携を登録していません (お客様の設定は一切書き換えていません)" -f $mcpWhich) "設定ファイルの書式をご確認いただくか、この画面を添えてサポート窓口 (nomura.y@soloptilink.com) へご連絡ください。"
        }
        if ($mcpState -eq 'ok') {
            Write-Ok "  Claude Desktop との連携を登録しました"
            Write-Host "  (反映には Claude Desktop の完全終了 → 再起動が必要です)"
        }
    } catch {
        Write-DetailToLog ("mcp-register-failure message={0}" -f $_.Exception.Message)
        Write-Warn "  Claude Desktop への登録を完了できませんでした (要対応一覧にまとめます)"
        # ★2026-09-29: 以前は「install-claude-desktop-mcp.ps1 を実行」と案内していたが、.ps1 は
        #   ダブルクリックするとメモ帳が開くだけで実行されない (行き止まり)。この工程は何度
        #   繰り返しても安全なので、同じセットアップの再実行へ案内する。
        Write-Host "  Claude Desktop を完全に終了してから、「まず最初にこれを実行.bat」をもう一度ダブルクリックしてください。"
        Add-Issue "Claude Desktop との連携" "連携の登録を完了できませんでした" "Claude Desktop を完全に終了（タスクトレイのアイコンも終了）してから、導入フォルダの「まず最初にこれを実行.bat」をもう一度ダブルクリックしてください。この工程は何度実行しても安全です。解消しない場合はサポート窓口 (nomura.y@soloptilink.com) へご連絡ください。"
    }
}
# <<< SOLOPTILINK-DESKTOP-MCP-END

# -----------------------------------------------------------------------------
# STEP 10: Claude Code 自動更新フックの登録 (Windows 導入時に更新が届かない状態を防ぐ)
# -----------------------------------------------------------------------------
# 【鶏卵デッドロックの解消 + Windows bash 非依存化】
# 従来 Windows では「自動更新フックを誰も登録しない」かつ「フック本体が bash 依存で
# 起動できない」ため、自動更新が一度も走らなかった。ここで導入時点で、ランチャー
# (.exe) 経由のフック (`"<exe>" --hook-autoupdate`) を ~/.claude/settings.json へ
# 冪等登録する。JSON マージは Go 実装に委譲し、PowerShell の配列直列化事故を避ける。
Write-Step "10/11 自動更新を有効化 (Claude Code フック登録)"

if (-not $launcher) {
    Write-Warn "  本体の準備が整っていないため、自動更新の設定を行えませんでした。"
    Write-Host "  最新版にしたいときは、チャット欄に「最新版にして」とお伝えください。"
} else {
    $prevEAP2 = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $hookOut = ""
    try { $hookOut = (& $launcher --register-autoupdate-hook 2>&1 | Out-String) } catch { }
    $ErrorActionPreference = $prevEAP2
    # 2026-07-13 敵対検証で確証: 旧判定 (-match "登録") は失敗メッセージ
    # 「自動更新フックの登録に失敗」にもマッチして偽成功になる。成功文言に限定する。
    if ($hookOut -match "登録しました|既に登録済み") {
        Write-Ok "  自動更新フックを登録しました (以降 Claude Code 起動時に最新版を自動取得)"
    } else {
        # ★2026-08-10 是正: 打ち込むコマンドではなく、チャットからできる案内に変える
        Write-Warn "  自動更新の登録結果を確認できませんでした。"
        Write-Host "  最新版にしたいときは、チャット欄に「最新版にして」とお伝えください。"
    }
}

# -----------------------------------------------------------------------------
# STEP 10.5: 品質・信頼性フックの登録 (2026-08-01 実測監査 指摘1 の恒久対策)
# -----------------------------------------------------------------------------
# 【何が壊れていたか】Windows 導入経路では migration/ を一度も実行していなかった。
#   そのため v2027 (自動更新) 以降に追加された遡及配線 — 品質ゲートや
#   エラーゼロ化4本柱の結線層 (lib/hooks/reliability-lifecycle-hook.sh の7エントリ) — が
#   Windows 端末には一切入らなかった。macOS 側 (.command) と同様に、
#   migration/ 配下を列挙せず全実行する (各スクリプトが自前で冪等)。
#   bash が見つからない環境では黙って諦めず、後で自動更新経路が拾えるよう案内だけ出す
#   (Git for Windows は STEP 11 で導入されるため、次回起動時に適用される)。
# -----------------------------------------------------------------------------
# STEP 10.4: 初期設定の材料を配置
# -----------------------------------------------------------------------------
# 【何が欠けていたか (2026-09-03)】
#   導入直後の自己診断で「初期設定 (日本語・品質の既定)」が未完了と表示される
#   端末があった。原因は故障ではなく、それが参照する材料 2 種類が配布物に一度も
#   入っていなかったこと。
#     ・customer-claude-md.md … 日本語・品質の既定を書き込むための元原稿
#     ・model-policy.json     … どのモデルを既定にするかの方針 (当社が定める)
#   材料が無いので移行処理は「勝手な既定文面で代替しない」設計どおり何もせず、
#   診断はそれを正しく「未完了」と表示していた。Windows・Mac の双方で起きる。
#   ★この配置は次の STEP 10.5 (移行処理) より前でなければならない。移行処理が
#     ここで置いた原稿を読んで CLAUDE.md へ追記するため。順序を入れ替えないこと。
#   ※ メニュー (スキル) の「4 か所目」はここでは作らない。あの場所は当社が本体を
#     組み立てる工程の置き場であり、お客様の端末には作られないのが正しい状態。
#     無いことを不合格にしていた診断側を是正済み (自己診断 #6)。
Write-Step "10.4/11 初期設定の材料を配置"
# >>> SOLOPTILINK-ONBOARDING-ASSETS-BEGIN
$oaPrevEAP = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$oaOk = 0; $oaNg = 0
if ([string]::IsNullOrWhiteSpace($env:USERPROFILE)) {
    Write-Warn "  お客様のフォルダの場所が特定できないため、この項目は次回に回します。"
} else {
    try {
        $oaAssetDir = Join-Path $env:USERPROFILE ".soloptilink\launcher\assets"
        if (-not (Test-Path $oaAssetDir)) { New-Item -ItemType Directory -Force -Path $oaAssetDir | Out-Null }
        # ★修正E (2026-09-03): 探す場所が実際の置き場所と違っていた。
        #   配布物の中でこの4ファイルは launcher\assets にあり、
        #   installer\assets はそもそも存在しない。旧版は installer\assets だけを
        #   見ていたため、どの端末でも必ず 4 件とも「配置できませんでした」となり、
        #   しかも案内文が「もう一度実行してください」だったため、何度実行しても
        #   表示が変わらなかった。実測 (2026-09-03 Windows 実機): 4 件中 4 件失敗。
        #   なお STEP 4 が配布物一式を ~\.soloptilink へ複製するため、この時点で
        #   宛先に既に置かれていることが普通である。その場合も成功として数える。
        foreach ($oaName in @("customer-claude-md.md", "model-policy.json", "onboarding-starter.txt", "onboarding-wait.txt")) {
            $oaDst = Join-Path $oaAssetDir $oaName
            $oaSrc = $null
            foreach ($oaCand in @(
                (Join-Path $PkgRoot "launcher\assets\$oaName"),
                (Join-Path $PSScriptRoot "assets\$oaName")
            )) {
                if (Test-Path $oaCand) {
                    # 宛先そのものを複製しようとすると失敗するため、同一ファイルは除く
                    $oaSame = $false
                    if (Test-Path $oaDst) {
                        try { $oaSame = ((Resolve-Path $oaCand).Path -ieq (Resolve-Path $oaDst).Path) } catch { $oaSame = $false }
                    }
                    if (-not $oaSame) { $oaSrc = $oaCand; break }
                }
            }
            if ($oaSrc) {
                Copy-Item -Path $oaSrc -Destination $oaDst -Force
                $oaOk++
            } elseif (Test-Path $oaDst) {
                $oaOk++
            } else {
                $oaNg++
            }
        }
    } catch {
        Write-DetailToLog ("onboarding-assets failed: {0}" -f $_.Exception.Message)
        $oaNg++
    }
}
$ErrorActionPreference = $oaPrevEAP
if ($oaOk -gt 0) { Write-Ok "  初期設定の材料を配置しました ($oaOk 件)" }
if ($oaNg -gt 0) {
    Write-Warn "  $oaNg 件は配置できませんでした (ご利用は始められます)。"
    Write-Host "     この表示が出た場合は、この画面を添えて nomura.y@soloptilink.com までご連絡ください (再実行では解消しません)。" -ForegroundColor DarkGray
}
# <<< SOLOPTILINK-ONBOARDING-ASSETS-END

Write-Step "10.5/11 品質・信頼性フックを登録"
$migBash = $null
$bashCmd = Get-Command bash -ErrorAction SilentlyContinue
if ($bashCmd) { $migBash = $bashCmd.Source }
if (-not $migBash) {
    foreach ($cand in @("$env:ProgramFiles\Git\bin\bash.exe", "${env:ProgramFiles(x86)}\Git\bin\bash.exe", "$env:LOCALAPPDATA\Programs\Git\bin\bash.exe")) {
        if ($cand -and (Test-Path $cand)) { $migBash = $cand; break }
    }
}
# 【P3 是正 (第2波) 2026-08-17】設定用スクリプトの置き場所は 2 か所ある
# ------------------------------------------------------------
# 何が起きていたか:
#   設定用スクリプトは migration\ と lib\migration\ の 2 か所に分かれて同梱されて
#   いるが、Windows 導入経路は前者しか走査していなかった。そのため Windows の
#   お客様は「本番モードの封緘」と「常駐チェック機能の登録」の 2 件が一度も
#   適用されない。入口 (Mac / Windows / Linux) の 3 つで端末の状態が食い違う。
# どう直したか:
#   両方の置き場所を走査する。走査条件は 3 つの入口で v*.sh に統一する
#   (自己実証用のテストスクリプトを「設定」として実行・計上しないため)。
#   適用できた件数と適用できなかった件数を両方とも表示し、成功したことにしない。
if (-not $migBash) {
    Write-Warn "  この時点では実行環境が揃っていないため、次回 Claude Code 起動時に自動で有効化します。"
} else {
    $migCount = 0
    $migNg = 0
    # >>> SOLOPTILINK-MIGRATION-SCAN-BEGIN
    #   ★ここから END までが「設定用スクリプトの走査条件」の正体。
    #     3 つの入口 (Mac / Windows / Linux) で同じ条件になっているかを、
    #     常設検査 L233-INSTALL-ENTRY-PARITY がこの区間だけを実際に走らせて確かめる。
    #     区間の外へ条件を書くと、入口ごとの食い違いが再発しても検査に映らない。
    $migDirs = @(
        (Join-Path $env:USERPROFILE ".soloptilink\migration"),
        (Join-Path $env:USERPROFILE ".soloptilink\lib\migration")
    )
    foreach ($migDir in $migDirs) {
        if (-not (Test-Path $migDir)) { continue }
        foreach ($m in (Get-ChildItem -Path $migDir -Filter "v*.sh" -File -ErrorAction SilentlyContinue)) {
            $prevEAP3 = $ErrorActionPreference
            $ErrorActionPreference = 'Continue'
            $migRc = 1
            try { & $migBash $m.FullName 2>&1 | Out-Null; $migRc = $LASTEXITCODE } catch { $migRc = 1 }
            $ErrorActionPreference = $prevEAP3
            if ($migRc -eq 0) { $migCount++ } else { $migNg++ }
        }
    }
    # <<< SOLOPTILINK-MIGRATION-SCAN-END
    if (($migCount + $migNg) -eq 0) {
        Write-Host "  追加で有効化する項目はありませんでした。" -ForegroundColor DarkGray
    } else {
        Write-Ok "  品質・信頼性の自動チェックを有効化しました ($migCount 項目)"
        if ($migNg -gt 0) {
            Write-Warn "  $migNg 件は適用できませんでした (ご利用は始められます)。"
            Write-Host "     次にしていただくこと: このセットアップをもう一度実行してください。それでも同じ表示が続く場合は、この画面を添えて nomura.y@soloptilink.com までご連絡ください。" -ForegroundColor DarkGray
        }
    }
}

# -----------------------------------------------------------------------------
# スキル自動連動の登録 (R4-09 / 2026-09-16 新設)
# -----------------------------------------------------------------------------
# 【塞ぐ穴】お客様が 1 文お書きになるたびに適した機能を選ぶ「振り分け」は、端末側の
#   設定 (~\.claude\settings.json の UserPromptSubmit) に登録されてはじめて走る。
#   2026-09-16 に呼び出し件数を数えたところ、登録する道具 lib/sar-linkage/wire-sar-hook.sh
#   を呼んでいたのは Linux の setup.sh だけで、**この Windows 経路と Mac のダブルクリック
#   経路は 0 件**だった。つまり Windows のお客様には自動連動が一度も届いていない。
#   3 経路 (Mac / Windows / Linux) で端末の状態をそろえる。
# 【二重化】migration\v2056.9_sar_gate_wire.sh も同じ登録を行う (上の走査で実行される)。
#   どちらが先でも結果は同じ (登録済みなら何もしない)。
# 【壊さない】設定が JSON として読めないときは、道具の側が書き換えずに止まる。
# 【止めない】登録できなくても導入は続ける。ただし黙らない。
# kill-switch: SOLOPTILINK_SAR_WIRE=off (既定 on)
# >>> SOLOPTILINK-SAR-WIRE-BEGIN
#   ★ここから END までが「振り分けを登録する工程」の正体。3 つの入口で同じ工程を
#     持ち、検査はこの区間だけを実際に走らせて確かめる。
$sarWire = Join-Path $env:USERPROFILE ".soloptilink\lib\sar-linkage\wire-sar-hook.sh"
if ($env:SOLOPTILINK_SAR_WIRE -eq 'off') {
    Write-Host "  ご用件に合う機能を自動で選ぶ設定は、設定で切られているため登録しませんでした。" -ForegroundColor DarkGray
} elseif (-not $migBash) {
    Write-Warn "  ご用件に合う機能を自動で選ぶ設定は、次回 Claude Code 起動時に自動で有効化します。"
} elseif (-not (Test-Path -LiteralPath $sarWire)) {
    Write-Warn "  自動連動の部品が見つかりませんでした (ご利用は始められます)。"
    Write-Host "     次にしていただくこと: この画面を添えて nomura.y@soloptilink.com までご連絡ください。" -ForegroundColor DarkGray
} else {
    $sarPrevEAP = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    $sarOut = ''
    try { $sarOut = (& $migBash $sarWire apply 2>&1 | Out-String) } catch { $sarOut = $_.Exception.Message }
    $sarOk = $false
    try { & $migBash $sarWire check 2>&1 | Out-Null; $sarOk = ($LASTEXITCODE -eq 0) } catch { $sarOk = $false }
    if ($sarOk) {
        Write-Ok "  ご用件に合う機能を自動で選ぶ設定を登録しました"
        $sarMf = 0
        try {
            $sarMfOut = ((& $migBash $sarWire manifest 2>&1 | Out-String) -replace '[^0-9]', '')
            if ($sarMfOut -ne '') { $sarMf = [int]$sarMfOut }
        } catch { $sarMf = 0 }
        if ($sarMf -ge 2) {
            Write-Ok "  導入台帳へ記録しました ($sarMf 件。ご解約時にこの2件も取り除かれます)"
        } else {
            Write-Warn "  登録はできましたが、導入台帳へは記録できませんでした。"
            Write-Host "     次にしていただくこと: このセットアップをもう一度実行してください。" -ForegroundColor DarkGray
        }
    } elseif ($sarOut -match '退去済み') {
        Write-Host "  ご解約済みの端末のため、自動連動の登録は行いませんでした。" -ForegroundColor DarkGray
    } elseif ($sarOut -match '読めない') {
        # ★お客様の設定は書き換えていない。何をすればよいかまで書く
        Write-Warn "  設定ファイル (~\.claude\settings.json) を読み取れないため、登録を見送りました。"
        Write-Host "     お客様の設定は一切書き換えていません。" -ForegroundColor DarkGray
        Write-Host "     次にしていただくこと: 設定ファイルの書式をご確認いただくか、この画面を添えて nomura.y@soloptilink.com までご連絡ください。" -ForegroundColor DarkGray
    } else {
        Write-Warn "  自動連動の設定を登録できませんでした (ご利用は始められます)。"
        Write-Host "     次にしていただくこと: このセットアップをもう一度実行してください。" -ForegroundColor DarkGray
    }
    $ErrorActionPreference = $sarPrevEAP
}
# <<< SOLOPTILINK-SAR-WIRE-END
# 試用端末の登録命令全体を関所で覆う。有料端末の設定は変更しない。
$trialHookWire = Join-Path $env:USERPROFILE ".soloptilink\lib\free-trial\wire-runtime-hooks.sh"
if ($migBash -and (Test-Path -LiteralPath $trialHookWire)) {
    try { & $migBash $trialHookWire 2>&1 | Out-Null } catch { }
}


# -----------------------------------------------------------------------------
# -----------------------------------------------------------------------------
# STEP 10.6: 接続の安定化
# -----------------------------------------------------------------------------
# 企業ネットワークの内側では、ご利用に不要な通信 (利用統計の送信・エラー報告・
#   自動更新の裏側通信) がセキュリティ機器に遮断されることがあり、その待ち時間で
#   起動が止まる。導入時にこれらを止めておけば、企業ネットワークでも初回から動く。
#   ★ご利用に必要な通信は一切止めない。既存の設定も壊さない (env へ追記のみ)。
Write-Step "10.6/11 接続を安定化"
# >>> SOLOPTILINK-NETWORK-STABILIZE-BEGIN
# ★2026-10-29: 足し方と記録の仕方は移行の台本 v2056.3 と同じ決まり (撤去の 2 巡目の審査の依頼 3)。
#   ・3 つの名前のうち設定に無いものだけを "1" で足す。お客様が既に設定していた名前は値を変えない
#     (以前はここで 3 つとも "1" で上書きしていた)
#   ・当社が足した名前だけを ~\.claude\.soloptilink-settings-added.json に記録する
#     (ご解約のときの撤去は、この記録にある名前だけを外す)。既に記録がある名前はその記録を残し、
#     読めない記録は新しく足した分だけで作り直す。新しい版 (version が 2 以上) の記録は書き換えない
#   ・設定を書いたあとに記録を書く
# 戻り値: 'ok' / 'failed' / 'skipped-newer'
function Write-SlSettingsAddedRecord {
    param([string]$Path, [string[]]$Names, [string]$By)
    $at = [DateTime]::UtcNow.ToString("yyyy-MM-dd'T'HH:mm:ss'Z'", [System.Globalization.CultureInfo]::InvariantCulture)
    $before = $null
    $rec = $null
    if (Test-Path -LiteralPath $Path) {
        try {
            $before = Get-Item -LiteralPath $Path -Force -ErrorAction Stop
            # 当社の記録はリンクをたどらない (たどると別のファイルを記録の中身で上書きしかねない)
            if ($before.PSIsContainer -or ($before.Attributes -band [System.IO.FileAttributes]::ReparsePoint)) { return 'failed' }
            $rec = [System.IO.File]::ReadAllText($Path, (New-Object System.Text.UTF8Encoding($false))) | ConvertFrom-Json -ErrorAction Stop
        } catch {
            $rec = $null
        }
        $recVersion = $null
        if ($rec -is [System.Management.Automation.PSCustomObject] -and (Test-HasProperty $rec 'version')) { $recVersion = $rec.version }
        $recIsInt = ($recVersion -is [int]) -or ($recVersion -is [long])
        if ($recIsInt -and $recVersion -gt 1) { return 'skipped-newer' }
        if (-not ($recIsInt -and $recVersion -eq 1 -and (Test-HasProperty $rec 'env') -and ($rec.env -is [System.Management.Automation.PSCustomObject]))) {
            $rec = $null
        }
    }
    if ($null -eq $rec) { $rec = [PSCustomObject]@{ version = 1; env = (New-Object psobject) } }
    foreach ($n in $Names) {
        if (-not (Test-HasProperty $rec.env $n)) {
            $rec.env | Add-Member -MemberType NoteProperty -Name $n -Value ([PSCustomObject][ordered]@{ value = '1'; by = $By; at = $at })
        }
    }
    $json = (ConvertTo-Json -InputObject $rec -Depth 10) + "`n"
    if (-not (Write-SlSettingsSafely -Path $Path -Json $json -Before $before)) { return 'failed' }
    if ([System.Environment]::OSVersion.Platform -eq [System.PlatformID]::Unix) {
        try { [System.IO.File]::SetUnixFileMode($Path, [System.IO.UnixFileMode]'UserRead, UserWrite') } catch { return 'failed' }
    }
    return 'ok'
}
$nsPrevEAP = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
try {
    $nsSettings = Join-Path (Join-Path $env:USERPROFILE ".claude") "settings.json"
    $nsRecord = Join-Path (Join-Path $env:USERPROFILE ".claude") ".soloptilink-settings-added.json"
    # ★2026-10-28: 書き換える前の全文の控え (settings.json.bak-netstab) は作らない。控えにはお客様の
    #   環境変数や許可の設定がそのまま写り、消す処理がどこにも無いまま残り続けていた。
    #   読めない・想定外の形の設定は書き換えず、共通の書き込み関数で読み直して確かめてから置き換える。
    $nsCfg = $null
    $nsBefore = $null
    if (Test-Path $nsSettings) {
        $nsBefore = Get-Item -LiteralPath $nsSettings -Force -ErrorAction Stop
        $nsRaw = [System.IO.File]::ReadAllText($nsSettings, (New-Object System.Text.UTF8Encoding($false)))
        if (-not [string]::IsNullOrWhiteSpace($nsRaw)) { $nsCfg = $nsRaw | ConvertFrom-Json }
        if ($null -ne $nsCfg -and -not ($nsCfg -is [System.Management.Automation.PSCustomObject])) { throw '設定が想定外の形' }
    }
    if ($null -eq $nsCfg) { $nsCfg = New-Object psobject }
    if (-not (Test-HasProperty $nsCfg 'env')) {
        $nsCfg | Add-Member -MemberType NoteProperty -Name 'env' -Value (New-Object psobject)
    } elseif ($null -eq $nsCfg.env) {
        $nsCfg.env = New-Object psobject
    } elseif (-not ($nsCfg.env -is [System.Management.Automation.PSCustomObject])) {
        throw 'env が想定外の形'
    }
    $nsNames = @('CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC', 'DISABLE_TELEMETRY', 'DISABLE_ERROR_REPORTING')
    # お客様が既に設定していた名前は値を変えない (足すのは設定に無いものだけ)
    $nsAdded = @($nsNames | Where-Object { -not (Test-HasProperty $nsCfg.env $_) })
    if ($nsAdded.Count -gt 0) {
        foreach ($nsK in $nsAdded) { $nsCfg.env | Add-Member -MemberType NoteProperty -Name $nsK -Value '1' }
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $nsSettings) | Out-Null
        # Out-File -Encoding UTF8 は Windows PowerShell 5.1 で BOM 付きになり、設定が読めなくなる
        # 恐れがあるため、BOM なしで書く (既存の読み手を壊さない。Write-SlSettingsSafely は BOM なしで書く)
        if (-not (Write-SlSettingsSafely -Path $nsSettings -Json (($nsCfg | ConvertTo-Json -Depth 20) + "`n") -Before $nsBefore)) {
            throw '置き換えを見送った (別の処理が書いていた・書けなかった)'
        }
        # 設定を書いたあとに、当社が足した名前だけを記録する
        $nsRecordState = Write-SlSettingsAddedRecord -Path $nsRecord -Names $nsAdded -By 'installer-windows'
        Write-DetailToLog ("network-stabilize: added={0} record={1}" -f ($nsAdded -join ','), $nsRecordState)
    }
    # 入れたつもりで終わらせない: 読み直して、3 つの名前がすべて設定にあることを確かめる
    $nsVerify = [System.IO.File]::ReadAllText($nsSettings, (New-Object System.Text.UTF8Encoding($false))) | ConvertFrom-Json
    $nsMissing = @($nsNames | Where-Object { -not (Test-HasProperty $nsVerify.env $_) })
    if ($nsMissing.Count -eq 0) { Write-Ok "  接続を安定化しました (社内ネットワークでも動作します。既に設定されていた項目は変えていません)" }
    else { Write-Warn "  接続の安定化を適用できませんでした (ご利用は始められます)" }
} catch {
    Write-Warn "  接続の安定化を適用できませんでした (ご利用は始められます)"
}
# ご利用確認の接続先を供給する (未設定の端末のみ・既存の指定は尊重)
try {
    $nsUrlFile = [IO.Path]::Combine($env:USERPROFILE, ".soloptilink", ".license", ".server_url")
    if (-not (Test-Path $nsUrlFile)) {
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $nsUrlFile) | Out-Null
        [IO.File]::WriteAllText($nsUrlFile, "https://admin-dashboard-blue-alpha-78.vercel.app`n", (New-Object System.Text.UTF8Encoding($false)))
    }
} catch { }
# 通信の確認: 通らない場合はここで気づけるようにする (導入後に詰まらせない)
try {
    $nsReach = Test-NetConnection -ComputerName "api.anthropic.com" -Port 443 -WarningAction SilentlyContinue -InformationLevel Quiet
    if ($nsReach) {
        Write-Ok "  通信の確認: 問題ありません"
    } else {
        Write-Warn "  通信の確認: 外部への通信が届いていません"
        Write-Host "     社内ネットワークの設定により通信が遮断されている可能性があります。" -ForegroundColor DarkGray
        Write-Host "     次にしていただくこと: この画面を添えて nomura.y@soloptilink.com までご連絡ください。" -ForegroundColor DarkGray
        Write-Host "     許可が必要な通信先の一覧をお送りし、こちらで対応いたします。" -ForegroundColor DarkGray
    }
} catch {
    Write-Host "  通信の確認: この時点では確認できませんでした (ご利用は始められます)" -ForegroundColor DarkGray
}
$ErrorActionPreference = $nsPrevEAP
# <<< SOLOPTILINK-NETWORK-STABILIZE-END

# STEP 11: 前提ソフト (Git / Node.js / Claude Code) の確認と導入 — 必ず最後に実行する
#   【順序の設計意図 — この順でないと導入が途中で止まる】
#   旧実装はこの前提ソフト導入を本体配置より前 (STEP 1.5) に実行しており、
#   winget が固まる・ウィンドウが閉じられる等で死ぬと SoloptiLink 本体が
#   1 ファイルも配置されないまま導入失敗になっていた (実事案: Git 導入中に
#   トランスクリプトが途絶し ~/.soloptilink が空のまま)。
#   本体配置・端末認証・MCP 登録・自動更新フックはいずれも Git/Node に依存
#   しないため、先に本体導入を完遂し、前提ソフトは最後に看視付きで導入する。
#   各ソフトは「先に検出し、在ればスキップ」する冪等設計 (再実行しても無害)。
#     - Git for Windows : SoloptiLink の bash 製 lib / chain.sh の動作に必要
#     - Node.js (LTS)   : 生成される業務システムの実行・ビルド検証に必要 (Claude Code 自体は Node 不要)
#     - Claude Code     : 公式ネイティブインストーラで導入 (背景で自動更新)
#   途中で失敗しても終了せず、最後に「要対応一覧」へ集約する。
# -----------------------------------------------------------------------------
Write-Step "11/11 前提ソフト (Git / Node.js / Claude Code) を確認・導入" `
    'SoloptiLinkAI 本体の導入はすでに終わっています。画面に出ている【要対応】を解消してから、このファイルをもう一度実行してください。'
Write-Host "  ※ SoloptiLinkAI 本体の導入・端末認証はすでに完了しています。" -ForegroundColor DarkGray
Write-Host "  ※ ここから先は補助ソフトの導入です。数分かかることがありますが、" -ForegroundColor DarkGray
Write-Host "     このウィンドウを閉じずにお待ちください (各ソフト最大10分で自動的に次へ進みます)。" -ForegroundColor DarkGray

# winget (アプリ インストーラー) の有無 = 前提ソフト導入の主手段
$script:HasWinget = Test-CommandExists 'winget'
if ($script:HasWinget) { Write-Ok "  winget (アプリ インストーラー) 検出" }
else { Write-Warn "  winget が見つかりません。前提ソフトの自動導入が制限されます (要対応に集約します)。" }

# 管理者権限の状況を通知 (昇格は強制しない = UAC 摩擦を最小化)。ソフト導入時に winget/MSI が
# 個別に昇格を求めることがあるため、その際の操作を事前に案内する。
try {
    $IsAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    if (-not $IsAdmin) {
        Write-Warn "  一般ユーザーで実行中です。ソフト導入時に管理者の許可 (UAC) を求められたら「はい」を選んでください。企業管理 PC では IT 部門の協力が必要な場合があります。"
    }
} catch { }

# 失敗してもセットアップ全体を止めないため、このフェーズ中は継続モードにする
$prereqEAP = $ErrorActionPreference
$ErrorActionPreference = 'Continue'

# --- Git for Windows ---
if (Test-CommandExists 'git') {
    Write-Skip ("Git ({0})" -f (& git --version 2>&1 | Select-Object -First 1))
} else {
    Write-Host "  Git: 未導入 → 導入します"
    Install-ViaWinget 'Git.Git' 'Git for Windows' 'git' 'https://git-scm.com/download/win' | Out-Null
}

# --- Node.js (LTS / v18 以上) ---
$needNode = $true
if (Test-CommandExists 'node') {
    $nodeVer = (& node -v 2>&1 | Select-Object -First 1)
    $nodeMajor = 0
    if ($nodeVer -match '^v(\d+)\.') { $nodeMajor = [int]$matches[1] }
    if ($nodeMajor -ge 18) {
        Write-Skip ("Node.js ({0})" -f $nodeVer)
        $needNode = $false
    } else {
        Write-Warn ("  Node.js ({0}) は古いため最新 LTS へ更新します (必要: v18 以上)" -f $nodeVer)
    }
} else {
    Write-Host "  Node.js: 未導入 → 導入します"
}
if ($needNode) {
    # ② winget 経路 (既存)。ここは二重実装しない = 判定順4の②はこの1行だけが担当する。
    Install-ViaWinget 'OpenJS.NodeJS.LTS' 'Node.js (LTS)' 'node' 'https://nodejs.org/en/download' | Out-Null

    # ③ winget 不在 / winget 失敗 → 公式 zip をユーザー領域へ展開 (T-017b / 2026-08-10)
    #   【何が壊れていたか】ここは winget の 1 行だけで、同梱している
    #     installer\lib\node-provision.ps1 (Invoke-NodeProvision) を一度も呼んでいなかった。
    #     モジュール冒頭には「あるべき結線 3 行」が使用例として書かれているのに、その 3 行が
    #     本体のどこにも存在しない状態 = 呼出元ゼロの死配線だった。
    #     winget はストアが使えない企業管理 PC・ソース無効化ポリシー・プロキシ遮断で普通に失敗する。
    #     その先に受け皿が無いと、顧客は公式インストーラの管理者権限入力へ誘導されて手が止まる。
    #   【契約】管理者権限 (UAC) を要求しない。展開先は %USERPROFILE%\.soloptilink\runtime\node。
    #     失敗しても導入全体は止めず、要対応一覧へ集約する。
    if (-not (Test-CommandExists 'node')) {
        $npModule = Join-Path $PSScriptRoot 'lib\node-provision.ps1'
        if (Test-Path $npModule) {
            Write-Host '  Node.js: 公式の配布物から用意します (管理者権限の確認画面は出ません)'
            try {
                . $npModule
                $npResult = Invoke-NodeProvision -Mode ensure
                Save-NodeProvisionResult -Result $npResult
                # 当社の起動経路にのみ PATH を前置き (ユーザーの環境変数は変更しない)
                if ($npResult.env_file -and (Test-Path $npResult.env_file)) {
                    . $npResult.env_file
                }
                if ($npResult.verdict -eq 'PASS') {
                    Write-Ok ('  Node.js 導入完了 (' + $npResult.node_version + ')')
                    # winget 経路が積んだ「Node.js (LTS)」の要対応は解消済みなので取り下げる
                    # (直っている項目を要対応に残すと、顧客が不要な作業をしてしまう)
                    $script:Issues = @($script:Issues | Where-Object { $_.Item -ne 'Node.js (LTS)' })
                } else {
                    Write-Warn '  Node.js を自動で用意できませんでした (要対応一覧に集約します)'
                    Add-Issue 'Node.js' $npResult.reason $npResult.issue_ja
                }
            } catch {
                Write-DetailToLog ("node-provision-failure message={0}" -f $_.Exception.Message)
                Write-Err "  Node.js の自動導入を完了できませんでした"
                Add-Issue 'Node.js' '自動導入の途中で想定外の問題が発生しました' 'https://nodejs.org/ja から LTS 版を導入したうえで、このセットアップをもう一度実行してください。解消しない場合は nomura.y@soloptilink.com へご連絡ください。'
            }
        } else {
            Write-Warn '  Node.js: 自動導入に必要な部品が見つかりません'
            Add-Issue 'Node.js' '自動導入に必要な部品が配布物の中に見当たりません' 'ZIP をもう一度展開し直してからセットアップを実行してください。解消しない場合は nomura.y@soloptilink.com へご連絡ください。'
        }
    }
}

# --- Claude Code (公式ネイティブインストーラ = 背景で自動更新) ---
if (Test-CommandExists 'claude') {
    Write-Skip ("Claude Code ({0})" -f (& claude --version 2>&1 | Select-Object -First 1))
    # 導入済みでも、この画面でだけ見えている (PATH が恒久登録されていない) 場合があるため登録する
    $null = Register-ClaudeUserPath
} else {
    Write-Host "  Claude Code: 未導入 → 導入します (公式ネイティブインストーラ / 自動更新あり)"
    # iex が exit を呼んでも本インストーラを巻き込まないよう、子 PowerShell で実行する。
    # ハング対策: 看視付き (Invoke-WithTimeout)。固まっても最大10分で次へ進む。
    # 注: PS 5.1 の Start-Process は配列引数を引用符なしで空白結合するため、
    #     空白を含む -Command は単一文字列で渡す (二重引用符を明示)。
    $claudeCode = Invoke-WithTimeout 'powershell' '-NoProfile -ExecutionPolicy Bypass -Command "irm https://claude.ai/install.ps1 | iex"' 600 'Claude Code (公式インストーラ)'
    if ($null -eq $claudeCode) { $claudeCode = -1 }
    Update-SessionPath
    # ネイティブで入らなければ winget 版へフォールバック (自動更新は環境変数で補う)
    if (-not (Test-CommandExists 'claude') -and $script:HasWinget) {
        Write-Warn "  winget 経由での導入に切り替えます"
        try {
            [Environment]::SetEnvironmentVariable('CLAUDE_CODE_PACKAGE_MANAGER_AUTO_UPDATE', '1', 'User')
            $claudeCode = Invoke-WithTimeout 'winget' @('install','--id','Anthropic.ClaudeCode','-e','--source','winget','--accept-source-agreements','--accept-package-agreements','--silent') 600 'Claude Code (winget)'
            if ($null -eq $claudeCode) { $claudeCode = -1 }
        } catch {
            Write-DetailToLog ("winget-install-failure message={0}" -f $_.Exception.Message)
            Write-Err "  別の方法でも導入を完了できませんでした"
            $claudeCode = -1
        }
        Update-SessionPath
    }
    # 別の画面からも claude が見つかるよう、利用者の PATH へ恒久登録する (見つかる場合のみ)
    $null = Register-ClaudeUserPath
    Update-SessionPath
    if (Test-CommandExists 'claude') {
        Write-Ok "  Claude Code 導入完了"
    } elseif ($claudeCode -eq 0 -or $claudeCode -eq -1978335189) {
        # 導入は成功した形跡 → PATH 未反映 (公式インストーラがレジストリ PATH を更新しない既知事象 #21365 を含む。再起動で直る)
        Write-Warn "  Claude Code を導入しましたが、このセッションでは確認できませんでした (PC 再起動後に反映)"
        # ★2026-08-10 是正: 「新しいウィンドウで claude --version を実行」は
        #   打ち込む場所の説明が無く行き止まりだった。画面操作だけの確認方法に変える。
        Add-Issue 'Claude Code' '導入は成功しましたが、反映に PC の再起動が必要な可能性があります' 'PC を再起動したあと、このファイルをもう一度実行してください。それでも変わらない場合は、この画面の写真を nomura.y@soloptilink.com へお送りください。'
    } else {
        # 導入そのものが失敗 → ネットワーク / プロキシ / SmartScreen / オフライン
        Write-DetailToLog ("claude-install-exit code={0}" -f $claudeCode)
        Write-Err "  Claude Code の自動導入に失敗しました"
        Add-Issue 'Claude Code' "自動導入に失敗しました。配信元への接続不可 (社内のネットワーク制限)、Windows の実行ブロック、またはインターネットに繋がっていないことが考えられます" 'ネットワーク管理者に claude.ai および Anthropic 配信ドメインの許可を依頼してください。SmartScreen の警告画面でブロックされた場合は「詳細情報」→「実行」を選択するか、IT 部門に実行許可を依頼してください。オフライン環境では、別のオンライン端末で導入した Claude Code を持ち込むか、サポートへご連絡ください。'
    }
}

# --- Python 3 (T-702 / 2026-08-10 新設) ---
#   【なぜ足したか / 実測】生成物の品質点検は 138 本中 107 本が python3 を呼ぶ。
#     つまり導入の前提なのに、お客様向けの手順書 7 本すべてに記載が 0 件で、
#     前提ソフトの確認対象にも入っていなかった (実測 2026-08-10)。
#     python3 が無いまま点検を走らせると、判定が全て「-」になり合否を出せなくなることを
#     実走で確認した (Mac ではさらに設定登録の段階で導入が止まる)。
#   ★Windows には python3.exe という「ストアへ誘導するだけの入口」が既定で置かれている。
#     コマンドがあることだけを見ると入っている扱いになるため、版の表示まで確かめる。
# ★2026-09-02 是正 (T-702b): 呼び名を python3 に決め打っていたため、Python を導入済みの
#   PC でも「無い」と判定して要対応を 1 件立て、ほかが全て問題なく終わっても
#   「セットアップは一部が未完了です」と表示していた。判定は Resolve-Python に 1 本化した。
#
# ★2026-09-02 方針変更 (T-702e): ここは従来「自動導入はしない」と決めていた。理由は
#   「Windows の Python は Microsoft Store 経由が主で、無人導入は同意画面とストアの
#   サインインを伴い、途中で止まる危険が高い」というものだった。これは実態と合っていない。
#   winget の Python.Python.3.x が引くのは Store ではなく python.org の公式インストーラで、
#   すぐ上の Git / Node.js / Claude Code とまったく同じ無人導入が効く。
#   方針を据え置いた結果、「Python が 1 つも入っていない PC」では他が全て問題なく
#   終わっても要対応が必ず 1 件残り、「セットアップは一部が未完了です」と出続けていた。
#   呼び名の決め打ち (T-702b) を直してもこの経路は残るため、ここで自動導入に切り替える。
#
#   【安全側の設計 — 悪くなる経路を作らない】
#     ・自動導入に失敗した場合の表示と要対応は従来とまったく同じ。増えるのは成功経路だけ。
#     ・入っているかどうかの最終判定は必ず Resolve-Python に通す。winget の戻り値や
#       python.exe の有無だけで「入った」と決めない (Store 誘導専用の python.exe が
#       置かれた PC で誤判定するため)。
#     ・要対応は 1 件を超えて積まない (自動導入で立てた要対応と、この下の判定とで
#       二重計上しない)。
$pyOk = Resolve-Python
$pyIssueRaised = $false
$pyInstalledNow = $false
$pyManualHelp = 'https://www.python.org/downloads/windows/ から導入し、導入時に「Add python.exe to PATH」にチェックを入れてください。社内の決まりで難しい場合は Microsoft Store で「Python 3」を検索して導入する方法でも構いません（無料トライアルをお使いの場合は、Microsoft Store 版では試用を始められないため、python.org の版を導入してください）。'
if (-not $pyOk) {
    $pyPkgId = 'Python.Python.3.12'
    if ($script:HasWinget) {
        Write-Host "  Python 3 を導入中... (winget: $pyPkgId)"
        $pyEAP = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        $pyCode = Invoke-WithTimeout 'winget' @('install','--id',$pyPkgId,'-e','--source','winget','--accept-source-agreements','--accept-package-agreements','--silent') 600 'Python 3'
        if ($null -eq $pyCode) { $pyCode = -1 }
        $ErrorActionPreference = $pyEAP
        Update-SessionPath
        $pyOk = Resolve-Python
        if ($pyOk) {
            $pyInstalledNow = $true
        } else {
            Write-DetailToLog ("winget-exit displayName=Python 3 code={0}" -f $pyCode)
            if ($pyCode -eq 0 -or $pyCode -eq -1978335189) {
                Write-Warn "  Python 3 を導入しましたが、このウィンドウでは確認できませんでした (PC 再起動後に反映)"
                Add-Issue 'Python 3' '導入は成功しましたが、コマンドの通り道への反映に PC の再起動が必要な可能性があります' 'PC を再起動したあと、このセットアップをもう一度実行してください。'
            } else {
                Write-Err "  Python 3 の自動導入に失敗しました"
                Add-Issue 'Python 3' '生成した業務システムの品質点検に Python 3 が必要ですが、自動導入に失敗しました' $pyManualHelp
            }
            $pyIssueRaised = $true
        }
    } else {
        Write-Warn "  Python 3 を自動導入できません (winget 非搭載)"
        Add-Issue 'Python 3' '生成した業務システムの品質点検に Python 3 が必要ですが、この PC には自動導入の仕組み (アプリ インストーラー) がありません' $pyManualHelp
        $pyIssueRaised = $true
    }
}
# 版の文字列は表示にも使うため、確認が行われなかった場合に備えて空で通る形にしておく。
$pyVer = $script:PyVersion
if ($pyOk) {
    if ($pyInstalledNow) { Write-Ok "  Python 3 導入完了 ($pyVer)" }
    else                 { Write-Ok "  Python 3 は導入済みです ($pyVer)" }
} elseif (-not $pyIssueRaised) {
    Write-Warn "  Python 3 が確認できません (品質点検の判定が行えません)"
    Add-Issue 'Python 3' '生成した業務システムの品質点検に Python 3 が必要ですが、この PC では確認できませんでした' $pyManualHelp
}

$ErrorActionPreference = $prereqEAP

# -----------------------------------------------------------------------------
# STEP 11.5: 品質・信頼性フックの再登録 (前提ソフト導入後・2026-09-04 新設)
# -----------------------------------------------------------------------------
# 【何が壊れていたか (2026-09-04 実顧客端末で確認)】
#   STEP 10.5 の登録は bash (Git for Windows) を必要とするのに、その Git を導入するのは
#   後続の STEP 11 だった。順序が逆のため、Git が未導入の端末では初回導入で登録が必ず飛び、
#   直後に走る自己診断が「自動チェック機能の登録」を要対応 (登録済み 7/8) と表示していた。
#   しかも案内は「セットアップをやり直してください」で、2 回目は Git が入っているため通る。
#   つまり「1 回目は必ず失敗し、2 回目で直る」導入になっていた。お客様から見れば
#   初回で必ずつまずく体験であり、やり直す前に諦められた場合は永久に登録されない。
#   → Git を入れ終えたこの位置で、飛んでいた分だけを冪等に再実行する。
#     migration 配下の各スクリプトは自前で冪等なので、二重に走っても害はない。
Write-Step "11.5/11 品質・信頼性フックを再確認 (前提ソフト導入後)"
# >>> SOLOPTILINK-MIGRATION-RETRY-BEGIN
$rtPrevEAP = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
$rtBash = $null
$rtCmd = Get-Command bash -ErrorAction SilentlyContinue
if ($rtCmd) { $rtBash = $rtCmd.Source }
if (-not $rtBash) {
    foreach ($rtC in @("$env:ProgramFiles\Git\bin\bash.exe", "${env:ProgramFiles(x86)}\Git\bin\bash.exe", "$env:LOCALAPPDATA\Programs\Git\bin\bash.exe")) {
        if ($rtC -and (Test-Path $rtC)) { $rtBash = $rtC; break }
    }
}
if (-not $rtBash) {
    Write-Warn "  この PC では品質の自動チェックを有効化できませんでした (ご利用は始められます)。"
    Add-Issue "自動チェック機能の登録" "品質の自動チェックを有効化できませんでした" "PC を再起動したあと、このセットアップをもう一度実行してください。解消しない場合は、この画面を添えてサポート窓口へご連絡ください。"
} else {
    $rtOk = 0
    $rtNg = 0
    foreach ($rtDir in @((Join-Path $env:USERPROFILE ".soloptilink\migration"), (Join-Path $env:USERPROFILE ".soloptilink\lib\migration"))) {
        if (-not (Test-Path $rtDir)) { continue }
        foreach ($rtM in (Get-ChildItem -Path $rtDir -Filter "v*.sh" -File -ErrorAction SilentlyContinue)) {
            $rtRc = 1
            try { & $rtBash $rtM.FullName 2>&1 | Out-Null; $rtRc = $LASTEXITCODE } catch { $rtRc = 1 }
            if ($rtRc -eq 0) { $rtOk++ } else { $rtNg++ }
        }
    }
    $LASTEXITCODE = 0
    if (($rtOk + $rtNg) -eq 0) {
        Write-Host "  追加で有効化する項目はありませんでした。" -ForegroundColor DarkGray
    } elseif ($rtNg -eq 0) {
        Write-Ok ("  品質・信頼性の自動チェックを有効化しました ({0} 項目)" -f $rtOk)
    } else {
        Write-Warn ("  {0} 件は適用できませんでした (ご利用は始められます)。" -f $rtNg)
        Add-Issue "自動チェック機能の登録" ("{0} 件の自動チェックを有効化できませんでした" -f $rtNg) "PC を再起動したあと、このセットアップをもう一度実行してください。解消しない場合は、この画面を添えてサポート窓口へご連絡ください。"
    }
}
$ErrorActionPreference = $rtPrevEAP
# <<< SOLOPTILINK-MIGRATION-RETRY-END

# -----------------------------------------------------------------------------
# 動作確認 (各前提ソフトのバージョンを実測表示)
# -----------------------------------------------------------------------------
Write-Step "動作確認 (バージョン表示)"
$verEAP = $ErrorActionPreference
$ErrorActionPreference = 'Continue'
function Show-Ver($label, $cmd, $verArg) {
    if (Test-CommandExists $cmd) {
        $out = (& $cmd $verArg 2>&1 | Select-Object -First 1)
        Write-Host ("  [ OK ] {0,-12}: {1}" -f $label, $out) -ForegroundColor Green
    } else {
        Write-Host ("  [FAIL] {0,-12}: 確認できません (PC 再起動後に再確認してください)" -f $label) -ForegroundColor Red
    }
}
Show-Ver 'Git'         'git'    '--version'
Show-Ver 'Node.js'     'node'   '-v'
Show-Ver 'npm'         'npm'    '-v'
Show-Ver 'Claude Code' 'claude' '--version'
# ★2026-09-02 是正 (T-702d): Show-Ver は「入口が在るか」しか見ないため、
#   Microsoft Store へ誘導するだけの python3.exe が置かれた PC では、緑の [ OK ] の横に
#   「Python was not found ...」という英文が並ぶ矛盾した表示になっていた。
#   実際に動く呼び名を探してから表示する。
if (Resolve-Python) {
    Write-Host ("  [ OK ] {0,-12}: {1}" -f 'Python 3', $script:PyVersion) -ForegroundColor Green
} else {
    Write-Host ("  [FAIL] {0,-12}: 確認できません (PC 再起動後に再確認してください)" -f 'Python 3') -ForegroundColor Red
}
$ErrorActionPreference = $verEAP

# -----------------------------------------------------------------------------
# 導入自己診断 (AC-I08) — 「最後まで走った」ではなく「診断が通った」を完了とする
# -----------------------------------------------------------------------------
# 【何が壊れていたか (T-017e / 2026-08-10)】installer\self-check.sh は 12 項目の自己診断を
#   実装し配布物にも同梱されているのに、Mac/Windows どちらのインストーラからも
#   呼ばれていなかった (呼出元は社内テストの台帳行と同梱必須リストだけ)。
# 【Windows 固有の限界 = 正直に「未測定」と出す】診断本体は bash と python3 に依存する。
#   Git for Windows の bash があれば実行できるが、python3 が無い PC では診断そのものが
#   実行できない。その場合は「合格」でも「不合格」でもなく【未測定】として表示し、
#   お客様に不要な作業を求めない (未測定を合格として数えない・偽の要対応を作らない)。
# 【契約】fail-open。診断の結果がどうであれ、ここで導入を中断しない。
#   無効化: SOLOPTILINK_SELF_CHECK=off
$selfCheckSh = Join-Path $PSScriptRoot 'self-check.sh'
if (Test-Path $selfCheckSh) {
    Write-Step '導入の自己診断'
    $bashExe = $null
    if (Test-CommandExists 'bash') {
        $bashExe = 'bash'
    } else {
        foreach ($cand in @("$env:ProgramFiles\Git\bin\bash.exe", "${env:ProgramFiles(x86)}\Git\bin\bash.exe", "$env:LOCALAPPDATA\Programs\Git\bin\bash.exe")) {
            if ($cand -and (Test-Path $cand)) { $bashExe = $cand; break }
        }
    }
    if ($null -eq $bashExe) {
        Write-Host '  [未測定] 自己診断を実行できる環境がこの PC にありません (診断は未実施です。合格という意味ではありません)'
        # 2026-09-02 是正: 未測定は「問題なし」ではないのに要対応一覧へ出していなかった。
        #   結果として最後に「一部が未完了です」とだけ出て、お客様が理由を辿れなかった。
        Add-Issue '導入の自己診断' '導入後の確認そのものを実行できませんでした (問題がないと確認できたわけではありません)' 'この画面の写真を撮って nomura.y@soloptilink.com へお送りください。こちらで原因をお調べしてご連絡いたします。'
    } else {
        $scEAP = $ErrorActionPreference
        $ErrorActionPreference = 'Continue'
        # ★2026-09-02 是正 (T-017h): 自己診断へ Windows の場所を渡す。
        #   渡さないと自己診断は mac の置き場所 (~/Library/Application Support/...) を
        #   見に行くため、直前に %APPDATA%\Claude\ へ正しく書き込んだ設定を
        #   「連携できていない」と判定していた。
        $scPrevMcp = $env:SC_MCP_CONFIG
        if ($env:APPDATA) {
            $env:SC_MCP_CONFIG = (Join-Path (Join-Path $env:APPDATA 'Claude') 'claude_desktop_config.json')
        }
        # ★2026-09-03 是正: デスクトップが OneDrive に移されている PC では、
        #   自己診断が「もう一方のデスクトップ」にレポートを書いていた。お客様の画面には
        #   何も現れないのに「デスクトップに保存しました」と案内していた。実際の場所を渡す。
        $scPrevDesk = $env:SC_DESKTOP
        try {
            $scDesk = [Environment]::GetFolderPath('Desktop')
            if ($scDesk -and (Test-Path $scDesk)) { $env:SC_DESKTOP = ($scDesk -replace '\\','/') }
        } catch { }
        # ★2026-09-25: 端末のご登録の区間で確かめた状態 (承認待ちなど) を渡す。
        #   承認待ちの端末には license.json が作られないため、渡さないと × と表示される。
        $scPrevReg = $env:SOLOPTILINK_SETUP_REGISTRATION_STATUS
        $env:SOLOPTILINK_SETUP_REGISTRATION_STATUS = $script:RegSyncStatus
        $scRc = Invoke-WithTimeout $bashExe @($selfCheckSh, 'run') 300 '導入の自己診断'
        $env:SC_MCP_CONFIG = $scPrevMcp
        $env:SC_DESKTOP = $scPrevDesk
        $env:SOLOPTILINK_SETUP_REGISTRATION_STATUS = $scPrevReg
        $ErrorActionPreference = $scEAP
        if ($null -eq $scRc) { $scRc = -1 }
        if ($scRc -eq 0) {
            Write-Ok '  自己診断は問題なく完了しました'
        } elseif ($scRc -eq 1) {
            Write-Warn '  自己診断で確認が必要な項目が見つかりました'
            Add-Issue '導入の自己診断' '診断で確認が必要な項目が見つかりました' '上の診断結果に表示された「お客様がすること」を実施してから、セットアップをもう一度実行してください。'
        } else {
            Write-Host '  [未測定] 自己診断を最後まで実行できませんでした (診断は未実施です。合格という意味ではありません)'
            # 2026-09-02 是正: 同上。ここが最も起きやすい未測定経路であり、
            #   要対応一覧に出さないと「未完了の理由が画面のどこにも無い」状態になる。
            Add-Issue '導入の自己診断' '導入後の確認が途中で終わりました (問題がないと確認できたわけではありません)' 'この画面の写真を撮って nomura.y@soloptilink.com へお送りください。こちらで原因をお調べしてご連絡いたします。'
        }
    }
} else {
    Write-Warn '  自己診断に必要な部品が見つかりません'
    Add-Issue '導入の自己診断' '自己診断に必要な部品が配布物の中に見当たりません' 'ZIP をもう一度展開し直してからセットアップを実行してください。解消しない場合は nomura.y@soloptilink.com へご連絡ください。'
}

# -----------------------------------------------------------------------------
# 利用規約のご確認と「未同意」の記録 (RQ-806 / 2026-09-13 新設)
# -----------------------------------------------------------------------------
# 【なぜ完了画面の直前か】途中に置くと、規約で止まった端末が「半分だけ入った状態」に
#   なる。ここまで来れば配置も登録も済んでいるので、断られても導入は止まらない。
# 【断っても止めない】返事は記録するだけで、要対応の件数にも完了判定にも使わない。
# 【3 経路そろえる】setup.sh / installer-mac / installer-win のどれで入った端末でも
#   同じ形の記録が残ること。1 つ欠けると「未同意」と「見せていない」の区別がつかない。
$termsPs1 = Join-Path (Join-Path (Join-Path $InstallDir 'lib') 'terms') 'terms-consent.ps1'
if (-not (Test-Path -LiteralPath $termsPs1)) {
    $termsPs1 = Join-Path (Join-Path (Join-Path $PSScriptRoot 'lib') 'terms') 'terms-consent.ps1'
}
if (Test-Path -LiteralPath $termsPs1) {
    try {
        . $termsPs1
        Invoke-SlTermsNotice -Channel 'installer-win'
    } catch {
        # 規約のご案内で導入を止めない
        Write-Host " 利用規約のご案内を表示できませんでした (導入は完了しています)"
    }
} else {
    Write-Host ""
    Write-Host " 利用規約のご確認: この配布物には規約のご案内の部品が含まれていないため、表示は行いませんでした"
}

# -----------------------------------------------------------------------------
# Finish
# -----------------------------------------------------------------------------
Write-Host ""
Write-Host "================================================================="
# ★2026-08-15 是正: ここは要対応が残っていても必ず「セットアップ完了」と出していた。
#   「完了」は、この先の作業を安心して始めてよいという合図である。直っていないものが
#   残ったまま同じ合図を出すと、お客様は直ったものと受け取って使い始めてしまう。
#   1 件でも要対応があるなら、完了とは名乗らない。
if (($script:Issues.Count -gt 0) -or (-not $activated)) {
    Write-Host " セットアップは一部が未完了です" -ForegroundColor Yellow
} else {
    Write-Host " セットアップ完了" -ForegroundColor Green
}
Write-Host "================================================================="
Write-Host ""
# 要対応一覧 (前提ソフトで自動完了できなかったもの)
if ($script:Issues.Count -gt 0) {
    Write-Host (" 【要対応】以下は自動で完了できませんでした ({0} 件):" -f $script:Issues.Count) -ForegroundColor Yellow
    $idx = 1
    foreach ($iss in $script:Issues) {
        Write-Host ("   {0}. {1}" -f $idx, $iss.Item) -ForegroundColor Yellow
        Write-Host ("      原因 : {0}" -f $iss.Detail)
        Write-Host ("      対処 : {0}" -f $iss.Remedy)
        $idx++
    }
    Write-Host "   ※ まず上記の【要対応】を解消してから、下の「次のステップ」へお進みください。" -ForegroundColor Yellow
    Write-Host ""
}

Write-Host " 次のステップ:"
Write-Host ""
# ★2026-08-10 是正: 従来は端末登録のやり直しに打ち込むコマンドを 2 行そのまま出し、
#   ログインも「新しいウィンドウで claude と入力」とだけ書いていた。
#   どちらも打ち込む場所の説明がなく、お使いになる方はそこで止まる。
#   画面の操作だけで完結する道順に書き換える。
if (-not $activated) {
    Write-Host "   1. ご登録がまだ完了していません。"
    Write-Host "      このファイルをもう一度実行してください (二重に登録されることはありません)。"
    Write-Host ""
    Write-Host "   2. 弊社での確認が必要な場合は、終わりしだいメールでご連絡します"
    Write-Host ""
    Write-Host "   3. Claude Desktop を起動し、画面の案内にしたがってログインしてください"
    Write-Host "      ※ ご利用には有料の Claude プラン (Pro / Max / Team / Enterprise) または" -ForegroundColor DarkYellow
    Write-Host "        API のご契約が必要です。無料プランでは Claude Code は使えません。" -ForegroundColor DarkYellow
    Write-Host ""
    Write-Host "   4. Claude Desktop の「Code」の画面に切り替え (通常のチャット画面では機能が読み込まれません)、"
    Write-Host "      入力欄に /soloptilink-boost と入力し、続けてお仕事の内容をお伝えください"
} else {
    Write-Host "   1. 弊社での確認が必要な場合は、終わりしだいメールでご連絡します"
    Write-Host ""
    Write-Host "   2. Claude Desktop を起動し、画面の案内にしたがってログインしてください"
    Write-Host "      ※ ご利用には有料の Claude プラン (Pro / Max / Team / Enterprise) または" -ForegroundColor DarkYellow
    Write-Host "        API のご契約が必要です。無料プランでは Claude Code は使えません。" -ForegroundColor DarkYellow
    Write-Host ""
    Write-Host "   3. Claude Desktop の「Code」の画面に切り替え (通常のチャット画面では機能が読み込まれません)、"
    Write-Host "      入力欄に /soloptilink-boost と入力し、続けてお仕事の内容をお伝えください"
}
Write-Host ""
# ★例示とご利用開始の案内は正典 (lib/onboarding-canon.sh) から取り出して表示する
#   (T-703 / T-706 / 2026-08-10)。ここに文面を書き写すと、手順書・同梱案内・
#   ランチャーの案内と必ずどこか 1 箇所だけが古くなる。実測でも、手順書 3 本は
#   「最大で1〜2営業日」、Mac の完了画面は「通常1営業日以内」と食い違っていた。
$obcPath = Join-Path $InstallDir 'lib\onboarding-canon.sh'
$obcBash = Get-Command bash -ErrorAction SilentlyContinue
if ((Test-Path $obcPath) -and $obcBash) {
    foreach ($what in @('starter', 'wait')) {
        try {
            $block = & $obcBash.Source "$obcPath" emit $what 2>$null
            if ($block) { $block | ForEach-Object { Write-Host ("   " + $_) } ; Write-Host "" }
        } catch { }
    }
} else {
    Write-Host "   最初の一言の例と、ご利用開始のタイミングは、同梱の手順書をご覧ください。"
    Write-Host ""
}
Write-Host "   すでに前提ソフトを導入済みの方は、導入工程は自動でスキップされています (再実行しても無害)。" -ForegroundColor DarkGray
if ($script:LogPath) { Write-Host ("   実行ログ: {0}" -f $script:LogPath) -ForegroundColor DarkGray }
Write-Host ""

try { Stop-Transcript | Out-Null } catch { }
End-Pause
exit 0
