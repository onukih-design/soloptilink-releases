#!/bin/bash
# ----------------------------------------------------------------
# (c) 2026 SoloptiLink Inc. - All rights reserved.
# ----------------------------------------------------------------
# 困ったときはこちら.command — ダブルクリックで動く「困ったとき」の入口 (Mac・2026-11-11 新設・T1-061)
#
# 【何をするか】黒い画面に打ち込まずに、次をまとめて行う。
#   1. スラッシュの一覧の診断 (lib/slash-doctor/slash-doctor.sh fix)
#      … 置き場所・説明書きの先頭・Claude Code を調べ、置き直せるものは置き直して 1 回だけ測り直す
#   2. 結果 (総合の判定と、日本語の案内) をこの画面に出す
#   3. 結果を当社へ届ける (report)。届けるのは判定の記号と版だけ (パス・利用者名・メールアドレス・端末名は送らない。
#      送る直前にも機械で調べる)。3 秒で諦める・お客様の「送らない」ご指定を守る
#   4. Enter キーを押すまで画面を閉じない (結果を読めるように)
#
# 【置き場】① 配布物の ZIP の一番上 (「①ここをダブルクリック（導入）.command」と同じ階層)
#           ② 導入の後は本体の置き場の中 (~/.soloptilink/困ったときはこちら.command)
#   どちらに置かれていても動く (導入済みの本体の診断を先に使い、無ければ同じ配布物の中の診断を使う)。
#   ★デスクトップなどには置かない (お客様の環境を広く書き換えないため)。
#
# 【止める】SOLOPTILINK_SLASH_DOCTOR=off (診断) / SOLOPTILINK_SLASH_PROBE=off (Claude Code の起動) /
#           SOLOPTILINK_SLASH_REPORT=off (当社へ送る)。共通の決めごと: lib/slash-doctor/SPEC.md
# ----------------------------------------------------------------
set -u
HERE="$(cd "$(dirname "$0")" 2>/dev/null && pwd)"
SD=""
for c in "$HOME/.soloptilink/lib/slash-doctor/slash-doctor.sh" \
         "$HERE/lib/slash-doctor/slash-doctor.sh" \
         "$HERE/app/lib/slash-doctor/slash-doctor.sh"; do
    if [ -f "$c" ]; then SD="$c"; break; fi
done

echo ""
echo "  ╔══════════════════════════════════════════════════════╗"
echo "  ║   SoloptiLinkAI 困ったときの確認                     ║"
echo "  ║   (1 分ほどかかることがあります。閉じずにお待ちください) ║"
echo "  ╚══════════════════════════════════════════════════════╝"
echo ""
if [ -z "$SD" ]; then
    echo "  確認の道具が見つかりませんでした。"
    echo "  SoloptiLinkAI のセットアップ (①ここをダブルクリック（導入）) をもう一度実行してください。"
    echo "  うまくいかない場合は、この画面の写真を nomura.y@soloptilink.com へお送りください。"
else
    /bin/bash "$SD" fix --entry doctor-cli
    /bin/bash "$SD" report --entry doctor-cli >/dev/null 2>&1 || true
    echo ""
    echo "  うまくいかない場合は、この画面の写真を nomura.y@soloptilink.com へお送りください。"
fi
echo ""
printf '  Enter キーを押すと閉じます...'
read -r _ || true
exit 0
