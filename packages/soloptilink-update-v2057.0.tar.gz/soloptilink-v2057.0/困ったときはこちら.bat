@echo off
setlocal
rem SoloptiLinkAI troubleshooting entry (2026-11-11 / T1-062). Double-click to run.
rem It checks whether /soloptilink-boost appears in the Claude Code slash list, re-places
rem missing parts (installer\slash-doctor.ps1 -Mode fix), shows the result, sends the
rem result codes (no paths, user names, mail addresses or host names; checked again
rem right before sending), and waits for a key so the window does not close.
rem Works from the top of the customer ZIP and from %USERPROFILE%\.soloptilink after setup.
rem PFP-108 invariant: ASCII-only / CRLF / no BOM. Japanese messages come from the .ps1.
rem Stop switches: SOLOPTILINK_SLASH_DOCTOR=off / SOLOPTILINK_SLASH_PROBE=off / SOLOPTILINK_SLASH_REPORT=off
set "SD=%USERPROFILE%\.soloptilink\installer\slash-doctor.ps1"
if not exist "%SD%" set "SD=%~dp0installer\slash-doctor.ps1"
if not exist "%SD%" set "SD=%~dp0app\installer\slash-doctor.ps1"
if not exist "%SD%" (
  echo [SoloptiLinkAI] The check tool was not found. Please run the setup again.
  echo If it does not help, please send a photo of this screen to nomura.y@soloptilink.com
  pause
  exit /b 1
)
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SD%" -Mode fix -Entry doctor-cli
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SD%" -Mode report -Entry doctor-cli -Json >nul 2>&1
echo.
echo If it does not help, please send a photo of this screen to nomura.y@soloptilink.com
pause
exit /b 0
