/**
 * architecture.ts — 1級建築士レベル建築知識DB (Phase 9)
 *
 * Claude Code が絶対に持たない「日本の建築実務に刺さる」知識を
 * コードから import で参照できる静的 DB として凝集する。
 *
 * カバー領域:
 *   1. 建築基準法 (集団規定 / 単体規定 / 構造 / 防火 / 避難 / 日影 / 斜線)
 *   2. 建築士法 (業務範囲 / 一級・二級・木造の扱える規模)
 *   3. 構造設計 (木造 / S造 / RC造 / SRC造 + 壁量計算 / 4号特例)
 *   4. 省エネ基準 (外皮 UA/ηAC / 一次エネルギー消費量)
 *   5. 都市計画法 (用途地域 13種 + 容積率 / 建ぺい率 / 高度地区)
 *   6. 確認申請・完了検査フロー
 *   7. 設備 (給排水・電気・空調・ガス) の日本基準
 *   8. バリアフリー法 / 品確法 / 瑕疵担保 / 住宅瑕疵担保履行法
 *   9. JIS / JAS 規格参照
 *  10. 積算の構造 (仮設 / 土工 / 躯体 / 仕上 / 設備 / 外構 / 共通仮設 / 諸経費)
 *
 * 使い方:
 *   import { getBuildingCode, calcFloorAreaRatio, useDistricts, checkStructureFeasibility } from '@/lib/japan/architecture';
 *
 * 注意: 本 DB は 2024〜2026 年時点の法令を基準とする。
 *       改正がある場合は `effective_until` フィールドで新旧を切り替える運用。
 *       実プロジェクトでは最新の官報・国交省告示を必ず確認すること。
 */

// =============================================================================
// 1. 用途地域 13種 (都市計画法 第8条)
// =============================================================================

export type UseDistrictCode =
  | 'Category1LowRise'        // 第一種低層住居専用地域
  | 'Category2LowRise'        // 第二種低層住居専用地域
  | 'Category1MidHighRise'    // 第一種中高層住居専用地域
  | 'Category2MidHighRise'    // 第二種中高層住居専用地域
  | 'Category1Residential'    // 第一種住居地域
  | 'Category2Residential'    // 第二種住居地域
  | 'QuasiResidential'        // 準住居地域
  | 'RuralResidential'        // 田園住居地域
  | 'Neighborhood'            // 近隣商業地域
  | 'Commercial'              // 商業地域
  | 'QuasiIndustrial'         // 準工業地域
  | 'Industrial'              // 工業地域
  | 'IndustrialExclusive';    // 工業専用地域

export interface UseDistrict {
  code: UseDistrictCode;
  name_ja: string;
  abbr: string;
  /** 建ぺい率の上限範囲(%) */
  buildingCoverageRange: [number, number];
  /** 容積率の上限範囲(%) */
  floorAreaRatioRange: [number, number];
  /** 北側斜線 規制 */
  northernSlopeRestriction: boolean;
  /** 絶対高さ制限 (m) - null の場合は地区による */
  absoluteHeightLimit: number | null;
  /** 日影規制 適用地域 */
  shadowRegulationApplicable: boolean;
  allowedUses: string[];
  prohibitedUses: string[];
}

export const USE_DISTRICTS: Readonly<Record<UseDistrictCode, UseDistrict>> = Object.freeze({
  Category1LowRise: {
    code: 'Category1LowRise',
    name_ja: '第一種低層住居専用地域',
    abbr: '1低',
    buildingCoverageRange: [30, 60],
    floorAreaRatioRange: [50, 200],
    northernSlopeRestriction: true,
    absoluteHeightLimit: 12, // 10m or 12m (地区指定)
    shadowRegulationApplicable: true,
    allowedUses: ['戸建住宅', '共同住宅', '小規模店舗(兼用住宅で50㎡以下)', '診療所', '保育所', '小中学校'],
    prohibitedUses: ['店舗(50㎡超)', '事務所', '工場', 'カラオケ', 'パチンコ', '風俗営業'],
  },
  Category2LowRise: {
    code: 'Category2LowRise',
    name_ja: '第二種低層住居専用地域',
    abbr: '2低',
    buildingCoverageRange: [30, 60],
    floorAreaRatioRange: [50, 200],
    northernSlopeRestriction: true,
    absoluteHeightLimit: 12,
    shadowRegulationApplicable: true,
    allowedUses: ['戸建住宅', '共同住宅', '150㎡以下の店舗', '小中学校'],
    prohibitedUses: ['大規模店舗', '工場', 'カラオケ', 'パチンコ'],
  },
  Category1MidHighRise: {
    code: 'Category1MidHighRise',
    name_ja: '第一種中高層住居専用地域',
    abbr: '1中高',
    buildingCoverageRange: [30, 60],
    floorAreaRatioRange: [100, 500],
    northernSlopeRestriction: true,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: true,
    allowedUses: ['住宅', '共同住宅', '500㎡以下の店舗', '病院', '大学'],
    prohibitedUses: ['工場', 'カラオケ', 'パチンコ'],
  },
  Category2MidHighRise: {
    code: 'Category2MidHighRise',
    name_ja: '第二種中高層住居専用地域',
    abbr: '2中高',
    buildingCoverageRange: [30, 60],
    floorAreaRatioRange: [100, 500],
    northernSlopeRestriction: true,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: true,
    allowedUses: ['住宅', '1500㎡以下の店舗', '事務所'],
    prohibitedUses: ['工場', 'パチンコ'],
  },
  Category1Residential: {
    code: 'Category1Residential',
    name_ja: '第一種住居地域',
    abbr: '1住',
    buildingCoverageRange: [50, 80],
    floorAreaRatioRange: [100, 500],
    northernSlopeRestriction: false,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: true,
    allowedUses: ['住宅', '3000㎡以下の店舗', 'ホテル'],
    prohibitedUses: ['風俗', 'カラオケ(特定条件)'],
  },
  Category2Residential: {
    code: 'Category2Residential',
    name_ja: '第二種住居地域',
    abbr: '2住',
    buildingCoverageRange: [50, 80],
    floorAreaRatioRange: [100, 500],
    northernSlopeRestriction: false,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: true,
    allowedUses: ['住宅', '10000㎡以下の店舗', 'パチンコ', 'カラオケ'],
    prohibitedUses: ['大規模工場'],
  },
  QuasiResidential: {
    code: 'QuasiResidential',
    name_ja: '準住居地域',
    abbr: '準住',
    buildingCoverageRange: [50, 80],
    floorAreaRatioRange: [100, 500],
    northernSlopeRestriction: false,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: true,
    allowedUses: ['住宅', '店舗', '小規模自動車関連施設'],
    prohibitedUses: ['大規模工場'],
  },
  RuralResidential: {
    code: 'RuralResidential',
    name_ja: '田園住居地域',
    abbr: '田住',
    buildingCoverageRange: [30, 60],
    floorAreaRatioRange: [50, 200],
    northernSlopeRestriction: true,
    absoluteHeightLimit: 12,
    shadowRegulationApplicable: true,
    allowedUses: ['住宅', '農産物直売所', '農家レストラン(500㎡以下)'],
    prohibitedUses: ['大規模店舗', '工場'],
  },
  Neighborhood: {
    code: 'Neighborhood',
    name_ja: '近隣商業地域',
    abbr: '近商',
    buildingCoverageRange: [60, 80],
    floorAreaRatioRange: [100, 500],
    northernSlopeRestriction: false,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: false,
    allowedUses: ['店舗', '事務所', '住宅', '小規模工場'],
    prohibitedUses: ['危険工場'],
  },
  Commercial: {
    code: 'Commercial',
    name_ja: '商業地域',
    abbr: '商',
    buildingCoverageRange: [80, 80],
    floorAreaRatioRange: [200, 1300],
    northernSlopeRestriction: false,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: false,
    allowedUses: ['店舗', '事務所', 'ホテル', '住宅', '映画館', '風俗(一部)'],
    prohibitedUses: ['危険工場'],
  },
  QuasiIndustrial: {
    code: 'QuasiIndustrial',
    name_ja: '準工業地域',
    abbr: '準工',
    buildingCoverageRange: [50, 80],
    floorAreaRatioRange: [100, 500],
    northernSlopeRestriction: false,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: false,
    allowedUses: ['住宅', '店舗', '工場(軽工業)'],
    prohibitedUses: ['危険工場', '風俗(一部)'],
  },
  Industrial: {
    code: 'Industrial',
    name_ja: '工業地域',
    abbr: '工',
    buildingCoverageRange: [50, 60],
    floorAreaRatioRange: [100, 400],
    northernSlopeRestriction: false,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: false,
    allowedUses: ['工場', '住宅', '店舗(10000㎡以下)'],
    prohibitedUses: ['病院', '学校', 'ホテル'],
  },
  IndustrialExclusive: {
    code: 'IndustrialExclusive',
    name_ja: '工業専用地域',
    abbr: '工専',
    buildingCoverageRange: [30, 60],
    floorAreaRatioRange: [100, 400],
    northernSlopeRestriction: false,
    absoluteHeightLimit: null,
    shadowRegulationApplicable: false,
    allowedUses: ['工場全般'],
    prohibitedUses: ['住宅', '病院', '学校', '店舗', 'ホテル'],
  },
});

/** 13用途地域を配列で取得 */
export function listUseDistricts(): UseDistrict[] {
  return Object.values(USE_DISTRICTS);
}

/** 用途地域から特定用途が建てられるか判定 (概算判定。最終判断は特定行政庁) */
export function canBuildUse(district: UseDistrictCode, useType: string): {
  allowed: boolean;
  reason: string;
  suggestion?: string;
} {
  const d = USE_DISTRICTS[district];
  const prohibited = d.prohibitedUses.find(u => useType.includes(u) || u.includes(useType));
  if (prohibited) {
    return { allowed: false, reason: `${d.name_ja}では「${prohibited}」は原則不可`, suggestion: '用途地域を確認し、可能な地域を選定してください' };
  }
  const allowed = d.allowedUses.find(u => useType.includes(u) || u.includes(useType));
  if (allowed) {
    return { allowed: true, reason: `${d.name_ja}で「${allowed}」は許容` };
  }
  return { allowed: false, reason: `${d.name_ja}では「${useType}」の可否を個別判断要(特定行政庁確認)`, suggestion: '建築士に相談してください' };
}

// =============================================================================
// 2. 建築基準法 集団規定
// =============================================================================

/** 前面道路幅員による容積率制限 (建基法52条2項) */
export function calcFloorAreaRatioByRoad(
  frontRoadWidthM: number,
  district: UseDistrictCode,
  zonedFar: number, // 都市計画で指定された容積率(%)
): number {
  // 住居系: 前面道路幅員 × 0.4 (商業系は × 0.6)
  const isResidential = [
    'Category1LowRise', 'Category2LowRise',
    'Category1MidHighRise', 'Category2MidHighRise',
    'Category1Residential', 'Category2Residential',
    'QuasiResidential', 'RuralResidential',
  ].includes(district);
  const coef = isResidential ? 0.4 : 0.6;
  const roadFar = frontRoadWidthM * coef * 100;
  return Math.min(zonedFar, roadFar);
}

/**
 * 建蔽率の緩和（建築基準法第53条第3項・第6項第1号）。
 * 出典: https://laws.e-gov.go.jp/api/1/lawdata/325AC0000000201 （取得日: 2026-11-13）
 * 第3項: 防火地域の耐火建築物等、準防火地域の耐火・準耐火建築物等は10ポイント加算。
 * 指定された角地等も10ポイント加算し、両方なら20ポイント加算する。
 * 「等」は同等以上の延焼防止性能を持つものとして政令で定める建築物を含む。
 * 第6項第1号: 第1項第2〜4号による限度80%の防火地域の耐火建築物等は適用除外。
 * 本関数は単一の指定建蔽率を対象とし、この適用除外を敷地全面の100%として返す。
 * 複数地域の面積按分（第2項）や個別許可（第4〜6項）はこの関数の対象外。
 */
export function calcBuildingCoverageWithRelief(
  baseCoverage: number,
  opts: {
    /** 単に角にあるだけでなく、特定行政庁が指定した敷地であること。 */
    corner?: boolean;
    fireResistant?: boolean;
    quasiFireResistant?: boolean;
    /** 第3項第1号イの政令に該当する延焼防止性能。 */
    fireResistantEquivalent?: boolean;
    /** 第3項第1号ロの政令に該当する延焼防止性能。 */
    quasiFireResistantEquivalent?: boolean;
    fireZone?: 'fire' | 'quasi' | 'none';
  } = {},
): number {
  const fireQualified = !!(opts.fireResistant || opts.fireResistantEquivalent);
  const quasiQualified = fireQualified || !!(opts.quasiFireResistant || opts.quasiFireResistantEquivalent);
  if (baseCoverage === 80 && opts.fireZone === 'fire' && fireQualified) return 100;
  let coverage = baseCoverage;
  if (opts.corner) coverage += 10;
  const fireRelief = (opts.fireZone === 'fire' && fireQualified)
    || (opts.fireZone === 'quasi' && quasiQualified);
  if (fireRelief) coverage += 10;
  return Math.min(100, coverage);
}

/** 絶対高さ制限(低層専用地域)を確認 */
export function checkAbsoluteHeight(
  proposedHeightM: number,
  district: UseDistrictCode,
): { ok: boolean; limit: number | null; overM: number } {
  const d = USE_DISTRICTS[district];
  if (d.absoluteHeightLimit == null) return { ok: true, limit: null, overM: 0 };
  const over = proposedHeightM - d.absoluteHeightLimit;
  return { ok: over <= 0, limit: d.absoluteHeightLimit, overM: Math.max(0, over) };
}

/**
 * 北側斜線 (建基法56条): 隣地境界から真北に向かって高さ制限
 * 低層専用: 5m + 1.25×距離、中高層専用: 10m + 1.25×距離
 */
export function calcNorthernSlopeLimit(
  distanceFromNorthBoundaryM: number,
  district: UseDistrictCode,
): { applies: boolean; heightLimitM: number } {
  const d = USE_DISTRICTS[district];
  if (!d.northernSlopeRestriction) return { applies: false, heightLimitM: Infinity };
  const base = district === 'Category1LowRise' || district === 'Category2LowRise' || district === 'RuralResidential' ? 5 : 10;
  return { applies: true, heightLimitM: base + 1.25 * distanceFromNorthBoundaryM };
}

/**
 * 道路斜線 (建基法56条1項1号): 前面道路の反対側境界線から1.25 or 1.5の勾配
 */
export function calcRoadSlopeLimit(
  distanceFromOppositeRoadM: number,
  district: UseDistrictCode,
): number {
  const isResidential = [
    'Category1LowRise', 'Category2LowRise',
    'Category1MidHighRise', 'Category2MidHighRise',
    'Category1Residential', 'Category2Residential',
    'QuasiResidential', 'RuralResidential',
  ].includes(district);
  const coef = isResidential ? 1.25 : 1.5;
  return distanceFromOppositeRoadM * coef;
}

/**
 * 隣地斜線 (建基法56条1項2号): 隣地境界から20m(住居系) or 31m(その他) 上で1.25 or 2.5
 */
export function calcAdjacentSlopeLimit(
  distanceFromAdjacentBoundaryM: number,
  district: UseDistrictCode,
): number {
  const isResidential = [
    'Category1MidHighRise', 'Category2MidHighRise',
    'Category1Residential', 'Category2Residential',
    'QuasiResidential',
  ].includes(district);
  const isLowRise = district === 'Category1LowRise' || district === 'Category2LowRise' || district === 'RuralResidential';
  if (isLowRise) return 0; // 低層専用は絶対高さで規制される
  const base = isResidential ? 20 : 31;
  const coef = isResidential ? 1.25 : 2.5;
  return base + distanceFromAdjacentBoundaryM * coef;
}

/**
 * 日影規制 (建基法56条の2): 冬至日 8:00〜16:00 の日影時間規制
 */
export function getShadowRegulation(district: UseDistrictCode): {
  applies: boolean;
  measurementHeightM: number;
  tiers: { range: '5mLine' | '10mLine'; maxHours: number[] }[];
} {
  const d = USE_DISTRICTS[district];
  if (!d.shadowRegulationApplicable) {
    return { applies: false, measurementHeightM: 0, tiers: [] };
  }
  const isLowRise = district === 'Category1LowRise' || district === 'Category2LowRise' || district === 'RuralResidential';
  const height = isLowRise ? 1.5 : 4.0; // 平均地盤面からの測定面高さ
  return {
    applies: true,
    measurementHeightM: height,
    tiers: [
      { range: '5mLine', maxHours: [3, 4, 5] },   // 境界から 5m超〜10m: 3h/4h/5h (地区指定)
      { range: '10mLine', maxHours: [2, 2.5, 3] }, // 10m超: 2h/2.5h/3h
    ],
  };
}

// =============================================================================
// 3. 構造設計 (建築基準法施行令 + 告示)
// =============================================================================

export type StructureType = 'wood' | 'steel' | 'rc' | 'src' | 'clt' | 'mixed';

export interface StructureSpec {
  type: StructureType;
  /** 審査省略制度の対象か (2025-03-31 までは旧4号特例、2025-04-01 以後は新3号建築物＝平屋かつ延べ200㎡以下) */
  exemption4go: boolean;
  /** 構造計算ルート */
  calcRoute: 'route1' | 'route2' | 'route3' | 'timeHistory';
  /** 必要な構造計算 */
  requiredCalcs: string[];
}

/** 2025-04-01 施行の改正建築基準法 (令和4年法律第69号) — 4号特例の縮小と木造の構造計算の対象拡大 */
export const STRUCTURE_ROUTE_REVISION_2025 = Object.freeze({
  effectiveFrom: '2025-04-01',
  /** 審査省略 (新3号建築物): 構造によらず 平屋かつ延べ面積200㎡以下 */
  reviewExemptionMaxStories: 1,
  reviewExemptionMaxFloorAreaM2: 200,
  /** 木造の仕様規定 (壁量計算等) の範囲: 階数2以下・延べ300㎡以下・高さ16m以下。超えると構造計算 */
  woodSpecMaxStories: 2,
  woodSpecMaxFloorAreaM2: 300,
  woodSpecMaxHeightM: 16,
  /** 木造の簡易な構造計算 (許容応力度計算) の範囲: 階数3以下・高さ16m以下 */
  woodSimpleCalcMaxStories: 3,
  woodSimpleCalcMaxHeightM: 16,
  source_ja:
    '国土交通省「建築基準法・建築物省エネ法 改正法制度説明資料」(令和6年9月) https://www.mlit.go.jp/common/001627103.pdf — 審査省略は平屋かつ延べ200㎡以下 (新3号) に縮小、2階以下の木造で構造計算が必要な規模は延べ500㎡超→300㎡超、簡易な構造計算は階数3以下かつ高さ16m以下',
});

function toYmd(d: Date | string | undefined): string {
  if (d === undefined) {
    const n = new Date();
    return `${n.getFullYear()}-${String(n.getMonth() + 1).padStart(2, '0')}-${String(n.getDate()).padStart(2, '0')}`;
  }
  if (typeof d === 'string') return d.slice(0, 10);
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

/**
 * 構造計算ルート判定 (建基法20条 + 令81条)
 *   基準日 asOf (確認申請・着工の日。省略時は今日) で新旧を切り替える。
 *   〜2025-03-31: 木造 2階以下 かつ 延床 500㎡以下 かつ 高さ 13m以下 かつ 軒高 9m以下 → 4号特例 (旧法)
 *   2025-04-01〜: 審査省略は 平屋かつ延べ200㎡以下 (新3号) だけ。木造2階建ては新2号で全規定が審査対象。
 *                 木造で 階数2以下・延べ300㎡以下・高さ16m以下 は仕様規定、超えると構造計算。
 *                 出典は STRUCTURE_ROUTE_REVISION_2025.source_ja
 */
export function determineStructureRoute(opts: {
  type: StructureType;
  stories: number;
  floorArea: number;
  heightM: number;
  eaveHeightM?: number;
  hasSoftStory?: boolean;
  spanM?: number;
  /** 判定の基準日 (YYYY-MM-DD または Date)。省略時は今日 */
  asOf?: Date | string;
}): StructureSpec {
  const { type, stories, floorArea, heightM, eaveHeightM = heightM, hasSoftStory, spanM } = opts;
  const R = STRUCTURE_ROUTE_REVISION_2025;
  const revised = toYmd(opts.asOf) >= R.effectiveFrom;

  if (revised && type === 'wood' && heightM <= 60) {
    const exemption = stories <= R.reviewExemptionMaxStories && floorArea <= R.reviewExemptionMaxFloorAreaM2;
    // 仕様規定の範囲 (構造計算は不要。壁量計算等)
    if (stories <= R.woodSpecMaxStories && floorArea <= R.woodSpecMaxFloorAreaM2 && heightM <= R.woodSpecMaxHeightM) {
      return {
        type,
        exemption4go: exemption,
        calcRoute: 'route1',
        requiredCalcs: ['壁量計算(令46条・昭和56年建設省告示第1100号)', '壁配置バランス(四分割法)', 'N値計算(柱頭柱脚金物)', '柱の小径(令43条)'],
      };
    }
    // 簡易な構造計算 (許容応力度計算)
    if (stories <= R.woodSimpleCalcMaxStories && heightM <= R.woodSimpleCalcMaxHeightM && !hasSoftStory) {
      return {
        type,
        exemption4go: exemption,
        calcRoute: 'route1',
        requiredCalcs: ['許容応力度計算(令82条)', '長期荷重 + 短期荷重(地震/風)'],
      };
    }
    // 高さ16m超60m以下・4階建て以上など: 高度な構造計算
    return {
      type,
      exemption4go: false,
      calcRoute: hasSoftStory || heightM > 31 ? 'route3' : 'route2',
      requiredCalcs: hasSoftStory || heightM > 31
        ? ['一次設計(許容応力度)', '保有水平耐力計算(令82条の3)', 'Ds値算定', '偏心率/剛性率検証']
        : ['許容応力度等計算(令82条の6)', '層間変形角≤1/200', '剛性率≥0.6', '偏心率≤0.15'],
    };
  }

  // 4号建築物特例 (〜2025-03-31 の基準日に限る)
  if (!revised && type === 'wood' && stories <= 2 && floorArea <= 500 && heightM <= 13 && eaveHeightM <= 9) {
    return {
      type,
      exemption4go: true,
      calcRoute: 'route1',
      requiredCalcs: ['壁量計算(令46条)', '壁配置バランス(四分割法)', 'N値計算(柱頭柱脚金物)'],
    };
  }

  // 超高層 (60m超) → 時刻歴応答解析
  if (heightM > 60) {
    return {
      type,
      exemption4go: false,
      calcRoute: 'timeHistory',
      requiredCalcs: ['時刻歴応答解析(告示1461号)', '大臣認定取得必要'],
    };
  }

  // ルート3 (保有水平耐力計算)
  if (hasSoftStory || (type === 'steel' && stories >= 4) || heightM > 31) {
    return {
      type,
      exemption4go: false,
      calcRoute: 'route3',
      requiredCalcs: ['一次設計(許容応力度)', '保有水平耐力計算(令82条の3)', 'Ds値算定', '偏心率/剛性率検証'],
    };
  }

  // ルート2 (許容応力度等計算 + 剛性率/偏心率)
  if (heightM > 20 || (spanM != null && spanM >= 6)) {
    return {
      type,
      exemption4go: false,
      calcRoute: 'route2',
      requiredCalcs: ['許容応力度計算', '層間変形角≤1/200', '剛性率≥0.6', '偏心率≤0.15'],
    };
  }

  // ルート1 (許容応力度のみ)
  return {
    type,
    exemption4go: false,
    calcRoute: 'route1',
    requiredCalcs: ['許容応力度計算(令82条)', '長期荷重 + 短期荷重(地震/風)'],
  };
}

// =============================================================================
// 3.5 木造の壁量計算・柱の小径 (2025年4月1日施行の基準)
// =============================================================================
//
// 【この節の出典】
//   図面側の基準辞書 lib/drawing-sdm/dip/dicts/standards_architecture.json と、
//   その出典である lib/japan/law-sources/articles/wall-quantity-2025-revision.json
//   を唯一の出典とし、そこから転記している。**この値と式を独自に書き換えないこと。**
//   食い違いは常設の照合検査 (L63-BUILDING-CODE-CONSISTENCY) が検出して不合格にする。
//
// 【2026-08-26 の是正 — 法令の版が古かった】
//   当社の実装は「令46条4項 表2 (軽い屋根/重い屋根の区分)」を参照していたが、
//   この表は 2025年4月1日施行の改正 (令和6年政令第172号・令和6年国土交通省告示第447号) で
//   施行令から削除され、昭和56年建設省告示第1100号へ移行している。屋根の重さによる
//   区分そのものが廃止され、必要壁量は建築物の荷重の実態に応じた算定式で求める。
//   経過措置 (令和7年4月1日〜令和8年3月31日着手) も既に終了している。
//   古い表のまま計算し続けると、省エネ化で重量化した建物の壁量不足を見逃す。
//
// 【当社が数値を作らない範囲】
//   荷重 (屋根・外壁・内壁・床・断熱材・太陽光発電設備・積載) は設計者が建築物の
//   実況に応じて定めるものであり、法定値ではない。指定が無いときは数値を返さず
//   「未検算」とする。合格と表示しない。

/** 壁の単位長さあたりの許容せん断耐力に対応する係数 (kN/cm)。告示1100号 第3 */
const WALL_QTY_QO = 0.0196;
/** 標準せん断力係数 C0 (告示1100号 第3・令88条2項) */
const WALL_QTY_C0_DEFAULT = 0.2;
const WALL_QTY_C0_DESIGNATED = 0.3;
/** 階高の低減しきい値 (mm)。告示1100号 別表第1関係 */
const BRACE_HEIGHT_THRESHOLD_MM = 3200;
/** 準耐力壁等を存在壁量へ算入できる上限 (必要壁量に対する割合)。告示1100号 第3 */
const QUASI_WALL_INCLUSION_RATIO = 0.5;

/**
 * 層せん断力分布係数 Ai を求める (告示1100号 第3)。
 *   Ai = 1 + { (1/√αi) − αi } × 2T/(1+3T)、固有周期 T = 0.03h (秒)
 *
 * @param alphaI 当該階が支える部分の荷重 ÷ 地上部分の荷重の合計 (0 < αi ≦ 1)
 * @param buildingHeightM 建築物の高さ h (m)
 */
export function calcAiDistributionFactor(alphaI: number, buildingHeightM: number): number | null {
  if (!(alphaI > 0 && alphaI <= 1)) return null;
  if (!(buildingHeightM > 0)) return null;
  const t = 0.03 * buildingHeightM;
  return 1 + (1 / Math.sqrt(alphaI) - alphaI) * (2 * t) / (1 + 3 * t);
}

/**
 * 階高が3.2mを超える軸組の壁倍率の低減係数 αh (告示1100号 別表第1関係)。
 *   αh = 3.5 × Ld / H0 (1.0 を超える場合は 1.0)
 * 筋かいに限らず、全ての耐力壁・準耐力壁等に適用する。
 */
export function calcBraceHeightReduction(ldMm: number, h0Mm: number): number | null {
  if (!(h0Mm > 0)) return null;
  if (h0Mm <= BRACE_HEIGHT_THRESHOLD_MM) return 1.0;
  if (!(ldMm > 0)) return null;
  return Math.min(3.5 * ldMm / h0Mm, 1.0);
}

/**
 * 準耐力壁等の壁倍率 (告示1100号 第1・別表第10)。
 *   面材:   材料の基準倍率 × 0.6 × (面材の高さの合計 ÷ 横架材間内法寸法)
 *   木ずり: 0.5 × (木ずりの高さの合計 ÷ 横架材間内法寸法)
 * 仕様 (幅・高さ・両側の耐力壁) を満たさないものは null を返し、算入しない。
 */
export function calcQuasiWallMultiplier(opts: {
  kind: 'panel' | 'kizuri';
  type: 'quasi' | 'hanging_spandrel';
  baseMultiplier?: number;   // 面材のみ (構造用合板等 2.5 / 石こうボード 0.9)
  heightTotalMm: number;
  clearSpanMm: number;
  widthMm?: number;
  bothSidesBearing?: boolean; // 垂れ壁・腰壁のみ
}): { multiplier: number | null; reason: string } {
  const { kind, type, baseMultiplier, heightTotalMm, clearSpanMm, widthMm, bothSidesBearing } = opts;
  if (!(clearSpanMm > 0)) return { multiplier: null, reason: '横架材間内法寸法が指定されていません' };
  if (!(heightTotalMm > 0)) return { multiplier: null, reason: '面材 (または木ずり) の高さの合計が指定されていません' };

  if (type === 'quasi') {
    if (widthMm !== undefined && widthMm < 900) {
      return { multiplier: null, reason: '幅が90cm未満のため準耐力壁として算入できません' };
    }
    if (heightTotalMm < clearSpanMm * 0.8) {
      return { multiplier: null, reason: '高さが横架材間内法寸法の80%未満のため準耐力壁として算入できません' };
    }
  } else {
    if (widthMm !== undefined && widthMm < 900) {
      return { multiplier: null, reason: '幅が90cm未満のため垂れ壁・腰壁として算入できません' };
    }
    if (widthMm !== undefined && widthMm > 2000) {
      return { multiplier: null, reason: '幅が2mを超えるため垂れ壁・腰壁として算入できません' };
    }
    if (heightTotalMm < 360) {
      return { multiplier: null, reason: '高さが36cm未満のため垂れ壁・腰壁として算入できません' };
    }
    if (!bothSidesBearing) {
      return { multiplier: null, reason: '両側に耐力壁または準耐力壁があることが確認できていません' };
    }
  }

  const ratio = heightTotalMm / clearSpanMm;
  if (kind === 'panel') {
    if (baseMultiplier === undefined) {
      return { multiplier: null, reason: '面材の基準倍率が指定されていません' };
    }
    return {
      multiplier: baseMultiplier * 0.6 * ratio,
      reason: `材料の基準倍率 ${baseMultiplier} × 0.6 × (${heightTotalMm}mm ÷ ${clearSpanMm}mm)`,
    };
  }
  return { multiplier: 0.5 * ratio, reason: `0.5 × (${heightTotalMm}mm ÷ ${clearSpanMm}mm)` };
}

// ══════════════════════════════════════════════════════════════════
// 原典台帳（一次情報の収録先）を見て、開示の文面を切り替えるための部品
//
// 【なぜ要るか / 2026-09-24】
//   風圧力の地域区分の数値（一般の区域 50cm/㎡・特定行政庁が指定する強風区域は
//   50 を超え 75 以下）と見付面積の控除高さ 1.35m は、2026-08-31 の是正で
//   law-sources/articles/wall-quantity-h56-1100.json へ出典つきで収録済みだった。
//   ところがこのファイルの開示文だけが「当システムは改正後の告示原文を確認できて
//   いないため、改正前の数値をそのまま用いています。風圧力の判定は参考値として
//   お取り扱いください」を **無条件で** 出し続けていた（2026-09-24 実測）。
//   是正が原典台帳には届き、お客様の目に触れるこの一文には届いていなかった。
//   結果としてお客様には、実際より不確かに見えていた。
//
// 【直し方の方針】
//   文面を書き換えるのではなく、**原典台帳に収録されているかどうかを見て切り替える**。
//   収録が無ければ従来どおり「参考値」と出る。台帳の側が後退すれば開示も自動で戻る。
//   ★「確認済みです」とだけ言い切る文面にはしない。何を出典としたかを必ず添える。
// ══════════════════════════════════════════════════════════════════
import wallQuantity1100 from './law-sources/articles/wall-quantity-h56-1100.json';

type PrimarySourceRef = {
  /** 原典台帳に「一次情報で確認した」として収録されているか */
  verified: boolean;
  /** 収録されている条番号 (例: 告示1100号 第三第一項第二号 表（二）項) */
  article?: string;
  /** 収録の出典 (例: 令和6年国交告447号 新旧対照表 p.10) */
  source?: string;
};

/** 原典台帳から 1 項目を引く。台帳に無い・未確認なら verified:false を返す（推測しない）。 */
export function lookupPrimarySource(key: string): PrimarySourceRef {
  const items = (wallQuantity1100 as { items?: Array<Record<string, unknown>> })?.items;
  if (!Array.isArray(items)) return { verified: false };
  const hit = items.find((x) => x && (x as { key?: string }).key === key);
  if (!hit) return { verified: false };
  const h = hit as { verified_from_primary?: unknown; article?: unknown; source?: unknown };
  return {
    verified: h.verified_from_primary === true,
    article: typeof h.article === 'string' ? h.article : undefined,
    source: typeof h.source === 'string' ? h.source : undefined,
  };
}

/**
 * 風圧力の数値について、いま出すべき開示文を組み立てる。
 * 一般の区域と強風区域の **両方** が原典台帳に収録されているときだけ、出典つきの文面にする。
 * 片方でも欠けていれば、従来どおり「参考値としてお取り扱いください」を出す（安全側）。
 */
export function windCoefficientDisclosure(): string {
  const general = lookupPrimarySource('wind_coefficient_general');
  const designated = lookupPrimarySource('wind_coefficient_designated');
  if (general.verified && designated.verified) {
    return (
      '風圧力の基準は2025年4月1日施行の改正で施行令から告示へ移りました。' +
      `見付面積に乗ずる数値は${general.article ?? '告示1100号 第三第一項第二号'}に定められており、` +
      '当社はその原文を取得して照合しています' +
      `（出典: ${general.source ?? '令和6年国交告447号'}）。` +
      'なお、特定行政庁が指定する強風区域に当たるかどうかと、その区域で用いる数値は' +
      '所轄の特定行政庁の規則で定められます（当社では判定しません）。'
    );
  }
  return (
    '風圧力の基準も2025年4月1日施行の改正で施行令から告示へ移行しました。' +
    '当システムは改正後の告示原文を確認できていないため、改正前の数値をそのまま用いています。' +
    '風圧力の判定は参考値としてお取り扱いください。'
  );
}

/**
 * 木造の必要壁量 (地震力・風圧力) を求める。
 *
 * 【地震力】昭和56年建設省告示第1100号 第3 (令46条4項に基づく基準)
 *   Lw (cm/㎡) = (Ai × C0 × Σwi) ÷ (0.0196 × Afi)
 *   必要壁量(cm) = Lw × 当該階の床面積(㎡)
 *
 * 【風圧力】同告示 (改正前は令46条4項 表3)
 *   必要壁量(cm) = 見付面積(㎡) × 見付面積に乗ずる数値(cm/㎡)
 *   ※ 数値の出どころの開示は windCoefficientDisclosure() が原典台帳を見て決める。
 *      台帳に収録があれば出典つきの文面、無ければ従来どおり「参考値」と出す。
 */
export function calcRequiredWallQuantityWood(opts: {
  /** 検算する階の床面積 (㎡) */
  floorAreaM2: number;
  /** 建築物の高さ h (m)。固有周期 T = 0.03h の算定に使う */
  buildingHeightM: number;
  /** 当該階が地震時に負担する固定荷重と積載荷重の和 (kN)。積雪荷重は含まない */
  storeySeismicLoadKn: number;
  /** 地上部分の固定荷重と積載荷重の合計 (kN)。αi の算定に使う */
  groundTotalLoadKn: number;
  /** 見付面積 (㎡)。風圧力の検算に使う */
  windAreaM2?: number;
  /** 地盤が著しく軟弱な区域として特定行政庁が指定する区域内か (令88条2項 → C0 = 0.3) */
  designatedSoftGround?: boolean;
  /** 特定行政庁が指定する強風区域の係数 (50〜75)。未指定は一般区域50 */
  windCoefOverride?: number;
}): {
  /** 床面積あたりの必要壁量 Lw (cm/㎡) */
  lw_cm_per_m2: number | null;
  earthquake_cm: number | null;
  wind_cm: number | null;
  required_cm: number | null;
  ai: number | null;
  alpha_i: number | null;
  /** 適合判定に使える値が出せたか。'未検算' のときは数値を null で返す (合格と表示しないため) */
  verdict: '検算可' | '未検算';
  /** 未検算・注意事項の理由 (日本語・そのまま画面に出してよい) */
  notes: string[];
} {
  const {
    floorAreaM2, buildingHeightM, storeySeismicLoadKn, groundTotalLoadKn,
    windAreaM2, designatedSoftGround, windCoefOverride,
  } = opts;
  const notes: string[] = [];
  const fail = (): ReturnType<typeof calcRequiredWallQuantityWood> => ({
    lw_cm_per_m2: null, earthquake_cm: null, wind_cm: null, required_cm: null,
    ai: null, alpha_i: null, verdict: '未検算', notes,
  });

  if (!(floorAreaM2 > 0)) {
    notes.push('当該階の床面積が指定されていないため検算できません。');
    return fail();
  }
  if (!(buildingHeightM > 0)) {
    notes.push(
      '建築物の高さが指定されていないため検算できません。' +
      '2025年4月1日施行の基準では、必要壁量を建築物の荷重と高さから算定します。'
    );
    return fail();
  }
  if (!(storeySeismicLoadKn > 0) || !(groundTotalLoadKn > 0)) {
    notes.push(
      '荷重が指定されていないため検算できません。' +
      '屋根・外壁・断熱材・太陽光発電設備・積載荷重などの重さは建物ごとに設計者が定めるものであり、' +
      '当システムでは数値を作りません。ご指定いただければその値で検算します。'
    );
    return fail();
  }
  if (storeySeismicLoadKn > groundTotalLoadKn) {
    notes.push('当該階が負担する荷重が、地上部分の荷重の合計を超えています。入力をご確認ください。');
    return fail();
  }

  const alphaI = storeySeismicLoadKn / groundTotalLoadKn;
  const ai = calcAiDistributionFactor(alphaI, buildingHeightM);
  if (ai === null) {
    notes.push('層せん断力分布係数を算定できませんでした。荷重と高さの入力をご確認ください。');
    return fail();
  }

  const c0 = designatedSoftGround ? WALL_QTY_C0_DESIGNATED : WALL_QTY_C0_DEFAULT;
  if (designatedSoftGround) {
    notes.push('地盤が著しく軟弱な区域として指定された区域のため、標準せん断力係数を0.3で算定しています (令88条2項)。');
  } else {
    notes.push('標準せん断力係数は0.2で算定しています。特定行政庁が地盤が著しく軟弱な区域として指定する区域内では0.3になります。');
  }

  const lw = (ai * c0 * storeySeismicLoadKn) / (WALL_QTY_QO * floorAreaM2);
  const earthquake_cm = lw * floorAreaM2;
  notes.push(
    `必要壁量は建築物の荷重の実態から算定しています (昭和56年建設省告示第1100号 第3)。` +
    `2025年4月1日施行の改正で「軽い屋根」「重い屋根」の区分は廃止されました。`
  );

  let wind_cm: number | null = null;
  if (windAreaM2 !== undefined && windAreaM2 > 0) {
    let windCoef = 50;
    if (windCoefOverride !== undefined) {
      if (windCoefOverride < 50 || windCoefOverride > 75) {
        notes.push(
          `指定された風圧力の係数 ${windCoefOverride} は、定められた範囲 (50〜75) の外です。` +
          `特定行政庁が定める数値をご確認ください。`
        );
        return fail();
      }
      windCoef = windCoefOverride;
      notes.push(`特定行政庁が定める風圧力の係数 ${windCoef}cm/㎡ を用いて算定しています。`);
    } else {
      notes.push('風圧力は一般区域の50cm/㎡で算定しています。特定行政庁が指定する区域では50〜75の範囲で数値が定められます。');
    }
    // 2026-09-24: 無条件で「確認できていない」と出していたのをやめ、原典台帳を見て切り替える
    notes.push(windCoefficientDisclosure());
    wind_cm = windAreaM2 * windCoef;
  } else {
    notes.push('見付面積の指定が無いため、風圧力に対する必要壁量は算定していません。');
  }

  return {
    lw_cm_per_m2: lw,
    earthquake_cm,
    wind_cm,
    required_cm: wind_cm === null ? earthquake_cm : Math.max(earthquake_cm, wind_cm),
    ai,
    alpha_i: alphaI,
    verdict: '検算可',
    notes,
  };
}

/**
 * 耐震等級 (品確法・住宅性能表示制度) の必要壁量を求める。
 *
 * 【出典】日本住宅性能表示基準・評価方法基準 (平成13年国土交通省告示第1347号)
 *   Lw (cm/㎡) = (Z × Ai × C0 × Σwi) ÷ (0.0196 × Afi) × 等級の倍率
 *   等級2 = 1.25倍、等級3 = 1.5倍
 *
 * 建築基準法の算定式との違いは2つ:
 *   ・地震地域係数 Z (0.7〜1.0) を乗じる
 *   ・Σwi に積雪荷重を含む
 *
 * 当社は Z の地域別の数値を収録していないため、Z は利用者入力とする。
 * 未入力のときは数値を返さず「未検算」にする。
 *
 * ※ 当社が行うのは壁量に基づく検算であり、登録住宅性能評価機関による評価に代わるものではない。
 */
export function calcSeismicGradeWallQuantity(opts: {
  grade: 1 | 2 | 3;
  floorAreaM2: number;
  buildingHeightM: number;
  /** 当該階が地震時に負担する固定荷重と積載荷重の和 (kN)。積雪荷重は snowLoadKn で別に渡す */
  storeySeismicLoadKn: number;
  groundTotalLoadKn: number;
  /** 地震地域係数 Z (0.7〜1.0)。告示1793号第1 */
  zoneFactorZ: number;
  /**
   * 多雪区域における積雪荷重 (kN)。
   * 評価方法基準では、そのまま加えるのではなく **0.35 を乗じた値** を Σwi に加える。
   */
  snowLoadKn?: number;
  designatedSoftGround?: boolean;
}): {
  lw_cm_per_m2: number | null;
  required_cm: number | null;
  grade_factor: number | null;
  verdict: '検算可' | '未検算';
  notes: string[];
} {
  const { grade, floorAreaM2, buildingHeightM, storeySeismicLoadKn,
          groundTotalLoadKn, zoneFactorZ, snowLoadKn, designatedSoftGround } = opts;
  const notes: string[] = [];
  const factors: Record<number, number> = { 1: 1.0, 2: 1.25, 3: 1.5 };
  const factor = factors[grade];
  /** 多雪区域の積雪荷重に乗じる係数 (評価方法基準) */
  const SNOW_LOAD_FACTOR = 0.35;

  if (factor === undefined) {
    notes.push(`耐震等級 ${grade} は当システムが扱う範囲 (等級1〜3) の外です。`);
    return { lw_cm_per_m2: null, required_cm: null, grade_factor: null, verdict: '未検算', notes };
  }
  if (!(zoneFactorZ >= 0.7 && zoneFactorZ <= 1.0)) {
    notes.push(
      '耐震等級の算定式では地震地域係数 Z (0.7〜1.0) を乗じます。' +
      '当システムは地域別の Z の数値を収録していないため、建設地の Z をご指定ください。'
    );
    return { lw_cm_per_m2: null, required_cm: null, grade_factor: null, verdict: '未検算', notes };
  }

  // 多雪区域では積雪荷重に 0.35 を乗じた値を Σwi に加える (評価方法基準の原文による)
  const snowRaw = snowLoadKn ?? 0;
  const snowAdded = snowRaw * SNOW_LOAD_FACTOR;
  const base = calcRequiredWallQuantityWood({
    floorAreaM2, buildingHeightM,
    storeySeismicLoadKn: storeySeismicLoadKn + snowAdded,
    groundTotalLoadKn: groundTotalLoadKn + snowAdded,
    designatedSoftGround,
  });
  if (base.verdict === '未検算' || base.lw_cm_per_m2 === null) {
    return { lw_cm_per_m2: null, required_cm: null, grade_factor: null,
             verdict: '未検算', notes: base.notes };
  }

  const lw = base.lw_cm_per_m2 * zoneFactorZ * factor;
  notes.push(
    `耐震等級${grade}の必要壁量は、建築基準法の算定式に地震地域係数 Z (${zoneFactorZ}) と` +
    `等級の倍率 (${factor}倍) を乗じて求めています。`
  );
  if (snowRaw > 0) {
    notes.push(
      `多雪区域の積雪荷重 ${snowRaw} kN に ${SNOW_LOAD_FACTOR} を乗じた ` +
      `${snowAdded.toFixed(1)} kN を Σwi に加えています。`
    );
  } else {
    notes.push(
      `積雪荷重の指定が無いため 0 として計算しています。多雪区域では、積雪荷重に ` +
      `${SNOW_LOAD_FACTOR} を乗じた値を加える必要があります。`
    );
  }
  notes.push('当システムが行うのは壁量に基づく検算であり、登録住宅性能評価機関による評価に代わるものではありません。');

  return {
    lw_cm_per_m2: lw,
    required_cm: lw * floorAreaM2,
    grade_factor: factor,
    verdict: '検算可',
    notes,
  };
}

/**
 * 木造の柱の必要小径を求める。
 *
 * 【出典】平成12年建設省告示第1349号 第1 (令43条1項に基づく基準)
 *   de / l = 0.027 + 22.5 × Wd / l²
 *     de: 必要な柱の小径 (mm) / l: 横架材の相互間の垂直距離 (mm)
 *     Wd: 当該階が負担する単位面積あたりの固定荷重と積載荷重の和 (N/㎡)。積雪荷重は含まない
 *
 * 2025年4月1日施行の改正で「軽い屋根」「重い屋根」等の区分は廃止された。
 * 令43条2項により、階数が2を超える建築物の1階の柱は13.5cmを下回れない。
 */
export function calcRequiredColumnSizeWood(opts: {
  /** 当該階が負担する単位面積あたりの固定荷重と積載荷重の和 (N/㎡) */
  loadWdNPerM2: number;
  /** 横架材の相互間の垂直距離 l (mm) */
  clearHeightMm: number;
  /** 建物の階数 (令43条2項の下限判定に使う) */
  stories?: number;
  /** 検算する階 */
  targetStory?: number;
}): {
  required_de_mm: number | null;
  de_over_l: number | null;
  verdict: '検算可' | '未検算';
  notes: string[];
} {
  const { loadWdNPerM2, clearHeightMm, stories, targetStory } = opts;
  const notes: string[] = [];
  if (!(loadWdNPerM2 > 0) || !(clearHeightMm > 0)) {
    notes.push(
      '柱の小径は建築物の荷重の実態から算定します (平成12年建設省告示第1349号 第1)。' +
      '当該階が負担する単位面積あたりの荷重 (N/㎡) と、横架材の相互間の垂直距離 (mm) を' +
      'ご指定いただければ検算します。荷重は設計者が定めるものであり、当システムでは数値を作りません。'
    );
    return { required_de_mm: null, de_over_l: null, verdict: '未検算', notes };
  }

  const ratio = 0.027 + 22.5 * loadWdNPerM2 / (clearHeightMm * clearHeightMm);
  let de = ratio * clearHeightMm;
  notes.push(
    `2025年4月1日施行の改正で「軽い屋根」「重い屋根」等の区分は廃止され、` +
    `荷重の実態に応じた算定式になりました。`
  );

  if (stories !== undefined && targetStory !== undefined && stories > 2 && targetStory === 1) {
    if (de < 135) {
      notes.push(
        `算定値は ${de.toFixed(1)} mm ですが、階数が2を超える建築物の1階の柱は 135 mm (13.5cm) を` +
        `下回れません (令43条第2項)。こちらを必要小径とします。`
      );
      de = 135;
    }
  }
  notes.push('柱に壁が取り付く場合、その壁の方向については柱の小径の検討は不要です (告示1349号第1ただし書)。');

  return { required_de_mm: de, de_over_l: ratio, verdict: '検算可', notes };
}

/**
 * 【経過措置】改正前の令46条4項 表2 による必要壁量。
 *
 * 2025年4月1日施行の改正でこの表は廃止され、経過措置 (令和7年4月1日〜令和8年3月31日に
 * 工事着手するもの) も終了している。**現在着手する建築物には使わない。**
 * 既存建築物の検証や、経過措置期間中に着手した建築物の確認にのみ用いる。
 */
export function calcRequiredWallQuantityWoodPre2025(opts: {
  floorAreaM2: number;
  stories: number;
  targetStory: number;
  roofWeight: 'light' | 'heavy';
  windAreaM2: number;
  softGround?: boolean;
  windCoefOverride?: number;
}): {
  earthquake_cm: number | null;
  wind_cm: number | null;
  required_cm: number | null;
  verdict: '検算可' | '未検算';
  notes: string[];
} {
  const { floorAreaM2, stories, targetStory, roofWeight, windAreaM2, softGround, windCoefOverride } = opts;
  const notes: string[] = [
    '【ご注意】改正前の基準 (令46条4項 表2) で計算しています。この基準は2025年4月1日施行の' +
    '改正で廃止され、経過措置も令和8年3月31日着手分をもって終了しています。' +
    '現在着手する建築物には改正後の基準 (荷重の実態に応じた算定式) が適用されます。',
  ];

  // 改正前の令46条4項 表2 — 地震力に対する必要壁量 (cm/㎡)。全6条件 × 屋根2種。
  const earthquakeCoef: Record<string, number> = {
    'light_1s_1f': 11, 'heavy_1s_1f': 15,   // 階数1 (平屋)
    'light_2s_1f': 29, 'heavy_2s_1f': 33,   // 階数2 の1階
    'light_2s_2f': 15, 'heavy_2s_2f': 21,   // 階数2 の2階
    'light_3s_1f': 46, 'heavy_3s_1f': 50,   // 階数3 の1階
    'light_3s_2f': 34, 'heavy_3s_2f': 39,   // 階数3 の2階
    'light_3s_3f': 18, 'heavy_3s_3f': 24,   // 階数3 の3階
  };

  const key = `${roofWeight}_${stories}s_${targetStory}f`;
  const eqCoefBase = earthquakeCoef[key];

  // ★ 未登録の条件で別の値へ置き換えない。置き換えると壁量不足を「適合」と表示してしまう。
  if (eqCoefBase === undefined) {
    notes.push(
      `階数${stories}・${targetStory}階・${roofWeight === 'light' ? '軽い屋根' : '重い屋根'} の必要壁量の係数を当システムは持っていません。` +
      `改正前の令46条4項 表2 が定めるのは階数3までです。階数4以上、または表2の範囲外の建物は、` +
      `壁量計算ではなく構造計算 (許容応力度計算以上) が必要です。設計者にご確認ください。`
    );
    return { earthquake_cm: null, wind_cm: null, required_cm: null, verdict: '未検算', notes };
  }

  // 改正前の令46条4項ただし書 — 軟弱地盤の指定区域では表2の数値を1.5倍する
  const softGroundFactor = softGround ? 1.5 : 1.0;
  if (softGround) {
    notes.push('特定行政庁が指定する軟弱地盤区域として、必要壁量を1.5倍しています (改正前の令46条4項ただし書)。');
  } else {
    notes.push('軟弱地盤の指定区域ではない前提で算定しています。指定区域内の場合は必要壁量が1.5倍になります。');
  }
  const earthquake_cm = floorAreaM2 * eqCoefBase * softGroundFactor;

  // 改正前の令46条4項 表3 — 風圧力に対する必要壁量。一般区域は50、指定区域は50〜75。
  let windCoef = 50;
  if (windCoefOverride !== undefined) {
    if (windCoefOverride < 50 || windCoefOverride > 75) {
      notes.push(
        `指定された風圧力の係数 ${windCoefOverride} は、改正前の令46条4項 表3 が定める範囲 (50〜75) の外です。` +
        `特定行政庁が定める数値をご確認ください。`
      );
      return { earthquake_cm: null, wind_cm: null, required_cm: null, verdict: '未検算', notes };
    }
    windCoef = windCoefOverride;
    notes.push(`特定行政庁が定める風圧力の係数 ${windCoef}cm/㎡ を用いて算定しています。`);
  } else {
    notes.push('風圧力は一般区域の50cm/㎡で算定しています。特定行政庁が指定する区域では50〜75の範囲で数値が定められます。');
  }
  const wind_cm = windAreaM2 * windCoef;

  return {
    earthquake_cm,
    wind_cm,
    required_cm: Math.max(earthquake_cm, wind_cm),
    verdict: '検算可',
    notes,
  };
}

// =============================================================================
// 4. 防火・避難 (建築基準法 21条〜27条 + 令112〜129条)
// =============================================================================

export type FireZone = 'fire' | 'quasi' | 'none';

export interface FireResistantSpec {
  /** 耐火建築物相当 */
  fireResistant: boolean;
  /** 準耐火建築物相当 */
  quasiFireResistant: boolean;
  /** 求められる壁・柱・床・梁・屋根・階段の構造等級 */
  requirements: { part: string; duration: string }[];
}

/** 用途・階数・延床から耐火要求を判定 */
export function requiredFireResistance(opts: {
  fireZone: FireZone;
  buildingType: 'residential' | 'detached' | 'store' | 'hotel' | 'hospital' | 'school' | 'factory';
  stories: number;
  floorAreaM2: number;
}): FireResistantSpec {
  const { fireZone, buildingType, stories, floorAreaM2 } = opts;

  // 防火地域 3階以上 or 延床100㎡超 → 耐火建築物
  if (fireZone === 'fire' && (stories >= 3 || floorAreaM2 > 100)) {
    return {
      fireResistant: true,
      quasiFireResistant: false,
      requirements: [
        { part: '主要構造部(柱/梁/壁/床/屋根/階段)', duration: '1〜3時間耐火' },
        { part: '外壁(延焼のおそれのある部分)', duration: '1時間耐火 + 防火設備' },
      ],
    };
  }

  // 準防火地域 4階以上 or 延床1500㎡超 → 耐火建築物
  if (fireZone === 'quasi' && (stories >= 4 || floorAreaM2 > 1500)) {
    return {
      fireResistant: true,
      quasiFireResistant: false,
      requirements: [
        { part: '主要構造部', duration: '1〜3時間耐火' },
      ],
    };
  }

  // 準防火地域 3階建て or 延床500㎡超 → 準耐火建築物
  if (fireZone === 'quasi' && (stories === 3 || floorAreaM2 > 500)) {
    return {
      fireResistant: false,
      quasiFireResistant: true,
      requirements: [
        { part: '主要構造部', duration: '45分準耐火 or 1時間準耐火' },
      ],
    };
  }

  // 特殊建築物 (ホテル/病院/学校) は規模別に耐火要求
  if (['hotel', 'hospital', 'school'].includes(buildingType) && floorAreaM2 > 200) {
    return {
      fireResistant: floorAreaM2 > 3000,
      quasiFireResistant: floorAreaM2 <= 3000,
      requirements: [{ part: '主要構造部', duration: floorAreaM2 > 3000 ? '1時間耐火' : '45分準耐火' }],
    };
  }

  return {
    fireResistant: false,
    quasiFireResistant: false,
    requirements: [{ part: '原則', duration: '一般構造で可(ただし延焼のおそれのある部分は防火設備)' }],
  };
}

/**
 * 避難 2方向避難の要否 (令121条)
 * 共同住宅/ホテル/病院/物販で床面積超過 or 階上避難距離30m超
 */
export function requires2WayEvacuation(opts: {
  buildingType: 'apartment' | 'hotel' | 'hospital' | 'store' | 'office' | 'school';
  storyFloorArea: number;
  evacuationDistanceM: number;
  isFireResistant: boolean;
}): boolean {
  const { buildingType, storyFloorArea, evacuationDistanceM, isFireResistant } = opts;
  if (evacuationDistanceM > 30) return true;
  if (buildingType === 'apartment' && storyFloorArea > 100) return true;
  if (['hotel', 'hospital'].includes(buildingType) && storyFloorArea > 100) return true;
  if (buildingType === 'store' && storyFloorArea > 1500 && !isFireResistant) return true;
  return false;
}

/** 直通階段までの歩行距離 (令120条) */
export function maxEvacuationDistanceM(opts: {
  buildingType: string;
  isFireResistant: boolean;
  isMajorStruct: boolean;
}): number {
  const { isFireResistant, isMajorStruct } = opts;
  // 耐火 + 主要構造部が準不燃以上 = 50m, 耐火のみ = 40m, その他 = 30m
  if (isFireResistant && isMajorStruct) return 50;
  if (isFireResistant) return 40;
  return 30;
}

// =============================================================================
// 5. 建築士法 (設計・監理ができる規模)
// =============================================================================

export type ArchitectLicense = 'first' | 'second' | 'wood' | 'none';

/** 設計可能か判定 (建築士法3条〜3条の3) */
export function canDesign(
  license: ArchitectLicense,
  opts: { type: StructureType; stories: number; heightM: number; eaveHeightM: number; floorAreaM2: number; specialUse?: boolean },
): { allowed: boolean; reason: string } {
  const { type, stories, heightM, eaveHeightM, floorAreaM2, specialUse } = opts;

  // 1級建築士専属範囲 (建築士法3条)
  const requiresFirst =
    (type !== 'wood' && floorAreaM2 > 300) ||
    stories >= 3 ||
    heightM > 13 ||
    eaveHeightM > 9 ||
    floorAreaM2 > 1000 ||
    specialUse;

  if (requiresFirst) {
    if (license === 'first') return { allowed: true, reason: '1級建築士範囲' };
    return { allowed: false, reason: '1級建築士の業務独占範囲です(建築士法3条)' };
  }

  // 2級建築士範囲
  if (license === 'first' || license === 'second') {
    return { allowed: true, reason: '2級建築士以上で設計可' };
  }

  // 木造建築士範囲 (2階以下/延床100㎡超300㎡以下の木造)
  if (type === 'wood' && stories <= 2 && floorAreaM2 > 100 && floorAreaM2 <= 300) {
    if (license === 'wood') return { allowed: true, reason: '木造建築士範囲' };
    return { allowed: false, reason: '木造建築士以上が必要' };
  }

  // 小規模 (100㎡以下 木造 1〜2階) は無資格可
  if (type === 'wood' && stories <= 2 && floorAreaM2 <= 100) {
    return { allowed: true, reason: '無資格でも設計可(建築士法3条の3)' };
  }

  return { allowed: false, reason: '適切な建築士資格が必要' };
}

// =============================================================================
// 6. 確認申請フロー
// =============================================================================

export type PermitStage = '事前協議' | '確認申請' | '中間検査' | '完了検査' | '検査済証交付';

export interface PermitFlow {
  stages: PermitStage[];
  estimatedDays: number;
  requiredDocs: string[];
  submitTo: '特定行政庁' | '指定確認検査機関';
}

export function buildPermitFlow(opts: { type: StructureType; stories: number; floorAreaM2: number; specialUse: boolean }): PermitFlow {
  const { stories, floorAreaM2, specialUse } = opts;
  const needsIntermediate = stories >= 3 || floorAreaM2 > 500 || specialUse;
  const stages: PermitStage[] = ['事前協議', '確認申請'];
  if (needsIntermediate) stages.push('中間検査');
  stages.push('完了検査', '検査済証交付');

  const docs = [
    '確認申請書(第1〜6面)',
    '付近見取図', '配置図', '各階平面図', '立面図(4面)', '断面図(2面以上)',
    '面積表(建築面積/延床面積/用途別)',
    '仕様書', '構造図(軸組図/基礎伏図/床伏図/小屋伏図)',
    '構造計算書', '設備図(給排水衛生/電気/空調/換気)',
    '省エネ計算書(外皮/一次エネ)',
    '敷地求積図', 'シックハウス対策資料(24時間換気 + F☆☆☆☆)',
  ];
  if (specialUse) docs.push('特殊建築物定期報告書', '防災計画書');

  return {
    stages,
    estimatedDays: floorAreaM2 > 500 ? 35 : 14,
    requiredDocs: docs,
    submitTo: floorAreaM2 > 10000 ? '特定行政庁' : '指定確認検査機関',
  };
}

// =============================================================================
// 7. 省エネ基準 (建築物省エネ法 — 2025年4月 全建築物義務化)
// =============================================================================

export interface EnergyPerformance {
  /** 外皮平均熱貫流率 W/(㎡·K) */
  ua: number;
  /** 冷房期の平均日射熱取得率 */
  etaAC: number;
  /** 一次エネルギー消費量基準値に対する比率 (BEI, 1.0以下が基準適合) */
  bei: number;
}

/** 地域区分 1〜8 (北から南) と UA 基準値 */
export const ENERGY_REGIONS: Readonly<{ region: number; representative_city: string; ua_threshold: number; etaAC_threshold: number }[]> = Object.freeze([
  { region: 1, representative_city: '旭川', ua_threshold: 0.46, etaAC_threshold: Infinity },
  { region: 2, representative_city: '札幌', ua_threshold: 0.46, etaAC_threshold: Infinity },
  { region: 3, representative_city: '盛岡', ua_threshold: 0.56, etaAC_threshold: Infinity },
  { region: 4, representative_city: '仙台', ua_threshold: 0.75, etaAC_threshold: Infinity },
  { region: 5, representative_city: '宇都宮', ua_threshold: 0.87, etaAC_threshold: 3.0 },
  { region: 6, representative_city: '東京', ua_threshold: 0.87, etaAC_threshold: 2.8 },
  { region: 7, representative_city: '鹿児島', ua_threshold: 0.87, etaAC_threshold: 2.7 },
  { region: 8, representative_city: '那覇', ua_threshold: Infinity, etaAC_threshold: 6.7 },
]);

export function checkEnergyCompliance(perf: EnergyPerformance, region: number): { ua_ok: boolean; etaAC_ok: boolean; bei_ok: boolean; overall: boolean } {
  const r = ENERGY_REGIONS.find(x => x.region === region);
  if (!r) throw new Error(`地域区分 ${region} は 1〜8 でなければならない`);
  const ua_ok = perf.ua <= r.ua_threshold;
  const etaAC_ok = perf.etaAC <= r.etaAC_threshold;
  const bei_ok = perf.bei <= 1.0;
  return { ua_ok, etaAC_ok, bei_ok, overall: ua_ok && etaAC_ok && bei_ok };
}

// =============================================================================
// 8. JIS 主要規格 (設計・施工・材料)
// =============================================================================

export const JIS_STANDARDS: Readonly<Record<string, { code: string; title: string; category: string }>> = Object.freeze({
  A5308: { code: 'JIS A 5308', title: 'レディーミクストコンクリート', category: 'concrete' },
  G3101: { code: 'JIS G 3101', title: '一般構造用圧延鋼材(SS材)', category: 'steel' },
  G3106: { code: 'JIS G 3106', title: '溶接構造用圧延鋼材(SM材)', category: 'steel' },
  G3136: { code: 'JIS G 3136', title: '建築構造用圧延鋼材(SN材)', category: 'steel' },
  Z3211: { code: 'JIS Z 3211', title: '軟鋼用被覆アーク溶接棒', category: 'weld' },
  A1107: { code: 'JIS A 1107', title: 'コンクリートからのコアの採取方法及び圧縮強度試験方法', category: 'test' },
  A5430: { code: 'JIS A 5430', title: '繊維強化セメント板', category: 'finish' },
  A6909: { code: 'JIS A 6909', title: '建築用仕上塗材', category: 'finish' },
  A4706: { code: 'JIS A 4706', title: 'サッシ', category: 'opening' },
  A6519: { code: 'JIS A 6519', title: '建築用鋼製床下地材', category: 'structure' },
  F7001: { code: 'JAS 合板', title: '構造用合板', category: 'wood' },
});

// =============================================================================
// 9. 総合ヘルパー: 敷地概要から「建てられる建物の上限」を推論
// =============================================================================

export interface SiteAnalysis {
  district: UseDistrictCode;
  siteAreaM2: number;
  frontRoadWidthM: number;
  fireZone: FireZone;
  zonedCoverage: number;
  zonedFar: number;
  corner?: boolean;
}

export interface BuildableEnvelope {
  maxBuildingArea: number;
  maxFloorArea: number;
  estimatedMaxStories: number;
  restrictions: string[];
  recommendedStructure: StructureType;
  cautions: string[];
}

export function analyzeSiteBuildable(site: SiteAnalysis): BuildableEnvelope {
  const effectiveFar = calcFloorAreaRatioByRoad(site.frontRoadWidthM, site.district, site.zonedFar);
  const effectiveCoverage = calcBuildingCoverageWithRelief(site.zonedCoverage, { corner: site.corner, fireZone: site.fireZone, fireResistant: site.fireZone === 'fire' });
  const maxBuildingArea = site.siteAreaM2 * effectiveCoverage / 100;
  const maxFloorArea = site.siteAreaM2 * effectiveFar / 100;
  const estimatedMaxStories = Math.max(1, Math.floor(maxFloorArea / maxBuildingArea));
  const restrictions: string[] = [
    `建ぺい率 ${effectiveCoverage}% → 建築面積上限 ${Math.floor(maxBuildingArea * 100) / 100}㎡`,
    `容積率 ${effectiveFar}% → 延床上限 ${Math.floor(maxFloorArea * 100) / 100}㎡`,
  ];
  if (site.frontRoadWidthM < 4) restrictions.push('⚠ 前面道路4m未満。42条2項道路(セットバック)の可能性あり');
  const d = USE_DISTRICTS[site.district];
  if (d.absoluteHeightLimit) restrictions.push(`絶対高さ制限 ${d.absoluteHeightLimit}m`);
  if (d.northernSlopeRestriction) restrictions.push('北側斜線制限あり');
  if (d.shadowRegulationApplicable) restrictions.push('日影規制の地区指定あり(自治体確認)');
  const cautions: string[] = [
    '確認申請前に特定行政庁の事前協議を強く推奨',
    '地盤調査(SWS/ボーリング)は必須',
    '既存道路後退 + 越境物確認',
  ];
  const recommendedStructure: StructureType =
    estimatedMaxStories <= 2 && maxFloorArea <= 300 ? 'wood' :
    estimatedMaxStories <= 4 ? 'steel' : 'rc';
  return { maxBuildingArea, maxFloorArea, estimatedMaxStories, restrictions, recommendedStructure, cautions };
}
