#!/usr/bin/env bash
# 当社の実行部品へ入る前に試用の期限と対象を確かめる。
if [ "${BASH_SOURCE[0]}" = "$0" ]; then
_sl_trial_runtime="${SOLOPTILINK_HOME:-$HOME/.soloptilink}/lib/free-trial/runtime_guard.py"
if [ ! -f "$_sl_trial_runtime" ]; then
  _sl_trial_runtime="$HOME/.soloptilink/lib/free-trial/runtime_guard.py"
fi
if [ ! -f "$_sl_trial_runtime" ]; then
  _sl_trial_runtime="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/../../../lib/free-trial/runtime_guard.py"
fi
if [ -f "$_sl_trial_runtime" ]; then
  python3 "$_sl_trial_runtime" soloptilink-japan || exit $?
else
  python3 - "${SOLOPTILINK_HOME:-$HOME/.soloptilink}" "$HOME/.soloptilink" <<'SL_TRIAL_CHECK'
import json, os, sys
from pathlib import Path
for root in map(Path, sys.argv[1:]):
    trial = os.path.lexists(root / '.free-trial/marker.json')
    try:
        trial = trial or json.loads((root / 'activation.json').read_text(encoding='utf-8-sig')).get('plan_kind') == 'trial'
    except (OSError, ValueError, AttributeError):
        pass
    if trial:
        print('無料トライアルの確認部品が見つからないため、この機能は実行できません。', file=sys.stderr)
        raise SystemExit(3)
SL_TRIAL_CHECK
  _sl_trial_result=$?
  if [ "$_sl_trial_result" -ne 0 ]; then exit "$_sl_trial_result"; fi
  unset _sl_trial_result
fi
unset _sl_trial_runtime
fi
# SOLOPTILINK-TRIAL-ENTRY:END

# 日本語Windowsで python3 の出力が cp932 になり途中停止するのを防ぐ (2026-09-04)
export PYTHONIOENCODING="utf-8:replace"
export PYTHONUTF8=1
# ドメイン辞書 JSON の検証スクリプト (SIer Marketplace 貢献受付用)
# v3 (Phase 8): 拡張法令(PL/景表/特商/食品衛生/食品表示/薬機/旅館/宅建/児福/安衛/育介/派遣) 対応
#               + recommended_drawings / estimate_unit_price_refs (Phase 9 準備) の任意検証
# 使い方: bash validate_domain.sh <domain.json>
#
# ★外部の方から届いた辞書を検査する部品のため、辞書の道（ファイル名）は届いた側が決められる（2026-11-12）。
#   - 道を Python・Node の命令文の中へ埋めない。必ず引数（sys.argv / process.argv）で渡す。
#     埋めると、名前に「'」を入れるだけで任意の命令を動かせてしまう（11-12 の審査で発見・砂箱で再現）。
#   - Python は -I で起動し、今いる場所に置かれた json.py などを読み込まない（-I は PYTHONUTF8 を
#     読まないため、同じ働きの -X utf8 を付ける）。
#   - 結果の JSON に載せる道は JSON の書き方で包む（名前に「"」を入れて ok などを書き足させない）。
set -u

FILE="${1:-}"
if [ -z "$FILE" ] || [ ! -f "$FILE" ]; then
  echo '{"ok":false,"error":"ファイルが指定されていません / 存在しません"}'
  exit 2
fi
# 道が「-」で始まると grep・jq がそれを自分の設定として読み、個人情報の検査が素通りになるため、
# 同じファイルを指す「./」付きの道に直す。
case "$FILE" in
  -*) FILE="./$FILE" ;;
esac

# JSON パーサの検出（python3 > node > jq > 手動）
detect_parser() {
  if command -v python3 >/dev/null 2>&1; then echo "python"; return; fi
  if command -v node >/dev/null 2>&1; then echo "node"; return; fi
  if command -v jq >/dev/null 2>&1; then echo "jq"; return; fi
  echo "manual"
}
PARSER=$(detect_parser)

# JSON 文法チェック
case "$PARSER" in
  python)
    python3 -I -X utf8 -c 'import json,sys; json.load(open(sys.argv[1]))' "$FILE" 2>/dev/null || { echo '{"ok":false,"error":"JSON文法エラー"}'; exit 1; }
    ;;
  node)
    node -e 'JSON.parse(require("fs").readFileSync(process.argv[1],"utf8"))' -- "$FILE" 2>/dev/null || { echo '{"ok":false,"error":"JSON文法エラー"}'; exit 1; }
    ;;
  jq)
    jq empty "$FILE" 2>/dev/null || { echo '{"ok":false,"error":"JSON文法エラー"}'; exit 1; }
    ;;
  manual)
    echo '{"ok":false,"error":"JSONパーサが見つかりません(python3/node/jqのいずれかが必要)"}'; exit 2
    ;;
esac

# required フィールドチェック
REQUIRED_FIELDS=(industry industry_ja version applicable_laws terminology mandatory_fields ui_hints)
MISSING=()
for f in ${REQUIRED_FIELDS[@]+"${REQUIRED_FIELDS[@]}"}; do
  VAL="MISSING"
  case "$PARSER" in
    python)
      VAL=$(python3 -I -X utf8 -c 'import json,sys; d=json.load(open(sys.argv[1])); print("OK" if sys.argv[2] in d else "MISSING")' "$FILE" "$f" 2>/dev/null)
      ;;
    node)
      VAL=$(node -e 'const d=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8")); console.log(d[process.argv[2]]!==undefined?"OK":"MISSING")' -- "$FILE" "$f" 2>/dev/null)
      ;;
    jq)
      if jq -e ".$f" "$FILE" >/dev/null 2>&1; then VAL="OK"; fi
      ;;
  esac
  [ "$VAL" != "OK" ] && MISSING+=("$f")
done

# 禁止事項
PII_HITS=$(grep -c -E '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}|0[789]0-?[0-9]{4}-?[0-9]{4}' "$FILE" 2>/dev/null | head -1 | tr -d '\n' || true)
PII_HITS=${PII_HITS:-0}
EXT_URLS=$(grep -c -E 'https?://[^"]+\?[a-zA-Z0-9_=&-]+' "$FILE" 2>/dev/null | head -1 | tr -d '\n' || true)
EXT_URLS=${EXT_URLS:-0}

# KPI / mandatory_fields カテゴリ数
KPI_COUNT=0
MF_COUNT=0
case "$PARSER" in
  python)
    KPI_COUNT=$(python3 -I -X utf8 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(len(d.get("ui_hints",{}).get("dashboard_kpi",[])))' "$FILE" 2>/dev/null || echo 0)
    MF_COUNT=$(python3 -I -X utf8 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(len(d.get("mandatory_fields",{})))' "$FILE" 2>/dev/null || echo 0)
    ;;
  node)
    KPI_COUNT=$(node -e 'const d=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8")); console.log((d.ui_hints&&d.ui_hints.dashboard_kpi||[]).length)' -- "$FILE" 2>/dev/null || echo 0)
    MF_COUNT=$(node -e 'const d=JSON.parse(require("fs").readFileSync(process.argv[1],"utf8")); console.log(Object.keys(d.mandatory_fields||{}).length)' -- "$FILE" 2>/dev/null || echo 0)
    ;;
  jq)
    KPI_COUNT=$(jq '.ui_hints.dashboard_kpi | length' "$FILE" 2>/dev/null || echo 0)
    MF_COUNT=$(jq '.mandatory_fields | keys | length' "$FILE" 2>/dev/null || echo 0)
    ;;
esac

# スコア
SCORE=100
[ ${#MISSING[@]} -gt 0 ] && SCORE=$((SCORE - ${#MISSING[@]} * 15))
[ "$PII_HITS" -gt 0 ] && SCORE=$((SCORE - 30))
[ "$EXT_URLS" -gt 0 ] && SCORE=$((SCORE - 10))
[ "$KPI_COUNT" -lt 3 ] && SCORE=$((SCORE - 10))
[ "$MF_COUNT" -lt 2 ] && SCORE=$((SCORE - 10))
[ "$SCORE" -lt 0 ] && SCORE=0

OK="true"
[ ${#MISSING[@]} -gt 0 ] || [ "$PII_HITS" -gt 0 ] && { [ ${#MISSING[@]} -gt 0 ] && OK="false"; [ "$PII_HITS" -gt 0 ] && OK="false"; }

MISSING_JSON="[]"
if [ ${#MISSING[@]} -gt 0 ]; then
  MISSING_JSON=$(printf '%s\n' ${MISSING[@]+"${MISSING[@]}"} | awk 'BEGIN{printf "["} {printf (NR>1?",":"") "\"" $0 "\""} END{printf "]"}')
fi

# 結果に載せる道を JSON の文字列として包む（ふつうの名前では、包む前と同じ文字になる）。
# 包めなかったときは、道をそのまま載せずに null にする。
FILE_JSON=""
case "$PARSER" in
  python)
    FILE_JSON=$(python3 -I -X utf8 -c 'import json,sys; print(json.dumps(sys.argv[1], ensure_ascii=False))' "$FILE" 2>/dev/null)
    ;;
  node)
    FILE_JSON=$(node -e 'console.log(JSON.stringify(process.argv[1]))' -- "$FILE" 2>/dev/null)
    ;;
  jq)
    FILE_JSON=$(jq -n --arg f "$FILE" '$f' 2>/dev/null)
    ;;
esac
[ -n "$FILE_JSON" ] || FILE_JSON="null"

cat <<EOF
{
  "ok": $OK,
  "file": $FILE_JSON,
  "parser": "$PARSER",
  "score": $SCORE,
  "missing_fields": $MISSING_JSON,
  "pii_hits": $PII_HITS,
  "external_url_hits": $EXT_URLS,
  "kpi_count": $KPI_COUNT,
  "mandatory_field_categories": $MF_COUNT,
  "decision": "$([ "$OK" = "true" ] && [ "$SCORE" -ge 80 ] && echo 'ACCEPTED' || echo 'REJECTED')"
}
EOF

[ "$OK" = "true" ] && [ "$SCORE" -ge 80 ] && exit 0 || exit 1
