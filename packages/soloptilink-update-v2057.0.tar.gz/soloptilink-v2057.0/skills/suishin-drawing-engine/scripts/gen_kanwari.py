#!/usr/bin/env python3
"""管割図（Pipe-Segment Layout Drawing）自動生成 v2

実寸mm描画 + View/Panel 自動縮尺（DRAWING_API.md v2 準拠）。
外部契約（KanwariInput.from_json / draw_kanwari のシグネチャ・戻り値キー）は変更禁止。
管割ロジック compute_pipe_segments の計算結果も変更禁止。
"""
from __future__ import annotations

# 当社の実行部品へ入る前に試用の期限と対象を確かめる。
if __name__ == "__main__":
    import sys as _sl_trial_sys
    from pathlib import Path as _SlTrialPath
    _sl_trial_sys.path.insert(0, str((_SlTrialPath(__file__).resolve().parent / ".").resolve()))
    from _trial_guard import require_runtime as _require_trial_runtime
    _require_trial_runtime("suishin-drawing-engine")
# SOLOPTILINK-TRIAL-ENTRY:END



import json
import math
import sys
from collections import defaultdict
from dataclasses import dataclass, field, fields
from typing import Dict, List, Optional

from dxf_base import OgumiDXF, TH_TINY, TH_SMALL, TH_BODY, TH_HEAD
from layout import View, Panel, split_rows, split_cols


# ---- 入力データモデル（外部契約 — フィールド名・from_json シグネチャ変更禁止） ----

@dataclass
class Curve:
    """曲線区間"""
    start_station_m: float   # 起点からの位置 (m)
    radius_m: float          # 曲線半径 R (m)
    direction: str = "L"     # "L"=左曲、"R"=右曲
    ia_deg: Optional[float] = None       # 交角 IA
    arc_length_m: Optional[float] = None  # 弧長

    def resolve(self) -> None:
        if self.ia_deg is None and self.arc_length_m is not None:
            self.ia_deg = self.arc_length_m * 180.0 / (math.pi * self.radius_m)
        elif self.arc_length_m is None and self.ia_deg is not None:
            self.arc_length_m = self.ia_deg * math.pi * self.radius_m / 180.0
        elif self.ia_deg is None and self.arc_length_m is None:
            raise ValueError(
                f"曲線 sta={self.start_station_m}: IAまたは弧長のどちらかを指定してください"
            )


@dataclass
class Span:
    """1スパン (発進立坑〜到達立坑)"""
    name: str
    length_m: float
    diameter_mm: int
    machine_type: str = ""
    curves: List[Curve] = field(default_factory=list)
    start_shaft: str = ""
    arrival_shaft: str = ""


# 管割図が使う区間の項目。案件の区間 (spans[]) には推力計算書が使う土質 (soil)・
# 土被り (depth_m) なども並ぶ。管割図はそれらを使わないので読み飛ばす
# (2026-10-23 是正: 受け付けずに例外で止まり、推力計算書まで作れなかった)。
SPAN_FIELDS = frozenset(f.name for f in fields(Span))


def span_from_dict(sp: dict) -> Span:
    """案件の区間 1 件 (辞書) から管割図の Span を作る。管割図が使わない項目は読み飛ばす。"""
    curves = []
    for c in sp.get("curves") or []:
        cc = Curve(**c)
        cc.resolve()
        curves.append(cc)
    kw = {k: v for k, v in sp.items() if k in SPAN_FIELDS and k != "curves"}
    return Span(curves=curves, **kw)


@dataclass
class KanwariInput:
    """管割図入力（外部契約 — 変更禁止）"""
    project_name: str
    drawing_no: str
    client: str
    method: str
    spans: List[Span]
    pipe_lengths_m: List[float] = field(default_factory=lambda: [2.43, 1.2, 1.0, 0.6])
    paper: str = "A1"
    scale: float = 100.0
    designer: str = ""

    @classmethod
    def from_json(cls, path: str) -> "KanwariInput":
        d = json.load(open(path, encoding="utf-8"))
        spans = [span_from_dict(sp) for sp in d["spans"]]
        return cls(
            project_name=d["project_name"],
            drawing_no=d.get("drawing_no", ""),
            client=d.get("client", ""),
            method=d["method"],
            spans=spans,
            pipe_lengths_m=d.get("pipe_lengths_m", [2.43, 1.2, 1.0, 0.6]),
            paper=d.get("paper", "A1"),
            scale=float(d.get("scale", 100.0)),
            designer=d.get("designer", ""),
        )


# ---- 管割ロジック（計算結果・シグネチャ変更禁止） ----

def compute_pipe_segments(span: Span, pipe_lengths: List[float]) -> List[dict]:
    """
    スパンの推進延長を、利用可能な管長ラインアップから最適配列する。
    曲線部は最短管を優先し、直線部は最長管を優先する。
    戻り: [{"no": 1, "length": 2.43, "station_start": 0.0, "station_end": 2.43,
             "in_curve": False, "curve_no": None}, ...]
    """
    L = span.length_m
    curve_ranges = []
    for i, c in enumerate(span.curves):
        curve_ranges.append((i, c.start_station_m,
                             c.start_station_m + (c.arc_length_m or 0.0)))

    def in_curve(station_start: float, station_end: float) -> Optional[int]:
        mid = (station_start + station_end) / 2
        for idx, s, e in curve_ranges:
            if s <= mid <= e:
                return idx
        return None

    segments = []
    remaining = L
    station = 0.0
    no = 1
    min_pipe = min(pipe_lengths)
    sorted_pipes_desc = sorted(pipe_lengths, reverse=True)
    sorted_pipes_asc = sorted(pipe_lengths)

    while remaining > 1e-6:
        curve_idx = in_curve(station, station + min_pipe)
        candidates = sorted_pipes_asc if curve_idx is not None else sorted_pipes_desc
        chosen = None
        for p in candidates:
            if p <= remaining + 1e-6:
                chosen = p
                break
        if chosen is None:
            chosen = min_pipe
        actual = min(chosen, remaining)
        seg = {
            "no": no,
            "length": round(actual, 3),
            "station_start": round(station, 3),
            "station_end": round(station + actual, 3),
            "in_curve": in_curve(station, station + actual) is not None,
            "curve_no": in_curve(station, station + actual),
        }
        segments.append(seg)
        station += actual
        remaining -= actual
        no += 1
        if no > 10000:
            raise RuntimeError("管割ループが収束しません")
    return segments


# ---- 描画ヘルパー（View の実寸mm空間に書く。紙面mm換算を行わない） ----

def _draw_span_to_view(v: View, span: Span, segs: List[dict]) -> None:
    """スパン1本分を View の実寸mm空間に描く。

    座標系:
      X: 0（発進立坑中心）→ span.length_m * 1000（到達立坑中心）
      Y: 管中心を 0 とする対称軸。呼び径半径 = span.diameter_mm / 2
    """
    L_mm: float = span.length_m * 1000.0          # 推進延長（実寸mm）
    r_mm: float = span.diameter_mm / 2.0          # 呼び径半径（実寸mm）

    # --- 中心線（一点鎖線） ---
    v.line((0.0, 0.0), (L_mm, 0.0), "1-CENTER")

    # --- 立坑シンボル（呼び径に比例した矩形） ---
    # 幅: 呼び径 × 2、高さ: 呼び径 × 4（実寸mm）
    sw: float = span.diameter_mm * 2.0
    sh: float = span.diameter_mm * 4.0
    v.rect(-sw / 2, -sh / 2,  sw / 2, sh / 2, "14-SHAFT")           # 発進
    v.rect(L_mm - sw / 2, -sh / 2, L_mm + sw / 2, sh / 2, "14-SHAFT")  # 到達

    # 立坑名（立坑上端の紙面mm位置から 1.5mm 上）
    v.label(span.start_shaft or "発進立坑",
            (0.0, sh / 2), TH_SMALL, "14-SHAFT",
            align="c_b", dy=1.5, priority=2)
    v.label(span.arrival_shaft or "到達立坑",
            (L_mm, sh / 2), TH_SMALL, "14-SHAFT",
            align="c_b", dy=1.5, priority=2)

    # --- 曲線ゾーン（ハッチングで区別） ---
    hatch_scale = max(0.5, span.diameter_mm / 500.0)
    for curve in span.curves:
        cs_mm = curve.start_station_m * 1000.0
        ce_mm = cs_mm + (curve.arc_length_m or 0.0) * 1000.0
        v.hatch_rect(cs_mm, -r_mm, ce_mm, r_mm,
                     pattern="ANSI31", layer="12-CURVE",
                     pattern_scale=hatch_scale)

    # --- 管セグメント（実寸mm 矩形 + 継手線） ---
    n_segs = len(segs)
    # 管本数が多い場合は管番号を間引き（最大20本表示）
    label_every = max(1, n_segs // 20)

    for seg in segs:
        x1 = seg["station_start"] * 1000.0
        x2 = seg["station_end"] * 1000.0
        layer = "12-CURVE" if seg["in_curve"] else "11-PIPE"
        v.rect(x1, -r_mm, x2, r_mm, layer)
        # 各管の始端に継手線
        v.line((x1, -r_mm * 1.35), (x1, r_mm * 1.35), "13-JOINT")

    # 末端継手
    v.line((L_mm, -r_mm * 1.35), (L_mm, r_mm * 1.35), "13-JOINT")

    # --- 管番号ラベル（間引き、管中心上部に配置） ---
    for seg in segs:
        # 最初の管・最後の管・label_every 番目の管だけ表示
        if seg["no"] != 1 and seg["no"] != n_segs and seg["no"] % label_every != 1:
            continue
        xc = (seg["station_start"] + seg["station_end"]) * 500.0  # 中点（実寸mm）
        v.label(str(seg["no"]), (xc, r_mm), TH_TINY, "3-TEXT",
                align="c_b", dy=0.5, priority=8)

    # --- 管長代表ラベル（各管長種別の最初の1本だけ表示） ---
    shown_lens: set = set()
    for seg in segs:
        lk = seg["length"]
        if lk not in shown_lens:
            shown_lens.add(lk)
            xc = (seg["station_start"] + seg["station_end"]) * 500.0
            v.label(f"L={lk}m", (xc, -r_mm), TH_TINY, "9-DIM-TEXT",
                    align="c_t", dy=-0.5, priority=7)

    # --- 曲線諸元注記 ---
    for ci, curve in enumerate(span.curves):
        cs_mm = curve.start_station_m * 1000.0
        ce_mm = cs_mm + (curve.arc_length_m or 0.0) * 1000.0
        xc = (cs_mm + ce_mm) / 2.0
        ann = (
            f"曲線{ci + 1}  R={curve.radius_m}m  "
            f"IA={curve.ia_deg:.1f}°({curve.direction})\n"
            f"弧長={curve.arc_length_m:.2f}m"
        )
        # 複数曲線が重ならないよう dy を段ずらし（LabelPlacer も衝突を解消する）
        dy_base = 2.5 + ci * (TH_TINY * 2 * 1.4)
        v.label(ann, (xc, r_mm), TH_TINY, "12-CURVE",
                align="c_b", dy=dy_base, priority=3)

    # --- スパン全長寸法（管中心下側 14mm に寸法線） ---
    v.dim((0.0, 0.0), (L_mm, 0.0), orient="h", offset_mm=14.0,
          text=f"L={span.length_m}m")


def _build_pipe_length_table_rows(
    all_segments: List[dict],
    pipe_lengths: List[float],
) -> List[List[str]]:
    """管長別集計表の行データを構築する（ヘッダ含む）"""
    count_all: Dict[float, int] = defaultdict(int)
    count_curve: Dict[float, int] = defaultdict(int)

    for entry in all_segments:
        for seg in entry["segments"]:
            lk = seg["length"]
            count_all[lk] += 1
            if seg["in_curve"]:
                count_curve[lk] += 1

    header = ["管長(m)", "本数", "延長(m)", "曲線内"]
    rows: List[List[str]] = [header]

    total_pipes = 0
    total_len = 0.0
    # 標準管長の順序で出力（大→小）、端数管は最後
    standard = sorted(pipe_lengths, reverse=True)
    extra = sorted([k for k in count_all if k not in standard], reverse=True)
    ordered = standard + extra

    for lk in ordered:
        if lk not in count_all:
            continue
        cnt = count_all[lk]
        ext = lk * cnt
        total_pipes += cnt
        total_len += ext
        rows.append([
            f"{lk}",
            str(cnt),
            f"{round(ext, 2):.2f}",
            str(count_curve.get(lk, 0)),
        ])
    rows.append(["合計", str(total_pipes), f"{round(total_len, 2):.2f}", ""])
    return rows


def _build_span_summary_rows(
    all_segments: List[dict],
    spans: List[Span],
) -> List[List[str]]:
    """スパン別集計行データ"""
    rows: List[List[str]] = [["スパン", "本数", "総延長(m)"]]
    for entry, sp in zip(all_segments, spans):
        segs = entry["segments"]
        total = round(sum(s["length"] for s in segs), 2)
        rows.append([sp.name[:12], str(len(segs)), f"{total:.2f}"])
    return rows


# ---- 外部公開 API ----

def draw_kanwari(inp: KanwariInput, out_path: str) -> dict:
    """管割図を描画してDXF保存。戻り値の構造は外部契約（変更禁止）。"""
    # タイトル用の呼び径文字列（複数径スパンがあれば併記）
    diams = sorted(set(sp.diameter_mm for sp in inp.spans))
    diam_str = "/".join(f"φ{d}" for d in diams)
    total_length = sum(sp.length_m for sp in inp.spans)

    d = OgumiDXF(
        paper=inp.paper,
        scale=inp.scale,
        title=f"管割図（{inp.method} {diam_str}）",
        drawing_no=inp.drawing_no,
        project=inp.project_name,
        client=inp.client,
        designer=inp.designer,
        extra_meta={
            "工法": inp.method,
            "総スパン数": str(len(inp.spans)),
            "総推進延長": f"{total_length}m",
        },
    )

    main = d.content_panel()

    # レイアウト: 左 3/4 = 管割図エリア、右 1/4 = 集計表・凡例
    pipe_area, table_area = split_cols(main, [3, 1], gap=8)

    # スパン数に応じて管割図エリアを縦分割
    n = len(inp.spans)
    if n == 1:
        span_panels = [pipe_area]
    else:
        span_panels = split_rows(pipe_area, [1] * n, gap=6)

    # 各スパンを View へ描画し、OgumiDXF へ配置
    all_segments: List[dict] = []
    for span, panel in zip(inp.spans, span_panels):
        segs = compute_pipe_segments(span, inp.pipe_lengths_m)
        all_segments.append({"span": span.name, "segments": segs})

        n_segs = len(segs)
        view_title = (
            f"【{span.name}】  φ{span.diameter_mm}  "
            f"L={span.length_m}m  ({span.machine_type})  {n_segs}本"
        )
        v = View(panel, preferred_scale=inp.scale,
                 title=view_title, pad_mm=5.0, title_height=TH_SMALL)
        _draw_span_to_view(v, span, segs)
        d.place(v)

    # ---- 集計表（右エリア上部・紙面mm で配置） ----
    tbl_x = table_area.x
    tbl_top = table_area.y + table_area.h   # 右エリアの上端

    # 管長別集計表
    pipe_rows = _build_pipe_length_table_rows(all_segments, inp.pipe_lengths_m)
    col_pipe = [22, 12, 22, 12]  # 合計 68mm
    pipe_tbl_rect = d.table(
        tbl_x, tbl_top, pipe_rows, col_pipe,
        row_h=5.5, height=TH_TINY, header=True,
        title="【管割集計】", title_height=TH_SMALL,
    )

    # スパン別概要表（管長集計表の下）
    span_rows = _build_span_summary_rows(all_segments, inp.spans)
    col_span = [35, 12, 21]  # 合計 68mm
    span_tbl_rect = d.table(
        tbl_x, pipe_tbl_rect.y1 - 6, span_rows, col_span,
        row_h=5.5, height=TH_TINY, header=True,
        title="【スパン別】", title_height=TH_SMALL,
    )

    # ---- 凡例（右エリア下部） ----
    # 凡例の高さ見積もり: タイトル + 5エントリ × 約 4.5mm ≈ 30mm
    legend_y = table_area.y + 35
    d.legend(
        tbl_x, legend_y,
        [
            ("11-PIPE", "直線部推進管"),
            ("12-CURVE", "曲線部推進管"),
            ("13-JOINT", "継手位置"),
            ("14-SHAFT", "立坑"),
            ("1-CENTER", "推進中心線"),
        ],
    )

    # ---- 確定・保存（タイトルブロック描画・衝突解消込み） ----
    d.finish(out_path)

    # 戻り値（外部契約 — 既存のキー名・構造は変更禁止）
    # 2026-10-23: ドクターが管 1 本ずつの長さを照査できるよう、キーを足した（足すだけ）。
    #   method / standard_pipe_lengths_m / 各スパンの shortest_pipe_m・shortest_pipe_no
    #   合計と設計延長の差しか見ていなかったため、0.04m の管を含む割付が合格していた。
    meta = {
        "output": out_path,
        "method": inp.method,
        "standard_pipe_lengths_m": list(inp.pipe_lengths_m),
        "spans": [
            {
                "name": sp.name,
                "length_m": sp.length_m,
                "diameter_mm": sp.diameter_mm,
                "segment_count": len(seg["segments"]),
                "total_pipe_length_m": round(
                    sum(s["length"] for s in seg["segments"]), 3
                ),
                "curves": len(sp.curves),
                **_shortest_pipe(seg["segments"]),
            }
            for sp, seg in zip(inp.spans, all_segments)
        ],
    }
    return meta


def _shortest_pipe(segs: List[dict]) -> dict:
    """スパンの中で最も短い管の長さと管番号（管が無いときは空）。"""
    if not segs:
        return {}
    s = min(segs, key=lambda x: (x["length"], x["no"]))
    return {"shortest_pipe_m": s["length"], "shortest_pipe_no": s["no"]}


# ---- CLI ----

def main() -> None:
    if len(sys.argv) < 3:
        print("Usage: python3 gen_kanwari.py <input.json> <output.dxf>")
        sys.exit(1)
    inp = KanwariInput.from_json(sys.argv[1])
    out = sys.argv[2]
    meta = draw_kanwari(inp, out)
    print(json.dumps(meta, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
