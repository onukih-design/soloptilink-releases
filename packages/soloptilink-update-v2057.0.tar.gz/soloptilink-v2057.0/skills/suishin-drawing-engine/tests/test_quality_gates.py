#!/usr/bin/env python3
"""品質ゲートの回帰テスト（両側弁別）

2026-07 に発覚した重大欠陥
  ・寸法文字が縮尺倍に巨大化して図面を覆う（文字被り）
  ・図形が図枠を数千mm突き破る
  ・それをドクターが PASS と判定していた
を二度と通さないための番人。

「健全な図面は PASS」だけでなく「壊れた図面は必ず FAIL」の両方を実証する。
片側しか見ないと、検査が常に PASS を返すだけの飾りになっていても気づけない。

実行: python3 tests/test_quality_gates.py
"""
from __future__ import annotations

# 当社の実行部品へ入る前に試用の期限と対象を確かめる。
if __name__ == "__main__":
    import sys as _sl_trial_sys
    from pathlib import Path as _SlTrialPath
    _sl_trial_sys.path.insert(0, str((_SlTrialPath(__file__).resolve().parent / "../scripts").resolve()))
    from _trial_guard import require_runtime as _require_trial_runtime
    _require_trial_runtime("suishin-drawing-engine")
# SOLOPTILINK-TRIAL-ENTRY:END


import json
import os
import sys
import tempfile

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "scripts"))

import ezdxf  # noqa: E402

import drawing_qc  # noqa: E402
from dxf_base import OgumiDXF, TH_SMALL  # noqa: E402
from layout import Panel, View, fit_scale, split_cols, split_rows  # noqa: E402
from textfit import Label, LabelPlacer, Rect, count_overlaps, text_width  # noqa: E402

_failures: list = []
_passes = 0


def check(name: str, cond: bool, detail: str = "") -> None:
    global _passes
    if cond:
        _passes += 1
        print(f"  ✓ {name}")
    else:
        _failures.append(name)
        print(f"  ✗ {name}  {detail}")


def build_healthy(path: str) -> None:
    """新基盤で作った健全な図面"""
    d = OgumiDXF(paper="A1", scale=100, title="回帰テスト図",
                 drawing_no="T-001", project="品質ゲート回帰テスト",
                 client="", designer="")
    v = View(d.content_panel(), preferred_scale=None, title="【試験図】")
    v.rect(0, 0, 60000, 4000, "11-PIPE")
    v.circle((30000, 2000), 1500, "1-CENTER")
    v.dim((0, 0), (60000, 0), "h", offset_mm=12, text="L=60.0m")
    v.dim((0, 0), (0, 4000), "v", offset_mm=12, text="W=4.0m")
    for i in range(12):
        v.label(f"注記{i}", (30000, 2000), TH_SMALL)   # 全部同じ点に重ねる
    d.place(v)
    d.table(60, 120, [["項目", "値"], ["工法", "コマンド"], ["口径", "φ400"]],
            [30, 40], title="【仕様】")
    d.legend(60, 80, [("11-PIPE", "推進管"), ("1-CENTER", "中心線")])
    d.finish(path)


def build_broken(path: str) -> None:
    """v1 と同じ壊れ方を再現した図面（巨大寸法文字＋図枠外へはみ出し）"""
    doc = ezdxf.new(dxfversion="R2018", setup=True)
    msp = doc.modelspace()
    doc.layers.add("5-FRAME", color=7)
    doc.layers.add("3-TEXT", color=7)
    # A1 図枠
    msp.add_lwpolyline([(25, 10), (831, 10), (831, 584), (25, 584)],
                       dxfattribs={"layer": "5-FRAME"}).close(True)
    # 縮尺倍に巨大化した寸法文字（v1 の DIMSCALE=100 相当）
    msp.add_text("L=88.5m (74本)",
                 dxfattribs={"layer": "3-TEXT", "height": 250}).set_placement((100, 300))
    # 図枠外へ大きくはみ出す図形
    msp.add_line((-200, -100), (1200, 800), dxfattribs={"layer": "3-TEXT"})
    # 重なる文字
    msp.add_text("内空W=4.0m", dxfattribs={"layer": "3-TEXT", "height": 3}).set_placement((100, 100))
    msp.add_text("内空L=5.0m", dxfattribs={"layer": "3-TEXT", "height": 3}).set_placement((101, 100))
    doc.saveas(path)


def main() -> int:
    tmp = tempfile.mkdtemp(prefix="suishin_qc_")
    healthy = os.path.join(tmp, "healthy.dxf")
    broken = os.path.join(tmp, "broken.dxf")

    print("\n[1] 部品の単体動作")
    check("縮尺選定: 65m を A1 に収める", fit_scale(65000, 800, 700, 300) == 100)
    check("縮尺選定: 収まらない希望縮尺は自動で粗くする",
          fit_scale(65000, 800, 700, 300, preferred=20) == 100)
    check("縮尺選定: 収まる希望縮尺は尊重する",
          fit_scale(5000, 4000, 700, 300, preferred=50) == 50)
    check("日本語の文字幅推定（全角は文字高と同幅）",
          abs(text_width("あいう", 3.0) - 9.0) < 1e-6,
          f"実測 {text_width('あいう', 3.0)}")
    p = LabelPlacer(bounds=Rect(0, 0, 200, 120))
    for i in range(8):
        p.add(Label(text=f"重なる注記{i}", x=50, y=60, height=3.0))
    placed, unresolved = p.resolve()
    check("文字衝突回避: 8件を重なりゼロで配置",
          count_overlaps([l.rect() for l in placed]) == 0 and not unresolved)
    left = split_cols(Panel("m", 0, 0, 800, 500), [2, 1])[0]
    panels = split_rows(left, [1, 1])
    check("パネル分割が破綻しない",
          len(panels) == 2 and all(p.w > 0 and p.h > 0 for p in panels))

    print("\n[2] 健全な図面は PASS になる")
    build_healthy(healthy)
    good = drawing_qc.analyze(healthy)
    for key in ("layout_overflow", "text_too_large", "text_overlap", "dimstyle_scale"):
        check(f"健全: {key} = PASS", good["checks"][key]["verdict"] == "PASS",
              good["checks"][key]["detail"])
    check("健全: 総合 PASS", good["verdict"] == "PASS", str(good["verdict"]))

    print("\n[3] 壊れた図面は必ず FAIL になる（検査が飾りでないことの証明）")
    build_broken(broken)
    bad = drawing_qc.analyze(broken)
    check("壊れ: 図枠はみ出しを検出",
          bad["checks"]["layout_overflow"]["verdict"] == "FAIL",
          bad["checks"]["layout_overflow"]["detail"])
    check("壊れ: 巨大文字を検出",
          bad["checks"]["text_too_large"]["verdict"] == "FAIL",
          bad["checks"]["text_too_large"]["detail"])
    check("壊れ: 文字の重なりを検出",
          bad["checks"]["text_overlap"]["verdict"] == "FAIL",
          bad["checks"]["text_overlap"]["detail"])
    check("壊れ: 総合 FAIL", bad["verdict"] == "FAIL", str(bad["verdict"]))

    # 2026-10-23: 施工計画書が区間の土質・土被りを見ず、推力計算書と食い違っていた
    print("\n[3b] 施工計画書の土質・土被りは区間の値を優先し、推力計算書と一致する")
    import suishin  # noqa: E402
    from doctor import Doctor  # noqa: E402
    from gen_construction_plan import render as render_plan  # noqa: E402

    g1 = suishin._plan_ground_conditions(
        {"soil": "粘性土", "depth_m": 5.0,
         "spans": [{"name": "S1", "soil": "砂質土", "depth_m": 3.5}]})
    check("区間の値が案件全体の値より優先される",
          g1["soil_ja"] == "砂質土" and g1["depth_ja"] == "3.5m", str(g1))
    g2 = suishin._plan_ground_conditions(
        {"spans": [{"name": "S1", "soil": "砂質土", "depth_m": 3.5},
                   {"name": "S2", "soil": "礫混り土", "depth_m": 6.2},
                   {"name": "S3"}]})
    check("区間ごとに違えば区間名と値を全部並べる（代表値を 1 つに丸めない）",
          "S1: 砂質土" in g2["soil_ja"] and "S2: 礫混り土" in g2["soil_ja"]
          and "S3: 粘性土※" in g2["soil_ja"] and "3.5〜6.2m" in g2["depth_ja"]
          and "S3: 5.0m※" in g2["depth_ja"] and "既定値" in g2["depth_ja"], str(g2))
    g3 = suishin._plan_ground_conditions({"spans": [{"name": "S1", "soil": "", "depth_m": None}]})
    check("どこにも書いていなければ既定値と明記する（空欄も書いていない扱い）",
          g3["soil_ja"].startswith("粘性土") and "既定値" in g3["soil_ja"]
          and g3["depth_ja"].startswith("5.0m") and "既定値" in g3["depth_ja"], str(g3))

    gproj = os.path.join(tmp, "ground_project.json")
    with open(gproj, "w", encoding="utf-8") as f:
        f.write('{"project_name": "地盤条件の回帰テスト", "method": "エースモール",'
                ' "soil": "粘性土", "depth_m": 5.0,'
                ' "spans": [{"name": "No.1→No.2", "length_m": 60.0, "diameter_mm": 350,'
                ' "soil": "砂質土", "depth_m": 3.5},'
                ' {"name": "No.2→No.3", "length_m": 40.0, "diameter_mm": 350}]}')
    gout = os.path.join(tmp, "ground_out")
    gres = suishin.run_project(gproj, gout, only=["thrust_calc", "construction_plan"],
                               preview=False)
    gv = [r for r in gres["doctor"]["results"] if r["check"] == Doctor.GROUND_CHECK]
    check("健全: 生成した施工計画書と推力計算書の 土質・土被り = PASS",
          len(gv) == 1 and gv[0]["verdict"] == "PASS", str(gv))
    # 是正前と同じ書き方（案件全体の値だけ）の施工計画書は食い違いとして落ちる
    old_plan = os.path.join(tmp, "ground_old_plan.xlsx")
    render_plan({"project_name": "地盤条件の回帰テスト", "method": "エースモール",
                 "diameter_mm": 350, "length_m": 100.0,
                 "soil": "粘性土", "depth_m": 5.0}, old_plan)
    dold = Doctor()
    dold.check_ground_conditions(old_plan, [
        {"span": o["span"], "soil": o["soil"], "depth_m": o["depth_m"]}
        for o in gres["outputs"] if o["type"] == "thrust_calc"])
    check("壊れ: 案件全体の値だけを書いた施工計画書は 土質・土被り = FAIL",
          [r["verdict"] for r in dold.results] == ["FAIL"], str(dold.results))

    # 2026-10-23: 一括生成が案件の pipe_lengths_m を読まず、常に既定で割り付けていた
    print("\n[3c] 案件の管長の並び (pipe_lengths_m) が一括生成の管割に届く")

    def kanwari_run(name: str, extra: str) -> dict:
        pj = os.path.join(tmp, f"{name}.json")
        with open(pj, "w", encoding="utf-8") as f:
            f.write('{"project_name": "管長の並びの回帰テスト", "method": "エースモール",'
                    ' "spans": [{"name": "S1", "length_m": 10.0, "diameter_mm": 350}]'
                    + extra + '}')
        res = suishin.run_project(pj, os.path.join(tmp, name), only=["kanwari"],
                                  preview=False)
        return next(o for o in res["outputs"] if o["type"] == "kanwari")

    k_def = kanwari_run("pl_default", "")
    k_one = kanwari_run("pl_given", ', "pipe_lengths_m": [1.0]')
    check("指定が無ければ既定 2.43/1.2/1.0/0.6m のまま（割付は変えない）",
          k_def["pipe_lengths_m"] == [2.43, 1.2, 1.0, 0.6]
          and k_def["meta"]["spans"][0]["segment_count"] == 5, str(k_def["meta"]["spans"]))
    check("指定 [1.0] は管割に届く（L=10m が 1.0m×10 本）",
          k_one["pipe_lengths_m"] == [1.0] and "案件の指定" in k_one["pipe_lengths_source"]
          and k_one["meta"]["spans"][0]["segment_count"] == 10, str(k_one["meta"]["spans"]))
    try:
        kanwari_run("pl_bad", ', "pipe_lengths_m": [2.43, -1]')
        bad_msg = ""
    except ValueError as e:
        bad_msg = str(e)
    check("壊れ: 正の数でない並びは黙って既定に戻さず止める",
          "pipe_lengths_m" in bad_msg, bad_msg)

    print("\n[4] 寸法スタイルの倍率が 1.0 に固定されている")
    d = OgumiDXF(paper="A3", scale=2500, title="倍率確認", project="t")
    check("縮尺2500でも DIMSCALE は 1.0",
          float(d.doc.dimstyles.get("SUISHIN").dxf.dimscale) == 1.0,
          str(d.doc.dimstyles.get("SUISHIN").dxf.dimscale))

    # 2026-10-23: 研修の演習素材づくりで見つかった 2 件の番人
    from gen_kanwari import KanwariInput, Span, draw_kanwari, span_from_dict  # noqa: E402
    from doctor import Doctor  # noqa: E402
    import method_engine  # noqa: E402

    print("\n[5] 区間に土質・土被りがあっても管割図が止まらない")
    sp = span_from_dict({"name": "No.1→No.2", "length_m": 80.0, "diameter_mm": 350,
                         "soil": "砂質土", "depth_m": 3.5, "curves": []})
    check("区間の soil・depth_m を読み飛ばして管割図の区間を作る",
          sp.length_m == 80.0 and sp.diameter_mm == 350 and sp.curves == [])
    try:
        Span(name="x", length_m=1.0, diameter_mm=350, soil="砂質土")
        raised = False
    except TypeError:
        raised = True
    check("壊れ: 読み飛ばさずに渡すと止まる（是正前の止まり方の再現）", raised)

    print("\n[6] 管の最小長の照査（健全→合格・下限未満→要確認）")

    def kanwari_verdicts(length_m: float, name: str) -> dict:
        inp = KanwariInput(project_name="管の最小長の回帰テスト", drawing_no="T-K",
                           client="", method="エースモール",
                           spans=[span_from_dict({"name": "S1", "length_m": length_m,
                                                  "diameter_mm": 350})])
        meta = draw_kanwari(inp, os.path.join(tmp, f"{name}.dxf"))
        mp = os.path.join(tmp, f"{name}_meta.json")
        with open(mp, "w", encoding="utf-8") as f:
            json.dump(meta, f, ensure_ascii=False)
        doc = Doctor()
        doc.check_kanwari_meta(mp)
        return {r["check"].split(":")[0]: r["verdict"] for r in doc.results}

    good_v = kanwari_verdicts(24.3, "k_good")      # 2.43m × 10 本で割り切れる
    check("健全: 2.43m×10本の割付は 管の最小長 = PASS",
          good_v.get("管の最小長") == "PASS", str(good_v))
    bad_v = kanwari_verdicts(80.0, "k_short")      # 2.43×32＋1.2＋1.0＋0.04
    check("壊れ: 0.04m の管を含む割付は 管の最小長 = WARN",
          bad_v.get("管の最小長") == "WARN", str(bad_v))
    check("壊れ: 合計の整合だけでは見逃す（管割整合性は PASS のまま）",
          bad_v.get("管割整合性") == "PASS", str(bad_v))

    # 工法の諸元に調整管の最小長があれば、標準管の最短よりもそちらを使う
    meta_x = {"method": "試験用工法", "standard_pipe_lengths_m": [2.43, 0.6],
              "spans": [{"name": "S1", "length_m": 10.0, "total_pipe_length_m": 10.0,
                         "segment_count": 5, "shortest_pipe_m": 0.55,
                         "shortest_pipe_no": 5}]}
    mpx = os.path.join(tmp, "x_meta.json")
    with open(mpx, "w", encoding="utf-8") as f:
        json.dump(meta_x, f, ensure_ascii=False)

    def verdict_with_spec(spec: dict) -> str:
        orig = method_engine.MethodEngine.get_spec
        method_engine.MethodEngine.get_spec = lambda self, m: spec
        try:
            doc = Doctor()
            doc.check_kanwari_meta(mpx)
        finally:
            method_engine.MethodEngine.get_spec = orig
        return next(r["verdict"] for r in doc.results if r["check"].startswith("管の最小長"))

    check("諸元に調整管の最小長 0.5m があれば 0.55m の管は PASS",
          verdict_with_spec({Doctor.MIN_ADJUST_KEY: 0.5, "reference_pdf": "試験用"}) == "PASS")
    check("諸元に記載が無ければ標準管の最短 0.6m を下限とし 0.55m の管は WARN",
          verdict_with_spec({}) == "WARN")

    print("\n" + "=" * 60)
    if _failures:
        print(f"  結果: FAIL  （成功 {_passes} / 失敗 {len(_failures)}）")
        for f in _failures:
            print(f"    - {f}")
        print("=" * 60)
        return 1
    print(f"  結果: PASS  （全 {_passes} 項目）")
    print("=" * 60)
    return 0


if __name__ == "__main__":
    sys.exit(main())
