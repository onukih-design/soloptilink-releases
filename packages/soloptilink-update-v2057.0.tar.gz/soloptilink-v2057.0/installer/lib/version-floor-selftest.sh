#!/bin/bash
# 日本語Windowsで python3 の出力が cp932 になり途中停止するのを防ぐ (2026-09-04)
export PYTHONIOENCODING="utf-8:replace"
export PYTHONUTF8=1
# ----------------------------------------------------------------
# (c) 2026 SoloptiLink Inc. - All rights reserved.
# ----------------------------------------------------------------
# version-floor-selftest.sh — 古い版の導入を始まりで止める処理 (T1-015) の両側試験 (2026-11-11 新設)
#
#   対象: 3 つの導入台本の SOLOPTILINK-VERSION-FLOOR 区画
#         installer/SoloptiLinkAI-Setup.command (Mac) / setup.sh (Linux) / installer/soloptilink-install.ps1 (Windows)
#   身代わりの受け口 (127.0.0.1 の空いている番号) が管理画面の GET /system/version の代わりに答える。
#   管理画面 (2026-11-11 の写し) の応答の形: 200 {version,baseUrl,verified,min_deliverable_version:"v2056.6"} /
#     配れないとき 503 {error,code,min_deliverable_version} / 例外のとき 503 {error} (下限なし)
#   欠陥側 (止める): 応答の下限より古い (200 でも 503 でも) / 下限が無い・読めない応答で、台本の下限 2056.6 より古い /
#                    版を数として比べる (v2056.9 は v2056.10 より古い・文字として比べると逆になる)
#   健全側 (進める): 下限以上 / 通信できない / 応答しない (5 秒で諦める) / 許可していない宛先 /
#                    同梱の VERSION が無い / 止める指定 (SOLOPTILINK_INSTALL_VERSION_FLOOR=off)
#   実走: Mac と Linux の導入台本そのものを砂箱の HOME で動かし、古い版なら何も置かずに止まって案内が出ることを測る
#         (進める側は台本全体を動かすと導入が始まるため、区画を取り出して試す)。
#   Windows: pwsh があれば区画を取り出して同じ場合を試す (Windows PowerShell 5.1 の実機では未測定)。
#
#   ★本物の HOME・~/.soloptilink・~/.claude には触れない (砂箱の HOME で env -i で動かす)。外へは何も送らない。
# 使い方: bash installer/lib/version-floor-selftest.sh   (終了 0=全合格 / 1=不合格あり / 3=道具が無い)
# ----------------------------------------------------------------
set -u
HERE="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
TREE="$(cd "$HERE/../.." && pwd -P)"
MAC="$TREE/installer/SoloptiLinkAI-Setup.command"
LNX="$TREE/setup.sh"
WIN="$TREE/installer/soloptilink-install.ps1"
ROOT="${TMPDIR:-/tmp}"; ROOT="${ROOT%/}/sl-version-floor-selftest"
command -v python3 >/dev/null 2>&1 || { echo "未測定: python3 が無い"; exit 3; }
command -v curl >/dev/null 2>&1 || { echo "未測定: curl が無い"; exit 3; }
for f in "$MAC" "$LNX" "$WIN"; do [ -f "$f" ] || { echo "未測定: 台本が無い $f"; exit 3; }; done

PASS=0; FAIL=0
_t() { if [ "$1" = "$2" ]; then PASS=$((PASS + 1)); echo "  [合格] $3"; else FAIL=$((FAIL + 1)); echo "  [不合格] $3 (期待 $1 / 実際 $2)"; fi; }

python3 -I -c "import shutil,sys; shutil.rmtree(sys.argv[1], ignore_errors=True)" "$ROOT"
mkdir -p "$ROOT"

# 身代わりの受け口: mode のファイルの中身で答え方を変える
cat > "$ROOT/recv.py" <<'PY'
import http.server, sys, time, os
modef, portfile, logf = sys.argv[1], sys.argv[2], sys.argv[3]
class H(http.server.BaseHTTPRequestHandler):
    def do_GET(self):
        mode = open(modef).read().strip()
        with open(logf, "a") as f: f.write(self.path + "\n")
        if mode == "hang":
            time.sleep(20)
        code, body = 200, b""
        if mode == "floor":
            body = b'{"version":"v2056.30","baseUrl":"x","verified":true,"min_deliverable_version":"v2056.25"}'
        elif mode == "real":   # 管理画面の写しの 200 の形そのもの
            body = b'{"version":"v2056.19","baseUrl":"https://example.invalid/d","verified":true,"min_deliverable_version":"v2056.6"}'
        elif mode == "floor10":
            body = b'{"version":"v2056.30","baseUrl":"x","verified":true,"min_deliverable_version":"v2056.10"}'
        elif mode == "badfloor":
            body = b'{"version":"v2056.30","baseUrl":"x","verified":true,"min_deliverable_version":"v2056..1"}'
        elif mode == "nofloor":
            body = b'{"version":"v2056.30","baseUrl":"x","verified":true}'
        elif mode == "html":
            body = b"<html>maintenance</html>"
        elif mode == "503":    # 管理画面の例外のときの形 (下限なし)
            code, body = 503, b'{"error":"x"}'
        elif mode == "503floor":   # 配れないときの形 (下限あり)
            code, body = 503, b'{"error":"x","code":"no_deliverable_version","min_deliverable_version":"v2056.25"}'
        self.send_response(code); self.send_header("Content-Length", str(len(body))); self.end_headers(); self.wfile.write(body)
    def log_message(self, *a): pass
s = http.server.ThreadingHTTPServer(("127.0.0.1", 0), H)
open(portfile + ".tmp", "w").write(str(s.server_address[1])); os.replace(portfile + ".tmp", portfile)
s.serve_forever()
PY
echo floor > "$ROOT/mode"; : > "$ROOT/recv.log"
python3 -I "$ROOT/recv.py" "$ROOT/mode" "$ROOT/port" "$ROOT/recv.log" >/dev/null 2>&1 &
RP=$!
trap 'kill "$RP" 2>/dev/null; wait "$RP" 2>/dev/null' EXIT
i=0; while [ ! -s "$ROOT/port" ] && [ "$i" -lt 50 ]; do sleep 0.1; i=$((i + 1)); done
PORT="$(cat "$ROOT/port" 2>/dev/null)"
[ -n "$PORT" ] || { echo "未測定: 身代わりの受け口が立たない"; exit 3; }
API="http://127.0.0.1:$PORT/api/v1"
CLOSED="$(python3 -I -c 'import socket;s=socket.socket();s.bind(("127.0.0.1",0));print(s.getsockname()[1]);s.close()')"
BASE_PATH="/usr/bin:/bin:/usr/sbin:/sbin"

# ---------------------------------------------------------------- Mac と Linux の区画が同じ中身か
blk() { sed -n '/^# >>> SOLOPTILINK-VERSION-FLOOR-BEGIN/,/^# <<< SOLOPTILINK-VERSION-FLOOR-END/p' "$1"; }
BM="$(blk "$MAC")"; BL="$(blk "$LNX")"
[ -n "$BM" ]; _t 0 $? "Mac の導入台本に版の下限の確かめの区画がある"
[ "$BM" = "$BL" ]; _t 0 $? "Mac と Linux の区画が 1 文字も違わない"

# ---------------------------------------------------------------- 区画を取り出して判定だけを試す
vf() { # mode 版(空なら VERSION 無し) [追加の環境…] → 0=進める 1=止める
    local mode="$1" ver="$2" kit="$ROOT/kit-fn"
    shift 2
    echo "$mode" > "$ROOT/mode"
    python3 -I -c "import shutil,sys; shutil.rmtree(sys.argv[1], ignore_errors=True)" "$kit"
    mkdir -p "$kit"
    [ -n "$ver" ] && printf '%s\n' "$ver" > "$kit/VERSION"
    env -i HOME="$ROOT/home-fn" PATH="$BASE_PATH" SOLOPTILINK_API_URL="$API" "$@" /bin/bash -c "$BM"'
_sl_version_floor_check "$1"' _ "$kit/VERSION"
}
echo "--- 区画の判定 (Mac・Linux 共通)"
vf floor v2056.19;                     _t 1 $? "欠陥側: 応答の下限 v2056.25 より古い v2056.19 は止める"
vf 503floor v2056.19;                  _t 1 $? "欠陥側: 配れないとき (503) の応答でも、下限 v2056.25 より古い版は止める"
vf real v2056.5;                       _t 1 $? "欠陥側: 管理画面の写しの形 (下限 v2056.6) で v2056.5 は止める"
vf floor10 v2056.9;                    _t 1 $? "欠陥側: 版は数として比べる (v2056.9 は下限 v2056.10 より古い)"
vf nofloor v2054.5;                    _t 1 $? "欠陥側: 応答に下限が無いとき、台本の下限 2056.6 より古い v2054.5 は止める"
vf html v2054.5;                       _t 1 $? "欠陥側: 応答が読めない (HTML) ときは台本の下限 2056.6 と比べる (v2054.5 は止める)"
vf 503 v2054.5;                        _t 1 $? "欠陥側: 下限の無い 503 のときは台本の下限 2056.6 と比べる (v2054.5 は止める)"
vf badfloor v2054.5;                   _t 1 $? "欠陥側: 下限の値が版の形でないときは台本の下限 2056.6 と比べる (v2054.5 は止める)"
vf floor v2056.25;                     _t 0 $? "健全側: 下限と同じ版は進める"
vf floor 2056.31;                      _t 0 $? "健全側: 下限より新しい版 (v の無い書き方) は進める"
vf real v2056.19;                      _t 0 $? "健全側: 管理画面の写しの形 (下限 v2056.6) で v2056.19 は進める (数として 19 > 6)"
vf floor10 v2056.10;                   _t 0 $? "健全側: 下限 v2056.10 と同じ版は進める"
vf 503floor v2056.25;                  _t 0 $? "健全側: 503 の応答の下限と同じ版は進める"
vf nofloor v2056.19;                   _t 0 $? "健全側: 応答に下限が無いときは台本の下限 2056.6 で比べる (v2056.19 は進める)"
vf html v2056.19;                      _t 0 $? "健全側: 応答が読めないときも、台本の下限以上なら進める"
vf badfloor v2056.19;                  _t 0 $? "健全側: 下限の値が読めないときも、台本の下限以上なら進める"
vf floor v2054.5 SOLOPTILINK_API_URL="http://127.0.0.1:$CLOSED/api/v1"; _t 0 $? "健全側: 通信できないときは止めずに進める (v2054.5 でも)"
t0="$(python3 -I -c 'import time;print(int(time.time()*1000))')"
vf hang v2054.5;                       RC=$?
t1="$(python3 -I -c 'import time;print(int(time.time()*1000))')"
_t 0 "$RC" "健全側: 応答しないときは止めずに進める (v2054.5 でも)"
[ $((t1 - t0)) -lt 8000 ]; _t 0 $? "健全側: 応答しない宛先は 5 秒で諦める ($((t1 - t0)) ミリ秒)"
echo floor > "$ROOT/mode"
: > "$ROOT/recv.log"
vf floor v2054.5 SOLOPTILINK_API_URL="http://example.invalid/api/v1"; _t 0 $? "健全側: 許可していない宛先には問い合わせず進める"
[ ! -s "$ROOT/recv.log" ]; _t 0 $? "許可していない宛先のとき、受け口には何も届かない"
vf floor "";                           _t 0 $? "健全側: 同梱の VERSION が無いときは進める"
vf floor v2054.5 SOLOPTILINK_INSTALL_VERSION_FLOOR=off; _t 0 $? "止める指定 (SOLOPTILINK_INSTALL_VERSION_FLOOR=off) では進める"

# ---------------------------------------------------------------- 台本そのものを砂箱で動かす (古い版 → 何も置かずに止まる)
run_real() { # 台本 名前 [応答の場合 同梱の版]
    local src="$1" name="$2" mode="${3:-floor}" ver="${4:-v2056.19}" kit="$ROOT/kit-$2" home="$ROOT/home-$2" out rc
    python3 -I -c "import shutil,sys; [shutil.rmtree(p, ignore_errors=True) for p in sys.argv[1:]]" "$kit" "$home"
    mkdir -p "$kit" "$home"
    cp "$src" "$kit/$(basename "$src")"
    printf '%s\n' "$ver" > "$kit/VERSION"
    echo "$mode" > "$ROOT/mode"
    out="$(cd "$kit" && env -i HOME="$home" PATH="$BASE_PATH" TERM=dumb SOLOPTILINK_API_URL="$API" /bin/bash "$kit/$(basename "$src")" </dev/null 2>&1)"; rc=$?
    _t 1 "$rc" "$name: 古い版 ($ver・応答 $mode) の台本は終了コード 1 で止まる"
    case "$out" in *"この版は古いため、ダウンロードのリンクから取り直してください"*) _t 0 0 "$name: 「この版は古いため、ダウンロードのリンクから取り直してください」と出る" ;;
                   *) _t 0 1 "$name: 案内が出ない" ;; esac
    [ -z "$(ls -A "$home" 2>/dev/null)" ]; _t 0 $? "$name: お客様の HOME に何も置いていない"
    case "$out" in *"STEP 1/6"*|*"本体を配置"*|*"モジュール"*) _t 0 1 "$name: 止まらずに次の工程へ進んだ" ;; *) _t 0 0 "$name: 次の工程へ進まない" ;; esac
}
echo "--- 台本そのもの (砂箱の HOME)"
run_real "$MAC" "Mac (SoloptiLinkAI-Setup.command)"
run_real "$LNX" "Linux (setup.sh)"
run_real "$MAC" "Mac・管理画面の写しの形" real v2056.5
run_real "$LNX" "Linux・配れないとき (503)" 503floor v2056.19

# ---------------------------------------------------------------- Windows の区画 (pwsh があれば)
PWSH="$(command -v pwsh 2>/dev/null || true)"
if [ -n "$PWSH" ]; then
    echo "--- Windows の区画 (pwsh・PowerShell 5.1 の実機ではない)"
    python3 -I - "$WIN" "$ROOT/win-harness.ps1" <<'PY'
import re, sys
src = open(sys.argv[1], encoding="utf-8-sig").read().replace("\r\n", "\n")
def func(name):
    lines = src.split("\n")
    for i, l in enumerate(lines):
        if re.match(r"^function %s\b" % re.escape(name), l):
            depth, out = 0, []
            for l2 in lines[i:]:
                out.append(l2); depth += l2.count("{") - l2.count("}")
                if depth <= 0 and "{" in "".join(out):
                    return "\n".join(out) + "\n"
    raise SystemExit("関数が見つからない: " + name)
m = re.search(r"# >>> SOLOPTILINK-VERSION-FLOOR-BEGIN\n.*?# <<< SOLOPTILINK-VERSION-FLOOR-END\n", src, re.S)
if not m:
    raise SystemExit("区画が見つからない")
h = "\n".join(["$ErrorActionPreference = 'Stop'", "Set-StrictMode -Version Latest",
               func("Write-Err"), func("End-Pause"), func("Test-HasProperty"), m.group(0), "Write-Host 'PASSED_FLOOR'"])
open(sys.argv[2], "w", encoding="utf-8-sig").write(h)
PY
    _t 0 $? "Windows の導入台本から区画を取り出せる"
    wvf() { # mode 版 [追加の環境…] → 出力の末尾
        local mode="$1" ver="$2" kit="$ROOT/kit-win"
        shift 2
        echo "$mode" > "$ROOT/mode"
        python3 -I -c "import shutil,sys; shutil.rmtree(sys.argv[1], ignore_errors=True)" "$kit"
        mkdir -p "$kit/installer"
        cp "$ROOT/win-harness.ps1" "$kit/installer/harness.ps1"
        [ -n "$ver" ] && printf '%s\r\n' "$ver" > "$kit/VERSION"
        env -i HOME="$ROOT/home-win" PATH="$BASE_PATH" SOLOPTILINK_API_URL="$API" SOLOPTILINK_NO_END_PAUSE=1 "$@" \
            "$PWSH" -NoProfile -File "$kit/installer/harness.ps1" 2>&1
    }
    O="$(wvf floor v2056.19)"; RC=$?
    _t 1 "$RC" "Windows 欠陥側: 応答の下限より古い版は終了コード 1 で止める"
    case "$O" in *"この版は古いため"*) _t 0 0 "Windows: 案内が出る" ;; *) _t 0 1 "Windows: 案内が出ない ($O)" ;; esac
    case "$O" in *PASSED_FLOOR*) _t 0 1 "Windows: 止まらずに先へ進んだ" ;; *) _t 0 0 "Windows: 先へ進まない" ;; esac
    O="$(wvf 503floor v2056.19)"; RC=$?; _t 1 "$RC" "Windows 欠陥側: 配れないとき (503) の応答の下限でも止める"
    O="$(wvf real v2056.5)"; RC=$?;     _t 1 "$RC" "Windows 欠陥側: 管理画面の写しの形 (下限 v2056.6) で v2056.5 は止める"
    O="$(wvf floor10 v2056.9)"; RC=$?;  _t 1 "$RC" "Windows 欠陥側: 版は数として比べる (v2056.9 < v2056.10)"
    O="$(wvf nofloor v2054.5)"; RC=$?;  _t 1 "$RC" "Windows 欠陥側: 下限が無い応答では台本の下限 2056.6 より古い版を止める"
    O="$(wvf html v2054.5)"; RC=$?;     _t 1 "$RC" "Windows 欠陥側: 読めない応答では台本の下限 2056.6 と比べる (v2054.5 は止める)"
    O="$(wvf floor v2056.25)";           case "$O" in *PASSED_FLOOR*) _t 0 0 "Windows 健全側: 下限と同じ版は進める" ;; *) _t 0 1 "Windows 健全側: 下限と同じ版で止まった ($O)" ;; esac
    O="$(wvf real v2056.19)";            case "$O" in *PASSED_FLOOR*) _t 0 0 "Windows 健全側: 管理画面の写しの形で v2056.19 は進める (数として 19 > 6)" ;; *) _t 0 1 "Windows: 進まない ($O)" ;; esac
    O="$(wvf floor10 v2056.10)";         case "$O" in *PASSED_FLOOR*) _t 0 0 "Windows 健全側: 下限 v2056.10 と同じ版は進める" ;; *) _t 0 1 "Windows: 進まない ($O)" ;; esac
    O="$(wvf nofloor v2056.19)";         case "$O" in *PASSED_FLOOR*) _t 0 0 "Windows 健全側: 下限が無い応答では 2056.6 と比べて進める" ;; *) _t 0 1 "Windows: 進まない ($O)" ;; esac
    O="$(wvf badfloor v2056.19)";        case "$O" in *PASSED_FLOOR*) _t 0 0 "Windows 健全側: 下限の値が読めないときも台本の下限以上なら進める" ;; *) _t 0 1 "Windows: 進まない ($O)" ;; esac
    O="$(wvf 503 v2056.19)";             case "$O" in *PASSED_FLOOR*) _t 0 0 "Windows 健全側: 下限の無い 503 でも台本の下限以上なら進める" ;; *) _t 0 1 "Windows: 503 で止まった ($O)" ;; esac
    O="$(wvf floor v2054.5 SOLOPTILINK_API_URL="http://127.0.0.1:$CLOSED/api/v1")"
    case "$O" in *PASSED_FLOOR*) _t 0 0 "Windows 健全側: 通信できないときは進める" ;; *) _t 0 1 "Windows: 通信できないのに止まった ($O)" ;; esac
    t0="$(python3 -I -c 'import time;print(int(time.time()*1000))')"
    O="$(wvf hang v2054.5)"
    t1="$(python3 -I -c 'import time;print(int(time.time()*1000))')"
    case "$O" in *PASSED_FLOOR*) _t 0 0 "Windows 健全側: 応答しないときは進める ($((t1 - t0)) ミリ秒)" ;; *) _t 0 1 "Windows: 応答しないときに止まった ($O)" ;; esac
    [ $((t1 - t0)) -lt 12000 ]; _t 0 $? "Windows: 応答しない宛先は 5 秒ほどで諦める ($((t1 - t0)) ミリ秒・pwsh の起動を含む)"
    O="$(wvf floor "")";                 case "$O" in *PASSED_FLOOR*) _t 0 0 "Windows 健全側: 同梱の VERSION が無いときは進める" ;; *) _t 0 1 "Windows: VERSION 無しで止まった ($O)" ;; esac
    O="$(wvf floor v2054.5 SOLOPTILINK_INSTALL_VERSION_FLOOR=off)"
    case "$O" in *PASSED_FLOOR*) _t 0 0 "Windows: 止める指定では進める" ;; *) _t 0 1 "Windows: 止める指定でも止まった ($O)" ;; esac
    [ ! -e "$ROOT/home-win/.soloptilink" ]; _t 0 $? "Windows: 区画は HOME に何も置かない"
else
    echo "  [参考] pwsh が無いため Windows の区画は未測定"
fi

kill "$RP" 2>/dev/null; wait "$RP" 2>/dev/null
python3 -I -c "import shutil,sys; shutil.rmtree(sys.argv[1], ignore_errors=True)" "$ROOT"
echo "== 結果: 合格 $PASS 件 / 不合格 $FAIL 件 =="
[ "$FAIL" = "0" ]
