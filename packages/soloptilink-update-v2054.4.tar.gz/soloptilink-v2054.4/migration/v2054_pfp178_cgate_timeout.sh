#!/usr/bin/env bash
# ============================================================================
# Migration v2054_pfp178_cgate_timeout — 完成ゲート Stop hook の timeout 遡及是正
# ============================================================================
# 背景 (PFP-178 / NDC事案 2026-07-23):
#   完成ゲート (boost-completion-gate-hook.sh) の本体処理は実測66秒以上かかるが、
#   Stop hook の timeout は未指定 (ハーネス既定60秒) または 30秒 で登録されており、
#   ブロック判定が出力される前にプロセスごと殺され「完成宣言が無審査で素通り」していた。
#   hook 本体は v2054.5 で watchdog+予算自己較正により時間内判定を自力保証するが、
#   フル検証を時間内に完走させるため timeout も 240秒 へ遡及是正する。
# 冪等: 既に 240 以上なら NOOP。settings.json が無い/壊れている場合は安全に素通り。
# ============================================================================
set -uo pipefail

MIG_NAME="v2054_pfp178_cgate_timeout"
SL_DIR="$HOME/.soloptilink"
STATE_FILE="$SL_DIR/.migration-state.json"
SETTINGS_FILE="$HOME/.claude/settings.json"

mig_log() { printf '[%s] %s %s\n' "$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || echo '-')" "$MIG_NAME" "$1"; }

[ -f "$SETTINGS_FILE" ] || { mig_log "SKIP_NO_SETTINGS"; exit 0; }

RESULT="$(SETTINGS_FILE="$SETTINGS_FILE" python3 - <<'PY' 2>/dev/null
import json, os
sp = os.environ["SETTINGS_FILE"]
try:
    with open(sp) as f:
        d = json.load(f)
except Exception:
    print("ABORT_UNREADABLE"); raise SystemExit
if not isinstance(d, dict):
    print("ABORT_NOT_DICT"); raise SystemExit
changed = 0
for m in (d.get("hooks", {}).get("Stop") or []):
    for h in (m.get("hooks") or []):
        if "boost-completion-gate-hook.sh" in (h.get("command") or ""):
            try:
                cur = int(h.get("timeout") or 0)
            except Exception:
                cur = 0
            if cur < 240:
                h["timeout"] = 240
                changed += 1
if changed:
    tmp = sp + ".tmp-pfp178"
    with open(tmp, "w") as f:
        json.dump(d, f, ensure_ascii=False, indent=2)
    os.replace(tmp, sp)
    print("APPLIED:%d" % changed)
else:
    print("NOOP_ALREADY_OK")
PY
)" || { mig_log "PY_FAILED (retryable)"; exit 0; }

mig_log "RESULT ${RESULT:-empty}"

case "$RESULT" in
    APPLIED:*|NOOP_ALREADY_OK)
        if [ -f "$STATE_FILE" ]; then
            STATE_FILE="$STATE_FILE" MIG_NAME="$MIG_NAME" python3 -c "
import json, os
p = os.environ['STATE_FILE']
try:
    with open(p) as f:
        d = json.load(f)
except Exception:
    d = {}
a = d.setdefault('applied', [])
if os.environ['MIG_NAME'] not in a:
    a.append(os.environ['MIG_NAME'])
with open(p, 'w') as f:
    json.dump(d, f, ensure_ascii=False, indent=2)
" 2>/dev/null || echo "{\"applied\":[\"$MIG_NAME\"]}" > "$STATE_FILE"
        else
            echo "{\"applied\":[\"$MIG_NAME\"]}" > "$STATE_FILE"
        fi
        mig_log "APPLIED_STATE_RECORDED"
        ;;
    *)
        mig_log "NOT_RECORDED (${RESULT:-empty}) — 次回再試行"
        ;;
esac

exit 0
