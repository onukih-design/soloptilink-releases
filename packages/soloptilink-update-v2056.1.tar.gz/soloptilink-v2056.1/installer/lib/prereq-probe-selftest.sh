#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# 前提ソフト判定の両側検証
#
# 【なぜ要るか】導入の検査は「Node.js が【無い】端末」は模擬していたが、
#   「部品は【在る】が動かない端末」を模擬していなかった。そのため、
#   その組み合わせで起きる不具合を検査がすり抜けていた。
#
# 【この検査が見るもの】
#   S1 開発ツール未導入 (git / python3 が入口だけ在って実行できない)
#   S2 python3 が動かない状態で、Node の判定が正しく呼び出し側へ伝わるか
#   S3 判定が空のとき「用意できませんでした」ではなく「判定できません」と出るか
#   S4 正常な端末で従来どおり動くか (回帰が無いこと)
#
# 【両側弁別】健全な検体で PASS し、欠陥のある検体 (修正前の実装) で FAIL する
#   ことを同じ実行の中で示す。片側だけの検査は「何を与えても PASS する検査」と
#   区別がつかないため、無効とする。
#
# 使い方: bash prereq-probe-selftest.sh [--json]
# ---------------------------------------------------------------------------
set -uo pipefail

PPS_SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]:-$0}")" 2>/dev/null && pwd)"
PPS_SETUP="${PPS_SETUP:-$PPS_SELF_DIR/../SoloptiLinkAI-Setup.command}"
PPS_NODEPROV="${PPS_NODEPROV:-$PPS_SELF_DIR/node-provision.sh}"

PASS_N=0; FAIL_N=0; NA_N=0
RESULTS=""

_ok()   { PASS_N=$((PASS_N+1)); RESULTS="${RESULTS}  ✅ $1\n"; }
_ng()   { FAIL_N=$((FAIL_N+1)); RESULTS="${RESULTS}  ❌ $1\n"; }
# 対象外 = 「この検体には設計上存在しないもの」。合格にも不合格にもせず、理由つきで開示する。
# ★「取れなかった」と「そもそも無い」を混ぜると、正常な状態で検査が落ちて無効化に倒れる
#   (2026-08-14 実測: 回収経路は配布物へ同梱しない設計なのに、出荷物での不在を欠陥と読んで配信が止まった)。
_na()   { NA_N=$((NA_N+1));  RESULTS="${RESULTS}  ➖ $1\n"; }
_judge(){ if [ "$1" = "$2" ]; then _ok "$3 (期待=$2 実測=$1)"; else _ng "$3 (期待=$2 実測=$1)"; fi; }

# --- 両側検体の名簿行 (2026-08-21 追加 / 起動契約の空洞化を塞ぐ) ---------------
# 【なぜ要るか = 実測で分かったこと】
#   起動契約は「両側で確認」という固定文と状態語 PASS:FAIL を、欠陥検体を実際に
#   走らせたかどうかと無関係に印字できていた。欠陥側の判定を1本消しても契約の
#   出力は 1 文字も変わらなかった (痕跡ゼロ)。
# 【対策】検体ごとに【どちらの側か / 実測値 / 期待値】を機械可読の1行で残し、
#   審査する側が【件数】と【落ちた理由 (検体名と実測値)】まで照合できるようにする。
# 【通常実行への影響なし】呼び出し側が渡した使い捨ての合図 (PPS_BS_NONCE) が
#   無いときは1行も出さない。よって引数なし実行と --json の出力は従来どおり。
PPS_BS_ROWS=""
_pps_bs_san(){ printf '%s' "$1" | tr ':\n' '//' ; }   # 区切り文字を実測値へ混ぜない
_bs_judge(){   # $1=検体名 $2=side(healthy|defective) $3=実測 $4=期待 $5=説明
    local _st=FAIL
    [ "$3" = "$4" ] && _st=PASS
    PPS_BS_ROWS="${PPS_BS_ROWS}BSROW:${PPS_BS_NONCE:-}:$1:$2:${_st}:$(_pps_bs_san "$3"):$(_pps_bs_san "$4")\n"
    _judge "$3" "$4" "$5"
}
# この検査に書かれている判定の総数 (分岐を含む上限値)。部分実行を「全項目」と
# 名乗らせないため、実走件数の分母として開示する。
PPS_BS_DEFINED="$(grep -cE '^[[:space:]]*(_judge|_bs_judge|_na|_ng)[[:space:]]+' "${BASH_SOURCE[0]:-$0}" 2>/dev/null || true)"
case "$PPS_BS_DEFINED" in ''|*[!0-9]*) PPS_BS_DEFINED=0 ;; esac

# 名簿行と要約を出す (合図が無ければ何も出さない = 通常実行の出力は不変)
_pps_bs_emit() {
    [ -n "${PPS_BS_NONCE:-}" ] || return 0
    printf '%b' "$PPS_BS_ROWS"
    printf 'BSSUM:%s:ran=%d:defined=%d:part=%s\n' \
        "$PPS_BS_NONCE" "${TOTAL:-0}" "$PPS_BS_DEFINED" "${PPS_PART:-full}"
}

# --- 部分実行で走らせる群の選択 (2026-08-21) ---------------------------------
#   PPS_PART が空 = 全群 (既定・通常実行は従来どおり)。
#   PPS_PART=bothside = 検体を実走させる【速い群】だけを走らせる。走らせなかった群は
#     数えない (合格側へ倒さない)。呼び出し側は「部分実行 (N/M)」と明記する義務を負う。
#   PPS_PART=s1 = 旧互換 (S1 群だけで打ち切る。下の早期報告で処理する)。
_pps_group_on() {   # $1 = 群名 → 走らせるなら 0
    case "${PPS_PART:-}" in
        "")       return 0 ;;
        bothside) case "$1" in s2|s6to12|preflight|r17) return 1 ;; *) return 0 ;; esac ;;
        *)        return 0 ;;
    esac
}

# --- 結果の書き出し (完走時と部分実行の双方が同じ 1 本を通る) -----------------
#   ★2026-08-21 切り出し: 部分実行 (PPS_PART) でも同じ書式で返すため。
#     書式を 2 か所に書くと、片方だけ直したときに機械が読めない形へ静かに割れる。
pps_report() {   # $1 = "--json" のときだけ機械可読で返す
    TOTAL=$((PASS_N+FAIL_N+NA_N))
    if [ "${1:-}" = "--json" ]; then
        printf '{"gate":"prereq-probe-selftest","verdict":"%s","pass":%d,"fail":%d,"not_applicable":%d,"total":%d,"recover_context":"%s"}\n' \
            "$([ "$FAIL_N" -eq 0 ] && echo PASS || echo FAIL)" "$PASS_N" "$FAIL_N" "$NA_N" "$TOTAL" "${PPS_RECOVER_CTX:-}"
    else
        echo "前提ソフト判定 両側検証 (T-04/T-08):"
        printf "%b" "$RESULTS"
        echo "判定: $([ "$FAIL_N" -eq 0 ] && echo PASS || echo FAIL)  (合格 $PASS_N / 不合格 $FAIL_N / 対象外 $NA_N / 全 $TOTAL)"
        printf "%b" "$R17_ROWS"
    fi
    _pps_bs_emit
    [ "$FAIL_N" -eq 0 ] && exit 0 || exit 1
}

# --- 端末の実状態を模した検体群 (R-17) の充足を機械が数えられる形にする ---------
#   ここでは新しい判定を足さない。上の _judge が出した結果をそのまま拾って
#   1 行にまとめるだけ (同じ判定を 2 か所に書かないため)。
#   形式: R17-FIXTURE:<検体番号>:<PASS|FAIL|UNMEASURED>:<出所>:<日本語の説明>
R17_ROWS=""
_r17_begin(){ _R17_ID="$1"; _R17_F0="$FAIL_N"; _R17_N0="$NA_N"; }
_r17_end(){   # $1 = 日本語の説明
    local st=PASS
    [ "$NA_N"   -gt "$_R17_N0" ] && st=UNMEASURED
    [ "$FAIL_N" -gt "$_R17_F0" ] && st=FAIL
    R17_ROWS="${R17_ROWS}R17-FIXTURE:${_R17_ID}:${st}:prereq-probe-selftest:$1\n"
}

# --- 検体置き場 (実HOMEに触れない) -----------------------------------------
SB="$(mktemp -d 2>/dev/null)" || { echo "作業領域を作れません" >&2; exit 2; }
trap 'rm -rf "$SB" 2>/dev/null || true' EXIT

# 開発ツール未導入の macOS を模した検体を作る。
#   実機の /usr/bin/git は「入口(シム)」で、存在はするが実行すると失敗する。
#   その挙動を、非ゼロで終了し何も出力しない実行ファイルで再現する。
mk_shim() {           # $1 = 名前
    printf '#!/bin/sh\nexit 1\n' > "$SB/bin/$1"
    chmod +x "$SB/bin/$1"
}
mk_real_python() {    # 正常に動く python3 を用意する (健全側)
    local p; p="$(command -v python3 2>/dev/null || true)"
    [ -n "$p" ] && ln -sf "$p" "$SB/bin/python3"
}
mk_fake_node() {      # $1 = 版数
    printf '#!/bin/sh\n[ "$1" = "-v" ] && { echo "%s"; exit 0; }\necho "%s"\n' "$1" "$1" > "$SB/bin/node"
    chmod +x "$SB/bin/node"
}
mkdir -p "$SB/bin"

# 判定関数だけを Setup.command から取り出して一時ファイルへ置く
#   (.command 全体を実行すると導入が走ってしまうため、関数定義部だけを抜き出す)
#   ★検体側では PATH を絞るため、取り出しは PATH を絞る【前】に済ませておく
#     (絞った中で sed を呼ぶと sed 自体が見つからず、製品ではなく検体が壊れる)
PROBE_LIB="$SB/probe.sh"
sed -n '/^prereq_probe() {/,/^}/p' "$PPS_SETUP" > "$PROBE_LIB" 2>/dev/null || true
if [ ! -s "$PROBE_LIB" ]; then
    echo "判定関数を取り出せませんでした (検査を実行できません = 未測定)" >&2
    exit 2
fi

# ===========================================================================
# S1: 開発ツール未導入 — 入口はあるが実行できない
# ===========================================================================
s1_probe_verdict() {
    # $1 = "fixed" (是正後の判定) / "legacy" (是正前の存在確認だけの判定)
    local mode="$1" out
    out="$(
        PATH="$SB/bin:/usr/bin:/bin"
        if [ "$mode" = "legacy" ]; then
            # 【是正前の実装】存在確認だけ。入口があれば「使える」と判定していた
            if command -v git >/dev/null 2>&1; then printf 'available'; else printf 'absent'; fi
        else
            # shellcheck disable=SC1090
            . "$PROBE_LIB"
            PREREQ_VER=""
            prereq_probe git --version 'git version [0-9]'
        fi
    )"
    printf '%s' "$out"
}

_r17_begin F1
mk_shim git
_bs_judge S1-FIXED  healthy   "$(s1_probe_verdict fixed)"  "present_but_broken" \
    "S1 是正後: 入口だけの git を『存在するが動かない』と判定する"
_bs_judge S1-LEGACY defective "$(s1_probe_verdict legacy)" "available" \
    "S1 是正前: 同じ検体を『使える』と誤判定していた (欠陥側の再現)"

# S1b: 入口ごと無い場合は absent (真の未導入と区別できること)
#   git を PATH から完全に外す (実機の /usr/bin/git を拾わないよう $SB/bin だけにする。
#   absent は command -v の時点で確定するので、他の外部コマンドには到達しない)
rm -f "$SB/bin/git"
_bs_judge S1B-ABSENT healthy "$( PATH="$SB/bin"; . "$PROBE_LIB"; prereq_probe git --version 'git version [0-9]' )" \
    "absent" "S1b 入口ごと無い端末は『未導入』と判定する"

# S1c: 正常に動く場合は available (回帰が無いこと)
printf '#!/bin/sh\necho "git version 2.39.0"\n' > "$SB/bin/git"; chmod +x "$SB/bin/git"
_bs_judge S1C-OK healthy "$( PATH="$SB/bin:/usr/bin:/bin"; . "$PROBE_LIB"; prereq_probe git --version 'git version [0-9]' )" \
    "available" "S1c 正常な端末では従来どおり『使える』と判定する"
_r17_end "開発ツールが未導入の Mac (入口だけ在って実行できる状態にない端末を、未導入・故障・正常の3通りに弁別)"

# ===========================================================================
# 【両側判定の起動契約のための部分実行】(2026-08-21 追加)
#   PPS_PART=s1 のときは、ここまでの S1 群 (開発ツールが未導入の端末を
#   未導入・故障・正常の3通りに弁別する両側検体) だけを走らせて結果を返す。
#
#   ★なぜ要るか = 実際に起きていたこと (2026-08-21 実測)
#     完走には実測 33 秒かかる (S20〜S22 が検体ごとに一括診断を走らせ、そのたびに
#     偽の実行ファイル 7 本を作り直すため)。verify.d の審査は起動契約の応答を
#     既定 25 秒で打ち切るので、両側実証をしている軸が「応答なし」と記録されていた。
#
#   ★これは検査を弱めるスイッチではない。走らせなかった検体は【数えない】ので、
#     合格件数がそのぶん減るだけで、合格側へ倒れる経路は 1 つも増えない。
#     既定 (環境変数なし) では S2 以降が従来どおり全て走る。
# ===========================================================================
if [ "${PPS_PART:-}" = "s1" ]; then
    pps_report "${1:-}"
fi

# ===========================================================================
# S2: python3 が動かない状態で、Node の判定が呼び出し側へ伝わるか
#     (開発ツール未導入の端末で、正常な Node.js を「用意できませんでした」と
#      誤報告する経路があったため)
# ===========================================================================
if _pps_group_on s2; then   # ← 部分実行では走らせない群 (走らせない項目は数えない)
s2_verdict() {
    # $1 = "broken_python" / "ok_python"
    local mode="$1"
    rm -f "$SB/bin/python3"
    [ "$mode" = "broken_python" ] && mk_shim python3 || mk_real_python
    mk_fake_node "v24.19.0"
    (
        export NP_HOME="$SB/home" NP_SOLOPTILINK="$SB/home/.soloptilink"
        export NP_VAR_DIR="$SB/home/.soloptilink/var"
        export NP_RUNTIME_DIR="$SB/home/.soloptilink/runtime/node"
        export SOLOPTILINK_NODE_TARBALL=off SOLOPTILINK_NODE_BREW=off
        mkdir -p "$NP_VAR_DIR"
        PATH="$SB/bin:/usr/bin:/bin"
        # shellcheck disable=SC1090
        . "$PPS_NODEPROV" 2>/dev/null
        node_provision_ensure >/dev/null 2>&1
        printf '%s' "${NODE_PROVISION_VERDICT:-<空>}"
    )
}

_r17_begin F2
_judge "$(s2_verdict ok_python)" "PASS" \
    "S2a python3 が動く端末: Node 判定が伝わる (回帰なし)"
_judge "$(s2_verdict broken_python)" "PASS" \
    "S2b python3 が動かない端末でも Node 判定が伝わる (★最重要)"
_r17_end "python3 が動かない端末 (判定手段が欠けても、前提ソフトの判定が呼び出し側へ伝わる)"
fi   # _pps_group_on s2

# ===========================================================================
# S3: 判定が空のとき、誤った導入案内を出さないか
# ===========================================================================
s3_message() {
    # $1 = "fixed" / "legacy"。判定が空の状態で、お客様に何と表示されるかを見る
    local mode="$1" verdict="" version="v24.19.0"
    if [ "$mode" = "legacy" ]; then
        # 【是正前】空は「*」に落ち、既定文言 (nodejs.org から導入) が出ていた
        case "$verdict" in
            PASS) printf '使える' ;;
            *)    printf 'nodejs.org から導入してください' ;;
        esac
    else
        # 【是正後】空は専用の枝で受け、導入案内へ落とさない
        case "$verdict" in
            PASS) printf '使える' ;;
            "")   if [ -n "$version" ]; then printf '判定できませんでした(導入済み)'; else printf '判定できませんでした'; fi ;;
            *)    printf 'nodejs.org から導入してください' ;;
        esac
    fi
}
_bs_judge S3-FIXED  healthy   "$(s3_message fixed)"  "判定できませんでした(導入済み)" \
    "S3 是正後: 判定不能を『判定できません』と伝える"
_bs_judge S3-LEGACY defective "$(s3_message legacy)" "nodejs.org から導入してください" \
    "S3 是正前: 既に入っている Node の導入を促す誤案内だった (欠陥側の再現)"

# ===========================================================================
# S4: 是正後の実装に、存在確認だけで合格させる書き方が残っていないか
# ===========================================================================
s4_leftovers() {
    # 前提ソフトの判定で command -v の結果だけを [skip] に直結している行を探す
    grep -nE 'if command -v (git|python3) >/dev/null 2>&1; then' "$PPS_SETUP" 2>/dev/null | wc -l | tr -d ' '
}
_judge "$(s4_leftovers)" "0" "S4 存在確認だけで合格させる判定が残っていない"

# ===========================================================================
# S5: 自動更新が「入口だけの python3」で止まらないか (v2040 固着デッドロックの経路)
#     自動更新には python3 が使えない端末向けの代替経路が実装済みだったが、
#     その入口の判定が存在確認だけだったため、代替経路へ到達できなかった。
# ===========================================================================
PPS_AUTOUPD="${PPS_AUTOUPD:-$PPS_SELF_DIR/../../auto-update.sh}"
s5_fallback_reachable() {
    # $1 = "fixed" / "legacy"。入口だけの python3 がある端末で、代替経路に入れるか
    local mode="$1"
    rm -f "$SB/bin/python3"; mk_shim python3
    (
        PATH="$SB/bin:/usr/bin:/bin"
        if [ "$mode" = "legacy" ]; then
            HAS_PY3=0; command -v python3 >/dev/null 2>&1 && HAS_PY3=1
        else
            HAS_PY3=0
            if command -v python3 >/dev/null 2>&1 && python3 --version >/dev/null 2>&1; then HAS_PY3=1; fi
        fi
        # HAS_PY3=1 だと python3 経路が選ばれ、代替経路(sed)へ到達しない
        [ "$HAS_PY3" -eq 0 ] && printf '代替経路に到達' || printf 'python3経路を選択'
    )
}
_bs_judge S5-FIXED  healthy   "$(s5_fallback_reachable fixed)" "代替経路に到達" \
    "S5 是正後: python3 が動かない端末で代替経路に到達する (v2040 固着を回避)"
_bs_judge S5-LEGACY defective "$(s5_fallback_reachable legacy)" "python3経路を選択" \
    "S5 是正前: 同じ端末で代替経路に到達できず更新が止まっていた (欠陥側の再現)"

# S5b: 実装側にその是正が入っているか (巻き戻り検出)
if [ -f "$PPS_AUTOUPD" ]; then
    _s5b=$(grep -c 'python3 --version >/dev/null 2>&1' "$PPS_AUTOUPD" 2>/dev/null || true)
    _judge "$([ "${_s5b:-0}" -ge 1 ] && echo あり || echo なし)" "あり" \
        "S5b 自動更新の判定が実行可否ベースになっている"
else
    _ng "S5b 自動更新スクリプトが見つからず確認できない (未測定)"
fi

if _pps_group_on s6to12; then   # ← 部分実行では走らせない群 (走らせない項目は数えない)
# ===========================================================================
# S6: 自動更新の登録を「実行した」ではなく「効いた」で判定しているか
#     この事象への対処。
#     実際に登録されたかを確かめていなかった。登録されていないまま
#     「以降は自動で最新版を取得します」と表示され、お客様は気づけない。
# ===========================================================================
s6_verify_wired() {
    grep -c '_hook_is_registered' "$PPS_SETUP" 2>/dev/null || true
}
_s6=$(s6_verify_wired)
_judge "$([ "${_s6:-0}" -ge 2 ] && echo あり || echo なし)" "あり" \
    "S6 自動更新の登録を実際に確認してから成功と表示する"

# S6b: その確認が python3 に依存していないこと
#      (依存すると、確認したい端末でこそ確認できないという自己矛盾になる)
s6b_no_py_dep() {
    # _hook_is_registered 関数の本体に python3 が出てこないこと
    sed -n '/^_hook_is_registered() {/,/^}/p' "$PPS_SETUP" 2>/dev/null | grep -c 'python3' || true
}
_judge "$(s6b_no_py_dep)" "0" "S6b 登録の確認が python3 に依存していない"

# ===========================================================================
# S7: 効かない案内が残っていないか
#     この事象への対処。
#     お伝えください」と案内していたが、チャットの中からは設定を書き換えられない
#     仕組みになっており、案内どおりにしても解決しない行き止まりだった。
# ===========================================================================
s7_dead_end() {
    grep -c 'チャット欄に「最新版にして」' "$PPS_SETUP" 2>/dev/null || true
}
_judge "$(s7_dead_end)" "0" "S7 効かない案内 (チャットから更新できる旨) が残っていない"

# ===========================================================================
# S8: 認証に失敗しても、要対応の一覧まで到達するか (Windows と同じ形か)
#     この事象への対処。
#     前提ソフト工程が積み上げた要対応一覧も自己診断も完了画面も出ないまま
#     終わっていた。お客様には「登録できませんでした」しか残らない。
# ===========================================================================
s8_failopen() {
    # 要対応一覧の行番号より手前に、認証失敗による打ち切りが残っていないか
    local l_issue l_exit
    l_issue=$(grep -n 'PREREQ_ISSUES\[@\]' "$PPS_SETUP" 2>/dev/null | head -1 | cut -d: -f1)
    [ -n "$l_issue" ] || { printf '判定不能'; return 0; }
    # 認証分岐の中に exit が残っていれば打ち切りが復活している
    l_exit=$(awk '/soloptilink --activate \|\| \{/,/^\}/' "$PPS_SETUP" 2>/dev/null | grep -c 'exit 1' || true)
    [ "${l_exit:-0}" -eq 0 ] && printf '到達する' || printf '打ち切られる'
}
_judge "$(s8_failopen)" "到達する" "S8 認証に失敗しても要対応一覧まで到達する (Windows と同じ形)"

# ===========================================================================
# S9: すでに登録済みなら入力を求めずに飛ばすか
#     再実行が救済にならず、毎回入力待ちへ戻る問題 (申告①の「放置したが完了しない」)
# ===========================================================================
s9_preskip() {
    grep -c '_ALREADY_REGISTERED' "$PPS_SETUP" 2>/dev/null || true
}
_s9=$(s9_preskip)
_judge "$([ "${_s9:-0}" -ge 3 ] && echo あり || echo なし)" "あり" \
    "S9 登録済みの端末では認証の入力を求めない (再実行が救済になる)"

# ===========================================================================
# S10: メニュー修復フックを顧客端末へ登録する経路が実在するか
#      この事象への対処。
#      宣言していたのに、登録する処理が本体のどこにも無かった (死配線)。
# ===========================================================================
s10_heal_wired() {
    grep -c 'session-start-skill-heal.sh' "$PPS_SETUP" 2>/dev/null || true
}
_s10=$(s10_heal_wired)
_judge "$([ "${_s10:-0}" -ge 2 ] && echo あり || echo なし)" "あり" \
    "S10 メニュー修復フックを登録する経路が実在する"

# ===========================================================================
# S11: 顧客に見せる版数が、代入の無い変数を参照していないか
#      この事象への対処。
#      測っていない値をエージェントが補完して断定していた。
# ===========================================================================
#   ★検査対象は2系統。スキル本文の正典は ~/.claude/commands/ 側であり、
#     配布物側 (~/.soloptilink/skills/) だけを直しても同期で巻き戻る。両方を見る。
PPS_UPG="${PPS_UPG:-$PPS_SELF_DIR/../../skills/soloptilink-upgrade/SKILL.md}"
PPS_UPG_CANON="${PPS_UPG_CANON:-$HOME/.claude/commands/soloptilink-upgrade.md}"
# 系統ごとの「その木に在るべきか」を示す置き場 (下の3値判定で使う)
PPS_UPG_AREA="${PPS_UPG_AREA:-$PPS_SELF_DIR/../../skills}"
PPS_UPG_CANON_AREA="${PPS_UPG_CANON_AREA:-$HOME/.claude/commands}"

# --- 系統ごとの3値文脈 (S12 の回収経路と同じ考え方に揃える) -----------------
#   present     … 本文が在る                                → 実測する
#   missing     … 置き場は在るのに本文が無い                 → 実体欠落 = 欠陥 (不合格)
#   not_present … 置き場ごと無い (その系統がこの木に存在しない) → 対象外 (合格に数えない)
#
# 【なぜ3値にしたか / 2026-08-16 実測】
#   直前の実装は「ファイルが無い」を、S11 では【合格】(違反0件と数える)、
#   S11b では【不合格】(不足1/2) と、同じ事実を正反対に読んでいた。
#   そのため、更新スキル本文を持たない木 (HOME を差し替えた隔離ツリー、
#   スキル未導入の端末、skills を含まない検体) で本検査を走らせると、
#   製品に何の欠陥も無いのに 49/50 の FAIL が出た (実測で再現済み)。
#   一方で S11 側は同じ条件で【何も読まずに合格】を出しており、
#   「検査の入力が実物でないのに緑」という、より危険な向きに倒れていた。
#   よって「読めなかった」を合格にも不合格にも丸めず、状態語で開示する。
_pps_upg_ctx() {   # $1=本文の場所  $2=その系統がこの木に在るかを示す置き場
    local f="$1" area="$2"
    if [ -f "$f" ];    then printf 'present';  return 0; fi
    if [ -d "$area" ]; then printf 'missing';  return 0; fi
    printf 'not_present'
}
PPS_UPG_CTX="$(_pps_upg_ctx       "$PPS_UPG"       "$PPS_UPG_AREA")"
PPS_UPG_CANON_CTX="$(_pps_upg_ctx "$PPS_UPG_CANON" "$PPS_UPG_CANON_AREA")"
# 実測できる系統の本数 (=分母)。0 本なら合否を出さず対象外にする。
PPS_UPG_DEN=0
[ "$PPS_UPG_CTX"       = present ] && PPS_UPG_DEN=$((PPS_UPG_DEN+1))
[ "$PPS_UPG_CANON_CTX" = present ] && PPS_UPG_DEN=$((PPS_UPG_DEN+1))
# 置き場は在るのに本文だけ消えている系統の本数 (巻き戻り/欠落 = 欠陥)
PPS_UPG_LOST=0
[ "$PPS_UPG_CTX"       = missing ] && PPS_UPG_LOST=$((PPS_UPG_LOST+1))
[ "$PPS_UPG_CANON_CTX" = missing ] && PPS_UPG_LOST=$((PPS_UPG_LOST+1))
PPS_UPG_WHERE="配布物側=${PPS_UPG_CTX} 正典側=${PPS_UPG_CANON_CTX}"

s11_undefined_var() {
    # 提示文に代入の無い変数が残っていないか ($CURRENT_VERSION は別物なので除外)。
    # ★「使ってはいけない」と説明している行そのものは検査対象から外す
    #   (自己参照による誤検知。除外しないと、直した本人の注意書きが違反として数えられる)。
    local n=0 f seen=0
    for f in "$PPS_UPG" "$PPS_UPG_CANON"; do
        [ -f "$f" ] || continue
        seen=$((seen + 1))
        local c
        c=$(grep -vE '禁止|使わない|使うこと|原因はこれ' "$f" 2>/dev/null \
            | grep -oE '\$CURRENT([^_A-Z]|$)' 2>/dev/null | wc -l | tr -d ' ')
        n=$((n + ${c:-0}))
    done
    # ★1本も読めていないのに「違反0件」と答えない (読めなかったことを合格にしない)
    [ "$seen" -eq 0 ] && { printf '判定不能'; return 0; }
    [ "${n:-0}" -eq 0 ] && printf 'なし' || printf "残存${n}件"
}
if [ "$PPS_UPG_DEN" -eq 0 ]; then
    _na "S11 顧客提示文の変数参照 — 対象外 (この木には更新スキルの本文が1本も置かれていません: ${PPS_UPG_WHERE})。読めなかったので合格にも不合格にも数えません"
else
    _judge "$(s11_undefined_var)" "なし" \
        "S11 顧客提示文が代入の無い変数を参照していない (この木に在る全系統 ${PPS_UPG_DEN}/2 を実測: ${PPS_UPG_WHERE})"
fi

# S11b: 実測値を入れる変数が用意されているか (この木に在る全系統)
s11b_measured() {
    local ok=0 f
    for f in "$PPS_UPG" "$PPS_UPG_CANON"; do
        [ -f "$f" ] || continue
        if grep -q 'CUR_LOCAL=' "$f" 2>/dev/null && grep -q 'SRV_LATEST=' "$f" 2>/dev/null; then
            ok=$((ok + 1))
        fi
    done
    # 置き場は在るのに本文が消えている = 同期での巻き戻りが起きた形。これは欠陥として落とす。
    if [ "$PPS_UPG_LOST" -ge 1 ]; then printf "本文欠落${PPS_UPG_LOST}件"; return 0; fi
    [ "$ok" -eq "$PPS_UPG_DEN" ] && printf 'あり' || printf "不足(${ok}/${PPS_UPG_DEN})"
}
if [ "$PPS_UPG_DEN" -eq 0 ] && [ "$PPS_UPG_LOST" -eq 0 ]; then
    _na "S11b 実測値とサーバ申告値を別々に取る実装 — 対象外 (この木には更新スキルの本文が1本も置かれていません: ${PPS_UPG_WHERE})。読めなかったので合格にも不合格にも数えません"
else
    _judge "$(s11b_measured)" "あり" \
        "S11b 実測値とサーバ申告値を別々に取る実装が、この木に在る全系統 (${PPS_UPG_DEN}/2) に入っている (${PPS_UPG_WHERE})"
fi

# ===========================================================================
# S12: 回収経路 (最後の砦) が「入口だけの python3」で止まらないか
#      回収は開発ツールが壊れた端末のための経路なのに、その解析関数が
#      存在確認だけで python3 経路を選び、sed 代替へ到達しない欠陥があった。
# ===========================================================================
PPS_RECOVER="${PPS_RECOVER:-$PPS_SELF_DIR/../../scripts/distribution/recover.sh}"
PPS_RECOVER_HOME_DIR="$(dirname "$PPS_RECOVER")"

# この検体で回収経路を測れる文脈かを判定する (3値)。
#   applicable   … 回収経路が在るべき場所で、実際に在る            → 通常どおり検査する
#   missing      … 在るべき場所なのに不在                          → 欠陥 (不合格)
#   not_shipped  … 配信対象外の領域ごと存在しない (＝出荷物の中)   → 対象外
# ★出荷物には配信用スクリプト群 (回収経路を含む) を一切同梱しない設計である。
#   顧客は回収エンドポイントの URL から直接取得して実行する。したがって出荷物の中に
#   無いことは欠陥ではない。ただし「無いから合格」にもしない — 対象外として開示する。
_pps_recover_context() {
    if [ -f "$PPS_RECOVER" ]; then printf 'applicable'; return 0; fi
    if [ -d "$PPS_RECOVER_HOME_DIR" ]; then printf 'missing'; return 0; fi
    printf 'not_shipped'
}
PPS_RECOVER_CTX="$(_pps_recover_context)"

s12_recover_guard() {
    [ -f "$PPS_RECOVER" ] || { printf '判定不能'; return 0; }
    # 実行可否を見ない python3 ガードが残っていないか
    local n
    n=$(grep -c 'command -v python3 >/dev/null 2>&1' "$PPS_RECOVER" 2>/dev/null || true)
    local ok
    ok=$(grep -c 'python3 --version >/dev/null 2>&1' "$PPS_RECOVER" 2>/dev/null || true)
    if [ "${n:-0}" -ge 1 ] && [ "${n:-0}" -eq "${ok:-0}" ]; then printf '全て実行可否ベース'
    elif [ "${n:-0}" -eq 0 ]; then printf 'python3不使用'
    else printf "存在確認だけが$((n-ok))件残存"; fi
}
if [ "$PPS_RECOVER_CTX" = "not_shipped" ]; then
    _na "S12 回収経路の python3 判定 — 対象外 (回収経路は配布物へ同梱せず、回収用の入口から直接取得して実行する設計。正典ツリーでは本検査が実走する)"
else
    _judge "$(s12_recover_guard)" "全て実行可否ベース" \
        "S12 回収経路の python3 判定が実行可否ベースになっている"
fi

# S12b: 実際に「入口だけの python3」で sed 代替に到達するか (実走)
s12b_fallback() {
    [ -f "$PPS_RECOVER" ] || { printf '判定不能'; return 0; }
    rm -f "$SB/bin/python3"; mk_shim python3
    (
        PATH="$SB/bin:/usr/bin:/bin"
        # _json_field 関数だけを取り出して実走する
        eval "$(sed -n '/^_json_field() {/,/^}/p' "$PPS_RECOVER")"
        _json_field '{"version":"2055.5"}' version
    )
}
if [ "$PPS_RECOVER_CTX" = "not_shipped" ]; then
    _na "S12b 回収の解析が sed 代替に到達するか — 対象外 (同上・正典ツリーでは実走で検証する)"
else
    _judge "$(s12b_fallback)" "2055.5" \
        "S12b 入口だけの python3 端末で回収の解析が sed 代替に到達する (実走)"
fi
fi   # _pps_group_on s6to12

# ===========================================================================
# S13〜S15: 準備状況の一括診断が「出るべきときに出て、出なくてよいときは出ない」か
#
#   【なぜ足したか / 2026-08-15 実測】ここまでの S1〜S12 は【判定が正しいか】しか
#   見ていなかった。判定が正しくても、その結果をお客様に【いつ見せるか】が
#   間違っていれば事案は再発する (2026-08-13 は、判定はできていたのに提示が
#   導入の後ろにあったため、お客様は途中で止まってから初めて不足を知った)。
#   よってここでは「提示の有無」そのものを検体で弁別する。
#     S13 不足のある端末   → 開始前に一覧が出る          (健全側)
#     S14 すべて揃った端末 → 一覧を出さず素通りする      (もう一方の側)
#     S15 確認できない項目がある端末 → 素通りしない      (未確認を合格に丸めない)
# ===========================================================================
if _pps_group_on preflight; then   # ← 部分実行では走らせない群 (走らせない項目は数えない)
PREFLIGHT_LIB="$SB/preflight.sh"
awk '/PREFLIGHT-LIB-BEGIN/{f=1;next} /PREFLIGHT-LIB-END/{f=0} f' "$PPS_SETUP" > "$PREFLIGHT_LIB" 2>/dev/null || true

_mk_exec() {   # $1 = 置き場所 / $2 = 中身 (1行のシェル)
    printf '#!/bin/sh\n%s\n' "$2" > "$1"
    chmod +x "$1"
}

# R-17 検体の土台 = すべて良好な端末。ここから 1 か所だけ崩して各検体を作る
# (既存の分岐には触れない。1 か所だけ違う検体でないと、どの項目が効いたのか分からない)
_pf_bin_base() {
    _mk_exec "$SB/pfbin/df"      'echo "Filesystem 1024-blocks Used Available Capacity Mounted on"; echo "/dev/disk1 100000000 1000000 99000000 1% /"'
    _mk_exec "$SB/pfbin/sw_vers" 'echo "14.5"'
    _mk_exec "$SB/pfbin/curl"    'printf 200'
    _mk_exec "$SB/pfbin/git"     'echo "git version 2.39.0"'
    _mk_exec "$SB/pfbin/python3" 'echo "Python 3.11.9"'
    _mk_exec "$SB/pfbin/node"    'echo "v24.19.0"'
    _mk_exec "$SB/pfbin/claude"  'echo "2.0.1 (Claude Code)"'
}

pf_make_bin() {   # $1 = good | short | unknown_os
    rm -rf "$SB/pfbin" "$SB/pfhome" 2>/dev/null || true
    mkdir -p "$SB/pfbin" "$SB/pfhome"
    case "$1" in
        short)
            # 空きわずか / 古い基本ソフト / 接続不可 / 開発ツール未導入 (入口だけ)
            _mk_exec "$SB/pfbin/df"      'echo "Filesystem 1024-blocks Used Available Capacity Mounted on"; echo "/dev/disk1 100000000 99500000 500000 99% /"'
            _mk_exec "$SB/pfbin/sw_vers" 'echo "11.7.10"'
            _mk_exec "$SB/pfbin/curl"    'printf 000'
            _mk_exec "$SB/pfbin/git"     'exit 1'
            _mk_exec "$SB/pfbin/python3" 'exit 1'
            ;;
        unknown_os)
            # 基本ソフトの版だけ確かめられない端末 (他はすべて良好)
            #   ★実機の sw_vers を拾わないよう、答えを返さない検体を必ず置く
            #     (置かずに PATH から外すだけでは /usr/bin の本物が見つかり、検体にならない)
            _mk_exec "$SB/pfbin/sw_vers" 'exit 1'
            _mk_exec "$SB/pfbin/df"      'echo "Filesystem 1024-blocks Used Available Capacity Mounted on"; echo "/dev/disk1 100000000 1000000 99000000 1% /"'
            _mk_exec "$SB/pfbin/curl"    'printf 200'
            _mk_exec "$SB/pfbin/git"     'echo "git version 2.39.0"'
            _mk_exec "$SB/pfbin/python3" 'echo "Python 3.11.9"'
            _mk_exec "$SB/pfbin/node"    'echo "v24.19.0"'
            _mk_exec "$SB/pfbin/claude"  'echo "2.0.1 (Claude Code)"'
            ;;
        # ── R-17 検体 ⑧ 空き容量不足 ────────────────────────────────────
        disk_short)                     # 空きが 488MB しかない端末 (他は良好)
            _pf_bin_base
            _mk_exec "$SB/pfbin/df"      'echo "Filesystem 1024-blocks Used Available Capacity Mounted on"; echo "/dev/disk1 100000000 99500000 500000 99% /"'
            ;;
        disk_unknown)                   # 空き容量を答えられない端末 (他は良好)
            _pf_bin_base
            _mk_exec "$SB/pfbin/df"      'exit 1'
            ;;
        # ── R-17 検体 ⑤ ネットワーク制限 ────────────────────────────────
        net_blocked)                    # どこにも届かない (社内の遮断 / 名前解決不可)
            _pf_bin_base
            _mk_exec "$SB/pfbin/curl"    'printf 000'
            ;;
        net_partial)                    # 配信元には届くが Claude 側には届かない (部分到達)
            _pf_bin_base
            _mk_exec "$SB/pfbin/curl"    'case "$*" in *admin.soloptilink.com*) printf 200 ;; *) printf 000 ;; esac'
            ;;
        # ── R-17 検体 ④ Node が古い版で入っている端末 ───────────────────
        old_node)
            _pf_bin_base
            _mk_exec "$SB/pfbin/node"    'echo "v16.20.2"'
            ;;
        *)
            _mk_exec "$SB/pfbin/df"      'echo "Filesystem 1024-blocks Used Available Capacity Mounted on"; echo "/dev/disk1 100000000 1000000 99000000 1% /"'
            _mk_exec "$SB/pfbin/sw_vers" 'echo "14.5"'
            _mk_exec "$SB/pfbin/curl"    'printf 200'
            _mk_exec "$SB/pfbin/git"     'echo "git version 2.39.0"'
            _mk_exec "$SB/pfbin/python3" 'echo "Python 3.11.9"'
            _mk_exec "$SB/pfbin/node"    'echo "v24.19.0"'
            _mk_exec "$SB/pfbin/claude"  'echo "2.0.1 (Claude Code)"'
            ;;
    esac
}

pf_verdict() {   # $1 = good | short | unknown_os → 一覧を出す / 素通り / 判定不能
    [ -s "$PREFLIGHT_LIB" ] || { printf '切り出せない'; return 0; }
    pf_make_bin "$1"
    local out
    out="$(
        PATH="$SB/pfbin:/usr/bin:/bin"
        HOME="$SB/pfhome"
        # shellcheck disable=SC1090
        . "$PROBE_LIB"
        # shellcheck disable=SC1090
        . "$PREFLIGHT_LIB"
        { preflight_collect; preflight_present; } </dev/null 2>&1
    )"
    if printf '%s' "$out" | grep -q "導入をはじめる前に、次の点をご確認ください"; then
        printf '一覧を出す'
    elif printf '%s' "$out" | grep -q "準備はととのっています"; then
        printf '素通り'
    else
        printf '判定不能'
    fi
}

_judge "$(pf_verdict short)" "一覧を出す" \
    "S13 不足のある端末では、導入を始める前に一覧を出す (健全側)"
_judge "$(pf_verdict good)" "素通り" \
    "S14 すべて揃った端末では一覧を出さず素通りする (もう一方の側)"
_judge "$(pf_verdict unknown_os)" "一覧を出す" \
    "S15 確認できない項目があるときは素通りしない (未確認を合格に丸めない)"

# S16: 一括診断が【自動導入より前】かつ【本体配置より前】に置かれているか (順序の巻き戻り検出)
s16_order() {
    local l_pf l_node l_step3
    l_pf=$(grep -n '^    preflight_collect$' "$PPS_SETUP" 2>/dev/null | head -1 | cut -d: -f1)
    l_node=$(grep -n 'node_provision_ensure ||' "$PPS_SETUP" 2>/dev/null | head -1 | cut -d: -f1)
    l_step3=$(grep -n 'echo "\[STEP 3/6\]' "$PPS_SETUP" 2>/dev/null | head -1 | cut -d: -f1)
    if [ -z "$l_pf" ] || [ -z "$l_node" ] || [ -z "$l_step3" ]; then printf '判定不能'; return 0; fi
    if [ "$l_pf" -lt "$l_node" ] && [ "$l_pf" -lt "$l_step3" ]; then printf '前にある'; else printf '後ろにある'; fi
}
_judge "$(s16_order)" "前にある" "S16 一括診断が自動導入と本体配置より前に置かれている"
fi   # _pps_group_on preflight

# ===========================================================================
# S17: 異常終了画面が「どの工程で止まったか」を伝えるか
#      2026-08-13 事案では、止まった場所が分からずお客様が自力で回避策を探した。
# ===========================================================================
s17_trap_phase() {   # $1 = fixed / legacy
    local scr="$SB/trap_$1.sh" out
    {
        echo '#!/usr/bin/env bash'
        echo 'set -e'
        if [ "$1" = "legacy" ]; then
            # 【是正前】工程を持たない異常終了画面 (どこで止まったかを言えない)
            echo "trap 'echo \"予期しない問題が発生しました\"; exit 1' ERR"
        else
            grep -m1 '^trap ' "$PPS_SETUP"
            echo 'SETUP_PHASE="SoloptiLinkAI 本体の配置"'
            echo 'SETUP_PHASE_NEXT="インターネットの接続をご確認のうえ、もう一度ダブルクリックしてください。"'
        fi
        echo 'ls /nonexistent-for-prereq-selftest 2>/dev/null'
    } > "$scr"
    out="$(HOME="$SB/pfhome" bash "$scr" </dev/null 2>&1)"
    if printf '%s' "$out" | grep -q "止まったところ: SoloptiLinkAI 本体の配置"; then
        printf '工程を伝える'
    else
        printf '工程を伝えない'
    fi
}
mkdir -p "$SB/pfhome" 2>/dev/null || true
_bs_judge S17-FIXED  healthy   "$(s17_trap_phase fixed)"  "工程を伝える"   "S17 是正後: 異常終了画面が止まった工程と次の一手を伝える"
_bs_judge S17-LEGACY defective "$(s17_trap_phase legacy)" "工程を伝えない" "S17 是正前: 止まった工程を言えなかった (欠陥側の再現)"

# ===========================================================================
# S18: 「セットアップ完了」を、要対応が残っていても出していないか
#      完了画面の分岐を実際に走らせて確かめる (書いてあるかではなく、出る文字を見る)
# ===========================================================================
s18_banner() {   # $1 = withissues / clean
    local blk="$SB/banner_$1.sh" out
    {
        echo 'PREREQ_ISSUES=()'
        [ "$1" = "withissues" ] && echo 'PREREQ_ISSUES=("Git|開発ツールの導入が必要です")'
        awk -v k='if [ "${#PREREQ_ISSUES[@]}" -gt 0 ]; then' \
            'index($0,k)==1{f=1} f{print} f&&$0=="fi"{exit}' "$PPS_SETUP"
    } > "$blk"
    out="$(bash "$blk" 2>&1)"
    if printf '%s' "$out" | grep -q "一部が未完了"; then printf '未完了と出す'
    elif printf '%s' "$out" | grep -q "セットアップ完了"; then printf '完了と出す'
    else printf '判定不能'; fi
}
_judge "$(s18_banner withissues)" "未完了と出す" "S18 要対応が残る端末に「完了」と表示しない (健全側)"
_judge "$(s18_banner clean)"      "完了と出す"   "S18b 要対応が無い端末では従来どおり完了と表示する (回帰なし)"

# ===========================================================================
# S19: 「版を下げてください」という案内を当社から出していないか
#      2026-08-13 にお客様が自力で到達した回避策であり、当社が薦める形にはしない。
# ===========================================================================
PPS_PS1="${PPS_PS1:-$PPS_SELF_DIR/../soloptilink-install.ps1}"
_downgrade_hits() { printf '%s' "$1" | grep -oE '版を下げ|ダウングレード|古い版に戻|前の版に戻|旧版に戻' 2>/dev/null | sort -u; }
s19_downgrade() {
    local n=0 f c
    for f in "$PPS_SETUP" "$PPS_PS1"; do
        [ -f "$f" ] || continue
        c=$(_downgrade_hits "$(cat "$f")" | wc -l | tr -d ' ')
        n=$((n + ${c:-0}))
    done
    printf '%s' "$n"
}
_judge "$(s19_downgrade)" "0" "S19 当社から「版を下げる」ことを薦める案内が残っていない"
_judge "$([ -n "$(_downgrade_hits 'うまくいかない場合は版を下げてお試しください')" ] && echo 捕まえる || echo 素通り)" \
    "捕まえる" "S19b 同じ検査が、版を下げる案内の検体を必ず捕まえる (欠陥側の再現)"

# ===========================================================================
# S20〜S22: 端末の実状態を模した検体 (R-17 ④⑤⑧)
#
#   【なぜ足したか / 2026-08-15 実測】S13〜S15 は「不足が【いくつか】あれば一覧を
#   出すか」までしか見ておらず、不足を 4 つ同時に仕込んだ検体しか無かった。
#   そのため【どの項目が効いて止まったのか】が区別できず、空き容量の判定を丸ごと
#   落としても S13 は PASS のままだった (項目が 1 つでも欠ければ一覧は出るため)。
#   ここでは 1 か所だけ崩した検体を使い、項目ごとに
#     健全な端末 = 導入を続ける / 欠陥のある端末 = 日本語で明示して止まれる
#   の両側を実際に走らせて確かめる。
# ===========================================================================
if _pps_group_on r17; then   # ← 部分実行では走らせない群 (走らせない項目は数えない)
# 項目の判定だけを取り出す (PREFLIGHT_ROWS の形式は 項目名|判定|案内|持ち越し)
pf_row() {   # $1 = 検体名 / $2 = 項目名 → "判定|案内|持ち越し"
    [ -s "$PREFLIGHT_LIB" ] || { printf '切り出せない'; return 0; }
    pf_make_bin "$1"
    (
        PATH="$SB/pfbin:/usr/bin:/bin"
        HOME="$SB/pfhome"
        # shellcheck disable=SC1090
        . "$PROBE_LIB"
        # shellcheck disable=SC1090
        . "$PREFLIGHT_LIB"
        preflight_collect >/dev/null 2>&1
        [ "${#PREFLIGHT_ROWS[@]}" -gt 0 ] || { printf '行が無い'; exit 0; }
        for _r in "${PREFLIGHT_ROWS[@]}"; do
            case "$_r" in "$2|"*) printf '%s' "${_r#*|}"; exit 0 ;; esac
        done
        printf '項目が無い'
    )
}
pf_state() { pf_row "$1" "$2" | cut -d'|' -f1; }   # 判定だけ (ok|auto|need|unknown)
pf_note()  { pf_row "$1" "$2" | cut -d'|' -f2; }   # お客様への案内だけ

# 導入を続けるのか、中断できるのか (お客様の入力つきで実際に走らせる)
pf_proceed() {   # $1 = 検体名 / $2 = お客様の入力 (n = 中断を選ぶ / 空 = 何も押さない)
    [ -s "$PREFLIGHT_LIB" ] || { printf '切り出せない'; return 0; }
    pf_make_bin "$1"
    # ★お客様の入力はパイプではなく【ファイル】から渡す (2026-08-16 実測で是正)。
    #   不足が何も無い端末では、提示側は入力を読まずにそのまま戻る。これが正しい挙動である。
    #   ところがパイプで渡していたため、読まれなかった書き手 (printf) が SIGPIPE を受けて
    #   終了コード 141 になり、pipefail によってパイプライン全体が非ゼロになっていた。
    #   その結果、何の問題も無い端末の実行が「中断する」と読まれ、検査だけが落ちていた。
    #   実測 (2026-08-16 / 本体で再現): 健全側の同じ実行を 60 回まわして 2 回が rc=141。
    #   混雑しているほど当たりやすく、並列度を上げる統合ゲートでは実際に不合格が出ていた。
    #   ファイル経由なら書き手が居ないので、読まれても読まれなくても判定が揺れない。
    printf '%s\n' "$2" > "$SB/pf_answer.txt" 2>/dev/null || true
    (
        PATH="$SB/pfbin:/usr/bin:/bin"
        HOME="$SB/pfhome"
        # shellcheck disable=SC1090
        . "$PROBE_LIB"
        # shellcheck disable=SC1090
        . "$PREFLIGHT_LIB"
        preflight_collect >/dev/null 2>&1
        preflight_present >/dev/null 2>&1 < "$SB/pf_answer.txt"
    ) && printf '導入へ進む' || printf '中断する'
}
_pf_has() { case "$1" in *"$2"*) printf 'あり' ;; *) printf 'なし' ;; esac; }

# ---- ⑧ 空き容量不足 -------------------------------------------------------
_r17_begin F8
_judge "$(pf_state disk_short   'ディスクの空き容量')" "need"    "S20 空きが足りない端末は『ご用意ください』として止める側に置く (欠陥側)"
_judge "$(pf_state good         'ディスクの空き容量')" "ok"      "S20b 空きが十分な端末は素通りさせる (健全側・回帰なし)"
_judge "$(pf_state disk_unknown 'ディスクの空き容量')" "unknown" "S20c 空き容量を確認できない端末を『問題なし』に丸めない"
_judge "$(_pf_has "$(pf_note disk_short 'ディスクの空き容量')" "MB 以上の空き")" "あり" \
    "S20d 案内が『どれだけ空ければよいか』を数字で伝えている"
_judge "$(pf_verdict disk_short)" "一覧を出す" "S20e 空き容量だけが足りない端末でも、導入を始める前に一覧を出す"
_judge "$(pf_proceed disk_short n)" "中断する"   "S20f 空き容量不足の端末で、お客様が中断を選べば中断する"
_judge "$(pf_proceed good        '')" "導入へ進む" "S20g 空きが十分な端末は何も尋ねずそのまま導入へ進む (健全側)"
_r17_end "空き容量が足りない端末 (足りない/十分/確認できない の3通りを弁別し、必要量を数字で伝えて中断できる)"

# ---- ⑤ ネットワーク制限 ---------------------------------------------------
#   社内の遮断と名前解決の失敗は、この判定の見え方 (応答が返らない) が同じであり
#   分けられない。分けられないことを隠さず、どちらでも同じ正しい案内へ倒すことを見る。
_r17_begin F5
_judge "$(pf_state net_blocked 'インターネット接続')" "need" "S21 必要な接続先へ届かない端末は止める側に置く (社内の遮断 / 名前解決の失敗)"
_judge "$(pf_state net_partial 'インターネット接続')" "need" "S21b 片方だけ届く端末 (部分到達) も『つながらない』側として扱う"
_judge "$(pf_state good        'インターネット接続')" "ok"   "S21c 両方に届く端末は素通りさせる (健全側・回帰なし)"
_judge "$(_pf_has "$(pf_note net_blocked 'インターネット接続')" "プロキシ")" "あり" \
    "S21d 案内が社内のネットワーク制限 (プロキシ / VPN) の可能性に触れている"
_judge "$(_pf_has "$(pf_note net_blocked 'インターネット接続')" "ネットワーク管理者")" "あり" \
    "S21e 案内が『誰に頼めばよいか』まで伝えている"
_judge "$(pf_verdict net_partial)" "一覧を出す" "S21f 部分到達の端末でも、導入を始める前に一覧を出す"
_judge "$(pf_proceed net_blocked n)" "中断する" "S21g 接続できない端末で、お客様が中断を選べば中断する"
_r17_end "ネットワークが制限された端末 (全不通・部分到達・良好 の3通りを弁別し、プロキシ/VPN と依頼先まで案内して中断できる)"

# ---- ④ Node が古い版で入っている端末 --------------------------------------
#   ここは「止める」のが正解ではない。当社側で新しい版を用意できるので、
#   お客様の手を止めずに導入を続けられること (かつ黙って古いまま進めないこと) を見る。
_r17_begin F4
_judge "$(pf_state old_node 'Node.js')" "auto" "S22 古い Node が入った端末は『このあと当社側で用意します』として扱う"
_judge "$(pf_state good     'Node.js')" "ok"   "S22b 新しい Node が入った端末は『使えます』のまま (回帰なし)"
_judge "$(_pf_has "$(pf_note old_node 'Node.js')" "お客様の操作は不要")" "あり" \
    "S22c 案内が『お客様の操作は要らない』ことを伝えている"
_judge "$(pf_proceed old_node '')" "導入へ進む" "S22d 古い Node だけが理由なら、お客様に尋ねず導入を続ける"
_r17_end "Node が古い版で入っている端末 (素通りも中断もせず、当社側で用意する項目として提示したうえで導入を続ける)"
fi   # _pps_group_on r17

# ===========================================================================
# 結果
# ===========================================================================
pps_report "${1:-}"
