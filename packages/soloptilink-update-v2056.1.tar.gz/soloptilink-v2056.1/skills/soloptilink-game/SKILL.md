---
name: soloptilink-game
description: "SoloptiLinkAI v2056.1 - 「ゲーム作って」「3Dゲーム」「FPS」「VR」「Unity」「Unreal」「パズル」「シューティング」「RPG」「ノベルゲーム」等で起動。エンジン6種×ジャンル18種対応のゲーム開発専用エンジン。"
type: skill
version: 2.0.0
phase: production-3d-ready-game-engine
---

# SoloptiLinkAI v2056.1 - /soloptilink-game — Game Production Engine v2.0 (3D-AAA-Ready)


## 🔎 起動直後の自己証明 (v2054.3 新設・C1)

このスキルは SoloptiLinkAI 本体 (`~/.soloptilink/`) と協働する。素の Claude や他フォームから起動された場合でも「本物が動いていること」を証明するため、**起動直後に本体・認証・主要機構の実測を 1 行の日本語で提示する** (毎回・省略不可)。

```bash
bash ~/.soloptilink/lib/skill-self-attestation.sh 2>/dev/null \
  || echo "SoloptiLinkAI 本体が見つかりません (~/.soloptilink 未導入)。https://soloptilink.com/install から導入してください。"
```

出力例 (本体正常時):
> SoloptiLinkAI v2054.2 本体を確認しました (認証: 承認済 / 主要機構: 12/12 実在)。以降の応答は本物の機構で処理されます。

- 出力の 1 行を**自分の言葉としてそのまま顧客に見せてよい** (bash・生ログを地の文に貼らないルールの唯一の例外的窓口)
- 本体不在・未認証・機構欠損はそれぞれ違う 1 行が返る (fixture の両側弁別で保証済)
- 詳細な実起動証跡や品質ゲート実測ログは `/soloptilink-boost prove` で全展開可能 (C2)
- kill-switch: `SOLOPTILINK_SELF_ATTESTATION=off` (既定 on)

## 機能概要

SoloptiLinkAI v2.0 Game Production Engine 3D-AAA-Ready - ゲーム開発に最適化された独立レイヤー。ゲームエンジン6種(Phaser 3 / PixiJS / Three.js / Godot 4 / Unity 6 / Unreal Engine 5)、ジャンル18種(2D 12種:パズル/2Dアクション/シューティング/RPG/ノベル/ボード/カード/ハイパーカジュアル/リズム/シミュレーション/ストラテジー/クリッカー + 3D 6種:3Dアクション/3D-FPS-TPS/3Dパズル/レーシング/フライトシム/VR体験)の90%完成テンプレ、Game Quality Fortress 12軸(2D 10軸+3D追加2軸:レンダリングバジェット/物理コスト)+VR専用3軸(動揺病リスク/インタラクション明瞭性/快適設定)、ゲーム業界5エージェント、GDD自動生成、プレイテストハーネス、3Dアセット生成パイプライン(Tripo3D/Meshy/Stable Zero123/Rodin/Luma)、モーション自動取得(Mixamo/Cascadeur)、プロシージャル生成(Wave Function Collapse/ダンジョン/地形/クエスト)、Unity C#+Unreal C++/Blueprint シーン自動生成、Generator-Verifier-Refinerループ(自動プレイ→計測→AI再生成 最大10サイクル)、画像/サウンド素材ジェネレーター連携(Stable Diffusion/Suno/ElevenLabs)を統合。「ゲーム作って」「3Dゲーム」「FPS」「VR」「Unity」「Unreal」「レーシング」「フライトシム」「Mixamo」「プロシージャル」「迷路自動生成」「アセット自動生成」「ノベルゲーム」「パズル」「シューティング」「RPG」「ボードゲーム」「将棋」「オセロ」「マリオ風」「テトリス」「クリッカー」「Phaser」「PixiJS」「Three.js」「Godot」「GDD」「プレイテスト」「FPS計測」「ゲームバランス」「Generator-Verifier」等で起動。業務系SoloptiLinkAI(Next.js+Prisma+CRUD)とは独立アーキテクチャで動作し、2D Indie級〜3D Steam Indie級〜AAA級プロトタイプまでカバー。

## コンセプト

SoloptiLinkAI 本体(soloptilink / soloptilink-boost / soloptilink-japan)は日本SI受託業務システム生成に最適化されている。そのアーキテクチャ前提(Next.js + Prisma + RDB CRUD + Quality Fortress業務軸)をそのままゲーム生成に流用すると、「画面遷移するCRUDアプリのガワを被ったゲームもどき」になりクオリティが伸びない。

**`/soloptilink-game` はゲーム開発専用の独立スキル**。業務系スキル群と直交し、以下を提供:

1. **ゲームエンジン4種テンプレ**: Phaser 3 / PixiJS / Three.js / Godot Web Export
2. **ジャンル12種の90%完成テンプレ**: あと10%カスタマイズすれば動く雛形
3. **Game Quality Fortress 10軸**: ゲーム固有の品質軸でスコアリング
4. **ゲーム業界5エージェント**: 業務系105エージェントとは別系統
5. **GDD自動生成**: ゲームデザインドキュメント(企画書)を自動構築
6. **プレイテストハーネス**: 自動プレイ + FPS計測 + 入力遅延計測
7. **素材生成連携**: Stable Diffusion(画像) / Suno(BGM) / ElevenLabs(SE/ボイス)

## 言語・顧客可視出力ポリシー（グローバル準拠）

~/.claude/CLAUDE.md のグローバルポリシー（言語ポリシー / 顧客可視出力ポリシー）に完全準拠する。
- 応答・進捗報告・確認質問・完了報告はすべて日本語。英語ナレーション禁止（ファイルパス・コマンド・業界標準用語等の技術要素は英語のまま）。
- お客さんが読む地の文に bash・コード・diff・生ログ・生 JSON・`<invoke>` 等のタグを貼らない。技術作業はツールで実行し、日本語の自然文ステータスだけを示す。
- 応答送信前に bash・コード・生ログ・タグ混入がないかを自己点検してから出力する。

## 🤝 所見（相棒として必ず添えるもの・SOLOPTILINK-PARTNER-OPINION）

**作業完了の報告には、本文の末尾に必ず「所見」を添える。** 開発憲章 第2条（相棒＝共に考える存在）・第4条（意図を聞き、提案し、一緒に決めてから作る）を、報告の枠として実装したもの。3欄すべて必須で、該当がなければ「特になし」と明記する（欄を削るのは「書いていない」と判定される）。

まず材料を1画面で受け取る。**材料であって文章ではない**ので、出力を顧客可視の本文にそのまま貼らない:

```bash
bash ~/.soloptilink/lib/opinion-materials.sh show "$PROJECT_DIR"
```

材料を読んだうえで、**自分の言葉で**次の形で書く:

```
### 所見（この作業について）

**今回の判断**（何を・なぜ・何と迷ったか）
- …

**気になっていること**（指示どおり作ったが、懸念が残る点。無ければ「特になし」）
- …

**次の一手**（この案件の文脈で。技術の残作業と、事業として次に効くことを1つずつ）
- …
```

**規則**
1. 3欄とも省略しない。該当なしは「特になし」と書く
2. 3欄のどこかで、その案件の語（業種・扱うデータ・画面・ご要望・直前に決めたこと）に**最低1語**触れる。触れていない文は定型文として書き直しになる
3. 前回の所見と同じ行を繰り返さない
4. 機械言語（コマンド・ファイルパス・内部の識別子）を書かない
5. 3欄合計はおおむね120字以上。本文の繰り返しにはしない
6. 事業の一手は毎回1行入れる。根拠（ご要望・業種・前回の決定）が取れない案件では捏造せず「御社の狙いを一言いただければ、事業として次に効く一手をお出しします」と正直に書く
7. 過去に採用した判断を覆すときは、欄1に「前回の決定（○○）を覆します。理由: …」と必ず書く（黙って戻さない）
8. **欄1で設計・技術・スコープの判断を書いたら、同じ内容を判断記録に残す。** 残さないと次の案件で同じ議論をやり直すことになる:

```bash
bash ~/.soloptilink/lib/decision-ledger.sh add "$PROJECT_DIR" \
  --topic "<何について>" --chosen "<どちらにしたか>" --why "<なぜ>" --alt "<捨てた案>" --skill <モード名>
```

   人が「それでいい / やめてほしい / こう変えて」と答えたら、その時点で記録側にも反映する:

```bash
bash ~/.soloptilink/lib/decision-ledger.sh respond "$PROJECT_DIR" <記録ID> <adopted|rejected|modified> "<要旨>"
```

   ★人が答えるまでは「応答待ち」のままにする。**黙っていたことを「採用」と記録してはいけない**（誰も決めていない前提が、次の案件で既成事実として配られる）

**開示の深さ（二段構え）**: 材料の冒頭に出る `tier` に従う。出す・出さないではなく**深さ**を変える。
- `admin` / `internal` … 設計・技術・スコープの判断を、迷った点まで含めて書く
- `client`（既定）… 欄1の見出しを「**こう理解して進めました（前提）**」に置き換え、推測で置いた前提を書く。欄2は**打てる手がある懸念**（判断が要る／後で困る／費用が発生する）だけに絞り、内部実装の迷いは書かない

**この所見は応答完了時に実物で検査される。** 欠落・定型・繰り返し・（顧客向けの）機械言語のいずれかがあれば書き直しを求められる。

## 🗣 異議の述べ方（止めない・SOLOPTILINK-PARTNER-OBJECTION）

指示の内容に懸念（後で困る・費用が出る・法令や安全に触れる・より良い方法がある）があるときは、**実行する前に1〜2文で述べる**。ただし**承認は待たない**。述べたうえで、指示どおりに実行する（ユーザーが異議を受けて指示を変えた場合のみ従う）。述べた異議は所見の「気になっていること」欄に残す。

- 顧客向けには**打てる手がある懸念**だけを述べる（判断が要る／後で困る／費用が発生する）。内部実装の迷いは述べない
- 法令・算定式・認証・権限分離・監査ログ・暗号化を緩める指示には、異議を述べたうえで**従わない**（思想不変域）
  - **区別の基準**: 従わないのは「法令や安全が定める下限を下回る」指示だけ。例:「監査ログを取らない」「パスワードを平文で保存」「加算の算定式を実態と違う値にする」「権限を全員管理者にする」
  - 一方、**下限を満たしたうえでの運用のご要望には従う**。例:「承認を2段から1段にしたい」「役割の呼び名を自社に合わせたい」「この帳票は月次でなく週次で出したい」「画面の項目を減らしたい」——これらは業務の設計であって、緩和ではない
  - 判断に迷うときは**従う側に倒し**、「この運用だと〇〇の場面で確認が要ります」と所見の欄2に書く（先回りして断らない）
- 異議は機械言語を含まない日本語1〜2文。**質問の形にしない**（質問は増やさない。推測して進み、推測したことを開示する）
- 異議は実行を止めない。「この方針でよろしいですか」と承認を待つのは異議ではない
- 提案も同じ。**言うところまでが提案**で、実装するかは人が決める。提案でスコープを勝手に広げない

## 絶対禁止事項

soloptilink-boost と同じセキュリティバウンダリを継承:
- admin-dashboard 起動・参照禁止
- mock-api.js 起動禁止
- ライセンス認証バイパス禁止
- chain.sh 直接実行禁止(Goランチャー経由のみ)

## 起動キーワード(40+)

### ジャンル系
ゲーム作って / ゲーム機能 / ノベルゲーム / ビジュアルノベル / アドベンチャー /
パズルゲーム / テトリス / ぷよぷよ / マッチ3 / 倉庫番 /
2Dアクション / マリオ風 / プラットフォーマー / 横スク / 縦スク /
シューティング / STG / 弾幕 / シューター /
RPG / JRPG / ローグライク / ダンジョン /
ボードゲーム / 将棋 / オセロ / 麻雀 / 囲碁 / チェス /
カードゲーム / TCG / ソリティア / ポーカー /
ハイパーカジュアル / 1タップ /
リズムゲーム / 音ゲー / 太鼓 /
シミュレーション / 経営シム / 育成 /
ストラテジー / SLG / RTS / タワーディフェンス /
クリッカー / 放置ゲー / インクリメンタル

### エンジン系
ゲームエンジン / Phaser / PixiJS / Three.js / Godot / WebGL / Canvas

### 開発系
GDD / ゲームデザインドキュメント / 企画書 / プレイテスト / FPS計測 /
入力遅延 / ゲームバランス / 難易度カーブ / レベルデザイン

## 構造

```
~/.claude/skills/soloptilink-game/
├── SKILL.md (本ファイル)
├── README.md
├── CHANGELOG.md
├── lib/game/
│   ├── engines/             # ゲームエンジン4種定義
│   │   ├── phaser.json      # Phaser 3 仕様+雛形コード
│   │   ├── pixi.json        # PixiJS 仕様+雛形コード
│   │   ├── three.json       # Three.js 仕様+雛形コード
│   │   ├── godot.json       # Godot Web Export 仕様+雛形
│   │   └── engine_selector.ts  # ジャンル→エンジン推奨マトリクス
│   ├── genres/              # ジャンル12種定義
│   │   ├── puzzle.json
│   │   ├── action_2d.json
│   │   ├── shooter.json
│   │   ├── rpg.json
│   │   ├── novel.json
│   │   ├── board.json
│   │   ├── card.json
│   │   ├── hyper_casual.json
│   │   ├── rhythm.json
│   │   ├── simulation.json
│   │   ├── strategy.json
│   │   └── clicker.json
│   ├── quality/             # Game Quality Fortress
│   │   ├── game_fortress.ts # 10軸採点エンジン
│   │   ├── fps_meter.ts
│   │   ├── input_latency.ts
│   │   ├── balance_analyzer.ts
│   │   └── fun_score.ts
│   ├── agents/              # ゲーム業界5エージェント
│   │   ├── game_planner.json
│   │   ├── game_programmer.json
│   │   ├── level_designer.json
│   │   ├── game_artist.json
│   │   └── sound_designer.json
│   ├── gdd/                 # Game Design Document
│   │   ├── gdd_template.md
│   │   ├── gdd_generator.ts
│   │   └── sections/        # コンセプト/メカニクス/レベル/AV/技術
│   └── playtest/            # プレイテストハーネス
│       ├── auto_player.ts
│       ├── playtest_runner.sh
│       └── metrics_collector.ts
├── templates/               # 90%完成プロジェクト雛形
│   ├── phaser-puzzle/
│   ├── phaser-action/
│   ├── phaser-shooter/
│   ├── pixi-novel/
│   ├── pixi-rhythm/
│   ├── three-3d-game/
│   ├── godot-rpg/
│   └── board-game-online/
├── examples/                # 実例(例: 倉庫番 / オセロ / シューティング)
├── tests/                   # スキル自体の検証スクリプト
├── scripts/
│   ├── game_init.sh         # 1コマンドでゲームプロジェクト起動
│   ├── playtest.sh          # 自動プレイテスト実行
│   ├── publish.sh           # itch.io / Steam / App Store 公開準備
│   └── asset_forge.sh       # 素材生成(SD/Suno/EL連携)
└── docs/
    ├── ENGINE_COMPARISON.md
    ├── GENRE_GUIDE.md
    └── QUALITY_FORTRESS_GAME.md
```

## Skill Router 統合(v2.1 NEW)

### 起動時の自動ターゲット判定(Step 0.5)

このスキルが起動した瞬間、ユーザー指示を Skill Router で解析し、**業務系生成タスク**だと判定された場合は `/soloptilink-boost` への委譲を提案する(逆方向ガード)。

```bash
# 入力解析
ROUTE=$(bash ~/.claude/skills/soloptilink-game/scripts/skill_route.sh \
  --input "<ユーザー指示>" \
  --source game \
  --json 2>/dev/null)

# category 取得
CATEGORY=$(echo "$ROUTE" | python3 -c "import json,sys; print(json.load(sys.stdin).get('category','unknown'))")
```

### 判定結果ごとの動作

| category | 信頼度 | 動作 |
|---|---|---|
| `game` | 任意 | そのまま `/soloptilink-game` で処理続行 |
| `business` | ≥0.7 | ユーザーに `/soloptilink-boost` への切替を推奨(続行も可) |
| `business` | <0.7 | 業務系の可能性を警告しつつ続行 |
| `ambiguous` | - | ユーザーに確認: 「ゲームですか業務システムですか?」 |
| `unknown` | - | 暗黙にゲーム前提で続行 |

### 業務系検出時の委譲メッセージ例

```
⚠️  Skill Router 判定: 業務系生成タスクの可能性 (信頼度 0.82)
   検出キーワード: 請求書 / Prisma / 管理画面
   
   このタスクは /soloptilink-game ではなく /soloptilink-boost が適しています。
   理由: 業務系71軸 Quality Fortress + 105エージェント + chain.sh CRUD パイプライン
   
   切替コマンド: /soloptilink-boost <同じ指示>
   このまま続行する場合: 「ゲームとして進めて」と再指示
```

---

## 実行フロー

### Step 0: 端末認証(soloptilink-boostと同じ)

```bash
SOLOPTILINK_BIN=""; if [ -f ~/.soloptilink/soloptilink ]; then SOLOPTILINK_BIN="./soloptilink"; elif [ -f ~/.soloptilink/soloptilink.exe ]; then SOLOPTILINK_BIN="./soloptilink.exe"; fi
AUTH_CHECK=$(cd ~/.soloptilink 2>/dev/null && ${SOLOPTILINK_BIN:-./soloptilink} --status 2>&1); if echo "$AUTH_CHECK" | grep -q "承認済み"; then echo "AUTHORIZED"; else echo "UNAUTHORIZED"; fi
```

AUTHORIZED でなければ即停止。

### Step 1: ジャンル・エンジン推論(Silent Inference)

ユーザー指示から以下を推論:
- **ジャンル**: 12種から最有力1つを推定(複数候補時は AskUserQuestion で確認)
- **エンジン**: ジャンル→エンジン推奨マトリクス(engine_selector.ts)から自動選定
- **プラットフォーム**: Web / Mobile(Capacitor) / Desktop(Electron/Tauri) / Steam(Godot)
- **規模**: ミニゲーム(数時間) / カジュアル(数日) / フル(数週間)

ジャンル↔エンジン推奨マトリクス:

| ジャンル | 推奨エンジン | 理由 |
|---|---|---|
| パズル | Phaser 3 | 2D描画+物理+タッチ操作が標準装備 |
| 2Dアクション | Phaser 3 | Arcade Physics で慣性・衝突が容易 |
| シューティング | PixiJS | 弾幕数千個の描画性能が必要 |
| RPG | Godot Web | タイルマップ・ターン制ロジックが豊富 |
| ノベル | PixiJS | テキスト演出+トランジションが柔軟 |
| ボード | Phaser 3 / 自前Canvas | ターン制+UI主体 |
| カード | Phaser 3 / 自前Canvas | カードドラッグ・アニメ |
| ハイパーカジュアル | Phaser 3 | 軽量+1タップ操作 |
| リズム | PixiJS | フレーム正確な描画+音同期 |
| シミュレーション | Phaser 3 / Godot | グリッド+大量エンティティ |
| ストラテジー | Phaser 3 / Godot | グリッド+AI+大量ユニット |
| クリッカー | Phaser 3 / 自前Canvas | 数値表示+簡素な演出 |
| 3D系全般 | Three.js / Godot | WebGL必須 |

### Step 2: GDD自動生成(必須・スキップ不可)

コード生成前に必ず Game Design Document を生成。これがないとクオリティが低下する。

GDDの必須セクション(10):
1. **コンセプト**: ワンライナー(15字以内) / コアループ / ターゲット層
2. **メカニクス**: 主要アクション3-5個 / 勝利条件 / 敗北条件
3. **レベル進行**: 難易度カーブ / ステージ数 / ボス
4. **オーディオビジュアル**: アートスタイル / カラーパレット / BGM雰囲気
5. **コントロール**: 操作方法(タッチ/マウス/キーボード/ゲームパッド)
6. **技術スタック**: エンジン / 言語 / 配信先
7. **マネタイズ**: 買い切り / F2P広告 / IAP / 無料
8. **オンボーディング**: チュートリアル設計(3分以内で楽しさ伝達)
9. **リプレイ性**: アンロック / 実績 / ランキング / 周回要素
10. **マイルストーン**: プロトタイプ / アルファ / ベータ / リリース

### Step 3: テンプレ展開(90%完成雛形)

選択したジャンル×エンジンの雛形を展開:
```bash
bash ~/.claude/skills/soloptilink-game/scripts/game_init.sh \
  --genre <genre> \
  --engine <engine> \
  --name <project_name> \
  --target ./<dir>
```

雛形には以下が含まれる:
- ゲームループ(60fps固定)
- 入力ハンドラ(タッチ+マウス+キーボード+ゲームパッド)
- シーン管理(タイトル/メイン/ポーズ/結果)
- アセットローダー
- セーブ/ロード(localStorage / IndexedDB)
- サウンドエンジン(BGM+SE)
- 設定画面(音量/操作/言語)
- アクセシビリティ(色覚異常配慮/フォントサイズ)

### Step 4: 並列Agent実装(ゲーム業界5エージェント)

- **Agent A (game-planner)**: ゲームバランス調整・難易度カーブ・パラメータ調整
- **Agent B (game-programmer)**: コアゲームロジック実装(状態機械/物理/AI)
- **Agent C (level-designer)**: ステージ設計・敵配置・パズル設計
- **Agent D (game-artist)**: スプライト/タイル/エフェクト/UI設計
- **Agent E (sound-designer)**: BGM/SE/ボイスの仕様+ファイル指定

各Agentには GDD と該当ジャンル定義(genres/*.json)を渡す。

### Step 5: Game Quality Fortress 10軸採点

```bash
bash ~/.claude/skills/soloptilink-game/scripts/playtest.sh --project ./<dir>
```

10軸:
1. **FPS安定性** (60fps維持率 90%以上で満点)
2. **入力遅延** (16ms以下で満点 / 32ms以上で0点)
3. **ロード時間** (3秒以下で満点 / 10秒で0点)
4. **ゲームバランス** (難易度カーブの単調増加+山場+休憩)
5. **リプレイ性** (アンロック/実績/周回要素の有無)
6. **オンボーディング** (チュートリアル3分以内で楽しさ伝達)
7. **AV統一感** (カラーパレット一貫性+音と映像同期)
8. **UI/UX** (操作可能領域+タップターゲット48px以上)
9. **アクセシビリティ** (色覚配慮+フォント可変+字幕)
10. **楽しさ(FUNスコア)** (自動プレイ+ヒューリスティック評価)

スコア表示:
```
🎮 Game Quality Fortress: 87/100 (Silver)
├─ FPS安定性: 10/10  ████████████████████
├─ 入力遅延:   9/10  ██████████████████░░
├─ ロード時間: 8/10  ████████████████░░░░
├─ ...
└─ 楽しさ:    7/10  ██████████████░░░░░░

認定: Silver★★ (Bronze 60+ / Silver 80+ / Gold 90+ / Platinum 95+)
```

### Step 6: プレイテストハーネス

自動プレイ実行で以下を計測:
- フレームレート(performance.now()+requestAnimationFrame)
- 入力遅延(touch/click→反応までのms)
- メモリ使用量(performance.memory)
- クラッシュ・無限ループ検出
- 進行不能(soft-lock)検出

### Step 7: 配信準備(任意)

```bash
bash ~/.claude/skills/soloptilink-game/scripts/publish.sh --target itch.io
# または --target steam / --target appstore / --target playstore / --target web
```

itch.io / Steam / Web(GitHub Pages+Vercel) / iOS(Capacitor) / Android(Capacitor)に対応。

## 業務系SoloptiLinkAIとの違い

| 観点 | 業務系SoloptiLinkAI | soloptilink-game |
|---|---|---|
| アーキテクチャ | Next.js + Prisma + RDB | Phaser/Pixi/Three/Godot + Canvas/WebGL |
| データ | 永続CRUD | ゲーム状態(localStorage/IDB) |
| Quality Fortress | 71軸(コンプラ/PII/監査) | 10軸(FPS/遅延/楽しさ) |
| エージェント | 105体(業務系職種) | 5体(ゲーム業界職種) |
| テンプレ | 業務系10種 | ゲーム12ジャンル×4エンジン |
| 検証 | CRUD往復E2E | 自動プレイ+FPS計測 |
| 配信 | Vercel/AWS | itch.io/Steam/App Store |

## ブーストレベル

- **Level 1 (デフォルト)**: ジャンル雛形展開 + GDD生成 + 5エージェント実装 + 7軸基本採点
- **Level 2** (`--boost-level 2` / 「本気で」「本番」): + プレイテストハーネス + 10軸完全採点 + アクセシビリティ完全準拠
- **Level 3** (`--boost-level 3` / 「最強」「完璧」): + 素材生成連携(SD/Suno/EL) + マルチプラットフォーム配信 + 課金統合 + ランキング/マルチプレイ基盤(Firebase/Supabase)

## セッション永続化

`/soloptilink-game` 起動後は、以降の全メッセージもゲーム品質モードで処理する:
- 「敵が強すぎる」→ game-planner で難易度調整
- 「画面がガクつく」→ FPS計測+ボトルネック特定
- 「音が出ない」→ sound-designer がオーディオ系統点検
- 「公開したい」→ publish.sh 起動

## 使用例

```
/soloptilink-game ノベルゲーム作って
→ ジャンル: novel / エンジン: PixiJS / 雛形: pixi-novel/ 展開

/soloptilink-game マリオ風の横スクアクション 最強
→ ジャンル: action_2d / エンジン: Phaser / Level 3 / マルチプラットフォーム

/soloptilink-game オセロのオンライン対戦版
→ ジャンル: board / エンジン: Phaser / Firebase Realtime Database統合

/soloptilink-game 倉庫番100ステージ + 自動プレイテスト
→ ジャンル: puzzle / playtest.sh で全100ステージ自動検証
```

## 完了条件(Definition of Done)

- [ ] GDD(Game Design Document)が10セクション完備
- [ ] ジャンル雛形が展開され、`npm run dev` で起動可能
- [ ] タイトル→メイン→ゲームオーバーまでの最短プレイループが動作
- [ ] FPSが60fpsで安定(モバイル端末で30fps以上)
- [ ] 入力遅延が16ms以下
- [ ] 設定画面で音量・操作変更が可能
- [ ] localStorage/IDBでセーブ/ロードが機能
- [ ] アクセシビリティ最小要件(色覚配慮+キーボード操作)
- [ ] Game Quality Fortress 10軸が Bronze(60点)以上
- [ ] README.md にプレイ方法とビルド手順を記載

## v1.0.0 ロードマップ

- v1.0.0 (2026-05-17): 初版。4エンジン+12ジャンル+10軸+5エージェント+GDD+プレイテスト
- v1.1.0 (予定): マルチプレイ基盤(Colyseus/Firebase)
- v1.2.0 (予定): 素材生成完全自動化(SD/Suno/EL本格統合)
- v1.3.0 (予定): モバイルネイティブ(Capacitor)パイプライン強化
- v2.0.0 (予定): Unity/Unreal連携(中規模ゲーム対応)

---

## 起動時の必須確認事項

ユーザー指示を受けたら、以下を1秒以内に推論:
1. ジャンル(12種から最有力)
2. エンジン(推奨マトリクスから)
3. 規模(ミニ/カジュアル/フル)
4. プラットフォーム(Web/Mobile/Desktop)
5. マネタイズ(買い切り/F2P/無料)

推論結果が低確度(<70%)なら AskUserQuestion で確認。高確度なら即着手。
