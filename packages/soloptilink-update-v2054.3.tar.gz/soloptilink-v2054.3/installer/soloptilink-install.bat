@echo off
setlocal EnableExtensions
set "RC=1"

echo.
echo =================================================================
echo  SoloptiLinkAI  Windows Setup
echo  (Please wait - this window proceeds automatically)
echo =================================================================
echo.

echo [STEP 1/3] Checking PowerShell
where powershell >nul 2>&1
if errorlevel 1 (
  echo [FAIL] PowerShell not found. Windows 10 or later is required.
  goto END_PAUSE
)
echo  [ OK ] PowerShell is available

echo.
echo [STEP 2/3] Launching installer (Japanese guidance appears below)
set "PS1=%~dp0soloptilink-install.ps1"
if not exist "%PS1%" (
  echo [FAIL] soloptilink-install.ps1 was not found next to this file.
  echo        Please keep this .bat and soloptilink-install.ps1 in the same folder.
  goto END_PAUSE
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%PS1%" %*
set "RC=%ERRORLEVEL%"

echo.
echo [STEP 3/3] Finished (exit code = %RC%)

:END_PAUSE
echo.
echo =================================================================
echo  Press any key to close this window...
echo =================================================================
pause >nul
endlocal
exit /b %RC%
