#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v499.0 - Production Hardening Engine
# =============================================================================
# 本番環境投入前の包括的な堅牢化テスト。
# ストレステスト、セキュリティ監査、パフォーマンス監査、安定性チェックを
# 全自動で実施し、本番品質を保証するエンジン。
#
# Functions:
#   _ph_init              - 初期化
#   _ph_stress_test       - ストレステスト
#   _ph_security_audit    - セキュリティ監査
#   _ph_performance_audit - パフォーマンス監査
#   _ph_stability_check   - 安定性チェック
#   _ph_full_audit        - 全監査実行
#   _ph_certification     - 本番認証
#   _ph_report / _ph_score
#
# Globals: PH_ prefix
# =============================================================================

[[ -n "${_PRODUCTION_HARDENING_LOADED:-}" ]] && return 0
_PRODUCTION_HARDENING_LOADED=1

PH_VERSION="499.0"
PH_INITIALIZED=false

PH_DATA_DIR=""
PH_AUDIT_LOG=""
PH_CERT_FILE=""

PH_SECURITY_SCORE=0
PH_PERFORMANCE_SCORE=0
PH_STABILITY_SCORE=0
PH_STRESS_SCORE=0
PH_OVERALL_SCORE=0
PH_CERTIFIED=false
PH_ISSUES_FOUND=0
PH_ISSUES_CRITICAL=0

declare -g -A _PH_SECURITY_CHECKS=()
declare -g -A _PH_PERF_CHECKS=()
declare -g -A _PH_STABILITY_CHECKS=()
declare -g -a _PH_ISSUES=()
declare -g -a _PH_CRITICAL_ISSUES=()

_ph_init() {
    local project_dir="${PROJECT_DIR:-.}"
    PH_DATA_DIR="${project_dir}/.soloptilink/ph"
    PH_AUDIT_LOG="${PH_DATA_DIR}/audit.jsonl"
    PH_CERT_FILE="${PH_DATA_DIR}/certification.json"
    mkdir -p "$PH_DATA_DIR"
    PH_INITIALIZED=true
    return 0
}

# =============================================================================
# ストレステスト
# =============================================================================
_ph_stress_test() {
    local project_dir="${1:-.}"
    [[ "$PH_INITIALIZED" != "true" ]] && _ph_init

    PH_STRESS_SCORE=70  # ベースライン
    local issues=0

    # package.json依存数チェック
    if [[ -f "${project_dir}/package.json" ]]; then
        local dep_count
        dep_count=$(grep -c '"' "${project_dir}/package.json" 2>/dev/null || echo "0")
        if [[ $dep_count -gt 200 ]]; then
            _PH_ISSUES+=("[STRESS] 依存パッケージ数過多(${dep_count}): バンドルサイズ影響")
            PH_STRESS_SCORE=$((PH_STRESS_SCORE - 10))
            issues=$((issues + 1))
        fi
    fi

    # 巨大ファイルチェック
    local large_files
    large_files=$(find "$project_dir" -name "*.ts" -o -name "*.tsx" 2>/dev/null | grep -v node_modules | while read -r f; do
        local lines
        lines=$(wc -l < "$f" 2>/dev/null || echo "0")
        [[ $lines -gt 1000 ]] && echo "$f:$lines"
    done | wc -l)

    if [[ $large_files -gt 0 ]]; then
        _PH_ISSUES+=("[STRESS] 巨大ファイル${large_files}件(1000行超): メンテナンス性リスク")
        PH_STRESS_SCORE=$((PH_STRESS_SCORE - 5 * large_files))
        issues=$((issues + 1))
    fi

    # 深いネストチェック
    local deep_nesting
    deep_nesting=$(find "$project_dir" -type f -name "*.ts" -not -path "*/node_modules/*" 2>/dev/null | awk -F/ '{print NF}' | sort -n | tail -1)
    if [[ ${deep_nesting:-0} -gt 10 ]]; then
        _PH_ISSUES+=("[STRESS] ディレクトリネスト深すぎ(${deep_nesting}層)")
        PH_STRESS_SCORE=$((PH_STRESS_SCORE - 5))
        issues=$((issues + 1))
    fi

    [[ $PH_STRESS_SCORE -lt 0 ]] && PH_STRESS_SCORE=0
    PH_ISSUES_FOUND=$((PH_ISSUES_FOUND + issues))

    echo "$PH_STRESS_SCORE"
    return 0
}

# =============================================================================
# セキュリティ監査
# =============================================================================
_ph_security_audit() {
    local project_dir="${1:-.}"
    [[ "$PH_INITIALIZED" != "true" ]] && _ph_init

    PH_SECURITY_SCORE=80
    local checks_passed=0
    local checks_total=0

    # 1. ハードコードされたシークレット
    checks_total=$((checks_total + 1))
    local secrets
    secrets=$(find "$project_dir" -name "*.ts" -o -name "*.tsx" -o -name "*.js" 2>/dev/null | grep -v node_modules | xargs grep -liE "password\s*=\s*['\"][^'\"]+['\"]|api.?key\s*=\s*['\"][^'\"]+['\"]|secret\s*=\s*['\"][^'\"]+['\"]" 2>/dev/null | head -5)
    if [[ -z "$secrets" ]]; then
        _PH_SECURITY_CHECKS["no_hardcoded_secrets"]="PASS"
        checks_passed=$((checks_passed + 1))
    else
        _PH_SECURITY_CHECKS["no_hardcoded_secrets"]="FAIL"
        _PH_CRITICAL_ISSUES+=("[SECURITY:CRITICAL] ハードコードされたシークレット検出")
        PH_SECURITY_SCORE=$((PH_SECURITY_SCORE - 30))
        PH_ISSUES_CRITICAL=$((PH_ISSUES_CRITICAL + 1))
    fi

    # 2. zodバリデーション存在
    checks_total=$((checks_total + 1))
    if find "$project_dir" -path "*/api/*" -name "route.ts" 2>/dev/null | head -1 | grep -q .; then
        local api_with_zod
        api_with_zod=$(find "$project_dir" -path "*/api/*" -name "route.ts" 2>/dev/null | grep -v node_modules | xargs grep -l "z\.\|zod" 2>/dev/null | wc -l)
        local total_apis
        total_apis=$(find "$project_dir" -path "*/api/*" -name "route.ts" 2>/dev/null | grep -v node_modules | wc -l)

        if [[ $total_apis -gt 0 && $api_with_zod -ge $((total_apis * 70 / 100)) ]]; then
            _PH_SECURITY_CHECKS["zod_validation"]="PASS"
            checks_passed=$((checks_passed + 1))
        else
            _PH_SECURITY_CHECKS["zod_validation"]="FAIL"
            _PH_ISSUES+=("[SECURITY] zodバリデーション不足: ${api_with_zod}/${total_apis} APIs")
            PH_SECURITY_SCORE=$((PH_SECURITY_SCORE - 15))
        fi
    else
        checks_passed=$((checks_passed + 1))
    fi

    # 3. 認証ミドルウェア
    checks_total=$((checks_total + 1))
    if [[ -f "${project_dir}/middleware.ts" ]]; then
        _PH_SECURITY_CHECKS["auth_middleware"]="PASS"
        checks_passed=$((checks_passed + 1))
    else
        _PH_SECURITY_CHECKS["auth_middleware"]="WARN"
        _PH_ISSUES+=("[SECURITY] middleware.ts未検出: 認証チェックの一元管理推奨")
        PH_SECURITY_SCORE=$((PH_SECURITY_SCORE - 10))
    fi

    # 4. CSP/Helmet
    checks_total=$((checks_total + 1))
    if grep -rq "helmet\|Content-Security-Policy" "${project_dir}/app/" 2>/dev/null || grep -q "helmet" "${project_dir}/package.json" 2>/dev/null; then
        _PH_SECURITY_CHECKS["security_headers"]="PASS"
        checks_passed=$((checks_passed + 1))
    else
        _PH_SECURITY_CHECKS["security_headers"]="WARN"
        _PH_ISSUES+=("[SECURITY] セキュリティヘッダー未設定: CSP/HSTS推奨")
        PH_SECURITY_SCORE=$((PH_SECURITY_SCORE - 10))
    fi

    # 5. .env.example存在
    checks_total=$((checks_total + 1))
    if [[ -f "${project_dir}/.env.example" ]]; then
        _PH_SECURITY_CHECKS["env_example"]="PASS"
        checks_passed=$((checks_passed + 1))
    else
        _PH_SECURITY_CHECKS["env_example"]="WARN"
        PH_SECURITY_SCORE=$((PH_SECURITY_SCORE - 5))
    fi

    [[ $PH_SECURITY_SCORE -lt 0 ]] && PH_SECURITY_SCORE=0
    PH_ISSUES_FOUND=$((PH_ISSUES_FOUND + checks_total - checks_passed))

    echo "${checks_passed}/${checks_total}"
    return 0
}

# =============================================================================
# パフォーマンス監査
# =============================================================================
_ph_performance_audit() {
    local project_dir="${1:-.}"
    [[ "$PH_INITIALIZED" != "true" ]] && _ph_init

    PH_PERFORMANCE_SCORE=75

    # N+1クエリリスク
    local n_plus_1
    n_plus_1=$(find "$project_dir" -name "*.ts" 2>/dev/null | grep -v node_modules | xargs grep -l "for.*await.*prisma\|\.map.*prisma\|forEach.*prisma" 2>/dev/null | wc -l)
    if [[ $n_plus_1 -gt 0 ]]; then
        _PH_PERF_CHECKS["n_plus_1"]="FAIL:${n_plus_1}files"
        _PH_ISSUES+=("[PERF] N+1クエリリスク: ${n_plus_1}ファイル")
        PH_PERFORMANCE_SCORE=$((PH_PERFORMANCE_SCORE - 10 * n_plus_1))
    else
        _PH_PERF_CHECKS["n_plus_1"]="PASS"
    fi

    # include/selectの使用
    local include_usage
    include_usage=$(find "$project_dir" -name "*.ts" 2>/dev/null | grep -v node_modules | xargs grep -c "include:\|select:" 2>/dev/null | awk -F: '{sum+=$2}END{print sum+0}')
    if [[ $include_usage -gt 5 ]]; then
        _PH_PERF_CHECKS["efficient_queries"]="PASS"
        PH_PERFORMANCE_SCORE=$((PH_PERFORMANCE_SCORE + 5))
    fi

    # 画像最適化
    if grep -rq "next/image\|Image" "${project_dir}/app/" 2>/dev/null; then
        _PH_PERF_CHECKS["image_optimization"]="PASS"
        PH_PERFORMANCE_SCORE=$((PH_PERFORMANCE_SCORE + 5))
    fi

    [[ $PH_PERFORMANCE_SCORE -lt 0 ]] && PH_PERFORMANCE_SCORE=0
    [[ $PH_PERFORMANCE_SCORE -gt 100 ]] && PH_PERFORMANCE_SCORE=100

    echo "$PH_PERFORMANCE_SCORE"
    return 0
}

# =============================================================================
# 安定性チェック
# =============================================================================
_ph_stability_check() {
    local project_dir="${1:-.}"
    [[ "$PH_INITIALIZED" != "true" ]] && _ph_init

    PH_STABILITY_SCORE=75

    # try-catch使用率
    local try_count
    try_count=$(find "$project_dir" -path "*/api/*" -name "route.ts" 2>/dev/null | grep -v node_modules | xargs grep -c "try {" 2>/dev/null | awk -F: '{sum+=$2}END{print sum+0}')
    local api_count
    api_count=$(find "$project_dir" -path "*/api/*" -name "route.ts" 2>/dev/null | grep -v node_modules | wc -l)

    if [[ $api_count -gt 0 && $try_count -ge $api_count ]]; then
        _PH_STABILITY_CHECKS["error_handling"]="PASS"
        PH_STABILITY_SCORE=$((PH_STABILITY_SCORE + 10))
    else
        _PH_STABILITY_CHECKS["error_handling"]="FAIL"
        _PH_ISSUES+=("[STABILITY] エラーハンドリング不足: try-catch ${try_count}/${api_count} APIs")
        PH_STABILITY_SCORE=$((PH_STABILITY_SCORE - 15))
    fi

    # テスト存在
    local test_count
    test_count=$(find "$project_dir" -name "*.test.*" -o -name "*.spec.*" 2>/dev/null | grep -v node_modules | wc -l)
    if [[ $test_count -gt 5 ]]; then
        _PH_STABILITY_CHECKS["tests"]="PASS"
        PH_STABILITY_SCORE=$((PH_STABILITY_SCORE + 10))
    elif [[ $test_count -gt 0 ]]; then
        _PH_STABILITY_CHECKS["tests"]="WARN"
    else
        _PH_STABILITY_CHECKS["tests"]="FAIL"
        _PH_ISSUES+=("[STABILITY] テストファイル未検出")
        PH_STABILITY_SCORE=$((PH_STABILITY_SCORE - 20))
    fi

    # TypeScript strict
    if [[ -f "${project_dir}/tsconfig.json" ]]; then
        if grep -q '"strict": true' "${project_dir}/tsconfig.json" 2>/dev/null; then
            _PH_STABILITY_CHECKS["ts_strict"]="PASS"
            PH_STABILITY_SCORE=$((PH_STABILITY_SCORE + 5))
        fi
    fi

    [[ $PH_STABILITY_SCORE -lt 0 ]] && PH_STABILITY_SCORE=0
    [[ $PH_STABILITY_SCORE -gt 100 ]] && PH_STABILITY_SCORE=100

    echo "$PH_STABILITY_SCORE"
    return 0
}

# =============================================================================
# 全監査実行
# =============================================================================
_ph_full_audit() {
    local project_dir="${1:-.}"
    [[ "$PH_INITIALIZED" != "true" ]] && _ph_init

    _PH_ISSUES=()
    _PH_CRITICAL_ISSUES=()
    PH_ISSUES_FOUND=0
    PH_ISSUES_CRITICAL=0

    echo "  [PH] Production Hardening Audit v${PH_VERSION}" >&2
    echo "  [PH] ========================================" >&2

    _ph_stress_test "$project_dir"
    echo "  [PH] Stress Test:     ${PH_STRESS_SCORE}/100" >&2

    _ph_security_audit "$project_dir"
    echo "  [PH] Security Audit:  ${PH_SECURITY_SCORE}/100" >&2

    _ph_performance_audit "$project_dir"
    echo "  [PH] Performance:     ${PH_PERFORMANCE_SCORE}/100" >&2

    _ph_stability_check "$project_dir"
    echo "  [PH] Stability:       ${PH_STABILITY_SCORE}/100" >&2

    PH_OVERALL_SCORE=$(( (PH_STRESS_SCORE + PH_SECURITY_SCORE + PH_PERFORMANCE_SCORE + PH_STABILITY_SCORE) / 4 ))

    echo "  [PH] ========================================" >&2
    echo "  [PH] Overall Score:   ${PH_OVERALL_SCORE}/100" >&2
    echo "  [PH] Issues:          ${PH_ISSUES_FOUND} (Critical: ${PH_ISSUES_CRITICAL})" >&2

    _ph_certification
    return 0
}

# =============================================================================
# 本番認証
# =============================================================================
_ph_certification() {
    if [[ $PH_OVERALL_SCORE -ge 70 && $PH_ISSUES_CRITICAL -eq 0 ]]; then
        PH_CERTIFIED=true
        echo "  [PH] CERTIFIED: Production-ready" >&2
    else
        PH_CERTIFIED=false
        echo "  [PH] NOT CERTIFIED: ${PH_ISSUES_CRITICAL} critical issues remaining" >&2
    fi

    local timestamp
    timestamp=$(date +%s)
    echo "{\"ts\":${timestamp},\"score\":${PH_OVERALL_SCORE},\"certified\":${PH_CERTIFIED},\"issues\":${PH_ISSUES_FOUND},\"critical\":${PH_ISSUES_CRITICAL}}" > "$PH_CERT_FILE" 2>/dev/null
}

_ph_report() {
    echo -e "\n  ${BOLD:-}═══ Production Hardening v${PH_VERSION} ═══${NC:-}"
    echo -e "  ストレス           : ${PH_STRESS_SCORE}/100"
    echo -e "  セキュリティ       : ${PH_SECURITY_SCORE}/100"
    echo -e "  パフォーマンス     : ${PH_PERFORMANCE_SCORE}/100"
    echo -e "  安定性             : ${PH_STABILITY_SCORE}/100"
    echo -e "  総合スコア         : ${PH_OVERALL_SCORE}/100"
    echo -e "  認証               : ${PH_CERTIFIED}"
    echo -e "  問題数             : ${PH_ISSUES_FOUND} (Critical: ${PH_ISSUES_CRITICAL})"
}

_ph_score() {
    [[ "$PH_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    echo "$PH_OVERALL_SCORE"
}

_ph_init_message() {
    echo -e "  ${GREEN:-}✅ v${PH_VERSION} production-hardening: 本番堅牢化エンジン${NC:-}" >&2
}

_mr_register \
    --name "production-hardening" \
    --version "$PH_VERSION" \
    --description "本番堅牢化エンジン" \
    --init "_ph_init" \
    --report "_ph_report" \
    --score "_ph_score" \
    --enable-var "ENABLE_PRODUCTION_HARDENING" \
    --cli-flags "--production-hardening:--no-production-hardening" \
    --init-msg "_ph_init_message"
