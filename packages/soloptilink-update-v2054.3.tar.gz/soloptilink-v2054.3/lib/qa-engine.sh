#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v11.0 - Exhaustive QA Engine
# =============================================================================
# v8.0: Tests EVERY interactive element - buttons, forms, routes, APIs, DB, security
# v11.0: Test auto-generation, coverage estimation, performance testing,
#         load test stub, dependency vulnerability check
# Usage: source lib/qa-engine.sh
# =============================================================================

# Color codes
readonly _QA_GREEN='\033[0;32m'  _QA_YELLOW='\033[0;33m'  _QA_RED='\033[0;31m'
readonly _QA_CYAN='\033[0;36m'   _QA_BOLD='\033[1m'        _QA_NC='\033[0m'

# Counters
_QA_PASS=0; _QA_FAIL=0; _QA_WARN=0; _QA_RESULTS=""

# --- Helpers ----------------------------------------------------------------

_qa_log() {
  local level="$1" message="$2" ts
  ts="$(date '+%Y-%m-%d %H:%M:%S')"
  case "$level" in
    PASS) printf "${_QA_GREEN}[QA PASS %s]${_QA_NC} %s\n" "$ts" "$message"; ((_QA_PASS++)) ;;
    FAIL) printf "${_QA_RED}[QA FAIL %s]${_QA_NC} %s\n"   "$ts" "$message"; ((_QA_FAIL++)) ;;
    WARN) printf "${_QA_YELLOW}[QA WARN %s]${_QA_NC} %s\n" "$ts" "$message"; ((_QA_WARN++)) ;;
    INFO) printf "${_QA_CYAN}[QA INFO %s]${_QA_NC} %s\n"   "$ts" "$message" ;;
    *)    printf "[QA %s] %s\n" "$ts" "$message" ;;
  esac
  _QA_RESULTS+="${level}: ${message}\n"
}

_qa_call_claude() {
  claude -p --dangerously-skip-permissions --output-format text "$1" 2>/dev/null
}

_qa_find_files() {
  local dir="$1" pattern="$2"
  find "$dir" -type f -name "$pattern" \
    ! -path '*/node_modules/*' ! -path '*/.git/*' \
    ! -path '*/dist/*' ! -path '*/build/*' ! -path '*/.next/*' ! -path '*/vendor/*' \
    2>/dev/null
}

# --- qa_init(project_dir) --------------------------------------------------

qa_init() {
  local project_dir="$1"
  [[ -z "$project_dir" || ! -d "$project_dir" ]] && { _qa_log FAIL "Invalid project dir: ${project_dir}"; return 1; }
  _QA_PASS=0; _QA_FAIL=0; _QA_WARN=0; _QA_RESULTS=""
  _qa_log INFO "Initialising QA for: ${project_dir}"

  QA_PROJECT_TYPE="unknown"
  if [[ -f "${project_dir}/package.json" ]]; then
    QA_PROJECT_TYPE="node"
    grep -q '"react"'  "${project_dir}/package.json" 2>/dev/null && QA_PROJECT_TYPE="react"
    grep -q '"next"'   "${project_dir}/package.json" 2>/dev/null && QA_PROJECT_TYPE="nextjs"
    grep -q '"vue"'    "${project_dir}/package.json" 2>/dev/null && QA_PROJECT_TYPE="vue"
    grep -q '"svelte"' "${project_dir}/package.json" 2>/dev/null && QA_PROJECT_TYPE="svelte"
  elif [[ -f "${project_dir}/requirements.txt" || -f "${project_dir}/pyproject.toml" ]]; then
    QA_PROJECT_TYPE="python"
  elif [[ -f "${project_dir}/Cargo.toml" ]]; then QA_PROJECT_TYPE="rust"
  elif [[ -f "${project_dir}/go.mod" ]]; then       QA_PROJECT_TYPE="go"
  fi
  export QA_PROJECT_TYPE
  _qa_log INFO "Detected project type: ${QA_PROJECT_TYPE}"
}

# --- qa_test_all_buttons(project_dir) ---------------------------------------

qa_test_all_buttons() {
  local project_dir="$1"
  _qa_log INFO "Testing all button / click handlers ..."

  local all_files
  all_files="$(_qa_find_files "$project_dir" '*.js')
$(_qa_find_files "$project_dir" '*.tsx')
$(_qa_find_files "$project_dir" '*.vue')
$(_qa_find_files "$project_dir" '*.svelte')"
  all_files="$(echo "$all_files" | sed '/^$/d')"
  [[ -z "$all_files" ]] && { _qa_log WARN "No JS/TSX/Vue/Svelte files - skipping"; return 0; }

  local handler_count=0 missing_count=0
  while IFS= read -r file; do
    [[ -z "$file" ]] && continue
    local handlers
    handlers="$(grep -nE '(onClick|@click|on:click|onclick)\s*=' "$file" 2>/dev/null)"
    [[ -z "$handlers" ]] && continue
    local n; n="$(echo "$handlers" | wc -l | tr -d ' ')"
    handler_count=$(( handler_count + n ))

    local analysis
    analysis="$(_qa_call_claude "Analyse click handlers from ${file}. For each: 1) handler exists/imported? 2) unhandled throw? 3) edge cases? Reply JSON [{\"line\":N,\"status\":\"pass|fail|warn\",\"reason\":\"...\"}]. Handlers:\n${handlers}\n\nFile (first 200 lines):\n$(head -200 "$file")")"
    if echo "$analysis" | grep -q '"fail"'; then
      _qa_log FAIL "Button handler issues: $(basename "$file")"
      missing_count=$(( missing_count + 1 ))
    else
      _qa_log PASS "Button handlers OK: $(basename "$file") (${n})"
    fi
  done <<< "$all_files"
  _qa_log INFO "Button audit: ${handler_count} handlers, ${missing_count} issues"
}

# --- qa_test_all_forms(project_dir) -----------------------------------------

qa_test_all_forms() {
  local project_dir="$1"
  _qa_log INFO "Testing all form submissions ..."

  local all_files
  all_files="$(_qa_find_files "$project_dir" '*.tsx')
$(_qa_find_files "$project_dir" '*.jsx')
$(_qa_find_files "$project_dir" '*.vue')
$(_qa_find_files "$project_dir" '*.svelte')
$(_qa_find_files "$project_dir" '*.html')"
  all_files="$(echo "$all_files" | sed '/^$/d')"
  [[ -z "$all_files" ]] && { _qa_log WARN "No template files - skipping forms"; return 0; }

  local form_count=0
  while IFS= read -r file; do
    [[ -z "$file" ]] && continue
    grep -qE '<form' "$file" 2>/dev/null || continue
    form_count=$(( form_count + 1 ))

    if ! grep -qE '(onSubmit|@submit|on:submit|action=)' "$file" 2>/dev/null; then
      _qa_log FAIL "Form without submit handler: $(basename "$file")"; continue
    fi
    local req; req="$(grep -cE '(required|aria-required|\.required)' "$file" 2>/dev/null || echo 0)"
    (( req == 0 )) && _qa_log WARN "No required-field markers: $(basename "$file")"
    if grep -qE '(error|Error|err|invalid|Invalid)' "$file" 2>/dev/null; then
      _qa_log PASS "Form validation OK: $(basename "$file")"
    else
      _qa_log WARN "Form may lack error display: $(basename "$file")"
    fi
  done <<< "$all_files"
  (( form_count == 0 )) && _qa_log INFO "No <form> elements detected" || _qa_log INFO "Form audit: ${form_count} form(s)"
}

# --- qa_test_all_routes(project_dir) ----------------------------------------

qa_test_all_routes() {
  local project_dir="$1"
  _qa_log INFO "Testing all routes ..."

  local router_files
  router_files="$(_qa_find_files "$project_dir" 'router.*')
$(_qa_find_files "$project_dir" 'routes.*')
$(_qa_find_files "$project_dir" 'App.tsx')
$(_qa_find_files "$project_dir" 'App.jsx')
$(_qa_find_files "$project_dir" 'app.py')
$(_qa_find_files "$project_dir" 'urls.py')"
  router_files="$(echo "$router_files" | sed '/^$/d' | sort -u)"
  [[ -z "$router_files" ]] && { _qa_log INFO "No router configs - skipping"; return 0; }

  local route_count=0 issue_count=0
  while IFS= read -r rfile; do
    [[ -z "$rfile" || ! -f "$rfile" ]] && continue
    local routes
    routes="$(grep -oE "(path|route|Route)\s*[:=(\[]\s*['\"][^'\"]+['\"]" "$rfile" 2>/dev/null)"
    [[ -z "$routes" ]] && continue
    local n; n="$(echo "$routes" | wc -l | tr -d ' ')"
    route_count=$(( route_count + n ))

    local out
    out="$(_qa_call_claude "Analyse routes from ${rfile}. For each: component/handler exists? 404 catch-all? Reply concisely, issues only.\nRoutes:\n${routes}\nFile (first 300 lines):\n$(head -300 "$rfile")")"
    if echo "$out" | grep -qiE '(missing|no 404|not found|undefined)'; then
      _qa_log WARN "Route issues: $(basename "$rfile")"; issue_count=$(( issue_count + 1 ))
    else
      _qa_log PASS "Routes OK: $(basename "$rfile") (${n})"
    fi
  done <<< "$router_files"

  # 404 check
  local has_404; has_404="$(_qa_find_files "$project_dir" '*404*' | head -1)"
  if [[ -z "$has_404" ]]; then
    grep -rlE '(\*|catch.?all|notFound|not-found|NotFound)' "$project_dir/src" 2>/dev/null | head -1 | grep -q . \
      || _qa_log WARN "No 404 / catch-all page detected"
  fi
  _qa_log INFO "Route audit: ${route_count} route(s), ${issue_count} issue(s)"
}

# --- qa_test_api_endpoints(project_dir) -------------------------------------

qa_test_api_endpoints() {
  local project_dir="$1"
  _qa_log INFO "Testing API endpoints ..."

  local api_files
  api_files="$(_qa_find_files "$project_dir" '*.controller.*')
$(_qa_find_files "$project_dir" '*.route.*')
$(_qa_find_files "$project_dir" '*.api.*')
$(_qa_find_files "$project_dir" 'views.py')
$(_qa_find_files "$project_dir" 'handlers.go')
$(grep -rlE '\.(get|post|put|delete|patch)\s*\(' "$project_dir/src" 2>/dev/null | head -30)"
  api_files="$(echo "$api_files" | sed '/^$/d' | sort -u)"
  [[ -z "$api_files" ]] && { _qa_log INFO "No API endpoints found - skipping"; return 0; }

  local ep_total=0
  while IFS= read -r afile; do
    [[ -z "$afile" || ! -f "$afile" ]] && continue
    local n; n="$(grep -cE '\.(get|post|put|delete|patch)\s*\(' "$afile" 2>/dev/null || echo 0)"
    ep_total=$(( ep_total + n ))

    # Error handling
    if grep -qE '(try\s*\{|catch\s*\(|\.catch\(|except |rescue )' "$afile" 2>/dev/null; then
      _qa_log PASS "Error handling present: $(basename "$afile")"
    else
      _qa_log FAIL "No error handling: $(basename "$afile")"
    fi
    # Auth
    if grep -qE '(auth|Auth|authenticate|protect|guard|jwt|token|session)' "$afile" 2>/dev/null; then
      _qa_log PASS "Auth refs found: $(basename "$afile")"
    else
      _qa_log WARN "No auth middleware: $(basename "$afile")"
    fi
    # Validation
    if grep -qE '(validate|sanitize|zod|yup|joi|class-validator|pydantic)' "$afile" 2>/dev/null; then
      _qa_log PASS "Input validation: $(basename "$afile")"
    else
      _qa_log WARN "No input validation lib: $(basename "$afile")"
    fi
  done <<< "$api_files"
  _qa_log INFO "API audit: ~${ep_total} endpoint(s)"
}

# --- qa_test_database(project_dir) ------------------------------------------

qa_test_database() {
  local project_dir="$1"
  _qa_log INFO "Testing database layer ..."

  local db_files
  db_files="$(grep -rlE '(SELECT|INSERT|UPDATE|DELETE|CREATE TABLE|query\(|prisma|sequelize|mongoose|knex|typeorm|drizzle)' \
    "$project_dir/src" "$project_dir/lib" "$project_dir/app" 2>/dev/null \
    | grep -v node_modules | grep -v '.git' | head -40)"
  [[ -z "$db_files" ]] && { _qa_log INFO "No DB query files - skipping"; return 0; }

  local issues=0
  while IFS= read -r dbf; do
    [[ -z "$dbf" || ! -f "$dbf" ]] && continue
    # SQL injection risk
    if grep -nE '(query\s*\(\s*[`"'"'"'].*\$\{|execute\s*\(\s*f['"'"'"])' "$dbf" 2>/dev/null | grep -q .; then
      _qa_log FAIL "SQL injection risk: $(basename "$dbf")"; issues=$(( issues + 1 ))
    fi
    # Error handling
    if grep -qE '(try\s*\{|\.catch\(|except |rescue )' "$dbf" 2>/dev/null; then
      _qa_log PASS "DB error handling: $(basename "$dbf")"
    else
      _qa_log WARN "DB lacks error handling: $(basename "$dbf")"; issues=$(( issues + 1 ))
    fi
  done <<< "$db_files"

  # Migrations
  local mdir; mdir="$(find "$project_dir" -type d -name 'migrations' ! -path '*/node_modules/*' 2>/dev/null | head -1)"
  if [[ -n "$mdir" ]]; then
    _qa_log INFO "Migrations dir found: ${mdir}"
  elif [[ -f "${project_dir}/prisma/schema.prisma" ]]; then _qa_log PASS "Prisma schema detected"
  elif [[ -d "${project_dir}/drizzle" ]]; then               _qa_log PASS "Drizzle migrations detected"
  else _qa_log WARN "No migration system detected"
  fi
  _qa_log INFO "DB audit: ${issues} issue(s)"
}

# --- qa_security_scan(project_dir) ------------------------------------------

qa_security_scan() {
  local project_dir="$1"
  _qa_log INFO "Running security scan ..."
  local issues=0 hits

  # 1. Hardcoded secrets
  hits="$(grep -rnE '(API_KEY|SECRET_KEY|PASSWORD|PRIVATE_KEY|ACCESS_TOKEN|api_key|secret|password)\s*[:=]\s*['"'"'"][A-Za-z0-9]' \
    "$project_dir/src" "$project_dir/lib" "$project_dir/app" 2>/dev/null \
    | grep -v node_modules | grep -v .env.example | head -20)"
  if [[ -n "$hits" ]]; then
    _qa_log FAIL "Hardcoded secrets found"; issues=$(( issues + 1 ))
    echo "$hits" | while IFS= read -r l; do printf "  ${_QA_RED}%s${_QA_NC}\n" "$l"; done
  else _qa_log PASS "No hardcoded secrets"
  fi

  # 2. eval()
  hits="$(grep -rnE '\beval\s*\(' "$project_dir/src" "$project_dir/lib" 2>/dev/null \
    | grep -v node_modules | grep -v test | head -10)"
  if [[ -n "$hits" ]]; then
    _qa_log FAIL "Dangerous eval() usage"; issues=$(( issues + 1 ))
    echo "$hits" | while IFS= read -r l; do printf "  ${_QA_RED}%s${_QA_NC}\n" "$l"; done
  else _qa_log PASS "No eval() usage"
  fi

  # 3. innerHTML / dangerouslySetInnerHTML
  hits="$(grep -rnE '(innerHTML\s*=|dangerouslySetInnerHTML|v-html)' "$project_dir/src" 2>/dev/null \
    | grep -v node_modules | head -10)"
  if [[ -n "$hits" ]]; then
    _qa_log WARN "innerHTML usage found (verify sanitisation)"; issues=$(( issues + 1 ))
  else _qa_log PASS "No dangerous innerHTML"
  fi

  # 4. CORS
  hits="$(grep -rnE '(cors|CORS|Access-Control-Allow-Origin)' "$project_dir/src" "$project_dir/lib" 2>/dev/null \
    | grep -v node_modules | head -10)"
  if [[ -n "$hits" ]]; then
    if echo "$hits" | grep -qE '(\*|origin:\s*true)'; then
      _qa_log WARN "CORS wildcard origin detected"
    else _qa_log PASS "CORS restricted"
    fi
  else _qa_log INFO "No CORS config found"
  fi

  # 5. Auth middleware
  local auth_f
  auth_f="$(grep -rlE '(middleware.*auth|auth.*middleware|protect|guard|jwt\.verify|passport\.)' \
    "$project_dir/src" "$project_dir/lib" 2>/dev/null | grep -v node_modules | head -5)"
  if [[ -n "$auth_f" ]]; then
    _qa_log PASS "Auth middleware found"
  else _qa_log WARN "No auth middleware detected"
  fi

  # 6. .env exposure
  if [[ -f "${project_dir}/.env" ]]; then
    if grep -q '\.env' "${project_dir}/.gitignore" 2>/dev/null; then
      _qa_log PASS ".env properly gitignored"
    else
      _qa_log FAIL ".env NOT in .gitignore"; issues=$(( issues + 1 ))
    fi
  fi
  _qa_log INFO "Security scan: ${issues} issue(s)"
}

# --- qa_suggest_missing_tests(project_dir) ----------------------------------

qa_suggest_missing_tests() {
  local project_dir="$1"
  _qa_log INFO "Asking Claude for missing test suggestions ..."

  local structure
  structure="$(find "$project_dir/src" "$project_dir/lib" "$project_dir/app" \
    -type f \( -name '*.ts' -o -name '*.tsx' -o -name '*.js' -o -name '*.jsx' -o -name '*.py' -o -name '*.go' \) \
    ! -path '*/node_modules/*' ! -path '*/.git/*' 2>/dev/null | head -80)"

  local test_files
  test_files="$(find "$project_dir" \
    -type f \( -name '*.test.*' -o -name '*.spec.*' -o -name 'test_*' -o -name '*_test.*' \) \
    ! -path '*/node_modules/*' ! -path '*/.git/*' 2>/dev/null | head -40)"

  local suggestion
  suggestion="$(_qa_call_claude "Given this project, suggest missing tests. Focus on: 1) source files with no test 2) critical integration tests 3) untested edge cases. Be specific.

Source files:
${structure}

Existing tests:
${test_files:-'(none found)'}")"

  if [[ -n "$suggestion" ]]; then
    printf "\n${_QA_BOLD}${_QA_CYAN}=== Missing Test Suggestions ===${_QA_NC}\n"
    printf '%s\n' "$suggestion"
    printf "${_QA_CYAN}=================================${_QA_NC}\n\n"
  else
    _qa_log WARN "Claude returned no suggestions"
  fi
}

# =============================================================================
# v11.0: Test Auto-Generation
# =============================================================================

# qa_generate_tests(project_dir) - Claude-driven test generation
qa_generate_tests() {
  local project_dir="$1"
  _qa_log INFO "v11.0: Auto-generating tests ..."

  local test_framework=""
  local test_dir=""
  local test_ext=""

  # Detect test framework and set output paths
  case "${QA_PROJECT_TYPE:-unknown}" in
    node|react|nextjs|vue|svelte)
      if [[ -f "${project_dir}/package.json" ]]; then
        if grep -qE '"jest"' "${project_dir}/package.json" 2>/dev/null; then
          test_framework="jest"
        elif grep -qE '"vitest"' "${project_dir}/package.json" 2>/dev/null; then
          test_framework="vitest"
        elif grep -qE '"mocha"' "${project_dir}/package.json" 2>/dev/null; then
          test_framework="mocha"
        else
          test_framework="jest"  # default for Node ecosystem
        fi
      fi
      test_dir="${project_dir}/tests"
      test_ext=".test.ts"
      # Use .test.js if no TypeScript
      [[ ! -f "${project_dir}/tsconfig.json" ]] && test_ext=".test.js"
      ;;
    python)
      test_framework="pytest"
      test_dir="${project_dir}/tests"
      test_ext="_test.py"
      # Alternative: test_*.py
      if [[ -d "${project_dir}/tests" ]] && find "${project_dir}/tests" -name "test_*" -type f 2>/dev/null | head -1 | grep -q .; then
        test_ext=".py"  # Will prefix with test_
      fi
      ;;
    go)
      test_framework="go_test"
      test_dir=""  # Go tests live alongside source
      test_ext="_test.go"
      ;;
    rust)
      test_framework="cargo_test"
      test_dir="${project_dir}/tests"
      test_ext=".rs"
      ;;
    *)
      _qa_log WARN "Cannot determine test framework for project type: ${QA_PROJECT_TYPE}"
      return 1
      ;;
  esac

  _qa_log INFO "Test framework: ${test_framework} | Output: ${test_dir:-alongside source}"

  # Gather source files without tests
  local source_files untested_files=()
  source_files="$(find "$project_dir/src" "$project_dir/lib" "$project_dir/app" \
    -type f \( -name '*.ts' -o -name '*.tsx' -o -name '*.js' -o -name '*.jsx' -o -name '*.py' -o -name '*.go' -o -name '*.rs' \) \
    ! -path '*/node_modules/*' ! -path '*/.git/*' ! -path '*/dist/*' ! -path '*/build/*' \
    ! -name '*.test.*' ! -name '*.spec.*' ! -name 'test_*' ! -name '*_test.*' \
    2>/dev/null | head -50)"

  while IFS= read -r sf; do
    [[ -z "$sf" ]] && continue
    local base_name="${sf##*/}"
    local name_no_ext="${base_name%.*}"
    # Check if a test file exists for this source file
    local has_test=false
    find "$project_dir" \
      -type f \( -name "${name_no_ext}.test.*" -o -name "${name_no_ext}.spec.*" -o -name "test_${name_no_ext}.*" -o -name "${name_no_ext}_test.*" \) \
      ! -path '*/node_modules/*' 2>/dev/null | head -1 | grep -q . && has_test=true
    [[ "$has_test" == "false" ]] && untested_files+=("$sf")
  done <<< "$source_files"

  local untested_count=${#untested_files[@]}
  if [[ "$untested_count" -eq 0 ]]; then
    _qa_log PASS "All source files have corresponding test files"
    return 0
  fi

  _qa_log INFO "Found ${untested_count} untested source file(s)"

  # Generate tests for each untested file (max 10 at a time)
  local generated=0 failed=0
  local max_generate=10
  [[ -n "$test_dir" ]] && mkdir -p "$test_dir" 2>/dev/null

  for sf in "${untested_files[@]}"; do
    [[ "$generated" -ge "$max_generate" ]] && break

    local base_name="${sf##*/}"
    local name_no_ext="${base_name%.*}"
    local file_content
    file_content=$(head -200 "$sf" 2>/dev/null)
    [[ -z "$file_content" ]] && continue

    _qa_log INFO "Generating tests for: ${base_name}"

    local prompt="Generate ${test_framework} test file for the following source code.
Include tests for all exported functions/classes/components.
Cover: normal cases, edge cases, error handling.
Output ONLY the test code, no explanations.

Framework: ${test_framework}
File: ${base_name}

Source code:
${file_content}"

    local test_code
    test_code=$(_qa_call_claude "$prompt")
    if [[ -z "$test_code" ]]; then
      _qa_log WARN "Failed to generate tests for: ${base_name}"
      failed=$((failed + 1))
      continue
    fi

    # Remove code block markers
    test_code=$(echo "$test_code" | sed '/^```[a-zA-Z]*/d; /^```$/d')

    # Determine output path
    local test_output_path
    case "$test_framework" in
      jest|vitest|mocha)
        test_output_path="${test_dir}/${name_no_ext}${test_ext}"
        ;;
      pytest)
        test_output_path="${test_dir}/test_${name_no_ext}.py"
        ;;
      go_test)
        local src_dir
        src_dir="$(dirname "$sf")"
        test_output_path="${src_dir}/${name_no_ext}_test.go"
        ;;
      cargo_test)
        test_output_path="${test_dir}/${name_no_ext}${test_ext}"
        ;;
      *)
        test_output_path="${test_dir}/${name_no_ext}${test_ext}"
        ;;
    esac

    # Write test file (only if it doesn't already exist)
    if [[ ! -f "$test_output_path" ]]; then
      mkdir -p "$(dirname "$test_output_path")" 2>/dev/null
      printf '%s\n' "$test_code" > "$test_output_path"
      _qa_log PASS "Generated: ${test_output_path##*/}"
      generated=$((generated + 1))
    else
      _qa_log WARN "Test file already exists: ${test_output_path##*/}"
    fi
  done

  _qa_log INFO "Test generation: ${generated} created, ${failed} failed, ${untested_count} total untested"
  echo "${generated}"
}

# =============================================================================
# v11.0: Coverage Estimation
# =============================================================================

# qa_estimate_coverage(project_dir) - Estimate test coverage without running tests
qa_estimate_coverage() {
  local project_dir="$1"
  _qa_log INFO "v11.0: Estimating test coverage ..."

  local total_functions=0 tested_functions=0
  local coverage_details=""

  # Collect all source files
  local source_files
  source_files="$(find "$project_dir/src" "$project_dir/lib" "$project_dir/app" \
    -type f \( -name '*.ts' -o -name '*.tsx' -o -name '*.js' -o -name '*.jsx' -o -name '*.py' -o -name '*.go' \) \
    ! -path '*/node_modules/*' ! -path '*/.git/*' ! -path '*/dist/*' \
    ! -name '*.test.*' ! -name '*.spec.*' ! -name 'test_*' ! -name '*_test.*' \
    2>/dev/null | head -60)"

  [[ -z "$source_files" ]] && { _qa_log WARN "No source files found for coverage analysis"; return 0; }

  # Collect all test files
  local test_files
  test_files="$(find "$project_dir" \
    -type f \( -name '*.test.*' -o -name '*.spec.*' -o -name 'test_*' -o -name '*_test.*' \) \
    ! -path '*/node_modules/*' ! -path '*/.git/*' 2>/dev/null)"

  local test_content=""
  while IFS= read -r tf; do
    [[ -z "$tf" || ! -f "$tf" ]] && continue
    test_content+="$(cat "$tf" 2>/dev/null)\n"
  done <<< "$test_files"

  # Analyze each source file
  while IFS= read -r sf; do
    [[ -z "$sf" || ! -f "$sf" ]] && continue
    local base_name="${sf##*/}"
    local ext="${sf##*.}"

    # Extract function/method names
    local functions=""
    case "$ext" in
      js|jsx|ts|tsx)
        functions="$(grep -oE '(export\s+)?(async\s+)?function\s+\w+|const\s+\w+\s*=\s*(async\s+)?\(' "$sf" 2>/dev/null | \
          grep -oE '\b[a-zA-Z_]\w*\s*=' | sed 's/\s*=//g')"
        functions+=$'\n'"$(grep -oE 'function\s+\w+' "$sf" 2>/dev/null | sed 's/function\s*//')"
        ;;
      py)
        functions="$(grep -oE '^\s*def\s+\w+' "$sf" 2>/dev/null | sed 's/.*def\s*//' | grep -v '^_')"
        functions+=$'\n'"$(grep -oE '^\s*class\s+\w+' "$sf" 2>/dev/null | sed 's/.*class\s*//')"
        ;;
      go)
        functions="$(grep -oE '^func\s+(\(\w+\s+\*?\w+\)\s+)?\w+' "$sf" 2>/dev/null | grep -oE '\w+$')"
        ;;
    esac

    functions="$(echo "$functions" | sed '/^$/d' | sort -u)"
    [[ -z "$functions" ]] && continue

    local file_total=0 file_tested=0
    while IFS= read -r func; do
      [[ -z "$func" || ${#func} -lt 2 ]] && continue
      file_total=$((file_total + 1))
      total_functions=$((total_functions + 1))

      # Check if function name appears in test files
      if echo -e "$test_content" | grep -q "\b${func}\b" 2>/dev/null; then
        file_tested=$((file_tested + 1))
        tested_functions=$((tested_functions + 1))
      fi
    done <<< "$functions"

    local file_pct=0
    [[ "$file_total" -gt 0 ]] && file_pct=$(( (file_tested * 100) / file_total ))

    local color="${_QA_GREEN}"
    [[ "$file_pct" -lt 50 ]] && color="${_QA_RED}"
    [[ "$file_pct" -ge 50 && "$file_pct" -lt 80 ]] && color="${_QA_YELLOW}"

    coverage_details+="$(printf "${color}  %-40s %3d/%3d (%3d%%)${_QA_NC}\n" "$base_name" "$file_tested" "$file_total" "$file_pct")\n"
  done <<< "$source_files"

  # Overall coverage
  local overall_pct=0
  [[ "$total_functions" -gt 0 ]] && overall_pct=$(( (tested_functions * 100) / total_functions ))

  local overall_color="${_QA_GREEN}"
  [[ "$overall_pct" -lt 50 ]] && overall_color="${_QA_RED}"
  [[ "$overall_pct" -ge 50 && "$overall_pct" -lt 80 ]] && overall_color="${_QA_YELLOW}"

  printf "\n${_QA_BOLD}${_QA_CYAN}=== Coverage Estimation (v11.0) ===${_QA_NC}\n"
  printf "${_QA_BOLD}  %-40s %s${_QA_NC}\n" "FILE" "TESTED/TOTAL (%)"
  printf '  %s\n' "------------------------------------------------------"
  printf '%b' "$coverage_details"
  printf '  %s\n' "------------------------------------------------------"
  printf "  ${_QA_BOLD}${overall_color}OVERALL: %d/%d functions referenced in tests (%d%%)${_QA_NC}\n" \
    "$tested_functions" "$total_functions" "$overall_pct"
  printf "${_QA_CYAN}====================================${_QA_NC}\n\n"

  if [[ "$overall_pct" -ge 80 ]]; then
    _qa_log PASS "Coverage estimation: ${overall_pct}% (good)"
  elif [[ "$overall_pct" -ge 50 ]]; then
    _qa_log WARN "Coverage estimation: ${overall_pct}% (needs improvement)"
  else
    _qa_log FAIL "Coverage estimation: ${overall_pct}% (low coverage)"
  fi

  echo "$overall_pct"
}

# =============================================================================
# v11.0: Performance Testing
# =============================================================================

# qa_performance_check(project_dir) - Check response times and performance
qa_performance_check() {
  local project_dir="$1"
  _qa_log INFO "v11.0: Running performance checks ..."

  local issues=0

  # 1. Bundle size analysis (for Node/frontend projects)
  if [[ -f "${project_dir}/package.json" ]]; then
    # Check if build output exists
    local build_dir=""
    [[ -d "${project_dir}/dist" ]] && build_dir="${project_dir}/dist"
    [[ -d "${project_dir}/build" ]] && build_dir="${project_dir}/build"
    [[ -d "${project_dir}/.next" ]] && build_dir="${project_dir}/.next"

    if [[ -n "$build_dir" ]]; then
      local total_size
      total_size=$(du -sk "$build_dir" 2>/dev/null | cut -f1)
      if [[ -n "$total_size" && "$total_size" -gt 0 ]]; then
        local size_mb=$(( total_size / 1024 ))
        if [[ "$size_mb" -gt 10 ]]; then
          _qa_log WARN "Build output large: ${size_mb}MB (consider code splitting)"
          issues=$((issues + 1))
        elif [[ "$size_mb" -gt 5 ]]; then
          _qa_log WARN "Build output: ${size_mb}MB"
        else
          _qa_log PASS "Build output: ${size_mb}MB (good)"
        fi
      fi

      # Check for large JS bundles
      local large_js
      large_js="$(find "$build_dir" -name '*.js' -size +500k 2>/dev/null | head -5)"
      if [[ -n "$large_js" ]]; then
        _qa_log WARN "Large JS bundles detected (>500KB):"
        echo "$large_js" | while IFS= read -r jf; do
          local sz
          sz=$(du -sk "$jf" 2>/dev/null | cut -f1)
          printf "  ${_QA_YELLOW}%s (%dKB)${_QA_NC}\n" "$(basename "$jf")" "$sz"
        done
        issues=$((issues + 1))
      else
        _qa_log PASS "No oversized JS bundles"
      fi
    else
      _qa_log INFO "No build output found - run build first for bundle analysis"
    fi

    # Check package.json for known heavy dependencies
    local heavy_deps=("moment" "lodash" "jquery" "rxjs" "core-js")
    for dep in "${heavy_deps[@]}"; do
      if grep -q "\"${dep}\"" "${project_dir}/package.json" 2>/dev/null; then
        case "$dep" in
          moment)  _qa_log WARN "Heavy dep: moment.js - consider day.js or date-fns" ;;
          lodash)  _qa_log WARN "Heavy dep: lodash - consider lodash-es or individual imports" ;;
          jquery)  _qa_log WARN "Heavy dep: jquery - consider native APIs" ;;
          *)       _qa_log INFO "Dep check: ${dep} present" ;;
        esac
      fi
    done
  fi

  # 2. Response time check for running servers
  local server_port=""
  # Try to detect running dev server
  for port in 3000 3001 5173 8080 8000 4200 5000; do
    if curl -s -o /dev/null -w "%{http_code}" "http://localhost:${port}" 2>/dev/null | grep -qE '^(200|301|302|304)'; then
      server_port=$port
      break
    fi
  done

  if [[ -n "$server_port" ]]; then
    _qa_log INFO "Found running server on port ${server_port}"

    # Measure response time
    local response_time
    response_time=$(curl -s -o /dev/null -w "%{time_total}" "http://localhost:${server_port}" 2>/dev/null)
    if [[ -n "$response_time" ]]; then
      # Convert to ms (bash can't do floating point, use awk)
      local ms
      ms=$(echo "$response_time" | awk '{printf "%.0f", $1 * 1000}')
      if [[ "$ms" -gt 3000 ]]; then
        _qa_log FAIL "Slow response: ${ms}ms (>3s)"; issues=$((issues + 1))
      elif [[ "$ms" -gt 1000 ]]; then
        _qa_log WARN "Response time: ${ms}ms (>1s)"
      else
        _qa_log PASS "Response time: ${ms}ms (good)"
      fi

      # TTFB (Time to First Byte)
      local ttfb
      ttfb=$(curl -s -o /dev/null -w "%{time_starttransfer}" "http://localhost:${server_port}" 2>/dev/null)
      local ttfb_ms
      ttfb_ms=$(echo "$ttfb" | awk '{printf "%.0f", $1 * 1000}')
      if [[ "$ttfb_ms" -gt 500 ]]; then
        _qa_log WARN "TTFB: ${ttfb_ms}ms (consider server-side optimization)"
      else
        _qa_log PASS "TTFB: ${ttfb_ms}ms"
      fi
    fi
  else
    _qa_log INFO "No running server detected - skipping response time check"
  fi

  # 3. Source code performance anti-patterns
  local perf_issues=0
  local src_files
  src_files="$(_qa_find_files "$project_dir" '*.js')
$(_qa_find_files "$project_dir" '*.tsx')
$(_qa_find_files "$project_dir" '*.ts')
$(_qa_find_files "$project_dir" '*.py')"

  # Check for N+1 patterns (nested loops with DB calls)
  local n_plus_1
  n_plus_1="$(grep -rlE '(for.*await.*query|for.*await.*find|for.*await.*fetch|\.map\(.*await)' \
    "$project_dir/src" "$project_dir/lib" 2>/dev/null | grep -v node_modules | head -5)"
  if [[ -n "$n_plus_1" ]]; then
    _qa_log WARN "Potential N+1 query pattern detected"
    echo "$n_plus_1" | while IFS= read -r f; do
      printf "  ${_QA_YELLOW}%s${_QA_NC}\n" "$(basename "$f")"
    done
    perf_issues=$((perf_issues + 1))
  fi

  # Check for missing React.memo / useMemo / useCallback
  if [[ "${QA_PROJECT_TYPE}" =~ ^(react|nextjs)$ ]]; then
    local components
    components="$(_qa_find_files "$project_dir" '*.tsx')
$(_qa_find_files "$project_dir" '*.jsx')"
    local comp_count
    comp_count=$(echo "$components" | sed '/^$/d' | wc -l | tr -d ' ')
    local memo_count
    memo_count=$(grep -rlE '(React\.memo|useMemo|useCallback|memo\()' "$project_dir/src" 2>/dev/null | wc -l | tr -d ' ')
    if [[ "$comp_count" -gt 10 && "$memo_count" -lt 3 ]]; then
      _qa_log WARN "React: ${comp_count} components but few memoization hooks (${memo_count}) - consider optimization"
    fi
  fi

  _qa_log INFO "Performance check: ${issues} issue(s), ${perf_issues} anti-pattern(s)"
}

# =============================================================================
# v11.0: Load Test Stub (using curl)
# =============================================================================

# qa_load_test(project_dir, url, concurrent) - Basic load testing with curl
qa_load_test() {
  local project_dir="$1"
  local url="${2:-}"
  local concurrent="${3:-10}"
  local total_requests="${4:-50}"

  # Auto-detect URL if not provided
  if [[ -z "$url" ]]; then
    for port in 3000 3001 5173 8080 8000 4200 5000; do
      if curl -s -o /dev/null -w "%{http_code}" "http://localhost:${port}" 2>/dev/null | grep -qE '^(200|301|302)'; then
        url="http://localhost:${port}"
        break
      fi
    done
  fi

  if [[ -z "$url" ]]; then
    _qa_log WARN "No URL provided and no local server detected - skipping load test"
    return 0
  fi

  _qa_log INFO "v11.0: Load test starting - URL: ${url} | Concurrent: ${concurrent} | Total: ${total_requests}"

  local results_dir="${project_dir}/docs/chain-logs/load_test_$(date +%s)"
  mkdir -p "$results_dir" 2>/dev/null

  local success=0 failed=0 total_time=0
  local pids=() slot=0
  local results_file="${results_dir}/results.txt"
  : > "$results_file"

  for i in $(seq 1 "$total_requests"); do
    # Throttle concurrent requests
    while [[ "$slot" -ge "$concurrent" ]]; do
      local new_pids=()
      for pid in "${pids[@]}"; do
        if kill -0 "$pid" 2>/dev/null; then
          new_pids+=("$pid")
        else
          slot=$((slot - 1))
        fi
      done
      pids=("${new_pids[@]}")
      [[ "$slot" -ge "$concurrent" ]] && sleep 0.1
    done

    # Fire request in background
    (
      local start_ts end_ts duration http_code
      start_ts=$(date +%s%N 2>/dev/null || date +%s)
      http_code=$(curl -s -o /dev/null -w "%{http_code}|%{time_total}" --max-time 30 "$url" 2>/dev/null || echo "000|30.0")
      echo "${http_code}" >> "$results_file"
    ) &
    pids+=($!)
    slot=$((slot + 1))
  done

  # Wait for all requests
  for pid in "${pids[@]}"; do
    wait "$pid" 2>/dev/null || true
  done

  # Analyze results
  local total_done=0 ok_count=0 err_count=0
  local total_seconds=0 min_time=99999 max_time=0

  while IFS='|' read -r code timing; do
    [[ -z "$code" ]] && continue
    total_done=$((total_done + 1))
    local ms
    ms=$(echo "$timing" | awk '{printf "%.0f", $1 * 1000}' 2>/dev/null || echo "0")
    total_seconds=$((total_seconds + ms))
    [[ "$ms" -lt "$min_time" ]] && min_time=$ms
    [[ "$ms" -gt "$max_time" ]] && max_time=$ms

    if [[ "$code" =~ ^(200|201|301|302|304)$ ]]; then
      ok_count=$((ok_count + 1))
    else
      err_count=$((err_count + 1))
    fi
  done < "$results_file"

  local avg_time=0
  [[ "$total_done" -gt 0 ]] && avg_time=$((total_seconds / total_done))
  local err_rate=0
  [[ "$total_done" -gt 0 ]] && err_rate=$(( (err_count * 100) / total_done ))

  printf "\n${_QA_BOLD}${_QA_CYAN}=== Load Test Results (v11.0) ===${_QA_NC}\n"
  printf "  URL:          %s\n" "$url"
  printf "  Concurrency:  %d\n" "$concurrent"
  printf "  Total:        %d requests\n" "$total_done"
  printf "  ${_QA_GREEN}Success:      %d${_QA_NC}\n" "$ok_count"
  printf "  ${_QA_RED}Failed:       %d (%.1f%%)${_QA_NC}\n" "$err_count" "$err_rate"
  printf "  Avg time:     %dms\n" "$avg_time"
  printf "  Min time:     %dms\n" "$min_time"
  printf "  Max time:     %dms\n" "$max_time"
  printf "${_QA_CYAN}=================================${_QA_NC}\n\n"

  if [[ "$err_rate" -gt 10 ]]; then
    _qa_log FAIL "Load test: ${err_rate}% error rate (too high)"
  elif [[ "$avg_time" -gt 2000 ]]; then
    _qa_log WARN "Load test: Avg ${avg_time}ms (slow under load)"
  else
    _qa_log PASS "Load test: ${ok_count}/${total_done} OK, avg ${avg_time}ms"
  fi

  # Save report
  {
    echo "{\"url\":\"${url}\",\"concurrent\":${concurrent},\"total\":${total_done},"
    echo "\"success\":${ok_count},\"failed\":${err_count},\"error_rate\":${err_rate},"
    echo "\"avg_ms\":${avg_time},\"min_ms\":${min_time},\"max_ms\":${max_time},"
    echo "\"timestamp\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}"
  } > "${results_dir}/load_test_report.json"

  _qa_log INFO "Load test report: ${results_dir}/load_test_report.json"
}

# =============================================================================
# v11.0: Dependency Check
# =============================================================================

# qa_check_dependencies(project_dir) - Check for outdated/vulnerable packages
qa_check_dependencies() {
  local project_dir="$1"
  _qa_log INFO "v11.0: Checking dependencies ..."

  local issues=0

  # --- Node.js / npm ---
  if [[ -f "${project_dir}/package.json" ]]; then
    _qa_log INFO "Checking Node.js dependencies ..."

    # npm audit (if available)
    if command -v npm &>/dev/null && [[ -d "${project_dir}/node_modules" ]]; then
      local audit_result
      audit_result=$(cd "$project_dir" && npm audit --json 2>/dev/null || echo '{}')
      if [[ -n "$audit_result" ]]; then
        local vuln_total
        vuln_total=$(echo "$audit_result" | grep -oE '"total":\s*[0-9]+' | head -1 | grep -oE '[0-9]+')
        vuln_total="${vuln_total:-0}"
        if [[ "$vuln_total" -gt 0 ]]; then
          local critical high moderate
          critical=$(echo "$audit_result" | grep -oE '"critical":\s*[0-9]+' | head -1 | grep -oE '[0-9]+' || echo "0")
          high=$(echo "$audit_result" | grep -oE '"high":\s*[0-9]+' | head -1 | grep -oE '[0-9]+' || echo "0")
          moderate=$(echo "$audit_result" | grep -oE '"moderate":\s*[0-9]+' | head -1 | grep -oE '[0-9]+' || echo "0")
          critical="${critical:-0}"; high="${high:-0}"; moderate="${moderate:-0}"

          if [[ "$critical" -gt 0 ]]; then
            _qa_log FAIL "npm audit: ${critical} critical, ${high} high, ${moderate} moderate vulnerabilities"
            issues=$((issues + 1))
          elif [[ "$high" -gt 0 ]]; then
            _qa_log WARN "npm audit: ${high} high, ${moderate} moderate vulnerabilities"
            issues=$((issues + 1))
          else
            _qa_log WARN "npm audit: ${moderate} moderate vulnerabilities"
          fi
        else
          _qa_log PASS "npm audit: No vulnerabilities found"
        fi
      fi

      # Check for outdated packages
      local outdated
      outdated=$(cd "$project_dir" && npm outdated --json 2>/dev/null || echo '{}')
      if [[ -n "$outdated" && "$outdated" != "{}" ]]; then
        local outdated_count
        outdated_count=$(echo "$outdated" | grep -c '"current"' 2>/dev/null || echo "0")
        if [[ "$outdated_count" -gt 10 ]]; then
          _qa_log WARN "npm outdated: ${outdated_count} packages behind"
        elif [[ "$outdated_count" -gt 0 ]]; then
          _qa_log INFO "npm outdated: ${outdated_count} package(s) have updates"
        fi

        # Check for major version gaps
        local major_gaps
        major_gaps=$(echo "$outdated" | grep -B1 '"latest"' 2>/dev/null | head -20)
        if [[ -n "$major_gaps" ]]; then
          _qa_log INFO "Run 'npm outdated' for details"
        fi
      else
        _qa_log PASS "All npm packages are up to date"
      fi
    else
      _qa_log INFO "node_modules not found - run npm install first"
    fi

    # Check for deprecated packages in package.json
    local deprecated_pkgs=("request" "node-uuid" "nomnom" "node-gyp-build" "left-pad")
    for dep in "${deprecated_pkgs[@]}"; do
      if grep -q "\"${dep}\"" "${project_dir}/package.json" 2>/dev/null; then
        _qa_log WARN "Deprecated package: ${dep}"
        issues=$((issues + 1))
      fi
    done

    # Lock file check
    if [[ ! -f "${project_dir}/package-lock.json" && ! -f "${project_dir}/yarn.lock" && ! -f "${project_dir}/pnpm-lock.yaml" ]]; then
      _qa_log WARN "No lock file found (package-lock.json / yarn.lock / pnpm-lock.yaml)"
      issues=$((issues + 1))
    else
      _qa_log PASS "Lock file present"
    fi
  fi

  # --- Python ---
  if [[ -f "${project_dir}/requirements.txt" || -f "${project_dir}/pyproject.toml" ]]; then
    _qa_log INFO "Checking Python dependencies ..."

    if command -v pip &>/dev/null || command -v pip3 &>/dev/null; then
      local pip_cmd="pip3"
      command -v pip3 &>/dev/null || pip_cmd="pip"

      # Check for known vulnerable packages
      if command -v safety &>/dev/null; then
        local safety_result
        safety_result=$(cd "$project_dir" && safety check 2>/dev/null || echo "")
        if echo "$safety_result" | grep -qi "vulnerability"; then
          _qa_log FAIL "Python safety: Vulnerabilities found"
          issues=$((issues + 1))
        else
          _qa_log PASS "Python safety: No known vulnerabilities"
        fi
      elif [[ -f "${project_dir}/requirements.txt" ]]; then
        # Basic version check for pinned requirements
        local unpinned
        unpinned=$(grep -cvE '(==|>=|<=|~=|!=|#|^$)' "${project_dir}/requirements.txt" 2>/dev/null || echo "0")
        if [[ "$unpinned" -gt 0 ]]; then
          _qa_log WARN "Python: ${unpinned} unpinned dependencies in requirements.txt"
        else
          _qa_log PASS "Python: All dependencies pinned"
        fi
      fi
    fi
  fi

  # --- Go ---
  if [[ -f "${project_dir}/go.mod" ]]; then
    _qa_log INFO "Checking Go dependencies ..."
    if command -v go &>/dev/null; then
      local go_vuln
      go_vuln=$(cd "$project_dir" && go list -m -u all 2>/dev/null | grep -c '\[' || echo "0")
      if [[ "$go_vuln" -gt 0 ]]; then
        _qa_log INFO "Go: ${go_vuln} package(s) have updates available"
      fi
      # Check if govulncheck is available
      if command -v govulncheck &>/dev/null; then
        local vuln_result
        vuln_result=$(cd "$project_dir" && govulncheck ./... 2>/dev/null || echo "")
        if echo "$vuln_result" | grep -qi "vulnerability"; then
          _qa_log FAIL "Go: Vulnerabilities found by govulncheck"
          issues=$((issues + 1))
        else
          _qa_log PASS "Go: No vulnerabilities found"
        fi
      fi
    fi
  fi

  # --- Rust ---
  if [[ -f "${project_dir}/Cargo.toml" ]]; then
    _qa_log INFO "Checking Rust dependencies ..."
    if command -v cargo &>/dev/null; then
      if command -v cargo-audit &>/dev/null; then
        local audit_result
        audit_result=$(cd "$project_dir" && cargo audit 2>/dev/null || echo "")
        if echo "$audit_result" | grep -qi "vulnerability"; then
          _qa_log FAIL "Rust: Vulnerabilities found by cargo audit"
          issues=$((issues + 1))
        else
          _qa_log PASS "Rust: No vulnerabilities found"
        fi
      fi
    fi
  fi

  # General: License check
  local license_file=""
  [[ -f "${project_dir}/LICENSE" ]] && license_file="${project_dir}/LICENSE"
  [[ -f "${project_dir}/LICENSE.md" ]] && license_file="${project_dir}/LICENSE.md"
  if [[ -n "$license_file" ]]; then
    _qa_log PASS "License file present: $(basename "$license_file")"
  else
    _qa_log INFO "No LICENSE file found"
  fi

  _qa_log INFO "Dependency check: ${issues} issue(s)"
}

# --- qa_generate_report(project_dir) ----------------------------------------

qa_generate_report() {
  local project_dir="${1:-.}"
  local report_file="${project_dir}/docs/chain-logs/qa-report-$(date '+%Y%m%d-%H%M%S').txt"
  mkdir -p "$(dirname "$report_file")"

  {
    printf '=%.0s' {1..70}; echo
    printf "SoloptiLink Chain v11.0 - QA Report\n"
    printf "Generated: %s\nProject: %s\nType: %s\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$project_dir" "${QA_PROJECT_TYPE:-unknown}"
    printf '=%.0s' {1..70}; echo; echo
    printf "SUMMARY\n"; printf '%s\n' "----------------------------------------"
    printf "  PASS: %d  FAIL: %d  WARN: %d  TOTAL: %d\n" "$_QA_PASS" "$_QA_FAIL" "$_QA_WARN" "$((_QA_PASS+_QA_FAIL+_QA_WARN))"
    echo; printf "DETAILS\n"; printf '%s\n' "----------------------------------------"
    printf '%b' "$_QA_RESULTS"
    echo; printf '=%.0s' {1..70}; echo
  } > "$report_file"

  echo
  printf "${_QA_BOLD}+--------------------------------------+${_QA_NC}\n"
  printf "${_QA_BOLD}|     QA Report Summary (v11.0)        |${_QA_NC}\n"
  printf "${_QA_BOLD}+--------------------------------------+${_QA_NC}\n"
  printf "${_QA_BOLD}|${_QA_NC}  ${_QA_GREEN}PASS:${_QA_NC}     %-24d${_QA_BOLD}|${_QA_NC}\n" "$_QA_PASS"
  printf "${_QA_BOLD}|${_QA_NC}  ${_QA_RED}FAIL:${_QA_NC}     %-24d${_QA_BOLD}|${_QA_NC}\n" "$_QA_FAIL"
  printf "${_QA_BOLD}|${_QA_NC}  ${_QA_YELLOW}WARNINGS:${_QA_NC} %-24d${_QA_BOLD}|${_QA_NC}\n" "$_QA_WARN"
  printf "${_QA_BOLD}+--------------------------------------+${_QA_NC}\n"

  if (( _QA_FAIL > 0 )); then
    printf "\n${_QA_RED}${_QA_BOLD}QA FAILED${_QA_NC} - %d issue(s) require attention\n" "$_QA_FAIL"
  elif (( _QA_WARN > 0 )); then
    printf "\n${_QA_YELLOW}${_QA_BOLD}QA PASSED WITH WARNINGS${_QA_NC} - %d warning(s)\n" "$_QA_WARN"
  else
    printf "\n${_QA_GREEN}${_QA_BOLD}QA PASSED${_QA_NC} - all checks green\n"
  fi
  _qa_log INFO "Report saved: ${report_file}"
}

# --- qa_run_exhaustive(project_dir) -----------------------------------------

qa_run_exhaustive() {
  local project_dir="$1"
  qa_init "$project_dir" || return 1

  printf "\n${_QA_BOLD}${_QA_CYAN}"
  printf '=%.0s' {1..60}; echo
  printf "  SoloptiLink Chain v11.0 - Exhaustive QA Engine\n"
  printf '=%.0s' {1..60}
  printf "${_QA_NC}\n\n"
  _qa_log INFO "Starting exhaustive QA run ..."

  printf "\n${_QA_BOLD}--- Phase 1: Interactive Elements ---${_QA_NC}\n"
  qa_test_all_buttons "$project_dir"
  qa_test_all_forms   "$project_dir"

  printf "\n${_QA_BOLD}--- Phase 2: Routing ---${_QA_NC}\n"
  qa_test_all_routes "$project_dir"

  printf "\n${_QA_BOLD}--- Phase 3: API & Database ---${_QA_NC}\n"
  qa_test_api_endpoints "$project_dir"
  qa_test_database      "$project_dir"

  printf "\n${_QA_BOLD}--- Phase 4: Security ---${_QA_NC}\n"
  qa_security_scan "$project_dir"

  printf "\n${_QA_BOLD}--- Phase 5: Missing Test Coverage ---${_QA_NC}\n"
  qa_suggest_missing_tests "$project_dir"

  printf "\n${_QA_BOLD}--- Phase 6: Test Auto-Generation (v11.0) ---${_QA_NC}\n"
  qa_generate_tests "$project_dir"

  printf "\n${_QA_BOLD}--- Phase 7: Coverage Estimation (v11.0) ---${_QA_NC}\n"
  qa_estimate_coverage "$project_dir"

  printf "\n${_QA_BOLD}--- Phase 8: Performance Testing (v11.0) ---${_QA_NC}\n"
  qa_performance_check "$project_dir"

  printf "\n${_QA_BOLD}--- Phase 9: Dependency Check (v11.0) ---${_QA_NC}\n"
  qa_check_dependencies "$project_dir"

  printf "\n${_QA_BOLD}--- Final Report ---${_QA_NC}\n"
  qa_generate_report "$project_dir"

  (( _QA_FAIL == 0 ))
}
