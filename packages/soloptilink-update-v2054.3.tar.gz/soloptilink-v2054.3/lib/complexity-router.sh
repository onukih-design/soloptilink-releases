#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v64.0 - Adaptive Complexity Router
#
# タスクの複雑度を分析し、最適なモデルとリソース配分を決定する。
#
# 従来: 全タスクに同じモデル（Sonnet）+ 同じ予算
# v64.0: タスク分析 → 複雑度スコア → モデル/予算/ツール自動選択
#
# 複雑度レベル:
#   L1 (trivial):  設定ファイル修正、typo修正 → Haiku, $0.10
#   L2 (simple):   単一ファイル実装、簡単な機能 → Sonnet, $0.50
#   L3 (moderate): 複数ファイル、API+DB連携 → Sonnet, $2.00
#   L4 (complex):  アーキテクチャ設計、大規模実装 → Opus, $5.00
#   L5 (critical): セキュリティ監査、本番デプロイ → Opus, $8.00
#
# モデルの正式ID:
#   Opus:   claude-opus-4-20250514
#   Sonnet: claude-sonnet-4-20250514
#   Haiku:  claude-haiku-4-5-20251001
# ============================================================

[[ -n "${_COMPLEXITY_ROUTER_LOADED:-}" ]] && return 0
_COMPLEXITY_ROUTER_LOADED=1

# --- Configuration ---
CR_ENABLE="${CR_ENABLE:-true}"
CR_BUDGET_TOTAL="${CR_BUDGET_TOTAL:-10.00}"   # セッション総予算
CR_BUDGET_REMAINING="${CR_BUDGET_REMAINING:-10.00}"

# --- Models ---
CR_MODEL_OPUS="claude-opus-4-20250514"
CR_MODEL_SONNET="claude-sonnet-4-20250514"
CR_MODEL_HAIKU="claude-haiku-4-5-20251001"

# --- State ---
CR_ROUTE_COUNT=0
CR_L1_COUNT=0
CR_L2_COUNT=0
CR_L3_COUNT=0
CR_L4_COUNT=0
CR_L5_COUNT=0
CR_BUDGET_SAVED=0

# ============================================================
# 初期化
# ============================================================
cr_init() {
    CR_ROUTE_COUNT=0
    CR_L1_COUNT=0
    CR_L2_COUNT=0
    CR_L3_COUNT=0
    CR_L4_COUNT=0
    CR_L5_COUNT=0
    CR_BUDGET_SAVED=0
    CR_BUDGET_REMAINING="${CR_BUDGET_TOTAL}"
    return 0
}

# ============================================================
# タスク複雑度分析
# テキスト分析でL1-L5を判定
# ============================================================
cr_analyze_complexity() {
    local task_desc="$1"
    local phase="${2:-implementation}"
    local file_count="${3:-1}"

    local score=0

    # --- Phase-based scoring ---
    case "$phase" in
        scaffold|config)     score=$((score + 10)) ;;
        backend|api)         score=$((score + 30)) ;;
        frontend|ui)         score=$((score + 25)) ;;
        implementation)      score=$((score + 35)) ;;
        security|audit)      score=$((score + 45)) ;;
        design|architecture) score=$((score + 40)) ;;
        test|verify)         score=$((score + 20)) ;;
        fix|heal)            score=$((score + 25)) ;;
        deploy)              score=$((score + 40)) ;;
    esac

    # --- Keyword-based scoring ---
    local desc_lower
    desc_lower=$(echo "$task_desc" | tr '[:upper:]' '[:lower:]')

    # 高複雑度キーワード
    [[ "$desc_lower" == *"authentication"* || "$desc_lower" == *"認証"* ]] && score=$((score + 15))
    [[ "$desc_lower" == *"payment"* || "$desc_lower" == *"決済"* ]] && score=$((score + 20))
    [[ "$desc_lower" == *"security"* || "$desc_lower" == *"セキュリティ"* ]] && score=$((score + 15))
    [[ "$desc_lower" == *"migration"* || "$desc_lower" == *"マイグレーション"* ]] && score=$((score + 15))
    [[ "$desc_lower" == *"saas"* || "$desc_lower" == *"multi-tenant"* ]] && score=$((score + 20))
    [[ "$desc_lower" == *"real-time"* || "$desc_lower" == *"websocket"* ]] && score=$((score + 15))
    [[ "$desc_lower" == *"deploy"* || "$desc_lower" == *"デプロイ"* ]] && score=$((score + 10))

    # 低複雑度キーワード
    [[ "$desc_lower" == *"typo"* || "$desc_lower" == *"fix"* ]] && score=$((score - 10))
    [[ "$desc_lower" == *"config"* || "$desc_lower" == *"設定"* ]] && score=$((score - 5))
    [[ "$desc_lower" == *"comment"* || "$desc_lower" == *"コメント"* ]] && score=$((score - 15))

    # --- File count scoring ---
    if [[ $file_count -gt 20 ]]; then
        score=$((score + 20))
    elif [[ $file_count -gt 10 ]]; then
        score=$((score + 10))
    elif [[ $file_count -gt 5 ]]; then
        score=$((score + 5))
    fi

    # Clamp
    [[ $score -lt 0 ]] && score=0
    [[ $score -gt 100 ]] && score=100

    # Level determination
    local level
    if [[ $score -le 15 ]]; then
        level=1
    elif [[ $score -le 30 ]]; then
        level=2
    elif [[ $score -le 50 ]]; then
        level=3
    elif [[ $score -le 75 ]]; then
        level=4
    else
        level=5
    fi

    echo "$level:$score"
}

# ============================================================
# ルーティング決定
# 複雑度レベルからモデル・予算・ツール構成を決定
# ============================================================
cr_route() {
    local task_desc="$1"
    local phase="${2:-implementation}"
    local file_count="${3:-1}"

    CR_ROUTE_COUNT=$((CR_ROUTE_COUNT + 1))

    local analysis
    analysis=$(cr_analyze_complexity "$task_desc" "$phase" "$file_count")

    local level="${analysis%%:*}"
    local score="${analysis##*:}"

    local model="" budget="" tools="" fallback=""

    case "$level" in
        1)
            model="$CR_MODEL_HAIKU"
            fallback="$CR_MODEL_SONNET"
            budget="0.10"
            tools="Read,Write,Bash"
            CR_L1_COUNT=$((CR_L1_COUNT + 1))
            ;;
        2)
            model="$CR_MODEL_SONNET"
            fallback="$CR_MODEL_HAIKU"
            budget="0.50"
            tools="Read,Write,Edit,Bash,Glob"
            CR_L2_COUNT=$((CR_L2_COUNT + 1))
            ;;
        3)
            model="$CR_MODEL_SONNET"
            fallback="$CR_MODEL_HAIKU"
            budget="2.00"
            tools="Read,Write,Edit,Bash,Glob,Grep"
            CR_L3_COUNT=$((CR_L3_COUNT + 1))
            ;;
        4)
            model="$CR_MODEL_OPUS"
            fallback="$CR_MODEL_SONNET"
            budget="5.00"
            tools="Read,Write,Edit,Bash,Glob,Grep"
            CR_L4_COUNT=$((CR_L4_COUNT + 1))
            ;;
        5)
            model="$CR_MODEL_OPUS"
            fallback="$CR_MODEL_SONNET"
            budget="8.00"
            tools="Read,Write,Edit,Bash,Glob,Grep"
            CR_L5_COUNT=$((CR_L5_COUNT + 1))
            ;;
    esac

    # 残り予算チェック
    local budget_ok
    budget_ok=$(python3 -c "print('yes' if ${CR_BUDGET_REMAINING} >= ${budget} else 'no')" 2>/dev/null || echo "yes")

    if [[ "$budget_ok" != "yes" ]]; then
        # 予算不足: ダウングレード
        model="$CR_MODEL_HAIKU"
        budget=$(python3 -c "print(min(${CR_BUDGET_REMAINING}, 0.50))" 2>/dev/null || echo "0.50")
        echo -e "  ${YELLOW:-}💰 予算不足: L${level}→Haiku にダウングレード (残 \$${CR_BUDGET_REMAINING})${NC:-}" >&2
    fi

    # 予算消費
    CR_BUDGET_REMAINING=$(python3 -c "print(round(${CR_BUDGET_REMAINING} - ${budget}, 2))" 2>/dev/null || echo "$CR_BUDGET_REMAINING")

    # デフォルト予算との差額を節約額に加算
    local default_budget="3.00"
    local saved
    saved=$(python3 -c "print(max(0, round(${default_budget} - ${budget}, 2)))" 2>/dev/null || echo "0")
    CR_BUDGET_SAVED=$(python3 -c "print(round(${CR_BUDGET_SAVED} + ${saved}, 2))" 2>/dev/null || echo "$CR_BUDGET_SAVED")

    # 結果をkey=value形式で出力
    echo "level=${level} score=${score} model=${model} fallback=${fallback} budget=${budget} tools=${tools}"
}

# ============================================================
# ルーティング結果からClaude CLIコマンドを構築
# ============================================================
cr_build_claude_cmd() {
    local route_result="$1"
    local prompt="$2"

    # パース
    local model fallback budget tools
    eval "$(echo "$route_result" | tr ' ' '\n' | grep -E '^(model|fallback|budget|tools)=' | sed 's/^/local /')"

    local -a cmd_args=()
    cmd_args+=("claude" "-p" "--dangerously-skip-permissions")
    cmd_args+=("--model" "$model")
    cmd_args+=("--fallback-model" "$fallback")
    cmd_args+=("--max-budget-usd" "$budget")

    if [[ -n "$tools" ]]; then
        cmd_args+=("--allowedTools" "$tools")
    fi

    cmd_args+=("--output-format" "text")
    cmd_args+=("$prompt")

    echo "${cmd_args[@]}"
}

# ============================================================
# Complexity-Aware 実行（analyze → route → execute を一括）
# ============================================================
cr_smart_execute() {
    local prompt="$1"
    local output_file="${2:-}"
    local phase="${3:-implementation}"
    local file_count="${4:-1}"

    # ルーティング
    local route_result
    route_result=$(cr_route "$prompt" "$phase" "$file_count")

    local level
    level=$(echo "$route_result" | grep -o 'level=[0-9]*' | cut -d= -f2)
    local model_short
    model_short=$(echo "$route_result" | grep -o 'model=[^ ]*' | cut -d= -f2 | sed 's/claude-//' | cut -d- -f1)
    local budget
    budget=$(echo "$route_result" | grep -o 'budget=[^ ]*' | cut -d= -f2)

    echo -e "  ${CYAN:-}🧠 Complexity L${level} → ${model_short} (\$${budget})${NC:-}" >&2

    # コマンド構築・実行
    local cmd_str
    cmd_str=$(cr_build_claude_cmd "$route_result" "$prompt")

    local result
    result=$(timeout 300 bash -c "$cmd_str" 2>/dev/null) || true

    if [[ -n "$output_file" ]]; then
        echo "$result" > "$output_file"
    fi

    echo "$result"
    return 0
}

# ============================================================
# レポート / スコア
# ============================================================
cr_report() {
    echo -e "\n  ${BOLD:-}═══ Complexity Router v64.0 レポート ═══${NC:-}"
    echo -e "  ルーティング回数   : ${CR_ROUTE_COUNT}"
    echo -e "  L1 (Haiku)         : ${CR_L1_COUNT}"
    echo -e "  L2-L3 (Sonnet)     : $((CR_L2_COUNT + CR_L3_COUNT))"
    echo -e "  L4-L5 (Opus)       : $((CR_L4_COUNT + CR_L5_COUNT))"
    echo -e "  コスト節約額       : \$${CR_BUDGET_SAVED}"
    echo -e "  残り予算           : \$${CR_BUDGET_REMAINING}"
}

cr_score() {
    if [[ $CR_ROUTE_COUNT -eq 0 ]]; then
        echo "50"
    else
        # コスト効率が高いほど高スコア
        local efficiency
        efficiency=$(python3 -c "
saved = ${CR_BUDGET_SAVED}
total = ${CR_ROUTE_COUNT} * 3.0
if total > 0:
    print(min(100, int(50 + saved / total * 100)))
else:
    print(70)
" 2>/dev/null || echo "70")
        echo "$efficiency"
    fi
}

# ============================================================
# v59.0: Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "complexity-router" \
        --version "64.0" \
        --description "タスク複雑度→Opus/Sonnet/Haiku自動選択×予算最適化" \
        --init "cr_init" \
        --report "cr_report" \
        --score "cr_score" \
        --enable-var "ENABLE_COMPLEXITY_ROUTER" \
        --cli-flags "--complexity-router:--no-complexity-router"
fi

# v2003.1: source時のexit codeを確実に0にする
true
