#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v105.0 - Prompt Effectiveness Analyzer
# =============================================================================
# どのプロンプトテンプレートが最高品質の出力を生むかを計測。
# prompt_hash → quality_score × runtime_pass_rate を記録し、
# ドメイン×フェーズ別に最適テンプレートを推薦するエンジン。
#
# Functions:
#   pea_init              - 履歴ロード・ディレクトリ準備
#   pea_track_prompt      - プロンプト使用を記録
#   pea_record_outcome    - 結果をリンク
#   pea_rank_templates    - テンプレートをランキング
#   pea_recommend_template- 最適テンプレートを推薦
#   pea_get_anti_patterns - 低スコアパターンを取得
#   pea_report            - レポート出力
#   pea_score             - モジュールスコア(0-100)
#
# All globals use the PEA_ prefix.
# =============================================================================

[[ -n "${_PROMPT_EFFECTIVENESS_LOADED:-}" ]] && return 0
_PROMPT_EFFECTIVENESS_LOADED=1

PEA_VERSION="105.0"
PEA_INITIALIZED=false

# Storage
PEA_LEARN_DIR=""
PEA_DATA_FILE=""

# Counters
PEA_TOTAL_TRACKED=0
PEA_TOTAL_OUTCOMES=0
PEA_TOTAL_TEMPLATES=0

# In-memory storage
# Key: prompt_hash
declare -g -A _PEA_TEMPLATE_NAME=()     # hash → template_name
declare -g -A _PEA_DOMAIN=()            # hash → domain
declare -g -A _PEA_PHASE=()             # hash → phase
declare -g -A _PEA_USE_COUNT=()         # hash → usage count
declare -g -A _PEA_QUALITY_SUM=()       # hash → sum of quality scores
declare -g -A _PEA_QUALITY_COUNT=()     # hash → number of quality measurements
declare -g -A _PEA_PASS_RATE_SUM=()     # hash → sum of pass rates
declare -g -A _PEA_PASS_RATE_COUNT=()   # hash → number of pass rate measurements

# Template-level aggregates (by template_name::domain)
declare -g -A _PEA_TPL_QUALITY=()       # name::domain → total quality
declare -g -A _PEA_TPL_COUNT=()         # name::domain → count
declare -g -A _PEA_TPL_PASS=()          # name::domain → total pass rate

# =============================================================================
# pea_init - Load history, prepare directories
# =============================================================================
pea_init() {
    PEA_LEARN_DIR="${HOME}/.soloptilink/learning/prompts"
    mkdir -p "$PEA_LEARN_DIR" 2>/dev/null || true

    PEA_DATA_FILE="${PEA_LEARN_DIR}/effectiveness.jsonl"

    # Reset
    PEA_TOTAL_TRACKED=0
    PEA_TOTAL_OUTCOMES=0
    PEA_TOTAL_TEMPLATES=0
    _PEA_TEMPLATE_NAME=()
    _PEA_DOMAIN=()
    _PEA_PHASE=()
    _PEA_USE_COUNT=()
    _PEA_QUALITY_SUM=()
    _PEA_QUALITY_COUNT=()
    _PEA_PASS_RATE_SUM=()
    _PEA_PASS_RATE_COUNT=()
    _PEA_TPL_QUALITY=()
    _PEA_TPL_COUNT=()
    _PEA_TPL_PASS=()

    # Load existing data
    if [[ -f "$PEA_DATA_FILE" ]]; then
        _pea_load_history
    fi

    PEA_INITIALIZED=true
    return 0
}

# =============================================================================
# _pea_json_val - Extract value from JSON (no jq)
# =============================================================================
_pea_json_val() {
    local json="$1" key="$2"
    echo "$json" | grep -o "\"${key}\":[^,}]*" | head -1 | sed "s/\"${key}\"://;s/^\"//;s/\"$//;s/^[[:space:]]*//;s/[[:space:]]*$//"
}

# =============================================================================
# _pea_escape_json - Escape string for JSON
# =============================================================================
_pea_escape_json() {
    local s="$1"
    s="${s//\\/\\\\}"
    s="${s//\"/\\\"}"
    s="${s//$'\n'/\\n}"
    echo "$s"
}

# =============================================================================
# _pea_load_history - Load persisted data from JSONL
# =============================================================================
_pea_load_history() {
    [[ ! -f "$PEA_DATA_FILE" ]] && return 0

    local line
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue

        local record_type phash tname domain phase quality pass_rate
        record_type=$(_pea_json_val "$line" "type")
        phash=$(_pea_json_val "$line" "prompt_hash")

        [[ -z "$phash" ]] && continue

        case "$record_type" in
            track)
                tname=$(_pea_json_val "$line" "template_name")
                domain=$(_pea_json_val "$line" "domain")
                phase=$(_pea_json_val "$line" "phase")

                _PEA_TEMPLATE_NAME["$phash"]="${tname:-unknown}"
                _PEA_DOMAIN["$phash"]="${domain:-general}"
                _PEA_PHASE["$phash"]="${phase:-unknown}"
                local prev_use="${_PEA_USE_COUNT[$phash]:-0}"
                _PEA_USE_COUNT["$phash"]=$((prev_use + 1))

                if [[ $prev_use -eq 0 ]]; then
                    PEA_TOTAL_TEMPLATES=$((PEA_TOTAL_TEMPLATES + 1))
                fi
                PEA_TOTAL_TRACKED=$((PEA_TOTAL_TRACKED + 1))
                ;;
            outcome)
                quality=$(_pea_json_val "$line" "quality_score")
                pass_rate=$(_pea_json_val "$line" "runtime_pass_rate")

                [[ -z "$quality" || ! "$quality" =~ ^[0-9]+$ ]] && quality=0
                [[ -z "$pass_rate" || ! "$pass_rate" =~ ^[0-9]+$ ]] && pass_rate=0

                local prev_qsum="${_PEA_QUALITY_SUM[$phash]:-0}"
                local prev_qcount="${_PEA_QUALITY_COUNT[$phash]:-0}"
                _PEA_QUALITY_SUM["$phash"]=$((prev_qsum + quality))
                _PEA_QUALITY_COUNT["$phash"]=$((prev_qcount + 1))

                local prev_psum="${_PEA_PASS_RATE_SUM[$phash]:-0}"
                local prev_pcount="${_PEA_PASS_RATE_COUNT[$phash]:-0}"
                _PEA_PASS_RATE_SUM["$phash"]=$((prev_psum + pass_rate))
                _PEA_PASS_RATE_COUNT["$phash"]=$((prev_pcount + 1))

                # Update template-level aggregates
                local tname_for_agg="${_PEA_TEMPLATE_NAME[$phash]:-unknown}"
                local domain_for_agg="${_PEA_DOMAIN[$phash]:-general}"
                local tpl_key="${tname_for_agg}::${domain_for_agg}"

                local prev_tq="${_PEA_TPL_QUALITY[$tpl_key]:-0}"
                local prev_tc="${_PEA_TPL_COUNT[$tpl_key]:-0}"
                local prev_tp="${_PEA_TPL_PASS[$tpl_key]:-0}"
                _PEA_TPL_QUALITY["$tpl_key"]=$((prev_tq + quality))
                _PEA_TPL_COUNT["$tpl_key"]=$((prev_tc + 1))
                _PEA_TPL_PASS["$tpl_key"]=$((prev_tp + pass_rate))

                PEA_TOTAL_OUTCOMES=$((PEA_TOTAL_OUTCOMES + 1))
                ;;
        esac
    done < "$PEA_DATA_FILE"

    return 0
}

# =============================================================================
# pea_track_prompt - Record prompt usage
# =============================================================================
# Args: prompt_hash, domain, phase, template_name
pea_track_prompt() {
    local prompt_hash="${1:-}"
    local domain="${2:-general}"
    local phase="${3:-unknown}"
    local template_name="${4:-default}"

    [[ "$PEA_INITIALIZED" != "true" ]] && return 1
    [[ -z "$prompt_hash" ]] && return 1

    local timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date +"%Y-%m-%d")

    # Update in-memory
    if [[ -z "${_PEA_USE_COUNT[$prompt_hash]:-}" ]]; then
        PEA_TOTAL_TEMPLATES=$((PEA_TOTAL_TEMPLATES + 1))
        _PEA_USE_COUNT["$prompt_hash"]=0
    fi

    _PEA_TEMPLATE_NAME["$prompt_hash"]="$template_name"
    _PEA_DOMAIN["$prompt_hash"]="$domain"
    _PEA_PHASE["$prompt_hash"]="$phase"
    _PEA_USE_COUNT["$prompt_hash"]=$(( ${_PEA_USE_COUNT[$prompt_hash]} + 1 ))

    PEA_TOTAL_TRACKED=$((PEA_TOTAL_TRACKED + 1))

    # Persist
    local escaped_name
    escaped_name=$(_pea_escape_json "$template_name")
    echo "{\"type\":\"track\",\"timestamp\":\"${timestamp}\",\"prompt_hash\":\"${prompt_hash}\",\"domain\":\"${domain}\",\"phase\":\"${phase}\",\"template_name\":\"${escaped_name}\"}" >> "$PEA_DATA_FILE" 2>/dev/null

    return 0
}

# =============================================================================
# pea_record_outcome - Link a prompt to its quality outcome
# =============================================================================
# Args: prompt_hash, quality_score (0-100), runtime_pass_rate (0-100)
pea_record_outcome() {
    local prompt_hash="${1:-}"
    local quality_score="${2:-0}"
    local runtime_pass_rate="${3:-0}"

    [[ "$PEA_INITIALIZED" != "true" ]] && return 1
    [[ -z "$prompt_hash" ]] && return 1
    [[ ! "$quality_score" =~ ^[0-9]+$ ]] && quality_score=0
    [[ ! "$runtime_pass_rate" =~ ^[0-9]+$ ]] && runtime_pass_rate=0
    [[ $quality_score -gt 100 ]] && quality_score=100
    [[ $runtime_pass_rate -gt 100 ]] && runtime_pass_rate=100

    local timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date +"%Y-%m-%d")

    # Update per-hash stats
    local prev_qsum="${_PEA_QUALITY_SUM[$prompt_hash]:-0}"
    local prev_qcount="${_PEA_QUALITY_COUNT[$prompt_hash]:-0}"
    _PEA_QUALITY_SUM["$prompt_hash"]=$((prev_qsum + quality_score))
    _PEA_QUALITY_COUNT["$prompt_hash"]=$((prev_qcount + 1))

    local prev_psum="${_PEA_PASS_RATE_SUM[$prompt_hash]:-0}"
    local prev_pcount="${_PEA_PASS_RATE_COUNT[$prompt_hash]:-0}"
    _PEA_PASS_RATE_SUM["$prompt_hash"]=$((prev_psum + runtime_pass_rate))
    _PEA_PASS_RATE_COUNT["$prompt_hash"]=$((prev_pcount + 1))

    # Update template-level aggregates
    local tname="${_PEA_TEMPLATE_NAME[$prompt_hash]:-unknown}"
    local domain="${_PEA_DOMAIN[$prompt_hash]:-general}"
    local tpl_key="${tname}::${domain}"

    local prev_tq="${_PEA_TPL_QUALITY[$tpl_key]:-0}"
    local prev_tc="${_PEA_TPL_COUNT[$tpl_key]:-0}"
    local prev_tp="${_PEA_TPL_PASS[$tpl_key]:-0}"
    _PEA_TPL_QUALITY["$tpl_key"]=$((prev_tq + quality_score))
    _PEA_TPL_COUNT["$tpl_key"]=$((prev_tc + 1))
    _PEA_TPL_PASS["$tpl_key"]=$((prev_tp + runtime_pass_rate))

    PEA_TOTAL_OUTCOMES=$((PEA_TOTAL_OUTCOMES + 1))

    # Persist
    echo "{\"type\":\"outcome\",\"timestamp\":\"${timestamp}\",\"prompt_hash\":\"${prompt_hash}\",\"quality_score\":${quality_score},\"runtime_pass_rate\":${runtime_pass_rate}}" >> "$PEA_DATA_FILE" 2>/dev/null

    return 0
}

# =============================================================================
# pea_rank_templates - Rank templates by avg quality for a domain
# =============================================================================
# Args: domain
# Output: lines of "avg_quality|template_name|count|avg_pass_rate"
pea_rank_templates() {
    local domain="${1:-general}"

    local entries=""
    local tpl_key
    for tpl_key in "${!_PEA_TPL_COUNT[@]}"; do
        local tpl_domain="${tpl_key##*::}"
        [[ "$tpl_domain" != "$domain" && "$domain" != "all" ]] && continue

        local tpl_name="${tpl_key%%::*}"
        local total_q="${_PEA_TPL_QUALITY[$tpl_key]:-0}"
        local count="${_PEA_TPL_COUNT[$tpl_key]:-0}"
        local total_p="${_PEA_TPL_PASS[$tpl_key]:-0}"

        [[ $count -eq 0 ]] && continue

        local avg_q=$((total_q / count))
        local avg_p=$((total_p / count))

        entries="${entries}${avg_q}|${tpl_name}|${count}|${avg_p}"$'\n'
    done

    # Sort by avg quality descending
    echo "$entries" | sort -t'|' -k1 -rn | while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        echo "$line"
    done

    return 0
}

# =============================================================================
# pea_recommend_template - Return best template name for domain+phase
# =============================================================================
# Args: domain, phase
# Output: template name or "default"
pea_recommend_template() {
    local domain="${1:-general}"
    local phase="${2:-}"

    local best_name="default"
    local best_score=0

    local phash
    for phash in "${!_PEA_TEMPLATE_NAME[@]}"; do
        local h_domain="${_PEA_DOMAIN[$phash]:-}"
        local h_phase="${_PEA_PHASE[$phash]:-}"

        # Match domain
        [[ "$h_domain" != "$domain" ]] && continue
        # Match phase if specified
        [[ -n "$phase" && "$h_phase" != "$phase" ]] && continue

        local qcount="${_PEA_QUALITY_COUNT[$phash]:-0}"
        [[ $qcount -eq 0 ]] && continue

        local qsum="${_PEA_QUALITY_SUM[$phash]:-0}"
        local avg=$((qsum / qcount))

        if [[ $avg -gt $best_score ]]; then
            best_score=$avg
            best_name="${_PEA_TEMPLATE_NAME[$phash]:-default}"
        fi
    done

    echo "$best_name"
    return 0
}

# =============================================================================
# pea_get_anti_patterns - Return low-scoring prompt patterns
# =============================================================================
# Output: lines of "avg_quality|template_name|domain|count"
pea_get_anti_patterns() {
    local threshold=40  # Below this is considered anti-pattern

    local tpl_key
    for tpl_key in "${!_PEA_TPL_COUNT[@]}"; do
        local count="${_PEA_TPL_COUNT[$tpl_key]:-0}"
        [[ $count -lt 2 ]] && continue  # Need at least 2 uses

        local total_q="${_PEA_TPL_QUALITY[$tpl_key]:-0}"
        local avg_q=$((total_q / count))

        if [[ $avg_q -lt $threshold ]]; then
            local tpl_name="${tpl_key%%::*}"
            local tpl_domain="${tpl_key##*::}"
            echo "${avg_q}|${tpl_name}|${tpl_domain}|${count}"
        fi
    done | sort -t'|' -k1 -n

    return 0
}

# =============================================================================
# pea_report - Summary report
# =============================================================================
pea_report() {
    echo -e "\n  ${BOLD:-}--- Prompt Effectiveness v${PEA_VERSION} ---${NC:-}"
    echo -e "  Prompts tracked    : ${PEA_TOTAL_TRACKED}"
    echo -e "  Outcomes recorded  : ${PEA_TOTAL_OUTCOMES}"
    echo -e "  Unique templates   : ${PEA_TOTAL_TEMPLATES}"

    # Show top template per domain
    local seen_domains=""
    local tpl_key
    for tpl_key in "${!_PEA_TPL_COUNT[@]}"; do
        local tpl_domain="${tpl_key##*::}"
        [[ "$seen_domains" == *"|${tpl_domain}|"* ]] && continue
        seen_domains="${seen_domains}|${tpl_domain}|"

        local best
        best=$(pea_rank_templates "$tpl_domain" | head -1)
        if [[ -n "$best" ]]; then
            local bscore="${best%%|*}"
            local rest="${best#*|}"
            local bname="${rest%%|*}"
            echo -e "  [${tpl_domain}] best=${bname} (avg_quality=${bscore})"
        fi
    done

    # Show anti-patterns count
    local anti_count=0
    local anti_line
    while IFS= read -r anti_line; do
        [[ -n "$anti_line" ]] && anti_count=$((anti_count + 1))
    done < <(pea_get_anti_patterns)
    [[ $anti_count -gt 0 ]] && echo -e "  Anti-patterns      : ${anti_count}"
}

# =============================================================================
# pea_score - Module health score (0-100)
# =============================================================================
pea_score() {
    local score=50

    # +15 if prompts are being tracked
    [[ $PEA_TOTAL_TRACKED -gt 0 ]] && score=$((score + 15))

    # +15 if outcomes are recorded
    [[ $PEA_TOTAL_OUTCOMES -gt 0 ]] && score=$((score + 15))

    # +10 if multiple templates tracked
    [[ $PEA_TOTAL_TEMPLATES -ge 3 ]] && score=$((score + 10))

    # +10 if best template avg > 70
    local any_good=false
    local tpl_key
    for tpl_key in "${!_PEA_TPL_COUNT[@]}"; do
        local count="${_PEA_TPL_COUNT[$tpl_key]:-0}"
        [[ $count -eq 0 ]] && continue
        local total_q="${_PEA_TPL_QUALITY[$tpl_key]:-0}"
        local avg=$((total_q / count))
        [[ $avg -ge 70 ]] && any_good=true && break
    done
    [[ "$any_good" == "true" ]] && score=$((score + 10))

    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "prompt-effectiveness" \
    --version "105.0" \
    --description "プロンプトテンプレート効果測定・最適テンプレート推薦" \
    --init "pea_init" \
    --report "pea_report" \
    --score "pea_score" \
    --enable-var "ENABLE_PEA" \
    --cli-flags "--prompt-effectiveness:--no-prompt-effectiveness"
