#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v330.0 - Metrics & Alerting Engine
# =============================================================================
# Prometheusメトリクス、アラートルール、Grafanaダッシュボード自動生成。
#
# Functions:
#   _ma_init()                - Initialize
#   _ma_generate_metrics()    - Generate metrics collection code
#   _ma_generate_alerts()     - Generate alerting rules
#   _ma_generate_dashboard()  - Generate Grafana dashboard JSON
#   _ma_report() / _ma_score()
# =============================================================================

[[ -n "${_MA_LOADED:-}" ]] && return 0; _MA_LOADED=1

readonly _MA_RED='\033[0;31m'
readonly _MA_GREEN='\033[0;32m'
readonly _MA_YELLOW='\033[0;33m'
readonly _MA_CYAN='\033[0;36m'
readonly _MA_NC='\033[0m'

declare -g MA_VERSION="330.0"
MA_GENERATED=0
MA_ERRORS=0
MA_FILES_WRITTEN=0
MA_METRICS_OK=false
MA_ALERTS_OK=false
MA_DASHBOARD_OK=false

_ma_init() {
    MA_GENERATED=0; MA_ERRORS=0; MA_FILES_WRITTEN=0
    MA_METRICS_OK=false; MA_ALERTS_OK=false; MA_DASHBOARD_OK=false
    echo -e "  ${_MA_GREEN}OK${_MA_NC} Metrics & Alerting v${MA_VERSION}" >&2
    return 0
}

_ma_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { MA_FILES_WRITTEN=$((MA_FILES_WRITTEN + 1)); return 0; }
    MA_ERRORS=$((MA_ERRORS + 1)); return 1
}

_ma_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_MA_CYAN}[metrics]${_MA_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_MA_GREEN}[metrics]${_MA_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_MA_YELLOW}[metrics]${_MA_NC} $msg" >&2 ;;
        error) echo -e "  ${_MA_RED}[metrics]${_MA_NC} $msg" >&2 ;;
    esac
}

# =============================================================================
# Generate Metrics Collection
# =============================================================================
_ma_generate_metrics() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ma_log info "Generating metrics collection..."

    _ma_write_file "${project_dir}/src/lib/metrics.ts" "$(cat <<'TYPESCRIPT'
import { Registry, Counter, Histogram, Gauge, collectDefaultMetrics } from 'prom-client';

const register = new Registry();

// Collect default Node.js metrics
collectDefaultMetrics({ register, prefix: 'app_' });

// HTTP request metrics
export const httpRequestDuration = new Histogram({
  name: 'http_request_duration_seconds',
  help: 'Duration of HTTP requests in seconds',
  labelNames: ['method', 'route', 'status_code'] as const,
  buckets: [0.01, 0.05, 0.1, 0.25, 0.5, 1, 2.5, 5, 10],
  registers: [register],
});

export const httpRequestTotal = new Counter({
  name: 'http_requests_total',
  help: 'Total number of HTTP requests',
  labelNames: ['method', 'route', 'status_code'] as const,
  registers: [register],
});

// Business metrics
export const activeUsers = new Gauge({
  name: 'app_active_users',
  help: 'Number of currently active users',
  registers: [register],
});

export const dbQueryDuration = new Histogram({
  name: 'db_query_duration_seconds',
  help: 'Duration of database queries',
  labelNames: ['operation', 'table'] as const,
  buckets: [0.001, 0.005, 0.01, 0.05, 0.1, 0.5, 1],
  registers: [register],
});

export const cacheHitRate = new Counter({
  name: 'cache_hits_total',
  help: 'Cache hit/miss counter',
  labelNames: ['result'] as const,
  registers: [register],
});

export const errorTotal = new Counter({
  name: 'app_errors_total',
  help: 'Total application errors',
  labelNames: ['type', 'severity'] as const,
  registers: [register],
});

// Metrics endpoint handler
export async function metricsHandler(): Promise<{ contentType: string; metrics: string }> {
  return {
    contentType: register.contentType,
    metrics: await register.metrics(),
  };
}

// Middleware for request tracking
export function metricsMiddleware() {
  return (req: any, res: any, next: any) => {
    const end = httpRequestDuration.startTimer();
    res.on('finish', () => {
      const route = req.route?.path || req.url?.split('?')[0] || 'unknown';
      const labels = { method: req.method, route, status_code: String(res.statusCode) };
      end(labels);
      httpRequestTotal.inc(labels);
    });
    next();
  };
}
TYPESCRIPT
)"

    _ma_log ok "Metrics collection generated (Prometheus)"
    MA_METRICS_OK=true
    MA_GENERATED=$((MA_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate Alert Rules
# =============================================================================
_ma_generate_alerts() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local alerts_dir="${project_dir}/infra/monitoring"

    _ma_log info "Generating alert rules..."

    _ma_write_file "${alerts_dir}/alerts.yml" "groups:
  - name: app-alerts
    rules:
      - alert: HighErrorRate
        expr: rate(http_requests_total{status_code=~\"5..\"}[5m]) / rate(http_requests_total[5m]) > 0.05
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: 'High error rate detected'
          description: 'Error rate is {{ \$value | humanizePercentage }} over the last 5 minutes'

      - alert: HighLatency
        expr: histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m])) > 2
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: 'High request latency'
          description: 'p95 latency is {{ \$value }}s'

      - alert: HighMemoryUsage
        expr: process_resident_memory_bytes / 1024 / 1024 > 512
        for: 10m
        labels:
          severity: warning
        annotations:
          summary: 'High memory usage'
          description: 'Memory usage is {{ \$value }}MB'

      - alert: DatabaseSlowQueries
        expr: histogram_quantile(0.95, rate(db_query_duration_seconds_bucket[5m])) > 1
        for: 5m
        labels:
          severity: warning
        annotations:
          summary: 'Slow database queries detected'
          description: 'p95 query time is {{ \$value }}s'

      - alert: PodCrashLooping
        expr: rate(kube_pod_container_status_restarts_total[15m]) > 0
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: 'Pod {{ \$labels.pod }} is crash looping'

      - alert: DiskSpaceLow
        expr: node_filesystem_avail_bytes{mountpoint=\"/\"} / node_filesystem_size_bytes{mountpoint=\"/\"} < 0.1
        for: 5m
        labels:
          severity: critical
        annotations:
          summary: 'Disk space critically low'
          description: 'Only {{ \$value | humanizePercentage }} remaining'
"

    # Alertmanager config
    _ma_write_file "${alerts_dir}/alertmanager.yml" "global:
  resolve_timeout: 5m

route:
  group_by: ['alertname', 'severity']
  group_wait: 10s
  group_interval: 10s
  repeat_interval: 1h
  receiver: 'slack-notifications'
  routes:
    - match:
        severity: critical
      receiver: 'pager-duty'
    - match:
        severity: warning
      receiver: 'slack-notifications'

receivers:
  - name: 'slack-notifications'
    slack_configs:
      - api_url: '\${SLACK_WEBHOOK_URL}'
        channel: '#alerts'
        title: '{{ .GroupLabels.alertname }}'
        text: '{{ range .Alerts }}{{ .Annotations.description }}\n{{ end }}'

  - name: 'pager-duty'
    pagerduty_configs:
      - service_key: '\${PAGERDUTY_SERVICE_KEY}'
"

    _ma_log ok "Alert rules generated (Prometheus + Alertmanager)"
    MA_ALERTS_OK=true
    MA_GENERATED=$((MA_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate Grafana Dashboard
# =============================================================================
_ma_generate_dashboard() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local mon_dir="${project_dir}/infra/monitoring"

    _ma_log info "Generating Grafana dashboard..."

    _ma_write_file "${mon_dir}/grafana-dashboard.json" '{
  "dashboard": {
    "title": "Application Overview",
    "uid": "app-overview",
    "timezone": "browser",
    "refresh": "10s",
    "panels": [
      {
        "title": "Request Rate",
        "type": "graph",
        "gridPos": { "h": 8, "w": 12, "x": 0, "y": 0 },
        "targets": [{ "expr": "rate(http_requests_total[5m])", "legendFormat": "{{method}} {{route}}" }]
      },
      {
        "title": "Error Rate",
        "type": "graph",
        "gridPos": { "h": 8, "w": 12, "x": 12, "y": 0 },
        "targets": [{ "expr": "rate(http_requests_total{status_code=~\"5..\"}[5m])", "legendFormat": "{{status_code}}" }]
      },
      {
        "title": "Latency (p50/p95/p99)",
        "type": "graph",
        "gridPos": { "h": 8, "w": 12, "x": 0, "y": 8 },
        "targets": [
          { "expr": "histogram_quantile(0.5, rate(http_request_duration_seconds_bucket[5m]))", "legendFormat": "p50" },
          { "expr": "histogram_quantile(0.95, rate(http_request_duration_seconds_bucket[5m]))", "legendFormat": "p95" },
          { "expr": "histogram_quantile(0.99, rate(http_request_duration_seconds_bucket[5m]))", "legendFormat": "p99" }
        ]
      },
      {
        "title": "Active Users",
        "type": "stat",
        "gridPos": { "h": 4, "w": 6, "x": 12, "y": 8 },
        "targets": [{ "expr": "app_active_users" }]
      },
      {
        "title": "Memory Usage",
        "type": "gauge",
        "gridPos": { "h": 4, "w": 6, "x": 18, "y": 8 },
        "targets": [{ "expr": "process_resident_memory_bytes / 1024 / 1024" }]
      },
      {
        "title": "DB Query Latency",
        "type": "graph",
        "gridPos": { "h": 8, "w": 12, "x": 12, "y": 12 },
        "targets": [{ "expr": "histogram_quantile(0.95, rate(db_query_duration_seconds_bucket[5m]))", "legendFormat": "{{operation}} {{table}}" }]
      }
    ]
  }
}'

    _ma_log ok "Grafana dashboard generated"
    MA_DASHBOARD_OK=true
    MA_GENERATED=$((MA_GENERATED + 1))
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_ma_report() {
    echo -e "\n  ${_MA_CYAN}=== Metrics & Alerting v${MA_VERSION} ===${_MA_NC}"
    echo -e "  Generated: ${MA_GENERATED} | Files: ${MA_FILES_WRITTEN} | Errors: ${MA_ERRORS}"
    echo -e "  Metrics: $( ${MA_METRICS_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Alerts: $( ${MA_ALERTS_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Dashboard: $( ${MA_DASHBOARD_OK} && echo 'OK' || echo 'SKIP')"
}

_ma_score() {
    local score=50
    ${MA_METRICS_OK} && score=$((score + 15))
    ${MA_ALERTS_OK} && score=$((score + 15))
    ${MA_DASHBOARD_OK} && score=$((score + 15))
    [[ ${MA_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "metrics-alerting" --version "330.0" \
        --description "メトリクス&アラート Prometheus/Grafana/Alertmanager (v330)" \
        --init "_ma_init" --report "_ma_report" --score "_ma_score" \
        --enable-var "ENABLE_METRICS_ALERTING" --cli-flags "--metrics-alerting:--no-metrics-alerting"
fi

# v2003.1: source時のexit codeを確実に0にする
true
