#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v362.0 - Container Security Scanner
# =============================================================================
# コンテナイメージスキャン×脆弱性チェック×レポート生成
#
# 機能:
#   - Dockerfileベストプラクティス検証
#   - コンテナイメージ脆弱性スキャン（Trivy/Grype連携）
#   - ベースイメージ推奨（Alpine/Distroless）
#   - シークレット漏洩検出
#   - セキュリティレポート生成
#
# 全globals: CSS2_ prefix
# =============================================================================

[[ -n "${_CSS2_LOADED:-}" ]] && return 0; _CSS2_LOADED=1

CSS2_VERSION="362.0"
CSS2_GENERATED=0
CSS2_ERRORS=0
CSS2_PHASE="container_security"
CSS2_FILES_CREATED=()
CSS2_VULNS_FOUND=0

: "${GREEN:=\033[0;32m}" ; : "${RED:=\033[0;31m}" ; : "${YELLOW:=\033[0;33m}"
: "${CYAN:=\033[0;36m}" ; : "${BOLD:=\033[1m}" ; : "${NC:=\033[0m}"

_css2_log() { echo -e "  ${CYAN}[CSS2]${NC} $*"; }
_css2_ok() { echo -e "  ${GREEN}[CSS2]${NC} $*"; }
_css2_err() { echo -e "  ${RED}[CSS2]${NC} $*"; }

_css2_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        CSS2_FILES_CREATED+=("$filepath")
        CSS2_GENERATED=$((CSS2_GENERATED + 1))
        _css2_ok "Created: ${filepath##*/}"
    else
        CSS2_ERRORS=$((CSS2_ERRORS + 1))
        _css2_err "Failed: ${filepath##*/}"
    fi
}

css2_init() {
    CSS2_GENERATED=0; CSS2_ERRORS=0; CSS2_VULNS_FOUND=0; CSS2_FILES_CREATED=()
    _css2_log "Container Security Scanner v${CSS2_VERSION} initialized"
    return 0
}

# =============================================================================
# Scan Image
# =============================================================================
_css2_scan_image() {
    local project_dir="${1:-.}"

    _css2_log "Generating container image scanner..."

    local sec_dir="${project_dir}/src/lib/container-security"
    mkdir -p "$sec_dir" 2>/dev/null

    _css2_write_file "${sec_dir}/dockerfile-linter.ts" "$(cat <<'TS'
import { readFileSync } from 'fs';

interface LintRule {
  id: string;
  severity: 'error' | 'warning' | 'info';
  message: string;
  check: (lines: string[]) => boolean;
}

interface LintResult {
  passed: boolean;
  findings: { rule: string; severity: string; message: string; line?: number }[];
}

const RULES: LintRule[] = [
  {
    id: 'DL3006', severity: 'warning', message: 'Use a specific tag instead of latest',
    check: (lines) => lines.some(l => /^FROM\s+\S+:latest/i.test(l) || /^FROM\s+[^:]+$/i.test(l)),
  },
  {
    id: 'DL3007', severity: 'warning', message: 'Use specific version for base image',
    check: (lines) => lines.some(l => /^FROM\s+\w+:latest/i.test(l)),
  },
  {
    id: 'DL3008', severity: 'warning', message: 'Pin versions in apt-get install',
    check: (lines) => lines.some(l => /apt-get install/.test(l) && !/=/.test(l)),
  },
  {
    id: 'DL3009', severity: 'info', message: 'Delete apt-get lists after install',
    check: (lines) => lines.some(l => /apt-get install/.test(l)) && !lines.some(l => /rm.*apt.*lists/.test(l)),
  },
  {
    id: 'DL3018', severity: 'warning', message: 'Pin versions in apk add',
    check: (lines) => lines.some(l => /apk add/.test(l) && !/=/.test(l) && !l.includes('--no-cache')),
  },
  {
    id: 'DL3025', severity: 'warning', message: 'Use COPY instead of ADD for files',
    check: (lines) => lines.some(l => /^ADD\s/.test(l) && !l.includes('http') && !l.includes('.tar')),
  },
  {
    id: 'DL4006', severity: 'warning', message: 'Set SHELL to use pipefail',
    check: (lines) => lines.some(l => l.includes('|')) && !lines.some(l => /SHELL.*pipefail/.test(l)),
  },
  {
    id: 'SEC001', severity: 'error', message: 'Do not run as root - use USER directive',
    check: (lines) => !lines.some(l => /^USER\s+(?!root)/i.test(l)),
  },
  {
    id: 'SEC002', severity: 'error', message: 'Sensitive data detected in Dockerfile',
    check: (lines) => lines.some(l => /(password|secret|api.?key|token)\s*=/i.test(l) && /^(ENV|ARG)/i.test(l)),
  },
];

export function lintDockerfile(path: string): LintResult {
  const content = readFileSync(path, 'utf-8');
  const lines = content.split('\n');
  const findings: LintResult['findings'] = [];

  for (const rule of RULES) {
    if (rule.check(lines)) {
      findings.push({ rule: rule.id, severity: rule.severity, message: rule.message });
    }
  }

  return { passed: !findings.some(f => f.severity === 'error'), findings };
}
TS
)"

    _css2_write_file "${sec_dir}/secure-dockerfile.template" "$(cat <<'DOCKERFILE'
# Multi-stage build for minimal attack surface
FROM node:20-alpine AS builder
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
RUN npm run build

FROM gcr.io/distroless/nodejs20-debian12 AS runner
WORKDIR /app
COPY --from=builder /app/node_modules ./node_modules
COPY --from=builder /app/.next ./.next
COPY --from=builder /app/public ./public
COPY --from=builder /app/package.json ./

ENV NODE_ENV=production
EXPOSE 3000
USER nonroot:nonroot
CMD ["server.js"]
DOCKERFILE
)"

    _css2_ok "Container image scanner generated"
}

# =============================================================================
# Check Vulnerabilities
# =============================================================================
_css2_check_vulnerabilities() {
    local project_dir="${1:-.}"

    _css2_log "Generating vulnerability check CI..."

    local ci_dir="${project_dir}/.github/workflows"
    mkdir -p "$ci_dir" 2>/dev/null

    _css2_write_file "${ci_dir}/container-scan.yml" "$(cat <<'YAML'
name: Container Security Scan
on:
  push:
    paths:
      - 'Dockerfile*'
      - '.dockerignore'
  pull_request:
    paths:
      - 'Dockerfile*'

jobs:
  scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Build image
        run: docker build -t app:scan .

      - name: Run Trivy vulnerability scanner
        uses: aquasecurity/trivy-action@master
        with:
          image-ref: 'app:scan'
          format: 'sarif'
          output: 'trivy-results.sarif'
          severity: 'CRITICAL,HIGH'
          exit-code: '1'

      - name: Upload SARIF
        uses: github/codeql-action/upload-sarif@v3
        if: always()
        with:
          sarif_file: 'trivy-results.sarif'

      - name: Dockerfile lint
        uses: hadolint/hadolint-action@v3.1.0
        with:
          dockerfile: Dockerfile
          failure-threshold: warning
YAML
)"

    _css2_ok "Container vulnerability check CI generated"
}

# =============================================================================
# Generate Report
# =============================================================================
_css2_generate_report() {
    local project_dir="${1:-.}"

    _css2_log "Generating container security report template..."

    local sec_dir="${project_dir}/src/lib/container-security"
    mkdir -p "$sec_dir" 2>/dev/null

    _css2_write_file "${sec_dir}/report.ts" "$(cat <<'TS'
interface ContainerSecurityReport {
  image: string;
  scannedAt: string;
  dockerfile: { passed: boolean; findings: number };
  vulnerabilities: { critical: number; high: number; medium: number; low: number };
  bestPractices: { score: number; recommendations: string[] };
}

export function generateReport(image: string, dockerLint: any, trivyResults: any): ContainerSecurityReport {
  const recommendations: string[] = [];

  if (!dockerLint.passed) recommendations.push('Fix Dockerfile lint errors');
  if (trivyResults.critical > 0) recommendations.push('Patch critical vulnerabilities immediately');
  if (trivyResults.high > 0) recommendations.push('Address high severity vulnerabilities');

  const totalIssues = (dockerLint.findings?.length || 0) + trivyResults.critical + trivyResults.high;
  const score = Math.max(0, 100 - totalIssues * 5);

  return {
    image,
    scannedAt: new Date().toISOString(),
    dockerfile: { passed: dockerLint.passed, findings: dockerLint.findings?.length || 0 },
    vulnerabilities: trivyResults,
    bestPractices: { score, recommendations },
  };
}
TS
)"

    _css2_ok "Container security report template generated"
}

# =============================================================================
# Report / Score / Register
# =============================================================================
css2_report() {
    echo -e "\n  ${BOLD}=== Container Security Scanner v${CSS2_VERSION} ===${NC}"
    echo -e "  生成ファイル数 : ${CSS2_GENERATED}"
    echo -e "  エラー         : ${CSS2_ERRORS}"
    echo -e "  脆弱性検出     : ${CSS2_VULNS_FOUND}"
    if [[ ${#CSS2_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${CSS2_FILES_CREATED[@]}"; do echo -e "    - ${f}"; done
    fi
}

css2_score() {
    if [[ ${CSS2_GENERATED} -ge 3 ]] && [[ ${CSS2_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${CSS2_GENERATED} -gt 0 ]] && [[ ${CSS2_ERRORS} -eq 0 ]]; then echo "90"
    elif [[ ${CSS2_GENERATED} -gt 0 ]]; then echo "70"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "container-security-scanner" --version "362.0" \
        --description "コンテナイメージスキャン×脆弱性チェック×セキュアDockerfile" \
        --init "css2_init" --report "css2_report" --score "css2_score" \
        --enable-var "ENABLE_CONTAINER_SECURITY" --cli-flags "--container-security:--no-container-security"
fi

# v2003.1: source時のexit codeを確実に0にする
true
