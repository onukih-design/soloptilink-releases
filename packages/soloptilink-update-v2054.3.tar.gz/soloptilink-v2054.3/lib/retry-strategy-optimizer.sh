#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v448.0 - Retry Strategy Optimizer
# =============================================================================
# リトライ戦略の最適化。指数バックオフ設定、ジッター追加、
# 最大リトライ回数の設定を自動化する。
#
# Functions:
#   _rso_init()               - 初期化
#   _rso_configure_retry()    - リトライ設定分析
#   _rso_add_jitter()         - ジッター追加推奨
#   _rso_set_max_retries()    - 最大リトライ設定
#   _rso_report() / _rso_score()
#
# All globals use the RSO_ prefix.
# =============================================================================

[[ -n "${_RSO_LOADED:-}" ]] && return 0; _RSO_LOADED=1

declare -g RSO_VERSION="448.0"
declare -g RSO_GENERATED=0
declare -g RSO_ERRORS=0
declare -g RSO_RETRY_PATTERNS=0
declare -g RSO_MISSING_BACKOFF=0
declare -g RSO_MISSING_JITTER=0
declare -g RSO_INFINITE_RETRIES=0

declare -ga _RSO_FINDINGS=()

_RSO_GREEN="${GREEN:-\033[0;32m}"
_RSO_YELLOW="${YELLOW:-\033[0;33m}"
_RSO_CYAN="${CYAN:-\033[0;36m}"
_RSO_BOLD="${BOLD:-\033[1m}"
_RSO_NC="${NC:-\033[0m}"

_rso_init() {
    RSO_GENERATED=0; RSO_ERRORS=0; RSO_RETRY_PATTERNS=0
    RSO_MISSING_BACKOFF=0; RSO_MISSING_JITTER=0; RSO_INFINITE_RETRIES=0
    _RSO_FINDINGS=()
    return 0
}

_rso_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_RSO_CYAN}[RSO]${_RSO_NC} $*" >&2 ;;
        ok)    echo -e "  ${_RSO_GREEN}[RSO]${_RSO_NC} $*" >&2 ;;
        warn)  echo -e "  ${_RSO_YELLOW}[RSO]${_RSO_NC} $*" >&2 ;;
        *)     echo -e "  ${_RSO_CYAN}[RSO]${_RSO_NC} $*" >&2 ;;
    esac
}

_rso_configure_retry() {
    local project_dir="${1:-.}"
    _rso_log info "リトライ設定分析"

    RSO_RETRY_PATTERNS=0
    RSO_MISSING_BACKOFF=0

    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"

        # リトライパターン検出
        local retry_count
        retry_count=$(grep -c "retry\|retries\|maxRetries\|attempts" "$file" 2>/dev/null || echo 0)
        if [[ $retry_count -gt 0 ]]; then
            RSO_RETRY_PATTERNS=$((RSO_RETRY_PATTERNS + retry_count))
        fi

        # catch-and-retry without backoff
        local catch_retry
        catch_retry=$(grep -n "catch.*retry\|catch.*attempt\|while.*retry\|for.*retry" "$file" 2>/dev/null | wc -l || echo 0)
        if [[ $catch_retry -gt 0 ]]; then
            local has_delay
            has_delay=$(grep -c "setTimeout\|sleep\|delay\|backoff\|wait" "$file" 2>/dev/null || echo 0)
            if [[ $has_delay -eq 0 ]]; then
                RSO_MISSING_BACKOFF=$((RSO_MISSING_BACKOFF + 1))
                _RSO_FINDINGS+=("NO_BACKOFF:${rel}:retry without delay - add exponential backoff")
                _rso_log warn "バックオフなしリトライ: ${rel}"
            fi
        fi

        # while(true) retry loop
        local infinite
        infinite=$(grep -c "while.*true.*retry\|while.*true.*fetch\|while.*true.*request" "$file" 2>/dev/null || echo 0)
        if [[ $infinite -gt 0 ]]; then
            RSO_INFINITE_RETRIES=$((RSO_INFINITE_RETRIES + 1))
            _RSO_FINDINGS+=("INFINITE_RETRY:${rel}:infinite retry loop detected - add max attempts")
            _rso_log warn "無限リトライ: ${rel}"
        fi

        # fetch without retry
        local fetch_no_retry
        fetch_no_retry=$(grep -n "fetch(" "$file" 2>/dev/null | wc -l || echo 0)
        local fetch_with_retry
        fetch_with_retry=$(grep -c "fetch.*retry\|retry.*fetch" "$file" 2>/dev/null || echo 0)
        if [[ $fetch_no_retry -gt 3 ]] && [[ $fetch_with_retry -eq 0 ]]; then
            _RSO_FINDINGS+=("NO_RETRY:${rel}:${fetch_no_retry}x fetch without retry wrapper")
        fi
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.js" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" -print0 2>/dev/null)

    RSO_GENERATED=$((RSO_GENERATED + 1))
    _rso_log ok "リトライパターン: ${RSO_RETRY_PATTERNS}件, バックオフ不足: ${RSO_MISSING_BACKOFF}件"
    return 0
}

_rso_add_jitter() {
    local project_dir="${1:-.}"
    _rso_log info "ジッター分析"

    RSO_MISSING_JITTER=0

    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"
        local has_backoff
        has_backoff=$(grep -c "backoff\|exponential\|Math.pow.*2\|<< " "$file" 2>/dev/null || echo 0)
        local has_jitter
        has_jitter=$(grep -c "jitter\|Math.random\|random()" "$file" 2>/dev/null || echo 0)

        if [[ $has_backoff -gt 0 ]] && [[ $has_jitter -eq 0 ]]; then
            RSO_MISSING_JITTER=$((RSO_MISSING_JITTER + 1))
            _RSO_FINDINGS+=("NO_JITTER:${rel}:exponential backoff without jitter - thundering herd risk")
            _rso_log warn "ジッターなし: ${rel}"
        fi
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.js" \) \
             -not -path "*/node_modules/*" -print0 2>/dev/null)

    _RSO_FINDINGS+=("JITTER_FORMULA:delay = min(baseDelay * 2^attempt + random(0, baseDelay), maxDelay)")
    _RSO_FINDINGS+=("FULL_JITTER:prefer full jitter over equal jitter for better distribution")

    RSO_GENERATED=$((RSO_GENERATED + 1))
    _rso_log ok "ジッター不足: ${RSO_MISSING_JITTER}件"
    return 0
}

_rso_set_max_retries() {
    local project_dir="${1:-.}"
    _rso_log info "最大リトライ設定推奨"

    _RSO_FINDINGS+=("MAX_RETRIES:API calls: maxRetries=3, baseDelay=1000ms, maxDelay=30000ms")
    _RSO_FINDINGS+=("DB_RETRIES:database: maxRetries=5, baseDelay=100ms (transient errors)")
    _RSO_FINDINGS+=("QUEUE_RETRIES:job queue: maxRetries=10, baseDelay=5000ms with DLQ")
    _RSO_FINDINGS+=("IDEMPOTENCY:ensure retry-safe operations are idempotent")
    _RSO_FINDINGS+=("NON_RETRYABLE:skip retry for 4xx errors (except 429 Rate Limit)")

    RSO_GENERATED=$((RSO_GENERATED + 1))
    _rso_log ok "リトライ設定推奨完了"
    return 0
}

_rso_report() {
    echo -e "\n  ${_RSO_BOLD}=== retry-strategy-optimizer v${RSO_VERSION} ===${_RSO_NC}"
    echo -e "  リトライパターン: ${RSO_RETRY_PATTERNS}"
    echo -e "  バックオフ不足  : ${RSO_MISSING_BACKOFF}"
    echo -e "  ジッター不足    : ${RSO_MISSING_JITTER}"
    echo -e "  無限リトライ    : ${RSO_INFINITE_RETRIES}"
    echo -e "  エラー          : ${RSO_ERRORS}"
}

_rso_score() {
    local score=50
    [[ ${RSO_RETRY_PATTERNS} -gt 0 ]] && score=$((score + 10))
    [[ ${RSO_MISSING_BACKOFF} -eq 0 ]] && score=$((score + 15))
    [[ ${RSO_MISSING_JITTER} -eq 0 ]] && score=$((score + 10))
    [[ ${RSO_INFINITE_RETRIES} -eq 0 ]] && score=$((score + 10))
    [[ ${RSO_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "retry-strategy-optimizer" --version "${RSO_VERSION}" \
        --description "リトライ戦略最適化×指数バックオフ×ジッター×最大回数 (v448)" \
        --init "_rso_init" --report "_rso_report" --score "_rso_score" \
        --enable-var "ENABLE_RETRY_OPT" --cli-flags "--retry-opt:--no-retry-opt"
fi

# v2003.1: source時のexit codeを確実に0にする
true
