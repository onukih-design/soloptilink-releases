#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v52.0 - Structured Output Pipeline v2
# =============================================================================
# Replaces fragile markdown regex parsing with JSON-structured output.
# Claude outputs {"files":[{"path":"...","content":"..."}],"summary":"..."}
# format, enabling reliable file extraction.
#
# v52.0: Full structured output pipeline
#   - JSON出力フォーマット指示をプロンプト末尾に自動注入
#   - jq/Python3によるJSONパース（多段フォールバック）
#   - マークダウンフォールバック（JSON失敗時）
#   - ファイル書き込み前の構文チェック統合
#
# Functions:
#   so2_init                    - Initialize v2 structured output
#   so2_inject_format_instruction - Append JSON format instruction to prompt
#   so2_call_claude_structured  - Call Claude with structured output enforcement
#   so2_parse_json_output       - Parse JSON output into files
#   so2_parse_markdown_fallback - Fallback markdown parser
#   so2_write_files             - Write parsed files to disk
#   so2_validate_file           - Validate file before writing
#   so2_report                  - Usage statistics
#
# All globals use the SO2_ prefix.
# =============================================================================

[[ -n "${_STRUCTURED_OUTPUT_V2_LOADED:-}" ]] && return 0
_STRUCTURED_OUTPUT_V2_LOADED=1

# ============================================================
# State
# ============================================================
declare -g SO2_VERSION="52.0"
declare -g SO2_ENABLED="false"
declare -g SO2_CALLS=0
declare -g SO2_JSON_SUCCESS=0
declare -g SO2_MARKDOWN_FALLBACK=0
declare -g SO2_FILES_WRITTEN=0
declare -g SO2_VALIDATION_FAILURES=0
declare -g SO2_REWRITE_ATTEMPTS=0

# ============================================================
# Internal logger
# ============================================================
_so2_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    [[ "$level" == "SUCCESS" ]] && color="${GREEN:-}"
    echo -e "  ${color}[STRUCT-OUT-v2]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize
# ============================================================
so2_init() {
    SO2_ENABLED="true"
    SO2_CALLS=0
    SO2_JSON_SUCCESS=0
    SO2_MARKDOWN_FALLBACK=0
    SO2_FILES_WRITTEN=0
    SO2_VALIDATION_FAILURES=0
    SO2_REWRITE_ATTEMPTS=0
    _so2_log "SUCCESS" "Structured Output v2 初期化完了"
    return 0
}

# ============================================================
# JSON format instruction to append to prompts
# ============================================================
SO2_FORMAT_INSTRUCTION='

=== 出力フォーマット指示（必須） ===
以下のJSON形式で出力してください。マークダウンのコードブロック(```)は使わないでください。
純粋なJSONのみを出力してください。説明文も不要です。

{
  "files": [
    {
      "path": "ファイルの相対パス（例: src/app/api/items/route.ts）",
      "content": "ファイルの完全な内容"
    }
  ],
  "summary": "変更内容の1行要約"
}

重要なルール:
- JSONの文字列値内の改行は \n でエスケープしてください
- JSONの文字列値内のダブルクォートは \" でエスケープしてください
- ファイルは省略せず完全な内容を出力してください
- pathは相対パスで指定してください
- 必ず有効なJSONを出力してください
'

# ============================================================
# Inject format instruction into prompt
# ============================================================
so2_inject_format_instruction() {
    local prompt="$1"
    printf '%s\n%s' "$prompt" "$SO2_FORMAT_INSTRUCTION"
}

# ============================================================
# Call Claude with structured output enforcement
# Returns: JSON or markdown text (with indicator in SO2_LAST_FORMAT)
# ============================================================
declare -g SO2_LAST_FORMAT=""  # "json" or "markdown"
declare -g SO2_LAST_OUTPUT=""

so2_call_claude_structured() {
    local prompt="$1"
    local output_file="${2:-}"
    local agent_file="${3:-}"
    local phase_name="${4:-}"

    SO2_CALLS=$((SO2_CALLS + 1))
    SO2_LAST_FORMAT=""
    SO2_LAST_OUTPUT=""

    # Inject JSON format instruction
    local structured_prompt
    structured_prompt=$(so2_inject_format_instruction "$prompt")

    # Build Claude CLI command
    local cmd_args=(-p --dangerously-skip-permissions --output-format text)
    [[ -n "$agent_file" && -f "$agent_file" ]] && cmd_args+=(-a "$agent_file")

    # Model routing integration
    local model_flag=""
    if [[ "${MR_ENABLED:-false}" == "true" ]] && type -t mr_route_phase &>/dev/null; then
        local tier
        tier=$(mr_route_phase "${phase_name:-unknown}" "" 2>/dev/null || echo "balanced")
        model_flag=$(mr_get_model_flag "$tier" 2>/dev/null || echo "")
    fi
    [[ -n "$model_flag" ]] && cmd_args+=($model_flag)

    # Execute with timeout and retry
    local timeout_sec="${CLAUDE_TIMEOUT:-300}"
    local result=""
    local rc=1
    local claude_err="${SESSION_LOG_DIR:-/tmp}/claude_so2_stderr.log"
    mkdir -p "$(dirname "$claude_err")" 2>/dev/null || true

    local timeout_cmd=""
    if command -v timeout &>/dev/null; then
        timeout_cmd="timeout ${timeout_sec}"
    fi

    result=$(${timeout_cmd} claude "${cmd_args[@]}" "$structured_prompt" 2>>"$claude_err")
    rc=$?

    if [[ $rc -ne 0 || -z "$result" ]]; then
        _so2_log "WARN" "Claude呼び出し失敗 (rc=${rc})"
        SO2_LAST_FORMAT="error"
        return $rc
    fi

    # Try JSON parsing first
    if so2_parse_json_output "$result" >/dev/null 2>&1; then
        SO2_LAST_FORMAT="json"
        SO2_LAST_OUTPUT="$result"
        SO2_JSON_SUCCESS=$((SO2_JSON_SUCCESS + 1))
        _so2_log "SUCCESS" "JSON構造化出力を取得"
    else
        # Fallback to markdown
        SO2_LAST_FORMAT="markdown"
        SO2_LAST_OUTPUT="$result"
        SO2_MARKDOWN_FALLBACK=$((SO2_MARKDOWN_FALLBACK + 1))
        _so2_log "WARN" "JSONパース失敗 → マークダウンフォールバック"
    fi

    # Write to output file if specified
    if [[ -n "$output_file" ]]; then
        mkdir -p "$(dirname "$output_file")" 2>/dev/null || true
        printf '%s\n' "$result" > "$output_file"
    fi

    printf '%s\n' "$result"
    return 0
}

# ============================================================
# Parse JSON structured output → file list
# Output: path\tcontent lines (tab-separated)
# Returns 0 if valid JSON with files array, 1 otherwise
# ============================================================
so2_parse_json_output() {
    local raw_output="$1"
    [[ -z "$raw_output" ]] && return 1

    # Strip any leading/trailing markdown code block markers
    local cleaned
    cleaned=$(printf '%s' "$raw_output" | sed -E 's/^```(json)?//;s/```$//')

    # Try jq first (fastest)
    if command -v jq &>/dev/null; then
        local file_count
        file_count=$(printf '%s' "$cleaned" | jq -r '.files | length' 2>/dev/null)
        if [[ "$file_count" =~ ^[0-9]+$ ]] && [[ "$file_count" -gt 0 ]]; then
            # Valid JSON with files array
            printf '%s' "$cleaned" | jq -r '.files[] | "\(.path)\t\(.content)"' 2>/dev/null
            return 0
        fi
    fi

    # Try Python3 (more robust)
    if command -v python3 &>/dev/null; then
        local py_result
        py_result=$(python3 -c "
import json, sys

raw = sys.stdin.read().strip()
# Try to find JSON in the output (may be wrapped in markdown)
start = raw.find('{')
end = raw.rfind('}')
if start < 0 or end < 0:
    sys.exit(1)

try:
    data = json.loads(raw[start:end+1])
    files = data.get('files', [])
    if not files:
        sys.exit(1)
    for f in files:
        path = f.get('path', '')
        content = f.get('content', '')
        if path and content:
            # Output path and content separated by a unique delimiter
            print(f'FILE_PATH:{path}')
            print(content)
            print('FILE_END_MARKER')
    sys.exit(0)
except (json.JSONDecodeError, KeyError, TypeError):
    sys.exit(1)
" <<< "$raw_output" 2>/dev/null)
        if [[ $? -eq 0 && -n "$py_result" ]]; then
            printf '%s\n' "$py_result"
            return 0
        fi
    fi

    return 1
}

# ============================================================
# Fallback: Parse markdown code blocks
# ============================================================
so2_parse_markdown_fallback() {
    local raw_output="$1"
    [[ -z "$raw_output" ]] && return 1

    # Delegate to existing file writers if available
    if type -t fw2_parse_and_write &>/dev/null; then
        printf '%s\n' "$raw_output"
        return 0
    fi
    if type -t fw_smart_write &>/dev/null; then
        printf '%s\n' "$raw_output"
        return 0
    fi

    # Basic markdown code block extraction
    python3 -c "
import re, sys

text = sys.stdin.read()
# Match ```language\npath\n...content...\n```
pattern = r'\`\`\`\w*\n(?://|#|<!--)?\s*(?:file:?\s*)?([^\n]+)\n(.*?)\n\`\`\`'
matches = re.findall(pattern, text, re.DOTALL)

for path, content in matches:
    path = path.strip().strip('\"').strip(\"'\")
    # Skip paths that look like descriptions, not file paths
    if '/' in path or '.' in path:
        print(f'FILE_PATH:{path}')
        print(content)
        print('FILE_END_MARKER')
" <<< "$raw_output" 2>/dev/null
    return $?
}

# ============================================================
# Write parsed files to project directory
# Integrates with Code Validator for pre-write checks
# ============================================================
so2_write_files() {
    local parsed_output="$1"
    local project_dir="${2:-${PROJECT_DIR:-.}}"
    local validate="${3:-true}"

    [[ -z "$parsed_output" ]] && return 1

    local current_path=""
    local current_content=""
    local files_written=0
    local write_errors=0

    while IFS= read -r line; do
        if [[ "$line" == FILE_PATH:* ]]; then
            # Write previous file if exists
            if [[ -n "$current_path" && -n "$current_content" ]]; then
                _so2_write_single_file "$project_dir" "$current_path" "$current_content" "$validate"
                if [[ $? -eq 0 ]]; then
                    files_written=$((files_written + 1))
                else
                    write_errors=$((write_errors + 1))
                fi
            fi
            current_path="${line#FILE_PATH:}"
            current_content=""
        elif [[ "$line" == "FILE_END_MARKER" ]]; then
            # Write current file
            if [[ -n "$current_path" && -n "$current_content" ]]; then
                _so2_write_single_file "$project_dir" "$current_path" "$current_content" "$validate"
                if [[ $? -eq 0 ]]; then
                    files_written=$((files_written + 1))
                else
                    write_errors=$((write_errors + 1))
                fi
            fi
            current_path=""
            current_content=""
        else
            if [[ -n "$current_content" ]]; then
                current_content="${current_content}
${line}"
            else
                current_content="$line"
            fi
        fi
    done <<< "$parsed_output"

    # Handle last file
    if [[ -n "$current_path" && -n "$current_content" ]]; then
        _so2_write_single_file "$project_dir" "$current_path" "$current_content" "$validate"
        if [[ $? -eq 0 ]]; then
            files_written=$((files_written + 1))
        else
            write_errors=$((write_errors + 1))
        fi
    fi

    SO2_FILES_WRITTEN=$((SO2_FILES_WRITTEN + files_written))
    _so2_log "SUCCESS" "${files_written}ファイル書き込み完了 (エラー: ${write_errors})"
    return 0
}

# ============================================================
# Write a single file with optional pre-write validation
# ============================================================
_so2_write_single_file() {
    local project_dir="$1"
    local file_path="$2"
    local content="$3"
    local validate="$4"

    # Sanitize path (prevent directory traversal)
    file_path="${file_path#./}"
    if [[ "$file_path" == ../* || "$file_path" == */../* ]]; then
        _so2_log "ERROR" "不正なパス検出、スキップ: ${file_path}"
        return 1
    fi

    local full_path="${project_dir}/${file_path}"

    # Pre-write validation
    if [[ "$validate" == "true" ]]; then
        if ! so2_validate_file "$file_path" "$content"; then
            SO2_VALIDATION_FAILURES=$((SO2_VALIDATION_FAILURES + 1))
            _so2_log "WARN" "検証失敗、書き込み続行: ${file_path}"
            # Write anyway but log the failure - Code Validator will catch it later
        fi
    fi

    # Create directory and write
    mkdir -p "$(dirname "$full_path")" 2>/dev/null || true
    printf '%s\n' "$content" > "$full_path"

    if [[ $? -eq 0 ]]; then
        return 0
    else
        _so2_log "ERROR" "書き込み失敗: ${full_path}"
        return 1
    fi
}

# ============================================================
# Validate file content before writing
# ============================================================
so2_validate_file() {
    local file_path="$1"
    local content="$2"
    local ext="${file_path##*.}"

    case "$ext" in
        ts|tsx|js|jsx)
            # Basic check: matching braces/brackets
            local open_braces close_braces
            open_braces=$(printf '%s' "$content" | tr -cd '{' | wc -c)
            close_braces=$(printf '%s' "$content" | tr -cd '}' | wc -c)
            if [[ "$open_braces" -ne "$close_braces" ]]; then
                _so2_log "WARN" "波括弧不一致 (開${open_braces} / 閉${close_braces}): ${file_path}"
                return 1
            fi
            ;;
        json)
            if command -v jq &>/dev/null; then
                printf '%s' "$content" | jq . &>/dev/null || return 1
            elif command -v python3 &>/dev/null; then
                printf '%s' "$content" | python3 -c "import json,sys; json.load(sys.stdin)" 2>/dev/null || return 1
            fi
            ;;
        py)
            if command -v python3 &>/dev/null; then
                python3 -c "
import ast, sys
try:
    ast.parse(sys.stdin.read())
    sys.exit(0)
except SyntaxError:
    sys.exit(1)
" <<< "$content" 2>/dev/null || return 1
            fi
            ;;
        swift)
            # Basic Swift syntax check: matching braces
            local open_braces close_braces
            open_braces=$(printf '%s' "$content" | tr -cd '{' | wc -c)
            close_braces=$(printf '%s' "$content" | tr -cd '}' | wc -c)
            if [[ "$open_braces" -ne "$close_braces" ]]; then
                return 1
            fi
            ;;
        prisma)
            # Check for model/generator/datasource keywords
            if ! printf '%s' "$content" | grep -qE '(model|generator|datasource)'; then
                return 1
            fi
            ;;
    esac

    return 0
}

# ============================================================
# Process Claude output: parse + write (main entry point)
# ============================================================
so2_process_output() {
    local raw_output="$1"
    local project_dir="${2:-${PROJECT_DIR:-.}}"

    [[ -z "$raw_output" ]] && return 1

    local parsed=""

    # Try JSON first
    parsed=$(so2_parse_json_output "$raw_output" 2>/dev/null)
    if [[ $? -eq 0 && -n "$parsed" ]]; then
        _so2_log "SUCCESS" "JSON構造化出力からファイルを抽出"
        so2_write_files "$parsed" "$project_dir"
        return $?
    fi

    # Fallback to markdown parsing
    parsed=$(so2_parse_markdown_fallback "$raw_output" 2>/dev/null)
    if [[ $? -eq 0 && -n "$parsed" ]]; then
        _so2_log "WARN" "マークダウンフォールバックからファイルを抽出"
        so2_write_files "$parsed" "$project_dir"
        return $?
    fi

    _so2_log "ERROR" "ファイル抽出失敗: JSON/マークダウンいずれもパース不能"
    return 1
}

# ============================================================
# Report
# ============================================================
so2_report() {
    echo -e "\n${BOLD:-}=== Structured Output v2 Report ===${NC:-}"
    echo -e "  バージョン:              ${SO2_VERSION}"
    echo -e "  呼び出し回数:            ${SO2_CALLS}"
    echo -e "  JSON成功:                ${SO2_JSON_SUCCESS}"
    echo -e "  マークダウンフォールバック: ${SO2_MARKDOWN_FALLBACK}"
    local json_rate=0
    if [[ $SO2_CALLS -gt 0 ]]; then
        json_rate=$(( (SO2_JSON_SUCCESS * 100) / SO2_CALLS ))
    fi
    echo -e "  JSON成功率:              ${json_rate}%"
    echo -e "  書き込みファイル数:      ${SO2_FILES_WRITTEN}"
    echo -e "  検証失敗:                ${SO2_VALIDATION_FAILURES}"
    echo -e "  再書き込み試行:          ${SO2_REWRITE_ATTEMPTS}"
}
