#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v104.0 - Error Pattern Learner
# =============================================================================
# テスト失敗・ビルドエラーからパターンを自動学習し、
# 頻度×重大度でランク付けして予防プロンプトを生成するエンジン。
#
# 過去のエラー→修正→成功/失敗をJSONLで蓄積し、
# ドメイン別×エラー種別のパターンを計算。高頻度パターンは
# プロンプト注入用の予防テキストとして自動生成される。
#
# Functions:
#   epl_init                - 履歴ロード・ディレクトリ準備
#   epl_ingest_failure      - エラーと修正を記録
#   epl_compute_patterns    - エラーをグルーピングしてパターン計算
#   epl_rank_patterns       - 頻度×重大度でソート
#   epl_generate_prevention - 予防プロンプト生成
#   epl_export_to_ei        - error-intelligenceへ連携
#   epl_report              - レポート出力
#   epl_score               - モジュールスコア(0-100)
#
# All globals use the EPL_ prefix.
# =============================================================================

[[ -n "${_ERROR_PATTERN_LEARNER_LOADED:-}" ]] && return 0
_ERROR_PATTERN_LEARNER_LOADED=1

EPL_VERSION="200.0"
EPL_INITIALIZED=false

# Storage paths
EPL_LEARN_DIR=""
EPL_PATTERNS_FILE=""
EPL_RAW_FILE=""

# In-memory counters
EPL_TOTAL_INGESTED=0
EPL_TOTAL_PATTERNS=0
EPL_TOTAL_EXPORTED=0

# Pattern storage (associative arrays)
# Key format: "error_type::domain"
declare -g -A _EPL_FREQ=()           # pattern_key → frequency count
declare -g -A _EPL_FIX_SUCCESS=()    # pattern_key → successful fix count
declare -g -A _EPL_FIX_TOTAL=()      # pattern_key → total fix attempts
declare -g -A _EPL_LAST_MSG=()       # pattern_key → last error message
declare -g -A _EPL_SEVERITY=()       # pattern_key → severity (1-10)

# Ranked patterns (indexed arrays)
declare -g -a _EPL_RANKED_KEYS=()
declare -g -a _EPL_RANKED_SCORES=()

# =============================================================================
# epl_init - Load historical errors, prepare directories
# =============================================================================
epl_init() {
    EPL_LEARN_DIR="${HOME}/.soloptilink/learning/errors"
    mkdir -p "$EPL_LEARN_DIR" 2>/dev/null || true

    EPL_PATTERNS_FILE="${EPL_LEARN_DIR}/patterns.jsonl"
    EPL_RAW_FILE="${EPL_LEARN_DIR}/raw_failures.jsonl"

    # Reset in-memory state
    EPL_TOTAL_INGESTED=0
    EPL_TOTAL_PATTERNS=0
    EPL_TOTAL_EXPORTED=0
    _EPL_FREQ=()
    _EPL_FIX_SUCCESS=()
    _EPL_FIX_TOTAL=()
    _EPL_LAST_MSG=()
    _EPL_SEVERITY=()
    _EPL_RANKED_KEYS=()
    _EPL_RANKED_SCORES=()

    # Load existing patterns from disk
    if [[ -f "$EPL_PATTERNS_FILE" ]]; then
        _epl_load_patterns
    fi

    EPL_INITIALIZED=true
    return 0
}

# =============================================================================
# _epl_load_patterns - Load persisted patterns from JSONL
# =============================================================================
_epl_load_patterns() {
    [[ ! -f "$EPL_PATTERNS_FILE" ]] && return 0

    local line
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue

        local etype edomain freq fix_succ fix_total sev msg
        etype=$(_epl_json_val "$line" "error_type")
        edomain=$(_epl_json_val "$line" "domain")
        freq=$(_epl_json_val "$line" "frequency")
        fix_succ=$(_epl_json_val "$line" "fix_success_count")
        fix_total=$(_epl_json_val "$line" "fix_total_count")
        sev=$(_epl_json_val "$line" "severity")
        msg=$(_epl_json_val "$line" "last_message")

        [[ -z "$etype" || -z "$edomain" ]] && continue

        local key="${etype}::${edomain}"
        _EPL_FREQ["$key"]="${freq:-0}"
        _EPL_FIX_SUCCESS["$key"]="${fix_succ:-0}"
        _EPL_FIX_TOTAL["$key"]="${fix_total:-0}"
        _EPL_SEVERITY["$key"]="${sev:-5}"
        _EPL_LAST_MSG["$key"]="${msg:-}"
        EPL_TOTAL_PATTERNS=$((EPL_TOTAL_PATTERNS + 1))
    done < "$EPL_PATTERNS_FILE"

    return 0
}

# =============================================================================
# _epl_json_val - Extract value from JSON string (no jq dependency)
# =============================================================================
_epl_json_val() {
    local json="$1" key="$2"
    local val
    # Handle both string and numeric values
    val=$(echo "$json" | grep -o "\"${key}\":[^,}]*" | head -1 | sed "s/\"${key}\"://;s/^\"//;s/\"$//;s/^[[:space:]]*//;s/[[:space:]]*$//")
    echo "$val"
}

# =============================================================================
# _epl_escape_json - Escape string for JSON embedding
# =============================================================================
_epl_escape_json() {
    local s="$1"
    s="${s//\\/\\\\}"
    s="${s//\"/\\\"}"
    s="${s//$'\n'/\\n}"
    s="${s//$'\t'/\\t}"
    echo "$s"
}

# =============================================================================
# _epl_classify_severity - Classify error severity (1-10) by type
# =============================================================================
_epl_classify_severity() {
    local error_type="$1"
    case "$error_type" in
        security*|injection*|auth*)    echo 10 ;;
        data_loss*|corruption*)        echo 9 ;;
        runtime_crash*|segfault*)      echo 8 ;;
        type_error*|null_ref*)         echo 7 ;;
        build_failure*|compile*)       echo 6 ;;
        test_failure*|assertion*)      echo 5 ;;
        import_error*|module_not_found*) echo 5 ;;
        lint_error*|style*)            echo 3 ;;
        warning*|deprecation*)         echo 2 ;;
        *)                             echo 5 ;;
    esac
}

# =============================================================================
# epl_ingest_failure - Record a failure with its fix attempt
# =============================================================================
# Args: error_type, error_msg, domain, fix_applied, fix_success (true/false)
epl_ingest_failure() {
    local error_type="${1:-unknown}"
    local error_msg="${2:-}"
    local domain="${3:-general}"
    local fix_applied="${4:-none}"
    local fix_success="${5:-false}"

    [[ "$EPL_INITIALIZED" != "true" ]] && return 1

    local key="${error_type}::${domain}"
    local timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date +"%Y-%m-%d")

    # Update in-memory pattern
    local prev_freq="${_EPL_FREQ[$key]:-0}"
    _EPL_FREQ["$key"]=$((prev_freq + 1))

    local prev_total="${_EPL_FIX_TOTAL[$key]:-0}"
    _EPL_FIX_TOTAL["$key"]=$((prev_total + 1))

    if [[ "$fix_success" == "true" ]]; then
        local prev_succ="${_EPL_FIX_SUCCESS[$key]:-0}"
        _EPL_FIX_SUCCESS["$key"]=$((prev_succ + 1))
    fi

    # Set severity if not already set
    if [[ -z "${_EPL_SEVERITY[$key]:-}" ]]; then
        _EPL_SEVERITY["$key"]=$(_epl_classify_severity "$error_type")
    fi

    local escaped_msg
    escaped_msg=$(_epl_escape_json "$error_msg")
    _EPL_LAST_MSG["$key"]="$escaped_msg"

    EPL_TOTAL_INGESTED=$((EPL_TOTAL_INGESTED + 1))

    # Track as new pattern if first occurrence
    if [[ $prev_freq -eq 0 ]]; then
        EPL_TOTAL_PATTERNS=$((EPL_TOTAL_PATTERNS + 1))
    fi

    # Append raw failure to disk
    local escaped_fix
    escaped_fix=$(_epl_escape_json "$fix_applied")
    echo "{\"timestamp\":\"${timestamp}\",\"error_type\":\"${error_type}\",\"domain\":\"${domain}\",\"message\":\"${escaped_msg}\",\"fix\":\"${escaped_fix}\",\"fix_success\":${fix_success}}" >> "$EPL_RAW_FILE" 2>/dev/null

    return 0
}

# =============================================================================
# epl_compute_patterns - Group errors by (type, domain), compute statistics
# =============================================================================
epl_compute_patterns() {
    [[ "$EPL_INITIALIZED" != "true" ]] && return 1

    # If raw file has new entries not yet in patterns, ingest them
    if [[ -f "$EPL_RAW_FILE" ]]; then
        local line
        while IFS= read -r line; do
            [[ -z "$line" ]] && continue

            local etype edomain msg fix fsuccess
            etype=$(_epl_json_val "$line" "error_type")
            edomain=$(_epl_json_val "$line" "domain")
            msg=$(_epl_json_val "$line" "message")
            fix=$(_epl_json_val "$line" "fix")
            fsuccess=$(_epl_json_val "$line" "fix_success")

            [[ -z "$etype" ]] && continue
            [[ -z "$edomain" ]] && edomain="general"

            local key="${etype}::${edomain}"

            # Only count if not already tracked in memory from patterns file
            if [[ -z "${_EPL_FREQ[$key]:-}" ]]; then
                _EPL_FREQ["$key"]=0
                _EPL_FIX_SUCCESS["$key"]=0
                _EPL_FIX_TOTAL["$key"]=0
                _EPL_SEVERITY["$key"]=$(_epl_classify_severity "$etype")
                EPL_TOTAL_PATTERNS=$((EPL_TOTAL_PATTERNS + 1))
            fi
        done < "$EPL_RAW_FILE"
    fi

    # Persist computed patterns to JSONL (overwrite with current state)
    _epl_save_patterns

    return 0
}

# =============================================================================
# _epl_save_patterns - Persist current pattern state to JSONL
# =============================================================================
_epl_save_patterns() {
    [[ -z "$EPL_PATTERNS_FILE" ]] && return 1

    local tmp_file="${EPL_PATTERNS_FILE}.tmp.$$"
    local key
    for key in "${!_EPL_FREQ[@]}"; do
        local etype="${key%%::*}"
        local edomain="${key##*::}"
        local freq="${_EPL_FREQ[$key]:-0}"
        local fix_succ="${_EPL_FIX_SUCCESS[$key]:-0}"
        local fix_total="${_EPL_FIX_TOTAL[$key]:-0}"
        local sev="${_EPL_SEVERITY[$key]:-5}"
        local msg="${_EPL_LAST_MSG[$key]:-}"
        local rate=0
        if [[ $fix_total -gt 0 ]]; then
            rate=$(( (fix_succ * 100) / fix_total ))
        fi

        echo "{\"error_type\":\"${etype}\",\"domain\":\"${edomain}\",\"frequency\":${freq},\"fix_success_count\":${fix_succ},\"fix_total_count\":${fix_total},\"fix_success_rate\":${rate},\"severity\":${sev},\"last_message\":\"${msg}\"}" >> "$tmp_file"
    done

    if [[ -f "$tmp_file" ]]; then
        mv "$tmp_file" "$EPL_PATTERNS_FILE" 2>/dev/null
    fi

    return 0
}

# =============================================================================
# epl_rank_patterns - Sort by frequency * severity, return top-N
# =============================================================================
# Args: top_n (default 10)
# Output: ranked list printed to stdout, one per line: "score|type|domain|freq|fix_rate"
epl_rank_patterns() {
    local top_n="${1:-10}"

    _EPL_RANKED_KEYS=()
    _EPL_RANKED_SCORES=()

    # Build score list: score = frequency * severity
    local key
    local all_entries=""
    for key in "${!_EPL_FREQ[@]}"; do
        local freq="${_EPL_FREQ[$key]:-0}"
        local sev="${_EPL_SEVERITY[$key]:-5}"
        local score=$((freq * sev))
        all_entries="${all_entries}${score}|${key}"$'\n'
    done

    # Sort numerically descending and take top N
    local sorted
    sorted=$(echo "$all_entries" | sort -t'|' -k1 -rn | head -n "$top_n")

    local count=0
    while IFS= read -r entry; do
        [[ -z "$entry" ]] && continue
        local score="${entry%%|*}"
        local key="${entry#*|}"
        _EPL_RANKED_KEYS+=("$key")
        _EPL_RANKED_SCORES+=("$score")

        local etype="${key%%::*}"
        local edomain="${key##*::}"
        local freq="${_EPL_FREQ[$key]:-0}"
        local fix_total="${_EPL_FIX_TOTAL[$key]:-0}"
        local fix_succ="${_EPL_FIX_SUCCESS[$key]:-0}"
        local rate=0
        [[ $fix_total -gt 0 ]] && rate=$(( (fix_succ * 100) / fix_total ))

        echo "${score}|${etype}|${edomain}|${freq}|${rate}"
        count=$((count + 1))
    done <<< "$sorted"

    return 0
}

# =============================================================================
# epl_generate_prevention - Generate prevention prompt for a domain
# =============================================================================
# Args: domain
# Output: prevention text for prompt injection
epl_generate_prevention() {
    local domain="${1:-general}"

    [[ "$EPL_INITIALIZED" != "true" ]] && return 1

    local prevention=""
    local found=0
    local key

    for key in "${!_EPL_FREQ[@]}"; do
        local edomain="${key##*::}"
        # Match exact domain or "all" patterns
        [[ "$edomain" != "$domain" && "$edomain" != "all" && "$edomain" != "general" ]] && continue

        local freq="${_EPL_FREQ[$key]:-0}"
        [[ $freq -lt 2 ]] && continue  # Only include patterns seen 2+ times

        local etype="${key%%::*}"
        local sev="${_EPL_SEVERITY[$key]:-5}"
        local fix_total="${_EPL_FIX_TOTAL[$key]:-0}"
        local fix_succ="${_EPL_FIX_SUCCESS[$key]:-0}"
        local rate=0
        [[ $fix_total -gt 0 ]] && rate=$(( (fix_succ * 100) / fix_total ))
        local msg="${_EPL_LAST_MSG[$key]:-}"

        if [[ $found -eq 0 ]]; then
            prevention="=== ERROR PATTERN PREVENTION (学習済みエラーパターン) ===
以下のエラーは過去に繰り返し発生しています。必ず回避してください:
"
        fi

        prevention="${prevention}- [${etype}] (発生${freq}回, 重大度${sev}/10, 修正成功率${rate}%)"
        if [[ -n "$msg" ]]; then
            prevention="${prevention}: ${msg}"
        fi
        prevention="${prevention}
"
        found=$((found + 1))
    done

    if [[ $found -gt 0 ]]; then
        prevention="${prevention}=== END ERROR PATTERN PREVENTION ==="
        echo "$prevention"
    fi

    return 0
}

# =============================================================================
# epl_export_to_ei - Register learned patterns into error-intelligence
# =============================================================================
epl_export_to_ei() {
    [[ "$EPL_INITIALIZED" != "true" ]] && return 1

    # Check if error-intelligence is available
    if ! type -t ei_record_error &>/dev/null; then
        return 0  # ei not loaded, skip silently
    fi

    local exported=0
    local key
    for key in "${!_EPL_FREQ[@]}"; do
        local freq="${_EPL_FREQ[$key]:-0}"
        [[ $freq -lt 3 ]] && continue  # Only export high-frequency patterns

        local etype="${key%%::*}"
        local edomain="${key##*::}"
        local msg="${_EPL_LAST_MSG[$key]:-}"
        local fix_total="${_EPL_FIX_TOTAL[$key]:-0}"
        local fix_succ="${_EPL_FIX_SUCCESS[$key]:-0}"

        # Build fix instruction from success rate
        local fix_note="auto-learned pattern (freq=${freq})"
        if [[ $fix_total -gt 0 ]]; then
            local rate=$(( (fix_succ * 100) / fix_total ))
            fix_note="${fix_note}, fix_success_rate=${rate}%"
        fi

        # Call ei_record_error if available (pattern_id, description, fix, domains)
        if type -t _ei_add_pattern &>/dev/null; then
            _ei_add_pattern "epl_${etype}" "$msg" "$fix_note" "$edomain" 2>/dev/null || true
        fi

        exported=$((exported + 1))
    done

    EPL_TOTAL_EXPORTED=$exported
    return 0
}

# =============================================================================
# epl_report - Summary report
# =============================================================================
epl_report() {
    echo -e "\n  ${BOLD:-}--- Error Pattern Learner v${EPL_VERSION} ---${NC:-}"
    echo -e "  Ingested failures  : ${EPL_TOTAL_INGESTED}"
    echo -e "  Known patterns     : ${EPL_TOTAL_PATTERNS}"
    echo -e "  Exported to EI     : ${EPL_TOTAL_EXPORTED}"

    if [[ ${#_EPL_RANKED_KEYS[@]} -gt 0 ]]; then
        echo -e "  Top pattern        : ${_EPL_RANKED_KEYS[0]:-none} (score=${_EPL_RANKED_SCORES[0]:-0})"
    fi
}

# =============================================================================
# epl_score - Module health score (0-100)
# =============================================================================
epl_score() {
    local score=50  # Base score

    # +20 if patterns are being tracked
    [[ $EPL_TOTAL_PATTERNS -gt 0 ]] && score=$((score + 20))

    # +15 if patterns have been computed and ranked
    [[ ${#_EPL_RANKED_KEYS[@]} -gt 0 ]] && score=$((score + 15))

    # +15 if fix success rate across all patterns > 50%
    local total_succ=0 total_attempts=0
    local key
    for key in "${!_EPL_FIX_TOTAL[@]}"; do
        total_attempts=$((total_attempts + ${_EPL_FIX_TOTAL[$key]:-0}))
        total_succ=$((total_succ + ${_EPL_FIX_SUCCESS[$key]:-0}))
    done
    if [[ $total_attempts -gt 0 ]]; then
        local global_rate=$(( (total_succ * 100) / total_attempts ))
        [[ $global_rate -ge 50 ]] && score=$((score + 15))
    fi

    # Cap at 100
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# v130.0: 予測関数群
# =============================================================================

# --- ドメイン別エラー予測 ---
# 過去の記録から、このドメインで最も発生しやすいエラー上位5件を返す
epl_predict_errors() {
    local domain="${1:-general}"
    local patterns_file="${EPL_WORK_DIR:-${HOME}/.soloptilink/learning/errors}/patterns.jsonl"

    [[ ! -f "$patterns_file" ]] && return 0

    local predictions=""
    local count=0

    # ドメインでフィルタし、頻度順にソート
    local domain_patterns
    domain_patterns=$(grep "\"domain\":\"${domain}\"" "$patterns_file" 2>/dev/null || \
                     grep "\"domain\":\"general\"" "$patterns_file" 2>/dev/null || echo "")

    if [[ -z "$domain_patterns" ]]; then
        # ドメイン一致がなければ全パターンから
        domain_patterns=$(cat "$patterns_file" 2>/dev/null || echo "")
    fi

    # 頻度でソート（frequency フィールド降順）
    local sorted
    sorted=$(echo "$domain_patterns" | grep -oE '"error_type":"[^"]*".*"frequency":[0-9]+' 2>/dev/null | \
             sort -t: -k3 -rn | head -5)

    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        local etype
        etype=$(echo "$line" | grep -oE '"error_type":"[^"]*"' | sed 's/"error_type":"//;s/"//')
        [[ -z "$etype" ]] && continue
        count=$((count + 1))
        predictions+="${count}. [${etype}] - このドメインで頻出\n"
    done <<< "$sorted"

    if [[ $count -gt 0 ]]; then
        echo -e "## エラー予測（${domain}ドメイン - 上位${count}件）\n${predictions}"
    fi
}

# --- 最高成功率の修正戦略を返す ---
epl_query_best_fix() {
    local error_type="${1:-unknown}"
    local domain="${2:-general}"
    local solutions_file="${HOME}/.soloptilink/learning/solutions/index.jsonl"

    [[ ! -f "$solutions_file" ]] && return 0

    # エラータイプ+ドメインで検索、成功率でソート
    local matches
    matches=$(grep "\"error_type\":\"${error_type}\"" "$solutions_file" 2>/dev/null || echo "")

    if [[ -z "$matches" ]]; then
        # 完全一致がなければ部分一致
        matches=$(grep "${error_type}" "$solutions_file" 2>/dev/null | head -5 || echo "")
    fi

    [[ -z "$matches" ]] && return 0

    # 成功率が最高のエントリを取得
    local best_line
    best_line=$(echo "$matches" | sort -t: -k2 -rn | head -1)

    local fix_strategy
    fix_strategy=$(echo "$best_line" | grep -oE '"fix_strategy":"[^"]*"' | sed 's/"fix_strategy":"//;s/"//')
    local success_rate
    success_rate=$(echo "$best_line" | grep -oE '"success_rate":[0-9]+' | grep -oE '[0-9]+')

    if [[ -n "$fix_strategy" && "${success_rate:-0}" -ge 50 ]]; then
        echo "## EPL推奨修正戦略（成功率${success_rate}%）
${fix_strategy}

過去のセッションで同種のエラーに対してこの戦略が最も効果的でした。"
    fi
}

# =============================================================================
# v193: Predictive error prevention
# ドメイン別エラー予測: 過去パターンから高頻度エラーを事前警告
# =============================================================================
epl_predict_errors() {
    local domain="${1:-general}"
    local predictions=()
    local history_dir="${HOME}/.soloptilink/knowledge/error_patterns"

    [[ ! -d "$history_dir" ]] && return 0

    # Aggregate error frequencies by domain
    local domain_errors
    domain_errors=$(find "$history_dir" -name "*.jsonl" -exec grep "\"domain\":\"${domain}\"" {} \; 2>/dev/null | head -100)

    if [[ -n "$domain_errors" ]]; then
        # Top 5 error types by frequency
        local top_errors
        top_errors=$(echo "$domain_errors" | grep -oE '"error_type":"[^"]*"' | sort | uniq -c | sort -rn | head -5)

        while IFS= read -r line; do
            [[ -z "$line" ]] && continue
            local count
            count=$(echo "$line" | awk '{print $1}')
            local etype
            etype=$(echo "$line" | grep -oE '"[^"]*"' | tr -d '"')
            predictions+=("${etype}(過去${count}回発生)")
        done <<< "$top_errors"
    fi

    if [[ ${#predictions[@]} -gt 0 ]]; then
        echo "以下のエラーが予測されます。事前に対策してください:"
        printf '- %s\n' "${predictions[@]}"
    fi
}

# =============================================================================
# v2001.0: セッション終了時の学習（chain.shエラー回復パイプラインから呼ばれる）
# =============================================================================
epl_learn_from_session() {
    local session_id="${1:-unknown}"
    local project_dir="${2:-.}"
    local recovered="${3:-false}"

    echo -e "  [EPL v130.0] セッション学習: session=${session_id} recovered=${recovered}" >&2

    # セッションログからエラーを収集
    local log_dir="${SESSION_LOG_DIR:-/tmp}/epl_session_${session_id}"
    mkdir -p "$log_dir" 2>/dev/null || true

    # プロジェクト内のエラーログを収集
    local error_files=()
    if [[ -d "${project_dir}" ]]; then
        # TypeScriptコンパイルエラーの収集
        if [[ -f "${project_dir}/tsconfig.json" ]]; then
            local tsc_errors
            tsc_errors=$(cd "$project_dir" && npx tsc --noEmit 2>&1 | grep "error TS" | head -20 2>/dev/null || echo "")
            if [[ -n "$tsc_errors" ]]; then
                echo "$tsc_errors" > "${log_dir}/tsc_errors.txt"
                local tsc_count
                tsc_count=$(echo "$tsc_errors" | wc -l | tr -d ' ')
                echo -e "  [EPL] TypeScriptエラー: ${tsc_count}件収集" >&2
                # パターンDBに記録
                while IFS= read -r err_line; do
                    [[ -z "$err_line" ]] && continue
                    local err_file
                    err_file=$(echo "$err_line" | cut -d'(' -f1)
                    epl_ingest_failure "$err_line" "$err_file" "typescript" 2>/dev/null || true
                done <<< "$tsc_errors"
            fi
        fi

        # ESLintエラーの収集
        if [[ -f "${project_dir}/.eslintrc.json" ]] || [[ -f "${project_dir}/eslint.config.js" ]]; then
            local eslint_errors
            eslint_errors=$(cd "$project_dir" && npx eslint . --quiet 2>&1 | grep "error" | head -20 2>/dev/null || echo "")
            if [[ -n "$eslint_errors" ]]; then
                local eslint_count
                eslint_count=$(echo "$eslint_errors" | wc -l | tr -d ' ')
                echo -e "  [EPL] ESLintエラー: ${eslint_count}件収集" >&2
            fi
        fi
    fi

    # パターン集計
    epl_compute_patterns 2>/dev/null || true

    # 回復結果の記録
    local result_file="${EPL_DB_DIR:-${HOME}/.soloptilink/knowledge/error_patterns}/session_results.jsonl"
    mkdir -p "$(dirname "$result_file")" 2>/dev/null || true
    local timestamp
    timestamp=$(date -u '+%Y-%m-%dT%H:%M:%SZ')
    echo "{\"ts\":\"${timestamp}\",\"session\":\"${session_id}\",\"recovered\":${recovered},\"patterns_learned\":${EPL_TOTAL_PATTERNS:-0}}" >> "$result_file" 2>/dev/null || true

    echo -e "  [EPL] セッション学習完了: ${EPL_TOTAL_PATTERNS:-0}パターン記録" >&2
    return 0
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "error-pattern-learner" \
    --version "130.0" \
    --description "テスト失敗からエラーパターンを自動学習・予防注入" \
    --init "epl_init" \
    --report "epl_report" \
    --score "epl_score" \
    --enable-var "ENABLE_EPL" \
    --cli-flags "--error-pattern-learner:--no-error-pattern-learner"
