#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v322.0 - Docker Optimizer
# =============================================================================
# Dockerfile生成、レイヤー最適化、docker-compose構築。
# マルチステージビルド、セキュリティスキャン、.dockerignore自動生成。
#
# Functions:
#   _do_init()               - Initialize
#   _do_generate_dockerfile() - Generate optimized Dockerfile
#   _do_optimize_layers()    - Analyze & optimize Docker layers
#   _do_generate_compose()   - Generate docker-compose.yml
#   _do_report() / _do_score()
# =============================================================================

[[ -n "${_DO_LOADED:-}" ]] && return 0; _DO_LOADED=1

readonly _DO_RED='\033[0;31m'
readonly _DO_GREEN='\033[0;32m'
readonly _DO_YELLOW='\033[0;33m'
readonly _DO_CYAN='\033[0;36m'
readonly _DO_NC='\033[0m'

declare -g DO_VERSION="322.0"
DO_GENERATED=0
DO_ERRORS=0
DO_FILES_WRITTEN=0
DO_DOCKERFILE_OK=false
DO_COMPOSE_OK=false
DO_OPTIMIZE_OK=false

_do_init() {
    DO_GENERATED=0; DO_ERRORS=0; DO_FILES_WRITTEN=0
    DO_DOCKERFILE_OK=false; DO_COMPOSE_OK=false; DO_OPTIMIZE_OK=false
    echo -e "  ${_DO_GREEN}OK${_DO_NC} Docker Optimizer v${DO_VERSION}" >&2
    return 0
}

_do_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { DO_FILES_WRITTEN=$((DO_FILES_WRITTEN + 1)); return 0; }
    DO_ERRORS=$((DO_ERRORS + 1)); return 1
}

_do_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_DO_CYAN}[docker]${_DO_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_DO_GREEN}[docker]${_DO_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_DO_YELLOW}[docker]${_DO_NC} $msg" >&2 ;;
        error) echo -e "  ${_DO_RED}[docker]${_DO_NC} $msg" >&2 ;;
    esac
}

# =============================================================================
# Detect project runtime
# =============================================================================
_do_detect_runtime() {
    local project_dir="${1:-./output}"
    if [[ -f "${project_dir}/next.config.js" ]] || [[ -f "${project_dir}/next.config.mjs" ]]; then
        echo "nextjs"
    elif [[ -f "${project_dir}/package.json" ]]; then
        if grep -q '"fastify\|express\|koa\|hono"' "${project_dir}/package.json" 2>/dev/null; then
            echo "node-api"
        else
            echo "node"
        fi
    elif [[ -f "${project_dir}/requirements.txt" ]] || [[ -f "${project_dir}/pyproject.toml" ]]; then
        echo "python"
    elif [[ -f "${project_dir}/go.mod" ]]; then
        echo "golang"
    else
        echo "node"
    fi
}

# =============================================================================
# Generate Optimized Dockerfile (multi-stage)
# =============================================================================
_do_generate_dockerfile() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local runtime
    runtime=$(_do_detect_runtime "$project_dir")
    _do_log info "Generating Dockerfile for runtime: ${runtime}"

    case "$runtime" in
    nextjs)
        _do_write_file "${project_dir}/Dockerfile" "$(cat <<'DOCKERFILE'
# === Stage 1: Dependencies ===
FROM node:20-alpine AS deps
RUN apk add --no-cache libc6-compat
WORKDIR /app
COPY package.json package-lock.json* yarn.lock* pnpm-lock.yaml* ./
RUN \
  if [ -f yarn.lock ]; then yarn install --frozen-lockfile; \
  elif [ -f pnpm-lock.yaml ]; then corepack enable pnpm && pnpm i --frozen-lockfile; \
  elif [ -f package-lock.json ]; then npm ci; \
  else npm install; fi

# === Stage 2: Build ===
FROM node:20-alpine AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
ENV NEXT_TELEMETRY_DISABLED=1
RUN npm run build

# === Stage 3: Production ===
FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
ENV NEXT_TELEMETRY_DISABLED=1
RUN addgroup --system --gid 1001 nodejs && adduser --system --uid 1001 nextjs
COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static
USER nextjs
EXPOSE 3000
ENV PORT=3000
ENV HOSTNAME="0.0.0.0"
CMD ["node", "server.js"]
DOCKERFILE
)" ;;

    node-api|node)
        _do_write_file "${project_dir}/Dockerfile" "$(cat <<'DOCKERFILE'
FROM node:20-alpine AS deps
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production && cp -R node_modules /prod_deps
RUN npm ci

FROM node:20-alpine AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm run build 2>/dev/null || true

FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
RUN addgroup -g 1001 -S appgroup && adduser -S appuser -u 1001
COPY --from=deps /prod_deps ./node_modules
COPY --from=builder /app/dist ./dist
COPY --from=builder /app/package.json ./
USER appuser
EXPOSE 3000
HEALTHCHECK --interval=30s --timeout=3s CMD wget -qO- http://localhost:3000/api/health || exit 1
CMD ["node", "dist/index.js"]
DOCKERFILE
)" ;;

    python)
        _do_write_file "${project_dir}/Dockerfile" "$(cat <<'DOCKERFILE'
FROM python:3.12-slim AS builder
WORKDIR /app
COPY requirements*.txt ./
RUN pip install --no-cache-dir --prefix=/install -r requirements.txt

FROM python:3.12-slim
WORKDIR /app
COPY --from=builder /install /usr/local
COPY . .
RUN useradd -m appuser && chown -R appuser:appuser /app
USER appuser
EXPOSE 8000
HEALTHCHECK --interval=30s --timeout=3s CMD python -c "import urllib.request; urllib.request.urlopen('http://localhost:8000/health')"
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "8000"]
DOCKERFILE
)" ;;
    esac

    # .dockerignore
    _do_write_file "${project_dir}/.dockerignore" "$(cat <<'IGNORE'
node_modules
.next
.git
*.md
.env*
.DS_Store
coverage
.nyc_output
dist
__pycache__
*.pyc
.pytest_cache
IGNORE
)"

    _do_log ok "Dockerfile generated for ${runtime}"
    DO_DOCKERFILE_OK=true
    DO_GENERATED=$((DO_GENERATED + 1))
    return 0
}

# =============================================================================
# Optimize Docker Layers (analyze existing Dockerfile)
# =============================================================================
_do_optimize_layers() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local dockerfile="${project_dir}/Dockerfile"
    local issues=0

    if [[ ! -f "$dockerfile" ]]; then
        _do_log warn "No Dockerfile found at ${dockerfile}"
        return 1
    fi

    _do_log info "Analyzing Dockerfile layers..."

    # Check: No COPY . before dependency install
    local copy_line
    copy_line=$(grep -n "^COPY \. " "$dockerfile" 2>/dev/null | head -1 | cut -d: -f1)
    local install_line
    install_line=$(grep -n "npm ci\|npm install\|pip install\|go mod download" "$dockerfile" 2>/dev/null | head -1 | cut -d: -f1)
    if [[ -n "$copy_line" ]] && [[ -n "$install_line" ]] && [[ "$copy_line" -lt "$install_line" ]]; then
        _do_log warn "COPY . before dependency install breaks cache. Move COPY package*.json first."
        issues=$((issues + 1))
    fi

    # Check: Multi-stage build
    local stage_count
    stage_count=$(grep -c "^FROM " "$dockerfile" 2>/dev/null || echo 0)
    if [[ "$stage_count" -lt 2 ]]; then
        _do_log warn "Single-stage build detected. Use multi-stage to reduce image size."
        issues=$((issues + 1))
    fi

    # Check: Running as root
    if ! grep -q "^USER " "$dockerfile" 2>/dev/null; then
        _do_log warn "No USER directive. Container runs as root."
        issues=$((issues + 1))
    fi

    # Check: HEALTHCHECK
    if ! grep -q "^HEALTHCHECK" "$dockerfile" 2>/dev/null; then
        _do_log warn "No HEALTHCHECK directive."
        issues=$((issues + 1))
    fi

    # Check: Alpine base
    if ! grep -q "alpine\|slim\|distroless" "$dockerfile" 2>/dev/null; then
        _do_log warn "Consider using alpine/slim base image to reduce size."
        issues=$((issues + 1))
    fi

    if [[ $issues -eq 0 ]]; then
        _do_log ok "Dockerfile passes all optimization checks"
    else
        _do_log warn "${issues} optimization issues found"
    fi

    DO_OPTIMIZE_OK=true
    DO_GENERATED=$((DO_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate docker-compose.yml
# =============================================================================
_do_generate_compose() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _do_log info "Generating docker-compose.yml..."

    local services="  app:\n    build: .\n    ports:\n      - '3000:3000'\n    environment:\n      - NODE_ENV=development\n      - DATABASE_URL=postgresql://postgres:postgres@db:5432/app\n    depends_on:\n      db:\n        condition: service_healthy\n    volumes:\n      - .:/app\n      - /app/node_modules\n    restart: unless-stopped"

    # Detect if DB is needed
    local db_service=""
    if find "$project_dir" -name "*.prisma" -o -name "schema.prisma" 2>/dev/null | head -1 | grep -q .; then
        db_service="\n\n  db:\n    image: postgres:16-alpine\n    environment:\n      POSTGRES_USER: postgres\n      POSTGRES_PASSWORD: postgres\n      POSTGRES_DB: app\n    ports:\n      - '5432:5432'\n    volumes:\n      - postgres_data:/var/lib/postgresql/data\n    healthcheck:\n      test: ['CMD-SHELL', 'pg_isready -U postgres']\n      interval: 5s\n      timeout: 3s\n      retries: 5"
    fi

    # Detect Redis
    local redis_service=""
    if grep -rq "redis\|ioredis\|bull" "$project_dir" --include="*.ts" --include="*.json" 2>/dev/null; then
        redis_service="\n\n  redis:\n    image: redis:7-alpine\n    ports:\n      - '6379:6379'\n    healthcheck:\n      test: ['CMD', 'redis-cli', 'ping']\n      interval: 5s\n      timeout: 3s"
    fi

    local volumes=""
    [[ -n "$db_service" ]] && volumes="\n\nvolumes:\n  postgres_data:"

    _do_write_file "${project_dir}/docker-compose.yml" "$(printf "version: '3.8'\n\nservices:\n${services}${db_service}${redis_service}${volumes}\n")"

    _do_log ok "docker-compose.yml generated"
    DO_COMPOSE_OK=true
    DO_GENERATED=$((DO_GENERATED + 1))
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_do_report() {
    echo -e "\n  ${_DO_CYAN}=== Docker Optimizer v${DO_VERSION} ===${_DO_NC}"
    echo -e "  Generated: ${DO_GENERATED} | Files: ${DO_FILES_WRITTEN} | Errors: ${DO_ERRORS}"
    echo -e "  Dockerfile: $( ${DO_DOCKERFILE_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Compose: $( ${DO_COMPOSE_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Optimization: $( ${DO_OPTIMIZE_OK} && echo 'OK' || echo 'SKIP')"
}

_do_score() {
    local score=50
    ${DO_DOCKERFILE_OK} && score=$((score + 20))
    ${DO_COMPOSE_OK} && score=$((score + 15))
    ${DO_OPTIMIZE_OK} && score=$((score + 10))
    [[ ${DO_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

# =============================================================================
# Module Registry
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "docker-optimizer" --version "322.0" \
        --description "Docker最適化 マルチステージビルド/Compose生成 (v322)" \
        --init "_do_init" --report "_do_report" --score "_do_score" \
        --enable-var "ENABLE_DOCKER_OPTIMIZER" --cli-flags "--docker-optimizer:--no-docker-optimizer"
fi

# v2003.1: source時のexit codeを確実に0にする
true
