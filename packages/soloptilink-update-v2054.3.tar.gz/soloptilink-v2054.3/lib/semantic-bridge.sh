#!/usr/bin/env bash
# SoloptiLinkAI v540 - Semantic Intelligence Bridge
# Bash↔Python Semantic Engine統合レイヤー
# Epoch 12: 意味理解・コード解析・推論をchain.shから呼び出し可能にする

[[ -n "${_SEMANTIC_BRIDGE_LOADED:-}" ]] && return 0
_SEMANTIC_BRIDGE_LOADED=1

# Logging wrappers (delegate to log() from lib/common/logger.sh)
_log_info()  { if declare -f log &>/dev/null; then log INFO "$1"; else echo "[INFO] $1"; fi; }
_log_warn()  { if declare -f log &>/dev/null; then log WARN "$1"; else echo "[WARN] $1" >&2; fi; }

SEMANTIC_BRIDGE_VERSION="540.0"
SEMANTIC_BRIDGE_INITIALIZED=false

# ============================================================
# 初期化
# ============================================================
_semantic_bridge_init() {
    [[ "$SEMANTIC_BRIDGE_INITIALIZED" == "true" ]] && return 0

    local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
    local python_cmd="${PYTHON_CMD:-python3}"

    # Python + semantic modules check
    if ! command -v "$python_cmd" &>/dev/null; then
        _log_warn "semantic-bridge: Python3 not found, semantic features disabled"
        SEMANTIC_BRIDGE_INITIALIZED="fallback"
        return 0
    fi

    if ! "$python_cmd" -c "import sys; sys.path.insert(0,'$ml_dir'); from semantic import IntentParser" 2>/dev/null; then
        _log_warn "semantic-bridge: Semantic modules not found, using fallback"
        SEMANTIC_BRIDGE_INITIALIZED="fallback"
        return 0
    fi

    SEMANTIC_BRIDGE_INITIALIZED=true
    _log_info "semantic-bridge: v${SEMANTIC_BRIDGE_VERSION} initialized"
}

# ============================================================
# Intent Parsing - 自然言語→構造化意図
# ============================================================
_semantic_parse_intent() {
    local description="$1"

    if [[ "$SEMANTIC_BRIDGE_INITIALIZED" == "fallback" ]]; then
        _semantic_parse_intent_fallback "$description"
        return
    fi

    local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
    local python_cmd="${PYTHON_CMD:-python3}"

    _SOL_INPUT="$description" "$python_cmd" -c "
import sys, json, os
sys.path.insert(0, '$ml_dir')
from semantic import IntentParser
parser = IntentParser()
result = parser.parse(os.environ.get('_SOL_INPUT', ''))
print(json.dumps(result, ensure_ascii=False, default=str))
" 2>/dev/null || _semantic_parse_intent_fallback "$description"
}

_semantic_parse_intent_fallback() {
    local desc="$1"
    local intent="CREATE_CRUD"
    local domain="GENERAL"

    # Japanese keyword detection
    case "$desc" in
        *CRM*|*顧客管理*|*営業管理*) domain="CRM"; intent="CREATE_CRUD" ;;
        *EC*|*ショップ*|*商品*|*カート*) domain="EC"; intent="CREATE_CRUD" ;;
        *チャット*|*メッセージ*|*chat*) domain="CHAT"; intent="CREATE_CRUD" ;;
        *タスク*|*TODO*|*todo*|*管理*) domain="TASK"; intent="CREATE_CRUD" ;;
        *LP*|*ランディング*|*landing*) domain="LP"; intent="DESIGN_UI" ;;
        *ダッシュボード*|*dashboard*) domain="DASHBOARD"; intent="DESIGN_UI" ;;
        *会計*|*請求*|*invoice*) domain="ACCOUNTING"; intent="CREATE_CRUD" ;;
        *在庫*|*inventory*) domain="INVENTORY"; intent="CREATE_CRUD" ;;
        *予約*|*reservation*|*booking*) domain="RESERVATION"; intent="CREATE_CRUD" ;;
        *HR*|*人事*|*従業員*) domain="HR"; intent="CREATE_CRUD" ;;
        *SaaS*|*saas*) domain="SAAS"; intent="CREATE_CRUD" ;;
        *ブログ*|*blog*|*CMS*) domain="BLOG"; intent="CREATE_CRUD" ;;
        *API*|*api*) domain="API"; intent="ADD_API" ;;
        *修正*|*fix*|*バグ*|*bug*) intent="FIX_BUG" ;;
        *リファクタ*|*refactor*) intent="REFACTOR" ;;
        *最適化*|*optimize*|*高速化*) intent="OPTIMIZE" ;;
        *デプロイ*|*deploy*) intent="DEPLOY" ;;
        *テスト*|*test*) intent="TEST" ;;
        *認証*|*auth*|*ログイン*) intent="ADD_AUTH" ;;
    esac

    cat <<EOF
{"intent":"${intent}","domain":"${domain}","confidence":0.7,"entities":{"description":"${desc}"},"source":"fallback"}
EOF
}

# ============================================================
# Requirement Analysis - 要件分解
# ============================================================
_semantic_analyze_requirements() {
    local description="$1"
    local domain="${2:-GENERAL}"

    if [[ "$SEMANTIC_BRIDGE_INITIALIZED" == "fallback" ]]; then
        _semantic_analyze_requirements_fallback "$description" "$domain"
        return
    fi

    local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
    local python_cmd="${PYTHON_CMD:-python3}"

    _SOL_INPUT="$description" _SOL_DOMAIN="$domain" "$python_cmd" -c "
import sys, json, os
sys.path.insert(0, '$ml_dir')
from semantic import RequirementAnalyzer
analyzer = RequirementAnalyzer()
result = analyzer.analyze(os.environ.get('_SOL_INPUT', ''), domain=os.environ.get('_SOL_DOMAIN', 'GENERAL'))
print(json.dumps(result, ensure_ascii=False, default=str))
" 2>/dev/null || _semantic_analyze_requirements_fallback "$description" "$domain"
}

_semantic_analyze_requirements_fallback() {
    local desc="$1"
    local domain="$2"

    # 基本タスク分解
    local tasks='[]'
    case "$domain" in
        CRM|EC|TASK|ACCOUNTING|HR|INVENTORY|RESERVATION)
            tasks='[
                {"id":"t1","name":"Database Schema Design","priority":1,"complexity":"medium"},
                {"id":"t2","name":"API Endpoints","priority":2,"complexity":"medium","depends":["t1"]},
                {"id":"t3","name":"Authentication","priority":1,"complexity":"medium"},
                {"id":"t4","name":"Frontend Pages","priority":3,"complexity":"high","depends":["t2"]},
                {"id":"t5","name":"CRUD Operations","priority":2,"complexity":"medium","depends":["t1","t2"]},
                {"id":"t6","name":"Dashboard","priority":4,"complexity":"medium","depends":["t5"]},
                {"id":"t7","name":"Testing","priority":5,"complexity":"medium","depends":["t2","t4"]}
            ]'
            ;;
        CHAT)
            tasks='[
                {"id":"t1","name":"WebSocket Server","priority":1,"complexity":"high"},
                {"id":"t2","name":"Message Schema","priority":1,"complexity":"low"},
                {"id":"t3","name":"Chat UI","priority":2,"complexity":"high","depends":["t1","t2"]},
                {"id":"t4","name":"Authentication","priority":1,"complexity":"medium"},
                {"id":"t5","name":"Message History","priority":3,"complexity":"medium","depends":["t2"]}
            ]'
            ;;
        LP|DASHBOARD)
            tasks='[
                {"id":"t1","name":"Layout Design","priority":1,"complexity":"medium"},
                {"id":"t2","name":"Component Implementation","priority":2,"complexity":"medium","depends":["t1"]},
                {"id":"t3","name":"Responsive Design","priority":3,"complexity":"medium","depends":["t2"]},
                {"id":"t4","name":"SEO Optimization","priority":3,"complexity":"low","depends":["t2"]}
            ]'
            ;;
        *)
            tasks='[
                {"id":"t1","name":"Project Setup","priority":1,"complexity":"low"},
                {"id":"t2","name":"Core Implementation","priority":2,"complexity":"high","depends":["t1"]},
                {"id":"t3","name":"Testing","priority":3,"complexity":"medium","depends":["t2"]},
                {"id":"t4","name":"Deployment Config","priority":4,"complexity":"low","depends":["t2"]}
            ]'
            ;;
    esac

    cat <<EOF
{"domain":"${domain}","task_count":$(echo "$tasks" | python3 -c "import sys,json;print(len(json.load(sys.stdin)))" 2>/dev/null || echo 4),"tasks":${tasks},"source":"fallback"}
EOF
}

# ============================================================
# Context Ranking - タスクに最適なファイル選択
# ============================================================
_semantic_rank_context() {
    local task_description="$1"
    local project_dir="${2:-$OUTPUT_DIR}"
    local max_files="${3:-20}"

    if [[ "$SEMANTIC_BRIDGE_INITIALIZED" == "fallback" ]] || [[ ! -d "$project_dir" ]]; then
        _semantic_rank_context_fallback "$task_description" "$project_dir" "$max_files"
        return
    fi

    local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
    local python_cmd="${PYTHON_CMD:-python3}"

    _SOL_INPUT="$task_description" "$python_cmd" -c "
import sys, json, os
sys.path.insert(0, '$ml_dir')
from semantic import ContextRanker
ranker = ContextRanker()
result = ranker.rank(os.environ.get('_SOL_INPUT', ''), '$project_dir', max_files=$max_files)
print(json.dumps(result, ensure_ascii=False, default=str))
" 2>/dev/null || _semantic_rank_context_fallback "$task_description" "$project_dir" "$max_files"
}

_semantic_rank_context_fallback() {
    local desc="$1"
    local dir="$2"
    local max="$3"

    # ファイル拡張子ベースの簡易ランキング
    local files='[]'
    if [[ -d "$dir" ]]; then
        files=$(find "$dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.py" -o -name "*.prisma" \) \
            -not -path "*/node_modules/*" -not -path "*/.next/*" \
            -newer "$dir" 2>/dev/null | head -"$max" | \
            python3 -c "
import sys, json
files = [{'file': line.strip(), 'score': 0.5} for line in sys.stdin if line.strip()]
print(json.dumps(files))
" 2>/dev/null || echo '[]')
    fi

    echo "{\"files\":${files},\"source\":\"fallback\"}"
}

# ============================================================
# Code Pattern Analysis - コードパターン分析
# ============================================================
_semantic_analyze_patterns() {
    local project_dir="${1:-$OUTPUT_DIR}"

    if [[ "$SEMANTIC_BRIDGE_INITIALIZED" == "fallback" ]] || [[ ! -d "$project_dir" ]]; then
        echo '{"patterns":[],"consistency":0.5,"source":"fallback"}'
        return
    fi

    local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
    local python_cmd="${PYTHON_CMD:-python3}"

    "$python_cmd" -c "
import sys, json
sys.path.insert(0, '$ml_dir')
from semantic import PatternMiner
miner = PatternMiner()
result = miner.analyze_project('$project_dir')
print(json.dumps(result, ensure_ascii=False, default=str))
" 2>/dev/null || echo '{"patterns":[],"consistency":0.5,"source":"fallback"}'
}

# ============================================================
# Dependency Analysis - 依存関係分析
# ============================================================
_semantic_analyze_dependencies() {
    local project_dir="${1:-$OUTPUT_DIR}"

    if [[ "$SEMANTIC_BRIDGE_INITIALIZED" == "fallback" ]] || [[ ! -d "$project_dir" ]]; then
        echo '{"nodes":[],"edges":[],"circular":[],"source":"fallback"}'
        return
    fi

    local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
    local python_cmd="${PYTHON_CMD:-python3}"

    "$python_cmd" -c "
import sys, json
sys.path.insert(0, '$ml_dir')
from semantic import DependencyGraph
graph = DependencyGraph()
result = graph.build_from_directory('$project_dir')
print(json.dumps(result, ensure_ascii=False, default=str))
" 2>/dev/null || echo '{"nodes":[],"edges":[],"circular":[],"source":"fallback"}'
}

# ============================================================
# Complexity Analysis - 複雑度分析
# ============================================================
_semantic_analyze_complexity() {
    local file_path="$1"

    if [[ "$SEMANTIC_BRIDGE_INITIALIZED" == "fallback" ]] || [[ ! -f "$file_path" ]]; then
        echo '{"cyclomatic":1,"cognitive":1,"nesting_depth":0,"source":"fallback"}'
        return
    fi

    local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
    local python_cmd="${PYTHON_CMD:-python3}"

    "$python_cmd" -c "
import sys, json
sys.path.insert(0, '$ml_dir')
from semantic import ComplexityAnalyzer
analyzer = ComplexityAnalyzer()
result = analyzer.analyze_file('$file_path')
print(json.dumps(result, ensure_ascii=False, default=str))
" 2>/dev/null || echo '{"cyclomatic":1,"cognitive":1,"nesting_depth":0,"source":"fallback"}'
}

# ============================================================
# Semantic Code Search - 意味的コード検索
# ============================================================
_semantic_search() {
    local query="$1"
    local project_dir="${2:-$OUTPUT_DIR}"
    local max_results="${3:-10}"

    if [[ "$SEMANTIC_BRIDGE_INITIALIZED" == "fallback" ]] || [[ ! -d "$project_dir" ]]; then
        # Fallback: grep-based search
        local results
        results=$(grep -rn --include="*.ts" --include="*.tsx" --include="*.js" --include="*.py" \
            -l "$query" "$project_dir" 2>/dev/null | head -"$max_results" | \
            python3 -c "
import sys, json
files = [{'file': l.strip(), 'score': 0.5, 'method': 'grep'} for l in sys.stdin if l.strip()]
print(json.dumps(files))
" 2>/dev/null || echo '[]')
        echo "{\"results\":${results},\"source\":\"fallback\"}"
        return
    fi

    local ml_dir="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
    local python_cmd="${PYTHON_CMD:-python3}"

    _SOL_INPUT="$query" "$python_cmd" -c "
import sys, json, os
sys.path.insert(0, '$ml_dir')
from semantic import SemanticSearch
search = SemanticSearch()
search.index_project('$project_dir')
result = search.search(os.environ.get('_SOL_INPUT', ''), max_results=$max_results)
print(json.dumps(result, ensure_ascii=False, default=str))
" 2>/dev/null || echo '{"results":[],"source":"fallback"}'
}

# ============================================================
# Unified Semantic Analysis - 統合分析
# ============================================================
_semantic_full_analysis() {
    local description="$1"
    local project_dir="${2:-$OUTPUT_DIR}"

    _log_info "semantic-bridge: Running full semantic analysis..."

    local intent_json
    intent_json=$(_semantic_parse_intent "$description")

    local domain
    domain=$(echo "$intent_json" | python3 -c "import sys,json;print(json.load(sys.stdin).get('domain','GENERAL'))" 2>/dev/null || echo "GENERAL")

    local requirements_json
    requirements_json=$(_semantic_analyze_requirements "$description" "$domain")

    local context_json=""
    if [[ -d "$project_dir" ]]; then
        context_json=$(_semantic_rank_context "$description" "$project_dir")
    fi

    # Merge results
    cat <<EOF
{
    "version": "${SEMANTIC_BRIDGE_VERSION}",
    "intent": ${intent_json},
    "requirements": ${requirements_json},
    "context": ${context_json:-"{}"},
    "domain": "${domain}"
}
EOF

    _log_info "semantic-bridge: Full analysis complete (domain=${domain})"
}

# ============================================================
# Module Registry Integration
# ============================================================
_semantic_bridge_score() {
    echo "95"  # High capability score
}

_semantic_bridge_report() {
    local status="active"
    [[ "$SEMANTIC_BRIDGE_INITIALIZED" == "fallback" ]] && status="fallback"
    [[ "$SEMANTIC_BRIDGE_INITIALIZED" == "false" ]] && status="disabled"
    echo "semantic-bridge: v${SEMANTIC_BRIDGE_VERSION} [${status}] intent-parsing+requirement-analysis+context-ranking+pattern-mining+dependency-graph+semantic-search"
}

# Self-register with Module Registry
if declare -f _mr_register &>/dev/null; then
    _mr_register \
        --name "semantic-bridge" \
        --version "$SEMANTIC_BRIDGE_VERSION" \
        --description "Semantic Intelligence Bridge" \
        --init "_semantic_bridge_init" \
        --report "_semantic_bridge_report" \
        --score "_semantic_bridge_score"
fi

# v2003.1: source時のexit codeを確実に0にする
true
