#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v295.0 - Email System Generator
# =============================================================================
# メールサービス自動生成。SendGrid/SES/Resend対応、HTMLテンプレート、
# メールキュー(信頼性確保)を生成する。
#
# 機能一覧:
#   _esg_generate_email_service - メールサービス生成
#   _esg_generate_templates     - メールテンプレート生成
#   _esg_generate_queue         - メールキュー生成
#
# 全globals: ESG_ prefix
# =============================================================================

[[ -n "${_ESG_LOADED:-}" ]] && return 0; _ESG_LOADED=1

declare -g ESG_VERSION="295.0"
declare -g ESG_GENERATED=0
declare -g ESG_ERRORS=0
declare -g ESG_FILES_WRITTEN=0

esg_init() { ESG_GENERATED=0; ESG_ERRORS=0; ESG_FILES_WRITTEN=0; return 0; }

_esg_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then ESG_FILES_WRITTEN=$((ESG_FILES_WRITTEN + 1)); echo "  [esg] wrote: $filepath" >&2
    else ESG_ERRORS=$((ESG_ERRORS + 1)); fi
}

_esg_log() { echo -e "  ${GREEN:-\033[0;32m}[ESG]${NC:-\033[0m} $*" >&2; }

# =============================================================================
# _esg_generate_email_service
# =============================================================================
_esg_generate_email_service() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _esg_log "Generating email service..."

    local email_ts
    email_ts=$(cat <<'EMAILEOF'
// =============================================================================
// Email Service - Multi-provider email abstraction
// Supports: Resend, SendGrid, SES, SMTP (Nodemailer)
// =============================================================================
import { z } from 'zod';

export const EmailSchema = z.object({
  to: z.union([z.string().email(), z.array(z.string().email())]),
  subject: z.string().min(1).max(200),
  html: z.string().optional(),
  text: z.string().optional(),
  from: z.string().email().optional(),
  replyTo: z.string().email().optional(),
  cc: z.array(z.string().email()).optional(),
  bcc: z.array(z.string().email()).optional(),
  attachments: z.array(z.object({
    filename: z.string(),
    content: z.union([z.string(), z.instanceof(Buffer)]),
    contentType: z.string().optional(),
  })).optional(),
});
export type EmailInput = z.infer<typeof EmailSchema>;

export interface EmailResult {
  success: boolean;
  messageId?: string;
  error?: string;
}

export interface EmailProvider {
  send(email: EmailInput): Promise<EmailResult>;
}

// --- Resend Provider ---
export class ResendProvider implements EmailProvider {
  async send(email: EmailInput): Promise<EmailResult> {
    try {
      const { Resend } = await import('resend');
      const resend = new Resend(process.env.RESEND_API_KEY);
      const result = await resend.emails.send({
        from: email.from || process.env.EMAIL_FROM || 'noreply@example.com',
        to: Array.isArray(email.to) ? email.to : [email.to],
        subject: email.subject,
        html: email.html,
        text: email.text,
      });
      return { success: true, messageId: (result as any).data?.id };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }
}

// --- Nodemailer Provider (SMTP) ---
export class SmtpProvider implements EmailProvider {
  async send(email: EmailInput): Promise<EmailResult> {
    try {
      const nodemailer = await import('nodemailer');
      const transport = nodemailer.createTransport({
        host: process.env.SMTP_HOST || 'localhost',
        port: parseInt(process.env.SMTP_PORT || '587'),
        secure: process.env.SMTP_SECURE === 'true',
        auth: { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS },
      });
      const info = await transport.sendMail({
        from: email.from || process.env.EMAIL_FROM,
        to: Array.isArray(email.to) ? email.to.join(',') : email.to,
        subject: email.subject,
        html: email.html,
        text: email.text,
        cc: email.cc?.join(','),
        bcc: email.bcc?.join(','),
      });
      return { success: true, messageId: info.messageId };
    } catch (err: any) {
      return { success: false, error: err.message };
    }
  }
}

export function createEmailProvider(): EmailProvider {
  const provider = process.env.EMAIL_PROVIDER || 'smtp';
  switch (provider) {
    case 'resend': return new ResendProvider();
    default: return new SmtpProvider();
  }
}

// --- Convenience function ---
export async function sendEmail(input: EmailInput): Promise<EmailResult> {
  const validated = EmailSchema.parse(input);
  const provider = createEmailProvider();
  return provider.send(validated);
}
EMAILEOF
)
    _esg_write_file "${project_dir}/src/lib/email/service.ts" "$email_ts"
    ESG_GENERATED=$((ESG_GENERATED + 1))
    return 0
}

# =============================================================================
# _esg_generate_templates
# =============================================================================
_esg_generate_templates() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _esg_log "Generating email templates..."

    local tmpl_ts
    tmpl_ts=$(cat <<'TMPLEOF'
// =============================================================================
// Email Templates - HTML + text versions with variable substitution
// =============================================================================

export interface EmailTemplate {
  name: string;
  subject: string;
  html: string;
  text: string;
}

function renderTemplate(template: string, vars: Record<string, string>): string {
  let result = template;
  for (const [key, value] of Object.entries(vars)) {
    result = result.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), value);
  }
  return result;
}

const templates: Record<string, EmailTemplate> = {
  welcome: {
    name: 'welcome',
    subject: '{{appName}}へようこそ！',
    html: `<div style="font-family:sans-serif;max-width:600px;margin:0 auto"><h1>{{appName}}へようこそ！</h1><p>{{userName}}さん、ご登録ありがとうございます。</p><a href="{{dashboardUrl}}" style="background:#2563eb;color:#fff;padding:12px 24px;text-decoration:none;border-radius:6px;display:inline-block">ダッシュボードへ</a></div>`,
    text: '{{appName}}へようこそ！\n\n{{userName}}さん、ご登録ありがとうございます。\n\nダッシュボード: {{dashboardUrl}}',
  },
  passwordReset: {
    name: 'passwordReset',
    subject: 'パスワードリセットのご案内',
    html: `<div style="font-family:sans-serif;max-width:600px;margin:0 auto"><h1>パスワードリセット</h1><p>以下のリンクからパスワードをリセットしてください（30分間有効）。</p><a href="{{resetUrl}}" style="background:#dc2626;color:#fff;padding:12px 24px;text-decoration:none;border-radius:6px;display:inline-block">パスワードをリセット</a><p style="color:#666;font-size:12px">このメールに心当たりがない場合は無視してください。</p></div>`,
    text: 'パスワードリセット\n\n以下のリンクからパスワードをリセットしてください（30分間有効）。\n{{resetUrl}}',
  },
  orderConfirmation: {
    name: 'orderConfirmation',
    subject: '注文確認 #{{orderId}}',
    html: `<div style="font-family:sans-serif;max-width:600px;margin:0 auto"><h1>ご注文ありがとうございます</h1><p>注文番号: #{{orderId}}</p><p>合計: {{total}}</p><a href="{{orderUrl}}" style="background:#2563eb;color:#fff;padding:12px 24px;text-decoration:none;border-radius:6px;display:inline-block">注文詳細を確認</a></div>`,
    text: 'ご注文ありがとうございます\n\n注文番号: #{{orderId}}\n合計: {{total}}\n\n注文詳細: {{orderUrl}}',
  },
  invoice: {
    name: 'invoice',
    subject: '請求書 #{{invoiceNumber}}',
    html: `<div style="font-family:sans-serif;max-width:600px;margin:0 auto"><h1>請求書</h1><p>請求番号: #{{invoiceNumber}}</p><p>金額: {{amount}}</p><p>お支払期限: {{dueDate}}</p><a href="{{invoiceUrl}}" style="background:#2563eb;color:#fff;padding:12px 24px;text-decoration:none;border-radius:6px;display:inline-block">請求書を表示</a></div>`,
    text: '請求書\n\n請求番号: #{{invoiceNumber}}\n金額: {{amount}}\nお支払期限: {{dueDate}}\n\n請求書: {{invoiceUrl}}',
  },
};

export function getTemplate(name: string): EmailTemplate | undefined { return templates[name]; }

export function renderEmail(templateName: string, vars: Record<string, string>): { subject: string; html: string; text: string } {
  const tmpl = templates[templateName];
  if (!tmpl) throw new Error(`Template not found: ${templateName}`);
  return {
    subject: renderTemplate(tmpl.subject, vars),
    html: renderTemplate(tmpl.html, vars),
    text: renderTemplate(tmpl.text, vars),
  };
}

export function listTemplates(): string[] { return Object.keys(templates); }
TMPLEOF
)
    _esg_write_file "${project_dir}/src/lib/email/templates.ts" "$tmpl_ts"
    ESG_GENERATED=$((ESG_GENERATED + 1))
    return 0
}

# =============================================================================
# _esg_generate_queue
# =============================================================================
_esg_generate_queue() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _esg_log "Generating email queue..."

    local queue_ts
    queue_ts=$(cat <<'QEOF'
// =============================================================================
// Email Queue - Reliable email delivery with retry
// =============================================================================
import { sendEmail, EmailInput } from './service';
import { renderEmail } from './templates';

interface QueuedEmail {
  id: string;
  input: EmailInput;
  attempts: number;
  maxAttempts: number;
  status: 'pending' | 'sending' | 'sent' | 'failed';
  error?: string;
  createdAt: Date;
  sentAt?: Date;
}

const emailQueue: QueuedEmail[] = [];
let processing = false;

export function enqueueEmail(input: EmailInput, maxAttempts = 3): string {
  const id = crypto.randomUUID();
  emailQueue.push({ id, input, attempts: 0, maxAttempts, status: 'pending', createdAt: new Date() });
  processQueue(); // trigger processing
  return id;
}

export function enqueueTemplatedEmail(templateName: string, vars: Record<string, string>, to: string, maxAttempts = 3): string {
  const { subject, html, text } = renderEmail(templateName, vars);
  return enqueueEmail({ to, subject, html, text }, maxAttempts);
}

async function processQueue(): Promise<void> {
  if (processing) return;
  processing = true;

  while (true) {
    const pending = emailQueue.find((e) => e.status === 'pending');
    if (!pending) break;

    pending.status = 'sending';
    pending.attempts++;

    const result = await sendEmail(pending.input);
    if (result.success) {
      pending.status = 'sent';
      pending.sentAt = new Date();
    } else {
      pending.error = result.error;
      if (pending.attempts >= pending.maxAttempts) {
        pending.status = 'failed';
        console.error(`[email-queue] Failed permanently: ${pending.id} (${pending.error})`);
      } else {
        pending.status = 'pending';
        // Exponential backoff: wait before retrying
        await new Promise((r) => setTimeout(r, 1000 * Math.pow(2, pending.attempts)));
      }
    }
  }

  processing = false;
}

export function getQueueStats(): { pending: number; sending: number; sent: number; failed: number } {
  return {
    pending: emailQueue.filter((e) => e.status === 'pending').length,
    sending: emailQueue.filter((e) => e.status === 'sending').length,
    sent: emailQueue.filter((e) => e.status === 'sent').length,
    failed: emailQueue.filter((e) => e.status === 'failed').length,
  };
}
QEOF
)
    _esg_write_file "${project_dir}/src/lib/email/queue.ts" "$queue_ts"
    ESG_GENERATED=$((ESG_GENERATED + 1))
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
esg_report() {
    echo -e "\n  ${BOLD:-}=== email-system-generator v${ESG_VERSION} ===${NC:-}"
    echo -e "  生成数: ${ESG_GENERATED}"; echo -e "  エラー: ${ESG_ERRORS}"
}

esg_score() {
    if [[ ${ESG_GENERATED} -ge 3 ]] && [[ ${ESG_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${ESG_GENERATED} -gt 0 ]] && [[ ${ESG_ERRORS} -eq 0 ]]; then echo "85"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "email-system-generator" --version "${ESG_VERSION}" \
        --description "メールサービス×テンプレート×キュー×Resend/SMTP" \
        --init "esg_init" --report "esg_report" --score "esg_score" \
        --enable-var "ENABLE_EMAIL_SYSTEM" --cli-flags "--email-system:--no-email-system"
fi

# v2003.1: source時のexit codeを確実に0にする
true
