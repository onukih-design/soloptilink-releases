#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v210.0 - Multi-Project Context
# =============================================================================
# ワークスペース内の複数プロジェクトを横断的に解析し、共通パターン・
# 共有ライブラリ・プロジェクト間依存関係を検出・同期する。
#
# 機能:
#   - ワークスペース内の兄弟プロジェクトスキャン
#   - プロジェクト間の共通パターン検出（命名規約/構造/技術スタック）
#   - 共有ライブラリ・パッケージの検出
#   - プロジェクト間依存関係マッピング
#   - コーディングパターンの同期
#   - プロンプト注入用コンテキスト生成
#
# 全globals: MPC_ prefix
# =============================================================================

[[ -n "${_MPC_LOADED:-}" ]] && return 0; _MPC_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g MPC_VERSION="210.0"
declare -g MPC_INITIALIZED=false
declare -g MPC_ERRORS=0
declare -g MPC_PHASE="multi_project_context"
declare -g MPC_STORAGE_DIR="${HOME}/.soloptilink/multi-project"
declare -g MPC_PROJECTS_FOUND=0
declare -g MPC_SHARED_PATTERNS=0
declare -g MPC_SHARED_LIBS=0
declare -g MPC_CROSS_DEPS=0
declare -g MPC_SYNCED_PATTERNS=0

# =============================================================================
# 初期化
# =============================================================================
mpc_init() {
    MPC_INITIALIZED=true
    MPC_ERRORS=0
    MPC_PROJECTS_FOUND=0
    MPC_SHARED_PATTERNS=0
    MPC_SHARED_LIBS=0
    MPC_CROSS_DEPS=0
    MPC_SYNCED_PATTERNS=0

    mkdir -p "${MPC_STORAGE_DIR}/projects" 2>/dev/null
    mkdir -p "${MPC_STORAGE_DIR}/patterns" 2>/dev/null
    mkdir -p "${MPC_STORAGE_DIR}/sync" 2>/dev/null

    return 0
}

# =============================================================================
# Internal: プロジェクト検出ヒューリスティック
# =============================================================================
_mpc_is_project_dir() {
    local dir="$1"
    # package.json, Cargo.toml, go.mod, requirements.txt, pyproject.toml, etc.
    [[ -f "${dir}/package.json" ]] && return 0
    [[ -f "${dir}/Cargo.toml" ]] && return 0
    [[ -f "${dir}/go.mod" ]] && return 0
    [[ -f "${dir}/requirements.txt" ]] && return 0
    [[ -f "${dir}/pyproject.toml" ]] && return 0
    [[ -f "${dir}/pom.xml" ]] && return 0
    [[ -f "${dir}/build.gradle" ]] && return 0
    [[ -f "${dir}/Gemfile" ]] && return 0
    [[ -f "${dir}/composer.json" ]] && return 0
    [[ -f "${dir}/pubspec.yaml" ]] && return 0
    return 1
}

# =============================================================================
# Internal: プロジェクトの技術スタック検出
# =============================================================================
_mpc_detect_tech_stack() {
    local dir="$1"
    local stack=""

    # フレームワーク検出
    if [[ -f "${dir}/package.json" ]]; then
        local pkg_content
        pkg_content=$(cat "${dir}/package.json" 2>/dev/null)

        if echo "$pkg_content" | grep -q '"next"'; then
            stack+="nextjs,"
        fi
        if echo "$pkg_content" | grep -q '"react"'; then
            stack+="react,"
        fi
        if echo "$pkg_content" | grep -q '"vue"'; then
            stack+="vue,"
        fi
        if echo "$pkg_content" | grep -q '"express"'; then
            stack+="express,"
        fi
        if echo "$pkg_content" | grep -q '"prisma"'; then
            stack+="prisma,"
        fi
        if echo "$pkg_content" | grep -q '"typescript"'; then
            stack+="typescript,"
        fi
        if echo "$pkg_content" | grep -q '"tailwindcss"'; then
            stack+="tailwind,"
        fi
        if echo "$pkg_content" | grep -q '"drizzle-orm"'; then
            stack+="drizzle,"
        fi
    fi

    if [[ -f "${dir}/Cargo.toml" ]]; then
        stack+="rust,"
    fi
    if [[ -f "${dir}/go.mod" ]]; then
        stack+="go,"
    fi
    if [[ -f "${dir}/requirements.txt" || -f "${dir}/pyproject.toml" ]]; then
        stack+="python,"
    fi

    # 末尾カンマ削除
    echo "${stack%,}"
}

# =============================================================================
# Internal: プロジェクト名取得
# =============================================================================
_mpc_get_project_name() {
    local dir="$1"
    if [[ -f "${dir}/package.json" ]]; then
        local name
        name=$(grep -oE '"name"[[:space:]]*:[[:space:]]*"[^"]*"' "${dir}/package.json" 2>/dev/null | head -1 | sed 's/"name"[[:space:]]*:[[:space:]]*"//;s/"//')
        [[ -n "$name" ]] && echo "$name" && return
    fi
    basename "$dir"
}

# =============================================================================
# ワークスペーススキャン: 兄弟プロジェクト検出
# =============================================================================
_mpc_scan_workspace() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    [[ "$MPC_INITIALIZED" != "true" ]] && mpc_init

    # ワークスペースルート: プロジェクトの親ディレクトリ
    local workspace_dir
    workspace_dir=$(dirname "$project_dir")

    echo "[multi-project-context] Scanning workspace: ${workspace_dir}"

    local projects_json='{"workspace":"'"${workspace_dir}"'","projects":['
    local first=true
    MPC_PROJECTS_FOUND=0

    # 直下のディレクトリをスキャン
    while IFS= read -r dir; do
        [[ -z "$dir" ]] && continue
        [[ ! -d "$dir" ]] && continue
        [[ "$(basename "$dir")" == "node_modules" ]] && continue
        [[ "$(basename "$dir")" == ".git" ]] && continue
        [[ "$(basename "$dir")" == ".next" ]] && continue
        [[ "$(basename "$dir")" == "dist" ]] && continue
        [[ "$(basename "$dir")" == ".soloptilink" ]] && continue

        if _mpc_is_project_dir "$dir"; then
            local proj_name
            proj_name=$(_mpc_get_project_name "$dir")
            local tech_stack
            tech_stack=$(_mpc_detect_tech_stack "$dir")
            local file_count
            file_count=$(find "$dir" \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" -o -name "*.py" -o -name "*.go" -o -name "*.rs" \) 2>/dev/null | grep -v node_modules | grep -v '.next' | wc -l | tr -d ' ')
            local has_prisma="false"
            [[ -f "${dir}/prisma/schema.prisma" ]] && has_prisma="true"
            local has_tests="false"
            [[ -d "${dir}/tests" || -d "${dir}/__tests__" || -d "${dir}/test" ]] && has_tests="true"

            [[ "$first" == "true" ]] && first=false || projects_json+=","
            projects_json+='{"name":"'"${proj_name}"'","path":"'"${dir}"'","tech_stack":"'"${tech_stack}"'","file_count":'"${file_count}"',"has_prisma":'"${has_prisma}"',"has_tests":'"${has_tests}"'}'

            MPC_PROJECTS_FOUND=$((MPC_PROJECTS_FOUND + 1))

            # 個別プロジェクト情報を保存
            local proj_key
            proj_key=$(echo "$proj_name" | sed 's/[^a-zA-Z0-9_-]/_/g')
            cat > "${MPC_STORAGE_DIR}/projects/${proj_key}.json" <<PROJ_EOF
{
  "name": "${proj_name}",
  "path": "${dir}",
  "tech_stack": "${tech_stack}",
  "file_count": ${file_count},
  "has_prisma": ${has_prisma},
  "has_tests": ${has_tests},
  "scanned_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
PROJ_EOF
        fi
    done < <(find "$workspace_dir" -maxdepth 1 -type d 2>/dev/null | sort)

    # monorepo内のpackagesもスキャン
    for packages_dir in "${workspace_dir}/packages" "${project_dir}/packages"; do
        [[ ! -d "$packages_dir" ]] && continue
        while IFS= read -r dir; do
            [[ -z "$dir" ]] && continue
            [[ ! -d "$dir" ]] && continue
            if _mpc_is_project_dir "$dir"; then
                local proj_name
                proj_name=$(_mpc_get_project_name "$dir")
                local tech_stack
                tech_stack=$(_mpc_detect_tech_stack "$dir")
                local file_count
                file_count=$(find "$dir" \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" \) 2>/dev/null | grep -v node_modules | wc -l | tr -d ' ')

                [[ "$first" == "true" ]] && first=false || projects_json+=","
                projects_json+='{"name":"'"${proj_name}"'","path":"'"${dir}"'","tech_stack":"'"${tech_stack}"'","file_count":'"${file_count}"',"monorepo_package":true}'

                MPC_PROJECTS_FOUND=$((MPC_PROJECTS_FOUND + 1))
            fi
        done < <(find "$packages_dir" -maxdepth 1 -type d 2>/dev/null | sort)
    done

    projects_json+='],"total_projects":'"${MPC_PROJECTS_FOUND}"'}'

    echo "$projects_json" > "${MPC_STORAGE_DIR}/workspace.json"
    echo "[multi-project-context] Found ${MPC_PROJECTS_FOUND} projects in workspace"
    echo "$projects_json"
}

# =============================================================================
# 共通パターン検出
# =============================================================================
_mpc_find_shared_patterns() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    [[ "$MPC_INITIALIZED" != "true" ]] && mpc_init

    # ワークスペースをスキャン済みでなければスキャン
    [[ ! -f "${MPC_STORAGE_DIR}/workspace.json" ]] && _mpc_scan_workspace "$project_dir" >/dev/null

    echo "[multi-project-context] Analyzing shared patterns..."

    local patterns_json='{"patterns":['
    local first=true
    MPC_SHARED_PATTERNS=0

    # 各プロジェクトのパターンを収集
    declare -A _mpc_dir_structures
    declare -A _mpc_naming_conventions
    declare -A _mpc_config_patterns
    declare -A _mpc_tech_stacks

    while IFS= read -r proj_file; do
        [[ -z "$proj_file" ]] && continue
        local proj_path
        proj_path=$(grep -oE '"path":"[^"]*"' "$proj_file" 2>/dev/null | sed 's/"path":"//;s/"//')
        [[ -z "$proj_path" || ! -d "$proj_path" ]] && continue

        local proj_name
        proj_name=$(grep -oE '"name":"[^"]*"' "$proj_file" 2>/dev/null | sed 's/"name":"//;s/"//')

        # ディレクトリ構造パターン
        local structure=""
        [[ -d "${proj_path}/src" ]] && structure+="src,"
        [[ -d "${proj_path}/app" ]] && structure+="app,"
        [[ -d "${proj_path}/lib" ]] && structure+="lib,"
        [[ -d "${proj_path}/components" ]] && structure+="components,"
        [[ -d "${proj_path}/utils" ]] && structure+="utils,"
        [[ -d "${proj_path}/hooks" ]] && structure+="hooks,"
        [[ -d "${proj_path}/types" ]] && structure+="types,"
        [[ -d "${proj_path}/services" ]] && structure+="services,"
        [[ -d "${proj_path}/middleware" ]] && structure+="middleware,"
        structure="${structure%,}"
        _mpc_dir_structures["$proj_name"]="$structure"

        # 命名規約検出
        local naming=""
        # kebab-case ファイル
        local kebab_count
        kebab_count=$(find "$proj_path" -name "*-*" \( -name "*.ts" -o -name "*.tsx" \) 2>/dev/null | grep -v node_modules | wc -l | tr -d ' ')
        # camelCase ファイル
        local camel_count
        camel_count=$(find "$proj_path" -name "*[a-z][A-Z]*" \( -name "*.ts" -o -name "*.tsx" \) 2>/dev/null | grep -v node_modules | wc -l | tr -d ' ')
        # PascalCase ファイル
        local pascal_count
        pascal_count=$(find "$proj_path" -name "[A-Z]*" \( -name "*.tsx" -o -name "*.jsx" \) 2>/dev/null | grep -v node_modules | wc -l | tr -d ' ')

        if [[ $kebab_count -gt $camel_count && $kebab_count -gt $pascal_count ]]; then
            naming="kebab-case"
        elif [[ $pascal_count -gt $camel_count ]]; then
            naming="PascalCase"
        else
            naming="camelCase"
        fi
        _mpc_naming_conventions["$proj_name"]="$naming"

        # 設定パターン
        local config=""
        [[ -f "${proj_path}/tsconfig.json" ]] && config+="tsconfig,"
        [[ -f "${proj_path}/eslint.config.js" || -f "${proj_path}/.eslintrc.json" || -f "${proj_path}/.eslintrc.js" ]] && config+="eslint,"
        [[ -f "${proj_path}/prettier.config.js" || -f "${proj_path}/.prettierrc" ]] && config+="prettier,"
        [[ -f "${proj_path}/tailwind.config.ts" || -f "${proj_path}/tailwind.config.js" ]] && config+="tailwind,"
        [[ -f "${proj_path}/jest.config.ts" || -f "${proj_path}/jest.config.js" || -f "${proj_path}/vitest.config.ts" ]] && config+="testing,"
        config="${config%,}"
        _mpc_config_patterns["$proj_name"]="$config"

        local tech_stack
        tech_stack=$(grep -oE '"tech_stack":"[^"]*"' "$proj_file" 2>/dev/null | sed 's/"tech_stack":"//;s/"//')
        _mpc_tech_stacks["$proj_name"]="$tech_stack"
    done < <(find "${MPC_STORAGE_DIR}/projects" -name "*.json" 2>/dev/null | sort)

    # 共通パターンの特定
    # 1. ディレクトリ構造の共通部分
    local common_dirs=""
    local dir_candidates="src app lib components utils hooks types services"
    for dir_name in $dir_candidates; do
        local present_count=0
        local total_projects=0
        for proj in "${!_mpc_dir_structures[@]}"; do
            total_projects=$((total_projects + 1))
            if [[ "${_mpc_dir_structures[$proj]}" == *"${dir_name}"* ]]; then
                present_count=$((present_count + 1))
            fi
        done
        if [[ $total_projects -gt 1 && $present_count -gt 1 ]]; then
            common_dirs+="${dir_name}(${present_count}/${total_projects}),"
            MPC_SHARED_PATTERNS=$((MPC_SHARED_PATTERNS + 1))
        fi
    done

    if [[ -n "$common_dirs" ]]; then
        [[ "$first" == "true" ]] && first=false || patterns_json+=","
        patterns_json+='{"type":"directory_structure","shared_dirs":"'"${common_dirs%,}"'"}'
    fi

    # 2. 命名規約の統一性
    declare -A naming_counts
    for proj in "${!_mpc_naming_conventions[@]}"; do
        local conv="${_mpc_naming_conventions[$proj]}"
        naming_counts["$conv"]=$(( ${naming_counts["$conv"]:-0} + 1 ))
    done
    local dominant_naming="" dominant_count=0
    for conv in "${!naming_counts[@]}"; do
        if [[ ${naming_counts[$conv]} -gt $dominant_count ]]; then
            dominant_naming="$conv"
            dominant_count=${naming_counts[$conv]}
        fi
    done
    if [[ -n "$dominant_naming" ]]; then
        [[ "$first" == "true" ]] && first=false || patterns_json+=","
        patterns_json+='{"type":"naming_convention","dominant":"'"${dominant_naming}"'","count":'"${dominant_count}"'}'
        MPC_SHARED_PATTERNS=$((MPC_SHARED_PATTERNS + 1))
    fi

    # 3. 共通設定ファイル
    declare -A config_counts
    for proj in "${!_mpc_config_patterns[@]}"; do
        IFS=',' read -ra configs <<< "${_mpc_config_patterns[$proj]}"
        for cfg in "${configs[@]}"; do
            [[ -z "$cfg" ]] && continue
            config_counts["$cfg"]=$(( ${config_counts["$cfg"]:-0} + 1 ))
        done
    done
    local common_configs=""
    for cfg in "${!config_counts[@]}"; do
        if [[ ${config_counts[$cfg]} -gt 1 ]]; then
            common_configs+="${cfg}(${config_counts[$cfg]}),"
            MPC_SHARED_PATTERNS=$((MPC_SHARED_PATTERNS + 1))
        fi
    done
    if [[ -n "$common_configs" ]]; then
        [[ "$first" == "true" ]] && first=false || patterns_json+=","
        patterns_json+='{"type":"config_patterns","shared":"'"${common_configs%,}"'"}'
    fi

    # 4. 技術スタックの共通部分
    declare -A stack_counts
    for proj in "${!_mpc_tech_stacks[@]}"; do
        IFS=',' read -ra techs <<< "${_mpc_tech_stacks[$proj]}"
        for tech in "${techs[@]}"; do
            [[ -z "$tech" ]] && continue
            stack_counts["$tech"]=$(( ${stack_counts["$tech"]:-0} + 1 ))
        done
    done
    local common_tech=""
    for tech in "${!stack_counts[@]}"; do
        if [[ ${stack_counts[$tech]} -gt 1 ]]; then
            common_tech+="${tech}(${stack_counts[$tech]}),"
        fi
    done
    if [[ -n "$common_tech" ]]; then
        [[ "$first" == "true" ]] && first=false || patterns_json+=","
        patterns_json+='{"type":"tech_stack","shared":"'"${common_tech%,}"'"}'
        MPC_SHARED_PATTERNS=$((MPC_SHARED_PATTERNS + 1))
    fi

    patterns_json+='],"total_patterns":'"${MPC_SHARED_PATTERNS}"'}'
    echo "$patterns_json" > "${MPC_STORAGE_DIR}/patterns/shared.json"

    echo "[multi-project-context] Found ${MPC_SHARED_PATTERNS} shared patterns"
    echo "$patterns_json"
}

# =============================================================================
# 共有ライブラリ検出
# =============================================================================
_mpc_find_shared_libs() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    [[ "$MPC_INITIALIZED" != "true" ]] && mpc_init

    [[ ! -f "${MPC_STORAGE_DIR}/workspace.json" ]] && _mpc_scan_workspace "$project_dir" >/dev/null

    echo "[multi-project-context] Finding shared libraries..."

    # 各プロジェクトの依存関係を収集
    declare -A _mpc_all_deps
    declare -A _mpc_dep_projects

    while IFS= read -r proj_file; do
        [[ -z "$proj_file" ]] && continue
        local proj_path
        proj_path=$(grep -oE '"path":"[^"]*"' "$proj_file" 2>/dev/null | sed 's/"path":"//;s/"//')
        [[ -z "$proj_path" ]] && continue

        local proj_name
        proj_name=$(grep -oE '"name":"[^"]*"' "$proj_file" 2>/dev/null | sed 's/"name":"//;s/"//')

        local pkg_json="${proj_path}/package.json"
        [[ ! -f "$pkg_json" ]] && continue

        # dependencies + devDependencies のパッケージ名を抽出
        while IFS= read -r dep_line; do
            [[ -z "$dep_line" ]] && continue
            local dep_name
            dep_name=$(echo "$dep_line" | grep -oE '"[^"]+":' | head -1 | tr -d '":')
            [[ -z "$dep_name" ]] && continue
            # @types/* など一部を除外
            [[ "$dep_name" == "@types/"* ]] && continue

            _mpc_all_deps["$dep_name"]=$(( ${_mpc_all_deps["$dep_name"]:-0} + 1 ))
            local existing_projs="${_mpc_dep_projects[$dep_name]:-}"
            _mpc_dep_projects["$dep_name"]="${existing_projs:+${existing_projs},}${proj_name}"
        done < <(grep -E '^\s+"[^"]+"\s*:\s*"[^"]*"' "$pkg_json" 2>/dev/null)
    done < <(find "${MPC_STORAGE_DIR}/projects" -name "*.json" 2>/dev/null | sort)

    # 複数プロジェクトで使用されているライブラリを検出
    local libs_json='{"shared_libraries":['
    local first=true
    MPC_SHARED_LIBS=0

    for dep in "${!_mpc_all_deps[@]}"; do
        local count=${_mpc_all_deps[$dep]}
        if [[ $count -gt 1 ]]; then
            local projects="${_mpc_dep_projects[$dep]}"
            [[ "$first" == "true" ]] && first=false || libs_json+=","
            libs_json+='{"name":"'"${dep}"'","used_by_count":'"${count}"',"projects":"'"${projects}"'"}'
            MPC_SHARED_LIBS=$((MPC_SHARED_LIBS + 1))
        fi
    done

    libs_json+='],"total_shared":'"${MPC_SHARED_LIBS}"'}'
    echo "$libs_json" > "${MPC_STORAGE_DIR}/patterns/shared-libs.json"

    echo "[multi-project-context] Found ${MPC_SHARED_LIBS} shared libraries"
    echo "$libs_json"
}

# =============================================================================
# プロジェクト間依存関係マッピング
# =============================================================================
_mpc_get_cross_project_deps() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    [[ "$MPC_INITIALIZED" != "true" ]] && mpc_init

    [[ ! -f "${MPC_STORAGE_DIR}/workspace.json" ]] && _mpc_scan_workspace "$project_dir" >/dev/null

    echo "[multi-project-context] Mapping cross-project dependencies..."

    local deps_json='{"cross_project_dependencies":['
    local first=true
    MPC_CROSS_DEPS=0

    # プロジェクトリストを取得
    declare -a project_names
    declare -A project_paths
    while IFS= read -r proj_file; do
        [[ -z "$proj_file" ]] && continue
        local pname
        pname=$(grep -oE '"name":"[^"]*"' "$proj_file" 2>/dev/null | sed 's/"name":"//;s/"//')
        local ppath
        ppath=$(grep -oE '"path":"[^"]*"' "$proj_file" 2>/dev/null | sed 's/"path":"//;s/"//')
        [[ -z "$pname" || -z "$ppath" ]] && continue
        project_names+=("$pname")
        project_paths["$pname"]="$ppath"
    done < <(find "${MPC_STORAGE_DIR}/projects" -name "*.json" 2>/dev/null | sort)

    for proj_name in "${project_names[@]}"; do
        local proj_path="${project_paths[$proj_name]}"
        [[ ! -d "$proj_path" ]] && continue

        # package.jsonで他プロジェクトへの直接依存をチェック
        local pkg_json="${proj_path}/package.json"
        if [[ -f "$pkg_json" ]]; then
            for other_name in "${project_names[@]}"; do
                [[ "$other_name" == "$proj_name" ]] && continue
                if grep -q "\"${other_name}\"" "$pkg_json" 2>/dev/null; then
                    [[ "$first" == "true" ]] && first=false || deps_json+=","
                    deps_json+='{"from":"'"${proj_name}"'","to":"'"${other_name}"'","type":"package_dependency"}'
                    MPC_CROSS_DEPS=$((MPC_CROSS_DEPS + 1))
                fi
            done
        fi

        # ファイルシステムレベルの参照をチェック（相対パスインポート）
        local workspace_dir
        workspace_dir=$(dirname "$proj_path")
        while IFS= read -r import_line; do
            [[ -z "$import_line" ]] && continue
            for other_name in "${project_names[@]}"; do
                [[ "$other_name" == "$proj_name" ]] && continue
                local other_path="${project_paths[$other_name]}"
                local other_basename
                other_basename=$(basename "$other_path")
                if echo "$import_line" | grep -qE "(\.\./${other_basename}|@${other_name})" 2>/dev/null; then
                    [[ "$first" == "true" ]] && first=false || deps_json+=","
                    deps_json+='{"from":"'"${proj_name}"'","to":"'"${other_name}"'","type":"import_reference"}'
                    MPC_CROSS_DEPS=$((MPC_CROSS_DEPS + 1))
                    break
                fi
            done
        done < <(grep -rh "from ['\"]" "$proj_path" --include='*.ts' --include='*.tsx' 2>/dev/null | grep -E '\.\./|@' | head -100)

        # 共有データベース検出（同じDB接続先）
        for other_name in "${project_names[@]}"; do
            [[ "$other_name" == "$proj_name" ]] && continue
            local other_path="${project_paths[$other_name]}"

            # .envファイルでDATABASE_URLが同じかチェック
            if [[ -f "${proj_path}/.env" && -f "${other_path}/.env" ]]; then
                local db_url_1
                db_url_1=$(grep "DATABASE_URL" "${proj_path}/.env" 2>/dev/null | head -1)
                local db_url_2
                db_url_2=$(grep "DATABASE_URL" "${other_path}/.env" 2>/dev/null | head -1)
                if [[ -n "$db_url_1" && "$db_url_1" == "$db_url_2" ]]; then
                    [[ "$first" == "true" ]] && first=false || deps_json+=","
                    deps_json+='{"from":"'"${proj_name}"'","to":"'"${other_name}"'","type":"shared_database"}'
                    MPC_CROSS_DEPS=$((MPC_CROSS_DEPS + 1))
                fi
            fi
        done
    done

    deps_json+='],"total_dependencies":'"${MPC_CROSS_DEPS}"'}'
    echo "$deps_json" > "${MPC_STORAGE_DIR}/patterns/cross-deps.json"

    echo "[multi-project-context] Found ${MPC_CROSS_DEPS} cross-project dependencies"
    echo "$deps_json"
}

# =============================================================================
# パターン同期
# =============================================================================
_mpc_sync_patterns() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    [[ "$MPC_INITIALIZED" != "true" ]] && mpc_init

    echo "[multi-project-context] Generating pattern sync recommendations..."

    # まず共通パターンを検出
    [[ ! -f "${MPC_STORAGE_DIR}/patterns/shared.json" ]] && _mpc_find_shared_patterns "$project_dir" >/dev/null

    local sync_json='{"sync_recommendations":['
    local first=true
    MPC_SYNCED_PATTERNS=0

    # 各プロジェクトの設定を比較して同期推奨を生成
    while IFS= read -r proj_file; do
        [[ -z "$proj_file" ]] && continue
        local proj_path
        proj_path=$(grep -oE '"path":"[^"]*"' "$proj_file" 2>/dev/null | sed 's/"path":"//;s/"//')
        local proj_name
        proj_name=$(grep -oE '"name":"[^"]*"' "$proj_file" 2>/dev/null | sed 's/"name":"//;s/"//')
        [[ -z "$proj_path" || ! -d "$proj_path" ]] && continue

        # tsconfig strict mode チェック
        if [[ -f "${proj_path}/tsconfig.json" ]]; then
            if ! grep -q '"strict"[[:space:]]*:[[:space:]]*true' "${proj_path}/tsconfig.json" 2>/dev/null; then
                [[ "$first" == "true" ]] && first=false || sync_json+=","
                sync_json+='{"project":"'"${proj_name}"'","recommendation":"enable_strict_mode","details":"tsconfig.json に strict: true を追加","priority":"high"}'
                MPC_SYNCED_PATTERNS=$((MPC_SYNCED_PATTERNS + 1))
            fi
        fi

        # ESLint 設定の欠如チェック
        if [[ ! -f "${proj_path}/.eslintrc.json" && ! -f "${proj_path}/.eslintrc.js" && ! -f "${proj_path}/eslint.config.js" && ! -f "${proj_path}/eslint.config.mjs" ]]; then
            if [[ -f "${proj_path}/package.json" ]] && grep -q '"typescript"' "${proj_path}/package.json" 2>/dev/null; then
                [[ "$first" == "true" ]] && first=false || sync_json+=","
                sync_json+='{"project":"'"${proj_name}"'","recommendation":"add_eslint","details":"ESLint設定ファイルがない。他プロジェクトと統一した設定を追加","priority":"medium"}'
                MPC_SYNCED_PATTERNS=$((MPC_SYNCED_PATTERNS + 1))
            fi
        fi

        # Prettier 設定の欠如チェック
        if [[ ! -f "${proj_path}/.prettierrc" && ! -f "${proj_path}/prettier.config.js" && ! -f "${proj_path}/.prettierrc.json" ]]; then
            [[ "$first" == "true" ]] && first=false || sync_json+=","
            sync_json+='{"project":"'"${proj_name}"'","recommendation":"add_prettier","details":"Prettier設定がない。コードフォーマット統一のために追加","priority":"low"}'
            MPC_SYNCED_PATTERNS=$((MPC_SYNCED_PATTERNS + 1))
        fi

        # バージョン不一致検出（React/Nextのメジャーバージョン）
        if [[ -f "${proj_path}/package.json" ]]; then
            local next_ver
            next_ver=$(grep -oE '"next"[[:space:]]*:[[:space:]]*"[^"]*"' "${proj_path}/package.json" 2>/dev/null | grep -oE '[0-9]+\.' | head -1)
            local react_ver
            react_ver=$(grep -oE '"react"[[:space:]]*:[[:space:]]*"[^"]*"' "${proj_path}/package.json" 2>/dev/null | grep -oE '[0-9]+\.' | head -1)

            # 他プロジェクトとバージョン比較
            while IFS= read -r other_proj_file; do
                [[ "$other_proj_file" == "$proj_file" ]] && continue
                local other_path
                other_path=$(grep -oE '"path":"[^"]*"' "$other_proj_file" 2>/dev/null | sed 's/"path":"//;s/"//')
                [[ -z "$other_path" || ! -f "${other_path}/package.json" ]] && continue

                if [[ -n "$next_ver" ]]; then
                    local other_next
                    other_next=$(grep -oE '"next"[[:space:]]*:[[:space:]]*"[^"]*"' "${other_path}/package.json" 2>/dev/null | grep -oE '[0-9]+\.' | head -1)
                    if [[ -n "$other_next" && "$next_ver" != "$other_next" ]]; then
                        local other_name
                        other_name=$(grep -oE '"name":"[^"]*"' "$other_proj_file" 2>/dev/null | sed 's/"name":"//;s/"//')
                        [[ "$first" == "true" ]] && first=false || sync_json+=","
                        sync_json+='{"project":"'"${proj_name}"'","recommendation":"sync_next_version","details":"Next.js バージョン不一致: '"${proj_name}"'=v'"${next_ver}"'x vs '"${other_name}"'=v'"${other_next}"'x","priority":"high"}'
                        MPC_SYNCED_PATTERNS=$((MPC_SYNCED_PATTERNS + 1))
                        break
                    fi
                fi
            done < <(find "${MPC_STORAGE_DIR}/projects" -name "*.json" 2>/dev/null | sort)
        fi
    done < <(find "${MPC_STORAGE_DIR}/projects" -name "*.json" 2>/dev/null | sort)

    sync_json+='],"total_recommendations":'"${MPC_SYNCED_PATTERNS}"'}'
    echo "$sync_json" > "${MPC_STORAGE_DIR}/sync/recommendations.json"

    echo "[multi-project-context] Generated ${MPC_SYNCED_PATTERNS} sync recommendations"
    echo "$sync_json"
}

# =============================================================================
# 全解析実行
# =============================================================================
mpc_build_context() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    echo "[multi-project-context] Building multi-project context..."
    _mpc_scan_workspace "$project_dir" >/dev/null
    _mpc_find_shared_patterns "$project_dir" >/dev/null
    _mpc_find_shared_libs "$project_dir" >/dev/null
    _mpc_get_cross_project_deps "$project_dir" >/dev/null
    _mpc_sync_patterns "$project_dir" >/dev/null
    echo "[multi-project-context] Complete: ${MPC_PROJECTS_FOUND} projects, ${MPC_SHARED_PATTERNS} patterns, ${MPC_SHARED_LIBS} shared libs, ${MPC_CROSS_DEPS} cross-deps"
}

# =============================================================================
# プロンプト注入
# =============================================================================
mpc_inject_context() {
    local prompt="${1:-}"
    local project_dir="${2:-${PROJECT_DIR:-./output}}"

    local workspace_data=""
    [[ -f "${MPC_STORAGE_DIR}/workspace.json" ]] && workspace_data=$(cat "${MPC_STORAGE_DIR}/workspace.json" 2>/dev/null)
    local patterns_data=""
    [[ -f "${MPC_STORAGE_DIR}/patterns/shared.json" ]] && patterns_data=$(cat "${MPC_STORAGE_DIR}/patterns/shared.json" 2>/dev/null)

    cat <<INJECTION

## [Multi-Project Context] ワークスペース横断コンテキスト

### ワークスペース構造:
${workspace_data:-No workspace data yet}

### 共通パターン:
${patterns_data:-No patterns detected yet}

### ルール:
1. **命名規約統一**: ワークスペース内の他プロジェクトと同じ命名規約を使用
2. **共有ライブラリ**: 既に他プロジェクトで使用中のライブラリを優先的に採用
3. **設定統一**: tsconfig/eslint/prettierは他プロジェクトの設定をベースに
4. **DB共有時**: 同じデータベースを共有する場合、スキーマ変更の影響を全プロジェクトで検討
5. **バージョン統一**: フレームワークのメジャーバージョンをワークスペース内で揃える
INJECTION

    echo "$prompt"
}

# =============================================================================
# レポート & スコア
# =============================================================================
mpc_report() {
    echo -e "\n  ${BOLD:-}=== multi-project-context v${MPC_VERSION} ===${NC:-}"
    echo -e "  検出プロジェクト数 : ${MPC_PROJECTS_FOUND}"
    echo -e "  共有パターン       : ${MPC_SHARED_PATTERNS}"
    echo -e "  共有ライブラリ     : ${MPC_SHARED_LIBS}"
    echo -e "  プロジェクト間依存 : ${MPC_CROSS_DEPS}"
    echo -e "  同期推奨           : ${MPC_SYNCED_PATTERNS}"
    echo -e "  エラー             : ${MPC_ERRORS}"
}

mpc_score() {
    if [[ ${MPC_PROJECTS_FOUND} -ge 2 ]] && [[ ${MPC_ERRORS} -eq 0 ]]; then
        if [[ ${MPC_SHARED_PATTERNS} -gt 5 ]]; then
            echo "95"
        elif [[ ${MPC_SHARED_PATTERNS} -gt 0 ]]; then
            echo "85"
        else
            echo "75"
        fi
    elif [[ ${MPC_PROJECTS_FOUND} -gt 0 ]] && [[ ${MPC_ERRORS} -eq 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "multi-project-context" --version "210.0" \
        --description "ワークスペース横断解析×共通パターン検出×依存マッピング" \
        --init "mpc_init" --report "mpc_report" --score "mpc_score" \
        --enable-var "ENABLE_MULTI_PROJECT_CONTEXT" \
        --cli-flags "--multi-project-context:--no-multi-project-context"
fi

# v2003.1: source時のexit codeを確実に0にする
true
