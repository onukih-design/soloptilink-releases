#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v309.0 - Inventory System Generator
# =============================================================================
# 在庫管理システム自動生成: 商品モデル/在庫追跡/発注/バーコード
#
# 全globals: ISG_ prefix
# =============================================================================

[[ -n "${_INVENTORY_SYSTEM_GENERATOR_LOADED:-}" ]] && return 0
_INVENTORY_SYSTEM_GENERATOR_LOADED=1

declare -g ISG_VERSION="309.0"
declare -g ISG_INITIALIZED=false
declare -g ISG_GENERATED_COUNT=0
declare -g ENABLE_INVENTORY_SYSTEM_GENERATOR="${ENABLE_INVENTORY_SYSTEM_GENERATOR:-true}"

readonly ISG_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly ISG_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly ISG_BOLD="${CLR_BOLD:-\033[1m}"
readonly ISG_NC="${CLR_NC:-\033[0m}"

_isg_log() { echo -e "  ${ISG_CYAN}[ISG]${ISG_NC} $*" >&2; }
_isg_ok()  { echo -e "  ${ISG_GREEN}[ISG] OK${ISG_NC} $*" >&2; }

isg_init() { ISG_INITIALIZED=true; ISG_GENERATED_COUNT=0; return 0; }
isg_report() { [[ "$ISG_INITIALIZED" != "true" ]] && return 0; echo -e "\n  ${ISG_BOLD}--- Inventory System Generator v${ISG_VERSION} ---${ISG_NC}" >&2; echo -e "  生成数: ${ISG_GENERATED_COUNT}" >&2; }
isg_score() { [[ "$ISG_INITIALIZED" != "true" ]] && { echo "0"; return; }; local s=50; [[ $ISG_GENERATED_COUNT -ge 3 ]] && s=85; echo "$s"; }
isg_init_message() { echo -e "  ${ISG_GREEN}v${ISG_VERSION} inventory-system-generator: 在庫管理自動生成${ISG_NC}" >&2; }

# =============================================================================
# _isg_generate_product_model() - Product/item model
# =============================================================================
_isg_generate_product_model() {
    local project_dir="${1:-.}"
    _isg_log "在庫商品モデル生成"

    local snippet='
// --- Inventory System Models (v309.0) ---
model InventoryItem {
  id           String   @id @default(cuid())
  name         String
  sku          String   @unique
  barcode      String?  @unique
  description  String?
  category     String?
  unit         String   @default("pcs")
  costPrice    Int?
  sellPrice    Int?
  stock        Int      @default(0)
  reservedStock Int     @default(0)
  minStock     Int      @default(10)
  maxStock     Int?
  location     String?
  supplierId   String?
  movements    StockMovement[]
  purchaseOrderItems PurchaseOrderItem[]
  imageUrl     String?
  isActive     Boolean  @default(true)
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt
}

model StockMovement {
  id        String   @id @default(cuid())
  itemId    String
  item      InventoryItem @relation(fields: [itemId], references: [id], onDelete: Cascade)
  type      MovementType
  quantity  Int
  reference String?
  note      String?
  userId    String?
  createdAt DateTime @default(now())
}

enum MovementType { IN OUT ADJUSTMENT TRANSFER RETURN }

model PurchaseOrder {
  id         String   @id @default(cuid())
  orderNo    String   @unique
  supplierId String?
  status     POStatus @default(DRAFT)
  items      PurchaseOrderItem[]
  totalAmount Int     @default(0)
  notes      String?
  orderedAt  DateTime?
  receivedAt DateTime?
  createdAt  DateTime @default(now())
  updatedAt  DateTime @updatedAt
}

enum POStatus { DRAFT SUBMITTED APPROVED ORDERED PARTIALLY_RECEIVED RECEIVED CANCELLED }

model PurchaseOrderItem {
  id             String        @id @default(cuid())
  purchaseOrderId String
  purchaseOrder  PurchaseOrder @relation(fields: [purchaseOrderId], references: [id], onDelete: Cascade)
  itemId         String
  item           InventoryItem @relation(fields: [itemId], references: [id])
  quantity       Int
  unitPrice      Int
  receivedQty    Int           @default(0)
}'

    mkdir -p "${project_dir}/prisma"
    local schema_file="${project_dir}/prisma/schema.prisma"
    if [[ -f "$schema_file" ]] && ! grep -q "model InventoryItem" "$schema_file" 2>/dev/null; then
        echo "$snippet" >> "$schema_file"
    fi

    ISG_GENERATED_COUNT=$((ISG_GENERATED_COUNT + 1))
    _isg_ok "在庫商品モデル生成完了"
    return 0
}

# =============================================================================
# _isg_generate_stock_tracking() - Stock level tracking
# =============================================================================
_isg_generate_stock_tracking() {
    local project_dir="${1:-.}"
    _isg_log "在庫追跡API生成"

    local api_dir="${project_dir}/src/app/api/inventory"
    mkdir -p "${api_dir}/movements"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const search = req.nextUrl.searchParams.get('search') || '';
    const lowStock = req.nextUrl.searchParams.get('lowStock') === 'true';
    const category = req.nextUrl.searchParams.get('category');

    const where: any = { isActive: true };
    if (search) where.OR = [{ name: { contains: search } }, { sku: { contains: search } }, { barcode: { contains: search } }];
    if (category) where.category = category;

    let items = await prisma.inventoryItem.findMany({ where, orderBy: { name: 'asc' } });
    if (lowStock) items = items.filter((i: any) => i.stock <= i.minStock);

    const totalItems = items.length;
    const lowStockCount = items.filter((i: any) => i.stock <= i.minStock).length;
    const totalValue = items.reduce((sum: number, i: any) => sum + (i.stock * (i.costPrice || 0)), 0);

    return NextResponse.json({ data: items, totalItems, lowStockCount, totalValue });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch inventory' }, { status: 500 });
  }
}
EOF

    cat > "${api_dir}/movements/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest) {
  try {
    const { itemId, type, quantity, reference, note, userId } = await req.json();
    if (!itemId || !type || quantity === undefined) return NextResponse.json({ error: 'itemId, type, quantity required' }, { status: 400 });

    const result = await prisma.$transaction(async (tx) => {
      const movement = await tx.stockMovement.create({ data: { itemId, type, quantity, reference, note, userId } });
      const adjustment = ['IN', 'RETURN'].includes(type) ? quantity : -Math.abs(quantity);
      await tx.inventoryItem.update({ where: { id: itemId }, data: { stock: { increment: adjustment } } });
      return movement;
    });
    return NextResponse.json(result, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to record movement' }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const itemId = req.nextUrl.searchParams.get('itemId');
    const where: any = {};
    if (itemId) where.itemId = itemId;
    const movements = await prisma.stockMovement.findMany({
      where, include: { item: { select: { name: true, sku: true } } },
      orderBy: { createdAt: 'desc' }, take: 100,
    });
    return NextResponse.json({ data: movements });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch movements' }, { status: 500 });
  }
}
EOF

    ISG_GENERATED_COUNT=$((ISG_GENERATED_COUNT + 2))
    _isg_ok "在庫追跡API生成完了"
    return 0
}

# =============================================================================
# _isg_generate_purchase_order() - Purchase order generation
# =============================================================================
_isg_generate_purchase_order() {
    local project_dir="${1:-.}"
    _isg_log "発注管理生成"

    local api_dir="${project_dir}/src/app/api/inventory/purchase-orders"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

function generateOrderNo() {
  const d = new Date();
  return `PO-${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}${String(d.getDate()).padStart(2,'0')}-${Math.random().toString(36).substr(2,4).toUpperCase()}`;
}

export async function GET() {
  try {
    const orders = await prisma.purchaseOrder.findMany({
      include: { items: { include: { item: { select: { name: true, sku: true } } } } },
      orderBy: { createdAt: 'desc' },
    });
    return NextResponse.json({ data: orders });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch purchase orders' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { supplierId, items, notes } = await req.json();
    if (!items?.length) return NextResponse.json({ error: 'items required' }, { status: 400 });

    const totalAmount = items.reduce((s: number, i: any) => s + i.quantity * i.unitPrice, 0);
    const order = await prisma.purchaseOrder.create({
      data: {
        orderNo: generateOrderNo(),
        supplierId,
        notes,
        totalAmount,
        items: { create: items.map((i: any) => ({ itemId: i.itemId, quantity: i.quantity, unitPrice: i.unitPrice })) },
      },
      include: { items: true },
    });
    return NextResponse.json(order, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create purchase order' }, { status: 500 });
  }
}
EOF

    ISG_GENERATED_COUNT=$((ISG_GENERATED_COUNT + 1))
    _isg_ok "発注管理生成完了"
    return 0
}

# =============================================================================
# _isg_generate_barcode() - Barcode scanning integration
# =============================================================================
_isg_generate_barcode() {
    local project_dir="${1:-.}"
    _isg_log "バーコード連携生成"

    local comp_dir="${project_dir}/src/components/inventory"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/BarcodeScanner.tsx" <<'EOF'
'use client';
import { useState, useRef, useEffect } from 'react';
import { Camera, X, Search } from 'lucide-react';

interface BarcodeScannerProps {
  onScan: (barcode: string) => void;
  placeholder?: string;
}

export function BarcodeScanner({ onScan, placeholder = 'バーコードをスキャンまたは入力' }: BarcodeScannerProps) {
  const [manualInput, setManualInput] = useState('');
  const [scanning, setScanning] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);
  const bufferRef = useRef('');
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  // Listen for barcode scanner keyboard input (rapid keypresses)
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (document.activeElement === inputRef.current) return;

      if (e.key === 'Enter' && bufferRef.current.length >= 4) {
        onScan(bufferRef.current);
        bufferRef.current = '';
        return;
      }

      if (e.key.length === 1) {
        bufferRef.current += e.key;
        if (timerRef.current) clearTimeout(timerRef.current);
        timerRef.current = setTimeout(() => { bufferRef.current = ''; }, 100);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [onScan]);

  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (manualInput.trim()) { onScan(manualInput.trim()); setManualInput(''); }
  };

  return (
    <div className="space-y-3">
      <form onSubmit={handleManualSubmit} className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
          <input ref={inputRef} value={manualInput} onChange={e => setManualInput(e.target.value)}
            placeholder={placeholder} className="w-full pl-9 pr-4 py-2 border rounded-lg text-sm focus:ring-2 focus:ring-blue-500 focus:outline-none" />
        </div>
        <button type="submit" className="bg-blue-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-blue-700">検索</button>
      </form>
      <p className="text-xs text-gray-400">バーコードリーダーで直接スキャン、またはコードを手入力してください</p>
    </div>
  );
}
EOF

    ISG_GENERATED_COUNT=$((ISG_GENERATED_COUNT + 1))
    _isg_ok "バーコード連携生成完了"
    return 0
}

# =============================================================================
# Module Registration
# =============================================================================
_mr_register \
    --name "inventory-system-generator" \
    --version "309.0" \
    --description "在庫管理システム自動生成（商品/在庫追跡/発注/バーコード）" \
    --init "isg_init" \
    --report "isg_report" \
    --score "isg_score" \
    --enable-var "ENABLE_INVENTORY_SYSTEM_GENERATOR" \
    --cli-flags "--inventory:--no-inventory" \
    --init-msg "isg_init_message"
