#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v433.0 - API Response Optimizer
# =============================================================================
# APIレスポンスの最適化エンジン。ペイロード最適化、ページネーション追加、
# フィールド選択（sparse fieldsets）の実装を自動化する。
#
# Functions:
#   _aro_init()                  - 初期化
#   _aro_optimize_payload()      - ペイロード最適化分析
#   _aro_add_pagination()        - ページネーション追加検出
#   _aro_add_field_selection()   - フィールド選択追加
#   _aro_report() / _aro_score()
#
# All globals use the ARO_ prefix.
# =============================================================================

[[ -n "${_ARO_LOADED:-}" ]] && return 0; _ARO_LOADED=1

declare -g ARO_VERSION="433.0"
declare -g ARO_GENERATED=0
declare -g ARO_ERRORS=0
declare -g ARO_ENDPOINTS_SCANNED=0
declare -g ARO_MISSING_PAGINATION=0
declare -g ARO_OVERSIZED_RESPONSES=0
declare -g ARO_MISSING_FIELD_SELECT=0
declare -g ARO_OPTIMIZATIONS=0

declare -ga _ARO_FINDINGS=()

_ARO_GREEN="${GREEN:-\033[0;32m}"
_ARO_RED="${RED:-\033[0;31m}"
_ARO_YELLOW="${YELLOW:-\033[0;33m}"
_ARO_CYAN="${CYAN:-\033[0;36m}"
_ARO_BOLD="${BOLD:-\033[1m}"
_ARO_NC="${NC:-\033[0m}"

_aro_init() {
    ARO_GENERATED=0; ARO_ERRORS=0; ARO_ENDPOINTS_SCANNED=0
    ARO_MISSING_PAGINATION=0; ARO_OVERSIZED_RESPONSES=0
    ARO_MISSING_FIELD_SELECT=0; ARO_OPTIMIZATIONS=0
    _ARO_FINDINGS=()
    return 0
}

_aro_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_ARO_CYAN}[ARO]${_ARO_NC} $*" >&2 ;;
        ok)    echo -e "  ${_ARO_GREEN}[ARO]${_ARO_NC} $*" >&2 ;;
        warn)  echo -e "  ${_ARO_YELLOW}[ARO]${_ARO_NC} $*" >&2 ;;
        error) echo -e "  ${_ARO_RED}[ARO]${_ARO_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _aro_optimize_payload - ペイロード最適化分析
# =============================================================================
_aro_optimize_payload() {
    local project_dir="${1:-.}"
    _aro_log info "APIペイロード最適化分析"

    ARO_ENDPOINTS_SCANNED=0
    ARO_OVERSIZED_RESPONSES=0

    # API routeファイルを走査
    while IFS= read -r -d '' file; do
        ARO_ENDPOINTS_SCANNED=$((ARO_ENDPOINTS_SCANNED + 1))
        local rel="${file#${project_dir}/}"

        # NextResponse.jsonで大量データを返している箇所
        local returns_all
        returns_all=$(grep -n "NextResponse.json\|Response.json\|res.json\|res.send" "$file" 2>/dev/null)

        while IFS= read -r match; do
            [[ -z "$match" ]] && continue
            local line_num="${match%%:*}"
            local context
            context=$(sed -n "$((line_num > 5 ? line_num - 5 : 1)),$((line_num + 2))p" "$file" 2>/dev/null)

            # findManyの結果を直接返している場合
            if [[ "$context" == *"findMany"* ]] && [[ "$context" != *"select"* ]]; then
                ARO_OVERSIZED_RESPONSES=$((ARO_OVERSIZED_RESPONSES + 1))
                _ARO_FINDINGS+=("OVERSIZED:${rel}:${line_num}:findMany without select returns all fields")
                _aro_log warn "過大レスポンス: ${rel}:${line_num} (selectなしfindMany)"
            fi

            # パスワード等の機密フィールドを含む可能性
            if [[ "$context" == *"password"* ]] || [[ "$context" == *"secret"* ]] || [[ "$context" == *"token"* ]]; then
                if [[ "$context" != *"omit"* ]] && [[ "$context" != *"select"* ]] && [[ "$context" != *"exclude"* ]]; then
                    _ARO_FINDINGS+=("SENSITIVE_LEAK:${rel}:${line_num}:potential sensitive field in response")
                    _aro_log error "機密情報漏洩リスク: ${rel}:${line_num}"
                fi
            fi
        done <<< "$returns_all"
    done < <(find "$project_dir" \( -name "route.ts" -o -name "route.js" -o -name "*.controller.ts" \) \
             -not -path "*/node_modules/*" -print0 2>/dev/null)

    ARO_GENERATED=$((ARO_GENERATED + 1))
    _aro_log ok "ペイロード分析: ${ARO_ENDPOINTS_SCANNED}エンドポイント, ${ARO_OVERSIZED_RESPONSES}件過大"
    return 0
}

# =============================================================================
# _aro_add_pagination - ページネーション追加検出
# =============================================================================
_aro_add_pagination() {
    local project_dir="${1:-.}"
    _aro_log info "ページネーション不足検出"

    ARO_MISSING_PAGINATION=0

    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"

        # GET + findMany でページネーションなし
        local has_get
        has_get=$(grep -c "GET\|export.*get\b" "$file" 2>/dev/null || echo 0)
        [[ $has_get -eq 0 ]] && continue

        local has_findmany
        has_findmany=$(grep -c "findMany" "$file" 2>/dev/null || echo 0)
        [[ $has_findmany -eq 0 ]] && continue

        local has_pagination
        has_pagination=$(grep -c "skip\|take\|page\|limit\|offset\|cursor" "$file" 2>/dev/null || echo 0)

        if [[ $has_pagination -eq 0 ]]; then
            ARO_MISSING_PAGINATION=$((ARO_MISSING_PAGINATION + 1))
            _ARO_FINDINGS+=("NO_PAGINATION:${rel}:0:GET endpoint with findMany but no pagination")
            _aro_log warn "ページネーション不足: ${rel}"
        fi
    done < <(find "$project_dir" \( -name "route.ts" -o -name "route.js" \) \
             -not -path "*/node_modules/*" -print0 2>/dev/null)

    ARO_GENERATED=$((ARO_GENERATED + 1))
    _aro_log ok "ページネーション: ${ARO_MISSING_PAGINATION}件不足"
    return 0
}

# =============================================================================
# _aro_add_field_selection - フィールド選択追加
# =============================================================================
_aro_add_field_selection() {
    local project_dir="${1:-.}"
    _aro_log info "フィールド選択（sparse fieldsets）分析"

    ARO_MISSING_FIELD_SELECT=0

    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"

        # findMany/findUniqueでselectなし
        local queries_without_select
        queries_without_select=$(grep -n "findMany\|findUnique\|findFirst" "$file" 2>/dev/null)

        while IFS= read -r match; do
            [[ -z "$match" ]] && continue
            local line_num="${match%%:*}"
            local context
            context=$(sed -n "${line_num},$((line_num + 10))p" "$file" 2>/dev/null)

            if [[ "$context" != *"select:"* ]] && [[ "$context" != *"select :"* ]]; then
                ARO_MISSING_FIELD_SELECT=$((ARO_MISSING_FIELD_SELECT + 1))
                _ARO_FINDINGS+=("NO_FIELD_SELECT:${rel}:${line_num}:query without select clause")
            fi
        done <<< "$queries_without_select"
    done < <(find "$project_dir" \( -name "route.ts" -o -name "*.service.ts" -o -name "*.controller.ts" \) \
             -not -path "*/node_modules/*" -print0 2>/dev/null)

    ARO_OPTIMIZATIONS=$((ARO_MISSING_PAGINATION + ARO_OVERSIZED_RESPONSES + ARO_MISSING_FIELD_SELECT))
    ARO_GENERATED=$((ARO_GENERATED + 1))
    _aro_log ok "フィールド選択不足: ${ARO_MISSING_FIELD_SELECT}件"
    return 0
}

# =============================================================================
# _aro_generate_pagination_snippet - ページネーションコードスニペット生成
# =============================================================================
_aro_generate_pagination_snippet() {
    cat <<'SNIPPET'
// Cursor-based pagination (recommended)
const page = parseInt(searchParams.get('page') || '1');
const limit = Math.min(parseInt(searchParams.get('limit') || '20'), 100);
const skip = (page - 1) * limit;

const [items, total] = await prisma.$transaction([
  prisma.model.findMany({
    skip,
    take: limit,
    orderBy: { createdAt: 'desc' },
    select: { id: true, name: true, createdAt: true },
  }),
  prisma.model.count(),
]);

return NextResponse.json({
  data: items,
  pagination: {
    page,
    limit,
    total,
    totalPages: Math.ceil(total / limit),
    hasNext: page * limit < total,
  },
});
SNIPPET
}

# =============================================================================
# Report & Score
# =============================================================================
_aro_report() {
    echo -e "\n  ${_ARO_BOLD}=== api-response-optimizer v${ARO_VERSION} ===${_ARO_NC}"
    echo -e "  エンドポイント  : ${ARO_ENDPOINTS_SCANNED}"
    echo -e "  過大レスポンス  : ${ARO_OVERSIZED_RESPONSES}"
    echo -e "  ページネーション不足: ${ARO_MISSING_PAGINATION}"
    echo -e "  フィールド選択不足: ${ARO_MISSING_FIELD_SELECT}"
    echo -e "  最適化提案      : ${ARO_OPTIMIZATIONS}"
    echo -e "  エラー          : ${ARO_ERRORS}"
}

_aro_score() {
    local score=50
    [[ ${ARO_ENDPOINTS_SCANNED} -gt 0 ]] && score=$((score + 10))
    [[ ${ARO_MISSING_PAGINATION} -eq 0 ]] && score=$((score + 15))
    [[ ${ARO_OVERSIZED_RESPONSES} -eq 0 ]] && score=$((score + 10))
    [[ ${ARO_MISSING_FIELD_SELECT} -eq 0 ]] && score=$((score + 10))
    [[ ${ARO_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "api-response-optimizer" --version "${ARO_VERSION}" \
        --description "APIレスポンス最適化×ページネーション×フィールド選択 (v433)" \
        --init "_aro_init" --report "_aro_report" --score "_aro_score" \
        --enable-var "ENABLE_API_RESP_OPT" --cli-flags "--api-resp-opt:--no-api-resp-opt"
fi

# v2003.1: source時のexit codeを確実に0にする
true
