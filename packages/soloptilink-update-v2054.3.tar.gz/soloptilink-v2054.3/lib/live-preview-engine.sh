#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v408.0 - Live Preview Engine
# =============================================================================
# 生成コードのリアルタイムプレビュー・ホットリロード・変更同期を統合。
# 開発サーバー管理・ファイル監視・ブラウザ同期を自動化する。
#
# Functions:
#   _lpe_init          - 初期化
#   _lpe_start_preview - プレビューサーバー起動
#   _lpe_hot_reload    - ホットリロード設定生成
#   _lpe_sync_changes  - ファイル変更同期
#   _lpe_report        - レポート出力
#   _lpe_score         - モジュールスコア(0-100)
#
# All globals use the LPE_ prefix.
# =============================================================================

[[ -n "${_LIVE_PREVIEW_ENGINE_LOADED:-}" ]] && return 0
_LIVE_PREVIEW_ENGINE_LOADED=1

declare -g LPE_VERSION="408.0"
declare -g LPE_INITIALIZED=false
declare -g LPE_STORE_DIR=""
declare -g LPE_PREVIEW_COUNT=0
declare -g LPE_RELOAD_COUNT=0
declare -g LPE_SYNC_COUNT=0
declare -g LPE_SERVER_PID=""
declare -g LPE_SERVER_PORT=3000

declare -g -A _LPE_WATCHED_FILES=()   # file_path → last_modified
declare -g -A _LPE_SERVER_CONFIG=()    # config_key → value
declare -g -a _LPE_CHANGE_QUEUE=()    # pending changes

# =============================================================================
_lpe_init() {
    local project_dir="${PROJECT_DIR:-.}"
    LPE_STORE_DIR="${project_dir}/.soloptilink/live-preview"
    mkdir -p "${LPE_STORE_DIR}/snapshots" "${LPE_STORE_DIR}/logs"

    _LPE_SERVER_CONFIG["framework"]="nextjs"
    _LPE_SERVER_CONFIG["port"]="3000"
    _LPE_SERVER_CONFIG["host"]="localhost"
    _LPE_SERVER_CONFIG["hot_reload"]="true"

    # Detect framework
    if [[ -f "${project_dir}/next.config.js" || -f "${project_dir}/next.config.mjs" || -f "${project_dir}/next.config.ts" ]]; then
        _LPE_SERVER_CONFIG["framework"]="nextjs"
        _LPE_SERVER_CONFIG["start_cmd"]="npx next dev"
    elif [[ -f "${project_dir}/vite.config.ts" || -f "${project_dir}/vite.config.js" ]]; then
        _LPE_SERVER_CONFIG["framework"]="vite"
        _LPE_SERVER_CONFIG["start_cmd"]="npx vite"
        _LPE_SERVER_CONFIG["port"]="5173"
    elif [[ -f "${project_dir}/package.json" ]]; then
        local has_dev
        has_dev=$(grep -c '"dev"' "${project_dir}/package.json" 2>/dev/null || echo "0")
        if [[ $has_dev -gt 0 ]]; then
            _LPE_SERVER_CONFIG["start_cmd"]="npm run dev"
        fi
    fi

    LPE_INITIALIZED=true
    return 0
}

# =============================================================================
# _lpe_start_preview - Start preview development server
# =============================================================================
_lpe_start_preview() {
    local project_dir="${1:-${PROJECT_DIR:-.}}"
    local port="${2:-${_LPE_SERVER_CONFIG[port]:-3000}}"
    local background="${3:-true}"

    [[ "$LPE_INITIALIZED" != "true" ]] && { echo "ERROR: LPE not initialized" >&2; return 1; }
    LPE_PREVIEW_COUNT=$((LPE_PREVIEW_COUNT + 1))

    local framework="${_LPE_SERVER_CONFIG[framework]:-nextjs}"
    local start_cmd="${_LPE_SERVER_CONFIG[start_cmd]:-npm run dev}"
    LPE_SERVER_PORT=$port

    # Check if port is already in use
    if command -v lsof &>/dev/null; then
        local port_pid
        port_pid=$(lsof -ti ":${port}" 2>/dev/null | head -1)
        if [[ -n "$port_pid" ]]; then
            echo "WARNING: Port ${port} already in use (PID: ${port_pid})" >&2
            echo "existing:${port_pid}:${port}"
            return 0
        fi
    fi

    # Generate preview config
    local config_file="${LPE_STORE_DIR}/preview-config.json"
    cat > "$config_file" 2>/dev/null <<CFGEOF
{
  "framework": "${framework}",
  "port": ${port},
  "host": "localhost",
  "hot_reload": true,
  "open_browser": false,
  "started_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || echo '2026-01-01T00:00:00Z')"
}
CFGEOF

    if [[ "$background" == "true" ]]; then
        echo "Starting preview server: ${start_cmd} (port ${port})" >&2
        cd "$project_dir" 2>/dev/null && \
            PORT=$port $start_cmd > "${LPE_STORE_DIR}/logs/server.log" 2>&1 &
        LPE_SERVER_PID=$!
        echo "started:${LPE_SERVER_PID}:${port}"
    else
        echo "cmd:${start_cmd}:${port}"
    fi

    return 0
}

# =============================================================================
# _lpe_hot_reload - Generate hot reload configuration
# =============================================================================
_lpe_hot_reload() {
    local framework="${1:-${_LPE_SERVER_CONFIG[framework]:-nextjs}}"
    local project_dir="${2:-${PROJECT_DIR:-.}}"

    LPE_RELOAD_COUNT=$((LPE_RELOAD_COUNT + 1))

    case "$framework" in
        nextjs)
            cat <<'NHREOF'
// next.config.mjs - Hot Reload Configuration
/** @type {import('next').NextConfig} */
const nextConfig = {
  reactStrictMode: true,
  experimental: {
    // Turbopack for faster HMR
    turbo: {
      rules: {
        '*.svg': { loaders: ['@svgr/webpack'], as: '*.js' },
      },
    },
  },
  webpack: (config, { dev, isServer }) => {
    if (dev && !isServer) {
      // Fast refresh settings
      config.watchOptions = {
        poll: 1000,
        aggregateTimeout: 300,
        ignored: ['**/node_modules', '**/.git', '**/.next'],
      };
    }
    return config;
  },
};

export default nextConfig;
NHREOF
            ;;
        vite)
            cat <<'VHREOF'
// vite.config.ts - Hot Reload Configuration
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    hmr: {
      overlay: true,
      timeout: 5000,
    },
    watch: {
      usePolling: false,
      interval: 100,
    },
  },
  optimizeDeps: {
    include: ['react', 'react-dom'],
  },
});
VHREOF
            ;;
    esac
    return 0
}

# =============================================================================
# _lpe_sync_changes - Sync file changes and trigger reload
# =============================================================================
_lpe_sync_changes() {
    local project_dir="${1:-${PROJECT_DIR:-.}}"
    local watch_patterns="${2:-*.tsx,*.ts,*.css}"

    [[ "$LPE_INITIALIZED" != "true" ]] && { echo "ERROR: LPE not initialized" >&2; return 1; }
    LPE_SYNC_COUNT=$((LPE_SYNC_COUNT + 1))

    local changes_detected=0

    # Scan for changed files
    IFS=',' read -ra patterns <<< "$watch_patterns"
    for pattern in "${patterns[@]}"; do
        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            local mod_time
            mod_time=$(stat -f %m "$file" 2>/dev/null || stat -c %Y "$file" 2>/dev/null || echo "0")
            local last_known="${_LPE_WATCHED_FILES[$file]:-0}"

            if [[ "$mod_time" != "$last_known" ]]; then
                _LPE_WATCHED_FILES["$file"]="$mod_time"
                if [[ "$last_known" != "0" ]]; then
                    changes_detected=$((changes_detected + 1))
                    _LPE_CHANGE_QUEUE+=("${file}")
                    echo "Changed: ${file}" >&2
                fi
            fi
        done < <(find "$project_dir" -name "$pattern" -not -path "*/node_modules/*" -not -path "*/.next/*" -not -path "*/.git/*" 2>/dev/null | head -100)
    done

    # Process change queue
    if [[ ${#_LPE_CHANGE_QUEUE[@]} -gt 0 ]]; then
        # Take snapshot
        local snapshot_file="${LPE_STORE_DIR}/snapshots/snap_$(date +%s 2>/dev/null || echo '0').json"
        echo "{\"changes\":${#_LPE_CHANGE_QUEUE[@]},\"files\":[" > "$snapshot_file" 2>/dev/null
        local first=true
        for f in "${_LPE_CHANGE_QUEUE[@]}"; do
            [[ "$first" != "true" ]] && echo "," >> "$snapshot_file" 2>/dev/null
            echo "\"${f}\"" >> "$snapshot_file" 2>/dev/null
            first=false
        done
        echo "]}" >> "$snapshot_file" 2>/dev/null

        # Clear queue
        _LPE_CHANGE_QUEUE=()
    fi

    echo "${changes_detected}"
    return 0
}

# =============================================================================
# _lpe_stop_preview - Stop the preview server
# =============================================================================
_lpe_stop_preview() {
    if [[ -n "$LPE_SERVER_PID" ]]; then
        kill "$LPE_SERVER_PID" 2>/dev/null
        wait "$LPE_SERVER_PID" 2>/dev/null
        echo "Stopped preview server (PID: ${LPE_SERVER_PID})" >&2
        LPE_SERVER_PID=""
    fi
    return 0
}

# =============================================================================
# Report / Score
# =============================================================================
_lpe_report() {
    echo -e "\n  ${BOLD:-}=== Live Preview Engine v${LPE_VERSION} ===${NC:-}"
    echo -e "  Previews Started  : ${LPE_PREVIEW_COUNT}"
    echo -e "  Hot Reloads       : ${LPE_RELOAD_COUNT}"
    echo -e "  Syncs             : ${LPE_SYNC_COUNT}"
    echo -e "  Watched Files     : ${#_LPE_WATCHED_FILES[@]}"
    echo -e "  Framework         : ${_LPE_SERVER_CONFIG[framework]:-unknown}"
    [[ -n "$LPE_SERVER_PID" ]] && echo -e "  Server PID        : ${LPE_SERVER_PID} (port ${LPE_SERVER_PORT})"
}

_lpe_score() {
    local score=30
    [[ "$LPE_INITIALIZED" == "true" ]] && score=$((score + 20))
    [[ $LPE_PREVIEW_COUNT -gt 0 ]] && score=$((score + 20))
    [[ $LPE_SYNC_COUNT -gt 0 ]] && score=$((score + 15))
    [[ -n "${_LPE_SERVER_CONFIG[start_cmd]:-}" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "live-preview-engine" \
        --version "408.0" \
        --description "リアルタイムプレビュー・ホットリロード・変更同期" \
        --init "_lpe_init" \
        --report "_lpe_report" \
        --score "_lpe_score" \
        --enable-var "ENABLE_LPE" \
        --cli-flags "--live-preview:--no-live-preview"
fi

# v2003.1: source時のexit codeを確実に0にする
true
