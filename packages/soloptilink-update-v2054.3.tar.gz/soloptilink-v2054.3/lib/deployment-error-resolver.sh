#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v274.0 - Deployment Error Resolver
# =============================================================================
# Vercel/Docker/AWSデプロイメントエラーを自動解析・修正。
# ビルド出力設定、環境変数不足、プラットフォーム固有の問題を検出・解決。
#
# Functions:
#   _der_init             - 初期化
#   _der_fix_vercel_error - Vercelデプロイエラー修正
#   _der_fix_docker_error - Dockerビルド/実行エラー修正
#   _der_fix_aws_error    - AWSデプロイエラー修正
#   _der_fix_env_missing  - 環境変数不足修正
#   _der_fix_build_output - ビルド出力設定修正
#   _der_report           - レポート出力
#   _der_score            - スコア算出(0-100)
#
# All globals use the DER_ prefix.
# =============================================================================

[[ -n "${_DEPLOYMENT_ERROR_RESOLVER_LOADED:-}" ]] && return 0
_DEPLOYMENT_ERROR_RESOLVER_LOADED=1

DER_VERSION="274.0"
DER_INITIALIZED=false
ENABLE_DER="${ENABLE_DER:-true}"

# Counters
DER_VERCEL_FIXES=0
DER_DOCKER_FIXES=0
DER_AWS_FIXES=0
DER_ENV_FIXES=0
DER_BUILD_FIXES=0
DER_TOTAL_FIXES=0
DER_TOTAL_SCANS=0

# Storage
DER_WORK_DIR=""
declare -g -a _DER_FIX_LOG=()
declare -g -a _DER_WARNINGS=()

# Known error patterns
declare -g -A _DER_VERCEL_PATTERNS=(
    ["FUNCTION_INVOCATION_TIMEOUT"]="increase maxDuration in vercel.json or optimize function"
    ["EDGE_FUNCTION_INVOCATION"]="check edge runtime compatibility - avoid Node.js APIs"
    ["BUILD_UTILS_SPAWN"]="check build command and node version in vercel.json"
    ["SERVERLESS_FUNCTION_CRASHED"]="check memory limits and cold start optimization"
    ["MODULE_NOT_FOUND"]="check imports and ensure dependencies are in package.json"
    ["NO_RESPONSE"]="ensure API route returns a Response object"
    ["FUNCTION_PAYLOAD_TOO_LARGE"]="reduce response size or use streaming"
)

declare -g -A _DER_DOCKER_PATTERNS=(
    ["COPY failed"]="check file paths and .dockerignore"
    ["npm ERR! code ENOENT"]="ensure package.json exists in build context"
    ["ENOMEM"]="increase Docker memory limit"
    ["port is already allocated"]="change host port mapping"
    ["no matching manifest"]="check platform and architecture"
    ["Cannot find module"]="ensure multi-stage build copies node_modules"
    ["HEALTHCHECK"]="verify health endpoint is accessible"
)

declare -g -A _DER_AWS_PATTERNS=(
    ["AccessDenied"]="check IAM role permissions"
    ["InvalidParameterValue"]="validate environment variables and config"
    ["ResourceNotFoundException"]="ensure resource exists in the correct region"
    ["ThrottlingException"]="implement exponential backoff"
    ["ServiceException"]="check service health and retry"
    ["ValidationException"]="check parameter types and constraints"
)

# =============================================================================
# _der_init
# =============================================================================
_der_init() {
    DER_WORK_DIR="${HOME}/.soloptilink/deploy-resolver"
    mkdir -p "$DER_WORK_DIR" 2>/dev/null || true

    DER_VERCEL_FIXES=0
    DER_DOCKER_FIXES=0
    DER_AWS_FIXES=0
    DER_ENV_FIXES=0
    DER_BUILD_FIXES=0
    DER_TOTAL_FIXES=0
    DER_TOTAL_SCANS=0
    _DER_FIX_LOG=()
    _DER_WARNINGS=()

    DER_INITIALIZED=true
    return 0
}

# =============================================================================
# _der_fix_vercel_error - Fix Vercel deployment errors
# Usage: _der_fix_vercel_error <project_dir> <error_log>
# =============================================================================
_der_fix_vercel_error() {
    [[ "$DER_INITIALIZED" != "true" ]] && _der_init
    local project_dir="${1:-.}"
    local error_log="${2:-}"
    DER_TOTAL_SCANS=$((DER_TOTAL_SCANS + 1))

    echo -e "  ${CYAN:-}[DER] Analyzing Vercel deployment error...${NC:-}" >&2

    local vercel_json="${project_dir}/vercel.json"

    # If error_log provided, match against known patterns
    if [[ -n "$error_log" ]]; then
        for pattern in "${!_DER_VERCEL_PATTERNS[@]}"; do
            if echo "$error_log" | grep -q "$pattern"; then
                local fix="${_DER_VERCEL_PATTERNS[$pattern]}"
                _DER_FIX_LOG+=("[Vercel] ${pattern}: ${fix}")
                echo -e "  ${YELLOW:-}[DER] Matched: ${pattern}${NC:-}" >&2
                echo -e "  ${GREEN:-}[DER] Fix: ${fix}${NC:-}" >&2
            fi
        done
    fi

    # Check vercel.json
    if [[ ! -f "$vercel_json" ]]; then
        cat > "$vercel_json" << 'VJEOF'
{
  "framework": "nextjs",
  "buildCommand": "npm run build",
  "installCommand": "npm install",
  "functions": {
    "app/api/**/*.ts": {
      "maxDuration": 30,
      "memory": 1024
    }
  },
  "headers": [
    {
      "source": "/api/(.*)",
      "headers": [
        { "key": "Cache-Control", "value": "no-store, max-age=0" }
      ]
    }
  ]
}
VJEOF
        _DER_FIX_LOG+=("[Vercel] Created vercel.json with defaults")
        DER_VERCEL_FIXES=$((DER_VERCEL_FIXES + 1))
    fi

    # Check for common Vercel issues
    if [[ -f "${project_dir}/next.config.js" ]] || [[ -f "${project_dir}/next.config.mjs" ]]; then
        local config_file
        for f in "${project_dir}/next.config.js" "${project_dir}/next.config.mjs" "${project_dir}/next.config.ts"; do
            [[ -f "$f" ]] && { config_file="$f"; break; }
        done

        if [[ -n "$config_file" ]]; then
            # Check for output config
            if ! grep -q 'output' "$config_file" 2>/dev/null; then
                _DER_WARNINGS+=("[Vercel] next.config missing 'output' setting - consider 'standalone' for serverless")
            fi

            # Check for image optimization
            if ! grep -q 'images' "$config_file" 2>/dev/null; then
                _DER_WARNINGS+=("[Vercel] next.config missing 'images' config - may fail on Vercel")
            fi
        fi
    fi

    # Check for .vercelignore
    if [[ ! -f "${project_dir}/.vercelignore" ]]; then
        cat > "${project_dir}/.vercelignore" << 'VIEOF'
.git
node_modules
.env.local
.env.development
tests/
__tests__/
*.test.ts
*.test.tsx
*.spec.ts
*.spec.tsx
docs/
VIEOF
        _DER_FIX_LOG+=("[Vercel] Created .vercelignore")
        DER_VERCEL_FIXES=$((DER_VERCEL_FIXES + 1))
    fi

    DER_TOTAL_FIXES=$((DER_TOTAL_FIXES + DER_VERCEL_FIXES))
    return 0
}

# =============================================================================
# _der_fix_docker_error - Fix Docker build/run errors
# Usage: _der_fix_docker_error <project_dir> <error_log>
# =============================================================================
_der_fix_docker_error() {
    [[ "$DER_INITIALIZED" != "true" ]] && _der_init
    local project_dir="${1:-.}"
    local error_log="${2:-}"
    DER_TOTAL_SCANS=$((DER_TOTAL_SCANS + 1))

    echo -e "  ${CYAN:-}[DER] Analyzing Docker error...${NC:-}" >&2

    # Match error patterns
    if [[ -n "$error_log" ]]; then
        for pattern in "${!_DER_DOCKER_PATTERNS[@]}"; do
            if echo "$error_log" | grep -q "$pattern"; then
                local fix="${_DER_DOCKER_PATTERNS[$pattern]}"
                _DER_FIX_LOG+=("[Docker] ${pattern}: ${fix}")
                echo -e "  ${YELLOW:-}[DER] Matched: ${pattern}${NC:-}" >&2
            fi
        done
    fi

    local dockerfile="${project_dir}/Dockerfile"

    if [[ ! -f "$dockerfile" ]]; then
        # Generate optimized Dockerfile
        cat > "$dockerfile" << 'DKEOF'
# Stage 1: Dependencies
FROM node:20-alpine AS deps
RUN apk add --no-cache libc6-compat
WORKDIR /app
COPY package.json package-lock.json* ./
RUN npm ci --omit=dev

# Stage 2: Build
FROM node:20-alpine AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
ENV NEXT_TELEMETRY_DISABLED=1
RUN npm run build

# Stage 3: Production
FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
ENV NEXT_TELEMETRY_DISABLED=1

RUN addgroup --system --gid 1001 nodejs
RUN adduser --system --uid 1001 nextjs

COPY --from=builder /app/public ./public
COPY --from=builder --chown=nextjs:nodejs /app/.next/standalone ./
COPY --from=builder --chown=nextjs:nodejs /app/.next/static ./.next/static

USER nextjs
EXPOSE 3000
ENV PORT=3000
ENV HOSTNAME="0.0.0.0"
CMD ["node", "server.js"]
DKEOF
        _DER_FIX_LOG+=("[Docker] Created multi-stage Dockerfile")
        DER_DOCKER_FIXES=$((DER_DOCKER_FIXES + 1))
    else
        # Validate existing Dockerfile
        if ! grep -q 'AS.*builder\|as.*builder' "$dockerfile" 2>/dev/null; then
            _DER_WARNINGS+=("[Docker] Single-stage build - consider multi-stage for smaller images")
        fi

        if ! grep -q 'USER\|user' "$dockerfile" 2>/dev/null; then
            _DER_WARNINGS+=("[Docker] Running as root - add non-root USER")
        fi

        if grep -q 'npm install' "$dockerfile" 2>/dev/null && ! grep -q 'npm ci' "$dockerfile" 2>/dev/null; then
            _DER_WARNINGS+=("[Docker] Use 'npm ci' instead of 'npm install' for reproducible builds")
        fi
    fi

    # Check .dockerignore
    if [[ ! -f "${project_dir}/.dockerignore" ]]; then
        cat > "${project_dir}/.dockerignore" << 'DIEOF'
.git
node_modules
.next
.env.local
.env.development
*.md
tests/
__tests__
.github
.vscode
DIEOF
        _DER_FIX_LOG+=("[Docker] Created .dockerignore")
        DER_DOCKER_FIXES=$((DER_DOCKER_FIXES + 1))
    fi

    DER_TOTAL_FIXES=$((DER_TOTAL_FIXES + DER_DOCKER_FIXES))
    return 0
}

# =============================================================================
# _der_fix_aws_error - Fix AWS deployment errors
# Usage: _der_fix_aws_error <project_dir> <error_log>
# =============================================================================
_der_fix_aws_error() {
    [[ "$DER_INITIALIZED" != "true" ]] && _der_init
    local project_dir="${1:-.}"
    local error_log="${2:-}"
    DER_TOTAL_SCANS=$((DER_TOTAL_SCANS + 1))

    echo -e "  ${CYAN:-}[DER] Analyzing AWS error...${NC:-}" >&2

    if [[ -n "$error_log" ]]; then
        for pattern in "${!_DER_AWS_PATTERNS[@]}"; do
            if echo "$error_log" | grep -q "$pattern"; then
                local fix="${_DER_AWS_PATTERNS[$pattern]}"
                _DER_FIX_LOG+=("[AWS] ${pattern}: ${fix}")
                echo -e "  ${YELLOW:-}[DER] Matched: ${pattern}${NC:-}" >&2
            fi
        done

        # Lambda-specific fixes
        if echo "$error_log" | grep -q "Runtime.ImportModuleError"; then
            _DER_FIX_LOG+=("[AWS] Lambda handler path incorrect - check handler setting in template")
            DER_AWS_FIXES=$((DER_AWS_FIXES + 1))
        fi

        if echo "$error_log" | grep -q "Task timed out"; then
            _DER_FIX_LOG+=("[AWS] Lambda timeout - increase timeout in config or optimize function")
            DER_AWS_FIXES=$((DER_AWS_FIXES + 1))
        fi

        if echo "$error_log" | grep -q "ECONNREFUSED\|ETIMEDOUT"; then
            _DER_FIX_LOG+=("[AWS] Network connectivity - check VPC/Security Group/NAT Gateway config")
            DER_AWS_FIXES=$((DER_AWS_FIXES + 1))
        fi
    fi

    # Check for AWS config files
    if [[ -d "${project_dir}/aws-infra" ]] || [[ -d "${project_dir}/cdk" ]]; then
        local cdk_dir="${project_dir}/aws-infra"
        [[ -d "${project_dir}/cdk" ]] && cdk_dir="${project_dir}/cdk"

        if [[ -f "${cdk_dir}/cdk.json" ]]; then
            # Check CDK context
            if ! grep -q '"@aws-cdk/core:stackRelativeExports"' "${cdk_dir}/cdk.json" 2>/dev/null; then
                _DER_WARNINGS+=("[AWS] CDK context may need stackRelativeExports flag")
            fi
        fi
    fi

    DER_TOTAL_FIXES=$((DER_TOTAL_FIXES + DER_AWS_FIXES))
    return 0
}

# =============================================================================
# _der_fix_env_missing - Fix missing environment variables in deployment
# Usage: _der_fix_env_missing <project_dir>
# =============================================================================
_der_fix_env_missing() {
    [[ "$DER_INITIALIZED" != "true" ]] && _der_init
    local project_dir="${1:-.}"
    DER_TOTAL_SCANS=$((DER_TOTAL_SCANS + 1))

    echo -e "  ${CYAN:-}[DER] Checking environment variables...${NC:-}" >&2

    # Find all env references in code
    local env_refs=()
    while IFS= read -r ref; do
        [[ -n "$ref" ]] && env_refs+=("$ref")
    done < <(grep -rhoE 'process\.env\.[A-Z_]+|import\.meta\.env\.[A-Z_]+' \
        "${project_dir}/src" "${project_dir}/app" "${project_dir}/lib" 2>/dev/null | \
        sed 's/process\.env\.//;s/import\.meta\.env\.//' | sort -u)

    # Check against .env.example or .env.template
    local env_example=""
    for candidate in ".env.example" ".env.template" ".env.sample"; do
        [[ -f "${project_dir}/${candidate}" ]] && { env_example="${project_dir}/${candidate}"; break; }
    done

    if [[ -z "$env_example" ]] && [[ ${#env_refs[@]} -gt 0 ]]; then
        # Generate .env.example
        local env_file="${project_dir}/.env.example"
        echo "# Required Environment Variables" > "$env_file"
        echo "# Generated by SoloptiLinkAI v274.0 Deployment Error Resolver" >> "$env_file"
        echo "" >> "$env_file"

        for ref in "${env_refs[@]}"; do
            echo "${ref}=" >> "$env_file"
        done

        _DER_FIX_LOG+=("[Env] Generated .env.example with ${#env_refs[@]} variables")
        DER_ENV_FIXES=$((DER_ENV_FIXES + 1))
    fi

    # Check for required env vars
    local required_vars=("DATABASE_URL" "NEXTAUTH_SECRET" "NEXTAUTH_URL")
    for var in "${required_vars[@]}"; do
        local found=false
        for ref in "${env_refs[@]}"; do
            [[ "$ref" == "$var" ]] && { found=true; break; }
        done
        if [[ "$found" == "true" ]]; then
            # Check if it's in .env.local
            if [[ -f "${project_dir}/.env.local" ]] && ! grep -q "^${var}=" "${project_dir}/.env.local" 2>/dev/null; then
                _DER_WARNINGS+=("[Env] Required variable ${var} referenced but not set in .env.local")
            fi
        fi
    done

    # Check for secrets accidentally in env files
    for env_file in "${project_dir}/.env" "${project_dir}/.env.local" "${project_dir}/.env.production"; do
        if [[ -f "$env_file" ]]; then
            if grep -qE '^(DATABASE_URL|.*SECRET|.*KEY|.*PASSWORD)=.{10,}' "$env_file" 2>/dev/null; then
                if git -C "$project_dir" ls-files --error-unmatch "$(basename "$env_file")" &>/dev/null; then
                    _DER_WARNINGS+=("[Env] DANGER: ${env_file} with secrets is tracked by git!")
                fi
            fi
        fi
    done

    DER_TOTAL_FIXES=$((DER_TOTAL_FIXES + DER_ENV_FIXES))
    return 0
}

# =============================================================================
# _der_fix_build_output - Fix build output configuration issues
# Usage: _der_fix_build_output <project_dir> <error_log>
# =============================================================================
_der_fix_build_output() {
    [[ "$DER_INITIALIZED" != "true" ]] && _der_init
    local project_dir="${1:-.}"
    local error_log="${2:-}"
    DER_TOTAL_SCANS=$((DER_TOTAL_SCANS + 1))

    echo -e "  ${CYAN:-}[DER] Checking build output configuration...${NC:-}" >&2

    # Check Next.js output
    local next_config=""
    for f in "next.config.js" "next.config.mjs" "next.config.ts"; do
        [[ -f "${project_dir}/${f}" ]] && { next_config="${project_dir}/${f}"; break; }
    done

    if [[ -n "$next_config" ]]; then
        # Check for standalone output (needed for Docker)
        if [[ -f "${project_dir}/Dockerfile" ]] && ! grep -q "output.*standalone" "$next_config" 2>/dev/null; then
            _DER_WARNINGS+=("[Build] Docker found but next.config missing output: 'standalone'")
            DER_BUILD_FIXES=$((DER_BUILD_FIXES + 1))
        fi

        # Check for experimental features that might break build
        if grep -q 'experimental' "$next_config" 2>/dev/null; then
            if grep -q 'serverActions\|appDir' "$next_config" 2>/dev/null; then
                _DER_WARNINGS+=("[Build] Experimental features in next.config - may be unstable")
            fi
        fi
    fi

    # Check package.json build script
    if [[ -f "${project_dir}/package.json" ]]; then
        local pkg="${project_dir}/package.json"

        if ! grep -q '"build"' "$pkg" 2>/dev/null; then
            _DER_WARNINGS+=("[Build] package.json missing 'build' script")
            DER_BUILD_FIXES=$((DER_BUILD_FIXES + 1))
        fi

        if ! grep -q '"start"' "$pkg" 2>/dev/null; then
            _DER_WARNINGS+=("[Build] package.json missing 'start' script")
            DER_BUILD_FIXES=$((DER_BUILD_FIXES + 1))
        fi

        # Check node engine requirement
        if ! grep -q '"engines"' "$pkg" 2>/dev/null; then
            _DER_WARNINGS+=("[Build] package.json missing 'engines' field - deployment may use wrong Node version")
        fi
    fi

    # Check TypeScript build
    if [[ -f "${project_dir}/tsconfig.json" ]]; then
        if ! grep -q '"outDir"' "${project_dir}/tsconfig.json" 2>/dev/null; then
            _DER_WARNINGS+=("[Build] tsconfig.json missing 'outDir' - build output location undefined")
        fi
    fi

    # Error log analysis
    if [[ -n "$error_log" ]]; then
        if echo "$error_log" | grep -q "Type error"; then
            _DER_FIX_LOG+=("[Build] TypeScript type errors in build - fix type errors or add @ts-expect-error")
            DER_BUILD_FIXES=$((DER_BUILD_FIXES + 1))
        fi

        if echo "$error_log" | grep -q "ESLint"; then
            _DER_FIX_LOG+=("[Build] ESLint errors in build - fix lint errors or add eslint-disable")
            DER_BUILD_FIXES=$((DER_BUILD_FIXES + 1))
        fi

        if echo "$error_log" | grep -q "out of memory\|heap"; then
            _DER_FIX_LOG+=("[Build] Out of memory - increase NODE_OPTIONS='--max-old-space-size=4096'")
            DER_BUILD_FIXES=$((DER_BUILD_FIXES + 1))
        fi
    fi

    DER_TOTAL_FIXES=$((DER_TOTAL_FIXES + DER_BUILD_FIXES))
    return 0
}

# =============================================================================
# _der_report
# =============================================================================
_der_report() {
    echo -e "\n  ${BOLD:-}═══ Deployment Error Resolver v274.0 ═══${NC:-}"
    echo -e "  Total scans      : ${DER_TOTAL_SCANS}"
    echo -e "  Total fixes      : ${DER_TOTAL_FIXES}"
    echo -e "  Vercel fixes     : ${DER_VERCEL_FIXES}"
    echo -e "  Docker fixes     : ${DER_DOCKER_FIXES}"
    echo -e "  AWS fixes        : ${DER_AWS_FIXES}"
    echo -e "  Env fixes        : ${DER_ENV_FIXES}"
    echo -e "  Build fixes      : ${DER_BUILD_FIXES}"
    echo -e "  Warnings         : ${#_DER_WARNINGS[@]}"

    if [[ ${#_DER_FIX_LOG[@]} -gt 0 ]]; then
        echo -e "  ${GREEN:-}--- Applied Fixes ---${NC:-}"
        for fix in "${_DER_FIX_LOG[@]}"; do
            echo -e "    ${GREEN:-}${fix}${NC:-}"
        done
    fi
}

# =============================================================================
# _der_score
# =============================================================================
_der_score() {
    local score=70
    [[ $DER_TOTAL_SCANS -gt 0 ]] && score=$((score + 10))
    [[ ${#_DER_WARNINGS[@]} -eq 0 ]] && score=$((score + 10))
    [[ $DER_TOTAL_FIXES -gt 0 ]] && score=$((score + 10))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "deployment-error-resolver" \
    --version "274.0" \
    --description "Vercel/Docker/AWSデプロイエラーの自動解析・修正" \
    --init "_der_init" \
    --report "_der_report" \
    --score "_der_score" \
    --enable-var "ENABLE_DER" \
    --cli-flags "--deploy-resolver:--no-deploy-resolver"
