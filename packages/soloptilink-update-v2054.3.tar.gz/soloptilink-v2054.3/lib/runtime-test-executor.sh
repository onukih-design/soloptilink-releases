#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v156.0 - Runtime Test Executor
# 生成コードを実際に起動し、APIエンドポイントにCRUDテストを実行
#
# これまで: コードを生成→grepで検証→「たぶん動く」
# これから: コードを生成→実際に起動→curlで叩く→「動いた」or「ここが壊れてる」
#
# smoke-test-runner.shのサーバー検出を再利用し、
# 実際のHTTPリクエストでCRUD操作を検証する。
# ============================================================

[[ -n "${_RTE_LOADED:-}" ]] && return 0
_RTE_LOADED=1

# --- グローバル状態 ---
RTE_VERSION="156.0"
RTE_INITIALIZED=false
RTE_SERVER_PID=""
RTE_SERVER_PORT=""
RTE_BASE_URL=""
RTE_TIMEOUT=60              # サーバー起動待ちタイムアウト(秒)
RTE_REQUEST_TIMEOUT=10      # 各リクエストのタイムアウト(秒)
RTE_MAX_HEALTH_RETRIES=20   # ヘルスチェック最大リトライ

# --- 統計 ---
RTE_TOTAL_TESTS=0
RTE_PASSED_TESTS=0
RTE_FAILED_TESTS=0
RTE_PARTIAL_TESTS=0        # v156: 部分的成功（400/401/403等）
RTE_ERRORS=()              # 構造化エラーリスト

# --- テスト結果 ---
RTE_RESULTS=""             # JSON形式の結果

# ============================================================
# 初期化
# ============================================================
rte_init() {
    RTE_SERVER_PID=""
    RTE_SERVER_PORT=""
    RTE_BASE_URL=""
    RTE_TOTAL_TESTS=0
    RTE_PASSED_TESTS=0
    RTE_FAILED_TESTS=0
    RTE_PARTIAL_TESTS=0
    RTE_ERRORS=()
    RTE_RESULTS=""
    RTE_INITIALIZED=true
    return 0
}

# v156: Ensure server cleanup on exit/error
rte_cleanup() {
    if [[ -n "${RTE_SERVER_PID:-}" ]] && kill -0 "$RTE_SERVER_PID" 2>/dev/null; then
        kill "$RTE_SERVER_PID" 2>/dev/null || true
        wait "$RTE_SERVER_PID" 2>/dev/null || true
    fi
}

# ============================================================
# メイン: プロジェクトのランタイムテスト実行
# 戻り値: 0=全テスト通過, 1=失敗あり
# ============================================================
rte_run() {
    local project_dir="$1"

    [[ ! -d "$project_dir" ]] && return 1

    rte_init

    echo -e "  🚀 [RTE] Runtime Test Executor v${RTE_VERSION} 開始" >&2

    # --- Step 1: npm install (依存関係インストール) ---
    if [[ -f "${project_dir}/package.json" ]] && [[ ! -d "${project_dir}/node_modules" ]]; then
        echo -e "  📦 [RTE] npm install 実行中..." >&2
        (cd "$project_dir" && npm install --silent 2>/dev/null) || true
    fi

    # --- Step 2: サーバー起動 ---
    if ! _rte_start_server "$project_dir"; then
        echo -e "  ❌ [RTE] サーバー起動失敗" >&2
        RTE_ERRORS+=("SERVER_START_FAILED: サーバーが起動しない")
        RTE_FAILED_TESTS=$((RTE_FAILED_TESTS + 1))
        RTE_TOTAL_TESTS=$((RTE_TOTAL_TESTS + 1))
        return 1
    fi

    # --- Step 3: APIエンドポイント検出 ---
    local endpoints
    endpoints=$(_rte_detect_endpoints "$project_dir")

    if [[ -z "$endpoints" ]]; then
        echo -e "  ⚠️ [RTE] APIエンドポイント未検出 → ページテストのみ" >&2
    fi

    # --- Step 4: ページアクセステスト ---
    _rte_test_pages "$project_dir"

    # --- Step 5: API CRUDテスト ---
    if [[ -n "$endpoints" ]]; then
        _rte_test_api_endpoints "$endpoints"
    fi

    # --- Step 6: サーバー停止 ---
    _rte_stop_server

    # --- 結果サマリ ---
    echo -e "  📊 [RTE] 結果: ${RTE_PASSED_TESTS}/${RTE_TOTAL_TESTS} 通過 (部分: ${RTE_PARTIAL_TESTS}, 失敗: ${RTE_FAILED_TESTS})" >&2

    # エラーレポート生成
    RTE_RESULTS=$(_rte_build_report)

    if [[ ${RTE_FAILED_TESTS} -gt 0 ]]; then
        return 1
    fi
    return 0
}

# ============================================================
# サーバー起動
# ============================================================
_rte_start_server() {
    local project_dir="$1"

    # smoke-test-runner.shの検出ロジックを使用
    local start_cmd=""
    if type -t _str_detect_start_command &>/dev/null; then
        start_cmd=$(_str_detect_start_command "$project_dir" 2>/dev/null)
    fi

    # フォールバック: 自前検出
    if [[ -z "$start_cmd" ]]; then
        if [[ -f "${project_dir}/next.config.js" ]] || [[ -f "${project_dir}/next.config.mjs" ]] || [[ -f "${project_dir}/next.config.ts" ]]; then
            start_cmd="npm run dev"
        elif [[ -f "${project_dir}/package.json" ]]; then
            if grep -q '"start"' "${project_dir}/package.json" 2>/dev/null; then
                start_cmd="npm start"
            elif grep -q '"dev"' "${project_dir}/package.json" 2>/dev/null; then
                start_cmd="npm run dev"
            fi
        fi
    fi

    [[ -z "$start_cmd" ]] && return 1

    # ポート検出
    if type -t _str_detect_port &>/dev/null; then
        RTE_SERVER_PORT=$(_str_detect_port "$project_dir" 2>/dev/null)
    fi
    [[ -z "$RTE_SERVER_PORT" ]] && RTE_SERVER_PORT=3000
    RTE_BASE_URL="http://localhost:${RTE_SERVER_PORT}"

    # ポートが既に使用中なら再利用
    if command -v lsof &>/dev/null && lsof -i ":${RTE_SERVER_PORT}" &>/dev/null; then
        if curl -s --max-time 3 "${RTE_BASE_URL}" &>/dev/null; then
            echo -e "  ♻️ [RTE] 既存サーバー再利用 (port:${RTE_SERVER_PORT})" >&2
            return 0
        fi
    fi

    # v156: サーバー起動（バックグラウンド） - PID正確追跡
    # 旧実装: (cd "$project_dir" && $start_cmd &>/dev/null &) ではサブシェルのPIDを取得してしまう
    echo -e "  🔄 [RTE] サーバー起動: ${start_cmd} (port:${RTE_SERVER_PORT})" >&2
    pushd "$project_dir" >/dev/null 2>&1
    $start_cmd &>"${RTE_LOG_FILE:-/dev/null}" &
    RTE_SERVER_PID=$!
    popd >/dev/null 2>&1
    # v2000.0: EXIT trapはchain.shが管理。source時にtrap上書きしない
    # trap 'rte_cleanup' EXIT

    # ヘルスチェック（指数バックオフ）
    local retry=0
    local wait_time=1
    while [[ $retry -lt $RTE_MAX_HEALTH_RETRIES ]]; do
        if curl -s --max-time 3 "${RTE_BASE_URL}" &>/dev/null; then
            echo -e "  ✅ [RTE] サーバー起動完了 (${retry}回目で応答)" >&2
            return 0
        fi
        sleep "$wait_time"
        retry=$((retry + 1))
        # 指数バックオフ（1, 1, 2, 2, 3, 3...）
        wait_time=$(( (retry / 2) + 1 ))
        [[ $wait_time -gt 5 ]] && wait_time=5
    done

    echo -e "  ❌ [RTE] サーバー応答なし (${RTE_MAX_HEALTH_RETRIES}回リトライ)" >&2
    _rte_stop_server
    return 1
}

# ============================================================
# サーバー停止
# ============================================================
_rte_stop_server() {
    if [[ -n "$RTE_SERVER_PID" ]]; then
        kill "$RTE_SERVER_PID" 2>/dev/null || true
        wait "$RTE_SERVER_PID" 2>/dev/null || true
        RTE_SERVER_PID=""
        echo -e "  🛑 [RTE] サーバー停止" >&2
    fi
}

# ============================================================
# APIエンドポイント検出
# Next.js App Router: app/api/**/route.ts
# ============================================================
_rte_detect_endpoints() {
    local project_dir="$1"
    local endpoints=""

    # Next.js App Router パターン
    while IFS= read -r route_file; do
        [[ -z "$route_file" ]] && continue
        [[ "$route_file" == *".next"* ]] && continue
        [[ "$route_file" == *"node_modules"* ]] && continue

        # ファイルパスからAPIパスを抽出
        local api_path
        api_path=$(echo "$route_file" | sed "s|${project_dir}/||" | sed 's|/route\.ts||;s|/route\.js||' | sed 's|^app/||;s|^src/app/||')

        # 動的セグメント [id] を除外（テスト時に値が必要）
        if [[ "$api_path" != *"["* ]]; then
            # HTTPメソッドを検出
            local methods=""
            grep -qE "export\s+(async\s+)?function\s+GET" "$route_file" 2>/dev/null && methods="${methods}GET,"
            grep -qE "export\s+(async\s+)?function\s+POST" "$route_file" 2>/dev/null && methods="${methods}POST,"
            grep -qE "export\s+(async\s+)?function\s+PUT" "$route_file" 2>/dev/null && methods="${methods}PUT,"
            grep -qE "export\s+(async\s+)?function\s+PATCH" "$route_file" 2>/dev/null && methods="${methods}PATCH,"
            grep -qE "export\s+(async\s+)?function\s+DELETE" "$route_file" 2>/dev/null && methods="${methods}DELETE,"

            methods="${methods%,}" # 末尾カンマ除去

            if [[ -n "$methods" ]]; then
                endpoints+="/${api_path}|${methods}
"
            fi
        fi
    done < <(find "$project_dir" -path "*/api/*/route.ts" -o -path "*/api/*/route.js" 2>/dev/null | sort)

    echo "$endpoints"
}

# ============================================================
# ページアクセステスト
# ============================================================
_rte_test_pages() {
    local project_dir="$1"

    # トップページ
    _rte_http_test "GET" "${RTE_BASE_URL}/" 200 "トップページ"

    # ログインページ
    if [[ -d "${project_dir}/app/login" ]] || [[ -d "${project_dir}/src/app/login" ]]; then
        _rte_http_test "GET" "${RTE_BASE_URL}/login" 200 "ログインページ"
    fi
}

# ============================================================
# API CRUDテスト
# ============================================================
_rte_test_api_endpoints() {
    local endpoints="$1"

    echo "$endpoints" | while IFS='|' read -r path methods; do
        [[ -z "$path" ]] && continue
        local url="${RTE_BASE_URL}${path}"

        # GETテスト
        if [[ "$methods" == *"GET"* ]]; then
            _rte_http_test "GET" "$url" "2xx" "API GET ${path}"
        fi

        # POSTテスト（空ボディ → 400 or 401 が期待される = APIが動いている証拠）
        if [[ "$methods" == *"POST"* ]]; then
            local status
            status=$(curl -s -o /dev/null -w "%{http_code}" --max-time "$RTE_REQUEST_TIMEOUT" \
                -X POST -H "Content-Type: application/json" -d '{}' "$url" 2>/dev/null || echo "000")

            RTE_TOTAL_TESTS=$((RTE_TOTAL_TESTS + 1))

            # v156: Fix API response code validation - distinguish full pass vs partial pass
            if [[ "$status" == "200" || "$status" == "201" ]]; then
                RTE_PASSED_TESTS=$((RTE_PASSED_TESTS + 1))
            elif [[ "$status" == "400" || "$status" == "422" ]]; then
                # Validation error is expected for empty POST body - count as partial pass
                RTE_PARTIAL_TESTS=$((RTE_PARTIAL_TESTS + 1))
            elif [[ "$status" == "401" || "$status" == "403" ]]; then
                # Auth required - endpoint exists but needs auth
                RTE_PARTIAL_TESTS=$((RTE_PARTIAL_TESTS + 1))
            elif [[ "$status" == "000" ]]; then
                RTE_FAILED_TESTS=$((RTE_FAILED_TESTS + 1))
                RTE_ERRORS+=("API_UNREACHABLE: POST ${path} → 接続不可")
            elif [[ "$status" == "404" ]]; then
                RTE_FAILED_TESTS=$((RTE_FAILED_TESTS + 1))
                RTE_ERRORS+=("API_NOT_FOUND: POST ${path} → 404")
            elif [[ "$status" == "500" ]]; then
                RTE_FAILED_TESTS=$((RTE_FAILED_TESTS + 1))
                RTE_ERRORS+=("API_SERVER_ERROR: POST ${path} → 500 (サーバーエラー)")
            else
                RTE_FAILED_TESTS=$((RTE_FAILED_TESTS + 1))
                RTE_ERRORS+=("API_UNEXPECTED: POST ${path} → ${status}")
            fi
        fi
    done
}

# ============================================================
# HTTP テスト実行
# ============================================================
_rte_http_test() {
    local method="$1"
    local url="$2"
    local expected="$3"
    local test_name="$4"

    local status
    status=$(curl -s -o /dev/null -w "%{http_code}" --max-time "$RTE_REQUEST_TIMEOUT" \
        -X "$method" "$url" 2>/dev/null || echo "000")

    RTE_TOTAL_TESTS=$((RTE_TOTAL_TESTS + 1))

    local passed=false
    if [[ "$expected" == "2xx" ]]; then
        [[ "$status" == 2* ]] && passed=true
    else
        [[ "$status" == "$expected" ]] && passed=true
    fi

    if $passed; then
        RTE_PASSED_TESTS=$((RTE_PASSED_TESTS + 1))
    else
        RTE_FAILED_TESTS=$((RTE_FAILED_TESTS + 1))
        RTE_ERRORS+=("HTTP_${status}: ${method} ${url} → ${status} (期待: ${expected}) [${test_name}]")
    fi
}

# ============================================================
# エラーレポート生成（AI修正プロンプト用）
# ============================================================
_rte_build_report() {
    if [[ ${#RTE_ERRORS[@]} -eq 0 ]]; then
        echo ""
        return
    fi

    local report="## ランタイムテストエラー (${RTE_FAILED_TESTS}/${RTE_TOTAL_TESTS}件失敗)
"
    for err in "${RTE_ERRORS[@]}"; do
        report+="- ${err}
"
    done

    report+="
### 修正ガイド
"
    # エラータイプ別の修正ガイド
    local has_start_fail=false has_404=false has_500=false has_unreachable=false

    for err in "${RTE_ERRORS[@]}"; do
        [[ "$err" == *"SERVER_START"* ]] && has_start_fail=true
        [[ "$err" == *"NOT_FOUND"* ]] && has_404=true
        [[ "$err" == *"SERVER_ERROR"* ]] && has_500=true
        [[ "$err" == *"UNREACHABLE"* ]] && has_unreachable=true
    done

    $has_start_fail && report+="- **サーバー起動失敗**: package.jsonのscriptsにdev/startコマンドがあるか確認。依存関係のインストール漏れがないか確認。
"
    $has_404 && report+="- **404エラー**: app/api/ディレクトリ構造がfetch()のURLパスと一致しているか確認。route.tsが正しい場所にあるか確認。
"
    $has_500 && report+="- **500エラー**: APIルート内でtry/catchが不足している可能性。Prismaクエリがスキーマと一致しているか確認。環境変数が設定されているか確認。
"
    $has_unreachable && report+="- **接続不可**: サーバーが正しいポートでリッスンしているか確認。CORSやミドルウェアがリクエストをブロックしていないか確認。
"

    echo "$report"
}

# ============================================================
# 修正プロンプト生成
# ============================================================
rte_generate_fix_prompt() {
    local error_report="$1"
    [[ -z "$error_report" ]] && return

    echo "以下のランタイムテストが失敗しました。実際にサーバーを起動してAPIを叩いた結果です。

${error_report}

これらのエラーを修正してください。修正後はサーバーが正常に起動し、全APIエンドポイントが正しいHTTPステータスコードを返すようにしてください。"
}

# ============================================================
# レポート
# ============================================================
rte_report() {
    echo "=== Runtime Test Executor v${RTE_VERSION} ==="
    echo "  Tests: ${RTE_TOTAL_TESTS} (Pass:${RTE_PASSED_TESTS}, Partial:${RTE_PARTIAL_TESTS}, Fail:${RTE_FAILED_TESTS})"
}

rte_score() {
    if [[ $RTE_TOTAL_TESTS -eq 0 ]]; then
        echo "50"
        return
    fi
    # v156: Partial tests count as half credit
    local score=$(( ((RTE_PASSED_TESTS * 100) + (RTE_PARTIAL_TESTS * 50)) / RTE_TOTAL_TESTS ))
    echo "$score"
}

# ============================================================
# Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "runtime-test-executor" \
        --version "$RTE_VERSION" \
        --description "ランタイムテスト - サーバー起動→API CRUD検証→PID正確追跡→結果フィードバック" \
        --init "rte_init" \
        --report "rte_report" \
        --score "rte_score" \
        --enable-var "ENABLE_RTE" \
        --cli-flags "--runtime-test:--no-runtime-test"
fi

# v2003.1: source時のexit codeを確実に0にする
true
