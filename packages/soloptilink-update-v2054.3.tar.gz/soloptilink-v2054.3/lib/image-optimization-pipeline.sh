#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v246.0 - Image Optimization Pipeline
# =============================================================================
# next/image の設定、最適化画像コンポーネント、未最適化画像の検出、
# blur placeholder 生成、帯域節約試算を行う。
#
# 機能:
#   - next/image 設定
#   - 最適化画像コンポーネント生成
#   - 未最適化画像検出
#   - Blur placeholder 生成
#   - 帯域節約試算
#
# 全globals: IOP_ prefix
# =============================================================================

[[ -n "${_IMAGE_OPTIMIZATION_PIPELINE_LOADED:-}" ]] && return 0
_IMAGE_OPTIMIZATION_PIPELINE_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g IOP_VERSION="246.0"
declare -g IOP_INITIALIZED=false
declare -g IOP_IMAGES_FOUND=0
declare -g IOP_UNOPTIMIZED_FOUND=0
declare -g IOP_ESTIMATED_SAVINGS_KB=0
declare -g IOP_COMPONENTS_GENERATED=0
declare -g IOP_PROJECT_DIR=""
declare -g IOP_LOG_PREFIX="[IOP]"

# =============================================================================
# ログユーティリティ
# =============================================================================
_iop_log() { echo -e "  ${CLR_CYAN:-\033[0;36m}${IOP_LOG_PREFIX}${CLR_NC:-\033[0m} $*" >&2; }
_iop_success() { echo -e "  ${CLR_GREEN:-\033[0;32m}${IOP_LOG_PREFIX} OK${CLR_NC:-\033[0m} $*" >&2; }
_iop_warn() { echo -e "  ${CLR_YELLOW:-\033[0;33m}${IOP_LOG_PREFIX} WARN${CLR_NC:-\033[0m} $*" >&2; }
_iop_error() { echo -e "  ${CLR_RED:-\033[0;31m}${IOP_LOG_PREFIX} ERROR${CLR_NC:-\033[0m} $*" >&2; }

# =============================================================================
# 初期化
# =============================================================================
iop_init() {
    IOP_INITIALIZED=true
    IOP_IMAGES_FOUND=0
    IOP_UNOPTIMIZED_FOUND=0
    IOP_ESTIMATED_SAVINGS_KB=0
    IOP_COMPONENTS_GENERATED=0
    IOP_PROJECT_DIR="${PROJECT_DIR:-.}"
    return 0
}

# =============================================================================
# next/image 設定
# =============================================================================
# next.config の images 設定を生成する。
# リモート画像パターン、フォーマット、デバイスサイズを含む。
#
# 使い方: _iop_setup_next_image <output_dir>
# =============================================================================
_iop_setup_next_image() {
    local output_dir="${1:-${IOP_PROJECT_DIR}}"
    local config_file="${output_dir}/next-image.config.ts"

    [[ "$IOP_INITIALIZED" != "true" ]] && { _iop_error "未初期化"; return 1; }

    _iop_log "next/image 設定生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$config_file" <<'TS_CONFIG'
// =============================================================================
// SoloptiLinkAI v246.0 - Next.js Image Configuration
// next.config.ts の images セクションに統合する設定
// =============================================================================

import type { NextConfig } from 'next';

export const imageConfig: NextConfig['images'] = {
  // 出力フォーマット（WebP/AVIF で最大 70% サイズ削減）
  formats: ['image/avif', 'image/webp'],

  // デバイスサイズ（レスポンシブ画像生成用）
  deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048],

  // アイコン・サムネイルサイズ
  imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],

  // リモート画像パターン（必要に応じて追加）
  remotePatterns: [
    {
      protocol: 'https',
      hostname: '**.amazonaws.com',
    },
    {
      protocol: 'https',
      hostname: '**.cloudinary.com',
    },
    {
      protocol: 'https',
      hostname: 'images.unsplash.com',
    },
  ],

  // 最小キャッシュ TTL（秒）
  minimumCacheTTL: 60 * 60 * 24 * 30, // 30日

  // 静的画像インポートを有効化
  dangerouslyAllowSVG: false,
  contentDispositionType: 'attachment',
  contentSecurityPolicy: "default-src 'self'; script-src 'none'; sandbox;",
};

// next.config.ts での使用例:
// import { imageConfig } from './next-image.config';
// const nextConfig: NextConfig = { images: imageConfig };
TS_CONFIG

    if [[ -f "$config_file" ]]; then
        _iop_success "next/image 設定生成完了: ${config_file}"
        return 0
    else
        _iop_error "設定生成失敗"
        return 1
    fi
}

# =============================================================================
# 最適化画像コンポーネント生成
# =============================================================================
# next/image をラップした最適化コンポーネントを生成。
# blur placeholder、エラーハンドリング、レスポンシブ対応を含む。
#
# 使い方: _iop_generate_image_component <output_dir>
# =============================================================================
_iop_generate_image_component() {
    local output_dir="${1:-${IOP_PROJECT_DIR}/components}"
    local output_file="${output_dir}/OptimizedImage.tsx"

    [[ "$IOP_INITIALIZED" != "true" ]] && { _iop_error "未初期化"; return 1; }

    _iop_log "最適化画像コンポーネント生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$output_file" <<'TSX_IMAGE'
// =============================================================================
// SoloptiLinkAI v246.0 - Optimized Image Component
// next/image ラッパー（blur placeholder + error handling + responsive）
// =============================================================================

'use client';

import React, { useState } from 'react';
import Image, { ImageProps } from 'next/image';

interface OptimizedImageProps extends Omit<ImageProps, 'onError'> {
  fallbackSrc?: string;
  aspectRatio?: '1:1' | '4:3' | '16:9' | '3:2' | '21:9';
  showSkeleton?: boolean;
  containerClassName?: string;
}

const aspectRatioMap = {
  '1:1': 'aspect-square',
  '4:3': 'aspect-[4/3]',
  '16:9': 'aspect-video',
  '3:2': 'aspect-[3/2]',
  '21:9': 'aspect-[21/9]',
};

export function OptimizedImage({
  src,
  alt,
  fallbackSrc = '/images/placeholder.svg',
  aspectRatio,
  showSkeleton = true,
  containerClassName = '',
  className = '',
  ...props
}: OptimizedImageProps) {
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  const displaySrc = hasError ? fallbackSrc : src;

  return (
    <div
      className={`relative overflow-hidden ${aspectRatio ? aspectRatioMap[aspectRatio] : ''} ${containerClassName}`}
    >
      {isLoading && showSkeleton && (
        <div
          className="absolute inset-0 bg-gray-200 dark:bg-gray-700 animate-pulse"
          aria-hidden="true"
        />
      )}
      <Image
        src={displaySrc}
        alt={alt}
        className={`transition-opacity duration-300 ${isLoading ? 'opacity-0' : 'opacity-100'} ${className}`}
        onLoad={() => setIsLoading(false)}
        onError={() => {
          setHasError(true);
          setIsLoading(false);
        }}
        {...props}
      />
    </div>
  );
}

// --- Avatar コンポーネント ---
interface AvatarImageProps {
  src?: string | null;
  alt: string;
  size?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

const avatarSizes = {
  xs: { size: 24, className: 'w-6 h-6' },
  sm: { size: 32, className: 'w-8 h-8' },
  md: { size: 40, className: 'w-10 h-10' },
  lg: { size: 64, className: 'w-16 h-16' },
  xl: { size: 96, className: 'w-24 h-24' },
};

export function AvatarImage({ src, alt, size = 'md', className = '' }: AvatarImageProps) {
  const config = avatarSizes[size];
  const initials = alt
    .split(' ')
    .map((n) => n[0])
    .join('')
    .slice(0, 2)
    .toUpperCase();

  if (!src) {
    return (
      <div
        className={`${config.className} rounded-full bg-gray-300 dark:bg-gray-600
          flex items-center justify-center text-gray-700 dark:text-gray-200
          font-medium text-sm ${className}`}
        aria-label={alt}
      >
        {initials}
      </div>
    );
  }

  return (
    <OptimizedImage
      src={src}
      alt={alt}
      width={config.size}
      height={config.size}
      className={`${config.className} rounded-full object-cover ${className}`}
      containerClassName={`${config.className} rounded-full`}
    />
  );
}

// --- Background Image コンポーネント ---
interface BackgroundImageProps {
  src: string;
  alt: string;
  children?: React.ReactNode;
  className?: string;
  overlay?: boolean;
  overlayOpacity?: number;
}

export function BackgroundImage({
  src,
  alt,
  children,
  className = '',
  overlay = false,
  overlayOpacity = 0.5,
}: BackgroundImageProps) {
  return (
    <div className={`relative overflow-hidden ${className}`}>
      <Image
        src={src}
        alt={alt}
        fill
        className="object-cover"
        sizes="100vw"
        priority={false}
      />
      {overlay && (
        <div
          className="absolute inset-0 bg-black"
          style={{ opacity: overlayOpacity }}
          aria-hidden="true"
        />
      )}
      {children && <div className="relative z-10">{children}</div>}
    </div>
  );
}
TSX_IMAGE

    if [[ -f "$output_file" ]]; then
        IOP_COMPONENTS_GENERATED=$((IOP_COMPONENTS_GENERATED + 1))
        _iop_success "画像コンポーネント生成完了: ${output_file}"
        return 0
    else
        _iop_error "生成失敗"
        return 1
    fi
}

# =============================================================================
# 未最適化画像検出
# =============================================================================
_iop_find_unoptimized() {
    local project_dir="${1:-${IOP_PROJECT_DIR}}"
    local issues=0

    [[ "$IOP_INITIALIZED" != "true" ]] && { _iop_error "未初期化"; return 1; }

    _iop_log "未最適化画像検出中"

    # 1. public/ 内の大きな画像
    if [[ -d "${project_dir}/public" ]]; then
        while IFS= read -r f; do
            IOP_IMAGES_FOUND=$((IOP_IMAGES_FOUND + 1))
            local size_bytes
            size_bytes=$(wc -c < "$f" 2>/dev/null || echo 0)
            local size_kb=$(( (size_bytes + 1023) / 1024 ))

            if [[ $size_kb -gt 200 ]]; then
                _iop_warn "大きな画像: $(basename "$f") = ${size_kb}KB"
                issues=$((issues + 1))
                IOP_ESTIMATED_SAVINGS_KB=$((IOP_ESTIMATED_SAVINGS_KB + size_kb / 2))
            fi

            # PNG で写真（大サイズ = おそらく写真）
            if [[ "$f" == *.png && $size_kb -gt 100 ]]; then
                _iop_warn "$(basename "$f"): PNG → WebP/AVIF に変換推奨（${size_kb}KB）"
                issues=$((issues + 1))
            fi

            # BMP/TIFF（Web では非推奨）
            if [[ "$f" == *.bmp || "$f" == *.tiff || "$f" == *.tif ]]; then
                _iop_warn "$(basename "$f"): BMP/TIFF は Web 非推奨。WebP に変換必須"
                issues=$((issues + 1))
            fi
        done < <(find "${project_dir}/public" -type f \
            \( -name '*.png' -o -name '*.jpg' -o -name '*.jpeg' -o -name '*.gif' \
            -o -name '*.bmp' -o -name '*.tiff' -o -name '*.tif' -o -name '*.webp' \) \
            2>/dev/null)
    fi

    # 2. ソースコードで <img> タグの直接使用（next/image 未使用）
    if [[ -d "${project_dir}/app" || -d "${project_dir}/components" ]]; then
        local raw_img_count=0
        while IFS= read -r -d '' f; do
            if grep -qP '<img\b' "$f" 2>/dev/null; then
                if ! grep -qP 'next/image' "$f" 2>/dev/null; then
                    local bn
                    bn=$(basename "$f")
                    _iop_warn "${bn}: <img> タグ直接使用（next/image 推奨）"
                    raw_img_count=$((raw_img_count + 1))
                fi
            fi
        done < <(find "$project_dir" -type f \( -name '*.tsx' -o -name '*.jsx' \) \
            -not -path '*/node_modules/*' -not -path '*/.next/*' -print0 2>/dev/null)

        issues=$((issues + raw_img_count))
    fi

    # 3. width/height 未指定の Image コンポーネント
    if [[ -d "${project_dir}/app" || -d "${project_dir}/components" ]]; then
        while IFS= read -r -d '' f; do
            if grep -qP '<Image\b' "$f" 2>/dev/null; then
                if ! grep -qP '(?:width|fill)' "$f" 2>/dev/null; then
                    local bn
                    bn=$(basename "$f")
                    _iop_warn "${bn}: <Image> に width/height または fill なし（CLS 発生）"
                    issues=$((issues + 1))
                fi
            fi
        done < <(find "$project_dir" -type f \( -name '*.tsx' -o -name '*.jsx' \) \
            -not -path '*/node_modules/*' -not -path '*/.next/*' -print0 2>/dev/null)
    fi

    IOP_UNOPTIMIZED_FOUND=$((IOP_UNOPTIMIZED_FOUND + issues))

    if [[ $issues -eq 0 ]]; then
        _iop_success "画像チェック完了: 問題なし"
    else
        _iop_warn "画像チェック完了: ${issues}件の最適化対象"
    fi

    echo "$issues"
    return 0
}

# =============================================================================
# Blur Placeholder 生成ヘルパー
# =============================================================================
_iop_generate_placeholders() {
    local output_dir="${1:-${IOP_PROJECT_DIR}/lib}"
    local output_file="${output_dir}/image-placeholders.ts"

    [[ "$IOP_INITIALIZED" != "true" ]] && { _iop_error "未初期化"; return 1; }

    _iop_log "Blur placeholder ユーティリティ生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$output_file" <<'TS_PLACEHOLDER'
// =============================================================================
// SoloptiLinkAI v246.0 - Image Placeholder Utilities
// =============================================================================

/**
 * SVG ベースの blur placeholder を生成する。
 * next/image の blurDataURL に使用。
 */
export function generateBlurPlaceholder(
  width: number,
  height: number,
  color: string = '#e5e7eb'
): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">
    <rect width="100%" height="100%" fill="${color}"/>
    <filter id="b"><feGaussianBlur stdDeviation="20"/></filter>
    <rect width="100%" height="100%" filter="url(#b)" fill="${color}" opacity="0.5"/>
  </svg>`;
  const base64 = typeof window === 'undefined'
    ? Buffer.from(svg).toString('base64')
    : btoa(svg);
  return `data:image/svg+xml;base64,${base64}`;
}

/**
 * Shimmer effect placeholder
 */
export function generateShimmerPlaceholder(
  width: number,
  height: number
): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${width}" height="${height}">
    <defs>
      <linearGradient id="g">
        <stop stop-color="#e5e7eb" offset="20%"/>
        <stop stop-color="#f3f4f6" offset="50%"/>
        <stop stop-color="#e5e7eb" offset="80%"/>
      </linearGradient>
    </defs>
    <rect width="${width}" height="${height}" fill="#e5e7eb"/>
    <rect id="r" width="${width}" height="${height}" fill="url(#g)"/>
    <animate xlink:href="#r" attributeName="x" from="-${width}" to="${width}" dur="1.5s" repeatCount="indefinite"/>
  </svg>`;
  const base64 = typeof window === 'undefined'
    ? Buffer.from(svg).toString('base64')
    : btoa(svg);
  return `data:image/svg+xml;base64,${base64}`;
}

/**
 * プリセット placeholder map
 */
export const placeholders = {
  gray: generateBlurPlaceholder(16, 16, '#e5e7eb'),
  blue: generateBlurPlaceholder(16, 16, '#dbeafe'),
  green: generateBlurPlaceholder(16, 16, '#d1fae5'),
  purple: generateBlurPlaceholder(16, 16, '#ede9fe'),
} as const;
TS_PLACEHOLDER

    if [[ -f "$output_file" ]]; then
        _iop_success "Placeholder ユーティリティ生成完了: ${output_file}"
        return 0
    fi
    return 1
}

# =============================================================================
# 帯域節約試算
# =============================================================================
_iop_estimate_savings() {
    local project_dir="${1:-${IOP_PROJECT_DIR}}"

    [[ "$IOP_INITIALIZED" != "true" ]] && { _iop_error "未初期化"; return 1; }

    _iop_log "帯域節約試算中"

    local total_current_kb=0
    local total_optimized_kb=0

    if [[ -d "${project_dir}/public" ]]; then
        while IFS= read -r f; do
            local size_bytes
            size_bytes=$(wc -c < "$f" 2>/dev/null || echo 0)
            local size_kb=$(( (size_bytes + 1023) / 1024 ))
            total_current_kb=$((total_current_kb + size_kb))

            # 推定最適化後サイズ
            case "$f" in
                *.png)  total_optimized_kb=$((total_optimized_kb + size_kb * 30 / 100)) ;;
                *.jpg|*.jpeg) total_optimized_kb=$((total_optimized_kb + size_kb * 50 / 100)) ;;
                *.gif)  total_optimized_kb=$((total_optimized_kb + size_kb * 40 / 100)) ;;
                *.webp) total_optimized_kb=$((total_optimized_kb + size_kb * 90 / 100)) ;;
                *)      total_optimized_kb=$((total_optimized_kb + size_kb)) ;;
            esac
        done < <(find "${project_dir}/public" -type f \
            \( -name '*.png' -o -name '*.jpg' -o -name '*.jpeg' -o -name '*.gif' -o -name '*.webp' \) \
            2>/dev/null)
    fi

    local savings_kb=$((total_current_kb - total_optimized_kb))
    local savings_pct=0
    [[ $total_current_kb -gt 0 ]] && savings_pct=$((savings_kb * 100 / total_current_kb))

    IOP_ESTIMATED_SAVINGS_KB=$savings_kb

    _iop_success "現在: ${total_current_kb}KB → 最適化後: ${total_optimized_kb}KB (削減: ${savings_kb}KB / ${savings_pct}%)"
    echo "$savings_kb"
    return 0
}

# =============================================================================
# プロンプト注入
# =============================================================================
_iop_inject_prompt() {
    cat <<'PROMPT'
## [IOP] 画像最適化ルール

### next/image 必須
- <img> タグ直接使用禁止。必ず next/image の <Image> を使用
- width + height を明示（CLS 防止）、または fill 属性を使用
- sizes 属性でレスポンシブサイズを指定

### フォーマット
- PNG → WebP/AVIF に変換（next.config で自動）
- SVG はそのまま使用可
- アイコンは SVG コンポーネントとして実装

### 遅延読み込み
- ATF (Above The Fold) 画像: priority={true}
- BTF (Below The Fold) 画像: loading="lazy"（デフォルト）
- blur placeholder で UX 向上
PROMPT
}

# =============================================================================
# レポート
# =============================================================================
iop_report() {
    echo -e "\n  ${BOLD:-}--- Image Optimization Pipeline v${IOP_VERSION} ---${NC:-}"
    echo -e "  画像検出数      : ${IOP_IMAGES_FOUND}"
    echo -e "  未最適化        : ${IOP_UNOPTIMIZED_FOUND}"
    echo -e "  推定節約 (KB)   : ${IOP_ESTIMATED_SAVINGS_KB}"
    echo -e "  生成コンポーネント: ${IOP_COMPONENTS_GENERATED}"
}

iop_report_json() {
    cat <<EOF
{"module":"image-optimization-pipeline","version":"${IOP_VERSION}","images_found":${IOP_IMAGES_FOUND},"unoptimized":${IOP_UNOPTIMIZED_FOUND},"savings_kb":${IOP_ESTIMATED_SAVINGS_KB},"components":${IOP_COMPONENTS_GENERATED}}
EOF
}

iop_score() {
    if [[ "$IOP_INITIALIZED" != "true" ]]; then echo 0; return; fi
    local score=80
    [[ $IOP_UNOPTIMIZED_FOUND -eq 0 ]] && score=$((score + 20))
    [[ $IOP_UNOPTIMIZED_FOUND -gt 0 ]] && score=$((score - IOP_UNOPTIMIZED_FOUND * 5))
    [[ $score -lt 0 ]] && score=0
    echo "$score"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "image-optimization-pipeline" \
        --version "246.0" \
        --description "next/image 設定 + 画像コンポーネント + 未最適化検出 + 帯域節約" \
        --init "iop_init" \
        --report "iop_report" \
        --score "iop_score" \
        --enable-var "ENABLE_IMAGE_OPTIMIZATION" \
        --cli-flags "--image-opt:--no-image-opt"
fi

# v2003.1: source時のexit codeを確実に0にする
true
