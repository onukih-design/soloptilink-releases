#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2040 - Customer Output Layer (PFP-117 顧客向け出力層)
# =============================================================================
# 顧客可視出力ポリシー (CLAUDE.md「🪟 顧客可視出力ポリシー」) を chain.sh /
# 各フェーズスクリプトに実装レベルで提供するための出力ヘルパー。
# お客さんが読む画面には「日本語の自然文」だけを流し、技術ノイズ
# (内部診断・警告・コマンドログ) は環境変数でゲートする。
#
# 提供関数 (3つ。既存コードの書き換えはしない — 関数提供のみ):
#   customer_echo "<日本語自然文>"
#     → 常時表示。顧客が読む進捗・完了メッセージ専用。stdout へ出力。
#   admin_echo "<内部診断メッセージ>"
#     → SOLOPTILINK_VERBOSE=1 のときだけ表示 (stderr)。管理者・開発者向け。
#   quiet_warn "<警告メッセージ>"
#     → 画面非表示でログ (~/.soloptilink/.customer-output.log) にのみ記録。
#       SOLOPTILINK_DEBUG=1 のときだけ stderr にも表示。
#
# 環境変数:
#   SOLOPTILINK_VERBOSE=1 ... admin_echo を画面に出す (既定: 出さない)
#   SOLOPTILINK_DEBUG=1   ... quiet_warn を画面に出す (既定: ログのみ)
#   SOLOPTILINK_DIR       ... 本体ディレクトリ (既定: ~/.soloptilink)
#
# 設計原則:
#   - 出力関数は絶対に非ゼロ終了しない (set -e 環境の呼び出し元を殺さない)。
#   - ログ書き込み失敗 (権限・ディスク満杯) も silent に握りつぶす。
#   - 二重 source 安全 (ロードガード付き)。
# =============================================================================

[[ -n "${_CUSTOMER_OUTPUT_LOADED:-}" ]] && return 0
_CUSTOMER_OUTPUT_LOADED=1

_CO_SL_DIR="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
_CO_LOG_FILE="${_CO_SL_DIR}/.customer-output.log"

# -----------------------------------------------------------------------------
# _co_log - タイムスタンプ付きでログファイルに追記 (失敗しても無視)
#   引数: <level> <message>
# -----------------------------------------------------------------------------
_co_log() {
    local level="${1:-INFO}" msg="${2:-}"
    [[ -z "$msg" ]] && return 0
    mkdir -p "$_CO_SL_DIR" 2>/dev/null || return 0
    printf '%s [%s] %s\n' "$(date '+%Y-%m-%dT%H:%M:%S')" "$level" "$msg" >> "$_CO_LOG_FILE" 2>/dev/null || true
    return 0
}

# =============================================================================
# customer_echo <日本語自然文>
#   顧客に見せる進捗・完了メッセージ。常時 stdout 表示 + ログ記録。
#   ここに bash コマンド・生ログ・コード断片を渡さないこと (顧客可視出力ポリシー)。
# =============================================================================
customer_echo() {
    local msg="${1:-}"
    [[ -z "$msg" ]] && return 0
    printf '%s\n' "$msg"
    _co_log "CUSTOMER" "$msg"
    return 0
}

# =============================================================================
# admin_echo <内部診断メッセージ>
#   管理者向け詳細。SOLOPTILINK_VERBOSE=1 のときのみ stderr 表示。
#   表示有無に関わらずログには常時記録 (障害解析用)。
# =============================================================================
admin_echo() {
    local msg="${1:-}"
    [[ -z "$msg" ]] && return 0
    if [[ "${SOLOPTILINK_VERBOSE:-0}" == "1" ]]; then
        printf '[admin] %s\n' "$msg" >&2
    fi
    _co_log "ADMIN" "$msg"
    return 0
}

# =============================================================================
# quiet_warn <警告メッセージ>
#   非致命的な警告。画面には出さずログにのみ記録する。
#   SOLOPTILINK_DEBUG=1 のときだけ stderr にも表示 (開発・調査時)。
# =============================================================================
quiet_warn() {
    local msg="${1:-}"
    [[ -z "$msg" ]] && return 0
    if [[ "${SOLOPTILINK_DEBUG:-0}" == "1" ]]; then
        printf '[warn] %s\n' "$msg" >&2
    fi
    _co_log "WARN" "$msg"
    return 0
}

# =============================================================================
# v2043 (レーン2 / 導入確実性): 使用箇所拡充のための additive ヘルパー
#   ※上記3関数 (customer_echo/admin_echo/quiet_warn) の I/F は不変。以下は追加のみ。
#   新規消費者: lib/activation-guidance.sh / lib/first-boot-perfect/smoke-probe-port.sh
#              (承認待ち/起動摩擦の日本語ガイダンスを本層経由で顧客に出す)。
# =============================================================================

# customer_block <line...> — 複数行を1つの顧客可視ブロックとして customer_echo で出力。
#   各行は日本語自然文を渡す。機械言語は customer_safe_echo を使うこと。
customer_block() {
    local line
    for line in "$@"; do customer_echo "$line"; done
    return 0
}

# customer_safe_echo <msg> — 機械言語(パス/コマンド/HTTP/exit/<invoke>等)を検出したら
#   その行を出さずに安全な汎用日本語へ置換して出力する (顧客可視出力ポリシーの最終防壁)。
#   既にクリーンな日本語はそのまま customer_echo に流す (素通し=既存挙動不変)。
customer_safe_echo() {
    local msg="${1:-}"
    [[ -z "$msg" ]] && return 0
    if printf '%s' "$msg" | grep -qiE '(\.sh|\.tsx|\.ts|\.js|\.py)([^a-zA-Z]|$)|/[a-zA-Z]+/|exit[[:space:]]*[0-9]|https?://|HTTP[/ ][0-9]|<invoke|\$\(|&&|\|\||sudo |bash ' 2>/dev/null; then
        customer_echo "処理を進めています。少々お待ちください。"
        _co_log "SAFE_REDACT" "$msg"
        return 0
    fi
    customer_echo "$msg"
    return 0
}
