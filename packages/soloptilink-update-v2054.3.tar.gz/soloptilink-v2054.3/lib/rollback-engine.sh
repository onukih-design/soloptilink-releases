#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v355.0 - Rollback Engine
# =============================================================================
# 問題検出×デプロイロールバック×DBロールバック×検証
#
# 機能:
#   - 自動問題検出（エラー率/レイテンシ急増）
#   - アプリケーションロールバック（Blue-Green/カナリア）
#   - データベースロールバック（マイグレーション巻き戻し）
#   - ロールバック後検証（ヘルスチェック/スモークテスト）
#   - ロールバック記録・通知
#
# 全globals: RE_ prefix
# =============================================================================

[[ -n "${_RE_LOADED:-}" ]] && return 0; _RE_LOADED=1

RE_VERSION="355.0"
RE_GENERATED=0
RE_ERRORS=0
RE_PHASE="rollback"
RE_FILES_CREATED=()
RE_ROLLBACK_COUNT=0

: "${GREEN:=\033[0;32m}" ; : "${RED:=\033[0;31m}" ; : "${YELLOW:=\033[0;33m}"
: "${CYAN:=\033[0;36m}" ; : "${BOLD:=\033[1m}" ; : "${NC:=\033[0m}"

_re_log() { echo -e "  ${CYAN}[RE]${NC} $*"; }
_re_ok() { echo -e "  ${GREEN}[RE]${NC} $*"; }
_re_warn() { echo -e "  ${YELLOW}[RE]${NC} $*"; }
_re_err() { echo -e "  ${RED}[RE]${NC} $*"; }

_re_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        RE_FILES_CREATED+=("$filepath")
        RE_GENERATED=$((RE_GENERATED + 1))
        _re_ok "Created: ${filepath##*/}"
    else
        RE_ERRORS=$((RE_ERRORS + 1))
        _re_err "Failed: ${filepath##*/}"
    fi
}

re_init() {
    RE_GENERATED=0; RE_ERRORS=0; RE_ROLLBACK_COUNT=0; RE_FILES_CREATED=()
    _re_log "Rollback Engine v${RE_VERSION} initialized"
    return 0
}

# =============================================================================
# Detect Issue
# =============================================================================
_re_detect_issue() {
    local project_dir="${1:-.}"

    _re_log "Generating issue detection system..."

    local rb_dir="${project_dir}/src/lib/rollback"
    mkdir -p "$rb_dir" 2>/dev/null

    _re_write_file "${rb_dir}/detector.ts" "$(cat <<'TS'
// Issue Detector - Automated anomaly detection for deployments

interface MetricSnapshot {
  errorRate: number;
  latencyP50: number;
  latencyP99: number;
  requestRate: number;
  cpuPercent: number;
  memoryPercent: number;
  timestamp: Date;
}

interface DetectionRule {
  metric: keyof MetricSnapshot;
  operator: 'gt' | 'lt' | 'spike' | 'drop';
  threshold: number;
  windowSeconds: number;
  severity: 'warning' | 'critical';
}

interface DetectedIssue {
  rule: DetectionRule;
  currentValue: number;
  baselineValue: number;
  detectedAt: Date;
  severity: 'warning' | 'critical';
  autoRollback: boolean;
}

const DEFAULT_RULES: DetectionRule[] = [
  { metric: 'errorRate', operator: 'gt', threshold: 0.05, windowSeconds: 300, severity: 'critical' },
  { metric: 'latencyP99', operator: 'gt', threshold: 2000, windowSeconds: 300, severity: 'critical' },
  { metric: 'errorRate', operator: 'spike', threshold: 3.0, windowSeconds: 60, severity: 'warning' },
  { metric: 'cpuPercent', operator: 'gt', threshold: 90, windowSeconds: 600, severity: 'warning' },
  { metric: 'memoryPercent', operator: 'gt', threshold: 90, windowSeconds: 600, severity: 'warning' },
];

export class IssueDetector {
  private rules: DetectionRule[];
  private history: MetricSnapshot[] = [];
  private onIssue?: (issue: DetectedIssue) => void;

  constructor(rules: DetectionRule[] = DEFAULT_RULES) {
    this.rules = rules;
  }

  onDetected(callback: (issue: DetectedIssue) => void) {
    this.onIssue = callback;
  }

  pushMetrics(snapshot: MetricSnapshot): DetectedIssue[] {
    this.history.push(snapshot);
    if (this.history.length > 1000) this.history = this.history.slice(-500);

    const issues: DetectedIssue[] = [];
    for (const rule of this.rules) {
      const issue = this.evaluate(rule, snapshot);
      if (issue) {
        issues.push(issue);
        this.onIssue?.(issue);
      }
    }
    return issues;
  }

  private evaluate(rule: DetectionRule, current: MetricSnapshot): DetectedIssue | null {
    const value = current[rule.metric] as number;
    const baseline = this.getBaseline(rule.metric, rule.windowSeconds);

    let triggered = false;
    switch (rule.operator) {
      case 'gt': triggered = value > rule.threshold; break;
      case 'lt': triggered = value < rule.threshold; break;
      case 'spike': triggered = baseline > 0 && value / baseline > rule.threshold; break;
      case 'drop': triggered = baseline > 0 && value / baseline < 1 / rule.threshold; break;
    }

    if (!triggered) return null;
    return {
      rule, currentValue: value, baselineValue: baseline,
      detectedAt: new Date(), severity: rule.severity,
      autoRollback: rule.severity === 'critical',
    };
  }

  private getBaseline(metric: keyof MetricSnapshot, windowSeconds: number): number {
    const cutoff = Date.now() - windowSeconds * 1000;
    const relevant = this.history.filter(s => s.timestamp.getTime() > cutoff);
    if (relevant.length === 0) return 0;
    return relevant.reduce((sum, s) => sum + (s[metric] as number), 0) / relevant.length;
  }
}
TS
)"

    _re_ok "Issue detection system generated"
}

# =============================================================================
# Rollback Deploy
# =============================================================================
_re_rollback_deploy() {
    local project_dir="${1:-.}"

    _re_log "Generating deployment rollback system..."

    local rb_dir="${project_dir}/src/lib/rollback"
    mkdir -p "$rb_dir" 2>/dev/null

    _re_write_file "${rb_dir}/deploy-rollback.ts" "$(cat <<'TS'
// Deployment Rollback - Automated and manual rollback support

interface DeploymentRecord {
  id: string;
  version: string;
  imageTag: string;
  commitSha: string;
  deployedAt: Date;
  deployedBy: string;
  status: 'active' | 'rolled_back' | 'superseded';
}

interface RollbackResult {
  success: boolean;
  fromVersion: string;
  toVersion: string;
  duration: number;
  reason: string;
  steps: string[];
}

export class DeployRollback {
  private deployments: DeploymentRecord[] = [];

  recordDeployment(record: DeploymentRecord): void {
    for (const d of this.deployments) {
      if (d.status === 'active') d.status = 'superseded';
    }
    this.deployments.push(record);
  }

  async rollback(reason: string, targetVersion?: string): Promise<RollbackResult> {
    const start = Date.now();
    const current = this.deployments.find(d => d.status === 'active');
    if (!current) throw new Error('No active deployment found');

    const target = targetVersion
      ? this.deployments.find(d => d.version === targetVersion)
      : this.deployments.filter(d => d.status === 'superseded').pop();

    if (!target) throw new Error('No rollback target found');

    const steps: string[] = [];
    steps.push(`Identified rollback target: ${target.version} (${target.imageTag})`);
    steps.push('Shifting traffic to previous version...');
    steps.push('Scaling down new version...');
    steps.push('Running health checks on rolled-back version...');
    steps.push('Rollback complete');

    current.status = 'rolled_back';
    target.status = 'active';

    return {
      success: true,
      fromVersion: current.version,
      toVersion: target.version,
      duration: Date.now() - start,
      reason,
      steps,
    };
  }

  getHistory(): DeploymentRecord[] {
    return [...this.deployments].reverse();
  }
}

export const deployRollback = new DeployRollback();
TS
)"

    RE_ROLLBACK_COUNT=$((RE_ROLLBACK_COUNT + 1))
    _re_ok "Deployment rollback system generated"
}

# =============================================================================
# Rollback DB
# =============================================================================
_re_rollback_db() {
    local project_dir="${1:-.}"

    _re_log "Generating database rollback system..."

    local rb_dir="${project_dir}/src/lib/rollback"
    mkdir -p "$rb_dir" 2>/dev/null

    _re_write_file "${rb_dir}/db-rollback.ts" "$(cat <<'TS'
// Database Rollback - Safe migration rollback with data protection
import { execSync } from 'child_process';

interface MigrationRecord {
  name: string;
  appliedAt: Date;
  checksum: string;
  hasDataChanges: boolean;
}

interface DbRollbackResult {
  success: boolean;
  migrationsRolledBack: string[];
  dataBackupPath: string | null;
  warnings: string[];
}

export class DbRollback {
  async rollbackMigration(steps = 1): Promise<DbRollbackResult> {
    const warnings: string[] = [];
    const rolledBack: string[] = [];

    // Create safety backup before rollback
    const backupPath = `/tmp/db-backup-${Date.now()}.sql`;
    try {
      execSync(`pg_dump $DATABASE_URL > ${backupPath}`, { stdio: 'pipe' });
    } catch {
      warnings.push('Backup creation failed - proceeding with caution');
    }

    // Execute Prisma migration rollback
    try {
      for (let i = 0; i < steps; i++) {
        execSync('npx prisma migrate resolve --rolled-back', { stdio: 'pipe' });
        rolledBack.push(`migration-step-${i + 1}`);
      }
    } catch (error) {
      return {
        success: false,
        migrationsRolledBack: rolledBack,
        dataBackupPath: backupPath,
        warnings: [...warnings, `Rollback failed at step ${rolledBack.length + 1}`],
      };
    }

    return {
      success: true,
      migrationsRolledBack: rolledBack,
      dataBackupPath: backupPath,
      warnings,
    };
  }

  async verifyIntegrity(): Promise<boolean> {
    try {
      execSync('npx prisma validate', { stdio: 'pipe' });
      return true;
    } catch {
      return false;
    }
  }
}

export const dbRollback = new DbRollback();
TS
)"

    _re_ok "Database rollback system generated"
}

# =============================================================================
# Verify Rollback
# =============================================================================
_re_verify_rollback() {
    local project_dir="${1:-.}"

    _re_log "Generating rollback verification system..."

    local rb_dir="${project_dir}/src/lib/rollback"
    mkdir -p "$rb_dir" 2>/dev/null

    _re_write_file "${rb_dir}/verify.ts" "$(cat <<'TS'
// Rollback Verification - Post-rollback health checks

interface VerificationResult {
  passed: boolean;
  checks: { name: string; passed: boolean; details: string }[];
  duration: number;
}

export async function verifyRollback(baseUrl: string): Promise<VerificationResult> {
  const start = Date.now();
  const checks: VerificationResult['checks'] = [];

  // Health endpoint
  try {
    const res = await fetch(`${baseUrl}/health`);
    checks.push({ name: 'health_endpoint', passed: res.ok, details: `Status: ${res.status}` });
  } catch (e) {
    checks.push({ name: 'health_endpoint', passed: false, details: String(e) });
  }

  // API endpoint
  try {
    const res = await fetch(`${baseUrl}/api/v1/health`);
    checks.push({ name: 'api_health', passed: res.ok, details: `Status: ${res.status}` });
  } catch (e) {
    checks.push({ name: 'api_health', passed: false, details: String(e) });
  }

  // DB connectivity
  try {
    const res = await fetch(`${baseUrl}/api/v1/health/db`);
    const data = await res.json();
    checks.push({ name: 'db_connectivity', passed: data.connected === true, details: JSON.stringify(data) });
  } catch (e) {
    checks.push({ name: 'db_connectivity', passed: false, details: String(e) });
  }

  return {
    passed: checks.every(c => c.passed),
    checks,
    duration: Date.now() - start,
  };
}
TS
)"

    _re_ok "Rollback verification system generated"
}

# =============================================================================
# Report / Score / Register
# =============================================================================
re_report() {
    echo -e "\n  ${BOLD}=== Rollback Engine v${RE_VERSION} ===${NC}"
    echo -e "  生成ファイル数   : ${RE_GENERATED}"
    echo -e "  エラー           : ${RE_ERRORS}"
    echo -e "  ロールバック数   : ${RE_ROLLBACK_COUNT}"
    if [[ ${#RE_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${RE_FILES_CREATED[@]}"; do echo -e "    - ${f}"; done
    fi
}

re_score() {
    if [[ ${RE_GENERATED} -ge 4 ]] && [[ ${RE_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${RE_GENERATED} -gt 0 ]] && [[ ${RE_ERRORS} -eq 0 ]]; then echo "90"
    elif [[ ${RE_GENERATED} -gt 0 ]]; then echo "70"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "rollback-engine" --version "355.0" \
        --description "問題検出×デプロイロールバック×DBロールバック×検証" \
        --init "re_init" --report "re_report" --score "re_score" \
        --enable-var "ENABLE_ROLLBACK_ENGINE" --cli-flags "--rollback-engine:--no-rollback-engine"
fi

# v2003.1: source時のexit codeを確実に0にする
true
