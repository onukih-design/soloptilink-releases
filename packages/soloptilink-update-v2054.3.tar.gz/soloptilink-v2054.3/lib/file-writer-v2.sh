#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v12.0 - Intelligent File Writer v2
# =============================================================================
# v1の正規表現ベースの解析をマニフェスト方式に全面刷新。
# Claude出力から ```言語:パス 形式のコードブロックを確実に抽出し、
# プロジェクトファイルに書き出す。
#
# 方式:
#   パス1: Claude出力からコードブロック（```lang:path ... ```）を構造化抽出
#   パス2: 抽出したファイルリストを検証→プロジェクトに書き出し
#
# v1からの改善点:
#   - 正規表現パースの脆弱性を排除（Python解析エンジン使用）
#   - パストラバーサル防御の強化
#   - 既存ファイルのバックアップ自動作成
#   - 書き出し結果のJSON形式レポート
#   - フォールバック: Python未検出時はv1互換のBashパース
#
# Usage: source lib/file-writer-v2.sh
# =============================================================================

[[ -n "${_FW2_LOADED:-}" ]] && return 0
_FW2_LOADED=1

# カラー定義（FW2_プレフィックスで衝突回避）
FW2_GREEN='\033[0;32m'  FW2_YELLOW='\033[0;33m' FW2_RED='\033[0;31m'
FW2_CYAN='\033[0;36m'   FW2_BOLD='\033[1m'       FW2_NC='\033[0m'

# モジュール状態
FW2_PROJECT_DIR=""
FW2_FILES_WRITTEN=0
FW2_BYTES_WRITTEN=0
FW2_BACKUP_DIR=""
declare -a FW2_WRITTEN_LIST=()
declare -a FW2_SKIPPED_LIST=()

# --- ヘルパー ---
_fw2_log() {
    local level="$1" msg="$2"
    case "$level" in
        INFO) printf "  ${FW2_CYAN}[FW2]${FW2_NC} %s\n" "$msg" ;;
        OK)   printf "  ${FW2_GREEN}[FW2]${FW2_NC} %s\n" "$msg" ;;
        WARN) printf "  ${FW2_YELLOW}[FW2]${FW2_NC} %s\n" "$msg" ;;
        ERROR) printf "  ${FW2_RED}[FW2]${FW2_NC} %s\n" "$msg" ;;
    esac
}

# =============================================================================
# 1. fw2_init(project_dir) — 初期化
# =============================================================================
fw2_init() {
    local project_dir="${1:-.}"

    if [[ -d "$project_dir" ]]; then
        FW2_PROJECT_DIR="$(cd "$project_dir" && pwd)"
    else
        mkdir -p "$project_dir" 2>/dev/null || { _fw2_log "ERROR" "ディレクトリ作成失敗: $project_dir"; return 1; }
        FW2_PROJECT_DIR="$(cd "$project_dir" && pwd)"
    fi

    FW2_FILES_WRITTEN=0
    FW2_BYTES_WRITTEN=0
    FW2_WRITTEN_LIST=()
    FW2_SKIPPED_LIST=()
    FW2_BACKUP_DIR="${FW2_PROJECT_DIR}/.fw2-backups/$(date +%Y%m%d_%H%M%S)"

    _fw2_log "OK" "FileWriter v2 初期化: ${FW2_PROJECT_DIR}"
}

# =============================================================================
# 2. fw2_validate_path(filepath) — パストラバーサル防御
# =============================================================================
fw2_validate_path() {
    local filepath="$1"

    # 空パス
    [[ -z "$filepath" ]] && return 1

    # 絶対パス拒否
    [[ "$filepath" == /* ]] && { _fw2_log "WARN" "絶対パス拒否: ${filepath}"; return 1; }

    # ディレクトリトラバーサル拒否
    [[ "$filepath" == *../* || "$filepath" == */../* || "$filepath" == ..* ]] && {
        _fw2_log "WARN" "パストラバーサル拒否: ${filepath}"
        return 1
    }

    # 危険なパス拒否
    case "$filepath" in
        .env|.env.*|*.pem|*.key|*.p12|id_rsa*|*.pfx)
            _fw2_log "WARN" "機密ファイル拒否: ${filepath}"
            return 1
            ;;
        node_modules/*|.git/*|__pycache__/*)
            _fw2_log "WARN" "システムディレクトリ拒否: ${filepath}"
            return 1
            ;;
    esac

    return 0
}

# =============================================================================
# 3. fw2_parse_and_write(claude_output, project_dir) — メインエントリ
# =============================================================================
# Claude出力からコードブロックを抽出してファイルに書き出す
fw2_parse_and_write() {
    local claude_output="$1"
    local project_dir="${2:-$FW2_PROJECT_DIR}"

    [[ -z "$claude_output" ]] && { _fw2_log "WARN" "空の出力"; echo "0"; return 0; }
    [[ -z "$project_dir" ]] && { _fw2_log "ERROR" "project_dir未設定"; echo "0"; return 1; }

    # Python解析が使える場合はPythonで確実にパース
    if command -v python3 &>/dev/null; then
        _fw2_parse_python "$claude_output" "$project_dir"
    else
        _fw2_parse_bash "$claude_output" "$project_dir"
    fi

    echo "$FW2_FILES_WRITTEN"
}

# =============================================================================
# 3a. Python解析エンジン — 高精度コードブロック抽出
# =============================================================================
_fw2_parse_python() {
    local output_text="$1"
    local project_dir="$2"
    local tmp_input="/tmp/fw2_input_$$.txt"
    local tmp_manifest="/tmp/fw2_manifest_$$.json"
    # 2026-06-16: 残骸manifest footgun除去。PID固定名のため前回PID残骸/同PID再実行で既存manifestが
    # 残ると、後段の `[[ ! -f tmp_manifest ]]` 判定が誤りBashフォールバックに落ちず、古い/空の
    # manifestで「0件・ファイル未作成」のサイレント生成失敗に陥る経路があった。毎回まず削除して保証する。
    rm -f "$tmp_input" "$tmp_manifest" 2>/dev/null || true

    # 入力をテンポラリファイルに書き出し
    printf '%s\n' "$output_text" > "$tmp_input"

    # Python でコードブロックを抽出→マニフェストJSON生成
    python3 << 'PYEOF' "$tmp_input" "$tmp_manifest" 2>/dev/null
import sys, json, re, os

input_file = sys.argv[1]
manifest_file = sys.argv[2]

with open(input_file, 'r', encoding='utf-8', errors='replace') as f:
    content = f.read()

files = []

# パターン1: ```lang:path\n...\n``` (最も一般的)
pattern1 = re.compile(
    r'```(?:[a-zA-Z0-9_+-]+):([^\n`]+)\n(.*?)```',
    re.DOTALL
)

# パターン2: // filename: path または # filename: path の後にコードブロック
pattern2 = re.compile(
    r'(?://|#)\s*(?:[Ff]ile(?:name)?|[Pp]ath):\s*([^\n]+)\n\s*```[a-zA-Z0-9_+-]*\n(.*?)```',
    re.DOTALL
)

# パターン3: **path/to/file** の後にコードブロック
pattern3 = re.compile(
    r'\*\*([a-zA-Z0-9_./-]+\.[a-zA-Z0-9]+)\*\*[^\n]*\n\s*```[a-zA-Z0-9_+-]*\n(.*?)```',
    re.DOTALL
)

# パターン4: `path/to/file` の見出しの後にコードブロック
pattern4 = re.compile(
    r'`([a-zA-Z0-9_./-]+\.[a-zA-Z0-9]+)`[^\n]*\n\s*```[a-zA-Z0-9_+-]*\n(.*?)```',
    re.DOTALL
)

seen_paths = set()

for pattern in [pattern1, pattern2, pattern3, pattern4]:
    for m in pattern.finditer(content):
        path = m.group(1).strip()
        code = m.group(2)

        # パスのクリーンアップ
        path = path.strip('`').strip('"').strip("'").strip()
        if path.startswith('./'):
            path = path[2:]

        # 基本バリデーション
        if not path or '..' in path or path.startswith('/'):
            continue
        if path in seen_paths:
            continue
        # ファイル拡張子があるかチェック
        if '.' not in os.path.basename(path):
            continue

        seen_paths.add(path)
        files.append({
            'path': path,
            'content': code,
            'size': len(code.encode('utf-8'))
        })

manifest = {'files': files, 'count': len(files)}
with open(manifest_file, 'w', encoding='utf-8') as f:
    json.dump(manifest, f, ensure_ascii=False, indent=2)
PYEOF

    if [[ ! -f "$tmp_manifest" ]]; then
        _fw2_log "WARN" "Python解析失敗 → Bashフォールバック"
        rm -f "$tmp_input" 2>/dev/null
        _fw2_parse_bash "$output_text" "$project_dir"
        return
    fi

    # マニフェストからファイルを書き出し
    local file_count
    file_count=$(python3 -c "import json; d=json.load(open('$tmp_manifest')); print(d['count'])" 2>/dev/null || echo "0")

    if [[ "$file_count" -eq 0 ]]; then
        _fw2_log "INFO" "コードブロック未検出 (0ファイル)"
        rm -f "$tmp_input" "$tmp_manifest" 2>/dev/null
        return
    fi

    _fw2_log "INFO" "${file_count}個のコードブロックを検出"

    # 各ファイルを書き出し
    python3 << 'WRITEPY' "$tmp_manifest" "$project_dir" "$FW2_BACKUP_DIR" 2>/dev/null
import json, sys, os, shutil

manifest_file = sys.argv[1]
project_dir = sys.argv[2]
backup_dir = sys.argv[3]

with open(manifest_file, 'r', encoding='utf-8') as f:
    manifest = json.load(f)

written = 0
skipped = []

for item in manifest['files']:
    path = item['path']
    content = item['content']

    full_path = os.path.join(project_dir, path)

    # パストラバーサル最終チェック
    real_proj = os.path.realpath(project_dir)
    real_target = os.path.realpath(os.path.dirname(full_path) if os.path.dirname(full_path) else project_dir)
    if not real_target.startswith(real_proj):
        skipped.append(path)
        continue

    # 危険ファイルスキップ
    basename = os.path.basename(path)
    if basename in ('.env', '.env.local', '.env.production') or basename.endswith(('.pem', '.key', '.p12')):
        skipped.append(path)
        continue

    # 既存ファイルバックアップ
    if os.path.exists(full_path):
        try:
            os.makedirs(backup_dir, exist_ok=True)
            backup_path = os.path.join(backup_dir, path.replace('/', '_'))
            shutil.copy2(full_path, backup_path)
        except: pass

    # ディレクトリ作成＆書き込み
    try:
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, 'w', encoding='utf-8') as f:
            f.write(content)
            if not content.endswith('\n'):
                f.write('\n')
        written += 1
    except Exception as e:
        skipped.append(f"{path}: {e}")

# 結果をJSONで出力
result = {'written': written, 'skipped': skipped}
print(json.dumps(result))
WRITEPY

    # 結果読み取り
    local result
    result=$(python3 << 'READPY' "$tmp_manifest" "$project_dir" "$FW2_BACKUP_DIR" 2>/dev/null || echo '{"written":0}')
import json, sys, os, shutil

manifest_file = sys.argv[1]
project_dir = sys.argv[2]
backup_dir = sys.argv[3]

with open(manifest_file, 'r', encoding='utf-8') as f:
    manifest = json.load(f)

written = 0
for item in manifest['files']:
    path = item['path']
    full_path = os.path.join(project_dir, path)
    if os.path.exists(full_path):
        written += 1

print(json.dumps({'written': written, 'total': manifest['count']}))
READPY

    local written_count
    written_count=$(echo "$result" | python3 -c "import json,sys; print(json.loads(sys.stdin.read()).get('written',0))" 2>/dev/null || echo "0")

    FW2_FILES_WRITTEN=$((FW2_FILES_WRITTEN + written_count))
    _fw2_log "OK" "${written_count}ファイルを書き出し完了"

    # クリーンアップ
    rm -f "$tmp_input" "$tmp_manifest" 2>/dev/null
}

# =============================================================================
# 3b. Bashフォールバック解析 — Python未検出時
# =============================================================================
_fw2_parse_bash() {
    local output_text="$1"
    local project_dir="$2"

    local current_path="" current_content="" in_code_block=false
    local pending_path=""  # v13.0: パターン2-4用の先読みパス
    local written_count=0

    while IFS= read -r line; do
        # コードブロック開始: パターン1 — ```lang:path
        if [[ "$in_code_block" == false && "$line" =~ ^\`\`\`[a-zA-Z0-9_+-]*:(.+)$ ]]; then
            current_path="${BASH_REMATCH[1]}"
            current_path="${current_path#./}"
            current_path=$(echo "$current_path" | tr -d '`' | tr -d '"' | tr -d "'" | xargs)
            current_content=""
            in_code_block=true
            pending_path=""
            continue
        fi

        # v13.0: パターン2 — // filename: path or # filename: path (次行の```を待つ)
        if [[ "$in_code_block" == false && "$line" =~ ^[[:space:]]*(//|#)[[:space:]]*(filename|file|path):[[:space:]]*(.+)$ ]]; then
            pending_path="${BASH_REMATCH[3]}"
            pending_path="${pending_path#./}"
            pending_path=$(echo "$pending_path" | tr -d '`' | tr -d '"' | tr -d "'" | xargs)
            continue
        fi

        # v13.0: パターン3 — **path/to/file.ext** (次行の```を待つ)
        if [[ "$in_code_block" == false && "$line" =~ ^\*\*([a-zA-Z0-9_./-]+\.[a-zA-Z0-9]+)\*\* ]]; then
            pending_path="${BASH_REMATCH[1]}"
            pending_path="${pending_path#./}"
            continue
        fi

        # v13.0: パターン4 — `path/to/file.ext` (次行の```を待つ)
        if [[ "$in_code_block" == false && "$line" =~ ^\`([a-zA-Z0-9_./-]+\.[a-zA-Z0-9]+)\` ]]; then
            pending_path="${BASH_REMATCH[1]}"
            pending_path="${pending_path#./}"
            continue
        fi

        # コードブロック開始 (パターン2-4用: 先読みパスがある状態で```を検出)
        if [[ "$in_code_block" == false && -n "$pending_path" && "$line" =~ ^\`\`\`[a-zA-Z0-9_+-]*$ ]]; then
            current_path="$pending_path"
            current_content=""
            in_code_block=true
            pending_path=""
            continue
        fi

        # 先読みパスなしで無関係な行 → pending_pathをリセット
        if [[ "$in_code_block" == false && -n "$pending_path" && ! "$line" =~ ^\`\`\` && ! "$line" =~ ^[[:space:]]*$ ]]; then
            pending_path=""
        fi

        # コードブロック終了
        if [[ "$in_code_block" == true && "$line" == '```' ]]; then
            in_code_block=false

            # ファイル書き出し
            if [[ -n "$current_path" ]] && fw2_validate_path "$current_path"; then
                local full_path="${project_dir}/${current_path}"
                mkdir -p "$(dirname "$full_path")" 2>/dev/null || true

                # バックアップ
                if [[ -f "$full_path" ]]; then
                    mkdir -p "$FW2_BACKUP_DIR" 2>/dev/null || true
                    cp "$full_path" "${FW2_BACKUP_DIR}/$(echo "$current_path" | tr '/' '_')" 2>/dev/null || true
                fi

                printf '%s\n' "$current_content" > "$full_path"
                written_count=$((written_count + 1))
                FW2_WRITTEN_LIST+=("$current_path")
            fi

            current_path=""
            current_content=""
            continue
        fi

        # コードブロック内のコンテンツ蓄積
        if [[ "$in_code_block" == true ]]; then
            if [[ -z "$current_content" ]]; then
                current_content="$line"
            else
                current_content="${current_content}"$'\n'"${line}"
            fi
        fi
    done <<< "$output_text"

    FW2_FILES_WRITTEN=$((FW2_FILES_WRITTEN + written_count))

    if [[ $written_count -gt 0 ]]; then
        _fw2_log "OK" "${written_count}ファイルを書き出し (Bashモード)"
    fi
}

# =============================================================================
# 4. fw2_smart_write(claude_output, project_dir, expected_file)
# =============================================================================
# v1互換API: fw_smart_write()の代替
fw2_smart_write() {
    local claude_output="$1"
    local project_dir="${2:-$FW2_PROJECT_DIR}"
    local expected_file="${3:-}"

    # コードブロックが含まれているかチェック
    if echo "$claude_output" | grep -qE '```[a-zA-Z0-9_+-]*:'; then
        fw2_parse_and_write "$claude_output" "$project_dir"
        return $?
    fi

    # コードブロックがない場合、expected_fileに直接書き出し
    if [[ -n "$expected_file" ]]; then
        local full_path="${project_dir}/${expected_file}"
        mkdir -p "$(dirname "$full_path")" 2>/dev/null || true
        printf '%s\n' "$claude_output" > "$full_path"
        FW2_FILES_WRITTEN=$((FW2_FILES_WRITTEN + 1))
        echo "1"
        return 0
    fi

    # v1にフォールバック
    if type -t fw_write_from_claude &>/dev/null; then
        fw_write_from_claude "$claude_output" "$project_dir"
        return $?
    fi

    echo "0"
}

# =============================================================================
# 5. fw2_report() — 書き出し結果レポート
# =============================================================================
fw2_report() {
    echo -e "\n  ${FW2_BOLD}${FW2_CYAN}[FileWriter v2 レポート]${FW2_NC}"
    echo -e "  書き出しファイル数: ${FW2_GREEN}${FW2_FILES_WRITTEN}${FW2_NC}"

    if [[ ${#FW2_WRITTEN_LIST[@]} -gt 0 ]]; then
        echo -e "  ファイル一覧:"
        for f in "${FW2_WRITTEN_LIST[@]}"; do
            echo -e "    ${FW2_GREEN}+${FW2_NC} ${f}"
        done
    fi

    if [[ ${#FW2_SKIPPED_LIST[@]} -gt 0 ]]; then
        echo -e "  スキップ:"
        for f in "${FW2_SKIPPED_LIST[@]}"; do
            echo -e "    ${FW2_YELLOW}-${FW2_NC} ${f}"
        done
    fi

    if [[ -n "$FW2_BACKUP_DIR" && -d "$FW2_BACKUP_DIR" ]]; then
        local backup_count
        backup_count=$(find "$FW2_BACKUP_DIR" -type f 2>/dev/null | wc -l | tr -d ' ')
        [[ "$backup_count" -gt 0 ]] && echo -e "  バックアップ: ${backup_count}ファイル (${FW2_BACKUP_DIR})"
    fi
}
