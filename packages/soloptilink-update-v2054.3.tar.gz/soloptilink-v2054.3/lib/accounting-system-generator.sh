#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v310.0 - Accounting System Generator
# =============================================================================
# 会計システム自動生成: 仕訳/総勘定元帳/貸借対照表/請求書管理
#
# 全globals: ASG_ prefix
# =============================================================================

[[ -n "${_ACCOUNTING_SYSTEM_GENERATOR_LOADED:-}" ]] && return 0
_ACCOUNTING_SYSTEM_GENERATOR_LOADED=1

declare -g ASG_VERSION="310.0"
declare -g ASG_INITIALIZED=false
declare -g ASG_GENERATED_COUNT=0
declare -g ENABLE_ACCOUNTING_SYSTEM_GENERATOR="${ENABLE_ACCOUNTING_SYSTEM_GENERATOR:-true}"

readonly ASG_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly ASG_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly ASG_BOLD="${CLR_BOLD:-\033[1m}"
readonly ASG_NC="${CLR_NC:-\033[0m}"

_asg_log() { echo -e "  ${ASG_CYAN}[ASG]${ASG_NC} $*" >&2; }
_asg_ok()  { echo -e "  ${ASG_GREEN}[ASG] OK${ASG_NC} $*" >&2; }

asg_init() { ASG_INITIALIZED=true; ASG_GENERATED_COUNT=0; return 0; }
asg_report() { [[ "$ASG_INITIALIZED" != "true" ]] && return 0; echo -e "\n  ${ASG_BOLD}--- Accounting System Generator v${ASG_VERSION} ---${ASG_NC}" >&2; echo -e "  生成数: ${ASG_GENERATED_COUNT}" >&2; }
asg_score() { [[ "$ASG_INITIALIZED" != "true" ]] && { echo "0"; return; }; local s=50; [[ $ASG_GENERATED_COUNT -ge 3 ]] && s=85; echo "$s"; }
asg_init_message() { echo -e "  ${ASG_GREEN}v${ASG_VERSION} accounting-system-generator: 会計システム自動生成${ASG_NC}" >&2; }

# =============================================================================
# _asg_generate_journal_entry() - Journal entry model
# =============================================================================
_asg_generate_journal_entry() {
    local project_dir="${1:-.}"
    _asg_log "仕訳モデル生成"

    local snippet='
// --- Accounting System Models (v310.0) ---
model Account {
  id        String      @id @default(cuid())
  code      String      @unique
  name      String
  type      AccountType
  parentId  String?
  balance   Int         @default(0)
  isActive  Boolean     @default(true)
  debitEntries  JournalLine[] @relation("DebitAccount")
  creditEntries JournalLine[] @relation("CreditAccount")
  createdAt DateTime    @default(now())
}

enum AccountType { ASSET LIABILITY EQUITY REVENUE EXPENSE }

model JournalEntry {
  id          String   @id @default(cuid())
  entryNo     String   @unique
  date        DateTime @db.Date
  description String
  lines       JournalLine[]
  status      JournalStatus @default(DRAFT)
  userId      String?
  reference   String?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}

enum JournalStatus { DRAFT POSTED VOIDED }

model JournalLine {
  id             String       @id @default(cuid())
  journalEntryId String
  journalEntry   JournalEntry @relation(fields: [journalEntryId], references: [id], onDelete: Cascade)
  debitAccountId  String?
  debitAccount    Account?     @relation("DebitAccount", fields: [debitAccountId], references: [id])
  creditAccountId String?
  creditAccount   Account?     @relation("CreditAccount", fields: [creditAccountId], references: [id])
  amount         Int
  memo           String?
}

model Invoice {
  id          String   @id @default(cuid())
  invoiceNo   String   @unique
  customerId  String?
  customerName String?
  issueDate   DateTime @db.Date
  dueDate     DateTime @db.Date
  status      InvoiceStatus @default(DRAFT)
  items       InvoiceItem[]
  subtotal    Int      @default(0)
  tax         Int      @default(0)
  total       Int      @default(0)
  paidAmount  Int      @default(0)
  notes       String?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}

enum InvoiceStatus { DRAFT SENT PAID PARTIALLY_PAID OVERDUE CANCELLED }

model InvoiceItem {
  id          String  @id @default(cuid())
  invoiceId   String
  invoice     Invoice @relation(fields: [invoiceId], references: [id], onDelete: Cascade)
  description String
  quantity    Int
  unitPrice   Int
  amount      Int
  taxRate     Float   @default(0.1)
}'

    mkdir -p "${project_dir}/prisma"
    local schema_file="${project_dir}/prisma/schema.prisma"
    if [[ -f "$schema_file" ]] && ! grep -q "model JournalEntry" "$schema_file" 2>/dev/null; then
        echo "$snippet" >> "$schema_file"
    fi

    ASG_GENERATED_COUNT=$((ASG_GENERATED_COUNT + 1))
    _asg_ok "仕訳モデル生成完了"
    return 0
}

# =============================================================================
# _asg_generate_ledger() - General ledger
# =============================================================================
_asg_generate_ledger() {
    local project_dir="${1:-.}"
    _asg_log "総勘定元帳API生成"

    local api_dir="${project_dir}/src/app/api/accounting/ledger"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const accountId = req.nextUrl.searchParams.get('accountId');
    const from = req.nextUrl.searchParams.get('from');
    const to = req.nextUrl.searchParams.get('to');

    if (!accountId) {
      // Return chart of accounts with balances
      const accounts = await prisma.account.findMany({ where: { isActive: true }, orderBy: { code: 'asc' } });
      const grouped = {
        ASSET: accounts.filter(a => a.type === 'ASSET'),
        LIABILITY: accounts.filter(a => a.type === 'LIABILITY'),
        EQUITY: accounts.filter(a => a.type === 'EQUITY'),
        REVENUE: accounts.filter(a => a.type === 'REVENUE'),
        EXPENSE: accounts.filter(a => a.type === 'EXPENSE'),
      };
      return NextResponse.json({ data: accounts, grouped });
    }

    // Return ledger entries for specific account
    const dateFilter: any = {};
    if (from) dateFilter.gte = new Date(from);
    if (to) dateFilter.lte = new Date(to);

    const debitEntries = await prisma.journalLine.findMany({
      where: { debitAccountId: accountId, journalEntry: { status: 'POSTED', ...(from || to ? { date: dateFilter } : {}) } },
      include: { journalEntry: { select: { entryNo: true, date: true, description: true } } },
      orderBy: { journalEntry: { date: 'asc' } },
    });

    const creditEntries = await prisma.journalLine.findMany({
      where: { creditAccountId: accountId, journalEntry: { status: 'POSTED', ...(from || to ? { date: dateFilter } : {}) } },
      include: { journalEntry: { select: { entryNo: true, date: true, description: true } } },
      orderBy: { journalEntry: { date: 'asc' } },
    });

    const totalDebit = debitEntries.reduce((s, e) => s + e.amount, 0);
    const totalCredit = creditEntries.reduce((s, e) => s + e.amount, 0);

    return NextResponse.json({ debitEntries, creditEntries, totalDebit, totalCredit, balance: totalDebit - totalCredit });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch ledger' }, { status: 500 });
  }
}
EOF

    ASG_GENERATED_COUNT=$((ASG_GENERATED_COUNT + 1))
    _asg_ok "総勘定元帳API生成完了"
    return 0
}

# =============================================================================
# _asg_generate_balance_sheet() - Balance sheet report
# =============================================================================
_asg_generate_balance_sheet() {
    local project_dir="${1:-.}"
    _asg_log "貸借対照表API生成"

    local api_dir="${project_dir}/src/app/api/accounting/reports"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const type = req.nextUrl.searchParams.get('type') || 'balance-sheet';
    const asOfDate = req.nextUrl.searchParams.get('asOf') || new Date().toISOString().split('T')[0];

    const accounts = await prisma.account.findMany({ where: { isActive: true }, orderBy: { code: 'asc' } });

    if (type === 'balance-sheet') {
      const assets = accounts.filter(a => a.type === 'ASSET');
      const liabilities = accounts.filter(a => a.type === 'LIABILITY');
      const equity = accounts.filter(a => a.type === 'EQUITY');

      const totalAssets = assets.reduce((s, a) => s + a.balance, 0);
      const totalLiabilities = liabilities.reduce((s, a) => s + a.balance, 0);
      const totalEquity = equity.reduce((s, a) => s + a.balance, 0);

      return NextResponse.json({
        type: 'balance-sheet', asOf: asOfDate,
        assets: { items: assets, total: totalAssets },
        liabilities: { items: liabilities, total: totalLiabilities },
        equity: { items: equity, total: totalEquity },
        balanced: totalAssets === (totalLiabilities + totalEquity),
      });
    }

    if (type === 'income-statement') {
      const revenue = accounts.filter(a => a.type === 'REVENUE');
      const expenses = accounts.filter(a => a.type === 'EXPENSE');
      const totalRevenue = revenue.reduce((s, a) => s + Math.abs(a.balance), 0);
      const totalExpenses = expenses.reduce((s, a) => s + Math.abs(a.balance), 0);

      return NextResponse.json({
        type: 'income-statement',
        revenue: { items: revenue, total: totalRevenue },
        expenses: { items: expenses, total: totalExpenses },
        netIncome: totalRevenue - totalExpenses,
      });
    }

    return NextResponse.json({ error: 'Unknown report type' }, { status: 400 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to generate report' }, { status: 500 });
  }
}
EOF

    ASG_GENERATED_COUNT=$((ASG_GENERATED_COUNT + 1))
    _asg_ok "貸借対照表API生成完了"
    return 0
}

# =============================================================================
# _asg_generate_invoice_system() - Invoice management
# =============================================================================
_asg_generate_invoice_system() {
    local project_dir="${1:-.}"
    _asg_log "請求書管理API生成"

    local api_dir="${project_dir}/src/app/api/accounting/invoices"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

function generateInvoiceNo() {
  const d = new Date();
  return `INV-${d.getFullYear()}${String(d.getMonth()+1).padStart(2,'0')}-${Math.random().toString(36).substr(2,5).toUpperCase()}`;
}

export async function GET(req: NextRequest) {
  try {
    const status = req.nextUrl.searchParams.get('status');
    const where: any = {};
    if (status) where.status = status;
    const invoices = await prisma.invoice.findMany({ where, include: { items: true }, orderBy: { createdAt: 'desc' } });
    const summary = {
      total: invoices.length,
      totalAmount: invoices.reduce((s, i) => s + i.total, 0),
      paid: invoices.filter(i => i.status === 'PAID').reduce((s, i) => s + i.total, 0),
      outstanding: invoices.filter(i => ['SENT', 'PARTIALLY_PAID', 'OVERDUE'].includes(i.status)).reduce((s, i) => s + i.total - i.paidAmount, 0),
    };
    return NextResponse.json({ data: invoices, summary });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch invoices' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { customerName, customerId, issueDate, dueDate, items, notes } = await req.json();
    if (!items?.length) return NextResponse.json({ error: 'items required' }, { status: 400 });

    const processedItems = items.map((i: any) => ({
      description: i.description, quantity: i.quantity, unitPrice: i.unitPrice,
      amount: i.quantity * i.unitPrice, taxRate: i.taxRate ?? 0.1,
    }));
    const subtotal = processedItems.reduce((s: number, i: any) => s + i.amount, 0);
    const tax = processedItems.reduce((s: number, i: any) => s + Math.round(i.amount * i.taxRate), 0);

    const invoice = await prisma.invoice.create({
      data: {
        invoiceNo: generateInvoiceNo(), customerName, customerId,
        issueDate: new Date(issueDate || Date.now()), dueDate: new Date(dueDate || Date.now() + 30 * 86400000),
        subtotal, tax, total: subtotal + tax, notes,
        items: { create: processedItems },
      },
      include: { items: true },
    });
    return NextResponse.json(invoice, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create invoice' }, { status: 500 });
  }
}
EOF

    ASG_GENERATED_COUNT=$((ASG_GENERATED_COUNT + 1))
    _asg_ok "請求書管理API生成完了"
    return 0
}

# =============================================================================
# Module Registration
# =============================================================================
_mr_register \
    --name "accounting-system-generator" \
    --version "310.0" \
    --description "会計システム自動生成（仕訳/元帳/貸借対照表/請求書）" \
    --init "asg_init" \
    --report "asg_report" \
    --score "asg_score" \
    --enable-var "ENABLE_ACCOUNTING_SYSTEM_GENERATOR" \
    --cli-flags "--accounting:--no-accounting" \
    --init-msg "asg_init_message"
