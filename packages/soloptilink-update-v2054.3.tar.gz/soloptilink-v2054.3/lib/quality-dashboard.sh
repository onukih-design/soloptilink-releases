#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v110.0 - Quality Dashboard
# 全品質メトリクスを集約し、包括的レポートを生成
#
# 機能:
#   1. セッションレポート生成（全モジュールスコア集約）
#   2. トレンドレポート生成（品質推移）
#   3. プロバイダーレポート（プロバイダー別品質/コスト）
#   4. JSON出力（機械可読）
#   5. ASCIIダッシュボード表示
#
# v110.0: AGI Integration & Governance - Week 4
# ============================================================

[[ -n "${_QD_LOADED:-}" ]] && return 0
_QD_LOADED=1

# --- グローバル状態 ---
QD_VERSION="200.0"
QD_INITIALIZED=false
QD_BASE_DIR="${HOME}/.soloptilink/quality-dashboard"
QD_REPORTS_DIR=""

# --- 集約スコア ---
declare -A _QD_SCORES=()
QD_LAST_COMPOSITE=0

# ============================================================
# 初期化
# ============================================================
qd_init() {
    QD_REPORTS_DIR="${QD_BASE_DIR}/reports"
    mkdir -p "$QD_REPORTS_DIR" 2>/dev/null || true
    QD_INITIALIZED=true
    return 0
}

# ============================================================
# セッションレポート生成
# project_dirに対して利用可能な全スコアモジュールを呼び出し
# マークダウンレポートを生成
# ============================================================
qd_generate_session_report() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _QD_SCORES=()
    local total_score=0
    local score_count=0

    # --- 各モジュールのスコア収集 ---

    # Real Validator
    if type -t rv_score &>/dev/null; then
        local s
        s=$(rv_score 2>/dev/null || echo "0")
        s=$(_qd_clamp "$s")
        _QD_SCORES["rv"]="$s"
        total_score=$((total_score + s))
        score_count=$((score_count + 1))
    fi

    # Live Verification
    if type -t lv_score &>/dev/null; then
        local s
        s=$(lv_score 2>/dev/null || echo "0")
        s=$(_qd_clamp "$s")
        _QD_SCORES["lv"]="$s"
        total_score=$((total_score + s))
        score_count=$((score_count + 1))
    fi

    # Runtime Test Executor
    if type -t rte_score &>/dev/null; then
        local s
        s=$(rte_score 2>/dev/null || echo "0")
        s=$(_qd_clamp "$s")
        _QD_SCORES["rte"]="$s"
        total_score=$((total_score + s))
        score_count=$((score_count + 1))
    fi

    # E2E Runner
    if type -t e2e_score &>/dev/null; then
        local s
        s=$(e2e_score 2>/dev/null || echo "0")
        s=$(_qd_clamp "$s")
        _QD_SCORES["e2e"]="$s"
        total_score=$((total_score + s))
        score_count=$((score_count + 1))
    fi

    # Migration Tester
    if type -t mgt_score &>/dev/null; then
        local s
        s=$(mgt_score 2>/dev/null || echo "0")
        s=$(_qd_clamp "$s")
        _QD_SCORES["mgt"]="$s"
        total_score=$((total_score + s))
        score_count=$((score_count + 1))
    fi

    # Security Scanner
    if type -t ss_score &>/dev/null; then
        local s
        s=$(ss_score 2>/dev/null || echo "0")
        s=$(_qd_clamp "$s")
        _QD_SCORES["ss"]="$s"
        total_score=$((total_score + s))
        score_count=$((score_count + 1))
    fi

    # Accessibility
    if type -t a11y_score &>/dev/null; then
        local s
        s=$(a11y_score 2>/dev/null || echo "0")
        s=$(_qd_clamp "$s")
        _QD_SCORES["a11y"]="$s"
        total_score=$((total_score + s))
        score_count=$((score_count + 1))
    fi

    # Performance Profiler
    if type -t pm_score &>/dev/null; then
        local s
        s=$(pm_score 2>/dev/null || echo "0")
        s=$(_qd_clamp "$s")
        _QD_SCORES["pm"]="$s"
        total_score=$((total_score + s))
        score_count=$((score_count + 1))
    fi

    # Provider Verification
    if type -t pv_score &>/dev/null; then
        local s
        s=$(pv_score 2>/dev/null || echo "0")
        s=$(_qd_clamp "$s")
        _QD_SCORES["pv"]="$s"
        total_score=$((total_score + s))
        score_count=$((score_count + 1))
    fi

    # AI Governance
    if type -t aig_score &>/dev/null; then
        local s
        s=$(aig_score 2>/dev/null || echo "0")
        s=$(_qd_clamp "$s")
        _QD_SCORES["aig"]="$s"
        total_score=$((total_score + s))
        score_count=$((score_count + 1))
    fi

    # AI Provider
    if type -t aip_score &>/dev/null; then
        local s
        s=$(aip_score 2>/dev/null || echo "0")
        s=$(_qd_clamp "$s")
        _QD_SCORES["aip"]="$s"
        total_score=$((total_score + s))
        score_count=$((score_count + 1))
    fi

    # Benchmark Suite
    if type -t bs_score &>/dev/null; then
        local s
        s=$(bs_score 2>/dev/null || echo "0")
        s=$(_qd_clamp "$s")
        _QD_SCORES["bs"]="$s"
        total_score=$((total_score + s))
        score_count=$((score_count + 1))
    fi

    # Composite score
    local composite=0
    if [[ $score_count -gt 0 ]]; then
        composite=$((total_score / score_count))
    fi
    QD_LAST_COMPOSITE=$composite

    # --- マークダウンレポート生成 ---
    local report_file="${QD_REPORTS_DIR}/session_$(date '+%Y%m%d_%H%M%S').md"

    local report="# Quality Dashboard Report
Generated: $(date '+%Y-%m-%d %H:%M:%S')
Session: ${SESSION_ID:-unknown}
Project: ${project_dir}

## Composite Score: ${composite}/100

## Module Scores
| Module | Score | Grade |
|--------|-------|-------|"

    # ソート済みで表示
    for key in $(echo "${!_QD_SCORES[@]}" | tr ' ' '\n' | sort); do
        local val="${_QD_SCORES[$key]}"
        local grade
        grade=$(_qd_grade "$val")
        report="${report}
| ${key} | ${val} | ${grade} |"
    done

    report="${report}

## Summary
- Modules evaluated: ${score_count}
- Average score: ${composite}
- Provider: ${AIP_PROVIDER:-${AIP_DEFAULT_PROVIDER:-claude-cli}}
- Domain: ${DOMAIN_TYPE:-general}
"

    mkdir -p "$QD_REPORTS_DIR" 2>/dev/null || true
    echo "$report" > "$report_file" 2>/dev/null

    # 永続化用JSONL
    _qd_persist_session "$composite" "$score_count"

    echo "$report"
    return 0
}

# ============================================================
# トレンドレポート
# ============================================================
qd_generate_trend_report() {
    local domain="${1:-general}"
    local max_sessions="${2:-10}"

    # qt_get_trend が利用可能ならそれを使う
    if type -t qt_get_trend &>/dev/null; then
        echo "=== Quality Trend Report (via Quality Tracker) ==="
        qt_get_trend "$domain" "$max_sessions" 2>/dev/null
        return $?
    fi

    # フォールバック: 永続化データから自力生成
    local data_file="${QD_BASE_DIR}/sessions.jsonl"
    if [[ ! -f "$data_file" ]]; then
        echo "No trend data available yet."
        return 0
    fi

    echo "=== Quality Trend Report ==="
    echo "  Domain: ${domain}"
    echo "  ---"

    local count=0
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        # ドメインフィルタ
        local rec_domain
        rec_domain=$(echo "$line" | sed -n 's/.*"domain":"\([^"]*\)".*/\1/p')
        if [[ "$domain" != "all" && "$rec_domain" != "$domain" ]]; then
            continue
        fi

        local ts score modules
        ts=$(echo "$line" | sed -n 's/.*"timestamp":"\([^"]*\)".*/\1/p')
        score=$(echo "$line" | sed -n 's/.*"composite_score":\([0-9]*\).*/\1/p')
        modules=$(echo "$line" | sed -n 's/.*"modules_count":\([0-9]*\).*/\1/p')

        local bar
        bar=$(_qd_bar "$score" 40)
        printf "  %s  %3s/100  %s  (%s modules)\n" "${ts:-?}" "${score:-0}" "$bar" "${modules:-0}"

        count=$((count + 1))
        [[ $count -ge $max_sessions ]] && break
    done < <(tail -n "$((max_sessions * 3))" "$data_file" 2>/dev/null)

    if [[ $count -eq 0 ]]; then
        echo "  No sessions found for domain '${domain}'."
    fi

    return 0
}

# ============================================================
# プロバイダーレポート
# ============================================================
qd_generate_provider_report() {
    echo "=== Provider Performance Report ==="

    # aip_get_provider_stats があれば使う
    if type -t aip_get_provider_stats &>/dev/null; then
        aip_get_provider_stats 2>/dev/null
        return $?
    fi

    # フォールバック: AIPの基本情報
    if type -t aip_list_providers &>/dev/null; then
        echo "  Registered providers:"
        aip_list_providers 2>/dev/null
    fi

    if type -t aip_quality_report &>/dev/null; then
        echo ""
        aip_quality_report 2>/dev/null
    fi

    echo ""
    echo "  Session stats:"
    echo "    Total AI calls: ${AIP_CALL_COUNT:-0}"
    echo "    Successful: ${AIP_TOTAL_CALLS_OK:-0}"
    echo "    Failed: ${AIP_TOTAL_CALLS_FAIL:-0}"
    if [[ ${AIP_CALL_COUNT:-0} -gt 0 ]]; then
        local success_rate=$(( (${AIP_TOTAL_CALLS_OK:-0} * 100) / ${AIP_CALL_COUNT:-1} ))
        echo "    Success rate: ${success_rate}%"
    fi

    return 0
}

# ============================================================
# JSON出力
# ============================================================
qd_export_json() {
    local report_text="${1:-}"

    # スコアをJSON形式で出力
    local json="{\"timestamp\":\"$(date '+%Y-%m-%dT%H:%M:%S')\",\"session\":\"${SESSION_ID:-unknown}\",\"composite_score\":${QD_LAST_COMPOSITE},\"scores\":{"

    local first=true
    for key in $(echo "${!_QD_SCORES[@]}" | tr ' ' '\n' | sort); do
        local val="${_QD_SCORES[$key]}"
        if $first; then
            first=false
        else
            json="${json},"
        fi
        json="${json}\"${key}\":${val}"
    done

    json="${json}},\"provider\":\"${AIP_PROVIDER:-${AIP_DEFAULT_PROVIDER:-claude-cli}}\",\"domain\":\"${DOMAIN_TYPE:-general}\"}"

    echo "$json"
    return 0
}

# ============================================================
# ASCIIダッシュボード表示
# ============================================================
qd_display_dashboard() {
    local width=50

    echo "" >&2
    echo "  ============================================" >&2
    echo "   Quality Dashboard  v${QD_VERSION}" >&2
    echo "  ============================================" >&2
    echo "" >&2

    if [[ ${#_QD_SCORES[@]} -eq 0 ]]; then
        echo "  No scores collected yet. Run qd_generate_session_report first." >&2
        echo "" >&2
        return 0
    fi

    # コンポジットスコア表示
    local composite_bar
    composite_bar=$(_qd_bar "$QD_LAST_COMPOSITE" "$width")
    local composite_grade
    composite_grade=$(_qd_grade "$QD_LAST_COMPOSITE")
    printf "  COMPOSITE  %3d/100  %s  [%s]\n" "$QD_LAST_COMPOSITE" "$composite_bar" "$composite_grade" >&2
    echo "  --------------------------------------------" >&2

    # 各モジュールスコアをバーチャートで表示
    for key in $(echo "${!_QD_SCORES[@]}" | tr ' ' '\n' | sort); do
        local val="${_QD_SCORES[$key]}"
        local bar
        bar=$(_qd_bar "$val" "$width")
        local grade
        grade=$(_qd_grade "$val")
        printf "  %-10s %3d/100  %s  [%s]\n" "$key" "$val" "$bar" "$grade" >&2
    done

    echo "  --------------------------------------------" >&2
    echo "  Modules: ${#_QD_SCORES[@]}  |  Provider: ${AIP_PROVIDER:-${AIP_DEFAULT_PROVIDER:-cli}}" >&2
    echo "  Session: ${SESSION_ID:-unknown}" >&2
    echo "  ============================================" >&2
    echo "" >&2

    return 0
}

# ============================================================
# 内部ヘルパー
# ============================================================

_qd_clamp() {
    local v="$1"
    v=$(echo "$v" | grep -oE '^[0-9]+' | head -1)
    v=${v:-0}
    [[ $v -lt 0 ]] && v=0
    [[ $v -gt 100 ]] && v=100
    echo "$v"
}

_qd_grade() {
    local score="$1"
    score=${score:-0}
    if [[ $score -ge 90 ]]; then
        echo "A+"
    elif [[ $score -ge 80 ]]; then
        echo "A"
    elif [[ $score -ge 70 ]]; then
        echo "B"
    elif [[ $score -ge 60 ]]; then
        echo "C"
    elif [[ $score -ge 50 ]]; then
        echo "D"
    else
        echo "F"
    fi
}

# ASCIIバーチャート生成
_qd_bar() {
    local score="$1"
    local max_width="${2:-40}"
    score=${score:-0}

    local filled=$((score * max_width / 100))
    local empty=$((max_width - filled))

    local bar=""
    local i=0
    while [[ $i -lt $filled ]]; do
        bar="${bar}#"
        i=$((i + 1))
    done
    while [[ $i -lt $max_width ]]; do
        bar="${bar}-"
        i=$((i + 1))
    done

    echo "[${bar}]"
}

# セッション結果永続化
_qd_persist_session() {
    local composite="$1"
    local modules_count="$2"

    local data_file="${QD_BASE_DIR}/sessions.jsonl"
    mkdir -p "$QD_BASE_DIR" 2>/dev/null || true

    local scores_json=""
    local first=true
    for key in "${!_QD_SCORES[@]}"; do
        if $first; then first=false; else scores_json="${scores_json},"; fi
        scores_json="${scores_json}\"${key}\":${_QD_SCORES[$key]}"
    done

    local record="{\"timestamp\":\"$(date '+%Y-%m-%dT%H:%M:%S')\",\"session\":\"${SESSION_ID:-unknown}\",\"composite_score\":${composite},\"modules_count\":${modules_count},\"domain\":\"${DOMAIN_TYPE:-general}\",\"provider\":\"${AIP_PROVIDER:-${AIP_DEFAULT_PROVIDER:-claude-cli}}\",\"scores\":{${scores_json}}}"

    echo "$record" >> "$data_file" 2>/dev/null || true
}

# ============================================================
# レポート
# ============================================================
qd_report() {
    echo "=== Quality Dashboard v${QD_VERSION} ==="
    echo "  Last composite score: ${QD_LAST_COMPOSITE}/100"
    echo "  Collected scores: ${#_QD_SCORES[@]}"
    if [[ -f "${QD_BASE_DIR}/sessions.jsonl" ]]; then
        local session_count
        session_count=$(wc -l < "${QD_BASE_DIR}/sessions.jsonl" 2>/dev/null | tr -d ' ')
        echo "  Historical sessions: ${session_count:-0}"
    fi
}

qd_score() {
    # ダッシュボード自体のスコア = コンポジットスコアを反映
    if [[ $QD_LAST_COMPOSITE -gt 0 ]]; then
        echo "$QD_LAST_COMPOSITE"
    else
        local base=50
        [[ ${#_QD_SCORES[@]} -gt 0 ]] && base=$((base + 25))
        [[ -f "${QD_BASE_DIR}/sessions.jsonl" ]] && base=$((base + 15))
        [[ $base -gt 100 ]] && base=100
        echo "$base"
    fi
}

# ============================================================
# v194: HTML quality dashboard
# HTMLベースの品質ダッシュボード生成
# ============================================================
qd_generate_html_report() {
    local output_file="${1:-${HOME}/.soloptilink/dashboard/index.html}"
    local history_dir="${HOME}/.soloptilink/benchmarks"

    mkdir -p "$(dirname "$output_file")"

    cat > "$output_file" << 'HTMLEOF'
<!DOCTYPE html>
<html lang="ja">
<head>
<meta charset="UTF-8">
<title>SoloptiLinkAI Quality Dashboard</title>
<style>
body { font-family: -apple-system, BlinkMacSystemFont, sans-serif; max-width: 900px; margin: 0 auto; padding: 20px; background: #1a1a2e; color: #eee; }
h1 { color: #e94560; }
.card { background: #16213e; border-radius: 8px; padding: 20px; margin: 10px 0; }
.score { font-size: 48px; font-weight: bold; }
.good { color: #0f3460; } .ok { color: #e94560; } .bad { color: #ff0000; }
table { width: 100%; border-collapse: collapse; }
th, td { padding: 8px; text-align: left; border-bottom: 1px solid #333; }
</style>
</head>
<body>
<h1>SoloptiLinkAI Quality Dashboard v194</h1>
<div class="card">
<h2>Latest Build</h2>
<p>Version: VVERSION_PLACEHOLDER</p>
<p>Date: VDATE_PLACEHOLDER</p>
</div>
</body>
</html>
HTMLEOF

    # Replace placeholders
    sed -i '' "s/VVERSION_PLACEHOLDER/$(grep 'VERSION=' "${SCRIPT_DIR:-}/chain.sh" 2>/dev/null | head -1 | grep -oE '[0-9.]+' || echo 'unknown')/" "$output_file" 2>/dev/null || true
    sed -i '' "s/VDATE_PLACEHOLDER/$(date '+%Y-%m-%d %H:%M')/" "$output_file" 2>/dev/null || true

    echo -e "  [v194] ダッシュボード生成: $output_file" >&2
}

# ============================================================
# Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "quality-dashboard" \
        --version "$QD_VERSION" \
        --description "品質ダッシュボード - 全メトリクス集約レポート・トレンド分析 + v194 HTML Dashboard" \
        --init "qd_init" \
        --report "qd_report" \
        --score "qd_score" \
        --enable-var "ENABLE_QD" \
        --cli-flags "--quality-dashboard:--no-quality-dashboard"
fi

# v2003.1: source時のexit codeを確実に0にする
true
