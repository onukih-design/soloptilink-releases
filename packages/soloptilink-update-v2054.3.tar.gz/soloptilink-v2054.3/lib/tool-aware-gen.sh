#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v60.0 - Tool-Aware Generation
#
# Claude CLI の --tools フラグを活用し、コード生成時に
# Claude 自身がファイルシステムに直接アクセスできるようにする。
#
# 従来: prompt → Claude → テキスト出力 → regex抽出 → ファイル書込
# v60.0: prompt → Claude(+tools) → Claude自身がファイル読み書き
#
# メリット:
# - 既存コードを読みながら生成（整合性UP）
# - ファイルを直接書き込み（抽出エラーゼロ）
# - ディレクトリ構造を把握した上で適切な配置
#
# Claude CLI --tools オプション:
#   Bash, Read, Write, Edit, Glob, Grep, WebSearch 等
# ============================================================

[[ -n "${_TOOL_AWARE_GEN_LOADED:-}" ]] && return 0
_TOOL_AWARE_GEN_LOADED=1

# --- Configuration ---
TAG_ENABLE_TOOLS="${TAG_ENABLE_TOOLS:-true}"
TAG_TOOLS_LIST="${TAG_TOOLS_LIST:-Bash,Read,Write,Edit,Glob,Grep}"
TAG_SAFE_MODE="${TAG_SAFE_MODE:-true}"       # 安全モード（Write/Editのみプロジェクト内に制限）
TAG_READ_CONTEXT="${TAG_READ_CONTEXT:-true}" # 既存コード読み取り有効
TAG_DIRECT_WRITE="${TAG_DIRECT_WRITE:-true}" # 直接ファイル書き込み有効
TAG_MAX_FILES="${TAG_MAX_FILES:-50}"         # 1回の生成で書き込む最大ファイル数

# --- State ---
TAG_CALL_COUNT=0
TAG_TOOLS_USED=0
TAG_FILES_WRITTEN=0
TAG_READ_OPS=0
TAG_WRITE_OPS=0

# ============================================================
# 初期化
# ============================================================
tag_init() {
    TAG_CALL_COUNT=0
    TAG_TOOLS_USED=0
    TAG_FILES_WRITTEN=0
    TAG_READ_OPS=0
    TAG_WRITE_OPS=0
    return 0
}

# ============================================================
# --tools フラグ構築
# タスク種別に応じて適切なツールセットを選択
# ============================================================
tag_build_tools_flags() {
    local task_type="${1:-implementation}"
    local tools=""

    case "$task_type" in
        # 実装タスク: 全ツール
        implementation|backend|frontend|fullstack)
            tools="Bash,Read,Write,Edit,Glob,Grep"
            ;;
        # 解析タスク: 読み取り系のみ
        analysis|review|audit)
            tools="Read,Glob,Grep,Bash"
            ;;
        # 修正タスク: 読み取り＋編集
        fix|heal|repair)
            tools="Read,Edit,Glob,Grep,Bash"
            ;;
        # テストタスク: 読み取り＋実行
        test|verify)
            tools="Read,Glob,Grep,Bash"
            ;;
        # 設計タスク: 読み取り＋WebSearch
        design|blueprint)
            tools="Read,Glob,Grep"
            ;;
        # カスタム
        *)
            tools="${TAG_TOOLS_LIST}"
            ;;
    esac

    echo "$tools"
}

# ============================================================
# Tool-Aware プロンプト構築
# Claudeがツールを使って自律的にコード生成するためのプロンプト
# ============================================================
tag_build_prompt() {
    local task_desc="$1"
    local project_dir="$2"
    local task_type="${3:-implementation}"

    cat << PROMPT
# Task
${task_desc}

# Project Directory
${project_dir}

# Instructions
You have direct access to the file system through your tools.

## Step 1: Understand existing code
- Use Glob to find relevant files
- Use Read to understand existing code structure, patterns, and conventions
- Use Grep to find related implementations

## Step 2: Plan changes
- Identify which files need to be created or modified
- Ensure consistency with existing code style

## Step 3: Implement
- Use Write for new files
- Use Edit for modifications to existing files
- Use Bash to run validation commands (npm install, tsc, etc.)

## Rules
- NEVER overwrite files without reading them first
- Follow existing code patterns and conventions
- All file paths must be within: ${project_dir}
- Maximum ${TAG_MAX_FILES} files per generation
- Run type checking after writing TypeScript files
PROMPT
}

# ============================================================
# Tool-Aware Generation 実行
# claude CLI を --tools 付きで呼び出す
# ============================================================
tag_generate() {
    local task_desc="$1"
    local project_dir="$2"
    local task_type="${3:-implementation}"
    local output_file="${4:-}"

    TAG_CALL_COUNT=$((TAG_CALL_COUNT + 1))

    local tools
    tools=$(tag_build_tools_flags "$task_type")

    local prompt
    prompt=$(tag_build_prompt "$task_desc" "$project_dir" "$task_type")

    # コマンド構築
    local -a cmd_args=()
    cmd_args+=("claude" "-p")
    cmd_args+=("--dangerously-skip-permissions")

    # --tools フラグ
    if [[ "${TAG_ENABLE_TOOLS}" == "true" ]]; then
        cmd_args+=("--allowedTools" "$tools")
        TAG_TOOLS_USED=$((TAG_TOOLS_USED + 1))
    fi

    # System Prompt（Claude Bridge連携）
    if type -t cb2_build_system_prompt &>/dev/null; then
        local sys_prompt
        sys_prompt=$(cb2_build_system_prompt "implementation" 2>/dev/null || true)
        if [[ -n "$sys_prompt" ]]; then
            cmd_args+=("--system-prompt" "$sys_prompt")
        fi
    fi

    # Fallback Model
    cmd_args+=("--fallback-model" "claude-sonnet-4-20250514")

    # Budget
    local budget="${TAG_BUDGET:-2.00}"
    cmd_args+=("--max-budget-usd" "$budget")

    # Output format
    cmd_args+=("--output-format" "text")

    # プロンプト
    cmd_args+=("$prompt")

    # 実行
    local result
    if [[ -n "$output_file" ]]; then
        result=$(timeout 300 "${cmd_args[@]}" 2>/dev/null) || true
        echo "$result" > "$output_file"
    else
        result=$(timeout 300 "${cmd_args[@]}" 2>/dev/null) || true
        echo "$result"
    fi

    return 0
}

# ============================================================
# 既存コード読み取り＋差分生成
# 既存ファイルを読んでから修正を生成
# ============================================================
tag_read_and_fix() {
    local file_path="$1"
    local fix_instruction="$2"
    local project_dir="${3:-.}"

    TAG_READ_OPS=$((TAG_READ_OPS + 1))

    local prompt
    prompt=$(cat << PROMPT
# Fix Task
Fix the following file based on the instruction.

## File to fix
${file_path}

## Instruction
${fix_instruction}

## Steps
1. Use Read to read the file at: ${file_path}
2. Analyze the issue
3. Use Edit to apply the fix (use exact string matching)
4. Use Bash to verify the fix compiles/passes

## Project directory
${project_dir}
PROMPT
    )

    local -a cmd_args=()
    cmd_args+=("claude" "-p" "--dangerously-skip-permissions")
    cmd_args+=("--allowedTools" "Read,Edit,Bash,Grep")
    cmd_args+=("--fallback-model" "claude-sonnet-4-20250514")
    cmd_args+=("--max-budget-usd" "1.00")
    cmd_args+=("--output-format" "text")
    cmd_args+=("$prompt")

    timeout 180 "${cmd_args[@]}" 2>/dev/null || true
    return 0
}

# ============================================================
# Scaffold + Generate（プロジェクト骨格＋コード一括生成）
# Claudeにディレクトリ作成から実装まで一気にやらせる
# ============================================================
tag_scaffold_and_generate() {
    local task_desc="$1"
    local project_dir="$2"
    local tech_stack="${3:-nextjs}"

    local prompt
    prompt=$(cat << PROMPT
# Full Project Generation
Create a complete project from scratch.

## Task
${task_desc}

## Tech Stack
${tech_stack}

## Target Directory
${project_dir}

## Steps
1. Use Bash to create the project directory structure: mkdir -p ${project_dir}/{src,public,prisma}
2. Use Write to create package.json, tsconfig.json, and config files
3. Use Write to create prisma/schema.prisma with the data model
4. Use Write to create all source files (components, API routes, services)
5. Use Bash to run: cd ${project_dir} && npm install
6. Use Bash to run: cd ${project_dir} && npx tsc --noEmit
7. If there are errors, use Edit to fix them and re-run step 6

## Quality Requirements
- TypeScript strict mode
- Zod validation on all API inputs
- Prisma for database access
- Error handling on all async operations
- No 'any' types
- No mock data or placeholder implementations
PROMPT
    )

    local -a cmd_args=()
    cmd_args+=("claude" "-p" "--dangerously-skip-permissions")
    cmd_args+=("--allowedTools" "Bash,Read,Write,Edit,Glob,Grep")
    cmd_args+=("--system-prompt" "You are a senior full-stack engineer. Generate production-ready code only. Never use placeholder data or TODO comments. Every function must have real implementation.")
    cmd_args+=("--fallback-model" "claude-sonnet-4-20250514")
    cmd_args+=("--max-budget-usd" "5.00")
    cmd_args+=("--output-format" "text")
    cmd_args+=("$prompt")

    timeout 600 "${cmd_args[@]}" 2>/dev/null || true
    return 0
}

# ============================================================
# レポート / スコア
# ============================================================
tag_report() {
    echo -e "\n  ${BOLD:-}═══ Tool-Aware Generation v60.0 レポート ═══${NC:-}"
    echo -e "  生成呼び出し回数   : ${TAG_CALL_COUNT}"
    echo -e "  ツール使用回数     : ${TAG_TOOLS_USED}"
    echo -e "  Read操作数         : ${TAG_READ_OPS}"
    echo -e "  Write操作数        : ${TAG_WRITE_OPS}"
    echo -e "  書き込みファイル数 : ${TAG_FILES_WRITTEN}"
}

tag_score() {
    if [[ $TAG_CALL_COUNT -eq 0 ]]; then
        echo "50"
    elif [[ $TAG_TOOLS_USED -gt 0 ]]; then
        echo "90"
    else
        echo "70"
    fi
}

# ============================================================
# v59.0: Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "tool-aware-gen" \
        --version "60.0" \
        --description "Claude --tools直接ファイルI/O×自律コード生成" \
        --init "tag_init" \
        --report "tag_report" \
        --score "tag_score" \
        --enable-var "ENABLE_TOOL_AWARE_GEN" \
        --cli-flags "--tool-aware:--no-tool-aware"
fi

# v2003.1: source時のexit codeを確実に0にする
true
