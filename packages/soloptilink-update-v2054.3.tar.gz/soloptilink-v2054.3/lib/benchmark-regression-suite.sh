#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v468.0 - Benchmark Regression Suite
# =============================================================================
# ベンチマークリグレッションスイート: ベンチマーク生成、実行、結果比較。
#
# Functions:
#   _brs_init()               - Initialize
#   _brs_generate_benchmarks() - Generate benchmark test files
#   _brs_run_suite()           - Run benchmark suite
#   _brs_compare_results()     - Compare benchmark results
#   _brs_report() / _brs_score()
# =============================================================================

[[ -n "${_BRS_LOADED:-}" ]] && return 0; _BRS_LOADED=1

declare -g BRS_VERSION="468.0"
BRS_GENERATED=0; BRS_ERRORS=0; BRS_FILES_WRITTEN=0
BRS_BENCHMARKS_OK=false; BRS_RUNNER_OK=false; BRS_COMPARE_OK=false

_brs_init() {
    BRS_GENERATED=0; BRS_ERRORS=0; BRS_FILES_WRITTEN=0
    BRS_BENCHMARKS_OK=false; BRS_RUNNER_OK=false; BRS_COMPARE_OK=false
    return 0
}

_brs_log() { echo -e "  ${CYAN:-\033[0;36m}[benchmark]${NC:-\033[0m} $*" >&2; }
_brs_ok()  { echo -e "  ${GREEN:-\033[0;32m}✅ [benchmark]${NC:-\033[0m} $*" >&2; }
_brs_err() { echo -e "  ${RED:-\033[0;31m}❌ [benchmark]${NC:-\033[0m} $*" >&2; BRS_ERRORS=$((BRS_ERRORS + 1)); }

_brs_write_file() {
    local filepath="$1" content="$2"
    local dir; dir="$(dirname "$filepath")"
    [[ -d "$dir" ]] || mkdir -p "$dir"
    echo "$content" > "$filepath" 2>/dev/null || { _brs_err "Failed to write $filepath"; return 1; }
    BRS_FILES_WRITTEN=$((BRS_FILES_WRITTEN + 1))
    return 0
}

_brs_generate_benchmarks() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/benchmark/benchmark-generator.ts"
    _brs_log "Generating benchmark generator..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v468.0 - Benchmark Generator

export interface BenchmarkConfig {
  name: string;
  category: 'api' | 'database' | 'render' | 'computation' | 'bundle';
  iterations: number;
  warmupIterations: number;
  timeoutMs: number;
  fn: () => Promise<void> | void;
}

export interface BenchmarkResult {
  name: string;
  category: string;
  iterations: number;
  totalMs: number;
  avgMs: number;
  minMs: number;
  maxMs: number;
  p50Ms: number;
  p95Ms: number;
  p99Ms: number;
  opsPerSecond: number;
  timestamp: number;
}

export class BenchmarkGenerator {
  private benchmarks: BenchmarkConfig[] = [];

  register(config: BenchmarkConfig): void { this.benchmarks.push(config); }

  generateAPIBenchmarks(endpoints: Array<{ method: string; path: string; body?: unknown }>): void {
    for (const ep of endpoints) {
      this.register({
        name: `API ${ep.method} ${ep.path}`,
        category: 'api',
        iterations: 100,
        warmupIterations: 5,
        timeoutMs: 30000,
        fn: async () => { await fetch(ep.path, { method: ep.method, body: ep.body ? JSON.stringify(ep.body) : undefined }); },
      });
    }
  }

  generateDatabaseBenchmarks(queries: Array<{ name: string; fn: () => Promise<void> }>): void {
    for (const q of queries) {
      this.register({ name: `DB ${q.name}`, category: 'database', iterations: 50, warmupIterations: 3, timeoutMs: 60000, fn: q.fn });
    }
  }

  generateRenderBenchmarks(components: string[]): void {
    for (const comp of components) {
      this.register({
        name: `Render ${comp}`,
        category: 'render',
        iterations: 200,
        warmupIterations: 10,
        timeoutMs: 30000,
        fn: () => { /* Would use React testing library in actual impl */ },
      });
    }
  }

  getAll(): BenchmarkConfig[] { return [...this.benchmarks]; }
  getByCategory(category: string): BenchmarkConfig[] { return this.benchmarks.filter(b => b.category === category); }
}

export const benchmarkGenerator = new BenchmarkGenerator();
TYPESCRIPT
)
    _brs_write_file "$outfile" "$content" || return 1
    BRS_BENCHMARKS_OK=true
    BRS_GENERATED=$((BRS_GENERATED + 1))
    _brs_ok "Benchmark generator generated"
    return 0
}

_brs_run_suite() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/benchmark/benchmark-runner.ts"
    _brs_log "Generating benchmark runner..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v468.0 - Benchmark Runner

import type { BenchmarkConfig, BenchmarkResult } from './benchmark-generator';

export class BenchmarkRunner {
  async run(config: BenchmarkConfig): Promise<BenchmarkResult> {
    // Warmup
    for (let i = 0; i < config.warmupIterations; i++) await config.fn();

    const timings: number[] = [];
    const start = Date.now();

    for (let i = 0; i < config.iterations; i++) {
      const iterStart = performance.now();
      await config.fn();
      timings.push(performance.now() - iterStart);
    }

    const totalMs = Date.now() - start;
    timings.sort((a, b) => a - b);

    return {
      name: config.name,
      category: config.category,
      iterations: config.iterations,
      totalMs,
      avgMs: timings.reduce((a, b) => a + b, 0) / timings.length,
      minMs: timings[0],
      maxMs: timings[timings.length - 1],
      p50Ms: timings[Math.floor(timings.length * 0.5)],
      p95Ms: timings[Math.floor(timings.length * 0.95)],
      p99Ms: timings[Math.floor(timings.length * 0.99)],
      opsPerSecond: Math.round((config.iterations / totalMs) * 1000),
      timestamp: Date.now(),
    };
  }

  async runAll(configs: BenchmarkConfig[]): Promise<BenchmarkResult[]> {
    const results: BenchmarkResult[] = [];
    for (const config of configs) {
      try {
        results.push(await this.run(config));
      } catch (err) {
        console.error(`Benchmark ${config.name} failed:`, err);
      }
    }
    return results;
  }
}

export const benchmarkRunner = new BenchmarkRunner();
TYPESCRIPT
)
    _brs_write_file "$outfile" "$content" || return 1
    BRS_RUNNER_OK=true
    BRS_GENERATED=$((BRS_GENERATED + 1))
    _brs_ok "Benchmark runner generated"
    return 0
}

_brs_compare_results() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/benchmark/benchmark-comparator.ts"
    _brs_log "Generating benchmark comparator..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v468.0 - Benchmark Result Comparator

import type { BenchmarkResult } from './benchmark-generator';

export interface ComparisonResult {
  name: string;
  before: BenchmarkResult;
  after: BenchmarkResult;
  deltaAvgMs: number;
  deltaP95Ms: number;
  deltaPercent: number;
  improved: boolean;
  regressed: boolean;
  significance: 'none' | 'marginal' | 'significant' | 'major';
}

export class BenchmarkComparator {
  compare(before: BenchmarkResult[], after: BenchmarkResult[]): ComparisonResult[] {
    const results: ComparisonResult[] = [];
    for (const b of before) {
      const a = after.find(r => r.name === b.name);
      if (!a) continue;
      const deltaAvgMs = a.avgMs - b.avgMs;
      const deltaP95Ms = a.p95Ms - b.p95Ms;
      const deltaPercent = (deltaAvgMs / b.avgMs) * 100;
      const significance = Math.abs(deltaPercent) < 5 ? 'none' : Math.abs(deltaPercent) < 15 ? 'marginal' : Math.abs(deltaPercent) < 30 ? 'significant' : 'major';
      results.push({
        name: b.name, before: b, after: a, deltaAvgMs, deltaP95Ms, deltaPercent,
        improved: deltaPercent < -5, regressed: deltaPercent > 10, significance,
      });
    }
    return results;
  }

  generateMarkdown(comparisons: ComparisonResult[]): string {
    let md = `# Benchmark Comparison\n\n| Benchmark | Before (avg) | After (avg) | Delta | Status |\n|-----------|-------------|------------|-------|--------|\n`;
    for (const c of comparisons) {
      const status = c.regressed ? 'REGRESSED' : c.improved ? 'IMPROVED' : 'OK';
      md += `| ${c.name} | ${c.before.avgMs.toFixed(2)}ms | ${c.after.avgMs.toFixed(2)}ms | ${c.deltaPercent > 0 ? '+' : ''}${c.deltaPercent.toFixed(1)}% | ${status} |\n`;
    }
    return md;
  }

  hasRegressions(comparisons: ComparisonResult[]): boolean {
    return comparisons.some(c => c.regressed);
  }
}

export const benchmarkComparator = new BenchmarkComparator();
TYPESCRIPT
)
    _brs_write_file "$outfile" "$content" || return 1
    BRS_COMPARE_OK=true
    BRS_GENERATED=$((BRS_GENERATED + 1))
    _brs_ok "Benchmark comparator generated"
    return 0
}

_brs_generate_all() {
    local project_dir="${1:-.}"
    _brs_generate_benchmarks "$project_dir"
    _brs_run_suite "$project_dir"
    _brs_compare_results "$project_dir"
    _brs_ok "Benchmark regression suite complete: ${BRS_GENERATED} components, ${BRS_ERRORS} errors"
}

_brs_report() {
    echo -e "\n  ${BOLD:-\033[1m}═══ Benchmark Regression Suite v${BRS_VERSION} ═══${NC:-\033[0m}"
    echo -e "  Generated  : ${BRS_GENERATED}"
    echo -e "  Errors     : ${BRS_ERRORS}"
    echo -e "  Benchmarks : ${BRS_BENCHMARKS_OK}"
    echo -e "  Runner     : ${BRS_RUNNER_OK}"
    echo -e "  Comparator : ${BRS_COMPARE_OK}"
}

_brs_score() {
    local score=50
    ${BRS_BENCHMARKS_OK} && score=$((score + 15))
    ${BRS_RUNNER_OK} && score=$((score + 15))
    ${BRS_COMPARE_OK} && score=$((score + 15))
    [[ ${BRS_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "benchmark-regression-suite" --version "468.0" \
        --description "ベンチマークリグレッション: テスト生成×実行×結果比較" \
        --init "_brs_init" --report "_brs_report" --score "_brs_score" \
        --enable-var "ENABLE_BENCHMARK_REGRESSION" --cli-flags "--benchmark-regression:--no-benchmark-regression"
fi

# v2003.1: source時のexit codeを確実に0にする
true
