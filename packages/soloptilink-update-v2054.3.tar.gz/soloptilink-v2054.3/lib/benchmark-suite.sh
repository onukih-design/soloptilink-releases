#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v109.0 - Benchmark Suite
# 標準化ベンチマーク: コード生成品質を定量的に測定・比較
#
# 機能:
#   1. ベンチマーク定義（タスク/ドメイン/期待値/閾値）
#   2. 複合スコア算出（rv/lv/mgt/rte/e2e各モジュール集約）
#   3. 結果永続化（JSONL形式）
#   4. ベンチマーク間比較（スコア差分表示）
#   5. 組み込みベンチマーク4種（CRUD/SaaS/EC/ブログ）
#
# v109.0: AGI Integration & Governance - Week 4
# ============================================================

[[ -n "${_BS_LOADED:-}" ]] && return 0
_BS_LOADED=1

# --- グローバル状態 ---
BS_VERSION="109.0"
BS_INITIALIZED=false
BS_BASE_DIR="${HOME}/.soloptilink/benchmarks"
BS_RESULTS_FILE=""

# --- ベンチマーク定義格納 ---
declare -A _BS_BENCH_TASK=()
declare -A _BS_BENCH_DOMAIN=()
declare -A _BS_BENCH_ENTITIES=()
declare -A _BS_BENCH_APIS=()
declare -A _BS_BENCH_THRESHOLD=()
declare -a _BS_BENCH_NAMES=()

# --- 統計 ---
BS_TOTAL_RUNS=0
BS_TOTAL_PASS=0
BS_TOTAL_FAIL=0

# ============================================================
# 初期化
# ============================================================
bs_init() {
    BS_RESULTS_FILE="${BS_BASE_DIR}/results.jsonl"
    mkdir -p "$BS_BASE_DIR" 2>/dev/null || true

    # 組み込みベンチマーク定義
    bs_define_benchmark "simple-crud" \
        "タスク管理アプリ" \
        "task_management" \
        "5" "10" "80"

    bs_define_benchmark "saas-crm" \
        "マルチテナントCRM" \
        "crm" \
        "8" "20" "75"

    bs_define_benchmark "ec-site" \
        "ECサイト" \
        "ecommerce" \
        "10" "25" "75"

    bs_define_benchmark "blog" \
        "ブログプラットフォーム" \
        "general" \
        "4" "8" "85"

    BS_INITIALIZED=true
    return 0
}

# ============================================================
# ベンチマーク定義
# ============================================================
bs_define_benchmark() {
    local name="$1"
    local task_desc="$2"
    local domain="$3"
    local expected_entities="${4:-5}"
    local expected_apis="${5:-10}"
    local quality_threshold="${6:-80}"

    [[ -z "$name" ]] && return 1

    _BS_BENCH_TASK["$name"]="$task_desc"
    _BS_BENCH_DOMAIN["$name"]="$domain"
    _BS_BENCH_ENTITIES["$name"]="$expected_entities"
    _BS_BENCH_APIS["$name"]="$expected_apis"
    _BS_BENCH_THRESHOLD["$name"]="$quality_threshold"

    # 重複登録防止
    local already=false
    for existing in "${_BS_BENCH_NAMES[@]}"; do
        [[ "$existing" == "$name" ]] && already=true && break
    done
    if ! $already; then
        _BS_BENCH_NAMES+=("$name")
    fi

    return 0
}

# ============================================================
# ベンチマーク取得
# ============================================================
bs_get_benchmark() {
    local name="$1"
    [[ -z "$name" ]] && return 1

    local task="${_BS_BENCH_TASK[$name]:-}"
    [[ -z "$task" ]] && echo "Benchmark '${name}' not found" >&2 && return 1

    local domain="${_BS_BENCH_DOMAIN[$name]}"
    local entities="${_BS_BENCH_ENTITIES[$name]}"
    local apis="${_BS_BENCH_APIS[$name]}"
    local threshold="${_BS_BENCH_THRESHOLD[$name]}"

    echo "{\"name\":\"${name}\",\"task\":\"${task}\",\"domain\":\"${domain}\",\"expected_entities\":${entities},\"expected_apis\":${apis},\"quality_threshold\":${threshold}}"
    return 0
}

# ============================================================
# ベンチマーク一覧
# ============================================================
bs_list_benchmarks() {
    echo "=== Registered Benchmarks ==="
    for name in "${_BS_BENCH_NAMES[@]}"; do
        local task="${_BS_BENCH_TASK[$name]}"
        local domain="${_BS_BENCH_DOMAIN[$name]}"
        local threshold="${_BS_BENCH_THRESHOLD[$name]}"
        local entities="${_BS_BENCH_ENTITIES[$name]}"
        local apis="${_BS_BENCH_APIS[$name]}"
        printf "  %-15s %-25s domain=%-15s entities=%s apis=%s threshold=%s\n" \
            "$name" "$task" "$domain" "$entities" "$apis" "$threshold"
    done
}

# ============================================================
# ベンチマーク実行
# project_dirに対して利用可能な全検証モジュールを実行し
# 複合スコアを算出する
# ============================================================
bs_run_benchmark() {
    local name="$1"
    local project_dir="$2"

    [[ -z "$name" || -z "$project_dir" ]] && return 1

    local task="${_BS_BENCH_TASK[$name]:-}"
    [[ -z "$task" ]] && echo "Benchmark '${name}' not found" >&2 && return 1

    local domain="${_BS_BENCH_DOMAIN[$name]}"
    local expected_entities="${_BS_BENCH_ENTITIES[$name]}"
    local expected_apis="${_BS_BENCH_APIS[$name]}"
    local threshold="${_BS_BENCH_THRESHOLD[$name]}"

    echo "  [Benchmark] Running '${name}' on ${project_dir}..." >&2

    BS_TOTAL_RUNS=$((BS_TOTAL_RUNS + 1))
    local start_ts
    start_ts=$(date '+%s')

    local scores_sum=0
    local scores_count=0
    local score_details=""

    # --- 1. Real Validator (rv_validate_project) ---
    local rv_score=0
    if type -t rv_validate_project &>/dev/null; then
        rv_validate_project "$project_dir" 2>/dev/null || true
        if type -t rv_score &>/dev/null; then
            rv_score=$(rv_score 2>/dev/null || echo "0")
        fi
    fi
    rv_score=$(_bs_clamp_score "$rv_score")
    scores_sum=$((scores_sum + rv_score))
    scores_count=$((scores_count + 1))
    score_details="${score_details}rv:${rv_score},"

    # --- 2. Live Verification (lv_verify_integration) ---
    local lv_score=0
    if type -t lv_verify_integration &>/dev/null; then
        lv_verify_integration "$project_dir" 2>/dev/null || true
        if type -t lv_score &>/dev/null; then
            lv_score=$(lv_score 2>/dev/null || echo "0")
        fi
    fi
    lv_score=$(_bs_clamp_score "$lv_score")
    scores_sum=$((scores_sum + lv_score))
    scores_count=$((scores_count + 1))
    score_details="${score_details}lv:${lv_score},"

    # --- 3. Migration Tester (mgt_run) ---
    local mgt_score=0
    if type -t mgt_run &>/dev/null; then
        mgt_run "$project_dir" 2>/dev/null || true
        if type -t mgt_score &>/dev/null; then
            mgt_score=$(mgt_score 2>/dev/null || echo "0")
        fi
    fi
    mgt_score=$(_bs_clamp_score "$mgt_score")
    scores_sum=$((scores_sum + mgt_score))
    scores_count=$((scores_count + 1))
    score_details="${score_details}mgt:${mgt_score},"

    # --- 4. Runtime Test Executor (rte_run) ---
    local rte_score=0
    if type -t rte_run &>/dev/null; then
        rte_run "$project_dir" 2>/dev/null || true
        if type -t rte_score &>/dev/null; then
            rte_score=$(rte_score 2>/dev/null || echo "0")
        fi
    fi
    rte_score=$(_bs_clamp_score "$rte_score")
    scores_sum=$((scores_sum + rte_score))
    scores_count=$((scores_count + 1))
    score_details="${score_details}rte:${rte_score},"

    # --- 5. E2E Runner (e2e_run) ---
    local e2e_score=0
    if type -t e2e_run &>/dev/null; then
        e2e_run "$project_dir" 2>/dev/null || true
        if type -t e2e_score &>/dev/null; then
            e2e_score=$(e2e_score 2>/dev/null || echo "0")
        fi
    fi
    e2e_score=$(_bs_clamp_score "$e2e_score")
    scores_sum=$((scores_sum + e2e_score))
    scores_count=$((scores_count + 1))
    score_details="${score_details}e2e:${e2e_score}"

    # --- 6. Entity count validation ---
    local entity_score=0
    entity_score=$(_bs_check_entities "$project_dir" "$expected_entities")

    # --- 7. API route count validation ---
    local api_score=0
    api_score=$(_bs_check_apis "$project_dir" "$expected_apis")

    # Add structural scores
    scores_sum=$((scores_sum + entity_score + api_score))
    scores_count=$((scores_count + 2))
    score_details="${score_details},entities:${entity_score},apis:${api_score}"

    # --- Composite score ---
    local composite=0
    if [[ $scores_count -gt 0 ]]; then
        composite=$((scores_sum / scores_count))
    fi

    local end_ts
    end_ts=$(date '+%s')
    local duration=$((end_ts - start_ts))

    # --- Pass/Fail判定 ---
    local verdict="PASS"
    if [[ $composite -lt $threshold ]]; then
        verdict="FAIL"
        BS_TOTAL_FAIL=$((BS_TOTAL_FAIL + 1))
    else
        BS_TOTAL_PASS=$((BS_TOTAL_PASS + 1))
    fi

    # --- 結果永続化 ---
    _bs_persist_result "$name" "$composite" "$verdict" "$score_details" "$duration"

    # --- 結果出力 ---
    echo "  [Benchmark] '${name}' completed: score=${composite}/${threshold} verdict=${verdict} (${duration}s)" >&2
    echo "  [Benchmark] Details: ${score_details}" >&2

    # 結果JSON出力
    echo "{\"benchmark\":\"${name}\",\"composite_score\":${composite},\"threshold\":${threshold},\"verdict\":\"${verdict}\",\"details\":\"${score_details}\",\"duration_sec\":${duration},\"timestamp\":\"$(date '+%Y-%m-%dT%H:%M:%S')\"}"

    [[ "$verdict" == "PASS" ]] && return 0 || return 1
}

# ============================================================
# ベンチマーク結果比較
# ============================================================
bs_compare() {
    local result1="$1"
    local result2="$2"

    # JSONからスコア抽出 (jq不使用)
    local score1 score2 name1 name2 verdict1 verdict2

    score1=$(echo "$result1" | sed -n 's/.*"composite_score":\([0-9]*\).*/\1/p')
    score2=$(echo "$result2" | sed -n 's/.*"composite_score":\([0-9]*\).*/\1/p')
    name1=$(echo "$result1" | sed -n 's/.*"benchmark":"\([^"]*\)".*/\1/p')
    name2=$(echo "$result2" | sed -n 's/.*"benchmark":"\([^"]*\)".*/\1/p')
    verdict1=$(echo "$result1" | sed -n 's/.*"verdict":"\([^"]*\)".*/\1/p')
    verdict2=$(echo "$result2" | sed -n 's/.*"verdict":"\([^"]*\)".*/\1/p')

    score1=${score1:-0}
    score2=${score2:-0}
    name1=${name1:-unknown}
    name2=${name2:-unknown}

    local diff=$((score2 - score1))
    local direction="="
    [[ $diff -gt 0 ]] && direction="+"
    [[ $diff -lt 0 ]] && direction="-"

    echo "=== Benchmark Comparison ==="
    printf "  %-20s score=%-4s verdict=%s\n" "$name1" "$score1" "$verdict1"
    printf "  %-20s score=%-4s verdict=%s\n" "$name2" "$score2" "$verdict2"
    echo "  ---"
    printf "  Delta: %s%d points\n" "$direction" "${diff#-}"

    # Details比較
    local details1 details2
    details1=$(echo "$result1" | sed -n 's/.*"details":"\([^"]*\)".*/\1/p')
    details2=$(echo "$result2" | sed -n 's/.*"details":"\([^"]*\)".*/\1/p')

    if [[ -n "$details1" && -n "$details2" ]]; then
        echo "  Per-axis comparison:"
        # 各軸を抽出して比較
        local IFS_BAK="$IFS"
        IFS=','
        local -a axes1=($details1)
        local -a axes2=($details2)
        IFS="$IFS_BAK"

        local i=0
        while [[ $i -lt ${#axes1[@]} && $i -lt ${#axes2[@]} ]]; do
            local a1="${axes1[$i]}"
            local a2="${axes2[$i]}"
            local axis_name1="${a1%%:*}"
            local val1="${a1##*:}"
            local val2="${a2##*:}"
            val1=${val1:-0}
            val2=${val2:-0}
            local axis_diff=$((val2 - val1))
            local axis_dir="="
            [[ $axis_diff -gt 0 ]] && axis_dir="+"
            [[ $axis_diff -lt 0 ]] && axis_dir="-"
            printf "    %-10s %3s -> %3s (%s%d)\n" "$axis_name1" "$val1" "$val2" "$axis_dir" "${axis_diff#-}"
            i=$((i + 1))
        done
    fi

    return 0
}

# ============================================================
# 内部ヘルパー
# ============================================================

# スコアを0-100にクランプ
_bs_clamp_score() {
    local score="$1"
    score=$(echo "$score" | grep -oE '^[0-9]+' | head -1)
    score=${score:-0}
    [[ $score -lt 0 ]] && score=0
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# Prismaスキーマからエンティティ数を検証
_bs_check_entities() {
    local project_dir="$1"
    local expected="$2"

    local schema_file=""
    for candidate in \
        "${project_dir}/prisma/schema.prisma" \
        "${project_dir}/src/prisma/schema.prisma" \
        "${project_dir}/db/schema.prisma"; do
        [[ -f "$candidate" ]] && schema_file="$candidate" && break
    done

    if [[ -z "$schema_file" ]]; then
        echo "30"
        return
    fi

    local found_count=0
    found_count=$(grep -cE '^\s*model\s+[A-Z]' "$schema_file" 2>/dev/null || echo "0")
    found_count=$(echo "$found_count" | grep -oE '[0-9]+' | head -1)
    found_count=${found_count:-0}

    if [[ $found_count -ge $expected ]]; then
        echo "100"
    elif [[ $found_count -gt 0 ]]; then
        # 比例スコア
        local ratio=$((found_count * 100 / expected))
        [[ $ratio -gt 100 ]] && ratio=100
        echo "$ratio"
    else
        echo "10"
    fi
}

# APIルート数を検証
_bs_check_apis() {
    local project_dir="$1"
    local expected="$2"

    local found_count=0

    # Next.js App Router: app/api/**/route.ts
    if [[ -d "${project_dir}/src/app/api" ]]; then
        found_count=$(find "${project_dir}/src/app/api" -name "route.ts" -o -name "route.js" 2>/dev/null | wc -l | tr -d ' ')
    elif [[ -d "${project_dir}/app/api" ]]; then
        found_count=$(find "${project_dir}/app/api" -name "route.ts" -o -name "route.js" 2>/dev/null | wc -l | tr -d ' ')
    fi

    # Express/Fastify: routes/*.ts
    if [[ $found_count -eq 0 && -d "${project_dir}/src/routes" ]]; then
        found_count=$(find "${project_dir}/src/routes" -name "*.ts" -o -name "*.js" 2>/dev/null | wc -l | tr -d ' ')
    fi

    found_count=${found_count:-0}

    if [[ $found_count -ge $expected ]]; then
        echo "100"
    elif [[ $found_count -gt 0 ]]; then
        local ratio=$((found_count * 100 / expected))
        [[ $ratio -gt 100 ]] && ratio=100
        echo "$ratio"
    else
        echo "10"
    fi
}

# 結果をJSONLファイルに永続化
_bs_persist_result() {
    local name="$1"
    local score="$2"
    local verdict="$3"
    local details="$4"
    local duration="$5"

    mkdir -p "$BS_BASE_DIR" 2>/dev/null || true

    local record="{\"benchmark\":\"${name}\",\"composite_score\":${score},\"verdict\":\"${verdict}\",\"details\":\"${details}\",\"duration_sec\":${duration},\"session\":\"${SESSION_ID:-unknown}\",\"provider\":\"${AIP_PROVIDER:-claude-cli}\",\"timestamp\":\"$(date '+%Y-%m-%dT%H:%M:%S')\"}"

    echo "$record" >> "$BS_RESULTS_FILE" 2>/dev/null || true
}

# ============================================================
# レポート
# ============================================================
bs_report() {
    echo "=== Benchmark Suite v${BS_VERSION} ==="
    echo "  Defined benchmarks: ${#_BS_BENCH_NAMES[@]}"
    echo "  Total runs: ${BS_TOTAL_RUNS} (Pass: ${BS_TOTAL_PASS}, Fail: ${BS_TOTAL_FAIL})"
    if [[ -f "$BS_RESULTS_FILE" ]]; then
        local result_count
        result_count=$(wc -l < "$BS_RESULTS_FILE" 2>/dev/null | tr -d ' ')
        echo "  Persisted results: ${result_count:-0}"
    fi
    bs_list_benchmarks
}

bs_score() {
    local score=50
    # ベンチマーク定義があれば加点
    [[ ${#_BS_BENCH_NAMES[@]} -gt 0 ]] && score=$((score + 15))
    [[ ${#_BS_BENCH_NAMES[@]} -ge 4 ]] && score=$((score + 10))
    # 実行実績があれば加点
    [[ $BS_TOTAL_RUNS -gt 0 ]] && score=$((score + 15))
    # 合格率で加点
    if [[ $BS_TOTAL_RUNS -gt 0 ]]; then
        local pass_rate=$((BS_TOTAL_PASS * 100 / BS_TOTAL_RUNS))
        if [[ $pass_rate -ge 80 ]]; then
            score=$((score + 10))
        elif [[ $pass_rate -ge 50 ]]; then
            score=$((score + 5))
        fi
    fi
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# ============================================================
# Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "benchmark-suite" \
        --version "$BS_VERSION" \
        --description "標準化ベンチマーク - コード生成品質の定量測定・比較" \
        --init "bs_init" \
        --report "bs_report" \
        --score "bs_score" \
        --enable-var "ENABLE_BS" \
        --cli-flags "--benchmark-suite:--no-benchmark-suite"
fi

# v2003.1: source時のexit codeを確実に0にする
true
