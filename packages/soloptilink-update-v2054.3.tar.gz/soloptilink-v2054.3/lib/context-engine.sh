#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v12.0 - Context Engine
# =============================================================================
# フェーズ間のコンテキストを知的に管理する。各フェーズの出力をJSONステートに
# 保存し、次フェーズに必要な情報のみを渡すことで、Claude CLIのコンテキスト窓を
# 最大限活用する。
#
# 機能:
#   1. フェーズステート管理（JSON形式で成果物パス・メタデータを蓄積）
#   2. コンテキスト窓制御（ターゲットフェーズに必要な情報のみ組み立て）
#   3. トークン数推定（プロンプトサイズの事前推定）
#   4. コンテキスト圧縮（長文をClaude要約で圧縮）
#   5. フェーズ依存関係マップ（どのフェーズがどの情報を必要とするか）
#
# Usage: source lib/context-engine.sh
# =============================================================================

[[ -n "${_CTX_ENGINE_LOADED:-}" ]] && return 0
_CTX_ENGINE_LOADED=1

# カラー（CTX_プレフィックスで衝突回避）
CTX_GREEN='\033[0;32m'  CTX_YELLOW='\033[0;33m' CTX_RED='\033[0;31m'
CTX_CYAN='\033[0;36m'   CTX_BOLD='\033[1m'       CTX_NC='\033[0m'

# ステートファイルパス
CTX_STATE_FILE=""
CTX_SESSION_ID=""
CTX_MAX_PROMPT_CHARS="${CTX_MAX_PROMPT_CHARS:-120000}"  # ~30kトークン

# --- フェーズ依存関係マップ ---
# 各フェーズが必要とする先行フェーズの出力キー
# format: "target_phase=dep1,dep2,dep3"
declare -A CTX_DEPS=(
    [requirements]=""
    [competitive_research]=""
    [database]="requirements"
    [backend]="requirements,database"
    [api]="requirements,backend"
    [frontend]="requirements,api,spec"
    [quality_check]="requirements"
    [testing]="requirements"
    [security_audit]=""
    [documentation]="requirements"
    [deploy]=""
    [implementation]="requirements"
    [hotfix]=""
    [data_import]=""
    [saas_architecture]="requirements,database,data_import"
    [ai_integration]="requirements,backend,api,data_import"
    [data_integrity]="implementation"
    [audit_log]="implementation"
    [e2e_test]="implementation"
    # v28.0 Follow-up Intelligence
    [followup_detect]=""
    [code_scan]="followup_detect"
    [incremental_analysis]="code_scan,followup_detect"
    [targeted_compile]="incremental_analysis,code_scan"
    [delta_apply]="targeted_compile"
)

# --- ヘルパー ---
_ctx_log() {
    local level="$1" msg="$2"
    case "$level" in
        INFO)  printf "  ${CTX_CYAN}[CTX]${CTX_NC} %s\n" "$msg" ;;
        OK)    printf "  ${CTX_GREEN}[CTX]${CTX_NC} %s\n" "$msg" ;;
        WARN)  printf "  ${CTX_YELLOW}[CTX]${CTX_NC} %s\n" "$msg" ;;
        ERROR) printf "  ${CTX_RED}[CTX]${CTX_NC} %s\n" "$msg" ;;
    esac
}

# =============================================================================
# 1. ctx_init(session_id, log_dir)
# =============================================================================
ctx_init() {
    local session_id="${1:?ctx_init: session_id required}"
    local log_dir="${2:-}"

    CTX_SESSION_ID="$session_id"

    if [[ -n "$log_dir" ]]; then
        CTX_STATE_FILE="${log_dir}/state.json"
    elif [[ -n "${SESSION_LOG_DIR:-}" ]]; then
        CTX_STATE_FILE="${SESSION_LOG_DIR}/state.json"
    else
        CTX_STATE_FILE="/tmp/soloptilink_ctx_${session_id}.json"
    fi

    mkdir -p "$(dirname "$CTX_STATE_FILE")" 2>/dev/null || true

    # 既存ステートがなければ初期化
    if [[ ! -f "$CTX_STATE_FILE" ]]; then
        cat > "$CTX_STATE_FILE" <<'INITJSON'
{
  "version": "12.0",
  "session_id": "",
  "created_at": "",
  "phases": {},
  "metadata": {
    "total_tokens_estimated": 0,
    "phases_completed": 0
  }
}
INITJSON
        # セッションID・作成日時を設定
        if command -v python3 &>/dev/null; then
            python3 -c "
import json, sys
with open(sys.argv[1], 'r') as f:
    d = json.load(f)
d['session_id'] = sys.argv[2]
d['created_at'] = sys.argv[3]
with open(sys.argv[1], 'w') as f:
    json.dump(d, f, ensure_ascii=False, indent=2)
" "$CTX_STATE_FILE" "$session_id" "$(date '+%Y-%m-%d %H:%M:%S')" 2>/dev/null || true
        fi
    fi

    _ctx_log "OK" "Context Engine v12.0 初期化: ${CTX_STATE_FILE}"
}

# =============================================================================
# 2. ctx_save(phase, key, value) — フェーズ結果をJSONに保存
# =============================================================================
ctx_save() {
    local phase="${1:?ctx_save: phase required}"
    local key="${2:?ctx_save: key required}"
    local value="$3"

    [[ -z "$CTX_STATE_FILE" || ! -f "$CTX_STATE_FILE" ]] && return 1

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os

state_file = sys.argv[1]
phase = sys.argv[2]
key = sys.argv[3]
value = sys.argv[4]

with open(state_file, 'r') as f:
    state = json.load(f)

if phase not in state['phases']:
    state['phases'][phase] = {'started_at': '', 'completed_at': '', 'data': {}}

state['phases'][phase]['data'][key] = value

# ファイルパスの場合、サイズ情報も保存
if os.path.isfile(value):
    try:
        size = os.path.getsize(value)
        state['phases'][phase]['data'][key + '_size'] = size
    except: pass

with open(state_file, 'w') as f:
    json.dump(state, f, ensure_ascii=False, indent=2)
" "$CTX_STATE_FILE" "$phase" "$key" "$value" 2>/dev/null
    else
        _ctx_log "WARN" "python3未検出: ctx_save スキップ"
    fi
}

# =============================================================================
# 3. ctx_save_phase_status(phase, status) — フェーズ状態を記録
# =============================================================================
ctx_save_phase_status() {
    local phase="${1:?}" status="${2:?}"

    [[ -z "$CTX_STATE_FILE" || ! -f "$CTX_STATE_FILE" ]] && return 1

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, datetime

state_file = sys.argv[1]
phase = sys.argv[2]
status = sys.argv[3]
now = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')

with open(state_file, 'r') as f:
    state = json.load(f)

if phase not in state['phases']:
    state['phases'][phase] = {'started_at': '', 'completed_at': '', 'data': {}}

if status == 'started':
    state['phases'][phase]['started_at'] = now
elif status == 'completed':
    state['phases'][phase]['completed_at'] = now
    state['metadata']['phases_completed'] = state['metadata'].get('phases_completed', 0) + 1

with open(state_file, 'w') as f:
    json.dump(state, f, ensure_ascii=False, indent=2)
" "$CTX_STATE_FILE" "$phase" "$status" 2>/dev/null
    fi
}

# =============================================================================
# 4. ctx_load(phase) — 特定フェーズの結果を読み出し
# =============================================================================
ctx_load() {
    local phase="${1:?ctx_load: phase required}"

    [[ -z "$CTX_STATE_FILE" || ! -f "$CTX_STATE_FILE" ]] && return 1

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys

with open(sys.argv[1], 'r') as f:
    state = json.load(f)

phase_data = state.get('phases', {}).get(sys.argv[2], {}).get('data', {})
print(json.dumps(phase_data, ensure_ascii=False, indent=2))
" "$CTX_STATE_FILE" "$phase" 2>/dev/null
    fi
}

# =============================================================================
# 5. ctx_load_file(phase, key) — フェーズの成果物ファイルの中身を読み出し
# =============================================================================
ctx_load_file() {
    local phase="${1:?}" key="${2:?}"
    local filepath=""

    if command -v python3 &>/dev/null; then
        filepath=$(python3 -c "
import json, sys
with open(sys.argv[1], 'r') as f:
    state = json.load(f)
val = state.get('phases', {}).get(sys.argv[2], {}).get('data', {}).get(sys.argv[3], '')
print(val)
" "$CTX_STATE_FILE" "$phase" "$key" 2>/dev/null)
    fi

    if [[ -n "$filepath" && -f "$filepath" ]]; then
        cat "$filepath" 2>/dev/null
    fi
}

# =============================================================================
# 6. ctx_build_prompt(target_phase, task_desc) — ターゲットに必要なコンテキスト構築
# =============================================================================
ctx_build_prompt() {
    local target_phase="${1:?}" task_desc="${2:-}"
    local deps="${CTX_DEPS[$target_phase]:-}"
    local context=""
    local total_chars=0

    # タスク説明
    if [[ -n "$task_desc" ]]; then
        context="タスク: ${task_desc}\n\n"
        total_chars=${#task_desc}
    fi

    # 依存フェーズの出力を収集
    if [[ -n "$deps" ]]; then
        IFS=',' read -ra dep_list <<< "$deps"
        for dep in "${dep_list[@]}"; do
            dep=$(echo "$dep" | tr -d ' ')
            [[ -z "$dep" ]] && continue

            # 主要出力ファイルを読み込み
            local content=""
            content=$(ctx_load_file "$dep" "output_file" 2>/dev/null)

            if [[ -n "$content" ]]; then
                local content_chars=${#content}
                local remaining=$((CTX_MAX_PROMPT_CHARS - total_chars - 2000))

                if [[ $content_chars -gt $remaining && $remaining -gt 1000 ]]; then
                    # 長すぎる場合は圧縮
                    content=$(ctx_compress "$content" "$remaining" 2>/dev/null || echo "${content:0:$remaining}")
                    content_chars=${#content}
                fi

                if [[ $((total_chars + content_chars)) -lt $CTX_MAX_PROMPT_CHARS ]]; then
                    context+="--- ${dep}フェーズの成果 ---\n${content}\n\n"
                    total_chars=$((total_chars + content_chars + 50))
                else
                    _ctx_log "WARN" "コンテキスト窓超過: ${dep} をスキップ"
                fi
            fi
        done
    fi

    echo -e "$context"
}

# =============================================================================
# 7. ctx_estimate_tokens(text) — トークン数推定
# =============================================================================
ctx_estimate_tokens() {
    local text="$1"
    local char_count=${#text}
    # 日本語は1文字≒1.5トークン、英語は1文字≒0.25トークン
    # 混合テキストのため、大雑把に 文字数/3 で推定
    echo $(( (char_count + 2) / 3 ))
}

# =============================================================================
# 8. ctx_compress(text, max_chars) — コンテキスト圧縮
# =============================================================================
ctx_compress() {
    local text="$1"
    local max_chars="${2:-20000}"

    if [[ ${#text} -le $max_chars ]]; then
        echo "$text"
        return 0
    fi

    # v13.0: スマート圧縮 — 重要セクションを優先保持してからClaude要約
    # 1. 重要パターンの抽出（API定義/DBスキーマ/型定義/インターフェース）
    local important_sections=""
    if command -v python3 &>/dev/null; then
        important_sections=$(python3 -c "
import re, sys

text = sys.stdin.read()
sections = []

# 重要パターン: API定義、DBスキーマ、型定義、interface、エンドポイント
patterns = [
    (r'(?:CREATE TABLE|ALTER TABLE)[^;]+;', 'DB'),
    (r'(?:interface|type)\s+\w+\s*\{[^}]+\}', 'TYPE'),
    (r'(?:router\.\w+|app\.\w+)\s*\([^)]+\)', 'API'),
    (r'(?:export\s+(?:default\s+)?(?:function|const|class))\s+\w+', 'EXPORT'),
    (r'(?:schema|model)\s*=\s*\{[^}]+\}', 'SCHEMA'),
]

for pattern, label in patterns:
    matches = re.findall(pattern, text, re.DOTALL | re.IGNORECASE)
    for m in matches[:10]:  # 各パターン最大10件
        sections.append(f'[{label}] {m[:500]}')

# 重要セクション合計が予算の30%まで
budget = int(sys.argv[1]) * 30 // 100
output = '\n'.join(sections)
if len(output) > budget:
    output = output[:budget]
print(output)
" "$max_chars" <<< "$text" 2>/dev/null || echo "")
    fi

    local important_len=${#important_sections}
    local remaining_budget=$((max_chars - important_len - 200))

    # 2. Claude CLIで残りを要約
    if [[ $remaining_budget -gt 2000 ]] && command -v claude &>/dev/null; then
        local summary=""
        summary=$(timeout 60 claude -p \
            --dangerously-skip-permissions \
            --output-format text \
            "以下のテキストを${remaining_budget}文字以内に要約してください。重要な技術情報（API仕様、DBスキーマ、型定義、エンドポイント）は可能な限り保持:

${text:0:80000}" 2>/dev/null || echo "")

        if [[ -n "$summary" && ${#summary} -lt ${#text} ]]; then
            local result=""
            if [[ -n "$important_sections" ]]; then
                result="--- 重要定義（自動抽出） ---
${important_sections}

--- 要約 ---
${summary}"
            else
                result="$summary"
            fi
            _ctx_log "INFO" "スマート圧縮: ${#text} → ${#result}文字"
            echo "$result"
            return 0
        fi
    fi

    # 3. フォールバック: 重要セクション + 先頭と末尾を保持
    if [[ -n "$important_sections" ]]; then
        local head_budget=$(( (max_chars - important_len) * 60 / 100 ))
        local tail_budget=$(( (max_chars - important_len) * 40 / 100 ))
        echo "--- 重要定義 ---
${important_sections}

--- 冒頭 ---
${text:0:$head_budget}

--- 末尾 ---
${text: -$tail_budget}"
    else
        # 先頭60% + 末尾40% を保持
        local head_chars=$(( max_chars * 60 / 100 ))
        local tail_chars=$(( max_chars * 40 / 100 ))
        echo "${text:0:$head_chars}

[... ${#text}文字中 $((${#text} - head_chars - tail_chars))文字省略 ...]

${text: -$tail_chars}"
    fi
}

# =============================================================================
# 8.9. PFP-112: 固定ブロック重複注入抑止（端末経路トークン上限対策）
# =============================================================================
# 毎フェーズ注入される固定プロンプトブロック（セキュリティ/操作性/出力形式 等）を
# 「セッション内初回のみ全文、2回目以降は1行参照」に圧縮する。
# 状態は二重に保持する:
#   1. 環境変数 SOLOPTILINK_CTX_INJECTED（カンマ区切りブロック名。export で子プロセスへ伝播）
#   2. セッションマーカーファイル ${SESSION_LOG_DIR}/.ctx_injected_blocks
#      （getter はコマンド置換のサブシェル内で実行されるため、親シェルへの export が
#       届かない経路をファイルで補完する。セッションごとに新規ディレクトリのため自動リセット）
# 無効化: SOLOPTILINK_CTX_DEDUP=0 で常に全文注入（従来動作に戻す互換スイッチ）

ctx_is_injected() {
    local block="${1:?ctx_is_injected: block required}"
    # 互換スイッチ: 0 指定で重複抑止を無効化（常に全文注入）
    [[ "${SOLOPTILINK_CTX_DEDUP:-1}" == "0" ]] && return 1
    # 環境変数フラグ（子プロセスへ export 伝播済みの場合）
    case ",${SOLOPTILINK_CTX_INJECTED:-}," in
        *",${block},"*) return 0 ;;
    esac
    # セッションマーカーファイル（同一セッション内のサブシェル横断）
    [[ -z "${SESSION_LOG_DIR:-}" ]] && return 1
    local _marker="${SESSION_LOG_DIR}/.ctx_injected_blocks"
    [[ -f "$_marker" ]] && grep -qxF "$block" "$_marker" 2>/dev/null
}

ctx_mark_injected() {
    local block="${1:?ctx_mark_injected: block required}"
    # マーカーファイルへ追記（重複行は追加しない）
    if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
        local _marker="${SESSION_LOG_DIR}/.ctx_injected_blocks"
        mkdir -p "${SESSION_LOG_DIR}" 2>/dev/null || true
        grep -qxF "$block" "$_marker" 2>/dev/null || echo "$block" >> "$_marker" 2>/dev/null || true
    fi
    # 環境変数フラグを累積 export（子プロセスへ伝播）
    case ",${SOLOPTILINK_CTX_INJECTED:-}," in
        *",${block},"*) ;;
        *) export SOLOPTILINK_CTX_INJECTED="${SOLOPTILINK_CTX_INJECTED:+${SOLOPTILINK_CTX_INJECTED},}${block}" ;;
    esac
    return 0
}

# =============================================================================
# 9. ctx_get_security_prompt_injection() — セキュリティベストプラクティス注入テキスト
# =============================================================================
ctx_get_security_prompt() {
    # PFP-112: セッション内2回目以降は1行参照に圧縮
    if ctx_is_injected "security_prompt"; then
        printf '\n## セキュリティ要件: このセッションで既に提示済みの「セキュリティ要件（必須）」全10項目（bcryptハッシュ化/パラメータ化SQL/zodバリデーション/JWT/CORSホワイトリスト/helmet/レート制限/.env管理/XSS対策/CSRF対策）に引き続き全て従うこと\n'
        return 0
    fi
    ctx_mark_injected "security_prompt"
    cat <<'SECPROMPT'

## セキュリティ要件（必須）
- パスワード: bcrypt/argon2idでハッシュ化（平文保存禁止）
- SQLクエリ: 必ずパラメータ化（ORM推奨、文字列結合SQL禁止）
- 入力バリデーション: zod/pydanticで全エンドポイントにスキーマ定義
- 認証: JWT (RS256/ES256)、有効期限15分、リフレッシュトークン別管理
- CORS: 明示的オリジンホワイトリスト（*禁止）
- セキュリティヘッダー: helmet.js (CSP, X-Frame-Options, HSTS)
- レート制限: express-rate-limit / slowapi
- 環境変数: .envファイルで管理、.gitignoreに追加、ハードコード禁止
- XSS対策: HTMLエスケープ、dangerouslySetInnerHTML禁止
- CSRF対策: csrfトークン or SameSite Cookie
SECPROMPT
}

# =============================================================================
# 9.5. ctx_get_interactivity_prompt() — UI操作性要件注入テキスト (v14.0)
# =============================================================================
# 生成されるシステムが「表示だけ」ではなく「操作可能」であることを保証する
# プロンプト注入。call_claude()からセキュリティプロンプトと同様に注入される。
ctx_get_interactivity_prompt() {
    # PFP-112: セッション内2回目以降は1行参照に圧縮
    if ctx_is_injected "interactivity_prompt"; then
        printf '\n## UI操作性要件: このセッションで既に提示済みの「UI操作性要件（必須）」全10項目（onClick実装/onSubmit+バリデーション/検索・ソート・フィルタ・ページネーション/CRUD完全実装/実APIコール/エラーハンドリング/状態管理/DB永続化/空状態表示/確認ダイアログ）に引き続き全て従うこと\n'
        return 0
    fi
    ctx_mark_injected "interactivity_prompt"
    cat <<'INTERACTPROMPT'

## UI操作性要件（必須 - 表示だけのシステムは禁止）
このシステムは社内で実際に業務に使うものです。以下を必ず実装:
- 全ボタンにonClickハンドラ実装（空ハンドラ禁止）
- 全フォームにonSubmit実装、バリデーション付き、送信後フィードバック表示
- データ一覧: 検索バー、ソート（カラムクリック）、フィルター、ページネーション実装
- CRUD完全実装: 作成フォーム→保存、編集ボタン→編集フォーム→更新、削除→確認→実行
- APIコールは実際のエンドポイントを呼ぶ（モック/console.logだけは不可）
- エラーハンドリング: try-catch、エラー通知、ローディング状態管理
- 状態管理: useState/Zustand等でフォーム・フィルター・ページネーション状態を管理
- データ永続化: バックエンドAPI+DB（localStorageのみは不可）
- 空状態表示: データ0件時の案内メッセージ
- 確認ダイアログ: 削除等の破壊的操作には確認表示
INTERACTPROMPT
}

# =============================================================================
# 10. ctx_get_output_format_instruction() — ファイル出力形式指示
# =============================================================================
ctx_get_output_format() {
    # PFP-112: セッション内2回目以降は1行参照に圧縮
    if ctx_is_injected "output_format"; then
        printf '\n## 出力形式: このセッションで既に提示済みの「出力形式（厳守）」（```言語:ファイルパス フェンス形式・相対パス明示・省略なし完全出力・全UI操作可能実装）に引き続き従うこと\n'
        return 0
    fi
    ctx_mark_injected "output_format"
    cat <<'FMTPROMPT'

## 出力形式（厳守）
コードを生成する場合、以下のルールに従ってください:
1. プロジェクトルートからの相対パスを必ず明示
2. 各ファイルは以下の形式で出力:

```言語:ファイルパス
（ファイル内容）
```

例:
```typescript:src/server.ts
import express from 'express';
const app = express();
// ...
```

```typescript:src/routes/users.ts
import { Router } from 'express';
// ...
```

全てのファイルを省略なしで完全に出力してください。

重要: すべてのUIコンポーネントは操作可能な状態で実装すること。
- ボタン: onClick実装必須、空ハンドラ禁止
- フォーム: onSubmit実装必須、バリデーション必須
- テーブル: ソート・フィルタ・ページネーション実装必須
- 一覧画面: 検索バー実装必須
FMTPROMPT
}

# =============================================================================
# 11.5. ctx_recall(phase, key) — ctx_saveで保存した値を取得
# =============================================================================
ctx_recall() {
    local phase="${1:?ctx_recall: phase required}"
    local key="${2:?ctx_recall: key required}"

    [[ -z "$CTX_STATE_FILE" || ! -f "$CTX_STATE_FILE" ]] && return 1

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys

with open(sys.argv[1], 'r') as f:
    state = json.load(f)

value = state.get('phases', {}).get(sys.argv[2], {}).get('data', {}).get(sys.argv[3], '')
print(value)
" "$CTX_STATE_FILE" "$phase" "$key" 2>/dev/null
    else
        _ctx_log "WARN" "python3未検出: ctx_recall スキップ"
        return 1
    fi
}

# =============================================================================
# 12. ctx_summary() — 現在のステート概要
# =============================================================================
ctx_summary() {
    [[ -z "$CTX_STATE_FILE" || ! -f "$CTX_STATE_FILE" ]] && return 1

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys

with open(sys.argv[1], 'r') as f:
    state = json.load(f)

phases = state.get('phases', {})
meta = state.get('metadata', {})

print(f'Session: {state.get(\"session_id\", \"unknown\")}')
print(f'Phases completed: {meta.get(\"phases_completed\", 0)}')
for name, data in phases.items():
    started = data.get('started_at', '')
    completed = data.get('completed_at', '')
    keys = list(data.get('data', {}).keys())
    status = 'completed' if completed else ('running' if started else 'pending')
    print(f'  {name}: {status} | keys={keys}')
" "$CTX_STATE_FILE" 2>/dev/null
    fi
}
