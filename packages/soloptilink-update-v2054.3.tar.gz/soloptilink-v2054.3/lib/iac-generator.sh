#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v321.0 - Infrastructure as Code Generator
# =============================================================================
# プロジェクト構造を解析し、Terraform / AWS CDK / Pulumi のIaCコードを自動生成。
# デプロイ先インフラの自動検出、マルチクラウド対応、セキュリティベストプラクティス注入。
#
# Functions:
#   _iac_init()                - Initialize IaC generator
#   _iac_detect_infra_needs()  - Scan project to detect required infrastructure
#   _iac_generate_terraform()  - Generate Terraform HCL files
#   _iac_generate_cdk()        - Generate AWS CDK TypeScript code
#   _iac_inject_patterns()     - Inject IaC best practices into prompts
#   _iac_report() / _iac_score() - Reporting
#
# All globals use the IAC_ prefix.
# =============================================================================

[[ -n "${_IAC_LOADED:-}" ]] && return 0; _IAC_LOADED=1

# Colors
readonly _IAC_RED='\033[0;31m'
readonly _IAC_GREEN='\033[0;32m'
readonly _IAC_YELLOW='\033[0;33m'
readonly _IAC_CYAN='\033[0;36m'
readonly _IAC_NC='\033[0m'

# =============================================================================
# State
# =============================================================================
declare -g IAC_VERSION="321.0"
IAC_GENERATED=0
IAC_ERRORS=0
IAC_FILES_WRITTEN=0
IAC_TERRAFORM_OK=false
IAC_CDK_OK=false
IAC_DETECT_OK=false

declare -A IAC_DETECTED_SERVICES=()

# =============================================================================
# Init
# =============================================================================
_iac_init() {
    IAC_GENERATED=0
    IAC_ERRORS=0
    IAC_FILES_WRITTEN=0
    IAC_TERRAFORM_OK=false
    IAC_CDK_OK=false
    IAC_DETECT_OK=false
    echo -e "  ${_IAC_GREEN}OK${_IAC_NC} IaC Generator v${IAC_VERSION}" >&2
    return 0
}

# =============================================================================
# Utility
# =============================================================================
_iac_write_file() {
    local filepath="$1"
    local content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        IAC_FILES_WRITTEN=$((IAC_FILES_WRITTEN + 1))
        return 0
    else
        IAC_ERRORS=$((IAC_ERRORS + 1))
        return 1
    fi
}

_iac_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_IAC_CYAN}[iac]${_IAC_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_IAC_GREEN}[iac]${_IAC_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_IAC_YELLOW}[iac]${_IAC_NC} $msg" >&2 ;;
        error) echo -e "  ${_IAC_RED}[iac]${_IAC_NC} $msg" >&2 ;;
    esac
}

# =============================================================================
# Detect Infrastructure Needs from Project
# =============================================================================
_iac_detect_infra_needs() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _iac_log info "Scanning ${project_dir} for infrastructure requirements..."

    IAC_DETECTED_SERVICES=()

    # Detect database needs
    if find "$project_dir" -name "*.prisma" -o -name "*.sql" 2>/dev/null | head -1 | grep -q .; then
        IAC_DETECTED_SERVICES[database]="rds-postgres"
        _iac_log ok "Detected: Database (Prisma/SQL files found)"
    fi

    # Detect Next.js / Node.js
    if [[ -f "${project_dir}/next.config.js" ]] || [[ -f "${project_dir}/next.config.mjs" ]]; then
        IAC_DETECTED_SERVICES[compute]="ecs-fargate"
        IAC_DETECTED_SERVICES[cdn]="cloudfront"
        _iac_log ok "Detected: Next.js app -> ECS Fargate + CloudFront"
    elif [[ -f "${project_dir}/package.json" ]]; then
        if grep -q '"start"' "${project_dir}/package.json" 2>/dev/null; then
            IAC_DETECTED_SERVICES[compute]="ecs-fargate"
            _iac_log ok "Detected: Node.js app -> ECS Fargate"
        fi
    fi

    # Detect file upload needs
    if grep -rq "multer\|formidable\|file-upload\|S3Client" "$project_dir/src" 2>/dev/null; then
        IAC_DETECTED_SERVICES[storage]="s3"
        _iac_log ok "Detected: File uploads -> S3"
    fi

    # Detect Redis/cache needs
    if grep -rq "redis\|ioredis\|bull\|BullMQ" "$project_dir" --include="*.ts" --include="*.json" 2>/dev/null; then
        IAC_DETECTED_SERVICES[cache]="elasticache-redis"
        _iac_log ok "Detected: Redis -> ElastiCache"
    fi

    # Detect email needs
    if grep -rq "nodemailer\|@sendgrid\|ses\|SESClient" "$project_dir/src" 2>/dev/null; then
        IAC_DETECTED_SERVICES[email]="ses"
        _iac_log ok "Detected: Email service -> SES"
    fi

    # Detect WebSocket
    if grep -rq "ws\|socket\.io\|WebSocket" "$project_dir/src" 2>/dev/null; then
        IAC_DETECTED_SERVICES[websocket]="api-gateway-ws"
        _iac_log ok "Detected: WebSocket -> API Gateway WebSocket"
    fi

    # Detect queue/worker
    if grep -rq "bullmq\|sqs\|SQSClient" "$project_dir/src" 2>/dev/null; then
        IAC_DETECTED_SERVICES[queue]="sqs"
        _iac_log ok "Detected: Queue -> SQS"
    fi

    local count=${#IAC_DETECTED_SERVICES[@]}
    _iac_log info "Infrastructure scan complete: ${count} services detected"
    IAC_DETECT_OK=true
    IAC_GENERATED=$((IAC_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate Terraform Configuration
# =============================================================================
_iac_generate_terraform() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local env="${2:-production}"
    local tf_dir="${project_dir}/infra/terraform"

    _iac_log info "Generating Terraform config for ${env}..."

    # main.tf - Provider & Backend
    _iac_write_file "${tf_dir}/main.tf" "$(cat <<'HCL'
# =============================================================================
# SoloptiLinkAI - Terraform Configuration (Auto-Generated)
# =============================================================================

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 5.0"
    }
  }
  backend "s3" {
    bucket         = "terraform-state-${var.project_name}"
    key            = "infra/terraform.tfstate"
    region         = var.aws_region
    encrypt        = true
    dynamodb_table = "terraform-locks"
  }
}

provider "aws" {
  region = var.aws_region
  default_tags {
    tags = {
      Project     = var.project_name
      Environment = var.environment
      ManagedBy   = "terraform"
    }
  }
}
HCL
)"

    # variables.tf
    _iac_write_file "${tf_dir}/variables.tf" "$(cat <<'HCL'
variable "project_name" {
  description = "Project name"
  type        = string
}

variable "environment" {
  description = "Deployment environment"
  type        = string
  default     = "production"
  validation {
    condition     = contains(["development", "staging", "production"], var.environment)
    error_message = "Environment must be development, staging, or production."
  }
}

variable "aws_region" {
  description = "AWS region"
  type        = string
  default     = "ap-northeast-1"
}

variable "db_instance_class" {
  description = "RDS instance class"
  type        = string
  default     = "db.t3.micro"
}

variable "container_cpu" {
  description = "ECS task CPU units"
  type        = number
  default     = 256
}

variable "container_memory" {
  description = "ECS task memory (MiB)"
  type        = number
  default     = 512
}
HCL
)"

    # vpc.tf - Networking
    _iac_write_file "${tf_dir}/modules/vpc/main.tf" "$(cat <<'HCL'
# VPC with public/private subnets
resource "aws_vpc" "main" {
  cidr_block           = "10.0.0.0/16"
  enable_dns_hostnames = true
  enable_dns_support   = true
  tags = { Name = "${var.project_name}-vpc" }
}

resource "aws_subnet" "public" {
  count             = 2
  vpc_id            = aws_vpc.main.id
  cidr_block        = cidrsubnet(aws_vpc.main.cidr_block, 8, count.index)
  availability_zone = data.aws_availability_zones.available.names[count.index]
  map_public_ip_on_launch = true
  tags = { Name = "${var.project_name}-public-${count.index}" }
}

resource "aws_subnet" "private" {
  count             = 2
  vpc_id            = aws_vpc.main.id
  cidr_block        = cidrsubnet(aws_vpc.main.cidr_block, 8, count.index + 10)
  availability_zone = data.aws_availability_zones.available.names[count.index]
  tags = { Name = "${var.project_name}-private-${count.index}" }
}

data "aws_availability_zones" "available" { state = "available" }
HCL
)"

    # Generate service-specific modules based on detection
    if [[ "${IAC_DETECTED_SERVICES[database]:-}" == "rds-postgres" ]]; then
        _iac_write_file "${tf_dir}/modules/database/main.tf" "$(cat <<'HCL'
resource "aws_db_subnet_group" "main" {
  name       = "${var.project_name}-db-subnet"
  subnet_ids = var.private_subnet_ids
}

resource "aws_db_instance" "main" {
  identifier              = "${var.project_name}-db"
  engine                  = "postgres"
  engine_version          = "15.4"
  instance_class          = var.db_instance_class
  allocated_storage       = 20
  max_allocated_storage   = 100
  storage_encrypted       = true
  db_subnet_group_name    = aws_db_subnet_group.main.name
  vpc_security_group_ids  = [var.db_security_group_id]
  backup_retention_period = 7
  deletion_protection     = var.environment == "production"
  skip_final_snapshot     = var.environment != "production"
  multi_az                = var.environment == "production"
}
HCL
)"
    fi

    if [[ "${IAC_DETECTED_SERVICES[compute]:-}" == "ecs-fargate" ]]; then
        _iac_write_file "${tf_dir}/modules/ecs/main.tf" "$(cat <<'HCL'
resource "aws_ecs_cluster" "main" {
  name = "${var.project_name}-cluster"
  setting {
    name  = "containerInsights"
    value = "enabled"
  }
}

resource "aws_ecs_task_definition" "app" {
  family                   = "${var.project_name}-app"
  requires_compatibilities = ["FARGATE"]
  network_mode             = "awsvpc"
  cpu                      = var.container_cpu
  memory                   = var.container_memory
  execution_role_arn       = aws_iam_role.ecs_execution.arn
  task_role_arn            = aws_iam_role.ecs_task.arn
  container_definitions = jsonencode([{
    name      = "app"
    image     = "${var.ecr_repo_url}:latest"
    essential = true
    portMappings = [{ containerPort = 3000, protocol = "tcp" }]
    logConfiguration = {
      logDriver = "awslogs"
      options   = {
        "awslogs-group"         = "/ecs/${var.project_name}"
        "awslogs-region"        = var.aws_region
        "awslogs-stream-prefix" = "app"
      }
    }
    environment = [
      { name = "NODE_ENV", value = var.environment },
      { name = "DATABASE_URL", value = var.database_url }
    ]
  }])
}

resource "aws_ecs_service" "app" {
  name            = "${var.project_name}-service"
  cluster         = aws_ecs_cluster.main.id
  task_definition = aws_ecs_task_definition.app.arn
  desired_count   = var.environment == "production" ? 2 : 1
  launch_type     = "FARGATE"
  network_configuration {
    subnets          = var.private_subnet_ids
    security_groups  = [var.app_security_group_id]
    assign_public_ip = false
  }
  load_balancer {
    target_group_arn = var.target_group_arn
    container_name   = "app"
    container_port   = 3000
  }
}
HCL
)"
    fi

    _iac_log ok "Terraform config generated: ${tf_dir}"
    IAC_TERRAFORM_OK=true
    IAC_GENERATED=$((IAC_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate AWS CDK TypeScript
# =============================================================================
_iac_generate_cdk() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local cdk_dir="${project_dir}/infra/cdk"

    _iac_log info "Generating AWS CDK TypeScript..."

    _iac_write_file "${cdk_dir}/lib/app-stack.ts" "$(cat <<'TYPESCRIPT'
import * as cdk from 'aws-cdk-lib';
import * as ec2 from 'aws-cdk-lib/aws-ec2';
import * as ecs from 'aws-cdk-lib/aws-ecs';
import * as ecr from 'aws-cdk-lib/aws-ecr';
import * as elbv2 from 'aws-cdk-lib/aws-elasticloadbalancingv2';
import * as rds from 'aws-cdk-lib/aws-rds';
import { Construct } from 'constructs';

export interface AppStackProps extends cdk.StackProps {
  environment: 'development' | 'staging' | 'production';
}

export class AppStack extends cdk.Stack {
  constructor(scope: Construct, id: string, props: AppStackProps) {
    super(scope, id, props);

    const isProd = props.environment === 'production';

    // VPC
    const vpc = new ec2.Vpc(this, 'AppVpc', {
      maxAzs: isProd ? 3 : 2,
      natGateways: isProd ? 2 : 1,
    });

    // RDS
    const db = new rds.DatabaseInstance(this, 'Database', {
      engine: rds.DatabaseInstanceEngine.postgres({ version: rds.PostgresEngineVersion.VER_15_4 }),
      instanceType: ec2.InstanceType.of(ec2.InstanceClass.T3, ec2.InstanceSize.MICRO),
      vpc,
      vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
      multiAz: isProd,
      deletionProtection: isProd,
      backupRetention: cdk.Duration.days(isProd ? 14 : 3),
      storageEncrypted: true,
    });

    // ECS Cluster
    const cluster = new ecs.Cluster(this, 'Cluster', { vpc, containerInsights: true });

    // Fargate Service
    const taskDef = new ecs.FargateTaskDefinition(this, 'TaskDef', {
      memoryLimitMiB: 512,
      cpu: 256,
    });

    taskDef.addContainer('app', {
      image: ecs.ContainerImage.fromEcrRepository(
        ecr.Repository.fromRepositoryName(this, 'Repo', `${id}-app`)
      ),
      portMappings: [{ containerPort: 3000 }],
      environment: { NODE_ENV: props.environment },
      logging: ecs.LogDrivers.awsLogs({ streamPrefix: 'app' }),
    });

    const service = new ecs.FargateService(this, 'Service', {
      cluster,
      taskDefinition: taskDef,
      desiredCount: isProd ? 2 : 1,
      vpcSubnets: { subnetType: ec2.SubnetType.PRIVATE_WITH_EGRESS },
    });

    // ALB
    const alb = new elbv2.ApplicationLoadBalancer(this, 'ALB', {
      vpc,
      internetFacing: true,
    });

    const listener = alb.addListener('Listener', { port: 443 });
    listener.addTargets('AppTarget', {
      port: 3000,
      targets: [service],
      healthCheck: { path: '/api/health', interval: cdk.Duration.seconds(30) },
    });

    // Outputs
    new cdk.CfnOutput(this, 'AlbDns', { value: alb.loadBalancerDnsName });
    new cdk.CfnOutput(this, 'DbEndpoint', { value: db.dbInstanceEndpointAddress });
  }
}
TYPESCRIPT
)"

    _iac_write_file "${cdk_dir}/bin/app.ts" "$(cat <<'TYPESCRIPT'
#!/usr/bin/env node
import 'source-map-support/register';
import * as cdk from 'aws-cdk-lib';
import { AppStack } from '../lib/app-stack';

const app = new cdk.App();
const env = (app.node.tryGetContext('env') || 'production') as 'development' | 'staging' | 'production';

new AppStack(app, `App-${env}`, {
  environment: env,
  env: { region: process.env.CDK_DEFAULT_REGION || 'ap-northeast-1' },
});
TYPESCRIPT
)"

    _iac_log ok "CDK TypeScript generated: ${cdk_dir}"
    IAC_CDK_OK=true
    IAC_GENERATED=$((IAC_GENERATED + 1))
    return 0
}

# =============================================================================
# Inject IaC patterns into prompts
# =============================================================================
_iac_inject_patterns() {
    cat <<'INJECT'

## [IAC-GENERATOR] Infrastructure as Code Best Practices (MANDATORY)
- All infrastructure MUST be defined in code (Terraform or CDK)
- Use remote state (S3 + DynamoDB locking) for Terraform
- Enable encryption at rest for all data stores
- Use private subnets for compute, public only for load balancers
- Enable deletion protection in production
- Tag all resources with Project, Environment, ManagedBy
- Use IAM roles (not keys) for service-to-service auth

INJECT
}

# =============================================================================
# Report
# =============================================================================
_iac_report() {
    echo -e "\n  ${_IAC_CYAN}=== IaC Generator v${IAC_VERSION} ===${_IAC_NC}"
    echo -e "  Generated components: ${IAC_GENERATED}"
    echo -e "  Files written: ${IAC_FILES_WRITTEN}"
    echo -e "  Detection: $( ${IAC_DETECT_OK} && echo -e "${_IAC_GREEN}OK${_IAC_NC}" || echo 'SKIP')"
    echo -e "  Terraform: $( ${IAC_TERRAFORM_OK} && echo -e "${_IAC_GREEN}OK${_IAC_NC}" || echo 'SKIP')"
    echo -e "  CDK: $( ${IAC_CDK_OK} && echo -e "${_IAC_GREEN}OK${_IAC_NC}" || echo 'SKIP')"
    echo -e "  Detected services: ${#IAC_DETECTED_SERVICES[@]}"
    echo -e "  Errors: ${IAC_ERRORS}"
}

_iac_score() {
    local score=50
    ${IAC_DETECT_OK} && score=$((score + 15))
    ${IAC_TERRAFORM_OK} && score=$((score + 15))
    ${IAC_CDK_OK} && score=$((score + 15))
    [[ ${IAC_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry self-registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "iac-generator" --version "321.0" \
        --description "IaC自動生成 Terraform/CDK (v321)" \
        --init "_iac_init" --report "_iac_report" --score "_iac_score" \
        --enable-var "ENABLE_IAC_GENERATOR" --cli-flags "--iac-generator:--no-iac-generator"
fi

# v2003.1: source時のexit codeを確実に0にする
true
