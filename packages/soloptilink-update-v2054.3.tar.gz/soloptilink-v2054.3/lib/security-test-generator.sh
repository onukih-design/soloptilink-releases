#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v341.0 - Security Test Generator
# =============================================================================
# OWASPテスト、インジェクションテスト、認証テスト自動生成。
# XSS/SQLi/CSRF/認可バイパス検出テスト。
#
# Functions:
#   _stg_init()                     - Initialize
#   _stg_generate_owasp_tests()     - Generate OWASP Top 10 tests
#   _stg_generate_injection_tests() - Generate injection attack tests
#   _stg_generate_auth_tests()      - Generate auth/authz tests
#   _stg_report() / _stg_score()
# =============================================================================

[[ -n "${_STG_LOADED:-}" ]] && return 0; _STG_LOADED=1

readonly _STG_RED='\033[0;31m'
readonly _STG_GREEN='\033[0;32m'
readonly _STG_YELLOW='\033[0;33m'
readonly _STG_CYAN='\033[0;36m'
readonly _STG_NC='\033[0m'

declare -g STG_VERSION="341.0"
STG_GENERATED=0; STG_ERRORS=0; STG_FILES_WRITTEN=0
STG_OWASP_OK=false; STG_INJECTION_OK=false; STG_AUTH_OK=false

_stg_init() {
    STG_GENERATED=0; STG_ERRORS=0; STG_FILES_WRITTEN=0
    STG_OWASP_OK=false; STG_INJECTION_OK=false; STG_AUTH_OK=false
    echo -e "  ${_STG_GREEN}OK${_STG_NC} Security Test Generator v${STG_VERSION}" >&2
    return 0
}

_stg_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { STG_FILES_WRITTEN=$((STG_FILES_WRITTEN + 1)); return 0; }
    STG_ERRORS=$((STG_ERRORS + 1)); return 1
}

_stg_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_STG_CYAN}[sec-test]${_STG_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_STG_GREEN}[sec-test]${_STG_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_STG_YELLOW}[sec-test]${_STG_NC} $msg" >&2 ;;
        error) echo -e "  ${_STG_RED}[sec-test]${_STG_NC} $msg" >&2 ;;
    esac
}

_stg_generate_owasp_tests() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local sec_dir="${project_dir}/tests/security"

    _stg_log info "Generating OWASP Top 10 tests..."

    _stg_write_file "${sec_dir}/owasp.test.ts" "$(cat <<'TYPESCRIPT'
import { describe, it, expect } from 'vitest';

const BASE_URL = process.env.BASE_URL || 'http://localhost:3000';

describe('OWASP Top 10 Security Tests', () => {
  // A01: Broken Access Control
  describe('Access Control', () => {
    it('should enforce authentication on protected routes', async () => {
      const protectedRoutes = ['/api/v1/users', '/api/v1/admin/settings'];
      for (const route of protectedRoutes) {
        const res = await fetch(`${BASE_URL}${route}`);
        expect(res.status).toBe(401);
      }
    });

    it('should prevent IDOR (Insecure Direct Object Reference)', async () => {
      // User A should not access User B data
      const res = await fetch(`${BASE_URL}/api/v1/users/other-user-id`, {
        headers: { Authorization: 'Bearer user-a-token' },
      });
      expect([403, 404]).toContain(res.status);
    });

    it('should enforce role-based access', async () => {
      const res = await fetch(`${BASE_URL}/api/v1/admin/settings`, {
        headers: { Authorization: 'Bearer regular-user-token' },
      });
      expect(res.status).toBe(403);
    });
  });

  // A02: Cryptographic Failures
  describe('Cryptographic Security', () => {
    it('should enforce HTTPS (HSTS header)', async () => {
      const res = await fetch(`${BASE_URL}/api/health`);
      const hsts = res.headers.get('strict-transport-security');
      // In production, HSTS should be set
      if (process.env.NODE_ENV === 'production') {
        expect(hsts).toBeTruthy();
      }
    });

    it('should not expose sensitive data in responses', async () => {
      const res = await fetch(`${BASE_URL}/api/v1/users/1`, {
        headers: { Authorization: 'Bearer admin-token' },
      });
      if (res.ok) {
        const body = await res.json();
        expect(body.password).toBeUndefined();
        expect(body.passwordHash).toBeUndefined();
      }
    });
  });

  // A03: Injection
  describe('Injection Prevention', () => {
    it('should reject SQL injection in query params', async () => {
      const res = await fetch(`${BASE_URL}/api/v1/users?search=' OR 1=1 --`);
      expect(res.status).not.toBe(500);
    });
  });

  // A05: Security Misconfiguration
  describe('Security Headers', () => {
    it('should set security headers', async () => {
      const res = await fetch(`${BASE_URL}/api/health`);
      expect(res.headers.get('x-content-type-options')).toBe('nosniff');
      expect(res.headers.get('x-frame-options')).toBeTruthy();
    });

    it('should not expose server info', async () => {
      const res = await fetch(`${BASE_URL}/api/health`);
      const server = res.headers.get('server');
      expect(server).not.toContain('Express');
    });
  });

  // A07: Cross-Site Scripting (XSS)
  describe('XSS Prevention', () => {
    it('should sanitize HTML in user input', async () => {
      const payload = '<script>alert("xss")</script>';
      const res = await fetch(`${BASE_URL}/api/v1/users`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer admin-token' },
        body: JSON.stringify({ name: payload, email: 'xss@test.com' }),
      });
      if (res.ok) {
        const body = await res.json();
        expect(body.name).not.toContain('<script>');
      }
    });
  });
});
TYPESCRIPT
)"

    _stg_log ok "OWASP tests generated"
    STG_OWASP_OK=true
    STG_GENERATED=$((STG_GENERATED + 1))
    return 0
}

_stg_generate_injection_tests() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local sec_dir="${project_dir}/tests/security"

    _stg_log info "Generating injection attack tests..."

    _stg_write_file "${sec_dir}/injection.test.ts" "$(cat <<'TYPESCRIPT'
import { describe, it, expect } from 'vitest';

const BASE_URL = process.env.BASE_URL || 'http://localhost:3000';

const SQL_PAYLOADS = [
  "' OR '1'='1", "'; DROP TABLE users; --", "1 UNION SELECT * FROM users",
  "' OR 1=1--", "admin'--", "1; UPDATE users SET role='admin'",
];

const XSS_PAYLOADS = [
  '<script>alert(1)</script>', '<img src=x onerror=alert(1)>',
  '"><script>alert(1)</script>', "javascript:alert(1)",
  '<svg onload=alert(1)>', "';alert(1);//",
];

const NOSQL_PAYLOADS = [
  '{"$gt": ""}', '{"$ne": null}', '{"$regex": ".*"}',
];

describe('SQL Injection Tests', () => {
  for (const payload of SQL_PAYLOADS) {
    it(`should reject: ${payload.substring(0, 30)}...`, async () => {
      const res = await fetch(`${BASE_URL}/api/v1/users?search=${encodeURIComponent(payload)}`);
      expect(res.status).not.toBe(500);
      const body = await res.text();
      expect(body).not.toContain('syntax error');
      expect(body).not.toContain('SQLSTATE');
    });
  }
});

describe('XSS Injection Tests', () => {
  for (const payload of XSS_PAYLOADS) {
    it(`should sanitize: ${payload.substring(0, 30)}...`, async () => {
      const res = await fetch(`${BASE_URL}/api/v1/tasks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Authorization: 'Bearer test-token' },
        body: JSON.stringify({ title: payload }),
      });
      if (res.ok) {
        const body = await res.json();
        expect(JSON.stringify(body)).not.toContain('<script>');
        expect(JSON.stringify(body)).not.toContain('onerror=');
      }
    });
  }
});

describe('Path Traversal Tests', () => {
  const traversalPayloads = ['../../etc/passwd', '..\\..\\windows\\system32', '%2e%2e%2f%2e%2e%2f'];
  for (const payload of traversalPayloads) {
    it(`should block: ${payload}`, async () => {
      const res = await fetch(`${BASE_URL}/api/v1/files/${encodeURIComponent(payload)}`);
      expect([400, 403, 404]).toContain(res.status);
    });
  }
});
TYPESCRIPT
)"

    _stg_log ok "Injection tests generated"
    STG_INJECTION_OK=true
    STG_GENERATED=$((STG_GENERATED + 1))
    return 0
}

_stg_generate_auth_tests() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local sec_dir="${project_dir}/tests/security"

    _stg_log info "Generating auth/authz tests..."

    _stg_write_file "${sec_dir}/auth-security.test.ts" "$(cat <<'TYPESCRIPT'
import { describe, it, expect } from 'vitest';

const BASE_URL = process.env.BASE_URL || 'http://localhost:3000';

describe('Authentication Security', () => {
  it('should rate-limit login attempts', async () => {
    const results = [];
    for (let i = 0; i < 10; i++) {
      const res = await fetch(`${BASE_URL}/api/v1/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email: 'test@test.com', password: `wrong${i}` }),
      });
      results.push(res.status);
    }
    expect(results).toContain(429); // Should rate-limit after several attempts
  });

  it('should not leak user existence via timing', async () => {
    const start1 = Date.now();
    await fetch(`${BASE_URL}/api/v1/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'existing@test.com', password: 'wrong' }),
    });
    const time1 = Date.now() - start1;

    const start2 = Date.now();
    await fetch(`${BASE_URL}/api/v1/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'nonexistent@test.com', password: 'wrong' }),
    });
    const time2 = Date.now() - start2;

    // Response times should be similar (within 100ms)
    expect(Math.abs(time1 - time2)).toBeLessThan(100);
  });

  it('should reject expired JWT tokens', async () => {
    const expiredToken = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJleHAiOjB9.invalid';
    const res = await fetch(`${BASE_URL}/api/v1/users`, {
      headers: { Authorization: `Bearer ${expiredToken}` },
    });
    expect(res.status).toBe(401);
  });

  it('should reject malformed JWT tokens', async () => {
    const tokens = ['invalid', 'Bearer ', 'Bearer invalid.token', 'null'];
    for (const token of tokens) {
      const res = await fetch(`${BASE_URL}/api/v1/users`, {
        headers: { Authorization: token },
      });
      expect(res.status).toBe(401);
    }
  });
});
TYPESCRIPT
)"

    _stg_log ok "Auth security tests generated"
    STG_AUTH_OK=true
    STG_GENERATED=$((STG_GENERATED + 1))
    return 0
}

_stg_report() {
    echo -e "\n  ${_STG_CYAN}=== Security Test Generator v${STG_VERSION} ===${_STG_NC}"
    echo -e "  Generated: ${STG_GENERATED} | Files: ${STG_FILES_WRITTEN} | Errors: ${STG_ERRORS}"
    echo -e "  OWASP: $( ${STG_OWASP_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Injection: $( ${STG_INJECTION_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Auth: $( ${STG_AUTH_OK} && echo 'OK' || echo 'SKIP')"
}

_stg_score() {
    local score=50
    ${STG_OWASP_OK} && score=$((score + 15))
    ${STG_INJECTION_OK} && score=$((score + 15))
    ${STG_AUTH_OK} && score=$((score + 15))
    [[ ${STG_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "security-test-generator" --version "341.0" \
        --description "セキュリティテスト自動生成 OWASP/インジェクション/認証 (v341)" \
        --init "_stg_init" --report "_stg_report" --score "_stg_score" \
        --enable-var "ENABLE_SEC_TEST_GEN" --cli-flags "--sec-test-gen:--no-sec-test-gen"
fi

# v2003.1: source時のexit codeを確実に0にする
true
