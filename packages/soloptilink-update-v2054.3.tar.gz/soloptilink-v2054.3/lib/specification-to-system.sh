#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v406.0 - Specification to System Engine
# =============================================================================
# 仕様書（テキスト/マークダウン）からシステムアーキテクチャ・コード構造を
# 自動生成する。要件抽出・アーキテクチャ設計・システムスキャフォールドを統合。
#
# Functions:
#   _sts_init                - 初期化
#   _sts_parse_spec          - 仕様書パース・要件抽出
#   _sts_generate_architecture - アーキテクチャ設計生成
#   _sts_generate_system     - システムスキャフォールド生成
#   _sts_validate_coverage   - 仕様カバレッジ検証
#   _sts_report              - レポート出力
#   _sts_score               - モジュールスコア(0-100)
#
# All globals use the STS_ prefix.
# =============================================================================

[[ -n "${_SPECIFICATION_TO_SYSTEM_LOADED:-}" ]] && return 0
_SPECIFICATION_TO_SYSTEM_LOADED=1

declare -g STS_VERSION="406.0"
declare -g STS_INITIALIZED=false
declare -g STS_STORE_DIR=""
declare -g STS_SPEC_PARSED=0
declare -g STS_ARCH_GENERATED=0
declare -g STS_SYSTEM_GENERATED=0
declare -g STS_COVERAGE_SCORE=0

declare -g -A _STS_REQUIREMENTS=()      # req_id → description
declare -g -A _STS_REQ_PRIORITY=()      # req_id → high/medium/low
declare -g -A _STS_REQ_TYPE=()          # req_id → functional/non-functional/constraint
declare -g -A _STS_ENTITIES=()          # entity_name → fields_list
declare -g -A _STS_RELATIONS=()         # entity_a → "relation:entity_b"
declare -g -a _STS_TECH_DECISIONS=()    # technology decisions

# =============================================================================
_sts_init() {
    local project_dir="${PROJECT_DIR:-.}"
    STS_STORE_DIR="${project_dir}/.soloptilink/spec-to-system"
    mkdir -p "${STS_STORE_DIR}/specs" "${STS_STORE_DIR}/architectures" "${STS_STORE_DIR}/systems"

    STS_INITIALIZED=true
    return 0
}

# =============================================================================
# _sts_parse_spec - Parse specification document and extract requirements
# =============================================================================
_sts_parse_spec() {
    local spec_text="$1"
    [[ -z "$spec_text" ]] && { echo "ERROR: Empty specification" >&2; return 1; }

    STS_SPEC_PARSED=$((STS_SPEC_PARSED + 1))
    local req_count=0

    # Extract functional requirements (lines with "shall", "must", "should")
    while IFS= read -r line; do
        if echo "$line" | grep -qiE '(shall|must|should|need to|has to|required to)'; then
            req_count=$((req_count + 1))
            local req_id="REQ-$(printf '%03d' $req_count)"
            _STS_REQUIREMENTS["$req_id"]="$line"

            # Determine priority
            if echo "$line" | grep -qi 'must\|critical\|essential'; then
                _STS_REQ_PRIORITY["$req_id"]="high"
            elif echo "$line" | grep -qi 'should\|important'; then
                _STS_REQ_PRIORITY["$req_id"]="medium"
            else
                _STS_REQ_PRIORITY["$req_id"]="low"
            fi

            # Determine type
            if echo "$line" | grep -qiE 'performance|security|scalability|reliability|availability'; then
                _STS_REQ_TYPE["$req_id"]="non-functional"
            elif echo "$line" | grep -qiE 'constraint|limit|restrict|boundary'; then
                _STS_REQ_TYPE["$req_id"]="constraint"
            else
                _STS_REQ_TYPE["$req_id"]="functional"
            fi
        fi
    done <<< "$spec_text"

    # Extract entities (nouns after "manage", "track", "store", etc.)
    local entities_found
    entities_found=$(echo "$spec_text" | grep -oiE '(manage|track|store|handle|process)\s+[a-zA-Z]+' | awk '{print $2}' | sort -u)
    while IFS= read -r entity; do
        [[ -z "$entity" ]] && continue
        local entity_cap
        entity_cap=$(echo "$entity" | sed 's/^./\U&/')
        _STS_ENTITIES["$entity_cap"]="id,createdAt,updatedAt"
    done <<< "$entities_found"

    # Extract data fields from "with ... fields" or attribute mentions
    for entity_key in "${!_STS_ENTITIES[@]}"; do
        local entity_lower
        entity_lower=$(echo "$entity_key" | tr '[:upper:]' '[:lower:]')
        local fields_match
        fields_match=$(echo "$spec_text" | grep -oiE "${entity_lower}\s+(has|with|includes?)\s+[^.;]+" | head -1)
        if [[ -n "$fields_match" ]]; then
            local extra_fields
            extra_fields=$(echo "$fields_match" | grep -oE '[a-z]+' | grep -v "$entity_lower\|has\|with\|include\|includes\|and\|the\|a" | tr '\n' ',' | sed 's/,$//')
            [[ -n "$extra_fields" ]] && _STS_ENTITIES["$entity_key"]="${_STS_ENTITIES[$entity_key]},${extra_fields}"
        fi
    done

    # Detect relationships
    local rel_patterns
    rel_patterns=$(echo "$spec_text" | grep -oiE '[A-Za-z]+\s+(belongs to|has many|has one|references)\s+[A-Za-z]+')
    while IFS= read -r rel; do
        [[ -z "$rel" ]] && continue
        local from_entity to_entity rel_type
        from_entity=$(echo "$rel" | awk '{print $1}')
        to_entity=$(echo "$rel" | awk '{print $NF}')
        if echo "$rel" | grep -qi 'has many'; then
            rel_type="hasMany"
        elif echo "$rel" | grep -qi 'belongs to'; then
            rel_type="belongsTo"
        else
            rel_type="hasOne"
        fi
        _STS_RELATIONS["$from_entity"]="${rel_type}:${to_entity}"
    done <<< "$rel_patterns"

    # Save parsed spec
    local timestamp
    timestamp=$(date +%s 2>/dev/null || echo "0")
    echo "$spec_text" > "${STS_STORE_DIR}/specs/spec_${timestamp}.md" 2>/dev/null

    local high_count=0 med_count=0 low_count=0
    for req_id in "${!_STS_REQ_PRIORITY[@]}"; do
        case "${_STS_REQ_PRIORITY[$req_id]}" in
            high) high_count=$((high_count + 1)) ;;
            medium) med_count=$((med_count + 1)) ;;
            low) low_count=$((low_count + 1)) ;;
        esac
    done

    cat <<PARSEEOF
{"requirements":${req_count},"entities":${#_STS_ENTITIES[@]},"relations":${#_STS_RELATIONS[@]},"priority":{"high":${high_count},"medium":${med_count},"low":${low_count}}}
PARSEEOF
    return 0
}

# =============================================================================
# _sts_generate_architecture - Generate system architecture from parsed spec
# =============================================================================
_sts_generate_architecture() {
    local app_name="${1:-MyApp}"
    local tech_stack="${2:-nextjs}"  # nextjs|express|fastapi

    [[ "$STS_INITIALIZED" != "true" ]] && { echo "ERROR: STS not initialized" >&2; return 1; }
    STS_ARCH_GENERATED=$((STS_ARCH_GENERATED + 1))

    local entity_count=${#_STS_ENTITIES[@]}
    local req_count=${#_STS_REQUIREMENTS[@]}

    # Determine architecture pattern
    local arch_pattern="monolith"
    [[ $entity_count -gt 10 ]] && arch_pattern="modular-monolith"
    [[ $entity_count -gt 20 ]] && arch_pattern="microservices"

    # Technology decisions
    _STS_TECH_DECISIONS=()
    case "$tech_stack" in
        nextjs)
            _STS_TECH_DECISIONS+=("framework:Next.js 15 App Router")
            _STS_TECH_DECISIONS+=("database:PostgreSQL + Prisma ORM")
            _STS_TECH_DECISIONS+=("auth:NextAuth.js + JWT")
            _STS_TECH_DECISIONS+=("ui:Tailwind CSS + shadcn/ui")
            _STS_TECH_DECISIONS+=("validation:zod")
            ;;
        express)
            _STS_TECH_DECISIONS+=("framework:Express.js + TypeScript")
            _STS_TECH_DECISIONS+=("database:PostgreSQL + Prisma ORM")
            _STS_TECH_DECISIONS+=("auth:Passport.js + JWT")
            _STS_TECH_DECISIONS+=("validation:zod")
            ;;
        fastapi)
            _STS_TECH_DECISIONS+=("framework:FastAPI + Python")
            _STS_TECH_DECISIONS+=("database:PostgreSQL + SQLAlchemy")
            _STS_TECH_DECISIONS+=("auth:FastAPI Security + JWT")
            _STS_TECH_DECISIONS+=("validation:Pydantic")
            ;;
    esac

    # Check for non-functional requirements and add tech decisions
    for req_id in "${!_STS_REQ_TYPE[@]}"; do
        local req_type="${_STS_REQ_TYPE[$req_id]}"
        local req_text="${_STS_REQUIREMENTS[$req_id]}"
        if [[ "$req_type" == "non-functional" ]]; then
            if echo "$req_text" | grep -qi 'real.?time'; then
                _STS_TECH_DECISIONS+=("realtime:WebSocket (Socket.io)")
            fi
            if echo "$req_text" | grep -qi 'search'; then
                _STS_TECH_DECISIONS+=("search:Meilisearch")
            fi
            if echo "$req_text" | grep -qi 'cache\|fast'; then
                _STS_TECH_DECISIONS+=("cache:Redis")
            fi
        fi
    done

    # Generate architecture document
    cat <<ARCHEOF
# ${app_name} - System Architecture

## Pattern: ${arch_pattern}
## Entities: ${entity_count}
## Requirements: ${req_count}

## Technology Stack
$(for td in "${_STS_TECH_DECISIONS[@]}"; do echo "- ${td%%:*}: ${td#*:}"; done)

## Data Model
$(for entity in "${!_STS_ENTITIES[@]}"; do
    echo "### ${entity}"
    echo "Fields: ${_STS_ENTITIES[$entity]}"
    [[ -n "${_STS_RELATIONS[$entity]:-}" ]] && echo "Relations: ${_STS_RELATIONS[$entity]}"
    echo ""
done)

## API Routes
$(for entity in "${!_STS_ENTITIES[@]}"; do
    local lower_entity
    lower_entity=$(echo "$entity" | tr '[:upper:]' '[:lower:]')
    echo "- GET    /api/${lower_entity}s"
    echo "- POST   /api/${lower_entity}s"
    echo "- GET    /api/${lower_entity}s/:id"
    echo "- PUT    /api/${lower_entity}s/:id"
    echo "- DELETE /api/${lower_entity}s/:id"
done)
ARCHEOF
    return 0
}

# =============================================================================
# _sts_generate_system - Generate system scaffold (Prisma schema + routes)
# =============================================================================
_sts_generate_system() {
    local output_dir="${1:-}"
    [[ "$STS_INITIALIZED" != "true" ]] && { echo "ERROR: STS not initialized" >&2; return 1; }
    STS_SYSTEM_GENERATED=$((STS_SYSTEM_GENERATED + 1))

    # Generate Prisma schema
    echo "// Generated Prisma Schema"
    echo "generator client { provider = \"prisma-client-js\" }"
    echo "datasource db { provider = \"postgresql\" url = env(\"DATABASE_URL\") }"
    echo ""

    for entity in "${!_STS_ENTITIES[@]}"; do
        echo "model ${entity} {"
        local fields="${_STS_ENTITIES[$entity]}"
        IFS=',' read -ra field_arr <<< "$fields"
        for field in "${field_arr[@]}"; do
            field=$(echo "$field" | xargs)
            case "$field" in
                id) echo "  id        String   @id @default(cuid())" ;;
                createdAt) echo "  createdAt DateTime @default(now())" ;;
                updatedAt) echo "  updatedAt DateTime @updatedAt" ;;
                email) echo "  email     String   @unique" ;;
                name|title) echo "  ${field}      String" ;;
                *) echo "  ${field}    String?" ;;
            esac
        done
        echo "}"
        echo ""
    done

    return 0
}

# =============================================================================
# _sts_validate_coverage - Validate spec coverage
# =============================================================================
_sts_validate_coverage() {
    local total_reqs=${#_STS_REQUIREMENTS[@]}
    [[ $total_reqs -eq 0 ]] && { echo "0"; return 0; }

    local covered=0
    for req_id in "${!_STS_REQUIREMENTS[@]}"; do
        local req_text="${_STS_REQUIREMENTS[$req_id]}"
        local is_covered=false
        for entity in "${!_STS_ENTITIES[@]}"; do
            local entity_lower
            entity_lower=$(echo "$entity" | tr '[:upper:]' '[:lower:]')
            if echo "$req_text" | grep -qi "$entity_lower"; then
                is_covered=true
                break
            fi
        done
        [[ "$is_covered" == "true" ]] && covered=$((covered + 1))
    done

    STS_COVERAGE_SCORE=$(( (covered * 100) / total_reqs ))
    echo "$STS_COVERAGE_SCORE"
    return 0
}

# =============================================================================
# Report / Score
# =============================================================================
_sts_report() {
    echo -e "\n  ${BOLD:-}=== Specification to System v${STS_VERSION} ===${NC:-}"
    echo -e "  Specs Parsed       : ${STS_SPEC_PARSED}"
    echo -e "  Architectures      : ${STS_ARCH_GENERATED}"
    echo -e "  Systems Generated  : ${STS_SYSTEM_GENERATED}"
    echo -e "  Requirements       : ${#_STS_REQUIREMENTS[@]}"
    echo -e "  Entities           : ${#_STS_ENTITIES[@]}"
    echo -e "  Coverage Score     : ${STS_COVERAGE_SCORE}%"
}

_sts_score() {
    local score=30
    [[ "$STS_INITIALIZED" == "true" ]] && score=$((score + 15))
    [[ $STS_SPEC_PARSED -gt 0 ]] && score=$((score + 15))
    [[ $STS_ARCH_GENERATED -gt 0 ]] && score=$((score + 15))
    [[ $STS_SYSTEM_GENERATED -gt 0 ]] && score=$((score + 10))
    [[ $STS_COVERAGE_SCORE -ge 70 ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "specification-to-system" \
        --version "406.0" \
        --description "仕様書からアーキテクチャ・システムスキャフォールド自動生成" \
        --init "_sts_init" \
        --report "_sts_report" \
        --score "_sts_score" \
        --enable-var "ENABLE_STS" \
        --cli-flags "--spec-to-system:--no-spec-to-system"
fi

# v2003.1: source時のexit codeを確実に0にする
true
