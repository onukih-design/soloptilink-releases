#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v436.0 - Memory Management Engine
# =============================================================================
# メモリリーク検出・GC最適化・メモリ制限設定の自動化。
# Node.js/フロントエンドのメモリ問題をコード解析で検出する。
#
# Functions:
#   _mm_init()            - 初期化
#   _mm_detect_leaks()    - メモリリーク検出
#   _mm_optimize_gc()     - GC最適化設定
#   _mm_set_limits()      - メモリ制限設定
#   _mm_report() / _mm_score()
#
# All globals use the MM_ prefix.
# =============================================================================

[[ -n "${_MM_LOADED:-}" ]] && return 0; _MM_LOADED=1

declare -g MM_VERSION="436.0"
declare -g MM_GENERATED=0
declare -g MM_ERRORS=0
declare -g MM_LEAK_PATTERNS=0
declare -g MM_GC_OPTIMIZATIONS=0
declare -g MM_LIMITS_SET=0
declare -g MM_FILES_SCANNED=0

declare -ga _MM_FINDINGS=()

_MM_GREEN="${GREEN:-\033[0;32m}"
_MM_RED="${RED:-\033[0;31m}"
_MM_YELLOW="${YELLOW:-\033[0;33m}"
_MM_CYAN="${CYAN:-\033[0;36m}"
_MM_BOLD="${BOLD:-\033[1m}"
_MM_NC="${NC:-\033[0m}"

_mm_init() {
    MM_GENERATED=0; MM_ERRORS=0; MM_LEAK_PATTERNS=0
    MM_GC_OPTIMIZATIONS=0; MM_LIMITS_SET=0; MM_FILES_SCANNED=0
    _MM_FINDINGS=()
    return 0
}

_mm_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_MM_CYAN}[MM]${_MM_NC} $*" >&2 ;;
        ok)    echo -e "  ${_MM_GREEN}[MM]${_MM_NC} $*" >&2 ;;
        warn)  echo -e "  ${_MM_YELLOW}[MM]${_MM_NC} $*" >&2 ;;
        error) echo -e "  ${_MM_RED}[MM]${_MM_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _mm_detect_leaks - メモリリーク検出
# =============================================================================
_mm_detect_leaks() {
    local project_dir="${1:-.}"
    _mm_log info "メモリリークパターン検出"

    MM_LEAK_PATTERNS=0
    MM_FILES_SCANNED=0

    while IFS= read -r -d '' file; do
        MM_FILES_SCANNED=$((MM_FILES_SCANNED + 1))
        local rel="${file#${project_dir}/}"

        # useEffectでクリーンアップなし（イベントリスナー/タイマー）
        local line_num=0
        local in_effect=false
        local effect_start=0
        local has_cleanup=false

        while IFS= read -r line; do
            line_num=$((line_num + 1))

            if [[ "$line" == *"useEffect"* ]]; then
                in_effect=true
                effect_start=$line_num
                has_cleanup=false
            fi

            if [[ "$in_effect" == "true" ]]; then
                if [[ "$line" == *"addEventListener"* ]] || [[ "$line" == *"setInterval"* ]] || \
                   [[ "$line" == *"setTimeout"* ]] || [[ "$line" == *"subscribe"* ]]; then
                    # クリーンアップの存在確認
                    local effect_block
                    effect_block=$(sed -n "${effect_start},$((effect_start + 30))p" "$file" 2>/dev/null)
                    if [[ "$effect_block" != *"return"* ]] || \
                       [[ "$effect_block" != *"removeEventListener"* && "$effect_block" != *"clearInterval"* && \
                          "$effect_block" != *"clearTimeout"* && "$effect_block" != *"unsubscribe"* ]]; then
                        MM_LEAK_PATTERNS=$((MM_LEAK_PATTERNS + 1))
                        _MM_FINDINGS+=("EFFECT_LEAK:${rel}:${effect_start}:useEffect without cleanup")
                        _mm_log warn "useEffectリーク: ${rel}:${effect_start}"
                    fi
                fi

                # Effect終了検出（簡易）
                if [[ "$line" == *"}, ["* ]] || [[ "$line" == *"});"* ]]; then
                    in_effect=false
                fi
            fi
        done < "$file"

        # グローバル変数への蓄積
        local global_push
        global_push=$(grep -n "\.push(\|\.set(" "$file" 2>/dev/null | grep -v "router\|state\|local" | wc -l || echo 0)
        if [[ $global_push -gt 10 ]]; then
            MM_LEAK_PATTERNS=$((MM_LEAK_PATTERNS + 1))
            _MM_FINDINGS+=("ACCUMULATION:${rel}:excessive push/set operations (${global_push})")
        fi

        # クロージャによる参照保持
        local closures_with_large
        closures_with_large=$(grep -c "() =>" "$file" 2>/dev/null || echo 0)
        if [[ $closures_with_large -gt 20 ]]; then
            _MM_FINDINGS+=("CLOSURE_RISK:${rel}:${closures_with_large} closures - potential reference holding")
        fi

        # AbortController未使用のfetch
        local fetch_count
        fetch_count=$(grep -c "fetch(" "$file" 2>/dev/null || echo 0)
        local abort_count
        abort_count=$(grep -c "AbortController\|signal" "$file" 2>/dev/null || echo 0)
        if [[ $fetch_count -gt 2 ]] && [[ $abort_count -eq 0 ]]; then
            MM_LEAK_PATTERNS=$((MM_LEAK_PATTERNS + 1))
            _MM_FINDINGS+=("NO_ABORT:${rel}:fetch without AbortController")
        fi
    done < <(find "$project_dir" \( -name "*.tsx" -o -name "*.jsx" -o -name "*.ts" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" -print0 2>/dev/null)

    MM_GENERATED=$((MM_GENERATED + 1))
    _mm_log ok "リーク検出: ${MM_LEAK_PATTERNS}件 (${MM_FILES_SCANNED}ファイル)"
    return 0
}

# =============================================================================
# _mm_optimize_gc - GC最適化設定
# =============================================================================
_mm_optimize_gc() {
    local project_dir="${1:-.}"
    _mm_log info "GC最適化設定分析"

    MM_GC_OPTIMIZATIONS=0

    # Node.js GCフラグ推奨
    local node_options=""
    if [[ -f "${project_dir}/package.json" ]]; then
        local has_node_opts
        has_node_opts=$(grep -c "NODE_OPTIONS" "${project_dir}/package.json" 2>/dev/null || echo 0)

        # max-old-space-size推奨
        node_options="--max-old-space-size=4096"
        MM_GC_OPTIMIZATIONS=$((MM_GC_OPTIMIZATIONS + 1))

        # expose-gc（開発時のみ）
        _MM_FINDINGS+=("GC_CONFIG:NODE_OPTIONS='${node_options}' recommended for production")
        _mm_log ok "GC設定推奨: ${node_options}"
    fi

    # WeakRef/WeakMapの使用確認
    local weakref_count=0
    while IFS= read -r -d '' file; do
        local count
        count=$(grep -c "WeakRef\|WeakMap\|WeakSet" "$file" 2>/dev/null || echo 0)
        weakref_count=$((weakref_count + count))
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.js" \) \
             -not -path "*/node_modules/*" -print0 2>/dev/null)

    if [[ $weakref_count -eq 0 ]] && [[ $MM_LEAK_PATTERNS -gt 0 ]]; then
        _MM_FINDINGS+=("WEAK_REF:consider WeakRef/WeakMap for cache patterns")
        MM_GC_OPTIMIZATIONS=$((MM_GC_OPTIMIZATIONS + 1))
    fi

    MM_GENERATED=$((MM_GENERATED + 1))
    _mm_log ok "GC最適化: ${MM_GC_OPTIMIZATIONS}件推奨"
    return 0
}

# =============================================================================
# _mm_set_limits - メモリ制限設定
# =============================================================================
_mm_set_limits() {
    local project_dir="${1:-.}"
    local memory_limit_mb="${2:-2048}"

    _mm_log info "メモリ制限設定: ${memory_limit_mb}MB"

    MM_LIMITS_SET=0

    # Dockerfile チェック
    if [[ -f "${project_dir}/Dockerfile" ]]; then
        local has_mem_limit
        has_mem_limit=$(grep -c "max-old-space-size\|--memory" "${project_dir}/Dockerfile" 2>/dev/null || echo 0)
        if [[ $has_mem_limit -eq 0 ]]; then
            _MM_FINDINGS+=("DOCKER_MEM:Dockerfile should set NODE_OPTIONS max-old-space-size")
            MM_LIMITS_SET=$((MM_LIMITS_SET + 1))
        fi
    fi

    # docker-compose チェック
    if [[ -f "${project_dir}/docker-compose.yml" ]] || [[ -f "${project_dir}/docker-compose.yaml" ]]; then
        local compose_file="${project_dir}/docker-compose.yml"
        [[ ! -f "$compose_file" ]] && compose_file="${project_dir}/docker-compose.yaml"

        local has_deploy_limit
        has_deploy_limit=$(grep -c "mem_limit\|memory:" "$compose_file" 2>/dev/null || echo 0)
        if [[ $has_deploy_limit -eq 0 ]]; then
            _MM_FINDINGS+=("COMPOSE_MEM:docker-compose should set memory limits")
            MM_LIMITS_SET=$((MM_LIMITS_SET + 1))
        fi
    fi

    # Vercel/Cloudflare Workers制限
    if [[ -f "${project_dir}/vercel.json" ]]; then
        _MM_FINDINGS+=("VERCEL_MEM:Vercel serverless functions have 1024MB limit")
        MM_LIMITS_SET=$((MM_LIMITS_SET + 1))
    fi

    MM_GENERATED=$((MM_GENERATED + 1))
    _mm_log ok "メモリ制限設定: ${MM_LIMITS_SET}件推奨"
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_mm_report() {
    echo -e "\n  ${_MM_BOLD}=== memory-management v${MM_VERSION} ===${_MM_NC}"
    echo -e "  走査ファイル    : ${MM_FILES_SCANNED}"
    echo -e "  リークパターン  : ${MM_LEAK_PATTERNS}"
    echo -e "  GC最適化        : ${MM_GC_OPTIMIZATIONS}"
    echo -e "  制限設定        : ${MM_LIMITS_SET}"
    echo -e "  エラー          : ${MM_ERRORS}"
}

_mm_score() {
    local score=50
    [[ ${MM_FILES_SCANNED} -gt 0 ]] && score=$((score + 10))
    [[ ${MM_LEAK_PATTERNS} -eq 0 ]] && score=$((score + 20))
    [[ ${MM_GC_OPTIMIZATIONS} -gt 0 ]] && score=$((score + 10))
    [[ ${MM_ERRORS} -eq 0 ]] && score=$((score + 10))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "memory-management" --version "${MM_VERSION}" \
        --description "メモリ管理×リーク検出×GC最適化×制限設定 (v436)" \
        --init "_mm_init" --report "_mm_report" --score "_mm_score" \
        --enable-var "ENABLE_MEMORY_MGMT" --cli-flags "--memory-mgmt:--no-memory-mgmt"
fi

# v2003.1: source時のexit codeを確実に0にする
true
