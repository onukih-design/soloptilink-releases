#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v390.0 - KPI/OKR Tracker
# =============================================================================
# KPI/OKR目標管理エンジン。目標設定/ダッシュボード/進捗追跡を自動生成。
# All globals use the KOT_ prefix.
# =============================================================================

[[ -n "${_KPI_OKR_TRACKER_LOADED:-}" ]] && return 0
_KPI_OKR_TRACKER_LOADED=1

declare -g KOT_VERSION="390.0"
declare -g KOT_INITIALIZED=false
declare -g KOT_GENERATED_COUNT=0
declare -g KOT_GOAL_GENERATED=false
declare -g KOT_DASHBOARD_GENERATED=false
declare -g KOT_PROGRESS_GENERATED=false
declare -g KOT_CHECKIN_GENERATED=false
declare -g ENABLE_KOT="${ENABLE_KOT:-true}"

_kot_init() { KOT_INITIALIZED=true; KOT_GENERATED_COUNT=0; return 0; }

_kot_generate_all() {
    local project_dir="${1:-.}"
    [[ "$KOT_INITIALIZED" != "true" ]] && _kot_init
    echo -e "  ${CYAN:-\033[0;36m}[KOT]${NC:-\033[0m} KPI/OKRトラッカー生成開始..." >&2
    _kot_generate_goal_model "$project_dir"
    _kot_generate_dashboard "$project_dir"
    _kot_track_progress "$project_dir"
    _kot_generate_checkin "$project_dir"
    echo -e "  ${GREEN:-\033[0;32m}[KOT]${NC:-\033[0m} KPI/OKR生成完了: ${KOT_GENERATED_COUNT}件" >&2
    return 0
}

_kot_generate_goal_model() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [KOT-GOAL] 目標管理モデル

### Schema
```prisma
model Objective {
  id          String   @id @default(cuid())
  title       String
  description String?
  ownerId     String
  period      String
  periodStart DateTime
  periodEnd   DateTime
  status      String   @default("active")
  progress    Float    @default(0)
  parentId    String?
  parent      Objective? @relation("ObjectiveTree", fields: [parentId], references: [id])
  children    Objective[] @relation("ObjectiveTree")
  keyResults  KeyResult[]
  checkIns    OKRCheckIn[]
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  @@index([ownerId, period])
}

model KeyResult {
  id          String    @id @default(cuid())
  objectiveId String
  objective   Objective @relation(fields: [objectiveId], references: [id], onDelete: Cascade)
  title       String
  metricType  String    @default("percentage")
  startValue  Float     @default(0)
  targetValue Float
  currentValue Float    @default(0)
  unit        String?
  status      String    @default("on_track")
  updates     KRUpdate[]
  @@index([objectiveId])
}

model KRUpdate {
  id          String    @id @default(cuid())
  keyResultId String
  keyResult   KeyResult @relation(fields: [keyResultId], references: [id])
  value       Float
  note        String?
  updatedBy   String
  createdAt   DateTime  @default(now())
}

model OKRCheckIn {
  id          String    @id @default(cuid())
  objectiveId String
  objective   Objective @relation(fields: [objectiveId], references: [id])
  userId      String
  confidence  Int
  notes       String
  blockers    String?
  createdAt   DateTime  @default(now())
}
```

### OKR Service
```typescript
export class OKRService {
  async updateKeyResult(krId: string, value: number, userId: string, note?: string) {
    const kr = await prisma.keyResult.findUniqueOrThrow({ where: { id: krId } });
    await prisma.kRUpdate.create({ data: { keyResultId: krId, value, note, updatedBy: userId } });
    await prisma.keyResult.update({ where: { id: krId }, data: { currentValue: value,
      status: this.calculateStatus(value, kr.targetValue, kr.startValue) } });
    await this.recalculateObjectiveProgress(kr.objectiveId);
  }

  private calculateStatus(current: number, target: number, start: number): string {
    const progress = (current - start) / (target - start);
    if (progress >= 0.7) return 'on_track';
    if (progress >= 0.3) return 'at_risk';
    return 'off_track';
  }

  async recalculateObjectiveProgress(objectiveId: string) {
    const krs = await prisma.keyResult.findMany({ where: { objectiveId } });
    const progress = krs.length > 0
      ? krs.reduce((sum, kr) => sum + ((kr.currentValue - kr.startValue) / (kr.targetValue - kr.startValue)), 0) / krs.length * 100
      : 0;
    await prisma.objective.update({ where: { id: objectiveId }, data: { progress: Math.min(100, Math.max(0, progress)) } });
  }
}
```
TEMPLATE
    KOT_GOAL_GENERATED=true
    KOT_GENERATED_COUNT=$((KOT_GENERATED_COUNT + 1))
    return 0
}

_kot_generate_dashboard() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [KOT-DASHBOARD] OKRダッシュボード

```tsx
'use client';
export function OKRDashboard({ period }: { period: string }) {
  const { data, isLoading } = useSWR(`/api/okrs?period=${period}`);
  if (isLoading) return <DashboardSkeleton />;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-3 gap-4">
        <StatCard title="目標数" value={data?.totalObjectives ?? 0} />
        <StatCard title="平均進捗" value={`${Math.round(data?.averageProgress ?? 0)}%`} />
        <StatCard title="リスクあり" value={data?.atRiskCount ?? 0} color="warning" />
      </div>
      {data?.objectives?.map((obj: Objective) => (
        <div key={obj.id} className="border rounded-lg p-4">
          <div className="flex items-center justify-between mb-2">
            <h3 className="font-bold">{obj.title}</h3>
            <Badge variant={obj.progress >= 70 ? 'default' : obj.progress >= 30 ? 'secondary' : 'destructive'}>
              {Math.round(obj.progress)}%
            </Badge>
          </div>
          <Progress value={obj.progress} className="mb-3" />
          {obj.keyResults.map((kr: KeyResult) => (
            <div key={kr.id} className="ml-4 py-1 flex items-center gap-2">
              <span className={cn("w-2 h-2 rounded-full", kr.status === 'on_track' ? 'bg-green-500' : kr.status === 'at_risk' ? 'bg-yellow-500' : 'bg-red-500')} />
              <span className="flex-1">{kr.title}</span>
              <span className="text-sm text-muted-foreground">{kr.currentValue}/{kr.targetValue} {kr.unit}</span>
            </div>
          ))}
        </div>
      ))}
    </div>
  );
}
```
TEMPLATE
    KOT_DASHBOARD_GENERATED=true
    KOT_GENERATED_COUNT=$((KOT_GENERATED_COUNT + 1))
    return 0
}

_kot_track_progress() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [KOT-PROGRESS] 進捗追跡テンプレート

```typescript
export async function getProgressReport(period: string) {
  const objectives = await prisma.objective.findMany({
    where: { period }, include: { keyResults: true, owner: { select: { name: true } } },
  });
  const byTeam = objectives.reduce((acc, obj) => {
    const team = obj.owner.team ?? 'unassigned';
    if (!acc[team]) acc[team] = { objectives: 0, avgProgress: 0, totalProgress: 0 };
    acc[team].objectives++;
    acc[team].totalProgress += obj.progress;
    acc[team].avgProgress = acc[team].totalProgress / acc[team].objectives;
    return acc;
  }, {} as Record<string, any>);

  return { period, totalObjectives: objectives.length,
    averageProgress: objectives.reduce((s, o) => s + o.progress, 0) / objectives.length,
    atRiskCount: objectives.filter(o => o.progress < 30).length,
    byTeam, objectives };
}
```
TEMPLATE
    KOT_PROGRESS_GENERATED=true
    KOT_GENERATED_COUNT=$((KOT_GENERATED_COUNT + 1))
    return 0
}

_kot_generate_checkin() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [KOT-CHECKIN] チェックインテンプレート

```tsx
'use client';
export function CheckInForm({ objectiveId }: { objectiveId: string }) {
  const { register, handleSubmit, formState: { isSubmitting } } = useForm();
  const onSubmit = async (data: any) => {
    await fetch(`/api/okrs/${objectiveId}/checkins`, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(data),
    });
    toast.success('チェックインを記録しました');
  };
  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
      <div>
        <label>自信度 (1-10)</label>
        <Input type="number" min={1} max={10} {...register('confidence', { valueAsNumber: true })} />
      </div>
      <Textarea label="進捗メモ" {...register('notes')} />
      <Textarea label="ブロッカー" {...register('blockers')} />
      <Button type="submit" disabled={isSubmitting}>{isSubmitting ? '送信中...' : 'チェックイン'}</Button>
    </form>
  );
}
```
TEMPLATE
    KOT_CHECKIN_GENERATED=true
    KOT_GENERATED_COUNT=$((KOT_GENERATED_COUNT + 1))
    return 0
}

_kot_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== KPI/OKR Tracker v${KOT_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成数             : ${KOT_GENERATED_COUNT}"
    echo -e "  目標モデル         : ${KOT_GOAL_GENERATED}"
    echo -e "  ダッシュボード     : ${KOT_DASHBOARD_GENERATED}"
    echo -e "  進捗追跡           : ${KOT_PROGRESS_GENERATED}"
    echo -e "  チェックイン       : ${KOT_CHECKIN_GENERATED}"
}

_kot_score() {
    local score=30
    [[ "$KOT_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$KOT_GOAL_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$KOT_DASHBOARD_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$KOT_PROGRESS_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$KOT_CHECKIN_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "kpi-okr-tracker" \
    --version "390.0" \
    --description "KPI/OKRトラッカー（目標/ダッシュボード/進捗/チェックイン）" \
    --init "_kot_init" \
    --report "_kot_report" \
    --score "_kot_score" \
    --enable-var "ENABLE_KOT" \
    --cli-flags "--kpi-okr:--no-kpi-okr"
