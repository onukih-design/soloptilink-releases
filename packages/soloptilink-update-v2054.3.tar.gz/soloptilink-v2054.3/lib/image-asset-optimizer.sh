#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v434.0 - Image Asset Optimizer
# =============================================================================
# 画像アセットの分析・最適化。未最適化画像の検出、圧縮推奨、
# WebP/AVIF変換提案、next/image最適化設定を行う。
#
# Functions:
#   _iao_init()              - 初期化
#   _iao_find_unoptimized()  - 未最適化画像検出
#   _iao_compress_images()   - 圧縮推奨生成
#   _iao_generate_webp()     - WebP変換設定生成
#   _iao_report() / _iao_score()
#
# All globals use the IAO_ prefix.
# =============================================================================

[[ -n "${_IAO_LOADED:-}" ]] && return 0; _IAO_LOADED=1

declare -g IAO_VERSION="434.0"
declare -g IAO_GENERATED=0
declare -g IAO_ERRORS=0
declare -g IAO_IMAGES_FOUND=0
declare -g IAO_UNOPTIMIZED=0
declare -g IAO_TOTAL_SIZE_KB=0
declare -g IAO_POTENTIAL_SAVINGS_KB=0
declare -g IAO_MISSING_NEXT_IMAGE=0

declare -ga _IAO_FINDINGS=()
declare -gA _IAO_IMAGE_SIZES=()

_IAO_GREEN="${GREEN:-\033[0;32m}"
_IAO_RED="${RED:-\033[0;31m}"
_IAO_YELLOW="${YELLOW:-\033[0;33m}"
_IAO_CYAN="${CYAN:-\033[0;36m}"
_IAO_BOLD="${BOLD:-\033[1m}"
_IAO_NC="${NC:-\033[0m}"

_iao_init() {
    IAO_GENERATED=0; IAO_ERRORS=0; IAO_IMAGES_FOUND=0
    IAO_UNOPTIMIZED=0; IAO_TOTAL_SIZE_KB=0
    IAO_POTENTIAL_SAVINGS_KB=0; IAO_MISSING_NEXT_IMAGE=0
    _IAO_FINDINGS=(); _IAO_IMAGE_SIZES=()
    return 0
}

_iao_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_IAO_CYAN}[IAO]${_IAO_NC} $*" >&2 ;;
        ok)    echo -e "  ${_IAO_GREEN}[IAO]${_IAO_NC} $*" >&2 ;;
        warn)  echo -e "  ${_IAO_YELLOW}[IAO]${_IAO_NC} $*" >&2 ;;
        error) echo -e "  ${_IAO_RED}[IAO]${_IAO_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _iao_find_unoptimized - 未最適化画像検出
# =============================================================================
_iao_find_unoptimized() {
    local project_dir="${1:-.}"
    local size_threshold_kb="${2:-200}"

    _iao_log info "未最適化画像検出 (閾値: ${size_threshold_kb}KB)"

    IAO_IMAGES_FOUND=0
    IAO_UNOPTIMIZED=0
    IAO_TOTAL_SIZE_KB=0

    while IFS= read -r -d '' file; do
        IAO_IMAGES_FOUND=$((IAO_IMAGES_FOUND + 1))
        local rel="${file#${project_dir}/}"
        local size_kb
        size_kb=$(du -k "$file" 2>/dev/null | cut -f1 || echo 0)
        IAO_TOTAL_SIZE_KB=$((IAO_TOTAL_SIZE_KB + size_kb))
        _IAO_IMAGE_SIZES["$rel"]="$size_kb"

        # 大きな画像
        if [[ $size_kb -gt $size_threshold_kb ]]; then
            IAO_UNOPTIMIZED=$((IAO_UNOPTIMIZED + 1))
            IAO_POTENTIAL_SAVINGS_KB=$((IAO_POTENTIAL_SAVINGS_KB + size_kb / 2))
            _IAO_FINDINGS+=("LARGE_IMAGE:${rel}:${size_kb}KB")
            _iao_log warn "大きな画像: ${rel} (${size_kb}KB)"
        fi

        # BMP形式（非効率）
        if [[ "$file" == *.bmp ]]; then
            IAO_UNOPTIMIZED=$((IAO_UNOPTIMIZED + 1))
            _IAO_FINDINGS+=("BMP_FORMAT:${rel}:BMP should be PNG/WebP")
            _iao_log warn "非効率フォーマット: ${rel} (BMP→WebP推奨)"
        fi

        # 非常に大きなPNG（写真には不向き）
        if [[ "$file" == *.png ]] && [[ $size_kb -gt 500 ]]; then
            _IAO_FINDINGS+=("LARGE_PNG:${rel}:${size_kb}KB - consider JPEG/WebP for photos")
            _iao_log warn "大きなPNG: ${rel} (写真ならJPEG/WebP推奨)"
        fi
    done < <(find "$project_dir" \( -name "*.png" -o -name "*.jpg" -o -name "*.jpeg" \
             -o -name "*.gif" -o -name "*.bmp" -o -name "*.svg" -o -name "*.webp" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" \
             -not -path "*/.git/*" -print0 2>/dev/null)

    # SVGの最適化チェック
    while IFS= read -r -d '' svg; do
        local svg_size
        svg_size=$(wc -c < "$svg" 2>/dev/null || echo 0)
        if [[ $svg_size -gt 10000 ]]; then
            local rel="${svg#${project_dir}/}"
            _IAO_FINDINGS+=("LARGE_SVG:${rel}:${svg_size}bytes - consider SVGO optimization")
        fi
    done < <(find "$project_dir" -name "*.svg" -not -path "*/node_modules/*" -print0 2>/dev/null)

    IAO_GENERATED=$((IAO_GENERATED + 1))
    local mb=$((IAO_TOTAL_SIZE_KB / 1024))
    _iao_log ok "画像検出: ${IAO_IMAGES_FOUND}個, 合計${mb}MB, 未最適化${IAO_UNOPTIMIZED}個"
    return 0
}

# =============================================================================
# _iao_compress_images - 圧縮推奨生成
# =============================================================================
_iao_compress_images() {
    local project_dir="${1:-.}"
    _iao_log info "画像圧縮推奨生成"

    local recommendations=0

    # next/imageの使用チェック
    IAO_MISSING_NEXT_IMAGE=0
    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"
        local html_img
        html_img=$(grep -c '<img ' "$file" 2>/dev/null || echo 0)
        local next_img
        next_img=$(grep -c '<Image\|from.*next/image' "$file" 2>/dev/null || echo 0)

        if [[ $html_img -gt 0 ]] && [[ $next_img -eq 0 ]]; then
            IAO_MISSING_NEXT_IMAGE=$((IAO_MISSING_NEXT_IMAGE + html_img))
            _IAO_FINDINGS+=("HTML_IMG:${rel}:${html_img}x <img> tags - use next/image")
            _iao_log warn "<img>タグ検出: ${rel} → next/Image推奨"
        fi
    done < <(find "$project_dir" \( -name "*.tsx" -o -name "*.jsx" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" -print0 2>/dev/null)

    # package.jsonでsharp依存チェック
    if [[ -f "${project_dir}/package.json" ]]; then
        local has_sharp
        has_sharp=$(grep -c '"sharp"' "${project_dir}/package.json" 2>/dev/null || echo 0)
        if [[ $has_sharp -eq 0 ]]; then
            _IAO_FINDINGS+=("NO_SHARP:package.json:add sharp for Next.js image optimization")
            recommendations=$((recommendations + 1))
        fi
    fi

    IAO_GENERATED=$((IAO_GENERATED + 1))
    _iao_log ok "圧縮推奨: <img>→Image ${IAO_MISSING_NEXT_IMAGE}箇所"
    return 0
}

# =============================================================================
# _iao_generate_webp - WebP変換設定生成
# =============================================================================
_iao_generate_webp() {
    local project_dir="${1:-.}"
    _iao_log info "WebP/AVIF設定生成"

    local config_content=""

    # Next.js画像最適化設定
    if [[ -f "${project_dir}/next.config.js" ]] || [[ -f "${project_dir}/next.config.mjs" ]]; then
        config_content=$(cat <<'NEXTIMG'
// next.config.js - Image Optimization
module.exports = {
  images: {
    formats: ['image/avif', 'image/webp'],
    deviceSizes: [640, 750, 828, 1080, 1200, 1920, 2048, 3840],
    imageSizes: [16, 32, 48, 64, 96, 128, 256, 384],
    minimumCacheTTL: 60 * 60 * 24 * 30, // 30 days
    dangerouslyAllowSVG: false,
    remotePatterns: [
      // Add your image domains here
    ],
  },
};
NEXTIMG
)
        _iao_log ok "Next.js画像最適化設定推奨を生成"
    fi

    # 画像変換スクリプト推奨
    if [[ $IAO_UNOPTIMIZED -gt 0 ]]; then
        echo "# WebP変換推奨コマンド:"
        echo "# npx sharp-cli --input './public/**/*.{png,jpg}' --output './public/optimized' --format webp --quality 80"
        echo "# または: npx @squoosh/cli --webp '{quality:80}' ./public/**/*.png"
    fi

    IAO_GENERATED=$((IAO_GENERATED + 1))
    _iao_log ok "WebP設定生成完了"

    [[ -n "$config_content" ]] && echo "$config_content"
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_iao_report() {
    local total_mb=$((IAO_TOTAL_SIZE_KB / 1024))
    local savings_mb=$((IAO_POTENTIAL_SAVINGS_KB / 1024))
    echo -e "\n  ${_IAO_BOLD}=== image-asset-optimizer v${IAO_VERSION} ===${_IAO_NC}"
    echo -e "  画像総数        : ${IAO_IMAGES_FOUND}"
    echo -e "  合計サイズ      : ${total_mb}MB"
    echo -e "  未最適化        : ${IAO_UNOPTIMIZED}"
    echo -e "  削減可能        : ${savings_mb}MB"
    echo -e "  <img>→Image     : ${IAO_MISSING_NEXT_IMAGE}箇所"
    echo -e "  エラー          : ${IAO_ERRORS}"
}

_iao_score() {
    local score=50
    [[ ${IAO_IMAGES_FOUND} -gt 0 ]] && score=$((score + 10))
    [[ ${IAO_UNOPTIMIZED} -eq 0 ]] && score=$((score + 15))
    [[ ${IAO_MISSING_NEXT_IMAGE} -eq 0 ]] && score=$((score + 15))
    [[ ${IAO_ERRORS} -eq 0 ]] && score=$((score + 10))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "image-asset-optimizer" --version "${IAO_VERSION}" \
        --description "画像アセット最適化×未最適化検出×WebP/AVIF推奨 (v434)" \
        --init "_iao_init" --report "_iao_report" --score "_iao_score" \
        --enable-var "ENABLE_IMAGE_OPT" --cli-flags "--image-opt:--no-image-opt"
fi

# v2003.1: source時のexit codeを確実に0にする
true
