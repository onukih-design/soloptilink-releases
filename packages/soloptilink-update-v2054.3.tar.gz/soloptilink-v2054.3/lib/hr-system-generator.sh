#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v308.0 - HR System Generator
# =============================================================================
# 人事システム自動生成: 従業員モデル/勤怠管理/休暇管理/人事評価
#
# 全globals: HSG_ prefix
# =============================================================================

[[ -n "${_HR_SYSTEM_GENERATOR_LOADED:-}" ]] && return 0
_HR_SYSTEM_GENERATOR_LOADED=1

declare -g HSG_VERSION="308.0"
declare -g HSG_INITIALIZED=false
declare -g HSG_GENERATED_COUNT=0
declare -g ENABLE_HR_SYSTEM_GENERATOR="${ENABLE_HR_SYSTEM_GENERATOR:-true}"

readonly HSG_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly HSG_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly HSG_BOLD="${CLR_BOLD:-\033[1m}"
readonly HSG_NC="${CLR_NC:-\033[0m}"

_hsg_log() { echo -e "  ${HSG_CYAN}[HSG]${HSG_NC} $*" >&2; }
_hsg_ok()  { echo -e "  ${HSG_GREEN}[HSG] OK${HSG_NC} $*" >&2; }

hsg_init() { HSG_INITIALIZED=true; HSG_GENERATED_COUNT=0; return 0; }
hsg_report() { [[ "$HSG_INITIALIZED" != "true" ]] && return 0; echo -e "\n  ${HSG_BOLD}--- HR System Generator v${HSG_VERSION} ---${HSG_NC}" >&2; echo -e "  生成数: ${HSG_GENERATED_COUNT}" >&2; }
hsg_score() { [[ "$HSG_INITIALIZED" != "true" ]] && { echo "0"; return; }; local s=50; [[ $HSG_GENERATED_COUNT -ge 3 ]] && s=85; echo "$s"; }
hsg_init_message() { echo -e "  ${HSG_GREEN}v${HSG_VERSION} hr-system-generator: 人事システム自動生成${HSG_NC}" >&2; }

# =============================================================================
# _hsg_generate_employee_model() - Employee data model
# =============================================================================
_hsg_generate_employee_model() {
    local project_dir="${1:-.}"
    _hsg_log "従業員モデル生成"

    local snippet='
// --- HR System Models (v308.0) ---
model Employee {
  id           String   @id @default(cuid())
  employeeNo   String   @unique
  firstName    String
  lastName     String
  email        String   @unique
  phone        String?
  department   String?
  position     String?
  hireDate     DateTime
  status       EmployeeStatus @default(ACTIVE)
  managerId    String?
  salary       Int?
  attendances  Attendance[]
  leaveRequests LeaveRequest[]
  reviews      PerformanceReview[]
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt
}

enum EmployeeStatus { ACTIVE ON_LEAVE RESIGNED TERMINATED }

model Attendance {
  id         String   @id @default(cuid())
  employeeId String
  employee   Employee @relation(fields: [employeeId], references: [id], onDelete: Cascade)
  date       DateTime @db.Date
  clockIn    DateTime?
  clockOut   DateTime?
  breakMinutes Int    @default(60)
  workHours  Float?
  status     AttendanceStatus @default(PRESENT)
  note       String?
  @@unique([employeeId, date])
}

enum AttendanceStatus { PRESENT ABSENT LATE HALF_DAY REMOTE }

model LeaveRequest {
  id         String   @id @default(cuid())
  employeeId String
  employee   Employee @relation(fields: [employeeId], references: [id], onDelete: Cascade)
  type       LeaveType
  startDate  DateTime @db.Date
  endDate    DateTime @db.Date
  days       Float
  reason     String?
  status     LeaveApprovalStatus @default(PENDING)
  approverId String?
  createdAt  DateTime @default(now())
}

enum LeaveType { PAID SICK PERSONAL MATERNITY PATERNITY OTHER }
enum LeaveApprovalStatus { PENDING APPROVED REJECTED CANCELLED }

model PerformanceReview {
  id         String   @id @default(cuid())
  employeeId String
  employee   Employee @relation(fields: [employeeId], references: [id], onDelete: Cascade)
  reviewerId String
  period     String
  rating     Int
  strengths  String?  @db.Text
  improvements String? @db.Text
  goals      String?  @db.Text
  comments   String?  @db.Text
  status     ReviewStatus @default(DRAFT)
  createdAt  DateTime @default(now())
}

enum ReviewStatus { DRAFT SUBMITTED ACKNOWLEDGED }'

    local schema_file="${project_dir}/prisma/schema.prisma"
    mkdir -p "${project_dir}/prisma"
    if [[ -f "$schema_file" ]] && ! grep -q "model Employee" "$schema_file" 2>/dev/null; then
        echo "$snippet" >> "$schema_file"
    fi

    HSG_GENERATED_COUNT=$((HSG_GENERATED_COUNT + 1))
    _hsg_ok "従業員モデル生成完了"
    return 0
}

# =============================================================================
# _hsg_generate_attendance() - Attendance tracking (clock in/out)
# =============================================================================
_hsg_generate_attendance() {
    local project_dir="${1:-.}"
    _hsg_log "勤怠管理生成"

    local comp_dir="${project_dir}/src/components/hr"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/AttendanceClock.tsx" <<'EOF'
'use client';
import { useState, useEffect } from 'react';
import { Clock, LogIn, LogOut } from 'lucide-react';

export function AttendanceClock({ employeeId }: { employeeId: string }) {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [clockedIn, setClockedIn] = useState(false);
  const [clockInTime, setClockInTime] = useState<Date | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);
    // Check today's status
    fetch(`/api/hr/attendance?employeeId=${employeeId}&date=${new Date().toISOString().split('T')[0]}`)
      .then(r => r.json()).then(d => {
        if (d.data?.clockIn && !d.data?.clockOut) { setClockedIn(true); setClockInTime(new Date(d.data.clockIn)); }
      }).catch(() => {});
    return () => clearInterval(timer);
  }, [employeeId]);

  const handleClock = async (action: 'in' | 'out') => {
    setLoading(true);
    try {
      const res = await fetch('/api/hr/attendance/clock', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ employeeId, action }),
      });
      if (res.ok) {
        if (action === 'in') { setClockedIn(true); setClockInTime(new Date()); }
        else { setClockedIn(false); }
      }
    } catch { /* silent */ } finally { setLoading(false); }
  };

  const elapsed = clockInTime ? Math.floor((currentTime.getTime() - clockInTime.getTime()) / 60000) : 0;
  const hours = Math.floor(elapsed / 60);
  const mins = elapsed % 60;

  return (
    <div className="bg-white rounded-xl shadow p-6 text-center">
      <div className="text-4xl font-mono font-bold mb-2">
        {currentTime.toLocaleTimeString('ja-JP')}
      </div>
      <p className="text-gray-500 mb-6">{currentTime.toLocaleDateString('ja-JP', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</p>

      {clockedIn ? (
        <div>
          <p className="text-sm text-gray-500 mb-2">勤務中 - {hours}時間{mins}分</p>
          <button onClick={() => handleClock('out')} disabled={loading}
            className="bg-red-600 text-white px-8 py-3 rounded-lg font-medium flex items-center gap-2 mx-auto hover:bg-red-700 disabled:opacity-50">
            <LogOut size={20} /> {loading ? '処理中...' : '退勤'}
          </button>
        </div>
      ) : (
        <button onClick={() => handleClock('in')} disabled={loading}
          className="bg-green-600 text-white px-8 py-3 rounded-lg font-medium flex items-center gap-2 mx-auto hover:bg-green-700 disabled:opacity-50">
          <LogIn size={20} /> {loading ? '処理中...' : '出勤'}
        </button>
      )}
    </div>
  );
}
EOF

    local api_dir="${project_dir}/src/app/api/hr/attendance"
    mkdir -p "${api_dir}/clock"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const employeeId = req.nextUrl.searchParams.get('employeeId');
    const date = req.nextUrl.searchParams.get('date');
    if (!employeeId) return NextResponse.json({ error: 'employeeId required' }, { status: 400 });
    const where: any = { employeeId };
    if (date) where.date = new Date(date);
    const data = await prisma.attendance.findFirst({ where, orderBy: { date: 'desc' } });
    return NextResponse.json({ data });
  } catch (error) {
    return NextResponse.json({ error: 'Failed' }, { status: 500 });
  }
}
EOF

    cat > "${api_dir}/clock/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest) {
  try {
    const { employeeId, action } = await req.json();
    if (!employeeId || !action) return NextResponse.json({ error: 'employeeId and action required' }, { status: 400 });

    const today = new Date(); today.setHours(0, 0, 0, 0);
    const now = new Date();

    if (action === 'in') {
      const attendance = await prisma.attendance.upsert({
        where: { employeeId_date: { employeeId, date: today } },
        update: { clockIn: now },
        create: { employeeId, date: today, clockIn: now, status: 'PRESENT' },
      });
      return NextResponse.json(attendance);
    } else {
      const attendance = await prisma.attendance.update({
        where: { employeeId_date: { employeeId, date: today } },
        data: { clockOut: now, workHours: { set: undefined } },
      });
      // Calculate work hours
      if (attendance.clockIn) {
        const hours = (now.getTime() - attendance.clockIn.getTime()) / (1000 * 60 * 60) - (attendance.breakMinutes / 60);
        await prisma.attendance.update({ where: { id: attendance.id }, data: { workHours: Math.round(hours * 100) / 100 } });
      }
      return NextResponse.json(attendance);
    }
  } catch (error) {
    return NextResponse.json({ error: 'Clock action failed' }, { status: 500 });
  }
}
EOF

    HSG_GENERATED_COUNT=$((HSG_GENERATED_COUNT + 3))
    _hsg_ok "勤怠管理生成完了"
    return 0
}

# =============================================================================
# _hsg_generate_leave_management() - Leave/vacation management
# =============================================================================
_hsg_generate_leave_management() {
    local project_dir="${1:-.}"
    _hsg_log "休暇管理生成"

    local api_dir="${project_dir}/src/app/api/hr/leave"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const employeeId = req.nextUrl.searchParams.get('employeeId');
    const status = req.nextUrl.searchParams.get('status');
    const where: any = {};
    if (employeeId) where.employeeId = employeeId;
    if (status) where.status = status;
    const requests = await prisma.leaveRequest.findMany({
      where, include: { employee: { select: { firstName: true, lastName: true, department: true } } },
      orderBy: { createdAt: 'desc' }, take: 100,
    });
    return NextResponse.json({ data: requests });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch leave requests' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { employeeId, type, startDate, endDate, reason } = await req.json();
    if (!employeeId || !type || !startDate || !endDate) return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });
    const start = new Date(startDate);
    const end = new Date(endDate);
    const days = Math.ceil((end.getTime() - start.getTime()) / (1000 * 60 * 60 * 24)) + 1;
    const request = await prisma.leaveRequest.create({ data: { employeeId, type, startDate: start, endDate: end, days, reason } });
    return NextResponse.json(request, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create leave request' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const { id, status, approverId } = await req.json();
    if (!id || !status) return NextResponse.json({ error: 'id and status required' }, { status: 400 });
    const updated = await prisma.leaveRequest.update({ where: { id }, data: { status, approverId } });
    return NextResponse.json(updated);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update leave request' }, { status: 500 });
  }
}
EOF

    HSG_GENERATED_COUNT=$((HSG_GENERATED_COUNT + 1))
    _hsg_ok "休暇管理生成完了"
    return 0
}

# =============================================================================
# _hsg_generate_performance_review() - Performance review system
# =============================================================================
_hsg_generate_performance_review() {
    local project_dir="${1:-.}"
    _hsg_log "人事評価生成"

    local comp_dir="${project_dir}/src/components/hr"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/PerformanceReviewForm.tsx" <<'EOF'
'use client';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Star } from 'lucide-react';

interface ReviewFormProps { employeeId: string; reviewerId: string; period: string; }

export function PerformanceReviewForm({ employeeId, reviewerId, period }: ReviewFormProps) {
  const router = useRouter();
  const [rating, setRating] = useState(3);
  const [form, setForm] = useState({ strengths: '', improvements: '', goals: '', comments: '' });
  const [submitting, setSubmitting] = useState(false);

  const handleSubmit = async (status: 'DRAFT' | 'SUBMITTED') => {
    setSubmitting(true);
    try {
      const res = await fetch('/api/hr/reviews', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ employeeId, reviewerId, period, rating, ...form, status }),
      });
      if (res.ok) router.push('/hr/reviews');
      else alert('保存に失敗しました');
    } catch { alert('エラーが発生しました'); } finally { setSubmitting(false); }
  };

  return (
    <div className="max-w-2xl bg-white rounded-lg shadow p-6 space-y-6">
      <h2 className="text-lg font-bold">人事評価 - {period}</h2>

      <div>
        <label className="block text-sm font-medium mb-2">総合評価</label>
        <div className="flex gap-2">
          {[1, 2, 3, 4, 5].map(n => (
            <button key={n} onClick={() => setRating(n)} className="p-1">
              <Star size={28} className={n <= rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'} />
            </button>
          ))}
          <span className="ml-2 text-gray-500 self-center">{rating}/5</span>
        </div>
      </div>

      {[
        { key: 'strengths', label: '強み・良い点' },
        { key: 'improvements', label: '改善点' },
        { key: 'goals', label: '次期目標' },
        { key: 'comments', label: 'コメント' },
      ].map(f => (
        <div key={f.key}>
          <label className="block text-sm font-medium mb-1">{f.label}</label>
          <textarea value={(form as any)[f.key]} onChange={e => setForm({ ...form, [f.key]: e.target.value })}
            rows={3} className="w-full border rounded-lg px-3 py-2 text-sm" />
        </div>
      ))}

      <div className="flex gap-3">
        <button onClick={() => handleSubmit('DRAFT')} disabled={submitting} className="px-6 py-2 border rounded-lg hover:bg-gray-50 disabled:opacity-50">下書き保存</button>
        <button onClick={() => handleSubmit('SUBMITTED')} disabled={submitting} className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50">
          {submitting ? '送信中...' : '提出'}
        </button>
      </div>
    </div>
  );
}
EOF

    HSG_GENERATED_COUNT=$((HSG_GENERATED_COUNT + 1))
    _hsg_ok "人事評価生成完了"
    return 0
}

# =============================================================================
# Module Registration
# =============================================================================
_mr_register \
    --name "hr-system-generator" \
    --version "308.0" \
    --description "人事システム自動生成（従業員/勤怠/休暇/人事評価）" \
    --init "hsg_init" \
    --report "hsg_report" \
    --score "hsg_score" \
    --enable-var "ENABLE_HR_SYSTEM_GENERATOR" \
    --cli-flags "--hr-system:--no-hr-system" \
    --init-msg "hsg_init_message"
