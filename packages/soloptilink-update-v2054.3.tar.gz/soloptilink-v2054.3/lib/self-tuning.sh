#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v49.0 - Self-Tuning Engine
# =============================================================================
# 全パラメータ（品質閾値/コスト予算/リトライ回数/タイムアウト/エージェント数等）
# を過去のセッション実績から自動チューニングするエンジン。
#
# v49.0の核心: 「前回CRMでは品質閾値80で3回修復ループした→85に上げて
# 初回で通るようにする」「ECでは予算$3.50で十分→$4に設定」等、
# 過去の実績データから最適パラメータを自動導出する。
#
# Functions:
#   st_init              - Self-Tuning初期化
#   st_load_history      - 過去チューニングデータ読み込み
#   st_tune_quality      - 品質閾値チューニング
#   st_tune_budget       - 予算チューニング
#   st_tune_retries      - リトライ回数チューニング
#   st_tune_timeout      - タイムアウトチューニング
#   st_tune_agents       - エージェント数チューニング
#   st_get_tuned_config  - チューニング済み設定取得
#   st_get_stats         - 統計情報を返す
#   st_save              - チューニングデータ永続化
#
# All globals use the ST_ prefix.
# =============================================================================

[[ -n "${_SELF_TUNING_LOADED:-}" ]] && return 0
_SELF_TUNING_LOADED=1

declare -g ST_VERSION="49.0"
declare -g ST_ENABLED="${ST_ENABLED:-true}"

# チューニング結果
declare -g ST_QUALITY_THRESHOLD=80
declare -g ST_BUDGET_LIMIT="10.00"
declare -g ST_MAX_RETRIES=3
declare -g ST_TIMEOUT=300
declare -g ST_AGENT_COUNT=30
declare -g ST_TUNING_ROUNDS=0
declare -g ST_DATA_POINTS=0
declare -g ST_TUNING_FILE=""
declare -g ST_HISTORY_FILE=""

# デフォルト値（リセット用）
declare -g -r ST_DEFAULT_QUALITY=80
declare -g -r ST_DEFAULT_BUDGET="10.00"
declare -g -r ST_DEFAULT_RETRIES=3
declare -g -r ST_DEFAULT_TIMEOUT=300
declare -g -r ST_DEFAULT_AGENTS=30

# =============================================================================
# st_init - Self-Tuning初期化
# =============================================================================
st_init() {
    local domain="${1:-general}"

    ST_QUALITY_THRESHOLD=$ST_DEFAULT_QUALITY
    ST_BUDGET_LIMIT="$ST_DEFAULT_BUDGET"
    ST_MAX_RETRIES=$ST_DEFAULT_RETRIES
    ST_TIMEOUT=$ST_DEFAULT_TIMEOUT
    ST_AGENT_COUNT=$ST_DEFAULT_AGENTS
    ST_TUNING_ROUNDS=0
    ST_DATA_POINTS=0

    local knowledge_dir="${HOME}/.soloptilink/knowledge"
    mkdir -p "$knowledge_dir" 2>/dev/null || true
    ST_TUNING_FILE="${knowledge_dir}/self_tuning_config.json"
    ST_HISTORY_FILE="${knowledge_dir}/self_tuning_history.jsonl"

    # 過去データがあれば読み込み
    st_load_history "$domain"

    return 0
}

# =============================================================================
# st_load_history - 過去チューニングデータ読み込み
# =============================================================================
st_load_history() {
    local domain="${1:-general}"

    if [[ -f "$ST_TUNING_FILE" ]]; then
        # JSON解析（bashで簡易的に）
        local quality budget retries timeout agents
        quality=$(grep -o '"quality_threshold":[0-9]*' "$ST_TUNING_FILE" 2>/dev/null | head -1 | cut -d: -f2)
        budget=$(grep -o '"budget_limit":"[^"]*"' "$ST_TUNING_FILE" 2>/dev/null | head -1 | cut -d'"' -f4)
        retries=$(grep -o '"max_retries":[0-9]*' "$ST_TUNING_FILE" 2>/dev/null | head -1 | cut -d: -f2)
        timeout=$(grep -o '"timeout":[0-9]*' "$ST_TUNING_FILE" 2>/dev/null | head -1 | cut -d: -f2)
        agents=$(grep -o '"agent_count":[0-9]*' "$ST_TUNING_FILE" 2>/dev/null | head -1 | cut -d: -f2)

        [[ -n "$quality" && "$quality" =~ ^[0-9]+$ ]] && ST_QUALITY_THRESHOLD=$quality
        [[ -n "$budget" ]] && ST_BUDGET_LIMIT="$budget"
        [[ -n "$retries" && "$retries" =~ ^[0-9]+$ ]] && ST_MAX_RETRIES=$retries
        [[ -n "$timeout" && "$timeout" =~ ^[0-9]+$ ]] && ST_TIMEOUT=$timeout
        [[ -n "$agents" && "$agents" =~ ^[0-9]+$ ]] && ST_AGENT_COUNT=$agents
    fi

    # 履歴からデータポイント数を取得
    if [[ -f "$ST_HISTORY_FILE" ]]; then
        ST_DATA_POINTS=$(wc -l < "$ST_HISTORY_FILE" 2>/dev/null | tr -d ' ')
        [[ -z "$ST_DATA_POINTS" ]] && ST_DATA_POINTS=0
    fi

    return 0
}

# =============================================================================
# st_tune_quality - 品質閾値チューニング
# =============================================================================
st_tune_quality() {
    local recent_score="${1:-80}"
    local heal_loops="${2:-0}"

    recent_score=$(echo "$recent_score" | tr -d '[:space:]')
    heal_loops=$(echo "$heal_loops" | tr -d '[:space:]')
    [[ -z "$recent_score" || ! "$recent_score" =~ ^[0-9]+$ ]] && recent_score=80
    [[ -z "$heal_loops" || ! "$heal_loops" =~ ^[0-9]+$ ]] && heal_loops=0

    # 修復ループが多い → 閾値を少し上げて初回通過を促す
    if [[ $heal_loops -gt 2 ]]; then
        ST_QUALITY_THRESHOLD=$((ST_QUALITY_THRESHOLD + 5))
        [[ $ST_QUALITY_THRESHOLD -gt 95 ]] && ST_QUALITY_THRESHOLD=95
    elif [[ $heal_loops -eq 0 && $recent_score -gt 90 ]]; then
        # 余裕で通過 → 閾値据え置き（下げない）
        :
    fi

    ST_TUNING_ROUNDS=$((ST_TUNING_ROUNDS + 1))
    echo "$ST_QUALITY_THRESHOLD"
}

# =============================================================================
# st_tune_budget - 予算チューニング
# =============================================================================
st_tune_budget() {
    local actual_cost="${1:-0}"

    # 簡易的な文字列→数値変換（bash整数演算用にセント換算）
    local cost_cents
    cost_cents=$(echo "$actual_cost" | awk '{printf "%d", $1 * 100}' 2>/dev/null || echo "0")
    [[ -z "$cost_cents" ]] && cost_cents=0

    local budget_cents
    budget_cents=$(echo "$ST_BUDGET_LIMIT" | awk '{printf "%d", $1 * 100}' 2>/dev/null || echo "1000")
    [[ -z "$budget_cents" ]] && budget_cents=1000

    # 実コストが予算の80%以上→予算を20%増加
    local threshold_80=$((budget_cents * 80 / 100))
    if [[ $cost_cents -gt $threshold_80 ]]; then
        budget_cents=$((budget_cents * 120 / 100))
        [[ $budget_cents -gt 2000 ]] && budget_cents=2000  # 上限$20
    # 実コストが予算の30%以下→予算を少し縮小
    elif [[ $cost_cents -lt $((budget_cents * 30 / 100)) && $cost_cents -gt 0 ]]; then
        budget_cents=$((budget_cents * 80 / 100))
        [[ $budget_cents -lt 200 ]] && budget_cents=200  # 下限$2
    fi

    ST_BUDGET_LIMIT=$(awk "BEGIN{printf \"%.2f\", ${budget_cents}/100}" 2>/dev/null || echo "10.00")
    ST_TUNING_ROUNDS=$((ST_TUNING_ROUNDS + 1))
    echo "$ST_BUDGET_LIMIT"
}

# =============================================================================
# st_tune_retries - リトライ回数チューニング
# =============================================================================
st_tune_retries() {
    local retry_success_rate="${1:-100}"

    retry_success_rate=$(echo "$retry_success_rate" | tr -d '[:space:]')
    [[ -z "$retry_success_rate" || ! "$retry_success_rate" =~ ^[0-9]+$ ]] && retry_success_rate=100

    # リトライ成功率が低い → リトライ回数増加
    if [[ $retry_success_rate -lt 50 ]]; then
        ST_MAX_RETRIES=$((ST_MAX_RETRIES + 1))
        [[ $ST_MAX_RETRIES -gt 10 ]] && ST_MAX_RETRIES=10
    elif [[ $retry_success_rate -gt 90 && $ST_MAX_RETRIES -gt 2 ]]; then
        ST_MAX_RETRIES=$((ST_MAX_RETRIES - 1))
    fi

    ST_TUNING_ROUNDS=$((ST_TUNING_ROUNDS + 1))
    echo "$ST_MAX_RETRIES"
}

# =============================================================================
# st_tune_timeout - タイムアウトチューニング
# =============================================================================
st_tune_timeout() {
    local timeout_count="${1:-0}"
    local total_calls="${2:-1}"

    timeout_count=$(echo "$timeout_count" | tr -d '[:space:]')
    total_calls=$(echo "$total_calls" | tr -d '[:space:]')
    [[ -z "$timeout_count" || ! "$timeout_count" =~ ^[0-9]+$ ]] && timeout_count=0
    [[ -z "$total_calls" || ! "$total_calls" =~ ^[0-9]+$ || "$total_calls" -eq 0 ]] && total_calls=1

    local timeout_rate=$((timeout_count * 100 / total_calls))

    # タイムアウト率が高い → タイムアウトを延長
    if [[ $timeout_rate -gt 20 ]]; then
        ST_TIMEOUT=$((ST_TIMEOUT + 60))
        [[ $ST_TIMEOUT -gt 600 ]] && ST_TIMEOUT=600
    elif [[ $timeout_rate -eq 0 && $ST_TIMEOUT -gt 120 ]]; then
        ST_TIMEOUT=$((ST_TIMEOUT - 30))
    fi

    ST_TUNING_ROUNDS=$((ST_TUNING_ROUNDS + 1))
    echo "$ST_TIMEOUT"
}

# =============================================================================
# st_tune_agents - エージェント数チューニング
# =============================================================================
st_tune_agents() {
    local health_score="${1:-100}"

    health_score=$(echo "$health_score" | tr -d '[:space:]')
    [[ -z "$health_score" || ! "$health_score" =~ ^[0-9]+$ ]] && health_score=100

    # ヘルススコアが低い → エージェント数を削減
    if [[ $health_score -lt 40 ]]; then
        ST_AGENT_COUNT=$((ST_AGENT_COUNT - 5))
        [[ $ST_AGENT_COUNT -lt 10 ]] && ST_AGENT_COUNT=10
    elif [[ $health_score -gt 80 && $ST_AGENT_COUNT -lt 30 ]]; then
        ST_AGENT_COUNT=$((ST_AGENT_COUNT + 5))
        [[ $ST_AGENT_COUNT -gt 30 ]] && ST_AGENT_COUNT=30
    fi

    ST_TUNING_ROUNDS=$((ST_TUNING_ROUNDS + 1))
    echo "$ST_AGENT_COUNT"
}

# =============================================================================
# st_get_tuned_config - チューニング済み設定取得
# =============================================================================
st_get_tuned_config() {
    echo "quality_threshold=${ST_QUALITY_THRESHOLD};budget=${ST_BUDGET_LIMIT};retries=${ST_MAX_RETRIES};timeout=${ST_TIMEOUT};agents=${ST_AGENT_COUNT}"
}

# =============================================================================
# st_get_stats - 統計情報をJSON形式で返す
# =============================================================================
st_get_stats() {
    cat <<EOF
{
  "version": "${ST_VERSION}",
  "quality_threshold": ${ST_QUALITY_THRESHOLD},
  "budget_limit": "${ST_BUDGET_LIMIT}",
  "max_retries": ${ST_MAX_RETRIES},
  "timeout": ${ST_TIMEOUT},
  "agent_count": ${ST_AGENT_COUNT},
  "tuning_rounds": ${ST_TUNING_ROUNDS},
  "data_points": ${ST_DATA_POINTS}
}
EOF
}

# =============================================================================
# st_save - チューニングデータ永続化
# =============================================================================
st_save() {
    [[ -z "$ST_TUNING_FILE" ]] && return 0

    local timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date +"%Y-%m-%d")

    cat > "$ST_TUNING_FILE" 2>/dev/null <<EOF
{
  "timestamp": "${timestamp}",
  "version": "${ST_VERSION}",
  "quality_threshold": ${ST_QUALITY_THRESHOLD},
  "budget_limit": "${ST_BUDGET_LIMIT}",
  "max_retries": ${ST_MAX_RETRIES},
  "timeout": ${ST_TIMEOUT},
  "agent_count": ${ST_AGENT_COUNT},
  "tuning_rounds": ${ST_TUNING_ROUNDS}
}
EOF

    # 履歴にも追記
    if [[ -n "$ST_HISTORY_FILE" ]]; then
        echo "{\"timestamp\":\"${timestamp}\",\"quality\":${ST_QUALITY_THRESHOLD},\"budget\":\"${ST_BUDGET_LIMIT}\",\"retries\":${ST_MAX_RETRIES},\"timeout\":${ST_TIMEOUT},\"agents\":${ST_AGENT_COUNT}}" >> "$ST_HISTORY_FILE" 2>/dev/null || true
    fi

    return 0
}
