#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v289.0 - Service Discovery
# =============================================================================
# サービスディスカバリ自動生成。サービスレジストリ、ディスカバリクライアント、
# フェイルオーバーロジックを生成する。
#
# 機能一覧:
#   _svd_generate_registry   - サービスレジストリ生成
#   _svd_generate_discovery  - ディスカバリクライアント生成
#   _svd_generate_failover   - フェイルオーバーロジック
#
# 全globals: SVD_ prefix
# =============================================================================

[[ -n "${_SVD_LOADED:-}" ]] && return 0; _SVD_LOADED=1

declare -g SVD_VERSION="289.0"
declare -g SVD_GENERATED=0
declare -g SVD_ERRORS=0
declare -g SVD_FILES_WRITTEN=0

svd_init() { SVD_GENERATED=0; SVD_ERRORS=0; SVD_FILES_WRITTEN=0; return 0; }

_svd_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then SVD_FILES_WRITTEN=$((SVD_FILES_WRITTEN + 1)); echo "  [svd] wrote: $filepath" >&2
    else SVD_ERRORS=$((SVD_ERRORS + 1)); fi
}

_svd_log() { echo -e "  ${GREEN:-\033[0;32m}[SVD]${NC:-\033[0m} $*" >&2; }

# =============================================================================
# _svd_generate_registry
# =============================================================================
_svd_generate_registry() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _svd_log "Generating service registry..."

    local reg_ts
    reg_ts=$(cat <<'REGEOF'
// =============================================================================
// Service Registry - Central registry for service instances
// Supports registration, heartbeat, and deregistration
// =============================================================================

export interface ServiceInstance {
  id: string;
  serviceName: string;
  host: string;
  port: number;
  version: string;
  metadata: Record<string, string>;
  status: 'UP' | 'DOWN' | 'STARTING' | 'OUT_OF_SERVICE';
  registeredAt: string;
  lastHeartbeat: string;
  healthCheckUrl: string;
}

export interface ServiceRegistry {
  register(instance: Omit<ServiceInstance, 'id' | 'registeredAt' | 'lastHeartbeat' | 'status'>): string;
  deregister(instanceId: string): boolean;
  heartbeat(instanceId: string): boolean;
  getInstances(serviceName: string): ServiceInstance[];
  getAllServices(): string[];
  getHealthyInstances(serviceName: string): ServiceInstance[];
}

export class InMemoryServiceRegistry implements ServiceRegistry {
  private instances: Map<string, ServiceInstance> = new Map();
  private readonly heartbeatTimeout: number;
  private cleanupTimer: NodeJS.Timeout | null = null;

  constructor(heartbeatTimeoutMs = 30000) {
    this.heartbeatTimeout = heartbeatTimeoutMs;
    this.cleanupTimer = setInterval(() => this.cleanupStale(), 10000);
  }

  register(input: Omit<ServiceInstance, 'id' | 'registeredAt' | 'lastHeartbeat' | 'status'>): string {
    const id = crypto.randomUUID();
    const now = new Date().toISOString();
    const instance: ServiceInstance = {
      ...input, id, status: 'UP', registeredAt: now, lastHeartbeat: now,
    };
    this.instances.set(id, instance);
    console.log(`[registry] Registered: ${input.serviceName} at ${input.host}:${input.port} (${id})`);
    return id;
  }

  deregister(instanceId: string): boolean {
    const inst = this.instances.get(instanceId);
    if (!inst) return false;
    this.instances.delete(instanceId);
    console.log(`[registry] Deregistered: ${inst.serviceName} (${instanceId})`);
    return true;
  }

  heartbeat(instanceId: string): boolean {
    const inst = this.instances.get(instanceId);
    if (!inst) return false;
    inst.lastHeartbeat = new Date().toISOString();
    inst.status = 'UP';
    return true;
  }

  getInstances(serviceName: string): ServiceInstance[] {
    return Array.from(this.instances.values()).filter((i) => i.serviceName === serviceName);
  }

  getHealthyInstances(serviceName: string): ServiceInstance[] {
    return this.getInstances(serviceName).filter((i) => i.status === 'UP');
  }

  getAllServices(): string[] {
    return [...new Set(Array.from(this.instances.values()).map((i) => i.serviceName))];
  }

  private cleanupStale(): void {
    const now = Date.now();
    for (const [id, inst] of this.instances) {
      const lastBeat = new Date(inst.lastHeartbeat).getTime();
      if (now - lastBeat > this.heartbeatTimeout) {
        inst.status = 'DOWN';
        console.warn(`[registry] Instance ${inst.serviceName} (${id}) marked DOWN (stale heartbeat)`);
      }
    }
  }

  destroy(): void {
    if (this.cleanupTimer) clearInterval(this.cleanupTimer);
  }
}

// Singleton
let _registry: ServiceRegistry | null = null;
export function getRegistry(): ServiceRegistry {
  if (!_registry) _registry = new InMemoryServiceRegistry();
  return _registry;
}
REGEOF
)
    _svd_write_file "${project_dir}/src/lib/discovery/registry.ts" "$reg_ts"
    SVD_GENERATED=$((SVD_GENERATED + 1))
    return 0
}

# =============================================================================
# _svd_generate_discovery
# =============================================================================
_svd_generate_discovery() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _svd_log "Generating discovery client..."

    local disc_ts
    disc_ts=$(cat <<'DISCEOF'
// =============================================================================
// Service Discovery Client
// Used by services to discover other service instances
// =============================================================================
import { ServiceInstance } from './registry';

export interface DiscoveryClient {
  discover(serviceName: string): Promise<ServiceInstance[]>;
  discoverOne(serviceName: string): Promise<ServiceInstance>;
  getUrl(serviceName: string): Promise<string>;
  refresh(): Promise<void>;
}

export class HttpDiscoveryClient implements DiscoveryClient {
  private cache: Map<string, { instances: ServiceInstance[]; fetchedAt: number }> = new Map();
  private readonly cacheTtlMs: number;

  constructor(
    private registryUrl: string = process.env.REGISTRY_URL || 'http://localhost:3000/api/registry',
    cacheTtlMs = 10000
  ) {
    this.cacheTtlMs = cacheTtlMs;
  }

  async discover(serviceName: string): Promise<ServiceInstance[]> {
    const cached = this.cache.get(serviceName);
    if (cached && Date.now() - cached.fetchedAt < this.cacheTtlMs) {
      return cached.instances;
    }

    try {
      const resp = await fetch(`${this.registryUrl}/services/${serviceName}`);
      if (!resp.ok) throw new Error(`Registry returned ${resp.status}`);
      const data = await resp.json() as { instances: ServiceInstance[] };
      this.cache.set(serviceName, { instances: data.instances, fetchedAt: Date.now() });
      return data.instances;
    } catch (err) {
      // Return stale cache on error
      if (cached) return cached.instances;
      throw err;
    }
  }

  async discoverOne(serviceName: string): Promise<ServiceInstance> {
    const instances = await this.discover(serviceName);
    const healthy = instances.filter((i) => i.status === 'UP');
    if (healthy.length === 0) throw new Error(`No healthy instances for: ${serviceName}`);
    // Simple random selection
    return healthy[Math.floor(Math.random() * healthy.length)];
  }

  async getUrl(serviceName: string): Promise<string> {
    const instance = await this.discoverOne(serviceName);
    return `http://${instance.host}:${instance.port}`;
  }

  async refresh(): Promise<void> {
    this.cache.clear();
  }
}

// --- Environment-based fallback ---
export class EnvDiscoveryClient implements DiscoveryClient {
  private urlMap: Record<string, string>;

  constructor() {
    this.urlMap = {
      identity: process.env.IDENTITY_SERVICE_URL || 'http://localhost:3001',
      catalog: process.env.CATALOG_SERVICE_URL || 'http://localhost:3002',
      orders: process.env.ORDER_SERVICE_URL || 'http://localhost:3003',
      billing: process.env.BILLING_SERVICE_URL || 'http://localhost:3004',
      notifications: process.env.NOTIFICATION_SERVICE_URL || 'http://localhost:3005',
    };
  }

  async discover(serviceName: string): Promise<ServiceInstance[]> {
    const url = this.urlMap[serviceName];
    if (!url) return [];
    const parsed = new URL(url);
    return [{
      id: serviceName, serviceName, host: parsed.hostname,
      port: parseInt(parsed.port || '80'), version: '1.0.0',
      metadata: {}, status: 'UP',
      registeredAt: new Date().toISOString(),
      lastHeartbeat: new Date().toISOString(),
      healthCheckUrl: `${url}/health`,
    }];
  }

  async discoverOne(serviceName: string): Promise<ServiceInstance> {
    const instances = await this.discover(serviceName);
    if (instances.length === 0) throw new Error(`No instance for: ${serviceName}`);
    return instances[0];
  }

  async getUrl(serviceName: string): Promise<string> {
    return this.urlMap[serviceName] || '';
  }

  async refresh(): Promise<void> { /* no-op */ }
}

export function createDiscoveryClient(): DiscoveryClient {
  const mode = process.env.DISCOVERY_MODE || 'env';
  return mode === 'registry' ? new HttpDiscoveryClient() : new EnvDiscoveryClient();
}
DISCEOF
)
    _svd_write_file "${project_dir}/src/lib/discovery/client.ts" "$disc_ts"
    SVD_GENERATED=$((SVD_GENERATED + 1))
    return 0
}

# =============================================================================
# _svd_generate_failover
# =============================================================================
_svd_generate_failover() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _svd_log "Generating failover logic..."

    local failover_ts
    failover_ts=$(cat <<'FOEOF'
// =============================================================================
// Service Failover - Automatic failover when instances are unavailable
// =============================================================================
import { DiscoveryClient } from './client';

export interface FailoverOptions {
  maxAttempts: number;
  timeoutMs: number;
  onFailover?: (instance: string, error: Error) => void;
}

export async function callWithFailover<T>(
  discovery: DiscoveryClient,
  serviceName: string,
  requestFn: (baseUrl: string) => Promise<T>,
  options: Partial<FailoverOptions> = {}
): Promise<T> {
  const opts: FailoverOptions = { maxAttempts: 3, timeoutMs: 5000, ...options };
  const instances = await discovery.discover(serviceName);
  const healthy = instances.filter((i) => i.status === 'UP');

  if (healthy.length === 0) {
    throw new Error(`No healthy instances for service: ${serviceName}`);
  }

  const tried: Set<string> = new Set();
  let lastError: Error | undefined;

  for (let attempt = 0; attempt < Math.min(opts.maxAttempts, healthy.length); attempt++) {
    // Pick an untried instance
    const available = healthy.filter((i) => !tried.has(i.id));
    if (available.length === 0) break;

    const instance = available[Math.floor(Math.random() * available.length)];
    tried.add(instance.id);
    const baseUrl = `http://${instance.host}:${instance.port}`;

    try {
      const result = await Promise.race([
        requestFn(baseUrl),
        new Promise<never>((_, reject) =>
          setTimeout(() => reject(new Error(`Timeout: ${opts.timeoutMs}ms`)), opts.timeoutMs)
        ),
      ]);
      return result;
    } catch (err: any) {
      lastError = err;
      opts.onFailover?.(instance.id, err);
      console.warn(`[failover] ${serviceName} instance ${instance.id} failed: ${err.message}`);
    }
  }

  throw lastError || new Error(`All instances failed for: ${serviceName}`);
}
FOEOF
)
    _svd_write_file "${project_dir}/src/lib/discovery/failover.ts" "$failover_ts"
    SVD_GENERATED=$((SVD_GENERATED + 1))
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
svd_report() {
    echo -e "\n  ${BOLD:-}=== service-discovery v${SVD_VERSION} ===${NC:-}"
    echo -e "  生成数: ${SVD_GENERATED}"; echo -e "  エラー: ${SVD_ERRORS}"
}

svd_score() {
    if [[ ${SVD_GENERATED} -ge 3 ]] && [[ ${SVD_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${SVD_GENERATED} -gt 0 ]] && [[ ${SVD_ERRORS} -eq 0 ]]; then echo "85"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "service-discovery" --version "${SVD_VERSION}" \
        --description "サービスレジストリ×ディスカバリクライアント×フェイルオーバー" \
        --init "svd_init" --report "svd_report" --score "svd_score" \
        --enable-var "ENABLE_SERVICE_DISCOVERY" --cli-flags "--service-discovery:--no-service-discovery"
fi

# v2003.1: source時のexit codeを確実に0にする
true
