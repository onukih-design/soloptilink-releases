#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2015.0 - Output Maximizer Engine
# =============================================================================
# 生成物の品質スコアリング・検証・自動強化モジュール
# 全出力をディスク書き込み前にスコアリング・バリデーション・エンハンス
#
# 機能:
#   - 6軸品質スコアリング (Completeness/Correctness/Style/Security/Performance/Accessibility)
#   - プロジェクト全体スコアリング + ディレクトリ別集計
#   - 品質ギャップ検出 (未実装・不整合・欠落バリデーション)
#   - 自動エンハンス指示生成
#   - クロスファイル整合性検証
#   - ASCII品質ダッシュボード
#   - バージョン間品質比較
#   - Claude向けエンハンスプロンプト生成
#   - スコア永続化 + トレンド分析
#
# 全globals: OM_ prefix
# 関数prefix: om_
# =============================================================================

[[ -n "${_OM_LOADED:-}" ]] && return 0; _OM_LOADED=1

# =============================================================================
# Dependencies
# =============================================================================
_om_script_dir="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Source common utilities if available
[[ -f "${_om_script_dir}/lib/common/colors.sh" ]]    && source "${_om_script_dir}/lib/common/colors.sh" 2>/dev/null
[[ -f "${_om_script_dir}/lib/common/logger.sh" ]]     && source "${_om_script_dir}/lib/common/logger.sh" 2>/dev/null
[[ -f "${_om_script_dir}/lib/common/json-utils.sh" ]] && source "${_om_script_dir}/lib/common/json-utils.sh" 2>/dev/null

# Internal logging wrapper (delegates to unified logger if available)
_om_log() {
    local level="$1" msg="$2"
    if declare -f log &>/dev/null; then
        log "$level" "$msg"
    else
        local ts
        ts="$(date '+%H:%M:%S')"
        case "$level" in
            INFO)  echo -e "  ${CLR_CYAN:-\033[0;36m}[OM:INFO ${ts}]${CLR_NC:-\033[0m} $msg" ;;
            WARN)  echo -e "  ${CLR_YELLOW:-\033[0;33m}[OM:WARN ${ts}]${CLR_NC:-\033[0m} $msg" >&2 ;;
            ERROR) echo -e "  ${CLR_RED:-\033[0;31m}[OM:ERROR ${ts}]${CLR_NC:-\033[0m} $msg" >&2 ;;
            PASS)  echo -e "  ${CLR_GREEN:-\033[0;32m}[OM:PASS ${ts}]${CLR_NC:-\033[0m} $msg" ;;
            *)     echo -e "  [OM:${level} ${ts}] $msg" ;;
        esac
    fi
}

# Convenience wrappers
log_info()  { _om_log INFO  "$1"; }
log_warn()  { _om_log WARN  "$1"; }
log_error() { _om_log ERROR "$1"; }

# JSON helpers - wrap json-utils or use fallback
_om_json_get() {
    if declare -f json_get &>/dev/null; then
        json_get "$1" "$2"
    else
        echo "$1" | python3 -c "
import json,sys
try:
    d=json.loads(sys.stdin.read())
    keys='$2'.split('.')
    v=d
    for k in keys:
        v=v[k] if isinstance(v,dict) else v[int(k)] if isinstance(v,list) and k.isdigit() else None
        if v is None: break
    if v is not None: print(v if isinstance(v,str) else json.dumps(v,ensure_ascii=False))
except: pass" 2>/dev/null
    fi
}

_om_json_set() {
    local json_str="$1" key="$2" value="$3"
    if command -v python3 &>/dev/null; then
        python3 -c "
import json,sys
try:
    d=json.loads(sys.argv[1])
    d[sys.argv[2]]=json.loads(sys.argv[3]) if sys.argv[3] in ('true','false','null') or sys.argv[3][0] in ('{','[','-') or sys.argv[3].isdigit() else sys.argv[3]
except: d={sys.argv[2]:sys.argv[3]}
print(json.dumps(d,ensure_ascii=False))
" "$json_str" "$key" "$value" 2>/dev/null
    else
        echo "$json_str"
    fi
}

# =============================================================================
# Constants & State
# =============================================================================
OM_VERSION="2015.0"
OM_MODULE_NAME="OutputMaximizer"

# Quality axis names
OM_AXES=("completeness" "correctness" "style" "security" "performance" "accessibility")

# Thresholds per output type (minimum passing score)
declare -A OM_THRESHOLDS_CODE=()
declare -A OM_THRESHOLDS_CONFIG=()
declare -A OM_THRESHOLDS_DOCS=()
declare -A OM_THRESHOLDS_TESTS=()

# Scoring weights per axis (out of 100 total)
declare -A OM_WEIGHTS=()

# Runtime statistics
OM_TOTAL_FILES_SCORED=0
OM_TOTAL_ISSUES_FOUND=0
OM_TOTAL_ENHANCEMENTS=0
OM_AVG_SCORE=0
OM_INITIALIZED=false

# =============================================================================
# 1. om_init() - Initialize the Output Maximizer Engine
# =============================================================================
om_init() {
    if [[ "$OM_INITIALIZED" == "true" ]]; then
        log_info "Output Maximizer already initialized"
        return 0
    fi

    log_info "Initializing Output Maximizer Engine v${OM_VERSION}"

    # --- Quality thresholds per output type ---
    # code: strictest on correctness/security
    OM_THRESHOLDS_CODE[completeness]=70
    OM_THRESHOLDS_CODE[correctness]=80
    OM_THRESHOLDS_CODE[style]=60
    OM_THRESHOLDS_CODE[security]=75
    OM_THRESHOLDS_CODE[performance]=65
    OM_THRESHOLDS_CODE[accessibility]=50

    # config: strict on correctness, relaxed elsewhere
    OM_THRESHOLDS_CONFIG[completeness]=80
    OM_THRESHOLDS_CONFIG[correctness]=90
    OM_THRESHOLDS_CONFIG[style]=50
    OM_THRESHOLDS_CONFIG[security]=85
    OM_THRESHOLDS_CONFIG[performance]=40
    OM_THRESHOLDS_CONFIG[accessibility]=20

    # docs: strict on completeness/style
    OM_THRESHOLDS_DOCS[completeness]=85
    OM_THRESHOLDS_DOCS[correctness]=60
    OM_THRESHOLDS_DOCS[style]=75
    OM_THRESHOLDS_DOCS[security]=40
    OM_THRESHOLDS_DOCS[performance]=20
    OM_THRESHOLDS_DOCS[accessibility]=60

    # tests: strict on completeness/correctness
    OM_THRESHOLDS_TESTS[completeness]=85
    OM_THRESHOLDS_TESTS[correctness]=85
    OM_THRESHOLDS_TESTS[style]=55
    OM_THRESHOLDS_TESTS[security]=60
    OM_THRESHOLDS_TESTS[performance]=50
    OM_THRESHOLDS_TESTS[accessibility]=30

    # --- Scoring weights (must sum to 100) ---
    OM_WEIGHTS[completeness]=25
    OM_WEIGHTS[correctness]=25
    OM_WEIGHTS[style]=15
    OM_WEIGHTS[security]=15
    OM_WEIGHTS[performance]=10
    OM_WEIGHTS[accessibility]=10

    # --- Reset statistics ---
    OM_TOTAL_FILES_SCORED=0
    OM_TOTAL_ISSUES_FOUND=0
    OM_TOTAL_ENHANCEMENTS=0
    OM_AVG_SCORE=0

    # --- Ensure persistence directories ---
    local quality_dir="${SCRIPT_DIR:-${_om_script_dir}}/learning/quality"
    mkdir -p "$quality_dir" 2>/dev/null

    OM_INITIALIZED=true
    _om_log PASS "Output Maximizer v${OM_VERSION} ready (6 axes, 4 output types)"
    return 0
}

# =============================================================================
# 2. om_score_output(file_path, file_type, domain) - Score a single file
# =============================================================================
om_score_output() {
    local file_path="$1"
    local file_type="${2:-code}"    # code|config|docs|tests
    local domain="${3:-general}"

    if [[ ! -f "$file_path" ]]; then
        log_error "File not found: ${file_path}"
        echo '{"error":"file_not_found","total":0}'
        return 1
    fi

    local content
    content="$(cat "$file_path" 2>/dev/null)"
    local line_count
    line_count="$(wc -l < "$file_path" | tr -d ' ')"
    local ext="${file_path##*.}"

    # --- Completeness (0-100) ---
    local completeness=100
    local completeness_issues=""

    # Check for TODOs, FIXMEs, stubs
    local todo_count
    todo_count=$(grep -ciE '\bTODO\b|\bFIXME\b|\bHACK\b|\bXXX\b' "$file_path" 2>/dev/null || echo 0)
    if [[ "$todo_count" -gt 0 ]]; then
        completeness=$((completeness - todo_count * 8))
        completeness_issues="${completeness_issues}todo_count=${todo_count};"
    fi

    # Check for placeholder/stub patterns
    local stub_count
    stub_count=$(grep -cE 'throw new Error\(.*(not implemented|todo|stub)\)|pass\s*#\s*TODO|\.\.\..*implement|NotImplementedError|placeholder|PLACEHOLDER' "$file_path" 2>/dev/null || echo 0)
    if [[ "$stub_count" -gt 0 ]]; then
        completeness=$((completeness - stub_count * 15))
        completeness_issues="${completeness_issues}stubs=${stub_count};"
    fi

    # Check for empty function bodies (JS/TS)
    local empty_bodies
    empty_bodies=$(grep -cE '(function|=>)\s*\{[\s]*\}' "$file_path" 2>/dev/null || echo 0)
    if [[ "$empty_bodies" -gt 0 ]]; then
        completeness=$((completeness - empty_bodies * 12))
        completeness_issues="${completeness_issues}empty_bodies=${empty_bodies};"
    fi

    # Check for empty catch blocks
    local empty_catch
    empty_catch=$(grep -cE 'catch\s*\([^)]*\)\s*\{[\s]*\}' "$file_path" 2>/dev/null || echo 0)
    if [[ "$empty_catch" -gt 0 ]]; then
        completeness=$((completeness - empty_catch * 10))
        completeness_issues="${completeness_issues}empty_catch=${empty_catch};"
    fi

    # Penalize very short files (likely incomplete)
    if [[ "$line_count" -lt 5 && "$file_type" == "code" ]]; then
        completeness=$((completeness - 30))
        completeness_issues="${completeness_issues}too_short;"
    fi
    [[ "$completeness" -lt 0 ]] && completeness=0

    # --- Correctness (0-100) ---
    local correctness=100
    local correctness_issues=""

    # Check for unused imports (JS/TS) - import X but X never used again
    if [[ "$ext" =~ ^(ts|tsx|js|jsx)$ ]]; then
        local import_names
        import_names=$(grep -oE 'import\s+\{([^}]+)\}' "$file_path" 2>/dev/null | sed 's/import *{//;s/}//;s/,/\n/g' | sed 's/^ *//;s/ *$//' | grep -v '^$')
        local unused_imports=0
        while IFS= read -r imp_name; do
            [[ -z "$imp_name" ]] && continue
            # Strip 'as alias' patterns
            imp_name="${imp_name%% as *}"
            imp_name="$(echo "$imp_name" | tr -d ' ')"
            [[ -z "$imp_name" ]] && continue
            local usage_count
            usage_count=$(grep -c "\b${imp_name}\b" "$file_path" 2>/dev/null || echo 0)
            # The import line itself counts as 1 occurrence
            if [[ "$usage_count" -le 1 ]]; then
                unused_imports=$((unused_imports + 1))
            fi
        done <<< "$import_names"
        if [[ "$unused_imports" -gt 0 ]]; then
            correctness=$((correctness - unused_imports * 5))
            correctness_issues="${correctness_issues}unused_imports=${unused_imports};"
        fi
    fi

    # Check for console.log left in production code (not test files)
    if [[ "$file_type" != "tests" && "$ext" =~ ^(ts|tsx|js|jsx)$ ]]; then
        local console_logs
        console_logs=$(grep -cE 'console\.(log|debug|dir)\(' "$file_path" 2>/dev/null || echo 0)
        if [[ "$console_logs" -gt 0 ]]; then
            correctness=$((correctness - console_logs * 3))
            correctness_issues="${correctness_issues}console_logs=${console_logs};"
        fi
    fi

    # Check for 'any' type usage in TypeScript
    if [[ "$ext" =~ ^(ts|tsx)$ ]]; then
        local any_count
        any_count=$(grep -cE ':\s*any\b|<any>|as any' "$file_path" 2>/dev/null || echo 0)
        if [[ "$any_count" -gt 0 ]]; then
            correctness=$((correctness - any_count * 4))
            correctness_issues="${correctness_issues}any_types=${any_count};"
        fi
    fi

    # Check for syntax red flags: unmatched brackets (rough heuristic)
    local open_braces close_braces
    open_braces=$(grep -o '{' "$file_path" 2>/dev/null | wc -l | tr -d ' ')
    close_braces=$(grep -o '}' "$file_path" 2>/dev/null | wc -l | tr -d ' ')
    local brace_diff=$(( open_braces - close_braces ))
    if [[ "${brace_diff#-}" -gt 2 ]]; then
        correctness=$((correctness - 15))
        correctness_issues="${correctness_issues}brace_mismatch=${brace_diff};"
    fi

    # Check for duplicate function/const declarations
    if [[ "$ext" =~ ^(ts|tsx|js|jsx)$ ]]; then
        local dup_funcs
        dup_funcs=$(grep -oE '(export\s+)?(const|function|class)\s+[A-Za-z_][A-Za-z0-9_]*' "$file_path" 2>/dev/null \
            | sed 's/export *//' | sort | uniq -d | wc -l | tr -d ' ')
        if [[ "$dup_funcs" -gt 0 ]]; then
            correctness=$((correctness - dup_funcs * 10))
            correctness_issues="${correctness_issues}duplicate_decls=${dup_funcs};"
        fi
    fi
    [[ "$correctness" -lt 0 ]] && correctness=0

    # --- Style (0-100) ---
    local style=100
    local style_issues=""

    # Check indentation consistency (tabs vs spaces)
    local tab_lines space_lines
    tab_lines=$(grep -cP '^\t' "$file_path" 2>/dev/null || echo 0)
    space_lines=$(grep -cP '^ {2,}' "$file_path" 2>/dev/null || echo 0)
    if [[ "$tab_lines" -gt 0 && "$space_lines" -gt 0 ]]; then
        local mix_ratio
        if [[ "$tab_lines" -gt "$space_lines" ]]; then
            mix_ratio=$((space_lines * 100 / (tab_lines + space_lines)))
        else
            mix_ratio=$((tab_lines * 100 / (tab_lines + space_lines)))
        fi
        if [[ "$mix_ratio" -gt 10 ]]; then
            style=$((style - 15))
            style_issues="${style_issues}mixed_indent;"
        fi
    fi

    # Check for trailing whitespace
    local trailing_ws
    trailing_ws=$(grep -cP '[ \t]+$' "$file_path" 2>/dev/null || echo 0)
    if [[ "$trailing_ws" -gt 5 ]]; then
        style=$((style - 10))
        style_issues="${style_issues}trailing_ws=${trailing_ws};"
    fi

    # Check for very long lines (>120 chars)
    local long_lines
    long_lines=$(awk 'length > 120' "$file_path" 2>/dev/null | wc -l | tr -d ' ')
    if [[ "$long_lines" -gt 5 ]]; then
        style=$((style - long_lines / 2))
        style_issues="${style_issues}long_lines=${long_lines};"
    fi

    # Check naming: camelCase for JS/TS functions, snake_case for Python
    if [[ "$ext" =~ ^(ts|tsx|js|jsx)$ ]]; then
        local snake_funcs
        snake_funcs=$(grep -cE '(const|let|var|function)\s+[a-z]+_[a-z]+' "$file_path" 2>/dev/null || echo 0)
        if [[ "$snake_funcs" -gt 3 ]]; then
            style=$((style - 10))
            style_issues="${style_issues}naming_convention=${snake_funcs};"
        fi
    fi

    # Check for magic numbers (numeric literals other than 0, 1, -1)
    if [[ "$ext" =~ ^(ts|tsx|js|jsx)$ && "$file_type" == "code" ]]; then
        local magic_nums
        magic_nums=$(grep -oE '[^A-Za-z0-9_][0-9]{2,}[^A-Za-z0-9_.]' "$file_path" 2>/dev/null \
            | grep -cvE 'port|PORT|timeout|TIMEOUT|status|STATUS|0x|1000|100|200|201|204|301|302|400|401|403|404|500' || echo 0)
        if [[ "$magic_nums" -gt 5 ]]; then
            style=$((style - 8))
            style_issues="${style_issues}magic_numbers=${magic_nums};"
        fi
    fi

    # Reward: has file-level comment/docstring
    local has_header
    has_header=$(head -5 "$file_path" 2>/dev/null | grep -cE '^(//|/\*|\*|#|""")' || echo 0)
    if [[ "$has_header" -eq 0 && "$line_count" -gt 20 ]]; then
        style=$((style - 5))
        style_issues="${style_issues}no_file_header;"
    fi
    [[ "$style" -lt 0 ]] && style=0

    # --- Security (0-100) ---
    local security=100
    local security_issues=""

    # Check for hardcoded secrets
    local secrets_count
    secrets_count=$(grep -ciE \
        '(api[_-]?key|secret[_-]?key|password|token|credential)\s*[:=]\s*["\x27][A-Za-z0-9+/=]{8,}' \
        "$file_path" 2>/dev/null || echo 0)
    if [[ "$secrets_count" -gt 0 ]]; then
        security=$((security - secrets_count * 25))
        security_issues="${security_issues}hardcoded_secrets=${secrets_count};"
    fi

    # Check for eval() usage
    local eval_count
    eval_count=$(grep -cE '\beval\s*\(' "$file_path" 2>/dev/null || echo 0)
    if [[ "$eval_count" -gt 0 ]]; then
        security=$((security - eval_count * 20))
        security_issues="${security_issues}eval_usage=${eval_count};"
    fi

    # Check for innerHTML usage (XSS vector)
    local innerhtml_count
    innerhtml_count=$(grep -cE '\.innerHTML\s*=' "$file_path" 2>/dev/null || echo 0)
    if [[ "$innerhtml_count" -gt 0 ]]; then
        security=$((security - innerhtml_count * 15))
        security_issues="${security_issues}innerHTML=${innerhtml_count};"
    fi

    # Check for SQL injection patterns (raw string concatenation in queries)
    local sql_inject
    sql_inject=$(grep -cE "(query|execute|raw)\s*\(\s*['\"\`].*\\\$\{|query\s*\(\s*['\"].*\+\s*[a-zA-Z]" \
        "$file_path" 2>/dev/null || echo 0)
    if [[ "$sql_inject" -gt 0 ]]; then
        security=$((security - sql_inject * 20))
        security_issues="${security_issues}sql_injection_risk=${sql_inject};"
    fi

    # Check for missing input validation in API routes (Next.js)
    if [[ "$file_path" =~ /api/ && "$ext" =~ ^(ts|js)$ ]]; then
        local has_validation
        has_validation=$(grep -cE 'zod|z\.(string|number|object|array)|validate|schema\.parse|safeParse' \
            "$file_path" 2>/dev/null || echo 0)
        if [[ "$has_validation" -eq 0 ]]; then
            security=$((security - 15))
            security_issues="${security_issues}no_input_validation;"
        fi
    fi

    # Check for sensitive data in error messages
    local leak_count
    leak_count=$(grep -cE 'res\.(json|send)\(.*error\.(message|stack)|catch.*res\..*500.*err' \
        "$file_path" 2>/dev/null || echo 0)
    if [[ "$leak_count" -gt 0 ]]; then
        security=$((security - leak_count * 8))
        security_issues="${security_issues}error_leakage=${leak_count};"
    fi

    # Check for CORS wildcard
    local cors_wildcard
    cors_wildcard=$(grep -cE "origin:\s*['\"]\\*['\"]|Access-Control-Allow-Origin.*\\*" \
        "$file_path" 2>/dev/null || echo 0)
    if [[ "$cors_wildcard" -gt 0 ]]; then
        security=$((security - 12))
        security_issues="${security_issues}cors_wildcard;"
    fi
    [[ "$security" -lt 0 ]] && security=0

    # --- Performance (0-100) ---
    local performance=100
    local perf_issues=""

    # Check for N+1 query patterns (await inside loop)
    local n_plus_one
    n_plus_one=$(grep -cE 'for\s*\(.*\)\s*\{' "$file_path" 2>/dev/null)
    if [[ "$n_plus_one" -gt 0 ]]; then
        # Look for await/fetch/query inside loops
        local await_in_loop
        await_in_loop=$(awk '/for\s*\(/{f=1} f&&/await|\.findUnique|\.findFirst|fetch\(/{c++} /^\s*\}/{f=0} END{print c+0}' \
            "$file_path" 2>/dev/null)
        if [[ "$await_in_loop" -gt 0 ]]; then
            performance=$((performance - await_in_loop * 15))
            perf_issues="${perf_issues}n_plus_one=${await_in_loop};"
        fi
    fi

    # Check for missing memoization in React (re-renders)
    if [[ "$ext" =~ ^(tsx|jsx)$ ]]; then
        local expensive_renders
        expensive_renders=$(grep -cE '\.map\s*\(|\.filter\s*\(|\.reduce\s*\(' "$file_path" 2>/dev/null || echo 0)
        local has_memo
        has_memo=$(grep -cE 'useMemo|useCallback|React\.memo' "$file_path" 2>/dev/null || echo 0)
        if [[ "$expensive_renders" -gt 3 && "$has_memo" -eq 0 ]]; then
            performance=$((performance - 10))
            perf_issues="${perf_issues}no_memoization;"
        fi
    fi

    # Check for synchronous file operations in Node.js
    local sync_io
    sync_io=$(grep -cE 'readFileSync|writeFileSync|appendFileSync|existsSync|readdirSync|statSync' \
        "$file_path" 2>/dev/null || echo 0)
    if [[ "$sync_io" -gt 2 && "$file_type" != "tests" && "$file_type" != "config" ]]; then
        performance=$((performance - sync_io * 5))
        perf_issues="${perf_issues}sync_io=${sync_io};"
    fi

    # Check for missing pagination in database queries
    if [[ "$file_path" =~ /api/ ]]; then
        local findmany_count
        findmany_count=$(grep -cE '\.findMany\s*\(' "$file_path" 2>/dev/null || echo 0)
        local has_take
        has_take=$(grep -cE 'take:|skip:|limit:|offset:' "$file_path" 2>/dev/null || echo 0)
        if [[ "$findmany_count" -gt 0 && "$has_take" -eq 0 ]]; then
            performance=$((performance - 12))
            perf_issues="${perf_issues}no_pagination;"
        fi
    fi

    # Check for large bundle imports
    local large_imports
    large_imports=$(grep -cE "import .* from ['\"]lodash['\"]|import .* from ['\"]moment['\"]" \
        "$file_path" 2>/dev/null || echo 0)
    if [[ "$large_imports" -gt 0 ]]; then
        performance=$((performance - large_imports * 8))
        perf_issues="${perf_issues}large_bundle_import=${large_imports};"
    fi
    [[ "$performance" -lt 0 ]] && performance=0

    # --- Accessibility (0-100) ---
    local accessibility=100
    local a11y_issues=""

    if [[ "$ext" =~ ^(tsx|jsx|html)$ ]]; then
        # Check for images without alt text
        local no_alt
        no_alt=$(grep -cE '<img\b' "$file_path" 2>/dev/null || echo 0)
        local has_alt
        has_alt=$(grep -cE '<img\b[^>]*alt=' "$file_path" 2>/dev/null || echo 0)
        local missing_alt=$((no_alt - has_alt))
        if [[ "$missing_alt" -gt 0 ]]; then
            accessibility=$((accessibility - missing_alt * 15))
            a11y_issues="${a11y_issues}missing_alt=${missing_alt};"
        fi

        # Check for clickable divs without role/tabIndex
        local clickable_div
        clickable_div=$(grep -cE '<div\b[^>]*onClick' "$file_path" 2>/dev/null || echo 0)
        local clickable_with_role
        clickable_with_role=$(grep -cE '<div\b[^>]*onClick[^>]*(role=|tabIndex)' "$file_path" 2>/dev/null || echo 0)
        local missing_role=$((clickable_div - clickable_with_role))
        if [[ "$missing_role" -gt 0 ]]; then
            accessibility=$((accessibility - missing_role * 12))
            a11y_issues="${a11y_issues}clickable_no_role=${missing_role};"
        fi

        # Check for form inputs without labels
        local inputs
        inputs=$(grep -cE '<input\b' "$file_path" 2>/dev/null || echo 0)
        local labeled_inputs
        labeled_inputs=$(grep -cE '<input\b[^>]*(aria-label|aria-labelledby|id=)' "$file_path" 2>/dev/null || echo 0)
        local label_tags
        label_tags=$(grep -cE '<label\b[^>]*htmlFor=' "$file_path" 2>/dev/null || echo 0)
        local unlabeled=$((inputs - labeled_inputs - label_tags))
        [[ "$unlabeled" -lt 0 ]] && unlabeled=0
        if [[ "$unlabeled" -gt 0 ]]; then
            accessibility=$((accessibility - unlabeled * 10))
            a11y_issues="${a11y_issues}unlabeled_inputs=${unlabeled};"
        fi

        # Check for semantic HTML
        local has_semantic
        has_semantic=$(grep -cE '<(nav|main|header|footer|section|article|aside)\b' \
            "$file_path" 2>/dev/null || echo 0)
        local total_divs
        total_divs=$(grep -cE '<div\b' "$file_path" 2>/dev/null || echo 0)
        if [[ "$total_divs" -gt 10 && "$has_semantic" -eq 0 ]]; then
            accessibility=$((accessibility - 10))
            a11y_issues="${a11y_issues}no_semantic_html;"
        fi

        # Check for color-only indicators (no text/icon alternative)
        local color_only
        color_only=$(grep -cE 'className=.*text-(red|green|yellow|blue)-[0-9]' "$file_path" 2>/dev/null || echo 0)
        local has_sr_only
        has_sr_only=$(grep -cE 'sr-only|visually-hidden|aria-live' "$file_path" 2>/dev/null || echo 0)
        if [[ "$color_only" -gt 3 && "$has_sr_only" -eq 0 ]]; then
            accessibility=$((accessibility - 8))
            a11y_issues="${a11y_issues}color_only_indicators;"
        fi

        # Check for keyboard navigation support
        local interactive_elements
        interactive_elements=$(grep -cE 'onClick|onPress' "$file_path" 2>/dev/null || echo 0)
        local keyboard_handlers
        keyboard_handlers=$(grep -cE 'onKeyDown|onKeyUp|onKeyPress|tabIndex' "$file_path" 2>/dev/null || echo 0)
        if [[ "$interactive_elements" -gt 3 && "$keyboard_handlers" -eq 0 ]]; then
            accessibility=$((accessibility - 10))
            a11y_issues="${a11y_issues}no_keyboard_nav;"
        fi
    else
        # Non-UI files: accessibility is not directly applicable, score high
        accessibility=95
    fi
    [[ "$accessibility" -lt 0 ]] && accessibility=0

    # --- Calculate weighted total ---
    local total=0
    total=$(( \
        completeness  * ${OM_WEIGHTS[completeness]:-25} + \
        correctness   * ${OM_WEIGHTS[correctness]:-25}  + \
        style         * ${OM_WEIGHTS[style]:-15}        + \
        security      * ${OM_WEIGHTS[security]:-15}     + \
        performance   * ${OM_WEIGHTS[performance]:-10}  + \
        accessibility * ${OM_WEIGHTS[accessibility]:-10} \
    ))
    total=$((total / 100))

    # Update statistics
    OM_TOTAL_FILES_SCORED=$((OM_TOTAL_FILES_SCORED + 1))
    local issue_parts=0
    [[ -n "$completeness_issues" ]] && issue_parts=$((issue_parts + 1))
    [[ -n "$correctness_issues" ]] && issue_parts=$((issue_parts + 1))
    [[ -n "$style_issues" ]]       && issue_parts=$((issue_parts + 1))
    [[ -n "$security_issues" ]]    && issue_parts=$((issue_parts + 1))
    [[ -n "$perf_issues" ]]        && issue_parts=$((issue_parts + 1))
    [[ -n "$a11y_issues" ]]        && issue_parts=$((issue_parts + 1))
    OM_TOTAL_ISSUES_FOUND=$((OM_TOTAL_ISSUES_FOUND + issue_parts))

    # Build JSON result
    local filename
    filename="$(basename "$file_path")"
    cat <<EOF
{
  "file": "$(echo "$file_path" | sed 's/"/\\"/g')",
  "filename": "${filename}",
  "type": "${file_type}",
  "domain": "${domain}",
  "lines": ${line_count},
  "scores": {
    "completeness": ${completeness},
    "correctness": ${correctness},
    "style": ${style},
    "security": ${security},
    "performance": ${performance},
    "accessibility": ${accessibility}
  },
  "total": ${total},
  "issues": {
    "completeness": "$(echo "$completeness_issues" | sed 's/;$//')",
    "correctness": "$(echo "$correctness_issues" | sed 's/;$//')",
    "style": "$(echo "$style_issues" | sed 's/;$//')",
    "security": "$(echo "$security_issues" | sed 's/;$//')",
    "performance": "$(echo "$perf_issues" | sed 's/;$//')",
    "accessibility": "$(echo "$a11y_issues" | sed 's/;$//')"
  },
  "pass": $([ "$total" -ge 60 ] && echo "true" || echo "false")
}
EOF
    return 0
}

# =============================================================================
# Internal: Classify file type from extension/path
# =============================================================================
_om_classify_file() {
    local fpath="$1"
    local ext="${fpath##*.}"
    local base
    base="$(basename "$fpath")"

    # Test files
    if [[ "$fpath" =~ (__tests__|\.test\.|\.spec\.|test/|tests/|__mocks__) ]]; then
        echo "tests"
        return
    fi

    # Config files
    if [[ "$ext" =~ ^(json|yaml|yml|toml|ini|env|config)$ ]] \
        || [[ "$base" =~ ^(tsconfig|package|next\.config|tailwind\.config|postcss\.config|jest\.config|vitest\.config|eslint|prettier|Dockerfile|docker-compose) ]]; then
        echo "config"
        return
    fi

    # Documentation
    if [[ "$ext" =~ ^(md|mdx|txt|rst|adoc)$ ]]; then
        echo "docs"
        return
    fi

    # Default: code
    echo "code"
}

# =============================================================================
# Internal: Collect source files from a project directory
# =============================================================================
_om_collect_files() {
    local project_dir="$1"
    local max_files="${2:-500}"

    find "$project_dir" \
        -type f \
        \( -name '*.ts' -o -name '*.tsx' -o -name '*.js' -o -name '*.jsx' \
           -o -name '*.py' -o -name '*.go' -o -name '*.rs' \
           -o -name '*.json' -o -name '*.yaml' -o -name '*.yml' \
           -o -name '*.css' -o -name '*.scss' -o -name '*.html' \
           -o -name '*.md' -o -name '*.mdx' \
           -o -name '*.sh' -o -name '*.sql' \) \
        -not -path '*/node_modules/*' \
        -not -path '*/.next/*' \
        -not -path '*/dist/*' \
        -not -path '*/build/*' \
        -not -path '*/.git/*' \
        -not -path '*/coverage/*' \
        -not -path '*/__pycache__/*' \
        -not -path '*/vendor/*' \
        -not -name '*.min.*' \
        -not -name 'package-lock.json' \
        -not -name 'yarn.lock' \
        -not -name 'pnpm-lock.yaml' \
        2>/dev/null | head -n "$max_files" | sort
}

# =============================================================================
# 3. om_score_project(project_dir) - Score entire project
# =============================================================================
om_score_project() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    if [[ ! -d "$project_dir" ]]; then
        log_error "Project directory not found: ${project_dir}"
        echo '{"error":"dir_not_found","total":0}'
        return 1
    fi

    [[ "$OM_INITIALIZED" != "true" ]] && om_init

    log_info "Scoring project: ${project_dir}"

    local files
    files=$(_om_collect_files "$project_dir")
    local file_count
    file_count=$(echo "$files" | grep -c '.' 2>/dev/null || echo 0)

    if [[ "$file_count" -eq 0 ]]; then
        log_warn "No source files found in ${project_dir}"
        echo '{"error":"no_files","total":0}'
        return 1
    fi

    log_info "Found ${file_count} source files"

    # Aggregate scores
    local sum_completeness=0 sum_correctness=0 sum_style=0
    local sum_security=0 sum_performance=0 sum_accessibility=0
    local sum_total=0 scored_count=0
    local file_scores="["
    local first_entry=true
    local worst_file="" worst_score=101
    local best_file="" best_score=-1

    # Per-directory tracking
    declare -A dir_totals=()
    declare -A dir_counts=()

    while IFS= read -r fpath; do
        [[ -z "$fpath" ]] && continue
        [[ ! -f "$fpath" ]] && continue

        local ftype
        ftype=$(_om_classify_file "$fpath")
        local result
        result=$(om_score_output "$fpath" "$ftype" "auto" 2>/dev/null)

        # Extract total score
        local ftotal
        ftotal=$(echo "$result" | grep '"total"' | head -1 | grep -oE '[0-9]+')
        [[ -z "$ftotal" ]] && continue

        # Extract per-axis scores
        local fc fc2 fs fse fp fa
        fc=$(echo "$result" | grep '"completeness"' | head -1 | grep -oE '[0-9]+')
        fc2=$(echo "$result" | grep '"correctness"' | head -1 | grep -oE '[0-9]+')
        fs=$(echo "$result" | grep '"style"' | head -1 | grep -oE '[0-9]+')
        fse=$(echo "$result" | grep '"security"' | head -1 | grep -oE '[0-9]+')
        fp=$(echo "$result" | grep '"performance"' | head -1 | grep -oE '[0-9]+')
        fa=$(echo "$result" | grep '"accessibility"' | head -1 | grep -oE '[0-9]+')

        sum_completeness=$((sum_completeness + ${fc:-0}))
        sum_correctness=$((sum_correctness + ${fc2:-0}))
        sum_style=$((sum_style + ${fs:-0}))
        sum_security=$((sum_security + ${fse:-0}))
        sum_performance=$((sum_performance + ${fp:-0}))
        sum_accessibility=$((sum_accessibility + ${fa:-0}))
        sum_total=$((sum_total + ftotal))
        scored_count=$((scored_count + 1))

        # Track best/worst
        if [[ "$ftotal" -lt "$worst_score" ]]; then
            worst_score=$ftotal
            worst_file="$fpath"
        fi
        if [[ "$ftotal" -gt "$best_score" ]]; then
            best_score=$ftotal
            best_file="$fpath"
        fi

        # Per-directory aggregation
        local fdir
        fdir="$(dirname "$fpath")"
        fdir="${fdir#${project_dir}}"
        fdir="${fdir#/}"
        [[ -z "$fdir" ]] && fdir="."
        dir_totals["$fdir"]=$(( ${dir_totals["$fdir"]:-0} + ftotal ))
        dir_counts["$fdir"]=$(( ${dir_counts["$fdir"]:-0} + 1 ))

        # Append to file scores array (compact)
        local rel_path="${fpath#${project_dir}/}"
        if [[ "$first_entry" == true ]]; then
            first_entry=false
        else
            file_scores+=","
        fi
        file_scores+="{\"file\":\"${rel_path}\",\"type\":\"${ftype}\",\"total\":${ftotal}}"

    done <<< "$files"

    file_scores+="]"

    # Calculate averages
    local avg_total=0 avg_comp=0 avg_corr=0 avg_style=0 avg_sec=0 avg_perf=0 avg_a11y=0
    if [[ "$scored_count" -gt 0 ]]; then
        avg_total=$((sum_total / scored_count))
        avg_comp=$((sum_completeness / scored_count))
        avg_corr=$((sum_correctness / scored_count))
        avg_style=$((sum_style / scored_count))
        avg_sec=$((sum_security / scored_count))
        avg_perf=$((sum_performance / scored_count))
        avg_a11y=$((sum_accessibility / scored_count))
    fi
    OM_AVG_SCORE=$avg_total

    # Build per-directory scores
    local dir_scores="{"
    local dir_first=true
    for dir_key in "${!dir_totals[@]}"; do
        local davg=0
        [[ "${dir_counts[$dir_key]}" -gt 0 ]] && davg=$(( ${dir_totals[$dir_key]} / ${dir_counts[$dir_key]} ))
        [[ "$dir_first" == true ]] && dir_first=false || dir_scores+=","
        dir_scores+="\"${dir_key}\":{\"avg\":${davg},\"count\":${dir_counts[$dir_key]}}"
    done
    dir_scores+="}"

    log_info "Scored ${scored_count}/${file_count} files, avg=${avg_total}"

    cat <<EOF
{
  "project": "$(echo "$project_dir" | sed 's/"/\\"/g')",
  "timestamp": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')",
  "version": "${OM_VERSION}",
  "file_count": ${scored_count},
  "scores": {
    "completeness": ${avg_comp},
    "correctness": ${avg_corr},
    "style": ${avg_style},
    "security": ${avg_sec},
    "performance": ${avg_perf},
    "accessibility": ${avg_a11y}
  },
  "total": ${avg_total},
  "best": {"file": "$(echo "${best_file#${project_dir}/}" | sed 's/"/\\"/g')", "score": ${best_score}},
  "worst": {"file": "$(echo "${worst_file#${project_dir}/}" | sed 's/"/\\"/g')", "score": ${worst_score}},
  "directories": ${dir_scores},
  "files": ${file_scores},
  "pass": $([ "$avg_total" -ge 60 ] && echo "true" || echo "false")
}
EOF
    return 0
}

# =============================================================================
# 4. om_detect_quality_gaps(project_dir) - Find quality gaps
# =============================================================================
om_detect_quality_gaps() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    if [[ ! -d "$project_dir" ]]; then
        log_error "Project directory not found: ${project_dir}"
        echo '{"error":"dir_not_found","gaps":[]}'
        return 1
    fi

    [[ "$OM_INITIALIZED" != "true" ]] && om_init

    log_info "Detecting quality gaps in: ${project_dir}"

    local gaps="["
    local gap_count=0
    local first_gap=true

    _om_add_gap() {
        local severity="$1" category="$2" file="$3" line="$4" message="$5"
        [[ "$first_gap" == true ]] && first_gap=false || gaps+=","
        gaps+="{\"severity\":\"${severity}\",\"category\":\"${category}\",\"file\":\"$(echo "$file" | sed 's/"/\\"/g')\",\"line\":${line},\"message\":\"$(echo "$message" | sed 's/"/\\"/g')\"}"
        gap_count=$((gap_count + 1))
    }

    # --- 1. Incomplete implementations ---
    log_info "Scanning for incomplete implementations..."
    while IFS=: read -r filepath linenum content; do
        [[ -z "$filepath" ]] && continue
        local rel="${filepath#${project_dir}/}"
        _om_add_gap "high" "incomplete" "$rel" "${linenum:-0}" "$(echo "$content" | sed 's/^[ \t]*//' | head -c 100)"
    done < <(grep -rnE '\bTODO\b|\bFIXME\b|\bHACK\b|throw new Error\(.*(not implemented|todo)\)|NotImplementedError' \
        "$project_dir" \
        --include='*.ts' --include='*.tsx' --include='*.js' --include='*.jsx' --include='*.py' \
        --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=dist 2>/dev/null | head -50)

    # --- 2. API routes without handlers ---
    log_info "Checking route/handler consistency..."
    local route_dir="${project_dir}/src/app/api"
    if [[ -d "$route_dir" ]]; then
        while IFS= read -r route_file; do
            [[ ! -f "$route_file" ]] && continue
            local rel="${route_file#${project_dir}/}"
            # Check if common HTTP method handlers exist
            for method in GET POST PUT DELETE PATCH; do
                if ! grep -qE "export\s+(async\s+)?function\s+${method}\b|export\s+const\s+${method}\b" \
                    "$route_file" 2>/dev/null; then
                    # Only flag if the file looks like an API route
                    if grep -qE "export\s+(async\s+)?function\s+(GET|POST|PUT|DELETE|PATCH)\b" \
                        "$route_file" 2>/dev/null; then
                        # Has at least one method, check if common ones are missing
                        if [[ "$method" == "GET" || "$method" == "POST" ]]; then
                            continue  # Not all routes need both
                        fi
                    fi
                fi
            done
            # Check for empty route files
            local route_lines
            route_lines=$(wc -l < "$route_file" | tr -d ' ')
            if [[ "$route_lines" -lt 3 ]]; then
                _om_add_gap "critical" "missing_handler" "$rel" 1 "API route file is nearly empty (${route_lines} lines)"
            fi
        done < <(find "$route_dir" -name 'route.ts' -o -name 'route.js' 2>/dev/null)
    fi

    # --- 3. Missing error boundaries (React) ---
    log_info "Checking for missing error boundaries..."
    local page_dirs
    page_dirs=$(find "$project_dir/src/app" -type d 2>/dev/null | grep -v node_modules | head -50)
    while IFS= read -r page_dir; do
        [[ -z "$page_dir" ]] && continue
        if [[ -f "${page_dir}/page.tsx" || -f "${page_dir}/page.jsx" ]]; then
            if [[ ! -f "${page_dir}/error.tsx" && ! -f "${page_dir}/error.jsx" ]]; then
                local rel="${page_dir#${project_dir}/}"
                _om_add_gap "medium" "missing_error_boundary" "$rel" 0 "Page directory missing error.tsx boundary"
            fi
        fi
    done <<< "$page_dirs"

    # --- 4. Missing loading states in React components ---
    log_info "Checking for missing loading states..."
    while IFS= read -r page_dir; do
        [[ -z "$page_dir" ]] && continue
        if [[ -f "${page_dir}/page.tsx" || -f "${page_dir}/page.jsx" ]]; then
            if [[ ! -f "${page_dir}/loading.tsx" && ! -f "${page_dir}/loading.jsx" ]]; then
                # Check if the page uses async data fetching
                local page_file="${page_dir}/page.tsx"
                [[ ! -f "$page_file" ]] && page_file="${page_dir}/page.jsx"
                if grep -qE 'async|await|fetch\(|useQuery|useSWR|use\(' "$page_file" 2>/dev/null; then
                    local rel="${page_dir#${project_dir}/}"
                    _om_add_gap "medium" "missing_loading" "$rel" 0 "Async page missing loading.tsx (Suspense boundary)"
                fi
            fi
        fi
    done <<< "$page_dirs"

    # --- 5. Missing validation in API routes ---
    log_info "Checking API input validation..."
    while IFS= read -r api_file; do
        [[ -z "$api_file" ]] && continue
        local rel="${api_file#${project_dir}/}"
        # Check for POST/PUT/PATCH handlers without Zod/validation
        if grep -qE 'export\s+(async\s+)?function\s+(POST|PUT|PATCH)' "$api_file" 2>/dev/null; then
            if ! grep -qE 'z\.|zod|schema|validate|safeParse|parse\(' "$api_file" 2>/dev/null; then
                local line_num
                line_num=$(grep -nE 'export\s+(async\s+)?function\s+(POST|PUT|PATCH)' "$api_file" 2>/dev/null | head -1 | cut -d: -f1)
                _om_add_gap "high" "missing_validation" "$rel" "${line_num:-0}" "Mutation endpoint without input validation"
            fi
        fi
        # Check for request.json() without try-catch
        if grep -qE 'request\.json\(\)|req\.json\(\)' "$api_file" 2>/dev/null; then
            if ! grep -qE 'try\s*\{' "$api_file" 2>/dev/null; then
                local line_num
                line_num=$(grep -nE 'request\.json\(\)|req\.json\(\)' "$api_file" 2>/dev/null | head -1 | cut -d: -f1)
                _om_add_gap "high" "unhandled_parse" "$rel" "${line_num:-0}" "JSON parse without try-catch (malformed body crashes)"
            fi
        fi
    done < <(find "$project_dir" -path '*/api/*' \( -name '*.ts' -o -name '*.js' \) \
        -not -path '*/node_modules/*' 2>/dev/null | head -100)

    # --- 6. Components without proper TypeScript props ---
    log_info "Checking component type safety..."
    while IFS= read -r comp_file; do
        [[ -z "$comp_file" ]] && continue
        local rel="${comp_file#${project_dir}/}"
        # React components without Props interface/type
        if grep -qE 'export\s+(default\s+)?function\s+[A-Z]' "$comp_file" 2>/dev/null; then
            if ! grep -qE 'interface\s+\w*Props|type\s+\w*Props|Props\s*=' "$comp_file" 2>/dev/null; then
                local func_line
                func_line=$(grep -nE 'export\s+(default\s+)?function\s+[A-Z]' "$comp_file" 2>/dev/null | head -1 | cut -d: -f1)
                # Only flag if the component accepts parameters
                if grep -qE 'function\s+[A-Z]\w*\s*\(\s*\{' "$comp_file" 2>/dev/null; then
                    _om_add_gap "medium" "missing_types" "$rel" "${func_line:-0}" "Component accepts props without typed Props interface"
                fi
            fi
        fi
    done < <(find "$project_dir/src" \( -name '*.tsx' -o -name '*.jsx' \) \
        -not -path '*/node_modules/*' -not -name '*.test.*' -not -name '*.spec.*' 2>/dev/null | head -100)

    # --- 7. Missing env validation ---
    local env_file="${project_dir}/.env"
    local env_validation="${project_dir}/src/lib/env.ts"
    if [[ -f "$env_file" && ! -f "$env_validation" ]]; then
        _om_add_gap "medium" "missing_env_validation" ".env" 0 \
            "Environment variables used but no src/lib/env.ts validation schema found"
    fi

    gaps+="]"

    # Sort by severity (critical > high > medium > low)
    log_info "Found ${gap_count} quality gaps"

    cat <<EOF
{
  "project": "$(echo "$project_dir" | sed 's/"/\\"/g')",
  "timestamp": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')",
  "gap_count": ${gap_count},
  "gaps": ${gaps}
}
EOF
    unset -f _om_add_gap
    return 0
}

# =============================================================================
# 5. om_auto_enhance(file_path, issues) - Auto-enhance a file
# =============================================================================
om_auto_enhance() {
    local file_path="$1"
    local issues="${2:-}"

    if [[ ! -f "$file_path" ]]; then
        log_error "File not found: ${file_path}"
        echo '{"error":"file_not_found","enhancements":[]}'
        return 1
    fi

    [[ "$OM_INITIALIZED" != "true" ]] && om_init

    local ext="${file_path##*.}"
    local enhancements="["
    local first_enh=true
    local enh_count=0

    _om_add_enhancement() {
        local type="$1" line="$2" instruction="$3"
        [[ "$first_enh" == true ]] && first_enh=false || enhancements+=","
        enhancements+="{\"type\":\"${type}\",\"line\":${line},\"instruction\":\"$(echo "$instruction" | sed 's/"/\\"/g')\"}"
        enh_count=$((enh_count + 1))
    }

    # --- Add missing error handling wrappers ---
    if [[ "$ext" =~ ^(ts|tsx|js|jsx)$ ]]; then
        # Find async functions without try-catch
        while IFS=: read -r linenum content; do
            [[ -z "$linenum" ]] && continue
            # Look ahead for try-catch within next 5 lines (rough check)
            local has_try
            has_try=$(sed -n "$((linenum+1)),$((linenum+5))p" "$file_path" 2>/dev/null | grep -c 'try\s*{' || echo 0)
            if [[ "$has_try" -eq 0 ]]; then
                _om_add_enhancement "error_handling" "$linenum" \
                    "Wrap async function body in try-catch with proper error response"
            fi
        done < <(grep -nE 'async\s+function|async\s*\(' "$file_path" 2>/dev/null \
            | grep -v 'test\|spec\|describe\|it(' | head -20)
    fi

    # --- Add missing loading states ---
    if [[ "$ext" =~ ^(tsx|jsx)$ ]]; then
        # Components with data fetching but no loading state
        if grep -qE 'useState|useQuery|useSWR|fetch\(' "$file_path" 2>/dev/null; then
            local has_loading
            has_loading=$(grep -cE 'isLoading|loading|Loading|Skeleton|Spinner|pending' "$file_path" 2>/dev/null || echo 0)
            if [[ "$has_loading" -eq 0 ]]; then
                local fetch_line
                fetch_line=$(grep -nE 'useState|useQuery|useSWR|fetch\(' "$file_path" 2>/dev/null | head -1 | cut -d: -f1)
                _om_add_enhancement "loading_state" "${fetch_line:-1}" \
                    "Add loading state with Skeleton/Spinner while data is being fetched"
            fi
        fi

        # Components with conditional rendering but no empty state
        if grep -qE '\.length\s*===?\s*0|\.length\s*<\s*1|isEmpty' "$file_path" 2>/dev/null; then
            local has_empty_state
            has_empty_state=$(grep -cE 'EmptyState|No\s+\w+\s+found|empty.*state' "$file_path" 2>/dev/null || echo 0)
            if [[ "$has_empty_state" -eq 0 ]]; then
                local empty_line
                empty_line=$(grep -nE '\.length\s*===?\s*0' "$file_path" 2>/dev/null | head -1 | cut -d: -f1)
                _om_add_enhancement "empty_state" "${empty_line:-1}" \
                    "Add proper EmptyState component with icon and action prompt"
            fi
        fi
    fi

    # --- Add missing input validation ---
    if [[ "$file_path" =~ /api/ && "$ext" =~ ^(ts|js)$ ]]; then
        if grep -qE 'request\.json\(\)|req\.body' "$file_path" 2>/dev/null; then
            local has_zod
            has_zod=$(grep -cE 'z\.|zod|schema\.parse|safeParse' "$file_path" 2>/dev/null || echo 0)
            if [[ "$has_zod" -eq 0 ]]; then
                local body_line
                body_line=$(grep -nE 'request\.json\(\)|req\.body' "$file_path" 2>/dev/null | head -1 | cut -d: -f1)
                _om_add_enhancement "input_validation" "${body_line:-1}" \
                    "Add Zod schema validation: define schema with z.object(), use schema.safeParse(body), return 400 on failure"
            fi
        fi
    fi

    # --- Replace TypeScript 'any' with proper types ---
    if [[ "$ext" =~ ^(ts|tsx)$ ]]; then
        while IFS=: read -r linenum content; do
            [[ -z "$linenum" ]] && continue
            local trimmed
            trimmed="$(echo "$content" | sed 's/^[ \t]*//' | head -c 80)"
            _om_add_enhancement "type_safety" "$linenum" \
                "Replace 'any' type with proper TypeScript type: ${trimmed}"
        done < <(grep -nE ':\s*any\b|<any>|as any' "$file_path" 2>/dev/null | head -15)
    fi

    # --- Add missing ARIA labels ---
    if [[ "$ext" =~ ^(tsx|jsx)$ ]]; then
        while IFS=: read -r linenum content; do
            [[ -z "$linenum" ]] && continue
            _om_add_enhancement "accessibility" "$linenum" \
                "Add aria-label or aria-labelledby to interactive element"
        done < <(grep -nE '<(button|a|input|select|textarea)\b' "$file_path" 2>/dev/null \
            | grep -v 'aria-label\|aria-labelledby' | head -10)

        # Clickable divs without button role
        while IFS=: read -r linenum content; do
            [[ -z "$linenum" ]] && continue
            _om_add_enhancement "accessibility" "$linenum" \
                "Replace clickable div with <button> or add role='button' tabIndex={0} onKeyDown handler"
        done < <(grep -nE '<div\b[^>]*onClick' "$file_path" 2>/dev/null \
            | grep -v 'role=\|tabIndex' | head -10)
    fi

    # --- Add missing error boundary suggestion ---
    if [[ "$ext" =~ ^(tsx|jsx)$ ]]; then
        if grep -qE 'export\s+default\s+function\s+\w+Page' "$file_path" 2>/dev/null; then
            local sibling_error="${file_path%/*}/error.tsx"
            if [[ ! -f "$sibling_error" ]]; then
                _om_add_enhancement "error_boundary" 1 \
                    "Create sibling error.tsx with 'use client' Error Boundary for graceful failure handling"
            fi
        fi
    fi

    # --- Console.log cleanup ---
    if [[ "$ext" =~ ^(ts|tsx|js|jsx)$ ]]; then
        while IFS=: read -r linenum content; do
            [[ -z "$linenum" ]] && continue
            _om_add_enhancement "cleanup" "$linenum" \
                "Remove console.log (use structured logger instead)"
        done < <(grep -nE 'console\.(log|debug|dir)\(' "$file_path" 2>/dev/null \
            | grep -v '// keep\|eslint-disable' | head -10)
    fi

    enhancements+="]"

    OM_TOTAL_ENHANCEMENTS=$((OM_TOTAL_ENHANCEMENTS + enh_count))
    log_info "Generated ${enh_count} enhancement instructions for $(basename "$file_path")"

    cat <<EOF
{
  "file": "$(echo "$file_path" | sed 's/"/\\"/g')",
  "enhancement_count": ${enh_count},
  "enhancements": ${enhancements}
}
EOF
    unset -f _om_add_enhancement
    return 0
}

# =============================================================================
# 6. om_validate_consistency(project_dir) - Cross-file consistency check
# =============================================================================
om_validate_consistency() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    if [[ ! -d "$project_dir" ]]; then
        log_error "Project directory not found: ${project_dir}"
        echo '{"error":"dir_not_found","inconsistencies":[]}'
        return 1
    fi

    [[ "$OM_INITIALIZED" != "true" ]] && om_init

    log_info "Validating cross-file consistency in: ${project_dir}"

    local issues="["
    local issue_count=0
    local first_issue=true

    _om_add_issue() {
        local category="$1" source="$2" target="$3" detail="$4"
        [[ "$first_issue" == true ]] && first_issue=false || issues+=","
        issues+="{\"category\":\"${category}\",\"source\":\"$(echo "$source" | sed 's/"/\\"/g')\",\"target\":\"$(echo "$target" | sed 's/"/\\"/g')\",\"detail\":\"$(echo "$detail" | sed 's/"/\\"/g')\"}"
        issue_count=$((issue_count + 1))
    }

    # --- 1. Import/Export consistency ---
    log_info "Checking import/export consistency..."

    # Collect all local imports
    local import_map_file
    import_map_file="$(mktemp)"
    grep -rnE "from\s+['\"](\.\./|\./|@/)" "$project_dir/src" \
        --include='*.ts' --include='*.tsx' --include='*.js' --include='*.jsx' \
        --exclude-dir=node_modules 2>/dev/null | head -200 > "$import_map_file"

    while IFS=: read -r source_file linenum import_line; do
        [[ -z "$import_line" ]] && continue

        # Extract the import path
        local import_path
        import_path=$(echo "$import_line" | grep -oE "from\s+['\"]([^'\"]+)['\"]" | sed "s/from *['\"]//;s/['\"]$//")
        [[ -z "$import_path" ]] && continue

        # Resolve the path relative to the source file
        local source_dir
        source_dir="$(dirname "$source_file")"
        local resolved=""

        if [[ "$import_path" == @/* ]]; then
            # @/ alias typically maps to src/
            resolved="${project_dir}/src/${import_path#@/}"
        elif [[ "$import_path" == ./* || "$import_path" == ../* ]]; then
            resolved="$(cd "$source_dir" 2>/dev/null && cd "$(dirname "$import_path")" 2>/dev/null && pwd)/$(basename "$import_path")"
        fi
        [[ -z "$resolved" ]] && continue

        # Check if the target file exists (try common extensions)
        local found=false
        for try_ext in "" ".ts" ".tsx" ".js" ".jsx" "/index.ts" "/index.tsx" "/index.js"; do
            if [[ -f "${resolved}${try_ext}" ]]; then
                found=true
                break
            fi
        done

        if [[ "$found" == false ]]; then
            local rel_source="${source_file#${project_dir}/}"
            _om_add_issue "broken_import" "$rel_source" "$import_path" \
                "Import target does not exist (line ${linenum})"
        fi
    done < "$import_map_file"
    rm -f "$import_map_file"

    # --- 2. Route/Handler consistency ---
    log_info "Checking route/handler consistency..."
    local app_dir="${project_dir}/src/app"
    if [[ -d "$app_dir" ]]; then
        # Find page.tsx files that reference API routes
        while IFS= read -r page_file; do
            [[ -z "$page_file" ]] && continue
            # Extract fetch('/api/...') calls
            while IFS= read -r api_call; do
                [[ -z "$api_call" ]] && continue
                local api_path
                api_path=$(echo "$api_call" | grep -oE '/api/[a-zA-Z0-9/_-]+' | head -1)
                [[ -z "$api_path" ]] && continue

                # Check if the route handler exists
                local route_file="${app_dir}${api_path}/route.ts"
                local route_file_js="${app_dir}${api_path}/route.js"
                if [[ ! -f "$route_file" && ! -f "$route_file_js" ]]; then
                    local rel="${page_file#${project_dir}/}"
                    _om_add_issue "missing_route" "$rel" "$api_path" \
                        "Page fetches API route that has no handler file"
                fi
            done < <(grep -oE "fetch\s*\(\s*['\"][^'\"]*['\"]" "$page_file" 2>/dev/null | grep '/api/')
        done < <(find "$app_dir" -name 'page.tsx' -o -name 'page.jsx' 2>/dev/null \
            | grep -v node_modules | head -50)
    fi

    # --- 3. Type consistency ---
    log_info "Checking type consistency..."

    # Find shared type definitions
    local types_dir="${project_dir}/src/types"
    if [[ -d "$types_dir" ]]; then
        while IFS= read -r type_file; do
            [[ -z "$type_file" ]] && continue
            # Extract exported type/interface names
            local exported_types
            exported_types=$(grep -oE 'export\s+(type|interface)\s+([A-Z][A-Za-z0-9]+)' "$type_file" 2>/dev/null \
                | awk '{print $NF}')
            while IFS= read -r type_name; do
                [[ -z "$type_name" ]] && continue
                # Check if any file redefines this type locally instead of importing
                local redefinitions
                redefinitions=$(grep -rlE "(type|interface)\s+${type_name}\b" "$project_dir/src" \
                    --include='*.ts' --include='*.tsx' \
                    --exclude-dir=node_modules --exclude-dir=types 2>/dev/null \
                    | head -5)
                while IFS= read -r redef_file; do
                    [[ -z "$redef_file" || "$redef_file" == "$type_file" ]] && continue
                    local rel_type="${type_file#${project_dir}/}"
                    local rel_redef="${redef_file#${project_dir}/}"
                    _om_add_issue "type_redefinition" "$rel_redef" "$rel_type" \
                        "Type '${type_name}' redefined locally instead of importing from shared types"
                done <<< "$redefinitions"
            done <<< "$exported_types"
        done < <(find "$types_dir" -name '*.ts' 2>/dev/null | head -20)
    fi

    # --- 4. Naming consistency ---
    log_info "Checking naming consistency..."

    # Check component file naming (PascalCase expected)
    while IFS= read -r comp_file; do
        [[ -z "$comp_file" ]] && continue
        local basename_no_ext
        basename_no_ext="$(basename "$comp_file" | sed 's/\.\(tsx\|jsx\)$//')"
        # Check if file contains a React component export but filename is not PascalCase
        if grep -qE 'export\s+(default\s+)?function\s+[A-Z]' "$comp_file" 2>/dev/null; then
            if [[ ! "$basename_no_ext" =~ ^[A-Z] && "$basename_no_ext" != "page" && "$basename_no_ext" != "layout" \
                && "$basename_no_ext" != "error" && "$basename_no_ext" != "loading" && "$basename_no_ext" != "not-found" \
                && "$basename_no_ext" != "index" ]]; then
                local rel="${comp_file#${project_dir}/}"
                _om_add_issue "naming" "$rel" "" \
                    "Component file '${basename_no_ext}' should use PascalCase naming"
            fi
        fi
    done < <(find "$project_dir/src" \( -name '*.tsx' -o -name '*.jsx' \) \
        -not -path '*/node_modules/*' -not -name '*.test.*' 2>/dev/null | head -100)

    # Check for inconsistent export style (default vs named)
    local default_exports named_exports
    default_exports=$(grep -rlE 'export\s+default\s+(function|class)' "$project_dir/src" \
        --include='*.ts' --include='*.tsx' --exclude-dir=node_modules 2>/dev/null | wc -l | tr -d ' ')
    named_exports=$(grep -rlE 'export\s+(function|class|const)' "$project_dir/src" \
        --include='*.ts' --include='*.tsx' --exclude-dir=node_modules 2>/dev/null | wc -l | tr -d ' ')

    if [[ "$default_exports" -gt 5 && "$named_exports" -gt 5 ]]; then
        local total_exports=$((default_exports + named_exports))
        local default_pct=$((default_exports * 100 / total_exports))
        if [[ "$default_pct" -gt 20 && "$default_pct" -lt 80 ]]; then
            _om_add_issue "naming" "project-wide" "" \
                "Mixed export styles: ${default_exports} default exports vs ${named_exports} named exports (pick one convention)"
        fi
    fi

    issues+="]"

    log_info "Found ${issue_count} consistency issues"

    cat <<EOF
{
  "project": "$(echo "$project_dir" | sed 's/"/\\"/g')",
  "timestamp": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')",
  "issue_count": ${issue_count},
  "inconsistencies": ${issues}
}
EOF
    unset -f _om_add_issue
    return 0
}

# =============================================================================
# 7. om_generate_quality_dashboard(project_dir) - ASCII quality dashboard
# =============================================================================
om_generate_quality_dashboard() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    [[ "$OM_INITIALIZED" != "true" ]] && om_init

    # Score the project first
    local report
    report=$(om_score_project "$project_dir" 2>/dev/null)

    if echo "$report" | grep -q '"error"'; then
        log_error "Could not score project for dashboard"
        return 1
    fi

    # Extract scores from report
    local total avg_comp avg_corr avg_style avg_sec avg_perf avg_a11y
    total=$(echo "$report" | grep '"total"' | head -1 | grep -oE '[0-9]+')
    avg_comp=$(echo "$report" | grep '"completeness"' | head -1 | grep -oE '[0-9]+')
    avg_corr=$(echo "$report" | grep '"correctness"' | head -1 | grep -oE '[0-9]+')
    avg_style=$(echo "$report" | grep '"style"' | head -1 | grep -oE '[0-9]+')
    avg_sec=$(echo "$report" | grep '"security"' | head -1 | grep -oE '[0-9]+')
    avg_perf=$(echo "$report" | grep '"performance"' | head -1 | grep -oE '[0-9]+')
    avg_a11y=$(echo "$report" | grep '"accessibility"' | head -1 | grep -oE '[0-9]+')
    local file_count
    file_count=$(echo "$report" | grep '"file_count"' | head -1 | grep -oE '[0-9]+')
    local best_file best_score worst_file worst_score
    best_file=$(echo "$report" | grep -A1 '"best"' | grep '"file"' | grep -oE ':\s*"[^"]*"' | sed 's/: *"//;s/"$//')
    best_score=$(echo "$report" | grep -A2 '"best"' | grep '"score"' | grep -oE '[0-9]+')
    worst_file=$(echo "$report" | grep -A1 '"worst"' | grep '"file"' | grep -oE ':\s*"[^"]*"' | sed 's/: *"//;s/"$//')
    worst_score=$(echo "$report" | grep -A2 '"worst"' | grep '"score"' | grep -oE '[0-9]+')

    # Color helpers
    local G="${CLR_GREEN:-\033[0;32m}"
    local Y="${CLR_YELLOW:-\033[0;33m}"
    local R="${CLR_RED:-\033[0;31m}"
    local C="${CLR_CYAN:-\033[0;36m}"
    local B="${CLR_BOLD:-\033[1m}"
    local P="${CLR_PURPLE:-\033[0;35m}"
    local N="${CLR_NC:-\033[0m}"

    # Score color function
    _om_score_color() {
        local s="$1"
        if [[ "$s" -ge 80 ]]; then echo -ne "$G"
        elif [[ "$s" -ge 60 ]]; then echo -ne "$Y"
        else echo -ne "$R"
        fi
    }

    # Bar function (50 chars wide)
    _om_bar() {
        local score="$1" width=40
        local filled=$((score * width / 100))
        local empty=$((width - filled))
        local color
        if [[ "$score" -ge 80 ]]; then color="$G"
        elif [[ "$score" -ge 60 ]]; then color="$Y"
        else color="$R"
        fi
        printf "${color}"
        printf '%0.s#' $(seq 1 $filled 2>/dev/null) 2>/dev/null
        printf "${N}"
        printf '%0.s-' $(seq 1 $empty 2>/dev/null) 2>/dev/null
    }

    # Grade function
    _om_grade() {
        local s="$1"
        if [[ "$s" -ge 95 ]]; then echo "S"
        elif [[ "$s" -ge 90 ]]; then echo "A+"
        elif [[ "$s" -ge 80 ]]; then echo "A"
        elif [[ "$s" -ge 70 ]]; then echo "B"
        elif [[ "$s" -ge 60 ]]; then echo "C"
        elif [[ "$s" -ge 50 ]]; then echo "D"
        else echo "F"
        fi
    }

    local grade
    grade=$(_om_grade "${total:-0}")

    # Print dashboard
    echo ""
    echo -e "${B}${P}============================================================${N}"
    echo -e "${B}${P}  OUTPUT MAXIMIZER - Quality Dashboard v${OM_VERSION}${N}"
    echo -e "${B}${P}============================================================${N}"
    echo -e "  Project : ${B}${project_dir}${N}"
    echo -e "  Files   : ${file_count:-0}"
    echo -e "  Date    : $(date '+%Y-%m-%d %H:%M')"
    echo -e "${P}------------------------------------------------------------${N}"
    echo ""

    # Overall score (large display)
    echo -e "  ${B}OVERALL SCORE${N}"
    echo ""
    _om_score_color "${total:-0}"
    printf "       ╔═══════════╗\n"
    printf "       ║  %3d / 100 ║   Grade: %s\n" "${total:-0}" "$grade"
    printf "       ╚═══════════╝\n"
    echo -ne "${N}"
    echo ""

    # Per-axis bar charts
    echo -e "  ${B}QUALITY AXES${N}"
    echo -e "  ${C}(weight)${N}"
    echo ""
    printf "  Completeness  (25%%) %3d " "${avg_comp:-0}"
    _om_bar "${avg_comp:-0}"
    echo ""
    printf "  Correctness   (25%%) %3d " "${avg_corr:-0}"
    _om_bar "${avg_corr:-0}"
    echo ""
    printf "  Style         (15%%) %3d " "${avg_style:-0}"
    _om_bar "${avg_style:-0}"
    echo ""
    printf "  Security      (15%%) %3d " "${avg_sec:-0}"
    _om_bar "${avg_sec:-0}"
    echo ""
    printf "  Performance   (10%%) %3d " "${avg_perf:-0}"
    _om_bar "${avg_perf:-0}"
    echo ""
    printf "  Accessibility (10%%) %3d " "${avg_a11y:-0}"
    _om_bar "${avg_a11y:-0}"
    echo ""
    echo ""

    # Best/Worst files
    echo -e "  ${B}HIGHLIGHTS${N}"
    echo -e "  ${G}Best  :${N} ${best_file:-n/a} (${best_score:-0})"
    echo -e "  ${R}Worst :${N} ${worst_file:-n/a} (${worst_score:-0})"
    echo ""

    # Top file scores (extract from JSON)
    echo -e "  ${B}FILE SCORES (top 15)${N}"
    echo -e "  %-50s %5s %6s" "File" "Score" "Type"
    echo -e "  $(printf '%0.s-' {1..65})"

    # Parse file array from report (simple line-by-line extraction)
    echo "$report" | grep -oE '"file":"[^"]*","type":"[^"]*","total":[0-9]+' | head -15 | \
    while IFS= read -r entry; do
        local efile etype escore
        efile=$(echo "$entry" | grep -oE '"file":"[^"]*"' | sed 's/"file":"//;s/"$//')
        etype=$(echo "$entry" | grep -oE '"type":"[^"]*"' | sed 's/"type":"//;s/"$//')
        escore=$(echo "$entry" | grep -oE '"total":[0-9]+' | sed 's/"total"://')
        # Truncate file path
        if [[ ${#efile} -gt 48 ]]; then
            efile="...${efile: -45}"
        fi
        local scolor
        if [[ "${escore:-0}" -ge 80 ]]; then scolor="$G"
        elif [[ "${escore:-0}" -ge 60 ]]; then scolor="$Y"
        else scolor="$R"
        fi
        printf "  %-50s ${scolor}%3s${N}   %-6s\n" "$efile" "${escore:-0}" "$etype"
    done

    echo ""

    # Trend (if historical data exists)
    local scores_file="${SCRIPT_DIR:-${_om_script_dir}}/learning/quality/scores.jsonl"
    if [[ -f "$scores_file" ]]; then
        local prev_total
        prev_total=$(tail -1 "$scores_file" 2>/dev/null | grep -oE '"total":[0-9]+' | head -1 | sed 's/"total"://')
        if [[ -n "$prev_total" && "$prev_total" -gt 0 ]]; then
            local delta=$((${total:-0} - prev_total))
            local trend_symbol
            if [[ "$delta" -gt 0 ]]; then
                trend_symbol="${G}+${delta} (improving)${N}"
            elif [[ "$delta" -lt 0 ]]; then
                trend_symbol="${R}${delta} (regressing)${N}"
            else
                trend_symbol="${Y}+0 (stable)${N}"
            fi
            echo -e "  ${B}TREND${N}"
            echo -e "  Previous: ${prev_total}  Current: ${total:-0}  Delta: ${trend_symbol}"
            echo ""
        fi
    fi

    echo -e "${P}============================================================${N}"
    echo ""

    unset -f _om_score_color _om_bar _om_grade
    return 0
}

# =============================================================================
# 8. om_compare_versions(dir1, dir2) - Compare quality between versions
# =============================================================================
om_compare_versions() {
    local dir1="$1"
    local dir2="$2"

    if [[ ! -d "$dir1" ]]; then
        log_error "Directory 1 not found: ${dir1}"
        return 1
    fi
    if [[ ! -d "$dir2" ]]; then
        log_error "Directory 2 not found: ${dir2}"
        return 1
    fi

    [[ "$OM_INITIALIZED" != "true" ]] && om_init

    log_info "Comparing quality: ${dir1} vs ${dir2}"

    # Score both
    local report1 report2
    report1=$(om_score_project "$dir1" 2>/dev/null)
    report2=$(om_score_project "$dir2" 2>/dev/null)

    # Extract scores
    _om_extract_score() {
        local report="$1" field="$2"
        echo "$report" | grep "\"${field}\"" | head -1 | grep -oE '[0-9]+' | head -1
    }

    local t1 t2 c1 c2 co1 co2 s1 s2 se1 se2 p1 p2 a1 a2
    t1=$(_om_extract_score "$report1" "total")
    t2=$(_om_extract_score "$report2" "total")
    c1=$(_om_extract_score "$report1" "completeness")
    c2=$(_om_extract_score "$report2" "completeness")
    co1=$(_om_extract_score "$report1" "correctness")
    co2=$(_om_extract_score "$report2" "correctness")
    s1=$(_om_extract_score "$report1" "style")
    s2=$(_om_extract_score "$report2" "style")
    se1=$(_om_extract_score "$report1" "security")
    se2=$(_om_extract_score "$report2" "security")
    p1=$(_om_extract_score "$report1" "performance")
    p2=$(_om_extract_score "$report2" "performance")
    a1=$(_om_extract_score "$report1" "accessibility")
    a2=$(_om_extract_score "$report2" "accessibility")

    local fc1 fc2_count
    fc1=$(_om_extract_score "$report1" "file_count")
    fc2_count=$(_om_extract_score "$report2" "file_count")

    # Calculate deltas
    local dt=$((${t2:-0} - ${t1:-0}))
    local dc=$((${c2:-0} - ${c1:-0}))
    local dco=$((${co2:-0} - ${co1:-0}))
    local ds=$((${s2:-0} - ${s1:-0}))
    local dse=$((${se2:-0} - ${se1:-0}))
    local dp=$((${p2:-0} - ${p1:-0}))
    local da=$((${a2:-0} - ${a1:-0}))

    # Identify improvements and regressions
    local improvements="["
    local regressions="["
    local imp_first=true reg_first=true

    _om_check_axis() {
        local name="$1" old="$2" new="$3" delta="$4"
        if [[ "$delta" -gt 0 ]]; then
            [[ "$imp_first" == true ]] && imp_first=false || improvements+=","
            improvements+="{\"axis\":\"${name}\",\"old\":${old},\"new\":${new},\"delta\":+${delta}}"
        elif [[ "$delta" -lt 0 ]]; then
            [[ "$reg_first" == true ]] && reg_first=false || regressions+=","
            regressions+="{\"axis\":\"${name}\",\"old\":${old},\"new\":${new},\"delta\":${delta}}"
        fi
    }

    _om_check_axis "completeness"  "${c1:-0}"  "${c2:-0}"  "$dc"
    _om_check_axis "correctness"   "${co1:-0}" "${co2:-0}" "$dco"
    _om_check_axis "style"         "${s1:-0}"  "${s2:-0}"  "$ds"
    _om_check_axis "security"      "${se1:-0}" "${se2:-0}" "$dse"
    _om_check_axis "performance"   "${p1:-0}"  "${p2:-0}"  "$dp"
    _om_check_axis "accessibility" "${a1:-0}"  "${a2:-0}"  "$da"

    improvements+="]"
    regressions+="]"

    # Overall verdict
    local verdict="neutral"
    if [[ "$dt" -gt 5 ]]; then
        verdict="improved"
    elif [[ "$dt" -lt -5 ]]; then
        verdict="regressed"
    fi

    log_info "Comparison complete: delta=${dt} (${verdict})"

    cat <<EOF
{
  "version_a": {
    "dir": "$(echo "$dir1" | sed 's/"/\\"/g')",
    "files": ${fc1:-0},
    "total": ${t1:-0},
    "scores": {"completeness":${c1:-0},"correctness":${co1:-0},"style":${s1:-0},"security":${se1:-0},"performance":${p1:-0},"accessibility":${a1:-0}}
  },
  "version_b": {
    "dir": "$(echo "$dir2" | sed 's/"/\\"/g')",
    "files": ${fc2_count:-0},
    "total": ${t2:-0},
    "scores": {"completeness":${c2:-0},"correctness":${co2:-0},"style":${s2:-0},"security":${se2:-0},"performance":${p2:-0},"accessibility":${a2:-0}}
  },
  "delta": {
    "total": ${dt},
    "completeness": ${dc},
    "correctness": ${dco},
    "style": ${ds},
    "security": ${dse},
    "performance": ${dp},
    "accessibility": ${da}
  },
  "improvements": ${improvements},
  "regressions": ${regressions},
  "verdict": "${verdict}"
}
EOF
    unset -f _om_extract_score _om_check_axis
    return 0
}

# =============================================================================
# 9. om_get_enhancement_prompt(project_dir, focus_area) - Generate Claude prompt
# =============================================================================
om_get_enhancement_prompt() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local focus_area="${2:-auto}"

    [[ "$OM_INITIALIZED" != "true" ]] && om_init

    if [[ ! -d "$project_dir" ]]; then
        log_error "Project directory not found: ${project_dir}"
        return 1
    fi

    # Get quality gaps
    local gaps_report
    gaps_report=$(om_detect_quality_gaps "$project_dir" 2>/dev/null)

    # Get project score to identify weakest axis
    local score_report
    score_report=$(om_score_project "$project_dir" 2>/dev/null)

    # Find the weakest axis if auto
    if [[ "$focus_area" == "auto" ]]; then
        local min_score=101 min_axis=""
        for axis in completeness correctness style security performance accessibility; do
            local val
            val=$(echo "$score_report" | grep "\"${axis}\"" | head -1 | grep -oE '[0-9]+' | head -1)
            if [[ -n "$val" && "$val" -lt "$min_score" ]]; then
                min_score=$val
                min_axis=$axis
            fi
        done
        focus_area="${min_axis:-completeness}"
        log_info "Auto-detected weakest axis: ${focus_area} (score: ${min_score})"
    fi

    # Collect specific files and line numbers for the focus area
    local target_files=""
    local gap_details=""
    local gap_count=0

    # Extract gaps relevant to the focus area
    case "$focus_area" in
        completeness)
            local filter="incomplete|missing_handler|todo|stub"
            ;;
        correctness)
            local filter="broken_import|type_redefinition|missing_types|unhandled_parse"
            ;;
        style)
            local filter="naming|mixed_indent|trailing_ws"
            ;;
        security)
            local filter="missing_validation|hardcoded|injection|eval|innerHTML|cors"
            ;;
        performance)
            local filter="n_plus_one|pagination|sync_io|memoization|bundle"
            ;;
        accessibility)
            local filter="missing_alt|missing_role|unlabeled|keyboard|semantic|color_only"
            ;;
        *)
            local filter=".*"
            ;;
    esac

    # Parse gaps from the report
    while IFS= read -r gap_line; do
        [[ -z "$gap_line" ]] && continue
        local gap_file gap_msg gap_linenum
        gap_file=$(echo "$gap_line" | grep -oE '"file":"[^"]*"' | sed 's/"file":"//;s/"$//')
        gap_msg=$(echo "$gap_line" | grep -oE '"message":"[^"]*"' | sed 's/"message":"//;s/"$//')
        gap_linenum=$(echo "$gap_line" | grep -oE '"line":[0-9]+' | sed 's/"line"://')
        if [[ -n "$gap_file" ]]; then
            target_files="${target_files}\n- ${gap_file}:${gap_linenum:-0}: ${gap_msg}"
            gap_count=$((gap_count + 1))
        fi
    done < <(echo "$gaps_report" | tr '},{' '\n' | grep -iE "$filter" | head -20)

    # Also find specific files with low scores in the focus area
    local low_score_files=""
    local files
    files=$(_om_collect_files "$project_dir" 50)
    while IFS= read -r fpath; do
        [[ -z "$fpath" || ! -f "$fpath" ]] && continue
        local ftype
        ftype=$(_om_classify_file "$fpath")
        local result
        result=$(om_score_output "$fpath" "$ftype" "auto" 2>/dev/null)
        local axis_score
        axis_score=$(echo "$result" | grep "\"${focus_area}\"" | head -1 | grep -oE '[0-9]+' | head -1)
        if [[ -n "$axis_score" && "$axis_score" -lt 60 ]]; then
            local rel="${fpath#${project_dir}/}"
            local axis_issues
            axis_issues=$(echo "$result" | grep -A1 "\"${focus_area}\"" | tail -1 | grep -oE ':[^,}]*' | head -1 | sed 's/^://')
            low_score_files="${low_score_files}\n- ${rel} (score: ${axis_score}) issues: ${axis_issues}"
        fi
    done <<< "$files"

    # Build the enhancement prompt
    local overall_score
    overall_score=$(echo "$score_report" | grep '"total"' | head -1 | grep -oE '[0-9]+')
    local axis_score
    axis_score=$(echo "$score_report" | grep "\"${focus_area}\"" | head -1 | grep -oE '[0-9]+' | head -1)

    cat <<EOF
## Quality Enhancement Request

**Project**: ${project_dir}
**Current Score**: ${overall_score:-0}/100
**Focus Area**: ${focus_area} (current: ${axis_score:-0}/100)
**Target Score**: $(( ${axis_score:-0} + 20 > 100 ? 100 : ${axis_score:-0} + 20 ))/100

### Quality Gaps Found (${gap_count} issues):
$(echo -e "$target_files")

### Low-Scoring Files for ${focus_area}:
$(echo -e "$low_score_files")

### Instructions:
Please fix ALL the issues listed above, focusing on **${focus_area}**:

$(case "$focus_area" in
    completeness)
        echo "1. Remove all TODO/FIXME/HACK comments by implementing the actual logic
2. Replace all stub/placeholder implementations with real code
3. Fill in empty function bodies and catch blocks
4. Ensure every feature is fully implemented end-to-end"
        ;;
    correctness)
        echo "1. Fix all broken imports (ensure every import resolves to an existing file)
2. Remove unused imports
3. Fix type errors - replace 'any' with proper TypeScript types
4. Ensure bracket/brace matching is correct
5. Remove duplicate declarations"
        ;;
    style)
        echo "1. Standardize indentation (use spaces, not tabs)
2. Remove trailing whitespace
3. Break lines longer than 120 characters
4. Use consistent naming: camelCase for functions/variables, PascalCase for components/types
5. Add file-level documentation comments"
        ;;
    security)
        echo "1. Remove all hardcoded secrets/API keys (use environment variables)
2. Add Zod input validation to every API mutation endpoint
3. Remove eval() usage
4. Replace innerHTML with safe alternatives
5. Wrap request.json() in try-catch
6. Add CORS configuration (remove wildcard origins)"
        ;;
    performance)
        echo "1. Eliminate N+1 queries (move awaits outside loops, use batch queries)
2. Add useMemo/useCallback to expensive computations in React components
3. Replace synchronous file operations with async versions
4. Add pagination (take/skip) to all findMany queries
5. Use tree-shakeable imports (import specific functions, not entire libraries)"
        ;;
    accessibility)
        echo "1. Add alt text to all <img> elements
2. Replace clickable <div> elements with <button> or add role/tabIndex/onKeyDown
3. Add aria-label to all form inputs without visible labels
4. Use semantic HTML elements (nav, main, header, footer, section)
5. Add keyboard navigation handlers alongside onClick
6. Add sr-only text for color-only indicators"
        ;;
esac)

Return the complete fixed files using --- FILE: path --- markers.
EOF

    return 0
}

# =============================================================================
# 10. om_persist_scores(project_dir, scores) - Save scores for trending
# =============================================================================
om_persist_scores() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local scores="${2:-}"

    [[ "$OM_INITIALIZED" != "true" ]] && om_init

    local quality_dir="${SCRIPT_DIR:-${_om_script_dir}}/learning/quality"
    local scores_file="${quality_dir}/scores.jsonl"

    mkdir -p "$quality_dir" 2>/dev/null

    # If no scores provided, compute them
    if [[ -z "$scores" ]]; then
        log_info "No scores provided, computing..."
        scores=$(om_score_project "$project_dir" 2>/dev/null)
    fi

    # Extract individual scores
    local total comp corr sty sec perf a11y file_count
    total=$(echo "$scores" | grep '"total"' | head -1 | grep -oE '[0-9]+')
    comp=$(echo "$scores" | grep '"completeness"' | head -1 | grep -oE '[0-9]+')
    corr=$(echo "$scores" | grep '"correctness"' | head -1 | grep -oE '[0-9]+')
    sty=$(echo "$scores" | grep '"style"' | head -1 | grep -oE '[0-9]+')
    sec=$(echo "$scores" | grep '"security"' | head -1 | grep -oE '[0-9]+')
    perf=$(echo "$scores" | grep '"performance"' | head -1 | grep -oE '[0-9]+')
    a11y=$(echo "$scores" | grep '"accessibility"' | head -1 | grep -oE '[0-9]+')
    file_count=$(echo "$scores" | grep '"file_count"' | head -1 | grep -oE '[0-9]+')

    # Derive project name from directory
    local project_name
    project_name="$(basename "$project_dir")"

    # Build JSONL entry (one line)
    local ts
    ts="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
    local entry
    if declare -f json_object &>/dev/null; then
        entry=$(json_object \
            "timestamp=${ts}" \
            "project=${project_name}" \
            "dir=${project_dir}" \
            "version=${OM_VERSION}" \
            "file_count=${file_count:-0}" \
            "total=${total:-0}" \
            "completeness=${comp:-0}" \
            "correctness=${corr:-0}" \
            "style=${sty:-0}" \
            "security=${sec:-0}" \
            "performance=${perf:-0}" \
            "accessibility=${a11y:-0}")
    else
        entry="{\"timestamp\":\"${ts}\",\"project\":\"${project_name}\",\"dir\":\"$(echo "$project_dir" | sed 's/"/\\"/g')\",\"version\":\"${OM_VERSION}\",\"file_count\":${file_count:-0},\"total\":${total:-0},\"completeness\":${comp:-0},\"correctness\":${corr:-0},\"style\":${sty:-0},\"security\":${sec:-0},\"performance\":${perf:-0},\"accessibility\":${a11y:-0}}"
    fi

    # Append to JSONL file
    echo "$entry" >> "$scores_file"

    if [[ $? -eq 0 ]]; then
        _om_log PASS "Scores persisted to ${scores_file}"
    else
        log_error "Failed to persist scores to ${scores_file}"
        return 1
    fi

    # Show trend if we have history
    local history_count
    history_count=$(wc -l < "$scores_file" 2>/dev/null | tr -d ' ')

    if [[ "$history_count" -gt 1 ]]; then
        log_info "Score history: ${history_count} entries"

        # Show last 5 entries as trend
        local trend_data
        trend_data=$(tail -5 "$scores_file" 2>/dev/null)
        local trend_line=""
        while IFS= read -r hist_entry; do
            [[ -z "$hist_entry" ]] && continue
            local ht hts
            ht=$(echo "$hist_entry" | grep -oE '"total":[0-9]+' | head -1 | sed 's/"total"://')
            hts=$(echo "$hist_entry" | grep -oE '"timestamp":"[^"]*"' | sed 's/"timestamp":"//;s/"$//' | cut -c1-10)
            trend_line="${trend_line} ${hts}:${ht}"
        done <<< "$trend_data"

        if [[ -n "$trend_line" ]]; then
            log_info "Recent trend:${trend_line}"
        fi
    fi

    echo "$entry"
    return 0
}

# =============================================================================
# Summary / Report
# =============================================================================
om_report() {
    local B="${CLR_BOLD:-\033[1m}"
    local G="${CLR_GREEN:-\033[0;32m}"
    local N="${CLR_NC:-\033[0m}"

    echo -e "\n  ${B}=== Output Maximizer v${OM_VERSION} ===${N}"
    echo -e "  Files scored   : ${OM_TOTAL_FILES_SCORED}"
    echo -e "  Issues found   : ${OM_TOTAL_ISSUES_FOUND}"
    echo -e "  Enhancements   : ${OM_TOTAL_ENHANCEMENTS}"
    if [[ "$OM_TOTAL_FILES_SCORED" -gt 0 ]]; then
        echo -e "  Average score  : ${G}${OM_AVG_SCORE}/100${N}"
    fi
}

# =============================================================================
# Module registration hook (for chain.sh auto-discovery)
# =============================================================================
if declare -f _register_module &>/dev/null; then
    _register_module "output-maximizer" "$OM_VERSION" "om_init" "om_report"
fi
