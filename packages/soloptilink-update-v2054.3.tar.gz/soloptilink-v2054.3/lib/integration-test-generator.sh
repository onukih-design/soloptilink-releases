#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v337.0 - Integration Test Generator
# =============================================================================
# APIインテグレーションテスト、フィクスチャ、アサーション自動生成。
# Supertest/undici対応、DB統合テスト、認証フロー検証。
#
# Functions:
#   _itg_init()                  - Initialize
#   _itg_generate_api_tests()    - Generate API integration tests
#   _itg_generate_fixtures()     - Generate test fixtures & factories
#   _itg_generate_assertions()   - Generate custom assertion helpers
#   _itg_report() / _itg_score()
# =============================================================================

[[ -n "${_ITG_LOADED:-}" ]] && return 0; _ITG_LOADED=1

readonly _ITG_RED='\033[0;31m'
readonly _ITG_GREEN='\033[0;32m'
readonly _ITG_YELLOW='\033[0;33m'
readonly _ITG_CYAN='\033[0;36m'
readonly _ITG_NC='\033[0m'

declare -g ITG_VERSION="337.0"
ITG_GENERATED=0
ITG_ERRORS=0
ITG_FILES_WRITTEN=0
ITG_API_OK=false
ITG_FIXTURES_OK=false
ITG_ASSERTIONS_OK=false

_itg_init() {
    ITG_GENERATED=0; ITG_ERRORS=0; ITG_FILES_WRITTEN=0
    ITG_API_OK=false; ITG_FIXTURES_OK=false; ITG_ASSERTIONS_OK=false
    echo -e "  ${_ITG_GREEN}OK${_ITG_NC} Integration Test Generator v${ITG_VERSION}" >&2
    return 0
}

_itg_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { ITG_FILES_WRITTEN=$((ITG_FILES_WRITTEN + 1)); return 0; }
    ITG_ERRORS=$((ITG_ERRORS + 1)); return 1
}

_itg_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_ITG_CYAN}[integ-test]${_ITG_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_ITG_GREEN}[integ-test]${_ITG_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_ITG_YELLOW}[integ-test]${_ITG_NC} $msg" >&2 ;;
        error) echo -e "  ${_ITG_RED}[integ-test]${_ITG_NC} $msg" >&2 ;;
    esac
}

# =============================================================================
# Generate API Integration Tests
# =============================================================================
_itg_generate_api_tests() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local test_dir="${project_dir}/tests/integration"

    _itg_log info "Generating API integration tests..."

    # Scan for API routes
    local api_routes
    api_routes=$(find "$project_dir" -path "*/api/*" -name "route.ts" -not -path "*/node_modules/*" 2>/dev/null | head -20)
    local route_count
    route_count=$(echo "$api_routes" | grep -c . 2>/dev/null || echo 0)

    _itg_write_file "${test_dir}/api.test.ts" "$(cat <<'TYPESCRIPT'
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { createServer } from '../helpers/test-server';
import { seedTestData, cleanupTestData } from '../helpers/fixtures';

let baseUrl: string;
let authToken: string;

beforeAll(async () => {
  baseUrl = await createServer();
  await seedTestData();
  // Authenticate
  const res = await fetch(`${baseUrl}/api/v1/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email: 'admin@test.com', password: 'Test1234!' }),
  });
  const data = await res.json();
  authToken = data.token;
});

afterAll(async () => {
  await cleanupTestData();
});

function authedFetch(path: string, options: RequestInit = {}) {
  return fetch(`${baseUrl}${path}`, {
    ...options,
    headers: { ...options.headers as any, Authorization: `Bearer ${authToken}`, 'Content-Type': 'application/json' },
  });
}

describe('Authentication', () => {
  it('POST /api/v1/auth/login returns token with valid credentials', async () => {
    const res = await fetch(`${baseUrl}/api/v1/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'admin@test.com', password: 'Test1234!' }),
    });
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.token).toBeDefined();
  });

  it('POST /api/v1/auth/login returns 401 with invalid credentials', async () => {
    const res = await fetch(`${baseUrl}/api/v1/auth/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'admin@test.com', password: 'wrong' }),
    });
    expect(res.status).toBe(401);
  });

  it('Protected routes return 401 without token', async () => {
    const res = await fetch(`${baseUrl}/api/v1/users`);
    expect(res.status).toBe(401);
  });
});

describe('CRUD Operations', () => {
  let createdId: string;

  it('GET /api/v1/users returns list', async () => {
    const res = await authedFetch('/api/v1/users');
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(Array.isArray(body.data || body)).toBe(true);
  });

  it('POST /api/v1/users creates resource', async () => {
    const res = await authedFetch('/api/v1/users', {
      method: 'POST',
      body: JSON.stringify({ email: 'new@test.com', name: 'New User', role: 'user' }),
    });
    expect(res.status).toBe(201);
    const body = await res.json();
    createdId = body.id;
    expect(createdId).toBeDefined();
  });

  it('GET /api/v1/users/:id returns single resource', async () => {
    const res = await authedFetch(`/api/v1/users/${createdId}`);
    expect(res.status).toBe(200);
    const body = await res.json();
    expect(body.email).toBe('new@test.com');
  });

  it('PUT /api/v1/users/:id updates resource', async () => {
    const res = await authedFetch(`/api/v1/users/${createdId}`, {
      method: 'PUT',
      body: JSON.stringify({ name: 'Updated User' }),
    });
    expect(res.status).toBe(200);
  });

  it('DELETE /api/v1/users/:id removes resource', async () => {
    const res = await authedFetch(`/api/v1/users/${createdId}`, { method: 'DELETE' });
    expect(res.status).toBe(200);
    const check = await authedFetch(`/api/v1/users/${createdId}`);
    expect(check.status).toBe(404);
  });
});

describe('Validation', () => {
  it('rejects invalid email format', async () => {
    const res = await authedFetch('/api/v1/users', {
      method: 'POST',
      body: JSON.stringify({ email: 'not-an-email', name: 'Test' }),
    });
    expect(res.status).toBe(400);
  });

  it('rejects empty required fields', async () => {
    const res = await authedFetch('/api/v1/users', {
      method: 'POST',
      body: JSON.stringify({}),
    });
    expect(res.status).toBe(400);
  });
});
TYPESCRIPT
)"

    _itg_log ok "API integration tests generated (scanned ${route_count} routes)"
    ITG_API_OK=true
    ITG_GENERATED=$((ITG_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate Test Fixtures
# =============================================================================
_itg_generate_fixtures() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local helpers_dir="${project_dir}/tests/helpers"

    _itg_log info "Generating test fixtures..."

    _itg_write_file "${helpers_dir}/fixtures.ts" "$(cat <<'TYPESCRIPT'
import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

export async function seedTestData() {
  const hashedPassword = await bcrypt.hash('Test1234!', 10);

  await prisma.user.upsert({
    where: { email: 'admin@test.com' },
    update: {},
    create: { email: 'admin@test.com', name: 'Admin', password: hashedPassword, role: 'admin' },
  });

  await prisma.user.upsert({
    where: { email: 'user@test.com' },
    update: {},
    create: { email: 'user@test.com', name: 'User', password: hashedPassword, role: 'user' },
  });
}

export async function cleanupTestData() {
  const tables = ['task', 'project', 'session', 'user'];
  for (const table of tables) {
    await prisma.$executeRawUnsafe(`DELETE FROM "${table}" WHERE email LIKE '%@test.com' OR TRUE`).catch(() => {});
  }
  await prisma.$disconnect();
}

export function createTestUser(overrides = {}) {
  return { email: `test-${Date.now()}@test.com`, name: 'Test', role: 'user', ...overrides };
}
TYPESCRIPT
)"

    _itg_write_file "${helpers_dir}/test-server.ts" "$(cat <<'TYPESCRIPT'
export async function createServer(): Promise<string> {
  const port = 3000 + Math.floor(Math.random() * 1000);
  return `http://localhost:${port}`;
}
TYPESCRIPT
)"

    _itg_log ok "Test fixtures generated"
    ITG_FIXTURES_OK=true
    ITG_GENERATED=$((ITG_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate Custom Assertions
# =============================================================================
_itg_generate_assertions() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _itg_log info "Generating custom assertion helpers..."

    _itg_write_file "${project_dir}/tests/helpers/assertions.ts" "$(cat <<'TYPESCRIPT'
import { expect } from 'vitest';

export function expectPaginated(body: any) {
  expect(body).toHaveProperty('data');
  expect(body).toHaveProperty('total');
  expect(body).toHaveProperty('page');
  expect(Array.isArray(body.data)).toBe(true);
}

export function expectError(body: any, statusCode: number) {
  expect(body).toHaveProperty('error');
  expect(body.statusCode || body.status).toBe(statusCode);
}

export function expectValidDate(value: string) {
  expect(new Date(value).toISOString()).toBe(value);
}

export function expectUUID(value: string) {
  expect(value).toMatch(/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i);
}

export async function expectStatus(res: Response, expected: number) {
  expect(res.status).toBe(expected);
  return res.json();
}
TYPESCRIPT
)"

    _itg_log ok "Custom assertions generated"
    ITG_ASSERTIONS_OK=true
    ITG_GENERATED=$((ITG_GENERATED + 1))
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_itg_report() {
    echo -e "\n  ${_ITG_CYAN}=== Integration Test Generator v${ITG_VERSION} ===${_ITG_NC}"
    echo -e "  Generated: ${ITG_GENERATED} | Files: ${ITG_FILES_WRITTEN} | Errors: ${ITG_ERRORS}"
    echo -e "  API Tests: $( ${ITG_API_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Fixtures: $( ${ITG_FIXTURES_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Assertions: $( ${ITG_ASSERTIONS_OK} && echo 'OK' || echo 'SKIP')"
}

_itg_score() {
    local score=50
    ${ITG_API_OK} && score=$((score + 20))
    ${ITG_FIXTURES_OK} && score=$((score + 15))
    ${ITG_ASSERTIONS_OK} && score=$((score + 10))
    [[ ${ITG_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "integration-test-generator" --version "337.0" \
        --description "インテグレーションテスト自動生成 API/DB/認証 (v337)" \
        --init "_itg_init" --report "_itg_report" --score "_itg_score" \
        --enable-var "ENABLE_INTEG_TEST_GEN" --cli-flags "--integ-test-gen:--no-integ-test-gen"
fi

# v2003.1: source時のexit codeを確実に0にする
true
