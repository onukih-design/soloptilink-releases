#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v14.0 - Coverage Gate
# =============================================================================
# Blocks deployment if test coverage falls below configurable thresholds.
# Reads coverage data from test-runner.sh (TR_COVERAGE_*) variables.
# =============================================================================

[[ -n "${_COVERAGE_GATE_LOADED:-}" ]] && return 0
_COVERAGE_GATE_LOADED=1

# ============================================================
# State
# ============================================================
declare -g CG_THRESHOLD_LINE=70
declare -g CG_THRESHOLD_BRANCH=50
declare -g CG_THRESHOLD_FUNC=60
declare -g CG_THRESHOLD_STMT=70
declare -g CG_RESULT_LINE=0
declare -g CG_RESULT_BRANCH=0
declare -g CG_RESULT_FUNC=0
declare -g CG_RESULT_STMT=0
declare -g CG_GATE_PASSED=1     # 1=passed, 0=blocked
declare -g CG_FAILURES=""

# ============================================================
# Internal logger
# ============================================================
_cg_log() {
    local level="$1" msg="$2"
    echo -e "  ${CYAN:-}[COVERAGE-GATE]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize with threshold configuration
# ============================================================
covgate_init() {
    local thresholds="${1:-}"

    # Parse thresholds if provided
    if [[ -n "$thresholds" && "$thresholds" =~ ^[0-9]+$ ]]; then
        # Simple numeric threshold applies to all
        CG_THRESHOLD_LINE="$thresholds"
        CG_THRESHOLD_BRANCH="$thresholds"
        CG_THRESHOLD_FUNC="$thresholds"
        CG_THRESHOLD_STMT="$thresholds"
    elif [[ -n "$thresholds" ]] && command -v python3 &>/dev/null; then
        # JSON thresholds (pass via argv to avoid injection)
        local _cg_parsed
        _cg_parsed=$(python3 -c "
import json, sys
try:
    d = json.loads(sys.argv[1])
    print(f\"{d.get('line',70)} {d.get('branch',50)} {d.get('func',60)} {d.get('stmt',70)}\")
except: print('70 50 60 70')
" "$thresholds" 2>/dev/null || echo "70 50 60 70")
        read -r CG_THRESHOLD_LINE CG_THRESHOLD_BRANCH CG_THRESHOLD_FUNC CG_THRESHOLD_STMT <<< "$_cg_parsed"
    fi

    CG_GATE_PASSED=1
    CG_FAILURES=""
    _cg_log "INFO" "カバレッジゲート初期化: line=${CG_THRESHOLD_LINE}% branch=${CG_THRESHOLD_BRANCH}% func=${CG_THRESHOLD_FUNC}% stmt=${CG_THRESHOLD_STMT}%"
}

# ============================================================
# Check coverage against thresholds
# ============================================================
covgate_check() {
    # Read coverage from test-runner.sh globals
    CG_RESULT_LINE="${TR_COVERAGE_LINE:-0}"
    CG_RESULT_BRANCH="${TR_COVERAGE_BRANCH:-0}"
    CG_RESULT_FUNC="${TR_COVERAGE_FUNC:-0}"
    CG_RESULT_STMT="${TR_COVERAGE_STMT:-0}"

    # Clean up values (remove % sign, non-numeric chars)
    CG_RESULT_LINE=$(echo "$CG_RESULT_LINE" | grep -oE '[0-9]+' | head -1)
    CG_RESULT_BRANCH=$(echo "$CG_RESULT_BRANCH" | grep -oE '[0-9]+' | head -1)
    CG_RESULT_FUNC=$(echo "$CG_RESULT_FUNC" | grep -oE '[0-9]+' | head -1)
    CG_RESULT_STMT=$(echo "$CG_RESULT_STMT" | grep -oE '[0-9]+' | head -1)

    CG_RESULT_LINE="${CG_RESULT_LINE:-0}"
    CG_RESULT_BRANCH="${CG_RESULT_BRANCH:-0}"
    CG_RESULT_FUNC="${CG_RESULT_FUNC:-0}"
    CG_RESULT_STMT="${CG_RESULT_STMT:-0}"

    CG_GATE_PASSED=1
    CG_FAILURES=""

    # Check each metric
    if [[ "$CG_RESULT_LINE" -lt "$CG_THRESHOLD_LINE" ]]; then
        CG_GATE_PASSED=0
        CG_FAILURES+="line(${CG_RESULT_LINE}%<${CG_THRESHOLD_LINE}%) "
    fi
    if [[ "$CG_RESULT_BRANCH" -lt "$CG_THRESHOLD_BRANCH" ]]; then
        CG_GATE_PASSED=0
        CG_FAILURES+="branch(${CG_RESULT_BRANCH}%<${CG_THRESHOLD_BRANCH}%) "
    fi
    if [[ "$CG_RESULT_FUNC" -lt "$CG_THRESHOLD_FUNC" ]]; then
        CG_GATE_PASSED=0
        CG_FAILURES+="func(${CG_RESULT_FUNC}%<${CG_THRESHOLD_FUNC}%) "
    fi
    if [[ "$CG_RESULT_STMT" -lt "$CG_THRESHOLD_STMT" ]]; then
        CG_GATE_PASSED=0
        CG_FAILURES+="stmt(${CG_RESULT_STMT}%<${CG_THRESHOLD_STMT}%) "
    fi

    return $((1 - CG_GATE_PASSED))  # 0=success, 1=failure (shell convention)
}

# ============================================================
# Print coverage report
# ============================================================
covgate_report() {
    echo ""
    echo -e "  ${BOLD:-}${CYAN:-}[Coverage Gate] v14.0${NC:-}"
    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    printf "  %-10s  %8s  %10s  %s\n" "Metric" "Current" "Threshold" "Status"
    echo -e "  ──────────  ────────  ──────────  ──────"

    _cg_print_row "Line"     "$CG_RESULT_LINE"   "$CG_THRESHOLD_LINE"
    _cg_print_row "Branch"   "$CG_RESULT_BRANCH" "$CG_THRESHOLD_BRANCH"
    _cg_print_row "Function" "$CG_RESULT_FUNC"   "$CG_THRESHOLD_FUNC"
    _cg_print_row "Statement" "$CG_RESULT_STMT"  "$CG_THRESHOLD_STMT"

    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"

    if [[ "$CG_GATE_PASSED" -eq 1 ]]; then
        echo -e "  ${GREEN:-}✅ カバレッジゲート: PASS - デプロイ許可${NC:-}"
    else
        echo -e "  ${RED:-}❌ カバレッジゲート: BLOCKED - デプロイ不可${NC:-}"
        echo -e "  ${RED:-}   失敗項目: ${CG_FAILURES}${NC:-}"
    fi
    echo ""
}

# Internal: print a single coverage row
_cg_print_row() {
    local label="$1" current="$2" threshold="$3"
    local status_icon="${GREEN:-}✅${NC:-}"
    if [[ "$current" -lt "$threshold" ]]; then
        status_icon="${RED:-}❌${NC:-}"
    fi
    printf "  %-10s  %6s%%  %8s%%  %b\n" "$label" "$current" "$threshold" "$status_icon"
}

# ============================================================
# Should deploy be blocked? (returns 0=block, 1=OK)
# ============================================================
covgate_should_block_deploy() {
    [[ "$CG_GATE_PASSED" -eq 1 ]] && return 1  # OK to deploy
    return 0  # Block deploy
}

# ============================================================
# Export coverage gate result as JSON
# ============================================================
covgate_export_json() {
    echo "{"
    echo "  \"line\": {\"current\": ${CG_RESULT_LINE}, \"threshold\": ${CG_THRESHOLD_LINE}},"
    echo "  \"branch\": {\"current\": ${CG_RESULT_BRANCH}, \"threshold\": ${CG_THRESHOLD_BRANCH}},"
    echo "  \"function\": {\"current\": ${CG_RESULT_FUNC}, \"threshold\": ${CG_THRESHOLD_FUNC}},"
    echo "  \"statement\": {\"current\": ${CG_RESULT_STMT}, \"threshold\": ${CG_THRESHOLD_STMT}},"
    echo "  \"gate_passed\": $([ "$CG_GATE_PASSED" -eq 1 ] && echo "true" || echo "false"),"
    echo "  \"failures\": \"${CG_FAILURES}\""
    echo "}"
}
