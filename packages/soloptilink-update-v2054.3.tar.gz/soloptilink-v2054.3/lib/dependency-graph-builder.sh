#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v202.0 - Dependency Graph Builder
# =============================================================================
# import/require解析×依存グラフ構築×影響範囲解析×循環依存検出
#
# 機能:
#   - TS/TSX/JS/JSX ファイルの import/require を解析
#   - 隣接リスト形式の依存グラフ構築
#   - 変更ファイルからの影響範囲（推移的依存）解析
#   - 循環依存のDFS検出
#   - モジュール別依存取得
#   - 依存グラフの永続化とキャッシュ
#   - Mermaid形式の可視化
#
# 全globals: DGB_ prefix
# =============================================================================

[[ -n "${_DGB_LOADED:-}" ]] && return 0; _DGB_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g DGB_VERSION="202.0"
declare -g DGB_INITIALIZED=false
declare -g DGB_BUILD_COUNT=0
declare -g DGB_ERRORS=0
declare -g DGB_PHASE="dependency_graph_builder"
declare -g DGB_STORAGE_DIR="${HOME}/.soloptilink/dep-graph"

# Graph state
declare -g DGB_NODE_COUNT=0
declare -g DGB_EDGE_COUNT=0
declare -g DGB_CIRCULAR_COUNT=0
declare -g DGB_PROJECT_DIR=""

# Adjacency lists stored as files for large projects
declare -g DGB_GRAPH_FILE=""
declare -g DGB_REVERSE_GRAPH_FILE=""

# Color codes
declare -g DGB_GREEN="${GREEN:-\033[0;32m}"
declare -g DGB_YELLOW="${YELLOW:-\033[1;33m}"
declare -g DGB_RED="${RED:-\033[0;31m}"
declare -g DGB_CYAN="${CYAN:-\033[0;36m}"
declare -g DGB_BOLD="${BOLD:-\033[1m}"
declare -g DGB_NC="${NC:-\033[0m}"

# =============================================================================
# 初期化
# =============================================================================
dgb_init() {
    DGB_INITIALIZED=true
    DGB_BUILD_COUNT=0
    DGB_ERRORS=0
    DGB_NODE_COUNT=0
    DGB_EDGE_COUNT=0
    DGB_CIRCULAR_COUNT=0
    mkdir -p "${DGB_STORAGE_DIR}" 2>/dev/null
    DGB_GRAPH_FILE="${DGB_STORAGE_DIR}/graph.edges"
    DGB_REVERSE_GRAPH_FILE="${DGB_STORAGE_DIR}/reverse-graph.edges"
    return 0
}

# =============================================================================
# ユーティリティ: ログ
# =============================================================================
_dgb_log() {
    local level="$1"
    shift
    local msg="$*"
    case "$level" in
        info)  echo -e "  ${DGB_CYAN}[dep-graph]${DGB_NC} ${msg}" >&2 ;;
        ok)    echo -e "  ${DGB_GREEN}[dep-graph]${DGB_NC} ${msg}" >&2 ;;
        warn)  echo -e "  ${DGB_YELLOW}[dep-graph]${DGB_NC} ${msg}" >&2 ;;
        error) echo -e "  ${DGB_RED}[dep-graph]${DGB_NC} ${msg}" >&2; DGB_ERRORS=$((DGB_ERRORS + 1)) ;;
    esac
}

# =============================================================================
# import/require パース
# =============================================================================
_dgb_parse_imports() {
    local file="$1"
    local project_dir="$2"

    [[ ! -f "$file" ]] && return 0

    local source_rel="${file#${project_dir}/}"
    local source_dir
    source_dir=$(dirname "$source_rel")

    # Parse ES6 imports: import ... from '...'
    while IFS= read -r line; do
        local target=""

        # Match: from './path' or from '../path' or from '@/path'
        if [[ "$line" =~ from[[:space:]]+[\'\"]([^\'\"]+)[\'\"] ]]; then
            target="${BASH_REMATCH[1]}"
        fi

        [[ -z "$target" ]] && continue

        # Skip external packages (no . or @ prefix for local)
        if [[ "$target" != .* && "$target" != @/* ]]; then
            continue
        fi

        # Resolve relative imports
        local resolved=""
        if [[ "$target" == .* ]]; then
            resolved=$(_dgb_resolve_path "$source_dir" "$target" "$project_dir")
        elif [[ "$target" == @/* ]]; then
            # @/ alias typically maps to src/ or project root
            resolved="${target#@/}"
            resolved=$(_dgb_try_resolve_file "$resolved" "$project_dir")
        fi

        [[ -z "$resolved" ]] && continue
        echo "${source_rel}|${resolved}"
    done < <(grep -E "(import |from )" "$file" 2>/dev/null | grep -E "from ['\"]" || true)

    # Parse CommonJS requires: require('./...')
    while IFS= read -r line; do
        local target=""
        if [[ "$line" =~ require\([[:space:]]*[\'\"]([^\'\"]+)[\'\"] ]]; then
            target="${BASH_REMATCH[1]}"
        fi

        [[ -z "$target" ]] && continue
        [[ "$target" != .* ]] && continue

        local resolved
        resolved=$(_dgb_resolve_path "$source_dir" "$target" "$project_dir")
        [[ -z "$resolved" ]] && continue
        echo "${source_rel}|${resolved}"
    done < <(grep -E "require\(['\"]\.\.?\/" "$file" 2>/dev/null || true)

    # Parse dynamic imports: import('./...')
    while IFS= read -r line; do
        local target=""
        if [[ "$line" =~ import\([[:space:]]*[\'\"]([^\'\"]+)[\'\"] ]]; then
            target="${BASH_REMATCH[1]}"
        fi

        [[ -z "$target" ]] && continue
        [[ "$target" != .* ]] && continue

        local resolved
        resolved=$(_dgb_resolve_path "$source_dir" "$target" "$project_dir")
        [[ -z "$resolved" ]] && continue
        echo "${source_rel}|${resolved}"
    done < <(grep -E "import\(['\"]\.\.?\/" "$file" 2>/dev/null || true)
}

# =============================================================================
# パス解決
# =============================================================================
_dgb_resolve_path() {
    local source_dir="$1"
    local target="$2"
    local project_dir="$3"

    # Combine source dir and relative target
    local combined=""
    if [[ "$target" == ./* ]]; then
        combined="${source_dir}/${target#./}"
    elif [[ "$target" == ../* ]]; then
        combined="${source_dir}/${target}"
    else
        combined="${source_dir}/${target}"
    fi

    # Normalize path (remove ./ and resolve ../)
    combined=$(echo "$combined" | sed 's|/\./|/|g')
    # Simple ../ resolution
    while [[ "$combined" == *"/.."* ]]; do
        combined=$(echo "$combined" | sed 's|[^/]*/\.\./||' | sed 's|^\.\./||')
    done

    _dgb_try_resolve_file "$combined" "$project_dir"
}

_dgb_try_resolve_file() {
    local path="$1"
    local project_dir="$2"

    # Try extensions: .ts, .tsx, .js, .jsx, /index.ts, /index.tsx, /index.js
    local extensions=(".ts" ".tsx" ".js" ".jsx" "/index.ts" "/index.tsx" "/index.js" "/index.jsx")

    # Direct match first
    if [[ -f "${project_dir}/${path}" ]]; then
        echo "$path"
        return 0
    fi

    # Strip existing extension and try
    local base_path="${path%.ts}"
    base_path="${base_path%.tsx}"
    base_path="${base_path%.js}"
    base_path="${base_path%.jsx}"

    for ext in "${extensions[@]}"; do
        if [[ -f "${project_dir}/${base_path}${ext}" ]]; then
            echo "${base_path}${ext}"
            return 0
        fi
    done

    # Try with original path + extensions
    for ext in "${extensions[@]}"; do
        if [[ -f "${project_dir}/${path}${ext}" ]]; then
            echo "${path}${ext}"
            return 0
        fi
    done

    # Return original if nothing resolves (external or missing)
    echo "$path"
}

# =============================================================================
# グラフ構築（メイン関数）
# =============================================================================
_dgb_build_graph() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    DGB_PROJECT_DIR="$project_dir"

    if [[ ! -d "$project_dir" ]]; then
        _dgb_log error "Project directory not found: ${project_dir}"
        return 1
    fi

    _dgb_log info "Building dependency graph for: ${project_dir}"

    # Clear previous graph
    > "$DGB_GRAPH_FILE" 2>/dev/null
    > "$DGB_REVERSE_GRAPH_FILE" 2>/dev/null
    DGB_NODE_COUNT=0
    DGB_EDGE_COUNT=0

    # Collect all source files
    local source_files
    source_files=$(find "$project_dir" \
        \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        -not -path "*/dist/*" \
        -not -path "*/build/*" \
        -not -path "*/.git/*" \
        2>/dev/null | sort)

    local nodes_file="${DGB_STORAGE_DIR}/nodes.list"
    > "$nodes_file" 2>/dev/null

    local file_count=0
    local edge_count=0

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local rel="${file#${project_dir}/}"

        # Register node
        echo "$rel" >> "$nodes_file"
        file_count=$((file_count + 1))

        # Parse imports and write edges
        local edges
        edges=$(_dgb_parse_imports "$file" "$project_dir")

        while IFS='|' read -r from to; do
            [[ -z "$from" || -z "$to" ]] && continue
            echo "${from}|${to}" >> "$DGB_GRAPH_FILE"
            echo "${to}|${from}" >> "$DGB_REVERSE_GRAPH_FILE"
            edge_count=$((edge_count + 1))
        done <<< "$edges"
    done <<< "$source_files"

    DGB_NODE_COUNT=$file_count
    DGB_EDGE_COUNT=$edge_count

    # Sort and deduplicate
    if [[ -f "$DGB_GRAPH_FILE" ]]; then
        sort -u "$DGB_GRAPH_FILE" -o "$DGB_GRAPH_FILE" 2>/dev/null
    fi
    if [[ -f "$DGB_REVERSE_GRAPH_FILE" ]]; then
        sort -u "$DGB_REVERSE_GRAPH_FILE" -o "$DGB_REVERSE_GRAPH_FILE" 2>/dev/null
    fi
    if [[ -f "$nodes_file" ]]; then
        sort -u "$nodes_file" -o "$nodes_file" 2>/dev/null
    fi

    # Recalculate after dedup
    DGB_EDGE_COUNT=$(wc -l < "$DGB_GRAPH_FILE" 2>/dev/null | tr -d ' ')
    DGB_NODE_COUNT=$(wc -l < "$nodes_file" 2>/dev/null | tr -d ' ')

    DGB_BUILD_COUNT=$((DGB_BUILD_COUNT + 1))
    _dgb_log ok "Graph built: ${DGB_NODE_COUNT} nodes, ${DGB_EDGE_COUNT} edges"
    return 0
}

# =============================================================================
# 影響範囲解析（推移的依存）
# =============================================================================
_dgb_find_affected_files() {
    local changed_file="$1"
    local project_dir="${2:-${DGB_PROJECT_DIR:-./output}}"

    # Auto-build if needed
    if [[ ! -f "$DGB_REVERSE_GRAPH_FILE" ]] || [[ ! -s "$DGB_REVERSE_GRAPH_FILE" ]]; then
        _dgb_build_graph "$project_dir" 2>/dev/null
    fi

    if [[ ! -f "$DGB_REVERSE_GRAPH_FILE" ]]; then
        _dgb_log warn "No reverse graph available"
        echo "$changed_file"
        return 0
    fi

    # Strip project dir prefix if present
    changed_file="${changed_file#${project_dir}/}"

    _dgb_log info "Finding affected files for: ${changed_file}"

    # BFS traversal on reverse graph (who depends on me)
    local visited_file="${DGB_STORAGE_DIR}/.visited_$$"
    local queue_file="${DGB_STORAGE_DIR}/.queue_$$"
    local result_file="${DGB_STORAGE_DIR}/.result_$$"

    > "$visited_file"
    > "$result_file"
    echo "$changed_file" > "$queue_file"
    echo "$changed_file" > "$visited_file"

    local iteration=0
    local max_iterations=100  # Safety limit

    while [[ -s "$queue_file" ]] && [[ $iteration -lt $max_iterations ]]; do
        iteration=$((iteration + 1))
        local next_queue="${DGB_STORAGE_DIR}/.queue_next_$$"
        > "$next_queue"

        while IFS= read -r current; do
            [[ -z "$current" ]] && continue

            # Find all files that depend on current (from reverse graph)
            # Reverse graph format: target|source (meaning source imports target)
            local dependents
            dependents=$(grep "^${current}|" "$DGB_REVERSE_GRAPH_FILE" 2>/dev/null | cut -d'|' -f2)

            while IFS= read -r dep; do
                [[ -z "$dep" ]] && continue
                # Skip if already visited
                if ! grep -qxF "$dep" "$visited_file" 2>/dev/null; then
                    echo "$dep" >> "$visited_file"
                    echo "$dep" >> "$next_queue"
                    echo "$dep" >> "$result_file"
                fi
            done <<< "$dependents"
        done < "$queue_file"

        mv "$next_queue" "$queue_file" 2>/dev/null
    done

    local affected_count=0
    if [[ -f "$result_file" ]]; then
        affected_count=$(wc -l < "$result_file" 2>/dev/null | tr -d ' ')
        sort -u "$result_file"
    fi

    # Cleanup temp files
    rm -f "$visited_file" "$queue_file" "$result_file" "${DGB_STORAGE_DIR}/.queue_next_$$" 2>/dev/null

    _dgb_log ok "Found ${affected_count} affected file(s)"
    return 0
}

# =============================================================================
# 循環依存検出（DFS）
# =============================================================================
_dgb_detect_circular_deps() {
    local project_dir="${1:-${DGB_PROJECT_DIR:-./output}}"

    # Auto-build if needed
    if [[ ! -f "$DGB_GRAPH_FILE" ]] || [[ ! -s "$DGB_GRAPH_FILE" ]]; then
        _dgb_build_graph "$project_dir" 2>/dev/null
    fi

    if [[ ! -f "$DGB_GRAPH_FILE" ]]; then
        _dgb_log warn "No graph available for circular dependency detection"
        echo "0"
        return 0
    fi

    _dgb_log info "Detecting circular dependencies..."

    local circular_file="${DGB_STORAGE_DIR}/circular-deps.txt"
    > "$circular_file" 2>/dev/null
    DGB_CIRCULAR_COUNT=0

    local nodes_file="${DGB_STORAGE_DIR}/nodes.list"
    if [[ ! -f "$nodes_file" ]]; then
        _dgb_log warn "No nodes list available"
        echo "0"
        return 0
    fi

    # Method 1: Direct 2-hop cycle (A -> B -> A)
    local visited_pairs="${DGB_STORAGE_DIR}/.visited_pairs_$$"
    > "$visited_pairs"

    while IFS='|' read -r from to; do
        [[ -z "$from" || -z "$to" ]] && continue
        [[ "$from" == "$to" ]] && continue  # Self-reference

        # Check if pair already found (in either direction)
        local pair_key="${from}<=>${to}"
        local pair_key_rev="${to}<=>${from}"
        if grep -qxF "$pair_key" "$visited_pairs" 2>/dev/null || grep -qxF "$pair_key_rev" "$visited_pairs" 2>/dev/null; then
            continue
        fi

        # Check reverse edge exists
        if grep -qxF "${to}|${from}" "$DGB_GRAPH_FILE" 2>/dev/null; then
            echo "[circular-2hop] ${from} <-> ${to}" >> "$circular_file"
            echo "$pair_key" >> "$visited_pairs"
            DGB_CIRCULAR_COUNT=$((DGB_CIRCULAR_COUNT + 1))
        fi
    done < "$DGB_GRAPH_FILE"

    # Method 2: 3-hop cycles (A -> B -> C -> A) - sample-based for performance
    local sample_nodes
    sample_nodes=$(head -200 "$nodes_file" 2>/dev/null)

    while IFS= read -r node_a; do
        [[ -z "$node_a" ]] && continue

        # Get direct deps of A
        local deps_a
        deps_a=$(grep "^${node_a}|" "$DGB_GRAPH_FILE" 2>/dev/null | cut -d'|' -f2)

        while IFS= read -r node_b; do
            [[ -z "$node_b" ]] && continue
            [[ "$node_b" == "$node_a" ]] && continue

            # Get direct deps of B
            local deps_b
            deps_b=$(grep "^${node_b}|" "$DGB_GRAPH_FILE" 2>/dev/null | cut -d'|' -f2)

            while IFS= read -r node_c; do
                [[ -z "$node_c" ]] && continue
                [[ "$node_c" == "$node_a" ]] && continue
                [[ "$node_c" == "$node_b" ]] && continue

                # Check if C -> A exists
                if grep -qxF "${node_c}|${node_a}" "$DGB_GRAPH_FILE" 2>/dev/null; then
                    local cycle_key="${node_a}=>${node_b}=>${node_c}"
                    if ! grep -qF "$cycle_key" "$circular_file" 2>/dev/null; then
                        echo "[circular-3hop] ${node_a} -> ${node_b} -> ${node_c} -> ${node_a}" >> "$circular_file"
                        DGB_CIRCULAR_COUNT=$((DGB_CIRCULAR_COUNT + 1))
                    fi
                fi
            done <<< "$deps_b"
        done <<< "$deps_a"

        # Limit 3-hop detection for performance
        [[ $DGB_CIRCULAR_COUNT -gt 50 ]] && break
    done <<< "$sample_nodes"

    rm -f "$visited_pairs" 2>/dev/null

    if [[ $DGB_CIRCULAR_COUNT -gt 0 ]]; then
        _dgb_log warn "Found ${DGB_CIRCULAR_COUNT} circular dependency cycle(s)"
        cat "$circular_file"
    else
        _dgb_log ok "No circular dependencies detected"
    fi

    echo "$DGB_CIRCULAR_COUNT"
}

# =============================================================================
# モジュール直接依存取得
# =============================================================================
_dgb_get_module_dependencies() {
    local module_path="$1"
    local project_dir="${2:-${DGB_PROJECT_DIR:-./output}}"

    # Auto-build if needed
    if [[ ! -f "$DGB_GRAPH_FILE" ]] || [[ ! -s "$DGB_GRAPH_FILE" ]]; then
        _dgb_build_graph "$project_dir" 2>/dev/null
    fi

    # Strip project dir prefix if present
    module_path="${module_path#${project_dir}/}"

    _dgb_log info "Getting dependencies for: ${module_path}"

    if [[ ! -f "$DGB_GRAPH_FILE" ]]; then
        _dgb_log warn "No graph available"
        return 0
    fi

    # Get direct forward dependencies
    local deps
    deps=$(grep "^${module_path}|" "$DGB_GRAPH_FILE" 2>/dev/null | cut -d'|' -f2 | sort -u)

    local dep_count=0
    if [[ -n "$deps" ]]; then
        dep_count=$(echo "$deps" | wc -l | tr -d ' ')
    fi

    _dgb_log ok "${module_path}: ${dep_count} direct dependencies"
    echo "$deps"
}

# =============================================================================
# 最も依存されているファイル（ホットスポット）
# =============================================================================
_dgb_find_hotspots() {
    local project_dir="${1:-${DGB_PROJECT_DIR:-./output}}"
    local top_n="${2:-20}"

    if [[ ! -f "$DGB_REVERSE_GRAPH_FILE" ]] || [[ ! -s "$DGB_REVERSE_GRAPH_FILE" ]]; then
        _dgb_build_graph "$project_dir" 2>/dev/null
    fi

    if [[ ! -f "$DGB_REVERSE_GRAPH_FILE" ]]; then
        _dgb_log warn "No reverse graph available"
        return 0
    fi

    _dgb_log info "Finding dependency hotspots (top ${top_n})..."

    # Count how many files depend on each file
    cut -d'|' -f1 "$DGB_REVERSE_GRAPH_FILE" 2>/dev/null | sort | uniq -c | sort -rn | head -"$top_n" | while read -r count file; do
        echo "  [${count} dependents] ${file}"
    done
}

# =============================================================================
# グラフ統計
# =============================================================================
_dgb_get_stats() {
    local project_dir="${1:-${DGB_PROJECT_DIR:-./output}}"

    if [[ ! -f "$DGB_GRAPH_FILE" ]]; then
        _dgb_build_graph "$project_dir" 2>/dev/null
    fi

    local nodes_file="${DGB_STORAGE_DIR}/nodes.list"

    # Leaf nodes (no outgoing edges)
    local leaf_count=0
    if [[ -f "$nodes_file" ]] && [[ -f "$DGB_GRAPH_FILE" ]]; then
        while IFS= read -r node; do
            [[ -z "$node" ]] && continue
            if ! grep -q "^${node}|" "$DGB_GRAPH_FILE" 2>/dev/null; then
                leaf_count=$((leaf_count + 1))
            fi
        done < "$nodes_file"
    fi

    # Root nodes (no incoming edges)
    local root_count=0
    if [[ -f "$nodes_file" ]] && [[ -f "$DGB_REVERSE_GRAPH_FILE" ]]; then
        while IFS= read -r node; do
            [[ -z "$node" ]] && continue
            if ! grep -q "^${node}|" "$DGB_REVERSE_GRAPH_FILE" 2>/dev/null; then
                root_count=$((root_count + 1))
            fi
        done < "$nodes_file"
    fi

    # Average edges per node
    local avg_edges=0
    if [[ $DGB_NODE_COUNT -gt 0 ]]; then
        avg_edges=$((DGB_EDGE_COUNT / DGB_NODE_COUNT))
    fi

    cat <<EOF
{
  "nodes": ${DGB_NODE_COUNT},
  "edges": ${DGB_EDGE_COUNT},
  "circularDeps": ${DGB_CIRCULAR_COUNT},
  "leafNodes": ${leaf_count},
  "rootNodes": ${root_count},
  "avgEdgesPerNode": ${avg_edges}
}
EOF
}

# =============================================================================
# Mermaid グラフ出力
# =============================================================================
_dgb_export_mermaid() {
    local project_dir="${1:-${DGB_PROJECT_DIR:-./output}}"
    local max_edges="${2:-80}"
    local output_file="${DGB_STORAGE_DIR}/dependency-graph.md"

    if [[ ! -f "$DGB_GRAPH_FILE" ]] || [[ ! -s "$DGB_GRAPH_FILE" ]]; then
        _dgb_build_graph "$project_dir" 2>/dev/null
    fi

    local mermaid="graph TD\n"
    local edge_count=0

    while IFS='|' read -r from to; do
        [[ -z "$from" || -z "$to" ]] && continue
        [[ $edge_count -ge $max_edges ]] && break

        # Sanitize for mermaid IDs
        local from_id to_id
        from_id=$(echo "$from" | sed 's|[/.\-]|_|g')
        to_id=$(echo "$to" | sed 's|[/.\-@]|_|g')

        # Shorten labels
        local from_label to_label
        from_label=$(basename "$from" | sed 's/\.[^.]*$//')
        to_label=$(basename "$to" | sed 's/\.[^.]*$//')

        mermaid+="    ${from_id}[\"${from_label}\"] --> ${to_id}[\"${to_label}\"]\n"
        edge_count=$((edge_count + 1))
    done < "$DGB_GRAPH_FILE"

    {
        echo "# Dependency Graph"
        echo ""
        echo '```mermaid'
        echo -e "$mermaid"
        echo '```'
        echo ""
        echo "Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
        echo "Edges displayed: ${edge_count} / ${DGB_EDGE_COUNT}"
        echo "Nodes: ${DGB_NODE_COUNT}"
    } > "$output_file"

    _dgb_log ok "Exported Mermaid graph: ${output_file} (${edge_count} edges)"
}

# =============================================================================
# JSON形式の完全グラフエクスポート
# =============================================================================
_dgb_export_json() {
    local output_file="${DGB_STORAGE_DIR}/dependency-graph.json"

    local json='{"nodes":['
    local first=true
    local nodes_file="${DGB_STORAGE_DIR}/nodes.list"

    if [[ -f "$nodes_file" ]]; then
        while IFS= read -r node; do
            [[ -z "$node" ]] && continue
            [[ "$first" == "true" ]] && first=false || json+=","
            json+="\"${node}\""
        done < "$nodes_file"
    fi

    json+='],"edges":['
    first=true

    if [[ -f "$DGB_GRAPH_FILE" ]]; then
        while IFS='|' read -r from to; do
            [[ -z "$from" || -z "$to" ]] && continue
            [[ "$first" == "true" ]] && first=false || json+=","
            json+="{\"from\":\"${from}\",\"to\":\"${to}\"}"
        done < "$DGB_GRAPH_FILE"
    fi

    json+="]}"
    echo "$json" > "$output_file"
    echo "$json"
}

# =============================================================================
# レポート & スコア
# =============================================================================
dgb_report() {
    echo -e "\n  ${DGB_BOLD}=== dependency-graph-builder v${DGB_VERSION} ===${DGB_NC}"
    echo -e "  ビルド回数: ${DGB_BUILD_COUNT}"
    echo -e "  エラー: ${DGB_ERRORS}"
    if [[ "$DGB_BUILD_COUNT" -gt 0 ]]; then
        echo -e "  ノード数: ${DGB_NODE_COUNT}"
        echo -e "  エッジ数: ${DGB_EDGE_COUNT}"
        echo -e "  循環依存: ${DGB_CIRCULAR_COUNT}"
    fi
}

dgb_score() {
    if [[ ${DGB_BUILD_COUNT} -ge 1 ]] && [[ ${DGB_ERRORS} -eq 0 ]] && [[ ${DGB_CIRCULAR_COUNT} -eq 0 ]]; then
        echo "95"
    elif [[ ${DGB_BUILD_COUNT} -ge 1 ]] && [[ ${DGB_ERRORS} -eq 0 ]]; then
        echo "85"
    elif [[ ${DGB_BUILD_COUNT} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "dependency-graph-builder" --version "202.0" \
        --description "import/require解析×依存グラフ構築×影響範囲解析×循環依存検出" \
        --init "dgb_init" --report "dgb_report" --score "dgb_score" \
        --enable-var "ENABLE_DEP_GRAPH_BUILDER" --cli-flags "--dep-graph-builder:--no-dep-graph-builder"
fi

# v2003.1: source時のexit codeを確実に0にする
true
