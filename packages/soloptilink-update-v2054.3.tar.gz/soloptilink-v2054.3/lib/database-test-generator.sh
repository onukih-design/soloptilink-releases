#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v347.0 - Database Test Generator
# =============================================================================
# DBテスト: マイグレーションテスト、シードデータ検証、整合性チェック。
# Prisma migrate検証、外部キー整合性、インデックス最適化検証。
#
# Functions:
#   _dtg_init()                    - Initialize
#   _dtg_generate_migration_tests() - Generate migration tests
#   _dtg_generate_seed_tests()     - Generate seed data tests
#   _dtg_generate_integrity()      - Generate data integrity tests
#   _dtg_report() / _dtg_score()
# =============================================================================

[[ -n "${_DTG_LOADED:-}" ]] && return 0; _DTG_LOADED=1

readonly _DTG_RED='\033[0;31m'
readonly _DTG_GREEN='\033[0;32m'
readonly _DTG_YELLOW='\033[0;33m'
readonly _DTG_CYAN='\033[0;36m'
readonly _DTG_NC='\033[0m'

declare -g DTG_VERSION="347.0"
DTG_GENERATED=0; DTG_ERRORS=0; DTG_FILES_WRITTEN=0
DTG_MIGRATION_OK=false; DTG_SEED_OK=false; DTG_INTEGRITY_OK=false
DTG_MODELS_FOUND=0

_dtg_init() {
    DTG_GENERATED=0; DTG_ERRORS=0; DTG_FILES_WRITTEN=0
    DTG_MIGRATION_OK=false; DTG_SEED_OK=false; DTG_INTEGRITY_OK=false
    DTG_MODELS_FOUND=0
    echo -e "  ${_DTG_GREEN}OK${_DTG_NC} Database Test Generator v${DTG_VERSION}" >&2
    return 0
}

_dtg_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { DTG_FILES_WRITTEN=$((DTG_FILES_WRITTEN + 1)); return 0; }
    DTG_ERRORS=$((DTG_ERRORS + 1)); return 1
}

_dtg_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_DTG_CYAN}[db-test]${_DTG_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_DTG_GREEN}[db-test]${_DTG_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_DTG_YELLOW}[db-test]${_DTG_NC} $msg" >&2 ;;
        error) echo -e "  ${_DTG_RED}[db-test]${_DTG_NC} $msg" >&2 ;;
    esac
}

_dtg_generate_migration_tests() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _dtg_log info "Generating migration tests..."

    local schema_file="${project_dir}/prisma/schema.prisma"
    if [[ -f "$schema_file" ]]; then
        DTG_MODELS_FOUND=$(grep -c "^model " "$schema_file" 2>/dev/null || echo 0)
        _dtg_log info "Found ${DTG_MODELS_FOUND} Prisma models"
    fi

    _dtg_write_file "${project_dir}/tests/database/migration.test.ts" "$(cat <<'TYPESCRIPT'
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { execSync } from 'child_process';
import { PrismaClient } from '@prisma/client';

const TEST_DB_URL = 'postgresql://test:test@localhost:5432/migration_test';
let prisma: PrismaClient;

beforeAll(async () => {
  process.env.DATABASE_URL = TEST_DB_URL;
  execSync('npx prisma migrate reset --force --skip-seed', { env: { ...process.env, DATABASE_URL: TEST_DB_URL } });
  prisma = new PrismaClient({ datasources: { db: { url: TEST_DB_URL } } });
  await prisma.$connect();
});

afterAll(async () => {
  await prisma.$disconnect();
});

describe('Database Migration Tests', () => {
  it('should apply all migrations successfully', () => {
    const output = execSync('npx prisma migrate status', {
      env: { ...process.env, DATABASE_URL: TEST_DB_URL },
      encoding: 'utf-8',
    });
    expect(output).not.toContain('have not yet been applied');
  });

  it('should create all expected tables', async () => {
    const tables = await prisma.$queryRaw<Array<{tablename: string}>>`
      SELECT tablename FROM pg_tables WHERE schemaname = 'public'
    `;
    const tableNames = tables.map(t => t.tablename);
    expect(tableNames).toContain('User');
    // Add more table assertions based on schema
  });

  it('should have proper indexes', async () => {
    const indexes = await prisma.$queryRaw<Array<{indexname: string}>>`
      SELECT indexname FROM pg_indexes WHERE schemaname = 'public'
    `;
    const indexNames = indexes.map(i => i.indexname);
    // Verify email uniqueness index exists
    expect(indexNames.some(n => n.includes('email'))).toBe(true);
  });

  it('should enforce foreign key constraints', async () => {
    await expect(
      prisma.$executeRaw`INSERT INTO "Task" (id, title, "userId") VALUES ('fake', 'test', 'nonexistent')`
    ).rejects.toThrow();
  });

  it('should rollback cleanly', () => {
    // Test that migrations can be rolled back
    const output = execSync('npx prisma migrate reset --force --skip-seed 2>&1', {
      env: { ...process.env, DATABASE_URL: TEST_DB_URL },
      encoding: 'utf-8',
    });
    expect(output).not.toContain('error');
  });
});
TYPESCRIPT
)"

    _dtg_log ok "Migration tests generated"
    DTG_MIGRATION_OK=true
    DTG_GENERATED=$((DTG_GENERATED + 1))
    return 0
}

_dtg_generate_seed_tests() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _dtg_log info "Generating seed data tests..."

    _dtg_write_file "${project_dir}/tests/database/seed.test.ts" "$(cat <<'TYPESCRIPT'
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { PrismaClient } from '@prisma/client';
import { execSync } from 'child_process';

const TEST_DB_URL = 'postgresql://test:test@localhost:5432/seed_test';
let prisma: PrismaClient;

beforeAll(async () => {
  process.env.DATABASE_URL = TEST_DB_URL;
  execSync('npx prisma migrate reset --force', { env: { ...process.env, DATABASE_URL: TEST_DB_URL } });
  prisma = new PrismaClient({ datasources: { db: { url: TEST_DB_URL } } });
});

afterAll(async () => { await prisma.$disconnect(); });

describe('Seed Data Tests', () => {
  it('should create admin user', async () => {
    const admin = await prisma.user.findFirst({ where: { role: 'admin' } });
    expect(admin).toBeTruthy();
    expect(admin?.email).toBeTruthy();
  });

  it('should create sample data for all models', async () => {
    const userCount = await prisma.user.count();
    expect(userCount).toBeGreaterThan(0);
  });

  it('should be idempotent (running twice should not fail)', () => {
    expect(() => {
      execSync('npx prisma db seed', { env: { ...process.env, DATABASE_URL: TEST_DB_URL } });
    }).not.toThrow();
  });

  it('should not contain test-only data in production seed', async () => {
    const users = await prisma.user.findMany();
    for (const user of users) {
      expect(user.email).not.toContain('test@');
      expect(user.password).not.toBe('password');
    }
  });
});
TYPESCRIPT
)"

    _dtg_log ok "Seed tests generated"
    DTG_SEED_OK=true
    DTG_GENERATED=$((DTG_GENERATED + 1))
    return 0
}

_dtg_generate_integrity() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _dtg_log info "Generating data integrity tests..."

    _dtg_write_file "${project_dir}/tests/database/integrity.test.ts" "$(cat <<'TYPESCRIPT'
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { PrismaClient } from '@prisma/client';

let prisma: PrismaClient;
beforeAll(async () => { prisma = new PrismaClient(); await prisma.$connect(); });
afterAll(async () => { await prisma.$disconnect(); });

describe('Data Integrity Tests', () => {
  it('should enforce unique email constraint', async () => {
    const email = `unique-${Date.now()}@test.com`;
    await prisma.user.create({ data: { email, name: 'First', password: 'hash' } });
    await expect(
      prisma.user.create({ data: { email, name: 'Duplicate', password: 'hash' } })
    ).rejects.toThrow(/unique/i);
  });

  it('should enforce required fields', async () => {
    await expect(
      prisma.user.create({ data: {} as any })
    ).rejects.toThrow();
  });

  it('should cascade deletes properly', async () => {
    const user = await prisma.user.create({
      data: { email: `cascade-${Date.now()}@test.com`, name: 'Cascade', password: 'hash' },
    });
    // Create related records, then delete parent
    await prisma.user.delete({ where: { id: user.id } });
    // Verify orphans don't exist
  });

  it('should handle concurrent writes safely', async () => {
    const promises = Array.from({ length: 10 }, (_, i) =>
      prisma.user.create({
        data: { email: `concurrent-${Date.now()}-${i}@test.com`, name: `User ${i}`, password: 'hash' },
      })
    );
    const results = await Promise.allSettled(promises);
    const fulfilled = results.filter(r => r.status === 'fulfilled');
    expect(fulfilled.length).toBe(10);
  });
});
TYPESCRIPT
)"

    _dtg_log ok "Data integrity tests generated"
    DTG_INTEGRITY_OK=true
    DTG_GENERATED=$((DTG_GENERATED + 1))
    return 0
}

_dtg_report() {
    echo -e "\n  ${_DTG_CYAN}=== Database Test Generator v${DTG_VERSION} ===${_DTG_NC}"
    echo -e "  Generated: ${DTG_GENERATED} | Files: ${DTG_FILES_WRITTEN} | Models: ${DTG_MODELS_FOUND}"
    echo -e "  Migration: $( ${DTG_MIGRATION_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Seed: $( ${DTG_SEED_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Integrity: $( ${DTG_INTEGRITY_OK} && echo 'OK' || echo 'SKIP')"
}

_dtg_score() {
    local score=50
    ${DTG_MIGRATION_OK} && score=$((score + 15))
    ${DTG_SEED_OK} && score=$((score + 15))
    ${DTG_INTEGRITY_OK} && score=$((score + 15))
    [[ ${DTG_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "database-test-generator" --version "347.0" \
        --description "DBテスト自動生成 マイグレーション/シード/整合性 (v347)" \
        --init "_dtg_init" --report "_dtg_report" --score "_dtg_score" \
        --enable-var "ENABLE_DB_TEST_GEN" --cli-flags "--db-test-gen:--no-db-test-gen"
fi

# v2003.1: source時のexit codeを確実に0にする
true
