#!/usr/bin/env bash
# ==============================================================================
# centuria-live-orchestrator.sh — PFP-093 RLAE (Real Live Agent Engine)
#   「105体が本物として動いている」を実機能で保証する実エンジン
#
# 背景 (飛田さん事案 2026-06-05 / 小貫さん指示):
#   - 顧客 Desktop 環境では agent-orchestrator.sh の claude -p が Keychain 制限
#     (PFP-068) で起動不能 → 実エージェントを起動する仕組みが事実上存在せず、
#     「sequential-105」= 1体のLLMが役を演じるだけだった。
#   - PFP-091 は「実在証明(roster)」と「実起動数の正直な記録(manifest)」を足したが、
#     "正直に少なく開示する"設計のため「105体は動いていない」と答えてしまっていた。
#
# 本エンジンの思想 (誠実性を構造で担保):
#   1. Claude Code Desktop でも動く唯一の実起動経路 = Task(サブエージェント)ツール。
#      本エンジンは「どのロールを・どの順序(波)で・どんなロール固有プロンプトで
#      起動するか」の決定論的な dispatch-plan を生成する。実起動は上位 Claude が
#      plan に従って Task を波状に発行する。
#   2. 「105体走った」の真偽は、各エージェントが実際にディスクへ書き出した
#      証跡ファイル (agent-evidence/<role>.md) の "実数" から導出する。
#      LLM の自己申告数ではない。証跡が105個・各々が非空・互いに相違し、かつ
#      ロスターに実在するロールID由来であって初めて verify が PASS する。
#   3. 全ロールは実在する .claude/agents/*.md (121体: 既存118 + PFP-125 敵対ロール3) 由来。手作りの filler ではない。
#
# コマンド:
#   plan      <project_dir> <task_desc> [concurrency] [scope]   dispatch-plan 生成 + manifest begin
#                scope=all   : ロスター全ロール (既定・後方互換)
#                scope=claim : フェーズバランスを保ち優先度上位 105 体 (CLAIMED_CAPACITY) を選抜 (PFP-112)
#   wave      <project_dir> <wave_no>                            指定波のロール固有プロンプトを出力(LLMがTask発行)
#   tally     <project_dir>                                      証跡を走査し実起動数を更新(実数の唯一の源)
#   verify    <project_dir> [min]                                証跡 >= min かつ非空・相違・ロスター由来なら exit 0
#   report    <project_dir>                                      完了報告用の正直な一行
#   prove     <project_dir> <task_desc> [concurrency]            顧客向け「105体実証」エントリ (= plan + 案内)
#   summary   <project_dir>                                      波・フェーズ・進捗の人間可読サマリ
#
# 出力: <project_dir>/.soloptilink/centuria-dispatch-plan.json
#       <project_dir>/.soloptilink/centuria-live-manifest.json   (本エンジンの権威ある実数源)
#       <project_dir>/.soloptilink/agent-evidence/<role-id>.md   (各実エージェントの実成果物)
# 依存: python3 (Desktop 可 / claude -p 制約を受けない), centuria-roster.json
#
# 堅牢化 (2026-06-05 PFP-093 敵対的レビュー 7 high 対応):
#   - tally/verify はロスター実在IDと照合し、ロスター外ファイルを計上しない (証跡偽装防止)
#   - classify はハイフン考慮の単語境界マッチ (部分文字列誤分類 37件を解消)
#   - verify は tally 失敗を握り潰さず、manifest 不在/破損を FAIL として安全に報告
#   - project_dir は realpath 正規化し ../ によるパストラバーサルを排除
#   - EVIDENCE_MIN_CHARS は外部から 200 未満に下げられない (ゲーミング防止)
#   - summary は tally と同一基準で集計し数値乖離を解消
# ==============================================================================
set -euo pipefail

SL="$HOME/.soloptilink"
ROSTER="$SL/agents/centuria-roster.json"
ROSTER_SH="$SL/lib/centuria-roster.sh"
MANIFEST_SH="$SL/lib/agent-run-manifest.sh"
EVIDENCE_MARKER="CENTURIA-AGENT-EVIDENCE"
CLAIMED_CAPACITY=105   # 主張する最低体数 (verify の既定しきい値)。実在ロスターはこれ以上

# 証跡として認める最低文字数。外部環境変数で 200 未満に下げてゲーミングされないよう下限を固定
_min_env="${CENTURIA_EVIDENCE_MIN_CHARS:-200}"
[[ "$_min_env" =~ ^[0-9]+$ ]] || _min_env=200
EVIDENCE_MIN_CHARS=$(( _min_env > 200 ? _min_env : 200 ))

# 証跡の soft 上限 (バイト)。超過分は synthesis へ渡す際に切詰められる (PFP-112 トークン削減)。
# 有効/無効の判定には影響しない (soft)。1200 未満には下げられない (品質下限の保護)
_cap_env="${CENTURIA_EVIDENCE_SOFT_CAP_BYTES:-4000}"
[[ "$_cap_env" =~ ^[0-9]+$ ]] || _cap_env=4000
EVIDENCE_SOFT_CAP_BYTES=$(( _cap_env < 1200 ? 1200 : _cap_env ))

C_CY='\033[0;36m'; C_GR='\033[0;32m'; C_RD='\033[0;31m'; C_YL='\033[1;33m'; C_NC='\033[0m'

_die() { echo -e "${C_RD}$*${C_NC}" >&2; exit 2; }
# project_dir を絶対パスに正規化し ../ を解消 (パストラバーサル防止)
_norm() { python3 -c "import os,sys;print(os.path.realpath(sys.argv[1]))" "$1" 2>/dev/null || echo "$1"; }

[ -f "$ROSTER" ] || { bash "$ROSTER_SH" build >/dev/null 2>&1 || true; }
[ -f "$ROSTER" ] || _die "ロスターが見つかりません。先に centuria-roster.sh build を実行してください: $ROSTER"

# 実在ロスター総数 (報告用。主張105 ≤ 実在)
ROSTER_TOTAL=$(python3 -c "import json;r=json.load(open('$ROSTER'));print(len(r.get('centuria_specialists',[]))+len(r.get('executives',[])))" 2>/dev/null || echo "$CLAIMED_CAPACITY")
[[ "$ROSTER_TOTAL" =~ ^[0-9]+$ ]] || ROSTER_TOTAL="$CLAIMED_CAPACITY"

_plan_path()     { echo "$1/.soloptilink/centuria-dispatch-plan.json"; }
_manifest_path() { echo "$1/.soloptilink/centuria-live-manifest.json"; }
_evidence_dir()  { echo "$1/.soloptilink/agent-evidence"; }
# PFP-125 反証台帳 (rebuttal ledger): 敵対的検証波の指摘を機械抽出し、完成前に全件解消したかを判定する権威ファイル
_ledger_path()   { echo "$1/.soloptilink/centuria-rebuttal-ledger.json"; }
_review_bp_path(){ echo "$1/.soloptilink/centuria-blueprint-review.md"; }

# ------------------------------------------------------------------------------
# plan: dispatch-plan を生成する
# ------------------------------------------------------------------------------
_cmd_plan() {
  local pdir="${1:?project_dir required}"; local task="${2:?task_desc required}"
  local conc="${3:-12}"; local scope="${4:-all}"
  [[ "$conc" =~ ^[0-9]+$ ]] || _die "concurrency は数値で指定してください: '$conc'"
  # scope は all / claim のみ。未知値は後方互換のため all に安全フォールバック
  case "$scope" in
    all|claim) : ;;
    *) echo -e "${C_YL}⚠ 未知の scope '$scope' → 'all' として続行します (有効: all|claim)${C_NC}" >&2; scope="all" ;;
  esac
  pdir="$(_norm "$pdir")"
  mkdir -p "$pdir/.soloptilink" "$(_evidence_dir "$pdir")"

  # ── PFP-13x 法令実装要件の深い注入 ──
  # 該当する日本法/規制(個情法/マイナンバー/電帳法/インボイス等)の必須モデル・業務ルール・データ
  # 取扱ルール・監査要件を本文注入し、生成物に法的要件を実装させる。算出は python _build_dbl_digest が
  # 「解決済みドメイン(env→task検出)」を使い compliance-attach.sh(SoT)経由で行う。
  # (REF-02/03対策: bash層 env限定だと task検出DBLで業種法が脱落・DBL未解決時に注入が落ちるため python側へ一本化)
  # kill-switch: COMPLIANCE_INJECT=off で従来挙動(法令名のみ)に戻る。

  # ── Session① desktop-domain-bridge: 蓄積ドメイン資産(日本堀レーン)注入 ──
  # Desktop経路(chain.sh不発行)でも lib/japan の算定式/係数/様式/照合ルールを各ロールへ届ける『橋』。
  # 検出DBL+タスク本文から該当レーン(介護→reward-engine / 税→tax-engine / インボイス→authority-connectors /
  # 帳票→official-forms / 改正→amendment-tracker)を解決し business_logic サマリを digest 化する。
  # 該当レーン無し業種は空(no-op)=従来の汎用フロー不変。kill-switch: ENABLE_DOMAIN_BRIDGE=off で従来挙動。
  # companion 参照のみ=lib/japan/* レーン本体は無改変(越境ゼロ)。
  local _bridge_digest=""
  if [[ "${ENABLE_DOMAIN_BRIDGE:-auto}" != "off" && -f "$SL/lib/desktop-domain-bridge.sh" ]]; then
    local _br_tf=""; _br_tf="$(mktemp 2>/dev/null || true)"
    [[ -n "$_br_tf" ]] && printf '%s' "$task" > "$_br_tf"
    _bridge_digest="$(bash "$SL/lib/desktop-domain-bridge.sh" digest "${SOLOPTILINK_DETECTED_DBL:-}" "$_br_tf" 2>/dev/null || true)"
    [[ -n "$_br_tf" ]] && rm -f "$_br_tf"
  fi

  # ── Session⑤ desktop-scale-bridge: 累積レーン(可変層/段階生成/移行/運用/保証)注入 ──
  # Desktop経路(chain.sh不発行)でも scale-planner の可変層(規模層SL)を解決し LAYER_PLAN を各ロールへ届ける『橋』。
  # ≥11層は段階生成(群分割)を指示し生成物に群分割の痕跡(モジュール群)を出す。移行/自己運用/保証書は
  # 該当業種/要求時のみ同梱注入(非該当は空=no-op)。owner-GO待ち(realtime/sakana)は注入しない(誇大表示の禁止)。
  # companion 参照のみ=scale-planner/各レーン本体は無改変(越境ゼロ)。kill-switch: ENABLE_SCALE_DESKTOP=off で従来挙動。
  local _scale_digest=""
  if [[ "${ENABLE_SCALE_DESKTOP:-auto}" != "off" && -f "$SL/lib/desktop-scale-bridge.sh" ]]; then
    local _sc_tf=""; _sc_tf="$(mktemp 2>/dev/null || true)"
    [[ -n "$_sc_tf" ]] && printf '%s' "$task" > "$_sc_tf"
    _scale_digest="$(bash "$SL/lib/desktop-scale-bridge.sh" centuria-digest "${SOLOPTILINK_DETECTED_DBL:-}" "$_sc_tf" "$pdir" 2>/dev/null || true)"
    [[ -n "$_sc_tf" ]] && rm -f "$_sc_tf"
  fi

  # ── Session③ dbl-logic-codegen: DBL business_logic → 実行コード化 義務 注入 ──
  # DBL digest(PFP-129)が業務ロジックを prose で届けても、生成物に『実行コード』として落ちないと L3 は恒真。
  # 本ブリッジは検出DBLの算定ロジックを『関数+zod+単体テスト』へ materialize する変換義務(算定式・係数・閾値を
  # 本体に実装)を各ロール(特に Role2 Implementer)へ構造注入する。浅い業種/未検出は空(no-op)=従来挙動不変。
  # companion 参照のみ=DBL JSON(domains/*.json)は値の SoT として無編集。kill-switch: ENABLE_DBL_CODEGEN=off。
  local _codegen_digest=""
  if [[ "${ENABLE_DBL_CODEGEN:-auto}" != "off" && -f "$SL/lib/first-boot-perfect/dbl-logic-codegen.sh" ]]; then
    local _cg_tf=""; _cg_tf="$(mktemp 2>/dev/null || true)"
    [[ -n "$_cg_tf" ]] && printf '%s' "$task" > "$_cg_tf"
    _codegen_digest="$(bash "$SL/lib/first-boot-perfect/dbl-logic-codegen.sh" digest "${SOLOPTILINK_DETECTED_DBL:-}" "$_cg_tf" 2>/dev/null || true)"
    [[ -n "$_cg_tf" ]] && rm -f "$_cg_tf"
  fi

  # ── S6 第6波 security-injection: セキュリティ(DLP)/RBAC/差別化の生成指示 前段注入 ──
  # 安全・権限・賢さを『生成器へ書かせる指示』として Desktop 生成プロンプトへ前段注入する。後段ゲート
  # (permission-matrix / differentiation-insight)は本体無編集の verifier として born-passing ループ化。
  # DLP は当該タスク関連度上位の的中のみ載せ、S6追加分は soft_cap で総量予算(目安8000字)内に抑える。
  # companion 参照のみ=pii-mask.sh / secret-patterns.json / 両ゲート本体は無改変(越境ゼロ)。
  # kill-switch: ENABLE_SECINJ=off で完全 no-op(従来挙動)。
  local _secinj_digest=""
  if [[ "${ENABLE_SECINJ:-auto}" != "off" && -f "$SL/lib/security-injection/inject-security.sh" ]]; then
    local _si_tf=""; _si_tf="$(mktemp 2>/dev/null || true)"
    [[ -n "$_si_tf" ]] && printf '%s' "$task" > "$_si_tf"
    _secinj_digest="$(bash "$SL/lib/security-injection/inject-security.sh" centuria-digest "${SOLOPTILINK_DETECTED_DBL:-}" "$_si_tf" 2>/dev/null || true)"
    [[ -n "$_si_tf" ]] && rm -f "$_si_tf"
  fi

  # ── 第1波 cumulative-reclaim: 横展開ドメイン累積レーン(内部統制/電帳法/解約ロック/検収/tenant-dna)注入 ──
  # ⑤(scale-bridge)が回収しなかった横展開の実ドメイン資産を Desktop 生成物へ一括回収する補完。
  # 検出DBL+タスク本文から該当系統のみ(的中載せ)を解決し、業務機能要旨(電帳法AND検索/検収CRUD実走/
  # 職務分掌SoD/リースロック/命名ロック)を digest 化して各ロールへ届ける。非該当系統は no-op 素通り。
  # companion 参照のみ=lib/internal-control 等の回収本体は無改変(越境ゼロ)。kill-switch: ENABLE_CUMULATIVE_RECLAIM=off。
  local _cumulative_digest=""
  if [[ "${ENABLE_CUMULATIVE_RECLAIM:-auto}" != "off" && -f "$SL/lib/cumulative-reclaim/cumulative-reclaim.sh" ]]; then
    local _cr_tf=""; _cr_tf="$(mktemp 2>/dev/null || true)"
    [[ -n "$_cr_tf" ]] && printf '%s' "$task" > "$_cr_tf"
    _cumulative_digest="$(bash "$SL/lib/cumulative-reclaim/cumulative-reclaim.sh" centuria-digest "${SOLOPTILINK_DETECTED_DBL:-}" "$_cr_tf" "$pdir" 2>/dev/null || true)"
    [[ -n "$_cr_tf" ]] && rm -f "$_cr_tf"
  fi

  # ── S2 shell-asset-reclaim: 死蔵シェル資産の dedup 残余 reclaim(既配線でない未回収能力のみ的中載せ) ──
  # 兄弟機構(cumulative-reclaim=L33/security-injection=S6/asset-injection-ledger)が回収済みの能力は
  # dedup 除外し二重注入(品質希釈)を回避。未回収なし=空(no-op)。kill-switch: ENABLE_SHELL_RECLAIM=off。
  # companion 参照のみ=回収本体は無改変(越境ゼロ)。本番は通常空のため既定で従来挙動不変(回帰ゼロ)。
  local _reclaim_digest=""
  if [[ "${ENABLE_SHELL_RECLAIM:-auto}" != "off" && -f "$SL/lib/shell-asset-reclaim/sh-relevance-ranker.sh" ]]; then
    local _rk_tf=""; _rk_tf="$(mktemp 2>/dev/null || true)"
    [[ -n "$_rk_tf" ]] && printf '%s' "$task" > "$_rk_tf"
    _reclaim_digest="$(bash "$SL/lib/shell-asset-reclaim/sh-relevance-ranker.sh" centuria-digest "${SOLOPTILINK_DETECTED_DBL:-}" "$_rk_tf" 2>/dev/null || true)"
    [[ -n "$_rk_tf" ]] && rm -f "$_rk_tf"
  fi

  # ── S11 quality-elevation 消費側: 品質閉ループ書戻しヒント(過去ビルド実測の低成分)注入 ──
  # feedback-writeback.sh が tenant-dna inbox へ書き戻した品質実測(4成分の低成分)を consume し、
  # refiner ヒントとして各ロールへ届ける『生成→計測→書戻し→次ビルド注入』閉ループの消費側配線。
  # inbox 空/資産欠落/consume 失敗はすべて空(no-op)=従来挙動不変。kill-switch: ENABLE_QUALITY_ELEVATION=off。
  # 読取のみ(consume は append-only 尊重で削除なし)=lib/quality-elevation 本体は無改変(L38 seal 対象を編集しない)。
  local _qe_hints_json=""
  if [[ "${ENABLE_QUALITY_ELEVATION:-auto}" != "off" && -f "$SL/lib/quality-elevation/consume-writeback-inbox.sh" ]]; then
    _qe_hints_json="$(bash "$SL/lib/quality-elevation/consume-writeback-inbox.sh" consume --json 2>/dev/null || true)"
    # サイズ上限 64KB (adversarial w1 QLOOP-DOS-02): 汚染 inbox 由来の巨大出力を env 渡しすると
    # execve ARG_MAX (macOS 1MB) 超過で plan 本体が E2BIG 死する。上限超過は破棄=no-op 縮退
    # (consume 側にも hints 20件 emit 上限の二重防御あり)。
    if [[ "${#_qe_hints_json}" -gt 65536 ]]; then _qe_hints_json=""; fi
  fi

  ROSTER="$ROSTER" PLAN="$(_plan_path "$pdir")" TASK="$task" CONC="$conc" \
  SCOPE="$scope" EVDIR="$(_evidence_dir "$pdir")" MARKER="$EVIDENCE_MARKER" \
  CLAIM="$CLAIMED_CAPACITY" PDIR="$pdir" DOMAINS_DIR="$SL/domains" \
  DETECTED_DBL="${SOLOPTILINK_DETECTED_DBL:-}" \
  COMPLIANCE_INJECT="${COMPLIANCE_INJECT:-on}" \
  DOMAIN_BRIDGE_DIGEST="$_bridge_digest" \
  SCALE_BRIDGE_DIGEST="$_scale_digest" \
  DBL_CODEGEN_DIGEST="$_codegen_digest" \
  SECINJ_DIGEST="$_secinj_digest" \
  CUMULATIVE_RECLAIM_DIGEST="$_cumulative_digest" \
  RECLAIM_DIGEST="$_reclaim_digest" \
  QE_HINTS_JSON="$_qe_hints_json" \
  RECLAIM_BUDGET_MAX="${RECLAIM_BUDGET_MAX:-8000}" \
  RECLAIM_GOVERNOR="${RECLAIM_GOVERNOR:-off}" \
  RECLAIM_RANKER="$SL/lib/shell-asset-reclaim/sh-relevance-ranker.sh" \
  DBL_MIN_SCORE="${CENTURIA_DBL_MIN_SCORE:-2}" \
  python3 - <<'PY'
import json, os, re, glob

roster = json.load(open(os.environ["ROSTER"]))
task   = os.environ["TASK"]
conc   = max(1, int(os.environ["CONC"]))
scope  = os.environ["SCOPE"]
evdir  = os.path.realpath(os.environ["EVDIR"])
marker = os.environ["MARKER"]
claim  = int(os.environ["CLAIM"])
pdir   = os.environ["PDIR"]
domains_dir = os.environ["DOMAINS_DIR"]

specialists = roster["centuria_specialists"]
executives  = roster["executives"]

# --- フェーズ分類 (id + specialties のキーワードで決定論的に割当) -----------------
PHASE_RULES = [
    # PFP-125 敵対的検証波: 7 体の反証ロールを最優先で adversarial フェーズへ。
    # v2055 増強 (owner 2026-07-18): 従来トリオ (refuter/skeptic/falsifier) に
    #   exploiter (攻撃者) / saboteur (運用破壊) / regression-hunter (機能消失) /
    #   ux-adversary (未経験者UX) を追加。classify は最初に当たった規則を採用するため
    #   先頭に置き、専門ロールの id/specialties で確実に捕捉する。
    ("adversarial", ["refuter","skeptic","falsifier","refutation","counter-example",
                     "devils-advocate","assumption-attack","overconfidence",
                     "exploiter","saboteur","regression-hunter","ux-adversary",
                     "exploit-attack","authz-bypass","operational-sabotage",
                     "deploy-fragility","persistence-attack","regression-hunting",
                     "feature-loss-detection","usability-attack","novice-user-simulation"]),
    ("architecture", ["architect","ddd","clean-architecture","cqrs","domain","api-design",
                       "db-architect","schema","requirement","consultant","design-system",
                       "component-library","cloud-architect","event-storming","modeling","graphql"]),
    ("implementation", ["backend","frontend","fullstack","api","route","android","ios","mobile",
                        "animation","component","ui","ux","developer","integration","webhook",
                        "business-rules","email-system","notification-system","websocket","real-time",
                        "queue-specialist","file-processing","pdf-generator","form-specialist",
                        "search-engineer","flutter","react-native","pwa","i18n","responsive",
                        "regex","prototype"]),
    ("data_ai", ["data","analytics","ai-engineer","machine-learning","pipeline","etl",
                 "computer-vision","nlp","embedding","recommendation","forecast",
                 "graph-db","vector-db","timeseries","sql-optimizer","prompt-engineer",
                 "experiment","product-analyst","ml-ops"]),
    ("quality", ["test","qa","contract-tester","benchmark","accessibility","a11y","performance",
                 "load","e2e","coverage","lint","quality","fuzz","visual-regression"]),
    ("security", ["security","crypto","auth","compliance","privacy","threat","pentest","penetration",
                  "vulnerability","gdpr","encryption","rbac","oauth"]),
    ("ops", ["devops","sre","cloud","capacity","cost","config","dependency","cache","observability",
             "monitoring","ci-cd","docker","kubernetes","infra","deploy","release",
             "gitops","terraform","serverless","swarm","incident","log-analyst"]),
    ("review", ["review","refactor","changelog","docs","documentation","copywriter","editor",
                "tech-writer","technical-writer","audit","brand","lp-director","conversion",
                "seo","presentation","video","media-manager","follow-up","governance"]),
]
PHASE_ORDER = ["architecture","implementation","data_ai","quality","security","ops","review","analysis","adversarial"]
PHASE_LABEL = {
    "architecture":"設計", "implementation":"実装", "data_ai":"データ/AI",
    "quality":"品質/テスト", "security":"セキュリティ/規制", "ops":"運用/インフラ",
    "review":"レビュー/改善", "analysis":"専門分析", "adversarial":"敵対的検証",
}
PHASE_INSTRUCTION = {
    "architecture":"このプロジェクトのアーキテクチャ観点から、あなたの専門領域として必要なデータモデル/API/画面構造への要求、設計判断、トレードオフ、想定リスクを具体的に提示してください。",
    "implementation":"あなたの専門領域として、実装すべき具体的なモジュール・関数・コンポーネントと、その実装方針(Next.js 14 App Router / Prisma / TypeScript strict 前提)を具体的に提示してください。\n\n★実装時の絶対厳守 3 原則 (PFP-152/153/154/155・完成ゲートが機械検証):\n(1) セッション署名鍵は環境変数必須。auth.ts では SESSION_SECRET を『未設定なら throw』する形にし、ハードコード fallback (|| \"long-string\") は絶対に書かない。\n(2) login/signin ページの入力欄に defaultValue でメール/パスワードをプリフィルしない。画面に平文でデモ資格情報を表示しない。開発用初期資格情報は README のみに記載する。\n(3) 'use server' の Server Action は関数冒頭で requireUser()/requireAdmin() 等の実ガードを呼ぶ。redirect('/login') のみは偽装ガードなので不可。lib/auth.ts に requireUser() ヘルパーを実装する。\n加えて機微モデル (User/Customer/Order/Invoice/Payment) の mutation は AuditLog に記録し、複数 write は prisma.$transaction で包み、商業/製造を謳うなら受注→請求→入金のモデル3段を揃える (揃えない場合は SCOPE.md に『算定エンジン限定』を明示)。",
    "data_ai":"データ/AI 観点から、必要なデータモデル・パイプライン・主要指標(KPI)・分析/学習ロジックの実装方針を具体的に提示してください。",
    "quality":"品質/テスト観点から、検証すべき項目・代表テストケース・受入基準・想定不具合を具体的に提示してください。",
    "security":"セキュリティ/規制観点から、想定脅威・対策・該当法令対応(個情法R4 等)・認証認可方針を具体的に提示してください。",
    "ops":"運用/インフラ/コスト観点から、デプロイ構成・監視・スケーリング・コスト最適化の方針を具体的に提示してください。",
    "review":"レビュー観点から、想定される不足・整合性の懸念・改善提案・リファクタ候補を具体的に提示してください。",
    "analysis":"あなたは自分の専門領域(業種・業務)の第一人者です。この対象事業の現場を具体的に想像し、『この企業だからこそ必要で、汎用システムには無い』固有の業務要求・データモデル・賢い機能を提示してください。表面的な一覧/登録のCRUDで終わらせず、上記の業務ロジック詳細(算定式・係数・KPI)・成長戦略を活かした分析・予測・スコアリング・自動判定・異常検知・次アクション提案まで必ず踏み込むこと。",
    "adversarial":"あなたは敵対的検証者です。他の専門ロールが出した設計・実装方針を鵜呑みにせず、意図的に『反証』してください。具体的には: (1) 暗黙の前提で破綻するシナリオ、(2) 見落とされた失敗モード・反例・エッジケース、(3) データ整合性/権限/トランザクション境界/同時実行で壊れる箇所、(4) 規制・実務要件を満たさない点、(5) 品質証明書・受入基準が主張する品質と実測値の乖離(証跡のない合格主張・テスト未実走での合格宣言)、(6) 完成ゲートの退避・無効化・閲覧専用化・モック残存など false-PASS を誘発する兆候、(7) 差別化機能と称しながら実体は汎用CRUD/ラベルだけ・算定式や閾値が未実装の「見せかけの賢さ」 を、各々『どの設計判断のどこが』『どう壊れるか』『どう直すべきか』の3点セットで列挙してください。確信が持てない指摘は「要検証」と明記し、楽観的な追認は避けてください。出力は実装前に潰すべき具体的リスク台帳とすること。",
}

# --- 差別化の義務 (PFP-130): 全フェーズ(敵対的検証を除く)に付与する強制句 -----------------
# 無色の汎用指示は最大公約数=汎用CRUDへ収束する。反証(adversarial)を強制して守りを機構化したのと
# 対称に、攻め(差別化)を明示強制する。各ロールは必ず固有の賢い機能を3件、根拠付きで創出する。
DIFFERENTIATION_MANDATE = (
    "\n\n# 差別化の義務 (このフェーズの最重要要件・必須)\n"
    "一般的な機能の列挙で終わらせず、『この対象事業/業種だからこそ価値が出る、凡庸な開発者が思いつかない"
    "決定的機能・独自ワークフロー・競合が見落とす鋭い機能』を最低3件、必ず次の3点セットで提案せよ:\n"
    "  (a) 機能名と、それが解く具体的な業務の痛点\n"
    "  (b) なぜこの業種/企業で効くのか (上記の業務ロジック詳細・成長戦略・KPI のどれを根拠にするか)\n"
    "  (c) 競合や汎用CRMが見落とす理由\n"
    "単なる一覧/登録/編集/削除(CRUD)に留まる提案や、どの業種にも当てはまる汎用機能は『差別化』として認めない。"
    "上記DBLの業務ロジック詳細(算定式・係数・閾値)を必ず1つ以上、具体的な賢い機能"
    "(分析/予測/スコアリング/自動チェック/異常検知/次アクション提案)へ翻訳すること。"
)

# --- DBL digest 自動埋込 (PFP-112) ----------------------------------------------
# SOLOPTILINK_DETECTED_DBL (環境変数) または task テキストから業種辞書を解決し、
# models/keywords/business_logic の digest を各 role prompt に構造注入する。
# prose 指示 (boost.md 手動連結) に依存しない構造的注入が目的。
def _dbl_load(name):
    path = os.path.join(domains_dir, name + ".json")
    if not os.path.isfile(path):
        return None
    try:
        return json.load(open(path, encoding="utf-8"))
    except Exception:
        return None

def _dbl_detect_from_task(text):
    # chain.sh phase_dbl_detect と同思想: keywords[] の出現数スコアで最良候補を選ぶ
    try:
        min_score = max(1, int(os.environ.get("DBL_MIN_SCORE", "2")))
    except ValueError:
        min_score = 2
    low = text.lower()
    best_name, best_score = "", 0
    for f in sorted(glob.glob(os.path.join(domains_dir, "*.json"))):
        base = os.path.basename(f)
        if base == "_base.json":
            continue
        try:
            d = json.load(open(f, encoding="utf-8"))
        except Exception:
            continue
        kws = [k for k in d.get("keywords", []) if isinstance(k, str) and len(k) >= 2][:30]
        score = sum(1 for k in kws if k.lower() in low)
        if score > best_score:
            best_score, best_name = score, base[:-5]
    return best_name if best_score >= min_score else ""

def _names_of(v, limit):
    # models/business_logic は dict / list(各要素 dict or str) の両形式が混在するため正規化
    out = []
    if isinstance(v, dict):
        out = list(v.keys())
    elif isinstance(v, list):
        for item in v:
            if isinstance(item, dict):
                n = item.get("name") or item.get("title") or ""
                desc = item.get("description") or ""
                out.append(f"{n}（{desc[:40]}）" if n and desc else (n or str(item)[:40]))
            else:
                out.append(str(item)[:60])
    return [s for s in out if s][:limit]

def _logic_detail_of(v, limit, full_steps):
    # PFP-129: business_logic を name+description全文+steps(算定式/係数/条件分岐)+inputs+kpi まで
    # 構造保持して抽出する。名前だけの _names_of と異なり「業務上どう賢く振る舞うか」を各ロールへ届け、
    # 汎用CRUDへの退行を断つのが目的 (例: ヨミ着地=実績+Aヨミ×0.9+Bヨミ×0.5+Cヨミ×0.2 の係数を消さない)。
    items = []
    if isinstance(v, dict):
        for k, val in v.items():
            if isinstance(val, dict):
                d = dict(val); d.setdefault("name", k); items.append(d)
            else:
                items.append({"name": k, "description": str(val)})
    elif isinstance(v, list):
        for it in v:
            items.append(it if isinstance(it, dict) else {"name": str(it)[:60]})
    blocks = []
    for it in items[:limit]:
        n = it.get("name") or it.get("title") or ""
        if not n:
            continue
        seg = [f"■ {n}"]
        desc = (it.get("description") or "").strip()
        if desc:
            seg.append(f"  概要: {desc}")
        steps = it.get("steps") or it.get("algorithm") or it.get("rules") or []
        if isinstance(steps, str):
            steps = [steps]   # steps が文字列のDBL(例 logistics-trucking optimizeRoute)で算定式が脱落するのを防ぐ
        if isinstance(steps, dict):
            steps = [f"{kk}: {vv}" for kk, vv in steps.items()]
        if isinstance(steps, list) and steps:
            take = steps if full_steps else steps[:3]
            for st in take:
                if isinstance(st, dict):
                    # 想定キーが無い step dict の生 json 漏れを防ぎ、人間可読な要約に正規化する
                    stxt = st.get("step") or st.get("desc") or st.get("rule") or st.get("name") \
                        or "; ".join(f"{kk}={vv}" for kk, vv in st.items())
                else:
                    stxt = str(st)
                seg.append(f"    - {str(stxt)[:200]}")
            if not full_steps and len(steps) > 3:
                seg.append(f"    - …(他{len(steps)-3}手順は実装時に DBL から補完)")
        inputs = it.get("inputs") or it.get("input") or []
        if isinstance(inputs, dict):
            inputs = list(inputs.keys())
        if isinstance(inputs, list) and inputs:
            # 要素が dict/list の異常DBLで Python repr が漏れるのを防ぎ可読化する
            def _inp(x):
                if isinstance(x, dict):
                    return str(x.get("name") or x.get("field") or next(iter(x.keys()), ""))
                if isinstance(x, list):
                    return ", ".join(str(y) for y in x)
                return str(x)
            seg.append("    入力: " + ", ".join(_inp(x)[:40] for x in inputs[:8]))
        kpi = it.get("kpi") or it.get("kpis") or it.get("kpi_target") or ""
        if kpi:
            if isinstance(kpi, dict):
                kpitxt = ", ".join(f"{k}={v}" for k, v in kpi.items())
            elif isinstance(kpi, list):
                kpitxt = ", ".join(str(x.get("name") if isinstance(x, dict) else x) for x in kpi)
            else:
                kpitxt = str(kpi)
            seg.append(f"    KPI: {kpitxt[:140]}")
        blocks.append("\n".join(seg))
    return blocks

def _compliance_digest(domain):
    # 該当法令(日本法/規制)の実装要件本文を compliance-attach.sh(SoT)から取得。
    # 解決済み domain(env→task検出)を使うため DBL digest と法令の業種が必ず一致する(REF-02対策)。
    if (os.environ.get("COMPLIANCE_INJECT") or "on") == "off":
        return ""
    attach = os.path.join(os.path.dirname(domains_dir), "lib", "compliance-attach.sh")
    if not os.path.isfile(attach):
        return ""
    import subprocess, tempfile
    tf = None
    try:
        if task:
            fd, tf = tempfile.mkstemp()
            with os.fdopen(fd, "w") as _f:
                _f.write(task)
        r = subprocess.run(["bash", attach, "digest", domain or "", tf or ""],
                           capture_output=True, text=True, timeout=25)
        return (r.stdout or "").strip()
    except Exception:
        return ""
    finally:
        if tf:
            try: os.unlink(tf)
            except Exception: pass


def _build_dbl_digest():
    name = (os.environ.get("DETECTED_DBL") or "").strip()
    source = "env" if name else ""
    d = _dbl_load(name) if name else None
    if d is None:
        name = _dbl_detect_from_task(task)
        source = "task_text" if name else "none"
        d = _dbl_load(name) if name else None
    # 法令注入は DBL 解決の成否に依らず行う(横断法令はタスクシグナルでも付く=REF-03対策)
    comp_digest = _compliance_digest(name)
    if d is None:
        if comp_digest:
            return comp_digest, (name or ""), "compliance-only"
        return "", "", "none"
    # PFP-129: env明示指定のみ高確度 (steps全文注入)。task_text推定検出は低確度なので
    # steps要約に留め、誤検出DBLの無関係ロジックを大量注入しない (要約分岐を実際に発火させる)。
    confident = (source == "env")
    try:
        soft_cap = max(1500, int(os.environ.get("DBL_DIGEST_SOFT_CAP", "3500")))
    except ValueError:
        soft_cap = 3500
    # 名前カタログは件数を絞り、注入予算を「業務ロジックの中身」へ回す (旧: models24/kws40/logic名のみ)
    models  = _names_of(d.get("models", {}), 16)
    kws     = [k for k in d.get("keywords", []) if isinstance(k, str)][:24]
    bl      = d.get("business_logic") or d.get("business_rules") or []
    # 旧 limit=12 固定切り捨てを廃止 (リッチDBLほど末尾ロジックが無言脱落する逆進性を解消)。
    # 全件を _logic_detail_of で展開し、下流で文字数予算により動的にトリムする。
    logic_blocks = _logic_detail_of(bl, 999, full_steps=confident)
    parts = [f"# 業種ドメイン文脈 (DBL: {name} / plan 自動注入・PFP-129 高度知識注入)"]
    if models: parts.append("主要モデル: " + ", ".join(models))
    if kws:    parts.append("業界用語: " + ", ".join(kws))
    # ★賢さの核(最優先): 業務ロジックの算定式・係数・条件分岐・手順を本文注入する。
    # 成長戦略/KPI/規制/法令より先に予算を確保し、これらが先に予算を食ってロジック詳細が丸ごと
    # 脱落する優先順位逆転を防ぐ(logistics-trucking optimizeRoute 消失バグの根治)。
    if logic_blocks:
        parts.append("## この業種固有の業務ロジック詳細 (算定式・係数・閾値・手順を省略せず実装に落とすこと)")
        used_before = sum(len(p) for p in parts)
        # ロジック詳細に最低でも soft_cap の半分は確保 (他セクションに食われない床)
        logic_budget = max(int(soft_cap * 0.5), soft_cap - used_before - 400)
        acc, used = [], 0
        for b in logic_blocks:
            if used + len(b) + 1 > logic_budget:
                acc.append("…(残りの業務ロジックは centuria-blueprint 合成時に DBL から補完)")
                break
            acc.append(b); used += len(b) + 1
        parts.append("\n".join(acc))
    # 差別化機能の源泉: 成長戦略 / KPI目標 / 関連規制 (logic detail の後 = 予算超過時はこちらが先に切られる)
    gs = d.get("growth_strategies") or d.get("growth_strategy") or []
    if isinstance(gs, dict): gs = list(gs.values())
    if isinstance(gs, list) and gs:
        gnames = []
        for x in gs[:6]:
            if isinstance(x, dict):
                gnames.append(str(x.get("name") or x.get("strategy") or x.get("title") or "")[:90])
            else:
                gnames.append(str(x)[:90])
        gnames = [g for g in gnames if g]
        if gnames:
            parts.append("成長戦略(差別化の源泉): " + " / ".join(gnames))
    kt_raw = d.get("kpi_targets") or d.get("kpis") or {}
    kt_lines = []
    if isinstance(kt_raw, dict):
        for period, vals in list(kt_raw.items())[:4]:
            if isinstance(vals, dict):
                inner = ", ".join(f"{k}={v}" for k, v in list(vals.items())[:5])
                kt_lines.append(f"{period}: {inner}")
            else:
                kt_lines.append(f"{period}={vals}")
    elif isinstance(kt_raw, list):
        kt_lines = [str(x)[:60] for x in kt_raw[:8]]
    if kt_lines:
        parts.append("KPI目標: " + " / ".join(s[:90] for s in kt_lines))
    regs = d.get("regulations") or d.get("compliance") or []
    if isinstance(regs, dict): regs = list(regs.keys())
    if isinstance(regs, list) and regs:
        regnames = []
        for r in regs[:6]:
            regnames.append(r if isinstance(r, str) else (r.get("name") or r.get("law") or str(r)[:50]) if isinstance(r, dict) else str(r)[:50])
        parts.append("関連規制: " + ", ".join(str(x)[:50] for x in regnames))
    # ── PFP-13x 法令実装要件の本文注入 (python の解決済みドメインで算出した comp_digest) ──
    # 該当法令の必須モデル・業務ルール・データ取扱ルール・監査要件を本文注入し、生成物に法的要件
    # (同意/開示/保持/アクセスログ/監査証跡)を実装させる。
    _comp_digest = comp_digest
    if _comp_digest:
        parts.append(_comp_digest)
    digest = "\n".join(parts)
    # 法令本文がある場合は実効上限を拡張し、ロジック詳細と法令要件を両立させる
    eff_cap = soft_cap if not _comp_digest else min(6500, soft_cap + len(_comp_digest) + 100)
    if len(digest) > eff_cap:
        digest = digest[:eff_cap - 1] + "…"
    # 退行禁止の総括指示は cap 後に必ず付与 (切詰めで消えないように)
    digest += ("\n上記モデル・用語・ロジック詳細・成長戦略・KPI・規制をあなたの専門検討に必ず反映し、"
               "汎用 L0 骨組み(ただの一覧/登録のCRUD)への退行を禁止する。算定式・係数・閾値は省略せず実装に落とすこと。")
    return digest, name, source

def _build_strategic_digest():
    # strategic_plan.md が PROJECT_DIR (または .soloptilink/ 配下) にあれば要点を注入
    for cand in (os.path.join(pdir, "strategic_plan.md"),
                 os.path.join(pdir, ".soloptilink", "strategic_plan.md")):
        if os.path.isfile(cand):
            try:
                body = open(cand, encoding="utf-8", errors="ignore").read()
            except Exception:
                return ""
            points = []
            for ln in body.splitlines():
                s = ln.strip()
                if re.match(r"^#{1,4}\s+\S", s) or re.match(r"^[-*]\s+\S", s) or re.match(r"^\d+\.\s+\S", s):
                    points.append(s[:120])
                if sum(len(p) for p in points) > 800:
                    break
            if not points:
                points = [body[:400].replace("\n", " ")]
            return "# 戦略計画の要点 (strategic_plan.md / plan 自動注入)\n" + "\n".join(points[:14])
    return ""

DBL_DIGEST, DBL_NAME, DBL_SOURCE = _build_dbl_digest()
STRATEGIC_DIGEST = _build_strategic_digest()
# Session① 蓄積ドメイン資産ブリッジ digest (bash 層 desktop-domain-bridge.sh が算出して environ で渡す)
DOMAIN_BRIDGE_DIGEST = (os.environ.get("DOMAIN_BRIDGE_DIGEST") or "").strip()
# 注入した日本堀レーン名を可視化/検証用に抽出 (digest の `### … (<lane-id> / lib/japan/…)` ヘッダから)
DOMAIN_BRIDGE_LANES = re.findall(r"\(([\w-]+) / lib/japan/", DOMAIN_BRIDGE_DIGEST) if DOMAIN_BRIDGE_DIGEST else []
# Session⑤ 累積レーンブリッジ digest (bash 層 desktop-scale-bridge.sh が算出して environ で渡す)
SCALE_BRIDGE_DIGEST = (os.environ.get("SCALE_BRIDGE_DIGEST") or "").strip()
# Session③ DBL business_logic → 実行コード化 義務 digest (bash 層 dbl-logic-codegen.sh が算出)
# 業務ロジックを『関数+zod+単体テスト』へ materialize させる変換義務を各ロールへ届ける(L3 恒真化の根治)。
DBL_CODEGEN_DIGEST = (os.environ.get("DBL_CODEGEN_DIGEST") or "").strip()
# S6 第6波 security-injection: セキュリティ/RBAC/差別化 前段注入 digest(bash 層 inject-security.sh が算出)
SECINJ_DIGEST = (os.environ.get("SECINJ_DIGEST") or "").strip()
# 第1波 横展開ドメイン累積レーン digest (bash 層 cumulative-reclaim.sh が該当系統のみ算出)
# 内部統制(SoD)/電帳法保存/解約ロック/検収実行/tenant-dna の業務機能要旨を該当時のみ各ロールへ届ける。
CUMULATIVE_RECLAIM_DIGEST = (os.environ.get("CUMULATIVE_RECLAIM_DIGEST") or "").strip()
# 注入された累積系統 id を可視化/検証用に抽出(digest の `［累積回収:<id>］` 実体行から)
CUMULATIVE_RECLAIM_SYSTEMS = re.findall(r"［累積回収:([\w-]+)］", CUMULATIVE_RECLAIM_DIGEST) if CUMULATIVE_RECLAIM_DIGEST else []
# S2 shell-asset-reclaim: dedup 残余 reclaim digest(bash 層 sh-relevance-ranker.sh が算出)。本番は通常空。
RECLAIM_DIGEST = (os.environ.get("RECLAIM_DIGEST") or "").strip()
RECLAIM_BUDGET_MAX = int(os.environ.get("RECLAIM_BUDGET_MAX", "8000") or "8000")
RECLAIM_GOVERNOR_ON = (os.environ.get("RECLAIM_GOVERNOR", "off") == "on")  # 既定off=回帰ゼロ(opt-in)
RECLAIM_RANKER = (os.environ.get("RECLAIM_RANKER") or "").strip()          # governor 単一実装(rk_govern)への委譲先
# 解決した規模層数(可視化/検証用。digest の `... 結果 <N> 個の業務サブシステム` から抽出)
_m_sl = re.search(r"結果\s*(\d+)\s*個の業務サブシステム", SCALE_BRIDGE_DIGEST) if SCALE_BRIDGE_DIGEST else None
SCALE_BRIDGE_LAYERS = int(_m_sl.group(1)) if _m_sl else 0

# S11 品質閉ループ消費側: 書戻し inbox の集約ヒント(bash 層 consume-writeback-inbox.sh consume --json が算出)。
# 過去ビルドで実測された低成分(差別化/L3正確度/深さ/実機合格)の refiner ヒントを全ロールへ届ける。
# inbox 空/解析不能は空=no-op(従来挙動不変)。上限: ヒント5成分・digest 900字(総量予算の一部として計上)。
def _build_qe_digest():
    raw = (os.environ.get("QE_HINTS_JSON") or "").strip()
    if not raw:
        return "", 0
    try:
        qe = json.loads(raw)
    except ValueError:
        return "", 0
    # top-level が dict 以外の有効 JSON (null/list/str/int/bool) でも no-op 縮退
    # (w1 QLOOP-SH-03: AttributeError 未捕捉で plan 全体が fail-total になる穴の封鎖)
    if not isinstance(qe, dict):
        return "", 0
    hints = qe.get("low_component_hints") or []
    try:
        records = int(qe.get("records_total") or 0)
    except (TypeError, ValueError):
        records = 0
    if not isinstance(hints, list) or not hints or records < 1:
        return "", 0
    lines = ["# 品質閉ループヒント (過去ビルド実測の低成分 / S11 書戻し inbox 由来・plan 自動注入)",
             "過去の実ビルドで品質スコアが低かった成分。本ビルドでは同じ弱点を繰り返さないこと:"]
    used = 0
    for h in hints[:5]:
        if not isinstance(h, dict):
            continue
        comp = str(h.get("component") or "?")
        try:
            avg = float(h["avg_value"]) if h.get("avg_value") is not None else None
        except (TypeError, ValueError):
            avg = None
        try:
            cnt = int(h.get("count") or 0)
        except (TypeError, ValueError):
            cnt = 0
        tip = str(h.get("tip") or "").strip()
        avg_s = f"{avg:.2f}" if avg is not None else "?"
        lines.append(f"- {comp}: 実測平均 {avg_s} ({cnt}件) — {tip}"[:220])
        used += 1
    if used == 0:
        return "", 0
    return "\n".join(lines)[:900], used
QE_DIGEST, QE_HINTS_COUNT = _build_qe_digest()

def classify(aid, specialties):
    # 英数字のみを「語の内側」とみなす境界マッチ。ハイフン/空白/端は区切り扱い。
    # これにより 'terraform' は 'terraform-specialist' に一致し(前方一致OK)、
    # 'rag' は 'coverage' に・'form-specialist' は 'terraform-specialist' に一致しない(誤検出防止)。
    hay = (aid + " " + " ".join(specialties)).lower()
    for phase, kws in PHASE_RULES:
        for kw in kws:
            if re.search(r"(?<![a-z0-9])" + re.escape(kw) + r"(?![a-z0-9])", hay):
                return phase
    return "analysis"

roles = []
for s in specialists:
    roles.append({
        "id": s["id"], "title": s.get("title", s["id"]),
        "role_summary": s.get("role_summary",""),
        "specialties": s.get("specialties", []),
        "phase": classify(s["id"], s.get("specialties", [])),
        "kind": "specialist",
    })
for e in executives:
    roles.append({
        "id": e["id"], "title": e.get("title", e["id"]),
        "role_summary": e.get("mandate",""),
        "specialties": [], "phase": "review", "kind": "executive",
    })

by_phase = {p: [] for p in PHASE_ORDER}
for r in roles:
    by_phase.setdefault(r["phase"], []).append(r)

roster_total = len(roles)

# --- scope=claim: フェーズバランスを保ち優先度上位 claim(=105) 体を選抜 (PFP-112) ----
# 優先度: 各フェーズ内で executive を先頭に、その後ロスター順 (決定論的)。
# 配分: 非空フェーズに最低1体を保証しつつ、フェーズ規模比例の最大剰余法で claim 体に揃える。
# ★敵対的検証 (adversarial = refuter/skeptic/falsifier/exploiter/saboteur/
#   regression-hunter/ux-adversary・priority=1) は PFP-125 の必須反証ロール群 (v2055 で 7 体へ増強)。
#   ロスター拡張で proportional allocation に押し出され所定数未満になる回帰 (CLAIM-BENCH-b 違反) を
#   構造的に防ぐため、claim 選抜でも全数を必ずピン留め確保し、残予算のみ他フェーズへ比例配分する (L6)。
if scope == "claim" and roster_total > claim:
    all_phases = [p for p in list(by_phase.keys()) if by_phase.get(p)]
    sizes = {p: len(by_phase[p]) for p in all_phases}
    PINNED_PHASES = {"adversarial"}   # 必須反証ロール群を確保 (proportional 配分から除外)
    pinned = [p for p in all_phases if p in PINNED_PHASES]
    flex   = [p for p in all_phases if p not in PINNED_PHASES]
    n_flex = len(flex)
    # 最低 min(sizes, ADV_FLOOR) を死守しつつ、flex に最低1×フェーズ数を残す上限でキャップする。
    # (病的 roster で adversarial が claim を圧迫しても total<=claim と adversarial>=floor を両立=R1対策。
    #  現実の roster(adversarial=7)では floor=cap=7 となり全数ピン留めと完全に同一挙動。)
    ADV_FLOOR = 3   # 反証は最低 3 体を死守 (小規模 claim でも敵対波を消滅させない)
    quota = {}
    for p in pinned:
        floor_p = min(sizes[p], ADV_FLOOR)     # >=ADV_FLOOR 死守 (それ未満しか居なければ全数)
        cap_p   = max(floor_p, claim - n_flex)  # flex に最低1×フェーズ数を残す
        quota[p] = min(sizes[p], cap_p)
    pinned_total = sum(quota.values())
    flex_budget = max(0, claim - pinned_total)            # 残予算を flex フェーズへ
    flex_roster = sum(sizes[p] for p in flex) or 1
    raw = {p: sizes[p] * flex_budget / flex_roster for p in flex}
    for p in flex:
        quota[p] = min(sizes[p], max(1, int(raw[p])))
    assigned = sum(quota.values())
    # 剰余の大きい順に残枠を配る (flex フェーズのみ・フェーズ実数を超えない)
    order = sorted(flex, key=lambda p: raw[p] - int(raw[p]), reverse=True)
    while assigned < claim:
        progressed = False
        for p in order:
            if assigned >= claim:
                break
            if quota[p] < sizes[p]:
                quota[p] += 1; assigned += 1; progressed = True
        if not progressed:
            break
    # claim 超過時は flex フェーズの最大枠から削る (ピン留めと最低1は維持)
    while assigned > claim:
        cand = [p for p in flex if quota[p] > 1]
        if not cand:
            break
        p = max(cand, key=lambda q: quota[q])
        quota[p] -= 1; assigned -= 1
    for p in all_phases:
        bucket = sorted(by_phase[p], key=lambda r: 0 if r["kind"] == "executive" else 1)
        by_phase[p] = bucket[:quota[p]]
    roles = [r for p in by_phase for r in by_phase[p]]

def make_prompt(r, wave_no):
    persona = r["role_summary"] or "あなたはこの領域の専門家です。"
    spec = ", ".join(r["specialties"]) if r["specialties"] else "(汎用)"
    ev = os.path.join(evdir, r["id"] + ".md").replace(os.path.expanduser("~"), "~")
    instr = PHASE_INSTRUCTION.get(r["phase"], PHASE_INSTRUCTION["analysis"])
    # PFP-130: 敵対的検証以外の全フェーズに差別化義務を付与 (反証ロールには課さない)
    if r["phase"] != "adversarial":
        instr = instr + DIFFERENTIATION_MANDATE
    diff_output_rule = ""
    diff_token_exception = ""
    if r["phase"] != "adversarial":
        diff_output_rule = (
            "- 本文には必ず見出し『## 差別化提案』を設け、その配下に上記『差別化の義務』の"
            "3件を (a)機能名と痛点 (b)効く根拠 (c)競合が見落とす理由 の3点セットで箇条書きすること"
            "(この節は必須・省略不可)。\n"
        )
        diff_token_exception = "- ただし『## 差別化提案』節は必須でありトークン規律による削減の対象外(最優先で残すこと)。\n"
    # DBL / 戦略計画の digest は plan 時に構造注入する (prose 指示依存の廃止 / PFP-112)
    context_blocks = ""
    if DBL_DIGEST:
        context_blocks += f"\n{DBL_DIGEST}\n"
    if STRATEGIC_DIGEST:
        context_blocks += f"\n{STRATEGIC_DIGEST}\n"
    # Session① 蓄積ドメイン資産ブリッジ: 該当する日本堀レーンの算定式/係数/様式/照合ルールを全ロールへ注入
    # (Role1 Architect/Role2 Implementer に実装を必須化。非該当業種は空=注入なしで従来挙動不変)
    if DOMAIN_BRIDGE_DIGEST:
        context_blocks += f"\n{DOMAIN_BRIDGE_DIGEST}\n"
    # Session⑤ 累積レーンブリッジ: 可変層(規模層SL)プラン+段階生成指示+該当付加機能(移行/運用/保証)を全ロールへ注入
    # (規模に応じた業務サブシステム構成を必須化し汎用CRUD後退を防ぐ。小規模/kill-switch off は空=従来挙動不変)
    if SCALE_BRIDGE_DIGEST:
        context_blocks += f"\n{SCALE_BRIDGE_DIGEST}\n"
    # Session③ DBL codegen: 業務ロジックを実行コード(算定関数+zod+単体テスト)へ落とす義務を全ロールへ注入
    # (特に実装フェーズ Role2 Implementer に materialize を必須化。浅い業種/未検出は空=従来挙動不変)
    if DBL_CODEGEN_DIGEST:
        context_blocks += f"\n{DBL_CODEGEN_DIGEST}\n"
    # S6 security-injection: DLP/複数ロールRBAC/入力依存の差別化ロジックの生成指示を全ロールへ注入
    # (安全・権限・賢さを生成器へ前段指示。非該当/kill-switch off は空=従来挙動不変)
    if SECINJ_DIGEST:
        context_blocks += f"\n{SECINJ_DIGEST}\n"
    # 第1波 横展開ドメイン累積レーン: 該当系統(内部統制/電帳法/解約ロック/検収/tenant-dna)の業務機能要旨を全ロールへ注入
    # (該当案件の中核機能として Role1/Role2 に実装を必須化。非該当業種/kill-switch off は空=従来挙動不変)
    if CUMULATIVE_RECLAIM_DIGEST:
        context_blocks += f"\n{CUMULATIVE_RECLAIM_DIGEST}\n"
    # S11 品質閉ループヒント: 過去ビルドの品質実測(低成分)を refiner 指示として全ロールへ注入
    # (S2 headroom guard より前に連結し総量予算の計上対象に含める。inbox 空/kill-switch off は空=従来挙動不変)
    if QE_DIGEST:
        context_blocks += f"\n{QE_DIGEST}\n"
    # ── S2 shell-asset-reclaim 残余注入(headroom guard): 自分の取り分が予算を押し上げない時のみ載せる ──
    # 本番は通常空(全て既配線=dedup)=従来挙動不変。載る場合も連結後がグランド総量予算内に収まる時だけ。
    if RECLAIM_DIGEST and len(context_blocks) + len(RECLAIM_DIGEST) + 2 <= RECLAIM_BUDGET_MAX:
        context_blocks += f"\n{RECLAIM_DIGEST}\n"
    # ── S2 グランド総量 governor(opt-in・既定off=回帰ゼロ): 連結後が予算超過の時のみ関連度上位を残し予算内へ ──
    # 各機構は自分の取り分 soft_cap しか見ず連結後の総量予算が不在 → opt-in で関連度優先trim(品質純増)。
    # RECLAIM_GOVERNOR=on の時だけ作動。既存 digest 本体は無編集(縮約は連結後テキストのみ)。
    if RECLAIM_GOVERNOR_ON and len(context_blocks) > RECLAIM_BUDGET_MAX \
       and RECLAIM_RANKER and os.path.isfile(RECLAIM_RANKER):
        # ★単一実装委譲(F5/F6/F9 根治): governor は ranker の rk_govern に一本化。
        #   かつての独自 python コピーは「L35-GRANDBUDGET 軸の射程外で relevance殺し変異が無検出」
        #   「単一巨大節で先頭切断フォールバック」「保護節(セキュリティ/権限/差別化)が消える」を生んだため廃止。
        #   rk_govern は NOTE_RESERVE / 最大セクション保証トリム / 保護節keep を備え、軸が直接検証する。
        import subprocess, tempfile
        _gtaskf = None
        try:
            _fd, _gtaskf = tempfile.mkstemp()
            with os.fdopen(_fd, "w", encoding="utf-8") as _tf:
                _tf.write(task or "")
            _gr = subprocess.run(["bash", RECLAIM_RANKER, "govern", str(RECLAIM_BUDGET_MAX), _gtaskf],
                                 input=context_blocks, capture_output=True, text=True, timeout=15)
            if _gr.returncode == 0 and _gr.stdout.strip():
                context_blocks = _gr.stdout
        except Exception:
            pass  # 委譲失敗時は原文維持(no-op=安全・回帰ゼロ)
        finally:
            if _gtaskf:
                try: os.unlink(_gtaskf)
                except Exception: pass
    return (
        f"あなたは SoloptiLinkAI の専門ロール「{r['title']}」です。\n"
        f"{persona}\n"
        f"専門領域: {spec}\n\n"
        f"# 対象プロジェクト\n{task}\n"
        f"{context_blocks}\n"
        f"# あなたの任務（{PHASE_LABEL.get(r['phase'],'専門分析')}フェーズ）\n{instr}\n\n"
        f"# 出力ルール（厳守）\n"
        f"- 識別子(変数/関数/型/テーブル名)は英語、UI文字列・コメント・説明は日本語。\n"
        f"- 一般論ではなく、この対象プロジェクトに固有の具体的内容を書くこと。\n"
        f"- 成果物を必ず次のファイルに Write すること: {ev}\n"
        f"- そのファイルの先頭行は必ず次のマーカー行にすること:\n"
        f"  <!-- {marker} role={r['id']} wave={wave_no} phase={r['phase']} -->\n"
        f"- マーカー行の後に、あなたの専門的検討結果を Markdown で 200 文字以上書くこと。\n"
        f"{diff_output_rule}"
        f"- 最終メッセージには「このロールの結論を3行以内の日本語で要約」だけ返すこと(これは記録用で、ユーザーには表示されない)。\n"
        f"# トークン規律（厳守・コスト最適化）\n"
        f"- リポジトリ全体を探索しないこと。参照してよいのは prisma/schema.prisma・package.json・app/ のディレクトリ一覧まで。\n"
        f"- 証跡は要点のみ 400〜1200 字で書く（上限1200字・超過分は品質統合時に切詰められ評価されない）。"
        f"コード断片は最重要のものだけ短く。一般論・前置き・繰り返しは書かない。\n"
        f"{diff_token_exception}"
    )

# --- fan-out 容量の一元管理 (L6/goal7): 各波の同時展開体数の上限(ceiling)と高負荷縮退 ---
# 既定 ceiling=16 (parallel-exec-v2 / pe2 と整合)。conc<=ceiling かつ通常負荷では eff_conc=conc=既定不変。
# 高負荷(1分間ロードavg が CPU 数超)時のみ CPU 数-1 まで段階縮退し、波あたりの同時起動を抑える。
try:
    fanout_ceiling = max(1, int(os.environ.get("FANOUT_CEILING", "16")))
except ValueError:
    fanout_ceiling = 16
eff_cpu = os.cpu_count() or 4
try:
    load1 = os.getloadavg()[0]
except (OSError, AttributeError):
    load1 = 0.0
eff_conc = min(conc, fanout_ceiling)
fanout_degraded = False
if load1 > eff_cpu and eff_cpu >= 2:
    safe = max(2, eff_cpu - 1)
    if safe < eff_conc:
        eff_conc = safe; fanout_degraded = True

waves = []
wave_no = 0
for phase in PHASE_ORDER:
    bucket = by_phase.get(phase, [])
    for i in range(0, len(bucket), eff_conc):
        wave_no += 1
        chunk = bucket[i:i+eff_conc]
        agents = []
        for r in chunk:
            agents.append({
                "id": r["id"], "title": r["title"], "kind": r["kind"],
                "phase": r["phase"], "phase_label": PHASE_LABEL.get(r["phase"]),
                "specialties": r["specialties"],
                "evidence_path": os.path.join(evdir, r["id"]+".md"),
                "prompt": make_prompt(r, wave_no),
            })
        waves.append({"wave_no": wave_no, "phase": phase,
                      "phase_label": PHASE_LABEL.get(phase),
                      "agent_count": len(agents), "agents": agents})

# --- DAG I/F (L6/goal6): pe2_run_dag_waves 互換の依存波出力 (後方互換・追加フィールド) ---
# 既存 consumer は waves[] を逐次読むだけで不変。L2 (parallel-exec-v2 / pe2_run_dag_waves) は本 dag を読み、
# 依存階層を尊重しつつ独立フェーズを並列実行できる。フェーズ間依存(深い階層):
#   設計 → (実装/データ/分析) → (品質/セキュリティ/運用) → レビュー → 敵対
PHASE_DEPS = {
    "architecture": [],
    "implementation": ["architecture"],
    "data_ai": ["architecture"],
    "analysis": ["architecture"],
    "quality": ["implementation", "data_ai"],
    "security": ["implementation", "data_ai"],
    "ops": ["implementation"],
    "review": ["quality", "security", "ops"],
    "adversarial": ["review", "analysis"],
}
phase_waves = {}
for _w in waves:
    phase_waves.setdefault(_w["phase"], []).append(_w["wave_no"])
# wave 依存: ある波は前提フェーズに属する全波 + 同フェーズ内の直前波 (フェーズ内順序保持) に依存
wave_deps = {}
for _w in waves:
    _deps = []
    for _pre in PHASE_DEPS.get(_w["phase"], []):
        _deps.extend(phase_waves.get(_pre, []))
    _same = [n for n in phase_waves.get(_w["phase"], []) if n < _w["wave_no"]]
    if _same:
        _deps.append(max(_same))
    wave_deps[_w["wave_no"]] = sorted(set(_deps))
# 並列度ヒント: 依存解決済みの波を同一レベル(並列実行可)へまとめる (Kahn 法のレベル分割)
_levels = []; _done = set(); _remaining = [w["wave_no"] for w in waves]
while _remaining:
    _ready = [n for n in _remaining if all(d in _done for d in wave_deps[n])]
    if not _ready:
        _ready = _remaining[:]   # 循環防止フォールバック (理論上発生しない)
    _levels.append(_ready); _done.update(_ready)
    _remaining = [n for n in _remaining if n not in _done]
dag = {
    "schema": "centuria-dag/1",
    "note": "pe2_run_dag_waves 互換の依存波メタ。waves[] のみ読む既存 consumer には影響しない後方互換の追加フィールド。",
    "phase_dependencies": PHASE_DEPS,
    "wave_dependencies": {str(k): v for k, v in wave_deps.items()},
    "parallel_groups": _levels,
    "max_depth": len(_levels),
}

doc = {
    "schema_version": 1, "pfp": "PFP-093",
    "task": task, "concurrency": conc,
    "effective_concurrency": eff_conc, "fanout_ceiling": fanout_ceiling,
    "fanout_degraded": fanout_degraded, "effective_cpu": eff_cpu,
    "dag": dag,
    "scope": scope,
    "total_roles": len(roles), "total_waves": len(waves),
    "roster_total_roles": roster_total,
    "claimed_capacity": claim,
    "dbl": {"name": DBL_NAME, "source": DBL_SOURCE, "injected": bool(DBL_DIGEST)},
    "strategic_plan_injected": bool(STRATEGIC_DIGEST),
    "domain_bridge": {"injected": bool(DOMAIN_BRIDGE_DIGEST), "lanes": DOMAIN_BRIDGE_LANES},
    "scale_bridge": {"injected": bool(SCALE_BRIDGE_DIGEST), "layers": SCALE_BRIDGE_LAYERS},
    "dbl_codegen": {"injected": bool(DBL_CODEGEN_DIGEST), "chars": len(DBL_CODEGEN_DIGEST)},
    "security_injection": {"injected": bool(SECINJ_DIGEST), "chars": len(SECINJ_DIGEST)},
    "cumulative_reclaim": {"injected": bool(CUMULATIVE_RECLAIM_DIGEST), "systems": CUMULATIVE_RECLAIM_SYSTEMS},
    "quality_loop": {"hints_injected": bool(QE_DIGEST), "hint_components": QE_HINTS_COUNT},
    "evidence_dir": evdir, "evidence_marker": marker,
    "waves": waves,
}
plan = os.environ["PLAN"]
tmp = plan + ".tmp"
with open(tmp, "w") as f:
    json.dump(doc, f, ensure_ascii=False, indent=2)
os.replace(tmp, plan)
phase_counts = {}
for w in waves:
    phase_counts[w["phase_label"]] = phase_counts.get(w["phase_label"],0) + w["agent_count"]
scope_note = f" (scope=claim: ロスター{roster_total}体から選抜)" if scope == "claim" and roster_total > len(roles) else ""
print(f"[PFP-093] dispatch-plan 生成: 全{len(roles)}ロール / {len(waves)}波 / 同時最大{conc}体{scope_note}")
print("  フェーズ別:", "  ".join(f"{k}={v}" for k,v in phase_counts.items()))
if DBL_DIGEST:
    print(f"  DBL digest 注入: {DBL_NAME} (source={DBL_SOURCE})")
if STRATEGIC_DIGEST:
    print("  strategic_plan.md 要点 注入: あり")
if DOMAIN_BRIDGE_DIGEST:
    print(f"  ドメイン資産ブリッジ注入: {', '.join(DOMAIN_BRIDGE_LANES) or '(該当レーン)'} "
          f"(Session① 蓄積資産→Desktop到達・{len(DOMAIN_BRIDGE_DIGEST)}字)")
if SCALE_BRIDGE_DIGEST:
    print(f"  規模層プラン注入: {SCALE_BRIDGE_LAYERS}層 "
          f"(Session⑤ 可変層/段階生成/累積レーン→Desktop到達・{len(SCALE_BRIDGE_DIGEST)}字)")
if DBL_CODEGEN_DIGEST:
    print(f"  業務ロジック実行コード化 義務 注入: {DBL_NAME} "
          f"(Session③ business_logic→算定関数+zod+単体テスト・{len(DBL_CODEGEN_DIGEST)}字)")
if SECINJ_DIGEST:
    print(f"  セキュリティ/権限/差別化 前段注入: あり "
          f"(S6 DLP/複数ロールRBAC/入力依存の差別化→Desktop到達・{len(SECINJ_DIGEST)}字)")
if CUMULATIVE_RECLAIM_DIGEST:
    print(f"  横展開累積レーン注入: {', '.join(CUMULATIVE_RECLAIM_SYSTEMS) or '(該当系統)'} "
          f"(第1波 内部統制/電帳法/解約ロック/検収/tenant-dna→Desktop到達・{len(CUMULATIVE_RECLAIM_DIGEST)}字)")
if QE_DIGEST:
    print(f"  品質閉ループヒント注入: {QE_HINTS_COUNT}成分 "
          f"(S11 書戻し inbox→次ビルド反映・{len(QE_DIGEST)}字)")
print(f"  -> {plan}")
PY

  # 権威ある実数源(live-manifest)を初期化 + 既存 agent-run-manifest も begin で同期
  _manifest_init "$pdir" "$task" "$conc"
  bash "$MANIFEST_SH" begin "$pdir" >/dev/null 2>&1 || true
}

_manifest_init() {
  local pdir="$1" task="$2" conc="$3"
  MF="$(_manifest_path "$pdir")" PLAN="$(_plan_path "$pdir")" TASK="$task" CONC="$conc" \
  CLAIM="$CLAIMED_CAPACITY" \
  python3 - <<'PY'
import json, os, time
plan = json.load(open(os.environ["PLAN"]))
doc = {
  "schema_version": 1, "pfp": "PFP-093",
  "engine": "claude-code-task-subagents (real)",
  "runtime": ("claude-code-desktop" if os.environ.get("CLAUDECODE")=="1" else "terminal"),
  "task": os.environ["TASK"], "concurrency": int(os.environ["CONC"]),
  "claimed_capacity": int(os.environ["CLAIM"]),
  "planned_roles": plan["total_roles"], "planned_waves": plan["total_waves"],
  "launched_agents": 0,          # ← 証跡から tally で更新する実数の唯一の源
  "evidence_valid": 0, "evidence_empty": 0, "evidence_duplicate": 0, "evidence_unknown_role": 0,
  "evidence_oversize": 0,        # soft 上限(既定4000バイト)超過数。有効計上のまま synthesis 側で切詰め (PFP-112)
  "roles_with_evidence": [],
  "waves_recorded": [],
  "started_at": int(time.time()), "finished_at": None,
}
mf = os.environ["MF"]; tmp = mf + ".tmp"
with open(tmp, "w") as f:
    json.dump(doc, f, ensure_ascii=False, indent=2)
os.replace(tmp, mf)
PY
}

# ------------------------------------------------------------------------------
# wave: 指定波のロール固有プロンプトを出力 (上位 Claude が Task を発行する材料)
#   --compact (PFP-103): 親セッションの文脈を肥大させない圧縮配信モード。
#     ロールID一覧だけを出し、各 Task の prompt は role-prompt 取得の1行に固定する。
#     これにより波あたり数千〜数万トークンの親コンテキスト二重計上を排除する。
# ------------------------------------------------------------------------------
_cmd_wave() {
  local pdir="${1:?project_dir required}"; local wno="${2:?wave_no required}"
  local mode="${3:-}"
  pdir="$(_norm "$pdir")"
  [ -f "$(_plan_path "$pdir")" ] || _die "先に plan を実行してください"
  PLAN="$(_plan_path "$pdir")" WNO="$wno" MODE="$mode" PDIR="$pdir" python3 - <<'PY'
import json, os, sys
plan = json.load(open(os.environ["PLAN"]))
wno = int(os.environ["WNO"])
pdir = os.environ["PDIR"]
w = next((x for x in plan["waves"] if x["wave_no"]==wno), None)
if not w:
    print(f"波 {wno} は存在しません (全{plan['total_waves']}波)", file=sys.stderr); sys.exit(2)
if os.environ.get("MODE") == "--compact":
    print(f"# Wave {wno}/{plan['total_waves']}  フェーズ={w['phase_label']}  起動数={w['agent_count']} (圧縮配信/PFP-103)")
    print(f"# 下記 {w['agent_count']} 体を 1 メッセージ内で同時に Task 発行してください(=実並列起動)。")
    print(f"# 各 Task の prompt は次の1行のみ (<ROLE_ID> を置換。全文を貼らない):")
    print(f'#   bash ~/.soloptilink/lib/centuria-live-orchestrator.sh role-prompt "{pdir}" <ROLE_ID> を実行し、出力された指示に厳密に従って作業せよ。')
    for a in w["agents"]:
        print(f"{a['id']}\t{a['title']}")
else:
    print(f"# Wave {wno}/{plan['total_waves']}  フェーズ={w['phase_label']}  起動数={w['agent_count']}")
    print(f"# 下記 {w['agent_count']} 体を 1 メッセージ内で同時に Task 発行してください(=実並列起動)")
    for a in w["agents"]:
        print("="*70)
        print(f"## ROLE: {a['id']}  ({a['title']})  evidence={a['evidence_path']}")
        print(a["prompt"])
PY
}

# ------------------------------------------------------------------------------
# role-prompt: 単一ロールのプロンプトを出力 (PFP-103 圧縮配信の子エージェント側取得口)
#   子 Task が自分でこれを実行して指示を取得する。親はロールIDだけ知っていればよい。
# ------------------------------------------------------------------------------
_cmd_role_prompt() {
  local pdir="${1:?project_dir required}"; local rid="${2:?role_id required}"
  pdir="$(_norm "$pdir")"
  [ -f "$(_plan_path "$pdir")" ] || _die "先に plan を実行してください"
  PLAN="$(_plan_path "$pdir")" RID="$rid" python3 - <<'PY'
import json, os, sys
plan = json.load(open(os.environ["PLAN"]))
rid = os.environ["RID"]
for w in plan["waves"]:
    for a in w["agents"]:
        if a["id"] == rid:
            print(a["prompt"]); sys.exit(0)
print(f"ロール {rid} は plan に存在しません", file=sys.stderr); sys.exit(2)
PY
}

# ------------------------------------------------------------------------------
# 証跡走査の共通ロジック (tally/summary/verify が同一基準で使う)
#   有効条件: マーカー有 + 本文 >= minch + 内容ハッシュ非重複 + roレスター実在ID由来
# ------------------------------------------------------------------------------
_scan_evidence() {  # 引数: pdir / 出力: JSON {valid,empty,duplicate,unknown_role,oversize,roles[]}
  EVDIR="$(_evidence_dir "$1")" PLAN="$(_plan_path "$1")" \
  MARKER="$EVIDENCE_MARKER" MINCH="$EVIDENCE_MIN_CHARS" \
  SOFTCAP="$EVIDENCE_SOFT_CAP_BYTES" \
  python3 - <<'PY'
import json, os, glob, hashlib, sys
evdir = os.environ["EVDIR"]; marker = os.environ["MARKER"]; minch = int(os.environ["MINCH"])
softcap = int(os.environ["SOFTCAP"])
# ロスター実在ID (plan 由来)。plan が無ければ照合をスキップ(None)
allowed = None
try:
    plan = json.load(open(os.environ["PLAN"]))
    allowed = {a["id"] for w in plan["waves"] for a in w["agents"]}
except Exception:
    allowed = None
valid=empty=dup=unknown=oversize=0; seen=set(); roles=[]
for f in sorted(glob.glob(os.path.join(evdir, "*.md"))):
    rid = os.path.basename(f)[:-3]
    try: body = open(f, encoding="utf-8", errors="ignore").read()
    except Exception: continue
    if marker not in body:
        continue
    if allowed is not None and rid not in allowed:
        unknown += 1; continue          # ロスター外ファイル = 偽装の疑い → 計上しない
    content = body.split("-->",1)[-1].strip() if "-->" in body else body
    if len(content) < minch:
        empty += 1; continue
    h = hashlib.sha256(content.encode("utf-8","ignore")).hexdigest()
    if h in seen:
        dup += 1; continue
    # soft 上限超過は有効のまま計上し、synthesis 側で切詰められる旨を可視化する (PFP-112)
    if len(content.encode("utf-8", "ignore")) > softcap:
        oversize += 1
    seen.add(h); valid += 1; roles.append(rid)
print(json.dumps({"valid":valid,"empty":empty,"duplicate":dup,
                  "unknown_role":unknown,"oversize":oversize,"roles":roles}, ensure_ascii=False))
PY
}

# ------------------------------------------------------------------------------
# tally: 証跡を走査し、実起動数(=有効証跡数)を manifest に反映
# ------------------------------------------------------------------------------
_cmd_tally() {
  local pdir="${1:?project_dir required}"; pdir="$(_norm "$pdir")"
  local mf; mf="$(_manifest_path "$pdir")"
  [ -f "$mf" ] || _die "manifest が見つかりません。先に plan を実行してください: $mf"
  local scan; scan="$(_scan_evidence "$pdir")" || _die "証跡の走査に失敗しました"
  MF="$mf" SCAN="$scan" python3 - <<'PY'
import json, os, sys
mf = os.environ["MF"]
try:
    with open(mf) as f:
        doc = json.load(f)
except (OSError, ValueError):
    print("manifest が読み取れません (破損の可能性)。'plan' で作り直してください", file=sys.stderr)
    raise SystemExit(2)
s = json.loads(os.environ["SCAN"])
doc["launched_agents"]      = s["valid"]
doc["evidence_valid"]       = s["valid"]
doc["evidence_empty"]       = s["empty"]
doc["evidence_duplicate"]   = s["duplicate"]
doc["evidence_unknown_role"]= s["unknown_role"]
doc["evidence_oversize"]    = s.get("oversize", 0)
doc["roles_with_evidence"]  = s["roles"]
tmp = mf + ".tmp"
with open(tmp, "w") as f:
    json.dump(doc, f, ensure_ascii=False, indent=2)
os.replace(tmp, mf)
extra = f" / ロスター外{s['unknown_role']}(計上外)" if s["unknown_role"] else ""
if s.get("oversize"):
    extra += f" / soft上限超過{s['oversize']}(統合時切詰め)"
print(f"[PFP-093] 実証跡: 有効{s['valid']} / 空・短文{s['empty']} / 重複{s['duplicate']}{extra}  (実起動数={s['valid']})")
PY
}

# ------------------------------------------------------------------------------
# verify: 有効証跡 >= min(既定105) なら exit 0。証跡ベースの完成ゲート
#   tally の失敗を握り潰さず、manifest 不在/破損は FAIL として安全に報告する
# ------------------------------------------------------------------------------
_cmd_verify() {
  local pdir="${1:?project_dir required}"; pdir="$(_norm "$pdir")"
  local minv="${2:-$CLAIMED_CAPACITY}"
  local mf; mf="$(_manifest_path "$pdir")"
  if [ ! -f "$mf" ]; then
    echo "{\"pfp\":\"PFP-093\",\"verdict\":\"FAIL\",\"evidence_valid\":0,\"required_min\":$minv,\"reason\":\"manifest_missing\"}"
    echo -e "${C_RD}❌ PFP-093 FAIL: manifest 不在。先に plan→各波Task起動→tally を実行してください${C_NC}" >&2
    return 1
  fi
  # tally を実行 (失敗は握り潰さない)。失敗時は FAIL を返す
  if ! _cmd_tally "$pdir" >/dev/null 2>&1; then
    echo "{\"pfp\":\"PFP-093\",\"verdict\":\"FAIL\",\"evidence_valid\":0,\"required_min\":$minv,\"reason\":\"tally_failed\"}"
    echo -e "${C_RD}❌ PFP-093 FAIL: 証跡集計に失敗しました (manifest 破損の可能性)${C_NC}" >&2
    return 1
  fi
  local _vrc=0
  MF="$mf" MIN="$minv" python3 - <<'PY' || _vrc=$?
import json, os, sys
mf = os.environ["MF"]; minv = int(os.environ["MIN"])
try:
    d = json.load(open(mf))
except (OSError, ValueError):
    print(json.dumps({"pfp":"PFP-093","verdict":"FAIL","evidence_valid":0,
                      "required_min":minv,"reason":"manifest_unreadable"}, ensure_ascii=False))
    raise SystemExit(1)
v = int(d.get("evidence_valid", 0))
ok = v >= minv
print(json.dumps({
  "pfp":"PFP-093","verdict":"PASS" if ok else "FAIL",
  "evidence_valid": v, "required_min": minv,
  "evidence_empty": d.get("evidence_empty",0),
  "evidence_duplicate": d.get("evidence_duplicate",0),
  "evidence_unknown_role": d.get("evidence_unknown_role",0),
}, ensure_ascii=False))
if ok:
    sys.stderr.write(f"\033[0;32m✅ PFP-093 PASS: 実エージェント {v} 体が実際に成果物を残しました (要件 {minv} 体以上)\033[0m\n")
else:
    sys.stderr.write(f"\033[0;31m❌ PFP-093 FAIL: 実起動 {v} 体 < 要件 {minv} 体。未起動ロールの Task を追加発行してください\033[0m\n")
sys.exit(0 if ok else 1)
PY
  # ── S11 quality-elevation 生産側: 完成(verify PASS)時の品質書戻し(閉ループの生産側配線) ──
  # verify PASS 時のみ、生成物の品質4成分を quality-elevation/compose 経由で合成し tenant-dna inbox へ
  # append-only 書戻しする(次ビルドの plan が consume して refiner ヒントとして注入する)。
  # 書戻し失敗・資産欠落・kill-switch off は全て無処理素通り=verify の判定/exit code は不変。
  # sandbox/fixture ガード: 一時領域・fixture 配下の検証実走からは書き戻さない(本番 inbox 汚染防止)。
  if [[ "$_vrc" -eq 0 && "${ENABLE_QUALITY_ELEVATION:-auto}" != "off" \
        && -f "$SL/lib/quality-elevation/feedback-writeback.sh" ]]; then
    # sandbox 判定は pdir と同じ realpath 正規化を通す (w1 QLOOP-SH-01: pdir は _norm 済のため
    # 生 $TMPDIR (/var/folders/…) と realpath (/private/var/folders/…) が不一致でガード素通りした)。
    # ${var%/} の case パターン内インライン展開は bash 5.3 で空展開時にマッチ不能になる癖があるため
    # 事前に変数へ落とす (w1 QLOOP-SH-02)。末尾多重スラッシュ・"/"・空も無害化。
    local _qe_tmpraw="${TMPDIR:-/nonexistent-tmpdir}"
    while [[ "$_qe_tmpraw" == */ && "$_qe_tmpraw" != "/" ]]; do _qe_tmpraw="${_qe_tmpraw%/}"; done
    [[ -z "$_qe_tmpraw" || "$_qe_tmpraw" == "/" ]] && _qe_tmpraw="/nonexistent-tmpdir"
    local _qe_tmpnorm
    _qe_tmpnorm="$(_norm "$_qe_tmpraw" 2>/dev/null || echo /nonexistent-tmpdir)"
    [[ -z "$_qe_tmpnorm" || "$_qe_tmpnorm" == "/" ]] && _qe_tmpnorm="/nonexistent-tmpdir"
    case "$pdir" in
      /tmp/*|/private/tmp/*|/var/folders/*|/private/var/folders/*|"$_qe_tmpraw"/*|"$_qe_tmpnorm"/*|"$HOME"/.cache/*|*/fixtures/*) : ;;
      *)
        # 実測ゲート結果を1つ以上持つ実プロジェクトのみ書き戻す(空 compose レコードのノイズ防止)。
        # 実ゲートの実出力名 synonym (w2 QLOOP2-03/W2-04): compose.sh の ch_files と対称にしないと、
        # runtime-login-smoke.json / runtime-depth-results.json だけを持つプロジェクトが _qe_has=0 で
        # 弾かれ、フックが発火しない。compose 側の synonym と揃える (H1 修正の完全対称化)。
        local _qe_has=0 _qe_f
        for _qe_f in differentiation-insight-results.json layered-depth-results.json \
                     runtime-login-smoke-results.json runtime-login-smoke.json \
                     runtime-crud-smoke-results.json \
                     runtime-depth-probe-results.json runtime-depth-results.json \
                     dbl-logic-codegen-audit.json; do
          [[ -f "$pdir/.soloptilink/$_qe_f" ]] && { _qe_has=1; break; }
        done
        if [[ "$_qe_has" -eq 1 ]]; then
          # 同日 dedup (w1 QLOOP-PERF-03): verify PASS を再実行するたびの同一プロジェクト重複 append を
          # 抑止 (当日 inbox に同 project_dir のレコードが既にあれば skip)。inbox は append-only のまま。
          local _qe_dup=0 _qe_inbox=""
          _qe_inbox="$(bash "$SL/lib/quality-elevation/feedback-writeback.sh" inbox-path 2>/dev/null || true)"
          if [[ -n "$_qe_inbox" && -f "$_qe_inbox" ]] && grep -qF "\"project_dir\": \"$pdir\"" "$_qe_inbox" 2>/dev/null; then
            _qe_dup=1
          fi
          if [[ "$_qe_dup" -eq 0 ]]; then
            local _qe_ind="${SOLOPTILINK_DETECTED_DBL:-}"
            if [[ -z "$_qe_ind" ]]; then
              _qe_ind="$(PLAN="$(_plan_path "$pdir")" python3 -c 'import json,os; d=json.load(open(os.environ["PLAN"])); print(d.get("dbl",{}).get("name") or "")' 2>/dev/null || true)"
            fi
            if [[ -n "$_qe_ind" ]]; then
              bash "$SL/lib/quality-elevation/feedback-writeback.sh" writeback "$pdir" --industry "$_qe_ind" >/dev/null 2>&1 || true
            else
              bash "$SL/lib/quality-elevation/feedback-writeback.sh" writeback "$pdir" >/dev/null 2>&1 || true
            fi
          fi
        fi
      ;;
    esac
  fi

  # ── PFP-165 実起動累積台帳 追記 (v2052.0 キャンビィ様事案根絶) ──
  # verify PASS 時のみ、agent-evidence/*.md から実起動記録を HMAC chain 付きで
  # ~/.soloptilink/var/execution-ledger/ledger.jsonl に追記する。
  # 過去ビルドの実起動が独立検証可能になり、エンジニアが後日 evidence --verify で
  # 台帳整合性を再計算できるようになる (改竄検知含む)。
  # kill-switch: SOLOPTILINK_LEDGER_DISABLE=1 または ENABLE_EXECUTION_LEDGER=off
  # sandbox/fixture ガード: 一時領域からの verify では台帳汚染しない (本番プロジェクトのみ)
  if [[ "$_vrc" -eq 0 && "${SOLOPTILINK_LEDGER_DISABLE:-0}" != "1" \
        && "${ENABLE_EXECUTION_LEDGER:-auto}" != "off" \
        && -f "$SL/lib/execution-ledger/ledger-appender.sh" ]]; then
    local _el_tmpraw="${TMPDIR:-/nonexistent-tmpdir}"
    while [[ "$_el_tmpraw" == */ && "$_el_tmpraw" != "/" ]]; do _el_tmpraw="${_el_tmpraw%/}"; done
    [[ -z "$_el_tmpraw" || "$_el_tmpraw" == "/" ]] && _el_tmpraw="/nonexistent-tmpdir"
    local _el_tmpnorm
    _el_tmpnorm="$(_norm "$_el_tmpraw" 2>/dev/null || echo /nonexistent-tmpdir)"
    [[ -z "$_el_tmpnorm" || "$_el_tmpnorm" == "/" ]] && _el_tmpnorm="/nonexistent-tmpdir"
    case "$pdir" in
      /tmp/*|/private/tmp/*|/var/folders/*|/private/var/folders/*|"$_el_tmpraw"/*|"$_el_tmpnorm"/*|"$HOME"/.cache/*|*/fixtures/*|*/tests/*) : ;;
      *)
        # run_id をプロジェクトディレクトリ名+タイムスタンプで生成
        local _el_run_id
        _el_run_id="BUILD-$(basename "$pdir")-$(date -u +%Y%m%dT%H%M%SZ 2>/dev/null || echo unknown)"
        (
          # サブシェルで source (親環境への副作用を排除)
          source "$SL/lib/execution-ledger/ledger-appender.sh" 2>/dev/null
          ledger_append_build_from_project "$_el_run_id" "$pdir" >/dev/null 2>&1
        ) || true
      ;;
    esac
  fi

  return "$_vrc"
}

# ------------------------------------------------------------------------------
# report: 完了報告用の正直な一行 (実数のみ)
# ------------------------------------------------------------------------------
_cmd_report() {
  local pdir="${1:?project_dir required}"; pdir="$(_norm "$pdir")"
  _cmd_tally "$pdir" >/dev/null 2>&1 || true
  MF="$(_manifest_path "$pdir")" RTOTAL="$ROSTER_TOTAL" python3 - <<'PY'
import json, os
try:
    d = json.load(open(os.environ["MF"]))
except Exception:
    print("🤖 実起動: 記録なし (先に plan→Task起動→tally を実行)"); raise SystemExit(0)
v = d.get("evidence_valid",0); planned = d.get("planned_roles",0)
rt = d.get("runtime","?"); claim = d.get("claimed_capacity",105); rtotal = os.environ.get("RTOTAL","?")
print(f"🤖 実起動エージェント: {v}体が実際に成果物を生成 (計画{planned}ロール / 実行基盤: Claude Code Task並列 / runtime={rt})")
print(f"   主張する{claim}体以上を満たし、実在ロスター{rtotal}体のうち{v}体が証跡付きで完走 (証跡: .soloptilink/agent-evidence/)")
PY
}

# ------------------------------------------------------------------------------
# summary: 人間可読の波・フェーズ・進捗 (tally と同一基準で集計)
# ------------------------------------------------------------------------------
_cmd_summary() {
  local pdir="${1:?project_dir required}"; pdir="$(_norm "$pdir")"
  [ -f "$(_plan_path "$pdir")" ] || _die "先に plan を実行してください"
  local scan; scan="$(_scan_evidence "$pdir")" || scan='{"roles":[]}'
  PLAN="$(_plan_path "$pdir")" SCAN="$scan" python3 - <<'PY'
import json, os
plan = json.load(open(os.environ["PLAN"]))
done = set(json.loads(os.environ["SCAN"]).get("roles", []))   # tally と同一の有効判定済み
print("="*64)
print(f"  Centuria Live Orchestrator — 進捗 (PFP-093)")
print(f"  計画: 全{plan['total_roles']}ロール / {plan['total_waves']}波 / 同時最大{plan['concurrency']}体")
print(f"  有効証跡: {len(done)} / {plan['total_roles']}  (tally と同一基準)")
print("-"*64)
for w in plan["waves"]:
    ids = [a["id"] for a in w["agents"]]
    d = sum(1 for i in ids if i in done)
    bar = "✅" if d==len(ids) else ("🔄" if d>0 else "⬚")
    print(f"  {bar} Wave {w['wave_no']:>2} [{w['phase_label']:<10}] {d}/{len(ids)} 起動済")
print("="*64)
PY
}

# ------------------------------------------------------------------------------
# prove: 顧客向け「105体実証」エントリ (plan + 実行案内)
# ------------------------------------------------------------------------------
_cmd_prove() {
  local pdir="${1:?project_dir required}"; local task="${2:?task_desc required}"; local conc="${3:-12}"
  _cmd_plan "$pdir" "$task" "$conc" "all"
  pdir="$(_norm "$pdir")"
  echo ""
  echo -e "${C_CY}── 105体実証の進め方 ─────────────────────────────${C_NC}"
  echo "  1) 各波のプロンプトを取得:  centuria-live-orchestrator.sh wave \"$pdir\" <波番号>"
  echo "  2) 上位 Claude が各波を Task で同時発行(実並列起動)"
  echo "  3) 波ごとに集計:           centuria-live-orchestrator.sh tally \"$pdir\""
  echo "  4) 最終検証(105体以上):    centuria-live-orchestrator.sh verify \"$pdir\""
  echo "  5) 正直な報告:             centuria-live-orchestrator.sh report \"$pdir\""
}

# ------------------------------------------------------------------------------
# verify-adversarial: 敵対的検証波 (adversarial フェーズ) が実際に走り、反証ロールの
#   証跡が min(既定2)体以上残っているかを検証する (PFP-125)。既定 verify(105) とは独立で、
#   「敵対的検証が実装前に必ず実行された」ことの完成ゲートとして使う。
# ------------------------------------------------------------------------------
_cmd_verify_adversarial() {
  local pdir="${1:?project_dir required}"; pdir="$(_norm "$pdir")"
  # v2055: 反証ロールを 7 体へ増強したのに伴い、実効反証証跡の既定要件を 2→3 へ引き上げ
  #   (effective_min = min(minv, planned) のため計画数が少ない小規模ビルドは従来通り安全)。
  local minv="${2:-3}"
  local plan; plan="$(_plan_path "$pdir")"
  local evdir; evdir="$(_evidence_dir "$pdir")"
  if [ ! -f "$plan" ]; then
    echo "{\"pfp\":\"PFP-125\",\"verdict\":\"FAIL\",\"adversarial_evidence\":0,\"required_min\":$minv,\"reason\":\"plan_missing\"}"
    echo -e "${C_RD}❌ PFP-125 FAIL: dispatch-plan 不在。先に plan を実行してください${C_NC}" >&2
    return 1
  fi
  PLAN="$plan" EVDIR="$evdir" MARKER="$EVIDENCE_MARKER" MIN="$minv" MINCHARS="$EVIDENCE_MIN_CHARS" python3 - <<'PY'
import json, os, sys
plan = json.load(open(os.environ["PLAN"]))
evdir = os.environ["EVDIR"]; marker = os.environ["MARKER"]
minv = int(os.environ["MIN"]); minchars = int(os.environ["MINCHARS"])
adv_ids = set()
for w in plan.get("waves", []):
    for a in w.get("agents", []):
        if a.get("phase") == "adversarial":
            adv_ids.add(a["id"])
planned_adv = len(adv_ids)
# 【PFP-125 強化 (L8)】「証跡が長いだけ」を反証とみなす false-PASS を可視化する。
# 反証シグナル = 失敗モード/反例/エッジ/破綻/前提/権限/境界/要検証 等を含む実質的な反証語彙。
# 注: verify の PASS/FAIL は従来どおり長さ(>=minchars)基準のまま (verify-all PFP-125b の契約維持)。
#     実質 (反証台帳の中身) の厳格判定は ledger / verify-ledger サブコマンドが担う。
import re as _re
# v2051 session2 backlog#1: 英語トークンは語境界 \b で囲む。旧実装は `refuter` が
# `refute` に substring 一致してロール名を反証シグナルとして誤検出していた。
# 日本語トークンは word-boundary の概念が別 (kanji/kana 連接) のため \b を付けない。
_SIGNAL = _re.compile(r"(反証|反例|失敗|破綻|壊れ|脆弱|リスク|前提|不整合|矛盾|競合|境界|権限|"
                      r"見落と|漏れ|未対応|不足|違反|エッジ|要検証|"
                      r"\brace\b|\bedge\b|\bfail\b|\bvuln\b|"
                      r"\bmissing\b|\bassumption\b|\bbroken\b|\brisk\b|\brefute\b)", _re.I)
valid = 0
refutation_valid = 0   # 反証シグナルを実際に含む証跡数 (実質的な反証か)
for rid in adv_ids:
    f = os.path.join(evdir, rid + ".md")
    try:
        body = open(f, encoding="utf-8", errors="ignore").read()
    except OSError:
        continue
    if marker not in body:
        continue
    content = body.split("-->", 1)[-1].strip() if "-->" in body else body.strip()
    if len(content) >= minchars:
        valid += 1
        if _SIGNAL.search(content):
            refutation_valid += 1
# false-PASS 検知: 反証ロールの証跡は十分な長さで在るのに、反証シグナルを1つも含まない
# (=他ロールの追認/空回し)。長さ基準は満たすため verify は PASS だが、注意喚起する。
false_pass_risk = (valid > 0 and refutation_valid == 0)
# 【PFP-125 v2055 循環しきい値の是正 (敵対レビュー #10)】
# 旧実装は effective = min(minv, planned_adv) と「検証対象 plan 自身の敵対員数」でしきい値を
# 頭打ちにしていたため、敵対ロール1体だけの過少編成 plan が証跡1件で自己認証できてしまう
# 循環参照だった。合格判定を「計画が十分に敵対波を編成したか (員数)」と「実証跡が残ったか」の
# 2軸に分離し、前者を plan 自身から導かない独立床 ADV_FLOOR (=3・claim選抜側の床と一致) で判定する。
ADV_FLOOR = 3
# plan が確保すべき最低反証数。呼び出し側が minv を明示的に低く指定した場合はその意思を尊重する
# (min(minv, ADV_FLOOR))。既定 minv=3 では plan_floor=3 となり、過少編成 (planned_adv<3) を弾く。
plan_floor = min(minv, ADV_FLOOR)
effective = min(minv, planned_adv) if planned_adv > 0 else minv
# 合格 = ①敵対波が独立床以上に編成されている ∧ ②実証跡が独立床以上 ∧ ③実証跡が実効min以上。
ok = (planned_adv >= plan_floor) and (valid >= plan_floor) and (valid >= effective)
under_provisioned = planned_adv < plan_floor
print(json.dumps({"pfp":"PFP-125","verdict":"PASS" if ok else "FAIL",
                  "adversarial_evidence": valid, "refutation_evidence": refutation_valid,
                  "false_pass_risk": false_pass_risk, "planned_adversarial": planned_adv,
                  "required_min": minv, "effective_min": effective,
                  "plan_floor": plan_floor, "under_provisioned": under_provisioned}, ensure_ascii=False))
if under_provisioned:
    sys.stderr.write(f"\033[0;31m❌ PFP-125 FAIL: 敵対波の編成が過少です (planned={planned_adv} < 独立床={plan_floor})。"
                     f"roster から正しく plan すれば反証ロールは最低 {ADV_FLOOR} 体確保されます。plan を再生成してください\033[0m\n")
if ok and false_pass_risk:
    sys.stderr.write("\033[1;33m⚠ PFP-125 注意: 反証ロールは証跡を残しましたが反証シグナル(失敗モード/反例/リスク等)を検出できません。"
                     "ledger→verify-ledger で反証台帳の実質と解消状況を厳格確認してください\033[0m\n")
if ok:
    sys.stderr.write(f"\033[0;32m✅ PFP-125 PASS: 敵対的検証波で {valid} 体の反証ロールが実際に検証を残しました "
                     f"(うち反証シグナル有 {refutation_valid} 体 / 実効要件 {effective} 体以上 / 計画 {planned_adv} 体)\033[0m\n")
elif planned_adv == 0:
    sys.stderr.write(f"\033[0;31m❌ PFP-125 FAIL: 敵対的検証波が編成されていません (planned_adversarial=0)。refuter/skeptic/falsifier を plan に含めてください\033[0m\n")
else:
    sys.stderr.write(f"\033[0;31m❌ PFP-125 FAIL: 反証証跡 {valid} < 実効要件 {effective} (計画 {planned_adv} 体)。adversarial 波の Task を発行してください\033[0m\n")
sys.exit(0 if ok else 1)
PY
}

# ------------------------------------------------------------------------------
# _mirror_ledger_to_review: 反証台帳(JSON が SoT)を centuria-blueprint-review.md へ
#   機械可読ブロックとしてミラーする (集約先 = 設計上の反証台帳)。冪等(マーカーで差替)。
# ------------------------------------------------------------------------------
_mirror_ledger_to_review() {
  LEDGER="$(_ledger_path "$1")" REVIEW="$(_review_bp_path "$1")" python3 - <<'PY' 2>/dev/null || true
import json, os
ledger = os.environ["LEDGER"]; review = os.environ["REVIEW"]
try:
    d = json.load(open(ledger, encoding="utf-8"))
except Exception:
    raise SystemExit(0)
BEGIN = "<!-- CENTURIA-REBUTTAL-LEDGER:BEGIN -->"
END   = "<!-- CENTURIA-REBUTTAL-LEDGER:END -->"
lines = [BEGIN, "", "## 反証台帳 (機械抽出・完成前に全件 resolved 必須 / PFP-125)", ""]
findings = d.get("findings", [])
if not findings:
    if d.get("false_pass_risk"):
        lines.append("- ⚠ 反証ロールは走りましたが反証指摘を抽出できませんでした (false-PASS の疑い・実質的な反証を求めてください)")
    else:
        lines.append("- (反証指摘なし)")
for f in findings:
    mark = "✅解消済" if (f.get("status") == "resolved" and f.get("resolution")) else "⬜未解消"
    res  = (" — 解消: " + f["resolution"]) if f.get("resolution") else ""
    lines.append(f"- [{mark}] `{f.get('id','?')}` ({f.get('role','?')}) {f.get('text','')}{res}")
lines += ["", END, ""]
block = "\n".join(lines)
body = ""
if os.path.isfile(review):
    body = open(review, encoding="utf-8", errors="ignore").read()
if BEGIN in body and END in body:
    pre = body.split(BEGIN, 1)[0]; post = body.split(END, 1)[1]
    body = pre + block + post
else:
    body = (body.rstrip() + "\n\n" + block) if body else (
        "<!-- Centuria 品質・セキュリティ・レビュー統合 (反証台帳同梱) -->\n\n" + block)
tmp = review + ".tmp"
open(tmp, "w", encoding="utf-8").write(body)
os.replace(tmp, review)
PY
}

# ------------------------------------------------------------------------------
# ledger: 敵対的検証波(adversarial フェーズ)の証跡から反証指摘を機械抽出し、反証台帳
#   (centuria-rebuttal-ledger.json) に集約する。既存台帳の解消状況は finding-id で保全。
#   指摘の真偽は「実エージェントが書いた証跡から抽出」する(自己申告でない)。
# ------------------------------------------------------------------------------
_cmd_ledger() {
  local pdir="${1:?project_dir required}"; pdir="$(_norm "$pdir")"
  [ -f "$(_plan_path "$pdir")" ] || _die "先に plan を実行してください"
  PLAN="$(_plan_path "$pdir")" EVDIR="$(_evidence_dir "$pdir")" \
  LEDGER="$(_ledger_path "$pdir")" MARKER="$EVIDENCE_MARKER" MINCH="$EVIDENCE_MIN_CHARS" \
  python3 - <<'PY'
import json, os, re, glob, hashlib, datetime
plan_p = os.environ["PLAN"]; evdir = os.environ["EVDIR"]; ledger = os.environ["LEDGER"]
marker = os.environ["MARKER"]; minch = int(os.environ["MINCH"])
plan = json.load(open(plan_p, encoding="utf-8"))
adv_ids = [a["id"] for w in plan.get("waves", []) for a in w.get("agents", []) if a.get("phase") == "adversarial"]

# v2051 session2 backlog#1: 英語トークンは語境界 \b で囲む (上の _SIGNAL と同期)。
SIGNAL = re.compile(r"(反証|反例|失敗|破綻|壊れ|脆弱|リスク|前提|不整合|矛盾|競合|境界|権限|"
                    r"見落と|漏れ|未対応|不足|違反|エッジ|要検証|"
                    r"\brace\b|\bedge\b|\bfail\b|\bvuln\b|"
                    r"\bmissing\b|\bassumption\b|\bbroken\b|\brisk\b|\brefute\b)", re.I)
MAX_FINDINGS = 40

def norm(t):
    return re.sub(r"\s+", " ", t).strip()

def fid(role, text):
    return hashlib.sha1((role + "|" + norm(text)).encode("utf-8", "ignore")).hexdigest()[:10]

# v2043 L8: resolution_quality — 解消の *質* を 0.0-1.0 で採点 (再ランクの入力・cross-session-learning が消費)。
#   解消判定 (status=resolved かつノート>=8字) は不変。本スコアは追加情報であり判定を緩めない (後方互換)。
def rquality(status, note):
    note = (note or "").strip()
    if status != "resolved" or len(note) < 8:
        return 0.0
    score = 0.4  # 有効な解消ノートの基礎点
    if len(note) >= 30:
        score += 0.2
    if re.search(r"(修正|対応|実装|追加|配線|テスト|検証|ガード|zod|トランザクション|FK|ロック|境界|削除)", note):
        score += 0.25  # 具体的な修復行為への言及
    if re.search(r"\.(ts|tsx|prisma|sh|js|sql)\b|/", note):
        score += 0.15  # 具体的なファイル/パス参照
    return round(min(1.0, score), 2)

# 既存台帳の解消状況を保全 (id -> {status, resolution, resolution_quality}) ※後方互換: 旧台帳に quality 無くても可
prev = {}
try:
    old = json.load(open(ledger, encoding="utf-8"))
    for f in old.get("findings", []):
        prev[f.get("id")] = {"status": f.get("status", "open"), "resolution": f.get("resolution", ""),
                             "resolution_quality": f.get("resolution_quality")}
except Exception:
    prev = {}

evidence_present = False
findings = []
seen = set()
for rid in adv_ids:
    p = os.path.join(evdir, rid + ".md")
    try:
        body = open(p, encoding="utf-8", errors="ignore").read()
    except OSError:
        continue
    if marker not in body:
        continue
    content = body.split("-->", 1)[-1].strip() if "-->" in body else body.strip()
    if len(content) < minch:
        continue
    evidence_present = True
    # 1) 箇条書き/番号付き行のうち反証シグナルを含むものを finding として抽出
    extracted = []
    for ln in content.splitlines():
        s = ln.strip()
        # 箇条書き記号: 半角 -/*、和文 ・/●、番号付き。
        # v2051 session2 backlog#2: 見出し行 (#{1,4}) はレポート構造の見出しであり
        # 反証指摘そのものではないため抽出対象から除外する (旧実装は
        # 見出しにシグナル語が含まれると findings に混入していた)。
        m = re.match(r"^([-*]\s+|[・●]\s*|\d+[.)]\s+)(.+)$", s)
        if not m:
            continue
        txt = norm(m.group(2))
        if len(txt) >= 8 and SIGNAL.search(txt):
            extracted.append(txt[:200])
    # 2) フォールバック: 箇条書きが無くても反証シグナルを含む文を最大3件拾う
    if not extracted:
        for seg in re.split(r"[。\n]", content):
            seg = norm(seg)
            if len(seg) >= 12 and SIGNAL.search(seg):
                extracted.append(seg[:200])
            if len(extracted) >= 3:
                break
    for txt in extracted:
        i = fid(rid, txt)
        if i in seen:
            continue
        seen.add(i)
        st = prev.get(i, {})
        _status = st.get("status", "open"); _res = st.get("resolution", "")
        _rq = st.get("resolution_quality")
        if _rq is None:
            _rq = rquality(_status, _res)   # 旧台帳からの移行: 既存ノートから後方互換で再採点
        findings.append({"id": i, "role": rid, "text": txt,
                         "status": _status,
                         "resolution": _res,
                         "resolution_quality": _rq})

capped = len(findings) > MAX_FINDINGS
if capped:
    findings = findings[:MAX_FINDINGS]

false_pass_risk = evidence_present and len(findings) == 0
# 解消判定は verify-ledger と統一: status=resolved かつ解消ノート >=8字 のみ「解消」
open_count = sum(1 for f in findings
                 if f.get("status") != "resolved" or len((f.get("resolution") or "").strip()) < 8)
doc = {
    "schema_version": 1, "pfp": "PFP-125-ledger",
    "task": plan.get("task", ""),
    "adversarial_roles_planned": len(adv_ids),
    "adversarial_evidence_present": evidence_present,
    "false_pass_risk": false_pass_risk,
    "findings_total": len(findings),
    "open_count": open_count,
    "resolved_count": len(findings) - open_count,
    "avg_resolution_quality": (round(sum(f.get("resolution_quality", 0.0) for f in findings) / len(findings), 3) if findings else 0.0),
    "capped": capped,
    "generated_at": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "findings": findings,
}
tmp = ledger + ".tmp"
with open(tmp, "w", encoding="utf-8") as f:
    json.dump(doc, f, ensure_ascii=False, indent=2)
os.replace(tmp, ledger)
print(f"[PFP-125 ledger] 反証台帳: 指摘 {len(findings)} 件 (未解消 {open_count} / 解消 {len(findings)-open_count})"
      + (" / ⚠ false-PASS の疑い(反証証跡あるが反証指摘0)" if false_pass_risk else "")
      + (" / 上限超過のため切詰め" if capped else ""))
print(f"  -> {ledger}")
PY
  _mirror_ledger_to_review "$pdir"
}

# ------------------------------------------------------------------------------
# resolve: 反証台帳の指摘を「解消済」にする (非空の解消ノート必須・空解消の自己申告禁止)
# ------------------------------------------------------------------------------
_cmd_resolve() {
  local pdir="${1:?project_dir required}"; pdir="$(_norm "$pdir")"
  local fidv="${2:?finding_id required}"; shift 2 2>/dev/null || true
  local note="$*"
  [ -n "$note" ] && [ "${#note}" -ge 8 ] || _die "解消ノート(8文字以上)を指定してください。例: resolve <pdir> <id> 'server action に zod 検証と FK 整合チェックを追加'"
  local led; led="$(_ledger_path "$pdir")"
  [ -f "$led" ] || _die "反証台帳が未生成です。先に ledger を実行してください: $led"
  LEDGER="$led" FID="$fidv" NOTE="$note" python3 - <<'PY'
import json, os, sys, re
led = os.environ["LEDGER"]; fidv = os.environ["FID"]; note = os.environ["NOTE"].strip()
# v2043 L8: resolution_quality 採点 (ledger と同一基準・解消判定は変えない)
def rquality(status, note):
    note = (note or "").strip()
    if status != "resolved" or len(note) < 8:
        return 0.0
    score = 0.4
    if len(note) >= 30: score += 0.2
    if re.search(r"(修正|対応|実装|追加|配線|テスト|検証|ガード|zod|トランザクション|FK|ロック|境界|削除)", note): score += 0.25
    if re.search(r"\.(ts|tsx|prisma|sh|js|sql)\b|/", note): score += 0.15
    return round(min(1.0, score), 2)
d = json.load(open(led, encoding="utf-8"))
hit = None
for f in d.get("findings", []):
    if f.get("id") == fidv:
        f["status"] = "resolved"; f["resolution"] = note
        f["resolution_quality"] = rquality("resolved", note); hit = f; break
if hit is None:
    ids = ", ".join(f.get("id","") for f in d.get("findings", []))
    sys.stderr.write(f"\033[0;31m❌ finding-id '{fidv}' は台帳に存在しません。有効ID: {ids}\033[0m\n")
    raise SystemExit(2)
d["open_count"] = sum(1 for f in d["findings"]
                      if f.get("status") != "resolved" or len((f.get("resolution") or "").strip()) < 8)
d["resolved_count"] = len(d["findings"]) - d["open_count"]
d["avg_resolution_quality"] = (round(sum(f.get("resolution_quality", 0.0) for f in d["findings"]) / len(d["findings"]), 3) if d["findings"] else 0.0)
tmp = led + ".tmp"
json.dump(d, open(tmp, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
os.replace(tmp, led)
print(f"[PFP-125 ledger] 解消: {fidv} ({hit.get('role','?')}) — 残り未解消 {d['open_count']} 件")
PY
  _mirror_ledger_to_review "$pdir"
}

# ------------------------------------------------------------------------------
# verify-ledger: 反証台帳の全指摘が「完成前に解消」済みかを判定する完成ゲート (PFP-125 厳格化)。
#   FAIL 条件: 台帳不在 / 敵対波証跡なし / false-PASS(反証指摘0) / 未解消の指摘が残存。
#   PASS 条件: 敵対波が反証を生み、台帳に集約され、全件が非空ノート付きで resolved。
# ------------------------------------------------------------------------------
_cmd_verify_ledger() {
  local pdir="${1:?project_dir required}"; pdir="$(_norm "$pdir")"
  local led; led="$(_ledger_path "$pdir")"
  if [ ! -f "$led" ]; then
    echo "{\"pfp\":\"PFP-125-ledger\",\"verdict\":\"FAIL\",\"reason\":\"ledger_missing\"}"
    echo -e "${C_RD}❌ PFP-125 反証台帳 FAIL: 台帳が未生成。先に ledger を実行してください (synthesize 後)${C_NC}" >&2
    return 1
  fi
  LEDGER="$led" python3 - <<'PY'
import json, os, sys
d = json.load(open(os.environ["LEDGER"], encoding="utf-8"))
present = bool(d.get("adversarial_evidence_present"))
fp = bool(d.get("false_pass_risk"))
findings = d.get("findings", [])
# 自己反証 R3: resolve(≥8字必須)と整合させ、空/極短ノートでの「解消済」自己申告を弾く
open_items = [f for f in findings
              if f.get("status") != "resolved" or len((f.get("resolution") or "").strip()) < 8]
if not present:
    verdict, reason = "FAIL", "no_adversarial_evidence"
elif fp or len(findings) == 0:
    verdict, reason = "FAIL", "false_pass_no_refutation"
elif open_items:
    verdict, reason = "FAIL", "unresolved_findings"
else:
    verdict, reason = "PASS", "all_resolved"
print(json.dumps({"pfp":"PFP-125-ledger","verdict":verdict,"reason":reason,
                  "findings_total":len(findings),"open":len(open_items),
                  "resolved":len(findings)-len(open_items),
                  "adversarial_evidence_present":present,"false_pass_risk":fp,
                  "open_ids":[f.get("id") for f in open_items][:20]}, ensure_ascii=False))
if verdict == "PASS":
    sys.stderr.write(f"\033[0;32m✅ PFP-125 反証台帳 PASS: 反証 {len(findings)} 件すべてを完成前に解消済み\033[0m\n")
elif reason == "no_adversarial_evidence":
    sys.stderr.write("\033[0;31m❌ PFP-125 反証台帳 FAIL: 敵対波の証跡がありません。adversarial 波の Task を発行してください\033[0m\n")
elif reason == "false_pass_no_refutation":
    sys.stderr.write("\033[0;31m❌ PFP-125 反証台帳 FAIL: 反証ロールは走りましたが実質的な反証指摘が0 (false-PASS)。"
                     "失敗モード/反例/エッジ/規制不適合を具体的に出させてください\033[0m\n")
else:
    sys.stderr.write(f"\033[0;31m❌ PFP-125 反証台帳 FAIL: 未解消の反証指摘が {len(open_items)} 件 "
                     f"({', '.join(f.get('id') for f in open_items[:8])})。完成前に resolve で解消してください\033[0m\n")
sys.exit(0 if verdict == "PASS" else 1)
PY
}

cmd="${1:-}"; shift 2>/dev/null || true
case "$cmd" in
  plan)               _cmd_plan               "$@" ;;
  wave)               _cmd_wave               "$@" ;;
  role-prompt)        _cmd_role_prompt        "$@" ;;
  tally)              _cmd_tally              "$@" ;;
  verify)             _cmd_verify             "$@" ;;
  verify-adversarial) _cmd_verify_adversarial "$@" ;;
  ledger)             _cmd_ledger             "$@" ;;
  resolve)            _cmd_resolve            "$@" ;;
  verify-ledger)      _cmd_verify_ledger      "$@" ;;
  report)             _cmd_report             "$@" ;;
  summary)            _cmd_summary            "$@" ;;
  prove)              _cmd_prove              "$@" ;;
  *) echo "usage: centuria-live-orchestrator.sh {plan|wave [--compact]|role-prompt|tally|verify|verify-adversarial|ledger|resolve|verify-ledger|report|summary|prove} <project_dir> ..." >&2; exit 2 ;;
esac
