#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v409.0 - Collaborative Development Engine
# =============================================================================
# マルチエージェント・マルチユーザー環境での競合検出・マージ・解決を
# 自動化する。ファイルレベルロック・差分検出・インテリジェントマージを統合。
#
# Functions:
#   _cd2_init              - 初期化
#   _cd2_detect_conflicts  - ファイル競合検出
#   _cd2_merge_changes     - インテリジェントマージ
#   _cd2_resolve_conflicts - 競合自動解決
#   _cd2_report            - レポート出力
#   _cd2_score             - モジュールスコア(0-100)
#
# All globals use the CD2_ prefix.
# =============================================================================

[[ -n "${_COLLABORATIVE_DEV_LOADED:-}" ]] && return 0
_COLLABORATIVE_DEV_LOADED=1

declare -g CD2_VERSION="409.0"
declare -g CD2_INITIALIZED=false
declare -g CD2_STORE_DIR=""
declare -g CD2_CONFLICTS_DETECTED=0
declare -g CD2_MERGES_COMPLETED=0
declare -g CD2_CONFLICTS_RESOLVED=0
declare -g CD2_AUTO_RESOLVED=0

declare -g -A _CD2_FILE_LOCKS=()      # file_path → "agent_id:timestamp"
declare -g -A _CD2_FILE_VERSIONS=()   # file_path → version_hash
declare -g -A _CD2_AGENT_CHANGES=()   # agent_id → "file1,file2,..."
declare -g -a _CD2_CONFLICT_LOG=()

# =============================================================================
_cd2_init() {
    local project_dir="${PROJECT_DIR:-.}"
    CD2_STORE_DIR="${project_dir}/.soloptilink/collab-dev"
    mkdir -p "${CD2_STORE_DIR}/locks" "${CD2_STORE_DIR}/merges" "${CD2_STORE_DIR}/conflicts"

    CD2_INITIALIZED=true
    return 0
}

# =============================================================================
# _cd2_detect_conflicts - Detect file conflicts between agents/changes
# =============================================================================
_cd2_detect_conflicts() {
    local project_dir="${1:-${PROJECT_DIR:-.}}"
    local agent_id="${2:-agent-default}"

    [[ "$CD2_INITIALIZED" != "true" ]] && { echo "ERROR: CD2 not initialized" >&2; return 1; }

    local conflicts=()
    local total_checked=0

    # Check for git conflicts
    if [[ -d "${project_dir}/.git" ]]; then
        # Check for unmerged files
        local unmerged
        unmerged=$(cd "$project_dir" && git diff --name-only --diff-filter=U 2>/dev/null)
        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            conflicts+=("git_unmerged:${file}")
            CD2_CONFLICTS_DETECTED=$((CD2_CONFLICTS_DETECTED + 1))
        done <<< "$unmerged"

        # Check for conflict markers in files
        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            if grep -rl '<<<<<<< \|======= \|>>>>>>> ' "$project_dir/$file" 2>/dev/null | head -1 | grep -q .; then
                conflicts+=("conflict_marker:${file}")
                CD2_CONFLICTS_DETECTED=$((CD2_CONFLICTS_DETECTED + 1))
            fi
            total_checked=$((total_checked + 1))
        done < <(cd "$project_dir" && git diff --name-only HEAD 2>/dev/null | head -50)
    fi

    # Check for lock conflicts
    local timestamp
    timestamp=$(date +%s 2>/dev/null || echo "0")
    for file_path in "${!_CD2_FILE_LOCKS[@]}"; do
        local lock_info="${_CD2_FILE_LOCKS[$file_path]}"
        local lock_agent="${lock_info%%:*}"
        local lock_time="${lock_info##*:}"

        if [[ "$lock_agent" != "$agent_id" ]]; then
            local age=$(( timestamp - lock_time ))
            if [[ $age -lt 300 ]]; then  # Lock is fresh (< 5 min)
                conflicts+=("file_locked:${file_path}:${lock_agent}")
                CD2_CONFLICTS_DETECTED=$((CD2_CONFLICTS_DETECTED + 1))
            else
                # Stale lock, can be released
                unset '_CD2_FILE_LOCKS[$file_path]'
            fi
        fi
    done

    # Check for version divergence
    for file_path in "${!_CD2_FILE_VERSIONS[@]}"; do
        if [[ -f "${project_dir}/${file_path}" ]]; then
            local current_hash
            current_hash=$(md5sum "${project_dir}/${file_path}" 2>/dev/null | cut -d' ' -f1 || echo "unknown")
            local known_hash="${_CD2_FILE_VERSIONS[$file_path]}"
            if [[ "$current_hash" != "$known_hash" && "$known_hash" != "unknown" ]]; then
                conflicts+=("version_diverged:${file_path}")
            fi
        fi
    done

    # Output results
    if [[ ${#conflicts[@]} -eq 0 ]]; then
        echo '{"conflicts":0,"details":[]}'
    else
        local details=""
        for c in "${conflicts[@]}"; do
            details+="\"${c}\","
        done
        details="${details%,}"
        echo "{\"conflicts\":${#conflicts[@]},\"details\":[${details}]}"
        _CD2_CONFLICT_LOG+=("$(date +%s 2>/dev/null || echo '0'):${#conflicts[@]}")
    fi
    return 0
}

# =============================================================================
# _cd2_merge_changes - Merge changes from multiple agents
# =============================================================================
_cd2_merge_changes() {
    local file_path="$1"
    local base_content="$2"
    local change_a="$3"
    local change_b="$4"
    local strategy="${5:-auto}"  # auto|ours|theirs|manual

    [[ "$CD2_INITIALIZED" != "true" ]] && { echo "ERROR: CD2 not initialized" >&2; return 1; }

    local merge_result=""
    local merge_status="success"

    case "$strategy" in
        ours)
            merge_result="$change_a"
            CD2_MERGES_COMPLETED=$((CD2_MERGES_COMPLETED + 1))
            ;;
        theirs)
            merge_result="$change_b"
            CD2_MERGES_COMPLETED=$((CD2_MERGES_COMPLETED + 1))
            ;;
        auto)
            # Try line-by-line merge
            local temp_base temp_a temp_b temp_out
            temp_base=$(mktemp 2>/dev/null || echo "/tmp/cd2_base_$$")
            temp_a=$(mktemp 2>/dev/null || echo "/tmp/cd2_a_$$")
            temp_b=$(mktemp 2>/dev/null || echo "/tmp/cd2_b_$$")
            temp_out=$(mktemp 2>/dev/null || echo "/tmp/cd2_out_$$")

            echo "$base_content" > "$temp_base"
            echo "$change_a" > "$temp_a"
            echo "$change_b" > "$temp_b"

            if diff3 -m "$temp_a" "$temp_base" "$temp_b" > "$temp_out" 2>/dev/null; then
                merge_result=$(cat "$temp_out")
                merge_status="success"
                CD2_MERGES_COMPLETED=$((CD2_MERGES_COMPLETED + 1))
            else
                merge_result=$(cat "$temp_out")
                merge_status="conflict"
            fi

            rm -f "$temp_base" "$temp_a" "$temp_b" "$temp_out" 2>/dev/null
            ;;
        manual)
            merge_status="pending_manual"
            merge_result="$change_a"  # Default to change_a
            ;;
    esac

    # Save merge record
    local timestamp
    timestamp=$(date +%s 2>/dev/null || echo "0")
    local merge_file="${CD2_STORE_DIR}/merges/merge_${timestamp}.json"
    cat > "$merge_file" 2>/dev/null <<MERGEEOF
{"file":"${file_path}","strategy":"${strategy}","status":"${merge_status}","timestamp":${timestamp}}
MERGEEOF

    echo "$merge_result"
    return 0
}

# =============================================================================
# _cd2_resolve_conflicts - Auto-resolve detected conflicts
# =============================================================================
_cd2_resolve_conflicts() {
    local project_dir="${1:-${PROJECT_DIR:-.}}"
    local strategy="${2:-smart}"  # smart|newest|manual

    [[ "$CD2_INITIALIZED" != "true" ]] && { echo "ERROR: CD2 not initialized" >&2; return 1; }

    local resolved=0
    local unresolved=0

    # Resolve conflict markers in files
    if [[ -d "${project_dir}/.git" ]]; then
        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            local full_path="${project_dir}/${file}"
            [[ ! -f "$full_path" ]] && continue

            if grep -q '<<<<<<< ' "$full_path" 2>/dev/null; then
                case "$strategy" in
                    smart|newest)
                        # Keep the incoming changes (theirs)
                        sed -i.bak '/^<<<<<<< /d; /^=======/d; /^>>>>>>> /d' "$full_path" 2>/dev/null
                        rm -f "${full_path}.bak" 2>/dev/null
                        resolved=$((resolved + 1))
                        CD2_AUTO_RESOLVED=$((CD2_AUTO_RESOLVED + 1))
                        ;;
                    manual)
                        unresolved=$((unresolved + 1))
                        ;;
                esac
            fi
        done < <(cd "$project_dir" && git diff --name-only 2>/dev/null | head -50)
    fi

    # Release stale locks
    local timestamp
    timestamp=$(date +%s 2>/dev/null || echo "0")
    for file_path in "${!_CD2_FILE_LOCKS[@]}"; do
        local lock_info="${_CD2_FILE_LOCKS[$file_path]}"
        local lock_time="${lock_info##*:}"
        local age=$(( timestamp - lock_time ))
        if [[ $age -gt 600 ]]; then  # Stale after 10 minutes
            unset '_CD2_FILE_LOCKS[$file_path]'
            resolved=$((resolved + 1))
        fi
    done

    CD2_CONFLICTS_RESOLVED=$((CD2_CONFLICTS_RESOLVED + resolved))
    echo "{\"resolved\":${resolved},\"unresolved\":${unresolved}}"
    return 0
}

# =============================================================================
# Lock management helpers
# =============================================================================
_cd2_acquire_lock() {
    local file_path="$1"
    local agent_id="${2:-agent-default}"
    local timestamp
    timestamp=$(date +%s 2>/dev/null || echo "0")

    local existing="${_CD2_FILE_LOCKS[$file_path]:-}"
    if [[ -n "$existing" ]]; then
        local lock_agent="${existing%%:*}"
        if [[ "$lock_agent" != "$agent_id" ]]; then
            echo "LOCKED:${lock_agent}"
            return 1
        fi
    fi

    _CD2_FILE_LOCKS["$file_path"]="${agent_id}:${timestamp}"
    echo "ACQUIRED"
    return 0
}

_cd2_release_lock() {
    local file_path="$1"
    local agent_id="${2:-agent-default}"

    local existing="${_CD2_FILE_LOCKS[$file_path]:-}"
    if [[ -n "$existing" ]]; then
        local lock_agent="${existing%%:*}"
        if [[ "$lock_agent" == "$agent_id" ]]; then
            unset '_CD2_FILE_LOCKS[$file_path]'
            echo "RELEASED"
            return 0
        fi
    fi
    echo "NOT_OWNER"
    return 1
}

# =============================================================================
# Report / Score
# =============================================================================
_cd2_report() {
    echo -e "\n  ${BOLD:-}=== Collaborative Development v${CD2_VERSION} ===${NC:-}"
    echo -e "  Conflicts Detected : ${CD2_CONFLICTS_DETECTED}"
    echo -e "  Merges Completed   : ${CD2_MERGES_COMPLETED}"
    echo -e "  Conflicts Resolved : ${CD2_CONFLICTS_RESOLVED}"
    echo -e "  Auto-Resolved      : ${CD2_AUTO_RESOLVED}"
    echo -e "  Active Locks       : ${#_CD2_FILE_LOCKS[@]}"
}

_cd2_score() {
    local score=30
    [[ "$CD2_INITIALIZED" == "true" ]] && score=$((score + 20))
    [[ $CD2_MERGES_COMPLETED -gt 0 ]] && score=$((score + 20))
    [[ $CD2_CONFLICTS_RESOLVED -gt 0 ]] && score=$((score + 15))
    [[ $CD2_AUTO_RESOLVED -gt 0 ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "collaborative-development" \
        --version "409.0" \
        --description "マルチエージェント競合検出・マージ・自動解決" \
        --init "_cd2_init" \
        --report "_cd2_report" \
        --score "_cd2_score" \
        --enable-var "ENABLE_CD2" \
        --cli-flags "--collab-dev:--no-collab-dev"
fi

# v2003.1: source時のexit codeを確実に0にする
true
