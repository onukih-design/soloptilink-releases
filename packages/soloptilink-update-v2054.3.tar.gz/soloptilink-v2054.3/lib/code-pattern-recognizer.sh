#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v203.0 - Code Pattern Recognizer
# =============================================================================
# 命名規約分析×アーキテクチャ検出×スタイルガイド自動生成
#
# 機能:
#   - 命名規約検出（camelCase/snake_case/PascalCase/kebab-case）
#   - ファイル構成パターン検出
#   - コンポーネントパターン検出（関数型/クラス型/hooks）
#   - アーキテクチャスタイル検出（MVC/Clean/Hexagonal/Feature-based）
#   - コーディングスタイル抽出（セミコロン/引用符/インデント等）
#   - スタイルガイド自動生成
#   - Claude生成プロンプト注入
#
# 全globals: CPR_ prefix
# =============================================================================

[[ -n "${_CPR_LOADED:-}" ]] && return 0; _CPR_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g CPR_VERSION="203.0"
declare -g CPR_INITIALIZED=false
declare -g CPR_ANALYZE_COUNT=0
declare -g CPR_ERRORS=0
declare -g CPR_PHASE="code_pattern_recognizer"
declare -g CPR_STORAGE_DIR="${HOME}/.soloptilink/code-patterns"

# Detection results
declare -g CPR_PROJECT_DIR=""
declare -g CPR_NAMING_CONVENTION=""     # dominant naming style
declare -g CPR_ARCHITECTURE_STYLE=""    # detected architecture
declare -g CPR_COMPONENT_PATTERN=""     # dominant component pattern
declare -g CPR_INDENT_STYLE=""          # tabs or spaces
declare -g CPR_INDENT_SIZE=""           # 2 or 4
declare -g CPR_QUOTE_STYLE=""           # single or double
declare -g CPR_SEMICOLONS=""            # yes or no
declare -g CPR_FILE_ORGANIZATION=""     # type-based or feature-based

# Color codes
declare -g CPR_GREEN="${GREEN:-\033[0;32m}"
declare -g CPR_YELLOW="${YELLOW:-\033[1;33m}"
declare -g CPR_RED="${RED:-\033[0;31m}"
declare -g CPR_CYAN="${CYAN:-\033[0;36m}"
declare -g CPR_BOLD="${BOLD:-\033[1m}"
declare -g CPR_NC="${NC:-\033[0m}"

# =============================================================================
# 初期化
# =============================================================================
cpr_init() {
    CPR_INITIALIZED=true
    CPR_ANALYZE_COUNT=0
    CPR_ERRORS=0
    CPR_NAMING_CONVENTION=""
    CPR_ARCHITECTURE_STYLE=""
    CPR_COMPONENT_PATTERN=""
    CPR_INDENT_STYLE=""
    CPR_INDENT_SIZE=""
    CPR_QUOTE_STYLE=""
    CPR_SEMICOLONS=""
    CPR_FILE_ORGANIZATION=""
    mkdir -p "${CPR_STORAGE_DIR}" 2>/dev/null
    return 0
}

# =============================================================================
# ユーティリティ: ログ
# =============================================================================
_cpr_log() {
    local level="$1"
    shift
    local msg="$*"
    case "$level" in
        info)  echo -e "  ${CPR_CYAN}[code-patterns]${CPR_NC} ${msg}" >&2 ;;
        ok)    echo -e "  ${CPR_GREEN}[code-patterns]${CPR_NC} ${msg}" >&2 ;;
        warn)  echo -e "  ${CPR_YELLOW}[code-patterns]${CPR_NC} ${msg}" >&2 ;;
        error) echo -e "  ${CPR_RED}[code-patterns]${CPR_NC} ${msg}" >&2; CPR_ERRORS=$((CPR_ERRORS + 1)) ;;
    esac
}

# =============================================================================
# 命名規約検出
# =============================================================================
_cpr_detect_naming_conventions() {
    local project_dir="$1"

    _cpr_log info "Analyzing naming conventions..."

    local camel_count=0
    local snake_count=0
    local pascal_count=0
    local kebab_count=0

    # --- File naming ---
    local file_names
    file_names=$(find "$project_dir" \
        \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        -not -path "*/dist/*" \
        2>/dev/null | while read -r f; do basename "$f" | sed 's/\.[^.]*$//'; done)

    local file_camel=0 file_pascal=0 file_kebab=0 file_snake=0

    while IFS= read -r name; do
        [[ -z "$name" ]] && continue
        # PascalCase: starts with uppercase, has at least one lowercase
        if [[ "$name" =~ ^[A-Z][a-zA-Z0-9]*$ ]] && [[ "$name" =~ [a-z] ]]; then
            file_pascal=$((file_pascal + 1))
        # camelCase: starts with lowercase, has uppercase
        elif [[ "$name" =~ ^[a-z][a-zA-Z0-9]*$ ]] && [[ "$name" =~ [A-Z] ]]; then
            file_camel=$((file_camel + 1))
        # kebab-case: contains hyphens
        elif [[ "$name" =~ ^[a-z][a-z0-9]*(-[a-z0-9]+)+$ ]]; then
            file_kebab=$((file_kebab + 1))
        # snake_case: contains underscores
        elif [[ "$name" =~ ^[a-z][a-z0-9]*(_[a-z0-9]+)+$ ]]; then
            file_snake=$((file_snake + 1))
        fi
    done <<< "$file_names"

    # --- Variable/Function naming (from source code) ---
    local sample_files
    sample_files=$(find "$project_dir" \
        \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        -not -path "*/dist/*" \
        2>/dev/null | head -50)

    local var_camel=0 var_snake=0 var_pascal=0

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue

        # Extract variable names from const/let/var declarations
        local vars
        vars=$(grep -oE '(const|let|var)\s+[a-zA-Z_][a-zA-Z0-9_]*' "$file" 2>/dev/null | awk '{print $2}')

        while IFS= read -r var_name; do
            [[ -z "$var_name" ]] && continue
            [[ ${#var_name} -lt 3 ]] && continue  # Skip very short names

            if [[ "$var_name" =~ ^[a-z][a-zA-Z0-9]*$ ]] && [[ "$var_name" =~ [A-Z] ]]; then
                var_camel=$((var_camel + 1))
            elif [[ "$var_name" =~ ^[a-z][a-z0-9]*(_[a-z0-9]+)+ ]]; then
                var_snake=$((var_snake + 1))
            elif [[ "$var_name" =~ ^[A-Z][a-zA-Z0-9]*$ ]]; then
                var_pascal=$((var_pascal + 1))
            fi
        done <<< "$vars"

        # Extract function names
        local funcs
        funcs=$(grep -oE 'function\s+[a-zA-Z_][a-zA-Z0-9_]*' "$file" 2>/dev/null | awk '{print $2}')
        funcs+=$(grep -oE '(const|let)\s+[a-zA-Z_][a-zA-Z0-9_]*\s*=' "$file" 2>/dev/null | awk '{print $2}')

        while IFS= read -r fn_name; do
            [[ -z "$fn_name" ]] && continue
            [[ ${#fn_name} -lt 3 ]] && continue

            if [[ "$fn_name" =~ ^[a-z][a-zA-Z0-9]*$ ]] && [[ "$fn_name" =~ [A-Z] ]]; then
                var_camel=$((var_camel + 1))
            elif [[ "$fn_name" =~ ^[a-z][a-z0-9]*(_[a-z0-9]+)+ ]]; then
                var_snake=$((var_snake + 1))
            fi
        done <<< "$funcs"
    done <<< "$sample_files"

    # Aggregate totals
    camel_count=$((file_camel + var_camel))
    snake_count=$((file_snake + var_snake))
    pascal_count=$((file_pascal + var_pascal))
    kebab_count=$file_kebab

    # Determine dominant convention
    local max_count=$camel_count
    CPR_NAMING_CONVENTION="camelCase"

    if [[ $snake_count -gt $max_count ]]; then
        max_count=$snake_count
        CPR_NAMING_CONVENTION="snake_case"
    fi
    if [[ $pascal_count -gt $max_count ]]; then
        max_count=$pascal_count
        CPR_NAMING_CONVENTION="PascalCase"
    fi
    if [[ $kebab_count -gt $max_count ]]; then
        max_count=$kebab_count
        CPR_NAMING_CONVENTION="kebab-case"
    fi

    # Save detailed results
    cat > "${CPR_STORAGE_DIR}/naming-analysis.json" <<EOF
{
  "dominant": "${CPR_NAMING_CONVENTION}",
  "fileNaming": {
    "camelCase": ${file_camel},
    "PascalCase": ${file_pascal},
    "kebab-case": ${file_kebab},
    "snake_case": ${file_snake}
  },
  "variableNaming": {
    "camelCase": ${var_camel},
    "snake_case": ${var_snake},
    "PascalCase": ${var_pascal}
  },
  "totals": {
    "camelCase": ${camel_count},
    "snake_case": ${snake_count},
    "PascalCase": ${pascal_count},
    "kebab-case": ${kebab_count}
  }
}
EOF

    _cpr_log ok "Naming convention: ${CPR_NAMING_CONVENTION} (camel:${camel_count} snake:${snake_count} pascal:${pascal_count} kebab:${kebab_count})"
}

# =============================================================================
# コーディングスタイル検出（引用符/セミコロン/インデント）
# =============================================================================
_cpr_detect_coding_style() {
    local project_dir="$1"

    _cpr_log info "Analyzing coding style..."

    local sample_files
    sample_files=$(find "$project_dir" \
        \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        -not -path "*/dist/*" \
        2>/dev/null | head -30)

    local single_quotes=0
    local double_quotes=0
    local semicolons=0
    local no_semicolons=0
    local tab_indent=0
    local space2_indent=0
    local space4_indent=0

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue

        # Quote style (from imports as reliable indicator)
        local sq dq
        sq=$(grep -c "from '" "$file" 2>/dev/null || echo "0")
        dq=$(grep -c 'from "' "$file" 2>/dev/null || echo "0")
        single_quotes=$((single_quotes + sq))
        double_quotes=$((double_quotes + dq))

        # Semicolons (check line endings)
        local with_semi without_semi
        with_semi=$(grep -cE ';\s*$' "$file" 2>/dev/null || echo "0")
        without_semi=$(grep -cE '[^;{}\s]\s*$' "$file" 2>/dev/null || echo "0")
        semicolons=$((semicolons + with_semi))
        no_semicolons=$((no_semicolons + without_semi))

        # Indentation (check first 100 indented lines)
        local indent_sample
        indent_sample=$(grep -E '^\s+\S' "$file" 2>/dev/null | head -100)

        while IFS= read -r line; do
            [[ -z "$line" ]] && continue
            if [[ "$line" =~ ^$'\t' ]]; then
                tab_indent=$((tab_indent + 1))
            elif [[ "$line" =~ ^'    ' ]]; then
                space4_indent=$((space4_indent + 1))
            elif [[ "$line" =~ ^'  '[^' '] ]]; then
                space2_indent=$((space2_indent + 1))
            fi
        done <<< "$indent_sample"
    done <<< "$sample_files"

    # Determine styles
    if [[ $single_quotes -gt $double_quotes ]]; then
        CPR_QUOTE_STYLE="single"
    else
        CPR_QUOTE_STYLE="double"
    fi

    if [[ $semicolons -gt $no_semicolons ]]; then
        CPR_SEMICOLONS="yes"
    else
        CPR_SEMICOLONS="no"
    fi

    if [[ $tab_indent -gt $space2_indent ]] && [[ $tab_indent -gt $space4_indent ]]; then
        CPR_INDENT_STYLE="tabs"
        CPR_INDENT_SIZE="1"
    elif [[ $space4_indent -gt $space2_indent ]]; then
        CPR_INDENT_STYLE="spaces"
        CPR_INDENT_SIZE="4"
    else
        CPR_INDENT_STYLE="spaces"
        CPR_INDENT_SIZE="2"
    fi

    # Also check .editorconfig / prettier / eslint for authoritative config
    if [[ -f "${project_dir}/.prettierrc" ]] || [[ -f "${project_dir}/.prettierrc.json" ]]; then
        local prettier_file="${project_dir}/.prettierrc"
        [[ -f "${project_dir}/.prettierrc.json" ]] && prettier_file="${project_dir}/.prettierrc.json"

        if grep -q '"singleQuote"' "$prettier_file" 2>/dev/null; then
            if grep -q '"singleQuote"[[:space:]]*:[[:space:]]*true' "$prettier_file" 2>/dev/null; then
                CPR_QUOTE_STYLE="single"
            else
                CPR_QUOTE_STYLE="double"
            fi
        fi
        if grep -q '"semi"' "$prettier_file" 2>/dev/null; then
            if grep -q '"semi"[[:space:]]*:[[:space:]]*false' "$prettier_file" 2>/dev/null; then
                CPR_SEMICOLONS="no"
            else
                CPR_SEMICOLONS="yes"
            fi
        fi
        if grep -q '"tabWidth"' "$prettier_file" 2>/dev/null; then
            local tab_width
            tab_width=$(grep -oE '"tabWidth"[[:space:]]*:[[:space:]]*[0-9]+' "$prettier_file" 2>/dev/null | grep -oE '[0-9]+')
            [[ -n "$tab_width" ]] && CPR_INDENT_SIZE="$tab_width"
        fi
        if grep -q '"useTabs"' "$prettier_file" 2>/dev/null; then
            if grep -q '"useTabs"[[:space:]]*:[[:space:]]*true' "$prettier_file" 2>/dev/null; then
                CPR_INDENT_STYLE="tabs"
            fi
        fi
    fi

    _cpr_log ok "Style: quotes=${CPR_QUOTE_STYLE} semi=${CPR_SEMICOLONS} indent=${CPR_INDENT_STYLE}(${CPR_INDENT_SIZE})"
}

# =============================================================================
# コンポーネントパターン検出
# =============================================================================
_cpr_detect_component_patterns() {
    local project_dir="$1"

    _cpr_log info "Analyzing component patterns..."

    local func_components=0
    local arrow_components=0
    local class_components=0
    local hooks_usage=0
    local server_components=0
    local client_components=0

    local component_files
    component_files=$(find "$project_dir" \( -name "*.tsx" -o -name "*.jsx" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        -not -path "*/dist/*" \
        2>/dev/null | head -100)

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue

        # Function components: export function ComponentName
        local fc
        fc=$(grep -cE 'export\s+(default\s+)?function\s+[A-Z]' "$file" 2>/dev/null || echo "0")
        func_components=$((func_components + fc))

        # Arrow function components: export const ComponentName = () =>
        local ac
        ac=$(grep -cE 'export\s+(const|default)\s+[A-Z][a-zA-Z]*\s*=\s*(\([^)]*\)|[a-zA-Z]+)\s*=>' "$file" 2>/dev/null || echo "0")
        arrow_components=$((arrow_components + ac))

        # Class components: class ComponentName extends (React.Component|Component)
        local cc
        cc=$(grep -cE 'class\s+[A-Z][a-zA-Z]*\s+extends\s+(React\.)?Component' "$file" 2>/dev/null || echo "0")
        class_components=$((class_components + cc))

        # Hooks usage
        local hu
        hu=$(grep -cE 'use(State|Effect|Memo|Callback|Ref|Context|Reducer)' "$file" 2>/dev/null || echo "0")
        hooks_usage=$((hooks_usage + hu))

        # Server/Client components (Next.js App Router)
        if grep -q "'use server'" "$file" 2>/dev/null || grep -q '"use server"' "$file" 2>/dev/null; then
            server_components=$((server_components + 1))
        fi
        if grep -q "'use client'" "$file" 2>/dev/null || grep -q '"use client"' "$file" 2>/dev/null; then
            client_components=$((client_components + 1))
        fi
    done <<< "$component_files"

    # Determine dominant pattern
    if [[ $class_components -gt $func_components ]] && [[ $class_components -gt $arrow_components ]]; then
        CPR_COMPONENT_PATTERN="class-based"
    elif [[ $arrow_components -gt $func_components ]]; then
        CPR_COMPONENT_PATTERN="arrow-function"
    else
        CPR_COMPONENT_PATTERN="function-declaration"
    fi

    if [[ $hooks_usage -gt 10 ]]; then
        CPR_COMPONENT_PATTERN+="+hooks"
    fi

    if [[ $server_components -gt 0 ]] || [[ $client_components -gt 0 ]]; then
        CPR_COMPONENT_PATTERN+="+server-client"
    fi

    cat > "${CPR_STORAGE_DIR}/component-patterns.json" <<EOF
{
  "dominant": "${CPR_COMPONENT_PATTERN}",
  "functionDeclarations": ${func_components},
  "arrowFunctions": ${arrow_components},
  "classComponents": ${class_components},
  "hooksUsage": ${hooks_usage},
  "serverComponents": ${server_components},
  "clientComponents": ${client_components}
}
EOF

    _cpr_log ok "Component pattern: ${CPR_COMPONENT_PATTERN} (func:${func_components} arrow:${arrow_components} class:${class_components})"
}

# =============================================================================
# アーキテクチャスタイル検出
# =============================================================================
_cpr_detect_architecture() {
    local project_dir="${1:-${CPR_PROJECT_DIR:-./output}}"

    _cpr_log info "Detecting architecture style..."

    local scores_mvc=0
    local scores_clean=0
    local scores_feature=0
    local scores_hexagonal=0
    local scores_nextjs_app=0

    # Check for MVC patterns
    [[ -d "${project_dir}/models" ]] || [[ -d "${project_dir}/src/models" ]] && scores_mvc=$((scores_mvc + 3))
    [[ -d "${project_dir}/controllers" ]] || [[ -d "${project_dir}/src/controllers" ]] && scores_mvc=$((scores_mvc + 3))
    [[ -d "${project_dir}/views" ]] || [[ -d "${project_dir}/src/views" ]] && scores_mvc=$((scores_mvc + 3))
    [[ -d "${project_dir}/routes" ]] || [[ -d "${project_dir}/src/routes" ]] && scores_mvc=$((scores_mvc + 2))
    [[ -d "${project_dir}/middleware" ]] || [[ -d "${project_dir}/src/middleware" ]] && scores_mvc=$((scores_mvc + 1))

    # Check for Clean Architecture patterns
    [[ -d "${project_dir}/domain" ]] || [[ -d "${project_dir}/src/domain" ]] && scores_clean=$((scores_clean + 3))
    [[ -d "${project_dir}/usecases" ]] || [[ -d "${project_dir}/src/usecases" ]] || \
    [[ -d "${project_dir}/use-cases" ]] || [[ -d "${project_dir}/src/use-cases" ]] && scores_clean=$((scores_clean + 3))
    [[ -d "${project_dir}/infrastructure" ]] || [[ -d "${project_dir}/src/infrastructure" ]] && scores_clean=$((scores_clean + 3))
    [[ -d "${project_dir}/interfaces" ]] || [[ -d "${project_dir}/src/interfaces" ]] && scores_clean=$((scores_clean + 2))
    [[ -d "${project_dir}/entities" ]] || [[ -d "${project_dir}/src/entities" ]] && scores_clean=$((scores_clean + 2))
    [[ -d "${project_dir}/repositories" ]] || [[ -d "${project_dir}/src/repositories" ]] && scores_clean=$((scores_clean + 2))

    # Check for Feature-based organization
    local feature_dirs=0
    if [[ -d "${project_dir}/src/features" ]] || [[ -d "${project_dir}/features" ]]; then
        scores_feature=$((scores_feature + 5))
        feature_dirs=$(find "${project_dir}/src/features" "${project_dir}/features" -maxdepth 1 -type d 2>/dev/null | wc -l | tr -d ' ')
        [[ $feature_dirs -gt 3 ]] && scores_feature=$((scores_feature + 3))
    fi
    # modules/ directory (feature-based variant)
    if [[ -d "${project_dir}/src/modules" ]] || [[ -d "${project_dir}/modules" ]]; then
        scores_feature=$((scores_feature + 4))
    fi

    # Check for Hexagonal / Ports & Adapters
    [[ -d "${project_dir}/ports" ]] || [[ -d "${project_dir}/src/ports" ]] && scores_hexagonal=$((scores_hexagonal + 4))
    [[ -d "${project_dir}/adapters" ]] || [[ -d "${project_dir}/src/adapters" ]] && scores_hexagonal=$((scores_hexagonal + 4))
    [[ -d "${project_dir}/core" ]] || [[ -d "${project_dir}/src/core" ]] && scores_hexagonal=$((scores_hexagonal + 2))

    # Check for Next.js App Router
    if [[ -d "${project_dir}/app" ]] && [[ -f "${project_dir}/app/layout.tsx" ]] || [[ -f "${project_dir}/app/layout.ts" ]]; then
        scores_nextjs_app=$((scores_nextjs_app + 5))
        [[ -d "${project_dir}/app/api" ]] && scores_nextjs_app=$((scores_nextjs_app + 2))
        [[ -d "${project_dir}/components" ]] && scores_nextjs_app=$((scores_nextjs_app + 2))
        [[ -d "${project_dir}/lib" ]] && scores_nextjs_app=$((scores_nextjs_app + 1))
    fi

    # Also check file organization type
    local type_based_dirs=0
    local feature_based_dirs=0
    for dir in components hooks utils services lib types; do
        if [[ -d "${project_dir}/${dir}" ]] || [[ -d "${project_dir}/src/${dir}" ]]; then
            type_based_dirs=$((type_based_dirs + 1))
        fi
    done
    if [[ $type_based_dirs -ge 3 ]]; then
        CPR_FILE_ORGANIZATION="type-based"
    elif [[ $scores_feature -ge 5 ]]; then
        CPR_FILE_ORGANIZATION="feature-based"
    else
        CPR_FILE_ORGANIZATION="mixed"
    fi

    # Determine winner
    local max_score=$scores_nextjs_app
    CPR_ARCHITECTURE_STYLE="Next.js App Router"

    if [[ $scores_mvc -gt $max_score ]]; then
        max_score=$scores_mvc
        CPR_ARCHITECTURE_STYLE="MVC"
    fi
    if [[ $scores_clean -gt $max_score ]]; then
        max_score=$scores_clean
        CPR_ARCHITECTURE_STYLE="Clean Architecture"
    fi
    if [[ $scores_feature -gt $max_score ]]; then
        max_score=$scores_feature
        CPR_ARCHITECTURE_STYLE="Feature-based"
    fi
    if [[ $scores_hexagonal -gt $max_score ]]; then
        max_score=$scores_hexagonal
        CPR_ARCHITECTURE_STYLE="Hexagonal (Ports & Adapters)"
    fi

    if [[ $max_score -eq 0 ]]; then
        CPR_ARCHITECTURE_STYLE="Flat / Unstructured"
    fi

    cat > "${CPR_STORAGE_DIR}/architecture-analysis.json" <<EOF
{
  "detected": "${CPR_ARCHITECTURE_STYLE}",
  "fileOrganization": "${CPR_FILE_ORGANIZATION}",
  "scores": {
    "MVC": ${scores_mvc},
    "CleanArchitecture": ${scores_clean},
    "FeatureBased": ${scores_feature},
    "Hexagonal": ${scores_hexagonal},
    "NextjsAppRouter": ${scores_nextjs_app}
  }
}
EOF

    _cpr_log ok "Architecture: ${CPR_ARCHITECTURE_STYLE} (org: ${CPR_FILE_ORGANIZATION})"
}

# =============================================================================
# 命名ルール抽出
# =============================================================================
_cpr_get_naming_rules() {
    local project_dir="${1:-${CPR_PROJECT_DIR:-./output}}"

    # Auto-analyze if needed
    if [[ -z "$CPR_NAMING_CONVENTION" ]]; then
        _cpr_detect_naming_conventions "$project_dir"
    fi

    local rules=""

    # File naming rules
    rules+="## File Naming Rules\n"
    local tsx_files
    tsx_files=$(find "$project_dir" -name "*.tsx" -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null | head -20)
    local component_naming="PascalCase"
    local page_naming="lowercase"
    local hook_naming="camelCase"
    local util_naming="camelCase"

    # Detect component file naming
    local pascal_files=0 kebab_files=0 camel_files=0
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        local bn
        bn=$(basename "$f" | sed 's/\.[^.]*$//')
        if [[ "$bn" =~ ^[A-Z] ]]; then
            pascal_files=$((pascal_files + 1))
        elif [[ "$bn" =~ - ]]; then
            kebab_files=$((kebab_files + 1))
        elif [[ "$bn" =~ ^[a-z] ]]; then
            camel_files=$((camel_files + 1))
        fi
    done <<< "$tsx_files"

    if [[ $kebab_files -gt $pascal_files ]]; then
        component_naming="kebab-case"
    elif [[ $camel_files -gt $pascal_files ]]; then
        component_naming="camelCase"
    fi

    rules+="- Components: ${component_naming} (e.g., "
    case "$component_naming" in
        PascalCase) rules+="UserProfile.tsx)" ;;
        kebab-case) rules+="user-profile.tsx)" ;;
        camelCase)  rules+="userProfile.tsx)" ;;
    esac
    rules+="\n"

    # Check hooks naming
    local hooks_dir=""
    for candidate in "${project_dir}/hooks" "${project_dir}/src/hooks"; do
        [[ -d "$candidate" ]] && hooks_dir="$candidate" && break
    done
    if [[ -n "$hooks_dir" ]]; then
        local hook_example
        hook_example=$(find "$hooks_dir" -name "use*" 2>/dev/null | head -1 | xargs basename 2>/dev/null | sed 's/\.[^.]*$//')
        rules+="- Hooks: camelCase with 'use' prefix (e.g., ${hook_example:-useAuth}.ts)\n"
    fi

    rules+="- Variables/Functions: ${CPR_NAMING_CONVENTION}\n"
    rules+="- Constants: UPPER_SNAKE_CASE\n"
    rules+="- Types/Interfaces: PascalCase\n"

    # Detect export patterns
    local default_exports=0
    local named_exports=0
    local sample_files
    sample_files=$(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" \) \
        -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null | head -40)
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        local de ne
        de=$(grep -c "export default" "$f" 2>/dev/null || echo "0")
        ne=$(grep -c "export " "$f" 2>/dev/null || echo "0")
        ne=$((ne - de))
        default_exports=$((default_exports + de))
        named_exports=$((named_exports + ne))
    done <<< "$sample_files"

    if [[ $named_exports -gt $default_exports ]]; then
        rules+="- Exports: Prefer named exports\n"
    else
        rules+="- Exports: Default exports for components, named for utilities\n"
    fi

    echo -e "$rules"
}

# =============================================================================
# スタイルガイド生成
# =============================================================================
_cpr_get_style_guide() {
    local project_dir="${1:-${CPR_PROJECT_DIR:-./output}}"
    local output_file="${CPR_STORAGE_DIR}/style-guide.md"

    # Auto-analyze if needed
    if [[ "$CPR_ANALYZE_COUNT" -eq 0 ]]; then
        _cpr_analyze_patterns "$project_dir" 2>/dev/null
    fi

    local naming_rules
    naming_rules=$(_cpr_get_naming_rules "$project_dir")

    cat > "$output_file" <<EOF
# Code Style Guide (Auto-Generated)
> Generated by SoloptiLinkAI Code Pattern Recognizer v${CPR_VERSION}
> Project: $(basename "$project_dir")
> Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)

## Architecture
- Style: **${CPR_ARCHITECTURE_STYLE}**
- File Organization: **${CPR_FILE_ORGANIZATION}**

## Formatting
- Indent: **${CPR_INDENT_STYLE}** (size: ${CPR_INDENT_SIZE})
- Quotes: **${CPR_QUOTE_STYLE}**
- Semicolons: **${CPR_SEMICOLONS}**

## Component Pattern
- Style: **${CPR_COMPONENT_PATTERN}**

## Naming Conventions
$(echo -e "$naming_rules")

## Rules for Code Generation
1. Follow the **${CPR_NAMING_CONVENTION}** naming convention for variables and functions
2. Use **${CPR_QUOTE_STYLE} quotes** in all string literals
3. **${CPR_SEMICOLONS}** semicolons at end of statements
4. Indent with **${CPR_INDENT_SIZE} ${CPR_INDENT_STYLE}**
5. Follow **${CPR_ARCHITECTURE_STYLE}** architecture patterns
6. Use **${CPR_COMPONENT_PATTERN}** component pattern
7. Organize files in **${CPR_FILE_ORGANIZATION}** structure
EOF

    _cpr_log ok "Style guide generated: ${output_file}"
    cat "$output_file"
}

# =============================================================================
# メイン解析関数
# =============================================================================
_cpr_analyze_patterns() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    CPR_PROJECT_DIR="$project_dir"

    if [[ ! -d "$project_dir" ]]; then
        _cpr_log error "Project directory not found: ${project_dir}"
        return 1
    fi

    _cpr_log info "Analyzing code patterns in: ${project_dir}"

    # Step 1: Naming conventions
    _cpr_detect_naming_conventions "$project_dir"

    # Step 2: Coding style
    _cpr_detect_coding_style "$project_dir"

    # Step 3: Component patterns
    _cpr_detect_component_patterns "$project_dir"

    # Step 4: Architecture style
    _cpr_detect_architecture "$project_dir"

    CPR_ANALYZE_COUNT=$((CPR_ANALYZE_COUNT + 1))
    _cpr_log ok "Pattern analysis complete"
    return 0
}

# =============================================================================
# Claude プロンプト注入用コンテキスト
# =============================================================================
_cpr_inject_context() {
    local project_dir="${1:-${CPR_PROJECT_DIR:-./output}}"

    # Auto-analyze if needed
    if [[ "$CPR_ANALYZE_COUNT" -eq 0 ]]; then
        _cpr_analyze_patterns "$project_dir" 2>/dev/null
    fi

    cat <<CONTEXT
## [Code Pattern Recognizer] コーディング規約コンテキスト

### 検出されたパターン:
- アーキテクチャ: ${CPR_ARCHITECTURE_STYLE:-未検出}
- コンポーネント: ${CPR_COMPONENT_PATTERN:-未検出}
- 命名規約: ${CPR_NAMING_CONVENTION:-未検出}
- インデント: ${CPR_INDENT_STYLE:-spaces}(${CPR_INDENT_SIZE:-2})
- 引用符: ${CPR_QUOTE_STYLE:-single}
- セミコロン: ${CPR_SEMICOLONS:-no}
- ファイル構成: ${CPR_FILE_ORGANIZATION:-type-based}

### 必須ルール:
1. 命名は既存コードの規約（${CPR_NAMING_CONVENTION:-camelCase}）に必ず従うこと
2. ${CPR_QUOTE_STYLE:-single}引用符を使用すること
3. ${CPR_ARCHITECTURE_STYLE:-detected}アーキテクチャに沿ったファイル配置を行うこと
4. 既存の${CPR_COMPONENT_PATTERN:-function}コンポーネントパターンに合わせること
5. インデントは${CPR_INDENT_SIZE:-2}${CPR_INDENT_STYLE:-spaces}で統一すること
CONTEXT
}

# =============================================================================
# JSON要約出力
# =============================================================================
_cpr_get_summary_json() {
    cat <<EOF
{
  "version": "${CPR_VERSION}",
  "analyzeCount": ${CPR_ANALYZE_COUNT},
  "errors": ${CPR_ERRORS},
  "naming": "${CPR_NAMING_CONVENTION}",
  "architecture": "${CPR_ARCHITECTURE_STYLE}",
  "componentPattern": "${CPR_COMPONENT_PATTERN}",
  "indent": "${CPR_INDENT_STYLE}(${CPR_INDENT_SIZE})",
  "quotes": "${CPR_QUOTE_STYLE}",
  "semicolons": "${CPR_SEMICOLONS}",
  "fileOrganization": "${CPR_FILE_ORGANIZATION}"
}
EOF
}

# =============================================================================
# レポート & スコア
# =============================================================================
cpr_report() {
    echo -e "\n  ${CPR_BOLD}=== code-pattern-recognizer v${CPR_VERSION} ===${CPR_NC}"
    echo -e "  解析回数: ${CPR_ANALYZE_COUNT}"
    echo -e "  エラー: ${CPR_ERRORS}"
    if [[ "$CPR_ANALYZE_COUNT" -gt 0 ]]; then
        echo -e "  命名規約: ${CPR_NAMING_CONVENTION}"
        echo -e "  アーキテクチャ: ${CPR_ARCHITECTURE_STYLE}"
        echo -e "  コンポーネント: ${CPR_COMPONENT_PATTERN}"
        echo -e "  スタイル: quotes=${CPR_QUOTE_STYLE} semi=${CPR_SEMICOLONS} indent=${CPR_INDENT_STYLE}(${CPR_INDENT_SIZE})"
        echo -e "  ファイル構成: ${CPR_FILE_ORGANIZATION}"
    fi
}

cpr_score() {
    if [[ ${CPR_ANALYZE_COUNT} -ge 1 ]] && [[ ${CPR_ERRORS} -eq 0 ]]; then
        echo "95"
    elif [[ ${CPR_ANALYZE_COUNT} -gt 0 ]]; then
        echo "75"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "code-pattern-recognizer" --version "203.0" \
        --description "命名規約分析×アーキテクチャ検出×スタイルガイド自動生成" \
        --init "cpr_init" --report "cpr_report" --score "cpr_score" \
        --enable-var "ENABLE_CODE_PATTERN_RECOGNIZER" --cli-flags "--code-patterns:--no-code-patterns"
fi

# v2003.1: source時のexit codeを確実に0にする
true
