#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v465.0 - Data Migration Pipeline Engine
# =============================================================================
# データマイグレーションパイプライン: 計画策定、スクリプト生成、整合性検証。
#
# Functions:
#   _dmp_init()               - Initialize
#   _dmp_plan_migration()     - Migration plan generation
#   _dmp_generate_scripts()   - Migration script generation
#   _dmp_verify_integrity()   - Post-migration integrity verification
#   _dmp_report() / _dmp_score()
# =============================================================================

[[ -n "${_DMP_LOADED:-}" ]] && return 0; _DMP_LOADED=1

declare -g DMP_VERSION="465.0"
DMP_GENERATED=0; DMP_ERRORS=0; DMP_FILES_WRITTEN=0
DMP_PLAN_OK=false; DMP_SCRIPTS_OK=false; DMP_VERIFY_OK=false

_dmp_init() {
    DMP_GENERATED=0; DMP_ERRORS=0; DMP_FILES_WRITTEN=0
    DMP_PLAN_OK=false; DMP_SCRIPTS_OK=false; DMP_VERIFY_OK=false
    return 0
}

_dmp_log() { echo -e "  ${CYAN:-\033[0;36m}[data-migration]${NC:-\033[0m} $*" >&2; }
_dmp_ok()  { echo -e "  ${GREEN:-\033[0;32m}✅ [data-migration]${NC:-\033[0m} $*" >&2; }
_dmp_err() { echo -e "  ${RED:-\033[0;31m}❌ [data-migration]${NC:-\033[0m} $*" >&2; DMP_ERRORS=$((DMP_ERRORS + 1)); }

_dmp_write_file() {
    local filepath="$1" content="$2"
    local dir; dir="$(dirname "$filepath")"
    [[ -d "$dir" ]] || mkdir -p "$dir"
    echo "$content" > "$filepath" 2>/dev/null || { _dmp_err "Failed to write $filepath"; return 1; }
    DMP_FILES_WRITTEN=$((DMP_FILES_WRITTEN + 1))
    return 0
}

_dmp_plan_migration() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/migration/migration-planner.ts"
    _dmp_log "Generating migration planner..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v465.0 - Data Migration Planner

export type MigrationStrategy = 'big-bang' | 'rolling' | 'blue-green' | 'strangler-fig';

export interface MigrationPlan {
  id: string;
  name: string;
  strategy: MigrationStrategy;
  steps: MigrationStep[];
  estimatedDuration: string;
  rollbackPlan: string;
  riskLevel: 'low' | 'medium' | 'high' | 'critical';
}

export interface MigrationStep {
  order: number;
  name: string;
  type: 'schema' | 'data' | 'validation' | 'cleanup';
  description: string;
  reversible: boolean;
  dependsOn: number[];
  estimatedRows?: number;
  batchSize: number;
}

export class MigrationPlanner {
  createPlan(name: string, strategy: MigrationStrategy): MigrationPlan {
    return {
      id: `mig_${Date.now()}`,
      name,
      strategy,
      steps: [],
      estimatedDuration: '0m',
      rollbackPlan: '',
      riskLevel: 'low',
    };
  }

  addSchemaStep(plan: MigrationPlan, description: string): MigrationPlan {
    const step: MigrationStep = {
      order: plan.steps.length + 1, name: `schema_${plan.steps.length + 1}`,
      type: 'schema', description, reversible: true, dependsOn: [], batchSize: 1,
    };
    return { ...plan, steps: [...plan.steps, step] };
  }

  addDataStep(plan: MigrationPlan, description: string, estimatedRows: number, batchSize = 1000): MigrationPlan {
    const deps = plan.steps.filter(s => s.type === 'schema').map(s => s.order);
    const step: MigrationStep = {
      order: plan.steps.length + 1, name: `data_${plan.steps.length + 1}`,
      type: 'data', description, reversible: false, dependsOn: deps, estimatedRows, batchSize,
    };
    return { ...plan, steps: [...plan.steps, step] };
  }

  estimateDuration(plan: MigrationPlan): string {
    const totalRows = plan.steps.reduce((sum, s) => sum + (s.estimatedRows ?? 0), 0);
    const minutes = Math.ceil(totalRows / 10000) + plan.steps.length * 2;
    return minutes < 60 ? `${minutes}m` : `${Math.ceil(minutes / 60)}h ${minutes % 60}m`;
  }

  assessRisk(plan: MigrationPlan): MigrationPlan['riskLevel'] {
    const hasIrreversible = plan.steps.some(s => !s.reversible);
    const totalRows = plan.steps.reduce((sum, s) => sum + (s.estimatedRows ?? 0), 0);
    if (totalRows > 1000000 || (hasIrreversible && plan.strategy === 'big-bang')) return 'critical';
    if (totalRows > 100000 || hasIrreversible) return 'high';
    if (totalRows > 10000) return 'medium';
    return 'low';
  }
}

export const migrationPlanner = new MigrationPlanner();
TYPESCRIPT
)
    _dmp_write_file "$outfile" "$content" || return 1
    DMP_PLAN_OK=true
    DMP_GENERATED=$((DMP_GENERATED + 1))
    _dmp_ok "Migration planner generated"
    return 0
}

_dmp_generate_scripts() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/migration/script-generator.ts"
    _dmp_log "Generating migration scripts..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v465.0 - Migration Script Generator

export interface MigrationScript {
  name: string;
  up: string;
  down: string;
  checksum: string;
  appliedAt?: string;
}

export class MigrationScriptGenerator {
  generateRenameColumn(table: string, oldName: string, newName: string): MigrationScript {
    return {
      name: `rename_${table}_${oldName}_to_${newName}`,
      up: `ALTER TABLE "${table}" RENAME COLUMN "${oldName}" TO "${newName}";`,
      down: `ALTER TABLE "${table}" RENAME COLUMN "${newName}" TO "${oldName}";`,
      checksum: this.hash(`rename_${table}_${oldName}_${newName}`),
    };
  }

  generateAddColumn(table: string, column: string, type: string, nullable = true): MigrationScript {
    const nullClause = nullable ? '' : ' NOT NULL';
    return {
      name: `add_${table}_${column}`,
      up: `ALTER TABLE "${table}" ADD COLUMN "${column}" ${type}${nullClause};`,
      down: `ALTER TABLE "${table}" DROP COLUMN "${column}";`,
      checksum: this.hash(`add_${table}_${column}_${type}`),
    };
  }

  generateDataTransform(table: string, description: string, transformSql: string): MigrationScript {
    return {
      name: `transform_${table}_${Date.now()}`,
      up: `-- ${description}\n${transformSql}`,
      down: `-- Manual rollback required for: ${description}`,
      checksum: this.hash(transformSql),
    };
  }

  generateBatchUpdate(table: string, setClause: string, whereClause: string, batchSize = 1000): string {
    return `DO $$\nDECLARE\n  batch_count INT := 0;\nBEGIN\n  LOOP\n    UPDATE "${table}" SET ${setClause}\n    WHERE ctid IN (\n      SELECT ctid FROM "${table}" WHERE ${whereClause} LIMIT ${batchSize}\n    );\n    GET DIAGNOSTICS batch_count = ROW_COUNT;\n    EXIT WHEN batch_count = 0;\n    RAISE NOTICE 'Updated % rows', batch_count;\n  END LOOP;\nEND $$;`;
  }

  private hash(input: string): string {
    let hash = 0;
    for (let i = 0; i < input.length; i++) { hash = ((hash << 5) - hash) + input.charCodeAt(i); hash |= 0; }
    return Math.abs(hash).toString(16);
  }
}

export const scriptGenerator = new MigrationScriptGenerator();
TYPESCRIPT
)
    _dmp_write_file "$outfile" "$content" || return 1
    DMP_SCRIPTS_OK=true
    DMP_GENERATED=$((DMP_GENERATED + 1))
    _dmp_ok "Migration scripts generated"
    return 0
}

_dmp_verify_integrity() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/migration/integrity-verifier.ts"
    _dmp_log "Generating integrity verifier..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v465.0 - Post-Migration Integrity Verifier

export interface IntegrityCheck {
  name: string;
  query: string;
  expectedResult: 'zero' | 'non-zero' | 'match';
  matchValue?: number;
  severity: 'error' | 'warning';
}

export interface VerificationResult {
  check: string;
  passed: boolean;
  actual: number;
  expected: string;
  severity: 'error' | 'warning';
}

export class IntegrityVerifier {
  private checks: IntegrityCheck[] = [];

  addCheck(check: IntegrityCheck): void { this.checks.push(check); }

  addRowCountCheck(table: string, minRows: number): void {
    this.checks.push({
      name: `${table}_row_count`,
      query: `SELECT COUNT(*) as cnt FROM "${table}"`,
      expectedResult: 'non-zero',
      severity: 'error',
    });
  }

  addNullCheck(table: string, column: string): void {
    this.checks.push({
      name: `${table}_${column}_no_nulls`,
      query: `SELECT COUNT(*) as cnt FROM "${table}" WHERE "${column}" IS NULL`,
      expectedResult: 'zero',
      severity: 'error',
    });
  }

  addForeignKeyCheck(table: string, fkColumn: string, refTable: string, refColumn: string): void {
    this.checks.push({
      name: `${table}_${fkColumn}_fk_integrity`,
      query: `SELECT COUNT(*) as cnt FROM "${table}" t LEFT JOIN "${refTable}" r ON t."${fkColumn}" = r."${refColumn}" WHERE r."${refColumn}" IS NULL AND t."${fkColumn}" IS NOT NULL`,
      expectedResult: 'zero',
      severity: 'error',
    });
  }

  getChecks(): IntegrityCheck[] { return [...this.checks]; }

  generateReport(results: VerificationResult[]): { passed: number; failed: number; warnings: number } {
    return {
      passed: results.filter(r => r.passed).length,
      failed: results.filter(r => !r.passed && r.severity === 'error').length,
      warnings: results.filter(r => !r.passed && r.severity === 'warning').length,
    };
  }
}

export const integrityVerifier = new IntegrityVerifier();
TYPESCRIPT
)
    _dmp_write_file "$outfile" "$content" || return 1
    DMP_VERIFY_OK=true
    DMP_GENERATED=$((DMP_GENERATED + 1))
    _dmp_ok "Integrity verifier generated"
    return 0
}

_dmp_generate_all() {
    local project_dir="${1:-.}"
    _dmp_plan_migration "$project_dir"
    _dmp_generate_scripts "$project_dir"
    _dmp_verify_integrity "$project_dir"
    _dmp_ok "Data migration pipeline complete: ${DMP_GENERATED} components, ${DMP_ERRORS} errors"
}

_dmp_report() {
    echo -e "\n  ${BOLD:-\033[1m}═══ Data Migration Pipeline v${DMP_VERSION} ═══${NC:-\033[0m}"
    echo -e "  Generated  : ${DMP_GENERATED}"
    echo -e "  Errors     : ${DMP_ERRORS}"
    echo -e "  Plan       : ${DMP_PLAN_OK}"
    echo -e "  Scripts    : ${DMP_SCRIPTS_OK}"
    echo -e "  Integrity  : ${DMP_VERIFY_OK}"
}

_dmp_score() {
    local score=50
    ${DMP_PLAN_OK} && score=$((score + 15))
    ${DMP_SCRIPTS_OK} && score=$((score + 15))
    ${DMP_VERIFY_OK} && score=$((score + 15))
    [[ ${DMP_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "data-migration-pipeline" --version "465.0" \
        --description "データマイグレーション: 計画策定×スクリプト生成×整合性検証" \
        --init "_dmp_init" --report "_dmp_report" --score "_dmp_score" \
        --enable-var "ENABLE_DATA_MIGRATION" --cli-flags "--data-migration:--no-data-migration"
fi

# v2003.1: source時のexit codeを確実に0にする
true
