#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v340.0 - Load Test Generator
# =============================================================================
# k6負荷テストスクリプト、シナリオ定義、結果分析の自動生成。
# 段階的負荷、ストレステスト、スパイクテスト、しきい値検証。
#
# Functions:
#   _ltg_init()                 - Initialize
#   _ltg_generate_k6_script()   - Generate k6 load test scripts
#   _ltg_generate_scenarios()   - Generate load scenarios
#   _ltg_analyze_results()      - Analyze load test results
#   _ltg_report() / _ltg_score()
# =============================================================================

[[ -n "${_LTG_LOADED:-}" ]] && return 0; _LTG_LOADED=1

readonly _LTG_RED='\033[0;31m'
readonly _LTG_GREEN='\033[0;32m'
readonly _LTG_YELLOW='\033[0;33m'
readonly _LTG_CYAN='\033[0;36m'
readonly _LTG_NC='\033[0m'

declare -g LTG_VERSION="340.0"
LTG_GENERATED=0; LTG_ERRORS=0; LTG_FILES_WRITTEN=0
LTG_K6_OK=false; LTG_SCENARIOS_OK=false; LTG_ANALYZE_OK=false

_ltg_init() {
    LTG_GENERATED=0; LTG_ERRORS=0; LTG_FILES_WRITTEN=0
    LTG_K6_OK=false; LTG_SCENARIOS_OK=false; LTG_ANALYZE_OK=false
    echo -e "  ${_LTG_GREEN}OK${_LTG_NC} Load Test Generator v${LTG_VERSION}" >&2
    return 0
}

_ltg_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { LTG_FILES_WRITTEN=$((LTG_FILES_WRITTEN + 1)); return 0; }
    LTG_ERRORS=$((LTG_ERRORS + 1)); return 1
}

_ltg_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_LTG_CYAN}[load-test]${_LTG_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_LTG_GREEN}[load-test]${_LTG_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_LTG_YELLOW}[load-test]${_LTG_NC} $msg" >&2 ;;
        error) echo -e "  ${_LTG_RED}[load-test]${_LTG_NC} $msg" >&2 ;;
    esac
}

_ltg_generate_k6_script() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local load_dir="${project_dir}/tests/load"

    _ltg_log info "Generating k6 load test scripts..."

    _ltg_write_file "${load_dir}/smoke.js" 'import http from "k6/http";
import { check, sleep } from "k6";

export const options = {
  vus: 1,
  duration: "30s",
  thresholds: {
    http_req_duration: ["p(95)<500"],
    http_req_failed: ["rate<0.01"],
  },
};

const BASE_URL = __ENV.BASE_URL || "http://localhost:3000";

export default function () {
  const res = http.get(`${BASE_URL}/api/health`);
  check(res, {
    "status is 200": (r) => r.status === 200,
    "response time < 200ms": (r) => r.timings.duration < 200,
  });
  sleep(1);
}
'

    _ltg_write_file "${load_dir}/load.js" 'import http from "k6/http";
import { check, sleep, group } from "k6";
import { Rate, Trend } from "k6/metrics";

const errorRate = new Rate("errors");
const apiDuration = new Trend("api_duration");

export const options = {
  stages: [
    { duration: "2m", target: 10 },   // Ramp up
    { duration: "5m", target: 50 },   // Stay at 50
    { duration: "2m", target: 100 },  // Peak
    { duration: "3m", target: 100 },  // Stay at peak
    { duration: "2m", target: 0 },    // Ramp down
  ],
  thresholds: {
    http_req_duration: ["p(95)<1000", "p(99)<2000"],
    http_req_failed: ["rate<0.05"],
    errors: ["rate<0.1"],
  },
};

const BASE_URL = __ENV.BASE_URL || "http://localhost:3000";
let authToken = "";

export function setup() {
  const loginRes = http.post(`${BASE_URL}/api/v1/auth/login`, JSON.stringify({
    email: "loadtest@example.com", password: "LoadTest123!",
  }), { headers: { "Content-Type": "application/json" } });
  return { token: loginRes.json("token") };
}

export default function (data) {
  const headers = { Authorization: `Bearer ${data.token}`, "Content-Type": "application/json" };

  group("Read Operations", () => {
    const listRes = http.get(`${BASE_URL}/api/v1/users`, { headers });
    check(listRes, { "list 200": (r) => r.status === 200 });
    errorRate.add(listRes.status !== 200);
    apiDuration.add(listRes.timings.duration);
  });

  group("Write Operations", () => {
    const createRes = http.post(`${BASE_URL}/api/v1/tasks`, JSON.stringify({
      title: `Load test ${Date.now()}`, status: "pending",
    }), { headers });
    check(createRes, { "create 201": (r) => r.status === 201 });
    errorRate.add(createRes.status !== 201);
  });

  sleep(Math.random() * 3 + 1);
}
'

    _ltg_write_file "${load_dir}/stress.js" 'import http from "k6/http";
import { check, sleep } from "k6";

export const options = {
  stages: [
    { duration: "2m", target: 50 },
    { duration: "5m", target: 200 },
    { duration: "5m", target: 500 },
    { duration: "5m", target: 500 },
    { duration: "5m", target: 0 },
  ],
  thresholds: {
    http_req_duration: ["p(99)<5000"],
    http_req_failed: ["rate<0.10"],
  },
};

const BASE_URL = __ENV.BASE_URL || "http://localhost:3000";

export default function () {
  const res = http.get(`${BASE_URL}/api/health`);
  check(res, { "still responding": (r) => r.status === 200 });
  sleep(0.5);
}
'

    _ltg_log ok "k6 scripts generated (smoke/load/stress)"
    LTG_K6_OK=true
    LTG_GENERATED=$((LTG_GENERATED + 1))
    return 0
}

_ltg_generate_scenarios() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local load_dir="${project_dir}/tests/load"

    _ltg_log info "Generating load scenarios..."

    _ltg_write_file "${load_dir}/scenarios.json" '{
  "smoke": { "vus": 1, "duration": "30s", "description": "Sanity check" },
  "load": { "stages": "10->50->100->0 over 14min", "description": "Normal load" },
  "stress": { "stages": "50->200->500->0 over 22min", "description": "Beyond capacity" },
  "spike": { "stages": "10->500->10 over 8min", "description": "Sudden spike" },
  "soak": { "vus": 50, "duration": "2h", "description": "Extended duration" },
  "thresholds": {
    "p95_response_time_ms": 1000,
    "p99_response_time_ms": 2000,
    "error_rate_percent": 5,
    "requests_per_second": 100
  }
}'

    _ltg_log ok "Load scenarios defined"
    LTG_SCENARIOS_OK=true
    LTG_GENERATED=$((LTG_GENERATED + 1))
    return 0
}

_ltg_analyze_results() {
    local results_file="${1:-}"
    _ltg_log info "Analyzing load test results..."

    if [[ -n "$results_file" ]] && [[ -f "$results_file" ]]; then
        local p95
        p95=$(grep "http_req_duration.*p(95)" "$results_file" 2>/dev/null | awk '{print $NF}' | head -1)
        local error_rate
        error_rate=$(grep "http_req_failed" "$results_file" 2>/dev/null | awk '{print $NF}' | head -1)

        [[ -n "$p95" ]] && _ltg_log info "p95 latency: ${p95}"
        [[ -n "$error_rate" ]] && _ltg_log info "Error rate: ${error_rate}"
    else
        _ltg_log info "No results file to analyze (run k6 first)"
    fi

    LTG_ANALYZE_OK=true
    LTG_GENERATED=$((LTG_GENERATED + 1))
    return 0
}

_ltg_report() {
    echo -e "\n  ${_LTG_CYAN}=== Load Test Generator v${LTG_VERSION} ===${_LTG_NC}"
    echo -e "  Generated: ${LTG_GENERATED} | Files: ${LTG_FILES_WRITTEN} | Errors: ${LTG_ERRORS}"
    echo -e "  k6 Scripts: $( ${LTG_K6_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Scenarios: $( ${LTG_SCENARIOS_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Analysis: $( ${LTG_ANALYZE_OK} && echo 'OK' || echo 'SKIP')"
}

_ltg_score() {
    local score=50
    ${LTG_K6_OK} && score=$((score + 20))
    ${LTG_SCENARIOS_OK} && score=$((score + 15))
    ${LTG_ANALYZE_OK} && score=$((score + 10))
    [[ ${LTG_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "load-test-generator" --version "340.0" \
        --description "負荷テスト自動生成 k6/段階負荷/ストレス/スパイク (v340)" \
        --init "_ltg_init" --report "_ltg_report" --score "_ltg_score" \
        --enable-var "ENABLE_LOAD_TEST_GEN" --cli-flags "--load-test-gen:--no-load-test-gen"
fi

# v2003.1: source時のexit codeを確実に0にする
true
