#!/usr/bin/env bash
# SoloptiLinkAI v55.0 - Phase Functions (Split Loader)
# This file sources the 4 category-split phase files.
# Original: phases.sh.bak2 (2339 lines, 35 functions)
#
# Categories:
#   phases-core.sh       - Core development phases (17 functions)
#   phases-quality.sh    - Quality & testing phases (9 functions)
#   phases-enterprise.sh - Enterprise/security/compliance phases (4 functions)
#   phases-ops.sh        - Operations/deploy/knowledge phases (5 functions)

_PHASES_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# v2003.1: 各フェーズファイルのsourceにエラーガードを追加
# set -eo pipefail下でもロード失敗で即死しないようにする
source "${_PHASES_DIR}/phases-core.sh" || { echo "WARN: phases-core.sh load failed" >&2; }
source "${_PHASES_DIR}/phases-quality.sh" || { echo "WARN: phases-quality.sh load failed" >&2; }
source "${_PHASES_DIR}/phases-enterprise.sh" || { echo "WARN: phases-enterprise.sh load failed" >&2; }
source "${_PHASES_DIR}/phases-ops.sh" || { echo "WARN: phases-ops.sh load failed" >&2; }
# REQ-WIRE-001 (v2037): DAG縮退フォールバック4関数 (DB_LITE/BE_MIN/FE_STATIC/QA_MANUAL)
source "${_PHASES_DIR}/phases-fallback.sh" || { echo "WARN: phases-fallback.sh load failed" >&2; }

# ============================================================
# v2042 (L1ハーネス / REQ-WIRE-V2042): lib/phases/ サブディレクトリ動的ローダ
# ------------------------------------------------------------
# L2〜L9 が chain.sh / cli-parser.sh / lib/phases.sh 本体を再編集せず、
# `lib/phases/phase_lane<N>_<機能>.sh` を置くだけでフェーズ実体を定義できるよう、
# phases/ 配下の *.sh を自動 source する。配線の直列待ちを構造的にゼロ化する地盤。
#   - ディレクトリ不在・空ディレクトリでもエラーにしない (nullglob を局所適用し復元)。
#   - set -eo pipefail 下でも個別ロード失敗で即死しない (|| WARN・既存idiomと同一)。
#   - 既存 5 ファイルの source 順・挙動は不変 (本ブロックは末尾追記のみ)。
#   - ★bash 3.2 ガード (波3 refuter 指摘・恒久対策): chain.sh は top-level で本ファイルを source し、
#     その位置は main() 内 bash バージョンガード(行1847)より前。レーン実体が bash4+ 構文
#     (例 declare -gA)を持つと bash 3.2(Homebrew bash 非導入の顧客 macOS=/bin/bash)で set -e 下に
#     起動段階で即死する経路を新設してしまう。よって bash<4 ではレーン実体を一切 source せず、
#     既存5ファイルのみで継続させ main() の親切なバージョンガードに到達させる(graceful degradation 温存)。
if [[ -d "${_PHASES_DIR}/phases" ]] && [[ "${BASH_VERSINFO[0]:-0}" -ge 4 ]]; then
    _had_nullglob="$(shopt -p nullglob 2>/dev/null || true)"
    shopt -s nullglob 2>/dev/null || true
    for _phase_file in "${_PHASES_DIR}/phases/"*.sh; do
        [[ -e "$_phase_file" ]] || continue   # nullglob 不在環境での二重防御
        source "$_phase_file" || { echo "WARN: $(basename "$_phase_file") load failed (lib/phases/)" >&2; }
    done
    eval "${_had_nullglob:-}" 2>/dev/null || true   # 呼び出し元の nullglob 状態を復元
    unset _phase_file _had_nullglob
fi

