#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v471.0 - Self-Improving Prompts Engine
# =============================================================================
# プロンプトの結果品質を分析し、進化的手法でプロンプトを自動改善する。
# 結果スコアに基づいてプロンプト変異・選択・交叉を行い、
# 世代を重ねるごとにプロンプト品質が向上する自己進化エンジン。
#
# Functions:
#   _sip_init               - 初期化・履歴ロード
#   _sip_analyze_result     - 生成結果の品質分析
#   _sip_score_quality      - 多軸品質スコアリング
#   _sip_mutate_prompt      - プロンプトの突然変異
#   _sip_crossover          - 高スコアプロンプト同士の交叉
#   _sip_select_best        - 最良プロンプトの選択
#   _sip_evolve_generation  - 1世代の進化サイクル実行
#   _sip_report             - レポート出力
#   _sip_score              - モジュールスコア(0-100)
#
# Globals: SIP_ prefix
# =============================================================================

[[ -n "${_SELF_IMPROVING_PROMPTS_LOADED:-}" ]] && return 0
_SELF_IMPROVING_PROMPTS_LOADED=1

SIP_VERSION="471.0"
SIP_INITIALIZED=false

# --- Storage ---
SIP_DATA_DIR=""
SIP_HISTORY_FILE=""
SIP_BEST_PROMPTS_FILE=""
SIP_GENERATION_LOG=""

# --- State ---
SIP_CURRENT_GENERATION=0
SIP_TOTAL_MUTATIONS=0
SIP_TOTAL_CROSSOVERS=0
SIP_TOTAL_EVALUATIONS=0
SIP_BEST_SCORE=0
SIP_AVG_IMPROVEMENT=0

# --- Population ---
declare -g -a _SIP_POPULATION=()
declare -g -a _SIP_SCORES=()
declare -g -A _SIP_PROMPT_HISTORY=()
declare -g -A _SIP_QUALITY_CACHE=()
declare -g -A _SIP_MUTATION_STRATEGIES=()

# --- Quality Axes ---
declare -g -a SIP_QUALITY_AXES=(
    "completeness"
    "correctness"
    "security"
    "performance"
    "readability"
    "maintainability"
    "test_coverage"
    "error_handling"
)

# =============================================================================
# 初期化
# =============================================================================
_sip_init() {
    local project_dir="${PROJECT_DIR:-.}"
    SIP_DATA_DIR="${project_dir}/.soloptilink/sip"
    SIP_HISTORY_FILE="${SIP_DATA_DIR}/history.jsonl"
    SIP_BEST_PROMPTS_FILE="${SIP_DATA_DIR}/best_prompts.json"
    SIP_GENERATION_LOG="${SIP_DATA_DIR}/generations.log"

    mkdir -p "$SIP_DATA_DIR"

    # 変異戦略の登録
    _SIP_MUTATION_STRATEGIES["add_constraint"]="制約条件を追加してより厳密にする"
    _SIP_MUTATION_STRATEGIES["add_example"]="具体例を追加して明確にする"
    _SIP_MUTATION_STRATEGIES["simplify"]="冗長部分を削除してシンプルにする"
    _SIP_MUTATION_STRATEGIES["restructure"]="構造を再編成して論理的にする"
    _SIP_MUTATION_STRATEGIES["add_validation"]="バリデーション要件を追加する"
    _SIP_MUTATION_STRATEGIES["enhance_security"]="セキュリティ要件を強化する"
    _SIP_MUTATION_STRATEGIES["add_error_handling"]="エラーハンドリング要件を追加する"
    _SIP_MUTATION_STRATEGIES["specify_patterns"]="デザインパターンを明示する"

    # 履歴のロード
    if [[ -f "$SIP_HISTORY_FILE" ]]; then
        SIP_CURRENT_GENERATION=$(wc -l < "$SIP_HISTORY_FILE" 2>/dev/null || echo "0")
        SIP_CURRENT_GENERATION=$((SIP_CURRENT_GENERATION / 10))  # 概算
    fi

    SIP_INITIALIZED=true
    return 0
}

# =============================================================================
# 結果の品質分析
# =============================================================================
_sip_analyze_result() {
    local prompt="$1"
    local result_file="$2"
    local domain="${3:-general}"

    [[ "$SIP_INITIALIZED" != "true" ]] && _sip_init

    [[ ! -f "$result_file" ]] && { echo "0"; return 1; }

    local total_score=0
    local axis_count=0
    local result_content
    result_content=$(cat "$result_file" 2>/dev/null)
    local line_count
    line_count=$(wc -l < "$result_file" 2>/dev/null || echo "0")

    # Completeness: ファイルサイズと構造の充実度
    local completeness=0
    if [[ $line_count -gt 200 ]]; then
        completeness=90
    elif [[ $line_count -gt 100 ]]; then
        completeness=70
    elif [[ $line_count -gt 50 ]]; then
        completeness=50
    else
        completeness=30
    fi

    # Correctness: 構文エラーの有無
    local correctness=80
    if echo "$result_content" | grep -qiE "syntax error|undefined|cannot find"; then
        correctness=30
    fi

    # Security: セキュリティパターンの存在
    local security=50
    if echo "$result_content" | grep -qE "zod\.|z\.(string|number|object)|validate|sanitize"; then
        security=$((security + 20))
    fi
    if echo "$result_content" | grep -qE "bcrypt|argon2|hash"; then
        security=$((security + 15))
    fi
    if echo "$result_content" | grep -qE "helmet|cors|csrf"; then
        security=$((security + 15))
    fi

    # Error handling: try-catch/エラーハンドリングの存在
    local error_handling=50
    local try_count
    try_count=$(echo "$result_content" | grep -c "try {" 2>/dev/null || echo "0")
    if [[ $try_count -gt 3 ]]; then
        error_handling=85
    elif [[ $try_count -gt 0 ]]; then
        error_handling=65
    fi

    # Performance: N+1検出・インデックス利用
    local performance=60
    if echo "$result_content" | grep -qE "include:|select:|index"; then
        performance=80
    fi

    # 総合スコア
    total_score=$(( (completeness + correctness + security + error_handling + performance) / 5 ))

    # 履歴に記録
    local timestamp
    timestamp=$(date +%s)
    local prompt_hash
    prompt_hash=$(echo "$prompt" | md5sum 2>/dev/null | cut -c1-12 || echo "nohash")

    echo "{\"ts\":${timestamp},\"gen\":${SIP_CURRENT_GENERATION},\"hash\":\"${prompt_hash}\",\"domain\":\"${domain}\",\"score\":${total_score},\"completeness\":${completeness},\"correctness\":${correctness},\"security\":${security},\"error_handling\":${error_handling},\"performance\":${performance}}" >> "$SIP_HISTORY_FILE" 2>/dev/null

    SIP_TOTAL_EVALUATIONS=$((SIP_TOTAL_EVALUATIONS + 1))
    if [[ $total_score -gt $SIP_BEST_SCORE ]]; then
        SIP_BEST_SCORE=$total_score
    fi

    echo "$total_score"
    return 0
}

# =============================================================================
# 多軸品質スコアリング
# =============================================================================
_sip_score_quality() {
    local result_file="$1"
    local axes="${2:-all}"

    [[ ! -f "$result_file" ]] && { echo "0"; return 1; }

    local content
    content=$(cat "$result_file" 2>/dev/null)
    local scores=()
    local total=0

    # 各軸のスコアを計算
    for axis in "${SIP_QUALITY_AXES[@]}"; do
        [[ "$axes" != "all" && "$axes" != *"$axis"* ]] && continue

        local s=50
        case "$axis" in
            completeness)
                local exports
                exports=$(echo "$content" | grep -c "export " 2>/dev/null || echo "0")
                s=$((50 + exports * 5))
                [[ $s -gt 100 ]] && s=100
                ;;
            correctness)
                local errors
                errors=$(echo "$content" | grep -ciE "error|undefined|null" 2>/dev/null || echo "0")
                s=$((90 - errors * 10))
                [[ $s -lt 0 ]] && s=0
                ;;
            security)
                local sec_patterns=0
                echo "$content" | grep -qE "zod|validate" && sec_patterns=$((sec_patterns + 1))
                echo "$content" | grep -qE "bcrypt|argon2" && sec_patterns=$((sec_patterns + 1))
                echo "$content" | grep -qE "helmet|csp|hsts" && sec_patterns=$((sec_patterns + 1))
                echo "$content" | grep -qE "rate.?limit" && sec_patterns=$((sec_patterns + 1))
                s=$((40 + sec_patterns * 15))
                ;;
            test_coverage)
                local test_lines
                test_lines=$(echo "$content" | grep -cE "test\(|it\(|describe\(|expect\(" 2>/dev/null || echo "0")
                s=$((30 + test_lines * 5))
                [[ $s -gt 100 ]] && s=100
                ;;
            *)
                s=60
                ;;
        esac

        scores+=("$s")
        total=$((total + s))
    done

    local count=${#scores[@]}
    [[ $count -eq 0 ]] && { echo "50"; return 0; }

    echo "$((total / count))"
    return 0
}

# =============================================================================
# プロンプトの突然変異
# =============================================================================
_sip_mutate_prompt() {
    local prompt="$1"
    local strategy="${2:-random}"
    local intensity="${3:-medium}"

    [[ "$SIP_INITIALIZED" != "true" ]] && _sip_init

    # ランダム戦略選択
    if [[ "$strategy" == "random" ]]; then
        local keys
        keys=(${!_SIP_MUTATION_STRATEGIES[@]})
        local idx=$((RANDOM % ${#keys[@]}))
        strategy="${keys[$idx]}"
    fi

    local mutation_instruction=""
    case "$strategy" in
        add_constraint)
            mutation_instruction="以下の制約を追加: 全入力にzodバリデーション必須、全APIエンドポイントにエラーハンドリング必須、型安全を保証"
            ;;
        add_example)
            mutation_instruction="以下の具体例を参考に生成: Prismaモデル定義例、APIルート実装例、React Hookパターン例を含める"
            ;;
        simplify)
            mutation_instruction="冗長な説明を削除し、コード生成に直接関係する指示のみに絞る。アクション可能な指示に集中"
            ;;
        restructure)
            mutation_instruction="指示を以下の順序に再構成: 1.データモデル定義 2.API実装 3.フロントエンド 4.テスト 5.セキュリティ"
            ;;
        add_validation)
            mutation_instruction="全フォーム入力にクライアント/サーバー両方のバリデーション追加、エラーメッセージのi18n対応"
            ;;
        enhance_security)
            mutation_instruction="OWASP Top 10対策を明示: XSS防止(DOMPurify), CSRF(トークン), SQLi(パラメータ化), 認証(JWT RS256)"
            ;;
        add_error_handling)
            mutation_instruction="全非同期処理にtry-catch、API境界にエラーバウンダリ、グレースフルデグラデーション戦略を追加"
            ;;
        specify_patterns)
            mutation_instruction="デザインパターンを明示: Repository+Service層、Factory(テストデータ)、Observer(イベント)、Strategy(認証)"
            ;;
    esac

    # 変異強度に応じた適用
    local mutated_prompt=""
    case "$intensity" in
        low)
            mutated_prompt="${prompt}

[追加要件] ${mutation_instruction}"
            ;;
        medium)
            mutated_prompt="[重要な制約] ${mutation_instruction}

${prompt}"
            ;;
        high)
            mutated_prompt="[最重要制約 - 必ず従うこと]
${mutation_instruction}

---
${prompt}
---

上記の制約を全て満たすコードを生成してください。制約違反は許容されません。"
            ;;
    esac

    SIP_TOTAL_MUTATIONS=$((SIP_TOTAL_MUTATIONS + 1))

    echo "$mutated_prompt"
    return 0
}

# =============================================================================
# 高スコアプロンプト同士の交叉
# =============================================================================
_sip_crossover() {
    local prompt_a="$1"
    local prompt_b="$2"

    [[ "$SIP_INITIALIZED" != "true" ]] && _sip_init

    # 両プロンプトから構造部分と制約部分を抽出して組み合わせ
    local lines_a lines_b
    lines_a=$(echo "$prompt_a" | wc -l)
    lines_b=$(echo "$prompt_b" | wc -l)

    # 前半をAから、後半をBから取る（単純1点交叉）
    local split_a=$((lines_a / 2))
    local split_b=$((lines_b / 2))

    local part1 part2
    part1=$(echo "$prompt_a" | head -n "$split_a")
    part2=$(echo "$prompt_b" | tail -n +"$split_b")

    local offspring="${part1}

${part2}"

    SIP_TOTAL_CROSSOVERS=$((SIP_TOTAL_CROSSOVERS + 1))
    echo "$offspring"
    return 0
}

# =============================================================================
# 最良プロンプトの選択（トーナメント選択）
# =============================================================================
_sip_select_best() {
    local population_size=${#_SIP_POPULATION[@]}
    [[ $population_size -eq 0 ]] && return 1

    local best_idx=0
    local best_score=0

    for ((i=0; i<population_size; i++)); do
        local score="${_SIP_SCORES[$i]:-0}"
        if [[ $score -gt $best_score ]]; then
            best_score=$score
            best_idx=$i
        fi
    done

    SIP_BEST_SCORE=$best_score
    echo "${_SIP_POPULATION[$best_idx]}"
    return 0
}

# =============================================================================
# 1世代の進化サイクル
# =============================================================================
_sip_evolve_generation() {
    local base_prompt="$1"
    local result_file="$2"
    local domain="${3:-general}"

    [[ "$SIP_INITIALIZED" != "true" ]] && _sip_init

    SIP_CURRENT_GENERATION=$((SIP_CURRENT_GENERATION + 1))

    # 現在のプロンプトを評価
    local current_score
    current_score=$(_sip_analyze_result "$base_prompt" "$result_file" "$domain")

    # 変異体を生成（各戦略で1つずつ）
    _SIP_POPULATION=("$base_prompt")
    _SIP_SCORES=("$current_score")

    local strategies=(${!_SIP_MUTATION_STRATEGIES[@]})
    for strategy in "${strategies[@]}"; do
        local mutated
        mutated=$(_sip_mutate_prompt "$base_prompt" "$strategy" "medium")
        _SIP_POPULATION+=("$mutated")
        _SIP_SCORES+=("$current_score")  # 実際にはClaude実行後に再評価
    done

    # 最良を選択
    local best
    best=$(_sip_select_best)

    # ベストプロンプトを保存
    echo "$best" > "${SIP_DATA_DIR}/best_gen${SIP_CURRENT_GENERATION}.txt" 2>/dev/null

    # 世代ログ
    echo "[Gen ${SIP_CURRENT_GENERATION}] score=${current_score} mutations=${#strategies[@]} best=${SIP_BEST_SCORE}" >> "$SIP_GENERATION_LOG" 2>/dev/null

    echo "$best"
    return 0
}

# =============================================================================
# レポート
# =============================================================================
_sip_report() {
    echo -e "\n  ${BOLD:-}═══ Self-Improving Prompts v${SIP_VERSION} ═══${NC:-}"
    echo -e "  世代数           : ${SIP_CURRENT_GENERATION}"
    echo -e "  総変異数         : ${SIP_TOTAL_MUTATIONS}"
    echo -e "  総交叉数         : ${SIP_TOTAL_CROSSOVERS}"
    echo -e "  総評価数         : ${SIP_TOTAL_EVALUATIONS}"
    echo -e "  最高スコア       : ${SIP_BEST_SCORE}"
}

_sip_score() {
    [[ "$SIP_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    local s=50
    [[ $SIP_TOTAL_EVALUATIONS -gt 0 ]] && s=$((s + 15))
    [[ $SIP_BEST_SCORE -gt 70 ]] && s=$((s + 20))
    [[ $SIP_CURRENT_GENERATION -gt 3 ]] && s=$((s + 15))
    [[ $s -gt 100 ]] && s=100
    echo "$s"
}

_sip_init_message() {
    echo -e "  ${GREEN:-}✅ v${SIP_VERSION} self-improving-prompts: 進化的プロンプト自己改善エンジン (Gen ${SIP_CURRENT_GENERATION})${NC:-}" >&2
}

# =============================================================================
# Module Registry 登録
# =============================================================================
_mr_register \
    --name "self-improving-prompts" \
    --version "$SIP_VERSION" \
    --description "進化的プロンプト自己改善エンジン" \
    --init "_sip_init" \
    --report "_sip_report" \
    --score "_sip_score" \
    --enable-var "ENABLE_SELF_IMPROVING_PROMPTS" \
    --cli-flags "--self-improving-prompts:--no-self-improving-prompts" \
    --init-msg "_sip_init_message"
