#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - Migration Engine
# =============================================================================
# DBマイグレーション管理エンジン。
# Prisma/Drizzleのセットアップ、シードスクリプト、CI統合、ロールバック戦略、
# データマイグレーション、スキーマ変更のブレーキングチェンジ検出を行う。
#
# 機能一覧:
#   me_generate_migration_setup  - Prisma migrate / Drizzle migration設定
#   me_generate_seed_script      - リアルなテストデータでのシード
#   me_generate_migration_ci     - CI パイプラインでのマイグレーション検証
#   me_generate_rollback_strategy- ロールバック手順+安全なマイグレーションパターン
#   me_generate_data_migration   - データ変換ユーティリティ
#   me_validate_schema_changes   - ブレーキングチェンジ検出
#   me_inject_migration_patterns - Claudeプロンプトへのパターン注入
#
# 全globals: MIG_ prefix
# =============================================================================

[[ -n "${_MIG_LOADED:-}" ]] && return 0; _MIG_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g MIG_VERSION="140.0"
declare -g MIG_GENERATED=0
declare -g MIG_ERRORS=0
declare -g MIG_PHASE="migration"
declare -g MIG_FILES_WRITTEN=0
declare -g MIG_BREAKING_CHANGES=0

# =============================================================================
# 初期化
# =============================================================================
me_init() {
    MIG_GENERATED=0
    MIG_ERRORS=0
    MIG_FILES_WRITTEN=0
    MIG_BREAKING_CHANGES=0
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} migration-engine v${MIG_VERSION}"
    return 0
}

# =============================================================================
# ユーティリティ
# =============================================================================
_mig_write_file() {
    local filepath="$1"
    local content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then
        MIG_FILES_WRITTEN=$((MIG_FILES_WRITTEN + 1))
        echo "  [migration] wrote: $filepath" >&2
    else
        MIG_ERRORS=$((MIG_ERRORS + 1))
    fi
}

mig_detect_schema_changes() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    if [[ -f "${project_dir}/prisma/schema.prisma" ]]; then
        echo 'prisma-detected'
    elif [[ -f "${project_dir}/drizzle.config.ts" ]]; then
        echo 'drizzle-detected'
    else
        echo 'no-schema'
    fi
}

# =============================================================================
# me_generate_migration_setup - ORM マイグレーション設定
# =============================================================================
me_generate_migration_setup() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local orm="${2:-prisma}"

    if [[ "$orm" == "prisma" ]]; then
        # prisma/migrations helper script
        local runner_ts
        runner_ts=$(cat <<'MREOF'
import { execSync } from 'child_process';
import { existsSync } from 'fs';
import path from 'path';

interface MigrationOptions {
  action: 'deploy' | 'reset' | 'status' | 'create';
  name?: string;
  force?: boolean;
}

export async function runMigration(options: MigrationOptions): Promise<{
  success: boolean;
  output: string;
  error?: string;
}> {
  const schemaPath = path.resolve(process.cwd(), 'prisma/schema.prisma');
  if (!existsSync(schemaPath)) {
    return { success: false, output: '', error: 'prisma/schema.prisma not found' };
  }

  try {
    let cmd: string;
    switch (options.action) {
      case 'deploy':
        cmd = 'npx prisma migrate deploy';
        break;
      case 'reset':
        cmd = `npx prisma migrate reset${options.force ? ' --force' : ' --skip-seed'}`;
        break;
      case 'status':
        cmd = 'npx prisma migrate status';
        break;
      case 'create':
        if (!options.name) throw new Error('Migration name required');
        cmd = `npx prisma migrate dev --name ${options.name} --create-only`;
        break;
      default:
        throw new Error(`Unknown action: ${options.action}`);
    }

    const output = execSync(cmd, {
      encoding: 'utf-8',
      timeout: 60_000,
      env: { ...process.env },
    });

    return { success: true, output };
  } catch (err: any) {
    return {
      success: false,
      output: err.stdout || '',
      error: err.stderr || err.message,
    };
  }
}

export async function createBackup(databaseUrl: string): Promise<string> {
  const timestamp = new Date().toISOString().replace(/[:.]/g, '-');
  const backupFile = `prisma/backups/backup-${timestamp}.sql`;
  try {
    execSync(`mkdir -p prisma/backups`);
    execSync(`pg_dump "${databaseUrl}" > ${backupFile}`, {
      encoding: 'utf-8',
      timeout: 120_000,
    });
    return backupFile;
  } catch (err: any) {
    throw new Error(`Backup failed: ${err.message}`);
  }
}

export async function validateMigration(): Promise<{
  valid: boolean;
  pendingMigrations: number;
  failedMigrations: string[];
}> {
  try {
    const output = execSync('npx prisma migrate status', {
      encoding: 'utf-8',
      timeout: 30_000,
    });
    const pending = (output.match(/Following migration.*not yet been applied/g) || []).length;
    const failed = output.match(/failed to apply.*?(\S+\.sql)/g) || [];
    return {
      valid: pending === 0 && failed.length === 0,
      pendingMigrations: pending,
      failedMigrations: failed,
    };
  } catch {
    return { valid: false, pendingMigrations: -1, failedMigrations: ['status-check-failed'] };
  }
}
MREOF
)
        _mig_write_file "${project_dir}/src/lib/migration-runner.ts" "$runner_ts"

    elif [[ "$orm" == "drizzle" ]]; then
        local drizzle_config
        drizzle_config=$(cat <<'DRCEOF'
import type { Config } from 'drizzle-kit';

export default {
  schema: './src/db/schema.ts',
  out: './drizzle/migrations',
  dialect: 'postgresql',
  dbCredentials: {
    url: process.env.DATABASE_URL!,
  },
  verbose: true,
  strict: true,
} satisfies Config;
DRCEOF
)
        _mig_write_file "${project_dir}/drizzle.config.ts" "$drizzle_config"

        local migrate_ts
        migrate_ts=$(cat <<'DMEOF'
import { drizzle } from 'drizzle-orm/postgres-js';
import { migrate } from 'drizzle-orm/postgres-js/migrator';
import postgres from 'postgres';

async function runMigrations() {
  const connectionString = process.env.DATABASE_URL;
  if (!connectionString) {
    throw new Error('DATABASE_URL is not set');
  }

  const sql = postgres(connectionString, { max: 1 });
  const db = drizzle(sql);

  console.log('Running migrations...');
  await migrate(db, { migrationsFolder: './drizzle/migrations' });
  console.log('Migrations complete');

  await sql.end();
}

runMigrations().catch((err) => {
  console.error('Migration failed:', err);
  process.exit(1);
});
DMEOF
)
        _mig_write_file "${project_dir}/src/db/migrate.ts" "$migrate_ts"
    fi

    MIG_GENERATED=$((MIG_GENERATED + 1))
    return 0
}

# =============================================================================
# me_generate_seed_script - シードスクリプト
# =============================================================================
me_generate_seed_script() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local seed_ts
    seed_ts=$(cat <<'SEEDEOF'
import { PrismaClient } from '@prisma/client';
import { hash } from 'bcryptjs';

const prisma = new PrismaClient();

const SEED_PASSWORD = 'SeedP@ss123!';

interface SeedConfig {
  users: number;
  itemsPerUser: number;
  clean: boolean;
}

const defaultConfig: SeedConfig = {
  users: 10,
  itemsPerUser: 5,
  clean: true,
};

async function cleanDatabase() {
  const tablenames = await prisma.$queryRaw<
    Array<{ tablename: string }>
  >`SELECT tablename FROM pg_tables WHERE schemaname='public'`;

  const tables = tablenames
    .map(({ tablename }) => tablename)
    .filter((name) => name !== '_prisma_migrations')
    .map((name) => `"public"."${name}"`)
    .join(', ');

  if (tables.length > 0) {
    await prisma.$executeRawUnsafe(`TRUNCATE TABLE ${tables} CASCADE;`);
  }
}

async function seedUsers(count: number) {
  const hashedPassword = await hash(SEED_PASSWORD, 12);
  const users = [];

  // Admin user
  const admin = await prisma.user.upsert({
    where: { email: 'admin@example.com' },
    update: {},
    create: {
      email: 'admin@example.com',
      name: 'Admin User',
      password: hashedPassword,
      role: 'admin',
    },
  });
  users.push(admin);

  // Regular users
  for (let i = 1; i <= count; i++) {
    const user = await prisma.user.upsert({
      where: { email: `user${i}@example.com` },
      update: {},
      create: {
        email: `user${i}@example.com`,
        name: `Test User ${i}`,
        password: hashedPassword,
        role: 'user',
      },
    });
    users.push(user);
  }

  return users;
}

async function main() {
  const config = { ...defaultConfig };

  if (process.argv.includes('--no-clean')) {
    config.clean = false;
  }

  console.log('Seeding database with config:', config);

  if (config.clean) {
    console.log('Cleaning database...');
    await cleanDatabase();
  }

  console.log(`Creating ${config.users} users...`);
  const users = await seedUsers(config.users);
  console.log(`Created ${users.length} users`);

  console.log('Seed completed successfully');
  console.log('Admin login: admin@example.com / SeedP@ss123!');
}

main()
  .catch((e) => {
    console.error('Seed failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
SEEDEOF
)
    _mig_write_file "${project_dir}/prisma/seed.ts" "$seed_ts"
    MIG_GENERATED=$((MIG_GENERATED + 1))
    return 0
}

# =============================================================================
# me_generate_migration_ci - CI パイプラインでのマイグレーション検証
# =============================================================================
me_generate_migration_ci() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local ci_step
    ci_step=$(cat <<'MCIEOF'
name: Migration Check

on:
  pull_request:
    paths:
      - 'prisma/schema.prisma'
      - 'prisma/migrations/**'

jobs:
  migration-check:
    name: Validate Migrations
    runs-on: ubuntu-latest
    services:
      postgres:
        image: postgres:16-alpine
        env:
          POSTGRES_USER: postgres
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: migration_test
        ports:
          - 5432:5432
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
    env:
      DATABASE_URL: postgresql://postgres:postgres@localhost:5432/migration_test
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Generate Prisma Client
        run: npx prisma generate

      - name: Validate Schema
        run: npx prisma validate

      - name: Deploy Migrations (fresh DB)
        run: npx prisma migrate deploy

      - name: Check for Pending Migrations
        run: |
          STATUS=$(npx prisma migrate status 2>&1)
          if echo "$STATUS" | grep -q "not yet been applied"; then
            echo "::error::Pending migrations detected"
            exit 1
          fi

      - name: Run Seed (verify seed works)
        run: npx prisma db seed
        env:
          NODE_ENV: test

      - name: Reset & Re-deploy (idempotency check)
        run: |
          npx prisma migrate reset --force --skip-seed
          npx prisma migrate deploy

      - name: Schema Drift Check
        run: |
          npx prisma migrate diff \
            --from-schema-datamodel prisma/schema.prisma \
            --to-migrations prisma/migrations \
            --exit-code || echo "::warning::Schema drift detected"
MCIEOF
)
    _mig_write_file "${project_dir}/.github/workflows/migration-check.yml" "$ci_step"
    MIG_GENERATED=$((MIG_GENERATED + 1))
    return 0
}

# =============================================================================
# me_generate_rollback_strategy - ロールバック戦略
# =============================================================================
me_generate_rollback_strategy() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local rollback_ts
    rollback_ts=$(cat <<'RBEOF'
import { execSync } from 'child_process';
import { readFileSync, readdirSync } from 'fs';
import path from 'path';

interface RollbackPlan {
  currentMigration: string;
  targetMigration: string;
  stepsBack: number;
  requiresDataBackup: boolean;
  destructiveOperations: string[];
}

export function analyzeRollbackRisk(migrationDir: string): RollbackPlan['destructiveOperations'] {
  const destructive: string[] = [];
  const sqlFiles = readdirSync(migrationDir).filter((f) => f.endsWith('.sql'));

  for (const file of sqlFiles) {
    const sql = readFileSync(path.join(migrationDir, file), 'utf-8').toUpperCase();
    if (sql.includes('DROP TABLE')) destructive.push(`${file}: DROP TABLE detected`);
    if (sql.includes('DROP COLUMN')) destructive.push(`${file}: DROP COLUMN detected`);
    if (sql.includes('ALTER COLUMN') && sql.includes('TYPE'))
      destructive.push(`${file}: Column type change detected`);
    if (sql.includes('DELETE FROM')) destructive.push(`${file}: DELETE FROM detected`);
    if (sql.includes('TRUNCATE')) destructive.push(`${file}: TRUNCATE detected`);
  }
  return destructive;
}

export async function rollbackToMigration(targetMigration: string): Promise<void> {
  console.log(`Rolling back to migration: ${targetMigration}`);

  // Step 1: Create backup
  console.log('Creating backup before rollback...');
  execSync('pg_dump "$DATABASE_URL" > prisma/backups/pre-rollback.sql', {
    encoding: 'utf-8',
    timeout: 120_000,
  });

  // Step 2: Mark migrations as rolled back
  execSync(
    `npx prisma migrate resolve --rolled-back ${targetMigration}`,
    { encoding: 'utf-8', timeout: 30_000 }
  );

  // Step 3: Deploy to target state
  execSync('npx prisma migrate deploy', {
    encoding: 'utf-8',
    timeout: 60_000,
  });

  console.log('Rollback completed');
}

// Safe migration patterns
export const SAFE_MIGRATION_PATTERNS = {
  addColumn: `
    -- SAFE: Adding a nullable column
    ALTER TABLE "TableName" ADD COLUMN "newCol" TEXT;
  `,
  addColumnWithDefault: `
    -- SAFE: Adding column with default (no lock on PG 11+)
    ALTER TABLE "TableName" ADD COLUMN "newCol" TEXT NOT NULL DEFAULT 'value';
  `,
  renameColumnSafe: `
    -- SAFE: Two-phase rename (add new, copy, drop old)
    ALTER TABLE "TableName" ADD COLUMN "newName" TEXT;
    UPDATE "TableName" SET "newName" = "oldName";
    -- Deploy app reading both columns
    -- Next migration: ALTER TABLE "TableName" DROP COLUMN "oldName";
  `,
  createIndex: `
    -- SAFE: Concurrent index creation (no table lock)
    CREATE INDEX CONCURRENTLY "idx_table_col" ON "TableName" ("col");
  `,
};
RBEOF
)
    _mig_write_file "${project_dir}/src/lib/rollback-strategy.ts" "$rollback_ts"
    MIG_GENERATED=$((MIG_GENERATED + 1))
    return 0
}

# =============================================================================
# me_generate_data_migration - データ変換ユーティリティ
# =============================================================================
me_generate_data_migration() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local data_mig_ts
    data_mig_ts=$(cat <<'DMIGEOF'
import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

interface DataMigrationJob {
  name: string;
  description: string;
  batchSize: number;
  run: (prisma: PrismaClient) => Promise<{ processed: number; errors: number }>;
}

const migrations: DataMigrationJob[] = [];

export function registerDataMigration(job: DataMigrationJob) {
  migrations.push(job);
}

export async function runDataMigrations(targetName?: string) {
  const jobs = targetName ? migrations.filter((m) => m.name === targetName) : migrations;

  for (const job of jobs) {
    console.log(`Running data migration: ${job.name} - ${job.description}`);
    const startTime = Date.now();

    try {
      const result = await job.run(prisma);
      const duration = ((Date.now() - startTime) / 1000).toFixed(1);
      console.log(
        `  Completed: ${result.processed} processed, ${result.errors} errors (${duration}s)`
      );
    } catch (err) {
      console.error(`  FAILED: ${job.name}`, err);
      throw err;
    }
  }
}

// --- Example data migration: Normalize email addresses ---
registerDataMigration({
  name: 'normalize-emails',
  description: 'Lowercase all email addresses',
  batchSize: 500,
  async run(db) {
    let processed = 0;
    let errors = 0;
    const batchSize = 500;
    let skip = 0;

    while (true) {
      const users = await db.user.findMany({
        take: batchSize,
        skip,
        select: { id: true, email: true },
      });
      if (users.length === 0) break;

      for (const user of users) {
        const normalized = user.email.toLowerCase().trim();
        if (normalized !== user.email) {
          try {
            await db.user.update({
              where: { id: user.id },
              data: { email: normalized },
            });
            processed++;
          } catch {
            errors++;
          }
        }
      }
      skip += batchSize;
    }
    return { processed, errors };
  },
});

// --- Example: Backfill computed field ---
registerDataMigration({
  name: 'backfill-full-name',
  description: 'Compute fullName from firstName + lastName',
  batchSize: 1000,
  async run(db) {
    const result = await db.$executeRaw`
      UPDATE "User"
      SET "fullName" = CONCAT("firstName", ' ', "lastName")
      WHERE "fullName" IS NULL
        AND "firstName" IS NOT NULL
    `;
    return { processed: Number(result), errors: 0 };
  },
});

// CLI entry point
if (require.main === module) {
  const target = process.argv[2];
  runDataMigrations(target)
    .then(() => process.exit(0))
    .catch(() => process.exit(1))
    .finally(() => prisma.$disconnect());
}
DMIGEOF
)
    _mig_write_file "${project_dir}/src/lib/data-migration.ts" "$data_mig_ts"
    MIG_GENERATED=$((MIG_GENERATED + 1))
    return 0
}

# =============================================================================
# me_validate_schema_changes - ブレーキングチェンジ検出
# =============================================================================
me_validate_schema_changes() {
    local schema_file="${1:-}"
    local project_dir="${PROJECT_DIR:-./output}"

    if [[ -z "$schema_file" ]]; then
        schema_file="${project_dir}/prisma/schema.prisma"
    fi

    if [[ ! -f "$schema_file" ]]; then
        echo "[migration] Schema file not found: $schema_file" >&2
        MIG_ERRORS=$((MIG_ERRORS + 1))
        return 1
    fi

    local breaking=0
    local warnings=""

    # Check for git diff on schema
    local diff_output=""
    if command -v git &>/dev/null; then
        diff_output=$(cd "$(dirname "$schema_file")" && git diff HEAD -- "$(basename "$schema_file")" 2>/dev/null || true)
    fi

    if [[ -n "$diff_output" ]]; then
        # Detect dropped models
        local dropped_models
        dropped_models=$(echo "$diff_output" | grep '^-model ' | sed 's/^-model //' | awk '{print $1}')
        if [[ -n "$dropped_models" ]]; then
            warnings="${warnings}\n  BREAKING: Dropped models: ${dropped_models}"
            breaking=$((breaking + $(echo "$dropped_models" | wc -l)))
        fi

        # Detect removed fields
        local removed_fields
        removed_fields=$(echo "$diff_output" | grep -E '^\-\s+\w+\s+(String|Int|Float|Boolean|DateTime|Json|Bytes)' | sed 's/^-//' | awk '{print $1}')
        if [[ -n "$removed_fields" ]]; then
            warnings="${warnings}\n  BREAKING: Removed fields: ${removed_fields}"
            breaking=$((breaking + $(echo "$removed_fields" | wc -l)))
        fi

        # Detect type changes
        local type_changes
        type_changes=$(echo "$diff_output" | grep -E '^\+\s+\w+\s+(String|Int|Float|Boolean|DateTime|Json|Bytes)' | while read -r line; do
            local field
            field=$(echo "$line" | awk '{print $1}' | sed 's/^+//')
            if echo "$diff_output" | grep -qE "^\-\s+${field}\s+"; then
                echo "$field"
            fi
        done)
        if [[ -n "$type_changes" ]]; then
            warnings="${warnings}\n  WARNING: Possible type changes: ${type_changes}"
        fi

        # Detect optional -> required changes
        if echo "$diff_output" | grep -qE '^\-.*\?\s*$' && echo "$diff_output" | grep -qE '^\+.*[^?]\s*$'; then
            warnings="${warnings}\n  WARNING: Optional to required field change detected"
            breaking=$((breaking + 1))
        fi
    fi

    MIG_BREAKING_CHANGES=$breaking

    if [[ $breaking -gt 0 ]]; then
        echo -e "  [migration] ${breaking} breaking change(s) detected:${warnings}" >&2
        return 1
    else
        echo "  [migration] No breaking changes detected" >&2
        return 0
    fi
}

# =============================================================================
# me_inject_migration_patterns - Claudeプロンプトへのパターン注入
# =============================================================================
me_inject_migration_patterns() {
    local prompt="${1:-}"

    cat <<'INJECT'

## [Migration Patterns] - データベースマイグレーション必須要件

### マイグレーション安全ルール:
- **カラム追加**: 常にNULLABLEで追加し、後からDEFAULTを設定
- **カラム削除**: 2段階で実施（コードから参照除去→次リリースでDROP）
- **型変更**: 新カラム追加→データコピー→コード切替→旧カラム削除
- **インデックス**: CONCURRENTLY修飾子で無停止作成
- **バックアップ**: マイグレーション前に必ずpg_dumpを実行

### Prisma必須パターン:
- `prisma migrate dev --name descriptive_name` で開発時マイグレーション
- `prisma migrate deploy` で本番デプロイ（本番でdevは絶対禁止）
- `prisma migrate status` でCI/CDで未適用チェック
- `prisma db seed` でテストデータ投入

### シードスクリプト要件:
- 冪等性必須（何度実行しても同じ結果）
- upsert使用でconflictを回避
- パスワードは必ずbcryptでハッシュ化
- リアルなデータ（faker不要、手書きで十分）

INJECT

    echo "$prompt"
}

# =============================================================================
# mig_generate_migration - 全マイグレーション一括生成（レガシー互換）
# =============================================================================
mig_generate_migration() {
    local project_dir="${PROJECT_DIR:-./output}"
    me_generate_migration_setup "$project_dir" "prisma"
    me_generate_seed_script "$project_dir"
    me_generate_migration_ci "$project_dir"
    me_generate_rollback_strategy "$project_dir"
    me_generate_data_migration "$project_dir"
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
mig_report() {
    echo -e "\n  ${BOLD:-}=== migration-engine v${MIG_VERSION} ===${NC:-}"
    echo -e "  生成数: ${MIG_GENERATED}"
    echo -e "  書込数: ${MIG_FILES_WRITTEN}"
    echo -e "  ブレーキング: ${MIG_BREAKING_CHANGES}"
    echo -e "  エラー: ${MIG_ERRORS}"
}

mig_score() {
    if [[ ${MIG_GENERATED} -ge 3 ]] && [[ ${MIG_ERRORS} -eq 0 ]]; then
        echo "95"
    elif [[ ${MIG_GENERATED} -gt 0 ]] && [[ ${MIG_ERRORS} -eq 0 ]]; then
        echo "85"
    elif [[ ${MIG_GENERATED} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "migration-engine" --version "${MIG_VERSION}" \
        --description "DBマイグレーション管理×スキーマ検証×ロールバック戦略" \
        --init "me_init" --report "mig_report" --score "mig_score" \
        --enable-var "ENABLE_MIGRATION" --cli-flags "--migration:--no-migration"
fi

# v2003.1: source時のexit codeを確実に0にする
true
