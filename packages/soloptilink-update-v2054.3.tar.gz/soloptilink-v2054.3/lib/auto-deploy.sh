#!/usr/bin/env bash
# SoloptiLink Chain v11.0 - Auto-Deployment Module
# After validation passes, auto-deploy to Vercel, Railway, Netlify, GH-Pages,
# Docker, or serve locally.
# Detects project type, available tooling, selects the best deployment strategy.
#
# v11.0 Enhancements:
#   - Docker support (Dockerfile + docker-compose generation, build, run)
#   - Rollback mechanism (revert to previous deployment)
#   - Secret management (scan for exposed secrets before deploy)
#   - Deploy preview URLs (unique per non-production deploy)
#   - Post-deploy smoke test (check key routes after health check)
#   - Deploy history (timestamped log of all deployments)
#
# Sourced by the main orchestrator -- do NOT use set -euo pipefail.

[[ -n "${_AUTO_DEPLOY_LOADED:-}" ]] && return 0
_AUTO_DEPLOY_LOADED=1

###############################################################################
# Constants & Paths
###############################################################################
DP_HISTORY_DIR="${HOME}/.soloptilink/deploy-history"
DP_ROLLBACK_DIR="${HOME}/.soloptilink/deploy-rollback"
DP_SECRET_PATTERNS='(API_KEY|SECRET_KEY|PRIVATE_KEY|PASSWORD|DB_PASSWORD|DATABASE_URL|AWS_SECRET|TOKEN|OAUTH_SECRET|JWT_SECRET|STRIPE_SK|SENDGRID_API|FIREBASE_KEY|GITHUB_TOKEN|GH_TOKEN|NPM_TOKEN|HEROKU_API|SLACK_TOKEN|TWILIO_AUTH)[[:space:]]*='

###############################################################################
# 1. deploy_init(project_dir) -- colours, state, detect targets
###############################################################################
deploy_init() {
    local project_dir="${1:?deploy_init: project_dir required}"

    # Colours
    DP_GREEN="\033[0;32m"; DP_RED="\033[0;31m"; DP_YELLOW="\033[1;33m"
    DP_CYAN="\033[0;36m";  DP_BLUE="\033[0;34m"; DP_MAGENTA="\033[0;35m"
    DP_BOLD="\033[1m";     DP_RESET="\033[0m"

    # State
    declare -g DP_PROJECT_DIR="$project_dir" DP_PROJECT_TYPE="" DP_DEPLOY_URL=""
    declare -g DP_DEPLOY_METHOD="" DP_LOCAL_PID=""
    declare -g DP_PREVIEW_URL="" DP_DEPLOY_ID=""
    declare -g -a DP_AVAILABLE_TARGETS=()

    # Ensure history & rollback directories exist
    mkdir -p "$DP_HISTORY_DIR" 2>/dev/null || true
    mkdir -p "$DP_ROLLBACK_DIR" 2>/dev/null || true

    deploy_detect_targets "$project_dir"
    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Initialised  dir=${DP_BOLD}${project_dir}${DP_RESET}"
    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Available targets: ${DP_AVAILABLE_TARGETS[*]:-none}"
}

###############################################################################
# 2. deploy_auto(project_dir) -- MAIN: detect, secrets, select, deploy,
#    health-check, smoke-test, history
###############################################################################
deploy_auto() {
    local project_dir="${1:-$DP_PROJECT_DIR}"
    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} ${DP_BOLD}Auto-deploy starting${DP_RESET} for ${project_dir}"

    _deploy_detect_project_type "$project_dir"
    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Project type: ${DP_BOLD}${DP_PROJECT_TYPE}${DP_RESET}"

    # ── PFP-087: Deploy-Time Login Guarantee (preflight) ──────────────────
    # ローカルで PFP-086 が PASS しても、本番デプロイ後にログインできない事案
    # (SQLite on serverless / NEXTAUTH_URL・SECRET 未設定 / 本番DB未シード) を
    # デプロイ前に検出し、致命なら deploy を中止する。これが「デプロイ=ログイン
    # できる状態」の構造的大前提 (2026-05-31 小貫さん事案)。
    local _dlg="$HOME/.soloptilink/lib/first-boot-perfect/deploy-login-guarantee.sh"
    if [[ -x "$_dlg" ]]; then
        if bash "$_dlg" "$project_dir" >/dev/null 2>&1; then
            echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} Deploy-time login preflight OK (PFP-087)"
        else
            local _dlg_json="${project_dir}/.soloptilink/deploy-login-guarantee.json"
            local _dlg_verdict; _dlg_verdict="$(python3 -c "import json;print(json.load(open('$_dlg_json')).get('verdict',''))" 2>/dev/null || echo "")"
            if [[ "$_dlg_verdict" == "BLOCK" ]]; then
                echo -e "${DP_RED}[DEPLOY]${DP_RESET} デプロイ時ログイン保証 (PFP-087) が致命的問題を検出:"
                python3 -c "import json;[print('   ■ '+b) for b in json.load(open('$_dlg_json')).get('blockers',[])]" 2>/dev/null || true
                if [[ "${SOLOPTILINK_DEPLOY_LOGIN_GATE:-block}" == "warn" ]]; then
                    echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} SOLOPTILINK_DEPLOY_LOGIN_GATE=warn のため続行 (本番でログインできない可能性)。"
                else
                    echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} 上記を修正してから再デプロイしてください (一時回避: SOLOPTILINK_DEPLOY_LOGIN_GATE=warn)。"
                    echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} 自動是正の試行: bash \"$_dlg\" \"$project_dir\" --apply --url <本番URL>"
                    _deploy_record_history "$project_dir" "blocked_login_gate"
                    return 1
                fi
            fi
        fi
    fi

    # ── PFP-090: Secret-in-Prompt Protection (deploy preflight / G7・L10) ──
    # 生成物に平文の APIキー/接続文字列/秘密鍵が残ったまま本番へ出す事故を防ぐ。
    # SoT=secret-patterns.json で leak-scan し、BLOCK なら deploy を中止する。
    local _spg="$HOME/.soloptilink/lib/first-boot-perfect/secret-protection-guarantee.sh"
    if [[ -x "$_spg" ]]; then
        if bash "$_spg" "$project_dir" >/dev/null 2>&1; then
            echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} Secret protection preflight OK (PFP-090)"
        else
            local _spg_json="${project_dir}/.soloptilink/secret-protection-guarantee.json"
            local _spg_verdict; _spg_verdict="$(python3 -c "import json;print(json.load(open('$_spg_json')).get('verdict',''))" 2>/dev/null || echo "")"
            if [[ "$_spg_verdict" == "BLOCK" ]]; then
                echo -e "${DP_RED}[DEPLOY]${DP_RESET} 機密保護 (PFP-090) が平文のAPIキー残存を検出:"
                python3 -c "import json;[print('   ■ '+x.get('file','?')+' ('+x.get('pattern','?')+')') for x in json.load(open('$_spg_json')).get('leaks',[])]" 2>/dev/null || true
                if [[ "${SOLOPTILINK_DEPLOY_SECRET_GATE:-block}" == "warn" ]]; then
                    echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} SOLOPTILINK_DEPLOY_SECRET_GATE=warn のため続行 (機密が本番に出る可能性)。"
                else
                    echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} 平文キーを削除し環境変数(Vercel encrypted env)/api-key-vaultへ移してから再デプロイしてください。"
                    _deploy_record_history "$project_dir" "blocked_secret_gate"
                    return 1
                fi
            fi
        fi
    fi

    # v11.0: Secret check before deploy
    if ! _deploy_check_secrets "$project_dir"; then
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} Aborting deploy due to exposed secrets."
        echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} Fix the secrets above, then re-run deploy."
        return 1
    fi

    deploy_detect_targets "$project_dir"

    # Generate a unique deploy ID for this run
    DP_DEPLOY_ID="dp-$(date '+%Y%m%d%H%M%S')-$$"

    # v11.0: Save rollback snapshot before deploying
    _deploy_save_rollback "$project_dir"

    # v15.5: Plugin hook - pre_deploy
    type -t pl_fire_hook &>/dev/null && pl_fire_hook "pre_deploy" "${DP_TARGET:-}" 2>/dev/null || true

    local deploy_rc=1
    case "$DP_PROJECT_TYPE" in
        nextjs|react|vue|nuxt)
            if _dp_has_target "vercel"; then
                echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Strategy: Vercel"
                _deploy_vercel "$project_dir"; deploy_rc=$?; DP_DEPLOY_METHOD="vercel"
            elif _dp_has_target "netlify"; then
                _deploy_netlify "$project_dir"; deploy_rc=$?; DP_DEPLOY_METHOD="netlify"
            elif _dp_has_target "railway"; then
                _deploy_railway "$project_dir"; deploy_rc=$?; DP_DEPLOY_METHOD="railway"
            elif _dp_has_target "docker"; then
                _deploy_docker "$project_dir"; deploy_rc=$?; DP_DEPLOY_METHOD="docker"
            else
                echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} No cloud CLI. Falling back to local."
                _deploy_local_serve "$project_dir"; deploy_rc=$?; DP_DEPLOY_METHOD="local"
            fi ;;
        static)
            if _dp_has_target "gh-pages"; then
                _deploy_gh_pages "$project_dir"; deploy_rc=$?; DP_DEPLOY_METHOD="gh-pages"
            elif _dp_has_target "docker"; then
                _deploy_docker "$project_dir"; deploy_rc=$?; DP_DEPLOY_METHOD="docker"
            else
                _deploy_local_serve "$project_dir"; deploy_rc=$?; DP_DEPLOY_METHOD="local"
            fi ;;
        python|flask|django|fastapi)
            if _dp_has_target "railway"; then
                _deploy_railway "$project_dir"; deploy_rc=$?; DP_DEPLOY_METHOD="railway"
            elif _dp_has_target "docker"; then
                _deploy_docker "$project_dir"; deploy_rc=$?; DP_DEPLOY_METHOD="docker"
            else
                _deploy_local_serve "$project_dir"; deploy_rc=$?; DP_DEPLOY_METHOD="local"
            fi ;;
        *)
            echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} Unknown type."
            if _dp_has_target "docker"; then
                _deploy_docker "$project_dir"; deploy_rc=$?; DP_DEPLOY_METHOD="docker"
            else
                _deploy_local_serve "$project_dir"; deploy_rc=$?; DP_DEPLOY_METHOD="local"
            fi ;;
    esac

    # Health check
    if [[ $deploy_rc -eq 0 && -n "$DP_DEPLOY_URL" ]]; then
        echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Running health check..."
        if deploy_health_check "$DP_DEPLOY_URL" 5; then
            echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} Health check passed!"

            # v11.0: Post-deploy smoke test
            echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Running post-deploy smoke test..."
            if _deploy_smoke_test "$DP_DEPLOY_URL" "$project_dir"; then
                echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} Smoke test passed!"
            else
                echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} Smoke test had warnings (non-fatal)."
            fi

            # ── PFP-087: Deploy-Time Login Guarantee (postflight probe) ──
            # スモークテストは HTTP ステータスしか見ない。ここで本番 URL の NextAuth
            # credentials フロー (csrf→callback→session) を seed 認証情報で実走し、
            # 「本当にログインできるか」を最終保証する (3回リトライで断続失敗も検出)。
            if [[ -x "$_dlg" ]]; then
                echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} 本番URLで実ログイン検証 (PFP-087 probe)..."
                if bash "$_dlg" "$project_dir" --probe "$DP_DEPLOY_URL" >/dev/null 2>&1; then
                    echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} ✅ 本番ログイン検証 PASS — お客様は初回からログインできます"
                else
                    echo -e "${DP_RED}[DEPLOY]${DP_RESET} ⚠️ 本番URLでログインできませんでした (PFP-087 probe FAIL)"
                    echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET}    詳細: ${project_dir}/.soloptilink/deploy-login-guarantee.json"
                    echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET}    主因候補: NEXTAUTH_URL/NEXTAUTH_SECRET 未設定 / 本番DB未シード / SQLite誤デプロイ"
                    echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET}    自動是正: bash \"$_dlg\" \"$project_dir\" --apply --url \"$DP_DEPLOY_URL\""
                fi
            fi
        else
            echo -e "${DP_RED}[DEPLOY]${DP_RESET} Health check failed. May need manual verification."
            deploy_report "$DP_DEPLOY_URL" "$DP_PROJECT_TYPE"
            _deploy_record_history "$project_dir" "failed"
            return 1
        fi

        # v15.5: Plugin hook - post_deploy
        type -t pl_fire_hook &>/dev/null && pl_fire_hook "post_deploy" "${DP_TARGET:-}" 2>/dev/null || true

        # v11.0: Generate preview URL for non-production
        _deploy_generate_preview_url

        deploy_report "$DP_DEPLOY_URL" "$DP_PROJECT_TYPE"

        # v11.0: Record successful deployment to history
        _deploy_record_history "$project_dir" "success"
    else
        [[ $deploy_rc -ne 0 ]] && _deploy_record_history "$project_dir" "failed"
    fi

    return "$deploy_rc"
}

###############################################################################
# Internal: detect project type from files
###############################################################################
_deploy_detect_project_type() {
    local dir="$1"
    if [[ -f "${dir}/next.config.js" || -f "${dir}/next.config.mjs" || -f "${dir}/next.config.ts" ]]; then
        DP_PROJECT_TYPE="nextjs"
    elif [[ -f "${dir}/nuxt.config.js" || -f "${dir}/nuxt.config.ts" ]]; then
        DP_PROJECT_TYPE="nuxt"
    elif [[ -f "${dir}/vue.config.js" ]]; then
        DP_PROJECT_TYPE="vue"
    elif [[ -f "${dir}/vite.config.ts" || -f "${dir}/vite.config.js" ]]; then
        if [[ -f "${dir}/package.json" ]] && grep -q '"vue"' "${dir}/package.json" 2>/dev/null; then
            DP_PROJECT_TYPE="vue"
        elif [[ -f "${dir}/package.json" ]] && grep -q '"react"' "${dir}/package.json" 2>/dev/null; then
            DP_PROJECT_TYPE="react"
        else
            DP_PROJECT_TYPE="nodejs"
        fi
    elif [[ -f "${dir}/package.json" ]] && grep -q '"react"' "${dir}/package.json" 2>/dev/null; then
        DP_PROJECT_TYPE="react"
    elif [[ -f "${dir}/requirements.txt" || -f "${dir}/pyproject.toml" || -f "${dir}/setup.py" ]]; then
        if grep -q 'flask' "${dir}/requirements.txt" 2>/dev/null; then DP_PROJECT_TYPE="flask"
        elif grep -q 'django' "${dir}/requirements.txt" 2>/dev/null; then DP_PROJECT_TYPE="django"
        elif grep -q 'fastapi' "${dir}/requirements.txt" 2>/dev/null; then DP_PROJECT_TYPE="fastapi"
        else DP_PROJECT_TYPE="python"; fi
    elif [[ -f "${dir}/index.html" ]]; then DP_PROJECT_TYPE="static"
    elif [[ -f "${dir}/package.json" ]]; then DP_PROJECT_TYPE="nodejs"
    else DP_PROJECT_TYPE="unknown"; fi
}

###############################################################################
# Internal: check if target is available
###############################################################################
_dp_has_target() {
    local t; for t in "${DP_AVAILABLE_TARGETS[@]}"; do [[ "$t" == "$1" ]] && return 0; done; return 1
}

###############################################################################
# 3. _deploy_vercel(project_dir)
###############################################################################
_deploy_vercel() {
    local project_dir="$1"
    command -v vercel >/dev/null 2>&1 || { echo -e "${DP_RED}[DEPLOY]${DP_RESET} Vercel CLI not found." >&2; return 1; }
    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Deploying to Vercel (preview)..."
    local output; output=$(cd "$project_dir" && vercel --yes 2>&1); local rc=$?
    if [[ $rc -eq 0 ]]; then
        DP_DEPLOY_URL=$(echo "$output" | sed 's/\x1b\[[0-9;]*m//g' | grep -oE 'https://[a-zA-Z0-9._/-]+' | tail -1)
        echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} Vercel: ${DP_BOLD}${DP_DEPLOY_URL}${DP_RESET}"
    else
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} Vercel failed (exit=${rc})"; echo "$output" | tail -5
    fi
    return "$rc"
}

###############################################################################
# 4. _deploy_local_serve(project_dir)
###############################################################################
_deploy_local_serve() {
    local project_dir="$1" port="${DP_LOCAL_PORT:-3000}"
    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Starting local server on port ${port}..."
    local logf="/tmp/soloptilink_deploy_local.log"
    local _dp_prev_dir="$PWD"
    cd "$project_dir" 2>/dev/null || { echo -e "${DP_RED}[DEPLOY]${DP_RESET} cd failed"; return 1; }
    case "$DP_PROJECT_TYPE" in
        nextjs|react|vue|nuxt|nodejs)
            if [[ -f "package.json" ]]; then
                if grep -q '"dev"' "package.json" 2>/dev/null; then
                    PORT=$port npm run dev > "$logf" 2>&1 &
                elif grep -q '"start"' "package.json" 2>/dev/null; then
                    PORT=$port npm start > "$logf" 2>&1 &
                else
                    cd "$_dp_prev_dir" 2>/dev/null || true
                    echo -e "${DP_RED}[DEPLOY]${DP_RESET} No dev/start script"; return 1
                fi
                DP_LOCAL_PID=$!
            fi ;;
        flask)
            FLASK_APP=app.py flask run --port "$port" > "$logf" 2>&1 &
            DP_LOCAL_PID=$! ;;
        django)
            python3 manage.py runserver "0.0.0.0:${port}" > "$logf" 2>&1 &
            DP_LOCAL_PID=$! ;;
        fastapi)
            uvicorn main:app --host 0.0.0.0 --port "$port" > "$logf" 2>&1 &
            DP_LOCAL_PID=$! ;;
        python|static|*)
            python3 -m http.server "$port" > "$logf" 2>&1 &
            DP_LOCAL_PID=$! ;;
    esac
    cd "$_dp_prev_dir" 2>/dev/null || true
    sleep 3
    if kill -0 "$DP_LOCAL_PID" 2>/dev/null; then
        DP_DEPLOY_URL="http://localhost:${port}"
        echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} Running: ${DP_BOLD}${DP_DEPLOY_URL}${DP_RESET} (pid=${DP_LOCAL_PID})"
        return 0
    else
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} Server failed to start. See ${logf}"; return 1
    fi
}

###############################################################################
# 5. _deploy_gh_pages(project_dir) -- safe temp-directory approach
###############################################################################
_deploy_gh_pages() {
    local project_dir="$1"
    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Deploying to GitHub Pages..."
    # Build if needed
    if [[ -f "${project_dir}/package.json" ]] && grep -q '"build"' "${project_dir}/package.json" 2>/dev/null; then
        echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Building..."
        (cd "$project_dir" && npm run build 2>&1) || { echo -e "${DP_RED}[DEPLOY]${DP_RESET} Build failed."; return 1; }
    fi
    # Find build output
    local build_dir=""
    for d in dist build out public _site; do
        [[ -d "${project_dir}/${d}" ]] && { build_dir="${project_dir}/${d}"; break; }
    done
    [[ -z "$build_dir" ]] && build_dir="$project_dir"

    local tmp_dir
    tmp_dir=$(mktemp -d) || { echo -e "${DP_RED}[DEPLOY]${DP_RESET} Failed to create temp dir"; return 1; }

    local remote_url
    remote_url=$(cd "$project_dir" && git remote get-url origin 2>/dev/null) || {
        rm -rf "$tmp_dir"
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} No git remote 'origin' found"; return 1
    }

    cp -r "${build_dir}/"* "$tmp_dir/" 2>/dev/null || true
    cp -r "${build_dir}/".[!.]* "$tmp_dir/" 2>/dev/null || true

    local rc=0
    (
        cd "$tmp_dir" || exit 1
        git init -q 2>/dev/null
        git checkout -b gh-pages 2>/dev/null
        git add -A 2>/dev/null
        git commit -m "Deploy to GitHub Pages [auto-deploy $(date '+%Y-%m-%d %H:%M')]" -q 2>/dev/null || {
            echo -e "${DP_RED}[DEPLOY]${DP_RESET} Nothing to commit"; exit 1
        }
        git remote add origin "$remote_url" 2>/dev/null
        git push origin gh-pages --force 2>&1
    )
    rc=$?

    rm -rf "$tmp_dir"

    if [[ $rc -eq 0 ]]; then
        local repo_name
        repo_name=$(echo "$remote_url" | sed -E 's|.*/([^/]+)(\.git)?$|\1|')
        local owner
        owner=$(echo "$remote_url" | sed -E 's|.*[:/]([^/]+)/[^/]+$|\1|')
        DP_DEPLOY_URL="https://${owner}.github.io/${repo_name}"
        echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} GitHub Pages: ${DP_BOLD}${DP_DEPLOY_URL}${DP_RESET}"
    else
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} GitHub Pages deploy failed"
    fi
    return "$rc"
}

###############################################################################
# Internal: deploy to Railway
###############################################################################
_deploy_railway() {
    local project_dir="$1"
    command -v railway >/dev/null 2>&1 || { echo -e "${DP_RED}[DEPLOY]${DP_RESET} Railway CLI not found." >&2; return 1; }
    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Deploying to Railway..."
    local output; output=$(cd "$project_dir" && railway up --detach 2>&1); local rc=$?
    if [[ $rc -eq 0 ]]; then
        DP_DEPLOY_URL=$(echo "$output" | sed 's/\x1b\[[0-9;]*m//g' | grep -oE 'https://[a-zA-Z0-9._/-]+' | tail -1)
        echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} Railway: ${DP_BOLD}${DP_DEPLOY_URL}${DP_RESET}"
    else
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} Railway failed (exit=${rc})"; echo "$output" | tail -5
    fi
    return "$rc"
}

###############################################################################
# Internal: deploy to Netlify
###############################################################################
_deploy_netlify() {
    local project_dir="$1"
    command -v netlify >/dev/null 2>&1 || { echo -e "${DP_RED}[DEPLOY]${DP_RESET} Netlify CLI not found." >&2; return 1; }
    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Deploying to Netlify..."
    local output; output=$(cd "$project_dir" && netlify deploy --prod 2>&1); local rc=$?
    if [[ $rc -eq 0 ]]; then
        DP_DEPLOY_URL=$(echo "$output" | sed 's/\x1b\[[0-9;]*m//g' | grep -oE 'https://[a-zA-Z0-9._/-]+' | tail -1)
        echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} Netlify: ${DP_BOLD}${DP_DEPLOY_URL}${DP_RESET}"
    else
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} Netlify failed (exit=${rc})"; echo "$output" | tail -5
    fi
    return "$rc"
}

###############################################################################
# 6. deploy_detect_targets(project_dir)
###############################################################################
deploy_detect_targets() {
    local project_dir="${1:-.}"
    DP_AVAILABLE_TARGETS=()
    command -v vercel  >/dev/null 2>&1 && DP_AVAILABLE_TARGETS+=("vercel")
    command -v railway >/dev/null 2>&1 && DP_AVAILABLE_TARGETS+=("railway")
    command -v netlify >/dev/null 2>&1 && DP_AVAILABLE_TARGETS+=("netlify")
    if [[ -d "${project_dir}/.git" ]] || git -C "$project_dir" rev-parse --git-dir >/dev/null 2>&1; then
        local ru; ru=$(git -C "$project_dir" remote get-url origin 2>/dev/null)
        [[ "$ru" == *"github.com"* ]] && DP_AVAILABLE_TARGETS+=("gh-pages")
    fi
    # v11.0: Docker target detection
    if command -v docker >/dev/null 2>&1; then
        DP_AVAILABLE_TARGETS+=("docker")
    fi
    { command -v python3 >/dev/null 2>&1 || command -v node >/dev/null 2>&1; } && DP_AVAILABLE_TARGETS+=("local")
}

###############################################################################
# 7. deploy_health_check(url, retries)
###############################################################################
deploy_health_check() {
    local url="${1:?url required}" retries="${2:-5}" delay=3 attempt=0
    command -v curl >/dev/null 2>&1 || { echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} curl unavailable, skip." >&2; return 0; }
    while [[ $attempt -lt $retries ]]; do
        attempt=$((attempt + 1))
        echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Health check ${attempt}/${retries}: ${url}"
        local code; code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$url" 2>/dev/null)
        if [[ "$code" =~ ^2[0-9][0-9]$ ]]; then
            echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} HTTP ${code} OK"; return 0
        fi
        echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} HTTP ${code}, retry in ${delay}s..."; sleep "$delay"
    done
    echo -e "${DP_RED}[DEPLOY]${DP_RESET} Health check failed after ${retries} attempts."; return 1
}

###############################################################################
# 8. deploy_report(deploy_url, project_type)
###############################################################################
deploy_report() {
    local deploy_url="${1:-$DP_DEPLOY_URL}" project_type="${2:-$DP_PROJECT_TYPE}"
    echo ""
    echo -e "${DP_CYAN}========================================${DP_RESET}"
    echo -e "${DP_BOLD} Deployment Report${DP_RESET}"
    echo -e "${DP_CYAN}========================================${DP_RESET}"
    echo -e " Project dir   : ${DP_PROJECT_DIR}"
    echo -e " Project type  : ${DP_BOLD}${project_type}${DP_RESET}"
    echo -e " Deploy method : ${DP_BOLD}${DP_DEPLOY_METHOD}${DP_RESET}"
    echo -e " Deploy ID     : ${DP_DEPLOY_ID}"
    echo -e " URL           : ${DP_GREEN}${DP_BOLD}${deploy_url}${DP_RESET}"
    [[ -n "$DP_PREVIEW_URL" ]] && \
    echo -e " Preview URL   : ${DP_BLUE}${DP_BOLD}${DP_PREVIEW_URL}${DP_RESET}"
    [[ -n "$DP_LOCAL_PID" ]] && echo -e " Local PID     : ${DP_LOCAL_PID}  (kill ${DP_LOCAL_PID} to stop)"
    echo -e " Targets avail : ${DP_AVAILABLE_TARGETS[*]:-none}"
    echo -e " Deployed at   : $(date '+%Y-%m-%d %H:%M:%S')"
    echo -e "${DP_CYAN}========================================${DP_RESET}"
    echo ""
}

###############################################################################
#                        v11.0 NEW FEATURES BELOW                             #
###############################################################################

###############################################################################
# 9. _deploy_docker(project_dir) -- Docker support
#    Generates Dockerfile + docker-compose.yml if missing, builds, and runs.
###############################################################################
_deploy_docker() {
    local project_dir="$1"
    local port="${DP_LOCAL_PORT:-3000}"
    local container_name="soloptilink-${DP_DEPLOY_ID:-app}"

    command -v docker >/dev/null 2>&1 || {
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} Docker not found." >&2; return 1
    }

    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Deploying via Docker..."

    # Generate Dockerfile if not present
    if [[ ! -f "${project_dir}/Dockerfile" ]]; then
        echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} No Dockerfile found. Generating one for type=${DP_PROJECT_TYPE}..."
        _deploy_docker_generate_dockerfile "$project_dir"
    else
        echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Using existing Dockerfile."
    fi

    # Generate docker-compose.yml if not present
    if [[ ! -f "${project_dir}/docker-compose.yml" && ! -f "${project_dir}/docker-compose.yaml" ]]; then
        echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Generating docker-compose.yml..."
        _deploy_docker_generate_compose "$project_dir" "$port" "$container_name"
    else
        echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Using existing docker-compose.yml."
    fi

    # Stop any previous container with the same name
    docker rm -f "$container_name" >/dev/null 2>&1 || true

    # Build and run via docker-compose (prefer v2 plugin, fall back to v1)
    local compose_cmd="docker compose"
    if ! docker compose version >/dev/null 2>&1; then
        if command -v docker-compose >/dev/null 2>&1; then
            compose_cmd="docker-compose"
        else
            # Fall back to raw docker build + run
            echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} No docker-compose. Using raw docker build/run."
            _deploy_docker_raw "$project_dir" "$port" "$container_name"
            return $?
        fi
    fi

    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Building Docker image..."
    local build_output
    build_output=$(cd "$project_dir" && $compose_cmd build 2>&1); local build_rc=$?
    if [[ $build_rc -ne 0 ]]; then
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} Docker build failed (exit=${build_rc})"
        echo "$build_output" | tail -10
        return 1
    fi

    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Starting Docker container..."
    local run_output
    run_output=$(cd "$project_dir" && $compose_cmd up -d 2>&1); local run_rc=$?
    if [[ $run_rc -ne 0 ]]; then
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} Docker run failed (exit=${run_rc})"
        echo "$run_output" | tail -10
        return 1
    fi

    sleep 3
    DP_DEPLOY_URL="http://localhost:${port}"
    echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} Docker: ${DP_BOLD}${DP_DEPLOY_URL}${DP_RESET} (container=${container_name})"
    return 0
}

# Internal: raw docker build + run when compose is unavailable
_deploy_docker_raw() {
    local project_dir="$1" port="$2" container_name="$3"
    local image_name="soloptilink-app:${DP_DEPLOY_ID:-latest}"

    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} docker build..."
    local build_output
    build_output=$(cd "$project_dir" && docker build -t "$image_name" . 2>&1); local rc=$?
    if [[ $rc -ne 0 ]]; then
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} docker build failed"; echo "$build_output" | tail -10; return 1
    fi

    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} docker run..."
    docker run -d --name "$container_name" -p "${port}:${port}" "$image_name" >/dev/null 2>&1; rc=$?
    if [[ $rc -ne 0 ]]; then
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} docker run failed"; return 1
    fi

    sleep 3
    DP_DEPLOY_URL="http://localhost:${port}"
    echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} Docker (raw): ${DP_BOLD}${DP_DEPLOY_URL}${DP_RESET}"
    return 0
}

# Generate Dockerfile based on project type
_deploy_docker_generate_dockerfile() {
    local project_dir="$1"
    local port="${DP_LOCAL_PORT:-3000}"
    local dockerfile="${project_dir}/Dockerfile"

    case "$DP_PROJECT_TYPE" in
        nextjs)
            cat > "$dockerfile" <<'DOCKERFILE_NEXTJS'
# Auto-generated by SoloptiLink Chain v11.0
FROM node:20-alpine AS deps
WORKDIR /app
COPY package.json package-lock.json* yarn.lock* pnpm-lock.yaml* ./
RUN if [ -f pnpm-lock.yaml ]; then corepack enable && pnpm install --frozen-lockfile; \
    elif [ -f yarn.lock ]; then yarn install --frozen-lockfile; \
    else npm ci; fi

FROM node:20-alpine AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npm run build

FROM node:20-alpine AS runner
WORKDIR /app
ENV NODE_ENV=production
COPY --from=builder /app/public ./public
COPY --from=builder /app/.next/standalone ./
COPY --from=builder /app/.next/static ./.next/static
EXPOSE 3000
CMD ["node", "server.js"]
DOCKERFILE_NEXTJS
            ;;
        react|vue|nuxt)
            cat > "$dockerfile" <<DOCKERFILE_SPA
# Auto-generated by SoloptiLink Chain v11.0
FROM node:20-alpine AS build
WORKDIR /app
COPY package.json package-lock.json* yarn.lock* pnpm-lock.yaml* ./
RUN if [ -f pnpm-lock.yaml ]; then corepack enable && pnpm install --frozen-lockfile; \\
    elif [ -f yarn.lock ]; then yarn install --frozen-lockfile; \\
    else npm ci; fi
COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=build /app/dist /usr/share/nginx/html
COPY --from=build /app/build /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
DOCKERFILE_SPA
            ;;
        flask)
            cat > "$dockerfile" <<DOCKERFILE_FLASK
# Auto-generated by SoloptiLink Chain v11.0
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt ./
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE ${port}
CMD ["python", "-m", "flask", "run", "--host=0.0.0.0", "--port=${port}"]
DOCKERFILE_FLASK
            ;;
        django)
            cat > "$dockerfile" <<DOCKERFILE_DJANGO
# Auto-generated by SoloptiLink Chain v11.0
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt ./
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE ${port}
CMD ["python", "manage.py", "runserver", "0.0.0.0:${port}"]
DOCKERFILE_DJANGO
            ;;
        fastapi)
            cat > "$dockerfile" <<DOCKERFILE_FASTAPI
# Auto-generated by SoloptiLink Chain v11.0
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt ./
RUN pip install --no-cache-dir -r requirements.txt
COPY . .
EXPOSE ${port}
CMD ["uvicorn", "main:app", "--host", "0.0.0.0", "--port", "${port}"]
DOCKERFILE_FASTAPI
            ;;
        python)
            cat > "$dockerfile" <<DOCKERFILE_PY
# Auto-generated by SoloptiLink Chain v11.0
FROM python:3.12-slim
WORKDIR /app
COPY requirements.txt* ./
RUN [ -f requirements.txt ] && pip install --no-cache-dir -r requirements.txt || true
COPY . .
EXPOSE ${port}
CMD ["python3", "main.py"]
DOCKERFILE_PY
            ;;
        nodejs)
            cat > "$dockerfile" <<DOCKERFILE_NODE
# Auto-generated by SoloptiLink Chain v11.0
FROM node:20-alpine
WORKDIR /app
COPY package.json package-lock.json* yarn.lock* ./
RUN npm ci --production
COPY . .
EXPOSE ${port}
CMD ["npm", "start"]
DOCKERFILE_NODE
            ;;
        static|*)
            cat > "$dockerfile" <<DOCKERFILE_STATIC
# Auto-generated by SoloptiLink Chain v11.0
FROM nginx:alpine
COPY . /usr/share/nginx/html
EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
DOCKERFILE_STATIC
            ;;
    esac

    # Generate .dockerignore if missing
    if [[ ! -f "${project_dir}/.dockerignore" ]]; then
        cat > "${project_dir}/.dockerignore" <<'DOCKERIGNORE'
node_modules
.git
.next
dist
build
*.log
.env
.env.local
.env.*.local
__pycache__
*.pyc
.venv
venv
DOCKERIGNORE
    fi

    echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} Dockerfile generated for type=${DP_PROJECT_TYPE}"
}

# Generate docker-compose.yml
_deploy_docker_generate_compose() {
    local project_dir="$1" port="$2" container_name="$3"
    local compose_file="${project_dir}/docker-compose.yml"

    # Determine host:container port mapping
    local container_port="$port"
    if [[ "$DP_PROJECT_TYPE" == "react" || "$DP_PROJECT_TYPE" == "vue" || \
          "$DP_PROJECT_TYPE" == "nuxt" || "$DP_PROJECT_TYPE" == "static" ]]; then
        container_port="80"
    fi

    cat > "$compose_file" <<COMPOSEFILE
# Auto-generated by SoloptiLink Chain v11.0
version: "3.9"
services:
  app:
    build: .
    container_name: ${container_name}
    ports:
      - "${port}:${container_port}"
    restart: unless-stopped
    environment:
      - NODE_ENV=production
COMPOSEFILE

    echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} docker-compose.yml generated."
}

###############################################################################
# 10. deploy_rollback(project_dir) -- Rollback to previous deployment
###############################################################################
deploy_rollback() {
    local project_dir="${1:-$DP_PROJECT_DIR}"
    local rollback_meta="${DP_ROLLBACK_DIR}/$(echo "$project_dir" | sed 's|/|_|g').json"

    if [[ ! -f "$rollback_meta" ]]; then
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} No rollback snapshot found for ${project_dir}"
        echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} Rollback is only available after at least one successful deploy."
        return 1
    fi

    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} ${DP_BOLD}Starting rollback${DP_RESET} for ${project_dir}"

    # Read rollback metadata
    local prev_method prev_url prev_commit prev_timestamp prev_container
    prev_method=$(grep -o '"method":"[^"]*"' "$rollback_meta" 2>/dev/null | head -1 | cut -d'"' -f4)
    prev_url=$(grep -o '"url":"[^"]*"' "$rollback_meta" 2>/dev/null | head -1 | cut -d'"' -f4)
    prev_commit=$(grep -o '"git_commit":"[^"]*"' "$rollback_meta" 2>/dev/null | head -1 | cut -d'"' -f4)
    prev_timestamp=$(grep -o '"timestamp":"[^"]*"' "$rollback_meta" 2>/dev/null | head -1 | cut -d'"' -f4)
    prev_container=$(grep -o '"docker_container":"[^"]*"' "$rollback_meta" 2>/dev/null | head -1 | cut -d'"' -f4)

    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Previous deploy: method=${prev_method} commit=${prev_commit:-N/A} time=${prev_timestamp}"

    local rc=0
    case "$prev_method" in
        vercel)
            echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Reverting Vercel deployment..."
            if command -v vercel >/dev/null 2>&1 && [[ -n "$prev_url" ]]; then
                (cd "$project_dir" && vercel rollback 2>&1) || {
                    echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} vercel rollback not available. Redeploying from previous commit."
                    _deploy_rollback_git "$project_dir" "$prev_commit"
                    rc=$?
                }
            else
                _deploy_rollback_git "$project_dir" "$prev_commit"; rc=$?
            fi ;;
        railway)
            echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Reverting Railway deployment..."
            _deploy_rollback_git "$project_dir" "$prev_commit"
            if [[ $? -eq 0 ]]; then
                (cd "$project_dir" && railway up --detach 2>&1); rc=$?
            else
                rc=1
            fi ;;
        netlify)
            echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Reverting Netlify deployment..."
            _deploy_rollback_git "$project_dir" "$prev_commit"
            if [[ $? -eq 0 ]]; then
                (cd "$project_dir" && netlify deploy --prod 2>&1); rc=$?
            else
                rc=1
            fi ;;
        docker)
            echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Reverting Docker deployment..."
            if [[ -n "$prev_container" ]]; then
                # Stop current container
                docker stop "$prev_container" >/dev/null 2>&1 || true
                docker rm "$prev_container" >/dev/null 2>&1 || true
            fi
            # Revert code and rebuild
            _deploy_rollback_git "$project_dir" "$prev_commit"
            if [[ $? -eq 0 ]]; then
                _deploy_docker "$project_dir"; rc=$?
            else
                rc=1
            fi ;;
        gh-pages)
            echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Reverting GitHub Pages deployment..."
            _deploy_rollback_git "$project_dir" "$prev_commit"
            if [[ $? -eq 0 ]]; then
                _deploy_gh_pages "$project_dir"; rc=$?
            else
                rc=1
            fi ;;
        local)
            echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Reverting local deployment..."
            # Kill current local server
            [[ -n "$DP_LOCAL_PID" ]] && kill "$DP_LOCAL_PID" 2>/dev/null || true
            _deploy_rollback_git "$project_dir" "$prev_commit"
            if [[ $? -eq 0 ]]; then
                _deploy_local_serve "$project_dir"; rc=$?
            else
                rc=1
            fi ;;
        *)
            echo -e "${DP_RED}[DEPLOY]${DP_RESET} Unknown deploy method '${prev_method}' for rollback."
            rc=1 ;;
    esac

    if [[ $rc -eq 0 ]]; then
        echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} Rollback succeeded!"
        _deploy_record_history "$project_dir" "rollback"
    else
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} Rollback failed."
    fi
    return "$rc"
}

# Internal: git-based rollback to a specific commit
_deploy_rollback_git() {
    local project_dir="$1" target_commit="$2"

    if [[ -z "$target_commit" ]]; then
        echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} No previous git commit recorded. Attempting git revert of HEAD."
        (cd "$project_dir" && git revert --no-edit HEAD 2>&1); return $?
    fi

    if ! (cd "$project_dir" && git cat-file -t "$target_commit" >/dev/null 2>&1); then
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} Commit ${target_commit} not found in history."; return 1
    fi

    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Checking out commit ${target_commit}..."
    (cd "$project_dir" && git checkout "$target_commit" -- . 2>&1); local rc=$?
    if [[ $rc -eq 0 ]]; then
        echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} Code reverted to ${target_commit}"
    else
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} git checkout failed"
    fi
    return "$rc"
}

# Internal: save rollback metadata before a new deploy
_deploy_save_rollback() {
    local project_dir="$1"
    local rollback_meta="${DP_ROLLBACK_DIR}/$(echo "$project_dir" | sed 's|/|_|g').json"

    local current_commit=""
    if [[ -d "${project_dir}/.git" ]] || git -C "$project_dir" rev-parse --git-dir >/dev/null 2>&1; then
        current_commit=$(git -C "$project_dir" rev-parse HEAD 2>/dev/null || echo "")
    fi

    local current_container=""
    if [[ "$DP_DEPLOY_METHOD" == "docker" && -n "$DP_DEPLOY_ID" ]]; then
        current_container="soloptilink-${DP_DEPLOY_ID}"
    fi

    cat > "$rollback_meta" <<ROLLBACK_JSON
{
  "project_dir": "${project_dir}",
  "method": "${DP_DEPLOY_METHOD}",
  "url": "${DP_DEPLOY_URL}",
  "git_commit": "${current_commit}",
  "docker_container": "${current_container}",
  "timestamp": "$(date '+%Y-%m-%d %H:%M:%S')",
  "deploy_id": "${DP_DEPLOY_ID}"
}
ROLLBACK_JSON

    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Rollback snapshot saved."
}

###############################################################################
# 11. _deploy_check_secrets(project_dir) -- Secret management
#     Scans project files for exposed secrets/credentials before deploy.
#     Returns 0 (safe) or 1 (secrets found).
###############################################################################
_deploy_check_secrets() {
    local project_dir="${1:?project_dir required}"
    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Scanning for exposed secrets..."

    local secrets_found=0
    local scan_count=0
    local secret_files=""

    # Files to scan (skip node_modules, .git, venv, __pycache__, dist, build)
    local scan_dirs=("$project_dir")
    local exclude_pattern='(node_modules|\.git|venv|\.venv|__pycache__|dist|build|\.next|\.nuxt)'

    # Check for .env files that are NOT in .gitignore
    local env_files
    env_files=$(find "$project_dir" -maxdepth 3 -name ".env" -o -name ".env.local" -o -name ".env.production" \
        -o -name ".env.development" 2>/dev/null | grep -vE "$exclude_pattern" || true)

    if [[ -n "$env_files" ]]; then
        # Check if .env is in .gitignore
        local gitignore_file="${project_dir}/.gitignore"
        while IFS= read -r env_file; do
            local rel_path="${env_file#$project_dir/}"
            local is_ignored=false

            if [[ -f "$gitignore_file" ]]; then
                # Check if the file pattern is in .gitignore
                if grep -qE '^\s*\.env' "$gitignore_file" 2>/dev/null; then
                    is_ignored=true
                fi
                # Also check via git if available
                if git -C "$project_dir" check-ignore -q "$env_file" 2>/dev/null; then
                    is_ignored=true
                fi
            fi

            if [[ "$is_ignored" == "false" ]]; then
                echo -e "${DP_RED}[DEPLOY]${DP_RESET} WARNING: ${rel_path} is NOT in .gitignore!"
                secrets_found=$((secrets_found + 1))
                secret_files="${secret_files}\n  - ${rel_path} (not gitignored)"
            fi
        done <<< "$env_files"
    fi

    # Scan source files for hardcoded secrets
    local source_files
    source_files=$(find "$project_dir" -maxdepth 5 -type f \
        \( -name "*.js" -o -name "*.ts" -o -name "*.jsx" -o -name "*.tsx" \
        -o -name "*.py" -o -name "*.rb" -o -name "*.go" -o -name "*.java" \
        -o -name "*.php" -o -name "*.yaml" -o -name "*.yml" -o -name "*.toml" \
        -o -name "*.json" -o -name "*.sh" -o -name "*.env*" -o -name "*.cfg" \
        -o -name "*.ini" -o -name "*.conf" \) \
        2>/dev/null | grep -vE "$exclude_pattern" || true)

    if [[ -n "$source_files" ]]; then
        while IFS= read -r src_file; do
            [[ -z "$src_file" || ! -f "$src_file" ]] && continue
            scan_count=$((scan_count + 1))

            # Look for secret patterns with actual values assigned
            local matches
            matches=$(grep -nE "$DP_SECRET_PATTERNS" "$src_file" 2>/dev/null \
                | grep -vE '(#.*=|//.*=|process\.env\.|os\.environ|getenv|ENV\[)' \
                | grep -vE '^\s*(#|//|/\*|\*)' \
                | head -5 || true)

            if [[ -n "$matches" ]]; then
                local rel_path="${src_file#$project_dir/}"
                echo -e "${DP_RED}[DEPLOY]${DP_RESET} Potential secret in: ${rel_path}"
                while IFS= read -r match_line; do
                    # Redact the actual value for safety
                    local line_num line_content
                    line_num=$(echo "$match_line" | cut -d: -f1)
                    line_content=$(echo "$match_line" | cut -d: -f2- | sed -E 's/(=\s*).+/\1***REDACTED***/g')
                    echo -e "  ${DP_YELLOW}Line ${line_num}:${DP_RESET} ${line_content}"
                done <<< "$matches"
                secrets_found=$((secrets_found + 1))
                secret_files="${secret_files}\n  - ${rel_path}"
            fi
        done <<< "$source_files"
    fi

    # Check for private keys
    local key_files
    key_files=$(find "$project_dir" -maxdepth 3 -type f \
        \( -name "*.pem" -o -name "*.key" -o -name "*.p12" -o -name "*.pfx" \
        -o -name "id_rsa" -o -name "id_ed25519" -o -name "*.keystore" \) \
        2>/dev/null | grep -vE "$exclude_pattern" || true)

    if [[ -n "$key_files" ]]; then
        while IFS= read -r key_file; do
            [[ -z "$key_file" ]] && continue
            local rel_path="${key_file#$project_dir/}"
            echo -e "${DP_RED}[DEPLOY]${DP_RESET} Private key file: ${rel_path}"
            secrets_found=$((secrets_found + 1))
            secret_files="${secret_files}\n  - ${rel_path} (private key)"
        done <<< "$key_files"
    fi

    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Scanned ${scan_count} source files."

    if [[ $secrets_found -gt 0 ]]; then
        echo ""
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} ${DP_BOLD}Found ${secrets_found} potential secret exposure(s):${DP_RESET}"
        echo -e "$secret_files"
        echo ""
        echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} Recommendations:"
        echo -e "  1. Move secrets to environment variables (.env) and add .env to .gitignore"
        echo -e "  2. Use platform secret management (Vercel/Railway/Netlify env vars)"
        echo -e "  3. Remove private key files from the project directory"
        echo ""

        # Non-blocking warning: set DP_DEPLOY_FORCE_SECRETS=1 to override
        if [[ "${DP_DEPLOY_FORCE_SECRETS:-0}" == "1" ]]; then
            echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} DP_DEPLOY_FORCE_SECRETS=1 set. Proceeding despite warnings."
            return 0
        fi
        return 1
    else
        echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} No exposed secrets detected. Safe to deploy."
        return 0
    fi
}

###############################################################################
# 12. _deploy_generate_preview_url() -- Preview URL generation
#     Creates a unique preview URL for non-production deploys.
###############################################################################
_deploy_generate_preview_url() {
    DP_PREVIEW_URL=""

    case "$DP_DEPLOY_METHOD" in
        vercel)
            # Vercel preview deploys already have unique URLs
            if [[ -n "$DP_DEPLOY_URL" && "$DP_DEPLOY_URL" != *".vercel.app" ]]; then
                DP_PREVIEW_URL="$DP_DEPLOY_URL"
            else
                DP_PREVIEW_URL="${DP_DEPLOY_URL}"
            fi ;;
        netlify)
            # Netlify draft deploys have unique URLs
            DP_PREVIEW_URL="${DP_DEPLOY_URL}" ;;
        railway)
            DP_PREVIEW_URL="${DP_DEPLOY_URL}" ;;
        docker|local)
            # For local/docker, generate a descriptive preview identifier
            local project_name
            project_name=$(basename "${DP_PROJECT_DIR}" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9-]/-/g')
            local short_hash
            short_hash=$(echo "${DP_DEPLOY_ID}" | md5sum 2>/dev/null | cut -c1-8 || echo "$(date +%s)" | cut -c6-10)
            DP_PREVIEW_URL="http://localhost:${DP_LOCAL_PORT:-3000}  [preview: ${project_name}-${short_hash}]"
            ;;
        gh-pages)
            DP_PREVIEW_URL="${DP_DEPLOY_URL}" ;;
    esac

    if [[ -n "$DP_PREVIEW_URL" ]]; then
        echo -e "${DP_BLUE}[DEPLOY]${DP_RESET} Preview URL: ${DP_BOLD}${DP_PREVIEW_URL}${DP_RESET}"
    fi
}

###############################################################################
# 13. _deploy_smoke_test(url, project_dir) -- Post-deploy smoke test
#     After health check, verify key routes respond correctly.
###############################################################################
_deploy_smoke_test() {
    local url="${1:?url required}" project_dir="${2:-$DP_PROJECT_DIR}"
    local passed=0 failed=0 total=0

    command -v curl >/dev/null 2>&1 || {
        echo -e "${DP_YELLOW}[DEPLOY]${DP_RESET} curl unavailable. Skipping smoke test."
        return 0
    }

    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Smoke test: checking key routes..."

    # Build route list from project analysis
    local -a routes=("/")

    # Detect routes from common patterns
    case "$DP_PROJECT_TYPE" in
        nextjs)
            # Scan pages/ or app/ directory for routes
            if [[ -d "${project_dir}/pages" || -d "${project_dir}/src/pages" ]]; then
                local pages_dir="${project_dir}/pages"
                [[ -d "${project_dir}/src/pages" ]] && pages_dir="${project_dir}/src/pages"
                local page_files
                page_files=$(find "$pages_dir" -name "*.tsx" -o -name "*.ts" -o -name "*.jsx" -o -name "*.js" 2>/dev/null \
                    | grep -v '_app\|_document\|_error\|api/' | head -10 || true)
                while IFS= read -r pf; do
                    [[ -z "$pf" ]] && continue
                    local route="${pf#$pages_dir}"
                    route="${route%.*}"               # remove extension
                    route="${route%/index}"            # remove /index
                    [[ -n "$route" && "$route" != "/" ]] && routes+=("$route")
                done <<< "$page_files"
            fi
            # Check for API routes
            if [[ -d "${project_dir}/pages/api" || -d "${project_dir}/src/pages/api" || -d "${project_dir}/app/api" ]]; then
                routes+=("/api/health" "/api")
            fi
            ;;
        flask|django|fastapi)
            # Common API routes
            routes+=("/api" "/api/v1" "/health" "/api/health" "/docs")
            ;;
        react|vue|nuxt)
            # SPA: only root route is meaningful on server side
            routes+=("/index.html")
            ;;
        static)
            routes+=("/index.html")
            ;;
    esac

    # Also check if there is a custom routes file / sitemap
    if [[ -f "${project_dir}/sitemap.xml" ]]; then
        local sitemap_routes
        sitemap_routes=$(grep -oE '<loc>[^<]+</loc>' "${project_dir}/sitemap.xml" 2>/dev/null \
            | sed 's/<loc>//g;s|</loc>||g' | head -5 || true)
        while IFS= read -r sr; do
            [[ -n "$sr" ]] && routes+=("$sr")
        done <<< "$sitemap_routes"
    fi

    # Deduplicate routes
    local -a unique_routes=()
    local -A seen_routes
    local r
    for r in "${routes[@]}"; do
        if [[ -z "${seen_routes[$r]+_}" ]]; then
            unique_routes+=("$r")
            seen_routes[$r]=1
        fi
    done

    # Run smoke tests
    for route in "${unique_routes[@]}"; do
        total=$((total + 1))
        local test_url
        # Handle absolute vs relative routes
        if [[ "$route" == http* ]]; then
            test_url="$route"
        else
            test_url="${url%/}${route}"
        fi

        local code body_size
        code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "$test_url" 2>/dev/null || echo "000")
        body_size=$(curl -s -w '%{size_download}' -o /dev/null --max-time 10 "$test_url" 2>/dev/null || echo "0")

        if [[ "$code" =~ ^[23][0-9][0-9]$ ]]; then
            echo -e "  ${DP_GREEN}PASS${DP_RESET} ${route} -> HTTP ${code} (${body_size} bytes)"
            passed=$((passed + 1))
        else
            echo -e "  ${DP_RED}FAIL${DP_RESET} ${route} -> HTTP ${code}"
            failed=$((failed + 1))
        fi
    done

    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Smoke test: ${DP_GREEN}${passed} passed${DP_RESET}, ${DP_RED}${failed} failed${DP_RESET} / ${total} total"

    # Smoke test is advisory: fail only if ALL routes failed
    if [[ $passed -eq 0 && $total -gt 0 ]]; then
        return 1
    fi
    return 0
}

###############################################################################
# 14. deploy_history() -- Show deploy history with timestamps and URLs
###############################################################################
deploy_history() {
    local project_dir="${1:-}"

    echo ""
    echo -e "${DP_CYAN}========================================${DP_RESET}"
    echo -e "${DP_BOLD} Deploy History${DP_RESET}"
    echo -e "${DP_CYAN}========================================${DP_RESET}"

    if [[ ! -d "$DP_HISTORY_DIR" ]]; then
        echo -e "${DP_YELLOW}  No deployment history found.${DP_RESET}"
        echo -e "${DP_CYAN}========================================${DP_RESET}"
        echo ""
        return 0
    fi

    local history_files
    if [[ -n "$project_dir" ]]; then
        local safe_name
        safe_name=$(echo "$project_dir" | sed 's|/|_|g')
        history_files=$(find "$DP_HISTORY_DIR" -name "${safe_name}_*.log" -type f 2>/dev/null | sort -r | head -50)
    else
        history_files=$(find "$DP_HISTORY_DIR" -name "*.log" -type f 2>/dev/null | sort -r | head -50)
    fi

    if [[ -z "$history_files" ]]; then
        echo -e "${DP_YELLOW}  No deployment history found.${DP_RESET}"
        echo -e "${DP_CYAN}========================================${DP_RESET}"
        echo ""
        return 0
    fi

    local count=0
    printf "  ${DP_BOLD}%-4s %-20s %-10s %-10s %-8s %s${DP_RESET}\n" "#" "TIMESTAMP" "METHOD" "STATUS" "TYPE" "URL"
    echo -e "  ${DP_CYAN}----+--------------------+----------+----------+--------+----------------------------${DP_RESET}"

    while IFS= read -r hf; do
        [[ -z "$hf" || ! -f "$hf" ]] && continue
        count=$((count + 1))

        local h_timestamp h_method h_status h_type h_url h_deploy_id
        h_timestamp=$(grep -o '"timestamp":"[^"]*"' "$hf" 2>/dev/null | head -1 | cut -d'"' -f4)
        h_method=$(grep -o '"method":"[^"]*"' "$hf" 2>/dev/null | head -1 | cut -d'"' -f4)
        h_status=$(grep -o '"status":"[^"]*"' "$hf" 2>/dev/null | head -1 | cut -d'"' -f4)
        h_type=$(grep -o '"project_type":"[^"]*"' "$hf" 2>/dev/null | head -1 | cut -d'"' -f4)
        h_url=$(grep -o '"url":"[^"]*"' "$hf" 2>/dev/null | head -1 | cut -d'"' -f4)
        h_deploy_id=$(grep -o '"deploy_id":"[^"]*"' "$hf" 2>/dev/null | head -1 | cut -d'"' -f4)

        local status_color="$DP_GREEN"
        [[ "$h_status" == "failed" ]] && status_color="$DP_RED"
        [[ "$h_status" == "rollback" ]] && status_color="$DP_YELLOW"

        printf "  %-4s %-20s %-10s ${status_color}%-10s${DP_RESET} %-8s %s\n" \
            "$count" "${h_timestamp:-N/A}" "${h_method:-N/A}" "${h_status:-N/A}" \
            "${h_type:-N/A}" "${h_url:-N/A}"
    done <<< "$history_files"

    echo -e "  ${DP_CYAN}----+--------------------+----------+----------+--------+----------------------------${DP_RESET}"
    echo -e "  Total: ${count} deployment(s)"
    echo -e "${DP_CYAN}========================================${DP_RESET}"
    echo ""
    return 0
}

# Internal: record a deployment to the history log
_deploy_record_history() {
    local project_dir="$1" status="$2"
    mkdir -p "$DP_HISTORY_DIR" 2>/dev/null || true

    local safe_name
    safe_name=$(echo "$project_dir" | sed 's|/|_|g')
    local timestamp
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    local history_file="${DP_HISTORY_DIR}/${safe_name}_$(date '+%Y%m%d%H%M%S').log"

    local git_commit=""
    if [[ -d "${project_dir}/.git" ]] || git -C "$project_dir" rev-parse --git-dir >/dev/null 2>&1; then
        git_commit=$(git -C "$project_dir" rev-parse --short HEAD 2>/dev/null || echo "")
    fi

    cat > "$history_file" <<HISTORY_JSON
{
  "project_dir": "${project_dir}",
  "timestamp": "${timestamp}",
  "deploy_id": "${DP_DEPLOY_ID}",
  "method": "${DP_DEPLOY_METHOD}",
  "status": "${status}",
  "project_type": "${DP_PROJECT_TYPE}",
  "url": "${DP_DEPLOY_URL}",
  "preview_url": "${DP_PREVIEW_URL}",
  "git_commit": "${git_commit}",
  "targets_available": "${DP_AVAILABLE_TARGETS[*]}"
}
HISTORY_JSON

    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Deployment recorded to history (${status})."
}

###############################################################################
# 15. deploy_cleanup() -- Stop local servers, remove temp containers
###############################################################################
deploy_cleanup() {
    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Cleaning up..."
    if [[ -n "$DP_LOCAL_PID" ]]; then
        kill "$DP_LOCAL_PID" 2>/dev/null && \
            echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} Stopped local server (pid=${DP_LOCAL_PID})"
        DP_LOCAL_PID=""
    fi
    # Stop any soloptilink docker containers
    local containers
    containers=$(docker ps -q --filter "name=soloptilink-" 2>/dev/null || true)
    if [[ -n "$containers" ]]; then
        echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Stopping Docker containers..."
        docker stop $containers >/dev/null 2>&1 || true
        docker rm $containers >/dev/null 2>&1 || true
        echo -e "${DP_GREEN}[DEPLOY]${DP_RESET} Docker containers stopped."
    fi
}

###############################################################################
# 16. deploy_to(project_dir, target) -- Force deploy to a specific target
###############################################################################
deploy_to() {
    local project_dir="${1:?project_dir required}" target="${2:?target required}"
    echo -e "${DP_CYAN}[DEPLOY]${DP_RESET} Force deploying to ${DP_BOLD}${target}${DP_RESET}..."

    _deploy_detect_project_type "$project_dir"

    # v11.0: Secret check before deploy
    if ! _deploy_check_secrets "$project_dir"; then
        echo -e "${DP_RED}[DEPLOY]${DP_RESET} Aborting deploy due to exposed secrets."
        return 1
    fi

    DP_DEPLOY_ID="dp-$(date '+%Y%m%d%H%M%S')-$$"
    _deploy_save_rollback "$project_dir"

    local rc=1
    case "$target" in
        vercel)   _deploy_vercel "$project_dir";      rc=$?; DP_DEPLOY_METHOD="vercel" ;;
        netlify)  _deploy_netlify "$project_dir";      rc=$?; DP_DEPLOY_METHOD="netlify" ;;
        railway)  _deploy_railway "$project_dir";      rc=$?; DP_DEPLOY_METHOD="railway" ;;
        gh-pages) _deploy_gh_pages "$project_dir";     rc=$?; DP_DEPLOY_METHOD="gh-pages" ;;
        docker)   _deploy_docker "$project_dir";       rc=$?; DP_DEPLOY_METHOD="docker" ;;
        local)    _deploy_local_serve "$project_dir";  rc=$?; DP_DEPLOY_METHOD="local" ;;
        *)        echo -e "${DP_RED}[DEPLOY]${DP_RESET} Unknown target: ${target}"; return 1 ;;
    esac

    if [[ $rc -eq 0 && -n "$DP_DEPLOY_URL" ]]; then
        deploy_health_check "$DP_DEPLOY_URL" 5 && _deploy_smoke_test "$DP_DEPLOY_URL" "$project_dir"
        _deploy_generate_preview_url
        deploy_report "$DP_DEPLOY_URL" "$DP_PROJECT_TYPE"
        _deploy_record_history "$project_dir" "success"
    else
        _deploy_record_history "$project_dir" "failed"
    fi
    return "$rc"
}
