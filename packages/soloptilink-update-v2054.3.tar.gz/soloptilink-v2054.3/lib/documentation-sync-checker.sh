#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v218.0 - Documentation Sync Checker
# ドキュメントとコードの同期状態を検証
#
# 問題: コードは更新されるがドキュメントは放置される。
# README、API docs、コメント、.env.example が実態と乖離し、
# 新規開発者やAPI利用者に混乱を引き起こす。
#
# 解決: コードとドキュメントをクロスリファレンスし、
# 不整合を自動検出。更新計画を自動生成する。
#
# v218.0: Documentation Sync Checker
# ============================================================

[[ -n "${_DSC_LOADED:-}" ]] && return 0
_DSC_LOADED=1

DSC_VERSION="218.0"
DSC_INITIALIZED=false

# --- Detection Results ---
DSC_README_ISSUES=0
DSC_API_DOC_ISSUES=0
DSC_COMMENT_ISSUES=0
DSC_ENV_DOC_ISSUES=0
DSC_UNDOCUMENTED_COUNT=0
DSC_TOTAL_ISSUES=0
DSC_REPORT_DETAIL=""

# --- Finding Storage ---
declare -a DSC_FINDINGS=()
declare -a DSC_FINDING_TYPES=()
declare -a DSC_FINDING_FILES=()
declare -a DSC_FINDING_SEVERITY=()
declare -a DSC_FINDING_FIX=()

# --- Configuration ---
DSC_EXCLUDE_DIRS="node_modules|.next|dist|build|.git|coverage|__pycache__|.cache"
DSC_MAX_FILES=500

# ============================================================
# Init
# ============================================================
_dsc_init() {
    DSC_README_ISSUES=0
    DSC_API_DOC_ISSUES=0
    DSC_COMMENT_ISSUES=0
    DSC_ENV_DOC_ISSUES=0
    DSC_UNDOCUMENTED_COUNT=0
    DSC_TOTAL_ISSUES=0
    DSC_REPORT_DETAIL=""
    DSC_FINDINGS=()
    DSC_FINDING_TYPES=()
    DSC_FINDING_FILES=()
    DSC_FINDING_SEVERITY=()
    DSC_FINDING_FIX=()
    DSC_INITIALIZED=true
    return 0
}

# ============================================================
# Internal: Add finding
# ============================================================
_dsc_add_finding() {
    local type="$1"
    local file="$2"
    local severity="$3"
    local description="$4"
    local fix="$5"

    DSC_FINDINGS+=("$description")
    DSC_FINDING_TYPES+=("$type")
    DSC_FINDING_FILES+=("$file")
    DSC_FINDING_SEVERITY+=("$severity")
    DSC_FINDING_FIX+=("$fix")
}

# ============================================================
# Internal: Collect source files
# ============================================================
_dsc_collect_source_files() {
    local project_dir="$1"
    find "$project_dir" \
        -type f \
        -regextype posix-extended \
        -regex ".*\.(ts|tsx|js|jsx|py|go|rs)" \
        2>/dev/null \
    | grep -vE "($DSC_EXCLUDE_DIRS)" \
    | head -"$DSC_MAX_FILES"
}

# ============================================================
# 1. README Sync Check
# Verify README references match actual project state.
# ============================================================
_dsc_check_readme() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1
    [[ "$DSC_INITIALIZED" != "true" ]] && _dsc_init

    local count=0
    DSC_REPORT_DETAIL+="--- README Sync Check ---\n"

    # Find README files
    local -a readmes=()
    while IFS= read -r f; do
        readmes+=("$f")
    done < <(find "$project_dir" -maxdepth 2 -name "README*" -type f 2>/dev/null | head -10)

    if [[ ${#readmes[@]} -eq 0 ]]; then
        count=$((count + 1))
        _dsc_add_finding "README" "$project_dir" "medium" \
            "No README file found in project" \
            "Create a README.md with project description, setup instructions, and usage"
        DSC_REPORT_DETAIL+="  [MED] No README found.\n"
        DSC_README_ISSUES=$count
        DSC_REPORT_DETAIL+="\n"
        return 0
    fi

    for readme in "${readmes[@]}"; do
        local rel="${readme#$project_dir/}"

        # Check 1: Referenced scripts exist
        local scripts_mentioned
        scripts_mentioned=$(grep -oE '`[a-zA-Z0-9_./-]+\.(sh|ts|js|py)`|`npm run [a-zA-Z:_-]+`' "$readme" 2>/dev/null)
        if [[ -n "$scripts_mentioned" ]]; then
            while IFS= read -r script_ref; do
                local script_name
                script_name=$(echo "$script_ref" | tr -d '`')

                # Check npm run commands against package.json
                if [[ "$script_name" == npm\ run\ * ]]; then
                    local cmd="${script_name#npm run }"
                    local pkg_json="${project_dir}/package.json"
                    if [[ -f "$pkg_json" ]]; then
                        if ! grep -q "\"${cmd}\"" "$pkg_json" 2>/dev/null; then
                            count=$((count + 1))
                            _dsc_add_finding "README" "$rel" "high" \
                                "README references 'npm run ${cmd}' but script not in package.json" \
                                "Add '${cmd}' to package.json scripts or update README"
                            DSC_REPORT_DETAIL+="  [HIGH] ${rel} - Missing script: npm run ${cmd}\n"
                        fi
                    fi
                # Check file references
                elif [[ ! -f "${project_dir}/${script_name}" ]]; then
                    # Try common locations
                    local found=false
                    for prefix in "" "src/" "lib/" "scripts/"; do
                        if [[ -f "${project_dir}/${prefix}${script_name}" ]]; then
                            found=true
                            break
                        fi
                    done
                    if [[ "$found" != "true" ]]; then
                        count=$((count + 1))
                        _dsc_add_finding "README" "$rel" "medium" \
                            "README references '${script_name}' but file not found" \
                            "Update README to reflect current file structure or restore the file"
                        DSC_REPORT_DETAIL+="  [MED] ${rel} - Missing file: ${script_name}\n"
                    fi
                fi
            done <<< "$scripts_mentioned"
        fi

        # Check 2: Referenced directories exist
        local dirs_mentioned
        dirs_mentioned=$(grep -oE '\b(src|lib|app|pages|components|api|utils|hooks|services|prisma|tests|docs)/[a-zA-Z0-9_-]+/?' "$readme" 2>/dev/null | sort -u | head -20)
        if [[ -n "$dirs_mentioned" ]]; then
            while IFS= read -r dir_ref; do
                if [[ ! -d "${project_dir}/${dir_ref}" ]] && [[ ! -f "${project_dir}/${dir_ref}" ]]; then
                    count=$((count + 1))
                    _dsc_add_finding "README" "$rel" "low" \
                        "README references path '${dir_ref}' which doesn't exist" \
                        "Update README directory structure section"
                    DSC_REPORT_DETAIL+="  [LOW] ${rel} - Missing path: ${dir_ref}\n"
                fi
            done <<< "$dirs_mentioned"
        fi

        # Check 3: Package.json dependencies match README tech stack
        local pkg_json="${project_dir}/package.json"
        if [[ -f "$pkg_json" ]]; then
            # Check if README mentions outdated version numbers
            local version_refs
            version_refs=$(grep -oE '(v|version\s*)[0-9]+\.[0-9]+(\.[0-9]+)?' "$readme" 2>/dev/null | head -10)
            # Just count for awareness - version drift is common
        fi

        # Check 4: README mentions installation steps that may be outdated
        local has_install_section
        has_install_section=$(grep -ciE '(installation|getting started|setup|quick start)' "$readme" 2>/dev/null || echo "0")
        if [[ ${has_install_section:-0} -eq 0 ]]; then
            count=$((count + 1))
            _dsc_add_finding "README" "$rel" "low" \
                "README lacks installation/setup section" \
                "Add Getting Started section with prerequisites, installation, and configuration steps"
            DSC_REPORT_DETAIL+="  [LOW] ${rel} - No install section\n"
        fi

        # Check 5: README modification date vs code modification date
        if command -v stat &>/dev/null; then
            local readme_mtime
            readme_mtime=$(stat -f '%m' "$readme" 2>/dev/null || stat -c '%Y' "$readme" 2>/dev/null || echo "0")

            local latest_code_mtime=0
            while IFS= read -r src; do
                local mtime
                mtime=$(stat -f '%m' "$src" 2>/dev/null || stat -c '%Y' "$src" 2>/dev/null || echo "0")
                if [[ ${mtime:-0} -gt $latest_code_mtime ]]; then
                    latest_code_mtime=$mtime
                fi
            done < <(find "$project_dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" \) \
                -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null | head -50)

            if [[ $latest_code_mtime -gt 0 ]] && [[ $readme_mtime -gt 0 ]]; then
                local diff_days=$(( (latest_code_mtime - readme_mtime) / 86400 ))
                if [[ $diff_days -gt 30 ]]; then
                    count=$((count + 1))
                    _dsc_add_finding "README" "$rel" "medium" \
                        "README is ${diff_days} days older than latest code changes" \
                        "Review and update README to reflect recent code changes"
                    DSC_REPORT_DETAIL+="  [MED] ${rel} - ${diff_days} days stale\n"
                fi
            fi
        fi
    done

    DSC_README_ISSUES=$count
    if [[ $count -eq 0 ]]; then
        DSC_REPORT_DETAIL+="  README is in sync with project state.\n"
    else
        DSC_REPORT_DETAIL+="  Total: ${count} README sync issues found.\n"
    fi
    DSC_REPORT_DETAIL+="\n"
    return 0
}

# ============================================================
# 2. API Documentation Sync Check
# Verify API docs match actual routes and parameters.
# ============================================================
_dsc_check_api_docs() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1
    [[ "$DSC_INITIALIZED" != "true" ]] && _dsc_init

    local count=0
    DSC_REPORT_DETAIL+="--- API Documentation Sync Check ---\n"

    # Step 1: Extract actual API routes from code
    local -a actual_routes=()

    # Next.js App Router: app/api/*/route.ts
    while IFS= read -r route_file; do
        local route_path="${route_file#$project_dir/}"
        route_path=$(echo "$route_path" | sed 's|/route\.\(ts\|js\)$||' | sed 's|^app/|/|' | sed 's|\[|{|g' | sed 's|\]|}|g')
        actual_routes+=("$route_path")
    done < <(find "$project_dir" -path "*/api/*/route.ts" -o -path "*/api/*/route.js" 2>/dev/null | grep -v node_modules | head -100)

    # Express/Fastify routes: app.get/post/put/delete/patch
    while IFS= read -r route_line; do
        local route
        route=$(echo "$route_line" | grep -oE "['\"]\/[a-zA-Z0-9/:_{}*-]+['\"]" | head -1 | tr -d "'\"")
        if [[ -n "$route" ]]; then
            actual_routes+=("$route")
        fi
    done < <(grep -rn '\.\(get\|post\|put\|delete\|patch\)\s*(' "$project_dir" \
        --include="*.ts" --include="*.js" \
        --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=dist \
        2>/dev/null | grep -E "['\"]/" | head -100)

    # Step 2: Find API documentation files
    local -a api_docs=()
    while IFS= read -r doc_file; do
        api_docs+=("$doc_file")
    done < <(find "$project_dir" -type f \( \
        -name "openapi.*" -o -name "swagger.*" -o \
        -name "api-docs*" -o -name "API*.md" -o \
        -path "*/docs/api*" \
    \) 2>/dev/null | grep -vE "($DSC_EXCLUDE_DIRS)" | head -20)

    if [[ ${#api_docs[@]} -eq 0 ]] && [[ ${#actual_routes[@]} -gt 0 ]]; then
        count=$((count + 1))
        _dsc_add_finding "API_DOC" "$project_dir" "medium" \
            "${#actual_routes[@]} API routes found but no API documentation" \
            "Create OpenAPI/Swagger spec or API docs markdown documenting all ${#actual_routes[@]} routes"
        DSC_REPORT_DETAIL+="  [MED] ${#actual_routes[@]} routes, 0 API docs\n"
    fi

    # Step 3: Cross-reference routes with docs
    for doc_file in "${api_docs[@]}"; do
        local rel="${doc_file#$project_dir/}"
        local doc_content
        doc_content=$(cat "$doc_file" 2>/dev/null)

        for route in "${actual_routes[@]}"; do
            # Normalize route for matching
            local route_pattern
            route_pattern=$(echo "$route" | sed 's|{[^}]*}|[^/]+|g' | sed 's|/|\\\\\/|g')

            if ! echo "$doc_content" | grep -qE "$route" 2>/dev/null; then
                # Try a simpler match (last path segment)
                local last_segment
                last_segment=$(echo "$route" | rev | cut -d'/' -f1 | rev | tr -d '{}')
                if ! echo "$doc_content" | grep -qi "$last_segment" 2>/dev/null; then
                    count=$((count + 1))
                    _dsc_add_finding "API_DOC" "$rel" "high" \
                        "Route '${route}' not documented in ${rel}" \
                        "Add documentation for ${route} including request/response schema"
                    DSC_REPORT_DETAIL+="  [HIGH] ${rel} - Missing docs for: ${route}\n"
                fi
            fi
        done

        # Step 4: Check for documented routes that no longer exist
        local doc_routes
        doc_routes=$(grep -oE '(GET|POST|PUT|DELETE|PATCH)\s+\/[a-zA-Z0-9/:_{}-]+' "$doc_file" 2>/dev/null | awk '{print $2}' | head -50)
        if [[ -n "$doc_routes" ]]; then
            while IFS= read -r doc_route; do
                [[ -z "$doc_route" ]] && continue
                local found=false
                for actual in "${actual_routes[@]}"; do
                    if [[ "$actual" == "$doc_route" ]] || [[ "$actual" == *"$doc_route"* ]]; then
                        found=true
                        break
                    fi
                done
                if [[ "$found" != "true" ]]; then
                    count=$((count + 1))
                    _dsc_add_finding "API_DOC" "$rel" "medium" \
                        "Documented route '${doc_route}' may no longer exist in code" \
                        "Remove or update documentation for deprecated route ${doc_route}"
                    DSC_REPORT_DETAIL+="  [MED] ${rel} - Stale doc: ${doc_route}\n"
                fi
            done <<< "$doc_routes"
        fi
    done

    DSC_API_DOC_ISSUES=$count
    if [[ $count -eq 0 ]]; then
        DSC_REPORT_DETAIL+="  API documentation is in sync.\n"
    else
        DSC_REPORT_DETAIL+="  Total: ${count} API documentation issues found.\n"
    fi
    DSC_REPORT_DETAIL+="\n"
    return 0
}

# ============================================================
# 3. Outdated Comment Detection
# Find comments that reference removed functions/variables.
# ============================================================
_dsc_check_comments() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1
    [[ "$DSC_INITIALIZED" != "true" ]] && _dsc_init

    local count=0
    DSC_REPORT_DETAIL+="--- Outdated Comment Detection ---\n"

    # Step 1: Collect all defined function/variable names
    local -a all_symbols=()
    local symbols_file
    symbols_file=$(mktemp /tmp/dsc_symbols.XXXXXX 2>/dev/null || echo "/tmp/dsc_symbols_$$")

    # Extract function and const/let/var declarations
    grep -rhoE '(function\s+[a-zA-Z_$][a-zA-Z0-9_$]*|const\s+[a-zA-Z_$][a-zA-Z0-9_$]*|let\s+[a-zA-Z_$][a-zA-Z0-9_$]*|class\s+[a-zA-Z_$][a-zA-Z0-9_$]*)' \
        "$project_dir" \
        --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" \
        --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=dist \
        2>/dev/null \
    | awk '{print $NF}' | sort -u > "$symbols_file"

    while IFS= read -r file; do
        local rel="${file#$project_dir/}"

        # Pattern 1: TODO/FIXME with referenced functions
        local todo_comments
        todo_comments=$(grep -nE '//\s*(TODO|FIXME|HACK|XXX|DEPRECATED):?\s+' "$file" 2>/dev/null | head -10)
        if [[ -n "$todo_comments" ]]; then
            while IFS=: read -r line_no content; do
                [[ -z "$line_no" ]] && continue

                # Check if referenced symbols in TODO still exist
                local referenced_syms
                referenced_syms=$(echo "$content" | grep -oE '[a-zA-Z_$][a-zA-Z0-9_$]{3,}' | sort -u)
                while IFS= read -r sym; do
                    [[ -z "$sym" ]] && continue
                    # Skip common words
                    case "$sym" in
                        TODO|FIXME|HACK|XXX|DEPRECATED|this|that|should|could|would|need|when|from|with|after|before) continue ;;
                    esac
                    # Check if symbol looks like a function/variable name and exists
                    if echo "$sym" | grep -qE '^[a-z].*[A-Z]' 2>/dev/null; then
                        if ! grep -q "^${sym}$" "$symbols_file" 2>/dev/null; then
                            count=$((count + 1))
                            _dsc_add_finding "COMMENT" "$rel" "low" \
                                "Comment at line ${line_no} may reference non-existent symbol '${sym}'" \
                                "Update or remove the comment if '${sym}' no longer exists"
                            DSC_REPORT_DETAIL+="  [LOW] ${rel}:${line_no} - Possibly stale ref: ${sym}\n"
                        fi
                    fi
                done <<< "$referenced_syms"
            done <<< "$todo_comments"
        fi

        # Pattern 2: @deprecated comments for non-deprecated code
        local deprecated_comments
        deprecated_comments=$(grep -nE '@deprecated' "$file" 2>/dev/null)
        if [[ -n "$deprecated_comments" ]]; then
            while IFS=: read -r line_no content; do
                [[ -z "$line_no" ]] && continue
                # Check if the function after @deprecated is still actively used
                local next_fn
                next_fn=$(awk "NR > $line_no && /function\s+[a-zA-Z]/ { print \$0; exit }" "$file" 2>/dev/null)
                if [[ -n "$next_fn" ]]; then
                    local fn_name
                    fn_name=$(echo "$next_fn" | grep -oE 'function\s+[a-zA-Z_$][a-zA-Z0-9_$]*' | awk '{print $2}')
                    if [[ -n "$fn_name" ]]; then
                        local usage_count
                        usage_count=$(grep -rco "${fn_name}" "$project_dir" \
                            --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" \
                            --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=dist \
                            2>/dev/null | awk -F: '{s+=$2} END{print s+0}')
                        if [[ ${usage_count:-0} -gt 5 ]]; then
                            count=$((count + 1))
                            _dsc_add_finding "COMMENT" "$rel" "medium" \
                                "@deprecated '${fn_name}' still has ${usage_count} usages" \
                                "Either remove @deprecated tag or migrate callers to the replacement"
                            DSC_REPORT_DETAIL+="  [MED] ${rel}:${line_no} - @deprecated ${fn_name} used ${usage_count}x\n"
                        fi
                    fi
                fi
            done <<< "$deprecated_comments"
        fi

        # Pattern 3: JSDoc @param/@returns that don't match function signature
        local jsdoc_params
        jsdoc_params=$(awk '
            /\/\*\*/ { in_jsdoc=1; params="" }
            in_jsdoc && /@param\s+\{[^}]*\}\s+([a-zA-Z_$]+)/ {
                match($0, /@param\s+\{[^}]*\}\s+([a-zA-Z_$][a-zA-Z0-9_$]*)/, m)
                if (m[1]) params = params " " m[1]
            }
            in_jsdoc && /\*\// { in_jsdoc=0 }
            !in_jsdoc && /function\s+[a-zA-Z]|=>\s*\{|const\s+[a-zA-Z]+\s*=\s*\(/ && params {
                # Check if params from JSDoc appear in the function signature
                printf "%d:%s:%s\n", NR, $0, params
                params=""
            }
        ' "$file" 2>/dev/null | head -10)

        if [[ -n "$jsdoc_params" ]]; then
            while IFS=: read -r line_no sig doc_params; do
                [[ -z "$line_no" ]] && continue
                for param in $doc_params; do
                    if ! echo "$sig" | grep -q "$param" 2>/dev/null; then
                        count=$((count + 1))
                        _dsc_add_finding "COMMENT" "$rel" "medium" \
                            "JSDoc @param '${param}' not found in function signature (line ${line_no})" \
                            "Update JSDoc to match current function signature"
                        DSC_REPORT_DETAIL+="  [MED] ${rel}:${line_no} - JSDoc param mismatch: ${param}\n"
                    fi
                done
            done <<< "$jsdoc_params"
        fi

    done < <(_dsc_collect_source_files "$project_dir")

    rm -f "$symbols_file" 2>/dev/null

    DSC_COMMENT_ISSUES=$count
    if [[ $count -eq 0 ]]; then
        DSC_REPORT_DETAIL+="  No outdated comments detected.\n"
    else
        DSC_REPORT_DETAIL+="  Total: ${count} outdated comment issues found.\n"
    fi
    DSC_REPORT_DETAIL+="\n"
    return 0
}

# ============================================================
# 4. .env Documentation Check
# Verify .env.example matches actual env var usage.
# ============================================================
_dsc_check_env_docs() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1
    [[ "$DSC_INITIALIZED" != "true" ]] && _dsc_init

    local count=0
    DSC_REPORT_DETAIL+="--- Env Documentation Check ---\n"

    # Step 1: Find .env.example / .env.sample / .env.template
    local env_example=""
    for name in ".env.example" ".env.sample" ".env.template" ".env.local.example"; do
        if [[ -f "${project_dir}/${name}" ]]; then
            env_example="${project_dir}/${name}"
            break
        fi
    done

    # Step 2: Collect all env vars used in code
    local env_usage_file
    env_usage_file=$(mktemp /tmp/dsc_env.XXXXXX 2>/dev/null || echo "/tmp/dsc_env_$$")

    grep -rhoE '(process\.env\.[A-Z_][A-Z0-9_]*|import\.meta\.env\.[A-Z_][A-Z0-9_]*)' \
        "$project_dir" \
        --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" \
        --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=dist \
        2>/dev/null \
    | sed 's/process\.env\.//;s/import\.meta\.env\.//' \
    | sort -u > "$env_usage_file"

    local env_var_count
    env_var_count=$(wc -l < "$env_usage_file" 2>/dev/null | tr -d ' ')

    if [[ -z "$env_example" ]] && [[ ${env_var_count:-0} -gt 0 ]]; then
        count=$((count + 1))
        _dsc_add_finding "ENV" "$project_dir" "high" \
            "${env_var_count} env vars used in code but no .env.example file" \
            "Create .env.example with all required env vars and descriptions"
        DSC_REPORT_DETAIL+="  [HIGH] ${env_var_count} env vars, no .env.example\n"

        # List missing vars
        DSC_REPORT_DETAIL+="  Variables used in code:\n"
        while IFS= read -r var; do
            [[ -z "$var" ]] && continue
            DSC_REPORT_DETAIL+="    - ${var}\n"
        done < "$env_usage_file"

    elif [[ -n "$env_example" ]]; then
        local rel="${env_example#$project_dir/}"

        # Step 3: Extract vars from .env.example
        local -a documented_vars=()
        while IFS= read -r line; do
            [[ -z "$line" ]] && continue
            [[ "$line" == \#* ]] && continue
            local var_name
            var_name=$(echo "$line" | cut -d'=' -f1 | tr -d ' ')
            [[ -n "$var_name" ]] && documented_vars+=("$var_name")
        done < "$env_example"

        # Step 4: Find vars used in code but not in .env.example
        while IFS= read -r used_var; do
            [[ -z "$used_var" ]] && continue
            # Skip NODE_ENV and common builtins
            case "$used_var" in
                NODE_ENV|PATH|HOME|USER|PWD|PORT|HOST|HOSTNAME|TZ|LANG|SHELL) continue ;;
            esac

            local found=false
            for doc_var in "${documented_vars[@]}"; do
                if [[ "$doc_var" == "$used_var" ]]; then
                    found=true
                    break
                fi
            done

            if [[ "$found" != "true" ]]; then
                count=$((count + 1))
                _dsc_add_finding "ENV" "$rel" "high" \
                    "Env var '${used_var}' used in code but missing from ${rel}" \
                    "Add ${used_var}=<value> to ${rel} with a descriptive comment"
                DSC_REPORT_DETAIL+="  [HIGH] Missing from ${rel}: ${used_var}\n"
            fi
        done < "$env_usage_file"

        # Step 5: Find vars in .env.example but not used in code
        for doc_var in "${documented_vars[@]}"; do
            [[ -z "$doc_var" ]] && continue
            if ! grep -q "^${doc_var}$" "$env_usage_file" 2>/dev/null; then
                count=$((count + 1))
                _dsc_add_finding "ENV" "$rel" "low" \
                    "Env var '${doc_var}' in ${rel} but not found in code" \
                    "Remove unused ${doc_var} from ${rel} or verify it's used indirectly"
                DSC_REPORT_DETAIL+="  [LOW] Unused in code: ${doc_var}\n"
            fi
        done

        # Step 6: Check if .env.example has descriptions/comments
        local comment_count
        comment_count=$(grep -c '^#' "$env_example" 2>/dev/null || echo "0")
        local var_count=${#documented_vars[@]}
        if [[ $var_count -gt 5 ]] && [[ ${comment_count:-0} -lt 3 ]]; then
            count=$((count + 1))
            _dsc_add_finding "ENV" "$rel" "low" \
                "${rel} has ${var_count} vars but only ${comment_count} comments" \
                "Add descriptive comments for each env var explaining its purpose and valid values"
            DSC_REPORT_DETAIL+="  [LOW] Poor env documentation: ${var_count} vars, ${comment_count} comments\n"
        fi
    fi

    rm -f "$env_usage_file" 2>/dev/null

    DSC_ENV_DOC_ISSUES=$count
    if [[ $count -eq 0 ]]; then
        DSC_REPORT_DETAIL+="  Env documentation is in sync.\n"
    else
        DSC_REPORT_DETAIL+="  Total: ${count} env documentation issues found.\n"
    fi
    DSC_REPORT_DETAIL+="\n"
    return 0
}

# ============================================================
# 5. Find Undocumented Public Functions/APIs
# ============================================================
_dsc_find_undocumented() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1
    [[ "$DSC_INITIALIZED" != "true" ]] && _dsc_init

    local count=0
    DSC_REPORT_DETAIL+="--- Undocumented Public API Detection ---\n"

    while IFS= read -r file; do
        local rel="${file#$project_dir/}"

        # Pattern 1: Exported functions without JSDoc
        local undocumented_exports
        undocumented_exports=$(awk '
            BEGIN { prev_has_jsdoc=0 }
            /\/\*\*/ { in_jsdoc=1 }
            /\*\// { in_jsdoc=0; prev_has_jsdoc=1; next }
            /^[[:space:]]*\/\// { next }

            /^export\s+(async\s+)?function\s+[a-zA-Z]/ ||
            /^export\s+const\s+[a-zA-Z]+\s*=\s*(async\s*)?\(/ ||
            /^export\s+class\s+[a-zA-Z]/ ||
            /^export\s+default\s+(async\s+)?function/ {
                if (!prev_has_jsdoc) {
                    printf "%d:%s\n", NR, $0
                }
                prev_has_jsdoc=0
                next
            }

            { prev_has_jsdoc=0 }
        ' "$file" 2>/dev/null | head -10)

        if [[ -n "$undocumented_exports" ]]; then
            while IFS=: read -r line_no content; do
                [[ -z "$line_no" ]] && continue
                local fn_sig
                fn_sig=$(echo "$content" | sed 's/^[[:space:]]*//' | cut -c1-80)
                count=$((count + 1))
                _dsc_add_finding "UNDOC" "$rel" "low" \
                    "Exported symbol without JSDoc at line ${line_no}: ${fn_sig}" \
                    "Add JSDoc with @description, @param, and @returns"
                DSC_REPORT_DETAIL+="  [LOW] ${rel}:${line_no} - ${fn_sig}\n"
            done <<< "$undocumented_exports"
        fi

        # Pattern 2: API route handlers without description comments
        if [[ "$file" == *"/route."* || "$file" == *"/api/"* ]]; then
            local handler_funcs
            handler_funcs=$(grep -nE 'export\s+(async\s+)?function\s+(GET|POST|PUT|DELETE|PATCH)\s*\(' "$file" 2>/dev/null)
            if [[ -n "$handler_funcs" ]]; then
                while IFS=: read -r line_no content; do
                    [[ -z "$line_no" ]] && continue
                    local prev_line=$((line_no - 1))
                    local prev
                    prev=$(awk "NR==$prev_line" "$file" 2>/dev/null)
                    if ! echo "$prev" | grep -qE '(\*\/|\/\/)' 2>/dev/null; then
                        count=$((count + 1))
                        local method
                        method=$(echo "$content" | grep -oE '(GET|POST|PUT|DELETE|PATCH)')
                        _dsc_add_finding "UNDOC" "$rel" "medium" \
                            "API handler ${method} at line ${line_no} has no documentation" \
                            "Add JSDoc describing the endpoint, parameters, and response format"
                        DSC_REPORT_DETAIL+="  [MED] ${rel}:${line_no} - Undocumented ${method} handler\n"
                    fi
                done <<< "$handler_funcs"
            fi
        fi

    done < <(_dsc_collect_source_files "$project_dir")

    DSC_UNDOCUMENTED_COUNT=$count
    if [[ $count -eq 0 ]]; then
        DSC_REPORT_DETAIL+="  All public APIs are documented.\n"
    else
        DSC_REPORT_DETAIL+="  Total: ${count} undocumented public APIs found.\n"
    fi
    DSC_REPORT_DETAIL+="\n"
    return 0
}

# ============================================================
# 6. Generate Update Plan
# ============================================================
_dsc_generate_update_plan() {
    local project_dir="$1"
    local output_file="${2:-}"
    [[ ! -d "$project_dir" ]] && return 1

    if [[ "$DSC_INITIALIZED" != "true" ]]; then
        _dsc_init
    fi

    DSC_REPORT_DETAIL="============================================\n"
    DSC_REPORT_DETAIL+="  Documentation Sync Checker v${DSC_VERSION}\n"
    DSC_REPORT_DETAIL+="  Target: ${project_dir}\n"
    DSC_REPORT_DETAIL+="  Timestamp: $(date '+%Y-%m-%d %H:%M:%S')\n"
    DSC_REPORT_DETAIL+="============================================\n\n"

    _dsc_check_readme "$project_dir"
    _dsc_check_api_docs "$project_dir"
    _dsc_check_comments "$project_dir"
    _dsc_check_env_docs "$project_dir"
    _dsc_find_undocumented "$project_dir"

    DSC_TOTAL_ISSUES=$((DSC_README_ISSUES + DSC_API_DOC_ISSUES + DSC_COMMENT_ISSUES + DSC_ENV_DOC_ISSUES + DSC_UNDOCUMENTED_COUNT))

    # Summary
    DSC_REPORT_DETAIL+="============================================\n"
    DSC_REPORT_DETAIL+="  DOCUMENTATION UPDATE PLAN\n"
    DSC_REPORT_DETAIL+="============================================\n"
    DSC_REPORT_DETAIL+="  README Issues:       ${DSC_README_ISSUES}\n"
    DSC_REPORT_DETAIL+="  API Doc Issues:      ${DSC_API_DOC_ISSUES}\n"
    DSC_REPORT_DETAIL+="  Comment Issues:      ${DSC_COMMENT_ISSUES}\n"
    DSC_REPORT_DETAIL+="  Env Doc Issues:      ${DSC_ENV_DOC_ISSUES}\n"
    DSC_REPORT_DETAIL+="  Undocumented APIs:   ${DSC_UNDOCUMENTED_COUNT}\n"
    DSC_REPORT_DETAIL+="  ──────────────────────────────────────\n"
    DSC_REPORT_DETAIL+="  TOTAL ISSUES:        ${DSC_TOTAL_ISSUES}\n"
    DSC_REPORT_DETAIL+="  SCORE:               $(_dsc_score)/100\n"
    DSC_REPORT_DETAIL+="============================================\n\n"

    # Priority action items
    DSC_REPORT_DETAIL+="  ACTION ITEMS (by priority):\n\n"
    local action_num=1

    for i in "${!DSC_FINDINGS[@]}"; do
        if [[ "${DSC_FINDING_SEVERITY[$i]}" == "high" ]]; then
            DSC_REPORT_DETAIL+="  ${action_num}. [HIGH] ${DSC_FINDING_FILES[$i]}\n"
            DSC_REPORT_DETAIL+="     Issue: ${DSC_FINDINGS[$i]}\n"
            DSC_REPORT_DETAIL+="     Fix:   ${DSC_FINDING_FIX[$i]}\n\n"
            action_num=$((action_num + 1))
        fi
    done

    for i in "${!DSC_FINDINGS[@]}"; do
        if [[ "${DSC_FINDING_SEVERITY[$i]}" == "medium" ]] && [[ $action_num -le 20 ]]; then
            DSC_REPORT_DETAIL+="  ${action_num}. [MED] ${DSC_FINDING_FILES[$i]}\n"
            DSC_REPORT_DETAIL+="     Issue: ${DSC_FINDINGS[$i]}\n"
            DSC_REPORT_DETAIL+="     Fix:   ${DSC_FINDING_FIX[$i]}\n\n"
            action_num=$((action_num + 1))
        fi
    done

    if [[ -n "$output_file" ]]; then
        echo -e "$DSC_REPORT_DETAIL" > "$output_file"
        echo "[DSC] Update plan written to: ${output_file}" >&2
    fi

    echo -e "$DSC_REPORT_DETAIL"
    return 0
}

# ============================================================
# Generate prompt for Claude to fix documentation
# ============================================================
_dsc_generate_fix_prompt() {
    local prompt="Update the following documentation to match the current codebase:\n\n"
    local fix_count=0

    for i in "${!DSC_FINDINGS[@]}"; do
        [[ $fix_count -ge 15 ]] && break
        prompt+="## ${DSC_FINDING_TYPES[$i]} - ${DSC_FINDING_FILES[$i]}\n"
        prompt+="Issue: ${DSC_FINDINGS[$i]}\n"
        prompt+="Action: ${DSC_FINDING_FIX[$i]}\n\n"
        fix_count=$((fix_count + 1))
    done

    echo -e "$prompt"
}

# ============================================================
# Scoring
# ============================================================
_dsc_score() {
    local total=$DSC_TOTAL_ISSUES

    if [[ $total -eq 0 ]]; then
        echo "100"
    elif [[ $total -le 3 ]]; then
        echo "85"
    elif [[ $total -le 8 ]]; then
        echo "65"
    elif [[ $total -le 15 ]]; then
        echo "45"
    elif [[ $total -le 25 ]]; then
        echo "25"
    else
        echo "10"
    fi
}

# ============================================================
# Report (for module registry)
# ============================================================
_dsc_report() {
    echo -e "\n  ${BOLD:-}=== Documentation Sync Checker v${DSC_VERSION} ===${NC:-}"
    echo -e "  README Issues:     ${DSC_README_ISSUES}"
    echo -e "  API Doc Issues:    ${DSC_API_DOC_ISSUES}"
    echo -e "  Comment Issues:    ${DSC_COMMENT_ISSUES}"
    echo -e "  Env Doc Issues:    ${DSC_ENV_DOC_ISSUES}"
    echo -e "  Undocumented APIs: ${DSC_UNDOCUMENTED_COUNT}"
    echo -e "  Total Issues:      ${DSC_TOTAL_ISSUES}"
    echo -e "  Score:             $(_dsc_score)/100"
}

# ============================================================
# Module Registry self-registration
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "documentation-sync-checker" \
        --version "$DSC_VERSION" \
        --description "ドキュメント同期検証 - README/API docs/コメント/env整合性チェック" \
        --init "_dsc_init" \
        --report "_dsc_report" \
        --score "_dsc_score" \
        --enable-var "ENABLE_DSC" \
        --cli-flags "--doc-sync-check:--no-doc-sync-check"
fi

# v2003.1: source時のexit codeを確実に0にする
true
