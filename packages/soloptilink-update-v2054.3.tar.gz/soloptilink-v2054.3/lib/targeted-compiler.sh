#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v28.0 - Targeted Compiler
# =============================================================================
# Follow-up専用のプロンプトコンパイラー。既存プロジェクトのGenomeと変更計画を
# 基に、既存コードパターン・スキーマ・規約を注入した最適化プロンプトを生成する。
#
# 機能:
#   - 既存コードパターン注入（import/export/命名規則）
#   - DBスキーマ知識注入（Prisma/SQLAlchemyスキーマ全文）
#   - コーディング規約注入（indent/naming/CSS/framework）
#   - 影響ファイルの実際の内容注入
#   - 「変更禁止」制約生成
#   - Claude出力スコープ制限
#   - prompt-compiler.shのアンチパターン・出力形式再利用
#
# 依存: lib/prompt-compiler.sh (アンチパターン/出力形式), lib/incremental-analyzer.sh
# =============================================================================

[[ -n "${_TARGETED_COMPILER_LOADED:-}" ]] && return 0
_TARGETED_COMPILER_LOADED=1

# =============================================================================
# 設定
# =============================================================================
TRC_VERSION="28.0"
TRC_ENABLED="false"
TRC_SESSION_ID=""
TRC_COMPILED_PROMPT=""
TRC_PROMPT_CHARS=0
TRC_WORK_DIR="${HOME}/.soloptilink/targeted-compiler"

# トークン制限
TRC_MAX_CHARS=480000        # ~120K tokens
TRC_FILE_CONTENT_LIMIT=8000 # Per-file content limit in chars

# カラー
TRC_GREEN='\033[0;32m'
TRC_YELLOW='\033[0;33m'
TRC_RED='\033[0;31m'
TRC_CYAN='\033[0;36m'
TRC_BOLD='\033[1m'
TRC_DIM='\033[2m'
TRC_NC='\033[0m'

# =============================================================================
# 初期化
# =============================================================================
trc_init() {
    local session_id="${1:-}"
    TRC_SESSION_ID="$session_id"
    TRC_ENABLED="true"
    TRC_COMPILED_PROMPT=""
    TRC_PROMPT_CHARS=0
    mkdir -p "${TRC_WORK_DIR}" 2>/dev/null || true
    echo -e "  ${TRC_GREEN}OK${TRC_NC} Targeted Compiler v${TRC_VERSION}"
}

# =============================================================================
# ログ
# =============================================================================
_trc_log() {
    local level="$1" msg="$2"
    local color="${TRC_NC}"
    case "$level" in
        INFO)    color="${TRC_GREEN}" ;;
        WARN)    color="${TRC_YELLOW}" ;;
        ERROR)   color="${TRC_RED}" ;;
        DEBUG)   color="${TRC_DIM}" ;;
    esac
    echo -e "  ${color}[TRC/${level}]${TRC_NC} ${msg}" >&2
}

# =============================================================================
# 既存コードパターン注入
# =============================================================================
trc_inject_existing_patterns() {
    local prompt="${1:-}"
    local genome_json="${2:-}"

    [[ -z "$genome_json" ]] && { echo "$prompt"; return; }

    local patterns_section
    patterns_section=$(python3 -c "
import json

genome = json.loads('''${genome_json}''')
patterns = []

# Framework patterns
framework = genome.get('framework', 'unknown')
language = genome.get('language', 'unknown')
patterns.append(f'Framework: {framework}')
patterns.append(f'Language: {language}')

# Component patterns
components = genome.get('components', [])
if components:
    # Extract common import patterns
    import_sources = set()
    for c in components[:10]:
        for imp in c.get('imports', []):
            if not imp.startswith('.'):
                import_sources.add(imp)
    if import_sources:
        patterns.append('Common imports: ' + ', '.join(list(import_sources)[:10]))

    # Component file naming pattern
    comp_files = [c.get('file', '') for c in components[:5]]
    if comp_files:
        patterns.append('Component locations: ' + ', '.join(comp_files[:5]))

# Route patterns
routes = genome.get('routes', [])
if routes:
    route_files = list(set(r.get('file', '') for r in routes[:5]))
    patterns.append('API route locations: ' + ', '.join(route_files[:5]))

print('\\n'.join(patterns))
" 2>/dev/null || echo "")

    if [[ -n "$patterns_section" ]]; then
        prompt+="\n\n## EXISTING PROJECT PATTERNS (DO NOT DEVIATE)\n${patterns_section}\n"
    fi

    echo -e "$prompt"
}

# =============================================================================
# スキーマコンテキスト注入
# =============================================================================
trc_inject_schema_context() {
    local prompt="${1:-}"
    local genome_json="${2:-}"

    [[ -z "$genome_json" ]] && { echo "$prompt"; return; }

    local schema_section
    schema_section=$(python3 -c "
import json

genome = json.loads('''${genome_json}''')
schema = genome.get('schema', {})
schema_type = schema.get('type', 'none')
schema_raw = schema.get('raw', '')

if schema_type != 'none' and schema_raw:
    # Truncate if too long
    if len(schema_raw) > 5000:
        schema_raw = schema_raw[:5000] + '\\n... (truncated)'
    print(f'## DATABASE SCHEMA ({schema_type.upper()}) - DO NOT MODIFY UNLESS EXPLICITLY ASKED')
    print('\\x60\\x60\\x60' + schema_type)
    print(schema_raw)
    print('\\x60\\x60\\x60')
else:
    print('')
" 2>/dev/null || echo "")

    if [[ -n "$schema_section" ]]; then
        prompt+="\n${schema_section}\n"
    fi

    echo -e "$prompt"
}

# =============================================================================
# スタイルガイド注入
# =============================================================================
trc_inject_style_guide() {
    local prompt="${1:-}"
    local genome_json="${2:-}"

    [[ -z "$genome_json" ]] && { echo "$prompt"; return; }

    local style_section
    style_section=$(python3 -c "
import json

genome = json.loads('''${genome_json}''')
conventions = genome.get('conventions', {})

rules = []
indent = conventions.get('indent', 'unknown')
naming = conventions.get('naming', 'unknown')
css = conventions.get('css', 'none')
framework = conventions.get('framework', 'unknown')

if indent != 'unknown':
    rules.append(f'Indentation: {indent}')
if naming != 'unknown':
    rules.append(f'Naming convention: {naming}')
if css != 'none':
    rules.append(f'CSS framework: {css} (use ONLY this)')
if framework != 'unknown':
    rules.append(f'Framework: {framework}')

if rules:
    print('## CODING CONVENTIONS (MUST FOLLOW)')
    for r in rules:
        print(f'- {r}')
else:
    print('')
" 2>/dev/null || echo "")

    if [[ -n "$style_section" ]]; then
        prompt+="\n${style_section}\n"
    fi

    echo -e "$prompt"
}

# =============================================================================
# 影響ファイル内容注入
# =============================================================================
trc_inject_affected_file_contents() {
    local prompt="${1:-}"
    local affected_files_json="${2:-[]}"
    local project_dir="${3:-.}"

    local files_section=""
    files_section=$(python3 -c "
import json, os

files = json.loads('''${affected_files_json}''')
project_dir = '${project_dir}'
limit = ${TRC_FILE_CONTENT_LIMIT}
output = []

for f in files[:15]:  # Max 15 files
    full_path = os.path.join(project_dir, f)
    if os.path.isfile(full_path):
        try:
            with open(full_path, 'r', errors='ignore') as fh:
                content = fh.read(limit)
            if len(content) >= limit:
                content += '\\n// ... (truncated)'
            ext = f.split('.')[-1] if '.' in f else ''
            output.append(f'### File: {f}')
            output.append(f'\\x60\\x60\\x60{ext}')
            output.append(content)
            output.append('\\x60\\x60\\x60')
            output.append('')
        except:
            pass

print('\\n'.join(output))
" 2>/dev/null || echo "")

    if [[ -n "$files_section" ]]; then
        prompt+="\n## FILES TO MODIFY (Current Contents)\n${files_section}\n"
    fi

    echo -e "$prompt"
}

# =============================================================================
# 制約生成
# =============================================================================
trc_generate_constraints() {
    local genome_json="${1:-}"
    local change_plan="${2:-}"

    local constraints=""

    # From change plan
    if [[ -n "$change_plan" ]]; then
        constraints=$(python3 -c "
import json

plan = json.loads('''${change_plan}''')
items = plan.get('constraints', [])
for i, c in enumerate(items, 1):
    print(f'{i}. {c}')
" 2>/dev/null || echo "")
    fi

    # Add universal constraints
    constraints+="\n- 変更計画に含まれないファイルは変更しない"
    constraints+="\n- 既存のimportパス・命名規則を維持する"
    constraints+="\n- 新しいパッケージを勝手に追加しない（必要な場合は明示する）"

    echo -e "$constraints"
}

# =============================================================================
# ファイルスコープ構築
# =============================================================================
trc_build_file_scope() {
    local affected_files="${1:-[]}"

    python3 -c "
import json

files = json.loads('''${affected_files}''')
if files:
    print('## FILE SCOPE (Only modify these files)')
    for f in files:
        print(f'- {f}')
    print('')
    print('DO NOT create or modify any files outside this list unless explicitly needed for the task.')
else:
    print('')
" 2>/dev/null || echo ""
}

# =============================================================================
# メインコンパイル
# =============================================================================
trc_compile_followup_prompt() {
    local task_desc="${1:-}"
    local genome_json="${2:-}"
    local change_plan="${3:-}"
    local request_type="${4:-modification}"

    _trc_log "INFO" "Follow-upプロンプトコンパイル開始: type=${request_type}"

    local prompt=""

    # === Header ===
    prompt+="# CONTEXT: FOLLOW-UP INSTRUCTION (v28.0)\n"
    prompt+="あなたは既存プロジェクトを修正しています。ゼロからの再構築は行いません。\n"
    prompt+="既存のコード・構造・命名規則を最大限尊重し、最小限の変更で目的を達成してください。\n\n"

    # === Request Info ===
    prompt+="## Request Type: ${request_type}\n"
    prompt+="## Task: ${task_desc}\n\n"

    # === File Scope ===
    local affected_files="[]"
    if [[ -n "$change_plan" ]]; then
        affected_files=$(echo "$change_plan" | python3 -c "import sys,json; plan=json.loads(sys.stdin.read()); print(json.dumps(plan.get('affected_files',[])))" 2>/dev/null || echo "[]")
    fi
    local scope_section
    scope_section=$(trc_build_file_scope "$affected_files")
    [[ -n "$scope_section" ]] && prompt+="${scope_section}\n"

    # === Schema Context ===
    prompt=$(trc_inject_schema_context "$prompt" "$genome_json")

    # === Style Guide ===
    prompt=$(trc_inject_style_guide "$prompt" "$genome_json")

    # === Existing Patterns ===
    prompt=$(trc_inject_existing_patterns "$prompt" "$genome_json")

    # === Affected File Contents ===
    local project_dir
    if [[ -n "$genome_json" ]]; then
        project_dir=$(echo "$genome_json" | python3 -c "import sys,json; print(json.loads(sys.stdin.read()).get('project_dir','.'))" 2>/dev/null || echo ".")
    else
        project_dir="."
    fi
    prompt=$(trc_inject_affected_file_contents "$prompt" "$affected_files" "$project_dir")

    # === Constraints ===
    local constraints
    constraints=$(trc_generate_constraints "$genome_json" "$change_plan")
    prompt+="\n## CONSTRAINTS\n${constraints}\n"

    # === Anti-patterns (reuse from prompt-compiler if available) ===
    if [[ -n "${PC_ANTI_PATTERNS[*]:-}" ]]; then
        prompt+="\n## ANTI-PATTERNS (ABSOLUTELY FORBIDDEN)\n"
        for ap in "${PC_ANTI_PATTERNS[@]}"; do
            prompt+="- ${ap}\n"
        done
    else
        # Built-in anti-patterns
        prompt+="\n## ANTI-PATTERNS (ABSOLUTELY FORBIDDEN)\n"
        prompt+="- モックデータ禁止: ハードコードデータは使わない。全データはDB経由\n"
        prompt+="- 空イベントハンドラ禁止: onClick={() => {}} は禁止\n"
        prompt+="- TODO/FIXME禁止: 未実装部分を残さない\n"
        prompt+="- console.log禁止: デバッグログを残さない\n"
        prompt+="- any型禁止: TypeScript strict mode\n"
    fi

    # === Output Format ===
    prompt+="\n## OUTPUT FORMAT\n"
    prompt+="変更するファイルごとに以下の形式で出力してください:\n"
    prompt+="\n--- FILE: path/to/file.ts ---\n"
    prompt+="(ファイルの完全な内容)\n"
    prompt+="--- END FILE ---\n"
    prompt+="\n各ファイルは完全な内容を出力してください（差分ではなく全体）。\n"
    prompt+="変更しないファイルは出力に含めないでください。\n"

    TRC_COMPILED_PROMPT="$prompt"
    TRC_PROMPT_CHARS=$(echo -n "$prompt" | wc -c | tr -d ' ')

    # Check size limit
    if [[ "$TRC_PROMPT_CHARS" -gt "$TRC_MAX_CHARS" ]]; then
        _trc_log "WARN" "プロンプトサイズ超過: ${TRC_PROMPT_CHARS} chars (制限: ${TRC_MAX_CHARS})"
    fi

    _trc_log "INFO" "コンパイル完了: ${TRC_PROMPT_CHARS} chars"
    echo "$prompt"
}

# =============================================================================
# レポート
# =============================================================================
trc_report() {
    echo -e "\n  ${TRC_BOLD}${TRC_CYAN}[Targeted Compiler Report]${TRC_NC}"
    echo -e "  Version:      ${TRC_VERSION}"
    echo -e "  Prompt Size:  ${TRC_PROMPT_CHARS} chars"
    echo -e "  Max Allowed:  ${TRC_MAX_CHARS} chars"
}
