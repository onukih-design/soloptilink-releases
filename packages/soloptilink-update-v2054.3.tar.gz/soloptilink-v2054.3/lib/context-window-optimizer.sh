#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v207.0 - Context Window Optimizer
# Claude のコンテキストウィンドウを最大限活用するために、
# ファイル内容を圧縮・優先順位付け・トークン見積もりを行う。
#
# 問題: Claude Code にファイルを渡す際、コンテキストウィンドウには
# 上限がある。不要なコメントや空行で貴重なトークンが浪費される。
#
# 解決: ファイルを圧縮（コメント/空行除去、import折り畳み）、
# 関連度で優先順位付け、トークン見積もりでバジェット内に最適配置。
# ============================================================

[[ -n "${_CWO_LOADED:-}" ]] && return 0
_CWO_LOADED=1

CWO_VERSION="207.0"
CWO_INITIALIZED=false

# State
CWO_PROJECT_DIR=""
CWO_TOTAL_FILES=0
CWO_TOTAL_TOKENS_BEFORE=0
CWO_TOTAL_TOKENS_AFTER=0
CWO_COMPRESSION_RATIO=0
CWO_FILES_FITTED=0
CWO_BUDGET_USED=0
CWO_CACHE_DIR=""

# Default budget (tokens)
CWO_DEFAULT_BUDGET=100000

# ============================================================
# Init
# ============================================================
cwo_init() {
    CWO_TOTAL_FILES=0
    CWO_TOTAL_TOKENS_BEFORE=0
    CWO_TOTAL_TOKENS_AFTER=0
    CWO_COMPRESSION_RATIO=0
    CWO_FILES_FITTED=0
    CWO_BUDGET_USED=0

    CWO_PROJECT_DIR="${PROJECT_DIR:-.}"
    CWO_CACHE_DIR="${CWO_PROJECT_DIR}/.soloptilink/cache"
    mkdir -p "$CWO_CACHE_DIR" 2>/dev/null || true

    CWO_INITIALIZED=true
    return 0
}

# ============================================================
# Estimate token count for given content
# ~4 chars per token for English/code
# ~2 chars per token for Japanese/CJK
# ============================================================
_cwo_estimate_tokens() {
    local content="$1"
    [[ -z "$content" ]] && { echo "0"; return 0; }

    local total_chars=${#content}

    # Count CJK characters (Japanese/Chinese/Korean)
    local cjk_chars=0
    # Use LC_ALL=C to handle multi-byte properly with wc
    local ascii_chars
    ascii_chars=$(echo "$content" | LC_ALL=C tr -d '\200-\377' | wc -c | tr -d ' ')
    local non_ascii=$((total_chars - ascii_chars))

    # Estimate: non-ASCII chars are mostly CJK at ~2 chars/token
    # ASCII chars at ~4 chars/token
    local cjk_tokens=$((non_ascii / 2))
    local ascii_tokens=$((ascii_chars / 4))

    local total_tokens=$((cjk_tokens + ascii_tokens))
    [[ $total_tokens -lt 1 ]] && total_tokens=1

    echo "$total_tokens"
}

# ============================================================
# Estimate tokens for a file
# ============================================================
_cwo_estimate_file_tokens() {
    local file="$1"
    [[ ! -f "$file" ]] && { echo "0"; return 0; }

    local content
    content=$(cat "$file" 2>/dev/null)
    _cwo_estimate_tokens "$content"
}

# ============================================================
# Compress file contents - remove comments, blank lines,
# collapse imports, minimize whitespace
# ============================================================
_cwo_compress() {
    local file="$1"
    local mode="${2:-normal}"  # normal, aggressive, minimal
    [[ ! -f "$file" ]] && { echo "[CWO] Error: file not found: $file" >&2; return 1; }

    local ext="${file##*.}"
    local content
    content=$(cat "$file" 2>/dev/null)
    [[ -z "$content" ]] && return 0

    local compressed=""

    case "$ext" in
        ts|tsx|js|jsx)
            compressed=$(_cwo_compress_typescript "$content" "$mode")
            ;;
        sh)
            compressed=$(_cwo_compress_bash "$content" "$mode")
            ;;
        json)
            compressed=$(_cwo_compress_json "$content" "$mode")
            ;;
        py)
            compressed=$(_cwo_compress_python "$content" "$mode")
            ;;
        *)
            # Generic: remove blank lines and trailing whitespace
            compressed=$(echo "$content" | sed '/^[[:space:]]*$/d' | sed 's/[[:space:]]*$//')
            ;;
    esac

    echo "$compressed"
}

# ============================================================
# Internal: Compress TypeScript/JavaScript
# ============================================================
_cwo_compress_typescript() {
    local content="$1"
    local mode="${2:-normal}"

    local result=""

    case "$mode" in
        aggressive)
            # Remove all comments, blank lines, collapse imports
            result=$(echo "$content" | \
                sed '/^[[:space:]]*\/\//d' | \
                sed '/^[[:space:]]*\/\*\*/,/\*\//d' | \
                sed '/^[[:space:]]*\/\*/,/\*\//d' | \
                sed '/^[[:space:]]*\*/d' | \
                sed '/^[[:space:]]*$/d' | \
                sed 's/[[:space:]]*$//' | \
                awk '
                    /^import .* from/ {
                        if (!header_done) {
                            imports = imports "\n" $0
                            next
                        }
                    }
                    {
                        if (!header_done && imports != "") {
                            # Collapse imports to single summary line
                            print "// [" NR " imports collapsed]"
                            header_done = 1
                        }
                        header_done = 1
                        print
                    }
                ')
            ;;
        minimal)
            # Keep only function signatures and type definitions
            result=$(echo "$content" | \
                grep -E '(^export |^import |^interface |^type |^class |^(async )?function |^\s*(public|private|protected|static|async)\s+\w+|^\s*\})' | \
                sed '/^[[:space:]]*$/d')
            ;;
        *)
            # Normal: remove multi-line comments, collapse blank lines
            result=$(echo "$content" | \
                sed '/^[[:space:]]*\/\*\*/,/\*\//{ /^[[:space:]]*\/\*\*/d; /^[[:space:]]*\*\//d; /^[[:space:]]*\*/d; }' | \
                sed '/^[[:space:]]*\/\//d' | \
                sed '/^[[:space:]]*$/d' | \
                sed 's/[[:space:]]*$//')
            ;;
    esac

    echo "$result"
}

# ============================================================
# Internal: Compress Bash scripts
# ============================================================
_cwo_compress_bash() {
    local content="$1"
    local mode="${2:-normal}"

    case "$mode" in
        aggressive)
            echo "$content" | \
                sed '/^[[:space:]]*#[^!]/d' | \
                sed '/^[[:space:]]*$/d' | \
                sed '/^# ===/d' | \
                sed 's/[[:space:]]*$//'
            ;;
        minimal)
            echo "$content" | \
                grep -E '(^\w+\(\)|^function |^[A-Z_]+=|^export |^source |^\. )' | \
                sed '/^[[:space:]]*$/d'
            ;;
        *)
            # Normal: remove comment-only lines (keep shebangs), collapse blanks
            echo "$content" | \
                sed '/^[[:space:]]*#[^!]/{ /^#!/!d; }' | \
                sed '/^# ===.*===/d' | \
                sed '/^[[:space:]]*$/d' | \
                sed 's/[[:space:]]*$//'
            ;;
    esac
}

# ============================================================
# Internal: Compress JSON
# ============================================================
_cwo_compress_json() {
    local content="$1"
    local mode="${2:-normal}"

    case "$mode" in
        aggressive|minimal)
            # Single line JSON (remove all whitespace)
            echo "$content" | tr -d '\n' | sed 's/[[:space:]]\+/ /g'
            ;;
        *)
            # Remove blank lines only
            echo "$content" | sed '/^[[:space:]]*$/d'
            ;;
    esac
}

# ============================================================
# Internal: Compress Python
# ============================================================
_cwo_compress_python() {
    local content="$1"
    local mode="${2:-normal}"

    case "$mode" in
        aggressive)
            echo "$content" | \
                sed '/^[[:space:]]*#/d' | \
                sed '/^[[:space:]]*"""$/,/^[[:space:]]*"""$/d' | \
                sed "/^[[:space:]]*'''$/,/^[[:space:]]*'''$/d" | \
                sed '/^[[:space:]]*$/d' | \
                sed 's/[[:space:]]*$//'
            ;;
        minimal)
            echo "$content" | \
                grep -E '(^def |^class |^import |^from |^[A-Z_]+ =)' | \
                sed '/^[[:space:]]*$/d'
            ;;
        *)
            echo "$content" | \
                sed '/^[[:space:]]*#[^!]/d' | \
                sed '/^[[:space:]]*$/d' | \
                sed 's/[[:space:]]*$//'
            ;;
    esac
}

# ============================================================
# Prioritize files by relevance score
# Higher score = more relevant to include in context
# ============================================================
_cwo_prioritize() {
    local project_dir="${1:-$CWO_PROJECT_DIR}"
    shift
    local query="${1:-}"  # Optional relevance query
    shift
    local -a files=("$@")

    # If no files specified, collect all
    if [[ ${#files[@]} -eq 0 ]]; then
        while IFS= read -r f; do
            files+=("$f")
        done < <(find "$project_dir" \
            -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" -o -name "*.sh" -o -name "*.py" \) \
            ! -path "*/node_modules/*" ! -path "*/.next/*" ! -path "*/.git/*" \
            ! -path "*/dist/*" ! -path "*/.soloptilink/*" \
            2>/dev/null | head -500)
    fi

    echo "[CWO] Prioritizing ${#files[@]} files..." >&2

    local -a scored_files=()

    for f in "${files[@]}"; do
        [[ ! -f "$f" ]] && continue
        local rel="${f#$project_dir/}"
        local score=50  # Base score

        # Factor 1: File type priority
        case "$rel" in
            *schema*|*prisma*)          score=$((score + 20)) ;;
            *middleware*|*auth*)         score=$((score + 18)) ;;
            *lib/db*|*lib/api*)         score=$((score + 15)) ;;
            *api/*/route*)              score=$((score + 15)) ;;
            *config*|*env*)             score=$((score + 12)) ;;
            *page*|*layout*)            score=$((score + 10)) ;;
            *component*)                score=$((score + 8))  ;;
            *test*|*spec*)              score=$((score + 3))  ;;
            *types*|*interfaces*)       score=$((score + 12)) ;;
            *utils*|*helpers*)          score=$((score + 8))  ;;
        esac

        # Factor 2: Recently modified (within last hour)
        local mod_time
        mod_time=$(stat -f %m "$f" 2>/dev/null || stat -c %Y "$f" 2>/dev/null || echo "0")
        local now
        now=$(date +%s)
        local age=$((now - mod_time))
        if [[ $age -lt 3600 ]]; then
            score=$((score + 15))  # Modified in last hour
        elif [[ $age -lt 86400 ]]; then
            score=$((score + 8))   # Modified today
        fi

        # Factor 3: File size (prefer smaller, more focused files)
        local lines
        lines=$(wc -l < "$f" 2>/dev/null | tr -d ' ')
        if [[ ${lines:-0} -lt 50 ]]; then
            score=$((score + 5))
        elif [[ ${lines:-0} -lt 200 ]]; then
            score=$((score + 3))
        elif [[ ${lines:-0} -gt 500 ]]; then
            score=$((score - 5))  # Penalize very large files
        fi

        # Factor 4: Export density (more exports = more important)
        local exports
        exports=$(grep -cE '^export ' "$f" 2>/dev/null || echo "0")
        if [[ ${exports:-0} -gt 5 ]]; then
            score=$((score + 8))
        elif [[ ${exports:-0} -gt 2 ]]; then
            score=$((score + 4))
        fi

        # Factor 5: Query relevance (if query provided)
        if [[ -n "$query" ]]; then
            local query_lower
            query_lower=$(echo "$query" | tr '[:upper:]' '[:lower:]')
            local file_lower
            file_lower=$(echo "$rel" | tr '[:upper:]' '[:lower:]')

            for word in $query_lower; do
                # Check filename
                if echo "$file_lower" | grep -q "$word" 2>/dev/null; then
                    score=$((score + 15))
                fi
                # Check file content (first 100 lines)
                if head -100 "$f" 2>/dev/null | grep -qi "$word" 2>/dev/null; then
                    score=$((score + 10))
                fi
            done
        fi

        # Factor 6: Import count (more imported = more central)
        local basename_noext
        basename_noext=$(basename "$rel" | sed 's/\.[^.]*$//')
        local import_count
        import_count=$(grep -rl "$basename_noext" "$project_dir" \
            --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" \
            --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=.git \
            2>/dev/null | wc -l | tr -d ' ')
        if [[ ${import_count:-0} -gt 10 ]]; then
            score=$((score + 12))
        elif [[ ${import_count:-0} -gt 5 ]]; then
            score=$((score + 6))
        elif [[ ${import_count:-0} -gt 2 ]]; then
            score=$((score + 3))
        fi

        [[ $score -gt 100 ]] && score=100
        scored_files+=("${score}|${f}")
    done

    # Sort by score descending
    printf '%s\n' "${scored_files[@]}" | sort -t'|' -k1 -rn | while IFS='|' read -r score filepath; do
        [[ -z "$filepath" ]] && continue
        local rel="${filepath#$project_dir/}"
        local tokens
        tokens=$(_cwo_estimate_file_tokens "$filepath")
        echo "${score}|${tokens}|${filepath}|${rel}"
    done
}

# ============================================================
# Optimize a list of files for Claude's context window
# Returns compressed content fitted to budget
# ============================================================
_cwo_optimize() {
    local project_dir="${1:-$CWO_PROJECT_DIR}"
    local budget="${2:-$CWO_DEFAULT_BUDGET}"
    local query="${3:-}"
    shift 3 2>/dev/null || true
    local -a files=("$@")

    [[ "$CWO_INITIALIZED" != "true" ]] && cwo_init
    CWO_PROJECT_DIR="$project_dir"

    echo "[CWO] Optimizing for ${budget} token budget..." >&2

    # Get prioritized file list
    local prioritized
    prioritized=$(_cwo_prioritize "$project_dir" "$query" "${files[@]}")

    CWO_TOTAL_TOKENS_BEFORE=0
    CWO_TOTAL_TOKENS_AFTER=0
    CWO_FILES_FITTED=0
    CWO_BUDGET_USED=0
    CWO_TOTAL_FILES=0

    local remaining=$budget
    local output=""

    while IFS='|' read -r score tokens filepath rel; do
        [[ -z "$filepath" ]] && continue
        CWO_TOTAL_FILES=$((CWO_TOTAL_FILES + 1))
        CWO_TOTAL_TOKENS_BEFORE=$((CWO_TOTAL_TOKENS_BEFORE + tokens))

        # Determine compression mode based on remaining budget
        local mode="normal"
        if [[ $remaining -lt $((budget / 4)) ]]; then
            mode="minimal"
        elif [[ $remaining -lt $((budget / 2)) ]]; then
            mode="aggressive"
        fi

        # Compress the file
        local compressed
        compressed=$(_cwo_compress "$filepath" "$mode")
        local compressed_tokens
        compressed_tokens=$(_cwo_estimate_tokens "$compressed")

        # Check if it fits
        if [[ $compressed_tokens -le $remaining ]]; then
            output+="--- FILE: ${rel} (score=${score}, tokens=${compressed_tokens}, mode=${mode}) ---\n"
            output+="${compressed}\n"
            output+="--- END: ${rel} ---\n\n"

            remaining=$((remaining - compressed_tokens))
            CWO_TOTAL_TOKENS_AFTER=$((CWO_TOTAL_TOKENS_AFTER + compressed_tokens))
            CWO_FILES_FITTED=$((CWO_FILES_FITTED + 1))
        else
            # Try minimal mode as last resort
            if [[ "$mode" != "minimal" ]]; then
                compressed=$(_cwo_compress "$filepath" "minimal")
                compressed_tokens=$(_cwo_estimate_tokens "$compressed")
                if [[ $compressed_tokens -le $remaining ]]; then
                    output+="--- FILE: ${rel} (score=${score}, tokens=${compressed_tokens}, mode=minimal) ---\n"
                    output+="${compressed}\n"
                    output+="--- END: ${rel} ---\n\n"

                    remaining=$((remaining - compressed_tokens))
                    CWO_TOTAL_TOKENS_AFTER=$((CWO_TOTAL_TOKENS_AFTER + compressed_tokens))
                    CWO_FILES_FITTED=$((CWO_FILES_FITTED + 1))
                else
                    echo "[CWO] Skipping ${rel}: ${compressed_tokens} tokens exceeds remaining ${remaining}" >&2
                fi
            fi
        fi

        # Stop if budget exhausted
        [[ $remaining -le 0 ]] && break
    done <<< "$prioritized"

    CWO_BUDGET_USED=$((budget - remaining))

    # Calculate compression ratio
    if [[ $CWO_TOTAL_TOKENS_BEFORE -gt 0 ]]; then
        CWO_COMPRESSION_RATIO=$(( (CWO_TOTAL_TOKENS_BEFORE - CWO_TOTAL_TOKENS_AFTER) * 100 / CWO_TOTAL_TOKENS_BEFORE ))
    fi

    echo "[CWO] Fitted ${CWO_FILES_FITTED}/${CWO_TOTAL_FILES} files into budget" >&2
    echo "[CWO] Tokens: ${CWO_TOTAL_TOKENS_BEFORE} -> ${CWO_TOTAL_TOKENS_AFTER} (${CWO_COMPRESSION_RATIO}% reduction)" >&2

    echo -e "$output"
    return 0
}

# ============================================================
# Fit maximum context into a token budget
# Returns a manifest of what was included and what was skipped
# ============================================================
_cwo_fit_budget() {
    local project_dir="${1:-$CWO_PROJECT_DIR}"
    local budget="${2:-$CWO_DEFAULT_BUDGET}"
    local query="${3:-}"

    [[ "$CWO_INITIALIZED" != "true" ]] && cwo_init
    CWO_PROJECT_DIR="$project_dir"

    echo "=== Context Window Budget Fit ==="
    echo "Budget: ${budget} tokens"
    echo "Query: ${query:-none}"
    echo ""

    # Get prioritized files
    local prioritized
    prioritized=$(_cwo_prioritize "$project_dir" "$query")

    local remaining=$budget
    local included=0
    local skipped=0
    local included_tokens=0

    echo "Included files (by priority):"
    while IFS='|' read -r score tokens filepath rel; do
        [[ -z "$filepath" ]] && continue

        # Estimate compressed size
        local compressed
        compressed=$(_cwo_compress "$filepath" "normal")
        local compressed_tokens
        compressed_tokens=$(_cwo_estimate_tokens "$compressed")

        if [[ $compressed_tokens -le $remaining ]]; then
            remaining=$((remaining - compressed_tokens))
            included=$((included + 1))
            included_tokens=$((included_tokens + compressed_tokens))
            echo "  [+] ${rel} (score=${score}, ${compressed_tokens} tokens)"
        else
            # Try aggressive
            compressed=$(_cwo_compress "$filepath" "aggressive")
            compressed_tokens=$(_cwo_estimate_tokens "$compressed")
            if [[ $compressed_tokens -le $remaining ]]; then
                remaining=$((remaining - compressed_tokens))
                included=$((included + 1))
                included_tokens=$((included_tokens + compressed_tokens))
                echo "  [+] ${rel} (score=${score}, ${compressed_tokens} tokens, aggressive)"
            else
                skipped=$((skipped + 1))
                echo "  [-] ${rel} (score=${score}, ${compressed_tokens} tokens > ${remaining} remaining)"
            fi
        fi

        [[ $remaining -le 0 ]] && break
    done <<< "$prioritized"

    echo ""
    echo "--- Summary ---"
    echo "Included: ${included} files (${included_tokens} tokens)"
    echo "Skipped:  ${skipped} files"
    echo "Budget used: ${included_tokens}/${budget} tokens ($((included_tokens * 100 / budget))%)"
    echo "Remaining: ${remaining} tokens"

    CWO_FILES_FITTED=$included
    CWO_BUDGET_USED=$included_tokens

    return 0
}

# ============================================================
# Score
# ============================================================
cwo_score() {
    if [[ $CWO_TOTAL_FILES -eq 0 ]]; then
        echo "50"
        return 0
    fi

    local score=50

    # Good compression ratio
    if [[ $CWO_COMPRESSION_RATIO -gt 50 ]]; then
        score=$((score + 20))
    elif [[ $CWO_COMPRESSION_RATIO -gt 30 ]]; then
        score=$((score + 15))
    elif [[ $CWO_COMPRESSION_RATIO -gt 10 ]]; then
        score=$((score + 8))
    fi

    # Good fit ratio
    if [[ $CWO_TOTAL_FILES -gt 0 ]]; then
        local fit_pct=$((CWO_FILES_FITTED * 100 / CWO_TOTAL_FILES))
        if [[ $fit_pct -gt 80 ]]; then
            score=$((score + 20))
        elif [[ $fit_pct -gt 50 ]]; then
            score=$((score + 10))
        fi
    fi

    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# ============================================================
# Report
# ============================================================
cwo_report() {
    echo -e "\n  ${BOLD:-}=== Context Window Optimizer v${CWO_VERSION} ===${NC:-}"
    echo -e "  Files processed:    ${CWO_TOTAL_FILES}"
    echo -e "  Files fitted:       ${CWO_FILES_FITTED}"
    echo -e "  Tokens before:      ${CWO_TOTAL_TOKENS_BEFORE}"
    echo -e "  Tokens after:       ${CWO_TOTAL_TOKENS_AFTER}"
    echo -e "  Compression ratio:  ${CWO_COMPRESSION_RATIO}%"
    echo -e "  Budget used:        ${CWO_BUDGET_USED}"
    echo -e "  Score:              $(cwo_score)/100"
}

# ============================================================
# Module Registry self-registration
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "context-window-optimizer" \
        --version "$CWO_VERSION" \
        --description "コンテキストウィンドウ最適化 - 圧縮/優先順位/トークン管理" \
        --init "cwo_init" \
        --report "cwo_report" \
        --score "cwo_score" \
        --enable-var "ENABLE_CWO" \
        --cli-flags "--context-optimizer:--no-context-optimizer"
fi

# v2003.1: source時のexit codeを確実に0にする
true
