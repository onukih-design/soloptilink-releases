#!/usr/bin/env bash
# =====================================================================
# SoloptiLinkAI v2026.0 — UX-Reachability Gate (UXR)
# =====================================================================
# Purpose:
#   ZDDG が「リンク存在」を保証するのに対し、UXR は
#   「ロール A がログイン後にページ X に N クリック以内で辿り着けるか」
#   を保証する次世代ゲート。
#
# 入力:
#   - $proj/.rvg/zddg/link-graph.json (ZDDG が生成)
#   - $proj/docs/ROLE_NAVIGATION_CONTRACT.md (rnc が生成)
# 出力:
#   - $proj/.rvg/uxr/verdict.json
#
# 判定:
#   - 各 role について、sign-in landing から各 "key page" まで
#     <= 3 クリックで到達可能か (BFS)
#   - 1 つでも到達不能 = FAIL
# =====================================================================

set -uo pipefail

UXR_VERSION="1.0.0"

uxr_log()  { printf '\033[1;34m[UXR]\033[0m %s\n' "$*" >&2; }
uxr_ok()   { printf '\033[1;32m[UXR ✓]\033[0m %s\n' "$*" >&2; }
uxr_warn() { printf '\033[1;33m[UXR ⚠]\033[0m %s\n' "$*" >&2; }
uxr_err()  { printf '\033[1;31m[UXR ✗]\033[0m %s\n' "$*" >&2; }

# ---------------------------------------------------------------------
# Run UXR — produces verdict.json
# ---------------------------------------------------------------------
uxr_run() {
    local proj="${1:-}"
    local max_clicks="${2:-3}"
    [[ -z "$proj" ]] || [[ ! -d "$proj" ]] && { uxr_err "invalid project: $proj"; return 2; }

    local outdir="$proj/.rvg/uxr"
    mkdir -p "$outdir"

    local link_graph="$proj/.rvg/zddg/link-graph.json"
    if [[ ! -f "$link_graph" ]]; then
        uxr_warn "no link graph at $link_graph — run ZDDG first"
        cat > "$outdir/verdict.json" <<'EOF'
{
  "verdict": "SKIP",
  "reason": "no_link_graph",
  "score": 0,
  "max_score": 10
}
EOF
        return 0
    fi

    if ! command -v node >/dev/null 2>&1; then
        uxr_warn "node not available — UXR cannot run BFS"
        cat > "$outdir/verdict.json" <<'EOF'
{
  "verdict": "SKIP",
  "reason": "node_not_available",
  "score": 0,
  "max_score": 10
}
EOF
        return 0
    fi

    # extract roles + key pages from contract doc (best-effort)
    local contract="$proj/docs/ROLE_NAVIGATION_CONTRACT.md"
    local has_contract="false"
    [[ -f "$contract" ]] && has_contract="true"

    node - "$link_graph" "$contract" "$max_clicks" "$has_contract" "$outdir/verdict.json" <<'NODE_EOF'
const fs = require("fs");
const path = require("path");
const [graphPath, contractPath, maxClicksStr, hasContract, outPath] = process.argv.slice(2);

let graph;
try {
    graph = JSON.parse(fs.readFileSync(graphPath, "utf8"));
} catch (e) {
    fs.writeFileSync(outPath, JSON.stringify({verdict: "SKIP", reason: "graph_parse_error", score: 0, max_score: 10}, null, 2));
    process.exit(0);
}

const maxClicks = parseInt(maxClicksStr, 10) || 3;

// build adjacency: from each route -> set of <Link href> destinations
const adj = new Map();
function ensure(node) {
    if (!adj.has(node)) adj.set(node, new Set());
    return adj.get(node);
}
const links = (graph && graph.links) || (Array.isArray(graph) ? graph : []);
for (const l of links) {
    const from = l.from_route || l.source || "/";
    const to = l.to_route || l.href || l.target;
    if (!to) continue;
    // normalize: drop query / hash, leave [id] segments
    const target = String(to).split("?")[0].split("#")[0];
    ensure(from).add(target);
}

// derive role->landing + key pages from contract markdown (best-effort)
function readContractTable(md) {
    if (!md) return null;
    const rows = md.split(/\r?\n/).filter(l => /^\| [A-Z]/.test(l));
    const roles = [];
    for (const row of rows) {
        const cells = row.split("|").map(c => c.trim()).filter(Boolean);
        if (cells.length < 2) continue;
        const role = cells[0];
        const landing = (cells[1].match(/`([^`]+)`/) || [])[1];
        const headerLink = (cells[2] && (cells[2].match(/`([^`]+)`/) || []))[1];
        const acctLink = (cells[3] && (cells[3].match(/`([^`]+)`/) || []))[1];
        const keys = [landing, headerLink, acctLink].filter(Boolean);
        if (role && landing) roles.push({role, landing, keys: Array.from(new Set(keys))});
    }
    return roles.length ? roles : null;
}

let roles = null;
if (hasContract === "true") {
    try { roles = readContractTable(fs.readFileSync(contractPath, "utf8")); } catch {}
}

if (!roles || roles.length === 0) {
    // synthesize a generic test: from "/" can we reach common admin/account pages?
    roles = [
        {role: "GUEST", landing: "/", keys: ["/", "/signin"]},
        {role: "USER",  landing: "/account", keys: ["/account"]},
    ];
}

// helper: does node exist anywhere in graph (as source or as destination)?
function nodeExists(node) {
    if (adj.has(node)) return true;
    for (const dests of adj.values()) {
        if (dests.has(node)) return true;
    }
    return false;
}

// BFS from landing for each role.
// If start does not appear in the graph at all, it is unreachable (UI cannot
// land there because there is no route entry for it).
function bfs(start, target, maxDepth) {
    if (!nodeExists(start)) return -1;
    if (start === target) return 0;
    const seen = new Set([start]);
    let frontier = [start];
    for (let d = 1; d <= maxDepth; d++) {
        const next = [];
        for (const node of frontier) {
            const out = adj.get(node);
            if (!out) continue;
            for (const t of out) {
                if (seen.has(t)) continue;
                if (t === target) return d;
                // also accept [id] match
                if (target.includes("[id]") && t.replace(/\[[^\]]+\]/g, "[id]") === target) return d;
                seen.add(t);
                next.push(t);
            }
        }
        frontier = next;
    }
    return -1;
}

const failures = [];
for (const r of roles) {
    for (const target of r.keys) {
        const d = bfs(r.landing, target, maxClicks);
        if (d < 0) {
            failures.push({role: r.role, landing: r.landing, target, reason: `unreachable_within_${maxClicks}_clicks`});
        }
    }
}

const totalChecks = roles.reduce((a, r) => a + r.keys.length, 0);
const passes = totalChecks - failures.length;
let score, verdict;
if (totalChecks === 0) { score = 0; verdict = "SKIP"; }
else {
    const ratio = passes / totalChecks;
    score = Math.round(ratio * 10);
    if (failures.length === 0) verdict = "PASS";
    else if (ratio >= 0.8)     verdict = "WARN";
    else                       verdict = "FAIL";
}

fs.writeFileSync(outPath, JSON.stringify({
    verdict, score, max_score: 10,
    total_checks: totalChecks, passes, failures,
    roles_checked: roles.map(r => r.role),
    max_clicks: maxClicks,
}, null, 2));
NODE_EOF

    if [[ -f "$outdir/verdict.json" ]]; then
        local v
        v=$(grep -E '"verdict"' "$outdir/verdict.json" | head -1 | sed -E 's/.*"verdict":[[:space:]]*"([^"]+)".*/\1/')
        case "$v" in
            PASS) uxr_ok "UXR PASS"; return 0 ;;
            WARN) uxr_warn "UXR WARN — see $outdir/verdict.json"; return 0 ;;
            SKIP) uxr_warn "UXR SKIP"; return 0 ;;
            FAIL) uxr_err "UXR FAIL — see $outdir/verdict.json"; return 1 ;;
            *)    uxr_warn "UXR unknown verdict ($v)"; return 0 ;;
        esac
    fi
    return 0
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-}" in
        run) shift; uxr_run "$@" ;;
        version) echo "$UXR_VERSION" ;;
        *)
            echo "Usage: $0 run <project_dir> [max_clicks=3]"
            exit 1
            ;;
    esac
fi
