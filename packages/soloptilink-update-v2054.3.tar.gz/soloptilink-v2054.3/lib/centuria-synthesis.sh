#!/usr/bin/env bash
# ==============================================================================
# centuria-synthesis.sh — PFP-093 RLAE 品質最大化レイヤ (Quality Synthesis)
#   「105体が動いている」を「出力品質が最高値になる」へ接続する合成・採点エンジン
#
# 役割 (小貫さん指示 2026-06-05 「出力品質は最高値を叩き出せる環境」):
#   centuria-live-orchestrator が実起動した全ロールの専門成果物 (agent-evidence/*.md)
#   を、単に"走った証跡"で終わらせず、
#     1. フェーズ別に統合した「実装指示ブループリント」(centuria-blueprint.md) に合成し、
#        Implementer 波/親 Claude がこれを唯一の設計入力として高品質実装する
#     2. 実エージェントのレビューに基づく Centuria Quality Index (CQI) を算出し、
#        固定値ではなく"実際の専門レビュー網羅度"で品質を採点する
#   ことで、105体の専門知が出力物の品質に直結する状態を構造的に作る。
#
# コマンド:
#   synthesize <project_dir>            evidence を統合し blueprint(2分割) + CQI を生成
#   blueprint  <project_dir>            blueprint.md (実装コア版) のパスを出力
#   score      <project_dir> [min_cqi]  CQI を算出。min_cqi 未満なら exit 1 (品質ゲート)
#   report     <project_dir>            完了報告用の品質サマリ一行
#
# 出力 (PFP-112 トークン削減・2分割):
#   <project_dir>/.soloptilink/centuria-blueprint.md         (設計+実装フェーズ本体・上限60KB・1箇条書き120字)
#   <project_dir>/.soloptilink/centuria-blueprint-review.md  (品質/セキュリティ/レビュー指摘・実装後反映用)
#   <project_dir>/.soloptilink/centuria-quality-report.json  (CQI + 内訳)
# 依存: python3, centuria-dispatch-plan.json, agent-evidence/*.md
# ==============================================================================
set -euo pipefail

SL="$HOME/.soloptilink"
EVIDENCE_MARKER="CENTURIA-AGENT-EVIDENCE"
CQI_MIN_DEFAULT="${CENTURIA_CQI_MIN:-80}"

# 証跡 soft 上限 (バイト)。orchestrator の規律 (上限1200字) と整合し、超過分は統合時に切詰める (PFP-112)
_cap_env="${CENTURIA_EVIDENCE_SOFT_CAP_BYTES:-4000}"
[[ "$_cap_env" =~ ^[0-9]+$ ]] || _cap_env=4000
EVIDENCE_SOFT_CAP_BYTES=$(( _cap_env < 1200 ? 1200 : _cap_env ))

# CQI 有効性床 (L6/PFP-093 厳格化): CQI 算入に値する証跡の最小文字数。
# orchestrator の EVIDENCE_MIN_CHARS と同一基準 (max(env,200)) に整合させ、200未満には絶対に下げられない
# (環境変数によるゲーミング防止)。これにより 100〜199字のスタブ証跡で coverage/depth を水増しする抜け穴を塞ぐ。
# 正規の証跡 (規律上限1200字・有効床200字) はこの床を当然満たすため PASS 走の CQI は不変 (機能等価)。
_minch_env="${CENTURIA_EVIDENCE_MIN_CHARS:-200}"
[[ "$_minch_env" =~ ^[0-9]+$ ]] || _minch_env=200
EVIDENCE_MIN_CHARS=$(( _minch_env > 200 ? _minch_env : 200 ))

# blueprint (実装コア版) の上限バイト数 (既定60KB・下限8KB) と 1箇条書きの上限字数
_bp_env="${CENTURIA_BLUEPRINT_MAX_BYTES:-61440}"
[[ "$_bp_env" =~ ^[0-9]+$ ]] || _bp_env=61440
BLUEPRINT_MAX_BYTES=$(( _bp_env < 8192 ? 8192 : _bp_env ))
BULLET_MAX_CHARS=120

C_CY='\033[0;36m'; C_GR='\033[0;32m'; C_RD='\033[0;31m'; C_YL='\033[1;33m'; C_NC='\033[0m'
_die() { echo -e "${C_RD}$*${C_NC}" >&2; exit 2; }

_plan_path()     { echo "$1/.soloptilink/centuria-dispatch-plan.json"; }
_evidence_dir()  { echo "$1/.soloptilink/agent-evidence"; }
_blueprint_path(){ echo "$1/.soloptilink/centuria-blueprint.md"; }
_review_bp_path(){ echo "$1/.soloptilink/centuria-blueprint-review.md"; }
_quality_path()  { echo "$1/.soloptilink/centuria-quality-report.json"; }

# ------------------------------------------------------------------------------
# synthesize: evidence → blueprint.md + quality-report.json
# ------------------------------------------------------------------------------
_cmd_synthesize() {
  local pdir="${1:?project_dir required}"
  [ -f "$(_plan_path "$pdir")" ] || _die "先に centuria-live-orchestrator.sh plan を実行してください"
  PLAN="$(_plan_path "$pdir")" EVDIR="$(_evidence_dir "$pdir")" \
  BP="$(_blueprint_path "$pdir")" BPR="$(_review_bp_path "$pdir")" QR="$(_quality_path "$pdir")" \
  MARKER="$EVIDENCE_MARKER" SOFTCAP="$EVIDENCE_SOFT_CAP_BYTES" \
  MINCHARS="$EVIDENCE_MIN_CHARS" \
  BPMAX="$BLUEPRINT_MAX_BYTES" BULLETMAX="$BULLET_MAX_CHARS" python3 - <<'PY'
import json, os, glob, re, hashlib, unicodedata

plan = json.load(open(os.environ["PLAN"]))
evdir = os.environ["EVDIR"]; marker = os.environ["MARKER"]
bp = os.environ["BP"]; bpr = os.environ["BPR"]; qr = os.environ["QR"]
softcap   = int(os.environ["SOFTCAP"])
bp_max    = int(os.environ["BPMAX"])
bullet_max= int(os.environ["BULLETMAX"])
# CQI 有効性床 (L6): orchestrator EVIDENCE_MIN_CHARS と同一基準。200未満には決して下がらない (bash側で max(env,200) 済)
min_chars = max(200, int(os.environ.get("MINCHARS", "200")))

# 役割 → フェーズ/タイトルの索引
role_meta = {}
for w in plan["waves"]:
    for a in w["agents"]:
        role_meta[a["id"]] = {"title": a["title"], "phase": a["phase"],
                              "phase_label": a.get("phase_label", a["phase"]),
                              "wave": w["wave_no"]}

PHASE_ORDER = ["architecture","implementation","data_ai","quality","security","ops","review","analysis"]
PHASE_LABEL = {"architecture":"設計","implementation":"実装","data_ai":"データ/AI",
               "quality":"品質/テスト","security":"セキュリティ/規制","ops":"運用/インフラ",
               "review":"レビュー/改善","analysis":"専門分析","adversarial":"敵対的検証"}
# 注: adversarial は CQI 分母を変えないため synthesis PHASE_ORDER には敢えて含めない。
# by_phase.setdefault + extra_phases 機構で拾われ、REVIEW_PHASES により blueprint-review.md (反証台帳) へ集約される。

def truncate_bytes(text, cap):
    """UTF-8 バイト基準で安全に切詰める (多バイト文字の途中切断を防止)"""
    raw = text.encode("utf-8", "ignore")
    if len(raw) <= cap:
        return text, False
    return raw[:cap].decode("utf-8", "ignore"), True

def extract(body):
    """マーカー後の本文を取り出し、soft 上限で切詰めた上で見出し/要点と全文長を返す"""
    content = body.split("-->", 1)[-1].strip() if "-->" in body else body.strip()
    # 証跡 soft 上限 (PFP-112): 規律「上限1200字」超過分は統合時に切詰めて評価対象外とする
    content, truncated = truncate_bytes(content, softcap)
    # 見出し (##/###) と箇条書きの先頭を要点として抽出
    points = []
    for ln in content.splitlines():
        s = ln.strip()
        if re.match(r"^#{1,4}\s+\S", s):
            points.append(("h", re.sub(r"^#{1,4}\s+", "", s)))
        elif re.match(r"^[-*]\s+\S", s) or re.match(r"^\d+\.\s+\S", s):
            points.append(("b", re.sub(r"^([-*]|\d+\.)\s+", "", s)))
        if len(points) >= 8:
            break
    return content, points, truncated

def extract_differentiation(content):
    """PFP-130: 証跡本文から『## 差別化提案』節の箇条書きを抽出する (差別化台帳用)。
    見出しに『差別化』を含む節の配下の箇条書き/番号付き行を、次の見出しまで収集する。
    通常の要点抽出(extract)が先頭8件で打ち切られて差別化提案を取りこぼすのを防ぐ専用経路。"""
    out = []
    in_sec = False
    for ln in content.splitlines():
        s = ln.strip()
        if re.match(r"^#{1,6}\s+\S", s):
            # 出力契約で固定した見出し『## 差別化提案』(と台帳の差別化機能)に限定。
            # 『競合の差別化分析』『差別化戦略』等の無関係見出し配下の誤混入を防ぐ。
            in_sec = ("差別化提案" in s) or ("差別化機能" in s)
            continue
        if in_sec and (re.match(r"^[-*]\s+\S", s) or re.match(r"^\d+\.\s+\S", s)):
            item = re.sub(r"^([-*]|\d+\.)\s+", "", s).strip()
            item = re.sub(r"^\*\*(.+?)\*\*", r"\1", item)  # 強調記法を平坦化
            if len(item) >= 6:
                out.append(item)
    return out

# evidence 収集
collected = {}   # role_id -> {content, points, chars, hash, truncated}
hashes = {}
truncated_count = 0
outside_plan = 0
below_min = 0    # CQI 有効性床 (min_chars) 未満で除外した証跡数 (水増し防止の可視化)
for f in sorted(glob.glob(os.path.join(evdir, "*.md"))):
    rid = os.path.basename(f)[:-3]
    try: body = open(f, encoding="utf-8", errors="ignore").read()
    except Exception: continue
    if marker not in body: continue
    # plan 外ロールは統合しない (orchestrator tally と同一基準 / 証跡偽装による CQI 水増し防止)
    if rid not in role_meta:
        outside_plan += 1; continue
    # 相違判定 (distinctness) は切詰め前の全文ハッシュで行う (切詰めによる偽重複を防止)
    full = body.split("-->", 1)[-1].strip() if "-->" in body else body.strip()
    content, points, truncated = extract(body)
    # CQI 有効性床 (L6 厳格化): orchestrator EVIDENCE_MIN_CHARS と同一の min_chars(>=200) 未満は
    # coverage/depth/distinctness いずれにも算入しない。100〜199字スタブによる CQI 水増しを構造的に塞ぐ。
    if len(content) < min_chars:
        below_min += 1; continue
    if truncated: truncated_count += 1
    h = hashlib.sha256(full.encode("utf-8","ignore")).hexdigest()
    collected[rid] = {"content": content, "points": points, "chars": len(content),
                      "hash": h, "truncated": truncated,
                      "diffs": extract_differentiation(content)}
    hashes.setdefault(h, []).append(rid)

# --- blueprint 2分割生成 (PFP-112 トークン削減) -----------------------------------
#   centuria-blueprint.md        = 設計+実装フェーズ本体 (実装コア版・上限60KB・1箇条書き120字)
#   centuria-blueprint-review.md = 品質/セキュリティ/レビュー指摘 (実装後反映チェック用)
REVIEW_PHASES = {"quality", "security", "review", "adversarial"}

wm = ("<!--\n  Generated by SoloptiLinkAI BOOST (Centuria Synthesis / PFP-093)\n"
      "  (c) 2026 SoloptiLink Inc. - All rights reserved.\n"
      "  Redistribution / derivative-work / reverse-engineering prohibited.\n-->\n\n")

by_phase = {p: [] for p in PHASE_ORDER}
for rid, d in collected.items():
    ph = role_meta.get(rid, {}).get("phase", "analysis")
    by_phase.setdefault(ph, []).append((rid, d))

phase_contrib = {}
# PHASE_ORDER の順に出力し、想定外フェーズ(将来拡張)も末尾で必ず掲載する
extra_phases = [p for p in by_phase.keys() if p not in PHASE_ORDER and by_phase.get(p)]
for ph in PHASE_ORDER + extra_phases:
    if by_phase.get(ph):
        phase_contrib[ph] = len(by_phase[ph])

def norm_key(text):
    """近似重複マージ用の正規化キー (NFKC + 小文字化 + 空白/記号除去 → ハッシュ)"""
    t = unicodedata.normalize("NFKC", text).lower()
    t = re.sub(r"[\s、。,．.・:：;；()（）\[\]「」『』*`'\"_\-…→]+", "", t)
    return hashlib.sha256(t.encode("utf-8", "ignore")).hexdigest() if t else ""

def cap_bullet(txt):
    """1箇条書きの上限字数 (既定120字) を強制。超過は切詰め"""
    txt = " ".join(txt.split())
    return txt if len(txt) <= bullet_max else txt[: bullet_max - 1] + "…"

# --- 差別化台帳 (DIFFERENTIATION LEDGER / PFP-130) -------------------------------------
# 各ロールの『差別化提案』を集約し、重複マージ(render_phase)・段階圧縮の対象外で温存する。
# 反証台帳(adversarial→blueprint-review.md)と対称の「攻めの台帳」。blueprint 冒頭に置き、
# Implementer/親Claude が必ず実装入力として受け取れるようにする。
diff_items = []
_diff_seen = set()
for _rid in collected:
    _title = role_meta.get(_rid, {}).get("title", _rid)
    for _it in collected[_rid].get("diffs", []):
        _k = norm_key(_it)
        if _k and _k in _diff_seen:
            continue
        if _k: _diff_seen.add(_k)
        diff_items.append((_title, cap_bullet(_it)))
diff_count = len(diff_items)
if diff_items:
    _dl = ["\n\n## 差別化機能 台帳 (DIFFERENTIATION LEDGER — 最優先実装・必ず形にする)\n",
           "本節は各専門ロールが提案した『この事業ならではの賢い機能』の集約です。"
           "汎用CRUD(ただの一覧/登録)に退行せず、以下を実装の最優先入力として必ず反映してください"
           "(算定式・係数・閾値まで実装に落とすこと)。\n"]
    for _t, _it in diff_items[:40]:
        _dl.append(f"- [{_t}] {_it}\n")
    DIFFERENTIATION_BLOCK = "".join(_dl)
else:
    DIFFERENTIATION_BLOCK = (
        "\n\n## 差別化機能 台帳 (DIFFERENTIATION LEDGER)\n"
        "- ⚠ 差別化提案が抽出ゼロです。各ロールに『## 差別化提案』節を必須化していますが本ビルドでは検出されませんでした。"
        "汎用CRUDに留まっている可能性が高いため、実装前に業種固有の分析/予測/スコアリング/自動判定機能を最低1つ設計してください。\n")

def render_phase(ph, bucket, lines, seen, stats, max_points):
    """フェーズ単位で要点を出力。ロール間の近似重複箇条書きは初出ロールに統合する"""
    lines.append(f"\n## {PHASE_LABEL.get(ph, ph)} フェーズ ({len(bucket)} 専門ロール)\n")
    merged_roles = []
    for rid, d in bucket:
        title = role_meta.get(rid, {}).get("title", rid)
        pts = d["points"][:max_points] if d["points"] else [("b", d["content"][:280].replace("\n", " "))]
        role_lines = []
        for kind, txt in pts:
            txt = cap_bullet(txt)
            k = norm_key(txt)
            if k and k in seen:
                stats["merged"] += 1
                continue
            if k:
                seen.add(k)
            role_lines.append(f"- **{txt}**\n" if kind == "h" else f"- {txt}\n")
        if role_lines:
            lines.append(f"\n### {title} (`{rid}`)\n")
            lines.extend(role_lines)
        else:
            merged_roles.append(rid)   # 全要点が他ロールと同旨 → 1行に統合
    if merged_roles:
        lines.append(f"\n- (重複統合) 次のロールの要点は他ロールと同旨のため統合済: {', '.join(merged_roles)}\n")

def build_docs(core_max_points):
    """core(設計+実装) と review(品質/セキュリティ/レビュー) の2文書を同一の重複マージ基準で生成"""
    seen = set(); stats = {"merged": 0}
    core = [wm, "# Centuria 統合ブループリント (実装コア版)\n",
            f"本書は {len(collected)} 体の専門ロールが実際に生成した検討結果のうち、"
            f"設計+実装フェーズ本体を統合した**唯一の高品質設計入力**です。"
            f"Implementer/親 Claude はこのブループリントに従って実装します。\n",
            "品質/セキュリティ/レビュー指摘は centuria-blueprint-review.md を実装後に必ず反映してください。\n",
            f"\n対象タスク: {plan.get('task','(不明)')}\n"]
    # PFP-130: 差別化台帳を冒頭(導入直後・フェーズ本体の前)に温存。重複マージ・段階圧縮の影響を受けない。
    core.append(DIFFERENTIATION_BLOCK)
    review = [wm, "# Centuria 品質・セキュリティ・レビュー統合 (実装後反映チェック)\n",
              "本書は品質/テスト・セキュリティ/規制・レビュー/改善フェーズの専門ロール指摘を統合したものです。"
              "実装完了前に本書の指摘を必ず反映してから完成宣言してください。\n"]
    review_count = 0
    for ph in PHASE_ORDER + extra_phases:
        bucket = by_phase.get(ph, [])
        if not bucket:
            continue
        if ph in REVIEW_PHASES:
            render_phase(ph, bucket, review, seen, stats, 6)
            review_count += len(bucket)
        else:
            render_phase(ph, bucket, core, seen, stats, core_max_points)
    if review_count == 0:
        review.append("\n- (該当フェーズの証跡なし)\n")
    return "".join(core), "".join(review), stats["merged"]

# --- 実装の必須制約 (CONSTRAINTS): 切詰め時も blueprint 末尾で必ず温存する不変ブロック (L6/PFP-093) ---
# 60KB 上限で本文が切詰められても、実装者が従うべき品質不変条件 (bcrypt/モック禁止/和文UI 等) が
# 末尾ごと削られる事故 (PFP-112 切詰めの盲点) を構造的に防止する。本文中間のみ切詰め CONSTRAINTS は必ず残す。
CONSTRAINTS_BLOCK = (
    "\n\n## 実装の必須制約 (CONSTRAINTS — 上限切詰め時も必ず温存)\n"
    "- パスワードは bcrypt(コスト12)でハッシュ化。平文・可逆暗号での保存は禁止。\n"
    "- モックデータ・ダミー固定値・ハードコードされた一覧を残さない。全データは Prisma 経由で DB から取得・永続化する。\n"
    "- UI 文字列(ボタン/ラベル/見出し/トースト/バリデーション/空状態/確認ダイアログ)は日本語。識別子は英語。\n"
    "- 入力は zod でクライアント+サーバの二重バリデーション。書込は server action / API route → prisma.create/update。\n"
    "- 複数テーブル更新は prisma.$transaction で原子化し、トランザクション境界を守る。\n"
    "- 認可は最小権限・テナント境界を強制。監査ログ・エラーバウンダリ(error.tsx/not-found.tsx)を備える。\n"
    "- 【権限・役割: 初回から必須 / PFP-131】管理者1役割で完結させないこと。業務に応じた役割を2つ以上"
    "(例: 管理者/現場担当・オペレーター/閲覧専用/顧客 等)定義し、①各役割の代表アカウントを seed に投入"
    "(初回ログインで役割差を体感できる) ②役割ごとに見えるメニュー・操作・到達画面を分ける(役割別ナビゲーション) "
    "③データは自社/自担当のみへ権限スコープ(行レベル)。役割は middleware とサーバアクションの双方で実際に"
    "認可制御へ用いること(スキーマに role があるだけ・ラベルだけの未接続は不可)。\n"
    "- 上記は本ブループリントが切詰められても省略不可。詳細指摘は centuria-blueprint-review.md を参照。\n"
)
cons_bytes = len(CONSTRAINTS_BLOCK.encode("utf-8"))

# 60KB 上限: 要点数を 6→1 へ段階的に減らして本文(core_body)を収める。CONSTRAINTS 分の予算を確保して判定する。
core_body, review_text, merged_dups = build_docs(6)
for mp in (5, 4, 3, 2, 1):
    if len(core_body.encode("utf-8")) + cons_bytes <= bp_max:
        break
    core_body, review_text, merged_dups = build_docs(mp)

if len(core_body.encode("utf-8")) + cons_bytes <= bp_max:
    core_text = core_body + CONSTRAINTS_BLOCK
    blueprint_truncated = False
else:
    # 本文(core_body)のみを行境界で安全に切詰め、CONSTRAINTS は末尾に必ず再付与する (UTF-8 境界安全)
    note = f"\n\n- (上限{bp_max}バイトにより本文中間を切詰め。全文は agent-evidence/ を参照)\n"
    budget = bp_max - cons_bytes - len(note.encode("utf-8"))
    if budget < 0:
        budget = 0   # 極端に小さい上限でも CONSTRAINTS を最優先で温存する
    raw = core_body.encode("utf-8")[:budget].decode("utf-8", "ignore")
    cut = raw.rfind("\n")
    raw = raw[: cut + 1] if cut >= 0 else raw
    core_text = raw + note + CONSTRAINTS_BLOCK
    blueprint_truncated = True

open(bp, "w", encoding="utf-8").write(core_text)
open(bpr, "w", encoding="utf-8").write(review_text)

# --- Centuria Quality Index (CQI) 算出 (敵対的レビュー対応・水増し耐性) ---
# planned: plan.json の手動 total_roles ではなく、実際のエージェント定義数から算出
#          (外部書き換えによる coverage 水増しを排除)
planned = sum(len(w.get("agents", [])) for w in plan.get("waves", [])) or 1
roles_contrib = len(collected)
# 実フェーズ(analysis フォールバックを除く7フェーズ)を分母に固定し、単一フェーズ集中の水増しを排除
CORE_PHASES = [p for p in PHASE_ORDER if p != "analysis"]
expected_phases = len(CORE_PHASES)
total_phases = sum(1 for p in CORE_PHASES if by_phase.get(p))
avg_chars  = (sum(d["chars"] for d in collected.values()) / roles_contrib) if roles_contrib else 0
avg_points = (sum(len(d["points"]) for d in collected.values()) / roles_contrib) if roles_contrib else 0
# distinctness: 全同一なら 0、全相違なら 1 になる比 ((unique-1)/(n-1))。完全一致ハッシュ基準
unique = len(hashes)
distinctness = ((unique - 1) / (roles_contrib - 1)) if roles_contrib > 1 else (1.0 if roles_contrib == 1 else 0.0)
distinctness = max(0.0, min(1.0, distinctness))

coverage      = min(1.0, roles_contrib / planned)
phase_coverage= min(1.0, total_phases / expected_phases)
# depth: 文字量(基準1200字 = 証跡規律「上限1200字」と整合 / PFP-112)と構造量の複合。
# 旧基準4000字は規律準拠の証跡が構造的に減点される乖離があったため是正
char_depth   = min(1.0, avg_chars / 1200.0)
struct_depth = min(1.0, avg_points / 5.0)
depth        = 0.6*char_depth + 0.4*struct_depth
# differentiation (PFP-130): 差別化台帳の固有提案数を正規化した可視化指標。
# ★CQI 本式の重みは敢えて変えない (既存ビルドの CQI 回帰をゼロに保つため)。差別化の実装強制は
# differentiation-insight-gate (born-passing でコード実装を照合) が担い、ここは可視化と gate 入力に徹する。
diff_target = max(6.0, 0.1 * roles_contrib)
differentiation = min(1.0, diff_count / diff_target) if diff_target else 0.0
cqi = round(100 * (0.40*coverage + 0.20*phase_coverage + 0.25*depth + 0.15*distinctness))

report = {
    "schema_version": 1, "pfp": "PFP-093-synthesis",
    "cqi": cqi,
    "components": {
        "coverage": round(coverage,3), "phase_coverage": round(phase_coverage,3),
        "depth": round(depth,3), "distinctness": round(distinctness,3),
        "differentiation": round(differentiation,3),
    },
    "differentiation_items": diff_count,
    "roles_contributed": roles_contrib, "planned_roles": planned,
    "phases_covered": total_phases, "phases_expected": expected_phases,
    "avg_evidence_chars": int(avg_chars), "avg_evidence_points": round(avg_points,1),
    "unique_evidence": unique,
    "phase_contribution": {PHASE_LABEL.get(k,k): v for k,v in phase_contrib.items()},
    "blueprint_path": bp,
    "review_blueprint_path": bpr,
    "blueprint_bytes": len(core_text.encode("utf-8")),
    "blueprint_truncated": blueprint_truncated,
    "review_blueprint_bytes": len(review_text.encode("utf-8")),
    "merged_duplicate_points": merged_dups,
    "evidence_truncated": truncated_count,
    "evidence_outside_plan": outside_plan,
    "evidence_below_min": below_min,
    "evidence_min_chars": min_chars,
    "evidence_soft_cap_bytes": softcap,
    "bullet_max_chars": bullet_max,
}
tmp = qr + ".tmp"
with open(tmp, "w") as _f:
    json.dump(report, _f, ensure_ascii=False, indent=2)
os.replace(tmp, qr)
print(f"[PFP-093-synth] blueprint 生成 (実装コア版): {bp} ({len(core_text.encode('utf-8'))} bytes / 上限 {bp_max})")
print(f"[PFP-093-synth] blueprint-review 生成 (品質/セキュリティ/レビュー): {bpr} ({len(review_text.encode('utf-8'))} bytes)")
if merged_dups:
    print(f"[PFP-093-synth] ロール間の近似重複箇条書きを {merged_dups} 件マージ (正規化ハッシュ方式)")
if truncated_count:
    print(f"[PFP-093-synth] soft 上限 ({softcap} bytes) 超過の証跡 {truncated_count} 件を切詰めて統合")
print(f"[PFP-093-synth] CQI={cqi}/100  (網羅{coverage:.2f}/フェーズ{phase_coverage:.2f}/深さ{depth:.2f}/相違{distinctness:.2f}/差別化{differentiation:.2f}・台帳{diff_count}件)")
print(f"[PFP-093-synth] 統合した専門ロール: {roles_contrib}体 / {total_phases}フェーズ")
PY

  # ── Session③ DBL business_logic → 実行コード化 変換仕様を blueprint へ追記 ──
  # blueprint は実装(Role2/親Claude)の唯一の設計入力。差別化台帳と対称に『L3 codegen 義務』を本文へ温存し、
  # 業務ロジックを prose の言及で済ませず『関数+zod+単体テスト』へ materialize させる(L3 恒真化の根治)。
  # DBL は plan が解決済みの dbl.name を再利用(env→task 検出の二重実装を避ける)。浅い業種は spec が正直に
  # L2 止まりと申告(誇大 L3 を出さない)。kill-switch: ENABLE_DBL_CODEGEN=off で no-op。DBL JSON は無編集。
  local _bp; _bp="$(_blueprint_path "$pdir")"
  local _codegen="$SL/lib/first-boot-perfect/dbl-logic-codegen.sh"
  if [[ "${ENABLE_DBL_CODEGEN:-auto}" != "off" && -f "$_codegen" && -f "$_bp" ]]; then
    local _dbl_name=""
    _dbl_name="$(python3 -c "import json,sys
try:
    d=json.load(open('$(_plan_path "$pdir")'))
    print((d.get('dbl') or {}).get('name') or '')
except Exception: print('')" 2>/dev/null)"
    [[ -z "$_dbl_name" ]] && _dbl_name="${SOLOPTILINK_DETECTED_DBL:-}"
    if [[ -n "$_dbl_name" ]]; then
      local _spec; _spec="$(bash "$_codegen" spec "$_dbl_name" 2>/dev/null || true)"
      if [[ -n "$_spec" ]]; then
        { printf '\n\n'; printf '%s\n' "$_spec"; } >> "$_bp"
        echo "[PFP-093-synth] L3 codegen 変換仕様を blueprint へ追記 (DBL=$_dbl_name)"
      fi
    fi
  fi
}

_cmd_blueprint() { local pdir="${1:?}"; echo "$(_blueprint_path "$pdir")"; }

_cmd_score() {
  local pdir="${1:?project_dir required}"; local minv="${2:-$CQI_MIN_DEFAULT}"
  [ -f "$(_quality_path "$pdir")" ] || _cmd_synthesize "$pdir" >/dev/null
  QR="$(_quality_path "$pdir")" MIN="$minv" python3 - <<'PY'
import json, os, sys
d = json.load(open(os.environ["QR"])); minv = int(os.environ["MIN"]); cqi = d.get("cqi",0)
ok = cqi >= minv
print(json.dumps({"verdict":"PASS" if ok else "FAIL","cqi":cqi,"required_min":minv,
                  "components":d.get("components",{})}, ensure_ascii=False))
if ok: print(f"\033[0;32m✅ Centuria Quality Index {cqi}/100 (要件 {minv} 以上) — 出力品質を構造的に保証\033[0m")
else:  print(f"\033[0;31m❌ CQI {cqi}/100 < {minv}。専門ロールの網羅/深掘りを追加してください\033[0m")
sys.exit(0 if ok else 1)
PY
}

_cmd_report() {
  local pdir="${1:?project_dir required}"
  [ -f "$(_quality_path "$pdir")" ] || _cmd_synthesize "$pdir" >/dev/null 2>&1 || true
  QR="$(_quality_path "$pdir")" python3 - <<'PY'
import json, os
try: d = json.load(open(os.environ["QR"]))
except Exception:
    print("📊 品質統合: 未実行 (centuria-synthesis synthesize を実行してください)"); raise SystemExit(0)
pc = " / ".join(f"{k}{v}体" for k,v in d.get("phase_contribution",{}).items())
print(f"📊 Centuria Quality Index: {d.get('cqi',0)}/100 — {d.get('roles_contributed',0)}体の専門知を統合")
print(f"   フェーズ別貢献: {pc}")
print(f"   実装指示ブループリント: .soloptilink/centuria-blueprint.md (実装コア版・これを唯一の設計入力に高品質実装)")
print(f"   品質/セキュリティ/レビュー指摘: .soloptilink/centuria-blueprint-review.md (実装後に必ず反映)")
PY
}

cmd="${1:-}"; shift 2>/dev/null || true
case "$cmd" in
  synthesize) _cmd_synthesize "$@" ;;
  blueprint)  _cmd_blueprint  "$@" ;;
  score)      _cmd_score      "$@" ;;
  report)     _cmd_report     "$@" ;;
  *) echo "usage: centuria-synthesis.sh {synthesize|blueprint|score|report} <project_dir> [min_cqi]" >&2; exit 2 ;;
esac
