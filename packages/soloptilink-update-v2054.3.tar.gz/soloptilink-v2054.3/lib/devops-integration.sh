#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v370.0 - DevOps Integration Engine
# =============================================================================
# v321-v369全DevOpsモジュールの統合オーケストレーター
#
# 機能:
#   - プロジェクト構造解析→必要DevOpsモジュール自動選択
#   - 全DevOpsモジュールの統合初期化
#   - オーケストレーション（依存順実行）
#   - 統合レポート生成
#   - DevOps成熟度スコア計算
#
# 全globals: DOI_ prefix
# =============================================================================

[[ -n "${_DOI_LOADED:-}" ]] && return 0; _DOI_LOADED=1

DOI_VERSION="370.0"
DOI_GENERATED=0
DOI_ERRORS=0
DOI_PHASE="devops_integration"
DOI_FILES_CREATED=()
DOI_MODULES_SELECTED=()
DOI_MODULES_EXECUTED=0
DOI_MATURITY_SCORE=0

# DevOps modules registry (v351-v369)
declare -A DOI_DEVOPS_MODULES=(
    [canary-analysis]="v351:_cae2_deploy_canary:CAE2"
    [feature-flags]="v352:_ffm_create_flag:FFM"
    [ab-testing]="v353:_abtf_create_experiment:ABTF"
    [preview-env]="v354:_pe_create_preview:PE"
    [rollback]="v355:_re_detect_issue:RE"
    [health-check]="v356:_hcs_generate_health_endpoint:HCS"
    [incident-response]="v357:_ir_detect_incident:IR"
    [sla-monitor]="v358:_slm_define_sla:SLM"
    [compliance]="v359:_comp_scan_gdpr:COMP_SCAN"
    [dependency-update]="v360:_du_check_outdated:DU"
    [license-check]="v361:_lc_scan_licenses:LC"
    [container-security]="v362:_css2_scan_image:CSS2"
    [rate-limit-test]="v363:_arlt_test_rate_limits:ARLT"
    [data-privacy]="v364:_dps2_detect_pii:DPS2"
    [observability]="v365:_os_generate_tracing:OS"
    [cost-alert]="v366:_cas_set_budget:CAS"
    [deploy-dashboard]="v367:_dd_generate_dashboard:DD"
    [gitops]="v368:_ge_generate_gitops_config:GE"
    [multi-region]="v369:_mrd_generate_multi_region:MRD"
)

: "${GREEN:=\033[0;32m}" ; : "${RED:=\033[0;31m}" ; : "${YELLOW:=\033[0;33m}"
: "${CYAN:=\033[0;36m}" ; : "${BOLD:=\033[1m}" ; : "${NC:=\033[0m}"

_doi_log() { echo -e "  ${CYAN}[DOI]${NC} $*"; }
_doi_ok() { echo -e "  ${GREEN}[DOI]${NC} $*"; }
_doi_warn() { echo -e "  ${YELLOW}[DOI]${NC} $*"; }
_doi_err() { echo -e "  ${RED}[DOI]${NC} $*"; }

_doi_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        DOI_FILES_CREATED+=("$filepath")
        DOI_GENERATED=$((DOI_GENERATED + 1))
        _doi_ok "Created: ${filepath##*/}"
    else
        DOI_ERRORS=$((DOI_ERRORS + 1))
        _doi_err "Failed: ${filepath##*/}"
    fi
}

# =============================================================================
# Init
# =============================================================================
_doi_init() {
    DOI_GENERATED=0
    DOI_ERRORS=0
    DOI_MODULES_SELECTED=()
    DOI_MODULES_EXECUTED=0
    DOI_MATURITY_SCORE=0
    DOI_FILES_CREATED=()
    _doi_log "DevOps Integration Engine v${DOI_VERSION} initialized"
    _doi_log "Available DevOps modules: ${#DOI_DEVOPS_MODULES[@]}"
    return 0
}

# =============================================================================
# Select DevOps Modules
# =============================================================================
_doi_select_devops_modules() {
    local project_dir="${1:-.}"
    local force_all="${2:-false}"

    _doi_log "Analyzing project for DevOps module selection..."

    DOI_MODULES_SELECTED=()

    if [[ "$force_all" == "true" ]]; then
        for module_name in "${!DOI_DEVOPS_MODULES[@]}"; do
            DOI_MODULES_SELECTED+=("$module_name")
        done
        _doi_ok "Force-selected all ${#DOI_MODULES_SELECTED[@]} DevOps modules"
        return 0
    fi

    # Core modules (always selected)
    local core_modules=("health-check" "rollback" "observability" "deploy-dashboard")
    for m in "${core_modules[@]}"; do
        DOI_MODULES_SELECTED+=("$m")
    done

    # Docker detection
    if [[ -f "${project_dir}/Dockerfile" ]] || [[ -f "${project_dir}/docker-compose.yml" ]]; then
        DOI_MODULES_SELECTED+=("container-security" "preview-env")
        _doi_log "Docker detected → container-security, preview-env"
    fi

    # Kubernetes detection
    if [[ -d "${project_dir}/k8s" ]] || [[ -d "${project_dir}/helm" ]] || [[ -d "${project_dir}/gitops" ]]; then
        DOI_MODULES_SELECTED+=("canary-analysis" "gitops")
        _doi_log "Kubernetes detected → canary-analysis, gitops"
    fi

    # API detection
    if [[ -d "${project_dir}/src/app/api" ]] || [[ -d "${project_dir}/api" ]]; then
        DOI_MODULES_SELECTED+=("rate-limit-test" "sla-monitor")
        _doi_log "API detected → rate-limit-test, sla-monitor"
    fi

    # CI/CD detection
    if [[ -d "${project_dir}/.github/workflows" ]]; then
        DOI_MODULES_SELECTED+=("dependency-update" "license-check")
        _doi_log "GitHub Actions detected → dependency-update, license-check"
    fi

    # Privacy/compliance signals
    if [[ -f "${project_dir}/prisma/schema.prisma" ]]; then
        local has_user_data=false
        if [[ -f "${project_dir}/prisma/schema.prisma" ]]; then
            if grep -qi "email\|phone\|address\|password" "${project_dir}/prisma/schema.prisma" 2>/dev/null; then
                has_user_data=true
            fi
        fi
        if [[ "$has_user_data" == "true" ]]; then
            DOI_MODULES_SELECTED+=("data-privacy" "compliance")
            _doi_log "User data in schema → data-privacy, compliance"
        fi
    fi

    # Feature flags / AB testing (if frontend detected)
    if [[ -d "${project_dir}/src/components" ]] || [[ -d "${project_dir}/src/app" ]]; then
        DOI_MODULES_SELECTED+=("feature-flags" "ab-testing")
        _doi_log "Frontend detected → feature-flags, ab-testing"
    fi

    # Cost management (cloud infra)
    if [[ -d "${project_dir}/infra" ]] || [[ -d "${project_dir}/terraform" ]] || [[ -d "${project_dir}/aws-infra" ]]; then
        DOI_MODULES_SELECTED+=("cost-alert" "multi-region")
        _doi_log "Cloud infra detected → cost-alert, multi-region"
    fi

    # Incident response (production apps)
    if [[ -f "${project_dir}/vercel.json" ]] || [[ -f "${project_dir}/fly.toml" ]] || [[ -d "${project_dir}/infra" ]]; then
        DOI_MODULES_SELECTED+=("incident-response")
        _doi_log "Production deploy detected → incident-response"
    fi

    # Deduplicate
    local unique_modules=()
    declare -A seen
    for m in "${DOI_MODULES_SELECTED[@]}"; do
        if [[ -z "${seen[$m]:-}" ]]; then
            unique_modules+=("$m")
            seen["$m"]=1
        fi
    done
    DOI_MODULES_SELECTED=("${unique_modules[@]}")

    _doi_ok "Selected ${#DOI_MODULES_SELECTED[@]} DevOps modules"
}

# =============================================================================
# Orchestrate
# =============================================================================
_doi_orchestrate() {
    local project_dir="${1:-.}"

    _doi_log "Orchestrating ${#DOI_MODULES_SELECTED[@]} DevOps modules..."

    if [[ ${#DOI_MODULES_SELECTED[@]} -eq 0 ]]; then
        _doi_warn "No modules selected. Run _doi_select_devops_modules first."
        return 1
    fi

    # Execution order (dependencies first)
    local ordered_phases=(
        "health-check"
        "observability"
        "rollback"
        "container-security"
        "rate-limit-test"
        "data-privacy"
        "compliance"
        "license-check"
        "dependency-update"
        "sla-monitor"
        "incident-response"
        "cost-alert"
        "feature-flags"
        "ab-testing"
        "preview-env"
        "canary-analysis"
        "gitops"
        "multi-region"
        "deploy-dashboard"
    )

    for module in "${ordered_phases[@]}"; do
        # Check if module is selected
        local selected=false
        for sel in "${DOI_MODULES_SELECTED[@]}"; do
            [[ "$sel" == "$module" ]] && selected=true && break
        done
        [[ "$selected" != "true" ]] && continue

        local info="${DOI_DEVOPS_MODULES[$module]:-}"
        [[ -z "$info" ]] && continue

        local version="${info%%:*}"
        local remaining="${info#*:}"
        local entry_fn="${remaining%%:*}"
        local prefix="${remaining##*:}"

        _doi_log "Executing ${module} (${version})..."

        if type -t "$entry_fn" &>/dev/null; then
            if "$entry_fn" "$project_dir" 2>/dev/null; then
                DOI_MODULES_EXECUTED=$((DOI_MODULES_EXECUTED + 1))
                _doi_ok "${module} completed"
            else
                _doi_warn "${module} had issues (continuing)"
            fi
        else
            _doi_warn "${module} function not available: ${entry_fn}"
        fi
    done

    # Calculate maturity score
    _doi_calculate_maturity

    _doi_ok "DevOps orchestration complete: ${DOI_MODULES_EXECUTED}/${#DOI_MODULES_SELECTED[@]} modules executed"
}

# =============================================================================
# Calculate DevOps Maturity
# =============================================================================
_doi_calculate_maturity() {
    local total_possible=${#DOI_DEVOPS_MODULES[@]}
    local executed=${DOI_MODULES_EXECUTED}

    # Base score from module coverage
    local coverage_score=0
    if [[ $total_possible -gt 0 ]]; then
        coverage_score=$((executed * 100 / total_possible))
    fi

    # Category bonuses
    local category_score=0
    local categories_covered=0
    local total_categories=6

    # Check each category
    local has_deploy=false has_security=false has_monitoring=false
    local has_testing=false has_compliance=false has_infra=false

    for m in "${DOI_MODULES_SELECTED[@]}"; do
        case "$m" in
            canary-analysis|rollback|preview-env|gitops) has_deploy=true ;;
            container-security|data-privacy) has_security=true ;;
            health-check|observability|sla-monitor|incident-response) has_monitoring=true ;;
            rate-limit-test|ab-testing) has_testing=true ;;
            compliance|license-check) has_compliance=true ;;
            multi-region|cost-alert) has_infra=true ;;
        esac
    done

    [[ "$has_deploy" == "true" ]] && categories_covered=$((categories_covered + 1))
    [[ "$has_security" == "true" ]] && categories_covered=$((categories_covered + 1))
    [[ "$has_monitoring" == "true" ]] && categories_covered=$((categories_covered + 1))
    [[ "$has_testing" == "true" ]] && categories_covered=$((categories_covered + 1))
    [[ "$has_compliance" == "true" ]] && categories_covered=$((categories_covered + 1))
    [[ "$has_infra" == "true" ]] && categories_covered=$((categories_covered + 1))

    category_score=$((categories_covered * 100 / total_categories))

    # Weighted final score
    DOI_MATURITY_SCORE=$(( (coverage_score * 60 + category_score * 40) / 100 ))
}

# =============================================================================
# Report
# =============================================================================
_doi_report() {
    echo -e "\n  ${BOLD}════════════════════════════════════════════════${NC}"
    echo -e "  ${BOLD}  DevOps Integration Engine v${DOI_VERSION}${NC}"
    echo -e "  ${BOLD}════════════════════════════════════════════════${NC}"
    echo -e "  利用可能モジュール : ${#DOI_DEVOPS_MODULES[@]}"
    echo -e "  選択モジュール     : ${#DOI_MODULES_SELECTED[@]}"
    echo -e "  実行完了           : ${DOI_MODULES_EXECUTED}"
    echo -e "  生成ファイル数     : ${DOI_GENERATED}"
    echo -e "  エラー             : ${DOI_ERRORS}"
    echo -e "  DevOps成熟度スコア : ${DOI_MATURITY_SCORE}/100"

    if [[ ${#DOI_MODULES_SELECTED[@]} -gt 0 ]]; then
        echo -e "\n  ${BOLD}選択モジュール:${NC}"
        for m in "${DOI_MODULES_SELECTED[@]}"; do
            local info="${DOI_DEVOPS_MODULES[$m]:-}"
            local version="${info%%:*}"
            echo -e "    - [${version}] ${m}"
        done
    fi

    # Maturity rating
    local rating="初級"
    if [[ $DOI_MATURITY_SCORE -ge 90 ]]; then rating="エリート"
    elif [[ $DOI_MATURITY_SCORE -ge 70 ]]; then rating="上級"
    elif [[ $DOI_MATURITY_SCORE -ge 50 ]]; then rating="中級"
    fi
    echo -e "\n  DevOps成熟度レベル : ${BOLD}${rating}${NC}"

    if [[ ${#DOI_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "\n  生成ファイル:"
        for f in "${DOI_FILES_CREATED[@]}"; do
            echo -e "    - ${f}"
        done
    fi

    echo -e "  ${BOLD}════════════════════════════════════════════════${NC}"
}

doi_score() {
    echo "${DOI_MATURITY_SCORE:-50}"
}

# =============================================================================
# Prompt generation for Claude Code integration
# =============================================================================
_doi_generate_devops_prompt() {
    local project_dir="${1:-.}"

    local prompt="DevOps Integration Prompt (v${DOI_VERSION}):\n"
    prompt+="Selected modules: ${DOI_MODULES_SELECTED[*]}\n\n"
    prompt+="Generate the following DevOps infrastructure:\n"

    for m in "${DOI_MODULES_SELECTED[@]}"; do
        case "$m" in
            health-check)      prompt+="- Health check endpoints (/health, /health/ready, /health/live)\n" ;;
            observability)     prompt+="- OpenTelemetry tracing + structured logging + Prometheus metrics\n" ;;
            rollback)          prompt+="- Automatic rollback with issue detection\n" ;;
            container-security) prompt+="- Secure Dockerfile (multi-stage, non-root, distroless)\n" ;;
            gitops)            prompt+="- GitOps with Kustomize overlays (staging/production)\n" ;;
            canary-analysis)   prompt+="- Canary deployment with progressive rollout\n" ;;
            feature-flags)     prompt+="- Feature flag system with percentage/user-list support\n" ;;
            incident-response) prompt+="- Incident detection with Slack notification\n" ;;
            compliance)        prompt+="- GDPR/SOC2 compliance scanning\n" ;;
            *)                 prompt+="- ${m} module\n" ;;
        esac
    done

    echo -e "$prompt"
}

# =============================================================================
# v59.0: Module Registry
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "devops-integration" --version "370.0" \
        --description "v351-v369全DevOpsモジュール統合オーケストレーター" \
        --init "_doi_init" --report "_doi_report" --score "doi_score" \
        --enable-var "ENABLE_DEVOPS_INTEGRATION" --cli-flags "--devops-integration:--no-devops-integration"
fi

# v2003.1: source時のexit codeを確実に0にする
true
