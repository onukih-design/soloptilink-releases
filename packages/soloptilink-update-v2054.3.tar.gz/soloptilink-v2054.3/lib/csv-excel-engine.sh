#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v298.0 - CSV/Excel Engine
# =============================================================================
# CSV/Excelインポート・エクスポート自動生成。バリデーション付きCSVインポート、
# CSVエクスポート、Excelエクスポートを生成する。
#
# 機能一覧:
#   _cee_generate_csv_import   - CSVインポート(バリデーション付き)
#   _cee_generate_csv_export   - CSVエクスポート
#   _cee_generate_excel_export - Excelエクスポート
#
# 全globals: CEE_ prefix
# =============================================================================

[[ -n "${_CEE_LOADED:-}" ]] && return 0; _CEE_LOADED=1

declare -g CEE_VERSION="298.0"
declare -g CEE_GENERATED=0
declare -g CEE_ERRORS=0
declare -g CEE_FILES_WRITTEN=0

cee_init() { CEE_GENERATED=0; CEE_ERRORS=0; CEE_FILES_WRITTEN=0; return 0; }

_cee_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then CEE_FILES_WRITTEN=$((CEE_FILES_WRITTEN + 1)); echo "  [cee] wrote: $filepath" >&2
    else CEE_ERRORS=$((CEE_ERRORS + 1)); fi
}

_cee_log() { echo -e "  ${GREEN:-\033[0;32m}[CEE]${NC:-\033[0m} $*" >&2; }

# =============================================================================
# _cee_generate_csv_import
# =============================================================================
_cee_generate_csv_import() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _cee_log "Generating CSV import with validation..."

    local import_ts
    import_ts=$(cat <<'IMPEOF'
// =============================================================================
// CSV Import with Validation
// Parses CSV, validates rows, reports errors, supports streaming
// =============================================================================
import { z, ZodType } from 'zod';

export interface CsvImportOptions<T> {
  schema: ZodType<T>;
  delimiter?: string;
  skipHeader?: boolean;
  maxRows?: number;
  onRow?: (row: T, index: number) => Promise<void>;
  onError?: (error: string, rowIndex: number, raw: string[]) => void;
}

export interface CsvImportResult<T> {
  totalRows: number;
  validRows: number;
  invalidRows: number;
  data: T[];
  errors: Array<{ row: number; error: string; raw: string[] }>;
}

export async function importCsv<T>(
  content: string,
  options: CsvImportOptions<T>
): Promise<CsvImportResult<T>> {
  const delimiter = options.delimiter || ',';
  const lines = content.split('\n').filter((l) => l.trim());
  const headers = lines[0].split(delimiter).map((h) => h.trim().replace(/^"|"$/g, ''));
  const dataLines = options.skipHeader !== false ? lines.slice(1) : lines;

  const result: CsvImportResult<T> = { totalRows: 0, validRows: 0, invalidRows: 0, data: [], errors: [] };

  for (let i = 0; i < dataLines.length; i++) {
    if (options.maxRows && result.totalRows >= options.maxRows) break;
    result.totalRows++;

    const line = dataLines[i];
    const values = parseCsvLine(line, delimiter);
    const rowObj: Record<string, string> = {};

    for (let j = 0; j < headers.length; j++) {
      rowObj[headers[j]] = values[j]?.trim() || '';
    }

    const parsed = options.schema.safeParse(rowObj);
    if (parsed.success) {
      result.validRows++;
      result.data.push(parsed.data);
      if (options.onRow) await options.onRow(parsed.data, i);
    } else {
      result.invalidRows++;
      const errorMsg = parsed.error.issues.map((e) => `${e.path.join('.')}: ${e.message}`).join('; ');
      result.errors.push({ row: i + 1, error: errorMsg, raw: values });
      options.onError?.(errorMsg, i + 1, values);
    }
  }

  return result;
}

function parseCsvLine(line: string, delimiter: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      if (inQuotes && line[i + 1] === '"') { current += '"'; i++; }
      else { inQuotes = !inQuotes; }
    } else if (char === delimiter && !inQuotes) {
      result.push(current); current = '';
    } else {
      current += char;
    }
  }
  result.push(current);
  return result;
}

// --- Predefined Schemas ---
export const UserImportSchema = z.object({
  email: z.string().email(),
  name: z.string().min(1),
  role: z.enum(['admin', 'user', 'moderator']).default('user'),
});

export const ProductImportSchema = z.object({
  name: z.string().min(1),
  price: z.string().transform((v) => parseFloat(v)).pipe(z.number().positive()),
  stock: z.string().transform((v) => parseInt(v)).pipe(z.number().int().min(0)),
  category: z.string().optional(),
});
IMPEOF
)
    _cee_write_file "${project_dir}/src/lib/csv/import.ts" "$import_ts"
    CEE_GENERATED=$((CEE_GENERATED + 1))
    return 0
}

# =============================================================================
# _cee_generate_csv_export
# =============================================================================
_cee_generate_csv_export() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _cee_log "Generating CSV export..."

    local export_ts
    export_ts=$(cat <<'EXPEOF'
// =============================================================================
// CSV Export - Convert data arrays to CSV with proper escaping
// =============================================================================

export interface CsvExportOptions {
  delimiter?: string;
  includeHeader?: boolean;
  columns?: Array<{ key: string; label: string; format?: (value: unknown) => string }>;
  bom?: boolean;
}

export function exportToCsv<T extends Record<string, unknown>>(
  data: T[],
  options: CsvExportOptions = {}
): string {
  const delimiter = options.delimiter || ',';
  const includeHeader = options.includeHeader !== false;

  // Determine columns
  let columns = options.columns;
  if (!columns && data.length > 0) {
    columns = Object.keys(data[0]).map((key) => ({ key, label: key }));
  }
  if (!columns) return '';

  const rows: string[] = [];

  // BOM for Excel compatibility
  const bom = options.bom !== false ? '\uFEFF' : '';

  // Header
  if (includeHeader) {
    rows.push(columns.map((c) => escapeCsvField(c.label, delimiter)).join(delimiter));
  }

  // Data rows
  for (const row of data) {
    const fields = columns.map((col) => {
      const value = row[col.key];
      const formatted = col.format ? col.format(value) : String(value ?? '');
      return escapeCsvField(formatted, delimiter);
    });
    rows.push(fields.join(delimiter));
  }

  return bom + rows.join('\n');
}

function escapeCsvField(field: string, delimiter: string): string {
  if (field.includes(delimiter) || field.includes('"') || field.includes('\n')) {
    return `"${field.replace(/"/g, '""')}"`;
  }
  return field;
}

// --- Stream Export for large datasets ---
export async function* exportToCsvStream<T extends Record<string, unknown>>(
  dataSource: AsyncIterable<T>,
  columns: Array<{ key: string; label: string }>,
  delimiter = ','
): AsyncGenerator<string> {
  // Header
  yield columns.map((c) => escapeCsvField(c.label, delimiter)).join(delimiter) + '\n';

  // Rows
  for await (const row of dataSource) {
    const fields = columns.map((col) => escapeCsvField(String(row[col.key] ?? ''), delimiter));
    yield fields.join(delimiter) + '\n';
  }
}
EXPEOF
)
    _cee_write_file "${project_dir}/src/lib/csv/export.ts" "$export_ts"
    CEE_GENERATED=$((CEE_GENERATED + 1))
    return 0
}

# =============================================================================
# _cee_generate_excel_export
# =============================================================================
_cee_generate_excel_export() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _cee_log "Generating Excel export..."

    local excel_ts
    excel_ts=$(cat <<'XLEOF'
// =============================================================================
// Excel Export - Generate .xlsx files with formatting
// Uses ExcelJS library
// =============================================================================

export interface ExcelColumn {
  key: string;
  header: string;
  width?: number;
  style?: { numFmt?: string; font?: { bold?: boolean; color?: { argb: string } } };
}

export interface ExcelExportOptions {
  sheetName?: string;
  columns: ExcelColumn[];
  freezeFirstRow?: boolean;
  autoFilter?: boolean;
}

export async function exportToExcel<T extends Record<string, unknown>>(
  data: T[],
  options: ExcelExportOptions
): Promise<Buffer> {
  const ExcelJS = await import('exceljs');
  const workbook = new ExcelJS.Workbook();
  workbook.creator = process.env.APP_NAME || 'App';
  workbook.created = new Date();

  const sheet = workbook.addWorksheet(options.sheetName || 'Sheet1');

  // Columns
  sheet.columns = options.columns.map((col) => ({
    header: col.header,
    key: col.key,
    width: col.width || 15,
    style: col.style ? { numFmt: col.style.numFmt, font: col.style.font } : undefined,
  }));

  // Header styling
  const headerRow = sheet.getRow(1);
  headerRow.font = { bold: true, color: { argb: 'FFFFFFFF' } };
  headerRow.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FF2563EB' } };
  headerRow.alignment = { vertical: 'middle', horizontal: 'center' };
  headerRow.height = 25;

  // Data
  for (const row of data) {
    const values: Record<string, unknown> = {};
    for (const col of options.columns) { values[col.key] = row[col.key]; }
    sheet.addRow(values);
  }

  // Freeze header
  if (options.freezeFirstRow !== false) {
    sheet.views = [{ state: 'frozen', ySplit: 1 }];
  }

  // Auto filter
  if (options.autoFilter !== false) {
    sheet.autoFilter = { from: { row: 1, column: 1 }, to: { row: data.length + 1, column: options.columns.length } };
  }

  // Alternate row colors
  for (let i = 2; i <= data.length + 1; i++) {
    if (i % 2 === 0) {
      const row = sheet.getRow(i);
      row.fill = { type: 'pattern', pattern: 'solid', fgColor: { argb: 'FFF8F9FA' } };
    }
  }

  const buffer = await workbook.xlsx.writeBuffer();
  return Buffer.from(buffer);
}

// --- Response Helper ---
export function excelResponse(buffer: Buffer, filename: string): Response {
  return new Response(buffer, {
    headers: {
      'Content-Type': 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      'Content-Disposition': `attachment; filename="${filename}"`,
      'Content-Length': buffer.length.toString(),
    },
  });
}
XLEOF
)
    _cee_write_file "${project_dir}/src/lib/csv/excel-export.ts" "$excel_ts"
    CEE_GENERATED=$((CEE_GENERATED + 1))
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
cee_report() {
    echo -e "\n  ${BOLD:-}=== csv-excel-engine v${CEE_VERSION} ===${NC:-}"
    echo -e "  生成数: ${CEE_GENERATED}"; echo -e "  エラー: ${CEE_ERRORS}"
}

cee_score() {
    if [[ ${CEE_GENERATED} -ge 3 ]] && [[ ${CEE_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${CEE_GENERATED} -gt 0 ]] && [[ ${CEE_ERRORS} -eq 0 ]]; then echo "85"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "csv-excel-engine" --version "${CEE_VERSION}" \
        --description "CSVインポート(バリデーション)×CSVエクスポート×Excelエクスポート" \
        --init "cee_init" --report "cee_report" --score "cee_score" \
        --enable-var "ENABLE_CSV_EXCEL" --cli-flags "--csv-excel:--no-csv-excel"
fi

# v2003.1: source時のexit codeを確実に0にする
true
