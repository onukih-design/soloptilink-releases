#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v244.0 - Performance Budget Engine
# =============================================================================
# パフォーマンスバジェットの設定・監視・最適化提案。
# Core Web Vitals (LCP, FID, CLS) + バンドルサイズのバジェット管理。
#
# 機能:
#   - パフォーマンスバジェット設定（bundle size, LCP, FID, CLS）
#   - バジェット超過チェック
#   - バンドル最適化提案
#   - パフォーマンスバジェットレポート生成
#
# 全globals: PBE_ prefix
# =============================================================================

[[ -n "${_PERFORMANCE_BUDGET_ENGINE_LOADED:-}" ]] && return 0
_PERFORMANCE_BUDGET_ENGINE_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g PBE_VERSION="244.0"
declare -g PBE_INITIALIZED=false
declare -g PBE_PROJECT_DIR=""
declare -g PBE_VIOLATIONS=0
declare -g PBE_CHECKS_RUN=0
declare -g PBE_OPTIMIZATIONS_SUGGESTED=0
declare -g PBE_LOG_PREFIX="[PBE]"

# バジェットデフォルト値
declare -g PBE_BUDGET_JS_SIZE_KB=250        # JS バンドルサイズ上限 (KB)
declare -g PBE_BUDGET_CSS_SIZE_KB=50         # CSS サイズ上限 (KB)
declare -g PBE_BUDGET_IMAGE_SIZE_KB=200      # 画像サイズ上限 (KB/枚)
declare -g PBE_BUDGET_TOTAL_SIZE_KB=1000     # ページ総サイズ上限 (KB)
declare -g PBE_BUDGET_LCP_MS=2500            # LCP 上限 (ms)
declare -g PBE_BUDGET_FID_MS=100             # FID 上限 (ms)
declare -g PBE_BUDGET_CLS=0.1               # CLS 上限
declare -g PBE_BUDGET_TTFB_MS=800            # TTFB 上限 (ms)
declare -g PBE_BUDGET_FCP_MS=1800            # FCP 上限 (ms)

# =============================================================================
# ログユーティリティ
# =============================================================================
_pbe_log() { echo -e "  ${CLR_CYAN:-\033[0;36m}${PBE_LOG_PREFIX}${CLR_NC:-\033[0m} $*" >&2; }
_pbe_success() { echo -e "  ${CLR_GREEN:-\033[0;32m}${PBE_LOG_PREFIX} OK${CLR_NC:-\033[0m} $*" >&2; }
_pbe_warn() { echo -e "  ${CLR_YELLOW:-\033[0;33m}${PBE_LOG_PREFIX} WARN${CLR_NC:-\033[0m} $*" >&2; }
_pbe_error() { echo -e "  ${CLR_RED:-\033[0;31m}${PBE_LOG_PREFIX} ERROR${CLR_NC:-\033[0m} $*" >&2; }

# =============================================================================
# 初期化
# =============================================================================
pbe_init() {
    PBE_INITIALIZED=true
    PBE_VIOLATIONS=0
    PBE_CHECKS_RUN=0
    PBE_OPTIMIZATIONS_SUGGESTED=0
    PBE_PROJECT_DIR="${PROJECT_DIR:-.}"
    return 0
}

# =============================================================================
# バジェット設定
# =============================================================================
# パフォーマンスバジェットをカスタム値で設定する。
# 設定ファイルまたは引数から読み込み。
#
# 使い方: _pbe_set_budgets [--js-kb N] [--css-kb N] [--lcp-ms N] [--fid-ms N] [--cls N]
# =============================================================================
_pbe_set_budgets() {
    [[ "$PBE_INITIALIZED" != "true" ]] && { _pbe_error "未初期化"; return 1; }

    while [[ $# -gt 0 ]]; do
        case "$1" in
            --js-kb)       PBE_BUDGET_JS_SIZE_KB="$2"; shift 2 ;;
            --css-kb)      PBE_BUDGET_CSS_SIZE_KB="$2"; shift 2 ;;
            --image-kb)    PBE_BUDGET_IMAGE_SIZE_KB="$2"; shift 2 ;;
            --total-kb)    PBE_BUDGET_TOTAL_SIZE_KB="$2"; shift 2 ;;
            --lcp-ms)      PBE_BUDGET_LCP_MS="$2"; shift 2 ;;
            --fid-ms)      PBE_BUDGET_FID_MS="$2"; shift 2 ;;
            --cls)         PBE_BUDGET_CLS="$2"; shift 2 ;;
            --ttfb-ms)     PBE_BUDGET_TTFB_MS="$2"; shift 2 ;;
            --fcp-ms)      PBE_BUDGET_FCP_MS="$2"; shift 2 ;;
            --preset)
                case "$2" in
                    strict)
                        PBE_BUDGET_JS_SIZE_KB=150
                        PBE_BUDGET_CSS_SIZE_KB=30
                        PBE_BUDGET_LCP_MS=1500
                        PBE_BUDGET_FID_MS=50
                        PBE_BUDGET_CLS="0.05"
                        ;;
                    moderate)
                        PBE_BUDGET_JS_SIZE_KB=300
                        PBE_BUDGET_CSS_SIZE_KB=60
                        PBE_BUDGET_LCP_MS=2500
                        PBE_BUDGET_FID_MS=100
                        PBE_BUDGET_CLS="0.1"
                        ;;
                    relaxed)
                        PBE_BUDGET_JS_SIZE_KB=500
                        PBE_BUDGET_CSS_SIZE_KB=100
                        PBE_BUDGET_LCP_MS=4000
                        PBE_BUDGET_FID_MS=300
                        PBE_BUDGET_CLS="0.25"
                        ;;
                esac
                shift 2 ;;
            *) shift ;;
        esac
    done

    _pbe_success "バジェット設定: JS=${PBE_BUDGET_JS_SIZE_KB}KB, CSS=${PBE_BUDGET_CSS_SIZE_KB}KB, LCP=${PBE_BUDGET_LCP_MS}ms, FID=${PBE_BUDGET_FID_MS}ms, CLS=${PBE_BUDGET_CLS}"
    return 0
}

# =============================================================================
# バジェットチェック
# =============================================================================
# 現在のプロジェクトがバジェットを満たしているか検査。
# .next/analyze, build 出力、ソースコードを解析。
#
# 使い方: _pbe_check_budgets [project_dir]
# =============================================================================
_pbe_check_budgets() {
    local project_dir="${1:-${PBE_PROJECT_DIR}}"
    local violations=0

    [[ "$PBE_INITIALIZED" != "true" ]] && { _pbe_error "未初期化"; return 1; }

    _pbe_log "パフォーマンスバジェットチェック開始"

    # 1. JS バンドルサイズチェック
    PBE_CHECKS_RUN=$((PBE_CHECKS_RUN + 1))
    local next_dir="${project_dir}/.next"
    if [[ -d "${next_dir}/static/chunks" ]]; then
        local total_js_kb=0
        while IFS= read -r f; do
            local size_bytes
            size_bytes=$(wc -c < "$f" 2>/dev/null || echo 0)
            local size_kb=$(( (size_bytes + 1023) / 1024 ))
            total_js_kb=$((total_js_kb + size_kb))

            # 個別チャンクの巨大ファイル検出
            if [[ $size_kb -gt $PBE_BUDGET_JS_SIZE_KB ]]; then
                _pbe_warn "巨大JSチャンク: $(basename "$f") = ${size_kb}KB (上限: ${PBE_BUDGET_JS_SIZE_KB}KB)"
                violations=$((violations + 1))
            fi
        done < <(find "${next_dir}/static/chunks" -name '*.js' -type f 2>/dev/null)

        if [[ $total_js_kb -gt $((PBE_BUDGET_TOTAL_SIZE_KB)) ]]; then
            _pbe_warn "JS 総サイズ超過: ${total_js_kb}KB (上限: ${PBE_BUDGET_TOTAL_SIZE_KB}KB)"
            violations=$((violations + 1))
        else
            _pbe_success "JS バンドル: ${total_js_kb}KB (上限: ${PBE_BUDGET_TOTAL_SIZE_KB}KB)"
        fi
    else
        _pbe_log "ビルド出力なし (.next/static/chunks) - ソース解析に切り替え"
    fi

    # 2. CSS サイズチェック
    PBE_CHECKS_RUN=$((PBE_CHECKS_RUN + 1))
    if [[ -d "${next_dir}/static/css" ]]; then
        local total_css_kb=0
        while IFS= read -r f; do
            local size_bytes
            size_bytes=$(wc -c < "$f" 2>/dev/null || echo 0)
            local size_kb=$(( (size_bytes + 1023) / 1024 ))
            total_css_kb=$((total_css_kb + size_kb))
        done < <(find "${next_dir}/static/css" -name '*.css' -type f 2>/dev/null)

        if [[ $total_css_kb -gt $PBE_BUDGET_CSS_SIZE_KB ]]; then
            _pbe_warn "CSS サイズ超過: ${total_css_kb}KB (上限: ${PBE_BUDGET_CSS_SIZE_KB}KB)"
            violations=$((violations + 1))
        else
            _pbe_success "CSS: ${total_css_kb}KB (上限: ${PBE_BUDGET_CSS_SIZE_KB}KB)"
        fi
    fi

    # 3. 画像サイズチェック
    PBE_CHECKS_RUN=$((PBE_CHECKS_RUN + 1))
    if [[ -d "${project_dir}/public" ]]; then
        local large_images=0
        while IFS= read -r f; do
            local size_bytes
            size_bytes=$(wc -c < "$f" 2>/dev/null || echo 0)
            local size_kb=$(( (size_bytes + 1023) / 1024 ))
            if [[ $size_kb -gt $PBE_BUDGET_IMAGE_SIZE_KB ]]; then
                _pbe_warn "大きな画像: $(basename "$f") = ${size_kb}KB (上限: ${PBE_BUDGET_IMAGE_SIZE_KB}KB)"
                large_images=$((large_images + 1))
            fi
        done < <(find "${project_dir}/public" -type f \( -name '*.png' -o -name '*.jpg' -o -name '*.jpeg' -o -name '*.gif' -o -name '*.webp' \) 2>/dev/null)

        if [[ $large_images -gt 0 ]]; then
            violations=$((violations + large_images))
        else
            _pbe_success "画像サイズ: 全て ${PBE_BUDGET_IMAGE_SIZE_KB}KB 以下"
        fi
    fi

    # 4. ソースコード重量分析
    PBE_CHECKS_RUN=$((PBE_CHECKS_RUN + 1))
    local heavy_deps=0
    if [[ -f "${project_dir}/package.json" ]]; then
        # 重いライブラリの検出
        local heavy_libs=("moment" "lodash" "jquery" "rxjs" "three" "chart.js")
        for lib in "${heavy_libs[@]}"; do
            if grep -q "\"${lib}\"" "${project_dir}/package.json" 2>/dev/null; then
                _pbe_warn "重い依存: ${lib}（軽量代替を検討）"
                heavy_deps=$((heavy_deps + 1))
            fi
        done
    fi

    if [[ $heavy_deps -gt 0 ]]; then
        violations=$((violations + heavy_deps))
    fi

    PBE_VIOLATIONS=$((PBE_VIOLATIONS + violations))

    if [[ $violations -eq 0 ]]; then
        _pbe_success "バジェットチェック完了: 全バジェット準拠"
    else
        _pbe_warn "バジェットチェック完了: ${violations}件の超過"
    fi

    echo "$violations"
    return 0
}

# =============================================================================
# バンドル最適化提案
# =============================================================================
_pbe_optimize_bundle() {
    local project_dir="${1:-${PBE_PROJECT_DIR}}"
    local suggestions=0

    [[ "$PBE_INITIALIZED" != "true" ]] && { _pbe_error "未初期化"; return 1; }

    _pbe_log "バンドル最適化分析中"

    # package.json 分析
    if [[ -f "${project_dir}/package.json" ]]; then
        # moment → date-fns/dayjs
        if grep -q '"moment"' "${project_dir}/package.json" 2>/dev/null; then
            _pbe_log "提案: moment.js → date-fns or dayjs に置換（-60KB gzipped）"
            suggestions=$((suggestions + 1))
        fi

        # lodash → lodash-es or 個別import
        if grep -q '"lodash"' "${project_dir}/package.json" 2>/dev/null; then
            _pbe_log "提案: lodash → lodash-es + 個別 import で tree-shaking 有効化"
            suggestions=$((suggestions + 1))
        fi

        # axios → fetch API
        if grep -q '"axios"' "${project_dir}/package.json" 2>/dev/null; then
            _pbe_log "提案: axios → native fetch API（ブラウザ組込みで 0KB）"
            suggestions=$((suggestions + 1))
        fi
    fi

    # next.config チェック
    local next_config="${project_dir}/next.config.js"
    [[ ! -f "$next_config" ]] && next_config="${project_dir}/next.config.mjs"
    [[ ! -f "$next_config" ]] && next_config="${project_dir}/next.config.ts"

    if [[ -f "$next_config" ]]; then
        # バンドルアナライザー未設定
        if ! grep -q 'bundle-analyzer\|@next/bundle-analyzer' "$next_config" 2>/dev/null; then
            _pbe_log "提案: @next/bundle-analyzer を導入してバンドル可視化"
            suggestions=$((suggestions + 1))
        fi

        # 画像最適化未設定
        if ! grep -q 'images' "$next_config" 2>/dev/null; then
            _pbe_log "提案: next.config の images 設定で外部画像最適化を有効化"
            suggestions=$((suggestions + 1))
        fi
    fi

    # 動的 import の不足検出
    local pages_without_dynamic=0
    if [[ -d "${project_dir}/app" ]]; then
        while IFS= read -r -d '' f; do
            # 重いコンポーネントの static import 検出
            if grep -qP "import\s+.*(?:Chart|Editor|Map|Calendar|DataGrid)" "$f" 2>/dev/null; then
                if ! grep -qP "(?:dynamic|lazy|React\.lazy)" "$f" 2>/dev/null; then
                    local bn
                    bn=$(basename "$f")
                    _pbe_log "提案: ${bn} - 重いコンポーネントを dynamic import に変更"
                    pages_without_dynamic=$((pages_without_dynamic + 1))
                fi
            fi
        done < <(find "${project_dir}/app" -name '*.tsx' -type f -print0 2>/dev/null)
    fi

    suggestions=$((suggestions + pages_without_dynamic))
    PBE_OPTIMIZATIONS_SUGGESTED=$((PBE_OPTIMIZATIONS_SUGGESTED + suggestions))

    _pbe_success "最適化提案: ${suggestions}件"
    echo "$suggestions"
    return 0
}

# =============================================================================
# パフォーマンスバジェットレポート生成
# =============================================================================
_pbe_generate_report() {
    local output_file="${1:-${PBE_PROJECT_DIR}/perf-budget-report.json}"

    [[ "$PBE_INITIALIZED" != "true" ]] && { _pbe_error "未初期化"; return 1; }

    mkdir -p "$(dirname "$output_file")" 2>/dev/null || true

    local status="PASS"
    [[ $PBE_VIOLATIONS -gt 0 ]] && status="FAIL"

    cat > "$output_file" <<EOF
{
  "report": "Performance Budget Report",
  "version": "${PBE_VERSION}",
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "status": "${status}",
  "budgets": {
    "js_size_kb": ${PBE_BUDGET_JS_SIZE_KB},
    "css_size_kb": ${PBE_BUDGET_CSS_SIZE_KB},
    "image_size_kb": ${PBE_BUDGET_IMAGE_SIZE_KB},
    "total_size_kb": ${PBE_BUDGET_TOTAL_SIZE_KB},
    "lcp_ms": ${PBE_BUDGET_LCP_MS},
    "fid_ms": ${PBE_BUDGET_FID_MS},
    "cls": ${PBE_BUDGET_CLS},
    "ttfb_ms": ${PBE_BUDGET_TTFB_MS},
    "fcp_ms": ${PBE_BUDGET_FCP_MS}
  },
  "results": {
    "checks_run": ${PBE_CHECKS_RUN},
    "violations": ${PBE_VIOLATIONS},
    "optimizations_suggested": ${PBE_OPTIMIZATIONS_SUGGESTED}
  }
}
EOF

    if [[ -f "$output_file" ]]; then
        _pbe_success "レポート生成完了: ${output_file}"
        return 0
    fi
    return 1
}

# =============================================================================
# バジェット設定ファイル生成
# =============================================================================
_pbe_generate_config() {
    local output_file="${1:-${PBE_PROJECT_DIR}/perf-budget.json}"

    [[ "$PBE_INITIALIZED" != "true" ]] && { _pbe_error "未初期化"; return 1; }

    mkdir -p "$(dirname "$output_file")" 2>/dev/null || true

    cat > "$output_file" <<EOF
{
  "budgets": {
    "javascript": { "maxSize": "${PBE_BUDGET_JS_SIZE_KB}KB" },
    "css": { "maxSize": "${PBE_BUDGET_CSS_SIZE_KB}KB" },
    "image": { "maxSize": "${PBE_BUDGET_IMAGE_SIZE_KB}KB" },
    "total": { "maxSize": "${PBE_BUDGET_TOTAL_SIZE_KB}KB" }
  },
  "coreWebVitals": {
    "LCP": { "max": ${PBE_BUDGET_LCP_MS}, "unit": "ms" },
    "FID": { "max": ${PBE_BUDGET_FID_MS}, "unit": "ms" },
    "CLS": { "max": ${PBE_BUDGET_CLS} },
    "TTFB": { "max": ${PBE_BUDGET_TTFB_MS}, "unit": "ms" },
    "FCP": { "max": ${PBE_BUDGET_FCP_MS}, "unit": "ms" }
  }
}
EOF

    if [[ -f "$output_file" ]]; then
        _pbe_success "バジェット設定生成完了: ${output_file}"
        return 0
    fi
    return 1
}

# =============================================================================
# プロンプト注入
# =============================================================================
_pbe_inject_prompt() {
    cat <<PROMPT
## [PBE] パフォーマンスバジェットルール

### バンドルサイズ
- JS チャンク: ${PBE_BUDGET_JS_SIZE_KB}KB 以下
- CSS 総量: ${PBE_BUDGET_CSS_SIZE_KB}KB 以下
- 画像: ${PBE_BUDGET_IMAGE_SIZE_KB}KB/枚 以下

### Core Web Vitals
- LCP: ${PBE_BUDGET_LCP_MS}ms 以下
- FID: ${PBE_BUDGET_FID_MS}ms 以下
- CLS: ${PBE_BUDGET_CLS} 以下

### 最適化必須事項
- 重いライブラリは dynamic import
- Tree-shaking 有効な ESM import を使用
- 画像は next/image で最適化
- フォントは next/font で最適化
PROMPT
}

# =============================================================================
# レポート
# =============================================================================
pbe_report() {
    echo -e "\n  ${BOLD:-}--- Performance Budget Engine v${PBE_VERSION} ---${NC:-}"
    echo -e "  チェック実行数    : ${PBE_CHECKS_RUN}"
    echo -e "  バジェット超過    : ${PBE_VIOLATIONS}"
    echo -e "  最適化提案数      : ${PBE_OPTIMIZATIONS_SUGGESTED}"
}

pbe_report_json() {
    cat <<EOF
{"module":"performance-budget-engine","version":"${PBE_VERSION}","checks":${PBE_CHECKS_RUN},"violations":${PBE_VIOLATIONS},"optimizations":${PBE_OPTIMIZATIONS_SUGGESTED}}
EOF
}

pbe_score() {
    if [[ "$PBE_INITIALIZED" != "true" ]]; then echo 0; return; fi
    local score=100
    score=$((score - PBE_VIOLATIONS * 10))
    [[ $score -lt 0 ]] && score=0
    echo "$score"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "performance-budget-engine" \
        --version "244.0" \
        --description "Core Web Vitals + バンドルサイズのパフォーマンスバジェット管理" \
        --init "pbe_init" \
        --report "pbe_report" \
        --score "pbe_score" \
        --enable-var "ENABLE_PERF_BUDGET" \
        --cli-flags "--perf-budget:--no-perf-budget"
fi

# v2003.1: source時のexit codeを確実に0にする
true
