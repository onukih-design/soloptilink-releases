#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - CI/CD Generator
# =============================================================================
# CI/CDパイプライン自動生成エンジン。
# GitHub Actions、Dockerfile、docker-compose、pre-commit、リリース、デプロイ設定を
# プロジェクト構成に応じて自動生成する。
#
# 機能一覧:
#   ci_generate_github_actions   - GitHub Actionsワークフロー（lint/test/build/deploy）
#   ci_generate_dockerfile       - マルチステージDockerfile
#   ci_generate_docker_compose   - ローカル開発用docker-compose.yml
#   ci_generate_pre_commit       - Pre-commitフック（husky/lint-staged）
#   ci_generate_release_workflow - セマンティックバージョニング+リリース
#   ci_generate_deploy_config    - デプロイ設定（Vercel/Railway/Fly.io/AWS）
#   ci_inject_cicd_patterns      - Claudeプロンプトへのパターン注入
#
# 全globals: CIG_ prefix
# =============================================================================

[[ -n "${_CIG_LOADED:-}" ]] && return 0; _CIG_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g CIG_VERSION="140.0"
declare -g CIG_GENERATED=0
declare -g CIG_ERRORS=0
declare -g CIG_PHASE="cicd"
declare -g CIG_FILES_WRITTEN=0

# =============================================================================
# 初期化
# =============================================================================
ci_init() {
    CIG_GENERATED=0
    CIG_ERRORS=0
    CIG_FILES_WRITTEN=0
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} cicd-generator v${CIG_VERSION}"
    return 0
}

# =============================================================================
# ユーティリティ: ファイル安全書込
# =============================================================================
_cig_write_file() {
    local filepath="$1"
    local content="$2"
    local dir
    dir="$(dirname "$filepath")"
    mkdir -p "$dir" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then
        CIG_FILES_WRITTEN=$((CIG_FILES_WRITTEN + 1))
        echo "  [cicd] wrote: $filepath" >&2
    else
        echo "  [cicd] FAIL: $filepath" >&2
        CIG_ERRORS=$((CIG_ERRORS + 1))
    fi
}

# =============================================================================
# プラットフォーム検出
# =============================================================================
cig_detect_platform() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    if [[ -d "${project_dir}/.github" ]]; then echo 'github-actions'
    elif [[ -f "${project_dir}/.gitlab-ci.yml" ]]; then echo 'gitlab-ci'
    else echo 'github-actions'; fi
}

# =============================================================================
# テックスタック検出
# =============================================================================
_cig_detect_stack() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local stack="node"
    if [[ -f "${project_dir}/next.config.js" ]] || [[ -f "${project_dir}/next.config.mjs" ]] || [[ -f "${project_dir}/next.config.ts" ]]; then
        stack="nextjs"
    elif [[ -f "${project_dir}/nuxt.config.ts" ]]; then
        stack="nuxt"
    fi
    local has_prisma="false"
    [[ -f "${project_dir}/prisma/schema.prisma" ]] && has_prisma="true"
    local has_docker="false"
    [[ -f "${project_dir}/Dockerfile" ]] && has_docker="true"
    local pkg_manager="npm"
    [[ -f "${project_dir}/pnpm-lock.yaml" ]] && pkg_manager="pnpm"
    [[ -f "${project_dir}/yarn.lock" ]] && pkg_manager="yarn"
    [[ -f "${project_dir}/bun.lockb" ]] && pkg_manager="bun"
    echo "${stack}:${has_prisma}:${has_docker}:${pkg_manager}"
}

# =============================================================================
# ci_generate_github_actions - GitHub Actionsワークフロー生成
# =============================================================================
ci_generate_github_actions() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local stack_info
    stack_info="$(_cig_detect_stack "$project_dir")"
    local stack pkg_manager has_prisma
    stack="$(echo "$stack_info" | cut -d: -f1)"
    has_prisma="$(echo "$stack_info" | cut -d: -f2)"
    pkg_manager="$(echo "$stack_info" | cut -d: -f4)"

    local install_cmd="npm ci"
    local cache_path="~/.npm"
    case "$pkg_manager" in
        pnpm)  install_cmd="pnpm install --frozen-lockfile"; cache_path="~/.pnpm-store" ;;
        yarn)  install_cmd="yarn install --frozen-lockfile"; cache_path="~/.yarn/cache" ;;
        bun)   install_cmd="bun install --frozen-lockfile"; cache_path="~/.bun/install/cache" ;;
    esac

    local prisma_step=""
    if [[ "$has_prisma" == "true" ]]; then
        prisma_step="
      - name: Generate Prisma Client
        run: npx prisma generate

      - name: Validate Prisma Schema
        run: npx prisma validate"
    fi

    local ci_yml
    ci_yml=$(cat <<CIEOF
name: CI

on:
  push:
    branches: [main, develop]
  pull_request:
    branches: [main, develop]

concurrency:
  group: \${{ github.workflow }}-\${{ github.ref }}
  cancel-in-progress: true

env:
  NODE_ENV: test
  DATABASE_URL: postgresql://postgres:postgres@localhost:5432/test_db

jobs:
  lint:
    name: Lint & Type Check
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: '${pkg_manager}'

      - name: Install dependencies
        run: ${install_cmd}
${prisma_step}
      - name: ESLint
        run: npx eslint . --ext .ts,.tsx --max-warnings 0

      - name: Type Check
        run: npx tsc --noEmit

  test:
    name: Test (Node \${{ matrix.node-version }})
    runs-on: ubuntu-latest
    needs: lint
    strategy:
      matrix:
        node-version: [18, 20, 22]
    services:
      postgres:
        image: postgres:16-alpine
        env:
          POSTGRES_USER: postgres
          POSTGRES_PASSWORD: postgres
          POSTGRES_DB: test_db
        ports:
          - 5432:5432
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
      redis:
        image: redis:7-alpine
        ports:
          - 6379:6379
        options: >-
          --health-cmd "redis-cli ping"
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js \${{ matrix.node-version }}
        uses: actions/setup-node@v4
        with:
          node-version: \${{ matrix.node-version }}
          cache: '${pkg_manager}'

      - name: Install dependencies
        run: ${install_cmd}
${prisma_step}
      - name: Run Prisma Migrations
        if: \${{ ${has_prisma} }}
        run: npx prisma migrate deploy

      - name: Run Tests
        run: npx vitest run --coverage
        env:
          REDIS_URL: redis://localhost:6379

      - name: Upload Coverage
        if: matrix.node-version == 20
        uses: codecov/codecov-action@v4
        with:
          token: \${{ secrets.CODECOV_TOKEN }}
          files: ./coverage/lcov.info

  build:
    name: Build
    runs-on: ubuntu-latest
    needs: test
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: '${pkg_manager}'

      - name: Install dependencies
        run: ${install_cmd}
${prisma_step}
      - name: Build
        run: npm run build

      - name: Upload build artifact
        uses: actions/upload-artifact@v4
        with:
          name: build-output
          path: .next/
          retention-days: 7

  security:
    name: Security Audit
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: '${pkg_manager}'

      - name: Install dependencies
        run: ${install_cmd}

      - name: npm audit
        run: npm audit --audit-level=high
        continue-on-error: true

      - name: Check for secrets
        uses: trufflesecurity/trufflehog@main
        with:
          extra_args: --only-verified
CIEOF
)
    _cig_write_file "${project_dir}/.github/workflows/ci.yml" "$ci_yml"
    CIG_GENERATED=$((CIG_GENERATED + 1))
    return 0
}

# =============================================================================
# ci_generate_dockerfile - マルチステージDockerfile
# =============================================================================
ci_generate_dockerfile() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local stack_info
    stack_info="$(_cig_detect_stack "$project_dir")"
    local stack
    stack="$(echo "$stack_info" | cut -d: -f1)"

    local dockerfile
    dockerfile=$(cat <<'DKEOF'
# =============================================================================
# Multi-stage Dockerfile - SoloptiLinkAI Generated
# =============================================================================

# --- Stage 1: Dependencies ---
FROM node:20-alpine AS deps
RUN apk add --no-cache libc6-compat openssl
WORKDIR /app

COPY package.json package-lock.json* pnpm-lock.yaml* yarn.lock* ./
COPY prisma ./prisma/

RUN \
  if [ -f pnpm-lock.yaml ]; then corepack enable && pnpm install --frozen-lockfile; \
  elif [ -f yarn.lock ]; then yarn install --frozen-lockfile; \
  else npm ci; \
  fi

# --- Stage 2: Build ---
FROM node:20-alpine AS builder
RUN apk add --no-cache libc6-compat openssl
WORKDIR /app

COPY --from=deps /app/node_modules ./node_modules
COPY . .

RUN npx prisma generate 2>/dev/null || true

ENV NEXT_TELEMETRY_DISABLED=1
ENV NODE_ENV=production

RUN npm run build

# --- Stage 3: Production ---
FROM node:20-alpine AS runner
RUN apk add --no-cache libc6-compat openssl curl

WORKDIR /app

ENV NODE_ENV=production
ENV NEXT_TELEMETRY_DISABLED=1
ENV PORT=3000

# Non-root user for security
RUN addgroup --system --gid 1001 appgroup && \
    adduser --system --uid 1001 appuser

# Copy built assets
COPY --from=builder /app/public ./public
COPY --from=builder /app/package.json ./package.json
COPY --from=builder /app/prisma ./prisma

# Next.js standalone output
COPY --from=builder --chown=appuser:appgroup /app/.next/standalone ./
COPY --from=builder --chown=appuser:appgroup /app/.next/static ./.next/static

USER appuser

EXPOSE 3000

# Health check
HEALTHCHECK --interval=30s --timeout=10s --start-period=40s --retries=3 \
  CMD curl -f http://localhost:3000/api/health || exit 1

CMD ["node", "server.js"]
DKEOF
)
    _cig_write_file "${project_dir}/Dockerfile" "$dockerfile"

    # .dockerignore
    local dockerignore
    dockerignore=$(cat <<'DIEOF'
node_modules
.next
.git
.github
*.md
.env*
!.env.example
coverage
.nyc_output
*.log
.DS_Store
Thumbs.db
DIEOF
)
    _cig_write_file "${project_dir}/.dockerignore" "$dockerignore"
    CIG_GENERATED=$((CIG_GENERATED + 1))
    return 0
}

# =============================================================================
# ci_generate_docker_compose - ローカル開発用docker-compose.yml
# =============================================================================
ci_generate_docker_compose() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local compose
    compose=$(cat <<'DCEOF'
version: '3.8'

services:
  app:
    build:
      context: .
      dockerfile: Dockerfile
      target: builder
    ports:
      - '3000:3000'
    environment:
      - NODE_ENV=development
      - DATABASE_URL=postgresql://postgres:postgres@db:5432/app_dev
      - REDIS_URL=redis://redis:6379
      - NEXTAUTH_SECRET=dev-secret-change-in-production
      - NEXTAUTH_URL=http://localhost:3000
    volumes:
      - .:/app
      - /app/node_modules
      - /app/.next
    depends_on:
      db:
        condition: service_healthy
      redis:
        condition: service_healthy
    command: npm run dev
    restart: unless-stopped

  db:
    image: postgres:16-alpine
    ports:
      - '5432:5432'
    environment:
      POSTGRES_USER: postgres
      POSTGRES_PASSWORD: postgres
      POSTGRES_DB: app_dev
    volumes:
      - pgdata:/var/lib/postgresql/data
    healthcheck:
      test: ['CMD-SHELL', 'pg_isready -U postgres']
      interval: 10s
      timeout: 5s
      retries: 5
    restart: unless-stopped

  redis:
    image: redis:7-alpine
    ports:
      - '6379:6379'
    volumes:
      - redisdata:/data
    healthcheck:
      test: ['CMD', 'redis-cli', 'ping']
      interval: 10s
      timeout: 5s
      retries: 5
    command: redis-server --appendonly yes --maxmemory 256mb --maxmemory-policy allkeys-lru
    restart: unless-stopped

  # Optional: DB admin UI
  adminer:
    image: adminer:latest
    ports:
      - '8080:8080'
    depends_on:
      - db
    restart: unless-stopped
    profiles:
      - tools

volumes:
  pgdata:
    driver: local
  redisdata:
    driver: local
DCEOF
)
    _cig_write_file "${project_dir}/docker-compose.yml" "$compose"
    CIG_GENERATED=$((CIG_GENERATED + 1))
    return 0
}

# =============================================================================
# ci_generate_pre_commit - Pre-commitフック
# =============================================================================
ci_generate_pre_commit() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    # .husky/pre-commit
    local pre_commit_hook
    pre_commit_hook=$(cat <<'PCEOF'
#!/usr/bin/env sh
. "$(dirname -- "$0")/_/husky.sh"

npx lint-staged
PCEOF
)
    _cig_write_file "${project_dir}/.husky/pre-commit" "$pre_commit_hook"
    chmod +x "${project_dir}/.husky/pre-commit" 2>/dev/null

    # .husky/commit-msg
    local commit_msg_hook
    commit_msg_hook=$(cat <<'CMEOF'
#!/usr/bin/env sh
. "$(dirname -- "$0")/_/husky.sh"

npx --no -- commitlint --edit "$1"
CMEOF
)
    _cig_write_file "${project_dir}/.husky/commit-msg" "$commit_msg_hook"
    chmod +x "${project_dir}/.husky/commit-msg" 2>/dev/null

    # .lintstagedrc.json
    local lintstaged
    lintstaged=$(cat <<'LSEOF'
{
  "*.{ts,tsx}": [
    "eslint --fix --max-warnings 0",
    "prettier --write"
  ],
  "*.{js,jsx}": [
    "eslint --fix --max-warnings 0",
    "prettier --write"
  ],
  "*.{json,md,yml,yaml}": [
    "prettier --write"
  ],
  "*.prisma": [
    "npx prisma format"
  ]
}
LSEOF
)
    _cig_write_file "${project_dir}/.lintstagedrc.json" "$lintstaged"

    # commitlint.config.js
    local commitlint
    commitlint=$(cat <<'CLEOF'
module.exports = {
  extends: ['@commitlint/config-conventional'],
  rules: {
    'type-enum': [
      2,
      'always',
      ['feat', 'fix', 'docs', 'style', 'refactor', 'perf', 'test', 'build', 'ci', 'chore', 'revert'],
    ],
    'subject-max-length': [2, 'always', 100],
    'body-max-line-length': [1, 'always', 200],
  },
};
CLEOF
)
    _cig_write_file "${project_dir}/commitlint.config.js" "$commitlint"
    CIG_GENERATED=$((CIG_GENERATED + 1))
    return 0
}

# =============================================================================
# ci_generate_release_workflow - セマンティックバージョニング+リリース
# =============================================================================
ci_generate_release_workflow() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local release_yml
    release_yml=$(cat <<'RLEOF'
name: Release

on:
  push:
    branches: [main]

permissions:
  contents: write
  pull-requests: write
  packages: write

jobs:
  release:
    name: Semantic Release
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
        with:
          fetch-depth: 0
          token: ${{ secrets.GITHUB_TOKEN }}

      - name: Setup Node.js
        uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - name: Install dependencies
        run: npm ci

      - name: Build
        run: npm run build

      - name: Generate Changelog
        id: changelog
        run: |
          PREV_TAG=$(git describe --tags --abbrev=0 2>/dev/null || echo "")
          if [ -z "$PREV_TAG" ]; then
            COMMITS=$(git log --pretty=format:"- %s (%h)" --no-merges)
          else
            COMMITS=$(git log ${PREV_TAG}..HEAD --pretty=format:"- %s (%h)" --no-merges)
          fi
          echo "CHANGELOG<<EOF" >> $GITHUB_OUTPUT
          echo "$COMMITS" >> $GITHUB_OUTPUT
          echo "EOF" >> $GITHUB_OUTPUT

      - name: Determine Version Bump
        id: version
        run: |
          COMMITS=$(git log $(git describe --tags --abbrev=0 2>/dev/null || git rev-list --max-parents=0 HEAD)..HEAD --pretty=format:"%s")
          if echo "$COMMITS" | grep -qiE "^(feat|feature)(\(.+\))?!:"; then
            echo "bump=major" >> $GITHUB_OUTPUT
          elif echo "$COMMITS" | grep -qiE "^feat(\(.+\))?:"; then
            echo "bump=minor" >> $GITHUB_OUTPUT
          else
            echo "bump=patch" >> $GITHUB_OUTPUT
          fi

      - name: Bump Version
        id: bump
        run: |
          NEW_VERSION=$(npm version ${{ steps.version.outputs.bump }} --no-git-tag-version)
          echo "version=${NEW_VERSION}" >> $GITHUB_OUTPUT

      - name: Commit & Tag
        run: |
          git config user.name "github-actions[bot]"
          git config user.email "github-actions[bot]@users.noreply.github.com"
          git add package.json package-lock.json
          git commit -m "chore(release): ${{ steps.bump.outputs.version }}"
          git tag "${{ steps.bump.outputs.version }}"
          git push origin main --tags

      - name: Create GitHub Release
        uses: softprops/action-gh-release@v2
        with:
          tag_name: ${{ steps.bump.outputs.version }}
          name: Release ${{ steps.bump.outputs.version }}
          body: |
            ## Changes
            ${{ steps.changelog.outputs.CHANGELOG }}
          draft: false
          prerelease: false
RLEOF
)
    _cig_write_file "${project_dir}/.github/workflows/release.yml" "$release_yml"
    CIG_GENERATED=$((CIG_GENERATED + 1))
    return 0
}

# =============================================================================
# ci_generate_deploy_config - デプロイ設定
# =============================================================================
ci_generate_deploy_config() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${2:-vercel}"

    case "$target" in
        vercel)
            local vercel_json
            vercel_json=$(cat <<'VJEOF'
{
  "buildCommand": "prisma generate && next build",
  "installCommand": "npm ci",
  "framework": "nextjs",
  "regions": ["hnd1"],
  "env": {
    "DATABASE_URL": "@database-url",
    "NEXTAUTH_SECRET": "@nextauth-secret"
  },
  "headers": [
    {
      "source": "/api/(.*)",
      "headers": [
        { "key": "X-Content-Type-Options", "value": "nosniff" },
        { "key": "X-Frame-Options", "value": "DENY" },
        { "key": "Referrer-Policy", "value": "strict-origin-when-cross-origin" }
      ]
    }
  ]
}
VJEOF
)
            _cig_write_file "${project_dir}/vercel.json" "$vercel_json"
            ;;
        railway)
            local railway_toml
            railway_toml=$(cat <<'RTEOF'
[build]
builder = "nixpacks"
buildCommand = "npm ci && npx prisma generate && npm run build"

[deploy]
startCommand = "npx prisma migrate deploy && npm start"
healthcheckPath = "/api/health"
healthcheckTimeout = 30
numReplicas = 1
restartPolicyType = "ON_FAILURE"
restartPolicyMaxRetries = 3
RTEOF
)
            _cig_write_file "${project_dir}/railway.toml" "$railway_toml"
            ;;
        flyio)
            local fly_toml
            fly_toml=$(cat <<'FTEOF'
app = "my-app"
primary_region = "nrt"

[build]
  dockerfile = "Dockerfile"

[http_service]
  internal_port = 3000
  force_https = true
  auto_stop_machines = true
  auto_start_machines = true
  min_machines_running = 1

[http_service.concurrency]
  type = "requests"
  hard_limit = 250
  soft_limit = 200

[[services.http_checks]]
  interval = 10000
  grace_period = "10s"
  method = "get"
  path = "/api/health"
  protocol = "http"
  timeout = 2000

[env]
  NODE_ENV = "production"
  PORT = "3000"
FTEOF
)
            _cig_write_file "${project_dir}/fly.toml" "$fly_toml"
            ;;
        aws)
            local deploy_yml
            deploy_yml=$(cat <<'AWEOF'
name: Deploy to AWS

on:
  push:
    tags: ['v*']

jobs:
  deploy:
    runs-on: ubuntu-latest
    permissions:
      id-token: write
      contents: read
    steps:
      - uses: actions/checkout@v4

      - name: Configure AWS Credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-assume: ${{ secrets.AWS_ROLE_ARN }}
          aws-region: ap-northeast-1

      - name: Login to ECR
        id: ecr
        uses: aws-actions/amazon-ecr-login@v2

      - name: Build & Push Docker Image
        env:
          REGISTRY: ${{ steps.ecr.outputs.registry }}
          REPOSITORY: my-app
          IMAGE_TAG: ${{ github.sha }}
        run: |
          docker build -t $REGISTRY/$REPOSITORY:$IMAGE_TAG .
          docker push $REGISTRY/$REPOSITORY:$IMAGE_TAG

      - name: Deploy to ECS
        run: |
          aws ecs update-service \
            --cluster my-cluster \
            --service my-service \
            --force-new-deployment
AWEOF
)
            _cig_write_file "${project_dir}/.github/workflows/deploy-aws.yml" "$deploy_yml"
            ;;
        *)
            echo "[cicd] Unknown deploy target: $target" >&2
            CIG_ERRORS=$((CIG_ERRORS + 1))
            return 1
            ;;
    esac

    CIG_GENERATED=$((CIG_GENERATED + 1))
    return 0
}

# =============================================================================
# ci_inject_cicd_patterns - Claudeプロンプトへのパターン注入
# =============================================================================
ci_inject_cicd_patterns() {
    local prompt="${1:-}"

    cat <<'INJECT'

## [CI/CD Patterns] - 生成コードに必ず含めるCI/CD要件

### GitHub Actions必須構成:
- **キャッシュ**: node_modules, .next/cache, prisma engineを必ずキャッシュ
- **マトリックステスト**: Node 18/20/22 で並列テスト
- **サービスコンテナ**: PostgreSQL + Redis をGitHub Servicesで起動
- **並行制御**: concurrency group でPR毎に前回ビルドをキャンセル
- **セキュリティ**: npm audit + trufflehog でシークレットスキャン

### Dockerfile必須パターン:
- **マルチステージ**: deps → builder → runner の3段構成
- **非rootユーザー**: adduser --system で実行ユーザー分離
- **ヘルスチェック**: HEALTHCHECK命令で /api/health を定期チェック
- **レイヤーキャッシュ**: package.json を先にCOPYして依存キャッシュ最適化
- **.dockerignore**: node_modules, .next, .git, .env* を除外

### Pre-commit必須:
- **lint-staged**: .ts/.tsx はeslint --fix + prettier --write
- **commitlint**: Conventional Commits 強制
- **type-check**: コミット前にtsc --noEmit

### デプロイ設定:
- **vercel.json**: regions, headers（セキュリティヘッダー必須）, env参照
- **railway.toml**: healthcheck, restart policy
- **fly.toml**: auto_stop/start, concurrency制御

INJECT

    echo "$prompt"
}

# =============================================================================
# cig_generate_pipeline - 全CI/CD一括生成（レガシー互換）
# =============================================================================
cig_generate_pipeline() {
    local project_dir="${PROJECT_DIR:-./output}"
    ci_generate_github_actions "$project_dir"
    ci_generate_dockerfile "$project_dir"
    ci_generate_docker_compose "$project_dir"
    ci_generate_pre_commit "$project_dir"
    ci_generate_release_workflow "$project_dir"
    ci_generate_deploy_config "$project_dir" "vercel"
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
cig_report() {
    echo -e "\n  ${BOLD:-}=== cicd-generator v${CIG_VERSION} ===${NC:-}"
    echo -e "  生成数: ${CIG_GENERATED}"
    echo -e "  書込数: ${CIG_FILES_WRITTEN}"
    echo -e "  エラー: ${CIG_ERRORS}"
}

cig_score() {
    if [[ ${CIG_GENERATED} -ge 3 ]] && [[ ${CIG_ERRORS} -eq 0 ]]; then
        echo "95"
    elif [[ ${CIG_GENERATED} -gt 0 ]] && [[ ${CIG_ERRORS} -eq 0 ]]; then
        echo "85"
    elif [[ ${CIG_GENERATED} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "cicd-generator" --version "${CIG_VERSION}" \
        --description "CI/CDパイプライン自動生成×GitHub Actions/Docker/Deploy" \
        --init "ci_init" --report "cig_report" --score "cig_score" \
        --enable-var "ENABLE_CICD" --cli-flags "--cicd:--no-cicd"
fi

# v2003.1: source時のexit codeを確実に0にする
true
