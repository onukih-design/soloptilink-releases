#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v287.0 - Database Per Service
# =============================================================================
# サービスごとのDB分離パターン。各サービス専用のDBスキーマ設計、
# データ同期パターン、Sagaパターンによる分散トランザクションを生成。
#
# 機能一覧:
#   _dps_design_per_service_db - サービス別DBスキーマ設計
#   _dps_generate_data_sync    - データ同期パターン
#   _dps_generate_saga         - 分散トランザクション(Saga)
#
# 全globals: DPS_ prefix
# =============================================================================

[[ -n "${_DPS_LOADED:-}" ]] && return 0; _DPS_LOADED=1

declare -g DPS_VERSION="287.0"
declare -g DPS_GENERATED=0
declare -g DPS_ERRORS=0
declare -g DPS_FILES_WRITTEN=0

dps_init() { DPS_GENERATED=0; DPS_ERRORS=0; DPS_FILES_WRITTEN=0; return 0; }

_dps_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then DPS_FILES_WRITTEN=$((DPS_FILES_WRITTEN + 1)); echo "  [dps] wrote: $filepath" >&2
    else DPS_ERRORS=$((DPS_ERRORS + 1)); fi
}

_dps_log() { echo -e "  ${GREEN:-\033[0;32m}[DPS]${NC:-\033[0m} $*" >&2; }

# =============================================================================
# _dps_design_per_service_db
# =============================================================================
_dps_design_per_service_db() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _dps_log "Designing per-service database schemas..."

    local design_ts
    design_ts=$(cat <<'DESIGNEOF'
// =============================================================================
// Database Per Service - Schema Design
// Each service owns its database. No shared tables across services.
// =============================================================================

export interface ServiceDatabaseConfig {
  serviceName: string;
  dbType: 'postgresql' | 'mysql' | 'mongodb' | 'sqlite';
  connectionEnvVar: string;
  ownedModels: string[];
  readReplicas: boolean;
  migrations: 'prisma' | 'drizzle' | 'knex';
}

export const serviceDatabases: ServiceDatabaseConfig[] = [
  {
    serviceName: 'identity',
    dbType: 'postgresql',
    connectionEnvVar: 'IDENTITY_DATABASE_URL',
    ownedModels: ['User', 'Session', 'Role', 'Permission', 'AuditLog'],
    readReplicas: true,
    migrations: 'prisma',
  },
  {
    serviceName: 'catalog',
    dbType: 'postgresql',
    connectionEnvVar: 'CATALOG_DATABASE_URL',
    ownedModels: ['Product', 'Category', 'ProductVariant', 'Inventory'],
    readReplicas: true,
    migrations: 'prisma',
  },
  {
    serviceName: 'ordering',
    dbType: 'postgresql',
    connectionEnvVar: 'ORDER_DATABASE_URL',
    ownedModels: ['Order', 'OrderItem', 'Cart', 'CartItem'],
    readReplicas: false,
    migrations: 'prisma',
  },
  {
    serviceName: 'billing',
    dbType: 'postgresql',
    connectionEnvVar: 'BILLING_DATABASE_URL',
    ownedModels: ['Payment', 'Invoice', 'Subscription', 'Refund'],
    readReplicas: false,
    migrations: 'prisma',
  },
  {
    serviceName: 'notification',
    dbType: 'postgresql',
    connectionEnvVar: 'NOTIFICATION_DATABASE_URL',
    ownedModels: ['Notification', 'NotificationTemplate', 'NotificationPreference'],
    readReplicas: false,
    migrations: 'prisma',
  },
];

// Generate Prisma schema per service
export function generatePrismaSchema(config: ServiceDatabaseConfig): string {
  const header = [
    'generator client {',
    '  provider = "prisma-client-js"',
    `  output   = "../node_modules/.prisma/${config.serviceName}-client"`,
    '}',
    '',
    'datasource db {',
    `  provider = "${config.dbType === 'mongodb' ? 'mongodb' : 'postgresql'}"`,
    `  url      = env("${config.connectionEnvVar}")`,
    '}',
    '',
  ].join('\n');

  return header + `// Models owned by ${config.serviceName} service\n// Add model definitions here\n`;
}

export function validateNoSharedModels(): { valid: boolean; violations: string[] } {
  const modelOwnership: Record<string, string[]> = {};
  for (const db of serviceDatabases) {
    for (const model of db.ownedModels) {
      if (!modelOwnership[model]) modelOwnership[model] = [];
      modelOwnership[model].push(db.serviceName);
    }
  }

  const violations = Object.entries(modelOwnership)
    .filter(([, owners]) => owners.length > 1)
    .map(([model, owners]) => `Model '${model}' owned by multiple services: ${owners.join(', ')}`);

  return { valid: violations.length === 0, violations };
}
DESIGNEOF
)
    _dps_write_file "${project_dir}/src/architecture/database-per-service.ts" "$design_ts"
    DPS_GENERATED=$((DPS_GENERATED + 1))
    return 0
}

# =============================================================================
# _dps_generate_data_sync
# =============================================================================
_dps_generate_data_sync() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _dps_log "Generating data sync patterns..."

    local sync_ts
    sync_ts=$(cat <<'SYNCEOF'
// =============================================================================
// Data Synchronization Patterns
// Patterns for keeping data consistent across service databases
// =============================================================================

export interface SyncEvent {
  id: string;
  sourceService: string;
  targetService: string;
  entityType: string;
  entityId: string;
  operation: 'create' | 'update' | 'delete';
  payload: Record<string, unknown>;
  timestamp: string;
  processed: boolean;
}

// --- Change Data Capture (CDC) Outbox Pattern ---
export interface OutboxEntry {
  id: string;
  aggregateType: string;
  aggregateId: string;
  eventType: string;
  payload: string;
  createdAt: Date;
  publishedAt: Date | null;
}

export class OutboxPublisher {
  private pollInterval: NodeJS.Timeout | null = null;

  constructor(
    private prisma: any,
    private publisher: (event: OutboxEntry) => Promise<void>,
    private intervalMs: number = 1000,
  ) {}

  start(): void {
    this.pollInterval = setInterval(() => this.processOutbox(), this.intervalMs);
    console.log('[outbox] Publisher started');
  }

  stop(): void {
    if (this.pollInterval) clearInterval(this.pollInterval);
    this.pollInterval = null;
  }

  private async processOutbox(): Promise<void> {
    try {
      const entries = await this.prisma.outboxEvent.findMany({
        where: { publishedAt: null },
        orderBy: { createdAt: 'asc' },
        take: 100,
      });

      for (const entry of entries) {
        try {
          await this.publisher(entry);
          await this.prisma.outboxEvent.update({
            where: { id: entry.id },
            data: { publishedAt: new Date() },
          });
        } catch (err) {
          console.error(`[outbox] Failed to publish: ${entry.id}`, err);
        }
      }
    } catch (err) {
      console.error('[outbox] Poll error:', err);
    }
  }
}

// --- Materialized View Updater ---
export class MaterializedViewUpdater {
  private handlers: Map<string, (payload: Record<string, unknown>) => Promise<void>> = new Map();

  onEvent(eventType: string, handler: (payload: Record<string, unknown>) => Promise<void>): void {
    this.handlers.set(eventType, handler);
  }

  async processEvent(event: SyncEvent): Promise<void> {
    const handler = this.handlers.get(`${event.entityType}.${event.operation}`);
    if (handler) {
      await handler(event.payload);
      console.log(`[mv] Updated view for: ${event.entityType}.${event.operation}`);
    }
  }
}
SYNCEOF
)
    _dps_write_file "${project_dir}/src/lib/data-sync/sync-patterns.ts" "$sync_ts"
    DPS_GENERATED=$((DPS_GENERATED + 1))
    return 0
}

# =============================================================================
# _dps_generate_saga
# =============================================================================
_dps_generate_saga() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _dps_log "Generating saga pattern for distributed transactions..."

    local saga_ts
    saga_ts=$(cat <<'SAGAEOF'
// =============================================================================
// Saga Pattern - Distributed Transaction Coordination
// Orchestrator-based saga with compensation actions
// =============================================================================

export type SagaStatus = 'pending' | 'running' | 'completed' | 'compensating' | 'failed';

export interface SagaStep<TCtx> {
  name: string;
  execute: (ctx: TCtx) => Promise<TCtx>;
  compensate: (ctx: TCtx) => Promise<TCtx>;
}

export interface SagaLog {
  sagaId: string;
  step: string;
  action: 'execute' | 'compensate';
  status: 'success' | 'failure';
  error?: string;
  timestamp: string;
}

export class SagaOrchestrator<TCtx extends Record<string, any>> {
  private steps: SagaStep<TCtx>[] = [];
  private logs: SagaLog[] = [];
  private status: SagaStatus = 'pending';
  private sagaId: string;

  constructor(private name: string) {
    this.sagaId = crypto.randomUUID();
  }

  addStep(step: SagaStep<TCtx>): this {
    this.steps.push(step);
    return this;
  }

  async execute(initialContext: TCtx): Promise<{ success: boolean; context: TCtx; logs: SagaLog[] }> {
    let ctx = { ...initialContext };
    this.status = 'running';
    const completedSteps: SagaStep<TCtx>[] = [];

    for (const step of this.steps) {
      try {
        ctx = await step.execute(ctx);
        this.log(step.name, 'execute', 'success');
        completedSteps.push(step);
      } catch (error: any) {
        this.log(step.name, 'execute', 'failure', error.message);
        console.error(`[saga:${this.name}] Step '${step.name}' failed, compensating...`);

        // Compensate in reverse order
        this.status = 'compensating';
        for (const completed of completedSteps.reverse()) {
          try {
            ctx = await completed.compensate(ctx);
            this.log(completed.name, 'compensate', 'success');
          } catch (compError: any) {
            this.log(completed.name, 'compensate', 'failure', compError.message);
            console.error(`[saga:${this.name}] Compensation '${completed.name}' failed!`);
          }
        }

        this.status = 'failed';
        return { success: false, context: ctx, logs: this.logs };
      }
    }

    this.status = 'completed';
    return { success: true, context: ctx, logs: this.logs };
  }

  private log(step: string, action: 'execute' | 'compensate', status: 'success' | 'failure', error?: string): void {
    this.logs.push({ sagaId: this.sagaId, step, action, status, error, timestamp: new Date().toISOString() });
  }

  getStatus(): SagaStatus { return this.status; }
  getLogs(): SagaLog[] { return [...this.logs]; }
}
SAGAEOF
)
    _dps_write_file "${project_dir}/src/lib/data-sync/saga.ts" "$saga_ts"
    DPS_GENERATED=$((DPS_GENERATED + 1))
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
dps_report() {
    echo -e "\n  ${BOLD:-}=== database-per-service v${DPS_VERSION} ===${NC:-}"
    echo -e "  生成数: ${DPS_GENERATED}"; echo -e "  エラー: ${DPS_ERRORS}"
}

dps_score() {
    if [[ ${DPS_GENERATED} -ge 3 ]] && [[ ${DPS_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${DPS_GENERATED} -gt 0 ]] && [[ ${DPS_ERRORS} -eq 0 ]]; then echo "85"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "database-per-service" --version "${DPS_VERSION}" \
        --description "サービスごとDB分離×データ同期×Outboxパターン×Saga" \
        --init "dps_init" --report "dps_report" --score "dps_score" \
        --enable-var "ENABLE_DB_PER_SERVICE" --cli-flags "--db-per-service:--no-db-per-service"
fi

# v2003.1: source時のexit codeを確実に0にする
true
