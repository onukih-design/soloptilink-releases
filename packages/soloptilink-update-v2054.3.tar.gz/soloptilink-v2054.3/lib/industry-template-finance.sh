#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v375.0 - Industry Template: Finance
# =============================================================================
# 金融/会計特化テンプレートエンジン。
# 口座管理/取引履歴/レポーティング/コンプライアンス等の金融必須コンポーネントを自動生成。
#
# All globals use the ITF_ prefix.
# =============================================================================

[[ -n "${_INDUSTRY_TEMPLATE_FINANCE_LOADED:-}" ]] && return 0
_INDUSTRY_TEMPLATE_FINANCE_LOADED=1

declare -g ITF_VERSION="375.0"
declare -g ITF_INITIALIZED=false
declare -g ITF_GENERATED_COUNT=0
declare -g ITF_ACCOUNT_GENERATED=false
declare -g ITF_TRANSACTION_GENERATED=false
declare -g ITF_REPORTING_GENERATED=false
declare -g ITF_COMPLIANCE_GENERATED=false
declare -g ENABLE_ITF="${ENABLE_ITF:-true}"

_itf_init() {
    ITF_INITIALIZED=true
    ITF_GENERATED_COUNT=0
    return 0
}

_itf_generate_finance() {
    local project_dir="${1:-.}"
    [[ "$ITF_INITIALIZED" != "true" ]] && _itf_init

    echo -e "  ${CYAN:-\033[0;36m}[ITF]${NC:-\033[0m} 金融業界テンプレート生成開始..." >&2

    _itf_generate_account "$project_dir"
    _itf_generate_transaction "$project_dir"
    _itf_generate_reporting "$project_dir"
    _itf_generate_compliance "$project_dir"

    echo -e "  ${GREEN:-\033[0;32m}[ITF]${NC:-\033[0m} 金融業界テンプレート生成完了: ${ITF_GENERATED_COUNT}件" >&2
    return 0
}

_itf_generate_account() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITF-ACCOUNT] 口座管理テンプレート

### Prisma Schema
```prisma
model Account {
  id            String   @id @default(cuid())
  accountNumber String   @unique
  userId        String
  type          String   @default("checking")
  currency      String   @default("JPY")
  balance       BigInt   @default(0)
  availableBalance BigInt @default(0)
  status        String   @default("active")
  openedAt      DateTime @default(now())
  closedAt      DateTime?
  transactions  Transaction[]
  @@index([userId])
}
```

### Balance Service (Double-Entry)
```typescript
export class BalanceService {
  async transfer(fromAccountId: string, toAccountId: string, amount: bigint, description: string) {
    return prisma.$transaction(async (tx) => {
      const fromAccount = await tx.account.findUniqueOrThrow({ where: { id: fromAccountId } });
      if (fromAccount.balance < amount) throw new Error('残高不足');
      if (fromAccount.status !== 'active') throw new Error('口座が無効です');

      const [debit, credit] = await Promise.all([
        tx.transaction.create({ data: { accountId: fromAccountId, type: 'debit', amount: -amount, description, balanceAfter: fromAccount.balance - amount } }),
        tx.transaction.create({ data: { accountId: toAccountId, type: 'credit', amount, description, balanceAfter: (await tx.account.findUniqueOrThrow({ where: { id: toAccountId } })).balance + amount } }),
      ]);
      await Promise.all([
        tx.account.update({ where: { id: fromAccountId }, data: { balance: { decrement: amount } } }),
        tx.account.update({ where: { id: toAccountId }, data: { balance: { increment: amount } } }),
      ]);
      return { debit, credit };
    });
  }
}
```
TEMPLATE

    ITF_ACCOUNT_GENERATED=true
    ITF_GENERATED_COUNT=$((ITF_GENERATED_COUNT + 1))
    return 0
}

_itf_generate_transaction() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITF-TRANSACTION] 取引管理テンプレート

### Schema
```prisma
model Transaction {
  id           String   @id @default(cuid())
  accountId    String
  account      Account  @relation(fields: [accountId], references: [id])
  type         String
  amount       BigInt
  currency     String   @default("JPY")
  description  String?
  category     String?
  reference    String?
  balanceAfter BigInt
  status       String   @default("completed")
  metadata     Json?
  createdAt    DateTime @default(now())
  @@index([accountId, createdAt])
  @@index([category])
}
```

### Transaction History Component
```tsx
'use client';
export function TransactionHistory({ accountId }: { accountId: string }) {
  const [dateRange, setDateRange] = useState<DateRange>({ from: startOfMonth(new Date()), to: new Date() });
  const [category, setCategory] = useState('all');
  const params = new URLSearchParams({
    from: dateRange.from.toISOString(), to: dateRange.to.toISOString(),
    ...(category !== 'all' && { category }),
  });
  const { data, isLoading, error } = useSWR(`/api/accounts/${accountId}/transactions?${params}`);

  if (isLoading) return <TransactionSkeleton />;
  if (error) return <ErrorMessage message="取引履歴の取得に失敗しました" />;

  return (
    <div className="space-y-4">
      <DateRangePicker value={dateRange} onChange={setDateRange} />
      <CategoryFilter value={category} onChange={setCategory} />
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>日時</TableHead><TableHead>内容</TableHead>
            <TableHead>カテゴリ</TableHead><TableHead className="text-right">金額</TableHead>
            <TableHead className="text-right">残高</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data?.transactions?.map((tx: Transaction) => (
            <TableRow key={tx.id}>
              <TableCell>{format(new Date(tx.createdAt), 'yyyy/MM/dd HH:mm')}</TableCell>
              <TableCell>{tx.description}</TableCell>
              <TableCell><Badge>{tx.category}</Badge></TableCell>
              <TableCell className={cn("text-right", tx.amount > 0 ? "text-green-600" : "text-red-600")}>
                {formatCurrency(tx.amount)}
              </TableCell>
              <TableCell className="text-right">{formatCurrency(tx.balanceAfter)}</TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
```
TEMPLATE

    ITF_TRANSACTION_GENERATED=true
    ITF_GENERATED_COUNT=$((ITF_GENERATED_COUNT + 1))
    return 0
}

_itf_generate_reporting() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITF-REPORTING] 財務レポーティングテンプレート

### Monthly Summary
```typescript
export async function generateMonthlyReport(accountId: string, year: number, month: number) {
  const start = new Date(year, month - 1, 1);
  const end = new Date(year, month, 0, 23, 59, 59);

  const transactions = await prisma.transaction.findMany({
    where: { accountId, createdAt: { gte: start, lte: end } },
    orderBy: { createdAt: 'asc' },
  });

  const income = transactions.filter(t => t.amount > 0n).reduce((s, t) => s + t.amount, 0n);
  const expense = transactions.filter(t => t.amount < 0n).reduce((s, t) => s + t.amount, 0n);

  const byCategory = transactions.reduce((acc, t) => {
    const cat = t.category ?? 'uncategorized';
    acc[cat] = (acc[cat] ?? 0n) + t.amount;
    return acc;
  }, {} as Record<string, bigint>);

  return {
    period: { year, month }, totalIncome: income, totalExpense: expense,
    netIncome: income + expense, transactionCount: transactions.length,
    byCategory, openingBalance: transactions[0]?.balanceAfter - transactions[0]?.amount ?? 0n,
    closingBalance: transactions[transactions.length - 1]?.balanceAfter ?? 0n,
  };
}
```

### PL Dashboard
```tsx
export function PLDashboard({ year, month }: { year: number; month: number }) {
  const { data, isLoading } = useSWR(`/api/reports/monthly?year=${year}&month=${month}`);
  if (isLoading) return <ReportSkeleton />;
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <StatCard title="収入" value={formatCurrency(data.totalIncome)} trend="up" />
      <StatCard title="支出" value={formatCurrency(data.totalExpense)} trend="down" />
      <StatCard title="純利益" value={formatCurrency(data.netIncome)} trend={data.netIncome > 0 ? "up" : "down"} />
    </div>
  );
}
```
TEMPLATE

    ITF_REPORTING_GENERATED=true
    ITF_GENERATED_COUNT=$((ITF_GENERATED_COUNT + 1))
    return 0
}

_itf_generate_compliance() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITF-COMPLIANCE] 金融コンプライアンステンプレート

### AML/KYC Check
```typescript
export class ComplianceService {
  async performKYC(userId: string, documents: KYCDocument[]): Promise<KYCResult> {
    const verification = await prisma.kycVerification.create({
      data: { userId, status: 'pending', documents: JSON.stringify(documents), submittedAt: new Date() },
    });
    await this.runAutomatedChecks(verification.id, documents);
    return { verificationId: verification.id, status: 'pending' };
  }

  async checkTransactionLimits(accountId: string, amount: bigint): Promise<boolean> {
    const dailyTotal = await prisma.transaction.aggregate({
      where: { accountId, createdAt: { gte: startOfDay(new Date()) }, type: 'debit' },
      _sum: { amount: true },
    });
    const limit = await this.getAccountLimit(accountId);
    if (Math.abs(Number(dailyTotal._sum.amount ?? 0n)) + Number(amount) > limit) {
      await this.flagSuspiciousActivity(accountId, 'daily_limit_exceeded');
      return false;
    }
    return true;
  }
}
```
TEMPLATE

    ITF_COMPLIANCE_GENERATED=true
    ITF_GENERATED_COUNT=$((ITF_GENERATED_COUNT + 1))
    return 0
}

_itf_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Industry Template: Finance v${ITF_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成テンプレート数 : ${ITF_GENERATED_COUNT}"
    echo -e "  Account            : ${ITF_ACCOUNT_GENERATED}"
    echo -e "  Transaction        : ${ITF_TRANSACTION_GENERATED}"
    echo -e "  Reporting          : ${ITF_REPORTING_GENERATED}"
    echo -e "  Compliance         : ${ITF_COMPLIANCE_GENERATED}"
}

_itf_score() {
    local score=30
    [[ "$ITF_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$ITF_ACCOUNT_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITF_TRANSACTION_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITF_REPORTING_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITF_COMPLIANCE_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "industry-template-finance" \
    --version "375.0" \
    --description "金融業界テンプレート（口座/取引/レポート/コンプライアンス）" \
    --init "_itf_init" \
    --report "_itf_report" \
    --score "_itf_score" \
    --enable-var "ENABLE_ITF" \
    --cli-flags "--industry-finance:--no-industry-finance"
