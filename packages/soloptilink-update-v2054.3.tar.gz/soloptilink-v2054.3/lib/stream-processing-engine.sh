#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v426.0 - Stream Processing Engine
# =============================================================================
# AI生成のストリーミング処理エンジン。リアルタイムでの生成出力監視、
# 早期エラー検出、進捗レポートを提供し、生成品質をリアルタイムで把握する。
#
# Functions:
#   _spe2_init()                - 初期化
#   _spe2_stream_generation()   - ストリーミング生成処理
#   _spe2_early_error_detect()  - 早期エラー検出
#   _spe2_progress_report()     - リアルタイム進捗レポート
#   _spe2_report() / _spe2_score()
#
# All globals use the SPE2_ prefix.
# =============================================================================

[[ -n "${_SPE2_LOADED:-}" ]] && return 0; _SPE2_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g SPE2_VERSION="426.0"
declare -g SPE2_GENERATED=0
declare -g SPE2_ERRORS=0
declare -g SPE2_STREAMS_STARTED=0
declare -g SPE2_STREAMS_COMPLETED=0
declare -g SPE2_EARLY_ERRORS=0
declare -g SPE2_CHUNKS_PROCESSED=0
declare -g SPE2_BYTES_PROCESSED=0
declare -g SPE2_CURRENT_STREAM=""
declare -g SPE2_STREAM_LOG="${SPE2_STREAM_LOG:-.soloptilink/stream/current.log}"

declare -ga _SPE2_ERROR_PATTERNS=()
declare -gA _SPE2_STREAM_STATE=()

_SPE2_GREEN="${GREEN:-\033[0;32m}"
_SPE2_RED="${RED:-\033[0;31m}"
_SPE2_YELLOW="${YELLOW:-\033[0;33m}"
_SPE2_CYAN="${CYAN:-\033[0;36m}"
_SPE2_BOLD="${BOLD:-\033[1m}"
_SPE2_NC="${NC:-\033[0m}"

# =============================================================================
# Init
# =============================================================================
_spe2_init() {
    SPE2_GENERATED=0
    SPE2_ERRORS=0
    SPE2_STREAMS_STARTED=0
    SPE2_STREAMS_COMPLETED=0
    SPE2_EARLY_ERRORS=0
    SPE2_CHUNKS_PROCESSED=0
    SPE2_BYTES_PROCESSED=0
    SPE2_CURRENT_STREAM=""
    _SPE2_STREAM_STATE=()

    # デフォルトエラーパターン
    _SPE2_ERROR_PATTERNS=(
        "SyntaxError"
        "TypeError"
        "ReferenceError"
        "Cannot find module"
        "Import error"
        "Unexpected token"
        "FATAL"
        "panic:"
        "segmentation fault"
        "out of memory"
    )

    mkdir -p "$(dirname "$SPE2_STREAM_LOG")" 2>/dev/null
    return 0
}

_spe2_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_SPE2_CYAN}[SPE2]${_SPE2_NC} $*" >&2 ;;
        ok)    echo -e "  ${_SPE2_GREEN}[SPE2]${_SPE2_NC} $*" >&2 ;;
        warn)  echo -e "  ${_SPE2_YELLOW}[SPE2]${_SPE2_NC} $*" >&2 ;;
        error) echo -e "  ${_SPE2_RED}[SPE2]${_SPE2_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _spe2_stream_generation - ストリーミング生成処理
# =============================================================================
_spe2_stream_generation() {
    local input_source="$1"
    local output_file="${2:-/dev/stdout}"
    local stream_id="${3:-stream_$$_$(date +%s 2>/dev/null || echo 0)}"

    SPE2_CURRENT_STREAM="$stream_id"
    SPE2_STREAMS_STARTED=$((SPE2_STREAMS_STARTED + 1))
    _SPE2_STREAM_STATE["$stream_id"]="active"

    _spe2_log info "ストリーム開始: ${stream_id}"

    local chunk_count=0
    local byte_count=0
    local error_detected=false
    local start_time
    start_time=$(date +%s 2>/dev/null || echo 0)

    # 入力ソースからストリーム読み取り
    if [[ -f "$input_source" ]]; then
        while IFS= read -r chunk; do
            chunk_count=$((chunk_count + 1))
            byte_count=$((byte_count + ${#chunk}))

            # 早期エラー検出
            local error_msg
            error_msg=$(_spe2_early_error_detect "$chunk")
            if [[ -n "$error_msg" ]]; then
                error_detected=true
                _spe2_log error "早期エラー検出 (チャンク${chunk_count}): ${error_msg}"
                SPE2_EARLY_ERRORS=$((SPE2_EARLY_ERRORS + 1))
            fi

            # 出力に書き込み
            echo "$chunk" >> "$output_file" 2>/dev/null

            # 進捗レポート（100チャンクごと）
            if [[ $((chunk_count % 100)) -eq 0 ]]; then
                _spe2_progress_report "$stream_id" "$chunk_count" "$byte_count"
            fi
        done < "$input_source"
    elif [[ "$input_source" == "-" ]]; then
        while IFS= read -r chunk; do
            chunk_count=$((chunk_count + 1))
            byte_count=$((byte_count + ${#chunk}))

            local error_msg
            error_msg=$(_spe2_early_error_detect "$chunk")
            if [[ -n "$error_msg" ]]; then
                error_detected=true
                SPE2_EARLY_ERRORS=$((SPE2_EARLY_ERRORS + 1))
            fi

            echo "$chunk"

            if [[ $((chunk_count % 100)) -eq 0 ]]; then
                _spe2_progress_report "$stream_id" "$chunk_count" "$byte_count"
            fi
        done
    fi

    SPE2_CHUNKS_PROCESSED=$((SPE2_CHUNKS_PROCESSED + chunk_count))
    SPE2_BYTES_PROCESSED=$((SPE2_BYTES_PROCESSED + byte_count))

    local elapsed=$(( $(date +%s 2>/dev/null || echo 0) - start_time ))

    if [[ "$error_detected" == "true" ]]; then
        _SPE2_STREAM_STATE["$stream_id"]="error"
        SPE2_ERRORS=$((SPE2_ERRORS + 1))
    else
        _SPE2_STREAM_STATE["$stream_id"]="completed"
        SPE2_STREAMS_COMPLETED=$((SPE2_STREAMS_COMPLETED + 1))
    fi

    SPE2_GENERATED=$((SPE2_GENERATED + 1))
    _spe2_log ok "ストリーム完了: ${chunk_count}チャンク, ${byte_count}bytes (${elapsed}秒)"

    return 0
}

# =============================================================================
# _spe2_early_error_detect - 早期エラー検出
# =============================================================================
_spe2_early_error_detect() {
    local content="$1"

    for pattern in "${_SPE2_ERROR_PATTERNS[@]}"; do
        if [[ "$content" == *"$pattern"* ]]; then
            echo "$pattern"
            return 0
        fi
    done

    # 構文エラーの兆候検出
    # 不完全なJSON
    local open_braces close_braces
    open_braces=$(echo "$content" | tr -cd '{' | wc -c)
    close_braces=$(echo "$content" | tr -cd '}' | wc -c)
    if [[ $open_braces -gt $((close_braces + 10)) ]]; then
        echo "unbalanced_braces"
        return 0
    fi

    # 不完全な文字列
    local quotes
    quotes=$(echo "$content" | tr -cd '"' | wc -c)
    if [[ $((quotes % 2)) -ne 0 ]]; then
        # 大きなチャンクでのみ報告
        if [[ ${#content} -gt 500 ]]; then
            echo "unmatched_quotes"
            return 0
        fi
    fi

    echo ""
    return 1
}

# =============================================================================
# _spe2_progress_report - リアルタイム進捗レポート
# =============================================================================
_spe2_progress_report() {
    local stream_id="${1:-$SPE2_CURRENT_STREAM}"
    local chunks="${2:-$SPE2_CHUNKS_PROCESSED}"
    local bytes="${3:-$SPE2_BYTES_PROCESSED}"

    local state="${_SPE2_STREAM_STATE[$stream_id]:-unknown}"
    local kb=$((bytes / 1024))

    cat > "$SPE2_STREAM_LOG" <<EOF
{
  "stream_id": "${stream_id}",
  "state": "${state}",
  "chunks_processed": ${chunks},
  "bytes_processed": ${bytes},
  "kb_processed": ${kb},
  "early_errors": ${SPE2_EARLY_ERRORS},
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || echo "unknown")"
}
EOF

    _spe2_log info "進捗 [${stream_id}]: ${chunks}チャンク / ${kb}KB / エラー${SPE2_EARLY_ERRORS}"
    return 0
}

# =============================================================================
# _spe2_add_error_pattern - カスタムエラーパターン追加
# =============================================================================
_spe2_add_error_pattern() {
    local pattern="$1"
    _SPE2_ERROR_PATTERNS+=("$pattern")
}

# =============================================================================
# Report & Score
# =============================================================================
_spe2_report() {
    echo -e "\n  ${_SPE2_BOLD}=== stream-processing-engine v${SPE2_VERSION} ===${_SPE2_NC}"
    echo -e "  ストリーム開始  : ${SPE2_STREAMS_STARTED}"
    echo -e "  ストリーム完了  : ${SPE2_STREAMS_COMPLETED}"
    echo -e "  処理チャンク    : ${SPE2_CHUNKS_PROCESSED}"
    echo -e "  処理バイト      : ${SPE2_BYTES_PROCESSED}"
    echo -e "  早期エラー検出  : ${SPE2_EARLY_ERRORS}"
    echo -e "  エラー          : ${SPE2_ERRORS}"
}

_spe2_score() {
    local score=50
    [[ ${SPE2_STREAMS_COMPLETED} -gt 0 ]] && score=$((score + 15))
    [[ ${SPE2_CHUNKS_PROCESSED} -gt 0 ]] && score=$((score + 10))
    [[ ${SPE2_EARLY_ERRORS} -gt 0 ]] && score=$((score + 10))  # 検出自体は良いこと
    [[ ${SPE2_ERRORS} -eq 0 ]] && score=$((score + 15))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "stream-processing-engine" --version "${SPE2_VERSION}" \
        --description "ストリーミング生成×早期エラー検出×リアルタイム進捗 (v426)" \
        --init "_spe2_init" --report "_spe2_report" --score "_spe2_score" \
        --enable-var "ENABLE_STREAM_PROCESSING" --cli-flags "--stream-processing:--no-stream-processing"
fi

# v2003.1: source時のexit codeを確実に0にする
true
