#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2015.0 - Prompt Amplifier Engine
# =============================================================================
# The single most impactful module for improving ALL output quality.
# Enhances every prompt before it reaches Claude by injecting domain context,
# anti-pattern rules, quality requirements, code style enforcement, few-shot
# examples, and error-prevention knowledge.
#
# Functions:
#   pa_init                      - Initialize amplifier (load domains, patterns)
#   pa_amplify_prompt            - Main entry: raw prompt -> amplified prompt
#   pa_inject_anti_patterns      - Domain-specific NEVER-DO rules
#   pa_inject_quality_requirements - Framework-specific ALWAYS-DO rules
#   pa_inject_code_style         - Detect & enforce project code style
#   pa_inject_few_shot_examples  - Phase/domain-matched examples
#   pa_inject_error_prevention   - Learned error patterns + framework gotchas
#   pa_calculate_amplification_score - Score the amplification 0-100
#   pa_get_stats                 - Session statistics report
#
# All globals use the PA_ prefix.
# Sourced by chain.sh -- do NOT use set -euo pipefail.
# =============================================================================

[[ -n "${_PROMPT_AMPLIFIER_LOADED:-}" ]] && return 0
_PROMPT_AMPLIFIER_LOADED=1

# =============================================================================
# Constants & Configuration
# =============================================================================
declare -g PA_VERSION="2015.0"
declare -g PA_MODULE_NAME="PromptAmplifier"

# Directories -- resolved at init time via SCRIPT_DIR
declare -g PA_DOMAINS_DIR=""
declare -g PA_LEARNING_DIR=""
declare -g PA_PROMPTS_DIR=""
declare -g PA_QUALITY_DIR=""
declare -g PA_ERRORS_DIR=""

# Quality thresholds
declare -g PA_MIN_AMPLIFICATION_SCORE=40
declare -g PA_TARGET_AMPLIFICATION_SCORE=75
declare -g PA_MAX_INJECTION_CHARS=6000
declare -g PA_MAX_FEW_SHOT_CHARS=2000
declare -g PA_MAX_ANTI_PATTERN_RULES=15
declare -g PA_MAX_QUALITY_RULES=12

# State
declare -g PA_INITIALIZED="false"
declare -g PA_DOMAIN_CACHE=""
declare -g PA_LEARNED_PATTERNS=""
declare -g PA_LEARNED_ERRORS=""

# Statistics accumulators
declare -g PA_STAT_TOTAL_AMPLIFIED=0
declare -g PA_STAT_TOTAL_SCORE=0
declare -g PA_STAT_ANTI_PATTERNS_INJECTED=0
declare -g PA_STAT_QUALITY_RULES_INJECTED=0
declare -g PA_STAT_FEW_SHOTS_INJECTED=0
declare -g PA_STAT_ERROR_PREVENTIONS_INJECTED=0
declare -g PA_STAT_DOMAIN_COUNTS=""
declare -g PA_STAT_PHASE_COUNTS=""

# Temp file for passing stats out of subshells created by $(...)
declare -g PA_STAT_FILE="/tmp/.pa_stats_$$"

# Colours (self-contained fallback, avoids hard dependency on colors.sh)
PA_CLR_CYAN="${CLR_CYAN:-\033[0;36m}"
PA_CLR_GREEN="${CLR_GREEN:-\033[0;32m}"
PA_CLR_YELLOW="${CLR_YELLOW:-\033[0;33m}"
PA_CLR_RED="${CLR_RED:-\033[0;31m}"
PA_CLR_BOLD="${CLR_BOLD:-\033[1m}"
PA_CLR_NC="${CLR_NC:-\033[0m}"

# =============================================================================
# Internal Helpers
# =============================================================================

# Logging -- delegates to the project logger when available, otherwise stderr
_pa_log() {
    local level="$1"; shift
    local msg="$*"
    if declare -f log &>/dev/null; then
        log "$level" "[${PA_MODULE_NAME}] ${msg}"
    else
        local color
        case "$level" in
            INFO|PASS) color="$PA_CLR_CYAN"  ;;
            WARN)      color="$PA_CLR_YELLOW" ;;
            ERROR)     color="$PA_CLR_RED"    ;;
            *)         color="$PA_CLR_NC"     ;;
        esac
        printf "  ${color}[PA:${level}]${PA_CLR_NC} %s\n" "$msg" >&2
    fi
}

# Safe python3 JSON getter -- used heavily for domain JSON parsing
_pa_json_get() {
    local file="$1" key="$2"
    if [[ ! -f "$file" ]]; then
        return 1
    fi
    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys
try:
    with open(sys.argv[1]) as f:
        d = json.load(f)
    keys = sys.argv[2].split('.')
    val = d
    for k in keys:
        if isinstance(val, dict):
            val = val.get(k)
        elif isinstance(val, list) and k.isdigit():
            val = val[int(k)]
        else:
            val = None; break
    if val is not None:
        print(val if isinstance(val, str) else json.dumps(val, ensure_ascii=False))
except: pass
" "$file" "$key" 2>/dev/null
    elif command -v jq &>/dev/null; then
        jq -r ".${key} // empty" "$file" 2>/dev/null
    fi
}

# Safe python3 JSON array reader -- returns one element per line
_pa_json_array() {
    local file="$1" key="$2"
    if [[ ! -f "$file" ]]; then
        return 1
    fi
    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys
try:
    with open(sys.argv[1]) as f:
        d = json.load(f)
    keys = sys.argv[2].split('.')
    val = d
    for k in keys:
        if isinstance(val, dict):
            val = val.get(k)
        elif isinstance(val, list) and k.isdigit():
            val = val[int(k)]
        else:
            val = None; break
    if isinstance(val, list):
        for item in val:
            print(item if isinstance(item, str) else json.dumps(item, ensure_ascii=False))
except: pass
" "$file" "$key" 2>/dev/null
    fi
}

# Truncate text to a max character length, appending "..." if trimmed
_pa_truncate() {
    local text="$1" max_chars="${2:-$PA_MAX_INJECTION_CHARS}"
    local len=${#text}
    if (( len > max_chars )); then
        echo "${text:0:$((max_chars - 3))}..."
    else
        echo "$text"
    fi
}

# Append a section to an accumulating prompt, with a header
_pa_append_section() {
    local base="$1" header="$2" body="$3"
    if [[ -z "$body" ]]; then
        echo "$base"
        return
    fi
    printf '%s\n\n--- %s ---\n%s' "$base" "$header" "$body"
}

# Count lines in a string
_pa_line_count() {
    local text="$1"
    if [[ -z "$text" ]]; then
        echo 0
    else
        echo "$text" | wc -l | tr -d ' '
    fi
}

# Increment a domain counter in PA_STAT_DOMAIN_COUNTS (format: "dom1:N|dom2:M")
_pa_inc_domain_stat() {
    local domain="$1"
    if [[ -z "$PA_STAT_DOMAIN_COUNTS" ]]; then
        PA_STAT_DOMAIN_COUNTS="${domain}:1"
        return
    fi
    if [[ "$PA_STAT_DOMAIN_COUNTS" == *"${domain}:"* ]]; then
        # Extract current count and increment
        local before after cur new_val
        before="${PA_STAT_DOMAIN_COUNTS%%${domain}:*}"
        after="${PA_STAT_DOMAIN_COUNTS#*${domain}:}"
        cur="${after%%|*}"
        new_val=$((cur + 1))
        if [[ "$after" == *"|"* ]]; then
            after="${after#*|}"
            PA_STAT_DOMAIN_COUNTS="${before}${domain}:${new_val}|${after}"
        else
            PA_STAT_DOMAIN_COUNTS="${before}${domain}:${new_val}"
        fi
    else
        PA_STAT_DOMAIN_COUNTS="${PA_STAT_DOMAIN_COUNTS}|${domain}:1"
    fi
}

# Increment a phase counter in PA_STAT_PHASE_COUNTS
_pa_inc_phase_stat() {
    local phase="$1"
    if [[ -z "$PA_STAT_PHASE_COUNTS" ]]; then
        PA_STAT_PHASE_COUNTS="${phase}:1"
        return
    fi
    if [[ "$PA_STAT_PHASE_COUNTS" == *"${phase}:"* ]]; then
        local before after cur new_val
        before="${PA_STAT_PHASE_COUNTS%%${phase}:*}"
        after="${PA_STAT_PHASE_COUNTS#*${phase}:}"
        cur="${after%%|*}"
        new_val=$((cur + 1))
        if [[ "$after" == *"|"* ]]; then
            after="${after#*|}"
            PA_STAT_PHASE_COUNTS="${before}${phase}:${new_val}|${after}"
        else
            PA_STAT_PHASE_COUNTS="${before}${phase}:${new_val}"
        fi
    else
        PA_STAT_PHASE_COUNTS="${PA_STAT_PHASE_COUNTS}|${phase}:1"
    fi
}

# Write stats delta to temp file so the parent shell can absorb them
# Called at the end of pa_amplify_prompt (which may run in a $() subshell)
_pa_emit_stats() {
    local score="$1" anti="$2" quality="$3" fewshot="$4" errprev="$5"
    local domain="$6" phase="$7"
    cat >> "$PA_STAT_FILE" <<EOF
${score} ${anti} ${quality} ${fewshot} ${errprev} ${domain} ${phase}
EOF
}

# Absorb all pending stats from the temp file into the global accumulators.
# Call this in the parent shell after each pa_amplify_prompt invocation,
# or call pa_get_stats() which calls it automatically.
pa_sync_stats() {
    [[ -f "$PA_STAT_FILE" ]] || return 0
    local line score anti quality fewshot errprev domain phase
    while IFS=' ' read -r score anti quality fewshot errprev domain phase; do
        [[ -z "$score" ]] && continue
        (( PA_STAT_TOTAL_AMPLIFIED++ )) || true
        PA_STAT_TOTAL_SCORE=$(( PA_STAT_TOTAL_SCORE + score ))
        PA_STAT_ANTI_PATTERNS_INJECTED=$(( PA_STAT_ANTI_PATTERNS_INJECTED + anti ))
        PA_STAT_QUALITY_RULES_INJECTED=$(( PA_STAT_QUALITY_RULES_INJECTED + quality ))
        PA_STAT_FEW_SHOTS_INJECTED=$(( PA_STAT_FEW_SHOTS_INJECTED + fewshot ))
        PA_STAT_ERROR_PREVENTIONS_INJECTED=$(( PA_STAT_ERROR_PREVENTIONS_INJECTED + errprev ))
        _pa_inc_domain_stat "$domain"
        _pa_inc_phase_stat "$phase"
    done < "$PA_STAT_FILE"
    : > "$PA_STAT_FILE"  # Truncate after absorbing
}

# =============================================================================
# 1. pa_init() - Initialize the Prompt Amplifier
# =============================================================================
# Loads domain context, learned patterns, quality thresholds, and validates
# that required infrastructure is available.
# =============================================================================
pa_init() {
    [[ "$PA_INITIALIZED" == "true" ]] && return 0

    local script_dir="${SCRIPT_DIR:-${HOME}/.soloptilink}"

    # Resolve directories
    PA_DOMAINS_DIR="${script_dir}/domains"
    PA_LEARNING_DIR="${script_dir}/learning"
    PA_PROMPTS_DIR="${PA_LEARNING_DIR}/prompts"
    PA_QUALITY_DIR="${PA_LEARNING_DIR}/quality"
    PA_ERRORS_DIR="${PA_LEARNING_DIR}/errors"

    # Validate python3 availability (required for JSON operations)
    if ! command -v python3 &>/dev/null; then
        _pa_log "WARN" "python3 not found -- amplifier runs in degraded mode"
    fi

    # ---------------------------------------------------------------------------
    # Load domain context cache: read every domain JSON and cache the domain list
    # ---------------------------------------------------------------------------
    PA_DOMAIN_CACHE=""
    if [[ -d "$PA_DOMAINS_DIR" ]]; then
        local domain_file domain_name
        for domain_file in "${PA_DOMAINS_DIR}"/*.json; do
            [[ -f "$domain_file" ]] || continue
            domain_name="$(basename "$domain_file" .json)"
            # Skip the _base and subdirectories
            [[ "$domain_name" == _* ]] && continue
            if [[ -n "$PA_DOMAIN_CACHE" ]]; then
                PA_DOMAIN_CACHE="${PA_DOMAIN_CACHE}|${domain_name}"
            else
                PA_DOMAIN_CACHE="${domain_name}"
            fi
        done
        local domain_count
        domain_count=$(echo "$PA_DOMAIN_CACHE" | tr '|' '\n' | wc -l | tr -d ' ')
        _pa_log "INFO" "Loaded ${domain_count} domain definitions from ${PA_DOMAINS_DIR}"
    else
        _pa_log "WARN" "Domains directory not found: ${PA_DOMAINS_DIR}"
    fi

    # ---------------------------------------------------------------------------
    # Load learned patterns from quality scores and error history
    # ---------------------------------------------------------------------------
    PA_LEARNED_PATTERNS=""
    if [[ -f "${PA_QUALITY_DIR}/scores.jsonl" ]]; then
        # Read last 50 entries to extract recurring low-score areas
        PA_LEARNED_PATTERNS=$(tail -50 "${PA_QUALITY_DIR}/scores.jsonl" 2>/dev/null || echo "")
        local pattern_count
        pattern_count=$(_pa_line_count "$PA_LEARNED_PATTERNS")
        _pa_log "INFO" "Loaded ${pattern_count} quality score records"
    fi

    PA_LEARNED_ERRORS=""
    if [[ -f "${PA_ERRORS_DIR}/patterns.jsonl" ]]; then
        PA_LEARNED_ERRORS=$(tail -100 "${PA_ERRORS_DIR}/patterns.jsonl" 2>/dev/null || echo "")
        local error_count
        error_count=$(_pa_line_count "$PA_LEARNED_ERRORS")
        _pa_log "INFO" "Loaded ${error_count} error pattern records"
    fi

    # ---------------------------------------------------------------------------
    # Reset statistics
    # ---------------------------------------------------------------------------
    PA_STAT_TOTAL_AMPLIFIED=0
    PA_STAT_TOTAL_SCORE=0
    PA_STAT_ANTI_PATTERNS_INJECTED=0
    PA_STAT_QUALITY_RULES_INJECTED=0
    PA_STAT_FEW_SHOTS_INJECTED=0
    PA_STAT_ERROR_PREVENTIONS_INJECTED=0
    PA_STAT_DOMAIN_COUNTS=""
    PA_STAT_PHASE_COUNTS=""

    # Initialize stat file
    : > "$PA_STAT_FILE" 2>/dev/null || true

    PA_INITIALIZED="true"
    _pa_log "PASS" "v${PA_VERSION} initialized (domains=${PA_DOMAINS_DIR}, learning=${PA_LEARNING_DIR})"
    return 0
}

# =============================================================================
# 2. pa_amplify_prompt(phase, raw_prompt, domain, project_dir)
# =============================================================================
# Main amplification entry point. Applies all injection layers in sequence:
#   1. Domain context from JSON definitions
#   2. Anti-pattern rules (NEVER-DO)
#   3. Quality requirements (ALWAYS-DO)
#   4. Code style enforcement
#   5. Few-shot examples
#   6. Error prevention
# Returns the amplified prompt via stdout.
# =============================================================================
pa_amplify_prompt() {
    local phase="${1:?pa_amplify_prompt: phase required}"
    local raw_prompt="${2:?pa_amplify_prompt: raw_prompt required}"
    local domain="${3:-general}"
    local project_dir="${4:-.}"

    # Auto-init if not yet done
    if [[ "$PA_INITIALIZED" != "true" ]]; then
        pa_init || true
    fi

    _pa_log "INFO" "Amplifying prompt for phase=${phase} domain=${domain}"

    # Use a temp file to build the prompt incrementally.
    # This avoids nested $() subshells which lose stat counter increments.
    local tmpfile="/tmp/.pa_build_$$_${RANDOM}"
    printf '%s' "$raw_prompt" > "$tmpfile"

    # ---- Step 1: Inject domain context ----------------------------------------
    local domain_context=""
    domain_context=$(_pa_build_domain_context "$domain")
    if [[ -n "$domain_context" ]]; then
        printf '\n\n--- %s ---\n%s' "DOMAIN CONTEXT (${domain})" "$domain_context" >> "$tmpfile"
        _pa_log "INFO" "Injected domain context: ${#domain_context} chars"
    fi

    # ---- Step 2: Anti-patterns ------------------------------------------------
    # Run in same shell by reading/writing the temp file
    local current
    current=$(cat "$tmpfile")
    pa_inject_anti_patterns "$current" "$domain" > "$tmpfile"

    # ---- Step 3: Quality requirements -----------------------------------------
    local framework
    framework=$(_pa_detect_framework "$project_dir")
    current=$(cat "$tmpfile")
    pa_inject_quality_requirements "$current" "$framework" > "$tmpfile"

    # ---- Step 4: Code style enforcement ---------------------------------------
    current=$(cat "$tmpfile")
    pa_inject_code_style "$current" "$project_dir" > "$tmpfile"

    # ---- Step 5: Few-shot examples --------------------------------------------
    current=$(cat "$tmpfile")
    pa_inject_few_shot_examples "$current" "$phase" "$domain" > "$tmpfile"

    # ---- Step 6: Error prevention ---------------------------------------------
    current=$(cat "$tmpfile")
    pa_inject_error_prevention "$current" "$project_dir" > "$tmpfile"

    # Read final amplified prompt
    local amplified
    amplified=$(cat "$tmpfile")
    rm -f "$tmpfile" 2>/dev/null

    # ---- Score & log ----------------------------------------------------------
    local score
    score=$(pa_calculate_amplification_score "$raw_prompt" "$amplified")

    # Emit stats to temp file for parent-shell absorption (survives subshell)
    _pa_emit_stats "$score" \
        "$PA_STAT_ANTI_PATTERNS_INJECTED" \
        "$PA_STAT_QUALITY_RULES_INJECTED" \
        "$PA_STAT_FEW_SHOTS_INJECTED" \
        "$PA_STAT_ERROR_PREVENTIONS_INJECTED" \
        "$domain" "$phase"

    # Also update in-process counters (works when not in a subshell)
    (( PA_STAT_TOTAL_AMPLIFIED++ )) || true
    PA_STAT_TOTAL_SCORE=$(( PA_STAT_TOTAL_SCORE + score ))
    _pa_inc_domain_stat "$domain"
    _pa_inc_phase_stat "$phase"

    _pa_log "PASS" "Amplification complete: score=${score}/100, original=${#raw_prompt}ch -> amplified=${#amplified}ch"

    echo "$amplified"
}

# Build domain context string from the domain JSON file
_pa_build_domain_context() {
    local domain="$1"
    local domain_file="${PA_DOMAINS_DIR}/${domain}.json"
    local base_file="${PA_DOMAINS_DIR}/_base.json"

    # If the specific domain file does not exist, fall back to empty context
    if [[ ! -f "$domain_file" ]]; then
        _pa_log "WARN" "No domain file for '${domain}', skipping domain context injection"
        return 0
    fi

    local desc models_list keywords competitors
    desc=$(_pa_json_get "$domain_file" "description")
    keywords=$(_pa_json_get "$domain_file" "keywords")
    competitors=$(_pa_json_get "$domain_file" "competitors")

    # Build a compact model summary: model names with key field counts
    # PFP-114: LEGACY(dict {名前: 仕様}) / DEEP(list[dict] name+layer+fields) / 文字列list の全形式対応
    local models_summary=""
    local domain_scale=""
    if command -v python3 &>/dev/null; then
        models_summary=$(python3 -c "
import json, sys
try:
    with open(sys.argv[1]) as f:
        d = json.load(f)
    models = d.get('models') or {}
    parts = []
    if isinstance(models, dict):
        # LEGACY形式: {モデル名: {fields: dict, relations: list}}
        for name, spec in models.items():
            spec = spec if isinstance(spec, dict) else {}
            fields = spec.get('fields') or {}
            rels = spec.get('relations') or []
            parts.append('  - %s: %d fields, %d relations' % (name, len(fields), len(rels)))
    elif isinstance(models, list):
        # DEEP形式: [{name, layer, fields: list}] / 文字列list
        for x in models:
            if isinstance(x, dict):
                name = x.get('name') or x.get('id') or ''
                if not name:
                    continue
                fields = x.get('fields') or []
                layer = x.get('layer') or ''
                tag = ' [%s]' % layer if layer else ''
                parts.append('  - %s%s: %d fields' % (name, tag, len(fields)))
            elif x is not None:
                parts.append('  - %s' % x)
    print('\n'.join(parts))
except: pass
" "$domain_file" 2>/dev/null)
        # 業種規模(モデル+画面+API+業務ロジックの総項目数) — 可変予算の根拠
        domain_scale=$(python3 -c "
import json, sys
try:
    with open(sys.argv[1]) as f:
        d = json.load(f)
    n = 0
    for k in ('models', 'pages', 'apis', 'business_logic'):
        v = d.get(k)
        if isinstance(v, (list, dict)):
            n += len(v)
    print(n)
except: print(0)
" "$domain_file" 2>/dev/null)
    fi

    local context=""
    context+="Domain: ${domain}"
    [[ -n "$desc" ]] && context+="\nDescription: ${desc}"
    [[ -n "$competitors" ]] && context+="\nCompetitors: ${competitors}"
    [[ -n "$models_summary" ]] && context+="\nData Models:\n${models_summary}"

    # Merge _base.json model names for awareness
    if [[ -f "$base_file" ]] && command -v python3 &>/dev/null; then
        local base_models
        base_models=$(python3 -c "
import json
try:
    with open('${base_file}') as f:
        d = json.load(f)
    print(', '.join(d.get('models', {}).keys()))
except: pass
" 2>/dev/null)
        [[ -n "$base_models" ]] && context+="\nBase Models (always available): ${base_models}"
    fi

    # PFP-114: 1500字固定打ち切りを業種規模に応じて可変化
    #   基礎1500字 + 項目数x30字、上限 PA_DOMAIN_CTX_MAX_CHARS(既定6000字)
    local ctx_budget=1500
    if [[ "${domain_scale:-}" =~ ^[0-9]+$ ]] && (( domain_scale > 0 )); then
        ctx_budget=$(( 1500 + domain_scale * 30 ))
    fi
    local ctx_max="${PA_DOMAIN_CTX_MAX_CHARS:-6000}"
    [[ "$ctx_max" =~ ^[0-9]+$ ]] || ctx_max=6000
    (( ctx_budget > ctx_max )) && ctx_budget="$ctx_max"
    _pa_truncate "$context" "$ctx_budget"
}

# Detect primary framework from project files
_pa_detect_framework() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && echo "unknown" && return

    # Check for Next.js
    if [[ -f "${project_dir}/next.config.js" ]] || [[ -f "${project_dir}/next.config.ts" ]] || [[ -f "${project_dir}/next.config.mjs" ]]; then
        echo "nextjs"
        return
    fi

    # Check for package.json frameworks
    if [[ -f "${project_dir}/package.json" ]]; then
        local pkg_content
        pkg_content=$(cat "${project_dir}/package.json" 2>/dev/null || echo "")
        if [[ "$pkg_content" == *'"next"'* ]]; then
            echo "nextjs"; return
        elif [[ "$pkg_content" == *'"express"'* ]]; then
            echo "express"; return
        elif [[ "$pkg_content" == *'"react"'* ]]; then
            echo "react"; return
        elif [[ "$pkg_content" == *'"vue"'* ]]; then
            echo "vue"; return
        elif [[ "$pkg_content" == *'"svelte"'* ]]; then
            echo "svelte"; return
        elif [[ "$pkg_content" == *'"@angular/core"'* ]]; then
            echo "angular"; return
        fi
    fi

    # Check for Python frameworks
    if [[ -f "${project_dir}/requirements.txt" ]] || [[ -f "${project_dir}/pyproject.toml" ]]; then
        local py_content=""
        [[ -f "${project_dir}/requirements.txt" ]] && py_content=$(cat "${project_dir}/requirements.txt" 2>/dev/null)
        [[ -f "${project_dir}/pyproject.toml" ]] && py_content+=$(cat "${project_dir}/pyproject.toml" 2>/dev/null)
        if [[ "$py_content" == *"flask"* ]] || [[ "$py_content" == *"Flask"* ]]; then
            echo "flask"; return
        elif [[ "$py_content" == *"django"* ]] || [[ "$py_content" == *"Django"* ]]; then
            echo "django"; return
        elif [[ "$py_content" == *"fastapi"* ]] || [[ "$py_content" == *"FastAPI"* ]]; then
            echo "fastapi"; return
        fi
    fi

    # Check for Go
    if [[ -f "${project_dir}/go.mod" ]]; then
        echo "go"; return
    fi

    # Check for Rust
    if [[ -f "${project_dir}/Cargo.toml" ]]; then
        echo "rust"; return
    fi

    echo "unknown"
}

# =============================================================================
# 3. pa_inject_anti_patterns(prompt, domain)
# =============================================================================
# Appends domain-specific and universal NEVER-DO rules. Each rule is a concrete
# prohibition that prevents recurring quality issues.
# =============================================================================
pa_inject_anti_patterns() {
    local prompt="$1"
    local domain="${2:-general}"

    local rules=""
    local rule_count=0

    # ---------------------------------------------------------------------------
    # Universal anti-patterns (always injected)
    # ---------------------------------------------------------------------------
    rules+="
CRITICAL RULES - NEVER DO THE FOLLOWING:
[U-01] NEVER use the \`any\` type in TypeScript -- always provide explicit types or use \`unknown\` with type guards.
[U-02] NEVER leave empty catch blocks -- always log or re-throw with context.
[U-03] NEVER use \`console.log\` for production error handling -- use a structured logger.
[U-04] NEVER hardcode secrets, API keys, or credentials in source code -- use environment variables.
[U-05] NEVER commit .env files or files containing secrets to version control.
[U-06] NEVER use string concatenation for SQL queries -- always use parameterized queries or an ORM.
[U-07] NEVER trust user input -- always validate and sanitize on the server side.
[U-08] NEVER use synchronous file I/O in request handlers -- use async equivalents.
[U-09] NEVER ignore TypeScript compiler errors -- fix them, do not use @ts-ignore.
[U-10] NEVER return plain error messages that expose internal implementation details to end users."
    rule_count=10

    # ---------------------------------------------------------------------------
    # Domain-specific anti-patterns
    # ---------------------------------------------------------------------------
    case "$domain" in
        ecommerce)
            rules+="
[EC-01] NEVER hardcode prices or currency values -- always read from the database.
[EC-02] NEVER use floating-point arithmetic for currency -- use integer (cents) or Decimal.
[EC-03] NEVER allow negative stock quantities without explicit backorder logic.
[EC-04] NEVER process payments without idempotency keys.
[EC-05] NEVER display raw product IDs to customers -- use slugs or SKUs."
            rule_count=$((rule_count + 5))
            ;;
        healthcare)
            rules+="
[HC-01] NEVER log PII (patient names, SSN, insurance numbers) in plain text.
[HC-02] NEVER store patient data without encryption at rest (AES-256 minimum).
[HC-03] NEVER transmit patient records over unencrypted channels -- enforce TLS 1.2+.
[HC-04] NEVER allow bulk patient data export without audit logging and authorization.
[HC-05] NEVER display full patient identifiers on screen -- mask all but last 4 characters."
            rule_count=$((rule_count + 5))
            ;;
        hr)
            rules+="
[HR-01] NEVER expose salary information without role-based access control.
[HR-02] NEVER store unencrypted social security or tax identification numbers.
[HR-03] NEVER allow managers to view HR records outside their direct reports.
[HR-04] NEVER process payroll without double-entry verification."
            rule_count=$((rule_count + 4))
            ;;
        crm)
            rules+="
[CR-01] NEVER delete customer records -- always soft-delete with audit trail.
[CR-02] NEVER expose internal customer scoring to the end user.
[CR-03] NEVER allow bulk email sends without opt-out verification.
[CR-04] NEVER store credit card numbers in the CRM -- use payment processor tokens."
            rule_count=$((rule_count + 4))
            ;;
        lms)
            rules+="
[LM-01] NEVER reveal correct answers in the client-side payload for quizzes.
[LM-02] NEVER allow grade modification without instructor role verification.
[LM-03] NEVER serve downloadable content without checking enrollment status.
[LM-04] NEVER track student progress client-side only -- always persist server-side."
            rule_count=$((rule_count + 4))
            ;;
        booking|restaurant)
            rules+="
[BK-01] NEVER allow double-booking for the same time slot -- use database-level uniqueness.
[BK-02] NEVER accept reservations without capacity validation.
[BK-03] NEVER expose other customers' booking details in error messages.
[BK-04] NEVER process refunds without manager approval for amounts over threshold."
            rule_count=$((rule_count + 4))
            ;;
        inventory)
            rules+="
[IN-01] NEVER update stock counts without using database transactions.
[IN-02] NEVER allow stock to go negative without explicit backorder flag.
[IN-03] NEVER bypass the warehouse assignment when receiving goods.
[IN-04] NEVER skip serial number validation for tracked items."
            rule_count=$((rule_count + 4))
            ;;
        *)
            # General additional rules for unrecognized domains
            rules+="
[GN-01] NEVER omit input validation on API endpoints.
[GN-02] NEVER skip error boundaries in React component trees.
[GN-03] NEVER use default export for utility modules -- use named exports."
            rule_count=$((rule_count + 3))
            ;;
    esac

    # Load any domain-specific learned anti-patterns from error history
    if [[ -n "$PA_LEARNED_ERRORS" ]] && command -v python3 &>/dev/null; then
        local learned_rules
        learned_rules=$(python3 -c "
import json, sys
lines = sys.argv[1].strip().split('\n')
domain = sys.argv[2]
rules = []
for line in lines[-30:]:
    try:
        rec = json.loads(line)
        if rec.get('domain','') == domain or rec.get('domain','') == 'all':
            pat = rec.get('pattern','')
            if pat and len(rules) < 5:
                rules.append(f'[LEARNED] {pat}')
    except: pass
print('\n'.join(rules))
" "$PA_LEARNED_ERRORS" "$domain" 2>/dev/null)
        if [[ -n "$learned_rules" ]]; then
            rules+="
${learned_rules}"
            local extra
            extra=$(_pa_line_count "$learned_rules")
            rule_count=$((rule_count + extra))
        fi
    fi

    PA_STAT_ANTI_PATTERNS_INJECTED=$((PA_STAT_ANTI_PATTERNS_INJECTED + rule_count))
    _pa_log "INFO" "Injected ${rule_count} anti-pattern rules (domain=${domain})"

    _pa_append_section "$prompt" "ANTI-PATTERNS (NEVER DO)" "$rules"
}

# =============================================================================
# 4. pa_inject_quality_requirements(prompt, framework)
# =============================================================================
# Injects framework-aware quality rules that every code generation MUST follow.
# =============================================================================
pa_inject_quality_requirements() {
    local prompt="$1"
    local framework="${2:-unknown}"

    local rules=""
    local rule_count=0

    # ---------------------------------------------------------------------------
    # Universal quality requirements
    # ---------------------------------------------------------------------------
    rules+="
QUALITY REQUIREMENTS - ALWAYS DO THE FOLLOWING:
[Q-01] Always add proper TypeScript types for all function parameters and return values.
[Q-02] Always handle loading, error, and empty states in UI components.
[Q-03] Always use proper HTTP status codes (201 for creation, 204 for deletion, 400 for validation).
[Q-04] Always validate request bodies with a schema library (Zod, Joi, or equivalent).
[Q-05] Always write meaningful error messages that help debugging without exposing internals.
[Q-06] Always use database transactions for operations that modify multiple tables.
[Q-07] Always add appropriate indexes for columns used in WHERE, JOIN, and ORDER BY clauses.
[Q-08] Always implement pagination for list endpoints (limit + offset or cursor-based)."
    rule_count=8

    # ---------------------------------------------------------------------------
    # Framework-specific quality requirements
    # ---------------------------------------------------------------------------
    case "$framework" in
        nextjs)
            rules+="
--- Next.js Specific ---
[NX-01] Always use App Router (app/ directory) -- never use Pages Router for new code.
[NX-02] Always prefer Server Components by default -- only add 'use client' when needed.
[NX-03] Always use \`export const metadata\` or \`generateMetadata()\` for page SEO.
[NX-04] Always use Next.js Image component for images with explicit width/height.
[NX-05] Always use \`loading.tsx\` and \`error.tsx\` for route-level loading/error states.
[NX-06] Always use Server Actions for form mutations instead of client-side API calls.
[NX-07] Always use \`revalidatePath()\` or \`revalidateTag()\` after data mutations.
[NX-08] Always use route groups (parentheses folders) for layout organization.
[NX-09] Always import server-only utilities behind \`import 'server-only'\` to prevent client leaks.
[NX-10] Always use \`redirect()\` from 'next/navigation' for server-side redirects."
            rule_count=$((rule_count + 10))
            ;;
        express)
            rules+="
--- Express Specific ---
[EX-01] Always use the async error handler pattern (wrap route handlers in try/catch or use express-async-errors).
[EX-02] Always apply middleware in correct order: cors, helmet, body-parser, auth, routes, error handler.
[EX-03] Always validate request input with a middleware-based validator (express-validator or Zod).
[EX-04] Always use HTTP-only secure cookies for session tokens -- never store in localStorage.
[EX-05] Always set proper CORS origins -- never use \`origin: '*'\` in production.
[EX-06] Always apply rate limiting to authentication endpoints.
[EX-07] Always use helmet() for security headers."
            rule_count=$((rule_count + 7))
            ;;
        react)
            rules+="
--- React Specific ---
[RC-01] Always use hooks at the top level -- never inside conditions or loops.
[RC-02] Always provide a stable \`key\` prop for list items -- never use array index as key for dynamic lists.
[RC-03] Always memoize expensive computations with useMemo and callback refs with useCallback.
[RC-04] Always clean up effects (timers, subscriptions, listeners) in the useEffect cleanup function.
[RC-05] Always use Error Boundaries to catch rendering errors in subtrees.
[RC-06] Always co-locate component, styles, and tests in the same directory.
[RC-07] Always use React.lazy() with Suspense for code splitting heavy components."
            rule_count=$((rule_count + 7))
            ;;
        flask)
            rules+="
--- Flask/Python Specific ---
[FL-01] Always use Blueprints to organize routes by domain.
[FL-02] Always use type hints for all function signatures (PEP 484).
[FL-03] Always handle exceptions with app.errorhandler decorators.
[FL-04] Always use Flask-SQLAlchemy with proper session management (db.session.commit/rollback).
[FL-05] Always use environment-based configuration (Flask Config classes).
[FL-06] Always use CSRF protection with Flask-WTF for form endpoints."
            rule_count=$((rule_count + 6))
            ;;
        django)
            rules+="
--- Django Specific ---
[DJ-01] Always use class-based views for CRUD operations.
[DJ-02] Always run makemigrations and migrate together -- never skip migrations.
[DJ-03] Always use Django ORM querysets with select_related/prefetch_related to avoid N+1.
[DJ-04] Always validate with Django Forms or DRF Serializers -- never manual dict parsing.
[DJ-05] Always use Django's built-in CSRF middleware -- never disable it."
            rule_count=$((rule_count + 5))
            ;;
        fastapi)
            rules+="
--- FastAPI Specific ---
[FA-01] Always use Pydantic models for request/response validation.
[FA-02] Always use dependency injection for shared logic (database sessions, auth).
[FA-03] Always define proper response_model for all endpoints.
[FA-04] Always use async def for I/O-bound endpoints.
[FA-05] Always add OpenAPI tags and descriptions to all routers."
            rule_count=$((rule_count + 5))
            ;;
        go)
            rules+="
--- Go Specific ---
[GO-01] Always check and handle errors -- never use _ for error returns.
[GO-02] Always use context.Context for cancellation and timeouts.
[GO-03] Always use struct field tags for JSON serialization.
[GO-04] Always close resources with defer immediately after acquisition.
[GO-05] Always use interfaces for testability and dependency injection."
            rule_count=$((rule_count + 5))
            ;;
        vue)
            rules+="
--- Vue Specific ---
[VU-01] Always use Composition API (setup script) for new components.
[VU-02] Always use defineProps/defineEmits with TypeScript types.
[VU-03] Always use computed properties instead of methods for derived state.
[VU-04] Always use v-for with a unique :key binding."
            rule_count=$((rule_count + 4))
            ;;
        *)
            _pa_log "INFO" "No framework-specific rules for '${framework}'"
            ;;
    esac

    # Check for Prisma usage and add ORM-specific rules
    if [[ -f "${4:-$project_dir}/prisma/schema.prisma" ]] || [[ -f "${4:-.}/prisma/schema.prisma" ]]; then
        rules+="
--- Prisma ORM ---
[PR-01] Always use transactions (\`prisma.\$transaction\`) for multi-table writes.
[PR-02] Always use \`select\` or \`include\` to limit fetched fields -- never fetch all columns.
[PR-03] Always handle unique constraint violations with proper error codes (P2002).
[PR-04] Always use \`findUnique\` instead of \`findFirst\` when querying by unique fields."
        rule_count=$((rule_count + 4))
    fi

    PA_STAT_QUALITY_RULES_INJECTED=$((PA_STAT_QUALITY_RULES_INJECTED + rule_count))
    _pa_log "INFO" "Injected ${rule_count} quality rules (framework=${framework})"

    _pa_append_section "$prompt" "QUALITY REQUIREMENTS (ALWAYS DO)" "$rules"
}

# =============================================================================
# 5. pa_inject_code_style(prompt, project_dir)
# =============================================================================
# Detects existing code style from the project directory and enforces it.
# =============================================================================
pa_inject_code_style() {
    local prompt="$1"
    local project_dir="${2:-.}"

    local style_rules=""
    local detected_items=0

    # ---------------------------------------------------------------------------
    # Detect indentation style
    # ---------------------------------------------------------------------------
    local indent_style="spaces" indent_size=2
    if [[ -f "${project_dir}/.editorconfig" ]]; then
        local ec_content
        ec_content=$(cat "${project_dir}/.editorconfig" 2>/dev/null || echo "")
        if [[ "$ec_content" == *"indent_style = tab"* ]]; then
            indent_style="tabs"
        fi
        if [[ "$ec_content" =~ indent_size[[:space:]]*=[[:space:]]*([0-9]+) ]]; then
            indent_size="${BASH_REMATCH[1]}"
        fi
        (( detected_items++ )) || true
    elif [[ -f "${project_dir}/.prettierrc" ]] || [[ -f "${project_dir}/.prettierrc.json" ]]; then
        local prettier_file="${project_dir}/.prettierrc"
        [[ -f "${project_dir}/.prettierrc.json" ]] && prettier_file="${project_dir}/.prettierrc.json"
        if command -v python3 &>/dev/null; then
            local tab_w
            tab_w=$(python3 -c "
import json
try:
    with open('${prettier_file}') as f:
        d = json.load(f)
    if d.get('useTabs', False):
        print('tabs')
    print(d.get('tabWidth', 2))
except: print('2')
" 2>/dev/null)
            if [[ "$tab_w" == *"tabs"* ]]; then
                indent_style="tabs"
            fi
            indent_size="${tab_w##*$'\n'}"
        fi
        (( detected_items++ )) || true
    fi

    style_rules+="
CODE STYLE ENFORCEMENT:
[S-01] Indentation: use ${indent_style} with size ${indent_size}."

    # ---------------------------------------------------------------------------
    # Detect language and set naming conventions
    # ---------------------------------------------------------------------------
    local primary_lang="typescript"
    if [[ -f "${project_dir}/tsconfig.json" ]]; then
        primary_lang="typescript"
    elif [[ -f "${project_dir}/package.json" ]]; then
        primary_lang="javascript"
    elif [[ -f "${project_dir}/pyproject.toml" ]] || [[ -f "${project_dir}/requirements.txt" ]]; then
        primary_lang="python"
    elif [[ -f "${project_dir}/go.mod" ]]; then
        primary_lang="go"
    elif [[ -f "${project_dir}/Cargo.toml" ]]; then
        primary_lang="rust"
    fi

    case "$primary_lang" in
        typescript|javascript)
            style_rules+="
[S-02] Naming: camelCase for variables/functions, PascalCase for classes/components/types, UPPER_SNAKE_CASE for constants.
[S-03] File naming: kebab-case for utility files (e.g. auth-utils.ts), PascalCase for React components (e.g. UserProfile.tsx).
[S-04] Import order: 1) node builtins, 2) external packages, 3) internal aliases (@/), 4) relative imports. Blank line between groups.
[S-05] Export style: use named exports for utilities, default export only for page/layout components.
[S-06] String style: use single quotes for JS/TS strings (or match existing prettier config). Use template literals for interpolation."
            (( detected_items += 5 )) || true
            ;;
        python)
            style_rules+="
[S-02] Naming: snake_case for variables/functions/modules, PascalCase for classes, UPPER_SNAKE_CASE for constants.
[S-03] File naming: snake_case for all Python files (e.g. user_service.py).
[S-04] Import order: 1) stdlib, 2) third-party, 3) local. Use isort grouping.
[S-05] Docstrings: use Google-style docstrings for all public functions and classes.
[S-06] Type hints: annotate all public function signatures (PEP 484)."
            (( detected_items += 5 )) || true
            ;;
        go)
            style_rules+="
[S-02] Naming: camelCase for unexported, PascalCase for exported. Acronyms fully capitalized (e.g. HTTPHandler).
[S-03] File naming: snake_case (e.g. user_handler.go, user_handler_test.go).
[S-04] Package naming: short, lowercase, single word preferred.
[S-05] Error wrapping: use fmt.Errorf with %w for error chain context."
            (( detected_items += 4 )) || true
            ;;
        rust)
            style_rules+="
[S-02] Naming: snake_case for functions/variables, PascalCase for types/traits, SCREAMING_SNAKE_CASE for constants.
[S-03] File naming: snake_case (e.g. user_service.rs).
[S-04] Error handling: use thiserror for library errors, anyhow for application errors."
            (( detected_items += 3 )) || true
            ;;
    esac

    # ---------------------------------------------------------------------------
    # Detect and enforce existing patterns: semicolons, trailing commas, etc.
    # ---------------------------------------------------------------------------
    if [[ -f "${project_dir}/.eslintrc.json" ]] || [[ -f "${project_dir}/.eslintrc.js" ]] || [[ -f "${project_dir}/eslint.config.mjs" ]]; then
        style_rules+="
[S-07] ESLint configuration detected -- all generated code must pass the existing ESLint rules without errors."
        (( detected_items++ )) || true
    fi

    if [[ -f "${project_dir}/biome.json" ]]; then
        style_rules+="
[S-07] Biome configuration detected -- all generated code must pass the existing Biome linter and formatter."
        (( detected_items++ )) || true
    fi

    # ---------------------------------------------------------------------------
    # File organization rules
    # ---------------------------------------------------------------------------
    style_rules+="
[S-10] File organization: keep files under 300 lines. Split large files into focused modules.
[S-11] Directory structure: group by feature (not by type) when the project uses feature-based organization.
[S-12] Never create barrel files (index.ts) that re-export everything -- only create them when the project already uses this pattern."

    _pa_log "INFO" "Code style: detected ${detected_items} project conventions (lang=${primary_lang})"

    _pa_append_section "$prompt" "CODE STYLE ENFORCEMENT" "$style_rules"
}

# =============================================================================
# 6. pa_inject_few_shot_examples(prompt, phase, domain)
# =============================================================================
# Inserts concrete code examples matched to the current phase and domain.
# =============================================================================
pa_inject_few_shot_examples() {
    local prompt="$1"
    local phase="${2:-3}"
    local domain="${3:-general}"

    local examples=""
    local injected=0

    # ---------------------------------------------------------------------------
    # Try loading from learned prompts directory first
    # ---------------------------------------------------------------------------
    if [[ -d "$PA_PROMPTS_DIR" ]]; then
        local phase_file="${PA_PROMPTS_DIR}/phase_${phase}_${domain}.txt"
        local generic_phase_file="${PA_PROMPTS_DIR}/phase_${phase}.txt"

        if [[ -f "$phase_file" ]]; then
            local file_content
            file_content=$(head -80 "$phase_file" 2>/dev/null || echo "")
            if [[ -n "$file_content" ]]; then
                examples+="
(Loaded from learned patterns for ${domain} phase ${phase}):
${file_content}"
                (( injected++ )) || true
            fi
        elif [[ -f "$generic_phase_file" ]]; then
            local file_content
            file_content=$(head -80 "$generic_phase_file" 2>/dev/null || echo "")
            if [[ -n "$file_content" ]]; then
                examples+="
(Loaded from learned patterns for phase ${phase}):
${file_content}"
                (( injected++ )) || true
            fi
        fi
    fi

    # ---------------------------------------------------------------------------
    # Generate inline examples based on phase type
    # ---------------------------------------------------------------------------
    case "$phase" in
        3|3b|3e|code_generation)
            # Code generation phases -- inject API route + component examples
            if [[ $injected -eq 0 ]]; then
                examples+='
EXAMPLE - API Route Handler (App Router):
```typescript
// app/api/items/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { z } from "zod";

const createSchema = z.object({
  name: z.string().min(1).max(200),
  price: z.number().int().positive(),
});

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const validated = createSchema.parse(body);
    const item = await prisma.item.create({
      data: validated,
      select: { id: true, name: true, price: true, createdAt: true },
    });
    return NextResponse.json(item, { status: 201 });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { error: "Validation failed", details: error.errors },
        { status: 400 }
      );
    }
    console.error("[POST /api/items]", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}
```'
                (( injected++ )) || true
            fi
            ;;
        4|test|testing)
            # Testing phases -- inject test pattern examples
            if [[ $injected -eq 0 ]]; then
                examples+='
EXAMPLE - API Route Test Pattern:
```typescript
// __tests__/api/items.test.ts
import { describe, it, expect, beforeEach, vi } from "vitest";

describe("POST /api/items", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("creates an item with valid data", async () => {
    const body = { name: "Test Item", price: 1000 };
    const response = await fetch("/api/items", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    expect(response.status).toBe(201);
    const data = await response.json();
    expect(data.name).toBe("Test Item");
    expect(data.id).toBeDefined();
  });

  it("rejects invalid input with 400", async () => {
    const response = await fetch("/api/items", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ name: "", price: -1 }),
    });
    expect(response.status).toBe(400);
    const data = await response.json();
    expect(data.error).toBe("Validation failed");
  });
});
```'
                (( injected++ )) || true
            fi
            ;;
        2|api_design|api)
            # API design phases -- inject REST convention examples
            if [[ $injected -eq 0 ]]; then
                examples+='
EXAMPLE - RESTful API Convention:
```
GET    /api/items          -> List (paginated, filterable)
GET    /api/items/:id      -> Detail
POST   /api/items          -> Create (201)
PUT    /api/items/:id      -> Full update (200)
PATCH  /api/items/:id      -> Partial update (200)
DELETE /api/items/:id      -> Soft delete (204)

Standard query parameters:
  ?page=1&limit=20         -> Pagination
  ?sort=createdAt&order=desc -> Sorting
  ?search=keyword          -> Full-text search
  ?status=active           -> Filtering

Response envelope:
{
  "data": [...],
  "meta": { "total": 100, "page": 1, "limit": 20, "totalPages": 5 }
}
```'
                (( injected++ )) || true
            fi
            ;;
        1|design|architecture)
            # Architecture/design phase
            if [[ $injected -eq 0 ]]; then
                examples+="
EXAMPLE - Directory Structure Convention:
\`\`\`
app/
  (auth)/
    login/page.tsx
    register/page.tsx
  (dashboard)/
    layout.tsx
    page.tsx
    settings/page.tsx
  api/
    items/route.ts
    items/[id]/route.ts
components/
  ui/          # Reusable UI primitives (Button, Modal, etc.)
  features/    # Domain-specific composite components
lib/
  prisma.ts    # Prisma client singleton
  auth.ts      # Auth utilities
  validators/  # Zod schemas
types/
  index.ts     # Shared TypeScript types
\`\`\`"
                (( injected++ )) || true
            fi
            ;;
    esac

    # ---------------------------------------------------------------------------
    # Domain-specific example supplements
    # ---------------------------------------------------------------------------
    if [[ "$domain" == "ecommerce" ]] && [[ "$phase" == 3* ]]; then
        examples+='

EXAMPLE - Currency Handling:
```typescript
// lib/currency.ts
export function formatPrice(priceInCents: number): string {
  return new Intl.NumberFormat("ja-JP", {
    style: "currency",
    currency: "JPY",
  }).format(priceInCents);
}

// Always store prices as integers (cents/yen)
// Never: price: 19.99  (floating point!)
// Always: price: 1999  (integer cents)
```'
        (( injected++ )) || true
    fi

    if [[ "$domain" == "healthcare" ]] && [[ "$phase" == 3* ]]; then
        examples+='

EXAMPLE - PII Masking:
```typescript
// lib/pii.ts
export function maskPatientId(id: string): string {
  if (id.length <= 4) return "****";
  return "*".repeat(id.length - 4) + id.slice(-4);
}

// Always mask PII in logs
// logger.info(`Patient ${maskPatientId(patient.id)} record updated`);
// Never: logger.info(`Patient ${patient.name} at ${patient.address}`);
```'
        (( injected++ )) || true
    fi

    if [[ $injected -eq 0 ]]; then
        _pa_log "INFO" "No few-shot examples matched phase=${phase} domain=${domain}"
        echo "$prompt"
        return
    fi

    PA_STAT_FEW_SHOTS_INJECTED=$((PA_STAT_FEW_SHOTS_INJECTED + injected))
    _pa_log "INFO" "Injected ${injected} few-shot examples (phase=${phase}, domain=${domain})"

    local trimmed
    trimmed=$(_pa_truncate "$examples" "$PA_MAX_FEW_SHOT_CHARS")
    _pa_append_section "$prompt" "REFERENCE EXAMPLES" "$trimmed"
}

# =============================================================================
# 7. pa_inject_error_prevention(prompt, project_dir)
# =============================================================================
# Appends a "Common mistakes to avoid" section based on learned error history
# and framework-specific gotchas.
# =============================================================================
pa_inject_error_prevention() {
    local prompt="$1"
    local project_dir="${2:-.}"

    local prevention_rules=""
    local prevention_count=0

    # ---------------------------------------------------------------------------
    # Framework-specific gotchas
    # ---------------------------------------------------------------------------
    local framework
    framework=$(_pa_detect_framework "$project_dir")

    case "$framework" in
        nextjs)
            prevention_rules+="
COMMON MISTAKES TO AVOID:
[EP-01] Next.js 14+: Client components cannot be async. Do NOT use async function with 'use client'.
[EP-02] Next.js 14+: useSearchParams() must be wrapped in Suspense boundary.
[EP-03] Next.js 14+: fetch() in Server Components is cached by default. Use { cache: 'no-store' } or { next: { revalidate: N } } for dynamic data.
[EP-04] Next.js 14+: Params in dynamic routes are now a Promise. Use \`const params = await props.params\` in Server Components.
[EP-05] Next.js: 'use server' functions cannot be defined in client components -- put them in separate files.
[EP-06] Next.js: Do NOT import server-only modules (fs, prisma) in files that have 'use client'.
[EP-07] Prisma: Do NOT call prisma in the browser. Always call through Server Components, Server Actions, or Route Handlers.
[EP-08] Next.js: cookies() and headers() are now async in Next.js 15 -- await them."
            prevention_count=8
            ;;
        express)
            prevention_rules+="
COMMON MISTAKES TO AVOID:
[EP-01] Express: Forgetting next(err) in async route handlers causes requests to hang forever.
[EP-02] Express: res.json() does not end the function -- add return or use else blocks after it.
[EP-03] Express: Middleware order matters -- error handler MUST be registered last (4-param function).
[EP-04] Express: body-parser has a default 100kb limit -- increase for file uploads.
[EP-05] Express: Do NOT trust req.ip behind a proxy without setting 'trust proxy'."
            prevention_count=5
            ;;
        react)
            prevention_rules+="
COMMON MISTAKES TO AVOID:
[EP-01] React: setState in useEffect without a dependency array causes infinite re-renders.
[EP-02] React: Object/array dependencies in useEffect cause infinite loops -- use JSON.stringify or individual fields.
[EP-03] React: Forgetting to cancel async operations in useEffect cleanup causes memory leaks and state-updates-on-unmounted warnings.
[EP-04] React: Using context for frequently changing values (e.g. mouse position) causes full subtree re-renders."
            prevention_count=4
            ;;
        flask)
            prevention_rules+="
COMMON MISTAKES TO AVOID:
[EP-01] Flask: db.session.commit() must be in a try/except with db.session.rollback() in except.
[EP-02] Flask: Circular imports when importing models in __init__.py -- use app factory pattern.
[EP-03] Flask: request.json is None if Content-Type header is missing -- always use request.get_json(force=True) or check first."
            prevention_count=3
            ;;
        django)
            prevention_rules+="
COMMON MISTAKES TO AVOID:
[EP-01] Django: Calling .save() after .update() is redundant and causes an extra query.
[EP-02] Django: Accessing related objects in a loop without prefetch_related causes N+1 queries.
[EP-03] Django: Changing models without makemigrations causes silent data loss on deploy."
            prevention_count=3
            ;;
        fastapi)
            prevention_rules+="
COMMON MISTAKES TO AVOID:
[EP-01] FastAPI: Using def (sync) for database operations blocks the event loop -- use async def.
[EP-02] FastAPI: Dependency with yield must handle cleanup in finally, not after yield.
[EP-03] FastAPI: Background tasks cannot access request-scoped dependencies after response is sent."
            prevention_count=3
            ;;
        *)
            prevention_rules+="
COMMON MISTAKES TO AVOID:
[EP-01] Always check return values -- silently ignoring errors leads to data corruption.
[EP-02] Always close database connections/cursors -- leaked connections exhaust the pool.
[EP-03] Always validate environment variables at startup -- not when first used at runtime."
            prevention_count=3
            ;;
    esac

    # ---------------------------------------------------------------------------
    # TypeScript strict mode requirements (if project uses TS)
    # ---------------------------------------------------------------------------
    if [[ -f "${project_dir}/tsconfig.json" ]]; then
        local strict_mode="false"
        if command -v python3 &>/dev/null; then
            strict_mode=$(python3 -c "
import json
try:
    with open('${project_dir}/tsconfig.json') as f:
        d = json.load(f)
    co = d.get('compilerOptions', {})
    if co.get('strict', False):
        print('true')
    else:
        print('false')
except: print('false')
" 2>/dev/null)
        fi

        if [[ "$strict_mode" == "true" ]]; then
            prevention_rules+="
--- TypeScript Strict Mode Active ---
[TS-01] strictNullChecks is ON: every nullable value MUST be checked before use.
[TS-02] noImplicitAny is ON: every variable and parameter MUST have an explicit type.
[TS-03] strictFunctionTypes is ON: function types are checked contravariantly -- no unsafe casts."
            prevention_count=$((prevention_count + 3))
        else
            prevention_rules+="
[TS-01] TypeScript detected but strict mode is OFF -- still use explicit types for all public APIs."
            prevention_count=$((prevention_count + 1))
        fi
    fi

    # ---------------------------------------------------------------------------
    # Load learned error patterns from history
    # ---------------------------------------------------------------------------
    if [[ -n "$PA_LEARNED_ERRORS" ]] && command -v python3 &>/dev/null; then
        local history_rules
        history_rules=$(python3 -c "
import json, sys, collections
lines = sys.argv[1].strip().split('\n')
counter = collections.Counter()
for line in lines:
    try:
        rec = json.loads(line)
        msg = rec.get('message', '') or rec.get('error', '') or rec.get('pattern', '')
        if msg:
            # Normalize and count
            short = msg[:120]
            counter[short] += 1
    except: pass
# Show top 5 most frequent errors
for msg, count in counter.most_common(5):
    print(f'[HIST-{count}x] {msg}')
" "$PA_LEARNED_ERRORS" 2>/dev/null)
        if [[ -n "$history_rules" ]]; then
            prevention_rules+="
--- Historically Frequent Errors (from learning data) ---
${history_rules}"
            local extra
            extra=$(_pa_line_count "$history_rules")
            prevention_count=$((prevention_count + extra))
        fi
    fi

    # ---------------------------------------------------------------------------
    # Load learned quality failures from scores history
    # ---------------------------------------------------------------------------
    if [[ -n "$PA_LEARNED_PATTERNS" ]] && command -v python3 &>/dev/null; then
        local quality_warnings
        quality_warnings=$(python3 -c "
import json, sys
lines = sys.argv[1].strip().split('\n')
low_areas = {}
for line in lines:
    try:
        rec = json.loads(line)
        score = rec.get('score', 100)
        area = rec.get('area', '') or rec.get('axis', '')
        if score < 70 and area:
            low_areas[area] = low_areas.get(area, 0) + 1
    except: pass
# Show areas that repeatedly score low
for area, count in sorted(low_areas.items(), key=lambda x: -x[1])[:5]:
    if count >= 2:
        print(f'[QUALITY-WARN] Area \"{area}\" has scored below threshold {count} times -- pay extra attention.')
" "$PA_LEARNED_PATTERNS" 2>/dev/null)
        if [[ -n "$quality_warnings" ]]; then
            prevention_rules+="
--- Quality Gate Weak Areas ---
${quality_warnings}"
            local extra
            extra=$(_pa_line_count "$quality_warnings")
            prevention_count=$((prevention_count + extra))
        fi
    fi

    PA_STAT_ERROR_PREVENTIONS_INJECTED=$((PA_STAT_ERROR_PREVENTIONS_INJECTED + prevention_count))
    _pa_log "INFO" "Injected ${prevention_count} error prevention rules (framework=${framework})"

    _pa_append_section "$prompt" "ERROR PREVENTION" "$prevention_rules"
}

# =============================================================================
# 8. pa_calculate_amplification_score(original, amplified)
# =============================================================================
# Calculates a 0-100 score reflecting how much useful context was added.
# Higher scores indicate more comprehensive amplification.
# =============================================================================
pa_calculate_amplification_score() {
    local original="$1"
    local amplified="$2"

    local orig_len=${#original}
    local amp_len=${#amplified}

    # Guard against division by zero
    if (( orig_len == 0 )); then
        echo 0
        return
    fi

    local added_chars=$(( amp_len - orig_len ))
    local ratio=0

    # ---------------------------------------------------------------------------
    # Scoring dimensions (each contributes to the total):
    #   1. Content expansion ratio (0-25 pts)
    #   2. Section diversity (0-25 pts)
    #   3. Rule density (0-25 pts)
    #   4. Example presence (0-25 pts)
    # ---------------------------------------------------------------------------

    # 1. Content expansion ratio: ideal is 2x-5x the original size
    local expansion_score=0
    if (( added_chars > 0 )); then
        ratio=$(( (added_chars * 100) / orig_len ))
        if (( ratio >= 400 )); then
            expansion_score=25
        elif (( ratio >= 200 )); then
            expansion_score=22
        elif (( ratio >= 100 )); then
            expansion_score=18
        elif (( ratio >= 50 )); then
            expansion_score=14
        elif (( ratio >= 20 )); then
            expansion_score=10
        else
            expansion_score=5
        fi
    fi

    # 2. Section diversity: count how many distinct sections were injected
    local section_score=0
    local section_count=0
    [[ "$amplified" == *"ANTI-PATTERNS"* ]]       && (( section_count++ )) || true
    [[ "$amplified" == *"QUALITY REQUIREMENTS"* ]] && (( section_count++ )) || true
    [[ "$amplified" == *"CODE STYLE"* ]]           && (( section_count++ )) || true
    [[ "$amplified" == *"REFERENCE EXAMPLES"* ]]   && (( section_count++ )) || true
    [[ "$amplified" == *"ERROR PREVENTION"* ]]     && (( section_count++ )) || true
    [[ "$amplified" == *"DOMAIN CONTEXT"* ]]       && (( section_count++ )) || true

    case $section_count in
        6) section_score=25 ;;
        5) section_score=22 ;;
        4) section_score=18 ;;
        3) section_score=14 ;;
        2) section_score=10 ;;
        1) section_score=5  ;;
        0) section_score=0  ;;
    esac

    # 3. Rule density: count total rules injected (lines starting with [)
    local rule_score=0
    local rule_lines
    rule_lines=$(echo "$amplified" | grep -c '^\[' 2>/dev/null || echo "0")
    if (( rule_lines >= 30 )); then
        rule_score=25
    elif (( rule_lines >= 20 )); then
        rule_score=20
    elif (( rule_lines >= 15 )); then
        rule_score=16
    elif (( rule_lines >= 10 )); then
        rule_score=12
    elif (( rule_lines >= 5 )); then
        rule_score=8
    elif (( rule_lines >= 1 )); then
        rule_score=4
    fi

    # 4. Example presence: check for code blocks
    local example_score=0
    local code_block_count
    code_block_count=$(echo "$amplified" | grep -c '```' 2>/dev/null || echo "0")
    code_block_count=$(( code_block_count / 2 ))  # pairs of ``` = one block
    if (( code_block_count >= 3 )); then
        example_score=25
    elif (( code_block_count >= 2 )); then
        example_score=20
    elif (( code_block_count >= 1 )); then
        example_score=15
    fi

    local total_score=$(( expansion_score + section_score + rule_score + example_score ))

    # Clamp to 0-100
    (( total_score > 100 )) && total_score=100
    (( total_score < 0 )) && total_score=0

    # Log breakdown
    _pa_log "INFO" "Amplification score: ${total_score}/100 (expansion=${expansion_score} sections=${section_score} rules=${rule_score} examples=${example_score})"
    _pa_log "INFO" "  original=${orig_len}ch, amplified=${amp_len}ch, added=${added_chars}ch, ratio=${ratio}%, rules=${rule_lines}, codeblocks=${code_block_count}"

    # Warn if below threshold
    if (( total_score < PA_MIN_AMPLIFICATION_SCORE )); then
        _pa_log "WARN" "Amplification score ${total_score} is below minimum threshold ${PA_MIN_AMPLIFICATION_SCORE}"
    fi

    echo "$total_score"
}

# =============================================================================
# 9. pa_get_stats() - Return amplification statistics for the session
# =============================================================================
pa_get_stats() {
    if [[ "$PA_INITIALIZED" != "true" ]]; then
        echo "PromptAmplifier not initialized"
        return 1
    fi

    # Absorb any pending stats from subshell invocations
    pa_sync_stats

    local avg_score=0
    if (( PA_STAT_TOTAL_AMPLIFIED > 0 )); then
        avg_score=$(( PA_STAT_TOTAL_SCORE / PA_STAT_TOTAL_AMPLIFIED ))
    fi

    # Format domain distribution
    local domain_dist="none"
    if [[ -n "$PA_STAT_DOMAIN_COUNTS" ]]; then
        domain_dist=$(echo "$PA_STAT_DOMAIN_COUNTS" | tr '|' '\n' | sort -t: -k2 -rn | head -10)
    fi

    # Format phase distribution
    local phase_dist="none"
    if [[ -n "$PA_STAT_PHASE_COUNTS" ]]; then
        phase_dist=$(echo "$PA_STAT_PHASE_COUNTS" | tr '|' '\n' | sort -t: -k2 -rn | head -10)
    fi

    cat <<STATS_EOF
=============================================================================
  Prompt Amplifier Engine v${PA_VERSION} - Session Statistics
=============================================================================
  Total prompts amplified:      ${PA_STAT_TOTAL_AMPLIFIED}
  Average amplification score:  ${avg_score}/100

  Injections Breakdown:
    Anti-pattern rules:         ${PA_STAT_ANTI_PATTERNS_INJECTED}
    Quality rules:              ${PA_STAT_QUALITY_RULES_INJECTED}
    Few-shot examples:          ${PA_STAT_FEW_SHOTS_INJECTED}
    Error preventions:          ${PA_STAT_ERROR_PREVENTIONS_INJECTED}

  Domain Distribution:
$(echo "$domain_dist" | sed 's/^/    /')

  Phase Distribution:
$(echo "$phase_dist" | sed 's/^/    /')
=============================================================================
STATS_EOF
}

# =============================================================================
# Module self-test (runs when executed directly, not when sourced)
# =============================================================================
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    echo "=== Prompt Amplifier Engine v${PA_VERSION} - Self Test ==="
    pa_init

    echo ""
    echo "--- Test: amplify a simple prompt ---"
    local_test_prompt="Create a REST API for managing products with CRUD operations."
    result=$(pa_amplify_prompt "3" "$local_test_prompt" "ecommerce" ".")
    echo "Original length: ${#local_test_prompt}"
    echo "Amplified length: ${#result}"
    echo ""

    echo "--- Test: amplify for healthcare domain ---"
    local_test_prompt2="Build a patient registration form."
    result2=$(pa_amplify_prompt "3" "$local_test_prompt2" "healthcare" ".")
    echo "Original length: ${#local_test_prompt2}"
    echo "Amplified length: ${#result2}"
    echo ""

    echo "--- Session Stats ---"
    pa_get_stats
fi
