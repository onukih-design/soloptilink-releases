#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v304.0 - Blog/CMS Generator
# =============================================================================
# ブログ/CMS自動生成: 記事モデル/リッチエディタ/一覧/詳細/カテゴリ・タグ
#
# 全globals: BCG_ prefix
# =============================================================================

[[ -n "${_BLOG_CMS_GENERATOR_LOADED:-}" ]] && return 0
_BLOG_CMS_GENERATOR_LOADED=1

declare -g BCG_VERSION="304.0"
declare -g BCG_INITIALIZED=false
declare -g BCG_GENERATED_COUNT=0
declare -g ENABLE_BLOG_CMS_GENERATOR="${ENABLE_BLOG_CMS_GENERATOR:-true}"

readonly BCG_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly BCG_YELLOW="${CLR_YELLOW:-\033[0;33m}"
readonly BCG_RED="${CLR_RED:-\033[0;31m}"
readonly BCG_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly BCG_BOLD="${CLR_BOLD:-\033[1m}"
readonly BCG_NC="${CLR_NC:-\033[0m}"

_bcg_log() { echo -e "  ${BCG_CYAN}[BCG]${BCG_NC} $*" >&2; }
_bcg_ok()  { echo -e "  ${BCG_GREEN}[BCG] OK${BCG_NC} $*" >&2; }
_bcg_warn(){ echo -e "  ${BCG_YELLOW}[BCG] WARN${BCG_NC} $*" >&2; }
_bcg_err() { echo -e "  ${BCG_RED}[BCG] ERR${BCG_NC} $*" >&2; }

bcg_init() { BCG_INITIALIZED=true; BCG_GENERATED_COUNT=0; return 0; }
bcg_report() {
    [[ "$BCG_INITIALIZED" != "true" ]] && return 0
    echo -e "\n  ${BCG_BOLD}--- Blog/CMS Generator v${BCG_VERSION} ---${BCG_NC}" >&2
    echo -e "  生成コンポーネント数: ${BCG_GENERATED_COUNT}" >&2
}
bcg_score() {
    [[ "$BCG_INITIALIZED" != "true" ]] && { echo "0"; return; }
    local s=50; [[ $BCG_GENERATED_COUNT -ge 3 ]] && s=80; [[ $BCG_GENERATED_COUNT -ge 5 ]] && s=95; echo "$s"
}
bcg_init_message() { echo -e "  ${BCG_GREEN}v${BCG_VERSION} blog-cms-generator: ブログ/CMS自動生成${BCG_NC}" >&2; }

# =============================================================================
# _bcg_generate_article_model() - Article data model (Prisma)
# =============================================================================
_bcg_generate_article_model() {
    local project_dir="${1:-.}"
    _bcg_log "記事データモデル生成"

    local prisma_dir="${project_dir}/prisma"
    mkdir -p "$prisma_dir"

    local schema_file="${prisma_dir}/schema.prisma"
    local article_schema='
// --- Blog/CMS Models (v304.0) ---
model Article {
  id          String   @id @default(cuid())
  title       String
  slug        String   @unique
  excerpt     String?
  content     String   @db.Text
  coverImage  String?
  status      ArticleStatus @default(DRAFT)
  publishedAt DateTime?
  authorId    String
  author      User     @relation(fields: [authorId], references: [id])
  categories  CategoriesOnArticles[]
  tags        TagsOnArticles[]
  viewCount   Int      @default(0)
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}

enum ArticleStatus {
  DRAFT
  PUBLISHED
  ARCHIVED
}

model Category {
  id       String @id @default(cuid())
  name     String @unique
  slug     String @unique
  articles CategoriesOnArticles[]
}

model Tag {
  id       String @id @default(cuid())
  name     String @unique
  slug     String @unique
  articles TagsOnArticles[]
}

model CategoriesOnArticles {
  article    Article  @relation(fields: [articleId], references: [id], onDelete: Cascade)
  articleId  String
  category   Category @relation(fields: [categoryId], references: [id], onDelete: Cascade)
  categoryId String
  @@id([articleId, categoryId])
}

model TagsOnArticles {
  article   Article @relation(fields: [articleId], references: [id], onDelete: Cascade)
  articleId String
  tag       Tag     @relation(fields: [tagId], references: [id], onDelete: Cascade)
  tagId     String
  @@id([articleId, tagId])
}'

    if [[ -f "$schema_file" ]]; then
        if ! grep -q "model Article" "$schema_file" 2>/dev/null; then
            echo "$article_schema" >> "$schema_file"
            _bcg_ok "Articleモデルを既存スキーマに追加"
        else
            _bcg_warn "Articleモデルは既に存在"
        fi
    else
        cat > "$schema_file" <<SCHEMA_EOF
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

${article_schema}
SCHEMA_EOF
        _bcg_ok "新規スキーマファイル生成"
    fi

    BCG_GENERATED_COUNT=$((BCG_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# _bcg_generate_editor() - Rich text editor (TipTap)
# =============================================================================
_bcg_generate_editor() {
    local project_dir="${1:-.}"
    _bcg_log "リッチテキストエディタ生成"

    local comp_dir="${project_dir}/src/components/blog"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/RichEditor.tsx" <<'EOF'
'use client';
import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Link from '@tiptap/extension-link';
import Image from '@tiptap/extension-image';
import Placeholder from '@tiptap/extension-placeholder';
import { Bold, Italic, List, ListOrdered, Link2, Image as ImageIcon, Heading1, Heading2, Code, Quote, Undo, Redo } from 'lucide-react';

interface RichEditorProps {
  content?: string;
  onChange?: (html: string) => void;
  placeholder?: string;
}

function ToolbarButton({ onClick, active, children }: { onClick: () => void; active?: boolean; children: React.ReactNode }) {
  return (
    <button type="button" onClick={onClick}
      className={`p-2 rounded hover:bg-gray-100 ${active ? 'bg-gray-200 text-blue-600' : 'text-gray-600'}`}>
      {children}
    </button>
  );
}

export function RichEditor({ content = '', onChange, placeholder = '記事を書く...' }: RichEditorProps) {
  const editor = useEditor({
    extensions: [
      StarterKit,
      Link.configure({ openOnClick: false }),
      Image,
      Placeholder.configure({ placeholder }),
    ],
    content,
    onUpdate: ({ editor }) => { onChange?.(editor.getHTML()); },
  });

  if (!editor) return <div className="h-64 bg-gray-100 animate-pulse rounded-lg" />;

  const addLink = () => {
    const url = window.prompt('URL:');
    if (url) editor.chain().focus().setLink({ href: url }).run();
  };

  const addImage = () => {
    const url = window.prompt('画像URL:');
    if (url) editor.chain().focus().setImage({ src: url }).run();
  };

  return (
    <div className="border rounded-lg overflow-hidden">
      <div className="flex flex-wrap gap-1 p-2 border-b bg-gray-50">
        <ToolbarButton onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()} active={editor.isActive('heading', { level: 1 })}><Heading1 size={16} /></ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()} active={editor.isActive('heading', { level: 2 })}><Heading2 size={16} /></ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleBold().run()} active={editor.isActive('bold')}><Bold size={16} /></ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleItalic().run()} active={editor.isActive('italic')}><Italic size={16} /></ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleBulletList().run()} active={editor.isActive('bulletList')}><List size={16} /></ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleOrderedList().run()} active={editor.isActive('orderedList')}><ListOrdered size={16} /></ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleBlockquote().run()} active={editor.isActive('blockquote')}><Quote size={16} /></ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().toggleCodeBlock().run()} active={editor.isActive('codeBlock')}><Code size={16} /></ToolbarButton>
        <ToolbarButton onClick={addLink}><Link2 size={16} /></ToolbarButton>
        <ToolbarButton onClick={addImage}><ImageIcon size={16} /></ToolbarButton>
        <div className="flex-1" />
        <ToolbarButton onClick={() => editor.chain().focus().undo().run()}><Undo size={16} /></ToolbarButton>
        <ToolbarButton onClick={() => editor.chain().focus().redo().run()}><Redo size={16} /></ToolbarButton>
      </div>
      <EditorContent editor={editor} className="prose max-w-none p-4 min-h-[300px] focus:outline-none" />
    </div>
  );
}
EOF

    BCG_GENERATED_COUNT=$((BCG_GENERATED_COUNT + 1))
    _bcg_ok "リッチテキストエディタ生成完了"
    return 0
}

# =============================================================================
# _bcg_generate_list_page() - Article list with pagination/filters
# =============================================================================
_bcg_generate_list_page() {
    local project_dir="${1:-.}"
    _bcg_log "記事一覧ページ生成"

    local page_dir="${project_dir}/src/app/blog"
    mkdir -p "$page_dir"

    cat > "${page_dir}/page.tsx" <<'EOF'
'use client';
import useSWR from 'swr';
import Link from 'next/link';
import { useSearchParams, useRouter } from 'next/navigation';
import { Calendar, Eye, Tag, ChevronLeft, ChevronRight } from 'lucide-react';

const fetcher = (url: string) => fetch(url).then(r => r.json());

export default function BlogListPage() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const page = Number(searchParams.get('page') || '1');
  const category = searchParams.get('category') || '';

  const { data, isLoading, error } = useSWR(`/api/articles?page=${page}&category=${category}`, fetcher);

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <h1 className="text-3xl font-bold mb-8">ブログ</h1>

      {data?.categories && (
        <div className="flex flex-wrap gap-2 mb-8">
          <button onClick={() => router.push('/blog')}
            className={`px-3 py-1 rounded-full text-sm ${!category ? 'bg-blue-600 text-white' : 'bg-gray-100 hover:bg-gray-200'}`}>すべて</button>
          {data.categories.map((cat: any) => (
            <button key={cat.slug} onClick={() => router.push(`/blog?category=${cat.slug}`)}
              className={`px-3 py-1 rounded-full text-sm ${category === cat.slug ? 'bg-blue-600 text-white' : 'bg-gray-100 hover:bg-gray-200'}`}>{cat.name}</button>
          ))}
        </div>
      )}

      {isLoading && <div className="space-y-6">{[1,2,3].map(i => <div key={i} className="h-40 bg-gray-200 rounded-lg animate-pulse" />)}</div>}
      {error && <p className="text-red-600">読み込みエラー</p>}

      {data?.articles && (
        <div className="space-y-8">
          {data.articles.map((article: any) => (
            <article key={article.id} className="group">
              <Link href={`/blog/${article.slug}`} className="block">
                {article.coverImage && <img src={article.coverImage} alt={article.title} className="w-full h-48 object-cover rounded-lg mb-4" />}
                <h2 className="text-xl font-bold group-hover:text-blue-600 transition">{article.title}</h2>
                {article.excerpt && <p className="text-gray-600 mt-2 line-clamp-2">{article.excerpt}</p>}
                <div className="flex items-center gap-4 mt-3 text-sm text-gray-500">
                  <span className="flex items-center gap-1"><Calendar size={14} /> {new Date(article.publishedAt || article.createdAt).toLocaleDateString('ja-JP')}</span>
                  <span className="flex items-center gap-1"><Eye size={14} /> {article.viewCount || 0}</span>
                  {article.tags?.length > 0 && <span className="flex items-center gap-1"><Tag size={14} /> {article.tags.map((t: any) => t.tag?.name || t).join(', ')}</span>}
                </div>
              </Link>
            </article>
          ))}
          {data.articles.length === 0 && <p className="text-gray-500 text-center py-12">記事がありません</p>}
        </div>
      )}

      {data?.totalPages > 1 && (
        <div className="flex justify-center items-center gap-4 mt-12">
          <button onClick={() => router.push(`/blog?page=${page - 1}${category ? `&category=${category}` : ''}`)} disabled={page <= 1}
            className="flex items-center gap-1 px-4 py-2 border rounded-lg disabled:opacity-50 hover:bg-gray-50"><ChevronLeft size={16} /> 前へ</button>
          <span className="text-sm text-gray-500">{page} / {data.totalPages}</span>
          <button onClick={() => router.push(`/blog?page=${page + 1}${category ? `&category=${category}` : ''}`)} disabled={page >= data.totalPages}
            className="flex items-center gap-1 px-4 py-2 border rounded-lg disabled:opacity-50 hover:bg-gray-50">次へ <ChevronRight size={16} /></button>
        </div>
      )}
    </div>
  );
}
EOF

    BCG_GENERATED_COUNT=$((BCG_GENERATED_COUNT + 1))
    _bcg_ok "記事一覧ページ生成完了"
    return 0
}

# =============================================================================
# _bcg_generate_article_page() - Article detail page (SEO optimized)
# =============================================================================
_bcg_generate_article_page() {
    local project_dir="${1:-.}"
    _bcg_log "記事詳細ページ生成"

    local page_dir="${project_dir}/src/app/blog/[slug]"
    mkdir -p "$page_dir"

    cat > "${page_dir}/page.tsx" <<'EOF'
import { Metadata } from 'next';
import { notFound } from 'next/navigation';
import Link from 'next/link';
import { Calendar, Eye, ArrowLeft, Tag } from 'lucide-react';

async function getArticle(slug: string) {
  const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL || ''}/api/articles/${slug}`, { next: { revalidate: 60 } });
  if (!res.ok) return null;
  return res.json();
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const article = await getArticle(params.slug);
  if (!article) return { title: '記事が見つかりません' };
  return {
    title: article.title,
    description: article.excerpt || article.title,
    openGraph: { title: article.title, description: article.excerpt, images: article.coverImage ? [article.coverImage] : [] },
  };
}

export default async function ArticlePage({ params }: { params: { slug: string } }) {
  const article = await getArticle(params.slug);
  if (!article) notFound();

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <Link href="/blog" className="text-blue-600 hover:underline flex items-center gap-1 mb-8 text-sm"><ArrowLeft size={14} /> ブログ一覧へ</Link>
      {article.coverImage && <img src={article.coverImage} alt={article.title} className="w-full rounded-lg mb-8" />}
      <h1 className="text-3xl sm:text-4xl font-bold mb-4">{article.title}</h1>
      <div className="flex items-center gap-4 text-sm text-gray-500 mb-8">
        <span className="flex items-center gap-1"><Calendar size={14} /> {new Date(article.publishedAt || article.createdAt).toLocaleDateString('ja-JP')}</span>
        <span className="flex items-center gap-1"><Eye size={14} /> {article.viewCount || 0}回</span>
        {article.author?.name && <span>by {article.author.name}</span>}
      </div>
      {article.tags?.length > 0 && (
        <div className="flex flex-wrap gap-2 mb-8">
          {article.tags.map((t: any) => (
            <span key={t.tag?.id || t} className="bg-gray-100 text-gray-600 text-xs px-3 py-1 rounded-full flex items-center gap-1"><Tag size={12} /> {t.tag?.name || t}</span>
          ))}
        </div>
      )}
      <div className="prose max-w-none" dangerouslySetInnerHTML={{ __html: article.content }} />
    </div>
  );
}
EOF

    BCG_GENERATED_COUNT=$((BCG_GENERATED_COUNT + 1))
    _bcg_ok "記事詳細ページ生成完了"
    return 0
}

# =============================================================================
# _bcg_generate_category_tags() - Category and tag management
# =============================================================================
_bcg_generate_category_tags() {
    local project_dir="${1:-.}"
    _bcg_log "カテゴリ・タグ管理生成"

    local api_dir="${project_dir}/src/app/api/articles"
    mkdir -p "${api_dir}/categories" "${api_dir}/tags"

    cat > "${api_dir}/categories/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const categories = await prisma.category.findMany({ include: { _count: { select: { articles: true } } }, orderBy: { name: 'asc' } });
    return NextResponse.json({ data: categories });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch categories' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { name } = await req.json();
    if (!name) return NextResponse.json({ error: 'Name required' }, { status: 400 });
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    const category = await prisma.category.create({ data: { name, slug } });
    return NextResponse.json(category, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create category' }, { status: 500 });
  }
}
EOF

    cat > "${api_dir}/tags/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const tags = await prisma.tag.findMany({ include: { _count: { select: { articles: true } } }, orderBy: { name: 'asc' } });
    return NextResponse.json({ data: tags });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch tags' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { name } = await req.json();
    if (!name) return NextResponse.json({ error: 'Name required' }, { status: 400 });
    const slug = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
    const tag = await prisma.tag.create({ data: { name, slug } });
    return NextResponse.json(tag, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create tag' }, { status: 500 });
  }
}
EOF

    BCG_GENERATED_COUNT=$((BCG_GENERATED_COUNT + 2))
    _bcg_ok "カテゴリ・タグ管理生成完了"
    return 0
}

# =============================================================================
# Module Registration
# =============================================================================
_mr_register \
    --name "blog-cms-generator" \
    --version "304.0" \
    --description "ブログ/CMS自動生成（記事モデル/エディタ/一覧/詳細/カテゴリ）" \
    --init "bcg_init" \
    --report "bcg_report" \
    --score "bcg_score" \
    --enable-var "ENABLE_BLOG_CMS_GENERATOR" \
    --cli-flags "--blog-cms:--no-blog-cms" \
    --init-msg "bcg_init_message"
