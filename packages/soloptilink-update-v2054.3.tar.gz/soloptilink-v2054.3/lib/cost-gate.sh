#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v31.0 - Cost Gate (Pre-Execution Cost Estimation & Approval)
# =============================================================================
# Estimates API costs BEFORE execution and requires user approval.
# Shows clear cost breakdowns, identifies free phases, and enforces hard budget.
#
# Core Principle: "API利用料を事前に見せて承認を取る"
# - Free-first: scaffold, quality_gate, prompt_compile, domain_knowledge = $0.00
# - Estimate BEFORE spend: session-level + phase-level estimation
# - Hard gate: budget exceeded → halt (not just warn)
# - Learning: actual vs estimated → improve future accuracy
#
# Functions:
#   cg_init              - Initialize cost gate
#   cg_estimate_phase    - Estimate cost for a single phase
#   cg_estimate_session  - Estimate total session cost
#   cg_render_estimate   - Display ASCII cost estimate table
#   cg_request_approval  - Get user approval before execution
#   cg_pre_phase_gate    - Pre-phase budget enforcement
#   cg_record_actual     - Record actual cost for learning
#   cg_update_estimates  - Re-estimate remaining phases using actuals
#   cg_identify_free     - List phases that cost nothing
#   cg_report            - Post-session accuracy report
#   cg_export_json       - Export estimate data as JSON
#
# All globals use the CG_ prefix.
# =============================================================================

[[ -n "${_COST_GATE_LOADED:-}" ]] && return 0
_COST_GATE_LOADED=1

# ============================================================
# State
# ============================================================
declare -g CG_VERSION="31.0"
declare -g CG_ENABLED="true"
declare -g CG_AUTO_APPROVE="false"
declare -g CG_ESTIMATE_ONLY="false"
declare -g CG_SESSION_ID=""
declare -g CG_HARD_BUDGET="10.00"
declare -g CG_WARNING_THRESHOLD="5.00"
declare -g CG_USER_APPROVED="false"
declare -g CG_SESSION_ESTIMATE_TOTAL="0.00"
declare -g CG_SESSION_ACTUAL_TOTAL="0.00"
declare -g CG_ACCURACY_LOG=""
declare -g CG_LEARNING_RATIO="1.00"

# Per-phase estimates and actuals
declare -g -A CG_PHASE_ESTIMATE=()
declare -g -A CG_PHASE_ACTUAL=()
declare -g -A CG_PHASE_MODEL=()
declare -g -A CG_PHASE_TOKENS=()

# Phases that cost NOTHING (no Claude CLI call)
declare -g -A CG_FREE_PHASES=(
    [scaffold]=1
    [quality_gate]=1
    [quality_check_local]=1
    [prompt_compile]=1
    [domain_knowledge]=1
    [domain_knowledge_inject]=1
    [tech_stack_resolve]=1
    [governance_check_local]=1
    [coverage_gate]=1
    [smoke_test_local]=1
)

# Output ratio by phase type (output tokens / input tokens)
declare -g -A CG_OUTPUT_RATIO=(
    [requirements]="0.80"
    [competitive_research]="0.70"
    [prompt_expand]="0.80"
    [database]="0.60"
    [backend]="0.65"
    [api]="0.60"
    [implementation]="0.65"
    [frontend]="0.65"
    [testing]="0.50"
    [quality_check]="0.30"
    [security_audit]="0.40"
    [browser_test]="0.30"
    [documentation]="0.50"
    [deploy]="0.30"
    [hotfix]="0.60"
)

# ============================================================
# Internal logger
# ============================================================
_cg_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    [[ "$level" == "SUCCESS" ]] && color="${GREEN:-}"
    echo -e "  ${color}[COST-GATE]${NC:-} ${msg}" >&2
}

# ============================================================
# Arithmetic helper (bc with awk fallback)
# ============================================================
_cg_calc() {
    local expr="$1"
    if command -v bc &>/dev/null; then
        echo "scale=4; ${expr}" | bc 2>/dev/null | sed 's/^\./0./'
    elif command -v awk &>/dev/null; then
        awk "BEGIN{printf \"%.4f\", ${expr}}" 2>/dev/null
    else
        echo "0.0000"
    fi
}

_cg_calc2() {
    local expr="$1"
    if command -v bc &>/dev/null; then
        echo "scale=2; ${expr}" | bc 2>/dev/null | sed 's/^\./0./'
    elif command -v awk &>/dev/null; then
        awk "BEGIN{printf \"%.2f\", ${expr}}" 2>/dev/null
    else
        echo "0.00"
    fi
}

# ============================================================
# Initialize cost gate
# ============================================================
cg_init() {
    local session_id="${1:-${SESSION_ID:-unknown}}"
    local hard_budget="${2:-${COST_LIMIT:-10.00}}"

    CG_SESSION_ID="$session_id"
    CG_HARD_BUDGET="$hard_budget"
    CG_USER_APPROVED="false"
    CG_SESSION_ESTIMATE_TOTAL="0.00"
    CG_SESSION_ACTUAL_TOTAL="0.00"
    CG_LEARNING_RATIO="1.00"
    CG_PHASE_ESTIMATE=()
    CG_PHASE_ACTUAL=()
    CG_PHASE_MODEL=()
    CG_PHASE_TOKENS=()

    local obs_dir="${SESSION_LOG_DIR:-/tmp}/observatory"
    mkdir -p "$obs_dir" 2>/dev/null || true
    CG_ACCURACY_LOG="${obs_dir}/cost_gate_accuracy.jsonl"

    # Load historical learning ratio if available
    local history_file="${HOME}/.soloptilink/knowledge/cost_gate_history.json"
    if [[ -f "$history_file" ]]; then
        local saved_ratio
        saved_ratio=$(python3 -c "
import json, sys
try:
    with open('${history_file}') as f:
        d = json.load(f)
    print(d.get('learning_ratio', '1.00'))
except:
    print('1.00')
" 2>/dev/null)
        CG_LEARNING_RATIO="${saved_ratio:-1.00}"
    fi

    _cg_log "SUCCESS" "Cost Gate v31.0 初期化: 予算上限=\$${hard_budget}, 学習係数=${CG_LEARNING_RATIO}"
    return 0
}

# ============================================================
# Estimate cost for a single phase
# ============================================================
cg_estimate_phase() {
    local phase="${1:-unknown}"
    local model_tier="${2:-}"
    local custom_tokens="${3:-}"

    # Free phase check
    if [[ -n "${CG_FREE_PHASES[$phase]:-}" ]]; then
        CG_PHASE_ESTIMATE["$phase"]="0.00"
        CG_PHASE_MODEL["$phase"]="free"
        CG_PHASE_TOKENS["$phase"]="0"
        echo "0.00"
        return 0
    fi

    # Determine model tier from model-router if not specified
    if [[ -z "$model_tier" ]]; then
        if [[ "${MR_ENABLED:-false}" == "true" ]] && declare -p MR_PHASE_TIER &>/dev/null 2>&1; then
            model_tier="${MR_PHASE_TIER[$phase]:-balanced}"
        else
            model_tier="balanced"
        fi
    fi

    # Determine input tokens from context-budget if not specified
    local input_tokens
    if [[ -n "$custom_tokens" ]]; then
        input_tokens="$custom_tokens"
    elif declare -p CB_DEFAULT_BUDGETS &>/dev/null 2>&1; then
        input_tokens="${CB_DEFAULT_BUDGETS[$phase]:-20000}"
    else
        input_tokens="20000"
    fi

    # Calculate output tokens using phase-specific ratio
    local output_ratio="${CG_OUTPUT_RATIO[$phase]:-0.50}"
    local output_tokens
    output_tokens=$(_cg_calc "${input_tokens} * ${output_ratio}")
    output_tokens="${output_tokens%.*}"  # truncate to integer

    # Get pricing from model-router
    local input_price output_price
    if declare -p MR_PRICING_INPUT &>/dev/null 2>&1; then
        input_price="${MR_PRICING_INPUT[$model_tier]:-3.00}"
        output_price="${MR_PRICING_OUTPUT[$model_tier]:-15.00}"
    else
        case "$model_tier" in
            frontier) input_price="15.00"; output_price="75.00" ;;
            economy)  input_price="0.25";  output_price="1.25"  ;;
            *)        input_price="3.00";  output_price="15.00" ;;
        esac
    fi

    # Calculate cost: (input_tokens * input_price + output_tokens * output_price) / 1,000,000
    local cost
    cost=$(_cg_calc "(${input_tokens} * ${input_price} + ${output_tokens} * ${output_price}) / 1000000")

    # Apply learning ratio (adjust based on historical accuracy)
    cost=$(_cg_calc "${cost} * ${CG_LEARNING_RATIO}")
    cost=$(_cg_calc2 "${cost}")

    # Store
    CG_PHASE_ESTIMATE["$phase"]="$cost"
    CG_PHASE_MODEL["$phase"]="$model_tier"
    CG_PHASE_TOKENS["$phase"]="$input_tokens"

    echo "$cost"
    return 0
}

# ============================================================
# Estimate total session cost
# ============================================================
cg_estimate_session() {
    local pipeline_mode="${1:-full}"

    # Define phase list based on pipeline mode
    local -a phases
    case "$pipeline_mode" in
        quick)
            phases=(prompt_expand scaffold domain_knowledge tech_stack_resolve
                    prompt_compile backend frontend quality_gate)
            ;;
        hotfix)
            phases=(hotfix quality_check testing)
            ;;
        deep)
            phases=(prompt_expand competitive_research scaffold domain_knowledge
                    tech_stack_resolve prompt_compile database backend api
                    frontend quality_gate quality_check security_audit
                    testing documentation deploy)
            ;;
        *)
            # Full pipeline
            phases=(prompt_expand competitive_research scaffold domain_knowledge
                    tech_stack_resolve prompt_compile database backend api
                    frontend quality_gate quality_check testing
                    security_audit deploy)
            ;;
    esac

    local total="0.00"
    local phase_cost

    for phase in "${phases[@]}"; do
        phase_cost=$(cg_estimate_phase "$phase")
        total=$(_cg_calc2 "${total} + ${phase_cost}")
    done

    CG_SESSION_ESTIMATE_TOTAL="$total"
    echo "$total"
    return 0
}

# ============================================================
# Identify free phases (no API cost)
# ============================================================
cg_identify_free() {
    local -a free_list=()
    for phase in "${!CG_FREE_PHASES[@]}"; do
        free_list+=("$phase")
    done
    echo "${free_list[*]}"
}

# ============================================================
# Render ASCII cost estimate table
# ============================================================
cg_render_estimate() {
    local budget="${CG_HARD_BUDGET:-10.00}"
    local total="${CG_SESSION_ESTIMATE_TOTAL:-0.00}"
    local remaining
    remaining=$(_cg_calc2 "${budget} - ${total}")

    # Budget percentage
    local pct
    pct=$(_cg_calc "(${total} / ${budget}) * 100")
    pct="${pct%.*}"

    # Color selection based on budget usage
    local color="${GREEN:-}"
    [[ "${pct:-0}" -ge 50 ]] && color="${YELLOW:-}"
    [[ "${pct:-0}" -ge 80 ]] && color="${RED:-}"

    echo ""
    echo -e "  ${BOLD:-}┌──────────────────────────────────────────────────┐${NC:-}"
    echo -e "  ${BOLD:-}│${NC:-}  ${MAGENTA:-}事前コスト見積もり (v31.0 Cost Gate)${NC:-}           ${BOLD:-}│${NC:-}"
    echo -e "  ${BOLD:-}├──────────────────────────────────────────────────┤${NC:-}"
    printf "  ${BOLD:-}│${NC:-}  %-24s %-10s %10s  ${BOLD:-}│${NC:-}\n" "フェーズ" "モデル" "見積もり"
    echo -e "  ${BOLD:-}│${NC:-}  ──────────────────────── ────────── ──────────  ${BOLD:-}│${NC:-}"

    # Sort phases by pipeline order and display
    local -a sorted_phases=()
    for phase in "${!CG_PHASE_ESTIMATE[@]}"; do
        sorted_phases+=("$phase")
    done

    # Display phases
    for phase in "${sorted_phases[@]}"; do
        local est="${CG_PHASE_ESTIMATE[$phase]:-0.00}"
        local model="${CG_PHASE_MODEL[$phase]:-unknown}"
        local display_model
        local line_color="${NC:-}"

        case "$model" in
            free)      display_model="(無料)"; line_color="${DIM:-}" ;;
            frontier)  display_model="Opus"   ;;
            balanced)  display_model="Sonnet" ;;
            economy)   display_model="Haiku"  ;;
            *)         display_model="$model" ;;
        esac

        # Phase name translation
        local display_phase
        case "$phase" in
            prompt_expand)           display_phase="プロンプト展開" ;;
            competitive_research)    display_phase="競合調査" ;;
            scaffold)                display_phase="スキャフォルド" ;;
            domain_knowledge*)       display_phase="ドメイン知識注入" ;;
            tech_stack_resolve)      display_phase="技術スタック解決" ;;
            prompt_compile)          display_phase="プロンプトコンパイル" ;;
            database)                display_phase="データベース設計" ;;
            backend)                 display_phase="バックエンド実装" ;;
            api)                     display_phase="API実装" ;;
            frontend)                display_phase="フロントエンド実装" ;;
            quality_gate)            display_phase="品質ゲート" ;;
            quality_check*)          display_phase="品質チェック" ;;
            testing)                 display_phase="テスト" ;;
            security_audit)          display_phase="セキュリティ監査" ;;
            deploy)                  display_phase="デプロイ" ;;
            hotfix)                  display_phase="ホットフィックス" ;;
            documentation)           display_phase="ドキュメント" ;;
            governance_check*)       display_phase="ガバナンスチェック" ;;
            coverage_gate)           display_phase="カバレッジゲート" ;;
            smoke_test*)             display_phase="スモークテスト" ;;
            *)                       display_phase="$phase" ;;
        esac

        printf "  ${BOLD:-}│${NC:-}  ${line_color}%-24s %-10s \$%9s${NC:-}  ${BOLD:-}│${NC:-}\n" \
            "$display_phase" "$display_model" "$est"
    done

    echo -e "  ${BOLD:-}│${NC:-}  ──────────────────────── ────────── ──────────  ${BOLD:-}│${NC:-}"
    printf "  ${BOLD:-}│${NC:-}  ${BOLD:-}%-24s %-10s ${color}\$%9s${NC:-}  ${BOLD:-}│${NC:-}\n" \
        "合計見積もり" "" "$total"
    printf "  ${BOLD:-}│${NC:-}  %-24s %-10s \$%4s / \$%s  ${BOLD:-}│${NC:-}\n" \
        "予算残高" "" "$remaining" "$budget"
    echo -e "  ${BOLD:-}│${NC:-}                                                  ${BOLD:-}│${NC:-}"

    # Warning if high cost
    if [[ "${pct:-0}" -ge 80 ]]; then
        echo -e "  ${BOLD:-}│${NC:-}  ${RED:-}!! 見積もりが予算の${pct}%に達しています !!${NC:-}         ${BOLD:-}│${NC:-}"
    elif [[ "${pct:-0}" -ge 50 ]]; then
        echo -e "  ${BOLD:-}│${NC:-}  ${YELLOW:-}! 予算の${pct}%を使用する見込みです${NC:-}              ${BOLD:-}│${NC:-}"
    fi

    local warn_exceeded="false"
    if command -v awk &>/dev/null; then
        warn_exceeded=$(awk "BEGIN{print (${total} > ${CG_WARNING_THRESHOLD}) ? \"true\" : \"false\"}" 2>/dev/null)
    fi
    if [[ "$warn_exceeded" == "true" ]]; then
        echo -e "  ${BOLD:-}│${NC:-}  ${YELLOW:-}! 警告閾値(\$${CG_WARNING_THRESHOLD})を超過${NC:-}                      ${BOLD:-}│${NC:-}"
    fi

    echo -e "  ${BOLD:-}│${NC:-}  ${DIM:-}* 実際のコストは±30%程度変動する場合があります${NC:-}  ${BOLD:-}│${NC:-}"
    echo -e "  ${BOLD:-}└──────────────────────────────────────────────────┘${NC:-}"
    echo ""
}

# ============================================================
# Request user approval before execution
# ============================================================
cg_request_approval() {
    # Auto-approve mode
    if [[ "${CG_AUTO_APPROVE}" == "true" ]]; then
        CG_USER_APPROVED="true"
        _cg_log "SUCCESS" "自動承認モード: 見積もり \$${CG_SESSION_ESTIMATE_TOTAL}"
        return 0
    fi

    # Estimate-only mode
    if [[ "${CG_ESTIMATE_ONLY}" == "true" ]]; then
        _cg_log "INFO" "見積もりのみモード: 実行はスキップ"
        CG_USER_APPROVED="false"
        return 1
    fi

    # Budget exceeded - warn strongly
    local exceeded="false"
    if command -v awk &>/dev/null; then
        exceeded=$(awk "BEGIN{print (${CG_SESSION_ESTIMATE_TOTAL} > ${CG_HARD_BUDGET}) ? \"true\" : \"false\"}" 2>/dev/null)
    fi

    if [[ "$exceeded" == "true" ]]; then
        echo -e "  ${RED:-}${BOLD:-}!! 警告: 見積もり(\$${CG_SESSION_ESTIMATE_TOTAL})が予算上限(\$${CG_HARD_BUDGET})を超えています !!${NC:-}"
        echo -e "  ${YELLOW:-}モデルダウングレードや一部フェーズ省略を検討してください${NC:-}"
        echo ""
    fi

    # Interactive approval
    local response=""
    read -r -p "  進めますか？ [Y/n]: " response < /dev/tty 2>/dev/null || response="y"

    case "${response,,}" in
        n|no|いいえ)
            CG_USER_APPROVED="false"
            _cg_log "WARN" "ユーザーが実行を拒否しました"
            return 1
            ;;
        *)
            CG_USER_APPROVED="true"
            _cg_log "SUCCESS" "ユーザー承認完了: 見積もり \$${CG_SESSION_ESTIMATE_TOTAL}"
            return 0
            ;;
    esac
}

# ============================================================
# Pre-phase budget gate (called before each Claude CLI call)
# ============================================================
cg_pre_phase_gate() {
    local phase="${1:-unknown}"

    [[ "${CG_ENABLED}" != "true" ]] && return 0

    # Free phase - always allow
    if [[ -n "${CG_FREE_PHASES[$phase]:-}" ]]; then
        return 0
    fi

    # Calculate: actual so far + estimated remaining
    local actual_so_far="${CG_SESSION_ACTUAL_TOTAL:-0.00}"
    local estimated_remaining="0.00"

    for p in "${!CG_PHASE_ESTIMATE[@]}"; do
        # Skip phases that already have actuals
        if [[ -n "${CG_PHASE_ACTUAL[$p]:-}" ]]; then
            continue
        fi
        local est="${CG_PHASE_ESTIMATE[$p]:-0.00}"
        estimated_remaining=$(_cg_calc2 "${estimated_remaining} + ${est}")
    done

    local projected_total
    projected_total=$(_cg_calc2 "${actual_so_far} + ${estimated_remaining}")

    # Check against hard budget
    local exceeded="false"
    if command -v awk &>/dev/null; then
        exceeded=$(awk "BEGIN{print (${projected_total} > ${CG_HARD_BUDGET}) ? \"true\" : \"false\"}" 2>/dev/null)
    fi

    if [[ "$exceeded" == "true" ]]; then
        _cg_log "WARN" "予算超過見込み: 実績\$${actual_so_far} + 残見積\$${estimated_remaining} = \$${projected_total} > \$${CG_HARD_BUDGET}"

        # Try model downgrade first
        local current_tier="${CG_PHASE_MODEL[$phase]:-balanced}"
        if [[ "$current_tier" == "frontier" ]]; then
            _cg_log "WARN" "モデルダウングレード: ${phase} Opus → Sonnet"
            CG_PHASE_MODEL["$phase"]="balanced"
            # Recalculate this phase estimate
            cg_estimate_phase "$phase" "balanced" > /dev/null
            return 0
        elif [[ "$current_tier" == "balanced" ]]; then
            _cg_log "WARN" "モデルダウングレード: ${phase} Sonnet → Haiku"
            CG_PHASE_MODEL["$phase"]="economy"
            cg_estimate_phase "$phase" "economy" > /dev/null
            return 0
        fi

        # Already at lowest tier - halt with user prompt
        echo ""
        echo -e "  ${RED:-}${BOLD:-}予算超過警告${NC:-}"
        echo -e "  実績: \$${actual_so_far} / 予算: \$${CG_HARD_BUDGET}"
        echo -e "  残フェーズ見積もり: \$${estimated_remaining}"
        echo ""

        local response=""
        read -r -p "  予算を超過しますが続行しますか？ [y/N]: " response < /dev/tty 2>/dev/null || response="n"

        case "${response,,}" in
            y|yes|はい)
                _cg_log "WARN" "ユーザー承認で予算超過続行: ${phase}"
                return 0
                ;;
            *)
                _cg_log "ERROR" "予算超過により停止: ${phase}"
                return 1
                ;;
        esac
    fi

    return 0
}

# ============================================================
# Record actual cost after phase completion
# ============================================================
cg_record_actual() {
    local phase="${1:-unknown}"
    local actual_cost="${2:-0.00}"

    CG_PHASE_ACTUAL["$phase"]="$actual_cost"
    CG_SESSION_ACTUAL_TOTAL=$(_cg_calc2 "${CG_SESSION_ACTUAL_TOTAL} + ${actual_cost}")

    # Log accuracy
    local estimated="${CG_PHASE_ESTIMATE[$phase]:-0.00}"
    local accuracy_pct="100"
    if command -v awk &>/dev/null && [[ "$estimated" != "0.00" ]]; then
        accuracy_pct=$(awk "BEGIN{printf \"%.0f\", (${actual_cost} / ${estimated}) * 100}" 2>/dev/null || echo "100")
    fi

    if [[ -n "$CG_ACCURACY_LOG" ]]; then
        local ts
        ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
        printf '{"timestamp":"%s","phase":"%s","estimated":"%s","actual":"%s","accuracy_pct":%s}\n' \
            "$ts" "$phase" "$estimated" "$actual_cost" "$accuracy_pct" \
            >> "$CG_ACCURACY_LOG" 2>/dev/null || true
    fi

    return 0
}

# ============================================================
# Update remaining estimates using actual-vs-estimated ratio
# ============================================================
cg_update_estimates() {
    local total_estimated="0.00"
    local total_actual="0.00"
    local completed_count=0

    for phase in "${!CG_PHASE_ACTUAL[@]}"; do
        local est="${CG_PHASE_ESTIMATE[$phase]:-0.00}"
        local act="${CG_PHASE_ACTUAL[$phase]:-0.00}"

        # Skip free phases
        [[ "$est" == "0.00" ]] && continue

        total_estimated=$(_cg_calc2 "${total_estimated} + ${est}")
        total_actual=$(_cg_calc2 "${total_actual} + ${act}")
        completed_count=$((completed_count + 1))
    done

    # Need at least 2 completed phases to learn
    if [[ "$completed_count" -ge 2 && "$total_estimated" != "0.00" ]]; then
        local ratio
        ratio=$(_cg_calc "${total_actual} / ${total_estimated}")
        CG_LEARNING_RATIO="$ratio"

        # Recalculate remaining phase estimates
        for phase in "${!CG_PHASE_ESTIMATE[@]}"; do
            [[ -n "${CG_PHASE_ACTUAL[$phase]:-}" ]] && continue  # Skip completed
            [[ -n "${CG_FREE_PHASES[$phase]:-}" ]] && continue    # Skip free

            local original="${CG_PHASE_ESTIMATE[$phase]:-0.00}"
            local adjusted
            adjusted=$(_cg_calc2 "${original} * ${ratio}")
            CG_PHASE_ESTIMATE["$phase"]="$adjusted"
        done

        # Recalculate session total
        local new_total="0.00"
        for phase in "${!CG_PHASE_ESTIMATE[@]}"; do
            if [[ -n "${CG_PHASE_ACTUAL[$phase]:-}" ]]; then
                new_total=$(_cg_calc2 "${new_total} + ${CG_PHASE_ACTUAL[$phase]}")
            else
                new_total=$(_cg_calc2 "${new_total} + ${CG_PHASE_ESTIMATE[$phase]:-0.00}")
            fi
        done
        CG_SESSION_ESTIMATE_TOTAL="$new_total"

        _cg_log "INFO" "見積もり更新: 学習係数=${ratio}, 新合計=\$${new_total}"
    fi
}

# ============================================================
# Post-session accuracy report
# ============================================================
cg_report() {
    echo ""
    echo -e "  ${BOLD:-}=== Cost Gate 精度レポート ===${NC:-}"
    echo ""
    printf "  %-24s %10s %10s %8s\n" "フェーズ" "見積もり" "実績" "精度"
    echo "  ──────────────────────── ────────── ────────── ────────"

    for phase in "${!CG_PHASE_ESTIMATE[@]}"; do
        local est="${CG_PHASE_ESTIMATE[$phase]:-0.00}"
        local act="${CG_PHASE_ACTUAL[$phase]:--.--}"
        local acc="--"

        if [[ -n "${CG_PHASE_ACTUAL[$phase]:-}" && "$est" != "0.00" ]]; then
            acc=$(awk "BEGIN{printf \"%.0f%%\", (${act} / ${est}) * 100}" 2>/dev/null || echo "--")
        elif [[ "$est" == "0.00" ]]; then
            acc="N/A"
        fi

        printf "  %-24s \$%9s \$%9s %8s\n" "$phase" "$est" "$act" "$acc"
    done

    echo "  ──────────────────────── ────────── ────────── ────────"
    printf "  %-24s \$%9s \$%9s %8s\n" "合計" \
        "${CG_SESSION_ESTIMATE_TOTAL}" "${CG_SESSION_ACTUAL_TOTAL}" \
        "$(awk "BEGIN{printf \"%.0f%%\", (${CG_SESSION_ACTUAL_TOTAL:-0} / ${CG_SESSION_ESTIMATE_TOTAL:-1}) * 100}" 2>/dev/null || echo "--")"
    echo ""

    # Save learning ratio for next session
    local history_file="${HOME}/.soloptilink/knowledge/cost_gate_history.json"
    mkdir -p "$(dirname "$history_file")" 2>/dev/null || true
    local ts
    ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    cat > "$history_file" 2>/dev/null <<EOF
{
  "last_updated": "${ts}",
  "session_id": "${CG_SESSION_ID}",
  "learning_ratio": "${CG_LEARNING_RATIO}",
  "estimated_total": "${CG_SESSION_ESTIMATE_TOTAL}",
  "actual_total": "${CG_SESSION_ACTUAL_TOTAL}"
}
EOF
    _cg_log "SUCCESS" "学習データ保存: ${history_file}"
}

# ============================================================
# Export as JSON
# ============================================================
# ============================================================
# v35.0: Save learning data to persistent storage
# ============================================================
cg_save_learning() {
    local history_file="${HOME}/.soloptilink/knowledge/cost_gate_history.json"
    mkdir -p "$(dirname "$history_file")" 2>/dev/null || true

    # Compute final accuracy
    local total_est="$CG_SESSION_ESTIMATE_TOTAL"
    local total_act="$CG_SESSION_ACTUAL_TOTAL"
    local accuracy="0"
    if [[ "$total_est" != "0.00" && "$total_est" != "0" ]]; then
        accuracy=$(awk "BEGIN{printf \"%.0f\", (${total_act} / ${total_est}) * 100}" 2>/dev/null || echo "0")
    fi

    # Save learning ratio and session history
    cat > "$history_file" <<CGJSON
{
  "learning_ratio": "${CG_LEARNING_RATIO}",
  "last_session": "${CG_SESSION_ID}",
  "last_estimated": "${total_est}",
  "last_actual": "${total_act}",
  "last_accuracy_pct": "${accuracy}",
  "updated_at": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
}
CGJSON

    _cg_log "SUCCESS" "学習データ保存: ratio=${CG_LEARNING_RATIO}, accuracy=${accuracy}%"
    return 0
}

# ============================================================
# v35.0: Request model downgrade when budget is tight
# Returns: downgrade tier name (economy/balanced) or empty
# ============================================================
cg_suggest_downgrade() {
    local remaining_budget
    remaining_budget=$(_cg_calc2 "${CG_HARD_BUDGET} - ${CG_SESSION_ACTUAL_TOTAL}")
    local remaining_estimate
    remaining_estimate=$(_cg_calc2 "${CG_SESSION_ESTIMATE_TOTAL} - ${CG_SESSION_ACTUAL_TOTAL}")

    # If remaining budget < 50% of remaining estimate, suggest economy
    if [[ -n "$remaining_budget" && -n "$remaining_estimate" ]] && \
       command -v bc &>/dev/null; then
        local should_downgrade
        should_downgrade=$(echo "${remaining_budget} < (${remaining_estimate} * 0.5)" | bc 2>/dev/null || echo "0")
        if [[ "$should_downgrade" == "1" ]]; then
            echo "economy"
            return 0
        fi

        # If remaining budget < 80% of remaining estimate, suggest balanced
        local should_balanced
        should_balanced=$(echo "${remaining_budget} < (${remaining_estimate} * 0.8)" | bc 2>/dev/null || echo "0")
        if [[ "$should_balanced" == "1" ]]; then
            echo "balanced"
            return 0
        fi
    fi

    echo ""
    return 0
}

cg_export_json() {
    local output_file="${1:-}"
    local json="{"
    json+="\"version\":\"${CG_VERSION}\","
    json+="\"session_id\":\"${CG_SESSION_ID}\","
    json+="\"hard_budget\":\"${CG_HARD_BUDGET}\","
    json+="\"session_estimate\":\"${CG_SESSION_ESTIMATE_TOTAL}\","
    json+="\"session_actual\":\"${CG_SESSION_ACTUAL_TOTAL}\","
    json+="\"learning_ratio\":\"${CG_LEARNING_RATIO}\","
    json+="\"user_approved\":\"${CG_USER_APPROVED}\","
    json+="\"phases\":{"

    local first=1
    for phase in "${!CG_PHASE_ESTIMATE[@]}"; do
        [[ "$first" -eq 0 ]] && json+=","
        json+="\"${phase}\":{"
        json+="\"model\":\"${CG_PHASE_MODEL[$phase]:-unknown}\","
        json+="\"tokens\":\"${CG_PHASE_TOKENS[$phase]:-0}\","
        json+="\"estimated\":\"${CG_PHASE_ESTIMATE[$phase]:-0.00}\","
        json+="\"actual\":\"${CG_PHASE_ACTUAL[$phase]:-null}\""
        json+="}"
        first=0
    done

    json+="}}"

    if [[ -n "$output_file" ]]; then
        echo "$json" > "$output_file"
        _cg_log "SUCCESS" "JSON出力: ${output_file}"
    else
        echo "$json"
    fi
}
