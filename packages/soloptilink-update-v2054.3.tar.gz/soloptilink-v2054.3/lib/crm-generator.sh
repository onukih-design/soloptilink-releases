#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v306.0 - CRM Generator
# =============================================================================
# CRM自動生成: コンタクト/パイプライン/活動ログ/メール連携/レポート
#
# 全globals: CRM_ prefix
# =============================================================================

[[ -n "${_CRM_GENERATOR_LOADED:-}" ]] && return 0
_CRM_GENERATOR_LOADED=1

declare -g CRM_VERSION="306.0"
declare -g CRM_INITIALIZED=false
declare -g CRM_GENERATED_COUNT=0
declare -g ENABLE_CRM_GENERATOR="${ENABLE_CRM_GENERATOR:-true}"

readonly CRM_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly CRM_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly CRM_BOLD="${CLR_BOLD:-\033[1m}"
readonly CRM_NC="${CLR_NC:-\033[0m}"

_crm_log() { echo -e "  ${CRM_CYAN}[CRM]${CRM_NC} $*" >&2; }
_crm_ok()  { echo -e "  ${CRM_GREEN}[CRM] OK${CRM_NC} $*" >&2; }

crm_init() { CRM_INITIALIZED=true; CRM_GENERATED_COUNT=0; return 0; }
crm_report() {
    [[ "$CRM_INITIALIZED" != "true" ]] && return 0
    echo -e "\n  ${CRM_BOLD}--- CRM Generator v${CRM_VERSION} ---${CRM_NC}" >&2
    echo -e "  生成コンポーネント数: ${CRM_GENERATED_COUNT}" >&2
}
crm_score() { [[ "$CRM_INITIALIZED" != "true" ]] && { echo "0"; return; }; local s=50; [[ $CRM_GENERATED_COUNT -ge 3 ]] && s=80; [[ $CRM_GENERATED_COUNT -ge 5 ]] && s=95; echo "$s"; }
crm_init_message() { echo -e "  ${CRM_GREEN}v${CRM_VERSION} crm-generator: CRM自動生成エンジン${CRM_NC}" >&2; }

# =============================================================================
# _crm_generate_contact_model() - Contact/Lead model
# =============================================================================
_crm_generate_contact_model() {
    local project_dir="${1:-.}"
    _crm_log "コンタクト/リードモデル生成"

    local prisma_dir="${project_dir}/prisma"
    mkdir -p "$prisma_dir"

    local model_snippet='
// --- CRM Models (v306.0) ---
model Contact {
  id         String   @id @default(cuid())
  firstName  String
  lastName   String
  email      String?  @unique
  phone      String?
  company    String?
  title      String?
  status     ContactStatus @default(LEAD)
  source     String?
  ownerId    String?
  dealValue  Int?
  pipelineStageId String?
  activities Activity[]
  notes      String?  @db.Text
  customFields Json?
  createdAt  DateTime @default(now())
  updatedAt  DateTime @updatedAt
}

enum ContactStatus { LEAD PROSPECT CUSTOMER CHURNED }

model PipelineStage {
  id       String @id @default(cuid())
  name     String
  position Int
  color    String @default("#3B82F6")
}

model Activity {
  id        String       @id @default(cuid())
  contactId String
  contact   Contact      @relation(fields: [contactId], references: [id], onDelete: Cascade)
  type      ActivityType
  subject   String
  body      String?      @db.Text
  userId    String?
  createdAt DateTime     @default(now())
}

enum ActivityType { EMAIL CALL MEETING NOTE TASK }'

    local schema_file="${prisma_dir}/schema.prisma"
    if [[ -f "$schema_file" ]]; then
        if ! grep -q "model Contact" "$schema_file" 2>/dev/null; then
            echo "$model_snippet" >> "$schema_file"
        fi
    fi

    CRM_GENERATED_COUNT=$((CRM_GENERATED_COUNT + 1))
    _crm_ok "コンタクトモデル生成完了"
    return 0
}

# =============================================================================
# _crm_generate_pipeline() - Sales pipeline (kanban board)
# =============================================================================
_crm_generate_pipeline() {
    local project_dir="${1:-.}"
    _crm_log "セールスパイプライン生成"

    local comp_dir="${project_dir}/src/components/crm"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/PipelineBoard.tsx" <<'EOF'
'use client';
import { useState, useCallback } from 'react';
import useSWR from 'swr';
import { User, DollarSign, GripVertical } from 'lucide-react';

const fetcher = (url: string) => fetch(url).then(r => r.json());

interface Deal { id: string; firstName: string; lastName: string; company?: string; dealValue?: number; pipelineStageId?: string; }
interface Stage { id: string; name: string; position: number; color: string; }

export function PipelineBoard() {
  const { data: stagesData } = useSWR<{ data: Stage[] }>('/api/crm/pipeline-stages', fetcher);
  const { data: dealsData, mutate } = useSWR<{ data: Deal[] }>('/api/crm/contacts?status=LEAD,PROSPECT', fetcher);
  const [dragging, setDragging] = useState<string | null>(null);

  const stages = stagesData?.data || [
    { id: 'lead', name: 'リード', position: 0, color: '#94A3B8' },
    { id: 'qualified', name: '商談化', position: 1, color: '#3B82F6' },
    { id: 'proposal', name: '提案', position: 2, color: '#F59E0B' },
    { id: 'negotiation', name: '交渉', position: 3, color: '#8B5CF6' },
    { id: 'won', name: '受注', position: 4, color: '#10B981' },
  ];

  const deals = dealsData?.data || [];

  const moveDeal = useCallback(async (dealId: string, stageId: string) => {
    try {
      await fetch(`/api/crm/contacts/${dealId}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ pipelineStageId: stageId }),
      });
      mutate();
    } catch { /* silent */ }
  }, [mutate]);

  const handleDrop = (e: React.DragEvent, stageId: string) => {
    e.preventDefault();
    if (dragging) { moveDeal(dragging, stageId); setDragging(null); }
  };

  return (
    <div className="flex gap-4 overflow-x-auto pb-4 min-h-[600px]">
      {stages.sort((a, b) => a.position - b.position).map(stage => {
        const stageDeals = deals.filter(d => d.pipelineStageId === stage.id);
        const totalValue = stageDeals.reduce((sum, d) => sum + (d.dealValue || 0), 0);
        return (
          <div key={stage.id} className="flex-shrink-0 w-72"
            onDragOver={e => e.preventDefault()} onDrop={e => handleDrop(e, stage.id)}>
            <div className="flex items-center gap-2 mb-3 px-1">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: stage.color }} />
              <h3 className="font-semibold text-sm">{stage.name}</h3>
              <span className="text-xs text-gray-400 ml-auto">{stageDeals.length}件</span>
            </div>
            {totalValue > 0 && <p className="text-xs text-gray-500 mb-2 px-1">&yen;{totalValue.toLocaleString()}</p>}
            <div className="space-y-2">
              {stageDeals.map(deal => (
                <div key={deal.id} draggable onDragStart={() => setDragging(deal.id)}
                  className="bg-white rounded-lg border p-3 cursor-grab active:cursor-grabbing hover:shadow-md transition">
                  <div className="flex items-start gap-2">
                    <GripVertical size={14} className="text-gray-300 mt-0.5 flex-shrink-0" />
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm truncate">{deal.firstName} {deal.lastName}</p>
                      {deal.company && <p className="text-xs text-gray-500 flex items-center gap-1 mt-1"><User size={12} /> {deal.company}</p>}
                      {deal.dealValue && <p className="text-xs text-green-600 font-medium mt-1 flex items-center gap-1"><DollarSign size={12} /> &yen;{deal.dealValue.toLocaleString()}</p>}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}
EOF

    CRM_GENERATED_COUNT=$((CRM_GENERATED_COUNT + 1))
    _crm_ok "パイプラインボード生成完了"
    return 0
}

# =============================================================================
# _crm_generate_activity_log() - Activity tracking
# =============================================================================
_crm_generate_activity_log() {
    local project_dir="${1:-.}"
    _crm_log "活動ログ生成"

    local comp_dir="${project_dir}/src/components/crm"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/ActivityTimeline.tsx" <<'EOF'
'use client';
import useSWR from 'swr';
import { Mail, Phone, Calendar, FileText, CheckSquare } from 'lucide-react';
import { useState } from 'react';

const fetcher = (url: string) => fetch(url).then(r => r.json());
const typeIcons: Record<string, React.ReactNode> = {
  EMAIL: <Mail size={16} className="text-blue-500" />,
  CALL: <Phone size={16} className="text-green-500" />,
  MEETING: <Calendar size={16} className="text-purple-500" />,
  NOTE: <FileText size={16} className="text-gray-500" />,
  TASK: <CheckSquare size={16} className="text-yellow-500" />,
};

export function ActivityTimeline({ contactId }: { contactId: string }) {
  const { data, isLoading, mutate } = useSWR(`/api/crm/contacts/${contactId}/activities`, fetcher);
  const [newActivity, setNewActivity] = useState({ type: 'NOTE', subject: '', body: '' });
  const [adding, setAdding] = useState(false);

  const handleAdd = async () => {
    if (!newActivity.subject) return;
    setAdding(true);
    try {
      await fetch(`/api/crm/contacts/${contactId}/activities`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(newActivity),
      });
      setNewActivity({ type: 'NOTE', subject: '', body: '' });
      mutate();
    } catch { /* silent */ } finally { setAdding(false); }
  };

  return (
    <div>
      <div className="bg-gray-50 rounded-lg p-4 mb-6 space-y-3">
        <div className="flex gap-3">
          <select value={newActivity.type} onChange={e => setNewActivity({ ...newActivity, type: e.target.value })}
            className="border rounded px-3 py-2 text-sm"><option value="NOTE">メモ</option><option value="EMAIL">メール</option>
            <option value="CALL">電話</option><option value="MEETING">会議</option><option value="TASK">タスク</option></select>
          <input value={newActivity.subject} onChange={e => setNewActivity({ ...newActivity, subject: e.target.value })}
            placeholder="件名" className="flex-1 border rounded px-3 py-2 text-sm" />
        </div>
        <textarea value={newActivity.body} onChange={e => setNewActivity({ ...newActivity, body: e.target.value })}
          placeholder="詳細（任意）" rows={2} className="w-full border rounded px-3 py-2 text-sm" />
        <button onClick={handleAdd} disabled={adding || !newActivity.subject}
          className="bg-blue-600 text-white px-4 py-2 rounded text-sm disabled:opacity-50">{adding ? '追加中...' : '活動を追加'}</button>
      </div>

      {isLoading && <div className="space-y-4">{[1,2,3].map(i => <div key={i} className="h-16 bg-gray-200 rounded animate-pulse" />)}</div>}

      <div className="space-y-0">
        {data?.data?.map((act: any, i: number) => (
          <div key={act.id} className="flex gap-4 pb-6 relative">
            {i < (data.data.length - 1) && <div className="absolute left-[19px] top-10 bottom-0 w-px bg-gray-200" />}
            <div className="w-10 h-10 rounded-full bg-gray-100 flex items-center justify-center flex-shrink-0 z-10">
              {typeIcons[act.type] || typeIcons.NOTE}
            </div>
            <div className="flex-1">
              <p className="font-medium text-sm">{act.subject}</p>
              {act.body && <p className="text-gray-600 text-sm mt-1">{act.body}</p>}
              <p className="text-xs text-gray-400 mt-1">{new Date(act.createdAt).toLocaleString('ja-JP')}</p>
            </div>
          </div>
        ))}
        {data?.data?.length === 0 && <p className="text-gray-500 text-sm text-center py-8">活動ログなし</p>}
      </div>
    </div>
  );
}
EOF

    CRM_GENERATED_COUNT=$((CRM_GENERATED_COUNT + 1))
    _crm_ok "活動ログ生成完了"
    return 0
}

# =============================================================================
# _crm_generate_email_integration() - Email send/track
# =============================================================================
_crm_generate_email_integration() {
    local project_dir="${1:-.}"
    _crm_log "メール連携生成"

    local api_dir="${project_dir}/src/app/api/crm/email"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest) {
  try {
    const { contactId, subject, body, templateId } = await req.json();
    if (!contactId || !subject) return NextResponse.json({ error: 'contactId and subject required' }, { status: 400 });

    const contact = await prisma.contact.findUnique({ where: { id: contactId } });
    if (!contact?.email) return NextResponse.json({ error: 'Contact has no email' }, { status: 400 });

    // Record activity
    await prisma.activity.create({
      data: { contactId, type: 'EMAIL', subject: `Sent: ${subject}`, body: body?.substring(0, 500) },
    });

    // TODO: Integrate with actual email provider (SendGrid, Resend, etc.)
    // const emailResult = await sendEmail({ to: contact.email, subject, body });

    return NextResponse.json({ success: true, message: `Email queued to ${contact.email}` });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to send email' }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const contactId = req.nextUrl.searchParams.get('contactId');
    const where = contactId ? { contactId, type: 'EMAIL' as const } : { type: 'EMAIL' as const };
    const emails = await prisma.activity.findMany({ where, orderBy: { createdAt: 'desc' }, take: 50 });
    return NextResponse.json({ data: emails });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch emails' }, { status: 500 });
  }
}
EOF

    CRM_GENERATED_COUNT=$((CRM_GENERATED_COUNT + 1))
    _crm_ok "メール連携生成完了"
    return 0
}

# =============================================================================
# _crm_generate_reports() - CRM reports
# =============================================================================
_crm_generate_reports() {
    local project_dir="${1:-.}"
    _crm_log "CRMレポート生成"

    local api_dir="${project_dir}/src/app/api/crm/reports"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const type = req.nextUrl.searchParams.get('type') || 'overview';

    if (type === 'overview') {
      const [totalContacts, leads, prospects, customers, totalDealValue] = await Promise.all([
        prisma.contact.count(),
        prisma.contact.count({ where: { status: 'LEAD' } }),
        prisma.contact.count({ where: { status: 'PROSPECT' } }),
        prisma.contact.count({ where: { status: 'CUSTOMER' } }),
        prisma.contact.aggregate({ _sum: { dealValue: true }, where: { status: { in: ['LEAD', 'PROSPECT'] } } }),
      ]);
      return NextResponse.json({
        totalContacts, leads, prospects, customers,
        pipelineValue: totalDealValue._sum.dealValue || 0,
        conversionRate: totalContacts > 0 ? Math.round((customers / totalContacts) * 100) : 0,
      });
    }

    if (type === 'funnel') {
      const stages = await prisma.contact.groupBy({ by: ['status'], _count: true, _sum: { dealValue: true } });
      return NextResponse.json({ data: stages });
    }

    if (type === 'activity') {
      const activities = await prisma.activity.groupBy({
        by: ['type'], _count: true,
        where: { createdAt: { gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) } },
      });
      return NextResponse.json({ data: activities, period: '30days' });
    }

    return NextResponse.json({ error: 'Unknown report type' }, { status: 400 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to generate report' }, { status: 500 });
  }
}
EOF

    CRM_GENERATED_COUNT=$((CRM_GENERATED_COUNT + 1))
    _crm_ok "CRMレポート生成完了"
    return 0
}

# =============================================================================
# Module Registration
# =============================================================================
_mr_register \
    --name "crm-generator" \
    --version "306.0" \
    --description "CRM自動生成（コンタクト/パイプライン/活動ログ/メール/レポート）" \
    --init "crm_init" \
    --report "crm_report" \
    --score "crm_score" \
    --enable-var "ENABLE_CRM_GENERATOR" \
    --cli-flags "--crm:--no-crm" \
    --init-msg "crm_init_message"
