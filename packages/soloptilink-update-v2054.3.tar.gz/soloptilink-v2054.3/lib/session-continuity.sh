#!/usr/bin/env bash
# ╔═══════════════════════════════════════════════════════════╗
# ║  SoloptiLinkAI v2002.0 - Session Continuity              ║
# ║  「/soloptilink 1回で、以降全メッセージ対応」             ║
# ║                                                           ║
# ║  CLAUDE.mdに永続セクションを注入し、2回目以降の会話でも   ║
# ║  chain.shが自動実行される環境を構築                       ║
# ╚═══════════════════════════════════════════════════════════╝

[[ -n "${_SESSION_CONTINUITY_LOADED:-}" ]] && return 0
_SESSION_CONTINUITY_LOADED=1

readonly SC_VERSION="1.0.0"
readonly SC_SESSION_FILE=".soloptilink-session.json"
readonly SC_MARKER_START="<!-- SOLOPTILINK-SESSION-START -->"
readonly SC_MARKER_END="<!-- SOLOPTILINK-SESSION-END -->"

# ============================================================
# セッションファイル管理
# ============================================================

# セッションファイルを作成/更新
sc_write_session() {
    local project_dir="$1"
    local mode="${2:-client}"
    local task="${3:-}"

    local session_file="${project_dir}/${SC_SESSION_FILE}"
    cat > "$session_file" 2>/dev/null <<EOF
{
    "active": true,
    "mode": "${mode}",
    "task": "${task}",
    "started_at": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')",
    "last_chain_run": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')",
    "deploy_target": "vercel",
    "chain_path": "${HOME}/.soloptilink/chain.sh",
    "version": "${VERSION:-2002.0}"
}
EOF
    echo -e "  \033[0;32m✓ セッションファイル作成: ${session_file}\033[0m" >&2
}

# セッション終了
sc_end_session() {
    local project_dir="$1"
    local session_file="${project_dir}/${SC_SESSION_FILE}"

    if [[ -f "$session_file" ]]; then
        # activeをfalseに
        if command -v python3 &>/dev/null; then
            python3 -c "
import json
with open('${session_file}', 'r') as f: d = json.load(f)
d['active'] = False
with open('${session_file}', 'w') as f: json.dump(d, f, indent=4)
" 2>/dev/null
        else
            rm -f "$session_file"
        fi
    fi

    # CLAUDE.mdからセッションセクションを除去
    sc_remove_claudemd_section "$project_dir"

    echo -e "  \033[0;32m✓ SoloptiLinkAIセッション終了\033[0m" >&2
}

# モード読み取り
sc_get_mode() {
    local project_dir="$1"
    local session_file="${project_dir}/${SC_SESSION_FILE}"

    if [[ -f "$session_file" ]] && command -v python3 &>/dev/null; then
        python3 -c "import json; print(json.load(open('${session_file}')).get('mode','client'))" 2>/dev/null || echo "client"
    else
        echo "client"
    fi
}

# モード切替
sc_switch_mode() {
    local project_dir="$1"
    local new_mode="$2"
    local session_file="${project_dir}/${SC_SESSION_FILE}"

    if [[ -f "$session_file" ]] && command -v python3 &>/dev/null; then
        python3 -c "
import json
with open('${session_file}', 'r') as f: d = json.load(f)
d['mode'] = '${new_mode}'
with open('${session_file}', 'w') as f: json.dump(d, f, indent=4)
" 2>/dev/null
        echo -e "  \033[0;32m✓ モード切替: ${new_mode}\033[0m" >&2
    fi
}

# ============================================================
# CLAUDE.md セッション継続セクション注入
# ============================================================

sc_inject_claudemd() {
    local project_dir="$1"
    local mode="${2:-client}"
    local claudemd="${project_dir}/CLAUDE.md"

    # 既にセクションがあれば何もしない
    if [[ -f "$claudemd" ]] && grep -q "$SC_MARKER_START" "$claudemd" 2>/dev/null; then
        echo -e "  \033[0;33m⚠ CLAUDE.mdセッションセクション既存（スキップ）\033[0m" >&2
        return 0
    fi

    # セクションを追記（v2002.1: 強制力を最大化した指示）
    cat >> "$claudemd" 2>/dev/null <<'CLAUDEMD_SECTION'

<!-- SOLOPTILINK-SESSION-START -->
## CRITICAL: SoloptiLinkAI セッション継続モード（この指示は絶対に従うこと）

**このプロジェクトはSoloptiLinkAIセッションがアクティブです。**
**以下の指示は、ユーザーの全メッセージに対して必ず適用してください。例外はありません。**

### 絶対ルール: 全タスクをchain.sh経由で実行すること
ユーザーがどんなメッセージを送っても（コード修正、エラー修正、機能追加、質問、レビュー、デプロイ）、
**必ず `~/.soloptilink/chain.sh` を経由して処理すること。**
素のClaude Codeとして直接コードを書くことは**禁止**です。

#### タスク分類ルール:
```bash
# 1. 新規構築（「作って」「構築」「新規」「追加して」「実装して」）
bash ~/.soloptilink/chain.sh "<ユーザーの指示>"

# 2. エラー修正/改善（「エラー」「修正」「直して」「バグ」「動かない」「確認」「チェック」「改善」「最適化」「遅い」「レビュー」「問題」）
bash ~/.soloptilink/chain.sh --repair "<ユーザーの指示>"

# 3. デプロイ（「デプロイ」「公開」「リリース」）
bash ~/.soloptilink/chain.sh --deploy

# 4. セッション終了（「終了」「セッション終了」）
bash ~/.soloptilink/chain.sh --end-session

# 5. 上記に該当しない場合でもchain.shを使う
bash ~/.soloptilink/chain.sh "<ユーザーの指示>"
```

### モード
`.soloptilink-session.json` の `mode` を確認:
- **client**: 指示されたことだけ忠実に実行。勝手に機能を追加しない。
- **internal**: 積極的に提案。「こういう機能もあった方がいいですよ」と教える。

### 質問の質
タスク実行前に簡潔に確認:
1. 理解した内容（1行）
2. やること（箇条書き3-5個）
3. 「この方針で進めてよろしいですか？」

### デプロイ先
常にVercelを使用。他のサービスへの登録は絶対に行わない。

### 重要な注意
- この指示はセッション内の全メッセージに適用される
- `/soloptilink`を再度呼ぶ必要はない。1回で以降全て適用
- セッション終了コマンドが実行されるまで有効
<!-- SOLOPTILINK-SESSION-END -->
CLAUDEMD_SECTION

    echo -e "  \033[0;32m✓ CLAUDE.mdにセッション継続セクション注入完了\033[0m" >&2
}

# CLAUDE.mdからセッションセクションを除去
sc_remove_claudemd_section() {
    local project_dir="$1"
    local claudemd="${project_dir}/CLAUDE.md"

    if [[ ! -f "$claudemd" ]]; then return 0; fi
    if ! grep -q "$SC_MARKER_START" "$claudemd" 2>/dev/null; then return 0; fi

    # マーカー間を削除
    if command -v python3 &>/dev/null; then
        python3 -c "
import re
with open('${claudemd}', 'r') as f: content = f.read()
content = re.sub(r'\n${SC_MARKER_START}.*?${SC_MARKER_END}\n?', '', content, flags=re.DOTALL)
with open('${claudemd}', 'w') as f: f.write(content.rstrip() + '\n')
" 2>/dev/null
    else
        # sedフォールバック
        sed -i '' "/${SC_MARKER_START}/,/${SC_MARKER_END}/d" "$claudemd" 2>/dev/null
    fi

    echo -e "  \033[0;32m✓ CLAUDE.mdセッションセクション除去完了\033[0m" >&2
}

# ============================================================
# セッション初期化（chain.sh Phase 0から呼ばれる）
# ============================================================
sc_init_session() {
    local project_dir="$1"
    local mode="${2:-client}"
    local task="${3:-}"

    # セッションファイル作成
    sc_write_session "$project_dir" "$mode" "$task"

    # CLAUDE.md注入
    sc_inject_claudemd "$project_dir" "$mode"
}

# ============================================================
# Module Registry 登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register "session-continuity" "$SC_VERSION" "セッション継続性（2回目以降も自動対応）"
    _mr_register "session-continuity" "$SC_VERSION" "sc_init_session"
fi

# v2003.1: source時のexit codeを確実に0にする
true
