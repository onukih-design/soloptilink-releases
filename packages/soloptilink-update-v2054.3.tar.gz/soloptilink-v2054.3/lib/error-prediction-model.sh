#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v479.0 - Error Prediction Model
# =============================================================================
# プロジェクト特性とコード構造から発生し得るエラーを事前予測し、
# 予防コードを注入する。過去のエラーパターンDBから学習した
# 確率モデルによりエラーゼロを目指す予測エンジン。
#
# Functions:
#   _epm_init               - 初期化
#   _epm_predict_errors     - エラー発生予測
#   _epm_inject_prevention  - 予防コードの注入
#   _epm_update_model       - モデルの更新
#   _epm_get_risk_profile   - リスクプロファイル取得
#   _epm_report             - レポート出力
#   _epm_score              - モジュールスコア(0-100)
#
# Globals: EPM_ prefix
# =============================================================================

[[ -n "${_ERROR_PREDICTION_MODEL_LOADED:-}" ]] && return 0
_ERROR_PREDICTION_MODEL_LOADED=1

EPM_VERSION="479.0"
EPM_INITIALIZED=false

# --- Storage ---
EPM_DATA_DIR=""
EPM_MODEL_FILE=""
EPM_HISTORY_FILE=""
EPM_PREVENTION_LOG=""

# --- State ---
EPM_TOTAL_PREDICTIONS=0
EPM_ERRORS_PREVENTED=0
EPM_FALSE_POSITIVES=0
EPM_MODEL_PRECISION=70

# --- Error Pattern Database ---
declare -g -A _EPM_ERROR_PATTERNS=()
declare -g -A _EPM_PATTERN_FREQUENCY=()
declare -g -A _EPM_PATTERN_SEVERITY=()
declare -g -A _EPM_PREVENTION_MAP=()
declare -g -a _EPM_PREDICTED_ERRORS=()
declare -g -A _EPM_RISK_SCORES=()

# Known error categories
declare -g -a EPM_ERROR_CATEGORIES=(
    "type_error"
    "null_reference"
    "missing_import"
    "api_mismatch"
    "schema_drift"
    "auth_bypass"
    "sql_injection"
    "xss_vulnerability"
    "race_condition"
    "memory_leak"
    "infinite_loop"
    "unhandled_rejection"
    "cors_error"
    "hydration_mismatch"
    "missing_env_var"
)

# =============================================================================
# 初期化
# =============================================================================
_epm_init() {
    local project_dir="${PROJECT_DIR:-.}"
    EPM_DATA_DIR="${project_dir}/.soloptilink/epm"
    EPM_MODEL_FILE="${EPM_DATA_DIR}/model.json"
    EPM_HISTORY_FILE="${EPM_DATA_DIR}/history.jsonl"
    EPM_PREVENTION_LOG="${EPM_DATA_DIR}/preventions.jsonl"

    mkdir -p "$EPM_DATA_DIR"

    # パターンDBの初期化（ドメイン横断的な既知パターン）
    _EPM_ERROR_PATTERNS["type_error"]="TypeScriptの型不一致"
    _EPM_PATTERN_FREQUENCY["type_error"]=85
    _EPM_PATTERN_SEVERITY["type_error"]=6
    _EPM_PREVENTION_MAP["type_error"]="strict: trueのtsconfig、zodスキーマの全API適用"

    _EPM_ERROR_PATTERNS["null_reference"]="null/undefinedアクセス"
    _EPM_PATTERN_FREQUENCY["null_reference"]=78
    _EPM_PATTERN_SEVERITY["null_reference"]=7
    _EPM_PREVENTION_MAP["null_reference"]="Optional chaining(?.)の徹底、nullチェックガード"

    _EPM_ERROR_PATTERNS["api_mismatch"]="APIレスポンス型とフロントエンド期待型の不一致"
    _EPM_PATTERN_FREQUENCY["api_mismatch"]=72
    _EPM_PATTERN_SEVERITY["api_mismatch"]=8
    _EPM_PREVENTION_MAP["api_mismatch"]="Contract-First: 共有型定義ファイル、zodレスポンスバリデーション"

    _EPM_ERROR_PATTERNS["schema_drift"]="PrismaスキーマとAPIの乖離"
    _EPM_PATTERN_FREQUENCY["schema_drift"]=65
    _EPM_PATTERN_SEVERITY["schema_drift"]=8
    _EPM_PREVENTION_MAP["schema_drift"]="prisma generateの自動実行、型インポートの一元化"

    _EPM_ERROR_PATTERNS["auth_bypass"]="認証チェックの欠落"
    _EPM_PATTERN_FREQUENCY["auth_bypass"]=45
    _EPM_PATTERN_SEVERITY["auth_bypass"]=10
    _EPM_PREVENTION_MAP["auth_bypass"]="middleware認証必須化、protectedRoute HOC"

    _EPM_ERROR_PATTERNS["sql_injection"]="SQLインジェクション脆弱性"
    _EPM_PATTERN_FREQUENCY["sql_injection"]=30
    _EPM_PATTERN_SEVERITY["sql_injection"]=10
    _EPM_PREVENTION_MAP["sql_injection"]="PrismaORM強制使用、rawクエリ禁止ルール"

    _EPM_ERROR_PATTERNS["xss_vulnerability"]="XSS脆弱性"
    _EPM_PATTERN_FREQUENCY["xss_vulnerability"]=40
    _EPM_PATTERN_SEVERITY["xss_vulnerability"]=9
    _EPM_PREVENTION_MAP["xss_vulnerability"]="DOMPurify、dangerouslySetInnerHTML禁止、CSPヘッダー"

    _EPM_ERROR_PATTERNS["race_condition"]="非同期処理の競合状態"
    _EPM_PATTERN_FREQUENCY["race_condition"]=35
    _EPM_PATTERN_SEVERITY["race_condition"]=7
    _EPM_PREVENTION_MAP["race_condition"]="AbortController、楽観的ロック、$transaction"

    _EPM_ERROR_PATTERNS["hydration_mismatch"]="SSR/CSRの不整合"
    _EPM_PATTERN_FREQUENCY["hydration_mismatch"]=55
    _EPM_PATTERN_SEVERITY["hydration_mismatch"]=5
    _EPM_PREVENTION_MAP["hydration_mismatch"]="'use client'ディレクティブ、dynamic import(ssr:false)"

    _EPM_ERROR_PATTERNS["missing_env_var"]="環境変数の未設定"
    _EPM_PATTERN_FREQUENCY["missing_env_var"]=60
    _EPM_PATTERN_SEVERITY["missing_env_var"]=6
    _EPM_PREVENTION_MAP["missing_env_var"]="zodでenv検証、.env.example、起動時チェック"

    _EPM_ERROR_PATTERNS["unhandled_rejection"]="未処理のPromise例外"
    _EPM_PATTERN_FREQUENCY["unhandled_rejection"]=68
    _EPM_PATTERN_SEVERITY["unhandled_rejection"]=7
    _EPM_PREVENTION_MAP["unhandled_rejection"]="全async関数にtry-catch、グローバルエラーハンドラ"

    _EPM_ERROR_PATTERNS["cors_error"]="CORSポリシーエラー"
    _EPM_PATTERN_FREQUENCY["cors_error"]=50
    _EPM_PATTERN_SEVERITY["cors_error"]=5
    _EPM_PREVENTION_MAP["cors_error"]="明示的CORS設定、API Routeのヘッダー設定"

    _EPM_ERROR_PATTERNS["missing_import"]="インポート文の欠落"
    _EPM_PATTERN_FREQUENCY["missing_import"]=75
    _EPM_PATTERN_SEVERITY["missing_import"]=4
    _EPM_PREVENTION_MAP["missing_import"]="ESLint import/no-unresolved、auto-import設定"

    _EPM_ERROR_PATTERNS["infinite_loop"]="無限ループ/再レンダリング"
    _EPM_PATTERN_FREQUENCY["infinite_loop"]=25
    _EPM_PATTERN_SEVERITY["infinite_loop"]=8
    _EPM_PREVENTION_MAP["infinite_loop"]="useEffect依存配列チェック、useMemo/useCallback"

    _EPM_ERROR_PATTERNS["memory_leak"]="メモリリーク"
    _EPM_PATTERN_FREQUENCY["memory_leak"]=20
    _EPM_PATTERN_SEVERITY["memory_leak"]=7
    _EPM_PREVENTION_MAP["memory_leak"]="useEffectクリーンアップ、AbortController、イベントリスナー解除"

    if [[ -f "$EPM_HISTORY_FILE" ]]; then
        local total hit
        total=$(wc -l < "$EPM_HISTORY_FILE" 2>/dev/null || echo "0")
        hit=$(grep -c '"prevented":true' "$EPM_HISTORY_FILE" 2>/dev/null || echo "0")
        EPM_TOTAL_PREDICTIONS=$total
        EPM_ERRORS_PREVENTED=$hit
        if [[ $total -gt 0 ]]; then
            EPM_MODEL_PRECISION=$((hit * 100 / total))
        fi
    fi

    EPM_INITIALIZED=true
    return 0
}

# =============================================================================
# エラー発生予測
# =============================================================================
_epm_predict_errors() {
    local domain="$1"
    local stack="${2:-nextjs}"
    local project_dir="${3:-.}"

    [[ "$EPM_INITIALIZED" != "true" ]] && _epm_init

    _EPM_PREDICTED_ERRORS=()
    local total_risk=0

    for category in "${EPM_ERROR_CATEGORIES[@]}"; do
        local freq="${_EPM_PATTERN_FREQUENCY[$category]:-0}"
        local severity="${_EPM_PATTERN_SEVERITY[$category]:-5}"

        # ドメイン補正
        local domain_multiplier=10
        case "$domain" in
            ec|saas)
                [[ "$category" == "auth_bypass" || "$category" == "race_condition" || "$category" == "sql_injection" ]] && domain_multiplier=15
                ;;
            chat)
                [[ "$category" == "race_condition" || "$category" == "memory_leak" ]] && domain_multiplier=15
                ;;
            blog|portfolio)
                domain_multiplier=7
                ;;
        esac

        local risk_score=$(( (freq * severity * domain_multiplier) / 100 ))
        _EPM_RISK_SCORES["$category"]=$risk_score

        # 閾値超過で予測リストに追加
        if [[ $risk_score -gt 30 ]]; then
            _EPM_PREDICTED_ERRORS+=("$category")
            total_risk=$((total_risk + risk_score))
        fi
    done

    EPM_TOTAL_PREDICTIONS=$((EPM_TOTAL_PREDICTIONS + 1))

    echo "${#_EPM_PREDICTED_ERRORS[@]}:${total_risk}"
    return 0
}

# =============================================================================
# 予防コードの注入
# =============================================================================
_epm_inject_prevention() {
    local output_file="${1:-}"

    [[ "$EPM_INITIALIZED" != "true" ]] && _epm_init

    local preventions=""
    local injected=0

    for error in "${_EPM_PREDICTED_ERRORS[@]}"; do
        local prevention="${_EPM_PREVENTION_MAP[$error]:-}"
        local severity="${_EPM_PATTERN_SEVERITY[$error]:-5}"
        local pattern_desc="${_EPM_ERROR_PATTERNS[$error]:-}"

        if [[ -n "$prevention" ]]; then
            preventions+="[予防: ${pattern_desc}(重大度${severity}/10)]\n"
            preventions+="  対策: ${prevention}\n\n"
            injected=$((injected + 1))
        fi
    done

    if [[ -n "$output_file" && -n "$preventions" ]]; then
        echo -e "$preventions" > "$output_file"
    fi

    EPM_ERRORS_PREVENTED=$((EPM_ERRORS_PREVENTED + injected))

    local timestamp
    timestamp=$(date +%s)
    echo "{\"ts\":${timestamp},\"predicted\":${#_EPM_PREDICTED_ERRORS[@]},\"injected\":${injected}}" >> "$EPM_PREVENTION_LOG" 2>/dev/null

    echo -e "$preventions"
    return 0
}

# =============================================================================
# モデルの更新
# =============================================================================
_epm_update_model() {
    local error_category="$1"
    local actually_occurred="${2:-true}"

    [[ "$EPM_INITIALIZED" != "true" ]] && _epm_init

    local timestamp
    timestamp=$(date +%s)

    if [[ "$actually_occurred" == "true" ]]; then
        # エラーが実際に発生→頻度を上げる
        local freq="${_EPM_PATTERN_FREQUENCY[$error_category]:-50}"
        freq=$((freq + 2))
        [[ $freq -gt 100 ]] && freq=100
        _EPM_PATTERN_FREQUENCY["$error_category"]=$freq

        echo "{\"ts\":${timestamp},\"category\":\"${error_category}\",\"occurred\":true,\"prevented\":false}" >> "$EPM_HISTORY_FILE" 2>/dev/null
    else
        # 予測したが発生せず→偽陽性
        local freq="${_EPM_PATTERN_FREQUENCY[$error_category]:-50}"
        freq=$((freq - 1))
        [[ $freq -lt 0 ]] && freq=0
        _EPM_PATTERN_FREQUENCY["$error_category"]=$freq
        EPM_FALSE_POSITIVES=$((EPM_FALSE_POSITIVES + 1))

        echo "{\"ts\":${timestamp},\"category\":\"${error_category}\",\"occurred\":false,\"prevented\":true}" >> "$EPM_HISTORY_FILE" 2>/dev/null
    fi

    return 0
}

# =============================================================================
# リスクプロファイル取得
# =============================================================================
_epm_get_risk_profile() {
    echo "{"
    local first=true
    for category in "${EPM_ERROR_CATEGORIES[@]}"; do
        local risk="${_EPM_RISK_SCORES[$category]:-0}"
        [[ "$first" != "true" ]] && echo ","
        echo -n "  \"${category}\": ${risk}"
        first=false
    done
    echo ""
    echo "}"
}

# =============================================================================
# レポート
# =============================================================================
_epm_report() {
    echo -e "\n  ${BOLD:-}═══ Error Prediction Model v${EPM_VERSION} ═══${NC:-}"
    echo -e "  総予測回数         : ${EPM_TOTAL_PREDICTIONS}"
    echo -e "  エラー予防数       : ${EPM_ERRORS_PREVENTED}"
    echo -e "  偽陽性数           : ${EPM_FALSE_POSITIVES}"
    echo -e "  モデル精度         : ${EPM_MODEL_PRECISION}%"
    echo -e "  既知パターン数     : ${#_EPM_ERROR_PATTERNS[@]}"
}

_epm_score() {
    [[ "$EPM_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    echo "$EPM_MODEL_PRECISION"
}

_epm_init_message() {
    echo -e "  ${GREEN:-}✅ v${EPM_VERSION} error-prediction-model: エラー予測モデル (${#_EPM_ERROR_PATTERNS[@]} patterns, 精度 ${EPM_MODEL_PRECISION}%)${NC:-}" >&2
}

# =============================================================================
# Module Registry 登録
# =============================================================================
_mr_register \
    --name "error-prediction-model" \
    --version "$EPM_VERSION" \
    --description "エラー予測モデル" \
    --init "_epm_init" \
    --report "_epm_report" \
    --score "_epm_score" \
    --enable-var "ENABLE_ERROR_PREDICTION_MODEL" \
    --cli-flags "--error-prediction:--no-error-prediction" \
    --init-msg "_epm_init_message"
