#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v290.0 - Multi-DB Support
# =============================================================================
# マルチデータベースサポート。ユースケースに最適なDBを検出し、
# PostgreSQL/MySQL/MongoDB/Redis設定を自動生成する。
#
# 機能一覧:
#   _mds_detect_db_needs     - 最適DB検出
#   _mds_generate_pg_config  - PostgreSQL設定
#   _mds_generate_mysql_config - MySQL設定
#   _mds_generate_mongo_config - MongoDB設定
#   _mds_generate_redis_config - Redis設定
#
# 全globals: MDS_ prefix
# =============================================================================

[[ -n "${_MDS_LOADED:-}" ]] && return 0; _MDS_LOADED=1

declare -g MDS_VERSION="290.0"
declare -g MDS_GENERATED=0
declare -g MDS_ERRORS=0
declare -g MDS_FILES_WRITTEN=0
declare -g MDS_DETECTED_DB="postgresql"

mds_init() { MDS_GENERATED=0; MDS_ERRORS=0; MDS_FILES_WRITTEN=0; MDS_DETECTED_DB="postgresql"; return 0; }

_mds_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then MDS_FILES_WRITTEN=$((MDS_FILES_WRITTEN + 1)); echo "  [mds] wrote: $filepath" >&2
    else MDS_ERRORS=$((MDS_ERRORS + 1)); fi
}

_mds_log() { echo -e "  ${GREEN:-\033[0;32m}[MDS]${NC:-\033[0m} $*" >&2; }

# =============================================================================
# _mds_detect_db_needs
# =============================================================================
_mds_detect_db_needs() {
    local project_desc="${1:-}"
    local domain="${2:-web}"

    _mds_log "Detecting optimal database type..."

    # Default: PostgreSQL for most use cases
    MDS_DETECTED_DB="postgresql"

    # MongoDB for document-heavy or flexible schema
    if echo "$project_desc" | grep -qiE "cms|blog|content|document|flexible|schema-less|nosql"; then
        MDS_DETECTED_DB="mongodb"
    fi

    # Redis for cache/session-heavy
    if echo "$project_desc" | grep -qiE "cache|session|realtime|queue|pub.?sub"; then
        MDS_DETECTED_DB="redis"
    fi

    # MySQL for legacy/WordPress/PHP integration
    if echo "$project_desc" | grep -qiE "mysql|wordpress|php|legacy"; then
        MDS_DETECTED_DB="mysql"
    fi

    _mds_log "Detected optimal DB: ${MDS_DETECTED_DB}"
    echo "${MDS_DETECTED_DB}"
}

# =============================================================================
# _mds_generate_pg_config
# =============================================================================
_mds_generate_pg_config() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _mds_log "Generating PostgreSQL configuration..."

    local pg_ts
    pg_ts=$(cat <<'PGEOF'
// =============================================================================
// PostgreSQL Configuration
// Connection pooling, SSL, read replicas, health checks
// =============================================================================
import { PrismaClient } from '@prisma/client';

export interface PostgresConfig {
  url: string;
  readReplicaUrl?: string;
  poolSize: number;
  connectionTimeout: number;
  ssl: boolean;
}

function getConfig(): PostgresConfig {
  return {
    url: process.env.DATABASE_URL || 'postgresql://localhost:5432/app',
    readReplicaUrl: process.env.DATABASE_READ_URL,
    poolSize: parseInt(process.env.DB_POOL_SIZE || '10'),
    connectionTimeout: parseInt(process.env.DB_TIMEOUT || '5000'),
    ssl: process.env.DB_SSL === 'true',
  };
}

let _prisma: PrismaClient | null = null;
let _readPrisma: PrismaClient | null = null;

export function getWriteClient(): PrismaClient {
  if (!_prisma) {
    const config = getConfig();
    _prisma = new PrismaClient({
      datasources: { db: { url: config.url } },
      log: process.env.NODE_ENV === 'development' ? ['query', 'warn', 'error'] : ['error'],
    });
  }
  return _prisma;
}

export function getReadClient(): PrismaClient {
  const config = getConfig();
  if (!config.readReplicaUrl) return getWriteClient();
  if (!_readPrisma) {
    _readPrisma = new PrismaClient({
      datasources: { db: { url: config.readReplicaUrl } },
      log: ['error'],
    });
  }
  return _readPrisma;
}

export async function checkConnection(): Promise<{ ok: boolean; latency: number }> {
  const start = Date.now();
  try {
    await getWriteClient().$queryRaw`SELECT 1`;
    return { ok: true, latency: Date.now() - start };
  } catch {
    return { ok: false, latency: Date.now() - start };
  }
}

export async function disconnect(): Promise<void> {
  if (_prisma) await _prisma.$disconnect();
  if (_readPrisma) await _readPrisma.$disconnect();
  _prisma = null;
  _readPrisma = null;
}
PGEOF
)
    _mds_write_file "${project_dir}/src/lib/db/postgres.ts" "$pg_ts"
    MDS_GENERATED=$((MDS_GENERATED + 1))
    return 0
}

# =============================================================================
# _mds_generate_mysql_config
# =============================================================================
_mds_generate_mysql_config() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _mds_log "Generating MySQL configuration..."

    local mysql_ts
    mysql_ts=$(cat <<'MYSQLEOF'
// =============================================================================
// MySQL Configuration
// Connection pooling and health checks
// =============================================================================
import mysql from 'mysql2/promise';

export interface MySQLConfig {
  host: string;
  port: number;
  user: string;
  password: string;
  database: string;
  poolSize: number;
  ssl: boolean;
}

function getConfig(): MySQLConfig {
  return {
    host: process.env.MYSQL_HOST || 'localhost',
    port: parseInt(process.env.MYSQL_PORT || '3306'),
    user: process.env.MYSQL_USER || 'root',
    password: process.env.MYSQL_PASSWORD || '',
    database: process.env.MYSQL_DATABASE || 'app',
    poolSize: parseInt(process.env.MYSQL_POOL_SIZE || '10'),
    ssl: process.env.MYSQL_SSL === 'true',
  };
}

let pool: mysql.Pool | null = null;

export function getPool(): mysql.Pool {
  if (!pool) {
    const config = getConfig();
    pool = mysql.createPool({
      host: config.host, port: config.port,
      user: config.user, password: config.password,
      database: config.database,
      waitForConnections: true,
      connectionLimit: config.poolSize,
      queueLimit: 0,
    });
  }
  return pool;
}

export async function query<T = any>(sql: string, params?: any[]): Promise<T[]> {
  const [rows] = await getPool().execute(sql, params);
  return rows as T[];
}

export async function checkConnection(): Promise<{ ok: boolean; latency: number }> {
  const start = Date.now();
  try {
    await getPool().execute('SELECT 1');
    return { ok: true, latency: Date.now() - start };
  } catch {
    return { ok: false, latency: Date.now() - start };
  }
}

export async function disconnect(): Promise<void> {
  if (pool) { await pool.end(); pool = null; }
}
MYSQLEOF
)
    _mds_write_file "${project_dir}/src/lib/db/mysql.ts" "$mysql_ts"
    MDS_GENERATED=$((MDS_GENERATED + 1))
    return 0
}

# =============================================================================
# _mds_generate_mongo_config
# =============================================================================
_mds_generate_mongo_config() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _mds_log "Generating MongoDB configuration..."

    local mongo_ts
    mongo_ts=$(cat <<'MONGOEOF'
// =============================================================================
// MongoDB Configuration
// Connection management, typed collections, health checks
// =============================================================================
import { MongoClient, Db, Collection } from 'mongodb';

export interface MongoConfig {
  url: string;
  dbName: string;
  maxPoolSize: number;
}

function getConfig(): MongoConfig {
  return {
    url: process.env.MONGODB_URL || 'mongodb://localhost:27017',
    dbName: process.env.MONGODB_DB || 'app',
    maxPoolSize: parseInt(process.env.MONGODB_POOL_SIZE || '10'),
  };
}

let _client: MongoClient | null = null;
let _db: Db | null = null;

export async function getDb(): Promise<Db> {
  if (_db) return _db;
  const config = getConfig();
  _client = new MongoClient(config.url, { maxPoolSize: config.maxPoolSize });
  await _client.connect();
  _db = _client.db(config.dbName);
  console.log(`[mongodb] Connected to ${config.dbName}`);
  return _db;
}

export async function getCollection<T extends Document = Document>(name: string): Promise<Collection<T>> {
  const db = await getDb();
  return db.collection<T>(name);
}

export async function checkConnection(): Promise<{ ok: boolean; latency: number }> {
  const start = Date.now();
  try {
    const db = await getDb();
    await db.command({ ping: 1 });
    return { ok: true, latency: Date.now() - start };
  } catch {
    return { ok: false, latency: Date.now() - start };
  }
}

export async function disconnect(): Promise<void> {
  if (_client) { await _client.close(); _client = null; _db = null; }
}
MONGOEOF
)
    _mds_write_file "${project_dir}/src/lib/db/mongodb.ts" "$mongo_ts"
    MDS_GENERATED=$((MDS_GENERATED + 1))
    return 0
}

# =============================================================================
# _mds_generate_redis_config
# =============================================================================
_mds_generate_redis_config() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _mds_log "Generating Redis configuration..."

    local redis_ts
    redis_ts=$(cat <<'REDISEOF'
// =============================================================================
// Redis Configuration
// Connection, cache abstraction, pub/sub, session store
// =============================================================================

export interface RedisConfig {
  url: string;
  keyPrefix: string;
  defaultTtl: number;
}

function getConfig(): RedisConfig {
  return {
    url: process.env.REDIS_URL || 'redis://localhost:6379',
    keyPrefix: process.env.REDIS_PREFIX || 'app:',
    defaultTtl: parseInt(process.env.REDIS_TTL || '3600'),
  };
}

let _redis: any = null;

export async function getRedis() {
  if (_redis) return _redis;
  const Redis = (await import('ioredis')).default;
  const config = getConfig();
  _redis = new Redis(config.url, {
    keyPrefix: config.keyPrefix,
    retryStrategy: (times: number) => Math.min(times * 100, 3000),
    maxRetriesPerRequest: 3,
  });
  _redis.on('error', (err: Error) => console.error('[redis] Error:', err.message));
  _redis.on('connect', () => console.log('[redis] Connected'));
  return _redis;
}

// Cache abstraction
export async function cacheGet<T>(key: string): Promise<T | null> {
  const redis = await getRedis();
  const data = await redis.get(key);
  return data ? JSON.parse(data) : null;
}

export async function cacheSet<T>(key: string, value: T, ttl?: number): Promise<void> {
  const redis = await getRedis();
  const config = getConfig();
  await redis.set(key, JSON.stringify(value), 'EX', ttl || config.defaultTtl);
}

export async function cacheDel(key: string): Promise<void> {
  const redis = await getRedis();
  await redis.del(key);
}

export async function checkConnection(): Promise<{ ok: boolean; latency: number }> {
  const start = Date.now();
  try {
    const redis = await getRedis();
    await redis.ping();
    return { ok: true, latency: Date.now() - start };
  } catch {
    return { ok: false, latency: Date.now() - start };
  }
}

export async function disconnect(): Promise<void> {
  if (_redis) { await _redis.quit(); _redis = null; }
}
REDISEOF
)
    _mds_write_file "${project_dir}/src/lib/db/redis.ts" "$redis_ts"
    MDS_GENERATED=$((MDS_GENERATED + 1))
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
mds_report() {
    echo -e "\n  ${BOLD:-}=== multi-db-support v${MDS_VERSION} ===${NC:-}"
    echo -e "  DetectedDB: ${MDS_DETECTED_DB}"; echo -e "  生成数: ${MDS_GENERATED}"; echo -e "  エラー: ${MDS_ERRORS}"
}

mds_score() {
    if [[ ${MDS_GENERATED} -ge 4 ]] && [[ ${MDS_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${MDS_GENERATED} -gt 0 ]] && [[ ${MDS_ERRORS} -eq 0 ]]; then echo "85"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "multi-db-support" --version "${MDS_VERSION}" \
        --description "マルチDB対応×PostgreSQL×MySQL×MongoDB×Redis" \
        --init "mds_init" --report "mds_report" --score "mds_score" \
        --enable-var "ENABLE_MULTI_DB" --cli-flags "--multi-db:--no-multi-db"
fi

# v2003.1: source時のexit codeを確実に0にする
true
