#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v130.0 - Unified File Writer
# =============================================================================
# 3世代のFileWriter (v1/v2/v3) を統合した堅牢なファイル書き込みシステム。
#
# 特徴:
#   - アトミック書き込み（ステージング→検証→mv）
#   - SHA256マニフェストによる重複検出・整合性管理
#   - 自動バックアップ＆ロールバック
#   - 3段階パース戦略（マーカー→コードブロック→ヒューリスティック）
#   - 構文検証（node --check / python3 compile）
#   - 後方互換エイリアス（fw2_parse_and_write, fw_smart_write）
#
# Usage: source lib/file-writer-unified.sh
# =============================================================================

[[ -n "${_FWU_LOADED:-}" ]] && return 0
_FWU_LOADED=1

# =============================================================================
# Constants & State
# =============================================================================
FWU_VERSION="130.0"

declare -g FWU_PROJECT_DIR=""
declare -g FWU_STAGING_DIR=""
declare -g FWU_BACKUP_DIR=""
declare -g FWU_MANIFEST_FILE=""
declare -g FWU_FILES_WRITTEN=0
declare -g FWU_FILES_SKIPPED=0
declare -g FWU_FILES_FAILED=0
declare -g FWU_BYTES_WRITTEN=0
declare -g FWU_ROLLBACK_COUNT=0
declare -g FWU_FILES_VALIDATED=0    # v149: syntax validation success counter
declare -g -a FWU_WRITTEN_LIST=()
declare -g -a FWU_SKIPPED_LIST=()
declare -g -a FWU_FAILED_LIST=()
declare -g -A FWU_MANIFEST=()       # path -> sha256

# =============================================================================
# Internal Logger
# =============================================================================
_fwu_log() {
    local level="$1" msg="$2"
    local color="${NC:-\033[0m}"
    case "$level" in
        INFO)  color="${CYAN:-\033[0;36m}" ;;
        OK)    color="${GREEN:-\033[0;32m}" ;;
        WARN)  color="${YELLOW:-\033[0;33m}" ;;
        ERROR) color="${RED:-\033[0;31m}" ;;
        DEBUG) [[ "${FWU_DEBUG:-0}" != "1" ]] && return 0; color="${CYAN:-\033[0;36m}" ;;
    esac
    echo -e "  ${color}[FWU:${level}]${NC:-\033[0m} ${msg}" >&2
}

# =============================================================================
# 1. fwu_init(project_dir) - Initialize
# =============================================================================
fwu_init() {
    local project_dir="${1:-.}"

    # Resolve project directory
    if [[ -d "$project_dir" ]]; then
        FWU_PROJECT_DIR="$(cd "$project_dir" && pwd)"
    else
        mkdir -p "$project_dir" 2>/dev/null || {
            _fwu_log "ERROR" "ディレクトリ作成失敗: $project_dir"
            return 1
        }
        FWU_PROJECT_DIR="$(cd "$project_dir" && pwd)"
    fi

    # Reset counters
    FWU_FILES_WRITTEN=0
    FWU_FILES_SKIPPED=0
    FWU_FILES_FAILED=0
    FWU_BYTES_WRITTEN=0
    FWU_ROLLBACK_COUNT=0
    FWU_FILES_VALIDATED=0
    FWU_WRITTEN_LIST=()
    FWU_SKIPPED_LIST=()
    FWU_FAILED_LIST=()
    FWU_MANIFEST=()

    # Set up staging directory (temp workspace for atomic writes)
    FWU_STAGING_DIR="${SESSION_LOG_DIR:-/tmp}/fwu_staging_$$"
    mkdir -p "$FWU_STAGING_DIR" 2>/dev/null || {
        _fwu_log "ERROR" "ステージングディレクトリ作成失敗"
        return 1
    }

    # Set up backup directory
    FWU_BACKUP_DIR="${FWU_PROJECT_DIR}/.fwu-backups/$(date +%Y%m%d_%H%M%S)"
    mkdir -p "$FWU_BACKUP_DIR" 2>/dev/null || true

    # Manifest file (persistent across runs within session)
    FWU_MANIFEST_FILE="${FWU_PROJECT_DIR}/.fwu-manifest.sha256"

    # Load existing manifest if present
    _fwu_load_manifest

    _fwu_log "OK" "Unified FileWriter v${FWU_VERSION} 初期化完了"
    _fwu_log "INFO" "  project=${FWU_PROJECT_DIR}"
    _fwu_log "DEBUG" "  staging=${FWU_STAGING_DIR}"
    _fwu_log "DEBUG" "  backup=${FWU_BACKUP_DIR}"
}

# =============================================================================
# Manifest Operations
# =============================================================================
_fwu_load_manifest() {
    FWU_MANIFEST=()
    [[ ! -f "$FWU_MANIFEST_FILE" ]] && return 0

    while IFS=: read -r hash filepath; do
        [[ -z "$hash" || -z "$filepath" ]] && continue
        # Trim whitespace
        hash="${hash## }"; hash="${hash%% }"
        filepath="${filepath## }"; filepath="${filepath%% }"
        FWU_MANIFEST["$filepath"]="$hash"
    done < "$FWU_MANIFEST_FILE"

    _fwu_log "DEBUG" "マニフェストロード: ${#FWU_MANIFEST[@]} エントリ"
}

_fwu_save_manifest() {
    [[ -z "$FWU_MANIFEST_FILE" ]] && return 1

    local tmp_manifest="${FWU_MANIFEST_FILE}.tmp.$$"
    : > "$tmp_manifest"

    local path
    for path in "${!FWU_MANIFEST[@]}"; do
        echo "${FWU_MANIFEST[$path]}:${path}" >> "$tmp_manifest"
    done

    mv -f "$tmp_manifest" "$FWU_MANIFEST_FILE" 2>/dev/null || {
        _fwu_log "WARN" "マニフェスト保存失敗"
        rm -f "$tmp_manifest" 2>/dev/null
        return 1
    }
}

_fwu_hash_content() {
    local content="$1"
    if command -v shasum &>/dev/null; then
        printf '%s' "$content" | shasum -a 256 | cut -d' ' -f1
    elif command -v sha256sum &>/dev/null; then
        printf '%s' "$content" | sha256sum | cut -d' ' -f1
    else
        # Fallback: use cksum (less secure but always available)
        printf '%s' "$content" | cksum | cut -d' ' -f1
    fi
}

# =============================================================================
# Path Validation (consolidated from FW1/FW2/FW3)
# =============================================================================
_fwu_validate_path() {
    local filepath="$1"

    # Empty path
    [[ -z "$filepath" ]] && return 1

    # Absolute path
    [[ "$filepath" == /* ]] && {
        _fwu_log "WARN" "絶対パス拒否: ${filepath}"
        return 1
    }

    # Directory traversal
    [[ "$filepath" == *../* || "$filepath" == */../* || "$filepath" == ..* ]] && {
        _fwu_log "WARN" "パストラバーサル拒否: ${filepath}"
        return 1
    }

    # Sensitive files
    case "$filepath" in
        .env|.env.*|*.pem|*.key|*.p12|id_rsa*|*.pfx|*.secret)
            _fwu_log "WARN" "機密ファイル拒否: ${filepath}"
            return 1 ;;
        node_modules/*|.git/*|__pycache__/*|.fwu-backups/*)
            _fwu_log "WARN" "システムディレクトリ拒否: ${filepath}"
            return 1 ;;
    esac

    # Must have a file extension
    local basename="${filepath##*/}"
    [[ "$basename" != *.* ]] && {
        _fwu_log "WARN" "拡張子なしファイル拒否: ${filepath}"
        return 1
    }

    return 0
}

# Strip leading ./ and trim whitespace from path
_fwu_clean_path() {
    local p="$1"
    # Trim whitespace
    p="${p#"${p%%[![:space:]]*}"}"
    p="${p%"${p##*[![:space:]]}"}"
    # Strip quotes
    p="${p#\"}" ; p="${p%\"}"
    p="${p#\'}" ; p="${p%\'}"
    p="${p#\`}" ; p="${p%\`}"
    # Strip leading ./
    [[ "$p" == ./* ]] && p="${p:2}"
    echo "$p"
}

# =============================================================================
# Syntax Verification
# =============================================================================
_fwu_verify_syntax() {
    local filepath="$1" staged_file="$2"
    local ext="${filepath##*.}"

    case "$ext" in
        js|mjs|cjs)
            if command -v node &>/dev/null; then
                node --check "$staged_file" 2>/dev/null && return 0
                _fwu_log "WARN" "JS構文エラー: ${filepath}"
                return 1
            fi ;;
        py)
            if command -v python3 &>/dev/null; then
                python3 -c "compile(open('${staged_file}').read(), '${staged_file}', 'exec')" 2>/dev/null && return 0
                _fwu_log "WARN" "Python構文エラー: ${filepath}"
                return 1
            fi ;;
        json)
            if command -v python3 &>/dev/null; then
                python3 -c "import json; json.load(open('${staged_file}'))" 2>/dev/null && return 0
                _fwu_log "WARN" "JSON構文エラー: ${filepath}"
                return 1
            elif command -v node &>/dev/null; then
                node -e "JSON.parse(require('fs').readFileSync('${staged_file}','utf8'))" 2>/dev/null && return 0
                _fwu_log "WARN" "JSON構文エラー: ${filepath}"
                return 1
            fi ;;
        sh|bash)
            if command -v bash &>/dev/null; then
                bash -n "$staged_file" 2>/dev/null && return 0
                _fwu_log "WARN" "Shell構文エラー: ${filepath}"
                return 1
            fi ;;
        # v149: TypeScript syntax validation
        ts|tsx)
            if command -v node &>/dev/null && command -v npx &>/dev/null; then
                local _ts_check
                _ts_check=$(npx --yes tsc --noEmit --allowJs --esModuleInterop --jsx react-jsx --moduleResolution node --target es2020 --skipLibCheck "$staged_file" 2>&1 || true)
                if echo "$_ts_check" | grep -qE "error TS[0-9]"; then
                    # Only fail on critical syntax errors (TS1xxx), not type errors
                    if echo "$_ts_check" | grep -qE "error TS1[0-9]{3}:"; then
                        FWU_FILES_FAILED=$((FWU_FILES_FAILED + 1))
                        _fwu_log "ERROR" "TypeScript構文エラー: ${filepath}"
                        echo "$_ts_check" | grep "error TS1" | head -5 >&2
                        return 1
                    fi
                    _fwu_log "INFO" "TypeScript型警告あり（構文OK）: ${filepath}"
                fi
                FWU_FILES_VALIDATED=$((FWU_FILES_VALIDATED + 1))
                return 0
            fi ;;
        jsx)
            if command -v node &>/dev/null; then
                node --check "$staged_file" 2>/dev/null && return 0
                _fwu_log "WARN" "JSX構文エラー: ${filepath}"
                return 1
            fi ;;
    esac

    # No checker available or unsupported extension - pass
    return 0
}

# =============================================================================
# Backup a single file before overwrite
# =============================================================================
_fwu_backup_file() {
    local filepath="$1"
    local full_src="${FWU_PROJECT_DIR}/${filepath}"

    [[ ! -f "$full_src" ]] && return 0  # Nothing to back up

    local backup_dest="${FWU_BACKUP_DIR}/${filepath}"
    local backup_parent
    backup_parent="$(dirname "$backup_dest")"
    mkdir -p "$backup_parent" 2>/dev/null || true
    cp -p "$full_src" "$backup_dest" 2>/dev/null || {
        _fwu_log "WARN" "バックアップ失敗: ${filepath}"
        return 1
    }
    _fwu_log "DEBUG" "バックアップ: ${filepath}"
    return 0
}

# =============================================================================
# Atomic write: staging -> verify -> mv
# =============================================================================
_fwu_atomic_write() {
    local filepath="$1" content="$2"

    # Stage: write to temp location
    local staged_path="${FWU_STAGING_DIR}/${filepath}"
    local staged_parent
    staged_parent="$(dirname "$staged_path")"
    mkdir -p "$staged_parent" 2>/dev/null || {
        _fwu_log "ERROR" "ステージングディレクトリ作成失敗: ${staged_parent}"
        return 1
    }

    printf '%s\n' "$content" > "$staged_path" 2>/dev/null || {
        _fwu_log "ERROR" "ステージング書き込み失敗: ${filepath}"
        return 1
    }

    # Verify syntax
    if ! _fwu_verify_syntax "$filepath" "$staged_path"; then
        _fwu_log "WARN" "構文検証失敗 - 前バージョンを保持: ${filepath}"
        FWU_FILES_FAILED=$((FWU_FILES_FAILED + 1))
        FWU_FAILED_LIST+=("$filepath")
        rm -f "$staged_path" 2>/dev/null
        return 1
    fi

    # Backup existing file
    _fwu_backup_file "$filepath"

    # Atomic move to project
    local dest="${FWU_PROJECT_DIR}/${filepath}"
    local dest_parent
    dest_parent="$(dirname "$dest")"
    mkdir -p "$dest_parent" 2>/dev/null || {
        _fwu_log "ERROR" "宛先ディレクトリ作成失敗: ${dest_parent}"
        return 1
    }

    mv -f "$staged_path" "$dest" 2>/dev/null || {
        # Fallback: cp + rm (cross-device moves)
        cp -f "$staged_path" "$dest" 2>/dev/null && rm -f "$staged_path" 2>/dev/null || {
            _fwu_log "ERROR" "アトミック書き込み失敗: ${filepath}"
            return 1
        }
    }

    # Set executable permission for scripts
    case "$filepath" in
        *.sh|*.bash) chmod +x "$dest" 2>/dev/null ;;
        *.py)
            head -1 "$dest" 2>/dev/null | grep -q '^#!' && chmod +x "$dest" 2>/dev/null
            ;;
    esac

    # Update stats
    local bytes
    bytes="$(wc -c < "$dest" 2>/dev/null || echo 0)"
    bytes="${bytes## }"
    FWU_FILES_WRITTEN=$((FWU_FILES_WRITTEN + 1))
    FWU_BYTES_WRITTEN=$((FWU_BYTES_WRITTEN + bytes))
    FWU_WRITTEN_LIST+=("$filepath")

    # Update manifest
    local hash
    hash="$(_fwu_hash_content "$content")"
    FWU_MANIFEST["$filepath"]="$hash"

    _fwu_log "OK" "書込完了: ${filepath} (${bytes}B)"
    return 0
}

# =============================================================================
# 2. fwu_parse_and_write(claude_output, project_dir) - Main Entry Point
# =============================================================================
fwu_parse_and_write() {
    local claude_output="$1"
    local project_dir="${2:-$FWU_PROJECT_DIR}"

    [[ -z "$claude_output" ]] && {
        _fwu_log "WARN" "空の出力"
        echo "0"
        return 0
    }

    # Auto-init if needed
    if [[ -z "$FWU_PROJECT_DIR" || "$FWU_PROJECT_DIR" != "$project_dir" ]]; then
        fwu_init "${project_dir:-.}"
    fi

    # ── Parse Phase ──
    # Collect files as newline-separated "path\x00content" pairs in a temp dir
    local parse_dir="${FWU_STAGING_DIR}/_parsed_$$"
    mkdir -p "$parse_dir" 2>/dev/null

    local file_count=0

    # Strategy A: --- FILE: path --- ... --- END FILE --- markers
    file_count=$(_fwu_parse_strategy_markers "$claude_output" "$parse_dir")

    # Strategy B: ```lang:path code blocks (if A found nothing)
    if [[ "$file_count" -eq 0 ]]; then
        file_count=$(_fwu_parse_strategy_codeblocks "$claude_output" "$parse_dir")
    fi

    # Strategy C: Heuristic // filename: comments (if B found nothing)
    if [[ "$file_count" -eq 0 ]]; then
        file_count=$(_fwu_parse_strategy_heuristic "$claude_output" "$parse_dir")
    fi

    if [[ "$file_count" -eq 0 ]]; then
        _fwu_log "WARN" "ファイルブロックが検出されませんでした"
        rm -rf "$parse_dir" 2>/dev/null
        echo "0"
        return 0
    fi

    _fwu_log "INFO" "パース完了: ${file_count} ファイル検出"

    # ── Dedup + Write Phase ──
    local written=0
    local idx
    for idx in $(seq 0 $((file_count - 1))); do
        local meta_file="${parse_dir}/${idx}.meta"
        local content_file="${parse_dir}/${idx}.content"
        [[ ! -f "$meta_file" || ! -f "$content_file" ]] && continue

        local filepath
        filepath="$(cat "$meta_file" 2>/dev/null)"
        filepath="$(_fwu_clean_path "$filepath")"

        # Validate path
        if ! _fwu_validate_path "$filepath"; then
            FWU_FILES_SKIPPED=$((FWU_FILES_SKIPPED + 1))
            FWU_SKIPPED_LIST+=("${filepath}(invalid)")
            continue
        fi

        local content
        content="$(cat "$content_file" 2>/dev/null)"

        # Dedup: check manifest for same hash
        local new_hash
        new_hash="$(_fwu_hash_content "$content")"
        local existing_hash="${FWU_MANIFEST[$filepath]:-}"

        if [[ -n "$existing_hash" && "$existing_hash" == "$new_hash" ]]; then
            _fwu_log "DEBUG" "スキップ（同一ハッシュ）: ${filepath}"
            FWU_FILES_SKIPPED=$((FWU_FILES_SKIPPED + 1))
            FWU_SKIPPED_LIST+=("${filepath}(dup)")
            continue
        fi

        if [[ -n "$existing_hash" && "$existing_hash" != "$new_hash" ]]; then
            _fwu_log "WARN" "上書き（ハッシュ変更）: ${filepath}"
        fi

        # Atomic write
        if _fwu_atomic_write "$filepath" "$content"; then
            written=$((written + 1))
        fi
    done

    # ── Manifest Phase ──
    _fwu_save_manifest

    # Cleanup parse dir
    rm -rf "$parse_dir" 2>/dev/null

    _fwu_log "OK" "書込完了: ${written}ファイル / スキップ: ${FWU_FILES_SKIPPED} / 失敗: ${FWU_FILES_FAILED}"

    echo "$written"
}

# =============================================================================
# Parse Strategy A: --- FILE: path --- ... --- END FILE --- markers
# =============================================================================
_fwu_parse_strategy_markers() {
    local text="$1" parse_dir="$2"
    local count=0 in_file=false current_path="" current_content=""

    while IFS= read -r line; do
        # Detect start marker: --- FILE: path/to/file.ext ---
        if [[ "$line" =~ ^---[[:space:]]+FILE:[[:space:]]*(.+)[[:space:]]+---[[:space:]]*$ ]]; then
            # Save previous block
            if [[ "$in_file" == true && -n "$current_path" ]]; then
                echo "$current_path" > "${parse_dir}/${count}.meta"
                printf '%s' "$current_content" > "${parse_dir}/${count}.content"
                count=$((count + 1))
            fi
            current_path="${BASH_REMATCH[1]}"
            current_content=""
            in_file=true
            continue
        fi

        # Detect end marker: --- END FILE ---
        if [[ "$line" =~ ^---[[:space:]]+END[[:space:]]+FILE[[:space:]]+---[[:space:]]*$ ]]; then
            if [[ "$in_file" == true && -n "$current_path" ]]; then
                echo "$current_path" > "${parse_dir}/${count}.meta"
                printf '%s' "$current_content" > "${parse_dir}/${count}.content"
                count=$((count + 1))
            fi
            current_path=""
            current_content=""
            in_file=false
            continue
        fi

        # Accumulate content
        if [[ "$in_file" == true ]]; then
            [[ -n "$current_content" ]] && current_content+=$'\n'
            current_content+="$line"
        fi
    done <<< "$text"

    # Flush last block if no END marker
    if [[ "$in_file" == true && -n "$current_path" && -n "$current_content" ]]; then
        echo "$current_path" > "${parse_dir}/${count}.meta"
        printf '%s' "$current_content" > "${parse_dir}/${count}.content"
        count=$((count + 1))
    fi

    echo "$count"
}

# =============================================================================
# Parse Strategy B: ```lang:path code blocks
# =============================================================================
_fwu_parse_strategy_codeblocks() {
    local text="$1" parse_dir="$2"

    # Use Python for reliable multi-line regex if available
    if command -v python3 &>/dev/null; then
        _fwu_parse_codeblocks_python "$text" "$parse_dir"
        return
    fi

    # Bash fallback
    _fwu_parse_codeblocks_bash "$text" "$parse_dir"
}

_fwu_parse_codeblocks_python() {
    local text="$1" parse_dir="$2"
    local tmp_input="${FWU_STAGING_DIR}/_cb_input_$$.txt"
    printf '%s\n' "$text" > "$tmp_input"

    python3 << 'PYEOF' "$tmp_input" "$parse_dir" 2>/dev/null
import sys, re, os

input_file = sys.argv[1]
parse_dir = sys.argv[2]

with open(input_file, 'r', encoding='utf-8', errors='replace') as f:
    content = f.read()

patterns = [
    # Pattern 1: ```lang:path\n...\n```
    re.compile(r'```(?:[a-zA-Z0-9_+-]+):([^\n`]+)\n(.*?)```', re.DOTALL),
    # Pattern 2: **path** followed by code block
    re.compile(r'\*\*([a-zA-Z0-9_./-]+\.[a-zA-Z0-9]+)\*\*[^\n]*\n\s*```[a-zA-Z0-9_+-]*\n(.*?)```', re.DOTALL),
    # Pattern 3: `path` heading followed by code block
    re.compile(r'`([a-zA-Z0-9_./-]+\.[a-zA-Z0-9]+)`[^\n]*\n\s*```[a-zA-Z0-9_+-]*\n(.*?)```', re.DOTALL),
]

seen = set()
count = 0

for pattern in patterns:
    for m in pattern.finditer(content):
        path = m.group(1).strip().strip('`"\'').strip()
        code = m.group(2)
        if path.startswith('./'):
            path = path[2:]
        if not path or '..' in path or path.startswith('/'):
            continue
        if '.' not in os.path.basename(path):
            continue
        if path in seen:
            continue
        seen.add(path)

        with open(os.path.join(parse_dir, f'{count}.meta'), 'w') as mf:
            mf.write(path)
        with open(os.path.join(parse_dir, f'{count}.content'), 'w') as cf:
            cf.write(code)
        count += 1

print(count)
PYEOF

    rm -f "$tmp_input" 2>/dev/null
}

_fwu_parse_codeblocks_bash() {
    local text="$1" parse_dir="$2"
    local count=0 in_fenced=false current_path="" current_content=""

    while IFS= read -r line; do
        # Detect opening: ```lang:path
        if [[ "$in_fenced" == false && "$line" =~ ^\`\`\`[a-zA-Z0-9_+-]*:(.+)$ ]]; then
            # Save previous
            if [[ -n "$current_path" && -n "$current_content" ]]; then
                echo "$current_path" > "${parse_dir}/${count}.meta"
                printf '%s' "$current_content" > "${parse_dir}/${count}.content"
                count=$((count + 1))
            fi
            current_path="${BASH_REMATCH[1]}"
            current_content=""
            in_fenced=true
            continue
        fi

        # Detect closing: ```
        if [[ "$in_fenced" == true && "$line" =~ ^\`\`\`[[:space:]]*$ ]]; then
            if [[ -n "$current_path" ]]; then
                echo "$current_path" > "${parse_dir}/${count}.meta"
                printf '%s' "$current_content" > "${parse_dir}/${count}.content"
                count=$((count + 1))
            fi
            current_path=""
            current_content=""
            in_fenced=false
            continue
        fi

        # Accumulate
        if [[ "$in_fenced" == true ]]; then
            [[ -n "$current_content" ]] && current_content+=$'\n'
            current_content+="$line"
        fi
    done <<< "$text"

    echo "$count"
}

# =============================================================================
# Parse Strategy C: Heuristic (// filename: or # filename: comments)
# =============================================================================
_fwu_parse_strategy_heuristic() {
    local text="$1" parse_dir="$2"
    local count=0 current_path="" current_content="" in_block=false in_fenced=false

    while IFS= read -r line; do
        local new_path=""

        # Pattern: // filename: path  or  # filename: path
        if [[ "$line" =~ ^[[:space:]]*(//|#)[[:space:]]*[Ff]ile(name)?:[[:space:]]*(.+)$ ]]; then
            new_path="${BASH_REMATCH[3]}"
        # Pattern: --- path/to/file.ext ---
        elif [[ "$line" =~ ^---[[:space:]]+([a-zA-Z0-9_./-]+\.[a-zA-Z0-9]+)[[:space:]]+---[[:space:]]*$ ]]; then
            new_path="${BASH_REMATCH[1]}"
        # Pattern: /* path/to/file.ext */
        elif [[ "$line" =~ ^/\*[[:space:]]+([a-zA-Z0-9_./-]+\.[a-zA-Z0-9]+)[[:space:]]+\*/[[:space:]]*$ ]]; then
            new_path="${BASH_REMATCH[1]}"
        fi

        # Handle fenced block start within heuristic mode
        if [[ "$in_block" == true && "$in_fenced" == false && "$line" =~ ^\`\`\`[a-zA-Z0-9_+-]*$ ]]; then
            in_fenced=true
            continue
        fi

        # Fenced block end
        if [[ "$in_fenced" == true && "$line" =~ ^\`\`\`[[:space:]]*$ ]]; then
            in_fenced=false
            continue
        fi

        # New file marker detected
        if [[ -n "$new_path" ]]; then
            # Save previous block
            if [[ "$in_block" == true && -n "$current_path" && -n "$current_content" ]]; then
                echo "$current_path" > "${parse_dir}/${count}.meta"
                printf '%s' "$current_content" > "${parse_dir}/${count}.content"
                count=$((count + 1))
            fi
            current_path="$new_path"
            current_content=""
            in_block=true
            in_fenced=false
            continue
        fi

        # Accumulate content
        if [[ "$in_block" == true ]]; then
            [[ -n "$current_content" ]] && current_content+=$'\n'
            current_content+="$line"
        fi
    done <<< "$text"

    # Flush last block
    if [[ "$in_block" == true && -n "$current_path" && -n "$current_content" ]]; then
        echo "$current_path" > "${parse_dir}/${count}.meta"
        printf '%s' "$current_content" > "${parse_dir}/${count}.content"
        count=$((count + 1))
    fi

    echo "$count"
}

# =============================================================================
# 3. fwu_rollback() - Restore all files from backup
# =============================================================================
fwu_rollback() {
    [[ -z "$FWU_BACKUP_DIR" || ! -d "$FWU_BACKUP_DIR" ]] && {
        _fwu_log "WARN" "バックアップディレクトリが存在しません"
        return 1
    }
    [[ -z "$FWU_PROJECT_DIR" ]] && {
        _fwu_log "ERROR" "project_dir未設定"
        return 1
    }

    local restored=0

    # Walk backup directory and restore each file
    while IFS= read -r backup_file; do
        [[ -z "$backup_file" ]] && continue
        local rel_path="${backup_file#${FWU_BACKUP_DIR}/}"
        local dest="${FWU_PROJECT_DIR}/${rel_path}"
        local dest_parent
        dest_parent="$(dirname "$dest")"
        mkdir -p "$dest_parent" 2>/dev/null || true

        if cp -f "$backup_file" "$dest" 2>/dev/null; then
            _fwu_log "OK" "復元: ${rel_path}"
            restored=$((restored + 1))
        else
            _fwu_log "ERROR" "復元失敗: ${rel_path}"
        fi
    done < <(find "$FWU_BACKUP_DIR" -type f 2>/dev/null)

    FWU_ROLLBACK_COUNT=$((FWU_ROLLBACK_COUNT + restored))
    _fwu_log "OK" "ロールバック完了: ${restored} ファイル復元"

    # Reload manifest from disk (may have changed)
    _fwu_load_manifest

    return 0
}

# =============================================================================
# 4. fwu_get_manifest() - Return manifest contents
# =============================================================================
fwu_get_manifest() {
    if [[ -f "$FWU_MANIFEST_FILE" ]]; then
        cat "$FWU_MANIFEST_FILE"
    else
        local path
        for path in "${!FWU_MANIFEST[@]}"; do
            echo "${FWU_MANIFEST[$path]}:${path}"
        done
    fi
}

# =============================================================================
# 5. fwu_write_single(filepath, content) - Write a single file directly
# =============================================================================
fwu_write_single() {
    local filepath="$1" content="$2"

    [[ -z "$filepath" || -z "$content" ]] && {
        _fwu_log "ERROR" "filepath or content is empty"
        return 1
    }

    # Auto-init if needed
    [[ -z "$FWU_PROJECT_DIR" ]] && fwu_init "."

    filepath="$(_fwu_clean_path "$filepath")"

    if ! _fwu_validate_path "$filepath"; then
        return 1
    fi

    _fwu_atomic_write "$filepath" "$content"
}

# =============================================================================
# 6. fwu_cleanup() - Clean up staging directory
# =============================================================================
fwu_cleanup() {
    [[ -n "$FWU_STAGING_DIR" && -d "$FWU_STAGING_DIR" ]] && {
        rm -rf "$FWU_STAGING_DIR" 2>/dev/null
        _fwu_log "DEBUG" "ステージングクリーンアップ完了"
    }
}

# =============================================================================
# Standard MR Interface: report / report_json / score
# =============================================================================
fwu_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Unified File Writer v${FWU_VERSION} ===${NC:-\033[0m}"
    echo -e "  Files written:  ${FWU_FILES_WRITTEN}"
    echo -e "  Files skipped:  ${FWU_FILES_SKIPPED}"
    echo -e "  Files failed:   ${FWU_FILES_FAILED}"
    echo -e "  Files validated: ${FWU_FILES_VALIDATED}"
    echo -e "  Bytes written:  ${FWU_BYTES_WRITTEN}"
    echo -e "  Rollbacks:      ${FWU_ROLLBACK_COUNT}"
    echo -e "  Manifest entries: ${#FWU_MANIFEST[@]}"
    echo -e "  Score: $(fwu_score)/100"

    if [[ ${#FWU_FAILED_LIST[@]} -gt 0 ]]; then
        echo -e "  ${RED:-\033[0;31m}Failed files:${NC:-\033[0m}"
        local f
        for f in "${FWU_FAILED_LIST[@]}"; do
            echo -e "    - ${f}"
        done
    fi
}

fwu_report_json() {
    local written_json="["
    local first=true
    local f
    for f in "${FWU_WRITTEN_LIST[@]}"; do
        [[ "$first" == true ]] && first=false || written_json+=","
        written_json+="\"${f}\""
    done
    written_json+="]"

    local failed_json="["
    first=true
    for f in "${FWU_FAILED_LIST[@]}"; do
        [[ "$first" == true ]] && first=false || failed_json+=","
        failed_json+="\"${f}\""
    done
    failed_json+="]"

    cat <<JSONEOF
{
  "module": "file-writer-unified",
  "version": "${FWU_VERSION}",
  "files_written": ${FWU_FILES_WRITTEN},
  "files_skipped": ${FWU_FILES_SKIPPED},
  "files_failed": ${FWU_FILES_FAILED},
  "bytes_written": ${FWU_BYTES_WRITTEN},
  "rollback_count": ${FWU_ROLLBACK_COUNT},
  "manifest_entries": ${#FWU_MANIFEST[@]},
  "written_files": ${written_json},
  "failed_files": ${failed_json},
  "score": $(fwu_score)
}
JSONEOF
}

fwu_score() {
    # Score based on success rate
    local total=$((FWU_FILES_WRITTEN + FWU_FILES_FAILED))
    if [[ $total -eq 0 ]]; then
        echo "100"
        return
    fi

    local success_rate=$(( (FWU_FILES_WRITTEN * 100) / total ))

    # Penalize if many files failed
    if [[ $FWU_FILES_FAILED -gt 0 ]]; then
        local penalty=$(( FWU_FILES_FAILED * 5 ))
        [[ $penalty -gt 40 ]] && penalty=40
        success_rate=$((success_rate - penalty))
    fi

    [[ $success_rate -lt 0 ]] && success_rate=0
    [[ $success_rate -gt 100 ]] && success_rate=100
    echo "$success_rate"
}

# Init message for MR
_fwu_init_message() {
    echo "Unified FileWriter v${FWU_VERSION} | atomic+verify+rollback"
}

# =============================================================================
# Backward-compatible aliases
# =============================================================================
# fw2_parse_and_write() from file-writer-v2.sh
fw2_parse_and_write() { fwu_parse_and_write "$@"; }

# fw_smart_write() generic alias
fw_smart_write() { fwu_parse_and_write "$@"; }

# fw_write_from_claude() from file-writer.sh (v1)
fw_write_from_claude() { fwu_parse_and_write "$@"; }

# fw3_write() from file-writer-v3.sh (simple redirect - no merge semantics)
fw3_write() { fwu_parse_and_write "$@"; }

# v2034.2 配線監査修復: chain.sh:970-972 で呼ばれる report エイリアスを補完
# (fwu_report が存在するため、レガシー名前空間も同一実装に流す)
fw2_report() { fwu_report "$@"; }
fw3_report() { fwu_report "$@"; }
fw_report()  { fwu_report "$@"; }

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "file-writer-unified" \
        --version "$FWU_VERSION" \
        --description "統合ファイルライター - atomic書込×構文検証×SHA256マニフェスト×ロールバック" \
        --init "fwu_init" \
        --report "fwu_report" \
        --score "fwu_score" \
        --enable-var "ENABLE_FWU" \
        --cli-flags "--file-writer-unified:--no-file-writer-unified" \
        --init-msg "_fwu_init_message"
fi

# Cleanup on exit
# v2000.0: EXIT trapはchain.shが管理。source時にtrap上書きしない
# trap 'fwu_cleanup' EXIT 2>/dev/null || true
