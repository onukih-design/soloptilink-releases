#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2015.0 - Cross-Domain Intelligence Engine
# =============================================================================
# プロジェクトドメイン間でパターンを学習し、あるドメインのベストプラクティスを
# 別ドメインに適用することで、出力品質をユニバーサルに向上させるエンジン。
#
# ecommerceのカートパターン → bookingの予約パターン
# healthcareの監査ログ → コンプライアンス要件のある全ドメイン
# CRMの連絡先管理 → HRの従業員管理
# chatのリアルタイム機能 → helpdeskのチケット通知
#
# Functions:
#   cdi_init                          - クロスドメインインテリジェンス初期化
#   cdi_analyze_domain_patterns       - ドメインからパターンを抽出
#   cdi_find_cross_applicable_patterns - ドメイン間パターン適用検出
#   cdi_build_universal_quality_rules - 全ドメイン共通品質ルール構築
#   cdi_inject_learned_patterns       - プロンプトへの学習パターン注入
#   cdi_analyze_session_outcomes      - セッション結果分析・学習
#   cdi_get_domain_quality_profile    - ドメイン品質プロファイル取得
#   cdi_suggest_architecture          - アーキテクチャ提案
#   cdi_build_pattern_library         - パターンライブラリ構築・更新
#   cdi_get_intelligence_report       - インテリジェンスダッシュボード
#
# All globals use the CDI_ prefix.
# =============================================================================

[[ -n "${_CROSS_DOMAIN_INTELLIGENCE_LOADED:-}" ]] && return 0
_CROSS_DOMAIN_INTELLIGENCE_LOADED=1

declare -g CDI_VERSION="2015.0"
declare -g CDI_ENABLED="${CDI_ENABLED:-true}"

# --- Directories ---
declare -g CDI_DOMAIN_DIR="${SCRIPT_DIR:-$HOME/.soloptilink}/domains"
declare -g CDI_LEARNING_DIR="${SCRIPT_DIR:-$HOME/.soloptilink}/learning"
declare -g CDI_PATTERN_DIR="${CDI_LEARNING_DIR}/patterns"

# --- State ---
declare -g CDI_INITIALIZED=false
declare -g CDI_DOMAIN_COUNT=0
declare -g CDI_PATTERN_COUNT=0
declare -g CDI_UNIVERSAL_RULE_COUNT=0
declare -g CDI_CROSS_MATCH_COUNT=0
declare -g CDI_SESSION_ANALYZED=0

# --- Pattern type constants ---
declare -g CDI_PTYPE_AUTH="auth"
declare -g CDI_PTYPE_CRUD="crud"
declare -g CDI_PTYPE_SEARCH="search"
declare -g CDI_PTYPE_PAGINATION="pagination"
declare -g CDI_PTYPE_FILE_UPLOAD="file_upload"
declare -g CDI_PTYPE_REALTIME="realtime"
declare -g CDI_PTYPE_AUDIT="audit_logging"
declare -g CDI_PTYPE_NOTIFICATION="notification"
declare -g CDI_PTYPE_DASHBOARD="dashboard"
declare -g CDI_PTYPE_WORKFLOW="workflow"
declare -g CDI_PTYPE_CALENDAR="calendar"
declare -g CDI_PTYPE_PAYMENT="payment"
declare -g CDI_PTYPE_REPORTING="reporting"
declare -g CDI_PTYPE_IMPORT_EXPORT="import_export"
declare -g CDI_PTYPE_ROLE_ACCESS="role_access"

# --- Cross-domain mapping table ---
# source_pattern -> target_adaptation
declare -gA CDI_CROSS_MAP=()

# --- Logging helpers (fallback if not loaded) ---
if ! command -v log_info &>/dev/null; then
    log_info()  { echo "[INFO]  $(date '+%H:%M:%S') $*"; }
    log_warn()  { echo "[WARN]  $(date '+%H:%M:%S') $*"; }
    log_error() { echo "[ERROR] $(date '+%H:%M:%S') $*"; }
fi

# =============================================================================
# cdi_init - クロスドメインインテリジェンス初期化
# =============================================================================
# Load domain registry, historical session data, build pattern index
# =============================================================================
cdi_init() {
    if [[ "$CDI_INITIALIZED" == "true" ]]; then
        log_info "CDI: Already initialized (v${CDI_VERSION})"
        return 0
    fi

    log_info "CDI: Initializing Cross-Domain Intelligence Engine v${CDI_VERSION}"

    # Ensure directories exist
    mkdir -p "$CDI_DOMAIN_DIR" "$CDI_LEARNING_DIR" "$CDI_PATTERN_DIR" \
             "$CDI_LEARNING_DIR/errors" "$CDI_LEARNING_DIR/quality" \
             "$CDI_LEARNING_DIR/solutions" "$CDI_LEARNING_DIR/prompts" \
             "$CDI_LEARNING_DIR/sessions" 2>/dev/null

    # Reset counters
    CDI_DOMAIN_COUNT=0
    CDI_PATTERN_COUNT=0
    CDI_UNIVERSAL_RULE_COUNT=0
    CDI_CROSS_MATCH_COUNT=0
    CDI_SESSION_ANALYZED=0

    # Count available domain JSONs
    local domain_file
    for domain_file in "$CDI_DOMAIN_DIR"/../*.json; do
        [[ -f "$domain_file" ]] || continue
        local basename
        basename="$(basename "$domain_file" .json)"
        [[ "$basename" == _* ]] && continue
        CDI_DOMAIN_COUNT=$((CDI_DOMAIN_COUNT + 1))
    done

    # Also count domains subdirectory
    for domain_file in "$CDI_DOMAIN_DIR"/*.json; do
        [[ -f "$domain_file" ]] || continue
        CDI_DOMAIN_COUNT=$((CDI_DOMAIN_COUNT + 1))
    done

    # Load historical session count
    if [[ -f "$CDI_LEARNING_DIR/quality/scores.jsonl" ]]; then
        CDI_SESSION_ANALYZED=$(wc -l < "$CDI_LEARNING_DIR/quality/scores.jsonl" 2>/dev/null | tr -d ' ')
    fi

    # Load existing pattern count
    if [[ -d "$CDI_PATTERN_DIR" ]]; then
        CDI_PATTERN_COUNT=$(find "$CDI_PATTERN_DIR" -name "*.json" 2>/dev/null | wc -l | tr -d ' ')
    fi

    # Build cross-domain mapping table
    _cdi_build_cross_map

    CDI_INITIALIZED=true
    log_info "CDI: Initialized - ${CDI_DOMAIN_COUNT} domains, ${CDI_PATTERN_COUNT} patterns, ${CDI_SESSION_ANALYZED} sessions analyzed"
    return 0
}

# =============================================================================
# Internal: Build cross-domain pattern mapping
# =============================================================================
_cdi_build_cross_map() {
    # ecommerce cart -> booking reservation
    CDI_CROSS_MAP["ecommerce:cart->booking"]="cart_to_reservation: CartItem(productId,qty) maps to ReservationSlot(serviceId,date,time). Add availability check where stock check was."
    CDI_CROSS_MAP["ecommerce:cart->event-management"]="cart_to_ticket: CartItem maps to TicketSelection. Add seat/capacity check where stock check was."

    # healthcare audit -> compliance domains
    CDI_CROSS_MAP["healthcare:audit->accounting"]="medical_audit_to_financial: Add immutable audit trail on all financial mutations. Timestamp + userId + action + before/after snapshots."
    CDI_CROSS_MAP["healthcare:audit->hr"]="medical_audit_to_hr: Employee record changes need audit trail for labor law compliance. Track salary/role/status changes."
    CDI_CROSS_MAP["healthcare:audit->ecommerce"]="medical_audit_to_ecommerce: Order status transitions need audit for refund disputes. Log all price/status changes."

    # CRM contact management -> HR employee management
    CDI_CROSS_MAP["crm:contacts->hr"]="contact_to_employee: Contact(name,email,phone,company) maps to Employee(name,email,phone,department). Add employment-specific fields (startDate,salary,role)."
    CDI_CROSS_MAP["crm:contacts->school"]="contact_to_student: Contact maps to Student. Add enrollment-specific fields (grade,class,guardianContact)."

    # chat realtime -> notification systems
    CDI_CROSS_MAP["chat:realtime->helpdesk"]="realtime_to_ticket_notify: WebSocket room pattern -> ticket subscription. Agent gets live updates when ticket status changes."
    CDI_CROSS_MAP["chat:realtime->project-management"]="realtime_to_task_notify: Message push pattern -> task update notifications. Team members get live project activity feed."
    CDI_CROSS_MAP["chat:realtime->ecommerce"]="realtime_to_order_notify: Message delivery pattern -> order status push. Customer gets live order tracking updates."

    # booking calendar -> event/school scheduling
    CDI_CROSS_MAP["booking:calendar->event-management"]="booking_to_event_schedule: TimeSlot availability -> venue/room availability. Add multi-day span support."
    CDI_CROSS_MAP["booking:calendar->school"]="booking_to_class_schedule: Appointment slots -> class timetable. Add recurring pattern (weekly/semester)."
    CDI_CROSS_MAP["booking:calendar->healthcare"]="booking_to_appointment: Service booking -> medical appointment. Add doctor availability + specialty matching."

    # helpdesk ticket workflow -> project task workflow
    CDI_CROSS_MAP["helpdesk:workflow->project-management"]="ticket_to_task: Ticket(status,priority,assignee) -> Task(status,priority,assignee). Add dependency/subtask support."
    CDI_CROSS_MAP["helpdesk:workflow->hr"]="ticket_to_request: Support ticket flow -> HR request flow (leave/expense/onboarding). Add approval chain."

    # analytics dashboard -> any domain with KPIs
    CDI_CROSS_MAP["analytics-dashboard:kpi->ecommerce"]="dashboard_to_ecommerce_kpi: Generic chart components -> sales/revenue/conversion charts. Pre-wire date range filters."
    CDI_CROSS_MAP["analytics-dashboard:kpi->crm"]="dashboard_to_crm_kpi: Chart components -> pipeline/deal/activity metrics. Add funnel visualization."
    CDI_CROSS_MAP["analytics-dashboard:kpi->healthcare"]="dashboard_to_healthcare_kpi: Chart components -> patient/appointment/revenue metrics. Add compliance summary."

    # ecommerce payment -> any domain with billing
    CDI_CROSS_MAP["ecommerce:payment->booking"]="payment_to_booking_billing: Checkout flow -> reservation payment. Add deposit/partial payment support."
    CDI_CROSS_MAP["ecommerce:payment->lms"]="payment_to_course_billing: Product purchase -> course enrollment payment. Add subscription/installment."
    CDI_CROSS_MAP["ecommerce:payment->fitness"]="payment_to_membership_billing: One-time purchase -> recurring membership. Add plan upgrade/downgrade."

    # inventory stock management -> resource management
    CDI_CROSS_MAP["inventory:stock->restaurant"]="stock_to_ingredient: SKU stock tracking -> ingredient quantity tracking. Add unit conversion (kg/L/pc)."
    CDI_CROSS_MAP["inventory:stock->event-management"]="stock_to_capacity: Stock quantity -> venue/seat capacity. Add overbooking rules."
}

# =============================================================================
# cdi_analyze_domain_patterns - ドメインからパターンを抽出
# =============================================================================
# Usage: cdi_analyze_domain_patterns <domain>
# Returns structured pattern list via stdout (JSON)
# =============================================================================
cdi_analyze_domain_patterns() {
    local domain="${1:?Usage: cdi_analyze_domain_patterns <domain>}"
    local domain_file=""

    # Locate domain JSON
    domain_file="$(_cdi_find_domain_file "$domain")"
    if [[ -z "$domain_file" || ! -f "$domain_file" ]]; then
        log_error "CDI: Domain file not found for '${domain}'"
        echo '{"error":"domain_not_found","domain":"'"$domain"'"}'
        return 1
    fi

    log_info "CDI: Analyzing patterns for domain '${domain}'"

    local patterns="[]"
    local model_names=""
    local feature_keys=""
    local api_count=0
    local has_auth=false
    local has_search=false
    local has_pagination=false
    local has_file_upload=false
    local has_realtime=false
    local has_audit=false
    local has_payment=false
    local has_calendar=false
    local has_dashboard=false
    local has_notification=false
    local has_workflow=false
    local has_import_export=false
    local has_role_access=false

    # Extract model names
    if command -v jq &>/dev/null; then
        # R3: DBL models は dict {Name:{...}}(101辞書)と list [{name,...}](8辞書)の両形式が混在する。
        # 旧 `keys[]` は list 形式で配列インデックス(0,1,2…)を返しモデル名検出が壊れるため、
        # object=keys / array=各要素の name|model|title を抽出する両型対応式へ置換する。
        model_names=$(jq -r '.models | if type=="object" then keys elif type=="array" then [.[] | (.name // .model // .title // empty)] else [] end | .[]' "$domain_file" 2>/dev/null | tr '\n' ',')
        feature_keys=$(jq -r '.domain_features // {} | keys[]' "$domain_file" 2>/dev/null | tr '\n' ',')
        api_count=$(jq -r '.api_endpoints // [] | length' "$domain_file" 2>/dev/null)
    else
        model_names=$(grep -o '"[A-Z][a-zA-Z]*"\s*:' "$domain_file" | head -30 | tr -d '":' | tr '\n' ',')
        api_count=$(grep -c '"method"' "$domain_file" 2>/dev/null || echo "0")
    fi

    # Detect pattern types from models, features, and API endpoints
    # --- Auth pattern ---
    if _cdi_domain_has_pattern "$domain_file" "User" "auth" "login" "session" "password" "token"; then
        has_auth=true
    fi

    # --- CRUD pattern (universal - check model count) ---
    local model_count
    model_count=$(echo "$model_names" | tr ',' '\n' | grep -c '[A-Z]')

    # --- Search pattern ---
    if _cdi_domain_has_pattern "$domain_file" "search" "filter" "search_fields" "query"; then
        has_search=true
    fi

    # --- Pagination ---
    if _cdi_domain_has_pattern "$domain_file" "pagination" "page" "limit" "offset" "cursor"; then
        has_pagination=true
    fi

    # --- File upload ---
    if _cdi_domain_has_pattern "$domain_file" "upload" "file" "attachment" "image" "imageUrl" "fileUrl"; then
        has_file_upload=true
    fi

    # --- Realtime ---
    if _cdi_domain_has_pattern "$domain_file" "realtime" "websocket" "socket" "live" "push" "sse"; then
        has_realtime=true
    fi

    # --- Audit logging ---
    if _cdi_domain_has_pattern "$domain_file" "audit" "log" "history" "changelog" "tracking"; then
        has_audit=true
    fi

    # --- Payment ---
    if _cdi_domain_has_pattern "$domain_file" "payment" "checkout" "billing" "invoice" "charge" "stripe"; then
        has_payment=true
    fi

    # --- Calendar/scheduling ---
    if _cdi_domain_has_pattern "$domain_file" "calendar" "schedule" "appointment" "booking" "slot" "availability"; then
        has_calendar=true
    fi

    # --- Dashboard/KPI ---
    if _cdi_domain_has_pattern "$domain_file" "dashboard" "kpi" "metrics" "analytics" "chart" "statistics"; then
        has_dashboard=true
    fi

    # --- Notification ---
    if _cdi_domain_has_pattern "$domain_file" "notification" "notify" "alert" "email" "sms"; then
        has_notification=true
    fi

    # --- Workflow/status transitions ---
    if _cdi_domain_has_pattern "$domain_file" "workflow" "status" "transition" "approval" "state_machine"; then
        has_workflow=true
    fi

    # --- Import/Export ---
    if _cdi_domain_has_pattern "$domain_file" "import" "export" "csv" "excel" "bulk"; then
        has_import_export=true
    fi

    # --- Role-based access ---
    if _cdi_domain_has_pattern "$domain_file" "role" "permission" "admin" "ADMIN" "MANAGER"; then
        has_role_access=true
    fi

    # Build pattern JSON
    local pattern_json="{"
    pattern_json+="\"domain\":\"${domain}\","
    pattern_json+="\"model_count\":${model_count:-0},"
    pattern_json+="\"api_count\":${api_count:-0},"
    pattern_json+="\"features\":\"${feature_keys}\","
    pattern_json+="\"patterns\":{"
    pattern_json+="\"auth\":${has_auth},"
    pattern_json+="\"crud\":true,"
    pattern_json+="\"search\":${has_search},"
    pattern_json+="\"pagination\":${has_pagination},"
    pattern_json+="\"file_upload\":${has_file_upload},"
    pattern_json+="\"realtime\":${has_realtime},"
    pattern_json+="\"audit_logging\":${has_audit},"
    pattern_json+="\"payment\":${has_payment},"
    pattern_json+="\"calendar\":${has_calendar},"
    pattern_json+="\"dashboard\":${has_dashboard},"
    pattern_json+="\"notification\":${has_notification},"
    pattern_json+="\"workflow\":${has_workflow},"
    pattern_json+="\"import_export\":${has_import_export},"
    pattern_json+="\"role_access\":${has_role_access}"
    pattern_json+="},"
    pattern_json+="\"reusable_patterns\":["

    # List reusable patterns with detail
    local first=true
    if [[ "$has_auth" == "true" ]]; then
        [[ "$first" != "true" ]] && pattern_json+=","
        pattern_json+="{\"type\":\"auth\",\"description\":\"Authentication/session management\",\"universality\":\"high\"}"
        first=false
    fi
    if [[ "$has_search" == "true" ]]; then
        [[ "$first" != "true" ]] && pattern_json+=","
        pattern_json+="{\"type\":\"search\",\"description\":\"Search with filters\",\"universality\":\"high\"}"
        first=false
    fi
    if [[ "$has_payment" == "true" ]]; then
        [[ "$first" != "true" ]] && pattern_json+=","
        pattern_json+="{\"type\":\"payment\",\"description\":\"Payment/checkout flow\",\"universality\":\"medium\"}"
        first=false
    fi
    if [[ "$has_realtime" == "true" ]]; then
        [[ "$first" != "true" ]] && pattern_json+=","
        pattern_json+="{\"type\":\"realtime\",\"description\":\"Real-time updates via WebSocket/SSE\",\"universality\":\"medium\"}"
        first=false
    fi
    if [[ "$has_calendar" == "true" ]]; then
        [[ "$first" != "true" ]] && pattern_json+=","
        pattern_json+="{\"type\":\"calendar\",\"description\":\"Calendar/scheduling system\",\"universality\":\"medium\"}"
        first=false
    fi
    if [[ "$has_audit" == "true" ]]; then
        [[ "$first" != "true" ]] && pattern_json+=","
        pattern_json+="{\"type\":\"audit_logging\",\"description\":\"Audit trail/change tracking\",\"universality\":\"high\"}"
        first=false
    fi
    if [[ "$has_workflow" == "true" ]]; then
        [[ "$first" != "true" ]] && pattern_json+=","
        pattern_json+="{\"type\":\"workflow\",\"description\":\"Status-based workflow/state machine\",\"universality\":\"high\"}"
        first=false
    fi
    if [[ "$has_file_upload" == "true" ]]; then
        [[ "$first" != "true" ]] && pattern_json+=","
        pattern_json+="{\"type\":\"file_upload\",\"description\":\"File upload/attachment handling\",\"universality\":\"medium\"}"
        first=false
    fi
    if [[ "$has_dashboard" == "true" ]]; then
        [[ "$first" != "true" ]] && pattern_json+=","
        pattern_json+="{\"type\":\"dashboard\",\"description\":\"KPI dashboard/analytics\",\"universality\":\"medium\"}"
        first=false
    fi
    if [[ "$has_notification" == "true" ]]; then
        [[ "$first" != "true" ]] && pattern_json+=","
        pattern_json+="{\"type\":\"notification\",\"description\":\"Notification system\",\"universality\":\"high\"}"
        first=false
    fi
    if [[ "$has_import_export" == "true" ]]; then
        [[ "$first" != "true" ]] && pattern_json+=","
        pattern_json+="{\"type\":\"import_export\",\"description\":\"Bulk import/export (CSV/Excel)\",\"universality\":\"medium\"}"
        first=false
    fi
    if [[ "$has_role_access" == "true" ]]; then
        [[ "$first" != "true" ]] && pattern_json+=","
        pattern_json+="{\"type\":\"role_access\",\"description\":\"Role-based access control\",\"universality\":\"high\"}"
        first=false
    fi

    pattern_json+="]}"

    echo "$pattern_json"
    return 0
}

# =============================================================================
# Internal: Check if domain JSON contains pattern indicators
# =============================================================================
_cdi_domain_has_pattern() {
    local file="$1"
    shift
    local keyword
    for keyword in "$@"; do
        if grep -qi "$keyword" "$file" 2>/dev/null; then
            return 0
        fi
    done
    return 1
}

# =============================================================================
# Internal: Locate domain JSON file
# =============================================================================
_cdi_find_domain_file() {
    local domain="$1"
    local base_dir="${SCRIPT_DIR:-$HOME/.soloptilink}"

    # Check direct path first
    if [[ -f "${base_dir}/domains/${domain}.json" ]]; then
        echo "${base_dir}/domains/${domain}.json"
        return 0
    fi
    # Check parent (some domains are at root level)
    if [[ -f "${base_dir}/${domain}.json" ]]; then
        echo "${base_dir}/${domain}.json"
        return 0
    fi
    # Check with the domains directory structure
    if [[ -f "${CDI_DOMAIN_DIR}/${domain}.json" ]]; then
        echo "${CDI_DOMAIN_DIR}/${domain}.json"
        return 0
    fi
    # Fallback: parent of domains dir
    if [[ -f "${CDI_DOMAIN_DIR}/../${domain}.json" ]]; then
        echo "${CDI_DOMAIN_DIR}/../${domain}.json"
        return 0
    fi
    return 1
}

# =============================================================================
# cdi_find_cross_applicable_patterns - ドメイン間パターン適用検出
# =============================================================================
# Usage: cdi_find_cross_applicable_patterns <source_domain> <target_domain>
# Finds patterns from source that could benefit target
# =============================================================================
cdi_find_cross_applicable_patterns() {
    local source="${1:?Usage: cdi_find_cross_applicable_patterns <source> <target>}"
    local target="${2:?Usage: cdi_find_cross_applicable_patterns <source> <target>}"

    log_info "CDI: Finding cross-applicable patterns: ${source} -> ${target}"

    # Get patterns for both domains
    local source_patterns target_patterns
    source_patterns=$(cdi_analyze_domain_patterns "$source" 2>/dev/null)
    target_patterns=$(cdi_analyze_domain_patterns "$target" 2>/dev/null)

    if [[ -z "$source_patterns" || -z "$target_patterns" ]]; then
        log_error "CDI: Could not analyze one or both domains"
        echo '{"error":"analysis_failed","source":"'"$source"'","target":"'"$target"'"}'
        return 1
    fi

    local results="[]"
    local match_count=0

    # Check direct cross-map entries
    local map_key
    for map_key in "${!CDI_CROSS_MAP[@]}"; do
        if [[ "$map_key" == "${source}:"*"->${target}" ]]; then
            local adaptation="${CDI_CROSS_MAP[$map_key]}"
            local pattern_type
            pattern_type=$(echo "$map_key" | sed "s/${source}:\(.*\)->${target}/\1/")
            if [[ "$match_count" -eq 0 ]]; then
                results="[{\"source\":\"${source}\",\"target\":\"${target}\",\"pattern\":\"${pattern_type}\",\"adaptation\":\"${adaptation}\",\"confidence\":\"high\",\"source\":\"cross_map\"}"
            else
                results="${results},{\"source_domain\":\"${source}\",\"target_domain\":\"${target}\",\"pattern\":\"${pattern_type}\",\"adaptation\":\"${adaptation}\",\"confidence\":\"high\",\"source\":\"cross_map\"}"
            fi
            match_count=$((match_count + 1))
        fi
    done

    # Infer additional cross-applicable patterns by comparing capabilities
    # Source has pattern that target lacks -> suggest adoption
    local ptypes="auth search pagination file_upload realtime audit_logging payment calendar dashboard notification workflow import_export role_access"
    local ptype

    for ptype in $ptypes; do
        local source_has target_has
        source_has=$(_cdi_json_get_bool "$source_patterns" "$ptype")
        target_has=$(_cdi_json_get_bool "$target_patterns" "$ptype")

        if [[ "$source_has" == "true" && "$target_has" == "false" ]]; then
            local suggestion
            suggestion=$(_cdi_generate_adaptation_note "$source" "$target" "$ptype")
            if [[ "$match_count" -eq 0 ]]; then
                results="[{\"source_domain\":\"${source}\",\"target_domain\":\"${target}\",\"pattern\":\"${ptype}\",\"adaptation\":\"${suggestion}\",\"confidence\":\"medium\",\"source\":\"gap_analysis\"}"
            else
                results="${results},{\"source_domain\":\"${source}\",\"target_domain\":\"${target}\",\"pattern\":\"${ptype}\",\"adaptation\":\"${suggestion}\",\"confidence\":\"medium\",\"source\":\"gap_analysis\"}"
            fi
            match_count=$((match_count + 1))
        fi
    done

    # Close JSON array
    if [[ "$match_count" -gt 0 ]]; then
        results="${results}]"
    fi

    CDI_CROSS_MATCH_COUNT=$((CDI_CROSS_MATCH_COUNT + match_count))

    log_info "CDI: Found ${match_count} cross-applicable patterns (${source} -> ${target})"
    echo "{\"source\":\"${source}\",\"target\":\"${target}\",\"match_count\":${match_count},\"patterns\":${results}}"
    return 0
}

# =============================================================================
# Internal: Extract boolean from pattern JSON (lightweight parser)
# =============================================================================
_cdi_json_get_bool() {
    local json="$1"
    local key="$2"
    if echo "$json" | grep -q "\"${key}\":true"; then
        echo "true"
    else
        echo "false"
    fi
}

# =============================================================================
# Internal: Generate adaptation note for a pattern transfer
# =============================================================================
_cdi_generate_adaptation_note() {
    local source="$1" target="$2" ptype="$3"

    case "$ptype" in
        auth)
            echo "${source} has auth patterns. Add User model + NextAuth/session management to ${target}."
            ;;
        search)
            echo "${source} has search. Add search_fields to ${target} models and implement debounced search API."
            ;;
        pagination)
            echo "${source} uses pagination. Add cursor/offset pagination to ${target} list endpoints for scalability."
            ;;
        file_upload)
            echo "${source} handles file uploads. Add file upload with validation (size/type) and cloud storage to ${target}."
            ;;
        realtime)
            echo "${source} has real-time features. Add WebSocket/SSE for live updates in ${target} where users wait for changes."
            ;;
        audit_logging)
            echo "${source} has audit logging. Add immutable audit trail to ${target} for compliance and debugging."
            ;;
        payment)
            echo "${source} has payment flows. Add Stripe/payment integration to ${target} if monetization is needed."
            ;;
        calendar)
            echo "${source} has scheduling. Add calendar/time-slot management to ${target} for time-based features."
            ;;
        dashboard)
            echo "${source} has KPI dashboards. Add analytics charts to ${target} admin panel for data visibility."
            ;;
        notification)
            echo "${source} has notifications. Add email/push notification system to ${target} for user engagement."
            ;;
        workflow)
            echo "${source} has workflow/state machine. Add status transitions with validation to ${target} entities."
            ;;
        import_export)
            echo "${source} has import/export. Add CSV/Excel bulk operations to ${target} for admin efficiency."
            ;;
        role_access)
            echo "${source} has RBAC. Add role-based access control to ${target} for multi-user security."
            ;;
        *)
            echo "Transfer ${ptype} pattern from ${source} to ${target} with domain-specific adaptations."
            ;;
    esac
}

# =============================================================================
# cdi_build_universal_quality_rules - 全ドメイン共通品質ルール構築
# =============================================================================
# Returns a JSON array of universal quality rules that apply to every domain
# =============================================================================
cdi_build_universal_quality_rules() {
    log_info "CDI: Building universal quality rules"

    CDI_UNIVERSAL_RULE_COUNT=0
    local rules=""

    # --- 1. Input validation on all forms ---
    _cdi_append_rule rules "input_validation" "critical" \
        "All form inputs must have validation" \
        "Zod schema on server, client-side validation with error messages. Required fields, type checks, length limits, format validation (email/phone/url)." \
        "No unvalidated user input reaches the database"
    CDI_UNIVERSAL_RULE_COUNT=$((CDI_UNIVERSAL_RULE_COUNT + 1))

    # --- 2. Error boundaries on all pages ---
    _cdi_append_rule rules "error_boundary" "critical" \
        "All pages must have error boundaries" \
        "React ErrorBoundary or Next.js error.tsx on every route segment. Graceful fallback UI, error reporting, retry capability." \
        "No white screen of death on any page"
    CDI_UNIVERSAL_RULE_COUNT=$((CDI_UNIVERSAL_RULE_COUNT + 1))

    # --- 3. Loading states on all async operations ---
    _cdi_append_rule rules "loading_states" "critical" \
        "All async operations must show loading state" \
        "Skeleton loaders for initial page load. Spinner/disabled state on form submissions. Optimistic UI where appropriate." \
        "No frozen UI during network requests"
    CDI_UNIVERSAL_RULE_COUNT=$((CDI_UNIVERSAL_RULE_COUNT + 1))

    # --- 4. Pagination on all list endpoints ---
    _cdi_append_rule rules "pagination" "high" \
        "All list endpoints must support pagination" \
        "Cursor-based or offset pagination. Default limit 20, max 100. Return total count. Frontend pagination controls with page size selector." \
        "No endpoint returns unbounded result sets"
    CDI_UNIVERSAL_RULE_COUNT=$((CDI_UNIVERSAL_RULE_COUNT + 1))

    # --- 5. Search/filter on all list views ---
    _cdi_append_rule rules "search_filter" "high" \
        "All list views must have search and filter capabilities" \
        "Debounced text search (300ms). Filter by status, date range, category. URL-persisted filter state. Clear filters button." \
        "Users can find any record without scrolling through pages"
    CDI_UNIVERSAL_RULE_COUNT=$((CDI_UNIVERSAL_RULE_COUNT + 1))

    # --- 6. Audit logging on all write operations ---
    _cdi_append_rule rules "audit_logging" "high" \
        "All write operations must be audit logged" \
        "Log: timestamp, userId, action (CREATE/UPDATE/DELETE), entity type, entity id, changes (before/after for updates). Immutable append-only log." \
        "Every data mutation is traceable"
    CDI_UNIVERSAL_RULE_COUNT=$((CDI_UNIVERSAL_RULE_COUNT + 1))

    # --- 7. Rate limiting on all public endpoints ---
    _cdi_append_rule rules "rate_limiting" "high" \
        "All public endpoints must have rate limiting" \
        "IP-based rate limiting. 100 req/min for reads, 20 req/min for writes. 429 response with Retry-After header. Stricter limits on auth endpoints (5/min)." \
        "No endpoint is vulnerable to brute force or DoS"
    CDI_UNIVERSAL_RULE_COUNT=$((CDI_UNIVERSAL_RULE_COUNT + 1))

    # --- 8. CSRF protection on all mutations ---
    _cdi_append_rule rules "csrf_protection" "critical" \
        "All mutation endpoints must have CSRF protection" \
        "SameSite cookie attribute. CSRF token on forms. Verify Origin/Referer headers. Double-submit cookie pattern for API calls." \
        "No cross-site request forgery possible"
    CDI_UNIVERSAL_RULE_COUNT=$((CDI_UNIVERSAL_RULE_COUNT + 1))

    # --- 9. Empty state on all list views ---
    _cdi_append_rule rules "empty_state" "medium" \
        "All list views must show meaningful empty states" \
        "Illustration + descriptive text + primary CTA button. Different empty states for no-data vs no-results. Guide users to create first record." \
        "No confusing blank pages"
    CDI_UNIVERSAL_RULE_COUNT=$((CDI_UNIVERSAL_RULE_COUNT + 1))

    # --- 10. Responsive design on all pages ---
    _cdi_append_rule rules "responsive_design" "high" \
        "All pages must be fully responsive" \
        "Mobile-first approach. Breakpoints at 640/768/1024/1280px. Touch-friendly tap targets (min 44px). Collapsible sidebar on mobile." \
        "Usable on any device from phone to 4K monitor"
    CDI_UNIVERSAL_RULE_COUNT=$((CDI_UNIVERSAL_RULE_COUNT + 1))

    # --- 11. Accessibility (ARIA) ---
    _cdi_append_rule rules "accessibility" "high" \
        "All interactive elements must be accessible" \
        "ARIA labels on buttons/icons. Keyboard navigation (Tab/Enter/Escape). Focus management on modals. Color contrast ratio >= 4.5:1. Screen reader support." \
        "WCAG 2.1 AA compliance on all pages"
    CDI_UNIVERSAL_RULE_COUNT=$((CDI_UNIVERSAL_RULE_COUNT + 1))

    # --- 12. Confirmation on destructive actions ---
    _cdi_append_rule rules "destructive_confirm" "critical" \
        "All destructive actions must require confirmation" \
        "Modal confirmation dialog (not window.confirm). Show what will be affected. Require explicit action (type name to confirm for bulk deletes). Undo where possible." \
        "No accidental data loss"
    CDI_UNIVERSAL_RULE_COUNT=$((CDI_UNIVERSAL_RULE_COUNT + 1))

    # --- 13. Toast notifications for feedback ---
    _cdi_append_rule rules "toast_feedback" "medium" \
        "All user actions must provide feedback via toast notifications" \
        "Success toast (green) on create/update/delete. Error toast (red) with actionable message. Auto-dismiss after 5s. Stack multiple toasts." \
        "Users always know the result of their action"
    CDI_UNIVERSAL_RULE_COUNT=$((CDI_UNIVERSAL_RULE_COUNT + 1))

    # --- 14. Proper HTTP status codes ---
    _cdi_append_rule rules "http_status_codes" "high" \
        "All API responses must use correct HTTP status codes" \
        "200 OK, 201 Created, 204 No Content, 400 Bad Request, 401 Unauthorized, 403 Forbidden, 404 Not Found, 409 Conflict, 422 Validation Error, 429 Too Many Requests, 500 Server Error." \
        "Consistent, predictable API behavior"
    CDI_UNIVERSAL_RULE_COUNT=$((CDI_UNIVERSAL_RULE_COUNT + 1))

    # --- 15. SQL injection prevention ---
    _cdi_append_rule rules "sql_injection_prevention" "critical" \
        "All database queries must use parameterized queries" \
        "Use Prisma ORM (inherently safe). Never concatenate user input into raw SQL. If raw SQL needed, use parameterized queries exclusively." \
        "Zero SQL injection surface area"
    CDI_UNIVERSAL_RULE_COUNT=$((CDI_UNIVERSAL_RULE_COUNT + 1))

    # --- 16. XSS prevention ---
    _cdi_append_rule rules "xss_prevention" "critical" \
        "All user-generated content must be sanitized on output" \
        "React auto-escapes JSX. Never use dangerouslySetInnerHTML without DOMPurify. CSP headers. HttpOnly cookies." \
        "No stored or reflected XSS possible"
    CDI_UNIVERSAL_RULE_COUNT=$((CDI_UNIVERSAL_RULE_COUNT + 1))

    log_info "CDI: Built ${CDI_UNIVERSAL_RULE_COUNT} universal quality rules"
    echo "{\"rule_count\":${CDI_UNIVERSAL_RULE_COUNT},\"rules\":[${rules}]}"
    return 0
}

# =============================================================================
# Internal: Append a rule to the rules string
# =============================================================================
_cdi_append_rule() {
    local -n _rules_ref=$1
    local id="$2" severity="$3" title="$4" implementation="$5" acceptance="$6"

    local entry="{\"id\":\"${id}\",\"severity\":\"${severity}\",\"title\":\"${title}\",\"implementation\":\"${implementation}\",\"acceptance_criteria\":\"${acceptance}\"}"
    if [[ -n "$_rules_ref" ]]; then
        _rules_ref="${_rules_ref},${entry}"
    else
        _rules_ref="${entry}"
    fi
}

# =============================================================================
# cdi_inject_learned_patterns - プロンプトへの学習パターン注入
# =============================================================================
# Usage: cdi_inject_learned_patterns <prompt> <domain> <phase>
# Enhances prompt with universal rules + cross-domain patterns + history
# =============================================================================
cdi_inject_learned_patterns() {
    local prompt="${1:?Usage: cdi_inject_learned_patterns <prompt> <domain> <phase>}"
    local domain="${2:?}"
    local phase="${3:-implementation}"

    log_info "CDI: Injecting learned patterns for domain='${domain}' phase='${phase}'"

    local enhanced_prompt="$prompt"
    local injection_sections=""

    # --- Section 1: Universal quality rules relevant to this phase ---
    local phase_rules=""
    case "$phase" in
        design|planning)
            phase_rules="pagination,search_filter,responsive_design,accessibility,error_boundary,empty_state"
            ;;
        implementation|coding)
            phase_rules="input_validation,error_boundary,loading_states,pagination,search_filter,audit_logging,csrf_protection,sql_injection_prevention,xss_prevention,destructive_confirm,toast_feedback,http_status_codes"
            ;;
        review|testing)
            phase_rules="input_validation,error_boundary,loading_states,rate_limiting,csrf_protection,sql_injection_prevention,xss_prevention,accessibility"
            ;;
        deployment)
            phase_rules="rate_limiting,csrf_protection,sql_injection_prevention,xss_prevention"
            ;;
        *)
            phase_rules="input_validation,error_boundary,loading_states,pagination"
            ;;
    esac

    injection_sections+="\n\n--- UNIVERSAL QUALITY RULES (phase: ${phase}) ---\n"
    injection_sections+="Apply these rules to ALL generated code:\n"

    local rule_id
    local IFS=','
    for rule_id in $phase_rules; do
        local rule_text
        rule_text=$(_cdi_get_rule_text "$rule_id")
        if [[ -n "$rule_text" ]]; then
            injection_sections+="- ${rule_text}\n"
        fi
    done
    unset IFS

    # --- Section 2: Cross-domain patterns applicable to this domain ---
    local cross_patterns=""
    local other_domain other_file
    local base_dir="${SCRIPT_DIR:-$HOME/.soloptilink}"

    injection_sections+="\n--- CROSS-DOMAIN PATTERNS for ${domain} ---\n"
    injection_sections+="Patterns learned from other domains that should be applied:\n"

    local cross_count=0
    for map_key in "${!CDI_CROSS_MAP[@]}"; do
        if [[ "$map_key" == *"->${domain}" ]]; then
            local adaptation="${CDI_CROSS_MAP[$map_key]}"
            injection_sections+="- ${adaptation}\n"
            cross_count=$((cross_count + 1))
        fi
    done

    if [[ "$cross_count" -eq 0 ]]; then
        injection_sections+="- No specific cross-domain patterns found. Apply universal patterns.\n"
    fi

    # --- Section 3: Historical success patterns from past sessions ---
    injection_sections+="\n--- HISTORICAL PATTERNS for ${domain} ---\n"

    if [[ -f "$CDI_LEARNING_DIR/quality/scores.jsonl" ]]; then
        local high_score_sessions
        high_score_sessions=$(grep "\"domain\":\"${domain}\"" "$CDI_LEARNING_DIR/quality/scores.jsonl" 2>/dev/null \
            | grep -o '"score":[0-9]*' | sed 's/"score"://' | sort -rn | head -3)

        if [[ -n "$high_score_sessions" ]]; then
            local avg_score=0
            local count=0
            local s
            for s in $high_score_sessions; do
                avg_score=$((avg_score + s))
                count=$((count + 1))
            done
            if [[ "$count" -gt 0 ]]; then
                avg_score=$((avg_score / count))
                injection_sections+="- Historical avg quality score for ${domain}: ${avg_score}/100\n"
            fi
        else
            injection_sections+="- No historical data for ${domain} yet. First session - apply all universal rules.\n"
        fi
    fi

    # Historical error patterns to avoid
    if [[ -f "$CDI_LEARNING_DIR/errors/patterns.jsonl" ]]; then
        local domain_errors
        domain_errors=$(grep "\"domain\":\"${domain}\"" "$CDI_LEARNING_DIR/errors/patterns.jsonl" 2>/dev/null | head -5)
        if [[ -n "$domain_errors" ]]; then
            injection_sections+="- Known error patterns to avoid:\n"
            while IFS= read -r err_line; do
                local err_type err_msg
                err_type=$(echo "$err_line" | grep -o '"error_type":"[^"]*"' | sed 's/"error_type":"//;s/"//')
                err_msg=$(echo "$err_line" | grep -o '"last_message":"[^"]*"' | sed 's/"last_message":"//;s/"//')
                if [[ -n "$err_type" ]]; then
                    injection_sections+="  - Avoid: ${err_type} - ${err_msg}\n"
                fi
            done <<< "$domain_errors"
        fi
    fi

    # Historical solutions that worked
    if [[ -f "$CDI_LEARNING_DIR/solutions/index.jsonl" ]]; then
        local domain_solutions
        domain_solutions=$(grep "\"domain\":\"${domain}\"" "$CDI_LEARNING_DIR/solutions/index.jsonl" 2>/dev/null | head -3)
        if [[ -n "$domain_solutions" ]]; then
            injection_sections+="- Proven solutions for ${domain}:\n"
            while IFS= read -r sol_line; do
                local fix_desc
                fix_desc=$(echo "$sol_line" | grep -o '"fix_description":"[^"]*"' | sed 's/"fix_description":"//;s/"//')
                if [[ -n "$fix_desc" ]]; then
                    injection_sections+="  - Applied: ${fix_desc}\n"
                fi
            done <<< "$domain_solutions"
        fi
    fi

    injection_sections+="\n--- END CROSS-DOMAIN INTELLIGENCE ---"

    # Append to prompt
    enhanced_prompt="${prompt}${injection_sections}"

    echo "$enhanced_prompt"
    log_info "CDI: Injected ${CDI_UNIVERSAL_RULE_COUNT} universal rules + ${cross_count} cross-domain patterns"
    return 0
}

# =============================================================================
# Internal: Get human-readable rule text by ID
# =============================================================================
_cdi_get_rule_text() {
    local rule_id="$1"
    case "$rule_id" in
        input_validation)       echo "[CRITICAL] Validate all form inputs with Zod schemas. Required fields, type/format/length checks." ;;
        error_boundary)         echo "[CRITICAL] Add error boundaries (error.tsx) on every route segment. Graceful fallback UI." ;;
        loading_states)         echo "[CRITICAL] Show skeleton/spinner on all async operations. No frozen UI." ;;
        pagination)             echo "[HIGH] Paginate all list endpoints (default 20, max 100). Return total count." ;;
        search_filter)          echo "[HIGH] Add debounced search + filters on all list views. URL-persisted state." ;;
        audit_logging)          echo "[HIGH] Audit log all writes: timestamp, userId, action, entity, changes." ;;
        rate_limiting)          echo "[HIGH] Rate limit all public endpoints: 100/min reads, 20/min writes, 5/min auth." ;;
        csrf_protection)        echo "[CRITICAL] CSRF protection on all mutations: SameSite cookies + CSRF tokens." ;;
        empty_state)            echo "[MEDIUM] Show meaningful empty states with illustration + CTA on all list views." ;;
        responsive_design)      echo "[HIGH] Mobile-first responsive design. Breakpoints 640/768/1024/1280px." ;;
        accessibility)          echo "[HIGH] ARIA labels, keyboard nav, focus management, contrast ratio >= 4.5:1." ;;
        destructive_confirm)    echo "[CRITICAL] Modal confirmation on all destructive actions. Show affected items." ;;
        toast_feedback)         echo "[MEDIUM] Toast notifications for all user actions. Success=green, Error=red." ;;
        http_status_codes)      echo "[HIGH] Use correct HTTP status codes: 200/201/204/400/401/403/404/409/422/429/500." ;;
        sql_injection_prevention) echo "[CRITICAL] Parameterized queries only. Never concatenate user input into SQL." ;;
        xss_prevention)         echo "[CRITICAL] Sanitize all user content. No raw dangerouslySetInnerHTML. CSP headers." ;;
        *)                      echo "" ;;
    esac
}

# =============================================================================
# cdi_analyze_session_outcomes - セッション結果分析・学習
# =============================================================================
# Usage: cdi_analyze_session_outcomes <session_dir>
# Reads session results, extracts patterns and anti-patterns, persists learning
# =============================================================================
cdi_analyze_session_outcomes() {
    local session_dir="${1:?Usage: cdi_analyze_session_outcomes <session_dir>}"

    if [[ ! -d "$session_dir" ]]; then
        log_error "CDI: Session directory not found: ${session_dir}"
        return 1
    fi

    log_info "CDI: Analyzing session outcomes from ${session_dir}"

    local session_id quality_score error_count fix_count domain
    local timestamp
    timestamp=$(date -u '+%Y-%m-%dT%H:%M:%SZ')

    # Try to read session metadata
    local meta_file=""
    for candidate in "${session_dir}/meta.json" "${session_dir}/session.json" "${session_dir}/result.json"; do
        if [[ -f "$candidate" ]]; then
            meta_file="$candidate"
            break
        fi
    done

    # Extract session info from metadata or infer from files
    if [[ -n "$meta_file" ]] && command -v jq &>/dev/null; then
        session_id=$(jq -r '.session_id // .id // "unknown"' "$meta_file" 2>/dev/null)
        domain=$(jq -r '.domain // "unknown"' "$meta_file" 2>/dev/null)
        quality_score=$(jq -r '.quality_score // .score // 0' "$meta_file" 2>/dev/null)
    else
        session_id=$(basename "$session_dir")
        domain="unknown"
        quality_score=0
    fi

    # Count errors from session logs
    error_count=0
    local err_file
    for err_file in "${session_dir}"/*error* "${session_dir}"/*fail* "${session_dir}"/*.err; do
        if [[ -f "$err_file" ]]; then
            local count
            count=$(wc -l < "$err_file" 2>/dev/null | tr -d ' ')
            error_count=$((error_count + count))
        fi
    done

    # Count fix cycles from session logs
    fix_count=0
    local log_file
    for log_file in "${session_dir}"/*.log "${session_dir}"/*output*; do
        if [[ -f "$log_file" ]]; then
            local fixes
            fixes=$(grep -ci "fix\|repair\|patch\|retry\|corrected" "$log_file" 2>/dev/null || echo "0")
            fix_count=$((fix_count + fixes))
        fi
    done

    # Determine outcome
    local outcome="unknown"
    if [[ "$quality_score" -ge 90 ]]; then
        outcome="excellent"
    elif [[ "$quality_score" -ge 70 ]]; then
        outcome="good"
    elif [[ "$quality_score" -ge 50 ]]; then
        outcome="acceptable"
    elif [[ "$quality_score" -gt 0 ]]; then
        outcome="poor"
    fi

    # --- Extract new patterns from successful sessions ---
    local new_patterns=0
    if [[ "$quality_score" -ge 80 ]]; then
        log_info "CDI: High-quality session - extracting success patterns"

        # Look for code patterns that produced good results
        local code_files
        code_files=$(find "$session_dir" -name "*.tsx" -o -name "*.ts" -o -name "*.jsx" -o -name "*.js" 2>/dev/null | head -20)

        for code_file in $code_files; do
            # Extract validation patterns
            if grep -q "z\.\|zod\|schema" "$code_file" 2>/dev/null; then
                _cdi_record_success_pattern "$domain" "validation" "Zod schema validation used" "$session_id"
                new_patterns=$((new_patterns + 1))
            fi
            # Extract error handling patterns
            if grep -q "ErrorBoundary\|error\.tsx\|try.*catch" "$code_file" 2>/dev/null; then
                _cdi_record_success_pattern "$domain" "error_handling" "Proper error boundaries/handling" "$session_id"
                new_patterns=$((new_patterns + 1))
            fi
            # Extract loading state patterns
            if grep -q "isLoading\|Skeleton\|Spinner\|loading" "$code_file" 2>/dev/null; then
                _cdi_record_success_pattern "$domain" "loading_state" "Loading state management" "$session_id"
                new_patterns=$((new_patterns + 1))
            fi
        done
    fi

    # --- Extract anti-patterns from failed sessions ---
    local anti_patterns=0
    if [[ "$quality_score" -lt 60 && "$quality_score" -gt 0 ]]; then
        log_warn "CDI: Low-quality session - extracting anti-patterns"

        # Scan error logs for recurring issues
        for err_file in "${session_dir}"/*error* "${session_dir}"/*.err "${session_dir}"/*.log; do
            [[ -f "$err_file" ]] || continue

            # Type errors
            if grep -qi "type.*error\|TypeScript\|TS[0-9]" "$err_file" 2>/dev/null; then
                _cdi_record_anti_pattern "$domain" "type_error" "TypeScript type errors in generated code" "$session_id"
                anti_patterns=$((anti_patterns + 1))
            fi
            # Import errors
            if grep -qi "cannot find module\|import.*error\|module not found" "$err_file" 2>/dev/null; then
                _cdi_record_anti_pattern "$domain" "import_error" "Missing or incorrect imports" "$session_id"
                anti_patterns=$((anti_patterns + 1))
            fi
            # Runtime errors
            if grep -qi "runtime.*error\|undefined is not\|null reference" "$err_file" 2>/dev/null; then
                _cdi_record_anti_pattern "$domain" "runtime_error" "Runtime null/undefined errors" "$session_id"
                anti_patterns=$((anti_patterns + 1))
            fi
        done
    fi

    # Persist quality score to learning database
    local score_entry="{\"timestamp\":\"${timestamp}\",\"session_id\":\"${session_id}\",\"domain\":\"${domain}\",\"phase\":\"analysis\",\"score\":${quality_score},\"error_count\":${error_count},\"fix_count\":${fix_count},\"outcome\":\"${outcome}\",\"new_patterns\":${new_patterns},\"anti_patterns\":${anti_patterns}}"
    echo "$score_entry" >> "$CDI_LEARNING_DIR/quality/scores.jsonl" 2>/dev/null

    # Persist session summary
    mkdir -p "$CDI_LEARNING_DIR/sessions" 2>/dev/null
    local session_summary="{\"session_id\":\"${session_id}\",\"domain\":\"${domain}\",\"timestamp\":\"${timestamp}\",\"quality_score\":${quality_score},\"error_count\":${error_count},\"fix_count\":${fix_count},\"outcome\":\"${outcome}\",\"new_patterns\":${new_patterns},\"anti_patterns\":${anti_patterns}}"
    echo "$session_summary" >> "$CDI_LEARNING_DIR/sessions/history.jsonl" 2>/dev/null

    CDI_SESSION_ANALYZED=$((CDI_SESSION_ANALYZED + 1))

    log_info "CDI: Session analysis complete - score=${quality_score}, errors=${error_count}, fixes=${fix_count}, outcome=${outcome}, +${new_patterns} patterns, +${anti_patterns} anti-patterns"
    echo "$session_summary"
    return 0
}

# =============================================================================
# Internal: Record a success pattern to learning DB
# =============================================================================
_cdi_record_success_pattern() {
    local domain="$1" ptype="$2" description="$3" session_id="$4"
    local timestamp
    timestamp=$(date -u '+%Y-%m-%dT%H:%M:%SZ')

    mkdir -p "$CDI_PATTERN_DIR" 2>/dev/null

    local entry="{\"timestamp\":\"${timestamp}\",\"domain\":\"${domain}\",\"type\":\"success\",\"pattern\":\"${ptype}\",\"description\":\"${description}\",\"session_id\":\"${session_id}\"}"
    echo "$entry" >> "$CDI_PATTERN_DIR/success_patterns.jsonl" 2>/dev/null
}

# =============================================================================
# Internal: Record an anti-pattern to learning DB
# =============================================================================
_cdi_record_anti_pattern() {
    local domain="$1" ptype="$2" description="$3" session_id="$4"
    local timestamp
    timestamp=$(date -u '+%Y-%m-%dT%H:%M:%SZ')

    mkdir -p "$CDI_PATTERN_DIR" 2>/dev/null

    local entry="{\"timestamp\":\"${timestamp}\",\"domain\":\"${domain}\",\"type\":\"anti_pattern\",\"pattern\":\"${ptype}\",\"description\":\"${description}\",\"session_id\":\"${session_id}\"}"
    echo "$entry" >> "$CDI_PATTERN_DIR/anti_patterns.jsonl" 2>/dev/null
}

# =============================================================================
# cdi_get_domain_quality_profile - ドメイン品質プロファイル取得
# =============================================================================
# Usage: cdi_get_domain_quality_profile <domain>
# Returns historical quality data, error patterns, best practices
# =============================================================================
cdi_get_domain_quality_profile() {
    local domain="${1:?Usage: cdi_get_domain_quality_profile <domain>}"

    log_info "CDI: Building quality profile for domain '${domain}'"

    local avg_score=0
    local max_score=0
    local min_score=100
    local session_count=0
    local total_errors=0
    local total_fixes=0

    # Aggregate quality scores
    if [[ -f "$CDI_LEARNING_DIR/quality/scores.jsonl" ]]; then
        local score_sum=0
        while IFS= read -r line; do
            local line_domain
            line_domain=$(echo "$line" | grep -o '"domain":"[^"]*"' | sed 's/"domain":"//;s/"//')
            [[ "$line_domain" != "$domain" ]] && continue

            local score
            score=$(echo "$line" | grep -o '"score":[0-9]*' | sed 's/"score"://')
            [[ -z "$score" || "$score" == "0" ]] && continue

            score_sum=$((score_sum + score))
            session_count=$((session_count + 1))

            [[ "$score" -gt "$max_score" ]] && max_score=$score
            [[ "$score" -lt "$min_score" ]] && min_score=$score

            # Extract error/fix counts if present
            local errs
            errs=$(echo "$line" | grep -o '"error_count":[0-9]*' | sed 's/"error_count"://')
            [[ -n "$errs" ]] && total_errors=$((total_errors + errs))

            local fixes
            fixes=$(echo "$line" | grep -o '"fix_count":[0-9]*' | sed 's/"fix_count"://')
            [[ -n "$fixes" ]] && total_fixes=$((total_fixes + fixes))
        done < "$CDI_LEARNING_DIR/quality/scores.jsonl"

        if [[ "$session_count" -gt 0 ]]; then
            avg_score=$((score_sum / session_count))
        fi
    fi

    [[ "$session_count" -eq 0 ]] && min_score=0

    # Average fix cycles
    local avg_fixes=0
    if [[ "$session_count" -gt 0 ]]; then
        avg_fixes=$((total_fixes / session_count))
    fi

    # Gather common error patterns for this domain
    local error_patterns="[]"
    if [[ -f "$CDI_LEARNING_DIR/errors/patterns.jsonl" ]]; then
        local err_entries=""
        local err_count=0
        while IFS= read -r line; do
            local line_domain
            line_domain=$(echo "$line" | grep -o '"domain":"[^"]*"' | sed 's/"domain":"//;s/"//')
            [[ "$line_domain" != "$domain" ]] && continue

            local err_type frequency
            err_type=$(echo "$line" | grep -o '"error_type":"[^"]*"' | sed 's/"error_type":"//;s/"//')
            frequency=$(echo "$line" | grep -o '"frequency":[0-9]*' | sed 's/"frequency"://')

            if [[ -n "$err_type" ]]; then
                [[ "$err_count" -gt 0 ]] && err_entries+=","
                err_entries+="{\"type\":\"${err_type}\",\"frequency\":${frequency:-1}}"
                err_count=$((err_count + 1))
            fi
        done < "$CDI_LEARNING_DIR/errors/patterns.jsonl"

        if [[ "$err_count" -gt 0 ]]; then
            error_patterns="[${err_entries}]"
        fi
    fi

    # Domain-specific best practices (derived from domain JSON features)
    local best_practices="[]"
    local domain_file
    domain_file=$(_cdi_find_domain_file "$domain")

    if [[ -n "$domain_file" && -f "$domain_file" ]]; then
        local practices=""
        local practice_count=0

        # Check for business rules
        if command -v jq &>/dev/null; then
            local rules_json
            rules_json=$(jq -r '.business_rules // [] | .[:5] | .[]' "$domain_file" 2>/dev/null)
            if [[ -n "$rules_json" ]]; then
                while IFS= read -r rule; do
                    [[ -z "$rule" ]] && continue
                    # Escape quotes for JSON safety
                    rule=$(echo "$rule" | sed 's/"/\\"/g')
                    [[ "$practice_count" -gt 0 ]] && practices+=","
                    practices+="{\"source\":\"business_rule\",\"practice\":\"${rule}\"}"
                    practice_count=$((practice_count + 1))
                done <<< "$rules_json"
            fi
        else
            # Fallback: grep for business_rules
            local rules_text
            rules_text=$(grep -A1 '"business_rules"' "$domain_file" 2>/dev/null | head -5)
            if [[ -n "$rules_text" ]]; then
                practices+="{\"source\":\"business_rule\",\"practice\":\"See domain JSON for business rules\"}"
                practice_count=1
            fi
        fi

        if [[ "$practice_count" -gt 0 ]]; then
            best_practices="[${practices}]"
        fi
    fi

    # Build profile JSON
    local profile="{\"domain\":\"${domain}\",\"session_count\":${session_count},\"quality\":{\"average\":${avg_score},\"max\":${max_score},\"min\":${min_score}},\"errors\":{\"total\":${total_errors},\"patterns\":${error_patterns}},\"fixes\":{\"total\":${total_fixes},\"average_per_session\":${avg_fixes}},\"best_practices\":${best_practices}}"

    echo "$profile"
    log_info "CDI: Quality profile for '${domain}': avg=${avg_score}, sessions=${session_count}, errors=${total_errors}"
    return 0
}

# =============================================================================
# cdi_suggest_architecture - アーキテクチャ提案
# =============================================================================
# Usage: cdi_suggest_architecture <domain> [requirements]
# Suggests file structure, tech choices, design patterns, pitfalls
# =============================================================================
cdi_suggest_architecture() {
    local domain="${1:?Usage: cdi_suggest_architecture <domain> [requirements]}"
    local requirements="${2:-}"

    log_info "CDI: Generating architecture suggestion for domain '${domain}'"

    local domain_file
    domain_file=$(_cdi_find_domain_file "$domain")

    # Extract domain characteristics
    local model_count=0
    local api_count=0
    local has_realtime=false
    local has_payment=false
    local has_file_upload=false
    local complexity="standard"

    if [[ -n "$domain_file" && -f "$domain_file" ]]; then
        if command -v jq &>/dev/null; then
            model_count=$(jq '.models // {} | length' "$domain_file" 2>/dev/null)
            api_count=$(jq '.api_endpoints // [] | length' "$domain_file" 2>/dev/null)
        else
            model_count=$(grep -c '"fields"' "$domain_file" 2>/dev/null || echo "0")
            api_count=$(grep -c '"method"' "$domain_file" 2>/dev/null || echo "0")
        fi

        _cdi_domain_has_pattern "$domain_file" "realtime" "websocket" "socket" && has_realtime=true
        _cdi_domain_has_pattern "$domain_file" "payment" "checkout" "stripe" && has_payment=true
        _cdi_domain_has_pattern "$domain_file" "upload" "attachment" "file" && has_file_upload=true
    fi

    # Determine complexity tier
    if [[ "$model_count" -ge 15 || "$api_count" -ge 40 ]]; then
        complexity="enterprise"
    elif [[ "$model_count" -ge 8 || "$api_count" -ge 20 ]]; then
        complexity="complex"
    fi

    # --- File structure suggestion ---
    local file_structure="\"file_structure\":{"
    file_structure+="\"root\":[\"app/\",\"components/\",\"lib/\",\"prisma/\",\"public/\"],"

    case "$complexity" in
        enterprise)
            file_structure+="\"app\":[\"(auth)/\",\"(dashboard)/\",\"(public)/\",\"api/\",\"layout.tsx\",\"page.tsx\"],"
            file_structure+="\"components\":[\"ui/\",\"forms/\",\"tables/\",\"charts/\",\"layouts/\",\"modals/\",\"shared/\"],"
            file_structure+="\"lib\":[\"auth.ts\",\"db.ts\",\"utils.ts\",\"validators/\",\"services/\",\"hooks/\",\"types/\"]"
            ;;
        complex)
            file_structure+="\"app\":[\"(auth)/\",\"(main)/\",\"api/\",\"layout.tsx\",\"page.tsx\"],"
            file_structure+="\"components\":[\"ui/\",\"forms/\",\"tables/\",\"layouts/\",\"shared/\"],"
            file_structure+="\"lib\":[\"auth.ts\",\"db.ts\",\"utils.ts\",\"validators.ts\",\"hooks/\",\"types.ts\"]"
            ;;
        *)
            file_structure+="\"app\":[\"(auth)/\",\"(main)/\",\"api/\",\"layout.tsx\",\"page.tsx\"],"
            file_structure+="\"components\":[\"ui/\",\"forms/\",\"shared/\"],"
            file_structure+="\"lib\":[\"auth.ts\",\"db.ts\",\"utils.ts\"]"
            ;;
    esac
    file_structure+="}"

    # --- Technology choices ---
    local tech_choices="\"technology\":{"
    tech_choices+="\"framework\":\"Next.js 14+ (App Router)\","
    tech_choices+="\"language\":\"TypeScript (strict mode)\","
    tech_choices+="\"database\":\"PostgreSQL (Neon/Supabase)\","
    tech_choices+="\"orm\":\"Prisma\","
    tech_choices+="\"auth\":\"NextAuth.js v5\","
    tech_choices+="\"ui\":\"shadcn/ui + Tailwind CSS\","
    tech_choices+="\"validation\":\"Zod\","
    tech_choices+="\"state\":\"React Server Components + client hooks\""

    if [[ "$has_realtime" == "true" ]]; then
        tech_choices+=",\"realtime\":\"Socket.io or Pusher\""
    fi
    if [[ "$has_payment" == "true" ]]; then
        tech_choices+=",\"payment\":\"Stripe SDK\""
    fi
    if [[ "$has_file_upload" == "true" ]]; then
        tech_choices+=",\"storage\":\"Cloudflare R2 or AWS S3\""
    fi
    tech_choices+="}"

    # --- Design patterns to apply ---
    local design_patterns="\"design_patterns\":["
    design_patterns+="{\"pattern\":\"Repository Pattern\",\"reason\":\"Isolate DB queries from business logic. Use Prisma service classes.\"},"
    design_patterns+="{\"pattern\":\"Server Actions\",\"reason\":\"Type-safe form submissions without API route boilerplate.\"}"

    if [[ "$complexity" == "enterprise" || "$complexity" == "complex" ]]; then
        design_patterns+=",{\"pattern\":\"Service Layer\",\"reason\":\"Complex business logic isolated in /lib/services/ for testability.\"}"
    fi
    if [[ "$has_realtime" == "true" ]]; then
        design_patterns+=",{\"pattern\":\"Observer/Pub-Sub\",\"reason\":\"Decouple event producers from consumers for real-time features.\"}"
    fi
    if [[ "$has_payment" == "true" ]]; then
        design_patterns+=",{\"pattern\":\"Webhook Handler\",\"reason\":\"Idempotent webhook processing for payment status updates.\"}"
    fi

    design_patterns+="]"

    # --- Pitfalls to avoid (from cross-domain learning) ---
    local pitfalls="\"pitfalls\":["
    pitfalls+="{\"issue\":\"N+1 queries\",\"prevention\":\"Always use Prisma include/select for relations. Never query in loops.\"},"
    pitfalls+="{\"issue\":\"Missing error handling\",\"prevention\":\"Add error.tsx to every route segment. Wrap async calls in try/catch.\"},"
    pitfalls+="{\"issue\":\"Unbounded queries\",\"prevention\":\"Always add take/skip to findMany. Never return entire tables.\"},"
    pitfalls+="{\"issue\":\"Client-side secrets\",\"prevention\":\"Never expose API keys in client components. Use server actions or API routes.\"}"

    # Add domain-specific pitfalls from error history
    if [[ -f "$CDI_LEARNING_DIR/errors/patterns.jsonl" ]]; then
        local domain_err
        domain_err=$(grep "\"domain\":\"${domain}\"" "$CDI_LEARNING_DIR/errors/patterns.jsonl" 2>/dev/null | head -3)
        if [[ -n "$domain_err" ]]; then
            while IFS= read -r err_line; do
                local err_type err_msg
                err_type=$(echo "$err_line" | grep -o '"error_type":"[^"]*"' | sed 's/"error_type":"//;s/"//')
                err_msg=$(echo "$err_line" | grep -o '"last_message":"[^"]*"' | sed 's/"last_message":"//;s/"//')
                [[ -z "$err_type" ]] && continue
                pitfalls+=",{\"issue\":\"${err_type} (historical)\",\"prevention\":\"Previously encountered: ${err_msg}\"}"
            done <<< "$domain_err"
        fi
    fi

    pitfalls+="]"

    # --- Past session insights ---
    local past_insights="\"past_sessions\":{"
    local profile
    profile=$(cdi_get_domain_quality_profile "$domain" 2>/dev/null)
    local past_avg
    past_avg=$(echo "$profile" | grep -o '"average":[0-9]*' | sed 's/"average"://')
    local past_count
    past_count=$(echo "$profile" | grep -o '"session_count":[0-9]*' | sed 's/"session_count"://')

    past_insights+="\"session_count\":${past_count:-0},"
    past_insights+="\"avg_quality\":${past_avg:-0}"
    past_insights+="}"

    # Assemble full suggestion
    local suggestion="{"
    suggestion+="\"domain\":\"${domain}\","
    suggestion+="\"complexity\":\"${complexity}\","
    suggestion+="\"model_count\":${model_count},"
    suggestion+="\"api_count\":${api_count},"
    suggestion+="${file_structure},"
    suggestion+="${tech_choices},"
    suggestion+="${design_patterns},"
    suggestion+="${pitfalls},"
    suggestion+="${past_insights}"
    suggestion+="}"

    echo "$suggestion"
    log_info "CDI: Architecture suggestion generated - complexity=${complexity}, models=${model_count}, APIs=${api_count}"
    return 0
}

# =============================================================================
# cdi_build_pattern_library - パターンライブラリ構築・更新
# =============================================================================
# Scans all domain JSONs, extracts patterns, classifies, scores universality
# =============================================================================
cdi_build_pattern_library() {
    log_info "CDI: Building/updating pattern library"

    mkdir -p "$CDI_PATTERN_DIR" 2>/dev/null

    local base_dir="${SCRIPT_DIR:-$HOME/.soloptilink}"
    local total_domains=0
    local total_patterns=0

    # Pattern frequency counters (associative array)
    declare -A pattern_freq
    declare -A pattern_domains

    local ptype
    for ptype in auth crud search pagination file_upload realtime audit_logging payment calendar dashboard notification workflow import_export role_access; do
        pattern_freq[$ptype]=0
        pattern_domains[$ptype]=""
    done

    # Scan all domain JSON files
    local domain_file domain_name
    for domain_file in "$base_dir"/*.json "$base_dir"/domains/*.json; do
        [[ -f "$domain_file" ]] || continue

        domain_name=$(basename "$domain_file" .json)
        [[ "$domain_name" == _* ]] && continue

        total_domains=$((total_domains + 1))

        # Detect patterns in each domain
        if _cdi_domain_has_pattern "$domain_file" "User" "auth" "login" "password" "token"; then
            pattern_freq[auth]=$((${pattern_freq[auth]} + 1))
            pattern_domains[auth]+="${domain_name},"
        fi

        pattern_freq[crud]=$((${pattern_freq[crud]} + 1))
        pattern_domains[crud]+="${domain_name},"

        if _cdi_domain_has_pattern "$domain_file" "search" "filter" "search_fields"; then
            pattern_freq[search]=$((${pattern_freq[search]} + 1))
            pattern_domains[search]+="${domain_name},"
        fi

        if _cdi_domain_has_pattern "$domain_file" "pagination" "page" "limit" "cursor"; then
            pattern_freq[pagination]=$((${pattern_freq[pagination]} + 1))
            pattern_domains[pagination]+="${domain_name},"
        fi

        if _cdi_domain_has_pattern "$domain_file" "upload" "attachment" "file" "imageUrl"; then
            pattern_freq[file_upload]=$((${pattern_freq[file_upload]} + 1))
            pattern_domains[file_upload]+="${domain_name},"
        fi

        if _cdi_domain_has_pattern "$domain_file" "realtime" "websocket" "socket" "live"; then
            pattern_freq[realtime]=$((${pattern_freq[realtime]} + 1))
            pattern_domains[realtime]+="${domain_name},"
        fi

        if _cdi_domain_has_pattern "$domain_file" "audit" "log" "history" "changelog"; then
            pattern_freq[audit_logging]=$((${pattern_freq[audit_logging]} + 1))
            pattern_domains[audit_logging]+="${domain_name},"
        fi

        if _cdi_domain_has_pattern "$domain_file" "payment" "checkout" "billing" "stripe"; then
            pattern_freq[payment]=$((${pattern_freq[payment]} + 1))
            pattern_domains[payment]+="${domain_name},"
        fi

        if _cdi_domain_has_pattern "$domain_file" "calendar" "schedule" "appointment" "booking"; then
            pattern_freq[calendar]=$((${pattern_freq[calendar]} + 1))
            pattern_domains[calendar]+="${domain_name},"
        fi

        if _cdi_domain_has_pattern "$domain_file" "dashboard" "kpi" "metrics" "analytics"; then
            pattern_freq[dashboard]=$((${pattern_freq[dashboard]} + 1))
            pattern_domains[dashboard]+="${domain_name},"
        fi

        if _cdi_domain_has_pattern "$domain_file" "notification" "notify" "alert" "email"; then
            pattern_freq[notification]=$((${pattern_freq[notification]} + 1))
            pattern_domains[notification]+="${domain_name},"
        fi

        if _cdi_domain_has_pattern "$domain_file" "workflow" "status" "transition" "approval"; then
            pattern_freq[workflow]=$((${pattern_freq[workflow]} + 1))
            pattern_domains[workflow]+="${domain_name},"
        fi

        if _cdi_domain_has_pattern "$domain_file" "import" "export" "csv" "excel" "bulk"; then
            pattern_freq[import_export]=$((${pattern_freq[import_export]} + 1))
            pattern_domains[import_export]+="${domain_name},"
        fi

        if _cdi_domain_has_pattern "$domain_file" "role" "permission" "admin" "ADMIN"; then
            pattern_freq[role_access]=$((${pattern_freq[role_access]} + 1))
            pattern_domains[role_access]+="${domain_name},"
        fi
    done

    # Build pattern library JSON
    local library_entries=""
    local library_count=0

    for ptype in auth crud search pagination file_upload realtime audit_logging payment calendar dashboard notification workflow import_export role_access; do
        local freq=${pattern_freq[$ptype]:-0}
        local domains_list="${pattern_domains[$ptype]}"
        domains_list="${domains_list%,}"  # Remove trailing comma

        # Score universality: percentage of domains that use this pattern
        local universality_score=0
        if [[ "$total_domains" -gt 0 ]]; then
            universality_score=$((freq * 100 / total_domains))
        fi

        local universality_tier="low"
        if [[ "$universality_score" -ge 70 ]]; then
            universality_tier="universal"
        elif [[ "$universality_score" -ge 40 ]]; then
            universality_tier="high"
        elif [[ "$universality_score" -ge 20 ]]; then
            universality_tier="medium"
        fi

        [[ "$library_count" -gt 0 ]] && library_entries+=","
        library_entries+="{\"type\":\"${ptype}\",\"frequency\":${freq},\"domain_count\":${total_domains},\"universality_score\":${universality_score},\"universality_tier\":\"${universality_tier}\",\"domains\":\"${domains_list}\"}"
        library_count=$((library_count + 1))
        total_patterns=$((total_patterns + freq))
    done

    # Persist pattern library
    local timestamp
    timestamp=$(date -u '+%Y-%m-%dT%H:%M:%SZ')
    local library_json="{\"timestamp\":\"${timestamp}\",\"version\":\"${CDI_VERSION}\",\"total_domains\":${total_domains},\"total_pattern_instances\":${total_patterns},\"pattern_types\":${library_count},\"patterns\":[${library_entries}]}"

    echo "$library_json" > "$CDI_PATTERN_DIR/library.json" 2>/dev/null

    CDI_PATTERN_COUNT=$library_count

    log_info "CDI: Pattern library built - ${total_domains} domains, ${library_count} pattern types, ${total_patterns} instances"
    echo "$library_json"
    return 0
}

# =============================================================================
# cdi_get_intelligence_report - インテリジェンスダッシュボード
# =============================================================================
# Shows cross-domain coverage, learning volume, top patterns, insights
# =============================================================================
cdi_get_intelligence_report() {
    log_info "CDI: Generating intelligence report"

    # Ensure library is built
    local library_file="$CDI_PATTERN_DIR/library.json"
    if [[ ! -f "$library_file" ]]; then
        cdi_build_pattern_library >/dev/null 2>&1
    fi

    # Read library data
    local total_domains=0
    local total_pattern_instances=0

    if [[ -f "$library_file" ]] && command -v jq &>/dev/null; then
        total_domains=$(jq -r '.total_domains // 0' "$library_file" 2>/dev/null)
        total_pattern_instances=$(jq -r '.total_pattern_instances // 0' "$library_file" 2>/dev/null)
    fi

    # Count learning data
    local quality_entries=0
    local error_entries=0
    local solution_entries=0
    local success_patterns=0
    local anti_patterns=0

    [[ -f "$CDI_LEARNING_DIR/quality/scores.jsonl" ]] && \
        quality_entries=$(wc -l < "$CDI_LEARNING_DIR/quality/scores.jsonl" 2>/dev/null | tr -d ' ')
    [[ -f "$CDI_LEARNING_DIR/errors/patterns.jsonl" ]] && \
        error_entries=$(wc -l < "$CDI_LEARNING_DIR/errors/patterns.jsonl" 2>/dev/null | tr -d ' ')
    [[ -f "$CDI_LEARNING_DIR/solutions/index.jsonl" ]] && \
        solution_entries=$(wc -l < "$CDI_LEARNING_DIR/solutions/index.jsonl" 2>/dev/null | tr -d ' ')
    [[ -f "$CDI_PATTERN_DIR/success_patterns.jsonl" ]] && \
        success_patterns=$(wc -l < "$CDI_PATTERN_DIR/success_patterns.jsonl" 2>/dev/null | tr -d ' ')
    [[ -f "$CDI_PATTERN_DIR/anti_patterns.jsonl" ]] && \
        anti_patterns=$(wc -l < "$CDI_PATTERN_DIR/anti_patterns.jsonl" 2>/dev/null | tr -d ' ')

    local total_learning=$((quality_entries + error_entries + solution_entries + success_patterns + anti_patterns))

    # Count cross-domain mappings
    local cross_map_count=${#CDI_CROSS_MAP[@]}

    # Build top patterns list from library
    local top_patterns=""
    if [[ -f "$library_file" ]] && command -v jq &>/dev/null; then
        top_patterns=$(jq -r '.patterns | sort_by(-.universality_score) | .[:5] | .[] | "  \(.type): \(.universality_score)% (\(.frequency)/\(.domain_count) domains) [\(.universality_tier)]"' "$library_file" 2>/dev/null)
    fi

    # Build per-domain quality summary
    local domain_insights=""
    if [[ -f "$CDI_LEARNING_DIR/quality/scores.jsonl" ]]; then
        local seen_domains=""
        while IFS= read -r line; do
            local d
            d=$(echo "$line" | grep -o '"domain":"[^"]*"' | sed 's/"domain":"//;s/"//')
            [[ -z "$d" || "$seen_domains" == *"$d"* ]] && continue
            seen_domains+=" $d"

            local d_scores d_count d_sum d_avg
            d_scores=$(grep "\"domain\":\"${d}\"" "$CDI_LEARNING_DIR/quality/scores.jsonl" | grep -o '"score":[0-9]*' | sed 's/"score"://')
            d_count=0
            d_sum=0
            for s in $d_scores; do
                d_sum=$((d_sum + s))
                d_count=$((d_count + 1))
            done
            if [[ "$d_count" -gt 0 ]]; then
                d_avg=$((d_sum / d_count))
                domain_insights+="  ${d}: avg=${d_avg}/100 (${d_count} sessions)\n"
            fi
        done < "$CDI_LEARNING_DIR/quality/scores.jsonl"
    fi

    # ASCII Report
    local report=""
    report+="================================================================\n"
    report+="  SoloptiLinkAI v${CDI_VERSION} - Cross-Domain Intelligence Report\n"
    report+="  Generated: $(date '+%Y-%m-%d %H:%M:%S')\n"
    report+="================================================================\n"
    report+="\n"
    report+="  COVERAGE\n"
    report+="  --------\n"
    report+="  Registered domains:       ${total_domains}\n"
    report+="  Pattern type coverage:     ${CDI_PATTERN_COUNT} types\n"
    report+="  Total pattern instances:   ${total_pattern_instances}\n"
    report+="  Cross-domain mappings:     ${cross_map_count}\n"
    report+="  Universal quality rules:   ${CDI_UNIVERSAL_RULE_COUNT:-16}\n"
    report+="\n"
    report+="  LEARNING DATA\n"
    report+="  -------------\n"
    report+="  Quality score records:     ${quality_entries}\n"
    report+="  Error pattern records:     ${error_entries}\n"
    report+="  Solution records:          ${solution_entries}\n"
    report+="  Success patterns learned:  ${success_patterns}\n"
    report+="  Anti-patterns recorded:    ${anti_patterns}\n"
    report+="  Total learning entries:    ${total_learning}\n"
    report+="\n"
    report+="  TOP UNIVERSAL PATTERNS (by domain coverage)\n"
    report+="  -------------------------------------------\n"

    if [[ -n "$top_patterns" ]]; then
        report+="${top_patterns}\n"
    else
        report+="  (Run cdi_build_pattern_library to populate)\n"
    fi

    report+="\n"
    report+="  DOMAIN-SPECIFIC INSIGHTS\n"
    report+="  ------------------------\n"

    if [[ -n "$domain_insights" ]]; then
        report+="${domain_insights}"
    else
        report+="  (No session data yet. Run sessions to populate.)\n"
    fi

    report+="\n"
    report+="  CROSS-DOMAIN TRANSFER MAP\n"
    report+="  -------------------------\n"

    # Group cross-map entries by source
    local prev_source=""
    for map_key in $(echo "${!CDI_CROSS_MAP[@]}" | tr ' ' '\n' | sort); do
        local src tgt
        src=$(echo "$map_key" | sed 's/:.*//')
        tgt=$(echo "$map_key" | sed 's/.*->//')
        local pat
        pat=$(echo "$map_key" | sed "s/${src}://;s/->${tgt}//")

        if [[ "$src" != "$prev_source" ]]; then
            report+="  ${src}:\n"
            prev_source="$src"
        fi
        report+="    -> ${tgt} (${pat})\n"
    done

    report+="\n"
    report+="  SESSION STATISTICS\n"
    report+="  ------------------\n"
    report+="  Sessions analyzed (this run):  ${CDI_SESSION_ANALYZED}\n"
    report+="  Cross-matches found:           ${CDI_CROSS_MATCH_COUNT}\n"
    report+="\n"
    report+="================================================================\n"
    report+="  Engine Status: $([ "$CDI_INITIALIZED" = "true" ] && echo "ACTIVE" || echo "NOT INITIALIZED")\n"
    report+="================================================================\n"

    echo -e "$report"
    return 0
}

# =============================================================================
# Module self-test (invoked when script is run directly)
# =============================================================================
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    echo "=== Cross-Domain Intelligence Engine v${CDI_VERSION} Self-Test ==="

    cdi_init
    echo ""

    echo "--- Test: Analyze ecommerce patterns ---"
    cdi_analyze_domain_patterns "ecommerce" 2>/dev/null | python3 -m json.tool 2>/dev/null || cdi_analyze_domain_patterns "ecommerce"
    echo ""

    echo "--- Test: Cross-applicable patterns (ecommerce -> booking) ---"
    cdi_find_cross_applicable_patterns "ecommerce" "booking" 2>/dev/null | python3 -m json.tool 2>/dev/null || cdi_find_cross_applicable_patterns "ecommerce" "booking"
    echo ""

    echo "--- Test: Universal quality rules ---"
    cdi_build_universal_quality_rules 2>/dev/null | python3 -m json.tool 2>/dev/null || cdi_build_universal_quality_rules
    echo ""

    echo "--- Test: Build pattern library ---"
    cdi_build_pattern_library 2>/dev/null | python3 -m json.tool 2>/dev/null || cdi_build_pattern_library
    echo ""

    echo "--- Test: Domain quality profile (crm) ---"
    cdi_get_domain_quality_profile "crm" 2>/dev/null | python3 -m json.tool 2>/dev/null || cdi_get_domain_quality_profile "crm"
    echo ""

    echo "--- Test: Architecture suggestion (healthcare) ---"
    cdi_suggest_architecture "healthcare" 2>/dev/null | python3 -m json.tool 2>/dev/null || cdi_suggest_architecture "healthcare"
    echo ""

    echo "--- Test: Intelligence Report ---"
    cdi_get_intelligence_report
    echo ""

    echo "=== Self-Test Complete ==="
fi
