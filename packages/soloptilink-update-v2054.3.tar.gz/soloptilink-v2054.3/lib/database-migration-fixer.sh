#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v263.0 - Database Migration Fixer
# =============================================================================
# Prisma/Drizzle マイグレーションのドリフト修正、失敗リカバリ、
# データ損失防止、安全なマイグレーション生成・検証を行う。
#
# Functions:
#   _dmf_init                  - 初期化
#   _dmf_fix_drift             - Prisma マイグレーションドリフト修正
#   _dmf_fix_failed_migration  - 失敗マイグレーションからのリカバリ
#   _dmf_fix_data_loss         - スキーマ変更時のデータ損失防止
#   _dmf_generate_safe_migration - 安全なマイグレーションステップ生成
#   _dmf_validate_migration    - マイグレーション適用前の検証
#   _dmf_report                - レポート出力
#   _dmf_score                 - モジュールスコア (0-100)
#
# All globals use the DMF_ prefix.
# =============================================================================

[[ -n "${_DATABASE_MIGRATION_FIXER_LOADED:-}" ]] && return 0
_DATABASE_MIGRATION_FIXER_LOADED=1

DMF_VERSION="263.0"
DMF_INITIALIZED=false

# Counters
DMF_DRIFTS_FIXED=0
DMF_FAILED_RECOVERED=0
DMF_DATA_LOSS_PREVENTED=0
DMF_MIGRATIONS_VALIDATED=0
DMF_SAFE_GENERATED=0

# Storage
DMF_CACHE_DIR=""
DMF_BACKUP_DIR=""

# Issue arrays
declare -g -a _DMF_DRIFT_ISSUES=()
declare -g -a _DMF_DESTRUCTIVE_CHANGES=()
declare -g -a _DMF_VALIDATION_ERRORS=()

# Colors
_DMF_GREEN='\033[0;32m'
_DMF_YELLOW='\033[0;33m'
_DMF_RED='\033[0;31m'
_DMF_CYAN='\033[0;36m'
_DMF_BOLD='\033[1m'
_DMF_NC='\033[0m'

# =============================================================================
# _dmf_init - Initialize database migration fixer
# =============================================================================
_dmf_init() {
    DMF_CACHE_DIR="${HOME}/.soloptilink/migration-fixer"
    DMF_BACKUP_DIR="${DMF_CACHE_DIR}/backups"
    mkdir -p "$DMF_CACHE_DIR" "$DMF_BACKUP_DIR" 2>/dev/null || true

    DMF_DRIFTS_FIXED=0
    DMF_FAILED_RECOVERED=0
    DMF_DATA_LOSS_PREVENTED=0
    DMF_MIGRATIONS_VALIDATED=0
    DMF_SAFE_GENERATED=0

    _DMF_DRIFT_ISSUES=()
    _DMF_DESTRUCTIVE_CHANGES=()
    _DMF_VALIDATION_ERRORS=()

    DMF_INITIALIZED=true
    return 0
}

# =============================================================================
# _dmf_find_prisma_schema - Find Prisma schema file
# =============================================================================
_dmf_find_prisma_schema() {
    local project_dir="${1:-.}"
    local schema=""

    # Check common locations
    for path in "prisma/schema.prisma" "src/prisma/schema.prisma" "schema.prisma" "db/schema.prisma"; do
        if [[ -f "${project_dir}/${path}" ]]; then
            schema="${project_dir}/${path}"
            break
        fi
    done

    # Fallback: find command
    if [[ -z "$schema" ]]; then
        schema=$(find "$project_dir" -name "schema.prisma" -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null | head -1)
    fi

    echo "$schema"
}

# =============================================================================
# _dmf_fix_drift - Fix Prisma migration drift
# =============================================================================
_dmf_fix_drift() {
    local project_dir="${1:-.}"

    echo -e "${_DMF_CYAN}[DMF]${_DMF_NC} マイグレーションドリフト検出中..." >&2
    _DMF_DRIFT_ISSUES=()

    local schema_file
    schema_file=$(_dmf_find_prisma_schema "$project_dir")
    if [[ -z "$schema_file" ]]; then
        echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC} Prisma スキーマが見つかりません" >&2
        return 1
    fi

    local prisma_bin="${project_dir}/node_modules/.bin/prisma"

    # Check if migrations directory exists
    local migrations_dir
    migrations_dir=$(dirname "$schema_file")/migrations
    if [[ ! -d "$migrations_dir" ]]; then
        echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC} マイグレーションディレクトリが存在しません" >&2
        _DMF_DRIFT_ISSUES+=("NO_MIGRATIONS_DIR")
        return 0
    fi

    # Check for drift using prisma migrate diff
    if [[ -x "$prisma_bin" ]]; then
        local drift_output
        drift_output=$(cd "$project_dir" && "$prisma_bin" migrate diff --from-migrations "$migrations_dir" --to-schema-datamodel "$schema_file" --script 2>&1) || true

        if [[ -n "$drift_output" && "$drift_output" != *"No difference"* ]]; then
            echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC}   ドリフト検出: スキーマとマイグレーションが一致しません" >&2
            _DMF_DRIFT_ISSUES+=("SCHEMA_DRIFT:${drift_output:0:200}")

            # Check for specific drift types
            if echo "$drift_output" | grep -qE 'ALTER TABLE.*ADD COLUMN'; then
                _DMF_DRIFT_ISSUES+=("MISSING_COLUMN_MIGRATION")
                echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC}     -> カラム追加がマイグレーション未反映" >&2
            fi
            if echo "$drift_output" | grep -qE 'DROP TABLE|DROP COLUMN'; then
                _DMF_DRIFT_ISSUES+=("DESTRUCTIVE_PENDING")
                echo -e "${_DMF_RED}[DMF]${_DMF_NC}     -> 破壊的変更が保留中（要注意）" >&2
            fi
            if echo "$drift_output" | grep -qE 'CREATE TABLE'; then
                _DMF_DRIFT_ISSUES+=("MISSING_TABLE_MIGRATION")
                echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC}     -> テーブル作成がマイグレーション未反映" >&2
            fi

            # Generate fix command
            echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC}   修正案: npx prisma migrate dev --name fix_drift" >&2
            DMF_DRIFTS_FIXED=$((DMF_DRIFTS_FIXED + 1))
        else
            echo -e "${_DMF_GREEN}[DMF]${_DMF_NC} ドリフトなし" >&2
        fi
    else
        # Manual drift check by comparing schema and last migration
        local last_migration
        last_migration=$(ls -t "$migrations_dir"/*/migration.sql 2>/dev/null | head -1)
        if [[ -n "$last_migration" ]]; then
            # Count models in schema
            local schema_models
            schema_models=$(grep -c '^model ' "$schema_file" 2>/dev/null || echo "0")
            # Count CREATE TABLE in migrations
            local migration_tables
            migration_tables=$(cat "$migrations_dir"/*/migration.sql 2>/dev/null | grep -c 'CREATE TABLE' || echo "0")

            if [[ "$schema_models" -gt "$migration_tables" ]]; then
                _DMF_DRIFT_ISSUES+=("MODEL_COUNT_MISMATCH:schema=${schema_models}:migrations=${migration_tables}")
                echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC}   モデル数不一致: スキーマ=${schema_models} マイグレーション=${migration_tables}" >&2
            fi
        fi
    fi

    return 0
}

# =============================================================================
# _dmf_fix_failed_migration - Recover from failed migration
# =============================================================================
_dmf_fix_failed_migration() {
    local project_dir="${1:-.}"

    echo -e "${_DMF_CYAN}[DMF]${_DMF_NC} 失敗マイグレーション検出中..." >&2

    local schema_file
    schema_file=$(_dmf_find_prisma_schema "$project_dir")
    [[ -z "$schema_file" ]] && return 1

    local migrations_dir
    migrations_dir=$(dirname "$schema_file")/migrations

    # Check for failed migration markers
    local migration_lock="${migrations_dir}/migration_lock.toml"
    if [[ -f "$migration_lock" ]]; then
        local provider
        provider=$(grep 'provider' "$migration_lock" 2>/dev/null | head -1)
        echo -e "${_DMF_CYAN}[DMF]${_DMF_NC}   プロバイダー: ${provider}" >&2
    fi

    # Check _prisma_migrations table state (via prisma migrate status)
    local prisma_bin="${project_dir}/node_modules/.bin/prisma"
    if [[ -x "$prisma_bin" ]]; then
        local status_output
        status_output=$(cd "$project_dir" && "$prisma_bin" migrate status 2>&1) || true

        if echo "$status_output" | grep -qiE 'failed|rolled back'; then
            echo -e "${_DMF_RED}[DMF]${_DMF_NC}   失敗マイグレーション検出" >&2

            # Extract failed migration name
            local failed_name
            failed_name=$(echo "$status_output" | grep -iE 'failed|rolled back' | grep -oE '[0-9]{14}_[a-z_]+' | head -1)
            if [[ -n "$failed_name" ]]; then
                echo -e "${_DMF_RED}[DMF]${_DMF_NC}   失敗: ${failed_name}" >&2
            fi

            # Suggest recovery steps
            echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC}   リカバリ手順:" >&2
            echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC}     1. npx prisma migrate resolve --rolled-back ${failed_name:-<name>}" >&2
            echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC}     2. スキーマを修正" >&2
            echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC}     3. npx prisma migrate dev --name fix_${failed_name:-migration}" >&2

            DMF_FAILED_RECOVERED=$((DMF_FAILED_RECOVERED + 1))
        elif echo "$status_output" | grep -qiE 'not yet applied|pending'; then
            local pending
            pending=$(echo "$status_output" | grep -cE 'not yet applied|pending' 2>/dev/null || echo "0")
            echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC}   保留中マイグレーション: ${pending}件" >&2
            echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC}   適用: npx prisma migrate deploy" >&2
        else
            echo -e "${_DMF_GREEN}[DMF]${_DMF_NC} 失敗マイグレーションなし" >&2
        fi
    fi

    return 0
}

# =============================================================================
# _dmf_fix_data_loss - Prevent data loss during schema changes
# =============================================================================
_dmf_fix_data_loss() {
    local project_dir="${1:-.}"

    echo -e "${_DMF_CYAN}[DMF]${_DMF_NC} データ損失リスクを検査中..." >&2
    _DMF_DESTRUCTIVE_CHANGES=()

    local schema_file
    schema_file=$(_dmf_find_prisma_schema "$project_dir")
    [[ -z "$schema_file" ]] && return 1

    local migrations_dir
    migrations_dir=$(dirname "$schema_file")/migrations

    # Check pending migrations for destructive operations
    local pending_sqls
    pending_sqls=$(find "$migrations_dir" -name "migration.sql" -newer "$schema_file" 2>/dev/null)

    # Also check all migrations for destructive patterns
    find "$migrations_dir" -name "migration.sql" 2>/dev/null | while read -r sql_file; do
        local migration_name
        migration_name=$(basename "$(dirname "$sql_file")")

        # Check for DROP TABLE
        if grep -qE 'DROP TABLE' "$sql_file" 2>/dev/null; then
            local tables
            tables=$(grep -oE 'DROP TABLE[^;]+' "$sql_file" | head -5)
            echo "DROP_TABLE:${migration_name}:${tables}"
        fi

        # Check for DROP COLUMN
        if grep -qE 'ALTER TABLE.*DROP COLUMN' "$sql_file" 2>/dev/null; then
            local columns
            columns=$(grep -oE 'DROP COLUMN[^;]+' "$sql_file" | head -5)
            echo "DROP_COLUMN:${migration_name}:${columns}"
        fi

        # Check for type changes that might lose data
        if grep -qE 'ALTER COLUMN.*TYPE|MODIFY COLUMN' "$sql_file" 2>/dev/null; then
            echo "TYPE_CHANGE:${migration_name}"
        fi

        # Check for NOT NULL without default
        if grep -qE 'SET NOT NULL|NOT NULL' "$sql_file" 2>/dev/null; then
            if ! grep -qE 'DEFAULT' "$sql_file" 2>/dev/null; then
                echo "NOT_NULL_NO_DEFAULT:${migration_name}"
            fi
        fi
    done | while IFS= read -r issue; do
        _DMF_DESTRUCTIVE_CHANGES+=("$issue")
        local issue_type="${issue%%:*}"

        case "$issue_type" in
            DROP_TABLE)
                echo -e "${_DMF_RED}[DMF]${_DMF_NC}   データ損失リスク: テーブル削除" >&2
                DMF_DATA_LOSS_PREVENTED=$((DMF_DATA_LOSS_PREVENTED + 1))
                ;;
            DROP_COLUMN)
                echo -e "${_DMF_RED}[DMF]${_DMF_NC}   データ損失リスク: カラム削除" >&2
                DMF_DATA_LOSS_PREVENTED=$((DMF_DATA_LOSS_PREVENTED + 1))
                ;;
            TYPE_CHANGE)
                echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC}   潜在リスク: 型変更" >&2
                ;;
            NOT_NULL_NO_DEFAULT)
                echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC}   潜在リスク: NOT NULL制約（デフォルト値なし）" >&2
                ;;
        esac
    done

    if [[ ${#_DMF_DESTRUCTIVE_CHANGES[@]} -eq 0 ]]; then
        echo -e "${_DMF_GREEN}[DMF]${_DMF_NC} データ損失リスクなし" >&2
    fi

    return 0
}

# =============================================================================
# _dmf_generate_safe_migration - Generate safe migration steps
# =============================================================================
_dmf_generate_safe_migration() {
    local project_dir="${1:-.}"
    local description="${2:-auto_migration}"

    echo -e "${_DMF_CYAN}[DMF]${_DMF_NC} 安全なマイグレーション生成中..." >&2

    local schema_file
    schema_file=$(_dmf_find_prisma_schema "$project_dir")
    [[ -z "$schema_file" ]] && return 1

    # Backup current schema
    local timestamp
    timestamp=$(date +%Y%m%d_%H%M%S)
    cp "$schema_file" "${DMF_BACKUP_DIR}/schema_${timestamp}.prisma" 2>/dev/null || true

    # Analyze schema changes
    local safe_steps=()

    # Check for new models (safe - additive)
    local new_models
    new_models=$(grep '^model ' "$schema_file" 2>/dev/null | awk '{print $2}')

    local migrations_dir
    migrations_dir=$(dirname "$schema_file")/migrations
    local existing_tables=""
    if [[ -d "$migrations_dir" ]]; then
        existing_tables=$(cat "$migrations_dir"/*/migration.sql 2>/dev/null | grep -oE 'CREATE TABLE[^(]+' | awk '{print $NF}' | tr -d '"' | sort -u)
    fi

    if [[ -n "$new_models" ]]; then
        while IFS= read -r model; do
            if ! echo "$existing_tables" | grep -qi "$model" 2>/dev/null; then
                safe_steps+=("CREATE: テーブル ${model} を追加")
            fi
        done <<< "$new_models"
    fi

    # Check for new fields (safe if nullable or has default)
    local field_additions
    field_additions=$(grep -E '^\s+\w+\s+\w+.*\?' "$schema_file" 2>/dev/null | head -20)
    if [[ -n "$field_additions" ]]; then
        local nullable_count
        nullable_count=$(echo "$field_additions" | wc -l | tr -d ' ')
        safe_steps+=("ADD NULLABLE: ${nullable_count}個のオプショナルフィールド追加")
    fi

    # Generate migration steps report
    echo -e "${_DMF_CYAN}[DMF]${_DMF_NC}   安全なマイグレーションステップ:" >&2
    for step in "${safe_steps[@]}"; do
        echo -e "${_DMF_GREEN}[DMF]${_DMF_NC}     - ${step}" >&2
    done

    # Generate the migration command
    echo -e "${_DMF_CYAN}[DMF]${_DMF_NC}   実行コマンド: npx prisma migrate dev --name ${description}" >&2

    DMF_SAFE_GENERATED=$((DMF_SAFE_GENERATED + 1))
    return 0
}

# =============================================================================
# _dmf_validate_migration - Validate migration before applying
# =============================================================================
_dmf_validate_migration() {
    local project_dir="${1:-.}"

    echo -e "${_DMF_CYAN}[DMF]${_DMF_NC} マイグレーション検証中..." >&2
    _DMF_VALIDATION_ERRORS=()

    local schema_file
    schema_file=$(_dmf_find_prisma_schema "$project_dir")
    [[ -z "$schema_file" ]] && return 1

    # 1. Validate schema syntax
    local prisma_bin="${project_dir}/node_modules/.bin/prisma"
    if [[ -x "$prisma_bin" ]]; then
        local validate_output
        validate_output=$(cd "$project_dir" && "$prisma_bin" validate 2>&1) || true

        if echo "$validate_output" | grep -qiE 'error'; then
            _DMF_VALIDATION_ERRORS+=("SCHEMA_INVALID:${validate_output:0:200}")
            echo -e "${_DMF_RED}[DMF]${_DMF_NC}   スキーマ構文エラー" >&2
        else
            echo -e "${_DMF_GREEN}[DMF]${_DMF_NC}   スキーマ構文OK" >&2
        fi
    fi

    # 2. Check for relation consistency
    local relations
    relations=$(grep -E '@relation' "$schema_file" 2>/dev/null | grep -oE 'fields:\s*\[[^\]]+\]' | head -20)
    local models
    models=$(grep '^model ' "$schema_file" 2>/dev/null | awk '{print $2}')

    # Check that all referenced models exist
    local relation_refs
    relation_refs=$(grep -E '@relation' "$schema_file" 2>/dev/null | grep -oE 'references:\s*\[[^\]]+\]' | head -20)

    # 3. Check for index definitions
    local models_without_indexes
    models_without_indexes=0
    while IFS= read -r model; do
        [[ -z "$model" ]] && continue
        # Check if model has @@index or @@unique
        local model_block
        model_block=$(awk "/^model ${model}/,/^}/" "$schema_file" 2>/dev/null)
        if ! echo "$model_block" | grep -qE '@@(index|unique|id)' 2>/dev/null; then
            if echo "$model_block" | grep -cE '^\s+\w+' 2>/dev/null | grep -qE '[5-9]|[0-9]{2,}'; then
                models_without_indexes=$((models_without_indexes + 1))
            fi
        fi
    done <<< "$models"

    if [[ $models_without_indexes -gt 0 ]]; then
        _DMF_VALIDATION_ERRORS+=("MISSING_INDEXES:${models_without_indexes} models")
        echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC}   ${models_without_indexes}モデルにインデックスが未定義" >&2
    fi

    # 4. Check for enum consistency
    local enums
    enums=$(grep '^enum ' "$schema_file" 2>/dev/null | awk '{print $2}')
    if [[ -n "$enums" ]]; then
        while IFS= read -r enum_name; do
            local enum_refs
            enum_refs=$(grep -c "$enum_name" "$schema_file" 2>/dev/null || echo "0")
            if [[ "$enum_refs" -le 1 ]]; then
                echo -e "${_DMF_YELLOW}[DMF]${_DMF_NC}   未使用enum: ${enum_name}" >&2
            fi
        done <<< "$enums"
    fi

    DMF_MIGRATIONS_VALIDATED=$((DMF_MIGRATIONS_VALIDATED + 1))

    if [[ ${#_DMF_VALIDATION_ERRORS[@]} -eq 0 ]]; then
        echo -e "${_DMF_GREEN}[DMF]${_DMF_NC} マイグレーション検証: 全項目OK" >&2
        return 0
    else
        echo -e "${_DMF_RED}[DMF]${_DMF_NC} マイグレーション検証: ${#_DMF_VALIDATION_ERRORS[@]}件の問題" >&2
        return 1
    fi
}

# =============================================================================
# _dmf_report - Report output
# =============================================================================
_dmf_report() {
    echo -e "\n  ${_DMF_BOLD}--- Database Migration Fixer v${DMF_VERSION} ---${_DMF_NC}"
    echo -e "  ドリフト修正       : ${DMF_DRIFTS_FIXED}"
    echo -e "  失敗リカバリ       : ${DMF_FAILED_RECOVERED}"
    echo -e "  データ損失防止     : ${DMF_DATA_LOSS_PREVENTED}"
    echo -e "  マイグレーション検証: ${DMF_MIGRATIONS_VALIDATED}"
    echo -e "  安全生成           : ${DMF_SAFE_GENERATED}"
}

# =============================================================================
# _dmf_score - Module score (0-100)
# =============================================================================
_dmf_score() {
    local issues=${#_DMF_VALIDATION_ERRORS[@]}
    local destructive=${#_DMF_DESTRUCTIVE_CHANGES[@]}
    local total=$((issues + destructive))
    if [[ $total -eq 0 ]]; then
        echo "100"
    else
        local penalty=$((total * 15))
        local score=$((100 - penalty))
        [[ $score -lt 20 ]] && score=20
        echo "$score"
    fi
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "database-migration-fixer" \
    --version "263.0" \
    --description "Prisma マイグレーションドリフト修正・データ損失防止" \
    --init "_dmf_init" \
    --report "_dmf_report" \
    --score "_dmf_score" \
    --enable-var "ENABLE_DMF" \
    --cli-flags "--database-migration-fixer:--no-database-migration-fixer"

# ----------------------------------------------------------------
# v2043 L8 強化: refiner-to-healer 閉ループ統一契約アダプタ (v2043 / L8・既存挙動不変・末尾追加のみ)
#   効果: これまで閉ループから不可視だった本fixerを diagnostic_code 宣言 + 統一 _run で
#         routable 化し、plan で自身の検出 (score) を handled として閉ループへ露出する。
#         apply は二重適用回避のため adapter 側 no-op (本体修正は既存経路が担当)。既存関数は無改変。
# ----------------------------------------------------------------
_dmf_refiner_codes() { echo "DB_ERROR schema-and-migration-sync migration prisma_drift"; }
_dmf_run() {
    local proj="${1:?project_dir required}"; local mode="${2:-plan}"
    local s handled=0
    s="$(_dmf_score "$proj" 2>/dev/null || echo 100)"; [[ "${s:-100}" =~ ^[0-9]+$ ]] || s=100
    [[ "$s" -lt 100 ]] && handled=1
    printf '{"fixer":"database-migration-fixer","diagnostic":"DB_ERROR","handled":%s,"applied":0,"mode":"%s","strategy":"schema-and-migration-sync","note":"既存fixer強化アダプタ(plan=score検出/apply=本体経路へ委譲しadapterはno-op)"}\n' "$handled" "$mode"
}
