#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v380.0 - Industry Template: Legal
# =============================================================================
# 法律事務所/リーガルテック特化テンプレートエンジン。
# 案件管理/契約管理/タイムシート/請求等の法律業務必須コンポーネントを自動生成。
#
# All globals use the ITLG_ prefix.
# =============================================================================

[[ -n "${_INDUSTRY_TEMPLATE_LEGAL_LOADED:-}" ]] && return 0
_INDUSTRY_TEMPLATE_LEGAL_LOADED=1

declare -g ITLG_VERSION="380.0"
declare -g ITLG_INITIALIZED=false
declare -g ITLG_GENERATED_COUNT=0
declare -g ITLG_CASE_GENERATED=false
declare -g ITLG_CONTRACT_GENERATED=false
declare -g ITLG_TIMESHEET_GENERATED=false
declare -g ITLG_BILLING_GENERATED=false
declare -g ENABLE_ITLG="${ENABLE_ITLG:-true}"

_itlg_init() {
    ITLG_INITIALIZED=true
    ITLG_GENERATED_COUNT=0
    return 0
}

_itlg_generate_legal() {
    local project_dir="${1:-.}"
    [[ "$ITLG_INITIALIZED" != "true" ]] && _itlg_init

    echo -e "  ${CYAN:-\033[0;36m}[ITLG]${NC:-\033[0m} 法律業界テンプレート生成開始..." >&2

    _itlg_generate_case "$project_dir"
    _itlg_generate_contract "$project_dir"
    _itlg_generate_timesheet "$project_dir"
    _itlg_generate_billing "$project_dir"

    echo -e "  ${GREEN:-\033[0;32m}[ITLG]${NC:-\033[0m} 法律業界テンプレート生成完了: ${ITLG_GENERATED_COUNT}件" >&2
    return 0
}

_itlg_generate_case() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITLG-CASE] 案件管理テンプレート

### Prisma Schema
```prisma
model LegalCase {
  id            String   @id @default(cuid())
  caseNumber    String   @unique
  title         String
  type          String
  status        String   @default("active")
  clientId      String
  client        Client   @relation(fields: [clientId], references: [id])
  leadAttorneyId String
  assignedTo    CaseAssignment[]
  description   String?  @db.Text
  filingDate    DateTime?
  courtName     String?
  opposingParty String?
  opposingCounsel String?
  documents     CaseDocument[]
  timeEntries   TimeEntry[]
  invoices      LegalInvoice[]
  deadlines     CaseDeadline[]
  notes         CaseNote[]
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt
  @@index([clientId])
  @@index([status])
}

model CaseDeadline {
  id        String   @id @default(cuid())
  caseId    String
  legalCase LegalCase @relation(fields: [caseId], references: [id])
  title     String
  dueDate   DateTime
  type      String
  status    String   @default("pending")
  priority  String   @default("normal")
  assignedTo String?
  @@index([dueDate])
}

model CaseDocument {
  id        String   @id @default(cuid())
  caseId    String
  legalCase LegalCase @relation(fields: [caseId], references: [id])
  name      String
  type      String
  category  String
  url       String
  version   Int      @default(1)
  uploadedBy String
  uploadedAt DateTime @default(now())
  @@index([caseId, category])
}
```

### Case Dashboard
```tsx
'use client';
export function CaseDashboard() {
  const { data, isLoading } = useSWR('/api/cases?view=dashboard');
  if (isLoading) return <DashboardSkeleton />;

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard title="アクティブ案件" value={data?.activeCases ?? 0} />
        <StatCard title="今週の期限" value={data?.upcomingDeadlines ?? 0} color="warning" />
        <StatCard title="未請求時間" value={`${data?.unbilledHours ?? 0}h`} />
        <StatCard title="今月の売上" value={formatCurrency(data?.monthlyRevenue ?? 0)} />
      </div>
      <section>
        <h2 className="text-lg font-semibold mb-3">直近の期限</h2>
        {data?.deadlines?.map((d: CaseDeadline) => (
          <DeadlineCard key={d.id} deadline={d} />
        ))}
      </section>
    </div>
  );
}
```
TEMPLATE

    ITLG_CASE_GENERATED=true
    ITLG_GENERATED_COUNT=$((ITLG_GENERATED_COUNT + 1))
    return 0
}

_itlg_generate_contract() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITLG-CONTRACT] 契約管理テンプレート

### Schema
```prisma
model LegalContract {
  id              String   @id @default(cuid())
  title           String
  type            String
  status          String   @default("draft")
  parties         Json
  effectiveDate   DateTime?
  expirationDate  DateTime?
  renewalType     String?
  value           BigInt?
  currency        String   @default("JPY")
  terms           String?  @db.Text
  clauses         ContractClause[]
  versions        ContractVersion[]
  reviewHistory   ContractReview[]
  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt
}

model ContractClause {
  id         String @id @default(cuid())
  contractId String
  contract   LegalContract @relation(fields: [contractId], references: [id])
  title      String
  content    String @db.Text
  type       String
  sortOrder  Int
  isNegotiable Boolean @default(true)
}

model ContractVersion {
  id         String   @id @default(cuid())
  contractId String
  contract   LegalContract @relation(fields: [contractId], references: [id])
  version    Int
  content    String   @db.Text
  changes    String?  @db.Text
  createdBy  String
  createdAt  DateTime @default(now())
}
```

### Contract Comparison
```typescript
export async function compareContractVersions(contractId: string, v1: number, v2: number) {
  const [version1, version2] = await Promise.all([
    prisma.contractVersion.findFirst({ where: { contractId, version: v1 } }),
    prisma.contractVersion.findFirst({ where: { contractId, version: v2 } }),
  ]);
  if (!version1 || !version2) throw new Error('バージョンが見つかりません');
  return generateDiff(version1.content, version2.content);
}
```
TEMPLATE

    ITLG_CONTRACT_GENERATED=true
    ITLG_GENERATED_COUNT=$((ITLG_GENERATED_COUNT + 1))
    return 0
}

_itlg_generate_timesheet() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITLG-TIMESHEET] タイムシートテンプレート

### Schema
```prisma
model TimeEntry {
  id          String   @id @default(cuid())
  caseId      String
  legalCase   LegalCase @relation(fields: [caseId], references: [id])
  userId      String
  date        DateTime
  hours       Float
  description String
  activityCode String
  billable    Boolean  @default(true)
  billed      Boolean  @default(false)
  rate        Int?
  invoiceId   String?
  createdAt   DateTime @default(now())
  @@index([caseId, date])
  @@index([userId, date])
}
```

### Weekly Timesheet
```tsx
'use client';
export function WeeklyTimesheet({ userId, weekStart }: Props) {
  const { data, mutate } = useSWR(`/api/timesheets?userId=${userId}&weekStart=${weekStart.toISOString()}`);
  const days = Array.from({ length: 7 }, (_, i) => addDays(weekStart, i));

  const saveEntry = async (entry: Partial<TimeEntry>) => {
    await fetch('/api/timesheets', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(entry) });
    mutate();
  };

  const weekTotal = data?.entries?.reduce((sum: number, e: TimeEntry) => sum + e.hours, 0) ?? 0;

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-lg font-bold">週次タイムシート</h2>
        <span className="font-mono">{weekTotal.toFixed(1)}h / 40h</span>
      </div>
      {days.map(day => (
        <DayRow key={day.toISOString()} date={day}
          entries={data?.entries?.filter((e: TimeEntry) => isSameDay(new Date(e.date), day)) ?? []}
          onSave={saveEntry} />
      ))}
    </div>
  );
}
```
TEMPLATE

    ITLG_TIMESHEET_GENERATED=true
    ITLG_GENERATED_COUNT=$((ITLG_GENERATED_COUNT + 1))
    return 0
}

_itlg_generate_billing() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITLG-BILLING] 法律事務所請求テンプレート

### Schema
```prisma
model LegalInvoice {
  id         String   @id @default(cuid())
  caseId     String
  legalCase  LegalCase @relation(fields: [caseId], references: [id])
  clientId   String
  invoiceNumber String @unique
  status     String   @default("draft")
  subtotal   Int
  tax        Int
  total      Int
  issuedAt   DateTime?
  dueDate    DateTime?
  paidAt     DateTime?
  items      InvoiceLineItem[]
  @@index([clientId, status])
}

model InvoiceLineItem {
  id        String @id @default(cuid())
  invoiceId String
  invoice   LegalInvoice @relation(fields: [invoiceId], references: [id])
  description String
  hours     Float?
  rate      Int?
  amount    Int
  type      String @default("time")
}
```

### Invoice Generator
```typescript
export async function generateInvoice(caseId: string, period: { from: Date; to: Date }) {
  const unbilledEntries = await prisma.timeEntry.findMany({
    where: { caseId, billable: true, billed: false, date: { gte: period.from, lte: period.to } },
    include: { user: true },
  });
  if (unbilledEntries.length === 0) throw new Error('請求対象の時間エントリがありません');

  return prisma.$transaction(async (tx) => {
    const items = unbilledEntries.map(e => ({
      description: `${e.description} (${e.user.name})`, hours: e.hours, rate: e.rate!, amount: Math.round(e.hours * e.rate!), type: 'time',
    }));
    const subtotal = items.reduce((s, i) => s + i.amount, 0);
    const tax = Math.round(subtotal * 0.1);
    const invoice = await tx.legalInvoice.create({
      data: { caseId, clientId: (await tx.legalCase.findUniqueOrThrow({ where: { id: caseId } })).clientId,
        invoiceNumber: `INV-${format(new Date(), 'yyyyMMdd')}-${randomBytes(3).toString('hex')}`,
        subtotal, tax, total: subtotal + tax, items: { create: items } },
    });
    await tx.timeEntry.updateMany({ where: { id: { in: unbilledEntries.map(e => e.id) } }, data: { billed: true, invoiceId: invoice.id } });
    return invoice;
  });
}
```
TEMPLATE

    ITLG_BILLING_GENERATED=true
    ITLG_GENERATED_COUNT=$((ITLG_GENERATED_COUNT + 1))
    return 0
}

_itlg_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Industry Template: Legal v${ITLG_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成テンプレート数 : ${ITLG_GENERATED_COUNT}"
    echo -e "  Case               : ${ITLG_CASE_GENERATED}"
    echo -e "  Contract           : ${ITLG_CONTRACT_GENERATED}"
    echo -e "  Timesheet          : ${ITLG_TIMESHEET_GENERATED}"
    echo -e "  Billing            : ${ITLG_BILLING_GENERATED}"
}

_itlg_score() {
    local score=30
    [[ "$ITLG_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$ITLG_CASE_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITLG_CONTRACT_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITLG_TIMESHEET_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITLG_BILLING_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "industry-template-legal" \
    --version "380.0" \
    --description "法律業界テンプレート（案件/契約/タイムシート/請求）" \
    --init "_itlg_init" \
    --report "_itlg_report" \
    --score "_itlg_score" \
    --enable-var "ENABLE_ITLG" \
    --cli-flags "--industry-legal:--no-industry-legal"
