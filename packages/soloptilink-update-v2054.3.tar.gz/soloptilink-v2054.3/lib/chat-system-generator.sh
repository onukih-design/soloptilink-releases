#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v312.0 - Chat System Generator
# =============================================================================
# チャットシステム自動生成: メッセージモデル/UI/WebSocket/ファイル共有/既読
#
# 全globals: CHSG_ prefix
# =============================================================================

[[ -n "${_CHAT_SYSTEM_GENERATOR_LOADED:-}" ]] && return 0
_CHAT_SYSTEM_GENERATOR_LOADED=1

declare -g CHSG_VERSION="312.0"
declare -g CHSG_INITIALIZED=false
declare -g CHSG_GENERATED_COUNT=0
declare -g ENABLE_CHAT_SYSTEM_GENERATOR="${ENABLE_CHAT_SYSTEM_GENERATOR:-true}"

readonly CHSG_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly CHSG_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly CHSG_BOLD="${CLR_BOLD:-\033[1m}"
readonly CHSG_NC="${CLR_NC:-\033[0m}"

_chsg_log() { echo -e "  ${CHSG_CYAN}[CHSG]${CHSG_NC} $*" >&2; }
_chsg_ok()  { echo -e "  ${CHSG_GREEN}[CHSG] OK${CHSG_NC} $*" >&2; }

chsg_init() { CHSG_INITIALIZED=true; CHSG_GENERATED_COUNT=0; return 0; }
chsg_report() { [[ "$CHSG_INITIALIZED" != "true" ]] && return 0; echo -e "\n  ${CHSG_BOLD}--- Chat System Generator v${CHSG_VERSION} ---${CHSG_NC}" >&2; echo -e "  生成数: ${CHSG_GENERATED_COUNT}" >&2; }
chsg_score() { [[ "$CHSG_INITIALIZED" != "true" ]] && { echo "0"; return; }; local s=50; [[ $CHSG_GENERATED_COUNT -ge 3 ]] && s=80; [[ $CHSG_GENERATED_COUNT -ge 5 ]] && s=95; echo "$s"; }
chsg_init_message() { echo -e "  ${CHSG_GREEN}v${CHSG_VERSION} chat-system-generator: チャットシステム自動生成${CHSG_NC}" >&2; }

_chsg_generate_message_model() {
    local project_dir="${1:-.}"
    _chsg_log "メッセージモデル生成"
    local snippet='
// --- Chat System Models (v312.0) ---
model ChatRoom {
  id        String   @id @default(cuid())
  name      String?
  type      ChatRoomType @default(DIRECT)
  messages  ChatMessage[]
  members   ChatMember[]
  lastMessageAt DateTime?
  createdAt DateTime @default(now())
}
enum ChatRoomType { DIRECT GROUP CHANNEL }

model ChatMember {
  id       String   @id @default(cuid())
  roomId   String
  room     ChatRoom @relation(fields: [roomId], references: [id], onDelete: Cascade)
  userId   String
  role     String   @default("member")
  lastReadAt DateTime?
  joinedAt DateTime @default(now())
  @@unique([roomId, userId])
}

model ChatMessage {
  id        String   @id @default(cuid())
  roomId    String
  room      ChatRoom @relation(fields: [roomId], references: [id], onDelete: Cascade)
  senderId  String
  content   String?  @db.Text
  type      MessageType @default(TEXT)
  fileUrl   String?
  fileName  String?
  fileSize  Int?
  replyToId String?
  readReceipts ReadReceipt[]
  isEdited  Boolean  @default(false)
  isDeleted Boolean  @default(false)
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}
enum MessageType { TEXT IMAGE FILE SYSTEM }

model ReadReceipt {
  id        String   @id @default(cuid())
  messageId String
  message   ChatMessage @relation(fields: [messageId], references: [id], onDelete: Cascade)
  userId    String
  readAt    DateTime @default(now())
  @@unique([messageId, userId])
}'

    mkdir -p "${project_dir}/prisma"
    local sf="${project_dir}/prisma/schema.prisma"
    if [[ -f "$sf" ]] && ! grep -q "model ChatMessage" "$sf" 2>/dev/null; then echo "$snippet" >> "$sf"; fi
    CHSG_GENERATED_COUNT=$((CHSG_GENERATED_COUNT + 1))
    _chsg_ok "メッセージモデル生成完了"
    return 0
}

_chsg_generate_chat_ui() {
    local project_dir="${1:-.}"
    _chsg_log "チャットUI生成"
    local comp_dir="${project_dir}/src/components/chat"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/ChatWindow.tsx" <<'EOF'
'use client';
import { useState, useRef, useEffect, useCallback } from 'react';
import { Send, Paperclip, Smile, MoreVertical } from 'lucide-react';

interface Message { id: string; senderId: string; content?: string; type: string; fileUrl?: string; fileName?: string; createdAt: string; isEdited?: boolean; }
interface ChatWindowProps { roomId: string; currentUserId: string; messages: Message[]; onSend: (content: string) => void; onFileUpload?: (file: File) => void; }

export function ChatWindow({ roomId, currentUserId, messages, onSend, onFileUpload }: ChatWindowProps) {
  const [input, setInput] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const handleSend = () => { if (input.trim()) { onSend(input.trim()); setInput(''); } };
  const handleKeyDown = (e: React.KeyboardEvent) => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleSend(); } };
  const handleFile = (e: React.ChangeEvent<HTMLInputElement>) => { const f = e.target.files?.[0]; if (f && onFileUpload) onFileUpload(f); };

  return (
    <div className="flex flex-col h-full bg-white">
      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map(msg => {
          const isMine = msg.senderId === currentUserId;
          return (
            <div key={msg.id} className={`flex ${isMine ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[70%] rounded-2xl px-4 py-2 ${isMine ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-900'}`}>
                {msg.type === 'TEXT' && <p className="text-sm whitespace-pre-wrap">{msg.content}</p>}
                {msg.type === 'IMAGE' && msg.fileUrl && <img src={msg.fileUrl} alt="" className="rounded-lg max-w-full" />}
                {msg.type === 'FILE' && msg.fileUrl && (
                  <a href={msg.fileUrl} className="text-sm underline flex items-center gap-1"><Paperclip size={14} /> {msg.fileName || 'ファイル'}</a>
                )}
                <div className={`text-xs mt-1 ${isMine ? 'text-blue-200' : 'text-gray-400'}`}>
                  {new Date(msg.createdAt).toLocaleTimeString('ja-JP', { hour: '2-digit', minute: '2-digit' })}
                  {msg.isEdited && ' (編集済み)'}
                </div>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>
      <div className="border-t p-3">
        <div className="flex items-end gap-2">
          <button onClick={() => fileRef.current?.click()} className="p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100"><Paperclip size={20} /></button>
          <input ref={fileRef} type="file" className="hidden" onChange={handleFile} />
          <textarea value={input} onChange={e => setInput(e.target.value)} onKeyDown={handleKeyDown}
            placeholder="メッセージを入力..." rows={1}
            className="flex-1 border rounded-xl px-4 py-2 text-sm resize-none focus:ring-2 focus:ring-blue-500 focus:outline-none max-h-32" />
          <button onClick={handleSend} disabled={!input.trim()}
            className="p-2 bg-blue-600 text-white rounded-xl hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed"><Send size={20} /></button>
        </div>
      </div>
    </div>
  );
}
EOF

    CHSG_GENERATED_COUNT=$((CHSG_GENERATED_COUNT + 1))
    _chsg_ok "チャットUI生成完了"
    return 0
}

_chsg_generate_websocket() {
    local project_dir="${1:-.}"
    _chsg_log "WebSocketフック生成"
    local hooks_dir="${project_dir}/src/hooks"
    mkdir -p "$hooks_dir"

    cat > "${hooks_dir}/useChat.ts" <<'EOF'
'use client';
import { useState, useEffect, useCallback, useRef } from 'react';

interface ChatMessage { id: string; roomId: string; senderId: string; content?: string; type: string; fileUrl?: string; fileName?: string; createdAt: string; }
interface UseChatOptions { roomId: string; userId: string; wsUrl?: string; }

export function useChat({ roomId, userId, wsUrl }: UseChatOptions) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [connected, setConnected] = useState(false);
  const [typing, setTyping] = useState<string[]>([]);
  const wsRef = useRef<WebSocket | null>(null);
  const reconnectRef = useRef<NodeJS.Timeout>();

  const connect = useCallback(() => {
    const url = wsUrl || `${window.location.protocol === 'https:' ? 'wss:' : 'ws:'}//${window.location.host}/api/ws/chat?roomId=${roomId}&userId=${userId}`;
    const ws = new WebSocket(url);

    ws.onopen = () => { setConnected(true); };
    ws.onclose = () => {
      setConnected(false);
      reconnectRef.current = setTimeout(connect, 3000);
    };
    ws.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === 'message') setMessages(prev => [...prev, data.message]);
        else if (data.type === 'typing') setTyping(data.users.filter((u: string) => u !== userId));
        else if (data.type === 'history') setMessages(data.messages);
      } catch { /* ignore parse errors */ }
    };
    wsRef.current = ws;
  }, [roomId, userId, wsUrl]);

  useEffect(() => {
    // Load initial messages via REST
    fetch(`/api/chat/rooms/${roomId}/messages`).then(r => r.json()).then(d => setMessages(d.data || [])).catch(() => {});
    connect();
    return () => { clearTimeout(reconnectRef.current); wsRef.current?.close(); };
  }, [roomId, connect]);

  const sendMessage = useCallback((content: string, type = 'TEXT') => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ action: 'message', roomId, senderId: userId, content, type }));
    } else {
      // Fallback to REST
      fetch(`/api/chat/rooms/${roomId}/messages`, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ senderId: userId, content, type }),
      }).then(r => r.json()).then(msg => setMessages(prev => [...prev, msg])).catch(() => {});
    }
  }, [roomId, userId]);

  const sendTyping = useCallback(() => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ action: 'typing', roomId, userId }));
    }
  }, [roomId, userId]);

  return { messages, connected, typing, sendMessage, sendTyping };
}
EOF

    CHSG_GENERATED_COUNT=$((CHSG_GENERATED_COUNT + 1))
    _chsg_ok "WebSocketフック生成完了"
    return 0
}

_chsg_generate_file_sharing() {
    local project_dir="${1:-.}"
    _chsg_log "ファイル共有API生成"
    local api_dir="${project_dir}/src/app/api/chat/upload"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const formData = await req.formData();
    const file = formData.get('file') as File;
    const roomId = formData.get('roomId') as string;
    const senderId = formData.get('senderId') as string;
    if (!file || !roomId) return NextResponse.json({ error: 'file and roomId required' }, { status: 400 });

    // TODO: Upload to S3/R2
    const fileUrl = `/uploads/chat/${roomId}/${Date.now()}-${file.name}`;
    const type = file.type.startsWith('image/') ? 'IMAGE' : 'FILE';

    // Save message with file reference
    // const message = await prisma.chatMessage.create({ ... });

    return NextResponse.json({ fileUrl, fileName: file.name, fileSize: file.size, type });
  } catch (error) {
    return NextResponse.json({ error: 'Upload failed' }, { status: 500 });
  }
}
EOF

    CHSG_GENERATED_COUNT=$((CHSG_GENERATED_COUNT + 1))
    _chsg_ok "ファイル共有API生成完了"
    return 0
}

_chsg_generate_read_receipts() {
    local project_dir="${1:-.}"
    _chsg_log "既読機能API生成"
    local api_dir="${project_dir}/src/app/api/chat/rooms/[roomId]/read"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest, { params }: { params: { roomId: string } }) {
  try {
    const { userId, messageId } = await req.json();
    if (!userId || !messageId) return NextResponse.json({ error: 'userId and messageId required' }, { status: 400 });

    await prisma.readReceipt.upsert({
      where: { messageId_userId: { messageId, userId } },
      update: { readAt: new Date() },
      create: { messageId, userId },
    });

    await prisma.chatMember.updateMany({
      where: { roomId: params.roomId, userId },
      data: { lastReadAt: new Date() },
    });

    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to mark as read' }, { status: 500 });
  }
}

export async function GET(req: NextRequest, { params }: { params: { roomId: string } }) {
  try {
    const messageId = req.nextUrl.searchParams.get('messageId');
    if (!messageId) return NextResponse.json({ error: 'messageId required' }, { status: 400 });
    const receipts = await prisma.readReceipt.findMany({ where: { messageId } });
    return NextResponse.json({ data: receipts, readBy: receipts.length });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch receipts' }, { status: 500 });
  }
}
EOF

    CHSG_GENERATED_COUNT=$((CHSG_GENERATED_COUNT + 1))
    _chsg_ok "既読機能生成完了"
    return 0
}

_mr_register \
    --name "chat-system-generator" \
    --version "312.0" \
    --description "チャットシステム自動生成（メッセージ/UI/WebSocket/ファイル共有/既読）" \
    --init "chsg_init" \
    --report "chsg_report" \
    --score "chsg_score" \
    --enable-var "ENABLE_CHAT_SYSTEM_GENERATOR" \
    --cli-flags "--chat-system:--no-chat-system" \
    --init-msg "chsg_init_message"
