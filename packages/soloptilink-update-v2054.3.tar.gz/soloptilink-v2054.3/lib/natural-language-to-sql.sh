#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v402.0 - Natural Language to SQL Engine
# =============================================================================
# 自然言語クエリをSQL文に変換するエンジン。スキーマ認識・バリデーション・
# インジェクション防止を統合し、安全なSQL生成を実現する。
#
# Functions:
#   _nlsql_init           - 初期化・スキーマロード
#   _nlsql_parse_query    - 自然言語をAST中間表現にパース
#   _nlsql_generate_sql   - AST中間表現からSQL文を生成
#   _nlsql_validate_sql   - SQL安全性・構文・スキーマ整合性を検証
#   _nlsql_detect_schema  - Prismaスキーマから自動テーブル検出
#   _nlsql_report         - レポート出力
#   _nlsql_score          - モジュールスコア(0-100)
#
# All globals use the NLSQL_ prefix.
# =============================================================================

[[ -n "${_NATURAL_LANGUAGE_TO_SQL_LOADED:-}" ]] && return 0
_NATURAL_LANGUAGE_TO_SQL_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g NLSQL_VERSION="402.0"
declare -g NLSQL_INITIALIZED=false
declare -g NLSQL_STORE_DIR=""
declare -g NLSQL_QUERY_COUNT=0
declare -g NLSQL_GENERATE_COUNT=0
declare -g NLSQL_VALIDATE_PASS=0
declare -g NLSQL_VALIDATE_FAIL=0
declare -g NLSQL_INJECTION_BLOCKED=0

declare -g -A _NLSQL_TABLES=()         # table_name → column_list
declare -g -A _NLSQL_RELATIONS=()      # table_name → related_tables
declare -g -a _NLSQL_QUERY_LOG=()      # query history
declare -g -A _NLSQL_KEYWORD_MAP=()    # natural_keyword → sql_keyword

# =============================================================================
# _nlsql_init - Initialize NL-to-SQL engine
# =============================================================================
_nlsql_init() {
    local project_dir="${PROJECT_DIR:-.}"
    NLSQL_STORE_DIR="${project_dir}/.soloptilink/nl-sql"
    mkdir -p "${NLSQL_STORE_DIR}/queries" "${NLSQL_STORE_DIR}/cache"

    # Initialize keyword mapping
    _NLSQL_KEYWORD_MAP["show"]="SELECT"
    _NLSQL_KEYWORD_MAP["get"]="SELECT"
    _NLSQL_KEYWORD_MAP["find"]="SELECT"
    _NLSQL_KEYWORD_MAP["list"]="SELECT"
    _NLSQL_KEYWORD_MAP["count"]="COUNT"
    _NLSQL_KEYWORD_MAP["average"]="AVG"
    _NLSQL_KEYWORD_MAP["sum"]="SUM"
    _NLSQL_KEYWORD_MAP["maximum"]="MAX"
    _NLSQL_KEYWORD_MAP["minimum"]="MIN"
    _NLSQL_KEYWORD_MAP["where"]="WHERE"
    _NLSQL_KEYWORD_MAP["order"]="ORDER BY"
    _NLSQL_KEYWORD_MAP["sort"]="ORDER BY"
    _NLSQL_KEYWORD_MAP["group"]="GROUP BY"
    _NLSQL_KEYWORD_MAP["limit"]="LIMIT"
    _NLSQL_KEYWORD_MAP["top"]="LIMIT"
    _NLSQL_KEYWORD_MAP["join"]="JOIN"
    _NLSQL_KEYWORD_MAP["with"]="JOIN"
    _NLSQL_KEYWORD_MAP["delete"]="DELETE"
    _NLSQL_KEYWORD_MAP["remove"]="DELETE"
    _NLSQL_KEYWORD_MAP["update"]="UPDATE"
    _NLSQL_KEYWORD_MAP["change"]="UPDATE"
    _NLSQL_KEYWORD_MAP["create"]="INSERT INTO"
    _NLSQL_KEYWORD_MAP["add"]="INSERT INTO"
    _NLSQL_KEYWORD_MAP["insert"]="INSERT INTO"

    # Auto-detect schema from Prisma
    _nlsql_detect_schema "${project_dir}"

    NLSQL_INITIALIZED=true
    return 0
}

# =============================================================================
# _nlsql_detect_schema - Detect tables from Prisma schema
# =============================================================================
_nlsql_detect_schema() {
    local project_dir="$1"
    local schema_file=""

    # Find Prisma schema
    for candidate in \
        "${project_dir}/prisma/schema.prisma" \
        "${project_dir}/admin-dashboard/prisma/schema.prisma" \
        "${project_dir}/src/prisma/schema.prisma"; do
        [[ -f "$candidate" ]] && { schema_file="$candidate"; break; }
    done

    [[ -z "$schema_file" ]] && return 0

    # Parse model definitions
    local current_model=""
    local columns=""
    while IFS= read -r line; do
        if echo "$line" | grep -q '^model '; then
            [[ -n "$current_model" && -n "$columns" ]] && _NLSQL_TABLES["$current_model"]="$columns"
            current_model=$(echo "$line" | sed 's/^model \([A-Za-z]*\).*/\1/')
            columns=""
        elif [[ -n "$current_model" ]] && echo "$line" | grep -qE '^\s+\w+\s+\w+'; then
            local col_name
            col_name=$(echo "$line" | sed 's/^\s*\([a-zA-Z_]*\).*/\1/')
            [[ -n "$col_name" && "$col_name" != "}" ]] && columns="${columns:+${columns},}${col_name}"
        elif echo "$line" | grep -q '^}'; then
            [[ -n "$current_model" && -n "$columns" ]] && _NLSQL_TABLES["$current_model"]="$columns"
            current_model=""
            columns=""
        fi
    done < "$schema_file"

    return 0
}

# =============================================================================
# _nlsql_parse_query - Parse natural language to intermediate AST
# =============================================================================
_nlsql_parse_query() {
    local nl_query="$1"
    [[ -z "$nl_query" ]] && { echo "ERROR: Empty query" >&2; return 1; }

    NLSQL_QUERY_COUNT=$((NLSQL_QUERY_COUNT + 1))
    local lower_query
    lower_query=$(echo "$nl_query" | tr '[:upper:]' '[:lower:]')

    local action="SELECT"
    local target_table=""
    local columns="*"
    local conditions=""
    local ordering=""
    local limit_val=""
    local aggregation=""

    # Detect action
    local first_word
    first_word=$(echo "$lower_query" | awk '{print $1}')
    local mapped="${_NLSQL_KEYWORD_MAP[$first_word]:-}"
    [[ -n "$mapped" ]] && action="$mapped"

    # Detect table reference
    for table in "${!_NLSQL_TABLES[@]}"; do
        local lower_table
        lower_table=$(echo "$table" | tr '[:upper:]' '[:lower:]')
        if echo "$lower_query" | grep -qi "$lower_table\|${lower_table}s"; then
            target_table="$table"
            break
        fi
    done

    # Detect aggregation
    if echo "$lower_query" | grep -qi 'count\|how many'; then
        aggregation="COUNT(*)"
        action="SELECT"
    elif echo "$lower_query" | grep -qi 'average\|avg\|mean'; then
        aggregation="AVG"
    elif echo "$lower_query" | grep -qi 'total\|sum'; then
        aggregation="SUM"
    fi

    # Detect conditions
    if echo "$lower_query" | grep -qi 'where\|with\|that have\|whose\|which'; then
        local condition_part
        condition_part=$(echo "$lower_query" | sed -n 's/.*\(where\|with\|that have\|whose\|which\)\s*//ip')
        conditions="$condition_part"
    fi

    # Detect ordering
    if echo "$lower_query" | grep -qi 'order by\|sort by\|sorted\|newest\|oldest\|latest'; then
        if echo "$lower_query" | grep -qi 'newest\|latest\|recent'; then
            ordering="createdAt DESC"
        elif echo "$lower_query" | grep -qi 'oldest\|first'; then
            ordering="createdAt ASC"
        fi
    fi

    # Detect limit
    local limit_match
    limit_match=$(echo "$lower_query" | grep -oi 'top [0-9]*\|limit [0-9]*\|first [0-9]*\|last [0-9]*' | head -1)
    if [[ -n "$limit_match" ]]; then
        limit_val=$(echo "$limit_match" | grep -o '[0-9]*')
    fi

    # Build AST JSON
    cat <<ASTEOF
{"action":"${action}","table":"${target_table}","columns":"${columns}","aggregation":"${aggregation}","conditions":"${conditions}","ordering":"${ordering}","limit":"${limit_val}"}
ASTEOF

    _NLSQL_QUERY_LOG+=("${nl_query}")
    return 0
}

# =============================================================================
# _nlsql_generate_sql - Generate SQL from AST or natural language
# =============================================================================
_nlsql_generate_sql() {
    local ast_or_nl="$1"
    local safe_mode="${2:-true}"

    [[ "$NLSQL_INITIALIZED" != "true" ]] && { echo "ERROR: NLSQL not initialized" >&2; return 1; }
    NLSQL_GENERATE_COUNT=$((NLSQL_GENERATE_COUNT + 1))

    local action table columns aggregation conditions ordering limit_val
    if echo "$ast_or_nl" | grep -q '"action"'; then
        # Parse AST JSON
        action=$(echo "$ast_or_nl" | sed 's/.*"action":"\([^"]*\)".*/\1/')
        table=$(echo "$ast_or_nl" | sed 's/.*"table":"\([^"]*\)".*/\1/')
        columns=$(echo "$ast_or_nl" | sed 's/.*"columns":"\([^"]*\)".*/\1/')
        aggregation=$(echo "$ast_or_nl" | sed 's/.*"aggregation":"\([^"]*\)".*/\1/')
        conditions=$(echo "$ast_or_nl" | sed 's/.*"conditions":"\([^"]*\)".*/\1/')
        ordering=$(echo "$ast_or_nl" | sed 's/.*"ordering":"\([^"]*\)".*/\1/')
        limit_val=$(echo "$ast_or_nl" | sed 's/.*"limit":"\([^"]*\)".*/\1/')
    else
        # Parse from natural language first
        local ast
        ast=$(_nlsql_parse_query "$ast_or_nl")
        action=$(echo "$ast" | sed 's/.*"action":"\([^"]*\)".*/\1/')
        table=$(echo "$ast" | sed 's/.*"table":"\([^"]*\)".*/\1/')
        columns=$(echo "$ast" | sed 's/.*"columns":"\([^"]*\)".*/\1/')
        aggregation=$(echo "$ast" | sed 's/.*"aggregation":"\([^"]*\)".*/\1/')
        conditions=$(echo "$ast" | sed 's/.*"conditions":"\([^"]*\)".*/\1/')
        ordering=$(echo "$ast" | sed 's/.*"ordering":"\([^"]*\)".*/\1/')
        limit_val=$(echo "$ast" | sed 's/.*"limit":"\([^"]*\)".*/\1/')
    fi

    [[ -z "$table" ]] && { echo "ERROR: Could not determine target table" >&2; return 1; }

    # Build SQL
    local sql=""
    local select_expr="${columns}"
    [[ -n "$aggregation" && "$aggregation" != "COUNT(*)" ]] && select_expr="${aggregation}(${columns})"
    [[ "$aggregation" == "COUNT(*)" ]] && select_expr="COUNT(*)"

    case "$action" in
        SELECT)
            sql="SELECT ${select_expr} FROM \"${table}\""
            ;;
        DELETE)
            [[ "$safe_mode" == "true" && -z "$conditions" ]] && {
                echo "ERROR: DELETE without WHERE blocked in safe mode" >&2
                NLSQL_INJECTION_BLOCKED=$((NLSQL_INJECTION_BLOCKED + 1))
                return 1
            }
            sql="DELETE FROM \"${table}\""
            ;;
        UPDATE)
            sql="UPDATE \"${table}\" SET"
            ;;
        "INSERT INTO")
            sql="INSERT INTO \"${table}\""
            ;;
    esac

    [[ -n "$conditions" ]] && sql="${sql} WHERE ${conditions}"
    [[ -n "$ordering" ]] && sql="${sql} ORDER BY ${ordering}"
    [[ -n "$limit_val" ]] && sql="${sql} LIMIT ${limit_val}"

    sql="${sql};"
    echo "$sql"
    return 0
}

# =============================================================================
# _nlsql_validate_sql - Validate SQL for safety and correctness
# =============================================================================
_nlsql_validate_sql() {
    local sql="$1"
    local strict="${2:-true}"

    [[ -z "$sql" ]] && { echo "FAIL:empty_sql"; return 1; }

    local issues=()

    # Check 1: SQL injection patterns
    if echo "$sql" | grep -qiE ";\s*(DROP|ALTER|TRUNCATE|EXEC|UNION\s+SELECT)"; then
        issues+=("injection_detected")
        NLSQL_INJECTION_BLOCKED=$((NLSQL_INJECTION_BLOCKED + 1))
    fi

    # Check 2: Unescaped quotes
    local single_quotes
    single_quotes=$(echo "$sql" | tr -cd "'" | wc -c | tr -d ' ')
    if [[ $((single_quotes % 2)) -ne 0 ]]; then
        issues+=("unbalanced_quotes")
    fi

    # Check 3: DELETE/UPDATE without WHERE
    if [[ "$strict" == "true" ]]; then
        if echo "$sql" | grep -qi '^DELETE\|^UPDATE' && ! echo "$sql" | grep -qi 'WHERE'; then
            issues+=("destructive_without_where")
        fi
    fi

    # Check 4: Known table reference
    local has_known_table=false
    for table in "${!_NLSQL_TABLES[@]}"; do
        if echo "$sql" | grep -qi "$table"; then
            has_known_table=true
            break
        fi
    done
    if [[ "$has_known_table" != "true" && ${#_NLSQL_TABLES[@]} -gt 0 ]]; then
        issues+=("unknown_table")
    fi

    # Check 5: Basic syntax (must end with semicolon)
    if ! echo "$sql" | grep -q ';$'; then
        issues+=("missing_semicolon")
    fi

    # Check 6: Balanced parentheses
    local open_parens close_parens
    open_parens=$(echo "$sql" | tr -cd '(' | wc -c | tr -d ' ')
    close_parens=$(echo "$sql" | tr -cd ')' | wc -c | tr -d ' ')
    if [[ "$open_parens" != "$close_parens" ]]; then
        issues+=("unbalanced_parentheses")
    fi

    if [[ ${#issues[@]} -eq 0 ]]; then
        NLSQL_VALIDATE_PASS=$((NLSQL_VALIDATE_PASS + 1))
        echo "PASS"
        return 0
    else
        NLSQL_VALIDATE_FAIL=$((NLSQL_VALIDATE_FAIL + 1))
        local issue_str
        issue_str=$(IFS=','; echo "${issues[*]}")
        echo "FAIL:${issue_str}"
        return 1
    fi
}

# =============================================================================
# Report / Score
# =============================================================================
_nlsql_report() {
    echo -e "\n  ${BOLD:-}=== Natural Language to SQL v${NLSQL_VERSION} ===${NC:-}"
    echo -e "  Queries Parsed    : ${NLSQL_QUERY_COUNT}"
    echo -e "  SQL Generated     : ${NLSQL_GENERATE_COUNT}"
    echo -e "  Validation Pass   : ${NLSQL_VALIDATE_PASS}"
    echo -e "  Validation Fail   : ${NLSQL_VALIDATE_FAIL}"
    echo -e "  Injections Blocked: ${NLSQL_INJECTION_BLOCKED}"
    echo -e "  Known Tables      : ${#_NLSQL_TABLES[@]}"
}

_nlsql_score() {
    local score=30
    [[ "$NLSQL_INITIALIZED" == "true" ]] && score=$((score + 20))
    [[ ${#_NLSQL_TABLES[@]} -gt 0 ]] && score=$((score + 15))
    [[ $NLSQL_QUERY_COUNT -gt 0 ]] && score=$((score + 15))
    [[ $NLSQL_VALIDATE_PASS -gt 0 ]] && score=$((score + 10))
    [[ $NLSQL_INJECTION_BLOCKED -gt 0 ]] && score=$((score + 10))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "natural-language-to-sql" \
        --version "402.0" \
        --description "自然言語クエリからSQL生成・検証エンジン" \
        --init "_nlsql_init" \
        --report "_nlsql_report" \
        --score "_nlsql_score" \
        --enable-var "ENABLE_NLSQL" \
        --cli-flags "--nl-sql:--no-nl-sql"
fi

# v2003.1: source時のexit codeを確実に0にする
true
