#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v14.0 - Distributed Trace Propagator
# =============================================================================
# Provides distributed tracing across phases, agents, and Claude CLI calls.
# Each session gets a root trace_id, each phase/agent gets a span_id.
# Spans are stored as JSONL for future visualization.
# =============================================================================

[[ -n "${_TRACE_PROPAGATOR_LOADED:-}" ]] && return 0
_TRACE_PROPAGATOR_LOADED=1

# ============================================================
# State
# ============================================================
declare -g TRACE_ROOT_ID=""
declare -g TRACE_SESSION_DIR=""
declare -g TRACE_FILE=""
declare -g TRACE_SPAN_COUNT=0
declare -g -A TRACE_SPANS=()           # span_id -> name
declare -g -A TRACE_SPAN_START=()      # span_id -> epoch_ns
declare -g -A TRACE_SPAN_PARENT=()     # span_id -> parent_span_id
declare -g -A TRACE_SPAN_STATUS=()     # span_id -> ok|error
declare -g -A TRACE_SPAN_DURATION=()   # span_id -> ms
declare -g    TRACE_CURRENT_SPAN=""    # active span_id

# ============================================================
# Internal: generate 16-hex-char ID
# ============================================================
_trace_gen_id() {
    if command -v openssl &>/dev/null; then
        openssl rand -hex 8 2>/dev/null || printf '%04x%04x%04x%04x' $RANDOM $RANDOM $RANDOM $RANDOM
    else
        printf '%04x%04x%04x%04x' $RANDOM $RANDOM $RANDOM $RANDOM
    fi
}

# Internal logger
_trace_log() {
    local level="$1" msg="$2"
    echo -e "  ${CYAN:-}[TRACE]${NC:-} ${msg}" >&2
}

# Internal: save span as JSONL
_trace_save_span() {
    local json="$1"
    [[ -n "$TRACE_FILE" ]] && printf '%s\n' "$json" >> "$TRACE_FILE" 2>/dev/null || true
}

# ============================================================
# Initialize tracing for a session
# ============================================================
trace_init() {
    local session_id="${1:-unknown}"

    # Reset associative arrays from any previous session
    TRACE_SPANS=()
    TRACE_SPAN_START=()
    TRACE_SPAN_PARENT=()
    TRACE_SPAN_STATUS=()
    TRACE_SPAN_DURATION=()
    TRACE_SPAN_COUNT=0
    TRACE_CURRENT_SPAN=""

    TRACE_ROOT_ID=$(_trace_gen_id)
    TRACE_SESSION_DIR="${SESSION_LOG_DIR:-/tmp}/observatory"
    mkdir -p "$TRACE_SESSION_DIR" 2>/dev/null || true
    TRACE_FILE="${TRACE_SESSION_DIR}/traces.jsonl"

    # Write root span marker
    local ts
    ts=$(date -u +%Y-%m-%dT%H:%M:%S.000Z 2>/dev/null || date -u +%Y-%m-%dT%H:%M:%SZ)
    _trace_save_span "{\"trace_id\":\"${TRACE_ROOT_ID}\",\"span_id\":\"root\",\"parent_span_id\":\"\",\"name\":\"session_${session_id}\",\"type\":\"ROOT\",\"start_time\":\"${ts}\",\"status\":\"started\"}"

    _trace_log "INFO" "トレーシング初期化: trace_id=${TRACE_ROOT_ID}"
}

# ============================================================
# Create a new span
# ============================================================
trace_new_span() {
    local name="${1:-unnamed}"
    local parent="${2:-root}"

    local span_id
    span_id=$(_trace_gen_id)
    local start_epoch
    start_epoch=$(date +%s)

    TRACE_SPANS["$span_id"]="$name"
    TRACE_SPAN_START["$span_id"]="$start_epoch"
    TRACE_SPAN_PARENT["$span_id"]="$parent"
    TRACE_SPAN_STATUS["$span_id"]="running"
    TRACE_SPAN_COUNT=$((TRACE_SPAN_COUNT + 1))
    TRACE_CURRENT_SPAN="$span_id"

    local ts
    ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    _trace_save_span "{\"trace_id\":\"${TRACE_ROOT_ID}\",\"span_id\":\"${span_id}\",\"parent_span_id\":\"${parent}\",\"name\":\"${name}\",\"type\":\"SPAN_START\",\"start_time\":\"${ts}\",\"status\":\"running\"}"

    echo "$span_id"
}

# ============================================================
# End a span
# ============================================================
trace_end_span() {
    local span_id="${1:-}"
    local status="${2:-ok}"

    [[ -z "$span_id" ]] && return 0
    [[ -z "${TRACE_SPANS[$span_id]:-}" ]] && return 0

    local start_epoch="${TRACE_SPAN_START[$span_id]:-0}"
    local end_epoch
    end_epoch=$(date +%s)
    local duration_ms=$(( (end_epoch - start_epoch) * 1000 ))

    TRACE_SPAN_STATUS["$span_id"]="$status"
    TRACE_SPAN_DURATION["$span_id"]="$duration_ms"

    local name="${TRACE_SPANS[$span_id]}"
    local parent="${TRACE_SPAN_PARENT[$span_id]:-root}"
    local ts
    ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)

    _trace_save_span "{\"trace_id\":\"${TRACE_ROOT_ID}\",\"span_id\":\"${span_id}\",\"parent_span_id\":\"${parent}\",\"name\":\"${name}\",\"type\":\"SPAN_END\",\"end_time\":\"${ts}\",\"duration_ms\":${duration_ms},\"status\":\"${status}\"}"

    # Reset current span to parent
    if [[ "$TRACE_CURRENT_SPAN" == "$span_id" ]]; then
        TRACE_CURRENT_SPAN="$parent"
    fi
}

# ============================================================
# Get trace context string for prompt injection
# ============================================================
trace_context_string() {
    echo "trace_id=${TRACE_ROOT_ID:-none} span_id=${TRACE_CURRENT_SPAN:-root}"
}

# ============================================================
# Inject trace context into a prompt
# ============================================================
trace_inject_prompt() {
    local prompt="$1"
    local ctx
    ctx=$(trace_context_string)
    echo "[TRACE: ${ctx}]
${prompt}"
}

# ============================================================
# Export all spans as JSON
# ============================================================
trace_export_json() {
    [[ ! -f "$TRACE_FILE" ]] && return 0

    # End root span
    local ts
    ts=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    _trace_save_span "{\"trace_id\":\"${TRACE_ROOT_ID}\",\"span_id\":\"root\",\"type\":\"ROOT_END\",\"end_time\":\"${ts}\",\"total_spans\":${TRACE_SPAN_COUNT},\"status\":\"completed\"}"

    _trace_log "INFO" "トレースエクスポート: ${TRACE_FILE} (${TRACE_SPAN_COUNT} spans)"
}

# ============================================================
# Print ASCII waterfall diagram of spans
# ============================================================
trace_waterfall() {
    [[ ! -f "$TRACE_FILE" ]] && { echo "  (トレースデータなし)"; return 0; }

    echo ""
    echo -e "  ${BOLD:-}${CYAN:-}[Trace Waterfall] trace_id=${TRACE_ROOT_ID}${NC:-}"
    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"

    # Find session epoch range for scaling
    local min_start=999999999999 max_end=0
    local span_id name duration status

    for span_id in "${!TRACE_SPANS[@]}"; do
        local s="${TRACE_SPAN_START[$span_id]:-0}"
        local d="${TRACE_SPAN_DURATION[$span_id]:-0}"
        local e=$((s + d / 1000))
        [[ "$s" -lt "$min_start" && "$s" -gt 0 ]] && min_start="$s"
        [[ "$e" -gt "$max_end" ]] && max_end="$e"
    done

    local total_range=$((max_end - min_start))
    [[ "$total_range" -le 0 ]] && total_range=1
    local bar_width=40

    printf "  %-20s %-8s %s\n" "Span" "Duration" "Timeline"
    printf "  %-20s %-8s %s\n" "────────────────────" "────────" "$(printf '─%.0s' $(seq 1 $bar_width))"

    for span_id in "${!TRACE_SPANS[@]}"; do
        name="${TRACE_SPANS[$span_id]}"
        local s="${TRACE_SPAN_START[$span_id]:-$min_start}"
        local d="${TRACE_SPAN_DURATION[$span_id]:-0}"
        status="${TRACE_SPAN_STATUS[$span_id]:-unknown}"

        local offset=$(( (s - min_start) * bar_width / total_range ))
        local length=$(( d / 1000 * bar_width / total_range ))
        [[ "$length" -lt 1 ]] && length=1
        [[ "$offset" -lt 0 ]] && offset=0
        [[ $((offset + length)) -gt $bar_width ]] && length=$((bar_width - offset))

        local duration_str
        if [[ "$d" -ge 60000 ]]; then
            duration_str="$((d / 60000))m$((d % 60000 / 1000))s"
        else
            duration_str="$((d / 1000)).$((d % 1000 / 100))s"
        fi

        local bar=""
        local i
        for ((i=0; i<offset; i++)); do bar+=" "; done

        local color="${GREEN:-}"
        [[ "$status" == "error" ]] && color="${RED:-}"

        for ((i=0; i<length; i++)); do bar+="█"; done

        local name_short="${name:0:20}"
        printf "  %-20s %-8s ${color}%s${NC:-}\n" "$name_short" "$duration_str" "$bar"
    done

    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    echo -e "  Total spans: ${TRACE_SPAN_COUNT}"
    echo ""
}
