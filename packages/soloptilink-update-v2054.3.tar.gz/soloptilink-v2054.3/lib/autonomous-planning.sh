#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v475.0 - Autonomous Planning Engine
# =============================================================================
# ユーザーの自然言語要求から自律的に開発計画を生成する。
# 要件解析→タスク分解→依存関係構築→工数見積もり→リスク評価→
# 適応的計画修正までを完全自律で実行するAGIレベルのプランニングエンジン。
#
# Functions:
#   _ap_init               - 初期化
#   _ap_parse_requirements - 自然言語から要件抽出
#   _ap_generate_plan      - 実行計画の自動生成
#   _ap_validate_plan      - 計画の妥当性検証
#   _ap_adapt_plan         - 実行中の適応的計画修正
#   _ap_estimate_effort    - 工数見積もり
#   _ap_identify_risks     - リスク識別
#   _ap_report             - レポート出力
#   _ap_score              - モジュールスコア(0-100)
#
# Globals: AP_ prefix
# =============================================================================

[[ -n "${_AUTONOMOUS_PLANNING_LOADED:-}" ]] && return 0
_AUTONOMOUS_PLANNING_LOADED=1

AP_VERSION="475.0"
AP_INITIALIZED=false

# --- Storage ---
AP_DATA_DIR=""
AP_PLAN_FILE=""
AP_TASK_LOG=""
AP_RISK_LOG=""

# --- State ---
AP_TOTAL_TASKS=0
AP_COMPLETED_TASKS=0
AP_PLAN_REVISIONS=0
AP_ESTIMATED_HOURS=0
AP_RISK_COUNT=0

# --- Plan Structure ---
declare -g -a _AP_TASKS=()
declare -g -A _AP_TASK_STATUS=()
declare -g -A _AP_TASK_DEPS=()
declare -g -A _AP_TASK_PRIORITY=()
declare -g -A _AP_TASK_EFFORT=()
declare -g -A _AP_TASK_PHASE=()
declare -g -a _AP_RISKS=()
declare -g -A _AP_RISK_SEVERITY=()

# Phase definitions
declare -g -a AP_PHASES=(
    "requirements"
    "design"
    "scaffold"
    "implementation"
    "testing"
    "quality"
    "deployment"
    "monitoring"
)

# =============================================================================
# 初期化
# =============================================================================
_ap_init() {
    local project_dir="${PROJECT_DIR:-.}"
    AP_DATA_DIR="${project_dir}/.soloptilink/planning"
    AP_PLAN_FILE="${AP_DATA_DIR}/plan.json"
    AP_TASK_LOG="${AP_DATA_DIR}/tasks.jsonl"
    AP_RISK_LOG="${AP_DATA_DIR}/risks.jsonl"

    mkdir -p "$AP_DATA_DIR"

    # 既存計画のロード
    if [[ -f "$AP_TASK_LOG" ]]; then
        AP_TOTAL_TASKS=$(wc -l < "$AP_TASK_LOG" 2>/dev/null || echo "0")
        AP_COMPLETED_TASKS=$(grep -c '"done"' "$AP_TASK_LOG" 2>/dev/null || echo "0")
    fi

    AP_INITIALIZED=true
    return 0
}

# =============================================================================
# 自然言語から要件抽出
# =============================================================================
_ap_parse_requirements() {
    local description="$1"

    [[ "$AP_INITIALIZED" != "true" ]] && _ap_init

    local requirements=()

    # CRUD要件の検出
    if echo "$description" | grep -qiE "管理|CRUD|一覧|登録|編集|削除"; then
        requirements+=("crud_operations")
    fi

    # 認証要件
    if echo "$description" | grep -qiE "ログイン|認証|ユーザー|アカウント|会員|権限"; then
        requirements+=("authentication")
        if echo "$description" | grep -qiE "権限|ロール|admin|管理者"; then
            requirements+=("authorization_rbac")
        fi
    fi

    # リアルタイム要件
    if echo "$description" | grep -qiE "リアルタイム|チャット|通知|ライブ|WebSocket"; then
        requirements+=("realtime")
    fi

    # ファイルアップロード要件
    if echo "$description" | grep -qiE "アップロード|画像|ファイル|添付"; then
        requirements+=("file_upload")
    fi

    # 検索要件
    if echo "$description" | grep -qiE "検索|フィルタ|絞り込み|ソート"; then
        requirements+=("search_filter")
    fi

    # 決済要件
    if echo "$description" | grep -qiE "決済|支払い|課金|サブスク|Stripe"; then
        requirements+=("payment")
    fi

    # ダッシュボード要件
    if echo "$description" | grep -qiE "ダッシュボード|分析|統計|グラフ|チャート"; then
        requirements+=("analytics_dashboard")
    fi

    # メール要件
    if echo "$description" | grep -qiE "メール|通知|招待|リマインダー"; then
        requirements+=("email_notifications")
    fi

    # API要件
    if echo "$description" | grep -qiE "API|外部連携|インテグレーション|Webhook"; then
        requirements+=("external_api")
    fi

    # マルチテナント要件
    if echo "$description" | grep -qiE "マルチテナント|テナント|組織|チーム"; then
        requirements+=("multi_tenant")
    fi

    # i18n要件
    if echo "$description" | grep -qiE "多言語|i18n|国際化|翻訳"; then
        requirements+=("i18n")
    fi

    echo "${requirements[*]}"
    return 0
}

# =============================================================================
# 実行計画の自動生成
# =============================================================================
_ap_generate_plan() {
    local description="$1"
    local requirements="$2"

    [[ "$AP_INITIALIZED" != "true" ]] && _ap_init

    _AP_TASKS=()
    local task_id=0

    # Phase 1: 設計タスク
    _ap_add_task $((task_id++)) "requirements" "要件定義書の作成" "" "high" 1
    _ap_add_task $((task_id++)) "design" "データモデル設計(Prisma Schema)" "0" "high" 2
    _ap_add_task $((task_id++)) "design" "API設計(エンドポイント定義)" "1" "high" 2

    # Phase 2: スキャフォールド
    _ap_add_task $((task_id++)) "scaffold" "プロジェクト初期化(Next.js)" "0" "high" 1
    _ap_add_task $((task_id++)) "scaffold" "Prisma Schema実装・マイグレーション" "1" "high" 2

    # Phase 3: 実装タスク（要件に応じて動的生成）
    for req in $requirements; do
        case "$req" in
            crud_operations)
                _ap_add_task $((task_id++)) "implementation" "CRUDモデル・APIルート実装" "4" "high" 4
                _ap_add_task $((task_id++)) "implementation" "CRUD UIコンポーネント実装" "$((task_id-2))" "high" 4
                ;;
            authentication)
                _ap_add_task $((task_id++)) "implementation" "認証基盤(JWT/bcrypt)実装" "4" "critical" 3
                _ap_add_task $((task_id++)) "implementation" "ログイン/登録UIページ実装" "$((task_id-2))" "high" 2
                ;;
            authorization_rbac)
                _ap_add_task $((task_id++)) "implementation" "RBAC権限システム実装" "$((task_id-1))" "high" 3
                ;;
            realtime)
                _ap_add_task $((task_id++)) "implementation" "WebSocket/SSE基盤実装" "4" "medium" 3
                _ap_add_task $((task_id++)) "implementation" "リアルタイムUI連携" "$((task_id-2))" "medium" 2
                ;;
            file_upload)
                _ap_add_task $((task_id++)) "implementation" "ファイルアップロード基盤" "4" "medium" 2
                ;;
            search_filter)
                _ap_add_task $((task_id++)) "implementation" "検索・フィルタリング機能" "4" "medium" 2
                ;;
            payment)
                _ap_add_task $((task_id++)) "implementation" "決済統合(Stripe)" "4" "critical" 4
                ;;
            analytics_dashboard)
                _ap_add_task $((task_id++)) "implementation" "ダッシュボード・分析画面" "4" "medium" 3
                ;;
            email_notifications)
                _ap_add_task $((task_id++)) "implementation" "メール通知システム" "4" "medium" 2
                ;;
            external_api)
                _ap_add_task $((task_id++)) "implementation" "外部API統合" "4" "medium" 3
                ;;
            multi_tenant)
                _ap_add_task $((task_id++)) "implementation" "マルチテナント基盤" "4" "high" 4
                ;;
            i18n)
                _ap_add_task $((task_id++)) "implementation" "国際化(i18n)対応" "4" "low" 2
                ;;
        esac
    done

    # Phase 4: テスト
    _ap_add_task $((task_id++)) "testing" "ユニットテスト作成" "$((task_id-2))" "high" 3
    _ap_add_task $((task_id++)) "testing" "統合テスト作成" "$((task_id-2))" "high" 2
    _ap_add_task $((task_id++)) "testing" "E2Eテスト作成" "$((task_id-2))" "medium" 2

    # Phase 5: 品質
    _ap_add_task $((task_id++)) "quality" "セキュリティ監査" "$((task_id-2))" "high" 1
    _ap_add_task $((task_id++)) "quality" "パフォーマンス最適化" "$((task_id-2))" "medium" 2

    # Phase 6: デプロイ
    _ap_add_task $((task_id++)) "deployment" "デプロイメント設定" "$((task_id-2))" "high" 1

    AP_TOTAL_TASKS=${#_AP_TASKS[@]}

    # 工数集計
    AP_ESTIMATED_HOURS=0
    for key in "${!_AP_TASK_EFFORT[@]}"; do
        AP_ESTIMATED_HOURS=$((AP_ESTIMATED_HOURS + _AP_TASK_EFFORT[$key]))
    done

    # リスク識別
    _ap_identify_risks "$requirements"

    # 計画をファイルに保存
    _ap_save_plan

    echo "$AP_TOTAL_TASKS"
    return 0
}

# --- タスク追加ヘルパー ---
_ap_add_task() {
    local id="$1"
    local phase="$2"
    local name="$3"
    local deps="$4"
    local priority="$5"
    local effort="$6"

    _AP_TASKS+=("${id}:${name}")
    _AP_TASK_STATUS["$id"]="pending"
    _AP_TASK_DEPS["$id"]="$deps"
    _AP_TASK_PRIORITY["$id"]="$priority"
    _AP_TASK_EFFORT["$id"]="$effort"
    _AP_TASK_PHASE["$id"]="$phase"
}

# =============================================================================
# 計画の妥当性検証
# =============================================================================
_ap_validate_plan() {
    [[ "$AP_INITIALIZED" != "true" ]] && _ap_init

    local issues=0

    # 依存関係の循環チェック
    for task in "${_AP_TASKS[@]}"; do
        local id="${task%%:*}"
        local deps="${_AP_TASK_DEPS[$id]:-}"
        [[ -z "$deps" ]] && continue

        for dep in $deps; do
            local dep_deps="${_AP_TASK_DEPS[$dep]:-}"
            if [[ "$dep_deps" == *"$id"* ]]; then
                echo "[WARN] 循環依存検出: task $id <-> task $dep" >&2
                issues=$((issues + 1))
            fi
        done
    done

    # 未定義依存チェック
    for task in "${_AP_TASKS[@]}"; do
        local id="${task%%:*}"
        local deps="${_AP_TASK_DEPS[$id]:-}"
        for dep in $deps; do
            [[ -z "$dep" ]] && continue
            if [[ -z "${_AP_TASK_STATUS[$dep]:-}" ]]; then
                echo "[WARN] 未定義依存: task $id depends on non-existent task $dep" >&2
                issues=$((issues + 1))
            fi
        done
    done

    echo "$issues"
    return 0
}

# =============================================================================
# 適応的計画修正
# =============================================================================
_ap_adapt_plan() {
    local reason="$1"
    local failed_task="${2:-}"

    [[ "$AP_INITIALIZED" != "true" ]] && _ap_init

    AP_PLAN_REVISIONS=$((AP_PLAN_REVISIONS + 1))

    case "$reason" in
        task_failed)
            if [[ -n "$failed_task" ]]; then
                _AP_TASK_STATUS["$failed_task"]="failed"
                # 依存タスクをブロックに変更
                for task in "${_AP_TASKS[@]}"; do
                    local id="${task%%:*}"
                    local deps="${_AP_TASK_DEPS[$id]:-}"
                    if [[ "$deps" == *"$failed_task"* ]]; then
                        _AP_TASK_STATUS["$id"]="blocked"
                    fi
                done
                # リトライタスクを追加
                local name="${failed_task##*:}"
                local new_id=$((AP_TOTAL_TASKS))
                _ap_add_task $new_id "${_AP_TASK_PHASE[$failed_task]:-implementation}" "RETRY: ${name}" "" "critical" 2
                AP_TOTAL_TASKS=$((AP_TOTAL_TASKS + 1))
            fi
            ;;
        scope_change)
            echo "[ADAPT] スコープ変更による計画修正 (revision ${AP_PLAN_REVISIONS})" >&2
            ;;
        performance)
            echo "[ADAPT] パフォーマンス問題による計画修正 (revision ${AP_PLAN_REVISIONS})" >&2
            ;;
    esac

    _ap_save_plan
    return 0
}

# =============================================================================
# リスク識別
# =============================================================================
_ap_identify_risks() {
    local requirements="$1"

    _AP_RISKS=()

    if [[ "$requirements" == *"payment"* ]]; then
        _AP_RISKS+=("決済統合はPCI DSS準拠が必要")
        _AP_RISK_SEVERITY["${#_AP_RISKS[@]}"]="high"
        AP_RISK_COUNT=$((AP_RISK_COUNT + 1))
    fi

    if [[ "$requirements" == *"realtime"* ]]; then
        _AP_RISKS+=("WebSocket接続の同時接続数制限")
        _AP_RISK_SEVERITY["${#_AP_RISKS[@]}"]="medium"
        AP_RISK_COUNT=$((AP_RISK_COUNT + 1))
    fi

    if [[ "$requirements" == *"multi_tenant"* ]]; then
        _AP_RISKS+=("テナント間データ漏洩のリスク")
        _AP_RISK_SEVERITY["${#_AP_RISKS[@]}"]="critical"
        AP_RISK_COUNT=$((AP_RISK_COUNT + 1))
    fi

    if [[ $AP_ESTIMATED_HOURS -gt 40 ]]; then
        _AP_RISKS+=("大規模プロジェクト: 工数超過のリスク")
        _AP_RISK_SEVERITY["${#_AP_RISKS[@]}"]="medium"
        AP_RISK_COUNT=$((AP_RISK_COUNT + 1))
    fi

    return 0
}

# =============================================================================
# 計画保存
# =============================================================================
_ap_save_plan() {
    local timestamp
    timestamp=$(date +%s)

    {
        echo "{"
        echo "  \"version\": \"${AP_VERSION}\","
        echo "  \"timestamp\": ${timestamp},"
        echo "  \"total_tasks\": ${AP_TOTAL_TASKS},"
        echo "  \"estimated_hours\": ${AP_ESTIMATED_HOURS},"
        echo "  \"revisions\": ${AP_PLAN_REVISIONS},"
        echo "  \"risks\": ${AP_RISK_COUNT}"
        echo "}"
    } > "$AP_PLAN_FILE" 2>/dev/null
}

# =============================================================================
# 工数見積もり
# =============================================================================
_ap_estimate_effort() {
    echo "$AP_ESTIMATED_HOURS"
}

# =============================================================================
# レポート
# =============================================================================
_ap_report() {
    echo -e "\n  ${BOLD:-}═══ Autonomous Planning v${AP_VERSION} ═══${NC:-}"
    echo -e "  総タスク数         : ${AP_TOTAL_TASKS}"
    echo -e "  完了タスク         : ${AP_COMPLETED_TASKS}"
    echo -e "  見積工数           : ${AP_ESTIMATED_HOURS}h"
    echo -e "  計画改定回数       : ${AP_PLAN_REVISIONS}"
    echo -e "  リスク数           : ${AP_RISK_COUNT}"
}

_ap_score() {
    [[ "$AP_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    local s=50
    [[ $AP_TOTAL_TASKS -gt 0 ]] && s=$((s + 15))
    [[ $AP_COMPLETED_TASKS -gt 0 ]] && s=$((s + 15))
    [[ $AP_RISK_COUNT -gt 0 ]] && s=$((s + 10))  # リスク識別は良いこと
    [[ $AP_PLAN_REVISIONS -lt 5 ]] && s=$((s + 10))  # 安定した計画
    [[ $s -gt 100 ]] && s=100
    echo "$s"
}

_ap_init_message() {
    echo -e "  ${GREEN:-}✅ v${AP_VERSION} autonomous-planning: 自律プランニングエンジン (${AP_TOTAL_TASKS} tasks)${NC:-}" >&2
}

# =============================================================================
# Module Registry 登録
# =============================================================================
_mr_register \
    --name "autonomous-planning" \
    --version "$AP_VERSION" \
    --description "自律プランニングエンジン" \
    --init "_ap_init" \
    --report "_ap_report" \
    --score "_ap_score" \
    --enable-var "ENABLE_AUTONOMOUS_PLANNING" \
    --cli-flags "--autonomous-planning:--no-autonomous-planning" \
    --init-msg "_ap_init_message"
