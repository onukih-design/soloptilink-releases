#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v416.0 - Code Health Dashboard
# =============================================================================
# コードベース全体の健全性メトリクスを集約・ダッシュボード生成・
# トレンド追跡する統合ダッシュボードエンジン。
#
# Functions:
#   _chd_init               - 初期化
#   _chd_aggregate_metrics  - 全メトリクス集約
#   _chd_generate_dashboard - ダッシュボード生成
#   _chd_track_trends       - トレンド追跡
#   _chd_report             - レポート出力
#   _chd_score              - モジュールスコア(0-100)
#
# All globals use the CHD_ prefix.
# =============================================================================

[[ -n "${_CODE_HEALTH_DASHBOARD_LOADED:-}" ]] && return 0
_CODE_HEALTH_DASHBOARD_LOADED=1

declare -g CHD_VERSION="416.0"
declare -g CHD_INITIALIZED=false
declare -g CHD_STORE_DIR=""
declare -g CHD_AGGREGATE_COUNT=0
declare -g CHD_DASHBOARD_COUNT=0
declare -g CHD_OVERALL_HEALTH=0

declare -g -A _CHD_METRICS=()          # metric_name → value
declare -g -A _CHD_TRENDS=()           # metric_name → "val1,val2,val3..."
declare -g -A _CHD_THRESHOLDS=()       # metric_name → warning_threshold
declare -g -a _CHD_HEALTH_HISTORY=()

# =============================================================================
_chd_init() {
    local project_dir="${PROJECT_DIR:-.}"
    CHD_STORE_DIR="${project_dir}/.soloptilink/code-health"
    mkdir -p "${CHD_STORE_DIR}/dashboards" "${CHD_STORE_DIR}/trends"

    # Default thresholds
    _CHD_THRESHOLDS["test_coverage"]=60
    _CHD_THRESHOLDS["type_safety"]=80
    _CHD_THRESHOLDS["error_handling"]=70
    _CHD_THRESHOLDS["code_complexity"]=30
    _CHD_THRESHOLDS["tech_debt_score"]=40
    _CHD_THRESHOLDS["doc_coverage"]=50
    _CHD_THRESHOLDS["security_score"]=70
    _CHD_THRESHOLDS["dependency_freshness"]=60

    CHD_INITIALIZED=true
    return 0
}

# =============================================================================
# _chd_aggregate_metrics - Aggregate metrics from all sources
# =============================================================================
_chd_aggregate_metrics() {
    local project_dir="${1:-${PROJECT_DIR:-.}}"

    [[ "$CHD_INITIALIZED" != "true" ]] && { echo "ERROR: CHD not initialized" >&2; return 1; }
    CHD_AGGREGATE_COUNT=$((CHD_AGGREGATE_COUNT + 1))

    # Metric 1: File counts
    local ts_files tsx_files total_files
    ts_files=$(find "$project_dir" -name "*.ts" -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null | wc -l | tr -d ' ')
    tsx_files=$(find "$project_dir" -name "*.tsx" -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null | wc -l | tr -d ' ')
    total_files=$((ts_files + tsx_files))
    _CHD_METRICS["total_source_files"]=$total_files
    _CHD_METRICS["ts_files"]=$ts_files
    _CHD_METRICS["tsx_files"]=$tsx_files

    # Metric 2: Test coverage estimate
    local test_files
    test_files=$(find "$project_dir" \( -name "*.test.*" -o -name "*.spec.*" \) -not -path "*/node_modules/*" 2>/dev/null | wc -l | tr -d ' ')
    local test_ratio=0
    [[ $total_files -gt 0 ]] && test_ratio=$(( (test_files * 100) / total_files ))
    _CHD_METRICS["test_coverage"]=$test_ratio
    _CHD_METRICS["test_files"]=$test_files

    # Metric 3: Type safety (any usage)
    local any_count
    any_count=$(grep -rn ': any\b\|as any\b' "$project_dir" --include="*.ts" --include="*.tsx" 2>/dev/null | grep -v node_modules | wc -l | tr -d ' ')
    local type_safety=100
    [[ $total_files -gt 0 ]] && type_safety=$(( 100 - (any_count * 100 / (total_files + 1)) ))
    [[ $type_safety -lt 0 ]] && type_safety=0
    _CHD_METRICS["type_safety"]=$type_safety
    _CHD_METRICS["any_count"]=$any_count

    # Metric 4: Error handling
    local try_catch_files
    try_catch_files=$(grep -rl 'try {' "$project_dir" --include="*.ts" --include="*.tsx" 2>/dev/null | grep -v node_modules | wc -l | tr -d ' ')
    local error_handling=0
    [[ $total_files -gt 0 ]] && error_handling=$(( (try_catch_files * 100) / total_files ))
    [[ $error_handling -gt 100 ]] && error_handling=100
    _CHD_METRICS["error_handling"]=$error_handling

    # Metric 5: Documentation (README, JSDoc)
    local has_readme=0 jsdoc_files=0
    [[ -f "${project_dir}/README.md" ]] && has_readme=1
    jsdoc_files=$(grep -rl '/\*\*' "$project_dir" --include="*.ts" --include="*.tsx" 2>/dev/null | grep -v node_modules | wc -l | tr -d ' ')
    local doc_coverage=0
    [[ $total_files -gt 0 ]] && doc_coverage=$(( (jsdoc_files * 100) / total_files ))
    [[ $has_readme -eq 1 ]] && doc_coverage=$((doc_coverage + 10))
    [[ $doc_coverage -gt 100 ]] && doc_coverage=100
    _CHD_METRICS["doc_coverage"]=$doc_coverage

    # Metric 6: Security indicators
    local security_score=70
    if grep -rl 'bcrypt\|argon2\|helmet\|cors\|csrf' "$project_dir" --include="*.ts" --include="*.tsx" 2>/dev/null | grep -v node_modules | head -1 | grep -q .; then
        security_score=$((security_score + 15))
    fi
    if grep -rl 'z\.\|zod\|joi\|yup' "$project_dir" --include="*.ts" --include="*.tsx" 2>/dev/null | grep -v node_modules | head -1 | grep -q .; then
        security_score=$((security_score + 15))
    fi
    [[ $security_score -gt 100 ]] && security_score=100
    _CHD_METRICS["security_score"]=$security_score

    # Metric 7: Code complexity (line count proxy)
    local total_lines=0
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local lines
        lines=$(wc -l < "$file" | tr -d ' ')
        total_lines=$((total_lines + lines))
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" \) -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null | head -50)
    _CHD_METRICS["total_lines"]=$total_lines
    local avg_file_size=0
    [[ $total_files -gt 0 ]] && avg_file_size=$((total_lines / total_files))
    _CHD_METRICS["avg_file_size"]=$avg_file_size
    local complexity=$((avg_file_size > 200 ? 60 : (avg_file_size > 100 ? 30 : 10)))
    _CHD_METRICS["code_complexity"]=$complexity

    # Overall health score
    CHD_OVERALL_HEALTH=$(( (test_ratio + type_safety + error_handling + doc_coverage + security_score + (100 - complexity)) / 6 ))
    _CHD_METRICS["overall_health"]=$CHD_OVERALL_HEALTH

    cat <<AGGEOF
{"overall_health":${CHD_OVERALL_HEALTH},"total_files":${total_files},"total_lines":${total_lines},"test_coverage":${test_ratio},"type_safety":${type_safety},"error_handling":${error_handling},"doc_coverage":${doc_coverage},"security":${security_score}}
AGGEOF
    return 0
}

# =============================================================================
# _chd_generate_dashboard - Generate HTML dashboard
# =============================================================================
_chd_generate_dashboard() {
    local output_file="${1:-${CHD_STORE_DIR}/dashboards/health.html}"

    [[ "$CHD_INITIALIZED" != "true" ]] && { echo "ERROR: CHD not initialized" >&2; return 1; }
    CHD_DASHBOARD_COUNT=$((CHD_DASHBOARD_COUNT + 1))

    local health="${CHD_OVERALL_HEALTH:-0}"
    local health_color="red"
    [[ $health -ge 70 ]] && health_color="green"
    [[ $health -ge 40 && $health -lt 70 ]] && health_color="orange"

    cat > "$output_file" 2>/dev/null <<DASHEOF
<!DOCTYPE html>
<html lang="en">
<head><meta charset="UTF-8"><title>Code Health Dashboard</title>
<style>
body{font-family:system-ui;max-width:1200px;margin:0 auto;padding:20px;background:#f5f5f5}
.grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(200px,1fr));gap:16px;margin:20px 0}
.card{background:white;border-radius:8px;padding:20px;box-shadow:0 1px 3px rgba(0,0,0,.1)}
.card h3{margin:0 0 8px;font-size:14px;color:#666}
.card .value{font-size:32px;font-weight:bold}
.good{color:#22c55e} .warn{color:#f59e0b} .bad{color:#ef4444}
.bar{height:8px;border-radius:4px;background:#e5e7eb;margin-top:8px}
.bar-fill{height:100%;border-radius:4px;transition:width .3s}
h1{color:#1f2937} .timestamp{color:#9ca3af;font-size:12px}
</style></head>
<body>
<h1>Code Health Dashboard</h1>
<p class="timestamp">Generated: $(date 2>/dev/null || echo "N/A")</p>
<div class="grid">
  <div class="card"><h3>Overall Health</h3><div class="value" style="color:${health_color}">${health}%</div>
  <div class="bar"><div class="bar-fill" style="width:${health}%;background:${health_color}"></div></div></div>
  <div class="card"><h3>Test Coverage</h3><div class="value">${_CHD_METRICS[test_coverage]:-0}%</div></div>
  <div class="card"><h3>Type Safety</h3><div class="value">${_CHD_METRICS[type_safety]:-0}%</div></div>
  <div class="card"><h3>Error Handling</h3><div class="value">${_CHD_METRICS[error_handling]:-0}%</div></div>
  <div class="card"><h3>Security Score</h3><div class="value">${_CHD_METRICS[security_score]:-0}%</div></div>
  <div class="card"><h3>Source Files</h3><div class="value">${_CHD_METRICS[total_source_files]:-0}</div></div>
  <div class="card"><h3>Total Lines</h3><div class="value">${_CHD_METRICS[total_lines]:-0}</div></div>
  <div class="card"><h3>Avg File Size</h3><div class="value">${_CHD_METRICS[avg_file_size]:-0}L</div></div>
</div>
</body></html>
DASHEOF

    echo "$output_file"
    return 0
}

# =============================================================================
# _chd_track_trends - Record and analyze metric trends
# =============================================================================
_chd_track_trends() {
    [[ "$CHD_INITIALIZED" != "true" ]] && return 1

    local timestamp
    timestamp=$(date +%s 2>/dev/null || echo "0")

    for metric in "${!_CHD_METRICS[@]}"; do
        local value="${_CHD_METRICS[$metric]}"
        local history="${_CHD_TRENDS[$metric]:-}"
        _CHD_TRENDS["$metric"]="${history:+${history},}${value}"
    done

    _CHD_HEALTH_HISTORY+=("${timestamp}:${CHD_OVERALL_HEALTH}")

    # Trend analysis
    local trend="stable"
    if [[ ${#_CHD_HEALTH_HISTORY[@]} -ge 2 ]]; then
        local prev_health
        prev_health=$(echo "${_CHD_HEALTH_HISTORY[-2]}" | cut -d: -f2)
        if [[ $CHD_OVERALL_HEALTH -gt $prev_health ]]; then
            trend="improving"
        elif [[ $CHD_OVERALL_HEALTH -lt $prev_health ]]; then
            trend="declining"
        fi
    fi

    echo "{\"trend\":\"${trend}\",\"current_health\":${CHD_OVERALL_HEALTH},\"data_points\":${#_CHD_HEALTH_HISTORY[@]}}"
    return 0
}

# =============================================================================
# Report / Score
# =============================================================================
_chd_report() {
    echo -e "\n  ${BOLD:-}=== Code Health Dashboard v${CHD_VERSION} ===${NC:-}"
    echo -e "  Aggregations    : ${CHD_AGGREGATE_COUNT}"
    echo -e "  Dashboards      : ${CHD_DASHBOARD_COUNT}"
    echo -e "  Overall Health  : ${CHD_OVERALL_HEALTH}%"
    echo -e "  Metrics Tracked : ${#_CHD_METRICS[@]}"
}

_chd_score() {
    local score=30
    [[ "$CHD_INITIALIZED" == "true" ]] && score=$((score + 20))
    [[ $CHD_AGGREGATE_COUNT -gt 0 ]] && score=$((score + 20))
    [[ $CHD_OVERALL_HEALTH -ge 70 ]] && score=$((score + 30))
    [[ $CHD_OVERALL_HEALTH -ge 40 && $CHD_OVERALL_HEALTH -lt 70 ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "code-health-dashboard" \
        --version "416.0" \
        --description "コード健全性メトリクス集約・ダッシュボード・トレンド追跡" \
        --init "_chd_init" \
        --report "_chd_report" \
        --score "_chd_score" \
        --enable-var "ENABLE_CHD" \
        --cli-flags "--code-health:--no-code-health"
fi

# v2003.1: source時のexit codeを確実に0にする
true
