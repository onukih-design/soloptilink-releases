#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2037.x - Connector Forge
# =============================================================================
# 自然言語の連携依頼(「Zoom連携を追加して」)を受け、IBL辞書を引いて
# OAuth/APIクライアント/Webhook署名検証/設定UI/日本語手順を一発配線する。
# 既存の natural-language-to-api / ibl と連携。Desktopでも動く決定論生成
# (claude -p 非依存 / PFP-068 回避 = Phase 4 のDesktop経路の実体)。
#
# Functions:
#   cf_init             - 初期化(IBL読込)
#   cf_forge <自然言語> <project_dir> - 検出→生成を一気通貫
#   cf_forge_connector <connector> <project_dir> - コネクタ指定で生成
#   cf_report / cf_score
#
# All globals use the CF_ prefix.
# (c) 2026 SoloptiLink Inc. - 営業秘密 / 著作権法・不正競争防止法で保護
# =============================================================================

[[ -n "${_CONNECTOR_FORGE_LOADED:-}" ]] && return 0
_CONNECTOR_FORGE_LOADED=1

declare -g CF_VERSION="1.0"
declare -g CF_INITIALIZED=false
declare -g CF_HOME="${HOME}/.soloptilink"
declare -g CF_FORGE_PY="${CF_HOME}/lib/connector-forge/forge.py"
declare -g CF_IBL_DIR="${CF_HOME}/integrations"
declare -g CF_FORGE_COUNT=0
declare -g CF_LAST_CONNECTOR=""
declare -g CF_LAST_RESULT=""

cf_init() {
    [[ -f "${CF_HOME}/lib/ibl.sh" ]] && source "${CF_HOME}/lib/ibl.sh" 2>/dev/null || true
    type -t ibl_init &>/dev/null && ibl_init 2>/dev/null || true
    CF_INITIALIZED=true
    return 0
}

# 自然言語からコネクタを検出して生成する
# 使い方: cf_forge "Zoom連携を追加して" "/path/to/project"
cf_forge() {
    local nl_request="$1"
    local project_dir="${2:-$PWD}"
    [[ -z "$nl_request" ]] && { echo "ERROR: 連携依頼テキストが空です" >&2; return 1; }

    # IBL検出
    local detect_json connector score
    if ! type -t ibl_detect &>/dev/null; then
        source "${CF_HOME}/lib/ibl.sh" 2>/dev/null && ibl_init 2>/dev/null || true
    fi
    detect_json=$(ibl_detect "$nl_request")
    connector=$(echo "$detect_json" | python3 -c "import sys,json;print(json.load(sys.stdin).get('connector',''))" 2>/dev/null)
    local confident
    confident=$(echo "$detect_json" | python3 -c "import sys,json;print(json.load(sys.stdin).get('confident',False))" 2>/dev/null)

    # 未登録 or 低確信 → 誤検出で別サービスに繋がず、長尾フォールバックへ案内する。
    if [[ -z "$connector" || "$confident" != "True" ]]; then
        echo "::IBL_UNREGISTERED::" >&2
        echo "この連携先は辞書に未登録(または確信度が低い)です。『一言で何でも繋がる』ため、次のどちらかで対応します:" >&2
        echo "  ① 正確な辞書を新規作成 (zoom.json を手本に正確な値で) → ~/.soloptilink/integrations/ に保存 → 再実行" >&2
        echo "  ② 雛形を即作って繋ぐ: cf_draft \"<サービス名>\" \"<id>\" \"<category>\" \"$project_dir\" (Claudeが後で公式仕様で精緻化)" >&2
        return 2
    fi
    echo "  検出: ${connector} (confident)" >&2
    cf_forge_connector "$connector" "$project_dir"
}

# 長尾フォールバック: 辞書に無いサービスでも雛形辞書を即作成して配線する。
# 使い方: cf_draft "<サービス名>" [<id>] [<category>] [<project>]
cf_draft() {
    local display="$1" cid="${2:-}" category="${3:-other}" project_dir="${4:-$PWD}"
    [[ -z "$display" ]] && { echo "usage: cf_draft \"<サービス名>\" [id] [category] [project]" >&2; return 1; }
    local draft_py="${CF_HOME}/lib/connector-forge/draft.py"
    [[ ! -f "$draft_py" ]] && { echo "ERROR: 雛形生成器が見つかりません: ${draft_py}" >&2; return 1; }
    local out realid
    out=$(python3 "$draft_py" "$display" "$cid" "$category" 2>&1)
    realid=$(echo "$out" | python3 -c "import sys,json;print(json.load(sys.stdin).get('connector',''))" 2>/dev/null)
    echo "$out" >&2
    [[ -z "$realid" ]] && return 1
    # 雛形を即 forge (配線の雛形が出る。Claude が辞書を精緻化後に再 forge して精度を上げる)
    cf_forge_connector "$realid" "$project_dir"
}

# コネクタ名を直接指定して生成する
cf_forge_connector() {
    local connector="$1"
    local project_dir="${2:-$PWD}"
    local conn_file="${CF_IBL_DIR}/${connector}.json"

    [[ ! -f "$conn_file" ]] && { echo "ERROR: コネクタ辞書が見つかりません: ${connector}" >&2; return 1; }
    [[ ! -f "$CF_FORGE_PY" ]] && { echo "ERROR: 生成エンジンが見つかりません: ${CF_FORGE_PY}" >&2; return 1; }
    mkdir -p "$project_dir" 2>/dev/null || true

    local result
    result=$(python3 "$CF_FORGE_PY" "$conn_file" "$project_dir" 2>&1)
    local rc=$?
    if [[ $rc -ne 0 ]]; then
        echo "ERROR: 生成に失敗しました: $result" >&2
        return 1
    fi
    CF_FORGE_COUNT=$((CF_FORGE_COUNT + 1))
    CF_LAST_CONNECTOR="$connector"
    CF_LAST_RESULT="$result"

    # 連携の利用を学習ループへ記録 (Phase 3)
    if type -t ill_record_integration_use &>/dev/null; then
        ill_record_integration_use "$connector" "forge" "$project_dir" 2>/dev/null || true
    fi

    # PFP-118: 生成コードの catch パスへ friction 記録テンプレを注入 (学習閉ループの実データ化)
    cf_inject_friction_recorder "$connector" "$project_dir" 2>/dev/null || true

    echo "$result"
    return 0
}

# =============================================================================
# PFP-118 Learning Loop Revival: 生成コードへの friction 記録テンプレ注入
# =============================================================================
# forge が生成した OAuth/webhook/APIクライアントコードのエラーハンドラ (catch パス) に、
# 「どこで詰まったか」を記録するテンプレを注入する。記録はシェル経由ではなく、
# 生成 TS コード内コメント + API route 経由の軽量 JSONL 追記
# (<project>/.soloptilink/integration-friction.jsonl / ill_record_friction と同形式)。
# その JSONL は ill_ingest_project_frictions (integration-learning-loop.sh) が
# ILL の friction.jsonl へ取り込み、IBL 辞書 (learned_pitfalls) まで還元される。
# 冪等: 注入済みマーカー (PFP-118) があるファイルには再注入しない。
cf_inject_friction_recorder() {
    local connector="$1" project_dir="${2:-$PWD}"
    [[ -z "$connector" || ! -d "$project_dir" ]] && return 0
    CF_CONN="$connector" CF_PROJ="$project_dir" python3 - <<'PY' >&2 2>/dev/null || true
import os
conn = os.environ["CF_CONN"]; proj = os.environ["CF_PROJ"]
MARK = "PFP-118"  # 注入済み判定マーカー (全注入ブロックのコメントに含む)

# --- 1. friction 記録 API route (プロジェクトに1つ / 既存なら触らない) ---
route_dir = os.path.join(proj, "app", "api", "integrations", "friction")
route_path = os.path.join(route_dir, "route.ts")
if not os.path.exists(route_path):
    os.makedirs(route_dir, exist_ok=True)
    route = '''// 連携の詰まり(friction)を学習ループへ記録する軽量API (SoloptiLinkAI PFP-118)。
// Integration Learning Loop (ill_record_friction) と同形式の JSONL を
// プロジェクト直下の .soloptilink/integration-friction.jsonl に追記する。
// 失敗しても本体機能には一切影響しない (best-effort)。
export const runtime = "nodejs";

export async function POST(req: Request): Promise<Response> {
  try {
    const body = (await req.json().catch(() => ({}))) as Record<string, unknown>;
    const entry = {
      ts: new Date().toISOString(),
      connector: String(body.connector ?? "unknown").slice(0, 100),
      stage: String(body.stage ?? "unknown").slice(0, 100),
      note: String(body.note ?? "").slice(0, 500),
      error: String(body.error ?? "").slice(0, 500),
    };
    const fs = await import("node:fs");
    const path = await import("node:path");
    const dir = path.join(process.cwd(), ".soloptilink");
    fs.mkdirSync(dir, { recursive: true });
    fs.appendFileSync(path.join(dir, "integration-friction.jsonl"), JSON.stringify(entry) + "\\n");
  } catch { /* 記録失敗は無視 (学習はベストエフォート) */ }
  return Response.json({ ok: true });
}
'''
    open(route_path, "w", encoding="utf-8").write(route)

def server_block(stage, note, err_expr, indent):
    """サーバー側 (route handler) 用: node:fs で直接 JSONL 追記する catch 内ブロック"""
    pad = " " * indent
    return (
        pad + "// 連携の詰まり(friction)を学習ループへ記録 — ill_record_friction 連携 (PFP-118 / 失敗しても本処理に影響しない)\n"
        + pad + "try {\n"
        + pad + '  const __fs = await import("node:fs");\n'
        + pad + '  __fs.mkdirSync(".soloptilink", { recursive: true });\n'
        + pad + '  __fs.appendFileSync(".soloptilink/integration-friction.jsonl",\n'
        + pad + f'    JSON.stringify({{ ts: new Date().toISOString(), connector: "{conn}", stage: "{stage}", note: "{note}", error: {err_expr} }}) + "\\n");\n'
        + pad + "} catch { /* 記録失敗は無視 */ }\n"
    )

def inject(path, anchor, block):
    """anchor 直後にブロックを冪等注入する (マーカー存在時/アンカー不在時は何もしない)"""
    if not os.path.exists(path):
        return False
    src = open(path, encoding="utf-8").read()
    if MARK in src or anchor not in src:
        return False
    open(path, "w", encoding="utf-8").write(src.replace(anchor, anchor + block, 1))
    return True

injected = []

# --- 2. 接続テスト route の catch パス (サーバー側) ---
test_route = os.path.join(proj, "app", "api", "integrations", conn, "test", "route.ts")
if inject(test_route, "  } catch (e) {\n",
          server_block("test", "接続テスト失敗", "String((e as Error).message ?? e)", 4)):
    injected.append("test/route.ts")

# --- 3. Webhook route の署名検証失敗パス (サーバー側) ---
wh_route = os.path.join(proj, "app", "api", "integrations", conn, "webhook", "route.ts")
if inject(wh_route, "  if (!verifyWebhook(rawBody, req.headers)) {\n",
          server_block("webhook", "Webhook署名検証失敗", '""', 4)):
    injected.append("webhook/route.ts")

# --- 4. 設定画面 (client component) の接続テスト catch パス → API route 経由で記録 ---
ui_page = os.path.join(proj, "app", "(dashboard)", "settings", "integrations", conn, "page.tsx")
client_block = (
    "      // 連携の詰まりを学習ループへ記録 — API route 経由の軽量記録 / ill_record_friction 連携 (PFP-118)\n"
    + '      void fetch("/api/integrations/friction", { method: "POST", headers: { "Content-Type": "application/json" }, '
    + f'body: JSON.stringify({{ connector: "{conn}", stage: "test_ui", note: "設定画面の接続テストに失敗" }}) }}).catch(() => {{}});\n'
)
if inject(ui_page, "    } catch {\n", client_block):
    injected.append("settings/page.tsx")

if injected:
    print(f"  friction記録テンプレ注入 (PFP-118): {', '.join(injected)} + friction API route")
PY
    return 0
}

cf_report() {
    echo -e "\n  ${BOLD:-}=== Connector Forge v${CF_VERSION} ===${NC:-}"
    echo -e "  生成実行回数     : ${CF_FORGE_COUNT}"
    echo -e "  直近のコネクタ   : ${CF_LAST_CONNECTOR:-なし}"
}

cf_score() {
    local score=40
    [[ "$CF_INITIALIZED" == "true" ]] && score=$((score + 20))
    [[ -f "$CF_FORGE_PY" ]] && score=$((score + 20))
    [[ $CF_FORGE_COUNT -gt 0 ]] && score=$((score + 20))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# Module Registry Self-Registration
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "connector-forge" \
        --version "1.0" \
        --description "自然言語の連携依頼からOAuth/API/Webhookを一発配線(IBL駆動)" \
        --init "cf_init" \
        --report "cf_report" \
        --score "cf_score" \
        --enable-var "ENABLE_CONNECTOR_FORGE" \
        --cli-flags "--connector-forge:--no-connector-forge"
fi

# CLI ディスパッチ (管理者検証/直接利用)
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    cf_init
    case "${1:-help}" in
        forge)     cf_forge "${2:-}" "${3:-$PWD}" ;;
        connector) cf_forge_connector "${2:-}" "${3:-$PWD}" ;;
        draft)     cf_draft "${2:-}" "${3:-}" "${4:-other}" "${5:-$PWD}" ;;
        report)    cf_report ;;
        score)     cf_score ;;
        *)         echo "usage: connector-forge.sh {forge \"<自然言語>\" <dir> | connector <name> <dir> | report | score}" ;;
    esac
fi

true
