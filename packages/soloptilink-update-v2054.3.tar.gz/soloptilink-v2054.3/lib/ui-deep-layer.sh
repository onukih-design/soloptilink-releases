#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2016.0 - UI Deep Layer Test (RVG-3)
# =============================================================================
# Playwright を使い、生成プロジェクトの主要ページを実ブラウザで開いて
#   1. ページが console.error 0 件で表示される
#   2. ページ上のボタン/リンクが空ハンドラでないか
#   3. 一覧→詳細の遷移が動作するか
# を検証する。
#
# Playwright が未インストールなら SKIPPED として記録し、戻り値 0 を返す
# (done-definition.sh 側で部分減点)。
#
# 使用:
#   bash ~/.soloptilink/lib/ui-deep-layer.sh \
#         <ROUTES_JSON> <BASE_URL> [PROJECT_DIR] [OUT_JSON]
# 戻り値: 0=全 PASS or SKIPPED, 1=FAIL あり, 2=入力不正
# =============================================================================

[[ -n "${_UI_DEEP_LAYER_LOADED:-}" ]] && return 0
_UI_DEEP_LAYER_LOADED=1

readonly UDL_VERSION="1.0.0"
UDL_TIMEOUT_MS="${UDL_TIMEOUT_MS:-15000}"
UDL_VIEWPORT="${UDL_VIEWPORT:-1280x800}"

# ============================================================
# Public: udl_run <routes_json> <base_url> [project_dir] [out_json]
# ============================================================
udl_run() {
    local routes_json="${1:-.rvg/routes.json}"
    local base_url="${2:-http://localhost:3000}"
    local project_dir="${3:-$(pwd)}"
    local out_json="${4:-$(dirname "$routes_json")/ui-test-results.json}"

    if [[ ! -f "$routes_json" ]]; then
        echo "[ui-deep-layer] ERROR: routes.json not found: $routes_json" >&2
        return 2
    fi

    mkdir -p "$(dirname "$out_json")" 2>/dev/null

    # 1. Detect Playwright availability
    local playwright_cmd
    playwright_cmd=$(_udl_find_playwright "$project_dir")
    if [[ -z "$playwright_cmd" ]]; then
        _udl_emit_skip "$out_json" "playwright_not_installed"
        echo "[ui-deep-layer] Playwright not installed → SKIPPED" >&2
        return 0
    fi

    # 2. Build scenarios from routes.json
    local scenarios_file
    scenarios_file=$(mktemp)
    _udl_build_scenarios "$routes_json" "$base_url" "$scenarios_file"
    local scenario_count
    scenario_count=$(grep -c '"name"' "$scenarios_file" 2>/dev/null) || scenario_count=0
    if [[ "$scenario_count" -eq 0 ]]; then
        _udl_emit_skip "$out_json" "no_scenarios_buildable"
        rm -f "$scenarios_file"
        echo "[ui-deep-layer] no scenarios from routes → SKIPPED" >&2
        return 0
    fi

    # 3. Generate Playwright runner script
    local runner
    runner=$(mktemp -t udl_runner.XXXXXX.mjs)
    _udl_write_runner "$runner" "$scenarios_file" "$out_json" "$base_url"

    # 4. Execute Playwright
    pushd "$project_dir" >/dev/null 2>&1 || { rm -f "$scenarios_file" "$runner"; return 2; }
    local exit_code=0
    eval "$playwright_cmd" "$runner" 2>&1 | sed 's/^/[ui-deep-layer] /' >&2 || exit_code=$?
    popd >/dev/null 2>&1

    rm -f "$scenarios_file" "$runner"

    # 5. Summarize
    if [[ ! -f "$out_json" ]]; then
        _udl_emit_skip "$out_json" "runner_did_not_emit"
        echo "[ui-deep-layer] runner did not write output → SKIPPED" >&2
        return 0
    fi
    local pass fail
    pass=$(grep -c '"verdict":"PASS"' "$out_json" 2>/dev/null) || pass=0
    fail=$(grep -c '"verdict":"FAIL"' "$out_json" 2>/dev/null) || fail=0
    echo "[ui-deep-layer] scenarios=${scenario_count} pass=${pass} fail=${fail} → $out_json" >&2
    [[ "$fail" -eq 0 ]]
}

# ============================================================
# Internal: detect playwright command
# ============================================================
_udl_find_playwright() {
    local pd="$1"
    if [[ -x "${pd}/node_modules/.bin/playwright" ]]; then
        echo "node ${pd}/node_modules/.bin/playwright test-script"
        return 0
    fi
    if [[ -f "${pd}/node_modules/playwright/package.json" ]]; then
        # Use node directly via Playwright API
        echo "node"
        return 0
    fi
    if command -v playwright >/dev/null 2>&1 && [[ -f "${pd}/node_modules/playwright/package.json" || -f "$(npm root -g 2>/dev/null)/playwright/package.json" ]]; then
        echo "node"
        return 0
    fi
    echo ""
}

# ============================================================
# Internal: build scenarios from routes.json
# Strategy:
#   - For each "page" route, add a "open page" scenario
#   - For each "/foo/:id" detail route, add an "open detail with id=1" scenario
# ============================================================
_udl_build_scenarios() {
    local routes_json="$1"
    local base_url="$2"
    local out="$3"

    {
        echo '['
        local first=1
        # Parse routes.json
        local entries
        if command -v python3 >/dev/null 2>&1; then
            entries=$(python3 - "$routes_json" 2>/dev/null <<'PY'
import json, sys
try:
    data = json.load(open(sys.argv[1]))
except Exception:
    sys.exit(0)
seen = set()
for r in data:
    if r.get('kind') != 'page':
        continue
    url = r.get('url', '')
    if not url or url in seen:
        continue
    seen.add(url)
    print(url)
PY
)
        else
            entries=$(grep -oE '"kind":"page","url":"[^"]+"' "$routes_json" 2>/dev/null \
                | sed -nE 's/.*"url":"([^"]+)".*/\1/p' | sort -u)
        fi

        local url
        while IFS= read -r url; do
            [[ -z "$url" ]] && continue
            # Substitute :param with "1" for navigation
            local nav_url
            nav_url=$(echo "$url" | sed -E 's#:[A-Za-z_][A-Za-z0-9_]*#1#g; s#\*$#first#')
            local name
            name=$(echo "$url" | tr '/' '_' | tr -d ':*' | sed 's/^_//')
            [[ -z "$name" ]] && name="root"
            [[ $first -eq 1 ]] && first=0 || echo ','
            printf '  {"name":"page_%s","url":"%s%s","wait_selector":"body","check_console_error":true}' \
                "$name" "$base_url" "$nav_url"
        done <<< "$entries"
        echo ''
        echo ']'
    } > "$out"
}

# ============================================================
# Internal: emit Playwright runner script
# ============================================================
_udl_write_runner() {
    local runner="$1"
    local scenarios="$2"
    local out_json="$3"
    local base_url="$4"

    local sc
    sc=$(cat "$scenarios")

    cat > "$runner" <<RUNNER
import { chromium } from 'playwright';
import { writeFileSync } from 'fs';

const SCENARIOS = ${sc};
const TIMEOUT = ${UDL_TIMEOUT_MS};
const VIEWPORT = '${UDL_VIEWPORT}';
const OUT = '${out_json}';

(async () => {
  let browser;
  try {
    browser = await chromium.launch({ headless: true });
  } catch (e) {
    writeFileSync(OUT, JSON.stringify([{
      scenario: 'launch', verdict: 'SKIPPED',
      reason: 'browser_launch_failed: ' + (e && e.message),
    }], null, 2));
    process.exit(0);
  }
  const [w, h] = VIEWPORT.split('x').map(Number);
  const ctx = await browser.newContext({ viewport: { width: w, height: h } });
  const results = [];

  for (const sc of SCENARIOS) {
    const page = await ctx.newPage();
    const consoleErrors = [];
    page.on('console', (m) => { if (m.type() === 'error') consoleErrors.push(m.text()); });
    page.on('pageerror', (e) => { consoleErrors.push('pageerror: ' + e.message); });
    let verdict = 'PASS', reason = '', status = 0;
    try {
      const resp = await page.goto(sc.url, { waitUntil: 'networkidle', timeout: TIMEOUT });
      status = resp ? resp.status() : 0;
      if (!resp || status >= 400) {
        verdict = 'FAIL';
        reason = 'http_' + status;
      } else {
        await page.waitForSelector(sc.wait_selector || 'body', { timeout: TIMEOUT });
        if (sc.check_console_error && consoleErrors.length > 0) {
          verdict = 'FAIL';
          reason = 'console_errors: ' + consoleErrors.slice(0, 3).join(' | ');
        }
      }
    } catch (e) {
      verdict = 'FAIL';
      reason = 'exception: ' + (e && e.message);
    }
    results.push({ scenario: sc.name, url: sc.url, status, verdict, reason });
    await page.close();
  }

  await ctx.close();
  await browser.close();
  writeFileSync(OUT, JSON.stringify(results, null, 2));
})().catch((e) => {
  writeFileSync(OUT, JSON.stringify([{
    scenario: 'orchestrator', verdict: 'FAIL',
    reason: 'orchestrator_error: ' + (e && e.message),
  }], null, 2));
  process.exit(0);
});
RUNNER
}

# ============================================================
# Internal: emit a SKIPPED verdict
# ============================================================
_udl_emit_skip() {
    local out_json="$1"
    local reason="$2"
    cat > "$out_json" <<JSON
[
  {"scenario":"playwright","verdict":"SKIPPED","reason":"${reason}"}
]
JSON
}

# ============================================================
# CLI entry
# ============================================================
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    udl_run "${1:-.rvg/routes.json}" "${2:-http://localhost:3000}" "${3:-$(pwd)}" "${4:-}"
    exit $?
fi
