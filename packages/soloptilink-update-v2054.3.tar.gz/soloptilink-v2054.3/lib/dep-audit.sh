#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v11.0 - Dependency Security Audit Module
# =============================================================================
# Scans project dependencies for known vulnerabilities, outdated packages,
# license compliance issues, and supply chain risks.
# Usage: source lib/dep-audit.sh
# =============================================================================

DA_GREEN='\033[0;32m'  DA_YELLOW='\033[0;33m'  DA_RED='\033[0;31m'
DA_CYAN='\033[0;36m'   DA_BOLD='\033[1m'        DA_PURPLE='\033[0;35m'
DA_NC='\033[0m'

DA_CRITICAL=0; DA_HIGH=0; DA_MEDIUM=0; DA_LOW=0; DA_INFO=0
DA_OUTDATED=0; DA_LICENSE_ISSUES=0; DA_RESULTS=""
DA_PROJECT_TYPE=""

# --- Helpers ----------------------------------------------------------------
_dau_log() {
    local level="$1" msg="$2" ts; ts="$(date '+%H:%M:%S')"
    case "$level" in
        PASS) printf "${DA_GREEN}[AUDIT PASS %s]${DA_NC} %s\n" "$ts" "$msg" ;;
        FAIL) printf "${DA_RED}[AUDIT FAIL %s]${DA_NC} %s\n"   "$ts" "$msg" ;;
        WARN) printf "${DA_YELLOW}[AUDIT WARN %s]${DA_NC} %s\n" "$ts" "$msg" ;;
        INFO) printf "${DA_CYAN}[AUDIT INFO %s]${DA_NC} %s\n"   "$ts" "$msg" ;;
        CRIT) printf "${DA_RED}${DA_BOLD}[AUDIT CRIT %s]${DA_NC} %s\n" "$ts" "$msg" ;;
        *)    printf "[AUDIT %s] %s\n" "$ts" "$msg" ;;
    esac
    DA_RESULTS+="${level}: ${msg}\n"
}

# === 1. dep_audit_init(project_dir) =========================================
dep_audit_init() {
    # v2034.7-fix(SLB-005): chain-utils.sh:1339 calls dep_audit_init arg-less
    # (no project dir exists yet at subsystem-init time). Under chain.sh
    # `set -u`, a bare "$1" aborts the whole shell — and `2>/dev/null || true`
    # at the call site cannot catch a set -u shell-exit. Default to empty so
    # the -z guard below no-ops cleanly and returns 1 gracefully.
    local pd="${1:-}"
    [[ -z "$pd" || ! -d "$pd" ]] && { _dau_log FAIL "Invalid project dir: ${pd}"; return 1; }
    DA_CRITICAL=0; DA_HIGH=0; DA_MEDIUM=0; DA_LOW=0; DA_INFO=0
    DA_OUTDATED=0; DA_LICENSE_ISSUES=0; DA_RESULTS=""
    DA_PROJECT_TYPE=""

    if [[ -f "${pd}/package.json" ]]; then
        DA_PROJECT_TYPE="node"
    elif [[ -f "${pd}/requirements.txt" || -f "${pd}/pyproject.toml" ]]; then
        DA_PROJECT_TYPE="python"
    elif [[ -f "${pd}/Cargo.toml" ]]; then
        DA_PROJECT_TYPE="rust"
    elif [[ -f "${pd}/go.mod" ]]; then
        DA_PROJECT_TYPE="go"
    fi
    _dau_log INFO "Dependency audit init: ${pd} (type: ${DA_PROJECT_TYPE:-unknown})"
}

# === 2. dep_audit_vulnerabilities(project_dir) ==============================
dep_audit_vulnerabilities() {
    local pd="$1"
    _dau_log INFO "Scanning for known vulnerabilities..."

    case "$DA_PROJECT_TYPE" in
        node)
            if [[ -f "${pd}/package-lock.json" || -f "${pd}/yarn.lock" ]] && command -v npm &>/dev/null; then
                local audit_out; audit_out=$(cd "$pd" && npm audit --json 2>/dev/null) || true
                if [[ -n "$audit_out" ]] && command -v python3 &>/dev/null; then
                    local counts; counts=$(python3 -c "
import json, sys
try:
    d = json.loads(sys.stdin.read())
    v = d.get('metadata', {}).get('vulnerabilities', {})
    c = v.get('critical', 0); h = v.get('high', 0)
    m = v.get('moderate', 0); l = v.get('low', 0); i = v.get('info', 0)
    print(f'{c}|{h}|{m}|{l}|{i}')
except: print('0|0|0|0|0')
" <<< "$audit_out" 2>/dev/null)
                    IFS='|' read -r c h m l i <<< "$counts"
                    DA_CRITICAL=$((DA_CRITICAL + ${c:-0}))
                    DA_HIGH=$((DA_HIGH + ${h:-0}))
                    DA_MEDIUM=$((DA_MEDIUM + ${m:-0}))
                    DA_LOW=$((DA_LOW + ${l:-0}))
                    DA_INFO=$((DA_INFO + ${i:-0}))
                    local total=$(( ${c:-0} + ${h:-0} + ${m:-0} + ${l:-0} ))
                    if [[ "$total" -eq 0 ]]; then
                        _dau_log PASS "npm audit: No vulnerabilities found"
                    else
                        [[ "${c:-0}" -gt 0 ]] && _dau_log CRIT "npm audit: ${c} critical vulnerabilities"
                        [[ "${h:-0}" -gt 0 ]] && _dau_log FAIL "npm audit: ${h} high vulnerabilities"
                        [[ "${m:-0}" -gt 0 ]] && _dau_log WARN "npm audit: ${m} moderate vulnerabilities"
                        [[ "${l:-0}" -gt 0 ]] && _dau_log INFO "npm audit: ${l} low vulnerabilities"
                    fi
                else
                    _dau_log WARN "npm audit ran but could not parse results"
                fi
            else
                _dau_log WARN "No lockfile found - skipping npm audit"
            fi
            ;;
        python)
            if command -v pip-audit &>/dev/null; then
                local audit_out; audit_out=$(cd "$pd" && pip-audit -r requirements.txt --format json 2>/dev/null) || true
                if [[ -n "$audit_out" ]] && command -v python3 &>/dev/null; then
                    local vuln_count; vuln_count=$(python3 -c "
import json, sys
try:
    d = json.loads(sys.stdin.read())
    print(len(d.get('dependencies', []) if isinstance(d, dict) else d))
except: print('0')
" <<< "$audit_out" 2>/dev/null)
                    if [[ "${vuln_count:-0}" -gt 0 ]]; then
                        DA_HIGH=$((DA_HIGH + ${vuln_count:-0}))
                        _dau_log FAIL "pip-audit: ${vuln_count} vulnerable packages"
                    else
                        _dau_log PASS "pip-audit: No vulnerabilities found"
                    fi
                fi
            elif command -v safety &>/dev/null; then
                local out; out=$(cd "$pd" && safety check -r requirements.txt --short-report 2>/dev/null) || true
                if echo "$out" | grep -qi "found"; then
                    local cnt; cnt=$(echo "$out" | grep -oE '[0-9]+' | head -1)
                    DA_HIGH=$((DA_HIGH + ${cnt:-1}))
                    _dau_log FAIL "safety: ${cnt:-?} vulnerabilities found"
                else
                    _dau_log PASS "safety: No vulnerabilities found"
                fi
            else
                _dau_log WARN "No Python audit tool (pip-audit/safety) installed"
                # Fallback: check known dangerous packages
                if [[ -f "${pd}/requirements.txt" ]]; then
                    local dangerous=("requests<2.20" "django<3.2" "flask<2.0" "pyyaml<5.4" "urllib3<1.26")
                    while IFS= read -r line; do
                        [[ -z "$line" || "$line" == \#* ]] && continue
                        local pkg; pkg=$(echo "$line" | tr -d ' ' | cut -d'=' -f1 | cut -d'<' -f1 | cut -d'>' -f1)
                        for d in "${dangerous[@]}"; do
                            local dpkg; dpkg=$(echo "$d" | cut -d'<' -f1)
                            if [[ "$pkg" == "$dpkg" ]]; then
                                _dau_log WARN "Potentially outdated: ${line} (check for updates)"
                            fi
                        done
                    done < "${pd}/requirements.txt"
                fi
            fi
            ;;
        rust)
            if command -v cargo-audit &>/dev/null; then
                local out; out=$(cd "$pd" && cargo audit 2>/dev/null) || true
                local cnt; cnt=$(echo "$out" | grep -c "^error" 2>/dev/null || echo 0)
                if [[ "${cnt:-0}" -gt 0 ]]; then
                    DA_HIGH=$((DA_HIGH + cnt))
                    _dau_log FAIL "cargo-audit: ${cnt} vulnerabilities"
                else
                    _dau_log PASS "cargo-audit: No vulnerabilities"
                fi
            fi
            ;;
        go)
            if command -v govulncheck &>/dev/null; then
                local out; out=$(cd "$pd" && govulncheck ./... 2>/dev/null) || true
                local cnt; cnt=$(echo "$out" | grep -c "Vulnerability" 2>/dev/null || echo 0)
                if [[ "${cnt:-0}" -gt 0 ]]; then
                    DA_HIGH=$((DA_HIGH + cnt))
                    _dau_log FAIL "govulncheck: ${cnt} vulnerabilities"
                else
                    _dau_log PASS "govulncheck: No vulnerabilities"
                fi
            fi
            ;;
        *)
            _dau_log INFO "No vulnerability scanner for project type: ${DA_PROJECT_TYPE:-unknown}"
            ;;
    esac
}

# === 3. dep_audit_outdated(project_dir) =====================================
dep_audit_outdated() {
    local pd="$1"
    _dau_log INFO "Checking for outdated dependencies..."

    case "$DA_PROJECT_TYPE" in
        node)
            if command -v npm &>/dev/null && [[ -f "${pd}/package.json" ]]; then
                local out; out=$(cd "$pd" && npm outdated --json 2>/dev/null) || true
                if [[ -n "$out" && "$out" != "{}" ]] && command -v python3 &>/dev/null; then
                    local counts; counts=$(python3 -c "
import json, sys
try:
    d = json.loads(sys.stdin.read())
    major = sum(1 for v in d.values() if v.get('current','') != v.get('latest',''))
    print(major)
except: print('0')
" <<< "$out" 2>/dev/null)
                    DA_OUTDATED=$((DA_OUTDATED + ${counts:-0}))
                    if [[ "${counts:-0}" -gt 0 ]]; then
                        _dau_log WARN "npm outdated: ${counts} packages need updates"
                    else
                        _dau_log PASS "All npm packages up to date"
                    fi
                else
                    _dau_log PASS "All npm packages up to date"
                fi
            fi
            ;;
        python)
            if command -v pip &>/dev/null && [[ -f "${pd}/requirements.txt" ]]; then
                local out; out=$(cd "$pd" && pip list --outdated --format=json 2>/dev/null) || true
                if [[ -n "$out" ]] && command -v python3 &>/dev/null; then
                    local cnt; cnt=$(python3 -c "import json,sys; print(len(json.loads(sys.stdin.read())))" <<< "$out" 2>/dev/null || echo 0)
                    DA_OUTDATED=$((DA_OUTDATED + ${cnt:-0}))
                    [[ "${cnt:-0}" -gt 0 ]] && _dau_log WARN "pip outdated: ${cnt} packages" \
                        || _dau_log PASS "All pip packages up to date"
                fi
            fi
            ;;
    esac
}

# === 4. dep_audit_licenses(project_dir) =====================================
dep_audit_licenses() {
    local pd="$1"
    _dau_log INFO "Checking license compliance..."

    local copyleft_licenses=("GPL" "AGPL" "LGPL" "SSPL" "EUPL" "OSL" "RPL")

    case "$DA_PROJECT_TYPE" in
        node)
            if command -v npx &>/dev/null && [[ -f "${pd}/package.json" ]]; then
                # Check for license-checker
                local out; out=$(cd "$pd" && npx license-checker --json --production 2>/dev/null) || true
                if [[ -n "$out" ]] && command -v python3 &>/dev/null; then
                    local issues; issues=$(python3 -c "
import json, sys
try:
    d = json.loads(sys.stdin.read())
    copyleft = ['GPL', 'AGPL', 'LGPL', 'SSPL', 'EUPL', 'OSL', 'RPL']
    issues = []
    for pkg, info in d.items():
        lic = str(info.get('licenses', 'UNKNOWN'))
        for cl in copyleft:
            if cl in lic.upper():
                issues.append(f'{pkg}: {lic}')
                break
        if lic == 'UNKNOWN':
            issues.append(f'{pkg}: UNKNOWN license')
    print(len(issues))
    for i in issues[:10]:
        print(i)
except: print('0')
" <<< "$out" 2>/dev/null)
                    local cnt; cnt=$(echo "$issues" | head -1)
                    if [[ "${cnt:-0}" -gt 0 ]]; then
                        DA_LICENSE_ISSUES=$((DA_LICENSE_ISSUES + ${cnt:-0}))
                        _dau_log WARN "License concerns: ${cnt} packages"
                        echo "$issues" | tail -n +2 | head -5 | while IFS= read -r l; do
                            [[ -n "$l" ]] && _dau_log INFO "  ${l}"
                        done
                    else
                        _dau_log PASS "No license compliance issues"
                    fi
                fi
            fi
            ;;
        *)
            _dau_log INFO "License check not implemented for ${DA_PROJECT_TYPE:-unknown}"
            ;;
    esac
}

# === 5. dep_audit_supply_chain(project_dir) =================================
dep_audit_supply_chain() {
    local pd="$1"
    _dau_log INFO "Checking supply chain risks..."

    # Check for lockfile
    case "$DA_PROJECT_TYPE" in
        node)
            if [[ ! -f "${pd}/package-lock.json" && ! -f "${pd}/yarn.lock" && ! -f "${pd}/pnpm-lock.yaml" ]]; then
                _dau_log FAIL "No lockfile found - supply chain risk"
                DA_HIGH=$((DA_HIGH + 1))
            else
                _dau_log PASS "Lockfile present"
            fi
            # Check for install scripts
            if [[ -f "${pd}/package.json" ]] && grep -qE '"(preinstall|postinstall|prepare)":' "${pd}/package.json" 2>/dev/null; then
                _dau_log WARN "Install hooks detected in package.json - review for safety"
            fi
            # Check .npmrc for registry overrides
            if [[ -f "${pd}/.npmrc" ]] && grep -qE 'registry=' "${pd}/.npmrc" 2>/dev/null; then
                _dau_log WARN "Custom npm registry configured in .npmrc"
            fi
            ;;
        python)
            if [[ ! -f "${pd}/requirements.txt" ]] && [[ ! -f "${pd}/pyproject.toml" ]]; then
                _dau_log WARN "No requirements file found"
            fi
            # Check for pinned versions
            if [[ -f "${pd}/requirements.txt" ]]; then
                local unpinned=0
                while IFS= read -r line; do
                    [[ -z "$line" || "$line" == \#* || "$line" == -* ]] && continue
                    if ! echo "$line" | grep -qE '==|>=.*,<='; then
                        unpinned=$((unpinned + 1))
                    fi
                done < "${pd}/requirements.txt"
                if [[ "$unpinned" -gt 0 ]]; then
                    _dau_log WARN "${unpinned} unpinned dependencies in requirements.txt"
                else
                    _dau_log PASS "All Python dependencies are pinned"
                fi
            fi
            ;;
    esac

    # Check for .env files that shouldn't be committed
    if [[ -f "${pd}/.env" ]]; then
        if [[ -f "${pd}/.gitignore" ]] && grep -q '\.env' "${pd}/.gitignore" 2>/dev/null; then
            _dau_log PASS ".env properly in .gitignore"
        else
            _dau_log FAIL ".env file present but NOT in .gitignore - secret exposure risk"
            DA_CRITICAL=$((DA_CRITICAL + 1))
        fi
    fi

    # Check for hardcoded secrets in common config files
    local config_files=("${pd}/.env.example" "${pd}/config.js" "${pd}/config.ts" "${pd}/settings.py")
    for cf in "${config_files[@]}"; do
        [[ ! -f "$cf" ]] && continue
        if grep -qEi '(api_key|secret|password|token)\s*[:=]\s*["\x27][A-Za-z0-9]{20,}' "$cf" 2>/dev/null; then
            _dau_log FAIL "Possible hardcoded secret in $(basename "$cf")"
            DA_HIGH=$((DA_HIGH + 1))
        fi
    done
}

# === 6. dep_audit_run_all(project_dir) ======================================
dep_audit_run_all() {
    local pd="$1"
    dep_audit_init "$pd" || return 1

    printf "\n${DA_BOLD}${DA_PURPLE}"
    printf '=%.0s' {1..60}; echo
    printf "  SoloptiLink Chain v11.0 - Dependency Security Audit\n"
    printf '=%.0s' {1..60}
    printf "${DA_NC}\n\n"

    _dau_log INFO "Starting comprehensive dependency audit..."

    printf "\n${DA_BOLD}--- Phase 1: Vulnerability Scan ---${DA_NC}\n"
    dep_audit_vulnerabilities "$pd"

    printf "\n${DA_BOLD}--- Phase 2: Outdated Packages ---${DA_NC}\n"
    dep_audit_outdated "$pd"

    printf "\n${DA_BOLD}--- Phase 3: License Compliance ---${DA_NC}\n"
    dep_audit_licenses "$pd"

    printf "\n${DA_BOLD}--- Phase 4: Supply Chain Risks ---${DA_NC}\n"
    dep_audit_supply_chain "$pd"

    printf "\n${DA_BOLD}--- Audit Report ---${DA_NC}\n"
    dep_audit_report "$pd"

    local total_issues=$((DA_CRITICAL + DA_HIGH + DA_MEDIUM))
    (( total_issues == 0 ))
}

# === 7. dep_audit_report(project_dir) =======================================
dep_audit_report() {
    local pd="${1:-.}"
    local report_file="${pd}/docs/chain-logs/dep-audit-$(date '+%Y%m%d-%H%M%S').txt"
    mkdir -p "$(dirname "$report_file")" 2>/dev/null || true

    local total=$((DA_CRITICAL + DA_HIGH + DA_MEDIUM + DA_LOW + DA_INFO))
    local score=100
    score=$((score - DA_CRITICAL * 25 - DA_HIGH * 10 - DA_MEDIUM * 3 - DA_LOW * 1))
    [[ "$score" -lt 0 ]] && score=0

    {
        printf '=%.0s' {1..60}; echo
        printf "SoloptiLink Chain v11.0 - Dependency Audit Report\n"
        printf "Generated: %s\nProject: %s\nType: %s\n" "$(date '+%Y-%m-%d %H:%M:%S')" "$pd" "${DA_PROJECT_TYPE:-unknown}"
        printf '=%.0s' {1..60}; echo; echo
        printf "SUMMARY\n"
        printf '%.0s-' {1..40}; echo
        printf "  Critical:  %d\n  High:      %d\n  Medium:    %d\n  Low:       %d\n  Info:      %d\n" \
            "$DA_CRITICAL" "$DA_HIGH" "$DA_MEDIUM" "$DA_LOW" "$DA_INFO"
        printf "  Outdated:  %d\n  License:   %d\n" "$DA_OUTDATED" "$DA_LICENSE_ISSUES"
        printf "\n  Security Score: %d/100\n" "$score"
        echo; printf "DETAILS\n"
        printf '%.0s-' {1..40}; echo
        printf '%b' "$DA_RESULTS"
        echo; printf '=%.0s' {1..60}; echo
    } > "$report_file"

    echo
    printf "${DA_BOLD}+----------------------------------------------+${DA_NC}\n"
    printf "${DA_BOLD}|      Dependency Audit Report (v11.0)          |${DA_NC}\n"
    printf "${DA_BOLD}+----------------------------------------------+${DA_NC}\n"
    printf "${DA_BOLD}|${DA_NC}  ${DA_RED}CRITICAL:${DA_NC}  %-32d${DA_BOLD}|${DA_NC}\n" "$DA_CRITICAL"
    printf "${DA_BOLD}|${DA_NC}  ${DA_RED}HIGH:${DA_NC}      %-32d${DA_BOLD}|${DA_NC}\n" "$DA_HIGH"
    printf "${DA_BOLD}|${DA_NC}  ${DA_YELLOW}MEDIUM:${DA_NC}    %-32d${DA_BOLD}|${DA_NC}\n" "$DA_MEDIUM"
    printf "${DA_BOLD}|${DA_NC}  ${DA_CYAN}LOW:${DA_NC}       %-32d${DA_BOLD}|${DA_NC}\n" "$DA_LOW"
    printf "${DA_BOLD}|${DA_NC}  ${DA_CYAN}OUTDATED:${DA_NC}  %-32d${DA_BOLD}|${DA_NC}\n" "$DA_OUTDATED"
    printf "${DA_BOLD}|${DA_NC}  ${DA_PURPLE}LICENSE:${DA_NC}   %-32d${DA_BOLD}|${DA_NC}\n" "$DA_LICENSE_ISSUES"
    printf "${DA_BOLD}+----------------------------------------------+${DA_NC}\n"

    local score_color="$DA_GREEN"
    [[ "$score" -lt 80 ]] && score_color="$DA_YELLOW"
    [[ "$score" -lt 50 ]] && score_color="$DA_RED"
    printf "  ${DA_BOLD}Security Score: ${score_color}%d/100${DA_NC}\n\n" "$score"

    if (( DA_CRITICAL > 0 )); then
        printf "  ${DA_RED}${DA_BOLD}AUDIT FAILED${DA_NC} - Critical vulnerabilities require immediate action\n"
    elif (( DA_HIGH > 0 )); then
        printf "  ${DA_YELLOW}${DA_BOLD}AUDIT WARNING${DA_NC} - High-severity issues should be resolved\n"
    elif (( DA_MEDIUM > 0 )); then
        printf "  ${DA_YELLOW}AUDIT PASSED WITH WARNINGS${DA_NC}\n"
    else
        printf "  ${DA_GREEN}${DA_BOLD}AUDIT PASSED${DA_NC} - All clear\n"
    fi
    _dau_log INFO "Report saved: ${report_file}"
}

# === 8. dep_audit_auto_fix(project_dir) =====================================
dep_audit_auto_fix() {
    local pd="$1"
    _dau_log INFO "Attempting auto-fix for vulnerabilities..."

    case "$DA_PROJECT_TYPE" in
        node)
            if command -v npm &>/dev/null; then
                local out; out=$(cd "$pd" && npm audit fix 2>&1) || true
                if echo "$out" | grep -q "fixed"; then
                    _dau_log PASS "npm audit fix: $(echo "$out" | grep -oE 'fixed [0-9]+' | head -1)"
                else
                    _dau_log WARN "npm audit fix: No automatic fixes available"
                    _dau_log INFO "Try: npm audit fix --force (may have breaking changes)"
                fi
            fi
            ;;
        python)
            _dau_log INFO "Python auto-fix: Update requirements.txt manually or use pip-compile"
            ;;
        *)
            _dau_log INFO "Auto-fix not supported for ${DA_PROJECT_TYPE:-unknown}"
            ;;
    esac
}

# === 9. dep_audit_export_json(output_path) ==================================
dep_audit_export_json() {
    local output="${1:-dep-audit-results.json}"
    command -v python3 &>/dev/null || { _dau_log WARN "python3 needed for JSON export"; return 1; }
    python3 -c "
import json
data = {
    'version': '11.0',
    'timestamp': '$(date -u +%Y-%m-%dT%H:%M:%SZ)',
    'project_type': '${DA_PROJECT_TYPE}',
    'vulnerabilities': {
        'critical': ${DA_CRITICAL}, 'high': ${DA_HIGH},
        'medium': ${DA_MEDIUM}, 'low': ${DA_LOW}, 'info': ${DA_INFO}
    },
    'outdated': ${DA_OUTDATED},
    'license_issues': ${DA_LICENSE_ISSUES},
    'score': max(0, 100 - ${DA_CRITICAL}*25 - ${DA_HIGH}*10 - ${DA_MEDIUM}*3 - ${DA_LOW})
}
with open('${output}', 'w') as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
print(f'Exported to ${output}')
" 2>/dev/null
}
