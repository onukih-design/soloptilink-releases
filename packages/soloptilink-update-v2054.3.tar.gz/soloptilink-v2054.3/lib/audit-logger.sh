#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v17.0 - Audit Logger Module
# =============================================================================
# 基幹システムで必須の「誰が・いつ・何を・どう変更したか」の監査ログを、
# 生成されるアプリケーションに自動的に組み込むプロンプトとテンプレートを提供する。
#
# 機能:
#   1. 監査ログテーブル/コレクションのスキーマ生成（PostgreSQL/MySQL/MongoDB/SQLite）
#   2. Express/Fastify/Hono用の監査ミドルウェアコード生成
#   3. Prisma middleware/extensionでの全DB操作自動フック
#   4. 監査ログ検索用ヘルパー関数生成
#   5. Claude CLIプロンプトへの監査ログ要件自動注入
#   6. 監査ログ実装カバレッジの検証・レポート生成
#
# Usage: source lib/audit-logger.sh
# =============================================================================

[[ -n "${_AUDIT_LOGGER_LOADED:-}" ]] && return 0
_AUDIT_LOGGER_LOADED=1

# --- グローバル状態 ---
AL_ENABLED=true
AL_VERSION="17.0"
AL_LOG_LEVEL="info"            # debug/info/warn/error
AL_RETENTION_DAYS=365
AL_INCLUDE_BEFORE_AFTER=true
AL_PROJECT_DIR=""
AL_PROJECT_TYPE="unknown"
AL_DB_TYPE="unknown"
AL_FRAMEWORK="unknown"

# カバレッジカウンタ
AL_COVERAGE_TOTAL=0
AL_COVERAGE_COVERED=0
AL_COVERAGE_MISSING=0

# 結果蓄積
AL_RESULTS=""
AL_RECOMMENDATIONS=""

# カラー定義
AL_GREEN='\033[0;32m'   AL_YELLOW='\033[0;33m'  AL_RED='\033[0;31m'
AL_CYAN='\033[0;36m'    AL_BOLD='\033[1m'        AL_PURPLE='\033[0;35m'
AL_NC='\033[0m'

# --- 内部関数 ---

# --- _al_log: 内部ログ出力 ---------------------------------------------------
_al_log() {
    local level="$1" msg="$2"
    local ts; ts="$(date '+%H:%M:%S')"

    # ログレベルフィルタリング
    local -A level_map=([debug]=0 [info]=1 [warn]=2 [error]=3)
    local cur_level="${level_map[${AL_LOG_LEVEL}]:-1}"
    local msg_level="${level_map[${level}]:-1}"
    [[ "$msg_level" -lt "$cur_level" ]] && return 0

    case "$level" in
        debug) printf "  ${AL_CYAN}[AUDIT DBG ${ts}]${AL_NC} %s\n" "$msg" >&2 ;;
        info)  printf "  ${AL_CYAN}[AUDIT]${AL_NC} %s\n" "$msg" >&2 ;;
        warn)  printf "  ${AL_YELLOW}[AUDIT WARN]${AL_NC} %s\n" "$msg" >&2 ;;
        error) printf "  ${AL_RED}[AUDIT ERROR]${AL_NC} %s\n" "$msg" >&2 ;;
        pass)  printf "  ${AL_GREEN}[AUDIT PASS]${AL_NC} %s\n" "$msg" >&2 ;;
        fail)  printf "  ${AL_RED}[AUDIT FAIL]${AL_NC} %s\n" "$msg" >&2 ;;
    esac
    AL_RESULTS+="${level}|${msg}\n"
}

# --- _al_detect_framework: フレームワーク自動検出 --------------------------------
_al_detect_framework() {
    local pd="${1:-$AL_PROJECT_DIR}"
    [[ -z "$pd" || ! -d "$pd" ]] && { echo "unknown"; return; }
    if [[ -f "${pd}/package.json" ]]; then
        local pkg; pkg="$(cat "${pd}/package.json" 2>/dev/null)"
        echo "$pkg" | grep -q '"hono"' && { echo "hono"; return; }
        echo "$pkg" | grep -q '"fastify"' && { echo "fastify"; return; }
        echo "$pkg" | grep -q '"express"' && { echo "express"; return; }
        echo "$pkg" | grep -q '"next"' && { echo "nextjs"; return; }
        echo "node"; return
    fi
    if [[ -f "${pd}/requirements.txt" ]] || [[ -f "${pd}/pyproject.toml" ]]; then
        grep -q 'fastapi\|FastAPI' "${pd}/requirements.txt" "${pd}/pyproject.toml" 2>/dev/null && { echo "fastapi"; return; }
        grep -q 'django\|Django' "${pd}/requirements.txt" "${pd}/pyproject.toml" 2>/dev/null && { echo "django"; return; }
        grep -q 'flask\|Flask' "${pd}/requirements.txt" "${pd}/pyproject.toml" 2>/dev/null && { echo "flask"; return; }
        echo "python"; return
    fi
    [[ -f "${pd}/go.mod" ]] && { echo "go"; return; }
    echo "unknown"
}

# --- _al_detect_db_type: プロジェクトのDB種別を自動検出 -------------------------
_al_detect_db_type() {
    local pd="${1:-$AL_PROJECT_DIR}"
    [[ -z "$pd" || ! -d "$pd" ]] && { echo "unknown"; return; }
    # Prisma schema
    local ps="${pd}/prisma/schema.prisma"
    if [[ -f "$ps" ]]; then
        grep -qi 'provider.*"postgresql"' "$ps" 2>/dev/null && { echo "postgres"; return; }
        grep -qi 'provider.*"mysql"' "$ps" 2>/dev/null && { echo "mysql"; return; }
        grep -qi 'provider.*"sqlite"' "$ps" 2>/dev/null && { echo "sqlite"; return; }
        grep -qi 'provider.*"mongodb"' "$ps" 2>/dev/null && { echo "mongodb"; return; }
    fi
    # package.json
    if [[ -f "${pd}/package.json" ]]; then
        local pkg; pkg="$(cat "${pd}/package.json" 2>/dev/null)"
        echo "$pkg" | grep -q '"pg"\|"postgres"\|"@prisma/client"' && { echo "postgres"; return; }
        echo "$pkg" | grep -q '"mysql2"\|"mysql"' && { echo "mysql"; return; }
        echo "$pkg" | grep -q '"mongoose"\|"mongodb"' && { echo "mongodb"; return; }
        echo "$pkg" | grep -q '"better-sqlite3"\|"sqlite3"' && { echo "sqlite"; return; }
    fi
    # .env / docker-compose
    for ef in "${pd}/.env" "${pd}/docker-compose.yml"; do
        [[ -f "$ef" ]] || continue
        grep -qi 'postgres' "$ef" 2>/dev/null && { echo "postgres"; return; }
        grep -qi 'mysql' "$ef" 2>/dev/null && { echo "mysql"; return; }
        grep -qi 'mongo' "$ef" 2>/dev/null && { echo "mongodb"; return; }
    done
    # Python
    [[ -f "${pd}/requirements.txt" ]] && {
        grep -qi 'psycopg2\|asyncpg' "${pd}/requirements.txt" 2>/dev/null && { echo "postgres"; return; }
        grep -qi 'pymysql' "${pd}/requirements.txt" 2>/dev/null && { echo "mysql"; return; }
        grep -qi 'pymongo\|motor' "${pd}/requirements.txt" 2>/dev/null && { echo "mongodb"; return; }
    }
    echo "unknown"
}

# --- 1. 初期化 ---
al_init() {
    local pd="${1:-}"
    [[ -z "$pd" || ! -d "$pd" ]] && { _al_log error "Invalid project directory: ${pd}"; return 1; }

    AL_PROJECT_DIR="$pd"
    AL_COVERAGE_TOTAL=0
    AL_COVERAGE_COVERED=0
    AL_COVERAGE_MISSING=0
    AL_RESULTS=""
    AL_RECOMMENDATIONS=""

    AL_FRAMEWORK="$(_al_detect_framework "$pd")"
    AL_DB_TYPE="$(_al_detect_db_type "$pd")"
    AL_PROJECT_TYPE="$AL_FRAMEWORK"

    _al_log info "Audit Logger v${AL_VERSION} init: ${pd}"
    _al_log info "  Framework: ${AL_FRAMEWORK}, DB: ${AL_DB_TYPE}"
    _al_log info "  Retention: ${AL_RETENTION_DAYS} days, Before/After: ${AL_INCLUDE_BEFORE_AFTER}"
    return 0
}

# --- 2. 監査ログスキーマ生成 ---
al_generate_audit_schema() {
    local db_type="${1:-$AL_DB_TYPE}"
    _al_log info "Generating audit schema for: ${db_type}"

    case "$db_type" in
        postgres)
            cat <<'SCHEMA_PG'
-- SoloptiLink v17.0 - Audit Log Schema (PostgreSQL)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE TABLE IF NOT EXISTS audit_logs (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    entity_type VARCHAR(255) NOT NULL, entity_id VARCHAR(255) NOT NULL,
    action VARCHAR(50) NOT NULL CHECK (action IN ('CREATE','UPDATE','DELETE','READ','LOGIN','LOGOUT','EXPORT')),
    actor_id VARCHAR(255), actor_ip INET, actor_user_agent TEXT,
    before_data JSONB, after_data JSONB, changed_fields TEXT[],
    metadata JSONB DEFAULT '{}', session_id VARCHAR(255), request_id VARCHAR(255),
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_type,entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_logs(actor_id,created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_logs(action);
-- Retention: DELETE FROM audit_logs WHERE created_at < NOW() - INTERVAL '365 days';
SCHEMA_PG
            ;;

        mysql)
            cat <<'SCHEMA_MYSQL'
-- SoloptiLink v17.0 - Audit Log Schema (MySQL)
CREATE TABLE IF NOT EXISTS audit_logs (
    id CHAR(36) DEFAULT (UUID()) PRIMARY KEY,
    entity_type VARCHAR(255) NOT NULL, entity_id VARCHAR(255) NOT NULL,
    action ENUM('CREATE','UPDATE','DELETE','READ','LOGIN','LOGOUT','EXPORT') NOT NULL,
    actor_id VARCHAR(255), actor_ip VARCHAR(45), actor_user_agent TEXT,
    before_data JSON, after_data JSON, changed_fields JSON,
    metadata JSON DEFAULT ('{}'), session_id VARCHAR(255), request_id VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    INDEX idx_entity (entity_type, entity_id), INDEX idx_actor (actor_id, created_at),
    INDEX idx_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SCHEMA_MYSQL
            ;;

        mongodb)
            cat <<'SCHEMA_MONGO'
// SoloptiLink v17.0 - Audit Log Schema (MongoDB/Mongoose)
const mongoose = require('mongoose');
const auditLogSchema = new mongoose.Schema({
  entityType: {type:String, required:true, index:true},
  entityId: {type:String, required:true, index:true},
  action: {type:String, required:true, enum:['CREATE','UPDATE','DELETE','READ','LOGIN','LOGOUT','EXPORT']},
  actorId: {type:String, index:true}, actorIp: String, actorUserAgent: String,
  beforeData: mongoose.Schema.Types.Mixed, afterData: mongoose.Schema.Types.Mixed,
  changedFields: [{type:String}], metadata: {type:mongoose.Schema.Types.Mixed, default:{}},
  sessionId: String, requestId: String,
  createdAt: {type:Date, default:Date.now, index:true}
}, {timestamps:false, collection:'audit_logs'});
auditLogSchema.index({entityType:1,entityId:1,createdAt:-1});
auditLogSchema.index({actorId:1,createdAt:-1});
auditLogSchema.index({createdAt:1},{expireAfterSeconds:365*24*60*60});
const AuditLog = mongoose.model('AuditLog', auditLogSchema);
module.exports = { AuditLog, auditLogSchema };
SCHEMA_MONGO
            ;;

        sqlite)
            cat <<'SCHEMA_SQLITE'
-- SoloptiLink v17.0 - Audit Log Schema (SQLite)
CREATE TABLE IF NOT EXISTS audit_logs (
    id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    entity_type TEXT NOT NULL, entity_id TEXT NOT NULL,
    action TEXT NOT NULL CHECK (action IN ('CREATE','UPDATE','DELETE','READ','LOGIN','LOGOUT','EXPORT')),
    actor_id TEXT, actor_ip TEXT, actor_user_agent TEXT,
    before_data TEXT, after_data TEXT, changed_fields TEXT,
    metadata TEXT DEFAULT '{}', session_id TEXT, request_id TEXT,
    created_at TEXT DEFAULT (datetime('now')) NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_logs(entity_type,entity_id);
CREATE INDEX IF NOT EXISTS idx_audit_actor ON audit_logs(actor_id,created_at);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_logs(created_at);
SCHEMA_SQLITE
            ;;

        *)
            _al_log warn "Unknown DB type: ${db_type}. Defaulting to PostgreSQL."
            al_generate_audit_schema "postgres"
            return $?
            ;;
    esac
}

# --- 3. 監査ミドルウェア生成 ---
al_generate_audit_middleware() {
    local framework="${1:-$AL_FRAMEWORK}"
    _al_log info "Generating audit middleware for: ${framework}"

    case "$framework" in
        express)
            cat <<'MW_EXPRESS'
// SoloptiLink v17.0 - Audit Middleware (Express)
// Usage: app.use(auditMiddleware); await auditLog(req, {...});
const { v4: uuidv4 } = require('uuid');

function auditMiddleware(req, res, next) {
  req.auditContext = {
    requestId: uuidv4(),
    actorId: req.user?.id || req.headers['x-user-id'] || 'anonymous',
    actorIp: req.ip || req.headers['x-forwarded-for'] || req.connection?.remoteAddress,
    actorUserAgent: req.headers['user-agent'] || '',
    sessionId: req.sessionID || req.headers['x-session-id'] || ''
  };
  next();
}

async function auditLog(req, { entityType, entityId, action, before, after, metadata = {} }) {
  const ctx = req.auditContext || {}, changedFields = [];
  if (before && after && typeof before === 'object' && typeof after === 'object')
    for (const k of new Set([...Object.keys(before), ...Object.keys(after)]))
      if (JSON.stringify(before[k]) !== JSON.stringify(after[k])) changedFields.push(k);
  const entry = { id: uuidv4(), entityType, entityId: String(entityId), action,
    actorId: ctx.actorId, actorIp: ctx.actorIp, actorUserAgent: ctx.actorUserAgent,
    beforeData: before||null, afterData: after||null, changedFields, metadata,
    sessionId: ctx.sessionId, requestId: ctx.requestId, createdAt: new Date() };
  try {
    if (global.prisma) await global.prisma.auditLog.create({ data: entry });
    else if (global.db) await global.db('audit_logs').insert(entry);
    else console.log('[AUDIT]', JSON.stringify(entry));
  } catch (err) { console.error('[AUDIT] Write failed:', err.message); }
  return entry;
}
module.exports = { auditMiddleware, auditLog };
MW_EXPRESS
            ;;

        fastify)
            cat <<'MW_FASTIFY'
// SoloptiLink v17.0 - Audit Middleware (Fastify)
const { v4: uuidv4 } = require('uuid');
async function auditPlugin(fastify, opts) {
  fastify.decorateRequest('auditContext', null);
  fastify.decorateRequest('auditLog', null);
  fastify.addHook('onRequest', async (request) => {
    request.auditContext = {
      requestId: uuidv4(), actorId: request.user?.id || 'anonymous',
      actorIp: request.ip, actorUserAgent: request.headers['user-agent'] || '',
      sessionId: request.headers['x-session-id'] || ''
    };
    request.auditLog = async ({ entityType, entityId, action, before, after, metadata = {} }) => {
      const ctx = request.auditContext, changedFields = [];
      if (before && after && typeof before === 'object' && typeof after === 'object')
        for (const k of new Set([...Object.keys(before), ...Object.keys(after)]))
          if (JSON.stringify(before[k]) !== JSON.stringify(after[k])) changedFields.push(k);
      const entry = { id: uuidv4(), entityType, entityId: String(entityId), action,
        actorId: ctx.actorId, actorIp: ctx.actorIp, actorUserAgent: ctx.actorUserAgent,
        beforeData: before||null, afterData: after||null, changedFields, metadata,
        sessionId: ctx.sessionId, requestId: ctx.requestId, createdAt: new Date() };
      try { if (fastify.prisma) await fastify.prisma.auditLog.create({data:entry});
            else if (fastify.knex) await fastify.knex('audit_logs').insert(entry);
            else fastify.log.warn({msg:'No DB for audit',entry});
      } catch(e) { fastify.log.error({msg:'Audit write failed',err:e.message}); }
      return entry;
    };
  });
}
module.exports = auditPlugin;
MW_FASTIFY
            ;;

        hono)
            cat <<'MW_HONO'
// SoloptiLink v17.0 - Audit Middleware (Hono)
import { createMiddleware } from 'hono/factory';
import { v4 as uuidv4 } from 'uuid';
export const auditMiddleware = createMiddleware(async (c, next) => {
  c.set('auditContext', {
    requestId: uuidv4(), actorId: c.get('user')?.id || 'anonymous',
    actorIp: c.req.header('x-forwarded-for') || 'unknown',
    actorUserAgent: c.req.header('user-agent') || '',
    sessionId: c.req.header('x-session-id') || ''
  });
  await next();
});
export async function auditLog(c, { entityType, entityId, action, before, after, metadata = {} }) {
  const ctx = c.get('auditContext') || {}, changedFields = [];
  if (before && after && typeof before === 'object' && typeof after === 'object')
    for (const k of new Set([...Object.keys(before), ...Object.keys(after)]))
      if (JSON.stringify(before[k]) !== JSON.stringify(after[k])) changedFields.push(k);
  const entry = { id: uuidv4(), entityType, entityId: String(entityId), action, ...ctx,
    beforeData: before||null, afterData: after||null, changedFields, metadata,
    createdAt: new Date().toISOString() };
  const db = c.get('db');
  try { if (db) await db.insert(entry).into('audit_logs');
        else console.log('[AUDIT]', JSON.stringify(entry));
  } catch(e) { console.error('[AUDIT] Write failed:', e.message); }
  return entry;
}
MW_HONO
            ;;

        *)
            _al_log warn "Unknown framework: ${framework}. Generating Express middleware as default."
            al_generate_audit_middleware "express"
            return $?
            ;;
    esac
}

# --- 4. Prisma Extension 生成 ---
al_generate_audit_prisma_extension() {
    _al_log info "Generating Prisma audit extension"

    cat <<'PRISMA_EXT'
// SoloptiLink v17.0 - Prisma Audit Extension
// Usage: const prisma = new PrismaClient().$extends(withAuditLog());
const { v4: uuidv4 } = require('uuid');
function withAuditLog(opts={}) {
  const {excludeModels=['AuditLog'],actorResolver=null,
    sensitiveFields=['password','passwordHash','secret','token','apiKey']} = opts;
  const san = d => { if(!d||typeof d!=='object')return d; const c={...d};
    sensitiveFields.forEach(f=>{if(f in c)c[f]='[REDACTED]'}); return c; };
  const diff = (a,b) => (!a||!b)?[]:
    [...new Set([...Object.keys(a),...Object.keys(b)])].filter(k=>JSON.stringify(a[k])!==JSON.stringify(b[k]));
  const mk = async(e)=>{ try{const{PrismaClient:P}=require('@prisma/client');const p=new P();
    await p.auditLog.create({data:e});await p.$disconnect();}catch(x){console.error('[AUDIT]',x.message);}};
  const get = async(m,w)=>{ try{const{PrismaClient:P}=require('@prisma/client');const p=new P();
    const r=await p[m.charAt(0).toLowerCase()+m.slice(1)].findUnique({where:w});await p.$disconnect();return r;}catch(e){return null;}};
  const actor = async()=>actorResolver?await actorResolver():'system';
  return {name:'soloptilink-audit-log',query:{$allModels:{
    async create({model:m,args,query:q}){if(excludeModels.includes(m))return q(args);const r=await q(args);
      await mk({id:uuidv4(),entityType:m,entityId:String(r.id||'?'),action:'CREATE',actorId:await actor(),
        beforeData:null,afterData:san(r),changedFields:Object.keys(args.data||{}),metadata:{},createdAt:new Date()});return r;},
    async update({model:m,args,query:q}){if(excludeModels.includes(m))return q(args);const b=await get(m,args.where);
      const r=await q(args);const sb=b?san(b):null,sa=san(r);
      await mk({id:uuidv4(),entityType:m,entityId:String(r.id||'?'),action:'UPDATE',actorId:await actor(),
        beforeData:sb,afterData:sa,changedFields:diff(sb,sa),metadata:{},createdAt:new Date()});return r;},
    async delete({model:m,args,query:q}){if(excludeModels.includes(m))return q(args);const b=await get(m,args.where);
      const r=await q(args);await mk({id:uuidv4(),entityType:m,entityId:String(b?.id||'?'),action:'DELETE',
        actorId:await actor(),beforeData:b?san(b):null,afterData:null,changedFields:[],metadata:{},createdAt:new Date()});return r;}
  }}};
}
module.exports = { withAuditLog };
PRISMA_EXT
}

# --- 5. 監査ログ検索ヘルパー生成 ---
al_generate_audit_query_helpers() {
    local db_type="${1:-$AL_DB_TYPE}"
    _al_log info "Generating audit query helpers for: ${db_type}"

    case "$db_type" in
        postgres|mysql|sqlite)
            cat <<'QUERY_SQL'
// SoloptiLink v17.0 - Audit Log Query Helpers (SQL/Knex)
async function getAuditTrail(db, entityType, entityId, opts = {}) {
  const { limit=50, offset=0, startDate, endDate } = opts;
  let q = db('audit_logs').where({entity_type:entityType, entity_id:String(entityId)})
    .orderBy('created_at','desc').limit(limit).offset(offset);
  if (startDate) q = q.where('created_at','>=',startDate);
  if (endDate) q = q.where('created_at','<=',endDate);
  return q;
}
async function getActorActivity(db, actorId, range = {}, opts = {}) {
  const { limit=100, offset=0, actions } = opts;
  let q = db('audit_logs').where({actor_id:actorId})
    .orderBy('created_at','desc').limit(limit).offset(offset);
  if (range.start) q = q.where('created_at','>=',range.start);
  if (range.end) q = q.where('created_at','<=',range.end);
  if (actions?.length) q = q.whereIn('action',actions);
  return q;
}
async function getRecentChanges(db, limit = 20, filters = {}) {
  let q = db('audit_logs').orderBy('created_at','desc').limit(limit);
  if (filters.entityType) q = q.where('entity_type',filters.entityType);
  if (filters.action) q = q.where('action',filters.action);
  if (filters.actorId) q = q.where('actor_id',filters.actorId);
  return q;
}
async function getEntityStateAt(db, entityType, entityId, pointInTime) {
  const logs = await db('audit_logs')
    .where({entity_type:entityType, entity_id:String(entityId)})
    .where('created_at','<=',pointInTime).orderBy('created_at','asc');
  if (!logs.length) return null;
  const last = logs[logs.length-1];
  return last.after_data || last.before_data;
}
module.exports = { getAuditTrail, getActorActivity, getRecentChanges, getEntityStateAt };
QUERY_SQL
            ;;

        mongodb)
            cat <<'QUERY_MONGO'
// SoloptiLink v17.0 - Audit Log Query Helpers (MongoDB)
const { AuditLog } = require('../models/auditLog');
async function getAuditTrail(entityType, entityId, opts = {}) {
  const { limit=50, skip=0, startDate, endDate } = opts;
  const f = { entityType, entityId: String(entityId) };
  if (startDate||endDate) { f.createdAt = {};
    if (startDate) f.createdAt.$gte = new Date(startDate);
    if (endDate) f.createdAt.$lte = new Date(endDate); }
  return AuditLog.find(f).sort({createdAt:-1}).skip(skip).limit(limit).lean();
}
async function getActorActivity(actorId, range = {}, opts = {}) {
  const { limit=100, skip=0, actions } = opts;
  const f = { actorId };
  if (range.start||range.end) { f.createdAt = {};
    if (range.start) f.createdAt.$gte = new Date(range.start);
    if (range.end) f.createdAt.$lte = new Date(range.end); }
  if (actions?.length) f.action = { $in: actions };
  return AuditLog.find(f).sort({createdAt:-1}).skip(skip).limit(limit).lean();
}
async function getRecentChanges(limit = 20, filters = {}) {
  const f = {};
  if (filters.entityType) f.entityType = filters.entityType;
  if (filters.action) f.action = filters.action;
  if (filters.actorId) f.actorId = filters.actorId;
  return AuditLog.find(f).sort({createdAt:-1}).limit(limit).lean();
}
async function getEntityStateAt(entityType, entityId, pointInTime) {
  const logs = await AuditLog.find({ entityType, entityId:String(entityId),
    createdAt:{$lte:new Date(pointInTime)} }).sort({createdAt:1}).lean();
  if (!logs.length) return null;
  const last = logs[logs.length-1];
  return last.afterData || last.beforeData;
}
module.exports = { getAuditTrail, getActorActivity, getRecentChanges, getEntityStateAt };
QUERY_MONGO
            ;;

        *)
            _al_log warn "Unknown DB type for query helpers: ${db_type}. Using SQL variant."
            al_generate_audit_query_helpers "postgres"
            return $?
            ;;
    esac
}

# --- 6. プロンプト注入（最重要: sg_generate_security_prompt()同等） ---
al_inject_audit_prompt() {
    local original_prompt="${1:-}"

    # 監査ログ要件プロンプトを生成
    local audit_requirements
    audit_requirements=$(cat <<'AUDITPROMPT'

## 監査ログ要件（必須 - SoloptiLink v17.0）

### テーブル設計
- `audit_logs`テーブル: id, entity_type, entity_id, action(CREATE/UPDATE/DELETE/READ/LOGIN/LOGOUT/EXPORT), actor_id, actor_ip, before_data(JSON), after_data(JSON), changed_fields(配列), metadata, created_at
- インデックス: (entity_type,entity_id), (actor_id,created_at), (created_at)

### CRUD監査ルール
- CREATE: after_dataに記録 / UPDATE: before+after+changed_fields / DELETE: before_dataに記録
- LOGIN/LOGOUTも記録。機密フィールド(password,token,secret,apiKey)は'[REDACTED]'に置換
- 監査ログ自体は監査対象外（無限ループ防止）。書き込みは非同期、失敗してもメイン処理継続

### ミドルウェア・API
- 全リクエストに監査コンテキスト(actor_id,actor_ip,request_id)自動付与
- ORM使用時はPrisma Extension等で自動フック
- getAuditTrail(entityType,entityId) / getActorActivity(actorId,range) / getRecentChanges(limit)
- 保持期間365日
AUDITPROMPT
    )

    # 元のプロンプトと監査ログ要件を結合
    if [[ -n "$original_prompt" ]]; then
        printf '%s\n%s' "$original_prompt" "$audit_requirements"
    else
        printf '%s' "$audit_requirements"
    fi
}

# --- 7. 監査ログレポート生成 ---
al_generate_audit_report() {
    local pd="${1:-$AL_PROJECT_DIR}"
    [[ -z "$pd" || ! -d "$pd" ]] && { _al_log error "Invalid project: ${pd}"; return 1; }

    local report_file="${pd}/docs/chain-logs/audit-report-$(date '+%Y%m%d-%H%M%S').md"
    mkdir -p "$(dirname "$report_file")" 2>/dev/null || true

    # カバレッジ検証を実行
    local coverage_json
    coverage_json=$(al_validate_audit_coverage "$pd")

    # 各コンポーネント存在チェック
    local has_schema="no" has_middleware="no" has_helpers="no" has_redaction="no"
    local _src_files; _src_files=$(find "$pd" -type f \( -name '*.js' -o -name '*.ts' -o -name '*.sql' -o -name '*.prisma' \) \
        ! -path '*/node_modules/*' ! -path '*/.git/*' 2>/dev/null)
    [[ -n "$_src_files" ]] && {
        echo "$_src_files" | xargs grep -l 'audit_logs\|AuditLog' 2>/dev/null | head -1 | grep -q . && has_schema="yes"
        echo "$_src_files" | xargs grep -l 'auditMiddleware\|withAuditLog' 2>/dev/null | head -1 | grep -q . && has_middleware="yes"
        echo "$_src_files" | xargs grep -l 'getAuditTrail\|getActorActivity\|getRecentChanges' 2>/dev/null | head -1 | grep -q . && has_helpers="yes"
        echo "$_src_files" | xargs grep -l 'REDACTED\|sanitize\|sensitiveFields' 2>/dev/null | head -1 | grep -q . && has_redaction="yes"
    }

    local score=0
    [[ "$has_schema" == "yes" ]] && score=$((score + 30))
    [[ "$has_middleware" == "yes" ]] && score=$((score + 30))
    [[ "$has_helpers" == "yes" ]] && score=$((score + 20))
    [[ "$has_redaction" == "yes" ]] && score=$((score + 20))

    local status_msg="FAIL"; [[ "$score" -ge 50 ]] && status_msg="PARTIAL"; [[ "$score" -ge 80 ]] && status_msg="PASS"
    local s_schema; [[ "$has_schema" == "yes" ]] && s_schema="PASS" || s_schema="MISSING"
    local s_mw; [[ "$has_middleware" == "yes" ]] && s_mw="PASS" || s_mw="MISSING"
    local s_help; [[ "$has_helpers" == "yes" ]] && s_help="PASS" || s_help="MISSING"
    local s_redact; [[ "$has_redaction" == "yes" ]] && s_redact="PASS" || s_redact="MISSING"
    {
        echo "# Audit Log Implementation Report"
        echo "**Generated**: $(date '+%Y-%m-%d %H:%M:%S') | **Project**: ${pd}"
        echo "**Scanner**: SoloptiLink Chain v17.0 Audit Logger"
        echo ""
        echo "| Component | Status |"
        echo "|-----------|--------|"
        echo "| Schema | ${s_schema} |"
        echo "| Middleware | ${s_mw} |"
        echo "| Query Helpers | ${s_help} |"
        echo "| Data Redaction | ${s_redact} |"
        echo ""
        echo "**Audit Score: ${score}/100** - Status: ${status_msg}"
        echo ""
        echo '```json'
        echo "$coverage_json"
        echo '```'
        echo ""
        [[ "$has_schema" != "yes" ]] && echo "- audit_logsテーブルを作成してください"
        [[ "$has_middleware" != "yes" ]] && echo "- 監査ミドルウェアを全APIルートに適用してください"
        [[ "$has_helpers" != "yes" ]] && echo "- 検索ヘルパー関数を実装してください"
        [[ "$has_redaction" != "yes" ]] && echo "- 機密フィールドのマスク処理を実装してください"
        echo "---"
        echo "*Generated by SoloptiLink Chain v17.0 Audit Logger.*"
    } > "$report_file"

    # コンソール出力
    local sc="$AL_GREEN"; [[ "$score" -lt 80 ]] && sc="$AL_YELLOW"; [[ "$score" -lt 50 ]] && sc="$AL_RED"
    printf "\n${AL_BOLD}  Audit Report v17.0${AL_NC}  Schema:%s  MW:%s  Helpers:%s  Redact:%s\n" \
        "$has_schema" "$has_middleware" "$has_helpers" "$has_redaction"
    printf "  ${AL_BOLD}Audit Score: ${sc}%d/100${AL_NC}  Report: %s\n" "$score" "$report_file"
    echo "$score"
}

# --- 8. 監査ログカバレッジ検証 ---
al_validate_audit_coverage() {
    local pd="${1:-$AL_PROJECT_DIR}"
    [[ -z "$pd" || ! -d "$pd" ]] && { echo '{"error":"invalid project"}'; return 1; }

    AL_COVERAGE_TOTAL=0
    AL_COVERAGE_COVERED=0
    AL_COVERAGE_MISSING=0

    local -a missing_files=()
    local -a covered_files=()

    # CRUD操作を含むファイルを検索
    local crud_files
    crud_files=$(find "$pd" -type f \( -name '*.js' -o -name '*.ts' -o -name '*.tsx' -o -name '*.jsx' \
        -o -name '*.py' -o -name '*.go' -o -name '*.rb' \) \
        ! -path '*/node_modules/*' ! -path '*/.git/*' ! -path '*/dist/*' \
        ! -path '*/build/*' ! -path '*/.next/*' ! -path '*/vendor/*' \
        ! -path '*/__pycache__/*' ! -path '*/test*/*' ! -path '*/*.test.*' ! -path '*/*.spec.*' 2>/dev/null)
    [[ -z "$crud_files" ]] && { echo '{"total":0,"covered":0,"missing":0,"percentage":0,"files":[]}'; return 0; }

    local crud_pat='\.(create|insert|save|add|post|update|delete|destroy|remove)\b|INSERT\s+INTO|UPDATE\s+|DELETE\s+FROM|prisma\.[a-zA-Z]+\.(create|update|delete|upsert)'
    local audit_pat='audit[Ll]og|audit_log|AuditLog|auditMiddleware|withAuditLog|getAuditTrail'
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        grep -qE "$crud_pat" "$file" 2>/dev/null || continue
        AL_COVERAGE_TOTAL=$((AL_COVERAGE_TOTAL + 1))
        if grep -qE "$audit_pat" "$file" 2>/dev/null; then
            AL_COVERAGE_COVERED=$((AL_COVERAGE_COVERED + 1)); covered_files+=("$file")
        else
            AL_COVERAGE_MISSING=$((AL_COVERAGE_MISSING + 1)); missing_files+=("$file")
        fi
    done <<< "$crud_files"

    # カバレッジパーセンテージ計算
    local percentage=0
    if [[ "$AL_COVERAGE_TOTAL" -gt 0 ]]; then
        percentage=$((AL_COVERAGE_COVERED * 100 / AL_COVERAGE_TOTAL))
    fi

    # JSON配列生成
    local missing_json="[" covered_json="[" _f _first=true
    for _f in "${missing_files[@]}"; do
        [[ "$_first" == "true" ]] && _first=false || missing_json+=","
        missing_json+="\"${_f#${pd}/}\""
    done; missing_json+="]"; _first=true
    for _f in "${covered_files[@]}"; do
        [[ "$_first" == "true" ]] && _first=false || covered_json+=","
        covered_json+="\"${_f#${pd}/}\""
    done; covered_json+="]"

    printf '{"total":%d,"covered":%d,"missing":%d,"percentage":%d,"missingFiles":%s,"coveredFiles":%s}\n' \
        "$AL_COVERAGE_TOTAL" "$AL_COVERAGE_COVERED" "$AL_COVERAGE_MISSING" "$percentage" "$missing_json" "$covered_json"

    # ログ
    local lvl="fail"; [[ "$percentage" -ge 50 ]] && lvl="warn"; [[ "$percentage" -ge 80 ]] && lvl="pass"
    _al_log "$lvl" "Audit coverage: ${percentage}% (${AL_COVERAGE_COVERED}/${AL_COVERAGE_TOTAL})"
    for f in "${missing_files[@]}"; do _al_log warn "  No audit: ${f#${pd}/}"; done

    return 0
}

# --- 9. Prisma モデル生成 ---
al_generate_prisma_model() {
    _al_log info "Generating Prisma AuditLog model"

    cat <<'PRISMA_MODEL'
// SoloptiLink v17.0 - Audit Log Model (Prisma)
model AuditLog {
  id             String   @id @default(uuid())
  entityType     String   @map("entity_type")
  entityId       String   @map("entity_id")
  action         String
  actorId        String?  @map("actor_id")
  actorIp        String?  @map("actor_ip")
  actorUserAgent String?  @map("actor_user_agent")
  beforeData     Json?    @map("before_data")
  afterData      Json?    @map("after_data")
  changedFields  String[] @map("changed_fields")
  metadata       Json     @default("{}")
  sessionId      String?  @map("session_id")
  requestId      String?  @map("request_id")
  createdAt      DateTime @default(now()) @map("created_at")
  @@index([entityType, entityId])
  @@index([actorId, createdAt(sort: Desc)])
  @@index([createdAt(sort: Desc)])
  @@map("audit_logs")
}
PRISMA_MODEL
}

# --- 10. 全機能統合実行 ---
al_run_all() {
    local pd="$1"; al_init "$pd" || return 1
    printf "\n${AL_BOLD}${AL_PURPLE}%s\n  SoloptiLink Chain v17.0 - Audit Logger\n%s${AL_NC}\n" \
        "$(printf '=%.0s' {1..60})" "$(printf '=%.0s' {1..60})"
    al_validate_audit_coverage "$pd" > /dev/null
    al_generate_audit_report "$pd"
}

# --- 11. スキャフォールド ---
al_scaffold_audit_files() {
    local pd="${1:-$AL_PROJECT_DIR}" fw="${2:-$AL_FRAMEWORK}" db="${3:-$AL_DB_TYPE}"
    [[ -z "$pd" ]] && { _al_log error "Project directory required"; return 1; }
    _al_log info "Scaffolding audit files for ${fw}/${db} at ${pd}"
    case "$fw" in
        express|fastify|hono|nextjs|node)
            mkdir -p "${pd}/src/lib/audit" "${pd}/src/middleware" 2>/dev/null
            if [[ "$db" == "mongodb" ]]; then
                mkdir -p "${pd}/src/models" 2>/dev/null
                al_generate_audit_schema "$db" > "${pd}/src/models/auditLog.js"
            else
                mkdir -p "${pd}/prisma/migrations/audit" 2>/dev/null
                al_generate_audit_schema "$db" > "${pd}/prisma/migrations/audit/migration.sql"
                al_generate_prisma_model > "${pd}/prisma/audit-model.prisma"
                al_generate_audit_prisma_extension > "${pd}/src/lib/audit/prismaExtension.js"
            fi
            al_generate_audit_middleware "$fw" > "${pd}/src/middleware/audit.js"
            al_generate_audit_query_helpers "$db" > "${pd}/src/lib/audit/queryHelpers.js" ;;
        django|flask|fastapi|python)
            mkdir -p "${pd}/audit" 2>/dev/null
            al_generate_audit_schema "${db:-postgres}" > "${pd}/audit/schema.sql" ;;
        *)
            mkdir -p "${pd}/db/migrations" 2>/dev/null
            al_generate_audit_schema "${db:-postgres}" > "${pd}/db/migrations/create_audit_logs.sql" ;;
    esac
    _al_log info "Audit scaffolding complete"
}

# --- 12. Observatory連携 / 設定管理 / Prismaスキーマ注入 ---
al_emit_event() {
    local event_type="${1:-AUDIT}" event_data="${2:-{}}"
    local events_file="${SESSION_LOG_DIR:-/tmp}/observatory/events.jsonl"
    [[ -d "$(dirname "$events_file")" ]] || return 0
    local ts; ts="$(date -u '+%Y-%m-%dT%H:%M:%SZ' 2>/dev/null || date '+%Y-%m-%dT%H:%M:%SZ')"
    printf '{"type":"AUDIT","subtype":"%s","data":%s,"timestamp":"%s","module":"audit-logger","version":"%s"}\n' \
        "$event_type" "$event_data" "$ts" "$AL_VERSION" >> "$events_file"
}

al_configure() {
    local key="${1:-}" value="${2:-}"
    case "$key" in
        retention_days)       AL_RETENTION_DAYS="${value:-365}" ;;
        include_before_after) AL_INCLUDE_BEFORE_AFTER="${value:-true}" ;;
        log_level)            AL_LOG_LEVEL="${value:-info}" ;;
        enabled)              AL_ENABLED="${value:-true}" ;;
        *) _al_log warn "Unknown config: ${key} (valid: retention_days, include_before_after, log_level, enabled)"; return 1 ;;
    esac
    _al_log info "Config ${key} = ${value}"
}

al_inject_prisma_schema() {
    local pd="${1:-$AL_PROJECT_DIR}" schema_file="${1:-$AL_PROJECT_DIR}/prisma/schema.prisma"
    [[ ! -f "$schema_file" ]] && { _al_log warn "No Prisma schema at ${schema_file}"; return 1; }
    grep -q 'model AuditLog' "$schema_file" 2>/dev/null && { _al_log info "AuditLog already exists"; return 0; }
    { echo ""; al_generate_prisma_model; } >> "$schema_file"
    _al_log info "AuditLog injected into: ${schema_file}"
}

# --- 13. ヘルスチェック ---
al_health_check() {
    local pd="${1:-$AL_PROJECT_DIR}" status="healthy" issues=0
    [[ -z "$pd" || ! -d "$pd" ]] && { _al_log error "Invalid project: ${pd}"; return 1; }
    echo -e "\n${AL_BOLD}  [Audit Health Check]${AL_NC}"
    # Schema
    if find "$pd" -type f \( -name '*.sql' -o -name '*.prisma' \) ! -path '*/node_modules/*' 2>/dev/null | \
        xargs grep -l 'audit_logs\|AuditLog' 2>/dev/null | head -1 | grep -q .; then
        _al_log pass "Audit schema found"
    else _al_log fail "Audit schema not found"; status="unhealthy"; issues=$((issues+1)); fi
    # Middleware
    if find "$pd" -type f \( -name '*.js' -o -name '*.ts' \) ! -path '*/node_modules/*' 2>/dev/null | \
        xargs grep -l 'auditMiddleware\|auditLog\|withAuditLog' 2>/dev/null | head -1 | grep -q .; then
        _al_log pass "Audit middleware found"
    else _al_log fail "Audit middleware not found"; status="unhealthy"; issues=$((issues+1)); fi
    # Redaction
    if find "$pd" -type f \( -name '*.js' -o -name '*.ts' \) ! -path '*/node_modules/*' 2>/dev/null | \
        xargs grep -l 'REDACTED\|sanitize\|sensitiveFields' 2>/dev/null | head -1 | grep -q .; then
        _al_log pass "Sensitive data redaction found"
    else _al_log warn "No redaction found"; issues=$((issues+1)); fi
    printf "  ${AL_BOLD}Health: %s (issues: %d)${AL_NC}\n" "$status" "$issues"
    [[ "$issues" -eq 0 ]]
}
