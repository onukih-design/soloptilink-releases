#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v442.0 - Read Replica Setup
# =============================================================================
# リードレプリカ設定支援。レプリカ設定生成、クエリルーティング、
# レプリカラグ監視を自動化する。
#
# Functions:
#   _rrs_init()                       - 初期化
#   _rrs_generate_replica_config()    - レプリカ設定生成
#   _rrs_generate_query_routing()     - クエリルーティング生成
#   _rrs_monitor_lag()                - レプリカラグ監視設定
#   _rrs_report() / _rrs_score()
#
# All globals use the RRS_ prefix.
# =============================================================================

[[ -n "${_RRS_LOADED:-}" ]] && return 0; _RRS_LOADED=1

declare -g RRS_VERSION="442.0"
declare -g RRS_GENERATED=0
declare -g RRS_ERRORS=0
declare -g RRS_REPLICA_COUNT="${RRS_REPLICA_COUNT:-2}"
declare -g RRS_ROUTING_GENERATED=false
declare -g RRS_MONITOR_CONFIGURED=false
declare -g RRS_READ_ENDPOINTS=0
declare -g RRS_WRITE_ENDPOINTS=0

declare -ga _RRS_FINDINGS=()

_RRS_GREEN="${GREEN:-\033[0;32m}"
_RRS_RED="${RED:-\033[0;31m}"
_RRS_YELLOW="${YELLOW:-\033[0;33m}"
_RRS_CYAN="${CYAN:-\033[0;36m}"
_RRS_BOLD="${BOLD:-\033[1m}"
_RRS_NC="${NC:-\033[0m}"

_rrs_init() {
    RRS_GENERATED=0; RRS_ERRORS=0; RRS_ROUTING_GENERATED=false
    RRS_MONITOR_CONFIGURED=false; RRS_READ_ENDPOINTS=0; RRS_WRITE_ENDPOINTS=0
    _RRS_FINDINGS=()
    return 0
}

_rrs_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_RRS_CYAN}[RRS]${_RRS_NC} $*" >&2 ;;
        ok)    echo -e "  ${_RRS_GREEN}[RRS]${_RRS_NC} $*" >&2 ;;
        warn)  echo -e "  ${_RRS_YELLOW}[RRS]${_RRS_NC} $*" >&2 ;;
        error) echo -e "  ${_RRS_RED}[RRS]${_RRS_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _rrs_generate_replica_config - レプリカ設定生成
# =============================================================================
_rrs_generate_replica_config() {
    local project_dir="${1:-.}"
    local replica_count="${2:-$RRS_REPLICA_COUNT}"

    _rrs_log info "リードレプリカ設定生成 (${replica_count}レプリカ)"

    # APIエンドポイントのRead/Write分析
    RRS_READ_ENDPOINTS=0
    RRS_WRITE_ENDPOINTS=0

    while IFS= read -r -d '' file; do
        local has_get
        has_get=$(grep -c "export.*GET\|GET.*handler" "$file" 2>/dev/null || echo 0)
        local has_write
        has_write=$(grep -c "export.*POST\|export.*PUT\|export.*PATCH\|export.*DELETE" "$file" 2>/dev/null || echo 0)

        RRS_READ_ENDPOINTS=$((RRS_READ_ENDPOINTS + has_get))
        RRS_WRITE_ENDPOINTS=$((RRS_WRITE_ENDPOINTS + has_write))
    done < <(find "$project_dir" -name "route.ts" -not -path "*/node_modules/*" -print0 2>/dev/null)

    local read_ratio=0
    local total=$((RRS_READ_ENDPOINTS + RRS_WRITE_ENDPOINTS))
    [[ $total -gt 0 ]] && read_ratio=$((RRS_READ_ENDPOINTS * 100 / total))

    _rrs_log info "Read/Write比率: ${read_ratio}% read (${RRS_READ_ENDPOINTS}R / ${RRS_WRITE_ENDPOINTS}W)"

    local config=$(cat <<CONFIG
// lib/replica-config.ts - Read Replica Configuration
export interface ReplicaConfig {
  primary: {
    url: string;
    maxConnections: number;
  };
  replicas: Array<{
    id: number;
    url: string;
    maxConnections: number;
    weight: number;
  }>;
  lagThresholdMs: number;
}

export const replicaConfig: ReplicaConfig = {
  primary: {
    url: process.env.DATABASE_URL_PRIMARY || process.env.DATABASE_URL || '',
    maxConnections: 10,
  },
  replicas: Array.from({ length: ${replica_count} }, (_, i) => ({
    id: i,
    url: process.env[\`DATABASE_URL_REPLICA_\${i}\`] || '',
    maxConnections: 20,
    weight: 1,
  })),
  lagThresholdMs: 1000,
};
CONFIG
)

    if [[ $read_ratio -gt 70 ]]; then
        _RRS_FINDINGS+=("HIGH_READ:${read_ratio}% reads - read replicas strongly recommended")
    fi

    RRS_GENERATED=$((RRS_GENERATED + 1))
    _rrs_log ok "レプリカ設定生成完了"
    echo "$config"
    return 0
}

# =============================================================================
# _rrs_generate_query_routing - クエリルーティング生成
# =============================================================================
_rrs_generate_query_routing() {
    local project_dir="${1:-.}"
    _rrs_log info "クエリルーティング生成"

    local routing=$(cat <<'ROUTING'
// lib/db-router.ts - Query Routing (Primary/Replica)
import { PrismaClient } from '@prisma/client';
import { replicaConfig } from './replica-config';

let primaryClient: PrismaClient | null = null;
const replicaClients: PrismaClient[] = [];
let roundRobinIndex = 0;

function getPrimary(): PrismaClient {
  if (!primaryClient) {
    primaryClient = new PrismaClient({
      datasources: { db: { url: replicaConfig.primary.url } },
    });
  }
  return primaryClient;
}

function getReplica(): PrismaClient {
  const availableReplicas = replicaConfig.replicas.filter(r => r.url);
  if (availableReplicas.length === 0) return getPrimary();

  if (replicaClients.length === 0) {
    for (const replica of availableReplicas) {
      replicaClients.push(
        new PrismaClient({
          datasources: { db: { url: replica.url } },
        })
      );
    }
  }

  const client = replicaClients[roundRobinIndex % replicaClients.length];
  roundRobinIndex = (roundRobinIndex + 1) % replicaClients.length;
  return client;
}

export const db = {
  read: getReplica,
  write: getPrimary,
  primary: getPrimary,
  replica: getReplica,
};
ROUTING
)

    RRS_ROUTING_GENERATED=true
    RRS_GENERATED=$((RRS_GENERATED + 1))

    _RRS_FINDINGS+=("ROUTING:db.read() for GET, db.write() for mutations")
    _RRS_FINDINGS+=("CAUTION:avoid reading immediately after write (replication lag)")

    _rrs_log ok "クエリルーティング生成完了"
    echo "$routing"
    return 0
}

# =============================================================================
# _rrs_monitor_lag - レプリカラグ監視設定
# =============================================================================
_rrs_monitor_lag() {
    local project_dir="${1:-.}"
    _rrs_log info "レプリカラグ監視設定"

    local monitor=$(cat <<'MONITOR'
// lib/replica-monitor.ts - Replication Lag Monitor
import { db } from './db-router';

interface LagStatus {
  replicaId: number;
  lagMs: number;
  healthy: boolean;
}

export async function checkReplicationLag(): Promise<LagStatus[]> {
  const results: LagStatus[] = [];

  // PostgreSQL replication lag query
  try {
    const primary = db.primary();
    const lag = await primary.$queryRaw<Array<{ replica_lag_ms: number }>>`
      SELECT EXTRACT(EPOCH FROM (now() - pg_last_xact_replay_timestamp())) * 1000 AS replica_lag_ms
    `;
    // Monitor implementation depends on DB type
    results.push({
      replicaId: 0,
      lagMs: lag[0]?.replica_lag_ms || 0,
      healthy: (lag[0]?.replica_lag_ms || 0) < 1000,
    });
  } catch {
    // Lag monitoring not available
  }

  return results;
}
MONITOR
)

    RRS_MONITOR_CONFIGURED=true
    RRS_GENERATED=$((RRS_GENERATED + 1))

    _RRS_FINDINGS+=("LAG_MONITOR:check replication lag before critical reads")
    _RRS_FINDINGS+=("FAILOVER:if lag > threshold, route reads to primary")

    _rrs_log ok "ラグ監視設定完了"
    echo "$monitor"
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_rrs_report() {
    echo -e "\n  ${_RRS_BOLD}=== read-replica-setup v${RRS_VERSION} ===${_RRS_NC}"
    echo -e "  レプリカ数      : ${RRS_REPLICA_COUNT}"
    echo -e "  READエンドポイント: ${RRS_READ_ENDPOINTS}"
    echo -e "  WRITEエンドポイント: ${RRS_WRITE_ENDPOINTS}"
    echo -e "  ルーティング    : ${RRS_ROUTING_GENERATED}"
    echo -e "  ラグ監視        : ${RRS_MONITOR_CONFIGURED}"
    echo -e "  エラー          : ${RRS_ERRORS}"
}

_rrs_score() {
    local score=50
    [[ ${RRS_READ_ENDPOINTS} -gt 0 ]] && score=$((score + 10))
    [[ "$RRS_ROUTING_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$RRS_MONITOR_CONFIGURED" == "true" ]] && score=$((score + 15))
    [[ ${RRS_ERRORS} -eq 0 ]] && score=$((score + 10))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "read-replica-setup" --version "${RRS_VERSION}" \
        --description "リードレプリカ×クエリルーティング×ラグ監視 (v442)" \
        --init "_rrs_init" --report "_rrs_report" --score "_rrs_score" \
        --enable-var "ENABLE_READ_REPLICA" --cli-flags "--read-replica:--no-read-replica"
fi

# v2003.1: source時のexit codeを確実に0にする
true
