#!/usr/bin/env bash
# SoloptiLinkAI v2033.0 - Daily Upgrade Engine (DUE)
# scheduled-task "2032" による日次バージョンアップを駆動するコアエンジン
# 学習データ (errors / telemetry / sessions / distilled_patterns) を集計し、
# 「今日入れておいた方がいい機能」を構造的に抽出 → 提案レポートを出力する
#
# 設計方針:
#   - 読み取り専用 (危険な destructive 操作は一切しない)
#   - 出力は ~/.soloptilink/.proposals/daily_upgrade_<DATE>.md 1ファイルに集約
#   - 後続モジュール (DSD/IER) を呼び出して並列分析を統合する

[[ -n "${_DAILY_UPGRADE_ENGINE_LOADED:-}" ]] && return 0
_DAILY_UPGRADE_ENGINE_LOADED=1

DUE_VERSION="2034.2"
DUE_HOME="${SOLOPTILINK_HOME:-$HOME/.soloptilink}"
DUE_LEARN="${DUE_HOME}/learning"
DUE_OUT_DIR="${DUE_HOME}/.proposals"
DUE_REPORT_PREFIX="daily_upgrade"

mkdir -p "$DUE_OUT_DIR" 2>/dev/null || true

# ============================================================
# 学習データ集計
# ============================================================
due_count_recent_errors() {
    local file="${DUE_LEARN}/errors/raw_failures.jsonl"
    [[ -f "$file" ]] || { echo 0; return; }
    wc -l < "$file" | tr -d ' '
}

due_count_failed_fixes() {
    local file="${DUE_LEARN}/errors/raw_failures.jsonl"
    [[ -f "$file" ]] || { echo 0; return; }
    grep -c '"fix_success":false' "$file" 2>/dev/null || echo 0
}

due_count_distribution_blockers() {
    local file="${DUE_LEARN}/distilled_patterns.jsonl"
    [[ -f "$file" ]] || { echo 0; return; }
    tail -1 "$file" 2>/dev/null \
        | grep -oE '"distribution_blocker", *[0-9]+' \
        | grep -oE '[0-9]+$' \
        | head -1 \
        || echo 0
}

due_latest_telemetry_version() {
    local file="${DUE_LEARN}/telemetry/aggregates.json"
    [[ -f "$file" ]] || { echo "unknown"; return; }
    grep -oE '"version": *"[^"]+"' "$file" 2>/dev/null \
        | head -1 \
        | sed 's/.*"\([^"]*\)"$/\1/' \
        || echo "unknown"
}

due_top_failure_patterns() {
    # 直近 distilled_patterns.jsonl から fail_clusters を抽出
    local file="${DUE_LEARN}/distilled_patterns.jsonl"
    [[ -f "$file" ]] || return
    tail -1 "$file" 2>/dev/null | grep -oE '"fail_clusters":\[[^]]*\]' || true
}

# ============================================================
# 提案ロジック: 検出された問題ごとに upgrade 提案を生成
# ============================================================
due_propose_upgrades() {
    local errs failed blockers latest_ver
    errs=$(due_count_recent_errors)
    failed=$(due_count_failed_fixes)
    blockers=$(due_count_distribution_blockers)
    latest_ver=$(due_latest_telemetry_version)

    local proposals=()
    if [[ "$failed" -gt 0 ]]; then
        proposals+=("UPGRADE-A: import_error fix失敗が ${failed} 件残留 → IER (Import Error Resolver) を導入し fix失敗パターンを構造化")
    fi
    if [[ "$blockers" -gt 0 ]]; then
        proposals+=("UPGRADE-B: distribution_blocker が ${blockers} 件残留 → DSD (Distribution Stagnation Detector) を導入し配信停滞を能動検出")
    fi
    if [[ "$errs" -gt 0 ]]; then
        proposals+=("UPGRADE-C: 学習errors総数 ${errs} 件 → 解決パターンを solutions/index.jsonl に蓄積し再発時 0-shot 解決")
    fi
    proposals+=("UPGRADE-D: 学習telemetry最新schema ${latest_ver} → 本体VERSION (${DUE_VERSION}) と同期し schema 互換性を維持")

    # v2033.1: 本日の改修済み事項を可視化 (IER 昇格件数 / TAR 配線)
    if command -v ier_proven_solution_count >/dev/null 2>&1; then
        local proven
        proven=$(ier_proven_solution_count)
        if [[ "$proven" -gt 0 ]]; then
            proposals+=("UPGRADE-E (DONE today): IER v2033.1 が実証済み解決パターンを ${proven} 件 0-shot 化 (solutions/index.jsonl 蓄積済)")
        fi
    fi
    if [[ -f "${DUE_HOME}/lib/telemetry-auto-recorder.sh" ]]; then
        proposals+=("UPGRADE-F (DONE today): TAR v2033.1 配線 — sessions.jsonl 記録粒度向上 (start/end ペア + version/task_type/score/duration)")
    fi

    printf '%s\n' "${proposals[@]}"
}

# ============================================================
# レポート生成
# ============================================================
due_run() {
    local date_tag report_file
    date_tag=$(date -u +%Y%m%dT%H%M%SZ)
    report_file="${DUE_OUT_DIR}/${DUE_REPORT_PREFIX}_${date_tag}.md"

    # 兄弟モジュールを best-effort で source (なければサマリは空欄)
    local _here
    _here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    [[ -f "${_here}/distribution-stagnation-detector.sh" ]] && source "${_here}/distribution-stagnation-detector.sh" 2>/dev/null || true
    [[ -f "${_here}/import-error-resolver.sh" ]] && source "${_here}/import-error-resolver.sh" 2>/dev/null || true
    [[ -f "${_here}/telemetry-auto-recorder.sh" ]] && source "${_here}/telemetry-auto-recorder.sh" 2>/dev/null || true
    # v2033.2: 構造的トレンド + 解決テンプレ可視化
    [[ -f "${_here}/weekly-trend-aggregator.sh" ]] && source "${_here}/weekly-trend-aggregator.sh" 2>/dev/null || true
    [[ -f "${_here}/solutions-prefilter.sh" ]] && source "${_here}/solutions-prefilter.sh" 2>/dev/null || true
    # v2033.3: unproven → proven 昇格 readiness 検査
    [[ -f "${_here}/spf-auto-promoter.sh" ]] && source "${_here}/spf-auto-promoter.sh" 2>/dev/null || true
    # v2034.0: 整合性 + 集計鮮度 + 停滞検知
    [[ -f "${_here}/version-file-desync-detector.sh" ]] && source "${_here}/version-file-desync-detector.sh" 2>/dev/null || true
    [[ -f "${_here}/telemetry-aggregates-synchronizer.sh" ]] && source "${_here}/telemetry-aggregates-synchronizer.sh" 2>/dev/null || true
    [[ -f "${_here}/trend-repetition-alarm.sh" ]] && source "${_here}/trend-repetition-alarm.sh" 2>/dev/null || true
    # v2034.1: iron-dome failure_patterns → solutions 永続化 (v2033 で次走commitment)
    [[ -f "${_here}/iron-dome-failure-distiller.sh" ]] && source "${_here}/iron-dome-failure-distiller.sh" 2>/dev/null || true
    # 走査前に aggregates.json を最新化 (TAS は idempotent)
    if command -v tas_rebuild >/dev/null 2>&1; then
        tas_rebuild >/dev/null 2>&1 || true
    fi

    local errs failed blockers latest_ver fail_clusters
    errs=$(due_count_recent_errors)
    failed=$(due_count_failed_fixes)
    blockers=$(due_count_distribution_blockers)
    latest_ver=$(due_latest_telemetry_version)
    fail_clusters=$(due_top_failure_patterns)

    {
        echo "# Daily Upgrade Report (DUE v${DUE_VERSION})"
        echo
        echo "- generated_at: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
        echo "- soloptilink_home: ${DUE_HOME}"
        echo "- target_local_version: $(cat "${DUE_HOME}/VERSION" 2>/dev/null || echo unknown)"
        echo "- telemetry_schema_version: ${latest_ver}"
        echo
        echo "## 学習データ集計"
        echo "- raw failures: ${errs}"
        echo "- fix-failed entries: ${failed}"
        echo "- distribution blockers (latest distilled): ${blockers}"
        echo "- top fail clusters: ${fail_clusters:-none}"
        echo
        echo "## 今日のアップグレード提案"
        due_propose_upgrades | sed 's/^/- /'
        echo
        echo "## 配信パイプライン状況"
        if command -v dsd_summary >/dev/null 2>&1; then
            dsd_summary
        else
            echo "- DSD未ロード (load distribution-stagnation-detector.sh で詳細取得)"
        fi
        echo
        echo "## fix失敗パターン解析"
        if command -v ier_summary >/dev/null 2>&1; then
            ier_summary
        else
            echo "- IER未ロード (load import-error-resolver.sh で詳細取得)"
        fi
        echo
        echo "## Telemetry 記録粒度 (TAR v2033.1)"
        if command -v tar_summary >/dev/null 2>&1; then
            tar_summary 30
        else
            echo "- TAR未ロード (load telemetry-auto-recorder.sh で詳細取得)"
        fi
        echo
        echo "## 過去7日の構造的トレンド (WTA v${DUE_VERSION})"
        if command -v wta_summary >/dev/null 2>&1; then
            wta_summary
        else
            echo "- WTA未ロード (load weekly-trend-aggregator.sh で詳細取得)"
        fi
        echo
        echo "## 解決テンプレ在庫 (SPF v${DUE_VERSION})"
        if command -v spf_summary >/dev/null 2>&1; then
            spf_summary
        else
            echo "- SPF未ロード (load solutions-prefilter.sh で詳細取得)"
        fi
        echo
        echo "## 解決テンプレ昇格 readiness (SAP v${DUE_VERSION})"
        if command -v sap_summary >/dev/null 2>&1; then
            sap_summary
        else
            echo "- SAP未ロード (load spf-auto-promoter.sh で詳細取得)"
        fi
        # v2033.3: SAP 詳細チェックリストを別ファイルへ出力
        local _sap_out=""
        if command -v sap_emit_verification_checklist >/dev/null 2>&1; then
            _sap_out=$(sap_emit_verification_checklist)
            echo "- verification checklist: ${_sap_out}"
        fi
        echo
        echo "## バージョン整合性 (VFD v${DUE_VERSION})"
        if command -v vfd_summary >/dev/null 2>&1; then
            vfd_summary
        else
            echo "- VFD未ロード (load version-file-desync-detector.sh で詳細取得)"
        fi
        echo
        echo "## テレメトリ集計鮮度 (TAS v${DUE_VERSION})"
        if command -v tas_summary >/dev/null 2>&1; then
            tas_summary
            local _tas_age
            _tas_age=$(tas_freshness_days 2>/dev/null || echo "?")
            echo "- aggregates age: ${_tas_age} day(s) since last rebuild"
        else
            echo "- TAS未ロード (load telemetry-aggregates-synchronizer.sh で詳細取得)"
        fi
        echo
        echo "## トレンド停滞アラーム (TRA v${DUE_VERSION})"
        if command -v tra_summary >/dev/null 2>&1; then
            tra_summary
        else
            echo "- TRA未ロード (load trend-repetition-alarm.sh で詳細取得)"
        fi
        echo
        echo "## Iron-Dome 失敗パターン蒸留 (IFD v${DUE_VERSION})"
        if command -v ifd_summary >/dev/null 2>&1; then
            ifd_summary
        else
            echo "- IFD未ロード (load iron-dome-failure-distiller.sh で詳細取得)"
        fi
        echo
        echo "## 次アクション (管理者向け)"
        echo "- 配信ブロッカー解消は b1-b6 (GitHub Release / system_settings / launcher rebuild) が必要"
        echo "- SAP が readiness=ready と判定したテンプレは dry-run で安全に検証可能 (上記 checklist 参照)"
        echo "- VFD verdict が DESYNC の場合は fix_targets を 1 ファイルずつ揃える (TAR=真値)"
        echo "- TRA verdict が CHRONIC_BLOCKAGE の場合は b1-b5 を最優先で処理"
        echo "- 自動マージ可能な範囲は本ファイルに集約済み (本エンジンは destructive 操作を一切行わない)"
    } > "$report_file"

    echo "$report_file"
}

# CLI 直接実行サポート
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-run}" in
        run)
            out=$(due_run)
            echo "[DUE] report: $out"
            ;;
        version)
            echo "$DUE_VERSION"
            ;;
        propose)
            due_propose_upgrades
            ;;
        *)
            echo "usage: $0 {run|version|propose}" >&2
            exit 2
            ;;
    esac
fi
