#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v56.0 - Context Optimizer
# Claudeに渡すコンテキストを最適化してトークン効率を最大化
#
# 問題: 現在のシステムはプロンプトに全てを詰め込む
# - セキュリティルール + ドメイン知識 + 過去パターン + 参照実装 + タスク
# - 結果: 巨大プロンプト → コスト高 + Claudeの注意が分散 → 品質低下
#
# 解決: コンテキストを3層に構造化
# Layer 1 (system-prompt): 不変ルール・制約（Claudeが最も遵守する層）
# Layer 2 (append-system-prompt): ドメイン知識・参照実装（権威ある追加情報）
# Layer 3 (user-prompt): タスク記述のみ（Claudeが集中すべき対象）
#
# v56.0: Claude Maximizer
# ============================================================

# --- グローバル状態 ---
CO_VERSION="56.0"
CO_INITIALIZED=false
CO_TOTAL_SAVED_TOKENS=0
CO_COMPRESSION_COUNT=0

# --- 設定 ---
CO_MAX_CONTEXT_TOKENS=180000    # 最大コンテキストサイズ（≈200K上限の90%）
CO_TARGET_RATIO="0.15:0.35:0.50" # system:append:user の理想比率
CO_CHARS_PER_TOKEN=3.5          # 日本語混在での概算

# ============================================================
# 初期化
# ============================================================
co_init() {
    CO_INITIALIZED=true
    CO_TOTAL_SAVED_TOKENS=0
    CO_COMPRESSION_COUNT=0
    return 0
}

# ============================================================
# トークン数推定（文字数ベース）
# 日本語は1文字≈1.5-2トークン、英語は1単語≈1.3トークン
# 混在テキストでは1文字≈0.7トークン程度として概算
# ============================================================
co_estimate_tokens() {
    local text="$1"
    local char_count=${#text}

    # 日本語文字の割合を推定
    local jp_chars
    jp_chars=$(echo "$text" | grep -oP '[\p{Han}\p{Hiragana}\p{Katakana}]' 2>/dev/null | wc -l || echo "0")
    jp_chars=$((jp_chars + 0))  # 数値化
    local en_chars=$((char_count - jp_chars))

    # 日本語: 1文字≈1.5トークン, 英語: 4文字≈1トークン
    local jp_tokens=$((jp_chars * 15 / 10))
    local en_tokens=$((en_chars / 4))

    echo $((jp_tokens + en_tokens))
}

# ============================================================
# コンテキスト最適化
# 入力: 全コンテキスト要素
# 出力: 最適化された3層プロンプト構造
# ============================================================
co_optimize() {
    local system_prompt="$1"
    local append_prompt="$2"
    local user_prompt="$3"

    local sys_tokens
    sys_tokens=$(co_estimate_tokens "$system_prompt")
    local append_tokens
    append_tokens=$(co_estimate_tokens "$append_prompt")
    local user_tokens
    user_tokens=$(co_estimate_tokens "$user_prompt")
    local total_tokens=$((sys_tokens + append_tokens + user_tokens))

    # 予算内なら最適化不要
    if [[ $total_tokens -le $CO_MAX_CONTEXT_TOKENS ]]; then
        echo "OK"
        return 0
    fi

    CO_COMPRESSION_COUNT=$((CO_COMPRESSION_COUNT + 1))
    local saved_before=$total_tokens

    echo -e "  ${YELLOW:-}⚠️ [CO] コンテキストが大きすぎます (${total_tokens} tokens > ${CO_MAX_CONTEXT_TOKENS})${NC:-}" >&2
    echo -e "  ${CYAN:-}💡 [CO] コンテキスト圧縮を実行${NC:-}" >&2

    echo "COMPRESS"
    return 1
}

# ============================================================
# テキスト圧縮
# 冗長な部分を削除してトークン効率を上げる
# ============================================================
co_compress_text() {
    local text="$1"
    local max_chars="${2:-50000}"

    local compressed="$text"

    # 1. 連続空行を1行に
    compressed=$(echo "$compressed" | sed '/^$/N;/^\n$/d')

    # 2. コメント行の過剰部分を削除（先頭の装飾コメントは保持）
    compressed=$(echo "$compressed" | sed '/^[[:space:]]*\/\/[[:space:]]*={5,}/d')
    compressed=$(echo "$compressed" | sed '/^[[:space:]]*#[[:space:]]*-{5,}/d')

    # 3. 長すぎる行を切り詰め（200文字超）
    compressed=$(echo "$compressed" | awk '{if(length > 200) print substr($0, 1, 200) "..."; else print}')

    # 4. 文字数制限
    if [[ ${#compressed} -gt $max_chars ]]; then
        compressed="${compressed:0:$max_chars}

[コンテキスト圧縮: 残り省略]"
    fi

    local original_tokens
    original_tokens=$(co_estimate_tokens "$text")
    local compressed_tokens
    compressed_tokens=$(co_estimate_tokens "$compressed")
    local saved=$((original_tokens - compressed_tokens))
    CO_TOTAL_SAVED_TOKENS=$((CO_TOTAL_SAVED_TOKENS + saved))

    echo "$compressed"
}

# ============================================================
# 優先度ベースのコンテキスト選択
# 全てを入れる余裕がない場合、重要度順に取捨選択
# ============================================================
co_prioritize_context() {
    local phase="$1"
    local available_tokens="$2"

    # フェーズ別の重要コンテキスト優先度
    case "$phase" in
        backend|api|database)
            echo "security:high enterprise_patterns:high data_integrity:high audit_log:medium memory:low"
            ;;
        frontend|ui_design)
            echo "enterprise_patterns:high memory:medium security:medium data_integrity:low audit_log:low"
            ;;
        implementation)
            echo "enterprise_patterns:high security:high data_integrity:medium audit_log:medium memory:medium"
            ;;
        requirements|design)
            echo "memory:high enterprise_patterns:low security:low data_integrity:low audit_log:low"
            ;;
        *)
            echo "security:medium enterprise_patterns:medium data_integrity:medium audit_log:medium memory:medium"
            ;;
    esac
}

# ============================================================
# 重複検出・除去
# 同じ内容が複数のコンテキスト源から注入されるケースを検出
# ============================================================
co_deduplicate() {
    local text="$1"

    # 完全重複行の除去（順序保持）
    echo "$text" | awk '!seen[$0]++'
}

# ============================================================
# レポート
# ============================================================
co_report() {
    echo -e "\n  ${BOLD:-}═══ Context Optimizer v56.0 レポート ═══${NC:-}"
    echo -e "  圧縮実行回数     : ${CO_COMPRESSION_COUNT}"
    echo -e "  削減トークン合計 : ${CO_TOTAL_SAVED_TOKENS}"
    echo -e "  最大コンテキスト : ${CO_MAX_CONTEXT_TOKENS} tokens"
}

co_report_json() {
    cat <<EOF
{"module":"context-optimizer","version":"${CO_VERSION}","compressions":${CO_COMPRESSION_COUNT},"saved_tokens":${CO_TOTAL_SAVED_TOKENS},"max_context":${CO_MAX_CONTEXT_TOKENS}}
EOF
}

co_score() {
    local score=70
    if [[ $CO_TOTAL_SAVED_TOKENS -gt 10000 ]]; then
        score=90
    elif [[ $CO_TOTAL_SAVED_TOKENS -gt 5000 ]]; then
        score=80
    fi
    echo "$score"
}

# ============================================================
# v59.0: Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "context-optimizer" \
        --version "56.0" \
        --description "プロンプト構造最適化×トークン圧縮" \
        --init "co_init" \
        --report "co_report" \
        --score "co_score" \
        --enable-var "ENABLE_CONTEXT_OPTIMIZER" \
        --cli-flags "--context-optimizer:--no-context-optimizer"
fi

# v2003.1: source時のexit codeを確実に0にする
true
