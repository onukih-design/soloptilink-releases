#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v333.0 - Secret Management Engine
# =============================================================================
# シークレット管理、環境変数暗号化、シークレット漏洩検出。
# HashiCorp Vault / AWS Secrets Manager / .env暗号化対応。
#
# Functions:
#   _sm_init()                    - Initialize
#   _sm_generate_vault_config()   - Generate Vault / Secrets Manager config
#   _sm_generate_env_encryption() - Generate .env encryption tooling
#   _sm_check_secrets()           - Scan codebase for leaked secrets
#   _sm_report() / _sm_score()
# =============================================================================

[[ -n "${_SM_LOADED:-}" ]] && return 0; _SM_LOADED=1

readonly _SM_RED='\033[0;31m'
readonly _SM_GREEN='\033[0;32m'
readonly _SM_YELLOW='\033[0;33m'
readonly _SM_CYAN='\033[0;36m'
readonly _SM_NC='\033[0m'

declare -g SM_VERSION="333.0"
SM_GENERATED=0
SM_ERRORS=0
SM_FILES_WRITTEN=0
SM_VAULT_OK=false
SM_ENCRYPT_OK=false
SM_CHECK_OK=false
SM_SECRETS_FOUND=0

_sm_init() {
    SM_GENERATED=0; SM_ERRORS=0; SM_FILES_WRITTEN=0
    SM_VAULT_OK=false; SM_ENCRYPT_OK=false; SM_CHECK_OK=false; SM_SECRETS_FOUND=0
    echo -e "  ${_SM_GREEN}OK${_SM_NC} Secret Management v${SM_VERSION}" >&2
    return 0
}

_sm_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { SM_FILES_WRITTEN=$((SM_FILES_WRITTEN + 1)); return 0; }
    SM_ERRORS=$((SM_ERRORS + 1)); return 1
}

_sm_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_SM_CYAN}[secrets]${_SM_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_SM_GREEN}[secrets]${_SM_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_SM_YELLOW}[secrets]${_SM_NC} $msg" >&2 ;;
        error) echo -e "  ${_SM_RED}[secrets]${_SM_NC} $msg" >&2 ;;
    esac
}

# =============================================================================
# Generate Vault / Secrets Manager Config
# =============================================================================
_sm_generate_vault_config() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local sec_dir="${project_dir}/infra/secrets"

    _sm_log info "Generating secret management config..."

    # AWS Secrets Manager Terraform
    _sm_write_file "${sec_dir}/secrets-manager.tf" 'resource "aws_secretsmanager_secret" "app" {
  name                    = "${var.project_name}/${var.environment}/app"
  recovery_window_in_days = 7
  kms_key_id              = var.kms_key_id

  tags = {
    Environment = var.environment
    ManagedBy   = "terraform"
  }
}

resource "aws_secretsmanager_secret_version" "app" {
  secret_id = aws_secretsmanager_secret.app.id
  secret_string = jsonencode({
    DATABASE_URL    = var.database_url
    JWT_SECRET      = var.jwt_secret
    REDIS_URL       = var.redis_url
    SMTP_PASSWORD   = var.smtp_password
    S3_ACCESS_KEY   = var.s3_access_key
    S3_SECRET_KEY   = var.s3_secret_key
  })
}

resource "aws_secretsmanager_secret_rotation" "app" {
  secret_id           = aws_secretsmanager_secret.app.id
  rotation_lambda_arn = aws_lambda_function.secret_rotation.arn
  rotation_rules {
    automatically_after_days = 90
  }
}

# IAM policy for ECS task to read secrets
resource "aws_iam_policy" "secrets_read" {
  name = "${var.project_name}-secrets-read"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = ["secretsmanager:GetSecretValue"]
      Resource = [aws_secretsmanager_secret.app.arn]
    }]
  })
}
'

    # TypeScript secrets client
    _sm_write_file "${project_dir}/src/lib/secrets.ts" "$(cat <<'TYPESCRIPT'
import { SecretsManagerClient, GetSecretValueCommand } from '@aws-sdk/client-secrets-manager';

const client = new SecretsManagerClient({ region: process.env.AWS_REGION || 'ap-northeast-1' });

const cache = new Map<string, { value: Record<string, string>; expiry: number }>();
const CACHE_TTL = 5 * 60 * 1000; // 5 minutes

export async function getSecret(secretName: string): Promise<Record<string, string>> {
  const cached = cache.get(secretName);
  if (cached && cached.expiry > Date.now()) return cached.value;

  const command = new GetSecretValueCommand({ SecretId: secretName });
  const response = await client.send(command);

  if (!response.SecretString) throw new Error(`Secret ${secretName} has no value`);

  const value = JSON.parse(response.SecretString);
  cache.set(secretName, { value, expiry: Date.now() + CACHE_TTL });
  return value;
}

export async function getSecretValue(secretName: string, key: string): Promise<string> {
  const secrets = await getSecret(secretName);
  const value = secrets[key];
  if (!value) throw new Error(`Key ${key} not found in secret ${secretName}`);
  return value;
}

// For local development, fall back to .env
export function getEnvOrSecret(key: string): string {
  const value = process.env[key];
  if (!value) throw new Error(`Missing environment variable: ${key}`);
  return value;
}
TYPESCRIPT
)"

    _sm_log ok "Secret management config generated"
    SM_VAULT_OK=true
    SM_GENERATED=$((SM_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate .env Encryption
# =============================================================================
_sm_generate_env_encryption() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _sm_log info "Generating .env encryption tooling..."

    _sm_write_file "${project_dir}/scripts/encrypt-env.sh" '#!/usr/bin/env bash
set -euo pipefail
# Encrypt .env files for safe storage in git

ENV_FILE="${1:-.env}"
ENCRYPTED_FILE="${ENV_FILE}.enc"
KEY_FILE=".env.key"

if [[ ! -f "$ENV_FILE" ]]; then
  echo "Error: ${ENV_FILE} not found"
  exit 1
fi

# Generate key if not exists
if [[ ! -f "$KEY_FILE" ]]; then
  openssl rand -base64 32 > "$KEY_FILE"
  echo "Generated encryption key: ${KEY_FILE}"
  echo "IMPORTANT: Add ${KEY_FILE} to .gitignore!"
fi

openssl enc -aes-256-cbc -salt -pbkdf2 -iter 100000 \
  -in "$ENV_FILE" -out "$ENCRYPTED_FILE" \
  -pass "file:${KEY_FILE}"

echo "Encrypted: ${ENV_FILE} -> ${ENCRYPTED_FILE}"
'

    _sm_write_file "${project_dir}/scripts/decrypt-env.sh" '#!/usr/bin/env bash
set -euo pipefail

ENCRYPTED_FILE="${1:-.env.enc}"
OUTPUT_FILE="${ENCRYPTED_FILE%.enc}"
KEY_FILE=".env.key"

if [[ ! -f "$ENCRYPTED_FILE" ]]; then echo "Error: ${ENCRYPTED_FILE} not found"; exit 1; fi
if [[ ! -f "$KEY_FILE" ]]; then echo "Error: ${KEY_FILE} not found"; exit 1; fi

openssl enc -aes-256-cbc -d -pbkdf2 -iter 100000 \
  -in "$ENCRYPTED_FILE" -out "$OUTPUT_FILE" \
  -pass "file:${KEY_FILE}"

echo "Decrypted: ${ENCRYPTED_FILE} -> ${OUTPUT_FILE}"
'

    chmod +x "${project_dir}/scripts/encrypt-env.sh" "${project_dir}/scripts/decrypt-env.sh" 2>/dev/null || true

    _sm_log ok ".env encryption tooling generated"
    SM_ENCRYPT_OK=true
    SM_GENERATED=$((SM_GENERATED + 1))
    return 0
}

# =============================================================================
# Check for Leaked Secrets
# =============================================================================
_sm_check_secrets() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    SM_SECRETS_FOUND=0

    _sm_log info "Scanning for leaked secrets in ${project_dir}..."

    local patterns=(
        'AKIA[0-9A-Z]{16}'                    # AWS Access Key
        'sk_live_[0-9a-zA-Z]{24,}'            # Stripe Secret Key
        'ghp_[0-9a-zA-Z]{36}'                 # GitHub Personal Token
        'xox[bpsa]-[0-9a-zA-Z-]{10,}'         # Slack Token
        'ya29\.[0-9A-Za-z_-]+'                # Google OAuth
        'AIza[0-9A-Za-z_-]{35}'               # Google API Key
        'sk-[0-9a-zA-Z]{40,}'                 # OpenAI Key
        '[0-9a-f]{32,40}'                      # Generic hex tokens (loose)
    )

    for pattern in "${patterns[@]}"; do
        local matches
        matches=$(grep -rlE "$pattern" "$project_dir" \
            --include="*.ts" --include="*.js" --include="*.json" --include="*.yaml" --include="*.yml" \
            --exclude-dir=node_modules --exclude-dir=.git --exclude-dir=dist 2>/dev/null | head -20)

        if [[ -n "$matches" ]]; then
            local count
            count=$(echo "$matches" | wc -l | tr -d ' ')
            # Skip common false positives
            if echo "$matches" | grep -qv "\.lock\|package-lock\|test\|mock\|example\|template"; then
                SM_SECRETS_FOUND=$((SM_SECRETS_FOUND + count))
                _sm_log warn "Potential secret match (${pattern}): ${count} files"
            fi
        fi
    done

    # Check .gitignore for sensitive files
    local gitignore="${project_dir}/.gitignore"
    if [[ -f "$gitignore" ]]; then
        local missing_patterns=0
        for pat in ".env" ".env.local" "*.key" "*.pem" "credentials"; do
            if ! grep -q "$pat" "$gitignore" 2>/dev/null; then
                _sm_log warn ".gitignore missing: ${pat}"
                missing_patterns=$((missing_patterns + 1))
            fi
        done
        [[ $missing_patterns -eq 0 ]] && _sm_log ok ".gitignore covers sensitive files"
    else
        _sm_log warn "No .gitignore found!"
    fi

    if [[ $SM_SECRETS_FOUND -eq 0 ]]; then
        _sm_log ok "No leaked secrets detected"
    else
        _sm_log error "${SM_SECRETS_FOUND} potential secret leaks found!"
    fi

    SM_CHECK_OK=true
    SM_GENERATED=$((SM_GENERATED + 1))
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_sm_report() {
    echo -e "\n  ${_SM_CYAN}=== Secret Management v${SM_VERSION} ===${_SM_NC}"
    echo -e "  Generated: ${SM_GENERATED} | Files: ${SM_FILES_WRITTEN} | Errors: ${SM_ERRORS}"
    echo -e "  Vault: $( ${SM_VAULT_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Encryption: $( ${SM_ENCRYPT_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Secret Scan: $( ${SM_CHECK_OK} && echo 'OK' || echo 'SKIP') (found: ${SM_SECRETS_FOUND})"
}

_sm_score() {
    local score=50
    ${SM_VAULT_OK} && score=$((score + 15))
    ${SM_ENCRYPT_OK} && score=$((score + 10))
    ${SM_CHECK_OK} && score=$((score + 10))
    [[ ${SM_SECRETS_FOUND} -eq 0 ]] && score=$((score + 10))
    [[ ${SM_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "secret-management" --version "333.0" \
        --description "シークレット管理 Vault/暗号化/漏洩検出 (v333)" \
        --init "_sm_init" --report "_sm_report" --score "_sm_score" \
        --enable-var "ENABLE_SECRET_MGMT" --cli-flags "--secret-mgmt:--no-secret-mgmt"
fi

# v2003.1: source時のexit codeを確実に0にする
true
