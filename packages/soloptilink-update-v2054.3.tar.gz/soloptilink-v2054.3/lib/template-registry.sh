#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v19.0 - Template Registry
# =============================================================================
# プロジェクトテンプレートの登録・検索・適用・バージョン管理
# 過去のプロジェクト成果物をテンプレート化して再利用を促進
#
# Functions:
#   treg_init / treg_register / treg_unregister / treg_list / treg_search
#   treg_apply / treg_preview / treg_detect_from_project
#   treg_generate_builtin_templates / treg_get_template_info
#   treg_report / treg_export_json
#
# Usage: source lib/template-registry.sh
# =============================================================================

[[ -n "${_TEMPLATE_REGISTRY_LOADED:-}" ]] && return 0
_TEMPLATE_REGISTRY_LOADED=1

TR_VERSION="19.0"
TR_REGISTRY_DIR=""
TR_REGISTRY_FILE=""
TR_BUILTIN_DIR=""
TR_TOTAL=0
TR_APPLIED=0
TR_EXCLUDE_PATTERNS=(".git" "node_modules" "__pycache__" ".next" ".nuxt" "dist" "build" "*.pyc" "*.pyo" ".env" ".env.local" ".DS_Store")

# =============================================================================
# 内部関数
# =============================================================================
_treg_log() {
    local level="$1"; shift
    local color="${NC:-}"
    case "$level" in
        INFO) color="${CYAN:-}" ;; PASS) color="${GREEN:-}" ;;
        WARN) color="${YELLOW:-}" ;; ERROR) color="${RED:-}" ;;
        SECTION) color="${BOLD:-}" ;;
    esac
    echo -e "  ${color}[TR:${level}]${NC:-} $*" >&2
}

_treg_record() {
    local event_type="$1" message="$2"
    local ts events_file
    ts=$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date '+%Y-%m-%dT%H:%M:%SZ')
    events_file="${SESSION_LOG_DIR:-/tmp}/observatory/events.jsonl"
    [[ -d "$(dirname "$events_file")" ]] || mkdir -p "$(dirname "$events_file")" 2>/dev/null
    printf '{"timestamp":"%s","type":"TR","event":"%s","data":"%s","module":"template-registry","version":"%s"}\n' \
        "$ts" "$event_type" "$message" "$TR_VERSION" >> "$events_file" 2>/dev/null || true
}

_treg_ensure_registry() { [[ ! -f "$TR_REGISTRY_FILE" ]] && echo '[]' > "$TR_REGISTRY_FILE" 2>/dev/null || true; }
_treg_read_registry() { _treg_ensure_registry; cat "$TR_REGISTRY_FILE" 2>/dev/null || echo '[]'; }
_treg_write_registry() { echo "$1" > "$TR_REGISTRY_FILE" 2>/dev/null || true; }
_treg_count_templates() { _treg_read_registry | python3 -c "import json,sys; print(len(json.load(sys.stdin)))" 2>/dev/null || echo "0"; }
_treg_dir_size() { [[ -d "$1" ]] && du -sh "$1" 2>/dev/null | awk '{print $1}' || echo "0B"; }

# --- _treg_copy_with_excludes: 除外パターン付きコピー ---
_treg_copy_with_excludes() {
    local src="$1" dst="$2"
    if command -v rsync &>/dev/null; then
        local exclude_args=""
        for pat in "${TR_EXCLUDE_PATTERNS[@]}"; do exclude_args+=" --exclude=${pat}"; done
        eval rsync -a ${exclude_args} "${src}/" "${dst}/" 2>/dev/null
    else
        cp -R "${src}/." "${dst}/" 2>/dev/null || return 1
        for pat in ".git" "node_modules" "__pycache__" ".next" ".nuxt" "dist" "build"; do
            find "$dst" -name "$pat" -type d -exec rm -rf {} + 2>/dev/null || true
        done
        for pat in "*.pyc" "*.pyo" ".env" ".env.local" ".DS_Store"; do
            find "$dst" -name "$pat" -type f -delete 2>/dev/null || true
        done
    fi
}

# =============================================================================
# 1. treg_init - レジストリ初期化
# =============================================================================
treg_init() {
    TR_REGISTRY_DIR="${HOME}/.soloptilink/templates"
    TR_REGISTRY_FILE="${TR_REGISTRY_DIR}/registry.json"
    TR_BUILTIN_DIR="${CHAIN_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/plugins/templates"
    TR_TOTAL=0; TR_APPLIED=0
    mkdir -p "$TR_REGISTRY_DIR" "$TR_BUILTIN_DIR" 2>/dev/null || true
    _treg_ensure_registry
    TR_TOTAL=$(_treg_count_templates)
    _treg_log INFO "Template Registry v${TR_VERSION} initialized (${TR_TOTAL} templates)"
    _treg_record "INIT" "registry_dir=${TR_REGISTRY_DIR}"
    return 0
}

# =============================================================================
# 2. treg_register - テンプレート登録
# =============================================================================
treg_register() {
    local name="${1:-}" source_dir="${2:-}" description="${3:-No description}" tags="${4:-}"
    [[ -z "$name" ]] && { _treg_log ERROR "Template name is required"; return 1; }
    [[ -z "$source_dir" || ! -d "$source_dir" ]] && { _treg_log ERROR "Valid source directory required"; return 1; }

    local safe_name
    safe_name=$(echo "$name" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9_-]/-/g;s/--*/-/g;s/^-//;s/-$//')
    [[ -z "$safe_name" ]] && { _treg_log ERROR "Invalid template name: ${name}"; return 1; }

    local template_dir="${TR_REGISTRY_DIR}/${safe_name}"
    _treg_log INFO "Registering template: ${safe_name} from ${source_dir}"
    [[ -d "$template_dir" ]] && { _treg_log WARN "Overwriting existing template '${safe_name}'"; rm -rf "$template_dir" 2>/dev/null || true; }
    mkdir -p "$template_dir" 2>/dev/null || true

    _treg_copy_with_excludes "$source_dir" "$template_dir" || { _treg_log ERROR "Failed to copy template files"; return 1; }

    local created_at abs_source size
    created_at=$(date -u '+%Y-%m-%dT%H:%M:%SZ' 2>/dev/null || date '+%Y-%m-%dT%H:%M:%SZ')
    abs_source=$(cd "$source_dir" 2>/dev/null && pwd || echo "$source_dir")
    size=$(_treg_dir_size "$template_dir")

    local registry updated
    registry=$(_treg_read_registry)
    updated=$(python3 -c "
import json, sys
registry = json.loads(sys.stdin.read())
registry = [e for e in registry if e.get('name') != '${safe_name}']
tags = [t.strip() for t in '${tags}'.split(',') if t.strip()] if '${tags}' else []
registry.append({'name':'${safe_name}','description':$(python3 -c "import json;print(json.dumps('${description}'))" 2>/dev/null || echo "\"${description}\""),'tags':tags,'created_at':'${created_at}','source_path':'${abs_source}','version':'${TR_VERSION}','size':'${size}'})
print(json.dumps(registry, indent=2, ensure_ascii=False))
" <<< "$registry" 2>/dev/null)

    [[ -z "$updated" ]] && { _treg_log ERROR "Failed to update registry"; return 1; }
    _treg_write_registry "$updated"
    TR_TOTAL=$(_treg_count_templates)
    _treg_log PASS "Template '${safe_name}' registered (${size})"
    _treg_record "REGISTER" "name=${safe_name},tags=${tags},size=${size}"
    return 0
}

# =============================================================================
# 3. treg_unregister - テンプレート登録解除
# =============================================================================
treg_unregister() {
    local name="${1:-}"
    [[ -z "$name" ]] && { _treg_log ERROR "Template name is required"; return 1; }
    [[ -d "${TR_REGISTRY_DIR}/${name}" ]] && rm -rf "${TR_REGISTRY_DIR}/${name}" 2>/dev/null || true

    local registry updated
    registry=$(_treg_read_registry)
    updated=$(python3 -c "
import json, sys
r = json.loads(sys.stdin.read())
print(json.dumps([e for e in r if e.get('name') != '${name}'], indent=2, ensure_ascii=False))
" <<< "$registry" 2>/dev/null)
    [[ -n "$updated" ]] && _treg_write_registry "$updated"
    TR_TOTAL=$(_treg_count_templates)
    _treg_log PASS "Template '${name}' unregistered"
    _treg_record "UNREGISTER" "name=${name}"
    return 0
}

# =============================================================================
# 4. treg_list - 一覧表示
# =============================================================================
treg_list() {
    _treg_ensure_registry
    local registry count
    registry=$(_treg_read_registry)
    count=$(echo "$registry" | python3 -c "import json,sys; print(len(json.load(sys.stdin)))" 2>/dev/null || echo "0")
    if [[ "$count" -eq 0 ]]; then _treg_log INFO "No templates registered"; return 0; fi

    _treg_log SECTION "=== Template Registry (${count} templates) ==="
    echo
    printf "  ${BOLD:-}%-20s %-30s %-20s %-12s %-8s${NC:-}\n" "Name" "Description" "Tags" "Created" "Size"
    printf "  %-20s %-30s %-20s %-12s %-8s\n" "--------------------" "------------------------------" "--------------------" "------------" "--------"
    echo "$registry" | python3 -c "
import json, sys
for e in json.load(sys.stdin):
    print(f'  {e.get(\"name\",\"?\")[:20]:<20} {e.get(\"description\",\"\")[:30]:<30} {\",\".join(e.get(\"tags\",[]))[:20]:<20} {e.get(\"created_at\",\"?\")[:10]:<12} {e.get(\"size\",\"?\")[:8]:<8}')
" 2>/dev/null
    echo
    _treg_record "LIST" "count=${count}"
    return 0
}

# =============================================================================
# 5. treg_search - 全文検索
# =============================================================================
treg_search() {
    local query="${1:-}"
    [[ -z "$query" ]] && { _treg_log ERROR "Search query is required"; return 1; }
    local registry results
    registry=$(_treg_read_registry)
    _treg_log INFO "Searching for: '${query}'"
    results=$(python3 -c "
import json, sys
q = '${query}'.lower()
matches = [e for e in json.load(sys.stdin) if q in f'{e.get(\"name\",\"\")} {e.get(\"description\",\"\")} {\" \".join(e.get(\"tags\",[]))}'.lower()]
if not matches: print('NO_MATCH')
else:
    for m in matches: print(f'  {m.get(\"name\",\"?\")[:20]:<20} {m.get(\"description\",\"\")[:30]:<30} {\",\".join(m.get(\"tags\",[]))[:20]:<20}')
" <<< "$registry" 2>/dev/null)
    if [[ "$results" == "NO_MATCH" ]]; then _treg_log WARN "No matches for '${query}'"; return 1; fi
    echo
    printf "  ${BOLD:-}%-20s %-30s %-20s${NC:-}\n" "Name" "Description" "Tags"
    printf "  %-20s %-30s %-20s\n" "--------------------" "------------------------------" "--------------------"
    echo "$results"
    echo
    _treg_record "SEARCH" "query=${query}"
    return 0
}

# =============================================================================
# 6. treg_apply - テンプレート適用 (プレースホルダー置換付き)
# =============================================================================
treg_apply() {
    local name="${1:-}" target_dir="${2:-}"
    [[ -z "$name" ]] && { _treg_log ERROR "Template name is required"; return 1; }
    [[ -z "$target_dir" ]] && { _treg_log ERROR "Target directory is required"; return 1; }
    local template_dir="${TR_REGISTRY_DIR}/${name}"
    [[ ! -d "$template_dir" ]] && { _treg_log ERROR "Template not found: ${name}"; return 1; }

    _treg_log INFO "Applying '${name}' to: ${target_dir}"
    mkdir -p "$target_dir" 2>/dev/null || { _treg_log ERROR "Cannot create target dir"; return 1; }

    if command -v rsync &>/dev/null; then
        rsync -a "${template_dir}/" "${target_dir}/" 2>/dev/null
    else
        cp -R "${template_dir}/." "${target_dir}/" 2>/dev/null
    fi || { _treg_log ERROR "Failed to copy template files"; return 1; }

    local project_name author current_date version file_count=0
    project_name=$(basename "$target_dir")
    author="${USER:-developer}"
    current_date=$(date '+%Y-%m-%d' 2>/dev/null || date '+%Y-%m-%d')
    version="1.0.0"

    while IFS= read -r -d '' f; do
        if file "$f" 2>/dev/null | grep -q "text"; then
            if grep -q '{{PROJECT_NAME}}\|{{AUTHOR}}\|{{DATE}}\|{{VERSION}}' "$f" 2>/dev/null; then
                sed -i.bak -e "s/{{PROJECT_NAME}}/${project_name}/g" -e "s/{{AUTHOR}}/${author}/g" \
                    -e "s/{{DATE}}/${current_date}/g" -e "s/{{VERSION}}/${version}/g" "$f" 2>/dev/null || true
                rm -f "${f}.bak" 2>/dev/null || true
                (( file_count++ ))
            fi
        fi
    done < <(find "$target_dir" -type f -print0 2>/dev/null)

    TR_APPLIED=$((TR_APPLIED + 1))
    _treg_log PASS "Template '${name}' applied (${file_count} files updated)"
    _treg_record "APPLY" "name=${name},target=${target_dir},files=${file_count}"
    return 0
}

# =============================================================================
# 7. treg_preview - テンプレートプレビュー
# =============================================================================
treg_preview() {
    local name="${1:-}"
    [[ -z "$name" ]] && { _treg_log ERROR "Template name is required"; return 1; }
    local template_dir="${TR_REGISTRY_DIR}/${name}"
    [[ ! -d "$template_dir" ]] && { _treg_log ERROR "Template not found: ${name}"; return 1; }

    local info
    info=$(treg_get_template_info "$name" 2>/dev/null)
    echo
    _treg_log SECTION "=== Template Preview: ${name} ==="
    [[ -n "$info" && "$info" != "null" ]] && echo "$info" | python3 -c "
import json,sys
i=json.load(sys.stdin)
for k in ['name','description','tags','created_at','source_path','size']:
    v=i.get(k,'-'); v=', '.join(v) if isinstance(v,list) else str(v)
    print(f'  {k+\":\":<15} {v}')
" 2>/dev/null

    echo
    _treg_log INFO "Directory Structure:"
    if command -v tree &>/dev/null; then
        tree -L 3 --noreport "$template_dir" 2>/dev/null | head -40
    else
        find "$template_dir" -maxdepth 3 -print 2>/dev/null | while IFS= read -r p; do
            local rel="${p#$template_dir}"; [[ -z "$rel" ]] && continue
            local d; d=$(echo "$rel" | tr -cd '/' | wc -c | tr -d ' ')
            local indent=""; local i=0; while [[ $i -lt $d ]]; do indent+="  "; (( i++ )); done
            [[ -d "$p" ]] && echo "  ${indent}$(basename "$p")/" || echo "  ${indent}$(basename "$p")"
        done | head -40
    fi

    echo
    _treg_log INFO "Key Files:"
    for kf in package.json requirements.txt Cargo.toml go.mod Dockerfile; do
        local found; found=$(find "$template_dir" -maxdepth 2 -name "$kf" -type f 2>/dev/null | head -1)
        [[ -n "$found" ]] && echo "    ${found#$template_dir/} ($(wc -l < "$found" 2>/dev/null | tr -d ' ') lines)"
    done
    echo
    _treg_record "PREVIEW" "name=${name}"
    return 0
}

# =============================================================================
# 8. treg_detect_from_project - プロジェクトからテンプレート候補自動検出
# =============================================================================
treg_detect_from_project() {
    local project_dir="${1:-.}"
    [[ ! -d "$project_dir" ]] && { _treg_log ERROR "Directory not found: ${project_dir}"; return 1; }
    _treg_log INFO "Detecting template candidate from: ${project_dir}"

    local framework="unknown" language="unknown" suggested_tags=""

    if [[ -f "${project_dir}/package.json" ]]; then
        language="javascript"
        local pkg; pkg=$(cat "${project_dir}/package.json" 2>/dev/null || echo "{}")
        for fw_pair in "next:nextjs:nextjs,react" "nuxt:nuxt:nuxt,vue" "vue:vue:vue" "react:react:react" \
                       "express:express:express,nodejs,api" "fastify:fastify:fastify,nodejs,api" "hono:hono:hono,nodejs,api"; do
            IFS=: read -r key fw tags_val <<< "$fw_pair"
            if echo "$pkg" | grep -q "\"${key}\"" 2>/dev/null; then framework="$fw"; suggested_tags="$tags_val"; break; fi
        done
        [[ "$framework" == "unknown" ]] && { framework="nodejs"; suggested_tags="nodejs,javascript"; }
        [[ -f "${project_dir}/tsconfig.json" ]] && { language="typescript"; suggested_tags="${suggested_tags},typescript"; }
        [[ -d "${project_dir}/prisma" ]] && suggested_tags="${suggested_tags},prisma"
    elif [[ -f "${project_dir}/requirements.txt" || -f "${project_dir}/pyproject.toml" ]]; then
        language="python"
        local req=""; [[ -f "${project_dir}/requirements.txt" ]] && req=$(cat "${project_dir}/requirements.txt" 2>/dev/null)
        if echo "$req" | grep -qi "django" 2>/dev/null; then framework="django"; suggested_tags="django,python,web"
        elif echo "$req" | grep -qi "fastapi" 2>/dev/null; then framework="fastapi"; suggested_tags="fastapi,python,api"
        elif echo "$req" | grep -qi "flask" 2>/dev/null; then framework="flask"; suggested_tags="flask,python,web"
        else framework="python"; suggested_tags="python"; fi
    elif [[ -f "${project_dir}/Cargo.toml" ]]; then
        language="rust"; framework="rust"; suggested_tags="rust,cargo"
        grep -q "actix" "${project_dir}/Cargo.toml" 2>/dev/null && { framework="actix"; suggested_tags="rust,actix,web"; }
        grep -q "axum" "${project_dir}/Cargo.toml" 2>/dev/null && { framework="axum"; suggested_tags="rust,axum,web"; }
    elif [[ -f "${project_dir}/go.mod" ]]; then
        language="go"; framework="go"; suggested_tags="go,golang"
        grep -q "gin-gonic" "${project_dir}/go.mod" 2>/dev/null && { framework="gin"; suggested_tags="go,gin,web"; }
    elif [[ -f "${project_dir}/index.html" ]]; then
        language="html"; framework="static"; suggested_tags="html,css,static"
        [[ -f "${project_dir}/tailwind.config.js" || -f "${project_dir}/tailwind.config.ts" ]] && suggested_tags="html,tailwindcss,static"
    fi
    [[ -f "${project_dir}/Dockerfile" || -f "${project_dir}/docker-compose.yml" ]] && suggested_tags="${suggested_tags},docker"

    local dir_name suggested_name
    dir_name=$(basename "$project_dir" | tr '[:upper:]' '[:lower:]' | sed 's/[^a-z0-9_-]/-/g')
    suggested_name="${framework}-${dir_name}"
    suggested_tags=$(echo "$suggested_tags" | tr ',' '\n' | sort -u | grep -v '^$' | tr '\n' ',' | sed 's/,$//')

    _treg_log PASS "Detected: ${language}/${framework} -> ${suggested_name} [${suggested_tags}]"
    _treg_record "DETECT" "language=${language},framework=${framework}"
    printf '{"language":"%s","framework":"%s","suggested_name":"%s","suggested_tags":"%s"}' \
        "$language" "$framework" "$suggested_name" "$suggested_tags"
}

# =============================================================================
# 9. treg_generate_builtin_templates - ビルトインテンプレート生成
# =============================================================================
treg_generate_builtin_templates() {
    _treg_log INFO "Generating builtin templates..."
    local bd="$TR_BUILTIN_DIR"
    mkdir -p "$bd" 2>/dev/null || true

    # --- nextjs-saas ---
    if [[ ! -d "${bd}/nextjs-saas" ]]; then
        mkdir -p "${bd}/nextjs-saas/src/app" "${bd}/nextjs-saas/prisma" 2>/dev/null || true
        cat > "${bd}/nextjs-saas/package.json" <<'EOF'
{"name":"{{PROJECT_NAME}}","version":"{{VERSION}}","private":true,"scripts":{"dev":"next dev","build":"next build","start":"next start"},"dependencies":{"next":"^14.0.0","react":"^18.0.0","react-dom":"^18.0.0","@prisma/client":"^5.0.0","next-auth":"^5.0.0","zod":"^3.22.0"},"devDependencies":{"typescript":"^5.0.0","prisma":"^5.0.0","tailwindcss":"^3.4.0"}}
EOF
        cat > "${bd}/nextjs-saas/prisma/schema.prisma" <<'EOF'
generator client { provider = "prisma-client-js" }
datasource db { provider = "postgresql"; url = env("DATABASE_URL") }
model User { id String @id @default(uuid()); email String @unique; name String?; role String @default("user"); tenantId String; tenant Tenant @relation(fields: [tenantId], references: [id]); createdAt DateTime @default(now()); updatedAt DateTime @updatedAt; @@index([tenantId]) }
model Tenant { id String @id @default(uuid()); name String; slug String @unique; plan String @default("free"); users User[]; createdAt DateTime @default(now()); updatedAt DateTime @updatedAt }
EOF
        _treg_log PASS "  nextjs-saas created"
    fi

    # --- express-api ---
    if [[ ! -d "${bd}/express-api" ]]; then
        mkdir -p "${bd}/express-api/src/routes" "${bd}/express-api/src/middleware" 2>/dev/null || true
        cat > "${bd}/express-api/package.json" <<'EOF'
{"name":"{{PROJECT_NAME}}","version":"{{VERSION}}","private":true,"scripts":{"dev":"tsx watch src/index.ts","build":"tsc","start":"node dist/index.js"},"dependencies":{"express":"^4.18.0","@prisma/client":"^5.0.0","helmet":"^7.0.0","cors":"^2.8.0","zod":"^3.22.0"},"devDependencies":{"typescript":"^5.0.0","tsx":"^4.0.0","@types/express":"^4.17.0"}}
EOF
        cat > "${bd}/express-api/src/index.ts" <<'EOF'
import express from 'express'; import helmet from 'helmet'; import cors from 'cors';
const app = express(); const PORT = process.env.PORT || 3000;
app.use(helmet()); app.use(cors()); app.use(express.json());
app.get('/health', (_req, res) => { res.json({ status: 'ok', project: '{{PROJECT_NAME}}' }); });
app.listen(PORT, () => { console.log(`{{PROJECT_NAME}} running on port ${PORT}`); });
EOF
        _treg_log PASS "  express-api created"
    fi

    # --- flask-app ---
    if [[ ! -d "${bd}/flask-app" ]]; then
        mkdir -p "${bd}/flask-app/app/routes" "${bd}/flask-app/app/models" 2>/dev/null || true
        printf 'Flask>=3.0.0\nFlask-SQLAlchemy>=3.1.0\nFlask-Migrate>=4.0.0\npython-dotenv>=1.0.0\ngunicorn>=21.0.0\n' > "${bd}/flask-app/requirements.txt"
        cat > "${bd}/flask-app/app/__init__.py" <<'EOF'
from flask import Flask; from flask_sqlalchemy import SQLAlchemy
db = SQLAlchemy()
def create_app():
    app = Flask(__name__); app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///{{PROJECT_NAME}}.db'
    app.config['SECRET_KEY'] = 'change-me-in-production'; db.init_app(app); return app
EOF
        _treg_log PASS "  flask-app created"
    fi

    # --- static-site ---
    if [[ ! -d "${bd}/static-site" ]]; then
        mkdir -p "${bd}/static-site/src/css" "${bd}/static-site/public" 2>/dev/null || true
        cat > "${bd}/static-site/index.html" <<'EOF'
<!DOCTYPE html><html lang="ja"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1.0"><title>{{PROJECT_NAME}}</title><script src="https://cdn.tailwindcss.com"></script></head><body class="bg-gray-50 min-h-screen"><header class="bg-white shadow"><div class="max-w-7xl mx-auto py-6 px-4"><h1 class="text-3xl font-bold text-gray-900">{{PROJECT_NAME}}</h1></div></header><main class="max-w-7xl mx-auto py-6 px-4"><p class="text-gray-600">Built with SoloptiLink Chain v19.0</p></main></body></html>
EOF
        _treg_log PASS "  static-site created"
    fi

    _treg_log PASS "Builtin templates generated in: ${bd}"
    _treg_record "BUILTIN_GENERATE" "dir=${bd}"
    return 0
}

# =============================================================================
# 10. treg_get_template_info - テンプレート詳細情報 (JSON)
# =============================================================================
treg_get_template_info() {
    local name="${1:-}"
    [[ -z "$name" ]] && { _treg_log ERROR "Template name is required"; return 1; }
    _treg_ensure_registry
    local info
    info=$(_treg_read_registry | python3 -c "
import json, sys
for e in json.load(sys.stdin):
    if e.get('name') == '${name}': print(json.dumps(e, indent=2, ensure_ascii=False)); sys.exit(0)
print('null')
" 2>/dev/null)
    [[ "$info" == "null" || -z "$info" ]] && { _treg_log WARN "Template not found: ${name}"; echo "null"; return 1; }
    echo "$info"
    return 0
}

# =============================================================================
# 11. treg_report - サマリーレポート
# =============================================================================
treg_report() {
    _treg_ensure_registry
    TR_TOTAL=$(_treg_count_templates)
    local registry stats
    registry=$(_treg_read_registry)
    stats=$(echo "$registry" | python3 -c "
import json, sys
r=json.load(sys.stdin); tags=[]
for e in r: tags.extend(e.get('tags',[]))
tc={}
for t in tags: tc[t]=tc.get(t,0)+1
top=sorted(tc.items(),key=lambda x:-x[1])[:5]
print(f'{len(r)}|{len(set(tags))}|{(\", \".join(f\"{t}({c})\" for t,c in top)) if top else \"-\"}')
" 2>/dev/null || echo "0|0|-")

    local total unique_tags top_tags
    IFS='|' read -r total unique_tags top_tags <<< "$stats"
    echo
    printf "  ${BOLD:-}+----------------------------------------------+${NC:-}\n"
    printf "  ${BOLD:-}|   Template Registry Report (v${TR_VERSION})          |${NC:-}\n"
    printf "  ${BOLD:-}+----------------------------------------------+${NC:-}\n"
    printf "  ${BOLD:-}|${NC:-}  ${CYAN:-}Total Templates:${NC:-}   %-24s${BOLD:-}|${NC:-}\n" "$total"
    printf "  ${BOLD:-}|${NC:-}  ${CYAN:-}Unique Tags:${NC:-}       %-24s${BOLD:-}|${NC:-}\n" "$unique_tags"
    printf "  ${BOLD:-}|${NC:-}  ${CYAN:-}Applied (session):${NC:-} %-24s${BOLD:-}|${NC:-}\n" "$TR_APPLIED"
    printf "  ${BOLD:-}|${NC:-}  ${CYAN:-}Top Tags:${NC:-}          %-24s${BOLD:-}|${NC:-}\n" "$top_tags"
    printf "  ${BOLD:-}+----------------------------------------------+${NC:-}\n"
    echo
    _treg_record "REPORT" "total=${total},applied=${TR_APPLIED}"
    return 0
}

# =============================================================================
# 12. treg_export_json - レジストリJSON出力
# =============================================================================
treg_export_json() {
    local output_file="${1:-}"
    if [[ -z "$output_file" ]]; then
        local log_dir="${SESSION_LOG_DIR:-/tmp}/observatory"
        mkdir -p "$log_dir" 2>/dev/null || true
        output_file="${log_dir}/template-registry-$(date '+%Y%m%d-%H%M%S').json"
    fi
    mkdir -p "$(dirname "$output_file")" 2>/dev/null || true
    TR_TOTAL=$(_treg_count_templates)

    _treg_read_registry | python3 -c "
import json, sys
r=json.load(sys.stdin)
print(json.dumps({'report_type':'template_registry','version':'${TR_VERSION}','generated_at':'$(date -u '+%Y-%m-%dT%H:%M:%SZ' 2>/dev/null)','summary':{'total_templates':len(r),'applied_session':${TR_APPLIED}},'templates':r},indent=2,ensure_ascii=False))
" > "$output_file" 2>/dev/null

    _treg_log PASS "JSON exported: ${output_file}"
    _treg_record "EXPORT" "file=${output_file}"
    echo "$output_file"
    return 0
}

# =============================================================================
# Usage:
#   source lib/template-registry.sh
#   treg_init
#   treg_register "my-tpl" "/path/to/project" "Description" "tag1,tag2"
#   treg_list / treg_search "nextjs" / treg_apply "my-tpl" "/new/project"
#   treg_preview "my-tpl" / treg_detect_from_project "/path"
#   treg_generate_builtin_templates / treg_report / treg_export_json
# =============================================================================
