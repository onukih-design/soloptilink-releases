#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v353.0 - A/B Test Framework
# =============================================================================
# A/Bテスト実験×バリアント割当×統計分析×レポート
#
# 機能:
#   - 実験作成（仮説/バリアント/トラフィック割当）
#   - ユーザーバリアント割当（一貫性ハッシュ）
#   - 統計分析（Z検定/カイ二乗/ベイジアン）
#   - 結果レポート・可視化
#   - 早期停止判定
#
# 全globals: ABTF_ prefix
# =============================================================================

[[ -n "${_ABTF_LOADED:-}" ]] && return 0; _ABTF_LOADED=1

# =============================================================================
# State
# =============================================================================
ABTF_VERSION="353.0"
ABTF_GENERATED=0
ABTF_ERRORS=0
ABTF_PHASE="ab_test"
ABTF_FILES_CREATED=()
ABTF_EXPERIMENTS_CREATED=0

: "${GREEN:=\033[0;32m}" ; : "${RED:=\033[0;31m}" ; : "${YELLOW:=\033[0;33m}"
: "${CYAN:=\033[0;36m}" ; : "${BOLD:=\033[1m}" ; : "${NC:=\033[0m}"

_abtf_log() { echo -e "  ${CYAN}[ABTF]${NC} $*"; }
_abtf_ok() { echo -e "  ${GREEN}[ABTF]${NC} $*"; }
_abtf_warn() { echo -e "  ${YELLOW}[ABTF]${NC} $*"; }
_abtf_err() { echo -e "  ${RED}[ABTF]${NC} $*"; }

_abtf_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        ABTF_FILES_CREATED+=("$filepath")
        ABTF_GENERATED=$((ABTF_GENERATED + 1))
        _abtf_ok "Created: ${filepath##*/}"
    else
        ABTF_ERRORS=$((ABTF_ERRORS + 1))
        _abtf_err "Failed: ${filepath##*/}"
    fi
}

abtf_init() {
    ABTF_GENERATED=0; ABTF_ERRORS=0; ABTF_EXPERIMENTS_CREATED=0; ABTF_FILES_CREATED=()
    _abtf_log "A/B Test Framework v${ABTF_VERSION} initialized"
    return 0
}

# =============================================================================
# Create Experiment
# =============================================================================
_abtf_create_experiment() {
    local project_dir="${1:-.}"

    _abtf_log "Generating A/B test framework..."

    local ab_dir="${project_dir}/src/lib/ab-testing"
    mkdir -p "$ab_dir" 2>/dev/null

    _abtf_write_file "${ab_dir}/experiment.ts" "$(cat <<'TS'
import { z } from 'zod';
import crypto from 'crypto';

export const VariantSchema = z.object({
  id: z.string(),
  name: z.string(),
  weight: z.number().min(0).max(100),
  description: z.string().optional(),
});

export const ExperimentSchema = z.object({
  id: z.string(),
  name: z.string(),
  hypothesis: z.string(),
  variants: z.array(VariantSchema).min(2),
  metrics: z.array(z.string()),
  trafficPercent: z.number().min(0).max(100).default(100),
  status: z.enum(['draft', 'running', 'paused', 'completed', 'cancelled']),
  startDate: z.string().datetime().optional(),
  endDate: z.string().datetime().optional(),
  minSampleSize: z.number().default(1000),
  confidenceLevel: z.number().default(0.95),
  createdAt: z.string().datetime(),
});

export type Variant = z.infer<typeof VariantSchema>;
export type Experiment = z.infer<typeof ExperimentSchema>;

class ExperimentStore {
  private experiments = new Map<string, Experiment>();

  create(input: Omit<Experiment, 'createdAt' | 'status'>): Experiment {
    const experiment: Experiment = {
      ...input,
      status: 'draft',
      createdAt: new Date().toISOString(),
    };
    ExperimentSchema.parse(experiment);
    this.experiments.set(experiment.id, experiment);
    return experiment;
  }

  get(id: string): Experiment | undefined { return this.experiments.get(id); }
  list(): Experiment[] { return Array.from(this.experiments.values()); }

  updateStatus(id: string, status: Experiment['status']): void {
    const exp = this.experiments.get(id);
    if (!exp) throw new Error(`Experiment not found: ${id}`);
    exp.status = status;
    if (status === 'running' && !exp.startDate) exp.startDate = new Date().toISOString();
    if (['completed', 'cancelled'].includes(status)) exp.endDate = new Date().toISOString();
  }
}

export const experimentStore = new ExperimentStore();
TS
)"

    _abtf_write_file "${ab_dir}/assignment.ts" "$(cat <<'TS'
import crypto from 'crypto';
import { experimentStore, type Experiment, type Variant } from './experiment';

function consistentHash(userId: string, experimentId: string): number {
  const hash = crypto.createHash('sha256').update(`${experimentId}:${userId}`).digest('hex');
  return parseInt(hash.substring(0, 8), 16) % 10000;
}

export function assignVariant(experimentId: string, userId: string): Variant | null {
  const experiment = experimentStore.get(experimentId);
  if (!experiment || experiment.status !== 'running') return null;

  const trafficHash = consistentHash(userId, `${experimentId}:traffic`);
  if (trafficHash >= experiment.trafficPercent * 100) return null;

  const variantHash = consistentHash(userId, experimentId);
  let cumulative = 0;
  for (const variant of experiment.variants) {
    cumulative += variant.weight * 100;
    if (variantHash < cumulative) return variant;
  }

  return experiment.variants[experiment.variants.length - 1];
}

export function trackConversion(experimentId: string, userId: string, metric: string, value = 1): void {
  // Store in analytics backend
  console.log(`[AB] conversion: exp=${experimentId} user=${userId} metric=${metric} value=${value}`);
}
TS
)"

    ABTF_EXPERIMENTS_CREATED=$((ABTF_EXPERIMENTS_CREATED + 1))
    _abtf_ok "A/B test framework generated"
}

# =============================================================================
# Assign Variant
# =============================================================================
_abtf_assign_variant() {
    local project_dir="${1:-.}"

    _abtf_log "Generating React A/B test components..."

    local ab_dir="${project_dir}/src/components/ab-testing"
    mkdir -p "$ab_dir" 2>/dev/null

    _abtf_write_file "${ab_dir}/ABTestProvider.tsx" "$(cat <<'TSX'
'use client';
import React, { createContext, useContext, useEffect, useState } from 'react';

interface ABTestContextValue {
  getVariant: (experimentId: string) => string | null;
  trackConversion: (experimentId: string, metric: string, value?: number) => void;
}

const ABTestContext = createContext<ABTestContextValue | null>(null);

export function ABTestProvider({ userId, children }: { userId: string; children: React.ReactNode }) {
  const [assignments, setAssignments] = useState<Record<string, string>>({});

  useEffect(() => {
    fetch(`/api/v1/ab/assignments?userId=${userId}`)
      .then(r => r.json())
      .then(data => setAssignments(data.assignments || {}))
      .catch(() => {});
  }, [userId]);

  const getVariant = (experimentId: string) => assignments[experimentId] ?? null;

  const trackConversion = (experimentId: string, metric: string, value = 1) => {
    fetch('/api/v1/ab/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ experimentId, userId, metric, value }),
    }).catch(() => {});
  };

  return (
    <ABTestContext.Provider value={{ getVariant, trackConversion }}>
      {children}
    </ABTestContext.Provider>
  );
}

export function useABTest(experimentId: string) {
  const ctx = useContext(ABTestContext);
  if (!ctx) throw new Error('useABTest must be used within ABTestProvider');
  return {
    variant: ctx.getVariant(experimentId),
    trackConversion: (metric: string, value?: number) => ctx.trackConversion(experimentId, metric, value),
  };
}

export function ABVariant({ experimentId, variant, children }: {
  experimentId: string; variant: string; children: React.ReactNode;
}) {
  const { variant: assigned } = useABTest(experimentId);
  if (assigned !== variant) return null;
  return <>{children}</>;
}
TSX
)"

    _abtf_ok "React A/B test components generated"
}

# =============================================================================
# Analyze Results
# =============================================================================
_abtf_analyze_results() {
    local project_dir="${1:-.}"

    _abtf_log "Generating A/B test analysis engine..."

    local ab_dir="${project_dir}/src/lib/ab-testing"
    mkdir -p "$ab_dir" 2>/dev/null

    _abtf_write_file "${ab_dir}/analysis.ts" "$(cat <<'TS'
// Statistical Analysis Engine for A/B Tests

interface VariantData {
  variantId: string;
  sampleSize: number;
  conversions: number;
  conversionRate: number;
  sumValues: number;
  sumSquaredValues: number;
}

interface AnalysisResult {
  experimentId: string;
  winner: string | null;
  confidence: number;
  significant: boolean;
  variants: VariantData[];
  uplift: number;
  pValue: number;
  recommendation: 'continue' | 'stop_winner' | 'stop_no_effect';
}

function zScore(p1: number, p2: number, n1: number, n2: number): number {
  const p = (p1 * n1 + p2 * n2) / (n1 + n2);
  const se = Math.sqrt(p * (1 - p) * (1 / n1 + 1 / n2));
  if (se === 0) return 0;
  return (p1 - p2) / se;
}

function pValueFromZ(z: number): number {
  const absZ = Math.abs(z);
  const a1 = 0.254829592, a2 = -0.284496736, a3 = 1.421413741;
  const a4 = -1.453152027, a5 = 1.061405429, p = 0.3275911;
  const t = 1 / (1 + p * absZ / Math.SQRT2);
  const erf = 1 - ((((a5 * t + a4) * t + a3) * t + a2) * t + a1) * t * Math.exp(-absZ * absZ / 2);
  return 1 - erf;
}

export function analyzeExperiment(experimentId: string, data: VariantData[], confidenceLevel = 0.95): AnalysisResult {
  if (data.length < 2) {
    return { experimentId, winner: null, confidence: 0, significant: false, variants: data, uplift: 0, pValue: 1, recommendation: 'continue' };
  }

  const [control, ...treatments] = data;
  let bestTreatment = treatments[0];
  let bestUplift = 0;
  let bestPValue = 1;

  for (const treatment of treatments) {
    const z = zScore(treatment.conversionRate, control.conversionRate, treatment.sampleSize, control.sampleSize);
    const pVal = pValueFromZ(z);
    const uplift = control.conversionRate > 0
      ? (treatment.conversionRate - control.conversionRate) / control.conversionRate
      : 0;

    if (pVal < bestPValue) {
      bestTreatment = treatment;
      bestUplift = uplift;
      bestPValue = pVal;
    }
  }

  const significant = bestPValue < (1 - confidenceLevel);
  const minSample = data.every(d => d.sampleSize >= 100);

  return {
    experimentId,
    winner: significant && bestUplift > 0 ? bestTreatment.variantId : null,
    confidence: 1 - bestPValue,
    significant,
    variants: data,
    uplift: bestUplift,
    pValue: bestPValue,
    recommendation: !minSample ? 'continue' : significant ? 'stop_winner' : 'stop_no_effect',
  };
}
TS
)"

    _abtf_ok "A/B test analysis engine generated"
}

# =============================================================================
# Report / Score / Register
# =============================================================================
abtf_report() {
    echo -e "\n  ${BOLD}=== A/B Test Framework v${ABTF_VERSION} ===${NC}"
    echo -e "  生成ファイル数 : ${ABTF_GENERATED}"
    echo -e "  エラー         : ${ABTF_ERRORS}"
    echo -e "  実験作成数     : ${ABTF_EXPERIMENTS_CREATED}"
    if [[ ${#ABTF_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${ABTF_FILES_CREATED[@]}"; do echo -e "    - ${f}"; done
    fi
}

abtf_score() {
    if [[ ${ABTF_GENERATED} -ge 4 ]] && [[ ${ABTF_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${ABTF_GENERATED} -gt 0 ]] && [[ ${ABTF_ERRORS} -eq 0 ]]; then echo "90"
    elif [[ ${ABTF_GENERATED} -gt 0 ]]; then echo "70"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "ab-test-framework" --version "353.0" \
        --description "A/Bテスト実験×バリアント割当×統計分析×レポート" \
        --init "abtf_init" --report "abtf_report" --score "abtf_score" \
        --enable-var "ENABLE_AB_TEST" --cli-flags "--ab-test:--no-ab-test"
fi

# v2003.1: source時のexit codeを確実に0にする
true
