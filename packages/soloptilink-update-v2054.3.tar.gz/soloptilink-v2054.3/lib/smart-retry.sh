#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v36.0 - Smart Retry Engine
# =============================================================================
# Claude CLI呼び出し失敗時のインテリジェントリトライエンジン。
# エラー分類（timeout/rate-limit/context-overflow/network/unknown）に基づき
# 最適なリトライ戦略（指数バックオフ/プロンプト短縮/モデルダウングレード）を
# 自動選択して再試行する。
#
# v36.0の核心: call_claude()が失敗した時に「なぜ失敗したか」を分析し、
# 失敗原因に最適な回復戦略を自動適用する。
#
# Functions:
#   sr_init              - Smart Retry初期化
#   sr_classify_error    - エラー出力からエラー種別を分類
#   sr_get_strategy      - エラー種別に基づく最適リトライ戦略を返す
#   sr_execute_retry     - リトライ戦略に基づいて再試行を実行
#   sr_record_outcome    - リトライ結果を記録（学習用）
#   sr_get_stats         - リトライ統計を返す
#   sr_suggest_prevention - 頻出エラーに対する予防策を提案
#
# All globals use the SR_ prefix.
# =============================================================================

[[ -n "${_SMART_RETRY_LOADED:-}" ]] && return 0
_SMART_RETRY_LOADED=1

declare -g SR_VERSION="36.0"
declare -g SR_ENABLED="${SR_ENABLED:-true}"

# リトライ統計
declare -g SR_TOTAL_RETRIES=0
declare -g SR_SUCCESSFUL_RETRIES=0
declare -g SR_FAILED_RETRIES=0
declare -g SR_HISTORY_FILE=""

# エラー分類カウンタ
declare -g SR_COUNT_TIMEOUT=0
declare -g SR_COUNT_RATE_LIMIT=0
declare -g SR_COUNT_CONTEXT_OVERFLOW=0
declare -g SR_COUNT_NETWORK=0
declare -g SR_COUNT_UNKNOWN=0

# リトライ設定
declare -g SR_MAX_RETRIES="${SR_MAX_RETRIES:-3}"
declare -g SR_BASE_DELAY="${SR_BASE_DELAY:-5}"
declare -g SR_MAX_DELAY="${SR_MAX_DELAY:-60}"

# =============================================================================
# sr_init - Smart Retry初期化
# =============================================================================
sr_init() {
    local session_id="${1:-default}"

    SR_TOTAL_RETRIES=0
    SR_SUCCESSFUL_RETRIES=0
    SR_FAILED_RETRIES=0
    SR_COUNT_TIMEOUT=0
    SR_COUNT_RATE_LIMIT=0
    SR_COUNT_CONTEXT_OVERFLOW=0
    SR_COUNT_NETWORK=0
    SR_COUNT_UNKNOWN=0

    # 履歴ファイル
    local knowledge_dir="${HOME}/.soloptilink/knowledge"
    mkdir -p "$knowledge_dir" 2>/dev/null || true
    SR_HISTORY_FILE="${knowledge_dir}/smart_retry_history.json"

    # 過去の統計があれば読み込み
    if [[ -f "$SR_HISTORY_FILE" ]]; then
        local _prev_success
        _prev_success=$(grep -o '"success_rate":[0-9.]*' "$SR_HISTORY_FILE" 2>/dev/null | head -1 | cut -d: -f2)
        if [[ -n "$_prev_success" ]]; then
            echo -e "  ${GREEN:-}✓ Smart Retry: 過去の成功率 ${_prev_success}% を読み込み${NC:-}" >&2
        fi
    fi

    return 0
}

# =============================================================================
# sr_classify_error - エラー出力からエラー種別を分類
# Returns: timeout | rate_limit | context_overflow | network | auth | unknown
# =============================================================================
sr_classify_error() {
    local error_output="${1:-}"
    local exit_code="${2:-1}"

    [[ -z "$error_output" ]] && echo "unknown" && return 0

    # タイムアウト系
    if echo "$error_output" | grep -qi -E "timeout|timed.out|deadline.exceeded|SIGTERM|killed"; then
        echo "timeout"
        return 0
    fi

    # レートリミット系
    if echo "$error_output" | grep -qi -E "rate.limit|429|too.many.requests|throttl|quota.exceeded|overloaded"; then
        echo "rate_limit"
        return 0
    fi

    # コンテキストオーバーフロー系
    if echo "$error_output" | grep -qi -E "context.length|token.limit|too.long|max.tokens|context.*exceed|prompt.*too.*large"; then
        echo "context_overflow"
        return 0
    fi

    # ネットワーク系
    if echo "$error_output" | grep -qi -E "network|connection.*refused|ECONNRESET|ENOTFOUND|DNS|socket|SSL|certificate|502|503|504"; then
        echo "network"
        return 0
    fi

    # 認証系
    if echo "$error_output" | grep -qi -E "auth|401|403|forbidden|unauthorized|invalid.*key|api.*key"; then
        echo "auth"
        return 0
    fi

    echo "unknown"
    return 0
}

# =============================================================================
# sr_get_strategy - エラー種別に基づく最適リトライ戦略を返す
# Returns: JSON-like strategy string
# =============================================================================
sr_get_strategy() {
    local error_type="${1:-unknown}"
    local attempt="${2:-1}"

    case "$error_type" in
        timeout)
            # タイムアウト→プロンプト短縮 + タイムアウト延長
            local delay=$((SR_BASE_DELAY * attempt))
            [[ $delay -gt $SR_MAX_DELAY ]] && delay=$SR_MAX_DELAY
            echo "action=extend_timeout;delay=${delay};reduce_prompt=true;timeout_multiplier=$((attempt + 1))"
            ;;
        rate_limit)
            # レートリミット→指数バックオフ（長め）
            local delay=$((SR_BASE_DELAY * 2 ** attempt))
            [[ $delay -gt $SR_MAX_DELAY ]] && delay=$SR_MAX_DELAY
            echo "action=exponential_backoff;delay=${delay};reduce_prompt=false;timeout_multiplier=1"
            ;;
        context_overflow)
            # コンテキスト超過→プロンプト短縮 + モデルダウングレード不要
            echo "action=truncate_prompt;delay=${SR_BASE_DELAY};reduce_prompt=true;truncate_ratio=$((50 + attempt * 10))"
            ;;
        network)
            # ネットワーク→短いバックオフ + そのまま再試行
            local delay=$((SR_BASE_DELAY * attempt))
            [[ $delay -gt 30 ]] && delay=30
            echo "action=simple_retry;delay=${delay};reduce_prompt=false;timeout_multiplier=1"
            ;;
        auth)
            # 認証エラー→リトライ不可
            echo "action=abort;delay=0;reduce_prompt=false;reason=auth_failure"
            ;;
        *)
            # 不明→段階的バックオフ
            local delay=$((SR_BASE_DELAY * attempt))
            [[ $delay -gt $SR_MAX_DELAY ]] && delay=$SR_MAX_DELAY
            echo "action=graduated_backoff;delay=${delay};reduce_prompt=false;timeout_multiplier=1"
            ;;
    esac
    return 0
}

# =============================================================================
# sr_parse_strategy - 戦略文字列からフィールドを取得
# =============================================================================
sr_parse_strategy() {
    local strategy="$1"
    local field="$2"

    echo "$strategy" | tr ';' '\n' | grep "^${field}=" | cut -d= -f2
}

# =============================================================================
# sr_execute_retry - リトライ戦略に基づいて待機・調整を実行
# Returns: 0=retry可, 1=abort
# =============================================================================
sr_execute_retry() {
    local error_type="${1:-unknown}"
    local attempt="${2:-1}"
    local max_retries="${3:-$SR_MAX_RETRIES}"

    # 最大リトライ回数チェック
    if [[ $attempt -gt $max_retries ]]; then
        echo "MAX_RETRIES_EXCEEDED" >&2
        return 1
    fi

    local strategy
    strategy=$(sr_get_strategy "$error_type" "$attempt")

    local action
    action=$(sr_parse_strategy "$strategy" "action")

    # abort戦略の場合はリトライ不可
    if [[ "$action" == "abort" ]]; then
        local reason
        reason=$(sr_parse_strategy "$strategy" "reason")
        echo "ABORT:${reason}" >&2
        return 1
    fi

    local delay
    delay=$(sr_parse_strategy "$strategy" "delay")
    delay="${delay:-$SR_BASE_DELAY}"

    echo -e "  ${YELLOW:-}⟳ Smart Retry: ${error_type} 検出 → ${action} (${delay}秒待機, attempt ${attempt}/${max_retries})${NC:-}" >&2

    # 待機
    sleep "$delay" 2>/dev/null || true

    SR_TOTAL_RETRIES=$((SR_TOTAL_RETRIES + 1))

    return 0
}

# =============================================================================
# sr_record_outcome - リトライ結果を記録
# =============================================================================
sr_record_outcome() {
    local error_type="${1:-unknown}"
    local success="${2:-false}"  # true/false
    local attempt="${3:-1}"

    if [[ "$success" == "true" ]]; then
        SR_SUCCESSFUL_RETRIES=$((SR_SUCCESSFUL_RETRIES + 1))
    else
        SR_FAILED_RETRIES=$((SR_FAILED_RETRIES + 1))
    fi

    # エラー種別カウンタ更新
    case "$error_type" in
        timeout) SR_COUNT_TIMEOUT=$((SR_COUNT_TIMEOUT + 1)) ;;
        rate_limit) SR_COUNT_RATE_LIMIT=$((SR_COUNT_RATE_LIMIT + 1)) ;;
        context_overflow) SR_COUNT_CONTEXT_OVERFLOW=$((SR_COUNT_CONTEXT_OVERFLOW + 1)) ;;
        network) SR_COUNT_NETWORK=$((SR_COUNT_NETWORK + 1)) ;;
        *) SR_COUNT_UNKNOWN=$((SR_COUNT_UNKNOWN + 1)) ;;
    esac

    return 0
}

# =============================================================================
# sr_get_stats - リトライ統計をJSON形式で返す
# =============================================================================
sr_get_stats() {
    local success_rate=0
    if [[ $SR_TOTAL_RETRIES -gt 0 ]]; then
        success_rate=$((SR_SUCCESSFUL_RETRIES * 100 / SR_TOTAL_RETRIES))
    fi

    cat <<EOF
{
  "version": "${SR_VERSION}",
  "total_retries": ${SR_TOTAL_RETRIES},
  "successful": ${SR_SUCCESSFUL_RETRIES},
  "failed": ${SR_FAILED_RETRIES},
  "success_rate": ${success_rate},
  "by_type": {
    "timeout": ${SR_COUNT_TIMEOUT},
    "rate_limit": ${SR_COUNT_RATE_LIMIT},
    "context_overflow": ${SR_COUNT_CONTEXT_OVERFLOW},
    "network": ${SR_COUNT_NETWORK},
    "unknown": ${SR_COUNT_UNKNOWN}
  }
}
EOF
}

# =============================================================================
# sr_save_history - 統計を永続化
# =============================================================================
sr_save_history() {
    [[ -z "$SR_HISTORY_FILE" ]] && return 0

    local stats
    stats=$(sr_get_stats)

    echo "$stats" > "$SR_HISTORY_FILE" 2>/dev/null || true
    return 0
}

# =============================================================================
# sr_suggest_prevention - 頻出エラーに対する予防策を提案
# =============================================================================
sr_suggest_prevention() {
    local suggestions=""

    if [[ $SR_COUNT_TIMEOUT -ge 2 ]]; then
        suggestions="${suggestions}⚠️ タイムアウト頻発: --model-tier economy でHaikuに切替を推奨\n"
    fi

    if [[ $SR_COUNT_RATE_LIMIT -ge 2 ]]; then
        suggestions="${suggestions}⚠️ レートリミット頻発: フェーズ間隔を広げるか、並列度を下げてください\n"
    fi

    if [[ $SR_COUNT_CONTEXT_OVERFLOW -ge 2 ]]; then
        suggestions="${suggestions}⚠️ コンテキスト超過頻発: --context-budget を下げてプロンプトを短縮\n"
    fi

    if [[ $SR_COUNT_NETWORK -ge 3 ]]; then
        suggestions="${suggestions}⚠️ ネットワークエラー頻発: インターネット接続を確認してください\n"
    fi

    if [[ -z "$suggestions" ]]; then
        echo "✅ Smart Retry: 特に問題のあるパターンは検出されませんでした"
    else
        echo -e "$suggestions"
    fi
}
