#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v335.0 - Cloud Cost Optimization Engine
# =============================================================================
# クラウドコスト分析、節約提案、予算アラート生成。
# リソースサイジング、Savings Plans、スポットインスタンス提案。
#
# Functions:
#   _cco_init()                  - Initialize
#   _cco_analyze_costs()         - Analyze IaC for cost implications
#   _cco_suggest_savings()       - Generate cost optimization suggestions
#   _cco_generate_budget_alert() - Generate AWS Budget alerts
#   _cco_report() / _cco_score()
# =============================================================================

[[ -n "${_CCO_LOADED:-}" ]] && return 0; _CCO_LOADED=1

readonly _CCO_RED='\033[0;31m'
readonly _CCO_GREEN='\033[0;32m'
readonly _CCO_YELLOW='\033[0;33m'
readonly _CCO_CYAN='\033[0;36m'
readonly _CCO_NC='\033[0m'

declare -g CCO_VERSION="335.0"
CCO_GENERATED=0
CCO_ERRORS=0
CCO_FILES_WRITTEN=0
CCO_ANALYZE_OK=false
CCO_SAVINGS_OK=false
CCO_BUDGET_OK=false
CCO_ESTIMATED_MONTHLY=0
CCO_POTENTIAL_SAVINGS=0

_cco_init() {
    CCO_GENERATED=0; CCO_ERRORS=0; CCO_FILES_WRITTEN=0
    CCO_ANALYZE_OK=false; CCO_SAVINGS_OK=false; CCO_BUDGET_OK=false
    CCO_ESTIMATED_MONTHLY=0; CCO_POTENTIAL_SAVINGS=0
    echo -e "  ${_CCO_GREEN}OK${_CCO_NC} Cloud Cost Optimization v${CCO_VERSION}" >&2
    return 0
}

_cco_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { CCO_FILES_WRITTEN=$((CCO_FILES_WRITTEN + 1)); return 0; }
    CCO_ERRORS=$((CCO_ERRORS + 1)); return 1
}

_cco_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_CCO_CYAN}[cost]${_CCO_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_CCO_GREEN}[cost]${_CCO_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_CCO_YELLOW}[cost]${_CCO_NC} $msg" >&2 ;;
        error) echo -e "  ${_CCO_RED}[cost]${_CCO_NC} $msg" >&2 ;;
    esac
}

# =============================================================================
# Analyze Cost from IaC
# =============================================================================
_cco_analyze_costs() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local cost_total=0

    _cco_log info "Analyzing infrastructure costs..."

    # Scan Terraform files for cost-bearing resources
    local tf_files
    tf_files=$(find "$project_dir" -name "*.tf" -not -path "*/node_modules/*" 2>/dev/null)

    if [[ -z "$tf_files" ]]; then
        _cco_log warn "No Terraform files found"
        return 1
    fi

    # Rough cost estimates (monthly, ap-northeast-1 pricing)
    local rds_count
    rds_count=$(echo "$tf_files" | xargs grep -l "aws_db_instance" 2>/dev/null | wc -l | tr -d ' ')
    if [[ $rds_count -gt 0 ]]; then
        local rds_cost=30  # db.t3.micro base
        if echo "$tf_files" | xargs grep -q "multi_az.*true" 2>/dev/null; then
            rds_cost=$((rds_cost * 2))
        fi
        cost_total=$((cost_total + rds_cost))
        _cco_log info "RDS: ~\$${rds_cost}/mo (${rds_count} instances)"
    fi

    local ecs_count
    ecs_count=$(echo "$tf_files" | xargs grep -l "aws_ecs_service" 2>/dev/null | wc -l | tr -d ' ')
    if [[ $ecs_count -gt 0 ]]; then
        local ecs_cost=40  # 256 CPU / 512 MB Fargate
        cost_total=$((cost_total + ecs_cost))
        _cco_log info "ECS Fargate: ~\$${ecs_cost}/mo"
    fi

    local alb_count
    alb_count=$(echo "$tf_files" | xargs grep -l "aws_lb\b\|aws_alb" 2>/dev/null | wc -l | tr -d ' ')
    if [[ $alb_count -gt 0 ]]; then
        local alb_cost=25
        cost_total=$((cost_total + alb_cost))
        _cco_log info "ALB: ~\$${alb_cost}/mo"
    fi

    local nat_count
    nat_count=$(echo "$tf_files" | xargs grep -c "enable_nat_gateway.*true\|aws_nat_gateway" 2>/dev/null | awk '{sum+=$1} END{print sum+0}')
    if [[ $nat_count -gt 0 ]]; then
        local nat_cost=$((nat_count * 45))
        cost_total=$((cost_total + nat_cost))
        _cco_log info "NAT Gateway: ~\$${nat_cost}/mo (${nat_count} gateways)"
    fi

    local cf_count
    cf_count=$(echo "$tf_files" | xargs grep -l "aws_cloudfront_distribution" 2>/dev/null | wc -l | tr -d ' ')
    if [[ $cf_count -gt 0 ]]; then
        cost_total=$((cost_total + 10))
        _cco_log info "CloudFront: ~\$10/mo (base)"
    fi

    CCO_ESTIMATED_MONTHLY=$cost_total
    _cco_log ok "Estimated monthly cost: ~\$${cost_total}"

    CCO_ANALYZE_OK=true
    CCO_GENERATED=$((CCO_GENERATED + 1))
    return 0
}

# =============================================================================
# Suggest Savings
# =============================================================================
_cco_suggest_savings() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local suggestions=()
    local savings=0

    _cco_log info "Generating cost optimization suggestions..."

    local tf_files
    tf_files=$(find "$project_dir" -name "*.tf" -not -path "*/node_modules/*" 2>/dev/null)

    # Check NAT Gateway (expensive)
    if echo "$tf_files" | xargs grep -q "single_nat_gateway.*false\|nat_gateways.*[2-9]" 2>/dev/null; then
        suggestions+=("Use single NAT Gateway in non-prod (saves ~\$45/mo per extra gateway)")
        savings=$((savings + 45))
    fi

    # Check RDS Multi-AZ in dev
    if echo "$tf_files" | xargs grep -q "multi_az.*true" 2>/dev/null; then
        suggestions+=("Disable Multi-AZ for dev/staging databases (saves ~\$30/mo)")
        savings=$((savings + 30))
    fi

    # Check for Graviton/ARM
    if echo "$tf_files" | xargs grep -q "db\.t3\.\|db\.m5\.\|db\.r5\." 2>/dev/null; then
        suggestions+=("Switch to Graviton instances (db.t4g/m6g) for ~20% savings")
        savings=$((savings + 10))
    fi

    # Check ECS CPU overprovisioning
    if echo "$tf_files" | xargs grep -q "cpu.*=.*1024\|cpu.*=.*2048" 2>/dev/null; then
        suggestions+=("Review ECS CPU allocation - may be overprovisioned")
        savings=$((savings + 15))
    fi

    # Check S3 storage class
    if echo "$tf_files" | xargs grep -q "aws_s3_bucket" 2>/dev/null; then
        if ! echo "$tf_files" | xargs grep -q "lifecycle_rule\|intelligent_tiering" 2>/dev/null; then
            suggestions+=("Add S3 Intelligent-Tiering or lifecycle rules for infrequent data")
            savings=$((savings + 5))
        fi
    fi

    CCO_POTENTIAL_SAVINGS=$savings

    # Write suggestions
    local report="${project_dir}/cost-optimization-report.json"
    local suggestions_json=""
    for s in "${suggestions[@]}"; do
        [[ -n "$suggestions_json" ]] && suggestions_json="${suggestions_json},"
        suggestions_json="${suggestions_json}\"${s}\""
    done

    _cco_write_file "$report" "{
  \"estimated_monthly_cost\": ${CCO_ESTIMATED_MONTHLY},
  \"potential_savings\": ${savings},
  \"suggestions\": [${suggestions_json}],
  \"generated_at\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"
}"

    _cco_log ok "Found ${#suggestions[@]} optimization suggestions (~\$${savings}/mo savings)"

    CCO_SAVINGS_OK=true
    CCO_GENERATED=$((CCO_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate Budget Alerts
# =============================================================================
_cco_generate_budget_alert() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local budget="${2:-200}"
    local cost_dir="${project_dir}/infra/cost"

    _cco_log info "Generating budget alerts (limit: \$${budget}/mo)..."

    _cco_write_file "${cost_dir}/budget.tf" "resource \"aws_budgets_budget\" \"monthly\" {
  name         = \"\${var.project_name}-monthly-budget\"
  budget_type  = \"COST\"
  limit_amount = \"${budget}\"
  limit_unit   = \"USD\"
  time_unit    = \"MONTHLY\"

  notification {
    comparison_operator       = \"GREATER_THAN\"
    threshold                 = 50
    threshold_type            = \"PERCENTAGE\"
    notification_type         = \"ACTUAL\"
    subscriber_email_addresses = [var.alert_email]
  }

  notification {
    comparison_operator       = \"GREATER_THAN\"
    threshold                 = 80
    threshold_type            = \"PERCENTAGE\"
    notification_type         = \"ACTUAL\"
    subscriber_email_addresses = [var.alert_email]
    subscriber_sns_topic_arns  = [var.alert_sns_arn]
  }

  notification {
    comparison_operator       = \"GREATER_THAN\"
    threshold                 = 100
    threshold_type            = \"PERCENTAGE\"
    notification_type         = \"ACTUAL\"
    subscriber_email_addresses = [var.alert_email]
    subscriber_sns_topic_arns  = [var.alert_sns_arn]
  }

  notification {
    comparison_operator       = \"GREATER_THAN\"
    threshold                 = 80
    threshold_type            = \"PERCENTAGE\"
    notification_type         = \"FORECASTED\"
    subscriber_email_addresses = [var.alert_email]
  }
}

resource \"aws_ce_anomaly_monitor\" \"service\" {
  name              = \"\${var.project_name}-anomaly-monitor\"
  monitor_type      = \"DIMENSIONAL\"
  monitor_dimension = \"SERVICE\"
}

resource \"aws_ce_anomaly_subscription\" \"alerts\" {
  name      = \"\${var.project_name}-anomaly-sub\"
  frequency = \"DAILY\"
  monitor_arn_list = [aws_ce_anomaly_monitor.service.arn]
  subscriber {
    type    = \"EMAIL\"
    address = var.alert_email
  }
  threshold_expression {
    dimension {
      key           = \"ANOMALY_TOTAL_IMPACT_ABSOLUTE\"
      values        = [\"50\"]
      match_options = [\"GREATER_THAN_OR_EQUAL\"]
    }
  }
}
"

    _cco_log ok "Budget alerts generated (\$${budget}/mo limit)"
    CCO_BUDGET_OK=true
    CCO_GENERATED=$((CCO_GENERATED + 1))
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_cco_report() {
    echo -e "\n  ${_CCO_CYAN}=== Cloud Cost Optimization v${CCO_VERSION} ===${_CCO_NC}"
    echo -e "  Generated: ${CCO_GENERATED} | Files: ${CCO_FILES_WRITTEN} | Errors: ${CCO_ERRORS}"
    echo -e "  Analysis: $( ${CCO_ANALYZE_OK} && echo 'OK' || echo 'SKIP') (est: \$${CCO_ESTIMATED_MONTHLY}/mo)"
    echo -e "  Savings: $( ${CCO_SAVINGS_OK} && echo 'OK' || echo 'SKIP') (potential: \$${CCO_POTENTIAL_SAVINGS}/mo)"
    echo -e "  Budget Alerts: $( ${CCO_BUDGET_OK} && echo 'OK' || echo 'SKIP')"
}

_cco_score() {
    local score=50
    ${CCO_ANALYZE_OK} && score=$((score + 15))
    ${CCO_SAVINGS_OK} && score=$((score + 15))
    ${CCO_BUDGET_OK} && score=$((score + 15))
    [[ ${CCO_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "cloud-cost-optimization" --version "335.0" \
        --description "クラウドコスト最適化 分析/節約提案/予算アラート (v335)" \
        --init "_cco_init" --report "_cco_report" --score "_cco_score" \
        --enable-var "ENABLE_CLOUD_COST_OPT" --cli-flags "--cloud-cost-opt:--no-cloud-cost-opt"
fi

# v2003.1: source時のexit codeを確実に0にする
true
