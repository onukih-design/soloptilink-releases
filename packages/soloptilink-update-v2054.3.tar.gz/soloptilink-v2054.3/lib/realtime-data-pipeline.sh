#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v444.0 - Realtime Data Pipeline
# =============================================================================
# リアルタイムデータパイプライン生成。ストリーム処理、ETLパイプライン、
# スループット監視を自動化する。
#
# Functions:
#   _rdp_init()                   - 初期化
#   _rdp_generate_stream()        - ストリーム処理生成
#   _rdp_generate_etl()           - ETLパイプライン生成
#   _rdp_monitor_throughput()     - スループット監視
#   _rdp_report() / _rdp_score()
#
# All globals use the RDP_ prefix.
# =============================================================================

[[ -n "${_RDP_LOADED:-}" ]] && return 0; _RDP_LOADED=1

declare -g RDP_VERSION="444.0"
declare -g RDP_GENERATED=0
declare -g RDP_ERRORS=0
declare -g RDP_STREAMS=0
declare -g RDP_ETL_PIPELINES=0
declare -g RDP_MONITOR_CONFIGURED=false
declare -g RDP_REALTIME_TECH=""

declare -ga _RDP_FINDINGS=()

_RDP_GREEN="${GREEN:-\033[0;32m}"
_RDP_YELLOW="${YELLOW:-\033[0;33m}"
_RDP_CYAN="${CYAN:-\033[0;36m}"
_RDP_BOLD="${BOLD:-\033[1m}"
_RDP_NC="${NC:-\033[0m}"

_rdp_init() {
    RDP_GENERATED=0; RDP_ERRORS=0; RDP_STREAMS=0
    RDP_ETL_PIPELINES=0; RDP_MONITOR_CONFIGURED=false; RDP_REALTIME_TECH=""
    _RDP_FINDINGS=()
    return 0
}

_rdp_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_RDP_CYAN}[RDP]${_RDP_NC} $*" >&2 ;;
        ok)    echo -e "  ${_RDP_GREEN}[RDP]${_RDP_NC} $*" >&2 ;;
        warn)  echo -e "  ${_RDP_YELLOW}[RDP]${_RDP_NC} $*" >&2 ;;
        *)     echo -e "  ${_RDP_CYAN}[RDP]${_RDP_NC} $*" >&2 ;;
    esac
}

_rdp_generate_stream() {
    local project_dir="${1:-.}"
    _rdp_log info "ストリーム処理分析"

    RDP_REALTIME_TECH=""
    local pkg="${project_dir}/package.json"
    if [[ -f "$pkg" ]]; then
        if grep -q '"ws"\|"socket.io"' "$pkg" 2>/dev/null; then RDP_REALTIME_TECH="websocket"; fi
        if grep -q '"sse"\|"eventsource"' "$pkg" 2>/dev/null; then RDP_REALTIME_TECH="${RDP_REALTIME_TECH:+${RDP_REALTIME_TECH}+}sse"; fi
        if grep -q '"redis"\|"ioredis"' "$pkg" 2>/dev/null; then RDP_REALTIME_TECH="${RDP_REALTIME_TECH:+${RDP_REALTIME_TECH}+}redis-pubsub"; fi
        if grep -q '"kafkajs"\|"kafka"' "$pkg" 2>/dev/null; then RDP_REALTIME_TECH="${RDP_REALTIME_TECH:+${RDP_REALTIME_TECH}+}kafka"; fi
    fi

    # WebSocket/SSEエンドポイント検出
    while IFS= read -r -d '' file; do
        local ws_count
        ws_count=$(grep -c "WebSocket\|wss://\|new Server.*ws\|ReadableStream\|SSE\|text/event-stream" "$file" 2>/dev/null || echo 0)
        if [[ $ws_count -gt 0 ]]; then
            RDP_STREAMS=$((RDP_STREAMS + 1))
        fi
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.js" \) \
             -not -path "*/node_modules/*" -print0 2>/dev/null)

    if [[ $RDP_STREAMS -eq 0 ]] && [[ -n "$RDP_REALTIME_TECH" ]]; then
        _RDP_FINDINGS+=("UNUSED_REALTIME:${RDP_REALTIME_TECH} dependency found but no stream endpoints")
    fi

    RDP_GENERATED=$((RDP_GENERATED + 1))
    _rdp_log ok "ストリーム: ${RDP_STREAMS}個, tech=${RDP_REALTIME_TECH:-none}"
    return 0
}

_rdp_generate_etl() {
    local project_dir="${1:-.}"
    _rdp_log info "ETLパイプライン分析"

    RDP_ETL_PIPELINES=0

    # Cronジョブ/バッチ処理の検出
    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"
        local has_cron
        has_cron=$(grep -c "cron\|schedule\|setInterval\|bullmq\|agenda" "$file" 2>/dev/null || echo 0)
        if [[ $has_cron -gt 0 ]]; then
            RDP_ETL_PIPELINES=$((RDP_ETL_PIPELINES + 1))
            _RDP_FINDINGS+=("ETL_ENDPOINT:${rel}:scheduled/batch processing detected")
        fi
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.js" \) \
             -not -path "*/node_modules/*" -path "*cron*" -o -path "*job*" -o -path "*worker*" -o -path "*queue*" \
             -print0 2>/dev/null)

    # データ変換パターン検出
    local transform_count=0
    while IFS= read -r -d '' file; do
        local transforms
        transforms=$(grep -c "\.transform\|\.pipe\|\.map.*\.filter\|aggregat" "$file" 2>/dev/null || echo 0)
        transform_count=$((transform_count + transforms))
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.js" \) \
             -not -path "*/node_modules/*" -print0 2>/dev/null)

    if [[ $transform_count -gt 10 ]]; then
        _RDP_FINDINGS+=("TRANSFORM_HEAVY:${transform_count}x data transform operations - consider streaming ETL")
    fi

    RDP_GENERATED=$((RDP_GENERATED + 1))
    _rdp_log ok "ETLパイプライン: ${RDP_ETL_PIPELINES}個"
    return 0
}

_rdp_monitor_throughput() {
    local project_dir="${1:-.}"
    _rdp_log info "スループット監視設定"

    _RDP_FINDINGS+=("THROUGHPUT:implement request counter per endpoint for throughput monitoring")
    _RDP_FINDINGS+=("BACKPRESSURE:add backpressure handling for stream producers")
    _RDP_FINDINGS+=("METRICS:expose Prometheus metrics for stream processing rates")

    RDP_MONITOR_CONFIGURED=true
    RDP_GENERATED=$((RDP_GENERATED + 1))
    _rdp_log ok "スループット監視推奨生成"
    return 0
}

_rdp_report() {
    echo -e "\n  ${_RDP_BOLD}=== realtime-data-pipeline v${RDP_VERSION} ===${_RDP_NC}"
    echo -e "  リアルタイム技術: ${RDP_REALTIME_TECH:-none}"
    echo -e "  ストリーム数    : ${RDP_STREAMS}"
    echo -e "  ETLパイプライン : ${RDP_ETL_PIPELINES}"
    echo -e "  監視設定        : ${RDP_MONITOR_CONFIGURED}"
    echo -e "  エラー          : ${RDP_ERRORS}"
}

_rdp_score() {
    local score=50
    [[ -n "$RDP_REALTIME_TECH" ]] && score=$((score + 10))
    [[ ${RDP_STREAMS} -gt 0 ]] && score=$((score + 15))
    [[ "$RDP_MONITOR_CONFIGURED" == "true" ]] && score=$((score + 15))
    [[ ${RDP_ERRORS} -eq 0 ]] && score=$((score + 10))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "realtime-data-pipeline" --version "${RDP_VERSION}" \
        --description "リアルタイムデータパイプライン×ストリーム×ETL×監視 (v444)" \
        --init "_rdp_init" --report "_rdp_report" --score "_rdp_score" \
        --enable-var "ENABLE_RT_PIPELINE" --cli-flags "--rt-pipeline:--no-rt-pipeline"
fi

# v2003.1: source時のexit codeを確実に0にする
true
