#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v41.0 - Dependency Sync Engine
# =============================================================================
# プロジェクト依存関係のリアルタイム同期・自動修復エンジン。
# chain.shフェーズ実行中にpackage.json/requirements.txt等の矛盾を検出し、
# lockfile更新・未使用パッケージ検出・バージョン競合解決を自動実行。
#
# v41.0の核心: 依存関係の「壊れ」を検出した瞬間に修復する。
# ビルドエラーの30%は依存関係問題 → フェーズ完了後に毎回チェック。
#
# Functions:
#   ds_init              - Dependency Sync初期化
#   ds_detect_manager    - パッケージマネージャ自動検出
#   ds_check_integrity   - 依存関係整合性チェック
#   ds_find_unused       - 未使用パッケージ検出
#   ds_find_outdated     - 古いパッケージ検出
#   ds_find_conflicts    - バージョン競合検出
#   ds_auto_fix          - 自動修復実行
#   ds_get_stats         - 統計情報を返す
#   ds_save_history      - 履歴永続化
#
# All globals use the DS_ prefix.
# =============================================================================

[[ -n "${_DEP_SYNC_LOADED:-}" ]] && return 0
_DEP_SYNC_LOADED=1

declare -g DS_VERSION="41.0"
declare -g DS_ENABLED="${DS_ENABLED:-true}"

# 検出結果
declare -g DS_MANAGER=""          # npm|yarn|pnpm|pip|poetry|go|cargo
declare -g DS_PROJECT_DIR=""
declare -g DS_TOTAL_DEPS=0
declare -g DS_UNUSED_COUNT=0
declare -g DS_OUTDATED_COUNT=0
declare -g DS_CONFLICT_COUNT=0
declare -g DS_FIX_COUNT=0
declare -g DS_CHECKS_RUN=0
declare -g DS_HISTORY_FILE=""

# =============================================================================
# ds_init - Dependency Sync初期化
# =============================================================================
ds_init() {
    local project_dir="${1:-$(pwd)}"

    DS_PROJECT_DIR="$project_dir"
    DS_TOTAL_DEPS=0
    DS_UNUSED_COUNT=0
    DS_OUTDATED_COUNT=0
    DS_CONFLICT_COUNT=0
    DS_FIX_COUNT=0
    DS_CHECKS_RUN=0

    local knowledge_dir="${HOME}/.soloptilink/knowledge"
    mkdir -p "$knowledge_dir" 2>/dev/null || true
    DS_HISTORY_FILE="${knowledge_dir}/dep_sync_history.jsonl"

    # パッケージマネージャ自動検出
    DS_MANAGER=$(ds_detect_manager "$project_dir")

    return 0
}

# =============================================================================
# ds_detect_manager - パッケージマネージャ自動検出
# =============================================================================
ds_detect_manager() {
    local dir="${1:-.}"

    if [[ -f "${dir}/package-lock.json" ]]; then
        echo "npm"
    elif [[ -f "${dir}/yarn.lock" ]]; then
        echo "yarn"
    elif [[ -f "${dir}/pnpm-lock.yaml" ]]; then
        echo "pnpm"
    elif [[ -f "${dir}/package.json" ]]; then
        echo "npm"
    elif [[ -f "${dir}/Pipfile.lock" ]] || [[ -f "${dir}/Pipfile" ]]; then
        echo "pipenv"
    elif [[ -f "${dir}/poetry.lock" ]] || [[ -f "${dir}/pyproject.toml" ]]; then
        echo "poetry"
    elif [[ -f "${dir}/requirements.txt" ]]; then
        echo "pip"
    elif [[ -f "${dir}/go.mod" ]]; then
        echo "go"
    elif [[ -f "${dir}/Cargo.toml" ]]; then
        echo "cargo"
    else
        echo "unknown"
    fi
}

# =============================================================================
# ds_check_integrity - 依存関係整合性チェック
# Returns: issues count
# =============================================================================
ds_check_integrity() {
    local dir="${1:-$DS_PROJECT_DIR}"
    local issues=0

    DS_CHECKS_RUN=$((DS_CHECKS_RUN + 1))

    case "$DS_MANAGER" in
        npm|yarn|pnpm)
            # package.json存在チェック
            if [[ ! -f "${dir}/package.json" ]]; then
                issues=$((issues + 1))
                echo "MISSING:package.json"
                return $issues
            fi

            # node_modules存在チェック
            if [[ ! -d "${dir}/node_modules" ]]; then
                issues=$((issues + 1))
                echo "MISSING:node_modules"
            fi

            # lockfile存在チェック
            if [[ "$DS_MANAGER" == "npm" && ! -f "${dir}/package-lock.json" ]]; then
                issues=$((issues + 1))
                echo "MISSING:lockfile"
            elif [[ "$DS_MANAGER" == "yarn" && ! -f "${dir}/yarn.lock" ]]; then
                issues=$((issues + 1))
                echo "MISSING:lockfile"
            fi

            # package.json構文チェック
            if command -v node &>/dev/null; then
                if ! node -e "JSON.parse(require('fs').readFileSync('${dir}/package.json','utf8'))" 2>/dev/null; then
                    issues=$((issues + 1))
                    echo "INVALID:package.json"
                fi
            fi

            # 依存数カウント
            if command -v node &>/dev/null && [[ -f "${dir}/package.json" ]]; then
                local dep_count
                dep_count=$(node -e "
                    const p=JSON.parse(require('fs').readFileSync('${dir}/package.json','utf8'));
                    console.log(Object.keys(p.dependencies||{}).length + Object.keys(p.devDependencies||{}).length)
                " 2>/dev/null || echo "0")
                dep_count=$(echo "$dep_count" | tr -d '[:space:]')
                [[ -z "$dep_count" ]] && dep_count=0
                DS_TOTAL_DEPS=$dep_count
            fi
            ;;
        pip|pipenv|poetry)
            if [[ ! -f "${dir}/requirements.txt" && ! -f "${dir}/pyproject.toml" && ! -f "${dir}/Pipfile" ]]; then
                issues=$((issues + 1))
                echo "MISSING:requirements"
            fi
            if [[ -f "${dir}/requirements.txt" ]]; then
                local req_count
                req_count=$(grep -c -v -E "^#|^$" "${dir}/requirements.txt" 2>/dev/null || echo "0")
                req_count=$(echo "$req_count" | tr -d '[:space:]')
                [[ -z "$req_count" ]] && req_count=0
                DS_TOTAL_DEPS=$req_count
            fi
            ;;
        go)
            if [[ ! -f "${dir}/go.sum" ]]; then
                issues=$((issues + 1))
                echo "MISSING:go.sum"
            fi
            ;;
        cargo)
            if [[ ! -f "${dir}/Cargo.lock" ]]; then
                issues=$((issues + 1))
                echo "MISSING:Cargo.lock"
            fi
            ;;
    esac

    echo "$issues"
}

# =============================================================================
# ds_find_unused - 未使用パッケージ検出（簡易版）
# =============================================================================
ds_find_unused() {
    local dir="${1:-$DS_PROJECT_DIR}"
    local unused=0

    [[ "$DS_MANAGER" != "npm" && "$DS_MANAGER" != "yarn" && "$DS_MANAGER" != "pnpm" ]] && echo "0" && return 0
    [[ ! -f "${dir}/package.json" ]] && echo "0" && return 0

    # package.jsonのdependenciesを走査してimport/requireの有無をチェック
    if command -v node &>/dev/null; then
        local deps
        deps=$(node -e "
            const p=JSON.parse(require('fs').readFileSync('${dir}/package.json','utf8'));
            const d=Object.keys(p.dependencies||{});
            d.forEach(dep=>console.log(dep));
        " 2>/dev/null || true)

        while IFS= read -r dep; do
            [[ -z "$dep" ]] && continue
            # @スコープ付きパッケージ名のエスケープ
            local search_name="${dep}"
            if [[ "$dep" == @* ]]; then
                search_name="${dep}"
            fi
            # src/以下でimportされているか簡易チェック
            if [[ -d "${dir}/src" ]]; then
                if ! grep -r -q -l "$search_name" "${dir}/src" 2>/dev/null; then
                    # app/以下もチェック
                    if [[ -d "${dir}/app" ]]; then
                        if ! grep -r -q -l "$search_name" "${dir}/app" 2>/dev/null; then
                            unused=$((unused + 1))
                        fi
                    else
                        unused=$((unused + 1))
                    fi
                fi
            fi
        done <<< "$deps"
    fi

    DS_UNUSED_COUNT=$unused
    echo "$unused"
}

# =============================================================================
# ds_find_outdated - 古いパッケージ検出（キャッシュ版）
# =============================================================================
ds_find_outdated() {
    local dir="${1:-$DS_PROJECT_DIR}"

    # npm outdatedは遅いので、lockfileの日付で簡易判定
    case "$DS_MANAGER" in
        npm)
            if [[ -f "${dir}/package-lock.json" ]]; then
                local lock_age
                if [[ "$(uname)" == "Darwin" ]]; then
                    lock_age=$(( ($(date +%s) - $(stat -f %m "${dir}/package-lock.json")) / 86400 ))
                else
                    lock_age=$(( ($(date +%s) - $(stat -c %Y "${dir}/package-lock.json" 2>/dev/null || echo "$(date +%s)")) / 86400 ))
                fi
                if [[ $lock_age -gt 90 ]]; then
                    DS_OUTDATED_COUNT=$((lock_age / 30))
                    echo "$DS_OUTDATED_COUNT"
                    return 0
                fi
            fi
            ;;
    esac

    DS_OUTDATED_COUNT=0
    echo "0"
}

# =============================================================================
# ds_find_conflicts - バージョン競合検出
# =============================================================================
ds_find_conflicts() {
    local dir="${1:-$DS_PROJECT_DIR}"
    local conflicts=0

    case "$DS_MANAGER" in
        npm|yarn|pnpm)
            if [[ -f "${dir}/package.json" ]] && command -v node &>/dev/null; then
                # peerDependency警告をチェック
                local peer_issues
                peer_issues=$(node -e "
                    try {
                        const p=JSON.parse(require('fs').readFileSync('${dir}/package.json','utf8'));
                        const peers=p.peerDependencies||{};
                        const deps=Object.assign({},p.dependencies||{},p.devDependencies||{});
                        let c=0;
                        for(const [k,v] of Object.entries(peers)){
                            if(!deps[k]) c++;
                        }
                        console.log(c);
                    } catch(e) { console.log(0); }
                " 2>/dev/null || echo "0")
                peer_issues=$(echo "$peer_issues" | tr -d '[:space:]')
                [[ -z "$peer_issues" ]] && peer_issues=0
                conflicts=$peer_issues
            fi
            ;;
    esac

    DS_CONFLICT_COUNT=$conflicts
    echo "$conflicts"
}

# =============================================================================
# ds_auto_fix - 自動修復実行
# Returns: fix_count
# =============================================================================
ds_auto_fix() {
    local dir="${1:-$DS_PROJECT_DIR}"
    local fixed=0

    case "$DS_MANAGER" in
        npm)
            # node_modules不足→npm install
            if [[ ! -d "${dir}/node_modules" && -f "${dir}/package.json" ]]; then
                if command -v npm &>/dev/null; then
                    (cd "$dir" && npm install --legacy-peer-deps 2>/dev/null) && fixed=$((fixed + 1))
                fi
            fi
            # lockfile不足→生成
            if [[ ! -f "${dir}/package-lock.json" && -f "${dir}/package.json" ]]; then
                if command -v npm &>/dev/null; then
                    (cd "$dir" && npm install --package-lock-only 2>/dev/null) && fixed=$((fixed + 1))
                fi
            fi
            ;;
        yarn)
            if [[ ! -d "${dir}/node_modules" && -f "${dir}/package.json" ]]; then
                if command -v yarn &>/dev/null; then
                    (cd "$dir" && yarn install 2>/dev/null) && fixed=$((fixed + 1))
                fi
            fi
            ;;
        pip)
            # requirements.txtの構文エラーを修正（重複行除去）
            if [[ -f "${dir}/requirements.txt" ]]; then
                local orig_lines new_lines
                orig_lines=$(wc -l < "${dir}/requirements.txt" | tr -d ' ')
                sort -u -o "${dir}/requirements.txt" "${dir}/requirements.txt" 2>/dev/null
                new_lines=$(wc -l < "${dir}/requirements.txt" | tr -d ' ')
                [[ "$orig_lines" != "$new_lines" ]] && fixed=$((fixed + 1))
            fi
            ;;
    esac

    DS_FIX_COUNT=$((DS_FIX_COUNT + fixed))
    echo "$fixed"
}

# =============================================================================
# ds_get_stats - 統計情報をJSON形式で返す
# =============================================================================
ds_get_stats() {
    cat <<EOF
{
  "version": "${DS_VERSION}",
  "manager": "${DS_MANAGER}",
  "total_deps": ${DS_TOTAL_DEPS},
  "unused_count": ${DS_UNUSED_COUNT},
  "outdated_count": ${DS_OUTDATED_COUNT},
  "conflict_count": ${DS_CONFLICT_COUNT},
  "fix_count": ${DS_FIX_COUNT},
  "checks_run": ${DS_CHECKS_RUN}
}
EOF
}

# =============================================================================
# ds_save_history - 履歴永続化
# =============================================================================
ds_save_history() {
    [[ -z "$DS_HISTORY_FILE" ]] && return 0

    local timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date +"%Y-%m-%d")

    echo "{\"timestamp\":\"${timestamp}\",\"manager\":\"${DS_MANAGER}\",\"total_deps\":${DS_TOTAL_DEPS},\"unused\":${DS_UNUSED_COUNT},\"outdated\":${DS_OUTDATED_COUNT},\"conflicts\":${DS_CONFLICT_COUNT},\"fixes\":${DS_FIX_COUNT}}" >> "$DS_HISTORY_FILE" 2>/dev/null || true
    return 0
}
