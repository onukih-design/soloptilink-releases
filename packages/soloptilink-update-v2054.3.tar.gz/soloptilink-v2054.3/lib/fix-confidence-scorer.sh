#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v253.0 - Fix Confidence Scorer
# =============================================================================
# 提案された修正の信頼度をスコアリングし、最適な修正を選択するエンジン。
#
# 問題: 複数の修正候補がある場合、どれが最も安全で効果的かわからない。
#   - 過去に成功した修正パターンを活用できていない
#   - 副作用のリスクが見積もれない
#   - 修正スコープが適切かどうか判断できない
#
# 解決: 修正候補を多面的に評価し、0-100のスコアで信頼度を付与。
#   過去の成功率、副作用リスク、スコープ適切性を総合判断。
#
# Functions:
#   fcs_init                  - 初期化
#   _fcs_score_fix            - 修正案をスコアリング (0-100)
#   _fcs_check_past_success   - 過去の類似修正の成功率を確認
#   _fcs_check_side_effects   - 副作用リスクを推定
#   _fcs_check_scope          - 修正スコープの適切性を判定
#   _fcs_rank_fixes           - 複数修正案をスコアでランキング
#   _fcs_get_recommendation   - 最良の修正案と説明を返す
#   fcs_report                - レポート出力
#   fcs_score                 - モジュールスコア(0-100)
#
# All globals use the FCS_ prefix.
# =============================================================================

[[ -n "${_FIX_CONFIDENCE_SCORER_LOADED:-}" ]] && return 0
_FIX_CONFIDENCE_SCORER_LOADED=1

FCS_VERSION="253.0"
FCS_INITIALIZED=false

# --- Paths ---
FCS_KNOWLEDGE_DIR=""
FCS_HISTORY_FILE=""

# --- Counters ---
FCS_TOTAL_SCORED=0
FCS_HIGH_CONFIDENCE=0
FCS_MEDIUM_CONFIDENCE=0
FCS_LOW_CONFIDENCE=0

# --- In-memory storage ---
declare -g -A _FCS_PAST_FIXES=()       # fix_pattern → success_count:total_count
declare -g -A _FCS_SCORED_RESULTS=()    # fix_hash → score
declare -g -a _FCS_RANKING_CACHE=()     # recent ranking results

# =============================================================================
# fcs_init - Initialize fix confidence scorer
# =============================================================================
fcs_init() {
    FCS_KNOWLEDGE_DIR="${HOME}/.soloptilink/knowledge"
    mkdir -p "$FCS_KNOWLEDGE_DIR" 2>/dev/null || true

    FCS_HISTORY_FILE="${FCS_KNOWLEDGE_DIR}/fix-confidence-history.jsonl"

    FCS_TOTAL_SCORED=0
    FCS_HIGH_CONFIDENCE=0
    FCS_MEDIUM_CONFIDENCE=0
    FCS_LOW_CONFIDENCE=0
    _FCS_PAST_FIXES=()
    _FCS_SCORED_RESULTS=()
    _FCS_RANKING_CACHE=()

    # Load past fix data
    _fcs_load_history

    FCS_INITIALIZED=true
    return 0
}

# =============================================================================
# _fcs_hash_fix - Generate hash for a fix description
# =============================================================================
_fcs_hash_fix() {
    echo "${1:-}" | head -c 150 | cksum | awk '{print $1}'
}

# =============================================================================
# _fcs_score_fix - Score a proposed fix (0-100)
# Arguments:
#   $1 - error_message (the original error)
#   $2 - fix_description (what the fix does)
#   $3 - fix_file (target file to modify)
#   $4 - project_dir (optional)
#   $5 - fix_lines_changed (optional, estimated lines changed)
# Returns:
#   JSON with score and breakdown via stdout
# =============================================================================
_fcs_score_fix() {
    local error_message="${1:-}"
    local fix_description="${2:-}"
    local fix_file="${3:-}"
    local project_dir="${4:-.}"
    local fix_lines="${5:-0}"

    [[ -z "$fix_description" ]] && echo '{"score":0,"reason":"修正説明なし"}' && return 1

    FCS_TOTAL_SCORED=$((FCS_TOTAL_SCORED + 1))

    local total_score=0
    local breakdown=""

    # === Factor 1: Past success rate (0-30 points) ===
    local past_score=0
    local past_data
    past_data=$(_fcs_check_past_success "$error_message" "$fix_description")
    local past_rate
    past_rate=$(echo "$past_data" | grep -oE '"success_rate":[0-9]+' | sed 's/"success_rate"://')
    past_rate="${past_rate:-0}"

    if [[ $past_rate -gt 0 ]]; then
        past_score=$(( (past_rate * 30) / 100 ))
    else
        # No history = neutral (15 points)
        past_score=15
    fi
    total_score=$((total_score + past_score))
    breakdown="\"past_success\":${past_score}"

    # === Factor 2: Side effect risk (0-25 points, lower risk = higher score) ===
    local side_effect_score=0
    local side_effects
    side_effects=$(_fcs_check_side_effects "$fix_file" "$project_dir" "$fix_lines")
    local risk_level
    risk_level=$(echo "$side_effects" | grep -oE '"risk_level":"[^"]*"' | sed 's/"risk_level":"//;s/"//')

    case "$risk_level" in
        "low")    side_effect_score=25 ;;
        "medium") side_effect_score=15 ;;
        "high")   side_effect_score=5 ;;
        *)        side_effect_score=12 ;;
    esac
    total_score=$((total_score + side_effect_score))
    breakdown="${breakdown},\"side_effect_risk\":${side_effect_score}"

    # === Factor 3: Scope appropriateness (0-20 points) ===
    local scope_score=0
    local scope_data
    scope_data=$(_fcs_check_scope "$fix_file" "$fix_lines" "$error_message")
    local scope_verdict
    scope_verdict=$(echo "$scope_data" | grep -oE '"verdict":"[^"]*"' | sed 's/"verdict":"//;s/"//')

    case "$scope_verdict" in
        "appropriate")    scope_score=20 ;;
        "slightly_narrow") scope_score=14 ;;
        "slightly_broad")  scope_score=12 ;;
        "too_narrow")     scope_score=5 ;;
        "too_broad")      scope_score=3 ;;
        *)                scope_score=10 ;;
    esac
    total_score=$((total_score + scope_score))
    breakdown="${breakdown},\"scope\":${scope_score}"

    # === Factor 4: Fix targets the right location (0-15 points) ===
    local location_score=0
    if [[ -n "$fix_file" ]]; then
        # Check if fix file is in error trace
        if echo "$error_message" | grep -qF "$(basename "$fix_file" 2>/dev/null)"; then
            location_score=10
        fi

        # Check if fix file exists
        if [[ -f "${project_dir}/${fix_file}" || -f "$fix_file" ]]; then
            location_score=$((location_score + 5))
        fi
    fi
    total_score=$((total_score + location_score))
    breakdown="${breakdown},\"location\":${location_score}"

    # === Factor 5: Fix description quality (0-10 points) ===
    local desc_score=0
    local desc_len=${#fix_description}

    # Reasonable length
    if [[ $desc_len -ge 20 && $desc_len -le 500 ]]; then
        desc_score=$((desc_score + 3))
    fi

    # Contains actionable verbs
    if echo "$fix_description" | grep -qiE '追加|修正|変更|削除|更新|移動|add|fix|change|remove|update|move|replace|refactor'; then
        desc_score=$((desc_score + 3))
    fi

    # References specific file/function
    if echo "$fix_description" | grep -qE '\.(ts|tsx|js|jsx|json|prisma)|function|export|import|const|interface|type '; then
        desc_score=$((desc_score + 2))
    fi

    # Has clear before/after
    if echo "$fix_description" | grep -qiE 'から|へ|→|before.*after|instead of|replace.*with'; then
        desc_score=$((desc_score + 2))
    fi

    total_score=$((total_score + desc_score))
    breakdown="${breakdown},\"description_quality\":${desc_score}"

    # === Clamp score ===
    [[ $total_score -gt 100 ]] && total_score=100
    [[ $total_score -lt 0 ]] && total_score=0

    # Update confidence buckets
    if [[ $total_score -ge 70 ]]; then
        FCS_HIGH_CONFIDENCE=$((FCS_HIGH_CONFIDENCE + 1))
    elif [[ $total_score -ge 40 ]]; then
        FCS_MEDIUM_CONFIDENCE=$((FCS_MEDIUM_CONFIDENCE + 1))
    else
        FCS_LOW_CONFIDENCE=$((FCS_LOW_CONFIDENCE + 1))
    fi

    # Cache result
    local fix_hash
    fix_hash=$(_fcs_hash_fix "$fix_description")
    _FCS_SCORED_RESULTS["$fix_hash"]="$total_score"

    # Build confidence label
    local confidence_label="low"
    if [[ $total_score -ge 70 ]]; then
        confidence_label="high"
    elif [[ $total_score -ge 40 ]]; then
        confidence_label="medium"
    fi

    cat <<EOF
{
  "score": ${total_score},
  "confidence": "${confidence_label}",
  "breakdown": {${breakdown}},
  "fix_description": "$(echo "$fix_description" | head -c 200 | sed 's/"/\\"/g')",
  "fix_file": "${fix_file:-}"
}
EOF
    return 0
}

# =============================================================================
# _fcs_check_past_success - Check success rate of similar fixes
# Arguments:
#   $1 - error_message
#   $2 - fix_description
# Returns:
#   JSON with past fix stats
# =============================================================================
_fcs_check_past_success() {
    local error_message="${1:-}"
    local fix_description="${2:-}"

    local total_matches=0
    local total_success=0

    # Extract error signature (key words)
    local error_sig
    error_sig=$(echo "$error_message" | grep -oE '[A-Z][a-zA-Z]+Error|Cannot [a-z]+|not found|not assignable|does not exist' | head -1)

    # Extract fix signature
    local fix_sig
    fix_sig=$(echo "$fix_description" | grep -oE '追加|修正|変更|削除|import|export|type|schema|route|env' | head -3 | tr '\n' '_' | sed 's/_$//')

    local pattern_key="${error_sig}::${fix_sig}"

    # Check in-memory past fixes
    if [[ -n "${_FCS_PAST_FIXES[$pattern_key]:-}" ]]; then
        local data="${_FCS_PAST_FIXES[$pattern_key]}"
        total_success=$(echo "$data" | cut -d: -f1)
        total_matches=$(echo "$data" | cut -d: -f2)
    fi

    # Also check knowledge dir for historical data
    if [[ $total_matches -eq 0 && -d "$FCS_KNOWLEDGE_DIR" ]]; then
        if [[ -n "$error_sig" ]]; then
            local hist_count
            hist_count=$(grep -rlc "$error_sig" "${FCS_KNOWLEDGE_DIR}/" 2>/dev/null | awk -F: '{s+=$NF} END {print s+0}')
            if [[ "${hist_count:-0}" -gt 0 ]]; then
                total_matches=$((hist_count))
                # Assume 60% success rate for historical patterns with matching error sig
                total_success=$(( (total_matches * 60) / 100 ))
            fi
        fi
    fi

    local success_rate=0
    if [[ $total_matches -gt 0 ]]; then
        success_rate=$(( (total_success * 100) / total_matches ))
    fi

    cat <<EOF
{
  "pattern_key": "${pattern_key}",
  "total_matches": ${total_matches},
  "total_success": ${total_success},
  "success_rate": ${success_rate}
}
EOF
    return 0
}

# =============================================================================
# _fcs_check_side_effects - Estimate side effect risk of a fix
# Arguments:
#   $1 - fix_file
#   $2 - project_dir
#   $3 - fix_lines_changed
# Returns:
#   JSON with risk assessment
# =============================================================================
_fcs_check_side_effects() {
    local fix_file="${1:-}"
    local project_dir="${2:-.}"
    local fix_lines="${3:-0}"

    local risk_level="low"
    local risk_score=0
    local reasons=""

    # Factor 1: Number of lines changed
    if [[ $fix_lines -gt 50 ]]; then
        risk_score=$((risk_score + 30))
        reasons="${reasons}大量の行変更(${fix_lines}行); "
    elif [[ $fix_lines -gt 20 ]]; then
        risk_score=$((risk_score + 15))
        reasons="${reasons}中程度の行変更(${fix_lines}行); "
    elif [[ $fix_lines -gt 0 ]]; then
        risk_score=$((risk_score + 5))
    fi

    # Factor 2: File importance/centrality
    if [[ -n "$fix_file" ]]; then
        local basename_file
        basename_file=$(basename "$fix_file" 2>/dev/null)

        # High-risk files
        case "$basename_file" in
            prisma|schema.prisma)
                risk_score=$((risk_score + 25))
                reasons="${reasons}DBスキーマ変更は全APIに影響; "
                ;;
            middleware.ts|middleware.js)
                risk_score=$((risk_score + 20))
                reasons="${reasons}ミドルウェアは全ルートに影響; "
                ;;
            package.json)
                risk_score=$((risk_score + 15))
                reasons="${reasons}依存関係変更はビルド全体に影響; "
                ;;
            tsconfig.json)
                risk_score=$((risk_score + 15))
                reasons="${reasons}TypeScript設定は全ファイルに影響; "
                ;;
            layout.tsx|layout.ts)
                risk_score=$((risk_score + 15))
                reasons="${reasons}レイアウト変更は全子ページに影響; "
                ;;
            .env|.env.local)
                risk_score=$((risk_score + 10))
                reasons="${reasons}環境変数変更は複数サービスに影響; "
                ;;
        esac

        # Shared/lib files are higher risk
        if echo "$fix_file" | grep -qE '(lib/|utils/|shared/|common/|hooks/)'; then
            risk_score=$((risk_score + 10))
            reasons="${reasons}共有モジュールは多くのファイルからimportされる; "
        fi

        # Count how many files import this file
        if [[ -n "$fix_file" ]]; then
            local basename_no_ext
            basename_no_ext=$(echo "$basename_file" | sed 's/\.[^.]*$//')

            local import_count=0
            if [[ -d "$project_dir" ]]; then
                import_count=$(grep -rlE "from.*${basename_no_ext}" "$project_dir" \
                    --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" 2>/dev/null | \
                    grep -v node_modules | wc -l | tr -d ' ')
            fi

            if [[ $import_count -gt 10 ]]; then
                risk_score=$((risk_score + 20))
                reasons="${reasons}${import_count}個のファイルが依存; "
            elif [[ $import_count -gt 5 ]]; then
                risk_score=$((risk_score + 10))
                reasons="${reasons}${import_count}個のファイルが依存; "
            fi
        fi
    fi

    # Factor 3: Type of change (inferred from description)
    # (This factor is handled by caller context)

    # Determine risk level
    if [[ $risk_score -ge 40 ]]; then
        risk_level="high"
    elif [[ $risk_score -ge 20 ]]; then
        risk_level="medium"
    else
        risk_level="low"
    fi

    cat <<EOF
{
  "risk_level": "${risk_level}",
  "risk_score": ${risk_score},
  "reasons": "$(echo "$reasons" | sed 's/; $//' | sed 's/"/\\"/g')"
}
EOF
    return 0
}

# =============================================================================
# _fcs_check_scope - Check if fix scope is appropriate
# Arguments:
#   $1 - fix_file
#   $2 - fix_lines_changed
#   $3 - error_message
# Returns:
#   JSON with scope verdict
# =============================================================================
_fcs_check_scope() {
    local fix_file="${1:-}"
    local fix_lines="${2:-0}"
    local error_message="${3:-}"

    local verdict="appropriate"
    local explanation=""

    # Count how many files the error mentions
    local error_file_count
    error_file_count=$(echo "$error_message" | grep -oE '[a-zA-Z0-9_/.-]+\.(ts|tsx|js|jsx)' | sort -u | wc -l | tr -d ' ')

    # Heuristic: if error mentions multiple files but fix is single file with few lines
    if [[ $error_file_count -gt 3 && $fix_lines -le 5 ]]; then
        verdict="too_narrow"
        explanation="エラーが${error_file_count}ファイルに言及しているが、修正が${fix_lines}行と少なすぎる可能性"
    fi

    # Heuristic: fix changes too many lines for a simple error
    if echo "$error_message" | grep -qiE 'typo|spelling|missing semicolon|missing comma'; then
        if [[ $fix_lines -gt 20 ]]; then
            verdict="too_broad"
            explanation="単純なエラーに対して${fix_lines}行の変更は過剰"
        fi
    fi

    # Heuristic: schema change for a single API error
    if echo "$fix_file" | grep -qE 'schema\.prisma'; then
        if echo "$error_message" | grep -qiE 'single|one|specific'; then
            verdict="slightly_broad"
            explanation="スキーマ変更は影響範囲が広い"
        else
            verdict="appropriate"
            explanation="DBスキーマの修正は根本解決として適切"
        fi
    fi

    # Heuristic: single line fix for a complex error
    if [[ $fix_lines -eq 1 ]] && echo "$error_message" | grep -qiE 'multiple|several|many'; then
        verdict="slightly_narrow"
        explanation="複雑なエラーに対して1行修正は不十分な可能性"
    fi

    # If no issue detected, it's appropriate
    if [[ -z "$explanation" ]]; then
        explanation="修正スコープは問題なし"
    fi

    cat <<EOF
{
  "verdict": "${verdict}",
  "fix_lines": ${fix_lines},
  "error_files_mentioned": ${error_file_count},
  "explanation": "${explanation}"
}
EOF
    return 0
}

# =============================================================================
# _fcs_rank_fixes - Rank multiple fix proposals by confidence
# Arguments:
#   $1 - error_message
#   $2 - project_dir
#   $3..N - fix descriptions (pipe-separated: "desc|file|lines")
# Returns:
#   JSON array of ranked fixes via stdout
# =============================================================================
_fcs_rank_fixes() {
    local error_message="${1:-}"
    local project_dir="${2:-.}"
    shift 2

    local temp_file
    temp_file=$(mktemp 2>/dev/null || echo "/tmp/fcs_rank_$$")
    : > "$temp_file"

    local idx=0
    for fix_spec in "$@"; do
        local desc file lines
        desc=$(echo "$fix_spec" | cut -d'|' -f1)
        file=$(echo "$fix_spec" | cut -d'|' -f2)
        lines=$(echo "$fix_spec" | cut -d'|' -f3)

        local score_json
        score_json=$(_fcs_score_fix "$error_message" "$desc" "$file" "$project_dir" "$lines")

        local score
        score=$(echo "$score_json" | grep -oE '"score":[0-9]+' | sed 's/"score"://')

        echo "${score:-0} ${idx} $(echo "$score_json" | tr '\n' ' ')" >> "$temp_file"
        idx=$((idx + 1))
    done

    # Sort by score descending
    local sorted
    sorted=$(sort -rn "$temp_file")

    local result="["
    local first=true

    while IFS= read -r line; do
        [[ -z "$line" ]] && continue

        local score rank json_part
        score=$(echo "$line" | awk '{print $1}')
        rank=$(echo "$line" | awk '{print $2}')
        json_part=$(echo "$line" | cut -d' ' -f3-)

        if [[ "$first" == "true" ]]; then
            first=false
        else
            result="${result},"
        fi

        result="${result}{\"rank\":$((rank + 1)),\"original_index\":${rank},${json_part#\{}}"
    done <<< "$sorted"

    result="${result}]"

    rm -f "$temp_file" 2>/dev/null

    # Cache the ranking
    _FCS_RANKING_CACHE+=("$result")
    if [[ ${#_FCS_RANKING_CACHE[@]} -gt 20 ]]; then
        _FCS_RANKING_CACHE=("${_FCS_RANKING_CACHE[@]:1}")
    fi

    echo "$result"
    return 0
}

# =============================================================================
# _fcs_get_recommendation - Return best fix with confidence explanation
# Arguments:
#   $1 - error_message
#   $2 - project_dir
#   $3..N - fix descriptions (pipe-separated)
# Returns:
#   JSON with best fix and explanation
# =============================================================================
_fcs_get_recommendation() {
    local error_message="${1:-}"
    local project_dir="${2:-.}"
    shift 2

    local ranked
    ranked=$(_fcs_rank_fixes "$error_message" "$project_dir" "$@")

    # Extract the top-ranked fix
    local best_score best_confidence best_desc
    best_score=$(echo "$ranked" | grep -oE '"score":[0-9]+' | head -1 | sed 's/"score"://')
    best_confidence=$(echo "$ranked" | grep -oE '"confidence":"[^"]*"' | head -1 | sed 's/"confidence":"//;s/"//')
    best_desc=$(echo "$ranked" | grep -oE '"fix_description":"[^"]*"' | head -1 | sed 's/"fix_description":"//;s/"//')

    local recommendation=""
    local action=""

    if [[ ${best_score:-0} -ge 70 ]]; then
        recommendation="この修正を強く推奨します。過去の成功パターンと合致し、副作用リスクも低いです。"
        action="apply"
    elif [[ ${best_score:-0} -ge 50 ]]; then
        recommendation="この修正は妥当ですが、適用後にテストで動作確認することを推奨します。"
        action="apply_with_test"
    elif [[ ${best_score:-0} -ge 30 ]]; then
        recommendation="この修正には不確実性があります。手動レビュー後に適用することを推奨します。"
        action="review_first"
    else
        recommendation="この修正は信頼度が低いため、手動分析を推奨します。"
        action="manual_analysis"
    fi

    local fix_count=$#

    cat <<EOF
{
  "recommended_fix": "${best_desc:-}",
  "score": ${best_score:-0},
  "confidence": "${best_confidence:-low}",
  "recommendation": "${recommendation}",
  "action": "${action}",
  "alternatives_count": ${fix_count},
  "ranking": ${ranked}
}
EOF
    return 0
}

# =============================================================================
# _fcs_record_fix_outcome - Record whether an applied fix succeeded
# Arguments:
#   $1 - error_signature
#   $2 - fix_signature
#   $3 - success ("true"/"false")
# =============================================================================
_fcs_record_fix_outcome() {
    local error_sig="${1:-}"
    local fix_sig="${2:-}"
    local success="${3:-false}"

    [[ -z "$error_sig" || -z "$fix_sig" ]] && return 1

    local pattern_key="${error_sig}::${fix_sig}"
    local prev="${_FCS_PAST_FIXES[$pattern_key]:-0:0}"
    local prev_success prev_total
    prev_success=$(echo "$prev" | cut -d: -f1)
    prev_total=$(echo "$prev" | cut -d: -f2)

    prev_total=$((prev_total + 1))
    if [[ "$success" == "true" ]]; then
        prev_success=$((prev_success + 1))
    fi

    _FCS_PAST_FIXES["$pattern_key"]="${prev_success}:${prev_total}"

    # Persist
    _fcs_save_history "$pattern_key" "$prev_success" "$prev_total"
    return 0
}

# =============================================================================
# _fcs_load_history / _fcs_save_history - Persistence
# =============================================================================
_fcs_load_history() {
    [[ ! -f "$FCS_HISTORY_FILE" ]] && return 0

    while IFS= read -r line; do
        [[ -z "$line" ]] && continue

        local key success total
        key=$(echo "$line" | grep -oE '"pattern_key":"[^"]*"' | sed 's/"pattern_key":"//;s/"//')
        success=$(echo "$line" | grep -oE '"success":[0-9]*' | sed 's/"success"://')
        total=$(echo "$line" | grep -oE '"total":[0-9]*' | sed 's/"total"://')

        [[ -z "$key" ]] && continue
        _FCS_PAST_FIXES["$key"]="${success:-0}:${total:-0}"
    done < "$FCS_HISTORY_FILE"

    return 0
}

_fcs_save_history() {
    local key="${1:-}"
    local success="${2:-0}"
    local total="${3:-0}"

    [[ -z "$key" || -z "$FCS_HISTORY_FILE" ]] && return 0

    echo "{\"pattern_key\":\"${key}\",\"success\":${success},\"total\":${total},\"ts\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}" >> "$FCS_HISTORY_FILE" 2>/dev/null || true

    # Rotate
    local lines
    lines=$(wc -l < "$FCS_HISTORY_FILE" 2>/dev/null | tr -d ' ')
    if [[ "${lines:-0}" -gt 1000 ]]; then
        tail -500 "$FCS_HISTORY_FILE" > "${FCS_HISTORY_FILE}.tmp" 2>/dev/null
        mv "${FCS_HISTORY_FILE}.tmp" "$FCS_HISTORY_FILE" 2>/dev/null || true
    fi

    return 0
}

# =============================================================================
# fcs_report - Module report output
# =============================================================================
fcs_report() {
    echo -e "\n  ${CLR_BOLD:-}═══ Fix Confidence Scorer v${FCS_VERSION} ═══${CLR_NC:-}" >&2
    echo -e "  スコアリング総数   : ${FCS_TOTAL_SCORED}" >&2
    echo -e "  高信頼度 (70+)     : ${FCS_HIGH_CONFIDENCE}" >&2
    echo -e "  中信頼度 (40-69)   : ${FCS_MEDIUM_CONFIDENCE}" >&2
    echo -e "  低信頼度 (0-39)    : ${FCS_LOW_CONFIDENCE}" >&2

    if [[ $FCS_TOTAL_SCORED -gt 0 ]]; then
        local high_rate=$(( (FCS_HIGH_CONFIDENCE * 100) / FCS_TOTAL_SCORED ))
        echo -e "  高信頼度比率       : ${high_rate}%" >&2
    fi

    local past_count=${#_FCS_PAST_FIXES[@]}
    echo -e "  過去パターン数     : ${past_count}" >&2
}

# =============================================================================
# fcs_score - Module score (0-100)
# =============================================================================
fcs_score() {
    local score=50

    if [[ $FCS_TOTAL_SCORED -gt 0 ]]; then
        local high_rate=$(( (FCS_HIGH_CONFIDENCE * 100) / FCS_TOTAL_SCORED ))
        score=$((40 + (high_rate * 40 / 100)))
    fi

    # Bonus for having past data
    local past_count=${#_FCS_PAST_FIXES[@]}
    if [[ $past_count -ge 10 ]]; then
        score=$((score + 10))
    fi
    if [[ $past_count -ge 50 ]]; then
        score=$((score + 10))
    fi

    [[ $score -gt 100 ]] && score=100
    [[ $score -lt 0 ]] && score=0

    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "fix-confidence-scorer" \
    --version "253.0" \
    --description "修正案の信頼度を多面的スコアリング・最適選択" \
    --init "fcs_init" \
    --report "fcs_report" \
    --score "fcs_score" \
    --enable-var "ENABLE_FCS" \
    --cli-flags "--fix-confidence:--no-fix-confidence"
