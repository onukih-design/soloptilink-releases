#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v385.0 - Workflow Template Engine
# =============================================================================
# ワークフローテンプレートエンジン。
# 承認ワークフロー/レビューフロー/エスカレーションフロー等を自動生成。
#
# All globals use the WTE_ prefix.
# =============================================================================

[[ -n "${_WORKFLOW_TEMPLATE_ENGINE_LOADED:-}" ]] && return 0
_WORKFLOW_TEMPLATE_ENGINE_LOADED=1

declare -g WTE_VERSION="385.0"
declare -g WTE_INITIALIZED=false
declare -g WTE_GENERATED_COUNT=0
declare -g WTE_APPROVAL_GENERATED=false
declare -g WTE_REVIEW_GENERATED=false
declare -g WTE_ESCALATION_GENERATED=false
declare -g WTE_PARALLEL_GENERATED=false
declare -g ENABLE_WTE="${ENABLE_WTE:-true}"

_wte_init() {
    WTE_INITIALIZED=true
    WTE_GENERATED_COUNT=0
    return 0
}

_wte_generate_all() {
    local project_dir="${1:-.}"
    [[ "$WTE_INITIALIZED" != "true" ]] && _wte_init

    echo -e "  ${CYAN:-\033[0;36m}[WTE]${NC:-\033[0m} ワークフローテンプレート生成開始..." >&2

    _wte_generate_approval "$project_dir"
    _wte_generate_review "$project_dir"
    _wte_generate_escalation "$project_dir"
    _wte_generate_parallel "$project_dir"

    echo -e "  ${GREEN:-\033[0;32m}[WTE]${NC:-\033[0m} ワークフロー生成完了: ${WTE_GENERATED_COUNT}件" >&2
    return 0
}

_wte_generate_approval() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [WTE-APPROVAL] 承認ワークフローテンプレート

### Workflow Engine
```typescript
interface WorkflowDefinition {
  id: string;
  name: string;
  steps: WorkflowStep[];
  onComplete: (context: WorkflowContext) => Promise<void>;
  onReject: (context: WorkflowContext) => Promise<void>;
}

interface WorkflowStep {
  id: string;
  name: string;
  type: 'approval' | 'review' | 'notification' | 'auto';
  assignee: string | ((ctx: WorkflowContext) => Promise<string>);
  timeout?: number;
  onTimeout?: 'escalate' | 'auto_approve' | 'reject';
}

export class WorkflowEngine {
  async start(definitionId: string, context: Record<string, any>): Promise<string> {
    const def = await this.getDefinition(definitionId);
    const instance = await prisma.workflowInstance.create({
      data: { definitionId, context: JSON.stringify(context), currentStepIndex: 0, status: 'active' },
    });
    await this.activateStep(instance.id, 0);
    return instance.id;
  }

  async processAction(instanceId: string, action: 'approve' | 'reject', userId: string, comment?: string) {
    const instance = await prisma.workflowInstance.findUniqueOrThrow({ where: { id: instanceId } });
    const def = await this.getDefinition(instance.definitionId);
    const step = def.steps[instance.currentStepIndex];

    await prisma.workflowAction.create({
      data: { instanceId, stepId: step.id, action, userId, comment },
    });

    if (action === 'reject') {
      await prisma.workflowInstance.update({ where: { id: instanceId }, data: { status: 'rejected' } });
      await def.onReject(JSON.parse(instance.context));
    } else {
      const nextIndex = instance.currentStepIndex + 1;
      if (nextIndex >= def.steps.length) {
        await prisma.workflowInstance.update({ where: { id: instanceId }, data: { status: 'completed' } });
        await def.onComplete(JSON.parse(instance.context));
      } else {
        await prisma.workflowInstance.update({ where: { id: instanceId }, data: { currentStepIndex: nextIndex } });
        await this.activateStep(instanceId, nextIndex);
      }
    }
  }

  private async activateStep(instanceId: string, stepIndex: number) {
    // 通知・タイムアウトスケジュール設定
  }

  private async getDefinition(id: string): Promise<WorkflowDefinition> {
    // 定義をDBまたはコードから取得
    return {} as WorkflowDefinition;
  }
}
```
TEMPLATE

    WTE_APPROVAL_GENERATED=true
    WTE_GENERATED_COUNT=$((WTE_GENERATED_COUNT + 1))
    return 0
}

_wte_generate_review() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [WTE-REVIEW] レビューワークフローテンプレート

```typescript
interface ReviewWorkflow {
  targetId: string;
  targetType: string;
  reviewers: string[];
  requiredApprovals: number;
  deadline: Date;
}

export class ReviewService {
  async createReview(workflow: ReviewWorkflow) {
    const review = await prisma.reviewRequest.create({
      data: {
        targetId: workflow.targetId, targetType: workflow.targetType,
        requiredApprovals: workflow.requiredApprovals, deadline: workflow.deadline,
        status: 'pending',
        reviewers: { create: workflow.reviewers.map(id => ({ userId: id, status: 'pending' })) },
      },
    });
    for (const reviewerId of workflow.reviewers) {
      await sendNotification(reviewerId, 'review_requested', { reviewId: review.id });
    }
    return review;
  }

  async submitReview(reviewId: string, reviewerId: string, decision: 'approve' | 'request_changes', comments: string) {
    await prisma.reviewer.update({
      where: { reviewId_userId: { reviewId, userId: reviewerId } },
      data: { status: decision, comments, reviewedAt: new Date() },
    });
    const review = await prisma.reviewRequest.findUniqueOrThrow({
      where: { id: reviewId }, include: { reviewers: true },
    });
    const approvedCount = review.reviewers.filter(r => r.status === 'approve').length;
    if (approvedCount >= review.requiredApprovals) {
      await prisma.reviewRequest.update({ where: { id: reviewId }, data: { status: 'approved' } });
    }
  }
}
```
TEMPLATE

    WTE_REVIEW_GENERATED=true
    WTE_GENERATED_COUNT=$((WTE_GENERATED_COUNT + 1))
    return 0
}

_wte_generate_escalation() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [WTE-ESCALATION] エスカレーションフローテンプレート

```typescript
interface EscalationRule {
  triggerAfterHours: number;
  escalateTo: string | ((ctx: any) => Promise<string>);
  notifyChannels: string[];
  maxLevel: number;
}

export class EscalationService {
  private rules: Record<string, EscalationRule[]> = {
    support_ticket: [
      { triggerAfterHours: 4, escalateTo: 'team_lead', notifyChannels: ['email', 'slack'], maxLevel: 3 },
      { triggerAfterHours: 8, escalateTo: 'manager', notifyChannels: ['email', 'slack', 'phone'], maxLevel: 3 },
      { triggerAfterHours: 24, escalateTo: 'director', notifyChannels: ['email', 'phone'], maxLevel: 3 },
    ],
    approval: [
      { triggerAfterHours: 24, escalateTo: 'skip_level_manager', notifyChannels: ['email'], maxLevel: 2 },
      { triggerAfterHours: 48, escalateTo: 'auto_approve', notifyChannels: ['email'], maxLevel: 2 },
    ],
  };

  async checkAndEscalate() {
    const pendingItems = await prisma.escalatableItem.findMany({
      where: { status: 'pending', escalationLevel: { lt: 3 } },
    });
    for (const item of pendingItems) {
      const rules = this.rules[item.type] ?? [];
      const hoursWaiting = differenceInHours(new Date(), item.createdAt);
      const rule = rules.find(r => hoursWaiting >= r.triggerAfterHours && item.escalationLevel < r.maxLevel);
      if (rule) {
        const target = typeof rule.escalateTo === 'function' ? await rule.escalateTo(item) : rule.escalateTo;
        await this.escalate(item.id, target, rule.notifyChannels);
      }
    }
  }

  private async escalate(itemId: string, target: string, channels: string[]) {
    await prisma.escalatableItem.update({
      where: { id: itemId }, data: { assignedTo: target, escalationLevel: { increment: 1 }, escalatedAt: new Date() },
    });
  }
}
```
TEMPLATE

    WTE_ESCALATION_GENERATED=true
    WTE_GENERATED_COUNT=$((WTE_GENERATED_COUNT + 1))
    return 0
}

_wte_generate_parallel() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [WTE-PARALLEL] 並列ワークフローテンプレート

```typescript
export class ParallelWorkflow {
  async executeParallel(tasks: WorkflowTask[], joinCondition: 'all' | 'any' = 'all'): Promise<WorkflowResult> {
    const results = await Promise.allSettled(tasks.map(t => this.executeTask(t)));
    const fulfilled = results.filter(r => r.status === 'fulfilled');
    if (joinCondition === 'all' && fulfilled.length < tasks.length) {
      const failed = results.filter(r => r.status === 'rejected').map((r, i) => ({ task: tasks[i].name, error: (r as PromiseRejectedResult).reason }));
      return { status: 'failed', completedTasks: fulfilled.length, failedTasks: failed };
    }
    return { status: 'completed', completedTasks: fulfilled.length, failedTasks: [] };
  }

  private async executeTask(task: WorkflowTask): Promise<any> {
    await prisma.workflowTaskLog.create({ data: { taskName: task.name, status: 'started', startedAt: new Date() } });
    try {
      const result = await task.execute();
      await prisma.workflowTaskLog.create({ data: { taskName: task.name, status: 'completed', completedAt: new Date() } });
      return result;
    } catch (error) {
      await prisma.workflowTaskLog.create({ data: { taskName: task.name, status: 'failed', error: String(error) } });
      throw error;
    }
  }
}
```
TEMPLATE

    WTE_PARALLEL_GENERATED=true
    WTE_GENERATED_COUNT=$((WTE_GENERATED_COUNT + 1))
    return 0
}

_wte_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Workflow Template Engine v${WTE_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成ワークフロー数 : ${WTE_GENERATED_COUNT}"
    echo -e "  承認フロー         : ${WTE_APPROVAL_GENERATED}"
    echo -e "  レビューフロー     : ${WTE_REVIEW_GENERATED}"
    echo -e "  エスカレーション   : ${WTE_ESCALATION_GENERATED}"
    echo -e "  並列フロー         : ${WTE_PARALLEL_GENERATED}"
}

_wte_score() {
    local score=30
    [[ "$WTE_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$WTE_APPROVAL_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$WTE_REVIEW_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$WTE_ESCALATION_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$WTE_PARALLEL_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "workflow-template-engine" \
    --version "385.0" \
    --description "ワークフローテンプレート（承認/レビュー/エスカレーション/並列）" \
    --init "_wte_init" \
    --report "_wte_report" \
    --score "_wte_score" \
    --enable-var "ENABLE_WTE" \
    --cli-flags "--workflow-templates:--no-workflow-templates"
