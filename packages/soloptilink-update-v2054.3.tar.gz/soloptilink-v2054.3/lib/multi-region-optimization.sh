#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v453.0 - Multi-Region Optimization Engine
# =============================================================================
# マルチリージョン最適化: レイテンシ最適化、データ同期、ルーティング戦略。
#
# Functions:
#   _mro_init()                - Initialize
#   _mro_optimize_latency()    - Latency-based routing optimization
#   _mro_generate_data_sync()  - Cross-region data synchronization
#   _mro_generate_routing()    - Geo-aware routing configuration
#   _mro_report() / _mro_score()
# =============================================================================

[[ -n "${_MRO_LOADED:-}" ]] && return 0; _MRO_LOADED=1

declare -g MRO_VERSION="453.0"
MRO_GENERATED=0; MRO_ERRORS=0; MRO_FILES_WRITTEN=0
MRO_LATENCY_OK=false; MRO_DATA_SYNC_OK=false; MRO_ROUTING_OK=false

_mro_init() {
    MRO_GENERATED=0; MRO_ERRORS=0; MRO_FILES_WRITTEN=0
    MRO_LATENCY_OK=false; MRO_DATA_SYNC_OK=false; MRO_ROUTING_OK=false
    return 0
}

_mro_log() { echo -e "  ${CYAN:-\033[0;36m}[multi-region]${NC:-\033[0m} $*" >&2; }
_mro_ok()  { echo -e "  ${GREEN:-\033[0;32m}✅ [multi-region]${NC:-\033[0m} $*" >&2; }
_mro_err() { echo -e "  ${RED:-\033[0;31m}❌ [multi-region]${NC:-\033[0m} $*" >&2; MRO_ERRORS=$((MRO_ERRORS + 1)); }

_mro_write_file() {
    local filepath="$1" content="$2"
    local dir; dir="$(dirname "$filepath")"
    [[ -d "$dir" ]] || mkdir -p "$dir"
    echo "$content" > "$filepath" 2>/dev/null || { _mro_err "Failed to write $filepath"; return 1; }
    MRO_FILES_WRITTEN=$((MRO_FILES_WRITTEN + 1))
    return 0
}

# =============================================================================
# Latency Optimization
# =============================================================================
_mro_optimize_latency() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/multi-region/latency-optimizer.ts"
    _mro_log "Generating latency optimizer..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v453.0 - Latency-Based Routing Optimizer

export interface RegionEndpoint {
  region: string;
  endpoint: string;
  avgLatencyMs: number;
  healthy: boolean;
  weight: number;
}

export interface LatencyMeasurement {
  region: string;
  latencyMs: number;
  timestamp: number;
}

export class LatencyOptimizer {
  private endpoints: Map<string, RegionEndpoint> = new Map();
  private measurements: LatencyMeasurement[] = [];
  private readonly maxHistory = 1000;
  private readonly staleThresholdMs = 300000; // 5 min

  addEndpoint(endpoint: RegionEndpoint): void {
    this.endpoints.set(endpoint.region, endpoint);
  }

  recordLatency(region: string, latencyMs: number): void {
    this.measurements.push({ region, latencyMs, timestamp: Date.now() });
    if (this.measurements.length > this.maxHistory) {
      this.measurements = this.measurements.slice(-this.maxHistory);
    }
    const ep = this.endpoints.get(region);
    if (ep) {
      // Exponential moving average
      ep.avgLatencyMs = ep.avgLatencyMs * 0.7 + latencyMs * 0.3;
    }
  }

  selectBestRegion(clientRegion?: string): RegionEndpoint | null {
    const healthy = Array.from(this.endpoints.values()).filter(e => e.healthy);
    if (healthy.length === 0) return null;
    // Prefer client's region if healthy
    if (clientRegion) {
      const local = healthy.find(e => e.region === clientRegion);
      if (local && local.avgLatencyMs < 100) return local;
    }
    // Sort by weighted latency
    healthy.sort((a, b) => (a.avgLatencyMs / a.weight) - (b.avgLatencyMs / b.weight));
    return healthy[0];
  }

  getRegionStats(): Array<{ region: string; avgMs: number; healthy: boolean }> {
    return Array.from(this.endpoints.values()).map(e => ({
      region: e.region,
      avgMs: Math.round(e.avgLatencyMs),
      healthy: e.healthy,
    }));
  }

  markUnhealthy(region: string): void {
    const ep = this.endpoints.get(region);
    if (ep) ep.healthy = false;
  }

  markHealthy(region: string): void {
    const ep = this.endpoints.get(region);
    if (ep) ep.healthy = true;
  }
}

export const latencyOptimizer = new LatencyOptimizer();
TYPESCRIPT
)
    _mro_write_file "$outfile" "$content" || return 1
    MRO_LATENCY_OK=true
    MRO_GENERATED=$((MRO_GENERATED + 1))
    _mro_ok "Latency optimizer generated"
    return 0
}

# =============================================================================
# Data Sync Generator
# =============================================================================
_mro_generate_data_sync() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/multi-region/data-sync.ts"
    _mro_log "Generating cross-region data sync..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v453.0 - Cross-Region Data Synchronization

export type ConflictResolution = 'last-write-wins' | 'first-write-wins' | 'merge' | 'manual';
export type SyncMode = 'async' | 'sync' | 'eventual';

export interface SyncConfig {
  sourceRegion: string;
  targetRegions: string[];
  mode: SyncMode;
  conflictResolution: ConflictResolution;
  batchSize: number;
  intervalMs: number;
  retryAttempts: number;
}

interface SyncEvent {
  id: string;
  table: string;
  operation: 'INSERT' | 'UPDATE' | 'DELETE';
  payload: Record<string, unknown>;
  sourceRegion: string;
  timestamp: number;
  version: number;
}

export class CrossRegionSync {
  private config: SyncConfig;
  private pendingEvents: SyncEvent[] = [];
  private syncedCount = 0;
  private conflictCount = 0;

  constructor(config: SyncConfig) { this.config = config; }

  queueEvent(event: Omit<SyncEvent, 'id' | 'timestamp'>): void {
    this.pendingEvents.push({
      ...event,
      id: `sync_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      timestamp: Date.now(),
    });
  }

  async flush(): Promise<{ synced: number; conflicts: number; errors: number }> {
    const batch = this.pendingEvents.splice(0, this.config.batchSize);
    let synced = 0, conflicts = 0, errors = 0;
    for (const event of batch) {
      try {
        // In production: send to target region's replication endpoint
        synced++;
        this.syncedCount++;
      } catch {
        errors++;
      }
    }
    return { synced, conflicts, errors };
  }

  getStatus(): { pending: number; synced: number; conflicts: number; config: SyncConfig } {
    return { pending: this.pendingEvents.length, synced: this.syncedCount, conflicts: this.conflictCount, config: this.config };
  }
}
TYPESCRIPT
)
    _mro_write_file "$outfile" "$content" || return 1
    MRO_DATA_SYNC_OK=true
    MRO_GENERATED=$((MRO_GENERATED + 1))
    _mro_ok "Data sync generated"
    return 0
}

# =============================================================================
# Routing Generator
# =============================================================================
_mro_generate_routing() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/multi-region/geo-routing.ts"
    _mro_log "Generating geo-aware routing..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v453.0 - Geo-Aware Request Routing

export interface GeoRoutingRule {
  name: string;
  continents?: string[];
  countries?: string[];
  targetRegion: string;
  fallbackRegion: string;
  weight: number;
}

export class GeoRouter {
  private rules: GeoRoutingRule[] = [];

  addRule(rule: GeoRoutingRule): void { this.rules.push(rule); }

  route(clientCountry: string, clientContinent: string): string {
    // Find matching rule by country first, then continent
    for (const rule of this.rules) {
      if (rule.countries?.includes(clientCountry)) return rule.targetRegion;
    }
    for (const rule of this.rules) {
      if (rule.continents?.includes(clientContinent)) return rule.targetRegion;
    }
    // Fallback to first rule's fallback
    return this.rules[0]?.fallbackRegion ?? 'us-east-1';
  }

  generateEdgeConfig(): string {
    return JSON.stringify({ rules: this.rules, version: Date.now() }, null, 2);
  }
}

export const geoRouter = new GeoRouter();
TYPESCRIPT
)
    _mro_write_file "$outfile" "$content" || return 1
    MRO_ROUTING_OK=true
    MRO_GENERATED=$((MRO_GENERATED + 1))
    _mro_ok "Geo routing generated"
    return 0
}

_mro_generate_all() {
    local project_dir="${1:-.}"
    _mro_log "Generating full multi-region optimization..."
    _mro_optimize_latency "$project_dir"
    _mro_generate_data_sync "$project_dir"
    _mro_generate_routing "$project_dir"
    _mro_ok "Multi-region complete: ${MRO_GENERATED} components, ${MRO_ERRORS} errors"
}

_mro_report() {
    echo -e "\n  ${BOLD:-\033[1m}═══ Multi-Region Optimization v${MRO_VERSION} ═══${NC:-\033[0m}"
    echo -e "  Generated  : ${MRO_GENERATED}"
    echo -e "  Errors     : ${MRO_ERRORS}"
    echo -e "  Latency    : ${MRO_LATENCY_OK}"
    echo -e "  Data Sync  : ${MRO_DATA_SYNC_OK}"
    echo -e "  Routing    : ${MRO_ROUTING_OK}"
}

_mro_report_json() {
    cat <<JSON
{"module":"multi-region-optimization","version":"${MRO_VERSION}","generated":${MRO_GENERATED},"errors":${MRO_ERRORS},"components":{"latency":${MRO_LATENCY_OK},"data_sync":${MRO_DATA_SYNC_OK},"routing":${MRO_ROUTING_OK}}}
JSON
}

_mro_score() {
    local score=50
    ${MRO_LATENCY_OK} && score=$((score + 15))
    ${MRO_DATA_SYNC_OK} && score=$((score + 15))
    ${MRO_ROUTING_OK} && score=$((score + 15))
    [[ ${MRO_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "multi-region-optimization" --version "453.0" \
        --description "マルチリージョン最適化: レイテンシ×データ同期×Geoルーティング" \
        --init "_mro_init" --report "_mro_report" --score "_mro_score" \
        --enable-var "ENABLE_MULTI_REGION" --cli-flags "--multi-region:--no-multi-region"
fi

# v2003.1: source時のexit codeを確実に0にする
true
