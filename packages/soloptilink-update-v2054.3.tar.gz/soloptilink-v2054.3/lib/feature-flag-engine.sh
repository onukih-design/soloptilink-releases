#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - Feature Flag Engine
# =============================================================================
# フィーチャーフラグ基盤×段階的ロールアウト×A/Bテスト
#
# 機能:
#   - フラグ評価エンジン（boolean/percentage/segment/schedule）
#   - CRUD API（フラグ管理REST API）
#   - Express/Next.js ミドルウェア（リクエストレベルのフラグゲーティング）
#   - React Hooks（useFeatureFlag, FeatureGate, withFeatureFlag HOC）
#   - ロールアウト戦略（%ロールアウト、ユーザーターゲティング、A/B）
#   - 管理ダッシュボード（フラグ一覧/切替/ロールアウト設定UI）
#   - Claude生成プロンプト注入
#
# 全globals: FF_ prefix
# =============================================================================

[[ -n "${_FFE_LOADED:-}" ]] && return 0; _FFE_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g FF_VERSION="140.0"
declare -g FF_INITIALIZED=false
declare -g FFE_GENERATED=0
declare -g FFE_ERRORS=0
declare -g FFE_PHASE="feature_flag"

# =============================================================================
# 初期化
# =============================================================================
ff_init() {
    FF_INITIALIZED=true
    FFE_GENERATED=0
    FFE_ERRORS=0
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} Feature Flag Engine v${FF_VERSION}"
}

# =============================================================================
# ユーティリティ: ファイル書き込み（ディレクトリ自動生成）
# =============================================================================
_ff_write_file() {
    local filepath="$1"
    local dir
    dir=$(dirname "$filepath")
    mkdir -p "$dir" 2>/dev/null
    cat > "$filepath"
    if [[ $? -eq 0 ]]; then
        FFE_GENERATED=$((FFE_GENERATED + 1))
        return 0
    else
        FFE_ERRORS=$((FFE_ERRORS + 1))
        return 1
    fi
}

# =============================================================================
# フラグサービス生成（評価エンジンコア）
# =============================================================================
ff_generate_flag_service() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local src_dir="${project_dir}/src/lib"

    _ff_write_file "${src_dir}/feature-flags.ts" <<'TYPESCRIPT'
import { prisma } from './prisma';
import crypto from 'crypto';

// --- Types ---
export type FlagType = 'boolean' | 'percentage' | 'segment' | 'schedule';
export type FlagValue = boolean | string | number;

export interface FlagContext {
  userId?: string;
  email?: string;
  role?: string;
  country?: string;
  attributes?: Record<string, string>;
}

export interface FeatureFlag {
  key: string;
  type: FlagType;
  enabled: boolean;
  percentage?: number;
  segments?: string[];
  scheduleStart?: Date;
  scheduleEnd?: Date;
  defaultValue: FlagValue;
  description?: string;
}

// --- In-memory cache ---
const flagCache = new Map<string, { flag: FeatureFlag; expiresAt: number }>();
const CACHE_TTL_MS = 30_000; // 30 seconds

async function getCachedFlag(key: string): Promise<FeatureFlag | null> {
  const cached = flagCache.get(key);
  if (cached && cached.expiresAt > Date.now()) {
    return cached.flag;
  }
  flagCache.delete(key);

  try {
    const dbFlag = await prisma.featureFlag.findUnique({ where: { key } });
    if (!dbFlag) return null;

    const flag: FeatureFlag = {
      key: dbFlag.key,
      type: dbFlag.type as FlagType,
      enabled: dbFlag.enabled,
      percentage: dbFlag.percentage ?? undefined,
      segments: dbFlag.segments ? JSON.parse(dbFlag.segments as string) : undefined,
      scheduleStart: dbFlag.scheduleStart ?? undefined,
      scheduleEnd: dbFlag.scheduleEnd ?? undefined,
      defaultValue: dbFlag.defaultValue as FlagValue,
      description: dbFlag.description ?? undefined,
    };

    flagCache.set(key, { flag, expiresAt: Date.now() + CACHE_TTL_MS });
    return flag;
  } catch (err) {
    console.error(`[FeatureFlags] Failed to fetch flag "${key}":`, err);
    return null;
  }
}

// --- Evaluation engine ---
function hashUserToPercentage(flagKey: string, userId: string): number {
  const hash = crypto.createHash('md5').update(`${flagKey}:${userId}`).digest('hex');
  const num = parseInt(hash.substring(0, 8), 16);
  return num % 100;
}

function evaluateSegment(flag: FeatureFlag, ctx: FlagContext): boolean {
  if (!flag.segments || flag.segments.length === 0) return true;
  const userSegments: string[] = [];
  if (ctx.role) userSegments.push(`role:${ctx.role}`);
  if (ctx.country) userSegments.push(`country:${ctx.country}`);
  if (ctx.email) {
    const domain = ctx.email.split('@')[1];
    if (domain) userSegments.push(`domain:${domain}`);
  }
  if (ctx.attributes) {
    for (const [k, v] of Object.entries(ctx.attributes)) {
      userSegments.push(`${k}:${v}`);
    }
  }
  return flag.segments.some((s) => userSegments.includes(s));
}

function evaluateSchedule(flag: FeatureFlag): boolean {
  const now = new Date();
  if (flag.scheduleStart && now < flag.scheduleStart) return false;
  if (flag.scheduleEnd && now > flag.scheduleEnd) return false;
  return true;
}

export async function evaluateFlag(key: string, ctx: FlagContext = {}): Promise<FlagValue> {
  const flag = await getCachedFlag(key);
  if (!flag) return false;
  if (!flag.enabled) return flag.defaultValue;

  switch (flag.type) {
    case 'boolean':
      return flag.enabled;

    case 'percentage': {
      if (!ctx.userId) return flag.defaultValue;
      const bucket = hashUserToPercentage(key, ctx.userId);
      return bucket < (flag.percentage ?? 0);
    }

    case 'segment':
      return evaluateSegment(flag, ctx);

    case 'schedule':
      return evaluateSchedule(flag);

    default:
      return flag.defaultValue;
  }
}

export async function isEnabled(key: string, ctx: FlagContext = {}): Promise<boolean> {
  const result = await evaluateFlag(key, ctx);
  return Boolean(result);
}

export function invalidateCache(key?: string): void {
  if (key) {
    flagCache.delete(key);
  } else {
    flagCache.clear();
  }
}
TYPESCRIPT
}

# =============================================================================
# フラグCRUD API生成
# =============================================================================
ff_generate_flag_api() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local api_dir="${project_dir}/src/app/api/admin/flags"

    # --- List & Create ---
    _ff_write_file "${api_dir}/route.ts" <<'TYPESCRIPT'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';
import { invalidateCache } from '@/lib/feature-flags';

const createFlagSchema = z.object({
  key: z.string().min(1).max(100).regex(/^[a-z0-9_.-]+$/, 'Key must be lowercase alphanumeric with dots/dashes/underscores'),
  type: z.enum(['boolean', 'percentage', 'segment', 'schedule']),
  enabled: z.boolean().default(false),
  percentage: z.number().min(0).max(100).optional(),
  segments: z.array(z.string()).optional(),
  scheduleStart: z.string().datetime().optional(),
  scheduleEnd: z.string().datetime().optional(),
  defaultValue: z.union([z.boolean(), z.string(), z.number()]).default(false),
  description: z.string().max(500).optional(),
});

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const page = Math.max(1, parseInt(searchParams.get('page') ?? '1'));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') ?? '20')));
    const search = searchParams.get('search') ?? '';

    const where = search ? { key: { contains: search } } : {};
    const [flags, total] = await Promise.all([
      prisma.featureFlag.findMany({
        where,
        orderBy: { updatedAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.featureFlag.count({ where }),
    ]);

    return NextResponse.json({ data: flags, total, page, limit });
  } catch (err) {
    console.error('[FeatureFlags API] GET error:', err);
    return NextResponse.json({ error: 'Failed to fetch flags' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = createFlagSchema.parse(body);

    const existing = await prisma.featureFlag.findUnique({ where: { key: parsed.key } });
    if (existing) {
      return NextResponse.json({ error: 'Flag key already exists' }, { status: 409 });
    }

    const flag = await prisma.featureFlag.create({
      data: {
        ...parsed,
        segments: parsed.segments ? JSON.stringify(parsed.segments) : null,
        scheduleStart: parsed.scheduleStart ? new Date(parsed.scheduleStart) : null,
        scheduleEnd: parsed.scheduleEnd ? new Date(parsed.scheduleEnd) : null,
      },
    });

    invalidateCache(parsed.key);
    return NextResponse.json({ data: flag }, { status: 201 });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: 'Validation error', details: err.errors }, { status: 400 });
    }
    console.error('[FeatureFlags API] POST error:', err);
    return NextResponse.json({ error: 'Failed to create flag' }, { status: 500 });
  }
}
TYPESCRIPT

    # --- Single flag operations ---
    _ff_write_file "${api_dir}/[key]/route.ts" <<'TYPESCRIPT'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';
import { invalidateCache } from '@/lib/feature-flags';

const updateFlagSchema = z.object({
  enabled: z.boolean().optional(),
  percentage: z.number().min(0).max(100).optional(),
  segments: z.array(z.string()).optional(),
  scheduleStart: z.string().datetime().optional().nullable(),
  scheduleEnd: z.string().datetime().optional().nullable(),
  defaultValue: z.union([z.boolean(), z.string(), z.number()]).optional(),
  description: z.string().max(500).optional(),
});

export async function GET(_req: NextRequest, { params }: { params: { key: string } }) {
  try {
    const flag = await prisma.featureFlag.findUnique({ where: { key: params.key } });
    if (!flag) return NextResponse.json({ error: 'Flag not found' }, { status: 404 });
    return NextResponse.json({ data: flag });
  } catch (err) {
    console.error('[FeatureFlags API] GET error:', err);
    return NextResponse.json({ error: 'Internal error' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest, { params }: { params: { key: string } }) {
  try {
    const body = await req.json();
    const parsed = updateFlagSchema.parse(body);

    const flag = await prisma.featureFlag.update({
      where: { key: params.key },
      data: {
        ...parsed,
        segments: parsed.segments ? JSON.stringify(parsed.segments) : undefined,
        scheduleStart: parsed.scheduleStart !== undefined
          ? (parsed.scheduleStart ? new Date(parsed.scheduleStart) : null)
          : undefined,
        scheduleEnd: parsed.scheduleEnd !== undefined
          ? (parsed.scheduleEnd ? new Date(parsed.scheduleEnd) : null)
          : undefined,
      },
    });

    invalidateCache(params.key);
    return NextResponse.json({ data: flag });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: 'Validation error', details: err.errors }, { status: 400 });
    }
    console.error('[FeatureFlags API] PATCH error:', err);
    return NextResponse.json({ error: 'Failed to update flag' }, { status: 500 });
  }
}

export async function DELETE(_req: NextRequest, { params }: { params: { key: string } }) {
  try {
    await prisma.featureFlag.delete({ where: { key: params.key } });
    invalidateCache(params.key);
    return NextResponse.json({ success: true });
  } catch (err) {
    console.error('[FeatureFlags API] DELETE error:', err);
    return NextResponse.json({ error: 'Failed to delete flag' }, { status: 500 });
  }
}
TYPESCRIPT
}

# =============================================================================
# フラグミドルウェア生成（Next.js middleware）
# =============================================================================
ff_generate_flag_middleware() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ff_write_file "${project_dir}/src/middleware/feature-flag-middleware.ts" <<'TYPESCRIPT'
import { NextRequest, NextResponse } from 'next/server';
import { evaluateFlag, FlagContext } from '@/lib/feature-flags';

export interface FlagGateConfig {
  flagKey: string;
  redirectTo?: string;
  statusCode?: number;
}

/**
 * Feature flag middleware factory.
 * Usage in Next.js middleware:
 *   return featureFlagGate(req, { flagKey: 'new-dashboard', redirectTo: '/old-dashboard' });
 */
export async function featureFlagGate(
  req: NextRequest,
  config: FlagGateConfig
): Promise<NextResponse | null> {
  const ctx: FlagContext = {
    userId: req.headers.get('x-user-id') ?? undefined,
    email: req.headers.get('x-user-email') ?? undefined,
    role: req.headers.get('x-user-role') ?? undefined,
  };

  const enabled = await evaluateFlag(config.flagKey, ctx);

  if (!enabled) {
    if (config.redirectTo) {
      return NextResponse.redirect(new URL(config.redirectTo, req.url));
    }
    return NextResponse.json(
      { error: 'Feature not available' },
      { status: config.statusCode ?? 403 }
    );
  }

  return null; // Continue to next middleware / route
}

/**
 * Multi-flag gate: all flags must be enabled.
 */
export async function multiFeatureFlagGate(
  req: NextRequest,
  configs: FlagGateConfig[]
): Promise<NextResponse | null> {
  for (const config of configs) {
    const result = await featureFlagGate(req, config);
    if (result) return result;
  }
  return null;
}
TYPESCRIPT
}

# =============================================================================
# React Hooks生成（useFeatureFlag, FeatureGate, withFeatureFlag HOC）
# =============================================================================
ff_generate_react_hooks() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local hooks_dir="${project_dir}/src/hooks"
    local comp_dir="${project_dir}/src/components"

    # --- useFeatureFlag hook ---
    _ff_write_file "${hooks_dir}/useFeatureFlag.ts" <<'TYPESCRIPT'
'use client';
import useSWR from 'swr';

interface FlagEvalResult {
  enabled: boolean;
  loading: boolean;
  error: Error | undefined;
}

const fetcher = async (url: string): Promise<{ enabled: boolean }> => {
  const res = await fetch(url);
  if (!res.ok) throw new Error(`Flag evaluation failed: ${res.status}`);
  return res.json();
};

/**
 * React hook for feature flag evaluation.
 * Calls server-side evaluation endpoint and caches result.
 *
 * Usage:
 *   const { enabled, loading } = useFeatureFlag('new-sidebar');
 */
export function useFeatureFlag(flagKey: string): FlagEvalResult {
  const { data, error, isLoading } = useSWR(
    `/api/flags/evaluate?key=${encodeURIComponent(flagKey)}`,
    fetcher,
    { revalidateOnFocus: false, dedupingInterval: 30_000 }
  );

  return {
    enabled: data?.enabled ?? false,
    loading: isLoading,
    error,
  };
}

/**
 * Check multiple flags at once.
 */
export function useFeatureFlags(flagKeys: string[]): Record<string, FlagEvalResult> {
  const results: Record<string, FlagEvalResult> = {};
  for (const key of flagKeys) {
    // eslint-disable-next-line react-hooks/rules-of-hooks
    results[key] = useFeatureFlag(key);
  }
  return results;
}
TYPESCRIPT

    # --- FeatureGate component ---
    _ff_write_file "${comp_dir}/FeatureGate.tsx" <<'TYPESCRIPT'
'use client';
import { ReactNode } from 'react';
import { useFeatureFlag } from '@/hooks/useFeatureFlag';

interface FeatureGateProps {
  flag: string;
  children: ReactNode;
  fallback?: ReactNode;
  loadingFallback?: ReactNode;
}

/**
 * Declarative feature gate component.
 *
 * Usage:
 *   <FeatureGate flag="new-sidebar" fallback={<OldSidebar />}>
 *     <NewSidebar />
 *   </FeatureGate>
 */
export function FeatureGate({ flag, children, fallback = null, loadingFallback }: FeatureGateProps) {
  const { enabled, loading } = useFeatureFlag(flag);

  if (loading) {
    return <>{loadingFallback ?? fallback}</>;
  }

  return <>{enabled ? children : fallback}</>;
}
TYPESCRIPT

    # --- withFeatureFlag HOC ---
    _ff_write_file "${comp_dir}/withFeatureFlag.tsx" <<'TYPESCRIPT'
'use client';
import { ComponentType } from 'react';
import { useFeatureFlag } from '@/hooks/useFeatureFlag';

interface WithFeatureFlagOptions {
  flagKey: string;
  FallbackComponent?: ComponentType;
  LoadingComponent?: ComponentType;
}

/**
 * Higher-order component for feature gating.
 *
 * Usage:
 *   export default withFeatureFlag({ flagKey: 'new-profile' })(NewProfilePage);
 */
export function withFeatureFlag<P extends object>(options: WithFeatureFlagOptions) {
  return function wrapper(WrappedComponent: ComponentType<P>) {
    function FeatureFlagWrapper(props: P) {
      const { enabled, loading } = useFeatureFlag(options.flagKey);

      if (loading) {
        return options.LoadingComponent ? <options.LoadingComponent /> : null;
      }
      if (!enabled) {
        return options.FallbackComponent ? <options.FallbackComponent /> : null;
      }

      return <WrappedComponent {...props} />;
    }

    FeatureFlagWrapper.displayName = `withFeatureFlag(${WrappedComponent.displayName || WrappedComponent.name || 'Component'})`;
    return FeatureFlagWrapper;
  };
}
TYPESCRIPT

    # --- Flag evaluation API endpoint ---
    _ff_write_file "${project_dir}/src/app/api/flags/evaluate/route.ts" <<'TYPESCRIPT'
import { NextRequest, NextResponse } from 'next/server';
import { isEnabled } from '@/lib/feature-flags';

export async function GET(req: NextRequest) {
  const key = new URL(req.url).searchParams.get('key');
  if (!key) {
    return NextResponse.json({ error: 'Missing flag key' }, { status: 400 });
  }

  try {
    const ctx = {
      userId: req.headers.get('x-user-id') ?? undefined,
      email: req.headers.get('x-user-email') ?? undefined,
      role: req.headers.get('x-user-role') ?? undefined,
    };

    const enabled = await isEnabled(key, ctx);
    return NextResponse.json({ enabled });
  } catch (err) {
    console.error(`[Flag Evaluate] Error for key "${key}":`, err);
    return NextResponse.json({ enabled: false });
  }
}
TYPESCRIPT
}

# =============================================================================
# ロールアウト戦略生成
# =============================================================================
ff_generate_rollout_strategy() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ff_write_file "${project_dir}/src/lib/rollout-strategy.ts" <<'TYPESCRIPT'
import { prisma } from './prisma';
import { invalidateCache } from './feature-flags';

export interface RolloutPlan {
  flagKey: string;
  stages: RolloutStage[];
  currentStage: number;
}

export interface RolloutStage {
  name: string;
  percentage: number;
  duration: number; // minutes
  segments?: string[];
}

/**
 * Predefined rollout strategies.
 */
export const STRATEGIES = {
  canary: (flagKey: string): RolloutPlan => ({
    flagKey,
    stages: [
      { name: 'canary', percentage: 1, duration: 60 },
      { name: 'early-adopters', percentage: 10, duration: 240 },
      { name: 'half', percentage: 50, duration: 1440 },
      { name: 'full', percentage: 100, duration: 0 },
    ],
    currentStage: 0,
  }),
  internal: (flagKey: string): RolloutPlan => ({
    flagKey,
    stages: [
      { name: 'internal', percentage: 100, duration: 1440, segments: ['role:admin'] },
      { name: 'beta-users', percentage: 100, duration: 1440, segments: ['role:admin', 'role:beta'] },
      { name: 'full', percentage: 100, duration: 0 },
    ],
    currentStage: 0,
  }),
  abTest: (flagKey: string, percentage: number = 50): RolloutPlan => ({
    flagKey,
    stages: [
      { name: 'ab-test', percentage, duration: 10080 }, // 7 days
      { name: 'decision', percentage: 0, duration: 0 },
    ],
    currentStage: 0,
  }),
} as const;

/**
 * Advance a rollout plan to its next stage.
 */
export async function advanceRollout(plan: RolloutPlan): Promise<RolloutPlan> {
  if (plan.currentStage >= plan.stages.length - 1) {
    return plan;
  }

  plan.currentStage += 1;
  const stage = plan.stages[plan.currentStage];

  await prisma.featureFlag.update({
    where: { key: plan.flagKey },
    data: {
      percentage: stage.percentage,
      segments: stage.segments ? JSON.stringify(stage.segments) : null,
      enabled: true,
    },
  });

  invalidateCache(plan.flagKey);
  return plan;
}

/**
 * Rollback to the previous stage or disable entirely.
 */
export async function rollbackFlag(flagKey: string): Promise<void> {
  await prisma.featureFlag.update({
    where: { key: flagKey },
    data: { enabled: false, percentage: 0 },
  });
  invalidateCache(flagKey);
}
TYPESCRIPT
}

# =============================================================================
# フラグ管理ダッシュボード生成
# =============================================================================
ff_generate_flag_dashboard() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ff_write_file "${project_dir}/src/app/admin/flags/page.tsx" <<'TYPESCRIPT'
'use client';
import { useState } from 'react';
import useSWR from 'swr';

interface Flag {
  id: string;
  key: string;
  type: string;
  enabled: boolean;
  percentage: number | null;
  description: string | null;
  updatedAt: string;
}

const fetcher = (url: string) => fetch(url).then(r => r.json());

export default function FeatureFlagDashboard() {
  const [search, setSearch] = useState('');
  const { data, error, isLoading, mutate } = useSWR<{ data: Flag[]; total: number }>(
    `/api/admin/flags?search=${encodeURIComponent(search)}`,
    fetcher
  );
  const [toggling, setToggling] = useState<string | null>(null);

  const handleToggle = async (flag: Flag) => {
    setToggling(flag.key);
    try {
      const res = await fetch(`/api/admin/flags/${flag.key}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ enabled: !flag.enabled }),
      });
      if (!res.ok) throw new Error('Toggle failed');
      mutate();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Failed to toggle flag');
    } finally {
      setToggling(null);
    }
  };

  const handleDelete = async (flag: Flag) => {
    if (!confirm(`Delete flag "${flag.key}"? This cannot be undone.`)) return;
    try {
      const res = await fetch(`/api/admin/flags/${flag.key}`, { method: 'DELETE' });
      if (!res.ok) throw new Error('Delete failed');
      mutate();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Failed to delete flag');
    }
  };

  if (isLoading) {
    return (
      <div className="p-6 space-y-4">
        <h1 className="text-2xl font-bold">Feature Flags</h1>
        {[...Array(5)].map((_, i) => (
          <div key={i} className="h-16 bg-gray-200 rounded animate-pulse" />
        ))}
      </div>
    );
  }

  if (error) {
    return (
      <div className="p-6 text-center">
        <p className="text-red-600 mb-4">Failed to load flags: {error.message}</p>
        <button onClick={() => mutate()} className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">Retry</button>
      </div>
    );
  }

  const flags = data?.data ?? [];

  return (
    <div className="p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Feature Flags ({data?.total ?? 0})</h1>
        <a href="/admin/flags/new" className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700">New Flag</a>
      </div>

      <input
        type="text"
        placeholder="Search flags..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="w-full border rounded px-3 py-2 mb-4"
      />

      {flags.length === 0 ? (
        <p className="text-center text-gray-500 py-8">No feature flags found.</p>
      ) : (
        <table className="w-full border-collapse">
          <thead>
            <tr className="border-b bg-gray-50">
              <th className="text-left p-3">Key</th>
              <th className="text-left p-3">Type</th>
              <th className="text-left p-3">Status</th>
              <th className="text-left p-3">Rollout</th>
              <th className="text-left p-3">Updated</th>
              <th className="text-right p-3">Actions</th>
            </tr>
          </thead>
          <tbody>
            {flags.map((flag) => (
              <tr key={flag.key} className="border-b hover:bg-gray-50">
                <td className="p-3 font-mono text-sm">{flag.key}</td>
                <td className="p-3">
                  <span className="px-2 py-1 text-xs rounded bg-gray-100">{flag.type}</span>
                </td>
                <td className="p-3">
                  <button
                    onClick={() => handleToggle(flag)}
                    disabled={toggling === flag.key}
                    className={`px-3 py-1 rounded text-sm font-medium ${
                      flag.enabled ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-600'
                    }`}
                  >
                    {toggling === flag.key ? '...' : flag.enabled ? 'ON' : 'OFF'}
                  </button>
                </td>
                <td className="p-3">{flag.percentage != null ? `${flag.percentage}%` : '-'}</td>
                <td className="p-3 text-sm text-gray-500">{new Date(flag.updatedAt).toLocaleDateString()}</td>
                <td className="p-3 text-right">
                  <button onClick={() => handleDelete(flag)} className="text-red-600 hover:text-red-800 text-sm">Delete</button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
TYPESCRIPT
}

# =============================================================================
# Claudeプロンプト注入
# =============================================================================
ff_inject_flag_patterns() {
    local prompt="${1:-}"

    cat <<'INJECTION'

## [Feature Flag Patterns] フィーチャーフラグ実装ルール

### 必須パターン:
1. **フラグ評価**: `isEnabled('flag-key', ctx)` で判定（直接DB参照禁止）
2. **React側**: `useFeatureFlag('flag-key')` フックまたは `<FeatureGate flag="...">` を使用
3. **API側**: `featureFlagGate(req, { flagKey: '...' })` ミドルウェアを使用
4. **キャッシュ**: フラグ変更時は必ず `invalidateCache(key)` を呼ぶ
5. **型**: FlagType = 'boolean' | 'percentage' | 'segment' | 'schedule'
6. **フラグキー命名**: kebab-case のみ（例: `new-dashboard`, `beta-export`）

### ロールアウト:
- `STRATEGIES.canary(key)` → 1% → 10% → 50% → 100% の段階的展開
- `STRATEGIES.internal(key)` → 社内 → ベータ → 全体
- `STRATEGIES.abTest(key, 50)` → A/Bテスト（50%分割）

### Prisma FeatureFlag モデル:
```prisma
model FeatureFlag {
  id            String    @id @default(cuid())
  key           String    @unique
  type          String    @default("boolean")
  enabled       Boolean   @default(false)
  percentage    Int?
  segments      String?
  scheduleStart DateTime?
  scheduleEnd   DateTime?
  defaultValue  String    @default("false")
  description   String?
  createdAt     DateTime  @default(now())
  updatedAt     DateTime  @updatedAt
}
```
INJECTION

    echo "$prompt"
}

# =============================================================================
# 全生成実行
# =============================================================================
ffe_generate_flags() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    echo "[feature-flag-engine] Generating feature flag infrastructure..."
    ff_generate_flag_service "$project_dir"
    ff_generate_flag_api "$project_dir"
    ff_generate_flag_middleware "$project_dir"
    ff_generate_react_hooks "$project_dir"
    ff_generate_rollout_strategy "$project_dir"
    ff_generate_flag_dashboard "$project_dir"
    echo "[feature-flag-engine] Generated ${FFE_GENERATED} files (${FFE_ERRORS} errors)"
}

# =============================================================================
# レポート & スコア
# =============================================================================
ffe_report() {
    echo -e "\n  ${BOLD:-}=== feature-flag-engine v${FF_VERSION} ===${NC:-}"
    echo -e "  生成ファイル数: ${FFE_GENERATED}"
    echo -e "  エラー: ${FFE_ERRORS}"
    if [[ ${FFE_GENERATED} -gt 0 ]]; then
        echo -e "  生成内容: flag-service, CRUD API, middleware, React hooks, rollout-strategy, dashboard"
    fi
}

ffe_score() {
    if [[ ${FFE_GENERATED} -ge 6 ]] && [[ ${FFE_ERRORS} -eq 0 ]]; then
        echo "95"
    elif [[ ${FFE_GENERATED} -gt 0 ]] && [[ ${FFE_ERRORS} -eq 0 ]]; then
        echo "90"
    elif [[ ${FFE_GENERATED} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "feature-flag-engine" --version "140.0" \
        --description "フィーチャーフラグ基盤×段階的ロールアウト×A/Bテスト" \
        --init "ff_init" --report "ffe_report" --score "ffe_score" \
        --enable-var "ENABLE_FEATURE_FLAGS" --cli-flags "--feature-flag:--no-feature-flag"
fi

# v2003.1: source時のexit codeを確実に0にする
true
