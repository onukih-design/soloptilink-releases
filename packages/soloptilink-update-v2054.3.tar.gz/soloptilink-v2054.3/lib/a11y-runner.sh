#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v106.0 - Accessibility Runner
# 生成フロントエンドのアクセシビリティ検査
#
# 問題: 生成されたUIにaltテキスト欠落、aria-label不足、
# フォームラベル欠如、見出し階層の乱れが頻発。
# これらはLighthouseでは見つかるがビルド時には検出できない。
#
# 解決: axe-core CLI が使えればフルスキャン、なければ
# 静的解析(grep/awk)でWCAG 2.1レベルA/AAの主要違反を検出。
# WCAG参照付き修正プロンプトを生成。
# ============================================================

[[ -n "${_A11Y_RUNNER_LOADED:-}" ]] && return 0
_A11Y_RUNNER_LOADED=1

A11Y_R_VERSION="106.0"
A11Y_R_INITIALIZED=false
A11Y_R_HAS_AXE=false

# Violation counts by impact
A11Y_R_CRITICAL=0
A11Y_R_SERIOUS=0
A11Y_R_MODERATE=0
A11Y_R_MINOR=0
A11Y_R_VIOLATIONS_DETAIL=""
A11Y_R_FILES_SCANNED=0

# ============================================================
# Init
# ============================================================
a11y_init() {
    A11Y_R_CRITICAL=0
    A11Y_R_SERIOUS=0
    A11Y_R_MODERATE=0
    A11Y_R_MINOR=0
    A11Y_R_VIOLATIONS_DETAIL=""
    A11Y_R_FILES_SCANNED=0

    # Check for axe-core CLI
    if command -v npx &>/dev/null; then
        if npx --no-install @axe-core/cli --version &>/dev/null 2>&1; then
            A11Y_R_HAS_AXE=true
        fi
    fi

    A11Y_R_INITIALIZED=true
    return 0
}

# ============================================================
# Main: Run a11y checks
# ============================================================
a11y_run() {
    local project_dir="$1"
    local base_url="${2:-}"
    [[ ! -d "$project_dir" ]] && return 1
    [[ "$A11Y_R_INITIALIZED" != "true" ]] && a11y_init

    # If axe-core is available and a base_url is given, run dynamic analysis
    if [[ "$A11Y_R_HAS_AXE" == "true" ]] && [[ -n "$base_url" ]]; then
        _a11y_run_axe "$base_url" "$project_dir"
    fi

    # Always run static analysis (catches issues even without running server)
    a11y_static_check "$project_dir"

    return 0
}

# ============================================================
# Dynamic analysis via axe-core
# ============================================================
_a11y_run_axe() {
    local base_url="$1"
    local project_dir="$2"

    # Discover page routes from app/ directory
    local -a pages=()
    pages+=("$base_url")

    # Find page.tsx files to determine routes
    while IFS= read -r page_file; do
        local rel="${page_file#$project_dir/app}"
        rel="${rel%/page.tsx}"
        rel="${rel%/page.jsx}"
        rel="${rel%/page.ts}"
        rel="${rel%/page.js}"
        # Skip dynamic routes, API routes, and layout
        [[ "$rel" == *"["* ]] && continue
        [[ "$rel" == *"api"* ]] && continue
        [[ -z "$rel" ]] && continue
        pages+=("${base_url}${rel}")
    done < <(find "$project_dir/app" -name "page.tsx" -o -name "page.jsx" 2>/dev/null | grep -v node_modules | head -20)

    for page_url in "${pages[@]}"; do
        local axe_output
        axe_output=$(timeout 30 npx --no-install @axe-core/cli "$page_url" --stdout 2>/dev/null || true)

        if [[ -n "$axe_output" ]]; then
            # Parse violation counts from axe output
            local violations
            violations=$(echo "$axe_output" | grep -c "violation" 2>/dev/null || echo "0")
            local critical
            critical=$(echo "$axe_output" | grep -c "critical" 2>/dev/null || echo "0")
            local serious
            serious=$(echo "$axe_output" | grep -c "serious" 2>/dev/null || echo "0")

            A11Y_R_CRITICAL=$((A11Y_R_CRITICAL + ${critical:-0}))
            A11Y_R_SERIOUS=$((A11Y_R_SERIOUS + ${serious:-0}))

            if [[ ${violations:-0} -gt 0 ]]; then
                A11Y_R_VIOLATIONS_DETAIL+="  [AXE] ${page_url}: ${violations} violation(s)\n"
            fi
        fi
    done
}

# ============================================================
# Static analysis: grep-based WCAG checks
# ============================================================
a11y_static_check() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1

    local files_scanned=0
    local -a ui_files=()

    # Collect .tsx, .jsx, .html files (UI components)
    while IFS= read -r f; do
        ui_files+=("$f")
    done < <(find "$project_dir" \
        -type f \( -name "*.tsx" -o -name "*.jsx" -o -name "*.html" \) \
        ! -path "*/node_modules/*" \
        ! -path "*/.next/*" \
        ! -path "*/.git/*" \
        ! -path "*/dist/*" \
        2>/dev/null | head -300)

    files_scanned=${#ui_files[@]}
    A11Y_R_FILES_SCANNED=$files_scanned

    [[ $files_scanned -eq 0 ]] && return 0

    # --- Check 1: Images without alt attribute ---
    local img_no_alt=0
    for f in "${ui_files[@]}"; do
        # Find <img or <Image tags without alt=
        local count
        count=$(grep -cE '<(img|Image)\b' "$f" 2>/dev/null || echo "0")
        if [[ ${count:-0} -gt 0 ]]; then
            local with_alt
            with_alt=$(grep -cE '<(img|Image)\b[^>]*alt=' "$f" 2>/dev/null || echo "0")
            local missing=$((${count:-0} - ${with_alt:-0}))
            if [[ $missing -gt 0 ]]; then
                img_no_alt=$((img_no_alt + missing))
                local rel="${f#$project_dir/}"
                A11Y_R_VIOLATIONS_DETAIL+="  [IMG_ALT] ${rel}: ${missing} image(s) without alt attribute (WCAG 1.1.1)\n"
            fi
        fi
    done
    if [[ $img_no_alt -gt 0 ]]; then
        A11Y_R_SERIOUS=$((A11Y_R_SERIOUS + img_no_alt))
    fi

    # --- Check 2: Input fields without associated labels ---
    local input_no_label=0
    for f in "${ui_files[@]}"; do
        # Find <input that lack aria-label, aria-labelledby, id+label, or placeholder-as-label
        local inputs
        inputs=$(grep -cE '<input\b' "$f" 2>/dev/null || echo "0")
        if [[ ${inputs:-0} -gt 0 ]]; then
            local labeled
            labeled=$(grep -cE '<input\b[^>]*(aria-label|aria-labelledby|id=)' "$f" 2>/dev/null || echo "0")
            local missing=$((${inputs:-0} - ${labeled:-0}))
            if [[ $missing -gt 0 ]]; then
                # Check if there are <label> elements nearby (crude but effective)
                local labels_in_file
                labels_in_file=$(grep -cE '<label\b' "$f" 2>/dev/null || echo "0")
                # If labels exist, reduce missing count by label count
                missing=$((missing - ${labels_in_file:-0}))
                if [[ $missing -gt 0 ]]; then
                    input_no_label=$((input_no_label + missing))
                    local rel="${f#$project_dir/}"
                    A11Y_R_VIOLATIONS_DETAIL+="  [INPUT_LABEL] ${rel}: ${missing} input(s) without label (WCAG 1.3.1)\n"
                fi
            fi
        fi
    done
    if [[ $input_no_label -gt 0 ]]; then
        A11Y_R_SERIOUS=$((A11Y_R_SERIOUS + input_no_label))
    fi

    # --- Check 3: Buttons without accessible text ---
    local btn_no_text=0
    for f in "${ui_files[@]}"; do
        # Find buttons without aria-label and with potential empty content (icon-only buttons)
        local icon_btns
        icon_btns=$(grep -cE '<button[^>]*>\s*<(svg|img|Icon|span class)' "$f" 2>/dev/null || echo "0")
        if [[ ${icon_btns:-0} -gt 0 ]]; then
            local with_aria
            with_aria=$(grep -cE '<button[^>]*(aria-label|title=)' "$f" 2>/dev/null || echo "0")
            local missing=$((${icon_btns:-0} - ${with_aria:-0}))
            if [[ $missing -gt 0 ]]; then
                btn_no_text=$((btn_no_text + missing))
                local rel="${f#$project_dir/}"
                A11Y_R_VIOLATIONS_DETAIL+="  [BTN_LABEL] ${rel}: ${missing} button(s) without accessible name (WCAG 4.1.2)\n"
            fi
        fi
    done
    if [[ $btn_no_text -gt 0 ]]; then
        A11Y_R_MODERATE=$((A11Y_R_MODERATE + btn_no_text))
    fi

    # --- Check 4: Heading hierarchy ---
    for f in "${ui_files[@]}"; do
        local has_headings=false
        local prev_level=0

        # Extract heading levels in order
        local heading_levels
        heading_levels=$(grep -oE '<[hH][1-6]\b' "$f" 2>/dev/null | grep -oE '[1-6]' || true)
        [[ -z "$heading_levels" ]] && continue

        has_headings=true
        local first_heading=true

        while IFS= read -r level; do
            [[ -z "$level" ]] && continue
            if [[ "$first_heading" == "true" ]]; then
                # First heading should ideally be h1
                if [[ $level -gt 2 ]]; then
                    A11Y_R_MINOR=$((A11Y_R_MINOR + 1))
                    local rel="${f#$project_dir/}"
                    A11Y_R_VIOLATIONS_DETAIL+="  [HEADING] ${rel}: first heading is h${level}, should start with h1 or h2 (WCAG 1.3.1)\n"
                fi
                first_heading=false
                prev_level=$level
                continue
            fi

            # Check for skipped levels (e.g., h1 -> h3)
            if [[ $level -gt $((prev_level + 1)) ]] && [[ $level -gt $prev_level ]]; then
                A11Y_R_MODERATE=$((A11Y_R_MODERATE + 1))
                local rel="${f#$project_dir/}"
                A11Y_R_VIOLATIONS_DETAIL+="  [HEADING] ${rel}: heading skip h${prev_level} -> h${level} (WCAG 1.3.1)\n"
            fi
            prev_level=$level
        done <<< "$heading_levels"
    done

    # --- Check 5: Color contrast patterns (basic) ---
    for f in "${ui_files[@]}"; do
        # Check for light-on-light or dark-on-dark text patterns
        # Look for text-gray-300/400 on white bg or text-gray-600/700 on dark bg
        if grep -qE 'text-gray-[34]00.*bg-white|bg-white.*text-gray-[34]00' "$f" 2>/dev/null; then
            A11Y_R_SERIOUS=$((A11Y_R_SERIOUS + 1))
            local rel="${f#$project_dir/}"
            A11Y_R_VIOLATIONS_DETAIL+="  [CONTRAST] ${rel}: potential low contrast text (WCAG 1.4.3)\n"
        fi
        # Inline style low contrast check
        if grep -qE 'color:\s*#[cdefCDEF]{3}|color:\s*#[cdefCDEF]{6}' "$f" 2>/dev/null; then
            A11Y_R_SERIOUS=$((A11Y_R_SERIOUS + 1))
            local rel="${f#$project_dir/}"
            A11Y_R_VIOLATIONS_DETAIL+="  [CONTRAST] ${rel}: very light text color in inline styles (WCAG 1.4.3)\n"
        fi
    done

    # --- Check 6: Form elements ---
    for f in "${ui_files[@]}"; do
        # Select without label
        local selects
        selects=$(grep -cE '<select\b' "$f" 2>/dev/null || echo "0")
        if [[ ${selects:-0} -gt 0 ]]; then
            local sel_labeled
            sel_labeled=$(grep -cE '<select\b[^>]*(aria-label|id=)' "$f" 2>/dev/null || echo "0")
            local sel_missing=$((${selects:-0} - ${sel_labeled:-0}))
            if [[ $sel_missing -gt 0 ]]; then
                A11Y_R_MODERATE=$((A11Y_R_MODERATE + sel_missing))
                local rel="${f#$project_dir/}"
                A11Y_R_VIOLATIONS_DETAIL+="  [FORM] ${rel}: ${sel_missing} select(s) without label (WCAG 1.3.1)\n"
            fi
        fi

        # Textarea without label
        local textareas
        textareas=$(grep -cE '<textarea\b' "$f" 2>/dev/null || echo "0")
        if [[ ${textareas:-0} -gt 0 ]]; then
            local ta_labeled
            ta_labeled=$(grep -cE '<textarea\b[^>]*(aria-label|id=)' "$f" 2>/dev/null || echo "0")
            local ta_missing=$((${textareas:-0} - ${ta_labeled:-0}))
            if [[ $ta_missing -gt 0 ]]; then
                A11Y_R_MODERATE=$((A11Y_R_MODERATE + ta_missing))
                local rel="${f#$project_dir/}"
                A11Y_R_VIOLATIONS_DETAIL+="  [FORM] ${rel}: ${ta_missing} textarea(s) without label (WCAG 1.3.1)\n"
            fi
        fi
    done

    return 0
}

# ============================================================
# Generate WCAG fix prompt
# ============================================================
a11y_generate_fix_prompt() {
    local report="${1:-$A11Y_R_VIOLATIONS_DETAIL}"
    local prompt="Fix the following accessibility violations per WCAG 2.1 Level AA.\n\n"

    if echo "$report" | grep -q "IMG_ALT" 2>/dev/null; then
        prompt+="## Images Missing Alt Text (WCAG 1.1.1 Non-text Content)\n"
        prompt+="Add descriptive alt attributes to all <img> and <Image> tags.\n"
        prompt+="- Decorative images: use alt=\"\" (empty string, not omitted)\n"
        prompt+="- Functional images (icons in buttons): describe the action\n"
        prompt+="- Informative images: describe the content/meaning\n\n"
    fi

    if echo "$report" | grep -q "INPUT_LABEL" 2>/dev/null; then
        prompt+="## Form Inputs Missing Labels (WCAG 1.3.1 Info and Relationships)\n"
        prompt+="Every input must have an associated label:\n"
        prompt+="- Visible: <label htmlFor=\"id\">Label</label> + <input id=\"id\" />\n"
        prompt+="- Hidden: <input aria-label=\"Description\" />\n"
        prompt+="- Group: <fieldset><legend>Group</legend>...</fieldset>\n\n"
    fi

    if echo "$report" | grep -q "BTN_LABEL" 2>/dev/null; then
        prompt+="## Buttons Without Accessible Names (WCAG 4.1.2 Name, Role, Value)\n"
        prompt+="Icon-only buttons need aria-label:\n"
        prompt+="<button aria-label=\"Close dialog\"><XIcon /></button>\n\n"
    fi

    if echo "$report" | grep -q "HEADING" 2>/dev/null; then
        prompt+="## Heading Hierarchy Issues (WCAG 1.3.1)\n"
        prompt+="- Start with h1, then h2, h3 in sequence\n"
        prompt+="- Never skip levels (h1 -> h3 is invalid)\n"
        prompt+="- Each page should have exactly one h1\n\n"
    fi

    if echo "$report" | grep -q "CONTRAST" 2>/dev/null; then
        prompt+="## Color Contrast Issues (WCAG 1.4.3 Contrast Minimum)\n"
        prompt+="- Normal text: minimum 4.5:1 contrast ratio\n"
        prompt+="- Large text (18px+ or 14px+ bold): minimum 3:1\n"
        prompt+="- Use darker text colors: text-gray-700 or darker on white bg\n\n"
    fi

    if echo "$report" | grep -q "FORM" 2>/dev/null; then
        prompt+="## Form Elements Missing Labels (WCAG 1.3.1)\n"
        prompt+="All select, textarea elements need associated labels.\n\n"
    fi

    echo -e "$prompt"
}

# ============================================================
# Score: 100 minus impact-weighted violations
# ============================================================
a11y_score() {
    local deduction=0
    deduction=$((A11Y_R_CRITICAL * 15 + A11Y_R_SERIOUS * 8 + A11Y_R_MODERATE * 4 + A11Y_R_MINOR * 1))

    local score=$((100 - deduction))
    if [[ $score -lt 0 ]]; then
        score=0
    fi
    echo "$score"
}

# ============================================================
# Report
# ============================================================
a11y_report() {
    echo -e "\n  ${BOLD:-}=== Accessibility Runner v${A11Y_R_VERSION} ===${NC:-}"
    echo -e "  Files scanned: ${A11Y_R_FILES_SCANNED}"
    echo -e "  Critical: ${A11Y_R_CRITICAL} | Serious: ${A11Y_R_SERIOUS} | Moderate: ${A11Y_R_MODERATE} | Minor: ${A11Y_R_MINOR}"
    if [[ -n "$A11Y_R_VIOLATIONS_DETAIL" ]]; then
        echo -e "$A11Y_R_VIOLATIONS_DETAIL" | head -15
    fi
    echo -e "  Score: $(a11y_score)/100"
}

# ============================================================
# Module Registry self-registration
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "a11y-runner" \
        --version "$A11Y_R_VERSION" \
        --description "アクセシビリティ検査 - WCAG 2.1静的解析+axe-core" \
        --init "a11y_init" \
        --report "a11y_report" \
        --score "a11y_score" \
        --enable-var "ENABLE_A11Y" \
        --cli-flags "--a11y-runner:--no-a11y-runner"
fi

# v2003.1: source時のexit codeを確実に0にする
true
