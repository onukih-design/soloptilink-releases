#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v399.0 - Code Explanation Engine
# =============================================================================
# コード解説エンジン。関数/モジュール/コメント生成を自動化。
# All globals use the CEE2_ prefix.
# =============================================================================

[[ -n "${_CODE_EXPLANATION_ENGINE_LOADED:-}" ]] && return 0
_CODE_EXPLANATION_ENGINE_LOADED=1

declare -g CEE2_VERSION="399.0"
declare -g CEE2_INITIALIZED=false
declare -g CEE2_GENERATED_COUNT=0
declare -g CEE2_FUNCTION_EXPLAINED=false
declare -g CEE2_MODULE_EXPLAINED=false
declare -g CEE2_COMMENTS_GENERATED=false
declare -g CEE2_JSDOC_GENERATED=false
declare -g ENABLE_CEE2="${ENABLE_CEE2:-true}"

_cee2_init() { CEE2_INITIALIZED=true; CEE2_GENERATED_COUNT=0; return 0; }

_cee2_generate_all() {
    local project_dir="${1:-.}"
    [[ "$CEE2_INITIALIZED" != "true" ]] && _cee2_init
    echo -e "  ${CYAN:-\033[0;36m}[CEE2]${NC:-\033[0m} コード解説エンジン生成開始..." >&2
    _cee2_explain_function "$project_dir"
    _cee2_explain_module "$project_dir"
    _cee2_generate_comments "$project_dir"
    _cee2_generate_jsdoc "$project_dir"
    echo -e "  ${GREEN:-\033[0;32m}[CEE2]${NC:-\033[0m} コード解説エンジン生成完了: ${CEE2_GENERATED_COUNT}件" >&2
    return 0
}

_cee2_explain_function() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [CEE2-FUNC] 関数解説テンプレート

### Function Analyzer
```typescript
interface FunctionInfo {
  name: string;
  params: { name: string; type: string; description?: string }[];
  returnType: string;
  complexity: number;
  dependencies: string[];
  sideEffects: string[];
  body: string;
}

export function analyzeFunctionForExplanation(code: string, functionName: string): FunctionInfo {
  const funcMatch = code.match(new RegExp(`(?:export\\s+)?(?:async\\s+)?function\\s+${functionName}\\s*\\(([^)]*)\\)(?:\\s*:\\s*([^{]+))?\\s*\\{`, 's'));
  if (!funcMatch) throw new Error(`Function ${functionName} not found`);

  const params = parseParams(funcMatch[1]);
  const returnType = funcMatch[2]?.trim() ?? 'void';
  const body = extractFunctionBody(code, funcMatch.index!);

  return {
    name: functionName, params, returnType,
    complexity: calculateComplexity(body),
    dependencies: extractImports(body),
    sideEffects: detectSideEffects(body),
    body,
  };
}

export function generateExplanation(info: FunctionInfo): string {
  let explanation = `### \`${info.name}\`\n\n`;
  explanation += `**概要**: `;

  if (info.sideEffects.includes('database')) explanation += 'データベース操作を行う関数。';
  if (info.sideEffects.includes('api_call')) explanation += '外部API呼び出しを行う関数。';
  if (info.sideEffects.includes('file_io')) explanation += 'ファイル入出力を行う関数。';

  explanation += `\n\n**パラメータ**:\n`;
  for (const p of info.params) {
    explanation += `- \`${p.name}: ${p.type}\` - ${p.description ?? '説明未設定'}\n`;
  }

  explanation += `\n**戻り値**: \`${info.returnType}\`\n`;
  explanation += `\n**複雑度**: ${info.complexity} (${info.complexity <= 5 ? '低' : info.complexity <= 10 ? '中' : '高'})\n`;

  if (info.dependencies.length > 0) {
    explanation += `\n**依存関係**: ${info.dependencies.join(', ')}\n`;
  }

  return explanation;
}

function detectSideEffects(body: string): string[] {
  const effects: string[] = [];
  if (/prisma\.|\.create\(|\.update\(|\.delete\(/i.test(body)) effects.push('database');
  if (/fetch\(|axios\.|\.get\(|\.post\(/i.test(body)) effects.push('api_call');
  if (/writeFile|readFile|fs\./i.test(body)) effects.push('file_io');
  if (/console\.(log|error|warn)/i.test(body)) effects.push('console');
  return effects;
}
```
TEMPLATE
    CEE2_FUNCTION_EXPLAINED=true
    CEE2_GENERATED_COUNT=$((CEE2_GENERATED_COUNT + 1))
    return 0
}

_cee2_explain_module() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [CEE2-MODULE] モジュール解説テンプレート

```typescript
export async function explainModule(filePath: string): Promise<ModuleExplanation> {
  const content = await readFile(filePath, 'utf-8');
  const imports = extractAllImports(content);
  const exports = extractAllExports(content);
  const functions = extractAllFunctions(content);
  const interfaces = extractAllInterfaces(content);

  return {
    filePath,
    purpose: inferModulePurpose(filePath, exports),
    imports: imports.map(i => ({ from: i.source, items: i.specifiers })),
    exports: exports.map(e => ({ name: e.name, type: e.type })),
    functions: functions.map(f => ({
      name: f.name, params: f.params, returnType: f.returnType,
      description: generateFunctionSummary(f),
    })),
    interfaces: interfaces.map(i => ({ name: i.name, fields: i.fields })),
    complexity: functions.reduce((sum, f) => sum + f.complexity, 0),
    lineCount: content.split('\n').length,
  };
}

function inferModulePurpose(path: string, exports: Export[]): string {
  if (path.includes('/api/')) return 'APIエンドポイント';
  if (path.includes('/components/')) return 'UIコンポーネント';
  if (path.includes('/lib/')) return 'ユーティリティ/サービス';
  if (path.includes('/hooks/')) return 'カスタムフック';
  return 'モジュール';
}
```
TEMPLATE
    CEE2_MODULE_EXPLAINED=true
    CEE2_GENERATED_COUNT=$((CEE2_GENERATED_COUNT + 1))
    return 0
}

_cee2_generate_comments() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [CEE2-COMMENTS] インラインコメント生成

```typescript
export function generateInlineComments(code: string): string {
  const lines = code.split('\n');
  const commented: string[] = [];

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const trimmed = line.trim();

    // Complex conditions
    if (trimmed.startsWith('if (') && trimmed.length > 60) {
      commented.push(`${getIndent(line)}// ${explainCondition(trimmed)}`);
    }
    // Regex patterns
    if (trimmed.includes('new RegExp') || /\/[^/]+\/[gimsu]*/.test(trimmed)) {
      commented.push(`${getIndent(line)}// ${explainRegex(trimmed)}`);
    }
    // Algorithm blocks
    if (trimmed.includes('.reduce(') || trimmed.includes('.sort(')) {
      commented.push(`${getIndent(line)}// ${explainArrayOperation(trimmed)}`);
    }

    commented.push(line);
  }
  return commented.join('\n');
}
```
TEMPLATE
    CEE2_COMMENTS_GENERATED=true
    CEE2_GENERATED_COUNT=$((CEE2_GENERATED_COUNT + 1))
    return 0
}

_cee2_generate_jsdoc() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [CEE2-JSDOC] JSDoc生成

```typescript
export function generateJSDoc(func: FunctionInfo): string {
  let doc = '/**\n';
  doc += ` * ${generateFunctionSummary(func)}\n`;
  doc += ' *\n';
  for (const param of func.params) {
    doc += ` * @param {${param.type}} ${param.name} - ${param.description ?? ''}\n`;
  }
  if (func.returnType !== 'void') {
    doc += ` * @returns {${func.returnType}}\n`;
  }
  if (func.sideEffects.length > 0) {
    doc += ` * @sideEffects ${func.sideEffects.join(', ')}\n`;
  }
  doc += ` * @example\n * ${generateUsageExample(func)}\n`;
  doc += ' */\n';
  return doc;
}
```
TEMPLATE
    CEE2_JSDOC_GENERATED=true
    CEE2_GENERATED_COUNT=$((CEE2_GENERATED_COUNT + 1))
    return 0
}

_cee2_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Code Explanation Engine v${CEE2_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成数             : ${CEE2_GENERATED_COUNT}"
    echo -e "  関数解説           : ${CEE2_FUNCTION_EXPLAINED}"
    echo -e "  モジュール解説     : ${CEE2_MODULE_EXPLAINED}"
    echo -e "  コメント           : ${CEE2_COMMENTS_GENERATED}"
    echo -e "  JSDoc              : ${CEE2_JSDOC_GENERATED}"
}

_cee2_score() {
    local score=30
    [[ "$CEE2_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$CEE2_FUNCTION_EXPLAINED" == "true" ]] && score=$((score + 15))
    [[ "$CEE2_MODULE_EXPLAINED" == "true" ]] && score=$((score + 15))
    [[ "$CEE2_COMMENTS_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$CEE2_JSDOC_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "code-explanation-engine" \
    --version "399.0" \
    --description "コード解説エンジン（関数/モジュール/コメント/JSDoc）" \
    --init "_cee2_init" \
    --report "_cee2_report" \
    --score "_cee2_score" \
    --enable-var "ENABLE_CEE2" \
    --cli-flags "--code-explain:--no-code-explain"
