#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v249.0 - Logging & Monitoring Setup
# =============================================================================
# 構造化ログ、エラートラッキング、APM、ヘルスチェック、
# 監視ダッシュボード設定を自動生成する。
#
# 機能:
#   - 構造化ログ（pino/winston）生成
#   - エラートラッキング（Sentry 統合）生成
#   - APM（Application Performance Monitoring）生成
#   - ヘルスチェックエンドポイント生成
#   - 監視ダッシュボード設定生成
#
# 全globals: LMS_ prefix
# =============================================================================

[[ -n "${_LOGGING_MONITORING_SETUP_LOADED:-}" ]] && return 0
_LOGGING_MONITORING_SETUP_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g LMS_VERSION="249.0"
declare -g LMS_INITIALIZED=false
declare -g LMS_LOGGERS_GENERATED=0
declare -g LMS_MONITORS_GENERATED=0
declare -g LMS_HEALTH_CHECKS_GENERATED=0
declare -g LMS_PROJECT_DIR=""
declare -g LMS_LOG_PREFIX="[LMS]"

# =============================================================================
# ログユーティリティ
# =============================================================================
_lms_log() { echo -e "  ${CLR_CYAN:-\033[0;36m}${LMS_LOG_PREFIX}${CLR_NC:-\033[0m} $*" >&2; }
_lms_success() { echo -e "  ${CLR_GREEN:-\033[0;32m}${LMS_LOG_PREFIX} OK${CLR_NC:-\033[0m} $*" >&2; }
_lms_warn() { echo -e "  ${CLR_YELLOW:-\033[0;33m}${LMS_LOG_PREFIX} WARN${CLR_NC:-\033[0m} $*" >&2; }
_lms_error() { echo -e "  ${CLR_RED:-\033[0;31m}${LMS_LOG_PREFIX} ERROR${CLR_NC:-\033[0m} $*" >&2; }

# =============================================================================
# 初期化
# =============================================================================
lms_init() {
    LMS_INITIALIZED=true
    LMS_LOGGERS_GENERATED=0
    LMS_MONITORS_GENERATED=0
    LMS_HEALTH_CHECKS_GENERATED=0
    LMS_PROJECT_DIR="${PROJECT_DIR:-.}"
    return 0
}

# =============================================================================
# 構造化ログ生成
# =============================================================================
# pino ベースの構造化ログシステムを生成。
# リクエストID追跡、ログレベル制御、開発/本番出力切り替え。
#
# 使い方: _lms_generate_logger <output_dir>
# =============================================================================
_lms_generate_logger() {
    local output_dir="${1:-${LMS_PROJECT_DIR}/lib}"
    local output_file="${output_dir}/logger.ts"

    [[ "$LMS_INITIALIZED" != "true" ]] && { _lms_error "未初期化"; return 1; }

    _lms_log "構造化ログシステム生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$output_file" <<'TS_LOGGER'
// =============================================================================
// SoloptiLinkAI v249.0 - Structured Logger
// pino 互換の構造化ログシステム
// =============================================================================

type LogLevel = 'trace' | 'debug' | 'info' | 'warn' | 'error' | 'fatal';

interface LogEntry {
  level: LogLevel;
  timestamp: string;
  message: string;
  requestId?: string;
  userId?: string;
  module?: string;
  duration?: number;
  error?: {
    name: string;
    message: string;
    stack?: string;
  };
  [key: string]: unknown;
}

const LOG_LEVELS: Record<LogLevel, number> = {
  trace: 10, debug: 20, info: 30, warn: 40, error: 50, fatal: 60,
};

class Logger {
  private minLevel: number;
  private defaultMeta: Record<string, unknown>;

  constructor(options: { level?: LogLevel; meta?: Record<string, unknown> } = {}) {
    this.minLevel = LOG_LEVELS[options.level || 'info'];
    this.defaultMeta = options.meta || {};
  }

  private shouldLog(level: LogLevel): boolean {
    return LOG_LEVELS[level] >= this.minLevel;
  }

  private formatEntry(level: LogLevel, message: string, data?: Record<string, unknown>): LogEntry {
    return {
      level,
      timestamp: new Date().toISOString(),
      message,
      ...this.defaultMeta,
      ...data,
    };
  }

  private output(entry: LogEntry): void {
    const json = JSON.stringify(entry);

    if (process.env.NODE_ENV === 'development') {
      const color = { trace: '90', debug: '36', info: '32', warn: '33', error: '31', fatal: '35' };
      const c = color[entry.level] || '0';
      console.log(`\x1b[${c}m[${entry.level.toUpperCase()}]\x1b[0m ${entry.message}`,
        Object.keys(entry).length > 3 ? entry : '');
    } else {
      // 本番: JSON 構造化ログ
      if (LOG_LEVELS[entry.level] >= LOG_LEVELS.error) {
        console.error(json);
      } else {
        console.log(json);
      }
    }
  }

  trace(message: string, data?: Record<string, unknown>) {
    if (this.shouldLog('trace')) this.output(this.formatEntry('trace', message, data));
  }

  debug(message: string, data?: Record<string, unknown>) {
    if (this.shouldLog('debug')) this.output(this.formatEntry('debug', message, data));
  }

  info(message: string, data?: Record<string, unknown>) {
    if (this.shouldLog('info')) this.output(this.formatEntry('info', message, data));
  }

  warn(message: string, data?: Record<string, unknown>) {
    if (this.shouldLog('warn')) this.output(this.formatEntry('warn', message, data));
  }

  error(message: string, err?: Error | Record<string, unknown>, data?: Record<string, unknown>) {
    if (!this.shouldLog('error')) return;
    const errorData = err instanceof Error
      ? { error: { name: err.name, message: err.message, stack: err.stack }, ...data }
      : { ...err, ...data };
    this.output(this.formatEntry('error', message, errorData));
  }

  fatal(message: string, err?: Error | Record<string, unknown>) {
    if (!this.shouldLog('fatal')) return;
    const errorData = err instanceof Error
      ? { error: { name: err.name, message: err.message, stack: err.stack } }
      : err;
    this.output(this.formatEntry('fatal', message, errorData));
  }

  child(meta: Record<string, unknown>): Logger {
    return new Logger({
      level: Object.entries(LOG_LEVELS).find(([, v]) => v === this.minLevel)?.[0] as LogLevel,
      meta: { ...this.defaultMeta, ...meta },
    });
  }
}

// --- シングルトン ---
const logLevel = (process.env.LOG_LEVEL || 'info') as LogLevel;
export const logger = new Logger({ level: logLevel });

// --- リクエストスコープロガー ---
export function createRequestLogger(requestId: string, userId?: string): Logger {
  return logger.child({ requestId, userId });
}

// --- API ルートロギングラッパー ---
export function withLogging(
  handler: (req: Request) => Promise<Response>,
  routeName: string
) {
  return async (req: Request): Promise<Response> => {
    const start = Date.now();
    const requestId = crypto.randomUUID();
    const log = createRequestLogger(requestId);

    log.info(`${req.method} ${routeName} started`, { url: req.url });

    try {
      const response = await handler(req);
      const duration = Date.now() - start;
      log.info(`${req.method} ${routeName} completed`, {
        status: response.status, duration,
      });
      return response;
    } catch (err) {
      const duration = Date.now() - start;
      log.error(`${req.method} ${routeName} failed`, err as Error, { duration });
      throw err;
    }
  };
}

export { Logger };
export type { LogLevel, LogEntry };
TS_LOGGER

    if [[ -f "$output_file" ]]; then
        LMS_LOGGERS_GENERATED=$((LMS_LOGGERS_GENERATED + 1))
        _lms_success "構造化ログ生成完了: ${output_file}"
        return 0
    fi
    return 1
}

# =============================================================================
# エラートラッキング生成
# =============================================================================
_lms_generate_error_tracking() {
    local output_dir="${1:-${LMS_PROJECT_DIR}/lib}"
    local output_file="${output_dir}/error-tracking.ts"

    [[ "$LMS_INITIALIZED" != "true" ]] && { _lms_error "未初期化"; return 1; }

    _lms_log "エラートラッキング生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$output_file" <<'TS_SENTRY'
// =============================================================================
// SoloptiLinkAI v249.0 - Error Tracking
// Sentry 互換エラートラッキングシステム
// =============================================================================

interface ErrorTrackingConfig {
  dsn?: string;
  environment: string;
  release?: string;
  sampleRate?: number;
  tracesSampleRate?: number;
}

interface CapturedError {
  id: string;
  timestamp: string;
  level: 'warning' | 'error' | 'fatal';
  message: string;
  stack?: string;
  tags: Record<string, string>;
  extra: Record<string, unknown>;
  user?: { id: string; email?: string };
  request?: { url: string; method: string; headers: Record<string, string> };
}

class ErrorTracker {
  private config: ErrorTrackingConfig;
  private errors: CapturedError[] = [];
  private breadcrumbs: Array<{ timestamp: string; category: string; message: string }> = [];

  constructor(config: ErrorTrackingConfig) {
    this.config = config;
  }

  init(): void {
    if (typeof window !== 'undefined') {
      window.addEventListener('error', (event) => {
        this.captureError(event.error || new Error(event.message));
      });
      window.addEventListener('unhandledrejection', (event) => {
        this.captureError(event.reason instanceof Error
          ? event.reason
          : new Error(String(event.reason)));
      });
    }
  }

  addBreadcrumb(category: string, message: string): void {
    this.breadcrumbs.push({
      timestamp: new Date().toISOString(),
      category,
      message,
    });
    // 最新 50 件のみ保持
    if (this.breadcrumbs.length > 50) {
      this.breadcrumbs = this.breadcrumbs.slice(-50);
    }
  }

  captureError(
    error: Error,
    context?: { tags?: Record<string, string>; extra?: Record<string, unknown> }
  ): string {
    const id = crypto.randomUUID();
    const captured: CapturedError = {
      id,
      timestamp: new Date().toISOString(),
      level: 'error',
      message: error.message,
      stack: error.stack,
      tags: { environment: this.config.environment, ...context?.tags },
      extra: { breadcrumbs: [...this.breadcrumbs], ...context?.extra },
    };

    this.errors.push(captured);
    console.error(`[ErrorTracker] Captured: ${id} - ${error.message}`);

    // DSN 設定時は外部送信
    if (this.config.dsn) {
      this.sendToRemote(captured).catch(() => {});
    }

    return id;
  }

  captureMessage(message: string, level: 'warning' | 'error' = 'warning'): string {
    const id = crypto.randomUUID();
    const captured: CapturedError = {
      id,
      timestamp: new Date().toISOString(),
      level,
      message,
      tags: { environment: this.config.environment },
      extra: {},
    };
    this.errors.push(captured);
    return id;
  }

  private async sendToRemote(error: CapturedError): Promise<void> {
    if (!this.config.dsn) return;
    try {
      await fetch(this.config.dsn, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(error),
      });
    } catch {
      // サイレントフェイル（トラッキング自体のエラーは無視）
    }
  }

  getErrors(): CapturedError[] {
    return [...this.errors];
  }

  clearErrors(): void {
    this.errors = [];
  }
}

// --- シングルトン ---
export const errorTracker = new ErrorTracker({
  dsn: process.env.NEXT_PUBLIC_SENTRY_DSN || '',
  environment: process.env.NODE_ENV || 'development',
  release: process.env.NEXT_PUBLIC_APP_VERSION,
  sampleRate: 1.0,
  tracesSampleRate: 0.1,
});

export { ErrorTracker };
export type { ErrorTrackingConfig, CapturedError };
TS_SENTRY

    if [[ -f "$output_file" ]]; then
        LMS_MONITORS_GENERATED=$((LMS_MONITORS_GENERATED + 1))
        _lms_success "エラートラッキング生成完了: ${output_file}"
        return 0
    fi
    return 1
}

# =============================================================================
# APM 生成
# =============================================================================
_lms_generate_apm() {
    local output_dir="${1:-${LMS_PROJECT_DIR}/lib}"
    local output_file="${output_dir}/apm.ts"

    [[ "$LMS_INITIALIZED" != "true" ]] && { _lms_error "未初期化"; return 1; }

    _lms_log "APM 生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$output_file" <<'TS_APM'
// =============================================================================
// SoloptiLinkAI v249.0 - Application Performance Monitoring
// =============================================================================

interface Metric {
  name: string;
  value: number;
  unit: 'ms' | 'bytes' | 'count' | 'percent';
  timestamp: number;
  tags: Record<string, string>;
}

interface Span {
  traceId: string;
  spanId: string;
  name: string;
  startTime: number;
  endTime?: number;
  duration?: number;
  status: 'ok' | 'error';
  attributes: Record<string, unknown>;
}

class APMCollector {
  private metrics: Metric[] = [];
  private spans: Span[] = [];
  private maxMetrics = 1000;
  private maxSpans = 500;

  // --- メトリクス ---
  recordMetric(name: string, value: number, unit: Metric['unit'], tags: Record<string, string> = {}): void {
    this.metrics.push({ name, value, unit, timestamp: Date.now(), tags });
    if (this.metrics.length > this.maxMetrics) {
      this.metrics = this.metrics.slice(-this.maxMetrics);
    }
  }

  // --- トレーシング ---
  startSpan(name: string, attributes: Record<string, unknown> = {}): Span {
    const span: Span = {
      traceId: crypto.randomUUID(),
      spanId: crypto.randomUUID().slice(0, 16),
      name,
      startTime: performance.now(),
      status: 'ok',
      attributes,
    };
    return span;
  }

  endSpan(span: Span, status: 'ok' | 'error' = 'ok'): void {
    span.endTime = performance.now();
    span.duration = span.endTime - span.startTime;
    span.status = status;
    this.spans.push(span);

    // 自動メトリクス記録
    this.recordMetric(`span.${span.name}.duration`, span.duration, 'ms', {
      status: span.status,
    });

    if (this.spans.length > this.maxSpans) {
      this.spans = this.spans.slice(-this.maxSpans);
    }
  }

  // --- API タイミング計測 ---
  async measureAsync<T>(name: string, fn: () => Promise<T>): Promise<T> {
    const span = this.startSpan(name);
    try {
      const result = await fn();
      this.endSpan(span, 'ok');
      return result;
    } catch (error) {
      this.endSpan(span, 'error');
      throw error;
    }
  }

  // --- Web Vitals 収集 ---
  collectWebVitals(): void {
    if (typeof window === 'undefined' || !('PerformanceObserver' in window)) return;

    // LCP
    try {
      const lcpObserver = new PerformanceObserver((list) => {
        const entries = list.getEntries();
        const lastEntry = entries[entries.length - 1];
        if (lastEntry) {
          this.recordMetric('web_vitals.lcp', lastEntry.startTime, 'ms');
        }
      });
      lcpObserver.observe({ type: 'largest-contentful-paint', buffered: true });
    } catch {}

    // FID
    try {
      const fidObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          const fidEntry = entry as PerformanceEventTiming;
          this.recordMetric('web_vitals.fid', fidEntry.processingStart - fidEntry.startTime, 'ms');
        }
      });
      fidObserver.observe({ type: 'first-input', buffered: true });
    } catch {}

    // CLS
    try {
      let clsValue = 0;
      const clsObserver = new PerformanceObserver((list) => {
        for (const entry of list.getEntries()) {
          if (!(entry as any).hadRecentInput) {
            clsValue += (entry as any).value;
          }
        }
        this.recordMetric('web_vitals.cls', clsValue, 'count');
      });
      clsObserver.observe({ type: 'layout-shift', buffered: true });
    } catch {}
  }

  // --- レポート ---
  getMetrics(name?: string): Metric[] {
    if (name) return this.metrics.filter(m => m.name === name);
    return [...this.metrics];
  }

  getSpans(): Span[] {
    return [...this.spans];
  }

  getSummary(): Record<string, { avg: number; p95: number; count: number }> {
    const groups: Record<string, number[]> = {};
    for (const m of this.metrics) {
      if (!groups[m.name]) groups[m.name] = [];
      groups[m.name].push(m.value);
    }

    const summary: Record<string, { avg: number; p95: number; count: number }> = {};
    for (const [name, values] of Object.entries(groups)) {
      values.sort((a, b) => a - b);
      const avg = values.reduce((s, v) => s + v, 0) / values.length;
      const p95Index = Math.ceil(values.length * 0.95) - 1;
      summary[name] = {
        avg: Math.round(avg * 100) / 100,
        p95: values[p95Index] || 0,
        count: values.length,
      };
    }
    return summary;
  }
}

export const apm = new APMCollector();
export { APMCollector };
export type { Metric, Span };
TS_APM

    if [[ -f "$output_file" ]]; then
        LMS_MONITORS_GENERATED=$((LMS_MONITORS_GENERATED + 1))
        _lms_success "APM 生成完了: ${output_file}"
        return 0
    fi
    return 1
}

# =============================================================================
# ヘルスチェックエンドポイント生成
# =============================================================================
_lms_generate_health_check() {
    local output_dir="${1:-${LMS_PROJECT_DIR}/app/api/health}"
    local output_file="${output_dir}/route.ts"

    [[ "$LMS_INITIALIZED" != "true" ]] && { _lms_error "未初期化"; return 1; }

    _lms_log "ヘルスチェックエンドポイント生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$output_file" <<'TS_HEALTH'
// =============================================================================
// SoloptiLinkAI v249.0 - Health Check Endpoint
// =============================================================================

import { NextResponse } from 'next/server';

interface HealthStatus {
  status: 'healthy' | 'degraded' | 'unhealthy';
  timestamp: string;
  version: string;
  uptime: number;
  checks: Record<string, {
    status: 'pass' | 'fail' | 'warn';
    duration?: number;
    message?: string;
  }>;
}

const startTime = Date.now();

async function checkDatabase(): Promise<{ status: 'pass' | 'fail'; duration: number; message?: string }> {
  const start = performance.now();
  try {
    // Prisma health check
    // await prisma.$queryRaw`SELECT 1`;
    return { status: 'pass', duration: Math.round(performance.now() - start) };
  } catch (err) {
    return {
      status: 'fail',
      duration: Math.round(performance.now() - start),
      message: err instanceof Error ? err.message : 'Unknown error',
    };
  }
}

async function checkMemory(): Promise<{ status: 'pass' | 'warn' | 'fail'; message: string }> {
  if (typeof process !== 'undefined' && process.memoryUsage) {
    const usage = process.memoryUsage();
    const heapUsedMB = Math.round(usage.heapUsed / 1024 / 1024);
    const heapTotalMB = Math.round(usage.heapTotal / 1024 / 1024);
    const ratio = usage.heapUsed / usage.heapTotal;

    if (ratio > 0.9) return { status: 'fail', message: `Heap: ${heapUsedMB}/${heapTotalMB}MB (${Math.round(ratio*100)}%)` };
    if (ratio > 0.7) return { status: 'warn', message: `Heap: ${heapUsedMB}/${heapTotalMB}MB (${Math.round(ratio*100)}%)` };
    return { status: 'pass', message: `Heap: ${heapUsedMB}/${heapTotalMB}MB` };
  }
  return { status: 'pass', message: 'N/A (client)' };
}

export async function GET() {
  const dbCheck = await checkDatabase();
  const memCheck = await checkMemory();

  const checks = {
    database: dbCheck,
    memory: memCheck,
  };

  const hasFailure = Object.values(checks).some(c => c.status === 'fail');
  const hasWarning = Object.values(checks).some(c => c.status === 'warn');
  const overallStatus = hasFailure ? 'unhealthy' : hasWarning ? 'degraded' : 'healthy';

  const health: HealthStatus = {
    status: overallStatus,
    timestamp: new Date().toISOString(),
    version: process.env.NEXT_PUBLIC_APP_VERSION || '0.0.0',
    uptime: Math.round((Date.now() - startTime) / 1000),
    checks,
  };

  return NextResponse.json(health, {
    status: overallStatus === 'unhealthy' ? 503 : 200,
    headers: { 'Cache-Control': 'no-cache, no-store' },
  });
}
TS_HEALTH

    if [[ -f "$output_file" ]]; then
        LMS_HEALTH_CHECKS_GENERATED=$((LMS_HEALTH_CHECKS_GENERATED + 1))
        _lms_success "ヘルスチェック生成完了: ${output_file}"
        return 0
    fi
    return 1
}

# =============================================================================
# 監視ダッシュボード設定生成
# =============================================================================
_lms_generate_dashboard_config() {
    local output_dir="${1:-${LMS_PROJECT_DIR}}"
    local output_file="${output_dir}/monitoring-config.json"

    [[ "$LMS_INITIALIZED" != "true" ]] && { _lms_error "未初期化"; return 1; }

    _lms_log "監視ダッシュボード設定生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$output_file" <<'JSON_MONITOR'
{
  "version": "249.0",
  "monitoring": {
    "healthCheck": {
      "endpoint": "/api/health",
      "intervalMs": 30000,
      "timeout": 5000,
      "alertOnFailure": true
    },
    "metrics": {
      "webVitals": {
        "LCP": { "target": 2500, "warning": 4000 },
        "FID": { "target": 100, "warning": 300 },
        "CLS": { "target": 0.1, "warning": 0.25 },
        "TTFB": { "target": 800, "warning": 1800 }
      },
      "api": {
        "p95ResponseTime": { "target": 500, "warning": 1000, "unit": "ms" },
        "errorRate": { "target": 0.01, "warning": 0.05, "unit": "ratio" },
        "availability": { "target": 0.999, "warning": 0.995, "unit": "ratio" }
      },
      "system": {
        "cpuUsage": { "warning": 80, "critical": 95, "unit": "percent" },
        "memoryUsage": { "warning": 80, "critical": 95, "unit": "percent" },
        "diskUsage": { "warning": 80, "critical": 90, "unit": "percent" }
      }
    },
    "alerts": {
      "channels": ["email", "slack"],
      "rules": [
        {
          "name": "HighErrorRate",
          "condition": "error_rate > 0.05 for 5m",
          "severity": "critical"
        },
        {
          "name": "SlowResponse",
          "condition": "p95_latency > 2000 for 10m",
          "severity": "warning"
        },
        {
          "name": "HealthCheckFailed",
          "condition": "health_status == unhealthy for 1m",
          "severity": "critical"
        }
      ]
    }
  }
}
JSON_MONITOR

    if [[ -f "$output_file" ]]; then
        _lms_success "監視ダッシュボード設定生成完了: ${output_file}"
        return 0
    fi
    return 1
}

# =============================================================================
# プロンプト注入
# =============================================================================
_lms_inject_prompt() {
    cat <<'PROMPT'
## [LMS] ロギング & 監視ルール

### ログ
- 構造化 JSON ログ必須（console.log 直接使用禁止）
- リクエストID をログに含める
- エラーログにスタックトレース必須
- 機密データ（パスワード、トークン）をログに含めない

### エラートラッキング
- 未キャッチ例外の自動捕捉
- ユーザーコンテキスト付与
- Breadcrumb でユーザー操作追跡

### ヘルスチェック
- /api/health エンドポイント必須
- DB 接続、メモリ使用率を検査
- 503 レスポンスで異常を通知

### APM
- API レスポンスタイム計測
- Web Vitals (LCP, FID, CLS) 自動収集
PROMPT
}

# =============================================================================
# レポート
# =============================================================================
lms_report() {
    echo -e "\n  ${BOLD:-}--- Logging & Monitoring Setup v${LMS_VERSION} ---${NC:-}"
    echo -e "  ロガー生成        : ${LMS_LOGGERS_GENERATED}"
    echo -e "  モニター生成      : ${LMS_MONITORS_GENERATED}"
    echo -e "  ヘルスチェック    : ${LMS_HEALTH_CHECKS_GENERATED}"
}

lms_report_json() {
    cat <<EOF
{"module":"logging-monitoring-setup","version":"${LMS_VERSION}","loggers":${LMS_LOGGERS_GENERATED},"monitors":${LMS_MONITORS_GENERATED},"health_checks":${LMS_HEALTH_CHECKS_GENERATED}}
EOF
}

lms_score() {
    if [[ "$LMS_INITIALIZED" != "true" ]]; then echo 0; return; fi
    local score=60
    [[ $LMS_LOGGERS_GENERATED -gt 0 ]] && score=$((score + 15))
    [[ $LMS_MONITORS_GENERATED -gt 0 ]] && score=$((score + 15))
    [[ $LMS_HEALTH_CHECKS_GENERATED -gt 0 ]] && score=$((score + 10))
    echo "$score"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "logging-monitoring-setup" \
        --version "249.0" \
        --description "構造化ログ + エラートラッキング + APM + ヘルスチェック" \
        --init "lms_init" \
        --report "lms_report" \
        --score "lms_score" \
        --enable-var "ENABLE_LOGGING_MONITORING" \
        --cli-flags "--logging:--no-logging"
fi

# v2003.1: source時のexit codeを確実に0にする
true
