#!/usr/bin/env bash
# SoloptiLinkAI v2033.1 - Telemetry Auto-Recorder (TAR)
# BOOST セッションの開始・完了を learning/sessions.jsonl に詳細記録する
#
# 過去の問題 (本日 2026-05-11 の Daily Upgrade で観測):
#   - sessions.jsonl の直近 10 件すべて version=null / task=null / score=null
#   - "ts" と "status:ok" だけの空殻 record では学習データとして集計できない
#
# v2033.1 設計:
#   - tar_record_start  : セッション開始時に session_id / version / task_type / domain を記録
#   - tar_record_end    : セッション完了時に status / fortress_score / duration_sec を記録
#   - sessions.jsonl は append-only (既存セマンティクス維持)
#   - 1 セッション = 2 record (start + end) のペアになる
#   - 既存の単純 record (空殻) は触らない (互換性維持)

[[ -n "${_TAR_LOADED:-}" ]] && return 0
_TAR_LOADED=1

TAR_VERSION="2033.1"
TAR_HOME="${SOLOPTILINK_HOME:-$HOME/.soloptilink}"
TAR_LEARN="${TAR_HOME}/learning"
TAR_SESSIONS="${TAR_LEARN}/sessions.jsonl"
TAR_STATE_DIR="${TAR_HOME}/.coordination"
TAR_STATE_FILE="${TAR_STATE_DIR}/tar-current-session.json"

mkdir -p "$TAR_LEARN" "$TAR_STATE_DIR" 2>/dev/null || true
touch "$TAR_SESSIONS" 2>/dev/null || true

_tar_now() { date -u +%Y-%m-%dT%H:%M:%SZ; }
_tar_now_epoch() { date -u +%s; }

# JSONL に 1 record を append (atomic: 1行)
_tar_append_jsonl() {
    local record="$1"
    [[ -z "$record" ]] && return 0
    printf '%s\n' "$record" >> "$TAR_SESSIONS"
}

# セッション開始記録
# 引数: session_id, version, task_type, domain
tar_record_start() {
    local session_id="${1:-${SOLOPTILINK_SESSION_ID:-unknown}}"
    local version="${2:-$(cat "${TAR_HOME}/VERSION" 2>/dev/null || echo unknown)}"
    local task_type="${3:-${BOOST_TASK_TYPE:-unknown}}"
    local domain="${4:-${BOOST_DOMAIN:-unknown}}"
    local now epoch
    now=$(_tar_now)
    epoch=$(_tar_now_epoch)
    local record
    record=$(printf '{"ts":"%s","epoch":%s,"event":"session_start","session_id":"%s","version":"%s","task_type":"%s","domain":"%s","recorder":"TAR v%s"}' \
        "$now" "$epoch" "$session_id" "$version" "$task_type" "$domain" "$TAR_VERSION")
    _tar_append_jsonl "$record"
    # state file: end record で reference するために start epoch を保存
    cat > "$TAR_STATE_FILE" <<EOF
{"session_id":"${session_id}","version":"${version}","task_type":"${task_type}","domain":"${domain}","start_epoch":${epoch},"start_ts":"${now}"}
EOF
    echo "[TAR] session_start recorded: ${session_id} (v${version} / ${task_type})"
}

# セッション完了記録
# 引数: status (ok/fail/partial), fortress_score (任意), summary (任意)
tar_record_end() {
    local status="${1:-ok}"
    local score="${2:-null}"
    local summary="${3:-}"
    local now epoch
    now=$(_tar_now)
    epoch=$(_tar_now_epoch)

    local session_id="unknown" version="unknown" task_type="unknown" domain="unknown"
    local start_epoch="$epoch" duration_sec=0
    if [[ -f "$TAR_STATE_FILE" ]]; then
        session_id=$(grep -oE '"session_id":"[^"]+"' "$TAR_STATE_FILE" | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
        version=$(grep -oE '"version":"[^"]+"' "$TAR_STATE_FILE" | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
        task_type=$(grep -oE '"task_type":"[^"]+"' "$TAR_STATE_FILE" | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
        domain=$(grep -oE '"domain":"[^"]+"' "$TAR_STATE_FILE" | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
        start_epoch=$(grep -oE '"start_epoch":[0-9]+' "$TAR_STATE_FILE" | grep -oE '[0-9]+' | head -1 || echo "$epoch")
        duration_sec=$(( epoch - start_epoch ))
    fi
    [[ -z "$session_id" ]] && session_id="${SOLOPTILINK_SESSION_ID:-unknown}"

    # summary を JSON-safe にエスケープ (簡易: " と \ のみ)
    local safe_summary
    safe_summary=$(printf '%s' "$summary" | sed 's/\\/\\\\/g; s/"/\\"/g' | head -c 500)

    local record
    record=$(printf '{"ts":"%s","epoch":%s,"event":"session_end","session_id":"%s","version":"%s","task_type":"%s","domain":"%s","status":"%s","fortress_score":%s,"duration_sec":%s,"summary":"%s","recorder":"TAR v%s"}' \
        "$now" "$epoch" "$session_id" "$version" "$task_type" "$domain" \
        "$status" "$score" "$duration_sec" "$safe_summary" "$TAR_VERSION")
    _tar_append_jsonl "$record"
    rm -f "$TAR_STATE_FILE"
    echo "[TAR] session_end recorded: ${session_id} status=${status} score=${score} duration=${duration_sec}s"
}

# 直近 N 件の TAR 記録から集計サマリー
tar_summary() {
    local n="${1:-30}"
    [[ -f "$TAR_SESSIONS" ]] || { echo "- no sessions.jsonl yet"; return; }
    local total starts ends ok_count fail_count avg_score
    # grep -c は 0 件でも "0" を出力するので || は不要 (二重発火を避ける)
    total=$(grep -c '"recorder":"TAR ' "$TAR_SESSIONS" 2>/dev/null); total="${total:-0}"
    starts=$(grep -c '"event":"session_start"' "$TAR_SESSIONS" 2>/dev/null); starts="${starts:-0}"
    ends=$(grep -c '"event":"session_end"' "$TAR_SESSIONS" 2>/dev/null); ends="${ends:-0}"
    ok_count=$(grep '"event":"session_end"' "$TAR_SESSIONS" 2>/dev/null | grep -c '"status":"ok"'); ok_count="${ok_count:-0}"
    fail_count=$(grep '"event":"session_end"' "$TAR_SESSIONS" 2>/dev/null | grep -c '"status":"fail"'); fail_count="${fail_count:-0}"

    avg_score=$(grep '"event":"session_end"' "$TAR_SESSIONS" 2>/dev/null \
        | tail -"$n" \
        | grep -oE '"fortress_score":[0-9.]+' \
        | grep -oE '[0-9.]+' \
        | awk 'BEGIN{s=0;c=0} {s+=$1;c++} END {if (c>0) printf "%.1f", s/c; else print "n/a"}')

    echo "- TAR records total: ${total} (start=${starts} / end=${ends})"
    echo "- session status: ok=${ok_count} / fail=${fail_count}"
    echo "- avg fortress_score (last ${n}): ${avg_score}"
}

# CLI
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-summary}" in
        start)   shift; tar_record_start "$@" ;;
        end)     shift; tar_record_end "$@" ;;
        summary) shift; tar_summary "${1:-30}" ;;
        version) echo "$TAR_VERSION" ;;
        *) echo "usage: $0 {start <session_id> <version> <task_type> <domain>|end <status> <score> <summary>|summary [n]|version}" >&2; exit 2 ;;
    esac
fi
