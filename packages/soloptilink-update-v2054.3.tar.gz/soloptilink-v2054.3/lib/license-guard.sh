#!/usr/bin/env bash
# ╔═══════════════════════════════════════════════════════════╗
# ║  SoloptiLinkAI - License Guard Module v3.0               ║
# ║  端末認証必須版（サーバー承認なしでは動作不可）           ║
# ║                                                           ║
# ║  セキュリティ方針:                                        ║
# ║  1. ローカルファイルだけでは動作しない                    ║
# ║  2. 毎回サーバーに認証リクエストを送る                    ║
# ║  3. サーバーが発行した署名付きレスポンスのみ受け入れる    ║
# ║  4. ローカルキー自己生成は不可（AIによるバイパス防止）    ║
# ╚═══════════════════════════════════════════════════════════╝

readonly LG_VERSION="3.0.0"
readonly LG_LICENSE_DIR="${HOME}/.soloptilink/.license"
readonly LG_LICENSE_FILE="${LG_LICENSE_DIR}/license.key"
readonly LG_SESSION_FILE="${LG_LICENSE_DIR}/.session_token"

# カラー
readonly LG_RED='\033[0;31m'
readonly LG_GREEN='\033[0;32m'
readonly LG_YELLOW='\033[0;33m'
readonly LG_CYAN='\033[0;36m'
readonly LG_BOLD='\033[1m'
readonly LG_NC='\033[0m'

# ============================================================
# サーバー URL 取得
# ============================================================
_lg_server_url() {
    if [[ -n "${SOLOPTILINK_SERVER:-}" ]]; then
        echo "$SOLOPTILINK_SERVER"
        return
    fi
    local url_file="${LG_LICENSE_DIR}/.server_url"
    if [[ -f "$url_file" ]]; then
        local url
        url=$(cat "$url_file" 2>/dev/null | tr -d '[:space:]')
        if [[ -n "$url" ]]; then
            echo "$url"
            return
        fi
    fi
    echo "${SOLOPTILINK_DEFAULT_SERVER:-https://your-admin-dashboard.vercel.app}"
}

# ============================================================
# マシンハッシュ（SHA256先頭8文字）
# ============================================================
_lg_machine_hash() {
    local machine_id=""
    local os_type
    os_type=$(uname -s 2>/dev/null || echo "Unknown")

    case "$os_type" in
        Darwin)
            machine_id=$(ioreg -rd1 -c IOPlatformExpertDevice 2>/dev/null \
                | grep -i "IOPlatformUUID" | awk -F'"' '{print $4}' || echo "")
            ;;
        Linux)
            machine_id=$(cat /etc/machine-id 2>/dev/null \
                || cat /var/lib/dbus/machine-id 2>/dev/null || echo "")
            ;;
        MINGW*|MSYS*|CYGWIN*)
            # PowerShell優先（Windows 11 では wmic が非推奨）
            if command -v powershell.exe &>/dev/null; then
                machine_id=$(powershell.exe -NoProfile -Command \
                    "(Get-CimInstance -ClassName Win32_ComputerSystemProduct).UUID" 2>/dev/null | tr -d '[:space:]')
            fi
            if [[ -z "$machine_id" ]] && command -v wmic &>/dev/null; then
                machine_id=$(wmic csproduct get UUID 2>/dev/null | grep -v UUID | tr -d '[:space:]\r\n')
            fi
            if [[ -z "$machine_id" ]]; then
                machine_id=$(hostname)
            fi
            ;;
    esac

    if [[ -z "$machine_id" ]]; then
        machine_id="$(hostname 2>/dev/null):$(id -un 2>/dev/null)"
    fi

    # v2004.0 セキュリティ強化: ハッシュ長を8→16文字に拡張
    # 8文字 = 2^32（総当たり数分）→ 16文字 = 2^64（総当たり数百年）
    # md5フォールバック削除（暗号学的に破綻済み）
    local hash=""
    if command -v sha256sum &>/dev/null; then
        hash=$(echo -n "${machine_id}:$(id -un 2>/dev/null):soloptilink-v2004" | sha256sum | cut -c1-16)
    elif command -v shasum &>/dev/null; then
        hash=$(echo -n "${machine_id}:$(id -un 2>/dev/null):soloptilink-v2004" | shasum -a 256 | cut -c1-16)
    else
        # md5フォールバック廃止: sha256が使えない環境はサポート対象外
        echo "ERROR: sha256sum or shasum required. Cannot generate secure machine hash." >&2
        exit 1
    fi
    if [[ -z "$hash" || ${#hash} -lt 16 ]]; then
        echo "ERROR: Failed to generate machine hash." >&2
        exit 1
    fi
    echo "$hash"
}

# ============================================================
# v2008.6: セッションキャッシュ確認（1時間以内なら高速パス）
# 12h→1hに短縮。未承認端末の即時ブロックを確実にするため。
# さらにステータスフィールドを保存・確認し、ACTIVE以外は拒否。
# ============================================================
_lg_check_session_cache() {
    [[ ! -f "$LG_SESSION_FILE" ]] && return 1

    local session_data
    session_data=$(cat "$LG_SESSION_FILE" 2>/dev/null) || return 1

    local cached_machine_hash
    cached_machine_hash=$(echo "$session_data" | grep "^machine_hash=" | cut -d= -f2-)
    local cached_expires_at
    cached_expires_at=$(echo "$session_data" | grep "^expires_at=" | cut -d= -f2-)
    local cached_customer_id
    cached_customer_id=$(echo "$session_data" | grep "^customer_id=" | cut -d= -f2-)
    local cached_status
    cached_status=$(echo "$session_data" | grep "^status=" | cut -d= -f2-)

    local current_hash
    current_hash=$(_lg_machine_hash)
    [[ "$cached_machine_hash" != "$current_hash" ]] && return 1

    # ステータスがACTIVE以外ならキャッシュ無効（PENDING/SUSPENDED/REJECTED拒否）
    if [[ -n "$cached_status" ]] && [[ "$cached_status" != "ACTIVE" ]]; then
        rm -f "$LG_SESSION_FILE" 2>/dev/null
        return 1
    fi

    local now
    now=$(date '+%s')
    [[ -z "$cached_expires_at" ]] && return 1
    [[ "$now" -ge "$cached_expires_at" ]] && return 1

    # v2008.6: キャッシュ保存から1時間以上経過したらサーバー再検証を強制
    local cached_saved_at
    cached_saved_at=$(echo "$session_data" | grep "^saved_at=" | cut -d= -f2-)
    if [[ -n "$cached_saved_at" ]]; then
        local elapsed=$(( now - cached_saved_at ))
        if [[ "$elapsed" -ge 3600 ]]; then
            # 1時間経過 → キャッシュ無効化してサーバー認証を強制
            return 1
        fi
    fi

    LG_CUSTOMER_ID="$cached_customer_id"
    return 0
}

# ============================================================
# セッショントークン保存
# ============================================================
_lg_save_session() {
    local machine_hash="$1"
    local session_token="$2"
    local expires_at="$3"
    local customer_id="$4"
    local status="${5:-ACTIVE}"

    mkdir -p "$LG_LICENSE_DIR" 2>/dev/null
    chmod 700 "$LG_LICENSE_DIR" 2>/dev/null

    cat > "$LG_SESSION_FILE" 2>/dev/null <<SESSIONEOF
machine_hash=${machine_hash}
session_token=${session_token}
expires_at=${expires_at}
customer_id=${customer_id}
status=${status}
saved_at=$(date '+%s')
SESSIONEOF
    chmod 600 "$LG_SESSION_FILE" 2>/dev/null
}

# ============================================================
# 端末登録（初回 / 未登録時）
# ============================================================
_lg_register_terminal() {
    local machine_hash="$1"
    local license_key="$2"
    local server_url="$3"

    local hostname
    hostname=$(hostname 2>/dev/null | cut -c1-128)
    local os_type
    os_type=$(uname -s 2>/dev/null | cut -c1-64)
    local username
    username=$(id -un 2>/dev/null | cut -c1-64)

    local response
    response=$(curl -s -m 15 -X POST \
        "${server_url}/api/v1/license/terminal-register" \
        -H "Content-Type: application/json" \
        -d "{\"machineHash\":\"${machine_hash}\",\"licenseKey\":\"${license_key}\",\"hostname\":\"${hostname}\",\"os\":\"${os_type}\",\"username\":\"${username}\"}" \
        2>/dev/null) || {
        echo -e "${LG_RED}[LICENSE] サーバーへの接続に失敗しました${LG_NC}" >&2
        return 1
    }

    local status
    status=$(echo "$response" | grep -o '"status":"[^"]*"' | head -1 | cut -d'"' -f4)
    local error
    error=$(echo "$response" | grep -o '"error":"[^"]*"' | head -1 | cut -d'"' -f4)

    if [[ -n "$error" ]]; then
        echo -e "${LG_RED}[LICENSE] 端末登録エラー: ${error}${LG_NC}" >&2
        return 1
    fi

    case "$status" in
        ACTIVE)
            echo -e "${LG_GREEN}  ✓ この端末は既に承認済みです${LG_NC}" >&2
            return 0
            ;;
        PENDING)
            echo "" >&2
            echo -e "${LG_YELLOW}╔══════════════════════════════════════════════════════════╗${LG_NC}" >&2
            echo -e "${LG_YELLOW}║           🔐 端末承認が必要です                            ║${LG_NC}" >&2
            echo -e "${LG_YELLOW}╠══════════════════════════════════════════════════════════╣${LG_NC}" >&2
            echo -e "${LG_YELLOW}║  この端末はまだ管理者に承認されていません。                 ║${LG_NC}" >&2
            echo -e "${LG_YELLOW}║                                                          ║${LG_NC}" >&2
            echo -e "${LG_YELLOW}║  手順:                                                   ║${LG_NC}" >&2
            echo -e "${LG_YELLOW}║  1. 管理者に以下の端末IDを伝えてください:                  ║${LG_NC}" >&2
            echo -e "${LG_YELLOW}║     端末ID: ${machine_hash}                                   ║${LG_NC}" >&2
            echo -e "${LG_YELLOW}║  2. 管理者が管理画面から承認すると自動的に使えます          ║${LG_NC}" >&2
            echo -e "${LG_YELLOW}║  3. 承認後: ./soloptilink \"CRM作って\"                    ║${LG_NC}" >&2
            echo -e "${LG_YELLOW}║     ステータス確認: ./soloptilink --status               ║${LG_NC}" >&2
            echo -e "${LG_YELLOW}╚══════════════════════════════════════════════════════════╝${LG_NC}" >&2
            echo "" >&2
            return 1
            ;;
        REJECTED)
            echo -e "${LG_RED}[LICENSE] この端末は管理者に拒否されています。${LG_NC}" >&2
            return 1
            ;;
        *)
            echo -e "${LG_YELLOW}[LICENSE] 端末登録: ステータス不明 (${status})${LG_NC}" >&2
            return 1
            ;;
    esac
}

# ============================================================
# セッショントークンによるサーバー認証（ランチャー経由時）
# Go launcher が発行したセッショントークンで端末認証する
# ライセンスキー不要 - 端末認証（デバイス承認）のみで動作
# ============================================================
_lg_server_auth_by_session() {
    local machine_hash="$1"
    local session_token="$2"
    local device_id="$3"
    local server_url="$4"

    local response
    response=$(curl -s -m 15 -X POST \
        "${server_url}/api/v1/license/terminal-auth" \
        -H "Content-Type: application/json" \
        -d "{\"machineHash\":\"${machine_hash}\",\"sessionToken\":\"${session_token}\",\"deviceId\":\"${device_id}\"}" \
        2>/dev/null)
    local curl_exit=$?

    if [[ "$curl_exit" -ne 0 ]] || [[ -z "$response" ]]; then
        echo -e "${LG_YELLOW}[LICENSE] セッショントークン認証: サーバー接続失敗（キャッシュにフォールバック）${LG_NC}" >&2
        return 1
    fi

    local approved
    approved=$(echo "$response" | grep -o '"approved":[a-z]*' | head -1 | cut -d: -f2)

    if [[ "$approved" != "true" ]]; then
        local reason
        reason=$(echo "$response" | grep -o '"reason":"[^"]*"' | head -1 | cut -d'"' -f4)
        case "$reason" in
            pending)
                echo -e "${LG_YELLOW}[LICENSE] この端末はまだ管理者に承認されていません${LG_NC}" >&2
                exit 1
                ;;
            rejected|suspended|revoked)
                # サーバー生値を日本語対訳に変換して表示（機械言語の顧客露出防止）
                local reason_ja
                case "$reason" in
                    rejected)  reason_ja="拒否" ;;
                    suspended) reason_ja="一時停止" ;;
                    revoked)   reason_ja="無効化" ;;
                esac
                echo -e "${LG_RED}[LICENSE] この端末は${reason_ja}されています。管理者にお問い合わせください${LG_NC}" >&2
                exit 1
                ;;
            *)
                # セッショントークン認証非対応の場合はフォールバック
                return 1
                ;;
        esac
    fi

    # 認証成功 → セッション保存
    local customer_id
    customer_id=$(echo "$response" | grep -o '"customerId":"[^"]*"' | head -1 | cut -d'"' -f4)
    local new_session_token
    new_session_token=$(echo "$response" | grep -o '"sessionToken":"[^"]*"' | head -1 | cut -d'"' -f4)
    local expires_at
    expires_at=$(echo "$response" | grep -o '"expiresAt":[0-9]*' | head -1 | cut -d: -f2)

    if [[ -n "$new_session_token" ]] && [[ -n "$expires_at" ]]; then
        _lg_save_session "$machine_hash" "$new_session_token" "$expires_at" "$customer_id"
    fi

    LG_CUSTOMER_ID="$customer_id"
    return 0
}

# ============================================================
# サーバー認証（毎回必須）
# ============================================================
_lg_server_auth() {
    local machine_hash="$1"
    local license_key="$2"
    local server_url="$3"

    local response
    response=$(curl -s -m 15 -X POST \
        "${server_url}/api/v1/license/terminal-auth" \
        -H "Content-Type: application/json" \
        -d "{\"machineHash\":\"${machine_hash}\",\"licenseKey\":\"${license_key}\"}" \
        2>/dev/null)
    local curl_exit=$?

    if [[ "$curl_exit" -ne 0 ]] || [[ -z "$response" ]]; then
        echo -e "${LG_RED}[LICENSE] 認証サーバーに接続できません${LG_NC}" >&2
        echo -e "${LG_YELLOW}  サーバー: ${server_url}${LG_NC}" >&2
        echo -e "${LG_YELLOW}  オフライン使用はセキュリティポリシーによりサポートされていません${LG_NC}" >&2
        return 1
    fi

    local approved
    approved=$(echo "$response" | grep -o '"approved":[a-z]*' | head -1 | cut -d: -f2)
    local reason
    reason=$(echo "$response" | grep -o '"reason":"[^"]*"' | head -1 | cut -d'"' -f4)

    if [[ "$approved" != "true" ]]; then
        case "$reason" in
            not_registered)
                echo -e "${LG_YELLOW}[LICENSE] この端末はまだ登録されていません。登録を開始します...${LG_NC}" >&2
                _lg_register_terminal "$machine_hash" "$license_key" "$server_url"
                return $?
                ;;
            pending)
                local machine_hash_display
                machine_hash_display=$(_lg_machine_hash)
                echo "" >&2
                echo -e "${LG_YELLOW}╔══════════════════════════════════════════════════════════╗${LG_NC}" >&2
                echo -e "${LG_YELLOW}║           🔐 端末承認が必要です                            ║${LG_NC}" >&2
                echo -e "${LG_YELLOW}╠══════════════════════════════════════════════════════════╣${LG_NC}" >&2
                echo -e "${LG_YELLOW}║  この端末はまだ管理者に承認されていません。                 ║${LG_NC}" >&2
                echo -e "${LG_YELLOW}║                                                          ║${LG_NC}" >&2
                echo -e "${LG_YELLOW}║  手順:                                                   ║${LG_NC}" >&2
                echo -e "${LG_YELLOW}║  1. 管理者に以下の端末IDを伝えてください:                  ║${LG_NC}" >&2
                echo -e "${LG_YELLOW}║     端末ID: ${machine_hash_display}                                   ║${LG_NC}" >&2
                echo -e "${LG_YELLOW}║  2. 管理者が管理画面から承認すると自動的に使えます          ║${LG_NC}" >&2
                echo -e "${LG_YELLOW}║  3. 承認後: ./soloptilink \"CRM作って\"                    ║${LG_NC}" >&2
                echo -e "${LG_YELLOW}║     ステータス確認: ./soloptilink --status               ║${LG_NC}" >&2
                echo -e "${LG_YELLOW}╚══════════════════════════════════════════════════════════╝${LG_NC}" >&2
                echo "" >&2
                return 1
                ;;
            rejected)
                echo -e "${LG_RED}[LICENSE] この端末は管理者に拒否されています。${LG_NC}" >&2
                return 1
                ;;
            suspended)
                echo -e "${LG_RED}[LICENSE] この端末は一時停止されています。${LG_NC}" >&2
                return 1
                ;;
            key_mismatch)
                echo -e "${LG_RED}[LICENSE] ライセンスキーが登録時と異なります。${LG_NC}" >&2
                return 1
                ;;
            *)
                local message
                message=$(echo "$response" | grep -o '"message":"[^"]*"' | head -1 | cut -d'"' -f4)
                echo -e "${LG_RED}[LICENSE] 認証失敗: ${message:-不明なエラー}${LG_NC}" >&2
                return 1
                ;;
        esac
    fi

    # 認証成功 → セッション保存
    local customer_id
    customer_id=$(echo "$response" | grep -o '"customerId":"[^"]*"' | head -1 | cut -d'"' -f4)
    local session_token
    session_token=$(echo "$response" | grep -o '"sessionToken":"[^"]*"' | head -1 | cut -d'"' -f4)
    local expires_at
    expires_at=$(echo "$response" | grep -o '"expiresAt":[0-9]*' | head -1 | cut -d: -f2)

    if [[ -n "$session_token" ]] && [[ -n "$expires_at" ]]; then
        _lg_save_session "$machine_hash" "$session_token" "$expires_at" "$customer_id"
    fi

    LG_CUSTOMER_ID="$customer_id"
    return 0
}

# ============================================================
# メイン認証関数（chain.sh から呼ばれる）
# ============================================================
lg_check_license() {
    # Step 1: curl 必須チェック
    if ! command -v curl &>/dev/null; then
        echo -e "${LG_RED}[LICENSE] curl が見つかりません。インストールしてください。${LG_NC}" >&2
        return 1
    fi

    # Step 1.5: ランチャー認証済みチェック（端末認証承認済みならライセンスキー不要）
    # Go launcher が SOLOPTILINK_LICENSED=true を設定 + セッショントークンを渡す
    if [[ "${SOLOPTILINK_LICENSED:-}" == "true" ]]; then
        local launcher_token="${SOLOPTILINK_SESSION_TOKEN:-}"
        local launcher_device_id="${SOLOPTILINK_DEVICE_ID:-}"

        if [[ -n "$launcher_token" ]] && [[ -n "$launcher_device_id" ]]; then
            # ランチャーのセッショントークンでサーバー認証
            local machine_hash
            machine_hash=$(_lg_machine_hash)

            # セッションキャッシュ確認（1時間以内なら高速パス）
            if _lg_check_session_cache; then
                echo -e "  ${LG_GREEN}✓ 端末認証済み（${LG_CUSTOMER_ID:-デバイス承認済み}）${LG_NC}" >&2
                return 0
            fi

            # セッショントークンでサーバー認証
            local server_url
            server_url=$(_lg_server_url)
            echo -e "  ${LG_CYAN}端末認証中（セッショントークン）... (${server_url})${LG_NC}" >&2

            if _lg_server_auth_by_session "$machine_hash" "$launcher_token" "$launcher_device_id" "$server_url"; then
                echo -e "  ${LG_GREEN}✓ 端末認証完了（デバイス承認済み）${LG_NC}" >&2
                return 0
            fi
            # セッショントークン認証失敗時はフォールバック（license.keyがあれば使う）
        fi

        # セッショントークンなし: license.json を直接チェック
        local launcher_license="${HOME}/.soloptilink/license.json"
        if [[ -f "$launcher_license" ]]; then
            local token_status
            # v2034.7-fix(SLB-004): Go ランチャーが書く license.json は整形 JSON
            # （'"status": "approved"' のようにコロン後にスペース）。旧パターン
            # '"status":"[^"]*"' はスペース無し前提でマッチせず、承認済み端末でも
            # license.json フォールバック認証が失敗していた。[[:space:]]* を挟んで
            # 整形・非整形どちらの JSON も解釈する。
            token_status=$(grep -o '"status"[[:space:]]*:[[:space:]]*"[^"]*"' "$launcher_license" 2>/dev/null | head -1 | cut -d'"' -f4)
            local expires_at_str
            expires_at_str=$(grep -o '"expires_at"[[:space:]]*:[[:space:]]*"[^"]*"' "$launcher_license" 2>/dev/null | head -1 | cut -d'"' -f4)

            if [[ "$token_status" == "approved" ]] && [[ -n "$expires_at_str" ]]; then
                # トークン有効期限チェック
                local expires_epoch=0
                # RFC3339形式の日付をエポック秒に変換
                if command -v date &>/dev/null; then
                    # macOS対応: -j -f フォーマット
                    local date_part="${expires_at_str%%T*}"
                    local time_part="${expires_at_str#*T}"
                    time_part="${time_part%%[Z+-]*}"
                    expires_epoch=$(date -j -f "%Y-%m-%d %H:%M:%S" "${date_part} ${time_part}" '+%s' 2>/dev/null || \
                                   date -d "$expires_at_str" '+%s' 2>/dev/null || echo "0")
                fi
                local now
                now=$(date '+%s')
                if [[ "$expires_epoch" -gt 0 ]] && [[ "$now" -lt "$expires_epoch" ]]; then
                    echo -e "  ${LG_GREEN}✓ 端末認証済み（デバイス承認済み）${LG_NC}" >&2
                    return 0
                fi
            fi
        fi
    fi

    # Step 2: ライセンスキーファイル確認（従来フロー）
    if [[ ! -f "$LG_LICENSE_FILE" ]]; then
        echo "" >&2
        echo -e "${LG_RED}╔═══════════════════════════════════════════════════════╗${LG_NC}" >&2
        echo -e "${LG_RED}║  ライセンスキーが設定されていません                   ║${LG_NC}" >&2
        echo -e "${LG_RED}╚═══════════════════════════════════════════════════════╝${LG_NC}" >&2
        echo "" >&2
        echo -e "  ${LG_CYAN}アクティベーション: ./soloptilink --activate${LG_NC}" >&2
        echo -e "  ${LG_CYAN}ステータス確認:     ./soloptilink --status${LG_NC}" >&2
        echo -e "  ${LG_CYAN}サポート窓口:       support@soloptilink.com${LG_NC}" >&2
        echo "" >&2
        return 1
    fi

    local license_key
    license_key=$(cat "$LG_LICENSE_FILE" 2>/dev/null | tr -d '[:space:]')
    if [[ -z "$license_key" ]]; then
        echo -e "${LG_RED}[LICENSE] ライセンスファイルが空です${LG_NC}" >&2
        return 1
    fi

    # Step 3: マシンハッシュ取得
    local machine_hash
    machine_hash=$(_lg_machine_hash)

    # Step 4: セッションキャッシュ確認（1時間以内なら高速パス）
    if _lg_check_session_cache; then
        echo -e "  ${LG_GREEN}✓ 端末認証済み（${LG_CUSTOMER_ID:-認証済み}）${LG_NC}" >&2
        return 0
    fi

    # Step 5: サーバー認証（必須・バイパス不可）
    local server_url
    server_url=$(_lg_server_url)
    echo -e "  ${LG_CYAN}端末認証中... (${server_url})${LG_NC}" >&2

    if ! _lg_server_auth "$machine_hash" "$license_key" "$server_url"; then
        # 未承認端末・認証失敗は即時強制終了（バイパス不可）
        exit 1
    fi

    echo -e "  ${LG_GREEN}✓ 端末認証完了（${LG_CUSTOMER_ID:-認証済み}）${LG_NC}" >&2
    return 0
}

# ============================================================
# ライセンスキー登録（setup.sh から呼ばれる）
# ============================================================
lg_register_license() {
    local key="$1"

    if [[ -z "$key" ]]; then
        echo -e "${LG_RED}[LICENSE] ライセンスキーを指定してください${LG_NC}" >&2
        return 1
    fi

    # v2.0形式（マシンハッシュ付き）必須
    if ! [[ "$key" =~ ^SLA-(TRIAL|STD|PRO|ENT)-([A-Za-z0-9_]+)-([a-f0-9]{4,8})-([0-9]{8})-([a-f0-9]{8})$ ]]; then
        echo -e "${LG_RED}[LICENSE] 無効なライセンスキー形式です${LG_NC}" >&2
        echo -e "${LG_RED}  v2.0形式のキーが必要です（管理者に発行を依頼してください）${LG_NC}" >&2
        return 1
    fi

    mkdir -p "$LG_LICENSE_DIR" 2>/dev/null
    chmod 700 "$LG_LICENSE_DIR" 2>/dev/null
    echo "$key" > "$LG_LICENSE_FILE"
    chmod 600 "$LG_LICENSE_FILE" 2>/dev/null

    echo -e "${LG_GREEN}[LICENSE] ライセンスキーを設定しました${LG_NC}" >&2
    echo -e "${LG_YELLOW}  次回起動時にサーバーへの端末登録が行われます${LG_NC}" >&2
    return 0
}

# ============================================================
# サーバーURL設定
# ============================================================
lg_set_server_url() {
    local url="$1"
    if [[ -z "$url" ]]; then
        echo -e "${LG_RED}[LICENSE] URLを指定してください${LG_NC}" >&2
        return 1
    fi
    mkdir -p "$LG_LICENSE_DIR" 2>/dev/null
    echo "$url" > "${LG_LICENSE_DIR}/.server_url"
    chmod 600 "${LG_LICENSE_DIR}/.server_url" 2>/dev/null
    echo -e "${LG_GREEN}[LICENSE] サーバーURLを設定しました: ${url}${LG_NC}" >&2
}

# ============================================================
# マシンハッシュ取得（管理者へのキー発行申請用）
# ============================================================
lg_get_machine_hash() {
    _lg_machine_hash
}

# ============================================================
# Module Registry 登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register "license-guard" "$LG_VERSION" "ライセンス認証ガード v3.0（端末認証必須）"
fi
true
