#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v281.0 - Monolith-First Generator
# =============================================================================
# モノリスファースト設計エンジン。プロジェクト規模を分析し、適切なアーキテクチャ
# （モノリス/モジュラーモノリス/マイクロサービス）を判定。将来の分割を見据えた
# モジュール境界定義と、整理されたモノリス構造を自動生成する。
#
# 機能一覧:
#   _mfg_analyze_scale       - 規模分析→アーキテクチャ判定
#   _mfg_generate_monolith   - モジュラーモノリス骨格生成
#   _mfg_generate_module_boundaries - モジュール境界定義
#   _mfg_inject_patterns     - Claudeプロンプトへのパターン注入
#
# 全globals: MFG_ prefix
# =============================================================================

[[ -n "${_MFG_LOADED:-}" ]] && return 0; _MFG_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g MFG_VERSION="281.0"
declare -g MFG_GENERATED=0
declare -g MFG_ERRORS=0
declare -g MFG_FILES_WRITTEN=0
declare -g MFG_ARCHITECTURE=""  # monolith | modular-monolith | microservices

# =============================================================================
# 初期化
# =============================================================================
mfg_init() {
    MFG_GENERATED=0
    MFG_ERRORS=0
    MFG_FILES_WRITTEN=0
    MFG_ARCHITECTURE=""
    return 0
}

# =============================================================================
# ユーティリティ
# =============================================================================
_mfg_write_file() {
    local filepath="$1"
    local content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then
        MFG_FILES_WRITTEN=$((MFG_FILES_WRITTEN + 1))
        echo "  [mfg] wrote: $filepath" >&2
    else
        MFG_ERRORS=$((MFG_ERRORS + 1))
    fi
}

_mfg_log() {
    echo -e "  ${GREEN:-\033[0;32m}[MFG]${NC:-\033[0m} $*" >&2
}

_mfg_warn() {
    echo -e "  ${YELLOW:-\033[0;33m}[MFG]${NC:-\033[0m} $*" >&2
}

# =============================================================================
# _mfg_analyze_scale - 規模分析→アーキテクチャ推奨
# =============================================================================
# 入力: プロジェクト記述、予想ユーザー数、チーム規模
# 出力: recommended architecture (monolith/modular-monolith/microservices)
_mfg_analyze_scale() {
    local project_desc="${1:-}"
    local expected_users="${2:-1000}"
    local team_size="${3:-3}"
    local domain_count="${4:-2}"

    _mfg_log "Analyzing project scale..."

    # 判定ロジック
    local score=0

    # ユーザー規模スコア
    if [[ $expected_users -gt 100000 ]]; then
        score=$((score + 30))
    elif [[ $expected_users -gt 10000 ]]; then
        score=$((score + 20))
    elif [[ $expected_users -gt 1000 ]]; then
        score=$((score + 10))
    fi

    # チーム規模スコア
    if [[ $team_size -gt 20 ]]; then
        score=$((score + 30))
    elif [[ $team_size -gt 8 ]]; then
        score=$((score + 20))
    elif [[ $team_size -gt 3 ]]; then
        score=$((score + 10))
    fi

    # ドメイン数スコア
    if [[ $domain_count -gt 8 ]]; then
        score=$((score + 30))
    elif [[ $domain_count -gt 4 ]]; then
        score=$((score + 20))
    elif [[ $domain_count -gt 2 ]]; then
        score=$((score + 10))
    fi

    # 判定
    if [[ $score -ge 60 ]]; then
        MFG_ARCHITECTURE="microservices"
        _mfg_log "Recommendation: Microservices (score=${score})"
    elif [[ $score -ge 30 ]]; then
        MFG_ARCHITECTURE="modular-monolith"
        _mfg_log "Recommendation: Modular Monolith (score=${score})"
    else
        MFG_ARCHITECTURE="monolith"
        _mfg_log "Recommendation: Monolith (score=${score})"
    fi

    # 分析レポート生成
    local report
    report=$(cat <<EOF
{
  "analysis": {
    "expectedUsers": ${expected_users},
    "teamSize": ${team_size},
    "domainCount": ${domain_count},
    "complexityScore": ${score}
  },
  "recommendation": "${MFG_ARCHITECTURE}",
  "rationale": {
    "monolith": "Simple deployment, single codebase, fast development for small teams",
    "modular-monolith": "Clear boundaries with shared deployment, best for medium teams",
    "microservices": "Independent scaling and deployment, suited for large teams with multiple domains"
  },
  "nextSteps": [
    "Define module boundaries based on domain analysis",
    "Generate project skeleton with recommended architecture",
    "Implement shared infrastructure (auth, logging, monitoring)"
  ]
}
EOF
)
    echo "$report"
    MFG_GENERATED=$((MFG_GENERATED + 1))
    return 0
}

# =============================================================================
# _mfg_generate_monolith - モジュラーモノリス骨格生成
# =============================================================================
_mfg_generate_monolith() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local project_name="${2:-app}"
    local modules="${3:-users,products,orders}"

    _mfg_log "Generating modular monolith structure..."

    # ディレクトリ構造生成
    local base_dir="${project_dir}/src"
    mkdir -p "${base_dir}/shared/lib" 2>/dev/null
    mkdir -p "${base_dir}/shared/middleware" 2>/dev/null
    mkdir -p "${base_dir}/shared/types" 2>/dev/null

    IFS=',' read -ra MODULE_LIST <<< "$modules"
    for mod in "${MODULE_LIST[@]}"; do
        mod=$(echo "$mod" | xargs)
        mkdir -p "${base_dir}/modules/${mod}/api" 2>/dev/null
        mkdir -p "${base_dir}/modules/${mod}/service" 2>/dev/null
        mkdir -p "${base_dir}/modules/${mod}/repository" 2>/dev/null
        mkdir -p "${base_dir}/modules/${mod}/types" 2>/dev/null
    done

    # 共有モジュール: module-loader.ts
    local loader_ts
    loader_ts=$(cat <<'LOADER'
// =============================================================================
// Modular Monolith - Module Loader
// Each module registers itself; the loader discovers and initializes them.
// =============================================================================
import { Router } from 'express';
import { PrismaClient } from '@prisma/client';

export interface AppModule {
  name: string;
  version: string;
  router: Router;
  initialize(prisma: PrismaClient): Promise<void>;
  healthCheck(): Promise<{ status: 'ok' | 'degraded' | 'error'; details?: string }>;
}

const modules: Map<string, AppModule> = new Map();

export function registerModule(mod: AppModule): void {
  if (modules.has(mod.name)) {
    throw new Error(`Module '${mod.name}' is already registered`);
  }
  modules.set(mod.name, mod);
  console.log(`[module-loader] Registered: ${mod.name} v${mod.version}`);
}

export async function initializeAllModules(prisma: PrismaClient): Promise<void> {
  for (const [name, mod] of modules) {
    try {
      await mod.initialize(prisma);
      console.log(`[module-loader] Initialized: ${name}`);
    } catch (err) {
      console.error(`[module-loader] Failed to initialize ${name}:`, err);
      throw err;
    }
  }
}

export function getAllRouters(): Array<{ path: string; router: Router }> {
  return Array.from(modules.entries()).map(([name, mod]) => ({
    path: `/api/${name}`,
    router: mod.router,
  }));
}

export async function healthCheckAll(): Promise<Record<string, { status: string; details?: string }>> {
  const results: Record<string, { status: string; details?: string }> = {};
  for (const [name, mod] of modules) {
    try {
      results[name] = await mod.healthCheck();
    } catch {
      results[name] = { status: 'error', details: 'Health check threw an exception' };
    }
  }
  return results;
}

export function getModule(name: string): AppModule | undefined {
  return modules.get(name);
}

export function listModules(): string[] {
  return Array.from(modules.keys());
}
LOADER
)
    _mfg_write_file "${base_dir}/shared/lib/module-loader.ts" "$loader_ts"

    # 共有: module-boundary.ts (境界を型で強制)
    local boundary_ts
    boundary_ts=$(cat <<'BOUNDARY'
// =============================================================================
// Module Boundary Enforcement
// Modules communicate ONLY through defined public interfaces.
// Direct imports across module boundaries are forbidden.
// =============================================================================

export interface ModulePublicApi {
  moduleName: string;
  queries: Record<string, (...args: any[]) => Promise<any>>;
  commands: Record<string, (...args: any[]) => Promise<any>>;
  events: string[];
}

const publicApis: Map<string, ModulePublicApi> = new Map();

export function exposePublicApi(api: ModulePublicApi): void {
  publicApis.set(api.moduleName, api);
}

export function getPublicApi(moduleName: string): ModulePublicApi {
  const api = publicApis.get(moduleName);
  if (!api) {
    throw new Error(`Module '${moduleName}' has no public API registered`);
  }
  return api;
}

export async function queryModule<T = unknown>(
  moduleName: string,
  queryName: string,
  ...args: unknown[]
): Promise<T> {
  const api = getPublicApi(moduleName);
  const queryFn = api.queries[queryName];
  if (!queryFn) {
    throw new Error(`Module '${moduleName}' has no query '${queryName}'`);
  }
  return queryFn(...args) as Promise<T>;
}

export async function commandModule<T = unknown>(
  moduleName: string,
  commandName: string,
  ...args: unknown[]
): Promise<T> {
  const api = getPublicApi(moduleName);
  const cmdFn = api.commands[commandName];
  if (!cmdFn) {
    throw new Error(`Module '${moduleName}' has no command '${commandName}'`);
  }
  return cmdFn(...args) as Promise<T>;
}
BOUNDARY
)
    _mfg_write_file "${base_dir}/shared/lib/module-boundary.ts" "$boundary_ts"

    # 共有: event-bus.ts (モジュール間イベント)
    local eventbus_ts
    eventbus_ts=$(cat <<'EVENTBUS'
// =============================================================================
// In-Process Event Bus for Modular Monolith
// Modules communicate via events to maintain loose coupling.
// When migrating to microservices, replace with distributed message broker.
// =============================================================================
import { EventEmitter } from 'events';

type EventHandler<T = unknown> = (payload: T) => void | Promise<void>;

class ModuleEventBus {
  private emitter = new EventEmitter();
  private handlers: Map<string, Set<string>> = new Map();

  constructor() {
    this.emitter.setMaxListeners(100);
  }

  on<T = unknown>(event: string, sourceModule: string, handler: EventHandler<T>): void {
    if (!this.handlers.has(event)) {
      this.handlers.set(event, new Set());
    }
    this.handlers.get(event)!.add(sourceModule);
    this.emitter.on(event, handler);
  }

  async emit<T = unknown>(event: string, payload: T): Promise<void> {
    this.emitter.emit(event, payload);
  }

  listSubscriptions(): Record<string, string[]> {
    const result: Record<string, string[]> = {};
    for (const [event, modules] of this.handlers) {
      result[event] = Array.from(modules);
    }
    return result;
  }

  removeAll(sourceModule: string): void {
    this.emitter.removeAllListeners();
    for (const [event, modules] of this.handlers) {
      modules.delete(sourceModule);
    }
  }
}

export const eventBus = new ModuleEventBus();
EVENTBUS
)
    _mfg_write_file "${base_dir}/shared/lib/event-bus.ts" "$eventbus_ts"

    # サンプルモジュール生成 (最初のモジュールのみ)
    local first_module="${MODULE_LIST[0]}"
    first_module=$(echo "$first_module" | xargs)

    local sample_index
    sample_index=$(cat <<SAMPLEEOF
// =============================================================================
// Module: ${first_module}
// Auto-generated modular monolith module
// =============================================================================
import { Router } from 'express';
import { PrismaClient } from '@prisma/client';
import { registerModule, AppModule } from '@/shared/lib/module-loader';
import { exposePublicApi } from '@/shared/lib/module-boundary';
import { eventBus } from '@/shared/lib/event-bus';

let prisma: PrismaClient;
const router = Router();

// --- API Routes ---
router.get('/', async (req, res) => {
  try {
    const items = await prisma.\$queryRaw\`SELECT 1\`;
    res.json({ module: '${first_module}', status: 'ok' });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// --- Module Definition ---
const ${first_module}Module: AppModule = {
  name: '${first_module}',
  version: '1.0.0',
  router,
  async initialize(p: PrismaClient) {
    prisma = p;
    // Register event handlers
    eventBus.on('app.started', '${first_module}', () => {
      console.log('[${first_module}] Module ready');
    });
  },
  async healthCheck() {
    try {
      await prisma.\$queryRaw\`SELECT 1\`;
      return { status: 'ok' };
    } catch {
      return { status: 'error', details: 'Database connection failed' };
    }
  },
};

// --- Public API ---
exposePublicApi({
  moduleName: '${first_module}',
  queries: {},
  commands: {},
  events: ['${first_module}.created', '${first_module}.updated', '${first_module}.deleted'],
});

// --- Register ---
registerModule(${first_module}Module);
export default ${first_module}Module;
SAMPLEEOF
)
    _mfg_write_file "${base_dir}/modules/${first_module}/index.ts" "$sample_index"

    MFG_GENERATED=$((MFG_GENERATED + 1))
    _mfg_log "Monolith structure generated (${#MODULE_LIST[@]} modules)"
    return 0
}

# =============================================================================
# _mfg_generate_module_boundaries - モジュール境界定義
# =============================================================================
_mfg_generate_module_boundaries() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local domain_desc="${2:-}"

    _mfg_log "Generating module boundary definitions..."

    local boundaries_ts
    boundaries_ts=$(cat <<'MBEOF'
// =============================================================================
// Module Boundary Configuration
// Defines which modules can communicate and through which interfaces.
// Enforced at build time via ESLint rules and at runtime via the event bus.
// =============================================================================

export interface ModuleBoundary {
  name: string;
  description: string;
  owns: string[];           // Prisma models owned by this module
  exposes: string[];         // Public API endpoints
  consumes: string[];        // Events this module listens to
  produces: string[];        // Events this module emits
  allowedDependencies: string[]; // Modules this can import from
}

export const MODULE_BOUNDARIES: ModuleBoundary[] = [
  {
    name: 'users',
    description: 'User management, authentication, profiles',
    owns: ['User', 'UserProfile', 'Session'],
    exposes: ['/api/users', '/api/auth'],
    consumes: ['order.completed', 'subscription.changed'],
    produces: ['user.created', 'user.updated', 'user.deleted', 'user.login'],
    allowedDependencies: [],
  },
  {
    name: 'products',
    description: 'Product catalog, categories, inventory',
    owns: ['Product', 'Category', 'Inventory'],
    exposes: ['/api/products', '/api/categories'],
    consumes: ['order.completed'],
    produces: ['product.created', 'product.updated', 'inventory.low'],
    allowedDependencies: [],
  },
  {
    name: 'orders',
    description: 'Order processing, cart, checkout',
    owns: ['Order', 'OrderItem', 'Cart'],
    exposes: ['/api/orders', '/api/cart'],
    consumes: ['user.created', 'product.updated', 'payment.succeeded', 'payment.failed'],
    produces: ['order.created', 'order.completed', 'order.cancelled'],
    allowedDependencies: ['users', 'products'],
  },
  {
    name: 'payments',
    description: 'Payment processing, invoicing',
    owns: ['Payment', 'Invoice', 'Refund'],
    exposes: ['/api/payments', '/api/invoices'],
    consumes: ['order.created'],
    produces: ['payment.succeeded', 'payment.failed', 'refund.processed'],
    allowedDependencies: ['users', 'orders'],
  },
  {
    name: 'notifications',
    description: 'Email, push, in-app notifications',
    owns: ['Notification', 'NotificationPreference'],
    exposes: ['/api/notifications'],
    consumes: ['user.created', 'order.completed', 'payment.succeeded', 'payment.failed'],
    produces: ['notification.sent', 'notification.failed'],
    allowedDependencies: ['users'],
  },
];

// --- Boundary Validation ---
export function validateDependency(source: string, target: string): boolean {
  const boundary = MODULE_BOUNDARIES.find((b) => b.name === source);
  if (!boundary) return false;
  return boundary.allowedDependencies.includes(target);
}

export function getModuleBoundary(name: string): ModuleBoundary | undefined {
  return MODULE_BOUNDARIES.find((b) => b.name === name);
}

export function detectBoundaryViolations(
  imports: Array<{ source: string; target: string }>
): Array<{ source: string; target: string; reason: string }> {
  const violations: Array<{ source: string; target: string; reason: string }> = [];

  for (const imp of imports) {
    if (imp.source === imp.target) continue;
    if (!validateDependency(imp.source, imp.target)) {
      violations.push({
        ...imp,
        reason: `Module '${imp.source}' is not allowed to depend on '${imp.target}'`,
      });
    }
  }
  return violations;
}
MBEOF
)
    _mfg_write_file "${project_dir}/src/shared/config/module-boundaries.ts" "$boundaries_ts"

    # ESLint boundary enforcement rule
    local eslint_rule
    eslint_rule=$(cat <<'ESLINTEOF'
// =============================================================================
// ESLint Rule: no-cross-module-import
// Prevents direct imports across module boundaries.
// Modules must use the public API (module-boundary.ts) to communicate.
// =============================================================================
module.exports = {
  meta: {
    type: 'problem',
    docs: {
      description: 'Disallow direct imports across module boundaries',
    },
    messages: {
      noCrossModule: "Direct import from '{{target}}' module is not allowed in '{{source}}'. Use the public API via module-boundary.ts.",
    },
  },
  create(context) {
    const filename = context.getFilename();
    const moduleMatch = filename.match(/modules\/([^/]+)\//);
    if (!moduleMatch) return {};

    const currentModule = moduleMatch[1];

    return {
      ImportDeclaration(node) {
        const importPath = node.source.value;
        const targetMatch = importPath.match(/modules\/([^/]+)/);
        if (!targetMatch) return;

        const targetModule = targetMatch[1];
        if (targetModule !== currentModule) {
          context.report({
            node,
            messageId: 'noCrossModule',
            data: { source: currentModule, target: targetModule },
          });
        }
      },
    };
  },
};
ESLINTEOF
)
    _mfg_write_file "${project_dir}/eslint-rules/no-cross-module-import.js" "$eslint_rule"

    MFG_GENERATED=$((MFG_GENERATED + 1))
    _mfg_log "Module boundaries defined"
    return 0
}

# =============================================================================
# _mfg_inject_patterns - Claudeプロンプトへのパターン注入
# =============================================================================
_mfg_inject_patterns() {
    local prompt="${1:-}"

    cat <<'INJECT'

## [Monolith-First] モジュラーモノリス必須パターン

### アーキテクチャ原則:
- **モノリスファースト**: 最初はモノリスで構築し、必要に応じて分割
- **モジュール境界**: 各ドメインはsrc/modules/配下に独立ディレクトリ
- **公開API**: モジュール間通信はmodule-boundary.tsのqueryModule/commandModule経由
- **直接import禁止**: 他モジュールのinternal実装を直接importしない
- **イベント駆動**: モジュール間の疎結合はevent-bus.ts経由のイベントで実現

### ディレクトリ構造:
```
src/
  modules/
    users/          # ユーザードメイン
      api/          # APIルート
      service/      # ビジネスロジック
      repository/   # データアクセス
      types/        # 型定義
      index.ts      # モジュールエントリーポイント
    products/       # 商品ドメイン
    orders/         # 注文ドメイン
  shared/
    lib/            # 共有ライブラリ
    middleware/     # 共有ミドルウェア
    types/          # 共有型定義
```

### 分割判断基準:
- ユーザー >100K && チーム >8人 → マイクロサービス検討
- それ以外 → モジュラーモノリスで十分

INJECT

    echo "$prompt"
}

# =============================================================================
# メイン統合実行
# =============================================================================
mfg_generate_all() {
    local project_dir="${PROJECT_DIR:-./output}"
    _mfg_log "Starting monolith-first generation..."

    _mfg_analyze_scale "" "5000" "5" "3" > /dev/null
    _mfg_generate_monolith "$project_dir" "app" "users,products,orders"
    _mfg_generate_module_boundaries "$project_dir"

    _mfg_log "Monolith-first generation complete (${MFG_GENERATED} artifacts)"
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
mfg_report() {
    echo -e "\n  ${BOLD:-}=== monolith-first-generator v${MFG_VERSION} ===${NC:-}"
    echo -e "  Architecture: ${MFG_ARCHITECTURE:-not analyzed}"
    echo -e "  生成数: ${MFG_GENERATED}"
    echo -e "  書込数: ${MFG_FILES_WRITTEN}"
    echo -e "  エラー: ${MFG_ERRORS}"
}

mfg_score() {
    if [[ ${MFG_GENERATED} -ge 3 ]] && [[ ${MFG_ERRORS} -eq 0 ]]; then
        echo "95"
    elif [[ ${MFG_GENERATED} -gt 0 ]] && [[ ${MFG_ERRORS} -eq 0 ]]; then
        echo "85"
    elif [[ ${MFG_GENERATED} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "monolith-first-generator" --version "${MFG_VERSION}" \
        --description "モノリスファースト設計×モジュール境界×アーキテクチャ判定" \
        --init "mfg_init" --report "mfg_report" --score "mfg_score" \
        --enable-var "ENABLE_MONOLITH_FIRST" --cli-flags "--monolith-first:--no-monolith-first"
fi

# v2003.1: source時のexit codeを確実に0にする
true
