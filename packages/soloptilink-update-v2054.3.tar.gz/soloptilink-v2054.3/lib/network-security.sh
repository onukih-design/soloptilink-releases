#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v334.0 - Network Security Engine
# =============================================================================
# VPC設計、セキュリティグループ、WAFルール自動生成。
#
# Functions:
#   _ns_init()                     - Initialize
#   _ns_generate_vpc()             - Generate VPC with subnets
#   _ns_generate_security_groups() - Generate security group rules
#   _ns_generate_waf()             - Generate WAF rules
#   _ns_report() / _ns_score()
# =============================================================================

[[ -n "${_NS_LOADED:-}" ]] && return 0; _NS_LOADED=1

readonly _NS_RED='\033[0;31m'
readonly _NS_GREEN='\033[0;32m'
readonly _NS_YELLOW='\033[0;33m'
readonly _NS_CYAN='\033[0;36m'
readonly _NS_NC='\033[0m'

declare -g NS_VERSION="334.0"
NS_GENERATED=0
NS_ERRORS=0
NS_FILES_WRITTEN=0
NS_VPC_OK=false
NS_SG_OK=false
NS_WAF_OK=false

_ns_init() {
    NS_GENERATED=0; NS_ERRORS=0; NS_FILES_WRITTEN=0
    NS_VPC_OK=false; NS_SG_OK=false; NS_WAF_OK=false
    echo -e "  ${_NS_GREEN}OK${_NS_NC} Network Security v${NS_VERSION}" >&2
    return 0
}

_ns_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { NS_FILES_WRITTEN=$((NS_FILES_WRITTEN + 1)); return 0; }
    NS_ERRORS=$((NS_ERRORS + 1)); return 1
}

_ns_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_NS_CYAN}[netsec]${_NS_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_NS_GREEN}[netsec]${_NS_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_NS_YELLOW}[netsec]${_NS_NC} $msg" >&2 ;;
        error) echo -e "  ${_NS_RED}[netsec]${_NS_NC} $msg" >&2 ;;
    esac
}

# =============================================================================
# Generate VPC
# =============================================================================
_ns_generate_vpc() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local net_dir="${project_dir}/infra/network"

    _ns_log info "Generating VPC configuration..."

    _ns_write_file "${net_dir}/vpc.tf" 'module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "~> 5.0"

  name = "${var.project_name}-vpc"
  cidr = "10.0.0.0/16"

  azs             = ["${var.region}a", "${var.region}c"]
  private_subnets = ["10.0.1.0/24", "10.0.2.0/24"]
  public_subnets  = ["10.0.101.0/24", "10.0.102.0/24"]

  enable_nat_gateway   = true
  single_nat_gateway   = var.environment != "production"
  enable_dns_hostnames = true
  enable_dns_support   = true

  # VPC Flow Logs
  enable_flow_log                      = true
  create_flow_log_cloudwatch_log_group = true
  create_flow_log_iam_role             = true
  flow_log_max_aggregation_interval    = 60

  tags = {
    Environment = var.environment
  }

  public_subnet_tags = {
    "kubernetes.io/role/elb" = "1"
  }

  private_subnet_tags = {
    "kubernetes.io/role/internal-elb" = "1"
  }
}

# VPC Endpoints for private access to AWS services
resource "aws_vpc_endpoint" "s3" {
  vpc_id       = module.vpc.vpc_id
  service_name = "com.amazonaws.${var.region}.s3"
  vpc_endpoint_type = "Gateway"
  route_table_ids   = module.vpc.private_route_table_ids
}

resource "aws_vpc_endpoint" "ecr_api" {
  vpc_id              = module.vpc.vpc_id
  service_name        = "com.amazonaws.${var.region}.ecr.api"
  vpc_endpoint_type   = "Interface"
  subnet_ids          = module.vpc.private_subnets
  security_group_ids  = [aws_security_group.vpc_endpoints.id]
  private_dns_enabled = true
}

resource "aws_vpc_endpoint" "secrets_manager" {
  vpc_id              = module.vpc.vpc_id
  service_name        = "com.amazonaws.${var.region}.secretsmanager"
  vpc_endpoint_type   = "Interface"
  subnet_ids          = module.vpc.private_subnets
  security_group_ids  = [aws_security_group.vpc_endpoints.id]
  private_dns_enabled = true
}
'

    _ns_log ok "VPC configuration generated"
    NS_VPC_OK=true
    NS_GENERATED=$((NS_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate Security Groups
# =============================================================================
_ns_generate_security_groups() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local net_dir="${project_dir}/infra/network"

    _ns_log info "Generating security groups..."

    _ns_write_file "${net_dir}/security-groups.tf" 'resource "aws_security_group" "alb" {
  name_prefix = "${var.project_name}-alb-"
  vpc_id      = module.vpc.vpc_id
  description = "ALB security group"

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
    description = "HTTPS from internet"
  }

  ingress {
    from_port   = 80
    to_port     = 80
    protocol    = "tcp"
    cidr_blocks = ["0.0.0.0/0"]
    description = "HTTP (redirect to HTTPS)"
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  lifecycle { create_before_destroy = true }
}

resource "aws_security_group" "app" {
  name_prefix = "${var.project_name}-app-"
  vpc_id      = module.vpc.vpc_id
  description = "Application security group"

  ingress {
    from_port       = 3000
    to_port         = 3000
    protocol        = "tcp"
    security_groups = [aws_security_group.alb.id]
    description     = "From ALB only"
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
    description = "All outbound"
  }

  lifecycle { create_before_destroy = true }
}

resource "aws_security_group" "database" {
  name_prefix = "${var.project_name}-db-"
  vpc_id      = module.vpc.vpc_id
  description = "Database security group"

  ingress {
    from_port       = 5432
    to_port         = 5432
    protocol        = "tcp"
    security_groups = [aws_security_group.app.id]
    description     = "PostgreSQL from app only"
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  lifecycle { create_before_destroy = true }
}

resource "aws_security_group" "redis" {
  name_prefix = "${var.project_name}-redis-"
  vpc_id      = module.vpc.vpc_id
  description = "Redis security group"

  ingress {
    from_port       = 6379
    to_port         = 6379
    protocol        = "tcp"
    security_groups = [aws_security_group.app.id]
    description     = "Redis from app only"
  }

  lifecycle { create_before_destroy = true }
}

resource "aws_security_group" "vpc_endpoints" {
  name_prefix = "${var.project_name}-vpce-"
  vpc_id      = module.vpc.vpc_id
  description = "VPC Endpoints"

  ingress {
    from_port   = 443
    to_port     = 443
    protocol    = "tcp"
    cidr_blocks = [module.vpc.vpc_cidr_block]
  }
}
'

    _ns_log ok "Security groups generated"
    NS_SG_OK=true
    NS_GENERATED=$((NS_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate WAF Rules
# =============================================================================
_ns_generate_waf() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local net_dir="${project_dir}/infra/network"

    _ns_log info "Generating WAF rules..."

    _ns_write_file "${net_dir}/waf.tf" 'resource "aws_wafv2_web_acl" "main" {
  name        = "${var.project_name}-waf"
  scope       = "REGIONAL"
  description = "WAF for ${var.project_name}"

  default_action { allow {} }

  # Rate limiting
  rule {
    name     = "rate-limit"
    priority = 1
    action { block {} }
    statement {
      rate_based_statement {
        limit              = 2000
        aggregate_key_type = "IP"
      }
    }
    visibility_config {
      sampled_requests_enabled   = true
      cloudwatch_metrics_enabled = true
      metric_name                = "RateLimit"
    }
  }

  # AWS Managed Rules - Common
  rule {
    name     = "aws-common"
    priority = 2
    override_action { none {} }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesCommonRuleSet"
        vendor_name = "AWS"
      }
    }
    visibility_config {
      sampled_requests_enabled   = true
      cloudwatch_metrics_enabled = true
      metric_name                = "AWSCommon"
    }
  }

  # SQL Injection protection
  rule {
    name     = "sql-injection"
    priority = 3
    override_action { none {} }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesSQLiRuleSet"
        vendor_name = "AWS"
      }
    }
    visibility_config {
      sampled_requests_enabled   = true
      cloudwatch_metrics_enabled = true
      metric_name                = "SQLInjection"
    }
  }

  # Known bad inputs
  rule {
    name     = "known-bad-inputs"
    priority = 4
    override_action { none {} }
    statement {
      managed_rule_group_statement {
        name        = "AWSManagedRulesKnownBadInputsRuleSet"
        vendor_name = "AWS"
      }
    }
    visibility_config {
      sampled_requests_enabled   = true
      cloudwatch_metrics_enabled = true
      metric_name                = "KnownBadInputs"
    }
  }

  visibility_config {
    sampled_requests_enabled   = true
    cloudwatch_metrics_enabled = true
    metric_name                = "WAF"
  }
}

resource "aws_wafv2_web_acl_association" "alb" {
  resource_arn = var.alb_arn
  web_acl_arn  = aws_wafv2_web_acl.main.arn
}
'

    _ns_log ok "WAF rules generated"
    NS_WAF_OK=true
    NS_GENERATED=$((NS_GENERATED + 1))
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_ns_report() {
    echo -e "\n  ${_NS_CYAN}=== Network Security v${NS_VERSION} ===${_NS_NC}"
    echo -e "  Generated: ${NS_GENERATED} | Files: ${NS_FILES_WRITTEN} | Errors: ${NS_ERRORS}"
    echo -e "  VPC: $( ${NS_VPC_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Security Groups: $( ${NS_SG_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  WAF: $( ${NS_WAF_OK} && echo 'OK' || echo 'SKIP')"
}

_ns_score() {
    local score=50
    ${NS_VPC_OK} && score=$((score + 15))
    ${NS_SG_OK} && score=$((score + 15))
    ${NS_WAF_OK} && score=$((score + 15))
    [[ ${NS_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "network-security" --version "334.0" \
        --description "ネットワークセキュリティ VPC/SG/WAF (v334)" \
        --init "_ns_init" --report "_ns_report" --score "_ns_score" \
        --enable-var "ENABLE_NETWORK_SECURITY" --cli-flags "--network-security:--no-network-security"
fi

# v2003.1: source時のexit codeを確実に0にする
true
