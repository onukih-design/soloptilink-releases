#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v363.0 - API Rate Limit Tester
# =============================================================================
# レート制限テスト×ヘッダー検証×レポート生成
#
# 機能:
#   - レート制限の動作テスト（リクエスト送信→429検証）
#   - レスポンスヘッダー検証（X-RateLimit-Limit等）
#   - エンドポイント別レート制限テスト
#   - バースト耐性テスト
#   - テストレポート生成
#
# 全globals: ARLT_ prefix
# =============================================================================

[[ -n "${_ARLT_LOADED:-}" ]] && return 0; _ARLT_LOADED=1

ARLT_VERSION="363.0"
ARLT_GENERATED=0
ARLT_ERRORS=0
ARLT_PHASE="rate_limit_test"
ARLT_FILES_CREATED=()
ARLT_TESTS_RUN=0

: "${GREEN:=\033[0;32m}" ; : "${RED:=\033[0;31m}" ; : "${YELLOW:=\033[0;33m}"
: "${CYAN:=\033[0;36m}" ; : "${BOLD:=\033[1m}" ; : "${NC:=\033[0m}"

_arlt_log() { echo -e "  ${CYAN}[ARLT]${NC} $*"; }
_arlt_ok() { echo -e "  ${GREEN}[ARLT]${NC} $*"; }
_arlt_err() { echo -e "  ${RED}[ARLT]${NC} $*"; }

_arlt_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        ARLT_FILES_CREATED+=("$filepath")
        ARLT_GENERATED=$((ARLT_GENERATED + 1))
        _arlt_ok "Created: ${filepath##*/}"
    else
        ARLT_ERRORS=$((ARLT_ERRORS + 1))
        _arlt_err "Failed: ${filepath##*/}"
    fi
}

arlt_init() {
    ARLT_GENERATED=0; ARLT_ERRORS=0; ARLT_TESTS_RUN=0; ARLT_FILES_CREATED=()
    _arlt_log "API Rate Limit Tester v${ARLT_VERSION} initialized"
    return 0
}

# =============================================================================
# Test Rate Limits
# =============================================================================
_arlt_test_rate_limits() {
    local project_dir="${1:-.}"

    _arlt_log "Generating rate limit test suite..."

    local test_dir="${project_dir}/src/lib/rate-limit-tests"
    mkdir -p "$test_dir" 2>/dev/null

    _arlt_write_file "${test_dir}/rate-limit-tester.ts" "$(cat <<'TS'
interface RateLimitConfig {
  endpoint: string;
  method: 'GET' | 'POST' | 'PUT' | 'DELETE';
  maxRequests: number;
  windowMs: number;
  headers?: Record<string, string>;
}

interface TestResult {
  endpoint: string;
  totalRequests: number;
  successCount: number;
  rateLimitedCount: number;
  errorCount: number;
  firstLimitedAt: number | null;
  avgResponseTime: number;
  rateLimitHeaders: Record<string, string>;
  passed: boolean;
  details: string;
}

export async function testRateLimit(baseUrl: string, config: RateLimitConfig): Promise<TestResult> {
  const results: { status: number; time: number; headers: Record<string, string> }[] = [];
  const requestCount = Math.ceil(config.maxRequests * 1.5);

  for (let i = 0; i < requestCount; i++) {
    const start = Date.now();
    try {
      const res = await fetch(`${baseUrl}${config.endpoint}`, {
        method: config.method,
        headers: { 'Content-Type': 'application/json', ...config.headers },
      });
      const headers: Record<string, string> = {};
      res.headers.forEach((v, k) => { headers[k] = v; });
      results.push({ status: res.status, time: Date.now() - start, headers });
    } catch (e) {
      results.push({ status: 0, time: Date.now() - start, headers: {} });
    }
  }

  const successCount = results.filter(r => r.status >= 200 && r.status < 300).length;
  const rateLimitedCount = results.filter(r => r.status === 429).length;
  const errorCount = results.filter(r => r.status !== 429 && (r.status < 200 || r.status >= 300)).length;
  const firstLimitedIdx = results.findIndex(r => r.status === 429);
  const avgTime = results.reduce((s, r) => s + r.time, 0) / results.length;
  const lastHeaders = results[results.length - 1]?.headers || {};

  const rateLimitHeaders: Record<string, string> = {};
  for (const [k, v] of Object.entries(lastHeaders)) {
    if (k.toLowerCase().includes('ratelimit') || k.toLowerCase().includes('rate-limit') || k.toLowerCase() === 'retry-after') {
      rateLimitHeaders[k] = v;
    }
  }

  const passed = rateLimitedCount > 0 && successCount <= config.maxRequests + 2;

  return {
    endpoint: config.endpoint,
    totalRequests: requestCount,
    successCount,
    rateLimitedCount,
    errorCount,
    firstLimitedAt: firstLimitedIdx >= 0 ? firstLimitedIdx + 1 : null,
    avgResponseTime: Math.round(avgTime),
    rateLimitHeaders,
    passed,
    details: passed
      ? `Rate limit working: limited at request ${firstLimitedIdx + 1} (max: ${config.maxRequests})`
      : rateLimitedCount === 0
        ? 'Rate limiting not detected - no 429 responses received'
        : `Rate limit may be misconfigured: ${successCount} successful out of ${config.maxRequests} allowed`,
  };
}
TS
)"

    ARLT_TESTS_RUN=$((ARLT_TESTS_RUN + 1))
    _arlt_ok "Rate limit test suite generated"
}

# =============================================================================
# Verify Headers
# =============================================================================
_arlt_verify_headers() {
    local project_dir="${1:-.}"

    _arlt_log "Generating rate limit header verifier..."

    local test_dir="${project_dir}/src/lib/rate-limit-tests"
    mkdir -p "$test_dir" 2>/dev/null

    _arlt_write_file "${test_dir}/header-verifier.ts" "$(cat <<'TS'
interface HeaderVerification {
  header: string;
  present: boolean;
  value: string | null;
  valid: boolean;
  expected: string;
}

const REQUIRED_HEADERS = [
  { name: 'X-RateLimit-Limit', description: 'Maximum requests allowed in window' },
  { name: 'X-RateLimit-Remaining', description: 'Requests remaining in current window' },
  { name: 'X-RateLimit-Reset', description: 'Unix timestamp when window resets' },
];

const OPTIONAL_HEADERS = [
  { name: 'Retry-After', description: 'Seconds to wait before retrying (on 429)' },
  { name: 'X-RateLimit-Policy', description: 'Rate limit policy description' },
];

export function verifyRateLimitHeaders(headers: Record<string, string>, status: number): {
  passed: boolean;
  verifications: HeaderVerification[];
} {
  const verifications: HeaderVerification[] = [];

  for (const hdr of REQUIRED_HEADERS) {
    const value = findHeader(headers, hdr.name);
    const present = value !== null;
    const valid = present && !isNaN(Number(value));
    verifications.push({
      header: hdr.name, present, value, valid,
      expected: hdr.description,
    });
  }

  if (status === 429) {
    const retryAfter = findHeader(headers, 'Retry-After');
    verifications.push({
      header: 'Retry-After',
      present: retryAfter !== null,
      value: retryAfter,
      valid: retryAfter !== null && !isNaN(Number(retryAfter)),
      expected: 'Required on 429 responses',
    });
  }

  const passed = verifications.filter(v => v.header !== 'Retry-After' || status === 429)
    .every(v => v.present && v.valid);

  return { passed, verifications };
}

function findHeader(headers: Record<string, string>, name: string): string | null {
  const lower = name.toLowerCase();
  for (const [k, v] of Object.entries(headers)) {
    if (k.toLowerCase() === lower) return v;
  }
  return null;
}
TS
)"

    _arlt_ok "Rate limit header verifier generated"
}

# =============================================================================
# Generate Report
# =============================================================================
_arlt_generate_report() {
    local project_dir="${1:-.}"

    _arlt_log "Generating rate limit test report..."

    local test_dir="${project_dir}/src/lib/rate-limit-tests"
    mkdir -p "$test_dir" 2>/dev/null

    _arlt_write_file "${test_dir}/report.ts" "$(cat <<'TS'
interface RateLimitReport {
  timestamp: string;
  baseUrl: string;
  endpoints: {
    endpoint: string;
    passed: boolean;
    maxRequests: number;
    actualLimitAt: number | null;
    headersValid: boolean;
    avgResponseMs: number;
  }[];
  overallPassed: boolean;
  summary: string;
}

export function generateRateLimitReport(baseUrl: string, results: any[]): RateLimitReport {
  const endpoints = results.map(r => ({
    endpoint: r.endpoint,
    passed: r.passed,
    maxRequests: r.totalRequests,
    actualLimitAt: r.firstLimitedAt,
    headersValid: Object.keys(r.rateLimitHeaders).length >= 2,
    avgResponseMs: r.avgResponseTime,
  }));

  const overallPassed = endpoints.every(e => e.passed);

  return {
    timestamp: new Date().toISOString(),
    baseUrl,
    endpoints,
    overallPassed,
    summary: overallPassed
      ? `All ${endpoints.length} endpoints correctly enforce rate limits`
      : `${endpoints.filter(e => !e.passed).length}/${endpoints.length} endpoints have rate limit issues`,
  };
}
TS
)"

    _arlt_ok "Rate limit test report generated"
}

# =============================================================================
# Report / Score / Register
# =============================================================================
arlt_report() {
    echo -e "\n  ${BOLD}=== API Rate Limit Tester v${ARLT_VERSION} ===${NC}"
    echo -e "  生成ファイル数 : ${ARLT_GENERATED}"
    echo -e "  エラー         : ${ARLT_ERRORS}"
    echo -e "  テスト実行     : ${ARLT_TESTS_RUN}"
    if [[ ${#ARLT_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${ARLT_FILES_CREATED[@]}"; do echo -e "    - ${f}"; done
    fi
}

arlt_score() {
    if [[ ${ARLT_GENERATED} -ge 3 ]] && [[ ${ARLT_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${ARLT_GENERATED} -gt 0 ]] && [[ ${ARLT_ERRORS} -eq 0 ]]; then echo "90"
    elif [[ ${ARLT_GENERATED} -gt 0 ]]; then echo "70"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "api-rate-limit-tester" --version "363.0" \
        --description "レート制限テスト×ヘッダー検証×バースト耐性テスト" \
        --init "arlt_init" --report "arlt_report" --score "arlt_score" \
        --enable-var "ENABLE_RATE_LIMIT_TESTER" --cli-flags "--rate-limit-tester:--no-rate-limit-tester"
fi

# v2003.1: source時のexit codeを確実に0にする
true
