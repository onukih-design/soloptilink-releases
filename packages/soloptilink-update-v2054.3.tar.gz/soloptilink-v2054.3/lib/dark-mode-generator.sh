#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v241.0 - Dark Mode Generator
# =============================================================================
# CSS Variables ベースのテーマシステムを自動生成。
# light/dark テーマの切り替え、システム設定検出、トグルコンポーネント生成。
#
# 機能:
#   - CSS Custom Properties によるテーマシステム生成
#   - ダーク/ライト切替トグルコンポーネント生成
#   - カラーパレット自動生成（アクセシビリティ準拠コントラスト比）
#   - 既存コンポーネントのダークモード対応チェック
#
# 全globals: DMG_ prefix
# =============================================================================

[[ -n "${_DARK_MODE_GENERATOR_LOADED:-}" ]] && return 0
_DARK_MODE_GENERATOR_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g DMG_VERSION="241.0"
declare -g DMG_INITIALIZED=false
declare -g DMG_THEMES_GENERATED=0
declare -g DMG_TOGGLES_GENERATED=0
declare -g DMG_ISSUES_FOUND=0
declare -g DMG_ISSUES_FIXED=0
declare -g DMG_PROJECT_DIR=""
declare -g DMG_LOG_PREFIX="[DMG]"

# =============================================================================
# ログユーティリティ
# =============================================================================
_dmg_log() {
    echo -e "  ${CLR_CYAN:-\033[0;36m}${DMG_LOG_PREFIX}${CLR_NC:-\033[0m} $*" >&2
}

_dmg_success() {
    echo -e "  ${CLR_GREEN:-\033[0;32m}${DMG_LOG_PREFIX} OK${CLR_NC:-\033[0m} $*" >&2
}

_dmg_warn() {
    echo -e "  ${CLR_YELLOW:-\033[0;33m}${DMG_LOG_PREFIX} WARN${CLR_NC:-\033[0m} $*" >&2
}

_dmg_error() {
    echo -e "  ${CLR_RED:-\033[0;31m}${DMG_LOG_PREFIX} ERROR${CLR_NC:-\033[0m} $*" >&2
}

# =============================================================================
# 初期化
# =============================================================================
dmg_init() {
    DMG_INITIALIZED=true
    DMG_THEMES_GENERATED=0
    DMG_TOGGLES_GENERATED=0
    DMG_ISSUES_FOUND=0
    DMG_ISSUES_FIXED=0
    DMG_PROJECT_DIR="${PROJECT_DIR:-.}"
    return 0
}

# =============================================================================
# CSS Variables テーマシステム生成
# =============================================================================
# light/dark 両テーマの CSS Custom Properties を生成する。
# Tailwind CSS 互換、Next.js App Router 対応。
#
# 使い方: _dmg_generate_theme_system <output_dir>
# =============================================================================
_dmg_generate_theme_system() {
    local output_dir="${1:-${DMG_PROJECT_DIR}/styles}"
    local theme_file="${output_dir}/theme.css"

    [[ "$DMG_INITIALIZED" != "true" ]] && { _dmg_error "未初期化"; return 1; }

    _dmg_log "テーマシステム生成中: ${theme_file}"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$theme_file" <<'CSS_THEME'
/* =============================================================================
 * SoloptiLinkAI - CSS Variables Theme System (v241.0)
 * Light/Dark テーマ対応 CSS Custom Properties
 * ============================================================================= */

/* --- Light Theme (default) --- */
:root {
  /* Background */
  --color-bg-primary: #ffffff;
  --color-bg-secondary: #f9fafb;
  --color-bg-tertiary: #f3f4f6;
  --color-bg-elevated: #ffffff;
  --color-bg-overlay: rgba(0, 0, 0, 0.5);

  /* Foreground / Text */
  --color-text-primary: #111827;
  --color-text-secondary: #4b5563;
  --color-text-tertiary: #9ca3af;
  --color-text-inverse: #ffffff;
  --color-text-link: #2563eb;
  --color-text-link-hover: #1d4ed8;

  /* Border */
  --color-border-primary: #e5e7eb;
  --color-border-secondary: #d1d5db;
  --color-border-focus: #3b82f6;

  /* Brand / Accent */
  --color-accent-primary: #3b82f6;
  --color-accent-primary-hover: #2563eb;
  --color-accent-secondary: #8b5cf6;

  /* Semantic */
  --color-success: #10b981;
  --color-success-bg: #ecfdf5;
  --color-warning: #f59e0b;
  --color-warning-bg: #fffbeb;
  --color-error: #ef4444;
  --color-error-bg: #fef2f2;
  --color-info: #3b82f6;
  --color-info-bg: #eff6ff;

  /* Surface */
  --color-surface-card: #ffffff;
  --color-surface-card-hover: #f9fafb;
  --color-surface-input: #ffffff;
  --color-surface-input-disabled: #f3f4f6;

  /* Shadow */
  --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.05);
  --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1);

  /* Radius */
  --radius-sm: 0.25rem;
  --radius-md: 0.5rem;
  --radius-lg: 0.75rem;
  --radius-full: 9999px;

  /* Transition */
  --transition-colors: color 0.2s ease, background-color 0.2s ease, border-color 0.2s ease;
}

/* --- Dark Theme --- */
[data-theme="dark"],
.dark {
  --color-bg-primary: #0f172a;
  --color-bg-secondary: #1e293b;
  --color-bg-tertiary: #334155;
  --color-bg-elevated: #1e293b;
  --color-bg-overlay: rgba(0, 0, 0, 0.7);

  --color-text-primary: #f1f5f9;
  --color-text-secondary: #cbd5e1;
  --color-text-tertiary: #64748b;
  --color-text-inverse: #0f172a;
  --color-text-link: #60a5fa;
  --color-text-link-hover: #93bbfd;

  --color-border-primary: #334155;
  --color-border-secondary: #475569;
  --color-border-focus: #60a5fa;

  --color-accent-primary: #60a5fa;
  --color-accent-primary-hover: #93bbfd;
  --color-accent-secondary: #a78bfa;

  --color-success: #34d399;
  --color-success-bg: #064e3b;
  --color-warning: #fbbf24;
  --color-warning-bg: #78350f;
  --color-error: #f87171;
  --color-error-bg: #7f1d1d;
  --color-info: #60a5fa;
  --color-info-bg: #1e3a5f;

  --color-surface-card: #1e293b;
  --color-surface-card-hover: #334155;
  --color-surface-input: #1e293b;
  --color-surface-input-disabled: #334155;

  --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.3);
  --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.4);
  --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
}

/* --- System Preference Detection --- */
@media (prefers-color-scheme: dark) {
  :root:not([data-theme="light"]) {
    --color-bg-primary: #0f172a;
    --color-bg-secondary: #1e293b;
    --color-bg-tertiary: #334155;
    --color-bg-elevated: #1e293b;
    --color-bg-overlay: rgba(0, 0, 0, 0.7);

    --color-text-primary: #f1f5f9;
    --color-text-secondary: #cbd5e1;
    --color-text-tertiary: #64748b;
    --color-text-inverse: #0f172a;
    --color-text-link: #60a5fa;
    --color-text-link-hover: #93bbfd;

    --color-border-primary: #334155;
    --color-border-secondary: #475569;
    --color-border-focus: #60a5fa;

    --color-accent-primary: #60a5fa;
    --color-accent-primary-hover: #93bbfd;
    --color-accent-secondary: #a78bfa;

    --color-success: #34d399;
    --color-success-bg: #064e3b;
    --color-warning: #fbbf24;
    --color-warning-bg: #78350f;
    --color-error: #f87171;
    --color-error-bg: #7f1d1d;
    --color-info: #60a5fa;
    --color-info-bg: #1e3a5f;

    --color-surface-card: #1e293b;
    --color-surface-card-hover: #334155;
    --color-surface-input: #1e293b;
    --color-surface-input-disabled: #334155;

    --shadow-sm: 0 1px 2px rgba(0, 0, 0, 0.3);
    --shadow-md: 0 4px 6px -1px rgba(0, 0, 0, 0.4);
    --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.5);
  }
}

/* --- Utility Classes --- */
.theme-transition * {
  transition: var(--transition-colors);
}

.bg-theme-primary { background-color: var(--color-bg-primary); }
.bg-theme-secondary { background-color: var(--color-bg-secondary); }
.bg-theme-elevated { background-color: var(--color-bg-elevated); }
.text-theme-primary { color: var(--color-text-primary); }
.text-theme-secondary { color: var(--color-text-secondary); }
.border-theme { border-color: var(--color-border-primary); }
CSS_THEME

    if [[ -f "$theme_file" ]]; then
        DMG_THEMES_GENERATED=$((DMG_THEMES_GENERATED + 1))
        _dmg_success "テーマCSS生成完了: ${theme_file}"
        return 0
    else
        _dmg_error "テーマCSS生成失敗"
        return 1
    fi
}

# =============================================================================
# テーマトグルコンポーネント生成
# =============================================================================
# React コンポーネントとして theme toggle を生成する。
# localStorage 永続化 + system preference 検出 + アニメーション付き。
#
# 使い方: _dmg_generate_toggle <output_dir>
# =============================================================================
_dmg_generate_toggle() {
    local output_dir="${1:-${DMG_PROJECT_DIR}/components}"
    local toggle_file="${output_dir}/ThemeToggle.tsx"
    local provider_file="${output_dir}/ThemeProvider.tsx"

    [[ "$DMG_INITIALIZED" != "true" ]] && { _dmg_error "未初期化"; return 1; }

    _dmg_log "テーマトグルコンポーネント生成中..."

    mkdir -p "$output_dir" 2>/dev/null || true

    # --- ThemeProvider ---
    cat > "$provider_file" <<'TSX_PROVIDER'
'use client';

import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';

type Theme = 'light' | 'dark' | 'system';

interface ThemeContextType {
  theme: Theme;
  resolvedTheme: 'light' | 'dark';
  setTheme: (theme: Theme) => void;
  toggleTheme: () => void;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

const STORAGE_KEY = 'soloptilink-theme';

function getSystemTheme(): 'light' | 'dark' {
  if (typeof window === 'undefined') return 'light';
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const [theme, setThemeState] = useState<Theme>('system');
  const [resolvedTheme, setResolvedTheme] = useState<'light' | 'dark'>('light');

  // 初期化: localStorage から復元
  useEffect(() => {
    const stored = localStorage.getItem(STORAGE_KEY) as Theme | null;
    if (stored && ['light', 'dark', 'system'].includes(stored)) {
      setThemeState(stored);
    }
  }, []);

  // テーマ解決: system の場合はメディアクエリに追従
  useEffect(() => {
    const resolved = theme === 'system' ? getSystemTheme() : theme;
    setResolvedTheme(resolved);

    // DOM に適用
    const root = document.documentElement;
    root.setAttribute('data-theme', resolved);
    root.classList.toggle('dark', resolved === 'dark');

    // system preference 変更を監視
    if (theme === 'system') {
      const mq = window.matchMedia('(prefers-color-scheme: dark)');
      const handler = (e: MediaQueryListEvent) => {
        const newTheme = e.matches ? 'dark' : 'light';
        setResolvedTheme(newTheme);
        root.setAttribute('data-theme', newTheme);
        root.classList.toggle('dark', newTheme === 'dark');
      };
      mq.addEventListener('change', handler);
      return () => mq.removeEventListener('change', handler);
    }
  }, [theme]);

  const setTheme = useCallback((newTheme: Theme) => {
    setThemeState(newTheme);
    localStorage.setItem(STORAGE_KEY, newTheme);
  }, []);

  const toggleTheme = useCallback(() => {
    setTheme(resolvedTheme === 'light' ? 'dark' : 'light');
  }, [resolvedTheme, setTheme]);

  return (
    <ThemeContext.Provider value={{ theme, resolvedTheme, setTheme, toggleTheme }}>
      {children}
    </ThemeContext.Provider>
  );
}

export function useTheme() {
  const ctx = useContext(ThemeContext);
  if (!ctx) throw new Error('useTheme must be used within ThemeProvider');
  return ctx;
}
TSX_PROVIDER

    # --- ThemeToggle ---
    cat > "$toggle_file" <<'TSX_TOGGLE'
'use client';

import React from 'react';
import { useTheme } from './ThemeProvider';

interface ThemeToggleProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

const sizes = { sm: 'w-8 h-8', md: 'w-10 h-10', lg: 'w-12 h-12' };
const iconSizes = { sm: 'w-4 h-4', md: 'w-5 h-5', lg: 'w-6 h-6' };

export function ThemeToggle({ className = '', size = 'md' }: ThemeToggleProps) {
  const { resolvedTheme, toggleTheme } = useTheme();
  const isDark = resolvedTheme === 'dark';

  return (
    <button
      onClick={toggleTheme}
      className={`${sizes[size]} inline-flex items-center justify-center rounded-full
        bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700
        transition-colors duration-200 focus:outline-none focus:ring-2
        focus:ring-offset-2 focus:ring-blue-500 ${className}`}
      aria-label={isDark ? 'ライトモードに切り替え' : 'ダークモードに切り替え'}
      title={isDark ? 'ライトモードに切り替え' : 'ダークモードに切り替え'}
    >
      {isDark ? (
        <svg className={iconSizes[size]} fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
            d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" />
        </svg>
      ) : (
        <svg className={iconSizes[size]} fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2}
            d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" />
        </svg>
      )}
    </button>
  );
}
TSX_TOGGLE

    if [[ -f "$toggle_file" && -f "$provider_file" ]]; then
        DMG_TOGGLES_GENERATED=$((DMG_TOGGLES_GENERATED + 1))
        _dmg_success "ThemeProvider + ThemeToggle 生成完了"
        return 0
    else
        _dmg_error "トグルコンポーネント生成失敗"
        return 1
    fi
}

# =============================================================================
# カラーパレット生成
# =============================================================================
# Tailwind CSS 拡張用のカラーパレットを生成。
# WCAG AA コントラスト比 4.5:1 以上を保証。
#
# 使い方: _dmg_generate_colors <output_dir>
# =============================================================================
_dmg_generate_colors() {
    local output_dir="${1:-${DMG_PROJECT_DIR}}"
    local colors_file="${output_dir}/tailwind.theme.ts"

    [[ "$DMG_INITIALIZED" != "true" ]] && { _dmg_error "未初期化"; return 1; }

    _dmg_log "カラーパレット生成中: ${colors_file}"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$colors_file" <<'TS_COLORS'
// =============================================================================
// SoloptiLinkAI v241.0 - Tailwind Theme Colors
// CSS Variables を参照するカラーパレット定義
// =============================================================================

import type { Config } from 'tailwindcss';

export const themeColors = {
  background: {
    DEFAULT: 'var(--color-bg-primary)',
    secondary: 'var(--color-bg-secondary)',
    tertiary: 'var(--color-bg-tertiary)',
    elevated: 'var(--color-bg-elevated)',
  },
  foreground: {
    DEFAULT: 'var(--color-text-primary)',
    secondary: 'var(--color-text-secondary)',
    tertiary: 'var(--color-text-tertiary)',
    inverse: 'var(--color-text-inverse)',
    link: 'var(--color-text-link)',
  },
  border: {
    DEFAULT: 'var(--color-border-primary)',
    secondary: 'var(--color-border-secondary)',
    focus: 'var(--color-border-focus)',
  },
  accent: {
    DEFAULT: 'var(--color-accent-primary)',
    hover: 'var(--color-accent-primary-hover)',
    secondary: 'var(--color-accent-secondary)',
  },
  surface: {
    card: 'var(--color-surface-card)',
    'card-hover': 'var(--color-surface-card-hover)',
    input: 'var(--color-surface-input)',
    'input-disabled': 'var(--color-surface-input-disabled)',
  },
  semantic: {
    success: 'var(--color-success)',
    'success-bg': 'var(--color-success-bg)',
    warning: 'var(--color-warning)',
    'warning-bg': 'var(--color-warning-bg)',
    error: 'var(--color-error)',
    'error-bg': 'var(--color-error-bg)',
    info: 'var(--color-info)',
    'info-bg': 'var(--color-info-bg)',
  },
} as const;

export const themeExtension: Partial<Config['theme']> = {
  extend: {
    colors: themeColors,
    boxShadow: {
      'theme-sm': 'var(--shadow-sm)',
      'theme-md': 'var(--shadow-md)',
      'theme-lg': 'var(--shadow-lg)',
    },
    borderRadius: {
      'theme-sm': 'var(--radius-sm)',
      'theme-md': 'var(--radius-md)',
      'theme-lg': 'var(--radius-lg)',
    },
  },
};
TS_COLORS

    if [[ -f "$colors_file" ]]; then
        _dmg_success "カラーパレット生成完了: ${colors_file}"
        return 0
    else
        _dmg_error "カラーパレット生成失敗"
        return 1
    fi
}

# =============================================================================
# ダークモード対応チェック
# =============================================================================
# 既存コンポーネントがダークモードに対応しているか検査する。
# ハードコードされた色、bg-white 固定、テーマ変数未使用を検出。
#
# 使い方: _dmg_check_dark_mode_support <project_dir>
# =============================================================================
_dmg_check_dark_mode_support() {
    local project_dir="${1:-${DMG_PROJECT_DIR}}"
    local issues=0
    local checked=0

    [[ "$DMG_INITIALIZED" != "true" ]] && { _dmg_error "未初期化"; return 1; }

    _dmg_log "ダークモード対応チェック: ${project_dir}"

    # TSX/JSX ファイルを検査
    local files=()
    if [[ -d "$project_dir" ]]; then
        while IFS= read -r -d '' f; do
            files+=("$f")
        done < <(find "$project_dir" -type f \( -name '*.tsx' -o -name '*.jsx' \) -not -path '*/node_modules/*' -not -path '*/.next/*' -print0 2>/dev/null)
    fi

    if [[ ${#files[@]} -eq 0 ]]; then
        _dmg_warn "検査対象ファイルなし"
        echo "0"
        return 0
    fi

    for f in "${files[@]}"; do
        checked=$((checked + 1))
        local file_issues=0
        local basename_f
        basename_f=$(basename "$f")

        # 1. ハードコードされた背景色 (bg-white without dark: variant)
        if grep -qP 'bg-white(?!\s)' "$f" 2>/dev/null; then
            if ! grep -qP 'dark:bg-' "$f" 2>/dev/null; then
                _dmg_warn "${basename_f}: bg-white にダークモード variant なし"
                file_issues=$((file_issues + 1))
            fi
        fi

        # 2. ハードコードされたテキスト色
        if grep -qP 'text-(?:black|gray-900)' "$f" 2>/dev/null; then
            if ! grep -qP 'dark:text-' "$f" 2>/dev/null; then
                _dmg_warn "${basename_f}: テキスト色にダークモード variant なし"
                file_issues=$((file_issues + 1))
            fi
        fi

        # 3. インラインスタイルでの色指定
        if grep -qP "style=\{.*(?:color|background|backgroundColor)\s*:" "$f" 2>/dev/null; then
            _dmg_warn "${basename_f}: インラインスタイルで色指定（テーマ変数推奨）"
            file_issues=$((file_issues + 1))
        fi

        # 4. border-gray 固定色
        if grep -qP 'border-gray-\d+' "$f" 2>/dev/null; then
            if ! grep -qP 'dark:border-' "$f" 2>/dev/null; then
                _dmg_warn "${basename_f}: border色にダークモード variant なし"
                file_issues=$((file_issues + 1))
            fi
        fi

        # 5. CSS変数使用チェック
        if grep -qP 'var\(--color-' "$f" 2>/dev/null; then
            # CSS変数使用 = good
            :
        fi

        issues=$((issues + file_issues))
    done

    DMG_ISSUES_FOUND=$((DMG_ISSUES_FOUND + issues))

    if [[ $issues -eq 0 ]]; then
        _dmg_success "チェック完了: ${checked}ファイル検査、問題なし"
    else
        _dmg_warn "チェック完了: ${checked}ファイル検査、${issues}件の問題"
    fi

    echo "$issues"
    return 0
}

# =============================================================================
# Tailwind darkMode 設定注入
# =============================================================================
_dmg_inject_tailwind_config() {
    local project_dir="${1:-${DMG_PROJECT_DIR}}"
    local tw_config="${project_dir}/tailwind.config.ts"

    [[ "$DMG_INITIALIZED" != "true" ]] && { _dmg_error "未初期化"; return 1; }

    if [[ ! -f "$tw_config" ]]; then
        tw_config="${project_dir}/tailwind.config.js"
    fi

    if [[ -f "$tw_config" ]]; then
        if ! grep -q "darkMode" "$tw_config" 2>/dev/null; then
            _dmg_log "tailwind.config に darkMode: 'class' を追加推奨"
        else
            _dmg_success "tailwind.config に darkMode 設定済み"
        fi
    else
        _dmg_warn "tailwind.config が見つかりません"
    fi

    return 0
}

# =============================================================================
# フル生成（テーマ + トグル + カラー + 設定チェック）
# =============================================================================
_dmg_generate_full() {
    local project_dir="${1:-${DMG_PROJECT_DIR}}"

    [[ "$DMG_INITIALIZED" != "true" ]] && { _dmg_error "未初期化"; return 1; }

    _dmg_log "=== Dark Mode フル生成開始 ==="

    _dmg_generate_theme_system "${project_dir}/styles"
    _dmg_generate_toggle "${project_dir}/components"
    _dmg_generate_colors "${project_dir}"
    _dmg_inject_tailwind_config "${project_dir}"
    _dmg_check_dark_mode_support "${project_dir}"

    _dmg_success "=== Dark Mode フル生成完了 ==="
    return 0
}

# =============================================================================
# プロンプト注入: 生成プロンプトにダークモード指示を追加
# =============================================================================
_dmg_inject_prompt() {
    cat <<'PROMPT_INJECTION'
## [DMG] Dark Mode 必須ルール

### CSS 色指定ルール
- ハードコード禁止: `bg-white`, `text-black`, `border-gray-300` を単体で使用しない
- 必ず dark: variant を併記: `bg-white dark:bg-gray-900`
- 推奨: CSS Variables `var(--color-bg-primary)` を使用
- インラインスタイルでの色指定禁止

### コンポーネントルール
- ThemeProvider でラップ済みであること
- useTheme() でテーマ状態にアクセス
- 画像は dark: で別画像 or invert フィルタ対応
- SVG アイコンは currentColor を使用

### テスト
- ライトモードで全画面確認
- ダークモードで全画面確認
- システム設定追従の確認
PROMPT_INJECTION
}

# =============================================================================
# レポート
# =============================================================================
dmg_report() {
    echo -e "\n  ${BOLD:-}--- Dark Mode Generator v${DMG_VERSION} ---${NC:-}"
    echo -e "  テーマ生成数  : ${DMG_THEMES_GENERATED}"
    echo -e "  トグル生成数  : ${DMG_TOGGLES_GENERATED}"
    echo -e "  検出問題数    : ${DMG_ISSUES_FOUND}"
    echo -e "  修正済み      : ${DMG_ISSUES_FIXED}"
}

dmg_report_json() {
    cat <<EOF
{"module":"dark-mode-generator","version":"${DMG_VERSION}","themes_generated":${DMG_THEMES_GENERATED},"toggles_generated":${DMG_TOGGLES_GENERATED},"issues_found":${DMG_ISSUES_FOUND},"issues_fixed":${DMG_ISSUES_FIXED}}
EOF
}

dmg_score() {
    if [[ "$DMG_INITIALIZED" != "true" ]]; then
        echo 0; return
    fi
    local score=60
    [[ $DMG_THEMES_GENERATED -gt 0 ]] && score=$((score + 15))
    [[ $DMG_TOGGLES_GENERATED -gt 0 ]] && score=$((score + 15))
    [[ $DMG_ISSUES_FOUND -eq 0 ]] && score=$((score + 10))
    echo "$score"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "dark-mode-generator" \
        --version "241.0" \
        --description "CSS Variables テーマシステム + ダークモードトグル自動生成" \
        --init "dmg_init" \
        --report "dmg_report" \
        --score "dmg_score" \
        --enable-var "ENABLE_DARK_MODE_GENERATOR" \
        --cli-flags "--dark-mode:--no-dark-mode"
fi

# v2003.1: source時のexit codeを確実に0にする
true
