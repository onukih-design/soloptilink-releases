#!/usr/bin/env bash
# SoloptiLinkAI v55.0 - Operations/Deploy/Knowledge Phase Functions
# Deploy, documentation, knowledge save, RAG search phases
# Auto-generated from phases.sh - 5 functions



# ---- Phase: 自動デプロイ (v10.0) ----
phase_auto_deploy() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "auto_deploy" 2>/dev/null || true

    echo -e "  ${CYAN}🚀 自動デプロイフェーズ (v10.0)${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    if ! type -t deploy_auto &>/dev/null; then
        echo -e "  ${YELLOW}⚠️ デプロイモジュール未ロード → スキップ${NC}"
        return 0
    fi

    deploy_init "." 2>/dev/null || true
    if deploy_auto "." 2>/dev/null; then
        echo -e "  ${GREEN}✅ デプロイ完了${NC}"
    else
        echo -e "  ${YELLOW}⚠️ デプロイ失敗（手動デプロイを推奨）${NC}"
    fi

    _post_phase_checkpoint "auto_deploy"
    return 0
}



# ---- Phase: デプロイ準備 ----
phase_deploy() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "deploy" 2>/dev/null || true

    echo -e "  ${CYAN}🚀 デプロイ準備フェーズ${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    local prompt="以下のプロジェクトのデプロイ準備を行ってください。

タスク: ${task_desc}

以下を作成してください:
1. Dockerfile / docker-compose.yml
2. CI/CD設定（GitHub Actions）
3. 環境変数テンプレート
4. ヘルスチェックエンドポイント
5. 本番用ビルド設定

全ファイルをプロジェクトルートに書き出してください。"

    local output_file="${SESSION_LOG_DIR}/deploy_prep.md"
    if _call_claude "$prompt" "$output_file"; then
        echo -e "  ${GREEN}✅ デプロイ準備完了${NC}"
        _write_claude_output_to_files "$output_file"
    else
        echo -e "  ${RED}❌ デプロイ準備失敗${NC}"
    fi

    _post_phase_checkpoint "deploy"
    return 0
}



# ---- Phase: ドキュメント生成 ----
phase_documentation() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "documentation" 2>/dev/null || true

    echo -e "  ${CYAN}📝 ドキュメント生成フェーズ${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    local req_content=""
    [[ -n "${REQUIREMENTS_FILE:-}" && -f "$REQUIREMENTS_FILE" ]] && req_content="$(cat "$REQUIREMENTS_FILE")"

    local prompt="あなたはテクニカルライターです。以下のプロジェクトのドキュメントを作成してください。

タスク: ${task_desc}

要件:
${req_content:-（なし）}

以下を作成してください:
1. README.md（プロジェクト概要、セットアップ手順、使用方法、API概要）
2. APIドキュメント（全エンドポイント）
3. アーキテクチャドキュメント
4. デプロイ手順書
5. 開発ガイド（コーディング規約、ブランチ戦略）

全ファイルをプロジェクトルートに書き出してください。"

    local output_file="${SESSION_LOG_DIR}/documentation.md"
    if _call_claude "$prompt" "$output_file"; then
        echo -e "  ${GREEN}✅ ドキュメント生成完了${NC}"
        _write_claude_output_to_files "$output_file"
    else
        echo -e "  ${RED}❌ ドキュメント生成失敗${NC}"
    fi

    [[ "$NO_LEARN" != "1" ]] && type -t rt_capture_success &>/dev/null && \
        rt_capture_success "DOC" "documentation" "ドキュメント生成完了"

    _post_phase_checkpoint "documentation"
    return 0
}



# ---- Phase: ナレッジ蓄積 ----
phase_knowledge_save() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "knowledge_save" 2>/dev/null || true

    echo -e "  ${CYAN}🧠 ナレッジ蓄積フェーズ${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    # セッションサマリーを保存
    local summary_file="${SESSION_LOG_DIR}/session_summary.md"
    local session_end
    session_end=$(date +%s)
    local duration=$((session_end - SESSION_START))

    cat > "$summary_file" <<EOF
# セッションサマリー: ${session_id}
- タスク: ${task_desc}
- 日時: $(date '+%Y-%m-%d %H:%M:%S')
- パイプライン: ${PIPELINE_MODE}
- バージョン: v${VERSION}
- 実行時間: $((duration / 60))分$((duration % 60))秒
- URL数: ${#URLS[@]}
EOF

    # リアルタイム学習の同期
    if [[ "$NO_LEARN" != "1" ]] && type -t rt_sync_to_global &>/dev/null; then
        rt_sync_to_global "$session_id" 2>/dev/null || true
        echo -e "  ${GREEN}✅ 学習データ同期完了${NC}"
    fi

    # RAGインデックスに追加
    if [[ "$NO_RAG" != "1" && -f "tools/rag-engine.py" ]]; then
        python3 tools/rag-engine.py add "$summary_file" --tags "session-summary,${session_id}" 2>/dev/null || true
        echo -e "  ${GREEN}✅ RAGインデックスにセッション追加${NC}"
    fi

    # セッションナレッジのRAGインデックス化
    if [[ "$NO_RAG" != "1" ]] && type -t rt_index_session_knowledge &>/dev/null; then
        rt_index_session_knowledge "$session_id" 2>/dev/null || true
    fi

    _post_phase_checkpoint "knowledge_save"
    return 0
}



# ---- Phase: RAGナレッジ検索 ----
phase_rag_search() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "rag_search" 2>/dev/null || true

    if [[ "$NO_RAG" == "1" ]]; then
        echo -e "  ${YELLOW}RAG検索スキップ（--no-rag）${NC}"
        return 0
    fi

    if [[ ! -f "tools/rag-engine.py" ]]; then
        echo -e "  ${YELLOW}RAGエンジン未インストール${NC}"
        return 0
    fi

    echo -e "  ${CYAN}📚 RAGナレッジ検索中...${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    local results
    results=$(python3 tools/rag-engine.py search "$task_desc" --top-k 5 2>/dev/null || echo "")

    if [[ -n "$results" ]]; then
        echo "$results" > "${SESSION_LOG_DIR}/rag_results.txt"
        echo -e "  ${GREEN}✅ RAG結果取得: $(echo "$results" | wc -l | tr -d ' ')行${NC}"
    else
        echo -e "  ${YELLOW}関連ナレッジなし（新規タスク）${NC}"
    fi

    _post_phase_checkpoint "rag_search"
    return 0
}

