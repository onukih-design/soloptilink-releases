#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v209.0 - Incremental Understanding
# =============================================================================
# ファイル変更差分ベースの増分解析キャッシュ。全ファイル再スキャンを回避し、
# 変更されたファイルのみを再解析してキャッシュとマージする。
#
# 機能:
#   - 理解キャッシュの初期化 (.soloptilink/cache/)
#   - git diff ベースのファイル変更検出
#   - 変更ファイルのみの増分解析 + キャッシュマージ
#   - キャッシュ済み解析データの取得
#   - 特定キャッシュエントリの無効化
#   - キャッシュ統計レポート
#   - プロジェクト構造の増分理解（import/export/型定義/API）
#
# 全globals: IU_ prefix
# =============================================================================

[[ -n "${_IU_LOADED:-}" ]] && return 0; _IU_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g IU_VERSION="209.0"
declare -g IU_INITIALIZED=false
declare -g IU_ERRORS=0
declare -g IU_PHASE="incremental_understanding"
declare -g IU_CACHE_DIR="${HOME}/.soloptilink/cache"
declare -g IU_CACHE_INDEX="${HOME}/.soloptilink/cache/index.json"
declare -g IU_LAST_COMMIT_FILE="${HOME}/.soloptilink/cache/.last_commit"
declare -g IU_FILES_ANALYZED=0
declare -g IU_FILES_CACHED=0
declare -g IU_FILES_INVALIDATED=0
declare -g IU_CACHE_HITS=0
declare -g IU_CACHE_MISSES=0
declare -g IU_TOTAL_ENTRIES=0

# =============================================================================
# 初期化
# =============================================================================
iu_init() {
    IU_INITIALIZED=true
    IU_ERRORS=0
    IU_FILES_ANALYZED=0
    IU_FILES_CACHED=0
    IU_FILES_INVALIDATED=0
    IU_CACHE_HITS=0
    IU_CACHE_MISSES=0
    IU_TOTAL_ENTRIES=0

    mkdir -p "${IU_CACHE_DIR}/files" 2>/dev/null
    mkdir -p "${IU_CACHE_DIR}/analysis" 2>/dev/null
    mkdir -p "${IU_CACHE_DIR}/meta" 2>/dev/null

    # キャッシュインデックスがなければ初期化
    if [[ ! -f "${IU_CACHE_INDEX}" ]]; then
        _iu_write_index "{\"version\":\"${IU_VERSION}\",\"created\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\",\"entries\":{},\"stats\":{\"total_analyses\":0,\"cache_hits\":0,\"cache_misses\":0}}"
    fi

    # エントリ数を読み込み
    if [[ -f "${IU_CACHE_INDEX}" ]]; then
        IU_TOTAL_ENTRIES=$(_iu_count_entries)
    fi

    return 0
}

# =============================================================================
# Internal: キャッシュインデックス書き込み
# =============================================================================
_iu_write_index() {
    local content="$1"
    local tmp_file="${IU_CACHE_INDEX}.tmp.$$"
    echo "$content" > "$tmp_file" 2>/dev/null
    mv "$tmp_file" "${IU_CACHE_INDEX}" 2>/dev/null
}

# =============================================================================
# Internal: エントリ数カウント
# =============================================================================
_iu_count_entries() {
    if [[ -f "${IU_CACHE_INDEX}" ]]; then
        local count
        count=$(grep -o '"hash":' "${IU_CACHE_INDEX}" 2>/dev/null | wc -l | tr -d ' ')
        echo "${count:-0}"
    else
        echo "0"
    fi
}

# =============================================================================
# Internal: ファイルのSHA256ハッシュ
# =============================================================================
_iu_file_hash() {
    local file="$1"
    if [[ -f "$file" ]]; then
        if command -v shasum &>/dev/null; then
            shasum -a 256 "$file" 2>/dev/null | cut -d' ' -f1
        elif command -v sha256sum &>/dev/null; then
            sha256sum "$file" 2>/dev/null | cut -d' ' -f1
        else
            # Fallback: use modification time + size
            stat -f "%m_%z" "$file" 2>/dev/null || stat -c "%Y_%s" "$file" 2>/dev/null || echo "unknown"
        fi
    else
        echo "missing"
    fi
}

# =============================================================================
# Internal: ファイルのキャッシュキー生成
# =============================================================================
_iu_cache_key() {
    local file_path="$1"
    # パスをファイルシステムセーフな名前に変換
    echo "$file_path" | sed 's|/|__|g; s| |_|g; s|\.|_DOT_|g'
}

# =============================================================================
# Internal: 単一ファイルの解析結果をキャッシュに保存
# =============================================================================
_iu_save_file_cache() {
    local file_path="$1"
    local project_dir="$2"
    local rel_path="${file_path#${project_dir}/}"
    local cache_key
    cache_key=$(_iu_cache_key "$rel_path")
    local hash
    hash=$(_iu_file_hash "$file_path")
    local analysis_file="${IU_CACHE_DIR}/analysis/${cache_key}.json"

    # ファイル解析
    local analysis
    analysis=$(_iu_analyze_single_file "$file_path" "$project_dir")

    # キャッシュファイルに書き込み
    local timestamp
    timestamp=$(date -u +%Y-%m-%dT%H:%M:%SZ)
    cat > "$analysis_file" <<CACHE_EOF
{
  "file": "${rel_path}",
  "hash": "${hash}",
  "analyzed_at": "${timestamp}",
  "analysis": ${analysis}
}
CACHE_EOF

    IU_FILES_CACHED=$((IU_FILES_CACHED + 1))
}

# =============================================================================
# Internal: 単一ファイル解析
# =============================================================================
_iu_analyze_single_file() {
    local file="$1"
    local project_dir="$2"
    local rel_path="${file#${project_dir}/}"
    local ext="${file##*.}"

    local file_type="unknown"
    local imports=""
    local exports=""
    local functions=""
    local types=""
    local api_calls=""
    local line_count=0
    local complexity="low"

    [[ -f "$file" ]] || { echo '{"error":"file_not_found"}'; return; }

    line_count=$(wc -l < "$file" 2>/dev/null | tr -d ' ')

    # ファイルタイプ判定
    case "$rel_path" in
        */route.ts|*/route.js)         file_type="api_route" ;;
        */page.tsx|*/page.jsx)         file_type="page" ;;
        */layout.tsx|*/layout.jsx)     file_type="layout" ;;
        */middleware.ts)               file_type="middleware" ;;
        *prisma/schema.prisma)         file_type="schema" ;;
        */components/*|*/Components/*) file_type="component" ;;
        */lib/*|*/utils/*|*/helpers/*) file_type="utility" ;;
        */hooks/*)                     file_type="hook" ;;
        */types/*|*/interfaces/*)      file_type="type_definition" ;;
        *.test.*|*.spec.*)             file_type="test" ;;
        *.config.*|*.conf.*)           file_type="config" ;;
        *)
            case "$ext" in
                ts|tsx|js|jsx) file_type="source" ;;
                json)          file_type="config" ;;
                css|scss)      file_type="style" ;;
                md)            file_type="documentation" ;;
                sh)            file_type="script" ;;
            esac
            ;;
    esac

    # TypeScript/JavaScript ファイルの詳細解析
    if [[ "$ext" == "ts" || "$ext" == "tsx" || "$ext" == "js" || "$ext" == "jsx" ]]; then
        # インポート抽出
        local import_list=""
        local import_first=true
        while IFS= read -r imp; do
            [[ -z "$imp" ]] && continue
            local _iu_imp_re="from[[:space:]]+['\"]([^'\"]+)['\"]"
            if [[ "$imp" =~ $_iu_imp_re ]]; then
                local imp_path="${BASH_REMATCH[1]}"
                [[ "$import_first" == "true" ]] && import_first=false || import_list+=","
                import_list+="\"${imp_path}\""
            fi
        done < <(grep -E "^import " "$file" 2>/dev/null)
        imports="[${import_list}]"

        # エクスポート抽出
        local export_list=""
        local export_first=true
        while IFS= read -r exp_line; do
            [[ -z "$exp_line" ]] && continue
            local exp_name=""
            if [[ "$exp_line" =~ export[[:space:]]+(default[[:space:]]+)?(function|const|class|type|interface|enum)[[:space:]]+([A-Za-z_][A-Za-z0-9_]*) ]]; then
                exp_name="${BASH_REMATCH[3]}"
            elif [[ "$exp_line" =~ export[[:space:]]+default ]]; then
                exp_name="default"
            fi
            if [[ -n "$exp_name" ]]; then
                [[ "$export_first" == "true" ]] && export_first=false || export_list+=","
                export_list+="\"${exp_name}\""
            fi
        done < <(grep -E "^export " "$file" 2>/dev/null)
        exports="[${export_list}]"

        # 関数抽出
        local func_list=""
        local func_first=true
        while IFS= read -r func_line; do
            [[ -z "$func_line" ]] && continue
            local fn_name=""
            if [[ "$func_line" =~ (function|const|export[[:space:]]+function|export[[:space:]]+const|export[[:space:]]+async[[:space:]]+function)[[:space:]]+([A-Za-z_][A-Za-z0-9_]*) ]]; then
                fn_name="${BASH_REMATCH[2]}"
            fi
            if [[ -n "$fn_name" ]]; then
                [[ "$func_first" == "true" ]] && func_first=false || func_list+=","
                func_list+="\"${fn_name}\""
            fi
        done < <(grep -E "(^|export )(async )?(function |const )[A-Za-z_]" "$file" 2>/dev/null | head -50)
        functions="[${func_list}]"

        # 型定義抽出
        local type_list=""
        local type_first=true
        while IFS= read -r type_line; do
            [[ -z "$type_line" ]] && continue
            local type_name=""
            if [[ "$type_line" =~ (type|interface)[[:space:]]+([A-Za-z_][A-Za-z0-9_]*) ]]; then
                type_name="${BASH_REMATCH[2]}"
            fi
            if [[ -n "$type_name" ]]; then
                [[ "$type_first" == "true" ]] && type_first=false || type_list+=","
                type_list+="\"${type_name}\""
            fi
        done < <(grep -E "^(export )?(type|interface) [A-Z]" "$file" 2>/dev/null)
        types="[${type_list}]"

        # API呼び出し抽出
        local api_list=""
        local api_first=true
        while IFS= read -r fetch_line; do
            [[ -z "$fetch_line" ]] && continue
            local api_path=""
            local _iu_fetch_re="fetch\(['\"\`](/api/[^'\"\`\$]+)"
            if [[ "$fetch_line" =~ $_iu_fetch_re ]]; then
                api_path="${BASH_REMATCH[1]}"
            fi
            if [[ -n "$api_path" ]]; then
                [[ "$api_first" == "true" ]] && api_first=false || api_list+=","
                api_list+="\"${api_path}\""
            fi
        done < <(grep -E "fetch\(.*?/api/" "$file" 2>/dev/null | head -20)
        api_calls="[${api_list}]"

        # 複雑度評価
        local import_cnt
        import_cnt=$(grep -c "^import " "$file" 2>/dev/null || echo "0")
        if [[ $line_count -gt 500 || $import_cnt -gt 20 ]]; then
            complexity="high"
        elif [[ $line_count -gt 200 || $import_cnt -gt 10 ]]; then
            complexity="medium"
        fi
    else
        imports="[]"
        exports="[]"
        functions="[]"
        types="[]"
        api_calls="[]"
    fi

    # HTTPメソッド検出（APIルートの場合）
    local http_methods="[]"
    if [[ "$file_type" == "api_route" ]]; then
        local method_list=""
        local method_first=true
        for method in GET POST PUT PATCH DELETE; do
            if grep -qE "export (async )?function ${method}" "$file" 2>/dev/null; then
                [[ "$method_first" == "true" ]] && method_first=false || method_list+=","
                method_list+="\"${method}\""
            fi
        done
        http_methods="[${method_list}]"
    fi

    cat <<ANALYSIS_EOF
{
    "file_type": "${file_type}",
    "extension": "${ext}",
    "line_count": ${line_count},
    "complexity": "${complexity}",
    "imports": ${imports},
    "exports": ${exports},
    "functions": ${functions},
    "types": ${types},
    "api_calls": ${api_calls},
    "http_methods": ${http_methods}
}
ANALYSIS_EOF
}

# =============================================================================
# キャッシュ初期化
# =============================================================================
_iu_init_cache() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    [[ "$IU_INITIALIZED" != "true" ]] && iu_init

    echo "[incremental-understanding] Initializing cache for: ${project_dir}"

    # 現在のgit commitを保存
    if [[ -d "${project_dir}/.git" ]]; then
        local current_commit
        current_commit=$(cd "$project_dir" && git rev-parse HEAD 2>/dev/null || echo "none")
        echo "$current_commit" > "${IU_LAST_COMMIT_FILE}"
        echo "[incremental-understanding] Anchored to commit: ${current_commit:0:8}"
    fi

    # プロジェクトメタデータ保存
    local meta_file="${IU_CACHE_DIR}/meta/project.json"
    local file_count
    file_count=$(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) 2>/dev/null | grep -v node_modules | grep -v '.next' | grep -v dist | wc -l | tr -d ' ')

    cat > "$meta_file" <<META_EOF
{
  "project_dir": "${project_dir}",
  "initialized_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "total_source_files": ${file_count},
  "cache_version": "${IU_VERSION}"
}
META_EOF

    echo "[incremental-understanding] Cache initialized. ${file_count} source files in project."
    return 0
}

# =============================================================================
# 変更検出: git diff ベース
# =============================================================================
_iu_detect_changes() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local changed_files=""
    local change_count=0

    if [[ ! -d "${project_dir}/.git" ]]; then
        echo "[incremental-understanding] Not a git repo, falling back to full scan"
        # git非対応の場合: キャッシュされていないファイルを「変更」とみなす
        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            local rel_path="${file#${project_dir}/}"
            local cache_key
            cache_key=$(_iu_cache_key "$rel_path")
            local cached_file="${IU_CACHE_DIR}/analysis/${cache_key}.json"

            if [[ ! -f "$cached_file" ]]; then
                changed_files+="${file}\n"
                change_count=$((change_count + 1))
            else
                # ハッシュ比較
                local current_hash
                current_hash=$(_iu_file_hash "$file")
                local cached_hash
                cached_hash=$(grep -oE '"hash":"[^"]*"' "$cached_file" 2>/dev/null | sed 's/"hash":"//;s/"//')
                if [[ "$current_hash" != "$cached_hash" ]]; then
                    changed_files+="${file}\n"
                    change_count=$((change_count + 1))
                fi
            fi
        done < <(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) 2>/dev/null | grep -v node_modules | grep -v '.next' | grep -v dist | sort)

        echo "[incremental-understanding] Non-git mode: ${change_count} file(s) need analysis"
        echo -e "$changed_files" | grep -v '^$'
        return 0
    fi

    # git ベースの変更検出
    local last_commit=""
    if [[ -f "${IU_LAST_COMMIT_FILE}" ]]; then
        last_commit=$(cat "${IU_LAST_COMMIT_FILE}" 2>/dev/null)
    fi

    local current_commit
    current_commit=$(cd "$project_dir" && git rev-parse HEAD 2>/dev/null || echo "none")

    if [[ -z "$last_commit" || "$last_commit" == "none" ]]; then
        # 初回: 全ファイルが「変更」
        echo "[incremental-understanding] No previous commit recorded. Full scan needed."
        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            changed_files+="${project_dir}/${file}\n"
            change_count=$((change_count + 1))
        done < <(cd "$project_dir" && git ls-files '*.ts' '*.tsx' '*.js' '*.jsx' 2>/dev/null | grep -v node_modules | grep -v '.next' | sort)
    else
        # コミット間の差分
        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            # ソースファイルのみ
            case "$file" in
                *.ts|*.tsx|*.js|*.jsx)
                    if [[ -f "${project_dir}/${file}" ]]; then
                        changed_files+="${project_dir}/${file}\n"
                        change_count=$((change_count + 1))
                    fi
                    ;;
            esac
        done < <(cd "$project_dir" && git diff --name-only "${last_commit}" "${current_commit}" 2>/dev/null)

        # ステージされていない変更も含める
        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            case "$file" in
                *.ts|*.tsx|*.js|*.jsx)
                    if [[ -f "${project_dir}/${file}" ]]; then
                        # 重複チェック
                        if ! echo -e "$changed_files" | grep -qF "${project_dir}/${file}"; then
                            changed_files+="${project_dir}/${file}\n"
                            change_count=$((change_count + 1))
                        fi
                    fi
                    ;;
            esac
        done < <(cd "$project_dir" && git diff --name-only 2>/dev/null)

        # 未追跡ファイル
        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            case "$file" in
                *.ts|*.tsx|*.js|*.jsx)
                    if [[ -f "${project_dir}/${file}" ]]; then
                        if ! echo -e "$changed_files" | grep -qF "${project_dir}/${file}"; then
                            changed_files+="${project_dir}/${file}\n"
                            change_count=$((change_count + 1))
                        fi
                    fi
                    ;;
            esac
        done < <(cd "$project_dir" && git ls-files --others --exclude-standard 2>/dev/null)
    fi

    echo "[incremental-understanding] Detected ${change_count} changed file(s) since ${last_commit:0:8:-unknown}"
    echo -e "$changed_files" | grep -v '^$'
}

# =============================================================================
# 増分更新: 変更ファイルのみ再解析してキャッシュマージ
# =============================================================================
_iu_update_incremental() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    [[ "$IU_INITIALIZED" != "true" ]] && iu_init

    echo "[incremental-understanding] Starting incremental update..."

    # 変更検出
    local changed
    changed=$(_iu_detect_changes "$project_dir" | tail -n +2)

    local analyzed=0
    local skipped=0

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        [[ ! -f "$file" ]] && continue

        # 解析 + キャッシュ保存
        _iu_save_file_cache "$file" "$project_dir"
        analyzed=$((analyzed + 1))
        IU_FILES_ANALYZED=$((IU_FILES_ANALYZED + 1))
        IU_CACHE_MISSES=$((IU_CACHE_MISSES + 1))
    done <<< "$changed"

    # キャッシュ済みファイル数カウント
    IU_FILES_CACHED=$(find "${IU_CACHE_DIR}/analysis" -name "*.json" 2>/dev/null | wc -l | tr -d ' ')

    # 最終コミット更新
    if [[ -d "${project_dir}/.git" ]]; then
        local current_commit
        current_commit=$(cd "$project_dir" && git rev-parse HEAD 2>/dev/null || echo "none")
        echo "$current_commit" > "${IU_LAST_COMMIT_FILE}"
    fi

    # キャッシュ統計更新
    local stats_file="${IU_CACHE_DIR}/meta/stats.json"
    cat > "$stats_file" <<STATS_EOF
{
  "last_update": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "files_analyzed_this_run": ${analyzed},
  "total_cached_files": ${IU_FILES_CACHED},
  "total_analyses": ${IU_FILES_ANALYZED},
  "cache_hits": ${IU_CACHE_HITS},
  "cache_misses": ${IU_CACHE_MISSES}
}
STATS_EOF

    echo "[incremental-understanding] Incremental update complete: ${analyzed} files analyzed, ${IU_FILES_CACHED} total cached"
    return 0
}

# =============================================================================
# キャッシュ済み解析データ取得
# =============================================================================
_iu_get_cached_analysis() {
    local file_path="${1:-}"
    local project_dir="${2:-${PROJECT_DIR:-./output}}"

    if [[ -z "$file_path" ]]; then
        # 全キャッシュの集約を返す
        _iu_get_all_cached "$project_dir"
        return $?
    fi

    local rel_path="${file_path#${project_dir}/}"
    local cache_key
    cache_key=$(_iu_cache_key "$rel_path")
    local cached_file="${IU_CACHE_DIR}/analysis/${cache_key}.json"

    if [[ -f "$cached_file" ]]; then
        # ハッシュが最新か確認
        if [[ -f "${project_dir}/${rel_path}" ]]; then
            local current_hash
            current_hash=$(_iu_file_hash "${project_dir}/${rel_path}")
            local cached_hash
            cached_hash=$(grep -oE '"hash":"[^"]*"' "$cached_file" 2>/dev/null | sed 's/"hash":"//;s/"//')

            if [[ "$current_hash" == "$cached_hash" ]]; then
                IU_CACHE_HITS=$((IU_CACHE_HITS + 1))
                cat "$cached_file"
                return 0
            else
                # キャッシュが古い
                IU_CACHE_MISSES=$((IU_CACHE_MISSES + 1))
                echo "[incremental-understanding] Cache stale for: ${rel_path}" >&2
                # 自動的に再解析
                _iu_save_file_cache "${project_dir}/${rel_path}" "$project_dir"
                cat "$cached_file"
                return 0
            fi
        fi

        IU_CACHE_HITS=$((IU_CACHE_HITS + 1))
        cat "$cached_file"
        return 0
    fi

    # キャッシュミス
    IU_CACHE_MISSES=$((IU_CACHE_MISSES + 1))
    echo "[incremental-understanding] Cache miss for: ${rel_path}" >&2

    # 存在するファイルなら解析してキャッシュ
    if [[ -f "${project_dir}/${rel_path}" ]]; then
        _iu_save_file_cache "${project_dir}/${rel_path}" "$project_dir"
        cat "${IU_CACHE_DIR}/analysis/${cache_key}.json"
        return 0
    fi

    echo '{"error":"file_not_found","file":"'"${rel_path}"'"}'
    return 1
}

# =============================================================================
# Internal: 全キャッシュの集約
# =============================================================================
_iu_get_all_cached() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local json='{"cached_files":['
    local first=true
    local count=0

    while IFS= read -r cache_file; do
        [[ -z "$cache_file" ]] && continue
        [[ ! -f "$cache_file" ]] && continue

        local file_entry
        file_entry=$(grep -oE '"file":"[^"]*"' "$cache_file" 2>/dev/null | head -1)
        local file_type
        file_type=$(grep -oE '"file_type":"[^"]*"' "$cache_file" 2>/dev/null | head -1)

        [[ -z "$file_entry" ]] && continue

        [[ "$first" == "true" ]] && first=false || json+=","
        json+="{${file_entry},${file_type:-\"file_type\":\"unknown\"}}"
        count=$((count + 1))
    done < <(find "${IU_CACHE_DIR}/analysis" -name "*.json" 2>/dev/null | sort)

    json+="],"
    json+="\"total_cached\":${count},"
    json+="\"cache_dir\":\"${IU_CACHE_DIR}\""
    json+="}"

    echo "$json"
}

# =============================================================================
# キャッシュ無効化
# =============================================================================
_iu_invalidate() {
    local target="${1:-}"
    local project_dir="${2:-${PROJECT_DIR:-./output}}"

    if [[ -z "$target" ]]; then
        echo "[incremental-understanding] Usage: _iu_invalidate <file_path|pattern|--all>"
        return 1
    fi

    local invalidated=0

    if [[ "$target" == "--all" ]]; then
        # 全キャッシュクリア
        local count
        count=$(find "${IU_CACHE_DIR}/analysis" -name "*.json" 2>/dev/null | wc -l | tr -d ' ')
        rm -f "${IU_CACHE_DIR}/analysis/"*.json 2>/dev/null
        rm -f "${IU_LAST_COMMIT_FILE}" 2>/dev/null
        invalidated=$count
        echo "[incremental-understanding] All cache cleared: ${invalidated} entries removed"
    elif [[ "$target" == *"*"* ]]; then
        # パターンマッチで無効化
        local pattern
        pattern=$(echo "$target" | sed 's|/|__|g; s| |_|g; s|\.|_DOT_|g; s|\*|.*|g')
        while IFS= read -r cache_file; do
            [[ -z "$cache_file" ]] && continue
            local basename
            basename=$(basename "$cache_file")
            if [[ "$basename" =~ $pattern ]]; then
                rm -f "$cache_file" 2>/dev/null
                invalidated=$((invalidated + 1))
            fi
        done < <(find "${IU_CACHE_DIR}/analysis" -name "*.json" 2>/dev/null)
        echo "[incremental-understanding] Pattern '${target}': ${invalidated} entries invalidated"
    else
        # 特定ファイルの無効化
        local rel_path="${target#${project_dir}/}"
        local cache_key
        cache_key=$(_iu_cache_key "$rel_path")
        local cached_file="${IU_CACHE_DIR}/analysis/${cache_key}.json"
        if [[ -f "$cached_file" ]]; then
            rm -f "$cached_file"
            invalidated=1
            echo "[incremental-understanding] Invalidated cache for: ${rel_path}"
        else
            echo "[incremental-understanding] No cache entry for: ${rel_path}"
        fi
    fi

    IU_FILES_INVALIDATED=$((IU_FILES_INVALIDATED + invalidated))
    return 0
}

# =============================================================================
# キャッシュ統計
# =============================================================================
_iu_cache_stats() {
    local total_cached
    total_cached=$(find "${IU_CACHE_DIR}/analysis" -name "*.json" 2>/dev/null | wc -l | tr -d ' ')
    local cache_size
    cache_size=$(du -sh "${IU_CACHE_DIR}" 2>/dev/null | cut -f1 || echo "0B")

    local last_commit="none"
    [[ -f "${IU_LAST_COMMIT_FILE}" ]] && last_commit=$(cat "${IU_LAST_COMMIT_FILE}" 2>/dev/null | head -c 8)

    # ファイルタイプ別カウント
    local api_count=0 page_count=0 component_count=0 utility_count=0 other_count=0
    while IFS= read -r cache_file; do
        [[ -z "$cache_file" ]] && continue
        local ft
        ft=$(grep -oE '"file_type":"[^"]*"' "$cache_file" 2>/dev/null | sed 's/"file_type":"//;s/"//' | head -1)
        case "$ft" in
            api_route)  api_count=$((api_count + 1)) ;;
            page)       page_count=$((page_count + 1)) ;;
            component)  component_count=$((component_count + 1)) ;;
            utility)    utility_count=$((utility_count + 1)) ;;
            *)          other_count=$((other_count + 1)) ;;
        esac
    done < <(find "${IU_CACHE_DIR}/analysis" -name "*.json" 2>/dev/null)

    cat <<STATS
{
  "total_cached_files": ${total_cached},
  "cache_size": "${cache_size}",
  "last_commit": "${last_commit}",
  "by_type": {
    "api_routes": ${api_count},
    "pages": ${page_count},
    "components": ${component_count},
    "utilities": ${utility_count},
    "other": ${other_count}
  },
  "session_stats": {
    "files_analyzed": ${IU_FILES_ANALYZED},
    "cache_hits": ${IU_CACHE_HITS},
    "cache_misses": ${IU_CACHE_MISSES},
    "invalidated": ${IU_FILES_INVALIDATED}
  }
}
STATS
}

# =============================================================================
# プロンプト注入: キャッシュベースのコンテキスト生成
# =============================================================================
_iu_inject_context() {
    local prompt="${1:-}"
    local project_dir="${2:-${PROJECT_DIR:-./output}}"

    local stats
    stats=$(_iu_cache_stats)

    local cached_summary
    cached_summary=$(_iu_get_all_cached "$project_dir")

    cat <<INJECTION
## [Incremental Understanding] プロジェクト理解キャッシュ

### キャッシュ統計:
${stats}

### ファイルインデックス（キャッシュ済み）:
${cached_summary}

### ルール:
1. **変更ファイルのみ再解析**: git diffで変更を検出し、未変更ファイルはキャッシュを使用
2. **型定義参照**: キャッシュされた型情報を活用し、型の不一致を防ぐ
3. **API呼び出し一貫性**: キャッシュされたAPI情報でfetch先とルートの一致を検証
4. **インポートグラフ**: キャッシュされたインポート情報で循環依存を予防
INJECTION

    echo "$prompt"
}

# =============================================================================
# 完全ビルド: 全ファイルスキャン（初回用）
# =============================================================================
_iu_full_build() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    [[ "$IU_INITIALIZED" != "true" ]] && iu_init

    echo "[incremental-understanding] Full build: scanning all source files..."
    _iu_init_cache "$project_dir"

    local total=0
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        [[ ! -f "$file" ]] && continue
        _iu_save_file_cache "$file" "$project_dir"
        total=$((total + 1))
        # 進捗表示（100ファイルごと）
        if [[ $((total % 100)) -eq 0 ]]; then
            echo "[incremental-understanding] Progress: ${total} files analyzed..." >&2
        fi
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) 2>/dev/null | grep -v node_modules | grep -v '.next' | grep -v dist | sort)

    IU_FILES_ANALYZED=$total
    echo "[incremental-understanding] Full build complete: ${total} files analyzed and cached"
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
iu_report() {
    echo -e "\n  ${BOLD:-}=== incremental-understanding v${IU_VERSION} ===${NC:-}"
    echo -e "  解析ファイル数     : ${IU_FILES_ANALYZED}"
    echo -e "  キャッシュ済み     : ${IU_FILES_CACHED}"
    echo -e "  キャッシュヒット   : ${IU_CACHE_HITS}"
    echo -e "  キャッシュミス     : ${IU_CACHE_MISSES}"
    echo -e "  無効化済み         : ${IU_FILES_INVALIDATED}"
    echo -e "  エラー             : ${IU_ERRORS}"
    if [[ $IU_CACHE_HITS -gt 0 || $IU_CACHE_MISSES -gt 0 ]]; then
        local total_access=$((IU_CACHE_HITS + IU_CACHE_MISSES))
        local hit_rate=0
        [[ $total_access -gt 0 ]] && hit_rate=$((IU_CACHE_HITS * 100 / total_access))
        echo -e "  ヒット率           : ${hit_rate}%"
    fi
}

iu_score() {
    if [[ ${IU_FILES_ANALYZED} -gt 0 ]] && [[ ${IU_ERRORS} -eq 0 ]]; then
        local total_access=$((IU_CACHE_HITS + IU_CACHE_MISSES))
        if [[ $total_access -gt 0 ]]; then
            local hit_rate=$((IU_CACHE_HITS * 100 / total_access))
            if [[ $hit_rate -ge 80 ]]; then
                echo "95"
            elif [[ $hit_rate -ge 50 ]]; then
                echo "85"
            else
                echo "75"
            fi
        else
            echo "80"
        fi
    elif [[ ${IU_FILES_ANALYZED} -gt 0 ]]; then
        echo "65"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "incremental-understanding" --version "209.0" \
        --description "増分解析キャッシュ×git差分検出×変更ファイルのみ再解析" \
        --init "iu_init" --report "iu_report" --score "iu_score" \
        --enable-var "ENABLE_INCREMENTAL_UNDERSTANDING" \
        --cli-flags "--incremental-understanding:--no-incremental-understanding"
fi

# v2003.1: source時のexit codeを確実に0にする
true
