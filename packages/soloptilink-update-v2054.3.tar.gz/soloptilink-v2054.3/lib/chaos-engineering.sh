#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - Chaos Engineering Engine
# =============================================================================
# カオスエンジニアリング×障害注入×サーキットブレーカー×リトライ×バルクヘッド
#
# 機能:
#   - 障害注入ミドルウェア（ランダムレイテンシ/エラー/タイムアウト）
#   - サーキットブレーカー（Closed/Open/Half-Open状態遷移）
#   - リトライ+ジッタ（指数バックオフ）
#   - タイムアウトハンドラ（AbortController）
#   - バルクヘッド（リソース分離）
#   - カオステストスイート
#   - レジリエンスレポート
#
# 全globals: CE_ prefix
# =============================================================================

[[ -n "${_CE_LOADED:-}" ]] && return 0; _CE_LOADED=1

# =============================================================================
# State
# =============================================================================
CE_VERSION="140.0"
CE_GENERATED=0
CE_ERRORS=0
CE_PHASE="chaos_test"
CE_FILES_CREATED=()

# =============================================================================
# Helper
# =============================================================================
_ce_write_file() {
    local filepath="$1"
    local content="$2"
    local dir
    dir="$(dirname "$filepath")"
    mkdir -p "$dir" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        CE_FILES_CREATED+=("$filepath")
        CE_GENERATED=$((CE_GENERATED + 1))
        echo -e "  ${GREEN:-\033[0;32m}[CE]${NC:-\033[0m} Created: ${filepath##*/}"
    else
        CE_ERRORS=$((CE_ERRORS + 1))
        echo -e "  ${RED:-\033[0;31m}[CE]${NC:-\033[0m} Failed: ${filepath##*/}"
    fi
}

# =============================================================================
# 初期化
# =============================================================================
ce_init() {
    CE_GENERATED=0
    CE_ERRORS=0
    CE_FILES_CREATED=()
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} Chaos Engineering Engine v${CE_VERSION}"
    return 0
}

# =============================================================================
# Fault Injection Middleware
# =============================================================================
ce_generate_fault_injection() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/lib/fault-injection.ts"

    _ce_write_file "$target" "$(cat <<'TYPESCRIPT'
import { NextRequest, NextResponse } from 'next/server';

// ---------------------------------------------------------------------------
// Fault Injection Config
// ---------------------------------------------------------------------------
interface FaultConfig {
  enabled: boolean;
  latency: { enabled: boolean; minMs: number; maxMs: number; probability: number };
  error: { enabled: boolean; statusCode: number; probability: number };
  timeout: { enabled: boolean; probability: number };
  excludePaths: string[];
}

const defaultConfig: FaultConfig = {
  enabled: process.env.CHAOS_ENABLED === 'true',
  latency: {
    enabled: true,
    minMs: 100,
    maxMs: 3000,
    probability: 0.1, // 10% of requests
  },
  error: {
    enabled: true,
    statusCode: 500,
    probability: 0.05, // 5% of requests
  },
  timeout: {
    enabled: true,
    probability: 0.02, // 2% of requests
  },
  excludePaths: ['/api/health', '/api/auth/login', '/_next'],
};

function shouldInject(probability: number): boolean {
  return Math.random() < probability;
}

function randomBetween(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// ---------------------------------------------------------------------------
// Middleware
// ---------------------------------------------------------------------------
export function withFaultInjection(
  handler: (req: NextRequest) => Promise<NextResponse>,
  config: Partial<FaultConfig> = {}
) {
  const cfg: FaultConfig = { ...defaultConfig, ...config };

  return async function faultHandler(req: NextRequest): Promise<NextResponse> {
    if (!cfg.enabled) return handler(req);

    const path = req.nextUrl.pathname;
    if (cfg.excludePaths.some((p) => path.startsWith(p))) {
      return handler(req);
    }

    // Inject random error
    if (cfg.error.enabled && shouldInject(cfg.error.probability)) {
      console.warn(`[Chaos] Injected error ${cfg.error.statusCode} for ${req.method} ${path}`);
      return NextResponse.json(
        { error: 'Chaos: Injected failure', chaos: true },
        { status: cfg.error.statusCode }
      );
    }

    // Inject timeout (no response)
    if (cfg.timeout.enabled && shouldInject(cfg.timeout.probability)) {
      console.warn(`[Chaos] Injected timeout for ${req.method} ${path}`);
      await new Promise((resolve) => setTimeout(resolve, 30000));
      return NextResponse.json({ error: 'Chaos: Timeout' }, { status: 504 });
    }

    // Inject latency
    if (cfg.latency.enabled && shouldInject(cfg.latency.probability)) {
      const delay = randomBetween(cfg.latency.minMs, cfg.latency.maxMs);
      console.warn(`[Chaos] Injected ${delay}ms latency for ${req.method} ${path}`);
      await new Promise((resolve) => setTimeout(resolve, delay));
    }

    return handler(req);
  };
}
TYPESCRIPT
)"
}

# =============================================================================
# Circuit Breaker
# =============================================================================
ce_generate_circuit_breaker() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/lib/circuit-breaker.ts"

    _ce_write_file "$target" "$(cat <<'TYPESCRIPT'
// ---------------------------------------------------------------------------
// Circuit Breaker Pattern
// ---------------------------------------------------------------------------
// States: CLOSED (normal) -> OPEN (failing) -> HALF_OPEN (testing recovery)
// ---------------------------------------------------------------------------

type CircuitState = 'CLOSED' | 'OPEN' | 'HALF_OPEN';

interface CircuitBreakerOptions {
  failureThreshold: number;      // failures before opening
  successThreshold: number;      // successes in half-open before closing
  timeout: number;               // ms to wait before half-open
  resetTimeout?: number;         // ms to reset failure count (sliding window)
  onStateChange?: (from: CircuitState, to: CircuitState, name: string) => void;
}

const DEFAULT_OPTIONS: CircuitBreakerOptions = {
  failureThreshold: 5,
  successThreshold: 2,
  timeout: 30000,
  resetTimeout: 60000,
};

export class CircuitBreaker {
  private state: CircuitState = 'CLOSED';
  private failureCount = 0;
  private successCount = 0;
  private lastFailureTime = 0;
  private nextAttemptTime = 0;
  private options: CircuitBreakerOptions;
  private name: string;

  constructor(name: string, options: Partial<CircuitBreakerOptions> = {}) {
    this.name = name;
    this.options = { ...DEFAULT_OPTIONS, ...options };
  }

  async execute<T>(fn: () => Promise<T>): Promise<T> {
    if (this.state === 'OPEN') {
      if (Date.now() >= this.nextAttemptTime) {
        this.transition('HALF_OPEN');
      } else {
        throw new CircuitBreakerError(
          `Circuit breaker '${this.name}' is OPEN. Retry after ${new Date(this.nextAttemptTime).toISOString()}`,
          this.name, this.state
        );
      }
    }

    try {
      const result = await fn();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }

  private onSuccess(): void {
    if (this.state === 'HALF_OPEN') {
      this.successCount++;
      if (this.successCount >= this.options.successThreshold) {
        this.transition('CLOSED');
      }
    }
    this.failureCount = 0;
  }

  private onFailure(): void {
    this.failureCount++;
    this.lastFailureTime = Date.now();

    if (this.state === 'HALF_OPEN') {
      this.transition('OPEN');
    } else if (this.failureCount >= this.options.failureThreshold) {
      this.transition('OPEN');
    }
  }

  private transition(newState: CircuitState): void {
    const oldState = this.state;
    this.state = newState;

    if (newState === 'OPEN') {
      this.nextAttemptTime = Date.now() + this.options.timeout;
      this.successCount = 0;
    } else if (newState === 'CLOSED') {
      this.failureCount = 0;
      this.successCount = 0;
    } else if (newState === 'HALF_OPEN') {
      this.successCount = 0;
    }

    this.options.onStateChange?.(oldState, newState, this.name);
    console.log(`[CircuitBreaker:${this.name}] ${oldState} -> ${newState}`);
  }

  getState(): CircuitState { return this.state; }
  getFailureCount(): number { return this.failureCount; }
  reset(): void { this.transition('CLOSED'); }
}

export class CircuitBreakerError extends Error {
  constructor(message: string, public circuitName: string, public circuitState: CircuitState) {
    super(message);
    this.name = 'CircuitBreakerError';
  }
}

// ---------------------------------------------------------------------------
// Circuit Breaker Registry (singleton per service)
// ---------------------------------------------------------------------------
const registry = new Map<string, CircuitBreaker>();

export function getCircuitBreaker(name: string, options?: Partial<CircuitBreakerOptions>): CircuitBreaker {
  if (!registry.has(name)) {
    registry.set(name, new CircuitBreaker(name, options));
  }
  return registry.get(name)!;
}
TYPESCRIPT
)"
}

# =============================================================================
# Retry with Jitter
# =============================================================================
ce_generate_retry_wrapper() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/lib/retry.ts"

    _ce_write_file "$target" "$(cat <<'TYPESCRIPT'
// ---------------------------------------------------------------------------
// Retry with Exponential Backoff + Jitter
// ---------------------------------------------------------------------------

export interface RetryOptions {
  maxRetries: number;
  baseDelayMs: number;
  maxDelayMs: number;
  jitter: boolean;
  retryOn?: (error: any) => boolean;
  onRetry?: (error: any, attempt: number, delayMs: number) => void;
}

const DEFAULT_RETRY: RetryOptions = {
  maxRetries: 3,
  baseDelayMs: 1000,
  maxDelayMs: 30000,
  jitter: true,
};

function calculateDelay(attempt: number, opts: RetryOptions): number {
  // Exponential backoff: base * 2^attempt
  const exponential = opts.baseDelayMs * Math.pow(2, attempt);
  const capped = Math.min(exponential, opts.maxDelayMs);

  if (opts.jitter) {
    // Full jitter: random between 0 and capped
    return Math.floor(Math.random() * capped);
  }

  return capped;
}

export async function withRetry<T>(
  fn: () => Promise<T>,
  options: Partial<RetryOptions> = {}
): Promise<T> {
  const opts: RetryOptions = { ...DEFAULT_RETRY, ...options };

  let lastError: any;

  for (let attempt = 0; attempt <= opts.maxRetries; attempt++) {
    try {
      return await fn();
    } catch (error) {
      lastError = error;

      // Check if we should retry this error
      if (opts.retryOn && !opts.retryOn(error)) {
        throw error;
      }

      if (attempt < opts.maxRetries) {
        const delay = calculateDelay(attempt, opts);
        opts.onRetry?.(error, attempt + 1, delay);
        console.warn(`[Retry] Attempt ${attempt + 1}/${opts.maxRetries} failed, retrying in ${delay}ms`);
        await new Promise((resolve) => setTimeout(resolve, delay));
      }
    }
  }

  throw lastError;
}

// Convenience: retry only on transient errors
export function isTransientError(error: any): boolean {
  if (error?.status) {
    return [408, 429, 500, 502, 503, 504].includes(error.status);
  }
  if (error?.code) {
    return ['ECONNRESET', 'ETIMEDOUT', 'ECONNREFUSED', 'EPIPE', 'EAI_AGAIN'].includes(error.code);
  }
  return false;
}

export async function withTransientRetry<T>(fn: () => Promise<T>, maxRetries = 3): Promise<T> {
  return withRetry(fn, { maxRetries, retryOn: isTransientError });
}
TYPESCRIPT
)"
}

# =============================================================================
# Timeout Handler (AbortController)
# =============================================================================
ce_generate_timeout_handler() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/lib/timeout.ts"

    _ce_write_file "$target" "$(cat <<'TYPESCRIPT'
// ---------------------------------------------------------------------------
// Timeout Handler with AbortController
// ---------------------------------------------------------------------------

export class TimeoutError extends Error {
  constructor(public timeoutMs: number, public operation: string) {
    super(`Operation '${operation}' timed out after ${timeoutMs}ms`);
    this.name = 'TimeoutError';
  }
}

export async function withTimeout<T>(
  fn: (signal: AbortSignal) => Promise<T>,
  timeoutMs: number,
  operation = 'unknown'
): Promise<T> {
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const result = await fn(controller.signal);
    return result;
  } catch (error: any) {
    if (error.name === 'AbortError' || controller.signal.aborted) {
      throw new TimeoutError(timeoutMs, operation);
    }
    throw error;
  } finally {
    clearTimeout(timer);
  }
}

// Fetch with timeout
export async function fetchWithTimeout(
  url: string,
  options: RequestInit & { timeoutMs?: number } = {}
): Promise<Response> {
  const { timeoutMs = 10000, ...fetchOptions } = options;

  return withTimeout(
    async (signal) => {
      const response = await fetch(url, { ...fetchOptions, signal });
      return response;
    },
    timeoutMs,
    `fetch ${url}`
  );
}

// Generic promise race with timeout
export async function raceTimeout<T>(
  promise: Promise<T>,
  timeoutMs: number,
  operation = 'promise'
): Promise<T> {
  return Promise.race([
    promise,
    new Promise<never>((_, reject) =>
      setTimeout(() => reject(new TimeoutError(timeoutMs, operation)), timeoutMs)
    ),
  ]);
}
TYPESCRIPT
)"
}

# =============================================================================
# Bulkhead Pattern
# =============================================================================
ce_generate_bulkhead() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/lib/bulkhead.ts"

    _ce_write_file "$target" "$(cat <<'TYPESCRIPT'
// ---------------------------------------------------------------------------
// Bulkhead Pattern - Resource Isolation
// ---------------------------------------------------------------------------
// Limits concurrent executions per named partition to prevent cascading failures

export class BulkheadError extends Error {
  constructor(public partition: string, public maxConcurrent: number, public queueSize: number) {
    super(`Bulkhead '${partition}' rejected: ${maxConcurrent} concurrent + ${queueSize} queued`);
    this.name = 'BulkheadError';
  }
}

interface QueueItem<T> {
  fn: () => Promise<T>;
  resolve: (value: T) => void;
  reject: (error: any) => void;
}

export class Bulkhead {
  private active = 0;
  private queue: Array<QueueItem<any>> = [];
  private name: string;
  private maxConcurrent: number;
  private maxQueue: number;

  constructor(name: string, maxConcurrent = 10, maxQueue = 50) {
    this.name = name;
    this.maxConcurrent = maxConcurrent;
    this.maxQueue = maxQueue;
  }

  async execute<T>(fn: () => Promise<T>): Promise<T> {
    if (this.active < this.maxConcurrent) {
      return this.run(fn);
    }

    if (this.queue.length >= this.maxQueue) {
      throw new BulkheadError(this.name, this.maxConcurrent, this.queue.length);
    }

    // Queue the request
    return new Promise<T>((resolve, reject) => {
      this.queue.push({ fn, resolve, reject });
    });
  }

  private async run<T>(fn: () => Promise<T>): Promise<T> {
    this.active++;
    try {
      return await fn();
    } finally {
      this.active--;
      this.dequeue();
    }
  }

  private dequeue(): void {
    if (this.queue.length > 0 && this.active < this.maxConcurrent) {
      const item = this.queue.shift()!;
      this.run(item.fn).then(item.resolve).catch(item.reject);
    }
  }

  getStats() {
    return {
      name: this.name,
      active: this.active,
      queued: this.queue.length,
      maxConcurrent: this.maxConcurrent,
      maxQueue: this.maxQueue,
      available: this.maxConcurrent - this.active,
    };
  }
}

// ---------------------------------------------------------------------------
// Registry
// ---------------------------------------------------------------------------
const bulkheads = new Map<string, Bulkhead>();

export function getBulkhead(name: string, maxConcurrent?: number, maxQueue?: number): Bulkhead {
  if (!bulkheads.has(name)) {
    bulkheads.set(name, new Bulkhead(name, maxConcurrent, maxQueue));
  }
  return bulkheads.get(name)!;
}
TYPESCRIPT
)"
}

# =============================================================================
# Chaos Test Suite
# =============================================================================
ce_generate_chaos_tests() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/tests/chaos/resilience.test.ts"

    _ce_write_file "$target" "$(cat <<'TYPESCRIPT'
import { describe, it, expect, beforeEach } from 'vitest';
import { CircuitBreaker, CircuitBreakerError } from '@/lib/circuit-breaker';
import { withRetry, isTransientError } from '@/lib/retry';
import { withTimeout, TimeoutError } from '@/lib/timeout';
import { Bulkhead, BulkheadError } from '@/lib/bulkhead';

describe('Chaos Engineering - Resilience Tests', () => {
  // -----------------------------------------------------------------------
  // Circuit Breaker
  // -----------------------------------------------------------------------
  describe('CircuitBreaker', () => {
    let cb: CircuitBreaker;

    beforeEach(() => {
      cb = new CircuitBreaker('test', { failureThreshold: 3, successThreshold: 1, timeout: 100 });
    });

    it('stays CLOSED on success', async () => {
      const result = await cb.execute(async () => 'ok');
      expect(result).toBe('ok');
      expect(cb.getState()).toBe('CLOSED');
    });

    it('opens after threshold failures', async () => {
      const fail = async () => { throw new Error('fail'); };

      for (let i = 0; i < 3; i++) {
        await cb.execute(fail).catch(() => {});
      }

      expect(cb.getState()).toBe('OPEN');
      await expect(cb.execute(async () => 'ok')).rejects.toThrow(CircuitBreakerError);
    });

    it('transitions to HALF_OPEN after timeout', async () => {
      const fail = async () => { throw new Error('fail'); };
      for (let i = 0; i < 3; i++) await cb.execute(fail).catch(() => {});

      await new Promise((r) => setTimeout(r, 150)); // wait for timeout

      const result = await cb.execute(async () => 'recovered');
      expect(result).toBe('recovered');
      expect(cb.getState()).toBe('CLOSED');
    });
  });

  // -----------------------------------------------------------------------
  // Retry
  // -----------------------------------------------------------------------
  describe('Retry with Backoff', () => {
    it('succeeds on first try', async () => {
      const result = await withRetry(async () => 42);
      expect(result).toBe(42);
    });

    it('retries on transient failure then succeeds', async () => {
      let attempts = 0;
      const result = await withRetry(async () => {
        attempts++;
        if (attempts < 3) throw { status: 503 };
        return 'ok';
      }, { maxRetries: 3, baseDelayMs: 10, retryOn: isTransientError });

      expect(result).toBe('ok');
      expect(attempts).toBe(3);
    });

    it('throws after max retries', async () => {
      await expect(withRetry(
        async () => { throw new Error('persistent'); },
        { maxRetries: 2, baseDelayMs: 10 }
      )).rejects.toThrow('persistent');
    });
  });

  // -----------------------------------------------------------------------
  // Timeout
  // -----------------------------------------------------------------------
  describe('Timeout Handler', () => {
    it('resolves before timeout', async () => {
      const result = await withTimeout(async () => 'fast', 1000, 'test');
      expect(result).toBe('fast');
    });

    it('throws TimeoutError on slow operation', async () => {
      await expect(withTimeout(
        async () => new Promise((r) => setTimeout(r, 5000)),
        50, 'slow-op'
      )).rejects.toThrow(TimeoutError);
    });
  });

  // -----------------------------------------------------------------------
  // Bulkhead
  // -----------------------------------------------------------------------
  describe('Bulkhead', () => {
    it('allows concurrent up to limit', async () => {
      const bh = new Bulkhead('test', 2, 5);
      const results = await Promise.all([
        bh.execute(async () => 1),
        bh.execute(async () => 2),
      ]);
      expect(results).toEqual([1, 2]);
    });

    it('rejects when queue full', async () => {
      const bh = new Bulkhead('test', 1, 1);
      const slow = () => new Promise((r) => setTimeout(r, 1000));

      bh.execute(slow); // active
      bh.execute(slow); // queued

      await expect(bh.execute(slow)).rejects.toThrow(BulkheadError);
    });
  });
});
TYPESCRIPT
)"
}

# =============================================================================
# Resilience Report
# =============================================================================
ce_generate_resilience_report() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/lib/resilience-report.ts"

    _ce_write_file "$target" "$(cat <<'TYPESCRIPT'
import { getCircuitBreaker } from './circuit-breaker';
import { getBulkhead } from './bulkhead';

export interface ResilienceReport {
  timestamp: string;
  circuits: Array<{ name: string; state: string; failures: number }>;
  bulkheads: Array<{ name: string; active: number; queued: number; available: number }>;
  score: number; // 0-100
  recommendations: string[];
}

export function generateResilienceReport(
  circuitNames: string[],
  bulkheadNames: string[]
): ResilienceReport {
  const circuits = circuitNames.map((name) => {
    const cb = getCircuitBreaker(name);
    return { name, state: cb.getState(), failures: cb.getFailureCount() };
  });

  const bulkheads = bulkheadNames.map((name) => {
    const bh = getBulkhead(name);
    const stats = bh.getStats();
    return { name, active: stats.active, queued: stats.queued, available: stats.available };
  });

  // Calculate score
  let score = 100;
  const recommendations: string[] = [];

  for (const c of circuits) {
    if (c.state === 'OPEN') {
      score -= 30;
      recommendations.push(`Circuit '${c.name}' is OPEN - investigate upstream service`);
    } else if (c.state === 'HALF_OPEN') {
      score -= 10;
    }
    if (c.failures > 0) score -= c.failures * 2;
  }

  for (const b of bulkheads) {
    if (b.available === 0) {
      score -= 20;
      recommendations.push(`Bulkhead '${b.name}' is at capacity - consider scaling`);
    }
    if (b.queued > 0) score -= b.queued;
  }

  return {
    timestamp: new Date().toISOString(),
    circuits,
    bulkheads,
    score: Math.max(0, Math.min(100, score)),
    recommendations,
  };
}
TYPESCRIPT
)"
}

# =============================================================================
# Inject chaos patterns into Claude prompt
# =============================================================================
ce_inject_chaos_patterns() {
    local prompt="${1:-}"

    cat <<'PATTERNS'

## [CHAOS] レジリエンスパターン（必須準拠）

### サーキットブレーカー
- `getCircuitBreaker(name).execute(fn)` - 外部サービス呼び出しをラップ
- CLOSED(正常) -> OPEN(失敗多発) -> HALF_OPEN(回復テスト) -> CLOSED
- failureThreshold: 5回失敗でOPEN、timeout: 30秒でHALF_OPEN

### リトライ
- `withRetry(fn, { maxRetries: 3, jitter: true })` - 指数バックオフ+ジッタ
- `withTransientRetry(fn)` - 一時的エラー(408/429/5xx)のみリトライ
- `isTransientError(error)` - エラー判定

### タイムアウト
- `withTimeout(fn, ms, name)` - AbortController活用
- `fetchWithTimeout(url, { timeoutMs: 10000 })` - fetch+タイムアウト

### バルクヘッド
- `getBulkhead(name, maxConcurrent, maxQueue).execute(fn)`
- リソース枯渇防止（DB接続プール、外部API等）

### 障害注入（テスト用）
- `withFaultInjection(handler)` - CHAOS_ENABLED=true で有効化
- ランダムレイテンシ(10%) / エラー(5%) / タイムアウト(2%)
PATTERNS

    echo "$prompt"
}

# =============================================================================
# Report
# =============================================================================
ce_report() {
    echo -e "\n  ${BOLD:-}=== Chaos Engineering Engine v${CE_VERSION} ===${NC:-}"
    echo -e "  生成数: ${CE_GENERATED}"
    echo -e "  エラー: ${CE_ERRORS}"
    if [[ ${#CE_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${CE_FILES_CREATED[@]}"; do
            echo -e "    - ${f}"
        done
    fi
}

ce_score() {
    if [[ ${CE_GENERATED} -ge 5 ]] && [[ ${CE_ERRORS} -eq 0 ]]; then
        echo "95"
    elif [[ ${CE_GENERATED} -gt 0 ]] && [[ ${CE_ERRORS} -eq 0 ]]; then
        echo "90"
    elif [[ ${CE_GENERATED} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "chaos-engineering" --version "140.0" \
        --description "カオスエンジニアリング×障害注入×サーキットブレーカー×リトライ×バルクヘッド" \
        --init "ce_init" --report "ce_report" --score "ce_score" \
        --enable-var "ENABLE_CHAOS" --cli-flags "--chaos:--no-chaos"
fi

# v2003.1: source時のexit codeを確実に0にする
true
