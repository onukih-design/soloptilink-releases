#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v323.0 - Kubernetes Manifest Generator
# =============================================================================
# Deployment/Service/Ingress/HPA/Helm Chart自動生成。
# プロジェクト構造からリソース要件を推定、本番グレードのマニフェストを出力。
#
# Functions:
#   _kmg_init()                - Initialize
#   _kmg_generate_deployment() - Generate K8s Deployment + ConfigMap
#   _kmg_generate_service()    - Generate Service + Ingress
#   _kmg_generate_helm()       - Generate Helm chart scaffold
#   _kmg_report() / _kmg_score()
# =============================================================================

[[ -n "${_KMG_LOADED:-}" ]] && return 0; _KMG_LOADED=1

readonly _KMG_RED='\033[0;31m'
readonly _KMG_GREEN='\033[0;32m'
readonly _KMG_YELLOW='\033[0;33m'
readonly _KMG_CYAN='\033[0;36m'
readonly _KMG_NC='\033[0m'

declare -g KMG_VERSION="323.0"
KMG_GENERATED=0
KMG_ERRORS=0
KMG_FILES_WRITTEN=0
KMG_DEPLOYMENT_OK=false
KMG_SERVICE_OK=false
KMG_HELM_OK=false

_kmg_init() {
    KMG_GENERATED=0; KMG_ERRORS=0; KMG_FILES_WRITTEN=0
    KMG_DEPLOYMENT_OK=false; KMG_SERVICE_OK=false; KMG_HELM_OK=false
    echo -e "  ${_KMG_GREEN}OK${_KMG_NC} K8s Manifest Generator v${KMG_VERSION}" >&2
    return 0
}

_kmg_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { KMG_FILES_WRITTEN=$((KMG_FILES_WRITTEN + 1)); return 0; }
    KMG_ERRORS=$((KMG_ERRORS + 1)); return 1
}

_kmg_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_KMG_CYAN}[k8s]${_KMG_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_KMG_GREEN}[k8s]${_KMG_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_KMG_YELLOW}[k8s]${_KMG_NC} $msg" >&2 ;;
        error) echo -e "  ${_KMG_RED}[k8s]${_KMG_NC} $msg" >&2 ;;
    esac
}

# =============================================================================
# Generate Deployment + ConfigMap + HPA
# =============================================================================
_kmg_generate_deployment() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local app_name="${2:-app}"
    local namespace="${3:-default}"
    local k8s_dir="${project_dir}/k8s"

    _kmg_log info "Generating K8s Deployment for ${app_name}..."

    # Deployment
    _kmg_write_file "${k8s_dir}/deployment.yaml" "$(cat <<YAML
apiVersion: apps/v1
kind: Deployment
metadata:
  name: ${app_name}
  namespace: ${namespace}
  labels:
    app: ${app_name}
    version: v1
spec:
  replicas: 2
  selector:
    matchLabels:
      app: ${app_name}
  strategy:
    type: RollingUpdate
    rollingUpdate:
      maxSurge: 1
      maxUnavailable: 0
  template:
    metadata:
      labels:
        app: ${app_name}
        version: v1
    spec:
      serviceAccountName: ${app_name}
      securityContext:
        runAsNonRoot: true
        runAsUser: 1001
        fsGroup: 1001
      containers:
        - name: ${app_name}
          image: \${IMAGE_REPO}/${app_name}:latest
          ports:
            - containerPort: 3000
              protocol: TCP
          env:
            - name: NODE_ENV
              value: production
            - name: DATABASE_URL
              valueFrom:
                secretKeyRef:
                  name: ${app_name}-secrets
                  key: database-url
          resources:
            requests:
              cpu: 100m
              memory: 128Mi
            limits:
              cpu: 500m
              memory: 512Mi
          readinessProbe:
            httpGet:
              path: /api/health
              port: 3000
            initialDelaySeconds: 5
            periodSeconds: 10
          livenessProbe:
            httpGet:
              path: /api/health
              port: 3000
            initialDelaySeconds: 15
            periodSeconds: 20
          lifecycle:
            preStop:
              exec:
                command: ["/bin/sh", "-c", "sleep 5"]
      terminationGracePeriodSeconds: 30
YAML
)"

    # HPA
    _kmg_write_file "${k8s_dir}/hpa.yaml" "$(cat <<YAML
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: ${app_name}-hpa
  namespace: ${namespace}
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: ${app_name}
  minReplicas: 2
  maxReplicas: 10
  metrics:
    - type: Resource
      resource:
        name: cpu
        target:
          type: Utilization
          averageUtilization: 70
    - type: Resource
      resource:
        name: memory
        target:
          type: Utilization
          averageUtilization: 80
  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
        - type: Pods
          value: 1
          periodSeconds: 60
YAML
)"

    # ConfigMap
    _kmg_write_file "${k8s_dir}/configmap.yaml" "$(cat <<YAML
apiVersion: v1
kind: ConfigMap
metadata:
  name: ${app_name}-config
  namespace: ${namespace}
data:
  LOG_LEVEL: "info"
  CORS_ORIGIN: "https://${app_name}.example.com"
  RATE_LIMIT_MAX: "100"
  RATE_LIMIT_WINDOW: "60000"
YAML
)"

    # ServiceAccount
    _kmg_write_file "${k8s_dir}/serviceaccount.yaml" "$(cat <<YAML
apiVersion: v1
kind: ServiceAccount
metadata:
  name: ${app_name}
  namespace: ${namespace}
  annotations:
    eks.amazonaws.com/role-arn: arn:aws:iam::role/${app_name}-role
YAML
)"

    _kmg_log ok "Deployment + HPA + ConfigMap generated"
    KMG_DEPLOYMENT_OK=true
    KMG_GENERATED=$((KMG_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate Service + Ingress
# =============================================================================
_kmg_generate_service() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local app_name="${2:-app}"
    local namespace="${3:-default}"
    local domain="${4:-app.example.com}"
    local k8s_dir="${project_dir}/k8s"

    _kmg_log info "Generating K8s Service + Ingress..."

    _kmg_write_file "${k8s_dir}/service.yaml" "$(cat <<YAML
apiVersion: v1
kind: Service
metadata:
  name: ${app_name}
  namespace: ${namespace}
  labels:
    app: ${app_name}
spec:
  type: ClusterIP
  ports:
    - port: 80
      targetPort: 3000
      protocol: TCP
      name: http
  selector:
    app: ${app_name}
YAML
)"

    _kmg_write_file "${k8s_dir}/ingress.yaml" "$(cat <<YAML
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: ${app_name}-ingress
  namespace: ${namespace}
  annotations:
    kubernetes.io/ingress.class: nginx
    cert-manager.io/cluster-issuer: letsencrypt-prod
    nginx.ingress.kubernetes.io/rate-limit: "100"
    nginx.ingress.kubernetes.io/ssl-redirect: "true"
    nginx.ingress.kubernetes.io/proxy-body-size: "10m"
spec:
  tls:
    - hosts:
        - ${domain}
      secretName: ${app_name}-tls
  rules:
    - host: ${domain}
      http:
        paths:
          - path: /
            pathType: Prefix
            backend:
              service:
                name: ${app_name}
                port:
                  number: 80
YAML
)"

    # NetworkPolicy
    _kmg_write_file "${k8s_dir}/networkpolicy.yaml" "$(cat <<YAML
apiVersion: networking.k8s.io/v1
kind: NetworkPolicy
metadata:
  name: ${app_name}-netpol
  namespace: ${namespace}
spec:
  podSelector:
    matchLabels:
      app: ${app_name}
  policyTypes:
    - Ingress
    - Egress
  ingress:
    - from:
        - namespaceSelector:
            matchLabels:
              name: ingress-nginx
      ports:
        - protocol: TCP
          port: 3000
  egress:
    - to: []
      ports:
        - protocol: TCP
          port: 5432
        - protocol: TCP
          port: 6379
        - protocol: TCP
          port: 443
YAML
)"

    _kmg_log ok "Service + Ingress + NetworkPolicy generated"
    KMG_SERVICE_OK=true
    KMG_GENERATED=$((KMG_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate Helm Chart
# =============================================================================
_kmg_generate_helm() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local app_name="${2:-app}"
    local helm_dir="${project_dir}/helm/${app_name}"

    _kmg_log info "Generating Helm chart for ${app_name}..."

    _kmg_write_file "${helm_dir}/Chart.yaml" "$(cat <<YAML
apiVersion: v2
name: ${app_name}
description: Helm chart for ${app_name}
type: application
version: 0.1.0
appVersion: "1.0.0"
YAML
)"

    _kmg_write_file "${helm_dir}/values.yaml" "$(cat <<YAML
replicaCount: 2
image:
  repository: ${app_name}
  pullPolicy: IfNotPresent
  tag: latest
service:
  type: ClusterIP
  port: 80
  targetPort: 3000
ingress:
  enabled: true
  className: nginx
  host: ${app_name}.example.com
  tls: true
resources:
  limits:
    cpu: 500m
    memory: 512Mi
  requests:
    cpu: 100m
    memory: 128Mi
autoscaling:
  enabled: true
  minReplicas: 2
  maxReplicas: 10
  targetCPU: 70
env:
  NODE_ENV: production
secrets:
  databaseUrl: ""
YAML
)"

    _kmg_write_file "${helm_dir}/templates/deployment.yaml" '{{- $fullName := include "app.fullname" . -}}
apiVersion: apps/v1
kind: Deployment
metadata:
  name: {{ $fullName }}
  labels:
    {{- include "app.labels" . | nindent 4 }}
spec:
  replicas: {{ .Values.replicaCount }}
  selector:
    matchLabels:
      {{- include "app.selectorLabels" . | nindent 6 }}
  template:
    metadata:
      labels:
        {{- include "app.selectorLabels" . | nindent 8 }}
    spec:
      containers:
        - name: {{ .Chart.Name }}
          image: "{{ .Values.image.repository }}:{{ .Values.image.tag }}"
          ports:
            - containerPort: {{ .Values.service.targetPort }}
          resources:
            {{- toYaml .Values.resources | nindent 12 }}'

    _kmg_write_file "${helm_dir}/templates/_helpers.tpl" '{{- define "app.fullname" -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" }}
{{- end }}
{{- define "app.labels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end }}
{{- define "app.selectorLabels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}'

    _kmg_log ok "Helm chart generated: ${helm_dir}"
    KMG_HELM_OK=true
    KMG_GENERATED=$((KMG_GENERATED + 1))
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_kmg_report() {
    echo -e "\n  ${_KMG_CYAN}=== K8s Manifest Generator v${KMG_VERSION} ===${_KMG_NC}"
    echo -e "  Generated: ${KMG_GENERATED} | Files: ${KMG_FILES_WRITTEN} | Errors: ${KMG_ERRORS}"
    echo -e "  Deployment: $( ${KMG_DEPLOYMENT_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Service: $( ${KMG_SERVICE_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Helm: $( ${KMG_HELM_OK} && echo 'OK' || echo 'SKIP')"
}

_kmg_score() {
    local score=50
    ${KMG_DEPLOYMENT_OK} && score=$((score + 15))
    ${KMG_SERVICE_OK} && score=$((score + 15))
    ${KMG_HELM_OK} && score=$((score + 15))
    [[ ${KMG_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "k8s-manifest-generator" --version "323.0" \
        --description "K8sマニフェスト自動生成 Deployment/Service/Helm (v323)" \
        --init "_kmg_init" --report "_kmg_report" --score "_kmg_score" \
        --enable-var "ENABLE_K8S_MANIFEST" --cli-flags "--k8s-manifest:--no-k8s-manifest"
fi

# v2003.1: source時のexit codeを確実に0にする
true
