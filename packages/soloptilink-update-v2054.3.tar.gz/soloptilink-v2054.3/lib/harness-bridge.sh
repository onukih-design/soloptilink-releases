#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2009.0 - Harness Bridge
# ハーネステストとSoloptiLinkAI本体の双方向連携モジュール
#
# 機能:
#   - ハーネス実行結果の取り込み・品質スコア反映
#   - テスト失敗→自動修復パイプライン連携
#   - プロジェクトディレクトリ↔本体の同期チェック
#   - ハーネスからのヘルスレポート統合
# =============================================================================

HB_VERSION="2009.0"

# Ensure _log exists
if ! declare -f _log &>/dev/null; then
    _log() { echo "[$1] $2" >&2; }
fi

# ─── 設定 ─────────────────────────────────────────────────

HB_HARNESS_DIR=""  # ハーネスのあるディレクトリ (自動検出)
HB_REPORTS_DIR=""
HB_LAST_SCORE=0
HB_LAST_FAILURES=()

# ─── ハーネス自動検出 ─────────────────────────────────────

hb_detect_harness() {
    local search_dirs=(
        "${PROJECT_ROOT:-.}"
        "${SOLOPTILINK_DIR:-$HOME/.soloptilink}/.."
        "$HOME/Downloads/社内システム開発/クロードコード上位互換開発"
    )
    for dir in "${search_dirs[@]}"; do
        if [[ -f "$dir/harness.sh" ]]; then
            HB_HARNESS_DIR="$dir"
            HB_REPORTS_DIR="$dir/.harness/reports"
            _log "INFO" "[HarnessBridge] ハーネス検出: $dir/harness.sh"
            return 0
        fi
    done
    _log "WARN" "[HarnessBridge] ハーネスが見つかりません"
    return 1
}

# ─── 最新テスト結果の取得 ──────────────────────────────────

hb_get_latest_results() {
    [[ -z "$HB_REPORTS_DIR" ]] && hb_detect_harness
    [[ -z "$HB_REPORTS_DIR" ]] && return 1

    local latest
    latest=$(ls -td "$HB_REPORTS_DIR"/*/ 2>/dev/null | head -1)
    [[ -z "$latest" ]] && return 1

    local results_file="$latest/results.txt"
    [[ -f "$results_file" ]] || return 1

    echo "$results_file"
}

# ─── テストスコア取得 ──────────────────────────────────────

hb_get_score() {
    local results
    results=$(hb_get_latest_results) || return 1

    local total=0 passed=0
    while IFS= read -r line; do
        if [[ "$line" =~ ^suite: ]]; then
            local t p
            t=$(echo "$line" | grep -o 'total:[0-9]*' | cut -d: -f2)
            p=$(echo "$line" | grep -o 'passed:[0-9]*' | cut -d: -f2)
            total=$((total + t))
            passed=$((passed + p))
        fi
    done < "$results"

    [[ $total -eq 0 ]] && { echo "0"; return; }
    HB_LAST_SCORE=$((passed * 100 / total))
    echo "$HB_LAST_SCORE"
}

# ─── 失敗テスト抽出 ───────────────────────────────────────

hb_get_failures() {
    local results_dir
    results_dir=$(dirname "$(hb_get_latest_results 2>/dev/null)") || return 1

    local tap_file="$results_dir/bats.tap"
    [[ -f "$tap_file" ]] || return 1

    HB_LAST_FAILURES=()
    while IFS= read -r line; do
        if [[ "$line" =~ ^"not ok" ]]; then
            HB_LAST_FAILURES+=("$line")
        fi
    done < "$tap_file"

    printf '%s\n' "${HB_LAST_FAILURES[@]}"
}

# ─── 同期チェック ─────────────────────────────────────────

hb_sync_check() {
    local project_dir="${1:-}"
    local sl_dir="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"

    [[ -z "$project_dir" ]] && project_dir=$(hb_detect_harness && echo "$HB_HARNESS_DIR")
    [[ -z "$project_dir" || ! -d "$project_dir/lib" ]] && return 1

    local out_of_sync=0
    local checked=0
    local synced=0

    # lib/ 以下の .sh ファイルを比較
    while IFS= read -r -d '' sl_file; do
        local rel="${sl_file#$sl_dir/}"
        local proj_file="$project_dir/$rel"
        checked=$((checked + 1))

        if [[ ! -f "$proj_file" ]]; then
            out_of_sync=$((out_of_sync + 1))
        elif ! diff -q "$sl_file" "$proj_file" &>/dev/null; then
            out_of_sync=$((out_of_sync + 1))
        else
            synced=$((synced + 1))
        fi
    done < <(find "$sl_dir/lib" -name "*.sh" -print0 2>/dev/null)

    echo "checked:$checked synced:$synced out_of_sync:$out_of_sync"
    [[ $out_of_sync -eq 0 ]]
}

# ─── 自動修復連携 ─────────────────────────────────────────

hb_auto_heal() {
    # ハーネスの失敗をSoloptiLinkAIの修復エンジンに渡す
    local failures
    failures=$(hb_get_failures 2>/dev/null) || { _log "INFO" "[HarnessBridge] 失敗なし - 修復不要"; return 0; }

    local count
    count=$(echo "$failures" | wc -l | xargs)
    [[ "$count" -eq 0 ]] && { _log "INFO" "[HarnessBridge] 失敗なし"; return 0; }

    _log "INFO" "[HarnessBridge] ${count}件の失敗を検出 → 修復パイプライン起動"

    # 失敗分類
    local version_fails=0 api_fails=0 other_fails=0
    while IFS= read -r line; do
        if echo "$line" | grep -qi "version"; then
            version_fails=$((version_fails + 1))
        elif echo "$line" | grep -qi "function\|not found\|declare"; then
            api_fails=$((api_fails + 1))
        else
            other_fails=$((other_fails + 1))
        fi
    done <<< "$failures"

    local fixed=0
    local sl_dir="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"

    # バージョン不整合の自動修復
    if [[ $version_fails -gt 0 ]]; then
        local chain_ver
        chain_ver=$(grep -m1 "^readonly VERSION=" "$sl_dir/chain.sh" 2>/dev/null | sed 's/.*="//' | sed 's/"//')
        if [[ -n "$chain_ver" ]]; then
            for core_file in "$sl_dir"/lib/core/*.sh; do
                [[ -f "$core_file" ]] || continue
                local base; base=$(basename "$core_file")
                if [[ "$base" == "cli-parser.sh" ]] && ! head -5 "$core_file" | grep -q "v${chain_ver}"; then
                    sed -i '' "s/# SoloptiLink Chain v[0-9.]*/# SoloptiLink Chain v${chain_ver}/" "$core_file" 2>/dev/null || \
                        sed -i "s/# SoloptiLink Chain v[0-9.]*/# SoloptiLink Chain v${chain_ver}/" "$core_file" 2>/dev/null || true
                    fixed=$((fixed + 1))
                    _log "INFO" "[HarnessBridge] ${base} ヘッダバージョンを v${chain_ver} に更新"
                fi
            done
        fi
    fi

    # モジュールロード失敗: 旧形式_mr_register検出レポート
    if [[ $api_fails -gt 0 ]]; then
        local mr_issues=0
        while IFS= read -r -d '' file; do
            if grep -q '_mr_register "' "$file" 2>/dev/null && ! grep -q '_mr_register.*--name' "$file" 2>/dev/null; then
                mr_issues=$((mr_issues + 1))
                _log "WARN" "[HarnessBridge] 旧形式_mr_register: $(basename "$file")"
            fi
        done < <(find "$sl_dir/lib" -name "*.sh" -not -path "*/common/*" -not -path "*/core/*" -print0 2>/dev/null)
    fi

    echo "total:$count version:$version_fails api:$api_fails other:$other_fails fixed:$fixed"
}

# ─── プロジェクト→本体 同期 ───────────────────────────────

hb_sync_to_install() {
    local project_dir="${1:-}"
    local sl_dir="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"

    [[ -z "$project_dir" ]] && return 1
    [[ -d "$project_dir/lib" ]] || return 1

    local count=0
    # lib/ 以下を同期
    while IFS= read -r -d '' proj_file; do
        local rel="${proj_file#$project_dir/}"
        local target="$sl_dir/$rel"
        mkdir -p "$(dirname "$target")"
        if ! diff -q "$proj_file" "$target" &>/dev/null 2>&1; then
            cp "$proj_file" "$target"
            count=$((count + 1))
        fi
    done < <(find "$project_dir/lib" -name "*.sh" -print0 2>/dev/null)

    # chain.sh
    if [[ -f "$project_dir/chain.sh" ]] && ! diff -q "$project_dir/chain.sh" "$sl_dir/chain.sh" &>/dev/null 2>&1; then
        cp "$project_dir/chain.sh" "$sl_dir/chain.sh"
        count=$((count + 1))
    fi

    _log "INFO" "[HarnessBridge] ${count}ファイル同期完了"
    echo "$count"
}

# ─── ヘルスレポート統合 ───────────────────────────────────

hb_health_report() {
    local score
    score=$(hb_get_score 2>/dev/null) || score=0

    local sync_status
    sync_status=$(hb_sync_check 2>/dev/null) || sync_status="checked:0 synced:0 out_of_sync:0"

    local failures
    failures=$(hb_get_failures 2>/dev/null | wc -l | xargs) || failures=0

    cat <<EOF
{
  "harness_bridge_version": "${HB_VERSION}",
  "test_score": ${score},
  "test_failures": ${failures},
  "sync_status": "${sync_status}",
  "harness_dir": "${HB_HARNESS_DIR:-unknown}",
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
EOF
}

# ─── モジュール登録 ───────────────────────────────────────

_hb_mr_register() {
    if declare -f _mr_register &>/dev/null; then
        _mr_register \
            --name "harness-bridge" \
            --version "v${HB_VERSION}" \
            --description "Harness Bridge - テストハーネスとSoloptiLinkAI本体の双方向連携" \
            --init "hb_detect_harness" \
            --report "hb_health_report"
    fi
}

# Auto-register on source
_hb_mr_register
