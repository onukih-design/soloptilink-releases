#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v130.0 - Spec Tracer
# ============================================================
# 生成コードがユーザーの元リクエストを満たしているかを検証。
# タスク記述→機能チェックリスト抽出→生成コード突合→修正プロンプト生成。
# All globals use the ST_ prefix.
# ============================================================

[[ -n "${_SPEC_TRACER_LOADED:-}" ]] && return 0
_SPEC_TRACER_LOADED=1

ST_VERSION="130.0"
ST_INITIALIZED=false
ST_DATA_DIR=""
ST_FEATURES_FILE=""
ST_RESULTS_FILE=""
ST_FEATURE_COUNT=0
ST_VERIFIED_COUNT=0
ST_PASS_COUNT=0
ST_PARTIAL_COUNT=0
ST_FAIL_COUNT=0
ST_OVERALL_SCORE=0
ST_LAST_TASK=""

# --- Domain decomposition: "keyword|feat1:pattern1,feat2:pattern2,..." ---
_ST_DOMAIN_MAP=(
    "タスク管理\|task.manag|task_list:task.*list\|タスク一覧\|TaskList,task_create:createTask\|task.*create\|タスク作成,task_edit:updateTask\|task.*edit\|タスク編集,task_delete:deleteTask\|task.*delete\|タスク削除,task_status:status\|ステータス\|completed\|pending"
    "CRM\|crm|contact_list:contact\|顧客一覧\|CustomerList,contact_create:createContact\|顧客登録,lead_management:lead\|リード\|LeadList,deal_pipeline:deal\|pipeline\|案件\|商談,activity_log:activity\|アクティビティ\|ActivityLog"
    "EC\|ecommerce\|ショッピング|product_list:product\|商品\|ProductList,cart:cart\|カート\|ShoppingCart,checkout:checkout\|決済\|payment,order_history:order\|注文\|OrderList,product_detail:ProductDetail\|商品詳細"
    "チャット\|chat|chat_room:ChatRoom\|chat.*room\|チャットルーム,message_send:sendMessage\|メッセージ送信,message_list:MessageList\|message.*list\|メッセージ一覧,realtime:websocket\|socket\|リアルタイム"
    "ブログ\|blog|post_list:PostList\|post.*list\|記事一覧,post_create:createPost\|記事作成\|新規投稿,post_detail:PostDetail\|記事詳細\|slug,comment:comment\|コメント\|Comment"
    "認証\|auth|login:login\|ログイン\|signIn,register:register\|登録\|signUp,logout:logout\|ログアウト\|signOut,password_reset:reset.*password\|パスワードリセット"
    "ダッシュボード\|dashboard|dashboard_view:Dashboard\|ダッシュボード,chart:Chart\|chart\|グラフ,stats:stats\|statistics\|統計,export:export\|エクスポート\|csv\|pdf"
    "カレンダー\|予定管理|calendar_view:calendar\|Calendar\|カレンダー,event_create:createEvent\|イベント作成\|予定追加,event_edit:updateEvent\|イベント編集,event_delete:deleteEvent\|イベント削除"
    "請求書\|invoice|invoice_list:invoice\|請求一覧\|InvoiceList,invoice_create:createInvoice\|請求作成,invoice_pdf:pdf\|PDF\|generatePdf,payment_status:payment.*status\|支払状況"
    "在庫管理\|inventory|inventory_list:inventory\|在庫一覧\|stock,inventory_update:updateStock\|在庫更新,low_stock_alert:alert\|アラート\|在庫切れ,barcode:barcode\|バーコード"
    "ファイル管理\|file.manag|file_upload:upload\|アップロード\|FileUpload,file_list:file.*list\|ファイル一覧,file_download:download\|ダウンロード,file_delete:deleteFile\|ファイル削除"
    "ユーザー管理\|user.manag|user_list:user.*list\|ユーザー一覧\|UserList,user_create:createUser\|ユーザー作成,user_edit:updateUser\|ユーザー編集,role_management:role\|権限\|ロール"
    "LP\|ランディング|hero_section:hero\|Hero\|ヒーロー,cta_button:cta\|CTA\|申し込み,features_section:features\|特徴\|Features,contact_form:form\|フォーム\|contact"
)

# --- Explicit feature keywords: "keyword|feature_name|grep_pattern" ---
_ST_FEATURE_KEYWORDS=(
    "リードスコアリング\|lead.scoring|lead_scoring|leadScore\|lead_score\|スコアリング\|scoring"
    "検索\|search|search|search\|検索\|Search\|useSearch\|SearchBar"
    "ソート\|sort|sort|sort\|ソート\|orderBy\|sortBy"
    "フィルター\|filter|filter|filter\|フィルター\|filterBy\|useFilter"
    "ページネーション\|pagination|pagination|pagination\|ページネーション\|paginate\|page.*size\|cursor"
    "お気に入り\|favorite|favorite|favorite\|お気に入り\|bookmark\|like"
    "通知\|notification|notification|notification\|通知\|Notification\|toast\|alert"
    "エクスポート\|export|export|export\|エクスポート\|CSV\|csv\|download\|PDF"
    "インポート\|import|import_data|import.*data\|インポート\|upload.*csv\|bulkInsert"
    "ダークモード\|dark.mode|dark_mode|dark.*mode\|ダークモード\|theme.*dark\|darkTheme"
    "多言語\|i18n|i18n|i18n\|locale\|多言語\|translation\|useTranslation"
    "レスポンシブ\|responsive|responsive|responsive\|レスポンシブ\|media.*query\|breakpoint"
    "バリデーション\|validation|validation|validation\|バリデーション\|validate\|zod\|yup"
    "権限\|rbac\|権限管理|rbac|role\|permission\|権限\|RBAC\|authorize\|canAccess"
    "ドラッグ\|drag|drag_drop|drag\|drop\|ドラッグ\|DnD\|sortable\|draggable"
    "グラフ\|chart|chart|chart\|Chart\|グラフ\|graph\|recharts\|chart.js\|d3"
    "マップ\|map|map|map\|Map\|地図\|mapbox\|leaflet\|google.*map"
    "タイムライン\|timeline|timeline|timeline\|タイムライン\|Timeline\|history"
    "プロフィール\|profile|profile|profile\|プロフィール\|Profile\|userProfile"
    "設定\|settings|settings|settings\|設定\|Settings\|preferences\|config.*page"
)

# --- Init ---
st_init() {
    ST_DATA_DIR="${HOME}/.soloptilink/spec-tracer"
    mkdir -p "$ST_DATA_DIR" 2>/dev/null || true
    ST_FEATURES_FILE="${ST_DATA_DIR}/features.jsonl"
    ST_RESULTS_FILE="${ST_DATA_DIR}/results.jsonl"
    ST_FEATURE_COUNT=0; ST_VERIFIED_COUNT=0
    ST_PASS_COUNT=0; ST_PARTIAL_COUNT=0; ST_FAIL_COUNT=0
    ST_OVERALL_SCORE=0; ST_LAST_TASK=""
    ST_INITIALIZED=true
    return 0
}

# --- Internal helpers ---
_st_json_val() {
    local json="$1" key="$2"
    echo "$json" | grep -o "\"${key}\":[^,}]*" | head -1 \
        | sed "s/\"${key}\"://;s/^\"//;s/\"$//;s/^[[:space:]]*//;s/[[:space:]]*$//"
}

_st_normalize_task() {
    echo "$1" | tr '[:upper:]' '[:lower:]' | sed 's/[[:space:]]\+/ /g;s/^ //;s/ $//'
}

_st_append_feature() {
    local name="$1" pattern="$2" source="$3"
    # Dedup
    if [[ -f "$ST_FEATURES_FILE" ]]; then
        grep -q "\"name\":\"${name}\"" "$ST_FEATURES_FILE" 2>/dev/null && return 0
    fi
    local ts; ts=$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date +"%Y-%m-%d")
    echo "{\"name\":\"${name}\",\"pattern\":\"${pattern}\",\"source\":\"${source}\",\"timestamp\":\"${ts}\",\"score\":0,\"evidence\":\"\"}" \
        >> "$ST_FEATURES_FILE" 2>/dev/null
    ST_FEATURE_COUNT=$((ST_FEATURE_COUNT + 1))
}

# --- Extract feature checklist from task description ---
st_extract_features() {
    local task_desc="$1"
    [[ -z "$task_desc" ]] && echo "0" && return 1
    [[ "$ST_INITIALIZED" != "true" ]] && st_init
    ST_LAST_TASK="$task_desc"
    : > "$ST_FEATURES_FILE" 2>/dev/null
    ST_FEATURE_COUNT=0
    local normalized; normalized=$(_st_normalize_task "$task_desc")

    # Phase 1: Domain pattern expansion
    local entry
    for entry in "${_ST_DOMAIN_MAP[@]}"; do
        local domain_keyword="${entry%%|*}"
        local features_str="${entry#*|}"
        if echo "$task_desc" | grep -qiE "$domain_keyword" 2>/dev/null; then
            local IFS_SAVE="$IFS"; IFS=','
            local pair
            for pair in $features_str; do
                _st_append_feature "${pair%%:*}" "${pair#*:}" "domain:${domain_keyword}"
            done
            IFS="$IFS_SAVE"
        fi
    done

    # Phase 2: Explicit feature keyword matching
    local kw_entry
    for kw_entry in "${_ST_FEATURE_KEYWORDS[@]}"; do
        local keyword="${kw_entry%%|*}"
        local remainder="${kw_entry#*|}"
        local feat_name="${remainder%%|*}"
        local feat_pattern="${remainder#*|}"
        if echo "$task_desc" | grep -qiE "$keyword" 2>/dev/null; then
            _st_append_feature "$feat_name" "$feat_pattern" "keyword:${keyword}"
        fi
    done

    # Phase 3: Generic CRUD from entity nouns ("XXX管理" / "xxx management")
    local entity=""
    if echo "$task_desc" | grep -oE '[ァ-ヶー]+管理' 2>/dev/null | head -1 | grep -oE '[ァ-ヶー]+' | head -1 | read -r entity; then
        if [[ -n "$entity" && ${#entity} -ge 2 ]]; then
            _st_append_feature "${entity}_list" "${entity}.*一覧\|${entity}List\|${entity}" "entity:${entity}"
            _st_append_feature "${entity}_create" "${entity}.*作成\|create.*${entity}" "entity:${entity}"
        fi
    fi
    local eng_entity=""
    eng_entity=$(echo "$normalized" | grep -oE '[a-z]+[ _-]?(management|manager|app|application|system|tool)' | head -1 | sed 's/[ _-]*\(management\|manager\|app\|application\|system\|tool\)$//')
    if [[ -n "$eng_entity" && ${#eng_entity} -ge 3 ]]; then
        _st_append_feature "${eng_entity}_list" "${eng_entity}.*list\|${eng_entity}List" "entity:${eng_entity}"
        _st_append_feature "${eng_entity}_create" "create.*${eng_entity}\|${eng_entity}.*create" "entity:${eng_entity}"
        _st_append_feature "${eng_entity}_edit" "update.*${eng_entity}\|${eng_entity}.*edit" "entity:${eng_entity}"
        _st_append_feature "${eng_entity}_delete" "delete.*${eng_entity}\|${eng_entity}.*delete" "entity:${eng_entity}"
    fi

    # Phase 4: "X付き"/"X機能"/"with X" addition patterns
    local _st_additions=""
    _st_additions=$(echo "$task_desc" | grep -oE '[ァ-ヶーａ-ｚA-Za-z]+[付機]能' 2>/dev/null | sed 's/[付機]能$//')
    _st_additions+=$'\n'
    _st_additions+=$(echo "$normalized" | grep -oE 'with [a-z]+' 2>/dev/null | sed 's/^with //')
    local addition
    while IFS= read -r addition; do
        [[ -z "$addition" ]] && continue
        for kw_entry in "${_ST_FEATURE_KEYWORDS[@]}"; do
            local keyword="${kw_entry%%|*}"
            local remainder="${kw_entry#*|}"
            if echo "$addition" | grep -qiE "$keyword" 2>/dev/null; then
                _st_append_feature "${remainder%%|*}" "${remainder#*|}" "addition:${addition}"
                break
            fi
        done
    done <<< "$_st_additions"

    echo "$ST_FEATURE_COUNT"
    return 0
}

# --- Verify each feature is implemented in project ---
st_verify_features() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1
    [[ "$ST_INITIALIZED" != "true" ]] && st_init
    [[ ! -f "$ST_FEATURES_FILE" ]] && return 1
    : > "$ST_RESULTS_FILE" 2>/dev/null
    ST_VERIFIED_COUNT=0; ST_PASS_COUNT=0; ST_PARTIAL_COUNT=0; ST_FAIL_COUNT=0

    local line
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        local feat_name feat_pattern
        feat_name=$(_st_json_val "$line" "name")
        feat_pattern=$(_st_json_val "$line" "pattern")
        [[ -z "$feat_name" || -z "$feat_pattern" ]] && continue
        ST_VERIFIED_COUNT=$((ST_VERIFIED_COUNT + 1))

        # Search source files (exclude build artifacts)
        local match_count=0 comment_only_count=0 evidence=""
        local src_matches
        src_matches=$(find "$project_dir" \
            -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \
                -o -name "*.vue" -o -name "*.svelte" -o -name "*.py" -o -name "*.go" \) \
            ! -path "*/node_modules/*" ! -path "*/.next/*" ! -path "*/.git/*" \
            ! -path "*/dist/*" ! -path "*/build/*" \
            -exec grep -lE "$feat_pattern" {} \; 2>/dev/null)

        if [[ -n "$src_matches" ]]; then
            match_count=$(echo "$src_matches" | wc -l | tr -d ' ')
            evidence=$(echo "$src_matches" | head -3 | tr '\n' ',' | sed 's/,$//')
        fi

        # Distinguish code matches vs comment-only matches
        if [[ $match_count -gt 0 ]]; then
            local real_code=0
            while IFS= read -r matched_file; do
                [[ -z "$matched_file" ]] && continue
                local code_hits comment_hits
                code_hits=$(grep -cE "$feat_pattern" "$matched_file" 2>/dev/null || echo "0")
                comment_hits=$(grep -E '^\s*(//|#|\*|/\*|<!--)' "$matched_file" 2>/dev/null \
                    | grep -cE "$feat_pattern" 2>/dev/null || echo "0")
                [[ $((code_hits - comment_hits)) -gt 0 ]] && real_code=$((real_code + code_hits - comment_hits))
            done <<< "$src_matches"
            if [[ $real_code -eq 0 ]]; then
                comment_only_count=$match_count; match_count=0
            fi
        fi

        # Score: 100=implemented, 75=partial, 50=comment_only, 0=missing
        local feat_score=0 status="missing"
        if [[ $match_count -ge 2 ]]; then
            feat_score=100; status="implemented"; ST_PASS_COUNT=$((ST_PASS_COUNT + 1))
        elif [[ $match_count -eq 1 ]]; then
            feat_score=75; status="partial"; ST_PARTIAL_COUNT=$((ST_PARTIAL_COUNT + 1))
        elif [[ $comment_only_count -gt 0 ]]; then
            feat_score=50; status="comment_only"; ST_PARTIAL_COUNT=$((ST_PARTIAL_COUNT + 1))
        else
            ST_FAIL_COUNT=$((ST_FAIL_COUNT + 1))
        fi

        local rel_ev; rel_ev=$(echo "$evidence" | sed "s|${project_dir}/||g")
        echo "{\"name\":\"${feat_name}\",\"score\":${feat_score},\"status\":\"${status}\",\"matches\":${match_count},\"evidence\":\"${rel_ev}\"}" \
            >> "$ST_RESULTS_FILE" 2>/dev/null
    done < "$ST_FEATURES_FILE"

    # Calculate overall score
    if [[ $ST_VERIFIED_COUNT -gt 0 ]]; then
        local total_score=0
        while IFS= read -r line; do
            [[ -z "$line" ]] && continue
            local s; s=$(_st_json_val "$line" "score")
            [[ -n "$s" && "$s" =~ ^[0-9]+$ ]] && total_score=$((total_score + s))
        done < "$ST_RESULTS_FILE"
        ST_OVERALL_SCORE=$((total_score / ST_VERIFIED_COUNT))
    fi
    return 0
}

# --- Return unimplemented features (score < 50) as "name|score|status" ---
st_get_missing_features() {
    [[ ! -f "$ST_RESULTS_FILE" ]] && return 1
    local line
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        local s n st
        s=$(_st_json_val "$line" "score"); n=$(_st_json_val "$line" "name"); st=$(_st_json_val "$line" "status")
        [[ -n "$s" && "$s" =~ ^[0-9]+$ && $s -lt 50 ]] && echo "${n}|${s}|${st}"
    done < "$ST_RESULTS_FILE"
    return 0
}

# --- Generate fix prompt for missing features ---
st_generate_fix_prompt() {
    [[ ! -f "$ST_RESULTS_FILE" ]] && echo "" && return 1
    local missing_list; missing_list=$(st_get_missing_features)
    [[ -z "$missing_list" ]] && echo "" && return 0
    local missing_count; missing_count=$(echo "$missing_list" | wc -l | tr -d ' ')

    local prompt="## Spec Tracer: 未実装機能の修正指示\n\n"
    prompt+="以下の ${missing_count} 機能がユーザーのリクエストに含まれていますが、実装が確認できません。\n"
    prompt+="各機能を実装してください。\n\n"
    [[ -n "$ST_LAST_TASK" ]] && prompt+="### 元リクエスト\n\`\`\`\n${ST_LAST_TASK}\n\`\`\`\n\n"
    prompt+="### 未実装機能一覧\n"

    local entry
    while IFS= read -r entry; do
        [[ -z "$entry" ]] && continue
        local name="${entry%%|*}"; local rest="${entry#*|}"
        local score="${rest%%|*}"; local status="${rest#*|}"
        prompt+="- **${name}** (status: ${status}, score: ${score}/100)\n"
        if [[ -f "$ST_FEATURES_FILE" ]]; then
            local fl; fl=$(grep "\"name\":\"${name}\"" "$ST_FEATURES_FILE" 2>/dev/null | head -1)
            if [[ -n "$fl" ]]; then
                local p; p=$(_st_json_val "$fl" "pattern")
                [[ -n "$p" ]] && prompt+="  期待される実装パターン: \`${p}\`\n"
            fi
        fi
    done <<< "$missing_list"

    prompt+="\n### 修正要件\n"
    prompt+="1. 上記の各機能について、ルート/コンポーネント/APIを実装すること\n"
    prompt+="2. 既存コードとの整合性を維持すること\n"
    prompt+="3. エンタープライズパターン（zod, try/catch, 認証チェック）を遵守すること\n"
    echo -e "$prompt"
    return 0
}

# --- MR standard report ---
st_report() {
    echo -e "\n  ${BOLD:-}=== Spec Tracer v${ST_VERSION} ===${NC:-}"
    if [[ $ST_FEATURE_COUNT -eq 0 && $ST_VERIFIED_COUNT -eq 0 ]]; then
        echo -e "  No features extracted yet"; return 0
    fi
    echo -e "  Features extracted  : ${ST_FEATURE_COUNT}"
    echo -e "  Features verified   : ${ST_VERIFIED_COUNT}"
    echo -e "  Implemented (100)   : ${ST_PASS_COUNT}"
    echo -e "  Partial (50-75)     : ${ST_PARTIAL_COUNT}"
    echo -e "  Missing (0)         : ${ST_FAIL_COUNT}"
    echo -e "  Overall score       : ${ST_OVERALL_SCORE}/100"
    if [[ $ST_FAIL_COUNT -gt 0 && -f "$ST_RESULTS_FILE" ]]; then
        echo -e "  --- Missing Features ---"
        local line
        while IFS= read -r line; do
            [[ -z "$line" ]] && continue
            local s n st
            s=$(_st_json_val "$line" "score"); n=$(_st_json_val "$line" "name"); st=$(_st_json_val "$line" "status")
            [[ -n "$s" && "$s" =~ ^[0-9]+$ && $s -lt 50 ]] && echo -e "    [MISSING] ${n} (${st})"
        done < "$ST_RESULTS_FILE"
    fi
}

# --- JSON report ---
st_report_json() {
    local json="{\"module\":\"spec-tracer\",\"version\":\"${ST_VERSION}\""
    json+=",\"feature_count\":${ST_FEATURE_COUNT},\"verified_count\":${ST_VERIFIED_COUNT}"
    json+=",\"pass_count\":${ST_PASS_COUNT},\"partial_count\":${ST_PARTIAL_COUNT}"
    json+=",\"fail_count\":${ST_FAIL_COUNT},\"overall_score\":${ST_OVERALL_SCORE}"
    json+=",\"features\":["
    if [[ -f "$ST_RESULTS_FILE" ]]; then
        local first=true line
        while IFS= read -r line; do
            [[ -z "$line" ]] && continue
            [[ "$first" == "true" ]] && first=false || json+=","
            json+="$line"
        done < "$ST_RESULTS_FILE"
    fi
    json+="]}"
    echo "$json"
}

# --- Module score (0-100) ---
st_score() {
    [[ $ST_VERIFIED_COUNT -eq 0 ]] && echo "50" && return 0
    echo "$ST_OVERALL_SCORE"
}

# --- Module Registry Self-Registration ---
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "spec-tracer" \
        --version "$ST_VERSION" \
        --description "ユーザーリクエスト↔生成コード機能突合検証" \
        --init "st_init" \
        --report "st_report" \
        --score "st_score" \
        --enable-var "ENABLE_ST" \
        --cli-flags "--spec-tracer:--no-spec-tracer"
fi

# v2003.1: source時のexit codeを確実に0にする
true
