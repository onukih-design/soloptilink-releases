#!/usr/bin/env bash
# =============================================================================
# causal-healer.sh - 因果推論によるエラー修復強化 v1.0.0
# -----------------------------------------------------------------------------
# 役割:
#   Python認知層の causal_reasoner(ベイズネット Noisy-OR)でエラー/findings の
#   root_cause / fix_location / fix_action / confidence を分析し、healer の
#   修復プロンプトに「## 因果分析による修復ヒント」として注入する。
#   対症療法(エラー文言を消すだけ)ではなく根本原因の除去を促す。
# 二経路(PFP-068):
#   分析自体は cognitive_rpc(python3) で動くため Desktop でも利用可能。
#   ターミナル経路では healer の claude -p 修復プロンプトに合流し、
#   Desktop では Claude 本体が cognitive_rpc を直接叩いて因果分析を利用できる。
# 配線:
#   functional-healer.sh の _fh_call_claude が _FH_HEAL_CONTEXT を元に呼ぶ。
# =============================================================================
[[ -n "${CHEAL_LOADED:-}" ]] && return 0 2>/dev/null || true
CHEAL_LOADED=1
CHEAL_VERSION="1.0.0"
CHEAL_LIB_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" 2>/dev/null && pwd || echo "${HOME}/.soloptilink/lib")"
# 保険: BASH_SOURCE が効かない環境でも lib を確実に指す
[[ -f "${CHEAL_LIB_DIR}/cognitive-rpc.sh" ]] || CHEAL_LIB_DIR="${HOME}/.soloptilink/lib"

# 依存(cognitive-rpc)の保険ロード
_cheal_ensure_rpc() {
  type -t cognitive_rpc &>/dev/null && return 0
  [[ -f "${CHEAL_LIB_DIR}/cognitive-rpc.sh" ]] && source "${CHEAL_LIB_DIR}/cognitive-rpc.sh" 2>/dev/null || true
}

# causal_healer_analyze <error_text> -> 因果分析の修復ヒント(stdout)。分析不能なら空。
causal_healer_analyze() {
  local error="${1:-}"
  [[ -z "$error" ]] && return 0
  _cheal_ensure_rpc
  type -t cognitive_rpc &>/dev/null || return 0
  # 認知層が使えない環境なら静かに諦める
  if type -t crpc_available &>/dev/null && ! crpc_available 2>/dev/null; then
    return 0
  fi
  local err_json
  # analyse_error は error_type / message キーを部分文字列マッチで参照する。
  # 全文を message に、先頭(エラーコードが来やすい)を error_type に渡してマッチ機会を最大化。
  err_json=$(printf '%s' "$error" | python3 -c 'import sys,json;t=sys.stdin.read()[:2000];print(json.dumps({"message":t,"error_type":t[:120]}))' 2>/dev/null) || return 0
  local result
  result=$(cognitive_rpc causal_reasoner causal.analyse "$err_json" 2>/dev/null)
  [[ -z "$result" ]] && return 0
  printf '%s' "$result" | python3 -c '
import sys, json
try:
    d = json.load(sys.stdin)
    rc = (d.get("root_cause") or "").strip()
    fl = (d.get("fix_location") or "").strip()
    fa = (d.get("fix_action") or "").strip()
    cf = d.get("confidence", "")
    # 有意な分析が無ければ注入しない(ノイズ防止)
    if rc in ("", "unknown") and not fa:
        raise SystemExit(0)
    print("## 因果分析による修復ヒント (Python causal_reasoner / ベイズ推論)")
    if rc and rc != "unknown":
        print(f"- 推定根本原因: {rc}")
    if fl:
        print(f"- 修正箇所の候補: {fl}")
    if fa:
        print(f"- 推奨修正アクション: {fa}")
    if cf not in ("", None):
        print(f"- 推定信頼度: {cf}")
    print("対症療法ではなく、上記の根本原因の除去を優先してください。")
except Exception:
    pass
' 2>/dev/null
}

# causal_healer_inject <prompt> <error_text> -> error の因果分析を追記した prompt(stdout)
# 分析不能/エラー空のときは元の prompt をそのまま返す(グレースフル)。
causal_healer_inject() {
  local prompt="${1:-}" error="${2:-}"
  [[ -z "$error" ]] && { printf '%s' "$prompt"; return 0; }
  local hint
  hint=$(causal_healer_analyze "$error")
  if [[ -n "$hint" ]]; then
    printf '%s\n\n%s' "$prompt" "$hint"
  else
    printf '%s' "$prompt"
  fi
}

# causal_healer_enrich_report <errors_json_array> -> 各エラーに root_cause/fix_action/fix_location を付加した JSON
# build-verifier の構造化エラーレポートを因果推論で強化する。CausalReasoner を1度だけ生成し全件処理(効率的)。
causal_healer_enrich_report() {
  local errors_json="${1:-[]}"
  CHEAL_ERRORS="$errors_json" \
  CHEAL_PERSIST="${TMPDIR:-/tmp}/soloptilink-ml-rpc" \
  PYTHONPATH="${SOLOPTILINK_HOME:-$HOME/.soloptilink}" python3 - <<'PY' 2>/dev/null || printf '%s' "${1:-[]}"
import os, json, pathlib
src = os.environ.get('CHEAL_ERRORS') or '[]'
try:
    import ml.reasoning.causal_reasoner as crmod
    # 永続化を一時領域へ逃がし本番データ領域を汚さない
    crmod.PERSIST_DIR = pathlib.Path(os.environ.get('CHEAL_PERSIST', '/tmp/soloptilink-ml-rpc'))
    errs = json.loads(src)
    if not isinstance(errs, list):
        raise SystemExit(0)
    r = crmod.CausalReasoner()
    for e in errs:
        if not isinstance(e, dict):
            continue
        msg = e.get('message') or e.get('msg') or e.get('raw') or ''
        if not msg:
            continue
        d = r.analyse_error({'message': msg, 'error_type': msg[:120]}).to_dict()
        rc = d.get('root_cause')
        if rc and rc != 'unknown':
            e['root_cause'] = rc
            e['fix_action'] = d.get('fix_action')
            e['fix_location'] = d.get('fix_location')
            e['causal_confidence'] = d.get('confidence')
    print(json.dumps(errs, ensure_ascii=False))
except Exception:
    print(src)
PY
}

# 直接実行時のCLIエントリ
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  case "${1:-help}" in
    analyze) shift; causal_healer_analyze "$@";;
    inject)  shift; causal_healer_inject "$@";;
    enrich)  shift; causal_healer_enrich_report "$@";;
    *) echo "usage: $0 {analyze <error_text>|inject <prompt> <error_text>|enrich <errors_json>}";;
  esac
fi
