#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v255.0 - Regression Preventer
# =============================================================================
# 修正適用後のリグレッション（機能退行）を検出・防止するエンジン。
#
# 問題: 1つのバグを修正すると、別の機能が壊れることがある。
#   - DBスキーマ変更で既存APIが動かなくなる
#   - 型定義変更で別コンポーネントがエラーになる
#   - 共有ユーティリティの変更が複数ページに影響
#
# 解決: 修正前のスナップショットを取り、修正後に比較。
#   影響範囲（blast radius）を事前計算し、関連テストのみを実行。
#   リグレッション検出時はガードテストを提案。
#
# Functions:
#   rp_init                  - 初期化
#   _rp_check_regression     - 修正後のリグレッションチェック
#   _rp_run_affected_tests   - 影響を受けるテストのみ実行
#   _rp_snapshot_before      - 修正前のスナップショット取得
#   _rp_compare_after        - 修正後のスナップショット比較
#   _rp_suggest_guard_tests  - リグレッション防止テストを提案
#   _rp_get_change_impact    - 変更の影響範囲（blast radius）を計算
#   rp_report                - レポート出力
#   rp_score                 - モジュールスコア(0-100)
#
# All globals use the RP_ prefix.
# =============================================================================

[[ -n "${_REGRESSION_PREVENTER_LOADED:-}" ]] && return 0
_REGRESSION_PREVENTER_LOADED=1

RP_VERSION="255.0"
RP_INITIALIZED=false

# --- Paths ---
RP_CACHE_DIR=""
RP_SNAPSHOT_DIR=""
RP_HISTORY_FILE=""

# --- Counters ---
RP_TOTAL_CHECKS=0
RP_REGRESSIONS_FOUND=0
RP_REGRESSIONS_PREVENTED=0
RP_TESTS_SUGGESTED=0
RP_SNAPSHOTS_TAKEN=0

# --- In-memory storage ---
declare -g -A _RP_SNAPSHOTS=()          # snapshot_id → snapshot data JSON
declare -g -A _RP_IMPACT_CACHE=()       # file_path → impact JSON
declare -g -a _RP_REGRESSION_LOG=()     # detected regressions

# =============================================================================
# rp_init - Initialize regression preventer
# =============================================================================
rp_init() {
    RP_CACHE_DIR="${HOME}/.soloptilink/cache/rp"
    RP_SNAPSHOT_DIR="${RP_CACHE_DIR}/snapshots"
    mkdir -p "$RP_SNAPSHOT_DIR" 2>/dev/null || true

    RP_HISTORY_FILE="${RP_CACHE_DIR}/regression-history.jsonl"

    RP_TOTAL_CHECKS=0
    RP_REGRESSIONS_FOUND=0
    RP_REGRESSIONS_PREVENTED=0
    RP_TESTS_SUGGESTED=0
    RP_SNAPSHOTS_TAKEN=0
    _RP_SNAPSHOTS=()
    _RP_IMPACT_CACHE=()
    _RP_REGRESSION_LOG=()

    RP_INITIALIZED=true
    return 0
}

# =============================================================================
# _rp_snapshot_before - Take a snapshot of project state before a fix
# Arguments:
#   $1 - project_dir
#   $2 - changed_files (comma-separated list of files that will be changed)
#   $3 - snapshot_id (optional, auto-generated if not provided)
# Returns:
#   snapshot_id via stdout
# =============================================================================
_rp_snapshot_before() {
    local project_dir="${1:-.}"
    local changed_files="${2:-}"
    local snapshot_id="${3:-}"

    [[ -z "$snapshot_id" ]] && snapshot_id="snap_$(date +%s)_$$"

    RP_SNAPSHOTS_TAKEN=$((RP_SNAPSHOTS_TAKEN + 1))

    local snapshot_path="${RP_SNAPSHOT_DIR}/${snapshot_id}"
    mkdir -p "$snapshot_path" 2>/dev/null || true

    # 1. Save checksums of all source files
    local checksum_file="${snapshot_path}/checksums.txt"
    : > "$checksum_file"

    if [[ -d "$project_dir" ]]; then
        find "$project_dir" \
            -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" -o -name "*.json" -o -name "*.prisma" -o -name "*.css" \) \
            ! -path "*/node_modules/*" \
            ! -path "*/.next/*" \
            ! -path "*/dist/*" \
            ! -path "*/.git/*" \
            2>/dev/null | while IFS= read -r file; do
            local ck
            ck=$(cksum "$file" 2>/dev/null | awk '{print $1}')
            echo "${ck} ${file}" >> "$checksum_file"
        done
    fi

    # 2. Save the content of files that will be changed
    local changed_dir="${snapshot_path}/changed_files"
    mkdir -p "$changed_dir" 2>/dev/null || true

    if [[ -n "$changed_files" ]]; then
        IFS=',' read -ra files_arr <<< "$changed_files"
        for f in "${files_arr[@]}"; do
            f=$(echo "$f" | sed 's/^ *//;s/ *$//')
            local full_path="${project_dir}/${f}"
            [[ ! -f "$full_path" ]] && full_path="$f"

            if [[ -f "$full_path" ]]; then
                local safe_name
                safe_name=$(echo "$f" | tr '/' '_')
                cp "$full_path" "${changed_dir}/${safe_name}" 2>/dev/null || true
            fi
        done
    fi

    # 3. Save TypeScript compilation state
    local ts_errors_file="${snapshot_path}/ts_errors.txt"
    if command -v npx &>/dev/null && [[ -f "${project_dir}/tsconfig.json" ]]; then
        (cd "$project_dir" && npx tsc --noEmit 2>&1 | head -50 > "$ts_errors_file") 2>/dev/null || true
    else
        echo "tsc not available" > "$ts_errors_file"
    fi

    # 4. Save test state if tests exist
    local test_state_file="${snapshot_path}/test_state.txt"
    _rp_capture_test_state "$project_dir" > "$test_state_file" 2>/dev/null

    # 5. Save export signatures of changed files
    local exports_file="${snapshot_path}/exports.txt"
    : > "$exports_file"
    if [[ -n "$changed_files" ]]; then
        IFS=',' read -ra files_arr <<< "$changed_files"
        for f in "${files_arr[@]}"; do
            f=$(echo "$f" | sed 's/^ *//;s/ *$//')
            local full_path="${project_dir}/${f}"
            [[ ! -f "$full_path" ]] && full_path="$f"

            if [[ -f "$full_path" ]]; then
                echo "=== ${f} ===" >> "$exports_file"
                grep -nE '^export ' "$full_path" 2>/dev/null >> "$exports_file"
            fi
        done
    fi

    # Store in memory
    _RP_SNAPSHOTS["$snapshot_id"]="{\"id\":\"${snapshot_id}\",\"dir\":\"${snapshot_path}\",\"project\":\"${project_dir}\",\"changed\":\"${changed_files}\",\"ts\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}"

    echo "$snapshot_id"
    return 0
}

# =============================================================================
# _rp_capture_test_state - Capture current test pass/fail state
# Arguments:
#   $1 - project_dir
# Returns:
#   test state summary via stdout
# =============================================================================
_rp_capture_test_state() {
    local project_dir="${1:-.}"

    local pkg_json="${project_dir}/package.json"
    if [[ ! -f "$pkg_json" ]]; then
        echo "no_package_json"
        return 0
    fi

    # Check which test runner is available
    local test_runner="none"
    if grep -q '"jest"' "$pkg_json" 2>/dev/null || [[ -f "${project_dir}/jest.config.js" ]] || [[ -f "${project_dir}/jest.config.ts" ]]; then
        test_runner="jest"
    elif grep -q '"vitest"' "$pkg_json" 2>/dev/null || [[ -f "${project_dir}/vitest.config.ts" ]]; then
        test_runner="vitest"
    fi

    # Count test files
    local test_file_count
    test_file_count=$(find "$project_dir" -type f \( -name "*.test.ts" -o -name "*.test.tsx" -o -name "*.spec.ts" -o -name "*.spec.tsx" \) \
        ! -path "*/node_modules/*" 2>/dev/null | wc -l | tr -d ' ')

    echo "runner:${test_runner},test_files:${test_file_count}"
    return 0
}

# =============================================================================
# _rp_compare_after - Compare project state after fix with snapshot
# Arguments:
#   $1 - snapshot_id
#   $2 - project_dir (optional, uses stored path)
# Returns:
#   JSON comparison result via stdout
# =============================================================================
_rp_compare_after() {
    local snapshot_id="${1:-}"
    local project_dir="${2:-}"

    [[ -z "$snapshot_id" ]] && echo '{"error":"no snapshot_id"}' && return 1

    local snapshot_data="${_RP_SNAPSHOTS[$snapshot_id]:-}"
    if [[ -z "$snapshot_data" ]]; then
        echo '{"error":"snapshot not found"}'
        return 1
    fi

    local snapshot_path="${RP_SNAPSHOT_DIR}/${snapshot_id}"
    [[ -z "$project_dir" ]] && project_dir=$(echo "$snapshot_data" | grep -oE '"project":"[^"]*"' | sed 's/"project":"//;s/"//')

    RP_TOTAL_CHECKS=$((RP_TOTAL_CHECKS + 1))

    local regressions=()
    local warnings=()
    local changes=()

    # 1. Compare checksums - find unexpected changes
    local old_checksums="${snapshot_path}/checksums.txt"
    if [[ -f "$old_checksums" ]]; then
        while IFS=' ' read -r old_ck file_path; do
            [[ -z "$old_ck" || -z "$file_path" ]] && continue

            if [[ -f "$file_path" ]]; then
                local new_ck
                new_ck=$(cksum "$file_path" 2>/dev/null | awk '{print $1}')
                if [[ "$new_ck" != "$old_ck" ]]; then
                    changes+=("$file_path")
                fi
            else
                # File was deleted
                regressions+=("ファイル削除: ${file_path}")
            fi
        done < "$old_checksums"
    fi

    # 2. Compare TypeScript errors (new errors = regression)
    local old_ts_errors="${snapshot_path}/ts_errors.txt"
    if [[ -f "$old_ts_errors" ]]; then
        local old_error_count
        old_error_count=$(grep -cE 'error TS' "$old_ts_errors" 2>/dev/null || echo "0")

        local new_ts_errors
        new_ts_errors=$(mktemp 2>/dev/null || echo "/tmp/rp_ts_$$")
        if command -v npx &>/dev/null && [[ -f "${project_dir}/tsconfig.json" ]]; then
            (cd "$project_dir" && npx tsc --noEmit 2>&1 | head -50 > "$new_ts_errors") 2>/dev/null || true
        fi

        local new_error_count
        new_error_count=$(grep -cE 'error TS' "$new_ts_errors" 2>/dev/null || echo "0")

        if [[ $new_error_count -gt $old_error_count ]]; then
            local diff_count=$((new_error_count - old_error_count))
            regressions+=("TypeScriptエラーが${diff_count}個増加 (${old_error_count}→${new_error_count})")

            # Find the new errors
            local new_errors
            new_errors=$(diff "$old_ts_errors" "$new_ts_errors" 2>/dev/null | grep '^>' | head -5)
            if [[ -n "$new_errors" ]]; then
                local safe_errors
                safe_errors=$(echo "$new_errors" | head -c 300 | sed 's/"/\\"/g')
                warnings+=("新規TypeScriptエラー: ${safe_errors}")
            fi
        fi

        rm -f "$new_ts_errors" 2>/dev/null
    fi

    # 3. Compare exports - removed/changed exports cause regressions
    local old_exports="${snapshot_path}/exports.txt"
    if [[ -f "$old_exports" ]]; then
        local current_file=""
        while IFS= read -r line; do
            if echo "$line" | grep -qE '^=== .* ===$'; then
                current_file=$(echo "$line" | sed 's/^=== //;s/ ===$//')
                continue
            fi
            [[ -z "$line" || -z "$current_file" ]] && continue

            # Check if this export still exists
            local full_path="${project_dir}/${current_file}"
            [[ ! -f "$full_path" ]] && full_path="$current_file"

            if [[ -f "$full_path" ]]; then
                local export_name
                export_name=$(echo "$line" | grep -oE 'export (const|function|type|interface|class|enum|default) [a-zA-Z0-9_]+' | awk '{print $NF}')
                if [[ -n "$export_name" ]]; then
                    local still_exported
                    still_exported=$(grep -c "export.*${export_name}" "$full_path" 2>/dev/null || echo "0")
                    if [[ "$still_exported" -eq 0 ]]; then
                        regressions+=("export '${export_name}' が ${current_file} から削除された")
                    fi
                fi
            fi
        done < "$old_exports"
    fi

    # 4. Check if changed files broke their importers
    local changed_files
    changed_files=$(echo "$snapshot_data" | grep -oE '"changed":"[^"]*"' | sed 's/"changed":"//;s/"//')
    if [[ -n "$changed_files" ]]; then
        IFS=',' read -ra files_arr <<< "$changed_files"
        for f in "${files_arr[@]}"; do
            f=$(echo "$f" | sed 's/^ *//;s/ *$//')
            local basename_no_ext
            basename_no_ext=$(basename "$f" | sed 's/\.[^.]*$//')

            # Find files that import this changed file
            local importers
            importers=$(grep -rlE "from.*${basename_no_ext}" "$project_dir" \
                --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" 2>/dev/null | \
                grep -v node_modules | head -10)

            local importer_count
            importer_count=$(echo "$importers" | grep -c . 2>/dev/null || echo "0")

            if [[ $importer_count -gt 5 ]]; then
                warnings+=("${f} を変更: ${importer_count}ファイルがインポートしている（影響範囲大）")
            fi
        done
    fi

    # Build result
    local regression_count=${#regressions[@]}
    local warning_count=${#warnings[@]}
    local change_count=${#changes[@]}

    if [[ $regression_count -gt 0 ]]; then
        RP_REGRESSIONS_FOUND=$((RP_REGRESSIONS_FOUND + regression_count))
    fi

    local reg_json=""
    local first=true
    for r in "${regressions[@]}"; do
        [[ "$first" == "true" ]] && first=false || reg_json="${reg_json},"
        reg_json="${reg_json}\"$(echo "$r" | sed 's/"/\\"/g')\""
    done

    local warn_json=""
    first=true
    for w in "${warnings[@]}"; do
        [[ "$first" == "true" ]] && first=false || warn_json="${warn_json},"
        warn_json="${warn_json}\"$(echo "$w" | sed 's/"/\\"/g')\""
    done

    local change_json=""
    first=true
    for c in "${changes[@]}"; do
        [[ "$first" == "true" ]] && first=false || change_json="${change_json},"
        change_json="${change_json}\"$(echo "$c" | sed 's/"/\\"/g')\""
    done

    local has_regression="false"
    [[ $regression_count -gt 0 ]] && has_regression="true"

    # Log regression
    if [[ "$has_regression" == "true" ]]; then
        _RP_REGRESSION_LOG+=("{\"snapshot\":\"${snapshot_id}\",\"count\":${regression_count},\"ts\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}")
    fi

    cat <<EOF
{
  "snapshot_id": "${snapshot_id}",
  "has_regression": ${has_regression},
  "regression_count": ${regression_count},
  "warning_count": ${warning_count},
  "unexpected_changes": ${change_count},
  "regressions": [${reg_json}],
  "warnings": [${warn_json}],
  "changed_files": [${change_json}]
}
EOF
    return 0
}

# =============================================================================
# _rp_check_regression - Full regression check (snapshot + compare + test)
# Arguments:
#   $1 - project_dir
#   $2 - changed_files (comma-separated)
# Returns:
#   JSON with complete regression analysis
# =============================================================================
_rp_check_regression() {
    local project_dir="${1:-.}"
    local changed_files="${2:-}"

    # Take a post-fix snapshot for comparison
    local snapshot_id="regcheck_$(date +%s)_$$"

    # If we have a previous snapshot, compare with it
    local latest_snap=""
    for id in "${!_RP_SNAPSHOTS[@]}"; do
        latest_snap="$id"
    done

    if [[ -n "$latest_snap" ]]; then
        local comparison
        comparison=$(_rp_compare_after "$latest_snap" "$project_dir")
        echo "$comparison"
    else
        # No previous snapshot - do a fresh analysis
        local impact
        impact=$(_rp_get_change_impact "$changed_files" "$project_dir")

        local blast_radius
        blast_radius=$(echo "$impact" | grep -oE '"blast_radius":[0-9]+' | sed 's/"blast_radius"://')

        local test_suggestions
        test_suggestions=$(_rp_suggest_guard_tests "$changed_files" "$project_dir")

        cat <<EOF
{
  "has_regression": false,
  "note": "前回のスナップショットなし（初回チェック）",
  "blast_radius": ${blast_radius:-0},
  "impact": ${impact},
  "suggested_tests": ${test_suggestions}
}
EOF
    fi

    return 0
}

# =============================================================================
# _rp_run_affected_tests - Run only tests affected by changed files
# Arguments:
#   $1 - changed_files (comma-separated)
#   $2 - project_dir
# Returns:
#   JSON with test results
# =============================================================================
_rp_run_affected_tests() {
    local changed_files="${1:-}"
    local project_dir="${2:-.}"

    [[ -z "$changed_files" ]] && echo '{"tests_run":0,"note":"no changed files specified"}' && return 0

    local affected_tests=()

    # Find test files related to changed files
    IFS=',' read -ra files_arr <<< "$changed_files"
    for f in "${files_arr[@]}"; do
        f=$(echo "$f" | sed 's/^ *//;s/ *$//')
        local basename_no_ext
        basename_no_ext=$(basename "$f" | sed 's/\.[^.]*$//')

        # Look for test files with matching name
        local test_patterns=(
            "${basename_no_ext}.test.ts"
            "${basename_no_ext}.test.tsx"
            "${basename_no_ext}.spec.ts"
            "${basename_no_ext}.spec.tsx"
        )

        for pattern in "${test_patterns[@]}"; do
            local found
            found=$(find "$project_dir" -name "$pattern" ! -path "*/node_modules/*" 2>/dev/null | head -3)
            while IFS= read -r test_file; do
                [[ -z "$test_file" ]] && continue
                affected_tests+=("$test_file")
            done <<< "$found"
        done

        # Also find test files that import the changed file
        local importing_tests
        importing_tests=$(grep -rlE "from.*${basename_no_ext}" "$project_dir" \
            --include="*.test.ts" --include="*.test.tsx" --include="*.spec.ts" --include="*.spec.tsx" \
            2>/dev/null | grep -v node_modules | head -5)

        while IFS= read -r test_file; do
            [[ -z "$test_file" ]] && continue
            local already=false
            for existing in "${affected_tests[@]}"; do
                [[ "$existing" == "$test_file" ]] && already=true && break
            done
            [[ "$already" == "false" ]] && affected_tests+=("$test_file")
        done <<< "$importing_tests"
    done

    # Deduplicate
    local unique_tests=()
    declare -A seen_tests
    for t in "${affected_tests[@]}"; do
        if [[ -z "${seen_tests[$t]:-}" ]]; then
            seen_tests["$t"]=1
            unique_tests+=("$t")
        fi
    done

    local test_count=${#unique_tests[@]}

    # Build test file list JSON
    local tests_json=""
    local first=true
    for t in "${unique_tests[@]}"; do
        [[ "$first" == "true" ]] && first=false || tests_json="${tests_json},"
        local rel_path
        rel_path=$(echo "$t" | sed "s|^${project_dir}/||")
        tests_json="${tests_json}\"${rel_path}\""
    done

    # Try to run affected tests
    local test_result="not_run"
    local test_output=""
    local pass_count=0
    local fail_count=0

    if [[ $test_count -gt 0 ]]; then
        local pkg_json="${project_dir}/package.json"
        if [[ -f "$pkg_json" ]]; then
            # Determine test runner
            local runner_cmd=""
            if grep -q '"vitest"' "$pkg_json" 2>/dev/null; then
                runner_cmd="npx vitest run --reporter=verbose"
            elif grep -q '"jest"' "$pkg_json" 2>/dev/null; then
                runner_cmd="npx jest --verbose"
            fi

            if [[ -n "$runner_cmd" ]]; then
                # Build file args
                local file_args=""
                for t in "${unique_tests[@]}"; do
                    file_args="${file_args} ${t}"
                done

                # Run tests (with timeout)
                local test_log
                test_log=$(mktemp 2>/dev/null || echo "/tmp/rp_test_$$")

                (cd "$project_dir" && timeout 60 $runner_cmd $file_args > "$test_log" 2>&1) || true

                if [[ -f "$test_log" ]]; then
                    pass_count=$(grep -cE '(PASS|passed|✓|✔)' "$test_log" 2>/dev/null || echo "0")
                    fail_count=$(grep -cE '(FAIL|failed|✗|✘|×)' "$test_log" 2>/dev/null || echo "0")
                    test_output=$(tail -10 "$test_log" | head -c 500 | sed 's/"/\\"/g; s/\n/ /g')

                    if [[ $fail_count -gt 0 ]]; then
                        test_result="failed"
                        RP_REGRESSIONS_FOUND=$((RP_REGRESSIONS_FOUND + fail_count))
                    else
                        test_result="passed"
                        RP_REGRESSIONS_PREVENTED=$((RP_REGRESSIONS_PREVENTED + 1))
                    fi
                fi

                rm -f "$test_log" 2>/dev/null
            else
                test_result="no_runner"
            fi
        fi
    fi

    cat <<EOF
{
  "tests_found": ${test_count},
  "test_files": [${tests_json}],
  "result": "${test_result}",
  "passed": ${pass_count},
  "failed": ${fail_count},
  "output_summary": "$(echo "$test_output" | head -c 300 | sed 's/"/\\"/g')"
}
EOF
    return 0
}

# =============================================================================
# _rp_suggest_guard_tests - Suggest tests to prevent regression
# Arguments:
#   $1 - changed_files (comma-separated)
#   $2 - project_dir
# Returns:
#   JSON array of test suggestions
# =============================================================================
_rp_suggest_guard_tests() {
    local changed_files="${1:-}"
    local project_dir="${2:-.}"

    local suggestions=()

    IFS=',' read -ra files_arr <<< "$changed_files"
    for f in "${files_arr[@]}"; do
        f=$(echo "$f" | sed 's/^ *//;s/ *$//')
        [[ -z "$f" ]] && continue

        local basename_file
        basename_file=$(basename "$f")
        local basename_no_ext
        basename_no_ext=$(echo "$basename_file" | sed 's/\.[^.]*$//')
        local ext
        ext=$(echo "$basename_file" | grep -oE '\.[^.]+$')

        # Skip test files themselves
        echo "$f" | grep -qE '\.(test|spec)\.' && continue

        # Determine what kind of test to suggest based on file type
        case "$f" in
            *route.ts|*route.js)
                # API route → suggest API integration test
                local api_path
                api_path=$(echo "$f" | grep -oE 'app/api/.*/' | sed 's|app/api/||;s|/route\.\(ts\|js\)||;s|/$||')
                suggestions+=("{\"file\":\"${basename_no_ext}.test.ts\",\"type\":\"api_integration\",\"description\":\"APIルート /api/${api_path} のCRUD操作テスト (GET/POST/PUT/DELETE)。ステータスコード、レスポンスボディ、バリデーションエラーを検証。\"}")
                RP_TESTS_SUGGESTED=$((RP_TESTS_SUGGESTED + 1))
                ;;
            *page.tsx|*page.ts)
                # Page component → suggest render test
                suggestions+=("{\"file\":\"${basename_no_ext}.test.tsx\",\"type\":\"component_render\",\"description\":\"ページコンポーネントのレンダリングテスト。主要要素の存在、ローディング状態、エラー状態を検証。\"}")
                RP_TESTS_SUGGESTED=$((RP_TESTS_SUGGESTED + 1))
                ;;
            *schema.prisma)
                # Schema → suggest migration test
                suggestions+=("{\"file\":\"schema-validation.test.ts\",\"type\":\"schema_validation\",\"description\":\"Prismaスキーマの整合性テスト。全モデルのCRUD操作、リレーション、ユニーク制約を検証。\"}")
                RP_TESTS_SUGGESTED=$((RP_TESTS_SUGGESTED + 1))
                ;;
            *lib/*|*utils/*|*shared/*|*hooks/*)
                # Shared module → suggest unit test
                local full_path="${project_dir}/${f}"
                [[ ! -f "$full_path" ]] && full_path="$f"

                local exported_funcs=""
                if [[ -f "$full_path" ]]; then
                    exported_funcs=$(grep -oE 'export (async )?(function|const) ([a-zA-Z0-9_]+)' "$full_path" 2>/dev/null | awk '{print $NF}' | head -5 | tr '\n' ',')
                fi

                suggestions+=("{\"file\":\"${basename_no_ext}.test.ts\",\"type\":\"unit\",\"description\":\"ユニットテスト: ${exported_funcs:-関数} の入出力、エッジケース、エラーハンドリングを検証。\"}")
                RP_TESTS_SUGGESTED=$((RP_TESTS_SUGGESTED + 1))
                ;;
            *components/*)
                # Component → suggest component test
                suggestions+=("{\"file\":\"${basename_no_ext}.test.tsx\",\"type\":\"component\",\"description\":\"コンポーネントテスト: レンダリング、ユーザーインタラクション(クリック/入力)、props変更時の再レンダリングを検証。\"}")
                RP_TESTS_SUGGESTED=$((RP_TESTS_SUGGESTED + 1))
                ;;
            *middleware*)
                suggestions+=("{\"file\":\"middleware.test.ts\",\"type\":\"middleware\",\"description\":\"ミドルウェアテスト: 認証チェック、リダイレクト、ヘッダー設定、保護ルートのアクセス制御を検証。\"}")
                RP_TESTS_SUGGESTED=$((RP_TESTS_SUGGESTED + 1))
                ;;
        esac
    done

    # Build JSON array
    local json="["
    local first=true
    for s in "${suggestions[@]}"; do
        [[ "$first" == "true" ]] && first=false || json="${json},"
        json="${json}${s}"
    done
    json="${json}]"

    echo "$json"
    return 0
}

# =============================================================================
# _rp_get_change_impact - Calculate blast radius of changes
# Arguments:
#   $1 - changed_files (comma-separated)
#   $2 - project_dir
# Returns:
#   JSON with impact analysis
# =============================================================================
_rp_get_change_impact() {
    local changed_files="${1:-}"
    local project_dir="${2:-.}"

    local total_importers=0
    local direct_importers=0
    local indirect_importers=0
    local affected_pages=0
    local affected_apis=0
    local affected_components=0
    local critical_files=()

    IFS=',' read -ra files_arr <<< "$changed_files"
    for f in "${files_arr[@]}"; do
        f=$(echo "$f" | sed 's/^ *//;s/ *$//')
        [[ -z "$f" ]] && continue

        local basename_no_ext
        basename_no_ext=$(basename "$f" | sed 's/\.[^.]*$//')

        # Check cache
        if [[ -n "${_RP_IMPACT_CACHE[$f]:-}" ]]; then
            local cached="${_RP_IMPACT_CACHE[$f]}"
            local cached_count
            cached_count=$(echo "$cached" | grep -oE '"direct_importers":[0-9]+' | sed 's/"direct_importers"://')
            direct_importers=$((direct_importers + ${cached_count:-0}))
            continue
        fi

        # Find direct importers
        local importers
        importers=$(grep -rlE "from.*['\"].*${basename_no_ext}['\"]|import.*${basename_no_ext}" "$project_dir" \
            --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" 2>/dev/null | \
            grep -v node_modules | grep -v ".next")

        local file_direct=0
        local file_pages=0
        local file_apis=0
        local file_components=0

        while IFS= read -r importer; do
            [[ -z "$importer" ]] && continue
            file_direct=$((file_direct + 1))

            # Classify importer
            if echo "$importer" | grep -qE 'page\.(ts|tsx|js|jsx)$'; then
                file_pages=$((file_pages + 1))
            elif echo "$importer" | grep -qE 'route\.(ts|js)$'; then
                file_apis=$((file_apis + 1))
            elif echo "$importer" | grep -qE 'components/'; then
                file_components=$((file_components + 1))
            fi

            # Check for indirect importers (files that import the direct importers)
            local importer_basename
            importer_basename=$(basename "$importer" | sed 's/\.[^.]*$//')
            local indirect
            indirect=$(grep -rlE "from.*${importer_basename}" "$project_dir" \
                --include="*.ts" --include="*.tsx" 2>/dev/null | grep -v node_modules | wc -l | tr -d ' ')
            indirect_importers=$((indirect_importers + ${indirect:-0}))
        done <<< "$importers"

        direct_importers=$((direct_importers + file_direct))
        affected_pages=$((affected_pages + file_pages))
        affected_apis=$((affected_apis + file_apis))
        affected_components=$((affected_components + file_components))

        # Identify critical files
        if [[ $file_direct -gt 10 ]]; then
            critical_files+=("${f}(${file_direct}依存)")
        fi

        # Cache
        _RP_IMPACT_CACHE["$f"]="{\"direct_importers\":${file_direct},\"pages\":${file_pages},\"apis\":${file_apis}}"
    done

    total_importers=$((direct_importers + indirect_importers))

    # Calculate blast radius score (0-100)
    local blast_radius=0
    if [[ $total_importers -gt 50 ]]; then
        blast_radius=100
    elif [[ $total_importers -gt 20 ]]; then
        blast_radius=80
    elif [[ $total_importers -gt 10 ]]; then
        blast_radius=60
    elif [[ $total_importers -gt 5 ]]; then
        blast_radius=40
    elif [[ $total_importers -gt 0 ]]; then
        blast_radius=20
    else
        blast_radius=5
    fi

    local risk_level="low"
    if [[ $blast_radius -ge 60 ]]; then
        risk_level="high"
    elif [[ $blast_radius -ge 30 ]]; then
        risk_level="medium"
    fi

    # Build critical files JSON
    local crit_json=""
    local first=true
    for c in "${critical_files[@]}"; do
        [[ "$first" == "true" ]] && first=false || crit_json="${crit_json},"
        crit_json="${crit_json}\"$(echo "$c" | sed 's/"/\\"/g')\""
    done

    cat <<EOF
{
  "blast_radius": ${blast_radius},
  "risk_level": "${risk_level}",
  "direct_importers": ${direct_importers},
  "indirect_importers": ${indirect_importers},
  "total_affected": ${total_importers},
  "affected_pages": ${affected_pages},
  "affected_apis": ${affected_apis},
  "affected_components": ${affected_components},
  "critical_files": [${crit_json}]
}
EOF
    return 0
}

# =============================================================================
# _rp_generate_guard_test_code - Generate actual test code for a suggestion
# Arguments:
#   $1 - test_type (api_integration|component_render|unit|schema_validation)
#   $2 - target_file (the file being tested)
#   $3 - project_dir
# Returns:
#   Test code template via stdout
# =============================================================================
_rp_generate_guard_test_code() {
    local test_type="${1:-unit}"
    local target_file="${2:-}"
    local project_dir="${3:-.}"

    local basename_no_ext
    basename_no_ext=$(basename "$target_file" | sed 's/\.[^.]*$//')

    case "$test_type" in
        "api_integration")
            cat <<'TESTEOF'
import { describe, it, expect } from 'vitest';

describe('API Route Guard Test', () => {
  it('GET should return 200 with valid data', async () => {
    const res = await fetch('/api/ENDPOINT');
    expect(res.status).toBe(200);
    const data = await res.json();
    expect(data).toBeDefined();
  });

  it('POST should validate input', async () => {
    const res = await fetch('/api/ENDPOINT', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({})
    });
    expect([400, 422]).toContain(res.status);
  });

  it('should require authentication', async () => {
    const res = await fetch('/api/ENDPOINT', {
      headers: {} // no auth
    });
    expect([401, 403]).toContain(res.status);
  });
});
TESTEOF
            ;;
        "component_render")
            cat <<TESTEOF
import { describe, it, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import Page from './${basename_no_ext}';

describe('${basename_no_ext} Guard Test', () => {
  it('should render without crashing', () => {
    render(<Page />);
    expect(document.body).toBeTruthy();
  });

  it('should show loading state initially', () => {
    render(<Page />);
    // Verify loading indicator exists
  });

  it('should handle empty data gracefully', () => {
    render(<Page />);
    // Verify empty state UI
  });
});
TESTEOF
            ;;
        "unit")
            cat <<TESTEOF
import { describe, it, expect } from 'vitest';
import * as module from './${basename_no_ext}';

describe('${basename_no_ext} Guard Test', () => {
  it('module should export expected functions', () => {
    expect(module).toBeDefined();
  });

  it('should handle null/undefined input', () => {
    // Test each exported function with null/undefined
  });

  it('should handle edge cases', () => {
    // Test boundary values, empty strings, etc.
  });
});
TESTEOF
            ;;
        *)
            echo "// Guard test template for ${basename_no_ext}"
            echo "// Type: ${test_type}"
            ;;
    esac

    return 0
}

# =============================================================================
# _rp_cleanup_snapshots - Clean up old snapshots to save disk space
# Arguments:
#   $1 - max_age_hours (default 24)
# =============================================================================
_rp_cleanup_snapshots() {
    local max_age="${1:-24}"

    [[ ! -d "$RP_SNAPSHOT_DIR" ]] && return 0

    find "$RP_SNAPSHOT_DIR" -maxdepth 1 -type d -name "snap_*" -mmin "+$((max_age * 60))" \
        -exec rm -rf {} + 2>/dev/null || true

    return 0
}

# =============================================================================
# rp_report - Module report output
# =============================================================================
rp_report() {
    echo -e "\n  ${CLR_BOLD:-}═══ Regression Preventer v${RP_VERSION} ═══${CLR_NC:-}" >&2
    echo -e "  スナップショット数 : ${RP_SNAPSHOTS_TAKEN}" >&2
    echo -e "  チェック総数       : ${RP_TOTAL_CHECKS}" >&2
    echo -e "  リグレッション検出 : ${RP_REGRESSIONS_FOUND}" >&2
    echo -e "  リグレッション防止 : ${RP_REGRESSIONS_PREVENTED}" >&2
    echo -e "  テスト提案数       : ${RP_TESTS_SUGGESTED}" >&2

    if [[ $RP_TOTAL_CHECKS -gt 0 ]]; then
        local detection_rate=0
        if [[ $RP_REGRESSIONS_FOUND -gt 0 || $RP_REGRESSIONS_PREVENTED -gt 0 ]]; then
            detection_rate=$(( (RP_REGRESSIONS_PREVENTED * 100) / (RP_REGRESSIONS_FOUND + RP_REGRESSIONS_PREVENTED + 1) ))
        fi
        echo -e "  防止率             : ${detection_rate}%" >&2
    fi
}

# =============================================================================
# rp_score - Module score (0-100)
# =============================================================================
rp_score() {
    local score=50

    # Bonus for usage
    [[ $RP_SNAPSHOTS_TAKEN -ge 1 ]] && score=$((score + 10))
    [[ $RP_TOTAL_CHECKS -ge 1 ]] && score=$((score + 10))

    # Bonus for prevention
    if [[ $RP_REGRESSIONS_PREVENTED -gt 0 ]]; then
        score=$((score + 15))
    fi

    # Bonus for test suggestions
    if [[ $RP_TESTS_SUGGESTED -ge 3 ]]; then
        score=$((score + 10))
    fi

    # Penalty for unresolved regressions
    if [[ $RP_REGRESSIONS_FOUND -gt 0 && $RP_REGRESSIONS_PREVENTED -eq 0 ]]; then
        score=$((score - 10))
    fi

    [[ $score -gt 100 ]] && score=100
    [[ $score -lt 0 ]] && score=0

    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "regression-preventer" \
    --version "255.0" \
    --description "修正後のリグレッション検出・防止・ガードテスト提案" \
    --init "rp_init" \
    --report "rp_report" \
    --score "rp_score" \
    --enable-var "ENABLE_RP" \
    --cli-flags "--regression-preventer:--no-regression-preventer"
