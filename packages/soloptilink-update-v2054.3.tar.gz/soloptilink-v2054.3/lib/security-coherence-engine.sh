#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v2004.0 - Security Coherence Engine (セキュリティ連鎖検出エンジン)
# ============================================================
#
# 目的:
#   1箇所のセキュリティ問題を修正する際、関連する全箇所を自動特定して
#   まとめて修正漏れを防ぐ。
#   「Aを直すなら、BとCも直さないと意味がない」を自動で教えてくれる。
#
# 主要機能:
#   - セキュリティ依存マップ（どのコンポーネントがどのセキュリティに依存するか）
#   - 連鎖スキャン（1つ修正 → 関連箇所を自動検出）
#   - ビジネス言語変換（技術用語 → わかりやすい日本語）
#   - 契約認識型セキュリティ（料金設計に基づいたリスク評価）
#
# Module Registry v59.0 自動登録
# ============================================================

# ============================================================
# 定数・カラー定義
# ============================================================
SCE_VERSION="1.0.0"
SCE_MODULE_NAME="security-coherence-engine"

# セキュリティリスクレベル
SCE_RISK_CRITICAL="🔴 CRITICAL"
SCE_RISK_HIGH="🟠 HIGH"
SCE_RISK_MEDIUM="🟡 MEDIUM"
SCE_RISK_LOW="🟢 LOW"

# ============================================================
# セキュリティ依存マップ
# 「このコンポーネントを修正したら、これも確認せよ」という関係性定義
# ============================================================

declare -A _SCE_DEPENDENCY_MAP

_sce_init_dependency_map() {
    # ライセンス認証 → 関連コンポーネント
    _SCE_DEPENDENCY_MAP["license_verify"]="terminal_auth device_register contract_limit"
    _SCE_DEPENDENCY_MAP["terminal_auth"]="license_verify session_token device_count"
    _SCE_DEPENDENCY_MAP["device_register"]="contract_limit company_status license_status"
    _SCE_DEPENDENCY_MAP["contract_limit"]="device_register terminal_auth billing"

    # 認証・認可 → 関連コンポーネント
    _SCE_DEPENDENCY_MAP["auth_login"]="auth_session auth_token password_hash rate_limit"
    _SCE_DEPENDENCY_MAP["auth_session"]="auth_login auth_token session_expiry"
    _SCE_DEPENDENCY_MAP["auth_token"]="auth_login auth_session token_expiry"
    _SCE_DEPENDENCY_MAP["password_hash"]="auth_login user_register password_reset"
    _SCE_DEPENDENCY_MAP["rate_limit"]="auth_login api_endpoints brute_force"

    # データアクセス → 関連コンポーネント
    _SCE_DEPENDENCY_MAP["sql_query"]="sql_injection input_validation orm_usage"
    _SCE_DEPENDENCY_MAP["api_endpoint"]="auth_middleware input_validation rate_limit error_handling"
    _SCE_DEPENDENCY_MAP["file_upload"]="mime_validation size_limit virus_scan path_traversal"

    # 課金・契約 → 関連コンポーネント（契約認識型セキュリティ）
    _SCE_DEPENDENCY_MAP["billing"]="contract_limit device_count license_status payment_validation"
    _SCE_DEPENDENCY_MAP["device_count"]="contract_limit billing terminal_auth device_register"
    _SCE_DEPENDENCY_MAP["payment_validation"]="billing contract_status invoice_generation"
}

# ============================================================
# ビジネス言語変換テーブル
# 技術用語 → お客様向けのわかりやすい日本語
# ============================================================

declare -A _SCE_BUSINESS_LANGUAGE

_sce_init_business_language() {
    _SCE_BUSINESS_LANGUAGE["license_verify_bypass"]="ライセンスキーを持っているだけで端末認証をスキップして使えてしまう問題"
    _SCE_BUSINESS_LANGUAGE["terminal_not_verified"]="管理者が承認していない端末でも使えてしまう問題"
    _SCE_BUSINESS_LANGUAGE["device_limit_bypass"]="契約台数を超えて追加料金なしに複数端末で使えてしまう問題"
    _SCE_BUSINESS_LANGUAGE["auth_bypass"]="パスワードなしでログインできてしまう問題"
    _SCE_BUSINESS_LANGUAGE["sql_injection"]="悪意ある入力でデータベースのデータを盗まれたり壊されたりする問題"
    _SCE_BUSINESS_LANGUAGE["weak_password"]="推測されやすいパスワードが設定できてしまう問題"
    _SCE_BUSINESS_LANGUAGE["session_hijack"]="他のユーザーのログイン状態を乗っ取れてしまう問題"
    _SCE_BUSINESS_LANGUAGE["data_leak"]="お客様の情報が外部に漏れてしまう問題"
    _SCE_BUSINESS_LANGUAGE["rate_limit_missing"]="大量アクセスでシステムが止まってしまう問題"
    _SCE_BUSINESS_LANGUAGE["contract_expired_bypass"]="契約が終わっているのに使い続けられてしまう問題"
    _SCE_BUSINESS_LANGUAGE["hmac_missing"]="データが改ざんされても検知できない問題"
    _SCE_BUSINESS_LANGUAGE["cors_misconfigured"]="どのウェブサイトからでもAPIにアクセスできてしまう問題"
}

# ============================================================
# メイン関数: セキュリティ修正時の連鎖チェック
# ============================================================

# セキュリティ修正箇所から関連コンポーネントを特定して報告
# 使用例: sce_analyze_fix_cascade "license_verify" "/path/to/project"
sce_analyze_fix_cascade() {
    local fixed_component="${1:-}"
    local project_dir="${2:-.}"
    local report_file="${3:-/tmp/sce_cascade_report.md}"

    _sce_init_dependency_map
    _sce_init_business_language

    echo ""
    echo "╔════════════════════════════════════════════════════════╗"
    echo "║   🔍 セキュリティ連鎖チェック (Security Coherence)    ║"
    echo "╚════════════════════════════════════════════════════════╝"
    echo ""
    echo "修正済みコンポーネント: ${fixed_component}"
    echo ""

    # 関連コンポーネントを取得
    local related_components="${_SCE_DEPENDENCY_MAP[$fixed_component]:-}"

    if [[ -z "$related_components" ]]; then
        echo "✅ このコンポーネントの既知の依存関係は見つかりませんでした。"
        return 0
    fi

    echo "⚠️  以下の関連箇所も確認が必要です:"
    echo ""

    local cascade_count=0
    for component in $related_components; do
        cascade_count=$((cascade_count + 1))
        local business_desc="${_SCE_BUSINESS_LANGUAGE[${component}_bypass]:-${_SCE_BUSINESS_LANGUAGE[$component]:-$component の確認が必要}}"

        echo "  ${cascade_count}. 📌 ${component}"
        echo "     → ${business_desc}"

        # プロジェクト内の関連ファイルを検索
        _sce_find_related_files "$component" "$project_dir"
        echo ""
    done

    # レポート生成
    _sce_generate_cascade_report "$fixed_component" "$related_components" "$project_dir" "$report_file"

    echo "📄 詳細レポート: ${report_file}"
    echo ""
}

# 関連ファイルを検索して表示
_sce_find_related_files() {
    local component="$1"
    local project_dir="$2"

    local search_patterns=()

    case "$component" in
        terminal_auth|license_verify)
            search_patterns=("license/verify" "license/terminal" "license-guard" "verifyLicense")
            ;;
        device_register|device_count)
            search_patterns=("devices/register" "device_count" "maxDevices" "max_devices")
            ;;
        contract_limit|billing)
            search_patterns=("contract" "billing" "max_devices" "device.*limit")
            ;;
        auth_login|auth_session)
            search_patterns=("auth/login" "auth/session" "jwt" "bcrypt" "session")
            ;;
        rate_limit)
            search_patterns=("rate-limit" "rateLimit" "rateLimitMap")
            ;;
        sql_query)
            search_patterns=("SELECT\|INSERT\|UPDATE\|DELETE" "prisma" "getDb()")
            ;;
    esac

    if [[ ${#search_patterns[@]} -gt 0 ]]; then
        for pattern in "${search_patterns[@]}"; do
            local files
            files=$(grep -rl "$pattern" "$project_dir" \
                --include="*.ts" --include="*.tsx" --include="*.js" \
                2>/dev/null | head -3)
            if [[ -n "$files" ]]; then
                while IFS= read -r file; do
                    local relative_path="${file#$project_dir/}"
                    echo "     📁 ${relative_path}"
                done <<< "$files"
            fi
        done
    fi
}

# ============================================================
# 契約認識型セキュリティスキャン
# 料金設計（1台¥100,000 / 追加¥30,000）に基づくリスク評価
# ============================================================

sce_contract_aware_security_scan() {
    local project_dir="${1:-.}"

    echo ""
    echo "╔════════════════════════════════════════════════════════╗"
    echo "║  💰 契約認識型セキュリティスキャン                    ║"
    echo "║  （お金周りのセキュリティを重点チェック）             ║"
    echo "╚════════════════════════════════════════════════════════╝"
    echo ""
    echo "料金設計: 1台目 ¥100,000 / 追加1台 ¥30,000"
    echo ""

    local issues_found=0

    # チェック1: ライセンス検証でmachine_id必須化
    echo "【チェック1】端末認証必須化"
    if grep -r "machine_id" "${project_dir}" \
        --include="*.ts" --include="*.tsx" 2>/dev/null | \
        grep -q "required\|必須\|MACHINE_ID_REQUIRED"; then
        echo "  ✅ machine_id が必須として実装されています"
    else
        echo "  🔴 CRITICAL: machine_id がオプション扱いの可能性があります"
        echo "     → 端末認証を経ずにライセンスキーだけで使えてしまうリスクがあります"
        echo "     → 対応: /api/v1/license/verify でmachine_id必須チェックを追加"
        issues_found=$((issues_found + 1))
    fi
    echo ""

    # チェック2: 端末テーブルのACTIVEチェック
    echo "【チェック2】端末承認ステータス確認"
    if grep -r "terminal_status\|terminalStatus\|ACTIVE" "${project_dir}/admin-dashboard/app/api/v1/license" \
        --include="*.ts" 2>/dev/null | grep -q "terminal_status\|ACTIVE"; then
        echo "  ✅ 端末のACTIVEステータス確認が実装されています"
    else
        echo "  🔴 CRITICAL: 端末のステータス確認が不十分な可能性があります"
        echo "     → 管理者が未承認の端末でも使えてしまうリスクがあります"
        issues_found=$((issues_found + 1))
    fi
    echo ""

    # チェック3: 契約台数上限チェック
    echo "【チェック3】契約台数上限チェック"
    if grep -r "max_devices\|maxDevices\|DEVICE_LIMIT" "${project_dir}" \
        --include="*.ts" --include="*.tsx" 2>/dev/null | grep -q "max_devices\|DEVICE_LIMIT"; then
        echo "  ✅ 契約台数の上限チェックが実装されています"
    else
        echo "  🔴 CRITICAL: 契約台数の上限チェックがありません"
        echo "     → 1台契約のお客様が追加料金なしに何台でも使えてしまうリスクがあります"
        echo "     → 追加1台 ¥30,000 の収益機会損失につながります"
        issues_found=$((issues_found + 1))
    fi
    echo ""

    # チェック4: 契約有効期限チェック
    echo "【チェック4】契約有効期限チェック"
    if grep -r "contract_status\|contractStatus\|expired\|EXPIRED" \
        "${project_dir}/admin-dashboard/app/api/v1/license" \
        --include="*.ts" 2>/dev/null | grep -q "EXPIRED\|expired\|contract"; then
        echo "  ✅ 契約有効期限の確認が実装されています"
    else
        echo "  🟠 HIGH: 契約有効期限の確認が不十分な可能性があります"
        echo "     → 契約期限切れのお客様が使い続けられてしまうリスクがあります"
        issues_found=$((issues_found + 1))
    fi
    echo ""

    # チェック5: レート制限
    echo "【チェック5】ライセンス認証のレート制限"
    if grep -r "rateLimit\|rateLimitMap\|RATE_LIMIT" \
        "${project_dir}/admin-dashboard/app/api/v1/license" \
        --include="*.ts" 2>/dev/null | grep -q "rateLimit\|RATE_LIMIT"; then
        echo "  ✅ レート制限が実装されています"
    else
        echo "  🟠 HIGH: レート制限がありません"
        echo "     → ライセンスキーの総当たり攻撃でシステムが止まる可能性があります"
        issues_found=$((issues_found + 1))
    fi
    echo ""

    # サマリー
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    if [[ $issues_found -eq 0 ]]; then
        echo "✅ 契約認識型セキュリティスキャン: 問題なし"
    else
        echo "⚠️  ${issues_found}件の問題が見つかりました"
        echo "   料金漏れリスク: 1台 ¥30,000〜¥100,000 の収益機会損失の可能性"
    fi
    echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    echo ""

    return $issues_found
}

# ============================================================
# レポート生成
# ============================================================

_sce_generate_cascade_report() {
    local fixed_component="$1"
    local related_components="$2"
    local project_dir="$3"
    local report_file="$4"

    cat > "$report_file" << REPORT_EOF
# セキュリティ連鎖修正レポート
生成日時: $(date '+%Y-%m-%d %H:%M:%S')

## 修正済みコンポーネント
- **${fixed_component}**

## 関連して確認が必要なコンポーネント

$(for comp in $related_components; do
    echo "### ${comp}"
    echo "確認が必要な理由: ${_SCE_DEPENDENCY_MAP[$comp]:-依存関係があります}"
    echo ""
done)

## 次のステップ
1. 上記の関連コンポーネントを順番に確認してください
2. 各コンポーネントで同様の問題がないか確認してください
3. 修正後、再度このスキャンを実行して漏れがないか確認してください

---
*このレポートはSoloptiLinkAI Security Coherence Engine v${SCE_VERSION}によって生成されました*
REPORT_EOF
}

# ============================================================
# セキュリティ修正提案をビジネス言語で生成
# ============================================================

sce_generate_business_proposal() {
    local issue_code="${1:-}"
    local context="${2:-}"

    _sce_init_business_language

    echo ""
    echo "╔════════════════════════════════════════════════════════╗"
    echo "║  📋 セキュリティ改善提案（わかりやすく説明）         ║"
    echo "╚════════════════════════════════════════════════════════╝"
    echo ""

    local business_desc="${_SCE_BUSINESS_LANGUAGE[$issue_code]:-この問題}"

    cat << PROPOSAL_EOF
【現在の状況】
${business_desc}が起きています。

【何が問題か】
$(_sce_get_business_problem "$issue_code")

【対策案】
$(_sce_get_business_solution "$issue_code")

【放置した場合のリスク】
$(_sce_get_business_risk "$issue_code")

PROPOSAL_EOF
}

_sce_get_business_problem() {
    local issue_code="$1"
    case "$issue_code" in
        license_verify_bypass)
            echo "お客様がライセンスキーをお持ちであれば、端末の登録・承認プロセスを通らずに"
            echo "そのままシステムをご利用できてしまいます。"
            ;;
        device_limit_bypass)
            echo "1台分の契約（¥100,000）をお持ちのお客様が、"
            echo "追加料金なしに複数台でご利用できてしまいます。"
            ;;
        contract_expired_bypass)
            echo "契約期限が切れたお客様が、更新なしにシステムを使い続けられます。"
            ;;
        *)
            echo "セキュリティ上の問題が検出されました。"
            ;;
    esac
}

_sce_get_business_solution() {
    local issue_code="$1"
    case "$issue_code" in
        license_verify_bypass)
            echo "1. 端末を使い始める前に、必ず端末登録を行うよう変更します"
            echo "2. 管理者が承認した端末のみが使えるよう制限をかけます"
            echo "3. 承認されていない端末でのアクセスは自動でブロックします"
            ;;
        device_limit_bypass)
            echo "1. 新しい端末を登録する際に、契約台数を自動チェックします"
            echo "2. 上限に達している場合は、わかりやすいメッセージで追加契約を案内します"
            echo "3. 管理画面で現在の使用台数と上限をリアルタイム表示します"
            ;;
        contract_expired_bypass)
            echo "1. 毎回の起動時に契約有効期限を確認します"
            echo "2. 期限切れの場合は自動でサービス停止し、更新案内を表示します"
            echo "3. 期限の30日前から管理者にアラートメールを送信します"
            ;;
        *)
            echo "詳細な対策については技術担当者にご相談ください。"
            ;;
    esac
}

_sce_get_business_risk() {
    local issue_code="$1"
    case "$issue_code" in
        license_verify_bypass)
            echo "・未承認端末でのご利用によるサポート範囲外の使用が発生します"
            echo "・不正アクセスや情報漏えいのリスクが高まります"
            ;;
        device_limit_bypass)
            echo "・1台につき ¥30,000/月 の売上機会損失が継続的に発生します"
            echo "・契約台数が把握できず、サポートコストが増加します"
            ;;
        contract_expired_bypass)
            echo "・更新されない契約に対してインフラコストが発生し続けます"
            echo "・未更新ユーザーへの請求が困難になります"
            ;;
        *)
            echo "セキュリティリスクが継続します。"
            ;;
    esac
}

# ============================================================
# Module Registry 自動登録 (v59.0)
# ============================================================
_mr_register() {
    local name="$1"
    local version="$2"
    if declare -f _mr_add_module > /dev/null 2>&1; then
        _mr_add_module "$name" "$version" "セキュリティ連鎖検出エンジン"
    fi
}

_mr_register "$SCE_MODULE_NAME" "$SCE_VERSION"
