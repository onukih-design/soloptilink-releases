#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v500.0 - Delivery Verification Module (納品検証)
# =============================================================================
# ビルドしたシステムが実際に動くかを検証し、合格するまで「完了」と報告しない。
#
# 検証項目:
#   1. プロジェクト種別検出 (Next.js / Node / static)
#   2. ビルド成功検証 (npm run build / next build)
#   3. 開発サーバー起動 & readiness ポーリング
#   4. /api/health エンドポイント検証
#   5. 主要ページルート HTTP 200 検証
#   6. ビルド出力中の JavaScript エラー検出
#   7. 検証レポート生成 (docs/verification-report.md)
#
# 使用方法:
#   source lib/delivery-verification.sh
#   dv_run_full_verification "/path/to/project"
# =============================================================================

[[ -n "${_DELIVERY_VERIFICATION_LOADED:-}" ]] && return 0
_DELIVERY_VERIFICATION_LOADED=1

# ============================================================
# Constants
# ============================================================
DV_VERSION="500.0"
DV_SERVER_START_TIMEOUT=30
DV_POLL_INTERVAL=2
DV_REQUEST_TIMEOUT=10
DV_DEFAULT_PORT=3000
DV_MAX_POLL_ATTEMPTS=$(( DV_SERVER_START_TIMEOUT / DV_POLL_INTERVAL ))

DV_DEFAULT_ROUTES=( "/" "/login" "/companies" "/devices" )

# ============================================================
# Colors (defensive: fall back when not already loaded)
# ============================================================
DV_GREEN="${GREEN:-\033[0;32m}"
DV_RED="${RED:-\033[0;31m}"
DV_YELLOW="${YELLOW:-\033[0;33m}"
DV_CYAN="${CYAN:-\033[0;36m}"
DV_BOLD="${BOLD:-\033[1m}"
DV_NC="${NC:-\033[0m}"

# ============================================================
# Internal state
# ============================================================
_DV_SERVER_PID=""
_DV_PORT=""
_DV_BASE_URL=""
_DV_PROJECT_DIR=""
_DV_LOG_DIR=""
_DV_BUILD_LOG=""
_DV_PASS_COUNT=0
_DV_FAIL_COUNT=0
_DV_SKIP_COUNT=0
_DV_RESULTS=()
_DV_INITIALIZED=0

# ============================================================
# Logging
# ============================================================
_dv_log() {
    local level="$1"; shift
    local msg="$*"
    local ts
    ts="$(date '+%Y-%m-%d %H:%M:%S')"
    echo -e "  [DeliveryVerify][${level}] ${msg}" >&2
    if [[ -n "${_DV_LOG_DIR:-}" && -d "${_DV_LOG_DIR}" ]]; then
        echo "[${ts}][DV][${level}] ${msg}" >> "${_DV_LOG_DIR}/delivery-verification.log" 2>/dev/null || true
    fi
}

# ============================================================
# Test result recording
# ============================================================
_dv_record() {
    local name="$1" status="$2" detail="${3:-}"

    case "$status" in
        PASS) (( _DV_PASS_COUNT++ )) ;;
        FAIL) (( _DV_FAIL_COUNT++ )) ;;
        SKIP) (( _DV_SKIP_COUNT++ )) ;;
    esac

    local entry="${status}: ${name}"
    [[ -n "$detail" ]] && entry="${entry} - ${detail}"
    _DV_RESULTS+=("$entry")
    _dv_log "$status" "${name}${detail:+ - ${detail}}"
}

# ============================================================
# Module init / report (Module Registry integration)
# ============================================================
dv_init() {
    _DV_PASS_COUNT=0
    _DV_FAIL_COUNT=0
    _DV_SKIP_COUNT=0
    _DV_RESULTS=()
    _DV_SERVER_PID=""
    _DV_INITIALIZED=1
    _dv_log "INFO" "Delivery Verification v${DV_VERSION} initialized"
}

dv_report() {
    echo -e "\n  ${DV_BOLD}=== Delivery Verification Report ===${DV_NC}"
    echo -e "  Version: ${DV_VERSION}"
    echo -e "  Pass: ${DV_GREEN}${_DV_PASS_COUNT}${DV_NC}  Fail: ${DV_RED}${_DV_FAIL_COUNT}${DV_NC}  Skip: ${DV_YELLOW}${_DV_SKIP_COUNT}${DV_NC}"
    if [[ ${#_DV_RESULTS[@]} -gt 0 ]]; then
        for r in "${_DV_RESULTS[@]}"; do
            local color="$DV_NC"
            case "${r%%:*}" in
                PASS) color="$DV_GREEN" ;;
                FAIL) color="$DV_RED" ;;
                SKIP) color="$DV_YELLOW" ;;
            esac
            echo -e "    ${color}${r}${DV_NC}"
        done
    fi
    echo ""
}

# ============================================================
# 1. Detect project type
# ============================================================
_dv_detect_project_type() {
    local dir="$1"

    if [[ ! -f "${dir}/package.json" ]]; then
        echo "unknown"
        return
    fi

    if [[ -f "${dir}/next.config.js" ]] || \
       [[ -f "${dir}/next.config.mjs" ]] || \
       [[ -f "${dir}/next.config.ts" ]]; then
        echo "nextjs"
        return
    fi

    if grep -q '"next"' "${dir}/package.json" 2>/dev/null; then
        echo "nextjs"
        return
    fi

    echo "node"
}

# ============================================================
# 2. Build verification
# ============================================================
_dv_run_build() {
    local dir="$1"
    local project_type="$2"
    local build_log="${_DV_LOG_DIR}/build.log"

    _dv_log "INFO" "ビルド検証開始 (type=${project_type})"

    if [[ ! -d "${dir}/node_modules" ]]; then
        _dv_log "INFO" "npm install 実行中..."
        if ! (cd "$dir" && npm install --no-audit --no-fund 2>&1) > "${_DV_LOG_DIR}/install.log" 2>&1; then
            _dv_record "npm install" "FAIL" "依存関係インストール失敗"
            return 1
        fi
        _dv_record "npm install" "PASS" "依存関係インストール完了"
    else
        _dv_record "npm install" "SKIP" "node_modules 存在済み"
    fi

    local build_cmd="npm run build"
    if [[ "$project_type" == "nextjs" ]]; then
        if grep -q '"build"' "${dir}/package.json" 2>/dev/null; then
            build_cmd="npm run build"
        else
            build_cmd="npx next build"
        fi
    fi

    _dv_log "INFO" "${build_cmd} 実行中..."
    if (cd "$dir" && eval "$build_cmd" 2>&1) > "$build_log" 2>&1; then
        _DV_BUILD_LOG="$build_log"
        _dv_record "ビルド" "PASS" "${build_cmd} 成功"
        return 0
    else
        _DV_BUILD_LOG="$build_log"
        local err_tail
        err_tail="$(tail -5 "$build_log" 2>/dev/null | tr '\n' ' ')"
        _dv_record "ビルド" "FAIL" "${build_cmd} 失敗: ${err_tail}"
        return 1
    fi
}

# ============================================================
# 3. Start dev server
# ============================================================
_dv_start_server() {
    local dir="$1"
    local port="${2:-$DV_DEFAULT_PORT}"
    local server_log="${_DV_LOG_DIR}/server.log"

    _DV_PORT="$port"
    _DV_BASE_URL="http://localhost:${port}"

    # Kill anything already on the port
    _dv_kill_port "$port"

    local start_cmd="npm run dev"
    if ! grep -q '"dev"' "${dir}/package.json" 2>/dev/null; then
        if grep -q '"start"' "${dir}/package.json" 2>/dev/null; then
            start_cmd="npm start"
        else
            _dv_record "サーバー起動" "FAIL" "dev/start スクリプト未定義"
            return 1
        fi
    fi

    _dv_log "INFO" "${start_cmd} (port=${port}) 起動中..."
    (cd "$dir" && PORT="$port" eval "$start_cmd" > "$server_log" 2>&1) &
    _DV_SERVER_PID=$!

    # Brief pause to allow process to spawn
    sleep 1

    # Check if process is still alive
    if ! kill -0 "$_DV_SERVER_PID" 2>/dev/null; then
        _dv_record "サーバー起動" "FAIL" "プロセス即座に終了"
        _DV_SERVER_PID=""
        return 1
    fi

    _dv_log "INFO" "サーバー起動 PID=${_DV_SERVER_PID}"
    return 0
}

# ============================================================
# 4. Wait for server readiness
# ============================================================
_dv_wait_for_ready() {
    local attempt=0

    _dv_log "INFO" "サーバー readiness ポーリング (max ${DV_SERVER_START_TIMEOUT}s)..."

    while (( attempt < DV_MAX_POLL_ATTEMPTS )); do
        (( attempt++ ))

        # Ensure process is still alive
        if [[ -n "${_DV_SERVER_PID}" ]] && ! kill -0 "$_DV_SERVER_PID" 2>/dev/null; then
            _dv_record "サーバー readiness" "FAIL" "サーバープロセスが終了 (attempt ${attempt})"
            return 1
        fi

        if curl -sf -o /dev/null --connect-timeout 2 --max-time "$DV_REQUEST_TIMEOUT" "${_DV_BASE_URL}/" 2>/dev/null; then
            _dv_record "サーバー readiness" "PASS" "${attempt} 回目のポーリングで応答確認 (${_DV_BASE_URL})"
            return 0
        fi

        sleep "$DV_POLL_INTERVAL"
    done

    _dv_record "サーバー readiness" "FAIL" "${DV_SERVER_START_TIMEOUT}秒以内に応答なし"
    return 1
}

# ============================================================
# 5. Health endpoint check
# ============================================================
_dv_check_health() {
    local url="${_DV_BASE_URL}/api/health"

    _dv_log "INFO" "ヘルスエンドポイント検証: ${url}"

    local http_code body
    http_code="$(curl -sf -o /dev/null -w '%{http_code}' --connect-timeout 5 --max-time "$DV_REQUEST_TIMEOUT" "$url" 2>/dev/null)" || http_code="000"

    if [[ "$http_code" == "200" ]]; then
        _dv_record "/api/health" "PASS" "HTTP 200"
        return 0
    elif [[ "$http_code" == "000" ]]; then
        _dv_record "/api/health" "SKIP" "エンドポイント未実装 (接続不可)"
        return 0  # Not a hard failure; many projects don't have /api/health
    else
        _dv_record "/api/health" "FAIL" "HTTP ${http_code} (期待: 200)"
        return 1
    fi
}

# ============================================================
# 6. Route verification
# ============================================================
_dv_check_routes() {
    local routes=("${@}")
    local all_pass=0

    if [[ ${#routes[@]} -eq 0 ]]; then
        routes=("${DV_DEFAULT_ROUTES[@]}")
    fi

    _dv_log "INFO" "ルート検証: ${routes[*]}"

    for route in "${routes[@]}"; do
        local url="${_DV_BASE_URL}${route}"
        local http_code
        http_code="$(curl -sf -o /dev/null -w '%{http_code}' -L --connect-timeout 5 --max-time "$DV_REQUEST_TIMEOUT" "$url" 2>/dev/null)" || http_code="000"

        if [[ "$http_code" == "200" ]] || [[ "$http_code" == "307" ]] || [[ "$http_code" == "302" ]]; then
            _dv_record "ルート ${route}" "PASS" "HTTP ${http_code}"
        elif [[ "$http_code" == "000" ]]; then
            _dv_record "ルート ${route}" "SKIP" "接続不可"
        else
            _dv_record "ルート ${route}" "FAIL" "HTTP ${http_code}"
            all_pass=1
        fi
    done

    return $all_pass
}

# ============================================================
# 7. JS error detection in build output
# ============================================================
_dv_check_build_errors() {
    if [[ -z "${_DV_BUILD_LOG:-}" ]] || [[ ! -f "${_DV_BUILD_LOG}" ]]; then
        _dv_record "JSエラー検出" "SKIP" "ビルドログなし"
        return 0
    fi

    _dv_log "INFO" "ビルド出力中の JS エラー検出..."

    local error_patterns=(
        "TypeError:"
        "ReferenceError:"
        "SyntaxError:"
        "Error: Cannot find module"
        "Module not found"
        "FATAL ERROR"
    )

    local found_errors=()
    for pattern in "${error_patterns[@]}"; do
        local count
        count="$(grep -c "$pattern" "$_DV_BUILD_LOG" 2>/dev/null)" || count=0
        if (( count > 0 )); then
            found_errors+=("${pattern} (${count}件)")
        fi
    done

    if [[ ${#found_errors[@]} -eq 0 ]]; then
        _dv_record "JSエラー検出" "PASS" "ビルド出力にエラーなし"
        return 0
    else
        local summary
        summary="$(printf '%s, ' "${found_errors[@]}")"
        _dv_record "JSエラー検出" "FAIL" "${summary%, }"
        return 1
    fi
}

# ============================================================
# Kill process on port (cleanup helper)
# ============================================================
_dv_kill_port() {
    local port="$1"
    local pid
    pid="$(lsof -ti :"$port" 2>/dev/null)" || true
    if [[ -n "$pid" ]]; then
        _dv_log "INFO" "ポート ${port} 上のプロセス ${pid} を停止"
        kill "$pid" 2>/dev/null || true
        sleep 1
        kill -9 "$pid" 2>/dev/null || true
    fi
}

# ============================================================
# Stop server (cleanup)
# ============================================================
_dv_stop_server() {
    if [[ -n "${_DV_SERVER_PID:-}" ]]; then
        _dv_log "INFO" "サーバー停止 PID=${_DV_SERVER_PID}"
        kill "$_DV_SERVER_PID" 2>/dev/null || true
        sleep 1
        kill -9 "$_DV_SERVER_PID" 2>/dev/null || true
        _DV_SERVER_PID=""
    fi

    if [[ -n "${_DV_PORT:-}" ]]; then
        _dv_kill_port "$_DV_PORT"
    fi
}

# ============================================================
# Generate verification report
# ============================================================
_dv_generate_report() {
    local project_dir="$1"
    local report_dir="${project_dir}/docs"
    local report_file="${report_dir}/verification-report.md"
    local ts
    ts="$(date '+%Y-%m-%d %H:%M:%S')"

    mkdir -p "$report_dir"

    local total=$(( _DV_PASS_COUNT + _DV_FAIL_COUNT + _DV_SKIP_COUNT ))
    local verdict="FAIL"
    if (( _DV_FAIL_COUNT == 0 )); then
        verdict="PASS"
    fi

    {
        echo "# Delivery Verification Report"
        echo ""
        echo "- **Generated**: ${ts}"
        echo "- **Module Version**: ${DV_VERSION}"
        echo "- **Project**: ${project_dir}"
        echo "- **Verdict**: **${verdict}**"
        echo ""
        echo "## Summary"
        echo ""
        echo "| Metric | Count |"
        echo "|--------|-------|"
        echo "| Pass   | ${_DV_PASS_COUNT} |"
        echo "| Fail   | ${_DV_FAIL_COUNT} |"
        echo "| Skip   | ${_DV_SKIP_COUNT} |"
        echo "| Total  | ${total} |"
        echo ""
        echo "## Details"
        echo ""
        for r in "${_DV_RESULTS[@]}"; do
            local icon="?"
            case "${r%%:*}" in
                PASS) icon="[PASS]" ;;
                FAIL) icon="[FAIL]" ;;
                SKIP) icon="[SKIP]" ;;
            esac
            echo "- ${icon} ${r#*: }"
        done
        echo ""
        echo "---"
        echo "*Report generated by SoloptiLinkAI Delivery Verification v${DV_VERSION}*"
    } > "$report_file"

    _dv_log "INFO" "レポート生成: ${report_file}"
    echo "$report_file"
}

# ============================================================
# MAIN: Full verification pipeline
# ============================================================
dv_run_full_verification() {
    local project_dir="${1:?dv_run_full_verification: project directory required}"

    # Resolve to absolute path
    project_dir="$(cd "$project_dir" 2>/dev/null && pwd)" || {
        echo -e "  ${DV_RED}ERROR: ディレクトリが存在しません: $1${DV_NC}" >&2
        return 1
    }

    _DV_PROJECT_DIR="$project_dir"

    # Initialize state
    dv_init

    # Setup log directory
    _DV_LOG_DIR="${project_dir}/.dv-logs"
    mkdir -p "$_DV_LOG_DIR"

    echo -e "\n  ${DV_BOLD}╔══════════════════════════════════════════════════╗${DV_NC}"
    echo -e "  ${DV_BOLD}║   Delivery Verification v${DV_VERSION}                  ║${DV_NC}"
    echo -e "  ${DV_BOLD}╚══════════════════════════════════════════════════╝${DV_NC}"
    echo -e "  ${DV_CYAN}Project: ${project_dir}${DV_NC}\n"

    # Trap to ensure cleanup on exit
    trap '_dv_stop_server' EXIT INT TERM

    local final_rc=0

    # --- Step 1: Detect project type ---
    local project_type
    project_type="$(_dv_detect_project_type "$project_dir")"
    _dv_log "INFO" "プロジェクト種別: ${project_type}"

    if [[ "$project_type" == "unknown" ]]; then
        _dv_record "プロジェクト検出" "FAIL" "package.json が見つかりません"
        final_rc=1
        _dv_generate_report "$project_dir" > /dev/null
        dv_report
        trap - EXIT INT TERM
        return $final_rc
    fi
    _dv_record "プロジェクト検出" "PASS" "種別: ${project_type}"

    # --- Step 2: Build ---
    if ! _dv_run_build "$project_dir" "$project_type"; then
        final_rc=1
        # Continue to generate report even on failure
    fi

    # --- Step 3: Check build output for JS errors ---
    if ! _dv_check_build_errors; then
        final_rc=1
    fi

    # --- Step 4: Start server ---
    local server_started=0
    if _dv_start_server "$project_dir" "$DV_DEFAULT_PORT"; then
        _dv_record "サーバー起動" "PASS" "PID=${_DV_SERVER_PID} port=${_DV_PORT}"
        server_started=1
    else
        final_rc=1
    fi

    # --- Step 5: Wait for readiness ---
    if (( server_started )); then
        if ! _dv_wait_for_ready; then
            final_rc=1
            server_started=0  # No point testing routes
        fi
    fi

    # --- Step 6: Health check ---
    if (( server_started )); then
        _dv_check_health || true  # /api/health is informational, not a hard gate
    else
        _dv_record "/api/health" "SKIP" "サーバー未起動"
    fi

    # --- Step 7: Route checks ---
    if (( server_started )); then
        if ! _dv_check_routes "${DV_DEFAULT_ROUTES[@]}"; then
            final_rc=1
        fi
    else
        for route in "${DV_DEFAULT_ROUTES[@]}"; do
            _dv_record "ルート ${route}" "SKIP" "サーバー未起動"
        done
    fi

    # --- Step 8: Stop server ---
    _dv_stop_server
    trap - EXIT INT TERM

    # --- Step 9: Generate report ---
    local report_path
    report_path="$(_dv_generate_report "$project_dir")"

    # --- Print summary ---
    dv_report
    echo -e "  ${DV_CYAN}レポート: ${report_path}${DV_NC}"

    if (( final_rc == 0 )); then
        echo -e "\n  ${DV_GREEN}${DV_BOLD}VERDICT: ALL CHECKS PASSED${DV_NC}\n"
    else
        echo -e "\n  ${DV_RED}${DV_BOLD}VERDICT: VERIFICATION FAILED (${_DV_FAIL_COUNT} failures)${DV_NC}\n"
    fi

    return $final_rc
}

# ============================================================
# Module Registry self-registration
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "delivery-verification" \
        --version "$DV_VERSION" \
        --description "納品検証（ビルド/起動/ルート/ヘルス/JSエラー検出）" \
        --init "dv_init" \
        --report "dv_report" \
        --enable-var "ENABLE_DELIVERY_VERIFICATION" \
        --cli-flags "--delivery-verify:--no-delivery-verify"
fi

# v2003.1: source時のexit codeを確実に0にする
true
