#!/usr/bin/env bash
# =============================================================================
# cognitive-rpc.sh - Python認知層への shell ブリッジ v1.0.0
# -----------------------------------------------------------------------------
# 役割:
#   SPE 等の shell から、ml/reasoning・ml/cognitive の認知モジュール(handle_rpc)を
#   python3 経由で叩く。numpy非依存(_npshim)化済みなので追加依存なしで動く。
#   PFP-068: claude -p は Desktop で不可だが python3 は動くため、認知層は
#   Desktop でも利用可能(SPE の二経路設計を補完)。
# 使い方:
#   source lib/cognitive-rpc.sh
#   cognitive_rpc task_planner planner.plan '{"goal":"CRM構築"}'
#   cognitive_rpc strategy_selector strategy.select '{"complexity":0.7,"domain":"crm"}'
# =============================================================================
[[ -n "${CRPC_LOADED:-}" ]] && return 0 2>/dev/null || true
CRPC_LOADED=1
CRPC_VERSION="1.0.0"
CRPC_HOME="${SOLOPTILINK_HOME:-$HOME/.soloptilink}"

# cognitive_rpc <module> <method> [params_json] -> 結果JSON(stdout)
# module: reasoning配下(task_planner/strategy_selector/decision_engine/causal_reasoner/
#         hypothesis_tester/learning_loop/knowledge_base) または cognitive_controller
cognitive_rpc() {
  # 注意: "${3:-{}}" は bash の brace 展開で余分な } を付け JSON を壊すため使わない
  local _crpc_params="${3:-}"
  [ -z "$_crpc_params" ] && _crpc_params='{}'
  CRPC_MOD="${1:-}" CRPC_METHOD="${2:-}" CRPC_PARAMS="$_crpc_params" \
  PYTHONPATH="$CRPC_HOME" python3 - <<'PY' 2>/dev/null
import os, json, importlib
mod = os.environ.get('CRPC_MOD', '')
method = os.environ.get('CRPC_METHOD', '')
try:
    params = json.loads(os.environ.get('CRPC_PARAMS') or '{}')
    if not isinstance(params, dict):
        params = {}
except Exception:
    params = {}
try:
    import pathlib
    # RPC経由は「算出」用途のため、認知層の永続化を一時領域へ逃がし、
    # 本番データ領域(plans/*.json / decisions.json 等)の無限増殖を防ぐ。
    _rpc_persist = pathlib.Path(os.environ.get('SOLOPTILINK_ML_RPC_PERSIST', '/tmp/soloptilink-ml-rpc'))
    cognitive_classes = {
        'cognitive_controller': 'CognitiveController',
        'metacognition': 'Metacognition',
        'working_memory': 'WorkingMemory',
        'long_term_memory': 'LongTermMemory',
    }
    if mod in cognitive_classes:
        m = importlib.import_module(f'ml.cognitive.{mod}')
        if hasattr(m, 'PERSIST_DIR'):
            m.PERSIST_DIR = _rpc_persist
        obj = getattr(m, cognitive_classes[mod])()
        if hasattr(obj, 'handle_rpc'):
            out = obj.handle_rpc(method, params)
        else:
            out = {"error": f"{mod} has no handle_rpc"}
    else:
        m = importlib.import_module(f'ml.reasoning.{mod}')
        if hasattr(m, 'PERSIST_DIR'):
            m.PERSIST_DIR = _rpc_persist
        out = m.handle_rpc(method, params)
    print(json.dumps(out, ensure_ascii=False, default=str))
except Exception as e:
    print(json.dumps({"error": f"{type(e).__name__}: {e}"}, ensure_ascii=False))
PY
}

# crpc_available -> 認知層が利用可能か(exit 0=可 / 非0=不可)
crpc_available() {
  PYTHONPATH="$CRPC_HOME" python3 -c "import ml.reasoning.task_planner, ml.cognitive.cognitive_controller" 2>/dev/null
}

# crpc_value <json> <key> -> JSONから単一キーを抽出(shell側の軽量ヘルパー)
crpc_value() {
  CRPC_JSON="${1:-}" CRPC_KEY="${2:-}" python3 - <<'PY' 2>/dev/null || true
import os, json
try:
    d = json.loads(os.environ.get('CRPC_JSON') or '{}')
    v = d.get(os.environ.get('CRPC_KEY', ''))
    print(v if v is not None else '')
except Exception:
    pass
PY
}

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  case "${1:-help}" in
    --available) crpc_available && echo "available" || { echo "unavailable"; exit 1; } ;;
    -h|--help|help) echo "usage: $0 <module> <method> [params_json]" ;;
    *) cognitive_rpc "$@" ;;
  esac
fi
