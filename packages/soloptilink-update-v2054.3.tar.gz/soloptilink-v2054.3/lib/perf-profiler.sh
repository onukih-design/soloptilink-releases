#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v70.0 - Performance Profiler
#
# 生成コードのパフォーマンスボトルネックを検出し自動最適化。
#
# 検出パターン:
# - N+1 クエリ問題
# - 不要な再レンダリング（React）
# - メモリリーク（イベントリスナー未解放）
# - 非効率なアルゴリズム（O(n²)ネストループ）
# - バンドルサイズ肥大（不要なインポート）
# - キャッシュ未使用
# - 同期的重い処理（メインスレッドブロック）
# ============================================================

[[ -n "${_PERF_PROFILER_LOADED:-}" ]] && return 0
_PERF_PROFILER_LOADED=1

# --- Configuration ---
PP2_ENABLE="${PP2_ENABLE:-true}"
PP2_AUTO_OPTIMIZE="${PP2_AUTO_OPTIMIZE:-true}"
PP2_BUNDLE_THRESHOLD="${PP2_BUNDLE_THRESHOLD:-500}"  # KB

# --- State ---
PP2_SCAN_COUNT=0
PP2_ISSUES_FOUND=0
PP2_OPTIMIZATIONS=0
PP2_N_PLUS_1=0
PP2_RERENDER=0
PP2_MEMORY_LEAK=0
PP2_BUNDLE_ISSUES=0

# ============================================================
# 初期化
# ============================================================
pp2_init() {
    PP2_SCAN_COUNT=0
    PP2_ISSUES_FOUND=0
    PP2_OPTIMIZATIONS=0
    PP2_N_PLUS_1=0
    PP2_RERENDER=0
    PP2_MEMORY_LEAK=0
    PP2_BUNDLE_ISSUES=0
    return 0
}

# ============================================================
# 静的パフォーマンス分析
# ソースコードのパターンマッチでボトルネックを検出
# ============================================================
pp2_static_analysis() {
    local file_path="$1"

    if [[ ! -f "$file_path" ]]; then
        return 1
    fi

    PP2_SCAN_COUNT=$((PP2_SCAN_COUNT + 1))

    local content
    content=$(cat "$file_path")
    local issues=""

    # --- N+1 クエリ検出 ---
    # forループ内でawait prisma/db呼出
    if echo "$content" | grep -qE 'for\s*\(' && echo "$content" | grep -qE '(prisma\.|\.findMany|\.findFirst|\.query)'; then
        local n1_count
        n1_count=$(echo "$content" | grep -cE 'await.*(prisma\.|db\.|\.find|\.query)' || true)
        if [[ $n1_count -gt 1 ]]; then
            issues+="N_PLUS_1|high|Possible N+1 query pattern: ${n1_count} DB calls potentially in loop|Use include/join or batch query\n"
            PP2_N_PLUS_1=$((PP2_N_PLUS_1 + 1))
            PP2_ISSUES_FOUND=$((PP2_ISSUES_FOUND + 1))
        fi
    fi

    # --- 不要な再レンダリング検出 ---
    # オブジェクトリテラルをpropsに直接渡し
    if echo "$content" | grep -qE '\<[A-Z][a-zA-Z]*\s+.*=\{\{'; then
        issues+="RERENDER|medium|Inline object/array in JSX props causes re-render|Extract to useMemo or const outside component\n"
        PP2_RERENDER=$((PP2_RERENDER + 1))
        PP2_ISSUES_FOUND=$((PP2_ISSUES_FOUND + 1))
    fi

    # useStateで大きなオブジェクトをspread更新
    if echo "$content" | grep -qE 'set[A-Z].*\(\{.*\.\.\.'; then
        if echo "$content" | grep -cE 'set[A-Z]' | grep -qE '[3-9]|[1-9][0-9]'; then
            issues+="RERENDER|low|Multiple state updates may cause extra renders|Consider useReducer or batch updates\n"
            PP2_RERENDER=$((PP2_RERENDER + 1))
            PP2_ISSUES_FOUND=$((PP2_ISSUES_FOUND + 1))
        fi
    fi

    # --- メモリリーク検出 ---
    # addEventListener without removeEventListener
    if echo "$content" | grep -q 'addEventListener' && ! echo "$content" | grep -q 'removeEventListener'; then
        issues+="MEMORY_LEAK|high|addEventListener without matching removeEventListener|Add cleanup in useEffect return or componentWillUnmount\n"
        PP2_MEMORY_LEAK=$((PP2_MEMORY_LEAK + 1))
        PP2_ISSUES_FOUND=$((PP2_ISSUES_FOUND + 1))
    fi

    # setInterval without clearInterval
    if echo "$content" | grep -q 'setInterval' && ! echo "$content" | grep -q 'clearInterval'; then
        issues+="MEMORY_LEAK|high|setInterval without clearInterval|Store interval ID and clear on cleanup\n"
        PP2_MEMORY_LEAK=$((PP2_MEMORY_LEAK + 1))
        PP2_ISSUES_FOUND=$((PP2_ISSUES_FOUND + 1))
    fi

    # --- 非効率アルゴリズム検出 ---
    # ネストされたforループ（O(n²)）
    local nested_loops
    nested_loops=$(echo "$content" | grep -cE '(for|forEach|\.map)\s*\(' || true)
    if [[ $nested_loops -gt 3 ]]; then
        issues+="ALGORITHM|medium|${nested_loops} loop constructs detected - check for nested iterations|Consider Map/Set for O(1) lookups\n"
        PP2_ISSUES_FOUND=$((PP2_ISSUES_FOUND + 1))
    fi

    # --- 同期重い処理 ---
    if echo "$content" | grep -qE '(fs\.readFileSync|fs\.writeFileSync|execSync)'; then
        issues+="SYNC_BLOCKING|high|Synchronous I/O blocking main thread|Use async versions: readFile, writeFile, exec\n"
        PP2_ISSUES_FOUND=$((PP2_ISSUES_FOUND + 1))
    fi

    # --- 不要なインポート ---
    if echo "$content" | grep -qE "import.*from\s+['\"]lodash['\"]"; then
        issues+="BUNDLE|medium|Full lodash import increases bundle size|Use lodash/specific-function or lodash-es\n"
        PP2_BUNDLE_ISSUES=$((PP2_BUNDLE_ISSUES + 1))
        PP2_ISSUES_FOUND=$((PP2_ISSUES_FOUND + 1))
    fi
    if echo "$content" | grep -qE "import.*from\s+['\"]moment['\"]"; then
        issues+="BUNDLE|medium|moment.js is deprecated and large (330KB)|Use date-fns or dayjs instead\n"
        PP2_BUNDLE_ISSUES=$((PP2_BUNDLE_ISSUES + 1))
        PP2_ISSUES_FOUND=$((PP2_ISSUES_FOUND + 1))
    fi

    echo -e "$issues"
}

# ============================================================
# パフォーマンス最適化プロンプト生成
# ============================================================
pp2_build_optimize_prompt() {
    local file_path="$1"
    local issues="$2"
    local code="$3"

    cat << PROMPT
# Performance Optimization Request

## File: ${file_path}

## Issues Found:
$(echo -e "$issues" | while IFS='|' read -r type sev desc fix; do
    [[ -z "$type" ]] && continue
    echo "- [${sev}] ${type}: ${desc}"
    echo "  Fix: ${fix}"
done)

## Code:
\`\`\`
${code}
\`\`\`

## Instructions
1. Fix ALL performance issues listed above
2. Maintain functional correctness
3. Add comments explaining WHY each optimization was made
4. Output the COMPLETE optimized file
PROMPT
}

# ============================================================
# ファイルのプロファイル＋最適化
# ============================================================
pp2_profile_and_optimize() {
    local file_path="$1"

    if [[ ! -f "$file_path" ]]; then
        return 1
    fi

    local issues
    issues=$(pp2_static_analysis "$file_path")

    if [[ -z "$issues" ]]; then
        echo -e "  ${GREEN:-}✅ ${file_path}: パフォーマンス問題なし${NC:-}" >&2
        return 0
    fi

    local issue_count
    issue_count=$(echo -e "$issues" | grep -c '|' || true)
    echo -e "  ${YELLOW:-}⚠️ ${file_path}: ${issue_count}件のパフォーマンス問題${NC:-}" >&2

    if [[ "${PP2_AUTO_OPTIMIZE}" == "true" ]]; then
        local code
        code=$(cat "$file_path")
        local prompt
        prompt=$(pp2_build_optimize_prompt "$file_path" "$issues" "$code")

        # Tool-Aware連携
        if type -t tag_read_and_fix &>/dev/null && [[ "${TAG_ENABLE_TOOLS:-false}" == "true" ]]; then
            tag_read_and_fix "$file_path" "$prompt" "$(dirname "$file_path")"
            PP2_OPTIMIZATIONS=$((PP2_OPTIMIZATIONS + 1))
        fi
    fi

    echo -e "$issues"
}

# ============================================================
# ディレクトリ全体のプロファイル
# ============================================================
pp2_profile_directory() {
    local dir="$1"

    echo -e "${BOLD:-}[Perf Profiler] ${dir} をプロファイリング中...${NC:-}" >&2

    while IFS= read -r -d '' file; do
        pp2_profile_and_optimize "$file"
    done < <(find "$dir" \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
        -not -path "*/node_modules/*" -not -path "*/.next/*" -not -path "*/__tests__/*" \
        -print0 2>/dev/null)

    echo -e "${GREEN:-}[Perf Profiler] 完了: ${PP2_SCAN_COUNT}ファイル, ${PP2_ISSUES_FOUND}問題, ${PP2_OPTIMIZATIONS}最適化${NC:-}" >&2
}

# ============================================================
# レポート / スコア
# ============================================================
pp2_report() {
    echo -e "\n  ${BOLD:-}═══ Performance Profiler v70.0 レポート ═══${NC:-}"
    echo -e "  スキャンファイル数 : ${PP2_SCAN_COUNT}"
    echo -e "  問題検出数         : ${PP2_ISSUES_FOUND}"
    echo -e "  N+1クエリ          : ${PP2_N_PLUS_1}"
    echo -e "  再レンダリング     : ${PP2_RERENDER}"
    echo -e "  メモリリーク       : ${PP2_MEMORY_LEAK}"
    echo -e "  バンドルサイズ     : ${PP2_BUNDLE_ISSUES}"
    echo -e "  最適化適用数       : ${PP2_OPTIMIZATIONS}"
}

pp2_score() {
    if [[ $PP2_SCAN_COUNT -eq 0 ]]; then
        echo "50"
    elif [[ $PP2_ISSUES_FOUND -eq 0 ]]; then
        echo "100"
    elif [[ $PP2_N_PLUS_1 -eq 0 && $PP2_MEMORY_LEAK -eq 0 ]]; then
        echo "80"
    else
        echo "$(( 100 - PP2_ISSUES_FOUND * 5 ))"
    fi
}

# ============================================================
# v59.0: Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "perf-profiler" \
        --version "70.0" \
        --description "N+1/メモリリーク/再レンダリング検出×自動最適化" \
        --init "pp2_init" \
        --report "pp2_report" \
        --score "pp2_score" \
        --enable-var "ENABLE_PERF_PROFILER" \
        --cli-flags "--perf-profile:--no-perf-profile"
fi

# v2003.1: source時のexit codeを確実に0にする
true
