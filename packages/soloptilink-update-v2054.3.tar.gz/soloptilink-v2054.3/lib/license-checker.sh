#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v361.0 - License Checker
# =============================================================================
# ライセンススキャン×互換性チェック×レポート生成
#
# 機能:
#   - 依存関係のライセンス一覧取得
#   - ライセンス互換性検証（GPL/MIT/Apache/BSD等）
#   - 禁止ライセンス検出
#   - SBOM（Software Bill of Materials）生成
#   - ライセンスコンプライアンスレポート
#
# 全globals: LC_ prefix
# =============================================================================

[[ -n "${_LC_LOADED:-}" ]] && return 0; _LC_LOADED=1

LC_VERSION="361.0"
LC_GENERATED=0
LC_ERRORS=0
LC_PHASE="license_check"
LC_FILES_CREATED=()
LC_VIOLATIONS=0

: "${GREEN:=\033[0;32m}" ; : "${RED:=\033[0;31m}" ; : "${YELLOW:=\033[0;33m}"
: "${CYAN:=\033[0;36m}" ; : "${BOLD:=\033[1m}" ; : "${NC:=\033[0m}"

_lc_log() { echo -e "  ${CYAN}[LC]${NC} $*"; }
_lc_ok() { echo -e "  ${GREEN}[LC]${NC} $*"; }
_lc_err() { echo -e "  ${RED}[LC]${NC} $*"; }

_lc_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        LC_FILES_CREATED+=("$filepath")
        LC_GENERATED=$((LC_GENERATED + 1))
        _lc_ok "Created: ${filepath##*/}"
    else
        LC_ERRORS=$((LC_ERRORS + 1))
        _lc_err "Failed: ${filepath##*/}"
    fi
}

lc_init() {
    LC_GENERATED=0; LC_ERRORS=0; LC_VIOLATIONS=0; LC_FILES_CREATED=()
    _lc_log "License Checker v${LC_VERSION} initialized"
    return 0
}

# =============================================================================
# Scan Licenses
# =============================================================================
_lc_scan_licenses() {
    local project_dir="${1:-.}"

    _lc_log "Generating license scanner..."

    local lic_dir="${project_dir}/src/lib/license"
    mkdir -p "$lic_dir" 2>/dev/null

    _lc_write_file "${lic_dir}/scanner.ts" "$(cat <<'TS'
import { execSync } from 'child_process';
import { readFileSync, existsSync } from 'fs';
import { join } from 'path';

interface PackageLicense {
  name: string;
  version: string;
  license: string;
  repository?: string;
  category: 'permissive' | 'copyleft' | 'weak_copyleft' | 'proprietary' | 'unknown';
}

const LICENSE_CATEGORIES: Record<string, PackageLicense['category']> = {
  'MIT': 'permissive',
  'ISC': 'permissive',
  'BSD-2-Clause': 'permissive',
  'BSD-3-Clause': 'permissive',
  'Apache-2.0': 'permissive',
  'CC0-1.0': 'permissive',
  'Unlicense': 'permissive',
  '0BSD': 'permissive',
  'GPL-2.0': 'copyleft',
  'GPL-3.0': 'copyleft',
  'AGPL-3.0': 'copyleft',
  'LGPL-2.1': 'weak_copyleft',
  'LGPL-3.0': 'weak_copyleft',
  'MPL-2.0': 'weak_copyleft',
  'EPL-1.0': 'weak_copyleft',
};

function categorize(license: string): PackageLicense['category'] {
  if (!license || license === 'UNKNOWN') return 'unknown';
  return LICENSE_CATEGORIES[license] ?? 'unknown';
}

export async function scanLicenses(cwd: string): Promise<PackageLicense[]> {
  const packages: PackageLicense[] = [];
  const nodeModules = join(cwd, 'node_modules');

  try {
    const output = execSync('npm ls --all --json', { cwd, encoding: 'utf-8', stdio: 'pipe' });
    const tree = JSON.parse(output);

    function walk(deps: Record<string, any>) {
      for (const [name, info] of Object.entries(deps)) {
        const pkgJsonPath = join(nodeModules, name, 'package.json');
        let license = 'UNKNOWN';
        let repository: string | undefined;

        if (existsSync(pkgJsonPath)) {
          try {
            const pkg = JSON.parse(readFileSync(pkgJsonPath, 'utf-8'));
            license = typeof pkg.license === 'string' ? pkg.license : typeof pkg.license === 'object' ? pkg.license.type : 'UNKNOWN';
            repository = typeof pkg.repository === 'string' ? pkg.repository : pkg.repository?.url;
          } catch {}
        }

        packages.push({ name, version: (info as any).version || '0.0.0', license, repository, category: categorize(license) });

        if ((info as any).dependencies) walk((info as any).dependencies);
      }
    }

    if (tree.dependencies) walk(tree.dependencies);
  } catch {}

  return packages;
}
TS
)"

    _lc_ok "License scanner generated"
}

# =============================================================================
# Check Compatibility
# =============================================================================
_lc_check_compatibility() {
    local project_dir="${1:-.}"

    _lc_log "Generating license compatibility checker..."

    local lic_dir="${project_dir}/src/lib/license"
    mkdir -p "$lic_dir" 2>/dev/null

    _lc_write_file "${lic_dir}/compatibility.ts" "$(cat <<'TS'
import type { PackageLicense } from './scanner';

interface LicensePolicy {
  projectLicense: string;
  allowed: string[];
  denied: string[];
  reviewRequired: string[];
}

interface CompatibilityResult {
  compatible: boolean;
  violations: { package: string; license: string; reason: string }[];
  warnings: { package: string; license: string; reason: string }[];
  reviewed: number;
}

const DEFAULT_POLICY: LicensePolicy = {
  projectLicense: 'MIT',
  allowed: ['MIT', 'ISC', 'BSD-2-Clause', 'BSD-3-Clause', 'Apache-2.0', 'CC0-1.0', 'Unlicense', '0BSD', 'BlueOak-1.0.0'],
  denied: ['GPL-2.0', 'GPL-3.0', 'AGPL-3.0', 'SSPL-1.0', 'EUPL-1.1'],
  reviewRequired: ['LGPL-2.1', 'LGPL-3.0', 'MPL-2.0', 'EPL-1.0', 'CC-BY-4.0', 'CC-BY-SA-4.0'],
};

export function checkCompatibility(packages: any[], policy: LicensePolicy = DEFAULT_POLICY): CompatibilityResult {
  const violations: CompatibilityResult['violations'] = [];
  const warnings: CompatibilityResult['warnings'] = [];

  for (const pkg of packages) {
    if (policy.denied.includes(pkg.license)) {
      violations.push({ package: `${pkg.name}@${pkg.version}`, license: pkg.license, reason: `License ${pkg.license} is in the deny list` });
    } else if (policy.reviewRequired.includes(pkg.license)) {
      warnings.push({ package: `${pkg.name}@${pkg.version}`, license: pkg.license, reason: `License ${pkg.license} requires legal review` });
    } else if (pkg.license === 'UNKNOWN') {
      warnings.push({ package: `${pkg.name}@${pkg.version}`, license: 'UNKNOWN', reason: 'License could not be determined' });
    }
  }

  return { compatible: violations.length === 0, violations, warnings, reviewed: packages.length };
}
TS
)"

    _lc_ok "License compatibility checker generated"
}

# =============================================================================
# Generate Report
# =============================================================================
_lc_generate_report() {
    local project_dir="${1:-.}"

    _lc_log "Generating license report & CI workflow..."

    local ci_dir="${project_dir}/.github/workflows"
    mkdir -p "$ci_dir" 2>/dev/null

    _lc_write_file "${ci_dir}/license-check.yml" "$(cat <<'YAML'
name: License Check
on:
  pull_request:
    paths:
      - 'package.json'
      - 'package-lock.json'

jobs:
  license-check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'
      - run: npm ci
      - name: Check licenses
        run: npx license-checker --production --failOn "GPL-2.0;GPL-3.0;AGPL-3.0" --summary
      - name: Generate SBOM
        run: npx @cyclonedx/cyclonedx-npm --output-file sbom.json
      - uses: actions/upload-artifact@v4
        with:
          name: sbom
          path: sbom.json
YAML
)"

    _lc_ok "License report & CI generated"
}

# =============================================================================
# Report / Score / Register
# =============================================================================
lc_report() {
    echo -e "\n  ${BOLD}=== License Checker v${LC_VERSION} ===${NC}"
    echo -e "  生成ファイル数 : ${LC_GENERATED}"
    echo -e "  エラー         : ${LC_ERRORS}"
    echo -e "  違反検出数     : ${LC_VIOLATIONS}"
    if [[ ${#LC_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${LC_FILES_CREATED[@]}"; do echo -e "    - ${f}"; done
    fi
}

lc_score() {
    if [[ ${LC_GENERATED} -ge 3 ]] && [[ ${LC_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${LC_GENERATED} -gt 0 ]] && [[ ${LC_ERRORS} -eq 0 ]]; then echo "90"
    elif [[ ${LC_GENERATED} -gt 0 ]]; then echo "70"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "license-checker" --version "361.0" \
        --description "ライセンススキャン×互換性チェック×SBOM生成" \
        --init "lc_init" --report "lc_report" --score "lc_score" \
        --enable-var "ENABLE_LICENSE_CHECKER" --cli-flags "--license-checker:--no-license-checker"
fi

# v2003.1: source時のexit codeを確実に0にする
true
