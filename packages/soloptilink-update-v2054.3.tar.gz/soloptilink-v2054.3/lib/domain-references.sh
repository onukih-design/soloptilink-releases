#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v101.0 - Domain Reference Implementation Engine
# ドメイン別の実コード参照実装を注入
#
# 問題: enterprise-patterns.shは全ドメインで同じテンプレートを使用。
# CRMもSaaSもブログも同じ「model.create()」テンプレートが注入される。
#
# 解決: ドメイン別に最適化された参照実装を注入。
# CRMなら顧客検索+パイプライン、SaaSならテナント分離+課金、
# ECなら在庫管理+カートのコードが注入される。
#
# v101.0: Domain-Specific Code Intelligence
# ============================================================

[[ -n "${_DOMAIN_REFERENCES_LOADED:-}" ]] && return 0
_DOMAIN_REFERENCES_LOADED=1

# --- グローバル状態 ---
DR_VERSION="101.0"
DR_INITIALIZED=false

# ============================================================
# 初期化
# ============================================================
dr_init() {
    DR_INITIALIZED=true
    return 0
}

# ============================================================
# ドメイン別参照実装を取得
# enterprise-patterns.sh の ep_inject_for_phase と同じインターフェース
# ============================================================
dr_get_reference() {
    local domain="${1:-general}"
    local phase="${2:-implementation}"

    case "$domain" in
        crm|CRM)           _dr_crm_reference "$phase" ;;
        saas|SaaS)          _dr_saas_reference "$phase" ;;
        ecommerce|ec|EC)    _dr_ec_reference "$phase" ;;
        task_management)    _dr_task_reference "$phase" ;;
        *)                  echo "" ;;
    esac
}

# ============================================================
# プロンプトに注入（ai_call pre-hookから呼ばれる）
# ============================================================
dr_inject_for_prompt() {
    local prompt="$1"
    local domain="${2:-general}"
    local phase="${3:-implementation}"

    local reference
    reference=$(dr_get_reference "$domain" "$phase")

    if [[ -n "$reference" ]]; then
        echo "${prompt}

[ドメイン固有の参照実装 - ${domain}]
以下のパターンに従って実装してください:
${reference}"
    else
        echo "$prompt"
    fi
}

# ============================================================
# CRM ドメイン参照実装
# ============================================================
_dr_crm_reference() {
    local phase="$1"
    cat << 'CRM_REF'
### CRM APIルート例 (app/api/companies/route.ts)
```typescript
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';

const companySchema = z.object({
  name: z.string().min(1, '会社名は必須です'),
  industry: z.string().optional(),
  website: z.string().url().optional().or(z.literal('')),
  phone: z.string().optional(),
  address: z.string().optional(),
  status: z.enum(['lead', 'prospect', 'customer', 'churned']).default('lead'),
  assignedToId: z.string().optional(),
});

export async function GET(request: NextRequest) {
  const { searchParams } = new URL(request.url);
  const page = parseInt(searchParams.get('page') || '1');
  const limit = parseInt(searchParams.get('limit') || '20');
  const search = searchParams.get('search') || '';
  const status = searchParams.get('status') || '';

  const where = {
    ...(search && {
      OR: [
        { name: { contains: search, mode: 'insensitive' as const } },
        { industry: { contains: search, mode: 'insensitive' as const } },
      ],
    }),
    ...(status && { status }),
  };

  const [companies, total] = await prisma.$transaction([
    prisma.company.findMany({
      where,
      include: { assignedTo: { select: { id: true, name: true } }, _count: { select: { contacts: true, deals: true } } },
      skip: (page - 1) * limit,
      take: limit,
      orderBy: { updatedAt: 'desc' },
    }),
    prisma.company.count({ where }),
  ]);

  return NextResponse.json({ data: companies, total, page, limit, totalPages: Math.ceil(total / limit) });
}

export async function POST(request: NextRequest) {
  const body = await request.json();
  const validated = companySchema.parse(body);

  const company = await prisma.$transaction(async (tx) => {
    const created = await tx.company.create({ data: validated });
    await tx.activityLog.create({
      data: { type: 'COMPANY_CREATED', entityType: 'company', entityId: created.id, description: `会社「${created.name}」を作成` },
    });
    return created;
  });

  return NextResponse.json(company, { status: 201 });
}
```

### CRM Prismaスキーマ例
```prisma
model Company {
  id          String    @id @default(cuid())
  name        String
  industry    String?
  website     String?
  phone       String?
  address     String?
  status      String    @default("lead") // lead, prospect, customer, churned
  assignedToId String?
  assignedTo  User?     @relation(fields: [assignedToId], references: [id])
  contacts    Contact[]
  deals       Deal[]
  activities  ActivityLog[]
  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt
}

model Deal {
  id          String    @id @default(cuid())
  title       String
  amount      Float
  stage       String    @default("qualification") // qualification, proposal, negotiation, closed_won, closed_lost
  companyId   String
  company     Company   @relation(fields: [companyId], references: [id])
  assignedToId String?
  closedAt    DateTime?
  createdAt   DateTime  @default(now())
  updatedAt   DateTime  @updatedAt
}
```
CRM_REF
}

# ============================================================
# SaaS ドメイン参照実装
# ============================================================
_dr_saas_reference() {
    local phase="$1"
    cat << 'SAAS_REF'
### SaaS マルチテナントミドルウェア例
```typescript
import { NextRequest, NextResponse } from 'next/server';
import { getToken } from 'next-auth/jwt';
import { prisma } from '@/lib/prisma';

export async function withTenant(request: NextRequest, handler: (req: NextRequest, tenantId: string) => Promise<NextResponse>) {
  const token = await getToken({ req: request });
  if (!token?.tenantId) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  // テナントの利用制限チェック
  const tenant = await prisma.tenant.findUnique({
    where: { id: token.tenantId },
    include: { plan: true },
  });

  if (!tenant || tenant.status !== 'active') {
    return NextResponse.json({ error: 'Tenant suspended' }, { status: 403 });
  }

  return handler(request, token.tenantId);
}
```

### SaaS Prismaスキーマ例（テナント分離）
```prisma
model Tenant {
  id        String   @id @default(cuid())
  name      String
  slug      String   @unique
  planId    String
  plan      Plan     @relation(fields: [planId], references: [id])
  status    String   @default("active") // active, suspended, cancelled
  users     User[]
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}

model Plan {
  id            String   @id @default(cuid())
  name          String   // Free, Pro, Enterprise
  price         Float
  maxUsers      Int
  maxStorage    Int      // MB
  features      Json     // {"api_access": true, "export": true}
  stripePriceId String?
  tenants       Tenant[]
}

model User {
  id        String   @id @default(cuid())
  email     String   @unique
  name      String?
  role      String   @default("member") // owner, admin, member
  tenantId  String
  tenant    Tenant   @relation(fields: [tenantId], references: [id])
  createdAt DateTime @default(now())
}
```

### SaaS 課金API例
```typescript
import Stripe from 'stripe';
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!);

export async function POST(request: NextRequest) {
  const { planId, tenantId } = await request.json();
  const plan = await prisma.plan.findUnique({ where: { id: planId } });
  if (!plan?.stripePriceId) return NextResponse.json({ error: 'Invalid plan' }, { status: 400 });

  const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    line_items: [{ price: plan.stripePriceId, quantity: 1 }],
    success_url: `${process.env.NEXT_PUBLIC_URL}/settings/billing?success=true`,
    cancel_url: `${process.env.NEXT_PUBLIC_URL}/settings/billing?cancelled=true`,
    metadata: { tenantId, planId },
  });

  return NextResponse.json({ url: session.url });
}
```
SAAS_REF
}

# ============================================================
# EC ドメイン参照実装
# ============================================================
_dr_ec_reference() {
    local phase="$1"
    cat << 'EC_REF'
### EC カート・注文API例
```typescript
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';

const addToCartSchema = z.object({
  productId: z.string(),
  quantity: z.number().int().min(1).max(99),
});

// カートに追加（在庫チェック付き）
export async function POST(request: NextRequest) {
  const body = await request.json();
  const { productId, quantity } = addToCartSchema.parse(body);
  const userId = request.headers.get('x-user-id');
  if (!userId) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

  const result = await prisma.$transaction(async (tx) => {
    // 在庫チェック
    const product = await tx.product.findUnique({ where: { id: productId } });
    if (!product || product.stock < quantity) {
      throw new Error('在庫不足');
    }

    // カートアイテム追加/更新
    const cartItem = await tx.cartItem.upsert({
      where: { userId_productId: { userId, productId } },
      create: { userId, productId, quantity },
      update: { quantity: { increment: quantity } },
    });

    return cartItem;
  });

  return NextResponse.json(result);
}
```

### EC Prismaスキーマ例
```prisma
model Product {
  id          String      @id @default(cuid())
  name        String
  description String?
  price       Float
  stock       Int         @default(0)
  images      Json        @default("[]") // ["url1", "url2"]
  categoryId  String?
  category    Category?   @relation(fields: [categoryId], references: [id])
  cartItems   CartItem[]
  orderItems  OrderItem[]
  reviews     Review[]
  isPublished Boolean     @default(true)
  createdAt   DateTime    @default(now())
  updatedAt   DateTime    @updatedAt
}

model Order {
  id            String      @id @default(cuid())
  userId        String
  user          User        @relation(fields: [userId], references: [id])
  items         OrderItem[]
  subtotal      Float
  tax           Float
  total         Float
  status        String      @default("pending") // pending, paid, shipped, delivered, cancelled
  shippingAddress Json
  paymentIntentId String?
  createdAt     DateTime    @default(now())
  updatedAt     DateTime    @updatedAt
}

model CartItem {
  id        String   @id @default(cuid())
  userId    String
  productId String
  quantity  Int
  user      User     @relation(fields: [userId], references: [id])
  product   Product  @relation(fields: [productId], references: [id])
  @@unique([userId, productId])
}
```
EC_REF
}

# ============================================================
# タスク管理ドメイン参照実装
# ============================================================
_dr_task_reference() {
    local phase="$1"
    cat << 'TASK_REF'
### タスク管理API例（ステータス更新+担当者割当）
```typescript
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/prisma';

const updateTaskSchema = z.object({
  title: z.string().min(1).optional(),
  description: z.string().optional(),
  status: z.enum(['todo', 'in_progress', 'review', 'done']).optional(),
  priority: z.enum(['low', 'medium', 'high', 'urgent']).optional(),
  assigneeId: z.string().nullable().optional(),
  dueDate: z.string().datetime().nullable().optional(),
  position: z.number().optional(), // カンバン内の位置
});

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  const body = await request.json();
  const validated = updateTaskSchema.parse(body);
  const userId = request.headers.get('x-user-id')!;

  const task = await prisma.$transaction(async (tx) => {
    const updated = await tx.task.update({
      where: { id: params.id },
      data: { ...validated, updatedAt: new Date() },
      include: { assignee: { select: { id: true, name: true, avatar: true } }, project: true },
    });

    // ステータス変更時は活動ログ記録
    if (validated.status) {
      await tx.activity.create({
        data: { type: 'STATUS_CHANGED', taskId: params.id, userId, metadata: { newStatus: validated.status } },
      });
    }

    return updated;
  });

  return NextResponse.json(task);
}
```

### タスク管理Prismaスキーマ例
```prisma
model Task {
  id          String     @id @default(cuid())
  title       String
  description String?
  status      String     @default("todo")
  priority    String     @default("medium")
  position    Float      @default(0) // カンバン内の順序
  dueDate     DateTime?
  projectId   String
  project     Project    @relation(fields: [projectId], references: [id])
  assigneeId  String?
  assignee    User?      @relation(fields: [assigneeId], references: [id])
  comments    Comment[]
  activities  Activity[]
  createdAt   DateTime   @default(now())
  updatedAt   DateTime   @updatedAt
}
```
TASK_REF
}

# ============================================================
# レポート
# ============================================================
dr_report() {
    echo "=== Domain References v${DR_VERSION} ==="
    echo "  Domains: crm, saas, ecommerce, task_management"
}

dr_score() {
    echo "80"
}

# ============================================================
# Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "domain-references" \
        --version "$DR_VERSION" \
        --description "ドメイン別参照実装 - CRM/SaaS/EC/タスク管理の実コードテンプレート" \
        --init "dr_init" \
        --report "dr_report" \
        --score "dr_score" \
        --enable-var "ENABLE_DOMAIN_REFERENCES" \
        --cli-flags "--domain-references:--no-domain-references"
fi

# v2003.1: source時のexit codeを確実に0にする
true
