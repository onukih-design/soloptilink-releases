#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v422.0 - Incremental Generation Engine
# =============================================================================
# 変更差分のみを再生成するインクリメンタルビルドエンジン。
# ファイルのハッシュ比較・依存ツリー走査により、変更影響のあるファイルのみ
# を再生成してビルド時間を削減する。
#
# Functions:
#   _ig_init()                - 初期化
#   _ig_detect_changes()      - 変更ファイルを検出
#   _ig_regenerate_affected() - 影響ファイルのみ再生成
#   _ig_cache_results()       - 生成結果をキャッシュ
#   _ig_report() / _ig_score()
#
# All globals use the IG_ prefix.
# =============================================================================

[[ -n "${_IG_LOADED:-}" ]] && return 0; _IG_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g IG_VERSION="422.0"
declare -g IG_GENERATED=0
declare -g IG_ERRORS=0
declare -g IG_FILES_WRITTEN=0
declare -g IG_CHANGES_DETECTED=0
declare -g IG_CACHE_HITS=0
declare -g IG_CACHE_MISSES=0
declare -g IG_AFFECTED_COUNT=0
declare -g IG_SKIPPED_COUNT=0
declare -g IG_CACHE_DIR="${IG_CACHE_DIR:-.soloptilink/cache/incremental}"

declare -gA _IG_HASH_CACHE=()
declare -gA _IG_DEP_TREE=()

_IG_GREEN="${GREEN:-\033[0;32m}"
_IG_RED="${RED:-\033[0;31m}"
_IG_YELLOW="${YELLOW:-\033[0;33m}"
_IG_CYAN="${CYAN:-\033[0;36m}"
_IG_BOLD="${BOLD:-\033[1m}"
_IG_NC="${NC:-\033[0m}"

# =============================================================================
# Init
# =============================================================================
_ig_init() {
    IG_GENERATED=0
    IG_ERRORS=0
    IG_FILES_WRITTEN=0
    IG_CHANGES_DETECTED=0
    IG_CACHE_HITS=0
    IG_CACHE_MISSES=0
    IG_AFFECTED_COUNT=0
    IG_SKIPPED_COUNT=0
    _IG_HASH_CACHE=()
    _IG_DEP_TREE=()
    mkdir -p "$IG_CACHE_DIR" 2>/dev/null
    return 0
}

_ig_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_IG_CYAN}[IG]${_IG_NC} $*" >&2 ;;
        ok)    echo -e "  ${_IG_GREEN}[IG]${_IG_NC} $*" >&2 ;;
        warn)  echo -e "  ${_IG_YELLOW}[IG]${_IG_NC} $*" >&2 ;;
        error) echo -e "  ${_IG_RED}[IG]${_IG_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _ig_detect_changes - 変更ファイルを検出
# =============================================================================
_ig_detect_changes() {
    local project_dir="${1:-.}"
    local hash_file="${IG_CACHE_DIR}/file_hashes.txt"

    _ig_log info "変更検出開始: ${project_dir}"

    local -A old_hashes=()
    if [[ -f "$hash_file" ]]; then
        while IFS='=' read -r path hash; do
            [[ -n "$path" ]] && old_hashes["$path"]="$hash"
        done < "$hash_file"
    fi

    local changed_files=()
    local new_hashes=""
    local total=0

    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"
        local current_hash
        current_hash=$(sha256sum "$file" 2>/dev/null | cut -d' ' -f1)
        [[ -z "$current_hash" ]] && current_hash=$(md5 -q "$file" 2>/dev/null || echo "unknown")

        new_hashes="${new_hashes}${rel}=${current_hash}\n"
        _IG_HASH_CACHE["$rel"]="$current_hash"
        total=$((total + 1))

        local old="${old_hashes[$rel]:-}"
        if [[ -z "$old" ]] || [[ "$old" != "$current_hash" ]]; then
            changed_files+=("$rel")
            IG_CHANGES_DETECTED=$((IG_CHANGES_DETECTED + 1))
        else
            IG_CACHE_HITS=$((IG_CACHE_HITS + 1))
        fi
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" -o -name "*.css" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" -not -path "*/dist/*" -print0 2>/dev/null)

    # 新しいハッシュを保存
    printf '%b' "$new_hashes" > "$hash_file" 2>/dev/null

    IG_CACHE_MISSES=$IG_CHANGES_DETECTED
    IG_SKIPPED_COUNT=$((total - IG_CHANGES_DETECTED))
    IG_GENERATED=$((IG_GENERATED + 1))

    _ig_log ok "変更検出完了: ${IG_CHANGES_DETECTED}/${total}ファイル変更"

    # 変更ファイルを返す
    printf '%s\n' "${changed_files[@]}"
    return 0
}

# =============================================================================
# _ig_regenerate_affected - 影響ファイルのみ再生成
# =============================================================================
_ig_regenerate_affected() {
    local project_dir="${1:-.}"
    shift
    local -a changed_files=("$@")

    _ig_log info "影響ファイル特定: ${#changed_files[@]}個の変更から波及解析"

    local -A affected=()
    for cf in "${changed_files[@]}"; do
        affected["$cf"]=1
    done

    # 依存ツリーを逆引き: 変更ファイルをimportしているファイルも再生成対象
    for file in "${!_IG_DEP_TREE[@]}"; do
        local deps="${_IG_DEP_TREE[$file]}"
        for cf in "${changed_files[@]}"; do
            if [[ "$deps" == *"$cf"* ]]; then
                affected["$file"]=1
            fi
        done
    done

    IG_AFFECTED_COUNT=${#affected[@]}
    _ig_log info "再生成対象: ${IG_AFFECTED_COUNT}ファイル"

    # 対象ファイルパスを返す
    for file in "${!affected[@]}"; do
        echo "$file"
    done

    IG_GENERATED=$((IG_GENERATED + 1))
    return 0
}

# =============================================================================
# _ig_cache_results - 生成結果をキャッシュ
# =============================================================================
_ig_cache_results() {
    local project_dir="${1:-.}"
    local cache_manifest="${IG_CACHE_DIR}/manifest.json"

    _ig_log info "キャッシュ保存中"

    local entries=""
    local count=0
    for file in "${!_IG_HASH_CACHE[@]}"; do
        local hash="${_IG_HASH_CACHE[$file]}"
        [[ $count -gt 0 ]] && entries="${entries},"
        entries="${entries}\"${file}\":\"${hash}\""
        count=$((count + 1))
    done

    cat > "$cache_manifest" <<EOF
{
  "version": "${IG_VERSION}",
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || echo "unknown")",
  "total_files": ${count},
  "changes_detected": ${IG_CHANGES_DETECTED},
  "cache_hits": ${IG_CACHE_HITS},
  "hashes": {${entries}}
}
EOF

    IG_FILES_WRITTEN=$((IG_FILES_WRITTEN + 1))
    IG_GENERATED=$((IG_GENERATED + 1))
    _ig_log ok "キャッシュ保存完了: ${count}ファイル"

    return 0
}

# =============================================================================
# _ig_build_dep_tree - 依存ツリー構築（内部ヘルパー）
# =============================================================================
_ig_build_dep_tree() {
    local project_dir="${1:-.}"
    _IG_DEP_TREE=()

    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"
        local deps=""
        while IFS= read -r line; do
            if [[ "$line" =~ from\ [\"\'](\./[^\"\']+)[\"\'] ]]; then
                local imported="${BASH_REMATCH[1]}"
                deps="${deps}${deps:+,}${imported}"
            fi
        done < <(grep -E "^import " "$file" 2>/dev/null || true)
        _IG_DEP_TREE["$rel"]="$deps"
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" \) \
             -not -path "*/node_modules/*" -print0 2>/dev/null)
}

# =============================================================================
# Report & Score
# =============================================================================
_ig_report() {
    echo -e "\n  ${_IG_BOLD}=== incremental-generation v${IG_VERSION} ===${_IG_NC}"
    echo -e "  変更検出        : ${IG_CHANGES_DETECTED}"
    echo -e "  影響ファイル    : ${IG_AFFECTED_COUNT}"
    echo -e "  スキップ        : ${IG_SKIPPED_COUNT}"
    echo -e "  キャッシュヒット: ${IG_CACHE_HITS}"
    echo -e "  キャッシュミス  : ${IG_CACHE_MISSES}"
    echo -e "  エラー          : ${IG_ERRORS}"
}

_ig_score() {
    local score=50
    [[ ${IG_CHANGES_DETECTED} -gt 0 ]] && score=$((score + 10))
    [[ ${IG_CACHE_HITS} -gt 0 ]] && score=$((score + 15))
    [[ ${IG_SKIPPED_COUNT} -gt 0 ]] && score=$((score + 10))
    [[ ${IG_AFFECTED_COUNT} -gt 0 ]] && score=$((score + 10))
    [[ ${IG_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "incremental-generation" --version "${IG_VERSION}" \
        --description "インクリメンタル再生成×ハッシュ差分×依存波及解析 (v422)" \
        --init "_ig_init" --report "_ig_report" --score "_ig_score" \
        --enable-var "ENABLE_INCREMENTAL_GEN" --cli-flags "--incremental-gen:--no-incremental-gen"
fi

# v2003.1: source時のexit codeを確実に0にする
true
