#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v371.0 - Industry Template: SaaS
# =============================================================================
# SaaS特化テンプレートエンジン。
# Billing/Tenant/Onboarding/Subscription/Usage Metering等のSaaS必須コンポーネントを
# ドメイン知識ベースで自動生成し、初回生成品質を大幅に引き上げる。
#
# Functions:
#   _its_init              - 初期化
#   _its_generate_saas     - SaaS全体テンプレート生成
#   _its_generate_billing  - 課金テンプレート（Stripe連携/プラン管理/請求サイクル）
#   _its_generate_tenant   - テナント管理テンプレート（分離/切替/設定）
#   _its_generate_onboarding - オンボーディングフロー（ステップ/進捗/チェックリスト）
#   _its_generate_subscription - サブスクリプション管理
#   _its_generate_usage_metering - 使用量メータリング
#   _its_report            - レポート出力
#   _its_score             - モジュールスコア(0-100)
#
# All globals use the ITS_ prefix.
# =============================================================================

[[ -n "${_INDUSTRY_TEMPLATE_SAAS_LOADED:-}" ]] && return 0
_INDUSTRY_TEMPLATE_SAAS_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g ITS_VERSION="371.0"
declare -g ITS_INITIALIZED=false
declare -g ITS_GENERATED_COUNT=0
declare -g ITS_TEMPLATE_DIR=""
declare -g ITS_BILLING_GENERATED=false
declare -g ITS_TENANT_GENERATED=false
declare -g ITS_ONBOARDING_GENERATED=false
declare -g ITS_SUBSCRIPTION_GENERATED=false
declare -g ITS_METERING_GENERATED=false
declare -g ENABLE_ITS="${ENABLE_ITS:-true}"

# =============================================================================
# 初期化
# =============================================================================
_its_init() {
    ITS_INITIALIZED=true
    ITS_GENERATED_COUNT=0
    ITS_TEMPLATE_DIR="${PROJECT_ROOT:-.}/.soloptilink/templates/saas"
    mkdir -p "$ITS_TEMPLATE_DIR" 2>/dev/null || true
    return 0
}

# =============================================================================
# SaaS全体テンプレート生成
# =============================================================================
_its_generate_saas() {
    local project_dir="${1:-.}"
    local domain="${2:-saas}"

    [[ "$ITS_INITIALIZED" != "true" ]] && _its_init

    echo -e "  ${CYAN:-\033[0;36m}[ITS]${NC:-\033[0m} SaaS業界テンプレート生成開始..." >&2

    _its_generate_billing "$project_dir"
    _its_generate_tenant "$project_dir"
    _its_generate_onboarding "$project_dir"
    _its_generate_subscription "$project_dir"
    _its_generate_usage_metering "$project_dir"

    echo -e "  ${GREEN:-\033[0;32m}[ITS]${NC:-\033[0m} SaaS業界テンプレート生成完了: ${ITS_GENERATED_COUNT}件" >&2
    return 0
}

# =============================================================================
# 課金テンプレート
# =============================================================================
_its_generate_billing() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITS-BILLING] SaaS課金テンプレート

### Prisma Schema
```prisma
model Plan {
  id          String   @id @default(cuid())
  name        String
  slug        String   @unique
  priceMonthly Int
  priceYearly  Int
  features    Json
  maxUsers    Int      @default(5)
  maxStorage  Int      @default(1073741824)
  isActive    Boolean  @default(true)
  subscriptions Subscription[]
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}

model Subscription {
  id              String   @id @default(cuid())
  tenantId        String
  planId          String
  plan            Plan     @relation(fields: [planId], references: [id])
  status          String   @default("active")
  currentPeriodStart DateTime
  currentPeriodEnd   DateTime
  cancelAtPeriodEnd  Boolean @default(false)
  stripeSubscriptionId String? @unique
  stripeCustomerId    String?
  invoices        Invoice[]
  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt
  @@index([tenantId])
}

model Invoice {
  id             String   @id @default(cuid())
  subscriptionId String
  subscription   Subscription @relation(fields: [subscriptionId], references: [id])
  amount         Int
  currency       String   @default("jpy")
  status         String   @default("draft")
  paidAt         DateTime?
  dueDate        DateTime
  stripeInvoiceId String? @unique
  createdAt      DateTime @default(now())
}
```

### API Routes
```typescript
// POST /api/billing/checkout
export async function createCheckoutSession(planId: string, tenantId: string) {
  const plan = await prisma.plan.findUniqueOrThrow({ where: { id: planId } });
  const session = await stripe.checkout.sessions.create({
    mode: 'subscription',
    line_items: [{ price: plan.stripePriceId, quantity: 1 }],
    success_url: `${process.env.NEXT_PUBLIC_URL}/billing?success=true`,
    cancel_url: `${process.env.NEXT_PUBLIC_URL}/billing?canceled=true`,
    metadata: { tenantId, planId },
  });
  return session;
}

// POST /api/billing/webhook (Stripe Webhook)
export async function handleStripeWebhook(event: Stripe.Event) {
  switch (event.type) {
    case 'checkout.session.completed':
      await activateSubscription(event.data.object);
      break;
    case 'invoice.paid':
      await recordPayment(event.data.object);
      break;
    case 'customer.subscription.deleted':
      await deactivateSubscription(event.data.object);
      break;
  }
}
```
TEMPLATE

    ITS_BILLING_GENERATED=true
    ITS_GENERATED_COUNT=$((ITS_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# テナント管理テンプレート
# =============================================================================
_its_generate_tenant() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITS-TENANT] マルチテナント管理テンプレート

### Prisma Schema
```prisma
model Tenant {
  id          String   @id @default(cuid())
  name        String
  slug        String   @unique
  domain      String?  @unique
  logoUrl     String?
  settings    Json     @default("{}")
  plan        String   @default("free")
  isActive    Boolean  @default(true)
  members     TenantMember[]
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}

model TenantMember {
  id       String @id @default(cuid())
  tenantId String
  userId   String
  role     String @default("member")
  tenant   Tenant @relation(fields: [tenantId], references: [id], onDelete: Cascade)
  @@unique([tenantId, userId])
  @@index([userId])
}
```

### Middleware (テナント解決)
```typescript
import { AsyncLocalStorage } from 'async_hooks';
const tenantStorage = new AsyncLocalStorage<{ tenantId: string }>();

export function withTenant(handler: Function) {
  return async (req: Request) => {
    const tenantId = req.headers.get('x-tenant-id')
      || extractTenantFromHost(req.headers.get('host'));
    if (!tenantId) return new Response('Tenant not found', { status: 404 });
    return tenantStorage.run({ tenantId }, () => handler(req));
  };
}

export function getCurrentTenantId(): string {
  const store = tenantStorage.getStore();
  if (!store) throw new Error('No tenant context');
  return store.tenantId;
}
```
TEMPLATE

    ITS_TENANT_GENERATED=true
    ITS_GENERATED_COUNT=$((ITS_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# オンボーディングテンプレート
# =============================================================================
_its_generate_onboarding() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITS-ONBOARDING] オンボーディングフローテンプレート

### Step Definition
```typescript
interface OnboardingStep {
  id: string;
  title: string;
  description: string;
  component: React.ComponentType;
  isComplete: (data: OnboardingData) => boolean;
  isRequired: boolean;
}

const ONBOARDING_STEPS: OnboardingStep[] = [
  { id: 'profile', title: 'プロフィール設定', isRequired: true, ... },
  { id: 'team', title: 'チームメンバー招待', isRequired: false, ... },
  { id: 'integration', title: '外部連携設定', isRequired: false, ... },
  { id: 'tutorial', title: 'チュートリアル', isRequired: true, ... },
];
```

### Progress Tracking
```typescript
export async function getOnboardingProgress(tenantId: string) {
  const progress = await prisma.onboardingProgress.findUnique({
    where: { tenantId },
  });
  const completedSteps = progress?.completedSteps ?? [];
  const totalRequired = ONBOARDING_STEPS.filter(s => s.isRequired).length;
  const completedRequired = completedSteps.filter(
    id => ONBOARDING_STEPS.find(s => s.id === id)?.isRequired
  ).length;
  return {
    currentStep: progress?.currentStep ?? ONBOARDING_STEPS[0].id,
    completedSteps,
    percentage: Math.round((completedRequired / totalRequired) * 100),
    isComplete: completedRequired >= totalRequired,
  };
}
```
TEMPLATE

    ITS_ONBOARDING_GENERATED=true
    ITS_GENERATED_COUNT=$((ITS_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# サブスクリプション管理テンプレート
# =============================================================================
_its_generate_subscription() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITS-SUBSCRIPTION] サブスクリプション管理テンプレート

### Plan Comparison Component
```tsx
'use client';
export function PlanComparison({ plans, currentPlan }: Props) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
      {plans.map(plan => (
        <div key={plan.id} className={cn(
          "border rounded-lg p-6",
          plan.id === currentPlan?.id && "border-primary ring-2 ring-primary"
        )}>
          <h3 className="text-xl font-bold">{plan.name}</h3>
          <p className="text-3xl font-bold mt-2">
            {formatCurrency(plan.priceMonthly)}<span className="text-sm">/月</span>
          </p>
          <ul className="mt-4 space-y-2">
            {plan.features.map((f: string) => (
              <li key={f} className="flex items-center gap-2">
                <CheckIcon className="h-4 w-4 text-green-500" />{f}
              </li>
            ))}
          </ul>
          <Button
            className="w-full mt-6"
            variant={plan.id === currentPlan?.id ? "outline" : "default"}
            onClick={() => handleUpgrade(plan.id)}
            disabled={plan.id === currentPlan?.id}
          >
            {plan.id === currentPlan?.id ? '現在のプラン' : 'アップグレード'}
          </Button>
        </div>
      ))}
    </div>
  );
}
```
TEMPLATE

    ITS_SUBSCRIPTION_GENERATED=true
    ITS_GENERATED_COUNT=$((ITS_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# 使用量メータリングテンプレート
# =============================================================================
_its_generate_usage_metering() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITS-METERING] 使用量メータリングテンプレート

### Usage Tracking
```typescript
export class UsageMeter {
  async record(tenantId: string, metric: string, quantity: number = 1) {
    await prisma.usageRecord.create({
      data: { tenantId, metric, quantity, recordedAt: new Date() },
    });
    await this.checkLimits(tenantId, metric);
  }

  async checkLimits(tenantId: string, metric: string) {
    const subscription = await prisma.subscription.findFirst({
      where: { tenantId, status: 'active' },
      include: { plan: true },
    });
    if (!subscription) return;
    const currentUsage = await this.getCurrentPeriodUsage(tenantId, metric);
    const limit = subscription.plan.limits?.[metric];
    if (limit && currentUsage >= limit * 0.8) {
      await this.sendUsageAlert(tenantId, metric, currentUsage, limit);
    }
  }

  async getCurrentPeriodUsage(tenantId: string, metric: string): Promise<number> {
    const result = await prisma.usageRecord.aggregate({
      where: { tenantId, metric, recordedAt: { gte: this.periodStart() } },
      _sum: { quantity: true },
    });
    return result._sum.quantity ?? 0;
  }
}
```
TEMPLATE

    ITS_METERING_GENERATED=true
    ITS_GENERATED_COUNT=$((ITS_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# レポート
# =============================================================================
_its_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Industry Template: SaaS v${ITS_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成テンプレート数 : ${ITS_GENERATED_COUNT}"
    echo -e "  Billing            : ${ITS_BILLING_GENERATED}"
    echo -e "  Tenant             : ${ITS_TENANT_GENERATED}"
    echo -e "  Onboarding         : ${ITS_ONBOARDING_GENERATED}"
    echo -e "  Subscription       : ${ITS_SUBSCRIPTION_GENERATED}"
    echo -e "  Usage Metering     : ${ITS_METERING_GENERATED}"
}

# =============================================================================
# スコア
# =============================================================================
_its_score() {
    local score=30
    [[ "$ITS_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$ITS_BILLING_GENERATED" == "true" ]] && score=$((score + 12))
    [[ "$ITS_TENANT_GENERATED" == "true" ]] && score=$((score + 12))
    [[ "$ITS_ONBOARDING_GENERATED" == "true" ]] && score=$((score + 12))
    [[ "$ITS_SUBSCRIPTION_GENERATED" == "true" ]] && score=$((score + 12))
    [[ "$ITS_METERING_GENERATED" == "true" ]] && score=$((score + 12))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "industry-template-saas" \
    --version "371.0" \
    --description "SaaS業界テンプレート（Billing/Tenant/Onboarding/Subscription/Metering）" \
    --init "_its_init" \
    --report "_its_report" \
    --score "_its_score" \
    --enable-var "ENABLE_ITS" \
    --cli-flags "--industry-saas:--no-industry-saas"
