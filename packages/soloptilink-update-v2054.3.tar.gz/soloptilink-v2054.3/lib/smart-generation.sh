#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v57.0 - Smart Generation Pipeline
# 依存関係順にコードを段階生成する知的パイプライン
#
# 問題: 1つの巨大プロンプトで全コードを同時生成すると
# - ファイル間のimportパスが不整合
# - 型定義と使用箇所が一致しない
# - DB schemaとAPIの不整合
# - フロントエンドがバックエンドAPIと不一致
#
# 解決: 依存関係順に段階生成
# Step 1: DB Schema (Prisma/SQLAlchemy) → 検証
# Step 2: 型定義/インターフェース → 検証
# Step 3: Backend API (schemaを参照) → 検証
# Step 4: Frontend (API型を参照) → 検証
# 各ステップで前ステップの成果物をコンテキストとして注入
#
# v57.0: Smart Generation
# ============================================================

# --- グローバル状態 ---
SG_VERSION="120.0"
SG_INITIALIZED=false
SG_STEP_COUNT=0
SG_TOTAL_FILES=0
SG_GENERATED_ARTIFACTS=()
SG_QUALITY_SCORES=()

# --- 設定 ---
SG_MAX_STEPS=8
SG_VALIDATE_EACH_STEP="true"

# ============================================================
# 初期化
# ============================================================
sg_init() {
    SG_INITIALIZED=true
    SG_STEP_COUNT=0
    SG_TOTAL_FILES=0
    SG_GENERATED_ARTIFACTS=()
    SG_QUALITY_SCORES=()
    return 0
}

# ============================================================
# プロジェクト種別に基づく生成ステップ定義
# 各ステップは「何を生成するか」「前提として何が必要か」を定義
# ============================================================
sg_define_steps() {
    local project_type="${1:-fullstack}"
    local domain="${2:-general}"
    local task_desc="${3:-}"

    local steps=""

    case "$project_type" in
        fullstack|nextjs|saas)
            steps="schema:DB Schema (Prisma) - テーブル定義・リレーション・インデックス
types:型定義 - API Request/Response型・Entity型・Enum定義
backend_core:バックエンドコア - サービス層・リポジトリ層・バリデーションスキーマ
api_routes:APIルート - エンドポイント実装・ミドルウェア・エラーハンドリング
frontend_core:フロントエンドコア - レイアウト・共通コンポーネント・認証Provider
frontend_pages:ページ実装 - CRUD画面・フォーム・一覧表示・詳細表示
frontend_hooks:カスタムフック - API呼び出し・状態管理・バリデーション
config:設定ファイル - .env・next.config・tailwind.config"
            ;;
        api-only|express|fastapi)
            steps="schema:DB Schema - テーブル定義・リレーション
types:型定義 - Request/Response型・Entity型
services:サービス層 - ビジネスロジック・トランザクション
api_routes:APIルート - エンドポイント・ミドルウェア・バリデーション
tests:テスト - ユニットテスト・APIテスト
config:設定 - .env・サーバー設定"
            ;;
        spa|react)
            steps="types:型定義 - コンポーネントProps・API型・状態型
components:共通コンポーネント - UI部品・レイアウト・ErrorBoundary
pages:ページ実装 - ルーティング・CRUD画面
hooks:カスタムフック - API呼び出し・状態管理
config:設定 - vite.config・tailwind.config"
            ;;
        static-site|lp)
            steps="structure:HTML構造 - ページ構成・セクション定義
styles:スタイル - CSS/Tailwind・レスポンシブ
scripts:JavaScript - インタラクション・フォーム処理"
            ;;
        ios-app|swift)
            steps="models:データモデル - CoreData Entity・Swift構造体
repository:リポジトリ層 - CoreDataRepository・CRUD操作
viewmodels:ViewModel - @Published・async/await・ビジネスロジック
views:SwiftUI Views - 一覧/詳細/作成/編集画面
config:設定 - Package.swift・Info.plist"
            ;;
        *)
            steps="schema:基盤定義 - データ構造・型定義
implementation:実装 - コアロジック
config:設定 - 設定ファイル"
            ;;
    esac

    echo "$steps"
}

# ============================================================
# ステップ別プロンプト生成
# 前ステップの成果物をコンテキストとして注入
# ============================================================
sg_build_step_prompt() {
    local step_name="$1"
    local step_desc="$2"
    local task_desc="$3"
    local domain="${4:-general}"
    local prev_artifacts="${5:-}"

    local prompt=""

    prompt+="## タスク: ${task_desc}

## 今回のステップ: ${step_desc}
このステップでは「${step_name}」のみを生成してください。他のステップの内容は含めないでください。

## 技術スタック（固定）
- フレームワーク: Next.js 15 App Router
- 言語: TypeScript (strict mode)
- ORM: Prisma (SQLite開発 → PostgreSQL本番)
- バリデーション: zod
- 全async関数にtry-catch必須"

    # 前ステップの成果物を参照コンテキストとして注入
    if [[ -n "$prev_artifacts" ]]; then
        prompt+="

## 前ステップの成果物（参照用 - これらと整合性を保ってください）
${prev_artifacts}"
    fi

    # ステップ別の具体的な指示
    case "$step_name" in
        schema)
            prompt+="

## Schema生成ルール
- Prisma schema format で出力してください
- 全テーブルに id, createdAt, updatedAt カラム必須
- リレーション（@relation）を正確に定義
- インデックス（@@index）をクエリパターンに合わせて定義
- enum を適切に使用
- ソフトデリート用の deletedAt カラムを追加"
            ;;
        types)
            prompt+="

## 型定義ルール
- TypeScript の型定義ファイルを出力
- API Request / Response の型を明示的に定義
- Schema と完全に一致する Entity 型を定義
- Enum を TypeScript enum として定義
- zodスキーマも同時に定義（型とバリデーションを統一）"
            ;;
        backend_core|services)
            prompt+="

## バックエンド実装ルール
- サービス層を分離（APIハンドラにビジネスロジック禁止）
- Prisma Client を使用（raw SQL禁止）
- 全操作に try-catch + 適切なエラーハンドリング
- 複数テーブル操作時は \$transaction 必須
- 監査ログ: createdBy/updatedBy を記録"
            ;;
        api_routes)
            prompt+="

## APIルート実装ルール
- 前ステップの型定義とサービス層を import して使用
- 全エンドポイントに zod バリデーション
- 統一エラーレスポンス形式
- ページネーション（cursor/offset 両対応）
- 認証ミドルウェアを適切に適用"
            ;;
        frontend_core|components)
            prompt+="

## フロントエンドコアルール
- 前ステップの型定義を import して使用
- ErrorBoundary でラップ
- ローディング/エラー/空状態を全て実装
- レスポンシブ（モバイルファースト）
- アクセシビリティ（aria-label, role）
- 共通ボタンコンポーネントは onClick プロパティを必須にすること
- 共通モーダルコンポーネントは isOpen/onClose プロパティを必須にすること
- href=\"#\" は絶対禁止。ナビゲーションにはNext.js Linkまたはrouter.push()を使用"
            ;;
        frontend_pages|pages)
            prompt+="

## ページ実装ルール
- 前ステップの共通コンポーネントとカスタムフックを import して使用
- APIエンドポイントは前ステップで定義されたものと完全一致
- CRUD全操作を実装（作成・読取・更新・削除・確認ダイアログ）
- React Hook Form + zodResolver でフォームバリデーション

## UI接続性ルール（v100.1 最重要）
- 全てのボタンには必ず動作するonClickハンドラを設定すること
- 「新規作成」「追加」等のボタンはrouter.push()で対応ページに遷移すること
- 「編集」「詳細」ボタンは該当レコードのIDを含むURLに遷移すること
- 「削除」ボタンは確認ダイアログ→API DELETE→一覧リフレッシュを実装すること
- href=\"#\" は絶対禁止。実際のルートパスを設定すること
- フォームには必ずonSubmit（API POST/PUT + エラーハンドリング + 成功時の遷移）を実装すること
- モーダル/ダイアログは開くトリガー（setIsOpen(true)等）を必ず実装すること
- ローディング状態・エラー状態・空状態を全て実装すること"

            # v120.0: API契約を注入（Frontend-Backend名前不一致を根絶）
            local _cg_contract="${PROJECT_DIR:-.}/.soloptilink/api-contract.json"
            if [[ -f "$_cg_contract" ]] && type -t cg_inject_into_prompt &>/dev/null; then
                prompt+="

$(cg_inject_into_prompt "$_cg_contract" "${PROJECT_DIR:-.}")"
            fi

            # v120.0: Golden Patternsテンプレート直接注入
            if type -t gp_pattern_data_fetching &>/dev/null; then
                prompt+="

## 必須テンプレート（Golden Pattern - このパターンをそのまま適用すること）
$(gp_pattern_data_fetching)

$(gp_pattern_form_submission)

$(gp_pattern_delete_with_confirm)

$(gp_pattern_crud_list)"
            fi
            ;;
        frontend_hooks|hooks)
            prompt+="

## カスタムフックルール
- useSWR / React Query でサーバーステート管理
- 前ステップの型定義を使用
- APIエンドポイントは前ステップと一致
- エラーハンドリング・ローディング状態を含む"
            ;;
    esac

    echo "$prompt"
}

# ============================================================
# 段階生成実行
# ============================================================
sg_execute_pipeline() {
    local task_desc="$1"
    local project_type="${2:-fullstack}"
    local domain="${3:-general}"
    local output_dir="${4:-}"

    sg_init

    # ステップ定義取得
    local steps_def
    steps_def=$(sg_define_steps "$project_type" "$domain" "$task_desc")

    local accumulated_artifacts=""
    local all_output=""
    local step_num=0

    echo -e "  ${CYAN:-}📋 [SG] Smart Generation Pipeline 開始 (${project_type})${NC:-}" >&2

    # 各ステップを順次実行
    while IFS= read -r step_line; do
        [[ -z "$step_line" ]] && continue

        step_num=$((step_num + 1))
        SG_STEP_COUNT=$step_num

        local step_name="${step_line%%:*}"
        local step_desc="${step_line#*:}"

        echo -e "  ${CYAN:-}📋 [SG] Step ${step_num}: ${step_desc}${NC:-}" >&2

        # ステップ別プロンプト構築（前ステップの成果物を注入）
        local step_prompt
        step_prompt=$(sg_build_step_prompt "$step_name" "$step_desc" "$task_desc" "$domain" "$accumulated_artifacts")

        # v2003.1: Enterprise Patterns と Cross-Session Learning をステップに注入
        # ただしプロンプト肥大化を防ぐため、backendとapi_routesステップのみ
        if [[ "$step_name" == "backend_core" || "$step_name" == "api_routes" ]]; then
            if [[ -n "${SG_ENTERPRISE_PATTERNS:-}" ]]; then
                # 参照実装は最大3000文字に制限（肥大化防止）
                step_prompt+="
=== Enterprise参照パターン（最重要部分のみ） ===
${SG_ENTERPRISE_PATTERNS:0:3000}
=== Enterprise参照END ==="
            fi
        fi
        if [[ -n "${SG_CROSS_SESSION:-}" && ${#SG_CROSS_SESSION} -gt 20 ]]; then
            step_prompt+="
=== エラー予防指示（過去学習） ===
${SG_CROSS_SESSION:0:1500}
=== エラー予防END ==="
        fi

        # v2048: 可変開発層数 — Scale Planner が決めた規模層(業務サブシステム構成)を注入。
        #   生成は「この規模に過不足なく」合わせる(多すぎる分割も不足も避ける)。空なら従来挙動。
        if [[ -n "${SG_LAYER_PLAN:-}" ]]; then
            step_prompt+="
=== 生成すべき規模(業務サブシステム構成・規模層) ===
${SG_LAYER_PLAN:0:2500}
※ 上記の各業務サブシステム(規模層 SL)を過不足なく実装すること。指定数より多い分割も、不足も避ける。
   検証段数(構文/型/ランタイム/UI/エッジの品質5層)は規模に関係なく常に全段かける。
=== 規模END ==="
        fi

        # v2003.1: Generation Quality品質パターン注入（frontendステップのみ）
        if [[ "$step_name" == "frontend_core" || "$step_name" == "frontend_pages" ]]; then
            if [[ -n "${SG_QUALITY_PATTERNS:-}" ]]; then
                step_prompt+="
=== 品質要件（アクセシビリティ/パフォーマンス） ===
${SG_QUALITY_PATTERNS:0:2000}
=== 品質要件END ==="
            fi
        fi

        # Claude呼び出し（v56.0 Claude Bridge経由）
        local step_output=""
        if type -t cb2_call &>/dev/null && [[ "${ENABLE_CLAUDE_BRIDGE:-true}" == "true" ]]; then
            step_output=$(cb2_call "$step_prompt" "" "$step_name" "$domain")
        elif type -t _call_claude &>/dev/null; then
            step_output=$(_call_claude "$step_prompt" "" "$step_name")
        fi

        if [[ -z "$step_output" ]]; then
            echo -e "  ${RED:-}❌ [SG] Step ${step_num} 生成失敗 → スキップ${NC:-}" >&2
            continue
        fi

        # v120.0: api_routesステップ完了後にAPI契約を自動生成
        if [[ "$step_name" == "api_routes" ]] && type -t cg_generate_contract &>/dev/null; then
            echo -e "  ${CYAN:-}📋 [SG] v120.0: API契約を自動生成中...${NC:-}" >&2
            cg_generate_contract "${PROJECT_DIR:-.}" >/dev/null 2>&1 || true
        fi

        # v120.0: 成果物を蓄積（構造化artifact抽出で品質向上）
        local artifact_summary=""
        if type -t cg_extract_key_artifacts &>/dev/null; then
            artifact_summary=$(cg_extract_key_artifacts "$step_output" "$step_name" 2>/dev/null || echo "${step_output:0:5000}")
        else
            artifact_summary="${step_output:0:5000}"
        fi
        SG_GENERATED_ARTIFACTS+=("$step_name:$artifact_summary")

        # コンテキスト更新（最新3ステップ分）
        accumulated_artifacts=""
        local art_count=${#SG_GENERATED_ARTIFACTS[@]}
        local start_idx=0
        [[ $art_count -gt 3 ]] && start_idx=$((art_count - 3))
        for ((idx=start_idx; idx<art_count; idx++)); do
            accumulated_artifacts+="
--- 前ステップ成果物: ${SG_GENERATED_ARTIFACTS[$idx]%%:*} ---
${SG_GENERATED_ARTIFACTS[$idx]#*:}
"
        done

        # 出力蓄積
        all_output+="$step_output
"

        # v100.1: ステップ毎に即時ファイル書出し（tsc検証のためにディスク上にコードを配置）
        if [[ "${SG_VALIDATE_EACH_STEP}" == "true" ]]; then
            local _sg_proj="${PROJECT_DIR:-.}"
            if type -t fw2_parse_and_write &>/dev/null; then
                local _sg_written
                _sg_written=$(fw2_parse_and_write "$step_output" "$_sg_proj" 2>/dev/null || echo "0")
                if [[ "${_sg_written:-0}" -gt 0 ]]; then
                    echo -e "  ${GREEN:-}✅ [SG] Step ${step_num}: ${_sg_written}ファイルを即時書出し${NC:-}" >&2
                fi
            elif type -t _write_claude_output_to_files &>/dev/null; then
                local _sg_tmp="/tmp/sg_step_${step_num}_$$.txt"
                echo "$step_output" > "$_sg_tmp"
                _write_claude_output_to_files "$_sg_tmp" 2>/dev/null || true
                rm -f "$_sg_tmp"
                echo -e "  ${GREEN:-}✅ [SG] Step ${step_num}: ファイルを即時書出し${NC:-}" >&2
            fi
        fi

        # ステップ間検証（v56.0 Real Feedback連携）
        if [[ "${SG_VALIDATE_EACH_STEP}" == "true" ]] && type -t rf_run_all_checks &>/dev/null; then
            local _sg_feedback
            _sg_feedback=$(rf_run_all_checks "${PROJECT_DIR:-.}" 2>/dev/null || echo "")
            if [[ -n "$_sg_feedback" ]]; then
                echo -e "  ${YELLOW:-}⚠️ [SG] Step ${step_num} 検証で問題あり（次ステップで対応）${NC:-}" >&2
            else
                echo -e "  ${GREEN:-}✅ [SG] Step ${step_num} 検証パス${NC:-}" >&2
            fi
        fi

        # v100.1: ステップ間ビルド検証（実コンパイラで型エラー・構文エラーを即座に検出）
        if [[ "${SG_VALIDATE_EACH_STEP}" == "true" ]]; then
            local _sg_build_errors=""
            _sg_proj="${PROJECT_DIR:-.}"  # 確実に設定（上のブロックがスキップされた場合に備える）

            # TypeScript プロジェクト: tsc --noEmit で型チェック（タイムアウト30秒）
            if [[ -f "${_sg_proj}/tsconfig.json" ]] && command -v npx &>/dev/null; then
                local _tsc_out
                _tsc_out=$(cd "$_sg_proj" && timeout 30 npx tsc --noEmit 2>&1 | head -30) || true
                local _tsc_errors
                _tsc_errors=$(echo "$_tsc_out" | grep -c "error TS" 2>/dev/null || echo "0")
                if [[ "${_tsc_errors:-0}" -gt 0 ]]; then
                    _sg_build_errors+="TypeScript: ${_tsc_errors}個の型エラー\n${_tsc_out}\n"
                    echo -e "  ${RED:-}❌ [SG] Step ${step_num} tsc: ${_tsc_errors}個の型エラー検出${NC:-}" >&2
                fi
            fi

            # Next.js プロジェクト: next lint で構文チェック（タイムアウト30秒）
            if [[ -f "${_sg_proj}/next.config.mjs" || -f "${_sg_proj}/next.config.js" || -f "${_sg_proj}/next.config.ts" ]] && command -v npx &>/dev/null; then
                local _lint_out
                _lint_out=$(cd "$_sg_proj" && timeout 30 npx next lint --quiet 2>&1 | head -20) || true
                local _lint_errors
                _lint_errors=$(echo "$_lint_out" | grep -cE "(Error|error)" 2>/dev/null || echo "0")
                if [[ "${_lint_errors:-0}" -gt 0 ]]; then
                    _sg_build_errors+="Lint: ${_lint_errors}個のエラー\n${_lint_out}\n"
                    echo -e "  ${YELLOW:-}⚠️ [SG] Step ${step_num} lint: ${_lint_errors}個のエラー${NC:-}" >&2
                fi
            fi

            # v101.0: Real Validatorで包括的検証（tsc + eslint + import整合性）
            if type -t rv_validate_project &>/dev/null; then
                local _rv_report
                _rv_report=$(rv_validate_project "${_sg_proj}" 2>/dev/null || echo "")
                if [[ -n "$_rv_report" ]]; then
                    _sg_build_errors+="
${_rv_report}"
                    echo -e "  ${RED:-}❌ [SG] Step ${step_num} Real Validator: ${RV_TOTAL_ERRORS:-0}エラー${NC:-}" >&2
                fi
            fi

            # v101.0: 最終ステップでは統合検証も実行
            if [[ "$step_num" -ge "$((SG_STEP_COUNT))" ]] && type -t lv_verify_integration &>/dev/null; then
                local _lv_report
                _lv_report=$(lv_verify_integration "${_sg_proj}" 2>/dev/null || echo "")
                if [[ -n "$_lv_report" ]]; then
                    _sg_build_errors+="
${_lv_report}"
                    echo -e "  ${YELLOW:-}⚠️ [SG] Step ${step_num} 統合検証: ${LV_TOTAL_ISSUES:-0}件の不整合${NC:-}" >&2
                fi
            fi

            # ビルドエラーがあれば、次ステップのコンテキストにエラー情報を構造化注入
            if [[ -n "$_sg_build_errors" ]]; then
                # v101.0: 構造化エラー注入（AIが理解しやすい形式）
                local _error_count=0
                _error_count=$(echo "$_sg_build_errors" | grep -c "エラー\|error\|Error" 2>/dev/null || echo "0")

                accumulated_artifacts+="
=== 【重要】Step ${step_num} で検出されたエラー (${_error_count}件) ===
【指示】次のステップで以下のエラーを全て修正してください。
       行番号が示されている場合、その行を正確に修正してください。
       anyやts-ignoreで回避せず、正しい型定義で解決してください。

$(echo -e "$_sg_build_errors")
=== エラー一覧終了 ===
"
                # Error Intelligence: パターン学習
                if type -t ei_learn_from_rv &>/dev/null; then
                    ei_learn_from_rv "$_sg_build_errors" "${DOMAIN_TYPE:-general}" 2>/dev/null || true
                fi

                echo -e "  ${YELLOW:-}⚠️ [SG] ${_error_count}件のエラーを次ステップに構造化注入${NC:-}" >&2
            else
                echo -e "  ${GREEN:-}✅ [SG] Step ${step_num} ビルド検証パス${NC:-}" >&2
            fi
        fi

        # ファイル数カウント
        local file_count
        file_count=$(echo "$step_output" | grep -c "^--- FILE:" 2>/dev/null || echo "0")
        SG_TOTAL_FILES=$((SG_TOTAL_FILES + file_count))

    done <<< "$steps_def"

    echo -e "  ${GREEN:-}✅ [SG] Pipeline完了: ${SG_STEP_COUNT}ステップ, ${SG_TOTAL_FILES}ファイル生成${NC:-}" >&2

    # 全出力を返す
    echo "$all_output"
}

# ============================================================
# プロジェクト種別自動検出
# Phase Optimizer (v38.0) の結果を活用
# ============================================================
sg_detect_project_type() {
    local task_desc="$1"

    # Phase Optimizer の結果があればそれを使用
    if [[ -n "${PO_PROJECT_TYPE:-}" ]]; then
        echo "$PO_PROJECT_TYPE"
        return 0
    fi

    # タスク記述から推定
    local desc_lower
    desc_lower=$(echo "$task_desc" | tr '[:upper:]' '[:lower:]')

    if echo "$desc_lower" | grep -qE '(ios|iphone|ipad|swift)'; then
        echo "ios-app"
    elif echo "$desc_lower" | grep -qE '(api|backend|サーバー|server)' && ! echo "$desc_lower" | grep -qE '(フロント|react|next|画面)'; then
        echo "api-only"
    elif echo "$desc_lower" | grep -qE '(lp|ランディング|静的|static)'; then
        echo "static-site"
    elif echo "$desc_lower" | grep -qE '(saas|マルチテナント|multi-tenant)'; then
        echo "saas"
    elif echo "$desc_lower" | grep -qE '(spa|react|vue|angular)' && ! echo "$desc_lower" | grep -qE '(api|db|データベース)'; then
        echo "spa"
    else
        echo "fullstack"
    fi
}

# ============================================================
# レポート
# ============================================================
sg_report() {
    echo -e "\n  ${BOLD:-}═══ Smart Generation v57.0 レポート ═══${NC:-}"
    echo -e "  ステップ数       : ${SG_STEP_COUNT}"
    echo -e "  生成ファイル数   : ${SG_TOTAL_FILES}"
    echo -e "  ステップ間検証   : ${SG_VALIDATE_EACH_STEP}"
}

sg_report_json() {
    cat <<EOF
{"module":"smart-generation","version":"${SG_VERSION}","steps":${SG_STEP_COUNT},"files":${SG_TOTAL_FILES},"validate_each":${SG_VALIDATE_EACH_STEP}}
EOF
}

sg_score() {
    if [[ $SG_STEP_COUNT -eq 0 ]]; then
        echo "50"
    elif [[ $SG_TOTAL_FILES -gt 10 ]]; then
        echo "90"
    elif [[ $SG_TOTAL_FILES -gt 5 ]]; then
        echo "80"
    else
        echo "70"
    fi
}

# ============================================================
# v59.0: Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "smart-generation" \
        --version "57.0" \
        --description "依存順段階生成×Schema→Backend→Frontend" \
        --init "sg_init" \
        --report "sg_report" \
        --score "sg_score" \
        --enable-var "ENABLE_SMART_GENERATION" \
        --cli-flags "--smart-generation:--no-smart-generation"
fi

# v2003.1: source時のexit codeを確実に0にする
true
