#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v473.0 - User Preference Learning Engine
# =============================================================================
# ユーザーのコーディングスタイル・技術選択・設計判断の傾向を学習し、
# 次回以降のコード生成に反映する。フィードバックから暗黙知を抽出して
# パーソナライズされた開発体験を提供するエンジン。
#
# Functions:
#   _upl_init               - 初期化・プロファイルロード
#   _upl_track_preferences  - ユーザー選択を追跡記録
#   _upl_learn_style        - コーディングスタイル学習
#   _upl_apply_preferences  - 学習した嗜好をプロンプトに反映
#   _upl_get_profile        - ユーザープロファイル取得
#   _upl_update_profile     - プロファイル更新
#   _upl_report             - レポート出力
#   _upl_score              - モジュールスコア(0-100)
#
# Globals: UPL_ prefix
# =============================================================================

[[ -n "${_USER_PREFERENCE_LEARNING_LOADED:-}" ]] && return 0
_USER_PREFERENCE_LEARNING_LOADED=1

UPL_VERSION="473.0"
UPL_INITIALIZED=false

# --- Storage ---
UPL_DATA_DIR=""
UPL_PROFILE_FILE=""
UPL_HISTORY_FILE=""
UPL_STYLE_FILE=""

# --- State ---
UPL_TOTAL_OBSERVATIONS=0
UPL_PROFILE_COMPLETENESS=0
UPL_STYLE_CONFIDENCE=0

# --- Preference Dimensions ---
declare -g -A _UPL_PREFERENCES=()
declare -g -A _UPL_STYLE_SCORES=()
declare -g -A _UPL_TECH_CHOICES=()
declare -g -A _UPL_DESIGN_DECISIONS=()
declare -g -a _UPL_FEEDBACK_LOG=()

# Style dimensions with defaults
declare -g -A _UPL_STYLE_DEFAULTS=(
    ["naming_convention"]="camelCase"
    ["indent_style"]="spaces"
    ["indent_size"]="2"
    ["quote_style"]="single"
    ["semicolons"]="false"
    ["trailing_comma"]="es5"
    ["max_line_length"]="100"
    ["component_style"]="functional"
    ["state_management"]="useState"
    ["css_approach"]="tailwind"
    ["api_style"]="rest"
    ["test_framework"]="vitest"
    ["error_handling"]="try-catch"
    ["comment_density"]="moderate"
    ["type_strictness"]="strict"
    ["file_organization"]="feature-based"
)

# =============================================================================
# 初期化
# =============================================================================
_upl_init() {
    local base_dir="${HOME}/.soloptilink/user-preferences"
    UPL_DATA_DIR="$base_dir"
    UPL_PROFILE_FILE="${base_dir}/profile.json"
    UPL_HISTORY_FILE="${base_dir}/history.jsonl"
    UPL_STYLE_FILE="${base_dir}/style.json"

    mkdir -p "$UPL_DATA_DIR"

    # 既存プロファイルのロード
    if [[ -f "$UPL_PROFILE_FILE" ]]; then
        while IFS='=' read -r key value; do
            [[ -z "$key" || "$key" == "#"* ]] && continue
            _UPL_PREFERENCES["$key"]="$value"
        done < <(grep -oP '"[^"]+"\s*:\s*"[^"]*"' "$UPL_PROFILE_FILE" 2>/dev/null | sed 's/"//g; s/\s*:\s*/=/')
        UPL_PROFILE_COMPLETENESS=$(( ${#_UPL_PREFERENCES[@]} * 100 / ${#_UPL_STYLE_DEFAULTS[@]} ))
        [[ $UPL_PROFILE_COMPLETENESS -gt 100 ]] && UPL_PROFILE_COMPLETENESS=100
    fi

    # デフォルト値の適用
    for key in "${!_UPL_STYLE_DEFAULTS[@]}"; do
        [[ -z "${_UPL_PREFERENCES[$key]:-}" ]] && _UPL_PREFERENCES["$key"]="${_UPL_STYLE_DEFAULTS[$key]}"
    done

    if [[ -f "$UPL_HISTORY_FILE" ]]; then
        UPL_TOTAL_OBSERVATIONS=$(wc -l < "$UPL_HISTORY_FILE" 2>/dev/null || echo "0")
    fi

    UPL_INITIALIZED=true
    return 0
}

# =============================================================================
# ユーザー選択を追跡記録
# =============================================================================
_upl_track_preferences() {
    local category="$1"
    local key="$2"
    local value="$3"
    local context="${4:-}"

    [[ "$UPL_INITIALIZED" != "true" ]] && _upl_init

    local timestamp
    timestamp=$(date +%s)

    _UPL_PREFERENCES["$key"]="$value"

    case "$category" in
        tech)    _UPL_TECH_CHOICES["$key"]="$value" ;;
        design)  _UPL_DESIGN_DECISIONS["$key"]="$value" ;;
        style)   _UPL_STYLE_SCORES["$key"]="$value" ;;
    esac

    echo "{\"ts\":${timestamp},\"cat\":\"${category}\",\"key\":\"${key}\",\"val\":\"${value}\",\"ctx\":\"${context}\"}" >> "$UPL_HISTORY_FILE" 2>/dev/null

    UPL_TOTAL_OBSERVATIONS=$((UPL_TOTAL_OBSERVATIONS + 1))
    return 0
}

# =============================================================================
# コーディングスタイル学習
# =============================================================================
_upl_learn_style() {
    local project_dir="$1"

    [[ "$UPL_INITIALIZED" != "true" ]] && _upl_init
    [[ ! -d "$project_dir" ]] && return 1

    local ts_files
    ts_files=$(find "$project_dir" -name "*.ts" -o -name "*.tsx" 2>/dev/null | grep -v node_modules | grep -v ".next" | head -50)

    [[ -z "$ts_files" ]] && return 1

    local sample_content=""
    for f in $ts_files; do
        sample_content+=$(head -50 "$f" 2>/dev/null)
        sample_content+=$'\n'
    done

    # インデントスタイル検出
    local tabs spaces
    tabs=$(echo "$sample_content" | grep -c "^	" 2>/dev/null || echo "0")
    spaces=$(echo "$sample_content" | grep -c "^  " 2>/dev/null || echo "0")
    if [[ $tabs -gt $spaces ]]; then
        _upl_track_preferences "style" "indent_style" "tabs"
    else
        _upl_track_preferences "style" "indent_style" "spaces"
        # インデントサイズ検出
        local two_spaces four_spaces
        two_spaces=$(echo "$sample_content" | grep -c "^  [^ ]" 2>/dev/null || echo "0")
        four_spaces=$(echo "$sample_content" | grep -c "^    [^ ]" 2>/dev/null || echo "0")
        if [[ $four_spaces -gt $two_spaces ]]; then
            _upl_track_preferences "style" "indent_size" "4"
        else
            _upl_track_preferences "style" "indent_size" "2"
        fi
    fi

    # クオートスタイル検出
    local single_quotes double_quotes
    single_quotes=$(echo "$sample_content" | grep -c "'" 2>/dev/null || echo "0")
    double_quotes=$(echo "$sample_content" | grep -c '"' 2>/dev/null || echo "0")
    if [[ $single_quotes -gt $double_quotes ]]; then
        _upl_track_preferences "style" "quote_style" "single"
    else
        _upl_track_preferences "style" "quote_style" "double"
    fi

    # セミコロン検出
    local with_semi without_semi
    with_semi=$(echo "$sample_content" | grep -c ";$" 2>/dev/null || echo "0")
    without_semi=$(echo "$sample_content" | grep -c "[^;]$" 2>/dev/null || echo "0")
    if [[ $with_semi -gt $((without_semi / 2)) ]]; then
        _upl_track_preferences "style" "semicolons" "true"
    else
        _upl_track_preferences "style" "semicolons" "false"
    fi

    # コンポーネントスタイル検出
    local functional_count class_count
    functional_count=$(echo "$sample_content" | grep -c "const .* = .*=>" 2>/dev/null || echo "0")
    class_count=$(echo "$sample_content" | grep -c "class .* extends" 2>/dev/null || echo "0")
    if [[ $class_count -gt $functional_count ]]; then
        _upl_track_preferences "style" "component_style" "class"
    else
        _upl_track_preferences "style" "component_style" "functional"
    fi

    # CSS アプローチ検出
    if echo "$sample_content" | grep -q "className.*=.*\"" 2>/dev/null; then
        if echo "$sample_content" | grep -q "flex\|grid\|p-\|m-\|text-" 2>/dev/null; then
            _upl_track_preferences "style" "css_approach" "tailwind"
        fi
    elif find "$project_dir" -name "*.module.css" 2>/dev/null | head -1 | grep -q .; then
        _upl_track_preferences "style" "css_approach" "css-modules"
    elif find "$project_dir" -name "*.styled.*" 2>/dev/null | head -1 | grep -q .; then
        _upl_track_preferences "style" "css_approach" "styled-components"
    fi

    # テストフレームワーク検出
    if grep -q "vitest" "${project_dir}/package.json" 2>/dev/null; then
        _upl_track_preferences "tech" "test_framework" "vitest"
    elif grep -q "jest" "${project_dir}/package.json" 2>/dev/null; then
        _upl_track_preferences "tech" "test_framework" "jest"
    fi

    # 信頼度の更新
    UPL_STYLE_CONFIDENCE=$((UPL_TOTAL_OBSERVATIONS * 5))
    [[ $UPL_STYLE_CONFIDENCE -gt 100 ]] && UPL_STYLE_CONFIDENCE=100

    _upl_update_profile
    return 0
}

# =============================================================================
# 学習した嗜好をプロンプトに反映
# =============================================================================
_upl_apply_preferences() {
    local base_prompt="$1"
    local category="${2:-all}"

    [[ "$UPL_INITIALIZED" != "true" ]] && _upl_init

    local style_instructions=""

    if [[ "$category" == "all" || "$category" == "style" ]]; then
        style_instructions+="[コーディングスタイル要件]\n"
        style_instructions+="- インデント: ${_UPL_PREFERENCES["indent_style"]:-spaces} (${_UPL_PREFERENCES["indent_size"]:-2})\n"
        style_instructions+="- クオート: ${_UPL_PREFERENCES["quote_style"]:-single}\n"
        style_instructions+="- セミコロン: ${_UPL_PREFERENCES["semicolons"]:-false}\n"
        style_instructions+="- コンポーネント: ${_UPL_PREFERENCES["component_style"]:-functional}\n"
        style_instructions+="- CSS: ${_UPL_PREFERENCES["css_approach"]:-tailwind}\n"
    fi

    if [[ "$category" == "all" || "$category" == "tech" ]]; then
        style_instructions+="[技術選択]\n"
        for key in "${!_UPL_TECH_CHOICES[@]}"; do
            style_instructions+="- ${key}: ${_UPL_TECH_CHOICES[$key]}\n"
        done
    fi

    if [[ "$category" == "all" || "$category" == "design" ]]; then
        if [[ ${#_UPL_DESIGN_DECISIONS[@]} -gt 0 ]]; then
            style_instructions+="[設計判断]\n"
            for key in "${!_UPL_DESIGN_DECISIONS[@]}"; do
                style_instructions+="- ${key}: ${_UPL_DESIGN_DECISIONS[$key]}\n"
            done
        fi
    fi

    echo -e "${style_instructions}\n${base_prompt}"
    return 0
}

# =============================================================================
# プロファイル取得・更新
# =============================================================================
_upl_get_profile() {
    echo "{"
    local first=true
    for key in "${!_UPL_PREFERENCES[@]}"; do
        [[ "$first" != "true" ]] && echo ","
        echo -n "  \"${key}\": \"${_UPL_PREFERENCES[$key]}\""
        first=false
    done
    echo ""
    echo "}"
}

_upl_update_profile() {
    _upl_get_profile > "$UPL_PROFILE_FILE" 2>/dev/null
    UPL_PROFILE_COMPLETENESS=$(( ${#_UPL_PREFERENCES[@]} * 100 / ${#_UPL_STYLE_DEFAULTS[@]} ))
    [[ $UPL_PROFILE_COMPLETENESS -gt 100 ]] && UPL_PROFILE_COMPLETENESS=100
}

# =============================================================================
# レポート
# =============================================================================
_upl_report() {
    echo -e "\n  ${BOLD:-}═══ User Preference Learning v${UPL_VERSION} ═══${NC:-}"
    echo -e "  観測数             : ${UPL_TOTAL_OBSERVATIONS}"
    echo -e "  プロファイル完成度 : ${UPL_PROFILE_COMPLETENESS}%"
    echo -e "  スタイル信頼度     : ${UPL_STYLE_CONFIDENCE}%"
    echo -e "  嗜好項目数         : ${#_UPL_PREFERENCES[@]}"
}

_upl_score() {
    [[ "$UPL_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    local s=50
    [[ $UPL_TOTAL_OBSERVATIONS -gt 5 ]] && s=$((s + 15))
    [[ $UPL_PROFILE_COMPLETENESS -gt 60 ]] && s=$((s + 15))
    [[ $UPL_STYLE_CONFIDENCE -gt 50 ]] && s=$((s + 20))
    [[ $s -gt 100 ]] && s=100
    echo "$s"
}

_upl_init_message() {
    echo -e "  ${GREEN:-}✅ v${UPL_VERSION} user-preference-learning: ユーザー嗜好学習エンジン (${UPL_PROFILE_COMPLETENESS}% complete)${NC:-}" >&2
}

# =============================================================================
# Module Registry 登録
# =============================================================================
_mr_register \
    --name "user-preference-learning" \
    --version "$UPL_VERSION" \
    --description "ユーザー嗜好学習エンジン" \
    --init "_upl_init" \
    --report "_upl_report" \
    --score "_upl_score" \
    --enable-var "ENABLE_USER_PREFERENCE_LEARNING" \
    --cli-flags "--user-preference-learning:--no-user-preference-learning" \
    --init-msg "_upl_init_message"
