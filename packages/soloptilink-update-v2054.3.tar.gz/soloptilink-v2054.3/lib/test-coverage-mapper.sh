#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v215.0 - Test Coverage Mapper
# =============================================================================
# テストファイルとソースファイルの対応を解析し、
# カバレッジギャップの特定・優先順位付け・テストケース提案を行う
#
# 機能:
#   1. カバレッジマッピング (Coverage Mapping)
#   2. 未テスト検出 (Untested Detection)
#   3. テスト優先順位付け (Test Prioritization)
#   4. カバレッジ見積もり (Coverage Estimation)
#   5. テストケース提案 (Test Case Suggestion)
#
# 使用方法:
#   source lib/test-coverage-mapper.sh
#   _tcm_map_coverage "/path/to/project"
#   _tcm_find_untested "/path/to/project"
#   _tcm_prioritize_testing "/path/to/project"
#   _tcm_estimate_coverage "/path/to/project"
#   _tcm_suggest_test_cases "/path/to/project"
# =============================================================================

[[ -n "${_TEST_COVERAGE_MAPPER_LOADED:-}" ]] && return 0
_TEST_COVERAGE_MAPPER_LOADED=1

# ============================================================
# Constants
# ============================================================
TCM_VERSION="215.0"
TCM_MIN_COVERAGE_TARGET=80
ENABLE_TEST_COVERAGE_MAPPER="${ENABLE_TEST_COVERAGE_MAPPER:-true}"

# ============================================================
# Internal State
# ============================================================
declare -a _TCM_SOURCE_FILES=()
declare -a _TCM_TEST_FILES=()
declare -A _TCM_SOURCE_TO_TEST=()      # source_file → test_file (or empty)
declare -A _TCM_TEST_TO_SOURCE=()      # test_file → source_file
declare -A _TCM_SOURCE_FUNCTIONS=()    # source_file → comma-separated functions
declare -A _TCM_TESTED_FUNCTIONS=()    # source_file → comma-separated tested functions
declare -A _TCM_SOURCE_RISK=()         # source_file → risk level (high/medium/low)
declare -A _TCM_SOURCE_COMPLEXITY=()   # source_file → complexity score
_TCM_PROJECT_DIR=""
_TCM_TOTAL_SOURCE=0
_TCM_TOTAL_TESTS=0
_TCM_TESTED_COUNT=0
_TCM_UNTESTED_COUNT=0
_TCM_COVERAGE_PCT=0
_TCM_SCORE=50

# ============================================================
# Logging
# ============================================================
_tcm_log() {
    local level="$1" msg="$2"
    local timestamp
    timestamp="$(date '+%Y-%m-%d %H:%M:%S')"
    echo -e "  [TCM][${level}] ${msg}" >&2
    if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
        echo "[${timestamp}][TCM][${level}] ${msg}" >> "${SESSION_LOG_DIR}/test_coverage_mapper.log" 2>/dev/null || true
    fi
}

# ============================================================
# Utility: Find source files
# ============================================================
_tcm_find_source_files() {
    local dir="$1"
    find "$dir" \
        -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" -o -name "*.py" -o -name "*.sh" \) \
        ! -path "*/node_modules/*" \
        ! -path "*/.next/*" \
        ! -path "*/dist/*" \
        ! -path "*/build/*" \
        ! -name "*.test.*" \
        ! -name "*.spec.*" \
        ! -name "*.bats" \
        ! -path "*/__tests__/*" \
        ! -path "*/tests/*" \
        ! -path "*/.git/*" \
        ! -name "*.d.ts" \
        ! -name "jest.config.*" \
        ! -name "vitest.config.*" \
        2>/dev/null | sort
}

# ============================================================
# Utility: Find test files
# ============================================================
_tcm_find_test_files() {
    local dir="$1"
    find "$dir" \
        -type f \( \
            -name "*.test.ts" -o -name "*.test.tsx" -o \
            -name "*.test.js" -o -name "*.test.jsx" -o \
            -name "*.spec.ts" -o -name "*.spec.tsx" -o \
            -name "*.spec.js" -o -name "*.spec.jsx" -o \
            -name "*.bats" -o \
            -name "test_*.py" -o -name "*_test.py" -o \
            -name "test_*.sh" \
        \) \
        ! -path "*/node_modules/*" \
        ! -path "*/.next/*" \
        ! -path "*/dist/*" \
        ! -path "*/.git/*" \
        2>/dev/null | sort
}

# ============================================================
# Utility: Match test file to source file
# ============================================================
_tcm_match_test_to_source() {
    local test_file="$1"
    local project_dir="$2"

    local test_basename
    test_basename="$(basename "$test_file")"

    # Remove test suffixes to get source name
    local source_name
    source_name=$(echo "$test_basename" | sed \
        -e 's/\.test\.\(ts\|tsx\|js\|jsx\)$//' \
        -e 's/\.spec\.\(ts\|tsx\|js\|jsx\)$//' \
        -e 's/\.bats$//' \
        -e 's/^test_//' \
        -e 's/_test$//' \
        -e 's/_test\.py$//' \
        -e 's/^test_\(.*\)\.py$/\1/')

    # Search for matching source file
    for src in "${_TCM_SOURCE_FILES[@]}"; do
        local src_basename
        src_basename="$(basename "$src" | sed 's/\.\(ts\|tsx\|js\|jsx\|py\|sh\)$//')"

        if [[ "$src_basename" == "$source_name" ]]; then
            echo "$src"
            return 0
        fi
    done

    # Try fuzzy match (partial name match)
    for src in "${_TCM_SOURCE_FILES[@]}"; do
        local src_basename
        src_basename="$(basename "$src" | sed 's/\.\(ts\|tsx\|js\|jsx\|py\|sh\)$//')"

        # Convert to comparable form (lowercase, remove hyphens/underscores)
        local norm_src norm_test
        norm_src=$(echo "$src_basename" | tr '[:upper:]' '[:lower:]' | tr '-' '_')
        norm_test=$(echo "$source_name" | tr '[:upper:]' '[:lower:]' | tr '-' '_')

        if [[ "$norm_src" == *"$norm_test"* || "$norm_test" == *"$norm_src"* ]]; then
            echo "$src"
            return 0
        fi
    done

    echo ""
    return 1
}

# ============================================================
# Utility: Extract function names from source
# ============================================================
_tcm_extract_functions() {
    local file="$1"
    local funcs=""

    local content
    content=$(cat "$file" 2>/dev/null) || return

    local ext="${file##*.}"

    case "$ext" in
        ts|tsx|js|jsx)
            # Export functions/const
            local names
            names=$(echo "$content" | grep -oE 'export\s+(async\s+)?function\s+\w+|export\s+const\s+\w+|function\s+\w+' | \
                    grep -oE '\w+$' | sort -u)
            for name in $names; do
                [[ "$name" == "function" || "$name" == "async" || "$name" == "export" || "$name" == "const" ]] && continue
                if [[ -z "$funcs" ]]; then
                    funcs="$name"
                else
                    funcs="${funcs},${name}"
                fi
            done

            # Arrow functions assigned to variables
            local arrow_names
            arrow_names=$(echo "$content" | grep -oE 'const\s+\w+\s*=\s*(async\s+)?\(' | grep -oE 'const\s+\w+' | sed 's/const //' | sort -u)
            for name in $arrow_names; do
                if ! echo ",$funcs," | grep -q ",${name},"; then
                    if [[ -z "$funcs" ]]; then
                        funcs="$name"
                    else
                        funcs="${funcs},${name}"
                    fi
                fi
            done
            ;;
        py)
            local names
            names=$(echo "$content" | grep -oE 'def\s+\w+|class\s+\w+' | sed 's/def //;s/class //' | sort -u)
            for name in $names; do
                if [[ -z "$funcs" ]]; then
                    funcs="$name"
                else
                    funcs="${funcs},${name}"
                fi
            done
            ;;
        sh)
            local names
            names=$(echo "$content" | grep -oE '^\w+\s*\(\)' | sed 's/\s*()$//' | sort -u)
            for name in $names; do
                if [[ -z "$funcs" ]]; then
                    funcs="$name"
                else
                    funcs="${funcs},${name}"
                fi
            done
            ;;
    esac

    echo "$funcs"
}

# ============================================================
# Utility: Extract tested function names from test file
# ============================================================
_tcm_extract_tested_functions() {
    local test_file="$1"
    local tested=""

    local content
    content=$(cat "$test_file" 2>/dev/null) || return

    # Extract from describe/it/test blocks
    local described
    described=$(echo "$content" | grep -oE "(describe|it|test)\s*\(['\"][^'\"]*['\"]" | \
               sed "s/describe *(['\"]//;s/it *(['\"]//;s/test *(['\"]//;s/['\"]$//" | sort -u)

    for desc in $described; do
        # Try to extract function names from test descriptions
        local func_name
        func_name=$(echo "$desc" | grep -oE '\b[a-z][A-Za-z0-9_]+' | head -1)
        if [[ -n "$func_name" ]]; then
            if [[ -z "$tested" ]]; then
                tested="$func_name"
            else
                tested="${tested},${func_name}"
            fi
        fi
    done

    # Also check direct function calls in test
    local called
    called=$(echo "$content" | grep -oE '(expect\(|await)\s*\w+' | grep -oE '\w+$' | sort -u)
    for func in $called; do
        [[ "$func" == "expect" || "$func" == "await" || "$func" == "true" || "$func" == "false" ]] && continue
        if ! echo ",$tested," | grep -q ",${func},"; then
            if [[ -z "$tested" ]]; then
                tested="$func"
            else
                tested="${tested},${func}"
            fi
        fi
    done

    # Bats test: check @test descriptions
    if echo "$test_file" | grep -qE '\.bats$'; then
        local bats_tests
        bats_tests=$(echo "$content" | grep -oE '@test\s+"[^"]+"' | sed 's/@test "//;s/"$//')
        for desc in $bats_tests; do
            local func_name
            func_name=$(echo "$desc" | grep -oE '\b_?[a-z][a-z0-9_]+' | head -1)
            if [[ -n "$func_name" ]]; then
                if ! echo ",$tested," | grep -q ",${func_name},"; then
                    if [[ -z "$tested" ]]; then
                        tested="$func_name"
                    else
                        tested="${tested},${func_name}"
                    fi
                fi
            fi
        done
    fi

    echo "$tested"
}

# ============================================================
# Utility: Assess risk level of source file
# ============================================================
_tcm_assess_risk() {
    local file="$1"
    local content
    content=$(cat "$file" 2>/dev/null) || { echo "low"; return; }

    local risk_score=0

    # Security-related code = high risk
    if echo "$content" | grep -qE 'password|auth|jwt|token|secret|encrypt|decrypt|hash|bcrypt|argon'; then
        risk_score=$((risk_score + 30))
    fi

    # Database operations = high risk
    if echo "$content" | grep -qE 'prisma\.|\.query|\.exec|INSERT|UPDATE|DELETE|SELECT|\$transaction'; then
        risk_score=$((risk_score + 25))
    fi

    # Payment/financial = critical risk
    if echo "$content" | grep -qE 'payment|stripe|billing|invoice|charge|refund|subscription'; then
        risk_score=$((risk_score + 40))
    fi

    # User input handling = medium risk
    if echo "$content" | grep -qE 'req\.body|req\.params|req\.query|request\.json|FormData|zod\.'; then
        risk_score=$((risk_score + 15))
    fi

    # API endpoints = medium risk
    if echo "$content" | grep -qE 'export\s+(async\s+)?function\s+(GET|POST|PUT|DELETE)|app\.(get|post|put|delete)'; then
        risk_score=$((risk_score + 15))
    fi

    # File system operations = medium risk
    if echo "$content" | grep -qE 'fs\.|writeFile|readFile|unlink|mkdir|rmdir'; then
        risk_score=$((risk_score + 10))
    fi

    if [[ $risk_score -ge 40 ]]; then
        echo "high"
    elif [[ $risk_score -ge 15 ]]; then
        echo "medium"
    else
        echo "low"
    fi
}

# ============================================================
# Utility: Estimate complexity
# ============================================================
_tcm_estimate_complexity() {
    local file="$1"
    local content
    content=$(cat "$file" 2>/dev/null) || { echo "0"; return; }

    local complexity=0

    # Line count contributes to complexity
    local lines
    lines=$(wc -l < "$file" 2>/dev/null | tr -d ' ')
    lines="${lines:-0}"
    complexity=$((complexity + lines / 20))

    # Conditional branches
    local branches
    branches=$(echo "$content" | grep -cE 'if\s*\(|else\s*\{|case\s|switch\s*\(|\?\s*:' 2>/dev/null || echo "0")
    branches="${branches%%[!0-9]*}"
    complexity=$((complexity + ${branches:-0}))

    # Loop constructs
    local loops
    loops=$(echo "$content" | grep -cE 'for\s*\(|while\s*\(|\.forEach\(|\.map\(|\.reduce\(' 2>/dev/null || echo "0")
    loops="${loops%%[!0-9]*}"
    complexity=$((complexity + ${loops:-0}))

    # Try-catch blocks
    local try_catch
    try_catch=$(echo "$content" | grep -cE 'try\s*\{|catch\s*\(' 2>/dev/null || echo "0")
    try_catch="${try_catch%%[!0-9]*}"
    complexity=$((complexity + ${try_catch:-0}))

    echo "$complexity"
}

# ============================================================
# 1. Map Coverage
# ============================================================
_tcm_map_coverage() {
    local project_dir="${1:-.}"
    _TCM_PROJECT_DIR="$project_dir"

    _tcm_log "INFO" "テストカバレッジマッピング開始: ${project_dir}"

    # Reset state
    _TCM_SOURCE_FILES=()
    _TCM_TEST_FILES=()
    _TCM_SOURCE_TO_TEST=()
    _TCM_TEST_TO_SOURCE=()
    _TCM_SOURCE_FUNCTIONS=()
    _TCM_TESTED_FUNCTIONS=()
    _TCM_SOURCE_RISK=()
    _TCM_SOURCE_COMPLEXITY=()
    _TCM_TOTAL_SOURCE=0
    _TCM_TOTAL_TESTS=0
    _TCM_TESTED_COUNT=0
    _TCM_UNTESTED_COUNT=0

    # Collect source files
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        _TCM_SOURCE_FILES+=("$file")
        _TCM_TOTAL_SOURCE=$((_TCM_TOTAL_SOURCE + 1))
    done < <(_tcm_find_source_files "$project_dir")

    # Collect test files
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        _TCM_TEST_FILES+=("$file")
        _TCM_TOTAL_TESTS=$((_TCM_TOTAL_TESTS + 1))
    done < <(_tcm_find_test_files "$project_dir")

    _tcm_log "INFO" "ソースファイル: ${_TCM_TOTAL_SOURCE}, テストファイル: ${_TCM_TOTAL_TESTS}"

    # Match tests to sources
    for test_file in "${_TCM_TEST_FILES[@]}"; do
        local matched_source
        matched_source=$(_tcm_match_test_to_source "$test_file" "$project_dir")
        if [[ -n "$matched_source" ]]; then
            _TCM_TEST_TO_SOURCE["$test_file"]="$matched_source"
            _TCM_SOURCE_TO_TEST["$matched_source"]="$test_file"
        fi
    done

    # Extract functions and assess risk
    for src in "${_TCM_SOURCE_FILES[@]}"; do
        _TCM_SOURCE_FUNCTIONS["$src"]=$(_tcm_extract_functions "$src")
        _TCM_SOURCE_RISK["$src"]=$(_tcm_assess_risk "$src")
        _TCM_SOURCE_COMPLEXITY["$src"]=$(_tcm_estimate_complexity "$src")

        local test_file="${_TCM_SOURCE_TO_TEST[$src]:-}"
        if [[ -n "$test_file" ]]; then
            _TCM_TESTED_FUNCTIONS["$src"]=$(_tcm_extract_tested_functions "$test_file")
            _TCM_TESTED_COUNT=$((_TCM_TESTED_COUNT + 1))
        else
            _TCM_UNTESTED_COUNT=$((_TCM_UNTESTED_COUNT + 1))
        fi
    done

    _tcm_log "INFO" "マッピング完了: tested=${_TCM_TESTED_COUNT}, untested=${_TCM_UNTESTED_COUNT}"

    # Output coverage map
    local output_file="${SESSION_LOG_DIR:-/tmp}/coverage_map.txt"
    {
        echo "============================================="
        echo " Test Coverage Map (v${TCM_VERSION})"
        echo " Project: ${project_dir}"
        echo " Source Files: ${_TCM_TOTAL_SOURCE}"
        echo " Test Files: ${_TCM_TOTAL_TESTS}"
        echo " Tested: ${_TCM_TESTED_COUNT}"
        echo " Untested: ${_TCM_UNTESTED_COUNT}"
        echo "============================================="
        echo ""

        echo "--- Tested Files ---"
        for src in "${_TCM_SOURCE_FILES[@]}"; do
            local test="${_TCM_SOURCE_TO_TEST[$src]:-}"
            [[ -z "$test" ]] && continue
            local rel_src="${src#${project_dir}/}"
            local rel_test="${test#${project_dir}/}"
            local risk="${_TCM_SOURCE_RISK[$src]:-low}"
            echo "  [TESTED] ${rel_src}"
            echo "    Test: ${rel_test}"
            echo "    Risk: ${risk}"
        done

        echo ""
        echo "--- Untested Files ---"
        for src in "${_TCM_SOURCE_FILES[@]}"; do
            local test="${_TCM_SOURCE_TO_TEST[$src]:-}"
            [[ -n "$test" ]] && continue
            local rel_src="${src#${project_dir}/}"
            local risk="${_TCM_SOURCE_RISK[$src]:-low}"
            echo "  [UNTESTED] ${rel_src} (risk: ${risk})"
        done
    } > "$output_file" 2>/dev/null

    return 0
}

# ============================================================
# 2. Find Untested Functions/Components
# ============================================================
_tcm_find_untested() {
    local project_dir="${1:-.}"

    if [[ ${_TCM_TOTAL_SOURCE} -eq 0 ]]; then
        _tcm_map_coverage "$project_dir"
    fi

    _tcm_log "INFO" "未テスト関数/コンポーネント検出開始"

    local output_file="${SESSION_LOG_DIR:-/tmp}/untested_functions.txt"
    local total_untested_funcs=0

    {
        echo "============================================="
        echo " Untested Functions & Components"
        echo "============================================="
        echo ""

        for src in "${_TCM_SOURCE_FILES[@]}"; do
            local all_funcs="${_TCM_SOURCE_FUNCTIONS[$src]:-}"
            [[ -z "$all_funcs" ]] && continue

            local tested_funcs="${_TCM_TESTED_FUNCTIONS[$src]:-}"
            local rel_src="${src#${project_dir}/}"
            local risk="${_TCM_SOURCE_RISK[$src]:-low}"

            # If no test file at all, all functions are untested
            local test_file="${_TCM_SOURCE_TO_TEST[$src]:-}"
            if [[ -z "$test_file" ]]; then
                IFS=',' read -ra func_arr <<< "$all_funcs"
                echo "  [${rel_src}] (risk: ${risk}) - ALL UNTESTED"
                for func in "${func_arr[@]}"; do
                    echo "    - ${func}"
                    total_untested_funcs=$((total_untested_funcs + 1))
                done
                echo ""
                continue
            fi

            # Compare all functions vs tested functions
            IFS=',' read -ra func_arr <<< "$all_funcs"
            local file_untested=()
            for func in "${func_arr[@]}"; do
                [[ -z "$func" ]] && continue
                if ! echo ",$tested_funcs," | grep -qi ",${func},"; then
                    file_untested+=("$func")
                    total_untested_funcs=$((total_untested_funcs + 1))
                fi
            done

            if [[ ${#file_untested[@]} -gt 0 ]]; then
                echo "  [${rel_src}] (risk: ${risk}) - ${#file_untested[@]} untested functions"
                for func in "${file_untested[@]}"; do
                    echo "    - ${func}"
                done
                echo ""
            fi
        done

        echo "--- 統計 ---"
        echo "  未テスト関数/コンポーネント: ${total_untested_funcs}"
    } > "$output_file" 2>/dev/null

    _tcm_log "INFO" "未テスト関数: ${total_untested_funcs} 件"
    return 0
}

# ============================================================
# 3. Prioritize Testing
# ============================================================
_tcm_prioritize_testing() {
    local project_dir="${1:-.}"

    if [[ ${_TCM_TOTAL_SOURCE} -eq 0 ]]; then
        _tcm_map_coverage "$project_dir"
    fi

    _tcm_log "INFO" "テスト優先順位付け開始"

    local output_file="${SESSION_LOG_DIR:-/tmp}/test_priorities.txt"

    # Build priority list: score = risk_weight * complexity * (1 - coverage_ratio)
    declare -a _priorities=()

    for src in "${_TCM_SOURCE_FILES[@]}"; do
        local risk="${_TCM_SOURCE_RISK[$src]:-low}"
        local complexity="${_TCM_SOURCE_COMPLEXITY[$src]:-0}"
        local test="${_TCM_SOURCE_TO_TEST[$src]:-}"

        local risk_weight=1
        case "$risk" in
            high)   risk_weight=3 ;;
            medium) risk_weight=2 ;;
            low)    risk_weight=1 ;;
        esac

        local coverage_factor=1
        if [[ -n "$test" ]]; then
            # Has test, lower priority
            local all_funcs="${_TCM_SOURCE_FUNCTIONS[$src]:-}"
            local tested_funcs="${_TCM_TESTED_FUNCTIONS[$src]:-}"
            if [[ -n "$all_funcs" ]]; then
                IFS=',' read -ra all_arr <<< "$all_funcs"
                local total_f=${#all_arr[@]}
                local tested_f=0
                for f in "${all_arr[@]}"; do
                    if echo ",$tested_funcs," | grep -qi ",${f},"; then
                        tested_f=$((tested_f + 1))
                    fi
                done
                if [[ $total_f -gt 0 ]]; then
                    coverage_factor=$(( (total_f - tested_f) * 10 / total_f ))
                else
                    coverage_factor=0
                fi
            fi
        else
            coverage_factor=10  # No test = max uncoverage
        fi

        local priority_score=$(( risk_weight * (complexity + 1) * coverage_factor ))
        _priorities+=("${priority_score}|${risk}|${complexity}|${src}")
    done

    # Sort by priority score descending
    IFS=$'\n' _priorities=($(sort -t'|' -k1 -nr <<< "${_priorities[*]}")); unset IFS

    {
        echo "============================================="
        echo " Test Priority List"
        echo " (Higher score = More urgent to test)"
        echo "============================================="
        echo ""

        local rank=1
        for entry in "${_priorities[@]}"; do
            [[ $rank -gt 30 ]] && break  # Top 30

            IFS='|' read -r score risk complexity file <<< "$entry"
            local rel_file="${file#${project_dir}/}"
            local test="${_TCM_SOURCE_TO_TEST[$file]:-}"
            local status="NO TEST"
            [[ -n "$test" ]] && status="PARTIAL"

            printf "  #%-3d [Score: %-4s] %-50s\n" "$rank" "$score" "$rel_file"
            echo "       Risk: ${risk} | Complexity: ${complexity} | Status: ${status}"

            rank=$((rank + 1))
        done

        echo ""
        echo "  Total ranked: ${#_priorities[@]} files"
    } > "$output_file" 2>/dev/null

    _tcm_log "INFO" "テスト優先順位付け完了"
    return 0
}

# ============================================================
# 4. Estimate Coverage
# ============================================================
_tcm_estimate_coverage() {
    local project_dir="${1:-.}"

    if [[ ${_TCM_TOTAL_SOURCE} -eq 0 ]]; then
        _tcm_map_coverage "$project_dir"
    fi

    _tcm_log "INFO" "カバレッジ見積もり開始"

    # File-level coverage
    local file_coverage=0
    if [[ $_TCM_TOTAL_SOURCE -gt 0 ]]; then
        file_coverage=$(( (_TCM_TESTED_COUNT * 100) / _TCM_TOTAL_SOURCE ))
    fi

    # Function-level coverage
    local total_funcs=0
    local tested_funcs=0

    for src in "${_TCM_SOURCE_FILES[@]}"; do
        local all_funcs="${_TCM_SOURCE_FUNCTIONS[$src]:-}"
        [[ -z "$all_funcs" ]] && continue

        IFS=',' read -ra arr <<< "$all_funcs"
        total_funcs=$((total_funcs + ${#arr[@]}))

        local tested="${_TCM_TESTED_FUNCTIONS[$src]:-}"
        if [[ -n "$tested" ]]; then
            for f in "${arr[@]}"; do
                if echo ",$tested," | grep -qi ",${f},"; then
                    tested_funcs=$((tested_funcs + 1))
                fi
            done
        fi
    done

    local func_coverage=0
    if [[ $total_funcs -gt 0 ]]; then
        func_coverage=$(( (tested_funcs * 100) / total_funcs ))
    fi

    # Risk-weighted coverage
    local risk_total=0
    local risk_tested=0
    for src in "${_TCM_SOURCE_FILES[@]}"; do
        local risk="${_TCM_SOURCE_RISK[$src]:-low}"
        local weight=1
        case "$risk" in
            high)   weight=3 ;;
            medium) weight=2 ;;
            low)    weight=1 ;;
        esac
        risk_total=$((risk_total + weight))

        local test="${_TCM_SOURCE_TO_TEST[$src]:-}"
        if [[ -n "$test" ]]; then
            risk_tested=$((risk_tested + weight))
        fi
    done

    local risk_coverage=0
    if [[ $risk_total -gt 0 ]]; then
        risk_coverage=$(( (risk_tested * 100) / risk_total ))
    fi

    _TCM_COVERAGE_PCT=$func_coverage

    local output_file="${SESSION_LOG_DIR:-/tmp}/coverage_estimate.txt"

    {
        echo "============================================="
        echo " Coverage Estimation (v${TCM_VERSION})"
        echo "============================================="
        echo ""
        echo "  File-Level Coverage:     ${file_coverage}%  (${_TCM_TESTED_COUNT}/${_TCM_TOTAL_SOURCE})"
        echo "  Function-Level Coverage: ${func_coverage}%  (${tested_funcs}/${total_funcs})"
        echo "  Risk-Weighted Coverage:  ${risk_coverage}%"
        echo ""
        echo "  Target Coverage: ${TCM_MIN_COVERAGE_TARGET}%"
        echo ""

        if [[ $func_coverage -ge $TCM_MIN_COVERAGE_TARGET ]]; then
            echo "  Status: PASS - カバレッジ目標達成"
        elif [[ $func_coverage -ge 60 ]]; then
            echo "  Status: WARN - カバレッジ目標未達 (${func_coverage}% < ${TCM_MIN_COVERAGE_TARGET}%)"
        else
            echo "  Status: FAIL - カバレッジ不足 (${func_coverage}% < ${TCM_MIN_COVERAGE_TARGET}%)"
        fi

        echo ""
        echo "  --- Risk Breakdown ---"
        local high_total=0 high_tested=0
        local medium_total=0 medium_tested=0
        local low_total=0 low_tested=0

        for src in "${_TCM_SOURCE_FILES[@]}"; do
            local risk="${_TCM_SOURCE_RISK[$src]:-low}"
            local test="${_TCM_SOURCE_TO_TEST[$src]:-}"
            case "$risk" in
                high)
                    high_total=$((high_total + 1))
                    [[ -n "$test" ]] && high_tested=$((high_tested + 1))
                    ;;
                medium)
                    medium_total=$((medium_total + 1))
                    [[ -n "$test" ]] && medium_tested=$((medium_tested + 1))
                    ;;
                low)
                    low_total=$((low_total + 1))
                    [[ -n "$test" ]] && low_tested=$((low_tested + 1))
                    ;;
            esac
        done

        echo "  High Risk:   ${high_tested}/${high_total} tested"
        echo "  Medium Risk: ${medium_tested}/${medium_total} tested"
        echo "  Low Risk:    ${low_tested}/${low_total} tested"
    } > "$output_file" 2>/dev/null

    _tcm_log "INFO" "カバレッジ推定: file=${file_coverage}%, func=${func_coverage}%, risk=${risk_coverage}%"

    echo "$func_coverage"
    return 0
}

# ============================================================
# 5. Suggest Test Cases
# ============================================================
_tcm_suggest_test_cases() {
    local project_dir="${1:-.}"

    if [[ ${_TCM_TOTAL_SOURCE} -eq 0 ]]; then
        _tcm_map_coverage "$project_dir"
    fi

    _tcm_log "INFO" "テストケース提案開始"

    local output_file="${SESSION_LOG_DIR:-/tmp}/test_suggestions.txt"

    {
        echo "============================================="
        echo " Test Case Suggestions"
        echo "============================================="
        echo ""

        for src in "${_TCM_SOURCE_FILES[@]}"; do
            local all_funcs="${_TCM_SOURCE_FUNCTIONS[$src]:-}"
            [[ -z "$all_funcs" ]] && continue

            local tested="${_TCM_TESTED_FUNCTIONS[$src]:-}"
            local risk="${_TCM_SOURCE_RISK[$src]:-low}"
            local rel_src="${src#${project_dir}/}"

            # Only suggest for untested or partially tested high/medium risk
            local test_file="${_TCM_SOURCE_TO_TEST[$src]:-}"
            if [[ -n "$test_file" && "$risk" == "low" ]]; then
                continue
            fi

            local untested_funcs=()
            IFS=',' read -ra func_arr <<< "$all_funcs"
            for func in "${func_arr[@]}"; do
                [[ -z "$func" ]] && continue
                if ! echo ",$tested," | grep -qi ",${func},"; then
                    untested_funcs+=("$func")
                fi
            done

            [[ ${#untested_funcs[@]} -eq 0 ]] && continue

            echo "  === ${rel_src} (risk: ${risk}) ==="
            echo ""

            # Read file content for context-aware suggestions
            local content
            content=$(cat "$src" 2>/dev/null) || continue

            for func in "${untested_funcs[@]}"; do
                echo "  Function: ${func}"

                # Determine test type based on content analysis
                local func_content
                func_content=$(echo "$content" | grep -A 30 -E "(function|const)\s+${func}" | head -30)

                # API handler test
                if echo "$func_content" | grep -qE 'req|res|NextRequest|NextResponse|Response'; then
                    echo "    Suggested Tests:"
                    echo "      - ${func}: 正常リクエストで200レスポンスを返すこと"
                    echo "      - ${func}: 不正入力で400エラーを返すこと"
                    echo "      - ${func}: 認証なしで401エラーを返すこと"
                    echo "      - ${func}: 存在しないリソースで404エラーを返すこと"
                fi

                # DB operation test
                if echo "$func_content" | grep -qE 'prisma\.|\.create|\.update|\.delete|\.find'; then
                    echo "    Suggested Tests:"
                    echo "      - ${func}: レコードの作成/取得が正しく動作すること"
                    echo "      - ${func}: 存在しないIDでnullまたはエラーを返すこと"
                    echo "      - ${func}: 重複データでユニーク制約エラーを返すこと"
                    echo "      - ${func}: トランザクション失敗時にロールバックすること"
                fi

                # Validation test
                if echo "$func_content" | grep -qE 'zod|validate|schema|parse'; then
                    echo "    Suggested Tests:"
                    echo "      - ${func}: 有効な入力を受け入れること"
                    echo "      - ${func}: 無効な入力を拒否すること"
                    echo "      - ${func}: 境界値で正しく動作すること"
                    echo "      - ${func}: 必須フィールド欠落時にエラーを返すこと"
                fi

                # Auth test
                if echo "$func_content" | grep -qE 'auth|login|password|token|jwt|session'; then
                    echo "    Suggested Tests:"
                    echo "      - ${func}: 正しい認証情報でログイン成功すること"
                    echo "      - ${func}: 不正な認証情報でログイン失敗すること"
                    echo "      - ${func}: トークン期限切れで401を返すこと"
                    echo "      - ${func}: ロール不足で403を返すこと"
                fi

                # Generic fallback
                if ! echo "$func_content" | grep -qE 'req|res|prisma|zod|auth|login|password'; then
                    echo "    Suggested Tests:"
                    echo "      - ${func}: 正常入力で期待結果を返すこと"
                    echo "      - ${func}: エッジケース入力で正しく処理すること"
                    echo "      - ${func}: エラー時に適切な例外を投げること"
                fi

                echo ""
            done
        done
    } > "$output_file" 2>/dev/null

    _tcm_log "INFO" "テストケース提案完了: ${output_file}"
    return 0
}

# ============================================================
# Module Interface: Init / Report / Score
# ============================================================
_tcm_init() {
    _tcm_log "INFO" "Test Coverage Mapper v${TCM_VERSION} 初期化"
    return 0
}

_tcm_init_message() {
    echo -e "  ${GREEN:-}v${TCM_VERSION} Test Coverage Mapper: テストカバレッジマッピング・ギャップ分析${NC:-}" >&2
}

_tcm_report() {
    echo -e "\n  ${BOLD:-}--- Test Coverage Mapper v${TCM_VERSION} ---${NC:-}"
    echo -e "  Source Files      : ${_TCM_TOTAL_SOURCE}"
    echo -e "  Test Files        : ${_TCM_TOTAL_TESTS}"
    echo -e "  Tested            : ${_TCM_TESTED_COUNT}"
    echo -e "  Untested          : ${_TCM_UNTESTED_COUNT}"
    echo -e "  Coverage (est.)   : ${_TCM_COVERAGE_PCT}%"
    echo -e "  Score             : ${_TCM_SCORE}/100"
}

_tcm_score() {
    local score=50

    if [[ $_TCM_TOTAL_SOURCE -gt 0 ]]; then
        local file_cov=$(( (_TCM_TESTED_COUNT * 100) / _TCM_TOTAL_SOURCE ))
        score=$file_cov
    fi

    # Bonus for high coverage
    if [[ $score -ge 90 ]]; then
        score=100
    elif [[ $score -ge 80 ]]; then
        score=$((score + 5))
    fi

    # Penalty if high-risk files are untested
    for src in "${_TCM_SOURCE_FILES[@]}"; do
        local risk="${_TCM_SOURCE_RISK[$src]:-low}"
        local test="${_TCM_SOURCE_TO_TEST[$src]:-}"
        if [[ "$risk" == "high" && -z "$test" ]]; then
            score=$((score - 10))
        fi
    done

    [[ $score -lt 0 ]] && score=0
    [[ $score -gt 100 ]] && score=100

    _TCM_SCORE=$score
    echo "$score"
}

# ============================================================
# Run all analyses
# ============================================================
_tcm_run_all() {
    local project_dir="${1:-.}"

    _tcm_map_coverage "$project_dir"
    _tcm_find_untested "$project_dir"
    _tcm_prioritize_testing "$project_dir"
    _tcm_estimate_coverage "$project_dir"
    _tcm_suggest_test_cases "$project_dir"
    _tcm_score

    _tcm_report
}

# ============================================================
# Module Registry Registration
# ============================================================
_mr_register \
    --name "test-coverage-mapper" \
    --version "215.0" \
    --description "テストカバレッジマッピング・ギャップ分析・優先順位付け・テストケース提案" \
    --init "_tcm_init" \
    --report "_tcm_report" \
    --score "_tcm_score" \
    --enable-var "ENABLE_TEST_COVERAGE_MAPPER" \
    --cli-flags "--coverage-mapper:--no-coverage-mapper" \
    --init-msg "_tcm_init_message"
