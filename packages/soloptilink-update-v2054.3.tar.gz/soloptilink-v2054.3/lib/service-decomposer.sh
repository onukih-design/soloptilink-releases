#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v282.0 - Service Decomposer
# =============================================================================
# ドメイン分析に基づくサービス分割エンジン。境界づけられたコンテキストの特定、
# サービス分割戦略の提案、サービス間インターフェース契約の自動生成を行う。
#
# 機能一覧:
#   _sd_analyze_domains      - 境界づけられたコンテキストの特定
#   _sd_suggest_services     - サービス分割戦略の提案
#   _sd_generate_interfaces  - サービス間インターフェース契約生成
#   _sd_inject_patterns      - Claudeプロンプトへのパターン注入
#
# 全globals: SD_ prefix
# =============================================================================

[[ -n "${_SD_LOADED:-}" ]] && return 0; _SD_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g SD_VERSION="282.0"
declare -g SD_GENERATED=0
declare -g SD_ERRORS=0
declare -g SD_FILES_WRITTEN=0
declare -g SD_DOMAINS_FOUND=0

# =============================================================================
# 初期化
# =============================================================================
sd_init() {
    SD_GENERATED=0
    SD_ERRORS=0
    SD_FILES_WRITTEN=0
    SD_DOMAINS_FOUND=0
    return 0
}

# =============================================================================
# ユーティリティ
# =============================================================================
_sd_write_file() {
    local filepath="$1"
    local content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then
        SD_FILES_WRITTEN=$((SD_FILES_WRITTEN + 1))
        echo "  [sd] wrote: $filepath" >&2
    else
        SD_ERRORS=$((SD_ERRORS + 1))
    fi
}

_sd_log() {
    echo -e "  ${GREEN:-\033[0;32m}[SD]${NC:-\033[0m} $*" >&2
}

# =============================================================================
# _sd_analyze_domains - 境界づけられたコンテキストの特定
# =============================================================================
_sd_analyze_domains() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local project_desc="${2:-}"

    _sd_log "Analyzing domain boundaries..."

    # Prismaスキーマからモデルを抽出
    local schema_file="${project_dir}/prisma/schema.prisma"
    local models=()
    local relations=()

    if [[ -f "$schema_file" ]]; then
        while IFS= read -r line; do
            if [[ "$line" =~ ^model[[:space:]]+([A-Z][a-zA-Z]+) ]]; then
                models+=("${BASH_REMATCH[1]}")
            fi
        done < "$schema_file"

        # リレーション分析
        while IFS= read -r line; do
            if [[ "$line" =~ @relation ]]; then
                relations+=("$line")
            fi
        done < "$schema_file"
    fi

    SD_DOMAINS_FOUND=${#models[@]}
    _sd_log "Found ${SD_DOMAINS_FOUND} models, ${#relations[@]} relations"

    # ドメイン分析結果生成
    local analysis_ts
    analysis_ts=$(cat <<'ANALYSISEOF'
// =============================================================================
// Domain Analysis Result
// Auto-generated bounded context identification
// =============================================================================

export interface BoundedContext {
  name: string;
  description: string;
  aggregateRoots: string[];
  entities: string[];
  valueObjects: string[];
  domainEvents: string[];
  externalDependencies: string[];
}

export interface DomainAnalysis {
  contexts: BoundedContext[];
  contextMap: Array<{
    upstream: string;
    downstream: string;
    relationship: 'customer-supplier' | 'conformist' | 'anticorruption-layer' | 'shared-kernel' | 'open-host';
  }>;
}

export const domainAnalysis: DomainAnalysis = {
  contexts: [
    {
      name: 'identity',
      description: 'User identity, authentication, authorization',
      aggregateRoots: ['User'],
      entities: ['UserProfile', 'Session', 'Role', 'Permission'],
      valueObjects: ['Email', 'PasswordHash', 'UserId'],
      domainEvents: ['UserRegistered', 'UserLoggedIn', 'PasswordChanged', 'RoleAssigned'],
      externalDependencies: [],
    },
    {
      name: 'catalog',
      description: 'Product catalog, categories, search',
      aggregateRoots: ['Product'],
      entities: ['Category', 'ProductVariant', 'ProductImage'],
      valueObjects: ['Price', 'SKU', 'ProductId'],
      domainEvents: ['ProductCreated', 'ProductUpdated', 'PriceChanged', 'StockUpdated'],
      externalDependencies: [],
    },
    {
      name: 'ordering',
      description: 'Order processing, cart management',
      aggregateRoots: ['Order'],
      entities: ['OrderItem', 'Cart', 'CartItem'],
      valueObjects: ['OrderId', 'OrderStatus', 'ShippingAddress'],
      domainEvents: ['OrderPlaced', 'OrderConfirmed', 'OrderShipped', 'OrderDelivered', 'OrderCancelled'],
      externalDependencies: ['identity', 'catalog', 'billing'],
    },
    {
      name: 'billing',
      description: 'Payments, invoices, subscriptions',
      aggregateRoots: ['Payment'],
      entities: ['Invoice', 'Subscription', 'Refund'],
      valueObjects: ['PaymentId', 'Amount', 'Currency'],
      domainEvents: ['PaymentProcessed', 'PaymentFailed', 'InvoiceGenerated', 'RefundIssued'],
      externalDependencies: ['identity', 'ordering'],
    },
    {
      name: 'notification',
      description: 'Email, push, in-app notifications',
      aggregateRoots: ['Notification'],
      entities: ['NotificationTemplate', 'NotificationPreference'],
      valueObjects: ['NotificationChannel', 'NotificationId'],
      domainEvents: ['NotificationSent', 'NotificationFailed', 'PreferenceUpdated'],
      externalDependencies: ['identity'],
    },
  ],
  contextMap: [
    { upstream: 'identity', downstream: 'ordering', relationship: 'customer-supplier' },
    { upstream: 'catalog', downstream: 'ordering', relationship: 'customer-supplier' },
    { upstream: 'ordering', downstream: 'billing', relationship: 'customer-supplier' },
    { upstream: 'identity', downstream: 'notification', relationship: 'open-host' },
    { upstream: 'ordering', downstream: 'notification', relationship: 'conformist' },
    { upstream: 'billing', downstream: 'notification', relationship: 'conformist' },
  ],
};

export function getContext(name: string): BoundedContext | undefined {
  return domainAnalysis.contexts.find((c) => c.name === name);
}

export function getUpstreamDependencies(contextName: string): string[] {
  return domainAnalysis.contextMap
    .filter((m) => m.downstream === contextName)
    .map((m) => m.upstream);
}

export function getDownstreamDependents(contextName: string): string[] {
  return domainAnalysis.contextMap
    .filter((m) => m.upstream === contextName)
    .map((m) => m.downstream);
}
ANALYSISEOF
)
    _sd_write_file "${project_dir}/src/architecture/domain-analysis.ts" "$analysis_ts"
    SD_GENERATED=$((SD_GENERATED + 1))
    return 0
}

# =============================================================================
# _sd_suggest_services - サービス分割戦略の提案
# =============================================================================
_sd_suggest_services() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _sd_log "Generating service decomposition strategy..."

    local strategy_ts
    strategy_ts=$(cat <<'STRATEOF'
// =============================================================================
// Service Decomposition Strategy
// Defines how to split a monolith into services, ordered by priority.
// =============================================================================

export interface ServiceDefinition {
  name: string;
  boundedContext: string;
  port: number;
  priority: 'high' | 'medium' | 'low';
  rationale: string;
  ownedModels: string[];
  apis: string[];
  dependencies: string[];
  splitComplexity: 'low' | 'medium' | 'high';
}

export const decompositionPlan: ServiceDefinition[] = [
  {
    name: 'identity-service',
    boundedContext: 'identity',
    port: 3001,
    priority: 'high',
    rationale: 'Auth is cross-cutting; extracting reduces coupling for all other services',
    ownedModels: ['User', 'Session', 'Role', 'Permission'],
    apis: ['/api/auth/login', '/api/auth/register', '/api/auth/refresh', '/api/users'],
    dependencies: [],
    splitComplexity: 'medium',
  },
  {
    name: 'catalog-service',
    boundedContext: 'catalog',
    port: 3002,
    priority: 'medium',
    rationale: 'Read-heavy workload; benefits from independent scaling',
    ownedModels: ['Product', 'Category', 'ProductVariant'],
    apis: ['/api/products', '/api/categories', '/api/search'],
    dependencies: ['identity-service'],
    splitComplexity: 'low',
  },
  {
    name: 'order-service',
    boundedContext: 'ordering',
    port: 3003,
    priority: 'medium',
    rationale: 'Core business logic with complex state machine',
    ownedModels: ['Order', 'OrderItem', 'Cart'],
    apis: ['/api/orders', '/api/cart'],
    dependencies: ['identity-service', 'catalog-service', 'billing-service'],
    splitComplexity: 'high',
  },
  {
    name: 'billing-service',
    boundedContext: 'billing',
    port: 3004,
    priority: 'high',
    rationale: 'Payment processing requires PCI compliance isolation',
    ownedModels: ['Payment', 'Invoice', 'Subscription'],
    apis: ['/api/payments', '/api/invoices', '/api/subscriptions'],
    dependencies: ['identity-service'],
    splitComplexity: 'medium',
  },
  {
    name: 'notification-service',
    boundedContext: 'notification',
    port: 3005,
    priority: 'low',
    rationale: 'Asynchronous workload, easy to extract',
    ownedModels: ['Notification', 'NotificationTemplate'],
    apis: ['/api/notifications'],
    dependencies: ['identity-service'],
    splitComplexity: 'low',
  },
];

export function getDecompositionOrder(): ServiceDefinition[] {
  const priorityOrder = { high: 0, medium: 1, low: 2 };
  return [...decompositionPlan].sort(
    (a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]
  );
}

export function estimateEffort(service: ServiceDefinition): {
  days: number;
  tasks: string[];
} {
  const baseDays = { low: 3, medium: 7, high: 14 };
  const days = baseDays[service.splitComplexity] + service.dependencies.length * 2;
  const tasks = [
    `Extract ${service.ownedModels.join(', ')} models to separate schema`,
    `Create ${service.name} API endpoints`,
    `Implement service-to-service communication for ${service.dependencies.length} dependencies`,
    `Migrate data from monolith DB`,
    `Set up health checks and monitoring`,
    `Integration testing with dependent services`,
  ];
  return { days, tasks };
}
STRATEOF
)
    _sd_write_file "${project_dir}/src/architecture/decomposition-strategy.ts" "$strategy_ts"
    SD_GENERATED=$((SD_GENERATED + 1))
    return 0
}

# =============================================================================
# _sd_generate_interfaces - サービス間インターフェース契約生成
# =============================================================================
_sd_generate_interfaces() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _sd_log "Generating service interface contracts..."

    local contracts_ts
    contracts_ts=$(cat <<'CONTRACTEOF'
// =============================================================================
// Service Interface Contracts
// Type-safe contracts for inter-service communication.
// Each service exposes a contract; consumers import only the contract types.
// =============================================================================
import { z } from 'zod';

// --- Identity Service Contract ---
export const IdentityServiceContract = {
  name: 'identity-service',
  baseUrl: process.env.IDENTITY_SERVICE_URL || 'http://localhost:3001',
  endpoints: {
    validateToken: {
      method: 'POST' as const,
      path: '/api/auth/validate',
      request: z.object({ token: z.string() }),
      response: z.object({
        valid: z.boolean(),
        userId: z.string().optional(),
        role: z.string().optional(),
      }),
    },
    getUser: {
      method: 'GET' as const,
      path: '/api/users/:id',
      request: z.object({ id: z.string() }),
      response: z.object({
        id: z.string(),
        email: z.string(),
        name: z.string(),
        role: z.string(),
      }),
    },
  },
} as const;

// --- Catalog Service Contract ---
export const CatalogServiceContract = {
  name: 'catalog-service',
  baseUrl: process.env.CATALOG_SERVICE_URL || 'http://localhost:3002',
  endpoints: {
    getProduct: {
      method: 'GET' as const,
      path: '/api/products/:id',
      request: z.object({ id: z.string() }),
      response: z.object({
        id: z.string(),
        name: z.string(),
        price: z.number(),
        stock: z.number(),
      }),
    },
    reserveStock: {
      method: 'POST' as const,
      path: '/api/products/:id/reserve',
      request: z.object({ id: z.string(), quantity: z.number().min(1) }),
      response: z.object({ reserved: z.boolean(), reservationId: z.string().optional() }),
    },
  },
} as const;

// --- Service Client Factory ---
export async function callService<T>(
  baseUrl: string,
  method: string,
  path: string,
  params?: Record<string, string>,
  body?: unknown,
): Promise<T> {
  let resolvedPath = path;
  if (params) {
    for (const [key, value] of Object.entries(params)) {
      resolvedPath = resolvedPath.replace(`:${key}`, value);
    }
  }

  const url = `${baseUrl}${resolvedPath}`;
  const options: RequestInit = {
    method,
    headers: {
      'Content-Type': 'application/json',
      'X-Service-Name': process.env.SERVICE_NAME || 'unknown',
      'X-Request-Id': crypto.randomUUID(),
    },
  };

  if (body && method !== 'GET') {
    options.body = JSON.stringify(body);
  }

  const response = await fetch(url, options);
  if (!response.ok) {
    throw new Error(`Service call failed: ${method} ${url} -> ${response.status}`);
  }
  return response.json() as Promise<T>;
}
CONTRACTEOF
)
    _sd_write_file "${project_dir}/src/architecture/service-contracts.ts" "$contracts_ts"
    SD_GENERATED=$((SD_GENERATED + 1))
    return 0
}

# =============================================================================
# _sd_inject_patterns - Claudeプロンプトへのパターン注入
# =============================================================================
_sd_inject_patterns() {
    local prompt="${1:-}"
    cat <<'INJECT'

## [Service Decomposer] サービス分割ルール

### ドメイン分析:
- **境界づけられたコンテキスト**: 各ドメインは独立した言語(ユビキタス言語)を持つ
- **集約ルート**: トランザクション境界の単位。集約間の直接参照禁止
- **コンテキストマップ**: upstream/downstream関係を明示

### 分割基準:
- チーム独立性: 1サービス = 1チームが所有
- データ独立性: 各サービスが自分のDBを所有
- 障害独立性: 1サービスの障害が他に伝播しない

INJECT
    echo "$prompt"
}

# =============================================================================
# レポート & スコア
# =============================================================================
sd_report() {
    echo -e "\n  ${BOLD:-}=== service-decomposer v${SD_VERSION} ===${NC:-}"
    echo -e "  ドメイン数: ${SD_DOMAINS_FOUND}"
    echo -e "  生成数: ${SD_GENERATED}"
    echo -e "  エラー: ${SD_ERRORS}"
}

sd_score() {
    if [[ ${SD_GENERATED} -ge 3 ]] && [[ ${SD_ERRORS} -eq 0 ]]; then
        echo "95"
    elif [[ ${SD_GENERATED} -gt 0 ]] && [[ ${SD_ERRORS} -eq 0 ]]; then
        echo "85"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "service-decomposer" --version "${SD_VERSION}" \
        --description "ドメイン分析×サービス分割戦略×インターフェース契約" \
        --init "sd_init" --report "sd_report" --score "sd_score" \
        --enable-var "ENABLE_SERVICE_DECOMPOSER" --cli-flags "--service-decomposer:--no-service-decomposer"
fi

# v2003.1: source時のexit codeを確実に0にする
true
