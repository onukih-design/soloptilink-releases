#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v398.0 - Onboarding Guide Generator
# =============================================================================
# 開発者オンボーディングガイド生成。Getting Started/アーキ解説/開発環境セットアップ。
# All globals use the OGG_ prefix.
# =============================================================================

[[ -n "${_ONBOARDING_GUIDE_GENERATOR_LOADED:-}" ]] && return 0
_ONBOARDING_GUIDE_GENERATOR_LOADED=1

declare -g OGG_VERSION="398.0"
declare -g OGG_INITIALIZED=false
declare -g OGG_GENERATED_COUNT=0
declare -g OGG_GETTING_STARTED_GENERATED=false
declare -g OGG_ARCH_GUIDE_GENERATED=false
declare -g OGG_DEV_SETUP_GENERATED=false
declare -g OGG_FAQ_GENERATED=false
declare -g ENABLE_OGG="${ENABLE_OGG:-true}"

_ogg_init() { OGG_INITIALIZED=true; OGG_GENERATED_COUNT=0; return 0; }

_ogg_generate_all() {
    local project_dir="${1:-.}"
    [[ "$OGG_INITIALIZED" != "true" ]] && _ogg_init
    echo -e "  ${CYAN:-\033[0;36m}[OGG]${NC:-\033[0m} オンボーディングガイド生成開始..." >&2
    _ogg_generate_getting_started "$project_dir"
    _ogg_generate_architecture_guide "$project_dir"
    _ogg_generate_dev_setup "$project_dir"
    _ogg_generate_faq "$project_dir"
    echo -e "  ${GREEN:-\033[0;32m}[OGG]${NC:-\033[0m} オンボーディングガイド生成完了: ${OGG_GENERATED_COUNT}件" >&2
    return 0
}

_ogg_generate_getting_started() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [OGG-START] Getting Startedガイド生成

### Project Analyzer
```typescript
export async function analyzeProject(rootDir: string): Promise<ProjectInfo> {
  const pkg = JSON.parse(await readFile(join(rootDir, 'package.json'), 'utf-8'));
  const hasNext = !!pkg.dependencies?.next;
  const hasPrisma = !!pkg.dependencies?.['@prisma/client'];
  const hasDocker = await exists(join(rootDir, 'Dockerfile'));
  const envExample = await readFile(join(rootDir, '.env.example'), 'utf-8').catch(() => null);

  return {
    name: pkg.name, version: pkg.version,
    framework: hasNext ? 'Next.js' : pkg.dependencies?.express ? 'Express' : 'Unknown',
    database: hasPrisma ? 'PostgreSQL (Prisma)' : pkg.dependencies?.mongoose ? 'MongoDB' : 'None',
    hasDocker, envVars: envExample ? parseEnvFile(envExample) : [],
    scripts: Object.entries(pkg.scripts ?? {}).map(([k, v]) => ({ name: k, command: v as string })),
  };
}

export function generateGettingStarted(project: ProjectInfo): string {
  let guide = `# ${project.name}\n\n## 前提条件\n`;
  guide += `- Node.js v18以上\n`;
  if (project.database.includes('PostgreSQL')) guide += `- PostgreSQL v15以上\n`;
  if (project.hasDocker) guide += `- Docker & Docker Compose\n`;

  guide += `\n## セットアップ\n\`\`\`bash\ngit clone <repo-url>\ncd ${project.name}\nnpm install\n`;
  if (project.envVars.length > 0) guide += `cp .env.example .env  # 環境変数を設定\n`;
  if (project.database.includes('Prisma')) guide += `npx prisma migrate dev\nnpx prisma db seed\n`;
  guide += `npm run dev\n\`\`\`\n`;

  guide += `\n## 利用可能なスクリプト\n`;
  for (const script of project.scripts) {
    guide += `- \`npm run ${script.name}\` - ${script.command}\n`;
  }
  return guide;
}
```
TEMPLATE
    OGG_GETTING_STARTED_GENERATED=true
    OGG_GENERATED_COUNT=$((OGG_GENERATED_COUNT + 1))
    return 0
}

_ogg_generate_architecture_guide() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [OGG-ARCH] アーキテクチャガイド生成

```typescript
export async function generateArchitectureGuide(rootDir: string): Promise<string> {
  const structure = await scanDirectoryStructure(rootDir);
  let guide = '# アーキテクチャガイド\n\n## ディレクトリ構造\n```\n';

  for (const entry of structure) {
    guide += `${'  '.repeat(entry.depth)}${entry.name}/\n`;
    if (entry.description) guide += `${'  '.repeat(entry.depth + 1)}# ${entry.description}\n`;
  }
  guide += '```\n\n';

  guide += '## 技術スタック\n';
  const techStack = await detectTechStack(rootDir);
  for (const [category, tech] of Object.entries(techStack)) {
    guide += `- **${category}**: ${tech}\n`;
  }

  guide += '\n## データフロー\n';
  guide += '1. クライアント → Next.js App Router → API Route\n';
  guide += '2. API Route → Service Layer → Prisma ORM → Database\n';
  guide += '3. Response → JSON → Client State (SWR/React Query)\n';

  return guide;
}

const DIR_DESCRIPTIONS: Record<string, string> = {
  app: 'Next.js App Routerページ・APIルート',
  components: 'Reactコンポーネント',
  lib: 'ユーティリティ・サービス層',
  prisma: 'データベーススキーマ・マイグレーション',
  public: '静的ファイル',
  tests: 'テストファイル',
};
```
TEMPLATE
    OGG_ARCH_GUIDE_GENERATED=true
    OGG_GENERATED_COUNT=$((OGG_GENERATED_COUNT + 1))
    return 0
}

_ogg_generate_dev_setup() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [OGG-SETUP] 開発環境セットアップガイド生成

```typescript
export function generateDevSetupGuide(project: ProjectInfo): string {
  let guide = '# 開発環境セットアップ\n\n';

  guide += '## 推奨エディタ設定\n';
  guide += '### VS Code 推奨拡張機能\n';
  guide += '- ESLint\n- Prettier\n- Prisma\n- Tailwind CSS IntelliSense\n- Error Lens\n\n';

  guide += '### .vscode/settings.json\n```json\n';
  guide += JSON.stringify({ "editor.defaultFormatter": "esbenp.prettier-vscode", "editor.formatOnSave": true, "editor.codeActionsOnSave": { "source.fixAll.eslint": "explicit" } }, null, 2);
  guide += '\n```\n\n';

  if (project.database.includes('PostgreSQL')) {
    guide += '## データベースセットアップ\n```bash\n';
    guide += '# PostgreSQL起動（Docker）\ndocker run -d --name postgres -p 5432:5432 -e POSTGRES_PASSWORD=password postgres:15\n\n';
    guide += '# マイグレーション実行\nnpx prisma migrate dev\n\n';
    guide += '# シードデータ投入\nnpx prisma db seed\n```\n\n';
  }

  guide += '## 環境変数\n';
  for (const env of project.envVars) {
    guide += `- \`${env.name}\` - ${env.description ?? '設定必須'} (例: \`${env.example ?? ''}\`)\n`;
  }

  return guide;
}
```
TEMPLATE
    OGG_DEV_SETUP_GENERATED=true
    OGG_GENERATED_COUNT=$((OGG_GENERATED_COUNT + 1))
    return 0
}

_ogg_generate_faq() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [OGG-FAQ] よくある質問生成

```typescript
const COMMON_FAQ = [
  { q: 'npm installでエラーが出る', a: 'Node.jsのバージョンを確認してください。v18以上が必要です。\n`node -v`でバージョンを確認し、nvmで切り替えてください。' },
  { q: 'Prismaマイグレーションが失敗する', a: 'DATABASE_URLが正しいか確認してください。\nPostgreSQLが起動しているか`pg_isready`で確認できます。' },
  { q: '開発サーバーが起動しない', a: '`.env`ファイルが存在するか確認してください。\n`cp .env.example .env`で作成し、必要な値を設定してください。' },
  { q: 'テストが失敗する', a: 'テスト用データベースのセットアップを確認してください。\n`npx prisma migrate dev --name init`を実行してください。' },
];

export function generateFAQ(project: ProjectInfo): string {
  let faq = '# よくある質問 (FAQ)\n\n';
  for (const item of COMMON_FAQ) {
    faq += `## Q: ${item.q}\n\n${item.a}\n\n---\n\n`;
  }
  return faq;
}
```
TEMPLATE
    OGG_FAQ_GENERATED=true
    OGG_GENERATED_COUNT=$((OGG_GENERATED_COUNT + 1))
    return 0
}

_ogg_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Onboarding Guide Generator v${OGG_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成数             : ${OGG_GENERATED_COUNT}"
    echo -e "  Getting Started    : ${OGG_GETTING_STARTED_GENERATED}"
    echo -e "  アーキテクチャ     : ${OGG_ARCH_GUIDE_GENERATED}"
    echo -e "  開発環境           : ${OGG_DEV_SETUP_GENERATED}"
    echo -e "  FAQ                : ${OGG_FAQ_GENERATED}"
}

_ogg_score() {
    local score=30
    [[ "$OGG_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$OGG_GETTING_STARTED_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$OGG_ARCH_GUIDE_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$OGG_DEV_SETUP_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$OGG_FAQ_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "onboarding-guide-generator" \
    --version "398.0" \
    --description "オンボーディングガイド（Getting Started/アーキ解説/開発環境/FAQ）" \
    --init "_ogg_init" \
    --report "_ogg_report" \
    --score "_ogg_score" \
    --enable-var "ENABLE_OGG" \
    --cli-flags "--onboarding-guide:--no-onboarding-guide"
