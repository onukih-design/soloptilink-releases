#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v336.0 - Unit Test Generator
# =============================================================================
# 関数解析からユニットテスト自動生成。Vitest/Jest対応。
# モック生成、エッジケース検出、カバレッジ最大化。
#
# Functions:
#   _utg_init()              - Initialize
#   _utg_analyze_function()  - Analyze function signature & behavior
#   _utg_generate_tests()    - Generate unit tests
#   _utg_generate_mocks()    - Generate mock/stub helpers
#   _utg_report() / _utg_score()
# =============================================================================

[[ -n "${_UTG_LOADED:-}" ]] && return 0; _UTG_LOADED=1

readonly _UTG_RED='\033[0;31m'
readonly _UTG_GREEN='\033[0;32m'
readonly _UTG_YELLOW='\033[0;33m'
readonly _UTG_CYAN='\033[0;36m'
readonly _UTG_NC='\033[0m'

declare -g UTG_VERSION="336.0"
UTG_GENERATED=0
UTG_ERRORS=0
UTG_FILES_WRITTEN=0
UTG_TESTS_OK=false
UTG_ANALYZE_OK=false
UTG_MOCKS_OK=false
UTG_FUNCTIONS_ANALYZED=0
UTG_TESTS_GENERATED=0

_utg_init() {
    UTG_GENERATED=0; UTG_ERRORS=0; UTG_FILES_WRITTEN=0
    UTG_TESTS_OK=false; UTG_ANALYZE_OK=false; UTG_MOCKS_OK=false
    UTG_FUNCTIONS_ANALYZED=0; UTG_TESTS_GENERATED=0
    echo -e "  ${_UTG_GREEN}OK${_UTG_NC} Unit Test Generator v${UTG_VERSION}" >&2
    return 0
}

_utg_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { UTG_FILES_WRITTEN=$((UTG_FILES_WRITTEN + 1)); return 0; }
    UTG_ERRORS=$((UTG_ERRORS + 1)); return 1
}

_utg_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_UTG_CYAN}[unit-test]${_UTG_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_UTG_GREEN}[unit-test]${_UTG_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_UTG_YELLOW}[unit-test]${_UTG_NC} $msg" >&2 ;;
        error) echo -e "  ${_UTG_RED}[unit-test]${_UTG_NC} $msg" >&2 ;;
    esac
}

# =============================================================================
# Analyze Functions in Source Files
# =============================================================================
_utg_analyze_function() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local src_dir="${project_dir}/src"

    _utg_log info "Analyzing functions in ${src_dir}..."

    if [[ ! -d "$src_dir" ]]; then
        _utg_log warn "Source directory not found: ${src_dir}"
        return 1
    fi

    # Find exported functions
    local export_funcs
    export_funcs=$(grep -rn "export\s\+\(async\s\+\)\?function\s\+" "$src_dir" \
        --include="*.ts" --include="*.tsx" 2>/dev/null | \
        grep -v "node_modules\|\.test\.\|\.spec\.\|__test__" | head -50)

    # Find exported arrow functions
    local export_arrows
    export_arrows=$(grep -rn "export\s\+const\s\+\w\+\s*=" "$src_dir" \
        --include="*.ts" --include="*.tsx" 2>/dev/null | \
        grep -v "node_modules\|\.test\.\|\.spec\.\|__test__\|interface\|type\|enum" | head -50)

    UTG_FUNCTIONS_ANALYZED=$(( $(echo "$export_funcs" | grep -c . 2>/dev/null || echo 0) + \
                               $(echo "$export_arrows" | grep -c . 2>/dev/null || echo 0) ))

    _utg_log ok "Found ${UTG_FUNCTIONS_ANALYZED} exported functions to test"

    UTG_ANALYZE_OK=true
    UTG_GENERATED=$((UTG_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate Unit Tests
# =============================================================================
_utg_generate_tests() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local src_dir="${project_dir}/src"
    local test_dir="${project_dir}/src/__tests__"

    _utg_log info "Generating unit tests..."

    # Generate test config
    _utg_write_file "${project_dir}/vitest.config.ts" "$(cat <<'TYPESCRIPT'
import { defineConfig } from 'vitest/config';
import path from 'path';

export default defineConfig({
  test: {
    globals: true,
    environment: 'node',
    include: ['src/**/*.test.ts', 'src/**/*.spec.ts'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html'],
      exclude: ['node_modules/', 'dist/', '**/*.d.ts', '**/*.test.ts'],
      thresholds: {
        branches: 80,
        functions: 80,
        lines: 80,
        statements: 80,
      },
    },
    setupFiles: ['./src/__tests__/setup.ts'],
  },
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
});
TYPESCRIPT
)"

    # Test setup
    _utg_write_file "${test_dir}/setup.ts" "$(cat <<'TYPESCRIPT'
import { beforeAll, afterAll, afterEach, vi } from 'vitest';

// Mock environment variables
process.env.NODE_ENV = 'test';
process.env.DATABASE_URL = 'postgresql://test:test@localhost:5432/test';
process.env.JWT_SECRET = 'test-secret-key-for-testing-only';

// Global test setup
beforeAll(() => {
  vi.useFakeTimers();
});

afterEach(() => {
  vi.restoreAllMocks();
});

afterAll(() => {
  vi.useRealTimers();
});
TYPESCRIPT
)"

    # Generate sample test patterns
    _utg_write_file "${test_dir}/lib/utils.test.ts" "$(cat <<'TYPESCRIPT'
import { describe, it, expect, vi } from 'vitest';

// Template: Pure function tests
describe('utils', () => {
  describe('formatCurrency', () => {
    it('should format positive numbers', () => {
      // expect(formatCurrency(1234.56)).toBe('$1,234.56');
    });

    it('should handle zero', () => {
      // expect(formatCurrency(0)).toBe('$0.00');
    });

    it('should handle negative numbers', () => {
      // expect(formatCurrency(-100)).toBe('-$100.00');
    });

    it('should handle edge cases', () => {
      // expect(formatCurrency(NaN)).toBe('$0.00');
      // expect(formatCurrency(Infinity)).toBe('$0.00');
    });
  });
});

// Template: Async function tests
describe('async operations', () => {
  it('should resolve successfully', async () => {
    // const result = await fetchData('test-id');
    // expect(result).toBeDefined();
  });

  it('should handle errors gracefully', async () => {
    // await expect(fetchData('invalid')).rejects.toThrow('Not found');
  });

  it('should respect timeout', async () => {
    // vi.useFakeTimers();
    // const promise = fetchWithTimeout('url', 1000);
    // vi.advanceTimersByTime(1001);
    // await expect(promise).rejects.toThrow('Timeout');
  });
});

// Template: Class/service tests
describe('UserService', () => {
  // let service: UserService;
  // const mockDb = { findUnique: vi.fn(), create: vi.fn() };

  // beforeEach(() => {
  //   service = new UserService(mockDb as any);
  //   vi.clearAllMocks();
  // });

  it('should create a user with valid data', async () => {
    // mockDb.create.mockResolvedValue({ id: '1', email: 'test@test.com' });
    // const user = await service.create({ email: 'test@test.com', name: 'Test' });
    // expect(user.id).toBe('1');
    // expect(mockDb.create).toHaveBeenCalledOnce();
  });

  it('should throw on duplicate email', async () => {
    // mockDb.create.mockRejectedValue(new Error('Unique constraint'));
    // await expect(service.create({ email: 'dup@test.com' })).rejects.toThrow();
  });
});
TYPESCRIPT
)"

    # API route test template
    _utg_write_file "${test_dir}/api/route.test.ts" "$(cat <<'TYPESCRIPT'
import { describe, it, expect, vi, beforeEach } from 'vitest';

// Template: API Route Handler tests
describe('API Route Handler', () => {
  // const mockPrisma = { user: { findMany: vi.fn(), create: vi.fn(), update: vi.fn(), delete: vi.fn() } };
  // vi.mock('@/lib/db', () => ({ prisma: mockPrisma }));

  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('GET /api/users', () => {
    it('should return 200 with user list', async () => {
      // mockPrisma.user.findMany.mockResolvedValue([{ id: '1', name: 'Test' }]);
      // const req = new Request('http://localhost/api/users');
      // const res = await GET(req);
      // expect(res.status).toBe(200);
      // const body = await res.json();
      // expect(body).toHaveLength(1);
    });

    it('should return 401 without auth', async () => {
      // const req = new Request('http://localhost/api/users');
      // const res = await GET(req);
      // expect(res.status).toBe(401);
    });
  });

  describe('POST /api/users', () => {
    it('should return 201 on valid input', async () => {
      // const body = JSON.stringify({ email: 'new@test.com', name: 'New' });
      // const req = new Request('http://localhost/api/users', { method: 'POST', body });
      // mockPrisma.user.create.mockResolvedValue({ id: '2', email: 'new@test.com' });
      // const res = await POST(req);
      // expect(res.status).toBe(201);
    });

    it('should return 400 on invalid input', async () => {
      // const req = new Request('http://localhost/api/users', { method: 'POST', body: '{}' });
      // const res = await POST(req);
      // expect(res.status).toBe(400);
    });
  });
});
TYPESCRIPT
)"

    local test_count
    test_count=$(find "$test_dir" -name "*.test.ts" -o -name "*.spec.ts" 2>/dev/null | wc -l | tr -d ' ')
    UTG_TESTS_GENERATED=$test_count

    _utg_log ok "Unit test templates generated (${test_count} files)"
    UTG_TESTS_OK=true
    UTG_GENERATED=$((UTG_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate Mocks
# =============================================================================
_utg_generate_mocks() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local mock_dir="${project_dir}/src/__tests__/__mocks__"

    _utg_log info "Generating mock helpers..."

    _utg_write_file "${mock_dir}/prisma.ts" "$(cat <<'TYPESCRIPT'
import { vi } from 'vitest';

export const prismaMock = {
  user: { findMany: vi.fn(), findUnique: vi.fn(), create: vi.fn(), update: vi.fn(), delete: vi.fn(), count: vi.fn() },
  project: { findMany: vi.fn(), findUnique: vi.fn(), create: vi.fn(), update: vi.fn(), delete: vi.fn() },
  task: { findMany: vi.fn(), findUnique: vi.fn(), create: vi.fn(), update: vi.fn(), delete: vi.fn() },
  $transaction: vi.fn((cb: any) => cb(prismaMock)),
  $connect: vi.fn(),
  $disconnect: vi.fn(),
};

vi.mock('@/lib/db', () => ({ prisma: prismaMock }));

export function resetPrismaMocks() {
  Object.values(prismaMock).forEach((model: any) => {
    if (typeof model === 'object') {
      Object.values(model).forEach((fn: any) => {
        if (typeof fn?.mockReset === 'function') fn.mockReset();
      });
    }
  });
}
TYPESCRIPT
)"

    _utg_write_file "${mock_dir}/auth.ts" "$(cat <<'TYPESCRIPT'
import { vi } from 'vitest';

export const mockUser = {
  id: 'user-1',
  email: 'test@example.com',
  name: 'Test User',
  role: 'admin',
};

export const mockSession = {
  user: mockUser,
  expires: new Date(Date.now() + 86400000).toISOString(),
};

export const authMock = {
  getSession: vi.fn().mockResolvedValue(mockSession),
  verifyToken: vi.fn().mockResolvedValue(mockUser),
  requireAuth: vi.fn().mockResolvedValue(mockUser),
};

vi.mock('@/lib/auth', () => authMock);
TYPESCRIPT
)"

    _utg_write_file "${mock_dir}/fetch.ts" "$(cat <<'TYPESCRIPT'
import { vi } from 'vitest';

export function mockFetch(responses: Record<string, { status: number; body: any }>) {
  return vi.fn((url: string) => {
    const match = Object.entries(responses).find(([pattern]) => url.includes(pattern));
    if (match) {
      return Promise.resolve({
        ok: match[1].status < 400,
        status: match[1].status,
        json: () => Promise.resolve(match[1].body),
        text: () => Promise.resolve(JSON.stringify(match[1].body)),
      });
    }
    return Promise.resolve({ ok: false, status: 404, json: () => Promise.resolve({ error: 'Not found' }) });
  });
}
TYPESCRIPT
)"

    _utg_log ok "Mock helpers generated"
    UTG_MOCKS_OK=true
    UTG_GENERATED=$((UTG_GENERATED + 1))
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_utg_report() {
    echo -e "\n  ${_UTG_CYAN}=== Unit Test Generator v${UTG_VERSION} ===${_UTG_NC}"
    echo -e "  Generated: ${UTG_GENERATED} | Files: ${UTG_FILES_WRITTEN} | Errors: ${UTG_ERRORS}"
    echo -e "  Functions Analyzed: ${UTG_FUNCTIONS_ANALYZED}"
    echo -e "  Tests Generated: ${UTG_TESTS_GENERATED}"
    echo -e "  Analysis: $( ${UTG_ANALYZE_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Tests: $( ${UTG_TESTS_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Mocks: $( ${UTG_MOCKS_OK} && echo 'OK' || echo 'SKIP')"
}

_utg_score() {
    local score=50
    ${UTG_ANALYZE_OK} && score=$((score + 10))
    ${UTG_TESTS_OK} && score=$((score + 20))
    ${UTG_MOCKS_OK} && score=$((score + 15))
    [[ ${UTG_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "unit-test-generator" --version "336.0" \
        --description "ユニットテスト自動生成 Vitest/モック/カバレッジ (v336)" \
        --init "_utg_init" --report "_utg_report" --score "_utg_score" \
        --enable-var "ENABLE_UNIT_TEST_GEN" --cli-flags "--unit-test-gen:--no-unit-test-gen"
fi

# v2003.1: source時のexit codeを確実に0にする
true
