#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v401.0 - Prompt Engineering Studio
# =============================================================================
# プロンプトの設計・テスト・バージョン管理を統合するスタジオ環境。
# AI呼び出しプロンプトを体系的に最適化し、A/Bテスト・品質スコアリングで
# 最適プロンプトを自動選択する。
#
# Functions:
#   _pes_init              - 初期化・ストレージ準備
#   _pes_optimize_prompt   - プロンプト最適化（冗長性除去/構造化/制約注入）
#   _pes_test_prompt       - プロンプトA/Bテスト実行・スコアリング
#   _pes_version_prompt    - プロンプトバージョン管理（作成/比較/ロールバック）
#   _pes_analyze_quality   - プロンプト品質分析（曖昧性/冗長性/網羅性）
#   _pes_inject_best       - 最適プロンプトをビルドフローに注入
#   _pes_report            - レポート出力
#   _pes_score             - モジュールスコア(0-100)
#
# All globals use the PES_ prefix.
# =============================================================================

[[ -n "${_PROMPT_ENGINEERING_STUDIO_LOADED:-}" ]] && return 0
_PROMPT_ENGINEERING_STUDIO_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g PES_VERSION="401.0"
declare -g PES_INITIALIZED=false
declare -g PES_STORE_DIR=""
declare -g PES_OPTIMIZED_COUNT=0
declare -g PES_TEST_COUNT=0
declare -g PES_VERSION_COUNT=0
declare -g PES_BEST_SCORE=0

declare -g -A _PES_PROMPT_VERSIONS=()    # prompt_id → version_count
declare -g -A _PES_PROMPT_SCORES=()      # prompt_id::version → score
declare -g -A _PES_PROMPT_CONTENT=()     # prompt_id::version → content_hash
declare -g -A _PES_AB_RESULTS=()         # test_id → "scoreA:scoreB"
declare -g -a _PES_OPTIMIZATION_LOG=()   # optimization history

# =============================================================================
# _pes_init - Initialize prompt engineering studio
# =============================================================================
_pes_init() {
    local project_dir="${PROJECT_DIR:-.}"
    PES_STORE_DIR="${project_dir}/.soloptilink/prompt-studio"
    mkdir -p "${PES_STORE_DIR}/versions" "${PES_STORE_DIR}/tests" "${PES_STORE_DIR}/analytics"

    # Load existing prompt versions from disk
    if [[ -f "${PES_STORE_DIR}/registry.json" ]]; then
        local count
        count=$(grep -c '"prompt_id"' "${PES_STORE_DIR}/registry.json" 2>/dev/null || echo "0")
        PES_VERSION_COUNT=$count
    fi

    PES_INITIALIZED=true
    return 0
}

# =============================================================================
# _pes_optimize_prompt - Optimize a prompt for quality and efficiency
# =============================================================================
_pes_optimize_prompt() {
    local prompt_text="$1"
    local domain="${2:-general}"
    local optimization_level="${3:-standard}"  # standard|aggressive|conservative

    [[ "$PES_INITIALIZED" != "true" ]] && { echo "ERROR: PES not initialized" >&2; return 1; }
    [[ -z "$prompt_text" ]] && { echo "ERROR: Empty prompt text" >&2; return 1; }

    local optimized="$prompt_text"
    local changes=0

    # Phase 1: Remove redundancy
    local deduped
    deduped=$(echo "$optimized" | awk '!seen[$0]++')
    if [[ "$deduped" != "$optimized" ]]; then
        optimized="$deduped"
        changes=$((changes + 1))
    fi

    # Phase 2: Add structural markers if missing
    if ! echo "$optimized" | grep -q '##\|###\|---'; then
        local structured=""
        local section_count=0
        while IFS= read -r line; do
            if [[ ${#line} -gt 80 ]] && [[ $section_count -lt 5 ]]; then
                structured+="## Section $((section_count + 1))"$'\n'
                section_count=$((section_count + 1))
            fi
            structured+="${line}"$'\n'
        done <<< "$optimized"
        if [[ $section_count -gt 0 ]]; then
            optimized="$structured"
            changes=$((changes + 1))
        fi
    fi

    # Phase 3: Inject domain-specific constraints
    case "$domain" in
        web|frontend)
            if ! echo "$optimized" | grep -qi 'responsive\|mobile'; then
                optimized+=$'\n'"## Constraints: Ensure responsive design, mobile-first approach."
                changes=$((changes + 1))
            fi
            ;;
        api|backend)
            if ! echo "$optimized" | grep -qi 'validation\|error.handling'; then
                optimized+=$'\n'"## Constraints: Include input validation, proper error handling, rate limiting."
                changes=$((changes + 1))
            fi
            ;;
        database)
            if ! echo "$optimized" | grep -qi 'index\|migration'; then
                optimized+=$'\n'"## Constraints: Include proper indexing, migration scripts, rollback plan."
                changes=$((changes + 1))
            fi
            ;;
    esac

    # Phase 4: Aggressive optimization - compress tokens
    if [[ "$optimization_level" == "aggressive" ]]; then
        optimized=$(echo "$optimized" | sed 's/  */ /g' | sed '/^$/d')
        changes=$((changes + 1))
    fi

    # Phase 5: Quality check - ensure minimum structure
    local word_count
    word_count=$(echo "$optimized" | wc -w | tr -d ' ')
    if [[ $word_count -lt 10 ]]; then
        echo "WARNING: Optimized prompt is very short ($word_count words)" >&2
    fi

    # Record optimization
    PES_OPTIMIZED_COUNT=$((PES_OPTIMIZED_COUNT + 1))
    local timestamp
    timestamp=$(date +%s 2>/dev/null || echo "0")
    _PES_OPTIMIZATION_LOG+=("${timestamp}:${domain}:${changes}changes")

    # Save to disk
    local opt_file="${PES_STORE_DIR}/analytics/optimization_${timestamp}.log"
    echo "domain=${domain} level=${optimization_level} changes=${changes}" > "$opt_file" 2>/dev/null

    echo "$optimized"
    return 0
}

# =============================================================================
# _pes_test_prompt - A/B test two prompt variants
# =============================================================================
_pes_test_prompt() {
    local prompt_id="$1"
    local variant_a="$2"
    local variant_b="$3"
    local test_criteria="${4:-completeness,accuracy,conciseness}"

    [[ "$PES_INITIALIZED" != "true" ]] && { echo "ERROR: PES not initialized" >&2; return 1; }
    [[ -z "$prompt_id" || -z "$variant_a" || -z "$variant_b" ]] && {
        echo "ERROR: prompt_id, variant_a, variant_b required" >&2; return 1
    }

    local test_id="${prompt_id}_$(date +%s 2>/dev/null || echo '0')"
    local score_a=0 score_b=0

    # Criterion 1: Completeness (structure coverage)
    if echo "$test_criteria" | grep -q 'completeness'; then
        local sections_a sections_b
        sections_a=$(echo "$variant_a" | grep -c '##\|###\|---' || echo "0")
        sections_b=$(echo "$variant_b" | grep -c '##\|###\|---' || echo "0")
        [[ $sections_a -ge 2 ]] && score_a=$((score_a + 20))
        [[ $sections_b -ge 2 ]] && score_b=$((score_b + 20))
    fi

    # Criterion 2: Accuracy (specific constraints present)
    if echo "$test_criteria" | grep -q 'accuracy'; then
        local constraints_a constraints_b
        constraints_a=$(echo "$variant_a" | grep -ci 'must\|shall\|required\|ensure\|always' || echo "0")
        constraints_b=$(echo "$variant_b" | grep -ci 'must\|shall\|required\|ensure\|always' || echo "0")
        score_a=$((score_a + constraints_a * 5))
        score_b=$((score_b + constraints_b * 5))
        [[ $score_a -gt 40 ]] && score_a=40
        [[ $score_b -gt 40 ]] && score_b=40
    fi

    # Criterion 3: Conciseness (token efficiency)
    if echo "$test_criteria" | grep -q 'conciseness'; then
        local words_a words_b
        words_a=$(echo "$variant_a" | wc -w | tr -d ' ')
        words_b=$(echo "$variant_b" | wc -w | tr -d ' ')
        # Penalize overly verbose prompts
        [[ $words_a -lt 500 ]] && score_a=$((score_a + 20))
        [[ $words_b -lt 500 ]] && score_b=$((score_b + 20))
        [[ $words_a -lt 200 ]] && score_a=$((score_a + 10))
        [[ $words_b -lt 200 ]] && score_b=$((score_b + 10))
    fi

    # Criterion 4: Examples present
    local examples_a examples_b
    examples_a=$(echo "$variant_a" | grep -ci 'example\|e\.g\.\|for instance' || echo "0")
    examples_b=$(echo "$variant_b" | grep -ci 'example\|e\.g\.\|for instance' || echo "0")
    [[ $examples_a -gt 0 ]] && score_a=$((score_a + 10))
    [[ $examples_b -gt 0 ]] && score_b=$((score_b + 10))

    # Cap scores
    [[ $score_a -gt 100 ]] && score_a=100
    [[ $score_b -gt 100 ]] && score_b=100

    _PES_AB_RESULTS["$test_id"]="${score_a}:${score_b}"
    PES_TEST_COUNT=$((PES_TEST_COUNT + 1))

    # Determine winner
    local winner="tie"
    [[ $score_a -gt $score_b ]] && winner="A"
    [[ $score_b -gt $score_a ]] && winner="B"

    # Save test results
    local test_file="${PES_STORE_DIR}/tests/${test_id}.json"
    cat > "$test_file" 2>/dev/null <<TESTEOF
{"test_id":"${test_id}","score_a":${score_a},"score_b":${score_b},"winner":"${winner}","criteria":"${test_criteria}"}
TESTEOF

    echo "${winner}:${score_a}:${score_b}"
    return 0
}

# =============================================================================
# _pes_version_prompt - Version control for prompts
# =============================================================================
_pes_version_prompt() {
    local action="$1"   # create|list|rollback|compare
    local prompt_id="$2"
    local content="$3"

    [[ "$PES_INITIALIZED" != "true" ]] && { echo "ERROR: PES not initialized" >&2; return 1; }

    case "$action" in
        create)
            [[ -z "$prompt_id" || -z "$content" ]] && { echo "ERROR: prompt_id and content required" >&2; return 1; }
            local current_ver="${_PES_PROMPT_VERSIONS[$prompt_id]:-0}"
            local new_ver=$((current_ver + 1))
            _PES_PROMPT_VERSIONS["$prompt_id"]=$new_ver

            local content_hash
            content_hash=$(echo "$content" | md5sum 2>/dev/null | cut -d' ' -f1 || echo "nohash")
            _PES_PROMPT_CONTENT["${prompt_id}::${new_ver}"]="$content_hash"
            _PES_PROMPT_SCORES["${prompt_id}::${new_ver}"]=0

            # Save version to disk
            local ver_file="${PES_STORE_DIR}/versions/${prompt_id}_v${new_ver}.txt"
            echo "$content" > "$ver_file" 2>/dev/null
            PES_VERSION_COUNT=$((PES_VERSION_COUNT + 1))
            echo "v${new_ver}"
            ;;
        list)
            [[ -z "$prompt_id" ]] && { echo "ERROR: prompt_id required" >&2; return 1; }
            local max_ver="${_PES_PROMPT_VERSIONS[$prompt_id]:-0}"
            local v
            for ((v=1; v<=max_ver; v++)); do
                local hash="${_PES_PROMPT_CONTENT[${prompt_id}::${v}]:-unknown}"
                local score="${_PES_PROMPT_SCORES[${prompt_id}::${v}]:-0}"
                echo "v${v} hash=${hash} score=${score}"
            done
            ;;
        rollback)
            [[ -z "$prompt_id" ]] && { echo "ERROR: prompt_id required" >&2; return 1; }
            local target_ver="${content:-}"
            [[ -z "$target_ver" ]] && target_ver=$(( ${_PES_PROMPT_VERSIONS[$prompt_id]:-1} - 1 ))
            [[ $target_ver -lt 1 ]] && { echo "ERROR: Cannot rollback below v1" >&2; return 1; }
            local ver_file="${PES_STORE_DIR}/versions/${prompt_id}_v${target_ver}.txt"
            if [[ -f "$ver_file" ]]; then
                cat "$ver_file"
            else
                echo "ERROR: Version file not found" >&2
                return 1
            fi
            ;;
        compare)
            [[ -z "$prompt_id" ]] && { echo "ERROR: prompt_id required" >&2; return 1; }
            local ver_a="${content:-1}"
            local ver_b="${4:-}"
            [[ -z "$ver_b" ]] && ver_b="${_PES_PROMPT_VERSIONS[$prompt_id]:-1}"
            local file_a="${PES_STORE_DIR}/versions/${prompt_id}_v${ver_a}.txt"
            local file_b="${PES_STORE_DIR}/versions/${prompt_id}_v${ver_b}.txt"
            if [[ -f "$file_a" && -f "$file_b" ]]; then
                diff "$file_a" "$file_b" 2>/dev/null || true
            fi
            ;;
        *)
            echo "ERROR: Unknown action: $action (use create|list|rollback|compare)" >&2
            return 1
            ;;
    esac
    return 0
}

# =============================================================================
# _pes_analyze_quality - Analyze prompt quality across multiple dimensions
# =============================================================================
_pes_analyze_quality() {
    local prompt_text="$1"
    [[ -z "$prompt_text" ]] && { echo "ERROR: Empty prompt" >&2; return 1; }

    local score=0
    local findings=""

    # Dimension 1: Clarity (no ambiguous phrases)
    local ambiguous_count
    ambiguous_count=$(echo "$prompt_text" | grep -ci 'maybe\|perhaps\|might\|could be\|sort of\|kind of' || echo "0")
    if [[ $ambiguous_count -eq 0 ]]; then
        score=$((score + 25))
    else
        findings+="ambiguity:${ambiguous_count},"
    fi

    # Dimension 2: Structure (headers, sections)
    local structure_count
    structure_count=$(echo "$prompt_text" | grep -c '^##\|^###\|^-\|^[0-9]\.' || echo "0")
    if [[ $structure_count -ge 3 ]]; then
        score=$((score + 25))
    elif [[ $structure_count -ge 1 ]]; then
        score=$((score + 15))
        findings+="low_structure,"
    else
        findings+="no_structure,"
    fi

    # Dimension 3: Specificity (concrete constraints)
    local specifics
    specifics=$(echo "$prompt_text" | grep -ci 'must\|always\|never\|exactly\|required' || echo "0")
    if [[ $specifics -ge 3 ]]; then
        score=$((score + 25))
    elif [[ $specifics -ge 1 ]]; then
        score=$((score + 15))
        findings+="low_specificity,"
    else
        findings+="vague,"
    fi

    # Dimension 4: Completeness (covers input/output/constraints)
    local has_input has_output has_constraints
    has_input=$(echo "$prompt_text" | grep -ci 'input\|given\|provided\|parameter' || echo "0")
    has_output=$(echo "$prompt_text" | grep -ci 'output\|return\|generate\|produce' || echo "0")
    has_constraints=$(echo "$prompt_text" | grep -ci 'constraint\|limit\|rule\|format' || echo "0")
    local completeness=0
    [[ $has_input -gt 0 ]] && completeness=$((completeness + 1))
    [[ $has_output -gt 0 ]] && completeness=$((completeness + 1))
    [[ $has_constraints -gt 0 ]] && completeness=$((completeness + 1))
    score=$((score + completeness * 8))

    [[ $score -gt 100 ]] && score=100
    [[ -n "$PES_BEST_SCORE" && $score -gt $PES_BEST_SCORE ]] && PES_BEST_SCORE=$score

    echo "${score}:${findings:-none}"
    return 0
}

# =============================================================================
# _pes_inject_best - Inject best-scoring prompt into build flow
# =============================================================================
_pes_inject_best() {
    local prompt_id="$1"
    local target_file="$2"

    [[ "$PES_INITIALIZED" != "true" ]] && return 1
    [[ -z "$prompt_id" ]] && return 1

    local best_ver=0
    local best_score=0
    local max_ver="${_PES_PROMPT_VERSIONS[$prompt_id]:-0}"

    local v
    for ((v=1; v<=max_ver; v++)); do
        local score="${_PES_PROMPT_SCORES[${prompt_id}::${v}]:-0}"
        if [[ $score -gt $best_score ]]; then
            best_score=$score
            best_ver=$v
        fi
    done

    [[ $best_ver -eq 0 ]] && best_ver=$max_ver
    local ver_file="${PES_STORE_DIR}/versions/${prompt_id}_v${best_ver}.txt"
    if [[ -f "$ver_file" ]]; then
        if [[ -n "$target_file" ]]; then
            cp "$ver_file" "$target_file" 2>/dev/null
        else
            cat "$ver_file"
        fi
        echo "Injected ${prompt_id} v${best_ver} (score=${best_score})" >&2
    fi
    return 0
}

# =============================================================================
# Report / Score
# =============================================================================
_pes_report() {
    echo -e "\n  ${BOLD:-}=== Prompt Engineering Studio v${PES_VERSION} ===${NC:-}"
    echo -e "  Optimized   : ${PES_OPTIMIZED_COUNT}"
    echo -e "  A/B Tests   : ${PES_TEST_COUNT}"
    echo -e "  Versions    : ${PES_VERSION_COUNT}"
    echo -e "  Best Score  : ${PES_BEST_SCORE}"
}

_pes_score() {
    local score=30
    [[ "$PES_INITIALIZED" == "true" ]] && score=$((score + 20))
    [[ $PES_OPTIMIZED_COUNT -gt 0 ]] && score=$((score + 20))
    [[ $PES_TEST_COUNT -gt 0 ]] && score=$((score + 15))
    [[ $PES_VERSION_COUNT -gt 0 ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "prompt-engineering-studio" \
        --version "401.0" \
        --description "プロンプト設計・テスト・バージョン管理統合スタジオ" \
        --init "_pes_init" \
        --report "_pes_report" \
        --score "_pes_score" \
        --enable-var "ENABLE_PES" \
        --cli-flags "--prompt-studio:--no-prompt-studio"
fi

# v2003.1: source時のexit codeを確実に0にする
true
