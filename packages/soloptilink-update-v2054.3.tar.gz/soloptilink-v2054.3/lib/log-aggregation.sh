#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v329.0 - Log Aggregation Engine
# =============================================================================
# 構造化ロガー、ログ集約、ログ検索インターフェース生成。
# Pino/Winston統合、ELKスタック設定、ログレベル管理。
#
# Functions:
#   _la_init()                     - Initialize
#   _la_generate_structured_logger() - Generate structured logger (Pino)
#   _la_generate_aggregator()      - Generate log aggregation config
#   _la_generate_search()          - Generate log search interface
#   _la_report() / _la_score()
# =============================================================================

[[ -n "${_LA_LOADED:-}" ]] && return 0; _LA_LOADED=1

readonly _LA_RED='\033[0;31m'
readonly _LA_GREEN='\033[0;32m'
readonly _LA_YELLOW='\033[0;33m'
readonly _LA_CYAN='\033[0;36m'
readonly _LA_NC='\033[0m'

declare -g LA_VERSION="329.0"
LA_GENERATED=0
LA_ERRORS=0
LA_FILES_WRITTEN=0
LA_LOGGER_OK=false
LA_AGGREGATOR_OK=false
LA_SEARCH_OK=false

_la_init() {
    LA_GENERATED=0; LA_ERRORS=0; LA_FILES_WRITTEN=0
    LA_LOGGER_OK=false; LA_AGGREGATOR_OK=false; LA_SEARCH_OK=false
    echo -e "  ${_LA_GREEN}OK${_LA_NC} Log Aggregation v${LA_VERSION}" >&2
    return 0
}

_la_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { LA_FILES_WRITTEN=$((LA_FILES_WRITTEN + 1)); return 0; }
    LA_ERRORS=$((LA_ERRORS + 1)); return 1
}

_la_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_LA_CYAN}[log-agg]${_LA_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_LA_GREEN}[log-agg]${_LA_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_LA_YELLOW}[log-agg]${_LA_NC} $msg" >&2 ;;
        error) echo -e "  ${_LA_RED}[log-agg]${_LA_NC} $msg" >&2 ;;
    esac
}

# =============================================================================
# Generate Structured Logger
# =============================================================================
_la_generate_structured_logger() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _la_log info "Generating structured logger..."

    _la_write_file "${project_dir}/src/lib/logger.ts" "$(cat <<'TYPESCRIPT'
import pino from 'pino';

const isProduction = process.env.NODE_ENV === 'production';

export const logger = pino({
  level: process.env.LOG_LEVEL || (isProduction ? 'info' : 'debug'),
  ...(isProduction
    ? {
        formatters: {
          level: (label: string) => ({ level: label }),
          bindings: (bindings: pino.Bindings) => ({
            pid: bindings.pid,
            hostname: bindings.hostname,
            service: process.env.SERVICE_NAME || 'app',
          }),
        },
        timestamp: pino.stdTimeFunctions.isoTime,
        redact: {
          paths: ['req.headers.authorization', 'req.headers.cookie', 'password', 'secret', 'token'],
          censor: '[REDACTED]',
        },
      }
    : { transport: { target: 'pino-pretty', options: { colorize: true } } }),
});

export function createChildLogger(context: Record<string, unknown>) {
  return logger.child(context);
}

// Request logger middleware
export function requestLogger() {
  return (req: any, res: any, next: any) => {
    const start = Date.now();
    const reqLogger = logger.child({
      requestId: req.headers['x-request-id'] || crypto.randomUUID(),
      method: req.method,
      url: req.url,
      userAgent: req.headers['user-agent'],
    });

    req.log = reqLogger;
    reqLogger.info('Request started');

    res.on('finish', () => {
      const duration = Date.now() - start;
      reqLogger.info({
        statusCode: res.statusCode,
        duration,
        contentLength: res.getHeader('content-length'),
      }, 'Request completed');
    });

    next();
  };
}

// Error logger
export function logError(error: Error, context?: Record<string, unknown>) {
  logger.error({
    err: {
      message: error.message,
      name: error.name,
      stack: error.stack,
    },
    ...context,
  }, 'Error occurred');
}

export type Logger = typeof logger;
TYPESCRIPT
)"

    _la_write_file "${project_dir}/src/lib/audit-logger.ts" "$(cat <<'TYPESCRIPT'
import { logger } from './logger';

interface AuditEntry {
  action: string;
  userId: string;
  resource: string;
  resourceId?: string;
  details?: Record<string, unknown>;
  ip?: string;
}

const auditLog = logger.child({ component: 'audit' });

export function logAudit(entry: AuditEntry): void {
  auditLog.info({
    ...entry,
    timestamp: new Date().toISOString(),
    type: 'AUDIT',
  }, `${entry.action} on ${entry.resource}`);
}

export function logLogin(userId: string, ip: string, success: boolean): void {
  logAudit({
    action: success ? 'LOGIN_SUCCESS' : 'LOGIN_FAILURE',
    userId,
    resource: 'auth',
    ip,
  });
}

export function logDataAccess(userId: string, resource: string, resourceId: string): void {
  logAudit({ action: 'DATA_ACCESS', userId, resource, resourceId });
}

export function logDataModify(userId: string, resource: string, resourceId: string, details: Record<string, unknown>): void {
  logAudit({ action: 'DATA_MODIFY', userId, resource, resourceId, details });
}
TYPESCRIPT
)"

    _la_log ok "Structured logger generated (Pino + audit)"
    LA_LOGGER_OK=true
    LA_GENERATED=$((LA_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate Log Aggregator Config (Fluent Bit / Loki)
# =============================================================================
_la_generate_aggregator() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local log_dir="${project_dir}/infra/logging"

    _la_log info "Generating log aggregation config..."

    # Fluent Bit config
    _la_write_file "${log_dir}/fluent-bit.conf" "[SERVICE]
    Flush        5
    Daemon       Off
    Log_Level    info
    Parsers_File parsers.conf

[INPUT]
    Name         tail
    Path         /var/log/app/*.log
    Parser       json
    Tag          app.*
    Refresh_Interval 5
    Mem_Buf_Limit 10MB

[FILTER]
    Name         modify
    Match        app.*
    Add          environment \${ENVIRONMENT}
    Add          service \${SERVICE_NAME}

[FILTER]
    Name         grep
    Match        app.*
    Exclude      level debug

[OUTPUT]
    Name         es
    Match        app.*
    Host         \${ES_HOST}
    Port         9200
    Index        app-logs
    Type         _doc
    Logstash_Format On
    Logstash_Prefix app
    Retry_Limit  3

[OUTPUT]
    Name         loki
    Match        app.*
    Host         \${LOKI_HOST}
    Port         3100
    Labels       job=app,environment=\${ENVIRONMENT}
    Auto_Kubernetes_Labels On
"

    # Parsers
    _la_write_file "${log_dir}/parsers.conf" "[PARSER]
    Name        json
    Format      json
    Time_Key    time
    Time_Format %Y-%m-%dT%H:%M:%S.%LZ
    Time_Keep   On

[PARSER]
    Name        docker
    Format      json
    Time_Key    time
    Time_Format %Y-%m-%dT%H:%M:%S.%L
"

    # Docker compose for log stack
    _la_write_file "${log_dir}/docker-compose.logging.yml" "version: '3.8'
services:
  loki:
    image: grafana/loki:2.9.0
    ports:
      - '3100:3100'
    volumes:
      - loki_data:/loki

  grafana:
    image: grafana/grafana:latest
    ports:
      - '3001:3000'
    environment:
      - GF_AUTH_ANONYMOUS_ENABLED=true
      - GF_AUTH_ANONYMOUS_ORG_ROLE=Admin
    volumes:
      - grafana_data:/var/lib/grafana

  fluent-bit:
    image: fluent/fluent-bit:latest
    volumes:
      - ./fluent-bit.conf:/fluent-bit/etc/fluent-bit.conf
      - ./parsers.conf:/fluent-bit/etc/parsers.conf
      - /var/log/app:/var/log/app:ro

volumes:
  loki_data:
  grafana_data:
"

    _la_log ok "Log aggregation config generated (Fluent Bit + Loki)"
    LA_AGGREGATOR_OK=true
    LA_GENERATED=$((LA_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate Log Search API
# =============================================================================
_la_generate_search() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _la_log info "Generating log search interface..."

    _la_write_file "${project_dir}/src/lib/log-search.ts" "$(cat <<'TYPESCRIPT'
interface LogSearchParams {
  query?: string;
  level?: 'debug' | 'info' | 'warn' | 'error' | 'fatal';
  from?: Date;
  to?: Date;
  service?: string;
  requestId?: string;
  limit?: number;
  offset?: number;
}

interface LogEntry {
  timestamp: string;
  level: string;
  message: string;
  service: string;
  requestId?: string;
  [key: string]: unknown;
}

export async function searchLogs(params: LogSearchParams): Promise<{ entries: LogEntry[]; total: number }> {
  const { query, level, from, to, service, requestId, limit = 100, offset = 0 } = params;

  const lokiQuery = buildLokiQuery({ level, service, requestId, query });
  const start = from?.toISOString() || new Date(Date.now() - 3600000).toISOString();
  const end = to?.toISOString() || new Date().toISOString();

  const response = await fetch(
    `${process.env.LOKI_URL}/loki/api/v1/query_range?` +
    new URLSearchParams({
      query: lokiQuery,
      start,
      end,
      limit: String(limit),
      direction: 'backward',
    })
  );

  if (!response.ok) throw new Error(`Loki query failed: ${response.statusText}`);

  const data = await response.json();
  const entries = (data.data?.result || []).flatMap((stream: any) =>
    stream.values.map(([ts, line]: [string, string]) => {
      try { return JSON.parse(line); } catch { return { timestamp: ts, message: line }; }
    })
  );

  return { entries: entries.slice(offset, offset + limit), total: entries.length };
}

function buildLokiQuery(params: Partial<LogSearchParams>): string {
  let q = '{job="app"';
  if (params.service) q += `,service="${params.service}"`;
  q += '}';
  if (params.level) q += ` |= "${params.level}"`;
  if (params.requestId) q += ` |= "${params.requestId}"`;
  if (params.query) q += ` |~ "${params.query}"`;
  return q;
}
TYPESCRIPT
)"

    _la_log ok "Log search interface generated"
    LA_SEARCH_OK=true
    LA_GENERATED=$((LA_GENERATED + 1))
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_la_report() {
    echo -e "\n  ${_LA_CYAN}=== Log Aggregation v${LA_VERSION} ===${_LA_NC}"
    echo -e "  Generated: ${LA_GENERATED} | Files: ${LA_FILES_WRITTEN} | Errors: ${LA_ERRORS}"
    echo -e "  Logger: $( ${LA_LOGGER_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Aggregator: $( ${LA_AGGREGATOR_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Search: $( ${LA_SEARCH_OK} && echo 'OK' || echo 'SKIP')"
}

_la_score() {
    local score=50
    ${LA_LOGGER_OK} && score=$((score + 15))
    ${LA_AGGREGATOR_OK} && score=$((score + 15))
    ${LA_SEARCH_OK} && score=$((score + 15))
    [[ ${LA_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "log-aggregation" --version "329.0" \
        --description "ログ集約 構造化ロガー/Fluent Bit/Loki/検索 (v329)" \
        --init "_la_init" --report "_la_report" --score "_la_score" \
        --enable-var "ENABLE_LOG_AGGREGATION" --cli-flags "--log-aggregation:--no-log-aggregation"
fi

# v2003.1: source時のexit codeを確実に0にする
true
