#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v13.0 - Test Runner Module
# =============================================================================
# 実テスト実行モジュール。プロジェクトのテストフレームワークを自動検出し、
# 実際にテストを実行して結果を構造化JSONで返す。カバレッジ計測・閾値チェック対応。
#
# 理論的バリデーションではなく、実際にテストを走らせてリアルな結果を取得する。
#
# 機能:
#   1. テストフレームワーク自動検出 (jest/vitest/pytest/mocha/go test/rspec)
#   2. テスト実行 & リアルタイム出力キャプチャ
#   3. テスト結果の構造化JSON解析 (pass/fail/error/skip)
#   4. カバレッジ計測 (lcov/istanbul/coverage.py 対応)
#   5. カバレッジ閾値チェック (pass/fail判定)
#   6. テスト実行レポート生成
#
# Usage: source lib/test-runner.sh
# =============================================================================

[[ -n "${_TR_LOADED:-}" ]] && return 0
_TR_LOADED=1

# カラー定義
TR_GREEN='\033[0;32m'   TR_YELLOW='\033[0;33m'  TR_RED='\033[0;31m'
TR_CYAN='\033[0;36m'    TR_BOLD='\033[1m'        TR_PURPLE='\033[0;35m'
TR_DIM='\033[2m'        TR_NC='\033[0m'

# モジュール状態
TR_PROJECT_DIR=""
TR_FRAMEWORK=""            # jest | vitest | pytest | mocha | go | rspec | cargo | unknown
TR_LOG_DIR=""
TR_LOG_FILE=""
TR_START_TIME=0

# テスト結果カウンタ
TR_TOTAL=0
TR_PASSED=0
TR_FAILED=0
TR_ERRORS=0
TR_SKIPPED=0
TR_DURATION=0

# カバレッジ
TR_COVERAGE_LINE=0
TR_COVERAGE_BRANCH=0
TR_COVERAGE_FUNC=0
TR_COVERAGE_STMT=0

# テスト出力バッファ
TR_RAW_OUTPUT=""
TR_RESULTS_JSON=""
TR_COVERAGE_JSON=""
TR_FAILURE_DETAILS=""

# Claude CLI タイムアウト
TR_CLAUDE_TIMEOUT="${TR_CLAUDE_TIMEOUT:-120}"

# =============================================================================
# ヘルパー関数
# =============================================================================
_tr_log() {
    local level="$1" msg="$2"
    local color="${TR_NC}"
    case "$level" in
        INFO)     color="${TR_CYAN}" ;;
        SUCCESS)  color="${TR_GREEN}" ;;
        WARN)     color="${TR_YELLOW}" ;;
        ERROR)    color="${TR_RED}" ;;
        RUN)      color="${TR_PURPLE}" ;;
    esac
    echo -e "  ${color}[TEST:${level}]${TR_NC} ${msg}"
    [[ -n "$TR_LOG_FILE" ]] && \
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [${level}] ${msg}" >> "$TR_LOG_FILE" 2>/dev/null || true
}

_tr_reset_counters() {
    TR_TOTAL=0; TR_PASSED=0; TR_FAILED=0; TR_ERRORS=0; TR_SKIPPED=0; TR_DURATION=0
    TR_COVERAGE_LINE=0; TR_COVERAGE_BRANCH=0; TR_COVERAGE_FUNC=0; TR_COVERAGE_STMT=0
    TR_RAW_OUTPUT=""; TR_RESULTS_JSON=""; TR_COVERAGE_JSON=""; TR_FAILURE_DETAILS=""
}

# Claude CLI呼び出し（リトライ付き）
_tr_call_claude() {
    local prompt="$1" retry=0
    while [[ "$retry" -lt 3 ]]; do
        retry=$((retry + 1))
        local result
        result=$(timeout "${TR_CLAUDE_TIMEOUT}" \
            claude -p --dangerously-skip-permissions \
            --output-format text "$prompt" 2>/dev/null || echo "")
        [[ -n "$result" ]] && { echo "$result"; return 0; }
        _tr_log "WARN" "Claude CLI応答なし (試行 ${retry}/3)"
        sleep $((retry * 2))
    done
    _tr_log "ERROR" "Claude CLI: 全リトライ失敗"
    return 1
}

# =============================================================================
# 1. 初期化
# =============================================================================
tr_init() {
    local project_dir="${1:-.}"
    project_dir="$(cd "$project_dir" 2>/dev/null && pwd)" || {
        _tr_log "ERROR" "ディレクトリが見つかりません: $1"
        return 1
    }

    TR_PROJECT_DIR="$project_dir"
    TR_LOG_DIR="${project_dir}/docs/chain-logs"
    TR_LOG_FILE="${TR_LOG_DIR}/test-runner_$(date +%Y%m%d_%H%M%S).log"
    TR_START_TIME=$(date +%s)

    mkdir -p "$TR_LOG_DIR" 2>/dev/null || true

    _tr_reset_counters

    # フレームワーク自動検出
    TR_FRAMEWORK=$(tr_detect_framework "$project_dir")

    _tr_log "INFO" "Test Runner v13.0 初期化完了"
    _tr_log "INFO" "プロジェクト: ${project_dir}"
    _tr_log "INFO" "検出フレームワーク: ${TR_FRAMEWORK}"

    return 0
}

# =============================================================================
# 2. テストフレームワーク検出
# =============================================================================
tr_detect_framework() {
    local pd="${1:-$TR_PROJECT_DIR}"
    [[ -z "$pd" || ! -d "$pd" ]] && { echo "unknown"; return 1; }

    # --- Node.js系 ---
    if [[ -f "${pd}/package.json" ]]; then
        local pkg_content
        pkg_content=$(cat "${pd}/package.json" 2>/dev/null || echo "{}")

        # vitest (vitest.config.ts or dependency)
        if [[ -f "${pd}/vitest.config.ts" ]] || [[ -f "${pd}/vitest.config.js" ]] || \
           echo "$pkg_content" | grep -q '"vitest"'; then
            echo "vitest"
            return 0
        fi

        # jest (jest.config.* or dependency)
        if [[ -f "${pd}/jest.config.js" ]] || [[ -f "${pd}/jest.config.ts" ]] || \
           [[ -f "${pd}/jest.config.mjs" ]] || [[ -f "${pd}/jest.config.cjs" ]] || \
           echo "$pkg_content" | grep -q '"jest"'; then
            echo "jest"
            return 0
        fi

        # mocha
        if [[ -f "${pd}/.mocharc.yml" ]] || [[ -f "${pd}/.mocharc.json" ]] || \
           echo "$pkg_content" | grep -q '"mocha"'; then
            echo "mocha"
            return 0
        fi

        # fallback: check scripts.test in package.json
        local test_script
        test_script=$(echo "$pkg_content" | grep -o '"test"[[:space:]]*:[[:space:]]*"[^"]*"' | head -1 || echo "")
        if echo "$test_script" | grep -q "vitest"; then
            echo "vitest"; return 0
        elif echo "$test_script" | grep -q "jest"; then
            echo "jest"; return 0
        elif echo "$test_script" | grep -q "mocha"; then
            echo "mocha"; return 0
        fi

        # Node project with no identifiable framework but has test dir
        if [[ -d "${pd}/test" ]] || [[ -d "${pd}/tests" ]] || [[ -d "${pd}/__tests__" ]]; then
            echo "jest"  # default to jest for Node projects
            return 0
        fi
    fi

    # --- Python ---
    if [[ -f "${pd}/pytest.ini" ]] || [[ -f "${pd}/pyproject.toml" ]] || \
       [[ -f "${pd}/setup.py" ]] || [[ -f "${pd}/setup.cfg" ]] || \
       [[ -f "${pd}/conftest.py" ]]; then
        echo "pytest"
        return 0
    fi
    if find "$pd" -maxdepth 3 -name "test_*.py" -not -path "*/node_modules/*" 2>/dev/null | head -1 | grep -q .; then
        echo "pytest"
        return 0
    fi

    # --- Go ---
    if [[ -f "${pd}/go.mod" ]]; then
        echo "go"
        return 0
    fi
    if find "$pd" -maxdepth 3 -name "*_test.go" 2>/dev/null | head -1 | grep -q .; then
        echo "go"
        return 0
    fi

    # --- Rust ---
    if [[ -f "${pd}/Cargo.toml" ]]; then
        echo "cargo"
        return 0
    fi

    # --- Ruby/RSpec ---
    if [[ -f "${pd}/Gemfile" ]] && grep -q "rspec" "${pd}/Gemfile" 2>/dev/null; then
        echo "rspec"
        return 0
    fi
    if [[ -d "${pd}/spec" ]] && [[ -f "${pd}/.rspec" ]]; then
        echo "rspec"
        return 0
    fi

    echo "unknown"
    return 0
}

# =============================================================================
# 3. テスト実行
# =============================================================================
tr_run_tests() {
    local pd="${1:-$TR_PROJECT_DIR}"
    [[ -z "$pd" || ! -d "$pd" ]] && { _tr_log "ERROR" "プロジェクトが未指定"; return 1; }

    local fw="${TR_FRAMEWORK}"
    [[ "$fw" == "unknown" ]] && fw=$(tr_detect_framework "$pd")
    TR_FRAMEWORK="$fw"

    _tr_log "RUN" "テスト実行開始: framework=${fw}"

    local test_start exit_code=0
    test_start=$(date +%s)

    local output_file="${TR_LOG_DIR}/test_output_$(date +%s).txt"

    case "$fw" in
        jest)
            _tr_log "RUN" "npm test (jest) 実行中..."
            TR_RAW_OUTPUT=$(cd "$pd" && npx jest --no-color --verbose --forceExit 2>&1) || exit_code=$?
            ;;
        vitest)
            _tr_log "RUN" "npx vitest run 実行中..."
            TR_RAW_OUTPUT=$(cd "$pd" && npx vitest run --reporter=verbose 2>&1) || exit_code=$?
            ;;
        mocha)
            _tr_log "RUN" "npx mocha 実行中..."
            TR_RAW_OUTPUT=$(cd "$pd" && npx mocha --recursive --reporter spec 2>&1) || exit_code=$?
            ;;
        pytest)
            _tr_log "RUN" "pytest 実行中..."
            TR_RAW_OUTPUT=$(cd "$pd" && python -m pytest -v --tb=short 2>&1) || exit_code=$?
            ;;
        go)
            _tr_log "RUN" "go test 実行中..."
            TR_RAW_OUTPUT=$(cd "$pd" && go test -v ./... 2>&1) || exit_code=$?
            ;;
        cargo)
            _tr_log "RUN" "cargo test 実行中..."
            TR_RAW_OUTPUT=$(cd "$pd" && cargo test 2>&1) || exit_code=$?
            ;;
        rspec)
            _tr_log "RUN" "rspec 実行中..."
            TR_RAW_OUTPUT=$(cd "$pd" && bundle exec rspec --format documentation 2>&1) || exit_code=$?
            ;;
        unknown)
            # Try npm test as fallback
            if [[ -f "${pd}/package.json" ]]; then
                _tr_log "WARN" "フレームワーク不明。npm test を試行..."
                TR_RAW_OUTPUT=$(cd "$pd" && npm test 2>&1) || exit_code=$?
            else
                _tr_log "ERROR" "テストフレームワークが検出できません"
                return 1
            fi
            ;;
    esac

    local test_end
    test_end=$(date +%s)
    TR_DURATION=$((test_end - test_start))

    # 生出力をログに保存
    echo "$TR_RAW_OUTPUT" > "$output_file" 2>/dev/null

    # 結果解析
    tr_parse_results "$TR_RAW_OUTPUT"

    if [[ "$exit_code" -eq 0 ]]; then
        _tr_log "SUCCESS" "全テスト通過 (${TR_PASSED}/${TR_TOTAL} passed, ${TR_DURATION}秒)"
    else
        _tr_log "ERROR" "テスト失敗あり (${TR_FAILED} failed, ${TR_ERRORS} errors out of ${TR_TOTAL}, ${TR_DURATION}秒)"
    fi

    return "$exit_code"
}

# =============================================================================
# 4. テスト結果解析 -> 構造化JSON
# =============================================================================
tr_parse_results() {
    local output="$1"

    TR_TOTAL=0; TR_PASSED=0; TR_FAILED=0; TR_ERRORS=0; TR_SKIPPED=0
    TR_FAILURE_DETAILS=""

    case "$TR_FRAMEWORK" in
        jest)
            _tr_parse_jest "$output"
            ;;
        vitest)
            _tr_parse_vitest "$output"
            ;;
        mocha)
            _tr_parse_mocha "$output"
            ;;
        pytest)
            _tr_parse_pytest "$output"
            ;;
        go)
            _tr_parse_go "$output"
            ;;
        cargo)
            _tr_parse_cargo "$output"
            ;;
        rspec)
            _tr_parse_rspec "$output"
            ;;
        *)
            _tr_parse_generic "$output"
            ;;
    esac

    # JSON結果生成
    TR_RESULTS_JSON=$(cat <<JSONEOF
{
  "framework": "${TR_FRAMEWORK}",
  "total": ${TR_TOTAL},
  "passed": ${TR_PASSED},
  "failed": ${TR_FAILED},
  "errors": ${TR_ERRORS},
  "skipped": ${TR_SKIPPED},
  "duration_seconds": ${TR_DURATION},
  "success": $([ "$TR_FAILED" -eq 0 ] && [ "$TR_ERRORS" -eq 0 ] && echo "true" || echo "false"),
  "pass_rate": $([ "$TR_TOTAL" -gt 0 ] && echo "$(( (TR_PASSED * 100) / TR_TOTAL ))" || echo "0"),
  "timestamp": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
}
JSONEOF
)

    echo "$TR_RESULTS_JSON"
}

# --- Jest パーサー ---
_tr_parse_jest() {
    local output="$1"

    # Jest summary line: Tests: X failed, Y skipped, Z passed, W total
    local summary_line
    summary_line=$(echo "$output" | grep -E "^Tests:" | tail -1)

    if [[ -n "$summary_line" ]]; then
        TR_FAILED=$(echo "$summary_line" | grep -oE '[0-9]+ failed' | grep -oE '[0-9]+' || echo "0")
        TR_SKIPPED=$(echo "$summary_line" | grep -oE '[0-9]+ skipped' | grep -oE '[0-9]+' || echo "0")
        TR_PASSED=$(echo "$summary_line" | grep -oE '[0-9]+ passed' | grep -oE '[0-9]+' || echo "0")
        TR_TOTAL=$(echo "$summary_line" | grep -oE '[0-9]+ total' | grep -oE '[0-9]+' || echo "0")
    else
        # Fallback: count PASS/FAIL markers
        TR_PASSED=$(echo "$output" | grep -c '✓\|PASS\| ✔' || echo "0")
        TR_FAILED=$(echo "$output" | grep -c '✕\|✗\|FAIL\| ✘' || echo "0")
        TR_TOTAL=$((TR_PASSED + TR_FAILED))
    fi
    [[ -z "$TR_FAILED" ]] && TR_FAILED=0
    [[ -z "$TR_PASSED" ]] && TR_PASSED=0
    [[ -z "$TR_SKIPPED" ]] && TR_SKIPPED=0
    [[ -z "$TR_TOTAL" ]] && TR_TOTAL=0

    # 失敗詳細を抽出
    TR_FAILURE_DETAILS=$(echo "$output" | grep -A 5 "● \|FAIL " || echo "")
}

# --- Vitest パーサー ---
_tr_parse_vitest() {
    local output="$1"

    # Vitest: Tests  X failed | Y passed (Z)
    local summary
    summary=$(echo "$output" | grep -E "Tests\s+" | tail -1)

    if [[ -n "$summary" ]]; then
        TR_FAILED=$(echo "$summary" | grep -oE '[0-9]+ failed' | grep -oE '[0-9]+' || echo "0")
        TR_PASSED=$(echo "$summary" | grep -oE '[0-9]+ passed' | grep -oE '[0-9]+' || echo "0")
        TR_SKIPPED=$(echo "$summary" | grep -oE '[0-9]+ skipped' | grep -oE '[0-9]+' || echo "0")
        TR_TOTAL=$((TR_PASSED + TR_FAILED + TR_SKIPPED))
    else
        TR_PASSED=$(echo "$output" | grep -c '✓\| ✔' || echo "0")
        TR_FAILED=$(echo "$output" | grep -c '×\|✗\| ✘' || echo "0")
        TR_TOTAL=$((TR_PASSED + TR_FAILED))
    fi
    [[ -z "$TR_FAILED" ]] && TR_FAILED=0
    [[ -z "$TR_PASSED" ]] && TR_PASSED=0
    [[ -z "$TR_SKIPPED" ]] && TR_SKIPPED=0

    TR_FAILURE_DETAILS=$(echo "$output" | grep -A 10 "FAIL\|AssertionError\|Error:" || echo "")
}

# --- Mocha パーサー ---
_tr_parse_mocha() {
    local output="$1"

    TR_PASSED=$(echo "$output" | grep -oE '[0-9]+ passing' | grep -oE '[0-9]+' || echo "0")
    TR_FAILED=$(echo "$output" | grep -oE '[0-9]+ failing' | grep -oE '[0-9]+' || echo "0")
    TR_SKIPPED=$(echo "$output" | grep -oE '[0-9]+ pending' | grep -oE '[0-9]+' || echo "0")
    [[ -z "$TR_PASSED" ]] && TR_PASSED=0
    [[ -z "$TR_FAILED" ]] && TR_FAILED=0
    [[ -z "$TR_SKIPPED" ]] && TR_SKIPPED=0
    TR_TOTAL=$((TR_PASSED + TR_FAILED + TR_SKIPPED))

    TR_FAILURE_DETAILS=$(echo "$output" | grep -A 8 "failing" || echo "")
}

# --- pytest パーサー ---
_tr_parse_pytest() {
    local output="$1"

    # pytest summary: X passed, Y failed, Z errors, W skipped
    local summary
    summary=$(echo "$output" | grep -E "=+ .*(passed|failed|error)" | tail -1)

    if [[ -n "$summary" ]]; then
        TR_PASSED=$(echo "$summary" | grep -oE '[0-9]+ passed' | grep -oE '[0-9]+' || echo "0")
        TR_FAILED=$(echo "$summary" | grep -oE '[0-9]+ failed' | grep -oE '[0-9]+' || echo "0")
        TR_ERRORS=$(echo "$summary" | grep -oE '[0-9]+ error' | grep -oE '[0-9]+' || echo "0")
        TR_SKIPPED=$(echo "$summary" | grep -oE '[0-9]+ skipped' | grep -oE '[0-9]+' || echo "0")
    else
        TR_PASSED=$(echo "$output" | grep -c "PASSED" || echo "0")
        TR_FAILED=$(echo "$output" | grep -c "FAILED" || echo "0")
        TR_ERRORS=$(echo "$output" | grep -c "ERROR" || echo "0")
    fi
    [[ -z "$TR_PASSED" ]] && TR_PASSED=0
    [[ -z "$TR_FAILED" ]] && TR_FAILED=0
    [[ -z "$TR_ERRORS" ]] && TR_ERRORS=0
    [[ -z "$TR_SKIPPED" ]] && TR_SKIPPED=0
    TR_TOTAL=$((TR_PASSED + TR_FAILED + TR_ERRORS + TR_SKIPPED))

    TR_FAILURE_DETAILS=$(echo "$output" | grep -A 10 "FAILED\|ERROR\|AssertionError" || echo "")
}

# --- Go test パーサー ---
_tr_parse_go() {
    local output="$1"

    TR_PASSED=$(echo "$output" | grep -c "^--- PASS:" || echo "0")
    TR_FAILED=$(echo "$output" | grep -c "^--- FAIL:" || echo "0")
    TR_SKIPPED=$(echo "$output" | grep -c "^--- SKIP:" || echo "0")
    [[ -z "$TR_PASSED" ]] && TR_PASSED=0
    [[ -z "$TR_FAILED" ]] && TR_FAILED=0
    [[ -z "$TR_SKIPPED" ]] && TR_SKIPPED=0
    TR_TOTAL=$((TR_PASSED + TR_FAILED + TR_SKIPPED))

    TR_FAILURE_DETAILS=$(echo "$output" | grep -A 5 "^--- FAIL:" || echo "")
}

# --- Cargo test パーサー ---
_tr_parse_cargo() {
    local output="$1"

    # test result: ok. X passed; Y failed; Z ignored; W measured; 0 filtered out
    local summary
    summary=$(echo "$output" | grep "^test result:" | tail -1)

    if [[ -n "$summary" ]]; then
        TR_PASSED=$(echo "$summary" | grep -oE '[0-9]+ passed' | grep -oE '[0-9]+' || echo "0")
        TR_FAILED=$(echo "$summary" | grep -oE '[0-9]+ failed' | grep -oE '[0-9]+' || echo "0")
        TR_SKIPPED=$(echo "$summary" | grep -oE '[0-9]+ ignored' | grep -oE '[0-9]+' || echo "0")
    fi
    [[ -z "$TR_PASSED" ]] && TR_PASSED=0
    [[ -z "$TR_FAILED" ]] && TR_FAILED=0
    [[ -z "$TR_SKIPPED" ]] && TR_SKIPPED=0
    TR_TOTAL=$((TR_PASSED + TR_FAILED + TR_SKIPPED))

    TR_FAILURE_DETAILS=$(echo "$output" | grep -B 2 -A 10 "^---- .* ----" || echo "")
}

# --- RSpec パーサー ---
_tr_parse_rspec() {
    local output="$1"

    # X examples, Y failures, Z pending
    local summary
    summary=$(echo "$output" | grep -E "[0-9]+ examples?" | tail -1)

    if [[ -n "$summary" ]]; then
        TR_TOTAL=$(echo "$summary" | grep -oE '^[0-9]+' || echo "0")
        TR_FAILED=$(echo "$summary" | grep -oE '[0-9]+ failures?' | grep -oE '[0-9]+' || echo "0")
        TR_SKIPPED=$(echo "$summary" | grep -oE '[0-9]+ pending' | grep -oE '[0-9]+' || echo "0")
    fi
    [[ -z "$TR_TOTAL" ]] && TR_TOTAL=0
    [[ -z "$TR_FAILED" ]] && TR_FAILED=0
    [[ -z "$TR_SKIPPED" ]] && TR_SKIPPED=0
    TR_PASSED=$((TR_TOTAL - TR_FAILED - TR_SKIPPED))
    [[ "$TR_PASSED" -lt 0 ]] && TR_PASSED=0

    TR_FAILURE_DETAILS=$(echo "$output" | grep -A 10 "Failure/Error:" || echo "")
}

# --- 汎用パーサー (fallback) ---
_tr_parse_generic() {
    local output="$1"

    # 汎用: pass/fail キーワードをカウント
    TR_PASSED=$(echo "$output" | grep -ciE 'pass(ed)?|ok$|✓|✔' || echo "0")
    TR_FAILED=$(echo "$output" | grep -ciE 'fail(ed)?|error|✗|✕|✘' || echo "0")
    [[ -z "$TR_PASSED" ]] && TR_PASSED=0
    [[ -z "$TR_FAILED" ]] && TR_FAILED=0
    TR_TOTAL=$((TR_PASSED + TR_FAILED))

    TR_FAILURE_DETAILS=$(echo "$output" | grep -iA 5 "fail\|error" | head -30 || echo "")
}

# =============================================================================
# 5. カバレッジ計測
# =============================================================================
tr_get_coverage() {
    local pd="${1:-$TR_PROJECT_DIR}"
    [[ -z "$pd" || ! -d "$pd" ]] && { _tr_log "ERROR" "プロジェクトが未指定"; return 1; }

    local fw="${TR_FRAMEWORK}"
    [[ "$fw" == "unknown" ]] && fw=$(tr_detect_framework "$pd")

    _tr_log "RUN" "カバレッジ計測開始: framework=${fw}"

    local cov_output="" exit_code=0

    case "$fw" in
        jest)
            _tr_log "RUN" "jest --coverage 実行中..."
            cov_output=$(cd "$pd" && npx jest --coverage --no-color --forceExit 2>&1) || exit_code=$?
            _tr_parse_jest_coverage "$pd" "$cov_output"
            ;;
        vitest)
            _tr_log "RUN" "vitest run --coverage 実行中..."
            cov_output=$(cd "$pd" && npx vitest run --coverage 2>&1) || exit_code=$?
            _tr_parse_istanbul_coverage "$pd"
            ;;
        pytest)
            _tr_log "RUN" "pytest --cov 実行中..."
            # Detect the main package name
            local pkg_name
            pkg_name=$(find "$pd" -maxdepth 2 -name "__init__.py" -not -path "*/test*" \
                       -not -path "*/.venv/*" -not -path "*/venv/*" 2>/dev/null | head -1 | xargs dirname 2>/dev/null | xargs basename 2>/dev/null || echo ".")
            cov_output=$(cd "$pd" && python -m pytest --cov="${pkg_name}" --cov-report=term-missing -v 2>&1) || exit_code=$?
            _tr_parse_pytest_coverage "$cov_output"
            ;;
        go)
            _tr_log "RUN" "go test -cover 実行中..."
            cov_output=$(cd "$pd" && go test -v -coverprofile=coverage.out ./... 2>&1) || exit_code=$?
            _tr_parse_go_coverage "$pd" "$cov_output"
            ;;
        *)
            _tr_log "WARN" "カバレッジ計測非対応: framework=${fw}"
            TR_COVERAGE_LINE=0; TR_COVERAGE_BRANCH=0; TR_COVERAGE_FUNC=0; TR_COVERAGE_STMT=0
            ;;
    esac

    # カバレッジJSON生成
    TR_COVERAGE_JSON=$(cat <<COVJSONEOF
{
  "framework": "${fw}",
  "line": ${TR_COVERAGE_LINE},
  "branch": ${TR_COVERAGE_BRANCH},
  "function": ${TR_COVERAGE_FUNC},
  "statement": ${TR_COVERAGE_STMT},
  "timestamp": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
}
COVJSONEOF
)

    _tr_log "INFO" "カバレッジ: Line=${TR_COVERAGE_LINE}% Branch=${TR_COVERAGE_BRANCH}% Func=${TR_COVERAGE_FUNC}% Stmt=${TR_COVERAGE_STMT}%"

    echo "$TR_COVERAGE_JSON"
    return "$exit_code"
}

# --- Jest カバレッジ解析 ---
_tr_parse_jest_coverage() {
    local pd="$1" output="$2"

    # Jest coverage summary: All files | XX.XX | XX.XX | XX.XX | XX.XX
    local summary
    summary=$(echo "$output" | grep -E "All files" | head -1)

    if [[ -n "$summary" ]]; then
        # Extract percentages from the table row
        local pcts
        pcts=$(echo "$summary" | grep -oE '[0-9]+\.?[0-9]*' | head -4)
        TR_COVERAGE_STMT=$(echo "$pcts" | sed -n '1p' | cut -d. -f1)
        TR_COVERAGE_BRANCH=$(echo "$pcts" | sed -n '2p' | cut -d. -f1)
        TR_COVERAGE_FUNC=$(echo "$pcts" | sed -n '3p' | cut -d. -f1)
        TR_COVERAGE_LINE=$(echo "$pcts" | sed -n '4p' | cut -d. -f1)
    fi

    # Fallback: parse lcov.info if available
    if [[ -z "$TR_COVERAGE_LINE" || "$TR_COVERAGE_LINE" == "0" ]]; then
        _tr_parse_lcov "${pd}/coverage/lcov.info"
    fi

    [[ -z "$TR_COVERAGE_LINE" ]] && TR_COVERAGE_LINE=0
    [[ -z "$TR_COVERAGE_BRANCH" ]] && TR_COVERAGE_BRANCH=0
    [[ -z "$TR_COVERAGE_FUNC" ]] && TR_COVERAGE_FUNC=0
    [[ -z "$TR_COVERAGE_STMT" ]] && TR_COVERAGE_STMT=0
}

# --- Istanbul (lcov) カバレッジ解析 ---
_tr_parse_istanbul_coverage() {
    local pd="$1"
    local lcov_file=""

    # Search common istanbul/vitest coverage output locations
    for candidate in \
        "${pd}/coverage/lcov.info" \
        "${pd}/coverage/lcov-report/index.html" \
        "${pd}/.coverage/lcov.info"; do
        [[ -f "$candidate" ]] && { lcov_file="$candidate"; break; }
    done

    if [[ -n "$lcov_file" && "$lcov_file" == *.info ]]; then
        _tr_parse_lcov "$lcov_file"
    else
        TR_COVERAGE_LINE=0; TR_COVERAGE_BRANCH=0; TR_COVERAGE_FUNC=0; TR_COVERAGE_STMT=0
    fi
}

# --- lcov.info パーサー ---
_tr_parse_lcov() {
    local lcov_file="$1"
    [[ ! -f "$lcov_file" ]] && return 1

    local lf=0 lh=0 bf=0 bh=0 ff=0 fh=0

    while IFS= read -r line; do
        case "$line" in
            LF:*) lf=$((lf + ${line#LF:})) ;;
            LH:*) lh=$((lh + ${line#LH:})) ;;
            BRF:*) bf=$((bf + ${line#BRF:})) ;;
            BRH:*) bh=$((bh + ${line#BRH:})) ;;
            FNF:*) ff=$((ff + ${line#FNF:})) ;;
            FNH:*) fh=$((fh + ${line#FNH:})) ;;
        esac
    done < "$lcov_file"

    [[ "$lf" -gt 0 ]] && TR_COVERAGE_LINE=$((lh * 100 / lf)) || TR_COVERAGE_LINE=0
    [[ "$bf" -gt 0 ]] && TR_COVERAGE_BRANCH=$((bh * 100 / bf)) || TR_COVERAGE_BRANCH=0
    [[ "$ff" -gt 0 ]] && TR_COVERAGE_FUNC=$((fh * 100 / ff)) || TR_COVERAGE_FUNC=0
    TR_COVERAGE_STMT="$TR_COVERAGE_LINE"  # lcov uses LF/LH for statements
}

# --- pytest カバレッジ解析 ---
_tr_parse_pytest_coverage() {
    local output="$1"

    # pytest-cov summary: TOTAL    XXX    XXX    XX%
    local total_line
    total_line=$(echo "$output" | grep "^TOTAL" | tail -1)

    if [[ -n "$total_line" ]]; then
        TR_COVERAGE_LINE=$(echo "$total_line" | grep -oE '[0-9]+%' | tail -1 | tr -d '%')
    fi
    [[ -z "$TR_COVERAGE_LINE" ]] && TR_COVERAGE_LINE=0
    TR_COVERAGE_STMT="$TR_COVERAGE_LINE"
    TR_COVERAGE_FUNC=0
    TR_COVERAGE_BRANCH=0
}

# --- Go カバレッジ解析 ---
_tr_parse_go_coverage() {
    local pd="$1" output="$2"

    # go test -cover output: coverage: XX.X% of statements
    local cov_pct
    cov_pct=$(echo "$output" | grep -oE 'coverage: [0-9]+\.?[0-9]*%' | grep -oE '[0-9]+\.?[0-9]*' | head -1)

    if [[ -n "$cov_pct" ]]; then
        TR_COVERAGE_STMT=$(echo "$cov_pct" | cut -d. -f1)
        TR_COVERAGE_LINE="$TR_COVERAGE_STMT"
    else
        TR_COVERAGE_STMT=0; TR_COVERAGE_LINE=0
    fi
    TR_COVERAGE_BRANCH=0; TR_COVERAGE_FUNC=0
}

# =============================================================================
# 6. カバレッジ閾値チェック
# =============================================================================
tr_check_coverage_threshold() {
    local coverage_pct="${1:-$TR_COVERAGE_LINE}"
    local threshold="${2:-80}"

    [[ -z "$coverage_pct" ]] && coverage_pct=0

    if [[ "$coverage_pct" -ge "$threshold" ]]; then
        _tr_log "SUCCESS" "カバレッジ閾値通過: ${coverage_pct}% >= ${threshold}%"
        echo "pass"
        return 0
    else
        _tr_log "ERROR" "カバレッジ閾値未達: ${coverage_pct}% < ${threshold}%"
        echo "fail"
        return 1
    fi
}

# =============================================================================
# 7. テスト実行レポート
# =============================================================================
tr_report() {
    local elapsed=$(( $(date +%s) - TR_START_TIME ))
    local pass_rate=0
    [[ "$TR_TOTAL" -gt 0 ]] && pass_rate=$(( (TR_PASSED * 100) / TR_TOTAL ))

    echo ""
    echo -e "${TR_BOLD}${TR_PURPLE}+=============================================+${TR_NC}"
    echo -e "${TR_BOLD}${TR_PURPLE}|       Test Runner Report (v13.0)            |${TR_NC}"
    echo -e "${TR_BOLD}${TR_PURPLE}+=============================================+${TR_NC}"
    echo -e "  フレームワーク: ${TR_FRAMEWORK}"
    echo -e "  プロジェクト: ${TR_PROJECT_DIR}"
    echo -e "  テスト合計: ${TR_TOTAL}"
    echo -e "  通過: ${TR_GREEN}${TR_PASSED}${TR_NC} | 失敗: ${TR_RED}${TR_FAILED}${TR_NC} | エラー: ${TR_RED}${TR_ERRORS}${TR_NC} | スキップ: ${TR_YELLOW}${TR_SKIPPED}${TR_NC}"
    echo -e "  通過率: ${pass_rate}%"
    echo -e "  テスト実行時間: ${TR_DURATION}秒"
    echo -e "  セッション経過: $((elapsed / 60))分$((elapsed % 60))秒"

    # カバレッジ情報
    if [[ -n "$TR_COVERAGE_JSON" ]]; then
        echo -e "  ${TR_BOLD}カバレッジ:${TR_NC}"
        echo -e "    Line: ${TR_COVERAGE_LINE}% | Branch: ${TR_COVERAGE_BRANCH}% | Func: ${TR_COVERAGE_FUNC}% | Stmt: ${TR_COVERAGE_STMT}%"
    fi

    # ステータス判定
    local status="TESTS FAILED" sc="${TR_RED}"
    if [[ "$TR_FAILED" -eq 0 && "$TR_ERRORS" -eq 0 ]]; then
        status="ALL TESTS PASSED"; sc="${TR_GREEN}"
    elif [[ "$TR_PASSED" -gt 0 ]]; then
        status="PARTIAL PASS"; sc="${TR_YELLOW}"
    fi
    echo -e "  ステータス: ${sc}${status}${TR_NC}"

    # 失敗詳細
    if [[ -n "$TR_FAILURE_DETAILS" && "$TR_FAILED" -gt 0 ]]; then
        echo -e "  ${TR_BOLD}${TR_RED}失敗詳細:${TR_NC}"
        echo "$TR_FAILURE_DETAILS" | head -20 | while IFS= read -r line; do
            echo -e "    ${TR_DIM}${line}${TR_NC}"
        done
        local total_lines
        total_lines=$(echo "$TR_FAILURE_DETAILS" | wc -l | tr -d ' ')
        [[ "$total_lines" -gt 20 ]] && echo -e "    ${TR_DIM}... (${total_lines} 行中 20行表示)${TR_NC}"
    fi

    echo -e "${TR_BOLD}${TR_PURPLE}+=============================================+${TR_NC}"

    # レポートファイル保存
    _tr_save_report "$elapsed" "$pass_rate" "$status"
}

# --- レポートファイル保存 ---
_tr_save_report() {
    local elapsed="$1" pass_rate="$2" status="$3"
    [[ -z "$TR_LOG_DIR" ]] && return

    local report_file="${TR_LOG_DIR}/test-report_$(date +%Y%m%d_%H%M%S).md"

    cat > "$report_file" 2>/dev/null << REPORTEOF
# Test Runner Report - SoloptiLink Chain v13.0

**日時**: $(date '+%Y-%m-%d %H:%M:%S')
**プロジェクト**: ${TR_PROJECT_DIR}
**フレームワーク**: ${TR_FRAMEWORK}
**ステータス**: ${status}

## テスト結果サマリー

| 項目 | 値 |
|------|-----|
| 合計 | ${TR_TOTAL} |
| 通過 | ${TR_PASSED} |
| 失敗 | ${TR_FAILED} |
| エラー | ${TR_ERRORS} |
| スキップ | ${TR_SKIPPED} |
| 通過率 | ${pass_rate}% |
| 実行時間 | ${TR_DURATION}秒 |

## カバレッジ

| メトリクス | 値 |
|-----------|-----|
| Line | ${TR_COVERAGE_LINE}% |
| Branch | ${TR_COVERAGE_BRANCH}% |
| Function | ${TR_COVERAGE_FUNC}% |
| Statement | ${TR_COVERAGE_STMT}% |

## 失敗詳細

\`\`\`
${TR_FAILURE_DETAILS:-なし}
\`\`\`

## JSON結果

\`\`\`json
${TR_RESULTS_JSON:-{}}
\`\`\`
REPORTEOF

    _tr_log "INFO" "レポート保存: ${report_file}"
}
