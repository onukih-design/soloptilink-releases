#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v404.0 - Voice Command Interface
# =============================================================================
# 音声コマンドUIの生成エンジン。Web Speech API統合コンポーネント・
# コマンドパーサー・アクション実行チェーンを自動生成する。
#
# Functions:
#   _vci_init              - 初期化
#   _vci_generate_voice_ui - 音声入力UIコンポーネント生成
#   _vci_parse_command     - 音声テキストをコマンドにパース
#   _vci_generate_actions  - コマンドからアクションチェーン生成
#   _vci_report            - レポート出力
#   _vci_score             - モジュールスコア(0-100)
#
# All globals use the VCI_ prefix.
# =============================================================================

[[ -n "${_VOICE_COMMAND_INTERFACE_LOADED:-}" ]] && return 0
_VOICE_COMMAND_INTERFACE_LOADED=1

declare -g VCI_VERSION="404.0"
declare -g VCI_INITIALIZED=false
declare -g VCI_STORE_DIR=""
declare -g VCI_UI_GENERATED=0
declare -g VCI_COMMANDS_PARSED=0
declare -g VCI_ACTIONS_GENERATED=0

declare -g -A _VCI_COMMAND_MAP=()   # command_pattern → action_type
declare -g -A _VCI_VOCAB=()         # domain → vocabulary_list
declare -g -a _VCI_SUPPORTED_LANGS=("en-US" "ja-JP" "zh-CN" "ko-KR" "es-ES" "fr-FR")

# =============================================================================
_vci_init() {
    local project_dir="${PROJECT_DIR:-.}"
    VCI_STORE_DIR="${project_dir}/.soloptilink/voice-cmd"
    mkdir -p "${VCI_STORE_DIR}/components" "${VCI_STORE_DIR}/grammars"

    # Default command patterns
    _VCI_COMMAND_MAP["navigate to *"]="navigation"
    _VCI_COMMAND_MAP["go to *"]="navigation"
    _VCI_COMMAND_MAP["open *"]="navigation"
    _VCI_COMMAND_MAP["search for *"]="search"
    _VCI_COMMAND_MAP["find *"]="search"
    _VCI_COMMAND_MAP["create new *"]="create"
    _VCI_COMMAND_MAP["add *"]="create"
    _VCI_COMMAND_MAP["delete *"]="delete"
    _VCI_COMMAND_MAP["remove *"]="delete"
    _VCI_COMMAND_MAP["update *"]="update"
    _VCI_COMMAND_MAP["edit *"]="update"
    _VCI_COMMAND_MAP["show *"]="display"
    _VCI_COMMAND_MAP["hide *"]="hide"
    _VCI_COMMAND_MAP["toggle *"]="toggle"
    _VCI_COMMAND_MAP["submit *"]="submit"
    _VCI_COMMAND_MAP["save *"]="save"
    _VCI_COMMAND_MAP["undo"]="undo"
    _VCI_COMMAND_MAP["redo"]="redo"
    _VCI_COMMAND_MAP["scroll down"]="scroll_down"
    _VCI_COMMAND_MAP["scroll up"]="scroll_up"

    VCI_INITIALIZED=true
    return 0
}

# =============================================================================
# _vci_generate_voice_ui - Generate voice input UI component
# =============================================================================
_vci_generate_voice_ui() {
    local component_name="${1:-VoiceCommand}"
    local language="${2:-en-US}"
    local style="${3:-floating}"  # floating|inline|modal

    [[ "$VCI_INITIALIZED" != "true" ]] && { echo "ERROR: VCI not initialized" >&2; return 1; }
    VCI_UI_GENERATED=$((VCI_UI_GENERATED + 1))

    cat <<VOICEEOF
'use client';

import { useState, useCallback, useRef, useEffect } from 'react';

interface ${component_name}Props {
  onCommand: (command: string, action: VoiceAction) => void;
  language?: string;
  continuous?: boolean;
  className?: string;
}

interface VoiceAction {
  type: string;
  target: string;
  params: Record<string, string>;
}

export function ${component_name}({
  onCommand,
  language = '${language}',
  continuous = false,
  className,
}: ${component_name}Props) {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState<string | null>(null);
  const recognitionRef = useRef<SpeechRecognition | null>(null);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    const SpeechRecognition =
      window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setError('Speech recognition not supported');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = language;
    recognition.continuous = continuous;
    recognition.interimResults = true;

    recognition.onresult = (event: SpeechRecognitionEvent) => {
      const current = event.results[event.results.length - 1];
      const text = current[0].transcript;
      setTranscript(text);

      if (current.isFinal) {
        const action = parseVoiceCommand(text);
        onCommand(text, action);
        if (!continuous) {
          setIsListening(false);
        }
      }
    };

    recognition.onerror = (event: SpeechRecognitionErrorEvent) => {
      setError(\`Voice error: \${event.error}\`);
      setIsListening(false);
    };

    recognition.onend = () => {
      if (!continuous) setIsListening(false);
    };

    recognitionRef.current = recognition;

    return () => { recognition.abort(); };
  }, [language, continuous, onCommand]);

  const toggleListening = useCallback(() => {
    if (!recognitionRef.current) return;
    if (isListening) {
      recognitionRef.current.stop();
      setIsListening(false);
    } else {
      setError(null);
      setTranscript('');
      recognitionRef.current.start();
      setIsListening(true);
    }
  }, [isListening]);

  return (
    <div className={\`voice-command ${className ?? ''}${style === 'floating' ? ' fixed bottom-4 right-4 z-50' : ''}\`}>
      <button
        onClick={toggleListening}
        className={\`p-3 rounded-full transition-all \${
          isListening
            ? 'bg-red-500 text-white animate-pulse'
            : 'bg-gray-100 hover:bg-gray-200 text-gray-700'
        }\`}
        aria-label={isListening ? 'Stop listening' : 'Start voice command'}
      >
        {isListening ? <MicOffIcon /> : <MicIcon />}
      </button>
      {transcript && (
        <div className="mt-2 p-2 bg-white rounded shadow text-sm">
          {transcript}
        </div>
      )}
      {error && (
        <div className="mt-1 text-xs text-red-500">{error}</div>
      )}
    </div>
  );
}

function parseVoiceCommand(text: string): VoiceAction {
  const lower = text.toLowerCase().trim();
  // Navigation
  if (/^(go to|navigate to|open)\s+/i.test(lower)) {
    const target = lower.replace(/^(go to|navigate to|open)\s+/i, '');
    return { type: 'navigation', target, params: {} };
  }
  // Search
  if (/^(search for|find|look for)\s+/i.test(lower)) {
    const target = lower.replace(/^(search for|find|look for)\s+/i, '');
    return { type: 'search', target, params: {} };
  }
  // CRUD
  if (/^(create|add|new)\s+/i.test(lower)) {
    const target = lower.replace(/^(create|add|new)\s+/i, '');
    return { type: 'create', target, params: {} };
  }
  if (/^(delete|remove)\s+/i.test(lower)) {
    const target = lower.replace(/^(delete|remove)\s+/i, '');
    return { type: 'delete', target, params: {} };
  }
  if (/^(update|edit|modify)\s+/i.test(lower)) {
    const target = lower.replace(/^(update|edit|modify)\s+/i, '');
    return { type: 'update', target, params: {} };
  }
  return { type: 'unknown', target: lower, params: {} };
}

function MicIcon() {
  return <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>;
}

function MicOffIcon() {
  return <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><line x1="1" y1="1" x2="23" y2="23"/><path d="M9 9v3a3 3 0 0 0 5.12 2.12M15 9.34V4a3 3 0 0 0-5.94-.6"/><path d="M17 16.95A7 7 0 0 1 5 12v-2m14 0v2c0 .76-.13 1.48-.35 2.17"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>;
}
VOICEEOF

    return 0
}

# =============================================================================
# _vci_parse_command - Parse voice text to command structure
# =============================================================================
_vci_parse_command() {
    local voice_text="$1"
    [[ -z "$voice_text" ]] && { echo "ERROR: Empty voice text" >&2; return 1; }

    VCI_COMMANDS_PARSED=$((VCI_COMMANDS_PARSED + 1))
    local lower
    lower=$(echo "$voice_text" | tr '[:upper:]' '[:lower:]')

    local action_type="unknown"
    local target=""

    for pattern in "${!_VCI_COMMAND_MAP[@]}"; do
        local regex_pattern
        regex_pattern=$(echo "$pattern" | sed 's/\*/\(.*\)/')
        if echo "$lower" | grep -qi "^${regex_pattern}$\|^${regex_pattern}"; then
            action_type="${_VCI_COMMAND_MAP[$pattern]}"
            target=$(echo "$lower" | sed "s/^${regex_pattern%\(.*\)}//" | sed 's/^\s*//')
            break
        fi
    done

    cat <<CMDEOF
{"action":"${action_type}","target":"${target}","original":"${voice_text}","confidence":0.85}
CMDEOF
    return 0
}

# =============================================================================
# _vci_generate_actions - Generate action chain from parsed command
# =============================================================================
_vci_generate_actions() {
    local action_type="$1"
    local target="$2"
    local context="${3:-}"

    VCI_ACTIONS_GENERATED=$((VCI_ACTIONS_GENERATED + 1))

    case "$action_type" in
        navigation)
            echo "router.push('/${target//[^a-zA-Z0-9-]/-}');"
            ;;
        search)
            echo "setSearchQuery('${target}'); await refetch();"
            ;;
        create)
            echo "router.push('/${target//[^a-zA-Z0-9-]/-}/new');"
            ;;
        delete)
            echo "if (confirm('Delete ${target}?')) { await deleteMutation('${target}'); }"
            ;;
        update)
            echo "router.push('/${target//[^a-zA-Z0-9-]/-}/edit');"
            ;;
        toggle)
            echo "setState(prev => ({ ...prev, ${target//[^a-zA-Z]/}: !prev.${target//[^a-zA-Z]/} }));"
            ;;
        scroll_down)
            echo "window.scrollBy({ top: 500, behavior: 'smooth' });"
            ;;
        scroll_up)
            echo "window.scrollBy({ top: -500, behavior: 'smooth' });"
            ;;
        undo)
            echo "history.undo();"
            ;;
        redo)
            echo "history.redo();"
            ;;
        *)
            echo "console.log('Unknown voice action:', '${action_type}', '${target}');"
            ;;
    esac
    return 0
}

# =============================================================================
# Report / Score
# =============================================================================
_vci_report() {
    echo -e "\n  ${BOLD:-}=== Voice Command Interface v${VCI_VERSION} ===${NC:-}"
    echo -e "  UI Generated    : ${VCI_UI_GENERATED}"
    echo -e "  Commands Parsed : ${VCI_COMMANDS_PARSED}"
    echo -e "  Actions Generated: ${VCI_ACTIONS_GENERATED}"
    echo -e "  Supported Langs : ${#_VCI_SUPPORTED_LANGS[@]}"
}

_vci_score() {
    local score=30
    [[ "$VCI_INITIALIZED" == "true" ]] && score=$((score + 20))
    [[ $VCI_UI_GENERATED -gt 0 ]] && score=$((score + 20))
    [[ $VCI_COMMANDS_PARSED -gt 0 ]] && score=$((score + 15))
    [[ $VCI_ACTIONS_GENERATED -gt 0 ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "voice-command-interface" \
        --version "404.0" \
        --description "音声コマンドUI生成・コマンドパース・アクション実行" \
        --init "_vci_init" \
        --report "_vci_report" \
        --score "_vci_score" \
        --enable-var "ENABLE_VCI" \
        --cli-flags "--voice-cmd:--no-voice-cmd"
fi

# v2003.1: source時のexit codeを確実に0にする
true
