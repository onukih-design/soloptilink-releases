#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v15.0 - Session State Persistence
# =============================================================================
# Enables cross-invocation session persistence and state serialization.
# Saves/restores CLI flags, phase completion status, agent registry,
# and context engine data between chain.sh invocations.
# =============================================================================

[[ -n "${_SESSION_STATE_LOADED:-}" ]] && return 0
_SESSION_STATE_LOADED=1

# ============================================================
# State
# ============================================================
declare -g SS_SESSION_ID=""
declare -g SS_STATE_FILE=""
declare -g SS_STATE_DIR=""
declare -g SS_RESTORED=0

# ============================================================
# Internal logger
# ============================================================
_ss_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    echo -e "  ${color}[SESSION-STATE]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize state store
# ============================================================
ss_init() {
    local session_id="${1:-${SESSION_ID:-unknown}}"

    SS_SESSION_ID="$session_id"
    SS_STATE_DIR="${SESSION_LOG_DIR:-/tmp}"
    SS_STATE_FILE="${SS_STATE_DIR}/session_state.json"
    SS_RESTORED=0

    mkdir -p "$SS_STATE_DIR" 2>/dev/null || true
    _ss_log "INFO" "セッション状態管理初期化: ${SS_SESSION_ID}"
}

# ============================================================
# Save current session state to JSON
# ============================================================
ss_save_state() {
    [[ -z "$SS_STATE_DIR" ]] && return 1

    local timestamp
    timestamp=$(date -u +%Y-%m-%dT%H:%M:%SZ 2>/dev/null || date +%Y-%m-%dT%H:%M:%SZ)

    # Collect phases completed
    local phases_json="[]"
    if [[ -n "${CTX_PHASE_STATUS:-}" ]] && declare -p CTX_PHASE_STATUS &>/dev/null 2>&1; then
        phases_json="["
        local first=1
        for phase in "${!CTX_PHASE_STATUS[@]}"; do
            [[ "${CTX_PHASE_STATUS[$phase]}" == "completed" ]] || continue
            [[ $first -eq 0 ]] && phases_json+=","
            phases_json+="\"${phase}\""
            first=0
        done
        phases_json+="]"
    fi

    # Collect cost info
    local cost_total="${COST_USD_TOTAL:-0.00}"
    local cost_calls="${COST_CALLS_TOTAL:-0}"

    # Build CLI flags JSON
    local pipeline="${PIPELINE_MODE:-auto}"
    local parallel="${ENABLE_PARALLEL:-false}"
    local deploy="${ENABLE_DEPLOY:-false}"
    local browser_test="${ENABLE_BROWSER_TEST:-false}"
    local security="${ENABLE_SECURITY:-true}"
    local agents="${ENABLE_AGENTS:-true}"
    local plugins="${ENABLE_PLUGINS:-true}"
    local structured="${ENABLE_STRUCTURED_OUTPUT:-false}"

    # Write state file
    cat > "$SS_STATE_FILE" <<SSJSON
{
  "version": "15.0",
  "session_id": "${SS_SESSION_ID}",
  "timestamp": "${timestamp}",
  "cli_flags": {
    "pipeline": "${pipeline}",
    "parallel": ${parallel},
    "deploy": ${deploy},
    "browser_test": ${browser_test},
    "security": ${security},
    "agents": ${agents},
    "plugins": ${plugins},
    "structured_output": ${structured}
  },
  "phases_completed": ${phases_json},
  "cost": {
    "total_usd": "${cost_total}",
    "total_calls": ${cost_calls}
  },
  "task_description": $(TASK_VAL="${TASK_DESC:-}" python3 -c "import json, os; print(json.dumps(os.environ.get('TASK_VAL', '')))" 2>/dev/null || echo '""')
}
SSJSON

    # Also save to global state index
    local global_index="${HOME}/.soloptilink/sessions_index.json"
    mkdir -p "${HOME}/.soloptilink" 2>/dev/null || true

    # Append session entry to index (simple append, not full JSON management)
    echo "{\"id\":\"${SS_SESSION_ID}\",\"timestamp\":\"${timestamp}\",\"dir\":\"${SS_STATE_DIR}\",\"task\":\"${TASK_DESC:-}\"}" \
        >> "$global_index" 2>/dev/null || true

    _ss_log "INFO" "セッション状態保存完了: ${SS_STATE_FILE}"
}

# ============================================================
# Restore state from a previous session
# ============================================================
ss_restore_state() {
    local target="${1:-latest}"

    local state_file=""

    if [[ "$target" == "latest" ]]; then
        state_file=$(_ss_find_latest_state)
    else
        # Find by session ID
        local logs_dir="${SCRIPT_DIR:-$(pwd)}/docs/chain-logs"
        if [[ -d "${logs_dir}/${target}" ]]; then
            state_file="${logs_dir}/${target}/session_state.json"
        fi
    fi

    if [[ -z "$state_file" || ! -f "$state_file" ]]; then
        _ss_log "WARN" "復元対象のセッション状態が見つかりません: ${target}"
        return 1
    fi

    # Parse and restore CLI flags (safe: no eval)
    if command -v python3 &>/dev/null; then
        local py_output
        py_output=$(python3 -c "
import json
with open('${state_file}') as f:
    d = json.load(f)
flags = d.get('cli_flags', {})
print(d.get('version', ''))
print(d.get('session_id', ''))
print(flags.get('parallel', 'false'))
print(flags.get('deploy', 'false'))
print(flags.get('browser_test', 'false'))
print(flags.get('security', 'true'))
print(d.get('task_description', ''))
" 2>/dev/null) || return 1

        # Read each line into variables
        local _restored_version _restored_session_id
        local _restored_parallel _restored_deploy _restored_browser_test
        local _restored_security _restored_task
        { read -r _restored_version
          read -r _restored_session_id
          read -r _restored_parallel
          read -r _restored_deploy
          read -r _restored_browser_test
          read -r _restored_security
          read -r _restored_task
        } <<< "$py_output"

        # Apply restored values if available
        [[ -n "$_restored_version" ]] && VERSION="$_restored_version"
        [[ -n "$_restored_task" ]] && TASK_DESC="$_restored_task"
        [[ "$_restored_parallel" == "true" ]] && ENABLE_PARALLEL="true"
        [[ "$_restored_deploy" == "true" ]] && ENABLE_DEPLOY="true"
        [[ "$_restored_browser_test" == "true" ]] && ENABLE_BROWSER_TEST="true"
        [[ "$_restored_security" == "false" ]] && ENABLE_SECURITY="false"
    fi

    SS_RESTORED=1
    _ss_log "INFO" "セッション状態復元完了: ${state_file}"
}

# ============================================================
# Save CLI flags (called during parse)
# ============================================================
ss_save_cli_flags() {
    # This is a lightweight save during CLI parsing
    # Full state save happens at session end via ss_save_state
    :
}

# ============================================================
# Restore CLI flags from saved state
# ============================================================
ss_restore_cli_flags() {
    ss_restore_state "${1:-latest}"
}

# ============================================================
# Get the last session ID
# ============================================================
ss_get_last_session() {
    local logs_dir="${SCRIPT_DIR:-$(pwd)}/docs/chain-logs"
    [[ ! -d "$logs_dir" ]] && return 1

    # Find most recent chain_* directory
    local latest
    latest=$(find "$logs_dir" -maxdepth 1 -type d -name "chain_*" 2>/dev/null | sort -r | head -1)
    [[ -z "$latest" ]] && return 1

    basename "$latest"
}

# ============================================================
# Internal: find the latest session_state.json
# ============================================================
_ss_find_latest_state() {
    local logs_dir="${SCRIPT_DIR:-$(pwd)}/docs/chain-logs"
    [[ ! -d "$logs_dir" ]] && return

    # Search in reverse chronological order
    local latest_dir
    latest_dir=$(find "$logs_dir" -maxdepth 1 -type d -name "chain_*" 2>/dev/null | sort -r | head -1)
    [[ -z "$latest_dir" ]] && return

    local state_file="${latest_dir}/session_state.json"
    [[ -f "$state_file" ]] && echo "$state_file"
}

# ============================================================
# Show session state info
# ============================================================
ss_show_state() {
    local target="${1:-latest}"

    if [[ "$target" == "latest" ]]; then
        local state_file
        state_file=$(_ss_find_latest_state)
        if [[ -z "$state_file" || ! -f "$state_file" ]]; then
            echo "保存済みセッション状態なし"
            return 1
        fi
    else
        local logs_dir="${SCRIPT_DIR:-$(pwd)}/docs/chain-logs"
        local state_file="${logs_dir}/${target}/session_state.json"
        [[ ! -f "$state_file" ]] && { echo "セッション状態なし: ${target}"; return 1; }
    fi

    echo -e "\n${BOLD:-}=== Session State ===${NC:-}"
    if command -v python3 &>/dev/null; then
        python3 -c "
import json
with open('${state_file}') as f:
    data = json.load(f)
print(f\"  Session ID:  {data.get('session_id', 'N/A')}\")
print(f\"  Version:     {data.get('version', 'N/A')}\")
print(f\"  Timestamp:   {data.get('timestamp', 'N/A')}\")
print(f\"  Task:        {data.get('task_description', 'N/A')}\")
flags = data.get('cli_flags', {})
print(f\"  Pipeline:    {flags.get('pipeline', 'N/A')}\")
print(f\"  Agents:      {flags.get('agents', 'N/A')}\")
print(f\"  Plugins:     {flags.get('plugins', 'N/A')}\")
phases = data.get('phases_completed', [])
print(f\"  Phases Done: {len(phases)} ({', '.join(phases[:5])}{'...' if len(phases)>5 else ''})\")
cost = data.get('cost', {})
print(f\"  Cost:        \${cost.get('total_usd', '0.00')} ({cost.get('total_calls', 0)} calls)\")
" 2>/dev/null
    else
        cat "$state_file"
    fi
}
