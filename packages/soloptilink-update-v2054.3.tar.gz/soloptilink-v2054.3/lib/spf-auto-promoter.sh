#!/usr/bin/env bash
# SoloptiLinkAI v2034.0 - SPF Auto-Promoter (SAP)
# 学習データ駆動: learning/solutions/index.jsonl の unproven テンプレを
# 「構造的に検証可能な状態」へ昇格させるための readiness 検査と
# dry-run 検証チェックリストを生成する。
#
# v2034.0 改修 (2026-05-12 学習データに基づく):
#   - admin-token の存在チェックだけでは「期限切れ」を検出できなかった
#     (ファイル mtime > 30 日 でも "ready" と判定 → 実走で 401 が頻発)
#   - feedback_admin_token_expiry.md (2026-05-10) で記録済み
#   → mtime ベースの age 判定を追加し blocked:admin_token_stale を返すよう拡張
#
# 設計方針:
#   - 読み取り専用 (destructive 操作は一切しない)
#   - DUE から呼び出され、レポートに inline で埋め込まれる
#   - 各 unproven エントリに対し signature 別に readiness check を実行
#   - 全前提が満たされたエントリを「promotion_candidate」として列挙
#   - 実際の昇格 (success_count++ / success_rate 更新) は IER/管理者が承認後実施
#
# 背景 (学習データ根拠 - 2026-05-11):
#   - 過去7日 distribution_blocker が STABLE=4 件のまま停滞
#   - SPF unproven=5 (うち4件が distribution_blocker_b1/b2/b4/b5)
#   - fortress_score 162 で停滞 → 解決テンプレ昇格経路の欠如が真因
#   - SAP が unproven→proven の半歩を構造化することでループ閉鎖

[[ -n "${_SPF_AUTO_PROMOTER_LOADED:-}" ]] && return 0
_SPF_AUTO_PROMOTER_LOADED=1

SAP_VERSION="2034.2"
SAP_HOME="${SOLOPTILINK_HOME:-$HOME/.soloptilink}"
SAP_INDEX="${SAP_HOME}/learning/solutions/index.jsonl"
SAP_OUT_DIR="${SAP_HOME}/.proposals"
SAP_TOKEN_STALE_DAYS="${SAP_TOKEN_STALE_DAYS:-30}"

mkdir -p "$SAP_OUT_DIR" 2>/dev/null || true

# ------------------------------------------------------------
# 内部ヘルパー: JSON 行からフィールド抽出
# ------------------------------------------------------------
_sap_field() {
    local line="$1" field="$2"
    echo "$line" | grep -oE "\"${field}\":[^,}]*" | head -1 \
        | sed -E "s/^\"${field}\"://; s/^\"//; s/\"$//"
}

# ------------------------------------------------------------
# Readiness check: signature ごとに前提条件の充足度を判定
# 出力: "ready" / "blocked:<reason>" / "skip"
# ------------------------------------------------------------
_sap_check_readiness() {
    local sig="$1"
    case "$sig" in
        distribution_blocker_b1_github_release_missing)
            # gh CLI と auth トークンが必要
            if ! command -v gh >/dev/null 2>&1; then
                echo "blocked:gh_cli_not_installed"
                return
            fi
            if ! gh auth status >/dev/null 2>&1; then
                echo "blocked:gh_auth_required"
                return
            fi
            echo "ready"
            ;;
        distribution_blocker_b2_system_settings_software_version|distribution_blocker_b4_system_settings_package_url|distribution_blocker_b5_system_settings_release_notes)
            # admin-dashboard 接続 + admin-token が必要
            local token_file="${SAP_HOME}/.admin-token"
            if [[ ! -f "$token_file" ]]; then
                echo "blocked:admin_token_missing"
                return
            fi
            # token expiry の簡易チェック (空でないこと)
            if [[ ! -s "$token_file" ]]; then
                echo "blocked:admin_token_empty"
                return
            fi
            # v2034.0: mtime ベース age 判定 (BSD/GNU stat 双方互換)
            local token_mtime token_age_days now_epoch
            token_mtime=$(stat -f %m "$token_file" 2>/dev/null || stat -c %Y "$token_file" 2>/dev/null || echo 0)
            now_epoch=$(date -u +%s)
            if [[ "$token_mtime" -gt 0 ]]; then
                token_age_days=$(( (now_epoch - token_mtime) / 86400 ))
                if (( token_age_days >= SAP_TOKEN_STALE_DAYS )); then
                    echo "blocked:admin_token_stale_${token_age_days}d"
                    return
                fi
            fi
            echo "ready"
            ;;
        import_error_cannot_find_module)
            # node + npm の存在のみ確認 (実行は IER 側)
            if ! command -v npm >/dev/null 2>&1; then
                echo "blocked:npm_not_installed"
                return
            fi
            echo "ready"
            ;;
        *)
            echo "skip"
            ;;
    esac
}

# ------------------------------------------------------------
# 検証コマンドテンプレート: signature ごとに dry-run 検証手順を返す
# ------------------------------------------------------------
_sap_verify_template() {
    local sig="$1"
    case "$sig" in
        distribution_blocker_b1_github_release_missing)
            cat <<'EOF'
# Dry-run verification (b1 GitHub Release):
gh release list --repo onukih-design/soloptilink-releases --limit 5
# 期待: 最新タグが本体 VERSION と一致していること
EOF
            ;;
        distribution_blocker_b2_system_settings_software_version)
            cat <<'EOF'
# Dry-run verification (b2 software_version):
curl -fsS -H "Authorization: Bearer $(cat ~/.soloptilink/.admin-token)" \
  https://admin.soloptilink.example.com/api/system-settings 2>/dev/null \
  | grep -o '"software_version":"[^"]*"' || echo "FETCH_FAILED"
# 期待: 本体 VERSION と一致する software_version が返ること
EOF
            ;;
        distribution_blocker_b4_system_settings_package_url)
            cat <<'EOF'
# Dry-run verification (b4 package_url):
curl -fsS -H "Authorization: Bearer $(cat ~/.soloptilink/.admin-token)" \
  https://admin.soloptilink.example.com/api/system-settings 2>/dev/null \
  | grep -o '"package_url":"[^"]*"' || echo "FETCH_FAILED"
# 期待: 新バージョン用 URL に更新されていること
EOF
            ;;
        distribution_blocker_b5_system_settings_release_notes)
            cat <<'EOF'
# Dry-run verification (b5 release_notes):
curl -fsS -H "Authorization: Bearer $(cat ~/.soloptilink/.admin-token)" \
  https://admin.soloptilink.example.com/api/system-settings 2>/dev/null \
  | grep -o '"release_notes":"[^"]*"' || echo "FETCH_FAILED"
# 期待: 空でない release_notes が返ること
EOF
            ;;
        import_error_cannot_find_module)
            cat <<'EOF'
# Dry-run verification (import_error structural template):
# 1) tsconfig.json paths を grep
# 2) package.json "imports"/"exports" を grep
# 3) ESM/CJS 差異 (.js 拡張子必須有無) を確認
# 4) npm ci でクリーン再構築 → tsc --noEmit で再現
# 5) 解消したら success_count++ → solutions/index.jsonl に反映
EOF
            ;;
        *)
            echo "# (no verification template for ${sig})"
            ;;
    esac
}

# ------------------------------------------------------------
# サマリ生成 (DUE から呼ばれる)
# ------------------------------------------------------------
sap_summary() {
    if [[ ! -f "$SAP_INDEX" ]]; then
        echo "- SAP: solutions/index.jsonl が未生成 (IER 未起動 or 学習データ無し)"
        return 0
    fi

    local unproven_total=0
    local ready_total=0
    local blocked_total=0
    local ready_list=()
    local blocked_list=()

    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        local sig rate
        sig=$(_sap_field "$line" "error_signature")
        rate=$(_sap_field "$line" "success_rate")
        # unproven 行のみ対象 (success_rate が null)
        [[ "$rate" == "null" ]] || continue
        unproven_total=$((unproven_total + 1))

        local status
        status=$(_sap_check_readiness "$sig")
        case "$status" in
            ready)
                ready_total=$((ready_total + 1))
                ready_list+=("${sig}")
                ;;
            blocked:*)
                blocked_total=$((blocked_total + 1))
                blocked_list+=("${sig} (${status#blocked:})")
                ;;
        esac
    done < "$SAP_INDEX"

    echo "- SAP unproven scanned: ${unproven_total} (ready=${ready_total} / blocked=${blocked_total})"
    if (( ready_total > 0 )); then
        echo "- promotion_candidate (前提充足 → 管理者が dry-run 検証して proven 化可能):"
        local s
        for s in "${ready_list[@]}"; do
            echo "    - ${s}"
        done
    fi
    if (( blocked_total > 0 )); then
        echo "- blocked (前提未充足 — 環境/トークン整備が必要):"
        local s
        for s in "${blocked_list[@]}"; do
            echo "    - ${s}"
        done
    fi
}

# ------------------------------------------------------------
# 詳細レポート出力 (個別ファイル): 各 ready 候補に対し検証手順を書き出す
# ------------------------------------------------------------
sap_emit_verification_checklist() {
    [[ -f "$SAP_INDEX" ]] || return 0

    local out
    out="${SAP_OUT_DIR}/sap_verify_$(date -u +%Y%m%dT%H%M%SZ).md"
    {
        echo "# SAP Verification Checklist (SAP v${SAP_VERSION})"
        echo
        echo "- generated_at: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
        echo "- source: ${SAP_INDEX}"
        echo
        echo "## unproven エントリの dry-run 検証手順"
        echo
    } > "$out"

    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        local sig rate status
        sig=$(_sap_field "$line" "error_signature")
        rate=$(_sap_field "$line" "success_rate")
        [[ "$rate" == "null" ]] || continue
        status=$(_sap_check_readiness "$sig")
        {
            echo "### ${sig}"
            echo "- readiness: ${status}"
            echo
            echo '```bash'
            _sap_verify_template "$sig"
            echo '```'
            echo
        } >> "$out"
    done < "$SAP_INDEX"

    echo "$out"
}

# CLI 直接実行
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-summary}" in
        summary) sap_summary ;;
        emit)    sap_emit_verification_checklist ;;
        version) echo "$SAP_VERSION" ;;
        *) echo "usage: $0 {summary|emit|version}" >&2; exit 2 ;;
    esac
fi
