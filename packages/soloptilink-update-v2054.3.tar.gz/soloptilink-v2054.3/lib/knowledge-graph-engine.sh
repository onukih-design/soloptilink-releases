#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v481.0 - Knowledge Graph Engine
# =============================================================================
# コードベース内のエンティティ間関係をグラフ構造で表現し、
# 依存関係の推論・影響範囲分析・リファクタリング提案を行う。
# ファイル→関数→型→APIルート→コンポーネントの全関係を追跡。
#
# Functions:
#   _kge_init               - 初期化
#   _kge_build_graph        - 知識グラフの構築
#   _kge_query_graph        - グラフへの問い合わせ
#   _kge_discover_relations - 暗黙の関係発見
#   _kge_reason             - グラフ推論
#   _kge_impact_analysis    - 影響範囲分析
#   _kge_report             - レポート出力
#   _kge_score              - モジュールスコア(0-100)
#
# Globals: KGE_ prefix
# =============================================================================

[[ -n "${_KNOWLEDGE_GRAPH_ENGINE_LOADED:-}" ]] && return 0
_KNOWLEDGE_GRAPH_ENGINE_LOADED=1

KGE_VERSION="481.0"
KGE_INITIALIZED=false

# --- Storage ---
KGE_DATA_DIR=""
KGE_GRAPH_FILE=""
KGE_QUERY_LOG=""

# --- State ---
KGE_TOTAL_NODES=0
KGE_TOTAL_EDGES=0
KGE_TOTAL_QUERIES=0
KGE_RELATIONS_DISCOVERED=0

# --- Graph Structure ---
declare -g -A _KGE_NODES=()          # node_id -> type:name
declare -g -A _KGE_NODE_TYPE=()      # node_id -> type
declare -g -A _KGE_NODE_FILE=()      # node_id -> file_path
declare -g -A _KGE_EDGES=()          # edge_id -> source:target:relation
declare -g -A _KGE_ADJACENCY=()      # node_id -> "neighbor1 neighbor2 ..."
declare -g -A _KGE_REVERSE_ADJ=()    # node_id -> "dependent1 dependent2 ..."

# Node types
declare -g -a KGE_NODE_TYPES=("file" "function" "component" "api_route" "model" "type" "hook" "middleware" "service")

# Edge relation types
declare -g -a KGE_RELATION_TYPES=("imports" "exports" "calls" "renders" "fetches" "extends" "implements" "uses" "depends_on")

# =============================================================================
# 初期化
# =============================================================================
_kge_init() {
    local project_dir="${PROJECT_DIR:-.}"
    KGE_DATA_DIR="${project_dir}/.soloptilink/kge"
    KGE_GRAPH_FILE="${KGE_DATA_DIR}/graph.jsonl"
    KGE_QUERY_LOG="${KGE_DATA_DIR}/queries.jsonl"

    mkdir -p "$KGE_DATA_DIR"

    if [[ -f "$KGE_GRAPH_FILE" ]]; then
        KGE_TOTAL_NODES=$(grep -c '"node"' "$KGE_GRAPH_FILE" 2>/dev/null || echo "0")
        KGE_TOTAL_EDGES=$(grep -c '"edge"' "$KGE_GRAPH_FILE" 2>/dev/null || echo "0")
    fi

    KGE_INITIALIZED=true
    return 0
}

# =============================================================================
# 知識グラフの構築
# =============================================================================
_kge_build_graph() {
    local project_dir="${1:-.}"

    [[ "$KGE_INITIALIZED" != "true" ]] && _kge_init
    [[ ! -d "$project_dir" ]] && return 1

    local node_id=0
    local edge_id=0

    # --- ファイルノードの作成 ---
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local rel_path="${file#$project_dir/}"
        local name
        name=$(basename "$file" .ts)
        name=$(basename "$name" .tsx)

        local type="file"
        case "$rel_path" in
            app/api/*)      type="api_route" ;;
            app/*)          [[ "$file" == *page.tsx ]] && type="component" ;;
            components/*)   type="component" ;;
            lib/*)          type="service" ;;
            hooks/*)        type="hook" ;;
            middleware*)     type="middleware" ;;
        esac

        _KGE_NODES["n${node_id}"]="${type}:${name}"
        _KGE_NODE_TYPE["n${node_id}"]="$type"
        _KGE_NODE_FILE["n${node_id}"]="$rel_path"

        echo "{\"type\":\"node\",\"id\":\"n${node_id}\",\"node_type\":\"${type}\",\"name\":\"${name}\",\"file\":\"${rel_path}\"}" >> "$KGE_GRAPH_FILE" 2>/dev/null

        node_id=$((node_id + 1))
    done < <(find "$project_dir" -name "*.ts" -o -name "*.tsx" 2>/dev/null | grep -v node_modules | grep -v ".next" | head -200)

    KGE_TOTAL_NODES=$node_id

    # --- エッジの構築(インポート関係) ---
    for src_id in "${!_KGE_NODE_FILE[@]}"; do
        local src_file="${project_dir}/${_KGE_NODE_FILE[$src_id]}"
        [[ ! -f "$src_file" ]] && continue

        # インポート文からの依存関係抽出
        while IFS= read -r import_line; do
            [[ -z "$import_line" ]] && continue
            local import_path
            import_path=$(echo "$import_line" | grep -oP "from ['\"]([^'\"]+)['\"]" | sed "s/from ['\"]//; s/['\"]//")
            [[ -z "$import_path" ]] && continue
            [[ "$import_path" == .* ]] || continue  # 相対パスのみ

            # インポート先のノードを検索
            for tgt_id in "${!_KGE_NODE_FILE[@]}"; do
                local tgt_file="${_KGE_NODE_FILE[$tgt_id]}"
                if [[ "$tgt_file" == *"${import_path##*/}"* ]]; then
                    _KGE_EDGES["e${edge_id}"]="${src_id}:${tgt_id}:imports"
                    _KGE_ADJACENCY["$src_id"]+="${tgt_id} "
                    _KGE_REVERSE_ADJ["$tgt_id"]+="${src_id} "

                    echo "{\"type\":\"edge\",\"id\":\"e${edge_id}\",\"src\":\"${src_id}\",\"tgt\":\"${tgt_id}\",\"relation\":\"imports\"}" >> "$KGE_GRAPH_FILE" 2>/dev/null

                    edge_id=$((edge_id + 1))
                    break
                fi
            done
        done < <(grep "^import " "$src_file" 2>/dev/null | head -30)
    done

    KGE_TOTAL_EDGES=$edge_id

    echo "${KGE_TOTAL_NODES}:${KGE_TOTAL_EDGES}"
    return 0
}

# =============================================================================
# グラフへの問い合わせ
# =============================================================================
_kge_query_graph() {
    local query_type="$1"
    local target="$2"

    [[ "$KGE_INITIALIZED" != "true" ]] && _kge_init

    KGE_TOTAL_QUERIES=$((KGE_TOTAL_QUERIES + 1))

    case "$query_type" in
        dependencies)
            # ノードの依存先を列挙
            local deps="${_KGE_ADJACENCY[$target]:-}"
            for dep in $deps; do
                echo "${_KGE_NODES[$dep]:-unknown} (${_KGE_NODE_FILE[$dep]:-})"
            done
            ;;
        dependents)
            # ノードに依存しているものを列挙
            local rdeps="${_KGE_REVERSE_ADJ[$target]:-}"
            for rdep in $rdeps; do
                echo "${_KGE_NODES[$rdep]:-unknown} (${_KGE_NODE_FILE[$rdep]:-})"
            done
            ;;
        type)
            # 特定タイプのノードを列挙
            for nid in "${!_KGE_NODE_TYPE[@]}"; do
                if [[ "${_KGE_NODE_TYPE[$nid]}" == "$target" ]]; then
                    echo "${nid}: ${_KGE_NODES[$nid]:-} (${_KGE_NODE_FILE[$nid]:-})"
                fi
            done
            ;;
        orphans)
            # 孤立ノード（依存もされていないノード）
            for nid in "${!_KGE_NODES[@]}"; do
                local has_edges=false
                [[ -n "${_KGE_ADJACENCY[$nid]:-}" ]] && has_edges=true
                [[ -n "${_KGE_REVERSE_ADJ[$nid]:-}" ]] && has_edges=true
                if [[ "$has_edges" == "false" ]]; then
                    echo "${nid}: ${_KGE_NODES[$nid]:-} (orphan)"
                fi
            done
            ;;
    esac

    return 0
}

# =============================================================================
# 暗黙の関係発見
# =============================================================================
_kge_discover_relations() {
    [[ "$KGE_INITIALIZED" != "true" ]] && _kge_init

    local discovered=0

    # API Route <-> Component の暗黙の関係（fetch URL一致）
    for nid in "${!_KGE_NODE_TYPE[@]}"; do
        [[ "${_KGE_NODE_TYPE[$nid]}" != "component" ]] && continue
        local file="${_KGE_NODE_FILE[$nid]:-}"
        [[ -z "$file" ]] && continue

        local full_path="${PROJECT_DIR:-.}/${file}"
        [[ ! -f "$full_path" ]] && continue

        # fetch/axios呼び出しからAPIパスを抽出
        local api_paths
        api_paths=$(grep -oP "fetch\(['\"]\/api\/[^'\"]*['\"]" "$full_path" 2>/dev/null | grep -oP "\/api\/[^'\"]*")

        for api_path in $api_paths; do
            # 対応するAPI Routeノードを検索
            for api_nid in "${!_KGE_NODE_TYPE[@]}"; do
                [[ "${_KGE_NODE_TYPE[$api_nid]}" != "api_route" ]] && continue
                local api_file="${_KGE_NODE_FILE[$api_nid]:-}"
                if [[ "$api_file" == *"${api_path}"* ]]; then
                    # 暗黙の fetches 関係を追加
                    _KGE_ADJACENCY["$nid"]+="${api_nid} "
                    _KGE_REVERSE_ADJ["$api_nid"]+="${nid} "
                    discovered=$((discovered + 1))
                fi
            done
        done
    done

    KGE_RELATIONS_DISCOVERED=$((KGE_RELATIONS_DISCOVERED + discovered))
    echo "$discovered"
    return 0
}

# =============================================================================
# グラフ推論
# =============================================================================
_kge_reason() {
    local question="$1"

    [[ "$KGE_INITIALIZED" != "true" ]] && _kge_init

    case "$question" in
        "circular_deps")
            # 循環依存の検出（簡易DFS）
            local cycles=0
            for nid in "${!_KGE_ADJACENCY[@]}"; do
                local deps="${_KGE_ADJACENCY[$nid]:-}"
                for dep in $deps; do
                    local reverse="${_KGE_ADJACENCY[$dep]:-}"
                    if [[ "$reverse" == *"$nid"* ]]; then
                        echo "[CYCLE] ${_KGE_NODES[$nid]:-} <-> ${_KGE_NODES[$dep]:-}"
                        cycles=$((cycles + 1))
                    fi
                done
            done
            echo "Total cycles: $cycles"
            ;;
        "hub_nodes")
            # 最も依存されているノード（ハブ）
            for nid in "${!_KGE_REVERSE_ADJ[@]}"; do
                local count
                count=$(echo "${_KGE_REVERSE_ADJ[$nid]}" | wc -w)
                if [[ $count -gt 3 ]]; then
                    echo "[HUB] ${_KGE_NODES[$nid]:-} (${count} dependents)"
                fi
            done
            ;;
        "isolated_modules")
            _kge_query_graph "orphans" ""
            ;;
    esac

    return 0
}

# =============================================================================
# 影響範囲分析
# =============================================================================
_kge_impact_analysis() {
    local changed_node="$1"

    [[ "$KGE_INITIALIZED" != "true" ]] && _kge_init

    echo "[Impact Analysis for ${_KGE_NODES[$changed_node]:-$changed_node}]"

    # 直接影響
    local direct="${_KGE_REVERSE_ADJ[$changed_node]:-}"
    echo "Direct impact (${direct:+$(echo $direct | wc -w)} files):"
    for dep in $direct; do
        echo "  - ${_KGE_NODES[$dep]:-} (${_KGE_NODE_FILE[$dep]:-})"
    done

    # 間接影響（2ホップ）
    echo "Indirect impact:"
    for dep in $direct; do
        local indirect="${_KGE_REVERSE_ADJ[$dep]:-}"
        for idep in $indirect; do
            [[ "$idep" == "$changed_node" ]] && continue
            echo "  - ${_KGE_NODES[$idep]:-} via ${_KGE_NODES[$dep]:-}"
        done
    done
}

# =============================================================================
# レポート
# =============================================================================
_kge_report() {
    echo -e "\n  ${BOLD:-}═══ Knowledge Graph Engine v${KGE_VERSION} ═══${NC:-}"
    echo -e "  ノード数           : ${KGE_TOTAL_NODES}"
    echo -e "  エッジ数           : ${KGE_TOTAL_EDGES}"
    echo -e "  クエリ数           : ${KGE_TOTAL_QUERIES}"
    echo -e "  発見された関係     : ${KGE_RELATIONS_DISCOVERED}"
}

_kge_score() {
    [[ "$KGE_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    local s=50
    [[ $KGE_TOTAL_NODES -gt 10 ]] && s=$((s + 15))
    [[ $KGE_TOTAL_EDGES -gt 5 ]] && s=$((s + 15))
    [[ $KGE_RELATIONS_DISCOVERED -gt 0 ]] && s=$((s + 20))
    [[ $s -gt 100 ]] && s=100
    echo "$s"
}

_kge_init_message() {
    echo -e "  ${GREEN:-}✅ v${KGE_VERSION} knowledge-graph-engine: 知識グラフエンジン (${KGE_TOTAL_NODES} nodes, ${KGE_TOTAL_EDGES} edges)${NC:-}" >&2
}

# =============================================================================
# Module Registry 登録
# =============================================================================
_mr_register \
    --name "knowledge-graph-engine" \
    --version "$KGE_VERSION" \
    --description "知識グラフエンジン" \
    --init "_kge_init" \
    --report "_kge_report" \
    --score "_kge_score" \
    --enable-var "ENABLE_KNOWLEDGE_GRAPH_ENGINE" \
    --cli-flags "--knowledge-graph-engine:--no-knowledge-graph-engine" \
    --init-msg "_kge_init_message"
