#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - Type Safety Enforcer
# =============================================================================
# TypeScript型安全性強化×any排除×strict mode×ブランド型×網羅チェック
#
# 機能:
#   - strict tsconfig.json 生成（noImplicitAny, strictNullChecks等）
#   - 共有API型生成（zod schemaからrequest/response型推論）
#   - ランタイム型ガード関数生成
#   - ブランド型（UserId, ProductId等のopaque type）
#   - 網羅的switch/caseパターン（exhaustive check）
#   - z.infer パターン（全モデルにzod→TS型推論）
#   - any型スキャン & レポート
#   - Claude生成プロンプト注入
#
# 全globals: TS_ / TSE_ prefix
# =============================================================================

[[ -n "${_TSE_LOADED:-}" ]] && return 0; _TSE_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g TS_VERSION="140.0"
declare -g TS_INITIALIZED=false
declare -g TSE_GENERATED=0
declare -g TSE_ERRORS=0
declare -g TSE_PHASE="type_safety"
declare -g TSE_ANY_COUNT=0

# =============================================================================
# 初期化
# =============================================================================
ts_init() {
    TS_INITIALIZED=true
    TSE_GENERATED=0
    TSE_ERRORS=0
    TSE_ANY_COUNT=0
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} Type Safety Enforcer v${TS_VERSION}"
}

# =============================================================================
# ユーティリティ
# =============================================================================
_ts_write_file() {
    local filepath="$1"
    local dir
    dir=$(dirname "$filepath")
    mkdir -p "$dir" 2>/dev/null
    cat > "$filepath"
    if [[ $? -eq 0 ]]; then
        TSE_GENERATED=$((TSE_GENERATED + 1))
        return 0
    else
        TSE_ERRORS=$((TSE_ERRORS + 1))
        return 1
    fi
}

# =============================================================================
# Strict tsconfig.json 生成
# =============================================================================
ts_generate_strict_config() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ts_write_file "${project_dir}/tsconfig.json" <<'JSON'
{
  "$schema": "https://json.schemastore.org/tsconfig",
  "compilerOptions": {
    /* Strict Type-Checking */
    "strict": true,
    "noImplicitAny": true,
    "strictNullChecks": true,
    "strictFunctionTypes": true,
    "strictBindCallApply": true,
    "strictPropertyInitialization": true,
    "noImplicitThis": true,
    "alwaysStrict": true,
    "useUnknownInCatchVariables": true,

    /* Additional Checks */
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "exactOptionalPropertyTypes": false,
    "noImplicitReturns": true,
    "noFallthroughCasesInSwitch": true,
    "noUncheckedIndexedAccess": true,
    "noImplicitOverride": true,
    "noPropertyAccessFromIndexSignature": true,

    /* Module */
    "target": "ES2022",
    "lib": ["dom", "dom.iterable", "esnext"],
    "module": "esnext",
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "esModuleInterop": true,
    "allowSyntheticDefaultImports": true,

    /* JSX */
    "jsx": "preserve",

    /* Output */
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true,
    "noEmit": true,
    "incremental": true,
    "skipLibCheck": true,

    /* Paths */
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"]
    },

    /* Plugins */
    "plugins": [
      { "name": "next" }
    ]
  },
  "include": [
    "next-env.d.ts",
    "**/*.ts",
    "**/*.tsx",
    ".next/types/**/*.ts"
  ],
  "exclude": [
    "node_modules",
    ".next",
    "out",
    "dist"
  ]
}
JSON
}

# =============================================================================
# 共有API型生成（zod schemaからrequest/response型推論）
# =============================================================================
ts_generate_api_types() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ts_write_file "${project_dir}/src/types/api.ts" <<'TYPESCRIPT'
import { z } from 'zod';

// =============================================================================
// Base Response Types
// =============================================================================
export const apiSuccessSchema = <T extends z.ZodType>(dataSchema: T) =>
  z.object({
    data: dataSchema,
    meta: z.object({
      total: z.number().optional(),
      page: z.number().optional(),
      limit: z.number().optional(),
    }).optional(),
  });

export const apiErrorSchema = z.object({
  error: z.string(),
  details: z.array(z.object({
    path: z.array(z.string()),
    message: z.string(),
  })).optional(),
  code: z.string().optional(),
});

export type ApiSuccess<T> = { data: T; meta?: { total?: number; page?: number; limit?: number } };
export type ApiError = z.infer<typeof apiErrorSchema>;
export type ApiResponse<T> = ApiSuccess<T> | ApiError;

// =============================================================================
// Pagination
// =============================================================================
export const paginationSchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  sortBy: z.string().optional(),
  sortOrder: z.enum(['asc', 'desc']).default('desc'),
  search: z.string().optional(),
});
export type PaginationParams = z.infer<typeof paginationSchema>;

// =============================================================================
// ID types (use with Branded types for full safety)
// =============================================================================
export const idParamSchema = z.object({
  id: z.string().min(1),
});
export type IdParam = z.infer<typeof idParamSchema>;

// =============================================================================
// Utility: Extract input/output types from zod schemas
// =============================================================================
export type SchemaInput<T extends z.ZodType> = z.input<T>;
export type SchemaOutput<T extends z.ZodType> = z.output<T>;

/**
 * Helper to create typed API fetcher.
 * Usage:
 *   const getUsers = createApiFetcher<User[]>('/api/users');
 *   const { data } = await getUsers({ page: 1, limit: 10 });
 */
export function createApiFetcher<TData>(
  url: string,
  defaultOptions?: RequestInit
) {
  return async (params?: Record<string, string | number | boolean>): Promise<ApiSuccess<TData>> => {
    const searchParams = new URLSearchParams();
    if (params) {
      for (const [key, value] of Object.entries(params)) {
        searchParams.set(key, String(value));
      }
    }
    const queryString = searchParams.toString();
    const fullUrl = queryString ? `${url}?${queryString}` : url;

    const res = await fetch(fullUrl, {
      ...defaultOptions,
      headers: { 'Content-Type': 'application/json', ...defaultOptions?.headers },
    });

    if (!res.ok) {
      const err = await res.json().catch(() => ({ error: `HTTP ${res.status}` }));
      throw new Error(err.error ?? `HTTP ${res.status}`);
    }

    return res.json() as Promise<ApiSuccess<TData>>;
  };
}
TYPESCRIPT
}

# =============================================================================
# ランタイム型ガード生成
# =============================================================================
ts_generate_type_guards() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ts_write_file "${project_dir}/src/types/guards.ts" <<'TYPESCRIPT'
/**
 * Runtime type guard functions.
 * Use these to narrow types at runtime boundaries (API responses, user input, etc.)
 */

export function isString(value: unknown): value is string {
  return typeof value === 'string';
}

export function isNumber(value: unknown): value is number {
  return typeof value === 'number' && !isNaN(value);
}

export function isBoolean(value: unknown): value is boolean {
  return typeof value === 'boolean';
}

export function isNonNullable<T>(value: T): value is NonNullable<T> {
  return value !== null && value !== undefined;
}

export function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

export function isArrayOf<T>(value: unknown, guard: (item: unknown) => item is T): value is T[] {
  return Array.isArray(value) && value.every(guard);
}

export function hasProperty<K extends string>(
  obj: unknown,
  key: K
): obj is Record<K, unknown> {
  return isRecord(obj) && key in obj;
}

/**
 * Assert a value matches a type guard, throwing if it doesn't.
 */
export function assertType<T>(
  value: unknown,
  guard: (v: unknown) => v is T,
  message?: string
): asserts value is T {
  if (!guard(value)) {
    throw new TypeError(message ?? `Type assertion failed: expected ${guard.name}, got ${typeof value}`);
  }
}

/**
 * Safely parse JSON and validate with a type guard.
 */
export function safeJsonParse<T>(
  json: string,
  guard: (v: unknown) => v is T
): T | null {
  try {
    const parsed = JSON.parse(json);
    return guard(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

/**
 * API response guard.
 */
export function isApiError(response: unknown): response is { error: string } {
  return isRecord(response) && isString(response.error);
}

export function isApiSuccess<T>(response: unknown): response is { data: T } {
  return isRecord(response) && 'data' in response;
}
TYPESCRIPT
}

# =============================================================================
# ブランド型生成（Opaque types for IDs）
# =============================================================================
ts_generate_branded_types() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ts_write_file "${project_dir}/src/types/branded.ts" <<'TYPESCRIPT'
/**
 * Branded/Opaque types for type-safe IDs.
 *
 * Prevents mixing up different ID types:
 *   const userId: UserId = 'abc';     // OK
 *   const productId: ProductId = userId; // Type error!
 *
 * Usage:
 *   type UserId = Brand<string, 'UserId'>;
 *   const userId = 'abc' as UserId;
 */

declare const __brand: unique symbol;

/**
 * Brand utility type - creates a nominal type from a base type.
 */
export type Brand<TBase, TBrand extends string> = TBase & {
  readonly [__brand]: TBrand;
};

// --- Common branded ID types ---
export type UserId = Brand<string, 'UserId'>;
export type ProductId = Brand<string, 'ProductId'>;
export type OrderId = Brand<string, 'OrderId'>;
export type SessionId = Brand<string, 'SessionId'>;
export type CompanyId = Brand<string, 'CompanyId'>;
export type InvoiceId = Brand<string, 'InvoiceId'>;
export type TaskId = Brand<string, 'TaskId'>;
export type ProjectId = Brand<string, 'ProjectId'>;

// --- Branded constructors (with optional validation) ---
export function createUserId(id: string): UserId {
  if (!id || id.trim().length === 0) throw new Error('Invalid UserId: empty string');
  return id as UserId;
}

export function createProductId(id: string): ProductId {
  if (!id || id.trim().length === 0) throw new Error('Invalid ProductId: empty string');
  return id as ProductId;
}

export function createOrderId(id: string): OrderId {
  if (!id || id.trim().length === 0) throw new Error('Invalid OrderId: empty string');
  return id as OrderId;
}

// --- Branded value types ---
export type Email = Brand<string, 'Email'>;
export type URL = Brand<string, 'URL'>;
export type PositiveInteger = Brand<number, 'PositiveInteger'>;
export type Percentage = Brand<number, 'Percentage'>;

export function createEmail(value: string): Email {
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
    throw new Error(`Invalid email: ${value}`);
  }
  return value as Email;
}

export function createPositiveInteger(value: number): PositiveInteger {
  if (!Number.isInteger(value) || value <= 0) {
    throw new Error(`Invalid positive integer: ${value}`);
  }
  return value as PositiveInteger;
}

export function createPercentage(value: number): Percentage {
  if (value < 0 || value > 100) {
    throw new Error(`Invalid percentage: ${value} (must be 0-100)`);
  }
  return value as Percentage;
}
TYPESCRIPT
}

# =============================================================================
# 網羅的switch/caseパターン
# =============================================================================
ts_generate_exhaustive_check() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ts_write_file "${project_dir}/src/types/exhaustive.ts" <<'TYPESCRIPT'
/**
 * Exhaustive check utility for TypeScript discriminated unions.
 *
 * Ensures all cases in a union are handled in switch statements.
 * If a new variant is added but not handled, TypeScript will report a compile error.
 *
 * Usage:
 *   type Status = 'active' | 'inactive' | 'pending';
 *
 *   function getLabel(status: Status): string {
 *     switch (status) {
 *       case 'active': return 'Active';
 *       case 'inactive': return 'Inactive';
 *       case 'pending': return 'Pending';
 *       default: return exhaustiveCheck(status);
 *     }
 *   }
 */

/**
 * Compile-time exhaustiveness check.
 * The `never` parameter ensures all union cases are handled.
 */
export function exhaustiveCheck(value: never, message?: string): never {
  throw new Error(message ?? `Unhandled discriminated union member: ${JSON.stringify(value)}`);
}

/**
 * Assert exhaustive check with a default return value.
 * Useful when you want a fallback instead of throwing.
 */
export function exhaustiveCheckWithDefault<T>(value: never, defaultValue: T): T {
  console.warn(`Unhandled discriminated union member: ${JSON.stringify(value)}, using default`);
  return defaultValue;
}

/**
 * Type-safe object mapper for discriminated unions.
 * Ensures all variants are mapped at compile time.
 *
 * Usage:
 *   type Role = 'admin' | 'user' | 'guest';
 *   const roleLabels = mapUnion<Role, string>({
 *     admin: 'Administrator',
 *     user: 'User',
 *     guest: 'Guest',
 *   });
 *   roleLabels.admin; // 'Administrator'
 */
export function mapUnion<TKey extends string, TValue>(
  mapping: Record<TKey, TValue>
): Readonly<Record<TKey, TValue>> {
  return Object.freeze(mapping);
}

/**
 * Type-safe switch utility using a mapping object.
 *
 * Usage:
 *   const result = match(status, {
 *     active: () => handleActive(),
 *     inactive: () => handleInactive(),
 *     pending: () => handlePending(),
 *   });
 */
export function match<TKey extends string, TResult>(
  value: TKey,
  handlers: Record<TKey, () => TResult>
): TResult {
  const handler = handlers[value];
  if (!handler) {
    throw new Error(`No handler for value: ${JSON.stringify(value)}`);
  }
  return handler();
}
TYPESCRIPT
}

# =============================================================================
# z.infer パターン生成
# =============================================================================
ts_generate_zod_inference() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ts_write_file "${project_dir}/src/types/schemas.ts" <<'TYPESCRIPT'
/**
 * Central schema + type definitions.
 * Single source of truth: define zod schema, infer TypeScript type.
 *
 * Pattern: Schema first, type second (always derived via z.infer).
 * NEVER define types manually if a zod schema exists.
 */
import { z } from 'zod';

// =============================================================================
// Base schemas (reusable)
// =============================================================================
export const idSchema = z.string().cuid();
export const emailSchema = z.string().email().toLowerCase().trim();
export const passwordSchema = z.string().min(8).max(128);
export const timestampSchema = z.string().datetime();
export const urlSchema = z.string().url();

// =============================================================================
// User
// =============================================================================
export const userSchema = z.object({
  id: idSchema,
  email: emailSchema,
  name: z.string().min(1).max(100),
  role: z.enum(['admin', 'user']),
  createdAt: timestampSchema,
  updatedAt: timestampSchema,
});
export type User = z.infer<typeof userSchema>;

export const createUserSchema = userSchema.pick({ email: true, name: true }).extend({
  password: passwordSchema,
});
export type CreateUserInput = z.infer<typeof createUserSchema>;

export const updateUserSchema = userSchema.pick({ name: true, role: true }).partial();
export type UpdateUserInput = z.infer<typeof updateUserSchema>;

// =============================================================================
// Pattern: Schema factory for CRUD operations
// =============================================================================
export function createCrudSchemas<T extends z.ZodRawShape>(
  baseShape: T,
  idField: keyof T = 'id' as keyof T
) {
  const baseSchema = z.object(baseShape);
  type Base = z.infer<typeof baseSchema>;

  const createSchema = baseSchema.omit({ [idField]: true, createdAt: true, updatedAt: true } as Record<string, true>);
  const updateSchema = createSchema.partial();
  const listSchema = z.object({
    data: z.array(baseSchema),
    total: z.number(),
    page: z.number(),
    limit: z.number(),
  });

  return {
    baseSchema,
    createSchema,
    updateSchema,
    listSchema,
  } as const;
}

// =============================================================================
// Pattern: Validate unknown data with schema
// =============================================================================
export function parseOrThrow<T extends z.ZodType>(
  schema: T,
  data: unknown,
  errorMessage?: string
): z.infer<T> {
  const result = schema.safeParse(data);
  if (!result.success) {
    const details = result.error.errors.map(e => `${e.path.join('.')}: ${e.message}`).join(', ');
    throw new Error(errorMessage ?? `Validation failed: ${details}`);
  }
  return result.data;
}

export function parseOrNull<T extends z.ZodType>(
  schema: T,
  data: unknown
): z.infer<T> | null {
  const result = schema.safeParse(data);
  return result.success ? result.data : null;
}
TYPESCRIPT
}

# =============================================================================
# any型スキャン
# =============================================================================
ts_verify_no_any() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    TSE_ANY_COUNT=0
    local report=""

    if [[ ! -d "$project_dir" ]]; then
        echo "0"
        return 0
    fi

    local files
    files=$(find "$project_dir" -name '*.ts' -o -name '*.tsx' 2>/dev/null | grep -v node_modules | grep -v '.next' | grep -v 'dist' || true)

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        # Match ": any", "as any", "<any>", "any[]", "Record<string, any>"
        local matches
        matches=$(grep -nE ':\s*any\b|as\s+any\b|<any>|any\[\]|,\s*any>' "$file" 2>/dev/null | grep -v '// @ts-ignore' | grep -v '// eslint-disable' || true)
        if [[ -n "$matches" ]]; then
            local count
            count=$(echo "$matches" | wc -l | tr -d ' ')
            TSE_ANY_COUNT=$((TSE_ANY_COUNT + count))
            local rel_path="${file#${project_dir}/}"
            report+="  ${rel_path}: ${count} any usage(s)\n"
        fi
    done <<< "$files"

    if [[ ${TSE_ANY_COUNT} -gt 0 ]]; then
        echo -e "[type-safety] WARNING: Found ${TSE_ANY_COUNT} 'any' type usage(s):"
        echo -e "$report"
    else
        echo "[type-safety] No 'any' type usage found - type safety is clean."
    fi

    echo "${TSE_ANY_COUNT}"
}

# =============================================================================
# Claudeプロンプト注入
# =============================================================================
ts_inject_type_patterns() {
    local prompt="${1:-}"

    cat <<'INJECTION'

## [Type Safety Patterns] 型安全性ルール

### 絶対禁止:
1. `: any` - 全箇所で具体型を指定（unknown → 型ガード → narrow）
2. `as any` - 型アサーション回避（zodでパース or 型ガード使用）
3. `@ts-ignore` / `@ts-expect-error` - 根本原因を修正

### 必須パターン:
1. **zod → 型推論**: `type User = z.infer<typeof userSchema>` （手動型定義禁止）
2. **ブランド型**: `type UserId = Brand<string, 'UserId'>` でID混同防止
3. **網羅チェック**: switch文の default に `exhaustiveCheck(value)` 必須
4. **型ガード**: API境界で `isRecord()`, `hasProperty()` による検証
5. **strict tsconfig**: `strict: true`, `noUncheckedIndexedAccess: true`

### API型:
- Request: `z.infer<typeof createXxxSchema>`
- Response: `ApiSuccess<Xxx>` | `ApiError`
- Params: `z.infer<typeof paginationSchema>`

### catch文:
```typescript
try { ... } catch (err: unknown) {
  const message = err instanceof Error ? err.message : 'Unknown error';
}
```
INJECTION

    echo "$prompt"
}

# =============================================================================
# 全生成実行
# =============================================================================
tse_enforce_types() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    echo "[type-safety-enforcer] Generating type safety infrastructure..."
    ts_generate_strict_config "$project_dir"
    ts_generate_api_types "$project_dir"
    ts_generate_type_guards "$project_dir"
    ts_generate_branded_types "$project_dir"
    ts_generate_exhaustive_check "$project_dir"
    ts_generate_zod_inference "$project_dir"
    ts_verify_no_any "$project_dir" >/dev/null
    echo "[type-safety-enforcer] Generated ${TSE_GENERATED} files (${TSE_ERRORS} errors, ${TSE_ANY_COUNT} any usages found)"
}

# =============================================================================
# スキャン（レガシー互換）
# =============================================================================
tse_scan_any_types() {
    local project_dir="${PROJECT_DIR:-./output}"
    local any_count=0
    if [[ -d "$project_dir" ]]; then
        any_count=$(grep -rn ': any' "$project_dir" --include='*.ts' --include='*.tsx' 2>/dev/null | grep -v node_modules | wc -l)
        any_count=$(echo "$any_count" | tr -d ' ')
    fi
    echo "$any_count"
}

# =============================================================================
# レポート & スコア
# =============================================================================
tse_report() {
    echo -e "\n  ${BOLD:-}=== type-safety-enforcer v${TS_VERSION} ===${NC:-}"
    echo -e "  生成ファイル数: ${TSE_GENERATED}"
    echo -e "  エラー: ${TSE_ERRORS}"
    echo -e "  any型検出数: ${TSE_ANY_COUNT}"
    if [[ ${TSE_GENERATED} -gt 0 ]]; then
        echo -e "  生成内容: tsconfig, API types, type guards, branded types, exhaustive check, zod schemas"
    fi
}

tse_score() {
    local base_score=50
    if [[ ${TSE_GENERATED} -ge 5 ]] && [[ ${TSE_ERRORS} -eq 0 ]]; then
        base_score=95
    elif [[ ${TSE_GENERATED} -gt 0 ]] && [[ ${TSE_ERRORS} -eq 0 ]]; then
        base_score=90
    elif [[ ${TSE_GENERATED} -gt 0 ]]; then
        base_score=70
    fi

    # Penalize for any usage
    if [[ ${TSE_ANY_COUNT} -gt 10 ]]; then
        base_score=$((base_score - 15))
    elif [[ ${TSE_ANY_COUNT} -gt 0 ]]; then
        base_score=$((base_score - 5))
    fi

    echo "$base_score"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "type-safety-enforcer" --version "140.0" \
        --description "型安全性強化×any排除×strict mode×ブランド型" \
        --init "ts_init" --report "tse_report" --score "tse_score" \
        --enable-var "ENABLE_TYPE_SAFETY" --cli-flags "--type-safety:--no-type-safety"
fi

# v2003.1: source時のexit codeを確実に0にする
true
