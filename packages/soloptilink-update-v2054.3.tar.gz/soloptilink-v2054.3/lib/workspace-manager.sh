#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v429.0 - Workspace Manager
# =============================================================================
# npm/yarn/pnpm ワークスペースの検出・依存管理・ホイスティング最適化。
# パッケージ間のバージョン整合性チェック、重複依存の排除、
# lockfileの最適化を自動実行する。
#
# Functions:
#   _wm_init()                - 初期化
#   _wm_detect_workspaces()   - ワークスペース検出
#   _wm_manage_deps()         - 依存関係管理
#   _wm_optimize_hoisting()   - ホイスティング最適化
#   _wm_report() / _wm_score()
#
# All globals use the WM_ prefix.
# =============================================================================

[[ -n "${_WM_LOADED:-}" ]] && return 0; _WM_LOADED=1

declare -g WM_VERSION="429.0"
declare -g WM_GENERATED=0
declare -g WM_ERRORS=0
declare -g WM_PKG_MANAGER=""
declare -g WM_WORKSPACE_COUNT=0
declare -g WM_DUPLICATE_DEPS=0
declare -g WM_VERSION_MISMATCHES=0
declare -g WM_HOISTING_SAVINGS_KB=0

declare -ga _WM_WORKSPACES=()
declare -gA _WM_WS_DEPS=()

_WM_GREEN="${GREEN:-\033[0;32m}"
_WM_RED="${RED:-\033[0;31m}"
_WM_YELLOW="${YELLOW:-\033[0;33m}"
_WM_CYAN="${CYAN:-\033[0;36m}"
_WM_BOLD="${BOLD:-\033[1m}"
_WM_NC="${NC:-\033[0m}"

_wm_init() {
    WM_GENERATED=0; WM_ERRORS=0; WM_PKG_MANAGER=""
    WM_WORKSPACE_COUNT=0; WM_DUPLICATE_DEPS=0
    WM_VERSION_MISMATCHES=0; WM_HOISTING_SAVINGS_KB=0
    _WM_WORKSPACES=(); _WM_WS_DEPS=()
    return 0
}

_wm_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_WM_CYAN}[WM]${_WM_NC} $*" >&2 ;;
        ok)    echo -e "  ${_WM_GREEN}[WM]${_WM_NC} $*" >&2 ;;
        warn)  echo -e "  ${_WM_YELLOW}[WM]${_WM_NC} $*" >&2 ;;
        error) echo -e "  ${_WM_RED}[WM]${_WM_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _wm_detect_workspaces - ワークスペース検出
# =============================================================================
_wm_detect_workspaces() {
    local project_dir="${1:-.}"
    _wm_log info "ワークスペース検出: ${project_dir}"

    _WM_WORKSPACES=()
    WM_PKG_MANAGER=""

    # パッケージマネージャ検出
    if [[ -f "${project_dir}/pnpm-lock.yaml" ]]; then
        WM_PKG_MANAGER="pnpm"
    elif [[ -f "${project_dir}/yarn.lock" ]]; then
        WM_PKG_MANAGER="yarn"
    elif [[ -f "${project_dir}/package-lock.json" ]]; then
        WM_PKG_MANAGER="npm"
    elif [[ -f "${project_dir}/bun.lockb" ]]; then
        WM_PKG_MANAGER="bun"
    fi

    # ワークスペースパス抽出
    local ws_patterns=()
    if [[ -f "${project_dir}/pnpm-workspace.yaml" ]]; then
        while IFS= read -r line; do
            line="${line#*- }"
            line="${line//\'/}"
            line="${line//\"/}"
            [[ -n "$line" ]] && [[ "$line" != "packages:" ]] && ws_patterns+=("$line")
        done < <(grep -E "^\s*-\s+" "${project_dir}/pnpm-workspace.yaml" 2>/dev/null)
    elif [[ -f "${project_dir}/package.json" ]]; then
        while IFS= read -r line; do
            line="${line//\"/}"
            line="${line//,/}"
            line="${line// /}"
            [[ -n "$line" ]] && [[ "$line" != "[" ]] && [[ "$line" != "]" ]] && ws_patterns+=("$line")
        done < <(sed -n '/"workspaces"/,/]/p' "${project_dir}/package.json" 2>/dev/null | grep -v 'workspaces')
    fi

    # パターンからワークスペースを解決
    for pattern in "${ws_patterns[@]}"; do
        local base_dir="${pattern%%\**}"
        base_dir="${base_dir%/}"
        if [[ -d "${project_dir}/${base_dir}" ]]; then
            while IFS= read -r -d '' ws_dir; do
                if [[ -f "${ws_dir}/package.json" ]]; then
                    local ws_name
                    ws_name=$(basename "$ws_dir")
                    _WM_WORKSPACES+=("${ws_dir#${project_dir}/}")
                fi
            done < <(find "${project_dir}/${base_dir}" -maxdepth 1 -mindepth 1 -type d -print0 2>/dev/null)
        fi
    done

    WM_WORKSPACE_COUNT=${#_WM_WORKSPACES[@]}
    WM_GENERATED=$((WM_GENERATED + 1))

    _wm_log ok "検出完了: ${WM_PKG_MANAGER}, ${WM_WORKSPACE_COUNT}ワークスペース"
    for ws in "${_WM_WORKSPACES[@]}"; do
        _wm_log info "  ${ws}"
    done

    echo "${WM_WORKSPACE_COUNT}"
    return 0
}

# =============================================================================
# _wm_manage_deps - 依存関係管理
# =============================================================================
_wm_manage_deps() {
    local project_dir="${1:-.}"
    _wm_log info "依存関係整合性チェック"

    WM_DUPLICATE_DEPS=0
    WM_VERSION_MISMATCHES=0
    _WM_WS_DEPS=()

    local -A dep_versions=()

    for ws in "${_WM_WORKSPACES[@]}"; do
        local pkg_json="${project_dir}/${ws}/package.json"
        [[ ! -f "$pkg_json" ]] && continue

        local ws_deps=""
        local in_deps=false

        while IFS= read -r line; do
            if [[ "$line" =~ \"(dependencies|devDependencies)\" ]]; then
                in_deps=true
                continue
            fi
            if [[ "$in_deps" == "true" ]] && [[ "$line" == *"}"* ]]; then
                in_deps=false
                continue
            fi
            if [[ "$in_deps" == "true" ]] && [[ "$line" =~ \"([^\"]+)\":\ *\"([^\"]+)\" ]]; then
                local dep_name="${BASH_REMATCH[1]}"
                local dep_ver="${BASH_REMATCH[2]}"
                ws_deps="${ws_deps}${ws_deps:+,}${dep_name}@${dep_ver}"

                local existing="${dep_versions[$dep_name]:-}"
                if [[ -n "$existing" ]] && [[ "$existing" != "$dep_ver" ]]; then
                    WM_VERSION_MISMATCHES=$((WM_VERSION_MISMATCHES + 1))
                    _wm_log warn "バージョン不整合: ${dep_name} ${existing} vs ${dep_ver} (${ws})"
                elif [[ -n "$existing" ]]; then
                    WM_DUPLICATE_DEPS=$((WM_DUPLICATE_DEPS + 1))
                fi
                dep_versions["$dep_name"]="$dep_ver"
            fi
        done < "$pkg_json"

        _WM_WS_DEPS["$ws"]="$ws_deps"
    done

    WM_GENERATED=$((WM_GENERATED + 1))

    if [[ $WM_VERSION_MISMATCHES -gt 0 ]]; then
        _wm_log warn "バージョン不整合: ${WM_VERSION_MISMATCHES}件"
    else
        _wm_log ok "依存整合性OK, 重複依存: ${WM_DUPLICATE_DEPS}"
    fi

    return 0
}

# =============================================================================
# _wm_optimize_hoisting - ホイスティング最適化
# =============================================================================
_wm_optimize_hoisting() {
    local project_dir="${1:-.}"
    _wm_log info "ホイスティング最適化分析"

    WM_HOISTING_SAVINGS_KB=0
    local -A dep_count=()
    local -A dep_size=()

    # ルートに既にある依存
    local root_modules="${project_dir}/node_modules"

    for ws in "${_WM_WORKSPACES[@]}"; do
        local ws_modules="${project_dir}/${ws}/node_modules"
        [[ ! -d "$ws_modules" ]] && continue

        while IFS= read -r -d '' dep_dir; do
            local dep_name
            dep_name=$(basename "$dep_dir")
            [[ "$dep_name" == ".package-lock.json" ]] && continue
            [[ "$dep_name" == ".cache" ]] && continue

            dep_count["$dep_name"]=$(( ${dep_count["$dep_name"]:-0} + 1 ))

            local size_kb
            size_kb=$(du -sk "$dep_dir" 2>/dev/null | cut -f1 || echo 0)
            dep_size["$dep_name"]=$(( ${dep_size["$dep_name"]:-0} + size_kb ))
        done < <(find "$ws_modules" -maxdepth 1 -mindepth 1 -type d -print0 2>/dev/null)
    done

    # ホイスティング可能な依存を特定
    local hoistable=0
    for dep in "${!dep_count[@]}"; do
        if [[ ${dep_count["$dep"]} -gt 1 ]]; then
            hoistable=$((hoistable + 1))
            local savings=$(( ${dep_size["$dep"]} * (${dep_count["$dep"]} - 1) / ${dep_count["$dep"]} ))
            WM_HOISTING_SAVINGS_KB=$((WM_HOISTING_SAVINGS_KB + savings))
        fi
    done

    WM_GENERATED=$((WM_GENERATED + 1))
    local savings_mb=$((WM_HOISTING_SAVINGS_KB / 1024))
    _wm_log ok "ホイスティング分析完了: ${hoistable}パッケージ, 推定${savings_mb}MB削減可能"

    echo "${WM_HOISTING_SAVINGS_KB}"
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_wm_report() {
    echo -e "\n  ${_WM_BOLD}=== workspace-manager v${WM_VERSION} ===${_WM_NC}"
    echo -e "  パッケージマネージャ: ${WM_PKG_MANAGER:-unknown}"
    echo -e "  ワークスペース数: ${WM_WORKSPACE_COUNT}"
    echo -e "  重複依存        : ${WM_DUPLICATE_DEPS}"
    echo -e "  バージョン不整合: ${WM_VERSION_MISMATCHES}"
    echo -e "  ホイスティング削減: ${WM_HOISTING_SAVINGS_KB}KB"
    echo -e "  エラー          : ${WM_ERRORS}"
}

_wm_score() {
    local score=50
    [[ ${WM_WORKSPACE_COUNT} -gt 0 ]] && score=$((score + 15))
    [[ ${WM_VERSION_MISMATCHES} -eq 0 ]] && score=$((score + 15))
    [[ ${WM_HOISTING_SAVINGS_KB} -gt 0 ]] && score=$((score + 10))
    [[ ${WM_ERRORS} -eq 0 ]] && score=$((score + 10))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "workspace-manager" --version "${WM_VERSION}" \
        --description "ワークスペース管理×依存整合性×ホイスティング最適化 (v429)" \
        --init "_wm_init" --report "_wm_report" --score "_wm_score" \
        --enable-var "ENABLE_WORKSPACE_MGR" --cli-flags "--workspace-mgr:--no-workspace-mgr"
fi

# v2003.1: source時のexit codeを確実に0にする
true
