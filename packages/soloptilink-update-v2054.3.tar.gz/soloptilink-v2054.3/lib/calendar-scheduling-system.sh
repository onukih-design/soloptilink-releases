#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v299.0 - Calendar & Scheduling System
# =============================================================================
# カレンダー・予約システム自動生成。カレンダーコンポーネント、
# 予約/リザベーションシステム、リマインダーシステムを生成する。
#
# 機能一覧:
#   _css_generate_calendar  - カレンダーコンポーネント生成
#   _css_generate_booking   - 予約システム生成
#   _css_generate_reminders - リマインダーシステム生成
#
# 全globals: CSS_ prefix
# =============================================================================

[[ -n "${_CSS_LOADED:-}" ]] && return 0; _CSS_LOADED=1

declare -g CSS_VERSION="299.0"
declare -g CSS_GENERATED=0
declare -g CSS_ERRORS=0
declare -g CSS_FILES_WRITTEN=0

css_init() { CSS_GENERATED=0; CSS_ERRORS=0; CSS_FILES_WRITTEN=0; return 0; }

_css_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then CSS_FILES_WRITTEN=$((CSS_FILES_WRITTEN + 1)); echo "  [css] wrote: $filepath" >&2
    else CSS_ERRORS=$((CSS_ERRORS + 1)); fi
}

_css_log() { echo -e "  ${GREEN:-\033[0;32m}[CSS]${NC:-\033[0m} $*" >&2; }

# =============================================================================
# _css_generate_calendar
# =============================================================================
_css_generate_calendar() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _css_log "Generating calendar component..."

    local cal_ts
    cal_ts=$(cat <<'CALEOF'
// =============================================================================
// Calendar Component (React) - Month view with event rendering
// =============================================================================
'use client';
import { useState, useMemo } from 'react';

export interface CalendarEvent {
  id: string;
  title: string;
  start: Date;
  end: Date;
  color?: string;
  allDay?: boolean;
  metadata?: Record<string, unknown>;
}

interface CalendarProps {
  events: CalendarEvent[];
  onDateClick?: (date: Date) => void;
  onEventClick?: (event: CalendarEvent) => void;
  onMonthChange?: (year: number, month: number) => void;
}

export function Calendar({ events, onDateClick, onEventClick, onMonthChange }: CalendarProps) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const year = currentDate.getFullYear();
  const month = currentDate.getMonth();

  const calendarDays = useMemo(() => {
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const startOffset = firstDay.getDay();
    const days: Array<{ date: Date; isCurrentMonth: boolean; events: CalendarEvent[] }> = [];

    // Previous month padding
    for (let i = startOffset - 1; i >= 0; i--) {
      const date = new Date(year, month, -i);
      days.push({ date, isCurrentMonth: false, events: [] });
    }

    // Current month
    for (let d = 1; d <= lastDay.getDate(); d++) {
      const date = new Date(year, month, d);
      const dayEvents = events.filter((e) => {
        const eventDate = new Date(e.start);
        return eventDate.getFullYear() === year && eventDate.getMonth() === month && eventDate.getDate() === d;
      });
      days.push({ date, isCurrentMonth: true, events: dayEvents });
    }

    // Next month padding
    const remaining = 42 - days.length;
    for (let i = 1; i <= remaining; i++) {
      const date = new Date(year, month + 1, i);
      days.push({ date, isCurrentMonth: false, events: [] });
    }

    return days;
  }, [year, month, events]);

  const navigateMonth = (delta: number) => {
    const newDate = new Date(year, month + delta, 1);
    setCurrentDate(newDate);
    onMonthChange?.(newDate.getFullYear(), newDate.getMonth());
  };

  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'];
  const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

  const today = new Date();
  const isToday = (date: Date) =>
    date.getFullYear() === today.getFullYear() &&
    date.getMonth() === today.getMonth() &&
    date.getDate() === today.getDate();

  return {
    year,
    month,
    monthName: monthNames[month],
    dayNames,
    calendarDays,
    navigateMonth,
    isToday,
    onDateClick,
    onEventClick,
  };
}

// --- Event Utilities ---
export function isOverlapping(a: CalendarEvent, b: CalendarEvent): boolean {
  return a.start < b.end && a.end > b.start;
}

export function getEventsForDateRange(events: CalendarEvent[], start: Date, end: Date): CalendarEvent[] {
  return events.filter((e) => e.start < end && e.end > start);
}

export function groupEventsByDate(events: CalendarEvent[]): Map<string, CalendarEvent[]> {
  const groups = new Map<string, CalendarEvent[]>();
  for (const event of events) {
    const key = event.start.toISOString().split('T')[0];
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key)!.push(event);
  }
  return groups;
}
CALEOF
)
    _css_write_file "${project_dir}/src/components/calendar/Calendar.ts" "$cal_ts"
    CSS_GENERATED=$((CSS_GENERATED + 1))
    return 0
}

# =============================================================================
# _css_generate_booking
# =============================================================================
_css_generate_booking() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _css_log "Generating booking/reservation system..."

    local book_ts
    book_ts=$(cat <<'BOOKEOF'
// =============================================================================
// Booking / Reservation System
// Time slot management, availability checking, booking CRUD
// =============================================================================
import { z } from 'zod';

export const BookingSchema = z.object({
  id: z.string().uuid(),
  userId: z.string(),
  resourceId: z.string(),
  title: z.string().min(1),
  startTime: z.date(),
  endTime: z.date(),
  status: z.enum(['pending', 'confirmed', 'cancelled', 'completed']),
  notes: z.string().optional(),
  metadata: z.record(z.unknown()).optional(),
});
export type Booking = z.infer<typeof BookingSchema>;

export interface TimeSlot {
  start: Date;
  end: Date;
  available: boolean;
}

export interface AvailabilityConfig {
  resourceId: string;
  workingHours: { start: number; end: number };  // 0-23
  slotDurationMinutes: number;
  bufferMinutes: number;
  workingDays: number[];  // 0=Sun, 1=Mon, ..., 6=Sat
  blockedDates: string[];  // ISO date strings
}

const DEFAULT_CONFIG: AvailabilityConfig = {
  resourceId: 'default',
  workingHours: { start: 9, end: 18 },
  slotDurationMinutes: 60,
  bufferMinutes: 15,
  workingDays: [1, 2, 3, 4, 5],
  blockedDates: [],
};

export function generateTimeSlots(date: Date, config: AvailabilityConfig = DEFAULT_CONFIG, existingBookings: Booking[] = []): TimeSlot[] {
  const slots: TimeSlot[] = [];
  const dayOfWeek = date.getDay();

  if (!config.workingDays.includes(dayOfWeek)) return [];
  const dateStr = date.toISOString().split('T')[0];
  if (config.blockedDates.includes(dateStr)) return [];

  const startHour = config.workingHours.start;
  const endHour = config.workingHours.end;
  const slotMs = config.slotDurationMinutes * 60000;
  const bufferMs = config.bufferMinutes * 60000;

  let current = new Date(date);
  current.setHours(startHour, 0, 0, 0);
  const dayEnd = new Date(date);
  dayEnd.setHours(endHour, 0, 0, 0);

  while (current.getTime() + slotMs <= dayEnd.getTime()) {
    const slotStart = new Date(current);
    const slotEnd = new Date(current.getTime() + slotMs);

    const isBooked = existingBookings.some((b) =>
      b.status !== 'cancelled' && b.resourceId === config.resourceId &&
      b.startTime < slotEnd && b.endTime > slotStart
    );

    slots.push({ start: slotStart, end: slotEnd, available: !isBooked });
    current = new Date(current.getTime() + slotMs + bufferMs);
  }

  return slots;
}

export async function createBooking(input: Omit<Booking, 'id' | 'status'>): Promise<Booking> {
  // Check availability
  const slots = generateTimeSlots(input.startTime);
  const isAvailable = slots.some((s) => s.start <= input.startTime && s.end >= input.endTime && s.available);
  if (!isAvailable) throw new Error('Time slot is not available');

  const booking: Booking = { ...input, id: crypto.randomUUID(), status: 'pending' };
  // In real implementation: save to database
  console.log(`[booking] Created: ${booking.id} for ${booking.userId}`);
  return booking;
}

export async function cancelBooking(bookingId: string): Promise<Booking> {
  // In real implementation: update in database
  console.log(`[booking] Cancelled: ${bookingId}`);
  return { id: bookingId, userId: '', resourceId: '', title: '', startTime: new Date(), endTime: new Date(), status: 'cancelled' };
}
BOOKEOF
)
    _css_write_file "${project_dir}/src/lib/scheduling/booking.ts" "$book_ts"
    CSS_GENERATED=$((CSS_GENERATED + 1))
    return 0
}

# =============================================================================
# _css_generate_reminders
# =============================================================================
_css_generate_reminders() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _css_log "Generating reminder system..."

    local remind_ts
    remind_ts=$(cat <<'REMEOF'
// =============================================================================
// Reminder System - Schedule and send reminders for bookings/events
// =============================================================================
import { z } from 'zod';

export const ReminderSchema = z.object({
  id: z.string().uuid(),
  bookingId: z.string(),
  userId: z.string(),
  type: z.enum(['email', 'push', 'sms']),
  scheduledAt: z.date(),
  sentAt: z.date().nullable(),
  status: z.enum(['scheduled', 'sent', 'failed', 'cancelled']),
  message: z.string(),
});
export type Reminder = z.infer<typeof ReminderSchema>;

export interface ReminderConfig {
  beforeMinutes: number[];  // e.g., [1440, 60, 15] = 1 day, 1 hour, 15 min before
  channels: Array<'email' | 'push' | 'sms'>;
  messageTemplate: string;
}

const DEFAULT_REMINDER_CONFIG: ReminderConfig = {
  beforeMinutes: [1440, 60, 15],
  channels: ['email', 'push'],
  messageTemplate: 'Reminder: Your booking "{{title}}" starts at {{startTime}}',
};

export function createReminders(
  bookingId: string,
  userId: string,
  title: string,
  startTime: Date,
  config: ReminderConfig = DEFAULT_REMINDER_CONFIG
): Reminder[] {
  const reminders: Reminder[] = [];

  for (const minutes of config.beforeMinutes) {
    const scheduledAt = new Date(startTime.getTime() - minutes * 60000);
    if (scheduledAt <= new Date()) continue;  // Skip past reminders

    for (const channel of config.channels) {
      const message = config.messageTemplate
        .replace('{{title}}', title)
        .replace('{{startTime}}', startTime.toLocaleString('ja-JP'));

      reminders.push({
        id: crypto.randomUUID(),
        bookingId,
        userId,
        type: channel,
        scheduledAt,
        sentAt: null,
        status: 'scheduled',
        message,
      });
    }
  }

  return reminders;
}

// --- Reminder Processor ---
export class ReminderProcessor {
  private timer: NodeJS.Timeout | null = null;
  private reminders: Reminder[] = [];

  addReminders(reminders: Reminder[]): void {
    this.reminders.push(...reminders);
  }

  start(intervalMs = 60000): void {
    this.timer = setInterval(() => this.processReminders(), intervalMs);
    console.log('[reminders] Processor started');
  }

  stop(): void {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
  }

  private async processReminders(): Promise<void> {
    const now = new Date();
    const due = this.reminders.filter((r) => r.status === 'scheduled' && r.scheduledAt <= now);

    for (const reminder of due) {
      try {
        await this.sendReminder(reminder);
        reminder.status = 'sent';
        reminder.sentAt = new Date();
        console.log(`[reminders] Sent: ${reminder.type} for booking ${reminder.bookingId}`);
      } catch (err: any) {
        reminder.status = 'failed';
        console.error(`[reminders] Failed: ${reminder.id}`, err.message);
      }
    }
  }

  private async sendReminder(reminder: Reminder): Promise<void> {
    switch (reminder.type) {
      case 'email': /* await emailService.send(...) */ break;
      case 'push':  /* await pushService.send(...)  */ break;
      case 'sms':   /* await smsService.send(...)   */ break;
    }
  }

  getStats(): { scheduled: number; sent: number; failed: number } {
    return {
      scheduled: this.reminders.filter((r) => r.status === 'scheduled').length,
      sent: this.reminders.filter((r) => r.status === 'sent').length,
      failed: this.reminders.filter((r) => r.status === 'failed').length,
    };
  }
}

export const reminderProcessor = new ReminderProcessor();
REMEOF
)
    _css_write_file "${project_dir}/src/lib/scheduling/reminders.ts" "$remind_ts"
    CSS_GENERATED=$((CSS_GENERATED + 1))
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
css_report() {
    echo -e "\n  ${BOLD:-}=== calendar-scheduling-system v${CSS_VERSION} ===${NC:-}"
    echo -e "  生成数: ${CSS_GENERATED}"; echo -e "  エラー: ${CSS_ERRORS}"
}

css_score() {
    if [[ ${CSS_GENERATED} -ge 3 ]] && [[ ${CSS_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${CSS_GENERATED} -gt 0 ]] && [[ ${CSS_ERRORS} -eq 0 ]]; then echo "85"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "calendar-scheduling-system" --version "${CSS_VERSION}" \
        --description "カレンダー×予約システム×リマインダー" \
        --init "css_init" --report "css_report" --score "css_score" \
        --enable-var "ENABLE_CALENDAR" --cli-flags "--calendar:--no-calendar"
fi

# v2003.1: source時のexit codeを確実に0にする
true
