#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v294.0 - File Storage System
# =============================================================================
# ストレージ抽象化レイヤー自動生成。S3/R2/GCS/ローカル対応、
# 署名付きURLアップロード、セキュアダウンロードAPIを生成。
#
# 機能一覧:
#   _fss_generate_storage_layer - ストレージ抽象化レイヤー
#   _fss_generate_upload_api   - アップロードAPI
#   _fss_generate_download_api - ダウンロードAPI
#
# 全globals: FSS_ prefix
# =============================================================================

[[ -n "${_FSS_LOADED:-}" ]] && return 0; _FSS_LOADED=1

declare -g FSS_VERSION="294.0"
declare -g FSS_GENERATED=0
declare -g FSS_ERRORS=0
declare -g FSS_FILES_WRITTEN=0

fss_init() { FSS_GENERATED=0; FSS_ERRORS=0; FSS_FILES_WRITTEN=0; return 0; }

_fss_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then FSS_FILES_WRITTEN=$((FSS_FILES_WRITTEN + 1)); echo "  [fss] wrote: $filepath" >&2
    else FSS_ERRORS=$((FSS_ERRORS + 1)); fi
}

_fss_log() { echo -e "  ${GREEN:-\033[0;32m}[FSS]${NC:-\033[0m} $*" >&2; }

# =============================================================================
# _fss_generate_storage_layer
# =============================================================================
_fss_generate_storage_layer() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _fss_log "Generating storage abstraction layer..."

    local storage_ts
    storage_ts=$(cat <<'STOREOF'
// =============================================================================
// File Storage Abstraction Layer
// Supports: S3, R2 (Cloudflare), GCS (Google), Local filesystem
// =============================================================================
import { z } from 'zod';
import { createReadStream, createWriteStream, existsSync, mkdirSync, unlinkSync, statSync } from 'fs';
import { join } from 'path';
import { pipeline } from 'stream/promises';

export const FileMetadataSchema = z.object({
  key: z.string(),
  bucket: z.string(),
  size: z.number(),
  contentType: z.string(),
  uploadedBy: z.string().optional(),
  uploadedAt: z.string().datetime(),
  metadata: z.record(z.string()).optional(),
});
export type FileMetadata = z.infer<typeof FileMetadataSchema>;

export interface StorageProvider {
  upload(key: string, data: Buffer | NodeJS.ReadableStream, contentType: string): Promise<FileMetadata>;
  download(key: string): Promise<{ stream: NodeJS.ReadableStream; metadata: FileMetadata }>;
  delete(key: string): Promise<boolean>;
  exists(key: string): Promise<boolean>;
  getSignedUploadUrl(key: string, contentType: string, expiresIn?: number): Promise<string>;
  getSignedDownloadUrl(key: string, expiresIn?: number): Promise<string>;
  list(prefix?: string, limit?: number): Promise<FileMetadata[]>;
}

// --- Local Storage Provider ---
export class LocalStorageProvider implements StorageProvider {
  private basePath: string;
  private baseUrl: string;

  constructor(basePath = './uploads', baseUrl = '/api/files') {
    this.basePath = basePath;
    this.baseUrl = baseUrl;
    if (!existsSync(basePath)) mkdirSync(basePath, { recursive: true });
  }

  async upload(key: string, data: Buffer | NodeJS.ReadableStream, contentType: string): Promise<FileMetadata> {
    const filePath = join(this.basePath, key);
    const dir = join(this.basePath, key.split('/').slice(0, -1).join('/'));
    if (!existsSync(dir)) mkdirSync(dir, { recursive: true });

    if (Buffer.isBuffer(data)) {
      const { writeFileSync } = await import('fs');
      writeFileSync(filePath, data);
    } else {
      const writeStream = createWriteStream(filePath);
      await pipeline(data, writeStream);
    }

    const stat = statSync(filePath);
    return { key, bucket: 'local', size: stat.size, contentType, uploadedAt: new Date().toISOString() };
  }

  async download(key: string): Promise<{ stream: NodeJS.ReadableStream; metadata: FileMetadata }> {
    const filePath = join(this.basePath, key);
    if (!existsSync(filePath)) throw new Error(`File not found: ${key}`);
    const stat = statSync(filePath);
    return {
      stream: createReadStream(filePath),
      metadata: { key, bucket: 'local', size: stat.size, contentType: 'application/octet-stream', uploadedAt: stat.mtime.toISOString() },
    };
  }

  async delete(key: string): Promise<boolean> {
    const filePath = join(this.basePath, key);
    if (!existsSync(filePath)) return false;
    unlinkSync(filePath); return true;
  }

  async exists(key: string): Promise<boolean> { return existsSync(join(this.basePath, key)); }

  async getSignedUploadUrl(key: string): Promise<string> { return `${this.baseUrl}/upload?key=${encodeURIComponent(key)}`; }
  async getSignedDownloadUrl(key: string): Promise<string> { return `${this.baseUrl}/download/${encodeURIComponent(key)}`; }

  async list(prefix = '', limit = 100): Promise<FileMetadata[]> {
    const { readdirSync } = await import('fs');
    const dir = join(this.basePath, prefix);
    if (!existsSync(dir)) return [];
    return readdirSync(dir).slice(0, limit).map((f) => {
      const stat = statSync(join(dir, f));
      return { key: join(prefix, f), bucket: 'local', size: stat.size, contentType: 'application/octet-stream', uploadedAt: stat.mtime.toISOString() };
    });
  }
}

// --- S3 Storage Provider ---
export class S3StorageProvider implements StorageProvider {
  private bucket: string;
  private client: any;

  constructor() {
    this.bucket = process.env.S3_BUCKET || 'app-uploads';
  }

  private async getClient() {
    if (this.client) return this.client;
    const { S3Client } = await import('@aws-sdk/client-s3');
    this.client = new S3Client({ region: process.env.AWS_REGION || 'ap-northeast-1' });
    return this.client;
  }

  async upload(key: string, data: Buffer | NodeJS.ReadableStream, contentType: string): Promise<FileMetadata> {
    const { PutObjectCommand } = await import('@aws-sdk/client-s3');
    const client = await this.getClient();
    await client.send(new PutObjectCommand({ Bucket: this.bucket, Key: key, Body: data, ContentType: contentType }));
    const size = Buffer.isBuffer(data) ? data.length : 0;
    return { key, bucket: this.bucket, size, contentType, uploadedAt: new Date().toISOString() };
  }

  async download(key: string): Promise<{ stream: NodeJS.ReadableStream; metadata: FileMetadata }> {
    const { GetObjectCommand } = await import('@aws-sdk/client-s3');
    const client = await this.getClient();
    const resp = await client.send(new GetObjectCommand({ Bucket: this.bucket, Key: key }));
    return { stream: resp.Body as NodeJS.ReadableStream, metadata: { key, bucket: this.bucket, size: resp.ContentLength || 0, contentType: resp.ContentType || '', uploadedAt: new Date().toISOString() } };
  }

  async delete(key: string): Promise<boolean> {
    const { DeleteObjectCommand } = await import('@aws-sdk/client-s3');
    const client = await this.getClient();
    await client.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
    return true;
  }

  async exists(key: string): Promise<boolean> {
    const { HeadObjectCommand } = await import('@aws-sdk/client-s3');
    try { await (await this.getClient()).send(new HeadObjectCommand({ Bucket: this.bucket, Key: key })); return true; } catch { return false; }
  }

  async getSignedUploadUrl(key: string, contentType: string, expiresIn = 3600): Promise<string> {
    const { PutObjectCommand } = await import('@aws-sdk/client-s3');
    const { getSignedUrl } = await import('@aws-sdk/s3-request-presigner');
    return getSignedUrl(await this.getClient(), new PutObjectCommand({ Bucket: this.bucket, Key: key, ContentType: contentType }), { expiresIn });
  }

  async getSignedDownloadUrl(key: string, expiresIn = 3600): Promise<string> {
    const { GetObjectCommand } = await import('@aws-sdk/client-s3');
    const { getSignedUrl } = await import('@aws-sdk/s3-request-presigner');
    return getSignedUrl(await this.getClient(), new GetObjectCommand({ Bucket: this.bucket, Key: key }), { expiresIn });
  }

  async list(prefix = '', limit = 100): Promise<FileMetadata[]> {
    const { ListObjectsV2Command } = await import('@aws-sdk/client-s3');
    const resp = await (await this.getClient()).send(new ListObjectsV2Command({ Bucket: this.bucket, Prefix: prefix, MaxKeys: limit }));
    return (resp.Contents || []).map((obj: any) => ({ key: obj.Key, bucket: this.bucket, size: obj.Size || 0, contentType: '', uploadedAt: obj.LastModified?.toISOString() || '' }));
  }
}

export function createStorageProvider(): StorageProvider {
  const provider = process.env.STORAGE_PROVIDER || 'local';
  switch (provider) {
    case 's3': return new S3StorageProvider();
    default: return new LocalStorageProvider();
  }
}
STOREOF
)
    _fss_write_file "${project_dir}/src/lib/storage/provider.ts" "$storage_ts"
    FSS_GENERATED=$((FSS_GENERATED + 1))
    return 0
}

# =============================================================================
# _fss_generate_upload_api
# =============================================================================
_fss_generate_upload_api() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _fss_log "Generating upload API..."

    local upload_ts
    upload_ts=$(cat <<'UPEOF'
// =============================================================================
// File Upload API - Signed URL upload flow
// =============================================================================
import { NextRequest, NextResponse } from 'next/server';
import { createStorageProvider } from '@/lib/storage/provider';
import { z } from 'zod';

const storage = createStorageProvider();

const RequestSchema = z.object({
  filename: z.string().min(1).max(255),
  contentType: z.string().min(1),
  size: z.number().max(50 * 1024 * 1024), // 50MB max
});

const ALLOWED_TYPES = ['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'application/pdf', 'text/csv',
  'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'];

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const parsed = RequestSchema.parse(body);

    if (!ALLOWED_TYPES.includes(parsed.contentType)) {
      return NextResponse.json({ error: 'File type not allowed' }, { status: 400 });
    }

    const key = `uploads/${Date.now()}-${crypto.randomUUID()}/${parsed.filename}`;
    const signedUrl = await storage.getSignedUploadUrl(key, parsed.contentType, 600);

    return NextResponse.json({ uploadUrl: signedUrl, key, expiresIn: 600 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 400 });
  }
}
UPEOF
)
    _fss_write_file "${project_dir}/src/app/api/files/upload/route.ts" "$upload_ts"
    FSS_GENERATED=$((FSS_GENERATED + 1))
    return 0
}

# =============================================================================
# _fss_generate_download_api
# =============================================================================
_fss_generate_download_api() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _fss_log "Generating download API..."

    local dl_ts
    dl_ts=$(cat <<'DLEOF'
// =============================================================================
// File Download API - Secure download with signed URLs
// =============================================================================
import { NextRequest, NextResponse } from 'next/server';
import { createStorageProvider } from '@/lib/storage/provider';

const storage = createStorageProvider();

export async function GET(req: NextRequest, { params }: { params: { key: string } }) {
  try {
    const key = decodeURIComponent(params.key);
    const fileExists = await storage.exists(key);
    if (!fileExists) {
      return NextResponse.json({ error: 'File not found' }, { status: 404 });
    }
    const signedUrl = await storage.getSignedDownloadUrl(key, 300);
    return NextResponse.redirect(signedUrl);
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
DLEOF
)
    _fss_write_file "${project_dir}/src/app/api/files/download/[key]/route.ts" "$dl_ts"
    FSS_GENERATED=$((FSS_GENERATED + 1))
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
fss_report() {
    echo -e "\n  ${BOLD:-}=== file-storage-system v${FSS_VERSION} ===${NC:-}"
    echo -e "  生成数: ${FSS_GENERATED}"; echo -e "  エラー: ${FSS_ERRORS}"
}

fss_score() {
    if [[ ${FSS_GENERATED} -ge 3 ]] && [[ ${FSS_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${FSS_GENERATED} -gt 0 ]] && [[ ${FSS_ERRORS} -eq 0 ]]; then echo "85"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "file-storage-system" --version "${FSS_VERSION}" \
        --description "ファイルストレージ×S3/R2/ローカル×署名付きURL×アップロード/ダウンロード" \
        --init "fss_init" --report "fss_report" --score "fss_score" \
        --enable-var "ENABLE_FILE_STORAGE" --cli-flags "--file-storage:--no-file-storage"
fi

# v2003.1: source時のexit codeを確実に0にする
true
