#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v367.0 - Deployment Dashboard
# =============================================================================
# デプロイダッシュボード×デプロイ追跡×MTTR計算
#
# 機能:
#   - デプロイ履歴ダッシュボード生成
#   - デプロイ頻度/成功率追跡
#   - MTTR（平均復旧時間）計算
#   - DORA メトリクス（4 Key Metrics）
#   - デプロイトレンド可視化
#
# 全globals: DD_ prefix
# =============================================================================

[[ -n "${_DD_LOADED:-}" ]] && return 0; _DD_LOADED=1

DD_VERSION="367.0"
DD_GENERATED=0
DD_ERRORS=0
DD_PHASE="deploy_dashboard"
DD_FILES_CREATED=()

: "${GREEN:=\033[0;32m}" ; : "${RED:=\033[0;31m}" ; : "${YELLOW:=\033[0;33m}"
: "${CYAN:=\033[0;36m}" ; : "${BOLD:=\033[1m}" ; : "${NC:=\033[0m}"

_dd_log() { echo -e "  ${CYAN}[DD]${NC} $*"; }
_dd_ok() { echo -e "  ${GREEN}[DD]${NC} $*"; }
_dd_err() { echo -e "  ${RED}[DD]${NC} $*"; }

_dd_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        DD_FILES_CREATED+=("$filepath")
        DD_GENERATED=$((DD_GENERATED + 1))
        _dd_ok "Created: ${filepath##*/}"
    else
        DD_ERRORS=$((DD_ERRORS + 1))
        _dd_err "Failed: ${filepath##*/}"
    fi
}

dd_init() {
    DD_GENERATED=0; DD_ERRORS=0; DD_FILES_CREATED=()
    _dd_log "Deployment Dashboard v${DD_VERSION} initialized"
    return 0
}

# =============================================================================
# Generate Dashboard
# =============================================================================
_dd_generate_dashboard() {
    local project_dir="${1:-.}"

    _dd_log "Generating deployment dashboard..."

    local dash_dir="${project_dir}/src/app/admin/deployments"
    mkdir -p "$dash_dir" 2>/dev/null

    _dd_write_file "${dash_dir}/page.tsx" "$(cat <<'TSX'
'use client';
import { useEffect, useState } from 'react';

interface Deployment {
  id: string;
  version: string;
  environment: string;
  status: 'success' | 'failed' | 'rolled_back' | 'in_progress';
  deployedBy: string;
  deployedAt: string;
  duration: number;
  commitSha: string;
}

interface DORAMetrics {
  deployFrequency: string;
  leadTime: string;
  changeFailureRate: string;
  mttr: string;
}

export default function DeploymentDashboard() {
  const [deployments, setDeployments] = useState<Deployment[]>([]);
  const [metrics, setMetrics] = useState<DORAMetrics | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    Promise.all([
      fetch('/api/v1/admin/deployments').then(r => r.json()),
      fetch('/api/v1/admin/deployments/metrics').then(r => r.json()),
    ]).then(([deploys, met]) => {
      setDeployments(deploys.data || []);
      setMetrics(met);
      setLoading(false);
    }).catch(() => setLoading(false));
  }, []);

  if (loading) return <div className="p-8">Loading deployment data...</div>;

  const statusColors = { success: 'bg-green-100 text-green-800', failed: 'bg-red-100 text-red-800', rolled_back: 'bg-yellow-100 text-yellow-800', in_progress: 'bg-blue-100 text-blue-800' };

  return (
    <div className="p-8 max-w-6xl mx-auto">
      <h1 className="text-2xl font-bold mb-6">Deployment Dashboard</h1>
      {metrics && (
        <div className="grid grid-cols-4 gap-4 mb-8">
          <div className="border rounded-lg p-4 text-center">
            <div className="text-sm text-gray-500">Deploy Frequency</div>
            <div className="text-2xl font-bold">{metrics.deployFrequency}</div>
          </div>
          <div className="border rounded-lg p-4 text-center">
            <div className="text-sm text-gray-500">Lead Time</div>
            <div className="text-2xl font-bold">{metrics.leadTime}</div>
          </div>
          <div className="border rounded-lg p-4 text-center">
            <div className="text-sm text-gray-500">Change Failure Rate</div>
            <div className="text-2xl font-bold">{metrics.changeFailureRate}</div>
          </div>
          <div className="border rounded-lg p-4 text-center">
            <div className="text-sm text-gray-500">MTTR</div>
            <div className="text-2xl font-bold">{metrics.mttr}</div>
          </div>
        </div>
      )}
      <div className="border rounded-lg overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50"><tr>
            <th className="px-4 py-3 text-left text-sm font-medium">Version</th>
            <th className="px-4 py-3 text-left text-sm font-medium">Environment</th>
            <th className="px-4 py-3 text-left text-sm font-medium">Status</th>
            <th className="px-4 py-3 text-left text-sm font-medium">Deployed By</th>
            <th className="px-4 py-3 text-left text-sm font-medium">Duration</th>
            <th className="px-4 py-3 text-left text-sm font-medium">Time</th>
          </tr></thead>
          <tbody className="divide-y">
            {deployments.map(d => (
              <tr key={d.id}>
                <td className="px-4 py-3 font-mono text-sm">{d.version}</td>
                <td className="px-4 py-3">{d.environment}</td>
                <td className="px-4 py-3">
                  <span className={`px-2 py-1 rounded text-xs font-medium ${statusColors[d.status]}`}>{d.status}</span>
                </td>
                <td className="px-4 py-3">{d.deployedBy}</td>
                <td className="px-4 py-3">{Math.round(d.duration / 1000)}s</td>
                <td className="px-4 py-3 text-sm text-gray-500">{new Date(d.deployedAt).toLocaleString()}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
TSX
)"

    _dd_ok "Deployment dashboard generated"
}

# =============================================================================
# Track Deployments
# =============================================================================
_dd_track_deployments() {
    local project_dir="${1:-.}"

    _dd_log "Generating deployment tracker..."

    local track_dir="${project_dir}/src/lib/deployment"
    mkdir -p "$track_dir" 2>/dev/null

    _dd_write_file "${track_dir}/tracker.ts" "$(cat <<'TS'
interface DeploymentRecord {
  id: string;
  version: string;
  environment: string;
  status: 'success' | 'failed' | 'rolled_back' | 'in_progress';
  deployedBy: string;
  deployedAt: Date;
  completedAt?: Date;
  duration: number;
  commitSha: string;
  prNumber?: number;
  rollbackOf?: string;
}

class DeploymentTracker {
  private deployments: DeploymentRecord[] = [];

  record(deployment: DeploymentRecord): void {
    this.deployments.push(deployment);
  }

  getByEnvironment(env: string): DeploymentRecord[] {
    return this.deployments.filter(d => d.environment === env).sort((a, b) =>
      b.deployedAt.getTime() - a.deployedAt.getTime()
    );
  }

  getFrequency(days = 30): { total: number; perDay: number; perWeek: number } {
    const cutoff = Date.now() - days * 86400000;
    const recent = this.deployments.filter(d => d.deployedAt.getTime() > cutoff && d.status === 'success');
    return {
      total: recent.length,
      perDay: Math.round((recent.length / days) * 10) / 10,
      perWeek: Math.round((recent.length / (days / 7)) * 10) / 10,
    };
  }

  getSuccessRate(days = 30): number {
    const cutoff = Date.now() - days * 86400000;
    const recent = this.deployments.filter(d => d.deployedAt.getTime() > cutoff);
    if (recent.length === 0) return 100;
    const success = recent.filter(d => d.status === 'success').length;
    return Math.round((success / recent.length) * 100);
  }

  getAll(): DeploymentRecord[] {
    return [...this.deployments].sort((a, b) => b.deployedAt.getTime() - a.deployedAt.getTime());
  }
}

export const deploymentTracker = new DeploymentTracker();
TS
)"

    _dd_ok "Deployment tracker generated"
}

# =============================================================================
# Calculate MTTR
# =============================================================================
_dd_calculate_mttr() {
    local project_dir="${1:-.}"

    _dd_log "Generating DORA metrics calculator..."

    local track_dir="${project_dir}/src/lib/deployment"
    mkdir -p "$track_dir" 2>/dev/null

    _dd_write_file "${track_dir}/dora-metrics.ts" "$(cat <<'TS'
import { deploymentTracker } from './tracker';

interface DORAMetrics {
  deployFrequency: { value: number; unit: string; rating: 'elite' | 'high' | 'medium' | 'low' };
  leadTime: { value: number; unit: string; rating: 'elite' | 'high' | 'medium' | 'low' };
  changeFailureRate: { value: number; rating: 'elite' | 'high' | 'medium' | 'low' };
  mttr: { value: number; unit: string; rating: 'elite' | 'high' | 'medium' | 'low' };
}

export function calculateDORAMetrics(days = 30): DORAMetrics {
  const freq = deploymentTracker.getFrequency(days);
  const successRate = deploymentTracker.getSuccessRate(days);
  const failureRate = 100 - successRate;

  const deploys = deploymentTracker.getAll();
  const failures = deploys.filter(d => d.status === 'failed' || d.status === 'rolled_back');
  let totalRecoveryTime = 0;
  let recoveryCount = 0;

  for (const failure of failures) {
    const nextSuccess = deploys.find(d =>
      d.environment === failure.environment &&
      d.status === 'success' &&
      d.deployedAt > failure.deployedAt
    );
    if (nextSuccess && failure.completedAt) {
      totalRecoveryTime += nextSuccess.deployedAt.getTime() - failure.completedAt.getTime();
      recoveryCount++;
    }
  }

  const mttrMinutes = recoveryCount > 0 ? Math.round(totalRecoveryTime / recoveryCount / 60000) : 0;

  // Lead time (commit to deploy)
  const avgDuration = deploys.length > 0
    ? deploys.reduce((s, d) => s + d.duration, 0) / deploys.length / 60000
    : 0;

  return {
    deployFrequency: {
      value: freq.perDay,
      unit: 'per day',
      rating: freq.perDay >= 1 ? 'elite' : freq.perWeek >= 1 ? 'high' : freq.perWeek >= 0.14 ? 'medium' : 'low',
    },
    leadTime: {
      value: Math.round(avgDuration),
      unit: 'minutes',
      rating: avgDuration < 60 ? 'elite' : avgDuration < 1440 ? 'high' : avgDuration < 10080 ? 'medium' : 'low',
    },
    changeFailureRate: {
      value: failureRate,
      rating: failureRate < 5 ? 'elite' : failureRate < 10 ? 'high' : failureRate < 15 ? 'medium' : 'low',
    },
    mttr: {
      value: mttrMinutes,
      unit: 'minutes',
      rating: mttrMinutes < 60 ? 'elite' : mttrMinutes < 1440 ? 'high' : mttrMinutes < 10080 ? 'medium' : 'low',
    },
  };
}
TS
)"

    _dd_ok "DORA metrics calculator generated"
}

# =============================================================================
# Report / Score / Register
# =============================================================================
dd_report() {
    echo -e "\n  ${BOLD}=== Deployment Dashboard v${DD_VERSION} ===${NC}"
    echo -e "  生成ファイル数 : ${DD_GENERATED}"
    echo -e "  エラー         : ${DD_ERRORS}"
    if [[ ${#DD_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${DD_FILES_CREATED[@]}"; do echo -e "    - ${f}"; done
    fi
}

dd_score() {
    if [[ ${DD_GENERATED} -ge 3 ]] && [[ ${DD_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${DD_GENERATED} -gt 0 ]] && [[ ${DD_ERRORS} -eq 0 ]]; then echo "90"
    elif [[ ${DD_GENERATED} -gt 0 ]]; then echo "70"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "deployment-dashboard" --version "367.0" \
        --description "デプロイダッシュボード×DORA メトリクス×MTTR計算" \
        --init "dd_init" --report "dd_report" --score "dd_score" \
        --enable-var "ENABLE_DEPLOY_DASHBOARD" --cli-flags "--deploy-dashboard:--no-deploy-dashboard"
fi

# v2003.1: source時のexit codeを確実に0にする
true
