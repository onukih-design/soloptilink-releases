#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v435.0 - Frontend Render Optimizer
# =============================================================================
# フロントエンドレンダリング最適化。不要な再レンダリング検出、
# React.memo/useMemo/useCallback追加、仮想化リスト推奨を行う。
#
# Functions:
#   _fro_init()                 - 初期化
#   _fro_detect_rerenders()     - 不要再レンダリング検出
#   _fro_add_memoization()      - メモ化推奨
#   _fro_add_virtualization()   - 仮想化推奨
#   _fro_report() / _fro_score()
#
# All globals use the FRO_ prefix.
# =============================================================================

[[ -n "${_FRO_LOADED:-}" ]] && return 0; _FRO_LOADED=1

declare -g FRO_VERSION="435.0"
declare -g FRO_GENERATED=0
declare -g FRO_ERRORS=0
declare -g FRO_COMPONENTS_SCANNED=0
declare -g FRO_RERENDER_ISSUES=0
declare -g FRO_MEMO_SUGGESTIONS=0
declare -g FRO_VIRTUALIZATION_SUGGESTIONS=0
declare -g FRO_OPTIMIZATIONS=0

declare -ga _FRO_FINDINGS=()

_FRO_GREEN="${GREEN:-\033[0;32m}"
_FRO_RED="${RED:-\033[0;31m}"
_FRO_YELLOW="${YELLOW:-\033[0;33m}"
_FRO_CYAN="${CYAN:-\033[0;36m}"
_FRO_BOLD="${BOLD:-\033[1m}"
_FRO_NC="${NC:-\033[0m}"

_fro_init() {
    FRO_GENERATED=0; FRO_ERRORS=0; FRO_COMPONENTS_SCANNED=0
    FRO_RERENDER_ISSUES=0; FRO_MEMO_SUGGESTIONS=0
    FRO_VIRTUALIZATION_SUGGESTIONS=0; FRO_OPTIMIZATIONS=0
    _FRO_FINDINGS=()
    return 0
}

_fro_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_FRO_CYAN}[FRO]${_FRO_NC} $*" >&2 ;;
        ok)    echo -e "  ${_FRO_GREEN}[FRO]${_FRO_NC} $*" >&2 ;;
        warn)  echo -e "  ${_FRO_YELLOW}[FRO]${_FRO_NC} $*" >&2 ;;
        error) echo -e "  ${_FRO_RED}[FRO]${_FRO_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _fro_detect_rerenders - 不要再レンダリング検出
# =============================================================================
_fro_detect_rerenders() {
    local project_dir="${1:-.}"
    _fro_log info "不要再レンダリング検出"

    FRO_COMPONENTS_SCANNED=0
    FRO_RERENDER_ISSUES=0

    while IFS= read -r -d '' file; do
        FRO_COMPONENTS_SCANNED=$((FRO_COMPONENTS_SCANNED + 1))
        local rel="${file#${project_dir}/}"

        # インラインオブジェクト/配列リテラルをpropsに渡す
        local inline_objects
        inline_objects=$(grep -n 'style={{' "$file" 2>/dev/null | wc -l || echo 0)
        local inline_arrays
        inline_arrays=$(grep -n '\[.*\].*}' "$file" 2>/dev/null | grep -v "import\|const\|let\|var" | wc -l || echo 0)

        if [[ $inline_objects -gt 3 ]]; then
            FRO_RERENDER_ISSUES=$((FRO_RERENDER_ISSUES + 1))
            _FRO_FINDINGS+=("INLINE_STYLE:${rel}:${inline_objects}x inline style objects cause rerenders")
            _fro_log warn "インラインstyle: ${rel} (${inline_objects}箇所)"
        fi

        # 匿名関数をpropsに渡す
        local inline_handlers
        inline_handlers=$(grep -n 'onClick={() =>\|onChange={() =>\|onSubmit={() =>' "$file" 2>/dev/null | wc -l || echo 0)
        if [[ $inline_handlers -gt 5 ]]; then
            FRO_RERENDER_ISSUES=$((FRO_RERENDER_ISSUES + 1))
            _FRO_FINDINGS+=("INLINE_HANDLER:${rel}:${inline_handlers}x inline handlers - use useCallback")
        fi

        # useEffectの依存配列問題
        local effect_no_deps
        effect_no_deps=$(grep -c "useEffect(() =>" "$file" 2>/dev/null || echo 0)
        local effect_empty_deps
        effect_empty_deps=$(grep -c "useEffect.*\[\]" "$file" 2>/dev/null || echo 0)
        if [[ $effect_no_deps -gt $effect_empty_deps ]] && [[ $effect_no_deps -gt 0 ]]; then
            local missing=$((effect_no_deps - effect_empty_deps))
            if [[ $missing -gt 0 ]]; then
                _FRO_FINDINGS+=("EFFECT_DEPS:${rel}:${missing}x useEffect may have missing dependency array")
            fi
        fi

        # Context値がオブジェクトで毎レンダリング新規作成
        local context_value
        context_value=$(grep -n "value={{" "$file" 2>/dev/null | wc -l || echo 0)
        if [[ $context_value -gt 0 ]]; then
            FRO_RERENDER_ISSUES=$((FRO_RERENDER_ISSUES + 1))
            _FRO_FINDINGS+=("CONTEXT_VALUE:${rel}:${context_value}x Context value inline object - use useMemo")
        fi

        # 不要なstate更新
        local set_state_in_render
        set_state_in_render=$(grep -n "setState\|set[A-Z]" "$file" 2>/dev/null | grep -v "useEffect\|useCallback\|handler\|onClick\|on[A-Z]" | wc -l || echo 0)
        if [[ $set_state_in_render -gt 3 ]]; then
            _FRO_FINDINGS+=("RENDER_SET_STATE:${rel}:possible state updates during render")
        fi
    done < <(find "$project_dir" \( -name "*.tsx" -o -name "*.jsx" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" -print0 2>/dev/null)

    FRO_GENERATED=$((FRO_GENERATED + 1))
    _fro_log ok "再レンダリング問題: ${FRO_RERENDER_ISSUES}件 (${FRO_COMPONENTS_SCANNED}コンポーネント)"
    return 0
}

# =============================================================================
# _fro_add_memoization - メモ化推奨
# =============================================================================
_fro_add_memoization() {
    local project_dir="${1:-.}"
    _fro_log info "メモ化推奨分析"

    FRO_MEMO_SUGGESTIONS=0

    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"

        # 重い計算がuseMemoなしで実行
        local heavy_compute
        heavy_compute=$(grep -n "\.filter(\|\.map(\|\.reduce(\|\.sort(" "$file" 2>/dev/null | wc -l || echo 0)
        local has_usememo
        has_usememo=$(grep -c "useMemo" "$file" 2>/dev/null || echo 0)

        if [[ $heavy_compute -gt 3 ]] && [[ $has_usememo -eq 0 ]]; then
            FRO_MEMO_SUGGESTIONS=$((FRO_MEMO_SUGGESTIONS + 1))
            _FRO_FINDINGS+=("NEED_MEMO:${rel}:${heavy_compute}x array operations without useMemo")
            _fro_log warn "useMemo推奨: ${rel} (配列操作${heavy_compute}箇所)"
        fi

        # React.memoなしの子コンポーネント
        local is_exported
        is_exported=$(grep -c "export default\|export const\|export function" "$file" 2>/dev/null || echo 0)
        local has_memo
        has_memo=$(grep -c "React.memo\|memo(" "$file" 2>/dev/null || echo 0)
        local has_props
        has_props=$(grep -c "props\|Props\b" "$file" 2>/dev/null || echo 0)

        if [[ $is_exported -gt 0 ]] && [[ $has_memo -eq 0 ]] && [[ $has_props -gt 2 ]]; then
            # propsを多く受け取るコンポーネントはmemo推奨
            FRO_MEMO_SUGGESTIONS=$((FRO_MEMO_SUGGESTIONS + 1))
            _FRO_FINDINGS+=("NEED_REACT_MEMO:${rel}:component with props should consider React.memo")
        fi

        # useCallbackなしのハンドラ
        local handlers
        handlers=$(grep -c "const handle\|function handle" "$file" 2>/dev/null || echo 0)
        local has_callback
        has_callback=$(grep -c "useCallback" "$file" 2>/dev/null || echo 0)

        if [[ $handlers -gt 2 ]] && [[ $has_callback -eq 0 ]]; then
            FRO_MEMO_SUGGESTIONS=$((FRO_MEMO_SUGGESTIONS + 1))
            _FRO_FINDINGS+=("NEED_CALLBACK:${rel}:${handlers}x handlers without useCallback")
        fi
    done < <(find "$project_dir" \( -name "*.tsx" -o -name "*.jsx" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" -print0 2>/dev/null)

    FRO_GENERATED=$((FRO_GENERATED + 1))
    _fro_log ok "メモ化推奨: ${FRO_MEMO_SUGGESTIONS}件"
    return 0
}

# =============================================================================
# _fro_add_virtualization - 仮想化推奨
# =============================================================================
_fro_add_virtualization() {
    local project_dir="${1:-.}"
    _fro_log info "仮想化リスト推奨分析"

    FRO_VIRTUALIZATION_SUGGESTIONS=0

    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"

        # .map()で大量要素をレンダリング
        local map_renders
        map_renders=$(grep -n "\.map(" "$file" 2>/dev/null)

        while IFS= read -r match; do
            [[ -z "$match" ]] && continue
            local line_num="${match%%:*}"
            local context
            context=$(sed -n "$((line_num > 3 ? line_num - 3 : 1)),$((line_num + 5))p" "$file" 2>/dev/null)

            # リスト/テーブルのレンダリング
            if [[ "$context" == *"<li"* ]] || [[ "$context" == *"<tr"* ]] || [[ "$context" == *"<div"* ]]; then
                # react-virtualizedまたはtanstack-virtualの使用チェック
                local has_virtual
                has_virtual=$(grep -c "react-virtualized\|@tanstack/react-virtual\|react-window" "$file" 2>/dev/null || echo 0)
                if [[ $has_virtual -eq 0 ]]; then
                    FRO_VIRTUALIZATION_SUGGESTIONS=$((FRO_VIRTUALIZATION_SUGGESTIONS + 1))
                    _FRO_FINDINGS+=("NEED_VIRTUAL:${rel}:${line_num}:list rendering - consider virtualization")
                fi
            fi
        done <<< "$map_renders"
    done < <(find "$project_dir" \( -name "*.tsx" -o -name "*.jsx" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" -print0 2>/dev/null)

    FRO_OPTIMIZATIONS=$((FRO_RERENDER_ISSUES + FRO_MEMO_SUGGESTIONS + FRO_VIRTUALIZATION_SUGGESTIONS))
    FRO_GENERATED=$((FRO_GENERATED + 1))
    _fro_log ok "仮想化推奨: ${FRO_VIRTUALIZATION_SUGGESTIONS}件"
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_fro_report() {
    echo -e "\n  ${_FRO_BOLD}=== frontend-render-optimizer v${FRO_VERSION} ===${_FRO_NC}"
    echo -e "  コンポーネント  : ${FRO_COMPONENTS_SCANNED}"
    echo -e "  再レンダリング問題: ${FRO_RERENDER_ISSUES}"
    echo -e "  メモ化推奨      : ${FRO_MEMO_SUGGESTIONS}"
    echo -e "  仮想化推奨      : ${FRO_VIRTUALIZATION_SUGGESTIONS}"
    echo -e "  最適化提案合計  : ${FRO_OPTIMIZATIONS}"
    echo -e "  エラー          : ${FRO_ERRORS}"
}

_fro_score() {
    local score=50
    [[ ${FRO_COMPONENTS_SCANNED} -gt 0 ]] && score=$((score + 10))
    [[ ${FRO_RERENDER_ISSUES} -eq 0 ]] && score=$((score + 15))
    [[ ${FRO_MEMO_SUGGESTIONS} -le 2 ]] && score=$((score + 10))
    [[ ${FRO_VIRTUALIZATION_SUGGESTIONS} -eq 0 ]] && score=$((score + 10))
    [[ ${FRO_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "frontend-render-optimizer" --version "${FRO_VERSION}" \
        --description "フロントエンドレンダリング最適化×再レンダリング検出×メモ化 (v435)" \
        --init "_fro_init" --report "_fro_report" --score "_fro_score" \
        --enable-var "ENABLE_RENDER_OPT" --cli-flags "--render-opt:--no-render-opt"
fi

# v2003.1: source時のexit codeを確実に0にする
true
