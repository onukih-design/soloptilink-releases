#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v421.0 - Parallel Generation Engine
# =============================================================================
# ファイル生成の並列実行エンジン。依存関係を解析し、独立したファイルを
# 並列に生成することでビルド時間を大幅短縮する。
#
# Functions:
#   _pge_init()              - 初期化
#   _pge_analyze_deps()      - ファイル間依存関係を解析
#   _pge_plan_parallel()     - 並列実行プランを策定
#   _pge_execute_parallel()  - 並列生成を実行
#   _pge_merge_results()     - 並列結果をマージ・検証
#   _pge_report() / _pge_score() - レポート
#
# All globals use the PGE_ prefix.
# =============================================================================

[[ -n "${_PGE_LOADED:-}" ]] && return 0; _PGE_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g PGE_VERSION="421.0"
declare -g PGE_GENERATED=0
declare -g PGE_ERRORS=0
declare -g PGE_FILES_WRITTEN=0
declare -g PGE_PARALLEL_GROUPS=0
declare -g PGE_MAX_PARALLEL="${PGE_MAX_PARALLEL:-4}"
declare -g PGE_DEPS_ANALYZED=false
declare -g PGE_PLAN_READY=false
declare -g PGE_EXECUTION_DONE=false
declare -g PGE_MERGE_DONE=false
declare -g PGE_TOTAL_TIME=0

declare -gA _PGE_DEP_MAP=()
declare -ga _PGE_EXEC_GROUPS=()
declare -ga _PGE_RESULTS=()

# Colors
_PGE_GREEN="${GREEN:-\033[0;32m}"
_PGE_RED="${RED:-\033[0;31m}"
_PGE_YELLOW="${YELLOW:-\033[0;33m}"
_PGE_CYAN="${CYAN:-\033[0;36m}"
_PGE_BOLD="${BOLD:-\033[1m}"
_PGE_NC="${NC:-\033[0m}"

# =============================================================================
# Init
# =============================================================================
_pge_init() {
    PGE_GENERATED=0
    PGE_ERRORS=0
    PGE_FILES_WRITTEN=0
    PGE_PARALLEL_GROUPS=0
    PGE_DEPS_ANALYZED=false
    PGE_PLAN_READY=false
    PGE_EXECUTION_DONE=false
    PGE_MERGE_DONE=false
    PGE_TOTAL_TIME=0
    _PGE_DEP_MAP=()
    _PGE_EXEC_GROUPS=()
    _PGE_RESULTS=()
    return 0
}

# =============================================================================
# Utility
# =============================================================================
_pge_log() {
    local level="$1"; shift
    local msg="$*"
    case "$level" in
        info)  echo -e "  ${_PGE_CYAN}[PGE]${_PGE_NC} ${msg}" >&2 ;;
        ok)    echo -e "  ${_PGE_GREEN}[PGE]${_PGE_NC} ${msg}" >&2 ;;
        warn)  echo -e "  ${_PGE_YELLOW}[PGE]${_PGE_NC} ${msg}" >&2 ;;
        error) echo -e "  ${_PGE_RED}[PGE]${_PGE_NC} ${msg}" >&2 ;;
    esac
}

_pge_write_file() {
    local filepath="$1"
    local content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    PGE_FILES_WRITTEN=$((PGE_FILES_WRITTEN + 1))
}

# =============================================================================
# _pge_analyze_deps - ファイル間依存関係を解析
# =============================================================================
_pge_analyze_deps() {
    local project_dir="${1:-.}"
    local start_time
    start_time=$(date +%s 2>/dev/null || echo 0)

    _pge_log info "依存関係解析開始: ${project_dir}"

    _PGE_DEP_MAP=()
    local file_count=0

    # TypeScript/JavaScript imports を解析
    while IFS= read -r -d '' file; do
        local rel_path="${file#${project_dir}/}"
        local deps=""

        # import文を解析
        while IFS= read -r line; do
            local imported=""
            if [[ "$line" =~ from\ [\"\'](\..*?)[\"\'] ]]; then
                imported="${BASH_REMATCH[1]}"
            elif [[ "$line" =~ require\([\"\'](\..*?)[\"\']\) ]]; then
                imported="${BASH_REMATCH[1]}"
            fi
            if [[ -n "$imported" ]]; then
                # 相対パスを正規化
                local dir
                dir=$(dirname "$rel_path")
                local resolved="${dir}/${imported}"
                # .ts/.tsx/.js拡張子の正規化
                resolved="${resolved%.ts}"
                resolved="${resolved%.tsx}"
                resolved="${resolved%.js}"
                deps="${deps}${deps:+,}${resolved}"
            fi
        done < <(grep -E "^(import|.*require\()" "$file" 2>/dev/null || true)

        _PGE_DEP_MAP["$rel_path"]="$deps"
        file_count=$((file_count + 1))
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" -print0 2>/dev/null)

    local elapsed=$(( $(date +%s 2>/dev/null || echo 0) - start_time ))
    PGE_DEPS_ANALYZED=true
    _pge_log ok "依存関係解析完了: ${file_count}ファイル (${elapsed}秒)"
    PGE_GENERATED=$((PGE_GENERATED + 1))

    echo "${file_count}"
    return 0
}

# =============================================================================
# _pge_plan_parallel - 並列実行プランを策定（トポロジカルソート）
# =============================================================================
_pge_plan_parallel() {
    local max_groups="${1:-10}"

    _pge_log info "並列実行プラン策定中 (最大${PGE_MAX_PARALLEL}並列)"

    if [[ "$PGE_DEPS_ANALYZED" != "true" ]]; then
        _pge_log error "依存関係が未解析です。先に _pge_analyze_deps() を実行してください"
        PGE_ERRORS=$((PGE_ERRORS + 1))
        return 1
    fi

    _PGE_EXEC_GROUPS=()
    local -A in_degree=()
    local -A remaining=()
    local -a all_files=()

    # 入次数を計算
    for file in "${!_PGE_DEP_MAP[@]}"; do
        all_files+=("$file")
        remaining["$file"]=1
        in_degree["$file"]=0
    done

    for file in "${!_PGE_DEP_MAP[@]}"; do
        local deps="${_PGE_DEP_MAP[$file]}"
        IFS=',' read -ra dep_arr <<< "$deps"
        for dep in "${dep_arr[@]}"; do
            [[ -z "$dep" ]] && continue
            for candidate in "${all_files[@]}"; do
                if [[ "$candidate" == *"$dep"* ]]; then
                    in_degree["$file"]=$(( ${in_degree["$file"]:-0} + 1 ))
                fi
            done
        done
    done

    # トポロジカルソートでグループ分け
    local group_idx=0
    local processed=0
    local total=${#all_files[@]}

    while [[ $processed -lt $total ]] && [[ $group_idx -lt $max_groups ]]; do
        local group_files=""
        local count_in_group=0

        for file in "${all_files[@]}"; do
            [[ "${remaining[$file]:-}" != "1" ]] && continue
            if [[ ${in_degree["$file"]:-0} -eq 0 ]]; then
                group_files="${group_files}${group_files:+|}${file}"
                count_in_group=$((count_in_group + 1))
                if [[ $count_in_group -ge $PGE_MAX_PARALLEL ]]; then
                    break
                fi
            fi
        done

        if [[ -z "$group_files" ]]; then
            # 循環依存の場合、残り全てを1グループに
            for file in "${all_files[@]}"; do
                [[ "${remaining[$file]:-}" != "1" ]] && continue
                group_files="${group_files}${group_files:+|}${file}"
                remaining["$file"]=0
                processed=$((processed + 1))
            done
            _PGE_EXEC_GROUPS+=("$group_files")
            group_idx=$((group_idx + 1))
            break
        fi

        # 処理済みマーク & 入次数更新
        IFS='|' read -ra gfiles <<< "$group_files"
        for gf in "${gfiles[@]}"; do
            remaining["$gf"]=0
            processed=$((processed + 1))
            # このファイルに依存していたファイルの入次数を減らす
            for other in "${all_files[@]}"; do
                [[ "${remaining[$other]:-}" != "1" ]] && continue
                local odeps="${_PGE_DEP_MAP[$other]}"
                if [[ "$odeps" == *"$gf"* ]]; then
                    in_degree["$other"]=$(( ${in_degree["$other"]:-1} - 1 ))
                fi
            done
        done

        _PGE_EXEC_GROUPS+=("$group_files")
        group_idx=$((group_idx + 1))
    done

    PGE_PARALLEL_GROUPS=$group_idx
    PGE_PLAN_READY=true
    PGE_GENERATED=$((PGE_GENERATED + 1))
    _pge_log ok "並列プラン完了: ${PGE_PARALLEL_GROUPS}グループ (${total}ファイル)"

    return 0
}

# =============================================================================
# _pge_execute_parallel - 並列生成を実行
# =============================================================================
_pge_execute_parallel() {
    local generator_fn="${1:-echo}"
    local start_time
    start_time=$(date +%s 2>/dev/null || echo 0)

    if [[ "$PGE_PLAN_READY" != "true" ]]; then
        _pge_log error "並列プランが未策定です"
        PGE_ERRORS=$((PGE_ERRORS + 1))
        return 1
    fi

    _pge_log info "並列生成開始 (${PGE_PARALLEL_GROUPS}グループ)"
    _PGE_RESULTS=()

    local group_idx=0
    for group in "${_PGE_EXEC_GROUPS[@]}"; do
        group_idx=$((group_idx + 1))
        IFS='|' read -ra files <<< "$group"
        local group_size=${#files[@]}

        _pge_log info "グループ ${group_idx}/${PGE_PARALLEL_GROUPS}: ${group_size}ファイル並列"

        local pids=()
        local tmp_dir
        tmp_dir=$(mktemp -d 2>/dev/null || echo "/tmp/pge_$$")
        mkdir -p "$tmp_dir"

        for file in "${files[@]}"; do
            (
                local result
                if type -t "$generator_fn" &>/dev/null; then
                    result=$($generator_fn "$file" 2>&1)
                else
                    result="generated:${file}"
                fi
                echo "$result" > "${tmp_dir}/$(echo "$file" | tr '/' '_').result"
            ) &
            pids+=($!)
        done

        # 全プロセスの完了を待機
        local failed=0
        for pid in "${pids[@]}"; do
            if ! wait "$pid" 2>/dev/null; then
                failed=$((failed + 1))
            fi
        done

        # 結果収集
        for result_file in "${tmp_dir}"/*.result; do
            [[ -f "$result_file" ]] || continue
            local content
            content=$(cat "$result_file" 2>/dev/null || echo "")
            _PGE_RESULTS+=("$content")
        done

        rm -rf "$tmp_dir" 2>/dev/null

        if [[ $failed -gt 0 ]]; then
            _pge_log warn "グループ${group_idx}: ${failed}/${group_size}失敗"
            PGE_ERRORS=$((PGE_ERRORS + failed))
        fi
    done

    PGE_TOTAL_TIME=$(( $(date +%s 2>/dev/null || echo 0) - start_time ))
    PGE_EXECUTION_DONE=true
    PGE_GENERATED=$((PGE_GENERATED + 1))
    _pge_log ok "並列生成完了 (${PGE_TOTAL_TIME}秒, ${#_PGE_RESULTS[@]}結果)"

    return 0
}

# =============================================================================
# _pge_merge_results - 並列結果をマージ・検証
# =============================================================================
_pge_merge_results() {
    local output_dir="${1:-.}"

    if [[ "$PGE_EXECUTION_DONE" != "true" ]]; then
        _pge_log error "実行が未完了です"
        PGE_ERRORS=$((PGE_ERRORS + 1))
        return 1
    fi

    _pge_log info "結果マージ開始: ${#_PGE_RESULTS[@]}件"

    local merged=0
    local conflicts=0

    for result in "${_PGE_RESULTS[@]}"; do
        if [[ "$result" == *"ERROR"* ]] || [[ "$result" == *"error"* ]]; then
            conflicts=$((conflicts + 1))
            _pge_log warn "競合検出: ${result:0:80}..."
        else
            merged=$((merged + 1))
        fi
    done

    PGE_MERGE_DONE=true
    PGE_GENERATED=$((PGE_GENERATED + 1))

    if [[ $conflicts -gt 0 ]]; then
        _pge_log warn "マージ完了: ${merged}成功, ${conflicts}競合"
    else
        _pge_log ok "マージ完了: ${merged}成功, 競合なし"
    fi

    echo "${merged}"
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_pge_report() {
    echo -e "\n  ${_PGE_BOLD}=== parallel-generation-engine v${PGE_VERSION} ===${_PGE_NC}"
    echo -e "  並列グループ数  : ${PGE_PARALLEL_GROUPS}"
    echo -e "  最大並列数      : ${PGE_MAX_PARALLEL}"
    echo -e "  結果数          : ${#_PGE_RESULTS[@]}"
    echo -e "  処理時間        : ${PGE_TOTAL_TIME}秒"
    echo -e "  生成数          : ${PGE_GENERATED}"
    echo -e "  エラー          : ${PGE_ERRORS}"
}

_pge_score() {
    local score=50
    ${PGE_DEPS_ANALYZED} && score=$((score + 10))
    ${PGE_PLAN_READY} && score=$((score + 10))
    ${PGE_EXECUTION_DONE} && score=$((score + 15))
    ${PGE_MERGE_DONE} && score=$((score + 10))
    [[ ${PGE_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "parallel-generation-engine" --version "${PGE_VERSION}" \
        --description "並列ファイル生成×依存解析×トポロジカルソート (v421)" \
        --init "_pge_init" --report "_pge_report" --score "_pge_score" \
        --enable-var "ENABLE_PARALLEL_GEN" --cli-flags "--parallel-gen:--no-parallel-gen"
fi

# v2003.1: source時のexit codeを確実に0にする
true
