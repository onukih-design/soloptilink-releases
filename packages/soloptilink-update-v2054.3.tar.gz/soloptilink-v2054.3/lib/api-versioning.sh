#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - API Versioning
# =============================================================================
# APIバージョニング自動設計×URLパス/ヘッダー戦略×後方互換性変換レイヤー×
# Deprecation/Sunsetヘッダー×API変更ログテンプレート
#
# 機能:
#   av_generate_versioned_routes    - URLパス (/v1/, /v2/) またはヘッダーベースルーティング
#   av_generate_version_middleware  - バージョン検出/ルーティングミドルウェア
#   av_generate_deprecation_headers - Sunset/Deprecationヘッダー
#   av_generate_changelog           - API変更ログテンプレート
#   av_generate_backwards_compat    - レスポンス変換レイヤー（後方互換性）
#   av_inject_versioning_patterns   - Claude生成へのパターン注入
#
# 全globals: AV_ prefix
# =============================================================================

[[ -n "${_AV_LOADED:-}" ]] && return 0; _AV_LOADED=1

# =============================================================================
# State
# =============================================================================
AV_GENERATED=0
AV_ERRORS=0
AV_PHASE="api_versioning"

# =============================================================================
# 初期化
# =============================================================================
av_init() {
    AV_GENERATED=0
    AV_ERRORS=0
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} api-versioning v140.0"
    return 0
}

# =============================================================================
# バージョン検出/ルーティングミドルウェア
# =============================================================================
av_generate_version_middleware() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local mw_dir="${project_dir}/src/lib/versioning"
    mkdir -p "$mw_dir" 2>/dev/null || true

    cat > "${mw_dir}/version-middleware.ts" <<'VERMW'
// =============================================================================
// API Version Detection & Routing Middleware
// Supports URL path (/api/v1/), Accept header, and custom header strategies
// =============================================================================
import { NextRequest, NextResponse } from 'next/server';

export type VersionStrategy = 'url-path' | 'header' | 'accept-header';

export interface VersionConfig {
  strategy: VersionStrategy;
  current: string;        // Current version (e.g., 'v2')
  supported: string[];    // All supported versions (e.g., ['v1', 'v2'])
  deprecated: string[];   // Deprecated but still working (e.g., ['v1'])
  sunset: Record<string, string>; // version -> sunset date ISO string
  defaultVersion: string; // Default when no version specified
  headerName?: string;    // Custom header name (default: 'api-version')
}

export const DEFAULT_VERSION_CONFIG: VersionConfig = {
  strategy: 'url-path',
  current: 'v1',
  supported: ['v1'],
  deprecated: [],
  sunset: {},
  defaultVersion: 'v1',
  headerName: 'api-version',
};

/**
 * Extract API version from request based on strategy.
 */
export function extractVersion(req: NextRequest, config: VersionConfig): string | null {
  switch (config.strategy) {
    case 'url-path': {
      const match = new URL(req.url).pathname.match(/\/api\/(v\d+)\//);
      return match?.[1] || null;
    }
    case 'header': {
      return req.headers.get(config.headerName || 'api-version');
    }
    case 'accept-header': {
      const accept = req.headers.get('accept') || '';
      const match = accept.match(/application\/vnd\.\w+\.(v\d+)\+json/);
      return match?.[1] || null;
    }
    default:
      return null;
  }
}

/**
 * Validate and resolve the API version.
 */
export function resolveVersion(
  requested: string | null,
  config: VersionConfig
): { version: string; isDeprecated: boolean; sunsetDate?: string; error?: string } {
  const version = requested || config.defaultVersion;

  if (!config.supported.includes(version)) {
    return {
      version: config.current,
      isDeprecated: false,
      error: `Unsupported API version: ${version}. Supported: ${config.supported.join(', ')}`,
    };
  }

  return {
    version,
    isDeprecated: config.deprecated.includes(version),
    sunsetDate: config.sunset[version],
  };
}

/**
 * Add versioning headers to response.
 */
export function addVersionHeaders(
  response: NextResponse,
  version: string,
  config: VersionConfig
): NextResponse {
  response.headers.set('X-API-Version', version);

  if (config.deprecated.includes(version)) {
    response.headers.set('Deprecation', 'true');
    response.headers.set(
      'Link',
      `</api/${config.current}/>; rel="successor-version"`
    );

    const sunsetDate = config.sunset[version];
    if (sunsetDate) {
      response.headers.set('Sunset', new Date(sunsetDate).toUTCString());
    }
  }

  return response;
}

/**
 * Middleware function for version detection.
 * Attach to Next.js middleware chain.
 */
export function versionMiddleware(
  req: NextRequest,
  config: VersionConfig = DEFAULT_VERSION_CONFIG
): { version: string; response?: NextResponse } {
  const requested = extractVersion(req, config);
  const resolved = resolveVersion(requested, config);

  if (resolved.error) {
    const errorResponse = NextResponse.json(
      {
        error: {
          code: 'UNSUPPORTED_VERSION',
          message: resolved.error,
          supportedVersions: config.supported,
          currentVersion: config.current,
        },
      },
      { status: 400 }
    );
    return { version: resolved.version, response: errorResponse };
  }

  return { version: resolved.version };
}
VERMW

    AV_GENERATED=$((AV_GENERATED + 1))
    echo -e "  ${GREEN:-\033[0;32m}[AV] version-middleware.ts 生成完了${NC:-\033[0m}" >&2
    return 0
}

# =============================================================================
# バージョン付きルート構造生成
# =============================================================================
av_generate_versioned_routes() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local strategy="${2:-url-path}"
    local routes_dir="${project_dir}/src/lib/versioning"
    mkdir -p "$routes_dir" 2>/dev/null || true

    cat > "${routes_dir}/versioned-router.ts" <<'VROUTER'
// =============================================================================
// Versioned Route Dispatcher
// Maps versioned requests to the correct handler
// =============================================================================
import { NextRequest, NextResponse } from 'next/server';
import {
  extractVersion,
  resolveVersion,
  addVersionHeaders,
  type VersionConfig,
  DEFAULT_VERSION_CONFIG,
} from './version-middleware';

type RouteHandler = (req: NextRequest, ctx?: unknown) => Promise<NextResponse>;

interface VersionedHandlers {
  [version: string]: RouteHandler;
}

/**
 * Create a versioned route handler.
 * Maps different versions to different handler implementations.
 *
 * Usage:
 *   export const GET = createVersionedHandler({
 *     v1: handleGetV1,
 *     v2: handleGetV2,
 *   });
 */
export function createVersionedHandler(
  handlers: VersionedHandlers,
  config: VersionConfig = DEFAULT_VERSION_CONFIG
): RouteHandler {
  return async (req: NextRequest, ctx?: unknown) => {
    const requested = extractVersion(req, config);
    const resolved = resolveVersion(requested, config);

    if (resolved.error) {
      return NextResponse.json(
        {
          error: {
            code: 'UNSUPPORTED_VERSION',
            message: resolved.error,
            supportedVersions: config.supported,
          },
        },
        { status: 400 }
      );
    }

    const handler = handlers[resolved.version];
    if (!handler) {
      // Fall back to latest available handler
      const latestAvailable = config.supported
        .filter((v) => handlers[v])
        .sort()
        .pop();

      if (!latestAvailable || !handlers[latestAvailable]) {
        return NextResponse.json(
          { error: { code: 'NO_HANDLER', message: `No handler for version ${resolved.version}` } },
          { status: 501 }
        );
      }

      const response = await handlers[latestAvailable](req, ctx);
      return addVersionHeaders(response, resolved.version, config);
    }

    const response = await handler(req, ctx);
    return addVersionHeaders(response, resolved.version, config);
  };
}

/**
 * Helper to generate Next.js App Router directory structure info.
 * Next.js convention: /app/api/v1/resource/route.ts
 */
export function getVersionedRoutePath(basePath: string, version: string): string {
  return `/api/${version}${basePath}`;
}
VROUTER

    AV_GENERATED=$((AV_GENERATED + 1))
    echo -e "  ${GREEN:-\033[0;32m}[AV] versioned-router.ts 生成完了${NC:-\033[0m}" >&2
    return 0
}

# =============================================================================
# Deprecation/Sunsetヘッダー
# =============================================================================
av_generate_deprecation_headers() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local dep_dir="${project_dir}/src/lib/versioning"
    mkdir -p "$dep_dir" 2>/dev/null || true

    cat > "${dep_dir}/deprecation.ts" <<'DEPR'
// =============================================================================
// Deprecation & Sunset Header Management
// RFC 8594 (Sunset) and draft-dalal-deprecation-header compliant
// =============================================================================
import { NextResponse } from 'next/server';

interface DeprecationInfo {
  version: string;
  deprecatedAt: string;   // ISO date when deprecated
  sunsetAt: string;        // ISO date when removed
  migration: string;       // Migration guide URL or message
  replacement?: string;    // Replacement API path
}

// Deprecation registry - add entries as versions are deprecated
const deprecationRegistry: DeprecationInfo[] = [
  // Example:
  // {
  //   version: 'v1',
  //   deprecatedAt: '2026-01-01',
  //   sunsetAt: '2026-07-01',
  //   migration: '/docs/migration/v1-to-v2',
  //   replacement: '/api/v2/',
  // },
];

/**
 * Get deprecation info for a version.
 */
export function getDeprecationInfo(version: string): DeprecationInfo | undefined {
  return deprecationRegistry.find((d) => d.version === version);
}

/**
 * Apply deprecation headers to a response.
 */
export function applyDeprecationHeaders(
  response: NextResponse,
  version: string
): NextResponse {
  const info = getDeprecationInfo(version);
  if (!info) return response;

  // Deprecation header (draft-dalal-deprecation-header)
  response.headers.set('Deprecation', info.deprecatedAt);

  // Sunset header (RFC 8594)
  response.headers.set('Sunset', new Date(info.sunsetAt).toUTCString());

  // Link to migration docs and successor version
  const links: string[] = [];
  if (info.migration) {
    links.push(`<${info.migration}>; rel="deprecation"`);
  }
  if (info.replacement) {
    links.push(`<${info.replacement}>; rel="successor-version"`);
  }
  if (links.length > 0) {
    response.headers.set('Link', links.join(', '));
  }

  return response;
}

/**
 * Check if a version is past its sunset date.
 */
export function isVersionSunset(version: string): boolean {
  const info = getDeprecationInfo(version);
  if (!info) return false;
  return new Date() > new Date(info.sunsetAt);
}

/**
 * Register a new deprecation.
 */
export function registerDeprecation(info: DeprecationInfo): void {
  const existing = deprecationRegistry.findIndex((d) => d.version === info.version);
  if (existing >= 0) {
    deprecationRegistry[existing] = info;
  } else {
    deprecationRegistry.push(info);
  }
}
DEPR

    AV_GENERATED=$((AV_GENERATED + 1))
    echo -e "  ${GREEN:-\033[0;32m}[AV] deprecation.ts 生成完了${NC:-\033[0m}" >&2
    return 0
}

# =============================================================================
# API変更ログテンプレート
# =============================================================================
av_generate_changelog() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local docs_dir="${project_dir}/docs"
    mkdir -p "$docs_dir" 2>/dev/null || true

    cat > "${docs_dir}/api-changelog.md" <<'CHANGELOG'
# API Changelog

All notable changes to the API are documented here.

## Versioning Policy

- **URL Path**: `/api/v1/`, `/api/v2/`
- **Deprecation Notice**: Minimum 6 months before sunset
- **Sunset**: Old versions are removed after the sunset date
- **Breaking Changes**: Always require a new major version

## [v1] - Current

### Endpoints
- `GET /api/v1/resources` - List resources
- `POST /api/v1/resources` - Create resource
- `GET /api/v1/resources/:id` - Get resource
- `PUT /api/v1/resources/:id` - Update resource
- `DELETE /api/v1/resources/:id` - Delete resource

### Authentication
- Bearer token via `Authorization` header
- API key via `x-api-key` header

### Rate Limits
- Anonymous: 30 req/15min
- Authenticated: 200 req/15min
- Premium: 1000 req/15min

---

## Migration Guides

### v1 to v2 (when available)
_No migration needed yet. v1 is the current version._
CHANGELOG

    AV_GENERATED=$((AV_GENERATED + 1))
    echo -e "  ${GREEN:-\033[0;32m}[AV] api-changelog.md 生成完了${NC:-\033[0m}" >&2
    return 0
}

# =============================================================================
# レスポンス変換レイヤー（後方互換性）
# =============================================================================
av_generate_backwards_compat() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local compat_dir="${project_dir}/src/lib/versioning"
    mkdir -p "$compat_dir" 2>/dev/null || true

    cat > "${compat_dir}/response-transformer.ts" <<'COMPAT'
// =============================================================================
// Response Transformation Layer
// Transforms v2 responses to v1 format for backward compatibility
// =============================================================================

type TransformFn = (data: Record<string, unknown>) => Record<string, unknown>;

interface VersionTransform {
  from: string;
  to: string;
  transform: TransformFn;
}

// Registry of response transformers
const transformRegistry: VersionTransform[] = [];

/**
 * Register a response transformer between versions.
 *
 * Example:
 *   registerTransform('v2', 'v1', (data) => ({
 *     ...data,
 *     name: data.displayName,     // v2 renamed name to displayName
 *     displayName: undefined,
 *   }));
 */
export function registerTransform(from: string, to: string, transform: TransformFn): void {
  transformRegistry.push({ from, to, transform });
}

/**
 * Transform response data from one version to another.
 * Finds a chain of transforms if no direct transform exists.
 */
export function transformResponse(
  data: Record<string, unknown>,
  fromVersion: string,
  toVersion: string
): Record<string, unknown> {
  if (fromVersion === toVersion) return data;

  // Direct transform
  const direct = transformRegistry.find((t) => t.from === fromVersion && t.to === toVersion);
  if (direct) return direct.transform(data);

  // Chain transform (simple 1-hop)
  for (const t1 of transformRegistry) {
    if (t1.from !== fromVersion) continue;
    const t2 = transformRegistry.find((t) => t.from === t1.to && t.to === toVersion);
    if (t2) {
      return t2.transform(t1.transform(data));
    }
  }

  // No transform found, return as-is with warning
  console.warn(`[versioning] No transform found: ${fromVersion} -> ${toVersion}`);
  return data;
}

/**
 * Transform an array of response items.
 */
export function transformResponseArray(
  items: Record<string, unknown>[],
  fromVersion: string,
  toVersion: string
): Record<string, unknown>[] {
  return items.map((item) => transformResponse(item, fromVersion, toVersion));
}

/**
 * Middleware-style response transformer.
 * Wraps a handler to auto-transform responses for older API versions.
 */
export function withBackwardsCompat(
  currentVersion: string,
  requestedVersion: string
): <T extends Record<string, unknown>>(data: T) => T {
  if (currentVersion === requestedVersion) {
    return (data) => data;
  }
  return (data) => transformResponse(data, currentVersion, requestedVersion) as typeof data;
}

// Example transforms - uncomment and customize:
// registerTransform('v2', 'v1', (data) => {
//   const result = { ...data };
//   // v2 splits 'name' into 'firstName'+'lastName'
//   if (result.firstName && result.lastName) {
//     result.name = `${result.firstName} ${result.lastName}`;
//     delete result.firstName;
//     delete result.lastName;
//   }
//   // v2 renames 'createdAt' to 'created_at'
//   if (result.created_at) {
//     result.createdAt = result.created_at;
//     delete result.created_at;
//   }
//   return result;
// });
COMPAT

    AV_GENERATED=$((AV_GENERATED + 1))
    echo -e "  ${GREEN:-\033[0;32m}[AV] response-transformer.ts 生成完了${NC:-\033[0m}" >&2
    return 0
}

# =============================================================================
# Claude生成プロンプトへのバージョニングパターン注入
# =============================================================================
av_inject_versioning_patterns() {
    local claude_prompt="${1:-}"

    cat <<'INJECT'

## [API-VERSIONING] APIバージョニングルール（必須準拠）

### URLパスバージョニングを使用せよ
- `/api/v1/resources` 形式を標準とする
- ヘッダーバージョニングは必要な場合のみ

### 破壊的変更はメジャーバージョンで
- フィールド名変更、フィールド削除、型変更 → 新バージョン必須
- フィールド追加はマイナー変更（同バージョン内で可）

### 非推奨化プロセス
1. `Deprecation: true` ヘッダーを付与
2. `Sunset: <date>` ヘッダーで終了日を明示
3. `Link: <migration-url>; rel="deprecation"` で移行先を案内
4. 最低6ヶ月の猶予期間

### レスポンス形式の統一
```typescript
// 全APIレスポンスはこの形式
{ data: T, meta?: { page, total, ... } }
{ error: { code: string, message: string, details?: ... } }
```

INJECT

    echo "$claude_prompt"
}

# =============================================================================
# メイン統合実行
# =============================================================================
av_generate_versioning() {
    local project_dir="${PROJECT_DIR:-./output}"
    echo -e "  ${BOLD:-\033[1m}[AV] Starting API versioning generation...${NC:-\033[0m}" >&2

    av_generate_version_middleware "$project_dir"
    av_generate_versioned_routes "$project_dir"
    av_generate_deprecation_headers "$project_dir"
    av_generate_changelog "$project_dir"
    av_generate_backwards_compat "$project_dir"

    echo -e "  ${GREEN:-\033[0;32m}[AV] API versioning generation complete (${AV_GENERATED} files)${NC:-\033[0m}" >&2
    return 0
}

# =============================================================================
# レポート
# =============================================================================
av_report() {
    echo -e "\n  ${BOLD:-}=== api-versioning v140.0 ===${NC:-}"
    echo -e "  生成数: ${AV_GENERATED}"
    echo -e "  エラー: ${AV_ERRORS}"
}

av_score() {
    if [[ ${AV_GENERATED} -gt 0 ]] && [[ ${AV_ERRORS} -eq 0 ]]; then
        echo "90"
    elif [[ ${AV_GENERATED} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "api-versioning" --version "140.0" \
        --description "APIバージョニング自動設計×後方互換性変換×Deprecation管理" \
        --init "av_init" --report "av_report" --score "av_score" \
        --enable-var "ENABLE_API_VERSIONING" --cli-flags "--api-versioning:--no-api-versioning"
fi

# v2003.1: source時のexit codeを確実に0にする
true
