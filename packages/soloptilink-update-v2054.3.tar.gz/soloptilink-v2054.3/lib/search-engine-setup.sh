#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - Search Engine Setup
# =============================================================================
# 全文検索の完全自動構築: Meilisearch/SQLite FTS/pg_trgm対応。
# 検索サービス抽象化、インデックス管理、検索API、検索UI、DB同期を
# 本番品質TypeScript/Reactコードとして直接生成する。
#
# Functions:
#   ses_init()                    - Initialize search config
#   ses_generate_search_service() - Search abstraction (multi-engine)
#   ses_generate_indexing()       - Document indexing with weights/facets
#   ses_generate_search_api()     - Search API endpoint
#   ses_generate_search_ui()      - Search component (React)
#   ses_generate_sync()           - DB-to-search sync hooks
#   ses_generate_search()         - Full search scaffold
#   ses_inject_search_patterns()  - Inject patterns into Claude prompt
#   ses_report() / ses_score()   - Reporting
#
# All globals use the SES_ prefix.
# =============================================================================

[[ -n "${_SES_LOADED:-}" ]] && return 0; _SES_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g SES_VERSION="140.0"
SES_GENERATED=0
SES_ERRORS=0
SES_FILES_WRITTEN=0
SES_PHASE="search"
SES_SERVICE_OK=false
SES_INDEXING_OK=false
SES_API_OK=false
SES_UI_OK=false
SES_SYNC_OK=false

# =============================================================================
# Init
# =============================================================================
ses_init() {
    SES_GENERATED=0
    SES_ERRORS=0
    SES_FILES_WRITTEN=0
    SES_SERVICE_OK=false
    SES_INDEXING_OK=false
    SES_API_OK=false
    SES_UI_OK=false
    SES_SYNC_OK=false
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} Search Engine Setup v${SES_VERSION}"
    return 0
}

# =============================================================================
# Utility
# =============================================================================
_ses_write_file() {
    local filepath="$1"
    local content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        SES_FILES_WRITTEN=$((SES_FILES_WRITTEN + 1))
        return 0
    else
        SES_ERRORS=$((SES_ERRORS + 1))
        return 1
    fi
}

# =============================================================================
# Generate Search Service Abstraction
# =============================================================================
ses_generate_search_service() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local engine="${2:-meilisearch}"

    _ses_write_file "${project_dir}/src/lib/search-service.ts" "$(cat <<'TYPESCRIPT'
import { logger } from '@/lib/logger';

// ====================================================================
// Search Service - Unified abstraction over multiple search engines
// Supports: Meilisearch (default), SQLite FTS, PostgreSQL pg_trgm
// ====================================================================

export interface SearchDocument {
  id: string;
  [key: string]: unknown;
}

export interface SearchOptions {
  query: string;
  filters?: Record<string, string | number | boolean | string[]>;
  facets?: string[];
  sort?: string[];           // e.g., ['createdAt:desc', 'name:asc']
  page?: number;
  limit?: number;
  highlightFields?: string[];
  attributesToRetrieve?: string[];
}

export interface SearchHit<T = Record<string, unknown>> {
  document: T;
  score: number;
  highlights: Record<string, string>;  // field -> highlighted snippet
}

export interface SearchResult<T = Record<string, unknown>> {
  hits: SearchHit<T>[];
  total: number;
  page: number;
  totalPages: number;
  query: string;
  processingTimeMs: number;
  facetDistribution?: Record<string, Record<string, number>>;
}

export interface SearchIndex {
  name: string;
  primaryKey: string;
  searchableAttributes: string[];
  filterableAttributes: string[];
  sortableAttributes: string[];
  displayedAttributes?: string[];
  rankingRules?: string[];
}

interface SearchEngine {
  createIndex(config: SearchIndex): Promise<void>;
  addDocuments(index: string, documents: SearchDocument[]): Promise<void>;
  updateDocuments(index: string, documents: SearchDocument[]): Promise<void>;
  deleteDocuments(index: string, ids: string[]): Promise<void>;
  search<T>(index: string, options: SearchOptions): Promise<SearchResult<T>>;
  deleteIndex(index: string): Promise<void>;
}

// ── Meilisearch Engine ──────────────────────────────────────────────
class MeilisearchEngine implements SearchEngine {
  private baseUrl: string;
  private apiKey: string;

  constructor() {
    this.baseUrl = process.env.MEILISEARCH_URL || 'http://localhost:7700';
    this.apiKey = process.env.MEILISEARCH_API_KEY || '';
  }

  private async request(path: string, method: string, body?: unknown) {
    const headers: Record<string, string> = { 'Content-Type': 'application/json' };
    if (this.apiKey) headers['Authorization'] = `Bearer ${this.apiKey}`;

    const res = await fetch(`${this.baseUrl}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(`Meilisearch error ${res.status}: ${text}`);
    }
    return res.status === 204 ? null : res.json();
  }

  async createIndex(config: SearchIndex) {
    await this.request('/indexes', 'POST', { uid: config.name, primaryKey: config.primaryKey });
    // Configure index settings
    await this.request(`/indexes/${config.name}/settings`, 'PATCH', {
      searchableAttributes: config.searchableAttributes,
      filterableAttributes: config.filterableAttributes,
      sortableAttributes: config.sortableAttributes,
      displayedAttributes: config.displayedAttributes || ['*'],
      rankingRules: config.rankingRules || ['words', 'typo', 'proximity', 'attribute', 'sort', 'exactness'],
    });
  }

  async addDocuments(index: string, documents: SearchDocument[]) {
    await this.request(`/indexes/${index}/documents`, 'POST', documents);
  }

  async updateDocuments(index: string, documents: SearchDocument[]) {
    await this.request(`/indexes/${index}/documents`, 'PUT', documents);
  }

  async deleteDocuments(index: string, ids: string[]) {
    await this.request(`/indexes/${index}/documents/delete-batch`, 'POST', ids);
  }

  async search<T>(index: string, options: SearchOptions): Promise<SearchResult<T>> {
    const page = options.page ?? 1;
    const limit = options.limit ?? 20;

    const body: Record<string, unknown> = {
      q: options.query,
      limit,
      offset: (page - 1) * limit,
      attributesToHighlight: options.highlightFields || ['*'],
      highlightPreTag: '<mark>',
      highlightPostTag: '</mark>',
    };

    if (options.filters) {
      const filterParts: string[] = [];
      for (const [key, value] of Object.entries(options.filters)) {
        if (Array.isArray(value)) {
          filterParts.push(`${key} IN [${value.map(v => `"${v}"`).join(', ')}]`);
        } else if (typeof value === 'string') {
          filterParts.push(`${key} = "${value}"`);
        } else {
          filterParts.push(`${key} = ${value}`);
        }
      }
      if (filterParts.length) body.filter = filterParts.join(' AND ');
    }

    if (options.facets) body.facets = options.facets;
    if (options.sort) body.sort = options.sort;
    if (options.attributesToRetrieve) body.attributesToRetrieve = options.attributesToRetrieve;

    const startTime = Date.now();
    const result = await this.request(`/indexes/${index}/search`, 'POST', body);
    const processingTimeMs = Date.now() - startTime;

    return {
      hits: (result.hits || []).map((hit: any) => ({
        document: hit as T,
        score: hit._rankingScore || 0,
        highlights: hit._formatted || {},
      })),
      total: result.estimatedTotalHits || result.totalHits || 0,
      page,
      totalPages: Math.ceil((result.estimatedTotalHits || 0) / limit),
      query: options.query,
      processingTimeMs,
      facetDistribution: result.facetDistribution,
    };
  }

  async deleteIndex(index: string) {
    await this.request(`/indexes/${index}`, 'DELETE');
  }
}

// ── SQLite FTS Fallback (using Prisma raw queries) ──────────────────
class SQLiteFTSEngine implements SearchEngine {
  async createIndex(_config: SearchIndex) {
    // SQLite FTS tables are created via Prisma migration
    logger.info('[search] SQLite FTS: indexes managed via Prisma migrations');
  }

  async addDocuments(_index: string, _documents: SearchDocument[]) {
    logger.info('[search] SQLite FTS: documents synced via Prisma writes');
  }

  async updateDocuments(_index: string, _documents: SearchDocument[]) {
    logger.info('[search] SQLite FTS: updates synced via Prisma writes');
  }

  async deleteDocuments(_index: string, _ids: string[]) {
    logger.info('[search] SQLite FTS: deletes synced via Prisma writes');
  }

  async search<T>(index: string, options: SearchOptions): Promise<SearchResult<T>> {
    // Fallback: use Prisma's contains for basic search
    const { prisma } = await import('@/lib/prisma');
    const page = options.page ?? 1;
    const limit = options.limit ?? 20;
    const startTime = Date.now();

    try {
      const where = { OR: [
        { name: { contains: options.query } },
        { title: { contains: options.query } },
        { description: { contains: options.query } },
      ].filter(Boolean) };

      const [items, total] = await Promise.all([
        (prisma as any)[index]?.findMany({ where, skip: (page - 1) * limit, take: limit }) ?? [],
        (prisma as any)[index]?.count({ where }) ?? 0,
      ]);

      return {
        hits: (items || []).map((doc: any) => ({
          document: doc as T,
          score: 1,
          highlights: {},
        })),
        total,
        page,
        totalPages: Math.ceil(total / limit),
        query: options.query,
        processingTimeMs: Date.now() - startTime,
      };
    } catch (error) {
      logger.error('[search] SQLite FTS query failed', error as Error);
      return { hits: [], total: 0, page, totalPages: 0, query: options.query, processingTimeMs: Date.now() - startTime };
    }
  }

  async deleteIndex(_index: string) {
    logger.info('[search] SQLite FTS: index deletion is a no-op');
  }
}

// ── Engine Singleton ────────────────────────────────────────────────
function createSearchEngine(): SearchEngine {
  const engine = process.env.SEARCH_ENGINE || 'meilisearch';
  switch (engine) {
    case 'meilisearch': return new MeilisearchEngine();
    case 'sqlite':
    default: return new SQLiteFTSEngine();
  }
}

export const searchEngine = createSearchEngine();
TYPESCRIPT
)"
    SES_SERVICE_OK=true
    SES_GENERATED=$((SES_GENERATED + 1))
}

# =============================================================================
# Generate Indexing Configuration
# =============================================================================
ses_generate_indexing() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ses_write_file "${project_dir}/src/lib/search-indexes.ts" "$(cat <<'TYPESCRIPT'
import { searchEngine, type SearchIndex } from './search-service';
import { logger } from '@/lib/logger';

// ====================================================================
// Search Index Definitions - Configure searchable entities
// ====================================================================

export const SEARCH_INDEXES: SearchIndex[] = [
  {
    name: 'users',
    primaryKey: 'id',
    searchableAttributes: ['name', 'email'],
    filterableAttributes: ['role', 'isActive'],
    sortableAttributes: ['name', 'createdAt'],
  },
  {
    name: 'projects',
    primaryKey: 'id',
    searchableAttributes: ['name', 'description', 'tags'],
    filterableAttributes: ['status', 'ownerId', 'createdAt'],
    sortableAttributes: ['name', 'createdAt', 'updatedAt'],
  },
  {
    name: 'tasks',
    primaryKey: 'id',
    searchableAttributes: ['title', 'description'],
    filterableAttributes: ['status', 'priority', 'assigneeId', 'projectId'],
    sortableAttributes: ['title', 'createdAt', 'dueDate', 'priority'],
  },
];

/** Initialize all search indexes */
export async function initializeSearchIndexes(): Promise<void> {
  for (const index of SEARCH_INDEXES) {
    try {
      await searchEngine.createIndex(index);
      logger.info(`[search] Index "${index.name}" initialized`);
    } catch (error) {
      logger.error(`[search] Failed to initialize index "${index.name}"`, error as Error);
    }
  }
}

/** Index a batch of documents */
export async function indexDocuments(indexName: string, documents: Array<{ id: string; [key: string]: unknown }>): Promise<void> {
  if (documents.length === 0) return;
  const BATCH_SIZE = 500;
  for (let i = 0; i < documents.length; i += BATCH_SIZE) {
    const batch = documents.slice(i, i + BATCH_SIZE);
    await searchEngine.addDocuments(indexName, batch);
    logger.info(`[search] Indexed ${Math.min(i + BATCH_SIZE, documents.length)}/${documents.length} documents into "${indexName}"`);
  }
}

/** Remove documents from index */
export async function removeFromIndex(indexName: string, ids: string[]): Promise<void> {
  if (ids.length === 0) return;
  await searchEngine.deleteDocuments(indexName, ids);
}

/** Full reindex of an entity type from database */
export async function fullReindex(indexName: string): Promise<number> {
  const { prisma } = await import('@/lib/prisma');
  const model = (prisma as any)[indexName];
  if (!model) {
    logger.warn(`[search] No Prisma model found for "${indexName}"`);
    return 0;
  }

  const BATCH_SIZE = 500;
  let indexed = 0;
  let skip = 0;

  while (true) {
    const batch = await model.findMany({ skip, take: BATCH_SIZE });
    if (batch.length === 0) break;
    await searchEngine.addDocuments(indexName, batch);
    indexed += batch.length;
    skip += BATCH_SIZE;
  }

  logger.info(`[search] Full reindex of "${indexName}": ${indexed} documents`);
  return indexed;
}
TYPESCRIPT
)"
    SES_INDEXING_OK=true
    SES_GENERATED=$((SES_GENERATED + 1))
}

# =============================================================================
# Generate Search API
# =============================================================================
ses_generate_search_api() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ses_write_file "${project_dir}/src/app/api/search/route.ts" "$(cat <<'TYPESCRIPT'
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { searchEngine } from '@/lib/search-service';
import { getCurrentUser } from '@/lib/auth';
import { SEARCH_INDEXES } from '@/lib/search-indexes';

const searchParamsSchema = z.object({
  q: z.string().min(1).max(200),
  index: z.string().min(1),
  page: z.coerce.number().int().min(1).default(1),
  limit: z.coerce.number().int().min(1).max(100).default(20),
  filters: z.string().optional(),        // JSON-encoded filters
  sort: z.string().optional(),           // comma-separated, e.g., "createdAt:desc"
  facets: z.string().optional(),         // comma-separated facet fields
});

/** GET /api/search?q=query&index=tasks&page=1&limit=20 */
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const params = Object.fromEntries(request.nextUrl.searchParams);
    const parsed = searchParamsSchema.safeParse(params);
    if (!parsed.success) {
      return NextResponse.json({ error: 'Invalid search parameters', details: parsed.error.flatten() }, { status: 400 });
    }
    const { q, index, page, limit, filters: filtersStr, sort: sortStr, facets: facetsStr } = parsed.data;

    // Validate index exists
    if (!SEARCH_INDEXES.find(i => i.name === index)) {
      return NextResponse.json({ error: `Unknown index: ${index}` }, { status: 400 });
    }

    // Parse optional parameters
    let filters: Record<string, unknown> | undefined;
    if (filtersStr) {
      try { filters = JSON.parse(filtersStr); } catch { return NextResponse.json({ error: 'Invalid filters JSON' }, { status: 400 }); }
    }
    const sort = sortStr?.split(',').map(s => s.trim()).filter(Boolean);
    const facets = facetsStr?.split(',').map(s => s.trim()).filter(Boolean);

    const result = await searchEngine.search(index, {
      query: q,
      page,
      limit,
      filters: filters as Record<string, string>,
      sort,
      facets,
      highlightFields: ['*'],
    });

    return NextResponse.json(result);
  } catch (error) {
    console.error('[search] Search error:', error);
    return NextResponse.json({ error: 'Search failed' }, { status: 500 });
  }
}
TYPESCRIPT
)"

    # Reindex admin endpoint
    _ses_write_file "${project_dir}/src/app/api/search/reindex/route.ts" "$(cat <<'TYPESCRIPT'
import { NextRequest, NextResponse } from 'next/server';
import { requireRole } from '@/lib/rbac';
import { fullReindex } from '@/lib/search-indexes';

/** POST /api/search/reindex - Admin-only full reindex */
export async function POST(request: NextRequest) {
  try {
    await requireRole('admin');

    const body = await request.json().catch(() => ({}));
    const indexName = body.index;

    if (indexName) {
      const count = await fullReindex(indexName);
      return NextResponse.json({ success: true, index: indexName, indexed: count });
    }

    // Reindex all
    const results: Record<string, number> = {};
    const { SEARCH_INDEXES } = await import('@/lib/search-indexes');
    for (const idx of SEARCH_INDEXES) {
      results[idx.name] = await fullReindex(idx.name);
    }
    return NextResponse.json({ success: true, results });
  } catch (error: any) {
    if (error.message === 'UNAUTHORIZED') return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    if (error.message === 'FORBIDDEN') return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    return NextResponse.json({ error: 'Reindex failed' }, { status: 500 });
  }
}
TYPESCRIPT
)"
    SES_API_OK=true
    SES_GENERATED=$((SES_GENERATED + 1))
}

# =============================================================================
# Generate Search UI Component
# =============================================================================
ses_generate_search_ui() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ses_write_file "${project_dir}/src/components/SearchBox.tsx" "$(cat <<'TYPESCRIPT'
'use client';
import { useState, useEffect, useRef, useCallback } from 'react';

interface SearchHit {
  document: Record<string, unknown>;
  highlights: Record<string, string>;
  score: number;
}

interface SearchResult {
  hits: SearchHit[];
  total: number;
  page: number;
  totalPages: number;
  processingTimeMs: number;
}

interface SearchBoxProps {
  index: string;                              // Search index name
  placeholder?: string;
  onSelect?: (hit: SearchHit) => void;       // Called when user selects a result
  renderHit?: (hit: SearchHit) => React.ReactNode;  // Custom hit renderer
  debounceMs?: number;
  minChars?: number;
  filters?: Record<string, string>;
  className?: string;
}

export function SearchBox({
  index,
  placeholder = 'Search...',
  onSelect,
  renderHit,
  debounceMs = 300,
  minChars = 2,
  filters,
  className = '',
}: SearchBoxProps) {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<SearchResult | null>(null);
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const inputRef = useRef<HTMLInputElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const debounceRef = useRef<NodeJS.Timeout>();

  // Debounced search
  const doSearch = useCallback(async (q: string) => {
    if (q.length < minChars) {
      setResults(null);
      setIsOpen(false);
      return;
    }

    setLoading(true);
    try {
      const params = new URLSearchParams({ q, index, limit: '10' });
      if (filters) params.set('filters', JSON.stringify(filters));

      const res = await fetch(`/api/search?${params}`);
      if (res.ok) {
        const data = await res.json();
        setResults(data);
        setIsOpen(data.hits.length > 0);
        setSelectedIndex(-1);
      }
    } catch {
      // Silently fail - search is non-critical
    } finally {
      setLoading(false);
    }
  }, [index, minChars, filters]);

  useEffect(() => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => doSearch(query), debounceMs);
    return () => { if (debounceRef.current) clearTimeout(debounceRef.current); };
  }, [query, debounceMs, doSearch]);

  // Close on outside click
  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (containerRef.current && !containerRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  // Keyboard navigation
  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (!isOpen || !results) return;
    const hits = results.hits;

    switch (e.key) {
      case 'ArrowDown':
        e.preventDefault();
        setSelectedIndex(prev => Math.min(prev + 1, hits.length - 1));
        break;
      case 'ArrowUp':
        e.preventDefault();
        setSelectedIndex(prev => Math.max(prev - 1, -1));
        break;
      case 'Enter':
        e.preventDefault();
        if (selectedIndex >= 0 && hits[selectedIndex]) {
          onSelect?.(hits[selectedIndex]);
          setIsOpen(false);
          setQuery('');
        }
        break;
      case 'Escape':
        setIsOpen(false);
        inputRef.current?.blur();
        break;
    }
  };

  const defaultRenderHit = (hit: SearchHit) => {
    const doc = hit.document as Record<string, string>;
    const title = doc.title || doc.name || doc.email || String(doc.id);
    const subtitle = doc.description || doc.body || '';
    return (
      <div>
        <div className="font-medium text-sm" dangerouslySetInnerHTML={{
          __html: hit.highlights.title || hit.highlights.name || title
        }} />
        {subtitle && (
          <div className="text-xs text-gray-500 truncate" dangerouslySetInnerHTML={{
            __html: (hit.highlights.description || subtitle).substring(0, 120)
          }} />
        )}
      </div>
    );
  };

  return (
    <div ref={containerRef} className={`relative ${className}`}>
      <div className="relative">
        <input
          ref={inputRef}
          type="text"
          value={query}
          onChange={e => setQuery(e.target.value)}
          onFocus={() => results && results.hits.length > 0 && setIsOpen(true)}
          onKeyDown={handleKeyDown}
          placeholder={placeholder}
          className="w-full px-4 py-2 pl-10 rounded-lg border border-gray-300 focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500"
          role="combobox"
          aria-expanded={isOpen}
          aria-autocomplete="list"
          aria-controls="search-results"
        />
        <svg className="absolute left-3 top-2.5 h-5 w-5 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
        </svg>
        {loading && (
          <div className="absolute right-3 top-2.5">
            <div className="animate-spin h-5 w-5 border-2 border-indigo-500 rounded-full border-t-transparent" />
          </div>
        )}
      </div>

      {isOpen && results && (
        <ul id="search-results" role="listbox"
          className="absolute z-50 w-full mt-1 bg-white rounded-lg shadow-lg border border-gray-200 max-h-80 overflow-y-auto">
          {results.hits.map((hit, idx) => (
            <li
              key={String(hit.document.id)}
              role="option"
              aria-selected={idx === selectedIndex}
              className={`px-4 py-2 cursor-pointer ${idx === selectedIndex ? 'bg-indigo-50' : 'hover:bg-gray-50'}`}
              onClick={() => { onSelect?.(hit); setIsOpen(false); setQuery(''); }}
              onMouseEnter={() => setSelectedIndex(idx)}
            >
              {renderHit ? renderHit(hit) : defaultRenderHit(hit)}
            </li>
          ))}
          <li className="px-4 py-1.5 text-xs text-gray-400 border-t">
            {results.total} results in {results.processingTimeMs}ms
          </li>
        </ul>
      )}
    </div>
  );
}
TYPESCRIPT
)"

    # useSearch hook
    _ses_write_file "${project_dir}/src/hooks/useSearch.ts" "$(cat <<'TYPESCRIPT'
'use client';
import { useState, useCallback, useRef } from 'react';

interface SearchOptions {
  index: string;
  limit?: number;
  debounceMs?: number;
  filters?: Record<string, string>;
}

interface SearchHit {
  document: Record<string, unknown>;
  highlights: Record<string, string>;
  score: number;
}

interface SearchState {
  hits: SearchHit[];
  total: number;
  page: number;
  totalPages: number;
  loading: boolean;
  error: string | null;
  processingTimeMs: number;
}

export function useSearch(options: SearchOptions) {
  const { index, limit = 20, debounceMs = 300, filters } = options;
  const [state, setState] = useState<SearchState>({
    hits: [], total: 0, page: 1, totalPages: 0, loading: false, error: null, processingTimeMs: 0,
  });
  const debounceRef = useRef<NodeJS.Timeout>();

  const search = useCallback(async (query: string, page = 1) => {
    if (!query.trim()) {
      setState(prev => ({ ...prev, hits: [], total: 0, page: 1, totalPages: 0, error: null }));
      return;
    }

    setState(prev => ({ ...prev, loading: true, error: null }));
    try {
      const params = new URLSearchParams({ q: query, index, page: String(page), limit: String(limit) });
      if (filters) params.set('filters', JSON.stringify(filters));

      const res = await fetch(`/api/search?${params}`);
      if (!res.ok) throw new Error(`Search failed: ${res.status}`);

      const data = await res.json();
      setState({
        hits: data.hits,
        total: data.total,
        page: data.page,
        totalPages: data.totalPages,
        loading: false,
        error: null,
        processingTimeMs: data.processingTimeMs,
      });
    } catch (error) {
      setState(prev => ({
        ...prev,
        loading: false,
        error: error instanceof Error ? error.message : 'Search failed',
      }));
    }
  }, [index, limit, filters]);

  const debouncedSearch = useCallback((query: string, page = 1) => {
    if (debounceRef.current) clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => search(query, page), debounceMs);
  }, [search, debounceMs]);

  return { ...state, search, debouncedSearch };
}
TYPESCRIPT
)"
    SES_UI_OK=true
    SES_GENERATED=$((SES_GENERATED + 1))
}

# =============================================================================
# Generate DB-to-Search Sync
# =============================================================================
ses_generate_sync() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ses_write_file "${project_dir}/src/lib/search-sync.ts" "$(cat <<'TYPESCRIPT'
import { searchEngine } from './search-service';
import { SEARCH_INDEXES } from './search-indexes';
import { logger } from '@/lib/logger';

// ====================================================================
// Database-to-Search Synchronization
// On-write hooks + batch reindex support
// ====================================================================

/** Sync a single document to search after a write operation */
export async function syncToSearch(
  indexName: string,
  action: 'create' | 'update' | 'delete',
  document: { id: string; [key: string]: unknown }
): Promise<void> {
  const indexConfig = SEARCH_INDEXES.find(i => i.name === indexName);
  if (!indexConfig) return; // Not a searchable entity

  try {
    switch (action) {
      case 'create':
      case 'update':
        await searchEngine.updateDocuments(indexName, [document]);
        break;
      case 'delete':
        await searchEngine.deleteDocuments(indexName, [document.id]);
        break;
    }
  } catch (error) {
    // Search sync failure is non-critical - log and continue
    logger.warn(`[search-sync] Failed to sync ${indexName}/${document.id} (${action})`, {
      error: error instanceof Error ? error.message : String(error),
    });
  }
}

/**
 * Prisma middleware for automatic search sync.
 * Add to Prisma client: prisma.$use(searchSyncMiddleware());
 */
export function searchSyncMiddleware() {
  return async (params: any, next: (params: any) => Promise<any>) => {
    const result = await next(params);
    const model = params.model?.toLowerCase();
    const indexConfig = SEARCH_INDEXES.find(i => i.name === model);
    if (!indexConfig) return result;

    try {
      if (['create', 'update', 'upsert'].includes(params.action) && result?.id) {
        await syncToSearch(model, params.action === 'create' ? 'create' : 'update', result);
      } else if (params.action === 'delete' && result?.id) {
        await syncToSearch(model, 'delete', { id: result.id });
      }
    } catch {
      // Non-critical: don't fail the DB operation if search sync fails
    }

    return result;
  };
}

/**
 * Batch sync: fetch all records from DB and send to search engine.
 * Use for initial setup or recovery from desync.
 */
export async function batchSync(indexName: string, documents: Array<{ id: string; [key: string]: unknown }>): Promise<number> {
  if (documents.length === 0) return 0;
  const BATCH_SIZE = 500;
  let synced = 0;

  for (let i = 0; i < documents.length; i += BATCH_SIZE) {
    const batch = documents.slice(i, i + BATCH_SIZE);
    await searchEngine.addDocuments(indexName, batch);
    synced += batch.length;
  }

  logger.info(`[search-sync] Batch synced ${synced} documents to "${indexName}"`);
  return synced;
}

/**
 * Health check: verify search engine connectivity.
 */
export async function isSearchHealthy(): Promise<boolean> {
  try {
    // Try a simple search to verify connectivity
    await searchEngine.search(SEARCH_INDEXES[0]?.name || 'test', { query: '', limit: 1 });
    return true;
  } catch {
    return false;
  }
}
TYPESCRIPT
)"
    SES_SYNC_OK=true
    SES_GENERATED=$((SES_GENERATED + 1))
}

# =============================================================================
# Inject Search Patterns
# =============================================================================
ses_inject_search_patterns() {
    local prompt="${1:-}"
    cat <<'INJECT'

## [SEARCH] Full-Text Search Best Practices (MANDATORY)

### Usage Pattern:
```typescript
import { searchEngine } from '@/lib/search-service';
import { syncToSearch } from '@/lib/search-sync';

// After DB write, sync to search
await prisma.task.create({ data: taskData });
await syncToSearch('tasks', 'create', taskData);

// Search with filters and pagination
const results = await searchEngine.search('tasks', {
  query: 'bug fix',
  filters: { status: 'open', priority: 'high' },
  sort: ['createdAt:desc'],
  page: 1,
  limit: 20,
});
```

### Rules:
- ALWAYS sync search index after DB writes (create/update/delete)
- Use searchSyncMiddleware() on Prisma for automatic sync
- Search failures are NON-CRITICAL (log and continue, never throw)
- Set appropriate searchable/filterable attributes per entity
- Debounce search input (300ms minimum)
- Search UI MUST support keyboard navigation (Arrow keys + Enter + Escape)
- Highlight matching text in search results

INJECT
    echo "$prompt"
}

# =============================================================================
# Full Search Scaffold
# =============================================================================
ses_generate_search() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    echo "[search-engine-setup] Generating search infrastructure for ${project_dir}..."

    ses_generate_search_service "$project_dir" "meilisearch"
    ses_generate_indexing "$project_dir"
    ses_generate_search_api "$project_dir"
    ses_generate_search_ui "$project_dir"
    ses_generate_sync "$project_dir"

    echo "[search-engine-setup] Generated ${SES_FILES_WRITTEN} files, ${SES_GENERATED} components"
    return 0
}

# =============================================================================
# Report
# =============================================================================
ses_report() {
    echo -e "\n  ${BOLD:-}=== Search Engine Setup v${SES_VERSION} ===${NC:-}"
    echo -e "  生成コンポーネント: ${SES_GENERATED}"
    echo -e "  ファイル書込数: ${SES_FILES_WRITTEN}"
    echo -e "  Search Service: $(${SES_SERVICE_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Indexing: $(${SES_INDEXING_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Search API: $(${SES_API_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Search UI: $(${SES_UI_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  DB Sync: $(${SES_SYNC_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  エラー: ${SES_ERRORS}"
}

ses_report_json() {
    cat <<JSON
{
  "module": "search-engine-setup",
  "version": "${SES_VERSION}",
  "generated": ${SES_GENERATED},
  "files_written": ${SES_FILES_WRITTEN},
  "errors": ${SES_ERRORS},
  "components": {
    "search_service": ${SES_SERVICE_OK},
    "indexing": ${SES_INDEXING_OK},
    "search_api": ${SES_API_OK},
    "search_ui": ${SES_UI_OK},
    "db_sync": ${SES_SYNC_OK}
  }
}
JSON
}

ses_score() {
    local score=50
    ${SES_SERVICE_OK} && score=$((score + 10))
    ${SES_INDEXING_OK} && score=$((score + 10))
    ${SES_API_OK} && score=$((score + 10))
    ${SES_UI_OK} && score=$((score + 10))
    ${SES_SYNC_OK} && score=$((score + 10))
    [[ ${SES_ERRORS} -eq 0 ]] || score=$((score - 10))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry self-registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "search-engine-setup" --version "140.0" \
        --description "全文検索自動構築×Meilisearch/SQLite FTS (v140完全実装)" \
        --init "ses_init" --report "ses_report" --report-json "ses_report_json" --score "ses_score" \
        --enable-var "ENABLE_SEARCH" --cli-flags "--search:--no-search"
fi

# v2003.1: source時のexit codeを確実に0にする
true
