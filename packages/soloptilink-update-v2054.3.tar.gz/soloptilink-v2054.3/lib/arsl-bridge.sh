#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2017.0 - ARSL Bridge (chain.sh ↔ ARSL 統合)
# =============================================================================
# chain.sh の各フェーズに ARSL を強制配線するブリッジ。
# v2016.0 RVG と同じ呼び出しパターン:
#   - chain.sh 起動時に ENABLE_ARSL=true (デフォルト) で本ブリッジが loader 経由で source
#   - フェーズ前: arsl_pre_inspect "$task_text"
#   - フェーズ後: arsl_post_verify  "$last_output"
#   - finalize : arsl_finalize_project "$PROJECT_DIR" → install + Fortress 採点
# =============================================================================

[[ -n "${_ARSL_BRIDGE_LOADED:-}" ]] && return 0
_ARSL_BRIDGE_LOADED=1

ARSL_BRIDGE_VERSION="v2017.0"
ARSL_DIR="${HOME}/.soloptilink/lib/security/arsl"
ARSL_BRIDGE_LOG="${HOME}/.soloptilink/.arsl/logs/bridge-$(date '+%Y%m').jsonl"
ENABLE_ARSL="${ENABLE_ARSL:-true}"
ARSL_BLOCK_ON_INJECTION="${ARSL_BLOCK_ON_INJECTION:-true}"
ARSL_FORTRESS_THRESHOLD="${ARSL_FORTRESS_THRESHOLD:-136}"  # Gold 以上で合格

ARSL_BR_RED='\033[0;31m'; ARSL_BR_YEL='\033[0;33m'; ARSL_BR_GRN='\033[0;32m'
ARSL_BR_CYAN='\033[0;36m'; ARSL_BR_BOLD='\033[1m'; ARSL_BR_NC='\033[0m'

mkdir -p "$(dirname "$ARSL_BRIDGE_LOG")" 2>/dev/null

arsl_log() {
    local action="$1" verdict="$2" detail="$3"
    printf '{"ts":"%s","module":"arsl-bridge","action":"%s","verdict":"%s","detail":"%s"}\n' \
        "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$action" "$verdict" "${detail//\"/\\\"}" \
        >> "$ARSL_BRIDGE_LOG" 2>/dev/null
}

# Step 0: kill-switch 確認 (chain.sh 起動直後に必ず呼ぶ)
arsl_assert_open() {
    [[ "$ENABLE_ARSL" != "true" ]] && return 0
    local ks="${ARSL_DIR}/kill-switch.sh"
    [[ ! -f "$ks" ]] && return 0
    if ! bash "$ks" assert >/dev/null 2>&1; then
        echo -e "${ARSL_BR_RED}${ARSL_BR_BOLD}[ARSL]${ARSL_BR_NC} Kill-switch ENGAGED — chain.sh aborting" >&2
        bash "$ks" status >&2
        arsl_log "boot" "BLOCK" "kill-switch engaged"
        return 1
    fi
    arsl_log "boot" "ALLOW" "kill-switch open"
    return 0
}

# 入力検査: ユーザのタスク原文を ARSL に通す
arsl_pre_inspect() {
    local text="$1"
    [[ "$ENABLE_ARSL" != "true" ]] && return 0
    [[ -z "$text" ]] && return 0
    local pig="${ARSL_DIR}/prompt-injection-guard.sh"
    local jbd="${ARSL_DIR}/jailbreak-defense.sh"
    local aid="${ARSL_DIR}/adversarial-input-detector.sh"

    local block=0
    if [[ -f "$pig" ]]; then
        bash "$pig" scan "$text" "chain.input" >/dev/null 2>&1
        local rc=$?
        [[ $rc -eq 2 ]] && block=$((block+1))
    fi
    if [[ -f "$jbd" ]]; then
        # source して関数呼び出し（rcだけ取る）
        ( source "$jbd"; jbd_init >/dev/null 2>&1; jbd_scan "$text" "chain.input" >/dev/null 2>&1 )
        [[ $? -eq 2 ]] && block=$((block+1))
    fi
    if [[ -f "$aid" ]]; then
        ( source "$aid"; aid_init >/dev/null 2>&1; aid_analyze "$text" "chain.input" >/dev/null 2>&1 ) || true
    fi

    if [[ $block -gt 0 && "$ARSL_BLOCK_ON_INJECTION" == "true" ]]; then
        echo -e "${ARSL_BR_RED}${ARSL_BR_BOLD}[ARSL]${ARSL_BR_NC} Prompt injection / jailbreak 検出。タスクを中止します。" >&2
        echo -e "${ARSL_BR_YEL}別の表現で依頼を再投入してください。${ARSL_BR_NC}" >&2
        arsl_log "pre_inspect" "BLOCK" "${text:0:80}"
        return 2
    fi
    arsl_log "pre_inspect" "ALLOW" "${text:0:80}"
    return 0
}

# 出力検査: AI生成出力を AOV に通す
arsl_post_verify() {
    local output="$1" source_label="${2:-chain.output}"
    [[ "$ENABLE_ARSL" != "true" ]] && return 0
    [[ -z "$output" ]] && return 0
    local aov="${ARSL_DIR}/ai-output-verifier.sh"
    [[ ! -f "$aov" ]] && return 0
    bash "$aov" verify "$output" "$source_label" >/dev/null 2>&1
    local rc=$?
    case $rc in
        0) arsl_log "post_verify" "ALLOW" "$source_label"; return 0 ;;
        1) arsl_log "post_verify" "REDACT" "$source_label"; return 1 ;;
        2) arsl_log "post_verify" "BLOCK"  "$source_label"; return 2 ;;
    esac
}

# 生成プロジェクトに ARSL を自動配線 (defense-in-depth + CLAUDE.md + package.json scripts)
arsl_install_to_project() {
    local project_dir="$1"
    [[ "$ENABLE_ARSL" != "true" ]] && return 0
    [[ -z "$project_dir" || ! -d "$project_dir" ]] && return 0

    local did="${ARSL_DIR}/defense-in-depth.sh"
    local scg="${ARSL_DIR}/supply-chain-guard.sh"
    [[ -f "$did" ]] && bash "$did" apply "$project_dir" >/dev/null 2>&1
    [[ -f "$scg" ]] && bash "$scg" sbom "$project_dir" "${project_dir}/SBOM.spdx.json" >/dev/null 2>&1

    # package.json に arsl:check スクリプト追記 (Node.js プロジェクト)
    local pkg="${project_dir}/package.json"
    if [[ -f "$pkg" ]] && ! grep -q '"arsl:check"' "$pkg"; then
        # node でパース→修正 (jq があれば優先)
        if command -v jq &>/dev/null; then
            local tmp; tmp=$(mktemp)
            jq '.scripts["arsl:check"]   = "echo ARSL Pre-Check via SoloptiLinkAI v2017.0 && bash ~/.soloptilink/lib/security/arsl/arsl-orchestrator.sh run ."
                | .scripts["arsl:install"] = "bash ~/.soloptilink/lib/security/arsl/arsl-orchestrator.sh install ."
                | .scripts["arsl:fortress"] = "bash ~/.soloptilink/lib/security/arsl/security-fortress.sh run ."' \
                "$pkg" > "$tmp" && mv "$tmp" "$pkg"
        fi
    fi

    # CLAUDE.md にARSLガイド追記
    local cmd="${project_dir}/CLAUDE.md"
    if [[ ! -f "$cmd" ]] || ! grep -q "ARSL" "$cmd"; then
        cat >> "$cmd" <<'EOF'

## ARSL (AI-Resilient Security Layer) v2017.0

このプロジェクトは SoloptiLinkAI v2017.0 によって ARSL 自動配線済みです。

### 配線済みファイル
- `src/middleware.ts` — CSP/HSTS/X-Frame-Options (L1 Edge)
- `src/lib/arsl/input-firewall.ts` — Prompt Injection 検知 (L3 Input)
- `src/lib/arsl/output-verifier.ts` — PII redact + harmful intent block (L5 Output)
- `src/lib/arsl/audit-logger.ts` — append-only audit log (L6 SIEM)
- `SBOM.spdx.json` — Software Bill of Materials (CycloneDX 1.6)

### 実行コマンド
```bash
npm run arsl:check      # ARSL フルパイプライン実行
npm run arsl:install    # 配線を再適用
npm run arsl:fortress   # 17軸170点 採点
```

### 開発ルール
1. **全 LLM 入力は `arslSanitizeInput()` 経由で渡す**
2. **全 LLM 出力は `arslVerifyOutput()` 経由で返す**
3. **全アクション (DB/外部API) は `arslAudit()` を呼ぶ**
4. **CSP は middleware.ts で強制 (緩和禁止)**

詳細: `~/.soloptilink/ROADMAP_v2017_AI_RESILIENT_SECURITY.md`
EOF
    fi

    arsl_log "install" "DONE" "$project_dir"
    return 0
}

# プロジェクト完成時の最終ゲート (RVG の後に呼ぶ)
arsl_finalize_project() {
    local project_dir="$1"
    [[ "$ENABLE_ARSL" != "true" ]] && return 0
    [[ -z "$project_dir" || ! -d "$project_dir" ]] && {
        echo -e "${ARSL_BR_YEL}[ARSL]${ARSL_BR_NC} skip finalize: invalid project_dir=$project_dir"
        return 0
    }

    echo -e "\n${ARSL_BR_CYAN}${ARSL_BR_BOLD}━━ ARSL Final Gate ${ARSL_BRIDGE_VERSION} ━━${ARSL_BR_NC}"

    # 1. 自動 install
    arsl_install_to_project "$project_dir"
    echo -e "${ARSL_BR_GRN}[ARSL]${ARSL_BR_NC} project wired (middleware + lib/arsl + SBOM + CLAUDE.md)"

    # 2. SOAR (threat-detector → incident-responder)
    local td="${ARSL_DIR}/threat-detector.sh"
    local ir="${ARSL_DIR}/incident-responder.sh"
    [[ -f "$td" ]] && bash "$td" evaluate >/dev/null 2>&1 || true
    [[ -f "$ir" ]] && bash "$ir" run >/dev/null 2>&1 || true

    # 3. Forensic chain 更新
    local fl="${ARSL_DIR}/forensic-logger.sh"
    [[ -f "$fl" ]] && bash "$fl" collect 60 >/dev/null 2>&1 || true

    # 4. Security Fortress 採点
    local sf="${ARSL_DIR}/security-fortress.sh"
    if [[ -f "$sf" ]]; then
        local report
        report=$(bash "$sf" run "$project_dir" 2>&1)
        echo "$report" | tail -25
        local total
        total=$(echo "$report" | grep -oE 'TOTAL : [0-9]+' | head -1 | grep -oE '[0-9]+')
        if [[ -n "$total" && "$total" -lt "$ARSL_FORTRESS_THRESHOLD" ]]; then
            echo -e "${ARSL_BR_RED}${ARSL_BR_BOLD}[ARSL]${ARSL_BR_NC} Security Fortress ${total}/170 < ${ARSL_FORTRESS_THRESHOLD} (Gold) — 未完成宣言推奨"
            arsl_log "finalize" "FAIL" "score=$total"
            return 3
        fi
        arsl_log "finalize" "PASS" "score=${total:-?}"
    fi
    return 0
}

# 一行サマリ (chain.sh 起動メッセージ用)
arsl_banner() {
    [[ "$ENABLE_ARSL" != "true" ]] && return 0
    echo -e "${ARSL_BR_CYAN}[ARSL ${ARSL_BRIDGE_VERSION}]${ARSL_BR_NC} AI-Resilient Security Layer enabled (kill-switch=open, threshold=${ARSL_FORTRESS_THRESHOLD}/170)"
}

# CLI: 直接呼び出し用
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-help}" in
        assert)        arsl_assert_open ;;
        pre)           arsl_pre_inspect "$2" ;;
        post)          arsl_post_verify "$2" "${3:-cli}" ;;
        install)       arsl_install_to_project "$2" ;;
        finalize)      arsl_finalize_project "$2" ;;
        banner)        arsl_banner ;;
        *) cat <<U
SoloptiLinkAI ARSL Bridge ${ARSL_BRIDGE_VERSION}
Usage:
  $(basename "$0") assert                       # kill-switch 確認
  $(basename "$0") pre "<task text>"            # 入力検査
  $(basename "$0") post "<output text>" [src]   # 出力検査
  $(basename "$0") install <project_dir>        # 配線
  $(basename "$0") finalize <project_dir>       # 最終ゲート (install + 採点)
  $(basename "$0") banner                       # 起動メッセージ
U
            ;;
    esac
fi
