#!/usr/bin/env bash
# =============================================================================
# shield-bootstrap.sh — local-prompt-shield を chain.sh に統合する bootstrap
# =============================================================================
# chain.sh の main() からライセンス認証直後に呼ばれる。
# 役割:
#  1. CLI 引数 (./soloptilink "...") に API キーが含まれていれば即 redact
#     (LR3: プロセス引数 ps aux 漏洩 を構造的に解消)
#  2. shield が未配線なら first-run wizard を提案
#  3. shield proxy 未起動なら自動起動
#  4. shield audit を非ブロッキングで実行 (5 秒以内に異常検出)
#
# Exit code:
#  0  正常 (chain.sh は処理続行)
#  ※「機密検出+CLI引数 redact」は chain.sh を続行する設計
#  ※「shield 未配線」も警告のみで続行 (顧客の自由を尊重)

# 既存定義の保護
[[ -n "${_SHIELD_BOOTSTRAP_LOADED:-}" ]] && return 0
_SHIELD_BOOTSTRAP_LOADED=1

readonly _SHIELD_HOME="${HOME}/.soloptilink/lib/security/local-prompt-shield"
readonly _SHIELD_PROXY_PORT="${SHIELD_PROXY_PORT:-9444}"

# colors fallback (chain.sh 側で定義済みの想定だが安全側で)
: "${RED:=\033[0;31m}"
: "${YELLOW:=\033[0;33m}"
: "${GREEN:=\033[0;32m}"
: "${BLUE:=\033[0;34m}"
: "${CYAN:=\033[0;36m}"
: "${BOLD:=\033[1m}"
: "${NC:=\033[0m}"

# -----------------------------------------------------------------------------
# CLI 引数 pre-scrubber (LR3 解消)
# -----------------------------------------------------------------------------
# 渡された引数の中に API キーパターンが含まれていれば、
# OS Keychain に保存して handle に置換した版を返す。
# 元の "$@" は ps aux で見える時点で漏洩しているので、
# *せめて以降のフェーズには handle のみ渡す* + 顧客に警告。
#
# 使い方 (chain.sh 側):
#   sb_scrub_cli_args "$@"
#   set -- "${SHIELD_SCRUBBED_ARGS[@]}"

declare -ag SHIELD_SCRUBBED_ARGS=()
declare -g  SHIELD_REDACTION_COUNT=0

sb_scrub_cli_args() {
    SHIELD_SCRUBBED_ARGS=()
    SHIELD_REDACTION_COUNT=0

    if [[ ! -d "${_SHIELD_HOME}" ]]; then
        # shield 未配線 → 引数透過 (sb_first_run_check で警告)
        SHIELD_SCRUBBED_ARGS=("$@")
        return 0
    fi

    if ! command -v node &>/dev/null; then
        SHIELD_SCRUBBED_ARGS=("$@")
        return 0
    fi

    # node に各引数を JSON 配列として渡し、scrub 済み配列を JSON で受け取る
    local input_json
    input_json=$(printf '%s\n' "$@" | node -e '
const fs = require("node:fs");
const items = fs.readFileSync(0, "utf8").split("\n").filter(Boolean);
console.log(JSON.stringify(items));
')
    local out_json
    out_json=$(node -e "
const path = require('node:path');
const SHIELD = '${_SHIELD_HOME}/lib';
const { scrubPrompt } = require(path.join(SHIELD, 'pre-scrubber'));
const { LocalVault } = require(path.join(SHIELD, 'local-vault'));
const { HandleStore } = require(path.join(SHIELD, 'handle-store'));
const args = ${input_json};
let projectId;
try { projectId = require('node:crypto').createHash('sha256').update(process.cwd()).digest('hex').slice(0, 16); } catch { projectId = 'cli'; }
const vault = new LocalVault();
const store = new HandleStore({ projectId });
const out = [];
let red = 0;
for (const a of args) {
  const r = scrubPrompt(a, { projectId, vault, store });
  out.push(r.scrubbed);
  red += r.redactions;
}
console.log(JSON.stringify({ args: out, red }));
" 2>/dev/null) || { SHIELD_SCRUBBED_ARGS=("$@"); return 0; }

    # parse JSON output
    if ! command -v jq &>/dev/null; then
        SHIELD_SCRUBBED_ARGS=("$@")
        return 0
    fi
    SHIELD_REDACTION_COUNT=$(echo "${out_json}" | jq -r '.red // 0')
    if [[ "${SHIELD_REDACTION_COUNT}" -gt 0 ]]; then
        # 警告表示
        echo -e "${YELLOW}╔═══════════════════════════════════════════════════════════════╗${NC}" >&2
        echo -e "${YELLOW}║  ⚠ shield: CLI 引数に機密情報を ${SHIELD_REDACTION_COUNT} 件検出しました              ║${NC}" >&2
        echo -e "${YELLOW}║  → OS Keychain に安全保存し、ハンドル経由で処理します          ║${NC}" >&2
        echo -e "${YELLOW}║  注: ps aux で既に見えています。次回はプロンプト経由を推奨    ║${NC}" >&2
        echo -e "${YELLOW}║       ./soloptilink (引数なし) → 起動後にプロンプト入力        ║${NC}" >&2
        echo -e "${YELLOW}╚═══════════════════════════════════════════════════════════════╝${NC}" >&2
        # scrubbed args に置換
        readarray -t SHIELD_SCRUBBED_ARGS < <(echo "${out_json}" | jq -r '.args[]')
    else
        SHIELD_SCRUBBED_ARGS=("$@")
    fi
}

# -----------------------------------------------------------------------------
# Shield 配線状態チェック + first-run wizard 提案
# -----------------------------------------------------------------------------
sb_first_run_check() {
    if [[ ! -d "${_SHIELD_HOME}" ]]; then
        echo -e "${YELLOW}[shield] local-prompt-shield が未配線です${NC}" >&2
        echo -e "${YELLOW}        プロンプトに API キーを入れた場合 Anthropic 側ログに残るリスクあり${NC}" >&2
        echo -e "${YELLOW}        対処: ${BOLD}~/.soloptilink/lib/security/local-prompt-shield/shield.sh init${NC}" >&2
        return 0
    fi

    # Claude Code settings.json に hook が配線されているか
    local cc_settings="${HOME}/.claude/settings.json"
    local already_init_marker="${HOME}/.shield/.initialized"
    if [[ -f "${cc_settings}" ]] && ! grep -q "user-prompt-submit.js" "${cc_settings}" 2>/dev/null; then
        # 未配線 + first-run wizard 未表示なら、対話型 wizard で誘導 (TTY のみ)
        if [[ ! -f "${already_init_marker}" ]] && [[ -t 0 ]] && [[ -t 1 ]]; then
            echo -e "${YELLOW}╔══════════════════════════════════════════════════════════════╗${NC}" >&2
            echo -e "${YELLOW}║  🛡 SoloptiLinkAI Shield 初回セットアップ案内                ║${NC}" >&2
            echo -e "${YELLOW}╚══════════════════════════════════════════════════════════════╝${NC}" >&2
            echo "" >&2
            echo -e "${CYAN}Shield は API キー流出ゼロを構造的に保証する Layer です:${NC}" >&2
            echo -e "  • プロンプトに sk-... を入れても Anthropic に届く前に handle 化" >&2
            echo -e "  • OS Keychain で実値保管 (macOS Keychain / Win Cred Mgr / Linux libsecret)" >&2
            echo -e "  • 過去 transcript も自動 sanitize" >&2
            echo "" >&2
            echo -e "${BOLD}今すぐ初期化しますか? [Y/n]:${NC}" >&2
            local ans=""
            read -r -t 30 ans 2>/dev/null || ans=""
            if [[ -z "$ans" || "$ans" == "Y" || "$ans" == "y" || "$ans" == "yes" ]]; then
                bash "${_SHIELD_HOME}/shield.sh" init
                touch "${already_init_marker}"
            else
                echo -e "${YELLOW}スキップ。後で実行: ${BOLD}${_SHIELD_HOME}/shield.sh init${NC}" >&2
                # 連続表示を避けるため marker 作成 (24h 保持)
                touch "${already_init_marker}"
                # 24h 後に再表示するため期限切れ判定用
                {
                  echo "skipped_at=$(date +%s)"
                  echo "expires_in=86400"
                } > "${already_init_marker}"
            fi
        else
            echo -e "${YELLOW}[shield] hooks 未配線 (ワンタイム警告):${NC}" >&2
            echo -e "${YELLOW}        ${BOLD}${_SHIELD_HOME}/shield.sh init${NC}" >&2
        fi
    fi

    # 24h 経過した skip marker は再表示
    if [[ -f "${already_init_marker}" ]] && grep -q "skipped_at" "${already_init_marker}" 2>/dev/null; then
        local skipped_at expires_in now
        skipped_at=$(grep "skipped_at" "${already_init_marker}" | cut -d= -f2)
        expires_in=$(grep "expires_in" "${already_init_marker}" | cut -d= -f2)
        now=$(date +%s)
        if [[ -n "${skipped_at}" && -n "${expires_in}" ]] && (( now - skipped_at > expires_in )); then
            rm -f "${already_init_marker}"
        fi
    fi
    return 0
}

# -----------------------------------------------------------------------------
# Shield proxy 状態チェック + 自動起動
# -----------------------------------------------------------------------------
sb_ensure_proxy_running() {
    if [[ ! -d "${_SHIELD_HOME}" ]]; then
        return 0
    fi
    # healthz をチェック
    if curl -fs --max-time 1 "http://127.0.0.1:${_SHIELD_PROXY_PORT}/healthz" >/dev/null 2>&1; then
        return 0
    fi
    # 未起動 → 自動起動
    if [[ -f "${_SHIELD_HOME}/shield.sh" ]]; then
        bash "${_SHIELD_HOME}/shield.sh" proxy start >/dev/null 2>&1 || true
    fi
}

# -----------------------------------------------------------------------------
# 統合 entry point
# -----------------------------------------------------------------------------
sb_bootstrap() {
    # 1. CLI 引数 redact (呼出側で配列として再代入する設計)
    sb_scrub_cli_args "$@"

    # 2. shield 配線 + proxy
    sb_first_run_check
    sb_ensure_proxy_running

    return 0
}
