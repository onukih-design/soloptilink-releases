#!/usr/bin/env bash
# ╔═══════════════════════════════════════════════════════════╗
# ║  SoloptiLinkAI v2001.0 - Scope Guard                     ║
# ║  「勝手に機能追加しない」制御モジュール                   ║
# ║                                                           ║
# ║  修復時にユーザーが頼んだこと以外を変更しない             ║
# ║  - 修正範囲の特定と制限                                   ║
# ║  - 無関係なファイル変更の検出・警告                       ║
# ║  - 変更理由の強制記録                                     ║
# ╚═══════════════════════════════════════════════════════════╝

[[ -n "${_SCOPE_GUARD_LOADED:-}" ]] && return 0
_SCOPE_GUARD_LOADED=1

readonly SG2_VERSION="1.0.0"

# カラー
readonly SG2_RED='\033[0;31m' SG2_GREEN='\033[0;32m' SG2_YELLOW='\033[0;33m'
readonly SG2_CYAN='\033[0;36m' SG2_BOLD='\033[1m' SG2_NC='\033[0m'

# 状態
SG2_PROJECT_DIR=""
SG2_TASK_DESC=""
SG2_MODE=""
SG2_ALLOWED_FILES=()
SG2_CHANGED_FILES=()
SG2_VIOLATIONS=()

# ============================================================
# 初期化
# ============================================================
sg2_init() {
    local project_dir="$1"
    local task_desc="$2"
    local mode="${3:-error_fix}"

    SG2_PROJECT_DIR="$project_dir"
    SG2_TASK_DESC="$task_desc"
    SG2_MODE="$mode"
    SG2_ALLOWED_FILES=()
    SG2_CHANGED_FILES=()
    SG2_VIOLATIONS=()

    # タスクから修正対象ファイルを推定
    _sg_estimate_scope "$project_dir" "$task_desc"
}

# ============================================================
# スコープ推定
# ============================================================
_sg_estimate_scope() {
    local project_dir="$1"
    local task_desc="$2"

    # タスク内のファイル名/パスを抽出
    local mentioned_files
    mentioned_files=$(echo "$task_desc" | grep -oE '[a-zA-Z0-9_/.-]+\.(ts|tsx|js|jsx|py|sh|prisma|css|scss|json)' || true)

    for f in $mentioned_files; do
        if [[ -f "${project_dir}/${f}" ]]; then
            SG2_ALLOWED_FILES+=("$f")
        fi
    done

    # エラーメッセージ内のファイル参照を抽出
    local error_files
    error_files=$(echo "$task_desc" | grep -oE 'src/[a-zA-Z0-9_/.-]+|app/[a-zA-Z0-9_/.-]+|lib/[a-zA-Z0-9_/.-]+' || true)

    for f in $error_files; do
        if [[ -f "${project_dir}/${f}" ]]; then
            SG2_ALLOWED_FILES+=("$f")
        fi
    done
}

# ============================================================
# 変更検証
# ============================================================
# 修復後に変更されたファイルがスコープ内かチェック
sg2_verify_changes() {
    local project_dir="$1"

    if [[ ! -d "${project_dir}/.git" ]]; then
        return 0
    fi

    # 変更されたファイル一覧
    local changed
    changed=$(cd "$project_dir" && git diff --name-only 2>/dev/null)
    changed+=$'\n'$(cd "$project_dir" && git diff --staged --name-only 2>/dev/null)
    changed=$(echo "$changed" | sort -u | grep -v "^$")

    if [[ -z "$changed" ]]; then
        return 0
    fi

    local violation_count=0

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        SG2_CHANGED_FILES+=("$file")

        # 許可リストに入っていない & 関連ファイルでもない
        local is_allowed=false

        # 直接指定されたファイル
        for allowed in "${SG2_ALLOWED_FILES[@]}"; do
            if [[ "$file" == *"$allowed"* || "$allowed" == *"$file"* ]]; then
                is_allowed=true
                break
            fi
        done

        # 設定ファイル（package.json, tsconfig.json等）は許可
        case "$file" in
            package.json|package-lock.json|tsconfig.json|.env*|prisma/schema.prisma)
                is_allowed=true
                ;;
        esac

        # 許可リストが空（スコープ推定できなかった場合）は全許可
        if [[ ${#SG2_ALLOWED_FILES[@]} -eq 0 ]]; then
            is_allowed=true
        fi

        if [[ "$is_allowed" == "false" ]]; then
            SG2_VIOLATIONS+=("$file")
            violation_count=$((violation_count + 1))
        fi
    done <<< "$changed"

    if [[ $violation_count -gt 0 ]]; then
        echo -e "${SG2_YELLOW}⚠ Scope Guard: スコープ外の変更を${violation_count}件検出${SG2_NC}" >&2
        for v in "${SG2_VIOLATIONS[@]}"; do
            echo -e "  ${SG2_YELLOW}  - ${v}${SG2_NC}" >&2
        done
        echo -e "  ${SG2_YELLOW}  これらの変更が意図的か確認してください${SG2_NC}" >&2
    fi

    return 0
}

# ============================================================
# Claudeプロンプトへの制約注入
# ============================================================
sg2_inject_constraints() {
    local base_prompt="$1"

    local constraints="
## ⚠️ Scope Guard 制約（絶対遵守）

### 禁止事項
- ユーザーが指示していない新機能の追加
- 修正と無関係なリファクタリング
- 修正と無関係なファイルの変更
- 既存のUIデザイン変更（指示されていない場合）
- ライブラリの追加・更新（修正に必要な場合を除く）

### 必須事項
- 変更した全ファイルとその理由を報告
- 既存テストが通ることを確認
- 修正前に動いていた機能が修正後も動くことを確認

### 変更判断基準
変更してよい:
  ✓ ユーザーが指示した問題の直接修正
  ✓ 修正に伴い必然的に変更が必要な関連箇所
  ✓ 修正対象のファイル内のインポート/エクスポートの整合性

変更してはいけない:
  ✗ 「ついでに」のリファクタリング
  ✗ 「見つけた」別の問題の修正（報告はOK、修正はNG）
  ✗ コードスタイルの統一（指示されていない場合）
  ✗ コメントの追加・削除（指示されていない場合）
"
    echo "${constraints}

${base_prompt}"
}

# ============================================================
# レポート生成
# ============================================================
sg2_report() {
    echo "" >&2
    echo -e "${SG2_BOLD}Scope Guard レポート${SG2_NC}" >&2
    echo -e "  変更ファイル数: ${#SG2_CHANGED_FILES[@]}" >&2
    echo -e "  スコープ違反:   ${#SG2_VIOLATIONS[@]}" >&2
    if [[ ${#SG2_VIOLATIONS[@]} -eq 0 ]]; then
        echo -e "  ${SG2_GREEN}✓ 全変更がスコープ内${SG2_NC}" >&2
    fi
    echo "" >&2
}

# ============================================================
# Module Registry 登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register "scope-guard" "$SG2_VERSION" "スコープガード（勝手な機能追加を防止）"
    _mr_register "scope-guard" "$SG2_VERSION" "sg_init"
fi

# v2003.1: source時のexit codeを確実に0にする
true
