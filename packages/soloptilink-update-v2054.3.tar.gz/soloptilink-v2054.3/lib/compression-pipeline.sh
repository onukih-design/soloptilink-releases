#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v456.0 - Compression Pipeline Engine
# =============================================================================
# 圧縮パイプライン: gzip/brotli圧縮、アセット最適化。
#
# Functions:
#   _cp_init()             - Initialize
#   _cp_generate_gzip()    - Gzip compression middleware
#   _cp_generate_brotli()  - Brotli compression middleware
#   _cp_optimize_assets()  - Static asset optimization
#   _cp_report() / _cp_score()
# =============================================================================

[[ -n "${_CP_LOADED:-}" ]] && return 0; _CP_LOADED=1

declare -g CP_VERSION="456.0"
CP_GENERATED=0; CP_ERRORS=0; CP_FILES_WRITTEN=0
CP_GZIP_OK=false; CP_BROTLI_OK=false; CP_ASSETS_OK=false

_cp_init() {
    CP_GENERATED=0; CP_ERRORS=0; CP_FILES_WRITTEN=0
    CP_GZIP_OK=false; CP_BROTLI_OK=false; CP_ASSETS_OK=false
    return 0
}

_cp_log() { echo -e "  ${CYAN:-\033[0;36m}[compression]${NC:-\033[0m} $*" >&2; }
_cp_ok()  { echo -e "  ${GREEN:-\033[0;32m}✅ [compression]${NC:-\033[0m} $*" >&2; }
_cp_err() { echo -e "  ${RED:-\033[0;31m}❌ [compression]${NC:-\033[0m} $*" >&2; CP_ERRORS=$((CP_ERRORS + 1)); }

_cp_write_file() {
    local filepath="$1" content="$2"
    local dir; dir="$(dirname "$filepath")"
    [[ -d "$dir" ]] || mkdir -p "$dir"
    echo "$content" > "$filepath" 2>/dev/null || { _cp_err "Failed to write $filepath"; return 1; }
    CP_FILES_WRITTEN=$((CP_FILES_WRITTEN + 1))
    return 0
}

_cp_generate_gzip() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/compression/gzip-middleware.ts"
    _cp_log "Generating gzip compression middleware..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v456.0 - Gzip Compression Middleware
import { createGzip } from 'zlib';
import type { NextRequest } from 'next/server';

export interface GzipConfig {
  level: number;               // 1-9, default 6
  threshold: number;           // Min bytes to compress, default 1024
  mimeTypes: string[];
}

const DEFAULT_CONFIG: GzipConfig = {
  level: 6,
  threshold: 1024,
  mimeTypes: [
    'text/html', 'text/css', 'text/javascript', 'text/plain', 'text/xml',
    'application/json', 'application/javascript', 'application/xml',
    'application/x-javascript', 'image/svg+xml',
  ],
};

export function shouldCompress(contentType: string, contentLength: number, config: GzipConfig = DEFAULT_CONFIG): boolean {
  if (contentLength < config.threshold) return false;
  return config.mimeTypes.some(mime => contentType.startsWith(mime));
}

export function gzipCompressionMiddleware(config: Partial<GzipConfig> = {}) {
  const cfg = { ...DEFAULT_CONFIG, ...config };
  return {
    config: cfg,
    shouldCompress: (contentType: string, contentLength: number) => shouldCompress(contentType, contentLength, cfg),
    getHeaders: () => ({ 'Content-Encoding': 'gzip', 'Vary': 'Accept-Encoding' }),
  };
}

export function supportsGzip(req: NextRequest): boolean {
  const acceptEncoding = req.headers.get('accept-encoding') ?? '';
  return acceptEncoding.includes('gzip');
}

export { DEFAULT_CONFIG as GZIP_DEFAULT_CONFIG };
TYPESCRIPT
)
    _cp_write_file "$outfile" "$content" || return 1
    CP_GZIP_OK=true
    CP_GENERATED=$((CP_GENERATED + 1))
    _cp_ok "Gzip middleware generated"
    return 0
}

_cp_generate_brotli() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/compression/brotli-middleware.ts"
    _cp_log "Generating brotli compression middleware..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v456.0 - Brotli Compression Middleware
import type { NextRequest } from 'next/server';

export interface BrotliConfig {
  quality: number;             // 0-11, default 4
  threshold: number;           // Min bytes, default 1024
  lgWindow: number;            // Window size log, default 22
  mimeTypes: string[];
}

const DEFAULT_CONFIG: BrotliConfig = {
  quality: 4,
  threshold: 1024,
  lgWindow: 22,
  mimeTypes: [
    'text/html', 'text/css', 'text/javascript', 'text/plain', 'text/xml',
    'application/json', 'application/javascript', 'application/xml',
    'application/wasm', 'image/svg+xml', 'font/woff2',
  ],
};

export function supportsBrotli(req: NextRequest): boolean {
  const acceptEncoding = req.headers.get('accept-encoding') ?? '';
  return acceptEncoding.includes('br');
}

export function brotliCompressionMiddleware(config: Partial<BrotliConfig> = {}) {
  const cfg = { ...DEFAULT_CONFIG, ...config };
  return {
    config: cfg,
    shouldCompress: (contentType: string, contentLength: number) => {
      if (contentLength < cfg.threshold) return false;
      return cfg.mimeTypes.some(mime => contentType.startsWith(mime));
    },
    getHeaders: () => ({ 'Content-Encoding': 'br', 'Vary': 'Accept-Encoding' }),
    preferOverGzip: true,
  };
}

export { DEFAULT_CONFIG as BROTLI_DEFAULT_CONFIG };
TYPESCRIPT
)
    _cp_write_file "$outfile" "$content" || return 1
    CP_BROTLI_OK=true
    CP_GENERATED=$((CP_GENERATED + 1))
    _cp_ok "Brotli middleware generated"
    return 0
}

_cp_optimize_assets() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/compression/asset-optimizer.ts"
    _cp_log "Generating asset optimizer..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v456.0 - Static Asset Optimization

export interface AssetOptimizationConfig {
  images: { quality: number; formats: ('webp' | 'avif' | 'png' | 'jpg')[]; maxWidth: number; lazy: boolean };
  fonts: { preload: boolean; display: 'swap' | 'block' | 'fallback'; subset: boolean };
  scripts: { defer: boolean; async: boolean; modulePreload: boolean };
  styles: { critical: boolean; minify: boolean; purgeUnused: boolean };
}

const DEFAULT_CONFIG: AssetOptimizationConfig = {
  images: { quality: 80, formats: ['webp', 'avif'], maxWidth: 1920, lazy: true },
  fonts: { preload: true, display: 'swap', subset: true },
  scripts: { defer: true, async: false, modulePreload: true },
  styles: { critical: true, minify: true, purgeUnused: true },
};

export class AssetOptimizer {
  private config: AssetOptimizationConfig;
  constructor(config?: Partial<AssetOptimizationConfig>) { this.config = { ...DEFAULT_CONFIG, ...config } as AssetOptimizationConfig; }

  generateNextConfig(): Record<string, unknown> {
    return {
      images: { formats: this.config.images.formats, deviceSizes: [640, 750, 828, 1080, 1200, 1920], imageSizes: [16, 32, 48, 64, 96, 128, 256, 384], minimumCacheTTL: 60 },
      compress: true,
      poweredByHeader: false,
      headers: [
        { source: '/_next/static/(.*)', headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }] },
        { source: '/fonts/(.*)', headers: [{ key: 'Cache-Control', value: 'public, max-age=31536000, immutable' }] },
      ],
    };
  }

  generateImageComponent(): string {
    return `// Use next/image with optimized defaults\nimport Image from 'next/image';\nexport const OptimizedImage = ({ src, alt, ...props }) => <Image src={src} alt={alt} quality={${this.config.images.quality}} loading="${this.config.images.lazy ? 'lazy' : 'eager'}" {...props} />;`;
  }

  getConfig(): AssetOptimizationConfig { return this.config; }
}

export const assetOptimizer = new AssetOptimizer();
TYPESCRIPT
)
    _cp_write_file "$outfile" "$content" || return 1
    CP_ASSETS_OK=true
    CP_GENERATED=$((CP_GENERATED + 1))
    _cp_ok "Asset optimizer generated"
    return 0
}

_cp_generate_all() {
    local project_dir="${1:-.}"
    _cp_log "Generating full compression pipeline..."
    _cp_generate_gzip "$project_dir"
    _cp_generate_brotli "$project_dir"
    _cp_optimize_assets "$project_dir"
    _cp_ok "Compression pipeline complete: ${CP_GENERATED} components, ${CP_ERRORS} errors"
}

_cp_report() {
    echo -e "\n  ${BOLD:-\033[1m}═══ Compression Pipeline v${CP_VERSION} ═══${NC:-\033[0m}"
    echo -e "  Generated  : ${CP_GENERATED}"
    echo -e "  Errors     : ${CP_ERRORS}"
    echo -e "  Gzip       : ${CP_GZIP_OK}"
    echo -e "  Brotli     : ${CP_BROTLI_OK}"
    echo -e "  Assets     : ${CP_ASSETS_OK}"
}

_cp_score() {
    local score=50
    ${CP_GZIP_OK} && score=$((score + 15))
    ${CP_BROTLI_OK} && score=$((score + 15))
    ${CP_ASSETS_OK} && score=$((score + 15))
    [[ ${CP_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "compression-pipeline" --version "456.0" \
        --description "圧縮パイプライン: gzip×brotli×アセット最適化" \
        --init "_cp_init" --report "_cp_report" --score "_cp_score" \
        --enable-var "ENABLE_COMPRESSION" --cli-flags "--compression:--no-compression"
fi

# v2003.1: source時のexit codeを確実に0にする
true
