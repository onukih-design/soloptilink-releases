#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v349.0 - Test Priority Optimizer
# =============================================================================
# テスト優先度最適化: 変更ファイル分析→影響範囲特定→テスト優先順位決定。
# 変更に最も関連するテストを先に実行し、フィードバックループを高速化。
#
# Functions:
#   _tpo_init()               - Initialize
#   _tpo_analyze_changes()    - Analyze git changes for impact
#   _tpo_prioritize_tests()   - Prioritize tests by relevance
#   _tpo_generate_test_plan() - Generate optimized test execution plan
#   _tpo_report() / _tpo_score()
# =============================================================================

[[ -n "${_TPO_LOADED:-}" ]] && return 0; _TPO_LOADED=1

readonly _TPO_RED='\033[0;31m'
readonly _TPO_GREEN='\033[0;32m'
readonly _TPO_YELLOW='\033[0;33m'
readonly _TPO_CYAN='\033[0;36m'
readonly _TPO_NC='\033[0m'

declare -g TPO_VERSION="349.0"
TPO_GENERATED=0; TPO_ERRORS=0; TPO_FILES_WRITTEN=0
TPO_ANALYZE_OK=false; TPO_PRIORITIZE_OK=false; TPO_PLAN_OK=false
TPO_CHANGED_FILES=0; TPO_AFFECTED_TESTS=0; TPO_TOTAL_TESTS=0

_tpo_init() {
    TPO_GENERATED=0; TPO_ERRORS=0; TPO_FILES_WRITTEN=0
    TPO_ANALYZE_OK=false; TPO_PRIORITIZE_OK=false; TPO_PLAN_OK=false
    TPO_CHANGED_FILES=0; TPO_AFFECTED_TESTS=0; TPO_TOTAL_TESTS=0
    echo -e "  ${_TPO_GREEN}OK${_TPO_NC} Test Priority Optimizer v${TPO_VERSION}" >&2
    return 0
}

_tpo_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { TPO_FILES_WRITTEN=$((TPO_FILES_WRITTEN + 1)); return 0; }
    TPO_ERRORS=$((TPO_ERRORS + 1)); return 1
}

_tpo_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_TPO_CYAN}[priority]${_TPO_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_TPO_GREEN}[priority]${_TPO_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_TPO_YELLOW}[priority]${_TPO_NC} $msg" >&2 ;;
        error) echo -e "  ${_TPO_RED}[priority]${_TPO_NC} $msg" >&2 ;;
    esac
}

_tpo_analyze_changes() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _tpo_log info "Analyzing file changes for test impact..."

    # Get changed files (from git or provided list)
    local changed_files=""
    if command -v git &>/dev/null && [[ -d "${project_dir}/.git" ]]; then
        changed_files=$(cd "$project_dir" && git diff --name-only HEAD~1 2>/dev/null || \
                       git diff --name-only --cached 2>/dev/null || \
                       git status --porcelain | awk '{print $2}')
    fi

    if [[ -z "$changed_files" ]]; then
        # Fallback: analyze recently modified files
        changed_files=$(find "$project_dir/src" -name "*.ts" -newer "$project_dir/package.json" \
            -not -path "*/node_modules/*" 2>/dev/null | head -20)
    fi

    TPO_CHANGED_FILES=$(echo "$changed_files" | grep -c . 2>/dev/null || echo 0)
    _tpo_log info "Changed files: ${TPO_CHANGED_FILES}"

    # Categorize changes
    local api_changes=0 ui_changes=0 lib_changes=0 db_changes=0
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        case "$file" in
            *api*|*route*) api_changes=$((api_changes + 1)) ;;
            *component*|*page*|*.tsx) ui_changes=$((ui_changes + 1)) ;;
            *lib*|*util*|*helper*) lib_changes=$((lib_changes + 1)) ;;
            *prisma*|*migration*|*schema*) db_changes=$((db_changes + 1)) ;;
        esac
    done <<< "$changed_files"

    _tpo_log info "Impact: API=${api_changes} UI=${ui_changes} Lib=${lib_changes} DB=${db_changes}"

    TPO_ANALYZE_OK=true
    TPO_GENERATED=$((TPO_GENERATED + 1))
    return 0
}

_tpo_prioritize_tests() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _tpo_log info "Prioritizing tests by relevance..."

    # Find all test files
    local test_files
    test_files=$(find "$project_dir" -name "*.test.ts" -o -name "*.spec.ts" \
        -not -path "*/node_modules/*" 2>/dev/null)
    TPO_TOTAL_TESTS=$(echo "$test_files" | grep -c . 2>/dev/null || echo 0)

    # Map test files to their source dependencies
    local priority_high=() priority_medium=() priority_low=()

    while IFS= read -r test_file; do
        [[ -z "$test_file" ]] && continue
        local basename
        basename=$(basename "$test_file" | sed 's/\.test\.\|\.spec\././;s/\.ts$//')

        # Check if corresponding source file was changed
        local source_file="${test_file//__tests__\//}"
        source_file="${source_file//.test./.}"
        source_file="${source_file//.spec./.}"

        if [[ -f "$source_file" ]]; then
            local mtime_test mtime_source
            mtime_test=$(stat -f %m "$test_file" 2>/dev/null || stat -c %Y "$test_file" 2>/dev/null || echo 0)
            mtime_source=$(stat -f %m "$source_file" 2>/dev/null || stat -c %Y "$source_file" 2>/dev/null || echo 0)

            if [[ $mtime_source -gt $mtime_test ]]; then
                priority_high+=("$test_file")
                continue
            fi
        fi

        # Integration/e2e tests are medium priority
        if echo "$test_file" | grep -q "integration\|e2e\|contract"; then
            priority_medium+=("$test_file")
        else
            priority_low+=("$test_file")
        fi
    done <<< "$test_files"

    TPO_AFFECTED_TESTS=${#priority_high[@]}
    _tpo_log ok "Priority: HIGH=${#priority_high[@]} MEDIUM=${#priority_medium[@]} LOW=${#priority_low[@]}"

    TPO_PRIORITIZE_OK=true
    TPO_GENERATED=$((TPO_GENERATED + 1))
    return 0
}

_tpo_generate_test_plan() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _tpo_log info "Generating optimized test plan..."

    _tpo_write_file "${project_dir}/test-plan.json" "{
  \"strategy\": \"impact-based\",
  \"changed_files\": ${TPO_CHANGED_FILES},
  \"total_tests\": ${TPO_TOTAL_TESTS},
  \"affected_tests\": ${TPO_AFFECTED_TESTS},
  \"execution_order\": [
    {\"phase\": 1, \"name\": \"smoke\", \"description\": \"Quick sanity (health, build)\", \"timeout\": \"30s\"},
    {\"phase\": 2, \"name\": \"affected-unit\", \"description\": \"Tests for changed modules\", \"timeout\": \"2m\"},
    {\"phase\": 3, \"name\": \"integration\", \"description\": \"API integration tests\", \"timeout\": \"5m\"},
    {\"phase\": 4, \"name\": \"remaining-unit\", \"description\": \"All other unit tests\", \"timeout\": \"5m\"},
    {\"phase\": 5, \"name\": \"e2e\", \"description\": \"End-to-end flows\", \"timeout\": \"10m\"}
  ],
  \"estimated_time\": \"~22 minutes\",
  \"skip_candidates\": [],
  \"generated_at\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"
}"

    _tpo_log ok "Test plan generated (${TPO_TOTAL_TESTS} tests, ${TPO_AFFECTED_TESTS} high-priority)"
    TPO_PLAN_OK=true
    TPO_GENERATED=$((TPO_GENERATED + 1))
    return 0
}

_tpo_report() {
    echo -e "\n  ${_TPO_CYAN}=== Test Priority Optimizer v${TPO_VERSION} ===${_TPO_NC}"
    echo -e "  Generated: ${TPO_GENERATED} | Files: ${TPO_FILES_WRITTEN} | Errors: ${TPO_ERRORS}"
    echo -e "  Changed: ${TPO_CHANGED_FILES} | Tests: ${TPO_TOTAL_TESTS} | Affected: ${TPO_AFFECTED_TESTS}"
    echo -e "  Analysis: $( ${TPO_ANALYZE_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Priority: $( ${TPO_PRIORITIZE_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Plan: $( ${TPO_PLAN_OK} && echo 'OK' || echo 'SKIP')"
}

_tpo_score() {
    local score=50
    ${TPO_ANALYZE_OK} && score=$((score + 15))
    ${TPO_PRIORITIZE_OK} && score=$((score + 15))
    ${TPO_PLAN_OK} && score=$((score + 15))
    [[ ${TPO_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "test-priority-optimizer" --version "349.0" \
        --description "テスト優先度最適化 変更影響分析/実行順序最適化 (v349)" \
        --init "_tpo_init" --report "_tpo_report" --score "_tpo_score" \
        --enable-var "ENABLE_TEST_PRIORITY" --cli-flags "--test-priority:--no-test-priority"
fi

# v2003.1: source時のexit codeを確実に0にする
true
