#!/usr/bin/env bash
# ============================================================
# SoloptiLink Chain v13.0 - Dev Server Module
# ============================================================
# Starts development servers for generated projects and verifies
# that they respond correctly over HTTP. Handles port detection,
# readiness polling, health checks, route discovery, and clean
# shutdown.
#
# v13.0 Features:
#   - Auto-detect start command (npm dev, flask run, cargo run, etc.)
#   - Configurable port with auto-detection from package.json / config
#   - Readiness polling with exponential back-off
#   - HTTP health check with status code & body validation
#   - Route capture from framework output or sitemap
#   - Structured JSON report of server status & routes
#   - Clean shutdown with SIGTERM → SIGKILL escalation
#   - Process group management (kills child processes too)
#
# Usage: source lib/dev-server.sh
# ============================================================

# sourceされるライブラリなので set -euo pipefail は設定しない

# --- Load guard --------------------------------------------------------------
[[ -n "${_DS_LOADED:-}" ]] && return 0
_DS_LOADED=1

# --- Colour constants (DS_ prefix) ------------------------------------------
DS_GREEN='\033[0;32m'   DS_YELLOW='\033[0;33m'  DS_RED='\033[0;31m'
DS_CYAN='\033[0;36m'    DS_PURPLE='\033[0;35m'  DS_BOLD='\033[1m'
DS_DIM='\033[2m'        DS_NC='\033[0m'

# --- Global state (DS_ prefix) ----------------------------------------------
DS_PROJECT_DIR=""
DS_LOG_DIR=""
DS_LOG_FILE=""
DS_SERVER_PID=""           # PID of the background dev server process
DS_SERVER_PGID=""          # Process group ID for cleanup
DS_PORT=""                 # Port the server is running on
DS_BASE_URL=""             # e.g. http://localhost:3000
DS_START_CMD=""            # The command used to start the server
DS_STACK=""                # Detected stack type
DS_SERVER_STDOUT=""        # Path to server stdout capture file
DS_SERVER_STDERR=""        # Path to server stderr capture file

# Health check state
DS_IS_READY=false
DS_STATUS_CODE=""
DS_RESPONSE_BODY=""

# Route capture
DS_ROUTES_FOUND=0
DS_ROUTES_JSON="[]"

# Timing
DS_START_TIME=""
DS_READY_TIME=""
DS_STARTUP_DURATION=""

# Default configuration
DS_DEFAULT_PORT="${DS_DEFAULT_PORT:-3000}"
DS_READY_TIMEOUT="${DS_READY_TIMEOUT:-60}"     # seconds to wait for server ready
DS_HEALTH_TIMEOUT="${DS_HEALTH_TIMEOUT:-10}"   # seconds per health check request
DS_SHUTDOWN_TIMEOUT="${DS_SHUTDOWN_TIMEOUT:-10}" # seconds before SIGKILL

# ============================================================
# Helper: _ds_log(level, message)
# Prints a coloured log line and optionally appends to the log file.
# Levels: INFO, SUCCESS, WARN, ERROR, STEP, SECTION
# ============================================================
_ds_log() {
    local level="$1" message="$2" color="${DS_NC}"
    case "$level" in
        INFO|SUCCESS) color="${DS_GREEN}"  ;;
        WARN)         color="${DS_YELLOW}" ;;
        ERROR|FAIL)   color="${DS_RED}"    ;;
        STEP)         color="${DS_CYAN}"   ;;
        SECTION)      color="${DS_PURPLE}" ;;
    esac
    echo -e "  ${color}[DEV-SERVER:${level}]${DS_NC} ${message}"
    if [[ -n "$DS_LOG_FILE" ]]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [${level}] ${message}" >> "$DS_LOG_FILE" 2>/dev/null || true
    fi
}

# ============================================================
# Helper: _ds_is_port_in_use(port)
# Returns 0 if the given port is already in use.
# ============================================================
_ds_is_port_in_use() {
    local port="$1"
    if command -v lsof &>/dev/null; then
        lsof -iTCP:"$port" -sTCP:LISTEN &>/dev/null && return 0
    elif command -v ss &>/dev/null; then
        ss -tlnp 2>/dev/null | grep -q ":${port} " && return 0
    elif command -v nc &>/dev/null; then
        nc -z localhost "$port" 2>/dev/null && return 0
    fi
    return 1
}

# ============================================================
# Helper: _ds_find_free_port(start_port)
# Finds a free port starting from start_port, checking up to 20
# ports sequentially. Echoes the free port number.
# ============================================================
_ds_find_free_port() {
    local port="${1:-3000}"
    local max_attempts=20 i=0
    while (( i < max_attempts )); do
        if ! _ds_is_port_in_use "$port"; then
            echo "$port"
            return 0
        fi
        (( port++ ))
        (( i++ ))
    done
    _ds_log "WARN" "空きポートが見つかりません (${1}-${port})"
    echo "$1"
    return 1
}

# ============================================================
# Helper: _ds_extract_port_from_config(project_dir)
# Try to determine the dev server port from project config files.
# Echoes the port number or empty string if not found.
# ============================================================
_ds_extract_port_from_config() {
    local dir="$1"

    # package.json: look for PORT in scripts or config
    if [[ -f "${dir}/package.json" ]]; then
        # Check for "dev": "... --port XXXX" or "PORT=XXXX"
        local dev_script
        dev_script=$(grep -oP '"dev"\s*:\s*"[^"]*"' "${dir}/package.json" 2>/dev/null || true)
        if [[ -n "$dev_script" ]]; then
            local port_match
            port_match=$(echo "$dev_script" | grep -oP '(?:--port\s+|PORT=)(\d+)' | grep -oP '\d+' | head -1)
            if [[ -n "$port_match" ]]; then
                echo "$port_match"
                return 0
            fi
        fi
        # Next.js default: 3000, Vite default: 5173
        if grep -q '"next"' "${dir}/package.json" 2>/dev/null; then
            echo "3000"; return 0
        fi
        if grep -q '"vite"' "${dir}/package.json" 2>/dev/null; then
            echo "5173"; return 0
        fi
    fi

    # .env file: PORT=XXXX
    if [[ -f "${dir}/.env" ]]; then
        local env_port
        env_port=$(grep -oP '^PORT=(\d+)' "${dir}/.env" 2>/dev/null | grep -oP '\d+' | head -1)
        if [[ -n "$env_port" ]]; then
            echo "$env_port"; return 0
        fi
    fi

    # Python Flask default: 5000, FastAPI default: 8000
    if [[ -f "${dir}/requirements.txt" || -f "${dir}/pyproject.toml" ]]; then
        if grep -qiE 'fastapi|uvicorn' "${dir}/requirements.txt" 2>/dev/null || \
           grep -qiE 'fastapi|uvicorn' "${dir}/pyproject.toml" 2>/dev/null; then
            echo "8000"; return 0
        fi
        if grep -qi 'flask' "${dir}/requirements.txt" 2>/dev/null || \
           grep -qi 'flask' "${dir}/pyproject.toml" 2>/dev/null; then
            echo "5000"; return 0
        fi
    fi

    # Go: common default 8080
    if [[ -f "${dir}/go.mod" ]]; then
        echo "8080"; return 0
    fi

    echo ""
    return 1
}

# ============================================================
# ds_init(project_dir)
# Initialise the dev server module for a given project directory.
# Creates log directories, resets state, and detects the stack.
# ============================================================
ds_init() {
    local project_dir="${1:?ds_init: project_dir required}"
    DS_PROJECT_DIR="$(cd "$project_dir" 2>/dev/null && pwd)" || {
        _ds_log "ERROR" "ディレクトリが見つかりません: $project_dir"
        return 1
    }
    DS_LOG_DIR="${DS_PROJECT_DIR}/docs/chain-logs"
    DS_LOG_FILE="${DS_LOG_DIR}/dev-server_$(date +%Y%m%d_%H%M%S).log"
    mkdir -p "$DS_LOG_DIR" 2>/dev/null || true

    # Reset state
    DS_SERVER_PID=""
    DS_SERVER_PGID=""
    DS_PORT=""
    DS_BASE_URL=""
    DS_START_CMD=""
    DS_STACK=""
    DS_IS_READY=false
    DS_STATUS_CODE=""
    DS_RESPONSE_BODY=""
    DS_ROUTES_FOUND=0
    DS_ROUTES_JSON="[]"
    DS_START_TIME=""
    DS_READY_TIME=""
    DS_STARTUP_DURATION=""

    # Detect stack
    if [[ -f "${DS_PROJECT_DIR}/package.json" ]]; then
        DS_STACK="node"
        [[ -f "${DS_PROJECT_DIR}/tsconfig.json" ]] && DS_STACK="typescript"
    elif [[ -f "${DS_PROJECT_DIR}/requirements.txt" || -f "${DS_PROJECT_DIR}/pyproject.toml" || -f "${DS_PROJECT_DIR}/Pipfile" ]]; then
        DS_STACK="python"
    elif [[ -f "${DS_PROJECT_DIR}/Cargo.toml" ]]; then
        DS_STACK="rust"
    elif [[ -f "${DS_PROJECT_DIR}/go.mod" ]]; then
        DS_STACK="go"
    elif ls "${DS_PROJECT_DIR}"/*.html &>/dev/null 2>&1; then
        DS_STACK="static"
    else
        DS_STACK="unknown"
    fi

    # Create stdout/stderr capture files
    DS_SERVER_STDOUT="${DS_LOG_DIR}/dev-server-stdout_$$.log"
    DS_SERVER_STDERR="${DS_LOG_DIR}/dev-server-stderr_$$.log"

    _ds_log "INFO" "Dev Server モジュール初期化: ${DS_PROJECT_DIR}"
    _ds_log "INFO" "検出スタック: ${DS_BOLD}${DS_STACK}${DS_NC}"
    return 0
}

# ============================================================
# ds_detect_start_command(project_dir)
# Auto-detect the appropriate dev server start command based on
# the project's stack and configuration files.
# Sets DS_START_CMD and echoes the detected command.
# ============================================================
ds_detect_start_command() {
    local dir="${1:-$DS_PROJECT_DIR}"
    DS_START_CMD=""

    case "$DS_STACK" in
        node|typescript)
            if [[ -f "${dir}/package.json" ]]; then
                # Priority: dev > start > next dev
                if grep -q '"dev"' "${dir}/package.json" 2>/dev/null; then
                    if [[ -f "${dir}/pnpm-lock.yaml" ]] && command -v pnpm &>/dev/null; then
                        DS_START_CMD="pnpm run dev"
                    elif [[ -f "${dir}/yarn.lock" ]] && command -v yarn &>/dev/null; then
                        DS_START_CMD="yarn dev"
                    else
                        DS_START_CMD="npm run dev"
                    fi
                elif grep -q '"start"' "${dir}/package.json" 2>/dev/null; then
                    if [[ -f "${dir}/pnpm-lock.yaml" ]] && command -v pnpm &>/dev/null; then
                        DS_START_CMD="pnpm start"
                    elif [[ -f "${dir}/yarn.lock" ]] && command -v yarn &>/dev/null; then
                        DS_START_CMD="yarn start"
                    else
                        DS_START_CMD="npm start"
                    fi
                else
                    # Fallback: look for common entry files
                    if [[ -f "${dir}/server.js" ]]; then
                        DS_START_CMD="node server.js"
                    elif [[ -f "${dir}/index.js" ]]; then
                        DS_START_CMD="node index.js"
                    elif [[ -f "${dir}/src/index.js" ]]; then
                        DS_START_CMD="node src/index.js"
                    elif [[ -f "${dir}/app.js" ]]; then
                        DS_START_CMD="node app.js"
                    else
                        _ds_log "WARN" "Node起動コマンドを検出できません"
                    fi
                fi
            fi
            ;;
        python)
            # FastAPI / Uvicorn
            if [[ -f "${dir}/main.py" ]] && grep -qi 'fastapi\|uvicorn' "${dir}/requirements.txt" 2>/dev/null; then
                DS_START_CMD="uvicorn main:app --host 0.0.0.0 --port \${PORT:-8000} --reload"
            elif [[ -f "${dir}/app/main.py" ]]; then
                DS_START_CMD="uvicorn app.main:app --host 0.0.0.0 --port \${PORT:-8000} --reload"
            # Flask
            elif [[ -f "${dir}/app.py" ]]; then
                DS_START_CMD="flask --app app run --host 0.0.0.0 --port \${PORT:-5000} --reload"
            elif [[ -f "${dir}/wsgi.py" ]]; then
                DS_START_CMD="flask --app wsgi run --host 0.0.0.0 --port \${PORT:-5000} --reload"
            # Django
            elif [[ -f "${dir}/manage.py" ]]; then
                DS_START_CMD="python manage.py runserver 0.0.0.0:\${PORT:-8000}"
            # Generic Python script
            elif [[ -f "${dir}/main.py" ]]; then
                DS_START_CMD="python main.py"
            else
                _ds_log "WARN" "Python起動コマンドを検出できません"
            fi
            ;;
        rust)
            DS_START_CMD="cargo run"
            ;;
        go)
            DS_START_CMD="go run ."
            ;;
        static)
            # Use npx serve or python http.server as fallback
            if command -v npx &>/dev/null; then
                DS_START_CMD="npx serve -s . -l \${PORT:-3000}"
            elif command -v python3 &>/dev/null; then
                DS_START_CMD="python3 -m http.server \${PORT:-8000}"
            elif command -v python &>/dev/null; then
                DS_START_CMD="python -m http.server \${PORT:-8000}"
            else
                _ds_log "WARN" "静的サーバーツール未検出"
            fi
            ;;
        *)
            _ds_log "WARN" "不明なスタック: 起動コマンドを検出できません"
            ;;
    esac

    if [[ -n "$DS_START_CMD" ]]; then
        _ds_log "INFO" "検出された起動コマンド: ${DS_BOLD}${DS_START_CMD}${DS_NC}"
    else
        _ds_log "ERROR" "起動コマンドが見つかりません"
        return 1
    fi
    echo "$DS_START_CMD"
    return 0
}

# ============================================================
# ds_start(project_dir, port)
# Start the dev server in the background. Determines port
# automatically if not specified. The server process is started
# in its own process group for clean shutdown.
# ============================================================
ds_start() {
    local dir="${1:-$DS_PROJECT_DIR}"
    local port="${2:-}"

    # Ensure we have a start command
    if [[ -z "$DS_START_CMD" ]]; then
        ds_detect_start_command "$dir" || return 1
    fi

    # Stop any existing server first
    if [[ -n "$DS_SERVER_PID" ]]; then
        _ds_log "WARN" "既存サーバープロセスを停止します (PID=${DS_SERVER_PID})"
        ds_stop
    fi

    # Determine port
    if [[ -z "$port" ]]; then
        port=$(_ds_extract_port_from_config "$dir")
        [[ -z "$port" ]] && port="$DS_DEFAULT_PORT"
    fi

    # Find a free port if the desired one is occupied
    if _ds_is_port_in_use "$port"; then
        _ds_log "WARN" "ポート ${port} は使用中です。空きポートを検索..."
        port=$(_ds_find_free_port "$port")
    fi

    DS_PORT="$port"
    DS_BASE_URL="http://localhost:${DS_PORT}"

    _ds_log "STEP" "Dev Server 起動: ポート ${DS_PORT}"
    _ds_log "INFO" "コマンド: ${DS_START_CMD}"
    _ds_log "INFO" "URL: ${DS_BASE_URL}"

    # Record start time
    DS_START_TIME=$(date +%s)

    # Start the server in background with PORT env var set
    # Use setsid (Linux) or create a subshell process group (macOS)
    (
        cd "$dir" 2>/dev/null || exit 1
        export PORT="$DS_PORT"
        eval "$DS_START_CMD" > "$DS_SERVER_STDOUT" 2> "$DS_SERVER_STDERR" &
        echo $!
    ) &
    local launcher_pid=$!

    # Wait briefly for the server PID to appear
    sleep 1

    # The actual server is the last background process in the subshell
    # We read stdout to get the PID from the echo
    if [[ -f "$DS_SERVER_STDOUT" ]]; then
        # The server is running in background. Get PID from the process list.
        DS_SERVER_PID=""
        # Find process listening on the target port (give it a moment)
        local attempts=0
        while (( attempts < 5 )); do
            sleep 1
            local pid_on_port
            pid_on_port=$(lsof -iTCP:"$DS_PORT" -sTCP:LISTEN -t 2>/dev/null | head -1)
            if [[ -n "$pid_on_port" ]]; then
                DS_SERVER_PID="$pid_on_port"
                break
            fi
            (( attempts++ ))
        done

        # Fallback: get from ps if lsof didn't work
        if [[ -z "$DS_SERVER_PID" ]]; then
            DS_SERVER_PID=$(pgrep -f "$DS_START_CMD" 2>/dev/null | head -1)
        fi
    fi

    if [[ -n "$DS_SERVER_PID" ]]; then
        # Try to get process group ID
        DS_SERVER_PGID=$(ps -o pgid= -p "$DS_SERVER_PID" 2>/dev/null | tr -d ' ')
        _ds_log "SUCCESS" "サーバー起動 PID=${DS_SERVER_PID} PGID=${DS_SERVER_PGID:-unknown}"
        return 0
    else
        _ds_log "ERROR" "サーバー起動失敗 - PIDを取得できません"
        # Show stderr for diagnostics
        if [[ -f "$DS_SERVER_STDERR" ]] && [[ -s "$DS_SERVER_STDERR" ]]; then
            _ds_log "ERROR" "stderr: $(head -5 "$DS_SERVER_STDERR")"
        fi
        return 1
    fi
}

# ============================================================
# ds_wait_ready(url, timeout_sec)
# Poll the given URL until it returns an HTTP response or the
# timeout expires. Uses exponential back-off starting at 0.5s.
# Sets DS_IS_READY=true on success.
# ============================================================
ds_wait_ready() {
    local url="${1:-$DS_BASE_URL}"
    local timeout_sec="${2:-$DS_READY_TIMEOUT}"

    _ds_log "STEP" "サーバー起動待機中: ${url} (最大 ${timeout_sec}秒)"

    local elapsed=0
    local interval=0.5  # start with 500ms
    local max_interval=3

    DS_IS_READY=false

    while (( elapsed < timeout_sec )); do
        # Try to connect
        local http_code
        http_code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 3 "$url" 2>/dev/null || echo "000")

        if [[ "$http_code" != "000" ]]; then
            DS_IS_READY=true
            DS_STATUS_CODE="$http_code"
            DS_READY_TIME=$(date +%s)
            DS_STARTUP_DURATION=$(( DS_READY_TIME - DS_START_TIME ))
            _ds_log "SUCCESS" "サーバー応答確認: HTTP ${http_code} (起動時間: ${DS_STARTUP_DURATION}秒)"
            return 0
        fi

        # Check if server process is still alive
        if [[ -n "$DS_SERVER_PID" ]] && ! kill -0 "$DS_SERVER_PID" 2>/dev/null; then
            _ds_log "ERROR" "サーバープロセスが終了しています (PID=${DS_SERVER_PID})"
            if [[ -f "$DS_SERVER_STDERR" ]] && [[ -s "$DS_SERVER_STDERR" ]]; then
                _ds_log "ERROR" "stderr: $(tail -10 "$DS_SERVER_STDERR" 2>/dev/null)"
            fi
            return 1
        fi

        sleep "$interval"
        elapsed=$(( elapsed + ${interval%.*} + 1 ))  # approximate for fractional sleep

        # Exponential back-off up to max_interval
        local new_interval
        new_interval=$(awk "BEGIN {v=$interval*1.5; if(v>$max_interval) v=$max_interval; print v}")
        interval="$new_interval"
    done

    _ds_log "ERROR" "サーバー起動タイムアウト (${timeout_sec}秒)"
    if [[ -f "$DS_SERVER_STDERR" ]] && [[ -s "$DS_SERVER_STDERR" ]]; then
        _ds_log "ERROR" "stderr (最後の10行):"
        tail -10 "$DS_SERVER_STDERR" 2>/dev/null | while IFS= read -r line; do
            _ds_log "ERROR" "  ${line}"
        done
    fi
    return 1
}

# ============================================================
# ds_health_check(url)
# Perform an HTTP health check against the given URL.
# Verifies status code (2xx/3xx = healthy), captures response body,
# and checks for common error indicators.
# Returns 0 if healthy, 1 otherwise.
# ============================================================
ds_health_check() {
    local url="${1:-$DS_BASE_URL}"
    _ds_log "STEP" "ヘルスチェック: ${url}"

    local response_file
    response_file="${DS_LOG_DIR}/health-check-response_$$.tmp"

    # Capture status code and body
    DS_STATUS_CODE=$(curl -s -o "$response_file" -w '%{http_code}' --max-time "$DS_HEALTH_TIMEOUT" "$url" 2>/dev/null || echo "000")
    DS_RESPONSE_BODY=""
    [[ -f "$response_file" ]] && DS_RESPONSE_BODY=$(head -c 5000 "$response_file" 2>/dev/null)
    rm -f "$response_file" 2>/dev/null

    if [[ "$DS_STATUS_CODE" == "000" ]]; then
        _ds_log "FAIL" "ヘルスチェック失敗: 接続不可"
        return 1
    fi

    # Check status code
    local code_prefix="${DS_STATUS_CODE:0:1}"
    if [[ "$code_prefix" == "2" || "$code_prefix" == "3" ]]; then
        _ds_log "SUCCESS" "ヘルスチェック成功: HTTP ${DS_STATUS_CODE}"

        # Check for common error pages in the response body
        if echo "$DS_RESPONSE_BODY" | grep -qiE 'internal server error|500 error|503 service unavailable|application error'; then
            _ds_log "WARN" "HTTP ${DS_STATUS_CODE} だがレスポンスボディにエラー文言あり"
            return 1
        fi
        return 0
    elif [[ "$code_prefix" == "4" ]]; then
        _ds_log "WARN" "ヘルスチェック: HTTP ${DS_STATUS_CODE} (クライアントエラー)"
        # 404 on root is likely a routing issue but server is running
        if [[ "$DS_STATUS_CODE" == "404" ]]; then
            _ds_log "INFO" "サーバーは起動中ですが、ルートパスが404を返しています"
            return 0  # Server is running, just wrong route
        fi
        return 1
    else
        _ds_log "FAIL" "ヘルスチェック失敗: HTTP ${DS_STATUS_CODE}"
        return 1
    fi
}

# ============================================================
# ds_stop()
# Gracefully stop the dev server. Sends SIGTERM first, waits
# for DS_SHUTDOWN_TIMEOUT seconds, then escalates to SIGKILL.
# Also cleans up the process group if available.
# ============================================================
ds_stop() {
    if [[ -z "$DS_SERVER_PID" ]]; then
        _ds_log "INFO" "停止するサーバーがありません"
        return 0
    fi

    _ds_log "STEP" "Dev Server 停止: PID=${DS_SERVER_PID}"

    # Check if process is still running
    if ! kill -0 "$DS_SERVER_PID" 2>/dev/null; then
        _ds_log "INFO" "サーバーは既に停止しています"
        DS_SERVER_PID=""
        DS_SERVER_PGID=""
        return 0
    fi

    # Step 1: SIGTERM (graceful)
    kill -TERM "$DS_SERVER_PID" 2>/dev/null

    # Also kill the process group if we know it
    if [[ -n "$DS_SERVER_PGID" && "$DS_SERVER_PGID" != "0" ]]; then
        kill -TERM -- "-${DS_SERVER_PGID}" 2>/dev/null || true
    fi

    # Wait for graceful shutdown
    local waited=0
    while (( waited < DS_SHUTDOWN_TIMEOUT )); do
        if ! kill -0 "$DS_SERVER_PID" 2>/dev/null; then
            _ds_log "SUCCESS" "サーバー正常停止 (${waited}秒)"
            DS_SERVER_PID=""
            DS_SERVER_PGID=""
            return 0
        fi
        sleep 1
        (( waited++ ))
    done

    # Step 2: SIGKILL (force)
    _ds_log "WARN" "SIGTERM タイムアウト - SIGKILL で強制停止"
    kill -9 "$DS_SERVER_PID" 2>/dev/null || true
    if [[ -n "$DS_SERVER_PGID" && "$DS_SERVER_PGID" != "0" ]]; then
        kill -9 -- "-${DS_SERVER_PGID}" 2>/dev/null || true
    fi

    sleep 1

    if ! kill -0 "$DS_SERVER_PID" 2>/dev/null; then
        _ds_log "SUCCESS" "サーバー強制停止完了"
    else
        _ds_log "ERROR" "サーバー停止失敗: PID ${DS_SERVER_PID} がまだ存在します"
    fi

    # Also free the port if something is still listening
    if [[ -n "$DS_PORT" ]] && _ds_is_port_in_use "$DS_PORT"; then
        local lingering_pid
        lingering_pid=$(lsof -iTCP:"$DS_PORT" -sTCP:LISTEN -t 2>/dev/null | head -1)
        if [[ -n "$lingering_pid" ]]; then
            _ds_log "WARN" "ポート ${DS_PORT} にまだプロセス (PID=${lingering_pid}) が残っています。強制停止..."
            kill -9 "$lingering_pid" 2>/dev/null || true
        fi
    fi

    DS_SERVER_PID=""
    DS_SERVER_PGID=""
    return 0
}

# ============================================================
# ds_capture_routes(url)
# Attempt to discover available routes by:
#   1. Parsing server stdout for registered routes
#   2. Fetching common API endpoints (/api, /health, /docs)
#   3. Checking sitemap.xml
#   4. Checking known framework-specific paths
# Populates DS_ROUTES_JSON and DS_ROUTES_FOUND.
# ============================================================
ds_capture_routes() {
    local base_url="${1:-$DS_BASE_URL}"
    _ds_log "STEP" "ルート探索開始: ${base_url}"

    DS_ROUTES_FOUND=0
    DS_ROUTES_JSON="[]"
    local routes_list=""

    # --- Method 1: Parse server stdout for route patterns ---
    if [[ -f "$DS_SERVER_STDOUT" ]]; then
        # Express: "GET /api/users"
        # FastAPI: "INFO:     GET /api/users"
        # Next.js: "- /about", "- /api/hello"
        local stdout_routes
        stdout_routes=$(grep -oP '(GET|POST|PUT|DELETE|PATCH)\s+/[^\s]*' "$DS_SERVER_STDOUT" 2>/dev/null | sort -u || true)
        if [[ -z "$stdout_routes" ]]; then
            # Next.js style: "- /path" or "○ /path" or "● /path"
            stdout_routes=$(grep -oP '[-○●λ]\s+(/[^\s]*)' "$DS_SERVER_STDOUT" 2>/dev/null | awk '{print $2}' | sort -u || true)
        fi
        if [[ -n "$stdout_routes" ]]; then
            routes_list="${routes_list}${stdout_routes}"$'\n'
        fi
    fi

    # --- Method 2: Probe common endpoints ---
    local common_paths=("/" "/api" "/health" "/healthz" "/docs" "/api/docs" "/swagger" "/openapi.json" "/sitemap.xml" "/robots.txt")
    for path in "${common_paths[@]}"; do
        local code
        code=$(curl -s -o /dev/null -w '%{http_code}' --max-time 3 "${base_url}${path}" 2>/dev/null || echo "000")
        if [[ "$code" != "000" && "$code" != "404" ]]; then
            routes_list="${routes_list}${path} [HTTP ${code}]"$'\n'
        fi
    done

    # --- Method 3: Parse sitemap.xml if available ---
    local sitemap_body
    sitemap_body=$(curl -s --max-time 5 "${base_url}/sitemap.xml" 2>/dev/null || true)
    if [[ -n "$sitemap_body" ]] && echo "$sitemap_body" | grep -q '<loc>' 2>/dev/null; then
        local sitemap_urls
        sitemap_urls=$(echo "$sitemap_body" | grep -oP '<loc>\K[^<]+' 2>/dev/null | sed "s|${base_url}||g" | head -20 || true)
        if [[ -n "$sitemap_urls" ]]; then
            routes_list="${routes_list}${sitemap_urls}"$'\n'
        fi
    fi

    # --- Build JSON array from collected routes ---
    DS_ROUTES_JSON="["
    local first=true
    while IFS= read -r route; do
        [[ -z "$route" ]] && continue
        local esc_route
        esc_route=$(printf '%s' "$route" | sed 's/\\/\\\\/g; s/"/\\"/g')
        if $first; then
            DS_ROUTES_JSON="${DS_ROUTES_JSON}\"${esc_route}\""
            first=false
        else
            DS_ROUTES_JSON="${DS_ROUTES_JSON},\"${esc_route}\""
        fi
        (( DS_ROUTES_FOUND++ ))
    done <<< "$(echo "$routes_list" | sort -u)"
    DS_ROUTES_JSON="${DS_ROUTES_JSON}]"

    _ds_log "INFO" "検出ルート数: ${DS_ROUTES_FOUND}"
    return 0
}

# ============================================================
# ds_report()
# Generate a structured JSON report of the dev server session,
# including status, timing, routes, and diagnostics.
# Also prints a human-readable summary.
# ============================================================
ds_report() {
    local is_running="false"
    if [[ -n "$DS_SERVER_PID" ]] && kill -0 "$DS_SERVER_PID" 2>/dev/null; then
        is_running="true"
    fi

    local stderr_tail=""
    if [[ -f "$DS_SERVER_STDERR" ]] && [[ -s "$DS_SERVER_STDERR" ]]; then
        stderr_tail=$(tail -5 "$DS_SERVER_STDERR" 2>/dev/null | sed 's/\\/\\\\/g; s/"/\\"/g' | tr '\n' ' ')
    fi

    # JSON report
    local report
    report=$(printf '{
  "project_dir": "%s",
  "stack": "%s",
  "start_cmd": "%s",
  "port": "%s",
  "base_url": "%s",
  "server_pid": "%s",
  "is_running": %s,
  "is_ready": %s,
  "status_code": "%s",
  "startup_duration_sec": "%s",
  "routes_found": %d,
  "routes": %s,
  "stderr_tail": "%s",
  "generated_at": "%s"
}' \
    "$DS_PROJECT_DIR" \
    "$DS_STACK" \
    "$(printf '%s' "$DS_START_CMD" | sed 's/"/\\"/g')" \
    "$DS_PORT" \
    "$DS_BASE_URL" \
    "${DS_SERVER_PID:-none}" \
    "$is_running" \
    "$DS_IS_READY" \
    "${DS_STATUS_CODE:-N/A}" \
    "${DS_STARTUP_DURATION:-N/A}" \
    "$DS_ROUTES_FOUND" \
    "$DS_ROUTES_JSON" \
    "$stderr_tail" \
    "$(date '+%Y-%m-%dT%H:%M:%S')")

    # Persist report
    if [[ -n "$DS_LOG_DIR" ]]; then
        echo "$report" > "${DS_LOG_DIR}/dev-server-report_$(date +%Y%m%d_%H%M%S).json" 2>/dev/null || true
    fi

    # Human-readable summary
    echo ""
    echo -e "  ${DS_BOLD}╔══════════════════════════════════════════════╗${DS_NC}"
    echo -e "  ${DS_BOLD}║          Dev Server Report                   ║${DS_NC}"
    echo -e "  ${DS_BOLD}╠══════════════════════════════════════════════╣${DS_NC}"
    printf  "  ${DS_BOLD}║${DS_NC} %-20s : %-22s ${DS_BOLD}║${DS_NC}\n" "Stack" "$DS_STACK"
    printf  "  ${DS_BOLD}║${DS_NC} %-20s : %-22s ${DS_BOLD}║${DS_NC}\n" "Port" "${DS_PORT:-N/A}"
    printf  "  ${DS_BOLD}║${DS_NC} %-20s : %-22s ${DS_BOLD}║${DS_NC}\n" "URL" "${DS_BASE_URL:-N/A}"
    printf  "  ${DS_BOLD}║${DS_NC} %-20s : %-22s ${DS_BOLD}║${DS_NC}\n" "PID" "${DS_SERVER_PID:-none}"

    local status_display
    if [[ "$is_running" == "true" ]]; then
        status_display="${DS_GREEN}RUNNING${DS_NC}"
    else
        status_display="${DS_RED}STOPPED${DS_NC}"
    fi
    echo -e "  ${DS_BOLD}║${DS_NC} %-20s : ${status_display}                ${DS_BOLD}║${DS_NC}" "Status"

    local ready_display
    if [[ "$DS_IS_READY" == "true" ]]; then
        ready_display="${DS_GREEN}READY (HTTP ${DS_STATUS_CODE})${DS_NC}"
    else
        ready_display="${DS_RED}NOT READY${DS_NC}"
    fi
    echo -e "  ${DS_BOLD}║${DS_NC} %-20s : ${ready_display}          ${DS_BOLD}║${DS_NC}" "Health"

    printf  "  ${DS_BOLD}║${DS_NC} %-20s : %-22s ${DS_BOLD}║${DS_NC}\n" "Startup time" "${DS_STARTUP_DURATION:-N/A}s"
    printf  "  ${DS_BOLD}║${DS_NC} %-20s : %-22s ${DS_BOLD}║${DS_NC}\n" "Routes found" "$DS_ROUTES_FOUND"
    echo -e "  ${DS_BOLD}╚══════════════════════════════════════════════╝${DS_NC}"
    echo ""

    echo "$report"
    return 0
}
