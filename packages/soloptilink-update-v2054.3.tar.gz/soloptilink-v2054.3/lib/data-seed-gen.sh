#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - Data Seed Generator
# =============================================================================
# テストデータシード×ファクトリ×ドメイン別リアルデータ×大規模データセット
#
# 機能:
#   - Prisma/Drizzle seedスクリプト生成（@faker-js/faker）
#   - ファクトリパターン（UserFactory, ProductFactory等）
#   - ドメイン別リアルデータ（CRM, EC, タスク管理）
#   - リレーション対応データ（外部キー整合性保証）
#   - パフォーマンステスト用大規模データセット（10K, 100K, 1M）
#   - JSON/YAMLフィクスチャローダー
#
# 全globals: DSG_ prefix
# =============================================================================

[[ -n "${_DSG_LOADED:-}" ]] && return 0; _DSG_LOADED=1

# =============================================================================
# State
# =============================================================================
DSG_VERSION="140.0"
DSG_GENERATED=0
DSG_ERRORS=0
DSG_PHASE="seed"
DSG_FILES_CREATED=()

# =============================================================================
# Helper
# =============================================================================
_dsg_write_file() {
    local filepath="$1"
    local content="$2"
    local dir
    dir="$(dirname "$filepath")"
    mkdir -p "$dir" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        DSG_FILES_CREATED+=("$filepath")
        DSG_GENERATED=$((DSG_GENERATED + 1))
        echo -e "  ${GREEN:-\033[0;32m}[DSG]${NC:-\033[0m} Created: ${filepath##*/}"
    else
        DSG_ERRORS=$((DSG_ERRORS + 1))
        echo -e "  ${RED:-\033[0;31m}[DSG]${NC:-\033[0m} Failed: ${filepath##*/}"
    fi
}

# =============================================================================
# 初期化
# =============================================================================
ds_init() {
    DSG_GENERATED=0
    DSG_ERRORS=0
    DSG_FILES_CREATED=()
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} Data Seed Generator v${DSG_VERSION}"
    return 0
}

# =============================================================================
# Prisma Seed Script
# =============================================================================
ds_generate_seed_script() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local orm="${2:-prisma}"
    local target="${project_dir}/prisma/seed.ts"

    _dsg_write_file "$target" "$(cat <<'TYPESCRIPT'
import { PrismaClient } from '@prisma/client';
import { createUserFactory, createProductFactory, createOrderFactory } from '../src/lib/seed-factory';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function main() {
  const env = process.env.SEED_ENV || 'development';
  console.log(`Seeding database for: ${env}`);

  // Clean existing data (development only)
  if (env === 'development') {
    console.log('Cleaning existing data...');
    await prisma.$transaction([
      prisma.$executeRaw`DELETE FROM "Order" WHERE 1=1`,
      prisma.$executeRaw`DELETE FROM "Product" WHERE 1=1`,
      prisma.$executeRaw`DELETE FROM "User" WHERE id != 'admin'`,
    ]);
  }

  // Admin user (always)
  const adminPassword = await bcrypt.hash('admin123456', 12);
  await prisma.user.upsert({
    where: { email: 'admin@example.com' },
    update: {},
    create: {
      email: 'admin@example.com',
      name: 'System Admin',
      password: adminPassword,
      role: 'admin',
    },
  });
  console.log('Admin user created');

  // 役割別の代表アカウント (PFP-131: 初回から多役割。管理者単独で完結させない)
  // ★初回ログインで役割差を体感できるよう、各役割の代表を最低1名ずつ投入する。
  //   業種に応じて role 名は調整可 (例: operator/engineer/sales/manager/customer)。
  const demoPassword = await bcrypt.hash('demo123456', 12);
  const roleAccounts = [
    { email: 'manager@example.com', name: 'マネージャー', role: 'manager' },
    { email: 'staff@example.com',   name: '担当者',       role: 'staff' },
    { email: 'viewer@example.com',  name: '閲覧専用',     role: 'viewer' },
  ];
  for (const acc of roleAccounts) {
    await prisma.user.upsert({
      where: { email: acc.email },
      update: {},
      create: { email: acc.email, name: acc.name, password: demoPassword, role: acc.role },
    });
  }
  console.log(`Role accounts created: ${roleAccounts.map((a) => a.role).join(', ')}`);

  // Seed based on environment
  const counts = {
    development: { users: 20, products: 50, orders: 100 },
    staging: { users: 100, products: 200, orders: 500 },
    'prod-sample': { users: 5, products: 10, orders: 20 },
  }[env] || { users: 20, products: 50, orders: 100 };

  const userFactory = createUserFactory();
  const productFactory = createProductFactory();
  const orderFactory = createOrderFactory();

  // Create users
  console.log(`Creating ${counts.users} users...`);
  const users = [];
  for (let i = 0; i < counts.users; i++) {
    const userData = userFactory.build();
    const user = await prisma.user.create({ data: userData });
    users.push(user);
  }

  // Create products
  console.log(`Creating ${counts.products} products...`);
  const products = [];
  for (let i = 0; i < counts.products; i++) {
    const productData = productFactory.build();
    const product = await prisma.product.create({ data: productData });
    products.push(product);
  }

  // Create orders with relationships
  console.log(`Creating ${counts.orders} orders...`);
  for (let i = 0; i < counts.orders; i++) {
    const user = users[Math.floor(Math.random() * users.length)];
    const orderItems = Array.from(
      { length: Math.floor(Math.random() * 4) + 1 },
      () => products[Math.floor(Math.random() * products.length)]
    );

    const orderData = orderFactory.build({
      userId: user.id,
      items: orderItems.map((p) => ({
        productId: p.id,
        quantity: Math.floor(Math.random() * 3) + 1,
        price: p.price,
      })),
    });

    await prisma.order.create({
      data: {
        userId: orderData.userId,
        status: orderData.status,
        total: orderData.items.reduce((s: number, item: any) => s + item.price * item.quantity, 0),
        items: { create: orderData.items },
      },
    });
  }

  console.log(`Seed complete: ${counts.users} users, ${counts.products} products, ${counts.orders} orders`);
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
TYPESCRIPT
)"
}

# =============================================================================
# Factory Pattern
# =============================================================================
ds_generate_factory() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/lib/seed-factory.ts"

    _dsg_write_file "$target" "$(cat <<'TYPESCRIPT'
import { faker } from '@faker-js/faker/locale/ja';
import bcrypt from 'bcryptjs';

// ---------------------------------------------------------------------------
// Base Factory
// ---------------------------------------------------------------------------
interface Factory<T> {
  build(overrides?: Partial<T>): T;
  buildMany(count: number, overrides?: Partial<T>): T[];
}

function createFactory<T>(defaults: () => T): Factory<T> {
  return {
    build(overrides?: Partial<T>): T {
      return { ...defaults(), ...overrides } as T;
    },
    buildMany(count: number, overrides?: Partial<T>): T[] {
      return Array.from({ length: count }, () => this.build(overrides));
    },
  };
}

// ---------------------------------------------------------------------------
// User Factory
// ---------------------------------------------------------------------------
export function createUserFactory() {
  const hashedPassword = bcrypt.hashSync('password123', 10);

  return createFactory(() => ({
    email: faker.internet.email(),
    name: faker.person.fullName(),
    password: hashedPassword,
    role: faker.helpers.arrayElement(['user', 'user', 'user', 'admin'] as const),
    phone: faker.phone.number(),
    avatar: faker.image.avatar(),
    createdAt: faker.date.past({ years: 1 }),
    updatedAt: new Date(),
  }));
}

// ---------------------------------------------------------------------------
// Product Factory
// ---------------------------------------------------------------------------
export function createProductFactory() {
  return createFactory(() => {
    const price = faker.number.int({ min: 100, max: 50000 });
    return {
      name: faker.commerce.productName(),
      description: faker.commerce.productDescription(),
      price,
      sku: faker.string.alphanumeric(8).toUpperCase(),
      stock: faker.number.int({ min: 0, max: 1000 }),
      category: faker.commerce.department(),
      imageUrl: faker.image.url(),
      isActive: faker.datatype.boolean({ probability: 0.9 }),
      createdAt: faker.date.past({ years: 1 }),
      updatedAt: new Date(),
    };
  });
}

// ---------------------------------------------------------------------------
// Order Factory
// ---------------------------------------------------------------------------
export function createOrderFactory() {
  return createFactory((overrides?: any) => ({
    userId: overrides?.userId || faker.string.uuid(),
    status: faker.helpers.arrayElement(['pending', 'confirmed', 'shipped', 'delivered', 'cancelled']),
    items: overrides?.items || [],
    total: 0,
    shippingAddress: `${faker.location.state()}${faker.location.city()}${faker.location.streetAddress()}`,
    createdAt: faker.date.past({ years: 1 }),
    updatedAt: new Date(),
  }));
}

// ---------------------------------------------------------------------------
// CRM Contact Factory
// ---------------------------------------------------------------------------
export function createContactFactory() {
  return createFactory(() => ({
    firstName: faker.person.firstName(),
    lastName: faker.person.lastName(),
    email: faker.internet.email(),
    phone: faker.phone.number(),
    company: faker.company.name(),
    position: faker.person.jobTitle(),
    status: faker.helpers.arrayElement(['lead', 'prospect', 'customer', 'churned']),
    source: faker.helpers.arrayElement(['web', 'referral', 'cold_call', 'event', 'ad']),
    notes: faker.lorem.sentence(),
    lastContactedAt: faker.date.recent({ days: 30 }),
    createdAt: faker.date.past({ years: 2 }),
  }));
}

// ---------------------------------------------------------------------------
// Task Factory
// ---------------------------------------------------------------------------
export function createTaskFactory() {
  return createFactory(() => ({
    title: faker.hacker.phrase(),
    description: faker.lorem.paragraph(),
    status: faker.helpers.arrayElement(['todo', 'in_progress', 'review', 'done']),
    priority: faker.helpers.arrayElement(['low', 'medium', 'high', 'urgent']),
    dueDate: faker.date.future({ years: 0.25 }),
    estimatedHours: faker.number.float({ min: 0.5, max: 40, fractionDigits: 1 }),
    tags: faker.helpers.arrayElements(['bug', 'feature', 'refactor', 'docs', 'test'], { min: 1, max: 3 }),
    createdAt: faker.date.past({ years: 0.5 }),
  }));
}
TYPESCRIPT
)"
}

# =============================================================================
# Domain-Specific Realistic Data
# =============================================================================
ds_generate_realistic_data() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local domain="${2:-${DOMAIN_TYPE:-general}}"
    local target="${project_dir}/src/lib/seed-data-${domain}.ts"

    _dsg_write_file "$target" "$(cat <<TYPESCRIPT
import { faker } from '@faker-js/faker/locale/ja';

// ---------------------------------------------------------------------------
// Domain: ${domain} - Realistic Seed Data
// ---------------------------------------------------------------------------

export function generateRealisticData(count: number) {
  const data: any[] = [];

  for (let i = 0; i < count; i++) {
$(case "$domain" in
    crm|CRM)
        cat <<'DOMAIN_CRM'
    data.push({
      companyName: faker.company.name(),
      industry: faker.helpers.arrayElement([
        'IT', '製造', '小売', '金融', '医療', '教育', '不動産', '物流', '飲食', 'コンサルティング',
      ]),
      revenue: faker.number.int({ min: 1000000, max: 10000000000 }),
      employees: faker.number.int({ min: 1, max: 50000 }),
      contacts: Array.from({ length: faker.number.int({ min: 1, max: 5 }) }, () => ({
        name: faker.person.fullName(),
        email: faker.internet.email(),
        phone: faker.phone.number(),
        department: faker.helpers.arrayElement(['営業', '開発', '人事', '経理', '企画']),
        role: faker.person.jobTitle(),
      })),
      deals: Array.from({ length: faker.number.int({ min: 0, max: 3 }) }, () => ({
        title: faker.commerce.productName() + ' 導入案件',
        amount: faker.number.int({ min: 100000, max: 50000000 }),
        stage: faker.helpers.arrayElement(['qualification', 'proposal', 'negotiation', 'closed_won', 'closed_lost']),
        probability: faker.number.int({ min: 10, max: 100 }),
        expectedCloseDate: faker.date.future({ years: 0.5 }),
      })),
      lastActivity: faker.date.recent({ days: 14 }),
      source: faker.helpers.arrayElement(['紹介', 'Web問合せ', '展示会', 'テレアポ', '広告']),
    });
DOMAIN_CRM
    ;;
    ec|EC|ecommerce)
        cat <<'DOMAIN_EC'
    data.push({
      productName: faker.commerce.productName(),
      description: faker.commerce.productDescription(),
      price: faker.number.int({ min: 100, max: 100000 }),
      originalPrice: faker.number.int({ min: 100, max: 120000 }),
      category: faker.helpers.arrayElement([
        '家電', 'ファッション', '食品', '書籍', 'スポーツ', 'ホビー', 'インテリア', 'コスメ',
      ]),
      brand: faker.company.name(),
      sku: faker.string.alphanumeric(10).toUpperCase(),
      stock: faker.number.int({ min: 0, max: 500 }),
      rating: faker.number.float({ min: 1, max: 5, fractionDigits: 1 }),
      reviewCount: faker.number.int({ min: 0, max: 200 }),
      images: Array.from({ length: faker.number.int({ min: 1, max: 5 }) }, () => faker.image.url()),
      tags: faker.helpers.arrayElements(['送料無料', 'セール', '新着', '人気', '限定'], { min: 0, max: 3 }),
      weight: faker.number.float({ min: 0.1, max: 20, fractionDigits: 1 }),
    });
DOMAIN_EC
    ;;
    *)
        cat <<'DOMAIN_GENERAL'
    data.push({
      name: faker.person.fullName(),
      email: faker.internet.email(),
      phone: faker.phone.number(),
      address: faker.location.state() + faker.location.city() + faker.location.streetAddress(),
      company: faker.company.name(),
      department: faker.helpers.arrayElement(['営業', '開発', '人事', '経理', '企画', '総務']),
      role: faker.person.jobTitle(),
      joinedAt: faker.date.past({ years: 5 }),
      isActive: faker.datatype.boolean({ probability: 0.85 }),
      tags: faker.helpers.arrayElements(['VIP', 'リピーター', '新規', '要フォロー'], { min: 0, max: 2 }),
    });
DOMAIN_GENERAL
    ;;
esac)
  }

  return data;
}
TYPESCRIPT
)"
}

# =============================================================================
# Relationship Data Generator
# =============================================================================
ds_generate_relationship_data() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/lib/seed-relationships.ts"

    _dsg_write_file "$target" "$(cat <<'TYPESCRIPT'
import { PrismaClient } from '@prisma/client';
import { faker } from '@faker-js/faker/locale/ja';

const prisma = new PrismaClient();

// ---------------------------------------------------------------------------
// Relationship-Aware Seeding
// ---------------------------------------------------------------------------
// Ensures foreign key integrity when creating interconnected data

export async function seedWithRelationships(config: {
  users: number;
  productsPerUser?: number;
  ordersPerUser?: number;
  commentsPerOrder?: number;
}) {
  const {
    users: userCount,
    productsPerUser = 3,
    ordersPerUser = 5,
    commentsPerOrder = 2,
  } = config;

  console.log('Phase 1: Creating users...');
  const userIds: string[] = [];
  for (let i = 0; i < userCount; i++) {
    const user = await prisma.user.create({
      data: {
        email: faker.internet.email(),
        name: faker.person.fullName(),
        password: '$2a$10$placeholder', // hashed password placeholder
        role: i === 0 ? 'admin' : 'user',
      },
    });
    userIds.push(user.id);
  }

  console.log('Phase 2: Creating products...');
  const productIds: string[] = [];
  for (let i = 0; i < userCount * productsPerUser; i++) {
    const product = await prisma.product.create({
      data: {
        name: faker.commerce.productName(),
        description: faker.commerce.productDescription(),
        price: faker.number.int({ min: 100, max: 50000 }),
        stock: faker.number.int({ min: 0, max: 100 }),
        category: faker.commerce.department(),
      },
    });
    productIds.push(product.id);
  }

  console.log('Phase 3: Creating orders with items...');
  for (const userId of userIds) {
    for (let o = 0; o < ordersPerUser; o++) {
      const itemCount = faker.number.int({ min: 1, max: 5 });
      const selectedProducts = faker.helpers.arrayElements(productIds, itemCount);

      const items = selectedProducts.map((productId) => ({
        productId,
        quantity: faker.number.int({ min: 1, max: 3 }),
        price: faker.number.int({ min: 100, max: 50000 }),
      }));

      await prisma.order.create({
        data: {
          userId,
          status: faker.helpers.arrayElement(['pending', 'confirmed', 'shipped', 'delivered']),
          total: items.reduce((s, item) => s + item.price * item.quantity, 0),
          items: { create: items },
        },
      });
    }
  }

  console.log(`Seeded: ${userIds.length} users, ${productIds.length} products, ${userIds.length * ordersPerUser} orders`);
  return { userIds, productIds };
}
TYPESCRIPT
)"
}

# =============================================================================
# Large Dataset Generator (10K, 100K, 1M)
# =============================================================================
ds_generate_large_dataset() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/scripts/seed-large.ts"

    _dsg_write_file "$target" "$(cat <<'TYPESCRIPT'
import { PrismaClient } from '@prisma/client';
import { faker } from '@faker-js/faker/locale/ja';

const prisma = new PrismaClient();

// ---------------------------------------------------------------------------
// Large Dataset Generator for Performance Testing
// ---------------------------------------------------------------------------
// Usage: npx tsx scripts/seed-large.ts [10k|100k|1m]
// ---------------------------------------------------------------------------

const SIZES: Record<string, { users: number; products: number; orders: number }> = {
  '10k':  { users: 1000,   products: 5000,   orders: 10000 },
  '100k': { users: 10000,  products: 50000,  orders: 100000 },
  '1m':   { users: 100000, products: 500000, orders: 1000000 },
};

const BATCH_SIZE = 500; // Prisma createMany batch size

async function seedLarge(size: string) {
  const config = SIZES[size];
  if (!config) {
    console.error(`Unknown size: ${size}. Use: 10k, 100k, 1m`);
    process.exit(1);
  }

  console.log(`Seeding ${size} dataset: ${JSON.stringify(config)}`);
  const start = Date.now();

  // Phase 1: Users (batch insert)
  console.log(`Creating ${config.users} users...`);
  for (let offset = 0; offset < config.users; offset += BATCH_SIZE) {
    const batch = Array.from({ length: Math.min(BATCH_SIZE, config.users - offset) }, (_, i) => ({
      email: `user${offset + i}@perf-test.local`,
      name: faker.person.fullName(),
      password: '$2a$10$placeholder',
      role: 'user' as const,
    }));

    await prisma.user.createMany({ data: batch, skipDuplicates: true });

    if ((offset + BATCH_SIZE) % 5000 === 0) {
      console.log(`  Users: ${Math.min(offset + BATCH_SIZE, config.users)}/${config.users}`);
    }
  }

  // Phase 2: Products (batch insert)
  console.log(`Creating ${config.products} products...`);
  for (let offset = 0; offset < config.products; offset += BATCH_SIZE) {
    const batch = Array.from({ length: Math.min(BATCH_SIZE, config.products - offset) }, () => ({
      name: faker.commerce.productName(),
      description: faker.lorem.sentence(),
      price: faker.number.int({ min: 100, max: 100000 }),
      stock: faker.number.int({ min: 0, max: 1000 }),
      category: faker.commerce.department(),
    }));

    await prisma.product.createMany({ data: batch });

    if ((offset + BATCH_SIZE) % 10000 === 0) {
      console.log(`  Products: ${Math.min(offset + BATCH_SIZE, config.products)}/${config.products}`);
    }
  }

  // Phase 3: Orders (requires user IDs)
  console.log(`Creating ${config.orders} orders...`);
  const userIds = (await prisma.user.findMany({ select: { id: true }, take: config.users })).map((u) => u.id);

  for (let offset = 0; offset < config.orders; offset += BATCH_SIZE) {
    const batch = Array.from({ length: Math.min(BATCH_SIZE, config.orders - offset) }, () => ({
      userId: userIds[Math.floor(Math.random() * userIds.length)],
      status: faker.helpers.arrayElement(['pending', 'confirmed', 'shipped', 'delivered', 'cancelled']),
      total: faker.number.int({ min: 500, max: 200000 }),
    }));

    await prisma.order.createMany({ data: batch });

    if ((offset + BATCH_SIZE) % 10000 === 0) {
      console.log(`  Orders: ${Math.min(offset + BATCH_SIZE, config.orders)}/${config.orders}`);
    }
  }

  const elapsed = ((Date.now() - start) / 1000).toFixed(1);
  console.log(`\nDone! ${size} dataset seeded in ${elapsed}s`);

  // Report counts
  const [uc, pc, oc] = await Promise.all([
    prisma.user.count(), prisma.product.count(), prisma.order.count(),
  ]);
  console.log(`Final counts: ${uc} users, ${pc} products, ${oc} orders`);
}

const size = process.argv[2] || '10k';
seedLarge(size)
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
TYPESCRIPT
)"
}

# =============================================================================
# Fixture Loader (JSON/YAML)
# =============================================================================
ds_generate_fixture_loader() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/lib/fixture-loader.ts"

    _dsg_write_file "$target" "$(cat <<'TYPESCRIPT'
import { readFileSync, existsSync, readdirSync } from 'fs';
import path from 'path';

// ---------------------------------------------------------------------------
// JSON/YAML Fixture Loader for Tests
// ---------------------------------------------------------------------------

export interface FixtureOptions {
  baseDir?: string;
  format?: 'json' | 'yaml' | 'auto';
}

const DEFAULT_FIXTURE_DIR = 'tests/fixtures';

export function loadFixture<T = any>(name: string, options: FixtureOptions = {}): T {
  const baseDir = options.baseDir || DEFAULT_FIXTURE_DIR;
  const format = options.format || 'auto';

  let filePath: string;

  if (format === 'auto') {
    // Try JSON first, then YAML
    const jsonPath = path.resolve(baseDir, `${name}.json`);
    const yamlPath = path.resolve(baseDir, `${name}.yaml`);
    const ymlPath = path.resolve(baseDir, `${name}.yml`);

    if (existsSync(jsonPath)) filePath = jsonPath;
    else if (existsSync(yamlPath)) filePath = yamlPath;
    else if (existsSync(ymlPath)) filePath = ymlPath;
    else throw new Error(`Fixture not found: ${name} (searched in ${baseDir})`);
  } else {
    const ext = format === 'yaml' ? 'yaml' : 'json';
    filePath = path.resolve(baseDir, `${name}.${ext}`);
    if (!existsSync(filePath)) {
      throw new Error(`Fixture not found: ${filePath}`);
    }
  }

  const content = readFileSync(filePath, 'utf-8');

  if (filePath.endsWith('.json')) {
    return JSON.parse(content) as T;
  }

  // Simple YAML parser for common structures (key: value, arrays)
  return parseSimpleYaml(content) as T;
}

export function loadAllFixtures<T = any>(dir?: string): Record<string, T> {
  const baseDir = dir || DEFAULT_FIXTURE_DIR;
  const result: Record<string, T> = {};

  if (!existsSync(baseDir)) return result;

  const files = readdirSync(baseDir).filter(
    (f) => f.endsWith('.json') || f.endsWith('.yaml') || f.endsWith('.yml')
  );

  for (const file of files) {
    const name = file.replace(/\.(json|yaml|yml)$/, '');
    try {
      result[name] = loadFixture<T>(name, { baseDir });
    } catch (e) {
      console.warn(`Failed to load fixture: ${file}`, e);
    }
  }

  return result;
}

function parseSimpleYaml(content: string): any {
  // Minimal YAML parser - for complex YAML, use 'yaml' package
  const lines = content.split('\n').filter((l) => l.trim() && !l.trim().startsWith('#'));
  const result: Record<string, any> = {};

  for (const line of lines) {
    const match = line.match(/^(\s*)(\w+):\s*(.*)$/);
    if (match) {
      const [, , key, value] = match;
      if (value === '') continue; // nested object, skip for simple parser
      result[key] = parseYamlValue(value);
    }
  }

  return result;
}

function parseYamlValue(value: string): any {
  if (value === 'true') return true;
  if (value === 'false') return false;
  if (value === 'null' || value === '~') return null;
  if (/^\d+$/.test(value)) return parseInt(value, 10);
  if (/^\d+\.\d+$/.test(value)) return parseFloat(value);
  if (value.startsWith('"') && value.endsWith('"')) return value.slice(1, -1);
  if (value.startsWith("'") && value.endsWith("'")) return value.slice(1, -1);
  if (value.startsWith('[') && value.endsWith(']')) {
    return value.slice(1, -1).split(',').map((v) => parseYamlValue(v.trim()));
  }
  return value;
}
TYPESCRIPT
)"

    # Create sample fixture
    local fixture_dir="${project_dir}/tests/fixtures"
    _dsg_write_file "${fixture_dir}/sample-users.json" "$(cat <<'JSON'
[
  { "email": "test@example.com", "name": "Test User", "role": "user" },
  { "email": "admin@example.com", "name": "Admin User", "role": "admin" }
]
JSON
)"
}

# =============================================================================
# Inject seed patterns into Claude prompt
# =============================================================================
ds_inject_seed_patterns() {
    local prompt="${1:-}"

    cat <<'PATTERNS'

## [SEED] テストデータ生成パターン（必須準拠）

### Prisma Seed
- `npx prisma db seed` で実行
- package.json に `"prisma": { "seed": "tsx prisma/seed.ts" }` 設定必須
- SEED_ENV=development|staging|prod-sample で件数切替

### ファクトリ
- `createUserFactory().build()` - 単体生成
- `createProductFactory().buildMany(100)` - 一括生成
- `createContactFactory()` - CRM向け
- `createTaskFactory()` - タスク管理向け
- faker.js/locale/ja で日本語リアルデータ

### リレーション
- `seedWithRelationships({ users: 100, ordersPerUser: 5 })`
- 外部キー整合性保証（User -> Order -> OrderItem）

### 大規模データ
- `npx tsx scripts/seed-large.ts 10k` - 1万件
- `npx tsx scripts/seed-large.ts 100k` - 10万件
- `npx tsx scripts/seed-large.ts 1m` - 100万件
- BATCH_SIZE=500 でメモリ効率的な一括挿入

### フィクスチャ
- `loadFixture<User[]>('sample-users')` - JSON/YAML自動検出
- `tests/fixtures/` ディレクトリ配置
PATTERNS

    echo "$prompt"
}

# =============================================================================
# Report
# =============================================================================
dsg_report() {
    echo -e "\n  ${BOLD:-}=== Data Seed Generator v${DSG_VERSION} ===${NC:-}"
    echo -e "  生成数: ${DSG_GENERATED}"
    echo -e "  エラー: ${DSG_ERRORS}"
    if [[ ${#DSG_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${DSG_FILES_CREATED[@]}"; do
            echo -e "    - ${f}"
        done
    fi
}

dsg_score() {
    if [[ ${DSG_GENERATED} -ge 5 ]] && [[ ${DSG_ERRORS} -eq 0 ]]; then
        echo "95"
    elif [[ ${DSG_GENERATED} -gt 0 ]] && [[ ${DSG_ERRORS} -eq 0 ]]; then
        echo "90"
    elif [[ ${DSG_GENERATED} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "data-seed-gen" --version "140.0" \
        --description "テストデータシード×ファクトリ×ドメイン別リアルデータ×大規模データセット" \
        --init "ds_init" --report "dsg_report" --score "dsg_score" \
        --enable-var "ENABLE_SEED" --cli-flags "--data-seed:--no-data-seed"
fi

# v2003.1: source時のexit codeを確実に0にする
true
