#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v317.0 - Notification Hub
# =============================================================================
# マルチチャネル通知ハブ: Email/Push/SMS/Slack/LINE/テンプレート/スケジューリング
#
# 全globals: NH_ prefix
# =============================================================================

[[ -n "${_NOTIFICATION_HUB_LOADED:-}" ]] && return 0
_NOTIFICATION_HUB_LOADED=1

declare -g NH_VERSION="317.0"
declare -g NH_INITIALIZED=false
declare -g NH_GENERATED_COUNT=0
declare -g ENABLE_NOTIFICATION_HUB="${ENABLE_NOTIFICATION_HUB:-true}"

readonly NH_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly NH_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly NH_BOLD="${CLR_BOLD:-\033[1m}"
readonly NH_NC="${CLR_NC:-\033[0m}"

_nh_log() { echo -e "  ${NH_CYAN}[NH]${NH_NC} $*" >&2; }
_nh_ok()  { echo -e "  ${NH_GREEN}[NH] OK${NH_NC} $*" >&2; }

nh_init() { NH_INITIALIZED=true; NH_GENERATED_COUNT=0; return 0; }
nh_report() { [[ "$NH_INITIALIZED" != "true" ]] && return 0; echo -e "\n  ${NH_BOLD}--- Notification Hub v${NH_VERSION} ---${NH_NC}" >&2; echo -e "  生成数: ${NH_GENERATED_COUNT}" >&2; }
nh_score() { [[ "$NH_INITIALIZED" != "true" ]] && { echo "0"; return; }; local s=50; [[ $NH_GENERATED_COUNT -ge 3 ]] && s=85; echo "$s"; }
nh_init_message() { echo -e "  ${NH_GREEN}v${NH_VERSION} notification-hub: マルチチャネル通知ハブ${NH_NC}" >&2; }

_nh_generate_multi_channel() {
    local project_dir="${1:-.}"
    _nh_log "マルチチャネル通知エンジン生成"
    local lib_dir="${project_dir}/src/lib"
    mkdir -p "$lib_dir"

    cat > "${lib_dir}/notification-service.ts" <<'EOF'
type Channel = 'email' | 'push' | 'sms' | 'slack' | 'line' | 'in_app';

interface NotificationPayload {
  userId: string;
  channels: Channel[];
  title: string;
  body: string;
  templateId?: string;
  data?: Record<string, any>;
  scheduledAt?: Date;
}

interface ChannelProvider {
  send(userId: string, title: string, body: string, data?: any): Promise<{ success: boolean; messageId?: string; error?: string }>;
}

class NotificationService {
  private providers = new Map<Channel, ChannelProvider>();

  registerProvider(channel: Channel, provider: ChannelProvider) {
    this.providers.set(channel, provider);
  }

  async send(payload: NotificationPayload): Promise<Record<Channel, { success: boolean; error?: string }>> {
    const results: Record<string, any> = {};

    for (const channel of payload.channels) {
      const provider = this.providers.get(channel);
      if (!provider) { results[channel] = { success: false, error: 'No provider registered' }; continue; }
      try {
        results[channel] = await provider.send(payload.userId, payload.title, payload.body, payload.data);
      } catch (e: any) {
        results[channel] = { success: false, error: e.message };
      }
    }

    // Log notification
    try {
      await fetch('/api/notifications/log', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...payload, results, sentAt: new Date() }),
      });
    } catch { /* silent */ }

    return results as any;
  }

  async sendBatch(payloads: NotificationPayload[]) {
    return Promise.allSettled(payloads.map(p => this.send(p)));
  }
}

// Default providers
const emailProvider: ChannelProvider = {
  async send(userId, title, body) {
    // TODO: Integrate with SendGrid/Resend/SES
    console.log(`[Email] To:${userId} Subject:${title}`);
    return { success: true, messageId: `email-${Date.now()}` };
  }
};

const slackProvider: ChannelProvider = {
  async send(userId, title, body) {
    const webhookUrl = process.env.SLACK_WEBHOOK_URL;
    if (!webhookUrl) return { success: false, error: 'SLACK_WEBHOOK_URL not set' };
    const res = await fetch(webhookUrl, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ text: `*${title}*\n${body}` }) });
    return { success: res.ok };
  }
};

const lineProvider: ChannelProvider = {
  async send(userId, title, body) {
    const token = process.env.LINE_CHANNEL_ACCESS_TOKEN;
    if (!token) return { success: false, error: 'LINE token not set' };
    const res = await fetch('https://api.line.me/v2/bot/message/push', {
      method: 'POST', headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${token}` },
      body: JSON.stringify({ to: userId, messages: [{ type: 'text', text: `${title}\n${body}` }] }),
    });
    return { success: res.ok };
  }
};

export const notificationService = new NotificationService();
notificationService.registerProvider('email', emailProvider);
notificationService.registerProvider('slack', slackProvider);
notificationService.registerProvider('line', lineProvider);
EOF

    NH_GENERATED_COUNT=$((NH_GENERATED_COUNT + 1))
    _nh_ok "マルチチャネル通知エンジン生成完了"
    return 0
}

_nh_generate_preferences() {
    local project_dir="${1:-.}"
    _nh_log "通知設定UI生成"
    local comp_dir="${project_dir}/src/components/notifications"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/NotificationPreferences.tsx" <<'EOF'
'use client';
import { useState, useEffect } from 'react';
import { Mail, Bell, MessageSquare, Hash, Save } from 'lucide-react';

const channels = [
  { id: 'email', label: 'メール', icon: <Mail size={18} /> },
  { id: 'push', label: 'プッシュ通知', icon: <Bell size={18} /> },
  { id: 'slack', label: 'Slack', icon: <Hash size={18} /> },
  { id: 'line', label: 'LINE', icon: <MessageSquare size={18} /> },
];

const categories = [
  { id: 'system', label: 'システム通知' },
  { id: 'marketing', label: 'マーケティング' },
  { id: 'updates', label: '更新通知' },
  { id: 'security', label: 'セキュリティ' },
];

export function NotificationPreferences({ userId }: { userId: string }) {
  const [prefs, setPrefs] = useState<Record<string, Record<string, boolean>>>({});
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    fetch(`/api/notifications/preferences?userId=${userId}`).then(r => r.json()).then(d => setPrefs(d.preferences || {})).catch(() => {});
  }, [userId]);

  const toggle = (category: string, channel: string) => {
    setPrefs(prev => ({ ...prev, [category]: { ...prev[category], [channel]: !(prev[category]?.[channel] ?? true) } }));
  };

  const handleSave = async () => {
    setSaving(true);
    try {
      await fetch('/api/notifications/preferences', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ userId, preferences: prefs }) });
      setSaved(true); setTimeout(() => setSaved(false), 2000);
    } catch { alert('保存に失敗'); } finally { setSaving(false); }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <h2 className="text-lg font-bold mb-4">通知設定</h2>
      <div className="overflow-auto">
        <table className="w-full text-sm">
          <thead><tr><th className="text-left py-2"></th>{channels.map(ch => <th key={ch.id} className="text-center py-2 px-4"><div className="flex flex-col items-center gap-1">{ch.icon}<span className="text-xs">{ch.label}</span></div></th>)}</tr></thead>
          <tbody>{categories.map(cat => (
            <tr key={cat.id} className="border-t">
              <td className="py-3 font-medium">{cat.label}</td>
              {channels.map(ch => (
                <td key={ch.id} className="text-center py-3">
                  <input type="checkbox" checked={prefs[cat.id]?.[ch.id] ?? true} onChange={() => toggle(cat.id, ch.id)} className="w-5 h-5 rounded" />
                </td>
              ))}
            </tr>
          ))}</tbody>
        </table>
      </div>
      <div className="mt-6 flex items-center gap-3">
        <button onClick={handleSave} disabled={saving} className="bg-blue-600 text-white px-6 py-2 rounded-lg flex items-center gap-2 disabled:opacity-50"><Save size={16} /> {saving ? '保存中...' : '保存'}</button>
        {saved && <span className="text-green-600 text-sm">保存しました</span>}
      </div>
    </div>
  );
}
EOF

    NH_GENERATED_COUNT=$((NH_GENERATED_COUNT + 1))
    _nh_ok "通知設定UI生成完了"
    return 0
}

_nh_generate_templates() {
    local project_dir="${1:-.}"
    _nh_log "通知テンプレート生成"
    local lib_dir="${project_dir}/src/lib"
    mkdir -p "$lib_dir"

    cat > "${lib_dir}/notification-templates.ts" <<'EOF'
interface NotificationTemplate { id: string; name: string; channels: Record<string, { subject?: string; body: string }>; variables: string[]; }

const templates: NotificationTemplate[] = [
  {
    id: 'welcome', name: 'ウェルカム', variables: ['userName', 'appName'],
    channels: {
      email: { subject: '{{appName}}へようこそ！', body: '{{userName}}様、{{appName}}への登録ありがとうございます。' },
      push: { body: '{{userName}}さん、ようこそ！' },
      slack: { body: ':wave: {{userName}}さんが{{appName}}に参加しました！' },
      line: { body: '{{userName}}様、{{appName}}へようこそ！' },
    },
  },
  {
    id: 'password_reset', name: 'パスワードリセット', variables: ['userName', 'resetLink'],
    channels: { email: { subject: 'パスワードリセット', body: '{{userName}}様、パスワードリセットはこちら: {{resetLink}}' } },
  },
  {
    id: 'order_confirmed', name: '注文確認', variables: ['userName', 'orderNumber', 'total'],
    channels: {
      email: { subject: '注文確認 #{{orderNumber}}', body: '{{userName}}様、ご注文（#{{orderNumber}}、合計{{total}}円）を確認しました。' },
      line: { body: 'ご注文 #{{orderNumber}} ({{total}}円) を承りました。' },
    },
  },
];

export function renderTemplate(templateId: string, channel: string, variables: Record<string, string>): { subject?: string; body: string } | null {
  const tmpl = templates.find(t => t.id === templateId);
  if (!tmpl) return null;
  const channelTmpl = tmpl.channels[channel];
  if (!channelTmpl) return null;

  const replace = (text: string) => Object.entries(variables).reduce((t, [k, v]) => t.replace(new RegExp(`\\{\\{${k}\\}\\}`, 'g'), v), text);
  return { subject: channelTmpl.subject ? replace(channelTmpl.subject) : undefined, body: replace(channelTmpl.body) };
}

export function listTemplates() { return templates; }
export function getTemplate(id: string) { return templates.find(t => t.id === id); }
EOF

    NH_GENERATED_COUNT=$((NH_GENERATED_COUNT + 1))
    _nh_ok "通知テンプレート生成完了"
    return 0
}

_nh_generate_scheduler() {
    local project_dir="${1:-.}"
    _nh_log "通知スケジューラー生成"
    local api_dir="${project_dir}/src/app/api/notifications/scheduled"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';

interface ScheduledNotification { id: string; userId: string; channels: string[]; title: string; body: string; scheduledAt: string; sent: boolean; }

// In production, use a database or queue system
const scheduledNotifications: ScheduledNotification[] = [];

export async function POST(req: NextRequest) {
  try {
    const { userId, channels, title, body, scheduledAt } = await req.json();
    if (!userId || !title || !scheduledAt) return NextResponse.json({ error: 'userId, title, scheduledAt required' }, { status: 400 });

    const notification: ScheduledNotification = {
      id: `sn-${Date.now()}-${Math.random().toString(36).substr(2, 6)}`,
      userId, channels: channels || ['email'], title, body,
      scheduledAt, sent: false,
    };
    scheduledNotifications.push(notification);
    return NextResponse.json(notification, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to schedule notification' }, { status: 500 });
  }
}

// Cron endpoint to process scheduled notifications
export async function GET() {
  try {
    const now = new Date();
    const pending = scheduledNotifications.filter(n => !n.sent && new Date(n.scheduledAt) <= now);
    let sent = 0;

    for (const notification of pending) {
      try {
        await fetch('/api/notifications/send', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId: notification.userId, channels: notification.channels, title: notification.title, body: notification.body }),
        });
        notification.sent = true;
        sent++;
      } catch { /* retry next cycle */ }
    }

    return NextResponse.json({ processed: sent, pending: scheduledNotifications.filter(n => !n.sent).length });
  } catch (error) {
    return NextResponse.json({ error: 'Processing failed' }, { status: 500 });
  }
}
EOF

    NH_GENERATED_COUNT=$((NH_GENERATED_COUNT + 1))
    _nh_ok "通知スケジューラー生成完了"
    return 0
}

_mr_register \
    --name "notification-hub" \
    --version "317.0" \
    --description "マルチチャネル通知ハブ（Email/Push/SMS/Slack/LINE/テンプレート）" \
    --init "nh_init" \
    --report "nh_report" \
    --score "nh_score" \
    --enable-var "ENABLE_NOTIFICATION_HUB" \
    --cli-flags "--notification-hub:--no-notification-hub" \
    --init-msg "nh_init_message"
