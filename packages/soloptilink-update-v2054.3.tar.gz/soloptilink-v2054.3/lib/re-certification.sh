#!/usr/bin/env bash
# ==============================================================================
# 月次 Re-Certification — 納品済みプロジェクトの「動く保証」継続更新
# ------------------------------------------------------------------------------
# 目的:
#   一度納品して終わりにせず、毎月「いまも問題なく動くこと」を実測で確認し直し、
#   品質証明書を最新の判定で再発行する。これが月額累計課金 (継続的動作保証) の
#   実体的な根拠となる。「払い続けている間、ずっと動く保証を更新し続けている」を
#   機械的・改ざん不能な形で示せるようにする。
#
# 使い方 (CLI 契約):
#   bash re-certification.sh <project_dir>
#     1. 依存脆弱性スキャン (npm audit --json / package.json 無ければ skip)
#     2. 主要ゲートの再走 (存在するもののみ・best-effort) で直近 verdict を更新
#     3. 品質証明書 (品質証明書.html / certificate.json) を再発行し
#        certificate.json に recertified_at と vuln_summary を追記
#        (前回 certificate.json があれば fingerprint 差分も記録)
#     4. サーバへ発行記録を best-effort 登録
#   bash re-certification.sh --help
#
# 設計上の不変条件:
#   - PII を一切残さない。再走ゲートの結果は verdict (PASS/WARN/FAIL/BLOCK/NA) のみを
#     抽出して certificate に継承させる。ログイン検証が出力する tested_email 等の
#     PII フィールドは取り込まない。
#   - best-effort 原則。npm が無い / quality-evidence-report.sh が無い / ゲートが
#     存在しない / サーバ未到達 — いずれでも全体は止めず、出来た範囲で再認証を完了する。
#   - quality-evidence-report.sh が在れば必ずそれを正本として使う。不在のときだけ
#     最小限の certificate.json を自前で生成し graceful degrade する。
#
# 出力:
#   <project_dir>/品質証明書.html              (quality-evidence-report.sh が在る場合)
#   <project_dir>/.soloptilink/certificate.json (recertified_at / vuln_summary 追記済)
#   <project_dir>/.soloptilink/*-recert-results.json (再走ゲートの verdict 記録・PIIなし)
#   <project_dir>/.soloptilink/recertification.json   (再認証サマリ・PIIなし)
#
# 終了コード:
#   0 = 再認証完了 (best-effort のため部分成功も 0)
#   2 = 設定エラー (project_dir 不正 / python3 不在)
# 依存: python3 (必須), npm (任意/脆弱性スキャン), bash (各ゲート / QER)
# ==============================================================================
set -uo pipefail

# ------------------------------------------------------------------------------
# 引数解釈
# ------------------------------------------------------------------------------
case "${1:-}" in
    -h|--help|help)
        cat <<'USAGE'
月次 Re-Certification — 納品済みプロジェクトの動作保証を継続更新
使い方:
  re-certification.sh <project_dir>   脆弱性スキャン→主要ゲート再走→品質証明書再発行→登録
  re-certification.sh --help          このヘルプを表示
USAGE
        exit 0
        ;;
esac

PROJECT_DIR_RAW="${1:-}"
if [[ -z "$PROJECT_DIR_RAW" ]]; then
    echo "❌ project_dir を指定してください (例: re-certification.sh /path/to/project)" >&2
    exit 2
fi

# プロジェクトディレクトリの正規化 (実在確認を兼ねる)
PROJECT_DIR="$(cd "$PROJECT_DIR_RAW" 2>/dev/null && pwd)" || {
    echo "❌ project_dir が見つかりません: $PROJECT_DIR_RAW" >&2
    exit 2
}

command -v python3 >/dev/null 2>&1 || {
    echo "❌ python3 が見つかりません (再認証の証明書処理に必要です)" >&2
    exit 2
}

# ------------------------------------------------------------------------------
# 基本パス・定数
# ------------------------------------------------------------------------------
SL_HOME="${SOLOPTILINK_HOME:-$HOME/.soloptilink}"
LIB_DIR="$SL_HOME/lib"
FBP_DIR="$LIB_DIR/first-boot-perfect"
QER="$LIB_DIR/quality-evidence-report.sh"
SLD="$PROJECT_DIR/.soloptilink"
CERT_PATH="$SLD/certificate.json"
RECERT_SUMMARY="$SLD/recertification.json"

RECERT_VERSION="v2041"
RECERTIFIED_AT="$(date -u +%Y-%m-%dT%H:%M:%SZ)"

mkdir -p "$SLD" 2>/dev/null || true

echo "🔄 月次 Re-Certification を開始します"
echo "   対象: $(basename "$PROJECT_DIR")"
echo "   日時: $RECERTIFIED_AT"
echo ""

# ==============================================================================
# STEP 1: 依存脆弱性スキャン (npm audit --json)
# ------------------------------------------------------------------------------
# package.json が在れば npm audit --json を best-effort 実行し critical/high を集計。
# package.json 無し / npm 不在 / 実行失敗・ネットワーク不通は skip (件数 0/0)。
# ==============================================================================
echo "── STEP 1 ── 依存脆弱性スキャン"

VULN_CRITICAL=0
VULN_HIGH=0
VULN_STATUS="skipped"   # scanned | skipped
VULN_REASON="package.json が無いためスキップ"

if [[ -f "$PROJECT_DIR/package.json" ]]; then
    if command -v npm >/dev/null 2>&1; then
        # ネットワーク制約やレジストリ未解決で長引くことがあるため上限を設ける。
        # GNU/BSD どちらの timeout も無い環境を考慮し、無ければそのまま実行する。
        AUDIT_JSON=""
        AUDIT_RC=0
        TIMEOUT_BIN=""
        if command -v timeout >/dev/null 2>&1; then TIMEOUT_BIN="timeout 120"
        elif command -v gtimeout >/dev/null 2>&1; then TIMEOUT_BIN="gtimeout 120"; fi

        # --json は脆弱性検出時に非ゼロ終了する仕様のため、終了コードでは成否判定しない。
        # 出力 JSON がパースできるかどうかで成否を判定する。
        AUDIT_JSON="$( cd "$PROJECT_DIR" && $TIMEOUT_BIN npm audit --json 2>/dev/null )" || AUDIT_RC=$?

        # npm v6 系: { metadata: { vulnerabilities: { critical, high, ... } } }
        # npm v7+   : { metadata: { vulnerabilities: { critical, high, ... } } } (同形)
        PARSED="$(
            printf '%s' "$AUDIT_JSON" | python3 -c '
import sys, json
try:
    d = json.load(sys.stdin)
except Exception:
    print("ERR 0 0"); sys.exit(0)
meta = d.get("metadata", {}) if isinstance(d, dict) else {}
vuln = meta.get("vulnerabilities", {}) if isinstance(meta, dict) else {}
def n(k):
    v = vuln.get(k, 0)
    try: return int(v)
    except Exception: return 0
print("OK %d %d" % (n("critical"), n("high")))
' 2>/dev/null
        )"

        set -- $PARSED
        if [[ "${1:-ERR}" == "OK" ]]; then
            VULN_CRITICAL="${2:-0}"
            VULN_HIGH="${3:-0}"
            VULN_STATUS="scanned"
            VULN_REASON="npm audit --json を実行"
            echo "   ✅ 脆弱性スキャン完了: critical=$VULN_CRITICAL / high=$VULN_HIGH"
        else
            VULN_STATUS="skipped"
            VULN_REASON="npm audit の結果を解析できなかったためスキップ (ネットワーク不通等)"
            echo "   ⚠ npm audit を解析できませんでした → スキップ (件数 0/0 として継続)"
        fi
    else
        VULN_REASON="npm コマンドが無いためスキップ"
        echo "   ⚠ npm が見つかりません → 脆弱性スキャンをスキップ"
    fi
else
    echo "   ℹ package.json が無いため脆弱性スキャンをスキップ"
fi
echo ""

# ==============================================================================
# STEP 2: 主要ゲートの再走 (存在するもののみ・best-effort)
# ------------------------------------------------------------------------------
# first-boot-perfect 配下の主要ゲートを <project_dir> に対して再実行し、直近の
# verdict を更新する。各ゲートは固有の出力 JSON を書く (例: runtime-login-smoke.json,
# build-dev-hygiene.json)。そこから verdict のみを抽出し、PII を含めずに
# <gate>-recert-results.json として書き出す。quality-evidence-report.sh は
# *-results.json を取り込むため、これにより再走判定が品質証明書へ継承される。
#
# 再走対象 (主要ゲート):
#   runtime-login-smoke   実 DB ログインが今も成立するか (動作保証の核)
#   build-dev-hygiene     ビルド衛生 (本番ビルドが今も通るか)
# 各ゲートのスクリプト / 引数の差異は best-effort で吸収する。存在しない・実行
# できないゲートは黙ってスキップする (全体は止めない)。
# ==============================================================================
echo "── STEP 2 ── 主要ゲートの再走 (best-effort)"

GATE_RESULTS_JSON="[]"   # python へ渡す再走結果の配列 (name/verdict/ran)

# ゲート 1 件を再走するヘルパ。
#   $1 = 表示名 (日本語)
#   $2 = recert-results の base 名 (<base>-recert-results.json として出力)
#   $3 = ゲートスクリプトのパス
#   $4 = ゲートが書く出力 JSON のパス (verdict 抽出元)
#   $5.. = ゲートに渡す引数 (PROJECT_DIR は含めず、ここで付与する位置に応じて呼ぶ)
run_gate() {
    local disp="$1"; local base="$2"; local script="$3"; local out_json="$4"; shift 4
    local ran="no" verdict="NA"

    if [[ ! -x "$script" && ! -f "$script" ]]; then
        echo "   ⏭  $disp: スクリプトが無いためスキップ"
        _append_gate_result "$base" "$disp" "$verdict" "$ran"
        return 0
    fi

    echo "   ▶ $disp を再走中..."
    # best-effort: ゲートが失敗 (exit!=0) しても処理は止めない。出力 JSON があれば
    # そこから verdict を採取する。出力が無ければ NA。
    bash "$script" "$@" >/dev/null 2>&1 || true
    ran="yes"

    if [[ -f "$out_json" ]]; then
        verdict="$(
            python3 - "$out_json" <<'PY'
import sys, json
ALLOWED = ("PASS", "WARN", "FAIL", "BLOCK", "NA")
def norm(v):
    u = str(v).strip().upper().replace("-", "_")
    if u in ("PASS","PASSED","OK","GO","SUCCESS","GREEN","APPLIED"): return "PASS"
    if u in ("WARN","WARNING","YELLOW"): return "WARN"
    if u in ("FAIL","FAILED","NG","RED","ERROR"): return "FAIL"
    if u == "BLOCK": return "BLOCK"
    if u in ("NOT_APPLICABLE","NA","N/A","SKIP","SKIPPED","NONE"): return "NA"
    return None
try:
    d = json.load(open(sys.argv[1], encoding="utf-8"))
except Exception:
    print("NA"); sys.exit(0)
res = None
if isinstance(d, dict):
    for k in ("verdict","status","overall","result"):
        if k in d:
            r = norm(d[k])
            if r: res = r; break
print(res if res in ALLOWED else "NA")
PY
        )"
    fi
    echo "      判定: $verdict"
    _append_gate_result "$base" "$disp" "$verdict" "$ran"

    # ★ PII を含めず verdict のみを *-recert-results.json として書き出し、
    #    quality-evidence-report.sh (*-results.json 取込) に継承させる。
    python3 - "$SLD/${base}-recert-results.json" "$disp" "$verdict" "$RECERTIFIED_AT" <<'PY'
import sys, json
out, name, verdict, ts = sys.argv[1], sys.argv[2], sys.argv[3], sys.argv[4]
rec = {
    "gate": name,
    "verdict": verdict,
    "recertified": True,
    "evaluatedAt": ts,
    "note": "月次再認証で再走した最新判定 (PIIなし)",
}
try:
    json.dump(rec, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
except Exception:
    pass
PY
}

# 再走結果を GATE_RESULTS_JSON (JSON配列) へ追記する。
_append_gate_result() {
    local base="$1" disp="$2" verdict="$3" ran="$4"
    GATE_RESULTS_JSON="$(
        python3 - "$GATE_RESULTS_JSON" "$base" "$disp" "$verdict" "$ran" <<'PY'
import sys, json
arr = json.loads(sys.argv[1]) if sys.argv[1].strip() else []
arr.append({"base": sys.argv[2], "name": sys.argv[3], "verdict": sys.argv[4], "ran": sys.argv[5]})
print(json.dumps(arr, ensure_ascii=False))
PY
    )"
}

# --- 主要ゲート 1: 実 DB ログインスモーク (動作保証の核) ---
# CLI: runtime-login-smoke.sh <project_dir>  → .soloptilink/runtime-login-smoke.json
# base には接尾辞を付けない (run_gate 側で <base>-recert-results.json を組み立てる)。
run_gate "実DBログイン検証" "runtime-login-smoke" \
    "$FBP_DIR/runtime-login-smoke.sh" \
    "$SLD/runtime-login-smoke.json" \
    "$PROJECT_DIR" --no-setup

# --- 主要ゲート 2: ビルド/開発衛生 (本番ビルドが今も通るか) ---
# CLI: build-dev-hygiene-gate.sh check <project_dir> → .soloptilink/build-dev-hygiene.json
run_gate "ビルド衛生検証" "build-dev-hygiene" \
    "$FBP_DIR/build-dev-hygiene-gate.sh" \
    "$SLD/build-dev-hygiene.json" \
    check "$PROJECT_DIR" --no-server

echo ""

# ==============================================================================
# STEP 3: 証明書再発行 + recertified_at / vuln_summary / fingerprint 差分の追記
# ------------------------------------------------------------------------------
# 前回 certificate.json を退避 → quality-evidence-report.sh generate で再発行 →
# 新 certificate.json に recertified_at と vuln_summary を追記。前回が在れば
# fingerprint 差分 (前回→今回) も記録する。QER 不在時は最小 certificate.json を
# 自前生成して graceful degrade する。
# ==============================================================================
echo "── STEP 3 ── 品質証明書の再発行"

PREV_FINGERPRINT=""
if [[ -f "$CERT_PATH" ]]; then
    PREV_FINGERPRINT="$(
        python3 - "$CERT_PATH" <<'PY'
import sys, json
try:
    d = json.load(open(sys.argv[1], encoding="utf-8"))
    print(str(d.get("fingerprint", "")))
except Exception:
    print("")
PY
    )"
    # 前回証明書を退避 (差分検証・監査用)
    cp "$CERT_PATH" "$SLD/certificate.prev.json" 2>/dev/null || true
fi

QER_USED="no"
if [[ -f "$QER" ]]; then
    echo "   ▶ 品質証明書を再生成中 (品質証明書.html / certificate.json)..."
    # best-effort: 生成失敗しても全体は止めない。
    bash "$QER" generate "$PROJECT_DIR" >/dev/null 2>&1 && QER_USED="yes" || {
        echo "   ⚠ 品質証明書ジェネレータの実行に失敗 → 最小証明書で継続"
        QER_USED="no"
    }
else
    echo "   ⚠ 品質証明書ジェネレータが見つかりません → 最小 certificate.json を自前生成"
fi

# certificate.json への recertified_at / vuln_summary / fingerprint 差分 追記。
# QER 不在 or 生成失敗で certificate.json が無い場合は、再走ゲートだけから最小の
# certificate.json を組み立てる (graceful degrade)。
NEW_FINGERPRINT="$(
    python3 - "$CERT_PATH" "$RECERTIFIED_AT" "$VULN_CRITICAL" "$VULN_HIGH" "$VULN_STATUS" "$PREV_FINGERPRINT" "$RECERT_VERSION" "$GATE_RESULTS_JSON" <<'PY'
import sys, json, os, hashlib

cert_path   = sys.argv[1]
recert_at   = sys.argv[2]
v_crit      = int(sys.argv[3] or 0)
v_high      = int(sys.argv[4] or 0)
v_status    = sys.argv[5]
prev_fp     = sys.argv[6]
recert_ver  = sys.argv[7]
gate_results = json.loads(sys.argv[8]) if sys.argv[8].strip() else []

ALLOWED = ("PASS", "WARN", "FAIL", "BLOCK", "NA")

def sha256(s):
    return hashlib.sha256(s.encode("utf-8")).hexdigest()

cert = None
if os.path.isfile(cert_path):
    try:
        cert = json.load(open(cert_path, encoding="utf-8"))
    except Exception:
        cert = None

# QER が certificate.json を生成できなかった場合の最小フォールバック。
# 再走ゲートの verdict だけからハッシュ連鎖を組み (QER と同じ algo='sha256-chain-v1')、
# 改ざん検知可能な最小証明書を成立させる。PII は一切含めない。
if not isinstance(cert, dict):
    issued_at = recert_at
    pairs = sorted(
        ((g.get("base", ""), g.get("verdict", "NA")) for g in gate_results if g.get("ran") == "yes"),
        key=lambda x: x[0],
    )
    chain = [sha256("%s|%s" % (recert_ver, issued_at))]
    for name, verdict in pairs:
        chain.append(sha256("%s|%s=%s" % (chain[-1], name, verdict)))
    fingerprint = chain[-1]
    cert = {
        "schema": "soloptilink-cert/v1",
        "cert_id": "recert-" + sha256(issued_at + "|" + recert_ver)[:16],
        "version": recert_ver,
        "issued_at": issued_at,
        "gates": [
            {"name": g.get("name", g.get("base", "")),
             "verdict": (g.get("verdict") if g.get("verdict") in ALLOWED else "NA")}
            for g in gate_results if g.get("ran") == "yes"
        ],
        "evidence": {"agent_count": 0, "pages": 0, "models": 0},
        "hash_chain": chain,
        "fingerprint": fingerprint,
        "algo": "sha256-chain-v1",
        "verify_url": "/verify/%s" % fingerprint,
        "minimal_fallback": True,
    }

new_fp = str(cert.get("fingerprint", ""))

# --- 月次再認証メタの追記 (PIIなし) ---
cert["recertified_at"] = recert_at
cert["vuln_summary"] = {
    "critical": v_crit,
    "high": v_high,
    "scanned": (v_status == "scanned"),
    "scanned_at": recert_at,
}
# fingerprint 差分 (前回証明書が在った場合のみ)
if prev_fp:
    cert["fingerprint_diff"] = {
        "previous": prev_fp,
        "current": new_fp,
        "changed": (prev_fp != new_fp),
    }

os.makedirs(os.path.dirname(cert_path), exist_ok=True)
json.dump(cert, open(cert_path, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
print(new_fp)
PY
)"

echo "   ✅ certificate.json を更新 (recertified_at / vuln_summary 追記済)"
echo "      新フィンガープリント: ${NEW_FINGERPRINT:0:16}"
if [[ -n "$PREV_FINGERPRINT" ]]; then
    if [[ "$PREV_FINGERPRINT" == "$NEW_FINGERPRINT" ]]; then
        echo "      前回比: 変化なし (判定は前回と同一)"
    else
        echo "      前回比: 変化あり (${PREV_FINGERPRINT:0:16} → ${NEW_FINGERPRINT:0:16})"
    fi
fi
echo ""

# ==============================================================================
# STEP 4: サーバ登録 (best-effort)
# ------------------------------------------------------------------------------
# quality-evidence-report.sh register で発行記録 (PIIなし) を best-effort 送信。
# 送信失敗・QER 不在はいずれも黙殺し、全体は止めない。
# ==============================================================================
echo "── STEP 4 ── サーバ登録 (best-effort)"
REGISTERED="no"
if [[ -f "$QER" ]]; then
    bash "$QER" register "$PROJECT_DIR" >/dev/null 2>&1 && REGISTERED="yes" || REGISTERED="no"
    if [[ "$REGISTERED" == "yes" ]]; then
        echo "   ✅ 発行記録をサーバへ登録しました"
    else
        echo "   ℹ サーバ未到達のため登録はスキップ (証明書はローカルに発行済)"
    fi
else
    echo "   ℹ 登録ツールが無いため登録をスキップ"
fi
echo ""

# ==============================================================================
# 再認証サマリの保存 (PIIなし) + 日本語サマリ出力
# ==============================================================================
python3 - "$RECERT_SUMMARY" "$RECERTIFIED_AT" "$VULN_CRITICAL" "$VULN_HIGH" "$VULN_STATUS" \
    "$NEW_FINGERPRINT" "$PREV_FINGERPRINT" "$QER_USED" "$REGISTERED" "$GATE_RESULTS_JSON" <<'PY'
import sys, json
out = sys.argv[1]
summary = {
    "recertified_at": sys.argv[2],
    "vuln_summary": {
        "critical": int(sys.argv[3] or 0),
        "high": int(sys.argv[4] or 0),
        "scanned": (sys.argv[5] == "scanned"),
    },
    "fingerprint": sys.argv[6],
    "previous_fingerprint": sys.argv[7],
    "fingerprint_changed": (bool(sys.argv[7]) and sys.argv[7] != sys.argv[6]),
    "certificate_generator_used": (sys.argv[8] == "yes"),
    "server_registered": (sys.argv[9] == "yes"),
    "gates": json.loads(sys.argv[10]) if sys.argv[10].strip() else [],
}
try:
    json.dump(summary, open(out, "w", encoding="utf-8"), ensure_ascii=False, indent=2)
except Exception:
    pass
PY

# --- 日本語サマリ (PIIなし) ---
GATES_LINE="$(
    python3 - "$GATE_RESULTS_JSON" <<'PY'
import sys, json
arr = json.loads(sys.argv[1]) if sys.argv[1].strip() else []
ran = [g for g in arr if g.get("ran") == "yes"]
if not ran:
    print("(再走対象ゲートなし)")
else:
    print(" / ".join("%s=%s" % (g.get("name",""), g.get("verdict","NA")) for g in ran))
PY
)"

echo "════════════════════════════════════════════"
echo " 月次 Re-Certification 完了"
echo "════════════════════════════════════════════"
echo " 再認証日      : $RECERTIFIED_AT"
if [[ "$VULN_STATUS" == "scanned" ]]; then
    echo " 脆弱性件数    : critical=$VULN_CRITICAL / high=$VULN_HIGH"
else
    echo " 脆弱性件数    : スキャン未実施 (npm/package.json 無し等)"
fi
echo " 主要ゲート再走: $GATES_LINE"
echo " 新証明書FP    : ${NEW_FINGERPRINT:0:16}"
if [[ -n "$PREV_FINGERPRINT" ]]; then
    if [[ "$PREV_FINGERPRINT" == "$NEW_FINGERPRINT" ]]; then
        echo " 前回比        : 変化なし"
    else
        echo " 前回比        : 変化あり (${PREV_FINGERPRINT:0:16} → ${NEW_FINGERPRINT:0:16})"
    fi
else
    echo " 前回比        : 初回発行 (比較対象なし)"
fi
echo "════════════════════════════════════════════"
echo "「動く保証」を更新しました。月額継続課金の動作保証根拠として記録済みです。"

exit 0
