#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v379.0 - Industry Template: Manufacturing
# =============================================================================
# 製造業特化テンプレートエンジン。
# BOM管理/製造工程/品質管理/設備管理等の製造業必須コンポーネントを自動生成。
#
# All globals use the ITM_ prefix.
# =============================================================================

[[ -n "${_INDUSTRY_TEMPLATE_MANUFACTURING_LOADED:-}" ]] && return 0
_INDUSTRY_TEMPLATE_MANUFACTURING_LOADED=1

declare -g ITM_VERSION="379.0"
declare -g ITM_INITIALIZED=false
declare -g ITM_GENERATED_COUNT=0
declare -g ITM_BOM_GENERATED=false
declare -g ITM_PROCESS_GENERATED=false
declare -g ITM_QUALITY_GENERATED=false
declare -g ITM_EQUIPMENT_GENERATED=false
declare -g ENABLE_ITM="${ENABLE_ITM:-true}"

_itm_init() {
    ITM_INITIALIZED=true
    ITM_GENERATED_COUNT=0
    return 0
}

_itm_generate_manufacturing() {
    local project_dir="${1:-.}"
    [[ "$ITM_INITIALIZED" != "true" ]] && _itm_init

    echo -e "  ${CYAN:-\033[0;36m}[ITM]${NC:-\033[0m} 製造業テンプレート生成開始..." >&2

    _itm_generate_bom "$project_dir"
    _itm_generate_process "$project_dir"
    _itm_generate_quality "$project_dir"
    _itm_generate_equipment "$project_dir"

    echo -e "  ${GREEN:-\033[0;32m}[ITM]${NC:-\033[0m} 製造業テンプレート生成完了: ${ITM_GENERATED_COUNT}件" >&2
    return 0
}

_itm_generate_bom() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITM-BOM] BOM（部品表）管理テンプレート

### Prisma Schema
```prisma
model Product {
  id          String   @id @default(cuid())
  partNumber  String   @unique
  name        String
  description String?
  type        String   @default("finished")
  unit        String   @default("pcs")
  bomItems    BOMItem[] @relation("ParentProduct")
  usedIn      BOMItem[] @relation("ChildProduct")
  workOrders  WorkOrder[]
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}

model BOMItem {
  id           String  @id @default(cuid())
  parentId     String
  parent       Product @relation("ParentProduct", fields: [parentId], references: [id])
  childId      String
  child        Product @relation("ChildProduct", fields: [childId], references: [id])
  quantity     Float
  unit         String  @default("pcs")
  sortOrder    Int     @default(0)
  isAlternative Boolean @default(false)
  notes        String?
  @@unique([parentId, childId])
  @@index([parentId])
}
```

### BOM Tree Component
```tsx
'use client';
export function BOMTree({ productId }: { productId: string }) {
  const { data, isLoading } = useSWR(`/api/products/${productId}/bom`);
  if (isLoading) return <TreeSkeleton />;

  const renderItem = (item: BOMItem, depth: number = 0) => (
    <div key={item.id} style={{ marginLeft: depth * 24 }} className="flex items-center gap-2 py-1 border-b">
      <ChevronRight className="h-4 w-4" />
      <span className="font-mono text-sm">{item.child.partNumber}</span>
      <span>{item.child.name}</span>
      <span className="text-muted-foreground ml-auto">{item.quantity} {item.unit}</span>
    </div>
  );

  return (
    <div className="border rounded-lg p-4">
      <h3 className="font-bold mb-2">BOM構成</h3>
      {data?.bomItems?.map((item: BOMItem) => renderItem(item, 0))}
    </div>
  );
}
```

### BOM Cost Calculator
```typescript
export async function calculateBOMCost(productId: string, quantity: number = 1): Promise<BOMCostResult> {
  const bomItems = await prisma.bOMItem.findMany({
    where: { parentId: productId },
    include: { child: true },
  });
  let totalMaterialCost = 0;
  const breakdown: CostBreakdown[] = [];
  for (const item of bomItems) {
    const unitCost = await getLatestPurchasePrice(item.childId);
    const itemCost = unitCost * item.quantity * quantity;
    totalMaterialCost += itemCost;
    breakdown.push({ partNumber: item.child.partNumber, name: item.child.name, quantity: item.quantity * quantity, unitCost, totalCost: itemCost });
  }
  return { productId, quantity, totalMaterialCost, breakdown };
}
```
TEMPLATE

    ITM_BOM_GENERATED=true
    ITM_GENERATED_COUNT=$((ITM_GENERATED_COUNT + 1))
    return 0
}

_itm_generate_process() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITM-PROCESS] 製造工程管理テンプレート

### Schema
```prisma
model WorkOrder {
  id          String   @id @default(cuid())
  orderNumber String   @unique
  productId   String
  product     Product  @relation(fields: [productId], references: [id])
  quantity    Int
  status      String   @default("planned")
  priority    String   @default("normal")
  scheduledStart DateTime?
  scheduledEnd   DateTime?
  actualStart    DateTime?
  actualEnd      DateTime?
  steps       WorkOrderStep[]
  defects     QualityDefect[]
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  @@index([status])
}

model WorkOrderStep {
  id          String    @id @default(cuid())
  workOrderId String
  workOrder   WorkOrder @relation(fields: [workOrderId], references: [id])
  processName String
  equipmentId String?
  operatorId  String?
  status      String    @default("pending")
  sortOrder   Int
  startedAt   DateTime?
  completedAt DateTime?
  notes       String?
  @@index([workOrderId])
}
```

### Production Kanban
```tsx
'use client';
export function ProductionKanban() {
  const { data, mutate } = useSWR('/api/work-orders?view=kanban');
  const statuses = ['planned', 'in_progress', 'quality_check', 'completed'];
  const updateStatus = async (id: string, status: string) => {
    await fetch(`/api/work-orders/${id}/status`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) });
    mutate();
  };
  return (
    <div className="grid grid-cols-4 gap-4">
      {statuses.map(status => (
        <div key={status} className="bg-muted/50 rounded-lg p-3">
          <h3 className="font-bold mb-3">{statusLabels[status]}</h3>
          {data?.workOrders?.filter((wo: WorkOrder) => wo.status === status).map((wo: WorkOrder) => (
            <WorkOrderCard key={wo.id} workOrder={wo} onStatusChange={(s) => updateStatus(wo.id, s)} />
          ))}
        </div>
      ))}
    </div>
  );
}
```
TEMPLATE

    ITM_PROCESS_GENERATED=true
    ITM_GENERATED_COUNT=$((ITM_GENERATED_COUNT + 1))
    return 0
}

_itm_generate_quality() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITM-QUALITY] 品質管理テンプレート

### Schema
```prisma
model QualityInspection {
  id          String   @id @default(cuid())
  workOrderId String?
  productId   String
  type        String
  inspectorId String
  result      String   @default("pending")
  sampleSize  Int
  passCount   Int      @default(0)
  failCount   Int      @default(0)
  checkItems  Json
  notes       String?
  inspectedAt DateTime @default(now())
}

model QualityDefect {
  id          String   @id @default(cuid())
  workOrderId String
  workOrder   WorkOrder @relation(fields: [workOrderId], references: [id])
  type        String
  severity    String
  description String
  rootCause   String?
  corrective  String?
  status      String   @default("open")
  reportedAt  DateTime @default(now())
  resolvedAt  DateTime?
}
```

### Quality Dashboard
```typescript
export async function getQualityMetrics(period: { from: Date; to: Date }) {
  const inspections = await prisma.qualityInspection.findMany({
    where: { inspectedAt: { gte: period.from, lte: period.to } },
  });
  const total = inspections.length;
  const passed = inspections.filter(i => i.result === 'passed').length;
  const defects = await prisma.qualityDefect.count({
    where: { reportedAt: { gte: period.from, lte: period.to } },
  });
  return { totalInspections: total, passRate: total > 0 ? (passed / total) * 100 : 0, defectCount: defects, yieldRate: total > 0 ? ((total - defects) / total) * 100 : 0 };
}
```
TEMPLATE

    ITM_QUALITY_GENERATED=true
    ITM_GENERATED_COUNT=$((ITM_GENERATED_COUNT + 1))
    return 0
}

_itm_generate_equipment() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITM-EQUIPMENT] 設備管理テンプレート

### Schema
```prisma
model Equipment {
  id             String   @id @default(cuid())
  name           String
  code           String   @unique
  type           String
  manufacturer   String?
  model          String?
  serialNumber   String?
  location       String
  status         String   @default("operational")
  purchasedAt    DateTime?
  lastMaintenance DateTime?
  nextMaintenance DateTime?
  maintenanceLogs MaintenanceLog[]
}

model MaintenanceLog {
  id          String   @id @default(cuid())
  equipmentId String
  equipment   Equipment @relation(fields: [equipmentId], references: [id])
  type        String
  description String
  technicianId String?
  cost        Int?
  startedAt   DateTime
  completedAt DateTime?
  nextDueDate DateTime?
}
```
TEMPLATE

    ITM_EQUIPMENT_GENERATED=true
    ITM_GENERATED_COUNT=$((ITM_GENERATED_COUNT + 1))
    return 0
}

_itm_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Industry Template: Manufacturing v${ITM_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成テンプレート数 : ${ITM_GENERATED_COUNT}"
    echo -e "  BOM                : ${ITM_BOM_GENERATED}"
    echo -e "  Process            : ${ITM_PROCESS_GENERATED}"
    echo -e "  Quality            : ${ITM_QUALITY_GENERATED}"
    echo -e "  Equipment          : ${ITM_EQUIPMENT_GENERATED}"
}

_itm_score() {
    local score=30
    [[ "$ITM_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$ITM_BOM_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITM_PROCESS_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITM_QUALITY_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITM_EQUIPMENT_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "industry-template-manufacturing" \
    --version "379.0" \
    --description "製造業テンプレート（BOM/工程/品質/設備管理）" \
    --init "_itm_init" \
    --report "_itm_report" \
    --score "_itm_score" \
    --enable-var "ENABLE_ITM" \
    --cli-flags "--industry-manufacturing:--no-industry-manufacturing"
