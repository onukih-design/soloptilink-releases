#!/usr/bin/env bash
# =============================================================================
# dl-health-monitor.sh — Distribution Download Health Monitor (v2027.3)
# =============================================================================
# 24 時間ごとに本番のダウンロード経路をエンドツーエンド検証し、
# PFP-023 (DL HTML 偽装事故) の予兆を構造的に検知する。
#
# やること:
#   1. peed-dl-flow-realverify.sh check を実行 (B11-B14)
#   2. 結果を JSONL に追記 (~/.soloptilink/lib/cognitive/data/peed-dl/health.log)
#   3. verdict=NO-GO なら以下を発火:
#      a. ローカル alert ログに critical 記録
#      b. オプション: Resend API でメール通知 (DL_MONITOR_NOTIFY_EMAIL 設定時)
#   4. 過去 7 日連続 PASS なら "healthy_streak" メトリクス更新
#
# 起動方法 (3 通り):
#   A. 手動: bash ~/.soloptilink/lib/dl-health-monitor.sh run
#   B. launchd (macOS): bash ~/.soloptilink/lib/dl-health-monitor.sh install-launchd
#   C. cron (Linux): bash ~/.soloptilink/lib/dl-health-monitor.sh install-cron
#
# 設計哲学:
#   * 本スクリプトは admin-dashboard の本番 URL に対して**読み取り専用**操作のみ行う
#     (DL リンク発行や DB 更新は一切しない)
#   * 失敗を「黙って蓄積」せず、人間に届くチャネルで通知する
#   * cron / launchd 設定は「インストールコマンド」を提供 — 手動 crontab 編集不要
# =============================================================================
set -euo pipefail

DLHM_HOME="${DLHM_HOME:-$HOME/.soloptilink/lib/cognitive/data/peed-dl}"
mkdir -p "$DLHM_HOME"
HEALTH_LOG="$DLHM_HOME/health.log"
ALERT_LOG="$DLHM_HOME/alert.log"
STREAK_FILE="$DLHM_HOME/healthy_streak.json"
LAUNCHD_LABEL="com.soloptilink.dl-health-monitor"
LAUNCHD_PLIST="$HOME/Library/LaunchAgents/${LAUNCHD_LABEL}.plist"
PEED_DL_RV="$HOME/.soloptilink/lib/cognitive/peed-dl-flow-realverify.sh"

cmd_run() {
  local now ts result verdict
  now=$(date -u +%Y-%m-%dT%H:%M:%SZ)
  ts=$(date +%Y%m%d-%H%M%S)

  if [[ ! -x "$PEED_DL_RV" ]]; then
    echo '{"error":"peed-dl-flow-realverify.sh not found or not executable","path":"'"$PEED_DL_RV"'"}' >&2
    return 1
  fi

  # 実走 (B11 含むので最大 ~60s)
  result=$("$PEED_DL_RV" check 2>/dev/null || echo '{"verdict":"NO-GO","fail_axes":["EXEC_ERROR"],"summary":"check execution failed"}')

  # JSONL に 1 行追記
  python3 - "$result" "$HEALTH_LOG" "$now" <<'PY'
import json, sys, os
res, log_path, ts = sys.argv[1], sys.argv[2], sys.argv[3]
try:
    obj = json.loads(res)
except Exception:
    obj = {"verdict": "NO-GO", "fail_axes": ["INVALID_JSON"], "raw": res}
obj["_recorded_at"] = ts
with open(log_path, "a", encoding="utf-8") as f:
    f.write(json.dumps(obj, ensure_ascii=False) + "\n")
print(obj.get("verdict", "UNKNOWN"))
PY
  verdict=$(python3 -c "import json,sys;print(json.loads(sys.argv[1]).get('verdict','UNKNOWN'))" "$result")

  # streak 更新
  python3 - "$STREAK_FILE" "$verdict" "$now" <<'PY'
import json, sys, os
streak_path, verdict, ts = sys.argv[1], sys.argv[2], sys.argv[3]
data = {"current_streak_days": 0, "last_pass_at": None, "last_fail_at": None, "total_runs": 0, "total_fails": 0}
if os.path.exists(streak_path):
    try:
        with open(streak_path, "r", encoding="utf-8") as f:
            data = {**data, **json.load(f)}
    except Exception:
        pass
data["total_runs"] += 1
if verdict == "GO":
    data["current_streak_days"] += 1
    data["last_pass_at"] = ts
else:
    data["current_streak_days"] = 0
    data["last_fail_at"] = ts
    data["total_fails"] += 1
with open(streak_path, "w", encoding="utf-8") as f:
    json.dump(data, f, ensure_ascii=False, indent=2)
PY

  # NO-GO の場合は alert ログ + (任意) Resend 通知
  if [[ "$verdict" != "GO" ]]; then
    echo "[$now] CRITICAL DL Flow NO-GO — see $HEALTH_LOG (last line)" >> "$ALERT_LOG"
    cmd_send_alert "$result" "$now" || true
  fi

  echo "verdict=$verdict logged_to=$HEALTH_LOG"
}

cmd_send_alert() {
  local result_json="$1" timestamp="$2"
  # DL_MONITOR_NOTIFY_EMAIL が設定されている場合のみ送信
  if [[ -z "${DL_MONITOR_NOTIFY_EMAIL:-}" ]]; then
    echo "[skip notify] DL_MONITOR_NOTIFY_EMAIL not set" >&2
    return 0
  fi
  if [[ -z "${RESEND_API_KEY:-}" ]]; then
    # admin-dashboard の .env から取得を試みる
    local env_file="$HOME/Downloads/社内システム開発/クロードコード上位互換開発/SOLAI/soloptilink/admin-dashboard/.env.vercel.prod"
    if [[ -f "$env_file" ]]; then
      RESEND_API_KEY=$(grep '^RESEND_API_KEY' "$env_file" | cut -d'=' -f2 | tr -d '"\\\\n' | sed 's/n$//')
    fi
  fi
  if [[ -z "${RESEND_API_KEY:-}" ]]; then
    echo "[skip notify] RESEND_API_KEY unavailable" >&2
    return 0
  fi

  local fail_axes summary
  fail_axes=$(python3 -c "import json,sys;print(','.join(json.loads(sys.argv[1]).get('fail_axes',[])))" "$result_json")
  summary=$(python3 -c "import json,sys;print(json.loads(sys.argv[1]).get('summary',''))" "$result_json")

  local payload
  payload=$(python3 -c "
import json,sys
data={'from':'SoloptiLinkAI Monitor <noreply@soloptilink.com>','to':[sys.argv[1]],'subject':'[ALERT] DL Flow Health NO-GO ('+sys.argv[2]+')','html':'<h2>Distribution DL Flow NO-GO</h2><p>Failed axes: <b>'+sys.argv[3]+'</b></p><p>Summary: '+sys.argv[4]+'</p><pre style=\"font-size:11px;background:#f5f5f5;padding:10px;\">'+sys.argv[5][:3500].replace('<','&lt;')+'</pre>'}
print(json.dumps(data))
" "$DL_MONITOR_NOTIFY_EMAIL" "$timestamp" "$fail_axes" "$summary" "$result_json")

  curl -sS -X POST "https://api.resend.com/emails" \
    -H "Authorization: Bearer ${RESEND_API_KEY}" \
    -H "Content-Type: application/json" \
    -d "$payload" \
    -o "$DLHM_HOME/last_notify_response.json" \
    -w "[notify] http=%{http_code}\n" >&2 || true
}

cmd_status() {
  if [[ -f "$STREAK_FILE" ]]; then
    cat "$STREAK_FILE"
  else
    echo '{"current_streak_days":0,"total_runs":0,"note":"No runs yet — execute: dl-health-monitor.sh run"}'
  fi
}

cmd_install_launchd() {
  cat >"$LAUNCHD_PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>${LAUNCHD_LABEL}</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/bash</string>
    <string>${HOME}/.soloptilink/lib/dl-health-monitor.sh</string>
    <string>run</string>
  </array>
  <key>StartCalendarInterval</key>
  <dict>
    <key>Hour</key><integer>9</integer>
    <key>Minute</key><integer>30</integer>
  </dict>
  <key>StandardOutPath</key>
  <string>${DLHM_HOME}/launchd.stdout.log</string>
  <key>StandardErrorPath</key>
  <string>${DLHM_HOME}/launchd.stderr.log</string>
  <key>RunAtLoad</key><false/>
</dict>
</plist>
EOF
  echo "Created plist: $LAUNCHD_PLIST"
  echo "Activate: launchctl load -w $LAUNCHD_PLIST"
  echo "Verify:   launchctl list | grep $LAUNCHD_LABEL"
  echo "Disable:  launchctl unload -w $LAUNCHD_PLIST"
  echo ""
  echo "(This skeleton schedules 09:30 daily. Adjust StartCalendarInterval as needed.)"
}

cmd_install_cron() {
  cat <<EOF
# Add this line to crontab (crontab -e):
30 9 * * * /bin/bash $HOME/.soloptilink/lib/dl-health-monitor.sh run >> $DLHM_HOME/cron.log 2>&1

# Optional: enable email notification
# 30 9 * * * DL_MONITOR_NOTIFY_EMAIL=admin@example.com /bin/bash $HOME/.soloptilink/lib/dl-health-monitor.sh run >> $DLHM_HOME/cron.log 2>&1
EOF
}

case "${1:-help}" in
  run|check)        cmd_run ;;
  status)           cmd_status ;;
  install-launchd)  cmd_install_launchd ;;
  install-cron)     cmd_install_cron ;;
  *) cat <<USG
dl-health-monitor.sh v2027.3 (24h health monitor for distribution flow)

Usage:
  $0 run                # 1 回実行 (B11-B14 PEED 経由)
  $0 status             # streak / total_runs / total_fails
  $0 install-launchd    # macOS launchd plist 生成 (毎日 09:30)
  $0 install-cron       # Linux crontab 設定例を表示

Environment:
  DL_MONITOR_NOTIFY_EMAIL  # NO-GO 時のメール通知先 (任意)
  RESEND_API_KEY           # メール送信用 (任意。未設定時は admin-dashboard/.env から自動取得を試行)

Files:
  $HEALTH_LOG       # JSONL run log
  $ALERT_LOG        # critical alerts
  $STREAK_FILE      # current/total stats
USG
  exit 0;;
esac
