#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v103.0 - Test Feedback Loop
# テスト結果→修正プロンプト→AI修正→再テストの自動ループ
#
# Runtime Test / E2E / Migration の結果を集約し、
# 最も効果的な修正プロンプトを生成してmulti-turn-engineに渡す。
# 修正結果はerror-intelligenceに自動学習される。
# ============================================================

[[ -n "${_TFL_LOADED:-}" ]] && return 0
_TFL_LOADED=1

TFL_VERSION="103.0"
TFL_INITIALIZED=false
TFL_MAX_CORRECTION_CYCLES=3   # 最大修正サイクル
TFL_CYCLE_COUNT=0

# --- 統計 ---
TFL_TOTAL_CORRECTIONS=0
TFL_SUCCESSFUL_CORRECTIONS=0

# ============================================================
# 初期化
# ============================================================
tfl_init() {
    TFL_CYCLE_COUNT=0
    TFL_TOTAL_CORRECTIONS=0
    TFL_SUCCESSFUL_CORRECTIONS=0
    TFL_INITIALIZED=true
    return 0
}

# ============================================================
# メイン: テスト→修正→再テストループ
# ============================================================
tfl_execute() {
    local project_dir="$1"
    local phase="${2:-implementation}"

    tfl_init
    echo -e "  🔄 [TFL] Test Feedback Loop v${TFL_VERSION} 開始" >&2

    local cycle=0
    while [[ $cycle -lt $TFL_MAX_CORRECTION_CYCLES ]]; do
        cycle=$((cycle + 1))
        TFL_CYCLE_COUNT=$cycle
        echo -e "  🔄 [TFL] サイクル ${cycle}/${TFL_MAX_CORRECTION_CYCLES}" >&2

        # --- 全テスト実行 ---
        local all_errors=""

        # 1. Real Validator (コンパイル)
        if type -t rv_validate_project &>/dev/null; then
            rv_init 2>/dev/null
            local rv_result
            rv_result=$(rv_validate_project "$project_dir" 2>/dev/null || echo "")
            [[ -n "$rv_result" ]] && all_errors+="$rv_result
"
        fi

        # 2. Migration Test
        if type -t mgt_run &>/dev/null; then
            if ! mgt_run "$project_dir" 2>/dev/null; then
                local mgt_report
                mgt_report=$(mgt_build_report 2>/dev/null)
                [[ -n "$mgt_report" ]] && all_errors+="$mgt_report
"
            fi
        fi

        # 3. Live Verification (統合検証)
        if type -t lv_verify_integration &>/dev/null; then
            lv_init 2>/dev/null
            local lv_result
            lv_result=$(lv_verify_integration "$project_dir" 2>/dev/null || echo "")
            [[ -n "$lv_result" ]] && [[ "$lv_result" == *"Critical"* || "$lv_result" == *"整合性"* ]] && all_errors+="$lv_result
"
        fi

        # 4. Runtime Test（サーバー起動テスト）
        if type -t rte_run &>/dev/null; then
            if ! rte_run "$project_dir" 2>/dev/null; then
                [[ -n "$RTE_RESULTS" ]] && all_errors+="$RTE_RESULTS
"
            fi
        fi

        # --- エラーなし → 成功 ---
        if [[ -z "$all_errors" ]] || [[ "$all_errors" =~ ^[[:space:]]*$ ]]; then
            echo -e "  ✅ [TFL] 全テスト通過 (サイクル${cycle})" >&2
            return 0
        fi

        # --- 修正プロンプト生成 ---
        local fix_prompt
        fix_prompt=$(_tfl_generate_fix_prompt "$all_errors" "$project_dir")

        # --- AI修正実行 ---
        echo -e "  🔧 [TFL] AI修正実行中..." >&2
        TFL_TOTAL_CORRECTIONS=$((TFL_TOTAL_CORRECTIONS + 1))

        local fix_result=""
        if type -t ai_call &>/dev/null; then
            fix_result=$(ai_call "$fix_prompt" "" "$phase" "${DOMAIN_TYPE:-general}" 2>/dev/null)
        elif type -t cb2_call &>/dev/null; then
            fix_result=$(cb2_call "$fix_prompt" "" "$phase" "${DOMAIN_TYPE:-general}" 2>/dev/null)
        fi

        if [[ -n "$fix_result" ]]; then
            # 修正結果をファイルに書き込み
            if type -t _write_claude_output_to_files &>/dev/null; then
                echo "$fix_result" | _write_claude_output_to_files "$project_dir" 2>/dev/null
            fi
        else
            echo -e "  ⚠️ [TFL] AI修正結果が空 → ループ終了" >&2
            break
        fi

        # --- エラーパターンを学習 ---
        _tfl_learn_from_errors "$all_errors"
    done

    echo -e "  📊 [TFL] 完了: ${TFL_TOTAL_CORRECTIONS}回修正, ${TFL_SUCCESSFUL_CORRECTIONS}回成功" >&2

    # 最終サイクルでもエラーがあれば失敗
    return 1
}

# ============================================================
# 修正プロンプト生成（優先度付き）
# ============================================================
_tfl_generate_fix_prompt() {
    local errors="$1"
    local project_dir="$2"

    # エラーを優先度でソート
    local critical="" high="" medium=""

    # コンパイルエラー = critical
    if echo "$errors" | grep -q "TypeScriptコンパイルエラー\|Prismaスキーマエラー\|MIGRATION_FAILED"; then
        critical=$(echo "$errors" | grep -A5 "TypeScriptコンパイル\|Prismaスキーマ\|MIGRATION_FAILED")
    fi

    # ランタイムエラー = high
    if echo "$errors" | grep -q "SERVER_START_FAILED\|API_SERVER_ERROR\|500"; then
        high=$(echo "$errors" | grep -A3 "SERVER_START\|SERVER_ERROR\|500")
    fi

    # 統合エラー = medium
    if echo "$errors" | grep -q "整合性\|Schema.*API\|型不一致"; then
        medium=$(echo "$errors" | grep -A3 "整合性\|Schema.*API\|型不一致")
    fi

    local prompt="以下のテスト結果に基づいてコードを修正してください。
**優先順位順に修正してください。**

"

    if [[ -n "$critical" ]]; then
        prompt+="## 🔴 CRITICAL（最優先で修正）
${critical}

"
    fi

    if [[ -n "$high" ]]; then
        prompt+="## 🟠 HIGH（次に修正）
${high}

"
    fi

    if [[ -n "$medium" ]]; then
        prompt+="## 🟡 MEDIUM
${medium}

"
    fi

    # 過去の学習から予防ルールも注入
    if type -t ei_build_prevention_prompt &>/dev/null; then
        local prevention
        prevention=$(ei_build_prevention_prompt "${DOMAIN_TYPE:-all}" 2>/dev/null)
        if [[ -n "$prevention" ]]; then
            prompt+="## 既知の注意事項
${prevention}

"
        fi
    fi

    prompt+="## 修正ルール
- ファイルマーカー（--- FILE: path ---）を維持してください
- 型エラーはanyではなく正しい型で解決
- 環境変数は.envと.env.exampleの両方に定義
- APIルートはapp/api/パスに正確に配置"

    echo "$prompt"
}

# ============================================================
# エラーパターン学習
# ============================================================
_tfl_learn_from_errors() {
    local errors="$1"

    if ! type -t ei_record_error &>/dev/null; then
        return
    fi

    # 各エラータイプを学習
    if echo "$errors" | grep -q "SERVER_START_FAILED"; then
        ei_record_error "server_start_fail" "npm run dev/startが起動しない" "all" 2>/dev/null || true
    fi
    if echo "$errors" | grep -q "API_SERVER_ERROR.*500"; then
        ei_record_error "api_500_error" "APIルートが500エラーを返す" "all" 2>/dev/null || true
    fi
    if echo "$errors" | grep -q "MIGRATION_FAILED"; then
        ei_record_error "migration_fail" "prisma db pushが失敗する" "all" 2>/dev/null || true
    fi
    if echo "$errors" | grep -q "PAGE_ERROR.*500"; then
        ei_record_error "page_500" "ページが500エラーを返す" "all" 2>/dev/null || true
    fi
}

# ============================================================
# レポート
# ============================================================
tfl_report() {
    echo "=== Test Feedback Loop v${TFL_VERSION} ==="
    echo "  Cycles: ${TFL_CYCLE_COUNT}/${TFL_MAX_CORRECTION_CYCLES}"
    echo "  Corrections: ${TFL_TOTAL_CORRECTIONS} (Success: ${TFL_SUCCESSFUL_CORRECTIONS})"
}

tfl_score() {
    if [[ $TFL_TOTAL_CORRECTIONS -eq 0 ]]; then
        echo "80"
        return
    fi
    echo "$(( (TFL_SUCCESSFUL_CORRECTIONS * 100) / TFL_TOTAL_CORRECTIONS ))"
}

# Module Registry
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "test-feedback-loop" \
        --version "$TFL_VERSION" \
        --description "テスト→修正→再テストの自動ループ + エラーパターン学習" \
        --init "tfl_init" \
        --report "tfl_report" \
        --score "tfl_score" \
        --enable-var "ENABLE_TFL" \
        --cli-flags "--test-feedback:--no-test-feedback"
fi

# v2003.1: source時のexit codeを確実に0にする
true
