#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2016.0 - Route Inventory (RVG-1)
# =============================================================================
# プロジェクト内の全URL/HTTPメソッドを静的列挙し JSON 出力する。
# Next.js (App Router / Pages Router), Express, FastAPI, Flask に対応。
#
# 使用:
#   bash ~/.soloptilink/lib/route-inventory.sh <PROJECT_DIR> [OUTPUT_JSON]
#   → デフォルト出力: <PROJECT_DIR>/.rvg/routes.json
# 戻り値: 0=success, 1=invalid project, 2=no routes detected
# =============================================================================

[[ -n "${_ROUTE_INVENTORY_LOADED:-}" ]] && return 0
_ROUTE_INVENTORY_LOADED=1

readonly RI_VERSION="1.0.0"

# ============================================================
# Public: ri_collect <project_dir> [out_json]
# ============================================================
ri_collect() {
    local project_dir="${1:-.}"
    local out_json="${2:-${project_dir}/.rvg/routes.json}"

    if [[ ! -d "$project_dir" ]]; then
        echo "[route-inventory] ERROR: project dir not found: $project_dir" >&2
        return 1
    fi

    mkdir -p "$(dirname "$out_json")" 2>/dev/null

    local tmp
    tmp=$(mktemp)
    {
        echo '['
        local first=1
        local r
        while IFS= read -r r; do
            [[ -z "$r" ]] && continue
            [[ $first -eq 1 ]] && first=0 || echo ','
            echo -n "  $r"
        done < <(_ri_emit_all "$project_dir")
        echo ''
        echo ']'
    } > "$tmp"

    mv "$tmp" "$out_json"
    local count
    count=$(grep -c '"url"' "$out_json" 2>/dev/null || true)
    count=${count:-0}
    # grep -c は1行のみ返すが、念のため改行除去
    count="${count//[$'\n\r']/}"
    [[ "$count" =~ ^[0-9]+$ ]] || count=0
    echo "[route-inventory] $count routes collected → $out_json" >&2
    [[ "$count" -gt 0 ]] || return 2
    return 0
}

# ============================================================
# Internal aggregator
# ============================================================
_ri_emit_all() {
    local project_dir="$1"
    _ri_scan_next_app_router "$project_dir"
    _ri_scan_next_pages_router "$project_dir"
    _ri_scan_express_routes "$project_dir"
    _ri_scan_python_routes "$project_dir"
}

# ----------------------------------------------------------------
# Next.js App Router: app/**/page.tsx, app/**/route.ts
# ----------------------------------------------------------------
_ri_scan_next_app_router() {
    local pd="$1"
    local app_dir="${pd}/app"
    [[ -d "$app_dir" ]] || app_dir="${pd}/src/app"
    [[ -d "$app_dir" ]] || return 0

    # Pages: page.tsx / page.jsx / page.ts / page.js
    while IFS= read -r -d '' f; do
        local rel="${f#"${app_dir}"/}"
        local route_path
        route_path=$(_ri_normalize_app_path "$rel" "page")
        _ri_emit_route "page" "$route_path" "GET" "$f"
    done < <(find "$app_dir" -type f \( -name 'page.tsx' -o -name 'page.jsx' -o -name 'page.ts' -o -name 'page.js' \) -not -path '*/node_modules/*' -not -path '*/.next/*' -print0 2>/dev/null)

    # API routes: route.ts / route.js
    while IFS= read -r -d '' f; do
        local rel="${f#"${app_dir}"/}"
        local route_path
        route_path=$(_ri_normalize_app_path "$rel" "route")
        # Detect exported HTTP methods
        local methods
        methods=$(grep -oE 'export[[:space:]]+(async[[:space:]]+)?function[[:space:]]+(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)' "$f" 2>/dev/null \
            | grep -oE '(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)' | sort -u)
        if [[ -z "$methods" ]]; then
            # Fallback: also check `export const GET = ...`
            methods=$(grep -oE 'export[[:space:]]+const[[:space:]]+(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)' "$f" 2>/dev/null \
                | grep -oE '(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)' | sort -u)
        fi
        if [[ -z "$methods" ]]; then
            methods="GET"
        fi
        local m
        while IFS= read -r m; do
            [[ -z "$m" ]] && continue
            _ri_emit_route "api" "$route_path" "$m" "$f"
        done <<< "$methods"
    done < <(find "$app_dir" -type f \( -name 'route.ts' -o -name 'route.js' \) -not -path '*/node_modules/*' -not -path '*/.next/*' -print0 2>/dev/null)
}

# Normalize Next.js App Router path: turn "(group)/users/[id]/page.tsx" into "/users/:id"
_ri_normalize_app_path() {
    local rel="$1"
    local kind="$2"
    # Strip the trailing /page.tsx or /route.ts
    local dir="${rel%/${kind}.*}"
    [[ "$dir" == "$rel" ]] && dir=""
    # Drop route groups: "(marketing)" segments
    local IFS='/' parts=()
    read -r -a parts <<< "$dir"
    local out=""
    local p
    for p in "${parts[@]}"; do
        [[ -z "$p" ]] && continue
        # Skip route groups like (auth)
        if [[ "$p" =~ ^\(.+\)$ ]]; then continue; fi
        # Convert dynamic segment [id] → :id, [...slug] → *
        if [[ "$p" =~ ^\[\.\.\.(.+)\]$ ]]; then
            out+="/*"
        elif [[ "$p" =~ ^\[(.+)\]$ ]]; then
            out+="/:${BASH_REMATCH[1]}"
        else
            out+="/${p}"
        fi
    done
    [[ -z "$out" ]] && out="/"
    echo "$out"
}

# ----------------------------------------------------------------
# Next.js Pages Router: pages/**/*.tsx
# ----------------------------------------------------------------
_ri_scan_next_pages_router() {
    local pd="$1"
    local pages_dir="${pd}/pages"
    [[ -d "$pages_dir" ]] || pages_dir="${pd}/src/pages"
    [[ -d "$pages_dir" ]] || return 0

    while IFS= read -r -d '' f; do
        local rel="${f#"${pages_dir}"/}"
        # Skip _app, _document, _error, api/_*
        case "$rel" in
            _app.*|_document.*|_error.*|404.*|500.*) continue ;;
        esac
        # Strip extension
        local p="${rel%.*}"
        [[ "$p" == "index" ]] && p=""
        p="${p%/index}"
        # Convert [id] → :id
        local out=""
        local IFS='/' parts=()
        read -r -a parts <<< "$p"
        local seg
        for seg in "${parts[@]}"; do
            [[ -z "$seg" ]] && continue
            if [[ "$seg" =~ ^\[\.\.\.(.+)\]$ ]]; then
                out+="/*"
            elif [[ "$seg" =~ ^\[(.+)\]$ ]]; then
                out+="/:${BASH_REMATCH[1]}"
            else
                out+="/${seg}"
            fi
        done
        [[ -z "$out" ]] && out="/"

        local kind="page"
        [[ "$out" == /api/* ]] && kind="api"
        local methods="GET"
        if [[ "$kind" == "api" ]]; then
            methods=$(grep -oE 'req\.method\s*===?\s*[\"\x27](GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)[\"\x27]' "$f" 2>/dev/null \
                | grep -oE '(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)' | sort -u)
            [[ -z "$methods" ]] && methods="GET"
        fi
        local m
        while IFS= read -r m; do
            [[ -z "$m" ]] && continue
            _ri_emit_route "$kind" "$out" "$m" "$f"
        done <<< "$methods"
    done < <(find "$pages_dir" -type f \( -name '*.tsx' -o -name '*.jsx' -o -name '*.ts' -o -name '*.js' \) -not -path '*/node_modules/*' -print0 2>/dev/null)
}

# ----------------------------------------------------------------
# Express routes: app.get / router.post etc
# ----------------------------------------------------------------
_ri_scan_express_routes() {
    local pd="$1"
    local files
    files=$(grep -rEl --include='*.js' --include='*.ts' --include='*.mjs' \
        --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=dist \
        '(router|app)\.(get|post|put|patch|delete|head|options)\s*\(' "$pd" 2>/dev/null)
    [[ -z "$files" ]] && return 0
    local f
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        # Capture: app.get('/foo', ...) or router.post("/bar/:id", ...)
        grep -oE '(router|app)\.(get|post|put|patch|delete|head|options)\s*\(\s*[\x27\"][^\x27\"]+[\x27\"]' "$f" 2>/dev/null | while IFS= read -r line; do
            local method url
            method=$(echo "$line" | grep -oE '\.(get|post|put|patch|delete|head|options)' | head -1 | tr -d '.' | tr 'a-z' 'A-Z')
            url=$(echo "$line" | grep -oE '[\x27\"][^\x27\"]+[\x27\"]' | head -1 | tr -d '"' | tr -d "'")
            [[ -z "$url" || -z "$method" ]] && continue
            _ri_emit_route "api" "$url" "$method" "$f"
        done
    done <<< "$files"
}

# ----------------------------------------------------------------
# Python routes: FastAPI / Flask
# ----------------------------------------------------------------
_ri_scan_python_routes() {
    local pd="$1"
    local files
    files=$(grep -rEl --include='*.py' --exclude-dir=__pycache__ --exclude-dir=.venv --exclude-dir=venv \
        '@(app|router)\.(get|post|put|patch|delete|head|options|route)' "$pd" 2>/dev/null)
    [[ -z "$files" ]] && return 0
    local f
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        # FastAPI / Flask decorator
        grep -oE '@(app|router)\.(get|post|put|patch|delete|head|options|route)\s*\(\s*[\x27\"][^\x27\"]+[\x27\"]' "$f" 2>/dev/null | while IFS= read -r line; do
            local method url
            method=$(echo "$line" | grep -oE '\.(get|post|put|patch|delete|head|options|route)' | head -1 | tr -d '.' | tr 'a-z' 'A-Z')
            [[ "$method" == "ROUTE" ]] && method="GET"
            url=$(echo "$line" | grep -oE '[\x27\"][^\x27\"]+[\x27\"]' | head -1 | tr -d '"' | tr -d "'")
            [[ -z "$url" || -z "$method" ]] && continue
            # FastAPI dynamic: /users/{id} → /users/:id
            url=$(echo "$url" | sed -E 's/\{([^}]+)\}/:\1/g')
            _ri_emit_route "api" "$url" "$method" "$f"
        done
    done <<< "$files"
}

# ============================================================
# Emit one JSON record
# ============================================================
_ri_emit_route() {
    local kind="$1"
    local url="$2"
    local method="$3"
    local file="$4"
    local rel_file="${file#"$(pwd)"/}"
    # Escape minimal JSON characters
    rel_file="${rel_file//\\/\\\\}"
    rel_file="${rel_file//\"/\\\"}"
    url="${url//\\/\\\\}"
    url="${url//\"/\\\"}"
    printf '{"kind":"%s","url":"%s","method":"%s","file":"%s"}\n' "$kind" "$url" "$method" "$rel_file"
}

# ============================================================
# CLI entry
# ============================================================
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    ri_collect "${1:-$(pwd)}" "${2:-}"
    exit $?
fi
