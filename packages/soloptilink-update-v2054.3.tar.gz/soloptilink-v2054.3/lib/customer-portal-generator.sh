#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v302.0 - Customer Portal Generator
# =============================================================================
# ドメイン特化: カスタマーポータル自動生成
# ポータルレイアウト、ダッシュボード、サポートチケット、請求履歴を自動生成。
#
# 全globals: CPG_ prefix
# =============================================================================

[[ -n "${_CUSTOMER_PORTAL_GENERATOR_LOADED:-}" ]] && return 0
_CUSTOMER_PORTAL_GENERATOR_LOADED=1

declare -g CPG_VERSION="302.0"
declare -g CPG_INITIALIZED=false
declare -g CPG_GENERATED_COUNT=0
declare -g ENABLE_CUSTOMER_PORTAL_GENERATOR="${ENABLE_CUSTOMER_PORTAL_GENERATOR:-true}"

readonly CPG_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly CPG_YELLOW="${CLR_YELLOW:-\033[0;33m}"
readonly CPG_RED="${CLR_RED:-\033[0;31m}"
readonly CPG_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly CPG_BOLD="${CLR_BOLD:-\033[1m}"
readonly CPG_NC="${CLR_NC:-\033[0m}"

_cpg_log() { echo -e "  ${CPG_CYAN}[CPG]${CPG_NC} $*" >&2; }
_cpg_ok()  { echo -e "  ${CPG_GREEN}[CPG] OK${CPG_NC} $*" >&2; }
_cpg_warn(){ echo -e "  ${CPG_YELLOW}[CPG] WARN${CPG_NC} $*" >&2; }
_cpg_err() { echo -e "  ${CPG_RED}[CPG] ERR${CPG_NC} $*" >&2; }

cpg_init() {
    CPG_INITIALIZED=true
    CPG_GENERATED_COUNT=0
    return 0
}

cpg_report() {
    [[ "$CPG_INITIALIZED" != "true" ]] && return 0
    echo -e "\n  ${CPG_BOLD}--- Customer Portal Generator v${CPG_VERSION} ---${CPG_NC}" >&2
    echo -e "  生成コンポーネント数: ${CPG_GENERATED_COUNT}" >&2
}

cpg_score() {
    [[ "$CPG_INITIALIZED" != "true" ]] && { echo "0"; return; }
    local score=50
    [[ ${CPG_GENERATED_COUNT} -ge 3 ]] && score=80
    [[ ${CPG_GENERATED_COUNT} -ge 6 ]] && score=95
    echo "$score"
}

cpg_init_message() {
    echo -e "  ${CPG_GREEN}v${CPG_VERSION} customer-portal-generator: カスタマーポータル自動生成${CPG_NC}" >&2
}

# =============================================================================
# _cpg_generate_portal_layout() - Customer portal layout
# =============================================================================
_cpg_generate_portal_layout() {
    local project_dir="${1:-.}"
    _cpg_log "ポータルレイアウト生成"

    local comp_dir="${project_dir}/src/components/portal"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/PortalLayout.tsx" <<'EOF'
'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Home, HelpCircle, CreditCard, Settings, LogOut, Menu, X } from 'lucide-react';
import { useState } from 'react';

const navItems = [
  { label: 'ダッシュボード', href: '/portal', icon: <Home size={18} /> },
  { label: 'サポート', href: '/portal/support', icon: <HelpCircle size={18} /> },
  { label: '請求', href: '/portal/billing', icon: <CreditCard size={18} /> },
  { label: '設定', href: '/portal/settings', icon: <Settings size={18} /> },
];

export function PortalLayout({ children }: { children: React.ReactNode }) {
  const pathname = usePathname();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <div className="min-h-screen bg-gray-50">
      <header className="bg-white shadow-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/portal" className="text-xl font-bold text-blue-600">MyPortal</Link>
            <nav className="hidden md:flex items-center gap-1">
              {navItems.map(item => (
                <Link key={item.href} href={item.href}
                  className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm ${
                    pathname === item.href ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-600 hover:bg-gray-50'
                  }`}>
                  {item.icon} {item.label}
                </Link>
              ))}
            </nav>
            <div className="flex items-center gap-4">
              <button className="text-gray-600 hover:text-red-600 text-sm flex items-center gap-1"><LogOut size={16} /> ログアウト</button>
              <button className="md:hidden" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
                {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
              </button>
            </div>
          </div>
        </div>
        {mobileMenuOpen && (
          <nav className="md:hidden border-t px-4 py-2 space-y-1 bg-white">
            {navItems.map(item => (
              <Link key={item.href} href={item.href} onClick={() => setMobileMenuOpen(false)}
                className="flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-gray-600 hover:bg-gray-50">
                {item.icon} {item.label}
              </Link>
            ))}
          </nav>
        )}
      </header>
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">{children}</main>
    </div>
  );
}
EOF

    CPG_GENERATED_COUNT=$((CPG_GENERATED_COUNT + 1))
    _cpg_ok "ポータルレイアウト生成完了"
    return 0
}

# =============================================================================
# _cpg_generate_dashboard() - Customer dashboard
# =============================================================================
_cpg_generate_dashboard() {
    local project_dir="${1:-.}"
    _cpg_log "カスタマーダッシュボード生成"

    local page_dir="${project_dir}/src/app/portal"
    mkdir -p "$page_dir"

    cat > "${page_dir}/page.tsx" <<'EOF'
'use client';
import useSWR from 'swr';
import { PortalLayout } from '@/components/portal/PortalLayout';
import { FileText, HelpCircle, CreditCard, ArrowRight } from 'lucide-react';
import Link from 'next/link';

const fetcher = (url: string) => fetch(url).then(r => r.json());

export default function PortalDashboard() {
  const { data, isLoading } = useSWR('/api/portal/dashboard', fetcher);

  const stats = [
    { label: 'アクティブプラン', value: data?.plan || '-', icon: <FileText size={20} />, color: 'blue' },
    { label: 'オープンチケット', value: data?.openTickets ?? '-', icon: <HelpCircle size={20} />, color: 'yellow' },
    { label: '今月の請求額', value: data?.currentBill ? `¥${data.currentBill.toLocaleString()}` : '-', icon: <CreditCard size={20} />, color: 'green' },
  ];

  return (
    <PortalLayout>
      <h1 className="text-2xl font-bold mb-6">ダッシュボード</h1>
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {[1,2,3].map(i => <div key={i} className="h-28 bg-gray-200 rounded-lg animate-pulse" />)}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          {stats.map(s => (
            <div key={s.label} className="bg-white rounded-lg shadow p-5">
              <div className="flex items-center gap-3 mb-2">
                <div className={`p-2 rounded-lg bg-${s.color}-50 text-${s.color}-600`}>{s.icon}</div>
                <span className="text-sm text-gray-500">{s.label}</span>
              </div>
              <p className="text-2xl font-bold">{s.value}</p>
            </div>
          ))}
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="bg-white rounded-lg shadow p-5">
          <h2 className="font-semibold mb-4">最近のアクティビティ</h2>
          {data?.recentActivity?.length > 0 ? (
            <ul className="space-y-3">
              {data.recentActivity.slice(0, 5).map((act: any, i: number) => (
                <li key={i} className="flex items-center gap-3 text-sm">
                  <span className="text-gray-400 text-xs w-20">{new Date(act.date).toLocaleDateString('ja-JP')}</span>
                  <span>{act.message}</span>
                </li>
              ))}
            </ul>
          ) : (
            <p className="text-gray-500 text-sm">アクティビティなし</p>
          )}
        </div>
        <div className="bg-white rounded-lg shadow p-5">
          <h2 className="font-semibold mb-4">クイックリンク</h2>
          <div className="space-y-2">
            {[
              { label: 'サポートに問い合わせ', href: '/portal/support/new' },
              { label: '請求履歴を確認', href: '/portal/billing' },
              { label: 'アカウント設定', href: '/portal/settings' },
            ].map(link => (
              <Link key={link.href} href={link.href}
                className="flex items-center justify-between p-3 rounded-lg border hover:bg-gray-50 text-sm">
                {link.label} <ArrowRight size={16} className="text-gray-400" />
              </Link>
            ))}
          </div>
        </div>
      </div>
    </PortalLayout>
  );
}
EOF

    CPG_GENERATED_COUNT=$((CPG_GENERATED_COUNT + 1))
    _cpg_ok "ダッシュボード生成完了"
    return 0
}

# =============================================================================
# _cpg_generate_support() - Support ticket system
# =============================================================================
_cpg_generate_support() {
    local project_dir="${1:-.}"
    _cpg_log "サポートチケットシステム生成"

    local support_dir="${project_dir}/src/app/portal/support"
    mkdir -p "${support_dir}/new" "${support_dir}/[id]"

    cat > "${support_dir}/page.tsx" <<'EOF'
'use client';
import useSWR from 'swr';
import { PortalLayout } from '@/components/portal/PortalLayout';
import Link from 'next/link';
import { Plus, Clock, CheckCircle, AlertCircle } from 'lucide-react';

const fetcher = (url: string) => fetch(url).then(r => r.json());
const statusIcon = (s: string) => s === 'open' ? <AlertCircle size={16} className="text-yellow-500" />
  : s === 'in_progress' ? <Clock size={16} className="text-blue-500" />
  : <CheckCircle size={16} className="text-green-500" />;

export default function SupportPage() {
  const { data, isLoading, error } = useSWR('/api/portal/tickets', fetcher);

  return (
    <PortalLayout>
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">サポート</h1>
        <Link href="/portal/support/new" className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 text-sm hover:bg-blue-700">
          <Plus size={16} /> 新規チケット
        </Link>
      </div>

      {isLoading && <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-20 bg-gray-200 rounded-lg animate-pulse" />)}</div>}
      {error && <p className="text-red-600">読み込みエラー</p>}
      {data?.data?.length === 0 && <p className="text-gray-500 text-center py-12">チケットはありません</p>}

      {data?.data && (
        <div className="space-y-3">
          {data.data.map((ticket: any) => (
            <Link key={ticket.id} href={`/portal/support/${ticket.id}`}
              className="block bg-white rounded-lg shadow p-4 hover:shadow-md transition-shadow">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  {statusIcon(ticket.status)}
                  <div>
                    <p className="font-medium">{ticket.subject}</p>
                    <p className="text-sm text-gray-500 mt-1">#{ticket.id} - {new Date(ticket.createdAt).toLocaleDateString('ja-JP')}</p>
                  </div>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${
                  ticket.priority === 'high' ? 'bg-red-100 text-red-700' :
                  ticket.priority === 'medium' ? 'bg-yellow-100 text-yellow-700' : 'bg-gray-100 text-gray-600'
                }`}>{ticket.priority}</span>
              </div>
            </Link>
          ))}
        </div>
      )}
    </PortalLayout>
  );
}
EOF

    cat > "${support_dir}/new/page.tsx" <<'EOF'
'use client';
import { useRouter } from 'next/navigation';
import { PortalLayout } from '@/components/portal/PortalLayout';
import { useState } from 'react';

export default function NewTicketPage() {
  const router = useRouter();
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    const fd = new FormData(e.currentTarget);
    try {
      const res = await fetch('/api/portal/tickets', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ subject: fd.get('subject'), body: fd.get('body'), priority: fd.get('priority') }),
      });
      if (!res.ok) throw new Error('送信に失敗');
      router.push('/portal/support');
    } catch (e: any) { setError(e.message); } finally { setSubmitting(false); }
  };

  return (
    <PortalLayout>
      <h1 className="text-2xl font-bold mb-6">新規チケット</h1>
      <div className="max-w-2xl bg-white rounded-lg shadow p-6">
        {error && <p className="text-red-600 mb-4">{error}</p>}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div><label className="block text-sm font-medium mb-1">件名</label>
            <input name="subject" required className="w-full border rounded-lg px-3 py-2" /></div>
          <div><label className="block text-sm font-medium mb-1">優先度</label>
            <select name="priority" className="w-full border rounded-lg px-3 py-2">
              <option value="low">低</option><option value="medium">中</option><option value="high">高</option>
            </select></div>
          <div><label className="block text-sm font-medium mb-1">内容</label>
            <textarea name="body" rows={6} required className="w-full border rounded-lg px-3 py-2" /></div>
          <div className="flex gap-3">
            <button type="submit" disabled={submitting} className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50">
              {submitting ? '送信中...' : '送信'}
            </button>
            <button type="button" onClick={() => router.back()} className="px-6 py-2 border rounded-lg hover:bg-gray-50">キャンセル</button>
          </div>
        </form>
      </div>
    </PortalLayout>
  );
}
EOF

    CPG_GENERATED_COUNT=$((CPG_GENERATED_COUNT + 2))
    _cpg_ok "サポートチケット生成完了"
    return 0
}

# =============================================================================
# _cpg_generate_billing_page() - Billing/invoice history
# =============================================================================
_cpg_generate_billing_page() {
    local project_dir="${1:-.}"
    _cpg_log "請求ページ生成"

    local billing_dir="${project_dir}/src/app/portal/billing"
    mkdir -p "$billing_dir"

    cat > "${billing_dir}/page.tsx" <<'EOF'
'use client';
import useSWR from 'swr';
import { PortalLayout } from '@/components/portal/PortalLayout';
import { Download, CreditCard, Calendar } from 'lucide-react';

const fetcher = (url: string) => fetch(url).then(r => r.json());

export default function BillingPage() {
  const { data, isLoading, error } = useSWR('/api/portal/billing', fetcher);

  return (
    <PortalLayout>
      <h1 className="text-2xl font-bold mb-6">請求・お支払い</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <div className="bg-white rounded-lg shadow p-5">
          <h2 className="text-sm text-gray-500 mb-2">現在のプラン</h2>
          <p className="text-xl font-bold">{data?.plan?.name || '-'}</p>
          <p className="text-gray-500 mt-1">¥{data?.plan?.price?.toLocaleString() || '-'}/月</p>
          <button className="mt-4 text-blue-600 text-sm hover:underline">プラン変更</button>
        </div>
        <div className="bg-white rounded-lg shadow p-5">
          <h2 className="text-sm text-gray-500 mb-2">支払い方法</h2>
          <div className="flex items-center gap-3">
            <CreditCard size={24} className="text-gray-400" />
            <div>
              <p className="font-medium">**** **** **** {data?.paymentMethod?.last4 || '****'}</p>
              <p className="text-xs text-gray-500">有効期限: {data?.paymentMethod?.expiry || '-'}</p>
            </div>
          </div>
          <button className="mt-4 text-blue-600 text-sm hover:underline">支払い方法変更</button>
        </div>
      </div>

      <h2 className="text-lg font-semibold mb-4">請求履歴</h2>
      {isLoading && <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-14 bg-gray-200 rounded animate-pulse" />)}</div>}
      {error && <p className="text-red-600">読み込みエラー</p>}

      {data?.invoices && (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="text-left px-4 py-3 font-medium">請求日</th>
                <th className="text-left px-4 py-3 font-medium">金額</th>
                <th className="text-left px-4 py-3 font-medium">ステータス</th>
                <th className="text-right px-4 py-3 font-medium">PDF</th>
              </tr>
            </thead>
            <tbody>
              {data.invoices.map((inv: any) => (
                <tr key={inv.id} className="border-b hover:bg-gray-50">
                  <td className="px-4 py-3 flex items-center gap-2"><Calendar size={14} className="text-gray-400" /> {new Date(inv.date).toLocaleDateString('ja-JP')}</td>
                  <td className="px-4 py-3 font-medium">¥{inv.amount?.toLocaleString()}</td>
                  <td className="px-4 py-3"><span className={`text-xs px-2 py-0.5 rounded-full ${inv.status === 'paid' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>{inv.status === 'paid' ? '支払済' : '未払'}</span></td>
                  <td className="px-4 py-3 text-right"><a href={inv.pdfUrl || '#'} className="text-blue-600 hover:underline inline-flex items-center gap-1"><Download size={14} /> PDF</a></td>
                </tr>
              ))}
            </tbody>
          </table>
          {data.invoices.length === 0 && <p className="text-center py-8 text-gray-500">請求履歴なし</p>}
        </div>
      )}
    </PortalLayout>
  );
}
EOF

    CPG_GENERATED_COUNT=$((CPG_GENERATED_COUNT + 1))
    _cpg_ok "請求ページ生成完了"
    return 0
}

# =============================================================================
# Module Registration
# =============================================================================
_mr_register \
    --name "customer-portal-generator" \
    --version "302.0" \
    --description "カスタマーポータル自動生成（ダッシュボード/サポート/請求）" \
    --init "cpg_init" \
    --report "cpg_report" \
    --score "cpg_score" \
    --enable-var "ENABLE_CUSTOMER_PORTAL_GENERATOR" \
    --cli-flags "--customer-portal:--no-customer-portal" \
    --init-msg "cpg_init_message"
