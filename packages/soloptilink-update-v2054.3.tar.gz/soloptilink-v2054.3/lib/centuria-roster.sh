#!/usr/bin/env bash
# ==============================================================================
# centuria-roster.sh — PFP-091 RPOG: 105エージェント「実在証明」の正規ロスター
#
# 役割:
#   「105エージェント (Centuria 100 + Executive 5)」という主張を、実在する役割
#   定義ファイル (~/.soloptilink/.claude/agents/*.md) と agent-scaler.sh の
#   レジストリから自動導出し、単一情報源 centuria-roster.json に固める。
#   → 手作業の filler ではなく「実ファイル由来」であることが本質。これにより
#     顧客 (例: 飛田さん) が「105体は実在するのか?」と問うたとき、ロスターと
#     各役割の定義ファイルを示して「実在する」と正直に答えられる。
#
# 使い方:
#   centuria-roster.sh build    # 実ファイルから roster を再導出
#   centuria-roster.sh show     # 105主張 vs 実在数 + ロール例を人間可読表示
#   centuria-roster.sh verify   # 実在数>=105 かつ全定義ファイル実在を検証 (exit 0/1)
#
# 出力: ~/.soloptilink/agents/centuria-roster.json
# 依存: python3
# ==============================================================================
set -euo pipefail
SL="$HOME/.soloptilink"
# 顧客端末では ~/.claude/agents のみ配信される ($SL/.claude/agents は管理者端末のみ存在)。
# 両環境対応: ~/.claude/agents を優先し、不在時のみ $SL/.claude/agents にフォールバック。
if ls "$HOME/.claude/agents/"*.md >/dev/null 2>&1; then
  AGENTS_DIR="$HOME/.claude/agents"
else
  AGENTS_DIR="$SL/.claude/agents"
fi
SCALER="$SL/agent-scaler.sh"
OUT="$SL/agents/centuria-roster.json"

_build() {
  mkdir -p "$SL/agents"
  AGENTS_DIR="$AGENTS_DIR" SCALER="$SCALER" OUT="$OUT" python3 - <<'PY'
import os, glob, re, json
ad = os.environ["AGENTS_DIR"]; scaler = os.environ["SCALER"]; out = os.environ["OUT"]

# --- agent-scaler.sh の AS_DEFAULT_AGENTS から specialties/tier/priority を抽出 ---
meta = {}
try:
    txt = open(scaler, encoding="utf-8", errors="ignore").read()
    m = re.search(r"AS_DEFAULT_AGENTS=\((.*?)\n\)", txt, re.S)
    block = m.group(1) if m else ""
    for mm in re.finditer(r'\[([a-z0-9\-]+)\]="([^"]+)"', block):
        aid, val = mm.group(1), mm.group(2)
        parts = val.split("|")
        meta[aid] = {
            "specialties": [s for s in parts[0].split(",") if s] if parts else [],
            "tier": parts[1] if len(parts) > 1 else "balanced",
            "priority": int(parts[4]) if len(parts) > 4 and parts[4].isdigit() else 5,
        }
except Exception:
    pass

def parse_md(path):
    title = ""; role = ""
    try:
        lines = open(path, encoding="utf-8", errors="ignore").read().splitlines()
    except Exception:
        return title, role
    for ln in lines:
        if ln.startswith("# "):
            title = ln[2:].strip(); break
    for i, ln in enumerate(lines):
        if ln.strip().startswith("## 役割"):
            for nxt in lines[i+1:i+6]:
                if nxt.strip():
                    role = nxt.strip(); break
            break
    return title, role

specialists = []
for f in sorted(glob.glob(os.path.join(ad, "*.md"))):
    aid = os.path.basename(f)[:-3]
    title, role = parse_md(f)
    m = meta.get(aid, {})
    specialists.append({
        "id": aid,
        "title": title or aid,
        "role_summary": role,
        "specialties": m.get("specialties", []),
        "model_tier": m.get("tier", "defined"),
        "definition_file": f.replace(os.path.expanduser("~"), "~"),
        "registered_in_scaler": aid in meta,
    })

# --- 役員 5 (Executive Cognitive Layer / soloptilink-executive C-suite に対応) ---
executives = [
    {"id": "ceo",  "title": "Chief Executive — 経営統括",       "mandate": "事業ゴール整合・優先順位付け・全体意思決定", "layer": "L21 Executive Cognitive"},
    {"id": "cfo",  "title": "Chief Financial — 財務統括",       "mandate": "コスト/予算/ROI・採算性の検証",            "layer": "L21 Executive Cognitive"},
    {"id": "coo",  "title": "Chief Operating — 実行統括",       "mandate": "Wave 進行・リソース配分・納期管理",         "layer": "L21 Executive Cognitive"},
    {"id": "cto",  "title": "Chief Technology — 技術統括",      "mandate": "アーキテクチャ決定・技術的負債・整合性",    "layer": "L21 Executive Cognitive"},
    {"id": "ciso", "title": "Chief Information Security — 情報セキュリティ統括", "mandate": "脅威モデル・規制対応・セキュリティ最終承認", "layer": "L21 Executive Cognitive"},
]

total = len(specialists) + len(executives)
doc = {
    "schema_version": 1,
    "pfp": "PFP-091",
    "generated_note": "実在する .claude/agents/*.md (役割定義) と agent-scaler.sh レジストリから自動導出。手作業の filler ではなく実ファイル由来。",
    "claimed_capacity": 105,
    "totals": {
        "specialists_defined": len(specialists),
        "executives_defined": len(executives),
        "total_defined": total,
        "claimed": 105,
        "claim_is_true": total >= 105,
    },
    "centuria_specialists": specialists,
    "executives": executives,
}
tmp = out + ".tmp"
with open(tmp, "w") as f:
    json.dump(doc, f, ensure_ascii=False, indent=2)
os.replace(tmp, out)   # atomic write (security-auditor ロール監査 L-2 対応)
print(f"[centuria-roster] specialists={len(specialists)} executives={len(executives)} "
      f"total={total} (claimed 105, true={doc['totals']['claim_is_true']})")
print(f"[centuria-roster] -> {out}")
PY
}

cmd="${1:-show}"
case "$cmd" in
  build) _build ;;
  show)
    [ -f "$OUT" ] || _build
    OUT="$OUT" python3 - <<'PY'
import os, json
d = json.load(open(os.environ["OUT"])); t = d["totals"]
print("=" * 64)
print("  SoloptiLinkAI — Centuria Roster (105エージェント実在証明)")
print("=" * 64)
print(f"  主張 (claimed)        : {t['claimed']} 体")
print(f"  実在定義 (defined)     : {t['total_defined']} 体 "
      f"(専門 {t['specialists_defined']} + 役員 {t['executives_defined']})")
print(f"  主張は真か (claim true): {t['claim_is_true']}  "
      f"※実在 {t['total_defined']} ≥ 主張 {t['claimed']}")
print("-" * 64)
print("  専門ロール例 (各々が実定義ファイルを持つ):")
for a in d["centuria_specialists"][:12]:
    reg = "★登録" if a["registered_in_scaler"] else "  定義"
    print(f"   {reg} {a['id']:<26} {a['title'][:32]}")
print(f"   … 他 {t['specialists_defined'] - 12} 専門ロール")
print("  役員ロール (Executive 5):")
for e in d["executives"]:
    print(f"   ◆ {e['id'].upper():<5} {e['title']}")
print("=" * 64)
PY
    ;;
  verify)
    [ -f "$OUT" ] || _build
    OUT="$OUT" python3 - <<'PY'
import os, json, sys
d = json.load(open(os.environ["OUT"])); t = d["totals"]
missing = sum(1 for a in d["centuria_specialists"]
              if not os.path.isfile(os.path.expanduser(a["definition_file"])))
ok = t["claim_is_true"] and t["total_defined"] >= 105 and missing == 0
print(f"claim_is_true={t['claim_is_true']} total_defined={t['total_defined']} "
      f"claimed={t['claimed']} missing_files={missing} verdict={'PASS' if ok else 'FAIL'}")
sys.exit(0 if ok else 1)
PY
    ;;
  *)
    echo "usage: centuria-roster.sh {build|show|verify}" >&2; exit 2 ;;
esac
