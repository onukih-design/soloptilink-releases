#!/usr/bin/env bash
# SoloptiLinkAI v2014.0 - Dynamic Module Loader
# Loads relevant orphaned modules based on project type and task
# Solves: 425+ modules in ~/.soloptilink/ disconnected from chain.sh

[[ -n "${_DYN_LOADER_LOADED:-}" ]] && return 0
_DYN_LOADER_LOADED=1

declare -g DL_VERSION="1.0"
declare -g DL_LOADED_MODULES=""
declare -g DL_MODULE_COUNT=0
declare -g DL_BASE_DIR="${HOME}/.soloptilink"
declare -g DL_PROJECT_TYPE=""
declare -gA DL_MODULE_MAP
declare -ga DL_AVAILABLE_MODULES=()
declare -ga DL_FAILED_MODULES=()

# --- Init: scan available modules ---
dl_init() {
  DL_AVAILABLE_MODULES=()
  local count=0
  for f in "${DL_BASE_DIR}"/*.sh; do
    [[ -f "$f" ]] || continue
    local base
    base="$(basename "$f")"
    [[ "$base" == "chain.sh" || "$base" == "chain-utils.sh" || "$base" == "dynamic-loader.sh" ]] && continue
    DL_AVAILABLE_MODULES+=("$base")
    ((count++))
  done
  echo "[DL] Scanned ${count} available modules in ${DL_BASE_DIR}/"
  return 0
}

# --- Detect project type from task description ---
dl_detect_project_type() {
  local task="${1:-}"
  [[ -z "$task" ]] && { echo "unknown"; return 1; }

  local task_lower
  task_lower="$(echo "$task" | tr '[:upper:]' '[:lower:]')"

  # Order: specific first, generic last
  if [[ "$task_lower" =~ (ecサイト|ecommerce|ec構築|ショッピング|通販|オンラインショップ|商品販売) ]]; then
    echo "ecommerce"
  elif [[ "$task_lower" =~ (crm|顧客管理|顧客関係|カスタマー管理|営業管理) ]]; then
    echo "crm"
  elif [[ "$task_lower" =~ (saas|マルチテナント|サブスクリプション|multi-tenant) ]]; then
    echo "saas"
  elif [[ "$task_lower" =~ (ブログ|cms|コンテンツ管理|記事管理|メディアサイト|wordpress) ]]; then
    echo "cms"
  elif [[ "$task_lower" =~ (ダッシュボード|管理画面|admin|バックオフィス|管理パネル) ]]; then
    echo "dashboard"
  elif [[ "$task_lower" =~ (api|バックエンド|backend|rest|graphql|エンドポイント) ]]; then
    echo "api"
  elif [[ "$task_lower" =~ (モバイル|ios|android|react.native|flutter|スマホアプリ) ]]; then
    echo "mobile"
  elif [[ "$task_lower" =~ (チャット|メッセージ|リアルタイム|websocket|messaging) ]]; then
    echo "chat"
  elif [[ "$task_lower" =~ (予約|reservation|booking|スケジュール|カレンダー予約) ]]; then
    echo "booking"
  elif [[ "$task_lower" =~ (決済|payment|stripe|課金|billing|請求) ]]; then
    echo "payment"
  elif [[ "$task_lower" =~ (認証|auth|ログイン|sso|oauth|セキュリティ) ]]; then
    echo "auth"
  elif [[ "$task_lower" =~ (分析|analytics|bi|レポート|統計|可視化|グラフ) ]]; then
    echo "analytics"
  elif [[ "$task_lower" =~ (在庫|inventory|倉庫|物流|logistics|配送|shipping) ]]; then
    echo "logistics"
  elif [[ "$task_lower" =~ (hr|人事|勤怠|給与|採用|employee) ]]; then
    echo "hr"
  elif [[ "$task_lower" =~ (会計|accounting|経理|簿記|財務|invoice|請求書) ]]; then
    echo "accounting"
  elif [[ "$task_lower" =~ (教育|lms|eラーニング|学習|education|course) ]]; then
    echo "education"
  elif [[ "$task_lower" =~ (医療|healthcare|病院|クリニック|患者|カルテ) ]]; then
    echo "healthcare"
  elif [[ "$task_lower" =~ (不動産|realestate|物件|property|賃貸) ]]; then
    echo "realestate"
  elif [[ "$task_lower" =~ (lp|ランディング|マーケティング|広告|キャンペーン) ]]; then
    echo "marketing"
  elif [[ "$task_lower" =~ (devops|ci.?cd|デプロイ|インフラ|kubernetes|docker) ]]; then
    echo "devops"
  elif [[ "$task_lower" =~ (テスト|test|qa|品質|検証) ]]; then
    echo "testing"
  else
    echo "general"
  fi
  return 0
}

# --- Module mapping per project type ---
dl_get_modules_for_type() {
  local ptype="${1:-general}"
  local modules=""

  case "$ptype" in
    ecommerce)
      modules="ecommerce-engine.sh payment-integration.sh inventory-system-generator.sh
        search-system-generator.sh seo-optimizer.sh i18n-engine.sh
        file-upload-system-generator.sh notification-system-generator.sh
        invoice-estimate-generator.sh customer-portal-generator.sh" ;;
    crm)
      modules="crm-generator.sh email-system-generator.sh notification-engine.sh
        customer-communication.sh calendar-scheduling-system.sh
        reporting-engine-generator.sh data-import-export-hub.sh
        kpi-okr-tracker.sh form-builder-engine.sh search-system-generator.sh" ;;
    saas)
      modules="saas-builder.sh saas-foundation.sh multi-tenant-engine.sh
        payment-integration.sh auth-flow-generator.sh authorization-matrix-generator.sh
        feature-flag-engine.sh rate-limiting-system.sh
        onboarding-guide-generator.sh customer-portal-generator.sh" ;;
    cms)
      modules="blog-cms-generator.sh seo-optimizer.sh search-system-generator.sh
        file-upload-system-generator.sh i18n-engine.sh
        static-site-generation.sh image-optimization-pipeline.sh
        responsive-design-engine.sh dark-mode-generator.sh" ;;
    dashboard)
      modules="dashboard-generator.sh admin-panel-generator.sh analytics-dashboard-generator.sh
        table-list-engine.sh reporting-engine-generator.sh
        data-import-export-hub.sh form-builder-engine.sh
        unified-dashboard.sh kpi-okr-tracker.sh" ;;
    api)
      modules="api-design-engine.sh api-gateway-generator.sh api-versioning.sh
        api-documentation-generator.sh api-response-optimizer.sh
        api-contract-validator.sh rate-limiter-gen.sh
        graphql-federation.sh type-safe-api-bridge.sh
        api-rate-limit-tester.sh api-surface-mapper.sh" ;;
    mobile)
      modules="ios-deploy-pipeline.sh responsive-design-engine.sh
        background-sync.sh notification-engine.sh
        image-optimization-pipeline.sh file-upload-engine.sh
        performance-budget-engine.sh state-management-optimizer.sh" ;;
    chat)
      modules="chat-system-generator.sh websocket-hub.sh notification-engine.sh
        realtime-sync.sh message-queue-integrator.sh
        file-upload-engine.sh stream-processor.sh
        background-job-system.sh" ;;
    booking)
      modules="reservation-system-generator.sh calendar-scheduling-system.sh
        notification-system-generator.sh payment-integration.sh
        email-system-generator.sh form-builder-engine.sh
        i18n-engine.sh queue-processor.sh" ;;
    payment)
      modules="payment-integration.sh invoice-estimate-generator.sh
        contract-management.sh audit-trail-system.sh
        notification-system-generator.sh regulatory-compliance-engine.sh
        secret-management.sh rate-limiting-system.sh" ;;
    auth)
      modules="auth-flow-generator.sh auth-scaffold.sh authorization-matrix-generator.sh
        auth-flow-fixer.sh security-scanner.sh
        secret-management.sh audit-trail-system.sh
        rate-limiting-system.sh compliance-scanner.sh" ;;
    analytics)
      modules="analytics-dashboard-generator.sh analytics-tracker.sh
        reporting-engine-generator.sh kpi-okr-tracker.sh
        realtime-data-pipeline.sh data-validation-pipeline.sh
        performance-report-generator.sh csv-excel-engine.sh
        batch-processing-engine.sh" ;;
    logistics)
      modules="inventory-system-generator.sh notification-system-generator.sh
        batch-processing-engine.sh data-import-export-hub.sh
        background-job-system.sh queue-processor.sh
        reporting-engine-generator.sh workflow-engine-generator.sh" ;;
    hr)
      modules="hr-system-generator.sh calendar-scheduling-system.sh
        notification-system-generator.sh reporting-engine-generator.sh
        form-builder-engine.sh data-import-export-hub.sh
        email-system-generator.sh workflow-engine-generator.sh" ;;
    accounting)
      modules="accounting-system-generator.sh invoice-estimate-generator.sh
        reporting-engine-generator.sh data-import-export-hub.sh
        csv-excel-engine.sh audit-trail-system.sh
        regulatory-compliance-engine.sh batch-processing-engine.sh" ;;
    education)
      modules="interactive-tutorial-generator.sh file-upload-system-generator.sh
        notification-system-generator.sh search-system-generator.sh
        calendar-scheduling-system.sh reporting-engine-generator.sh
        form-builder-engine.sh" ;;
    healthcare)
      modules="auth-flow-generator.sh audit-trail-system.sh
        notification-system-generator.sh calendar-scheduling-system.sh
        data-privacy-scanner.sh regulatory-compliance-engine.sh
        reporting-engine-generator.sh secret-management.sh" ;;
    realestate)
      modules="search-system-generator.sh file-upload-system-generator.sh
        image-optimization-pipeline.sh notification-system-generator.sh
        form-builder-engine.sh seo-optimizer.sh
        customer-communication.sh reporting-engine-generator.sh" ;;
    marketing)
      modules="lp-marketing-generator.sh seo-optimizer.sh analytics-tracker.sh
        ab-test-framework.sh responsive-design-engine.sh
        image-optimization-pipeline.sh form-builder-engine.sh
        email-system-generator.sh" ;;
    devops)
      modules="cicd-generator.sh cicd-pipeline-optimizer.sh auto-deploy.sh
        docker-optimizer.sh k8s-manifest-generator.sh
        monitoring-setup.sh log-aggregation.sh
        zero-downtime-deploy.sh iac-generator.sh
        canary-analysis-engine.sh" ;;
    testing)
      modules="test-generator.sh unit-test-generator.sh e2e-test-generator.sh
        integration-test-generator.sh test-coverage-maximizer.sh
        test-failure-analyzer.sh mutation-testing.sh
        browser-test.sh smoke-test-runner.sh
        load-test-generator.sh visual-regression-tester.sh" ;;
    general|*)
      modules="blueprint-generator.sh scaffolder.sh production-template-engine.sh
        code-review-ai.sh enterprise-patterns.sh
        error-handling-generator.sh performance-profiler.sh
        security-scanner.sh test-generator.sh" ;;
  esac

  echo "$modules"
}

# --- Load modules for a project type ---
dl_load_modules() {
  local ptype="${1:-}"
  [[ -z "$ptype" ]] && { echo "[DL] ERROR: project type required"; return 1; }

  DL_PROJECT_TYPE="$ptype"
  DL_LOADED_MODULES=""
  DL_MODULE_COUNT=0
  DL_FAILED_MODULES=()

  local modules
  modules="$(dl_get_modules_for_type "$ptype")"

  local loaded=0 skipped=0
  for mod in $modules; do
    local path="${DL_BASE_DIR}/${mod}"
    if [[ -f "$path" ]]; then
      # shellcheck disable=SC1090
      local _src_err=""
      if _src_err=$(source "$path" 2>&1); then
        DL_LOADED_MODULES="${DL_LOADED_MODULES:+${DL_LOADED_MODULES},}${mod}"
        ((loaded++))
      else
        _dl_log "WARN" "モジュール読込失敗: ${mod} - ${_src_err:0:100}"
        DL_FAILED_MODULES+=("$mod")
        ((skipped++))
      fi
    else
      DL_FAILED_MODULES+=("$mod")
      ((skipped++))
    fi
  done

  DL_MODULE_COUNT=$loaded
  echo "[DL] Loaded ${loaded} modules for type '${ptype}' (${skipped} skipped/missing)"
  return 0
}

# --- Auto-detect and load from task description ---
dl_auto_load() {
  local task="${1:-}"
  [[ -z "$task" ]] && { echo "[DL] ERROR: task description required"; return 1; }

  local ptype
  ptype="$(dl_detect_project_type "$task")"
  echo "[DL] Detected project type: ${ptype}"
  dl_load_modules "$ptype"
}

# --- List currently loaded modules ---
dl_get_loaded() {
  if [[ -z "$DL_LOADED_MODULES" ]]; then
    echo "[DL] No modules loaded"
    return 0
  fi
  echo "[DL] ${DL_MODULE_COUNT} modules loaded (type: ${DL_PROJECT_TYPE}):"
  local IFS=','
  local i=1
  for mod in $DL_LOADED_MODULES; do
    printf "  %2d. %s\n" "$i" "$mod"
    ((i++))
  done
}

# --- Report: summary of loaded modules and capabilities ---
dl_report() {
  echo "============================================"
  echo "  SoloptiLinkAI Dynamic Module Loader v${DL_VERSION}"
  echo "============================================"
  echo "Project Type : ${DL_PROJECT_TYPE:-not set}"
  echo "Loaded       : ${DL_MODULE_COUNT} modules"
  echo "Available    : ${#DL_AVAILABLE_MODULES[@]} total in ${DL_BASE_DIR}/"
  local avail=${#DL_AVAILABLE_MODULES[@]}
  [[ $avail -eq 0 ]] && avail=1
  echo "Coverage     : $(( DL_MODULE_COUNT * 100 / avail ))%"
  echo ""

  if [[ -n "$DL_LOADED_MODULES" ]]; then
    echo "Active Modules:"
    local IFS=','
    for mod in $DL_LOADED_MODULES; do
      printf "  [OK] %s\n" "$mod"
    done
  fi

  if [[ ${#DL_FAILED_MODULES[@]} -gt 0 ]]; then
    echo ""
    echo "Skipped (not found or source error):"
    for mod in "${DL_FAILED_MODULES[@]}"; do
      printf "  [--] %s\n" "$mod"
    done
  fi

  echo ""
  echo "Supported project types (22):"
  printf "  %-14s %-3s  %s\n" "TYPE" "#" "EXAMPLES"
  printf "  %-14s %2d   %s\n" "ecommerce" 10 "payment, search, seo, i18n..."
  printf "  %-14s %2d   %s\n" "crm" 10 "crm, email, notification..."
  printf "  %-14s %2d   %s\n" "saas" 10 "multi-tenant, auth, feature-flag..."
  printf "  %-14s %2d   %s\n" "cms" 9 "blog-cms, seo, static-site..."
  printf "  %-14s %2d   %s\n" "dashboard" 9 "admin-panel, analytics, table..."
  printf "  %-14s %2d   %s\n" "api" 11 "api-design, gateway, graphql..."
  printf "  %-14s %2d   %s\n" "mobile" 8 "ios-deploy, responsive, bg-sync..."
  printf "  %-14s %2d   %s\n" "chat" 8 "chat-system, websocket, mq..."
  printf "  %-14s %2d   %s\n" "booking" 8 "reservation, calendar, payment..."
  printf "  %-14s %2d   %s\n" "payment" 8 "payment, invoice, audit-trail..."
  printf "  %-14s %2d   %s\n" "auth" 9 "auth-flow, rbac, security..."
  printf "  %-14s %2d   %s\n" "analytics" 9 "analytics, reporting, kpi..."
  printf "  %-14s %2d   %s\n" "logistics" 8 "inventory, batch, workflow..."
  printf "  %-14s %2d   %s\n" "hr" 8 "hr-system, calendar, email..."
  printf "  %-14s %2d   %s\n" "accounting" 8 "accounting, invoice, csv..."
  printf "  %-14s %2d   %s\n" "education" 7 "tutorial, file-upload, search..."
  printf "  %-14s %2d   %s\n" "healthcare" 8 "auth, audit-trail, privacy..."
  printf "  %-14s %2d   %s\n" "realestate" 8 "search, file-upload, image..."
  printf "  %-14s %2d   %s\n" "marketing" 8 "lp-marketing, seo, ab-test..."
  printf "  %-14s %2d   %s\n" "devops" 10 "cicd, docker, k8s, zero-downtime..."
  printf "  %-14s %2d   %s\n" "testing" 11 "unit-test, e2e, mutation, load..."
  printf "  %-14s %2d   %s\n" "general" 9 "blueprint, scaffolder, enterprise..."
  echo "============================================"
}

# --- List all supported project types ---
dl_list_types() {
  echo "ecommerce crm saas cms dashboard api mobile chat booking payment auth analytics logistics hr accounting education healthcare realestate marketing devops testing general"
}

# --- Check if a specific module is loaded ---
dl_is_loaded() {
  local mod="${1:-}"
  [[ "$DL_LOADED_MODULES" == *"$mod"* ]]
}
