#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v19.0 - Workflow Engine
# =============================================================================
# YAML風ワークフロー定義 → DAG変換 → 自律実行
# カスタムワークフローの登録・検証・実行を管理
#
# ユーザーが .soloptilink/workflows/ にワークフローファイルを置くと自動検出し、
# DAGパイプラインに変換して実行する。ビルトインテンプレート（ci-cd, security-audit,
# full-stack, quick-deploy）も内蔵。
#
# 機能:
#   1.  wf_init()                    - エンジン初期化
#   2.  wf_discover_workflows()      - ワークフロー自動検出
#   3.  wf_parse_workflow()          - 簡易YAMLパーサー (pure bash)
#   4.  wf_validate_workflow()       - 妥当性チェック (循環依存検出含む)
#   5.  wf_to_dag()                  - DAGノード変換
#   6.  wf_execute_workflow()        - ワークフロー完全実行
#   7.  wf_create_template()         - テンプレート作成
#   8.  wf_list_templates()          - テンプレート一覧表示
#   9.  wf_generate_builtin_templates() - ビルトインテンプレート生成
#   10. wf_report()                  - ASCII表形式レポート出力
#   11. wf_export_json()             - JSON出力
#
# Usage: source lib/workflow-engine.sh
# =============================================================================

[[ -n "${_WORKFLOW_ENGINE_LOADED:-}" ]] && return 0
_WORKFLOW_ENGINE_LOADED=1

WF_VERSION="19.0"

# --- カラー定義 (WF_ prefix) --------------------------------------------------
WF_GREEN='\033[0;32m'   WF_YELLOW='\033[0;33m'  WF_RED='\033[0;31m'
WF_CYAN='\033[0;36m'    WF_PURPLE='\033[0;35m'  WF_BOLD='\033[1m'
WF_DIM='\033[2m'        WF_NC='\033[0m'

# --- グローバル状態 (WF_ prefix) -----------------------------------------------
WF_ENABLED="false"
WF_SESSION_ID=""
WF_PROJECT_DIR=""
WF_WORKFLOW_DIR=""
WF_REGISTRY_FILE=""
WF_HISTORY_FILE=""
WF_TOTAL_WORKFLOWS=0
WF_EXECUTED=0
WF_FAILED=0
WF_SKIPPED=0
WF_START_TIME=0
WF_CURRENT_WORKFLOW_NAME=""
WF_RESULTS=""

# パース結果を格納する連想配列
declare -gA WF_PARSED_STEPS=()
# ステップ実行状態: pending / running / completed / failed / skipped
declare -gA WF_STEP_STATUS=()
# ステップ実行時間
declare -gA WF_STEP_DURATION=()
# ステップ実行出力
declare -gA WF_STEP_OUTPUT=()

# =============================================================================
# 内部ヘルパー関数
# =============================================================================

# --- _wf_log: 構造化ログ出力 -------------------------------------------------
_wf_log() {
    local level="$1"; shift
    local color="${WF_NC}"
    case "$level" in
        INFO)    color="${WF_CYAN}" ;;
        PASS)    color="${WF_GREEN}" ;;
        WARN)    color="${WF_YELLOW}" ;;
        ERROR)   color="${WF_RED}" ;;
        SECTION) color="${WF_PURPLE}" ;;
        STEP)    color="${WF_CYAN}" ;;
    esac
    echo -e "  ${color}[WF:${level}]${WF_NC} $*" >&2
}

# --- _wf_record: Observatory イベント記録 ------------------------------------
_wf_record() {
    local event_type="$1" message="$2"
    local ts events_file
    ts=$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date '+%Y-%m-%dT%H:%M:%SZ')
    events_file="${SESSION_LOG_DIR:-/tmp}/observatory/events.jsonl"
    [[ -d "$(dirname "$events_file")" ]] || mkdir -p "$(dirname "$events_file")" 2>/dev/null
    printf '{"timestamp":"%s","type":"WF","event":"%s","data":"%s","module":"workflow-engine","version":"%s"}\n' \
        "$ts" "$event_type" "$message" "$WF_VERSION" >> "$events_file" 2>/dev/null || true
}

# --- _wf_timestamp: 現在時刻を秒で取得 ----------------------------------------
_wf_timestamp() {
    date +%s 2>/dev/null || echo "0"
}

# --- _wf_escape_json: JSON文字列エスケープ (簡易) ----------------------------
_wf_escape_json() {
    local s="$1"
    s="${s//\\/\\\\}"
    s="${s//\"/\\\"}"
    s="${s//$'\n'/\\n}"
    s="${s//$'\t'/\\t}"
    echo "$s"
}

# --- _wf_reset_step_arrays: ステップ配列リセット ------------------------------
_wf_reset_step_arrays() {
    unset WF_PARSED_STEPS WF_STEP_STATUS WF_STEP_DURATION WF_STEP_OUTPUT 2>/dev/null || true
    declare -gA WF_PARSED_STEPS=()
    declare -gA WF_STEP_STATUS=()
    declare -gA WF_STEP_DURATION=()
    declare -gA WF_STEP_OUTPUT=()
}

# =============================================================================
# 公開関数
# =============================================================================

# --- wf_init: エンジン初期化 --------------------------------------------------
wf_init() {
    local session_id="${1:-}"
    local project_dir="${2:-$(pwd)}"

    WF_SESSION_ID="${session_id:-wf_$(date +%s)}"
    WF_PROJECT_DIR="$project_dir"
    WF_WORKFLOW_DIR="${project_dir}/.soloptilink/workflows"
    WF_REGISTRY_FILE="${SESSION_LOG_DIR:-/tmp}/workflow/registry.json"
    WF_HISTORY_FILE="${SESSION_LOG_DIR:-/tmp}/workflow/history.jsonl"
    WF_TOTAL_WORKFLOWS=0
    WF_EXECUTED=0
    WF_FAILED=0
    WF_SKIPPED=0
    WF_START_TIME=$(_wf_timestamp)
    WF_ENABLED="true"
    WF_RESULTS=""
    WF_CURRENT_WORKFLOW_NAME=""

    # ディレクトリ作成
    mkdir -p "${SESSION_LOG_DIR:-/tmp}/workflow" 2>/dev/null || true
    mkdir -p "$WF_WORKFLOW_DIR" 2>/dev/null || true
    mkdir -p "${WF_PROJECT_DIR}/plugins/pipelines" 2>/dev/null || true

    _wf_reset_step_arrays

    _wf_log INFO "Workflow Engine v${WF_VERSION} initialized"
    _wf_log INFO "Workflow dir: ${WF_WORKFLOW_DIR}"
    _wf_record "INIT" "session=${WF_SESSION_ID}"
    return 0
}

# --- wf_discover_workflows: ワークフロー自動検出 -----------------------------
wf_discover_workflows() {
    local search_dirs=()
    local discovered=""
    local count=0

    _wf_log SECTION "=== Workflow Discovery ==="

    # スキャン対象ディレクトリ
    [[ -d "$WF_WORKFLOW_DIR" ]] && search_dirs+=("$WF_WORKFLOW_DIR")
    [[ -d "${WF_PROJECT_DIR}/plugins/pipelines" ]] && search_dirs+=("${WF_PROJECT_DIR}/plugins/pipelines")

    if [[ ${#search_dirs[@]} -eq 0 ]]; then
        _wf_log WARN "No workflow directories found"
        echo ""
        return 0
    fi

    for dir in "${search_dirs[@]}"; do
        local files
        # *.yml, *.yaml, *.workflow を検出
        for ext in yml yaml workflow; do
            while IFS= read -r -d '' f; do
                discovered="${discovered}${f}"$'\n'
                count=$((count + 1))
                _wf_log INFO "Discovered: $(basename "$f") [${dir}]"
            done < <(find "$dir" -maxdepth 2 -type f -name "*.${ext}" -print0 2>/dev/null)
        done
    done

    WF_TOTAL_WORKFLOWS=$count
    _wf_log PASS "Discovered ${count} workflow(s)"
    _wf_record "DISCOVER" "count=${count}"

    # 末尾の空行を除去して返す
    echo "$discovered" | sed '/^$/d'
    return 0
}

# --- wf_parse_workflow: 簡易YAMLパーサー (pure bash) -------------------------
# ワークフローファイルを読み取り、WF_PARSED_STEPS 連想配列に格納。
# フォーマット: WF_PARSED_STEPS[step_name]="command|depends|timeout|on_failure"
wf_parse_workflow() {
    local filepath="$1"

    if [[ ! -f "$filepath" ]]; then
        _wf_log ERROR "Workflow file not found: ${filepath}"
        return 1
    fi

    _wf_reset_step_arrays
    WF_CURRENT_WORKFLOW_NAME=""

    local in_steps=false
    local current_step_name=""
    local current_command=""
    local current_depends=""
    local current_timeout="60"
    local current_on_failure="abort"
    local wf_name="" wf_description=""

    while IFS= read -r line || [[ -n "$line" ]]; do
        # コメント行をスキップ
        [[ "$line" =~ ^[[:space:]]*# ]] && continue
        # 空行をスキップ
        [[ -z "${line// /}" ]] && continue

        # 先頭の空白数を数えてインデントレベルを判定
        local stripped="${line#"${line%%[![:space:]]*}"}"
        local indent=$(( ${#line} - ${#stripped} ))

        # トップレベルのキー: name, description, steps
        if [[ $indent -eq 0 ]]; then
            # 直前のステップがあれば保存
            if [[ -n "$current_step_name" ]]; then
                WF_PARSED_STEPS["$current_step_name"]="${current_command}|${current_depends}|${current_timeout}|${current_on_failure}"
                WF_STEP_STATUS["$current_step_name"]="pending"
                current_step_name=""
                current_command=""
                current_depends=""
                current_timeout="60"
                current_on_failure="abort"
            fi

            if [[ "$stripped" =~ ^name:[[:space:]]*(.*) ]]; then
                wf_name="${BASH_REMATCH[1]}"
                wf_name="${wf_name#\"}" ; wf_name="${wf_name%\"}"
                wf_name="${wf_name#\'}" ; wf_name="${wf_name%\'}"
                WF_CURRENT_WORKFLOW_NAME="$wf_name"
            elif [[ "$stripped" =~ ^description:[[:space:]]*(.*) ]]; then
                wf_description="${BASH_REMATCH[1]}"
            elif [[ "$stripped" =~ ^steps: ]]; then
                in_steps=true
            fi
            continue
        fi

        # steps ブロック内
        if [[ "$in_steps" == true ]]; then
            # ステップの開始: "- name: ..."
            if [[ "$stripped" =~ ^-[[:space:]]+name:[[:space:]]*(.*) ]]; then
                # 直前のステップがあれば保存
                if [[ -n "$current_step_name" ]]; then
                    WF_PARSED_STEPS["$current_step_name"]="${current_command}|${current_depends}|${current_timeout}|${current_on_failure}"
                    WF_STEP_STATUS["$current_step_name"]="pending"
                fi
                current_step_name="${BASH_REMATCH[1]}"
                current_step_name="${current_step_name#\"}" ; current_step_name="${current_step_name%\"}"
                current_step_name="${current_step_name#\'}" ; current_step_name="${current_step_name%\'}"
                current_command=""
                current_depends=""
                current_timeout="60"
                current_on_failure="abort"
                continue
            fi

            # ステップのプロパティ
            if [[ -n "$current_step_name" ]]; then
                if [[ "$stripped" =~ ^command:[[:space:]]*(.*) ]]; then
                    current_command="${BASH_REMATCH[1]}"
                    current_command="${current_command#\"}" ; current_command="${current_command%\"}"
                    current_command="${current_command#\'}" ; current_command="${current_command%\'}"
                elif [[ "$stripped" =~ ^depends_on:[[:space:]]*(.*) ]]; then
                    current_depends="${BASH_REMATCH[1]}"
                    current_depends="${current_depends#\"}" ; current_depends="${current_depends%\"}"
                    current_depends="${current_depends#\'}" ; current_depends="${current_depends%\'}"
                    # YAML配列の [a, b] 形式をカンマ区切りに変換
                    current_depends="${current_depends#\[}" ; current_depends="${current_depends%\]}"
                    current_depends="${current_depends// /}"
                elif [[ "$stripped" =~ ^timeout:[[:space:]]*(.*) ]]; then
                    current_timeout="${BASH_REMATCH[1]}"
                elif [[ "$stripped" =~ ^on_failure:[[:space:]]*(.*) ]]; then
                    current_on_failure="${BASH_REMATCH[1]}"
                    current_on_failure="${current_on_failure#\"}" ; current_on_failure="${current_on_failure%\"}"
                fi
            fi
        fi
    done < "$filepath"

    # 最後のステップを保存
    if [[ -n "$current_step_name" ]]; then
        WF_PARSED_STEPS["$current_step_name"]="${current_command}|${current_depends}|${current_timeout}|${current_on_failure}"
        WF_STEP_STATUS["$current_step_name"]="pending"
    fi

    local step_count=${#WF_PARSED_STEPS[@]}
    _wf_log PASS "Parsed workflow '${WF_CURRENT_WORKFLOW_NAME:-unknown}': ${step_count} step(s)"
    _wf_record "PARSE" "workflow=${WF_CURRENT_WORKFLOW_NAME:-unknown},steps=${step_count}"
    return 0
}

# --- wf_validate_workflow: ワークフロー定義の妥当性チェック -------------------
# 結果: 0=valid, 1=invalid
wf_validate_workflow() {
    local filepath="$1"
    local errors=0

    _wf_log SECTION "=== Workflow Validation ==="

    # ファイル存在チェック
    if [[ ! -f "$filepath" ]]; then
        _wf_log ERROR "File not found: ${filepath}"
        return 1
    fi

    # まだパースしていなければパース
    if [[ ${#WF_PARSED_STEPS[@]} -eq 0 ]]; then
        wf_parse_workflow "$filepath" || return 1
    fi

    # 必須フィールドチェック: name
    if [[ -z "$WF_CURRENT_WORKFLOW_NAME" ]]; then
        _wf_log ERROR "Missing required field: 'name'"
        errors=$((errors + 1))
    fi

    # 必須フィールドチェック: steps (少なくとも1つ)
    if [[ ${#WF_PARSED_STEPS[@]} -eq 0 ]]; then
        _wf_log ERROR "Missing required field: 'steps' (at least 1 step required)"
        errors=$((errors + 1))
        return 1
    fi

    # 各ステップのバリデーション
    local step_names=()
    for step_name in "${!WF_PARSED_STEPS[@]}"; do
        step_names+=("$step_name")
        local step_def="${WF_PARSED_STEPS[$step_name]}"
        local cmd depends timeout on_failure
        IFS='|' read -r cmd depends timeout on_failure <<< "$step_def"

        # command が空でないことを確認
        if [[ -z "$cmd" ]]; then
            _wf_log ERROR "Step '${step_name}': missing 'command'"
            errors=$((errors + 1))
        fi

        # on_failure の値チェック
        if [[ -n "$on_failure" && "$on_failure" != "skip" && "$on_failure" != "abort" && "$on_failure" != "retry" ]]; then
            _wf_log ERROR "Step '${step_name}': invalid on_failure '${on_failure}' (must be: skip, abort, retry)"
            errors=$((errors + 1))
        fi

        # 存在しない依存先の検出
        if [[ -n "$depends" ]]; then
            IFS=',' read -ra dep_list <<< "$depends"
            for dep in "${dep_list[@]}"; do
                dep="${dep// /}"
                [[ -z "$dep" ]] && continue
                if [[ -z "${WF_PARSED_STEPS[$dep]:-}" ]]; then
                    _wf_log ERROR "Step '${step_name}': depends on unknown step '${dep}'"
                    errors=$((errors + 1))
                fi
            done
        fi
    done

    # 循環依存検出 (DFS)
    if ! _wf_detect_cycle; then
        errors=$((errors + 1))
    fi

    if [[ $errors -gt 0 ]]; then
        _wf_log ERROR "Validation failed with ${errors} error(s)"
        _wf_record "VALIDATE" "status=FAIL,errors=${errors}"
        return 1
    fi

    _wf_log PASS "Validation passed: all checks OK"
    _wf_record "VALIDATE" "status=PASS,steps=${#WF_PARSED_STEPS[@]}"
    return 0
}

# --- _wf_detect_cycle: DFSによる循環依存検出 (内部) --------------------------
_wf_detect_cycle() {
    local -A visit_state=()

    for step_name in "${!WF_PARSED_STEPS[@]}"; do
        visit_state["$step_name"]="unvisited"
    done

    for step_name in "${!WF_PARSED_STEPS[@]}"; do
        if [[ "${visit_state[$step_name]}" == "unvisited" ]]; then
            if ! _wf_dfs_visit "$step_name" visit_state ""; then
                return 1
            fi
        fi
    done
    return 0
}

# --- _wf_dfs_visit: DFS巡回 (内部) -------------------------------------------
_wf_dfs_visit() {
    local node="$1"
    local -n _visit_ref=$2
    local path="$3"

    _visit_ref["$node"]="visiting"
    local current_path="${path:+${path} -> }${node}"

    local step_def="${WF_PARSED_STEPS[$node]:-}"
    [[ -z "$step_def" ]] && { _visit_ref["$node"]="visited"; return 0; }

    local depends
    IFS='|' read -r _ depends _ _ <<< "$step_def"

    if [[ -n "$depends" ]]; then
        IFS=',' read -ra dep_list <<< "$depends"
        for dep in "${dep_list[@]}"; do
            dep="${dep// /}"
            [[ -z "$dep" ]] && continue

            local dep_state="${_visit_ref[$dep]:-unvisited}"
            if [[ "$dep_state" == "visiting" ]]; then
                _wf_log ERROR "Circular dependency detected: ${current_path} -> ${dep}"
                return 1
            elif [[ "$dep_state" == "unvisited" ]]; then
                if ! _wf_dfs_visit "$dep" _visit_ref "$current_path"; then
                    return 1
                fi
            fi
        done
    fi

    _visit_ref["$node"]="visited"
    return 0
}

# --- wf_to_dag: パース済みワークフローをDAGノードに変換 ----------------------
wf_to_dag() {
    local filepath="$1"

    # パースされていなければパース
    if [[ ${#WF_PARSED_STEPS[@]} -eq 0 ]]; then
        wf_parse_workflow "$filepath" || return 1
    fi

    _wf_log SECTION "=== Converting to DAG ==="

    local dag_nodes="["
    local first=true

    for step_name in "${!WF_PARSED_STEPS[@]}"; do
        local step_def="${WF_PARSED_STEPS[$step_name]}"
        local cmd depends timeout on_failure
        IFS='|' read -r cmd depends timeout on_failure <<< "$step_def"

        # DAGノードIDとしてステップ名を大文字化
        local node_id
        node_id=$(echo "$step_name" | tr '[:lower:]' '[:upper:]' | tr ' -' '__')

        if [[ "$first" == true ]]; then
            first=false
        else
            dag_nodes="${dag_nodes},"
        fi

        # dag_add_node 互換フォーマット: id|name|est_minutes|dependencies|command
        local est_minutes=$(( timeout / 60 ))
        [[ $est_minutes -lt 1 ]] && est_minutes=1

        local escaped_cmd
        escaped_cmd=$(_wf_escape_json "$cmd")

        dag_nodes="${dag_nodes}{\"id\":\"${node_id}\",\"name\":\"${step_name}\",\"est_minutes\":${est_minutes},\"depends\":\"${depends}\",\"command\":\"${escaped_cmd}\",\"timeout\":${timeout},\"on_failure\":\"${on_failure}\"}"
    done

    dag_nodes="${dag_nodes}]"

    _wf_log PASS "Converted ${#WF_PARSED_STEPS[@]} step(s) to DAG nodes"
    _wf_record "TO_DAG" "nodes=${#WF_PARSED_STEPS[@]}"

    echo "$dag_nodes"
    return 0
}

# --- wf_execute_workflow: ワークフローの完全実行 -----------------------------
wf_execute_workflow() {
    local filepath="$1"
    local session_id="${2:-${WF_SESSION_ID}}"

    _wf_log SECTION "========================================="
    _wf_log SECTION "  Workflow Execution: $(basename "$filepath")"
    _wf_log SECTION "========================================="

    # パース & バリデーション
    wf_parse_workflow "$filepath" || return 1
    wf_validate_workflow "$filepath" || return 1

    local exec_start
    exec_start=$(_wf_timestamp)
    local wf_log_dir="${SESSION_LOG_DIR:-/tmp}/workflow"
    local exec_log="${wf_log_dir}/exec_${session_id}_$(date +%s).log"
    mkdir -p "$wf_log_dir" 2>/dev/null || true

    _wf_record "EXEC_START" "workflow=${WF_CURRENT_WORKFLOW_NAME},session=${session_id}"

    # トポロジカルソート順に実行
    local completed_count=0
    local failed_count=0
    local skipped_count=0
    local total=${#WF_PARSED_STEPS[@]}
    local max_iterations=$(( total * total + total ))
    local iteration=0

    while [[ $completed_count -lt $total && $iteration -lt $max_iterations ]]; do
        iteration=$((iteration + 1))
        local progress_made=false

        for step_name in "${!WF_PARSED_STEPS[@]}"; do
            local status="${WF_STEP_STATUS[$step_name]:-pending}"
            [[ "$status" != "pending" ]] && continue

            # 依存チェック
            local step_def="${WF_PARSED_STEPS[$step_name]}"
            local cmd depends timeout on_failure
            IFS='|' read -r cmd depends timeout on_failure <<< "$step_def"

            local deps_met=true
            local deps_failed=false
            if [[ -n "$depends" ]]; then
                IFS=',' read -ra dep_list <<< "$depends"
                for dep in "${dep_list[@]}"; do
                    dep="${dep// /}"
                    [[ -z "$dep" ]] && continue
                    local dep_status="${WF_STEP_STATUS[$dep]:-pending}"
                    if [[ "$dep_status" == "pending" || "$dep_status" == "running" ]]; then
                        deps_met=false
                        break
                    elif [[ "$dep_status" == "failed" ]]; then
                        deps_failed=true
                    fi
                done
            fi

            [[ "$deps_met" == false ]] && continue

            # 依存先が失敗している場合の処理
            if [[ "$deps_failed" == true ]]; then
                WF_STEP_STATUS["$step_name"]="skipped"
                WF_STEP_DURATION["$step_name"]="0"
                WF_STEP_OUTPUT["$step_name"]="Skipped: dependency failed"
                skipped_count=$((skipped_count + 1))
                completed_count=$((completed_count + 1))
                WF_SKIPPED=$((WF_SKIPPED + 1))
                _wf_log WARN "Step '${step_name}': SKIPPED (dependency failed)"
                progress_made=true
                continue
            fi

            # ステップ実行
            progress_made=true
            WF_STEP_STATUS["$step_name"]="running"
            _wf_log STEP "Step '${step_name}': RUNNING [timeout=${timeout}s, on_failure=${on_failure}]"

            local step_start
            step_start=$(_wf_timestamp)
            local step_output=""
            local step_exit=0

            # コマンド実行（タイムアウト付き）
            _wf_run_step "$cmd" "$timeout" step_output step_exit

            local step_end
            step_end=$(_wf_timestamp)
            local duration=$(( step_end - step_start ))
            WF_STEP_DURATION["$step_name"]="$duration"
            WF_STEP_OUTPUT["$step_name"]="$step_output"

            # 実行ログに記録
            {
                echo "=== Step: ${step_name} ==="
                echo "Command: ${cmd}"
                echo "Exit: ${step_exit}"
                echo "Duration: ${duration}s"
                echo "Output:"
                echo "$step_output"
                echo ""
            } >> "$exec_log" 2>/dev/null || true

            if [[ $step_exit -eq 0 ]]; then
                WF_STEP_STATUS["$step_name"]="completed"
                completed_count=$((completed_count + 1))
                _wf_log PASS "Step '${step_name}': COMPLETED (${duration}s)"
                _wf_record "STEP_PASS" "step=${step_name},duration=${duration}"
            else
                # 失敗時の戦略適用
                case "$on_failure" in
                    skip)
                        WF_STEP_STATUS["$step_name"]="skipped"
                        completed_count=$((completed_count + 1))
                        skipped_count=$((skipped_count + 1))
                        WF_SKIPPED=$((WF_SKIPPED + 1))
                        _wf_log WARN "Step '${step_name}': SKIPPED (on_failure=skip)"
                        _wf_record "STEP_SKIP" "step=${step_name}"
                        ;;
                    retry)
                        local retry_success=false
                        local max_retries=3
                        for r in $(seq 1 $max_retries); do
                            _wf_log WARN "Step '${step_name}': RETRY ${r}/${max_retries}"
                            _wf_run_step "$cmd" "$timeout" step_output step_exit
                            if [[ $step_exit -eq 0 ]]; then
                                retry_success=true
                                break
                            fi
                        done
                        if [[ "$retry_success" == true ]]; then
                            WF_STEP_STATUS["$step_name"]="completed"
                            completed_count=$((completed_count + 1))
                            _wf_log PASS "Step '${step_name}': COMPLETED after retry"
                            _wf_record "STEP_RETRY_PASS" "step=${step_name}"
                        else
                            WF_STEP_STATUS["$step_name"]="failed"
                            completed_count=$((completed_count + 1))
                            failed_count=$((failed_count + 1))
                            WF_FAILED=$((WF_FAILED + 1))
                            _wf_log ERROR "Step '${step_name}': FAILED after ${max_retries} retries"
                            _wf_record "STEP_FAIL" "step=${step_name},retries=${max_retries}"
                        fi
                        ;;
                    abort|*)
                        WF_STEP_STATUS["$step_name"]="failed"
                        completed_count=$((completed_count + 1))
                        failed_count=$((failed_count + 1))
                        WF_FAILED=$((WF_FAILED + 1))
                        _wf_log ERROR "Step '${step_name}': FAILED (on_failure=abort)"
                        _wf_record "STEP_FAIL" "step=${step_name},abort=true"

                        # abort: 残りのステップを全てスキップ
                        for remaining in "${!WF_PARSED_STEPS[@]}"; do
                            if [[ "${WF_STEP_STATUS[$remaining]}" == "pending" ]]; then
                                WF_STEP_STATUS["$remaining"]="skipped"
                                completed_count=$((completed_count + 1))
                                skipped_count=$((skipped_count + 1))
                                WF_SKIPPED=$((WF_SKIPPED + 1))
                            fi
                        done
                        _wf_log ERROR "Workflow aborted due to step failure"
                        ;;
                esac
            fi
        done

        # デッドロック検出: 進捗がない場合
        if [[ "$progress_made" == false ]]; then
            _wf_log ERROR "Deadlock detected: no progress possible"
            break
        fi
    done

    WF_EXECUTED=$((WF_EXECUTED + 1))

    local exec_end
    exec_end=$(_wf_timestamp)
    local total_duration=$(( exec_end - exec_start ))

    _wf_log SECTION "========================================="
    _wf_log SECTION "  Execution Summary"
    _wf_log SECTION "========================================="
    _wf_log INFO "Total steps: ${total}"
    _wf_log PASS "Completed:   $((total - failed_count - skipped_count))"
    [[ $failed_count -gt 0 ]] && _wf_log ERROR "Failed:      ${failed_count}"
    [[ $skipped_count -gt 0 ]] && _wf_log WARN "Skipped:     ${skipped_count}"
    _wf_log INFO "Duration:    ${total_duration}s"

    _wf_record "EXEC_END" "workflow=${WF_CURRENT_WORKFLOW_NAME},duration=${total_duration},failed=${failed_count},skipped=${skipped_count}"

    # 履歴に記録
    {
        printf '{"timestamp":"%s","workflow":"%s","session":"%s","duration":%d,"total":%d,"failed":%d,"skipped":%d}\n' \
            "$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date '+%Y-%m-%dT%H:%M:%SZ')" \
            "$WF_CURRENT_WORKFLOW_NAME" "$session_id" "$total_duration" "$total" "$failed_count" "$skipped_count"
    } >> "$WF_HISTORY_FILE" 2>/dev/null || true

    [[ $failed_count -gt 0 ]] && return 1
    return 0
}

# --- _wf_run_step: ステップコマンド実行 (タイムアウト付き) -------------------
_wf_run_step() {
    local cmd="$1"
    local timeout_sec="$2"
    local -n _output_ref=$3
    local -n _exit_ref=$4

    local tmp_out
    tmp_out=$(mktemp 2>/dev/null || echo "/tmp/wf_step_$$")

    # timeout コマンドの有無を確認
    if command -v timeout >/dev/null 2>&1; then
        timeout "${timeout_sec}" bash -c "$cmd" > "$tmp_out" 2>&1
        _exit_ref=$?
    elif command -v gtimeout >/dev/null 2>&1; then
        gtimeout "${timeout_sec}" bash -c "$cmd" > "$tmp_out" 2>&1
        _exit_ref=$?
    else
        # timeout なし: 直接実行
        bash -c "$cmd" > "$tmp_out" 2>&1
        _exit_ref=$?
    fi

    _output_ref=$(cat "$tmp_out" 2>/dev/null || echo "")
    rm -f "$tmp_out" 2>/dev/null || true
}

# --- wf_create_template: プリセットワークフローテンプレート作成 ---------------
wf_create_template() {
    local name="$1"
    local description="$2"
    local steps_json="$3"

    local template_dir="${WF_PROJECT_DIR}/plugins/pipelines"
    mkdir -p "$template_dir" 2>/dev/null || true

    local template_file="${template_dir}/${name}.workflow"

    {
        echo "# SoloptiLink Workflow Template: ${name}"
        echo "# Generated: $(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date '+%Y-%m-%dT%H:%M:%SZ')"
        echo ""
        echo "name: ${name}"
        echo "description: ${description}"
        echo ""
        echo "steps:"
        # steps_json は改行区切りの "step_name|command|depends|timeout|on_failure" 形式
        while IFS= read -r step_line; do
            [[ -z "$step_line" ]] && continue
            local s_name s_cmd s_dep s_timeout s_on_failure
            IFS='|' read -r s_name s_cmd s_dep s_timeout s_on_failure <<< "$step_line"
            echo "  - name: ${s_name}"
            echo "    command: ${s_cmd}"
            [[ -n "$s_dep" ]] && echo "    depends_on: ${s_dep}"
            [[ -n "$s_timeout" ]] && echo "    timeout: ${s_timeout}"
            [[ -n "$s_on_failure" ]] && echo "    on_failure: ${s_on_failure}"
            echo ""
        done <<< "$steps_json"
    } > "$template_file"

    _wf_log PASS "Template created: ${template_file}"
    _wf_record "TEMPLATE_CREATE" "name=${name}"
    echo "$template_file"
    return 0
}

# --- wf_list_templates: 利用可能なテンプレート一覧を表示 ----------------------
wf_list_templates() {
    _wf_log SECTION "=== Available Workflow Templates ==="

    local template_dirs=(
        "${WF_PROJECT_DIR}/plugins/pipelines"
        "${WF_WORKFLOW_DIR}"
    )
    local count=0

    echo ""
    printf "  ${WF_BOLD}%-20s %-40s %-10s${WF_NC}\n" "NAME" "DESCRIPTION" "TYPE"
    echo "  $(printf '%0.s-' {1..72})"

    for dir in "${template_dirs[@]}"; do
        [[ ! -d "$dir" ]] && continue
        for ext in yml yaml workflow; do
            while IFS= read -r -d '' f; do
                local t_name="" t_desc="" t_type="custom"
                while IFS= read -r line; do
                    if [[ "$line" =~ ^name:[[:space:]]*(.*) ]]; then
                        t_name="${BASH_REMATCH[1]}"
                        t_name="${t_name#\"}" ; t_name="${t_name%\"}"
                    elif [[ "$line" =~ ^description:[[:space:]]*(.*) ]]; then
                        t_desc="${BASH_REMATCH[1]}"
                        t_desc="${t_desc#\"}" ; t_desc="${t_desc%\"}"
                    fi
                done < "$f"
                # ビルトイン判定
                case "$t_name" in
                    ci-cd|security-audit|full-stack|quick-deploy) t_type="builtin" ;;
                esac
                [[ -z "$t_name" ]] && t_name="$(basename "$f")"
                printf "  %-20s %-40s %-10s\n" "$t_name" "${t_desc:0:38}" "$t_type"
                count=$((count + 1))
            done < <(find "$dir" -maxdepth 2 -type f -name "*.${ext}" -print0 2>/dev/null)
        done
    done

    echo ""
    _wf_log INFO "Total: ${count} template(s)"
    return 0
}

# --- wf_generate_builtin_templates: ビルトインテンプレート4種を生成 -----------
wf_generate_builtin_templates() {
    local wf_dir="${WF_PROJECT_DIR}/plugins/pipelines"
    mkdir -p "$wf_dir" 2>/dev/null || true

    _wf_log SECTION "=== Generating Built-in Templates ==="

    # 1. ci-cd: lint -> test -> build -> deploy
    cat > "${wf_dir}/ci-cd.workflow" << 'CICD_EOF'
# SoloptiLink Built-in Workflow: CI/CD Pipeline
name: ci-cd
description: Standard CI/CD pipeline with lint, test, build, deploy

steps:
  - name: lint
    command: npm run lint || echo 'lint skipped'
    timeout: 120
    on_failure: skip

  - name: test
    command: npm test || echo 'test skipped'
    depends_on: lint
    timeout: 300
    on_failure: retry

  - name: build
    command: npm run build
    depends_on: test
    timeout: 300
    on_failure: abort

  - name: deploy
    command: echo 'deploy step placeholder'
    depends_on: build
    timeout: 600
    on_failure: abort
CICD_EOF
    _wf_log PASS "Created: ci-cd.workflow"

    # 2. security-audit: scan -> audit -> report
    cat > "${wf_dir}/security-audit.workflow" << 'SECAUD_EOF'
# SoloptiLink Built-in Workflow: Security Audit
name: security-audit
description: Security scanning, dependency audit, and report generation

steps:
  - name: scan
    command: echo 'OWASP security scan'
    timeout: 300
    on_failure: retry

  - name: audit
    command: echo 'dependency audit'
    depends_on: scan
    timeout: 180
    on_failure: skip

  - name: report
    command: echo 'generate security report'
    depends_on: audit
    timeout: 120
    on_failure: skip
SECAUD_EOF
    _wf_log PASS "Created: security-audit.workflow"

    # 3. full-stack: design -> backend -> frontend -> test -> deploy
    cat > "${wf_dir}/full-stack.workflow" << 'FULLSTACK_EOF'
# SoloptiLink Built-in Workflow: Full-Stack Development
name: full-stack
description: Complete full-stack development pipeline

steps:
  - name: design
    command: echo 'design phase'
    timeout: 300
    on_failure: abort

  - name: backend
    command: echo 'backend implementation'
    depends_on: design
    timeout: 600
    on_failure: retry

  - name: frontend
    command: echo 'frontend implementation'
    depends_on: design
    timeout: 600
    on_failure: retry

  - name: test
    command: echo 'run tests'
    depends_on: backend, frontend
    timeout: 300
    on_failure: retry

  - name: deploy
    command: echo 'deploy to production'
    depends_on: test
    timeout: 600
    on_failure: abort
FULLSTACK_EOF
    _wf_log PASS "Created: full-stack.workflow"

    # 4. quick-deploy: build -> deploy -> verify
    cat > "${wf_dir}/quick-deploy.workflow" << 'QUICKDEP_EOF'
# SoloptiLink Built-in Workflow: Quick Deploy
name: quick-deploy
description: Fast build-deploy-verify cycle

steps:
  - name: build
    command: npm run build || echo 'build placeholder'
    timeout: 300
    on_failure: abort

  - name: deploy
    command: echo 'deploy placeholder'
    depends_on: build
    timeout: 300
    on_failure: abort

  - name: verify
    command: echo 'post-deploy verification'
    depends_on: deploy
    timeout: 120
    on_failure: skip
QUICKDEP_EOF
    _wf_log PASS "Created: quick-deploy.workflow"

    _wf_log PASS "Generated 4 built-in templates"
    _wf_record "BUILTIN_GEN" "count=4"
    return 0
}

# --- wf_report: ワークフロー実行レポート（ASCII表形式）-----------------------
wf_report() {
    local elapsed=0
    local now
    now=$(_wf_timestamp)
    [[ $WF_START_TIME -gt 0 ]] && elapsed=$(( now - WF_START_TIME ))

    echo ""
    echo -e "  ${WF_BOLD}${WF_PURPLE}=============================================${WF_NC}"
    echo -e "  ${WF_BOLD}${WF_PURPLE}  Workflow Engine Report v${WF_VERSION}${WF_NC}"
    echo -e "  ${WF_BOLD}${WF_PURPLE}=============================================${WF_NC}"
    echo ""

    # サマリー
    echo -e "  ${WF_BOLD}Session:${WF_NC}    ${WF_SESSION_ID}"
    echo -e "  ${WF_BOLD}Workflow:${WF_NC}   ${WF_CURRENT_WORKFLOW_NAME:-N/A}"
    echo -e "  ${WF_BOLD}Elapsed:${WF_NC}    ${elapsed}s"
    echo -e "  ${WF_BOLD}Discovered:${WF_NC} ${WF_TOTAL_WORKFLOWS}"
    echo -e "  ${WF_BOLD}Executed:${WF_NC}   ${WF_EXECUTED}"
    echo -e "  ${WF_BOLD}Failed:${WF_NC}     ${WF_FAILED}"
    echo -e "  ${WF_BOLD}Skipped:${WF_NC}    ${WF_SKIPPED}"
    echo ""

    # ステップ詳細テーブル
    if [[ ${#WF_PARSED_STEPS[@]} -gt 0 ]]; then
        echo -e "  ${WF_BOLD}Step Execution Details:${WF_NC}"
        echo ""
        printf "  ${WF_BOLD}%-20s %-12s %-10s %-12s${WF_NC}\n" "STEP" "STATUS" "DURATION" "ON_FAILURE"
        echo "  $(printf '%0.s-' {1..56})"

        for step_name in "${!WF_PARSED_STEPS[@]}"; do
            local status="${WF_STEP_STATUS[$step_name]:-pending}"
            local duration="${WF_STEP_DURATION[$step_name]:-0}"
            local step_def="${WF_PARSED_STEPS[$step_name]}"
            local on_failure
            IFS='|' read -r _ _ _ on_failure <<< "$step_def"

            local status_color="${WF_NC}"
            case "$status" in
                completed) status_color="${WF_GREEN}" ;;
                failed)    status_color="${WF_RED}" ;;
                skipped)   status_color="${WF_YELLOW}" ;;
                running)   status_color="${WF_CYAN}" ;;
                pending)   status_color="${WF_DIM}" ;;
            esac

            printf "  %-20s ${status_color}%-12s${WF_NC} %-10s %-12s\n" \
                "${step_name:0:18}" "$status" "${duration}s" "$on_failure"
        done
        echo ""
    fi

    echo -e "  ${WF_BOLD}${WF_PURPLE}=============================================${WF_NC}"
    echo ""
}

# --- wf_export_json: 実行結果のJSON出力 --------------------------------------
wf_export_json() {
    local output_file="${1:-${SESSION_LOG_DIR:-/tmp}/workflow/workflow_report.json}"

    local steps_json="["
    local first=true

    for step_name in "${!WF_PARSED_STEPS[@]}"; do
        local step_def="${WF_PARSED_STEPS[$step_name]}"
        local cmd depends timeout on_failure
        IFS='|' read -r cmd depends timeout on_failure <<< "$step_def"

        local status="${WF_STEP_STATUS[$step_name]:-pending}"
        local duration="${WF_STEP_DURATION[$step_name]:-0}"
        local output
        output=$(_wf_escape_json "${WF_STEP_OUTPUT[$step_name]:-}")

        if [[ "$first" == true ]]; then
            first=false
        else
            steps_json="${steps_json},"
        fi

        steps_json="${steps_json}{\"name\":\"${step_name}\",\"command\":\"$(_wf_escape_json "$cmd")\",\"depends\":\"${depends}\",\"timeout\":${timeout},\"on_failure\":\"${on_failure}\",\"status\":\"${status}\",\"duration\":${duration},\"output\":\"${output}\"}"
    done
    steps_json="${steps_json}]"

    local now_ts
    now_ts=$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date '+%Y-%m-%dT%H:%M:%SZ')

    {
        printf '{\n'
        printf '  "module": "workflow-engine",\n'
        printf '  "version": "%s",\n' "$WF_VERSION"
        printf '  "timestamp": "%s",\n' "$now_ts"
        printf '  "session_id": "%s",\n' "$WF_SESSION_ID"
        printf '  "workflow_name": "%s",\n' "$WF_CURRENT_WORKFLOW_NAME"
        printf '  "total_workflows": %d,\n' "$WF_TOTAL_WORKFLOWS"
        printf '  "executed": %d,\n' "$WF_EXECUTED"
        printf '  "failed": %d,\n' "$WF_FAILED"
        printf '  "skipped": %d,\n' "$WF_SKIPPED"
        printf '  "steps": %s\n' "$steps_json"
        printf '}\n'
    } > "$output_file" 2>/dev/null

    _wf_log PASS "JSON exported: ${output_file}"
    _wf_record "EXPORT" "file=${output_file}"
    echo "$output_file"
    return 0
}
