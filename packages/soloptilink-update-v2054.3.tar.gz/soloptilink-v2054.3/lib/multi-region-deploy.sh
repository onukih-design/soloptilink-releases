#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v369.0 - Multi-Region Deploy
# =============================================================================
# マルチリージョンデプロイ×データ同期×ルーティング
#
# 機能:
#   - マルチリージョンインフラ定義生成
#   - クロスリージョンデータ同期設定
#   - 地理ベースルーティング（GeoDNS/Anycast）
#   - リージョンフェイルオーバー設定
#   - レイテンシベースルーティング
#
# 全globals: MRD_ prefix
# =============================================================================

[[ -n "${_MRD_LOADED:-}" ]] && return 0; _MRD_LOADED=1

MRD_VERSION="369.0"
MRD_GENERATED=0
MRD_ERRORS=0
MRD_PHASE="multi_region"
MRD_FILES_CREATED=()

: "${GREEN:=\033[0;32m}" ; : "${RED:=\033[0;31m}" ; : "${YELLOW:=\033[0;33m}"
: "${CYAN:=\033[0;36m}" ; : "${BOLD:=\033[1m}" ; : "${NC:=\033[0m}"

_mrd_log() { echo -e "  ${CYAN}[MRD]${NC} $*"; }
_mrd_ok() { echo -e "  ${GREEN}[MRD]${NC} $*"; }
_mrd_err() { echo -e "  ${RED}[MRD]${NC} $*"; }

_mrd_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        MRD_FILES_CREATED+=("$filepath")
        MRD_GENERATED=$((MRD_GENERATED + 1))
        _mrd_ok "Created: ${filepath##*/}"
    else
        MRD_ERRORS=$((MRD_ERRORS + 1))
        _mrd_err "Failed: ${filepath##*/}"
    fi
}

mrd_init() {
    MRD_GENERATED=0; MRD_ERRORS=0; MRD_FILES_CREATED=()
    _mrd_log "Multi-Region Deploy v${MRD_VERSION} initialized"
    return 0
}

# =============================================================================
# Generate Multi-Region
# =============================================================================
_mrd_generate_multi_region() {
    local project_dir="${1:-.}"

    _mrd_log "Generating multi-region infrastructure..."

    local infra_dir="${project_dir}/infra/multi-region"
    mkdir -p "$infra_dir" 2>/dev/null

    _mrd_write_file "${infra_dir}/region-config.ts" "$(cat <<'TS'
import { z } from 'zod';

export const RegionSchema = z.object({
  id: z.string(),
  name: z.string(),
  provider: z.enum(['aws', 'gcp', 'azure']),
  region: z.string(),
  primary: z.boolean().default(false),
  endpoints: z.object({
    api: z.string().url(),
    db: z.string(),
    cache: z.string().optional(),
  }),
  healthCheckUrl: z.string().url(),
  weight: z.number().min(0).max(100).default(50),
  status: z.enum(['active', 'standby', 'draining', 'offline']).default('active'),
});

export type Region = z.infer<typeof RegionSchema>;

export const DEFAULT_REGIONS: Region[] = [
  {
    id: 'ap-northeast-1',
    name: 'Tokyo',
    provider: 'aws',
    region: 'ap-northeast-1',
    primary: true,
    endpoints: { api: 'https://api-tokyo.example.com', db: 'postgres://tokyo-primary:5432/app' },
    healthCheckUrl: 'https://api-tokyo.example.com/health',
    weight: 60,
    status: 'active',
  },
  {
    id: 'us-east-1',
    name: 'Virginia',
    provider: 'aws',
    region: 'us-east-1',
    primary: false,
    endpoints: { api: 'https://api-virginia.example.com', db: 'postgres://virginia-replica:5432/app' },
    healthCheckUrl: 'https://api-virginia.example.com/health',
    weight: 40,
    status: 'active',
  },
];

export class RegionManager {
  private regions: Region[] = [];

  constructor(regions: Region[] = DEFAULT_REGIONS) {
    this.regions = regions;
  }

  getPrimary(): Region | undefined {
    return this.regions.find(r => r.primary && r.status === 'active');
  }

  getActive(): Region[] {
    return this.regions.filter(r => r.status === 'active');
  }

  failover(regionId: string): void {
    const failing = this.regions.find(r => r.id === regionId);
    if (failing) {
      failing.status = 'offline';
      if (failing.primary) {
        const nextPrimary = this.regions.find(r => r.id !== regionId && r.status === 'active');
        if (nextPrimary) {
          nextPrimary.primary = true;
          failing.primary = false;
        }
      }
    }
  }

  getRegionForUser(latitude: number, longitude: number): Region {
    const active = this.getActive();
    if (active.length === 0) throw new Error('No active regions');
    // Simple: Asia -> Tokyo, Americas/Europe -> Virginia
    if (longitude > 60 && longitude < 180) {
      return active.find(r => r.region.startsWith('ap-')) || active[0];
    }
    return active.find(r => r.region.startsWith('us-')) || active[0];
  }
}

export const regionManager = new RegionManager();
TS
)"

    _mrd_write_file "${infra_dir}/terraform-multi-region.tf" "$(cat <<'TF'
# Multi-Region Infrastructure - Terraform

variable "regions" {
  type = map(object({
    region  = string
    primary = bool
    weight  = number
  }))
  default = {
    tokyo = {
      region  = "ap-northeast-1"
      primary = true
      weight  = 60
    }
    virginia = {
      region  = "us-east-1"
      primary = false
      weight  = 40
    }
  }
}

module "region" {
  for_each = var.regions
  source   = "./modules/region"

  region_name = each.key
  aws_region  = each.value.region
  is_primary  = each.value.primary
  weight      = each.value.weight
}

resource "aws_route53_health_check" "region" {
  for_each = var.regions

  fqdn              = "api-${each.key}.example.com"
  port              = 443
  type              = "HTTPS"
  resource_path     = "/health"
  failure_threshold = 3
  request_interval  = 30
}

resource "aws_route53_record" "weighted" {
  for_each = var.regions

  zone_id = data.aws_route53_zone.main.zone_id
  name    = "api.example.com"
  type    = "A"

  weighted_routing_policy {
    weight = each.value.weight
  }

  set_identifier = each.key
  health_check_id = aws_route53_health_check.region[each.key].id

  alias {
    name                   = module.region[each.key].alb_dns_name
    zone_id                = module.region[each.key].alb_zone_id
    evaluate_target_health = true
  }
}
TF
)"

    _mrd_ok "Multi-region infrastructure generated"
}

# =============================================================================
# Generate Data Sync
# =============================================================================
_mrd_generate_data_sync() {
    local project_dir="${1:-.}"

    _mrd_log "Generating cross-region data sync..."

    local sync_dir="${project_dir}/src/lib/multi-region"
    mkdir -p "$sync_dir" 2>/dev/null

    _mrd_write_file "${sync_dir}/data-sync.ts" "$(cat <<'TS'
// Cross-region data synchronization

interface SyncConfig {
  primaryRegion: string;
  replicaRegions: string[];
  syncMode: 'async' | 'semi_sync' | 'sync';
  conflictResolution: 'primary_wins' | 'last_write_wins' | 'custom';
  lagThresholdMs: number;
}

interface ReplicationStatus {
  region: string;
  lagMs: number;
  status: 'in_sync' | 'lagging' | 'disconnected';
  lastSyncAt: Date;
  bytesTransferred: number;
}

export class DataSyncManager {
  private config: SyncConfig;
  private replicationStatuses = new Map<string, ReplicationStatus>();

  constructor(config: SyncConfig) {
    this.config = config;
  }

  getStatus(): ReplicationStatus[] {
    return Array.from(this.replicationStatuses.values());
  }

  isHealthy(): boolean {
    return Array.from(this.replicationStatuses.values()).every(
      s => s.status !== 'disconnected' && s.lagMs < this.config.lagThresholdMs
    );
  }

  async checkReplicationLag(): Promise<void> {
    for (const region of this.config.replicaRegions) {
      const status: ReplicationStatus = {
        region,
        lagMs: 0,
        status: 'in_sync',
        lastSyncAt: new Date(),
        bytesTransferred: 0,
      };

      // In production, query replica for replication lag
      if (status.lagMs > this.config.lagThresholdMs) {
        status.status = 'lagging';
      }

      this.replicationStatuses.set(region, status);
    }
  }

  getReadRegion(userRegion: string): string {
    const replica = this.replicationStatuses.get(userRegion);
    if (replica && replica.status === 'in_sync') {
      return userRegion;
    }
    return this.config.primaryRegion;
  }

  getWriteRegion(): string {
    return this.config.primaryRegion;
  }
}

export const dataSyncManager = new DataSyncManager({
  primaryRegion: 'ap-northeast-1',
  replicaRegions: ['us-east-1'],
  syncMode: 'async',
  conflictResolution: 'last_write_wins',
  lagThresholdMs: 5000,
});
TS
)"

    _mrd_ok "Cross-region data sync generated"
}

# =============================================================================
# Generate Routing
# =============================================================================
_mrd_generate_routing() {
    local project_dir="${1:-.}"

    _mrd_log "Generating geo-based routing..."

    local route_dir="${project_dir}/src/lib/multi-region"
    mkdir -p "$route_dir" 2>/dev/null

    _mrd_write_file "${route_dir}/routing.ts" "$(cat <<'TS'
// Geo-based routing with latency awareness

interface RouteDecision {
  region: string;
  endpoint: string;
  reason: 'geo_proximity' | 'latency_based' | 'failover' | 'weight_based';
  latencyEstimate: number;
}

interface LatencyRecord {
  region: string;
  latencyMs: number;
  measuredAt: Date;
}

export class GeoRouter {
  private latencyCache = new Map<string, LatencyRecord[]>();

  async route(clientIP: string, regions: any[]): Promise<RouteDecision> {
    const activeRegions = regions.filter(r => r.status === 'active');
    if (activeRegions.length === 0) throw new Error('No active regions available');
    if (activeRegions.length === 1) {
      return {
        region: activeRegions[0].id,
        endpoint: activeRegions[0].endpoints.api,
        reason: 'failover',
        latencyEstimate: 0,
      };
    }

    // Try latency-based routing first
    const latencies = this.latencyCache.get(clientIP);
    if (latencies && latencies.length > 0) {
      const best = latencies.sort((a, b) => a.latencyMs - b.latencyMs)[0];
      const region = activeRegions.find(r => r.id === best.region);
      if (region) {
        return {
          region: region.id,
          endpoint: region.endpoints.api,
          reason: 'latency_based',
          latencyEstimate: best.latencyMs,
        };
      }
    }

    // Fall back to weight-based routing
    const totalWeight = activeRegions.reduce((s, r) => s + r.weight, 0);
    const random = Math.random() * totalWeight;
    let cumulative = 0;
    for (const region of activeRegions) {
      cumulative += region.weight;
      if (random <= cumulative) {
        return {
          region: region.id,
          endpoint: region.endpoints.api,
          reason: 'weight_based',
          latencyEstimate: 0,
        };
      }
    }

    return {
      region: activeRegions[0].id,
      endpoint: activeRegions[0].endpoints.api,
      reason: 'geo_proximity',
      latencyEstimate: 0,
    };
  }

  recordLatency(clientIP: string, region: string, latencyMs: number): void {
    const records = this.latencyCache.get(clientIP) || [];
    records.push({ region, latencyMs, measuredAt: new Date() });
    // Keep only recent measurements
    const cutoff = Date.now() - 3600000;
    this.latencyCache.set(clientIP, records.filter(r => r.measuredAt.getTime() > cutoff));
  }
}

export const geoRouter = new GeoRouter();
TS
)"

    _mrd_ok "Geo-based routing generated"
}

# =============================================================================
# Report / Score / Register
# =============================================================================
mrd_report() {
    echo -e "\n  ${BOLD}=== Multi-Region Deploy v${MRD_VERSION} ===${NC}"
    echo -e "  生成ファイル数 : ${MRD_GENERATED}"
    echo -e "  エラー         : ${MRD_ERRORS}"
    if [[ ${#MRD_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${MRD_FILES_CREATED[@]}"; do echo -e "    - ${f}"; done
    fi
}

mrd_score() {
    if [[ ${MRD_GENERATED} -ge 4 ]] && [[ ${MRD_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${MRD_GENERATED} -gt 0 ]] && [[ ${MRD_ERRORS} -eq 0 ]]; then echo "90"
    elif [[ ${MRD_GENERATED} -gt 0 ]]; then echo "70"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "multi-region-deploy" --version "369.0" \
        --description "マルチリージョンデプロイ×データ同期×Geoルーティング" \
        --init "mrd_init" --report "mrd_report" --score "mrd_score" \
        --enable-var "ENABLE_MULTI_REGION" --cli-flags "--multi-region:--no-multi-region"
fi

# v2003.1: source時のexit codeを確実に0にする
true
