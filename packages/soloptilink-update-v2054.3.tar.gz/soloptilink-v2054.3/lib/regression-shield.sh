#!/usr/bin/env bash
# ╔═══════════════════════════════════════════════════════════╗
# ║  SoloptiLinkAI v2001.0 - Regression Shield               ║
# ║  「1個直したら別が壊れる」問題の防止                      ║
# ║                                                           ║
# ║  修正前後の状態を比較し、意図しない退行を検出・ロールバック║
# ║  - git diff ベースの変更追跡                              ║
# ║  - テスト実行による回帰検出                               ║
# ║  - 自動ロールバック機能                                   ║
# ╚═══════════════════════════════════════════════════════════╝

[[ -n "${_REGRESSION_SHIELD_LOADED:-}" ]] && return 0
_REGRESSION_SHIELD_LOADED=1

readonly RS_VERSION="1.0.0"

# カラー
readonly RS_RED='\033[0;31m' RS_GREEN='\033[0;32m' RS_YELLOW='\033[0;33m'
readonly RS_CYAN='\033[0;36m' RS_BOLD='\033[1m' RS_NC='\033[0m'

# 状態
RS_PROJECT_DIR=""
RS_STASH_REF=""
RS_BACKUP_BRANCH=""
RS_PRE_TEST_RESULTS=""
RS_POST_TEST_RESULTS=""

# ============================================================
# 修復前バックアップ
# ============================================================
rs_backup_before_repair() {
    local project_dir="$1"
    RS_PROJECT_DIR="$project_dir"

    if [[ ! -d "${project_dir}/.git" ]]; then
        echo -e "  ${RS_YELLOW}⚠ git管理外: ロールバック機能は制限されます${RS_NC}" >&2
        return 0
    fi

    # 現在の変更をstash
    local has_changes
    has_changes=$(cd "$project_dir" && git status --porcelain 2>/dev/null)
    if [[ -n "$has_changes" ]]; then
        RS_STASH_REF=$(cd "$project_dir" && git stash push -m "soloptilink-repair-backup-$(date +%s)" 2>/dev/null && echo "stashed")
    fi

    # バックアップブランチ作成
    RS_BACKUP_BRANCH="soloptilink-backup-$(date +%Y%m%d-%H%M%S)"
    (cd "$project_dir" && git branch "$RS_BACKUP_BRANCH" 2>/dev/null) || true

    # stashを戻す
    if [[ "$RS_STASH_REF" == "stashed" ]]; then
        (cd "$project_dir" && git stash pop 2>/dev/null) || true
    fi

    echo -e "  ${RS_GREEN}✓ バックアップ作成: ${RS_BACKUP_BRANCH}${RS_NC}" >&2
    return 0
}

# ============================================================
# 修復前テスト実行
# ============================================================
rs_run_pre_tests() {
    local project_dir="$1"
    local results_file="/tmp/soloptilink_pretest_$$"

    echo -e "  ${RS_CYAN}修復前テスト実行中...${RS_NC}" >&2

    local test_results=""
    local pass_count=0
    local fail_count=0

    # 1. TypeScriptコンパイル
    if [[ -f "${project_dir}/tsconfig.json" ]]; then
        local tsc_result
        tsc_result=$(cd "$project_dir" && npx tsc --noEmit 2>&1; echo "EXIT:$?")
        local tsc_exit="${tsc_result##*EXIT:}"
        if [[ "$tsc_exit" == "0" ]]; then
            pass_count=$((pass_count + 1))
            test_results+="tsc:PASS\n"
        else
            fail_count=$((fail_count + 1))
            test_results+="tsc:FAIL\n"
        fi
    fi

    # 2. ビルド
    if [[ -f "${project_dir}/package.json" ]]; then
        if grep -q '"build"' "${project_dir}/package.json" 2>/dev/null; then
            local build_result
            build_result=$(cd "$project_dir" && timeout 120 npm run build 2>&1; echo "EXIT:$?")
            local build_exit="${build_result##*EXIT:}"
            if [[ "$build_exit" == "0" ]]; then
                pass_count=$((pass_count + 1))
                test_results+="build:PASS\n"
            else
                fail_count=$((fail_count + 1))
                test_results+="build:FAIL\n"
            fi
        fi
    fi

    # 3. ユニットテスト
    if [[ -f "${project_dir}/package.json" ]]; then
        if grep -q '"test"' "${project_dir}/package.json" 2>/dev/null; then
            local test_result
            test_result=$(cd "$project_dir" && timeout 120 npm test -- --passWithNoTests 2>&1; echo "EXIT:$?")
            local test_exit="${test_result##*EXIT:}"
            if [[ "$test_exit" == "0" ]]; then
                pass_count=$((pass_count + 1))
                test_results+="test:PASS\n"
            else
                fail_count=$((fail_count + 1))
                test_results+="test:FAIL\n"
            fi
        fi
    fi

    # 4. Prisma検証
    if [[ -f "${project_dir}/prisma/schema.prisma" ]]; then
        local prisma_result
        prisma_result=$(cd "$project_dir" && npx prisma validate 2>&1; echo "EXIT:$?")
        local prisma_exit="${prisma_result##*EXIT:}"
        if [[ "$prisma_exit" == "0" ]]; then
            pass_count=$((pass_count + 1))
            test_results+="prisma:PASS\n"
        else
            fail_count=$((fail_count + 1))
            test_results+="prisma:FAIL\n"
        fi
    fi

    RS_PRE_TEST_RESULTS="$test_results"
    echo -e "$test_results" > "$results_file"
    echo -e "  ${RS_CYAN}修復前: ${RS_GREEN}PASS ${pass_count}${RS_NC} / ${RS_RED}FAIL ${fail_count}${RS_NC}" >&2

    echo "$results_file"
}

# ============================================================
# 修復後検証
# ============================================================
rs_verify() {
    local project_dir="$1"
    local snapshot_before="${2:-}"
    local snapshot_after="${3:-}"
    local task_desc="${4:-}"

    echo "" >&2
    echo -e "  ${RS_BOLD}${RS_CYAN}Regression Shield 検証${RS_NC}" >&2

    local regression_detected=false

    # 1. 修復前PASSだったテストが修復後FAILになっていないか
    if [[ -n "$RS_PRE_TEST_RESULTS" ]]; then
        echo -e "  ${RS_CYAN}修復後テスト実行中...${RS_NC}" >&2

        local post_pass=0 post_fail=0
        local regressions=""

        # 修復前PASSだった項目を再テスト
        while IFS=: read -r test_name pre_result; do
            [[ -z "$test_name" ]] && continue
            if [[ "$pre_result" == "PASS" ]]; then
                # この項目を再テスト
                local post_result="UNKNOWN"
                case "$test_name" in
                    "tsc")
                        (cd "$project_dir" && npx tsc --noEmit 2>/dev/null) && post_result="PASS" || post_result="FAIL"
                        ;;
                    "build")
                        (cd "$project_dir" && timeout 120 npm run build 2>/dev/null) && post_result="PASS" || post_result="FAIL"
                        ;;
                    "test")
                        (cd "$project_dir" && timeout 120 npm test -- --passWithNoTests 2>/dev/null) && post_result="PASS" || post_result="FAIL"
                        ;;
                    "prisma")
                        (cd "$project_dir" && npx prisma validate 2>/dev/null) && post_result="PASS" || post_result="FAIL"
                        ;;
                esac

                if [[ "$post_result" == "PASS" ]]; then
                    post_pass=$((post_pass + 1))
                elif [[ "$post_result" == "FAIL" ]]; then
                    post_fail=$((post_fail + 1))
                    regressions+="  ${RS_RED}✗ ${test_name}: PASS→FAIL（リグレッション検出）${RS_NC}\n"
                    regression_detected=true
                fi
            fi
        done <<< "$(echo -e "$RS_PRE_TEST_RESULTS")"

        echo -e "  修復後: ${RS_GREEN}PASS ${post_pass}${RS_NC} / ${RS_RED}FAIL ${post_fail}${RS_NC}" >&2

        if [[ -n "$regressions" ]]; then
            echo "" >&2
            echo -e "${RS_RED}${RS_BOLD}⚠ リグレッション検出:${RS_NC}" >&2
            echo -e "$regressions" >&2
        fi
    fi

    # 2. リグレッション検出時の対応
    if [[ "$regression_detected" == "true" ]]; then
        echo "" >&2
        echo -e "${RS_YELLOW}修復によりリグレッションが発生しました。${RS_NC}" >&2
        echo -e "${RS_YELLOW}バックアップブランチ: ${RS_BACKUP_BRANCH}${RS_NC}" >&2
        echo -e "${RS_YELLOW}ロールバックするには:${RS_NC}" >&2
        echo -e "  ${RS_CYAN}cd $project_dir && git checkout ${RS_BACKUP_BRANCH}${RS_NC}" >&2
        echo "" >&2
        return 1
    fi

    echo -e "  ${RS_GREEN}✓ リグレッションなし${RS_NC}" >&2
    return 0
}

# ============================================================
# ロールバック
# ============================================================
rs_rollback() {
    local project_dir="$1"

    if [[ -z "$RS_BACKUP_BRANCH" || ! -d "${project_dir}/.git" ]]; then
        echo -e "${RS_RED}ロールバックできません（バックアップなし）${RS_NC}" >&2
        return 1
    fi

    echo -e "${RS_YELLOW}ロールバック実行中...${RS_NC}" >&2

    (cd "$project_dir" && git checkout "$RS_BACKUP_BRANCH" 2>/dev/null) || {
        echo -e "${RS_RED}ロールバック失敗${RS_NC}" >&2
        return 1
    }

    echo -e "${RS_GREEN}✓ ${RS_BACKUP_BRANCH} にロールバック完了${RS_NC}" >&2
    return 0
}

# ============================================================
# Module Registry 登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register "regression-shield" "$RS_VERSION" "リグレッションシールド（修正による退行を防止）"
    _mr_register "regression-shield" "$RS_VERSION" "rs_verify"
fi

# v2003.1: source時のexit codeを確実に0にする
true
