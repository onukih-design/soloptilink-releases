#!/usr/bin/env bash
# ==============================================================================
# quality-telemetry-reporter.sh — 品質メトリクス・テレメトリ送信 (v2041)
# ------------------------------------------------------------------------------
# 目的:
#   生成完了時に「PII を一切含まない品質メトリクス」を収集してサーバへ送り、
#   同じ PII 除外データをローカルの品質ゲノム学習層にも蓄積する。
#   本体の品質を継続改善するための統計基盤であり、顧客の業務情報・コード・
#   ファイルパス・メール等の個人情報 (PII) は構造的に送出しない。
#
# 使い方 (CLI 契約):
#   bash ~/.soloptilink/lib/quality-telemetry-reporter.sh <project_dir>
#       → 品質メトリクスを収集 → サーバへ POST → 品質ゲノムへ保存
#   bash ~/.soloptilink/lib/quality-telemetry-reporter.sh <project_dir> --dry-run
#       → 送信せず payload (1行JSON) のみ stdout に出力 (検証用)
#
# データソース (プロジェクトの実記録のみ):
#   ① <project_dir>/.soloptilink/*-results.json     … 各ゲートの判定 (verdict)
#   ② <project_dir>/.soloptilink/agent-evidence/*.md … 実起動ロール証跡の数
#   ③ 検出 DBL (環境変数 SOLOPTILINK_DETECTED_DBL か .soloptilink/detected-dbl)
#   ④ <project_dir>/(src/)prisma/schema.prisma       … model 数
#   ⑤ <project_dir>/(src/)app/**/page.{tsx,jsx,ts,js} … page 数
#
# 環境変数:
#   SOLOPTILINK_API_URL        API ベース (default: auto-update.sh と同じ既定)
#   SOLOPTILINK_DETECTED_DBL   検出済み DBL 名 (無ければ detected-dbl ファイル)
#   SOLOPTILINK_BOOST_LEVEL    Boost レベル (無ければ既定 0)
#
# 設計上の不変条件 (PII 禁制):
#   送信 payload は固定 allowlist のキーのみで「組み立てる」ホワイトリスト方式。
#   project 名 / ファイルパス / コード / 顧客データ / 業務データ / メール等は
#   いかなる経路でも payload に入らない (allowlist 外のキーは構造的に存在しない)。
#
# 送信は best-effort・非ブロッキング: 失敗しても黙殺し、生成完了は妨げない。
# exit: 0 = 正常終了 (送信失敗を含む best-effort) / 2 = 引数・環境エラー
# 依存: bash + python3 標準ライブラリ + curl (jq 非依存)
# ==============================================================================
set -uo pipefail

API_BASE="${SOLOPTILINK_API_URL:-https://admin-dashboard-blue-alpha-78.vercel.app/api/v1}"
SL_DIR="$HOME/.soloptilink"

PROJECT_DIR="${1:-}"
MODE="${2:-}"

usage() {
    cat >&2 <<'USAGE'
使い方:
  quality-telemetry-reporter.sh <project_dir>            品質メトリクスを収集→送信→学習層保存
  quality-telemetry-reporter.sh <project_dir> --dry-run  payload (1行JSON) のみ出力 (送信しない)
USAGE
}

if [[ -z "$PROJECT_DIR" || "$PROJECT_DIR" == "-h" || "$PROJECT_DIR" == "--help" ]]; then
    usage
    exit 2
fi

# project_dir の実在確認 (正規化はするが payload には絶対に入れない)
PROJECT_DIR="$(cd "$PROJECT_DIR" 2>/dev/null && pwd)" || {
    echo "❌ project_dir が見つかりません: ${1:-}" >&2
    exit 2
}

DRY_RUN="false"
if [[ "$MODE" == "--dry-run" ]]; then
    DRY_RUN="true"
elif [[ -n "$MODE" ]]; then
    echo "❌ 不明なオプションです: $MODE" >&2
    usage
    exit 2
fi

command -v python3 >/dev/null 2>&1 || {
    echo "❌ python3 が見つかりません (品質テレメトリの収集に必要です)" >&2
    exit 2
}

# 端末識別子 (実在すれば device_id / fingerprint を付与・無ければ送らない)
DEVICE_ID=""
FINGERPRINT=""
ACT_JSON="$SL_DIR/activation.json"
LIC_JSON="$SL_DIR/license.json"

read_cred() {
    # activation.json → license.json の順で device_id / fingerprint を抽出
    # (python3 で安全に読む。失敗時は空文字。allowlist 上のキーのみ取得)
    python3 - "$ACT_JSON" "$LIC_JSON" <<'CREDEOF' 2>/dev/null || true
import json, sys
act_path, lic_path = sys.argv[1], sys.argv[2]
device_id = ""
fingerprint = ""


def load(p):
    try:
        with open(p, encoding="utf-8") as fh:
            d = json.load(fh)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


act = load(act_path)
lic = load(lic_path)
for src in (act, lic):
    if not device_id:
        v = src.get("device_id")
        if isinstance(v, str) and v.strip():
            device_id = v.strip()
    if not fingerprint:
        v = src.get("fingerprint")
        if isinstance(v, str) and v.strip():
            fingerprint = v.strip()
# device_id<TAB>fingerprint の 1 行で返す
print("%s\t%s" % (device_id, fingerprint))
CREDEOF
}

CRED_LINE="$(read_cred)"
if [[ -n "$CRED_LINE" ]]; then
    DEVICE_ID="${CRED_LINE%%	*}"
    FINGERPRINT="${CRED_LINE#*	}"
    # タブが無かった場合のフォールバック (fingerprint を空に)
    [[ "$FINGERPRINT" == "$CRED_LINE" ]] && FINGERPRINT=""
fi

# 本体バージョン (VERSION ファイル → 既定)
CURRENT_VERSION="unknown"
if [[ -f "$SL_DIR/VERSION" ]]; then
    CURRENT_VERSION="$(tr -d '[:space:]' < "$SL_DIR/VERSION" 2>/dev/null || echo unknown)"
    [[ -z "$CURRENT_VERSION" ]] && CURRENT_VERSION="unknown"
fi

# 検出 DBL: 環境変数 → .soloptilink/detected-dbl ファイル
DETECTED_DBL="${SOLOPTILINK_DETECTED_DBL:-}"
if [[ -z "$DETECTED_DBL" ]]; then
    for f in "$PROJECT_DIR/.soloptilink/detected-dbl" "$PROJECT_DIR/.soloptilink/detected_dbl"; do
        if [[ -f "$f" ]]; then
            DETECTED_DBL="$(head -n1 "$f" 2>/dev/null | tr -d '[:space:]' || echo "")"
            [[ -n "$DETECTED_DBL" ]] && break
        fi
    done
fi

BOOST_LEVEL="${SOLOPTILINK_BOOST_LEVEL:-0}"

# 学習層 (品質ゲノム) のルート
GENOME_ROOT="$SL_DIR/learning/quality-genome"

# ------------------------------------------------------------------------------
# 本体: python3 (標準ライブラリのみ) で実測メトリクスを収集し、
# allowlist 方式で payload を組み立てて stdout に 1 行 JSON で出力する。
# ※ パス・各種値は argv 経由で渡す (コード内へのパス文字列展開は事故源のため禁止)。
# ------------------------------------------------------------------------------
PAYLOAD="$(python3 - \
    "$PROJECT_DIR" "$DETECTED_DBL" "$CURRENT_VERSION" "$BOOST_LEVEL" \
    "$DEVICE_ID" "$FINGERPRINT" <<'PYEOF'
# -*- coding: utf-8 -*-
# 品質メトリクス収集 + PII 禁制 allowlist payload 組み立て (実測データのみ)
import sys, os, re, json, glob

ROOT = os.path.realpath(sys.argv[1])
DETECTED_DBL = sys.argv[2] if len(sys.argv) > 2 else ""
CURRENT_VERSION = sys.argv[3] if len(sys.argv) > 3 else "unknown"
BOOST_LEVEL_RAW = sys.argv[4] if len(sys.argv) > 4 else "0"
DEVICE_ID = sys.argv[5] if len(sys.argv) > 5 else ""
FINGERPRINT = sys.argv[6] if len(sys.argv) > 6 else ""
SLD = os.path.join(ROOT, ".soloptilink")

# ==============================================================================
# 【PII 禁制】送信を許可する固定 allowlist (このキー以外は payload に入れない)
# ==============================================================================
ALLOWLIST = (
    "target_domain", "dbl_grade", "one_shot_success", "achieved_layer",
    "gates_passed", "gates_total", "crud_ok", "login_ok", "build_ok",
    "model_count", "page_count", "boost_level", "current_version",
    "details", "device_id", "fingerprint",
)

SEV = {"PASS": 1, "WARN": 2, "FAIL": 3, "BLOCK": 4}


def norm_verdict(v):
    """判定文字列を PASS/WARN/FAIL/BLOCK/NA に正規化。判定でない値は None。"""
    u = str(v).strip().upper().replace("-", "_")
    if u in ("PASS", "PASSED", "OK", "GO", "SUCCESS", "GREEN", "APPLIED"):
        return "PASS"
    if u in ("WARN", "WARNING", "YELLOW"):
        return "WARN"
    if u in ("FAIL", "FAILED", "NG", "RED", "ERROR"):
        return "FAIL"
    if u == "BLOCK":
        return "BLOCK"
    if u in ("NOT_APPLICABLE", "NA", "N/A", "SKIP", "SKIPPED", "NONE"):
        return "NA"
    return None


def collect_statuses(node, out):
    """ネストした verdict/status キーの値を再帰収集する。"""
    if isinstance(node, dict):
        for k, v in node.items():
            if k in ("verdict", "status") and isinstance(v, str):
                nv = norm_verdict(v)
                if nv:
                    out.append(nv)
            else:
                collect_statuses(v, out)
    elif isinstance(node, list):
        for v in node:
            collect_statuses(v, out)


def layer_num(s):
    m = re.match(r"[Ll](\d+)", str(s).strip())
    return int(m.group(1)) if m else None


def derive_verdict(base, d):
    """ゲートごとの実記録から判定を導出する。導出不能なら None。"""
    if base == "layered-depth":
        a, m = layer_num(d.get("achieved_layer")), layer_num(d.get("min_required"))
        if a is not None and m is not None:
            if a >= m:
                return "PASS"
            return "FAIL" if d.get("strict") is True else "WARN"
    for k in ("verdict", "status", "overall", "result"):
        v = d.get(k)
        if isinstance(v, str):
            nv = norm_verdict(v)
            if nv:
                return nv
    found = []
    collect_statuses(d, found)
    real = [v for v in found if v in SEV]
    if real:
        return max(real, key=lambda v: SEV[v])
    if "NA" in found:
        return "NA"
    return None


def has_refiner_trace(node):
    """results.json 内に refiner ループ / retry の痕跡があるか判定。"""
    if isinstance(node, dict):
        for k, v in node.items():
            kl = str(k).lower()
            if ("retry" in kl or "retries" in kl or "refiner" in kl
                    or "refine" in kl or "reattempt" in kl or "loop" in kl
                    or "attempt" in kl):
                # 数値なら 0 より大きいか、真偽なら True か、文字列なら非空かで判定
                if isinstance(v, bool):
                    if v:
                        return True
                elif isinstance(v, (int, float)):
                    if v and v > 0:
                        return True
                elif isinstance(v, str):
                    if v.strip() and v.strip().lower() not in ("0", "false", "none", "no"):
                        return True
                else:
                    # list/dict が空でなければ痕跡とみなす
                    if v:
                        return True
            if has_refiner_trace(v):
                return True
    elif isinstance(node, list):
        for v in node:
            if has_refiner_trace(v):
                return True
    return False


def count_models(root):
    """prisma/schema.prisma の model 定義数を数える ((src/)prisma 両対応)。"""
    for cand in (os.path.join(root, "prisma", "schema.prisma"),
                 os.path.join(root, "src", "prisma", "schema.prisma")):
        if os.path.isfile(cand):
            try:
                with open(cand, encoding="utf-8", errors="ignore") as fh:
                    txt = fh.read()
            except Exception:
                return 0
            return len(re.findall(r"(?m)^\s*model\s+[A-Za-z_]\w*\s*\{", txt))
    return 0


def count_pages(root):
    """(src/)app 配下の page.{tsx,jsx,ts,js} を URL ルート単位で数える。"""
    app_root = None
    for cand in (os.path.join(root, "src", "app"), os.path.join(root, "app")):
        if os.path.isdir(cand):
            app_root = cand
            break
    if not app_root:
        return 0
    seen = set()
    for dirpath, dirnames, filenames in os.walk(app_root):
        dirnames[:] = [x for x in dirnames if x not in ("node_modules", ".next", ".git")]
        if not any(fn in ("page.tsx", "page.jsx", "page.ts", "page.js") for fn in filenames):
            continue
        rel = os.path.relpath(dirpath, app_root)
        segs = [] if rel == "." else rel.split(os.sep)
        segs = [s for s in segs
                if not (s.startswith("(") and s.endswith(")")) and not s.startswith("@")]
        seen.add("/" + "/".join(segs))
    return len(seen)


# ==============================================================================
# ① 品質ゲート実記録の走査 (.soloptilink/*-results.json)
# ==============================================================================
details = {}            # ゲート名 → verdict (の文字列) のみ。実測値や付帯情報は入れない
verdicts = {}           # ゲート名 → 正規化 verdict
refiner_seen = False
achieved_layer = None

for path in sorted(glob.glob(os.path.join(SLD, "*-results.json"))):
    base = os.path.basename(path)[: -len("-results.json")]
    try:
        with open(path, encoding="utf-8") as fh:
            data = json.load(fh)
    except Exception:
        continue
    if not isinstance(data, dict):
        continue
    verdict = derive_verdict(base, data)
    if verdict is None:
        continue
    details[base] = verdict        # ★ allowlist: ゲート名 → verdict のみ (パス・コード・値を含めない)
    verdicts[base] = verdict
    if has_refiner_trace(data):
        refiner_seen = True
    # achieved_layer は deep-system の結果を最優先、無ければ layered-depth から
    al = data.get("achieved_layer")
    if isinstance(al, str) and al.strip():
        if base == "deep-system":
            achieved_layer = al.strip()
        elif achieved_layer is None:
            achieved_layer = al.strip()

gates_total = len(verdicts)
gates_passed = sum(1 for v in verdicts.values() if v == "PASS")

# ==============================================================================
# 主要ゲート判定 (実DBログイン / CRUD / フォーム / 深さ / build)
# ※ results ファイル名の表記ゆれを吸収して照合する
# ==============================================================================
def gate_verdict(*name_substrings):
    """ファイル名(base)に部分一致する主要ゲートの verdict を返す (無ければ None)。"""
    for base, v in verdicts.items():
        bl = base.lower()
        if any(sub in bl for sub in name_substrings):
            return v
    return None


login_v = gate_verdict("login", "runtime-login", "deploy-login", "auth")
crud_v = gate_verdict("crud", "crud-input")
form_v = gate_verdict("form-critical", "form", "fcpg")
depth_v = gate_verdict("layered-depth", "deep-system", "depth")
build_v = gate_verdict("build", "compile", "next-build")

login_ok = (login_v == "PASS")
crud_ok = (crud_v == "PASS")
build_ok = (build_v == "PASS")

# one_shot_success: 主要ゲート (login/crud/form/depth/build) のうち
# 実在するものが全て PASS かつ refiner/retry 痕跡が無い場合に true。
core_present = [v for v in (login_v, crud_v, form_v, depth_v, build_v) if v is not None]
one_shot_success = bool(core_present) and all(v == "PASS" for v in core_present) and not refiner_seen

# ==============================================================================
# ② 実起動ロール証跡数 (agent-evidence/*.md の非空ファイル実数)
#    ※ 件数のみを使う。ファイル名・内容は payload に一切入れない。
# ==============================================================================
agent_evidence_count = 0
ev_dir = os.path.join(SLD, "agent-evidence")
if os.path.isdir(ev_dir):
    for fn in os.listdir(ev_dir):
        if not fn.endswith(".md"):
            continue
        fp = os.path.join(ev_dir, fn)
        try:
            if os.path.isfile(fp) and os.path.getsize(fp) > 0:
                agent_evidence_count += 1
        except OSError:
            continue

# ==============================================================================
# DBL グレード: detect 結果ファイル等の grade を採用 (無ければ "" )
#  ・layered-depth-results.json の dbl.grade
#  ・.soloptilink/detected-dbl-grade ファイル
# ==============================================================================
dbl_grade = ""
ld_path = os.path.join(SLD, "layered-depth-results.json")
if os.path.isfile(ld_path):
    try:
        with open(ld_path, encoding="utf-8") as fh:
            ld = json.load(fh)
        g = ld.get("dbl", {}).get("grade") if isinstance(ld.get("dbl"), dict) else None
        if isinstance(g, str) and g.strip():
            dbl_grade = g.strip().upper()
    except Exception:
        pass
if not dbl_grade:
    gf = os.path.join(SLD, "detected-dbl-grade")
    if os.path.isfile(gf):
        try:
            with open(gf, encoding="utf-8") as fh:
                line = fh.readline().strip()
            if line:
                dbl_grade = line.upper()
        except Exception:
            pass

# ==============================================================================
# boost_level の正規化 (整数化できなければ 0)
# ==============================================================================
try:
    boost_level = int(str(BOOST_LEVEL_RAW).strip())
except Exception:
    boost_level = 0

# ==============================================================================
# 【PII 禁制】allowlist のみで payload を構築 (ホワイトリスト方式)
#   ここで定義する candidate のうち ALLOWLIST に載るキーだけが出力される。
#   project 名・パス・コード・業務データ・メールは candidate にそもそも入れない。
# ==============================================================================
candidate = {
    "target_domain": DETECTED_DBL or "",
    "dbl_grade": dbl_grade,
    "one_shot_success": one_shot_success,
    "achieved_layer": achieved_layer or "",
    "gates_passed": gates_passed,
    "gates_total": gates_total,
    "crud_ok": crud_ok,
    "login_ok": login_ok,
    "build_ok": build_ok,
    "model_count": count_models(ROOT),
    "page_count": count_pages(ROOT),
    "boost_level": boost_level,
    "current_version": CURRENT_VERSION,
    "details": details,   # ゲート名 → verdict のみ (上で厳格に構築済み)
}
# device_id / fingerprint は実在時のみ付与
if DEVICE_ID:
    candidate["device_id"] = DEVICE_ID
if FINGERPRINT:
    candidate["fingerprint"] = FINGERPRINT

# ★ 最終ガード: allowlist 外のキーは構造的に弾く
payload = {k: candidate[k] for k in ALLOWLIST if k in candidate}

# ★★ PII 構造防御の核 (監査指摘): allowlist の「キー」だけでなく各フィールドの「値」も
# 厳格な書式に正規化する。target_domain / dbl_grade / achieved_layer / current_version /
# device_id / fingerprint は『その書式以外を構造的に弾く』ことで、検出DBL名や環境変数に
# 万一パス・メール等が紛れても payload に混入しない不変条件を値レベルで成立させる。
import re as _re
def _san(val, pattern, maxlen, default=""):
    s = str(val) if val is not None else ""
    s = s[:maxlen]
    return s if _re.fullmatch(pattern, s) else default
if "target_domain" in payload:
    # target_domain は本来「登録済み DBL 識別子」しか取り得ない。記号除去では英数字語
    # (secret/tanaka 等)が連結して残るため、実在する登録 DBL 名の集合と完全一致照合し、
    # 一致しなければ "unregistered" に落とす。これで任意の文字列・パス・メールは構造的に
    # 通れず、payload に出るのは必ず実在 DBL 名か "unregistered"/"unknown" のみになる。
    _dom_dir = os.environ.get("SOLOPTILINK_DOMAINS_DIR") or os.path.expanduser("~/.soloptilink/domains")
    _valid = set()
    try:
        for _f in os.listdir(_dom_dir):
            if _f.endswith(".json") and not _f.startswith("_"):
                _valid.add(_f[:-5])
    except OSError:
        _valid = set()
    _td = _re.sub(r"[^a-z0-9_-]", "", str(payload["target_domain"]).lower())[:64]
    if _td and _td in _valid:
        payload["target_domain"] = _td
    elif _td:
        payload["target_domain"] = "unregistered"   # 未登録業種 (一発完成率の分析でも有意)
    else:
        payload["target_domain"] = "unknown"
if "dbl_grade" in payload:
    g = str(payload["dbl_grade"]).strip().upper()
    payload["dbl_grade"] = g if g in ("DEEP", "STUB", "LEGACY", "NONE") else "unknown"
if "achieved_layer" in payload:
    payload["achieved_layer"] = _san(payload["achieved_layer"], r"L[0-6]", 2, "")
if "current_version" in payload:
    payload["current_version"] = _san(payload["current_version"], r"[0-9][0-9.]*", 20, "unknown")
for _idk in ("device_id", "fingerprint"):
    if _idk in payload:
        payload[_idk] = _re.sub(r"[^A-Za-z0-9_-]", "", str(payload[_idk]))[:128]

# details も「ゲート名 → 短い verdict 文字列」だけであることを最終検証 (PII 二重防御)
# 値(verdict)だけでなくキー(ゲート名)も固定書式に制限する: ゲート名は本体固定語彙
# (login / crud-input / build 等) のため [A-Za-z0-9_-] 40字以内のみ通し、それ以外は捨てる。
safe_details = {}
for k, v in (payload.get("details") or {}).items():
    sk = str(k)
    sv = str(v).strip().upper()
    if not _re.fullmatch(r"[A-Za-z0-9_-]{1,40}", sk):
        continue  # ファイル名に万一パス・非ASCIIが混じってもキーごと弾く
    # verdict 集合に正規化できる値のみ通す (生ログ・パス・コードが紛れ込むのを防ぐ)
    if sv in ("PASS", "WARN", "FAIL", "BLOCK", "NA"):
        safe_details[sk] = sv
payload["details"] = safe_details

# 1 行 JSON で stdout に出す (ensure_ascii=True で非ASCIIもエスケープ)
sys.stdout.write(json.dumps(payload, ensure_ascii=False))
PYEOF
)"

if [[ -z "$PAYLOAD" ]]; then
    # 収集に失敗しても生成完了は妨げない (best-effort)
    echo "⚠️ 品質メトリクスを収集できませんでした (送信・保存をスキップします)" >&2
    exit 0
fi

# target_domain を学習層の保存先サブディレクトリに使う (英数・ハイフン以外は除去)
TARGET_DOMAIN="$(printf '%s' "$PAYLOAD" | python3 -c '
import sys, json, re
try:
    d = json.load(sys.stdin)
    t = str(d.get("target_domain") or "").strip()
except Exception:
    t = ""
t = re.sub(r"[^A-Za-z0-9_-]", "", t)
print(t or "unknown")
' 2>/dev/null || echo "unknown")"
[[ -z "$TARGET_DOMAIN" ]] && TARGET_DOMAIN="unknown"

# --dry-run: payload を stdout に出して終了 (送信・保存ともにしない)
if [[ "$DRY_RUN" == "true" ]]; then
    printf '%s\n' "$PAYLOAD"
    exit 0
fi

# ------------------------------------------------------------------------------
# ① ローカル学習層 (品質ゲノム) へ保存: 同じ PII 除外 JSON を蓄積する
#    保存先: learning/quality-genome/<target_domain>/<timestamp>.json
# ------------------------------------------------------------------------------
TS="$(date +%Y%m%dT%H%M%S 2>/dev/null || echo unknown)"
GENOME_DIR="$GENOME_ROOT/$TARGET_DOMAIN"
mkdir -p "$GENOME_DIR" 2>/dev/null || true
if [[ -d "$GENOME_DIR" ]]; then
    GENOME_FILE="$GENOME_DIR/$TS.json"
    # 同一秒の衝突回避
    if [[ -e "$GENOME_FILE" ]]; then
        GENOME_FILE="$GENOME_DIR/${TS}_$$.json"
    fi
    printf '%s\n' "$PAYLOAD" > "$GENOME_FILE" 2>/dev/null || true
fi

# ------------------------------------------------------------------------------
# ② サーバへ送信 (best-effort・非ブロッキング・失敗は黙殺)
#    POST {API_BASE}/quality-telemetry  Content-Type: application/json
# ------------------------------------------------------------------------------
if command -v curl >/dev/null 2>&1; then
    curl -s --max-time 8 \
        -X POST \
        -H "Content-Type: application/json" \
        --data-binary "$PAYLOAD" \
        "$API_BASE/quality-telemetry" >/dev/null 2>&1 || true
fi

# best-effort のため常に正常終了 (生成完了をブロックしない)
exit 0
