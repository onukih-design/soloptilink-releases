#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v354.0 - Preview Environment Engine
# =============================================================================
# PRプレビュー環境×自動デプロイ×クリーンアップ
#
# 機能:
#   - PR毎のプレビュー環境自動作成
#   - Docker Compose / Vercel / Fly.io 対応
#   - PR Close時の自動クリーンアップ
#   - プレビューURL通知（GitHub Comment）
#   - TTLベースの自動削除
#
# 全globals: PE_ prefix
# =============================================================================

[[ -n "${_PE_LOADED:-}" ]] && return 0; _PE_LOADED=1

PE_VERSION="354.0"
PE_GENERATED=0
PE_ERRORS=0
PE_PHASE="preview_env"
PE_FILES_CREATED=()
PE_ENVS_CREATED=0

: "${GREEN:=\033[0;32m}" ; : "${RED:=\033[0;31m}" ; : "${YELLOW:=\033[0;33m}"
: "${CYAN:=\033[0;36m}" ; : "${BOLD:=\033[1m}" ; : "${NC:=\033[0m}"

_pe_log() { echo -e "  ${CYAN}[PE]${NC} $*"; }
_pe_ok() { echo -e "  ${GREEN}[PE]${NC} $*"; }
_pe_warn() { echo -e "  ${YELLOW}[PE]${NC} $*"; }
_pe_err() { echo -e "  ${RED}[PE]${NC} $*"; }

_pe_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        PE_FILES_CREATED+=("$filepath")
        PE_GENERATED=$((PE_GENERATED + 1))
        _pe_ok "Created: ${filepath##*/}"
    else
        PE_ERRORS=$((PE_ERRORS + 1))
        _pe_err "Failed: ${filepath##*/}"
    fi
}

pe_init() {
    PE_GENERATED=0; PE_ERRORS=0; PE_ENVS_CREATED=0; PE_FILES_CREATED=()
    _pe_log "Preview Environment Engine v${PE_VERSION} initialized"
    return 0
}

# =============================================================================
# Create Preview
# =============================================================================
_pe_create_preview() {
    local project_dir="${1:-.}"
    local platform="${2:-docker}"

    _pe_log "Generating preview environment system (${platform})..."

    local preview_dir="${project_dir}/infra/preview"
    mkdir -p "$preview_dir" 2>/dev/null

    _pe_write_file "${preview_dir}/preview-manager.ts" "$(cat <<'TS'
// Preview Environment Manager
interface PreviewEnv {
  id: string;
  prNumber: number;
  branch: string;
  url: string;
  status: 'creating' | 'running' | 'stopping' | 'stopped' | 'error';
  createdAt: Date;
  ttlHours: number;
  dbName: string;
}

class PreviewManager {
  private envs = new Map<string, PreviewEnv>();

  async create(prNumber: number, branch: string): Promise<PreviewEnv> {
    const id = `preview-pr-${prNumber}`;
    const env: PreviewEnv = {
      id,
      prNumber,
      branch,
      url: `https://pr-${prNumber}.preview.example.com`,
      status: 'creating',
      createdAt: new Date(),
      ttlHours: 48,
      dbName: `preview_pr_${prNumber}`,
    };
    this.envs.set(id, env);
    await this.provisionResources(env);
    env.status = 'running';
    return env;
  }

  async destroy(prNumber: number): Promise<void> {
    const id = `preview-pr-${prNumber}`;
    const env = this.envs.get(id);
    if (!env) return;
    env.status = 'stopping';
    await this.cleanupResources(env);
    env.status = 'stopped';
    this.envs.delete(id);
  }

  async cleanupExpired(): Promise<number> {
    const now = Date.now();
    let cleaned = 0;
    for (const [id, env] of this.envs) {
      const expiresAt = env.createdAt.getTime() + env.ttlHours * 3600000;
      if (now > expiresAt) {
        await this.destroy(env.prNumber);
        cleaned++;
      }
    }
    return cleaned;
  }

  private async provisionResources(env: PreviewEnv): Promise<void> {
    console.log(`[Preview] Provisioning ${env.id}: DB=${env.dbName}, URL=${env.url}`);
  }

  private async cleanupResources(env: PreviewEnv): Promise<void> {
    console.log(`[Preview] Cleaning up ${env.id}`);
  }

  list(): PreviewEnv[] { return Array.from(this.envs.values()); }
}

export const previewManager = new PreviewManager();
TS
)"

    case "$platform" in
        docker)
            _pe_generate_docker_preview "$preview_dir"
            ;;
        vercel)
            _pe_generate_vercel_preview "$preview_dir"
            ;;
        *)
            _pe_generate_docker_preview "$preview_dir"
            ;;
    esac

    _pe_generate_preview_ci "$project_dir"

    PE_ENVS_CREATED=$((PE_ENVS_CREATED + 1))
    _pe_ok "Preview environment system generated"
}

_pe_generate_docker_preview() {
    local dir="$1"

    _pe_write_file "${dir}/docker-compose.preview.yml" "$(cat <<'YAML'
version: '3.8'
services:
  app:
    build:
      context: ../..
      dockerfile: Dockerfile
    ports:
      - "${PORT:-3000}:3000"
    environment:
      DATABASE_URL: postgres://preview:preview@db:5432/${DB_NAME:-preview}
      NODE_ENV: preview
      PREVIEW_PR: ${PR_NUMBER}
    depends_on:
      db:
        condition: service_healthy

  db:
    image: postgres:16-alpine
    environment:
      POSTGRES_USER: preview
      POSTGRES_PASSWORD: preview
      POSTGRES_DB: ${DB_NAME:-preview}
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U preview"]
      interval: 5s
      timeout: 5s
      retries: 5
    volumes:
      - preview_data:/var/lib/postgresql/data
    tmpfs:
      - /tmp

volumes:
  preview_data:
YAML
)"

    _pe_write_file "${dir}/preview-deploy.sh" "$(cat <<'BASH'
#!/usr/bin/env bash
set -euo pipefail

PR_NUMBER="${1:?PR number required}"
BRANCH="${2:?Branch name required}"
PORT=$((3000 + PR_NUMBER % 1000))
DB_NAME="preview_pr_${PR_NUMBER}"

export PR_NUMBER BRANCH PORT DB_NAME

echo "[Preview] Starting preview for PR #${PR_NUMBER} on port ${PORT}..."

docker compose -f infra/preview/docker-compose.preview.yml \
  -p "preview-pr-${PR_NUMBER}" \
  up -d --build

echo "[Preview] Environment ready: http://localhost:${PORT}"
BASH
)"
}

_pe_generate_vercel_preview() {
    local dir="$1"

    _pe_write_file "${dir}/vercel-preview.json" "$(cat <<'JSON'
{
  "github": {
    "enabled": true
  },
  "preview": {
    "autoAlias": true,
    "domains": ["preview-{branch}.example.com"],
    "env": {
      "NODE_ENV": "preview",
      "DATABASE_URL": "@preview-db-url"
    }
  }
}
JSON
)"
}

# =============================================================================
# Deploy PR
# =============================================================================
_pe_deploy_pr() {
    local project_dir="${1:-.}"
    local pr_number="${2:-0}"

    _pe_log "Generating PR deploy automation for PR #${pr_number}..."

    local ci_dir="${project_dir}/.github/workflows"
    mkdir -p "$ci_dir" 2>/dev/null

    _pe_write_file "${ci_dir}/preview-deploy.yml" "$(cat <<'YAML'
name: Preview Deploy
on:
  pull_request:
    types: [opened, synchronize, reopened]

concurrency:
  group: preview-${{ github.event.pull_request.number }}
  cancel-in-progress: true

jobs:
  deploy-preview:
    runs-on: ubuntu-latest
    permissions:
      pull-requests: write
    steps:
      - uses: actions/checkout@v4

      - name: Deploy Preview
        id: deploy
        run: |
          PR_NUM=${{ github.event.pull_request.number }}
          echo "url=https://pr-${PR_NUM}.preview.example.com" >> "$GITHUB_OUTPUT"

      - name: Comment PR
        uses: actions/github-script@v7
        with:
          script: |
            const url = '${{ steps.deploy.outputs.url }}';
            github.rest.issues.createComment({
              issue_number: context.issue.number,
              owner: context.repo.owner,
              repo: context.repo.repo,
              body: `## Preview Environment\n\nDeployed to: ${url}\n\nThis preview will be automatically cleaned up when the PR is closed.`
            });
YAML
)"

    _pe_ok "PR deploy automation generated"
}

# =============================================================================
# Cleanup Preview
# =============================================================================
_pe_cleanup_preview() {
    local project_dir="${1:-.}"

    _pe_log "Generating preview cleanup automation..."

    local ci_dir="${project_dir}/.github/workflows"
    mkdir -p "$ci_dir" 2>/dev/null

    _pe_write_file "${ci_dir}/preview-cleanup.yml" "$(cat <<'YAML'
name: Preview Cleanup
on:
  pull_request:
    types: [closed]
  schedule:
    - cron: '0 2 * * *'

jobs:
  cleanup:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Cleanup Preview
        run: |
          if [ "${{ github.event_name }}" = "pull_request" ]; then
            PR_NUM=${{ github.event.pull_request.number }}
            echo "Cleaning up preview for PR #${PR_NUM}..."
            docker compose -p "preview-pr-${PR_NUM}" down -v 2>/dev/null || true
          else
            echo "Running scheduled cleanup of expired previews..."
          fi
YAML
)"

    _pe_write_file "${project_dir}/infra/preview/cleanup.sh" "$(cat <<'BASH'
#!/usr/bin/env bash
set -euo pipefail
# Cleanup expired preview environments (TTL: 48 hours)

MAX_AGE_HOURS="${1:-48}"
NOW=$(date +%s)

docker ps --filter "label=com.docker.compose.project" --format '{{.Labels}}' | \
  grep "preview-pr-" | sort -u | while read -r project; do
    CREATED=$(docker inspect --format '{{.Created}}' "$(docker compose -p "$project" ps -q | head -1)" 2>/dev/null || echo "")
    if [[ -n "$CREATED" ]]; then
      CREATED_TS=$(date -d "$CREATED" +%s 2>/dev/null || date -jf "%Y-%m-%dT%H:%M:%S" "$CREATED" +%s 2>/dev/null || echo "0")
      AGE_HOURS=$(( (NOW - CREATED_TS) / 3600 ))
      if [[ $AGE_HOURS -gt $MAX_AGE_HOURS ]]; then
        echo "[Cleanup] Removing expired preview: $project (${AGE_HOURS}h old)"
        docker compose -p "$project" down -v 2>/dev/null || true
      fi
    fi
  done

echo "[Cleanup] Done"
BASH
)"

    _pe_ok "Preview cleanup automation generated"
}

# =============================================================================
# Report / Score / Register
# =============================================================================
pe_report() {
    echo -e "\n  ${BOLD}=== Preview Environment Engine v${PE_VERSION} ===${NC}"
    echo -e "  生成ファイル数 : ${PE_GENERATED}"
    echo -e "  エラー         : ${PE_ERRORS}"
    echo -e "  環境作成数     : ${PE_ENVS_CREATED}"
    if [[ ${#PE_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${PE_FILES_CREATED[@]}"; do echo -e "    - ${f}"; done
    fi
}

pe_score() {
    if [[ ${PE_GENERATED} -ge 5 ]] && [[ ${PE_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${PE_GENERATED} -gt 0 ]] && [[ ${PE_ERRORS} -eq 0 ]]; then echo "90"
    elif [[ ${PE_GENERATED} -gt 0 ]]; then echo "70"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "preview-environment" --version "354.0" \
        --description "PRプレビュー環境×自動デプロイ×クリーンアップ" \
        --init "pe_init" --report "pe_report" --score "pe_score" \
        --enable-var "ENABLE_PREVIEW_ENV" --cli-flags "--preview-env:--no-preview-env"
fi

# v2003.1: source時のexit codeを確実に0にする
true
