#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v262.0 - Dependency Conflict Resolver
# =============================================================================
# npm/yarn/pnpm 依存パッケージのバージョン競合を検出し、自動解決する。
# peer dependency 警告、バージョン互換性問題、代替パッケージ提案を行う。
#
# Functions:
#   _dcr_init               - 初期化
#   _dcr_detect_conflicts   - 依存バージョン競合を検出
#   _dcr_find_peer_dep_issues - peer dependency 警告/エラーを検出
#   _dcr_suggest_resolutions - バージョン解決策を提案
#   _dcr_find_alternatives  - 代替パッケージを検索
#   _dcr_apply_resolution   - 解決策を適用
#   _dcr_report             - レポート出力
#   _dcr_score              - モジュールスコア (0-100)
#
# All globals use the DCR_ prefix.
# =============================================================================

[[ -n "${_DEPENDENCY_CONFLICT_RESOLVER_LOADED:-}" ]] && return 0
_DEPENDENCY_CONFLICT_RESOLVER_LOADED=1

DCR_VERSION="262.0"
DCR_INITIALIZED=false

# Counters
DCR_CONFLICTS_FOUND=0
DCR_PEER_ISSUES=0
DCR_RESOLUTIONS_APPLIED=0
DCR_ALTERNATIVES_FOUND=0

# Storage
DCR_CACHE_DIR=""

# Conflict arrays
declare -g -a _DCR_CONFLICTS=()
declare -g -a _DCR_PEER_WARNINGS=()
declare -g -a _DCR_PEER_ERRORS=()
declare -g -A _DCR_RESOLUTIONS=()

# Colors
_DCR_GREEN='\033[0;32m'
_DCR_YELLOW='\033[0;33m'
_DCR_RED='\033[0;31m'
_DCR_CYAN='\033[0;36m'
_DCR_BOLD='\033[1m'
_DCR_NC='\033[0m'

# =============================================================================
# _dcr_init - Initialize dependency conflict resolver
# =============================================================================
_dcr_init() {
    DCR_CACHE_DIR="${HOME}/.soloptilink/dep-conflicts"
    mkdir -p "$DCR_CACHE_DIR" 2>/dev/null || true

    DCR_CONFLICTS_FOUND=0
    DCR_PEER_ISSUES=0
    DCR_RESOLUTIONS_APPLIED=0
    DCR_ALTERNATIVES_FOUND=0

    _DCR_CONFLICTS=()
    _DCR_PEER_WARNINGS=()
    _DCR_PEER_ERRORS=()
    _DCR_RESOLUTIONS=()

    DCR_INITIALIZED=true
    return 0
}

# =============================================================================
# _dcr_detect_conflicts - Detect dependency version conflicts
# =============================================================================
_dcr_detect_conflicts() {
    local project_dir="${1:-.}"
    local pkg_json="${project_dir}/package.json"

    [[ ! -f "$pkg_json" ]] && { echo -e "${_DCR_RED}[DCR]${_DCR_NC} package.json not found" >&2; return 1; }

    echo -e "${_DCR_CYAN}[DCR]${_DCR_NC} 依存競合を検出中..." >&2
    _DCR_CONFLICTS=()

    # Check for duplicate packages with different versions in lock file
    local lock_file=""
    if [[ -f "${project_dir}/package-lock.json" ]]; then
        lock_file="${project_dir}/package-lock.json"
    elif [[ -f "${project_dir}/yarn.lock" ]]; then
        lock_file="${project_dir}/yarn.lock"
    elif [[ -f "${project_dir}/pnpm-lock.yaml" ]]; then
        lock_file="${project_dir}/pnpm-lock.yaml"
    fi

    # Check npm ls for deduplication issues
    if command -v npm &>/dev/null; then
        local npm_ls_output
        npm_ls_output=$(cd "$project_dir" && npm ls --all --json 2>/dev/null) || true

        if [[ -n "$npm_ls_output" ]]; then
            # Find packages with "invalid" or "extraneous" flags
            local invalid_pkgs
            invalid_pkgs=$(echo "$npm_ls_output" | grep -oE '"[^"]+": \{[^}]*"invalid"' | head -20)
            if [[ -n "$invalid_pkgs" ]]; then
                while IFS= read -r pkg; do
                    local pkg_name
                    pkg_name=$(echo "$pkg" | grep -oE '^"[^"]+"' | tr -d '"')
                    _DCR_CONFLICTS+=("INVALID:${pkg_name}")
                done <<< "$invalid_pkgs"
            fi

            # Find missing peer deps
            local missing_deps
            missing_deps=$(echo "$npm_ls_output" | grep -oE '"missing":\s*true' -c 2>/dev/null || echo "0")
            if [[ "$missing_deps" -gt 0 ]]; then
                echo -e "${_DCR_YELLOW}[DCR]${_DCR_NC}   ${missing_deps}件の未解決依存を検出" >&2
            fi
        fi
    fi

    # Check for version range conflicts between deps and devDeps
    local deps dev_deps
    deps=$(grep -oE '"[^"]+"\s*:\s*"[^"]+"' "$pkg_json" 2>/dev/null | head -100)

    # Check for known conflicting package pairs
    _dcr_check_known_conflicts "$project_dir"

    # Check for React version mismatch
    _dcr_check_react_version_mismatch "$project_dir"

    # Check for Next.js / React compatibility
    _dcr_check_nextjs_compat "$project_dir"

    DCR_CONFLICTS_FOUND=${#_DCR_CONFLICTS[@]}
    echo -e "${_DCR_CYAN}[DCR]${_DCR_NC} 競合検出完了: ${DCR_CONFLICTS_FOUND}件" >&2
    return 0
}

# =============================================================================
# _dcr_check_known_conflicts - Check for known conflicting package pairs
# =============================================================================
_dcr_check_known_conflicts() {
    local project_dir="${1:-.}"
    local pkg_json="${project_dir}/package.json"

    # Known conflict pairs
    declare -a conflict_pairs=(
        "react:react-dom"
        "@types/react:@types/react-dom"
        "typescript:@typescript-eslint/parser"
        "eslint:@typescript-eslint/eslint-plugin"
        "next:react"
        "prisma:@prisma/client"
    )

    for pair in "${conflict_pairs[@]}"; do
        local pkg_a="${pair%%:*}"
        local pkg_b="${pair##*:}"

        local ver_a ver_b
        ver_a=$(grep -oE "\"${pkg_a}\"\s*:\s*\"[^\"]+\"" "$pkg_json" 2>/dev/null | grep -oE '"[0-9^~>=<][^"]*"' | tr -d '"')
        ver_b=$(grep -oE "\"${pkg_b}\"\s*:\s*\"[^\"]+\"" "$pkg_json" 2>/dev/null | grep -oE '"[0-9^~>=<][^"]*"' | tr -d '"')

        if [[ -n "$ver_a" && -n "$ver_b" ]]; then
            # Extract major versions
            local major_a major_b
            major_a=$(echo "$ver_a" | grep -oE '[0-9]+' | head -1)
            major_b=$(echo "$ver_b" | grep -oE '[0-9]+' | head -1)

            # For paired packages, majors should match
            if [[ "$pkg_a" == "react" && "$pkg_b" == "react-dom" ]]; then
                if [[ "$major_a" != "$major_b" ]]; then
                    _DCR_CONFLICTS+=("VERSION_MISMATCH:${pkg_a}@${ver_a}:${pkg_b}@${ver_b}")
                    echo -e "${_DCR_YELLOW}[DCR]${_DCR_NC}   バージョン不一致: ${pkg_a}@${ver_a} vs ${pkg_b}@${ver_b}" >&2
                fi
            fi

            if [[ "$pkg_a" == "prisma" && "$pkg_b" == "@prisma/client" ]]; then
                if [[ "$ver_a" != "$ver_b" ]]; then
                    _DCR_CONFLICTS+=("VERSION_MISMATCH:${pkg_a}@${ver_a}:${pkg_b}@${ver_b}")
                    echo -e "${_DCR_YELLOW}[DCR]${_DCR_NC}   Prisma バージョン不一致: ${pkg_a}@${ver_a} vs ${pkg_b}@${ver_b}" >&2
                fi
            fi
        fi
    done
}

# =============================================================================
# _dcr_check_react_version_mismatch - Check React ecosystem versions
# =============================================================================
_dcr_check_react_version_mismatch() {
    local project_dir="${1:-.}"
    local node_modules="${project_dir}/node_modules"
    [[ ! -d "$node_modules" ]] && return 0

    # Find all react versions installed
    local react_versions
    react_versions=$(find "$node_modules" -name "package.json" -path "*/react/package.json" 2>/dev/null | while read -r f; do
        grep -oE '"version"\s*:\s*"[^"]+"' "$f" 2>/dev/null | head -1
    done | sort -u)

    local version_count
    version_count=$(echo "$react_versions" | grep -c 'version' 2>/dev/null || echo "0")
    if [[ "$version_count" -gt 1 ]]; then
        _DCR_CONFLICTS+=("DUPLICATE:react:${version_count} versions installed")
        echo -e "${_DCR_RED}[DCR]${_DCR_NC}   React が${version_count}バージョンインストールされています" >&2
    fi
}

# =============================================================================
# _dcr_check_nextjs_compat - Check Next.js compatibility
# =============================================================================
_dcr_check_nextjs_compat() {
    local project_dir="${1:-.}"
    local pkg_json="${project_dir}/package.json"

    local next_ver
    next_ver=$(grep -oE '"next"\s*:\s*"[^"]+"' "$pkg_json" 2>/dev/null | grep -oE '[0-9]+\.[0-9]+' | head -1)
    [[ -z "$next_ver" ]] && return 0

    local next_major
    next_major=$(echo "$next_ver" | cut -d. -f1)

    local react_ver
    react_ver=$(grep -oE '"react"\s*:\s*"[^"]+"' "$pkg_json" 2>/dev/null | grep -oE '[0-9]+' | head -1)

    # Next.js 14+ requires React 18+
    if [[ "${next_major:-0}" -ge 14 && "${react_ver:-0}" -lt 18 ]]; then
        _DCR_CONFLICTS+=("COMPAT:next@${next_ver}:requires react@18+")
        echo -e "${_DCR_RED}[DCR]${_DCR_NC}   Next.js ${next_ver} は React 18+ が必要" >&2
    fi

    # Next.js 15+ requires React 19
    if [[ "${next_major:-0}" -ge 15 && "${react_ver:-0}" -lt 19 ]]; then
        _DCR_CONFLICTS+=("COMPAT:next@${next_ver}:recommends react@19")
        echo -e "${_DCR_YELLOW}[DCR]${_DCR_NC}   Next.js ${next_ver} は React 19 を推奨" >&2
    fi
}

# =============================================================================
# _dcr_find_peer_dep_issues - Find peer dependency warnings/errors
# =============================================================================
_dcr_find_peer_dep_issues() {
    local project_dir="${1:-.}"

    echo -e "${_DCR_CYAN}[DCR]${_DCR_NC} peer dependency 問題を検索中..." >&2
    _DCR_PEER_WARNINGS=()
    _DCR_PEER_ERRORS=()

    # Run npm install --dry-run to check peer deps
    local npm_output
    npm_output=$(cd "$project_dir" && npm install --dry-run 2>&1) || true

    if [[ -n "$npm_output" ]]; then
        # Extract peer dep warnings
        while IFS= read -r line; do
            if echo "$line" | grep -qiE 'peer dep|ERESOLVE|peer dependency'; then
                if echo "$line" | grep -qi 'error'; then
                    _DCR_PEER_ERRORS+=("$line")
                else
                    _DCR_PEER_WARNINGS+=("$line")
                fi
            fi
        done <<< "$npm_output"
    fi

    # Also check node_modules for unmet peer deps
    local node_modules="${project_dir}/node_modules"
    if [[ -d "$node_modules" ]]; then
        local peer_check
        peer_check=$(cd "$project_dir" && npm ls 2>&1 | grep -i "peer dep" | head -20) || true
        if [[ -n "$peer_check" ]]; then
            while IFS= read -r line; do
                _DCR_PEER_WARNINGS+=("$line")
            done <<< "$peer_check"
        fi
    fi

    DCR_PEER_ISSUES=$(( ${#_DCR_PEER_WARNINGS[@]} + ${#_DCR_PEER_ERRORS[@]} ))
    echo -e "${_DCR_CYAN}[DCR]${_DCR_NC} peer dep 問題: 警告=${#_DCR_PEER_WARNINGS[@]} エラー=${#_DCR_PEER_ERRORS[@]}" >&2
    return 0
}

# =============================================================================
# _dcr_suggest_resolutions - Suggest version resolutions
# =============================================================================
_dcr_suggest_resolutions() {
    local project_dir="${1:-.}"
    local pkg_json="${project_dir}/package.json"

    echo -e "${_DCR_CYAN}[DCR]${_DCR_NC} 解決策を生成中..." >&2
    _DCR_RESOLUTIONS=()

    for conflict in "${_DCR_CONFLICTS[@]}"; do
        local conflict_type="${conflict%%:*}"
        local conflict_detail="${conflict#*:}"

        case "$conflict_type" in
            VERSION_MISMATCH)
                local pkg_a_info="${conflict_detail%%:*}"
                local pkg_b_info="${conflict_detail#*:}"
                local pkg_a="${pkg_a_info%%@*}"
                local pkg_b="${pkg_b_info%%@*}"
                local ver_b="${pkg_b_info#*@}"

                # Suggest upgrading the lower version
                _DCR_RESOLUTIONS["$conflict"]="npm install ${pkg_a}@${ver_b}"
                echo -e "${_DCR_YELLOW}[DCR]${_DCR_NC}   提案: ${pkg_a} を ${ver_b} にアップグレード" >&2
                ;;
            COMPAT)
                local source_pkg="${conflict_detail%%:*}"
                local requirement="${conflict_detail#*:}"
                local required_ver
                required_ver=$(echo "$requirement" | grep -oE '[0-9]+' | head -1)

                local target_pkg
                target_pkg=$(echo "$requirement" | grep -oE 'react|node' | head -1)
                if [[ -n "$target_pkg" && -n "$required_ver" ]]; then
                    _DCR_RESOLUTIONS["$conflict"]="npm install ${target_pkg}@${required_ver}"
                    echo -e "${_DCR_YELLOW}[DCR]${_DCR_NC}   提案: ${target_pkg} を v${required_ver}+ にアップグレード" >&2
                fi
                ;;
            DUPLICATE)
                local dup_pkg="${conflict_detail%%:*}"
                _DCR_RESOLUTIONS["$conflict"]="npm dedupe"
                echo -e "${_DCR_YELLOW}[DCR]${_DCR_NC}   提案: npm dedupe で ${dup_pkg} を統合" >&2
                ;;
            INVALID)
                _DCR_RESOLUTIONS["$conflict"]="npm install"
                echo -e "${_DCR_YELLOW}[DCR]${_DCR_NC}   提案: npm install で再解決" >&2
                ;;
        esac
    done

    # Suggest overrides for peer dep issues
    if [[ ${#_DCR_PEER_ERRORS[@]} -gt 0 ]]; then
        echo -e "${_DCR_YELLOW}[DCR]${_DCR_NC}   peer dep エラー: package.json に overrides セクション追加を推奨" >&2
        echo -e "${_DCR_YELLOW}[DCR]${_DCR_NC}   例: \"overrides\": { \"package-name\": \"^version\" }" >&2
    fi

    return 0
}

# =============================================================================
# _dcr_find_alternatives - Find alternative packages
# =============================================================================
_dcr_find_alternatives() {
    local package_name="${1:-}"
    [[ -z "$package_name" ]] && return 1

    echo -e "${_DCR_CYAN}[DCR]${_DCR_NC} ${package_name} の代替パッケージを検索中..." >&2

    # Known alternatives map
    declare -A alternatives=(
        ["moment"]="dayjs date-fns luxon"
        ["lodash"]="lodash-es ramda"
        ["express"]="fastify koa hono"
        ["axios"]="ky got node-fetch undici"
        ["mongoose"]="prisma drizzle-orm typeorm"
        ["sequelize"]="prisma drizzle-orm knex"
        ["redux"]="zustand jotai valtio recoil"
        ["styled-components"]="emotion tailwindcss vanilla-extract"
        ["sass"]="postcss tailwindcss"
        ["chalk"]="picocolors kleur"
        ["uuid"]="nanoid cuid2"
        ["request"]="got axios node-fetch undici"
        ["mocha"]="vitest jest"
        ["jasmine"]="vitest jest"
        ["enzyme"]="@testing-library/react"
        ["classnames"]="clsx"
        ["body-parser"]="(built into express 4.16+)"
    )

    local base_name
    base_name=$(echo "$package_name" | sed 's/@[^/]*\///')

    if [[ -n "${alternatives[$base_name]:-}" ]]; then
        echo -e "${_DCR_GREEN}[DCR]${_DCR_NC}   代替候補: ${alternatives[$base_name]}" >&2
        DCR_ALTERNATIVES_FOUND=$((DCR_ALTERNATIVES_FOUND + 1))
        echo "${alternatives[$base_name]}"
        return 0
    fi

    echo -e "${_DCR_YELLOW}[DCR]${_DCR_NC}   既知の代替なし" >&2
    return 1
}

# =============================================================================
# _dcr_apply_resolution - Apply dependency resolution
# =============================================================================
_dcr_apply_resolution() {
    local project_dir="${1:-.}"
    local dry_run="${2:-true}"

    echo -e "${_DCR_CYAN}[DCR]${_DCR_NC} 解決策を適用中..." >&2

    if [[ ${#_DCR_RESOLUTIONS[@]} -eq 0 ]]; then
        echo -e "${_DCR_GREEN}[DCR]${_DCR_NC} 適用すべき解決策なし" >&2
        return 0
    fi

    for conflict in "${!_DCR_RESOLUTIONS[@]}"; do
        local resolution="${_DCR_RESOLUTIONS[$conflict]}"
        echo -e "${_DCR_CYAN}[DCR]${_DCR_NC}   実行: ${resolution}" >&2

        if [[ "$dry_run" == "true" ]]; then
            echo -e "${_DCR_YELLOW}[DCR]${_DCR_NC}   (dry-run モード: 実行スキップ)" >&2
        else
            local output
            output=$(cd "$project_dir" && eval "$resolution" 2>&1) || {
                echo -e "${_DCR_RED}[DCR]${_DCR_NC}   失敗: ${output}" >&2
                continue
            }
            echo -e "${_DCR_GREEN}[DCR]${_DCR_NC}   成功" >&2
            DCR_RESOLUTIONS_APPLIED=$((DCR_RESOLUTIONS_APPLIED + 1))
        fi
    done

    # Run npm dedupe after resolutions
    if [[ "$dry_run" != "true" ]]; then
        echo -e "${_DCR_CYAN}[DCR]${_DCR_NC}   npm dedupe 実行中..." >&2
        (cd "$project_dir" && npm dedupe 2>/dev/null) || true
    fi

    return 0
}

# =============================================================================
# _dcr_full_scan - Complete dependency scan and resolution
# =============================================================================
_dcr_full_scan() {
    local project_dir="${1:-.}"

    echo -e "${_DCR_BOLD}[DCR] 完全依存関係スキャン開始${_DCR_NC}" >&2

    _dcr_detect_conflicts "$project_dir"
    _dcr_find_peer_dep_issues "$project_dir"
    _dcr_suggest_resolutions "$project_dir"

    # Save scan results
    local scan_file="${DCR_CACHE_DIR}/last_scan.json"
    cat > "$scan_file" <<EOF
{
  "timestamp": "$(date -u +"%Y-%m-%dT%H:%M:%SZ")",
  "conflicts": ${DCR_CONFLICTS_FOUND},
  "peer_issues": ${DCR_PEER_ISSUES},
  "resolutions": ${#_DCR_RESOLUTIONS[@]}
}
EOF

    echo -e "${_DCR_BOLD}[DCR] スキャン完了${_DCR_NC}" >&2
    return 0
}

# =============================================================================
# _dcr_report - Report output
# =============================================================================
_dcr_report() {
    echo -e "\n  ${_DCR_BOLD}--- Dependency Conflict Resolver v${DCR_VERSION} ---${_DCR_NC}"
    echo -e "  バージョン競合   : ${DCR_CONFLICTS_FOUND}"
    echo -e "  peer dep問題     : ${DCR_PEER_ISSUES}"
    echo -e "  解決策適用       : ${DCR_RESOLUTIONS_APPLIED}"
    echo -e "  代替パッケージ   : ${DCR_ALTERNATIVES_FOUND}"
}

# =============================================================================
# _dcr_score - Module score (0-100)
# =============================================================================
_dcr_score() {
    local total=$((DCR_CONFLICTS_FOUND + DCR_PEER_ISSUES))
    if [[ $total -eq 0 ]]; then
        echo "100"
    elif [[ $DCR_RESOLUTIONS_APPLIED -ge $total ]]; then
        echo "90"
    else
        local resolved=$((DCR_RESOLUTIONS_APPLIED + DCR_ALTERNATIVES_FOUND))
        local ratio=$(( resolved * 100 / (total + 1) ))
        [[ $ratio -gt 100 ]] && ratio=100
        [[ $ratio -lt 20 ]] && ratio=20
        echo "$ratio"
    fi
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "dependency-conflict-resolver" \
    --version "262.0" \
    --description "依存パッケージバージョン競合検出・自動解決" \
    --init "_dcr_init" \
    --report "_dcr_report" \
    --score "_dcr_score" \
    --enable-var "ENABLE_DCR" \
    --cli-flags "--dependency-conflict-resolver:--no-dependency-conflict-resolver"
