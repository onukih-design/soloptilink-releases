#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v427.0 - Large Project Handler
# =============================================================================
# 大規模プロジェクト（1000+ファイル）向けの最適化ハンドラ。
# プロジェクトサイズ分析、作業分割、メモリ最適化を行い、
# 大規模コードベースでも安定した生成を実現する。
#
# Functions:
#   _lph_init()                  - 初期化
#   _lph_analyze_project_size()  - プロジェクト規模分析
#   _lph_partition_work()        - 作業パーティション分割
#   _lph_optimize_memory()       - メモリ使用最適化
#   _lph_report() / _lph_score()
#
# All globals use the LPH_ prefix.
# =============================================================================

[[ -n "${_LPH_LOADED:-}" ]] && return 0; _LPH_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g LPH_VERSION="427.0"
declare -g LPH_GENERATED=0
declare -g LPH_ERRORS=0
declare -g LPH_TOTAL_FILES=0
declare -g LPH_TOTAL_LINES=0
declare -g LPH_TOTAL_SIZE_KB=0
declare -g LPH_PARTITIONS=0
declare -g LPH_PROJECT_TIER=""
declare -g LPH_MEMORY_LIMIT_MB="${LPH_MEMORY_LIMIT_MB:-2048}"
declare -g LPH_PARTITION_SIZE="${LPH_PARTITION_SIZE:-50}"

declare -gA _LPH_DIR_STATS=()
declare -ga _LPH_PARTITIONS=()

_LPH_GREEN="${GREEN:-\033[0;32m}"
_LPH_RED="${RED:-\033[0;31m}"
_LPH_YELLOW="${YELLOW:-\033[0;33m}"
_LPH_CYAN="${CYAN:-\033[0;36m}"
_LPH_BOLD="${BOLD:-\033[1m}"
_LPH_NC="${NC:-\033[0m}"

_lph_init() {
    LPH_GENERATED=0
    LPH_ERRORS=0
    LPH_TOTAL_FILES=0
    LPH_TOTAL_LINES=0
    LPH_TOTAL_SIZE_KB=0
    LPH_PARTITIONS=0
    LPH_PROJECT_TIER=""
    _LPH_DIR_STATS=()
    _LPH_PARTITIONS=()
    return 0
}

_lph_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_LPH_CYAN}[LPH]${_LPH_NC} $*" >&2 ;;
        ok)    echo -e "  ${_LPH_GREEN}[LPH]${_LPH_NC} $*" >&2 ;;
        warn)  echo -e "  ${_LPH_YELLOW}[LPH]${_LPH_NC} $*" >&2 ;;
        error) echo -e "  ${_LPH_RED}[LPH]${_LPH_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _lph_analyze_project_size - プロジェクト規模分析
# =============================================================================
_lph_analyze_project_size() {
    local project_dir="${1:-.}"

    _lph_log info "プロジェクト規模分析: ${project_dir}"

    # ファイル数カウント
    LPH_TOTAL_FILES=0
    LPH_TOTAL_LINES=0
    LPH_TOTAL_SIZE_KB=0
    _LPH_DIR_STATS=()

    while IFS= read -r -d '' file; do
        LPH_TOTAL_FILES=$((LPH_TOTAL_FILES + 1))

        local lines
        lines=$(wc -l < "$file" 2>/dev/null || echo 0)
        LPH_TOTAL_LINES=$((LPH_TOTAL_LINES + lines))

        local size_kb
        size_kb=$(du -k "$file" 2>/dev/null | cut -f1 || echo 0)
        LPH_TOTAL_SIZE_KB=$((LPH_TOTAL_SIZE_KB + size_kb))

        # ディレクトリ別統計
        local dir
        dir=$(dirname "$file")
        dir="${dir#${project_dir}/}"
        local top_dir="${dir%%/*}"
        _LPH_DIR_STATS["$top_dir"]=$(( ${_LPH_DIR_STATS["$top_dir"]:-0} + 1 ))
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \
             -o -name "*.css" -o -name "*.scss" -o -name "*.json" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" \
             -not -path "*/dist/*" -not -path "*/.git/*" -print0 2>/dev/null)

    # プロジェクトティア判定
    if [[ $LPH_TOTAL_FILES -ge 5000 ]]; then
        LPH_PROJECT_TIER="enterprise"
    elif [[ $LPH_TOTAL_FILES -ge 1000 ]]; then
        LPH_PROJECT_TIER="large"
    elif [[ $LPH_TOTAL_FILES -ge 200 ]]; then
        LPH_PROJECT_TIER="medium"
    else
        LPH_PROJECT_TIER="small"
    fi

    LPH_GENERATED=$((LPH_GENERATED + 1))
    _lph_log ok "規模分析完了: ${LPH_TOTAL_FILES}ファイル, ${LPH_TOTAL_LINES}行, ${LPH_TOTAL_SIZE_KB}KB → tier=${LPH_PROJECT_TIER}"

    # ディレクトリ別統計表示
    for dir in "${!_LPH_DIR_STATS[@]}"; do
        _lph_log info "  ${dir}/: ${_LPH_DIR_STATS[$dir]}ファイル"
    done

    echo "${LPH_PROJECT_TIER}"
    return 0
}

# =============================================================================
# _lph_partition_work - 作業パーティション分割
# =============================================================================
_lph_partition_work() {
    local project_dir="${1:-.}"
    local partition_size="${2:-$LPH_PARTITION_SIZE}"

    _lph_log info "作業パーティション分割 (${partition_size}ファイル/パーティション)"

    _LPH_PARTITIONS=()
    local current_partition=""
    local count=0
    local partition_idx=0

    # ディレクトリ構造を尊重してパーティション
    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"

        current_partition="${current_partition}${current_partition:+|}${rel}"
        count=$((count + 1))

        if [[ $count -ge $partition_size ]]; then
            _LPH_PARTITIONS+=("$current_partition")
            current_partition=""
            count=0
            partition_idx=$((partition_idx + 1))
        fi
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" \
             -not -path "*/dist/*" -print0 2>/dev/null | sort -z)

    # 残りを最後のパーティションに
    if [[ -n "$current_partition" ]]; then
        _LPH_PARTITIONS+=("$current_partition")
        partition_idx=$((partition_idx + 1))
    fi

    LPH_PARTITIONS=$partition_idx

    # ティアに応じた推奨設定
    case "$LPH_PROJECT_TIER" in
        enterprise)
            _lph_log warn "エンタープライズ規模: 並列度4推奨, メモリ4GB推奨"
            ;;
        large)
            _lph_log info "大規模: 並列度3推奨, メモリ2GB推奨"
            ;;
        *)
            _lph_log info "標準規模: デフォルト設定で十分"
            ;;
    esac

    LPH_GENERATED=$((LPH_GENERATED + 1))
    _lph_log ok "パーティション完了: ${LPH_PARTITIONS}個"

    echo "${LPH_PARTITIONS}"
    return 0
}

# =============================================================================
# _lph_optimize_memory - メモリ使用最適化
# =============================================================================
_lph_optimize_memory() {
    local project_dir="${1:-.}"

    _lph_log info "メモリ最適化設定"

    local recommendations=""

    # Node.js ヒープサイズ推奨
    local node_heap=4096
    case "$LPH_PROJECT_TIER" in
        enterprise) node_heap=8192 ;;
        large)      node_heap=4096 ;;
        medium)     node_heap=2048 ;;
        small)      node_heap=1024 ;;
    esac

    recommendations="NODE_OPTIONS='--max-old-space-size=${node_heap}'"

    # TypeScript incrementalコンパイル推奨
    if [[ -f "${project_dir}/tsconfig.json" ]]; then
        local has_incremental
        has_incremental=$(grep -c '"incremental"' "${project_dir}/tsconfig.json" 2>/dev/null || echo 0)
        if [[ $has_incremental -eq 0 ]]; then
            recommendations="${recommendations}\ntsconfig.json: incremental: true を追加推奨"
        fi
    fi

    # .env.local にNODE_OPTIONS推奨
    if [[ -f "${project_dir}/.env.local" ]]; then
        local has_node_opts
        has_node_opts=$(grep -c "NODE_OPTIONS" "${project_dir}/.env.local" 2>/dev/null || echo 0)
        if [[ $has_node_opts -eq 0 ]]; then
            recommendations="${recommendations}\n.env.local: NODE_OPTIONS=${node_heap}MB を追加推奨"
        fi
    fi

    # next.config チェック
    if [[ -f "${project_dir}/next.config.js" ]] || [[ -f "${project_dir}/next.config.mjs" ]]; then
        recommendations="${recommendations}\nnext.config: experimental.workerThreads 推奨"
    fi

    LPH_GENERATED=$((LPH_GENERATED + 1))
    _lph_log ok "メモリ最適化設定完了 (Node.js heap: ${node_heap}MB)"
    printf '%b\n' "$recommendations"

    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_lph_report() {
    echo -e "\n  ${_LPH_BOLD}=== large-project-handler v${LPH_VERSION} ===${_LPH_NC}"
    echo -e "  プロジェクトティア: ${LPH_PROJECT_TIER}"
    echo -e "  総ファイル      : ${LPH_TOTAL_FILES}"
    echo -e "  総行数          : ${LPH_TOTAL_LINES}"
    echo -e "  総サイズ        : ${LPH_TOTAL_SIZE_KB}KB"
    echo -e "  パーティション  : ${LPH_PARTITIONS}"
    echo -e "  エラー          : ${LPH_ERRORS}"
}

_lph_score() {
    local score=50
    [[ -n "$LPH_PROJECT_TIER" ]] && score=$((score + 15))
    [[ ${LPH_PARTITIONS} -gt 0 ]] && score=$((score + 15))
    [[ ${LPH_TOTAL_FILES} -gt 0 ]] && score=$((score + 10))
    [[ ${LPH_ERRORS} -eq 0 ]] && score=$((score + 10))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "large-project-handler" --version "${LPH_VERSION}" \
        --description "大規模プロジェクト×規模分析×パーティション×メモリ最適化 (v427)" \
        --init "_lph_init" --report "_lph_report" --score "_lph_score" \
        --enable-var "ENABLE_LARGE_PROJECT" --cli-flags "--large-project:--no-large-project"
fi

# v2003.1: source時のexit codeを確実に0にする
true
