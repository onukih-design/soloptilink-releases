#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - Realtime Sync Engine
# =============================================================================
# リアルタイム通信基盤自動生成エンジン。
# WebSocket(Socket.IO/ws)、SSE、Reactフック、プレゼンス、ライブカーソル、
# 楽観的更新、自動再接続を完全生成する。
#
# 機能一覧:
#   rs_generate_websocket_server  - Socket.IO / wsサーバー（認証・ルーム・名前空間）
#   rs_generate_sse_endpoint      - Server-Sent Events エンドポイント
#   rs_generate_client_hooks      - React hooks: useWebSocket, useSSE, useRealtimeQuery
#   rs_generate_presence          - オンライン/オフライン プレゼンス
#   rs_generate_live_cursors      - 共同編集カーソル位置同期
#   rs_generate_optimistic_updates- 楽観的UI更新+コンフリクト解決
#   rs_generate_reconnection      - 自動再接続+指数バックオフ+キュー
#   rs_inject_realtime_patterns   - Claudeプロンプトへのパターン注入
#
# 全globals: RTS_ prefix
# =============================================================================

[[ -n "${_RTS_LOADED:-}" ]] && return 0; _RTS_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g RTS_VERSION="140.0"
declare -g RTS_GENERATED=0
declare -g RTS_ERRORS=0
declare -g RTS_PHASE="realtime"
declare -g RTS_FILES_WRITTEN=0

# =============================================================================
# 初期化
# =============================================================================
rs_init() {
    RTS_GENERATED=0
    RTS_ERRORS=0
    RTS_FILES_WRITTEN=0
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} realtime-sync v${RTS_VERSION}"
    return 0
}

# =============================================================================
# ユーティリティ
# =============================================================================
_rts_write_file() {
    local filepath="$1"
    local content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then
        RTS_FILES_WRITTEN=$((RTS_FILES_WRITTEN + 1))
        echo "  [realtime] wrote: $filepath" >&2
    else
        RTS_ERRORS=$((RTS_ERRORS + 1))
    fi
}

# =============================================================================
# rs_generate_websocket_server - WebSocket サーバー
# =============================================================================
rs_generate_websocket_server() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local ws_server
    ws_server=$(cat <<'WSEOF'
import { Server as SocketIOServer, Socket } from 'socket.io';
import { Server as HTTPServer } from 'http';
import { verify } from 'jsonwebtoken';
import { z } from 'zod';

// --- Types ---
interface AuthenticatedSocket extends Socket {
  userId: string;
  tenantId?: string;
}

interface RoomInfo {
  id: string;
  users: Map<string, { userId: string; joinedAt: Date }>;
}

// --- Zod Schemas ---
const MessageSchema = z.object({
  room: z.string().min(1).max(200),
  event: z.string().min(1).max(100),
  data: z.unknown(),
});

const JoinRoomSchema = z.object({
  room: z.string().min(1).max(200),
});

// --- Server Class ---
export class RealtimeServer {
  private io: SocketIOServer;
  private rooms: Map<string, RoomInfo> = new Map();
  private userSockets: Map<string, Set<string>> = new Map();

  constructor(httpServer: HTTPServer, options?: { cors?: { origin: string[] } }) {
    this.io = new SocketIOServer(httpServer, {
      cors: options?.cors ?? {
        origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
        credentials: true,
      },
      pingInterval: 25000,
      pingTimeout: 10000,
      transports: ['websocket', 'polling'],
    });

    this.setupAuth();
    this.setupHandlers();
    this.setupNamespaces();
  }

  private setupAuth() {
    this.io.use(async (socket: Socket, next) => {
      try {
        const token =
          socket.handshake.auth?.token ||
          socket.handshake.headers?.authorization?.replace('Bearer ', '');

        if (!token) {
          return next(new Error('Authentication required'));
        }

        const secret = process.env.JWT_SECRET || process.env.NEXTAUTH_SECRET;
        if (!secret) {
          return next(new Error('Server configuration error'));
        }

        const payload = verify(token, secret) as { sub: string; tenantId?: string };
        (socket as AuthenticatedSocket).userId = payload.sub;
        (socket as AuthenticatedSocket).tenantId = payload.tenantId;
        next();
      } catch (err) {
        next(new Error('Invalid token'));
      }
    });
  }

  private setupHandlers() {
    this.io.on('connection', (socket: Socket) => {
      const authSocket = socket as AuthenticatedSocket;
      const userId = authSocket.userId;

      // Track user sockets
      if (!this.userSockets.has(userId)) {
        this.userSockets.set(userId, new Set());
      }
      this.userSockets.get(userId)!.add(socket.id);

      console.log(`[ws] connected: ${userId} (${socket.id})`);

      // Join room
      socket.on('room:join', (data: unknown) => {
        const parsed = JoinRoomSchema.safeParse(data);
        if (!parsed.success) {
          socket.emit('error', { message: 'Invalid room data' });
          return;
        }
        const { room } = parsed.data;
        socket.join(room);

        if (!this.rooms.has(room)) {
          this.rooms.set(room, { id: room, users: new Map() });
        }
        this.rooms.get(room)!.users.set(userId, { userId, joinedAt: new Date() });

        this.io.to(room).emit('room:user-joined', { userId, room });
        socket.emit('room:joined', {
          room,
          users: Array.from(this.rooms.get(room)!.users.keys()),
        });
      });

      // Leave room
      socket.on('room:leave', (data: unknown) => {
        const parsed = JoinRoomSchema.safeParse(data);
        if (!parsed.success) return;
        const { room } = parsed.data;
        socket.leave(room);
        this.rooms.get(room)?.users.delete(userId);
        this.io.to(room).emit('room:user-left', { userId, room });
      });

      // Broadcast message to room
      socket.on('message', (data: unknown) => {
        const parsed = MessageSchema.safeParse(data);
        if (!parsed.success) {
          socket.emit('error', { message: 'Invalid message format' });
          return;
        }
        const { room, event, data: payload } = parsed.data;
        socket.to(room).emit(event, { from: userId, data: payload, timestamp: Date.now() });
      });

      // Typing indicator
      socket.on('typing:start', (data: { room: string }) => {
        socket.to(data.room).emit('typing:start', { userId });
      });
      socket.on('typing:stop', (data: { room: string }) => {
        socket.to(data.room).emit('typing:stop', { userId });
      });

      // Disconnect
      socket.on('disconnect', (reason) => {
        console.log(`[ws] disconnected: ${userId} (${reason})`);
        this.userSockets.get(userId)?.delete(socket.id);
        if (this.userSockets.get(userId)?.size === 0) {
          this.userSockets.delete(userId);
        }

        // Clean up room membership
        for (const [roomId, room] of this.rooms) {
          if (room.users.has(userId)) {
            room.users.delete(userId);
            this.io.to(roomId).emit('room:user-left', { userId, room: roomId });
          }
          if (room.users.size === 0) {
            this.rooms.delete(roomId);
          }
        }

        // Broadcast presence
        this.io.emit('presence:offline', { userId });
      });
    });
  }

  private setupNamespaces() {
    // Admin namespace
    const adminNs = this.io.of('/admin');
    adminNs.use((socket, next) => {
      const authSocket = socket as AuthenticatedSocket;
      // Add admin role check here
      next();
    });
    adminNs.on('connection', (socket) => {
      socket.on('broadcast', (data: { event: string; payload: unknown }) => {
        this.io.emit(data.event, data.payload);
      });
    });
  }

  // Public API
  broadcastToRoom(room: string, event: string, data: unknown) {
    this.io.to(room).emit(event, data);
  }

  broadcastToUser(userId: string, event: string, data: unknown) {
    const sockets = this.userSockets.get(userId);
    if (sockets) {
      for (const socketId of sockets) {
        this.io.to(socketId).emit(event, data);
      }
    }
  }

  getOnlineUsers(): string[] {
    return Array.from(this.userSockets.keys());
  }

  getRoomUsers(room: string): string[] {
    return Array.from(this.rooms.get(room)?.users.keys() || []);
  }
}
WSEOF
)
    _rts_write_file "${project_dir}/src/lib/realtime-server.ts" "$ws_server"
    RTS_GENERATED=$((RTS_GENERATED + 1))
    return 0
}

# =============================================================================
# rs_generate_sse_endpoint - SSE エンドポイント
# =============================================================================
rs_generate_sse_endpoint() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local sse_ts
    sse_ts=$(cat <<'SSEEOF'
import { NextRequest } from 'next/server';

// SSE connection manager
class SSEManager {
  private connections: Map<string, Set<ReadableStreamDefaultController>> = new Map();

  addConnection(channel: string, controller: ReadableStreamDefaultController) {
    if (!this.connections.has(channel)) {
      this.connections.set(channel, new Set());
    }
    this.connections.get(channel)!.add(controller);
  }

  removeConnection(channel: string, controller: ReadableStreamDefaultController) {
    this.connections.get(channel)?.delete(controller);
    if (this.connections.get(channel)?.size === 0) {
      this.connections.delete(channel);
    }
  }

  broadcast(channel: string, event: string, data: unknown) {
    const controllers = this.connections.get(channel);
    if (!controllers) return;
    const message = `event: ${event}\ndata: ${JSON.stringify(data)}\n\n`;
    const encoder = new TextEncoder();
    for (const ctrl of controllers) {
      try {
        ctrl.enqueue(encoder.encode(message));
      } catch {
        controllers.delete(ctrl);
      }
    }
  }

  getConnectionCount(channel?: string): number {
    if (channel) return this.connections.get(channel)?.size ?? 0;
    let total = 0;
    for (const set of this.connections.values()) total += set.size;
    return total;
  }
}

export const sseManager = new SSEManager();

// Next.js App Router SSE endpoint
export async function GET(request: NextRequest) {
  const channel = request.nextUrl.searchParams.get('channel') || 'default';
  const encoder = new TextEncoder();

  const stream = new ReadableStream({
    start(controller) {
      sseManager.addConnection(channel, controller);

      // Send initial connection event
      controller.enqueue(
        encoder.encode(`event: connected\ndata: ${JSON.stringify({ channel })}\n\n`)
      );

      // Heartbeat every 30s to keep connection alive
      const heartbeat = setInterval(() => {
        try {
          controller.enqueue(encoder.encode(`: heartbeat\n\n`));
        } catch {
          clearInterval(heartbeat);
        }
      }, 30_000);

      // Clean up on close
      request.signal.addEventListener('abort', () => {
        clearInterval(heartbeat);
        sseManager.removeConnection(channel, controller);
        try { controller.close(); } catch { /* already closed */ }
      });
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      Connection: 'keep-alive',
      'X-Accel-Buffering': 'no',
    },
  });
}
SSEEOF
)
    _rts_write_file "${project_dir}/src/app/api/sse/route.ts" "$sse_ts"
    RTS_GENERATED=$((RTS_GENERATED + 1))
    return 0
}

# =============================================================================
# rs_generate_client_hooks - React hooks
# =============================================================================
rs_generate_client_hooks() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local hooks_ts
    hooks_ts=$(cat <<'HKEOF'
'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { io, Socket } from 'socket.io-client';

// --- useWebSocket ---
interface UseWebSocketOptions {
  url?: string;
  token?: string;
  autoConnect?: boolean;
  reconnect?: boolean;
}

interface UseWebSocketReturn {
  socket: Socket | null;
  connected: boolean;
  emit: (event: string, data: unknown) => void;
  on: (event: string, handler: (...args: any[]) => void) => void;
  off: (event: string, handler?: (...args: any[]) => void) => void;
  joinRoom: (room: string) => void;
  leaveRoom: (room: string) => void;
}

export function useWebSocket(options: UseWebSocketOptions = {}): UseWebSocketReturn {
  const { url = '', token, autoConnect = true, reconnect = true } = options;
  const socketRef = useRef<Socket | null>(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    if (!autoConnect) return;

    const socket = io(url || undefined, {
      auth: token ? { token } : undefined,
      transports: ['websocket', 'polling'],
      reconnection: reconnect,
      reconnectionAttempts: 10,
      reconnectionDelay: 1000,
      reconnectionDelayMax: 30000,
    });

    socket.on('connect', () => setConnected(true));
    socket.on('disconnect', () => setConnected(false));
    socket.on('connect_error', (err) => {
      console.error('[ws] connection error:', err.message);
    });

    socketRef.current = socket;

    return () => {
      socket.disconnect();
      socketRef.current = null;
    };
  }, [url, token, autoConnect, reconnect]);

  const emit = useCallback(
    (event: string, data: unknown) => socketRef.current?.emit(event, data),
    []
  );

  const on = useCallback(
    (event: string, handler: (...args: any[]) => void) => {
      socketRef.current?.on(event, handler);
    },
    []
  );

  const off = useCallback(
    (event: string, handler?: (...args: any[]) => void) => {
      if (handler) socketRef.current?.off(event, handler);
      else socketRef.current?.removeAllListeners(event);
    },
    []
  );

  const joinRoom = useCallback(
    (room: string) => socketRef.current?.emit('room:join', { room }),
    []
  );

  const leaveRoom = useCallback(
    (room: string) => socketRef.current?.emit('room:leave', { room }),
    []
  );

  return { socket: socketRef.current, connected, emit, on, off, joinRoom, leaveRoom };
}

// --- useSSE ---
interface UseSSEOptions {
  channel: string;
  events?: string[];
  enabled?: boolean;
}

export function useSSE<T = unknown>(options: UseSSEOptions) {
  const { channel, events = [], enabled = true } = options;
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<Error | null>(null);
  const [connected, setConnected] = useState(false);
  const sourceRef = useRef<EventSource | null>(null);

  useEffect(() => {
    if (!enabled) return;

    const url = `/api/sse?channel=${encodeURIComponent(channel)}`;
    const source = new EventSource(url);
    sourceRef.current = source;

    source.addEventListener('connected', () => setConnected(true));
    source.onerror = () => {
      setConnected(false);
      setError(new Error('SSE connection lost'));
    };

    const handler = (event: MessageEvent) => {
      try {
        setData(JSON.parse(event.data));
        setError(null);
      } catch (e) {
        setError(e as Error);
      }
    };

    if (events.length > 0) {
      for (const evt of events) {
        source.addEventListener(evt, handler);
      }
    } else {
      source.onmessage = handler;
    }

    return () => {
      source.close();
      sourceRef.current = null;
      setConnected(false);
    };
  }, [channel, enabled, events.join(',')]);

  return { data, error, connected };
}

// --- useRealtimeQuery ---
interface UseRealtimeQueryOptions<T> {
  queryKey: string;
  queryFn: () => Promise<T>;
  channel: string;
  updateEvent?: string;
}

export function useRealtimeQuery<T>(options: UseRealtimeQueryOptions<T>) {
  const { queryKey, queryFn, channel, updateEvent = 'update' } = options;
  const [data, setData] = useState<T | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<Error | null>(null);

  // Initial fetch
  useEffect(() => {
    let cancelled = false;
    setIsLoading(true);
    queryFn()
      .then((result) => { if (!cancelled) { setData(result); setIsLoading(false); } })
      .catch((err) => { if (!cancelled) { setError(err); setIsLoading(false); } });
    return () => { cancelled = true; };
  }, [queryKey]);

  // SSE updates
  const { data: sseUpdate } = useSSE<T>({ channel, events: [updateEvent] });

  useEffect(() => {
    if (sseUpdate) {
      setData(sseUpdate);
    }
  }, [sseUpdate]);

  const refetch = useCallback(() => {
    setIsLoading(true);
    queryFn()
      .then(setData)
      .catch(setError)
      .finally(() => setIsLoading(false));
  }, [queryKey]);

  return { data, isLoading, error, refetch };
}
HKEOF
)
    _rts_write_file "${project_dir}/src/hooks/useRealtime.ts" "$hooks_ts"
    RTS_GENERATED=$((RTS_GENERATED + 1))
    return 0
}

# =============================================================================
# rs_generate_presence - プレゼンス追跡
# =============================================================================
rs_generate_presence() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local presence_ts
    presence_ts=$(cat <<'PREOF'
import { RealtimeServer } from './realtime-server';

interface PresenceInfo {
  userId: string;
  status: 'online' | 'away' | 'offline';
  lastSeen: Date;
  metadata?: Record<string, unknown>;
}

export class PresenceTracker {
  private presence: Map<string, PresenceInfo> = new Map();
  private awayTimers: Map<string, NodeJS.Timeout> = new Map();
  private awayTimeout: number;

  constructor(
    private server: RealtimeServer,
    options?: { awayTimeoutMs?: number }
  ) {
    this.awayTimeout = options?.awayTimeoutMs ?? 5 * 60 * 1000; // 5 min default
  }

  setOnline(userId: string, metadata?: Record<string, unknown>) {
    this.clearAwayTimer(userId);
    const info: PresenceInfo = {
      userId,
      status: 'online',
      lastSeen: new Date(),
      metadata,
    };
    this.presence.set(userId, info);
    this.server.broadcastToRoom('presence', 'presence:update', info);
  }

  setAway(userId: string) {
    const info = this.presence.get(userId);
    if (info) {
      info.status = 'away';
      info.lastSeen = new Date();
      this.server.broadcastToRoom('presence', 'presence:update', info);
    }
  }

  setOffline(userId: string) {
    this.clearAwayTimer(userId);
    const info: PresenceInfo = {
      userId,
      status: 'offline',
      lastSeen: new Date(),
    };
    this.presence.set(userId, info);
    this.server.broadcastToRoom('presence', 'presence:update', info);

    // Remove after 24h
    setTimeout(() => {
      if (this.presence.get(userId)?.status === 'offline') {
        this.presence.delete(userId);
      }
    }, 24 * 60 * 60 * 1000);
  }

  heartbeat(userId: string) {
    this.clearAwayTimer(userId);
    const info = this.presence.get(userId);
    if (info) {
      info.lastSeen = new Date();
      info.status = 'online';
    }
    // Set away timer
    this.awayTimers.set(
      userId,
      setTimeout(() => this.setAway(userId), this.awayTimeout)
    );
  }

  getPresence(userId: string): PresenceInfo | undefined {
    return this.presence.get(userId);
  }

  getOnlineUsers(): PresenceInfo[] {
    return Array.from(this.presence.values()).filter((p) => p.status === 'online');
  }

  getAllPresence(): PresenceInfo[] {
    return Array.from(this.presence.values());
  }

  private clearAwayTimer(userId: string) {
    const timer = this.awayTimers.get(userId);
    if (timer) {
      clearTimeout(timer);
      this.awayTimers.delete(userId);
    }
  }
}
PREOF
)
    _rts_write_file "${project_dir}/src/lib/presence.ts" "$presence_ts"
    RTS_GENERATED=$((RTS_GENERATED + 1))
    return 0
}

# =============================================================================
# rs_generate_live_cursors - ライブカーソル同期
# =============================================================================
rs_generate_live_cursors() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local cursors_ts
    cursors_ts=$(cat <<'LCEOF'
'use client';

import { useEffect, useState, useCallback, useRef } from 'react';
import { useWebSocket } from './useRealtime';

interface CursorPosition {
  userId: string;
  userName: string;
  x: number;
  y: number;
  color: string;
  lastUpdate: number;
}

const CURSOR_COLORS = [
  '#EF4444', '#F59E0B', '#10B981', '#3B82F6',
  '#8B5CF6', '#EC4899', '#06B6D4', '#F97316',
];

export function useLiveCursors(room: string, currentUser: { id: string; name: string }) {
  const [cursors, setCursors] = useState<Map<string, CursorPosition>>(new Map());
  const { socket, connected, emit, on, off, joinRoom } = useWebSocket();
  const throttleRef = useRef<NodeJS.Timeout | null>(null);

  // Assign stable color based on userId
  const colorIndex =
    currentUser.id.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0) % CURSOR_COLORS.length;

  useEffect(() => {
    if (!connected) return;
    joinRoom(room);

    const handler = (data: { from: string; data: CursorPosition }) => {
      if (data.from === currentUser.id) return;
      setCursors((prev) => {
        const next = new Map(prev);
        next.set(data.from, { ...data.data, lastUpdate: Date.now() });
        return next;
      });
    };

    on('cursor:move', handler);

    // Clean stale cursors every 5s
    const cleanup = setInterval(() => {
      setCursors((prev) => {
        const next = new Map(prev);
        const now = Date.now();
        for (const [uid, pos] of next) {
          if (now - pos.lastUpdate > 10_000) next.delete(uid);
        }
        return next;
      });
    }, 5000);

    return () => {
      off('cursor:move', handler);
      clearInterval(cleanup);
    };
  }, [connected, room]);

  const updateCursor = useCallback(
    (x: number, y: number) => {
      // Throttle to 50ms
      if (throttleRef.current) return;
      throttleRef.current = setTimeout(() => {
        throttleRef.current = null;
      }, 50);

      emit('message', {
        room,
        event: 'cursor:move',
        data: {
          userId: currentUser.id,
          userName: currentUser.name,
          x,
          y,
          color: CURSOR_COLORS[colorIndex],
        },
      });
    },
    [room, emit, currentUser.id, currentUser.name, colorIndex]
  );

  return {
    cursors: Array.from(cursors.values()),
    updateCursor,
    connected,
  };
}
LCEOF
)
    _rts_write_file "${project_dir}/src/hooks/useLiveCursors.ts" "$cursors_ts"
    RTS_GENERATED=$((RTS_GENERATED + 1))
    return 0
}

# =============================================================================
# rs_generate_optimistic_updates - 楽観的更新
# =============================================================================
rs_generate_optimistic_updates() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local optimistic_ts
    optimistic_ts=$(cat <<'OPEOF'
'use client';

import { useCallback, useRef, useState } from 'react';

interface OptimisticAction<T> {
  id: string;
  optimisticData: T;
  serverFn: () => Promise<T>;
  rollback: T;
  timestamp: number;
  status: 'pending' | 'confirmed' | 'rolled-back';
}

interface UseOptimisticOptions<T> {
  onConflict?: (local: T, server: T) => T;
  maxPendingMs?: number;
}

export function useOptimisticUpdate<T>(
  initialData: T,
  options: UseOptimisticOptions<T> = {}
) {
  const { onConflict, maxPendingMs = 10_000 } = options;
  const [data, setData] = useState<T>(initialData);
  const [isPending, setIsPending] = useState(false);
  const pendingActions = useRef<OptimisticAction<T>[]>([]);
  const versionRef = useRef(0);

  const mutate = useCallback(
    async (
      optimisticData: T,
      serverFn: () => Promise<T>
    ): Promise<{ success: boolean; data: T }> => {
      const actionId = `opt_${Date.now()}_${Math.random().toString(36).slice(2)}`;
      const currentVersion = ++versionRef.current;
      const rollback = data;

      // Apply optimistic update immediately
      const action: OptimisticAction<T> = {
        id: actionId,
        optimisticData,
        serverFn,
        rollback,
        timestamp: Date.now(),
        status: 'pending',
      };
      pendingActions.current.push(action);
      setData(optimisticData);
      setIsPending(true);

      try {
        const serverResult = await serverFn();

        // Only apply if this is still the latest version
        if (versionRef.current === currentVersion) {
          action.status = 'confirmed';

          // Check for conflicts
          if (onConflict && JSON.stringify(serverResult) !== JSON.stringify(optimisticData)) {
            const resolved = onConflict(optimisticData, serverResult);
            setData(resolved);
          } else {
            setData(serverResult);
          }
        }

        return { success: true, data: serverResult };
      } catch (err) {
        // Rollback
        action.status = 'rolled-back';
        if (versionRef.current === currentVersion) {
          setData(rollback);
        }
        return { success: false, data: rollback };
      } finally {
        pendingActions.current = pendingActions.current.filter((a) => a.id !== actionId);
        setIsPending(pendingActions.current.length > 0);
      }
    },
    [data, onConflict]
  );

  // Clean stale pending actions
  const cleanStale = useCallback(() => {
    const now = Date.now();
    pendingActions.current = pendingActions.current.filter(
      (a) => now - a.timestamp < maxPendingMs
    );
  }, [maxPendingMs]);

  return { data, mutate, isPending, cleanStale };
}
OPEOF
)
    _rts_write_file "${project_dir}/src/hooks/useOptimisticUpdate.ts" "$optimistic_ts"
    RTS_GENERATED=$((RTS_GENERATED + 1))
    return 0
}

# =============================================================================
# rs_generate_reconnection - 自動再接続
# =============================================================================
rs_generate_reconnection() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local reconnect_ts
    reconnect_ts=$(cat <<'RCEOF'
type MessageQueueItem = { event: string; data: unknown; timestamp: number };

export class ReconnectionManager {
  private retryCount = 0;
  private maxRetries: number;
  private baseDelay: number;
  private maxDelay: number;
  private messageQueue: MessageQueueItem[] = [];
  private maxQueueSize: number;
  private connectFn: () => Promise<void>;
  private onReconnected?: (missedMessages: MessageQueueItem[]) => void;
  private timer: NodeJS.Timeout | null = null;

  constructor(options: {
    connectFn: () => Promise<void>;
    maxRetries?: number;
    baseDelayMs?: number;
    maxDelayMs?: number;
    maxQueueSize?: number;
    onReconnected?: (missedMessages: MessageQueueItem[]) => void;
  }) {
    this.connectFn = options.connectFn;
    this.maxRetries = options.maxRetries ?? 15;
    this.baseDelay = options.baseDelayMs ?? 1000;
    this.maxDelay = options.maxDelayMs ?? 30000;
    this.maxQueueSize = options.maxQueueSize ?? 100;
    this.onReconnected = options.onReconnected;
  }

  async scheduleReconnect(): Promise<boolean> {
    if (this.retryCount >= this.maxRetries) {
      console.error(`[reconnect] Max retries (${this.maxRetries}) exceeded`);
      return false;
    }

    const delay = Math.min(
      this.baseDelay * Math.pow(2, this.retryCount) + Math.random() * 1000,
      this.maxDelay
    );

    this.retryCount++;
    console.log(`[reconnect] Attempt ${this.retryCount}/${this.maxRetries} in ${Math.round(delay)}ms`);

    return new Promise((resolve) => {
      this.timer = setTimeout(async () => {
        try {
          await this.connectFn();
          console.log(`[reconnect] Connected after ${this.retryCount} attempts`);
          this.onReconnected?.(this.drainQueue());
          this.retryCount = 0;
          resolve(true);
        } catch {
          const result = await this.scheduleReconnect();
          resolve(result);
        }
      }, delay);
    });
  }

  enqueueMessage(event: string, data: unknown) {
    if (this.messageQueue.length >= this.maxQueueSize) {
      this.messageQueue.shift(); // Drop oldest
    }
    this.messageQueue.push({ event, data, timestamp: Date.now() });
  }

  drainQueue(): MessageQueueItem[] {
    const messages = [...this.messageQueue];
    this.messageQueue = [];
    return messages;
  }

  reset() {
    this.retryCount = 0;
    this.messageQueue = [];
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
  }

  getRetryCount(): number {
    return this.retryCount;
  }

  getQueueSize(): number {
    return this.messageQueue.length;
  }
}
RCEOF
)
    _rts_write_file "${project_dir}/src/lib/reconnection-manager.ts" "$reconnect_ts"
    RTS_GENERATED=$((RTS_GENERATED + 1))
    return 0
}

# =============================================================================
# rs_inject_realtime_patterns - Claudeプロンプトへのパターン注入
# =============================================================================
rs_inject_realtime_patterns() {
    local prompt="${1:-}"

    cat <<'INJECT'

## [Realtime Patterns] - リアルタイム通信必須要件

### WebSocket必須:
- **認証**: handshake.auth.token でJWT検証、未認証は接続拒否
- **ルーム**: socket.join(room) でチャネル分離、テナント毎にルーム
- **バリデーション**: zod でメッセージペイロードを検証
- **ハートビート**: pingInterval=25s, pingTimeout=10s
- **トランスポート**: WebSocket優先、pollingフォールバック

### SSE必須（WebSocket不要の場合）:
- **ストリーム**: ReadableStream + TextEncoder
- **ハートビート**: 30秒毎にコメント行 `: heartbeat\n\n`
- **ヘッダー**: Content-Type: text/event-stream, Cache-Control: no-cache
- **クリーンアップ**: request.signal.addEventListener('abort') で接続解除

### クライアント必須:
- **useWebSocket**: Socket.IO + 自動再接続 + ルーム参加/離脱
- **useSSE**: EventSource + エラーハンドリング + 再接続
- **楽観的更新**: 即時UI反映→サーバー確認→コンフリクト解決/ロールバック
- **再接続**: 指数バックオフ + メッセージキュー + 再送

INJECT

    echo "$prompt"
}

# =============================================================================
# rts_generate_realtime - 全リアルタイム一括生成（レガシー互換）
# =============================================================================
rts_generate_realtime() {
    local project_dir="${PROJECT_DIR:-./output}"
    rs_generate_websocket_server "$project_dir"
    rs_generate_sse_endpoint "$project_dir"
    rs_generate_client_hooks "$project_dir"
    rs_generate_presence "$project_dir"
    rs_generate_live_cursors "$project_dir"
    rs_generate_optimistic_updates "$project_dir"
    rs_generate_reconnection "$project_dir"
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
rts_report() {
    echo -e "\n  ${BOLD:-}=== realtime-sync v${RTS_VERSION} ===${NC:-}"
    echo -e "  生成数: ${RTS_GENERATED}"
    echo -e "  書込数: ${RTS_FILES_WRITTEN}"
    echo -e "  エラー: ${RTS_ERRORS}"
}

rts_score() {
    if [[ ${RTS_GENERATED} -ge 5 ]] && [[ ${RTS_ERRORS} -eq 0 ]]; then
        echo "95"
    elif [[ ${RTS_GENERATED} -gt 0 ]] && [[ ${RTS_ERRORS} -eq 0 ]]; then
        echo "85"
    elif [[ ${RTS_GENERATED} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "realtime-sync" --version "${RTS_VERSION}" \
        --description "リアルタイム通信基盤×WebSocket/SSE/プレゼンス/楽観的更新" \
        --init "rs_init" --report "rts_report" --score "rts_score" \
        --enable-var "ENABLE_REALTIME" --cli-flags "--realtime:--no-realtime"
fi

# v2003.1: source時のexit codeを確実に0にする
true
