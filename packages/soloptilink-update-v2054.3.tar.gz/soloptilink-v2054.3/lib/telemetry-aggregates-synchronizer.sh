#!/usr/bin/env bash
# SoloptiLinkAI v2034.0 - Telemetry Aggregates Synchronizer (TAS)
# 学習データ証拠 (2026-05-12):
#   - learning/telemetry/aggregates.json header version="v2033.2"
#     だが本体は v2028.1 (1件) / v2029.0 (2件) のみ
#   - learning/sessions.jsonl は v2033.1 / v2033.2 / v2033.3 を含む 6 record
#   - 旧 schema (status/note/tags) と 新 schema (event/version/task_type/domain) が混在
#   - aggregator が一度も再走していないため telemetry/SAP の判定材料が陳腐化
#
# TAS は sessions.jsonl を 1パスで再集計し、両 schema を理解して
# telemetry/aggregates.json を up-to-date に保つ。
#
# 設計方針:
#   - destructive write は telemetry/aggregates.json のみ (バックアップを保持)
#   - DUE / TAR から呼び出される (idempotent)
#   - jq が無くても動く (pure bash + grep + awk)

[[ -n "${_TAS_LOADED:-}" ]] && return 0
_TAS_LOADED=1

TAS_VERSION="2034.2"
TAS_HOME="${SOLOPTILINK_HOME:-$HOME/.soloptilink}"
TAS_LEARN="${TAS_HOME}/learning"
TAS_SESSIONS="${TAS_LEARN}/sessions.jsonl"
TAS_TELEMETRY_DIR="${TAS_LEARN}/telemetry"
TAS_AGGREGATES="${TAS_TELEMETRY_DIR}/aggregates.json"

mkdir -p "$TAS_TELEMETRY_DIR" 2>/dev/null || true

# ------------------------------------------------------------
# 内部: 1行 JSON から特定フィールド抽出 (簡易・grep + sed)
# 旧 schema: {"ts":"...","status":"ok","note":"...","tags":[...],"schema":"v2027.0"}
# 新 schema: {"ts":"...","event":"session_end","version":"2033.3","status":"ok","fortress_score":165,...}
# ------------------------------------------------------------
_tas_field_str() {
    local line="$1" field="$2"
    echo "$line" | grep -oE "\"${field}\":\"[^\"]*\"" | head -1 \
        | sed -E "s/^\"${field}\":\"//; s/\"$//"
}

_tas_field_num() {
    local line="$1" field="$2"
    echo "$line" | grep -oE "\"${field}\":[0-9.]+" | head -1 \
        | sed -E "s/^\"${field}\"://"
}

# ------------------------------------------------------------
# 集計コア: sessions.jsonl を 1 pass で読み、awk で集計
# 出力 schema:
# {
#   "version": "v2034.0",
#   "generated_at": "<utc>",
#   "total": <int>,
#   "schema_versions": {"new":<int>, "old":<int>},
#   "by_version": { "<v>": {"count":<>,"success_rate":<>,"fortress_avg":<>,"duration_avg_sec":<>} },
#   "by_domain": { "<d>": {"count":<>,"success_rate":<>} },
#   "by_status": {"ok":<>,"fail":<>,"partial":<>}
# }
# ------------------------------------------------------------
tas_rebuild() {
    [[ -f "$TAS_SESSIONS" ]] || {
        echo "[TAS] sessions.jsonl が存在しません: $TAS_SESSIONS" >&2
        return 1
    }

    # バックアップ (1世代)
    [[ -f "$TAS_AGGREGATES" ]] && cp "$TAS_AGGREGATES" "${TAS_AGGREGATES}.bak" 2>/dev/null

    local now
    now=$(date -u +%Y-%m-%dT%H:%M:%SZ)

    # awk で 1パス集計 (新 schema = session_end record のみカウント, 旧 schema は schema_versions.old に集計)
    awk -v now="$now" -v ver="v${TAS_VERSION}" '
    BEGIN {
        new_count = 0
        old_count = 0
        ok = 0; fail = 0; partial = 0
    }
    {
        line = $0
        # event field の有無で新/旧を判定
        if (match(line, /"event":"session_end"/)) {
            new_count++
            # version
            if (match(line, /"version":"[^"]+"/)) {
                v = substr(line, RSTART+11, RLENGTH-12)
                ver_cnt[v]++
                # fortress_score
                if (match(line, /"fortress_score":[0-9.]+/)) {
                    s = substr(line, RSTART+17, RLENGTH-17)
                    ver_score_sum[v] += s
                    ver_score_cnt[v]++
                }
                # duration
                if (match(line, /"duration_sec":[0-9.]+/)) {
                    d = substr(line, RSTART+15, RLENGTH-15)
                    ver_dur_sum[v] += d
                    ver_dur_cnt[v]++
                }
                # status
                if (match(line, /"status":"ok"/)) { ver_ok[v]++; ok++ }
                else if (match(line, /"status":"fail"/)) { ver_fail[v]++; fail++ }
                else if (match(line, /"status":"partial"/)) { ver_partial[v]++; partial++ }
            }
            # domain
            if (match(line, /"domain":"[^"]+"/)) {
                d = substr(line, RSTART+10, RLENGTH-11)
                dom_cnt[d]++
                if (match(line, /"status":"ok"/)) dom_ok[d]++
            }
        } else if (match(line, /"event":"session_start"/)) {
            # start record はカウントしない (ペアの end で集計)
            ;
        } else if (line ~ /"status"/) {
            # 旧 schema (status だけある古いレコード)
            old_count++
        }
    }
    END {
        printf "{\n"
        printf "  \"version\": \"%s\",\n", ver
        printf "  \"generated_at\": \"%s\",\n", now
        printf "  \"total\": %d,\n", new_count
        printf "  \"schema_versions\": {\"new\": %d, \"old\": %d},\n", new_count, old_count
        printf "  \"by_status\": {\"ok\": %d, \"fail\": %d, \"partial\": %d},\n", ok, fail, partial

        # by_version
        printf "  \"by_version\": {"
        first = 1
        for (v in ver_cnt) {
            if (!first) printf ","
            first = 0
            cnt = ver_cnt[v]
            okc = (v in ver_ok ? ver_ok[v] : 0)
            sr = (cnt > 0 ? (okc * 100.0 / cnt) : 0)
            avg_score = (v in ver_score_cnt && ver_score_cnt[v] > 0 ? ver_score_sum[v] / ver_score_cnt[v] : 0)
            avg_dur = (v in ver_dur_cnt && ver_dur_cnt[v] > 0 ? ver_dur_sum[v] / ver_dur_cnt[v] : 0)
            printf "\n    \"%s\": {\"count\": %d, \"success_rate\": %.1f, \"fortress_avg\": %.1f, \"duration_avg_sec\": %.1f}", v, cnt, sr, avg_score, avg_dur
        }
        printf "\n  },\n"

        # by_domain
        printf "  \"by_domain\": {"
        first = 1
        for (d in dom_cnt) {
            if (!first) printf ","
            first = 0
            cnt = dom_cnt[d]
            okc = (d in dom_ok ? dom_ok[d] : 0)
            sr = (cnt > 0 ? (okc * 100.0 / cnt) : 0)
            printf "\n    \"%s\": {\"count\": %d, \"success_rate\": %.1f}", d, cnt, sr
        }
        printf "\n  }\n"
        printf "}\n"
    }
    ' "$TAS_SESSIONS" > "$TAS_AGGREGATES"

    echo "[TAS] aggregates.json updated: $TAS_AGGREGATES"
}

# ------------------------------------------------------------
# サマリ: 最新 aggregates.json から人間可読サマリ
# ------------------------------------------------------------
tas_summary() {
    [[ -f "$TAS_AGGREGATES" ]] || {
        echo "- TAS: aggregates.json 未生成 (tas_rebuild を実行)"
        return 0
    }
    local hdr_ver gen_at total new_cnt old_cnt ok_cnt fail_cnt
    hdr_ver=$(grep -oE '"version":[[:space:]]*"[^"]+"' "$TAS_AGGREGATES" | head -1 | sed -E 's/.*"([^"]+)"$/\1/')
    gen_at=$(grep -oE '"generated_at":[[:space:]]*"[^"]+"' "$TAS_AGGREGATES" | head -1 | sed -E 's/.*"([^"]+)"$/\1/')
    total=$(grep -oE '"total":[[:space:]]*[0-9]+' "$TAS_AGGREGATES" | head -1 | grep -oE '[0-9]+')
    new_cnt=$(grep -oE '"new":[[:space:]]*[0-9]+' "$TAS_AGGREGATES" | head -1 | grep -oE '[0-9]+')
    old_cnt=$(grep -oE '"old":[[:space:]]*[0-9]+' "$TAS_AGGREGATES" | head -1 | grep -oE '[0-9]+')
    ok_cnt=$(grep -oE '"ok":[[:space:]]*[0-9]+' "$TAS_AGGREGATES" | head -1 | grep -oE '[0-9]+')
    fail_cnt=$(grep -oE '"fail":[[:space:]]*[0-9]+' "$TAS_AGGREGATES" | head -1 | grep -oE '[0-9]+')

    echo "- TAS aggregates header: ${hdr_ver:-?} (generated_at: ${gen_at:-?})"
    echo "- TAS schema mix: new=${new_cnt:-0} / old=${old_cnt:-0} (total=${total:-0})"
    echo "- TAS status: ok=${ok_cnt:-0} / fail=${fail_cnt:-0}"

    # by_version 列挙 (簡易)
    local versions
    versions=$(grep -oE '"[0-9]+\.[0-9]+":[[:space:]]*\{"count":[[:space:]]*[0-9]+' "$TAS_AGGREGATES" \
        | sed -E 's/^"([0-9.]+)":[[:space:]]*\{"count":[[:space:]]*([0-9]+).*/    - v\1: count=\2/')
    if [[ -n "$versions" ]]; then
        echo "- TAS by_version:"
        echo "$versions"
    fi
}

# ------------------------------------------------------------
# verdict: aggregates.json が現実と何日ズレているか判定
# ------------------------------------------------------------
tas_freshness_days() {
    [[ -f "$TAS_AGGREGATES" ]] || { echo -1; return; }
    local gen_at epoch_a epoch_n
    gen_at=$(grep -oE '"generated_at":[[:space:]]*"[^"]+"' "$TAS_AGGREGATES" | head -1 | sed -E 's/.*"([^"]+)"$/\1/')
    [[ -z "$gen_at" ]] && { echo -1; return; }
    if epoch_a=$(date -j -u -f "%Y-%m-%dT%H:%M:%SZ" "$gen_at" +%s 2>/dev/null); then
        epoch_n=$(date -u +%s)
        echo $(( (epoch_n - epoch_a) / 86400 ))
    else
        echo -1
    fi
}

# CLI 直接実行
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-summary}" in
        rebuild)   tas_rebuild ;;
        summary)   tas_summary ;;
        freshness) tas_freshness_days ;;
        version)   echo "$TAS_VERSION" ;;
        *) echo "usage: $0 {rebuild|summary|freshness|version}" >&2; exit 2 ;;
    esac
fi
