#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v381.0 - Japanese Business Patterns
# =============================================================================
# 日本固有のビジネスパターン生成エンジン。
# 和暦変換/郵便番号API/インボイス制度/電子帳簿保存法対応等を自動生成。
#
# Functions:
#   _jbp_init                     - 初期化
#   _jbp_generate_wareki          - 和暦変換ユーティリティ
#   _jbp_generate_postal          - 郵便番号→住所変換
#   _jbp_generate_invoice_system  - インボイス制度対応（適格請求書）
#   _jbp_generate_name_format     - 氏名フォーマット（姓名/フリガナ）
#   _jbp_generate_tax_calc        - 消費税計算（軽減税率対応）
#   _jbp_report / _jbp_score
#
# All globals use the JBP_ prefix.
# =============================================================================

[[ -n "${_JAPANESE_BUSINESS_PATTERNS_LOADED:-}" ]] && return 0
_JAPANESE_BUSINESS_PATTERNS_LOADED=1

declare -g JBP_VERSION="381.0"
declare -g JBP_INITIALIZED=false
declare -g JBP_GENERATED_COUNT=0
declare -g JBP_WAREKI_GENERATED=false
declare -g JBP_POSTAL_GENERATED=false
declare -g JBP_INVOICE_GENERATED=false
declare -g JBP_NAME_GENERATED=false
declare -g JBP_TAX_GENERATED=false
declare -g ENABLE_JBP="${ENABLE_JBP:-true}"

_jbp_init() {
    JBP_INITIALIZED=true
    JBP_GENERATED_COUNT=0
    return 0
}

_jbp_generate_all() {
    local project_dir="${1:-.}"
    [[ "$JBP_INITIALIZED" != "true" ]] && _jbp_init

    echo -e "  ${CYAN:-\033[0;36m}[JBP]${NC:-\033[0m} 日本固有ビジネスパターン生成開始..." >&2

    _jbp_generate_wareki "$project_dir"
    _jbp_generate_postal "$project_dir"
    _jbp_generate_invoice_system "$project_dir"
    _jbp_generate_name_format "$project_dir"
    _jbp_generate_tax_calc "$project_dir"

    echo -e "  ${GREEN:-\033[0;32m}[JBP]${NC:-\033[0m} 日本固有パターン生成完了: ${JBP_GENERATED_COUNT}件" >&2
    return 0
}

# =============================================================================
# 和暦変換
# =============================================================================
_jbp_generate_wareki() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [JBP-WAREKI] 和暦変換ユーティリティ

```typescript
interface WarekiEra {
  name: string;
  nameShort: string;
  startDate: Date;
  endDate: Date | null;
}

const ERAS: WarekiEra[] = [
  { name: '令和', nameShort: 'R', startDate: new Date(2019, 4, 1), endDate: null },
  { name: '平成', nameShort: 'H', startDate: new Date(1989, 0, 8), endDate: new Date(2019, 3, 30) },
  { name: '昭和', nameShort: 'S', startDate: new Date(1926, 11, 25), endDate: new Date(1989, 0, 7) },
  { name: '大正', nameShort: 'T', startDate: new Date(1912, 6, 30), endDate: new Date(1926, 11, 24) },
  { name: '明治', nameShort: 'M', startDate: new Date(1868, 0, 25), endDate: new Date(1912, 6, 29) },
];

export function toWareki(date: Date): string {
  const era = ERAS.find(e => date >= e.startDate && (!e.endDate || date <= e.endDate));
  if (!era) throw new Error('対応する元号がありません');
  const year = date.getFullYear() - era.startDate.getFullYear() + 1;
  return `${era.name}${year === 1 ? '元' : year}年${date.getMonth() + 1}月${date.getDate()}日`;
}

export function toWarekiShort(date: Date): string {
  const era = ERAS.find(e => date >= e.startDate && (!e.endDate || date <= e.endDate));
  if (!era) throw new Error('対応する元号がありません');
  const year = date.getFullYear() - era.startDate.getFullYear() + 1;
  return `${era.nameShort}${String(year).padStart(2, '0')}.${String(date.getMonth() + 1).padStart(2, '0')}.${String(date.getDate()).padStart(2, '0')}`;
}

export function fromWareki(warekiStr: string): Date {
  const match = warekiStr.match(/^(令和|平成|昭和|大正|明治)(元|\d+)年(\d+)月(\d+)日$/);
  if (!match) throw new Error('無効な和暦形式');
  const era = ERAS.find(e => e.name === match[1]);
  if (!era) throw new Error('不明な元号');
  const year = match[2] === '元' ? 1 : parseInt(match[2]);
  return new Date(era.startDate.getFullYear() + year - 1, parseInt(match[3]) - 1, parseInt(match[4]));
}

// Zodスキーマ
export const warekiSchema = z.string().refine(v => {
  try { fromWareki(v); return true; } catch { return false; }
}, { message: '有効な和暦を入力してください（例: 令和6年1月1日）' });
```
TEMPLATE

    JBP_WAREKI_GENERATED=true
    JBP_GENERATED_COUNT=$((JBP_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# 郵便番号→住所変換
# =============================================================================
_jbp_generate_postal() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [JBP-POSTAL] 郵便番号→住所変換

```typescript
interface PostalResult {
  zipcode: string;
  prefecture: string;
  prefectureKana: string;
  city: string;
  cityKana: string;
  town: string;
  townKana: string;
}

export async function lookupPostalCode(zipcode: string): Promise<PostalResult | null> {
  const cleaned = zipcode.replace(/[-\s]/g, '');
  if (!/^\d{7}$/.test(cleaned)) throw new Error('郵便番号は7桁の数字で入力してください');

  const res = await fetch(`https://zipcloud.ibsnet.co.jp/api/search?zipcode=${cleaned}`);
  const data = await res.json();
  if (!data.results || data.results.length === 0) return null;

  const r = data.results[0];
  return {
    zipcode: cleaned,
    prefecture: r.address1,
    prefectureKana: r.kana1,
    city: r.address2,
    cityKana: r.kana2,
    town: r.address3,
    townKana: r.kana3,
  };
}

// React Hook
export function usePostalCode() {
  const [isLoading, setIsLoading] = useState(false);
  const lookup = async (zipcode: string) => {
    setIsLoading(true);
    try {
      const result = await lookupPostalCode(zipcode);
      return result;
    } finally {
      setIsLoading(false);
    }
  };
  return { lookup, isLoading };
}

// Component
export function PostalCodeInput({ onAddressFound }: { onAddressFound: (addr: PostalResult) => void }) {
  const { register, watch } = useFormContext();
  const { lookup, isLoading } = usePostalCode();
  const zipcode = watch('zipcode');

  useEffect(() => {
    const cleaned = zipcode?.replace(/[-\s]/g, '');
    if (cleaned?.length === 7) {
      lookup(cleaned).then(result => { if (result) onAddressFound(result); });
    }
  }, [zipcode]);

  return (
    <div className="flex gap-2 items-end">
      <Input label="郵便番号" placeholder="000-0000" {...register('zipcode')} />
      {isLoading && <Spinner size="sm" />}
    </div>
  );
}
```
TEMPLATE

    JBP_POSTAL_GENERATED=true
    JBP_GENERATED_COUNT=$((JBP_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# インボイス制度対応
# =============================================================================
_jbp_generate_invoice_system() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [JBP-INVOICE] インボイス制度（適格請求書等保存方式）対応

```typescript
// 適格請求書の必須要素
interface QualifiedInvoice {
  issuerName: string;               // 適格請求書発行事業者の氏名又は名称
  registrationNumber: string;       // 登録番号（T+13桁）
  transactionDate: Date;            // 取引年月日
  description: string;              // 取引内容
  items: InvoiceItem[];
  taxBreakdown: TaxBreakdown[];     // 税率ごとの合計
  totalWithTax: number;             // 税込合計
  recipientName: string;            // 書類の交付を受ける事業者の氏名又は名称
}

interface TaxBreakdown {
  taxRate: number;    // 10 or 8
  subtotal: number;   // 税抜合計
  taxAmount: number;  // 消費税額
}

// 登録番号バリデーション
export const registrationNumberSchema = z.string()
  .regex(/^T\d{13}$/, '登録番号はT+13桁の数字です（例: T1234567890123）');

// インボイス生成
export function generateQualifiedInvoice(data: CreateInvoiceInput): QualifiedInvoice {
  const standardItems = data.items.filter(i => i.taxRate === 10);
  const reducedItems = data.items.filter(i => i.taxRate === 8);
  const taxBreakdown: TaxBreakdown[] = [];

  if (standardItems.length > 0) {
    const subtotal = standardItems.reduce((s, i) => s + i.amount, 0);
    taxBreakdown.push({ taxRate: 10, subtotal, taxAmount: Math.floor(subtotal * 0.1) });
  }
  if (reducedItems.length > 0) {
    const subtotal = reducedItems.reduce((s, i) => s + i.amount, 0);
    taxBreakdown.push({ taxRate: 8, subtotal, taxAmount: Math.floor(subtotal * 0.08) });
  }

  const totalWithTax = taxBreakdown.reduce((s, t) => s + t.subtotal + t.taxAmount, 0);

  return {
    issuerName: data.issuerName,
    registrationNumber: data.registrationNumber,
    transactionDate: data.transactionDate,
    description: data.description,
    items: data.items,
    taxBreakdown,
    totalWithTax,
    recipientName: data.recipientName,
  };
}

// 軽減税率マーク表示
export function TaxRateLabel({ rate }: { rate: number }) {
  return rate === 8 ? <span className="text-xs text-blue-600">※軽減8%</span> : <span className="text-xs">10%</span>;
}
```
TEMPLATE

    JBP_INVOICE_GENERATED=true
    JBP_GENERATED_COUNT=$((JBP_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# 氏名フォーマット
# =============================================================================
_jbp_generate_name_format() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [JBP-NAME] 日本式氏名フォーマット

```typescript
// Zodスキーマ
export const japaneseNameSchema = z.object({
  lastName: z.string().min(1, '姓を入力してください'),
  firstName: z.string().min(1, '名を入力してください'),
  lastNameKana: z.string().min(1, 'セイを入力してください').regex(/^[\u30A0-\u30FF]+$/, 'カタカナで入力してください'),
  firstNameKana: z.string().min(1, 'メイを入力してください').regex(/^[\u30A0-\u30FF]+$/, 'カタカナで入力してください'),
});

export function formatFullName(lastName: string, firstName: string): string {
  return `${lastName} ${firstName}`;
}

export function formatFullNameKana(lastNameKana: string, firstNameKana: string): string {
  return `${lastNameKana} ${firstNameKana}`;
}

// 敬称
export function formatWithHonorific(name: string, honorific: string = '様'): string {
  return `${name}${honorific}`;
}
```
TEMPLATE

    JBP_NAME_GENERATED=true
    JBP_GENERATED_COUNT=$((JBP_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# 消費税計算
# =============================================================================
_jbp_generate_tax_calc() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [JBP-TAX] 消費税計算（軽減税率対応）

```typescript
const TAX_RATES = { standard: 0.10, reduced: 0.08 } as const;
type TaxCategory = keyof typeof TAX_RATES;

export function calculateTax(amount: number, category: TaxCategory = 'standard'): { subtotal: number; tax: number; total: number } {
  const rate = TAX_RATES[category];
  const tax = Math.floor(amount * rate);
  return { subtotal: amount, tax, total: amount + tax };
}

export function calculateTaxIncluded(totalWithTax: number, category: TaxCategory = 'standard'): { subtotal: number; tax: number; total: number } {
  const rate = TAX_RATES[category];
  const subtotal = Math.round(totalWithTax / (1 + rate));
  const tax = totalWithTax - subtotal;
  return { subtotal, tax, total: totalWithTax };
}

// 複数税率の合計
export function calculateMixedTax(items: { amount: number; category: TaxCategory }[]): { byRate: Record<string, { subtotal: number; tax: number }>; grandTotal: number } {
  const byRate: Record<string, { subtotal: number; tax: number }> = {};
  for (const item of items) {
    const key = `${TAX_RATES[item.category] * 100}%`;
    if (!byRate[key]) byRate[key] = { subtotal: 0, tax: 0 };
    byRate[key].subtotal += item.amount;
    byRate[key].tax += Math.floor(item.amount * TAX_RATES[item.category]);
  }
  const grandTotal = Object.values(byRate).reduce((s, r) => s + r.subtotal + r.tax, 0);
  return { byRate, grandTotal };
}
```
TEMPLATE

    JBP_TAX_GENERATED=true
    JBP_GENERATED_COUNT=$((JBP_GENERATED_COUNT + 1))
    return 0
}

_jbp_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Japanese Business Patterns v${JBP_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成パターン数     : ${JBP_GENERATED_COUNT}"
    echo -e "  和暦               : ${JBP_WAREKI_GENERATED}"
    echo -e "  郵便番号           : ${JBP_POSTAL_GENERATED}"
    echo -e "  インボイス制度     : ${JBP_INVOICE_GENERATED}"
    echo -e "  氏名フォーマット   : ${JBP_NAME_GENERATED}"
    echo -e "  消費税計算         : ${JBP_TAX_GENERATED}"
}

_jbp_score() {
    local score=20
    [[ "$JBP_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$JBP_WAREKI_GENERATED" == "true" ]] && score=$((score + 14))
    [[ "$JBP_POSTAL_GENERATED" == "true" ]] && score=$((score + 14))
    [[ "$JBP_INVOICE_GENERATED" == "true" ]] && score=$((score + 14))
    [[ "$JBP_NAME_GENERATED" == "true" ]] && score=$((score + 14))
    [[ "$JBP_TAX_GENERATED" == "true" ]] && score=$((score + 14))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "japanese-business-patterns" \
    --version "381.0" \
    --description "日本固有ビジネスパターン（和暦/郵便番号/インボイス制度/氏名/消費税）" \
    --init "_jbp_init" \
    --report "_jbp_report" \
    --score "_jbp_score" \
    --enable-var "ENABLE_JBP" \
    --cli-flags "--japanese-patterns:--no-japanese-patterns"
