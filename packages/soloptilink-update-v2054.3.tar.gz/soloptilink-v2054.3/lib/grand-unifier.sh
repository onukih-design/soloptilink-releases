#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v50.0 - Grand Unifier Engine
# =============================================================================
# 全モジュール（Layer 0-20）を統合し、セッション全体を俯瞰する
# グランドユニファイアエンジン。
#
# Functions:
#   gu_init, gu_collect_all, gu_compute_score, gu_generate_advisory
#   gu_get_session_summary, gu_get_next_session_hints, gu_get_stats, gu_save
#
# All globals use the GU_ prefix.
# =============================================================================

[[ -n "${_GRAND_UNIFIER_LOADED:-}" ]] && return 0
_GRAND_UNIFIER_LOADED=1

declare -g GU_VERSION="50.0"
declare -g GU_ENABLED="${GU_ENABLED:-true}"

declare -g GU_UNIFIED_SCORE=0
declare -g GU_MODULES_ACTIVE=0
declare -g GU_MODULES_TOTAL=0
declare -g GU_ADVISORY=""
declare -g GU_SESSION_SUMMARY=""
declare -g GU_COLLECTIONS_RUN=0
declare -g GU_SAVE_FILE=""

declare -g GU_HEALTH_SCORE=100
declare -g GU_QUALITY_SCORE=0
declare -g GU_COST_EFFICIENCY=0
declare -g GU_ERROR_RATE=0
declare -g GU_TUNING_STATUS=""

gu_init() {
    local session_id="${1:-default}"
    GU_UNIFIED_SCORE=0; GU_MODULES_ACTIVE=0; GU_MODULES_TOTAL=0
    GU_ADVISORY=""; GU_SESSION_SUMMARY=""; GU_COLLECTIONS_RUN=0
    GU_HEALTH_SCORE=100; GU_QUALITY_SCORE=0; GU_COST_EFFICIENCY=0
    GU_ERROR_RATE=0; GU_TUNING_STATUS="not_started"
    local knowledge_dir="${HOME}/.soloptilink/knowledge"
    mkdir -p "$knowledge_dir" 2>/dev/null || true
    GU_SAVE_FILE="${knowledge_dir}/grand_unifier_state.json"
    return 0
}

gu_collect_all() {
    GU_COLLECTIONS_RUN=$((GU_COLLECTIONS_RUN + 1))
    GU_MODULES_ACTIVE=0; GU_MODULES_TOTAL=21

    if type -t hm_get_health_score &>/dev/null; then
        GU_HEALTH_SCORE=$(hm_get_health_score 2>/dev/null || echo "100")
        GU_MODULES_ACTIVE=$((GU_MODULES_ACTIVE + 1))
    fi
    if [[ -n "${QG_SCORE:-}" ]]; then
        GU_QUALITY_SCORE="${QG_SCORE:-0}"
        GU_MODULES_ACTIVE=$((GU_MODULES_ACTIVE + 1))
    fi
    if [[ -n "${CG_TOTAL_ACTUAL:-}" && -n "${CG_TOTAL_ESTIMATED:-}" ]]; then
        local est_cents act_cents
        est_cents=$(echo "${CG_TOTAL_ESTIMATED:-0}" | awk '{printf "%d", $1 * 100}' 2>/dev/null || echo "0")
        act_cents=$(echo "${CG_TOTAL_ACTUAL:-0}" | awk '{printf "%d", $1 * 100}' 2>/dev/null || echo "0")
        if [[ "$est_cents" -gt 0 ]]; then
            local ratio=$((act_cents * 100 / est_cents))
            if [[ $ratio -gt 100 ]]; then GU_COST_EFFICIENCY=$((200 - ratio))
            else GU_COST_EFFICIENCY=$ratio; fi
            [[ $GU_COST_EFFICIENCY -lt 0 ]] && GU_COST_EFFICIENCY=0
            [[ $GU_COST_EFFICIENCY -gt 100 ]] && GU_COST_EFFICIENCY=100
        fi
        GU_MODULES_ACTIVE=$((GU_MODULES_ACTIVE + 1))
    fi
    if [[ -n "${EC_TOTAL_ERRORS:-}" ]]; then
        GU_ERROR_RATE=${EC_TOTAL_ERRORS:-0}
        GU_MODULES_ACTIVE=$((GU_MODULES_ACTIVE + 1))
    fi
    if [[ -n "${ST_TUNING_ROUNDS:-}" ]]; then
        if [[ ${ST_TUNING_ROUNDS:-0} -gt 0 ]]; then GU_TUNING_STATUS="active"
        else GU_TUNING_STATUS="idle"; fi
        GU_MODULES_ACTIVE=$((GU_MODULES_ACTIVE + 1))
    fi

    local check_funcs=("ds_get_stats" "pf_get_stats" "cs_get_stats" "ud_get_stats" "sv2_get_stats" "ap2_get_stats" "sr_get_stats" "pm_get_stats" "po_get_stats" "oa_get_stats" "ls_get_stats")
    for func in "${check_funcs[@]}"; do
        if type -t "$func" &>/dev/null; then GU_MODULES_ACTIVE=$((GU_MODULES_ACTIVE + 1)); fi
    done
    return 0
}

gu_compute_score() {
    local score=50
    local health_bonus=$((GU_HEALTH_SCORE * 20 / 100))
    score=$((score + health_bonus))
    if [[ ${GU_QUALITY_SCORE:-0} -gt 0 ]]; then
        local quality_bonus=$((GU_QUALITY_SCORE * 20 / 100))
        score=$((score + quality_bonus))
    fi
    if [[ ${GU_COST_EFFICIENCY:-0} -gt 0 ]]; then
        local cost_bonus=$((GU_COST_EFFICIENCY * 10 / 100))
        score=$((score + cost_bonus))
    fi
    if [[ ${GU_ERROR_RATE:-0} -gt 10 ]]; then score=$((score - 20))
    elif [[ ${GU_ERROR_RATE:-0} -gt 5 ]]; then score=$((score - 10))
    elif [[ ${GU_ERROR_RATE:-0} -gt 0 ]]; then score=$((score - 5)); fi
    [[ $score -lt 0 ]] && score=0; [[ $score -gt 100 ]] && score=100
    GU_UNIFIED_SCORE=$score
    echo "$score"
}

gu_generate_advisory() {
    local advisories=""
    if [[ ${GU_HEALTH_SCORE:-100} -lt 50 ]]; then advisories="system_degraded:reduce_agents_and_downgrade_model"
    elif [[ ${GU_HEALTH_SCORE:-100} -lt 70 ]]; then advisories="system_stressed:monitor_resources"; fi
    if [[ ${GU_QUALITY_SCORE:-0} -gt 0 && ${GU_QUALITY_SCORE:-0} -lt 70 ]]; then
        advisories="${advisories:+${advisories};}quality_low:enable_strict_validation"; fi
    if [[ ${GU_ERROR_RATE:-0} -gt 5 ]]; then
        advisories="${advisories:+${advisories};}high_error_rate:enable_error_chain_analysis"; fi
    if [[ "$GU_TUNING_STATUS" == "not_started" ]]; then
        advisories="${advisories:+${advisories};}tuning_needed:run_self_tuning"; fi
    if [[ $GU_MODULES_ACTIVE -lt 5 ]]; then
        advisories="${advisories:+${advisories};}low_module_coverage:check_layer_loader"; fi
    [[ -z "$advisories" ]] && advisories="all_systems_nominal"
    GU_ADVISORY="$advisories"
    echo "$advisories"
}

gu_get_session_summary() {
    gu_collect_all 2>/dev/null || true
    gu_compute_score 2>/dev/null || true
    gu_generate_advisory 2>/dev/null || true
    local summary="score=${GU_UNIFIED_SCORE};modules=${GU_MODULES_ACTIVE}/${GU_MODULES_TOTAL};health=${GU_HEALTH_SCORE};quality=${GU_QUALITY_SCORE};errors=${GU_ERROR_RATE};advisory=${GU_ADVISORY}"
    GU_SESSION_SUMMARY="$summary"
    echo "$summary"
}

gu_get_next_session_hints() {
    local hints=""
    if type -t st_get_tuned_config &>/dev/null; then
        local tuned; tuned=$(st_get_tuned_config 2>/dev/null || echo "")
        if [[ -n "$tuned" ]]; then hints="tuned_config:${tuned}"; fi
    fi
    if type -t cs_generate_advisory &>/dev/null; then
        local cs_adv; cs_adv=$(cs_generate_advisory 2>/dev/null || echo "")
        if [[ -n "$cs_adv" && "$cs_adv" != "normal_operation" ]]; then hints="${hints:+${hints};}cross_session:${cs_adv}"; fi
    fi
    if [[ ${EC_TOTAL_ERRORS:-0} -gt 0 ]]; then
        local chain; chain=$(ec_get_chain 3 2>/dev/null || echo "")
        if [[ -n "$chain" && "$chain" != "no_errors" ]]; then hints="${hints:+${hints};}error_pattern:${chain}"; fi
    fi
    [[ -z "$hints" ]] && hints="no_hints_available"
    echo "$hints"
}

gu_get_stats() {
    cat <<EOF
{
  "version": "${GU_VERSION}",
  "unified_score": ${GU_UNIFIED_SCORE},
  "modules_active": ${GU_MODULES_ACTIVE},
  "modules_total": ${GU_MODULES_TOTAL},
  "health_score": ${GU_HEALTH_SCORE},
  "quality_score": ${GU_QUALITY_SCORE},
  "cost_efficiency": ${GU_COST_EFFICIENCY},
  "error_rate": ${GU_ERROR_RATE},
  "tuning_status": "${GU_TUNING_STATUS}",
  "collections_run": ${GU_COLLECTIONS_RUN},
  "advisory": "${GU_ADVISORY}"
}
EOF
}

gu_save() {
    [[ -z "$GU_SAVE_FILE" ]] && return 0
    local timestamp; timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date +"%Y-%m-%d")
    cat > "$GU_SAVE_FILE" 2>/dev/null <<EOF
{
  "timestamp": "${timestamp}",
  "version": "${GU_VERSION}",
  "unified_score": ${GU_UNIFIED_SCORE},
  "modules_active": ${GU_MODULES_ACTIVE},
  "modules_total": ${GU_MODULES_TOTAL},
  "health_score": ${GU_HEALTH_SCORE},
  "quality_score": ${GU_QUALITY_SCORE},
  "cost_efficiency": ${GU_COST_EFFICIENCY},
  "error_rate": ${GU_ERROR_RATE},
  "tuning_status": "${GU_TUNING_STATUS}",
  "advisory": "${GU_ADVISORY}",
  "session_summary": "${GU_SESSION_SUMMARY}"
}
EOF
    local history_file="${HOME}/.soloptilink/knowledge/grand_unifier_history.jsonl"
    echo "{\"timestamp\":\"${timestamp}\",\"score\":${GU_UNIFIED_SCORE},\"modules\":${GU_MODULES_ACTIVE},\"health\":${GU_HEALTH_SCORE},\"quality\":${GU_QUALITY_SCORE},\"errors\":${GU_ERROR_RATE}}" >> "$history_file" 2>/dev/null || true
    return 0
}
