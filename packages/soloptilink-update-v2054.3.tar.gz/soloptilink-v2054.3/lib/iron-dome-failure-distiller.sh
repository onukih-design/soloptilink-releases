#!/usr/bin/env bash
# SoloptiLinkAI v2034.1 - Iron-Dome Failure Distiller (IFD)
# learning/iron-dome/failure_patterns.jsonl の業種別失敗パターンを
# 構造化された 0-shot 解決テンプレとして learning/solutions/index.jsonl に蓄積する
#
# v2033.0 CHANGELOG で「次走対応」と宣言された commitment を実装:
#   - construction / ui_density_low (UD06 Skeleton + UD08 ErrorState 不足)
#   - healthcare   / quindeca_reject (Cognitive Empathy 142 未満)
#
# 設計方針:
#   - 読み取り + 既存 solutions/index.jsonl への append (重複登録は signature 一致でスキップ)
#   - destructive 操作なし (既存行の書き換え禁止 = append-only)
#   - DUE から呼び出され、レポートに inline で埋め込まれる
#
# 学習データ根拠 (2026-05-06 記録の iron-dome failure_patterns):
#   {"id":"fp-...0001","industry":"construction","kind":"ui_density_low",
#    "remediation_hint":"Step3で全panelにSkeletonコンポーネント+app/error.tsx必須"}
#   {"id":"fp-...0002","industry":"healthcare","kind":"quindeca_reject",
#    "remediation_hint":"Step0.62.5でMulti-Perspective Council 7視点を必ず通す"}

[[ -n "${_IFD_LOADED:-}" ]] && return 0
_IFD_LOADED=1

IFD_VERSION="2034.2"
IFD_HOME="${SOLOPTILINK_HOME:-$HOME/.soloptilink}"
IFD_FAILURES="${IFD_HOME}/learning/iron-dome/failure_patterns.jsonl"
IFD_SOLUTIONS="${IFD_HOME}/learning/solutions/index.jsonl"

# ============================================================
# signature 生成: 業種 + kind を一意キー化
# ============================================================
ifd_signature() {
    local industry="$1" kind="$2"
    echo "iron_dome_${industry}_${kind}"
}

# ============================================================
# 既存 solutions に signature が登録済みか判定
# ============================================================
ifd_already_registered() {
    local signature="$1"
    [[ -f "$IFD_SOLUTIONS" ]] || return 1
    grep -q "\"error_signature\":\"${signature}\"" "$IFD_SOLUTIONS" 2>/dev/null
}

# ============================================================
# 失敗パターン件数取得
# ============================================================
ifd_count_failures() {
    [[ -f "$IFD_FAILURES" ]] || { echo 0; return; }
    wc -l < "$IFD_FAILURES" | tr -d ' '
}

# ============================================================
# 取込実行 (1パターンあたり1エントリを append)
# ============================================================
ifd_distill() {
    [[ -f "$IFD_FAILURES" ]] || { echo "[IFD] no failure_patterns.jsonl" >&2; return 0; }
    mkdir -p "$(dirname "$IFD_SOLUTIONS")" 2>/dev/null || true
    touch "$IFD_SOLUTIONS"

    local appended=0 skipped=0
    local now
    now=$(date -u +%Y-%m-%dT%H:%M:%SZ)

    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        local industry kind hint
        industry=$(echo "$line" | grep -oE '"industry":"[^"]*"' | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
        kind=$(echo "$line" | grep -oE '"kind":"[^"]*"' | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
        hint=$(echo "$line" | grep -oE '"remediation_hint":"[^"]*"' | head -1 | sed 's/^"remediation_hint":"//; s/"$//')
        [[ -z "$industry" || -z "$kind" ]] && continue

        local sig
        sig=$(ifd_signature "$industry" "$kind")

        if ifd_already_registered "$sig"; then
            skipped=$((skipped + 1))
            continue
        fi

        # JSON 1行を append (escape は最小限 — hint 内のダブルクオートは grep で既に除外済み)
        local fix_hash
        fix_hash=$(echo -n "$sig" | shasum -a 256 2>/dev/null | cut -c1-8)
        [[ -z "$fix_hash" ]] && fix_hash="ifd-2034"

        printf '{"error_signature":"%s","domain":"%s","fix_hash":"%s","fix_description":"%s","success_count":0,"fail_count":0,"success_rate":null,"last_used":"%s","registered_by":"IFD v%s"}\n' \
            "$sig" "$industry" "$fix_hash" "${hint:-Iron-Dome failure: see learning/iron-dome/failure_patterns.jsonl}" "$now" "$IFD_VERSION" \
            >> "$IFD_SOLUTIONS"
        appended=$((appended + 1))
    done < "$IFD_FAILURES"

    echo "appended=${appended} skipped=${skipped}"
}

# ============================================================
# サマリ (DUE から呼ばれる)
# ============================================================
ifd_summary() {
    local total
    total=$(ifd_count_failures)
    if [[ "$total" -eq 0 ]]; then
        echo "- IFD: iron-dome failure_patterns 未生成 (Diamond 採点が一度も failed していない正常状態)"
        return 0
    fi
    echo "- IFD: iron-dome failure patterns ${total} 件検出"
    # signature ベースで既登録 / 未登録を分離
    local registered=0 unregistered=0
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        local industry kind
        industry=$(echo "$line" | grep -oE '"industry":"[^"]*"' | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
        kind=$(echo "$line" | grep -oE '"kind":"[^"]*"' | head -1 | sed 's/.*"\([^"]*\)"$/\1/')
        [[ -z "$industry" || -z "$kind" ]] && continue
        if ifd_already_registered "$(ifd_signature "$industry" "$kind")"; then
            registered=$((registered + 1))
        else
            unregistered=$((unregistered + 1))
        fi
    done < "$IFD_FAILURES"
    echo "  - solutions 登録済: ${registered} / 未登録: ${unregistered}"
    if [[ "$unregistered" -gt 0 ]]; then
        echo "  - 推奨: 'ifd_distill' を実行して 0-shot 解決テンプレを永続化"
    fi
}

# CLI 直接実行サポート
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-summary}" in
        summary) ifd_summary ;;
        distill) ifd_distill ;;
        version) echo "$IFD_VERSION" ;;
        *)
            echo "usage: $0 {summary|distill|version}" >&2
            exit 2
            ;;
    esac
fi
