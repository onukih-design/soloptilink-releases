// SoloptiLink Chain v31.0 - Prisma Client Singleton
// シングルトンパターンでPrisma Clientを初期化
// 開発環境での接続プーリング最適化

import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const prisma =
  globalForPrisma.prisma ??
  new PrismaClient({
    log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
  })

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma

// グレースフルシャットダウン
process.on('beforeExit', async () => {
  await prisma.$disconnect()
})
