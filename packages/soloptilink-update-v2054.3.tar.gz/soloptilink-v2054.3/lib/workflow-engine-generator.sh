#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v313.0 - Workflow Engine Generator
# =============================================================================
# ワークフローエンジン自動生成: 定義モデル/ステートマシン/承認フロー/トリガー
#
# 全globals: WEG_ prefix
# =============================================================================

[[ -n "${_WORKFLOW_ENGINE_GENERATOR_LOADED:-}" ]] && return 0
_WORKFLOW_ENGINE_GENERATOR_LOADED=1

declare -g WEG_VERSION="313.0"
declare -g WEG_INITIALIZED=false
declare -g WEG_GENERATED_COUNT=0
declare -g ENABLE_WORKFLOW_ENGINE_GENERATOR="${ENABLE_WORKFLOW_ENGINE_GENERATOR:-true}"

readonly WEG_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly WEG_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly WEG_BOLD="${CLR_BOLD:-\033[1m}"
readonly WEG_NC="${CLR_NC:-\033[0m}"

_weg_log() { echo -e "  ${WEG_CYAN}[WEG]${WEG_NC} $*" >&2; }
_weg_ok()  { echo -e "  ${WEG_GREEN}[WEG] OK${WEG_NC} $*" >&2; }

weg_init() { WEG_INITIALIZED=true; WEG_GENERATED_COUNT=0; return 0; }
weg_report() { [[ "$WEG_INITIALIZED" != "true" ]] && return 0; echo -e "\n  ${WEG_BOLD}--- Workflow Engine Generator v${WEG_VERSION} ---${WEG_NC}" >&2; echo -e "  生成数: ${WEG_GENERATED_COUNT}" >&2; }
weg_score() { [[ "$WEG_INITIALIZED" != "true" ]] && { echo "0"; return; }; local s=50; [[ $WEG_GENERATED_COUNT -ge 3 ]] && s=85; echo "$s"; }
weg_init_message() { echo -e "  ${WEG_GREEN}v${WEG_VERSION} workflow-engine-generator: ワークフローエンジン自動生成${WEG_NC}" >&2; }

_weg_generate_workflow_model() {
    local project_dir="${1:-.}"
    _weg_log "ワークフローモデル生成"
    local snippet='
// --- Workflow Engine Models (v313.0) ---
model Workflow {
  id          String   @id @default(cuid())
  name        String
  description String?
  version     Int      @default(1)
  states      Json     // [{id, name, type: "start"|"task"|"approval"|"end", transitions: [{to, condition?}]}]
  triggers    WorkflowTrigger[]
  instances   WorkflowInstance[]
  isActive    Boolean  @default(true)
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}

model WorkflowInstance {
  id          String   @id @default(cuid())
  workflowId  String
  workflow    Workflow  @relation(fields: [workflowId], references: [id])
  currentState String
  data        Json?
  status      WFInstanceStatus @default(RUNNING)
  history     WorkflowHistory[]
  startedAt   DateTime @default(now())
  completedAt DateTime?
}

enum WFInstanceStatus { RUNNING COMPLETED CANCELLED FAILED PAUSED }

model WorkflowHistory {
  id         String   @id @default(cuid())
  instanceId String
  instance   WorkflowInstance @relation(fields: [instanceId], references: [id], onDelete: Cascade)
  fromState  String
  toState    String
  action     String?
  actorId    String?
  comment    String?
  createdAt  DateTime @default(now())
}

model WorkflowTrigger {
  id         String   @id @default(cuid())
  workflowId String
  workflow   Workflow  @relation(fields: [workflowId], references: [id], onDelete: Cascade)
  type       TriggerType
  config     Json?    // {schedule: "0 9 * * *"} or {event: "order.created"} etc.
  isActive   Boolean  @default(true)
}

enum TriggerType { MANUAL SCHEDULE EVENT WEBHOOK }'

    mkdir -p "${project_dir}/prisma"
    local sf="${project_dir}/prisma/schema.prisma"
    if [[ -f "$sf" ]] && ! grep -q "model Workflow" "$sf" 2>/dev/null; then echo "$snippet" >> "$sf"; fi
    WEG_GENERATED_COUNT=$((WEG_GENERATED_COUNT + 1))
    _weg_ok "ワークフローモデル生成完了"
    return 0
}

_weg_generate_state_machine() {
    local project_dir="${1:-.}"
    _weg_log "ステートマシンエンジン生成"
    local lib_dir="${project_dir}/src/lib"
    mkdir -p "$lib_dir"

    cat > "${lib_dir}/workflow-engine.ts" <<'EOF'
import { prisma } from '@/lib/prisma';

interface State { id: string; name: string; type: 'start' | 'task' | 'approval' | 'end'; transitions: { to: string; condition?: string }[]; }

export class WorkflowEngine {
  static async startWorkflow(workflowId: string, data?: Record<string, any>) {
    const workflow = await prisma.workflow.findUnique({ where: { id: workflowId } });
    if (!workflow || !workflow.isActive) throw new Error('Workflow not found or inactive');

    const states = workflow.states as State[];
    const startState = states.find(s => s.type === 'start');
    if (!startState) throw new Error('No start state defined');

    const instance = await prisma.workflowInstance.create({
      data: { workflowId, currentState: startState.id, data: data || {} },
    });
    return instance;
  }

  static async transition(instanceId: string, action: string, actorId?: string, comment?: string) {
    const instance = await prisma.workflowInstance.findUnique({ where: { id: instanceId }, include: { workflow: true } });
    if (!instance || instance.status !== 'RUNNING') throw new Error('Instance not found or not running');

    const states = instance.workflow.states as State[];
    const currentState = states.find(s => s.id === instance.currentState);
    if (!currentState) throw new Error('Current state not found');

    const transition = currentState.transitions.find(t => !t.condition || t.condition === action);
    if (!transition) throw new Error(`No valid transition for action: ${action}`);

    const nextState = states.find(s => s.id === transition.to);
    if (!nextState) throw new Error('Target state not found');

    const result = await prisma.$transaction(async (tx) => {
      await tx.workflowHistory.create({
        data: { instanceId, fromState: instance.currentState, toState: nextState.id, action, actorId, comment },
      });

      const update: any = { currentState: nextState.id };
      if (nextState.type === 'end') { update.status = 'COMPLETED'; update.completedAt = new Date(); }

      return tx.workflowInstance.update({ where: { id: instanceId }, data: update });
    });

    return result;
  }

  static async getInstanceStatus(instanceId: string) {
    const instance = await prisma.workflowInstance.findUnique({
      where: { id: instanceId },
      include: { workflow: true, history: { orderBy: { createdAt: 'asc' } } },
    });
    if (!instance) return null;

    const states = instance.workflow.states as State[];
    const currentState = states.find(s => s.id === instance.currentState);
    const availableTransitions = currentState?.transitions || [];

    return { ...instance, currentStateName: currentState?.name, availableTransitions };
  }
}
EOF

    WEG_GENERATED_COUNT=$((WEG_GENERATED_COUNT + 1))
    _weg_ok "ステートマシンエンジン生成完了"
    return 0
}

_weg_generate_approval_flow() {
    local project_dir="${1:-.}"
    _weg_log "承認フロー生成"
    local api_dir="${project_dir}/src/app/api/workflows/approve"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { WorkflowEngine } from '@/lib/workflow-engine';
import { prisma } from '@/lib/prisma';

export async function POST(req: NextRequest) {
  try {
    const { instanceId, action, actorId, comment } = await req.json();
    if (!instanceId || !action || !actorId) return NextResponse.json({ error: 'instanceId, action, actorId required' }, { status: 400 });
    if (!['approve', 'reject', 'return'].includes(action)) return NextResponse.json({ error: 'Invalid action' }, { status: 400 });

    const result = await WorkflowEngine.transition(instanceId, action, actorId, comment);
    return NextResponse.json(result);
  } catch (error: any) {
    return NextResponse.json({ error: error.message || 'Approval failed' }, { status: 500 });
  }
}

export async function GET(req: NextRequest) {
  try {
    const actorId = req.nextUrl.searchParams.get('actorId');
    // Get pending approvals for this user
    const pending = await prisma.workflowInstance.findMany({
      where: { status: 'RUNNING' },
      include: { workflow: { select: { name: true, states: true } }, history: { orderBy: { createdAt: 'desc' }, take: 1 } },
    });

    // Filter to instances where current state is approval type
    const approvals = pending.filter(inst => {
      const states = inst.workflow.states as any[];
      const current = states.find((s: any) => s.id === inst.currentState);
      return current?.type === 'approval';
    });

    return NextResponse.json({ data: approvals, count: approvals.length });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch approvals' }, { status: 500 });
  }
}
EOF

    WEG_GENERATED_COUNT=$((WEG_GENERATED_COUNT + 1))
    _weg_ok "承認フロー生成完了"
    return 0
}

_weg_generate_triggers() {
    local project_dir="${1:-.}"
    _weg_log "ワークフロートリガー生成"
    local api_dir="${project_dir}/src/app/api/workflows/triggers"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { WorkflowEngine } from '@/lib/workflow-engine';

export async function POST(req: NextRequest) {
  try {
    const { event, data } = await req.json();
    if (!event) return NextResponse.json({ error: 'event required' }, { status: 400 });

    // Find triggers matching this event
    const triggers = await prisma.workflowTrigger.findMany({
      where: { type: 'EVENT', isActive: true },
      include: { workflow: true },
    });

    const matchingTriggers = triggers.filter(t => {
      const config = t.config as any;
      return config?.event === event;
    });

    const instances = [];
    for (const trigger of matchingTriggers) {
      if (!trigger.workflow.isActive) continue;
      const instance = await WorkflowEngine.startWorkflow(trigger.workflowId, data);
      instances.push(instance);
    }

    return NextResponse.json({ triggered: instances.length, instances });
  } catch (error) {
    return NextResponse.json({ error: 'Trigger execution failed' }, { status: 500 });
  }
}

// Cron endpoint for scheduled triggers
export async function GET() {
  try {
    const scheduledTriggers = await prisma.workflowTrigger.findMany({
      where: { type: 'SCHEDULE', isActive: true },
      include: { workflow: true },
    });

    let triggered = 0;
    for (const trigger of scheduledTriggers) {
      if (!trigger.workflow.isActive) continue;
      // TODO: Check cron schedule match
      const config = trigger.config as any;
      // Simple check - in production use a proper cron parser
      try {
        await WorkflowEngine.startWorkflow(trigger.workflowId, { trigger: 'schedule', schedule: config?.schedule });
        triggered++;
      } catch { /* skip failed */ }
    }

    return NextResponse.json({ checked: scheduledTriggers.length, triggered });
  } catch (error) {
    return NextResponse.json({ error: 'Schedule check failed' }, { status: 500 });
  }
}
EOF

    WEG_GENERATED_COUNT=$((WEG_GENERATED_COUNT + 1))
    _weg_ok "トリガー生成完了"
    return 0
}

_mr_register \
    --name "workflow-engine-generator" \
    --version "313.0" \
    --description "ワークフローエンジン自動生成（ステートマシン/承認フロー/トリガー）" \
    --init "weg_init" \
    --report "weg_report" \
    --score "weg_score" \
    --enable-var "ENABLE_WORKFLOW_ENGINE_GENERATOR" \
    --cli-flags "--workflow-engine:--no-workflow-engine" \
    --init-msg "weg_init_message"
