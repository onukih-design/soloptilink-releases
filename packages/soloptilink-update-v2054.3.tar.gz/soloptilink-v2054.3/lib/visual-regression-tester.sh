#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v339.0 - Visual Regression Tester
# =============================================================================
# スクリーンショット比較テスト、ビジュアル差分検出、レポート生成。
# Playwright screenshots、pixelmatch、レスポンシブ対応。
#
# Functions:
#   _vrt_init()                      - Initialize
#   _vrt_generate_screenshot_tests() - Generate screenshot comparison tests
#   _vrt_compare_screenshots()       - Compare baseline vs current
#   _vrt_generate_report()           - Generate visual diff report
#   _vrt_report() / _vrt_score()
# =============================================================================

[[ -n "${_VRT_LOADED:-}" ]] && return 0; _VRT_LOADED=1

readonly _VRT_RED='\033[0;31m'
readonly _VRT_GREEN='\033[0;32m'
readonly _VRT_YELLOW='\033[0;33m'
readonly _VRT_CYAN='\033[0;36m'
readonly _VRT_NC='\033[0m'

declare -g VRT_VERSION="339.0"
VRT_GENERATED=0; VRT_ERRORS=0; VRT_FILES_WRITTEN=0
VRT_SCREENSHOT_OK=false; VRT_COMPARE_OK=false; VRT_REPORT_OK=false
VRT_PAGES_FOUND=0; VRT_DIFFS_FOUND=0

_vrt_init() {
    VRT_GENERATED=0; VRT_ERRORS=0; VRT_FILES_WRITTEN=0
    VRT_SCREENSHOT_OK=false; VRT_COMPARE_OK=false; VRT_REPORT_OK=false
    VRT_PAGES_FOUND=0; VRT_DIFFS_FOUND=0
    echo -e "  ${_VRT_GREEN}OK${_VRT_NC} Visual Regression Tester v${VRT_VERSION}" >&2
    return 0
}

_vrt_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { VRT_FILES_WRITTEN=$((VRT_FILES_WRITTEN + 1)); return 0; }
    VRT_ERRORS=$((VRT_ERRORS + 1)); return 1
}

_vrt_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_VRT_CYAN}[vrt]${_VRT_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_VRT_GREEN}[vrt]${_VRT_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_VRT_YELLOW}[vrt]${_VRT_NC} $msg" >&2 ;;
        error) echo -e "  ${_VRT_RED}[vrt]${_VRT_NC} $msg" >&2 ;;
    esac
}

_vrt_generate_screenshot_tests() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _vrt_log info "Generating visual regression tests..."

    # Discover pages
    local pages
    pages=$(find "$project_dir" -path "*/app/*/page.tsx" -not -path "*/node_modules/*" -not -path "*api*" 2>/dev/null)
    VRT_PAGES_FOUND=$(echo "$pages" | grep -c . 2>/dev/null || echo 0)

    _vrt_write_file "${project_dir}/e2e/visual.spec.ts" "$(cat <<'TYPESCRIPT'
import { test, expect } from '@playwright/test';

const viewports = [
  { name: 'desktop', width: 1280, height: 800 },
  { name: 'tablet', width: 768, height: 1024 },
  { name: 'mobile', width: 375, height: 812 },
];

const pages = [
  { name: 'login', path: '/login' },
  { name: 'dashboard', path: '/', auth: true },
  { name: 'settings', path: '/settings', auth: true },
];

for (const vp of viewports) {
  test.describe(`Visual - ${vp.name}`, () => {
    test.use({ viewport: { width: vp.width, height: vp.height } });

    for (const pg of pages) {
      test(`${pg.name} page matches snapshot`, async ({ page }) => {
        if (pg.auth) {
          await page.goto('/login');
          await page.getByLabel('Email').fill('admin@example.com');
          await page.getByLabel('Password').fill('password123');
          await page.getByRole('button', { name: /login/i }).click();
          await page.waitForURL(/dashboard|home/);
        }
        await page.goto(pg.path);
        await page.waitForLoadState('networkidle');
        await expect(page).toHaveScreenshot(`${pg.name}-${vp.name}.png`, {
          maxDiffPixelRatio: 0.01,
          animations: 'disabled',
        });
      });
    }
  });
}
TYPESCRIPT
)"

    _vrt_log ok "Screenshot tests generated for ${VRT_PAGES_FOUND} pages x 3 viewports"
    VRT_SCREENSHOT_OK=true
    VRT_GENERATED=$((VRT_GENERATED + 1))
    return 0
}

_vrt_compare_screenshots() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _vrt_log info "Checking for visual diffs..."

    local diff_dir="${project_dir}/e2e/screenshots"
    if [[ -d "$diff_dir" ]]; then
        VRT_DIFFS_FOUND=$(find "$diff_dir" -name "*-diff.*" 2>/dev/null | wc -l | tr -d ' ')
        if [[ $VRT_DIFFS_FOUND -gt 0 ]]; then
            _vrt_log warn "Found ${VRT_DIFFS_FOUND} visual diffs"
        else
            _vrt_log ok "No visual regressions detected"
        fi
    else
        _vrt_log info "No baseline screenshots yet (run tests first)"
    fi

    VRT_COMPARE_OK=true
    VRT_GENERATED=$((VRT_GENERATED + 1))
    return 0
}

_vrt_generate_report() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _vrt_log info "Generating visual regression report..."

    _vrt_write_file "${project_dir}/e2e/vrt-report.json" "{
  \"pages_tested\": ${VRT_PAGES_FOUND},
  \"viewports\": [\"desktop\", \"tablet\", \"mobile\"],
  \"diffs_found\": ${VRT_DIFFS_FOUND},
  \"threshold\": 0.01,
  \"generated_at\": \"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"
}"

    _vrt_log ok "VRT report generated"
    VRT_REPORT_OK=true
    VRT_GENERATED=$((VRT_GENERATED + 1))
    return 0
}

_vrt_report() {
    echo -e "\n  ${_VRT_CYAN}=== Visual Regression Tester v${VRT_VERSION} ===${_VRT_NC}"
    echo -e "  Generated: ${VRT_GENERATED} | Files: ${VRT_FILES_WRITTEN} | Errors: ${VRT_ERRORS}"
    echo -e "  Pages: ${VRT_PAGES_FOUND} | Diffs: ${VRT_DIFFS_FOUND}"
    echo -e "  Screenshots: $( ${VRT_SCREENSHOT_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Compare: $( ${VRT_COMPARE_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Report: $( ${VRT_REPORT_OK} && echo 'OK' || echo 'SKIP')"
}

_vrt_score() {
    local score=50
    ${VRT_SCREENSHOT_OK} && score=$((score + 20))
    ${VRT_COMPARE_OK} && score=$((score + 15))
    ${VRT_REPORT_OK} && score=$((score + 10))
    [[ ${VRT_DIFFS_FOUND} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "visual-regression-tester" --version "339.0" \
        --description "ビジュアル回帰テスト スクリーンショット比較/レスポンシブ (v339)" \
        --init "_vrt_init" --report "_vrt_report" --score "_vrt_score" \
        --enable-var "ENABLE_VRT" --cli-flags "--vrt:--no-vrt"
fi

# v2003.1: source時のexit codeを確実に0にする
true
