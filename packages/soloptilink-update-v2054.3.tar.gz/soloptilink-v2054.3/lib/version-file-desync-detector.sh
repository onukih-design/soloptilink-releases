#!/usr/bin/env bash
# SoloptiLinkAI v2034.0 - Version File Desync Detector (VFD)
# 学習データ証拠 (2026-05-12 Daily Upgrade) に基づく:
#   - ~/.soloptilink/VERSION = "2033.0"
#   - chain.sh "readonly VERSION=" = "2033.0"
#   - DUE_VERSION (lib/daily-upgrade-engine.sh) = "2033.3"
#   - TAR sessions.jsonl 直近5件 = "2033.1" .. "2033.3"
#   - 4経路で「現在のバージョン」が食い違い、telemetry/SAP/DUE の整合判定が崩壊
#
# VFD は 4経路を読み込み coherent / desync を判定し、
# desync の場合は「どのファイルを真として揃えるか」のヒントを返す。
#
# 設計方針:
#   - 読み取り専用 (destructive 操作は一切しない)
#   - DUE/SAP/TAR から呼び出されレポートに inline 埋込
#   - 真値は「TAR sessions.jsonl の最新 session_end version」
#     → 「実際に走った最新 BOOST」が真実だから

[[ -n "${_VFD_LOADED:-}" ]] && return 0
_VFD_LOADED=1

VFD_VERSION="2034.2"
VFD_HOME="${SOLOPTILINK_HOME:-$HOME/.soloptilink}"
VFD_VERSION_FILE="${VFD_HOME}/VERSION"
VFD_CHAIN_SH="${VFD_HOME}/chain.sh"
VFD_DUE_SH="${VFD_HOME}/lib/daily-upgrade-engine.sh"
VFD_SESSIONS="${VFD_HOME}/learning/sessions.jsonl"

# ------------------------------------------------------------
# 各経路から「現在の version」を取得
# ------------------------------------------------------------
vfd_version_from_file() {
    [[ -f "$VFD_VERSION_FILE" ]] || { echo "missing"; return; }
    local v
    v=$(tr -d '[:space:]' < "$VFD_VERSION_FILE" 2>/dev/null)
    echo "${v:-empty}"
}

vfd_version_from_chain() {
    [[ -f "$VFD_CHAIN_SH" ]] || { echo "missing"; return; }
    local v
    v=$(grep -E '^readonly VERSION=' "$VFD_CHAIN_SH" 2>/dev/null \
        | head -1 | sed -E 's/.*"([^"]+)".*/\1/')
    echo "${v:-empty}"
}

vfd_version_from_due() {
    [[ -f "$VFD_DUE_SH" ]] || { echo "missing"; return; }
    local v
    v=$(grep -E '^DUE_VERSION=' "$VFD_DUE_SH" 2>/dev/null \
        | head -1 | sed -E 's/.*"([^"]+)".*/\1/')
    echo "${v:-empty}"
}

vfd_version_from_tar_latest() {
    [[ -f "$VFD_SESSIONS" ]] || { echo "missing"; return; }
    local v
    v=$(grep '"event":"session_end"' "$VFD_SESSIONS" 2>/dev/null \
        | tail -1 \
        | grep -oE '"version":"[^"]+"' \
        | head -1 \
        | sed 's/.*"\([^"]*\)"$/\1/')
    echo "${v:-none}"
}

# ------------------------------------------------------------
# verdict: COHERENT / DESYNC
# 真値 = TAR latest (実際に走った最新 BOOST)
# ------------------------------------------------------------
vfd_verdict() {
    local v_file v_chain v_due v_tar
    v_file=$(vfd_version_from_file)
    v_chain=$(vfd_version_from_chain)
    v_due=$(vfd_version_from_due)
    v_tar=$(vfd_version_from_tar_latest)

    if [[ "$v_file" == "$v_chain" && "$v_chain" == "$v_due" && "$v_due" == "$v_tar" ]]; then
        echo "COHERENT"
    else
        echo "DESYNC"
    fi
}

# ------------------------------------------------------------
# サマリ生成 (DUE から呼ばれる)
# ------------------------------------------------------------
vfd_summary() {
    local v_file v_chain v_due v_tar verdict
    v_file=$(vfd_version_from_file)
    v_chain=$(vfd_version_from_chain)
    v_due=$(vfd_version_from_due)
    v_tar=$(vfd_version_from_tar_latest)
    verdict=$(vfd_verdict)

    echo "- VFD verdict: ${verdict}"
    echo "- VERSION file:        ${v_file}"
    echo "- chain.sh VERSION:    ${v_chain}"
    echo "- DUE_VERSION:         ${v_due}"
    echo "- TAR latest session:  ${v_tar}"
    if [[ "$verdict" == "DESYNC" ]]; then
        # 真値 = TAR (実走した最新)
        echo "- recommended_truth: ${v_tar} (実走最新 = 真値)"
        # 揃えるべきファイル列挙
        local fix_targets=()
        [[ "$v_file" != "$v_tar" ]] && fix_targets+=("VERSION file → ${v_tar}")
        [[ "$v_chain" != "$v_tar" ]] && fix_targets+=("chain.sh VERSION → ${v_tar}")
        [[ "$v_due" != "$v_tar" ]] && fix_targets+=("DUE_VERSION → ${v_tar}")
        if (( ${#fix_targets[@]} > 0 )); then
            echo "- fix_targets:"
            local t
            for t in "${fix_targets[@]}"; do
                echo "    - ${t}"
            done
        fi
    fi
}

# CLI 直接実行
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-summary}" in
        verdict) vfd_verdict ;;
        summary) vfd_summary ;;
        version) echo "$VFD_VERSION" ;;
        file)    vfd_version_from_file ;;
        chain)   vfd_version_from_chain ;;
        due)     vfd_version_from_due ;;
        tar)     vfd_version_from_tar_latest ;;
        *) echo "usage: $0 {verdict|summary|version|file|chain|due|tar}" >&2; exit 2 ;;
    esac
fi
