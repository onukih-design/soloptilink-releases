#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v491.0 - Emergent Behavior Detection Engine
# =============================================================================
# システム全体の振る舞いを監視し、予期せぬ創発的挙動を検出・分類する。
# 正常/異常の境界を学習し、有益な創発は促進、有害な創発は抑制する。
#
# Functions:
#   _ebd_init               - 初期化
#   _ebd_monitor_system     - システム監視
#   _ebd_detect_anomalies   - 異常検出
#   _ebd_classify_behavior  - 挙動分類
#   _ebd_report             - レポート出力
#   _ebd_score              - モジュールスコア(0-100)
#
# Globals: EBD_ prefix
# =============================================================================

[[ -n "${_EMERGENT_BEHAVIOR_DETECTION_LOADED:-}" ]] && return 0
_EMERGENT_BEHAVIOR_DETECTION_LOADED=1

EBD_VERSION="491.0"
EBD_INITIALIZED=false

EBD_DATA_DIR=""
EBD_MONITOR_LOG=""
EBD_ANOMALY_LOG=""

EBD_TOTAL_OBSERVATIONS=0
EBD_ANOMALIES_DETECTED=0
EBD_BENEFICIAL_EMERGENT=0
EBD_HARMFUL_EMERGENT=0

declare -g -A _EBD_BASELINES=()
declare -g -A _EBD_CURRENT_METRICS=()
declare -g -a _EBD_ANOMALIES=()
declare -g -A _EBD_BEHAVIOR_CLASS=()

_ebd_init() {
    local project_dir="${PROJECT_DIR:-.}"
    EBD_DATA_DIR="${project_dir}/.soloptilink/ebd"
    EBD_MONITOR_LOG="${EBD_DATA_DIR}/monitor.jsonl"
    EBD_ANOMALY_LOG="${EBD_DATA_DIR}/anomalies.jsonl"
    mkdir -p "$EBD_DATA_DIR"

    # ベースライン設定
    _EBD_BASELINES["build_time"]=60
    _EBD_BASELINES["error_count"]=5
    _EBD_BASELINES["quality_score"]=70
    _EBD_BASELINES["token_usage"]=50000
    _EBD_BASELINES["fix_iterations"]=5
    _EBD_BASELINES["file_count"]=30
    _EBD_BASELINES["test_pass_rate"]=80

    EBD_INITIALIZED=true
    return 0
}

_ebd_monitor_system() {
    local metric="$1"
    local value="$2"

    [[ "$EBD_INITIALIZED" != "true" ]] && _ebd_init

    _EBD_CURRENT_METRICS["$metric"]=$value
    EBD_TOTAL_OBSERVATIONS=$((EBD_TOTAL_OBSERVATIONS + 1))

    local timestamp
    timestamp=$(date +%s)
    echo "{\"ts\":${timestamp},\"metric\":\"${metric}\",\"value\":${value}}" >> "$EBD_MONITOR_LOG" 2>/dev/null

    # リアルタイム異常チェック
    local baseline="${_EBD_BASELINES[$metric]:-}"
    if [[ -n "$baseline" && $baseline -gt 0 ]]; then
        local deviation=$(( (value - baseline) * 100 / baseline ))
        [[ $deviation -lt 0 ]] && deviation=$((-deviation))

        if [[ $deviation -gt 100 ]]; then
            _ebd_detect_anomalies "$metric" "$value" "$baseline" "$deviation"
        fi
    fi

    return 0
}

_ebd_detect_anomalies() {
    local metric="$1"
    local value="$2"
    local baseline="${3:-}"
    local deviation="${4:-}"

    [[ "$EBD_INITIALIZED" != "true" ]] && _ebd_init

    if [[ -z "$baseline" ]]; then
        baseline="${_EBD_BASELINES[$metric]:-50}"
    fi
    if [[ -z "$deviation" && $baseline -gt 0 ]]; then
        deviation=$(( (value - baseline) * 100 / baseline ))
        [[ $deviation -lt 0 ]] && deviation=$((-deviation))
    fi

    local anomaly_type="unknown"
    if [[ $value -gt $baseline ]]; then
        case "$metric" in
            quality_score|test_pass_rate)
                anomaly_type="beneficial"
                EBD_BENEFICIAL_EMERGENT=$((EBD_BENEFICIAL_EMERGENT + 1))
                ;;
            build_time|error_count|token_usage|fix_iterations)
                anomaly_type="harmful"
                EBD_HARMFUL_EMERGENT=$((EBD_HARMFUL_EMERGENT + 1))
                ;;
        esac
    else
        case "$metric" in
            build_time|error_count|token_usage|fix_iterations)
                anomaly_type="beneficial"
                EBD_BENEFICIAL_EMERGENT=$((EBD_BENEFICIAL_EMERGENT + 1))
                ;;
            quality_score|test_pass_rate)
                anomaly_type="harmful"
                EBD_HARMFUL_EMERGENT=$((EBD_HARMFUL_EMERGENT + 1))
                ;;
        esac
    fi

    _EBD_ANOMALIES+=("${metric}:${anomaly_type}:deviation=${deviation}%")
    _EBD_BEHAVIOR_CLASS["${metric}::$(date +%s)"]="$anomaly_type"
    EBD_ANOMALIES_DETECTED=$((EBD_ANOMALIES_DETECTED + 1))

    local timestamp
    timestamp=$(date +%s)
    echo "{\"ts\":${timestamp},\"metric\":\"${metric}\",\"value\":${value},\"baseline\":${baseline},\"deviation\":${deviation},\"type\":\"${anomaly_type}\"}" >> "$EBD_ANOMALY_LOG" 2>/dev/null

    echo "  [EBD] Anomaly: ${metric} = ${value} (baseline=${baseline}, deviation=${deviation}%, type=${anomaly_type})" >&2
    return 0
}

_ebd_classify_behavior() {
    [[ "$EBD_INITIALIZED" != "true" ]] && _ebd_init

    echo "=== Emergent Behavior Classification ==="
    echo "Beneficial: ${EBD_BENEFICIAL_EMERGENT}"
    echo "Harmful:    ${EBD_HARMFUL_EMERGENT}"
    echo "Total:      ${EBD_ANOMALIES_DETECTED}"

    if [[ $EBD_BENEFICIAL_EMERGENT -gt $EBD_HARMFUL_EMERGENT ]]; then
        echo "Assessment: System is self-improving (net positive emergence)"
    elif [[ $EBD_HARMFUL_EMERGENT -gt $EBD_BENEFICIAL_EMERGENT ]]; then
        echo "Assessment: System is degrading (net negative emergence)"
    else
        echo "Assessment: System is stable (balanced emergence)"
    fi
}

_ebd_report() {
    echo -e "\n  ${BOLD:-}═══ Emergent Behavior Detection v${EBD_VERSION} ═══${NC:-}"
    echo -e "  観測数             : ${EBD_TOTAL_OBSERVATIONS}"
    echo -e "  異常検出数         : ${EBD_ANOMALIES_DETECTED}"
    echo -e "  有益な創発         : ${EBD_BENEFICIAL_EMERGENT}"
    echo -e "  有害な創発         : ${EBD_HARMFUL_EMERGENT}"
}

_ebd_score() {
    [[ "$EBD_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    local s=60
    [[ $EBD_TOTAL_OBSERVATIONS -gt 5 ]] && s=$((s + 10))
    [[ $EBD_BENEFICIAL_EMERGENT -gt $EBD_HARMFUL_EMERGENT ]] && s=$((s + 20))
    [[ $EBD_ANOMALIES_DETECTED -gt 0 ]] && s=$((s + 10))
    [[ $s -gt 100 ]] && s=100
    echo "$s"
}

_ebd_init_message() {
    echo -e "  ${GREEN:-}✅ v${EBD_VERSION} emergent-behavior-detection: 創発行動検出エンジン${NC:-}" >&2
}

_mr_register \
    --name "emergent-behavior-detection" \
    --version "$EBD_VERSION" \
    --description "創発行動検出エンジン" \
    --init "_ebd_init" \
    --report "_ebd_report" \
    --score "_ebd_score" \
    --enable-var "ENABLE_EMERGENT_BEHAVIOR_DETECTION" \
    --cli-flags "--emergent-behavior:--no-emergent-behavior" \
    --init-msg "_ebd_init_message"
