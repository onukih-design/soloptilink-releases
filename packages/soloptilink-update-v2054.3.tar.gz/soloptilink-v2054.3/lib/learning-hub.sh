#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v28.0 - Learning Hub (学習データハブ)
# =============================================================================
# セッションを超えてAIの開発精度を向上させる統合学習システム。
# 全Claude呼び出しの入出力・エラー・修正結果・品質スコアを蓄積し、
# 次回以降のプロンプト生成に最適パターンを自動注入する。
#
# 5つのサブシステム:
#   1. Call Capture     - Claude呼び出し全記録（プロンプト/レスポンス/トークン/エラー）
#   2. Solution Index   - エラーパターン→解決策→成功率のマッピング
#   3. Phase Metrics    - フェーズ別実行時間・コスト・品質スコアの時系列記録
#   4. Prompt Tracker   - プロンプト効果分析・最適テンプレート自動選択
#   5. Session Intel    - 過去セッション学習データのコンテキスト自動注入
#
# Storage: ~/.soloptilink/learning/
# =============================================================================

[[ -n "${_LEARNING_HUB_LOADED:-}" ]] && return 0
_LEARNING_HUB_LOADED=1

# ============================================================
# Configuration
# ============================================================
declare -g LH_ENABLED="true"
declare -g LH_BASE_DIR="${HOME}/.soloptilink/learning"
declare -g LH_CALLS_DIR=""
declare -g LH_SOLUTIONS_DIR=""
declare -g LH_METRICS_DIR=""
declare -g LH_PROMPTS_DIR=""
declare -g LH_INTEL_DIR=""
declare -g LH_SESSION_ID=""
declare -g LH_DOMAIN=""
declare -g LH_CALL_SEQ=0

# 保持上限
readonly LH_MAX_CALL_LOGS=2000
readonly LH_MAX_SOLUTIONS=500
readonly LH_MAX_METRICS_DAYS=90
readonly LH_MAX_PROMPT_TEMPLATES=200

# ============================================================
# Logger
# ============================================================
_lh_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-\033[0;36m}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-\033[0;33m}"
    [[ "$level" == "ERROR" ]] && color="${RED:-\033[0;31m}"
    [[ "$level" == "OK" ]] && color="${GREEN:-\033[0;32m}"
    [[ "$level" == "LEARN" ]] && color="${PURPLE:-\033[0;35m}"
    echo -e "  ${color}[LEARN]${NC:-\033[0m} ${msg}" >&2
}

# ============================================================
# Initialize
# ============================================================
lh_init() {
    local session_id="${1:-${SESSION_ID:-unknown}}"
    local domain="${2:-general}"

    LH_SESSION_ID="$session_id"
    LH_DOMAIN="$domain"
    LH_CALL_SEQ=0

    LH_CALLS_DIR="${LH_BASE_DIR}/calls"
    LH_SOLUTIONS_DIR="${LH_BASE_DIR}/solutions"
    LH_METRICS_DIR="${LH_BASE_DIR}/metrics"
    LH_PROMPTS_DIR="${LH_BASE_DIR}/prompts"
    LH_INTEL_DIR="${LH_BASE_DIR}/intelligence"

    mkdir -p "$LH_CALLS_DIR" "$LH_SOLUTIONS_DIR" "$LH_METRICS_DIR" \
             "$LH_PROMPTS_DIR" "$LH_INTEL_DIR" \
             "${LH_SOLUTIONS_DIR}/by-error" \
             "${LH_SOLUTIONS_DIR}/by-domain" \
             "${LH_METRICS_DIR}/phases" \
             "${LH_METRICS_DIR}/sessions" \
             "${LH_PROMPTS_DIR}/templates" \
             "${LH_PROMPTS_DIR}/scores" \
             "${LH_INTEL_DIR}/summaries" 2>/dev/null

    _lh_log "OK" "Learning Hub 初期化完了 (session=${session_id}, domain=${domain})"
}

# ============================================================
# [1] Call Capture - Claude呼び出し全記録
# ============================================================

# Claude呼び出しの完全な記録を保存
# 引数: phase, prompt_chars, response_chars, success(0/1), model_tier,
#        input_tokens, output_tokens, error_msg, duration_ms
lh_record_call() {
    [[ "$LH_ENABLED" != "true" ]] && return 0

    local phase="${1:-unknown}"
    local prompt_chars="${2:-0}"
    local response_chars="${3:-0}"
    local success="${4:-1}"
    local model_tier="${5:-balanced}"
    local input_tokens="${6:-0}"
    local output_tokens="${7:-0}"
    local error_msg="${8:-}"
    local duration_ms="${9:-0}"

    LH_CALL_SEQ=$((LH_CALL_SEQ + 1))
    local ts
    ts=$(date '+%Y-%m-%dT%H:%M:%S')
    local date_key
    date_key=$(date '+%Y%m%d')

    # 日別のJSONLファイルに追記
    local call_file="${LH_CALLS_DIR}/${date_key}.jsonl"

    python3 -c "
import json, sys
entry = {
    'session_id': sys.argv[1],
    'seq': int(sys.argv[2]),
    'phase': sys.argv[3],
    'domain': sys.argv[4],
    'prompt_chars': int(sys.argv[5]),
    'response_chars': int(sys.argv[6]),
    'success': sys.argv[7] == '1',
    'model_tier': sys.argv[8],
    'input_tokens': int(sys.argv[9]),
    'output_tokens': int(sys.argv[10]),
    'error_msg': sys.argv[11] if sys.argv[11] else None,
    'duration_ms': int(sys.argv[12]),
    'timestamp': sys.argv[13]
}
with open(sys.argv[14], 'a') as f:
    f.write(json.dumps(entry, ensure_ascii=False) + '\n')
" "$LH_SESSION_ID" "$LH_CALL_SEQ" "$phase" "$LH_DOMAIN" \
  "$prompt_chars" "$response_chars" "$success" "$model_tier" \
  "$input_tokens" "$output_tokens" "$error_msg" "$duration_ms" \
  "$ts" "$call_file" 2>/dev/null || true
}

# プロンプトのハッシュと要約を保存（全文は大きすぎるので要約）
lh_record_prompt_snapshot() {
    [[ "$LH_ENABLED" != "true" ]] && return 0

    local phase="${1:-unknown}"
    local prompt="$2"
    local quality_score="${3:-0}"

    # プロンプトのMD5ハッシュを取得
    local prompt_hash
    prompt_hash=$(printf '%s' "$prompt" | md5 2>/dev/null || printf '%s' "$prompt" | md5sum 2>/dev/null | cut -d' ' -f1 || echo "unknown")

    # 先頭500文字 + 末尾200文字を要約として保存
    local prompt_head="${prompt:0:500}"
    local prompt_len=${#prompt}
    local prompt_tail=""
    if [[ $prompt_len -gt 700 ]]; then
        prompt_tail="${prompt: -200}"
    fi

    local score_file="${LH_PROMPTS_DIR}/scores/${LH_DOMAIN}_${phase}.jsonl"

    python3 -c "
import json, sys
entry = {
    'hash': sys.argv[1],
    'phase': sys.argv[2],
    'domain': sys.argv[3],
    'prompt_chars': int(sys.argv[4]),
    'quality_score': float(sys.argv[5]),
    'session_id': sys.argv[6],
    'head': sys.argv[7],
    'tail': sys.argv[8],
    'timestamp': sys.argv[9]
}
with open(sys.argv[10], 'a') as f:
    f.write(json.dumps(entry, ensure_ascii=False) + '\n')
" "$prompt_hash" "$phase" "$LH_DOMAIN" "$prompt_len" "$quality_score" \
  "$LH_SESSION_ID" "$prompt_head" "$prompt_tail" \
  "$(date '+%Y-%m-%dT%H:%M:%S')" "$score_file" 2>/dev/null || true
}

# ============================================================
# [2] Solution Index - エラー→解決策マッピング
# ============================================================

# エラーパターンと解決策を記録
# 引数: error_type, error_msg, solution_desc, phase, success(0/1)
lh_record_solution() {
    [[ "$LH_ENABLED" != "true" ]] && return 0

    local error_type="${1:-unknown}"
    local error_msg="${2:-}"
    local solution_desc="${3:-}"
    local phase="${4:-unknown}"
    local success="${5:-1}"

    # エラータイプ別のファイルに追記
    local safe_type
    safe_type=$(echo "$error_type" | tr '[:upper:]/ ' '[:lower:]__' | tr -cd 'a-z0-9_-')
    local solution_file="${LH_SOLUTIONS_DIR}/by-error/${safe_type}.jsonl"

    python3 -c "
import json, sys
entry = {
    'error_type': sys.argv[1],
    'error_msg': sys.argv[2][:500],
    'solution': sys.argv[3][:1000],
    'phase': sys.argv[4],
    'domain': sys.argv[5],
    'success': sys.argv[6] == '1',
    'session_id': sys.argv[7],
    'timestamp': sys.argv[8]
}
with open(sys.argv[9], 'a') as f:
    f.write(json.dumps(entry, ensure_ascii=False) + '\n')
" "$error_type" "$error_msg" "$solution_desc" "$phase" "$LH_DOMAIN" \
  "$success" "$LH_SESSION_ID" "$(date '+%Y-%m-%dT%H:%M:%S')" \
  "$solution_file" 2>/dev/null || true
}

# 特定のエラータイプに対する過去の解決策を検索
# 返り値: 成功率順にソートされた解決策リスト
lh_search_solutions() {
    local error_type="${1:-}"
    local max_results="${2:-5}"

    local safe_type
    safe_type=$(echo "$error_type" | tr '[:upper:]/ ' '[:lower:]__' | tr -cd 'a-z0-9_-')
    local solution_file="${LH_SOLUTIONS_DIR}/by-error/${safe_type}.jsonl"

    [[ ! -f "$solution_file" ]] && return 0

    python3 -c "
import json, sys
from collections import defaultdict

solutions = defaultdict(lambda: {'total': 0, 'success': 0, 'solution': '', 'last_used': ''})

with open(sys.argv[1], 'r') as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
            key = entry.get('solution', '')[:200]
            solutions[key]['total'] += 1
            if entry.get('success', False):
                solutions[key]['success'] += 1
            solutions[key]['solution'] = entry.get('solution', '')
            solutions[key]['last_used'] = entry.get('timestamp', '')
        except:
            continue

# 成功率でソート
ranked = sorted(
    solutions.values(),
    key=lambda x: (x['success'] / max(x['total'], 1), x['total']),
    reverse=True
)[:int(sys.argv[2])]

for item in ranked:
    rate = item['success'] / max(item['total'], 1) * 100
    print(f'[{rate:.0f}% ({item[\"success\"]}/{item[\"total\"]})] {item[\"solution\"][:200]}')
" "$solution_file" "$max_results" 2>/dev/null
}

# 全エラータイプ横断検索（キーワードベース）
lh_search_solutions_keyword() {
    local keyword="${1:-}"
    local max_results="${2:-5}"

    [[ -z "$keyword" ]] && return 0

    python3 -c "
import json, sys, os, glob

keyword = sys.argv[1].lower()
max_results = int(sys.argv[2])
solutions_dir = sys.argv[3]
results = []

for filepath in glob.glob(os.path.join(solutions_dir, 'by-error', '*.jsonl')):
    with open(filepath, 'r') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
                text = json.dumps(entry, ensure_ascii=False).lower()
                if keyword in text:
                    results.append(entry)
            except:
                continue

# 成功のものを優先
results.sort(key=lambda x: (x.get('success', False), x.get('timestamp', '')), reverse=True)
for entry in results[:max_results]:
    status = 'OK' if entry.get('success') else 'NG'
    print(f'[{status}] [{entry.get(\"phase\",\"?\")}] {entry.get(\"error_type\",\"?\")} → {entry.get(\"solution\",\"?\")[:200]}')
" "$keyword" "$max_results" "$LH_SOLUTIONS_DIR" 2>/dev/null
}

# ============================================================
# [3] Phase Metrics - フェーズ別実行メトリクス時系列記録
# ============================================================

# フェーズの実行結果を記録
lh_record_phase_metrics() {
    [[ "$LH_ENABLED" != "true" ]] && return 0

    local phase="${1:-unknown}"
    local duration_sec="${2:-0}"
    local quality_score="${3:-0}"
    local error_count="${4:-0}"
    local claude_calls="${5:-0}"
    local estimated_cost="${6:-0.00}"

    local metrics_file="${LH_METRICS_DIR}/phases/${phase}.jsonl"

    python3 -c "
import json, sys
entry = {
    'session_id': sys.argv[1],
    'phase': sys.argv[2],
    'domain': sys.argv[3],
    'duration_sec': float(sys.argv[4]),
    'quality_score': float(sys.argv[5]),
    'error_count': int(sys.argv[6]),
    'claude_calls': int(sys.argv[7]),
    'estimated_cost': float(sys.argv[8]),
    'timestamp': sys.argv[9]
}
with open(sys.argv[10], 'a') as f:
    f.write(json.dumps(entry, ensure_ascii=False) + '\n')
" "$LH_SESSION_ID" "$phase" "$LH_DOMAIN" \
  "$duration_sec" "$quality_score" "$error_count" \
  "$claude_calls" "$estimated_cost" \
  "$(date '+%Y-%m-%dT%H:%M:%S')" "$metrics_file" 2>/dev/null || true
}

# セッション全体のサマリを記録
lh_record_session_summary() {
    [[ "$LH_ENABLED" != "true" ]] && return 0

    local task_desc="${1:-}"
    local total_duration="${2:-0}"
    local total_calls="${3:-0}"
    local total_cost="${4:-0.00}"
    local final_quality="${5:-0}"
    local exit_code="${6:-0}"
    local phases_completed="${7:-0}"

    local summary_file="${LH_METRICS_DIR}/sessions/sessions.jsonl"

    python3 -c "
import json, sys
entry = {
    'session_id': sys.argv[1],
    'task': sys.argv[2][:500],
    'domain': sys.argv[3],
    'total_duration_sec': float(sys.argv[4]),
    'total_claude_calls': int(sys.argv[5]),
    'total_cost_usd': float(sys.argv[6]),
    'final_quality_score': float(sys.argv[7]),
    'exit_code': int(sys.argv[8]),
    'phases_completed': int(sys.argv[9]),
    'success': int(sys.argv[8]) == 0,
    'timestamp': sys.argv[10]
}
with open(sys.argv[11], 'a') as f:
    f.write(json.dumps(entry, ensure_ascii=False) + '\n')
" "$LH_SESSION_ID" "$task_desc" "$LH_DOMAIN" \
  "$total_duration" "$total_calls" "$total_cost" \
  "$final_quality" "$exit_code" "$phases_completed" \
  "$(date '+%Y-%m-%dT%H:%M:%S')" "$summary_file" 2>/dev/null || true
}

# ============================================================
# [4] Prompt Effectiveness Tracker - プロンプト効果分析
# ============================================================

# ドメイン×フェーズの最高品質プロンプトテンプレートを取得
lh_get_best_prompt_pattern() {
    local phase="${1:-unknown}"
    local domain="${2:-${LH_DOMAIN:-general}}"

    local score_file="${LH_PROMPTS_DIR}/scores/${domain}_${phase}.jsonl"
    [[ ! -f "$score_file" ]] && return 0

    python3 -c "
import json, sys

best = None
best_score = -1

with open(sys.argv[1], 'r') as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        try:
            entry = json.loads(line)
            score = entry.get('quality_score', 0)
            if score > best_score:
                best_score = score
                best = entry
        except:
            continue

if best and best_score > 50:
    print(f'[スコア {best_score:.0f}] 最高品質プロンプト (chars={best.get(\"prompt_chars\",0)}, session={best.get(\"session_id\",\"?\")})')
    if best.get('head'):
        print(f'--- HEAD ---')
        print(best['head'][:300])
    if best.get('tail'):
        print(f'--- TAIL ---')
        print(best['tail'][:150])
" "$score_file" 2>/dev/null
}

# プロンプト効果の統計サマリ
lh_prompt_stats() {
    local domain="${1:-${LH_DOMAIN:-general}}"

    python3 -c "
import json, sys, os, glob

domain = sys.argv[1]
prompts_dir = sys.argv[2]
stats = {}

for filepath in glob.glob(os.path.join(prompts_dir, 'scores', f'{domain}_*.jsonl')):
    phase = os.path.basename(filepath).replace(f'{domain}_', '').replace('.jsonl', '')
    scores = []
    with open(filepath, 'r') as f:
        for line in f:
            try:
                entry = json.loads(line.strip())
                scores.append(entry.get('quality_score', 0))
            except:
                continue
    if scores:
        stats[phase] = {
            'count': len(scores),
            'avg': sum(scores) / len(scores),
            'max': max(scores),
            'min': min(scores),
            'trend': 'improving' if len(scores) > 1 and scores[-1] > scores[0] else 'stable'
        }

if not stats:
    sys.exit(0)

print(f'=== プロンプト効果サマリ (domain={domain}) ===')
for phase, s in sorted(stats.items(), key=lambda x: x[1]['avg'], reverse=True):
    trend_icon = '📈' if s['trend'] == 'improving' else '📊'
    print(f'  {trend_icon} {phase}: avg={s[\"avg\"]:.0f} max={s[\"max\"]:.0f} min={s[\"min\"]:.0f} ({s[\"count\"]}回)')
" "$domain" "$LH_PROMPTS_DIR" 2>/dev/null
}

# ============================================================
# [5] Cross-Session Intelligence - 過去セッション学習データ注入
# ============================================================

# 過去の成功・失敗パターンをコンテキストとして組み立てる
# → call_claudeに注入してAIの精度を向上させる
lh_build_intelligence_context() {
    local phase="${1:-unknown}"
    local domain="${2:-${LH_DOMAIN:-general}}"
    local max_chars="${3:-3000}"

    python3 -c "
import json, sys, os, glob

phase = sys.argv[1]
domain = sys.argv[2]
max_chars = int(sys.argv[3])
base_dir = sys.argv[4]

context_parts = []
total_chars = 0

# --- 1. 過去の解決策（成功のもの）---
solutions_dir = os.path.join(base_dir, 'solutions', 'by-error')
if os.path.isdir(solutions_dir):
    successful_solutions = []
    for filepath in glob.glob(os.path.join(solutions_dir, '*.jsonl')):
        with open(filepath, 'r') as f:
            for line in f:
                try:
                    entry = json.loads(line.strip())
                    if entry.get('success') and entry.get('phase') == phase:
                        successful_solutions.append(entry)
                except:
                    continue
    # 最新5件
    successful_solutions.sort(key=lambda x: x.get('timestamp', ''), reverse=True)
    if successful_solutions[:5]:
        section = '[過去に成功した修正パターン]\n'
        for sol in successful_solutions[:5]:
            line = f'- {sol.get(\"error_type\", \"?\")} → {sol.get(\"solution\", \"?\")[:150]}\n'
            section += line
        context_parts.append(section)

# --- 2. フェーズ別の品質トレンド ---
metrics_file = os.path.join(base_dir, 'metrics', 'phases', f'{phase}.jsonl')
if os.path.isfile(metrics_file):
    records = []
    with open(metrics_file, 'r') as f:
        for line in f:
            try:
                records.append(json.loads(line.strip()))
            except:
                continue
    if records:
        recent = records[-10:]  # 直近10件
        avg_quality = sum(r.get('quality_score', 0) for r in recent) / len(recent)
        avg_errors = sum(r.get('error_count', 0) for r in recent) / len(recent)
        section = f'[フェーズ \"{phase}\" の品質傾向]\n'
        section += f'- 直近{len(recent)}回の平均品質スコア: {avg_quality:.0f}/100\n'
        section += f'- 直近{len(recent)}回の平均エラー数: {avg_errors:.1f}\n'
        if len(records) > 1:
            first_half = records[:len(records)//2]
            second_half = records[len(records)//2:]
            fh_avg = sum(r.get('quality_score', 0) for r in first_half) / max(len(first_half), 1)
            sh_avg = sum(r.get('quality_score', 0) for r in second_half) / max(len(second_half), 1)
            if sh_avg > fh_avg:
                section += f'- 品質傾向: 改善中 (前半平均{fh_avg:.0f} → 後半平均{sh_avg:.0f})\n'
            else:
                section += f'- 品質傾向: 要注意 (前半平均{fh_avg:.0f} → 後半平均{sh_avg:.0f})\n'
        context_parts.append(section)

# --- 3. ドメイン別の頻出エラー ---
if os.path.isdir(solutions_dir):
    error_counts = {}
    for filepath in glob.glob(os.path.join(solutions_dir, '*.jsonl')):
        with open(filepath, 'r') as f:
            for line in f:
                try:
                    entry = json.loads(line.strip())
                    if entry.get('domain') == domain and not entry.get('success'):
                        etype = entry.get('error_type', 'unknown')
                        error_counts[etype] = error_counts.get(etype, 0) + 1
                except:
                    continue
    if error_counts:
        top_errors = sorted(error_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        section = f'[ドメイン \"{domain}\" で頻出するエラー（回避すべき）]\n'
        for etype, count in top_errors:
            section += f'- {etype} ({count}回発生)\n'
        context_parts.append(section)

# --- 4. セッション成功率 ---
sessions_file = os.path.join(base_dir, 'metrics', 'sessions', 'sessions.jsonl')
if os.path.isfile(sessions_file):
    domain_sessions = []
    with open(sessions_file, 'r') as f:
        for line in f:
            try:
                entry = json.loads(line.strip())
                if entry.get('domain') == domain:
                    domain_sessions.append(entry)
            except:
                continue
    if domain_sessions:
        total = len(domain_sessions)
        success = sum(1 for s in domain_sessions if s.get('success'))
        section = f'[過去の実績: {domain}ドメイン]\n'
        section += f'- 成功率: {success}/{total} ({success/total*100:.0f}%)\n'
        if domain_sessions:
            latest = domain_sessions[-1]
            section += f'- 直近セッション: 品質{latest.get(\"final_quality_score\", 0):.0f}, コスト\${latest.get(\"total_cost_usd\", 0):.2f}\n'
        context_parts.append(section)

# --- 5. 再発防止パターン (PFP-118: 管理者メモリ蒸留 PFP コーパス) ---
# scripts/learning/pfp-corpus-etl.sh が patterns/pfp_corpus.jsonl を生成する
corpus_file = os.path.join(base_dir, 'patterns', 'pfp_corpus.jsonl')
if os.path.isfile(corpus_file):
    corpus = []
    with open(corpus_file, 'r') as f:
        for line in f:
            try:
                corpus.append(json.loads(line.strip()))
            except:
                continue
    if corpus:
        # domain に近い症状カテゴリを優先し、残りは新しい順で最大5件
        corpus.sort(key=lambda x: x.get('distilled_at', ''), reverse=True)
        picked = []
        for e in corpus:
            if domain and domain != 'general' and domain in (e.get('symptom_category', '') + e.get('root_cause', '')):
                picked.append(e)
            if len(picked) >= 3:
                break
        for e in corpus:
            if len(picked) >= 5:
                break
            if e not in picked:
                picked.append(e)
        if picked:
            section = '[再発防止パターン（過去事案から蒸留・回避すべき）]\n'
            for e in picked[:5]:
                rc = (e.get('root_cause') or '')[:80]
                fx = (e.get('structural_fix') or '')[:80]
                section += f'- {e.get(\"pfp_id\", \"?\")} [{e.get(\"symptom_category\", \"\")}] 真因: {rc}'
                if fx:
                    section += f' → 対策: {fx}'
                section += '\n'
            context_parts.append(section)

# 出力（文字数制限）
output = '\n'.join(context_parts)
if len(output) > max_chars:
    output = output[:max_chars] + '\n...(truncated)'
print(output)
" "$phase" "$domain" "$max_chars" "$LH_BASE_DIR" 2>/dev/null
}

# セッション完了時にインテリジェンスサマリを保存
lh_save_session_intelligence() {
    [[ "$LH_ENABLED" != "true" ]] && return 0

    local task_desc="${1:-}"
    local project_dir="${2:-.}"

    local summary_file="${LH_INTEL_DIR}/summaries/${LH_SESSION_ID}.json"

    python3 -c "
import json, sys, os, glob

session_id = sys.argv[1]
task_desc = sys.argv[2]
domain = sys.argv[3]
base_dir = sys.argv[4]
output_file = sys.argv[5]

# 当セッションのコールログ集計
call_stats = {'total': 0, 'success': 0, 'failed': 0, 'by_phase': {}, 'by_model': {}}
calls_dir = os.path.join(base_dir, 'calls')
if os.path.isdir(calls_dir):
    for filepath in sorted(glob.glob(os.path.join(calls_dir, '*.jsonl')))[-7:]:
        with open(filepath, 'r') as f:
            for line in f:
                try:
                    entry = json.loads(line.strip())
                    if entry.get('session_id') != session_id:
                        continue
                    call_stats['total'] += 1
                    if entry.get('success'):
                        call_stats['success'] += 1
                    else:
                        call_stats['failed'] += 1
                    p = entry.get('phase', 'unknown')
                    call_stats['by_phase'][p] = call_stats['by_phase'].get(p, 0) + 1
                    m = entry.get('model_tier', 'balanced')
                    call_stats['by_model'][m] = call_stats['by_model'].get(m, 0) + 1
                except:
                    continue

summary = {
    'session_id': session_id,
    'task': task_desc[:500],
    'domain': domain,
    'call_stats': call_stats,
    'timestamp': sys.argv[6]
}

os.makedirs(os.path.dirname(output_file), exist_ok=True)
with open(output_file, 'w') as f:
    json.dump(summary, f, ensure_ascii=False, indent=2)

print(f'Learning intelligence saved: {call_stats[\"total\"]} calls, {call_stats[\"success\"]} success')
" "$LH_SESSION_ID" "$task_desc" "$LH_DOMAIN" "$LH_BASE_DIR" \
  "$summary_file" "$(date '+%Y-%m-%dT%H:%M:%S')" 2>/dev/null
}

# ============================================================
# [6] Healer連携 - エラー修正結果の自動記録
# ============================================================

# ヒーリング結果をSolution Indexに自動登録
lh_record_healing_result() {
    [[ "$LH_ENABLED" != "true" ]] && return 0

    local phase="${1:-unknown}"
    local error_report="${2:-}"
    local healing_output="${3:-}"
    local success="${4:-0}"

    # エラーレポートから主要なエラータイプを抽出
    local error_type="unknown"
    if echo "$error_report" | grep -qi "typescript\|tsc\|type.*error"; then
        error_type="typescript_error"
    elif echo "$error_report" | grep -qi "syntax\|parse\|unexpected"; then
        error_type="syntax_error"
    elif echo "$error_report" | grep -qi "import\|module\|require\|cannot find"; then
        error_type="import_error"
    elif echo "$error_report" | grep -qi "prisma\|database\|migration\|schema"; then
        error_type="database_error"
    elif echo "$error_report" | grep -qi "api\|fetch\|endpoint\|route\|404\|500"; then
        error_type="api_error"
    elif echo "$error_report" | grep -qi "react\|component\|render\|jsx\|tsx\|hook"; then
        error_type="react_error"
    elif echo "$error_report" | grep -qi "auth\|jwt\|token\|session\|login"; then
        error_type="auth_error"
    elif echo "$error_report" | grep -qi "test\|assert\|expect\|jest\|vitest"; then
        error_type="test_error"
    elif echo "$error_report" | grep -qi "build\|compile\|webpack\|vite\|next"; then
        error_type="build_error"
    elif echo "$error_report" | grep -qi "css\|style\|tailwind\|layout"; then
        error_type="style_error"
    fi

    lh_record_solution "$error_type" "${error_report:0:500}" "${healing_output:0:1000}" "$phase" "$success"
}

# ============================================================
# [7] ガベージコレクション - 古いデータの自動削除
# ============================================================

lh_gc() {
    [[ "$LH_ENABLED" != "true" ]] && return 0

    _lh_log "INFO" "Learning Hub ガベージコレクション実行中..."

    python3 -c "
import os, sys, glob, json
from datetime import datetime, timedelta

base_dir = sys.argv[1]
max_days = int(sys.argv[2])
max_calls = int(sys.argv[3])
cutoff = (datetime.now() - timedelta(days=max_days)).strftime('%Y%m%d')

# 古いコールログの削除
calls_dir = os.path.join(base_dir, 'calls')
if os.path.isdir(calls_dir):
    files = sorted(glob.glob(os.path.join(calls_dir, '*.jsonl')))
    if len(files) > max_calls // 100:  # 100エントリ/日として
        for f in files[:len(files) - max_calls // 100]:
            date_part = os.path.basename(f).replace('.jsonl', '')
            if date_part < cutoff:
                os.remove(f)
                print(f'Removed old call log: {os.path.basename(f)}')

# インテリジェンスサマリの古いもの削除
intel_dir = os.path.join(base_dir, 'intelligence', 'summaries')
if os.path.isdir(intel_dir):
    files = sorted(glob.glob(os.path.join(intel_dir, '*.json')))
    if len(files) > 200:
        for f in files[:len(files) - 200]:
            os.remove(f)

print('GC completed')
" "$LH_BASE_DIR" "$LH_MAX_METRICS_DAYS" "$LH_MAX_CALL_LOGS" 2>/dev/null || true

    _lh_log "OK" "ガベージコレクション完了"
}

# ============================================================
# [8] ダッシュボード - 学習状況の可視化
# ============================================================

lh_dashboard() {
    python3 -c "
import json, sys, os, glob
from datetime import datetime

base_dir = sys.argv[1]

print('╔════════════════════════════════════════════════════════╗')
print('║          Learning Hub Dashboard                       ║')
print('╠════════════════════════════════════════════════════════╣')

# コールログ統計
calls_dir = os.path.join(base_dir, 'calls')
total_calls = 0
success_calls = 0
if os.path.isdir(calls_dir):
    for filepath in glob.glob(os.path.join(calls_dir, '*.jsonl')):
        with open(filepath, 'r') as f:
            for line in f:
                try:
                    entry = json.loads(line.strip())
                    total_calls += 1
                    if entry.get('success'):
                        success_calls += 1
                except:
                    continue

print(f'║ 📞 Claude呼び出し総数: {total_calls:,}')
if total_calls > 0:
    print(f'║ ✅ 成功率: {success_calls/total_calls*100:.1f}% ({success_calls}/{total_calls})')

# ソリューション統計
solutions_dir = os.path.join(base_dir, 'solutions', 'by-error')
total_solutions = 0
error_types = set()
if os.path.isdir(solutions_dir):
    for filepath in glob.glob(os.path.join(solutions_dir, '*.jsonl')):
        error_types.add(os.path.basename(filepath).replace('.jsonl', ''))
        with open(filepath, 'r') as f:
            total_solutions += sum(1 for _ in f)

print(f'║ 🔧 蓄積ソリューション: {total_solutions:,} ({len(error_types)}種類のエラータイプ)')

# セッション統計
sessions_file = os.path.join(base_dir, 'metrics', 'sessions', 'sessions.jsonl')
if os.path.isfile(sessions_file):
    sessions = []
    with open(sessions_file, 'r') as f:
        for line in f:
            try:
                sessions.append(json.loads(line.strip()))
            except:
                continue
    if sessions:
        total = len(sessions)
        success = sum(1 for s in sessions if s.get('success'))
        print(f'║ 📊 セッション数: {total} (成功率: {success/total*100:.0f}%)')

        # ドメイン別
        by_domain = {}
        for s in sessions:
            d = s.get('domain', 'general')
            by_domain.setdefault(d, {'total': 0, 'success': 0})
            by_domain[d]['total'] += 1
            if s.get('success'):
                by_domain[d]['success'] += 1
        print(f'║ 🌐 ドメイン別:')
        for d, stats in sorted(by_domain.items(), key=lambda x: x[1]['total'], reverse=True):
            rate = stats['success'] / max(stats['total'], 1) * 100
            print(f'║   {d}: {stats[\"total\"]}回 (成功率{rate:.0f}%)')

# プロンプト統計
prompts_dir = os.path.join(base_dir, 'prompts', 'scores')
prompt_count = 0
if os.path.isdir(prompts_dir):
    for filepath in glob.glob(os.path.join(prompts_dir, '*.jsonl')):
        with open(filepath, 'r') as f:
            prompt_count += sum(1 for _ in f)
print(f'║ 📝 蓄積プロンプトスコア: {prompt_count:,}')

# フェーズメトリクス
metrics_dir = os.path.join(base_dir, 'metrics', 'phases')
if os.path.isdir(metrics_dir):
    phase_files = glob.glob(os.path.join(metrics_dir, '*.jsonl'))
    print(f'║ ⏱️  追跡フェーズ数: {len(phase_files)}')

print('╚════════════════════════════════════════════════════════╝')
" "$LH_BASE_DIR" 2>/dev/null
}

# ============================================================
# [9] 統合エクスポート
# ============================================================

lh_export_learning_report() {
    local output_file="${1:-${SESSION_LOG_DIR:-/tmp}/learning_report.json}"

    python3 -c "
import json, sys, os, glob

base_dir = sys.argv[1]
output = sys.argv[2]

report = {
    'generated_at': sys.argv[3],
    'calls': {'total': 0, 'success': 0, 'by_phase': {}, 'by_model': {}},
    'solutions': {'total': 0, 'by_type': {}},
    'sessions': {'total': 0, 'success': 0, 'by_domain': {}},
    'prompts': {'total': 0, 'by_phase': {}}
}

# コールログ集計
calls_dir = os.path.join(base_dir, 'calls')
if os.path.isdir(calls_dir):
    for filepath in glob.glob(os.path.join(calls_dir, '*.jsonl')):
        with open(filepath, 'r') as f:
            for line in f:
                try:
                    entry = json.loads(line.strip())
                    report['calls']['total'] += 1
                    if entry.get('success'):
                        report['calls']['success'] += 1
                    p = entry.get('phase', 'unknown')
                    report['calls']['by_phase'][p] = report['calls']['by_phase'].get(p, 0) + 1
                except:
                    continue

# ソリューション集計
solutions_dir = os.path.join(base_dir, 'solutions', 'by-error')
if os.path.isdir(solutions_dir):
    for filepath in glob.glob(os.path.join(solutions_dir, '*.jsonl')):
        etype = os.path.basename(filepath).replace('.jsonl', '')
        count = 0
        with open(filepath, 'r') as f:
            count = sum(1 for _ in f)
        report['solutions']['total'] += count
        report['solutions']['by_type'][etype] = count

os.makedirs(os.path.dirname(output), exist_ok=True)
with open(output, 'w') as f:
    json.dump(report, f, ensure_ascii=False, indent=2)
print(f'Learning report exported: {output}')
" "$LH_BASE_DIR" "$output_file" "$(date '+%Y-%m-%dT%H:%M:%S')" 2>/dev/null
}
