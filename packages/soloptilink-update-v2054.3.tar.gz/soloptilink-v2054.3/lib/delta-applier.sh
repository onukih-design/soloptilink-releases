#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v28.0 - Delta Applier
# =============================================================================
# Claude出力をターゲット変更として適用し、バックアップ・検証・ロールバックを行う。
# git-basedバックアップ + 構文検証 + ロールバック機能。
#
# 機能:
#   - git stash/tagベースのバックアップポイント作成
#   - Claude出力のファイル別パース・適用
#   - 変更後の構文チェック（tsc --noEmit / python -m py_compile）
#   - ロールバック（バックアップから復元）
#   - gitなし環境でのcp -rフォールバック
#
# 依存: なし（standalone, git optional）
# =============================================================================

[[ -n "${_DELTA_APPLIER_LOADED:-}" ]] && return 0
_DELTA_APPLIER_LOADED=1

# =============================================================================
# 設定
# =============================================================================
DA_VERSION="28.0"
DA_ENABLED="false"
DA_SESSION_ID=""
DA_FILES_APPLIED=0
DA_BACKUP_POINT=""
DA_BACKUP_DIR=""
DA_HAS_GIT="false"
DA_WORK_DIR="${HOME}/.soloptilink/delta-applier"

# カラー
DA_GREEN='\033[0;32m'
DA_YELLOW='\033[0;33m'
DA_RED='\033[0;31m'
DA_CYAN='\033[0;36m'
DA_BOLD='\033[1m'
DA_DIM='\033[2m'
DA_NC='\033[0m'

# =============================================================================
# 初期化
# =============================================================================
da_init() {
    local session_id="${1:-}"
    DA_SESSION_ID="$session_id"
    DA_ENABLED="true"
    DA_FILES_APPLIED=0
    DA_BACKUP_POINT=""
    DA_BACKUP_DIR=""
    DA_HAS_GIT="false"
    mkdir -p "${DA_WORK_DIR}" 2>/dev/null || true
    echo -e "  ${DA_GREEN}OK${DA_NC} Delta Applier v${DA_VERSION}"
}

# =============================================================================
# ログ
# =============================================================================
_da_log() {
    local level="$1" msg="$2"
    local color="${DA_NC}"
    case "$level" in
        INFO)    color="${DA_GREEN}" ;;
        WARN)    color="${DA_YELLOW}" ;;
        ERROR)   color="${DA_RED}" ;;
        DEBUG)   color="${DA_DIM}" ;;
    esac
    echo -e "  ${color}[DA/${level}]${DA_NC} ${msg}" >&2
}

# =============================================================================
# Git検出
# =============================================================================
_da_check_git() {
    local project_dir="${1:-.}"
    if [[ -d "${project_dir}/.git" ]] && command -v git &>/dev/null; then
        DA_HAS_GIT="true"
    else
        DA_HAS_GIT="false"
    fi
    return 0
}

# =============================================================================
# バックアップポイント作成
# =============================================================================
da_create_backup_point() {
    local project_dir="${1:-.}"

    _da_check_git "$project_dir"

    if [[ "$DA_HAS_GIT" == "true" ]]; then
        # Git-based backup
        local timestamp
        timestamp=$(date '+%Y%m%d_%H%M%S')
        local tag_name="delta-backup-${timestamp}"

        # Stage all current changes first
        (cd "$project_dir" && git add -A 2>/dev/null || true)

        # Create a stash (works even with clean working tree with --include-untracked)
        local stash_ref
        stash_ref=$(cd "$project_dir" && git stash create 2>/dev/null || echo "")

        if [[ -n "$stash_ref" ]]; then
            DA_BACKUP_POINT="$stash_ref"
            _da_log "INFO" "Git バックアップ作成: ${stash_ref}"
        else
            # If stash is empty (clean tree), create a ref to current HEAD
            DA_BACKUP_POINT=$(cd "$project_dir" && git rev-parse HEAD 2>/dev/null || echo "")
            _da_log "INFO" "Git HEAD参照: ${DA_BACKUP_POINT}"
        fi
    else
        # Fallback: cp -r backup
        local timestamp
        timestamp=$(date '+%Y%m%d_%H%M%S')
        DA_BACKUP_DIR="${DA_WORK_DIR}/backup_${timestamp}"
        mkdir -p "${DA_BACKUP_DIR}" 2>/dev/null || true

        # Copy source files only (not node_modules/.next/venv)
        rsync -a \
            --exclude='node_modules' \
            --exclude='.next' \
            --exclude='dist' \
            --exclude='venv' \
            --exclude='__pycache__' \
            --exclude='.git' \
            "${project_dir}/" "${DA_BACKUP_DIR}/" 2>/dev/null || {
            # rsync fallback to cp
            cp -r "${project_dir}" "${DA_BACKUP_DIR}" 2>/dev/null || true
        }
        DA_BACKUP_POINT="file://${DA_BACKUP_DIR}"
        _da_log "INFO" "ファイルバックアップ作成: ${DA_BACKUP_DIR}"
    fi

    echo "$DA_BACKUP_POINT"
}

# =============================================================================
# Claude出力からファイル変更をパース
# =============================================================================
da_parse_file_changes() {
    local claude_output="${1:-}"

    [[ -z "$claude_output" ]] && {
        echo "[]"
        return 0
    }

    # Parse --- FILE: path --- blocks
    python3 -c "
import sys, json, re

content = sys.stdin.read()
files = []

# Pattern 1: --- FILE: path ---  ...  --- END FILE ---
pattern1 = r'---\s*FILE:\s*(.+?)\s*---\n(.*?)\n---\s*END\s*FILE\s*---'
for m in re.finditer(pattern1, content, re.DOTALL):
    files.append({'path': m.group(1).strip(), 'content': m.group(2), 'action': 'write'})

# Pattern 2: \`\`\`filepath ... \`\`\`  (common Claude output format)
if not files:
    pattern2 = r'\x60\x60\x60(\S+)\n(.*?)\n\x60\x60\x60'
    for m in re.finditer(pattern2, content, re.DOTALL):
        path = m.group(1).strip()
        if '/' in path and not path.startswith('bash') and not path.startswith('json'):
            files.append({'path': path, 'content': m.group(2), 'action': 'write'})

print(json.dumps(files, ensure_ascii=False))
" <<< "$claude_output" 2>/dev/null || echo "[]"
}

# =============================================================================
# Delta適用
# =============================================================================
da_apply_delta() {
    local claude_output="${1:-}"
    local project_dir="${2:-.}"
    local change_plan="${3:-}"

    DA_FILES_APPLIED=0

    [[ -z "$claude_output" ]] && {
        _da_log "WARN" "Claude出力が空 → 適用スキップ"
        return 1
    }

    # Parse file changes
    local changes_json
    changes_json=$(da_parse_file_changes "$claude_output")

    local file_count
    file_count=$(echo "$changes_json" | python3 -c "import sys,json; print(len(json.loads(sys.stdin.read())))" 2>/dev/null || echo "0")

    if [[ "$file_count" -eq 0 ]]; then
        _da_log "WARN" "パース可能なファイル変更なし"
        return 1
    fi

    _da_log "INFO" "${file_count} ファイルの変更を適用中..."

    # Apply each file change
    echo "$changes_json" | python3 -c "
import json, sys, os

changes = json.loads(sys.stdin.read())
project_dir = '${project_dir}'
applied = 0

for change in changes:
    path = change['path']
    content = change['content']
    action = change.get('action', 'write')

    # Resolve full path
    full_path = os.path.join(project_dir, path)

    if action == 'delete':
        if os.path.exists(full_path):
            os.remove(full_path)
            print(f'DELETED: {path}')
            applied += 1
    else:
        # Create parent directory
        os.makedirs(os.path.dirname(full_path), exist_ok=True)
        with open(full_path, 'w') as f:
            f.write(content)
        print(f'WRITTEN: {path}')
        applied += 1

print(f'TOTAL: {applied}')
" 2>/dev/null

    DA_FILES_APPLIED=$file_count
    _da_log "INFO" "${DA_FILES_APPLIED} ファイル適用完了"
    return 0
}

# =============================================================================
# Delta検証
# =============================================================================
da_validate_delta() {
    local project_dir="${1:-.}"
    local change_plan="${2:-}"
    local errors=0

    _da_log "INFO" "変更の検証中..."

    # TypeScript syntax check
    if [[ -f "${project_dir}/tsconfig.json" ]] && command -v npx &>/dev/null; then
        if ! (cd "$project_dir" && npx tsc --noEmit --pretty false 2>/dev/null); then
            _da_log "WARN" "TypeScript コンパイルエラー検出"
            errors=$((errors + 1))
        fi
    fi

    # Python syntax check
    local py_files
    py_files=$(find "$project_dir" -name "*.py" -not -path "*/venv/*" -not -path "*/__pycache__/*" -newer "${DA_WORK_DIR}/validate_marker" 2>/dev/null || echo "")
    for py_file in $py_files; do
        if ! python3 -m py_compile "$py_file" 2>/dev/null; then
            _da_log "WARN" "Python構文エラー: ${py_file}"
            errors=$((errors + 1))
        fi
    done

    # ESLint check (if available)
    if [[ -f "${project_dir}/.eslintrc.js" ]] || [[ -f "${project_dir}/.eslintrc.json" ]] || [[ -f "${project_dir}/eslint.config.js" ]]; then
        if command -v npx &>/dev/null; then
            if ! (cd "$project_dir" && npx eslint --quiet src/ 2>/dev/null); then
                _da_log "WARN" "ESLintエラー検出"
                errors=$((errors + 1))
            fi
        fi
    fi

    if [[ "$errors" -eq 0 ]]; then
        _da_log "INFO" "検証完了: エラーなし"
        return 0
    else
        _da_log "WARN" "検証完了: ${errors} エラー検出"
        return 1
    fi
}

# =============================================================================
# ロールバック
# =============================================================================
da_rollback_delta() {
    local project_dir="${1:-.}"
    local backup_point="${2:-${DA_BACKUP_POINT}}"

    [[ -z "$backup_point" ]] && {
        _da_log "ERROR" "バックアップポイントが未設定"
        return 1
    }

    if [[ "$backup_point" == file://* ]]; then
        # File-based rollback
        local backup_dir="${backup_point#file://}"
        if [[ -d "$backup_dir" ]]; then
            rsync -a --delete \
                --exclude='node_modules' \
                --exclude='.next' \
                --exclude='dist' \
                --exclude='venv' \
                --exclude='__pycache__' \
                --exclude='.git' \
                "${backup_dir}/" "${project_dir}/" 2>/dev/null || {
                _da_log "ERROR" "ファイルロールバック失敗"
                return 1
            }
            _da_log "INFO" "ファイルロールバック完了"
        else
            _da_log "ERROR" "バックアップディレクトリ未検出: ${backup_dir}"
            return 1
        fi
    else
        # Git-based rollback
        _da_check_git "$project_dir"
        if [[ "$DA_HAS_GIT" == "true" ]]; then
            (cd "$project_dir" && git checkout -- . 2>/dev/null) || true
            if [[ -n "$backup_point" && "$backup_point" != "HEAD" ]]; then
                (cd "$project_dir" && git stash apply "$backup_point" 2>/dev/null) || true
            fi
            _da_log "INFO" "Gitロールバック完了: ${backup_point}"
        else
            _da_log "ERROR" "Gitが利用できません"
            return 1
        fi
    fi

    DA_FILES_APPLIED=0
    return 0
}

# =============================================================================
# レポート
# =============================================================================
da_report() {
    echo -e "\n  ${DA_BOLD}${DA_CYAN}[Delta Applier Report]${DA_NC}"
    echo -e "  Version:       ${DA_VERSION}"
    echo -e "  Files Applied: ${DA_FILES_APPLIED}"
    echo -e "  Backup:        ${DA_BACKUP_POINT:-none}"
    echo -e "  Git:           ${DA_HAS_GIT}"
}
