#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v466.0 - Performance Regression Guard
# =============================================================================
# パフォーマンスリグレッション防止: ベースライン設定、リグレッション検出、レポート生成。
#
# Functions:
#   _prg_init()              - Initialize
#   _prg_set_baselines()     - Set performance baselines
#   _prg_detect_regression() - Detect performance regressions
#   _prg_generate_report()   - Generate regression report
#   _prg_report() / _prg_score()
# =============================================================================

[[ -n "${_PRG_LOADED:-}" ]] && return 0; _PRG_LOADED=1

declare -g PRG_VERSION="466.0"
PRG_GENERATED=0; PRG_ERRORS=0; PRG_FILES_WRITTEN=0
PRG_BASELINES_OK=false; PRG_DETECT_OK=false; PRG_REPORT_GEN_OK=false

_prg_init() {
    PRG_GENERATED=0; PRG_ERRORS=0; PRG_FILES_WRITTEN=0
    PRG_BASELINES_OK=false; PRG_DETECT_OK=false; PRG_REPORT_GEN_OK=false
    return 0
}

_prg_log() { echo -e "  ${CYAN:-\033[0;36m}[perf-guard]${NC:-\033[0m} $*" >&2; }
_prg_ok()  { echo -e "  ${GREEN:-\033[0;32m}✅ [perf-guard]${NC:-\033[0m} $*" >&2; }
_prg_err() { echo -e "  ${RED:-\033[0;31m}❌ [perf-guard]${NC:-\033[0m} $*" >&2; PRG_ERRORS=$((PRG_ERRORS + 1)); }

_prg_write_file() {
    local filepath="$1" content="$2"
    local dir; dir="$(dirname "$filepath")"
    [[ -d "$dir" ]] || mkdir -p "$dir"
    echo "$content" > "$filepath" 2>/dev/null || { _prg_err "Failed to write $filepath"; return 1; }
    PRG_FILES_WRITTEN=$((PRG_FILES_WRITTEN + 1))
    return 0
}

_prg_set_baselines() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/perf-guard/baseline-manager.ts"
    _prg_log "Generating baseline manager..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v466.0 - Performance Baseline Manager

export interface PerformanceBaseline {
  metric: string;
  value: number;
  unit: 'ms' | 'bytes' | 'count' | 'percent';
  threshold: number;          // Max acceptable value
  tolerance: number;          // Percentage above baseline considered regression
  category: 'web-vitals' | 'api' | 'bundle' | 'database';
}

const DEFAULT_BASELINES: PerformanceBaseline[] = [
  { metric: 'LCP', value: 2500, unit: 'ms', threshold: 4000, tolerance: 20, category: 'web-vitals' },
  { metric: 'FID', value: 100, unit: 'ms', threshold: 300, tolerance: 25, category: 'web-vitals' },
  { metric: 'CLS', value: 0.1, unit: 'count', threshold: 0.25, tolerance: 30, category: 'web-vitals' },
  { metric: 'TTFB', value: 200, unit: 'ms', threshold: 600, tolerance: 20, category: 'web-vitals' },
  { metric: 'FCP', value: 1800, unit: 'ms', threshold: 3000, tolerance: 20, category: 'web-vitals' },
  { metric: 'API_P95', value: 200, unit: 'ms', threshold: 500, tolerance: 15, category: 'api' },
  { metric: 'API_P99', value: 500, unit: 'ms', threshold: 1000, tolerance: 15, category: 'api' },
  { metric: 'BUNDLE_SIZE', value: 250000, unit: 'bytes', threshold: 500000, tolerance: 10, category: 'bundle' },
  { metric: 'BUNDLE_JS', value: 150000, unit: 'bytes', threshold: 300000, tolerance: 10, category: 'bundle' },
  { metric: 'DB_QUERY_AVG', value: 50, unit: 'ms', threshold: 200, tolerance: 20, category: 'database' },
];

export class BaselineManager {
  private baselines: Map<string, PerformanceBaseline> = new Map();

  constructor(baselines?: PerformanceBaseline[]) {
    for (const b of baselines ?? DEFAULT_BASELINES) this.baselines.set(b.metric, b);
  }

  setBaseline(metric: string, value: number): void {
    const existing = this.baselines.get(metric);
    if (existing) existing.value = value;
  }

  getBaseline(metric: string): PerformanceBaseline | undefined {
    return this.baselines.get(metric);
  }

  isRegression(metric: string, currentValue: number): boolean {
    const baseline = this.baselines.get(metric);
    if (!baseline) return false;
    const maxAllowed = baseline.value * (1 + baseline.tolerance / 100);
    return currentValue > maxAllowed;
  }

  getAllBaselines(): PerformanceBaseline[] {
    return Array.from(this.baselines.values());
  }

  exportBaselines(): string {
    return JSON.stringify(Array.from(this.baselines.values()), null, 2);
  }

  importBaselines(json: string): void {
    const baselines: PerformanceBaseline[] = JSON.parse(json);
    for (const b of baselines) this.baselines.set(b.metric, b);
  }
}

export const baselineManager = new BaselineManager();
TYPESCRIPT
)
    _prg_write_file "$outfile" "$content" || return 1
    PRG_BASELINES_OK=true
    PRG_GENERATED=$((PRG_GENERATED + 1))
    _prg_ok "Baseline manager generated"
    return 0
}

_prg_detect_regression() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/perf-guard/regression-detector.ts"
    _prg_log "Generating regression detector..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v466.0 - Performance Regression Detector

import { baselineManager, PerformanceBaseline } from './baseline-manager';

export interface RegressionResult {
  metric: string;
  baseline: number;
  current: number;
  delta: number;
  deltaPercent: number;
  isRegression: boolean;
  severity: 'none' | 'warning' | 'critical';
}

export class RegressionDetector {
  detect(measurements: Record<string, number>): RegressionResult[] {
    const results: RegressionResult[] = [];
    for (const [metric, current] of Object.entries(measurements)) {
      const baseline = baselineManager.getBaseline(metric);
      if (!baseline) continue;
      const delta = current - baseline.value;
      const deltaPercent = (delta / baseline.value) * 100;
      const isRegression = baselineManager.isRegression(metric, current);
      const severity = !isRegression ? 'none' : current > baseline.threshold ? 'critical' : 'warning';
      results.push({ metric, baseline: baseline.value, current, delta, deltaPercent, isRegression, severity });
    }
    return results;
  }

  hasRegressions(results: RegressionResult[]): boolean {
    return results.some(r => r.isRegression);
  }

  hasCritical(results: RegressionResult[]): boolean {
    return results.some(r => r.severity === 'critical');
  }

  summarize(results: RegressionResult[]): { total: number; regressions: number; critical: number; improved: number } {
    return {
      total: results.length,
      regressions: results.filter(r => r.isRegression).length,
      critical: results.filter(r => r.severity === 'critical').length,
      improved: results.filter(r => r.delta < 0).length,
    };
  }
}

export const regressionDetector = new RegressionDetector();
TYPESCRIPT
)
    _prg_write_file "$outfile" "$content" || return 1
    PRG_DETECT_OK=true
    PRG_GENERATED=$((PRG_GENERATED + 1))
    _prg_ok "Regression detector generated"
    return 0
}

_prg_generate_report() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/perf-guard/regression-reporter.ts"
    _prg_log "Generating regression reporter..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v466.0 - Performance Regression Reporter

import type { RegressionResult } from './regression-detector';

export class RegressionReporter {
  generateMarkdown(results: RegressionResult[], commitHash?: string): string {
    const regressions = results.filter(r => r.isRegression);
    const improved = results.filter(r => r.delta < 0 && !r.isRegression);
    let md = `# Performance Regression Report\n`;
    if (commitHash) md += `Commit: \`${commitHash}\`\n`;
    md += `Date: ${new Date().toISOString()}\n\n`;
    if (regressions.length > 0) {
      md += `## Regressions (${regressions.length})\n`;
      md += `| Metric | Baseline | Current | Delta | Severity |\n|--------|----------|---------|-------|----------|\n`;
      for (const r of regressions) {
        md += `| ${r.metric} | ${r.baseline} | ${r.current} | +${r.deltaPercent.toFixed(1)}% | ${r.severity} |\n`;
      }
    }
    if (improved.length > 0) {
      md += `\n## Improvements (${improved.length})\n`;
      for (const r of improved) md += `- ${r.metric}: ${r.deltaPercent.toFixed(1)}%\n`;
    }
    md += `\n## Summary\n- Total metrics: ${results.length}\n- Regressions: ${regressions.length}\n- Improvements: ${improved.length}\n`;
    return md;
  }

  generateCIComment(results: RegressionResult[]): string {
    const regressions = results.filter(r => r.isRegression);
    if (regressions.length === 0) return 'All performance metrics within baselines.';
    return `Performance regressions detected:\n${regressions.map(r => `- ${r.metric}: ${r.baseline} -> ${r.current} (+${r.deltaPercent.toFixed(1)}%) [${r.severity}]`).join('\n')}`;
  }

  shouldBlockMerge(results: RegressionResult[]): boolean {
    return results.some(r => r.severity === 'critical');
  }
}

export const regressionReporter = new RegressionReporter();
TYPESCRIPT
)
    _prg_write_file "$outfile" "$content" || return 1
    PRG_REPORT_GEN_OK=true
    PRG_GENERATED=$((PRG_GENERATED + 1))
    _prg_ok "Regression reporter generated"
    return 0
}

_prg_generate_all() {
    local project_dir="${1:-.}"
    _prg_set_baselines "$project_dir"
    _prg_detect_regression "$project_dir"
    _prg_generate_report "$project_dir"
    _prg_ok "Performance regression guard complete: ${PRG_GENERATED} components, ${PRG_ERRORS} errors"
}

_prg_report() {
    echo -e "\n  ${BOLD:-\033[1m}═══ Performance Regression Guard v${PRG_VERSION} ═══${NC:-\033[0m}"
    echo -e "  Generated  : ${PRG_GENERATED}"
    echo -e "  Errors     : ${PRG_ERRORS}"
    echo -e "  Baselines  : ${PRG_BASELINES_OK}"
    echo -e "  Detection  : ${PRG_DETECT_OK}"
    echo -e "  Reporting  : ${PRG_REPORT_GEN_OK}"
}

_prg_score() {
    local score=50
    ${PRG_BASELINES_OK} && score=$((score + 15))
    ${PRG_DETECT_OK} && score=$((score + 15))
    ${PRG_REPORT_GEN_OK} && score=$((score + 15))
    [[ ${PRG_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "performance-regression-guard" --version "466.0" \
        --description "パフォーマンスリグレッション防止: ベースライン×検出×CI連携レポート" \
        --init "_prg_init" --report "_prg_report" --score "_prg_score" \
        --enable-var "ENABLE_PERF_REGRESSION" --cli-flags "--perf-regression:--no-perf-regression"
fi

# v2003.1: source時のexit codeを確実に0にする
true
