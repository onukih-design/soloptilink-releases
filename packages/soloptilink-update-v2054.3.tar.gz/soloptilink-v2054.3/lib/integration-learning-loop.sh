#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2037.x - Integration Learning Loop (ILL)
# =============================================================================
# 「外部サービス連携で、お客様がどこで詰まったか」を記録→集計→IBL辞書へ還元する
# 閉ループ。使われるほど連携辞書(learned_pitfalls)が賢くなる。
# 既存の学習ループ(TWL/Learning Fetcher/DNA harvest)と同じ流儀で接続する。
#
# データ:
#   ~/.soloptilink/learning/integrations/usage.jsonl     - 連携の利用記録
#   ~/.soloptilink/learning/integrations/friction.jsonl  - 詰まり(失敗/手戻り)記録
#   ~/.soloptilink/learning/integrations/insights.json   - 集計結果
#
# Functions:
#   ill_init
#   ill_record_integration_use <connector> <stage> <project>
#   ill_record_friction <connector> <stage> <note> [error]
#   ill_harvest                 - usage/friction を集計して insights.json 生成
#   ill_enrich_ibl              - friction を IBL の learned_pitfalls へ還元(冪等)
#   ill_inject <connector>      - そのコネクタの learned_pitfalls を出力
#   ill_report / ill_score
#
# All globals use the ILL_ prefix.
# (c) 2026 SoloptiLink Inc. - 営業秘密 / 著作権法・不正競争防止法で保護
# =============================================================================

[[ -n "${_INTEGRATION_LEARNING_LOOP_LOADED:-}" ]] && return 0
_INTEGRATION_LEARNING_LOOP_LOADED=1

declare -g ILL_VERSION="1.0"
declare -g ILL_ENABLED="${ILL_ENABLED:-true}"
# 既定値は環境変数で上書き可能(テスト隔離・顧客環境カスタマイズのため :- 形式必須)
declare -g ILL_HOME="${ILL_HOME:-${HOME}/.soloptilink/learning/integrations}"
declare -g ILL_IBL_DIR="${ILL_IBL_DIR:-${HOME}/.soloptilink/integrations}"
declare -g ILL_USAGE="${ILL_USAGE:-${ILL_HOME}/usage.jsonl}"
declare -g ILL_FRICTION="${ILL_FRICTION:-${ILL_HOME}/friction.jsonl}"
declare -g ILL_INSIGHTS="${ILL_INSIGHTS:-${ILL_HOME}/insights.json}"
declare -g ILL_ENRICH_THRESHOLD="${ILL_ENRICH_THRESHOLD:-2}"  # 同一の詰まりが何回出たら辞書へ昇格するか

ill_init() {
    mkdir -p "$ILL_HOME" 2>/dev/null || true
    return 0
}

_ill_ts() { date -u +%Y-%m-%dT%H:%M:%SZ; }
_ill_jesc() { python3 -c "import sys,json;print(json.dumps(sys.argv[1],ensure_ascii=False))" "$1" 2>/dev/null || echo '""'; }

# 連携の利用を記録 (Forge 実行時など)
ill_record_integration_use() {
    [[ "$ILL_ENABLED" != "true" ]] && return 0
    ill_init
    local connector="${1:-unknown}" stage="${2:-forge}" project="${3:-}"
    printf '{"ts":%s,"connector":%s,"stage":%s,"project":%s}\n' \
        "$(_ill_jesc "$(_ill_ts)")" "$(_ill_jesc "$connector")" "$(_ill_jesc "$stage")" "$(_ill_jesc "$(basename "$project")")" \
        >> "$ILL_USAGE" 2>/dev/null || true
    return 0
}

# 詰まり(連携で失敗・手戻りした箇所)を記録
# stage 例: oauth / webhook / rate_limit / token_refresh / scope / setup / signature
ill_record_friction() {
    [[ "$ILL_ENABLED" != "true" ]] && return 0
    ill_init
    local connector="${1:-unknown}" stage="${2:-unknown}" note="${3:-}" error="${4:-}"
    printf '{"ts":%s,"connector":%s,"stage":%s,"note":%s,"error":%s}\n' \
        "$(_ill_jesc "$(_ill_ts)")" "$(_ill_jesc "$connector")" "$(_ill_jesc "$stage")" "$(_ill_jesc "$note")" "$(_ill_jesc "$error")" \
        >> "$ILL_FRICTION" 2>/dev/null || true
    # 既存の中央テレメトリへも転送 (TWL があれば)
    if type -t twl_buffer_error &>/dev/null; then
        twl_buffer_error "$note" "integration_${stage}" "integration_${connector}" "" "false" "false" 2>/dev/null || true
    fi
    return 0
}

# usage/friction を集計して insights.json を生成
ill_harvest() {
    ill_init
    ILL_HOME="$ILL_HOME" ILL_INSIGHTS="$ILL_INSIGHTS" python3 - <<'PY'
import json, os, collections
home = os.environ["ILL_HOME"]
def load(p):
    rows=[]
    fp=os.path.join(home,p)
    if os.path.exists(fp):
        for line in open(fp, encoding="utf-8"):
            line=line.strip()
            if not line: continue
            try: rows.append(json.loads(line))
            except: pass
    return rows
usage=load("usage.jsonl"); friction=load("friction.jsonl")
by=collections.defaultdict(lambda:{"uses":0,"frictions":0,"stages":collections.Counter(),"notes":collections.Counter()})
for u in usage: by[u.get("connector","unknown")]["uses"]+=1
for f in friction:
    c=by[f.get("connector","unknown")]; c["frictions"]+=1
    c["stages"][f.get("stage","unknown")]+=1
    n=f.get("note","").strip()
    if n: c["notes"][n]+=1
out={"generated_at":None,"totals":{"uses":len(usage),"frictions":len(friction),"connectors":len(by)},"by_connector":{}}
for k,v in sorted(by.items()):
    out["by_connector"][k]={"uses":v["uses"],"frictions":v["frictions"],
        "top_stages":v["stages"].most_common(5),"top_notes":v["notes"].most_common(5)}
json.dump(out, open(os.environ["ILL_INSIGHTS"],"w",encoding="utf-8"), ensure_ascii=False, indent=2)
print(f"集計完了: 利用{out['totals']['uses']}件 / 詰まり{out['totals']['frictions']}件 / 対象{out['totals']['connectors']}コネクタ")
for k,v in out["by_connector"].items():
    if v["frictions"]:
        print(f"  {k}: 詰まり{v['frictions']}件 stages={dict(v['top_stages'])}")
PY
}

# friction を IBL の learned_pitfalls[] へ還元 (閾値以上の頻度のものを昇格・冪等)
ill_enrich_ibl() {
    ill_init
    ILL_HOME="$ILL_HOME" ILL_IBL_DIR="$ILL_IBL_DIR" ILL_THRESHOLD="$ILL_ENRICH_THRESHOLD" python3 - <<'PY'
import json, os, collections
home=os.environ["ILL_HOME"]; ibl=os.environ["ILL_IBL_DIR"]; th=int(os.environ["ILL_THRESHOLD"])
fp=os.path.join(home,"friction.jsonl")
if not os.path.exists(fp):
    print("詰まり記録がまだありません(辞書還元なし)"); raise SystemExit(0)
agg=collections.defaultdict(collections.Counter)  # connector -> note -> count
ts=collections.defaultdict(dict)                   # connector -> note -> stage
for line in open(fp, encoding="utf-8"):
    line=line.strip()
    if not line: continue
    try: d=json.loads(line)
    except: continue
    n=(d.get("note") or "").strip()
    if not n: continue
    agg[d.get("connector","")][n]+=1
    ts[d.get("connector","")][n]=d.get("stage","")
promoted=0
for conn,notes in agg.items():
    cf=os.path.join(ibl,f"{conn}.json")
    if not os.path.exists(cf): continue
    data=json.load(open(cf, encoding="utf-8"))
    lp=data.get("learned_pitfalls") or []
    existing={ (x.get("note_ja") if isinstance(x,dict) else x) for x in lp }
    changed=False
    for note,cnt in notes.items():
        if cnt>=th and note not in existing:
            lp.append({"note_ja":note,"count":cnt,"stage":ts[conn].get(note,""),"source":"integration-learning-loop"})
            existing.add(note); changed=True; promoted+=1
    if changed:
        data["learned_pitfalls"]=lp
        json.dump(data, open(cf,"w",encoding="utf-8"), ensure_ascii=False, indent=2)
        print(f"  {conn}: learned_pitfalls に {sum(1 for n,c in notes.items() if c>=th)} 件を昇格")
print(f"辞書還元完了: 計 {promoted} 件の詰まりを IBL に学習させました(閾値={th})")
PY
}

# そのコネクタの learned_pitfalls を表示 (生成プロンプト注入の補完)
ill_inject() {
    local conn="$1"; local cf="${ILL_IBL_DIR}/${conn}.json"
    [[ ! -f "$cf" ]] && return 1
    CF="$cf" python3 -c "
import json,os
d=json.load(open(os.environ['CF']))
lp=d.get('learned_pitfalls') or []
if not lp: raise SystemExit(0)
print('【実運用で学習した追加の罠】')
for p in lp:
    n=p.get('note_ja') if isinstance(p,dict) else p
    print(f'  ★ {n}')
"
}

# =============================================================================
# PFP-118: 生成アプリ側 friction の取り込み (Learning Loop Revival)
# =============================================================================
# connector-forge が生成したアプリは、連携エラー時に自アプリの
# <project>/.soloptilink/integration-friction.jsonl へ軽量記録する
# (API route 経由 / ill_record_friction と同形式)。
# 本関数はそれを ILL の friction.jsonl へ取り込み、閉ループを実データ化する。
# 冪等: プロジェクトごとに取込済み行数カーソルを持ち、新規行のみ追記する。
ill_ingest_project_frictions() {
    [[ "$ILL_ENABLED" != "true" ]] && return 0
    local project_dir="${1:-$PWD}"
    local src="${project_dir}/.soloptilink/integration-friction.jsonl"
    [[ ! -f "$src" ]] && return 0
    ill_init
    mkdir -p "${ILL_HOME}/.ingested" 2>/dev/null || true
    local pjh
    pjh=$(printf '%s' "$project_dir" | { md5 2>/dev/null || md5sum 2>/dev/null; } | tr -d ' -' | cut -c1-16)
    local cursor_file="${ILL_HOME}/.ingested/${pjh:-x}.count"
    ILL_SRC="$src" ILL_DST="$ILL_FRICTION" ILL_CURSOR="$cursor_file" ILL_PROJ="$(basename "$project_dir")" \
        python3 - <<'PY' 2>/dev/null || true
import json, os
src = os.environ["ILL_SRC"]; dst = os.environ["ILL_DST"]
cursor_file = os.environ["ILL_CURSOR"]; proj = os.environ["ILL_PROJ"]
done = 0
try:
    done = int(open(cursor_file).read().strip() or 0)
except Exception:
    done = 0
lines = open(src, encoding="utf-8").read().splitlines()
new = lines[done:]
added = 0
if new:
    with open(dst, "a", encoding="utf-8") as f:
        for line in new:
            line = line.strip()
            if not line:
                continue
            try:
                d = json.loads(line)
            except Exception:
                continue
            # ill_record_friction と同形式へ正規化 (+出所メタ)
            rec = {"ts": d.get("ts", ""), "connector": d.get("connector", "unknown"),
                   "stage": d.get("stage", "unknown"), "note": d.get("note", ""),
                   "error": d.get("error", ""), "project": proj, "source": "generated_app"}
            f.write(json.dumps(rec, ensure_ascii=False) + "\n")
            added += 1
with open(cursor_file, "w") as f:
    f.write(str(len(lines)))
print(f"取込: 新規 {added} 件 (累計 {len(lines)} 行)")
PY
    return 0
}

ill_report() {
    ill_init
    local u=0 f=0
    [[ -f "$ILL_USAGE" ]] && u=$(wc -l < "$ILL_USAGE" 2>/dev/null | tr -d ' ')
    [[ -f "$ILL_FRICTION" ]] && f=$(wc -l < "$ILL_FRICTION" 2>/dev/null | tr -d ' ')
    echo -e "\n  ${BOLD:-}=== Integration Learning Loop v${ILL_VERSION} ===${NC:-}"
    echo -e "  連携利用記録   : ${u}"
    echo -e "  詰まり記録     : ${f}"
}

ill_score() {
    local score=40
    [[ -d "$ILL_HOME" ]] && score=$((score + 30))
    [[ -f "$ILL_USAGE" || -f "$ILL_FRICTION" ]] && score=$((score + 30))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# session 終了時の保存フック (chain.sh の _save_session_data から呼ばれても良いよう公開)
# PFP-118: 第1引数にプロジェクトを渡すと、生成アプリ側 friction を先に取り込む (後方互換: 引数なしも従来通り)
ill_save_learning() {
    local project_dir="${1:-}"
    [[ -n "$project_dir" ]] && ill_ingest_project_frictions "$project_dir" >/dev/null 2>&1 || true
    ill_harvest >/dev/null 2>&1 || true
    ill_enrich_ibl >/dev/null 2>&1 || true
    return 0
}

if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "integration-learning-loop" \
        --version "1.0" \
        --description "外部連携の詰まりを記録→集計→IBL辞書へ還元する学習閉ループ" \
        --init "ill_init" \
        --report "ill_report" \
        --score "ill_score" \
        --enable-var "ENABLE_ILL" \
        --cli-flags "--ill:--no-ill"
fi

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    ill_init
    case "${1:-report}" in
        use)      ill_record_integration_use "${2:-}" "${3:-forge}" "${4:-}" ;;
        friction) ill_record_friction "${2:-}" "${3:-}" "${4:-}" "${5:-}" ;;
        harvest)  ill_harvest ;;
        enrich)   ill_enrich_ibl ;;
        ingest)   ill_ingest_project_frictions "${2:-$PWD}" ;;
        inject)   ill_inject "${2:-}" ;;
        report)   ill_report ;;
        score)    ill_score ;;
        *)        echo "usage: integration-learning-loop.sh {use|friction|harvest|enrich|ingest <project>|inject <conn>|report|score}" ;;
    esac
fi

true
