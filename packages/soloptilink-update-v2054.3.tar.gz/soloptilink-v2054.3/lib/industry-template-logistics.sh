#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v378.0 - Industry Template: Logistics
# =============================================================================
# 物流特化テンプレートエンジン。
# 出荷管理/追跡/倉庫管理/ルート最適化等の物流必須コンポーネントを自動生成。
#
# All globals use the ITL_ prefix.
# =============================================================================

[[ -n "${_INDUSTRY_TEMPLATE_LOGISTICS_LOADED:-}" ]] && return 0
_INDUSTRY_TEMPLATE_LOGISTICS_LOADED=1

declare -g ITL_VERSION="378.0"
declare -g ITL_INITIALIZED=false
declare -g ITL_GENERATED_COUNT=0
declare -g ITL_SHIPMENT_GENERATED=false
declare -g ITL_TRACKING_GENERATED=false
declare -g ITL_WAREHOUSE_GENERATED=false
declare -g ITL_ROUTE_GENERATED=false
declare -g ENABLE_ITL="${ENABLE_ITL:-true}"

_itl_init() {
    ITL_INITIALIZED=true
    ITL_GENERATED_COUNT=0
    return 0
}

_itl_generate_logistics() {
    local project_dir="${1:-.}"
    [[ "$ITL_INITIALIZED" != "true" ]] && _itl_init

    echo -e "  ${CYAN:-\033[0;36m}[ITL]${NC:-\033[0m} 物流業界テンプレート生成開始..." >&2

    _itl_generate_shipment "$project_dir"
    _itl_generate_tracking "$project_dir"
    _itl_generate_warehouse "$project_dir"
    _itl_generate_route "$project_dir"

    echo -e "  ${GREEN:-\033[0;32m}[ITL]${NC:-\033[0m} 物流業界テンプレート生成完了: ${ITL_GENERATED_COUNT}件" >&2
    return 0
}

_itl_generate_shipment() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITL-SHIPMENT] 出荷管理テンプレート

### Prisma Schema
```prisma
model Shipment {
  id              String   @id @default(cuid())
  trackingNumber  String   @unique
  senderId        String
  recipientId     String
  originAddress   Json
  destinationAddress Json
  weight          Float
  dimensions      Json?
  serviceType     String   @default("standard")
  status          String   @default("created")
  estimatedDelivery DateTime?
  actualDelivery  DateTime?
  cost            Int
  currency        String   @default("JPY")
  items           ShipmentItem[]
  events          TrackingEvent[]
  warehouseId     String?
  createdAt       DateTime @default(now())
  updatedAt       DateTime @updatedAt
  @@index([senderId])
  @@index([status])
  @@index([createdAt])
}

model ShipmentItem {
  id          String   @id @default(cuid())
  shipmentId  String
  shipment    Shipment @relation(fields: [shipmentId], references: [id])
  description String
  quantity    Int
  weight      Float?
  value       Int?
  hsCode      String?
}
```

### Shipment Service
```typescript
export class ShipmentService {
  async createShipment(data: CreateShipmentInput): Promise<Shipment> {
    const trackingNumber = generateTrackingNumber();
    const cost = await this.calculateShippingCost(data);
    const estimated = await this.estimateDelivery(data.originAddress, data.destinationAddress, data.serviceType);
    return prisma.$transaction(async (tx) => {
      const shipment = await tx.shipment.create({
        data: { ...data, trackingNumber, cost, estimatedDelivery: estimated,
          items: { create: data.items },
          events: { create: { status: 'created', location: JSON.stringify(data.originAddress), description: '出荷情報登録' } },
        },
      });
      await tx.inventory.updateMany({ /* 在庫減算 */ });
      return shipment;
    });
  }

  async calculateShippingCost(data: CreateShipmentInput): Promise<number> {
    const distance = calculateDistance(data.originAddress, data.destinationAddress);
    const weightRate = Math.ceil(data.weight) * 150;
    const distanceRate = Math.ceil(distance / 100) * 200;
    const serviceMultiplier = data.serviceType === 'express' ? 1.5 : data.serviceType === 'overnight' ? 2.0 : 1.0;
    return Math.round((weightRate + distanceRate) * serviceMultiplier);
  }
}
```
TEMPLATE

    ITL_SHIPMENT_GENERATED=true
    ITL_GENERATED_COUNT=$((ITL_GENERATED_COUNT + 1))
    return 0
}

_itl_generate_tracking() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITL-TRACKING] 追跡テンプレート

### Schema
```prisma
model TrackingEvent {
  id          String   @id @default(cuid())
  shipmentId  String
  shipment    Shipment @relation(fields: [shipmentId], references: [id])
  status      String
  location    Json?
  description String
  occurredAt  DateTime @default(now())
  @@index([shipmentId, occurredAt])
}
```

### Tracking Timeline Component
```tsx
'use client';
export function TrackingTimeline({ trackingNumber }: { trackingNumber: string }) {
  const { data, isLoading, error } = useSWR(`/api/tracking/${trackingNumber}`);

  if (isLoading) return <TimelineSkeleton />;
  if (error) return <ErrorMessage message="追跡情報の取得に失敗しました" />;
  if (!data) return <EmptyState message="追跡番号が見つかりません" />;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between p-4 bg-muted rounded-lg">
        <div>
          <p className="text-sm text-muted-foreground">追跡番号</p>
          <p className="font-mono font-bold">{data.trackingNumber}</p>
        </div>
        <Badge variant={data.status === 'delivered' ? 'default' : 'secondary'}>{statusLabel(data.status)}</Badge>
      </div>
      <ol className="relative border-l border-muted-foreground/20 ml-4">
        {data.events.map((event: TrackingEvent, i: number) => (
          <li key={event.id} className="mb-6 ml-6">
            <span className={cn("absolute w-3 h-3 rounded-full -left-1.5", i === 0 ? "bg-primary" : "bg-muted-foreground/40")} />
            <time className="text-sm text-muted-foreground">{format(new Date(event.occurredAt), 'yyyy/MM/dd HH:mm')}</time>
            <p className="font-medium">{event.description}</p>
            {event.location && <p className="text-sm text-muted-foreground">{formatLocation(event.location)}</p>}
          </li>
        ))}
      </ol>
    </div>
  );
}
```
TEMPLATE

    ITL_TRACKING_GENERATED=true
    ITL_GENERATED_COUNT=$((ITL_GENERATED_COUNT + 1))
    return 0
}

_itl_generate_warehouse() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITL-WAREHOUSE] 倉庫管理テンプレート

### Schema
```prisma
model Warehouse {
  id       String  @id @default(cuid())
  name     String
  code     String  @unique
  address  Json
  capacity Int
  zones    WarehouseZone[]
}

model WarehouseZone {
  id          String    @id @default(cuid())
  warehouseId String
  warehouse   Warehouse @relation(fields: [warehouseId], references: [id])
  name        String
  type        String
  locations   StorageLocation[]
  @@unique([warehouseId, name])
}

model StorageLocation {
  id       String        @id @default(cuid())
  zoneId   String
  zone     WarehouseZone @relation(fields: [zoneId], references: [id])
  code     String        @unique
  aisle    String
  rack     String
  shelf    String
  items    WarehouseItem[]
}

model WarehouseItem {
  id         String   @id @default(cuid())
  locationId String
  location   StorageLocation @relation(fields: [locationId], references: [id])
  sku        String
  quantity   Int
  batchNumber String?
  expiryDate DateTime?
  receivedAt DateTime @default(now())
  @@index([sku])
}
```

### Warehouse Dashboard
```typescript
export async function getWarehouseStats(warehouseId: string) {
  const [totalItems, lowStock, expiringSoon] = await Promise.all([
    prisma.warehouseItem.aggregate({ where: { location: { zone: { warehouseId } } }, _sum: { quantity: true } }),
    prisma.warehouseItem.count({ where: { location: { zone: { warehouseId } }, quantity: { lte: 10 } } }),
    prisma.warehouseItem.count({ where: { location: { zone: { warehouseId } }, expiryDate: { lte: addDays(new Date(), 30) } } }),
  ]);
  return { totalItems: totalItems._sum.quantity ?? 0, lowStockCount: lowStock, expiringSoonCount: expiringSoon };
}
```
TEMPLATE

    ITL_WAREHOUSE_GENERATED=true
    ITL_GENERATED_COUNT=$((ITL_GENERATED_COUNT + 1))
    return 0
}

_itl_generate_route() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITL-ROUTE] ルート最適化テンプレート

### Route Planning
```typescript
export class RoutePlanner {
  async optimizeRoutes(deliveries: Delivery[], vehicles: Vehicle[]): Promise<Route[]> {
    const clusters = this.clusterByProximity(deliveries, vehicles.length);
    return clusters.map((cluster, i) => {
      const vehicle = vehicles[i];
      const ordered = this.nearestNeighborSort(cluster, vehicle.startLocation);
      return {
        vehicleId: vehicle.id, stops: ordered,
        estimatedDistance: this.calculateTotalDistance(ordered),
        estimatedDuration: this.calculateTotalDuration(ordered),
      };
    });
  }

  private clusterByProximity(deliveries: Delivery[], k: number): Delivery[][] {
    // K-means clustering by coordinates
    const centroids = deliveries.slice(0, k).map(d => ({ lat: d.latitude, lng: d.longitude }));
    const clusters: Delivery[][] = Array.from({ length: k }, () => []);
    for (const delivery of deliveries) {
      let minDist = Infinity, bestCluster = 0;
      centroids.forEach((c, i) => {
        const dist = haversineDistance(delivery.latitude, delivery.longitude, c.lat, c.lng);
        if (dist < minDist) { minDist = dist; bestCluster = i; }
      });
      clusters[bestCluster].push(delivery);
    }
    return clusters;
  }
}
```
TEMPLATE

    ITL_ROUTE_GENERATED=true
    ITL_GENERATED_COUNT=$((ITL_GENERATED_COUNT + 1))
    return 0
}

_itl_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Industry Template: Logistics v${ITL_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成テンプレート数 : ${ITL_GENERATED_COUNT}"
    echo -e "  Shipment           : ${ITL_SHIPMENT_GENERATED}"
    echo -e "  Tracking           : ${ITL_TRACKING_GENERATED}"
    echo -e "  Warehouse          : ${ITL_WAREHOUSE_GENERATED}"
    echo -e "  Route              : ${ITL_ROUTE_GENERATED}"
}

_itl_score() {
    local score=30
    [[ "$ITL_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$ITL_SHIPMENT_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITL_TRACKING_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITL_WAREHOUSE_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITL_ROUTE_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "industry-template-logistics" \
    --version "378.0" \
    --description "物流業界テンプレート（出荷/追跡/倉庫/ルート最適化）" \
    --init "_itl_init" \
    --report "_itl_report" \
    --score "_itl_score" \
    --enable-var "ENABLE_ITL" \
    --cli-flags "--industry-logistics:--no-industry-logistics"
