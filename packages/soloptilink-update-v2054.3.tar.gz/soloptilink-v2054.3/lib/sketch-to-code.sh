#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v405.0 - Sketch to Code Engine
# =============================================================================
# ワイヤーフレーム/スケッチ記述からReactコンポーネント・スタイルを
# 自動生成する。レイアウト解析・コンポーネント推論・スタイル生成を統合。
#
# Functions:
#   _stc_init               - 初期化
#   _stc_parse_wireframe    - ワイヤーフレーム記述をレイアウトASTにパース
#   _stc_generate_components - ASTからReactコンポーネント生成
#   _stc_generate_styles    - コンポーネント用Tailwind/CSSスタイル生成
#   _stc_report             - レポート出力
#   _stc_score              - モジュールスコア(0-100)
#
# All globals use the STC_ prefix.
# =============================================================================

[[ -n "${_SKETCH_TO_CODE_LOADED:-}" ]] && return 0
_SKETCH_TO_CODE_LOADED=1

declare -g STC_VERSION="405.0"
declare -g STC_INITIALIZED=false
declare -g STC_STORE_DIR=""
declare -g STC_PARSE_COUNT=0
declare -g STC_COMPONENT_COUNT=0
declare -g STC_STYLE_COUNT=0

declare -g -A _STC_LAYOUT_MAP=()      # layout_type → css_class
declare -g -A _STC_WIDGET_MAP=()      # widget_type → component_template
declare -g -A _STC_SPACING_MAP=()     # size_hint → tailwind_class

# =============================================================================
_stc_init() {
    local project_dir="${PROJECT_DIR:-.}"
    STC_STORE_DIR="${project_dir}/.soloptilink/sketch-to-code"
    mkdir -p "${STC_STORE_DIR}/components" "${STC_STORE_DIR}/layouts"

    # Layout type mapping
    _STC_LAYOUT_MAP["row"]="flex flex-row"
    _STC_LAYOUT_MAP["column"]="flex flex-col"
    _STC_LAYOUT_MAP["grid"]="grid"
    _STC_LAYOUT_MAP["grid-2"]="grid grid-cols-2 gap-4"
    _STC_LAYOUT_MAP["grid-3"]="grid grid-cols-3 gap-4"
    _STC_LAYOUT_MAP["grid-4"]="grid grid-cols-4 gap-4"
    _STC_LAYOUT_MAP["stack"]="flex flex-col space-y-4"
    _STC_LAYOUT_MAP["sidebar"]="flex flex-row"
    _STC_LAYOUT_MAP["center"]="flex items-center justify-center"
    _STC_LAYOUT_MAP["full"]="w-full"

    # Widget type mapping
    _STC_WIDGET_MAP["header"]="Header"
    _STC_WIDGET_MAP["nav"]="Navigation"
    _STC_WIDGET_MAP["sidebar"]="Sidebar"
    _STC_WIDGET_MAP["card"]="Card"
    _STC_WIDGET_MAP["table"]="DataTable"
    _STC_WIDGET_MAP["form"]="Form"
    _STC_WIDGET_MAP["button"]="Button"
    _STC_WIDGET_MAP["input"]="Input"
    _STC_WIDGET_MAP["list"]="List"
    _STC_WIDGET_MAP["modal"]="Dialog"
    _STC_WIDGET_MAP["chart"]="Chart"
    _STC_WIDGET_MAP["image"]="Image"
    _STC_WIDGET_MAP["footer"]="Footer"
    _STC_WIDGET_MAP["search"]="SearchInput"
    _STC_WIDGET_MAP["tabs"]="Tabs"
    _STC_WIDGET_MAP["dropdown"]="DropdownMenu"
    _STC_WIDGET_MAP["avatar"]="Avatar"
    _STC_WIDGET_MAP["badge"]="Badge"
    _STC_WIDGET_MAP["alert"]="Alert"
    _STC_WIDGET_MAP["toast"]="Toast"

    # Spacing hints
    _STC_SPACING_MAP["tight"]="gap-1 p-1"
    _STC_SPACING_MAP["compact"]="gap-2 p-2"
    _STC_SPACING_MAP["normal"]="gap-4 p-4"
    _STC_SPACING_MAP["loose"]="gap-6 p-6"
    _STC_SPACING_MAP["spacious"]="gap-8 p-8"

    STC_INITIALIZED=true
    return 0
}

# =============================================================================
# _stc_parse_wireframe - Parse wireframe description to layout AST
# =============================================================================
_stc_parse_wireframe() {
    local description="$1"
    [[ -z "$description" ]] && { echo "ERROR: Empty wireframe description" >&2; return 1; }

    STC_PARSE_COUNT=$((STC_PARSE_COUNT + 1))
    local lower
    lower=$(echo "$description" | tr '[:upper:]' '[:lower:]')

    # Detect page type
    local page_type="page"
    if echo "$lower" | grep -qi 'dashboard'; then page_type="dashboard"
    elif echo "$lower" | grep -qi 'form\|edit\|create'; then page_type="form"
    elif echo "$lower" | grep -qi 'list\|table\|index'; then page_type="list"
    elif echo "$lower" | grep -qi 'detail\|view\|show'; then page_type="detail"
    elif echo "$lower" | grep -qi 'login\|signin\|auth'; then page_type="auth"
    elif echo "$lower" | grep -qi 'landing\|home\|hero'; then page_type="landing"
    elif echo "$lower" | grep -qi 'settings\|config\|preferences'; then page_type="settings"
    fi

    # Detect layout
    local layout="column"
    if echo "$lower" | grep -qi 'sidebar'; then layout="sidebar"
    elif echo "$lower" | grep -qi 'grid'; then layout="grid-3"
    elif echo "$lower" | grep -qi 'two.column\|split'; then layout="grid-2"
    fi

    # Detect widgets
    local widgets=()
    for widget_key in "${!_STC_WIDGET_MAP[@]}"; do
        if echo "$lower" | grep -qi "$widget_key"; then
            widgets+=("$widget_key")
        fi
    done

    # If no widgets detected, infer from page type
    if [[ ${#widgets[@]} -eq 0 ]]; then
        case "$page_type" in
            dashboard) widgets=("header" "nav" "card" "chart" "table") ;;
            form) widgets=("header" "form" "input" "button") ;;
            list) widgets=("header" "search" "table" "button") ;;
            detail) widgets=("header" "card" "button") ;;
            auth) widgets=("card" "form" "input" "button") ;;
            landing) widgets=("header" "image" "card" "button" "footer") ;;
            settings) widgets=("header" "nav" "form" "input" "button") ;;
            *) widgets=("header" "card" "button") ;;
        esac
    fi

    # Detect spacing
    local spacing="normal"
    if echo "$lower" | grep -qi 'compact\|dense\|tight'; then spacing="compact"
    elif echo "$lower" | grep -qi 'spacious\|loose\|airy'; then spacing="spacious"
    fi

    local widget_json
    widget_json=$(printf '"%s",' "${widgets[@]}" | sed 's/,$//')

    cat <<ASTEOF
{"page_type":"${page_type}","layout":"${layout}","widgets":[${widget_json}],"spacing":"${spacing}"}
ASTEOF
    return 0
}

# =============================================================================
# _stc_generate_components - Generate React components from layout AST
# =============================================================================
_stc_generate_components() {
    local ast="$1"
    local component_name="${2:-GeneratedPage}"

    [[ "$STC_INITIALIZED" != "true" ]] && { echo "ERROR: STC not initialized" >&2; return 1; }
    STC_COMPONENT_COUNT=$((STC_COMPONENT_COUNT + 1))

    local page_type layout spacing
    page_type=$(echo "$ast" | sed 's/.*"page_type":"\([^"]*\)".*/\1/')
    layout=$(echo "$ast" | sed 's/.*"layout":"\([^"]*\)".*/\1/')
    spacing=$(echo "$ast" | sed 's/.*"spacing":"\([^"]*\)".*/\1/')

    local layout_class="${_STC_LAYOUT_MAP[$layout]:-flex flex-col}"
    local spacing_class="${_STC_SPACING_MAP[$spacing]:-gap-4 p-4}"

    # Extract widget list
    local widgets_raw
    widgets_raw=$(echo "$ast" | sed 's/.*\[//;s/\].*//' | tr -d '"' | tr ',' ' ')

    cat <<COMPEOF
'use client';

import { useState } from 'react';

export default function ${component_name}() {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600" />
      </div>
    );
  }

  if (error) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-red-500 text-center">
          <p className="text-lg font-semibold">Error</p>
          <p className="text-sm mt-1">{error}</p>
          <button onClick={() => setError(null)} className="mt-2 text-blue-600 underline">Retry</button>
        </div>
      </div>
    );
  }

  return (
    <div className="${layout_class} ${spacing_class} min-h-screen">
COMPEOF

    # Generate widget sections
    for widget in $widgets_raw; do
        local comp_name="${_STC_WIDGET_MAP[$widget]:-div}"
        case "$widget" in
            header)
                cat <<'HEADEREOF'
      {/* Header */}
      <header className="flex items-center justify-between p-4 border-b bg-white">
        <h1 className="text-xl font-bold">Page Title</h1>
        <nav className="flex items-center gap-2">
          <button className="px-3 py-1.5 text-sm rounded-md hover:bg-gray-100">Action</button>
        </nav>
      </header>
HEADEREOF
                ;;
            card)
                cat <<'CARDEOF'
      {/* Card */}
      <div className="bg-white rounded-lg border p-6 shadow-sm">
        <h3 className="font-semibold text-lg mb-2">Card Title</h3>
        <p className="text-gray-600">Card content goes here.</p>
      </div>
CARDEOF
                ;;
            table)
                cat <<'TABLEEOF'
      {/* Data Table */}
      <div className="bg-white rounded-lg border overflow-hidden">
        <table className="w-full">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Name</th>
              <th className="px-4 py-3 text-left text-sm font-medium text-gray-500">Status</th>
              <th className="px-4 py-3 text-right text-sm font-medium text-gray-500">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y">
            <tr className="hover:bg-gray-50">
              <td className="px-4 py-3 text-sm">Item</td>
              <td className="px-4 py-3"><span className="px-2 py-0.5 text-xs rounded-full bg-green-100 text-green-700">Active</span></td>
              <td className="px-4 py-3 text-right"><button className="text-blue-600 text-sm hover:underline">Edit</button></td>
            </tr>
          </tbody>
        </table>
      </div>
TABLEEOF
                ;;
            form)
                cat <<'FORMEOF'
      {/* Form */}
      <form className="bg-white rounded-lg border p-6 space-y-4" onSubmit={(e) => { e.preventDefault(); }}>
        <div>
          <label className="block text-sm font-medium mb-1">Field Label</label>
          <input type="text" className="w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="Enter value..." />
        </div>
        <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:opacity-50">Submit</button>
      </form>
FORMEOF
                ;;
            search)
                cat <<'SEARCHEOF'
      {/* Search */}
      <div className="relative">
        <input type="search" className="w-full pl-10 pr-4 py-2 border rounded-md" placeholder="Search..." />
        <svg className="absolute left-3 top-2.5 h-4 w-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" /></svg>
      </div>
SEARCHEOF
                ;;
            button)
                cat <<'BTNEOF'
      {/* Action Button */}
      <div className="flex gap-2">
        <button className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">Primary</button>
        <button className="px-4 py-2 border rounded-md hover:bg-gray-50 transition-colors">Secondary</button>
      </div>
BTNEOF
                ;;
            footer)
                cat <<'FOOTEREOF'
      {/* Footer */}
      <footer className="mt-auto p-4 border-t text-center text-sm text-gray-500">
        <p>&copy; 2026 All rights reserved.</p>
      </footer>
FOOTEREOF
                ;;
            *)
                echo "      {/* ${comp_name} placeholder */}"
                echo "      <div className=\"p-4 border rounded-md bg-gray-50\">TODO: ${comp_name}</div>"
                ;;
        esac
    done

    echo "    </div>"
    echo "  );"
    echo "}"
    return 0
}

# =============================================================================
# _stc_generate_styles - Generate Tailwind config or CSS for components
# =============================================================================
_stc_generate_styles() {
    local ast="$1"
    local format="${2:-tailwind}"  # tailwind|css

    STC_STYLE_COUNT=$((STC_STYLE_COUNT + 1))

    local page_type
    page_type=$(echo "$ast" | sed 's/.*"page_type":"\([^"]*\)".*/\1/')

    case "$format" in
        tailwind)
            cat <<TWEOF
/* Custom Tailwind utilities for ${page_type} page */
@layer components {
  .page-container {
    @apply min-h-screen bg-gray-50;
  }
  .content-card {
    @apply bg-white rounded-lg border shadow-sm p-6;
  }
  .page-header {
    @apply flex items-center justify-between p-4 bg-white border-b sticky top-0 z-10;
  }
  .btn-primary {
    @apply px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 transition-colors disabled:opacity-50;
  }
  .btn-secondary {
    @apply px-4 py-2 border rounded-md hover:bg-gray-50 focus:ring-2 focus:ring-gray-500 focus:ring-offset-2 transition-colors;
  }
  .input-field {
    @apply w-full px-3 py-2 border rounded-md focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-colors;
  }
  .status-badge {
    @apply px-2 py-0.5 text-xs font-medium rounded-full;
  }
}
TWEOF
            ;;
        css)
            cat <<CSSEOF
/* Generated CSS for ${page_type} page */
.page-container { min-height: 100vh; background: #f9fafb; }
.content-card { background: white; border-radius: 0.5rem; border: 1px solid #e5e7eb; padding: 1.5rem; box-shadow: 0 1px 2px rgba(0,0,0,.05); }
.page-header { display: flex; align-items: center; justify-content: space-between; padding: 1rem; background: white; border-bottom: 1px solid #e5e7eb; }
.btn-primary { padding: 0.5rem 1rem; background: #2563eb; color: white; border-radius: 0.375rem; border: none; cursor: pointer; }
.btn-primary:hover { background: #1d4ed8; }
.btn-secondary { padding: 0.5rem 1rem; border: 1px solid #d1d5db; border-radius: 0.375rem; background: transparent; cursor: pointer; }
.btn-secondary:hover { background: #f9fafb; }
.input-field { width: 100%; padding: 0.5rem 0.75rem; border: 1px solid #d1d5db; border-radius: 0.375rem; }
.input-field:focus { outline: none; ring: 2px solid #2563eb; border-color: #2563eb; }
CSSEOF
            ;;
    esac
    return 0
}

# =============================================================================
# Report / Score
# =============================================================================
_stc_report() {
    echo -e "\n  ${BOLD:-}=== Sketch to Code v${STC_VERSION} ===${NC:-}"
    echo -e "  Wireframes Parsed   : ${STC_PARSE_COUNT}"
    echo -e "  Components Generated: ${STC_COMPONENT_COUNT}"
    echo -e "  Styles Generated    : ${STC_STYLE_COUNT}"
}

_stc_score() {
    local score=30
    [[ "$STC_INITIALIZED" == "true" ]] && score=$((score + 20))
    [[ $STC_PARSE_COUNT -gt 0 ]] && score=$((score + 20))
    [[ $STC_COMPONENT_COUNT -gt 0 ]] && score=$((score + 15))
    [[ $STC_STYLE_COUNT -gt 0 ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "sketch-to-code" \
        --version "405.0" \
        --description "ワイヤーフレームからReactコンポーネント・スタイル自動生成" \
        --init "_stc_init" \
        --report "_stc_report" \
        --score "_stc_score" \
        --enable-var "ENABLE_STC" \
        --cli-flags "--sketch-to-code:--no-sketch-to-code"
fi

# v2003.1: source時のexit codeを確実に0にする
true
