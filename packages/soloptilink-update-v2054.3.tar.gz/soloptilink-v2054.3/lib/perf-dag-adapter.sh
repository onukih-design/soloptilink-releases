#!/usr/bin/env bash
# =============================================================================
# perf-dag-adapter.sh — L6供給 DAG I/F の読み取り消費アダプタ層 (レーン2/性能 専有)
# =============================================================================
# 目的:
#   pe2 (parallel-exec-v2) や性能系コードが DAG_NODES の「形式」に直接依存しない
#   ように、読み取りアクセスを本ファイル1箇所へ集約する。L6 が DAG I/F の形式を
#   変えたら本ファイルだけ追従すればよい (疎結合)。★一方的なI/F拡張は禁止 ──
#   形式変更が必要なら verify-requests 経由で L6 へ申し送る。
#
# 追従中の形式 (v2041):
#   DAG_NODES["<id>"]="<name>|<min>|<deps>|<phase_func>"
#     name : 表示名 / min : 最小到達層 / deps : カンマ区切りの依存ノードID / phase_func : 実行関数
#
# 提供API (全て読み取り専用・DAG_NODES を変更しない):
#   pda_ids                 - 全ノードIDを改行区切りで列挙
#   pda_node_name/min/deps/func <id>
#   pda_resolve_func <id>   - 実呼出可能な関数名へ解決 (func / phase_func)
#   pda_validate_format     - 各エントリが規定フィールド数か (形式drift検出) 0=整合/1=drift
#   pda_validate_dag        - サイクル/到達不能の検出 (Kahn) 0=健全DAG/1=サイクルあり
#   pda_format_signature    - 追従中の形式マーカーを出力 (engineの期待と突合する用)
# =============================================================================

[[ -n "${_PERF_DAG_ADAPTER_LOADED:-}" ]] && return 0
_PERF_DAG_ADAPTER_LOADED=1

declare -g PDA_DAG_FORMAT="v2041:name|min|deps|func"   # 追従中の形式マーカー
declare -g PDA_FIELD_COUNT=4

pda_format_signature() { printf '%s\n' "$PDA_DAG_FORMAT"; }

# 内部: 1ノードを4フィールドへ分解 (区切りが足りなくても安全に空で埋まる)
_pda_split() {
    local id="$1"
    declare -p DAG_NODES &>/dev/null || return 1
    IFS='|' read -r _PDA_NAME _PDA_MIN _PDA_DEPS _PDA_FUNC <<< "${DAG_NODES[$id]:-}"
    return 0
}

pda_node_name() { local _PDA_NAME _PDA_MIN _PDA_DEPS _PDA_FUNC; _pda_split "$1" || return 1; printf '%s' "$_PDA_NAME"; }
pda_node_min()  { local _PDA_NAME _PDA_MIN _PDA_DEPS _PDA_FUNC; _pda_split "$1" || return 1; printf '%s' "$_PDA_MIN"; }
pda_node_deps() { local _PDA_NAME _PDA_MIN _PDA_DEPS _PDA_FUNC; _pda_split "$1" || return 1; printf '%s' "$_PDA_DEPS"; }
pda_node_func() { local _PDA_NAME _PDA_MIN _PDA_DEPS _PDA_FUNC; _pda_split "$1" || return 1; printf '%s' "$_PDA_FUNC"; }

pda_ids() {
    declare -p DAG_NODES &>/dev/null || return 1
    local id; for id in "${!DAG_NODES[@]}"; do printf '%s\n' "$id"; done
}

# func を実呼出可能名へ解決。無ければ非0。
pda_resolve_func() {
    local f; f="$(pda_node_func "$1")" || return 1
    [[ -z "$f" ]] && return 1
    if declare -F "$f" &>/dev/null; then printf '%s' "$f"; return 0; fi
    if declare -F "phase_${f}" &>/dev/null; then printf '%s' "phase_${f}"; return 0; fi
    return 1
}

# 形式整合性: 全エントリが規定フィールド数以上か。0=整合 / 1=drift (L6形式変更の兆候)
pda_validate_format() {
    declare -p DAG_NODES &>/dev/null || return 0   # DAG未宣言=検査対象外
    local id bad=0 nf
    for id in "${!DAG_NODES[@]}"; do
        nf=$(awk -F'|' '{print NF}' <<< "${DAG_NODES[$id]}")
        [[ "$nf" =~ ^[0-9]+$ ]] || nf=0
        (( nf >= PDA_FIELD_COUNT )) || bad=$((bad + 1))
    done
    (( bad == 0 )) && return 0 || return 1
}

# サイクル/到達不能検出 (Kahn のトポロジカルソート・読み取りのみ)。0=健全DAG / 1=サイクルあり
# ★O(V+E): 逆隣接(dependents)を1回だけ構築し、キュー処理時はそのノードの依存先のみ走査する
#   (旧実装は queue 消費毎に全ノードの全depsを再走査=O(V²E)で n=7→243ms の本配線overheadだった/FAL-05)
pda_validate_dag() {
    declare -p DAG_NODES &>/dev/null || return 0
    local -a ids=(); local id
    for id in "${!DAG_NODES[@]}"; do ids+=("$id"); done
    [[ ${#ids[@]} -eq 0 ]] && return 0
    local -A indeg=() present=() dependents=()
    for id in "${ids[@]}"; do present[$id]=1; indeg[$id]=0; done
    # 各ノードの依存を1回だけ解析: in-degree 計算 + 逆隣接(dep→そのdepに依存するノード群)を構築
    for id in "${ids[@]}"; do
        local deps d; deps="$(pda_node_deps "$id")"
        local IFS_BAK="$IFS"; IFS=','
        for d in $deps; do
            d="$(echo "$d" | tr -d '[:space:]')"; [[ -z "$d" ]] && continue
            if [[ -n "${present[$d]:-}" ]]; then
                indeg[$id]=$(( indeg[$id] + 1 ))
                dependents[$d]="${dependents[$d]:-} ${id}"
            fi
        done
        IFS="$IFS_BAK"
    done
    local -a queue=(); local processed=0
    for id in "${ids[@]}"; do (( indeg[$id] == 0 )) && queue+=("$id"); done
    while [[ ${#queue[@]} -gt 0 ]]; do
        local n="${queue[0]}"; queue=("${queue[@]:1}"); processed=$((processed + 1))
        local dep
        for dep in ${dependents[$n]:-}; do
            indeg[$dep]=$(( indeg[$dep] - 1 ))
            (( indeg[$dep] == 0 )) && queue+=("$dep")
        done
    done
    (( processed == ${#ids[@]} )) && return 0 || return 1
}

# 直接実行時の自己テスト (CI/手動確認用・本体には影響しない)
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    echo "perf-dag-adapter selftest"
    echo "format: $(pda_format_signature)"
    declare -gA DAG_NODES=()
    DAG_NODES[a]="A|1||phase_a"
    DAG_NODES[b]="B|1|a|phase_b"
    DAG_NODES[c]="C|1|b|phase_c"
    phase_a() { :; }
    echo "ids: $(pda_ids | tr '\n' ' ')"
    echo "deps(c)=$(pda_node_deps c)  func(b)=$(pda_node_func b)"
    pda_resolve_func a && echo " resolve(a)=ok" || echo " resolve(a)=NG"
    pda_validate_format && echo "format: OK" || echo "format: DRIFT"
    pda_validate_dag && echo "dag(acyclic): OK" || echo "dag: CYCLE"
    DAG_NODES[a]="A|1|c|phase_a"   # a<-c でサイクル化
    pda_validate_dag && echo "cycle-test: (誤)健全判定" || echo "cycle-test: サイクル検出 OK"
    unset DAG_NODES
fi
