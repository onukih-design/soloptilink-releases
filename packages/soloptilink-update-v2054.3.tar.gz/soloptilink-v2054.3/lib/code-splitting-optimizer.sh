#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v245.0 - Code Splitting Optimizer
# =============================================================================
# バンドル構成を分析し、最適なコード分割ポイントを特定。
# dynamic import 文と React.lazy ラッパーを自動生成。
#
# 機能:
#   - バンドル構成分析
#   - 最適コード分割ポイント特定
#   - dynamic import 文生成
#   - React.lazy ラッパー生成
#
# 全globals: CSO_ prefix
# =============================================================================

[[ -n "${_CODE_SPLITTING_OPTIMIZER_LOADED:-}" ]] && return 0
_CODE_SPLITTING_OPTIMIZER_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g CSO_VERSION="245.0"
declare -g CSO_INITIALIZED=false
declare -g CSO_FILES_ANALYZED=0
declare -g CSO_SPLIT_POINTS_FOUND=0
declare -g CSO_DYNAMIC_IMPORTS_GENERATED=0
declare -g CSO_LAZY_COMPONENTS_GENERATED=0
declare -g CSO_PROJECT_DIR=""
declare -g CSO_LOG_PREFIX="[CSO]"

# 重いモジュールの閾値 (KB)
declare -g CSO_HEAVY_THRESHOLD_KB=50

# =============================================================================
# ログユーティリティ
# =============================================================================
_cso_log() { echo -e "  ${CLR_CYAN:-\033[0;36m}${CSO_LOG_PREFIX}${CLR_NC:-\033[0m} $*" >&2; }
_cso_success() { echo -e "  ${CLR_GREEN:-\033[0;32m}${CSO_LOG_PREFIX} OK${CLR_NC:-\033[0m} $*" >&2; }
_cso_warn() { echo -e "  ${CLR_YELLOW:-\033[0;33m}${CSO_LOG_PREFIX} WARN${CLR_NC:-\033[0m} $*" >&2; }
_cso_error() { echo -e "  ${CLR_RED:-\033[0;31m}${CSO_LOG_PREFIX} ERROR${CLR_NC:-\033[0m} $*" >&2; }

# =============================================================================
# 初期化
# =============================================================================
cso_init() {
    CSO_INITIALIZED=true
    CSO_FILES_ANALYZED=0
    CSO_SPLIT_POINTS_FOUND=0
    CSO_DYNAMIC_IMPORTS_GENERATED=0
    CSO_LAZY_COMPONENTS_GENERATED=0
    CSO_PROJECT_DIR="${PROJECT_DIR:-.}"
    return 0
}

# =============================================================================
# バンドル構成分析
# =============================================================================
# ビルド出力と依存関係を分析し、バンドル構成を把握する。
#
# 使い方: _cso_analyze_bundles [project_dir]
# =============================================================================
_cso_analyze_bundles() {
    local project_dir="${1:-${CSO_PROJECT_DIR}}"

    [[ "$CSO_INITIALIZED" != "true" ]] && { _cso_error "未初期化"; return 1; }

    _cso_log "バンドル構成分析開始: ${project_dir}"

    local total_size_kb=0
    local chunk_count=0

    # .next/static/chunks 分析
    local next_chunks="${project_dir}/.next/static/chunks"
    if [[ -d "$next_chunks" ]]; then
        _cso_log "ビルド出力分析中..."
        while IFS= read -r f; do
            local size_bytes
            size_bytes=$(wc -c < "$f" 2>/dev/null || echo 0)
            local size_kb=$(( (size_bytes + 1023) / 1024 ))
            total_size_kb=$((total_size_kb + size_kb))
            chunk_count=$((chunk_count + 1))

            if [[ $size_kb -gt $CSO_HEAVY_THRESHOLD_KB ]]; then
                _cso_warn "重いチャンク: $(basename "$f") = ${size_kb}KB"
            fi
        done < <(find "$next_chunks" -name '*.js' -type f 2>/dev/null)

        _cso_success "チャンク: ${chunk_count}個, 合計: ${total_size_kb}KB"
    fi

    # ソースコードの import 分析
    local import_count=0
    local heavy_imports=()
    local known_heavy=("chart.js" "d3" "three" "monaco-editor" "react-quill" "draft-js"
                       "@mui/material" "antd" "lodash" "moment" "firebase"
                       "recharts" "plotly" "mapbox-gl" "leaflet")

    if [[ -f "${project_dir}/package.json" ]]; then
        for lib in "${known_heavy[@]}"; do
            if grep -q "\"${lib}\"" "${project_dir}/package.json" 2>/dev/null; then
                heavy_imports+=("$lib")
                import_count=$((import_count + 1))
            fi
        done

        if [[ ${#heavy_imports[@]} -gt 0 ]]; then
            _cso_warn "重い依存パッケージ: ${heavy_imports[*]}"
        fi
    fi

    # ページ別の import 重量分析
    local page_count=0
    if [[ -d "${project_dir}/app" ]]; then
        while IFS= read -r -d '' f; do
            page_count=$((page_count + 1))
            local static_heavy=0
            local bn
            bn=$(basename "$(dirname "$f")")/$(basename "$f")

            for lib in "${known_heavy[@]}"; do
                if grep -qP "^import\s.*['\"]${lib}" "$f" 2>/dev/null; then
                    static_heavy=$((static_heavy + 1))
                fi
            done

            if [[ $static_heavy -gt 0 ]]; then
                _cso_warn "${bn}: ${static_heavy}個の重いstatic import"
            fi

            CSO_FILES_ANALYZED=$((CSO_FILES_ANALYZED + 1))
        done < <(find "${project_dir}/app" -name '*.tsx' -type f -not -path '*node_modules*' -print0 2>/dev/null)
    fi

    _cso_success "分析完了: ${page_count}ページ, ${import_count}個の重い依存"
    echo "${import_count}"
    return 0
}

# =============================================================================
# 最適コード分割ポイント特定
# =============================================================================
# ルート境界、条件付きUI、重いコンポーネントを分析し、
# コード分割すべきポイントを特定する。
#
# 使い方: _cso_find_split_points [project_dir]
# =============================================================================
_cso_find_split_points() {
    local project_dir="${1:-${CSO_PROJECT_DIR}}"
    local split_points=0

    [[ "$CSO_INITIALIZED" != "true" ]] && { _cso_error "未初期化"; return 1; }

    _cso_log "コード分割ポイント分析中"

    local files=()
    if [[ -d "$project_dir" ]]; then
        while IFS= read -r -d '' f; do
            files+=("$f")
        done < <(find "$project_dir" -type f \( -name '*.tsx' -o -name '*.jsx' -o -name '*.ts' \) \
            -not -path '*/node_modules/*' -not -path '*/.next/*' -print0 2>/dev/null)
    fi

    for f in "${files[@]}"; do
        local bn
        bn=$(basename "$f")

        # 1. モーダル/ダイアログ（条件付き表示 = lazy loading 候補）
        if grep -qP 'import\s+.*(?:Modal|Dialog|Drawer|Sheet)' "$f" 2>/dev/null; then
            if ! grep -qP '(?:dynamic|lazy|React\.lazy)' "$f" 2>/dev/null; then
                _cso_log "分割候補: ${bn} - モーダル/ダイアログを lazy load に"
                split_points=$((split_points + 1))
            fi
        fi

        # 2. 重いチャート/エディタ/マップコンポーネント
        if grep -qP 'import\s+.*(?:Chart|Editor|Map|Calendar|DataGrid|DataTable|RichText)' "$f" 2>/dev/null; then
            if ! grep -qP '(?:dynamic|lazy|React\.lazy)' "$f" 2>/dev/null; then
                _cso_log "分割候補: ${bn} - 重いコンポーネントを dynamic import に"
                split_points=$((split_points + 1))
            fi
        fi

        # 3. 認証済みのみ表示のコンポーネント
        if grep -qP '(?:isAuthenticated|isLoggedIn|session)\s*(?:&&|\?)' "$f" 2>/dev/null; then
            if grep -qP 'import\s+.*(?:Dashboard|Admin|Settings|Profile)' "$f" 2>/dev/null; then
                if ! grep -qP '(?:dynamic|lazy)' "$f" 2>/dev/null; then
                    _cso_log "分割候補: ${bn} - 認証後コンポーネントを lazy load に"
                    split_points=$((split_points + 1))
                fi
            fi
        fi

        # 4. タブ/アコーディオン内のコンテンツ
        if grep -qP '(?:TabsContent|TabPanel|AccordionContent)' "$f" 2>/dev/null; then
            _cso_log "分割候補: ${bn} - タブコンテンツを lazy load に"
            split_points=$((split_points + 1))
        fi

        # 5. below-the-fold コンテンツ
        if grep -qP 'import\s+.*(?:Footer|Comments|Related|Recommendations)' "$f" 2>/dev/null; then
            if ! grep -qP '(?:dynamic|lazy|Suspense)' "$f" 2>/dev/null; then
                _cso_log "分割候補: ${bn} - below-the-fold コンテンツを lazy load に"
                split_points=$((split_points + 1))
            fi
        fi
    done

    CSO_SPLIT_POINTS_FOUND=$((CSO_SPLIT_POINTS_FOUND + split_points))
    _cso_success "分割ポイント: ${split_points}箇所"
    echo "$split_points"
    return 0
}

# =============================================================================
# Dynamic Import 文生成
# =============================================================================
# Next.js dynamic() を使用した動的インポートコードを生成。
#
# 使い方: _cso_generate_dynamic_imports <output_dir>
# =============================================================================
_cso_generate_dynamic_imports() {
    local output_dir="${1:-${CSO_PROJECT_DIR}/lib}"
    local output_file="${output_dir}/dynamic-imports.ts"

    [[ "$CSO_INITIALIZED" != "true" ]] && { _cso_error "未初期化"; return 1; }

    _cso_log "Dynamic Import ヘルパー生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$output_file" <<'TS_DYNAMIC'
// =============================================================================
// SoloptiLinkAI v245.0 - Dynamic Import Helpers
// Next.js dynamic() による遅延読み込みユーティリティ
// =============================================================================

import dynamic from 'next/dynamic';
import React from 'react';

// --- ローディングスケルトン ---
function LoadingSkeleton({ height = 200 }: { height?: number }) {
  return (
    <div
      className="animate-pulse bg-gray-200 dark:bg-gray-700 rounded-lg"
      style={{ height: `${height}px` }}
      role="status"
      aria-label="読み込み中"
    />
  );
}

// --- エラーフォールバック ---
function ErrorFallback({ error, retry }: { error: Error; retry: () => void }) {
  return (
    <div className="p-4 border border-red-200 rounded-lg bg-red-50 dark:bg-red-900/20">
      <p className="text-red-600 dark:text-red-400 mb-2">
        コンポーネントの読み込みに失敗しました
      </p>
      <button
        onClick={retry}
        className="text-sm px-3 py-1 bg-red-100 hover:bg-red-200 rounded"
      >
        再読み込み
      </button>
    </div>
  );
}

// --- 汎用 dynamic import ファクトリ ---
export function createDynamicComponent<P extends object>(
  importFn: () => Promise<{ default: React.ComponentType<P> }>,
  options: {
    ssr?: boolean;
    loading?: React.ComponentType;
    skeletonHeight?: number;
  } = {}
) {
  const { ssr = false, loading, skeletonHeight = 200 } = options;

  return dynamic(importFn, {
    ssr,
    loading: loading
      ? loading
      : () => <LoadingSkeleton height={skeletonHeight} />,
  });
}

// --- 共通パターン: SSR 無効の重いコンポーネント ---
export function createClientOnlyComponent<P extends object>(
  importFn: () => Promise<{ default: React.ComponentType<P> }>,
  skeletonHeight = 300
) {
  return createDynamicComponent(importFn, { ssr: false, skeletonHeight });
}

// --- 使用例 ---
// const HeavyChart = createClientOnlyComponent(
//   () => import('@/components/HeavyChart'),
//   400
// );
//
// const MarkdownEditor = createDynamicComponent(
//   () => import('@/components/MarkdownEditor'),
//   { ssr: false, skeletonHeight: 500 }
// );
TS_DYNAMIC

    if [[ -f "$output_file" ]]; then
        CSO_DYNAMIC_IMPORTS_GENERATED=$((CSO_DYNAMIC_IMPORTS_GENERATED + 1))
        _cso_success "Dynamic Import ヘルパー生成完了: ${output_file}"
        return 0
    else
        _cso_error "生成失敗"
        return 1
    fi
}

# =============================================================================
# React.lazy ラッパー生成
# =============================================================================
# React.lazy + Suspense によるコンポーネント遅延読み込みラッパーを生成。
#
# 使い方: _cso_generate_lazy_components <output_dir>
# =============================================================================
_cso_generate_lazy_components() {
    local output_dir="${1:-${CSO_PROJECT_DIR}/components}"
    local output_file="${output_dir}/LazyWrapper.tsx"

    [[ "$CSO_INITIALIZED" != "true" ]] && { _cso_error "未初期化"; return 1; }

    _cso_log "React.lazy ラッパー生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$output_file" <<'TSX_LAZY'
// =============================================================================
// SoloptiLinkAI v245.0 - Lazy Loading Wrapper Components
// React.lazy + Suspense + ErrorBoundary
// =============================================================================

'use client';

import React, { Suspense, lazy, ComponentType, useState, useEffect } from 'react';

// --- Error Boundary ---
interface ErrorBoundaryProps {
  fallback?: React.ReactNode;
  children: React.ReactNode;
  onError?: (error: Error) => void;
}

interface ErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

export class LazyErrorBoundary extends React.Component<ErrorBoundaryProps, ErrorBoundaryState> {
  constructor(props: ErrorBoundaryProps) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error: Error): ErrorBoundaryState {
    return { hasError: true, error };
  }

  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    console.error('[LazyWrapper] Component load error:', error, errorInfo);
    this.props.onError?.(error);
  }

  render() {
    if (this.state.hasError) {
      return this.props.fallback || (
        <div className="p-4 border border-red-200 rounded-lg bg-red-50 dark:bg-red-900/20">
          <p className="text-red-600 dark:text-red-400">
            コンポーネントの読み込みに失敗しました
          </p>
          <button
            onClick={() => this.setState({ hasError: false, error: null })}
            className="mt-2 text-sm px-3 py-1 bg-red-100 hover:bg-red-200 rounded"
          >
            再試行
          </button>
        </div>
      );
    }
    return this.props.children;
  }
}

// --- Lazy Wrapper HOC ---
interface LazyWrapperOptions {
  fallback?: React.ReactNode;
  errorFallback?: React.ReactNode;
  minDelay?: number;
  onError?: (error: Error) => void;
}

export function withLazy<P extends object>(
  importFn: () => Promise<{ default: ComponentType<P> }>,
  options: LazyWrapperOptions = {}
): ComponentType<P> {
  const LazyComponent = lazy(importFn);

  const {
    fallback = <DefaultSkeleton />,
    errorFallback,
    onError,
  } = options;

  const WrappedComponent = (props: P) => (
    <LazyErrorBoundary fallback={errorFallback} onError={onError}>
      <Suspense fallback={fallback}>
        <LazyComponent {...props} />
      </Suspense>
    </LazyErrorBoundary>
  );

  WrappedComponent.displayName = `Lazy(${importFn.toString().match(/['"]([^'"]+)['"]/)?.[1] || 'Component'})`;
  return WrappedComponent;
}

// --- デフォルトスケルトン ---
function DefaultSkeleton() {
  return (
    <div className="animate-pulse space-y-3" role="status" aria-label="読み込み中">
      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-3/4" />
      <div className="h-4 bg-gray-200 dark:bg-gray-700 rounded w-1/2" />
      <div className="h-32 bg-gray-200 dark:bg-gray-700 rounded" />
    </div>
  );
}

// --- Intersection Observer Lazy (viewport に入ったら読み込み) ---
export function withViewportLazy<P extends object>(
  importFn: () => Promise<{ default: ComponentType<P> }>,
  options: LazyWrapperOptions & { rootMargin?: string } = {}
): ComponentType<P> {
  const { rootMargin = '200px', ...lazyOptions } = options;

  const ViewportLazyComponent = (props: P) => {
    const [isVisible, setIsVisible] = useState(false);
    const ref = React.useRef<HTMLDivElement>(null);

    useEffect(() => {
      const el = ref.current;
      if (!el) return;

      const observer = new IntersectionObserver(
        ([entry]) => {
          if (entry.isIntersecting) {
            setIsVisible(true);
            observer.disconnect();
          }
        },
        { rootMargin }
      );
      observer.observe(el);
      return () => observer.disconnect();
    }, []);

    if (!isVisible) {
      return (
        <div ref={ref}>
          {lazyOptions.fallback || <DefaultSkeleton />}
        </div>
      );
    }

    const LazyComp = withLazy(importFn, lazyOptions);
    return <LazyComp {...props} />;
  };

  return ViewportLazyComponent;
}
TSX_LAZY

    if [[ -f "$output_file" ]]; then
        CSO_LAZY_COMPONENTS_GENERATED=$((CSO_LAZY_COMPONENTS_GENERATED + 1))
        _cso_success "React.lazy ラッパー生成完了: ${output_file}"
        return 0
    else
        _cso_error "生成失敗"
        return 1
    fi
}

# =============================================================================
# プロンプト注入
# =============================================================================
_cso_inject_prompt() {
    cat <<'PROMPT'
## [CSO] コード分割ルール

### Dynamic Import 必須対象
- チャート/グラフライブラリ（recharts, chart.js, d3）
- リッチテキストエディタ（react-quill, tiptap, draft-js）
- 地図コンポーネント（mapbox-gl, leaflet, google-maps）
- モーダル/ダイアログ内の重いフォーム
- 管理画面の重いデータグリッド

### 実装パターン
- Next.js: next/dynamic + { ssr: false }
- React: React.lazy + Suspense + ErrorBoundary
- Viewport lazy: IntersectionObserver で遅延読み込み

### ローディング状態
- 全 lazy コンポーネントに Suspense fallback 必須
- スケルトンローダー使用（spinner 禁止）
- エラー時のフォールバック UI 必須
PROMPT
}

# =============================================================================
# レポート
# =============================================================================
cso_report() {
    echo -e "\n  ${BOLD:-}--- Code Splitting Optimizer v${CSO_VERSION} ---${NC:-}"
    echo -e "  分析ファイル数    : ${CSO_FILES_ANALYZED}"
    echo -e "  分割ポイント      : ${CSO_SPLIT_POINTS_FOUND}"
    echo -e "  Dynamic Import    : ${CSO_DYNAMIC_IMPORTS_GENERATED}"
    echo -e "  Lazy Component    : ${CSO_LAZY_COMPONENTS_GENERATED}"
}

cso_report_json() {
    cat <<EOF
{"module":"code-splitting-optimizer","version":"${CSO_VERSION}","files_analyzed":${CSO_FILES_ANALYZED},"split_points":${CSO_SPLIT_POINTS_FOUND},"dynamic_imports":${CSO_DYNAMIC_IMPORTS_GENERATED},"lazy_components":${CSO_LAZY_COMPONENTS_GENERATED}}
EOF
}

cso_score() {
    if [[ "$CSO_INITIALIZED" != "true" ]]; then echo 0; return; fi
    local score=70
    [[ $CSO_DYNAMIC_IMPORTS_GENERATED -gt 0 ]] && score=$((score + 15))
    [[ $CSO_LAZY_COMPONENTS_GENERATED -gt 0 ]] && score=$((score + 15))
    echo "$score"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "code-splitting-optimizer" \
        --version "245.0" \
        --description "バンドル分析 + 最適コード分割 + dynamic import 自動生成" \
        --init "cso_init" \
        --report "cso_report" \
        --score "cso_score" \
        --enable-var "ENABLE_CODE_SPLITTING" \
        --cli-flags "--code-split:--no-code-split"
fi

# v2003.1: source時のexit codeを確実に0にする
true
