#!/usr/bin/env bash
# =============================================================================
# verify-distribution-exclude.sh — 配布物 EXCLUDE 検証 (v2027.0)
# =============================================================================
# 配布前パッケージ (dist-staging / zip 展開先 / .releases 配下) に
# 顧客に配ってはならないファイルが混入していないかを機械検証する。
#
# 禁止対象:
#   - 管理者専用: .admin-token / .admin_mode / .license-admin/
#   - 環境秘密: .env / .env.local / .env.*.local / credentials.json
#   - 学習データ: ~/.soloptilink/learning/ (テナントDNA・自動収穫)
#   - 提案レポート: ~/.soloptilink/.proposals/ (社内ナレッジ)
#   - ARTE 攻撃側資産: lib/security/arte/agents/ / payloads/ /
#                     lib/security/arte/v2021/ / v2022/ / v2023/ /
#                     lib/quality-fortresses/{offense,sales-excellence,
#                                            adaptive,cognitive,sovereign,
#                                            continuum,api-key-protection,
#                                            cognitive-empathy,
#                                            tridecafortress}-fortress.sh
#                     ※ 一部 fortress は配布可。下記参照
#   - Cognitive 学習データ: lib/cognitive/data/
#   - SIEM/FTI トークン: tokens.json / credentials.json / .audit.jsonl
#
# 例外 (配布可):
#   - lib/quality-fortresses/security-fortress.sh など採点軸の構造のみ
#
# Subcommands:
#   check <dir>            # 検証 (JSON 出力)
#   list-policy            # 適用ポリシー (default + override) を表示
#   add-rule <pattern>     # ローカルポリシーにパターン追加
#   ci                     # CI 用 exit 0/1 のみ返す
# =============================================================================
set -euo pipefail

readonly POLICY_FILE="${POLICY_FILE:-$HOME/.soloptilink/policies/exclude-list.txt}"
readonly LOCAL_OVERRIDE="${LOCAL_OVERRIDE:-$HOME/.soloptilink/policies/exclude-list.local.txt}"

# Default forbidden patterns (relative to staging dir)
DEFAULT_PATTERNS=(
  '.admin-token'
  '.admin_mode'
  '.license-admin/'
  '.env'
  '.env.local'
  '.env.*.local'
  '.env.production'
  'credentials.json'
  '.aws/credentials'
  '.gcp/credentials.json'
  '.npmrc.private'
  '.netrc'
  '.ssh/id_rsa'
  '.ssh/id_ed25519'
  '.proposals/'
  'learning/sessions.jsonl'
  'learning/distilled_patterns.jsonl'
  'learning/tenants/'
  'lib/cognitive/data/'
  'lib/security/arte/agents/'
  'lib/security/arte/payloads/'
  'lib/security/arte/audit.jsonl'
  'lib/security/arte/audit.log'
  'lib/security/arte/kill.flag'
  'lib/security/arte/kill.log'
  'lib/security/arte/policies/target-allowlist.json'
  'lib/security/arte/v2021/'
  'lib/security/arte/v2022/'
  'lib/security/arte/v2023/'
  'lib/security/arte/v2024/siem-bridge/credentials.json'
  'lib/security/arte/v2024/siem-bridge/tokens.json'
  'lib/security/arte/v2023/fti-hub/tokens.json'
  'lib/security/arte/v2023/saas/tenants/'
  'lib/quality-fortresses/offense-fortress.sh'
  'lib/quality-fortresses/adaptive-fortress.sh'
  'lib/quality-fortresses/cognitive-fortress.sh'
  'lib/quality-fortresses/sovereign-fortress.sh'
  'lib/quality-fortresses/continuum-fortress.sh'
  'lib/quality-fortresses/sales-excellence-fortress.sh'
  'lib/quality-fortresses/cognitive-empathy-fortress.sh'
  'lib/quality-fortresses/api-key-protection-fortress.sh'
  'lib/quality-fortresses/hexafortress.sh'
  'lib/quality-fortresses/septafortress.sh'
  'lib/quality-fortresses/octofortress.sh'
  'lib/quality-fortresses/nonafortress.sh'
  'lib/quality-fortresses/decafortress.sh'
  'lib/quality-fortresses/hendekafortress.sh'
  'lib/quality-fortresses/dodecafortress.sh'
  'lib/quality-fortresses/tridecafortress.sh'
  '.releases/'
  '.git/'
  '.github/workflows/admin-*.yml'
  'agent-scaler.sh'  # フェーズ管理ロジック (社内資産)
  '.soloptilink_salt'
)

load_patterns() {
  local out=()
  for p in "${DEFAULT_PATTERNS[@]}"; do out+=("$p"); done
  if [[ -f "$POLICY_FILE" ]]; then
    while IFS= read -r line; do
      [[ -z "$line" || "$line" =~ ^# ]] && continue
      out+=("$line")
    done <"$POLICY_FILE"
  fi
  if [[ -f "$LOCAL_OVERRIDE" ]]; then
    while IFS= read -r line; do
      [[ -z "$line" || "$line" =~ ^# ]] && continue
      out+=("$line")
    done <"$LOCAL_OVERRIDE"
  fi
  printf '%s\n' "${out[@]}"
}

cmd_list_policy() {
  load_patterns | python3 -c "
import sys, json
patterns = [l.strip() for l in sys.stdin if l.strip()]
print(json.dumps({'pattern_count': len(patterns), 'patterns': patterns}, ensure_ascii=False, indent=2))
"
}

cmd_check() {
  local target="${1:-}"
  if [[ -z "$target" ]]; then
    echo '{"error":"target dir required"}'; exit 2
  fi
  if [[ ! -d "$target" ]]; then
    echo "{\"error\":\"not a directory: $target\"}"; exit 2
  fi
  local patterns
  patterns="$(load_patterns)"
  local hits=()
  while IFS= read -r pat; do
    [[ -z "$pat" ]] && continue
    # find with -path glob — prefix wildcard
    local norm="${pat%/}"
    while IFS= read -r match; do
      [[ -z "$match" ]] && continue
      hits+=("$match")
    done < <(find "$target" \( -name "$(basename "$norm")" -o -path "*/$norm" -o -path "*/$norm/*" \) 2>/dev/null | head -50)
  done <<<"$patterns"

  python3 - "$target" <<PY
import json, sys, os
target = sys.argv[1]
hits_raw = """$(printf '%s\n' "${hits[@]}" 2>/dev/null)"""
hits = sorted(set([h for h in hits_raw.split("\n") if h.strip()]))
verdict = "PASS" if not hits else "FAIL"
out = {
  "version":"v2027.0",
  "target": target,
  "verdict": verdict,
  "blocked_files_count": len(hits),
  "blocked_files": hits[:200],
  "next_step": "FAIL なら blocked_files を全て削除 or .gitignore 化してから再検証"
}
print(json.dumps(out, ensure_ascii=False, indent=2))
PY
}

cmd_ci() {
  local target="${1:-}"
  local r; r="$(cmd_check "$target" 2>/dev/null)"
  if echo "$r" | grep -q '"verdict": "PASS"'; then exit 0
  else
    echo "$r" >&2
    exit 1
  fi
}

cmd_add_rule() {
  local rule="${1:-}"
  [[ -z "$rule" ]] && { echo '{"error":"rule required"}'; exit 2; }
  mkdir -p "$(dirname "$LOCAL_OVERRIDE")"
  echo "$rule" >>"$LOCAL_OVERRIDE"
  echo "{\"added\":\"$rule\",\"file\":\"$LOCAL_OVERRIDE\"}"
}

case "${1:-help}" in
  check)        shift; cmd_check "${1:-}";;
  ci)           shift; cmd_ci "${1:-}";;
  list-policy)  cmd_list_policy;;
  add-rule)     shift; cmd_add_rule "${1:-}";;
  *) cat <<USG
verify-distribution-exclude.sh v2027.0
Usage:
  $0 check <dist_dir>      # 配布物検証 (JSON)
  $0 ci    <dist_dir>      # CI 用 exit 0/1
  $0 list-policy           # 適用ポリシー一覧
  $0 add-rule "<pattern>"  # ローカル override 追加

Policy files:
  $POLICY_FILE
  $LOCAL_OVERRIDE
USG
  exit 0;;
esac
