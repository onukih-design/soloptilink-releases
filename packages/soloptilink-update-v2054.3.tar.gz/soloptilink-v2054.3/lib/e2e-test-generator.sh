#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v338.0 - E2E Test Generator
# =============================================================================
# Playwrightベースのエンドツーエンドテスト自動生成。
# ページシナリオ、セレクタ戦略、テストデータ管理。
#
# Functions:
#   _etg_init()                  - Initialize
#   _etg_generate_playwright()   - Generate Playwright config & tests
#   _etg_generate_scenarios()    - Generate user journey scenarios
#   _etg_generate_selectors()    - Generate robust selectors
#   _etg_report() / _etg_score()
# =============================================================================

[[ -n "${_ETG_LOADED:-}" ]] && return 0; _ETG_LOADED=1

readonly _ETG_RED='\033[0;31m'
readonly _ETG_GREEN='\033[0;32m'
readonly _ETG_YELLOW='\033[0;33m'
readonly _ETG_CYAN='\033[0;36m'
readonly _ETG_NC='\033[0m'

declare -g ETG_VERSION="338.0"
ETG_GENERATED=0; ETG_ERRORS=0; ETG_FILES_WRITTEN=0
ETG_PLAYWRIGHT_OK=false; ETG_SCENARIOS_OK=false; ETG_SELECTORS_OK=false

_etg_init() {
    ETG_GENERATED=0; ETG_ERRORS=0; ETG_FILES_WRITTEN=0
    ETG_PLAYWRIGHT_OK=false; ETG_SCENARIOS_OK=false; ETG_SELECTORS_OK=false
    echo -e "  ${_ETG_GREEN}OK${_ETG_NC} E2E Test Generator v${ETG_VERSION}" >&2
    return 0
}

_etg_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { ETG_FILES_WRITTEN=$((ETG_FILES_WRITTEN + 1)); return 0; }
    ETG_ERRORS=$((ETG_ERRORS + 1)); return 1
}

_etg_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_ETG_CYAN}[e2e]${_ETG_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_ETG_GREEN}[e2e]${_ETG_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_ETG_YELLOW}[e2e]${_ETG_NC} $msg" >&2 ;;
        error) echo -e "  ${_ETG_RED}[e2e]${_ETG_NC} $msg" >&2 ;;
    esac
}

_etg_generate_playwright() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _etg_log info "Generating Playwright config..."

    _etg_write_file "${project_dir}/playwright.config.ts" "$(cat <<'TYPESCRIPT'
import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './e2e',
  fullyParallel: true,
  forbidOnly: !!process.env.CI,
  retries: process.env.CI ? 2 : 0,
  workers: process.env.CI ? 1 : undefined,
  reporter: [['html'], ['json', { outputFile: 'e2e-results.json' }]],
  use: {
    baseURL: process.env.BASE_URL || 'http://localhost:3000',
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
  },
  projects: [
    { name: 'chromium', use: { ...devices['Desktop Chrome'] } },
    { name: 'firefox', use: { ...devices['Desktop Firefox'] } },
    { name: 'mobile', use: { ...devices['iPhone 14'] } },
  ],
  webServer: {
    command: 'npm run dev',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
    timeout: 120000,
  },
});
TYPESCRIPT
)"

    _etg_write_file "${project_dir}/e2e/auth.spec.ts" "$(cat <<'TYPESCRIPT'
import { test, expect } from '@playwright/test';

test.describe('Authentication Flow', () => {
  test('should login with valid credentials', async ({ page }) => {
    await page.goto('/login');
    await page.getByLabel('Email').fill('admin@example.com');
    await page.getByLabel('Password').fill('password123');
    await page.getByRole('button', { name: /login|sign in/i }).click();
    await expect(page).toHaveURL(/dashboard|home|\//);
    await expect(page.getByText(/welcome|dashboard/i)).toBeVisible();
  });

  test('should show error on invalid login', async ({ page }) => {
    await page.goto('/login');
    await page.getByLabel('Email').fill('wrong@example.com');
    await page.getByLabel('Password').fill('wrong');
    await page.getByRole('button', { name: /login|sign in/i }).click();
    await expect(page.getByText(/invalid|error|incorrect/i)).toBeVisible();
  });

  test('should redirect unauthenticated users to login', async ({ page }) => {
    await page.goto('/dashboard');
    await expect(page).toHaveURL(/login/);
  });

  test('should logout successfully', async ({ page }) => {
    // Login first
    await page.goto('/login');
    await page.getByLabel('Email').fill('admin@example.com');
    await page.getByLabel('Password').fill('password123');
    await page.getByRole('button', { name: /login|sign in/i }).click();
    await expect(page).toHaveURL(/dashboard|home/);
    // Logout
    await page.getByRole('button', { name: /logout|sign out/i }).click();
    await expect(page).toHaveURL(/login/);
  });
});
TYPESCRIPT
)"

    _etg_log ok "Playwright config & auth tests generated"
    ETG_PLAYWRIGHT_OK=true
    ETG_GENERATED=$((ETG_GENERATED + 1))
    return 0
}

_etg_generate_scenarios() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _etg_log info "Generating E2E scenarios..."

    # Scan pages
    local pages
    pages=$(find "$project_dir" -path "*/app/*/page.tsx" -not -path "*/node_modules/*" 2>/dev/null | head -20)

    _etg_write_file "${project_dir}/e2e/crud.spec.ts" "$(cat <<'TYPESCRIPT'
import { test, expect } from '@playwright/test';
import { login } from './helpers/auth';

test.describe('CRUD Operations', () => {
  test.beforeEach(async ({ page }) => {
    await login(page);
  });

  test('should create a new item', async ({ page }) => {
    await page.getByRole('link', { name: /new|create|add/i }).click();
    await page.getByLabel(/name|title/i).fill('Test Item');
    await page.getByRole('button', { name: /save|create|submit/i }).click();
    await expect(page.getByText('Test Item')).toBeVisible();
  });

  test('should edit an existing item', async ({ page }) => {
    await page.getByText('Test Item').click();
    await page.getByRole('link', { name: /edit/i }).click();
    await page.getByLabel(/name|title/i).clear();
    await page.getByLabel(/name|title/i).fill('Updated Item');
    await page.getByRole('button', { name: /save|update/i }).click();
    await expect(page.getByText('Updated Item')).toBeVisible();
  });

  test('should delete an item with confirmation', async ({ page }) => {
    await page.getByText('Updated Item').click();
    page.on('dialog', dialog => dialog.accept());
    await page.getByRole('button', { name: /delete|remove/i }).click();
    await expect(page.getByText('Updated Item')).not.toBeVisible();
  });
});
TYPESCRIPT
)"

    _etg_write_file "${project_dir}/e2e/helpers/auth.ts" "$(cat <<'TYPESCRIPT'
import { Page } from '@playwright/test';

export async function login(page: Page, email = 'admin@example.com', password = 'password123') {
  await page.goto('/login');
  await page.getByLabel('Email').fill(email);
  await page.getByLabel('Password').fill(password);
  await page.getByRole('button', { name: /login|sign in/i }).click();
  await page.waitForURL(/dashboard|home|\//);
}
TYPESCRIPT
)"

    _etg_log ok "E2E scenarios generated"
    ETG_SCENARIOS_OK=true
    ETG_GENERATED=$((ETG_GENERATED + 1))
    return 0
}

_etg_generate_selectors() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _etg_log info "Analyzing selectors..."

    # Check for data-testid usage
    local testid_count
    testid_count=$(grep -r "data-testid" "$project_dir/src" --include="*.tsx" --include="*.jsx" 2>/dev/null | \
        grep -v node_modules | wc -l | tr -d ' ')

    if [[ $testid_count -lt 5 ]]; then
        _etg_log warn "Low data-testid coverage (${testid_count}). Add data-testid to interactive elements."
    else
        _etg_log ok "Found ${testid_count} data-testid attributes"
    fi

    _etg_write_file "${project_dir}/e2e/helpers/selectors.ts" "$(cat <<'TYPESCRIPT'
// Selector strategies - prefer role > testid > text > css
export const selectors = {
  nav: {
    home: '[data-testid="nav-home"], a[href="/"]',
    dashboard: '[data-testid="nav-dashboard"], a[href="/dashboard"]',
    settings: '[data-testid="nav-settings"], a[href="/settings"]',
  },
  auth: {
    emailInput: 'input[name="email"], [data-testid="email-input"]',
    passwordInput: 'input[name="password"], [data-testid="password-input"]',
    submitButton: 'button[type="submit"], [data-testid="login-button"]',
  },
  common: {
    loadingSpinner: '[data-testid="loading"], .loading',
    errorMessage: '[role="alert"], [data-testid="error"]',
    successMessage: '[data-testid="success"], .toast-success',
  },
};
TYPESCRIPT
)"

    ETG_SELECTORS_OK=true
    ETG_GENERATED=$((ETG_GENERATED + 1))
    return 0
}

_etg_report() {
    echo -e "\n  ${_ETG_CYAN}=== E2E Test Generator v${ETG_VERSION} ===${_ETG_NC}"
    echo -e "  Generated: ${ETG_GENERATED} | Files: ${ETG_FILES_WRITTEN} | Errors: ${ETG_ERRORS}"
    echo -e "  Playwright: $( ${ETG_PLAYWRIGHT_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Scenarios: $( ${ETG_SCENARIOS_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Selectors: $( ${ETG_SELECTORS_OK} && echo 'OK' || echo 'SKIP')"
}

_etg_score() {
    local score=50
    ${ETG_PLAYWRIGHT_OK} && score=$((score + 20))
    ${ETG_SCENARIOS_OK} && score=$((score + 15))
    ${ETG_SELECTORS_OK} && score=$((score + 10))
    [[ ${ETG_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "e2e-test-generator" --version "338.0" \
        --description "E2Eテスト自動生成 Playwright/シナリオ/セレクタ (v338)" \
        --init "_etg_init" --report "_etg_report" --score "_etg_score" \
        --enable-var "ENABLE_E2E_TEST_GEN" --cli-flags "--e2e-test-gen:--no-e2e-test-gen"
fi

# v2003.1: source時のexit codeを確実に0にする
true
