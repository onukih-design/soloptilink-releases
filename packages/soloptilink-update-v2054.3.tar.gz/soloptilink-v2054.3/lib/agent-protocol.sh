#!/usr/bin/env bash
# ============================================================
# SoloptiLink Chain v13.0 - Agent Communication Protocol
# ============================================================
# File-based inter-agent communication protocol. Agents exchange
# messages through a shared directory structure, enabling
# asynchronous coordination without shared memory.
#
# Functions:
#   ap_init              - Initialize protocol message directory
#   ap_send_message      - Send a message from one agent to another
#   ap_read_messages     - Read all pending messages for an agent
#   ap_create_shared_state - Write a shared state key-value pair
#   ap_read_shared_state - Read a shared state value by key
#   ap_broadcast         - Send a message to all registered agents
#
# All globals use the AP_ prefix.
# Sourced by the main orchestrator -- do NOT use set -euo pipefail.
# ============================================================

###############################################################
# Global state
###############################################################

AP_GREEN='\033[0;32m';  AP_RED='\033[0;31m';    AP_YELLOW='\033[1;33m'
AP_CYAN='\033[0;36m';   AP_BLUE='\033[0;34m';   AP_MAGENTA='\033[0;35m'
AP_BOLD='\033[1m';      AP_DIM='\033[2m';        AP_RESET='\033[0m'

declare -g    AP_SESSION_DIR=""
declare -g    AP_MSG_DIR=""
declare -g    AP_STATE_DIR=""
declare -g    AP_MSG_COUNTER=0
declare -g -a AP_KNOWN_AGENTS=()

###############################################################
# Helpers
###############################################################

_ap_log() {
    local level="$1" message="$2"
    local color="${AP_RESET}"
    case "$level" in
        INFO)    color="${AP_CYAN}"    ;;
        SUCCESS) color="${AP_GREEN}"   ;;
        WARN)    color="${AP_YELLOW}"  ;;
        ERROR)   color="${AP_RED}"     ;;
        MSG)     color="${AP_MAGENTA}" ;;
    esac
    echo -e "  ${color}[AP:${level}]${AP_RESET} ${message}"
    if [[ -n "$AP_MSG_DIR" ]]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [${level}] ${message}" \
            >> "${AP_SESSION_DIR}/agent-protocol.log" 2>/dev/null || true
    fi
}

###############################################################
# ap_init(session_dir)
#   Initialize the protocol message directories.
#   session_dir: Base directory for this session (typically
#                SESSION_LOG_DIR or a temp dir).
###############################################################
ap_init() {
    local session_dir="${1:-}"

    if [[ -z "$session_dir" ]]; then
        if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
            session_dir="${SESSION_LOG_DIR}"
        else
            session_dir="/tmp/soloptilink-protocol-$(date +%Y%m%d-%H%M%S)"
        fi
    fi

    AP_SESSION_DIR="$session_dir"
    AP_MSG_DIR="${AP_SESSION_DIR}/agent-messages"
    AP_STATE_DIR="${AP_SESSION_DIR}/agent-state"
    AP_MSG_COUNTER=0
    AP_KNOWN_AGENTS=()

    mkdir -p "$AP_MSG_DIR" "$AP_STATE_DIR"

    _ap_log "INFO" "Agent Protocol initialized  msg_dir=${AP_MSG_DIR}"
    return 0
}

###############################################################
# ap_send_message(from_agent, to_agent, message_type, payload)
#   Send a message from one agent to another.
#   message_type: e.g. "request", "response", "review", "error", "info"
#   payload: The message body (text).
#   Messages are stored as files in: AP_MSG_DIR/to_agent/
###############################################################
ap_send_message() {
    local from_agent="$1" to_agent="$2" message_type="$3" payload="$4"

    if [[ -z "$from_agent" || -z "$to_agent" || -z "$message_type" ]]; then
        _ap_log "ERROR" "ap_send_message: from_agent, to_agent, and message_type are required"
        return 1
    fi

    # Ensure target inbox exists
    local inbox_dir="${AP_MSG_DIR}/${to_agent}"
    mkdir -p "$inbox_dir"

    AP_MSG_COUNTER=$((AP_MSG_COUNTER + 1))
    local timestamp
    timestamp=$(date '+%Y%m%d-%H%M%S')
    local msg_id="${AP_MSG_COUNTER}-${timestamp}"
    local msg_file="${inbox_dir}/${msg_id}.msg"

    # Write message as structured text
    {
        echo "MESSAGE_ID=${msg_id}"
        echo "FROM=${from_agent}"
        echo "TO=${to_agent}"
        echo "TYPE=${message_type}"
        echo "TIMESTAMP=$(date '+%Y-%m-%d %H:%M:%S')"
        echo "STATUS=unread"
        echo "---"
        echo "${payload}"
    } > "$msg_file"

    _ap_log "MSG" "${from_agent} -> ${to_agent}  type=${message_type}  id=${msg_id}"

    # Track known agents
    local found=0
    for a in "${AP_KNOWN_AGENTS[@]}"; do
        [[ "$a" == "$to_agent" ]] && found=1 && break
    done
    [[ $found -eq 0 ]] && AP_KNOWN_AGENTS+=("$to_agent")
    found=0
    for a in "${AP_KNOWN_AGENTS[@]}"; do
        [[ "$a" == "$from_agent" ]] && found=1 && break
    done
    [[ $found -eq 0 ]] && AP_KNOWN_AGENTS+=("$from_agent")

    return 0
}

###############################################################
# ap_read_messages(agent_id)
#   Read all pending (unread) messages for a given agent.
#   Prints messages to stdout. Marks them as read.
#   Returns 0 if messages found, 1 if no messages.
###############################################################
ap_read_messages() {
    local agent_id="$1"
    local inbox_dir="${AP_MSG_DIR}/${agent_id}"

    if [[ ! -d "$inbox_dir" ]]; then
        _ap_log "INFO" "No inbox for agent: ${agent_id}"
        return 1
    fi

    local msg_files=()
    while IFS= read -r -d '' f; do
        msg_files+=("$f")
    done < <(find "$inbox_dir" -name '*.msg' -print0 2>/dev/null | sort -z)

    if [[ ${#msg_files[@]} -eq 0 ]]; then
        _ap_log "INFO" "No messages for agent: ${agent_id}"
        return 1
    fi

    local count=0
    for msg_file in "${msg_files[@]}"; do
        # Check if unread
        if grep -q "STATUS=unread" "$msg_file" 2>/dev/null; then
            echo "=== Message: $(basename "$msg_file" .msg) ==="
            cat "$msg_file"
            echo ""

            # Mark as read (use sed portably)
            if [[ "$(uname)" == "Darwin" ]]; then
                sed -i '' 's/STATUS=unread/STATUS=read/' "$msg_file" 2>/dev/null || true
            else
                sed -i 's/STATUS=unread/STATUS=read/' "$msg_file" 2>/dev/null || true
            fi

            count=$((count + 1))
        fi
    done

    _ap_log "INFO" "Agent ${agent_id} read ${count} message(s)"
    [[ $count -gt 0 ]] && return 0 || return 1
}

###############################################################
# ap_create_shared_state(key, value)
#   Write a shared state key-value pair.
#   Any agent can read or overwrite these values.
###############################################################
ap_create_shared_state() {
    local key="$1" value="$2"

    if [[ -z "$key" ]]; then
        _ap_log "ERROR" "ap_create_shared_state: key is required"
        return 1
    fi

    # Sanitize key for filename (replace non-alnum with underscore)
    local safe_key
    safe_key=$(echo "$key" | tr -c '[:alnum:]-_' '_')

    local state_file="${AP_STATE_DIR}/${safe_key}.state"

    {
        echo "KEY=${key}"
        echo "UPDATED=$(date '+%Y-%m-%d %H:%M:%S')"
        echo "---"
        echo "${value}"
    } > "$state_file"

    _ap_log "INFO" "Shared state set: ${key}"
    return 0
}

###############################################################
# ap_read_shared_state(key)
#   Read a shared state value by key.
#   Prints the value to stdout.
#   Returns 0 if found, 1 if not found.
###############################################################
ap_read_shared_state() {
    local key="$1"

    local safe_key
    safe_key=$(echo "$key" | tr -c '[:alnum:]-_' '_')
    local state_file="${AP_STATE_DIR}/${safe_key}.state"

    if [[ ! -f "$state_file" ]]; then
        _ap_log "WARN" "Shared state not found: ${key}"
        return 1
    fi

    # Extract value (everything after the --- separator)
    local in_body=0
    while IFS= read -r line; do
        if [[ $in_body -eq 1 ]]; then
            echo "$line"
        elif [[ "$line" == "---" ]]; then
            in_body=1
        fi
    done < "$state_file"

    return 0
}

###############################################################
# ap_broadcast(from_agent, message)
#   Send a message to all known agents.
###############################################################
ap_broadcast() {
    local from_agent="$1" message="$2"

    if [[ -z "$from_agent" || -z "$message" ]]; then
        _ap_log "ERROR" "ap_broadcast: from_agent and message are required"
        return 1
    fi

    _ap_log "MSG" "${from_agent} broadcasting to ${#AP_KNOWN_AGENTS[@]} agent(s)"

    local sent=0
    for agent_id in "${AP_KNOWN_AGENTS[@]}"; do
        # Don't send to self
        [[ "$agent_id" == "$from_agent" ]] && continue
        ap_send_message "$from_agent" "$agent_id" "broadcast" "$message"
        sent=$((sent + 1))
    done

    _ap_log "INFO" "Broadcast sent to ${sent} agent(s)"
    return 0
}
