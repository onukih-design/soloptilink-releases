#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v476.0 - Multi-Agent Orchestration Engine
# =============================================================================
# 複数の専門エージェントを定義・タスク割当・協調制御し、
# 並列実行結果を統合する群知能オーケストレーションエンジン。
# エージェント間の通信プロトコル、コンフリクト解決、結果マージを管理。
#
# Functions:
#   _mao_init               - 初期化
#   _mao_define_agents      - エージェント定義・登録
#   _mao_assign_tasks       - タスクのエージェント割当
#   _mao_coordinate         - エージェント間協調制御
#   _mao_merge_results      - 複数結果の統合
#   _mao_resolve_conflicts  - コンフリクト解決
#   _mao_report             - レポート出力
#   _mao_score              - モジュールスコア(0-100)
#
# Globals: MAO_ prefix
# =============================================================================

[[ -n "${_MULTI_AGENT_ORCHESTRATION_LOADED:-}" ]] && return 0
_MULTI_AGENT_ORCHESTRATION_LOADED=1

MAO_VERSION="476.0"
MAO_INITIALIZED=false

# --- Storage ---
MAO_DATA_DIR=""
MAO_AGENT_LOG=""
MAO_TASK_LOG=""
MAO_MERGE_LOG=""

# --- State ---
MAO_TOTAL_AGENTS=0
MAO_ACTIVE_AGENTS=0
MAO_TOTAL_TASKS_ASSIGNED=0
MAO_TOTAL_MERGES=0
MAO_CONFLICTS_RESOLVED=0

# --- Agent Registry ---
declare -g -A _MAO_AGENTS=()
declare -g -A _MAO_AGENT_ROLE=()
declare -g -A _MAO_AGENT_STATUS=()
declare -g -A _MAO_AGENT_CAPABILITIES=()
declare -g -A _MAO_AGENT_WORKLOAD=()
declare -g -A _MAO_TASK_ASSIGNMENTS=()
declare -g -a _MAO_TASK_QUEUE=()
declare -g -a _MAO_RESULTS=()
declare -g -A _MAO_CONFLICT_LOG=()

# Predefined agent roles
declare -g -A _MAO_ROLE_TEMPLATES=(
    ["architect"]="設計判断・アーキテクチャレビュー・技術選定"
    ["frontend"]="UIコンポーネント・ページ実装・スタイリング"
    ["backend"]="APIルート・ビジネスロジック・データベース操作"
    ["security"]="脆弱性検出・認証実装・入力バリデーション"
    ["testing"]="テスト作成・カバレッジ分析・品質検証"
    ["devops"]="CI/CD・デプロイメント・インフラ設定"
    ["reviewer"]="コードレビュー・品質評価・改善提案"
    ["debugger"]="バグ検出・根本原因分析・修正適用"
    ["optimizer"]="パフォーマンス最適化・バンドルサイズ削減"
    ["documenter"]="ドキュメント生成・API仕様書・README"
)

# =============================================================================
# 初期化
# =============================================================================
_mao_init() {
    local project_dir="${PROJECT_DIR:-.}"
    MAO_DATA_DIR="${project_dir}/.soloptilink/mao"
    MAO_AGENT_LOG="${MAO_DATA_DIR}/agents.jsonl"
    MAO_TASK_LOG="${MAO_DATA_DIR}/tasks.jsonl"
    MAO_MERGE_LOG="${MAO_DATA_DIR}/merges.jsonl"

    mkdir -p "$MAO_DATA_DIR"

    # デフォルトエージェントの登録
    _mao_define_agents "default"

    MAO_INITIALIZED=true
    return 0
}

# =============================================================================
# エージェント定義・登録
# =============================================================================
_mao_define_agents() {
    local preset="${1:-default}"

    case "$preset" in
        default)
            _mao_register_agent "architect" "architect" "active"
            _mao_register_agent "frontend-dev" "frontend" "active"
            _mao_register_agent "backend-dev" "backend" "active"
            _mao_register_agent "security-auditor" "security" "standby"
            _mao_register_agent "test-engineer" "testing" "active"
            _mao_register_agent "code-reviewer" "reviewer" "standby"
            ;;
        full)
            for role in "${!_MAO_ROLE_TEMPLATES[@]}"; do
                _mao_register_agent "${role}-agent" "$role" "active"
            done
            ;;
        minimal)
            _mao_register_agent "fullstack" "frontend" "active"
            _mao_register_agent "qa" "testing" "active"
            ;;
    esac

    return 0
}

_mao_register_agent() {
    local agent_id="$1"
    local role="$2"
    local status="${3:-standby}"

    _MAO_AGENTS["$agent_id"]="$role"
    _MAO_AGENT_ROLE["$agent_id"]="$role"
    _MAO_AGENT_STATUS["$agent_id"]="$status"
    _MAO_AGENT_CAPABILITIES["$agent_id"]="${_MAO_ROLE_TEMPLATES[$role]:-general}"
    _MAO_AGENT_WORKLOAD["$agent_id"]=0

    MAO_TOTAL_AGENTS=$((MAO_TOTAL_AGENTS + 1))
    [[ "$status" == "active" ]] && MAO_ACTIVE_AGENTS=$((MAO_ACTIVE_AGENTS + 1))

    return 0
}

# =============================================================================
# タスクのエージェント割当
# =============================================================================
_mao_assign_tasks() {
    local tasks_json="$1"

    [[ "$MAO_INITIALIZED" != "true" ]] && _mao_init

    # タスクの種類に基づいてエージェントを自動選択
    while IFS= read -r task; do
        [[ -z "$task" ]] && continue

        local task_type=""
        local assigned_agent=""

        # タスクタイプの判定
        case "$task" in
            *schema*|*model*|*prisma*|*database*)
                task_type="backend" ;;
            *api*|*route*|*endpoint*|*controller*)
                task_type="backend" ;;
            *page*|*component*|*ui*|*layout*|*style*)
                task_type="frontend" ;;
            *test*|*spec*|*coverage*)
                task_type="testing" ;;
            *security*|*auth*|*permission*|*validate*)
                task_type="security" ;;
            *deploy*|*ci*|*docker*|*infra*)
                task_type="devops" ;;
            *design*|*architecture*|*tech*stack*)
                task_type="architect" ;;
            *review*|*quality*)
                task_type="reviewer" ;;
            *bug*|*fix*|*debug*)
                task_type="debugger" ;;
            *perf*|*optimize*|*bundle*)
                task_type="optimizer" ;;
            *)
                task_type="frontend" ;;  # デフォルト
        esac

        # 該当ロールのエージェントを検索（ワークロード最小を選択）
        local min_workload=999
        for agent_id in "${!_MAO_AGENTS[@]}"; do
            local role="${_MAO_AGENT_ROLE[$agent_id]}"
            local status="${_MAO_AGENT_STATUS[$agent_id]}"
            local workload="${_MAO_AGENT_WORKLOAD[$agent_id]:-0}"

            if [[ "$role" == "$task_type" && "$status" == "active" && $workload -lt $min_workload ]]; then
                min_workload=$workload
                assigned_agent="$agent_id"
            fi
        done

        # アクティブなエージェントがなければスタンバイから起動
        if [[ -z "$assigned_agent" ]]; then
            for agent_id in "${!_MAO_AGENTS[@]}"; do
                local role="${_MAO_AGENT_ROLE[$agent_id]}"
                if [[ "$role" == "$task_type" ]]; then
                    _MAO_AGENT_STATUS["$agent_id"]="active"
                    assigned_agent="$agent_id"
                    MAO_ACTIVE_AGENTS=$((MAO_ACTIVE_AGENTS + 1))
                    break
                fi
            done
        fi

        # それでもなければ最もワークロードの少ないアクティブエージェントに割当
        if [[ -z "$assigned_agent" ]]; then
            min_workload=999
            for agent_id in "${!_MAO_AGENTS[@]}"; do
                local status="${_MAO_AGENT_STATUS[$agent_id]}"
                local workload="${_MAO_AGENT_WORKLOAD[$agent_id]:-0}"
                if [[ "$status" == "active" && $workload -lt $min_workload ]]; then
                    min_workload=$workload
                    assigned_agent="$agent_id"
                fi
            done
        fi

        if [[ -n "$assigned_agent" ]]; then
            _MAO_TASK_ASSIGNMENTS["$task"]="$assigned_agent"
            _MAO_AGENT_WORKLOAD["$assigned_agent"]=$(( ${_MAO_AGENT_WORKLOAD[$assigned_agent]:-0} + 1 ))
            MAO_TOTAL_TASKS_ASSIGNED=$((MAO_TOTAL_TASKS_ASSIGNED + 1))

            local timestamp
            timestamp=$(date +%s)
            echo "{\"ts\":${timestamp},\"task\":\"${task}\",\"agent\":\"${assigned_agent}\",\"type\":\"${task_type}\"}" >> "$MAO_TASK_LOG" 2>/dev/null
        fi
    done <<< "$tasks_json"

    return 0
}

# =============================================================================
# エージェント間協調制御
# =============================================================================
_mao_coordinate() {
    local coordination_type="${1:-sequential}"

    [[ "$MAO_INITIALIZED" != "true" ]] && _mao_init

    case "$coordination_type" in
        sequential)
            # 依存順に1つずつ実行
            echo "[MAO] Sequential coordination: ${MAO_TOTAL_TASKS_ASSIGNED} tasks" >&2
            ;;
        parallel)
            # 独立タスクを並列実行
            echo "[MAO] Parallel coordination: ${MAO_ACTIVE_AGENTS} agents" >&2
            ;;
        pipeline)
            # パイプライン実行（architect→backend→frontend→testing）
            echo "[MAO] Pipeline coordination: architect->backend->frontend->testing" >&2
            ;;
        swarm)
            # 群知能モード（全エージェントが投票で最適解を決定）
            echo "[MAO] Swarm coordination: ${MAO_TOTAL_AGENTS} agents voting" >&2
            ;;
    esac

    return 0
}

# =============================================================================
# 複数結果の統合
# =============================================================================
_mao_merge_results() {
    local output_dir="$1"
    shift
    local result_files=("$@")

    [[ "$MAO_INITIALIZED" != "true" ]] && _mao_init

    mkdir -p "$output_dir"

    local merged_count=0
    local conflict_count=0

    for file in "${result_files[@]}"; do
        [[ ! -f "$file" ]] && continue

        local basename
        basename=$(basename "$file")
        local target="${output_dir}/${basename}"

        if [[ -f "$target" ]]; then
            # コンフリクト検出
            if ! diff -q "$file" "$target" &>/dev/null; then
                _mao_resolve_conflicts "$target" "$file"
                conflict_count=$((conflict_count + 1))
            fi
        else
            cp "$file" "$target" 2>/dev/null
        fi

        merged_count=$((merged_count + 1))
    done

    MAO_TOTAL_MERGES=$((MAO_TOTAL_MERGES + 1))

    local timestamp
    timestamp=$(date +%s)
    echo "{\"ts\":${timestamp},\"merged\":${merged_count},\"conflicts\":${conflict_count}}" >> "$MAO_MERGE_LOG" 2>/dev/null

    echo "${merged_count}:${conflict_count}"
    return 0
}

# =============================================================================
# コンフリクト解決
# =============================================================================
_mao_resolve_conflicts() {
    local file_a="$1"
    local file_b="$2"

    # 戦略: より行数の多い（包括的な）方を採用
    local lines_a lines_b
    lines_a=$(wc -l < "$file_a" 2>/dev/null || echo "0")
    lines_b=$(wc -l < "$file_b" 2>/dev/null || echo "0")

    if [[ $lines_b -gt $lines_a ]]; then
        cp "$file_b" "$file_a" 2>/dev/null
    fi

    MAO_CONFLICTS_RESOLVED=$((MAO_CONFLICTS_RESOLVED + 1))
    _MAO_CONFLICT_LOG["$(date +%s)"]="${file_a}:${file_b}"

    return 0
}

# =============================================================================
# レポート
# =============================================================================
_mao_report() {
    echo -e "\n  ${BOLD:-}═══ Multi-Agent Orchestration v${MAO_VERSION} ═══${NC:-}"
    echo -e "  総エージェント数   : ${MAO_TOTAL_AGENTS}"
    echo -e "  アクティブ         : ${MAO_ACTIVE_AGENTS}"
    echo -e "  割当タスク数       : ${MAO_TOTAL_TASKS_ASSIGNED}"
    echo -e "  マージ回数         : ${MAO_TOTAL_MERGES}"
    echo -e "  コンフリクト解決   : ${MAO_CONFLICTS_RESOLVED}"
}

_mao_score() {
    [[ "$MAO_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    local s=50
    [[ $MAO_ACTIVE_AGENTS -gt 2 ]] && s=$((s + 15))
    [[ $MAO_TOTAL_TASKS_ASSIGNED -gt 0 ]] && s=$((s + 15))
    [[ $MAO_TOTAL_MERGES -gt 0 ]] && s=$((s + 10))
    [[ $MAO_CONFLICTS_RESOLVED -ge 0 ]] && s=$((s + 10))
    [[ $s -gt 100 ]] && s=100
    echo "$s"
}

_mao_init_message() {
    echo -e "  ${GREEN:-}✅ v${MAO_VERSION} multi-agent-orchestration: 群知能オーケストレーション (${MAO_TOTAL_AGENTS} agents)${NC:-}" >&2
}

# =============================================================================
# Module Registry 登録
# =============================================================================
_mr_register \
    --name "multi-agent-orchestration" \
    --version "$MAO_VERSION" \
    --description "群知能オーケストレーション" \
    --init "_mao_init" \
    --report "_mao_report" \
    --score "_mao_score" \
    --enable-var "ENABLE_MULTI_AGENT_ORCHESTRATION" \
    --cli-flags "--multi-agent:--no-multi-agent" \
    --init-msg "_mao_init_message"
