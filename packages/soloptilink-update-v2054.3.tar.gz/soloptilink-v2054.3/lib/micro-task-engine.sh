#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v52.0 - Micro-Task Engine
# =============================================================================
# Decomposes large implementation phases into focused micro-tasks.
# Instead of one massive prompt generating everything, breaks down into:
#   Step 1: Schema/Models only
#   Step 2: API routes only (using Step 1 output as context)
#   Step 3: Frontend components (using Steps 1-2 as context)
#   Step 4: Tests (using Steps 1-3 as context)
#   Step 5: Configuration & integration (all prior steps as context)
#
# Each step's output becomes context for the next step.
# Each step is individually validated by Code Validator.
#
# Functions:
#   mt_init                 - Initialize micro-task engine
#   mt_decompose_task       - Break task into micro-tasks based on project type
#   mt_execute_pipeline     - Execute micro-tasks sequentially with context chain
#   mt_execute_step         - Execute a single micro-task
#   mt_validate_step        - Validate step output
#   mt_get_context_for_step - Build cumulative context from prior steps
#   mt_report               - Execution statistics
#
# All globals use the MT_ prefix.
# =============================================================================

[[ -n "${_MICRO_TASK_ENGINE_LOADED:-}" ]] && return 0
_MICRO_TASK_ENGINE_LOADED=1

# ============================================================
# State
# ============================================================
declare -g MT_VERSION="52.0"
declare -g MT_ENABLED="false"
declare -g MT_STEPS_TOTAL=0
declare -g MT_STEPS_COMPLETED=0
declare -g MT_STEPS_FAILED=0
declare -g MT_VALIDATION_PASSES=0
declare -g MT_VALIDATION_FAILS=0
declare -g MT_REWRITE_COUNT=0
declare -g MT_PROJECT_TYPE=""    # nextjs|express|flask|ios|static
declare -g MT_COMPLEXITY=""      # simple|medium|complex|enterprise
declare -g -a MT_STEP_NAMES=()
declare -g -a MT_STEP_OUTPUTS=()
declare -g MT_WORK_DIR=""

# ============================================================
# Internal logger
# ============================================================
_mt_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    [[ "$level" == "SUCCESS" ]] && color="${GREEN:-}"
    echo -e "  ${color}[MICRO-TASK]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize
# ============================================================
mt_init() {
    MT_ENABLED="true"
    MT_STEPS_TOTAL=0
    MT_STEPS_COMPLETED=0
    MT_STEPS_FAILED=0
    MT_VALIDATION_PASSES=0
    MT_VALIDATION_FAILS=0
    MT_REWRITE_COUNT=0
    MT_STEP_NAMES=()
    MT_STEP_OUTPUTS=()

    MT_WORK_DIR="${SESSION_LOG_DIR:-/tmp}/micro_tasks"
    mkdir -p "$MT_WORK_DIR" 2>/dev/null || true

    _mt_log "SUCCESS" "Micro-Task Engine v52.0 初期化完了"
    return 0
}

# ============================================================
# Detect project type and complexity
# ============================================================
mt_detect_project_type() {
    local task_desc="$1"
    local tech_stack="${2:-}"

    # Project type detection
    if [[ "$task_desc" =~ iOS|Swift|SwiftUI|UIKit ]]; then
        MT_PROJECT_TYPE="ios"
    elif [[ "$tech_stack" =~ nextjs|Next ]]; then
        MT_PROJECT_TYPE="nextjs"
    elif [[ "$tech_stack" =~ express|Express|fastify ]]; then
        MT_PROJECT_TYPE="express"
    elif [[ "$tech_stack" =~ flask|FastAPI|django ]]; then
        MT_PROJECT_TYPE="flask"
    elif [[ "$task_desc" =~ LP|ランディング|静的|static ]]; then
        MT_PROJECT_TYPE="static"
    else
        MT_PROJECT_TYPE="nextjs"  # Default
    fi

    # Complexity detection (reuse Phase Optimizer if available)
    if type -t po_detect_complexity &>/dev/null; then
        MT_COMPLEXITY=$(po_detect_complexity "$task_desc" 2>/dev/null || echo "medium")
    elif [[ "$task_desc" =~ SaaS|エンタープライズ|Enterprise|基幹|ERP ]]; then
        MT_COMPLEXITY="enterprise"
    elif [[ "$task_desc" =~ CRM|EC|チャット|予約|管理 ]]; then
        MT_COMPLEXITY="complex"
    elif [[ "$task_desc" =~ ブログ|タスク|TODO|メモ ]]; then
        MT_COMPLEXITY="medium"
    else
        MT_COMPLEXITY="simple"
    fi

    _mt_log "SUCCESS" "プロジェクト検出: type=${MT_PROJECT_TYPE}, complexity=${MT_COMPLEXITY}"
}

# ============================================================
# Decompose task into micro-tasks
# Returns step definitions based on project type
# ============================================================
mt_decompose_task() {
    local task_desc="$1"
    local domain="${2:-}"
    local tech_stack="${3:-}"

    mt_detect_project_type "$task_desc" "$tech_stack"

    MT_STEP_NAMES=()

    case "$MT_PROJECT_TYPE" in
        nextjs)
            MT_STEP_NAMES=(
                "schema"      # Prismaスキーマ + 型定義
                "api"         # APIルート (Next.js App Router)
                "frontend"    # Reactコンポーネント + ページ
                "integration" # レイアウト・ナビゲーション・設定ファイル
            )
            # Complex/Enterprise: テストも追加
            if [[ "$MT_COMPLEXITY" =~ ^(complex|enterprise)$ ]]; then
                MT_STEP_NAMES+=("testing")
            fi
            ;;
        express)
            MT_STEP_NAMES=(
                "schema"      # DB スキーマ/モデル
                "api"         # Expressルート + コントローラー
                "middleware"   # 認証・バリデーション・エラーハンドリング
                "integration" # エントリポイント・設定
            )
            if [[ "$MT_COMPLEXITY" =~ ^(complex|enterprise)$ ]]; then
                MT_STEP_NAMES+=("testing")
            fi
            ;;
        ios)
            MT_STEP_NAMES=(
                "model"       # CoreData/Swiftモデル
                "viewmodel"   # MVVM ViewModel
                "view"        # SwiftUI Views
                "integration" # App構造・ナビゲーション・設定
            )
            ;;
        flask)
            MT_STEP_NAMES=(
                "schema"      # SQLAlchemy/Pydanticモデル
                "api"         # Flask/FastAPI ルート
                "frontend"    # テンプレート or React SPA
                "integration" # 設定・WSGI・Docker
            )
            ;;
        static)
            # Simple projects: fewer steps
            MT_STEP_NAMES=(
                "structure"   # HTML/CSS構造
                "content"     # コンテンツ・スタイリング
            )
            ;;
    esac

    MT_STEPS_TOTAL=${#MT_STEP_NAMES[@]}
    _mt_log "SUCCESS" "タスク分解完了: ${MT_STEPS_TOTAL}ステップ (${MT_STEP_NAMES[*]})"
    return 0
}

# ============================================================
# Build prompt for a specific step
# ============================================================
mt_build_step_prompt() {
    local step_name="$1"
    local task_desc="$2"
    local domain_knowledge="${3:-}"
    local blueprint="${4:-}"

    local prompt=""

    # Build step-specific prompt
    case "$step_name" in
        schema|model)
            prompt="以下のシステムのデータベーススキーマのみを生成してください。

タスク: ${task_desc}

要件:
- Prismaスキーマ形式で出力（Next.js/Express）または CoreData モデル（iOS）
- 全モデルの定義、リレーション、インデックスを含める
- id, createdAt, updatedAt は全テーブルに含める
- enum がある場合は定義する
- バリデーション用のzodスキーマも同時に生成する

${domain_knowledge:+ドメイン知識:\n${domain_knowledge}\n}
${blueprint:+設計図:\n${blueprint}\n}"
            ;;

        api)
            local schema_context=""
            if [[ ${#MT_STEP_OUTPUTS[@]} -gt 0 ]]; then
                schema_context="${MT_STEP_OUTPUTS[0]}"
            fi
            prompt="以下のスキーマに基づいてAPIルートを生成してください。

タスク: ${task_desc}

前のステップで生成したスキーマ:
${schema_context}

要件:
- 全モデルのCRUD APIエンドポイント
- zodによる入力バリデーション
- Prismaクエリによるデータアクセス（モックデータは絶対に使わない）
- try-catchエラーハンドリング
- ページネーション対応（一覧API）
- 適切なHTTPステータスコード

${domain_knowledge:+ドメイン知識:\n${domain_knowledge}\n}"
            ;;

        frontend|view)
            local prior_context=""
            for ((i=0; i<${#MT_STEP_OUTPUTS[@]}; i++)); do
                prior_context="${prior_context}
--- ステップ ${MT_STEP_NAMES[$i]} の出力 ---
${MT_STEP_OUTPUTS[$i]}
"
            done
            prompt="以下のAPIに接続するフロントエンドコンポーネントを生成してください。

タスク: ${task_desc}

前のステップの出力:
${prior_context}

要件:
- APIに実際にfetch/SWRで接続するコンポーネント（モックデータ禁止）
- フォームはReact Hook Form + zodResolverで実装
- ローディング状態・エラー状態を必ず処理
- レスポンシブデザイン（Tailwind CSS）
- 一覧ページ: テーブル表示 + ページネーション + 検索
- 詳細/編集ページ: フォーム + バリデーション
- 削除確認ダイアログ

${domain_knowledge:+ドメイン知識:\n${domain_knowledge}\n}"
            ;;

        viewmodel)
            local model_context=""
            if [[ ${#MT_STEP_OUTPUTS[@]} -gt 0 ]]; then
                model_context="${MT_STEP_OUTPUTS[0]}"
            fi
            prompt="以下のモデルに基づいてMVVM ViewModelを生成してください。

タスク: ${task_desc}

モデル定義:
${model_context}

要件:
- @Published プロパティで状態管理
- async/await + Task でAPI/DB呼び出し
- エラーハンドリング（errorMessage プロパティ）
- isLoading 状態管理
- CRUD操作メソッド

${domain_knowledge:+ドメイン知識:\n${domain_knowledge}\n}"
            ;;

        middleware)
            local prior_context=""
            for ((i=0; i<${#MT_STEP_OUTPUTS[@]}; i++)); do
                prior_context="${prior_context}
${MT_STEP_OUTPUTS[$i]}
"
            done
            prompt="以下のAPIに必要なミドルウェアを生成してください。

タスク: ${task_desc}

既存コード:
${prior_context}

要件:
- 認証ミドルウェア（JWT検証）
- 入力バリデーションミドルウェア
- エラーハンドリングミドルウェア
- レート制限
- CORSミドルウェア
- リクエストログミドルウェア"
            ;;

        testing)
            local prior_context=""
            for ((i=0; i<${#MT_STEP_OUTPUTS[@]}; i++)); do
                prior_context="${prior_context}
--- ${MT_STEP_NAMES[$i]} ---
${MT_STEP_OUTPUTS[$i]}
"
            done
            prompt="以下のコードのテストを生成してください。

タスク: ${task_desc}

テスト対象コード:
${prior_context}

要件:
- APIルートの単体テスト（Jest/Vitest）
- コンポーネントのテスト（Testing Library）
- 各エンドポイントのHTTPテスト
- エッジケースを含む"
            ;;

        integration|structure|content)
            local prior_context=""
            for ((i=0; i<${#MT_STEP_OUTPUTS[@]}; i++)); do
                prior_context="${prior_context}
--- ${MT_STEP_NAMES[$i]} ---
${MT_STEP_OUTPUTS[$i]}
"
            done
            prompt="以下のコードを統合する設定ファイルとエントリポイントを生成してください。

タスク: ${task_desc}

生成済みコード:
${prior_context}

要件:
- レイアウトコンポーネント（ナビゲーション、サイドバー）
- ルーティング設定
- 環境変数テンプレート (.env.example)
- package.json の依存関係が正しいこと
- tsconfig.json / tailwind.config.ts の設定
- 全ファイルが相互に正しくimportされていること"
            ;;
    esac

    printf '%s' "$prompt"
}

# ============================================================
# Execute single micro-task step
# ============================================================
mt_execute_step() {
    local step_index="$1"
    local task_desc="$2"
    local domain_knowledge="${3:-}"
    local blueprint="${4:-}"

    local step_name="${MT_STEP_NAMES[$step_index]}"
    local step_output_file="${MT_WORK_DIR}/step_${step_index}_${step_name}.txt"

    _mt_log "SUCCESS" "ステップ ${step_index}/${MT_STEPS_TOTAL}: ${step_name} 実行中..."

    # Build step-specific prompt
    local prompt
    prompt=$(mt_build_step_prompt "$step_name" "$task_desc" "$domain_knowledge" "$blueprint")

    # Get agent file for this step
    local agent_file=""
    local agent_id=""
    case "$step_name" in
        schema|model) agent_id="db-architect" ;;
        api|middleware) agent_id="backend-dev" ;;
        frontend|view) agent_id="frontend-dev" ;;
        viewmodel) agent_id="ios-dev" ;;
        testing) agent_id="qa-engineer" ;;
        *) agent_id="pm" ;;
    esac

    local agents_dir="${AR_AGENTS_DIR:-${SCRIPT_DIR:-.}/.claude/agents}"
    if [[ -f "${agents_dir}/${agent_id}.md" ]]; then
        agent_file="${agents_dir}/${agent_id}.md"
    fi

    # Enterprise patterns injection
    local ep_patterns=""
    case "$step_name" in
        api)
            if type -t ep_inject_into_prompt &>/dev/null; then
                ep_patterns=$(ep_inject_into_prompt "backend" 2>/dev/null || echo "")
            fi
            ;;
        frontend|view)
            if type -t ep_inject_frontend_patterns &>/dev/null; then
                ep_patterns=$(ep_inject_frontend_patterns 2>/dev/null || echo "")
            elif type -t ep_inject_into_prompt &>/dev/null; then
                ep_patterns=$(ep_inject_into_prompt "frontend" 2>/dev/null || echo "")
            fi
            ;;
    esac
    [[ -n "$ep_patterns" ]] && prompt="${prompt}

${ep_patterns}"

    # Call Claude via structured output v2
    local result=""
    if type -t so2_call_claude_structured &>/dev/null; then
        result=$(so2_call_claude_structured "$prompt" "$step_output_file" "$agent_file" "$step_name")
    elif type -t _call_claude &>/dev/null; then
        result=$(_call_claude "$prompt" "$step_output_file" "$step_name")
    else
        _mt_log "ERROR" "Claude呼び出し関数が利用不可"
        return 1
    fi

    if [[ -z "$result" ]]; then
        _mt_log "ERROR" "ステップ ${step_name}: 空の出力"
        MT_STEPS_FAILED=$((MT_STEPS_FAILED + 1))
        return 1
    fi

    # Store output for next step's context
    MT_STEP_OUTPUTS+=("$result")
    MT_STEPS_COMPLETED=$((MT_STEPS_COMPLETED + 1))

    # Validate step output
    if mt_validate_step "$step_name" "$result"; then
        MT_VALIDATION_PASSES=$((MT_VALIDATION_PASSES + 1))
        _mt_log "SUCCESS" "ステップ ${step_name}: 検証OK"
    else
        MT_VALIDATION_FAILS=$((MT_VALIDATION_FAILS + 1))
        _mt_log "WARN" "ステップ ${step_name}: 検証失敗（続行）"
    fi

    return 0
}

# ============================================================
# Execute full micro-task pipeline
# ============================================================
mt_execute_pipeline() {
    local task_desc="$1"
    local project_dir="${2:-${PROJECT_DIR:-.}}"
    local domain_knowledge="${3:-}"
    local blueprint="${4:-}"

    if [[ ${#MT_STEP_NAMES[@]} -eq 0 ]]; then
        _mt_log "WARN" "マイクロタスク未定義。mt_decompose_task()を先に実行してください"
        return 1
    fi

    _mt_log "SUCCESS" "マイクロタスクパイプライン開始: ${MT_STEPS_TOTAL}ステップ"
    echo -e "  ${BOLD:-}[MICRO-TASK] パイプライン: ${MT_STEP_NAMES[*]}${NC:-}" >&2

    MT_STEP_OUTPUTS=()

    for ((i=0; i<MT_STEPS_TOTAL; i++)); do
        mt_execute_step "$i" "$task_desc" "$domain_knowledge" "$blueprint"
        local rc=$?

        if [[ $rc -ne 0 ]]; then
            _mt_log "WARN" "ステップ ${MT_STEP_NAMES[$i]} 失敗。パイプライン続行..."
            MT_STEP_OUTPUTS+=("")  # Empty placeholder for context chain
        fi

        # Write files from this step if structured output v2 is available
        local step_output="${MT_STEP_OUTPUTS[$i]:-}"
        if [[ -n "$step_output" ]] && type -t so2_process_output &>/dev/null; then
            so2_process_output "$step_output" "$project_dir"
        fi

        # Dashboard progress update
        if type -t dc_phase_update &>/dev/null; then
            dc_phase_update "micro_task_${MT_STEP_NAMES[$i]}" "completed" 2>/dev/null || true
        fi
    done

    _mt_log "SUCCESS" "パイプライン完了: ${MT_STEPS_COMPLETED}/${MT_STEPS_TOTAL} ステップ成功"
    return 0
}

# ============================================================
# Validate step output (basic checks)
# ============================================================
mt_validate_step() {
    local step_name="$1"
    local output="$2"

    [[ -z "$output" ]] && return 1

    # Check for mock data patterns (critical quality check)
    local mock_patterns=(
        "sampleData"
        "mockData"
        "dummyData"
        "TODO:"
        "FIXME:"
        "Date\.now()"
        "Math\.random()"
        '\[\s*\{.*id:\s*["\x27]1["\x27]'
    )

    for pattern in "${mock_patterns[@]}"; do
        if printf '%s' "$output" | grep -qE "$pattern" 2>/dev/null; then
            _mt_log "WARN" "ステップ ${step_name}: モックデータパターン検出 (${pattern})"
            return 1
        fi
    done

    # Step-specific validation
    case "$step_name" in
        schema)
            # Must contain model/table definitions
            if ! printf '%s' "$output" | grep -qiE '(model |CREATE TABLE|class .+Model|@Entity)'; then
                _mt_log "WARN" "ステップ schema: モデル定義が見つからない"
                return 1
            fi
            ;;
        api)
            # Must contain route/endpoint definitions
            if ! printf '%s' "$output" | grep -qiE '(export .*(GET|POST|PUT|DELETE|PATCH)|app\.(get|post|put|delete|patch)|@(Get|Post|Put|Delete))'; then
                _mt_log "WARN" "ステップ api: APIエンドポイントが見つからない"
                return 1
            fi
            ;;
        frontend|view)
            # Must contain component definitions
            if ! printf '%s' "$output" | grep -qiE '(export .*(function|const) |struct .+: View|@Component)'; then
                _mt_log "WARN" "ステップ frontend: コンポーネント定義が見つからない"
                return 1
            fi
            ;;
    esac

    return 0
}

# ============================================================
# Get accumulated context from prior steps
# ============================================================
mt_get_context_for_step() {
    local step_index="$1"
    local context=""

    for ((i=0; i<step_index && i<${#MT_STEP_OUTPUTS[@]}; i++)); do
        local step_output="${MT_STEP_OUTPUTS[$i]}"
        if [[ -n "$step_output" ]]; then
            # Truncate very long outputs to stay within context limits
            local max_chars=8000
            if [[ ${#step_output} -gt $max_chars ]]; then
                step_output="${step_output:0:$max_chars}
... (以降省略)"
            fi
            context="${context}
=== ${MT_STEP_NAMES[$i]} の出力 ===
${step_output}
"
        fi
    done

    printf '%s' "$context"
}

# ============================================================
# Check if micro-task decomposition should be used
# Returns 0 if micro-task is recommended, 1 otherwise
# ============================================================
mt_should_decompose() {
    local task_desc="$1"
    local pipeline_mode="${2:-standard}"

    # Quick pipeline: skip micro-task decomposition
    [[ "$pipeline_mode" == "quick" ]] && return 1

    # Static sites: too simple for micro-tasks
    [[ "$task_desc" =~ LP|ランディング|静的|static ]] && return 1

    # Simple complexity: skip
    [[ "${MT_COMPLEXITY:-}" == "simple" ]] && return 1

    # Default: use micro-tasks for medium+ complexity
    return 0
}

# ============================================================
# Report
# ============================================================
mt_report() {
    echo -e "\n${BOLD:-}=== Micro-Task Engine Report ===${NC:-}"
    echo -e "  バージョン:        ${MT_VERSION}"
    echo -e "  プロジェクトタイプ: ${MT_PROJECT_TYPE}"
    echo -e "  複雑度:            ${MT_COMPLEXITY}"
    echo -e "  ステップ数:        ${MT_STEPS_TOTAL}"
    echo -e "  完了:              ${MT_STEPS_COMPLETED}"
    echo -e "  失敗:              ${MT_STEPS_FAILED}"
    echo -e "  検証パス:          ${MT_VALIDATION_PASSES}"
    echo -e "  検証フェイル:      ${MT_VALIDATION_FAILS}"
    echo -e "  再書き込み回数:    ${MT_REWRITE_COUNT}"

    if [[ ${#MT_STEP_NAMES[@]} -gt 0 ]]; then
        echo -e "  ステップ詳細:"
        for ((i=0; i<${#MT_STEP_NAMES[@]}; i++)); do
            local status="✅"
            [[ -z "${MT_STEP_OUTPUTS[$i]:-}" ]] && status="❌"
            echo -e "    ${status} Step ${i}: ${MT_STEP_NAMES[$i]}"
        done
    fi
}
