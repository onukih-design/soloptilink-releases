#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v366.0 - Cost Alert System
# =============================================================================
# 予算設定×コスト異常検知×アラート生成
#
# 機能:
#   - クラウドコスト予算設定（月次/日次/サービス別）
#   - コスト異常検知（急増/トレンド逸脱）
#   - 予算超過アラート（Slack/Email通知）
#   - コスト最適化提案
#   - コストレポート生成
#
# 全globals: CAS_ prefix
# =============================================================================

[[ -n "${_CAS_LOADED:-}" ]] && return 0; _CAS_LOADED=1

CAS_VERSION="366.0"
CAS_GENERATED=0
CAS_ERRORS=0
CAS_PHASE="cost_alert"
CAS_FILES_CREATED=()
CAS_ALERTS_GENERATED=0

: "${GREEN:=\033[0;32m}" ; : "${RED:=\033[0;31m}" ; : "${YELLOW:=\033[0;33m}"
: "${CYAN:=\033[0;36m}" ; : "${BOLD:=\033[1m}" ; : "${NC:=\033[0m}"

_cas_log() { echo -e "  ${CYAN}[CAS]${NC} $*"; }
_cas_ok() { echo -e "  ${GREEN}[CAS]${NC} $*"; }
_cas_err() { echo -e "  ${RED}[CAS]${NC} $*"; }

_cas_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        CAS_FILES_CREATED+=("$filepath")
        CAS_GENERATED=$((CAS_GENERATED + 1))
        _cas_ok "Created: ${filepath##*/}"
    else
        CAS_ERRORS=$((CAS_ERRORS + 1))
        _cas_err "Failed: ${filepath##*/}"
    fi
}

cas_init() {
    CAS_GENERATED=0; CAS_ERRORS=0; CAS_ALERTS_GENERATED=0; CAS_FILES_CREATED=()
    _cas_log "Cost Alert System v${CAS_VERSION} initialized"
    return 0
}

# =============================================================================
# Set Budget
# =============================================================================
_cas_set_budget() {
    local project_dir="${1:-.}"

    _cas_log "Generating cost budget system..."

    local cost_dir="${project_dir}/src/lib/cost-management"
    mkdir -p "$cost_dir" 2>/dev/null

    _cas_write_file "${cost_dir}/budget.ts" "$(cat <<'TS'
import { z } from 'zod';

export const BudgetSchema = z.object({
  id: z.string(),
  name: z.string(),
  type: z.enum(['monthly', 'daily', 'per_service']),
  amount: z.number().positive(),
  currency: z.string().default('USD'),
  service: z.string().optional(),
  alertThresholds: z.array(z.object({
    percent: z.number().min(0).max(100),
    severity: z.enum(['info', 'warning', 'critical']),
    notifyChannels: z.array(z.string()),
  })),
  period: z.object({
    start: z.string().datetime(),
    end: z.string().datetime(),
  }),
  currentSpend: z.number().default(0),
});

export type Budget = z.infer<typeof BudgetSchema>;

class BudgetManager {
  private budgets = new Map<string, Budget>();

  create(budget: Budget): Budget {
    BudgetSchema.parse(budget);
    this.budgets.set(budget.id, budget);
    return budget;
  }

  updateSpend(id: string, amount: number): Budget {
    const budget = this.budgets.get(id);
    if (!budget) throw new Error(`Budget not found: ${id}`);
    budget.currentSpend = amount;
    return budget;
  }

  checkThresholds(id: string): { triggered: boolean; alerts: { percent: number; severity: string }[] } {
    const budget = this.budgets.get(id);
    if (!budget) return { triggered: false, alerts: [] };

    const usedPercent = (budget.currentSpend / budget.amount) * 100;
    const alerts = budget.alertThresholds
      .filter(t => usedPercent >= t.percent)
      .map(t => ({ percent: t.percent, severity: t.severity }));

    return { triggered: alerts.length > 0, alerts };
  }

  getAll(): Budget[] { return Array.from(this.budgets.values()); }

  getForecast(id: string): { projectedMonthEnd: number; overBudget: boolean; projectedOverage: number } {
    const budget = this.budgets.get(id);
    if (!budget) return { projectedMonthEnd: 0, overBudget: false, projectedOverage: 0 };

    const start = new Date(budget.period.start).getTime();
    const end = new Date(budget.period.end).getTime();
    const now = Date.now();
    const elapsed = (now - start) / (end - start);
    const projected = elapsed > 0 ? budget.currentSpend / elapsed : 0;

    return {
      projectedMonthEnd: Math.round(projected * 100) / 100,
      overBudget: projected > budget.amount,
      projectedOverage: Math.max(0, Math.round((projected - budget.amount) * 100) / 100),
    };
  }
}

export const budgetManager = new BudgetManager();
TS
)"

    _cas_ok "Cost budget system generated"
}

# =============================================================================
# Detect Anomaly
# =============================================================================
_cas_detect_anomaly() {
    local project_dir="${1:-.}"

    _cas_log "Generating cost anomaly detector..."

    local cost_dir="${project_dir}/src/lib/cost-management"
    mkdir -p "$cost_dir" 2>/dev/null

    _cas_write_file "${cost_dir}/anomaly-detector.ts" "$(cat <<'TS'
interface CostDataPoint {
  date: string;
  service: string;
  amount: number;
}

interface Anomaly {
  date: string;
  service: string;
  amount: number;
  expectedAmount: number;
  deviationPercent: number;
  severity: 'warning' | 'critical';
  reason: string;
}

export function detectAnomalies(data: CostDataPoint[], stdDevMultiplier = 2): Anomaly[] {
  const anomalies: Anomaly[] = [];
  const byService = new Map<string, CostDataPoint[]>();

  for (const point of data) {
    const existing = byService.get(point.service) || [];
    existing.push(point);
    byService.set(point.service, existing);
  }

  for (const [service, points] of byService) {
    if (points.length < 7) continue;

    const amounts = points.map(p => p.amount);
    const mean = amounts.reduce((s, v) => s + v, 0) / amounts.length;
    const variance = amounts.reduce((s, v) => s + (v - mean) ** 2, 0) / amounts.length;
    const stdDev = Math.sqrt(variance);

    for (const point of points) {
      const deviation = (point.amount - mean) / (stdDev || 1);
      if (Math.abs(deviation) > stdDevMultiplier) {
        const deviationPercent = ((point.amount - mean) / mean) * 100;
        anomalies.push({
          date: point.date,
          service,
          amount: point.amount,
          expectedAmount: Math.round(mean * 100) / 100,
          deviationPercent: Math.round(deviationPercent),
          severity: Math.abs(deviation) > stdDevMultiplier * 2 ? 'critical' : 'warning',
          reason: point.amount > mean
            ? `Cost spike: ${Math.round(deviationPercent)}% above average`
            : `Unusual drop: ${Math.round(Math.abs(deviationPercent))}% below average`,
        });
      }
    }
  }

  return anomalies;
}
TS
)"

    _cas_ok "Cost anomaly detector generated"
}

# =============================================================================
# Generate Alert
# =============================================================================
_cas_generate_alert() {
    local project_dir="${1:-.}"

    _cas_log "Generating cost alert system..."

    local cost_dir="${project_dir}/src/lib/cost-management"
    mkdir -p "$cost_dir" 2>/dev/null

    _cas_write_file "${cost_dir}/alerter.ts" "$(cat <<'TS'
interface CostAlert {
  id: string;
  type: 'budget_threshold' | 'anomaly' | 'forecast_overrun';
  severity: 'info' | 'warning' | 'critical';
  title: string;
  message: string;
  service?: string;
  amount?: number;
  threshold?: number;
  createdAt: string;
}

export class CostAlerter {
  private alerts: CostAlert[] = [];
  private notifiers: ((alert: CostAlert) => Promise<void>)[] = [];

  addNotifier(fn: (alert: CostAlert) => Promise<void>): void {
    this.notifiers.push(fn);
  }

  async alert(alert: Omit<CostAlert, 'id' | 'createdAt'>): Promise<CostAlert> {
    const full: CostAlert = {
      ...alert,
      id: `cost-alert-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    this.alerts.push(full);
    await Promise.allSettled(this.notifiers.map(n => n(full)));
    return full;
  }

  getRecent(hours = 24): CostAlert[] {
    const cutoff = Date.now() - hours * 3600000;
    return this.alerts.filter(a => new Date(a.createdAt).getTime() > cutoff);
  }
}

export const costAlerter = new CostAlerter();

// Default Slack notifier
costAlerter.addNotifier(async (alert) => {
  const webhookUrl = process.env.COST_ALERT_SLACK_WEBHOOK;
  if (!webhookUrl) return;

  const emoji = { info: 'information_source', warning: 'warning', critical: 'rotating_light' }[alert.severity];

  await fetch(webhookUrl, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      text: `:${emoji}: *[${alert.severity.toUpperCase()}] ${alert.title}*\n${alert.message}`,
    }),
  });
});
TS
)"

    CAS_ALERTS_GENERATED=$((CAS_ALERTS_GENERATED + 1))
    _cas_ok "Cost alert system generated"
}

# =============================================================================
# Report / Score / Register
# =============================================================================
cas_report() {
    echo -e "\n  ${BOLD}=== Cost Alert System v${CAS_VERSION} ===${NC}"
    echo -e "  生成ファイル数   : ${CAS_GENERATED}"
    echo -e "  エラー           : ${CAS_ERRORS}"
    echo -e "  アラート生成数   : ${CAS_ALERTS_GENERATED}"
    if [[ ${#CAS_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${CAS_FILES_CREATED[@]}"; do echo -e "    - ${f}"; done
    fi
}

cas_score() {
    if [[ ${CAS_GENERATED} -ge 3 ]] && [[ ${CAS_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${CAS_GENERATED} -gt 0 ]] && [[ ${CAS_ERRORS} -eq 0 ]]; then echo "90"
    elif [[ ${CAS_GENERATED} -gt 0 ]]; then echo "70"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "cost-alert-system" --version "366.0" \
        --description "予算設定×コスト異常検知×アラート生成" \
        --init "cas_init" --report "cas_report" --score "cas_score" \
        --enable-var "ENABLE_COST_ALERT" --cli-flags "--cost-alert:--no-cost-alert"
fi

# v2003.1: source時のexit codeを確実に0にする
true
