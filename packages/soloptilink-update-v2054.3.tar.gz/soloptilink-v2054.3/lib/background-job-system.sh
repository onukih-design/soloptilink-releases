#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v293.0 - Background Job System
# =============================================================================
# バックグラウンドジョブ自動生成。ワーカー、スケジューラー、モニタリングダッシュボード、
# リトライロジックを生成する。
#
# 機能一覧:
#   _bjs_generate_worker    - ジョブワーカー生成
#   _bjs_generate_scheduler - スケジューラー生成
#   _bjs_generate_dashboard - モニタリングダッシュボード
#   _bjs_generate_retry     - リトライロジック
#
# 全globals: BJS_ prefix
# =============================================================================

[[ -n "${_BJS_LOADED:-}" ]] && return 0; _BJS_LOADED=1

declare -g BJS_VERSION="293.0"
declare -g BJS_GENERATED=0
declare -g BJS_ERRORS=0
declare -g BJS_FILES_WRITTEN=0

bjs_init() { BJS_GENERATED=0; BJS_ERRORS=0; BJS_FILES_WRITTEN=0; return 0; }

_bjs_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then BJS_FILES_WRITTEN=$((BJS_FILES_WRITTEN + 1)); echo "  [bjs] wrote: $filepath" >&2
    else BJS_ERRORS=$((BJS_ERRORS + 1)); fi
}

_bjs_log() { echo -e "  ${GREEN:-\033[0;32m}[BJS]${NC:-\033[0m} $*" >&2; }

# =============================================================================
# _bjs_generate_worker
# =============================================================================
_bjs_generate_worker() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _bjs_log "Generating background job worker..."

    local worker_ts
    worker_ts=$(cat <<'WRKEOF'
// =============================================================================
// Background Job Worker
// Process jobs from queue with typed handlers
// =============================================================================
import { z } from 'zod';

// --- Job Types ---
export const JobTypeSchema = z.enum([
  'email.send', 'email.bulk', 'report.generate', 'export.csv', 'export.pdf',
  'cleanup.sessions', 'cleanup.files', 'notification.push', 'webhook.deliver',
  'import.csv', 'image.resize', 'invoice.generate',
]);
export type JobType = z.infer<typeof JobTypeSchema>;

export interface Job<T = unknown> {
  id: string;
  type: JobType;
  payload: T;
  priority: number;
  attempts: number;
  maxAttempts: number;
  createdAt: Date;
  scheduledAt?: Date;
  startedAt?: Date;
  completedAt?: Date;
  failedAt?: Date;
  error?: string;
  result?: unknown;
}

type JobHandler<T = unknown> = (job: Job<T>) => Promise<unknown>;

export class JobWorker {
  private handlers: Map<JobType, JobHandler> = new Map();
  private processing = false;
  private concurrency: number;
  private activeJobs = 0;

  constructor(concurrency = 5) { this.concurrency = concurrency; }

  register<T>(type: JobType, handler: JobHandler<T>): void {
    this.handlers.set(type, handler as JobHandler);
    console.log(`[worker] Registered handler: ${type}`);
  }

  async process(job: Job): Promise<void> {
    const handler = this.handlers.get(job.type);
    if (!handler) { console.warn(`[worker] No handler for: ${job.type}`); return; }

    job.startedAt = new Date();
    job.attempts++;
    this.activeJobs++;

    try {
      job.result = await handler(job);
      job.completedAt = new Date();
      console.log(`[worker] Completed: ${job.type} (${job.id}) in ${job.completedAt.getTime() - job.startedAt.getTime()}ms`);
    } catch (err: any) {
      job.error = err.message;
      if (job.attempts >= job.maxAttempts) {
        job.failedAt = new Date();
        console.error(`[worker] Failed permanently: ${job.type} (${job.id}) after ${job.attempts} attempts`);
      } else {
        console.warn(`[worker] Failed (retryable): ${job.type} (${job.id}) attempt ${job.attempts}/${job.maxAttempts}`);
      }
    } finally {
      this.activeJobs--;
    }
  }

  getStats(): { handlers: number; activeJobs: number; concurrency: number } {
    return { handlers: this.handlers.size, activeJobs: this.activeJobs, concurrency: this.concurrency };
  }
}

export const worker = new JobWorker();

// Register default handlers
worker.register('email.send', async (job) => {
  console.log(`[worker] Sending email to: ${(job.payload as any).to}`);
  // await emailService.send(job.payload);
});

worker.register('report.generate', async (job) => {
  console.log(`[worker] Generating report: ${(job.payload as any).type}`);
  // await reportService.generate(job.payload);
});

worker.register('cleanup.sessions', async () => {
  console.log('[worker] Cleaning up expired sessions');
  // await sessionService.cleanupExpired();
});
WRKEOF
)
    _bjs_write_file "${project_dir}/src/lib/jobs/worker.ts" "$worker_ts"
    BJS_GENERATED=$((BJS_GENERATED + 1))
    return 0
}

# =============================================================================
# _bjs_generate_scheduler
# =============================================================================
_bjs_generate_scheduler() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _bjs_log "Generating job scheduler..."

    local sched_ts
    sched_ts=$(cat <<'SCHEDEOF'
// =============================================================================
// Job Scheduler - Cron-like scheduling for recurring jobs
// =============================================================================

export interface ScheduledJob {
  name: string;
  type: string;
  cron: string;
  payload: Record<string, unknown>;
  enabled: boolean;
  timezone: string;
  lastRun?: Date;
  nextRun?: Date;
}

const scheduledJobs: ScheduledJob[] = [
  { name: 'daily-report', type: 'report.generate', cron: '0 8 * * *', payload: { format: 'pdf' }, enabled: true, timezone: 'Asia/Tokyo' },
  { name: 'session-cleanup', type: 'cleanup.sessions', cron: '0 2 * * *', payload: {}, enabled: true, timezone: 'UTC' },
  { name: 'weekly-export', type: 'export.csv', cron: '0 0 * * 1', payload: { scope: 'all' }, enabled: true, timezone: 'Asia/Tokyo' },
  { name: 'health-ping', type: 'notification.push', cron: '*/10 * * * *', payload: { type: 'health' }, enabled: true, timezone: 'UTC' },
];

// Simple cron parser for display
function parseCron(cron: string): string {
  const parts = cron.split(' ');
  if (parts.length !== 5) return cron;
  const [min, hour, dom, mon, dow] = parts;
  if (min === '*' && hour === '*') return `Every minute`;
  if (min.startsWith('*/')) return `Every ${min.slice(2)} minutes`;
  if (hour === '*') return `At minute ${min} of every hour`;
  if (dom === '*' && mon === '*' && dow === '*') return `Daily at ${hour}:${min.padStart(2, '0')}`;
  if (dow !== '*') return `Weekly on day ${dow} at ${hour}:${min.padStart(2, '0')}`;
  return cron;
}

export function getScheduledJobs(): Array<ScheduledJob & { description: string }> {
  return scheduledJobs.map((j) => ({ ...j, description: parseCron(j.cron) }));
}

export function enableJob(name: string): boolean {
  const job = scheduledJobs.find((j) => j.name === name);
  if (!job) return false;
  job.enabled = true; return true;
}

export function disableJob(name: string): boolean {
  const job = scheduledJobs.find((j) => j.name === name);
  if (!job) return false;
  job.enabled = false; return true;
}
SCHEDEOF
)
    _bjs_write_file "${project_dir}/src/lib/jobs/scheduler.ts" "$sched_ts"
    BJS_GENERATED=$((BJS_GENERATED + 1))
    return 0
}

# =============================================================================
# _bjs_generate_dashboard
# =============================================================================
_bjs_generate_dashboard() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _bjs_log "Generating job dashboard API..."

    local dash_ts
    dash_ts=$(cat <<'DASHEOF'
// =============================================================================
// Job Monitoring Dashboard API
// =============================================================================
import { NextRequest, NextResponse } from 'next/server';

interface JobStats {
  queued: number;
  active: number;
  completed: number;
  failed: number;
  delayed: number;
}

// GET /api/admin/jobs
export async function GET(req: NextRequest) {
  const stats: JobStats = { queued: 0, active: 0, completed: 0, failed: 0, delayed: 0 };
  // In real implementation: query BullMQ/DB for stats
  return NextResponse.json({
    stats,
    workers: { active: 1, idle: 4 },
    scheduledJobs: [],
    recentFailures: [],
    timestamp: new Date().toISOString(),
  });
}

// POST /api/admin/jobs/:id/retry
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { action, jobId } = body;
  switch (action) {
    case 'retry': return NextResponse.json({ retried: true, jobId });
    case 'cancel': return NextResponse.json({ cancelled: true, jobId });
    case 'pause': return NextResponse.json({ paused: true });
    case 'resume': return NextResponse.json({ resumed: true });
    default: return NextResponse.json({ error: 'Unknown action' }, { status: 400 });
  }
}
DASHEOF
)
    _bjs_write_file "${project_dir}/src/app/api/admin/jobs/route.ts" "$dash_ts"
    BJS_GENERATED=$((BJS_GENERATED + 1))
    return 0
}

# =============================================================================
# _bjs_generate_retry
# =============================================================================
_bjs_generate_retry() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _bjs_log "Generating job retry logic..."

    local retry_ts
    retry_ts=$(cat <<'RETRYEOF'
// =============================================================================
// Job Retry Logic with Backoff Strategies
// =============================================================================

export type BackoffStrategy = 'exponential' | 'linear' | 'fixed';

export interface RetryConfig {
  maxAttempts: number;
  strategy: BackoffStrategy;
  baseDelayMs: number;
  maxDelayMs: number;
}

export const JOB_RETRY_CONFIGS: Record<string, RetryConfig> = {
  'email.send': { maxAttempts: 5, strategy: 'exponential', baseDelayMs: 2000, maxDelayMs: 300000 },
  'email.bulk': { maxAttempts: 3, strategy: 'exponential', baseDelayMs: 5000, maxDelayMs: 600000 },
  'report.generate': { maxAttempts: 2, strategy: 'fixed', baseDelayMs: 10000, maxDelayMs: 10000 },
  'export.csv': { maxAttempts: 3, strategy: 'linear', baseDelayMs: 5000, maxDelayMs: 30000 },
  'webhook.deliver': { maxAttempts: 10, strategy: 'exponential', baseDelayMs: 1000, maxDelayMs: 3600000 },
  'default': { maxAttempts: 3, strategy: 'exponential', baseDelayMs: 1000, maxDelayMs: 60000 },
};

export function calculateDelay(config: RetryConfig, attempt: number): number {
  let delay: number;
  switch (config.strategy) {
    case 'exponential':
      delay = config.baseDelayMs * Math.pow(2, attempt - 1);
      delay *= 0.5 + Math.random(); // jitter
      break;
    case 'linear':
      delay = config.baseDelayMs * attempt;
      break;
    case 'fixed':
    default:
      delay = config.baseDelayMs;
  }
  return Math.min(delay, config.maxDelayMs);
}

export function getRetryConfig(jobType: string): RetryConfig {
  return JOB_RETRY_CONFIGS[jobType] || JOB_RETRY_CONFIGS['default'];
}

export function shouldRetry(jobType: string, attempt: number): boolean {
  const config = getRetryConfig(jobType);
  return attempt < config.maxAttempts;
}
RETRYEOF
)
    _bjs_write_file "${project_dir}/src/lib/jobs/retry.ts" "$retry_ts"
    BJS_GENERATED=$((BJS_GENERATED + 1))
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
bjs_report() {
    echo -e "\n  ${BOLD:-}=== background-job-system v${BJS_VERSION} ===${NC:-}"
    echo -e "  生成数: ${BJS_GENERATED}"; echo -e "  エラー: ${BJS_ERRORS}"
}

bjs_score() {
    if [[ ${BJS_GENERATED} -ge 4 ]] && [[ ${BJS_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${BJS_GENERATED} -gt 0 ]] && [[ ${BJS_ERRORS} -eq 0 ]]; then echo "85"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "background-job-system" --version "${BJS_VERSION}" \
        --description "バックグラウンドジョブ×ワーカー×スケジューラー×ダッシュボード" \
        --init "bjs_init" --report "bjs_report" --score "bjs_score" \
        --enable-var "ENABLE_BACKGROUND_JOBS" --cli-flags "--background-jobs:--no-background-jobs"
fi

# v2003.1: source時のexit codeを確実に0にする
true
