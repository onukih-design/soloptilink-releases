#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - Backup & Recovery Engine
# =============================================================================
# バックアップ×リカバリ×S3同期×ローテーション×監視アラート
#
# 機能:
#   - DBバックアップスクリプト（pg_dump / sqlite3 / mysqldump）
#   - Cron自動バックアップスケジューリング
#   - ローテーションポリシー（daily 7日 / weekly 4週 / monthly 12ヶ月）
#   - ポイントインタイムリストア（検証付き）
#   - S3/R2オフサイト同期（暗号化）
#   - バックアップ成功/失敗アラート
#
# 全globals: BR_ prefix
# =============================================================================

[[ -n "${_BR_LOADED:-}" ]] && return 0; _BR_LOADED=1

# =============================================================================
# State
# =============================================================================
BR_VERSION="140.0"
BR_GENERATED=0
BR_ERRORS=0
BR_PHASE="backup"
BR_FILES_CREATED=()

# =============================================================================
# Helper
# =============================================================================
_br_write_file() {
    local filepath="$1"
    local content="$2"
    local dir
    dir="$(dirname "$filepath")"
    mkdir -p "$dir" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        BR_FILES_CREATED+=("$filepath")
        BR_GENERATED=$((BR_GENERATED + 1))
        echo -e "  ${GREEN:-\033[0;32m}[BR]${NC:-\033[0m} Created: ${filepath##*/}"
    else
        BR_ERRORS=$((BR_ERRORS + 1))
        echo -e "  ${RED:-\033[0;31m}[BR]${NC:-\033[0m} Failed: ${filepath##*/}"
    fi
}

_br_write_executable() {
    _br_write_file "$1" "$2"
    chmod +x "$1" 2>/dev/null
}

# =============================================================================
# 初期化
# =============================================================================
br_init() {
    BR_GENERATED=0
    BR_ERRORS=0
    BR_FILES_CREATED=()
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} Backup & Recovery Engine v${BR_VERSION}"
    return 0
}

# =============================================================================
# Database Backup Script (pg_dump / sqlite3 / mysqldump)
# =============================================================================
br_generate_db_backup() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local db="${2:-postgres}"
    local target="${project_dir}/scripts/backup.sh"

    _br_write_executable "$target" "$(cat <<'BASH'
#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# Database Backup Script
# =============================================================================
# Usage: ./scripts/backup.sh [daily|weekly|monthly] [--upload]
# =============================================================================

BACKUP_TYPE="${1:-daily}"
UPLOAD="${2:-}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BACKUP_DIR="${BACKUP_DIR:-./backups}"
DB_TYPE="${DB_TYPE:-postgres}"

mkdir -p "${BACKUP_DIR}/${BACKUP_TYPE}"

BACKUP_FILE="${BACKUP_DIR}/${BACKUP_TYPE}/backup_${TIMESTAMP}"
LOG_FILE="${BACKUP_DIR}/backup.log"

log() {
    echo "[$(date -Iseconds)] $*" | tee -a "$LOG_FILE"
}

backup_postgres() {
    local dump_file="${BACKUP_FILE}.sql.gz"
    log "Starting PostgreSQL backup..."

    if [[ -z "${DATABASE_URL:-}" ]]; then
        log "ERROR: DATABASE_URL not set"
        return 1
    fi

    pg_dump "$DATABASE_URL" \
        --no-owner \
        --no-privileges \
        --clean \
        --if-exists \
        --format=custom \
        --compress=9 \
        -f "${BACKUP_FILE}.dump" 2>>"$LOG_FILE"

    if [[ $? -eq 0 ]]; then
        local size
        size=$(du -h "${BACKUP_FILE}.dump" | cut -f1)
        log "PostgreSQL backup complete: ${BACKUP_FILE}.dump (${size})"
        echo "${BACKUP_FILE}.dump"
    else
        log "ERROR: PostgreSQL backup failed"
        return 1
    fi
}

backup_sqlite() {
    local db_path="${SQLITE_PATH:-./prisma/dev.db}"
    local dump_file="${BACKUP_FILE}.sqlite.gz"
    log "Starting SQLite backup..."

    if [[ ! -f "$db_path" ]]; then
        log "ERROR: SQLite database not found: ${db_path}"
        return 1
    fi

    # Use .backup for online-safe backup
    sqlite3 "$db_path" ".backup '${BACKUP_FILE}.sqlite'"
    gzip "${BACKUP_FILE}.sqlite"

    local size
    size=$(du -h "$dump_file" | cut -f1)
    log "SQLite backup complete: ${dump_file} (${size})"
    echo "$dump_file"
}

backup_mysql() {
    local dump_file="${BACKUP_FILE}.sql.gz"
    log "Starting MySQL backup..."

    mysqldump \
        --host="${DB_HOST:-localhost}" \
        --port="${DB_PORT:-3306}" \
        --user="${DB_USER:-root}" \
        --password="${DB_PASSWORD:-}" \
        --single-transaction \
        --routines \
        --triggers \
        --databases "${DB_NAME:-app}" \
        2>>"$LOG_FILE" | gzip > "$dump_file"

    local size
    size=$(du -h "$dump_file" | cut -f1)
    log "MySQL backup complete: ${dump_file} (${size})"
    echo "$dump_file"
}

# Compute SHA256 checksum
compute_checksum() {
    local file="$1"
    if command -v sha256sum &>/dev/null; then
        sha256sum "$file" | awk '{print $1}' > "${file}.sha256"
    elif command -v shasum &>/dev/null; then
        shasum -a 256 "$file" | awk '{print $1}' > "${file}.sha256"
    fi
    log "Checksum: ${file}.sha256"
}

# Main
log "========================================="
log "Backup started: type=${BACKUP_TYPE} db=${DB_TYPE}"

case "$DB_TYPE" in
    postgres|postgresql) RESULT=$(backup_postgres) ;;
    sqlite|sqlite3)      RESULT=$(backup_sqlite) ;;
    mysql|mariadb)       RESULT=$(backup_mysql) ;;
    *)
        log "ERROR: Unknown DB type: ${DB_TYPE}"
        exit 1
        ;;
esac

if [[ -n "$RESULT" ]]; then
    compute_checksum "$RESULT"

    if [[ "$UPLOAD" == "--upload" ]]; then
        log "Uploading to S3..."
        if command -v aws &>/dev/null; then
            aws s3 cp "$RESULT" "s3://${S3_BACKUP_BUCKET:-backups}/db/${BACKUP_TYPE}/" --sse AES256
            aws s3 cp "${RESULT}.sha256" "s3://${S3_BACKUP_BUCKET:-backups}/db/${BACKUP_TYPE}/"
            log "Upload complete"
        else
            log "WARN: aws CLI not found, skipping upload"
        fi
    fi

    log "Backup completed successfully"
else
    log "ERROR: Backup failed"
    exit 1
fi
BASH
)"
}

# =============================================================================
# Scheduled Backup (Cron)
# =============================================================================
br_generate_scheduled_backup() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/scripts/setup-backup-cron.sh"

    _br_write_executable "$target" "$(cat <<'BASH'
#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# Setup Backup Cron Jobs
# =============================================================================
# Installs cron entries for daily/weekly/monthly backups
# =============================================================================

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$(dirname "$SCRIPT_DIR")"

echo "Setting up backup cron jobs..."

# Remove existing backup cron entries
crontab -l 2>/dev/null | grep -v "backup.sh" > /tmp/crontab_clean || true

# Add new entries
cat >> /tmp/crontab_clean <<CRON
# SoloptiLinkAI Daily Backup - 2:00 AM
0 2 * * * cd ${PROJECT_DIR} && ./scripts/backup.sh daily --upload >> ./backups/cron.log 2>&1

# SoloptiLinkAI Weekly Backup - Sunday 3:00 AM
0 3 * * 0 cd ${PROJECT_DIR} && ./scripts/backup.sh weekly --upload >> ./backups/cron.log 2>&1

# SoloptiLinkAI Monthly Backup - 1st of month 4:00 AM
0 4 1 * * cd ${PROJECT_DIR} && ./scripts/backup.sh monthly --upload >> ./backups/cron.log 2>&1

# SoloptiLinkAI Backup Rotation - daily 5:00 AM
0 5 * * * cd ${PROJECT_DIR} && ./scripts/rotate-backups.sh >> ./backups/cron.log 2>&1
CRON

crontab /tmp/crontab_clean
rm -f /tmp/crontab_clean

echo "Cron jobs installed:"
crontab -l | grep "backup"
echo "Done."
BASH
)"
}

# =============================================================================
# Backup Rotation (7 daily / 4 weekly / 12 monthly)
# =============================================================================
br_generate_backup_rotation() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/scripts/rotate-backups.sh"

    _br_write_executable "$target" "$(cat <<'BASH'
#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# Backup Rotation Policy
# =============================================================================
# daily:   keep 7 days
# weekly:  keep 4 weeks
# monthly: keep 12 months
# =============================================================================

BACKUP_DIR="${BACKUP_DIR:-./backups}"
LOG_FILE="${BACKUP_DIR}/rotation.log"

log() {
    echo "[$(date -Iseconds)] $*" | tee -a "$LOG_FILE"
}

rotate() {
    local type="$1"
    local keep_days="$2"
    local dir="${BACKUP_DIR}/${type}"

    [[ ! -d "$dir" ]] && return 0

    log "Rotating ${type}: keeping ${keep_days} days"

    local count=0
    while IFS= read -r -d '' file; do
        rm -f "$file" "${file}.sha256"
        count=$((count + 1))
    done < <(find "$dir" -type f -name "backup_*" -mtime +${keep_days} -print0 2>/dev/null)

    log "Removed ${count} old ${type} backups"
}

log "========================================="
log "Starting backup rotation"

rotate "daily" 7
rotate "weekly" 28
rotate "monthly" 365

# Report disk usage
if [[ -d "$BACKUP_DIR" ]]; then
    local usage
    usage=$(du -sh "$BACKUP_DIR" 2>/dev/null | cut -f1)
    log "Total backup size: ${usage}"
fi

log "Rotation complete"
BASH
)"
}

# =============================================================================
# Restore Script (Point-in-Time with Validation)
# =============================================================================
br_generate_restore_script() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/scripts/restore.sh"

    _br_write_executable "$target" "$(cat <<'BASH'
#!/usr/bin/env bash
set -euo pipefail

# =============================================================================
# Database Restore Script
# =============================================================================
# Usage: ./scripts/restore.sh <backup_file> [--verify-only]
# =============================================================================

BACKUP_FILE="${1:-}"
VERIFY_ONLY="${2:-}"
DB_TYPE="${DB_TYPE:-postgres}"
LOG_FILE="${BACKUP_DIR:-./backups}/restore.log"

if [[ -z "$BACKUP_FILE" ]]; then
    echo "Usage: $0 <backup_file> [--verify-only]"
    echo ""
    echo "Available backups:"
    find "${BACKUP_DIR:-./backups}" -name "backup_*" -type f ! -name "*.sha256" | sort -r | head -20
    exit 1
fi

if [[ ! -f "$BACKUP_FILE" ]]; then
    echo "ERROR: Backup file not found: $BACKUP_FILE"
    exit 1
fi

log() {
    echo "[$(date -Iseconds)] $*" | tee -a "$LOG_FILE"
}

verify_checksum() {
    local file="$1"
    local checksum_file="${file}.sha256"

    if [[ ! -f "$checksum_file" ]]; then
        log "WARN: No checksum file found for ${file}"
        return 0
    fi

    local expected
    expected=$(cat "$checksum_file")
    local actual
    if command -v sha256sum &>/dev/null; then
        actual=$(sha256sum "$file" | awk '{print $1}')
    elif command -v shasum &>/dev/null; then
        actual=$(shasum -a 256 "$file" | awk '{print $1}')
    else
        log "WARN: No sha256 tool available"
        return 0
    fi

    if [[ "$expected" == "$actual" ]]; then
        log "Checksum verified: OK"
        return 0
    else
        log "ERROR: Checksum mismatch! expected=${expected} actual=${actual}"
        return 1
    fi
}

restore_postgres() {
    local file="$1"
    log "Restoring PostgreSQL from ${file}..."

    if [[ -z "${DATABASE_URL:-}" ]]; then
        log "ERROR: DATABASE_URL not set"
        return 1
    fi

    pg_restore \
        --dbname="$DATABASE_URL" \
        --clean \
        --if-exists \
        --no-owner \
        --no-privileges \
        "$file" 2>>"$LOG_FILE"

    log "PostgreSQL restore complete"
}

restore_sqlite() {
    local file="$1"
    local db_path="${SQLITE_PATH:-./prisma/dev.db}"
    log "Restoring SQLite from ${file}..."

    # Create backup of current DB
    if [[ -f "$db_path" ]]; then
        cp "$db_path" "${db_path}.pre-restore.bak"
        log "Current DB backed up to ${db_path}.pre-restore.bak"
    fi

    if [[ "$file" == *.gz ]]; then
        gunzip -c "$file" > "$db_path"
    else
        cp "$file" "$db_path"
    fi

    # Verify integrity
    local integrity
    integrity=$(sqlite3 "$db_path" "PRAGMA integrity_check;" 2>&1)
    if [[ "$integrity" == "ok" ]]; then
        log "SQLite restore complete - integrity check passed"
    else
        log "ERROR: Integrity check failed: ${integrity}"
        # Rollback
        if [[ -f "${db_path}.pre-restore.bak" ]]; then
            mv "${db_path}.pre-restore.bak" "$db_path"
            log "Rolled back to previous database"
        fi
        return 1
    fi
}

restore_mysql() {
    local file="$1"
    log "Restoring MySQL from ${file}..."

    if [[ "$file" == *.gz ]]; then
        gunzip -c "$file" | mysql \
            --host="${DB_HOST:-localhost}" \
            --port="${DB_PORT:-3306}" \
            --user="${DB_USER:-root}" \
            --password="${DB_PASSWORD:-}" \
            2>>"$LOG_FILE"
    else
        mysql \
            --host="${DB_HOST:-localhost}" \
            --port="${DB_PORT:-3306}" \
            --user="${DB_USER:-root}" \
            --password="${DB_PASSWORD:-}" \
            < "$file" 2>>"$LOG_FILE"
    fi

    log "MySQL restore complete"
}

# Main
log "========================================="
log "Restore started: file=${BACKUP_FILE} db=${DB_TYPE}"

# Step 1: Verify checksum
verify_checksum "$BACKUP_FILE" || exit 1

if [[ "$VERIFY_ONLY" == "--verify-only" ]]; then
    log "Verification passed. Exiting (--verify-only mode)."
    exit 0
fi

# Step 2: Confirm
echo "WARNING: This will overwrite the current database!"
echo "Backup file: ${BACKUP_FILE}"
read -rp "Continue? (yes/no): " confirm
if [[ "$confirm" != "yes" ]]; then
    log "Restore cancelled by user"
    exit 0
fi

# Step 3: Restore
case "$DB_TYPE" in
    postgres|postgresql) restore_postgres "$BACKUP_FILE" ;;
    sqlite|sqlite3)      restore_sqlite "$BACKUP_FILE" ;;
    mysql|mariadb)       restore_mysql "$BACKUP_FILE" ;;
    *)
        log "ERROR: Unknown DB type: ${DB_TYPE}"
        exit 1
        ;;
esac

log "Restore completed successfully"
BASH
)"
}

# =============================================================================
# S3 Offsite Sync with Encryption
# =============================================================================
br_generate_s3_sync() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/lib/backup-s3-sync.ts"

    _br_write_file "$target" "$(cat <<'TYPESCRIPT'
import { S3Client, PutObjectCommand, ListObjectsV2Command, DeleteObjectCommand } from '@aws-sdk/client-s3';
import { createReadStream, statSync } from 'fs';
import { createHash, createCipheriv, randomBytes } from 'crypto';
import { readdir } from 'fs/promises';
import path from 'path';

const s3 = new S3Client({ region: process.env.S3_REGION || 'ap-northeast-1' });
const BUCKET = process.env.S3_BACKUP_BUCKET || 'backups';
const ENCRYPTION_KEY = process.env.BACKUP_ENCRYPTION_KEY || '';

export async function syncBackupsToS3(localDir: string, prefix = 'db-backups/'): Promise<{ uploaded: number; errors: number }> {
  let uploaded = 0;
  let errors = 0;

  const files = await readdir(localDir, { recursive: true });

  for (const file of files) {
    const filePath = path.join(localDir, file.toString());
    try {
      const stat = statSync(filePath);
      if (!stat.isFile()) continue;

      const key = `${prefix}${file}`;
      let body: Buffer | NodeJS.ReadableStream = createReadStream(filePath);

      // Encrypt if key provided
      if (ENCRYPTION_KEY) {
        const iv = randomBytes(16);
        const keyHash = createHash('sha256').update(ENCRYPTION_KEY).digest();
        const cipher = createCipheriv('aes-256-cbc', keyHash, iv);
        // For simplicity, read entire file for encryption
        const { readFileSync } = require('fs');
        const plaintext = readFileSync(filePath);
        const encrypted = Buffer.concat([iv, cipher.update(plaintext), cipher.final()]);
        body = encrypted;
      }

      await s3.send(new PutObjectCommand({
        Bucket: BUCKET,
        Key: key,
        Body: body,
        ServerSideEncryption: 'AES256',
        Metadata: { 'backup-date': new Date().toISOString() },
      }));

      uploaded++;
    } catch (error) {
      console.error(`Failed to sync ${file}:`, error);
      errors++;
    }
  }

  return { uploaded, errors };
}

export async function cleanupRemoteBackups(prefix: string, keepDays: number): Promise<number> {
  const cutoff = new Date(Date.now() - keepDays * 24 * 60 * 60 * 1000);
  let deleted = 0;

  const response = await s3.send(new ListObjectsV2Command({ Bucket: BUCKET, Prefix: prefix }));
  for (const obj of response.Contents || []) {
    if (obj.LastModified && obj.LastModified < cutoff && obj.Key) {
      await s3.send(new DeleteObjectCommand({ Bucket: BUCKET, Key: obj.Key }));
      deleted++;
    }
  }

  return deleted;
}
TYPESCRIPT
)"
}

# =============================================================================
# Backup Monitoring / Alerting
# =============================================================================
br_generate_backup_monitoring() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/lib/backup-monitor.ts"

    _br_write_file "$target" "$(cat <<'TYPESCRIPT'
import { z } from 'zod';

const BackupStatusSchema = z.object({
  type: z.enum(['daily', 'weekly', 'monthly']),
  status: z.enum(['success', 'failure', 'running', 'skipped']),
  startedAt: z.date(),
  completedAt: z.date().optional(),
  sizeBytes: z.number().optional(),
  error: z.string().optional(),
  checksum: z.string().optional(),
});

type BackupStatus = z.infer<typeof BackupStatusSchema>;

interface AlertConfig {
  webhookUrl?: string;       // Slack/Discord webhook
  emailTo?: string;          // Email alert
  failureThreshold: number;  // Alert after N consecutive failures
}

const defaultConfig: AlertConfig = {
  webhookUrl: process.env.BACKUP_ALERT_WEBHOOK,
  emailTo: process.env.BACKUP_ALERT_EMAIL,
  failureThreshold: 2,
};

let consecutiveFailures = 0;

export async function reportBackupStatus(status: BackupStatus, config = defaultConfig): Promise<void> {
  console.log(`[Backup Monitor] ${status.type}: ${status.status}`, {
    size: status.sizeBytes ? `${(status.sizeBytes / 1024 / 1024).toFixed(2)}MB` : 'N/A',
    duration: status.completedAt && status.startedAt
      ? `${Math.round((status.completedAt.getTime() - status.startedAt.getTime()) / 1000)}s`
      : 'N/A',
  });

  if (status.status === 'failure') {
    consecutiveFailures++;
    if (consecutiveFailures >= config.failureThreshold) {
      await sendAlert(status, config);
    }
  } else if (status.status === 'success') {
    if (consecutiveFailures > 0) {
      // Recovery notification
      await sendRecoveryAlert(status, config);
    }
    consecutiveFailures = 0;
  }
}

async function sendAlert(status: BackupStatus, config: AlertConfig): Promise<void> {
  const message = `[ALERT] Backup ${status.type} failed (${consecutiveFailures} consecutive failures)\nError: ${status.error || 'Unknown'}\nTime: ${status.startedAt.toISOString()}`;

  // Slack/Discord webhook
  if (config.webhookUrl) {
    try {
      await fetch(config.webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: message, content: message }),
      });
    } catch (e) {
      console.error('[Backup Monitor] Webhook failed:', e);
    }
  }

  // Console always
  console.error(message);
}

async function sendRecoveryAlert(status: BackupStatus, config: AlertConfig): Promise<void> {
  const message = `[RECOVERY] Backup ${status.type} recovered after ${consecutiveFailures} failures.\nSize: ${status.sizeBytes ? `${(status.sizeBytes / 1024 / 1024).toFixed(2)}MB` : 'N/A'}`;

  if (config.webhookUrl) {
    try {
      await fetch(config.webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: message, content: message }),
      });
    } catch (e) {
      console.error('[Backup Monitor] Recovery webhook failed:', e);
    }
  }

  console.log(message);
}

export async function getBackupHealth(): Promise<{
  status: 'healthy' | 'degraded' | 'critical';
  consecutiveFailures: number;
  lastCheck: string;
}> {
  return {
    status: consecutiveFailures === 0 ? 'healthy' : consecutiveFailures < 3 ? 'degraded' : 'critical',
    consecutiveFailures,
    lastCheck: new Date().toISOString(),
  };
}
TYPESCRIPT
)"
}

# =============================================================================
# Inject backup patterns into Claude prompt
# =============================================================================
br_inject_backup_patterns() {
    local prompt="${1:-}"

    cat <<'PATTERNS'

## [BACKUP] バックアップ&リカバリパターン（必須準拠）

### バックアップスクリプト
- `./scripts/backup.sh daily --upload` - 日次バックアップ+S3同期
- pg_dump (PostgreSQL) / sqlite3 .backup (SQLite) / mysqldump (MySQL)
- SHA256チェックサム付き

### スケジューリング
- daily: 毎日 2:00 AM
- weekly: 毎週日曜 3:00 AM
- monthly: 毎月1日 4:00 AM

### ローテーション
- daily: 7日間保持
- weekly: 4週間保持
- monthly: 12ヶ月保持

### リストア
- `./scripts/restore.sh <file> [--verify-only]`
- チェックサム検証 → 確認プロンプト → リストア → 整合性検証
- 失敗時ロールバック（SQLite）

### オフサイト同期
- S3/R2 に AES256 暗号化アップロード
- リモート古いバックアップ自動削除

### 監視
- 連続失敗でWebhookアラート
- 復旧時に自動通知
PATTERNS

    echo "$prompt"
}

# =============================================================================
# Report
# =============================================================================
br_report() {
    echo -e "\n  ${BOLD:-}=== Backup & Recovery Engine v${BR_VERSION} ===${NC:-}"
    echo -e "  生成数: ${BR_GENERATED}"
    echo -e "  エラー: ${BR_ERRORS}"
    if [[ ${#BR_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${BR_FILES_CREATED[@]}"; do
            echo -e "    - ${f}"
        done
    fi
}

br_score() {
    if [[ ${BR_GENERATED} -ge 5 ]] && [[ ${BR_ERRORS} -eq 0 ]]; then
        echo "95"
    elif [[ ${BR_GENERATED} -gt 0 ]] && [[ ${BR_ERRORS} -eq 0 ]]; then
        echo "90"
    elif [[ ${BR_GENERATED} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "backup-recovery" --version "140.0" \
        --description "バックアップ×リカバリ×S3同期×ローテーション×監視アラート" \
        --init "br_init" --report "br_report" --score "br_score" \
        --enable-var "ENABLE_BACKUP" --cli-flags "--backup:--no-backup"
fi

# v2003.1: source時のexit codeを確実に0にする
true
