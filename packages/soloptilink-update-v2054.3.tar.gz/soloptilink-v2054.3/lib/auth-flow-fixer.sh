#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v266.0 - Auth Flow Fixer
# =============================================================================
# 認証フローの問題（JWT期限、CORS、セッション管理、リダイレクトループ、
# ミドルウェアエラー）を検出・修正する。
#
# Functions:
#   _aff_init            - 初期化
#   _aff_fix_token_expiry - JWT トークン期限問題修正
#   _aff_fix_cors        - CORS 設定エラー修正
#   _aff_fix_session     - セッション管理エラー修正
#   _aff_fix_redirect    - 認証リダイレクトループ修正
#   _aff_fix_middleware  - 認証ミドルウェアエラー修正
#   _aff_report          - レポート出力
#   _aff_score           - モジュールスコア (0-100)
#
# All globals use the AFF_ prefix.
# =============================================================================

[[ -n "${_AUTH_FLOW_FIXER_LOADED:-}" ]] && return 0
_AUTH_FLOW_FIXER_LOADED=1

AFF_VERSION="266.0"
AFF_INITIALIZED=false

# Counters
AFF_TOKEN_FIXED=0
AFF_CORS_FIXED=0
AFF_SESSION_FIXED=0
AFF_REDIRECT_FIXED=0
AFF_MIDDLEWARE_FIXED=0
AFF_TOTAL_ISSUES=0

# Storage
AFF_CACHE_DIR=""

# Issue arrays
declare -g -a _AFF_TOKEN_ISSUES=()
declare -g -a _AFF_CORS_ISSUES=()
declare -g -a _AFF_SESSION_ISSUES=()
declare -g -a _AFF_REDIRECT_ISSUES=()
declare -g -a _AFF_MIDDLEWARE_ISSUES=()

# Colors
_AFF_GREEN='\033[0;32m'
_AFF_YELLOW='\033[0;33m'
_AFF_RED='\033[0;31m'
_AFF_CYAN='\033[0;36m'
_AFF_BOLD='\033[1m'
_AFF_NC='\033[0m'

# =============================================================================
# _aff_init - Initialize auth flow fixer
# =============================================================================
_aff_init() {
    AFF_CACHE_DIR="${HOME}/.soloptilink/auth-flow"
    mkdir -p "$AFF_CACHE_DIR" 2>/dev/null || true

    AFF_TOKEN_FIXED=0
    AFF_CORS_FIXED=0
    AFF_SESSION_FIXED=0
    AFF_REDIRECT_FIXED=0
    AFF_MIDDLEWARE_FIXED=0
    AFF_TOTAL_ISSUES=0

    _AFF_TOKEN_ISSUES=()
    _AFF_CORS_ISSUES=()
    _AFF_SESSION_ISSUES=()
    _AFF_REDIRECT_ISSUES=()
    _AFF_MIDDLEWARE_ISSUES=()

    AFF_INITIALIZED=true
    return 0
}

# =============================================================================
# _aff_find_auth_files - Find authentication-related files
# =============================================================================
_aff_find_auth_files() {
    local project_dir="${1:-.}"
    find "$project_dir" \
        \( -name "auth*" -o -name "*auth*" -o -name "middleware*" -o -name "*session*" -o -name "*jwt*" -o -name "*token*" \) \
        \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        -not -path "*/dist/*" \
        2>/dev/null | head -50
}

# =============================================================================
# _aff_fix_token_expiry - Fix JWT token expiry issues
# =============================================================================
_aff_fix_token_expiry() {
    local project_dir="${1:-.}"

    echo -e "${_AFF_CYAN}[AFF]${_AFF_NC} JWT トークン期限問題を検査中..." >&2
    _AFF_TOKEN_ISSUES=()

    # Find all files that deal with JWT
    local source_files
    source_files=$(find "$project_dir" -name "*.ts" -o -name "*.js" 2>/dev/null | grep -vE 'node_modules|\.next|dist' | head -200)

    [[ -z "$source_files" ]] && return 0

    while IFS= read -r file; do
        [[ ! -f "$file" ]] && continue

        # Check for JWT sign without expiresIn
        if grep -qE 'jwt\.sign|jsonwebtoken.*sign|jose.*sign' "$file" 2>/dev/null; then
            if ! grep -qE 'expiresIn|exp:|maxAge' "$file" 2>/dev/null; then
                _AFF_TOKEN_ISSUES+=("NO_EXPIRY:${file}:JWT sign without expiresIn")
                echo -e "${_AFF_RED}[AFF]${_AFF_NC}   JWT sign without expiresIn: ${file}" >&2
                AFF_TOKEN_FIXED=$((AFF_TOKEN_FIXED + 1))
            fi
        fi

        # Check for very long token expiry (> 24h for access token)
        if grep -qE "expiresIn.*['\"]([0-9]+d|[0-9]{5,})" "$file" 2>/dev/null; then
            _AFF_TOKEN_ISSUES+=("LONG_EXPIRY:${file}:Token expiry too long")
            echo -e "${_AFF_YELLOW}[AFF]${_AFF_NC}   トークン有効期限が長すぎます: ${file}" >&2
            AFF_TOKEN_FIXED=$((AFF_TOKEN_FIXED + 1))
        fi

        # Check for missing refresh token logic
        if grep -qE 'jwt\.sign|jsonwebtoken' "$file" 2>/dev/null; then
            if ! grep -qE 'refresh.*token|refreshToken|refresh_token' "$file" 2>/dev/null; then
                _AFF_TOKEN_ISSUES+=("NO_REFRESH:${file}:Missing refresh token mechanism")
                echo -e "${_AFF_YELLOW}[AFF]${_AFF_NC}   リフレッシュトークン未実装: ${file}" >&2
            fi
        fi

        # Check for token stored in localStorage (security risk)
        if grep -qE 'localStorage\.(setItem|getItem).*token' "$file" 2>/dev/null; then
            _AFF_TOKEN_ISSUES+=("LOCALSTORAGE_TOKEN:${file}:Token in localStorage (XSS risk)")
            echo -e "${_AFF_RED}[AFF]${_AFF_NC}   localStorage にトークン保存（XSSリスク）: ${file}" >&2
            AFF_TOKEN_FIXED=$((AFF_TOKEN_FIXED + 1))
        fi

        # Check for missing token validation
        if grep -qE 'jwt\.verify|jsonwebtoken.*verify' "$file" 2>/dev/null; then
            if ! grep -qE 'try.*catch|\.catch' "$file" 2>/dev/null; then
                _AFF_TOKEN_ISSUES+=("NO_VERIFY_CATCH:${file}:JWT verify without error handling")
                echo -e "${_AFF_YELLOW}[AFF]${_AFF_NC}   JWT検証にエラーハンドリングなし: ${file}" >&2
                AFF_TOKEN_FIXED=$((AFF_TOKEN_FIXED + 1))
            fi
        fi

        # Check for hardcoded JWT secret
        if grep -qE "(jwt_secret|JWT_SECRET|secret)\s*[:=]\s*['\"][^'\"]{5,}['\"]" "$file" 2>/dev/null; then
            if ! grep -qE 'process\.env|env\.' "$file" 2>/dev/null; then
                _AFF_TOKEN_ISSUES+=("HARDCODED_SECRET:${file}:Hardcoded JWT secret")
                echo -e "${_AFF_RED}[AFF]${_AFF_NC}   JWTシークレットがハードコード: ${file}" >&2
                AFF_TOKEN_FIXED=$((AFF_TOKEN_FIXED + 1))
            fi
        fi
    done <<< "$source_files"

    return 0
}

# =============================================================================
# _aff_fix_cors - Fix CORS configuration errors
# =============================================================================
_aff_fix_cors() {
    local project_dir="${1:-.}"

    echo -e "${_AFF_CYAN}[AFF]${_AFF_NC} CORS 設定を検査中..." >&2
    _AFF_CORS_ISSUES=()

    local source_files
    source_files=$(find "$project_dir" -name "*.ts" -o -name "*.js" -o -name "*.json" 2>/dev/null | grep -vE 'node_modules|\.next|dist' | head -200)

    while IFS= read -r file; do
        [[ ! -f "$file" ]] && continue

        # Check for wildcard CORS origin
        if grep -qE "origin.*['\"]\\*['\"]|Access-Control-Allow-Origin.*\\*" "$file" 2>/dev/null; then
            _AFF_CORS_ISSUES+=("WILDCARD_ORIGIN:${file}")
            echo -e "${_AFF_RED}[AFF]${_AFF_NC}   CORS ワイルドカード origin: ${file}" >&2
            AFF_CORS_FIXED=$((AFF_CORS_FIXED + 1))
        fi

        # Check for credentials with wildcard origin
        if grep -qE 'credentials.*true' "$file" 2>/dev/null; then
            if grep -qE "origin.*\\*" "$file" 2>/dev/null; then
                _AFF_CORS_ISSUES+=("CREDENTIALS_WILDCARD:${file}")
                echo -e "${_AFF_RED}[AFF]${_AFF_NC}   credentials:true + wildcard origin（ブラウザ拒否）: ${file}" >&2
                AFF_CORS_FIXED=$((AFF_CORS_FIXED + 1))
            fi
        fi

        # Check for missing CORS headers in API routes
        if echo "$file" | grep -qE 'route\.(ts|js)$'; then
            if grep -qE 'function (GET|POST|PUT|DELETE)' "$file" 2>/dev/null; then
                if ! grep -qE 'Access-Control|cors|CORS' "$file" 2>/dev/null; then
                    # Check if there's a middleware handling it
                    local middleware_file="${project_dir}/middleware.ts"
                    if [[ ! -f "$middleware_file" ]] || ! grep -qE 'cors|CORS|Access-Control' "$middleware_file" 2>/dev/null; then
                        _AFF_CORS_ISSUES+=("MISSING_CORS:${file}")
                        echo -e "${_AFF_YELLOW}[AFF]${_AFF_NC}   CORS 未設定: ${file}" >&2
                    fi
                fi
            fi
        fi

        # Check for missing OPTIONS handler
        if echo "$file" | grep -qE 'route\.(ts|js)$'; then
            if grep -qE 'function POST|function PUT|function DELETE' "$file" 2>/dev/null; then
                if ! grep -qE 'function OPTIONS|OPTIONS' "$file" 2>/dev/null; then
                    _AFF_CORS_ISSUES+=("NO_OPTIONS:${file}")
                    echo -e "${_AFF_YELLOW}[AFF]${_AFF_NC}   OPTIONS ハンドラ未定義: ${file}" >&2
                fi
            fi
        fi
    done <<< "$source_files"

    # Check next.config for CORS headers
    local next_config="${project_dir}/next.config.js"
    [[ ! -f "$next_config" ]] && next_config="${project_dir}/next.config.mjs"
    [[ ! -f "$next_config" ]] && next_config="${project_dir}/next.config.ts"

    if [[ -f "$next_config" ]]; then
        if ! grep -qE 'headers|Access-Control' "$next_config" 2>/dev/null; then
            echo -e "${_AFF_YELLOW}[AFF]${_AFF_NC}   next.config に CORS headers 未設定" >&2
        fi
    fi

    return 0
}

# =============================================================================
# _aff_fix_session - Fix session management errors
# =============================================================================
_aff_fix_session() {
    local project_dir="${1:-.}"

    echo -e "${_AFF_CYAN}[AFF]${_AFF_NC} セッション管理を検査中..." >&2
    _AFF_SESSION_ISSUES=()

    local source_files
    source_files=$(find "$project_dir" -name "*.ts" -o -name "*.js" 2>/dev/null | grep -vE 'node_modules|\.next|dist' | head -200)

    while IFS= read -r file; do
        [[ ! -f "$file" ]] && continue

        # Check for session without secure cookie settings
        if grep -qE 'cookie|session' "$file" 2>/dev/null; then
            if grep -qE 'httpOnly.*false|HttpOnly.*false' "$file" 2>/dev/null; then
                _AFF_SESSION_ISSUES+=("INSECURE_COOKIE:${file}:httpOnly=false")
                echo -e "${_AFF_RED}[AFF]${_AFF_NC}   httpOnly=false（XSSリスク）: ${file}" >&2
                AFF_SESSION_FIXED=$((AFF_SESSION_FIXED + 1))
            fi

            if grep -qE 'secure.*false' "$file" 2>/dev/null; then
                _AFF_SESSION_ISSUES+=("NO_SECURE:${file}:secure=false")
                echo -e "${_AFF_YELLOW}[AFF]${_AFF_NC}   secure=false（HTTPS未強制）: ${file}" >&2
                AFF_SESSION_FIXED=$((AFF_SESSION_FIXED + 1))
            fi

            # Check for missing sameSite
            if grep -qE 'Set-Cookie|setCookie|cookie' "$file" 2>/dev/null; then
                if ! grep -qE 'sameSite|SameSite' "$file" 2>/dev/null; then
                    _AFF_SESSION_ISSUES+=("NO_SAMESITE:${file}")
                    echo -e "${_AFF_YELLOW}[AFF]${_AFF_NC}   SameSite 未設定: ${file}" >&2
                    AFF_SESSION_FIXED=$((AFF_SESSION_FIXED + 1))
                fi
            fi
        fi

        # Check for session fixation vulnerability
        if grep -qE 'session\.(id|sessionId)\s*=' "$file" 2>/dev/null; then
            _AFF_SESSION_ISSUES+=("SESSION_FIXATION:${file}")
            echo -e "${_AFF_RED}[AFF]${_AFF_NC}   セッション固定の脆弱性: ${file}" >&2
            AFF_SESSION_FIXED=$((AFF_SESSION_FIXED + 1))
        fi
    done <<< "$source_files"

    return 0
}

# =============================================================================
# _aff_fix_redirect - Fix auth redirect loops
# =============================================================================
_aff_fix_redirect() {
    local project_dir="${1:-.}"

    echo -e "${_AFF_CYAN}[AFF]${_AFF_NC} 認証リダイレクトループを検査中..." >&2
    _AFF_REDIRECT_ISSUES=()

    # Check middleware for redirect patterns
    local middleware_file="${project_dir}/middleware.ts"
    [[ ! -f "$middleware_file" ]] && middleware_file="${project_dir}/middleware.js"

    if [[ -f "$middleware_file" ]]; then
        # Check for redirect to login without excluding login route
        if grep -qE 'redirect.*login|redirect.*signin' "$middleware_file" 2>/dev/null; then
            if ! grep -qE 'pathname.*login|pathname.*signin|startsWith.*login|includes.*login' "$middleware_file" 2>/dev/null; then
                _AFF_REDIRECT_ISSUES+=("REDIRECT_LOOP:${middleware_file}:Login redirect without exclusion")
                echo -e "${_AFF_RED}[AFF]${_AFF_NC}   ログインリダイレクトにログインページ除外なし" >&2
                AFF_REDIRECT_FIXED=$((AFF_REDIRECT_FIXED + 1))
            fi
        fi

        # Check for redirect without preserving callback URL
        if grep -qE 'redirect.*login' "$middleware_file" 2>/dev/null; then
            if ! grep -qE 'callbackUrl|returnTo|redirectTo|from=' "$middleware_file" 2>/dev/null; then
                _AFF_REDIRECT_ISSUES+=("NO_CALLBACK:${middleware_file}:Missing callback URL preservation")
                echo -e "${_AFF_YELLOW}[AFF]${_AFF_NC}   コールバックURL未保存: ${middleware_file}" >&2
                AFF_REDIRECT_FIXED=$((AFF_REDIRECT_FIXED + 1))
            fi
        fi

        # Check for missing public routes exclusion
        if grep -qE 'redirect|NextResponse\.redirect' "$middleware_file" 2>/dev/null; then
            if ! grep -qE '(api/|_next/|static/|public/|favicon)' "$middleware_file" 2>/dev/null; then
                _AFF_REDIRECT_ISSUES+=("NO_PUBLIC_EXCLUSION:${middleware_file}")
                echo -e "${_AFF_YELLOW}[AFF]${_AFF_NC}   パブリックルート除外なし（API/静的ファイル）" >&2
                AFF_REDIRECT_FIXED=$((AFF_REDIRECT_FIXED + 1))
            fi
        fi
    fi

    # Check for client-side redirect issues
    local page_files
    page_files=$(find "$project_dir" -name "page.tsx" -o -name "page.jsx" 2>/dev/null | grep -vE 'node_modules|\.next' | head -30)

    while IFS= read -r file; do
        [[ ! -f "$file" ]] && continue

        # Check for redirect without loading state
        if grep -qE 'router\.push|router\.replace|redirect\(' "$file" 2>/dev/null; then
            if ! grep -qE 'loading|isLoading|isRedirecting' "$file" 2>/dev/null; then
                _AFF_REDIRECT_ISSUES+=("NO_LOADING_STATE:${file}")
                echo -e "${_AFF_YELLOW}[AFF]${_AFF_NC}   リダイレクト時のローディング状態なし: ${file}" >&2
            fi
        fi
    done <<< "$page_files"

    return 0
}

# =============================================================================
# _aff_fix_middleware - Fix auth middleware errors
# =============================================================================
_aff_fix_middleware() {
    local project_dir="${1:-.}"

    echo -e "${_AFF_CYAN}[AFF]${_AFF_NC} 認証ミドルウェアを検査中..." >&2
    _AFF_MIDDLEWARE_ISSUES=()

    local middleware_file="${project_dir}/middleware.ts"
    [[ ! -f "$middleware_file" ]] && middleware_file="${project_dir}/middleware.js"

    if [[ ! -f "$middleware_file" ]]; then
        # Check if project has auth but no middleware
        local has_auth
        has_auth=$(find "$project_dir" -name "*.ts" -o -name "*.js" 2>/dev/null | grep -vE 'node_modules|\.next' | head -100 | xargs grep -l 'jwt\|auth\|session' 2>/dev/null | head -1)
        if [[ -n "$has_auth" ]]; then
            _AFF_MIDDLEWARE_ISSUES+=("NO_MIDDLEWARE:Missing middleware.ts for auth")
            echo -e "${_AFF_YELLOW}[AFF]${_AFF_NC}   認証コードあり、middleware.ts なし" >&2
            AFF_MIDDLEWARE_FIXED=$((AFF_MIDDLEWARE_FIXED + 1))
        fi
        return 0
    fi

    # Check for missing matcher config
    if ! grep -qE 'config.*matcher|export const config' "$middleware_file" 2>/dev/null; then
        _AFF_MIDDLEWARE_ISSUES+=("NO_MATCHER:${middleware_file}:Missing matcher config")
        echo -e "${_AFF_YELLOW}[AFF]${_AFF_NC}   matcher 設定なし（全ルートに適用されます）" >&2
        AFF_MIDDLEWARE_FIXED=$((AFF_MIDDLEWARE_FIXED + 1))
    fi

    # Check for async middleware without await
    if grep -qE 'async.*middleware' "$middleware_file" 2>/dev/null; then
        if ! grep -qE 'await' "$middleware_file" 2>/dev/null; then
            _AFF_MIDDLEWARE_ISSUES+=("ASYNC_NO_AWAIT:${middleware_file}")
            echo -e "${_AFF_YELLOW}[AFF]${_AFF_NC}   async middleware に await なし" >&2
            AFF_MIDDLEWARE_FIXED=$((AFF_MIDDLEWARE_FIXED + 1))
        fi
    fi

    # Check for error handling in middleware
    if ! grep -qE 'try\s*\{|catch' "$middleware_file" 2>/dev/null; then
        _AFF_MIDDLEWARE_ISSUES+=("NO_ERROR_HANDLING:${middleware_file}")
        echo -e "${_AFF_YELLOW}[AFF]${_AFF_NC}   ミドルウェアにエラーハンドリングなし" >&2
        AFF_MIDDLEWARE_FIXED=$((AFF_MIDDLEWARE_FIXED + 1))
    fi

    # Check for NextResponse.next() fallback
    if ! grep -qE 'NextResponse\.next\(\)' "$middleware_file" 2>/dev/null; then
        _AFF_MIDDLEWARE_ISSUES+=("NO_NEXT_FALLBACK:${middleware_file}")
        echo -e "${_AFF_YELLOW}[AFF]${_AFF_NC}   NextResponse.next() フォールバックなし" >&2
        AFF_MIDDLEWARE_FIXED=$((AFF_MIDDLEWARE_FIXED + 1))
    fi

    return 0
}

# =============================================================================
# _aff_report - Report output
# =============================================================================
_aff_report() {
    AFF_TOTAL_ISSUES=$((AFF_TOKEN_FIXED + AFF_CORS_FIXED + AFF_SESSION_FIXED + AFF_REDIRECT_FIXED + AFF_MIDDLEWARE_FIXED))
    echo -e "\n  ${_AFF_BOLD}--- Auth Flow Fixer v${AFF_VERSION} ---${_AFF_NC}"
    echo -e "  トークン問題     : ${AFF_TOKEN_FIXED}"
    echo -e "  CORS問題         : ${AFF_CORS_FIXED}"
    echo -e "  セッション問題   : ${AFF_SESSION_FIXED}"
    echo -e "  リダイレクト問題 : ${AFF_REDIRECT_FIXED}"
    echo -e "  ミドルウェア問題 : ${AFF_MIDDLEWARE_FIXED}"
    echo -e "  合計問題         : ${AFF_TOTAL_ISSUES}"
}

# =============================================================================
# _aff_score - Module score (0-100)
# =============================================================================
_aff_score() {
    AFF_TOTAL_ISSUES=$((AFF_TOKEN_FIXED + AFF_CORS_FIXED + AFF_SESSION_FIXED + AFF_REDIRECT_FIXED + AFF_MIDDLEWARE_FIXED))
    if [[ $AFF_TOTAL_ISSUES -eq 0 ]]; then
        echo "100"
    else
        local penalty=$((AFF_TOTAL_ISSUES * 12))
        local score=$((100 - penalty))
        [[ $score -lt 10 ]] && score=10
        echo "$score"
    fi
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "auth-flow-fixer" \
    --version "266.0" \
    --description "JWT/CORS/セッション/リダイレクト/ミドルウェア認証問題修正" \
    --init "_aff_init" \
    --report "_aff_report" \
    --score "_aff_score" \
    --enable-var "ENABLE_AFF" \
    --cli-flags "--auth-flow-fixer:--no-auth-flow-fixer"

# ----------------------------------------------------------------
# v2043 L8 強化: refiner-to-healer 閉ループ統一契約アダプタ (v2043 / L8・既存挙動不変・末尾追加のみ)
#   効果: これまで閉ループから不可視だった本fixerを diagnostic_code 宣言 + 統一 _run で
#         routable 化し、plan で自身の検出 (score) を handled として閉ループへ露出する。
#         apply は二重適用回避のため adapter 側 no-op (本体修正は既存経路が担当)。既存関数は無改変。
# ----------------------------------------------------------------
_aff_refiner_codes() { echo "AUTH_ERROR auth-flow-review auth_failure"; }
_aff_run() {
    local proj="${1:?project_dir required}"; local mode="${2:-plan}"
    local s handled=0
    s="$(_aff_score "$proj" 2>/dev/null || echo 100)"; [[ "${s:-100}" =~ ^[0-9]+$ ]] || s=100
    [[ "$s" -lt 100 ]] && handled=1
    printf '{"fixer":"auth-flow-fixer","diagnostic":"AUTH_ERROR","handled":%s,"applied":0,"mode":"%s","strategy":"auth-flow-review","note":"既存fixer強化アダプタ(plan=score検出/apply=本体経路へ委譲しadapterはno-op)"}\n' "$handled" "$mode"
}
