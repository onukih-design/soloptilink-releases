#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v101.0 - Declarative Task Definition Engine
# AGI対応: 「どうプロンプトするか」→「何を達成したいか」
#
# タスクをJSON/YAMLで宣言的に定義し、AIプロバイダーに依存しない
# 形で要件を記述する。AGIが来てもタスク定義は変わらない。
#
# 機能:
#   1. タスク定義（目標、制約、成果物、品質基準）をJSON形式で管理
#   2. タスク→プロンプトの変換（プロバイダー別に最適化）
#   3. テンプレートライブラリ（よくあるタスクパターン）
#   4. タスクの依存関係グラフ
#   5. 成果物の検証ルール定義
#
# v101.0: AGI-Ready Declarative Tasks
# ============================================================

[[ -n "${_TASK_DEFINITION_LOADED:-}" ]] && return 0
_TASK_DEFINITION_LOADED=1

# --- グローバル状態 ---
TDE_VERSION="109.0"
TDE_INITIALIZED=false
TDE_BASE_DIR="${HOME}/.soloptilink/task-definitions"
TDE_TEMPLATES_DIR=""

# ============================================================
# 初期化
# ============================================================
tde_init() {
    TDE_TEMPLATES_DIR="${TDE_BASE_DIR}/templates"
    mkdir -p "$TDE_TEMPLATES_DIR" "${TDE_BASE_DIR}/active" 2>/dev/null || true

    # テンプレート初期化
    if [[ ! -f "${TDE_TEMPLATES_DIR}/api_endpoint.json" ]]; then
        _tde_seed_templates
    fi

    TDE_INITIALIZED=true
    return 0
}

# ============================================================
# タスク定義の作成・管理
# ============================================================

# タスク定義を作成
tde_create_task() {
    local task_id="$1"
    local goal="$2"
    local domain="${3:-general}"
    local constraints="${4:-}"
    local deliverables="${5:-}"

    local task_file="${TDE_BASE_DIR}/active/${task_id}.json"

    cat > "$task_file" << TASK_EOF
{
  "id": "${task_id}",
  "goal": "${goal}",
  "domain": "${domain}",
  "status": "pending",
  "constraints": [${constraints}],
  "deliverables": [${deliverables}],
  "quality_criteria": {
    "min_score": 70,
    "require_tests": true,
    "require_types": true,
    "require_error_handling": true
  },
  "dependencies": [],
  "created_at": "$(date '+%Y-%m-%dT%H:%M:%S')",
  "completed_at": null
}
TASK_EOF

    echo "$task_id"
}

# タスク定義をプロンプトに変換
tde_to_prompt() {
    local task_file="$1"

    if [[ ! -f "$task_file" ]]; then
        # task_idとして扱う
        task_file="${TDE_BASE_DIR}/active/${task_file}.json"
    fi

    [[ ! -f "$task_file" ]] && return 1

    if command -v python3 &>/dev/null; then
        python3 -c "
import json
with open('$task_file') as f:
    task = json.load(f)

prompt_parts = []
prompt_parts.append(f\"## タスク目標\\n{task['goal']}\\n\")

if task.get('constraints'):
    prompt_parts.append('## 制約条件')
    for c in task['constraints']:
        if c: prompt_parts.append(f'- {c}')
    prompt_parts.append('')

if task.get('deliverables'):
    prompt_parts.append('## 成果物')
    for d in task['deliverables']:
        if d: prompt_parts.append(f'- {d}')
    prompt_parts.append('')

qc = task.get('quality_criteria', {})
if qc:
    prompt_parts.append('## 品質基準')
    if qc.get('require_tests'): prompt_parts.append('- テスト必須')
    if qc.get('require_types'): prompt_parts.append('- 型定義必須（TypeScript strict）')
    if qc.get('require_error_handling'): prompt_parts.append('- エラーハンドリング必須')
    prompt_parts.append(f\"- 最低品質スコア: {qc.get('min_score', 70)}/100\")

print('\\n'.join(prompt_parts))
" 2>/dev/null
    else
        cat "$task_file"
    fi
}

# 高レベルの説明からタスク定義を自動生成
tde_from_description() {
    local description="$1"
    local domain="${2:-general}"

    # テンプレートマッチング
    local template=""
    local desc_lower
    desc_lower=$(echo "$description" | tr '[:upper:]' '[:lower:]')

    if echo "$desc_lower" | grep -qE '(api|エンドポイント|endpoint)'; then
        template="api_endpoint"
    elif echo "$desc_lower" | grep -qE '(crud|管理画面|ダッシュボード)'; then
        template="crud_interface"
    elif echo "$desc_lower" | grep -qE '(認証|ログイン|auth)'; then
        template="authentication"
    elif echo "$desc_lower" | grep -qE '(saas|サブスクリプション|subscription)'; then
        template="saas_app"
    fi

    local task_id="task_$(date '+%Y%m%d_%H%M%S')"

    if [[ -n "$template" && -f "${TDE_TEMPLATES_DIR}/${template}.json" ]]; then
        # テンプレートベースで生成
        cp "${TDE_TEMPLATES_DIR}/${template}.json" "${TDE_BASE_DIR}/active/${task_id}.json"

        # 目標を上書き
        if command -v python3 &>/dev/null; then
            python3 -c "
import json
with open('${TDE_BASE_DIR}/active/${task_id}.json') as f:
    d = json.load(f)
d['id'] = '$task_id'
d['goal'] = '$description'
d['domain'] = '$domain'
d['created_at'] = '$(date '+%Y-%m-%dT%H:%M:%S')'
with open('${TDE_BASE_DIR}/active/${task_id}.json', 'w') as f:
    json.dump(d, f, indent=2, ensure_ascii=False)
" 2>/dev/null
        fi
    else
        # デフォルトで生成
        tde_create_task "$task_id" "$description" "$domain"
    fi

    echo "$task_id"
}

# ============================================================
# テンプレートライブラリ
# ============================================================
_tde_seed_templates() {
    # API Endpoint テンプレート
    cat > "${TDE_TEMPLATES_DIR}/api_endpoint.json" << 'EOF'
{
  "id": "template_api",
  "goal": "APIエンドポイントを実装する",
  "domain": "general",
  "status": "template",
  "constraints": [
    "全エンドポイントにzodバリデーション必須",
    "サービス層にビジネスロジックを分離",
    "Prisma ORM使用（raw SQL禁止）",
    "全CUD操作にトランザクション使用",
    "レート制限必須",
    "適切なHTTPステータスコード返却"
  ],
  "deliverables": [
    "APIルートファイル",
    "サービス層ファイル",
    "zodスキーマ定義",
    "Prismaモデル（必要時）"
  ],
  "quality_criteria": {
    "min_score": 75,
    "require_tests": true,
    "require_types": true,
    "require_error_handling": true,
    "require_validation": true
  },
  "dependencies": ["database_schema"]
}
EOF

    # CRUD Interface テンプレート
    cat > "${TDE_TEMPLATES_DIR}/crud_interface.json" << 'EOF'
{
  "id": "template_crud",
  "goal": "CRUD管理インターフェースを実装する",
  "domain": "general",
  "status": "template",
  "constraints": [
    "一覧（検索・フィルタ・ページネーション）",
    "新規作成フォーム（バリデーション付き）",
    "編集フォーム（既存データプリフィル）",
    "削除（確認ダイアログ付き）",
    "全ボタンに実動作するハンドラ必須",
    "ローディング/エラー/空状態を全て実装"
  ],
  "deliverables": [
    "一覧ページコンポーネント",
    "作成/編集フォームコンポーネント",
    "APIルート（CRUD全操作）",
    "サービス層"
  ],
  "quality_criteria": {
    "min_score": 75,
    "require_tests": true,
    "require_types": true,
    "require_error_handling": true,
    "require_ui_connectivity": true
  },
  "dependencies": ["api_endpoint", "database_schema"]
}
EOF

    # 認証テンプレート
    cat > "${TDE_TEMPLATES_DIR}/authentication.json" << 'EOF'
{
  "id": "template_auth",
  "goal": "認証・認可システムを実装する",
  "domain": "general",
  "status": "template",
  "constraints": [
    "パスワードはbcrypt/argon2idでハッシュ",
    "JWT RS256（有効期限15分以内）",
    "リフレッシュトークン（httpOnly cookie）",
    "RBAC（Role-Based Access Control）",
    "ブルートフォース対策（レート制限）",
    "セッション管理（ログアウト時の無効化）"
  ],
  "deliverables": [
    "認証ミドルウェア",
    "ログイン/ログアウトAPI",
    "ユーザー登録API",
    "パスワードリセットフロー",
    "ログインページUI"
  ],
  "quality_criteria": {
    "min_score": 85,
    "require_tests": true,
    "require_types": true,
    "require_error_handling": true,
    "require_security_audit": true
  },
  "dependencies": []
}
EOF

    # SaaS App テンプレート
    cat > "${TDE_TEMPLATES_DIR}/saas_app.json" << 'EOF'
{
  "id": "template_saas",
  "goal": "SaaSアプリケーションを構築する",
  "domain": "saas",
  "status": "template",
  "constraints": [
    "マルチテナント設計",
    "料金プラン（Free/Pro/Enterprise）",
    "Stripe決済連携",
    "管理者ダッシュボード",
    "ユーザー招待・チーム管理",
    "利用量追跡・制限",
    "利用規約・プライバシーポリシー"
  ],
  "deliverables": [
    "認証・認可システム",
    "テナント管理",
    "料金プラン・決済フロー",
    "管理者ダッシュボード",
    "ランディングページ",
    "メインアプリケーション機能"
  ],
  "quality_criteria": {
    "min_score": 80,
    "require_tests": true,
    "require_types": true,
    "require_error_handling": true,
    "require_audit_log": true,
    "require_rate_limiting": true
  },
  "dependencies": ["authentication", "database_schema"]
}
EOF
}

# ============================================================
# タスク一覧・状態管理
# ============================================================
tde_list_tasks() {
    local status_filter="${1:-all}"

    for f in "${TDE_BASE_DIR}/active"/*.json; do
        [[ -f "$f" ]] || continue
        python3 -c "
import json
with open('$f') as fp:
    d = json.load(fp)
status = d.get('status', 'pending')
if '$status_filter' == 'all' or status == '$status_filter':
    print(f\"  {d['id']} [{status}] - {d['goal'][:60]}\")
" 2>/dev/null
    done
}

tde_complete_task() {
    local task_id="$1"
    local task_file="${TDE_BASE_DIR}/active/${task_id}.json"

    [[ ! -f "$task_file" ]] && return 1

    python3 -c "
import json
with open('$task_file') as f:
    d = json.load(f)
d['status'] = 'completed'
d['completed_at'] = '$(date '+%Y-%m-%dT%H:%M:%S')'
with open('$task_file', 'w') as f:
    json.dump(d, f, indent=2, ensure_ascii=False)
" 2>/dev/null
}

# ============================================================
# v109.0 自然言語パーサー
# "CRM作って" → 構造化タスク定義
# ============================================================
td_parse_task() {
    local natural_language="$1"
    [[ -z "$natural_language" ]] && return 1

    local nl_lower
    nl_lower=$(echo "$natural_language" | tr '[:upper:]' '[:lower:]')

    # --- ドメイン判定 ---
    local domain="general"
    if echo "$nl_lower" | grep -qE '(crm|顧客管理|営業管理|リード)'; then
        domain="crm"
    elif echo "$nl_lower" | grep -qE '(saas|サブスク|subscription|プラン|月額|年額)'; then
        domain="saas"
    elif echo "$nl_lower" | grep -qE '(ec|ecommerce|通販|ショップ|カート|商品|購入|決済)'; then
        domain="ecommerce"
    elif echo "$nl_lower" | grep -qE '(ブログ|blog|記事|投稿|コメント)'; then
        domain="blog"
    elif echo "$nl_lower" | grep -qE '(タスク|todo|管理|プロジェクト管理)'; then
        domain="task_management"
    elif echo "$nl_lower" | grep -qE '(医療|health|診察|患者|カルテ)'; then
        domain="healthcare"
    elif echo "$nl_lower" | grep -qE '(金融|finance|銀行|口座|取引)'; then
        domain="finance"
    fi

    # --- エンティティ推定 ---
    local entities=""
    case "$domain" in
        crm)
            entities="User,Company,Contact,Deal,Activity,Note,Task,Tag"
            ;;
        saas)
            entities="User,Tenant,Subscription,Plan,Invoice,Team,Invitation"
            ;;
        ecommerce)
            entities="User,Product,Category,Cart,CartItem,Order,OrderItem,Review,Address,Payment"
            ;;
        blog)
            entities="User,Post,Category,Tag,Comment"
            ;;
        task_management)
            entities="User,Project,Task,Label,Comment"
            ;;
        healthcare)
            entities="User,Patient,Doctor,Appointment,MedicalRecord,Prescription"
            ;;
        finance)
            entities="User,Account,Transaction,Category,Budget"
            ;;
        *)
            entities="User"
            ;;
    esac

    # --- 追加エンティティ検出 ---
    if echo "$nl_lower" | grep -qE '(チーム|team|グループ|group)' && [[ "$entities" != *"Team"* ]]; then
        entities="${entities},Team"
    fi
    if echo "$nl_lower" | grep -qE '(通知|notification|お知らせ)'; then
        entities="${entities},Notification"
    fi
    if echo "$nl_lower" | grep -qE '(ファイル|アップロード|upload|添付)'; then
        entities="${entities},File"
    fi

    # --- 認証要件検出 ---
    local require_auth="true"
    if echo "$nl_lower" | grep -qE '(認証なし|ログインなし|公開|public only)'; then
        require_auth="false"
    fi

    # --- SaaS要件検出 ---
    local require_saas="false"
    if echo "$nl_lower" | grep -qE '(マルチテナント|multi.tenant|subscription|サブスク|プラン|月額|saas)'; then
        require_saas="true"
    fi

    # --- API数推定 ---
    local entity_count
    entity_count=$(echo "$entities" | tr ',' '\n' | grep -c '[A-Za-z]')
    entity_count=${entity_count:-1}
    # 各エンティティにCRUD(4) + 認証(3) + その他(2)
    local estimated_apis=$((entity_count * 4 + 5))
    if [[ "$require_auth" == "true" ]]; then
        estimated_apis=$((estimated_apis + 3))
    fi

    # --- ページ数推定 ---
    local estimated_pages=$((entity_count * 2 + 3))

    # --- 構造化出力 ---
    local task_id="task_$(date '+%Y%m%d_%H%M%S')"
    local task_file="${TDE_BASE_DIR}/active/${task_id}.json"
    mkdir -p "${TDE_BASE_DIR}/active" 2>/dev/null || true

    # エンティティをJSON配列に変換
    local entities_json=""
    local IFS_BAK="$IFS"
    IFS=','
    local first=true
    for entity in $entities; do
        [[ -z "$entity" ]] && continue
        if $first; then first=false; else entities_json="${entities_json},"; fi
        entities_json="${entities_json}\"${entity}\""
    done
    IFS="$IFS_BAK"

    cat > "$task_file" << TASK_EOF
{
  "id": "${task_id}",
  "goal": "${natural_language}",
  "domain": "${domain}",
  "status": "pending",
  "entities": [${entities_json}],
  "estimated_apis": ${estimated_apis},
  "estimated_pages": ${estimated_pages},
  "require_auth": ${require_auth},
  "require_saas": ${require_saas},
  "constraints": [],
  "deliverables": [],
  "quality_criteria": {
    "min_score": 70,
    "require_tests": true,
    "require_types": true,
    "require_error_handling": true
  },
  "dependencies": [],
  "created_at": "$(date '+%Y-%m-%dT%H:%M:%S')",
  "completed_at": null
}
TASK_EOF

    echo "$task_id"
    return 0
}

# ============================================================
# v109.0 完全性バリデーション
# 生成後プロジェクトがタスク定義の期待を満たしているか検証
# ============================================================
td_validate_completeness() {
    local project_dir="$1"
    local task_id="$2"

    [[ -z "$project_dir" || -z "$task_id" ]] && return 1

    local task_file="${TDE_BASE_DIR}/active/${task_id}.json"
    if [[ ! -f "$task_file" ]]; then
        # task_idがファイルパスの場合
        task_file="$task_id"
    fi
    [[ ! -f "$task_file" ]] && echo "Task definition not found: $task_id" >&2 && return 1

    local total_checks=0
    local passed_checks=0
    local failures=""

    # --- 1. エンティティ検証: Prismaスキーマに期待モデルがあるか ---
    local schema_file=""
    for candidate in \
        "${project_dir}/prisma/schema.prisma" \
        "${project_dir}/src/prisma/schema.prisma"; do
        [[ -f "$candidate" ]] && schema_file="$candidate" && break
    done

    # タスクファイルからエンティティ抽出 (jq不使用)
    local entities_line
    entities_line=$(grep -o '"entities":\[[^]]*\]' "$task_file" 2>/dev/null || echo "")
    local entities_raw
    entities_raw=$(echo "$entities_line" | sed 's/"entities":\[//;s/\]//;s/"//g;s/,/ /g')

    if [[ -n "$schema_file" && -n "$entities_raw" ]]; then
        for entity in $entities_raw; do
            [[ -z "$entity" ]] && continue
            total_checks=$((total_checks + 1))
            if grep -qE "^\s*model\s+${entity}\s" "$schema_file" 2>/dev/null; then
                passed_checks=$((passed_checks + 1))
            else
                failures="${failures}  - Missing Prisma model: ${entity}\n"
            fi
        done
    elif [[ -z "$schema_file" ]]; then
        total_checks=$((total_checks + 1))
        failures="${failures}  - No Prisma schema found\n"
    fi

    # --- 2. APIルート検証 ---
    local expected_apis
    expected_apis=$(grep -o '"estimated_apis":[0-9]*' "$task_file" 2>/dev/null | sed 's/"estimated_apis"://')
    expected_apis=${expected_apis:-5}

    local found_apis=0
    if [[ -d "${project_dir}/src/app/api" ]]; then
        found_apis=$(find "${project_dir}/src/app/api" -name "route.ts" -o -name "route.js" 2>/dev/null | wc -l | tr -d ' ')
    elif [[ -d "${project_dir}/app/api" ]]; then
        found_apis=$(find "${project_dir}/app/api" -name "route.ts" -o -name "route.js" 2>/dev/null | wc -l | tr -d ' ')
    fi
    found_apis=${found_apis:-0}

    total_checks=$((total_checks + 1))
    # 80%以上のAPIルートがあればパス
    local api_threshold=$(( (expected_apis * 80) / 100 ))
    [[ $api_threshold -lt 1 ]] && api_threshold=1
    if [[ $found_apis -ge $api_threshold ]]; then
        passed_checks=$((passed_checks + 1))
    else
        failures="${failures}  - Insufficient API routes: ${found_apis}/${expected_apis} (need ${api_threshold})\n"
    fi

    # --- 3. ページ検証 ---
    local expected_pages
    expected_pages=$(grep -o '"estimated_pages":[0-9]*' "$task_file" 2>/dev/null | sed 's/"estimated_pages"://')
    expected_pages=${expected_pages:-3}

    local found_pages=0
    for page_dir in "${project_dir}/src/app" "${project_dir}/app"; do
        [[ -d "$page_dir" ]] || continue
        found_pages=$(find "$page_dir" -name "page.tsx" -o -name "page.jsx" -o -name "page.ts" 2>/dev/null | wc -l | tr -d ' ')
        [[ $found_pages -gt 0 ]] && break
    done
    found_pages=${found_pages:-0}

    total_checks=$((total_checks + 1))
    local page_threshold=$(( (expected_pages * 60) / 100 ))
    [[ $page_threshold -lt 1 ]] && page_threshold=1
    if [[ $found_pages -ge $page_threshold ]]; then
        passed_checks=$((passed_checks + 1))
    else
        failures="${failures}  - Insufficient pages: ${found_pages}/${expected_pages} (need ${page_threshold})\n"
    fi

    # --- 4. 認証チェック ---
    local require_auth
    require_auth=$(grep -o '"require_auth":true' "$task_file" 2>/dev/null || echo "")
    if [[ -n "$require_auth" ]]; then
        total_checks=$((total_checks + 1))
        local has_auth=false
        # ミドルウェアまたは認証関連ファイルの存在チェック
        if find "$project_dir" -name "middleware.ts" -o -name "auth.ts" -o -name "auth.js" 2>/dev/null | grep -q '.'; then
            has_auth=true
        fi
        if $has_auth; then
            passed_checks=$((passed_checks + 1))
        else
            failures="${failures}  - Authentication files not found (middleware.ts or auth.ts)\n"
        fi
    fi

    # --- 結果出力 ---
    local completeness=0
    if [[ $total_checks -gt 0 ]]; then
        completeness=$((passed_checks * 100 / total_checks))
    fi

    echo "=== Task Completeness Validation ==="
    echo "  Task: ${task_id}"
    echo "  Passed: ${passed_checks}/${total_checks} (${completeness}%)"
    if [[ -n "$failures" ]]; then
        echo "  Failures:"
        echo -e "$failures"
    fi

    [[ $completeness -ge 70 ]] && return 0 || return 1
}

# ============================================================
# v109.0 受入基準自動生成
# タスク定義からテスト可能な受入基準を生成
# ============================================================
td_generate_acceptance_criteria() {
    local task_id="$1"
    [[ -z "$task_id" ]] && return 1

    local task_file="${TDE_BASE_DIR}/active/${task_id}.json"
    [[ ! -f "$task_file" ]] && task_file="$task_id"
    [[ ! -f "$task_file" ]] && echo "Task not found: $task_id" >&2 && return 1

    # タスクからメタデータ抽出
    local domain
    domain=$(grep -o '"domain":"[^"]*"' "$task_file" 2>/dev/null | sed 's/"domain":"//;s/"//')
    domain=${domain:-general}

    local entities_line
    entities_line=$(grep -o '"entities":\[[^]]*\]' "$task_file" 2>/dev/null || echo "")
    local entities_raw
    entities_raw=$(echo "$entities_line" | sed 's/"entities":\[//;s/\]//;s/"//g;s/,/ /g')

    local require_auth
    require_auth=$(grep -o '"require_auth":true' "$task_file" 2>/dev/null && echo "true" || echo "false")

    local require_saas
    require_saas=$(grep -o '"require_saas":true' "$task_file" 2>/dev/null && echo "true" || echo "false")

    echo "# Acceptance Criteria"
    echo "Generated: $(date '+%Y-%m-%d %H:%M:%S')"
    echo ""

    # --- スキーマ基準 ---
    echo "## Database Schema"
    for entity in $entities_raw; do
        [[ -z "$entity" ]] && continue
        echo "- [ ] ${entity} model exists in Prisma schema"
        echo "- [ ] ${entity} has id, createdAt, updatedAt fields"
    done
    echo ""

    # --- API基準 ---
    echo "## API Endpoints"
    for entity in $entities_raw; do
        [[ -z "$entity" ]] && continue
        local lower_entity
        lower_entity=$(echo "$entity" | tr '[:upper:]' '[:lower:]')
        echo "- [ ] GET /api/${lower_entity}s returns 200 with list"
        echo "- [ ] POST /api/${lower_entity}s returns 201 on valid input"
        echo "- [ ] GET /api/${lower_entity}s/[id] returns 200 for existing"
        echo "- [ ] PUT /api/${lower_entity}s/[id] returns 200 on valid update"
        echo "- [ ] DELETE /api/${lower_entity}s/[id] returns 200 on delete"
    done
    echo ""

    # --- UI基準 ---
    echo "## UI Pages"
    echo "- [ ] / (home) page renders without errors"
    if [[ "$require_auth" == "true" ]]; then
        echo "- [ ] /login page renders login form"
        echo "- [ ] /register page renders registration form"
    fi
    for entity in $entities_raw; do
        [[ -z "$entity" ]] && continue
        [[ "$entity" == "User" ]] && continue
        local lower_entity
        lower_entity=$(echo "$entity" | tr '[:upper:]' '[:lower:]')
        echo "- [ ] /${lower_entity}s list page renders"
    done
    echo ""

    # --- 認証基準 ---
    if [[ "$require_auth" == "true" ]]; then
        echo "## Authentication"
        echo "- [ ] Password hashing with bcrypt/argon2id"
        echo "- [ ] JWT token generation and validation"
        echo "- [ ] Protected routes require authentication"
        echo "- [ ] Login returns valid JWT on correct credentials"
        echo ""
    fi

    # --- SaaS基準 ---
    if [[ "$require_saas" == "true" ]]; then
        echo "## SaaS Features"
        echo "- [ ] Multi-tenant data isolation"
        echo "- [ ] Subscription plan model exists"
        echo "- [ ] Plan selection flow works"
        echo ""
    fi

    # --- 品質基準 ---
    echo "## Quality"
    echo "- [ ] TypeScript strict mode compiles without errors"
    echo "- [ ] No mock data in production code"
    echo "- [ ] All API endpoints have zod validation"
    echo "- [ ] All async functions have try-catch error handling"
    echo "- [ ] Prisma schema validates successfully"

    return 0
}

# ============================================================
# レポート
# ============================================================
tde_report() {
    echo "=== Task Definition Engine v${TDE_VERSION} ==="
    local template_count=0
    local active_count=0
    [[ -d "$TDE_TEMPLATES_DIR" ]] && template_count=$(find "$TDE_TEMPLATES_DIR" -name "*.json" 2>/dev/null | wc -l | tr -d ' ')
    [[ -d "${TDE_BASE_DIR}/active" ]] && active_count=$(find "${TDE_BASE_DIR}/active" -name "*.json" 2>/dev/null | wc -l | tr -d ' ')
    echo "  Templates: ${template_count}"
    echo "  Active tasks: ${active_count}"
}

tde_score() {
    local score=50
    local tc=0
    [[ -d "$TDE_TEMPLATES_DIR" ]] && tc=$(find "$TDE_TEMPLATES_DIR" -name "*.json" 2>/dev/null | wc -l | tr -d ' ')
    [[ $tc -gt 0 ]] && score=$((score + 25))
    [[ $tc -gt 3 ]] && score=$((score + 25))
    echo "$score"
}

# ============================================================
# Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "task-definition" \
        --version "$TDE_VERSION" \
        --description "AGI対応宣言的タスク定義 - AI非依存のタスク記述" \
        --init "tde_init" \
        --report "tde_report" \
        --score "tde_score" \
        --enable-var "ENABLE_TASK_DEFINITION" \
        --cli-flags "--task-definition:--no-task-definition"
fi

# v2003.1: source時のexit codeを確実に0にする
true
