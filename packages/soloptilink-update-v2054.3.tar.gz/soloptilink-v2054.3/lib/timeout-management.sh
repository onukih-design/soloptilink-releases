#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v449.0 - Timeout Management Engine
# =============================================================================
# タイムアウト設定の分析・最適化。不適切なタイムアウト検出、
# 最適値提案、設定生成を行う。カスケード障害を防止する。
#
# Functions:
#   _tm_init()                    - 初期化
#   _tm_analyze_timeouts()        - タイムアウト分析
#   _tm_set_optimal_timeouts()    - 最適タイムアウト設定
#   _tm_generate_config()         - タイムアウト設定生成
#   _tm_report() / _tm_score()
#
# All globals use the TM_ prefix.
# =============================================================================

[[ -n "${_TM_LOADED:-}" ]] && return 0; _TM_LOADED=1

declare -g TM_VERSION="449.0"
declare -g TM_GENERATED=0
declare -g TM_ERRORS=0
declare -g TM_TIMEOUTS_FOUND=0
declare -g TM_MISSING_TIMEOUTS=0
declare -g TM_EXCESSIVE_TIMEOUTS=0
declare -g TM_OPTIMAL_SET=0

declare -ga _TM_FINDINGS=()

_TM_GREEN="${GREEN:-\033[0;32m}"
_TM_YELLOW="${YELLOW:-\033[0;33m}"
_TM_CYAN="${CYAN:-\033[0;36m}"
_TM_BOLD="${BOLD:-\033[1m}"
_TM_NC="${NC:-\033[0m}"

_tm_init() {
    TM_GENERATED=0; TM_ERRORS=0; TM_TIMEOUTS_FOUND=0
    TM_MISSING_TIMEOUTS=0; TM_EXCESSIVE_TIMEOUTS=0; TM_OPTIMAL_SET=0
    _TM_FINDINGS=()
    return 0
}

_tm_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_TM_CYAN}[TM]${_TM_NC} $*" >&2 ;;
        ok)    echo -e "  ${_TM_GREEN}[TM]${_TM_NC} $*" >&2 ;;
        warn)  echo -e "  ${_TM_YELLOW}[TM]${_TM_NC} $*" >&2 ;;
        *)     echo -e "  ${_TM_CYAN}[TM]${_TM_NC} $*" >&2 ;;
    esac
}

_tm_analyze_timeouts() {
    local project_dir="${1:-.}"
    _tm_log info "タイムアウト設定分析"

    TM_TIMEOUTS_FOUND=0
    TM_MISSING_TIMEOUTS=0
    TM_EXCESSIVE_TIMEOUTS=0

    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"

        # 明示的タイムアウト設定の検出
        local timeout_settings
        timeout_settings=$(grep -n "timeout\|Timeout\|TIMEOUT" "$file" 2>/dev/null | grep -v "clearTimeout\|setTimeout" | wc -l || echo 0)
        TM_TIMEOUTS_FOUND=$((TM_TIMEOUTS_FOUND + timeout_settings))

        # 過大なタイムアウト値の検出
        while IFS= read -r match; do
            [[ -z "$match" ]] && continue
            if [[ "$match" =~ timeout.*([0-9]+) ]]; then
                local value="${BASH_REMATCH[1]}"
                if [[ $value -gt 60000 ]]; then  # 60秒以上
                    TM_EXCESSIVE_TIMEOUTS=$((TM_EXCESSIVE_TIMEOUTS + 1))
                    _TM_FINDINGS+=("EXCESSIVE:${rel}:timeout=${value}ms (>60s) - too long for API")
                    _tm_log warn "過大タイムアウト: ${rel} (${value}ms)"
                fi
            fi
        done < <(grep -n "timeout.*[0-9]" "$file" 2>/dev/null)

        # fetchにタイムアウトなし（AbortControllerなし）
        local fetch_count
        fetch_count=$(grep -c "fetch(" "$file" 2>/dev/null || echo 0)
        local abort_count
        abort_count=$(grep -c "AbortController\|signal\|timeout" "$file" 2>/dev/null || echo 0)

        if [[ $fetch_count -gt 0 ]] && [[ $abort_count -eq 0 ]]; then
            TM_MISSING_TIMEOUTS=$((TM_MISSING_TIMEOUTS + 1))
            _TM_FINDINGS+=("NO_TIMEOUT:${rel}:${fetch_count}x fetch without timeout/AbortController")
        fi

        # DB接続タイムアウト
        local db_no_timeout
        db_no_timeout=$(grep -n "createConnection\|new Pool\|PrismaClient" "$file" 2>/dev/null | head -1)
        if [[ -n "$db_no_timeout" ]]; then
            local line_num="${db_no_timeout%%:*}"
            local context
            context=$(sed -n "${line_num},$((line_num + 10))p" "$file" 2>/dev/null)
            if [[ "$context" != *"timeout"* ]] && [[ "$context" != *"connectTimeout"* ]]; then
                _TM_FINDINGS+=("DB_TIMEOUT:${rel}:database connection without explicit timeout")
            fi
        fi
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.js" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" -print0 2>/dev/null)

    TM_GENERATED=$((TM_GENERATED + 1))
    _tm_log ok "タイムアウト: ${TM_TIMEOUTS_FOUND}設定, 不足${TM_MISSING_TIMEOUTS}, 過大${TM_EXCESSIVE_TIMEOUTS}"
    return 0
}

_tm_set_optimal_timeouts() {
    local project_dir="${1:-.}"
    _tm_log info "最適タイムアウト値設定"

    TM_OPTIMAL_SET=0

    # エンドポイント種別ごとの推奨
    _TM_FINDINGS+=("OPTIMAL_API:API calls to external services: 5000-10000ms")
    _TM_FINDINGS+=("OPTIMAL_DB:Database queries: 5000ms for simple, 30000ms for complex")
    _TM_FINDINGS+=("OPTIMAL_UPLOAD:File uploads: 60000-120000ms")
    _TM_FINDINGS+=("OPTIMAL_WS:WebSocket ping: 30000ms, connect: 5000ms")
    _TM_FINDINGS+=("OPTIMAL_HTTP:HTTP server request: 30000ms (Node.js default)")
    TM_OPTIMAL_SET=5

    # カスケードタイムアウト推奨
    _TM_FINDINGS+=("CASCADE:downstream timeout should be shorter than upstream timeout")
    _TM_FINDINGS+=("BUDGET:implement timeout budget pattern for chained service calls")

    # Vercel/Lambda制限
    if [[ -f "${project_dir}/vercel.json" ]]; then
        _TM_FINDINGS+=("VERCEL_LIMIT:Vercel serverless: 10s default, 60s max (Pro), 300s max (Enterprise)")
    fi

    TM_GENERATED=$((TM_GENERATED + 1))
    _tm_log ok "最適タイムアウト設定: ${TM_OPTIMAL_SET}種別"
    return 0
}

_tm_generate_config() {
    local project_dir="${1:-.}"
    _tm_log info "タイムアウト設定生成"

    local config=$(cat <<'TIMEOUT_CONFIG'
// lib/timeout-config.ts - Centralized Timeout Configuration
export const TIMEOUTS = {
  api: {
    default: 10_000,
    external: 5_000,
    upload: 120_000,
    healthCheck: 3_000,
  },
  database: {
    query: 5_000,
    transaction: 30_000,
    connection: 5_000,
    migration: 300_000,
  },
  http: {
    server: 30_000,
    keepAlive: 5_000,
    headers: 60_000,
  },
  websocket: {
    connect: 5_000,
    ping: 30_000,
    close: 5_000,
  },
  cache: {
    redis: 3_000,
    memcache: 1_000,
  },
} as const;

// Utility: fetch with timeout
export async function fetchWithTimeout(
  url: string,
  options: RequestInit & { timeout?: number } = {}
): Promise<Response> {
  const { timeout = TIMEOUTS.api.default, ...fetchOptions } = options;
  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);
  try {
    return await fetch(url, { ...fetchOptions, signal: controller.signal });
  } finally {
    clearTimeout(id);
  }
}
TIMEOUT_CONFIG
)

    TM_GENERATED=$((TM_GENERATED + 1))
    _tm_log ok "タイムアウト設定生成完了"
    echo "$config"
    return 0
}

_tm_report() {
    echo -e "\n  ${_TM_BOLD}=== timeout-management v${TM_VERSION} ===${_TM_NC}"
    echo -e "  タイムアウト設定: ${TM_TIMEOUTS_FOUND}"
    echo -e "  不足            : ${TM_MISSING_TIMEOUTS}"
    echo -e "  過大            : ${TM_EXCESSIVE_TIMEOUTS}"
    echo -e "  最適設定        : ${TM_OPTIMAL_SET}"
    echo -e "  エラー          : ${TM_ERRORS}"
}

_tm_score() {
    local score=50
    [[ ${TM_TIMEOUTS_FOUND} -gt 0 ]] && score=$((score + 10))
    [[ ${TM_MISSING_TIMEOUTS} -eq 0 ]] && score=$((score + 15))
    [[ ${TM_EXCESSIVE_TIMEOUTS} -eq 0 ]] && score=$((score + 10))
    [[ ${TM_OPTIMAL_SET} -gt 0 ]] && score=$((score + 10))
    [[ ${TM_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "timeout-management" --version "${TM_VERSION}" \
        --description "タイムアウト管理×分析×最適値設定×カスケード防止 (v449)" \
        --init "_tm_init" --report "_tm_report" --score "_tm_score" \
        --enable-var "ENABLE_TIMEOUT_MGMT" --cli-flags "--timeout-mgmt:--no-timeout-mgmt"
fi

# v2003.1: source時のexit codeを確実に0にする
true
