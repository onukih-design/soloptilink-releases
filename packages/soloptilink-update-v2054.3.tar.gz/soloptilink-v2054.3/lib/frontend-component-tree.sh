#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v213.0 - Frontend Component Tree
# =============================================================================
# React/Next.js プロジェクトのコンポーネント階層を解析し、
# 再利用可能性・プロップドリリング・巨大コンポーネントを検出する
#
# 機能:
#   1. コンポーネント階層ツリー構築 (Component Hierarchy Tree)
#   2. 再利用候補検出 (Reusable Component Detection)
#   3. プロップドリリング検出 (Prop Drilling Detection)
#   4. 巨大コンポーネント検出 (Large Component Detection)
#   5. コンポーネントマップ生成 (JSON Component Map)
#
# 使用方法:
#   source lib/frontend-component-tree.sh
#   _fct_build_tree "/path/to/project"
#   _fct_find_reusable "/path/to/project"
#   _fct_detect_prop_drilling "/path/to/project"
#   _fct_find_large_components "/path/to/project"
#   _fct_generate_component_map "/path/to/project"
# =============================================================================

[[ -n "${_FRONTEND_COMPONENT_TREE_LOADED:-}" ]] && return 0
_FRONTEND_COMPONENT_TREE_LOADED=1

# ============================================================
# Constants
# ============================================================
FCT_VERSION="213.0"
FCT_LARGE_COMPONENT_THRESHOLD=200
FCT_PROP_DRILLING_DEPTH=3
FCT_SIMILARITY_THRESHOLD=70
ENABLE_FRONTEND_COMPONENT_TREE="${ENABLE_FRONTEND_COMPONENT_TREE:-true}"

# ============================================================
# Internal State
# ============================================================
declare -a _FCT_COMPONENTS=()
declare -A _FCT_COMPONENT_FILE=()       # name → file path
declare -A _FCT_COMPONENT_LINES=()      # name → line count
declare -A _FCT_COMPONENT_IMPORTS=()    # name → comma-separated imported components
declare -A _FCT_COMPONENT_PROPS=()      # name → comma-separated prop names
declare -A _FCT_COMPONENT_CHILDREN=()   # name → comma-separated child components
declare -A _FCT_COMPONENT_TYPE=()       # name → "page"|"layout"|"component"|"hook"|"context"
_FCT_PROJECT_DIR=""
_FCT_TOTAL_COMPONENTS=0
_FCT_REUSABLE_COUNT=0
_FCT_PROP_DRILLING_COUNT=0
_FCT_LARGE_COUNT=0
_FCT_SCORE=50

# ============================================================
# Logging
# ============================================================
_fct_log() {
    local level="$1" msg="$2"
    local timestamp
    timestamp="$(date '+%Y-%m-%d %H:%M:%S')"
    echo -e "  [FCT][${level}] ${msg}" >&2
    if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
        echo "[${timestamp}][FCT][${level}] ${msg}" >> "${SESSION_LOG_DIR}/frontend_component_tree.log" 2>/dev/null || true
    fi
}

# ============================================================
# Utility: Find React/Next.js component files
# ============================================================
_fct_find_component_files() {
    local dir="$1"
    find "$dir" \
        -type f \( -name "*.tsx" -o -name "*.jsx" \) \
        ! -path "*/node_modules/*" \
        ! -path "*/.next/*" \
        ! -path "*/dist/*" \
        ! -path "*/build/*" \
        ! -path "*/__tests__/*" \
        ! -path "*/*.test.*" \
        ! -path "*/*.spec.*" \
        2>/dev/null | sort
}

# ============================================================
# Utility: Extract component name from file
# ============================================================
_fct_extract_component_name() {
    local file="$1"
    local basename
    basename="$(basename "$file" | sed 's/\.\(tsx\|jsx\)$//')"

    # page.tsx / layout.tsx -> use parent directory name
    if [[ "$basename" == "page" || "$basename" == "layout" || "$basename" == "loading" || "$basename" == "error" ]]; then
        local parent_dir
        parent_dir="$(basename "$(dirname "$file")")"
        echo "${parent_dir}_${basename}"
    else
        echo "$basename"
    fi
}

# ============================================================
# Utility: Classify component type
# ============================================================
_fct_classify_component() {
    local file="$1"
    local basename
    basename="$(basename "$file")"

    case "$basename" in
        page.tsx|page.jsx)     echo "page" ;;
        layout.tsx|layout.jsx) echo "layout" ;;
        loading.tsx|loading.jsx) echo "loading" ;;
        error.tsx|error.jsx)   echo "error" ;;
        *)
            if echo "$file" | grep -qE '/(hooks|use[A-Z])'; then
                echo "hook"
            elif echo "$file" | grep -qE '/(context|provider)'; then
                echo "context"
            elif echo "$file" | grep -qE '/(components|ui|shared)/'; then
                echo "component"
            else
                echo "component"
            fi
            ;;
    esac
}

# ============================================================
# Utility: Extract imports from a file
# ============================================================
_fct_extract_imports() {
    local file="$1"
    local imports=""

    # Extract named and default imports from local paths
    while IFS= read -r line; do
        # Match: import X from './...' or import { X, Y } from '../...'
        if echo "$line" | grep -qE "^import\s+" ; then
            # Skip node_modules imports (no ./ or ../ prefix)
            local from_path
            from_path=$(echo "$line" | grep -oE "from ['\"]([^'\"]+)['\"]" | sed "s/from ['\"]//;s/['\"]//")
            [[ -z "$from_path" ]] && continue
            # Only track local imports
            if [[ "$from_path" == ./* || "$from_path" == ../* || "$from_path" == @/* ]]; then
                # Extract component names from import statement
                local names
                names=$(echo "$line" | sed 's/import//;s/from.*//;s/[{}]//g;s/type //g' | tr ',' '\n' | sed 's/^ *//;s/ *$//' | grep -vE '^\s*$' | grep -vE '^\*')
                for name in $names; do
                    # Skip 'as' aliases second part
                    [[ "$name" == "as" ]] && continue
                    name=$(echo "$name" | sed 's/ as .*//')
                    [[ -z "$name" ]] && continue
                    if [[ -z "$imports" ]]; then
                        imports="$name"
                    else
                        imports="${imports},${name}"
                    fi
                done
            fi
        fi
    done < "$file"

    echo "$imports"
}

# ============================================================
# Utility: Extract props from component definition
# ============================================================
_fct_extract_props() {
    local file="$1"
    local props=""

    # Match interface/type Props patterns
    local content
    content=$(cat "$file" 2>/dev/null) || return

    # Pattern 1: interface XxxProps { prop1: type; prop2: type; }
    local prop_block
    prop_block=$(echo "$content" | grep -A 50 -E '(interface|type)\s+\w*Props\s*(=\s*\{|\{)' | head -50)

    if [[ -n "$prop_block" ]]; then
        local extracted
        extracted=$(echo "$prop_block" | grep -oE '^\s+(\w+)(\?)?:' | sed 's/^\s*//;s/\??://' | grep -vE '^\s*$')
        for prop in $extracted; do
            if [[ -z "$props" ]]; then
                props="$prop"
            else
                props="${props},${prop}"
            fi
        done
    fi

    # Pattern 2: function Component({ prop1, prop2 }: Props)
    local destructured
    destructured=$(echo "$content" | grep -oE '\(\s*\{[^}]+\}\s*:' | head -1 | sed 's/(//;s/{//;s/}.*//;s/://g' | tr ',' '\n' | sed 's/^ *//;s/ *$//' | grep -vE '^\s*$')
    for prop in $destructured; do
        # Remove default values
        prop=$(echo "$prop" | sed 's/ *=.*//')
        [[ -z "$prop" ]] && continue
        if echo ",$props," | grep -q ",${prop},"; then
            continue  # already listed
        fi
        if [[ -z "$props" ]]; then
            props="$prop"
        else
            props="${props},${prop}"
        fi
    done

    echo "$props"
}

# ============================================================
# Utility: Count lines of component body (excluding imports/types)
# ============================================================
_fct_count_component_lines() {
    local file="$1"
    local total
    total=$(wc -l < "$file" 2>/dev/null | tr -d ' ')
    echo "${total:-0}"
}

# ============================================================
# Utility: Find JSX children components used in render
# ============================================================
_fct_find_jsx_children() {
    local file="$1"
    local children=""

    # Find PascalCase JSX tags: <ComponentName ... />  or <ComponentName>
    local tags
    tags=$(grep -oE '<[A-Z][A-Za-z0-9]+' "$file" 2>/dev/null | sed 's/<//g' | sort -u)

    for tag in $tags; do
        # Skip HTML-like but uppercase (e.g., SVG elements that might be capitalized)
        case "$tag" in
            Fragment|Suspense|StrictMode) continue ;;
        esac
        if [[ -z "$children" ]]; then
            children="$tag"
        else
            children="${children},${tag}"
        fi
    done

    echo "$children"
}

# ============================================================
# 1. Build Component Hierarchy Tree
# ============================================================
_fct_build_tree() {
    local project_dir="${1:-.}"
    _FCT_PROJECT_DIR="$project_dir"

    _fct_log "INFO" "コンポーネントツリー構築開始: ${project_dir}"

    # Reset state
    _FCT_COMPONENTS=()
    _FCT_COMPONENT_FILE=()
    _FCT_COMPONENT_LINES=()
    _FCT_COMPONENT_IMPORTS=()
    _FCT_COMPONENT_PROPS=()
    _FCT_COMPONENT_CHILDREN=()
    _FCT_COMPONENT_TYPE=()
    _FCT_TOTAL_COMPONENTS=0

    local files
    files=$(_fct_find_component_files "$project_dir")

    if [[ -z "$files" ]]; then
        _fct_log "WARN" "コンポーネントファイルが見つかりません"
        return 0
    fi

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue

        local comp_name
        comp_name=$(_fct_extract_component_name "$file")
        [[ -z "$comp_name" ]] && continue

        # Avoid duplicates by appending path hash for same-named components
        if [[ -n "${_FCT_COMPONENT_FILE[$comp_name]:-}" ]]; then
            local hash
            hash=$(echo "$file" | md5sum 2>/dev/null | cut -c1-6 || echo "dup")
            comp_name="${comp_name}_${hash}"
        fi

        _FCT_COMPONENTS+=("$comp_name")
        _FCT_COMPONENT_FILE["$comp_name"]="$file"
        _FCT_COMPONENT_LINES["$comp_name"]=$(_fct_count_component_lines "$file")
        _FCT_COMPONENT_IMPORTS["$comp_name"]=$(_fct_extract_imports "$file")
        _FCT_COMPONENT_PROPS["$comp_name"]=$(_fct_extract_props "$file")
        _FCT_COMPONENT_CHILDREN["$comp_name"]=$(_fct_find_jsx_children "$file")
        _FCT_COMPONENT_TYPE["$comp_name"]=$(_fct_classify_component "$file")

        _FCT_TOTAL_COMPONENTS=$((_FCT_TOTAL_COMPONENTS + 1))
    done <<< "$files"

    _fct_log "INFO" "コンポーネントツリー構築完了: ${_FCT_TOTAL_COMPONENTS} コンポーネント"

    # Print tree
    _fct_print_tree

    return 0
}

# ============================================================
# Print tree visualization
# ============================================================
_fct_print_tree() {
    local output_file="${SESSION_LOG_DIR:-/tmp}/component_tree.txt"

    {
        echo "============================================="
        echo " Frontend Component Tree (v${FCT_VERSION})"
        echo " Project: ${_FCT_PROJECT_DIR}"
        echo " Total Components: ${_FCT_TOTAL_COMPONENTS}"
        echo "============================================="
        echo ""

        # Group by type
        for type in page layout component hook context loading error; do
            local type_components=()
            for comp in "${_FCT_COMPONENTS[@]}"; do
                if [[ "${_FCT_COMPONENT_TYPE[$comp]:-}" == "$type" ]]; then
                    type_components+=("$comp")
                fi
            done
            [[ ${#type_components[@]} -eq 0 ]] && continue

            echo "--- ${type^^} (${#type_components[@]}) ---"
            for comp in "${type_components[@]}"; do
                local lines="${_FCT_COMPONENT_LINES[$comp]:-0}"
                local children="${_FCT_COMPONENT_CHILDREN[$comp]:-}"
                local props="${_FCT_COMPONENT_PROPS[$comp]:-}"
                local file="${_FCT_COMPONENT_FILE[$comp]:-}"
                # Relative path
                local rel_file="${file#${_FCT_PROJECT_DIR}/}"

                echo "  [${comp}] (${lines} lines)"
                echo "    File: ${rel_file}"
                [[ -n "$props" ]] && echo "    Props: ${props}"
                if [[ -n "$children" ]]; then
                    echo "    Children:"
                    IFS=',' read -ra child_arr <<< "$children"
                    for child in "${child_arr[@]}"; do
                        echo "      -> ${child}"
                    done
                fi
                echo ""
            done
        done
    } > "$output_file" 2>/dev/null

    _fct_log "INFO" "ツリー出力: ${output_file}"
}

# ============================================================
# 2. Find Reusable Components
# ============================================================
_fct_find_reusable() {
    local project_dir="${1:-.}"

    # Build tree if not already built
    if [[ ${_FCT_TOTAL_COMPONENTS} -eq 0 ]]; then
        _fct_build_tree "$project_dir"
    fi

    _fct_log "INFO" "再利用候補コンポーネント検出開始"
    _FCT_REUSABLE_COUNT=0

    local output_file="${SESSION_LOG_DIR:-/tmp}/reusable_components.txt"

    {
        echo "============================================="
        echo " Reusable Component Candidates"
        echo "============================================="
        echo ""

        # Strategy 1: Find components used in multiple places
        echo "--- 複数箇所で使用されているコンポーネント ---"
        for comp in "${_FCT_COMPONENTS[@]}"; do
            local usage_count=0
            for other in "${_FCT_COMPONENTS[@]}"; do
                [[ "$other" == "$comp" ]] && continue
                local children="${_FCT_COMPONENT_CHILDREN[$other]:-}"
                if echo ",$children," | grep -q ",${comp},"; then
                    usage_count=$((usage_count + 1))
                fi
            done
            if [[ $usage_count -ge 2 ]]; then
                echo "  [${comp}] - ${usage_count} 箇所で使用"
                _FCT_REUSABLE_COUNT=$((_FCT_REUSABLE_COUNT + 1))
            fi
        done

        echo ""

        # Strategy 2: Find structurally similar components (same prop patterns)
        echo "--- 構造的に類似したコンポーネント (統合候補) ---"
        local checked=()
        for comp_a in "${_FCT_COMPONENTS[@]}"; do
            for comp_b in "${_FCT_COMPONENTS[@]}"; do
                [[ "$comp_a" == "$comp_b" ]] && continue
                # Skip already compared pairs
                local pair_key="${comp_a}:${comp_b}"
                local pair_key_rev="${comp_b}:${comp_a}"
                local skip=false
                for checked_pair in "${checked[@]}"; do
                    if [[ "$checked_pair" == "$pair_key" || "$checked_pair" == "$pair_key_rev" ]]; then
                        skip=true
                        break
                    fi
                done
                [[ "$skip" == "true" ]] && continue
                checked+=("$pair_key")

                # Compare props
                local props_a="${_FCT_COMPONENT_PROPS[$comp_a]:-}"
                local props_b="${_FCT_COMPONENT_PROPS[$comp_b]:-}"

                [[ -z "$props_a" || -z "$props_b" ]] && continue

                # Count matching props
                local match=0
                local total_a=0
                IFS=',' read -ra arr_a <<< "$props_a"
                total_a=${#arr_a[@]}
                for pa in "${arr_a[@]}"; do
                    if echo ",$props_b," | grep -qi ",${pa},"; then
                        match=$((match + 1))
                    fi
                done

                if [[ $total_a -gt 0 ]]; then
                    local similarity=$(( (match * 100) / total_a ))
                    if [[ $similarity -ge $FCT_SIMILARITY_THRESHOLD ]]; then
                        echo "  [${comp_a}] <-> [${comp_b}] : ${similarity}% prop similarity"
                        _FCT_REUSABLE_COUNT=$((_FCT_REUSABLE_COUNT + 1))
                    fi
                fi
            done
        done

        echo ""

        # Strategy 3: Components with generic names that should be shared
        echo "--- 共通コンポーネント化推奨 ---"
        for comp in "${_FCT_COMPONENTS[@]}"; do
            local name_lower
            name_lower=$(echo "$comp" | tr '[:upper:]' '[:lower:]')
            case "$name_lower" in
                *button*|*modal*|*dialog*|*input*|*card*|*table*|*list*|*form*|*header*|*footer*|*sidebar*|*nav*)
                    local comp_type="${_FCT_COMPONENT_TYPE[$comp]:-}"
                    if [[ "$comp_type" != "component" ]]; then
                        continue
                    fi
                    # Check if it's in a shared/common directory
                    local file="${_FCT_COMPONENT_FILE[$comp]:-}"
                    if ! echo "$file" | grep -qE '/(shared|common|ui|components)/'; then
                        echo "  [${comp}] - 共通コンポーネントディレクトリへの移動を推奨"
                        echo "    現在: ${file#${_FCT_PROJECT_DIR}/}"
                        _FCT_REUSABLE_COUNT=$((_FCT_REUSABLE_COUNT + 1))
                    fi
                    ;;
            esac
        done
    } > "$output_file" 2>/dev/null

    _fct_log "INFO" "再利用候補: ${_FCT_REUSABLE_COUNT} 件検出"

    return 0
}

# ============================================================
# 3. Detect Prop Drilling
# ============================================================
_fct_detect_prop_drilling() {
    local project_dir="${1:-.}"

    if [[ ${_FCT_TOTAL_COMPONENTS} -eq 0 ]]; then
        _fct_build_tree "$project_dir"
    fi

    _fct_log "INFO" "プロップドリリング検出開始"
    _FCT_PROP_DRILLING_COUNT=0

    local output_file="${SESSION_LOG_DIR:-/tmp}/prop_drilling.txt"

    {
        echo "============================================="
        echo " Prop Drilling Detection"
        echo "============================================="
        echo ""

        # For each prop, trace how deep it flows through the component tree
        for comp in "${_FCT_COMPONENTS[@]}"; do
            local props="${_FCT_COMPONENT_PROPS[$comp]:-}"
            [[ -z "$props" ]] && continue

            IFS=',' read -ra prop_arr <<< "$props"
            for prop in "${prop_arr[@]}"; do
                [[ -z "$prop" ]] && continue

                # Trace this prop through children
                local depth=0
                local chain="$comp"
                local current="$comp"
                local visited="$comp"

                while true; do
                    local children="${_FCT_COMPONENT_CHILDREN[$current]:-}"
                    [[ -z "$children" ]] && break

                    local found_deeper=false
                    IFS=',' read -ra child_arr <<< "$children"
                    for child in "${child_arr[@]}"; do
                        # Check if this child component exists in our registry
                        local child_props="${_FCT_COMPONENT_PROPS[$child]:-}"
                        [[ -z "$child_props" ]] && continue

                        # Check if visited to avoid cycles
                        if echo ",$visited," | grep -q ",${child},"; then
                            continue
                        fi

                        # Check if this child receives the same prop
                        if echo ",$child_props," | grep -qi ",${prop},"; then
                            depth=$((depth + 1))
                            chain="${chain} -> ${child}"
                            current="$child"
                            visited="${visited},${child}"
                            found_deeper=true
                            break
                        fi
                    done

                    [[ "$found_deeper" != "true" ]] && break
                done

                if [[ $depth -ge $FCT_PROP_DRILLING_DEPTH ]]; then
                    echo "  DRILLING: prop '${prop}' passes through ${depth} levels"
                    echo "    Chain: ${chain}"
                    echo "    Recommendation: Use Context or state management"
                    echo ""
                    _FCT_PROP_DRILLING_COUNT=$((_FCT_PROP_DRILLING_COUNT + 1))
                fi
            done
        done

        # Also scan for common drilling patterns in source
        echo "--- ソースコードパターン検出 ---"
        local files
        files=$(_fct_find_component_files "$project_dir")

        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            local content
            content=$(cat "$file" 2>/dev/null) || continue

            # Pattern: same prop name appearing in interface AND being passed to child
            local interface_props
            interface_props=$(echo "$content" | grep -oE '^\s+\w+\??\s*:' | sed 's/^\s*//;s/\??.*://' | sort -u)

            for ip in $interface_props; do
                [[ -z "$ip" ]] && continue
                # Check if the same prop is passed down as JSX attribute
                local pass_count
                pass_count=$(echo "$content" | grep -cE "${ip}=\{" 2>/dev/null || echo "0")
                pass_count="${pass_count%%[!0-9]*}"
                pass_count="${pass_count:-0}"

                if [[ $pass_count -ge 2 ]]; then
                    local rel_file="${file#${project_dir}/}"
                    echo "  [${rel_file}] prop '${ip}' が ${pass_count} 箇所に渡されています"
                    _FCT_PROP_DRILLING_COUNT=$((_FCT_PROP_DRILLING_COUNT + 1))
                fi
            done
        done <<< "$files"

        if [[ $_FCT_PROP_DRILLING_COUNT -eq 0 ]]; then
            echo "  プロップドリリングは検出されませんでした"
        fi
    } > "$output_file" 2>/dev/null

    _fct_log "INFO" "プロップドリリング: ${_FCT_PROP_DRILLING_COUNT} 件検出"

    return 0
}

# ============================================================
# 4. Find Large Components
# ============================================================
_fct_find_large_components() {
    local project_dir="${1:-.}"
    local threshold="${2:-$FCT_LARGE_COMPONENT_THRESHOLD}"

    if [[ ${_FCT_TOTAL_COMPONENTS} -eq 0 ]]; then
        _fct_build_tree "$project_dir"
    fi

    _fct_log "INFO" "巨大コンポーネント検出開始 (閾値: ${threshold} 行)"
    _FCT_LARGE_COUNT=0

    local output_file="${SESSION_LOG_DIR:-/tmp}/large_components.txt"

    {
        echo "============================================="
        echo " Large Component Detection (>${threshold} lines)"
        echo "============================================="
        echo ""

        # Sort by line count descending
        local sorted_components=()
        for comp in "${_FCT_COMPONENTS[@]}"; do
            local lines="${_FCT_COMPONENT_LINES[$comp]:-0}"
            sorted_components+=("${lines}:${comp}")
        done

        # Sort numerically descending
        IFS=$'\n' sorted_components=($(sort -t: -k1 -nr <<< "${sorted_components[*]}")); unset IFS

        for entry in "${sorted_components[@]}"; do
            local lines="${entry%%:*}"
            local comp="${entry#*:}"

            if [[ $lines -ge $threshold ]]; then
                local file="${_FCT_COMPONENT_FILE[$comp]:-}"
                local rel_file="${file#${project_dir}/}"
                local children="${_FCT_COMPONENT_CHILDREN[$comp]:-}"
                local child_count=0
                if [[ -n "$children" ]]; then
                    IFS=',' read -ra arr <<< "$children"
                    child_count=${#arr[@]}
                fi

                echo "  [${comp}] - ${lines} lines"
                echo "    File: ${rel_file}"
                echo "    Child Components: ${child_count}"

                # Suggest split strategies
                if [[ $lines -ge 500 ]]; then
                    echo "    Severity: CRITICAL - 即座に分割が必要"
                elif [[ $lines -ge 300 ]]; then
                    echo "    Severity: HIGH - 分割を強く推奨"
                else
                    echo "    Severity: MEDIUM - 分割を検討"
                fi

                # Analyze what makes it large
                if [[ -n "$file" && -f "$file" ]]; then
                    local hook_count
                    hook_count=$(grep -cE 'use[A-Z]\w+\(' "$file" 2>/dev/null || echo "0")
                    hook_count="${hook_count%%[!0-9]*}"
                    hook_count="${hook_count:-0}"

                    local state_count
                    state_count=$(grep -cE 'useState|useReducer' "$file" 2>/dev/null || echo "0")
                    state_count="${state_count%%[!0-9]*}"
                    state_count="${state_count:-0}"

                    local effect_count
                    effect_count=$(grep -cE 'useEffect|useLayoutEffect' "$file" 2>/dev/null || echo "0")
                    effect_count="${effect_count%%[!0-9]*}"
                    effect_count="${effect_count:-0}"

                    echo "    Hooks: ${hook_count}, State: ${state_count}, Effects: ${effect_count}"

                    if [[ $state_count -ge 5 ]]; then
                        echo "    Suggestion: useReducerへの統合またはカスタムフックへの抽出"
                    fi
                    if [[ $effect_count -ge 3 ]]; then
                        echo "    Suggestion: 副作用をカスタムフックに分離"
                    fi
                    if [[ $child_count -ge 8 ]]; then
                        echo "    Suggestion: 子コンポーネントをセクション単位で分割"
                    fi
                fi

                echo ""
                _FCT_LARGE_COUNT=$((_FCT_LARGE_COUNT + 1))
            fi
        done

        if [[ $_FCT_LARGE_COUNT -eq 0 ]]; then
            echo "  全コンポーネントが ${threshold} 行以下です"
        fi

        echo ""
        echo "--- 統計 ---"
        echo "  合計コンポーネント: ${_FCT_TOTAL_COMPONENTS}"
        echo "  巨大コンポーネント: ${_FCT_LARGE_COUNT}"
        if [[ $_FCT_TOTAL_COMPONENTS -gt 0 ]]; then
            local pct=$(( (_FCT_LARGE_COUNT * 100) / _FCT_TOTAL_COMPONENTS ))
            echo "  割合: ${pct}%"
        fi
    } > "$output_file" 2>/dev/null

    _fct_log "INFO" "巨大コンポーネント: ${_FCT_LARGE_COUNT} 件検出"

    return 0
}

# ============================================================
# 5. Generate Component Map (JSON)
# ============================================================
_fct_generate_component_map() {
    local project_dir="${1:-.}"

    if [[ ${_FCT_TOTAL_COMPONENTS} -eq 0 ]]; then
        _fct_build_tree "$project_dir"
    fi

    _fct_log "INFO" "コンポーネントマップ (JSON) 生成開始"

    local output_file="${SESSION_LOG_DIR:-/tmp}/component_map.json"

    {
        echo "{"
        echo "  \"version\": \"${FCT_VERSION}\","
        echo "  \"project\": \"${project_dir}\","
        echo "  \"generatedAt\": \"$(date -u '+%Y-%m-%dT%H:%M:%SZ')\","
        echo "  \"totalComponents\": ${_FCT_TOTAL_COMPONENTS},"
        echo "  \"components\": ["

        local first=true
        for comp in "${_FCT_COMPONENTS[@]}"; do
            if [[ "$first" == "true" ]]; then
                first=false
            else
                echo "    ,"
            fi

            local file="${_FCT_COMPONENT_FILE[$comp]:-}"
            local rel_file="${file#${project_dir}/}"
            local lines="${_FCT_COMPONENT_LINES[$comp]:-0}"
            local imports="${_FCT_COMPONENT_IMPORTS[$comp]:-}"
            local props="${_FCT_COMPONENT_PROPS[$comp]:-}"
            local children="${_FCT_COMPONENT_CHILDREN[$comp]:-}"
            local comp_type="${_FCT_COMPONENT_TYPE[$comp]:-component}"

            # Convert comma-separated to JSON array
            local imports_json="[]"
            if [[ -n "$imports" ]]; then
                imports_json="[$(echo "$imports" | sed 's/,/","/g;s/^/"/;s/$/"/' )]"
            fi

            local props_json="[]"
            if [[ -n "$props" ]]; then
                props_json="[$(echo "$props" | sed 's/,/","/g;s/^/"/;s/$/"/' )]"
            fi

            local children_json="[]"
            if [[ -n "$children" ]]; then
                children_json="[$(echo "$children" | sed 's/,/","/g;s/^/"/;s/$/"/' )]"
            fi

            echo "    {"
            echo "      \"name\": \"${comp}\","
            echo "      \"file\": \"${rel_file}\","
            echo "      \"type\": \"${comp_type}\","
            echo "      \"lines\": ${lines},"
            echo "      \"imports\": ${imports_json},"
            echo "      \"props\": ${props_json},"
            echo "      \"children\": ${children_json}"
            echo "    }"
        done

        echo "  ]"
        echo "}"
    } > "$output_file" 2>/dev/null

    _fct_log "INFO" "コンポーネントマップ出力: ${output_file}"

    echo "$output_file"
    return 0
}

# ============================================================
# Module Interface: Init / Report / Score
# ============================================================
_fct_init() {
    _fct_log "INFO" "Frontend Component Tree v${FCT_VERSION} 初期化"
    return 0
}

_fct_init_message() {
    echo -e "  ${GREEN:-}v${FCT_VERSION} Frontend Component Tree: React/Next.jsコンポーネント階層解析${NC:-}" >&2
}

_fct_report() {
    echo -e "\n  ${BOLD:-}--- Frontend Component Tree v${FCT_VERSION} ---${NC:-}"
    echo -e "  Total Components  : ${_FCT_TOTAL_COMPONENTS}"
    echo -e "  Large Components  : ${_FCT_LARGE_COUNT}"
    echo -e "  Reusable Candidates: ${_FCT_REUSABLE_COUNT}"
    echo -e "  Prop Drilling     : ${_FCT_PROP_DRILLING_COUNT}"
    echo -e "  Score             : ${_FCT_SCORE}/100"
}

_fct_score() {
    local score=100

    # Penalize for large components
    if [[ $_FCT_TOTAL_COMPONENTS -gt 0 ]]; then
        local large_pct=$(( (_FCT_LARGE_COUNT * 100) / _FCT_TOTAL_COMPONENTS ))
        if [[ $large_pct -ge 30 ]]; then
            score=$((score - 30))
        elif [[ $large_pct -ge 15 ]]; then
            score=$((score - 15))
        elif [[ $large_pct -ge 5 ]]; then
            score=$((score - 5))
        fi
    fi

    # Penalize for prop drilling
    if [[ $_FCT_PROP_DRILLING_COUNT -ge 10 ]]; then
        score=$((score - 20))
    elif [[ $_FCT_PROP_DRILLING_COUNT -ge 5 ]]; then
        score=$((score - 10))
    elif [[ $_FCT_PROP_DRILLING_COUNT -ge 2 ]]; then
        score=$((score - 5))
    fi

    # Bonus for good component structure
    if [[ $_FCT_TOTAL_COMPONENTS -ge 5 && $_FCT_LARGE_COUNT -eq 0 ]]; then
        score=$((score + 0))  # Already at baseline
    fi

    [[ $score -lt 0 ]] && score=0
    [[ $score -gt 100 ]] && score=100

    _FCT_SCORE=$score
    echo "$score"
}

# ============================================================
# Run all analyses
# ============================================================
_fct_run_all() {
    local project_dir="${1:-.}"

    _fct_build_tree "$project_dir"
    _fct_find_reusable "$project_dir"
    _fct_detect_prop_drilling "$project_dir"
    _fct_find_large_components "$project_dir"
    _fct_generate_component_map "$project_dir"
    _fct_score

    _fct_report
}

# ============================================================
# Module Registry Registration
# ============================================================
_mr_register \
    --name "frontend-component-tree" \
    --version "213.0" \
    --description "React/Next.js コンポーネント階層解析・再利用性・プロップドリリング検出" \
    --init "_fct_init" \
    --report "_fct_report" \
    --score "_fct_score" \
    --enable-var "ENABLE_FRONTEND_COMPONENT_TREE" \
    --cli-flags "--component-tree:--no-component-tree" \
    --init-msg "_fct_init_message"
