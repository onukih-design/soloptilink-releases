#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v38.0 - Phase Optimizer Engine
# =============================================================================
# フェーズ実行順序の動的最適化エンジン。
# プロジェクト特性（ドメイン/スタック/規模）に基づき不要フェーズを自動スキップし、
# フェーズ間依存関係を動的に解決して最短パスで実行する。
#
# v38.0の核心: 「LP作成時にE2Eテスト不要」「静的サイトにDB統合不要」等を
# プロジェクト特性から自動判定し、無駄なフェーズをスキップ。
#
# Functions:
#   po_init              - Phase Optimizer初期化
#   po_analyze_project   - プロジェクト特性を分析
#   po_should_skip       - 指定フェーズをスキップすべきか判定
#   po_get_optimized_phases - 最適化されたフェーズ順序を返す
#   po_estimate_savings  - スキップによる時間/コスト節約見積もり
#   po_record_execution  - フェーズ実行結果を記録（学習用）
#   po_get_stats         - 最適化統計を返す
#
# All globals use the PO_ prefix.
# =============================================================================

[[ -n "${_PHASE_OPTIMIZER_LOADED:-}" ]] && return 0
_PHASE_OPTIMIZER_LOADED=1

declare -g PO_VERSION="38.0"
declare -g PO_ENABLED="${PO_ENABLED:-true}"

# プロジェクト分析結果
declare -g PO_PROJECT_TYPE=""     # static|spa|fullstack|api-only|saas
declare -g PO_HAS_DB="false"
declare -g PO_HAS_AUTH="false"
declare -g PO_HAS_API="false"
declare -g PO_COMPLEXITY=""       # simple|medium|complex|enterprise

# 統計
declare -g PO_PHASES_SKIPPED=0
declare -g PO_PHASES_EXECUTED=0
declare -g PO_ESTIMATED_SAVINGS=0

# スキップルール定義 (phase_name:condition)
declare -g -a PO_SKIP_RULES=()

# =============================================================================
# po_init - Phase Optimizer初期化
# =============================================================================
po_init() {
    local project_description="${1:-}"

    PO_PROJECT_TYPE=""
    PO_HAS_DB="false"
    PO_HAS_AUTH="false"
    PO_HAS_API="false"
    PO_COMPLEXITY=""
    PO_PHASES_SKIPPED=0
    PO_PHASES_EXECUTED=0
    PO_ESTIMATED_SAVINGS=0
    PO_SKIP_RULES=()

    if [[ -n "$project_description" ]]; then
        po_analyze_project "$project_description"
    fi

    return 0
}

# =============================================================================
# po_analyze_project - プロジェクト特性を分析
# =============================================================================
po_analyze_project() {
    local description="${1:-}"

    local lower_desc
    lower_desc=$(echo "$description" | tr '[:upper:]' '[:lower:]')

    # プロジェクトタイプ判定
    if echo "$lower_desc" | grep -qi -E "lp|landing|静的|static|portfolio|ポートフォリオ"; then
        PO_PROJECT_TYPE="static"
        PO_HAS_DB="false"
        PO_HAS_AUTH="false"
        PO_HAS_API="false"
        PO_COMPLEXITY="simple"
    elif echo "$lower_desc" | grep -qi -E "ios|iphone|ipad|swift|swiftui|uikit|xcode|モバイルアプリ|iosアプリ"; then
        PO_PROJECT_TYPE="ios-app"
        PO_HAS_DB="true"
        PO_HAS_AUTH="true"
        PO_HAS_API="true"
        PO_COMPLEXITY="medium"
    elif echo "$lower_desc" | grep -qi -E "api|バックエンド|backend|マイクロサービス|microservice"; then
        PO_PROJECT_TYPE="api-only"
        PO_HAS_DB="true"
        PO_HAS_AUTH="true"
        PO_HAS_API="true"
        PO_COMPLEXITY="medium"
    elif echo "$lower_desc" | grep -qi -E "saas|マルチテナント|multi.*tenant|サブスクリプション|subscription"; then
        PO_PROJECT_TYPE="saas"
        PO_HAS_DB="true"
        PO_HAS_AUTH="true"
        PO_HAS_API="true"
        PO_COMPLEXITY="enterprise"
    elif echo "$lower_desc" | grep -qi -E "spa|シングルページ|single.*page|ダッシュボード|dashboard"; then
        PO_PROJECT_TYPE="spa"
        PO_HAS_DB="true"
        PO_HAS_AUTH="true"
        PO_HAS_API="true"
        PO_COMPLEXITY="medium"
    else
        PO_PROJECT_TYPE="fullstack"
        PO_HAS_DB="true"
        PO_HAS_AUTH="true"
        PO_HAS_API="true"
        PO_COMPLEXITY="medium"
    fi

    # 複雑度補正
    if echo "$lower_desc" | grep -qi -E "簡単|シンプル|simple|basic|最小|minimal"; then
        PO_COMPLEXITY="simple"
    elif echo "$lower_desc" | grep -qi -E "エンタープライズ|enterprise|大規模|基幹|mission.*critical"; then
        PO_COMPLEXITY="enterprise"
    fi

    # スキップルール生成
    _po_generate_skip_rules

    return 0
}

# =============================================================================
# _po_generate_skip_rules - プロジェクト特性に基づくスキップルールを生成
# =============================================================================
_po_generate_skip_rules() {
    PO_SKIP_RULES=()

    case "$PO_PROJECT_TYPE" in
        static)
            PO_SKIP_RULES+=(
                "data_import:no_db"
                "saas_architecture:not_saas"
                "ai_integration:not_needed"
                "data_integrity:no_db"
                "audit_log_validation:no_db"
                "e2e_test:static_site"
                "smoke_test:static_site"
                "dependency_resolve:minimal_deps"
                "swarm_allocate:simple_project"
                "swarm_vote:simple_project"
                "governance_check:simple_project"
            )
            ;;
        ios-app)
            PO_SKIP_RULES+=(
                "data_import:not_needed"
                "saas_architecture:not_saas"
                "ai_integration:not_needed"
                "browser_test:ios_native"
                "auto_deploy:ios_app_store"
                "smoke_test:ios_uses_xcode_test"
            )
            ;;
        api-only)
            PO_SKIP_RULES+=(
                "saas_architecture:not_saas"
                "browser_test:no_frontend"
                "ai_integration:not_needed"
                "swarm_allocate:medium_project"
            )
            ;;
        spa)
            PO_SKIP_RULES+=(
                "saas_architecture:not_saas"
                "ai_integration:not_needed"
            )
            ;;
        saas)
            # SaaSは全フェーズ必要
            ;;
        fullstack)
            PO_SKIP_RULES+=(
                "saas_architecture:not_saas"
                "ai_integration:not_needed"
            )
            ;;
    esac

    # 複雑度に基づくスキップ
    if [[ "$PO_COMPLEXITY" == "simple" ]]; then
        PO_SKIP_RULES+=(
            "swarm_allocate:simple_project"
            "swarm_vote:simple_project"
            "governance_check:simple_project"
            "performance_profile:simple_project"
            "api_contract:simple_project"
        )
    fi
}

# =============================================================================
# po_should_skip - 指定フェーズをスキップすべきか判定
# Returns: 0=スキップ, 1=実行すべき
# =============================================================================
po_should_skip() {
    local phase_name="${1:-}"

    [[ "$PO_ENABLED" != "true" ]] && return 1
    [[ -z "$PO_PROJECT_TYPE" ]] && return 1

    for rule in "${PO_SKIP_RULES[@]}"; do
        local rule_phase="${rule%%:*}"
        if [[ "$rule_phase" == "$phase_name" ]]; then
            PO_PHASES_SKIPPED=$((PO_PHASES_SKIPPED + 1))
            return 0
        fi
    done

    return 1
}

# =============================================================================
# po_get_skip_reason - スキップ理由を取得
# =============================================================================
po_get_skip_reason() {
    local phase_name="${1:-}"

    for rule in "${PO_SKIP_RULES[@]}"; do
        local rule_phase="${rule%%:*}"
        local rule_reason="${rule##*:}"
        if [[ "$rule_phase" == "$phase_name" ]]; then
            echo "$rule_reason"
            return 0
        fi
    done

    echo "no_skip"
}

# =============================================================================
# po_get_optimized_phases - 最適化されたフェーズリストを返す
# =============================================================================
po_get_optimized_phases() {
    local all_phases="prompt_expand data_import scaffold url_analysis design saas_architecture swarm_allocate implementation ai_integration quality_gate functional_heal validation healing security data_integrity audit_log_validation e2e_test swarm_vote dependency_resolve performance_profile api_contract governance_check smoke_test browser_test deploy observatory knowledge_save"

    local optimized=""
    for phase in $all_phases; do
        if ! po_should_skip "$phase"; then
            optimized="${optimized} ${phase}"
            PO_PHASES_EXECUTED=$((PO_PHASES_EXECUTED + 1))
        fi
    done

    echo "$optimized" | xargs
}

# =============================================================================
# po_estimate_savings - スキップによるコスト節約見積もり
# =============================================================================
po_estimate_savings() {
    local cost_per_phase="${1:-0.30}"

    # bcが無ければ整数演算
    if command -v bc &>/dev/null; then
        PO_ESTIMATED_SAVINGS=$(echo "${PO_PHASES_SKIPPED} * ${cost_per_phase}" | bc 2>/dev/null || echo "0")
    else
        local cents
        cents=$(echo "$cost_per_phase" | tr -d '.' | sed 's/^0*//')
        cents="${cents:-30}"
        PO_ESTIMATED_SAVINGS="$((PO_PHASES_SKIPPED * cents / 100)).$(printf '%02d' $((PO_PHASES_SKIPPED * cents % 100)))"
    fi

    echo "$PO_ESTIMATED_SAVINGS"
}

# =============================================================================
# po_record_execution - フェーズ実行結果を記録
# =============================================================================
po_record_execution() {
    local phase_name="${1:-}"
    local duration_sec="${2:-0}"
    local was_skipped="${3:-false}"

    if [[ "$was_skipped" == "true" ]]; then
        PO_PHASES_SKIPPED=$((PO_PHASES_SKIPPED + 1))
    else
        PO_PHASES_EXECUTED=$((PO_PHASES_EXECUTED + 1))
    fi

    return 0
}

# =============================================================================
# po_get_stats - 最適化統計をJSON形式で返す
# =============================================================================
po_get_stats() {
    local total=$((PO_PHASES_SKIPPED + PO_PHASES_EXECUTED))
    local skip_rate=0
    [[ $total -gt 0 ]] && skip_rate=$((PO_PHASES_SKIPPED * 100 / total))

    cat <<EOF
{
  "version": "${PO_VERSION}",
  "project_type": "${PO_PROJECT_TYPE}",
  "complexity": "${PO_COMPLEXITY}",
  "has_db": ${PO_HAS_DB},
  "has_auth": ${PO_HAS_AUTH},
  "has_api": ${PO_HAS_API},
  "phases_skipped": ${PO_PHASES_SKIPPED},
  "phases_executed": ${PO_PHASES_EXECUTED},
  "skip_rate": ${skip_rate},
  "estimated_savings": "${PO_ESTIMATED_SAVINGS}"
}
EOF
}
