#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v101.0 - Real Validator Engine
# grep検証から実コンパイル検証へ
#
# 問題: 既存のquality-gate.shとcode-validator.shはgrepで
# パターンマッチングのみ。コードが実際にコンパイル/実行できるかは未検証。
#
# 解決: 実際のツール（tsc, eslint, prisma validate, pytest等）を
# 使って検証し、エラーを行番号+コンテキスト付きで返す。
#
# v101.0: Real Compilation + Precise Feedback
# ============================================================

[[ -n "${_REAL_VALIDATOR_LOADED:-}" ]] && return 0
_REAL_VALIDATOR_LOADED=1

# --- グローバル状態 ---
RV_VERSION="101.0"
RV_INITIALIZED=false
RV_TIMEOUT=60                    # 各ツールのタイムアウト(秒)
RV_MAX_ERRORS_PER_FILE=10       # ファイルあたり最大エラー表示数

# --- 統計 ---
RV_TOTAL_CHECKS=0
RV_TOTAL_ERRORS=0
RV_TOTAL_WARNINGS=0
RV_TSC_ERRORS=0
RV_ESLINT_ERRORS=0
RV_PRISMA_ERRORS=0

# --- 検証結果バッファ ---
RV_ERROR_REPORT=""               # 構造化エラーレポート

# ============================================================
# 初期化
# ============================================================
rv_init() {
    RV_TOTAL_CHECKS=0
    RV_TOTAL_ERRORS=0
    RV_TOTAL_WARNINGS=0
    RV_TSC_ERRORS=0
    RV_ESLINT_ERRORS=0
    RV_PRISMA_ERRORS=0
    RV_ERROR_REPORT=""
    RV_INITIALIZED=true
    return 0
}

# ============================================================
# メイン検証関数
# プロジェクトディレクトリを受け取り、全ツールで検証
# 戻り値: 構造化エラーレポート（AIに渡すのに最適な形式）
# ============================================================
rv_validate_project() {
    local project_dir="$1"
    local phase="${2:-implementation}"

    [[ ! -d "$project_dir" ]] && return 1

    RV_ERROR_REPORT=""
    local errors_found=0

    # --- TypeScript検証 ---
    if [[ -f "${project_dir}/tsconfig.json" ]]; then
        local tsc_result
        tsc_result=$(_rv_run_tsc "$project_dir")
        if [[ -n "$tsc_result" ]]; then
            RV_ERROR_REPORT+="$tsc_result"
            errors_found=1
        fi
    fi

    # --- ESLint検証 ---
    local eslint_result
    eslint_result=$(_rv_run_eslint "$project_dir")
    if [[ -n "$eslint_result" ]]; then
        RV_ERROR_REPORT+="$eslint_result"
        errors_found=1
    fi

    # --- Prisma検証 ---
    if [[ -f "${project_dir}/prisma/schema.prisma" ]]; then
        local prisma_result
        prisma_result=$(_rv_run_prisma_validate "$project_dir")
        if [[ -n "$prisma_result" ]]; then
            RV_ERROR_REPORT+="$prisma_result"
            errors_found=1
        fi
    fi

    # --- Import整合性検証 ---
    local import_result
    import_result=$(_rv_check_imports "$project_dir")
    if [[ -n "$import_result" ]]; then
        RV_ERROR_REPORT+="$import_result"
        errors_found=1
    fi

    # --- API/フロントエンド型整合性 ---
    local type_result
    type_result=$(_rv_check_type_consistency "$project_dir")
    if [[ -n "$type_result" ]]; then
        RV_ERROR_REPORT+="$type_result"
        errors_found=1
    fi

    RV_TOTAL_CHECKS=$((RV_TOTAL_CHECKS + 1))

    if [[ $errors_found -eq 0 ]]; then
        echo ""
        return 0
    fi

    echo "$RV_ERROR_REPORT"
    return 1
}

# ============================================================
# TypeScript コンパイル検証
# ============================================================
_rv_run_tsc() {
    local project_dir="$1"
    local result=""

    # npx tsc --noEmit で型チェック
    if command -v npx &>/dev/null; then
        local tsc_output
        tsc_output=$(cd "$project_dir" && timeout "$RV_TIMEOUT" npx tsc --noEmit --pretty false 2>&1 || true)

        if [[ -n "$tsc_output" && "$tsc_output" == *"error TS"* ]]; then
            local error_count
            error_count=$(echo "$tsc_output" | grep -c "error TS" || echo "0")
            RV_TSC_ERRORS=$((RV_TSC_ERRORS + error_count))
            RV_TOTAL_ERRORS=$((RV_TOTAL_ERRORS + error_count))

            result+="
## TypeScriptコンパイルエラー (${error_count}件)
"
            # 各エラーを構造化して出力（行番号+コンテキスト付き）
            echo "$tsc_output" | grep "error TS" | head -"$RV_MAX_ERRORS_PER_FILE" | while IFS= read -r line; do
                # 形式: src/app/api/route.ts(15,3): error TS2345: ...
                local file_path
                file_path=$(echo "$line" | sed 's/(.*//')
                local line_num
                line_num=$(echo "$line" | sed 's/.*(\([0-9]*\),.*/\1/')
                local error_msg
                error_msg=$(echo "$line" | sed 's/.*error TS[0-9]*: //')

                result+="### ${file_path}:${line_num}
- エラー: ${error_msg}
"
                # エラー箇所のソースコード表示（前後3行）
                if [[ -f "${project_dir}/${file_path}" ]]; then
                    local context
                    context=$(sed -n "$((line_num > 3 ? line_num - 3 : 1)),${line_num}p" "${project_dir}/${file_path}" 2>/dev/null | head -7)
                    if [[ -n "$context" ]]; then
                        result+='```typescript
'"${context}"'
```
'
                    fi
                fi
            done

            echo "$result"
            return
        fi
    fi

    echo ""
}

# ============================================================
# ESLint検証
# ============================================================
_rv_run_eslint() {
    local project_dir="$1"
    local result=""

    # ESLint設定がある場合のみ
    if [[ -f "${project_dir}/.eslintrc.json" || -f "${project_dir}/.eslintrc.js" || -f "${project_dir}/eslint.config.js" || -f "${project_dir}/eslint.config.mjs" ]] && command -v npx &>/dev/null; then
        local eslint_output
        eslint_output=$(cd "$project_dir" && timeout "$RV_TIMEOUT" npx eslint . --format compact --no-error-on-unmatched-pattern 2>&1 | grep -E "Error|Warning" | head -20 || true)

        if [[ -n "$eslint_output" ]]; then
            local error_count
            error_count=$(echo "$eslint_output" | grep -c "Error" || echo "0")
            RV_ESLINT_ERRORS=$((RV_ESLINT_ERRORS + error_count))
            RV_TOTAL_ERRORS=$((RV_TOTAL_ERRORS + error_count))

            result+="
## ESLintエラー (${error_count}件)
"
            echo "$eslint_output" | head -"$RV_MAX_ERRORS_PER_FILE" | while IFS= read -r line; do
                result+="- ${line}
"
            done

            echo "$result"
            return
        fi
    fi

    echo ""
}

# ============================================================
# Prisma Schema検証
# ============================================================
_rv_run_prisma_validate() {
    local project_dir="$1"
    local result=""

    if command -v npx &>/dev/null; then
        local prisma_output
        prisma_output=$(cd "$project_dir" && timeout "$RV_TIMEOUT" npx prisma validate 2>&1 || true)

        if [[ "$prisma_output" == *"error"* || "$prisma_output" == *"Error"* ]]; then
            RV_PRISMA_ERRORS=$((RV_PRISMA_ERRORS + 1))
            RV_TOTAL_ERRORS=$((RV_TOTAL_ERRORS + 1))

            result+="
## Prismaスキーマエラー
${prisma_output}
"
            echo "$result"
            return
        fi
    fi

    echo ""
}

# ============================================================
# Import整合性検証（存在しないファイルをimportしていないか）
# ============================================================
_rv_check_imports() {
    local project_dir="$1"
    local result=""
    local broken_imports=0

    # TypeScript/JavaScript のimport文を抽出
    while IFS= read -r file; do
        [[ -f "$file" ]] || continue
        # node_modules内は無視
        [[ "$file" == *"node_modules"* ]] && continue

        # 相対import（from './xxx' or from '../xxx'）を抽出
        grep -nE "from ['\"]\.\.?/" "$file" 2>/dev/null | while IFS= read -r import_line; do
            local line_num
            line_num=$(echo "$import_line" | cut -d: -f1)
            local import_path
            import_path=$(echo "$import_line" | sed "s/.*from ['\"]//;s/['\"].*//" )

            # 相対パスを解決
            local file_dir
            file_dir=$(dirname "$file")
            local resolved="${file_dir}/${import_path}"

            # 拡張子なしの場合、.ts, .tsx, .js, .jsx, /index.ts を試す
            local found=false
            for ext in "" ".ts" ".tsx" ".js" ".jsx" "/index.ts" "/index.tsx" "/index.js"; do
                if [[ -f "${resolved}${ext}" ]]; then
                    found=true
                    break
                fi
            done

            if ! $found; then
                broken_imports=$((broken_imports + 1))
                local rel_file="${file#$project_dir/}"
                result+="- ${rel_file}:${line_num} → import '${import_path}' が見つかりません
"
            fi
        done
    done < <(find "$project_dir" -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" 2>/dev/null | grep -v node_modules | head -100)

    if [[ $broken_imports -gt 0 ]]; then
        RV_TOTAL_ERRORS=$((RV_TOTAL_ERRORS + broken_imports))
        echo "
## インポート整合性エラー (${broken_imports}件)
${result}"
    else
        echo ""
    fi
}

# ============================================================
# API/フロントエンド型整合性検証
# ============================================================
_rv_check_type_consistency() {
    local project_dir="$1"
    local result=""
    local issues=0

    # Prismaスキーマのモデル名を取得
    local schema_file="${project_dir}/prisma/schema.prisma"
    if [[ -f "$schema_file" ]]; then
        local models
        models=$(grep "^model " "$schema_file" 2>/dev/null | awk '{print $2}')

        for model in $models; do
            # モデルに対応するAPIルートが存在するか
            local model_lower
            model_lower=$(echo "$model" | tr '[:upper:]' '[:lower:]')

            local has_api=false
            # Next.js App Router パターン
            for api_path in \
                "${project_dir}/app/api/${model_lower}" \
                "${project_dir}/app/api/${model_lower}s" \
                "${project_dir}/app/api/v1/${model_lower}" \
                "${project_dir}/app/api/v1/${model_lower}s" \
                "${project_dir}/src/app/api/${model_lower}" \
                "${project_dir}/src/app/api/${model_lower}s"; do
                if [[ -d "$api_path" ]]; then
                    has_api=true
                    break
                fi
            done

            # CRUDページが存在するか
            local has_page=false
            for page_path in \
                "${project_dir}/app/${model_lower}" \
                "${project_dir}/app/${model_lower}s" \
                "${project_dir}/src/app/${model_lower}" \
                "${project_dir}/src/app/${model_lower}s"; do
                if [[ -d "$page_path" ]]; then
                    has_page=true
                    break
                fi
            done

            if ! $has_api; then
                issues=$((issues + 1))
                result+="- Prismaモデル '${model}' に対応するAPIルートが見つかりません
"
            fi
        done
    fi

    if [[ $issues -gt 0 ]]; then
        RV_TOTAL_WARNINGS=$((RV_TOTAL_WARNINGS + issues))
        echo "
## API/スキーマ整合性警告 (${issues}件)
${result}"
    else
        echo ""
    fi
}

# ============================================================
# AIフィードバック生成（修正プロンプト用）
# エラーレポートをAIが理解しやすい形式に変換
# ============================================================
rv_build_fix_prompt() {
    local error_report="$1"
    local original_prompt="${2:-}"

    [[ -z "$error_report" ]] && return

    local fix_prompt="以下のエラーを修正してください。各エラーに対して、該当ファイルの該当箇所を正確に修正してください。

## 検出されたエラー（実コンパイラ出力）
${error_report}

## 修正ルール
1. **指摘されたエラーのみ修正**（他の部分は触らない）
2. **型エラーは正しい型を定義して解決**（anyやts-ignoreは禁止）
3. **存在しないインポートは正しいパスに修正**
4. **Prismaスキーマエラーはスキーマ定義を修正**
5. 修正後のファイルを --- FILE: path --- マーカー付きで出力"

    echo "$fix_prompt"
}

# ============================================================
# レポート
# ============================================================
rv_report() {
    echo "=== Real Validator Engine v${RV_VERSION} ==="
    echo "  Checks: ${RV_TOTAL_CHECKS}"
    echo "  Errors: ${RV_TOTAL_ERRORS} (tsc:${RV_TSC_ERRORS}, eslint:${RV_ESLINT_ERRORS}, prisma:${RV_PRISMA_ERRORS})"
    echo "  Warnings: ${RV_TOTAL_WARNINGS}"
}

rv_score() {
    if [[ $RV_TOTAL_CHECKS -eq 0 ]]; then
        echo "50"
        return
    fi
    if [[ $RV_TOTAL_ERRORS -eq 0 ]]; then
        echo "100"
    elif [[ $RV_TOTAL_ERRORS -lt 5 ]]; then
        echo "75"
    elif [[ $RV_TOTAL_ERRORS -lt 20 ]]; then
        echo "50"
    else
        echo "25"
    fi
}

# ============================================================
# Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "real-validator" \
        --version "$RV_VERSION" \
        --description "実コンパイル検証エンジン - tsc/eslint/prisma validate × 行番号付きフィードバック" \
        --init "rv_init" \
        --report "rv_report" \
        --score "rv_score" \
        --enable-var "ENABLE_REAL_VALIDATOR" \
        --cli-flags "--real-validator:--no-real-validator"
fi

# v2003.1: source時のexit codeを確実に0にする
true
