#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v42.0 - Prompt Fusion Engine
# =============================================================================
# Prompt Memory(v37) + Enterprise Patterns(v31) + Domain Knowledge を融合し、
# Claude に渡す最適プロンプトを自動合成するエンジン。
#
# v42.0の核心: 過去の成功プロンプトパターン + 参照実装テンプレート +
# ドメイン知識を1つに融合し、Claudeが最も高品質なコードを出力する
# プロンプトを自動生成する。
#
# Functions:
#   pf_init              - Prompt Fusion初期化
#   pf_fuse              - プロンプト融合（メイン関数）
#   pf_inject_history    - 過去の成功パターンを注入
#   pf_inject_patterns   - エンプラパターンを注入
#   pf_inject_domain     - ドメイン知識を注入
#   pf_inject_anti       - アンチパターン警告を注入
#   pf_score_prompt      - 融合プロンプトの品質スコア
#   pf_get_stats         - 統計情報を返す
#   pf_save_history      - 融合履歴永続化
#
# All globals use the PF_ prefix.
# =============================================================================

[[ -n "${_PROMPT_FUSION_LOADED:-}" ]] && return 0
_PROMPT_FUSION_LOADED=1

declare -g PF_VERSION="42.0"
declare -g PF_ENABLED="${PF_ENABLED:-true}"

# 融合結果
declare -g PF_TOTAL_FUSIONS=0
declare -g PF_AVG_SCORE=0
declare -g PF_HISTORY_INJECTED=0
declare -g PF_PATTERNS_INJECTED=0
declare -g PF_DOMAIN_INJECTED=0
declare -g PF_ANTI_INJECTED=0
declare -g PF_HISTORY_FILE=""
declare -g PF_LAST_FUSED_PROMPT=""

# スコア履歴（最新10件）
declare -g -a PF_SCORE_HISTORY=()

# =============================================================================
# pf_init - Prompt Fusion初期化
# =============================================================================
pf_init() {
    local session_id="${1:-default}"

    PF_TOTAL_FUSIONS=0
    PF_AVG_SCORE=0
    PF_HISTORY_INJECTED=0
    PF_PATTERNS_INJECTED=0
    PF_DOMAIN_INJECTED=0
    PF_ANTI_INJECTED=0
    PF_LAST_FUSED_PROMPT=""
    PF_SCORE_HISTORY=()

    local knowledge_dir="${HOME}/.soloptilink/knowledge"
    mkdir -p "$knowledge_dir" 2>/dev/null || true
    PF_HISTORY_FILE="${knowledge_dir}/prompt_fusion_history.jsonl"

    return 0
}

# =============================================================================
# pf_fuse - プロンプト融合（メイン関数）
# Args: base_prompt, phase_type(backend|frontend|api), domain
# Returns: fused prompt string
# =============================================================================
pf_fuse() {
    local base_prompt="${1:-}"
    local phase_type="${2:-backend}"
    local domain="${3:-general}"

    [[ -z "$base_prompt" ]] && echo "" && return 0

    local fused="$base_prompt"
    local injection_count=0

    # 1. 過去の成功パターンを注入
    local history_section
    history_section=$(pf_inject_history "$domain" "$phase_type")
    if [[ -n "$history_section" ]]; then
        fused="${fused}

${history_section}"
        injection_count=$((injection_count + 1))
        PF_HISTORY_INJECTED=$((PF_HISTORY_INJECTED + 1))
    fi

    # 2. エンタープライズパターンを注入
    local pattern_section
    pattern_section=$(pf_inject_patterns "$phase_type")
    if [[ -n "$pattern_section" ]]; then
        fused="${fused}

${pattern_section}"
        injection_count=$((injection_count + 1))
        PF_PATTERNS_INJECTED=$((PF_PATTERNS_INJECTED + 1))
    fi

    # 3. ドメイン知識を注入
    local domain_section
    domain_section=$(pf_inject_domain "$domain")
    if [[ -n "$domain_section" ]]; then
        fused="${fused}

${domain_section}"
        injection_count=$((injection_count + 1))
        PF_DOMAIN_INJECTED=$((PF_DOMAIN_INJECTED + 1))
    fi

    # 4. アンチパターン警告を注入
    local anti_section
    anti_section=$(pf_inject_anti "$phase_type")
    if [[ -n "$anti_section" ]]; then
        fused="${fused}

${anti_section}"
        injection_count=$((injection_count + 1))
        PF_ANTI_INJECTED=$((PF_ANTI_INJECTED + 1))
    fi

    PF_TOTAL_FUSIONS=$((PF_TOTAL_FUSIONS + 1))
    PF_LAST_FUSED_PROMPT="$fused"

    # スコア算出
    local score
    score=$(pf_score_prompt "$fused" "$injection_count")
    PF_SCORE_HISTORY+=("$score")
    if [[ ${#PF_SCORE_HISTORY[@]} -gt 10 ]]; then
        PF_SCORE_HISTORY=("${PF_SCORE_HISTORY[@]:1}")
    fi
    _pf_update_avg_score

    echo "$fused"
}

# =============================================================================
# pf_inject_history - 過去の成功パターンを注入
# =============================================================================
pf_inject_history() {
    local domain="${1:-general}"
    local phase_type="${2:-backend}"

    # Prompt Memoryから成功パターンを取得
    if type -t pm_get_success_patterns &>/dev/null; then
        local patterns
        patterns=$(pm_get_success_patterns "$domain" 2>/dev/null || echo "")
        if [[ -n "$patterns" && "$patterns" != "[]" && "$patterns" != "" ]]; then
            echo "## LEARNED SUCCESS PATTERNS (from previous sessions)
Based on past successful builds for '${domain}' domain:
${patterns}"
            return 0
        fi
    fi

    echo ""
}

# =============================================================================
# pf_inject_patterns - エンタープライズパターンを注入
# =============================================================================
pf_inject_patterns() {
    local phase_type="${1:-backend}"

    # Enterprise Patternsから参照実装を取得
    if type -t ep_inject_into_prompt &>/dev/null; then
        local ep_content
        ep_content=$(ep_inject_into_prompt "$phase_type" 2>/dev/null || echo "")
        if [[ -n "$ep_content" ]]; then
            echo "$ep_content"
            return 0
        fi
    fi

    # フォールバック: 基本的なパターンガイドラインを注入
    case "$phase_type" in
        backend|api)
            echo "## ENTERPRISE PATTERNS REMINDER
- Use service layer pattern (separate business logic from routes)
- Wrap DB operations in transactions
- Add zod/pydantic input validation on all endpoints
- Include proper error handling with typed error responses
- Add audit logging for all CRUD operations"
            ;;
        frontend)
            echo "## ENTERPRISE PATTERNS REMINDER
- Use React Hook Form + zod for form validation
- Implement proper loading/error/empty states
- Use ErrorBoundary for graceful error handling
- Avoid hardcoded data - all data must come from API
- Use useSWR/React Query for data fetching with caching"
            ;;
        *)
            echo ""
            ;;
    esac
}

# =============================================================================
# pf_inject_domain - ドメイン知識を注入
# =============================================================================
pf_inject_domain() {
    local domain="${1:-general}"

    [[ "$domain" == "general" ]] && echo "" && return 0

    # Domain Knowledgeから取得
    if type -t dk_get_domain_context &>/dev/null; then
        local dk_content
        dk_content=$(dk_get_domain_context "$domain" 2>/dev/null || echo "")
        if [[ -n "$dk_content" ]]; then
            echo "$dk_content"
            return 0
        fi
    fi

    # フォールバック: 基本的なドメインヒントを返す
    case "$domain" in
        crm)
            echo "## DOMAIN KNOWLEDGE: CRM
Key entities: Customer, Contact, Deal, Activity, Pipeline
Critical: Lead scoring, conversion tracking, activity timeline"
            ;;
        ecommerce)
            echo "## DOMAIN KNOWLEDGE: E-Commerce
Key entities: Product, Cart, Order, Payment, Review
Critical: Inventory management, payment processing, order lifecycle"
            ;;
        healthcare)
            echo "## DOMAIN KNOWLEDGE: Healthcare
Key entities: Patient, Appointment, Prescription, MedicalRecord
Critical: HIPAA compliance, data encryption, audit trails"
            ;;
        *)
            echo ""
            ;;
    esac
}

# =============================================================================
# pf_inject_anti - アンチパターン警告を注入
# =============================================================================
pf_inject_anti() {
    local phase_type="${1:-backend}"

    echo "## CRITICAL ANTI-PATTERNS (NEVER DO THESE)
- NEVER use hardcoded/mock data arrays (const items = [{...}])
- NEVER leave empty event handlers (onClick={() => {}})
- NEVER use Date.now() for IDs
- NEVER use localStorage as primary data store
- NEVER leave TODO/FIXME/HACK comments
- NEVER use 'any' type in TypeScript
- NEVER leave console.log in production code
- NEVER use eslint-disable comments
- NEVER skip error handling in API calls
- NEVER hardcode API URLs (use environment variables)"
}

# =============================================================================
# pf_score_prompt - 融合プロンプトの品質スコア (0-100)
# =============================================================================
pf_score_prompt() {
    local prompt="${1:-}"
    local injection_count="${2:-0}"

    [[ -z "$prompt" ]] && echo "0" && return 0

    local score=50  # 基礎点

    # 注入数に応じて加点 (+10 per injection, max +40)
    local inject_bonus=$((injection_count * 10))
    [[ $inject_bonus -gt 40 ]] && inject_bonus=40
    score=$((score + inject_bonus))

    # プロンプト長に応じて加点（500文字以上で+5、1000以上で+10）
    local prompt_len=${#prompt}
    if [[ $prompt_len -gt 1000 ]]; then
        score=$((score + 10))
    elif [[ $prompt_len -gt 500 ]]; then
        score=$((score + 5))
    fi

    # キーワード存在チェック
    if echo "$prompt" | grep -q -i "transaction\|トランザクション" 2>/dev/null; then
        score=$((score + 2))
    fi
    if echo "$prompt" | grep -q -i "validation\|バリデーション\|zod\|pydantic" 2>/dev/null; then
        score=$((score + 2))
    fi
    if echo "$prompt" | grep -q -i "error.*handling\|エラー" 2>/dev/null; then
        score=$((score + 2))
    fi
    if echo "$prompt" | grep -q -i "audit\|監査" 2>/dev/null; then
        score=$((score + 2))
    fi
    if echo "$prompt" | grep -q -i "anti.pattern\|NEVER" 2>/dev/null; then
        score=$((score + 2))
    fi

    # 最大100点
    [[ $score -gt 100 ]] && score=100

    echo "$score"
}

# =============================================================================
# _pf_update_avg_score - 平均スコア更新
# =============================================================================
_pf_update_avg_score() {
    local count=${#PF_SCORE_HISTORY[@]}
    [[ $count -eq 0 ]] && return 0

    local total=0
    for s in "${PF_SCORE_HISTORY[@]}"; do
        total=$((total + s))
    done
    PF_AVG_SCORE=$((total / count))
}

# =============================================================================
# pf_get_stats - 統計情報をJSON形式で返す
# =============================================================================
pf_get_stats() {
    cat <<EOF
{
  "version": "${PF_VERSION}",
  "total_fusions": ${PF_TOTAL_FUSIONS},
  "avg_score": ${PF_AVG_SCORE},
  "history_injected": ${PF_HISTORY_INJECTED},
  "patterns_injected": ${PF_PATTERNS_INJECTED},
  "domain_injected": ${PF_DOMAIN_INJECTED},
  "anti_injected": ${PF_ANTI_INJECTED},
  "recent_scores": [$(IFS=,; echo "${PF_SCORE_HISTORY[*]}")]
}
EOF
}

# =============================================================================
# pf_save_history - 融合履歴を永続化
# =============================================================================
pf_save_history() {
    [[ -z "$PF_HISTORY_FILE" ]] && return 0

    local timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date +"%Y-%m-%d")

    echo "{\"timestamp\":\"${timestamp}\",\"total_fusions\":${PF_TOTAL_FUSIONS},\"avg_score\":${PF_AVG_SCORE},\"history_injected\":${PF_HISTORY_INJECTED},\"patterns_injected\":${PF_PATTERNS_INJECTED}}" >> "$PF_HISTORY_FILE" 2>/dev/null || true
    return 0
}
