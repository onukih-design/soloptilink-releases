#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v305.0 - E-Commerce Engine
# =============================================================================
# EC自動生成: 商品モデル/カート/チェックアウト/注文管理/在庫管理
#
# 全globals: EE_ prefix
# =============================================================================

[[ -n "${_ECOMMERCE_ENGINE_LOADED:-}" ]] && return 0
_ECOMMERCE_ENGINE_LOADED=1

declare -g EE_VERSION="305.0"
declare -g EE_INITIALIZED=false
declare -g EE_GENERATED_COUNT=0
declare -g ENABLE_ECOMMERCE_ENGINE="${ENABLE_ECOMMERCE_ENGINE:-true}"

readonly EE_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly EE_YELLOW="${CLR_YELLOW:-\033[0;33m}"
readonly EE_RED="${CLR_RED:-\033[0;31m}"
readonly EE_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly EE_BOLD="${CLR_BOLD:-\033[1m}"
readonly EE_NC="${CLR_NC:-\033[0m}"

_ee_log() { echo -e "  ${EE_CYAN}[EE]${EE_NC} $*" >&2; }
_ee_ok()  { echo -e "  ${EE_GREEN}[EE] OK${EE_NC} $*" >&2; }
_ee_warn(){ echo -e "  ${EE_YELLOW}[EE] WARN${EE_NC} $*" >&2; }
_ee_err() { echo -e "  ${EE_RED}[EE] ERR${EE_NC} $*" >&2; }

ee_init() { EE_INITIALIZED=true; EE_GENERATED_COUNT=0; return 0; }
ee_report() {
    [[ "$EE_INITIALIZED" != "true" ]] && return 0
    echo -e "\n  ${EE_BOLD}--- E-Commerce Engine v${EE_VERSION} ---${EE_NC}" >&2
    echo -e "  生成コンポーネント数: ${EE_GENERATED_COUNT}" >&2
}
ee_score() {
    [[ "$EE_INITIALIZED" != "true" ]] && { echo "0"; return; }
    local s=50; [[ $EE_GENERATED_COUNT -ge 3 ]] && s=80; [[ $EE_GENERATED_COUNT -ge 5 ]] && s=95; echo "$s"
}
ee_init_message() { echo -e "  ${EE_GREEN}v${EE_VERSION} ecommerce-engine: EC自動生成エンジン${EE_NC}" >&2; }

# =============================================================================
# _ee_generate_product_model() - Product model with variants/images
# =============================================================================
_ee_generate_product_model() {
    local project_dir="${1:-.}"
    _ee_log "商品データモデル生成"

    local prisma_dir="${project_dir}/prisma"
    mkdir -p "$prisma_dir"

    local model_snippet='
// --- E-Commerce Models (v305.0) ---
model Product {
  id          String   @id @default(cuid())
  name        String
  slug        String   @unique
  description String?  @db.Text
  price       Int      // cents
  comparePrice Int?
  sku         String?  @unique
  status      ProductStatus @default(DRAFT)
  variants    ProductVariant[]
  images      ProductImage[]
  inventory   Inventory?
  orderItems  OrderItem[]
  categoryId  String?
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}

enum ProductStatus { DRAFT ACTIVE ARCHIVED }

model ProductVariant {
  id        String @id @default(cuid())
  productId String
  product   Product @relation(fields: [productId], references: [id], onDelete: Cascade)
  name      String
  sku       String? @unique
  price     Int
  stock     Int    @default(0)
  options   Json?
}

model ProductImage {
  id        String @id @default(cuid())
  productId String
  product   Product @relation(fields: [productId], references: [id], onDelete: Cascade)
  url       String
  alt       String?
  position  Int    @default(0)
}

model Order {
  id         String      @id @default(cuid())
  orderNumber String     @unique
  userId     String
  status     OrderStatus @default(PENDING)
  subtotal   Int
  tax        Int         @default(0)
  shipping   Int         @default(0)
  total      Int
  items      OrderItem[]
  shippingAddress Json?
  paymentMethod   String?
  paidAt     DateTime?
  shippedAt  DateTime?
  deliveredAt DateTime?
  createdAt  DateTime    @default(now())
  updatedAt  DateTime    @updatedAt
}

enum OrderStatus { PENDING PAID PROCESSING SHIPPED DELIVERED CANCELLED REFUNDED }

model OrderItem {
  id        String  @id @default(cuid())
  orderId   String
  order     Order   @relation(fields: [orderId], references: [id], onDelete: Cascade)
  productId String
  product   Product @relation(fields: [productId], references: [id])
  name      String
  price     Int
  quantity  Int
  variantId String?
}

model Inventory {
  id        String  @id @default(cuid())
  productId String  @unique
  product   Product @relation(fields: [productId], references: [id], onDelete: Cascade)
  stock     Int     @default(0)
  reserved  Int     @default(0)
  lowStockThreshold Int @default(10)
  updatedAt DateTime @updatedAt
}'

    local schema_file="${prisma_dir}/schema.prisma"
    if [[ -f "$schema_file" ]]; then
        if ! grep -q "model Product" "$schema_file" 2>/dev/null; then
            echo "$model_snippet" >> "$schema_file"
        fi
    else
        cat > "$schema_file" <<SEOF
generator client { provider = "prisma-client-js" }
datasource db { provider = "postgresql"; url = env("DATABASE_URL") }
${model_snippet}
SEOF
    fi

    EE_GENERATED_COUNT=$((EE_GENERATED_COUNT + 1))
    _ee_ok "商品モデル生成完了"
    return 0
}

# =============================================================================
# _ee_generate_cart() - Shopping cart
# =============================================================================
_ee_generate_cart() {
    local project_dir="${1:-.}"
    _ee_log "ショッピングカート生成"

    local comp_dir="${project_dir}/src/components/shop"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/CartProvider.tsx" <<'EOF'
'use client';
import { createContext, useContext, useState, useCallback, ReactNode } from 'react';

interface CartItem { productId: string; name: string; price: number; quantity: number; image?: string; variantId?: string; }
interface CartCtx { items: CartItem[]; addItem: (item: Omit<CartItem, 'quantity'>) => void; removeItem: (productId: string) => void; updateQuantity: (productId: string, qty: number) => void; clearCart: () => void; total: number; itemCount: number; }

const CartContext = createContext<CartCtx | null>(null);
export const useCart = () => { const c = useContext(CartContext); if (!c) throw new Error('useCart must be inside CartProvider'); return c; };

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);

  const addItem = useCallback((item: Omit<CartItem, 'quantity'>) => {
    setItems(prev => {
      const existing = prev.find(i => i.productId === item.productId && i.variantId === item.variantId);
      if (existing) return prev.map(i => i.productId === item.productId && i.variantId === item.variantId ? { ...i, quantity: i.quantity + 1 } : i);
      return [...prev, { ...item, quantity: 1 }];
    });
  }, []);

  const removeItem = useCallback((productId: string) => setItems(prev => prev.filter(i => i.productId !== productId)), []);
  const updateQuantity = useCallback((productId: string, qty: number) => {
    if (qty <= 0) { removeItem(productId); return; }
    setItems(prev => prev.map(i => i.productId === productId ? { ...i, quantity: qty } : i));
  }, [removeItem]);
  const clearCart = useCallback(() => setItems([]), []);
  const total = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const itemCount = items.reduce((sum, i) => sum + i.quantity, 0);

  return <CartContext.Provider value={{ items, addItem, removeItem, updateQuantity, clearCart, total, itemCount }}>{children}</CartContext.Provider>;
}
EOF

    cat > "${comp_dir}/CartDrawer.tsx" <<'EOF'
'use client';
import { useCart } from './CartProvider';
import { X, Plus, Minus, ShoppingBag } from 'lucide-react';
import Link from 'next/link';

export function CartDrawer({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { items, removeItem, updateQuantity, total, itemCount } = useCart();

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-50">
      <div className="absolute inset-0 bg-black/50" onClick={onClose} />
      <div className="absolute right-0 top-0 h-full w-full max-w-md bg-white shadow-xl flex flex-col">
        <div className="flex items-center justify-between p-4 border-b">
          <h2 className="font-bold text-lg flex items-center gap-2"><ShoppingBag size={20} /> カート ({itemCount})</h2>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded"><X size={20} /></button>
        </div>
        <div className="flex-1 overflow-y-auto p-4">
          {items.length === 0 ? (
            <p className="text-gray-500 text-center py-12">カートは空です</p>
          ) : (
            <div className="space-y-4">
              {items.map(item => (
                <div key={item.productId} className="flex gap-4 items-start">
                  {item.image && <img src={item.image} alt={item.name} className="w-16 h-16 rounded object-cover" />}
                  <div className="flex-1">
                    <p className="font-medium text-sm">{item.name}</p>
                    <p className="text-gray-500 text-sm">&yen;{item.price.toLocaleString()}</p>
                    <div className="flex items-center gap-2 mt-2">
                      <button onClick={() => updateQuantity(item.productId, item.quantity - 1)} className="p-1 border rounded hover:bg-gray-50"><Minus size={14} /></button>
                      <span className="text-sm w-8 text-center">{item.quantity}</span>
                      <button onClick={() => updateQuantity(item.productId, item.quantity + 1)} className="p-1 border rounded hover:bg-gray-50"><Plus size={14} /></button>
                    </div>
                  </div>
                  <button onClick={() => removeItem(item.productId)} className="text-gray-400 hover:text-red-500"><X size={16} /></button>
                </div>
              ))}
            </div>
          )}
        </div>
        {items.length > 0 && (
          <div className="p-4 border-t space-y-3">
            <div className="flex justify-between font-bold text-lg"><span>合計</span><span>&yen;{total.toLocaleString()}</span></div>
            <Link href="/checkout" onClick={onClose} className="block w-full bg-blue-600 text-white text-center py-3 rounded-lg font-medium hover:bg-blue-700">レジに進む</Link>
          </div>
        )}
      </div>
    </div>
  );
}
EOF

    EE_GENERATED_COUNT=$((EE_GENERATED_COUNT + 2))
    _ee_ok "カート生成完了"
    return 0
}

# =============================================================================
# _ee_generate_checkout() - Checkout flow
# =============================================================================
_ee_generate_checkout() {
    local project_dir="${1:-.}"
    _ee_log "チェックアウトフロー生成"

    local page_dir="${project_dir}/src/app/checkout"
    mkdir -p "$page_dir"

    cat > "${page_dir}/page.tsx" <<'EOF'
'use client';
import { useState } from 'react';
import { useCart } from '@/components/shop/CartProvider';
import { useRouter } from 'next/navigation';
import { CheckCircle } from 'lucide-react';

type Step = 'address' | 'payment' | 'confirm';

export default function CheckoutPage() {
  const { items, total, clearCart } = useCart();
  const router = useRouter();
  const [step, setStep] = useState<Step>('address');
  const [address, setAddress] = useState({ name: '', zip: '', prefecture: '', city: '', line: '', phone: '' });
  const [submitting, setSubmitting] = useState(false);
  const [orderId, setOrderId] = useState('');

  if (items.length === 0 && !orderId) {
    return <div className="max-w-2xl mx-auto py-20 text-center"><p className="text-gray-500">カートは空です</p></div>;
  }

  const handleOrder = async () => {
    setSubmitting(true);
    try {
      const res = await fetch('/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ items: items.map(i => ({ productId: i.productId, quantity: i.quantity, variantId: i.variantId })), shippingAddress: address }),
      });
      if (!res.ok) throw new Error('注文に失敗');
      const data = await res.json();
      setOrderId(data.orderNumber || data.id);
      clearCart();
    } catch { alert('注文に失敗しました'); } finally { setSubmitting(false); }
  };

  if (orderId) {
    return (
      <div className="max-w-2xl mx-auto py-20 text-center">
        <CheckCircle size={64} className="mx-auto text-green-500 mb-4" />
        <h1 className="text-2xl font-bold mb-2">ご注文ありがとうございます</h1>
        <p className="text-gray-600">注文番号: {orderId}</p>
        <button onClick={() => router.push('/')} className="mt-6 bg-blue-600 text-white px-6 py-2 rounded-lg">ホームに戻る</button>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto px-4 py-12">
      <div className="flex gap-4 mb-8">
        {(['address', 'payment', 'confirm'] as Step[]).map((s, i) => (
          <div key={s} className={`flex-1 text-center py-2 text-sm rounded ${step === s ? 'bg-blue-600 text-white' : 'bg-gray-100 text-gray-500'}`}>
            {i + 1}. {s === 'address' ? '配送先' : s === 'payment' ? 'お支払い' : '確認'}
          </div>
        ))}
      </div>

      {step === 'address' && (
        <div className="bg-white rounded-lg shadow p-6 space-y-4">
          <h2 className="text-lg font-bold mb-4">配送先情報</h2>
          {[{ name: 'name', label: '氏名' }, { name: 'zip', label: '郵便番号' }, { name: 'prefecture', label: '都道府県' }, { name: 'city', label: '市区町村' }, { name: 'line', label: '番地・建物' }, { name: 'phone', label: '電話番号' }].map(f => (
            <div key={f.name}><label className="block text-sm font-medium mb-1">{f.label}</label>
              <input value={(address as any)[f.name]} onChange={e => setAddress({ ...address, [f.name]: e.target.value })} required className="w-full border rounded-lg px-3 py-2" /></div>
          ))}
          <button onClick={() => setStep('payment')} className="bg-blue-600 text-white px-6 py-2 rounded-lg">次へ</button>
        </div>
      )}

      {step === 'payment' && (
        <div className="bg-white rounded-lg shadow p-6 space-y-4">
          <h2 className="text-lg font-bold mb-4">お支払い情報</h2>
          <p className="text-gray-500 text-sm">※ 決済プロバイダー連携（Stripe等）で実装</p>
          <div className="flex gap-3">
            <button onClick={() => setStep('address')} className="px-6 py-2 border rounded-lg">戻る</button>
            <button onClick={() => setStep('confirm')} className="bg-blue-600 text-white px-6 py-2 rounded-lg">次へ</button>
          </div>
        </div>
      )}

      {step === 'confirm' && (
        <div className="bg-white rounded-lg shadow p-6 space-y-4">
          <h2 className="text-lg font-bold mb-4">注文確認</h2>
          {items.map(i => (
            <div key={i.productId} className="flex justify-between text-sm border-b py-2">
              <span>{i.name} x{i.quantity}</span><span>&yen;{(i.price * i.quantity).toLocaleString()}</span>
            </div>
          ))}
          <div className="flex justify-between font-bold text-lg pt-2"><span>合計</span><span>&yen;{total.toLocaleString()}</span></div>
          <div className="flex gap-3">
            <button onClick={() => setStep('payment')} className="px-6 py-2 border rounded-lg">戻る</button>
            <button onClick={handleOrder} disabled={submitting} className="bg-blue-600 text-white px-6 py-2 rounded-lg disabled:opacity-50">
              {submitting ? '注文中...' : '注文を確定する'}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
EOF

    EE_GENERATED_COUNT=$((EE_GENERATED_COUNT + 1))
    _ee_ok "チェックアウト生成完了"
    return 0
}

# =============================================================================
# _ee_generate_order_management() - Order management
# =============================================================================
_ee_generate_order_management() {
    local project_dir="${1:-.}"
    _ee_log "注文管理ページ生成"

    local page_dir="${project_dir}/src/app/admin/orders"
    mkdir -p "$page_dir"

    cat > "${page_dir}/page.tsx" <<'EOF'
'use client';
import useSWR from 'swr';
import { Package, Truck, CheckCircle, Clock, XCircle } from 'lucide-react';

const fetcher = (url: string) => fetch(url).then(r => r.json());
const statusMap: Record<string, { icon: React.ReactNode; color: string; label: string }> = {
  PENDING: { icon: <Clock size={14} />, color: 'yellow', label: '保留中' },
  PAID: { icon: <CheckCircle size={14} />, color: 'green', label: '支払済' },
  PROCESSING: { icon: <Package size={14} />, color: 'blue', label: '処理中' },
  SHIPPED: { icon: <Truck size={14} />, color: 'purple', label: '発送済' },
  DELIVERED: { icon: <CheckCircle size={14} />, color: 'green', label: '配達済' },
  CANCELLED: { icon: <XCircle size={14} />, color: 'red', label: 'キャンセル' },
};

export default function OrderManagementPage() {
  const { data, isLoading, error, mutate } = useSWR('/api/admin/orders', fetcher);

  const updateStatus = async (orderId: string, status: string) => {
    try {
      await fetch(`/api/admin/orders/${orderId}`, { method: 'PATCH', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ status }) });
      mutate();
    } catch { alert('更新に失敗'); }
  };

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">注文管理</h1>
      {isLoading && <div className="space-y-3">{[1,2,3].map(i => <div key={i} className="h-16 bg-gray-200 rounded animate-pulse" />)}</div>}
      {error && <p className="text-red-600">読み込みエラー</p>}
      {data?.data && (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b"><tr>
              <th className="text-left px-4 py-3">注文番号</th><th className="text-left px-4 py-3">日時</th>
              <th className="text-left px-4 py-3">ステータス</th><th className="text-right px-4 py-3">金額</th>
              <th className="text-right px-4 py-3">操作</th>
            </tr></thead>
            <tbody>{data.data.map((order: any) => {
              const st = statusMap[order.status] || statusMap.PENDING;
              return (
                <tr key={order.id} className="border-b hover:bg-gray-50">
                  <td className="px-4 py-3 font-mono text-xs">{order.orderNumber}</td>
                  <td className="px-4 py-3 text-gray-500">{new Date(order.createdAt).toLocaleString('ja-JP')}</td>
                  <td className="px-4 py-3"><span className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full bg-${st.color}-100 text-${st.color}-700`}>{st.icon} {st.label}</span></td>
                  <td className="px-4 py-3 text-right font-medium">&yen;{order.total?.toLocaleString()}</td>
                  <td className="px-4 py-3 text-right">
                    <select value={order.status} onChange={e => updateStatus(order.id, e.target.value)} className="text-xs border rounded px-2 py-1">
                      {Object.entries(statusMap).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
                    </select>
                  </td>
                </tr>
              );
            })}</tbody>
          </table>
        </div>
      )}
    </div>
  );
}
EOF

    EE_GENERATED_COUNT=$((EE_GENERATED_COUNT + 1))
    _ee_ok "注文管理ページ生成完了"
    return 0
}

# =============================================================================
# _ee_generate_inventory() - Inventory tracking
# =============================================================================
_ee_generate_inventory() {
    local project_dir="${1:-.}"
    _ee_log "在庫管理API生成"

    local api_dir="${project_dir}/src/app/api/admin/inventory"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const inventory = await prisma.inventory.findMany({
      include: { product: { select: { id: true, name: true, sku: true, status: true } } },
      orderBy: { stock: 'asc' },
    });
    const lowStock = inventory.filter(i => i.stock <= i.lowStockThreshold);
    return NextResponse.json({ data: inventory, lowStockCount: lowStock.length, totalProducts: inventory.length });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch inventory' }, { status: 500 });
  }
}

export async function PATCH(req: NextRequest) {
  try {
    const { productId, adjustment, reason } = await req.json();
    if (!productId || adjustment === undefined) return NextResponse.json({ error: 'productId and adjustment required' }, { status: 400 });
    const updated = await prisma.inventory.update({
      where: { productId },
      data: { stock: { increment: adjustment } },
    });
    return NextResponse.json(updated);
  } catch (error) {
    return NextResponse.json({ error: 'Failed to update inventory' }, { status: 500 });
  }
}
EOF

    EE_GENERATED_COUNT=$((EE_GENERATED_COUNT + 1))
    _ee_ok "在庫管理API生成完了"
    return 0
}

# =============================================================================
# Module Registration
# =============================================================================
_mr_register \
    --name "ecommerce-engine" \
    --version "305.0" \
    --description "EC自動生成エンジン（商品/カート/チェックアウト/注文/在庫）" \
    --init "ee_init" \
    --report "ee_report" \
    --score "ee_score" \
    --enable-var "ENABLE_ECOMMERCE_ENGINE" \
    --cli-flags "--ecommerce:--no-ecommerce" \
    --init-msg "ee_init_message"
