#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2018.0 - UEL Bridge (chain.sh ↔ Universal Excellence Layer)
# =============================================================================
# 顧客プロジェクト生成完了時に Premium Starter を scaffold + 採点 する中継。
#
# 公開関数:
#   uel_install_to_project   生成プロジェクトに Premium Starter 一式をマージ
#   uel_score_project        Pentafortress 採点 (5×170=850)
#   uel_finalize_project     install + score + 認定/未完成宣言
#   uel_banner               起動メッセージ
# =============================================================================

[[ -n "${_UEL_BRIDGE_LOADED:-}" ]] && return 0
_UEL_BRIDGE_LOADED=1

UEL_BRIDGE_VERSION="v2018.0"
UEL_LIB_DIR="${HOME}/.soloptilink/lib/quality-fortresses"
UEL_TEMPLATE_DIR="${HOME}/.soloptilink/templates/premium-nextjs"
UEL_LOG="${HOME}/.soloptilink/.uel/logs/bridge-$(date '+%Y%m').jsonl"
ENABLE_UEL="${ENABLE_UEL:-true}"
UEL_FORTRESS_THRESHOLD="${UEL_FORTRESS_THRESHOLD:-720}"   # Premium Platinum 以上で合格

UEL_BR_RED='\033[0;31m'; UEL_BR_YEL='\033[0;33m'; UEL_BR_GRN='\033[0;32m'
UEL_BR_CYAN='\033[0;36m'; UEL_BR_BOLD='\033[1m'; UEL_BR_NC='\033[0m'

mkdir -p "$(dirname "$UEL_LOG")" 2>/dev/null

uel_log() {
    local action="$1" verdict="$2" detail="$3"
    printf '{"ts":"%s","module":"uel-bridge","action":"%s","verdict":"%s","detail":"%s"}\n' \
        "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" "$action" "$verdict" "${detail//\"/\\\"}" \
        >> "$UEL_LOG" 2>/dev/null
}

uel_banner() {
    [[ "$ENABLE_UEL" != "true" ]] && return 0
    echo -e "${UEL_BR_CYAN}[UEL ${UEL_BRIDGE_VERSION}]${UEL_BR_NC} Universal Excellence Layer enabled (Pentafortress 850点・閾値 ${UEL_FORTRESS_THRESHOLD})"
}

# プロジェクトに Premium Starter のセキュリティ + UX 部分を非破壊マージ
uel_install_to_project() {
    [[ "$ENABLE_UEL" != "true" ]] && return 0
    local target="$1"
    [[ -z "$target" || ! -d "$target" ]] && return 0
    [[ ! -d "$UEL_TEMPLATE_DIR" ]] && {
        echo -e "${UEL_BR_YEL}[UEL]${UEL_BR_NC} template missing: $UEL_TEMPLATE_DIR" >&2
        return 0
    }

    local installed=0

    # 1. ARSL TS 配線 (defense-in-depth と被るが、こちらは Tailwind v4 / shadcn 前提の最新版)
    mkdir -p "${target}/src/lib/arsl"
    for f in input-firewall.ts output-verifier.ts audit-logger.ts; do
        if [[ -f "${UEL_TEMPLATE_DIR}/src/lib/arsl/$f" ]] && [[ ! -f "${target}/src/lib/arsl/$f" ]]; then
            cp "${UEL_TEMPLATE_DIR}/src/lib/arsl/$f" "${target}/src/lib/arsl/$f"
            installed=$((installed+1))
        fi
    done

    # 2. middleware (CSP) - 既存があれば触らない
    if [[ ! -f "${target}/src/middleware.ts" && ! -f "${target}/middleware.ts" ]]; then
        if [[ -d "${target}/src" ]]; then
            cp "${UEL_TEMPLATE_DIR}/src/middleware.ts" "${target}/src/middleware.ts" && installed=$((installed+1))
        fi
    fi

    # 3. healthcheck routes
    mkdir -p "${target}/src/app/api/livez" "${target}/src/app/api/readyz" 2>/dev/null
    if [[ -d "${target}/src/app" ]]; then
        for ep in livez readyz; do
            if [[ ! -f "${target}/src/app/api/${ep}/route.ts" ]]; then
                cp "${UEL_TEMPLATE_DIR}/src/app/api/${ep}/route.ts" "${target}/src/app/api/${ep}/route.ts" \
                    && installed=$((installed+1))
            fi
        done
    fi

    # 4. ui状態 (loading/error/not-found/empty-state) - 既存があれば触らない
    if [[ -d "${target}/src/app" ]]; then
        for f in error.tsx loading.tsx not-found.tsx; do
            if [[ ! -f "${target}/src/app/$f" ]]; then
                cp "${UEL_TEMPLATE_DIR}/src/app/$f" "${target}/src/app/$f" 2>/dev/null && installed=$((installed+1))
            fi
        done
    fi

    # 5. utils + web-vitals
    if [[ -d "${target}/src/lib" && ! -f "${target}/src/lib/web-vitals.ts" ]]; then
        cp "${UEL_TEMPLATE_DIR}/src/lib/web-vitals.ts" "${target}/src/lib/web-vitals.ts" 2>/dev/null
        installed=$((installed+1))
    fi

    # 6. lighthouserc / playwright (CI ゲート)
    [[ ! -f "${target}/.lighthouserc.json" ]] && cp "${UEL_TEMPLATE_DIR}/.lighthouserc.json" "${target}/" 2>/dev/null && installed=$((installed+1))
    [[ ! -f "${target}/playwright.config.ts" ]] && cp "${UEL_TEMPLATE_DIR}/playwright.config.ts" "${target}/" 2>/dev/null && installed=$((installed+1))

    # 7. package.json に uel:fortress 等 scripts 追記 (jq があれば)
    local pkg="${target}/package.json"
    if [[ -f "$pkg" ]] && command -v jq &>/dev/null; then
        if ! grep -q '"uel:fortress"' "$pkg"; then
            local tmp; tmp=$(mktemp)
            jq '.scripts["uel:fortress"]   = "bash ~/.soloptilink/lib/quality-fortresses/pentafortress.sh run ."
                | .scripts["uel:reliability"] = "bash ~/.soloptilink/lib/quality-fortresses/reliability-fortress.sh run ."
                | .scripts["uel:performance"] = "bash ~/.soloptilink/lib/quality-fortresses/performance-fortress.sh run ."
                | .scripts["uel:ux"] = "bash ~/.soloptilink/lib/quality-fortresses/ux-fortress.sh run ."
                | .scripts["uel:design"] = "bash ~/.soloptilink/lib/quality-fortresses/design-fortress.sh run ."' \
                "$pkg" > "$tmp" && mv "$tmp" "$pkg"
            installed=$((installed+1))
        fi
    fi

    echo -e "${UEL_BR_GRN}[UEL]${UEL_BR_NC} ${installed} files/scripts wired into ${target}"
    uel_log "install" "DONE" "$target ($installed items)"
    return 0
}

# Pentafortress 採点 (rcに認定レベル反映)
uel_score_project() {
    [[ "$ENABLE_UEL" != "true" ]] && return 0
    local target="$1"
    [[ -z "$target" || ! -d "$target" ]] && return 0

    if [[ ! -f "${UEL_LIB_DIR}/pentafortress.sh" ]]; then
        echo -e "${UEL_BR_YEL}[UEL]${UEL_BR_NC} pentafortress.sh missing" >&2
        return 1
    fi
    bash "${UEL_LIB_DIR}/pentafortress.sh" run "$target"
    return $?
}

# 学習データへの Pentafortress 結果記録 (横断学習に蓄積)
uel_record_to_learning() {
    local target="$1" total="$2" cert="$3"
    local learning_dir="${HOME}/.soloptilink/learning"
    mkdir -p "${learning_dir}/quality" "${learning_dir}/sessions" 2>/dev/null

    # 1. quality/scores.jsonl に Pentafortress スコア追記
    printf '{"ts":"%s","type":"pentafortress","target":"%s","grand_total":%d,"max":850,"certification":"%s","fortresses":{"security":%d,"reliability":%d,"performance":%d,"ux":%d,"design":%d}}\n' \
        "$(date -u '+%Y-%m-%dT%H:%M:%SZ')" \
        "${target//\"/\\\"}" \
        "$total" \
        "${cert//\"/\\\"}" \
        "${PENTA_SECURITY:-0}" "${PENTA_RELIABILITY:-0}" "${PENTA_PERFORMANCE:-0}" "${PENTA_UX:-0}" "${PENTA_DESIGN:-0}" \
        >> "${learning_dir}/quality/scores.jsonl" 2>/dev/null

    # 2. session-learner.sh が利用可能なら蒸留呼び出し
    if [[ -f "${HOME}/.soloptilink/lib/session-learner.sh" ]]; then
        ( source "${HOME}/.soloptilink/lib/session-learner.sh" 2>/dev/null
          declare -f sl_record_session_outcome &>/dev/null && \
          sl_record_session_outcome "uel_finalize" "$total" "premium=$cert" 2>/dev/null ) || true
    fi

    # 3. learning-hub.sh が利用可能なら session_summary 記録
    if [[ -f "${HOME}/.soloptilink/lib/learning-hub.sh" ]]; then
        ( source "${HOME}/.soloptilink/lib/learning-hub.sh" 2>/dev/null
          declare -f lh_record_session_summary &>/dev/null && \
          lh_record_session_summary "$target" "uel_pentafortress=$total/850" 2>/dev/null ) || true
    fi
}

# install + score を一括実行 (chain.sh の finalize で呼ぶ)
uel_finalize_project() {
    [[ "$ENABLE_UEL" != "true" ]] && return 0
    local target="$1"
    [[ -z "$target" || ! -d "$target" ]] && {
        echo -e "${UEL_BR_YEL}[UEL]${UEL_BR_NC} skip finalize: invalid target=$target"
        return 0
    }

    echo -e "\n${UEL_BR_CYAN}${UEL_BR_BOLD}━━ UEL Final Gate ${UEL_BRIDGE_VERSION} ━━${UEL_BR_NC}"

    # Phase A: install
    uel_install_to_project "$target"

    # Phase B: score (pentafortress.sh は PENTA_* グローバル変数を更新する)
    # NOTE: pipe (penta_run | tail) は subshell を作って GRAND_TOTAL が親に反映されないため、
    # 一時ファイル経由で実行 → 親シェルの PENTA_* を保持
    local total="0" cert="Unrated"
    if [[ -f "${UEL_LIB_DIR}/pentafortress.sh" ]]; then
        # shellcheck disable=SC1090
        source "${UEL_LIB_DIR}/pentafortress.sh"
        local _tmp_out; _tmp_out=$(mktemp)
        penta_run "$target" > "$_tmp_out" 2>&1
        tail -22 "$_tmp_out"
        rm -f "$_tmp_out"
        total="${PENTA_GRAND_TOTAL:-0}"
        cert=$(penta_certification "$total")
    fi

    # Phase C: 学習データ記録 (横断学習に蓄積)
    uel_record_to_learning "$target" "$total" "$cert"

    # Phase D: 判定
    if [[ $total -lt $UEL_FORTRESS_THRESHOLD ]]; then
        echo -e "${UEL_BR_YEL}[UEL]${UEL_BR_NC} Pentafortress ${total}/850 < ${UEL_FORTRESS_THRESHOLD} (Platinum) — 改善推奨"
        uel_log "finalize" "BELOW_THRESHOLD" "score=$total"
        return 3
    fi
    echo -e "${UEL_BR_GRN}[UEL]${UEL_BR_NC} Pentafortress ${total}/850 ${cert} (learning に記録済)"
    uel_log "finalize" "PASS" "score=$total"
    return 0
}

# CLI
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-help}" in
        install)   uel_install_to_project "$2" ;;
        score)     uel_score_project "$2" ;;
        finalize)  uel_finalize_project "$2" ;;
        banner)    uel_banner ;;
        *) cat <<U
SoloptiLinkAI UEL Bridge ${UEL_BRIDGE_VERSION}
Usage:
  $(basename "$0") install <project_dir>     # Premium Starter 配線
  $(basename "$0") score   <project_dir>     # Pentafortress 850点採点
  $(basename "$0") finalize <project_dir>    # install + score + 認定
  $(basename "$0") banner                    # 起動メッセージ
U
            ;;
    esac
fi
