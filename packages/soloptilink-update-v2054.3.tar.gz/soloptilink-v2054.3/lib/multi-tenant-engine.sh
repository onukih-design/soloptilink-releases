#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - Multi-Tenant Engine
# =============================================================================
# マルチテナンシー自動構築エンジン。
# テナント分離戦略（行レベル/スキーマレベル/DB分離）、テナント検出ミドルウェア、
# AsyncLocalStorageコンテキスト、Prismaミドルウェア、管理API、課金フックを生成。
#
# 機能一覧:
#   mt_generate_tenant_model      - テナントモデル+分離戦略
#   mt_generate_tenant_middleware  - テナント検出（subdomain/header/JWT）
#   mt_generate_tenant_context     - AsyncLocalStorageベースのコンテキスト
#   mt_generate_data_isolation     - Prismaミドルウェア自動フィルタリング
#   mt_generate_tenant_admin       - テナント管理API
#   mt_generate_tenant_billing     - テナント別利用量+課金フック
#   mt_inject_tenant_patterns      - Claudeプロンプトへのパターン注入
#
# 全globals: MTE_ prefix
# =============================================================================

[[ -n "${_MTE_LOADED:-}" ]] && return 0; _MTE_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g MTE_VERSION="140.0"
declare -g MTE_GENERATED=0
declare -g MTE_ERRORS=0
declare -g MTE_PHASE="multi_tenant"
declare -g MTE_FILES_WRITTEN=0

# =============================================================================
# 初期化
# =============================================================================
mt_init() {
    MTE_GENERATED=0
    MTE_ERRORS=0
    MTE_FILES_WRITTEN=0
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} multi-tenant-engine v${MTE_VERSION}"
    return 0
}

# =============================================================================
# ユーティリティ
# =============================================================================
_mte_write_file() {
    local filepath="$1"
    local content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then
        MTE_FILES_WRITTEN=$((MTE_FILES_WRITTEN + 1))
        echo "  [multi-tenant] wrote: $filepath" >&2
    else
        MTE_ERRORS=$((MTE_ERRORS + 1))
    fi
}

# =============================================================================
# mt_generate_tenant_model - テナントモデル+Prismaスキーマ
# =============================================================================
mt_generate_tenant_model() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local strategy="${2:-row-level}"

    local tenant_schema
    tenant_schema=$(cat <<'TSEOF'
// === Prisma schema additions for multi-tenancy ===
// Add to your prisma/schema.prisma

// model Tenant {
//   id          String   @id @default(cuid())
//   name        String
//   slug        String   @unique
//   domain      String?  @unique
//   plan        String   @default("free") // free, starter, pro, enterprise
//   status      String   @default("active") // active, suspended, deleted
//   settings    Json     @default("{}")
//   features    Json     @default("{}") // feature flags per tenant
//   maxUsers    Int      @default(5)
//   maxStorage  BigInt   @default(1073741824) // 1GB
//   createdAt   DateTime @default(now())
//   updatedAt   DateTime @updatedAt
//
//   users       User[]
//   @@index([slug])
//   @@index([domain])
//   @@index([status])
// }
//
// model User {
//   id        String  @id @default(cuid())
//   tenantId  String
//   tenant    Tenant  @relation(fields: [tenantId], references: [id])
//   email     String
//   // ... other fields
//   @@unique([tenantId, email])
//   @@index([tenantId])
// }

export interface TenantConfig {
  id: string;
  name: string;
  slug: string;
  domain?: string;
  plan: 'free' | 'starter' | 'pro' | 'enterprise';
  status: 'active' | 'suspended' | 'deleted';
  settings: TenantSettings;
  features: TenantFeatures;
  maxUsers: number;
  maxStorage: number;
}

export interface TenantSettings {
  branding?: {
    primaryColor?: string;
    logo?: string;
    favicon?: string;
  };
  locale?: string;
  timezone?: string;
  emailFrom?: string;
}

export interface TenantFeatures {
  apiAccess?: boolean;
  customDomain?: boolean;
  sso?: boolean;
  auditLog?: boolean;
  advancedReporting?: boolean;
  webhooks?: boolean;
}

export const PLAN_LIMITS: Record<string, { maxUsers: number; maxStorage: number; features: TenantFeatures }> = {
  free: {
    maxUsers: 5,
    maxStorage: 1 * 1024 * 1024 * 1024, // 1GB
    features: { apiAccess: false, customDomain: false, sso: false, auditLog: false },
  },
  starter: {
    maxUsers: 25,
    maxStorage: 10 * 1024 * 1024 * 1024,
    features: { apiAccess: true, customDomain: false, sso: false, auditLog: true },
  },
  pro: {
    maxUsers: 100,
    maxStorage: 100 * 1024 * 1024 * 1024,
    features: { apiAccess: true, customDomain: true, sso: false, auditLog: true, advancedReporting: true },
  },
  enterprise: {
    maxUsers: -1, // unlimited
    maxStorage: -1,
    features: { apiAccess: true, customDomain: true, sso: true, auditLog: true, advancedReporting: true, webhooks: true },
  },
};
TSEOF
)
    _mte_write_file "${project_dir}/src/lib/tenant-model.ts" "$tenant_schema"
    MTE_GENERATED=$((MTE_GENERATED + 1))
    return 0
}

# =============================================================================
# mt_generate_tenant_middleware - テナント検出ミドルウェア
# =============================================================================
mt_generate_tenant_middleware() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local middleware_ts
    middleware_ts=$(cat <<'TMEOF'
import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { verify } from 'jsonwebtoken';

const prisma = new PrismaClient();

interface TenantDetectionResult {
  tenantId: string;
  slug: string;
  source: 'subdomain' | 'header' | 'jwt' | 'path';
}

/**
 * Detect tenant from multiple sources in priority order:
 * 1. X-Tenant-ID header (API clients)
 * 2. JWT claim (authenticated requests)
 * 3. Subdomain (web clients: acme.app.com)
 * 4. Path prefix (fallback: /t/acme/...)
 */
export async function detectTenant(request: NextRequest): Promise<TenantDetectionResult | null> {
  // 1. Header
  const headerTenantId = request.headers.get('X-Tenant-ID');
  if (headerTenantId) {
    const tenant = await prisma.tenant.findUnique({
      where: { id: headerTenantId, status: 'active' },
      select: { id: true, slug: true },
    });
    if (tenant) return { tenantId: tenant.id, slug: tenant.slug, source: 'header' };
  }

  // 2. JWT
  const authHeader = request.headers.get('authorization');
  if (authHeader?.startsWith('Bearer ')) {
    try {
      const token = authHeader.slice(7);
      const secret = process.env.JWT_SECRET || process.env.NEXTAUTH_SECRET || '';
      const payload = verify(token, secret) as { tenantId?: string; tenantSlug?: string };
      if (payload.tenantId) {
        return {
          tenantId: payload.tenantId,
          slug: payload.tenantSlug || payload.tenantId,
          source: 'jwt',
        };
      }
    } catch { /* token invalid, try other methods */ }
  }

  // 3. Subdomain
  const host = request.headers.get('host') || '';
  const baseDomain = process.env.BASE_DOMAIN || 'localhost:3000';
  if (host !== baseDomain && host.endsWith(baseDomain)) {
    const subdomain = host.replace(`.${baseDomain}`, '').split('.')[0];
    if (subdomain && subdomain !== 'www' && subdomain !== 'api') {
      const tenant = await prisma.tenant.findUnique({
        where: { slug: subdomain, status: 'active' },
        select: { id: true, slug: true },
      });
      if (tenant) return { tenantId: tenant.id, slug: tenant.slug, source: 'subdomain' };
    }
  }

  // 4. Custom domain
  const customTenant = await prisma.tenant.findFirst({
    where: { domain: host, status: 'active' },
    select: { id: true, slug: true },
  });
  if (customTenant) {
    return { tenantId: customTenant.id, slug: customTenant.slug, source: 'subdomain' };
  }

  // 5. Path prefix: /t/:slug/...
  const pathname = request.nextUrl.pathname;
  const pathMatch = pathname.match(/^\/t\/([a-z0-9-]+)/);
  if (pathMatch) {
    const slug = pathMatch[1];
    const tenant = await prisma.tenant.findUnique({
      where: { slug, status: 'active' },
      select: { id: true, slug: true },
    });
    if (tenant) return { tenantId: tenant.id, slug: tenant.slug, source: 'path' };
  }

  return null;
}

/**
 * Next.js Middleware for tenant injection
 */
export async function tenantMiddleware(request: NextRequest): Promise<NextResponse> {
  // Skip public routes
  const publicPaths = ['/login', '/register', '/api/auth', '/_next', '/favicon.ico'];
  if (publicPaths.some((p) => request.nextUrl.pathname.startsWith(p))) {
    return NextResponse.next();
  }

  const tenant = await detectTenant(request);

  if (!tenant) {
    // No tenant found - redirect to login or return 404
    if (request.nextUrl.pathname.startsWith('/api/')) {
      return NextResponse.json({ error: 'Tenant not found' }, { status: 404 });
    }
    return NextResponse.redirect(new URL('/login', request.url));
  }

  // Inject tenant info into headers for downstream use
  const response = NextResponse.next();
  response.headers.set('X-Tenant-ID', tenant.tenantId);
  response.headers.set('X-Tenant-Slug', tenant.slug);
  response.headers.set('X-Tenant-Source', tenant.source);

  return response;
}
TMEOF
)
    _mte_write_file "${project_dir}/src/middleware/tenant-middleware.ts" "$middleware_ts"
    MTE_GENERATED=$((MTE_GENERATED + 1))
    return 0
}

# =============================================================================
# mt_generate_tenant_context - AsyncLocalStorageコンテキスト
# =============================================================================
mt_generate_tenant_context() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local context_ts
    context_ts=$(cat <<'TCEOF'
import { AsyncLocalStorage } from 'async_hooks';
import type { TenantConfig } from './tenant-model';

interface TenantContext {
  tenantId: string;
  slug: string;
  plan: string;
  features: Record<string, boolean>;
}

const tenantStorage = new AsyncLocalStorage<TenantContext>();

/**
 * Run a function within a tenant context.
 * All Prisma queries within this scope will be automatically filtered.
 */
export function withTenantContext<T>(context: TenantContext, fn: () => T): T {
  return tenantStorage.run(context, fn);
}

/**
 * Get current tenant context. Throws if not within a tenant scope.
 */
export function getTenantContext(): TenantContext {
  const ctx = tenantStorage.getStore();
  if (!ctx) {
    throw new Error('No tenant context available. Ensure the request is within withTenantContext().');
  }
  return ctx;
}

/**
 * Get current tenant context or null (for optional tenant routes).
 */
export function getTenantContextOrNull(): TenantContext | null {
  return tenantStorage.getStore() || null;
}

/**
 * Get current tenant ID. Throws if not in tenant scope.
 */
export function getCurrentTenantId(): string {
  return getTenantContext().tenantId;
}

/**
 * Check if a feature is enabled for the current tenant.
 */
export function isTenantFeatureEnabled(feature: string): boolean {
  const ctx = getTenantContextOrNull();
  if (!ctx) return false;
  return ctx.features[feature] === true;
}

/**
 * Express/Next.js middleware helper to establish tenant context for request handlers.
 */
export function createTenantScope(tenantId: string, slug: string, plan: string, features: Record<string, boolean>) {
  return <T>(fn: () => T): T => {
    return withTenantContext({ tenantId, slug, plan, features }, fn);
  };
}

/**
 * Decorator-style wrapper for API route handlers.
 */
export function withTenant<Args extends any[], R>(
  handler: (...args: Args) => Promise<R>
): (...args: Args) => Promise<R> {
  return async (...args: Args) => {
    // Extract tenant from request headers (set by middleware)
    const request = args[0] as any;
    const tenantId = request?.headers?.get?.('X-Tenant-ID') || request?.headers?.['x-tenant-id'];
    const slug = request?.headers?.get?.('X-Tenant-Slug') || request?.headers?.['x-tenant-slug'];

    if (!tenantId) {
      throw new Error('Tenant context required but not found in request headers');
    }

    return withTenantContext(
      { tenantId, slug: slug || tenantId, plan: 'unknown', features: {} },
      () => handler(...args)
    );
  };
}
TCEOF
)
    _mte_write_file "${project_dir}/src/lib/tenant-context.ts" "$context_ts"
    MTE_GENERATED=$((MTE_GENERATED + 1))
    return 0
}

# =============================================================================
# mt_generate_data_isolation - Prismaミドルウェア
# =============================================================================
mt_generate_data_isolation() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local isolation_ts
    isolation_ts=$(cat <<'DIEOF'
import { PrismaClient, Prisma } from '@prisma/client';
import { getCurrentTenantId, getTenantContextOrNull } from './tenant-context';

// Models that require tenant filtering
const TENANT_MODELS = new Set([
  'User', 'Project', 'Task', 'Document', 'Invoice',
  'Contact', 'Note', 'Activity', 'Setting',
]);

// Models exempt from tenant filtering (global/system tables)
const GLOBAL_MODELS = new Set([
  'Tenant', 'Migration', 'SystemConfig',
]);

/**
 * Create a tenant-aware Prisma client with automatic row-level filtering.
 */
export function createTenantPrisma(): PrismaClient {
  const prisma = new PrismaClient();

  // Middleware: Inject tenantId filter on reads
  prisma.$use(async (params: Prisma.MiddlewareParams, next) => {
    const ctx = getTenantContextOrNull();
    if (!ctx || !params.model || !TENANT_MODELS.has(params.model)) {
      return next(params);
    }

    const tenantId = ctx.tenantId;

    // Read operations: inject where clause
    if (['findUnique', 'findFirst', 'findMany', 'count', 'aggregate', 'groupBy'].includes(params.action)) {
      if (params.args) {
        params.args.where = {
          ...params.args.where,
          tenantId,
        };
      }
    }

    // Create operations: inject tenantId
    if (params.action === 'create') {
      if (params.args?.data) {
        params.args.data.tenantId = tenantId;
      }
    }

    // CreateMany
    if (params.action === 'createMany') {
      if (Array.isArray(params.args?.data)) {
        params.args.data = params.args.data.map((item: any) => ({
          ...item,
          tenantId,
        }));
      }
    }

    // Update operations: scope to tenant
    if (['update', 'updateMany', 'delete', 'deleteMany'].includes(params.action)) {
      if (params.args?.where) {
        params.args.where = {
          ...params.args.where,
          tenantId,
        };
      }
    }

    // Upsert: scope both where and create
    if (params.action === 'upsert') {
      if (params.args?.where) {
        params.args.where = { ...params.args.where, tenantId };
      }
      if (params.args?.create) {
        params.args.create = { ...params.args.create, tenantId };
      }
    }

    return next(params);
  });

  // Middleware: Prevent cross-tenant data access on results
  prisma.$use(async (params, next) => {
    const result = await next(params);
    const ctx = getTenantContextOrNull();

    if (!ctx || !params.model || !TENANT_MODELS.has(params.model)) {
      return result;
    }

    // Verify returned data belongs to current tenant
    if (result && typeof result === 'object' && 'tenantId' in result) {
      if (result.tenantId !== ctx.tenantId) {
        throw new Error(`Cross-tenant data access violation: expected ${ctx.tenantId}, got ${result.tenantId}`);
      }
    }

    return result;
  });

  return prisma;
}

// Singleton tenant-aware prisma
let tenantPrisma: PrismaClient | null = null;

export function getTenantPrisma(): PrismaClient {
  if (!tenantPrisma) {
    tenantPrisma = createTenantPrisma();
  }
  return tenantPrisma;
}
DIEOF
)
    _mte_write_file "${project_dir}/src/lib/tenant-prisma.ts" "$isolation_ts"
    MTE_GENERATED=$((MTE_GENERATED + 1))
    return 0
}

# =============================================================================
# mt_generate_tenant_admin - テナント管理API
# =============================================================================
mt_generate_tenant_admin() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local admin_ts
    admin_ts=$(cat <<'TAEOF'
import { NextRequest, NextResponse } from 'next/server';
import { PrismaClient } from '@prisma/client';
import { z } from 'zod';
import { PLAN_LIMITS } from '@/lib/tenant-model';

const prisma = new PrismaClient();

// --- Schemas ---
const CreateTenantSchema = z.object({
  name: z.string().min(2).max(100),
  slug: z.string().min(2).max(50).regex(/^[a-z0-9-]+$/, 'Slug must be lowercase alphanumeric with hyphens'),
  plan: z.enum(['free', 'starter', 'pro', 'enterprise']).default('free'),
  domain: z.string().optional(),
  settings: z.record(z.unknown()).optional(),
});

const UpdateTenantSchema = z.object({
  name: z.string().min(2).max(100).optional(),
  plan: z.enum(['free', 'starter', 'pro', 'enterprise']).optional(),
  status: z.enum(['active', 'suspended']).optional(),
  domain: z.string().nullable().optional(),
  settings: z.record(z.unknown()).optional(),
});

// --- GET /api/admin/tenants ---
export async function GET(request: NextRequest) {
  try {
    const url = request.nextUrl;
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = Math.min(parseInt(url.searchParams.get('limit') || '20'), 100);
    const status = url.searchParams.get('status') || undefined;
    const search = url.searchParams.get('search') || undefined;

    const where: any = {};
    if (status) where.status = status;
    if (search) {
      where.OR = [
        { name: { contains: search, mode: 'insensitive' } },
        { slug: { contains: search, mode: 'insensitive' } },
      ];
    }

    const [tenants, total] = await Promise.all([
      prisma.tenant.findMany({
        where,
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { createdAt: 'desc' },
        include: { _count: { select: { users: true } } },
      }),
      prisma.tenant.count({ where }),
    ]);

    return NextResponse.json({
      data: tenants,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// --- POST /api/admin/tenants ---
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const parsed = CreateTenantSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: 'Validation failed', details: parsed.error.flatten() }, { status: 400 });
    }

    const { name, slug, plan, domain, settings } = parsed.data;
    const limits = PLAN_LIMITS[plan];

    // Check slug uniqueness
    const existing = await prisma.tenant.findUnique({ where: { slug } });
    if (existing) {
      return NextResponse.json({ error: 'Slug already taken' }, { status: 409 });
    }

    const tenant = await prisma.tenant.create({
      data: {
        name,
        slug,
        plan,
        domain: domain || null,
        status: 'active',
        settings: settings || {},
        features: limits.features,
        maxUsers: limits.maxUsers,
        maxStorage: limits.maxStorage,
      },
    });

    return NextResponse.json({ data: tenant }, { status: 201 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// --- PATCH /api/admin/tenants/[id] ---
export async function patchTenant(tenantId: string, request: NextRequest) {
  try {
    const body = await request.json();
    const parsed = UpdateTenantSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: 'Validation failed', details: parsed.error.flatten() }, { status: 400 });
    }

    const updateData: any = { ...parsed.data };

    // If plan changed, update limits
    if (parsed.data.plan) {
      const limits = PLAN_LIMITS[parsed.data.plan];
      updateData.features = limits.features;
      updateData.maxUsers = limits.maxUsers;
      updateData.maxStorage = limits.maxStorage;
    }

    const tenant = await prisma.tenant.update({
      where: { id: tenantId },
      data: updateData,
    });

    return NextResponse.json({ data: tenant });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// --- DELETE /api/admin/tenants/[id] (soft delete) ---
export async function deleteTenant(tenantId: string) {
  try {
    const tenant = await prisma.tenant.update({
      where: { id: tenantId },
      data: { status: 'deleted' },
    });
    return NextResponse.json({ data: tenant, message: 'Tenant soft-deleted' });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
TAEOF
)
    _mte_write_file "${project_dir}/src/app/api/admin/tenants/route.ts" "$admin_ts"
    MTE_GENERATED=$((MTE_GENERATED + 1))
    return 0
}

# =============================================================================
# mt_generate_tenant_billing - テナント別課金
# =============================================================================
mt_generate_tenant_billing() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local billing_ts
    billing_ts=$(cat <<'TBEOF'
import { PrismaClient } from '@prisma/client';
import { getCurrentTenantId } from './tenant-context';
import { PLAN_LIMITS } from './tenant-model';

const prisma = new PrismaClient();

interface UsageMetrics {
  tenantId: string;
  period: string; // YYYY-MM
  activeUsers: number;
  storageUsedBytes: number;
  apiCalls: number;
  records: number;
}

interface BillingEvent {
  type: 'usage' | 'overage' | 'upgrade' | 'downgrade';
  tenantId: string;
  detail: string;
  amount?: number;
  timestamp: Date;
}

/**
 * Track API call for current tenant.
 */
export async function trackApiCall(endpoint: string) {
  const tenantId = getCurrentTenantId();
  const period = new Date().toISOString().slice(0, 7); // YYYY-MM

  try {
    await prisma.$executeRaw`
      INSERT INTO "TenantUsage" ("tenantId", "period", "apiCalls", "lastApiCall")
      VALUES (${tenantId}, ${period}, 1, NOW())
      ON CONFLICT ("tenantId", "period")
      DO UPDATE SET
        "apiCalls" = "TenantUsage"."apiCalls" + 1,
        "lastApiCall" = NOW()
    `;
  } catch {
    // Non-critical: don't fail request on usage tracking error
  }
}

/**
 * Get usage metrics for a tenant.
 */
export async function getUsageMetrics(tenantId: string, period?: string): Promise<UsageMetrics> {
  const targetPeriod = period || new Date().toISOString().slice(0, 7);

  const [users, usage] = await Promise.all([
    prisma.user.count({ where: { tenantId } }),
    prisma.$queryRaw<any[]>`
      SELECT "apiCalls", "storageUsedBytes", "records"
      FROM "TenantUsage"
      WHERE "tenantId" = ${tenantId} AND "period" = ${targetPeriod}
      LIMIT 1
    `,
  ]);

  return {
    tenantId,
    period: targetPeriod,
    activeUsers: users,
    storageUsedBytes: usage[0]?.storageUsedBytes ?? 0,
    apiCalls: usage[0]?.apiCalls ?? 0,
    records: usage[0]?.records ?? 0,
  };
}

/**
 * Check if tenant has exceeded plan limits.
 */
export async function checkPlanLimits(tenantId: string): Promise<{
  withinLimits: boolean;
  violations: string[];
}> {
  const tenant = await prisma.tenant.findUnique({
    where: { id: tenantId },
    select: { plan: true, maxUsers: true, maxStorage: true },
  });

  if (!tenant) return { withinLimits: false, violations: ['Tenant not found'] };

  const metrics = await getUsageMetrics(tenantId);
  const violations: string[] = [];

  if (tenant.maxUsers > 0 && metrics.activeUsers > tenant.maxUsers) {
    violations.push(`User limit exceeded: ${metrics.activeUsers}/${tenant.maxUsers}`);
  }

  if (tenant.maxStorage > 0 && metrics.storageUsedBytes > Number(tenant.maxStorage)) {
    violations.push(`Storage limit exceeded: ${metrics.storageUsedBytes}/${tenant.maxStorage} bytes`);
  }

  return { withinLimits: violations.length === 0, violations };
}

/**
 * Emit a billing event (for external billing system integration).
 */
export async function emitBillingEvent(event: BillingEvent) {
  // Store locally
  try {
    await prisma.$executeRaw`
      INSERT INTO "BillingEvent" ("type", "tenantId", "detail", "amount", "timestamp")
      VALUES (${event.type}, ${event.tenantId}, ${event.detail}, ${event.amount ?? 0}, ${event.timestamp})
    `;
  } catch { /* table might not exist yet */ }

  // Webhook to external billing system (Stripe, etc.)
  const webhookUrl = process.env.BILLING_WEBHOOK_URL;
  if (webhookUrl) {
    try {
      await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(event),
      });
    } catch {
      console.error('[billing] webhook delivery failed');
    }
  }
}
TBEOF
)
    _mte_write_file "${project_dir}/src/lib/tenant-billing.ts" "$billing_ts"
    MTE_GENERATED=$((MTE_GENERATED + 1))
    return 0
}

# =============================================================================
# mt_inject_tenant_patterns - Claudeプロンプトへのパターン注入
# =============================================================================
mt_inject_tenant_patterns() {
    local prompt="${1:-}"

    cat <<'INJECT'

## [Multi-Tenant Patterns] - マルチテナンシー必須要件

### テナント分離（行レベル）:
- **全テナント対象テーブル**: tenantId カラム必須 + INDEX
- **Prisma middleware**: 全クエリに自動 WHERE tenantId = X 注入
- **Create時**: tenantId を自動設定（コンテキストから取得）
- **クロステナント防止**: 結果のtenantId検証、不一致は即エラー

### テナント検出（優先順）:
1. X-Tenant-ID ヘッダー（API）
2. JWT claim tenantId（認証済み）
3. サブドメイン: acme.app.com → slug=acme
4. カスタムドメイン: acme.com → domain lookup
5. パスプレフィックス: /t/acme/...

### コンテキスト伝搬:
- **AsyncLocalStorage**: リクエスト単位でテナント情報を保持
- **getCurrentTenantId()**: どこからでもテナントID取得
- **withTenantContext()**: テナントスコープ内で関数実行

### 管理API:
- テナントCRUD: create/read/update/soft-delete
- プラン管理: free/starter/pro/enterprise + 機能フラグ
- 利用量追跡: ユーザー数/ストレージ/API呼出数

INJECT

    echo "$prompt"
}

# =============================================================================
# mte_generate_tenant - 全テナント一括生成（レガシー互換）
# =============================================================================
mte_generate_tenant() {
    local project_dir="${PROJECT_DIR:-./output}"
    mt_generate_tenant_model "$project_dir" "row-level"
    mt_generate_tenant_middleware "$project_dir"
    mt_generate_tenant_context "$project_dir"
    mt_generate_data_isolation "$project_dir"
    mt_generate_tenant_admin "$project_dir"
    mt_generate_tenant_billing "$project_dir"
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
mte_report() {
    echo -e "\n  ${BOLD:-}=== multi-tenant-engine v${MTE_VERSION} ===${NC:-}"
    echo -e "  生成数: ${MTE_GENERATED}"
    echo -e "  書込数: ${MTE_FILES_WRITTEN}"
    echo -e "  エラー: ${MTE_ERRORS}"
}

mte_score() {
    if [[ ${MTE_GENERATED} -ge 4 ]] && [[ ${MTE_ERRORS} -eq 0 ]]; then
        echo "95"
    elif [[ ${MTE_GENERATED} -gt 0 ]] && [[ ${MTE_ERRORS} -eq 0 ]]; then
        echo "85"
    elif [[ ${MTE_GENERATED} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "multi-tenant-engine" --version "${MTE_VERSION}" \
        --description "マルチテナント自動設計×テナント分離×コンテキスト伝搬×課金" \
        --init "mt_init" --report "mte_report" --score "mte_score" \
        --enable-var "ENABLE_MULTI_TENANT" --cli-flags "--multi-tenant:--no-multi-tenant"
fi

# v2003.1: source時のexit codeを確実に0にする
true
