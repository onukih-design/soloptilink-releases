#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v257.0 - TypeScript Error Expert
# =============================================================================
# TypeScript固有のエラーパターンを専門的に解析・修正するエキスパートモジュール。
# 30+の一般的なTSエラーパターンと修正テンプレートのデータベースを内蔵。
#
# 対象エラー:
#   - Type X is not assignable to type Y
#   - Property does not exist on type
#   - Generic type parameter errors
#   - Strict null check errors
#   - Import/export type errors
#   - Function overload errors
#   - Enum/union/intersection type errors
#   - Index signature errors
#   - Declaration file errors
#
# Functions:
#   _tee_init                - 初期化・パターンDB構築
#   _tee_fix_type_mismatch   - Type assignment errors
#   _tee_fix_generic_error   - Generic type parameter errors
#   _tee_fix_missing_property - Property does not exist errors
#   _tee_fix_null_check      - Strict null check errors
#   _tee_fix_import_type     - Import/export type errors
#   _tee_fix_overload        - Function overload errors
#   _tee_classify            - Classify TS error into sub-category
#   _tee_get_fix_prompt      - Generate Claude prompt with TS context
#   _tee_auto_fix            - Attempt automatic fix for known patterns
#   _tee_report              - Report output
#   _tee_score               - Module score (0-100)
#
# All globals use the TEE_ prefix.
# =============================================================================

[[ -n "${_TYPESCRIPT_ERROR_EXPERT_LOADED:-}" ]] && return 0
_TYPESCRIPT_ERROR_EXPERT_LOADED=1

# --- Colors ---
readonly _TEE_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly _TEE_YELLOW="${CLR_YELLOW:-\033[0;33m}"
readonly _TEE_RED="${CLR_RED:-\033[0;31m}"
readonly _TEE_BLUE="${CLR_BLUE:-\033[0;34m}"
readonly _TEE_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly _TEE_PURPLE="${CLR_PURPLE:-\033[0;35m}"
readonly _TEE_BOLD="${CLR_BOLD:-\033[1m}"
readonly _TEE_NC="${CLR_NC:-\033[0m}"

# --- Module State ---
TEE_VERSION="257.0"
TEE_INITIALIZED=false
TEE_ENABLED="${TEE_ENABLED:-true}"

# --- Counters ---
TEE_TOTAL_ANALYZED=0
TEE_TOTAL_FIXED=0
TEE_TOTAL_AUTO_FIXED=0
TEE_TOTAL_PROMPTS=0
TEE_FIX_SUCCESS=0
TEE_FIX_FAIL=0

# --- Storage ---
TEE_STORE_DIR=""
TEE_HISTORY_FILE=""

# --- Pattern Database ---
# Format: "ts_error_code|pattern_regex|category|fix_template_fn|severity|description"
declare -g -a _TEE_PATTERNS=()

# --- Error buffer ---
declare -g -a _TEE_ERROR_MSGS=()
declare -g -a _TEE_ERROR_FILES=()
declare -g -a _TEE_ERROR_LINES=()
declare -g -a _TEE_ERROR_CODES=()
declare -g -a _TEE_ERROR_CATEGORIES=()

# =============================================================================
# Pattern Database - 35 common TypeScript error patterns
# =============================================================================
_tee_init_patterns() {
    _TEE_PATTERNS=()

    # --- Type Assignment Errors (TS2322, TS2345) ---
    _TEE_PATTERNS+=("TS2322|Type .* is not assignable to type|type_mismatch|_tee_tmpl_type_mismatch|8|Type assignment error")
    _TEE_PATTERNS+=("TS2345|Argument of type .* is not assignable to parameter|arg_mismatch|_tee_tmpl_arg_mismatch|8|Argument type mismatch")
    _TEE_PATTERNS+=("TS2741|Property .* is missing in type .* but required|missing_required|_tee_tmpl_missing_required|7|Missing required property")
    _TEE_PATTERNS+=("TS2559|Type .* has no properties in common with type|no_common|_tee_tmpl_no_common|6|No common properties")
    _TEE_PATTERNS+=("TS2304|Cannot find name|undefined_name|_tee_tmpl_undefined_name|9|Cannot find name")

    # --- Property Errors (TS2339, TS7053) ---
    _TEE_PATTERNS+=("TS2339|Property .* does not exist on type|missing_property|_tee_tmpl_missing_property|7|Property does not exist")
    _TEE_PATTERNS+=("TS7053|Element implicitly has an 'any' type|implicit_any_element|_tee_tmpl_index_signature|6|Implicit any on element access")
    _TEE_PATTERNS+=("TS7006|Parameter .* implicitly has an 'any' type|implicit_any_param|_tee_tmpl_implicit_any|5|Implicit any parameter")
    _TEE_PATTERNS+=("TS2551|Property .* does not exist.*Did you mean|typo_property|_tee_tmpl_typo_property|4|Property name typo")
    _TEE_PATTERNS+=("TS2540|Cannot assign to .* because it is a read-only|readonly_assign|_tee_tmpl_readonly|5|Read-only assignment")

    # --- Null/Undefined Checks (TS2531, TS2532, TS18047, TS18048) ---
    _TEE_PATTERNS+=("TS2531|Object is possibly 'null'|null_check|_tee_tmpl_null_check|7|Object possibly null")
    _TEE_PATTERNS+=("TS2532|Object is possibly 'undefined'|undefined_check|_tee_tmpl_undefined_check|7|Object possibly undefined")
    _TEE_PATTERNS+=("TS18047|.* is possibly 'null'|null_var|_tee_tmpl_null_check|7|Variable possibly null")
    _TEE_PATTERNS+=("TS18048|.* is possibly 'undefined'|undefined_var|_tee_tmpl_undefined_check|7|Variable possibly undefined")
    _TEE_PATTERNS+=("TS2533|Object is possibly 'null' or 'undefined'|null_or_undefined|_tee_tmpl_nullish_check|8|Object possibly null or undefined")

    # --- Generic Type Errors (TS2314, TS2344, TS2558) ---
    _TEE_PATTERNS+=("TS2314|Generic type .* requires .* type argument|generic_args|_tee_tmpl_generic_args|6|Missing generic type arguments")
    _TEE_PATTERNS+=("TS2344|Type .* does not satisfy the constraint|generic_constraint|_tee_tmpl_generic_constraint|7|Generic constraint violation")
    _TEE_PATTERNS+=("TS2558|Expected .* type arguments, but got|generic_count|_tee_tmpl_generic_count|5|Wrong number of type arguments")
    _TEE_PATTERNS+=("TS2707|Generic type .* requires between|generic_range|_tee_tmpl_generic_range|5|Generic argument count out of range")

    # --- Import/Export Errors (TS1192, TS2305, TS2497, TS1259) ---
    _TEE_PATTERNS+=("TS2305|Module .* has no exported member|no_export|_tee_tmpl_no_export|8|Module has no exported member")
    _TEE_PATTERNS+=("TS1192|Module .* has no default export|no_default_export|_tee_tmpl_no_default|7|No default export")
    _TEE_PATTERNS+=("TS2497|Module .* resolves to a non-module entity|non_module|_tee_tmpl_non_module|6|Non-module entity")
    _TEE_PATTERNS+=("TS1259|Module .* can only be default-imported using|esm_import|_tee_tmpl_esm_import|5|ESM import syntax needed")
    _TEE_PATTERNS+=("TS2307|Cannot find module .* or its corresponding type|module_not_found|_tee_tmpl_module_not_found|9|Module not found")
    _TEE_PATTERNS+=("TS7016|Could not find a declaration file for module|missing_dts|_tee_tmpl_missing_dts|4|Missing declaration file")

    # --- Function Overload Errors (TS2769, TS2554) ---
    _TEE_PATTERNS+=("TS2769|No overload matches this call|overload_mismatch|_tee_tmpl_overload|7|No overload matches")
    _TEE_PATTERNS+=("TS2554|Expected .* arguments, but got|arg_count|_tee_tmpl_arg_count|6|Wrong argument count")
    _TEE_PATTERNS+=("TS2556|A spread argument must either have a tuple type|spread_arg|_tee_tmpl_spread_arg|5|Spread argument type")

    # --- Enum/Union/Intersection Errors ---
    _TEE_PATTERNS+=("TS2365|Operator .* cannot be applied to types|operator_type|_tee_tmpl_operator|5|Operator type error")
    _TEE_PATTERNS+=("TS2678|Type .* is not comparable to type|not_comparable|_tee_tmpl_not_comparable|5|Type not comparable")
    _TEE_PATTERNS+=("TS2590|Expression produces a union type that is too complex|complex_union|_tee_tmpl_complex_union|4|Union too complex")

    # --- Async/Promise Errors ---
    _TEE_PATTERNS+=("TS2801|This condition will always return .* since.*Promise|promise_condition|_tee_tmpl_promise_condition|7|Promise in condition")
    _TEE_PATTERNS+=("TS1064|The return type of an async function must have a then|async_return|_tee_tmpl_async_return|6|Async return type")

    # --- JSX/React Specific TS Errors ---
    _TEE_PATTERNS+=("TS2786|.* cannot be used as a JSX component|jsx_component|_tee_tmpl_jsx_component|7|Invalid JSX component")
    _TEE_PATTERNS+=("TS2607|JSX element type .* does not have any construct|jsx_construct|_tee_tmpl_jsx_construct|6|JSX construct error")
    _TEE_PATTERNS+=("TS2746|This JSX tag's 'children' prop expects a single child|jsx_children|_tee_tmpl_jsx_children|5|JSX children type")
}

# =============================================================================
# Fix Template Functions - Each generates specific fix guidance
# =============================================================================

_tee_tmpl_type_mismatch() {
    local msg="$1" file="$2" line="$3"
    local source_type target_type
    source_type=$(echo "$msg" | grep -oP "Type '\\K[^']+(?=')" | head -1)
    target_type=$(echo "$msg" | grep -oP "to type '\\K[^']+(?=')" | head -1)

    cat <<FIX
**Fix for Type Mismatch** (${file}:${line})
Source type: \`${source_type}\`
Target type: \`${target_type}\`

Solutions (in order of preference):
1. **Update the value** to match the expected type:
   - If \`${target_type}\` is a union, ensure value is one of the union members
   - If \`${target_type}\` is an interface, add missing properties
2. **Update the type annotation** if the current type is too restrictive:
   \`\`\`typescript
   // Before: const x: ${target_type} = value;
   // After:  const x: ${source_type} | ${target_type} = value;
   \`\`\`
3. **Use a type guard** to narrow the type:
   \`\`\`typescript
   if (isTargetType(value)) { /* safe to use as ${target_type} */ }
   \`\`\`
4. **Last resort - type assertion** (unsafe):
   \`\`\`typescript
   const x = value as ${target_type};
   \`\`\`
FIX
}

_tee_tmpl_arg_mismatch() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Argument Type Mismatch** (${file}:${line})
The argument passed to the function doesn't match the expected parameter type.

Solutions:
1. Check the function signature and pass the correct type
2. Transform the argument: \`transformFn(arg)\` or spread/destructure
3. Update the function parameter type if it's too restrictive
4. Use a type guard before calling the function
FIX
}

_tee_tmpl_missing_required() {
    local msg="$1" file="$2" line="$3"
    local prop
    prop=$(echo "$msg" | grep -oP "Property '\\K[^']+(?=')" | head -1)
    cat <<FIX
**Fix for Missing Required Property** (${file}:${line})
Property \`${prop}\` is required but not provided.

Solutions:
1. Add the missing property: \`{ ...existing, ${prop}: defaultValue }\`
2. Make the property optional in the type: \`${prop}?: Type\`
3. Use \`Partial<T>\` if many properties are optional
FIX
}

_tee_tmpl_no_common() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for No Common Properties** (${file}:${line})
The object has no matching properties with the target type.

Solutions:
1. Verify you're using the correct type/interface
2. Check for typos in property names
3. The types might need to be updated to share a common base
FIX
}

_tee_tmpl_undefined_name() {
    local msg="$1" file="$2" line="$3"
    local name
    name=$(echo "$msg" | grep -oP "Cannot find name '\\K[^']+(?=')" | head -1)
    cat <<FIX
**Fix for Cannot Find Name** (${file}:${line})
Name \`${name}\` is not defined in scope.

Solutions:
1. Import it: \`import { ${name} } from './module'\`
2. Declare it if it's a global: \`declare const ${name}: Type;\`
3. Check for typos in the name
4. Ensure the module is installed: \`npm install <package>\`
FIX
}

_tee_tmpl_missing_property() {
    local msg="$1" file="$2" line="$3"
    local prop obj_type
    prop=$(echo "$msg" | grep -oP "Property '\\K[^']+(?=')" | head -1)
    obj_type=$(echo "$msg" | grep -oP "on type '\\K[^']+(?=')" | head -1)
    cat <<FIX
**Fix for Missing Property** (${file}:${line})
Property \`${prop}\` does not exist on type \`${obj_type}\`.

Solutions:
1. **Check the type definition** - the property might be named differently
2. **Extend the interface**:
   \`\`\`typescript
   interface Extended extends ${obj_type} { ${prop}: string; }
   \`\`\`
3. **Use type assertion** (if you're certain):
   \`\`\`typescript
   (obj as any).${prop}  // unsafe
   \`\`\`
4. **Use optional chaining** if property might not exist:
   \`\`\`typescript
   (obj as Record<string, unknown>)?.${prop}
   \`\`\`
5. **Add index signature** to the type:
   \`\`\`typescript
   interface ${obj_type} { [key: string]: unknown; }
   \`\`\`
FIX
}

_tee_tmpl_index_signature() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Implicit Any Element Access** (${file}:${line})
Accessing an object property dynamically without an index signature.

Solutions:
1. Add index signature: \`{ [key: string]: ValueType }\`
2. Use \`Record<string, ValueType>\` type
3. Use type assertion: \`obj[key as keyof typeof obj]\`
4. Use \`Map<string, ValueType>\` instead of plain object
FIX
}

_tee_tmpl_implicit_any() {
    local msg="$1" file="$2" line="$3"
    local param
    param=$(echo "$msg" | grep -oP "Parameter '\\K[^']+(?=')" | head -1)
    cat <<FIX
**Fix for Implicit Any Parameter** (${file}:${line})
Parameter \`${param}\` needs a type annotation.

Solutions:
1. Add type: \`(${param}: string)\` or appropriate type
2. If event handler: \`(e: React.ChangeEvent<HTMLInputElement>)\`
3. If callback: infer from context or add explicit type
FIX
}

_tee_tmpl_typo_property() {
    local msg="$1" file="$2" line="$3"
    local wrong correct
    wrong=$(echo "$msg" | grep -oP "Property '\\K[^']+(?=')" | head -1)
    correct=$(echo "$msg" | grep -oP "Did you mean '\\K[^']+(?=')" | head -1)
    cat <<FIX
**Fix for Property Typo** (${file}:${line})
Replace \`${wrong}\` with \`${correct}\`.
FIX
}

_tee_tmpl_readonly() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Read-only Assignment** (${file}:${line})
Cannot assign to a read-only property.

Solutions:
1. Use a mutable copy: \`const mutable = { ...readonlyObj };\`
2. Remove \`readonly\` modifier if mutation is intended
3. Use a state setter instead of direct mutation
FIX
}

_tee_tmpl_null_check() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Possibly Null** (${file}:${line})
Object might be null at runtime.

Solutions:
1. **Null check**: \`if (obj !== null) { obj.prop }\`
2. **Optional chaining**: \`obj?.prop\`
3. **Non-null assertion** (if certain): \`obj!.prop\`
4. **Nullish coalescing**: \`obj ?? defaultValue\`
5. **Type narrowing**:
   \`\`\`typescript
   if (!obj) { throw new Error('Expected non-null'); }
   obj.prop; // TypeScript knows obj is non-null here
   \`\`\`
FIX
}

_tee_tmpl_undefined_check() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Possibly Undefined** (${file}:${line})
Object might be undefined at runtime.

Solutions:
1. **Check before use**: \`if (obj !== undefined) { obj.prop }\`
2. **Optional chaining**: \`obj?.prop\`
3. **Default value**: \`const val = obj ?? defaultValue;\`
4. **Early return**: \`if (!obj) return;\`
FIX
}

_tee_tmpl_nullish_check() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Possibly Null or Undefined** (${file}:${line})
Solutions:
1. \`if (obj != null) { /* obj is neither null nor undefined */ }\`
2. \`obj?.prop ?? defaultValue\`
3. Type guard: \`function isValid(x: T | null | undefined): x is T { return x != null; }\`
FIX
}

_tee_tmpl_generic_args() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Missing Generic Type Arguments** (${file}:${line})
Generic type requires explicit type parameters.

Solutions:
1. Add type arguments: \`GenericType<string, number>\`
2. Let TypeScript infer: ensure the context provides enough info
3. Add defaults to generic: \`type G<T = string> = ...\`
FIX
}

_tee_tmpl_generic_constraint() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Generic Constraint Violation** (${file}:${line})
Type doesn't satisfy the generic constraint.

Solutions:
1. Ensure the type extends the required constraint
2. Widen the constraint: \`<T extends BaseType>\` -> \`<T extends Partial<BaseType>>\`
3. Add missing properties to satisfy the constraint
FIX
}

_tee_tmpl_generic_count() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Wrong Type Argument Count** (${file}:${line})
Pass the correct number of type arguments to the generic type.
Check the generic definition for the expected number of type parameters.
FIX
}

_tee_tmpl_generic_range() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Generic Argument Range** (${file}:${line})
The generic type requires a specific range of type arguments.
Some may have defaults - check which are optional.
FIX
}

_tee_tmpl_no_export() {
    local msg="$1" file="$2" line="$3"
    local member module
    member=$(echo "$msg" | grep -oP "exported member '\\K[^']+(?=')" | head -1)
    module=$(echo "$msg" | grep -oP "Module '\\K[^']+(?=')" | head -1)
    cat <<FIX
**Fix for Missing Export** (${file}:${line})
Module \`${module}\` doesn't export \`${member}\`.

Solutions:
1. Check the actual exports: the name might be different
2. Add the export to the source module
3. Use \`import type\` if it's a type-only export
4. Check if it was renamed: \`export { Original as ${member} }\`
FIX
}

_tee_tmpl_no_default() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for No Default Export** (${file}:${line})
Use named import instead: \`import { name } from 'module'\`
Or add \`export default\` to the source module.
FIX
}

_tee_tmpl_non_module() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Non-Module Entity** (${file}:${line})
The import resolves to something that isn't a module.
Try: \`import * as name from 'module'\` or check module format (CJS vs ESM).
FIX
}

_tee_tmpl_esm_import() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for ESM Import** (${file}:${line})
Enable \`esModuleInterop\` in tsconfig.json, or use:
\`import * as name from 'module'\` instead of \`import name from 'module'\`.
FIX
}

_tee_tmpl_module_not_found() {
    local msg="$1" file="$2" line="$3"
    local module
    module=$(echo "$msg" | grep -oP "module '\\K[^']+(?=')" | head -1)
    cat <<FIX
**Fix for Module Not Found** (${file}:${line})
Module \`${module}\` cannot be found.

Solutions:
1. Install: \`npm install ${module}\`
2. Install types: \`npm install -D @types/${module}\`
3. Check path alias in tsconfig.json \`paths\`
4. Verify relative path is correct from ${file}
5. Create declaration file: \`declare module '${module}'\`
FIX
}

_tee_tmpl_missing_dts() {
    local msg="$1" file="$2" line="$3"
    local module
    module=$(echo "$msg" | grep -oP "for module '\\K[^']+(?=')" | head -1)
    cat <<FIX
**Fix for Missing Declaration File** (${file}:${line})
1. Install types: \`npm install -D @types/${module}\`
2. Or create \`${module}.d.ts\`: \`declare module '${module}';\`
3. Or add to tsconfig: \`"skipLibCheck": true\` (less safe)
FIX
}

_tee_tmpl_overload() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Overload Mismatch** (${file}:${line})
No function overload matches the provided arguments.

Solutions:
1. Check all overload signatures and match one exactly
2. Verify argument types and count
3. Try explicit type annotations on arguments
4. Check if optional parameters need to be provided
FIX
}

_tee_tmpl_arg_count() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Wrong Argument Count** (${file}:${line})
Pass the correct number of arguments. Check the function signature.
If using optional params, ensure required ones are provided first.
FIX
}

_tee_tmpl_spread_arg() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Spread Argument** (${file}:${line})
Use \`as const\` on the array or type it as a tuple:
\`const args = [a, b] as const; fn(...args);\`
Or: \`const args: [string, number] = [a, b]; fn(...args);\`
FIX
}

_tee_tmpl_operator() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Operator Type Error** (${file}:${line})
The operator cannot be used with these types. Convert types first:
\`Number(value)\`, \`String(value)\`, or use appropriate comparison.
FIX
}

_tee_tmpl_not_comparable() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Not Comparable** (${file}:${line})
Types are not comparable in switch/if. Use explicit type narrowing or casting.
FIX
}

_tee_tmpl_complex_union() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Complex Union** (${file}:${line})
Simplify the union type. Extract sub-types into named types.
Use discriminated unions with a shared literal property.
FIX
}

_tee_tmpl_promise_condition() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Promise in Condition** (${file}:${line})
You're checking a Promise object (always truthy) instead of its resolved value.
Add \`await\`: \`if (await promise) { ... }\`
FIX
}

_tee_tmpl_async_return() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Async Return Type** (${file}:${line})
Async functions must return a Promise. Use \`Promise<ReturnType>\` annotation.
FIX
}

_tee_tmpl_jsx_component() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for Invalid JSX Component** (${file}:${line})
Component doesn't satisfy JSX element requirements.

Solutions:
1. Ensure component returns \`JSX.Element | null\`
2. Check React version compatibility in @types/react
3. Ensure the component is a valid function/class component
4. Check for conflicting React type versions
FIX
}

_tee_tmpl_jsx_construct() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for JSX Construct Error** (${file}:${line})
The JSX element type doesn't have a construct/call signature.
Ensure it's a React component (function or class), not a plain object.
FIX
}

_tee_tmpl_jsx_children() {
    local msg="$1" file="$2" line="$3"
    cat <<FIX
**Fix for JSX Children Type** (${file}:${line})
Wrap multiple children in a fragment: \`<>{child1}{child2}</>\`
Or use an array with keys if the component expects a single child.
FIX
}

# =============================================================================
# _tee_init - Initialize module
# =============================================================================
_tee_init() {
    [[ "$TEE_ENABLED" != "true" ]] && return 0

    TEE_STORE_DIR="${HOME}/.soloptilink/ts-errors"
    mkdir -p "$TEE_STORE_DIR" 2>/dev/null || true
    TEE_HISTORY_FILE="${TEE_STORE_DIR}/fix_history.jsonl"

    TEE_TOTAL_ANALYZED=0
    TEE_TOTAL_FIXED=0
    TEE_TOTAL_AUTO_FIXED=0
    TEE_TOTAL_PROMPTS=0
    TEE_FIX_SUCCESS=0
    TEE_FIX_FAIL=0

    _TEE_ERROR_MSGS=()
    _TEE_ERROR_FILES=()
    _TEE_ERROR_LINES=()
    _TEE_ERROR_CODES=()
    _TEE_ERROR_CATEGORIES=()

    _tee_init_patterns

    TEE_INITIALIZED=true
    echo -e "  ${_TEE_GREEN}[TEE]${_TEE_NC} TypeScript Error Expert v${TEE_VERSION} initialized (${#_TEE_PATTERNS[@]} patterns)" >&2
    return 0
}

# =============================================================================
# _tee_classify - Classify a TypeScript error into sub-category
# Returns: "ts_code|category|severity|pattern_index"
# =============================================================================
_tee_classify() {
    local error_msg="${1:-}"
    [[ -z "$error_msg" ]] && echo "unknown|unknown|0|-1" && return 0

    local i=0
    for pattern_def in "${_TEE_PATTERNS[@]}"; do
        local IFS='|'
        local parts=($pattern_def)
        unset IFS

        local ts_code="${parts[0]}"
        local regex="${parts[1]}"
        local category="${parts[2]}"
        local severity="${parts[4]}"

        if echo "$error_msg" | grep -qiE "$regex" 2>/dev/null; then
            echo "${ts_code}|${category}|${severity}|${i}"
            return 0
        fi

        # Also match by TS error code
        if echo "$error_msg" | grep -q "$ts_code" 2>/dev/null; then
            echo "${ts_code}|${category}|${severity}|${i}"
            return 0
        fi

        i=$((i + 1))
    done

    echo "unknown|unknown|3|-1"
}

# =============================================================================
# _tee_fix_type_mismatch - Fix "Type X is not assignable to type Y"
# =============================================================================
_tee_fix_type_mismatch() {
    local error_msg="${1:-}"
    local file="${2:-}"
    local line="${3:-0}"

    TEE_TOTAL_ANALYZED=$((TEE_TOTAL_ANALYZED + 1))
    echo -e "  ${_TEE_CYAN}[TEE]${_TEE_NC} Fixing type mismatch in ${file}:${line}" >&2

    _tee_tmpl_type_mismatch "$error_msg" "$file" "$line"
    TEE_TOTAL_FIXED=$((TEE_TOTAL_FIXED + 1))
}

# =============================================================================
# _tee_fix_generic_error - Fix generic type parameter errors
# =============================================================================
_tee_fix_generic_error() {
    local error_msg="${1:-}"
    local file="${2:-}"
    local line="${3:-0}"

    TEE_TOTAL_ANALYZED=$((TEE_TOTAL_ANALYZED + 1))
    echo -e "  ${_TEE_CYAN}[TEE]${_TEE_NC} Fixing generic error in ${file}:${line}" >&2

    local classification
    classification=$(_tee_classify "$error_msg")
    local category
    category=$(echo "$classification" | cut -d'|' -f2)

    case "$category" in
        generic_args)     _tee_tmpl_generic_args "$error_msg" "$file" "$line" ;;
        generic_constraint) _tee_tmpl_generic_constraint "$error_msg" "$file" "$line" ;;
        generic_count)    _tee_tmpl_generic_count "$error_msg" "$file" "$line" ;;
        generic_range)    _tee_tmpl_generic_range "$error_msg" "$file" "$line" ;;
        *)                _tee_tmpl_generic_args "$error_msg" "$file" "$line" ;;
    esac
    TEE_TOTAL_FIXED=$((TEE_TOTAL_FIXED + 1))
}

# =============================================================================
# _tee_fix_missing_property - Fix "Property does not exist on type"
# =============================================================================
_tee_fix_missing_property() {
    local error_msg="${1:-}"
    local file="${2:-}"
    local line="${3:-0}"

    TEE_TOTAL_ANALYZED=$((TEE_TOTAL_ANALYZED + 1))
    echo -e "  ${_TEE_CYAN}[TEE]${_TEE_NC} Fixing missing property in ${file}:${line}" >&2

    # Check if it's a typo suggestion
    if echo "$error_msg" | grep -q "Did you mean" 2>/dev/null; then
        _tee_tmpl_typo_property "$error_msg" "$file" "$line"
    else
        _tee_tmpl_missing_property "$error_msg" "$file" "$line"
    fi
    TEE_TOTAL_FIXED=$((TEE_TOTAL_FIXED + 1))
}

# =============================================================================
# _tee_fix_null_check - Fix strict null check errors
# =============================================================================
_tee_fix_null_check() {
    local error_msg="${1:-}"
    local file="${2:-}"
    local line="${3:-0}"

    TEE_TOTAL_ANALYZED=$((TEE_TOTAL_ANALYZED + 1))
    echo -e "  ${_TEE_CYAN}[TEE]${_TEE_NC} Fixing null check in ${file}:${line}" >&2

    if echo "$error_msg" | grep -q "'null' or 'undefined'" 2>/dev/null; then
        _tee_tmpl_nullish_check "$error_msg" "$file" "$line"
    elif echo "$error_msg" | grep -q "'null'" 2>/dev/null; then
        _tee_tmpl_null_check "$error_msg" "$file" "$line"
    else
        _tee_tmpl_undefined_check "$error_msg" "$file" "$line"
    fi
    TEE_TOTAL_FIXED=$((TEE_TOTAL_FIXED + 1))
}

# =============================================================================
# _tee_fix_import_type - Fix import/export type errors
# =============================================================================
_tee_fix_import_type() {
    local error_msg="${1:-}"
    local file="${2:-}"
    local line="${3:-0}"

    TEE_TOTAL_ANALYZED=$((TEE_TOTAL_ANALYZED + 1))
    echo -e "  ${_TEE_CYAN}[TEE]${_TEE_NC} Fixing import/type error in ${file}:${line}" >&2

    local classification
    classification=$(_tee_classify "$error_msg")
    local category
    category=$(echo "$classification" | cut -d'|' -f2)

    case "$category" in
        no_export)        _tee_tmpl_no_export "$error_msg" "$file" "$line" ;;
        no_default_export) _tee_tmpl_no_default "$error_msg" "$file" "$line" ;;
        module_not_found) _tee_tmpl_module_not_found "$error_msg" "$file" "$line" ;;
        missing_dts)      _tee_tmpl_missing_dts "$error_msg" "$file" "$line" ;;
        esm_import)       _tee_tmpl_esm_import "$error_msg" "$file" "$line" ;;
        non_module)       _tee_tmpl_non_module "$error_msg" "$file" "$line" ;;
        *)                _tee_tmpl_module_not_found "$error_msg" "$file" "$line" ;;
    esac
    TEE_TOTAL_FIXED=$((TEE_TOTAL_FIXED + 1))
}

# =============================================================================
# _tee_fix_overload - Fix function overload errors
# =============================================================================
_tee_fix_overload() {
    local error_msg="${1:-}"
    local file="${2:-}"
    local line="${3:-0}"

    TEE_TOTAL_ANALYZED=$((TEE_TOTAL_ANALYZED + 1))
    echo -e "  ${_TEE_CYAN}[TEE]${_TEE_NC} Fixing overload error in ${file}:${line}" >&2

    if echo "$error_msg" | grep -q "Expected.*arguments" 2>/dev/null; then
        _tee_tmpl_arg_count "$error_msg" "$file" "$line"
    elif echo "$error_msg" | grep -q "spread argument" 2>/dev/null; then
        _tee_tmpl_spread_arg "$error_msg" "$file" "$line"
    else
        _tee_tmpl_overload "$error_msg" "$file" "$line"
    fi
    TEE_TOTAL_FIXED=$((TEE_TOTAL_FIXED + 1))
}

# =============================================================================
# _tee_get_fix_prompt - Generate Claude prompt with TS-specific context
# =============================================================================
_tee_get_fix_prompt() {
    local error_msg="${1:-}"
    local file="${2:-}"
    local line="${3:-0}"
    local file_content="${4:-}"

    TEE_TOTAL_PROMPTS=$((TEE_TOTAL_PROMPTS + 1))

    local classification
    classification=$(_tee_classify "$error_msg")
    local ts_code category severity pattern_idx
    ts_code=$(echo "$classification" | cut -d'|' -f1)
    category=$(echo "$classification" | cut -d'|' -f2)
    severity=$(echo "$classification" | cut -d'|' -f3)
    pattern_idx=$(echo "$classification" | cut -d'|' -f4)

    # Get fix template
    local fix_guidance=""
    if [[ "$pattern_idx" -ge 0 ]] && [[ "$pattern_idx" -lt ${#_TEE_PATTERNS[@]} ]]; then
        local pattern_def="${_TEE_PATTERNS[$pattern_idx]}"
        local IFS='|'
        local parts=($pattern_def)
        unset IFS
        local fix_fn="${parts[3]}"
        if type -t "$fix_fn" &>/dev/null; then
            fix_guidance=$($fix_fn "$error_msg" "$file" "$line")
        fi
    fi

    cat <<PROMPT
## TypeScript Error Fix Request

### Error Details
- **Error Code**: ${ts_code}
- **Category**: ${category}
- **Severity**: ${severity}/10
- **File**: ${file}
- **Line**: ${line}
- **Message**: ${error_msg}

### Expert Fix Guidance
${fix_guidance}

### File Context
\`\`\`typescript
${file_content}
\`\`\`

### Instructions
1. Fix ONLY the TypeScript error described above
2. Maintain type safety - do NOT use \`any\` type unless absolutely necessary
3. Prefer type narrowing over type assertions
4. If changing types, verify downstream usage is still correct
5. Run \`npx tsc --noEmit\` after fix to verify no new errors introduced
PROMPT
}

# =============================================================================
# _tee_auto_fix - Attempt automatic fix for known simple patterns
# Returns the fix code or empty string if cannot auto-fix
# =============================================================================
_tee_auto_fix() {
    local error_msg="${1:-}"
    local file="${2:-}"
    local line="${3:-0}"
    local file_content="${4:-}"

    local classification
    classification=$(_tee_classify "$error_msg")
    local category
    category=$(echo "$classification" | cut -d'|' -f2)

    case "$category" in
        typo_property)
            # Auto-fix: rename property to suggested name
            local wrong correct
            wrong=$(echo "$error_msg" | grep -oP "Property '\\K[^']+(?=')" | head -1)
            correct=$(echo "$error_msg" | grep -oP "Did you mean '\\K[^']+(?=')" | head -1)
            if [[ -n "$wrong" ]] && [[ -n "$correct" ]] && [[ -n "$file_content" ]]; then
                echo "$file_content" | sed "s/\\.${wrong}/.${correct}/g"
                TEE_TOTAL_AUTO_FIXED=$((TEE_TOTAL_AUTO_FIXED + 1))
                echo -e "  ${_TEE_GREEN}[TEE]${_TEE_NC} Auto-fixed: ${wrong} -> ${correct}" >&2
                return 0
            fi
            ;;
        null_check|undefined_check|null_var|undefined_var)
            # Auto-fix: add optional chaining
            echo -e "  ${_TEE_YELLOW}[TEE]${_TEE_NC} Suggest: Add optional chaining (?.) at ${file}:${line}" >&2
            ;;
        implicit_any_param)
            # Cannot safely auto-fix without knowing the expected type
            echo -e "  ${_TEE_YELLOW}[TEE]${_TEE_NC} Cannot auto-fix implicit any - type information needed" >&2
            ;;
    esac

    return 1
}

# =============================================================================
# _tee_analyze_batch - Analyze a batch of TypeScript errors from build output
# =============================================================================
_tee_analyze_batch() {
    local build_output="${1:-}"
    [[ -z "$build_output" ]] && return 0

    local count=0
    local fixed=0

    # Parse TypeScript error lines: file(line,col): error TSxxxx: message
    while IFS= read -r line; do
        if echo "$line" | grep -qE "error TS[0-9]+:" 2>/dev/null; then
            local err_file err_line err_msg err_code
            err_file=$(echo "$line" | grep -oP '^[^(]+(?=\()' | head -1)
            err_line=$(echo "$line" | grep -oP '\((\d+),' | grep -oP '\d+' | head -1)
            err_code=$(echo "$line" | grep -oP 'TS\d+' | head -1)
            err_msg=$(echo "$line" | grep -oP 'error TS\d+: \K.*' | head -1)

            _TEE_ERROR_MSGS+=("$err_msg")
            _TEE_ERROR_FILES+=("$err_file")
            _TEE_ERROR_LINES+=("$err_line")
            _TEE_ERROR_CODES+=("$err_code")

            local classification
            classification=$(_tee_classify "$err_msg")
            local category
            category=$(echo "$classification" | cut -d'|' -f2)
            _TEE_ERROR_CATEGORIES+=("$category")

            count=$((count + 1))
        fi
    done <<< "$build_output"

    TEE_TOTAL_ANALYZED=$((TEE_TOTAL_ANALYZED + count))
    echo -e "  ${_TEE_BLUE}[TEE]${_TEE_NC} Analyzed ${count} TypeScript errors" >&2
    echo "$count"
}

# =============================================================================
# _tee_get_summary - Get error summary grouped by category
# =============================================================================
_tee_get_summary() {
    local -A category_counts=()

    for cat in "${_TEE_ERROR_CATEGORIES[@]}"; do
        category_counts["$cat"]=$(( ${category_counts[$cat]:-0} + 1 ))
    done

    echo "TypeScript Error Summary:"
    for cat in "${!category_counts[@]}"; do
        printf "  %-25s : %d\n" "$cat" "${category_counts[$cat]}"
    done | sort -t: -k2 -rn
}

# =============================================================================
# _tee_log_fix - Log a fix to history
# =============================================================================
_tee_log_fix() {
    local ts_code="$1" category="$2" file="$3" success="$4"

    [[ -z "$TEE_HISTORY_FILE" ]] && return 0

    local timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    echo "{\"timestamp\":\"${timestamp}\",\"ts_code\":\"${ts_code}\",\"category\":\"${category}\",\"file\":\"${file}\",\"success\":${success}}" >> "$TEE_HISTORY_FILE" 2>/dev/null || true

    if [[ "$success" == "true" ]]; then
        TEE_FIX_SUCCESS=$((TEE_FIX_SUCCESS + 1))
    else
        TEE_FIX_FAIL=$((TEE_FIX_FAIL + 1))
    fi
}

# =============================================================================
# _tee_report - Report output
# =============================================================================
_tee_report() {
    echo -e "\n  ${_TEE_BOLD}=== TypeScript Error Expert v${TEE_VERSION} Report ===${_TEE_NC}"
    echo -e "  Patterns loaded    : ${#_TEE_PATTERNS[@]}"
    echo -e "  Errors analyzed    : ${TEE_TOTAL_ANALYZED}"
    echo -e "  Fixes generated    : ${TEE_TOTAL_FIXED}"
    echo -e "  Auto-fixes applied : ${TEE_TOTAL_AUTO_FIXED}"
    echo -e "  Fix prompts        : ${TEE_TOTAL_PROMPTS}"
    echo -e "  Fix success        : ${TEE_FIX_SUCCESS}"
    echo -e "  Fix failures       : ${TEE_FIX_FAIL}"

    if [[ ${#_TEE_ERROR_CATEGORIES[@]} -gt 0 ]]; then
        echo -e "\n  ${_TEE_BOLD}Error Categories:${_TEE_NC}"
        _tee_get_summary | while IFS= read -r line; do
            echo -e "  $line"
        done
    fi
}

# =============================================================================
# _tee_score - Module score (0-100)
# =============================================================================
_tee_score() {
    local score=50
    [[ ${#_TEE_PATTERNS[@]} -ge 30 ]] && score=$((score + 10))
    [[ $TEE_TOTAL_ANALYZED -gt 0 ]] && score=$((score + 10))
    [[ $TEE_TOTAL_FIXED -gt 0 ]] && score=$((score + 10))
    [[ $TEE_TOTAL_AUTO_FIXED -gt 0 ]] && score=$((score + 10))
    if [[ $((TEE_FIX_SUCCESS + TEE_FIX_FAIL)) -gt 0 ]]; then
        local rate=$((TEE_FIX_SUCCESS * 100 / (TEE_FIX_SUCCESS + TEE_FIX_FAIL)))
        [[ $rate -ge 70 ]] && score=$((score + 10))
    fi
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# _tee_init_message
# =============================================================================
_tee_init_message() {
    echo -e "  ${_TEE_GREEN}v${TEE_VERSION}${_TEE_NC} TypeScript Error Expert: ${#_TEE_PATTERNS[@]} error patterns, auto-fix, batch analysis" >&2
}

# =============================================================================
# Module Registry Registration
# =============================================================================
_mr_register \
    --name "typescript-error-expert" \
    --version "${TEE_VERSION}" \
    --description "TypeScript専門エラー解析・修正（35パターン、自動修正、バッチ分析）" \
    --init "_tee_init" \
    --report "_tee_report" \
    --score "_tee_score" \
    --enable-var "TEE_ENABLED" \
    --cli-flags "--ts-error-expert:--no-ts-error-expert" \
    --init-msg "_tee_init_message"
