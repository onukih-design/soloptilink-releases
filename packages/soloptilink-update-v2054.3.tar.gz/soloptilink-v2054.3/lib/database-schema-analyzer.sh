#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v212.0 - Database Schema Analyzer
# =============================================================================
# Prismaスキーマの自動解析・リレーション分析・問題検出・改善提案・
# ER図生成・マイグレーション安全性チェックを行うデータベーススキーマ解析エンジン。
#
# 機能:
#   - Prisma schema.prisma ファイルのパース
#   - テーブルリレーション分析（1:1, 1:N, N:M）
#   - スキーマ問題検出（インデックス欠如/非正規化/命名規約違反）
#   - スキーマ改善提案
#   - テキストベースER図生成
#   - マイグレーション安全性チェック
#   - Claudeプロンプト注入用スキーマコンテキスト
#
# 全globals: DSA_ prefix
# =============================================================================

[[ -n "${_DSA_LOADED:-}" ]] && return 0; _DSA_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g DSA_VERSION="212.0"
declare -g DSA_INITIALIZED=false
declare -g DSA_ERRORS=0
declare -g DSA_PHASE="database_schema_analyzer"
declare -g DSA_STORAGE_DIR="${HOME}/.soloptilink/schema-analysis"
declare -g DSA_MODELS_FOUND=0
declare -g DSA_RELATIONS_FOUND=0
declare -g DSA_ISSUES_FOUND=0
declare -g DSA_SUGGESTIONS=0
declare -g DSA_GENERATED=0

# =============================================================================
# 初期化
# =============================================================================
dsa_init() {
    DSA_INITIALIZED=true
    DSA_ERRORS=0
    DSA_MODELS_FOUND=0
    DSA_RELATIONS_FOUND=0
    DSA_ISSUES_FOUND=0
    DSA_SUGGESTIONS=0
    DSA_GENERATED=0

    mkdir -p "${DSA_STORAGE_DIR}/models" 2>/dev/null
    mkdir -p "${DSA_STORAGE_DIR}/relations" 2>/dev/null
    mkdir -p "${DSA_STORAGE_DIR}/reports" 2>/dev/null

    return 0
}

# =============================================================================
# Internal: Prismaスキーマファイル検索
# =============================================================================
_dsa_find_schema() {
    local project_dir="$1"
    for candidate in \
        "${project_dir}/prisma/schema.prisma" \
        "${project_dir}/src/prisma/schema.prisma" \
        "${project_dir}/schema.prisma" \
        "${project_dir}/db/schema.prisma"; do
        [[ -f "$candidate" ]] && echo "$candidate" && return 0
    done
    return 1
}

# =============================================================================
# Internal: フィールド型を正規化
# =============================================================================
_dsa_normalize_type() {
    local raw_type="$1"
    # Optional(?)と配列([])を分離
    local base_type="$raw_type"
    local is_optional=false
    local is_array=false

    if [[ "$base_type" == *"?" ]]; then
        is_optional=true
        base_type="${base_type%?}"
    fi
    if [[ "$base_type" == *"[]" ]]; then
        is_array=true
        base_type="${base_type%\[\]}"
    fi

    echo "${base_type}|${is_optional}|${is_array}"
}

# =============================================================================
# スキーマパース
# =============================================================================
_dsa_parse_schema() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    [[ "$DSA_INITIALIZED" != "true" ]] && dsa_init

    local schema_file
    schema_file=$(_dsa_find_schema "$project_dir")
    if [[ -z "$schema_file" ]]; then
        echo "[database-schema-analyzer] No schema.prisma found in: ${project_dir}"
        DSA_ERRORS=$((DSA_ERRORS + 1))
        return 1
    fi

    echo "[database-schema-analyzer] Parsing: ${schema_file}"

    local models_json='{"schema_file":"'"${schema_file}"'","models":['
    local first_model=true
    DSA_MODELS_FOUND=0

    local in_model=false
    local model_name=""
    local fields_json=""
    local first_field=true
    local has_id=false
    local has_created_at=false
    local has_updated_at=false
    local field_count=0
    local relation_fields=""

    while IFS= read -r line; do
        # 空行・コメント行スキップ
        [[ -z "$line" ]] && continue
        [[ "$line" =~ ^[[:space:]]*// ]] && continue

        # モデル開始
        if [[ "$line" =~ ^[[:space:]]*model[[:space:]]+([A-Za-z_][A-Za-z0-9_]*)[[:space:]]*\{ ]]; then
            in_model=true
            model_name="${BASH_REMATCH[1]}"
            fields_json=""
            first_field=true
            has_id=false
            has_created_at=false
            has_updated_at=false
            field_count=0
            relation_fields=""
            continue
        fi

        # モデル終了
        if [[ "$in_model" == true && "$line" =~ ^[[:space:]]*\} ]]; then
            in_model=false
            [[ "$first_model" == "true" ]] && first_model=false || models_json+=","

            models_json+='{'
            models_json+='"name":"'"${model_name}"'",'
            models_json+='"fields":['"${fields_json}"'],'
            models_json+='"field_count":'"${field_count}"','
            models_json+='"has_id":'"${has_id}"','
            models_json+='"has_created_at":'"${has_created_at}"','
            models_json+='"has_updated_at":'"${has_updated_at}"
            models_json+='}'

            DSA_MODELS_FOUND=$((DSA_MODELS_FOUND + 1))

            # 個別モデル情報を保存
            local model_lower
            model_lower=$(echo "$model_name" | tr '[:upper:]' '[:lower:]')
            cat > "${DSA_STORAGE_DIR}/models/${model_lower}.json" <<MODEL_EOF
{
  "name": "${model_name}",
  "field_count": ${field_count},
  "has_id": ${has_id},
  "has_created_at": ${has_created_at},
  "has_updated_at": ${has_updated_at},
  "parsed_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
MODEL_EOF
            continue
        fi

        # フィールド解析
        if [[ "$in_model" == true ]]; then
            # @@index, @@unique, @@map 等のモデル属性はスキップ
            [[ "$line" =~ ^[[:space:]]*@@ ]] && continue

            # フィールド行: name Type @attribute...
            local _dsa_field_re="^[[:space:]]+([a-zA-Z_][a-zA-Z0-9_]*)[[:space:]]+([A-Za-z_][A-Za-z0-9_\[\]?]*)"
            if [[ "$line" =~ $_dsa_field_re ]]; then
                local field_name="${BASH_REMATCH[1]}"
                local field_type="${BASH_REMATCH[2]}"
                field_count=$((field_count + 1))

                # 属性抽出
                local is_id=false
                local is_unique=false
                local is_optional=false
                local is_relation=false
                local default_value=""
                local has_index=false

                [[ "$line" == *"@id"* ]] && is_id=true && has_id=true
                [[ "$line" == *"@unique"* ]] && is_unique=true
                [[ "$field_type" == *"?" ]] && is_optional=true
                [[ "$line" == *"@relation"* ]] && is_relation=true
                [[ "$line" == *"@default"* ]] && default_value="has_default"

                # 特殊フィールド検出
                case "$field_name" in
                    createdAt|created_at|createdat) has_created_at=true ;;
                    updatedAt|updated_at|updatedat) has_updated_at=true ;;
                esac

                # リレーションフィールドの型はモデル名
                local is_scalar=true
                case "$field_type" in
                    String|Int|Float|Boolean|DateTime|BigInt|Decimal|Bytes|Json)
                        is_scalar=true ;;
                    String?|Int?|Float?|Boolean?|DateTime?|BigInt?|Decimal?|Bytes?|Json?)
                        is_scalar=true ;;
                    *)
                        if [[ "$field_type" != *"[]" ]]; then
                            # 他モデルへの参照の可能性
                            is_scalar=false
                        else
                            is_scalar=false
                        fi
                        ;;
                esac

                [[ "$first_field" == "true" ]] && first_field=false || fields_json+=","
                fields_json+='{'
                fields_json+='"name":"'"${field_name}"'",'
                fields_json+='"type":"'"${field_type}"'",'
                fields_json+='"is_id":'"${is_id}"','
                fields_json+='"is_unique":'"${is_unique}"','
                fields_json+='"is_optional":'"${is_optional}"','
                fields_json+='"is_relation":'"${is_relation}"','
                fields_json+='"is_scalar":'"${is_scalar}"
                fields_json+='}'
            fi
        fi
    done < "$schema_file"

    models_json+='],"total_models":'"${DSA_MODELS_FOUND}"'}'
    echo "$models_json" > "${DSA_STORAGE_DIR}/models/schema-parsed.json"

    DSA_GENERATED=$((DSA_GENERATED + 1))
    echo "[database-schema-analyzer] Parsed ${DSA_MODELS_FOUND} models from schema"
    echo "$models_json"
}

# =============================================================================
# リレーション分析
# =============================================================================
_dsa_analyze_relations() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    [[ "$DSA_INITIALIZED" != "true" ]] && dsa_init

    local schema_file
    schema_file=$(_dsa_find_schema "$project_dir")
    [[ -z "$schema_file" ]] && echo "[database-schema-analyzer] No schema found" && return 1

    echo "[database-schema-analyzer] Analyzing relationships..."

    local relations_json='{"relations":['
    local first=true
    DSA_RELATIONS_FOUND=0

    # @relation属性を持つフィールドを抽出
    local current_model=""

    while IFS= read -r line; do
        [[ -z "$line" ]] && continue

        # モデル検出
        if [[ "$line" =~ ^[[:space:]]*model[[:space:]]+([A-Za-z_][A-Za-z0-9_]*)[[:space:]]*\{ ]]; then
            current_model="${BASH_REMATCH[1]}"
            continue
        fi
        [[ "$line" =~ ^[[:space:]]*\} ]] && current_model="" && continue
        [[ -z "$current_model" ]] && continue

        # @relationフィールド
        if [[ "$line" == *"@relation"* ]]; then
            local _dsa_rel_re="^[[:space:]]+([a-zA-Z_][a-zA-Z0-9_]*)[[:space:]]+([A-Za-z_][A-Za-z0-9_\[\]?]*)"
            if [[ "$line" =~ $_dsa_rel_re ]]; then
                local field_name="${BASH_REMATCH[1]}"
                local field_type="${BASH_REMATCH[2]}"

                # ターゲットモデル名
                local target_model="$field_type"
                target_model="${target_model%\?}"
                target_model="${target_model%\[\]}"

                # リレーション種別判定
                local relation_type="unknown"
                if [[ "$field_type" == *"[]" ]]; then
                    # 配列 = 1:N or N:M の "many" 側
                    # N:M判定: ターゲットモデルにも自分の配列があるか
                    local reverse_line
                    reverse_line=$(grep -E "^\s+\w+\s+${current_model}\[\]" "$schema_file" 2>/dev/null | head -1)
                    if [[ -n "$reverse_line" ]]; then
                        relation_type="many_to_many"
                    else
                        relation_type="one_to_many"
                    fi
                else
                    # 単数 = 1:1 or 1:N の "one" 側
                    # fields/references 解析
                    local _dsa_fk_re="fields:\[([^\]]+)\]"
                    if [[ "$line" =~ $_dsa_fk_re ]]; then
                        local fk_fields="${BASH_REMATCH[1]}"
                        # @unique付きの外部キー = 1:1
                        local fk_field
                        fk_field=$(echo "$fk_fields" | tr -d ' ')
                        if grep -qE "^\s+${fk_field}\s+.*@unique" "$schema_file" 2>/dev/null; then
                            relation_type="one_to_one"
                        else
                            relation_type="many_to_one"
                        fi
                    else
                        relation_type="many_to_one"
                    fi
                fi

                # 外部キー抽出
                local foreign_keys="[]"
                local _dsa_fk2_re="fields:\[([^\]]+)\]"
                if [[ "$line" =~ $_dsa_fk2_re ]]; then
                    local fk_raw="${BASH_REMATCH[1]}"
                    local fk_json=""
                    local fk_first=true
                    IFS=',' read -ra fk_arr <<< "$fk_raw"
                    for fk in "${fk_arr[@]}"; do
                        fk=$(echo "$fk" | tr -d ' ')
                        [[ -z "$fk" ]] && continue
                        [[ "$fk_first" == "true" ]] && fk_first=false || fk_json+=","
                        fk_json+="\"${fk}\""
                    done
                    foreign_keys="[${fk_json}]"
                fi

                # 参照先フィールド
                local references="[]"
                local _dsa_ref_re="references:\[([^\]]+)\]"
                if [[ "$line" =~ $_dsa_ref_re ]]; then
                    local ref_raw="${BASH_REMATCH[1]}"
                    local ref_json=""
                    local ref_first=true
                    IFS=',' read -ra ref_arr <<< "$ref_raw"
                    for ref in "${ref_arr[@]}"; do
                        ref=$(echo "$ref" | tr -d ' ')
                        [[ -z "$ref" ]] && continue
                        [[ "$ref_first" == "true" ]] && ref_first=false || ref_json+=","
                        ref_json+="\"${ref}\""
                    done
                    references="[${ref_json}]"
                fi

                [[ "$first" == "true" ]] && first=false || relations_json+=","
                relations_json+='{'
                relations_json+='"from_model":"'"${current_model}"'",'
                relations_json+='"to_model":"'"${target_model}"'",'
                relations_json+='"field_name":"'"${field_name}"'",'
                relations_json+='"relation_type":"'"${relation_type}"'",'
                relations_json+='"foreign_keys":'"${foreign_keys}"','
                relations_json+='"references":'"${references}"
                relations_json+='}'

                DSA_RELATIONS_FOUND=$((DSA_RELATIONS_FOUND + 1))
            fi
        fi

        # 暗黙的リレーション（@relation無しの外部モデル参照）
        local _dsa_implicit_re="^[[:space:]]+([a-zA-Z_]+)[[:space:]]+([A-Z][a-zA-Z0-9_]*)(\[\])?"
        if [[ "$line" =~ $_dsa_implicit_re && "$line" != *"@relation"* ]]; then
            local field_name="${BASH_REMATCH[1]}"
            local field_type="${BASH_REMATCH[2]}"
            local is_array="${BASH_REMATCH[3]}"

            # Prismaのスカラー型でないなら暗黙的リレーション
            case "$field_type" in
                String|Int|Float|Boolean|DateTime|BigInt|Decimal|Bytes|Json|Enum) continue ;;
            esac

            # 既にmodelとして定義されているかチェック
            if grep -qE "^model ${field_type} " "$schema_file" 2>/dev/null; then
                local relation_type="implicit"
                [[ -n "$is_array" ]] && relation_type="implicit_many"

                [[ "$first" == "true" ]] && first=false || relations_json+=","
                relations_json+='{"from_model":"'"${current_model}"'","to_model":"'"${field_type}"'","field_name":"'"${field_name}"'","relation_type":"'"${relation_type}"'","foreign_keys":[],"references":[]}'
                DSA_RELATIONS_FOUND=$((DSA_RELATIONS_FOUND + 1))
            fi
        fi
    done < "$schema_file"

    relations_json+='],"total_relations":'"${DSA_RELATIONS_FOUND}"'}'
    echo "$relations_json" > "${DSA_STORAGE_DIR}/relations/analyzed.json"

    DSA_GENERATED=$((DSA_GENERATED + 1))
    echo "[database-schema-analyzer] Found ${DSA_RELATIONS_FOUND} relationships"
    echo "$relations_json"
}

# =============================================================================
# スキーマ問題検出
# =============================================================================
_dsa_detect_issues() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    [[ "$DSA_INITIALIZED" != "true" ]] && dsa_init

    local schema_file
    schema_file=$(_dsa_find_schema "$project_dir")
    [[ -z "$schema_file" ]] && return 1

    # パース済みでなければパース
    [[ ! -f "${DSA_STORAGE_DIR}/models/schema-parsed.json" ]] && _dsa_parse_schema "$project_dir" >/dev/null

    echo "[database-schema-analyzer] Detecting schema issues..."

    local issues_json='{"issues":['
    local first=true
    DSA_ISSUES_FOUND=0

    local current_model=""
    local model_fields=""
    local model_has_index=false
    local model_has_created_at=false
    local model_has_updated_at=false
    local model_has_deleted_at=false
    local model_field_count=0
    local model_fk_fields=""

    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        [[ "$line" =~ ^[[:space:]]*// ]] && continue

        if [[ "$line" =~ ^[[:space:]]*model[[:space:]]+([A-Za-z_][A-Za-z0-9_]*)[[:space:]]*\{ ]]; then
            # 前のモデルの問題チェック
            if [[ -n "$current_model" ]]; then
                _dsa_check_model_issues
            fi
            current_model="${BASH_REMATCH[1]}"
            model_fields=""
            model_has_index=false
            model_has_created_at=false
            model_has_updated_at=false
            model_has_deleted_at=false
            model_field_count=0
            model_fk_fields=""
            continue
        fi

        if [[ "$line" =~ ^[[:space:]]*\} ]] && [[ -n "$current_model" ]]; then
            _dsa_check_model_issues
            current_model=""
            continue
        fi

        [[ -z "$current_model" ]] && continue

        # @@index, @@unique検出
        [[ "$line" == *"@@index"* || "$line" == *"@@unique"* ]] && model_has_index=true

        # フィールド解析
        local _dsa_fld_re="^[[:space:]]+([a-zA-Z_][a-zA-Z0-9_]*)[[:space:]]+([A-Za-z_][A-Za-z0-9_\[\]?]*)"
        if [[ "$line" =~ $_dsa_fld_re ]]; then
            local f_name="${BASH_REMATCH[1]}"
            local f_type="${BASH_REMATCH[2]}"
            model_field_count=$((model_field_count + 1))
            model_fields+="${f_name}:${f_type},"

            case "$f_name" in
                createdAt|created_at) model_has_created_at=true ;;
                updatedAt|updated_at) model_has_updated_at=true ;;
                deletedAt|deleted_at) model_has_deleted_at=true ;;
            esac

            # 外部キー検出（Idで終わるフィールド）
            if [[ "$f_name" =~ Id$ && "$f_type" != *"[]" ]]; then
                model_fk_fields+="${f_name},"
            fi

            # 命名規約チェック: snake_case vs camelCase の混在
            if [[ "$f_name" == *"_"* ]]; then
                # snake_case フィールド
                local camel_count
                camel_count=$(echo "$model_fields" | grep -oE '[a-z][A-Z]' | wc -l | tr -d ' ')
                if [[ $camel_count -gt 0 ]]; then
                    [[ "$first" == "true" ]] && first=false || issues_json+=","
                    issues_json+='{"model":"'"${current_model}"'","field":"'"${f_name}"'","severity":"warning","type":"naming_inconsistency","message":"snake_caseとcamelCaseが混在しています"}'
                    DSA_ISSUES_FOUND=$((DSA_ISSUES_FOUND + 1))
                fi
            fi

            # 型チェック: String で金額を扱っていそうなフィールド
            if [[ "$f_type" == "String" || "$f_type" == "String?" ]]; then
                case "$f_name" in
                    *price*|*amount*|*cost*|*total*|*balance*|*fee*)
                        [[ "$first" == "true" ]] && first=false || issues_json+=","
                        issues_json+='{"model":"'"${current_model}"'","field":"'"${f_name}"'","severity":"error","type":"wrong_type","message":"金額フィールドにString型を使用しています。Decimal型を推奨"}'
                        DSA_ISSUES_FOUND=$((DSA_ISSUES_FOUND + 1))
                        ;;
                esac
            fi

            # Int で ID を扱う場合の注意
            if [[ "$f_type" == "Int" && ("$f_name" == "id" || "$f_name" == *"Id") ]]; then
                [[ "$line" != *"@id"* && "$line" != *"autoincrement"* ]] || continue
                # Int ID は衝突リスク → cuid/uuid推奨
            fi
        fi
    done < "$schema_file"

    issues_json+='],"total_issues":'"${DSA_ISSUES_FOUND}"'}'
    echo "$issues_json" > "${DSA_STORAGE_DIR}/reports/issues.json"

    DSA_GENERATED=$((DSA_GENERATED + 1))
    echo "[database-schema-analyzer] Found ${DSA_ISSUES_FOUND} issue(s)"
    echo "$issues_json"
}

# =============================================================================
# Internal: モデルレベル問題チェック（_dsa_detect_issues内で呼ばれる）
# =============================================================================
_dsa_check_model_issues() {
    # createdAt/updatedAt の欠如
    if [[ "$model_has_created_at" == false ]]; then
        [[ "$first" == "true" ]] && first=false || issues_json+=","
        issues_json+='{"model":"'"${current_model}"'","field":null,"severity":"warning","type":"missing_timestamp","message":"createdAtフィールドがありません。レコード作成日時の追跡を推奨"}'
        DSA_ISSUES_FOUND=$((DSA_ISSUES_FOUND + 1))
    fi
    if [[ "$model_has_updated_at" == false ]]; then
        [[ "$first" == "true" ]] && first=false || issues_json+=","
        issues_json+='{"model":"'"${current_model}"'","field":null,"severity":"warning","type":"missing_timestamp","message":"updatedAtフィールドがありません。レコード更新日時の追跡を推奨"}'
        DSA_ISSUES_FOUND=$((DSA_ISSUES_FOUND + 1))
    fi

    # インデックスなしの外部キー
    if [[ -n "$model_fk_fields" && "$model_has_index" == false ]]; then
        [[ "$first" == "true" ]] && first=false || issues_json+=","
        issues_json+='{"model":"'"${current_model}"'","field":"'"${model_fk_fields%,}"'","severity":"error","type":"missing_index","message":"外部キーにインデックスがありません。JOINパフォーマンスが低下します"}'
        DSA_ISSUES_FOUND=$((DSA_ISSUES_FOUND + 1))
    fi

    # 大きすぎるモデル（20フィールド以上）
    if [[ $model_field_count -gt 20 ]]; then
        [[ "$first" == "true" ]] && first=false || issues_json+=","
        issues_json+='{"model":"'"${current_model}"'","field":null,"severity":"info","type":"large_model","message":"'"${model_field_count}"'フィールドあります。テーブル分割を検討してください"}'
        DSA_ISSUES_FOUND=$((DSA_ISSUES_FOUND + 1))
    fi
}

# =============================================================================
# スキーマ改善提案
# =============================================================================
_dsa_suggest_improvements() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    [[ "$DSA_INITIALIZED" != "true" ]] && dsa_init

    local schema_file
    schema_file=$(_dsa_find_schema "$project_dir")
    [[ -z "$schema_file" ]] && return 1

    echo "[database-schema-analyzer] Generating improvement suggestions..."

    local suggestions_json='{"suggestions":['
    local first=true
    DSA_SUGGESTIONS=0

    # 問題検出結果を元に提案
    [[ ! -f "${DSA_STORAGE_DIR}/reports/issues.json" ]] && _dsa_detect_issues "$project_dir" >/dev/null

    # ソフトデリートの提案
    local model_count=0
    local soft_delete_count=0
    while IFS= read -r line; do
        if [[ "$line" =~ ^[[:space:]]*model[[:space:]] ]]; then
            model_count=$((model_count + 1))
        fi
        if [[ "$line" == *"deletedAt"* || "$line" == *"deleted_at"* || "$line" == *"isDeleted"* ]]; then
            soft_delete_count=$((soft_delete_count + 1))
        fi
    done < "$schema_file"

    if [[ $model_count -gt 3 && $soft_delete_count -eq 0 ]]; then
        [[ "$first" == "true" ]] && first=false || suggestions_json+=","
        suggestions_json+='{"priority":"medium","type":"soft_delete","message":"ソフトデリート（deletedAt DateTime?）の導入を推奨。データ復旧と監査証跡に有効","affected_models":"all"}'
        DSA_SUGGESTIONS=$((DSA_SUGGESTIONS + 1))
    fi

    # フルテキストインデックスの提案
    local string_fields_count
    string_fields_count=$(grep -cE '^\s+\w+\s+String(\?)?(\s|$)' "$schema_file" 2>/dev/null || echo "0")
    local fulltext_count
    fulltext_count=$(grep -cE '@@fulltext' "$schema_file" 2>/dev/null || echo "0")
    if [[ $string_fields_count -gt 5 && $fulltext_count -eq 0 ]]; then
        [[ "$first" == "true" ]] && first=false || suggestions_json+=","
        suggestions_json+='{"priority":"low","type":"fulltext_index","message":"テキストフィールドが多数あります。全文検索インデックス(@@fulltext)の追加を検討","affected_models":"multiple"}'
        DSA_SUGGESTIONS=$((DSA_SUGGESTIONS + 1))
    fi

    # Enum型の提案（status/type/roleなどの文字列フィールド）
    while IFS= read -r line; do
        local _dsa_enum_re="^[[:space:]]+([a-zA-Z_]*(?:status|type|role|category|state|kind|level|priority)[a-zA-Z_]*)[[:space:]]+String"
        if [[ "$line" =~ ^[[:space:]]+([a-zA-Z_]*(status|type|role|category|state|kind|level|priority)[a-zA-Z_]*)[[:space:]]+String ]]; then
            local field="${BASH_REMATCH[1]}"
            [[ "$first" == "true" ]] && first=false || suggestions_json+=","
            suggestions_json+='{"priority":"medium","type":"use_enum","message":"'"${field}"' をString型からEnum型に変更を推奨。型安全性とバリデーションが向上","affected_field":"'"${field}"'"}'
            DSA_SUGGESTIONS=$((DSA_SUGGESTIONS + 1))
        fi
    done < "$schema_file"

    # 複合ユニーク制約の提案
    while IFS= read -r line; do
        if [[ "$line" =~ ^[[:space:]]*model[[:space:]]+([A-Za-z_]+) ]]; then
            local model="${BASH_REMATCH[1]}"
            # 外部キーが2つ以上あるモデルで@@uniqueがない場合
            local fk_count
            fk_count=$(grep -A 50 "model ${model} {" "$schema_file" 2>/dev/null | grep -m1 "^}" | head -1; grep -B 999 "^}" "$schema_file" 2>/dev/null | grep -cE "^\s+\w+Id\s+" || echo "0")
        fi
    done < "$schema_file"

    # @updatedAt の使用推奨
    local updated_at_count
    updated_at_count=$(grep -cE '@updatedAt' "$schema_file" 2>/dev/null || echo "0")
    local updated_field_count
    updated_field_count=$(grep -cE '^\s+(updatedAt|updated_at)\s+DateTime' "$schema_file" 2>/dev/null || echo "0")
    if [[ $updated_field_count -gt $updated_at_count ]]; then
        [[ "$first" == "true" ]] && first=false || suggestions_json+=","
        suggestions_json+='{"priority":"high","type":"updatedAt_annotation","message":"updatedAtフィールドに@updatedAt属性を追加してください。Prismaが自動更新します","affected_models":"multiple"}'
        DSA_SUGGESTIONS=$((DSA_SUGGESTIONS + 1))
    fi

    # map() によるテーブル名のカスタマイズ提案
    local map_count
    map_count=$(grep -cE '@@map\(' "$schema_file" 2>/dev/null || echo "0")
    if [[ $model_count -gt 5 && $map_count -eq 0 ]]; then
        [[ "$first" == "true" ]] && first=false || suggestions_json+=","
        suggestions_json+='{"priority":"low","type":"table_naming","message":"@@map()でテーブル名をsnake_caseに統一することを推奨（DB規約準拠）","affected_models":"all"}'
        DSA_SUGGESTIONS=$((DSA_SUGGESTIONS + 1))
    fi

    suggestions_json+='],"total_suggestions":'"${DSA_SUGGESTIONS}"'}'
    echo "$suggestions_json" > "${DSA_STORAGE_DIR}/reports/suggestions.json"

    DSA_GENERATED=$((DSA_GENERATED + 1))
    echo "[database-schema-analyzer] Generated ${DSA_SUGGESTIONS} improvement suggestions"
    echo "$suggestions_json"
}

# =============================================================================
# テキストベースER図生成
# =============================================================================
_dsa_generate_er_diagram() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    [[ "$DSA_INITIALIZED" != "true" ]] && dsa_init

    local schema_file
    schema_file=$(_dsa_find_schema "$project_dir")
    [[ -z "$schema_file" ]] && return 1

    # リレーション解析済みでなければ実行
    [[ ! -f "${DSA_STORAGE_DIR}/relations/analyzed.json" ]] && _dsa_analyze_relations "$project_dir" >/dev/null
    [[ ! -f "${DSA_STORAGE_DIR}/models/schema-parsed.json" ]] && _dsa_parse_schema "$project_dir" >/dev/null

    echo "[database-schema-analyzer] Generating ER diagram..."

    local er_file="${DSA_STORAGE_DIR}/reports/er-diagram.md"
    local mermaid="erDiagram\n"

    # モデルとフィールドをMermaid ER図に変換
    local current_model=""
    local in_model=false

    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        [[ "$line" =~ ^[[:space:]]*// ]] && continue

        if [[ "$line" =~ ^[[:space:]]*model[[:space:]]+([A-Za-z_][A-Za-z0-9_]*)[[:space:]]*\{ ]]; then
            current_model="${BASH_REMATCH[1]}"
            in_model=true
            mermaid+="    ${current_model} {\n"
            continue
        fi

        if [[ "$in_model" == true && "$line" =~ ^[[:space:]]*\} ]]; then
            mermaid+="    }\n"
            in_model=false
            current_model=""
            continue
        fi

        if [[ "$in_model" == true ]]; then
            [[ "$line" =~ ^[[:space:]]*@@ ]] && continue
            local _dsa_er_re="^[[:space:]]+([a-zA-Z_][a-zA-Z0-9_]*)[[:space:]]+([A-Za-z_][A-Za-z0-9_\[\]?]*)"
            if [[ "$line" =~ $_dsa_er_re ]]; then
                local f_name="${BASH_REMATCH[1]}"
                local f_type="${BASH_REMATCH[2]}"
                # リレーションフィールドはスキップ（関係線で表現）
                local base_type="${f_type%\?}"
                base_type="${base_type%\[\]}"
                case "$base_type" in
                    String|Int|Float|Boolean|DateTime|BigInt|Decimal|Bytes|Json)
                        local er_type="$base_type"
                        local pk_marker=""
                        [[ "$line" == *"@id"* ]] && pk_marker=" PK"
                        [[ "$line" == *"@unique"* ]] && pk_marker=" UK"
                        mermaid+="        ${er_type} ${f_name}${pk_marker}\n"
                        ;;
                esac
            fi
        fi
    done < "$schema_file"

    # リレーションの線を追加
    if [[ -f "${DSA_STORAGE_DIR}/relations/analyzed.json" ]]; then
        while IFS= read -r rel_entry; do
            [[ -z "$rel_entry" ]] && continue
            local from_m
            from_m=$(echo "$rel_entry" | grep -oE '"from_model":"[^"]*"' | sed 's/"from_model":"//;s/"//')
            local to_m
            to_m=$(echo "$rel_entry" | grep -oE '"to_model":"[^"]*"' | sed 's/"to_model":"//;s/"//')
            local rel_type
            rel_type=$(echo "$rel_entry" | grep -oE '"relation_type":"[^"]*"' | sed 's/"relation_type":"//;s/"//')
            [[ -z "$from_m" || -z "$to_m" ]] && continue

            case "$rel_type" in
                one_to_one)
                    mermaid+="    ${from_m} ||--|| ${to_m} : \"\"\n"
                    ;;
                one_to_many)
                    mermaid+="    ${from_m} ||--o{ ${to_m} : \"\"\n"
                    ;;
                many_to_one)
                    mermaid+="    ${from_m} }o--|| ${to_m} : \"\"\n"
                    ;;
                many_to_many)
                    mermaid+="    ${from_m} }o--o{ ${to_m} : \"\"\n"
                    ;;
                implicit|implicit_many)
                    mermaid+="    ${from_m} ..--.. ${to_m} : \"implicit\"\n"
                    ;;
            esac
        done < <(grep -oE '\{[^}]+\}' "${DSA_STORAGE_DIR}/relations/analyzed.json" 2>/dev/null)
    fi

    {
        echo "# Database ER Diagram"
        echo ""
        echo '```mermaid'
        echo -e "$mermaid"
        echo '```'
        echo ""
        echo "Generated: $(date -u +%Y-%m-%dT%H:%M:%SZ)"
        echo "Models: ${DSA_MODELS_FOUND} | Relations: ${DSA_RELATIONS_FOUND}"
    } > "$er_file"

    DSA_GENERATED=$((DSA_GENERATED + 1))
    echo "[database-schema-analyzer] ER diagram generated: ${er_file}"
}

# =============================================================================
# マイグレーション安全性チェック
# =============================================================================
_dsa_check_migration_safety() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local migration_dir="${2:-}"
    [[ "$DSA_INITIALIZED" != "true" ]] && dsa_init

    echo "[database-schema-analyzer] Checking migration safety..."

    local safety_json='{"migration_checks":['
    local first=true
    local danger_count=0

    # Prisma migration ディレクトリを検索
    if [[ -z "$migration_dir" ]]; then
        for candidate in "${project_dir}/prisma/migrations" "${project_dir}/src/prisma/migrations"; do
            [[ -d "$candidate" ]] && migration_dir="$candidate" && break
        done
    fi

    # 最新のマイグレーションを検査
    if [[ -n "$migration_dir" && -d "$migration_dir" ]]; then
        local latest_migration
        latest_migration=$(find "$migration_dir" -name "migration.sql" 2>/dev/null | sort | tail -1)

        if [[ -n "$latest_migration" && -f "$latest_migration" ]]; then
            local migration_name
            migration_name=$(basename "$(dirname "$latest_migration")")

            # 危険な操作検出
            # 1. DROP TABLE
            local drop_tables
            drop_tables=$(grep -ciE "DROP TABLE" "$latest_migration" 2>/dev/null || echo "0")
            if [[ $drop_tables -gt 0 ]]; then
                [[ "$first" == "true" ]] && first=false || safety_json+=","
                safety_json+='{"severity":"critical","type":"drop_table","count":'"${drop_tables}"',"migration":"'"${migration_name}"'","message":"テーブル削除が含まれています。データが失われます"}'
                danger_count=$((danger_count + 1))
            fi

            # 2. DROP COLUMN
            local drop_columns
            drop_columns=$(grep -ciE "DROP COLUMN|ALTER.*DROP" "$latest_migration" 2>/dev/null || echo "0")
            if [[ $drop_columns -gt 0 ]]; then
                [[ "$first" == "true" ]] && first=false || safety_json+=","
                safety_json+='{"severity":"critical","type":"drop_column","count":'"${drop_columns}"',"migration":"'"${migration_name}"'","message":"カラム削除が含まれています。データが失われます"}'
                danger_count=$((danger_count + 1))
            fi

            # 3. NOT NULL without default
            local not_null_no_default
            not_null_no_default=$(grep -cE "NOT NULL(?!.*DEFAULT)" "$latest_migration" 2>/dev/null || echo "0")
            if [[ $not_null_no_default -gt 0 ]]; then
                [[ "$first" == "true" ]] && first=false || safety_json+=","
                safety_json+='{"severity":"high","type":"not_null_no_default","count":'"${not_null_no_default}"',"migration":"'"${migration_name}"'","message":"NOT NULLカラムの追加にDEFAULT値がありません。既存データでエラーになります"}'
                danger_count=$((danger_count + 1))
            fi

            # 4. RENAME TABLE
            local renames
            renames=$(grep -ciE "RENAME|ALTER TABLE.*RENAME" "$latest_migration" 2>/dev/null || echo "0")
            if [[ $renames -gt 0 ]]; then
                [[ "$first" == "true" ]] && first=false || safety_json+=","
                safety_json+='{"severity":"high","type":"rename","count":'"${renames}"',"migration":"'"${migration_name}"'","message":"テーブル/カラムのリネームが含まれています。アプリケーションコードの更新が必要"}'
                danger_count=$((danger_count + 1))
            fi

            # 5. 型変更
            local type_changes
            type_changes=$(grep -ciE "ALTER.*TYPE|MODIFY.*COLUMN" "$latest_migration" 2>/dev/null || echo "0")
            if [[ $type_changes -gt 0 ]]; then
                [[ "$first" == "true" ]] && first=false || safety_json+=","
                safety_json+='{"severity":"medium","type":"type_change","count":'"${type_changes}"',"migration":"'"${migration_name}"'","message":"カラムの型変更が含まれています。データの暗黙的変換に注意"}'
                danger_count=$((danger_count + 1))
            fi

            # 6. 大きなインデックス追加（ロック注意）
            local index_adds
            index_adds=$(grep -ciE "CREATE.*INDEX" "$latest_migration" 2>/dev/null || echo "0")
            if [[ $index_adds -gt 2 ]]; then
                [[ "$first" == "true" ]] && first=false || safety_json+=","
                safety_json+='{"severity":"medium","type":"multiple_indexes","count":'"${index_adds}"',"migration":"'"${migration_name}"'","message":"複数インデックスの同時追加。大きなテーブルではCONCURRENTLYオプションを検討"}'
                danger_count=$((danger_count + 1))
            fi

            if [[ $danger_count -eq 0 ]]; then
                [[ "$first" == "true" ]] && first=false || safety_json+=","
                safety_json+='{"severity":"safe","type":"no_issues","migration":"'"${migration_name}"'","message":"危険な操作は検出されませんでした"}'
            fi
        fi
    fi

    # schema.prisma の diff ベースチェック（git差分）
    local schema_file
    schema_file=$(_dsa_find_schema "$project_dir")
    if [[ -n "$schema_file" && -d "${project_dir}/.git" ]]; then
        local schema_diff
        schema_diff=$(cd "$project_dir" && git diff -- "${schema_file#${project_dir}/}" 2>/dev/null)

        if [[ -n "$schema_diff" ]]; then
            # 削除されたフィールド
            local removed_fields
            removed_fields=$(echo "$schema_diff" | grep -cE '^-[[:space:]]+[a-zA-Z_]+[[:space:]]+' || echo "0")
            if [[ $removed_fields -gt 0 ]]; then
                [[ "$first" == "true" ]] && first=false || safety_json+=","
                safety_json+='{"severity":"high","type":"schema_field_removed","count":'"${removed_fields}"',"message":"スキーマからフィールドが削除されています。マイグレーション実行前にデータバックアップを"}'
                danger_count=$((danger_count + 1))
            fi

            # 削除されたモデル
            local removed_models
            removed_models=$(echo "$schema_diff" | grep -cE '^-model ' || echo "0")
            if [[ $removed_models -gt 0 ]]; then
                [[ "$first" == "true" ]] && first=false || safety_json+=","
                safety_json+='{"severity":"critical","type":"schema_model_removed","count":'"${removed_models}"',"message":"スキーマからモデルが削除されています。対応するテーブルとデータが失われます"}'
                danger_count=$((danger_count + 1))
            fi
        fi
    fi

    safety_json+='],"danger_level":'"${danger_count}"',"safe":'"$([ $danger_count -eq 0 ] && echo "true" || echo "false")"'}'
    echo "$safety_json" > "${DSA_STORAGE_DIR}/reports/migration-safety.json"

    DSA_GENERATED=$((DSA_GENERATED + 1))
    if [[ $danger_count -gt 0 ]]; then
        echo "[database-schema-analyzer] Migration safety: ${danger_count} potential danger(s) detected"
    else
        echo "[database-schema-analyzer] Migration safety: SAFE"
    fi
    echo "$safety_json"
}

# =============================================================================
# 全解析実行
# =============================================================================
dsa_build_analysis() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    echo "[database-schema-analyzer] Building full schema analysis..."
    _dsa_parse_schema "$project_dir" >/dev/null
    _dsa_analyze_relations "$project_dir" >/dev/null
    _dsa_detect_issues "$project_dir" >/dev/null
    _dsa_suggest_improvements "$project_dir" >/dev/null
    _dsa_generate_er_diagram "$project_dir" >/dev/null
    _dsa_check_migration_safety "$project_dir" >/dev/null
    echo "[database-schema-analyzer] Complete: ${DSA_MODELS_FOUND} models, ${DSA_RELATIONS_FOUND} relations, ${DSA_ISSUES_FOUND} issues, ${DSA_SUGGESTIONS} suggestions"
}

# =============================================================================
# プロンプト注入
# =============================================================================
dsa_inject_context() {
    local prompt="${1:-}"
    local project_dir="${2:-${PROJECT_DIR:-./output}}"

    local schema_data=""
    [[ -f "${DSA_STORAGE_DIR}/models/schema-parsed.json" ]] && schema_data=$(cat "${DSA_STORAGE_DIR}/models/schema-parsed.json" 2>/dev/null)
    local relations_data=""
    [[ -f "${DSA_STORAGE_DIR}/relations/analyzed.json" ]] && relations_data=$(cat "${DSA_STORAGE_DIR}/relations/analyzed.json" 2>/dev/null)

    cat <<INJECTION

## [Database Schema Analyzer] スキーマコンテキスト

### パース済みスキーマ:
${schema_data:-No schema parsed yet}

### リレーション:
${relations_data:-No relations analyzed yet}

### ルール:
1. **モデル追加時**: createdAt/updatedAtフィールドを必ず含める
2. **外部キー**: 全外部キーにインデックスを追加（@@index）
3. **命名規約**: camelCase統一（PrismaのPSL規約準拠）
4. **金額フィールド**: String型ではなくDecimal型を使用
5. **ステータスフィールド**: String型ではなくEnum型を定義
6. **リレーション**: @relationで明示的に外部キーとreferenceを指定
7. **マイグレーション**: 破壊的変更（DROP/RENAME）は段階的に実施
INJECTION

    echo "$prompt"
}

# =============================================================================
# レポート & スコア
# =============================================================================
dsa_report() {
    echo -e "\n  ${BOLD:-}=== database-schema-analyzer v${DSA_VERSION} ===${NC:-}"
    echo -e "  検出モデル数       : ${DSA_MODELS_FOUND}"
    echo -e "  リレーション数     : ${DSA_RELATIONS_FOUND}"
    echo -e "  問題検出           : ${DSA_ISSUES_FOUND}"
    echo -e "  改善提案           : ${DSA_SUGGESTIONS}"
    echo -e "  生成ファイル       : ${DSA_GENERATED}"
    echo -e "  エラー             : ${DSA_ERRORS}"
}

dsa_score() {
    if [[ ${DSA_MODELS_FOUND} -gt 0 ]] && [[ ${DSA_ERRORS} -eq 0 ]]; then
        if [[ ${DSA_ISSUES_FOUND} -eq 0 ]]; then
            echo "95"
        elif [[ ${DSA_ISSUES_FOUND} -le 3 ]]; then
            echo "85"
        elif [[ ${DSA_ISSUES_FOUND} -le 8 ]]; then
            echo "70"
        else
            echo "60"
        fi
    elif [[ ${DSA_MODELS_FOUND} -gt 0 ]]; then
        echo "55"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "database-schema-analyzer" --version "212.0" \
        --description "Prismaスキーマ解析×リレーション分析×問題検出×ER図生成×マイグレーション安全性" \
        --init "dsa_init" --report "dsa_report" --score "dsa_score" \
        --enable-var "ENABLE_DATABASE_SCHEMA_ANALYZER" \
        --cli-flags "--database-schema-analyzer:--no-database-schema-analyzer"
fi

# v2003.1: source時のexit codeを確実に0にする
true
