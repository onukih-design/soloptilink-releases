#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v11.0 - Checkpoint & Resume System
# =============================================================================
# v8.0: Saves state after each DAG stage so work is never lost.
# v11.0: Differential backups, auto-rotation (24h / max 20),
#         gzip compression, checkpoint diff, export/import
# Usage: source lib/checkpoint.sh
# =============================================================================

[[ -n "${_CHECKPOINT_LOADED:-}" ]] && return 0
_CHECKPOINT_LOADED=1

# Color codes
readonly _CKP_GREEN='\033[0;32m'  _CKP_YELLOW='\033[0;33m'  _CKP_RED='\033[0;31m'
readonly _CKP_CYAN='\033[0;36m'   _CKP_BOLD='\033[1m'        _CKP_NC='\033[0m'

CHECKPOINT_BASE_DIR="docs/chain-logs/checkpoints"

# v11.0: Configuration
CHECKPOINT_MAX_COUNT="${CHECKPOINT_MAX_COUNT:-20}"
CHECKPOINT_MAX_AGE_HOURS="${CHECKPOINT_MAX_AGE_HOURS:-24}"
CHECKPOINT_COMPRESS="${CHECKPOINT_COMPRESS:-true}"

# --- Helper: _checkpoint_log(level, message) --------------------------------

_checkpoint_log() {
  local level="$1" message="$2" ts
  ts="$(date '+%Y-%m-%d %H:%M:%S')"
  case "$level" in
    INFO)  printf "${_CKP_CYAN}[CHECKPOINT %s]${_CKP_NC} %s\n"   "$ts" "$message" ;;
    OK)    printf "${_CKP_GREEN}[CHECKPOINT %s]${_CKP_NC} %s\n"   "$ts" "$message" ;;
    WARN)  printf "${_CKP_YELLOW}[CHECKPOINT %s]${_CKP_NC} %s\n"  "$ts" "$message" ;;
    ERROR) printf "${_CKP_RED}[CHECKPOINT %s]${_CKP_NC} %s\n"     "$ts" "$message" ;;
    *)     printf "[CHECKPOINT %s] %s\n" "$ts" "$message" ;;
  esac
}

# --- checkpoint_init(session_id) --------------------------------------------

checkpoint_init() {
  local session_id="$1"
  [[ -z "$session_id" ]] && { _checkpoint_log ERROR "session_id is required"; return 1; }
  local ckp_dir="${CHECKPOINT_BASE_DIR}/${session_id}"
  mkdir -p "$ckp_dir" "${ckp_dir}/diffs" 2>/dev/null
  _checkpoint_log OK "Checkpoint directory initialised: ${ckp_dir} (v11.0: compress=${CHECKPOINT_COMPRESS}, max=${CHECKPOINT_MAX_COUNT})"
}

# --- checkpoint_save(session_id, stage_name, metadata) ----------------------

checkpoint_save() {
  local session_id="$1" stage_name="$2" metadata="$3"
  [[ -z "$session_id" || -z "$stage_name" ]] && {
    _checkpoint_log ERROR "Usage: checkpoint_save <session_id> <stage_name> [metadata]"; return 1
  }

  local ckp_dir="${CHECKPOINT_BASE_DIR}/${session_id}"
  mkdir -p "$ckp_dir" 2>/dev/null

  # Git commit current state
  git add -A 2>/dev/null
  git commit -m "checkpoint: ${session_id}/${stage_name}" --allow-empty -q 2>/dev/null
  local rev_hash; rev_hash="$(git rev-parse HEAD 2>/dev/null || echo 'no-git')"

  # Collect modified files
  local files_modified
  files_modified="$(git diff --name-only HEAD~1 HEAD 2>/dev/null | head -50 | paste -sd ',' -)"
  [[ -z "$files_modified" ]] && files_modified="none"

  # Write metadata JSON
  local ts; ts="$(date -u '+%Y-%m-%dT%H:%M:%SZ')"
  local meta_file="${ckp_dir}/${stage_name}.json"
  cat > "$meta_file" <<ENDJSON
{
  "stage": "${stage_name}",
  "timestamp": "${ts}",
  "rev_hash": "${rev_hash}",
  "dag_status": "${DAG_STATUS:-unknown}",
  "files_modified": "${files_modified}",
  "validation_results": "${VALIDATION_RESULTS:-none}",
  "extra": ${metadata:-"{}"}
}
ENDJSON

  # v11.0: Save differential backup
  _checkpoint_save_differential "$session_id" "$stage_name" "$rev_hash"

  # v11.0: Compress if enabled
  if [[ "$CHECKPOINT_COMPRESS" == "true" ]] && command -v gzip &>/dev/null; then
    _checkpoint_compress_meta "$meta_file"
  fi

  # v11.0: Auto-rotation
  _checkpoint_auto_rotate "$session_id"

  _checkpoint_log OK "Checkpoint saved: ${stage_name}  (rev ${rev_hash:0:8})"
}

# --- checkpoint_restore(session_id, stage_name) -----------------------------

checkpoint_restore() {
  local session_id="$1" stage_name="$2"
  local meta_file="${CHECKPOINT_BASE_DIR}/${session_id}/${stage_name}.json"

  # v11.0: Check for compressed version
  if [[ ! -f "$meta_file" && -f "${meta_file}.gz" ]]; then
    _checkpoint_decompress_meta "${meta_file}.gz"
  fi

  [[ ! -f "$meta_file" ]] && { _checkpoint_log ERROR "Checkpoint not found: ${meta_file}"; return 1; }

  local rev_hash; rev_hash="$(grep '"rev_hash"' "$meta_file" | sed 's/.*: *"\([^"]*\)".*/\1/')"
  if [[ "$rev_hash" != "no-git" && -n "$rev_hash" ]]; then
    _checkpoint_log INFO "Restoring git state to ${rev_hash:0:8} ..."
    git checkout "$rev_hash" -q 2>/dev/null
  fi

  # Export DAG_STATUS so callers can resume
  local dag_status; dag_status="$(grep '"dag_status"' "$meta_file" | sed 's/.*: *"\([^"]*\)".*/\1/')"
  export DAG_STATUS="$dag_status"

  _checkpoint_log OK "Restored checkpoint: ${stage_name}"
  cat "$meta_file"
}

# --- checkpoint_list(session_id) --------------------------------------------

checkpoint_list() {
  local session_id="$1"
  local ckp_dir="${CHECKPOINT_BASE_DIR}/${session_id}"
  [[ ! -d "$ckp_dir" ]] && { _checkpoint_log WARN "No checkpoints for session: ${session_id}"; return 1; }

  printf "${_CKP_BOLD}%-30s %-26s %-12s %-8s${_CKP_NC}\n" "STAGE" "TIMESTAMP" "REV" "SIZE"
  printf '%s\n' "--------------------------------------------------------------------------"
  for f in "$ckp_dir"/*.json "$ckp_dir"/*.json.gz; do
    [[ -f "$f" ]] || continue

    local display_file="$f"
    local compressed=false
    if [[ "$f" == *.gz ]]; then
      compressed=true
      # Decompress temporarily for reading
      local tmp_json="${f%.gz}"
      gzip -dk "$f" 2>/dev/null || continue
      display_file="$tmp_json"
    fi

    local stage ts rev fsize
    stage="$(grep '"stage"' "$display_file"    | sed 's/.*: *"\([^"]*\)".*/\1/')"
    ts="$(grep '"timestamp"' "$display_file"   | sed 's/.*: *"\([^"]*\)".*/\1/')"
    rev="$(grep '"rev_hash"' "$display_file"   | sed 's/.*: *"\([^"]*\)".*/\1/')"
    fsize="$(du -sk "$f" 2>/dev/null | cut -f1)"
    local size_display="${fsize}K"
    [[ "$compressed" == "true" ]] && size_display="${fsize}K(gz)"
    printf "%-30s %-26s %-12s %-8s\n" "$stage" "$ts" "${rev:0:8}" "$size_display"

    # Cleanup temp decompressed file
    [[ "$compressed" == "true" ]] && rm -f "$display_file" 2>/dev/null
  done
}

# --- checkpoint_latest() ---------------------------------------------------

checkpoint_latest() {
  local latest_file="" latest_ts="0"
  for f in "${CHECKPOINT_BASE_DIR}"/*/*.json "${CHECKPOINT_BASE_DIR}"/*/*.json.gz; do
    [[ -f "$f" ]] || continue

    local check_file="$f"
    local is_gz=false
    if [[ "$f" == *.gz ]]; then
      is_gz=true
      check_file="${f%.gz}"
      gzip -dk "$f" 2>/dev/null || continue
    fi

    local ts; ts="$(grep '"timestamp"' "$check_file" | sed 's/.*: *"\([^"]*\)".*/\1/')"
    if [[ "$ts" > "$latest_ts" ]]; then
      latest_ts="$ts"; latest_file="$f"
    fi

    [[ "$is_gz" == "true" ]] && rm -f "$check_file" 2>/dev/null
  done
  [[ -z "$latest_file" ]] && { _checkpoint_log WARN "No checkpoints found"; return 1; }
  _checkpoint_log INFO "Latest checkpoint: ${latest_file}  (${latest_ts})"

  # Output content (decompress if needed)
  if [[ "$latest_file" == *.gz ]]; then
    gzip -dc "$latest_file" 2>/dev/null
  else
    cat "$latest_file"
  fi
}

# --- checkpoint_cleanup(session_id, keep_last_n) ----------------------------

checkpoint_cleanup() {
  local session_id="$1" keep="${2:-5}"
  local ckp_dir="${CHECKPOINT_BASE_DIR}/${session_id}"
  [[ ! -d "$ckp_dir" ]] && return 0

  local total; total="$(find "$ckp_dir" \( -name '*.json' -o -name '*.json.gz' \) | wc -l | tr -d ' ')"
  if (( total <= keep )); then
    _checkpoint_log INFO "Only ${total} checkpoint(s); nothing to clean"
    return 0
  fi

  local to_remove=$(( total - keep ))
  find "$ckp_dir" \( -name '*.json' -o -name '*.json.gz' \) -print0 \
    | xargs -0 ls -1t \
    | tail -n "$to_remove" \
    | while read -r old; do
        rm -f "$old"
        # Also remove corresponding diff file
        local diff_name="${old%.json*}"
        rm -f "${ckp_dir}/diffs/$(basename "$diff_name")"*.diff* 2>/dev/null
        _checkpoint_log INFO "Removed: $(basename "$old")"
      done
  _checkpoint_log OK "Cleanup complete. Kept last ${keep} checkpoints."
}

# --- checkpoint_auto_save(session_id, stage_name) ---------------------------

checkpoint_auto_save() {
  local session_id="$1" stage_name="$2"
  checkpoint_save "$session_id" "$stage_name" '{"auto":true}'
}

# =============================================================================
# v11.0: Differential Backups
# =============================================================================

# Save only changed files (diff from previous checkpoint, not full git commit)
_checkpoint_save_differential() {
  local session_id="$1" stage_name="$2" rev_hash="$3"
  local ckp_dir="${CHECKPOINT_BASE_DIR}/${session_id}"
  local diff_dir="${ckp_dir}/diffs"
  mkdir -p "$diff_dir" 2>/dev/null

  # Get the diff from previous commit
  local diff_content
  diff_content=$(git diff HEAD~1 HEAD 2>/dev/null || echo "")

  if [[ -z "$diff_content" ]]; then
    _checkpoint_log INFO "Differential: No changes to save"
    return 0
  fi

  local diff_file="${diff_dir}/${stage_name}.diff"

  # v11.0: Compress diff if enabled
  if [[ "$CHECKPOINT_COMPRESS" == "true" ]] && command -v gzip &>/dev/null; then
    echo "$diff_content" | gzip > "${diff_file}.gz" 2>/dev/null
    local size
    size=$(du -sk "${diff_file}.gz" 2>/dev/null | cut -f1)
    _checkpoint_log INFO "Differential backup saved: ${stage_name}.diff.gz (${size}K compressed)"
  else
    echo "$diff_content" > "$diff_file" 2>/dev/null
    local size
    size=$(du -sk "$diff_file" 2>/dev/null | cut -f1)
    _checkpoint_log INFO "Differential backup saved: ${stage_name}.diff (${size}K)"
  fi

  # Also save a manifest of changed files
  local manifest_file="${diff_dir}/${stage_name}.manifest"
  git diff --name-status HEAD~1 HEAD 2>/dev/null > "$manifest_file"
}

# Restore from differential backup
checkpoint_restore_differential() {
  local session_id="$1" stage_name="$2"
  local ckp_dir="${CHECKPOINT_BASE_DIR}/${session_id}"
  local diff_dir="${ckp_dir}/diffs"

  local diff_file="${diff_dir}/${stage_name}.diff"
  local diff_gz="${diff_dir}/${stage_name}.diff.gz"

  local actual_diff=""
  if [[ -f "$diff_gz" ]]; then
    actual_diff=$(gzip -dc "$diff_gz" 2>/dev/null)
  elif [[ -f "$diff_file" ]]; then
    actual_diff=$(cat "$diff_file" 2>/dev/null)
  else
    _checkpoint_log WARN "No differential backup for: ${stage_name}"
    return 1
  fi

  if [[ -n "$actual_diff" ]]; then
    echo "$actual_diff" | git apply --allow-empty 2>/dev/null
    if [[ $? -eq 0 ]]; then
      _checkpoint_log OK "Differential restore applied: ${stage_name}"
      return 0
    else
      _checkpoint_log ERROR "Failed to apply differential backup: ${stage_name}"
      return 1
    fi
  fi

  return 1
}

# =============================================================================
# v11.0: Auto-Rotation
# =============================================================================

# Automatically delete old checkpoints: older than 24h, keep max 20
_checkpoint_auto_rotate() {
  local session_id="$1"
  local ckp_dir="${CHECKPOINT_BASE_DIR}/${session_id}"
  [[ ! -d "$ckp_dir" ]] && return 0

  local now_epoch
  now_epoch=$(date +%s)
  local max_age_sec=$((CHECKPOINT_MAX_AGE_HOURS * 3600))

  # 1. Remove checkpoints older than max age
  local removed_age=0
  for f in "$ckp_dir"/*.json "$ckp_dir"/*.json.gz; do
    [[ -f "$f" ]] || continue

    # Get file modification time
    local file_epoch
    if [[ "$(uname)" == "Darwin" ]]; then
      file_epoch=$(stat -f "%m" "$f" 2>/dev/null || echo "0")
    else
      file_epoch=$(stat -c "%Y" "$f" 2>/dev/null || echo "0")
    fi

    local age=$((now_epoch - file_epoch))
    if [[ "$age" -gt "$max_age_sec" ]]; then
      local basename_f
      basename_f="$(basename "$f")"
      rm -f "$f"
      # Also remove corresponding diff
      local stage_name="${basename_f%.json*}"
      rm -f "${ckp_dir}/diffs/${stage_name}".diff* 2>/dev/null
      rm -f "${ckp_dir}/diffs/${stage_name}".manifest 2>/dev/null
      removed_age=$((removed_age + 1))
    fi
  done

  [[ "$removed_age" -gt 0 ]] && _checkpoint_log INFO "Auto-rotation: Removed ${removed_age} checkpoint(s) older than ${CHECKPOINT_MAX_AGE_HOURS}h"

  # 2. Enforce max count
  local total
  total=$(find "$ckp_dir" \( -name '*.json' -o -name '*.json.gz' \) 2>/dev/null | wc -l | tr -d ' ')

  if [[ "$total" -gt "$CHECKPOINT_MAX_COUNT" ]]; then
    local excess=$((total - CHECKPOINT_MAX_COUNT))
    find "$ckp_dir" \( -name '*.json' -o -name '*.json.gz' \) -print0 2>/dev/null \
      | xargs -0 ls -1t 2>/dev/null \
      | tail -n "$excess" \
      | while read -r old; do
          rm -f "$old"
          local stage_name
          stage_name="$(basename "${old%.json*}")"
          rm -f "${ckp_dir}/diffs/${stage_name}".diff* 2>/dev/null
          rm -f "${ckp_dir}/diffs/${stage_name}".manifest 2>/dev/null
        done
    _checkpoint_log INFO "Auto-rotation: Trimmed to max ${CHECKPOINT_MAX_COUNT} checkpoints (removed ${excess})"
  fi
}

# =============================================================================
# v11.0: Compression
# =============================================================================

# Compress a checkpoint metadata file
_checkpoint_compress_meta() {
  local meta_file="$1"
  [[ ! -f "$meta_file" ]] && return 1

  if command -v gzip &>/dev/null; then
    gzip -f "$meta_file" 2>/dev/null
    [[ -f "${meta_file}.gz" ]] && return 0
  fi
  return 1
}

# Decompress a checkpoint metadata file
_checkpoint_decompress_meta() {
  local gz_file="$1"
  [[ ! -f "$gz_file" ]] && return 1

  if command -v gzip &>/dev/null; then
    gzip -dk "$gz_file" 2>/dev/null
    local json_file="${gz_file%.gz}"
    [[ -f "$json_file" ]] && return 0
  fi
  return 1
}

# Compress all uncompressed checkpoints in a session
checkpoint_compress_all() {
  local session_id="$1"
  local ckp_dir="${CHECKPOINT_BASE_DIR}/${session_id}"
  [[ ! -d "$ckp_dir" ]] && { _checkpoint_log WARN "No checkpoint dir for: ${session_id}"; return 1; }

  local compressed=0
  for f in "$ckp_dir"/*.json; do
    [[ -f "$f" ]] || continue
    # Skip if already has a .gz version
    [[ -f "${f}.gz" ]] && continue
    if _checkpoint_compress_meta "$f"; then
      compressed=$((compressed + 1))
    fi
  done

  # Also compress diff files
  for f in "$ckp_dir"/diffs/*.diff; do
    [[ -f "$f" ]] || continue
    [[ -f "${f}.gz" ]] && continue
    gzip -f "$f" 2>/dev/null && compressed=$((compressed + 1))
  done

  _checkpoint_log OK "Compressed ${compressed} file(s) in session ${session_id}"
}

# =============================================================================
# v11.0: Checkpoint Diff
# =============================================================================

# checkpoint_diff(session_id, stage1, stage2) - Show what changed between two checkpoints
checkpoint_diff() {
  local session_id="$1" stage1="$2" stage2="$3"
  [[ -z "$session_id" || -z "$stage1" || -z "$stage2" ]] && {
    _checkpoint_log ERROR "Usage: checkpoint_diff <session_id> <stage1> <stage2>"
    return 1
  }

  local ckp_dir="${CHECKPOINT_BASE_DIR}/${session_id}"

  # Get revision hashes for both stages
  local meta1 meta2
  meta1="${ckp_dir}/${stage1}.json"
  meta2="${ckp_dir}/${stage2}.json"

  # Decompress if needed
  [[ ! -f "$meta1" && -f "${meta1}.gz" ]] && _checkpoint_decompress_meta "${meta1}.gz"
  [[ ! -f "$meta2" && -f "${meta2}.gz" ]] && _checkpoint_decompress_meta "${meta2}.gz"

  [[ ! -f "$meta1" ]] && { _checkpoint_log ERROR "Checkpoint not found: ${stage1}"; return 1; }
  [[ ! -f "$meta2" ]] && { _checkpoint_log ERROR "Checkpoint not found: ${stage2}"; return 1; }

  local rev1 rev2 ts1 ts2 files1 files2
  rev1="$(grep '"rev_hash"' "$meta1" | sed 's/.*: *"\([^"]*\)".*/\1/')"
  rev2="$(grep '"rev_hash"' "$meta2" | sed 's/.*: *"\([^"]*\)".*/\1/')"
  ts1="$(grep '"timestamp"' "$meta1" | sed 's/.*: *"\([^"]*\)".*/\1/')"
  ts2="$(grep '"timestamp"' "$meta2" | sed 's/.*: *"\([^"]*\)".*/\1/')"
  files1="$(grep '"files_modified"' "$meta1" | sed 's/.*: *"\([^"]*\)".*/\1/')"
  files2="$(grep '"files_modified"' "$meta2" | sed 's/.*: *"\([^"]*\)".*/\1/')"

  printf "\n${_CKP_BOLD}${_CKP_CYAN}=== Checkpoint Diff (v11.0) ===${_CKP_NC}\n"
  printf "  ${_CKP_BOLD}Stage A:${_CKP_NC} %-20s  rev: %-10s  %s\n" "$stage1" "${rev1:0:8}" "$ts1"
  printf "  ${_CKP_BOLD}Stage B:${_CKP_NC} %-20s  rev: %-10s  %s\n" "$stage2" "${rev2:0:8}" "$ts2"
  printf "${_CKP_CYAN}%s${_CKP_NC}\n" "-------------------------------------------------------"

  # Show files modified in each
  printf "\n  ${_CKP_BOLD}Files in A:${_CKP_NC} %s\n" "${files1:-none}"
  printf "  ${_CKP_BOLD}Files in B:${_CKP_NC} %s\n" "${files2:-none}"

  # If git is available, show actual diff between revisions
  if [[ "$rev1" != "no-git" && "$rev2" != "no-git" ]] && command -v git &>/dev/null; then
    printf "\n  ${_CKP_BOLD}Git diff (${rev1:0:8}..${rev2:0:8}):${_CKP_NC}\n"

    local stat_output
    stat_output=$(git diff --stat "${rev1}" "${rev2}" 2>/dev/null)
    if [[ -n "$stat_output" ]]; then
      echo "$stat_output" | while IFS= read -r line; do
        printf "    %s\n" "$line"
      done
    else
      printf "    ${_CKP_YELLOW}(no file differences)${_CKP_NC}\n"
    fi

    # Show actual diff (limited output)
    local full_diff
    full_diff=$(git diff "${rev1}" "${rev2}" 2>/dev/null | head -100)
    if [[ -n "$full_diff" ]]; then
      printf "\n  ${_CKP_BOLD}Diff preview (first 100 lines):${_CKP_NC}\n"
      echo "$full_diff" | while IFS= read -r line; do
        if [[ "$line" =~ ^\+ ]]; then
          printf "    ${_CKP_GREEN}%s${_CKP_NC}\n" "$line"
        elif [[ "$line" =~ ^\- ]]; then
          printf "    ${_CKP_RED}%s${_CKP_NC}\n" "$line"
        else
          printf "    %s\n" "$line"
        fi
      done
    fi
  else
    # Fallback: compare differential backups
    printf "\n  ${_CKP_YELLOW}Git comparison not available - comparing manifests${_CKP_NC}\n"
    local manifest1="${ckp_dir}/diffs/${stage1}.manifest"
    local manifest2="${ckp_dir}/diffs/${stage2}.manifest"
    if [[ -f "$manifest1" && -f "$manifest2" ]]; then
      printf "\n  ${_CKP_BOLD}Changes in A -> B:${_CKP_NC}\n"
      diff "$manifest1" "$manifest2" 2>/dev/null | while IFS= read -r line; do
        printf "    %s\n" "$line"
      done
    fi
  fi

  printf "${_CKP_CYAN}===============================${_CKP_NC}\n"
}

# =============================================================================
# v11.0: Export / Import
# =============================================================================

# checkpoint_export(session_id) - Export all checkpoints as a compressed archive
checkpoint_export() {
  local session_id="$1"
  [[ -z "$session_id" ]] && { _checkpoint_log ERROR "Usage: checkpoint_export <session_id>"; return 1; }

  local ckp_dir="${CHECKPOINT_BASE_DIR}/${session_id}"
  [[ ! -d "$ckp_dir" ]] && { _checkpoint_log ERROR "No checkpoints for session: ${session_id}"; return 1; }

  local export_file="checkpoint_export_${session_id}_$(date +%Y%m%d_%H%M%S).tar.gz"

  # Count files to export
  local file_count
  file_count=$(find "$ckp_dir" -type f 2>/dev/null | wc -l | tr -d ' ')
  _checkpoint_log INFO "Exporting ${file_count} file(s) from session: ${session_id}"

  # Create tar.gz archive
  if command -v tar &>/dev/null; then
    tar -czf "$export_file" -C "$(dirname "$ckp_dir")" "$(basename "$ckp_dir")" 2>/dev/null
    if [[ -f "$export_file" ]]; then
      local size
      size=$(du -sk "$export_file" 2>/dev/null | cut -f1)
      _checkpoint_log OK "Exported: ${export_file} (${size}K)"

      # Also include git bundle if possible
      if command -v git &>/dev/null && git rev-parse --is-inside-work-tree &>/dev/null 2>&1; then
        local bundle_file="checkpoint_git_bundle_${session_id}.bundle"
        # Find the oldest and newest revisions in this session
        local oldest_rev newest_rev
        oldest_rev=""
        newest_rev=""
        for f in "$ckp_dir"/*.json "$ckp_dir"/*.json.gz; do
          [[ -f "$f" ]] || continue
          local check_file="$f"
          [[ "$f" == *.gz ]] && { gzip -dk "$f" 2>/dev/null; check_file="${f%.gz}"; }
          local rev
          rev="$(grep '"rev_hash"' "$check_file" | sed 's/.*: *"\([^"]*\)".*/\1/')"
          [[ "$f" == *.gz ]] && rm -f "$check_file" 2>/dev/null
          [[ "$rev" == "no-git" || -z "$rev" ]] && continue
          [[ -z "$oldest_rev" ]] && oldest_rev="$rev"
          newest_rev="$rev"
        done

        if [[ -n "$oldest_rev" && -n "$newest_rev" ]]; then
          git bundle create "$bundle_file" "${oldest_rev}..${newest_rev}" 2>/dev/null
          if [[ -f "$bundle_file" ]]; then
            _checkpoint_log INFO "Git bundle: ${bundle_file}"
          fi
        fi
      fi

      echo "$export_file"
      return 0
    fi
  fi

  _checkpoint_log ERROR "Export failed - tar not available"
  return 1
}

# checkpoint_import(archive_path) - Import checkpoints from a compressed archive
checkpoint_import() {
  local archive_path="$1"
  [[ -z "$archive_path" || ! -f "$archive_path" ]] && {
    _checkpoint_log ERROR "Usage: checkpoint_import <archive_path>"
    return 1
  }

  _checkpoint_log INFO "Importing from: ${archive_path}"

  # Verify archive
  if ! tar -tzf "$archive_path" &>/dev/null; then
    _checkpoint_log ERROR "Invalid archive: ${archive_path}"
    return 1
  fi

  # Extract archive contents to understand structure
  local contents
  contents=$(tar -tzf "$archive_path" 2>/dev/null | head -1)
  local session_dir
  session_dir=$(echo "$contents" | cut -d'/' -f1)

  if [[ -z "$session_dir" ]]; then
    _checkpoint_log ERROR "Cannot determine session from archive"
    return 1
  fi

  # Check if session already exists
  local target_dir="${CHECKPOINT_BASE_DIR}/${session_dir}"
  if [[ -d "$target_dir" ]]; then
    _checkpoint_log WARN "Session already exists: ${session_dir} - merging"
  fi

  # Extract
  mkdir -p "${CHECKPOINT_BASE_DIR}" 2>/dev/null
  tar -xzf "$archive_path" -C "${CHECKPOINT_BASE_DIR}" 2>/dev/null
  if [[ $? -eq 0 ]]; then
    local imported_count
    imported_count=$(find "$target_dir" -type f 2>/dev/null | wc -l | tr -d ' ')
    _checkpoint_log OK "Imported ${imported_count} file(s) to session: ${session_dir}"

    # List imported checkpoints
    checkpoint_list "$session_dir"
    return 0
  fi

  _checkpoint_log ERROR "Import failed"
  return 1
}

# =============================================================================
# v11.0: Utility Functions
# =============================================================================

# Get total size of all checkpoints for a session
checkpoint_size() {
  local session_id="$1"
  local ckp_dir="${CHECKPOINT_BASE_DIR}/${session_id}"
  [[ ! -d "$ckp_dir" ]] && { _checkpoint_log WARN "No checkpoints for: ${session_id}"; return 1; }

  local total_size
  total_size=$(du -sk "$ckp_dir" 2>/dev/null | cut -f1)
  local file_count
  file_count=$(find "$ckp_dir" -type f 2>/dev/null | wc -l | tr -d ' ')

  printf "${_CKP_BOLD}Checkpoint Size: ${session_id}${_CKP_NC}\n"
  printf "  Files: %d\n" "$file_count"
  printf "  Total: %dKB" "$total_size"
  if [[ "$total_size" -gt 1024 ]]; then
    printf " (%.1fMB)" "$(echo "$total_size" | awk '{printf "%.1f", $1/1024}')"
  fi
  printf "\n"

  # Breakdown
  local json_count json_size diff_count diff_size
  json_count=$(find "$ckp_dir" \( -name '*.json' -o -name '*.json.gz' \) 2>/dev/null | wc -l | tr -d ' ')
  json_size=$(find "$ckp_dir" \( -name '*.json' -o -name '*.json.gz' \) -exec du -sk {} + 2>/dev/null | awk '{s+=$1}END{print s+0}')
  diff_count=$(find "$ckp_dir/diffs" -type f 2>/dev/null | wc -l | tr -d ' ')
  diff_size=$(du -sk "$ckp_dir/diffs" 2>/dev/null | cut -f1)
  diff_size="${diff_size:-0}"

  printf "  Metadata: %d files (%dKB)\n" "$json_count" "$json_size"
  printf "  Diffs:    %d files (%dKB)\n" "$diff_count" "$diff_size"
}

# Verify integrity of all checkpoints
checkpoint_verify() {
  local session_id="$1"
  local ckp_dir="${CHECKPOINT_BASE_DIR}/${session_id}"
  [[ ! -d "$ckp_dir" ]] && { _checkpoint_log WARN "No checkpoints for: ${session_id}"; return 1; }

  local total=0 valid=0 invalid=0

  printf "${_CKP_BOLD}Verifying checkpoints: ${session_id}${_CKP_NC}\n"

  for f in "$ckp_dir"/*.json "$ckp_dir"/*.json.gz; do
    [[ -f "$f" ]] || continue
    total=$((total + 1))

    local check_file="$f"
    local is_gz=false
    if [[ "$f" == *.gz ]]; then
      is_gz=true
      check_file="${f%.gz}"
      if ! gzip -dk "$f" 2>/dev/null; then
        printf "  ${_CKP_RED}CORRUPT${_CKP_NC}: %s (cannot decompress)\n" "$(basename "$f")"
        invalid=$((invalid + 1))
        continue
      fi
    fi

    # Verify JSON structure
    if grep -q '"stage"' "$check_file" && grep -q '"timestamp"' "$check_file" && grep -q '"rev_hash"' "$check_file"; then
      local rev
      rev="$(grep '"rev_hash"' "$check_file" | sed 's/.*: *"\([^"]*\)".*/\1/')"
      # Verify git revision exists
      if [[ "$rev" != "no-git" ]] && command -v git &>/dev/null; then
        if git cat-file -t "$rev" &>/dev/null; then
          printf "  ${_CKP_GREEN}OK${_CKP_NC}: %s (rev %s)\n" "$(basename "$f")" "${rev:0:8}"
          valid=$((valid + 1))
        else
          printf "  ${_CKP_YELLOW}WARN${_CKP_NC}: %s (rev %s missing in git)\n" "$(basename "$f")" "${rev:0:8}"
          valid=$((valid + 1))  # Still valid metadata, just missing git ref
        fi
      else
        printf "  ${_CKP_GREEN}OK${_CKP_NC}: %s\n" "$(basename "$f")"
        valid=$((valid + 1))
      fi
    else
      printf "  ${_CKP_RED}INVALID${_CKP_NC}: %s (missing required fields)\n" "$(basename "$f")"
      invalid=$((invalid + 1))
    fi

    [[ "$is_gz" == "true" ]] && rm -f "$check_file" 2>/dev/null
  done

  printf "\n  Total: %d | Valid: ${_CKP_GREEN}%d${_CKP_NC} | Invalid: ${_CKP_RED}%d${_CKP_NC}\n" "$total" "$valid" "$invalid"
  [[ "$invalid" -eq 0 ]]
}
