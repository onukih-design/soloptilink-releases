#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v488.0 - Continuous Learning Engine
# =============================================================================
# ランタイム実行を継続的に観測し、洞察を抽出して改善を自動適用する。
# 実行パターン・エラー傾向・品質推移を学習し、
# 次回実行時により良い結果を出すための知識を蓄積する自己進化エンジン。
#
# Functions:
#   _cle_init               - 初期化
#   _cle_observe_runtime    - ランタイム観測
#   _cle_extract_insights   - 洞察抽出
#   _cle_apply_improvements - 改善適用
#   _cle_get_learning_state - 学習状態取得
#   _cle_report             - レポート出力
#   _cle_score              - モジュールスコア(0-100)
#
# Globals: CLE_ prefix
# =============================================================================

[[ -n "${_CONTINUOUS_LEARNING_ENGINE_LOADED:-}" ]] && return 0
_CONTINUOUS_LEARNING_ENGINE_LOADED=1

CLE_VERSION="488.0"
CLE_INITIALIZED=false

# --- Storage ---
CLE_DATA_DIR=""
CLE_OBSERVATIONS_FILE=""
CLE_INSIGHTS_FILE=""
CLE_IMPROVEMENTS_FILE=""

# --- State ---
CLE_TOTAL_OBSERVATIONS=0
CLE_TOTAL_INSIGHTS=0
CLE_TOTAL_IMPROVEMENTS=0
CLE_LEARNING_VELOCITY=0

# --- Knowledge ---
declare -g -A _CLE_OBSERVATIONS=()
declare -g -a _CLE_INSIGHTS=()
declare -g -A _CLE_IMPROVEMENT_MAP=()
declare -g -A _CLE_METRIC_TRENDS=()
declare -g -a _CLE_LEARNING_HISTORY=()

# =============================================================================
# 初期化
# =============================================================================
_cle_init() {
    local base_dir="${HOME}/.soloptilink/cle"
    CLE_DATA_DIR="$base_dir"
    CLE_OBSERVATIONS_FILE="${base_dir}/observations.jsonl"
    CLE_INSIGHTS_FILE="${base_dir}/insights.jsonl"
    CLE_IMPROVEMENTS_FILE="${base_dir}/improvements.jsonl"

    mkdir -p "$CLE_DATA_DIR"

    if [[ -f "$CLE_OBSERVATIONS_FILE" ]]; then
        CLE_TOTAL_OBSERVATIONS=$(wc -l < "$CLE_OBSERVATIONS_FILE" 2>/dev/null || echo "0")
    fi
    if [[ -f "$CLE_INSIGHTS_FILE" ]]; then
        CLE_TOTAL_INSIGHTS=$(wc -l < "$CLE_INSIGHTS_FILE" 2>/dev/null || echo "0")
    fi

    CLE_INITIALIZED=true
    return 0
}

# =============================================================================
# ランタイム観測
# =============================================================================
_cle_observe_runtime() {
    local event_type="$1"
    local data="$2"
    local context="${3:-}"

    [[ "$CLE_INITIALIZED" != "true" ]] && _cle_init

    local timestamp
    timestamp=$(date +%s)

    _CLE_OBSERVATIONS["${event_type}::${timestamp}"]="$data"

    # メトリクストレンドの更新
    case "$event_type" in
        build_time)
            local current="${_CLE_METRIC_TRENDS["build_time"]:-}"
            _CLE_METRIC_TRENDS["build_time"]="${current:+${current},}${data}"
            ;;
        quality_score)
            local current="${_CLE_METRIC_TRENDS["quality_score"]:-}"
            _CLE_METRIC_TRENDS["quality_score"]="${current:+${current},}${data}"
            ;;
        error_count)
            local current="${_CLE_METRIC_TRENDS["error_count"]:-}"
            _CLE_METRIC_TRENDS["error_count"]="${current:+${current},}${data}"
            ;;
        fix_iterations)
            local current="${_CLE_METRIC_TRENDS["fix_iterations"]:-}"
            _CLE_METRIC_TRENDS["fix_iterations"]="${current:+${current},}${data}"
            ;;
        token_usage)
            local current="${_CLE_METRIC_TRENDS["token_usage"]:-}"
            _CLE_METRIC_TRENDS["token_usage"]="${current:+${current},}${data}"
            ;;
    esac

    echo "{\"ts\":${timestamp},\"type\":\"${event_type}\",\"data\":\"${data}\",\"ctx\":\"${context}\"}" >> "$CLE_OBSERVATIONS_FILE" 2>/dev/null

    CLE_TOTAL_OBSERVATIONS=$((CLE_TOTAL_OBSERVATIONS + 1))
    return 0
}

# =============================================================================
# 洞察抽出
# =============================================================================
_cle_extract_insights() {
    [[ "$CLE_INITIALIZED" != "true" ]] && _cle_init

    _CLE_INSIGHTS=()

    # ビルド時間トレンド分析
    local build_times="${_CLE_METRIC_TRENDS["build_time"]:-}"
    if [[ -n "$build_times" ]]; then
        local count=0 total=0 last=0
        IFS=',' read -ra times <<< "$build_times"
        for t in "${times[@]}"; do
            total=$((total + t))
            count=$((count + 1))
            last=$t
        done
        if [[ $count -gt 2 ]]; then
            local avg=$((total / count))
            if [[ $last -gt $((avg * 120 / 100)) ]]; then
                _CLE_INSIGHTS+=("ビルド時間増加傾向: 最新${last}s > 平均${avg}s → バンドル最適化を検討")
            fi
        fi
    fi

    # 品質スコアトレンド分析
    local quality_scores="${_CLE_METRIC_TRENDS["quality_score"]:-}"
    if [[ -n "$quality_scores" ]]; then
        local count=0 total=0 last=0
        IFS=',' read -ra scores <<< "$quality_scores"
        for s in "${scores[@]}"; do
            total=$((total + s))
            count=$((count + 1))
            last=$s
        done
        if [[ $count -gt 2 ]]; then
            local avg=$((total / count))
            if [[ $last -gt $avg ]]; then
                _CLE_INSIGHTS+=("品質向上傾向: 最新${last} > 平均${avg} → 現在の戦略は効果的")
            elif [[ $last -lt $((avg * 90 / 100)) ]]; then
                _CLE_INSIGHTS+=("品質低下傾向: 最新${last} < 平均${avg} → プロンプト/パターン見直しが必要")
            fi
        fi
    fi

    # エラー数トレンド分析
    local error_counts="${_CLE_METRIC_TRENDS["error_count"]:-}"
    if [[ -n "$error_counts" ]]; then
        local count=0 total=0 last=0
        IFS=',' read -ra errors <<< "$error_counts"
        for e in "${errors[@]}"; do
            total=$((total + e))
            count=$((count + 1))
            last=$e
        done
        if [[ $count -gt 2 ]]; then
            local avg=$((total / count))
            if [[ $last -eq 0 && $avg -gt 0 ]]; then
                _CLE_INSIGHTS+=("エラーゼロ達成: エラー予防が成功している")
            elif [[ $last -gt $((avg * 150 / 100)) ]]; then
                _CLE_INSIGHTS+=("エラー増加傾向: 新しいエラーパターン出現の可能性 → EPLモデル更新推奨")
            fi
        fi
    fi

    # 修正イテレーション分析
    local fix_iters="${_CLE_METRIC_TRENDS["fix_iterations"]:-}"
    if [[ -n "$fix_iters" ]]; then
        local count=0 total=0
        IFS=',' read -ra iters <<< "$fix_iters"
        for i in "${iters[@]}"; do
            total=$((total + i))
            count=$((count + 1))
        done
        if [[ $count -gt 0 ]]; then
            local avg=$((total / count))
            if [[ $avg -gt 10 ]]; then
                _CLE_INSIGHTS+=("修正イテレーション過多(平均${avg}回): 初回生成品質の向上が急務")
            elif [[ $avg -le 3 ]]; then
                _CLE_INSIGHTS+=("効率的な修正サイクル(平均${avg}回): 高い初回生成品質")
            fi
        fi
    fi

    # 学習速度の計算
    CLE_LEARNING_VELOCITY=${#_CLE_INSIGHTS[@]}

    local timestamp
    timestamp=$(date +%s)
    for insight in "${_CLE_INSIGHTS[@]}"; do
        echo "{\"ts\":${timestamp},\"insight\":\"${insight}\"}" >> "$CLE_INSIGHTS_FILE" 2>/dev/null
        CLE_TOTAL_INSIGHTS=$((CLE_TOTAL_INSIGHTS + 1))
    done

    echo "${#_CLE_INSIGHTS[@]}"
    return 0
}

# =============================================================================
# 改善適用
# =============================================================================
_cle_apply_improvements() {
    [[ "$CLE_INITIALIZED" != "true" ]] && _cle_init

    local applied=0

    for insight in "${_CLE_INSIGHTS[@]}"; do
        local improvement=""

        case "$insight" in
            *"ビルド時間増加"*)
                improvement="next.config.jsにバンドル分析を追加、不要依存の削除"
                _CLE_IMPROVEMENT_MAP["build_optimization"]="$improvement"
                ;;
            *"品質低下"*)
                improvement="Enterprise Patterns注入レベルをfullに変更"
                _CLE_IMPROVEMENT_MAP["quality_boost"]="$improvement"
                ;;
            *"エラー増加"*)
                improvement="Error Prediction Modelの再学習を実行"
                _CLE_IMPROVEMENT_MAP["error_prevention"]="$improvement"
                ;;
            *"修正イテレーション過多"*)
                improvement="Golden Patternsテンプレートの更新、プロンプトの自己改善実行"
                _CLE_IMPROVEMENT_MAP["generation_quality"]="$improvement"
                ;;
        esac

        if [[ -n "$improvement" ]]; then
            applied=$((applied + 1))
            echo "  [CLE] 改善適用: $improvement" >&2
        fi
    done

    CLE_TOTAL_IMPROVEMENTS=$((CLE_TOTAL_IMPROVEMENTS + applied))

    local timestamp
    timestamp=$(date +%s)
    echo "{\"ts\":${timestamp},\"applied\":${applied}}" >> "$CLE_IMPROVEMENTS_FILE" 2>/dev/null

    echo "$applied"
    return 0
}

# =============================================================================
# 学習状態取得
# =============================================================================
_cle_get_learning_state() {
    echo "{"
    echo "  \"observations\": ${CLE_TOTAL_OBSERVATIONS},"
    echo "  \"insights\": ${CLE_TOTAL_INSIGHTS},"
    echo "  \"improvements\": ${CLE_TOTAL_IMPROVEMENTS},"
    echo "  \"velocity\": ${CLE_LEARNING_VELOCITY}"
    echo "}"
}

# =============================================================================
# レポート
# =============================================================================
_cle_report() {
    echo -e "\n  ${BOLD:-}═══ Continuous Learning Engine v${CLE_VERSION} ═══${NC:-}"
    echo -e "  観測数             : ${CLE_TOTAL_OBSERVATIONS}"
    echo -e "  洞察数             : ${CLE_TOTAL_INSIGHTS}"
    echo -e "  改善適用数         : ${CLE_TOTAL_IMPROVEMENTS}"
    echo -e "  学習速度           : ${CLE_LEARNING_VELOCITY}"
}

_cle_score() {
    [[ "$CLE_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    local s=50
    [[ $CLE_TOTAL_OBSERVATIONS -gt 10 ]] && s=$((s + 15))
    [[ $CLE_TOTAL_INSIGHTS -gt 3 ]] && s=$((s + 15))
    [[ $CLE_TOTAL_IMPROVEMENTS -gt 0 ]] && s=$((s + 20))
    [[ $s -gt 100 ]] && s=100
    echo "$s"
}

_cle_init_message() {
    echo -e "  ${GREEN:-}✅ v${CLE_VERSION} continuous-learning-engine: 継続学習エンジン (${CLE_TOTAL_OBSERVATIONS} observations)${NC:-}" >&2
}

# =============================================================================
# Module Registry 登録
# =============================================================================
_mr_register \
    --name "continuous-learning-engine" \
    --version "$CLE_VERSION" \
    --description "継続学習エンジン" \
    --init "_cle_init" \
    --report "_cle_report" \
    --score "_cle_score" \
    --enable-var "ENABLE_CONTINUOUS_LEARNING" \
    --cli-flags "--continuous-learning:--no-continuous-learning" \
    --init-msg "_cle_init_message"
