#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v107.0 - Performance Measurer
# 生成コードの実パフォーマンスを計測
#
# 問題: 生成されたNext.jsアプリのバンドルサイズが巨大、
# API応答が遅い、Prisma N+1クエリが放置される。
# ビルドが通るだけでは性能は保証できない。
#
# 解決: 実際にビルドしてバンドルサイズ計測、
# curlでAPI応答時間計測、ソースコードからN+1パターン検出。
# 閾値ベースの自動スコアリングと最適化プロンプト生成。
# ============================================================

[[ -n "${_PM_LOADED:-}" ]] && return 0
_PM_LOADED=1

PM_VERSION="107.0"
PM_INITIALIZED=false

# Measurement results
PM_BUNDLE_TOTAL_KB=0
PM_BUNDLE_JS_KB=0
PM_BUNDLE_CSS_KB=0
PM_BUNDLE_CHUNKS=0
PM_LATENCY_AVG_MS=0
PM_LATENCY_P95_MS=0
PM_LATENCY_ENDPOINTS_TESTED=0
PM_N_PLUS_ONE_COUNT=0
PM_DEEP_INCLUDE_COUNT=0
PM_REPORT_DETAIL=""

# ============================================================
# Init
# ============================================================
pm_init() {
    PM_BUNDLE_TOTAL_KB=0
    PM_BUNDLE_JS_KB=0
    PM_BUNDLE_CSS_KB=0
    PM_BUNDLE_CHUNKS=0
    PM_LATENCY_AVG_MS=0
    PM_LATENCY_P95_MS=0
    PM_LATENCY_ENDPOINTS_TESTED=0
    PM_N_PLUS_ONE_COUNT=0
    PM_DEEP_INCLUDE_COUNT=0
    PM_REPORT_DETAIL=""
    PM_INITIALIZED=true
    return 0
}

# ============================================================
# Measure bundle size (Next.js)
# ============================================================
pm_measure_bundle_size() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1

    local has_next=false
    for cfg in next.config.js next.config.mjs next.config.ts; do
        [[ -f "${project_dir}/${cfg}" ]] && has_next=true && break
    done

    # If .next doesn't exist, try building
    if [[ ! -d "${project_dir}/.next" ]] && [[ "$has_next" == "true" ]]; then
        if [[ -f "${project_dir}/package.json" ]] && command -v npm &>/dev/null; then
            PM_REPORT_DETAIL+="  [BUILD] Running npm run build...\n"
            local build_output
            build_output=$(cd "$project_dir" && timeout 120 npm run build 2>&1 || true)
            if [[ ! -d "${project_dir}/.next" ]]; then
                PM_REPORT_DETAIL+="  [BUILD] Build failed or timed out.\n"
                return 1
            fi
        fi
    fi

    if [[ -d "${project_dir}/.next" ]]; then
        # Measure total .next/static directory size
        local total_bytes=0
        local js_bytes=0
        local css_bytes=0
        local chunk_count=0

        # Count JS files and their sizes
        while IFS= read -r f; do
            local size
            size=$(wc -c < "$f" 2>/dev/null | tr -d ' ')
            js_bytes=$((js_bytes + ${size:-0}))
            chunk_count=$((chunk_count + 1))
        done < <(find "${project_dir}/.next/static" -name "*.js" -type f 2>/dev/null)

        # Count CSS files
        while IFS= read -r f; do
            local size
            size=$(wc -c < "$f" 2>/dev/null | tr -d ' ')
            css_bytes=$((css_bytes + ${size:-0}))
        done < <(find "${project_dir}/.next/static" -name "*.css" -type f 2>/dev/null)

        total_bytes=$((js_bytes + css_bytes))

        PM_BUNDLE_TOTAL_KB=$((total_bytes / 1024))
        PM_BUNDLE_JS_KB=$((js_bytes / 1024))
        PM_BUNDLE_CSS_KB=$((css_bytes / 1024))
        PM_BUNDLE_CHUNKS=$chunk_count

        PM_REPORT_DETAIL+="  [BUNDLE] Total: ${PM_BUNDLE_TOTAL_KB}KB (JS: ${PM_BUNDLE_JS_KB}KB, CSS: ${PM_BUNDLE_CSS_KB}KB)\n"
        PM_REPORT_DETAIL+="  [BUNDLE] JS Chunks: ${PM_BUNDLE_CHUNKS}\n"

    elif [[ -d "${project_dir}/dist" ]]; then
        # Fallback: Vite/generic dist
        local total_bytes=0
        local js_bytes=0
        local css_bytes=0

        while IFS= read -r f; do
            local size
            size=$(wc -c < "$f" 2>/dev/null | tr -d ' ')
            js_bytes=$((js_bytes + ${size:-0}))
        done < <(find "${project_dir}/dist" -name "*.js" -type f 2>/dev/null)

        while IFS= read -r f; do
            local size
            size=$(wc -c < "$f" 2>/dev/null | tr -d ' ')
            css_bytes=$((css_bytes + ${size:-0}))
        done < <(find "${project_dir}/dist" -name "*.css" -type f 2>/dev/null)

        total_bytes=$((js_bytes + css_bytes))
        PM_BUNDLE_TOTAL_KB=$((total_bytes / 1024))
        PM_BUNDLE_JS_KB=$((js_bytes / 1024))
        PM_BUNDLE_CSS_KB=$((css_bytes / 1024))

        PM_REPORT_DETAIL+="  [BUNDLE] Total: ${PM_BUNDLE_TOTAL_KB}KB (JS: ${PM_BUNDLE_JS_KB}KB, CSS: ${PM_BUNDLE_CSS_KB}KB)\n"
    else
        PM_REPORT_DETAIL+="  [BUNDLE] No build output found (.next/ or dist/).\n"
    fi

    return 0
}

# ============================================================
# Measure API latency
# ============================================================
pm_measure_api_latency() {
    local base_url="$1"
    local endpoints="$2"  # space-separated list of endpoints

    [[ -z "$base_url" ]] && return 1

    if ! command -v curl &>/dev/null; then
        PM_REPORT_DETAIL+="  [LATENCY] curl not available, skipping.\n"
        return 1
    fi

    local total_ms=0
    local max_ms=0
    local count=0
    local -a all_times=()

    # Default endpoints if none provided
    if [[ -z "$endpoints" ]]; then
        endpoints="/api/health /api/v1/status"
    fi

    for endpoint in $endpoints; do
        local url="${base_url}${endpoint}"
        local endpoint_total=0
        local endpoint_max=0
        local samples=0

        for i in 1 2 3 4 5; do
            local time_ms
            time_ms=$(curl -s -o /dev/null -w "%{time_total}" --connect-timeout 5 --max-time 10 "$url" 2>/dev/null || echo "0")

            # Convert seconds to milliseconds (time_total is in seconds with decimals)
            # Use awk since bash doesn't do float arithmetic
            local ms
            ms=$(echo "$time_ms" | awk '{printf "%d", $1 * 1000}' 2>/dev/null || echo "0")

            if [[ ${ms:-0} -gt 0 ]]; then
                endpoint_total=$((endpoint_total + ms))
                all_times+=("$ms")
                if [[ $ms -gt $endpoint_max ]]; then
                    endpoint_max=$ms
                fi
                samples=$((samples + 1))
            fi
        done

        if [[ $samples -gt 0 ]]; then
            local avg=$((endpoint_total / samples))
            PM_REPORT_DETAIL+="  [LATENCY] ${endpoint}: avg=${avg}ms max=${endpoint_max}ms (${samples} samples)\n"
            total_ms=$((total_ms + endpoint_total))
            count=$((count + samples))
            PM_LATENCY_ENDPOINTS_TESTED=$((PM_LATENCY_ENDPOINTS_TESTED + 1))
        else
            PM_REPORT_DETAIL+="  [LATENCY] ${endpoint}: unreachable\n"
        fi
    done

    if [[ $count -gt 0 ]]; then
        PM_LATENCY_AVG_MS=$((total_ms / count))

        # Compute p95: sort all times and pick the 95th percentile
        local sorted_times
        sorted_times=$(printf '%s\n' "${all_times[@]}" | sort -n)
        local total_samples=${#all_times[@]}
        local p95_index=$(( (total_samples * 95 + 99) / 100 ))
        if [[ $p95_index -ge $total_samples ]]; then
            p95_index=$((total_samples - 1))
        fi
        if [[ $p95_index -lt 0 ]]; then
            p95_index=0
        fi

        local idx=0
        while IFS= read -r t; do
            if [[ $idx -eq $p95_index ]]; then
                PM_LATENCY_P95_MS=$t
                break
            fi
            idx=$((idx + 1))
        done <<< "$sorted_times"

        PM_REPORT_DETAIL+="  [LATENCY] Overall: avg=${PM_LATENCY_AVG_MS}ms p95=${PM_LATENCY_P95_MS}ms\n"
    fi

    return 0
}

# ============================================================
# Detect N+1 query patterns in Prisma code
# ============================================================
pm_detect_n_plus_one() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1

    local n_plus_one=0
    local deep_includes=0

    # Collect source files that use Prisma
    local -a prisma_files=()
    while IFS= read -r f; do
        prisma_files+=("$f")
    done < <(grep -rlE 'prisma\.' "$project_dir" \
        --include="*.ts" --include="*.js" \
        --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=dist \
        2>/dev/null | head -200)

    for f in "${prisma_files[@]}"; do
        local rel="${f#$project_dir/}"

        # --- N+1 Detection ---
        # Pattern: for/forEach/map loop containing prisma.xxx.findUnique/findFirst
        # This is a strong signal of N+1 queries

        # Extract blocks that look like loops
        # Use awk to find for/forEach/map blocks, then check for prisma queries inside
        local loop_with_query
        loop_with_query=$(awk '
            /for\s*\(|\.forEach\s*\(|\.map\s*\(|for\s*await/ { in_loop=1; depth=0 }
            in_loop && /\{/ { depth++ }
            in_loop && /\}/ { depth--; if(depth<=0) in_loop=0 }
            in_loop && /prisma\.[a-zA-Z]+\.(findUnique|findFirst|findMany|create|update|delete)\s*\(/ {
                print FILENAME ":" NR ": " $0
            }
        ' "$f" 2>/dev/null)

        if [[ -n "$loop_with_query" ]]; then
            local lq_count
            lq_count=$(echo "$loop_with_query" | wc -l | tr -d ' ')
            n_plus_one=$((n_plus_one + ${lq_count:-0}))
            PM_REPORT_DETAIL+="  [N+1] ${rel}: ${lq_count} potential N+1 queries in loops\n"
        fi

        # --- Deep include detection ---
        # Check for Prisma include nesting depth > 3
        # Pattern: include: { xxx: { include: { yyy: { include: { ... } } } } }
        local deep
        deep=$(grep -cE 'include:\s*\{.*include:\s*\{.*include:\s*\{' "$f" 2>/dev/null || echo "0")
        if [[ ${deep:-0} -gt 0 ]]; then
            deep_includes=$((deep_includes + ${deep:-0}))
            PM_REPORT_DETAIL+="  [DEEP_INCLUDE] ${rel}: ${deep} deeply nested include(s) (depth > 3)\n"
        fi

        # Also check multiline deep includes using awk
        local ml_deep
        ml_deep=$(awk '
            BEGIN { depth=0; in_include=0 }
            /include\s*:/ { in_include++; depth++ }
            /\}/ && in_include>0 { in_include--; depth-- }
            depth >= 3 && /include\s*:/ { count++; depth=0 }
            END { print count+0 }
        ' "$f" 2>/dev/null)
        if [[ ${ml_deep:-0} -gt 0 ]]; then
            deep_includes=$((deep_includes + ${ml_deep:-0}))
        fi
    done

    PM_N_PLUS_ONE_COUNT=$n_plus_one
    PM_DEEP_INCLUDE_COUNT=$deep_includes

    if [[ $n_plus_one -eq 0 ]] && [[ $deep_includes -eq 0 ]]; then
        PM_REPORT_DETAIL+="  [QUERY] No N+1 or deep include issues detected.\n"
    fi

    return 0
}

# ============================================================
# Main: run all performance measurements
# ============================================================
pm_run() {
    local project_dir="$1"
    local base_url="${2:-}"
    local endpoints="${3:-}"
    [[ ! -d "$project_dir" ]] && return 1
    [[ "$PM_INITIALIZED" != "true" ]] && pm_init

    PM_REPORT_DETAIL="=== Performance Measurer v${PM_VERSION} ===\n"
    PM_REPORT_DETAIL+="Target: ${project_dir}\n"
    PM_REPORT_DETAIL+="Timestamp: $(date '+%Y-%m-%d %H:%M:%S')\n\n"

    pm_measure_bundle_size "$project_dir"
    pm_detect_n_plus_one "$project_dir"

    if [[ -n "$base_url" ]]; then
        pm_measure_api_latency "$base_url" "$endpoints"
    fi

    PM_REPORT_DETAIL+="\n--- Scores ---\n"
    PM_REPORT_DETAIL+="Bundle score: $(_pm_score_bundle)/100\n"
    PM_REPORT_DETAIL+="N+1 score: $(_pm_score_n_plus_one)/100\n"
    PM_REPORT_DETAIL+="Overall score: $(pm_score)/100\n"

    echo -e "$PM_REPORT_DETAIL"
    return 0
}

# ============================================================
# Generate optimization prompt
# ============================================================
pm_generate_optimization_prompt() {
    local report="${1:-$PM_REPORT_DETAIL}"
    local prompt="Optimize the following performance issues:\n\n"

    # Bundle size optimization
    if [[ $PM_BUNDLE_TOTAL_KB -gt 500 ]]; then
        prompt+="## Bundle Size (${PM_BUNDLE_TOTAL_KB}KB - target <500KB)\n"
        prompt+="1. Enable tree-shaking: check for barrel exports (index.ts re-exports)\n"
        prompt+="2. Use dynamic imports: const Component = dynamic(() => import('./Heavy'))\n"
        prompt+="3. Analyze with: npx @next/bundle-analyzer\n"
        prompt+="4. Replace heavy libraries:\n"
        prompt+="   - moment.js -> date-fns or dayjs\n"
        prompt+="   - lodash -> individual imports (lodash-es/specific)\n"
        prompt+="5. Move large dependencies to CDN or lazy-load\n"
        prompt+="6. Enable Next.js output: 'standalone' for smaller deployments\n\n"
    fi

    # N+1 query fixes
    if [[ $PM_N_PLUS_ONE_COUNT -gt 0 ]]; then
        prompt+="## N+1 Queries (${PM_N_PLUS_ONE_COUNT} detected)\n"
        prompt+="Replace loop-based queries with batch operations:\n"
        prompt+="- findUnique in loop -> findMany with 'where: { id: { in: ids } }'\n"
        prompt+="- Use Prisma 'include' for related data instead of separate queries\n"
        prompt+="- Consider using Prisma's selectRelationCount for counts\n"
        prompt+="Example fix:\n"
        prompt+="  // BAD: N+1\n"
        prompt+="  for (const id of ids) { await prisma.user.findUnique({ where: { id } }) }\n"
        prompt+="  // GOOD: Batch\n"
        prompt+="  const users = await prisma.user.findMany({ where: { id: { in: ids } } })\n\n"
    fi

    # Deep includes
    if [[ $PM_DEEP_INCLUDE_COUNT -gt 0 ]]; then
        prompt+="## Deep Prisma Includes (${PM_DEEP_INCLUDE_COUNT} detected, depth > 3)\n"
        prompt+="- Use select instead of include to fetch only needed fields\n"
        prompt+="- Split deeply nested queries into separate focused queries\n"
        prompt+="- Consider view models / DTOs to flatten response structure\n\n"
    fi

    # Latency optimization
    if [[ $PM_LATENCY_P95_MS -gt 500 ]]; then
        prompt+="## API Latency (p95: ${PM_LATENCY_P95_MS}ms - target <200ms)\n"
        prompt+="1. Add database indexes for frequently queried columns\n"
        prompt+="2. Implement response caching (Redis or in-memory)\n"
        prompt+="3. Use Prisma's select to return only needed fields\n"
        prompt+="4. Add connection pooling (PgBouncer or Prisma connection pool)\n"
        prompt+="5. Consider edge functions for read-heavy endpoints\n\n"
    fi

    echo -e "$prompt"
}

# ============================================================
# Score sub-components
# ============================================================
_pm_score_bundle() {
    local kb=$PM_BUNDLE_TOTAL_KB
    if [[ $kb -eq 0 ]]; then
        echo "50"  # No build output = neutral
        return
    fi
    if [[ $kb -lt 500 ]]; then
        echo "100"
    elif [[ $kb -lt 1024 ]]; then
        echo "80"
    elif [[ $kb -lt 2048 ]]; then
        echo "50"
    else
        echo "20"
    fi
}

_pm_score_latency() {
    local ms=$PM_LATENCY_P95_MS
    if [[ $ms -eq 0 ]]; then
        echo "50"  # Not measured = neutral
        return
    fi
    if [[ $ms -lt 200 ]]; then
        echo "100"
    elif [[ $ms -lt 500 ]]; then
        echo "80"
    elif [[ $ms -lt 1000 ]]; then
        echo "50"
    else
        echo "20"
    fi
}

_pm_score_n_plus_one() {
    local count=$((PM_N_PLUS_ONE_COUNT + PM_DEEP_INCLUDE_COUNT))
    if [[ $count -eq 0 ]]; then
        echo "100"
    elif [[ $count -le 2 ]]; then
        echo "70"
    elif [[ $count -le 5 ]]; then
        echo "40"
    else
        echo "10"
    fi
}

# ============================================================
# Overall score: weighted average
# Bundle 30% + Latency 30% + N+1 40%
# ============================================================
pm_score() {
    local bundle_score
    bundle_score=$(_pm_score_bundle)
    local latency_score
    latency_score=$(_pm_score_latency)
    local npo_score
    npo_score=$(_pm_score_n_plus_one)

    local weighted=$(( (bundle_score * 30 + latency_score * 30 + npo_score * 40) / 100 ))
    echo "$weighted"
}

# ============================================================
# Report
# ============================================================
pm_report() {
    echo -e "\n  ${BOLD:-}=== Performance Measurer v${PM_VERSION} ===${NC:-}"
    echo -e "  Bundle: ${PM_BUNDLE_TOTAL_KB}KB (JS: ${PM_BUNDLE_JS_KB}KB, CSS: ${PM_BUNDLE_CSS_KB}KB, Chunks: ${PM_BUNDLE_CHUNKS})"
    if [[ $PM_LATENCY_ENDPOINTS_TESTED -gt 0 ]]; then
        echo -e "  Latency: avg=${PM_LATENCY_AVG_MS}ms p95=${PM_LATENCY_P95_MS}ms (${PM_LATENCY_ENDPOINTS_TESTED} endpoints)"
    fi
    echo -e "  N+1 queries: ${PM_N_PLUS_ONE_COUNT} | Deep includes: ${PM_DEEP_INCLUDE_COUNT}"
    echo -e "  Score: $(pm_score)/100"
}

# ============================================================
# Module Registry self-registration
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "performance-measurer" \
        --version "$PM_VERSION" \
        --description "実パフォーマンス計測 - バンドル/レイテンシ/N+1検出" \
        --init "pm_init" \
        --report "pm_report" \
        --score "pm_score" \
        --enable-var "ENABLE_PM" \
        --cli-flags "--performance-measurer:--no-performance-measurer"
fi

# v2003.1: source時のexit codeを確実に0にする
true
