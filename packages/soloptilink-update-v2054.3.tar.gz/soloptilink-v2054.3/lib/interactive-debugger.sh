#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v391.0 - Interactive Debugger
# =============================================================================
# インタラクティブデバッグツール生成エンジン。
# デバッグUI/ランタイム分析/修正提案を自動生成。
# All globals use the ID_ prefix.
# =============================================================================

[[ -n "${_INTERACTIVE_DEBUGGER_LOADED:-}" ]] && return 0
_INTERACTIVE_DEBUGGER_LOADED=1

declare -g ID_VERSION="391.0"
declare -g ID_INITIALIZED=false
declare -g ID_GENERATED_COUNT=0
declare -g ID_DEBUG_TOOLS_GENERATED=false
declare -g ID_RUNTIME_ANALYZED=false
declare -g ID_FIX_SUGGESTED=false
declare -g ID_PANEL_GENERATED=false
declare -g ENABLE_ID="${ENABLE_ID:-true}"

_id_init() { ID_INITIALIZED=true; ID_GENERATED_COUNT=0; return 0; }

_id_generate_all() {
    local project_dir="${1:-.}"
    [[ "$ID_INITIALIZED" != "true" ]] && _id_init
    echo -e "  ${CYAN:-\033[0;36m}[ID]${NC:-\033[0m} デバッグツール生成開始..." >&2
    _id_generate_debug_tools "$project_dir"
    _id_analyze_runtime "$project_dir"
    _id_suggest_fix "$project_dir"
    _id_generate_panel "$project_dir"
    echo -e "  ${GREEN:-\033[0;32m}[ID]${NC:-\033[0m} デバッグツール生成完了: ${ID_GENERATED_COUNT}件" >&2
    return 0
}

_id_generate_debug_tools() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [ID-TOOLS] デバッグツール生成

### Debug Logger
```typescript
type LogLevel = 'debug' | 'info' | 'warn' | 'error';

class DebugLogger {
  private static instance: DebugLogger;
  private logs: { level: LogLevel; message: string; data?: any; timestamp: Date; source: string }[] = [];
  private enabled = process.env.NODE_ENV === 'development';

  static getInstance(): DebugLogger {
    if (!this.instance) this.instance = new DebugLogger();
    return this.instance;
  }

  log(level: LogLevel, source: string, message: string, data?: any) {
    if (!this.enabled) return;
    const entry = { level, message, data, timestamp: new Date(), source };
    this.logs.push(entry);
    if (this.logs.length > 1000) this.logs.shift();
    if (level === 'error') console.error(`[${source}] ${message}`, data);
  }

  getLogs(filter?: { level?: LogLevel; source?: string; since?: Date }) {
    return this.logs.filter(l =>
      (!filter?.level || l.level === filter.level) &&
      (!filter?.source || l.source === filter.source) &&
      (!filter?.since || l.timestamp >= filter.since)
    );
  }

  clear() { this.logs = []; }
}

export const debugLog = DebugLogger.getInstance();
```

### API Request Inspector
```typescript
export function useAPIInspector() {
  const [requests, setRequests] = useState<APIRequest[]>([]);

  useEffect(() => {
    if (process.env.NODE_ENV !== 'development') return;
    const originalFetch = window.fetch;
    window.fetch = async (...args) => {
      const start = performance.now();
      const url = typeof args[0] === 'string' ? args[0] : (args[0] as Request).url;
      try {
        const response = await originalFetch(...args);
        const duration = performance.now() - start;
        setRequests(prev => [...prev.slice(-50), { url, method: (args[1]?.method ?? 'GET'), status: response.status, duration, timestamp: new Date() }]);
        return response;
      } catch (error) {
        setRequests(prev => [...prev.slice(-50), { url, method: (args[1]?.method ?? 'GET'), status: 0, duration: performance.now() - start, error: String(error), timestamp: new Date() }]);
        throw error;
      }
    };
    return () => { window.fetch = originalFetch; };
  }, []);

  return { requests, clear: () => setRequests([]) };
}
```
TEMPLATE
    ID_DEBUG_TOOLS_GENERATED=true
    ID_GENERATED_COUNT=$((ID_GENERATED_COUNT + 1))
    return 0
}

_id_analyze_runtime() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [ID-RUNTIME] ランタイム分析

```typescript
export class RuntimeAnalyzer {
  analyzeRenderPerformance(componentName: string) {
    if (process.env.NODE_ENV !== 'development') return;
    const renders: { timestamp: number; duration: number; props: Record<string, any> }[] = [];

    return {
      onRender: (duration: number, props: Record<string, any>) => {
        renders.push({ timestamp: Date.now(), duration, props });
        if (renders.length > 1) {
          const avgDuration = renders.reduce((s, r) => s + r.duration, 0) / renders.length;
          if (avgDuration > 16) {
            debugLog.log('warn', 'RuntimeAnalyzer', `${componentName}: avg render ${avgDuration.toFixed(1)}ms (>16ms target)`, { renders: renders.length });
          }
        }
      },
      getStats: () => ({
        component: componentName, totalRenders: renders.length,
        avgDuration: renders.reduce((s, r) => s + r.duration, 0) / renders.length,
        maxDuration: Math.max(...renders.map(r => r.duration)),
      }),
    };
  }

  detectMemoryLeaks() {
    if (typeof performance === 'undefined' || !performance.memory) return null;
    const mem = (performance as any).memory;
    return { usedJSHeapSize: mem.usedJSHeapSize, totalJSHeapSize: mem.totalJSHeapSize,
      usagePercent: (mem.usedJSHeapSize / mem.totalJSHeapSize) * 100 };
  }
}
```
TEMPLATE
    ID_RUNTIME_ANALYZED=true
    ID_GENERATED_COUNT=$((ID_GENERATED_COUNT + 1))
    return 0
}

_id_suggest_fix() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [ID-FIX] 修正提案エンジン

```typescript
interface FixSuggestion { issue: string; severity: 'error' | 'warning' | 'info'; suggestion: string; autoFixable: boolean; fix?: () => void; }

const ERROR_PATTERNS: { pattern: RegExp; suggestion: string; severity: 'error' | 'warning' }[] = [
  { pattern: /Cannot read properties of (undefined|null)/, suggestion: 'Optional chaining (?.) を使用するか、nullチェックを追加してください', severity: 'error' },
  { pattern: /Failed to fetch/, suggestion: 'APIエンドポイントの存在確認、CORS設定、ネットワーク接続を確認してください', severity: 'error' },
  { pattern: /Hydration failed/, suggestion: 'サーバーとクライアントのレンダリング結果が不一致です。useEffectで分岐するか、suppressHydrationWarningを検討してください', severity: 'error' },
  { pattern: /Too many re-renders/, suggestion: 'useEffectの依存配列を確認するか、setState呼び出しの条件を見直してください', severity: 'error' },
  { pattern: /Each child in a list should have a unique "key"/, suggestion: 'map()内の要素にユニークなkey propを追加してください', severity: 'warning' },
];

export function analyzeError(error: Error): FixSuggestion[] {
  const suggestions: FixSuggestion[] = [];
  for (const pattern of ERROR_PATTERNS) {
    if (pattern.pattern.test(error.message)) {
      suggestions.push({ issue: error.message, severity: pattern.severity, suggestion: pattern.suggestion, autoFixable: false });
    }
  }
  return suggestions;
}
```
TEMPLATE
    ID_FIX_SUGGESTED=true
    ID_GENERATED_COUNT=$((ID_GENERATED_COUNT + 1))
    return 0
}

_id_generate_panel() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [ID-PANEL] デバッグパネルUI

```tsx
'use client';
export function DebugPanel() {
  const [isOpen, setIsOpen] = useState(false);
  const [tab, setTab] = useState<'logs' | 'network' | 'state'>('logs');
  const { requests } = useAPIInspector();

  if (process.env.NODE_ENV !== 'development') return null;

  return (
    <>
      <button onClick={() => setIsOpen(!isOpen)} className="fixed bottom-4 right-4 z-[9999] bg-black text-white rounded-full w-10 h-10 flex items-center justify-center">
        {isOpen ? 'x' : 'D'}
      </button>
      {isOpen && (
        <div className="fixed bottom-16 right-4 w-[600px] h-[400px] bg-background border shadow-xl rounded-lg z-[9998] flex flex-col">
          <div className="flex border-b">
            {(['logs', 'network', 'state'] as const).map(t => (
              <button key={t} onClick={() => setTab(t)} className={cn("px-4 py-2 text-sm", tab === t && "border-b-2 border-primary font-bold")}>{t}</button>
            ))}
          </div>
          <div className="flex-1 overflow-auto p-2 font-mono text-xs">
            {tab === 'network' && requests.map((r, i) => (
              <div key={i} className={cn("py-1", r.status >= 400 && "text-red-500")}>
                <span className="text-muted-foreground">{r.method}</span> {r.url} <span>{r.status}</span> <span>{r.duration.toFixed(0)}ms</span>
              </div>
            ))}
          </div>
        </div>
      )}
    </>
  );
}
```
TEMPLATE
    ID_PANEL_GENERATED=true
    ID_GENERATED_COUNT=$((ID_GENERATED_COUNT + 1))
    return 0
}

_id_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Interactive Debugger v${ID_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成数             : ${ID_GENERATED_COUNT}"
    echo -e "  デバッグツール     : ${ID_DEBUG_TOOLS_GENERATED}"
    echo -e "  ランタイム分析     : ${ID_RUNTIME_ANALYZED}"
    echo -e "  修正提案           : ${ID_FIX_SUGGESTED}"
    echo -e "  デバッグパネル     : ${ID_PANEL_GENERATED}"
}

_id_score() {
    local score=30
    [[ "$ID_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$ID_DEBUG_TOOLS_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ID_RUNTIME_ANALYZED" == "true" ]] && score=$((score + 15))
    [[ "$ID_FIX_SUGGESTED" == "true" ]] && score=$((score + 15))
    [[ "$ID_PANEL_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "interactive-debugger" \
    --version "391.0" \
    --description "インタラクティブデバッガー（ツール/ランタイム分析/修正提案/パネル）" \
    --init "_id_init" \
    --report "_id_report" \
    --score "_id_score" \
    --enable-var "ENABLE_ID" \
    --cli-flags "--debugger:--no-debugger"
