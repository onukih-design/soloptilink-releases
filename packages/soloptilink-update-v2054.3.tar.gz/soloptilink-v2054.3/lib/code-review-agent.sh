#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v67.0 - Code Review Agent
#
# 生成コードの品質をClaude自身がレビューし、自動改善する。
# 「生成者」と「レビュアー」を分離して品質向上。
#
# 従来: Claude生成 → そのまま使用（自己チェックなし）
# v67.0: Claude生成 → 別セッションのClaudeがレビュー → 指摘を反映
#
# レビュー観点:
# 1. セキュリティ（OWASP Top 10）
# 2. パフォーマンス（N+1, メモリリーク）
# 3. 保守性（命名, 複雑度, DRY）
# 4. エラーハンドリング（網羅性）
# 5. テスタビリティ
# ============================================================

[[ -n "${_CODE_REVIEW_AGENT_LOADED:-}" ]] && return 0
_CODE_REVIEW_AGENT_LOADED=1

# --- Configuration ---
CRA_ENABLE="${CRA_ENABLE:-true}"
CRA_REVIEW_THRESHOLD="${CRA_REVIEW_THRESHOLD:-50}"  # この行数以上のファイルをレビュー
CRA_AUTO_FIX="${CRA_AUTO_FIX:-true}"
CRA_MAX_ISSUES="${CRA_MAX_ISSUES:-20}"

# --- State ---
CRA_REVIEWS_DONE=0
CRA_ISSUES_FOUND=0
CRA_ISSUES_FIXED=0
CRA_FILES_REVIEWED=0
CRA_SECURITY_ISSUES=0

# ============================================================
# 初期化
# ============================================================
cra_init() {
    CRA_REVIEWS_DONE=0
    CRA_ISSUES_FOUND=0
    CRA_ISSUES_FIXED=0
    CRA_FILES_REVIEWED=0
    CRA_SECURITY_ISSUES=0
    return 0
}

# ============================================================
# レビュープロンプト構築
# ============================================================
cra_build_review_prompt() {
    local code="$1"
    local file_path="$2"
    local language="${3:-typescript}"

    cat << 'REVIEW_PROMPT'
You are a senior code reviewer. Review the following code for issues.

## Review Checklist
1. **Security**: SQL injection, XSS, auth bypass, secrets in code, path traversal
2. **Performance**: N+1 queries, unnecessary re-renders, memory leaks, missing indexes
3. **Error Handling**: Uncaught exceptions, missing error boundaries, silent failures
4. **Maintainability**: God functions (>50 lines), magic numbers, poor naming, code duplication
5. **Correctness**: Race conditions, off-by-one, null derefs, type mismatches

## Output Format
For each issue found, output EXACTLY this format:
ISSUE|severity|line|category|description|suggested_fix

Where:
- severity: critical/high/medium/low
- line: line number (0 if unknown)
- category: security/performance/error-handling/maintainability/correctness
- description: one-line description
- suggested_fix: one-line fix suggestion

If no issues found, output: NO_ISSUES

REVIEW_PROMPT

    echo ""
    echo "## File: ${file_path} (${language})"
    echo '```'"${language}"
    echo "$code"
    echo '```'
}

# ============================================================
# コードレビュー実行
# ============================================================
cra_review_code() {
    local code="$1"
    local file_path="$2"
    local language="${3:-typescript}"

    CRA_REVIEWS_DONE=$((CRA_REVIEWS_DONE + 1))
    CRA_FILES_REVIEWED=$((CRA_FILES_REVIEWED + 1))

    local prompt
    prompt=$(cra_build_review_prompt "$code" "$file_path" "$language")

    # Haikuでレビュー（コスト効率重視）
    local -a cmd_args=()
    cmd_args+=("claude" "-p" "--dangerously-skip-permissions")
    cmd_args+=("--model" "claude-haiku-4-5-20251001")
    cmd_args+=("--fallback-model" "claude-sonnet-4-20250514")
    cmd_args+=("--max-budget-usd" "0.20")
    cmd_args+=("--output-format" "text")
    cmd_args+=("--system-prompt" "You are a code reviewer. Output ONLY the ISSUE lines or NO_ISSUES. No explanations.")
    cmd_args+=("$prompt")

    local review_output
    review_output=$(timeout 60 "${cmd_args[@]}" 2>/dev/null) || true

    # パース
    local issues=()
    while IFS= read -r line; do
        if [[ "$line" == ISSUE\|* ]]; then
            issues+=("$line")
            CRA_ISSUES_FOUND=$((CRA_ISSUES_FOUND + 1))

            # セキュリティ問題カウント
            if echo "$line" | grep -qi "security"; then
                CRA_SECURITY_ISSUES=$((CRA_SECURITY_ISSUES + 1))
            fi
        fi
    done <<< "$review_output"

    # 結果出力
    if [[ ${#issues[@]} -eq 0 ]]; then
        echo "NO_ISSUES"
    else
        printf '%s\n' "${issues[@]}"
    fi
}

# ============================================================
# レビュー結果から修正プロンプトを生成
# ============================================================
cra_build_fix_prompt() {
    local file_path="$1"
    local review_output="$2"
    local original_code="$3"

    local prompt="# Code Review Fix Request\n\n"
    prompt+="## File: ${file_path}\n\n"
    prompt+="## Issues Found:\n"

    while IFS='|' read -r _ severity line category desc fix; do
        [[ -z "$severity" ]] && continue
        prompt+="- [${severity}] Line ${line} (${category}): ${desc}\n"
        prompt+="  Fix: ${fix}\n"
    done <<< "$review_output"

    prompt+="\n## Original Code:\n\`\`\`\n${original_code}\n\`\`\`\n"
    prompt+="\n## Instructions:\n"
    prompt+="1. Fix ALL listed issues\n"
    prompt+="2. Do NOT change code that wasn't flagged\n"
    prompt+="3. Output the COMPLETE fixed file\n"

    echo -e "$prompt"
}

# ============================================================
# レビュー＋自動修正パイプライン
# ============================================================
cra_review_and_fix() {
    local file_path="$1"

    if [[ ! -f "$file_path" ]]; then
        echo "ERROR: File not found: $file_path" >&2
        return 1
    fi

    local code
    code=$(cat "$file_path")

    # 行数チェック
    local line_count
    line_count=$(wc -l < "$file_path" | tr -d ' ')
    if [[ $line_count -lt $CRA_REVIEW_THRESHOLD ]]; then
        return 0  # 小さいファイルはスキップ
    fi

    # 言語検出
    local lang="typescript"
    case "$file_path" in
        *.py)    lang="python" ;;
        *.swift) lang="swift" ;;
        *.go)    lang="go" ;;
        *.rs)    lang="rust" ;;
        *.js)    lang="javascript" ;;
        *.jsx)   lang="jsx" ;;
        *.tsx)   lang="tsx" ;;
    esac

    # レビュー実行
    local review_result
    review_result=$(cra_review_code "$code" "$file_path" "$lang")

    if [[ "$review_result" == "NO_ISSUES" ]]; then
        echo -e "  ${GREEN:-}✅ ${file_path}: レビューOK${NC:-}" >&2
        return 0
    fi

    local issue_count
    issue_count=$(echo "$review_result" | grep -c "^ISSUE|" || true)
    echo -e "  ${YELLOW:-}⚠️ ${file_path}: ${issue_count}件の指摘${NC:-}" >&2

    # 自動修正
    if [[ "${CRA_AUTO_FIX}" == "true" ]]; then
        local fix_prompt
        fix_prompt=$(cra_build_fix_prompt "$file_path" "$review_result" "$code")

        # Tool-Aware連携で直接ファイル修正
        if type -t tag_read_and_fix &>/dev/null && [[ "${TAG_ENABLE_TOOLS:-false}" == "true" ]]; then
            tag_read_and_fix "$file_path" "$fix_prompt" "$(dirname "$file_path")"
        else
            # 従来方式: 修正コードを出力
            local -a cmd_args=()
            cmd_args+=("claude" "-p" "--dangerously-skip-permissions")
            cmd_args+=("--model" "claude-sonnet-4-20250514")
            cmd_args+=("--max-budget-usd" "0.50")
            cmd_args+=("--output-format" "text")
            cmd_args+=("$fix_prompt")

            local fixed_code
            fixed_code=$(timeout 120 "${cmd_args[@]}" 2>/dev/null) || true

            if [[ -n "$fixed_code" ]]; then
                echo "$fixed_code" > "$file_path"
                CRA_ISSUES_FIXED=$((CRA_ISSUES_FIXED + issue_count))
            fi
        fi
    fi

    return 0
}

# ============================================================
# ディレクトリ全体のレビュー
# ============================================================
cra_review_directory() {
    local dir="$1"
    local extensions="${2:-ts,tsx,js,jsx,py}"

    echo -e "${BOLD:-}[Code Review] ${dir} をレビュー中...${NC:-}" >&2

    local IFS=','
    for ext in $extensions; do
        while IFS= read -r -d '' file; do
            cra_review_and_fix "$file"
        done < <(find "$dir" -name "*.${ext}" -not -path "*/node_modules/*" -not -path "*/.next/*" -print0 2>/dev/null)
    done

    echo -e "${GREEN:-}[Code Review] 完了: ${CRA_FILES_REVIEWED}ファイル, ${CRA_ISSUES_FOUND}指摘, ${CRA_ISSUES_FIXED}修正${NC:-}" >&2
}

# ============================================================
# レポート / スコア
# ============================================================
cra_report() {
    echo -e "\n  ${BOLD:-}═══ Code Review Agent v67.0 レポート ═══${NC:-}"
    echo -e "  レビュー実行回数   : ${CRA_REVIEWS_DONE}"
    echo -e "  レビュー済みファイル: ${CRA_FILES_REVIEWED}"
    echo -e "  検出した問題数     : ${CRA_ISSUES_FOUND}"
    echo -e "  自動修正数         : ${CRA_ISSUES_FIXED}"
    echo -e "  セキュリティ問題   : ${CRA_SECURITY_ISSUES}"
}

cra_score() {
    if [[ $CRA_REVIEWS_DONE -eq 0 ]]; then
        echo "50"
    elif [[ $CRA_ISSUES_FOUND -eq 0 ]]; then
        echo "100"
    elif [[ $CRA_ISSUES_FOUND -gt 0 && $CRA_ISSUES_FIXED -eq $CRA_ISSUES_FOUND ]]; then
        echo "90"
    else
        echo "$(( CRA_ISSUES_FIXED * 100 / (CRA_ISSUES_FOUND + 1) ))"
    fi
}

# ============================================================
# v59.0: Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "code-review-agent" \
        --version "67.0" \
        --description "生成コード自動レビュー×OWASP/パフォ/保守性×自動修正" \
        --init "cra_init" \
        --report "cra_report" \
        --score "cra_score" \
        --enable-var "ENABLE_CODE_REVIEW_AGENT" \
        --cli-flags "--code-review:--no-code-review"
fi

# v2003.1: source時のexit codeを確実に0にする
true
