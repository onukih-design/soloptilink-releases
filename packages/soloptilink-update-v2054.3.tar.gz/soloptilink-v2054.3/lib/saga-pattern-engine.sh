#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v288.0 - Saga Pattern Engine
# =============================================================================
# Sagaオーケストレーター自動生成。注文処理・決済・在庫管理など複数サービスに
# またがるトランザクションの協調と補償(ロールバック)を自動構築する。
#
# 機能一覧:
#   _spe_generate_saga          - Sagaオーケストレーター生成
#   _spe_generate_compensations - 補償アクション生成
#   _spe_generate_saga_log      - Saga実行ログ生成
#
# 全globals: SPE_ prefix
# =============================================================================

[[ -n "${_SPE_LOADED:-}" ]] && return 0; _SPE_LOADED=1

declare -g SPE_VERSION="288.0"
declare -g SPE_GENERATED=0
declare -g SPE_ERRORS=0
declare -g SPE_FILES_WRITTEN=0

spe_init() { SPE_GENERATED=0; SPE_ERRORS=0; SPE_FILES_WRITTEN=0; return 0; }

_spe_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then SPE_FILES_WRITTEN=$((SPE_FILES_WRITTEN + 1)); echo "  [spe] wrote: $filepath" >&2
    else SPE_ERRORS=$((SPE_ERRORS + 1)); fi
}

_spe_log() { echo -e "  ${GREEN:-\033[0;32m}[SPE]${NC:-\033[0m} $*" >&2; }

# =============================================================================
# _spe_generate_saga - 具体的なSagaオーケストレーター生成
# =============================================================================
_spe_generate_saga() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _spe_log "Generating saga orchestrator..."

    local saga_ts
    saga_ts=$(cat <<'SAGAEOF'
// =============================================================================
// Order Processing Saga
// Orchestrates: CreateOrder -> ReserveInventory -> ProcessPayment -> ConfirmOrder
// Compensations: CancelOrder <- ReleaseInventory <- RefundPayment
// =============================================================================
import { z } from 'zod';

// --- Saga Context ---
export const OrderSagaContextSchema = z.object({
  orderId: z.string(),
  userId: z.string(),
  items: z.array(z.object({
    productId: z.string(),
    quantity: z.number().int().positive(),
    price: z.number().positive(),
  })),
  totalAmount: z.number().positive(),
  paymentMethodId: z.string(),
  // Populated during execution
  reservationId: z.string().optional(),
  paymentId: z.string().optional(),
  status: z.enum(['pending', 'inventory_reserved', 'payment_processed', 'confirmed', 'failed', 'compensated']).default('pending'),
  error: z.string().optional(),
});

export type OrderSagaContext = z.infer<typeof OrderSagaContextSchema>;

// --- Step Interface ---
interface SagaStep {
  name: string;
  execute(ctx: OrderSagaContext): Promise<OrderSagaContext>;
  compensate(ctx: OrderSagaContext): Promise<OrderSagaContext>;
}

// --- Step 1: Create Order ---
const createOrderStep: SagaStep = {
  name: 'CreateOrder',
  async execute(ctx) {
    console.log(`[saga] Creating order for user: ${ctx.userId}`);
    // In real implementation: await orderService.create(ctx);
    return { ...ctx, status: 'pending' };
  },
  async compensate(ctx) {
    console.log(`[saga] Cancelling order: ${ctx.orderId}`);
    // await orderService.cancel(ctx.orderId);
    return { ...ctx, status: 'compensated' };
  },
};

// --- Step 2: Reserve Inventory ---
const reserveInventoryStep: SagaStep = {
  name: 'ReserveInventory',
  async execute(ctx) {
    console.log(`[saga] Reserving inventory for ${ctx.items.length} items`);
    // const reservation = await inventoryService.reserve(ctx.items);
    const reservationId = crypto.randomUUID();
    return { ...ctx, reservationId, status: 'inventory_reserved' };
  },
  async compensate(ctx) {
    if (ctx.reservationId) {
      console.log(`[saga] Releasing inventory reservation: ${ctx.reservationId}`);
      // await inventoryService.release(ctx.reservationId);
    }
    return ctx;
  },
};

// --- Step 3: Process Payment ---
const processPaymentStep: SagaStep = {
  name: 'ProcessPayment',
  async execute(ctx) {
    console.log(`[saga] Processing payment: ${ctx.totalAmount}`);
    // const payment = await paymentService.charge(ctx);
    const paymentId = crypto.randomUUID();
    return { ...ctx, paymentId, status: 'payment_processed' };
  },
  async compensate(ctx) {
    if (ctx.paymentId) {
      console.log(`[saga] Refunding payment: ${ctx.paymentId}`);
      // await paymentService.refund(ctx.paymentId);
    }
    return ctx;
  },
};

// --- Step 4: Confirm Order ---
const confirmOrderStep: SagaStep = {
  name: 'ConfirmOrder',
  async execute(ctx) {
    console.log(`[saga] Confirming order: ${ctx.orderId}`);
    // await orderService.confirm(ctx.orderId);
    // await notificationService.sendOrderConfirmation(ctx.userId, ctx.orderId);
    return { ...ctx, status: 'confirmed' };
  },
  async compensate(ctx) {
    console.log(`[saga] Reverting order confirmation: ${ctx.orderId}`);
    return ctx;
  },
};

// --- Saga Executor ---
export class OrderProcessingSaga {
  private steps: SagaStep[] = [
    createOrderStep,
    reserveInventoryStep,
    processPaymentStep,
    confirmOrderStep,
  ];

  async execute(ctx: OrderSagaContext): Promise<{
    success: boolean;
    context: OrderSagaContext;
    executedSteps: string[];
    compensatedSteps: string[];
  }> {
    const validated = OrderSagaContextSchema.parse(ctx);
    let current = { ...validated };
    const executedSteps: string[] = [];
    const compensatedSteps: string[] = [];

    for (const step of this.steps) {
      try {
        current = await step.execute(current);
        executedSteps.push(step.name);
        console.log(`[saga] Step '${step.name}' completed`);
      } catch (error: any) {
        console.error(`[saga] Step '${step.name}' failed: ${error.message}`);
        current = { ...current, status: 'failed', error: error.message };

        // Compensate in reverse order
        for (const completedStep of [...executedSteps].reverse()) {
          const stepDef = this.steps.find((s) => s.name === completedStep)!;
          try {
            current = await stepDef.compensate(current);
            compensatedSteps.push(completedStep);
          } catch (compErr: any) {
            console.error(`[saga] Compensation '${completedStep}' failed: ${compErr.message}`);
          }
        }

        return { success: false, context: current, executedSteps, compensatedSteps };
      }
    }

    return { success: true, context: current, executedSteps, compensatedSteps };
  }
}
SAGAEOF
)
    _spe_write_file "${project_dir}/src/lib/saga/order-saga.ts" "$saga_ts"
    SPE_GENERATED=$((SPE_GENERATED + 1))
    return 0
}

# =============================================================================
# _spe_generate_compensations
# =============================================================================
_spe_generate_compensations() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _spe_log "Generating compensation actions..."

    local comp_ts
    comp_ts=$(cat <<'COMPEOF'
// =============================================================================
// Compensation Actions Registry
// Defines rollback actions for each saga step
// =============================================================================

export interface CompensationAction {
  stepName: string;
  description: string;
  maxRetries: number;
  timeoutMs: number;
  execute: (context: Record<string, any>) => Promise<void>;
}

export const compensationActions: CompensationAction[] = [
  {
    stepName: 'CancelOrder',
    description: 'Set order status to cancelled',
    maxRetries: 3,
    timeoutMs: 5000,
    execute: async (ctx) => {
      console.log(`[compensation] Cancelling order: ${ctx.orderId}`);
      // Implementation: update order status in DB
    },
  },
  {
    stepName: 'ReleaseInventory',
    description: 'Release reserved inventory back to available stock',
    maxRetries: 5,
    timeoutMs: 10000,
    execute: async (ctx) => {
      console.log(`[compensation] Releasing inventory: ${ctx.reservationId}`);
      // Implementation: release stock reservation
    },
  },
  {
    stepName: 'RefundPayment',
    description: 'Issue refund for processed payment',
    maxRetries: 3,
    timeoutMs: 30000,
    execute: async (ctx) => {
      console.log(`[compensation] Refunding payment: ${ctx.paymentId}`);
      // Implementation: call payment provider refund API
    },
  },
  {
    stepName: 'RevertShipment',
    description: 'Cancel shipment if not yet dispatched',
    maxRetries: 2,
    timeoutMs: 10000,
    execute: async (ctx) => {
      console.log(`[compensation] Reverting shipment: ${ctx.shipmentId}`);
      // Implementation: cancel shipment with carrier
    },
  },
];

export async function executeCompensation(
  stepName: string,
  context: Record<string, any>
): Promise<{ success: boolean; error?: string }> {
  const action = compensationActions.find((a) => a.stepName === stepName);
  if (!action) return { success: false, error: `No compensation found for: ${stepName}` };

  for (let attempt = 1; attempt <= action.maxRetries; attempt++) {
    try {
      await Promise.race([
        action.execute(context),
        new Promise((_, reject) => setTimeout(() => reject(new Error('Timeout')), action.timeoutMs)),
      ]);
      return { success: true };
    } catch (err: any) {
      if (attempt === action.maxRetries) {
        return { success: false, error: `Compensation '${stepName}' failed after ${action.maxRetries} attempts: ${err.message}` };
      }
      await new Promise((r) => setTimeout(r, 1000 * attempt));
    }
  }
  return { success: false, error: 'Unreachable' };
}
COMPEOF
)
    _spe_write_file "${project_dir}/src/lib/saga/compensations.ts" "$comp_ts"
    SPE_GENERATED=$((SPE_GENERATED + 1))
    return 0
}

# =============================================================================
# _spe_generate_saga_log
# =============================================================================
_spe_generate_saga_log() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _spe_log "Generating saga execution log..."

    local log_ts
    log_ts=$(cat <<'LOGEOF'
// =============================================================================
// Saga Execution Log
// Persistent log of all saga step executions for debugging and recovery
// =============================================================================

export interface SagaLogEntry {
  id: string;
  sagaId: string;
  sagaType: string;
  stepName: string;
  action: 'execute' | 'compensate';
  status: 'started' | 'completed' | 'failed';
  context: Record<string, unknown>;
  error?: string;
  durationMs: number;
  timestamp: string;
}

class SagaLogger {
  private entries: SagaLogEntry[] = [];

  log(entry: Omit<SagaLogEntry, 'id' | 'timestamp'>): string {
    const id = crypto.randomUUID();
    const full: SagaLogEntry = { ...entry, id, timestamp: new Date().toISOString() };
    this.entries.push(full);

    const icon = entry.status === 'completed' ? 'OK' : entry.status === 'failed' ? 'FAIL' : 'START';
    console.log(`[saga-log] [${icon}] ${entry.sagaType}/${entry.stepName} (${entry.action}) - ${entry.durationMs}ms`);
    return id;
  }

  getBySagaId(sagaId: string): SagaLogEntry[] {
    return this.entries.filter((e) => e.sagaId === sagaId).sort((a, b) => a.timestamp.localeCompare(b.timestamp));
  }

  getFailedSagas(): SagaLogEntry[] {
    return this.entries.filter((e) => e.status === 'failed');
  }

  getRecent(limit = 100): SagaLogEntry[] {
    return this.entries.slice(-limit);
  }

  getStats(): { total: number; completed: number; failed: number; avgDurationMs: number } {
    const total = this.entries.length;
    const completed = this.entries.filter((e) => e.status === 'completed').length;
    const failed = this.entries.filter((e) => e.status === 'failed').length;
    const avgDurationMs = total > 0 ? Math.round(this.entries.reduce((s, e) => s + e.durationMs, 0) / total) : 0;
    return { total, completed, failed, avgDurationMs };
  }

  clear(): void { this.entries = []; }
}

export const sagaLogger = new SagaLogger();
LOGEOF
)
    _spe_write_file "${project_dir}/src/lib/saga/saga-log.ts" "$log_ts"
    SPE_GENERATED=$((SPE_GENERATED + 1))
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
spe_report() {
    echo -e "\n  ${BOLD:-}=== saga-pattern-engine v${SPE_VERSION} ===${NC:-}"
    echo -e "  生成数: ${SPE_GENERATED}"; echo -e "  エラー: ${SPE_ERRORS}"
}

spe_score() {
    if [[ ${SPE_GENERATED} -ge 3 ]] && [[ ${SPE_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${SPE_GENERATED} -gt 0 ]] && [[ ${SPE_ERRORS} -eq 0 ]]; then echo "85"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "saga-pattern-engine" --version "${SPE_VERSION}" \
        --description "Sagaオーケストレーター×補償アクション×実行ログ" \
        --init "spe_init" --report "spe_report" --score "spe_score" \
        --enable-var "ENABLE_SAGA_PATTERN" --cli-flags "--saga-pattern:--no-saga-pattern"
fi

# v2003.1: source時のexit codeを確実に0にする
true
