#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v243.0 - SEO Optimizer
# =============================================================================
# メタタグ、構造化データ、サイトマップ、robots.txt を自動生成し、
# 一般的な SEO 問題を検出・修正する。
#
# 機能:
#   - 全ページのメタタグ生成（title, description, og:*, twitter:*）
#   - JSON-LD 構造化データ生成
#   - sitemap.xml 自動生成
#   - robots.txt 生成
#   - SEO 問題検出・レポート
#
# 全globals: SO_ prefix
# =============================================================================

[[ -n "${_SEO_OPTIMIZER_LOADED:-}" ]] && return 0
_SEO_OPTIMIZER_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g SO_VERSION="243.0"
declare -g SO_INITIALIZED=false
declare -g SO_META_GENERATED=0
declare -g SO_STRUCTURED_DATA_GENERATED=0
declare -g SO_ISSUES_FOUND=0
declare -g SO_PROJECT_DIR=""
declare -g SO_SITE_URL=""
declare -g SO_SITE_NAME=""
declare -g SO_LOG_PREFIX="[SEO]"

# =============================================================================
# ログユーティリティ
# =============================================================================
_so_log() { echo -e "  ${CLR_CYAN:-\033[0;36m}${SO_LOG_PREFIX}${CLR_NC:-\033[0m} $*" >&2; }
_so_success() { echo -e "  ${CLR_GREEN:-\033[0;32m}${SO_LOG_PREFIX} OK${CLR_NC:-\033[0m} $*" >&2; }
_so_warn() { echo -e "  ${CLR_YELLOW:-\033[0;33m}${SO_LOG_PREFIX} WARN${CLR_NC:-\033[0m} $*" >&2; }
_so_error() { echo -e "  ${CLR_RED:-\033[0;31m}${SO_LOG_PREFIX} ERROR${CLR_NC:-\033[0m} $*" >&2; }

# =============================================================================
# 初期化
# =============================================================================
so_init() {
    SO_INITIALIZED=true
    SO_META_GENERATED=0
    SO_STRUCTURED_DATA_GENERATED=0
    SO_ISSUES_FOUND=0
    SO_PROJECT_DIR="${PROJECT_DIR:-.}"
    SO_SITE_URL="${SITE_URL:-https://example.com}"
    SO_SITE_NAME="${SITE_NAME:-SoloptiLinkAI}"
    return 0
}

# =============================================================================
# メタタグ生成
# =============================================================================
# Next.js App Router の metadata export を生成。
# title, description, OpenGraph, Twitter Card を含む。
#
# 使い方: _so_generate_meta_tags <output_dir> [site_name] [site_url]
# =============================================================================
_so_generate_meta_tags() {
    local output_dir="${1:-${SO_PROJECT_DIR}/lib}"
    local site_name="${2:-${SO_SITE_NAME}}"
    local site_url="${3:-${SO_SITE_URL}}"
    local meta_file="${output_dir}/seo.ts"

    [[ "$SO_INITIALIZED" != "true" ]] && { _so_error "未初期化"; return 1; }

    _so_log "メタタグヘルパー生成中: ${meta_file}"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$meta_file" <<TYPESCRIPT
// =============================================================================
// SoloptiLinkAI v243.0 - SEO Metadata Helper
// Next.js App Router metadata API 対応
// =============================================================================

import type { Metadata, Viewport } from 'next';

const SITE_NAME = '${site_name}';
const SITE_URL = '${site_url}';

export const viewport: Viewport = {
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
  themeColor: [
    { media: '(prefers-color-scheme: light)', color: '#ffffff' },
    { media: '(prefers-color-scheme: dark)', color: '#0f172a' },
  ],
};

interface PageSEOProps {
  title: string;
  description: string;
  path?: string;
  ogImage?: string;
  noIndex?: boolean;
  keywords?: string[];
}

export function generatePageMetadata({
  title,
  description,
  path = '',
  ogImage,
  noIndex = false,
  keywords = [],
}: PageSEOProps): Metadata {
  const url = \`\${SITE_URL}\${path}\`;
  const fullTitle = \`\${title} | \${SITE_NAME}\`;
  const image = ogImage || \`\${SITE_URL}/og-image.png\`;

  return {
    title: fullTitle,
    description,
    keywords: keywords.length > 0 ? keywords.join(', ') : undefined,
    authors: [{ name: SITE_NAME }],
    creator: SITE_NAME,
    publisher: SITE_NAME,
    metadataBase: new URL(SITE_URL),
    alternates: {
      canonical: url,
    },
    openGraph: {
      type: 'website',
      locale: 'ja_JP',
      url,
      title: fullTitle,
      description,
      siteName: SITE_NAME,
      images: [
        {
          url: image,
          width: 1200,
          height: 630,
          alt: title,
        },
      ],
    },
    twitter: {
      card: 'summary_large_image',
      title: fullTitle,
      description,
      images: [image],
    },
    robots: noIndex
      ? { index: false, follow: false }
      : { index: true, follow: true },
  };
}

export function generateArticleMetadata({
  title,
  description,
  path = '',
  ogImage,
  publishedTime,
  modifiedTime,
  author,
  tags = [],
}: PageSEOProps & {
  publishedTime?: string;
  modifiedTime?: string;
  author?: string;
  tags?: string[];
}): Metadata {
  const base = generatePageMetadata({ title, description, path, ogImage });
  return {
    ...base,
    openGraph: {
      ...base.openGraph,
      type: 'article',
      publishedTime,
      modifiedTime,
      authors: author ? [author] : undefined,
      tags,
    },
  };
}

// デフォルト metadata（layout.tsx 用）
export const defaultMetadata: Metadata = {
  title: {
    default: SITE_NAME,
    template: \`%s | \${SITE_NAME}\`,
  },
  description: \`\${SITE_NAME} - 次世代自律開発プラットフォーム\`,
  metadataBase: new URL(SITE_URL),
};
TYPESCRIPT

    if [[ -f "$meta_file" ]]; then
        SO_META_GENERATED=$((SO_META_GENERATED + 1))
        _so_success "メタタグヘルパー生成完了: ${meta_file}"
        return 0
    else
        _so_error "メタタグ生成失敗"
        return 1
    fi
}

# =============================================================================
# JSON-LD 構造化データ生成
# =============================================================================
# WebSite, Organization, BreadcrumbList の JSON-LD を生成。
# Google リッチリザルト対応。
#
# 使い方: _so_generate_structured_data <output_dir>
# =============================================================================
_so_generate_structured_data() {
    local output_dir="${1:-${SO_PROJECT_DIR}/components}"
    local jsonld_file="${output_dir}/JsonLd.tsx"

    [[ "$SO_INITIALIZED" != "true" ]] && { _so_error "未初期化"; return 1; }

    _so_log "JSON-LD 構造化データコンポーネント生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$jsonld_file" <<'TSX_JSONLD'
// =============================================================================
// SoloptiLinkAI v243.0 - JSON-LD Structured Data Components
// =============================================================================

import React from 'react';

interface JsonLdProps {
  data: Record<string, unknown>;
}

export function JsonLd({ data }: JsonLdProps) {
  return (
    <script
      type="application/ld+json"
      dangerouslySetInnerHTML={{ __html: JSON.stringify(data) }}
    />
  );
}

// --- WebSite ---
interface WebSiteJsonLdProps {
  name: string;
  url: string;
  description?: string;
  searchUrl?: string;
}

export function WebSiteJsonLd({ name, url, description, searchUrl }: WebSiteJsonLdProps) {
  const data: Record<string, unknown> = {
    '@context': 'https://schema.org',
    '@type': 'WebSite',
    name,
    url,
    description,
  };

  if (searchUrl) {
    data.potentialAction = {
      '@type': 'SearchAction',
      target: { '@type': 'EntryPoint', urlTemplate: searchUrl },
      'query-input': 'required name=search_term_string',
    };
  }

  return <JsonLd data={data} />;
}

// --- Organization ---
interface OrganizationJsonLdProps {
  name: string;
  url: string;
  logo?: string;
  sameAs?: string[];
  contactEmail?: string;
}

export function OrganizationJsonLd({
  name, url, logo, sameAs, contactEmail,
}: OrganizationJsonLdProps) {
  const data: Record<string, unknown> = {
    '@context': 'https://schema.org',
    '@type': 'Organization',
    name,
    url,
    logo,
    sameAs,
  };

  if (contactEmail) {
    data.contactPoint = {
      '@type': 'ContactPoint',
      email: contactEmail,
      contactType: 'customer service',
    };
  }

  return <JsonLd data={data} />;
}

// --- BreadcrumbList ---
interface BreadcrumbItem {
  name: string;
  url: string;
}

interface BreadcrumbJsonLdProps {
  items: BreadcrumbItem[];
}

export function BreadcrumbJsonLd({ items }: BreadcrumbJsonLdProps) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'BreadcrumbList',
    itemListElement: items.map((item, index) => ({
      '@type': 'ListItem',
      position: index + 1,
      name: item.name,
      item: item.url,
    })),
  };

  return <JsonLd data={data} />;
}

// --- FAQ ---
interface FAQItem {
  question: string;
  answer: string;
}

interface FAQJsonLdProps {
  items: FAQItem[];
}

export function FAQJsonLd({ items }: FAQJsonLdProps) {
  const data = {
    '@context': 'https://schema.org',
    '@type': 'FAQPage',
    mainEntity: items.map((item) => ({
      '@type': 'Question',
      name: item.question,
      acceptedAnswer: {
        '@type': 'Answer',
        text: item.answer,
      },
    })),
  };

  return <JsonLd data={data} />;
}

// --- SoftwareApplication ---
interface SoftwareJsonLdProps {
  name: string;
  operatingSystem: string;
  applicationCategory: string;
  offers?: { price: string; currency: string };
}

export function SoftwareJsonLd({
  name, operatingSystem, applicationCategory, offers,
}: SoftwareJsonLdProps) {
  const data: Record<string, unknown> = {
    '@context': 'https://schema.org',
    '@type': 'SoftwareApplication',
    name,
    operatingSystem,
    applicationCategory,
  };

  if (offers) {
    data.offers = {
      '@type': 'Offer',
      price: offers.price,
      priceCurrency: offers.currency,
    };
  }

  return <JsonLd data={data} />;
}
TSX_JSONLD

    if [[ -f "$jsonld_file" ]]; then
        SO_STRUCTURED_DATA_GENERATED=$((SO_STRUCTURED_DATA_GENERATED + 1))
        _so_success "JSON-LD コンポーネント生成完了: ${jsonld_file}"
        return 0
    else
        _so_error "JSON-LD 生成失敗"
        return 1
    fi
}

# =============================================================================
# sitemap.xml 生成
# =============================================================================
_so_generate_sitemap() {
    local output_dir="${1:-${SO_PROJECT_DIR}/app}"
    local sitemap_file="${output_dir}/sitemap.ts"
    local site_url="${2:-${SO_SITE_URL}}"

    [[ "$SO_INITIALIZED" != "true" ]] && { _so_error "未初期化"; return 1; }

    _so_log "sitemap.ts 生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$sitemap_file" <<SITEMAP_TS
// =============================================================================
// SoloptiLinkAI v243.0 - Dynamic Sitemap Generator
// Next.js App Router sitemap.ts
// =============================================================================

import type { MetadataRoute } from 'next';

const BASE_URL = '${site_url}';

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  // 静的ページ
  const staticPages: MetadataRoute.Sitemap = [
    { url: BASE_URL, lastModified: new Date(), changeFrequency: 'daily', priority: 1.0 },
    { url: \`\${BASE_URL}/about\`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.8 },
    { url: \`\${BASE_URL}/pricing\`, lastModified: new Date(), changeFrequency: 'weekly', priority: 0.9 },
    { url: \`\${BASE_URL}/contact\`, lastModified: new Date(), changeFrequency: 'monthly', priority: 0.7 },
    { url: \`\${BASE_URL}/docs\`, lastModified: new Date(), changeFrequency: 'weekly', priority: 0.8 },
  ];

  // 動的ページ（DB から取得する場合のテンプレート）
  // const dynamicPages = await getDynamicPages();

  return [...staticPages];
}
SITEMAP_TS

    if [[ -f "$sitemap_file" ]]; then
        _so_success "sitemap.ts 生成完了: ${sitemap_file}"
        return 0
    else
        _so_error "sitemap.ts 生成失敗"
        return 1
    fi
}

# =============================================================================
# robots.txt 生成
# =============================================================================
_so_generate_robots() {
    local output_dir="${1:-${SO_PROJECT_DIR}/app}"
    local robots_file="${output_dir}/robots.ts"
    local site_url="${2:-${SO_SITE_URL}}"

    [[ "$SO_INITIALIZED" != "true" ]] && { _so_error "未初期化"; return 1; }

    _so_log "robots.ts 生成中"

    mkdir -p "$output_dir" 2>/dev/null || true

    cat > "$robots_file" <<ROBOTS_TS
// =============================================================================
// SoloptiLinkAI v243.0 - Robots.txt Generator
// =============================================================================

import type { MetadataRoute } from 'next';

export default function robots(): MetadataRoute.Robots {
  return {
    rules: [
      {
        userAgent: '*',
        allow: '/',
        disallow: ['/api/', '/admin/', '/login', '/register', '/_next/'],
      },
      {
        userAgent: 'Googlebot',
        allow: '/',
        disallow: ['/api/', '/admin/'],
      },
    ],
    sitemap: '${site_url}/sitemap.xml',
    host: '${site_url}',
  };
}
ROBOTS_TS

    if [[ -f "$robots_file" ]]; then
        _so_success "robots.ts 生成完了: ${robots_file}"
        return 0
    else
        _so_error "robots.ts 生成失敗"
        return 1
    fi
}

# =============================================================================
# SEO 問題チェック
# =============================================================================
_so_check_seo_issues() {
    local project_dir="${1:-${SO_PROJECT_DIR}}"
    local issues=0
    local checked=0

    [[ "$SO_INITIALIZED" != "true" ]] && { _so_error "未初期化"; return 1; }

    _so_log "SEO 問題チェック開始: ${project_dir}"

    # TSX/JSX ページファイルを検査
    local pages=()
    if [[ -d "${project_dir}/app" ]]; then
        while IFS= read -r -d '' f; do
            pages+=("$f")
        done < <(find "${project_dir}/app" -name 'page.tsx' -o -name 'page.jsx' -print0 2>/dev/null)
    fi

    for f in "${pages[@]}"; do
        checked=$((checked + 1))
        local rel_path="${f#${project_dir}/}"

        # 1. metadata export がない
        if ! grep -qP '(?:export\s+(?:const|async\s+function)\s+(?:metadata|generateMetadata))' "$f" 2>/dev/null; then
            _so_warn "${rel_path}: metadata/generateMetadata エクスポートなし"
            issues=$((issues + 1))
        fi

        # 2. h1 タグがない（ページには h1 が1つ必要）
        if ! grep -qP '<h1\b' "$f" 2>/dev/null; then
            _so_warn "${rel_path}: <h1> タグなし"
            issues=$((issues + 1))
        fi

        # 3. 複数の h1 タグ
        local h1_count
        h1_count=$(grep -cP '<h1\b' "$f" 2>/dev/null || echo "0")
        if [[ $h1_count -gt 1 ]]; then
            _so_warn "${rel_path}: 複数の <h1> タグ (${h1_count}個)"
            issues=$((issues + 1))
        fi

        # 4. img に alt がない
        if grep -qP '<img\b(?![^>]*\balt\b)' "$f" 2>/dev/null; then
            _so_warn "${rel_path}: <img> に alt 属性なし（SEO影響）"
            issues=$((issues + 1))
        fi

        # 5. a タグに意味のないテキスト
        if grep -qP '>(?:こちら|click here|here|詳しく)<\/a>' "$f" 2>/dev/null; then
            _so_warn "${rel_path}: リンクテキストが不適切（「こちら」「click here」）"
            issues=$((issues + 1))
        fi
    done

    # layout.tsx チェック
    local layout="${project_dir}/app/layout.tsx"
    if [[ -f "$layout" ]]; then
        checked=$((checked + 1))

        # html lang 属性
        if ! grep -qP 'lang=' "$layout" 2>/dev/null; then
            _so_warn "app/layout.tsx: <html lang> 属性なし"
            issues=$((issues + 1))
        fi

        # viewport/metadata の有無
        if ! grep -qP '(?:metadata|viewport)' "$layout" 2>/dev/null; then
            _so_warn "app/layout.tsx: metadata エクスポートなし"
            issues=$((issues + 1))
        fi
    fi

    # sitemap の存在確認
    if [[ ! -f "${project_dir}/app/sitemap.ts" && ! -f "${project_dir}/app/sitemap.tsx" && ! -f "${project_dir}/public/sitemap.xml" ]]; then
        _so_warn "sitemap なし"
        issues=$((issues + 1))
    fi

    # robots の存在確認
    if [[ ! -f "${project_dir}/app/robots.ts" && ! -f "${project_dir}/public/robots.txt" ]]; then
        _so_warn "robots.txt なし"
        issues=$((issues + 1))
    fi

    SO_ISSUES_FOUND=$((SO_ISSUES_FOUND + issues))

    if [[ $issues -eq 0 ]]; then
        _so_success "SEO チェック完了: ${checked}ファイル、問題なし"
    else
        _so_warn "SEO チェック完了: ${checked}ファイル、${issues}件の問題"
    fi

    echo "$issues"
    return 0
}

# =============================================================================
# フル生成
# =============================================================================
_so_generate_full() {
    local project_dir="${1:-${SO_PROJECT_DIR}}"

    [[ "$SO_INITIALIZED" != "true" ]] && { _so_error "未初期化"; return 1; }

    _so_log "=== SEO 最適化フル生成開始 ==="

    _so_generate_meta_tags "${project_dir}/lib"
    _so_generate_structured_data "${project_dir}/components"
    _so_generate_sitemap "${project_dir}/app"
    _so_generate_robots "${project_dir}/app"
    _so_check_seo_issues "${project_dir}"

    _so_success "=== SEO 最適化フル生成完了 ==="
    return 0
}

# =============================================================================
# プロンプト注入
# =============================================================================
_so_inject_prompt() {
    cat <<'PROMPT'
## [SEO] SEO 必須ルール

### メタデータ
- 全ページに metadata/generateMetadata エクスポート必須
- title: 60文字以内、description: 155文字以内
- OpenGraph + Twitter Card 設定必須
- canonical URL 設定

### HTML 構造
- 各ページに <h1> タグを1つだけ配置
- 見出しレベル順守（h1→h2→h3）
- セマンティック HTML 使用（header, main, nav, footer, article, section）
- lang 属性を <html> に設定

### 画像
- 全 <img> に alt 属性（説明的テキスト）
- next/image コンポーネント使用推奨（サイズ最適化）

### リンク
- 意味のあるリンクテキスト（「こちら」「click here」禁止）
- 外部リンクに rel="noopener noreferrer"

### 構造化データ
- WebSite + Organization の JSON-LD 必須
- パンくずリスト（BreadcrumbList）推奨
PROMPT
}

# =============================================================================
# レポート
# =============================================================================
so_report() {
    echo -e "\n  ${BOLD:-}--- SEO Optimizer v${SO_VERSION} ---${NC:-}"
    echo -e "  メタタグ生成    : ${SO_META_GENERATED}"
    echo -e "  構造化データ    : ${SO_STRUCTURED_DATA_GENERATED}"
    echo -e "  検出問題数      : ${SO_ISSUES_FOUND}"
}

so_report_json() {
    cat <<EOF
{"module":"seo-optimizer","version":"${SO_VERSION}","meta_generated":${SO_META_GENERATED},"structured_data":${SO_STRUCTURED_DATA_GENERATED},"issues_found":${SO_ISSUES_FOUND}}
EOF
}

so_score() {
    if [[ "$SO_INITIALIZED" != "true" ]]; then echo 0; return; fi
    local score=80
    [[ $SO_META_GENERATED -gt 0 ]] && score=$((score + 10))
    [[ $SO_STRUCTURED_DATA_GENERATED -gt 0 ]] && score=$((score + 10))
    [[ $SO_ISSUES_FOUND -gt 0 ]] && score=$((score - SO_ISSUES_FOUND * 3))
    [[ $score -lt 0 ]] && score=0
    echo "$score"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "seo-optimizer" \
        --version "243.0" \
        --description "SEO メタタグ/構造化データ/サイトマップ自動生成" \
        --init "so_init" \
        --report "so_report" \
        --score "so_score" \
        --enable-var "ENABLE_SEO_OPTIMIZER" \
        --cli-flags "--seo:--no-seo"
fi

# v2003.1: source時のexit codeを確実に0にする
true
