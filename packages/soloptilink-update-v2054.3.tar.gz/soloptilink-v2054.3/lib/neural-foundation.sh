#!/usr/bin/env bash
# SoloptiLinkAI v530.0 - Neural Foundation Integration
# Bash wrapper for Python ML layer (v501-v530)
# All ML calls go through this module -> Python JSON-RPC -> ML models
#
# Usage from other modules:
#   _nf_predict_quality '{"line_count": 100, "complexity": 5}'
#   _nf_classify_error "Cannot find module 'prisma'"
#   _nf_plan_fix '{"quality_score": 0.4, "error_count": 5}'
#   _nf_record_session '{"session_id": "...", "quality_score": 0.85}'
#   _nf_check_anomaly '{"quality": 0.3, "build_time": 120}'

# Ensure _log exists (fallback if logger not loaded)
if ! declare -f _log &>/dev/null; then
    _log() { echo "[$1] $2" >&2; }
fi

NF_VERSION="530.0"
NF_PYTHON="${NF_PYTHON:-python3}"
NF_ML_DIR="${PROJECT_ROOT:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}/ml"
NF_SERVER_PID=""
NF_SERVER_IN=""
NF_SERVER_OUT=""
NF_AVAILABLE=false
NF_CALL_COUNT=0

# ─── Initialization ─────────────────────────────────────────────

_nf_init() {
    local start_time
    start_time=$(date +%s)

    # Check Python3
    if ! command -v "$NF_PYTHON" &>/dev/null; then
        _log "WARN" "[NeuralFoundation] Python3 not found, ML disabled"
        NF_AVAILABLE=false
        return 1
    fi

    # Check sklearn
    if ! "$NF_PYTHON" -c "import sklearn" &>/dev/null; then
        _log "WARN" "[NeuralFoundation] scikit-learn not installed, ML disabled"
        _log "INFO" "[NeuralFoundation] Install: pip3 install scikit-learn"
        NF_AVAILABLE=false
        return 1
    fi

    # Check ML directory
    if [[ ! -d "$NF_ML_DIR" ]]; then
        _log "WARN" "[NeuralFoundation] ML directory not found: $NF_ML_DIR"
        NF_AVAILABLE=false
        return 1
    fi

    NF_AVAILABLE=true

    local elapsed=$(( $(date +%s) - start_time ))
    _log "INFO" "[NeuralFoundation] v${NF_VERSION} initialized (${elapsed}ms)"
    return 0
}

# ─── Core RPC Call ─────────────────────────────────────────────

_nf_call() {
    # Send JSON-RPC to Python ML layer
    # Usage: _nf_call "method_name" '{"param": "value"}'
    local method="$1"
    local params="${2:-{}}"
    local timeout="${3:-10}"

    if [[ "$NF_AVAILABLE" != "true" ]]; then
        echo '{"error": "ML not available"}'
        return 1
    fi

    NF_CALL_COUNT=$((NF_CALL_COUNT + 1))

    local request
    request=$(printf '{"jsonrpc":"2.0","method":"%s","params":%s,"id":%d}' \
        "$method" "$params" "$NF_CALL_COUNT")

    local result
    result=$(echo "$request" | timeout "$timeout" "$NF_PYTHON" -c "
import sys, os
sys.path.insert(0, os.path.dirname('${NF_ML_DIR}'))
sys.path.insert(0, '${NF_ML_DIR}/..')
from ml.neural_foundation import NeuralFoundation
import json

nf = NeuralFoundation()
req = json.loads(sys.stdin.readline())
method = req['method']
params = req.get('params', {})

# High-level methods
handlers = {
    'health': lambda p: nf.health_check(),
    'predict_quality': lambda p: nf.predict_quality(p),
    'classify_error': lambda p: nf.classify_error(p.get('message', '')),
    'plan_fix': lambda p: nf.plan_fix(p),
    'record_session': lambda p: nf.record_session_end(p),
    'check_anomaly': lambda p: nf.check_anomaly(p.get('metrics', {})),
    'search_code': lambda p: nf.search_code(p.get('query', ''), p.get('top_k', 10)),
    'learning_summary': lambda p: nf.get_learning_summary(),
}

if method in handlers:
    result = handlers[method](params)
else:
    # Dispatch to sub-modules
    try:
        prefix = method.split('.')[0]
        mod_map = {}
        try:
            from ml.models import session_learner, anomaly_detector, causal_inference, embedding_engine, world_model
            mod_map = {
                'session': session_learner.handle_rpc,
                'anomaly': anomaly_detector.handle_rpc,
                'timeseries': anomaly_detector.handle_rpc,
                'causal': causal_inference.handle_rpc,
                'embedding': embedding_engine.handle_rpc,
                'transfer': embedding_engine.handle_rpc,
                'online': embedding_engine.handle_rpc,
                'world': world_model.handle_rpc,
            }
        except ImportError:
            pass
        if prefix in mod_map:
            result = mod_map[prefix](method, params)
        else:
            result = {'error': f'Unknown method: {method}'}
    except Exception as e:
        result = {'error': str(e)}

print(json.dumps({'jsonrpc': '2.0', 'result': result, 'id': req.get('id', 0)}))
" 2>/dev/null)

    if [[ $? -ne 0 ]] || [[ -z "$result" ]]; then
        echo '{"error": "ML call failed"}'
        return 1
    fi

    # Extract result from JSON-RPC response
    echo "$result" | "$NF_PYTHON" -c "
import sys, json
try:
    resp = json.loads(sys.stdin.readline())
    if 'result' in resp:
        print(json.dumps(resp['result']))
    elif 'error' in resp:
        print(json.dumps(resp['error']))
    else:
        print(json.dumps(resp))
except:
    print('{\"error\": \"parse_failed\"}')
" 2>/dev/null
}

# ─── High-Level API ────────────────────────────────────────────

_nf_predict_quality() {
    # Predict quality score for code features
    # Usage: _nf_predict_quality '{"line_count": 100, "complexity": 5}'
    _nf_call "predict_quality" "${1:-{}}"
}

_nf_classify_error() {
    # Classify an error message
    # Usage: _nf_classify_error "Cannot find module 'prisma'"
    local msg="$1"
    local escaped
    escaped=$(echo "$msg" | sed 's/"/\\"/g' | head -c 500)
    _nf_call "classify_error" "{\"message\": \"${escaped}\"}"
}

_nf_plan_fix() {
    # Use World Model + MCTS to plan optimal fix sequence
    # Usage: _nf_plan_fix '{"quality_score": 0.4, "error_count": 5, "domain": "crm"}'
    _nf_call "plan_fix" "${1:-{}}"
}

_nf_record_session() {
    # Record session completion for learning
    # Usage: _nf_record_session '{"session_id": "...", "quality_score": 0.85, ...}'
    _nf_call "record_session" "${1:-{}}"
}

_nf_check_anomaly() {
    # Check metrics for anomalies
    # Usage: _nf_check_anomaly '{"quality": 0.3, "build_time": 120}'
    _nf_call "check_anomaly" "{\"metrics\": ${1:-{}}}"
}

_nf_search_code() {
    # Semantic code search
    # Usage: _nf_search_code "authentication validation"
    local query="$1"
    local top_k="${2:-10}"
    _nf_call "search_code" "{\"query\": \"${query}\", \"top_k\": ${top_k}}"
}

_nf_health() {
    # Health check
    _nf_call "health" "{}"
}

_nf_learning_summary() {
    # Get learning progress
    _nf_call "learning_summary" "{}"
}

_nf_root_cause() {
    # Find root cause of an error
    # Usage: _nf_root_cause "error message" '["context1", "context2"]'
    local error="$1"
    local context="${2:-[]}"
    local escaped
    escaped=$(echo "$error" | sed 's/"/\\"/g' | head -c 500)
    _nf_call "causal.root_cause" "{\"error\": \"${escaped}\", \"context\": ${context}}"
}

_nf_session_predict() {
    # Predict session outcomes before starting
    # Usage: _nf_session_predict "crm" "CRM作って"
    local domain="$1"
    local prompt="$2"
    local escaped
    escaped=$(echo "$prompt" | sed 's/"/\\"/g' | head -c 500)
    _nf_call "session.predict" "{\"domain\": \"${domain}\", \"prompt\": \"${escaped}\"}"
}

# ─── Integration Hooks (called from chain.sh phases) ──────────

_nf_on_phase_start() {
    # Called at the start of each phase
    local phase="$1"
    local domain="$2"
    [[ "$NF_AVAILABLE" != "true" ]] && return 0
    # Record phase start for online learning
    _nf_call "online.update" "{\"model\": \"phase_quality\", \"features\": [0], \"target\": 0}" >/dev/null 2>&1 &
}

_nf_on_phase_end() {
    # Called at the end of each phase
    local phase="$1"
    local quality="$2"
    local errors="$3"
    [[ "$NF_AVAILABLE" != "true" ]] && return 0

    # Check for anomalies
    local anomaly_result
    anomaly_result=$(_nf_check_anomaly "{\"quality_${phase}\": ${quality:-0}, \"errors_${phase}\": ${errors:-0}}")

    local has_anomaly
    has_anomaly=$(echo "$anomaly_result" | "$NF_PYTHON" -c "
import sys, json
try:
    data = json.loads(sys.stdin.readline())
    anomalies = data.get('anomalies', [])
    print(len(anomalies))
except:
    print(0)
" 2>/dev/null)

    if [[ "${has_anomaly:-0}" -gt 0 ]]; then
        _log "WARN" "[NeuralFoundation] Anomaly detected in phase ${phase}"
    fi
}

_nf_on_error() {
    # Called when an error occurs during healing
    local error_msg="$1"
    [[ "$NF_AVAILABLE" != "true" ]] && return 0

    local classification
    classification=$(_nf_classify_error "$error_msg")

    # Extract recommended fix
    local fix
    fix=$(echo "$classification" | "$NF_PYTHON" -c "
import sys, json
try:
    data = json.loads(sys.stdin.readline())
    fix = data.get('recommended_fix', {})
    if isinstance(fix, dict):
        print(fix.get('action', 'unknown'))
    else:
        print(str(fix))
except:
    print('unknown')
" 2>/dev/null)

    _log "INFO" "[NeuralFoundation] Error classified → recommended fix: ${fix:-unknown}"
    echo "$classification"
}

_nf_on_session_end() {
    # Called when chain.sh session completes
    local session_id="$1"
    local domain="$2"
    local quality="$3"
    local errors="$4"
    local duration="$5"
    local success="$6"

    [[ "$NF_AVAILABLE" != "true" ]] && return 0

    local session_data
    session_data=$(printf '{
        "session_id": "%s",
        "timestamp": %d,
        "domain": "%s",
        "prompt": "",
        "quality_score": %s,
        "total_errors": %s,
        "total_duration": %s,
        "success": %s
    }' "$session_id" "$(date +%s)" "$domain" "${quality:-0}" \
       "${errors:-0}" "${duration:-0}" "${success:-false}")

    _nf_record_session "$session_data"
    _log "INFO" "[NeuralFoundation] Session recorded for learning"
}

# ─── Report ────────────────────────────────────────────────────

_nf_report() {
    # Generate Neural Foundation status report
    if [[ "$NF_AVAILABLE" != "true" ]]; then
        echo "Neural Foundation: DISABLED (Python/sklearn not available)"
        return
    fi

    local health
    health=$(_nf_health)

    local available
    available=$(echo "$health" | "$NF_PYTHON" -c "
import sys, json
try:
    data = json.loads(sys.stdin.readline())
    print(f\"{data.get('available_count', 0)}/{data.get('total_count', 0)} modules\")
except:
    print('unknown')
" 2>/dev/null)

    local summary
    summary=$(_nf_learning_summary)

    local sessions
    sessions=$(echo "$summary" | "$NF_PYTHON" -c "
import sys, json
try:
    data = json.loads(sys.stdin.readline())
    print(f\"{data.get('total_sessions', 0)} sessions learned\")
except:
    print('0 sessions')
" 2>/dev/null)

    echo "Neural Foundation v${NF_VERSION}: ${available}, ${sessions}, ${NF_CALL_COUNT} calls this session"
}

# ─── Module Registry ───────────────────────────────────────────

_nf_mr_register() {
    if declare -f _mr_register &>/dev/null; then
        _mr_register \
            --name "neural-foundation" \
            --version "v530.0" \
            --description "Neural Foundation - Python ML layer (quality prediction, error classification, MCTS planning, session learning)" \
            --init "_nf_init" \
            --report "_nf_report"
    fi
}

# Auto-register on source
_nf_mr_register
