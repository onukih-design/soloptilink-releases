#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v217.0 - Performance Hotspot Finder
# コード内のパフォーマンスホットスポットを静的解析で検出
#
# 問題: 生成されたコードにN+1クエリ、不要な再レンダリング、
# メモリリーク、巨大バンドル、同期ブロッキング操作が混入し、
# 本番環境でパフォーマンス劣化を引き起こす。
#
# 解決: grep/awk ベースの静的パターンマッチングで
# 6カテゴリのパフォーマンスホットスポットを検出し、
# 修正提案付きレポートを自動生成する。
#
# v217.0: Performance Hotspot Finder
# ============================================================

[[ -n "${_PHF_LOADED:-}" ]] && return 0
_PHF_LOADED=1

PHF_VERSION="217.0"
PHF_INITIALIZED=false

# --- Detection Results ---
PHF_N_PLUS_ONE_COUNT=0
PHF_UNNECESSARY_RENDER_COUNT=0
PHF_MEMORY_LEAK_COUNT=0
PHF_LARGE_BUNDLE_COUNT=0
PHF_SYNC_OP_COUNT=0
PHF_TOTAL_HOTSPOTS=0
PHF_REPORT_DETAIL=""

# --- Finding Storage ---
declare -a PHF_FINDINGS=()
declare -a PHF_FINDING_TYPES=()
declare -a PHF_FINDING_FILES=()
declare -a PHF_FINDING_LINES=()
declare -a PHF_FINDING_SEVERITY=()
declare -a PHF_FINDING_SUGGESTIONS=()

# --- Configuration ---
PHF_MAX_FILES=500
PHF_EXCLUDE_DIRS="node_modules|.next|dist|build|.git|coverage|__pycache__|.cache"
PHF_SCAN_EXTENSIONS="ts|tsx|js|jsx|mjs"

# ============================================================
# Init
# ============================================================
_phf_init() {
    PHF_N_PLUS_ONE_COUNT=0
    PHF_UNNECESSARY_RENDER_COUNT=0
    PHF_MEMORY_LEAK_COUNT=0
    PHF_LARGE_BUNDLE_COUNT=0
    PHF_SYNC_OP_COUNT=0
    PHF_TOTAL_HOTSPOTS=0
    PHF_REPORT_DETAIL=""
    PHF_FINDINGS=()
    PHF_FINDING_TYPES=()
    PHF_FINDING_FILES=()
    PHF_FINDING_LINES=()
    PHF_FINDING_SEVERITY=()
    PHF_FINDING_SUGGESTIONS=()
    PHF_INITIALIZED=true
    return 0
}

# ============================================================
# Internal: Add finding
# ============================================================
_phf_add_finding() {
    local type="$1"
    local file="$2"
    local line="$3"
    local severity="$4"
    local description="$5"
    local suggestion="$6"

    PHF_FINDINGS+=("$description")
    PHF_FINDING_TYPES+=("$type")
    PHF_FINDING_FILES+=("$file")
    PHF_FINDING_LINES+=("$line")
    PHF_FINDING_SEVERITY+=("$severity")
    PHF_FINDING_SUGGESTIONS+=("$suggestion")
}

# ============================================================
# Internal: Collect source files
# ============================================================
_phf_collect_files() {
    local project_dir="$1"
    local ext_pattern="${2:-$PHF_SCAN_EXTENSIONS}"

    find "$project_dir" \
        -type f \
        -regextype posix-extended \
        -regex ".*\\.($ext_pattern)" \
        2>/dev/null \
    | grep -vE "($PHF_EXCLUDE_DIRS)" \
    | head -"$PHF_MAX_FILES"
}

# ============================================================
# 1. N+1 Query Pattern Detection
# Detect findMany/findUnique/findFirst inside loops,
# sequential awaits in loops, and missing batch operations.
# ============================================================
_phf_find_n_plus_one() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1
    [[ "$PHF_INITIALIZED" != "true" ]] && _phf_init

    local count=0
    PHF_REPORT_DETAIL+="--- N+1 Query Detection ---\n"

    while IFS= read -r file; do
        local rel="${file#$project_dir/}"

        # Pattern 1: Prisma queries inside for/forEach/map loops
        local loop_queries
        loop_queries=$(awk '
            BEGIN { in_loop=0; depth=0; loop_line=0 }
            /for\s*\(|\.forEach\s*\(|\.map\s*\(|for\s*await\s*\(|while\s*\(/ {
                in_loop=1; depth=0; loop_line=NR
            }
            in_loop && /\{/ { depth++ }
            in_loop && /\}/ { depth--; if(depth<=0) { in_loop=0 } }
            in_loop && /prisma\.[a-zA-Z]+\.(findUnique|findFirst|findMany|create|update|delete|upsert)\s*\(/ {
                printf "%d:%s\n", NR, $0
            }
            in_loop && /\.findOne\s*\(|\.find\s*\(.*\$eq|\.updateOne\s*\(/ {
                printf "%d:%s\n", NR, $0
            }
        ' "$file" 2>/dev/null)

        if [[ -n "$loop_queries" ]]; then
            while IFS=: read -r line_no content; do
                count=$((count + 1))
                local trimmed
                trimmed=$(echo "$content" | sed 's/^[[:space:]]*//' | cut -c1-100)
                _phf_add_finding \
                    "N+1" "$rel" "$line_no" "high" \
                    "N+1 query in loop: ${trimmed}" \
                    "Replace with batch query using findMany({ where: { id: { in: ids } } }) or use include/select for eager loading"
                PHF_REPORT_DETAIL+="  [HIGH] ${rel}:${line_no} - DB query inside loop\n"
            done <<< "$loop_queries"
        fi

        # Pattern 2: Sequential await in loop (non-DB but still blocking)
        local seq_awaits
        seq_awaits=$(awk '
            BEGIN { in_loop=0; depth=0; await_count=0 }
            /for\s*\(|\.forEach\s*\(|\.map\s*\(|for\s*await\s*\(/ {
                in_loop=1; depth=0; await_count=0; loop_start=NR
            }
            in_loop && /\{/ { depth++ }
            in_loop && /\}/ {
                depth--
                if(depth<=0) {
                    if(await_count >= 3) {
                        printf "%d:sequential_await_count=%d\n", loop_start, await_count
                    }
                    in_loop=0
                }
            }
            in_loop && /await\s+/ { await_count++ }
        ' "$file" 2>/dev/null)

        if [[ -n "$seq_awaits" ]]; then
            while IFS=: read -r line_no info; do
                [[ -z "$line_no" ]] && continue
                count=$((count + 1))
                _phf_add_finding \
                    "N+1" "$rel" "$line_no" "medium" \
                    "Multiple sequential awaits in loop ($info)" \
                    "Use Promise.all() or Promise.allSettled() for parallel execution"
                PHF_REPORT_DETAIL+="  [MED] ${rel}:${line_no} - Sequential awaits in loop\n"
            done <<< "$seq_awaits"
        fi

        # Pattern 3: Missing include/select with relation access
        local missing_include
        missing_include=$(grep -nE 'prisma\.[a-zA-Z]+\.findMany\s*\(\s*\)' "$file" 2>/dev/null)
        if [[ -n "$missing_include" ]]; then
            while IFS=: read -r line_no content; do
                count=$((count + 1))
                _phf_add_finding \
                    "N+1" "$rel" "$line_no" "low" \
                    "findMany() without select/include may over-fetch data" \
                    "Add select or include to limit fetched fields and eager-load relations"
                PHF_REPORT_DETAIL+="  [LOW] ${rel}:${line_no} - findMany without select/include\n"
            done <<< "$missing_include"
        fi

    done < <(_phf_collect_files "$project_dir")

    PHF_N_PLUS_ONE_COUNT=$count
    if [[ $count -eq 0 ]]; then
        PHF_REPORT_DETAIL+="  No N+1 query patterns detected.\n"
    else
        PHF_REPORT_DETAIL+="  Total: ${count} N+1 potential issues found.\n"
    fi
    PHF_REPORT_DETAIL+="\n"
    return 0
}

# ============================================================
# 2. Unnecessary React Re-render Detection
# Detect missing memo, useMemo, useCallback, unstable deps.
# ============================================================
_phf_find_unnecessary_renders() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1
    [[ "$PHF_INITIALIZED" != "true" ]] && _phf_init

    local count=0
    PHF_REPORT_DETAIL+="--- Unnecessary Re-render Detection ---\n"

    while IFS= read -r file; do
        local rel="${file#$project_dir/}"

        # Only scan React files (tsx/jsx)
        [[ "$file" != *.tsx && "$file" != *.jsx ]] && continue

        # Pattern 1: Component without React.memo receiving props
        # Look for function components that take props but aren't wrapped in memo
        local has_memo
        has_memo=$(grep -cE '(React\.memo|memo\s*\()' "$file" 2>/dev/null || echo "0")
        local has_props
        has_props=$(grep -cE 'function\s+\w+\s*\(\s*\{|:\s*(React\.FC|FC)<|Props\)' "$file" 2>/dev/null || echo "0")

        if [[ ${has_props:-0} -gt 0 ]] && [[ ${has_memo:-0} -eq 0 ]]; then
            # Check if it's a frequently re-rendered component (has parent with state)
            local component_name
            component_name=$(grep -oE '(export\s+(default\s+)?function|const)\s+[A-Z][a-zA-Z]+' "$file" 2>/dev/null | head -1 | awk '{print $NF}')
            if [[ -n "$component_name" ]]; then
                local line_no
                line_no=$(grep -nE "(function|const)\s+${component_name}" "$file" 2>/dev/null | head -1 | cut -d: -f1)
                count=$((count + 1))
                _phf_add_finding \
                    "RENDER" "$rel" "${line_no:-1}" "low" \
                    "Component '${component_name}' receives props but is not wrapped in React.memo" \
                    "Wrap with React.memo() if parent re-renders frequently: export default React.memo(${component_name})"
                PHF_REPORT_DETAIL+="  [LOW] ${rel} - ${component_name} not memo-wrapped\n"
            fi
        fi

        # Pattern 2: Object/array literals in JSX props (causes re-render)
        local inline_objects
        inline_objects=$(grep -nE '<[A-Z][a-zA-Z]*\s+[a-zA-Z]+=\{\s*\{' "$file" 2>/dev/null | head -10)
        if [[ -n "$inline_objects" ]]; then
            while IFS=: read -r line_no content; do
                [[ -z "$line_no" ]] && continue
                count=$((count + 1))
                _phf_add_finding \
                    "RENDER" "$rel" "$line_no" "medium" \
                    "Inline object literal in JSX prop creates new reference each render" \
                    "Extract to useMemo() or a constant outside the component"
                PHF_REPORT_DETAIL+="  [MED] ${rel}:${line_no} - Inline object in JSX prop\n"
            done <<< "$inline_objects"
        fi

        # Pattern 3: Arrow functions in JSX props (onClick={() => ...})
        local inline_arrows
        inline_arrows=$(grep -nE '<[A-Z][a-zA-Z]*\s+on[A-Z][a-zA-Z]+=\{\s*\(' "$file" 2>/dev/null | head -10)
        if [[ -n "$inline_arrows" ]]; then
            while IFS=: read -r line_no content; do
                [[ -z "$line_no" ]] && continue
                count=$((count + 1))
                _phf_add_finding \
                    "RENDER" "$rel" "$line_no" "low" \
                    "Inline arrow function in event handler prop" \
                    "Extract to useCallback() to maintain referential equality"
            done <<< "$inline_arrows"
        fi

        # Pattern 4: useEffect with missing or empty dependency array
        local effect_no_deps
        effect_no_deps=$(awk '
            /useEffect\s*\(/ {
                start = NR
                depth = 0
                found_deps = 0
            }
            start && /\{/ { depth++ }
            start && /\}/ { depth-- }
            start && depth <= 0 && /\)\s*;?\s*$/ {
                if (!found_deps) {
                    printf "%d:useEffect without dependency array\n", start
                }
                start = 0
            }
            start && /\]\s*\)\s*;?\s*$/ { found_deps = 1 }
        ' "$file" 2>/dev/null)

        if [[ -n "$effect_no_deps" ]]; then
            while IFS=: read -r line_no msg; do
                [[ -z "$line_no" ]] && continue
                count=$((count + 1))
                _phf_add_finding \
                    "RENDER" "$rel" "$line_no" "high" \
                    "useEffect may be missing dependency array - runs on every render" \
                    "Add dependency array: useEffect(() => { ... }, [dep1, dep2])"
                PHF_REPORT_DETAIL+="  [HIGH] ${rel}:${line_no} - useEffect without deps\n"
            done <<< "$effect_no_deps"
        fi

        # Pattern 5: Large component without useMemo for expensive computations
        local expensive_compute
        expensive_compute=$(grep -nE '\.(filter|sort|reduce|map)\s*\(' "$file" 2>/dev/null | head -10)
        local has_usememo
        has_usememo=$(grep -cE 'useMemo\s*\(' "$file" 2>/dev/null || echo "0")

        local compute_count
        compute_count=$(echo "$expensive_compute" | grep -c '[a-z]' 2>/dev/null || echo "0")

        if [[ ${compute_count:-0} -gt 3 ]] && [[ ${has_usememo:-0} -eq 0 ]]; then
            count=$((count + 1))
            _phf_add_finding \
                "RENDER" "$rel" "1" "medium" \
                "Multiple array transformations (filter/sort/reduce/map) without useMemo" \
                "Wrap expensive computations in useMemo(() => data.filter(...).sort(...), [data])"
            PHF_REPORT_DETAIL+="  [MED] ${rel} - ${compute_count} transforms without useMemo\n"
        fi

    done < <(_phf_collect_files "$project_dir" "tsx|jsx")

    PHF_UNNECESSARY_RENDER_COUNT=$count
    if [[ $count -eq 0 ]]; then
        PHF_REPORT_DETAIL+="  No unnecessary re-render patterns detected.\n"
    else
        PHF_REPORT_DETAIL+="  Total: ${count} re-render issues found.\n"
    fi
    PHF_REPORT_DETAIL+="\n"
    return 0
}

# ============================================================
# 3. Memory Leak Detection
# Detect uncleared intervals/timeouts, missing event listener
# cleanup, unsubscribed observables, unclosed connections.
# ============================================================
_phf_find_memory_leaks() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1
    [[ "$PHF_INITIALIZED" != "true" ]] && _phf_init

    local count=0
    PHF_REPORT_DETAIL+="--- Memory Leak Detection ---\n"

    while IFS= read -r file; do
        local rel="${file#$project_dir/}"

        # Pattern 1: setInterval without clearInterval
        local has_set_interval
        has_set_interval=$(grep -c 'setInterval\s*(' "$file" 2>/dev/null || echo "0")
        local has_clear_interval
        has_clear_interval=$(grep -c 'clearInterval\s*(' "$file" 2>/dev/null || echo "0")

        if [[ ${has_set_interval:-0} -gt ${has_clear_interval:-0} ]]; then
            local diff=$((has_set_interval - has_clear_interval))
            local line_no
            line_no=$(grep -n 'setInterval\s*(' "$file" 2>/dev/null | head -1 | cut -d: -f1)
            count=$((count + diff))
            _phf_add_finding \
                "MEMLEAK" "$rel" "${line_no:-1}" "high" \
                "${diff} setInterval(s) without matching clearInterval" \
                "Store interval ID and call clearInterval in cleanup: const id = setInterval(...); return () => clearInterval(id);"
            PHF_REPORT_DETAIL+="  [HIGH] ${rel} - ${diff} uncleared setInterval\n"
        fi

        # Pattern 2: setTimeout without clearTimeout (in components)
        local has_set_timeout
        has_set_timeout=$(grep -c 'setTimeout\s*(' "$file" 2>/dev/null || echo "0")
        local has_clear_timeout
        has_clear_timeout=$(grep -c 'clearTimeout\s*(' "$file" 2>/dev/null || echo "0")

        if [[ ${has_set_timeout:-0} -gt $((has_clear_timeout + 1)) ]]; then
            local diff=$((has_set_timeout - has_clear_timeout))
            local line_no
            line_no=$(grep -n 'setTimeout\s*(' "$file" 2>/dev/null | head -1 | cut -d: -f1)
            count=$((count + 1))
            _phf_add_finding \
                "MEMLEAK" "$rel" "${line_no:-1}" "medium" \
                "${diff} setTimeout(s) without matching clearTimeout" \
                "Store timeout ID and clear in useEffect cleanup or component unmount"
            PHF_REPORT_DETAIL+="  [MED] ${rel} - ${diff} uncleared setTimeout\n"
        fi

        # Pattern 3: addEventListener without removeEventListener
        local has_add_listener
        has_add_listener=$(grep -c 'addEventListener\s*(' "$file" 2>/dev/null || echo "0")
        local has_remove_listener
        has_remove_listener=$(grep -c 'removeEventListener\s*(' "$file" 2>/dev/null || echo "0")

        if [[ ${has_add_listener:-0} -gt ${has_remove_listener:-0} ]]; then
            local diff=$((has_add_listener - has_remove_listener))
            local line_no
            line_no=$(grep -n 'addEventListener\s*(' "$file" 2>/dev/null | head -1 | cut -d: -f1)
            count=$((count + diff))
            _phf_add_finding \
                "MEMLEAK" "$rel" "${line_no:-1}" "high" \
                "${diff} addEventListener(s) without matching removeEventListener" \
                "Always remove event listeners in useEffect cleanup: return () => el.removeEventListener(event, handler)"
            PHF_REPORT_DETAIL+="  [HIGH] ${rel} - ${diff} unremoved event listener(s)\n"
        fi

        # Pattern 4: useEffect without cleanup for subscriptions
        local effect_subscribe_no_cleanup
        effect_subscribe_no_cleanup=$(awk '
            BEGIN { in_effect=0; depth=0; has_subscribe=0; has_cleanup=0; effect_start=0 }
            /useEffect\s*\(/ { in_effect=1; depth=0; has_subscribe=0; has_cleanup=0; effect_start=NR }
            in_effect && /\{/ { depth++ }
            in_effect && /\}/ { depth-- }
            in_effect && /\.subscribe\s*\(|\.on\s*\(|new\s+WebSocket|new\s+EventSource/ { has_subscribe=1 }
            in_effect && /return\s*\(\s*\)\s*=>|return\s*\(\)\s*\{|return\s+function/ { has_cleanup=1 }
            in_effect && depth <= 0 {
                if (has_subscribe && !has_cleanup) {
                    printf "%d:subscription without cleanup\n", effect_start
                }
                in_effect=0
            }
        ' "$file" 2>/dev/null)

        if [[ -n "$effect_subscribe_no_cleanup" ]]; then
            while IFS=: read -r line_no msg; do
                [[ -z "$line_no" ]] && continue
                count=$((count + 1))
                _phf_add_finding \
                    "MEMLEAK" "$rel" "$line_no" "high" \
                    "useEffect creates subscription without cleanup function" \
                    "Add return () => { subscription.unsubscribe(); } to useEffect"
                PHF_REPORT_DETAIL+="  [HIGH] ${rel}:${line_no} - Subscription without cleanup\n"
            done <<< "$effect_subscribe_no_cleanup"
        fi

        # Pattern 5: AbortController not used with fetch in useEffect
        local fetch_in_effect
        fetch_in_effect=$(awk '
            BEGIN { in_effect=0; depth=0; has_fetch=0; has_abort=0; effect_start=0 }
            /useEffect\s*\(/ { in_effect=1; depth=0; has_fetch=0; has_abort=0; effect_start=NR }
            in_effect && /\{/ { depth++ }
            in_effect && /\}/ { depth-- }
            in_effect && /fetch\s*\(|axios\.|\.get\s*\(|\.post\s*\(/ { has_fetch=1 }
            in_effect && /AbortController|signal|\.abort\s*\(/ { has_abort=1 }
            in_effect && depth <= 0 {
                if (has_fetch && !has_abort) {
                    printf "%d:fetch without AbortController\n", effect_start
                }
                in_effect=0
            }
        ' "$file" 2>/dev/null)

        if [[ -n "$fetch_in_effect" ]]; then
            while IFS=: read -r line_no msg; do
                [[ -z "$line_no" ]] && continue
                count=$((count + 1))
                _phf_add_finding \
                    "MEMLEAK" "$rel" "$line_no" "medium" \
                    "fetch/axios in useEffect without AbortController" \
                    "Use AbortController for cleanup: const ctrl = new AbortController(); fetch(url, { signal: ctrl.signal }); return () => ctrl.abort();"
                PHF_REPORT_DETAIL+="  [MED] ${rel}:${line_no} - Fetch without AbortController\n"
            done <<< "$fetch_in_effect"
        fi

        # Pattern 6: Global variable accumulation
        local global_push
        global_push=$(grep -nE '(global|window|globalThis)\.[a-zA-Z]+\.(push|add|set)\s*\(' "$file" 2>/dev/null | head -5)
        if [[ -n "$global_push" ]]; then
            while IFS=: read -r line_no content; do
                [[ -z "$line_no" ]] && continue
                count=$((count + 1))
                _phf_add_finding \
                    "MEMLEAK" "$rel" "$line_no" "medium" \
                    "Global state accumulation - data pushed to global/window object" \
                    "Avoid accumulating data on global objects; use scoped state management instead"
                PHF_REPORT_DETAIL+="  [MED] ${rel}:${line_no} - Global accumulation\n"
            done <<< "$global_push"
        fi

    done < <(_phf_collect_files "$project_dir")

    PHF_MEMORY_LEAK_COUNT=$count
    if [[ $count -eq 0 ]]; then
        PHF_REPORT_DETAIL+="  No memory leak patterns detected.\n"
    else
        PHF_REPORT_DETAIL+="  Total: ${count} potential memory leak issues found.\n"
    fi
    PHF_REPORT_DETAIL+="\n"
    return 0
}

# ============================================================
# 4. Large Bundle Import Detection
# Detect imports that significantly increase bundle size.
# ============================================================
_phf_find_large_bundles() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1
    [[ "$PHF_INITIALIZED" != "true" ]] && _phf_init

    local count=0
    PHF_REPORT_DETAIL+="--- Large Bundle Import Detection ---\n"

    # Known heavy libraries and their lighter alternatives
    declare -A HEAVY_LIBS=(
        ["moment"]="date-fns or dayjs (2-6KB vs 72KB)"
        ["lodash\""]="lodash-es/specific or native methods (reduce by ~70KB)"
        ["@mui/material\"]"]="Import specific: @mui/material/Button instead of @mui/material (reduce by ~300KB)"
        ["antd\""]="Import specific: antd/es/button instead of antd (reduce by ~500KB)"
        ["chart.js\""]="react-chartjs-2 with tree-shaking or lightweight alternative like uPlot"
        ["@fortawesome"]="Use SVG icons or specific icon imports instead of full icon pack"
        ["rxjs\""]="Import specific operators: rxjs/operators/map instead of rxjs"
        ["aws-sdk\""]="Use @aws-sdk/client-* v3 modular packages (~80% smaller)"
        ["firebase\""]="Use firebase/app + specific modules instead of full firebase"
        ["three\""]="Use specific three.js modules and tree-shake with webpack"
    )

    while IFS= read -r file; do
        local rel="${file#$project_dir/}"

        for lib in "${!HEAVY_LIBS[@]}"; do
            local found
            found=$(grep -nE "from\s+['\"]${lib}|require\s*\(\s*['\"]${lib}" "$file" 2>/dev/null | head -3)
            if [[ -n "$found" ]]; then
                while IFS=: read -r line_no content; do
                    [[ -z "$line_no" ]] && continue
                    count=$((count + 1))
                    local clean_lib
                    clean_lib=$(echo "$lib" | tr -d '"' | tr -d "'" | tr -d ']')
                    _phf_add_finding \
                        "BUNDLE" "$rel" "$line_no" "medium" \
                        "Heavy library import: ${clean_lib}" \
                        "Alternative: ${HEAVY_LIBS[$lib]}"
                    PHF_REPORT_DETAIL+="  [MED] ${rel}:${line_no} - Heavy import: ${clean_lib}\n"
                done <<< "$found"
            fi
        done

        # Pattern 2: Wildcard imports (import * as)
        local wildcard_imports
        wildcard_imports=$(grep -nE 'import\s+\*\s+as\s+' "$file" 2>/dev/null | head -5)
        if [[ -n "$wildcard_imports" ]]; then
            while IFS=: read -r line_no content; do
                [[ -z "$line_no" ]] && continue
                count=$((count + 1))
                local trimmed
                trimmed=$(echo "$content" | sed 's/^[[:space:]]*//' | cut -c1-80)
                _phf_add_finding \
                    "BUNDLE" "$rel" "$line_no" "low" \
                    "Wildcard import prevents tree-shaking: ${trimmed}" \
                    "Use named imports: import { specific } from 'module' for better tree-shaking"
                PHF_REPORT_DETAIL+="  [LOW] ${rel}:${line_no} - Wildcard import\n"
            done <<< "$wildcard_imports"
        fi

        # Pattern 3: Dynamic import candidates (large static imports in routes)
        local is_page=false
        [[ "$file" == *"/page."* || "$file" == *"/pages/"* || "$file" == *"/views/"* ]] && is_page=true

        if [[ "$is_page" == "true" ]]; then
            local heavy_static
            heavy_static=$(grep -nE "^import\s+.*from\s+['\"].*chart|^import\s+.*from\s+['\"].*editor|^import\s+.*from\s+['\"].*map|^import\s+.*from\s+['\"].*table" "$file" 2>/dev/null)
            if [[ -n "$heavy_static" ]]; then
                while IFS=: read -r line_no content; do
                    [[ -z "$line_no" ]] && continue
                    count=$((count + 1))
                    _phf_add_finding \
                        "BUNDLE" "$rel" "$line_no" "medium" \
                        "Heavy component imported statically in page - consider lazy loading" \
                        "Use dynamic(() => import('./HeavyComponent'), { ssr: false }) or React.lazy()"
                    PHF_REPORT_DETAIL+="  [MED] ${rel}:${line_no} - Dynamic import candidate\n"
                done <<< "$heavy_static"
            fi
        fi

        # Pattern 4: Importing entire icon libraries
        local icon_full_import
        icon_full_import=$(grep -nE "from\s+['\"]react-icons['\"]|from\s+['\"]@heroicons/react['\"]$|from\s+['\"]lucide-react['\"]$" "$file" 2>/dev/null)
        if [[ -n "$icon_full_import" ]]; then
            while IFS=: read -r line_no content; do
                [[ -z "$line_no" ]] && continue
                count=$((count + 1))
                _phf_add_finding \
                    "BUNDLE" "$rel" "$line_no" "low" \
                    "Full icon library import instead of specific icons" \
                    "Import specific icons: import { FiHome } from 'react-icons/fi'"
            done <<< "$icon_full_import"
        fi

    done < <(_phf_collect_files "$project_dir")

    PHF_LARGE_BUNDLE_COUNT=$count
    if [[ $count -eq 0 ]]; then
        PHF_REPORT_DETAIL+="  No large bundle import issues detected.\n"
    else
        PHF_REPORT_DETAIL+="  Total: ${count} bundle optimization opportunities found.\n"
    fi
    PHF_REPORT_DETAIL+="\n"
    return 0
}

# ============================================================
# 5. Synchronous Blocking Operation Detection
# Find sync file I/O, blocking network calls, heavy computation
# on main thread.
# ============================================================
_phf_find_sync_operations() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1
    [[ "$PHF_INITIALIZED" != "true" ]] && _phf_init

    local count=0
    PHF_REPORT_DETAIL+="--- Synchronous Blocking Detection ---\n"

    while IFS= read -r file; do
        local rel="${file#$project_dir/}"

        # Pattern 1: Synchronous fs operations
        local sync_fs
        sync_fs=$(grep -nE '(readFileSync|writeFileSync|appendFileSync|readdirSync|statSync|existsSync|mkdirSync|unlinkSync|copyFileSync|renameSync)\s*\(' "$file" 2>/dev/null | head -10)
        if [[ -n "$sync_fs" ]]; then
            while IFS=: read -r line_no content; do
                [[ -z "$line_no" ]] && continue
                # existsSync is generally acceptable
                if echo "$content" | grep -q 'existsSync'; then
                    continue
                fi
                count=$((count + 1))
                local op
                op=$(echo "$content" | grep -oE '[a-zA-Z]+Sync' | head -1)
                _phf_add_finding \
                    "SYNC" "$rel" "$line_no" "high" \
                    "Synchronous file operation: ${op} blocks the event loop" \
                    "Use async version: ${op%Sync} with await, or use fs/promises"
                PHF_REPORT_DETAIL+="  [HIGH] ${rel}:${line_no} - Sync FS: ${op}\n"
            done <<< "$sync_fs"
        fi

        # Pattern 2: Synchronous child_process operations
        local sync_exec
        sync_exec=$(grep -nE '(execSync|spawnSync|execFileSync)\s*\(' "$file" 2>/dev/null | head -5)
        if [[ -n "$sync_exec" ]]; then
            while IFS=: read -r line_no content; do
                [[ -z "$line_no" ]] && continue
                count=$((count + 1))
                local op
                op=$(echo "$content" | grep -oE '[a-zA-Z]+Sync' | head -1)
                _phf_add_finding \
                    "SYNC" "$rel" "$line_no" "high" \
                    "Synchronous process execution: ${op} blocks the event loop" \
                    "Use async version: exec/spawn with callback or util.promisify"
                PHF_REPORT_DETAIL+="  [HIGH] ${rel}:${line_no} - Sync exec: ${op}\n"
            done <<< "$sync_exec"
        fi

        # Pattern 3: Heavy computation without worker thread
        local heavy_loops
        heavy_loops=$(awk '
            BEGIN { depth=0; loop_ops=0; loop_start=0; in_loop=0 }
            /for\s*\(.*;\s*.*<\s*[0-9]{4,}|while\s*\(/ {
                in_loop=1; loop_start=NR; loop_ops=0; depth=0
            }
            in_loop && /\{/ { depth++ }
            in_loop && /\}/ {
                depth--
                if(depth<=0) {
                    if(loop_ops >= 5) {
                        printf "%d:heavy_computation\n", loop_start
                    }
                    in_loop=0
                }
            }
            in_loop && /[+\-*\/=]/ { loop_ops++ }
        ' "$file" 2>/dev/null)

        if [[ -n "$heavy_loops" ]]; then
            while IFS=: read -r line_no msg; do
                [[ -z "$line_no" ]] && continue
                count=$((count + 1))
                _phf_add_finding \
                    "SYNC" "$rel" "$line_no" "medium" \
                    "Potentially heavy computation loop on main thread" \
                    "Consider offloading to Worker thread or using requestIdleCallback for non-critical work"
                PHF_REPORT_DETAIL+="  [MED] ${rel}:${line_no} - Heavy loop on main thread\n"
            done <<< "$heavy_loops"
        fi

        # Pattern 4: JSON.parse/stringify on potentially large objects
        local json_operations
        json_operations=$(grep -nE 'JSON\.(parse|stringify)\s*\(' "$file" 2>/dev/null | head -5)
        # Only flag if there are many (indicates parsing large data)
        local json_count
        json_count=$(echo "$json_operations" | grep -c '[a-z]' 2>/dev/null || echo "0")
        if [[ ${json_count:-0} -gt 5 ]]; then
            count=$((count + 1))
            _phf_add_finding \
                "SYNC" "$rel" "1" "low" \
                "Multiple JSON.parse/stringify operations (${json_count}) - may block on large payloads" \
                "Consider streaming JSON parsing for large data or move to worker thread"
            PHF_REPORT_DETAIL+="  [LOW] ${rel} - ${json_count} JSON parse/stringify operations\n"
        fi

    done < <(_phf_collect_files "$project_dir")

    PHF_SYNC_OP_COUNT=$count
    if [[ $count -eq 0 ]]; then
        PHF_REPORT_DETAIL+="  No synchronous blocking operations detected.\n"
    else
        PHF_REPORT_DETAIL+="  Total: ${count} sync blocking issues found.\n"
    fi
    PHF_REPORT_DETAIL+="\n"
    return 0
}

# ============================================================
# 6. Generate Comprehensive Report
# ============================================================
_phf_generate_report() {
    local project_dir="$1"
    local output_file="${2:-}"
    [[ ! -d "$project_dir" ]] && return 1

    # Run all detections if not already run
    if [[ "$PHF_INITIALIZED" != "true" ]]; then
        _phf_init
    fi

    PHF_REPORT_DETAIL="============================================\n"
    PHF_REPORT_DETAIL+="  Performance Hotspot Finder v${PHF_VERSION}\n"
    PHF_REPORT_DETAIL+="  Target: ${project_dir}\n"
    PHF_REPORT_DETAIL+="  Timestamp: $(date '+%Y-%m-%d %H:%M:%S')\n"
    PHF_REPORT_DETAIL+="============================================\n\n"

    _phf_find_n_plus_one "$project_dir"
    _phf_find_unnecessary_renders "$project_dir"
    _phf_find_memory_leaks "$project_dir"
    _phf_find_large_bundles "$project_dir"
    _phf_find_sync_operations "$project_dir"

    PHF_TOTAL_HOTSPOTS=$((PHF_N_PLUS_ONE_COUNT + PHF_UNNECESSARY_RENDER_COUNT + PHF_MEMORY_LEAK_COUNT + PHF_LARGE_BUNDLE_COUNT + PHF_SYNC_OP_COUNT))

    # Summary section
    PHF_REPORT_DETAIL+="============================================\n"
    PHF_REPORT_DETAIL+="  SUMMARY\n"
    PHF_REPORT_DETAIL+="============================================\n"
    PHF_REPORT_DETAIL+="  N+1 Queries:         ${PHF_N_PLUS_ONE_COUNT}\n"
    PHF_REPORT_DETAIL+="  Unnecessary Renders:  ${PHF_UNNECESSARY_RENDER_COUNT}\n"
    PHF_REPORT_DETAIL+="  Memory Leaks:         ${PHF_MEMORY_LEAK_COUNT}\n"
    PHF_REPORT_DETAIL+="  Large Bundles:        ${PHF_LARGE_BUNDLE_COUNT}\n"
    PHF_REPORT_DETAIL+="  Sync Blocking:        ${PHF_SYNC_OP_COUNT}\n"
    PHF_REPORT_DETAIL+="  ──────────────────────────────────────\n"
    PHF_REPORT_DETAIL+="  TOTAL HOTSPOTS:       ${PHF_TOTAL_HOTSPOTS}\n"
    PHF_REPORT_DETAIL+="  SCORE:                $(_phf_score)/100\n"
    PHF_REPORT_DETAIL+="============================================\n\n"

    # Top priority fixes
    if [[ ${#PHF_FINDINGS[@]} -gt 0 ]]; then
        PHF_REPORT_DETAIL+="  TOP PRIORITY FIXES:\n"
        local shown=0
        for i in "${!PHF_FINDINGS[@]}"; do
            if [[ "${PHF_FINDING_SEVERITY[$i]}" == "high" ]] && [[ $shown -lt 10 ]]; then
                PHF_REPORT_DETAIL+="  [${PHF_FINDING_TYPES[$i]}] ${PHF_FINDING_FILES[$i]}:${PHF_FINDING_LINES[$i]}\n"
                PHF_REPORT_DETAIL+="    Problem:  ${PHF_FINDINGS[$i]}\n"
                PHF_REPORT_DETAIL+="    Fix:      ${PHF_FINDING_SUGGESTIONS[$i]}\n\n"
                shown=$((shown + 1))
            fi
        done
        if [[ $shown -eq 0 ]]; then
            PHF_REPORT_DETAIL+="  No high-severity hotspots found.\n"
        fi
    fi

    if [[ -n "$output_file" ]]; then
        echo -e "$PHF_REPORT_DETAIL" > "$output_file"
        echo "[PHF] Report written to: ${output_file}" >&2
    fi

    echo -e "$PHF_REPORT_DETAIL"
    return 0
}

# ============================================================
# Generate optimization prompt for Claude
# ============================================================
_phf_generate_fix_prompt() {
    local prompt="Fix the following performance hotspots:\n\n"
    local fix_count=0

    for i in "${!PHF_FINDINGS[@]}"; do
        [[ "${PHF_FINDING_SEVERITY[$i]}" != "high" ]] && continue
        [[ $fix_count -ge 15 ]] && break

        prompt+="## ${PHF_FINDING_TYPES[$i]} - ${PHF_FINDING_FILES[$i]}:${PHF_FINDING_LINES[$i]}\n"
        prompt+="Problem: ${PHF_FINDINGS[$i]}\n"
        prompt+="Fix: ${PHF_FINDING_SUGGESTIONS[$i]}\n\n"
        fix_count=$((fix_count + 1))
    done

    if [[ $fix_count -eq 0 ]]; then
        prompt+="No high-severity performance issues to fix.\n"
    fi

    echo -e "$prompt"
}

# ============================================================
# Scoring
# ============================================================
_phf_score() {
    local total=$PHF_TOTAL_HOTSPOTS

    if [[ $total -eq 0 ]]; then
        echo "100"
    elif [[ $total -le 3 ]]; then
        echo "85"
    elif [[ $total -le 8 ]]; then
        echo "65"
    elif [[ $total -le 15 ]]; then
        echo "45"
    elif [[ $total -le 25 ]]; then
        echo "25"
    else
        echo "10"
    fi
}

# ============================================================
# Report (for module registry)
# ============================================================
_phf_report() {
    echo -e "\n  ${BOLD:-}=== Performance Hotspot Finder v${PHF_VERSION} ===${NC:-}"
    echo -e "  N+1 Queries:        ${PHF_N_PLUS_ONE_COUNT}"
    echo -e "  Unnecessary Renders: ${PHF_UNNECESSARY_RENDER_COUNT}"
    echo -e "  Memory Leaks:       ${PHF_MEMORY_LEAK_COUNT}"
    echo -e "  Large Bundles:      ${PHF_LARGE_BUNDLE_COUNT}"
    echo -e "  Sync Blocking:      ${PHF_SYNC_OP_COUNT}"
    echo -e "  Total Hotspots:     ${PHF_TOTAL_HOTSPOTS}"
    echo -e "  Score:              $(_phf_score)/100"
}

# ============================================================
# Module Registry self-registration
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "performance-hotspot-finder" \
        --version "$PHF_VERSION" \
        --description "パフォーマンスホットスポット検出 - N+1/再レンダリング/メモリリーク/バンドル/同期ブロック" \
        --init "_phf_init" \
        --report "_phf_report" \
        --score "_phf_score" \
        --enable-var "ENABLE_PHF" \
        --cli-flags "--hotspot-finder:--no-hotspot-finder"
fi

# v2003.1: source時のexit codeを確実に0にする
true
