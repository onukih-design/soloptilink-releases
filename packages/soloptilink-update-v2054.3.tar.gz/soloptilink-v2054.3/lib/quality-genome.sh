#!/usr/bin/env bash
# =============================================================================
# quality-genome.sh - 戦略学習層 (Quality Genome) v1.0.0
# -----------------------------------------------------------------------------
# 役割:
#   生成セッションの「計画 → 品質スコア → 効いた断片」をドメイン別に蓄積し、
#   次回の計画立案時に高スコア実績の断片を注入して初手精度を底上げする。
#   ROADMAP v30 "Quality Genome Recorder + Adaptive Prompt Optimizer" の最小実装。
# 配線:
#   strategic-planning-engine.sh (spe_assemble_inputs / spe_run) から呼ばれる。
# データ:
#   ~/.soloptilink/learning/quality-genome/<domain>.jsonl
#   端末内完結・外部送信なし・LLM非依存(python3標準ライブラリのみ。numpy不要)
# =============================================================================
[[ -n "${QG_LOADED:-}" ]] && return 0 2>/dev/null || true
QG_LOADED=1
QG_VERSION="1.0.0"
QG_DIR="${SOLOPTILINK_HOME:-${HOME}/.soloptilink}/learning/quality-genome"

_qg_log() { [[ "${QG_VERBOSE:-0}" == "1" ]] && echo "[quality-genome] $*" >&2 || true; }

qg_init() { mkdir -p "$QG_DIR" 2>/dev/null || true; }

# qg_record <domain> <plan_summary> <score 0-1> <outcome success|fail|unknown> [fragments_json_or_pipe]
# 戻り値(stdout): record id (PFP-114)。後から qg_update_outcome <id> で実績を書き戻せる。
qg_record() {
  qg_init
  # v2043 (Lane6/クロステナント学習): 第6引数 tenant_id は受領時に即 HMAC 化し
  #   tenant_hash としてのみ保存する。原値テナント識別子は jsonl へ一切書かない(原値残置=CRITICAL)。
  #   後方互換: 第6引数省略時は従来どおり tenant_hash キー無しのレコード(既存 schema 不変)。
  local _qg_tenant_hash=""
  [[ -n "${6:-}" ]] && _qg_tenant_hash="$(qg_tenant_hash "$6" 2>/dev/null || true)"
  QG_DIR="$QG_DIR" \
  QG_DOMAIN="${1:-general}" \
  QG_SUMMARY="${2:-}" \
  QG_SCORE="${3:-0}" \
  QG_OUTCOME="${4:-unknown}" \
  QG_FRAG="${5:-[]}" \
  QG_TENANT_HASH="$_qg_tenant_hash" \
  python3 - <<'PY' 2>/dev/null || return 1
import os, json, re, datetime, uuid
d = os.environ
# PII二重防御スクラブ (qg_ingest_telemetry と同一方針: 機密トークン/メール/絶対パスを再マスク)
_QG_PII = [
    re.compile(r'eyJ[A-Za-z0-9_\-]+\.eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+'),
    re.compile(r'sk-ant-[A-Za-z0-9_\-]{20,}'), re.compile(r'sk-[A-Za-z0-9_]{20,}'),
    re.compile(r'AKIA[0-9A-Z]{16}'), re.compile(r'gh[psour]_[A-Za-z0-9]{36,}'),
    re.compile(r'AIza[A-Za-z0-9_\-]{35}'), re.compile(r'xox[bpoarsut]-[A-Za-z0-9\-]+'),
    re.compile(r'(?:sk|rk|pk)_(?:live|test)_[A-Za-z0-9]{16,}'),
    re.compile(r'(?:postgres|postgresql|mysql|mongodb)(?:\+[a-z0-9_]+)?://[^:\s/]+:[^@\s]+@'),
    re.compile(r'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}'),
    re.compile(r'(?:/Users|/home|/root)/[^\s"\']+'),
    re.compile(r'[A-Za-z]:\\[^\s"\']+'),
    re.compile(r'\\\\[A-Za-z0-9._$-]+\\[^\s"\']+'),
]
def _qg_scrub(s):
    out = str(s or '')
    for pat in _QG_PII:
        out = pat.sub('[REDACTED]', out)
    return out
domain = re.sub(r'[^A-Za-z0-9_-]', '_', d.get('QG_DOMAIN', 'general'))[:64] or 'general'
path = os.path.join(d['QG_DIR'], domain + '.jsonl')
raw = (d.get('QG_FRAG') or '[]').strip()
frag = []
try:
    parsed = json.loads(raw)
    if isinstance(parsed, list):
        frag = parsed
except Exception:
    frag = [s.strip() for s in raw.replace('[', '').replace(']', '').split('|') if s.strip()]
try:
    score = max(0.0, min(1.0, float(d.get('QG_SCORE') or 0)))
except Exception:
    score = 0.0
now = datetime.datetime.now()
# record id: 後から実績(success/fail)を書き戻すための一意キー (PFP-114)
rec_id = "qg-%s-%s" % (now.strftime('%Y%m%d%H%M%S'), uuid.uuid4().hex[:8])
rec = {
    "id": rec_id,
    "ts": now.isoformat(timespec='seconds'),
    "domain": domain,
    "plan_summary": _qg_scrub(d.get('QG_SUMMARY') or '')[:2000],
    "score": round(score, 4),
    "outcome": d.get('QG_OUTCOME') or 'unknown',
    "fragments": [_qg_scrub(str(x))[:300] for x in frag][:20],
}
# v2043 (Lane6): tenant_hash は既に HMAC 化済の擬似名のみ(原値非保存)。欠落時は既存 schema 不変。
_th = (d.get('QG_TENANT_HASH') or '').strip()
if _th:
    rec['tenant_hash'] = _th[:40]
with open(path, 'a', encoding='utf-8') as f:
    f.write(json.dumps(rec, ensure_ascii=False) + "\n")
print(rec_id)
PY
}

# qg_ingest_telemetry [domain]  -> 実生成テレメトリ(実データ)を canonical jsonl へ冪等取込
# -----------------------------------------------------------------------------
# 実データ還流 (B-4): quality-telemetry-reporter.sh (テレメトリ層) は生成完了ごとに
#   learning/quality-genome/<target_domain>/<timestamp>.json
# へ PII 除外済みの実生成結果 (one_shot_success / gates_passed,total / achieved_layer /
# crud_ok,login_ok,build_ok / details など) を保存する。本関数はその実テレメトリを読み、
# quality-genome の canonical 形式 (<domain>.jsonl の1行=1レコード) に正規化して追記する。
# これにより qg_recommend / qg_stats が「合成データ」ではなく「実生成結果」を根拠にできる。
#
# 設計上の不変条件:
#   - 完全に読み取り→追記のみ。テレメトリ層 (telemetry-reporter.sh) は一切改変しない (所有境界)。
#   - 冪等: 取込済みファイルは src 名で識別しスキップ (再実行で二重計上しない)。
#   - 数値はすべて実テレメトリ由来 (score=gates_passed/gates_total・outcome=one_shot_success)。
#     導出不能なレコード(両ゲート欠落)はスキップ=捏造しない。
#   - domain 省略時は全テレメトリサブディレクトリを走査して各 jsonl へ取込む。
qg_ingest_telemetry() {
  qg_init
  QG_DIR="$QG_DIR" QG_ONLY_DOMAIN="${1:-}" python3 - <<'PY' 2>/dev/null || return 0
import os, json, glob, re, hashlib, hmac, secrets, time
d = os.environ
qdir = d['QG_DIR']

def qg_sanitize(s):
    return (re.sub(r'[^A-Za-z0-9_-]', '_', str(s or ''))[:64]) or 'general'

# --- テナント擬似名 (qg_tenant_hash と同一の二段HMAC・同一 salt ファイル=record/ingest 間で一貫) ----
# テレメトリ json に tenant/company 識別子があれば、ここで HMAC 化して tenant_hash に取り込む。
# 原値はメモリ内のみで jsonl へは擬似名しか書かない(原値残置=CRITICAL の根絶・record 経路と同契約)。
_QG_SALT_FILE = os.path.join(qdir, '.qg_tenant_salt')
def _qg_tenant_hash(tid):
    tid = str(tid or '').strip()
    if not tid:
        return ''
    secret = None
    try:
        with open(_QG_SALT_FILE, 'r', encoding='utf-8') as f:
            secret = f.read().strip()
    except Exception:
        secret = None
    if not secret:
        secret = secrets.token_hex(32)
        try:
            fd = os.open(_QG_SALT_FILE, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(fd, 'w', encoding='utf-8') as f:
                f.write(secret)
        except FileExistsError:
            try:
                with open(_QG_SALT_FILE, 'r', encoding='utf-8') as f:
                    secret = f.read().strip()
            except Exception:
                pass
        except Exception:
            pass
    key = secret.encode('utf-8')
    pts = hmac.new(key, ('salt|' + tid).encode('utf-8'), hashlib.sha256).digest()
    return 'th-' + hmac.new(pts, ('tid|' + tid).encode('utf-8'), hashlib.sha256).hexdigest()[:16]

# --- 並行 ingest 直列化ロック (mkdir 原子性・macOS は flock 不在のため) ----------------
# qg_recommend / qg_stats が共に冒頭で ingest を呼ぶため、同時実行時に両者が同一 ingested
# 集合を読み→同一 src を二重追記しうる(L80「冪等=二重計上しない」契約の破れ)。read→write を
# per-domain ロックで直列化して根絶する。stale は mtime タイムアウトで自動回収=デッドロックしない。
def _qg_acquire_lock(lockdir, timeout=10.0, stale=120.0):
    start = time.time()
    while True:
        try:
            os.mkdir(lockdir)
            return True
        except FileExistsError:
            try:
                if (time.time() - os.path.getmtime(lockdir)) > stale:
                    os.rmdir(lockdir)   # 死んだ保持者のロックを回収
                    continue
            except OSError:
                pass
            if (time.time() - start) > timeout:
                return False            # best-effort: 取得不可でも閉ループは止めない(既存挙動へ縮退)
            time.sleep(0.04)
        except OSError:
            return False

def _qg_release_lock(lockdir):
    try:
        os.rmdir(lockdir)
    except OSError:
        pass

# --- PII 二重防御スクラブ (pii-mask.sh と同一の機密パターン + メール/絶対パス) ----------
# テレメトリ層は保存時に PII 禁制 allowlist で浄化済みだが、万一不正な telemetry json が
# 紛れても plan_summary / fragments に平文 PII が残らないよう、取込側でも値レベルで再マスクする。
# (pii_mask_secrets の既存マスク経路は弱めず、独立した二重防御として ADD する)
_QG_PII = [
    re.compile(r'eyJ[A-Za-z0-9_\-]+\.eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+'),
    re.compile(r'sk-ant-[A-Za-z0-9_\-]{20,}'),
    re.compile(r'sk-[A-Za-z0-9_]{20,}'),
    re.compile(r'AKIA[0-9A-Z]{16}'),
    re.compile(r'gh[psour]_[A-Za-z0-9]{36,}'),
    re.compile(r'AIza[A-Za-z0-9_\-]{35}'),
    re.compile(r'xox[bpoarsut]-[A-Za-z0-9\-]+'),
    re.compile(r'(?:sk|rk|pk)_(?:live|test)_[A-Za-z0-9]{16,}'),
    re.compile(r'(?:postgres|postgresql|mysql|mongodb)(?:\+[a-z0-9_]+)?://[^:\s/]+:[^@\s]+@'),
    re.compile(r'[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}'),   # メール
    re.compile(r'(?:/Users|/home|/root)/[^\s"\']+'),                    # Unix ホーム配下の絶対パス
    re.compile(r'[A-Za-z]:\\[^\s"\']+'),                                # Windows ドライブ絶対パス
    re.compile(r'\\\\[A-Za-z0-9._$-]+\\[^\s"\']+'),                     # Windows UNC パス
]
def _qg_scrub(s):
    out = str(s or '')
    for pat in _QG_PII:
        out = pat.sub('[REDACTED]', out)
    return out

only = d.get('QG_ONLY_DOMAIN') or ''
only_norm = qg_sanitize(only) if only.strip() else None

# テレメトリサブディレクトリ (<domain>/) のみ対象。flat jsonl は対象外。
try:
    subdirs = [n for n in os.listdir(qdir) if os.path.isdir(os.path.join(qdir, n))]
except OSError:
    raise SystemExit(0)

total_ingested = 0
for sub in sorted(subdirs):
    dom = qg_sanitize(sub)
    if only_norm is not None and dom != only_norm:
        continue
    sub_path = os.path.join(qdir, sub)
    jsonl_path = os.path.join(qdir, dom + '.jsonl')

    # read(ingested集合)→write(追記) を per-domain ロックで直列化(並行二重取込レース根絶)。
    # この continue より後に早期 return/continue は無く、ロックは反復末尾で必ず解放される。
    _lockdir = jsonl_path + '.lock'
    _have_lock = _qg_acquire_lock(_lockdir)

    # 既に取込済みの src 名を収集 (冪等性)。flat jsonl を読み、origin=telemetry の src を集める。
    ingested = set()
    if os.path.exists(jsonl_path):
        try:
            with open(jsonl_path, encoding='utf-8') as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        r = json.loads(line)
                    except Exception:
                        continue
                    if r.get('origin') == 'telemetry' and r.get('src'):
                        ingested.add(str(r['src']))
        except Exception:
            pass

    new_lines = []
    for fp in sorted(glob.glob(os.path.join(sub_path, '*.json'))):
        src = os.path.basename(fp)
        if src in ingested:
            continue
        try:
            # utf-8-sig: 先頭BOM付き有効JSONも取りこぼさない(production非生成だが堅牢化)
            with open(fp, encoding='utf-8-sig') as f:
                t = json.load(f)
        except Exception:
            continue
        if not isinstance(t, dict):
            continue
        gp, gt = t.get('gates_passed'), t.get('gates_total')
        # score は実テレメトリのゲート通過率。両ゲート不明なら導出不能=スキップ(捏造しない)。
        try:
            gp_i, gt_i = int(gp), int(gt)
        except (TypeError, ValueError):
            continue
        if gt_i <= 0:
            continue
        score = max(0.0, min(1.0, gp_i / gt_i))
        oss = t.get('one_shot_success')
        outcome = 'success' if oss is True else ('fail' if oss is False else 'unknown')

        # plan_summary: 実テレメトリの実測値のみで構成 (人間可読・PIIなし)。
        bits = []
        grade = t.get('dbl_grade')
        if isinstance(grade, str) and grade and grade != 'unknown':
            bits.append('業種辞書グレード %s' % grade)
        layer = t.get('achieved_layer')
        if layer:
            bits.append('到達深度 %s' % layer)
        mc, pc = t.get('model_count'), t.get('page_count')
        if isinstance(mc, int) and mc > 0:
            bits.append('業務モデル%d件' % mc)
        if isinstance(pc, int) and pc > 0:
            bits.append('画面%d件' % pc)
        bits.append('ゲート通過 %d/%d' % (gp_i, gt_i))
        summary = '実生成テレメトリ: ' + ' / '.join(bits)

        # fragments: 「実際に効いた=合格した検証項目」を実 details から抽出 (高スコア時に推奨へ昇格)。
        frags = []
        details = t.get('details')
        if isinstance(details, dict):
            for k, v in sorted(details.items()):
                if str(v).strip().upper() in ('PASS', 'OK', 'PASSED', 'GREEN'):
                    frags.append('検証合格: %s' % k)
        for flag, label in (('crud_ok', 'CRUD入力経路の実装'),
                            ('login_ok', '実DBログインの成立'),
                            ('build_ok', '本番ビルド成功')):
            if t.get(flag) is True:
                frags.append(label)
        if layer:
            frags.append('業務深度 %s 到達構成' % layer)
        # 重複除去・上限20 (qg_record と同仕様)
        seen = set(); frags2 = []
        for x in frags:
            if x not in seen:
                seen.add(x); frags2.append(x)
        frags = frags2[:20]

        # ts はファイル名 (20260613T125151.json) から復元。失敗時は src をそのまま。
        m = re.match(r'(\d{8})T(\d{6})', src)
        if m:
            dd, tt = m.group(1), m.group(2)
            ts = '%s-%s-%sT%s:%s:%s' % (dd[0:4], dd[4:6], dd[6:8], tt[0:2], tt[2:4], tt[4:6])
        else:
            ts = src
        rec_id = 'qg-tlm-' + hashlib.sha1((dom + '|' + src).encode('utf-8')).hexdigest()[:16]
        # 失敗レコードへ構造化「失敗シグナル」を付与(還流で制約に変換・言語非依存=日本語要約に非依存)。
        # 構造化テレメトリの真偽値/深度から導出するため、qg_classify_failure のテキスト分類より頑健。
        failure_signals = []
        if outcome == 'fail':
            if t.get('login_ok') is False:
                failure_signals.append('login_failed')
            if t.get('crud_ok') is False:
                failure_signals.append('crud_failed')
            if t.get('build_ok') is False:
                failure_signals.append('build_failed')
            _m2 = re.match(r'[Ll](\d+)', str(layer or ''))
            if _m2 and int(_m2.group(1)) < 5:
                failure_signals.append('shallow_depth')
            if not failure_signals:
                failure_signals.append('generic_fail')
        rec = {
            'id': rec_id,
            'ts': ts,
            'domain': dom,
            'plan_summary': _qg_scrub(summary)[:2000],   # PII二重防御
            'score': round(score, 4),
            'outcome': outcome,
            'fragments': [_qg_scrub(str(x))[:300] for x in frags],   # PII二重防御
            'origin': 'telemetry',
            'src': src,
        }
        if failure_signals:
            rec['failure_signals'] = failure_signals
        # テレメトリに tenant/company 識別子があれば HMAC 化して取り込む(無ければ no-op=従来挙動)。
        # これにより実生成テレメトリ経路でもクロステナント蒸留のフライホイールが回り始める。
        _tid_raw = ''
        for _k in ('tenant_id', 'tenant', 'company_id', 'company'):
            _v = t.get(_k)
            if isinstance(_v, (str, int)) and str(_v).strip():
                _tid_raw = str(_v).strip()
                break
        if _tid_raw:
            _th = _qg_tenant_hash(_tid_raw)
            if _th:
                rec['tenant_hash'] = _th
        new_lines.append(json.dumps(rec, ensure_ascii=False))

    if new_lines:
        try:
            with open(jsonl_path, 'a', encoding='utf-8') as f:
                f.write('\n'.join(new_lines) + '\n')
            total_ingested += len(new_lines)
        except Exception:
            pass
        # 閉ループ可観測性 (軽量メトリクス): 取込が発生した時のみ1行追記 (owned・local・best-effort)。
        try:
            with open(os.path.join(qdir, '.qg_ingest_metrics.jsonl'), 'a', encoding='utf-8') as mf:
                mf.write(json.dumps({'ts': ts, 'domain': dom, 'ingested': len(new_lines)},
                                    ensure_ascii=False) + '\n')
        except Exception:
            pass

    # ★ロック解放: read→write 直列区間の末尾 (反復ごとに必ず解放=リーク時も stale 回収で自己治癒)
    if _have_lock:
        _qg_release_lock(_lockdir)

if total_ingested:
    print(total_ingested)
PY
}

# qg_update_outcome <record_id|latest> <success|fail> [score 0-1]
# 完成ゲートhookから引数のみで呼べる公開関数(対話なし) (PFP-114)。
# pending のまま放置されていた outcome を実績で確定する。
#   record_id : qg_record が返した id。"latest" 指定時は最新の pending レコードを対象にする。
#   score     : 省略可。指定時は score も実測値で上書きする。
qg_update_outcome() {
  qg_init
  local rid="${1:-}" outcome="${2:-}"
  if [[ -z "$rid" || -z "$outcome" ]]; then
    echo "usage: qg_update_outcome <record_id|latest> <success|fail> [score]" >&2
    return 1
  fi
  case "$outcome" in
    success|fail) ;;
    *) echo "[quality-genome] outcome は success|fail のみ指定可能です: ${outcome}" >&2; return 1;;
  esac
  QG_DIR="$QG_DIR" QG_ID="$rid" QG_OUTCOME="$outcome" QG_NEW_SCORE="${3:-}" \
  python3 - <<'PY' 2>/dev/null || return 1
import os, json, glob, datetime
d = os.environ
qdir = d['QG_DIR']
rid = d.get('QG_ID') or ''
outcome = d.get('QG_OUTCOME') or ''
new_score = (d.get('QG_NEW_SCORE') or '').strip()
target_path = None
target_idx = -1
if rid == 'latest':
    # 全ドメインから最新の pending レコードを探索
    best_ts = ''
    for path in sorted(glob.glob(os.path.join(qdir, '*.jsonl'))):
        try:
            with open(path, encoding='utf-8') as f:
                for i, line in enumerate(f):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        r = json.loads(line)
                    except Exception:
                        continue
                    if r.get('outcome') == 'pending' and str(r.get('ts') or '') >= best_ts:
                        best_ts = str(r.get('ts') or '')
                        target_path, target_idx = path, i
        except Exception:
            continue
else:
    for path in sorted(glob.glob(os.path.join(qdir, '*.jsonl'))):
        try:
            with open(path, encoding='utf-8') as f:
                for i, line in enumerate(f):
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        r = json.loads(line)
                    except Exception:
                        continue
                    if r.get('id') == rid:
                        target_path, target_idx = path, i
                        break
        except Exception:
            continue
        if target_path:
            break
if target_path is None or target_idx < 0:
    raise SystemExit(1)
# 対象行のみ書き換え(temp file + os.replace で安全に)
with open(target_path, encoding='utf-8') as f:
    lines = f.read().splitlines()
r = json.loads(lines[target_idx])
r['outcome'] = outcome
if new_score:
    try:
        r['score'] = round(max(0.0, min(1.0, float(new_score))), 4)
    except Exception:
        pass
r['outcome_ts'] = datetime.datetime.now().isoformat(timespec='seconds')
lines[target_idx] = json.dumps(r, ensure_ascii=False)
tmp = target_path + '.tmp'
with open(tmp, 'w', encoding='utf-8') as f:
    f.write('\n'.join(lines) + '\n')
os.replace(tmp, target_path)
print(r.get('id') or 'updated')
PY
}

# qg_recommend <domain> [n]  -> 注入用テキスト(高スコア実績の効いた断片 Top N)
qg_recommend() {
  qg_init
  # 実データ還流(B-4): 読み取り前に実生成テレメトリを canonical jsonl へ取込む(冪等)。
  # これにより推奨は「実生成結果」を根拠にする。テレメトリ不在ドメインは no-op。
  qg_ingest_telemetry "${1:-general}" >/dev/null 2>&1 || true
  QG_DIR="$QG_DIR" QG_DOMAIN="${1:-general}" QG_N="${2:-5}" python3 - <<'PY' 2>/dev/null || true
import os, json, re
from collections import Counter
d = os.environ
domain = re.sub(r'[^A-Za-z0-9_-]', '_', d.get('QG_DOMAIN', 'general'))[:64] or 'general'
path = os.path.join(d['QG_DIR'], domain + '.jsonl')
try:
    n = max(1, int(d.get('QG_N') or 5))
except Exception:
    n = 5
if not os.path.exists(path):
    raise SystemExit(0)
frags = Counter()
hi = 0
with open(path, encoding='utf-8') as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        try:
            r = json.loads(line)
        except Exception:
            continue
        if float(r.get('score', 0)) >= 0.7 and r.get('outcome') != 'fail':
            hi += 1
            for fr in r.get('fragments', []):
                if fr:
                    frags[fr.strip()] += 1
if not frags:
    raise SystemExit(0)
top = [f for f, _ in frags.most_common(n)]
print("## 過去の高品質実績から学習した推奨パターン (Quality Genome / {}件の成功計画より)".format(hi))
for t in top:
    print("- " + t)
PY
}

# qg_stats <domain>  -> "records=N avg_score=X success_rate=Y"
qg_stats() {
  qg_init
  # 実データ還流(B-4): 集計前に実生成テレメトリを取込む(冪等)。stats は実生成結果を反映する。
  qg_ingest_telemetry "${1:-general}" >/dev/null 2>&1 || true
  QG_DIR="$QG_DIR" QG_DOMAIN="${1:-general}" python3 - <<'PY' 2>/dev/null || echo "records=0 avg_score=0.0 success_rate=0.0"
import os, json, re
d = os.environ
domain = re.sub(r'[^A-Za-z0-9_-]', '_', d.get('QG_DOMAIN', 'general'))[:64] or 'general'
path = os.path.join(d['QG_DIR'], domain + '.jsonl')
if not os.path.exists(path):
    print("records=0 avg_score=0.0 success_rate=0.0")
    raise SystemExit(0)
n = 0; s = 0.0; ok = 0
with open(path, encoding='utf-8') as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        try:
            r = json.loads(line)
        except Exception:
            continue
        n += 1
        s += float(r.get('score', 0))
        if r.get('outcome') == 'success':
            ok += 1
print("records=%d avg_score=%.3f success_rate=%.3f" % (n, (s / n if n else 0), (ok / n if n else 0)))
PY
}

# qg_recommend_constraints <domain> [n]  -> 次回生成へ注入する CONSTRAINTS ブロック
# -----------------------------------------------------------------------------
# 還流反映強化 (B-3 goal#3): 既存 qg_recommend(成功フラグメント=「効いた手」)に加えて、
# 同ドメインの失敗レコード(outcome=fail)を qg_classify_failure カタログで分類し、
# 「失敗から学習した強制制約」(bcrypt/モック禁止・深さL5・実DBログイン 等)を供給する。
# 学習が生成品質を上げる経路を、成功(正例)と失敗(負例)の両輪で実データ駆動にする。
# カタログは qg_classify_failure を単一の所有とし、本関数はそれを呼ぶだけ(定義の三重化を回避)。
qg_recommend_constraints() {
  qg_init
  local domain="${1:-general}" n="${2:-5}"
  qg_ingest_telemetry "$domain" >/dev/null 2>&1 || true
  # ① 成功実績からの推奨(既存経路をそのまま活用=正例の還流)
  qg_recommend "$domain" "$n"
  # ② 失敗レコードから「分類器に渡す probe トークン」を1行ずつ取得(domain完全一致・fail のみ)。
  #    構造化シグナル(login_failed 等)は言語非依存の正準トークンへ写像し、テキスト要約しか無い
  #    合成レコードは要約そのものを probe にする。いずれも単一カタログ qg_classify_failure に通す。
  local path="$QG_DIR/$(printf '%s' "$domain" | sed 's/[^A-Za-z0-9_-]/_/g' | cut -c1-64).jsonl"
  [[ -f "$path" ]] || return 0
  local probes
  probes="$(QG_PATH="$path" python3 - <<'PY' 2>/dev/null || true
import os, json
# 構造化シグナル → qg_classify_failure が確実に分類できる正準 probe トークン(単一カタログ再利用)
SIG2PROBE = {
    'login_failed':  'runtime-login smoke FAILED auth 401',
    'crud_failed':   'runtime-crud smoke FAILED rollback',
    'build_failed':  'next build compilation error module not found',
    'shallow_depth': 'quality gate FAIL one_shot_success false achieved L2',
    'generic_fail':  'chain exit code 1 nonzero error',
}
p = os.environ['QG_PATH']
emitted = []
try:
    with open(p, encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                r = json.loads(line)
            except Exception:
                continue
            if r.get('outcome') != 'fail':
                continue
            sigs = r.get('failure_signals')
            if isinstance(sigs, list) and sigs:
                for s in sigs:
                    pr = SIG2PROBE.get(str(s))
                    if pr:
                        emitted.append(pr)
            else:
                # 構造化シグナル無し(合成レコード等)はテキスト要約を probe にする
                s = (r.get('plan_summary') or '').replace('\n', ' ').strip()
                if s:
                    emitted.append(s)
except Exception:
    pass
for x in emitted:
    print(x)
PY
)"
  [[ -z "$probes" ]] && return 0
  # ③ 各 probe を単一カタログで分類 → constraint 抽出 → 重複除去
  local seen="" out="" line cls hint
  while IFS= read -r line; do
    [[ -z "$line" ]] && continue
    cls="$(qg_classify_failure "$line")"
    hint="${cls#*constraint=}"
    [[ -z "$hint" || "$hint" == "$cls" ]] && continue
    case "$seen" in *"|$hint|"*) continue;; esac
    seen="$seen|$hint|"
    out="$out- $hint"$'\n'
  done <<< "$probes"
  if [[ -n "$out" ]]; then
    echo ""
    echo "## 過去の失敗から学習した強制制約 (Quality Genome / 次回生成のCONSTRAINTSに反映)"
    printf '%s' "$out"
  fi
  # ④ 因果スコア還流 (v2043/Lane6・opt-in): 転換が実在(status=converged)するクラスのみ、
  #    「この制約注入で成功率X%・median 修正Y回」を実測値で注記する。
  #    ★転換対ゼロのクラスは一切出さない=単一事例の false-positive を MUST 昇格させない(堀の信頼性)。
  #    ★MUST昇格ガード: pairs>=2(単一事例の false-positive を昇格させない=堀の信頼性)。
  #    下限クランプ: K_MIN/N_MIN と同様、env で 2 未満には下げられない(信頼性ガードを env 無効化不可)。
  local _min_pairs="${QG_CAUSAL_MIN_PAIRS:-2}"
  [[ "$_min_pairs" =~ ^[0-9]+$ ]] || _min_pairs=2
  (( _min_pairs < 2 )) && _min_pairs=2
  local traj; traj="$(qg_trajectory_pairs "$domain" 2>/dev/null | grep -E 'status=converged' || true)"
  if [[ -n "$traj" ]]; then
    local tl cls cr md pairs pct emitted=""
    while IFS= read -r tl; do
      [[ -z "$tl" ]] && continue
      pairs="$(printf '%s' "$tl" | sed -E 's/.*pairs=([0-9]+).*/\1/')"
      [[ "${pairs:-0}" -ge "$_min_pairs" ]] || continue   # 単一事例(pairs<2)は MUST 昇格させない
      cls="$(printf '%s' "$tl" | sed -E 's/.*class=([^ ]+).*/\1/')"
      cr="$(printf '%s' "$tl" | sed -E 's/.*conversion_rate=([^ ]+).*/\1/')"
      md="$(printf '%s' "$tl" | sed -E 's/.*median_fixes=([^ ]+).*/\1/')"
      pct="$(awk "BEGIN{printf \"%.0f\", ${cr:-0}*100}" 2>/dev/null || echo 0)"
      emitted="${emitted}- ${cls}: 制約注入で成功率 ${pct}%・median 修正 ${md} 回で解消した実績(因果スコア / ${pairs}件の転換軌跡)"$'\n'
    done <<< "$traj"
    if [[ -n "$emitted" ]]; then
      echo ""
      echo "## 因果スコア付き制約 (Quality Genome / 転換実績≥${_min_pairs}件のクラスのみ・収集中/単一事例は非表示)"
      printf '%s' "$emitted"
    fi
  fi
}

# qg_classify_failure <raw_error_or_context>  -> "class=<id> label=<ja> constraint=<hint>"
# -----------------------------------------------------------------------------
# エラー分類カタログ (B-2): 生成失敗の生コンテキストを canonical な失敗クラスへ正規化する。
# chain_exit_nonzero(従来)に加え、生成段別の失敗クラス(prompt超過切詰め / 品質ゲートFAIL /
# CRUD検証FAIL / デプロイ失敗 / build / typecheck / login)を辞書化し、各クラスに次回生成へ
# 効く CONSTRAINTS ヒントを紐付ける。qg_recommend の還流に「失敗から学んだ制約」を供給できる。
# 完全に純関数 (副作用なし・python3標準ライブラリのみ)。判定不能は unknown。
qg_classify_failure() {
  QG_RAW="${*:-}" python3 - <<'PY' 2>/dev/null || { echo "class=unknown label=分類不能 constraint="; return 0; }
import os, re
raw = os.environ.get('QG_RAW', '') or ''
low = raw.lower()
# (class_id, 日本語ラベル, 兆候パターン群, 次回CONSTRAINTSヒント)
# 上から順に優先評価 (より具体的な段別失敗を chain_exit_nonzero より先に判定)。
CATALOG = [
    ('prompt_truncation', 'プロンプト超過による末尾切詰め',
     [r'prompt.*(too long|truncat|exceed|over.?limit)', r'context.*(length|window).*exceed',
      r'切[りり]?詰め', r'token.*limit', r'max.*tokens'],
     'プロンプトのCONSTRAINTS(bcrypt/モック禁止/zod二重検証)を末尾でなく先頭に固定配置し、UTF-8境界で安全に切る'),
    ('crud_verify_fail', 'CRUD実走検証の失敗',
     [r'crud.*(fail|smoke.*fail)', r'runtime-crud', r'rollback.*(fail|残存)',
      r'create.*read.*update.*delete', r'txn.*fail',
      r'crud.*(失敗|エラー)', r'ロールバック', r'登録.*(失敗|できない)', r'入力.*失敗'],
     '全業務モデルに new 作成フォーム+server action(prisma.create/update)+[id]/edit+確認付き削除を最初から織り込む'),
    ('quality_gate_fail', '品質ゲートの不合格',
     [r'(quality|gate).*(fail|block)', r'verdict.*(fail|block)', r'pfp-\d+.*fail',
      r'one_shot_success.*false', r'achieved.*l[0-4]\b',
      r'品質.*(失敗|不合格|エラー)', r'ゲート.*(失敗|不合格)', r'検証.*不合格', r'深さ.*不足'],
     '深さL5まで自走補強(L4実データseed各10-50件/L5全モデルに[id]詳細+一覧結線/L6相互リンク+集計)'),
    ('login_fail', '実DBログインの不成立',
     [r'login.*(fail|smoke.*fail)', r'runtime-login', r'auth.*fail', r'nextauth.*url',
      r'unauthorized', r'401',
      r'ログイン.*(失敗|できない)', r'認証.*失敗', r'サインイン.*失敗'],
     'SQLite既定(file:./dev.db)+seedでadmin事前投入し、npm run dev だけで初回ログインまで到達させる'),
    ('build_fail', '本番ビルドの失敗',
     [r'\bbuild.*(fail|error)', r'next.*build.*fail', r'compilation.*(error|failed)',
      r'module not found', r'cannot find module',
      r'ビルド.*(失敗|エラー)', r'コンパイル.*(失敗|エラー)', r'モジュール.*(見つから|不明)'],
     '生成直後に npm run build / typecheck / prisma validate を exit 0 まで反復し未解決importを残さない'),
    ('typecheck_fail', '型検査の失敗',
     [r'(tsc|typescript|typecheck).*(error|fail)', r'type .* is not assignable',
      r'ts\d{3,}\b', r'型.*(エラー|不一致|合わない)', r'型検査.*失敗'],
     'strict TypeScript 0 error を完成条件にし、enumはSQLite非対応のため string union + zod で表現する'),
    ('deploy_fail', 'デプロイ/本番受け渡しの失敗',
     [r'deploy.*(fail|error)', r'vercel.*(error|fail)', r'production.*(login|seed).*fail',
      r'serverless.*sqlite', r'pool.*(exhaust|未設定)',
      r'デプロイ.*(失敗|エラー)', r'本番.*(反映|公開).*失敗', r'配信.*失敗'],
     'デプロイ時は本番URL実ログインprobeをPASSさせ、SQLite-on-serverless/未シード/プール未設定を出荷前に潰す'),
    ('lint_fail', 'Lint/静的解析の警告残存',
     [r'eslint.*(error|warn)', r'lint.*fail', r'\d+ problems?\b', r'lint.*(警告|エラー)'],
     'ESLint 警告0件を完成条件に含め、空イベントハンドラ・未使用import・TODO残存を除去する'),
    ('chain_exit_nonzero', '生成チェーンの非ゼロ終了(汎用)',
     [r'exit.*(code)?.*[1-9]', r'non-?zero', r'chain.*(fail|error)', r'\berror\b', r'\bfail',
      r'失敗', r'エラー', r'異常終了', r'中断'],
     '失敗段の根本原因を causal_healer で特定し、原因除去(リトライでなく)で修復する'),
]
for cid, label, pats, hint in CATALOG:
    for p in pats:
        if re.search(p, low):
            print("class=%s label=%s constraint=%s" % (cid, label, hint))
            raise SystemExit(0)
print("class=unknown label=分類不能 constraint=")
PY
}

# =============================================================================
# v2043 (Lane6 / クロステナント学習蒸留 + 失敗→成功 因果還流)
# -----------------------------------------------------------------------------
# 追加要素:
#   qg_tenant_hash       : テナント識別子を HMAC-SHA256(per-tenant salt 二重) で匿名化(原値非保存)。
#   qg_trajectory_pairs  : 同一 domain × 同一 failure_class の fail→success 軌跡を因果スコア化。
# 不変条件(契約):
#   - 既存 record schema(id/ts/domain/plan_summary/score/outcome/fragments)は破壊しない。
#     tenant_hash は追加キー(欠落=従来挙動)。
#   - PII二重防御(_QG_PII)・qg_classify_failure 9クラス契約は不変。
#   - 端末内完結・外部送信なし(python3 標準ライブラリ hmac/hashlib/secrets のみ)。
# =============================================================================

# qg_tenant_hash <raw_tenant_id>  -> "th-<16hex>" の安定擬似名(per-tenant salt 二重HMAC・不可逆)
# -----------------------------------------------------------------------------
# 匿名化契約(原値残置=CRITICAL の根絶):
#   - per-installation 秘密(HMAC鍵)を learning/quality-genome/.qg_tenant_salt(mode 0600)に
#     一度だけ生成。配布対象外・端末内完結。
#   - per-tenant salt = HMAC(secret, "salt|"+tid)。tenant_hash = HMAC(per_tenant_salt, "tid|"+tid)[:16]。
#     決定的(同テナント→同擬似名=k-匿名性の異なり数を数えられる)かつ不可逆(secret 不知では原値復元不能)。
#   - 原値 tenant_id は標準出力にも jsonl にも一切書かない(擬似名のみ返す)。
qg_tenant_hash() {
  qg_init
  QG_DIR="$QG_DIR" QG_TID="${1:-}" python3 - <<'PY' 2>/dev/null || true
import os, hmac, hashlib, secrets
d = os.environ
tid = (d.get('QG_TID') or '').strip()
if not tid:
    raise SystemExit(0)
salt_file = os.path.join(d['QG_DIR'], '.qg_tenant_salt')
secret = None
try:
    with open(salt_file, 'r', encoding='utf-8') as f:
        secret = f.read().strip()
except Exception:
    secret = None
if not secret:
    secret = secrets.token_hex(32)
    try:
        fd = os.open(salt_file, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            f.write(secret)
    except FileExistsError:
        # レース: 別プロセスが先に作成 → そちらの secret を採用(擬似名の安定性を保つ)
        try:
            with open(salt_file, 'r', encoding='utf-8') as f:
                secret = f.read().strip()
        except Exception:
            pass
    except Exception:
        pass
key = secret.encode('utf-8')
per_tenant_salt = hmac.new(key, ('salt|' + tid).encode('utf-8'), hashlib.sha256).digest()
th = hmac.new(per_tenant_salt, ('tid|' + tid).encode('utf-8'), hashlib.sha256).hexdigest()[:16]
print('th-' + th)
PY
}

# qg_trajectory_pairs <domain>  -> 同一 domain × 同一 failure_class の fail→success 軌跡を因果スコア化
# -----------------------------------------------------------------------------
# 因果還流 (B-3 goal): 失敗レコードを failure_signals(構造化・言語非依存)から 9クラスへ写像し、
#   同一テナント系列(tenant_hash 単位・無ければ単一バケット)内で fail の後方に最初の success を
#   探索して「転換(converted)」を判定。クラスごとに conversion_rate(転換率)と median_fixes
#   (解消までの median 試行回数)を実測する。
#   ★信頼性の砦: 転換対ゼロ(pairs=0)のクラスは status=collection と明示し conversion を捏造しない。
#     単一事例の MUST 昇格は呼出側(qg_recommend_constraints)で pairs>=1 ガードにより防ぐ。
qg_trajectory_pairs() {
  qg_init
  local domain="${1:-general}"
  qg_ingest_telemetry "$domain" >/dev/null 2>&1 || true
  local path="$QG_DIR/$(printf '%s' "$domain" | sed 's/[^A-Za-z0-9_-]/_/g' | cut -c1-64).jsonl"
  [[ -f "$path" ]] || { echo "trajectory_pairs=0 domain=${domain} status=no_data"; return 0; }
  QG_PATH="$path" python3 - <<'PY' 2>/dev/null || { echo "trajectory_pairs=0 status=error"; return 0; }
import os, json, statistics
from collections import defaultdict
p = os.environ['QG_PATH']
# failure_signals(構造化) → 9クラスへの正準写像(qg_classify_failure カタログと整合・三重定義回避)
SIG2CLASS = {
    'login_failed':  'login_fail',
    'crud_failed':   'crud_verify_fail',
    'build_failed':  'build_fail',
    'shallow_depth': 'quality_gate_fail',
    'generic_fail':  'chain_exit_nonzero',
}
recs = []
try:
    with open(p, encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                recs.append(json.loads(line))
            except Exception:
                continue
except Exception:
    raise SystemExit(0)
recs.sort(key=lambda r: str(r.get('ts') or ''))   # ts 昇順(安定)
seqs = defaultdict(list)
for r in recs:
    seqs[str(r.get('tenant_hash') or 'none')].append(r)

def fail_class(r):
    sigs = r.get('failure_signals')
    if isinstance(sigs, list):
        for s in sigs:
            c = SIG2CLASS.get(str(s))
            if c:
                return c
    fc = r.get('failure_class')
    if isinstance(fc, str) and fc:
        return fc
    return 'unspecified'

agg = {}   # class -> {'fails':int, 'conv':int, 'fixes':[int]}
for th, seq in seqs.items():
    n = len(seq)
    for i, r in enumerate(seq):
        if (r.get('outcome') or '') != 'fail':
            continue
        c = fail_class(r)
        a = agg.setdefault(c, {'fails': 0, 'conv': 0, 'fixes': []})
        a['fails'] += 1
        fixes = 0
        converted = False
        for j in range(i + 1, n):
            fixes += 1
            if (seq[j].get('outcome') or '') == 'success':
                converted = True
                break
        if converted:
            a['conv'] += 1
            a['fixes'].append(fixes)

out = []
for c in sorted(agg):
    a = agg[c]
    fails = a['fails']
    conv = a['conv']
    cr = (conv / fails) if fails else 0.0
    med = (statistics.median(a['fixes']) if a['fixes'] else 0)
    status = 'converged' if conv >= 1 else 'collection'
    out.append("class=%s conversion_rate=%.3f median_fixes=%s pairs=%d fails=%d status=%s"
               % (c, cr, (med if a['fixes'] else 0), conv, fails, status))
if not out:
    print("trajectory_pairs=0 status=no_fail_records")
else:
    print("## 因果軌跡スコア (Quality Genome / 同一failure_class fail→success 転換率・実測)")
    for line in out:
        print(line)
PY
}

# 直接実行時のCLIエントリ(疎結合呼び出し用)
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
  case "${1:-help}" in
    record)           shift; qg_record "$@";;
    update-outcome)   shift; qg_update_outcome "$@";;
    ingest-telemetry) shift; n=$(qg_ingest_telemetry "$@"); echo "ingested=${n:-0}";;
    recommend)        shift; qg_recommend "$@";;
    recommend-constraints) shift; qg_recommend_constraints "$@";;
    stats)            shift; qg_stats "$@";;
    classify-failure) shift; qg_classify_failure "$@";;
    tenant-hash)      shift; qg_tenant_hash "$@";;
    trajectory-pairs) shift; qg_trajectory_pairs "$@";;
    *) echo "usage: $0 {record <domain> <summary> <score> <outcome> [fragments] [tenant_id]|update-outcome <id|latest> <success|fail> [score]|ingest-telemetry [domain]|recommend <domain> [n]|recommend-constraints <domain> [n]|stats <domain>|classify-failure <raw_error_text>|tenant-hash <tenant_id>|trajectory-pairs <domain>}";;
  esac
fi
