#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v2012.0 - Web Creative Quality Gate Extension
# =============================================================================
# LP/コーポレートサイト開発の品質検証10軸
#
# 既存 quality-gate.sh の拡張モジュール。Web制作物に特化した品質ゲートを追加する。
#
# 検証軸:
#   1. ブランド一貫性 (Brand Consistency)
#   2. CV最適化 (Conversion Optimization)
#   3. レスポンシブ設計 (Responsive Design)
#   4. パフォーマンス (Performance)
#   5. SEO対策 (SEO Optimization)
#   6. アクセシビリティ (Accessibility)
#   7. アニメーション品質 (Animation Quality)
#   8. CMS運用性 (CMS Operability)
#   9. コンテンツ品質 (Content Quality)
#  10. モバイルファースト (Mobile First)
#
# 使用方法:
#   source lib/quality-gate-web.sh
#   qgw_run_all_checks "/path/to/project"
#   # 戻り値: 0=PASS, 1=FAIL  スコア: 0-100
# =============================================================================

[[ -n "${_QUALITY_GATE_WEB_LOADED:-}" ]] && return 0
_QUALITY_GATE_WEB_LOADED=1

# ============================================================
# Constants
# ============================================================
QGW_VERSION="2012.0"
QGW_DEFAULT_THRESHOLD=80
QGW_WARN_THRESHOLD=60

# Weight for each axis (total = 100)
QGW_WEIGHT_BRAND=12
QGW_WEIGHT_CV=14
QGW_WEIGHT_RESPONSIVE=12
QGW_WEIGHT_PERFORMANCE=10
QGW_WEIGHT_SEO=12
QGW_WEIGHT_A11Y=10
QGW_WEIGHT_ANIMATION=6
QGW_WEIGHT_CMS=8
QGW_WEIGHT_CONTENT=8
QGW_WEIGHT_MOBILE_FIRST=8

# ============================================================
# Internal state
# ============================================================
_QGW_PROJECT_DIR=""
_QGW_FINDINGS=()
_QGW_SCORES=()
_QGW_REPORT_FILE=""

_qgw_reset_state() {
    _QGW_FINDINGS=()
    _QGW_SCORES=()
    _QGW_REPORT_FILE=""
}

# ============================================================
# Logging
# ============================================================
_qgw_log() {
    local level="$1" msg="$2"
    local timestamp
    timestamp="$(date '+%Y-%m-%d %H:%M:%S')"
    echo -e "  [QualityGateWeb][${level}] ${msg}" >&2
    if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
        echo "[${timestamp}][QGW][${level}] ${msg}" >> "${SESSION_LOG_DIR}/quality_gate_web.log" 2>/dev/null || true
    fi
}

# ============================================================
# Safe numeric grep count
# ============================================================
_qgw_grep_count() {
    local pattern="$1"
    local result
    result=$(grep -cE "$pattern" 2>/dev/null) || true
    result="${result%%[!0-9]*}"
    echo "${result:-0}"
}

# ============================================================
# File scanning utilities
# ============================================================
_qgw_find_source_files() {
    local dir="$1"
    find "$dir" -type f \( -name "*.js" -o -name "*.jsx" -o -name "*.ts" -o -name "*.tsx" -o -name "*.css" -o -name "*.scss" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        -not -path "*/dist/*" \
        -not -path "*/build/*" \
        -not -path "*/.git/*" \
        -not -path "*/coverage/*" \
        2>/dev/null || true
}

_qgw_find_component_files() {
    local dir="$1"
    find "$dir" -type f \( -name "*.jsx" -o -name "*.tsx" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        -not -path "*/dist/*" \
        -not -path "*/.git/*" \
        2>/dev/null || true
}

_qgw_find_css_files() {
    local dir="$1"
    find "$dir" -type f \( -name "*.css" -o -name "*.scss" -o -name "*.module.css" -o -name "*.module.scss" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        -not -path "*/dist/*" \
        -not -path "*/.git/*" \
        2>/dev/null || true
}

_qgw_find_page_files() {
    local dir="$1"
    find "$dir" -type f \( -name "page.tsx" -o -name "page.jsx" -o -name "page.js" -o -name "page.ts" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        2>/dev/null || true
}

# ============================================================
# Axis 1: Brand Consistency - ブランド一貫性
# ============================================================
qgw_check_brand_consistency() {
    local dir="${1:-$_QGW_PROJECT_DIR}"
    local score=100
    local findings=""

    _qgw_log "INFO" "Axis 1: ブランド一貫性チェック..."

    local all_source
    all_source="$(_qgw_find_source_files "$dir")"

    if [[ -z "$all_source" ]]; then
        _qgw_log "WARN" "ソースファイルが見つかりません"
        _QGW_SCORES+=("brand:50")
        _QGW_FINDINGS+=("BRAND: ソースファイル未検出")
        echo 50
        return
    fi

    # Check for hardcoded hex color values (should use CSS variables or Tailwind tokens)
    local hardcoded_colors=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE '#[0-9a-fA-F]{3,8}[^a-zA-Z0-9]' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        hardcoded_colors=$(( hardcoded_colors + ${count:-0} ))
    done <<< "$all_source"

    if [[ $hardcoded_colors -gt 20 ]]; then
        score=$(( score - 30 ))
        findings="${findings}BRAND: ハードコードカラー ${hardcoded_colors}件検出 (CSS変数/Tailwindトークンを使用してください)\n"
    elif [[ $hardcoded_colors -gt 5 ]]; then
        score=$(( score - 15 ))
        findings="${findings}BRAND: ハードコードカラー ${hardcoded_colors}件検出\n"
    fi

    # Check CSS variables usage
    local css_var_usage=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'var\(--' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        css_var_usage=$(( css_var_usage + ${count:-0} ))
    done <<< "$all_source"

    if [[ $css_var_usage -eq 0 ]]; then
        score=$(( score - 20 ))
        findings="${findings}BRAND: CSS変数(var(--)が未使用。デザイントークンを定義してください\n"
    fi

    # Check font imports are consistent (multiple different font imports = inconsistent)
    local font_imports=0
    local font_families=""
    while IFS= read -r f; do
        local fonts
        fonts=$(grep -oE "font-family:[^;]+" "$f" 2>/dev/null || true)
        if [[ -n "$fonts" ]]; then
            font_families="${font_families}${fonts}\n"
        fi
        local count
        count=$(grep -cE '@import.*fonts|@font-face|googleapis\.com/css' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        font_imports=$(( font_imports + ${count:-0} ))
    done <<< "$all_source"

    local unique_font_count=0
    if [[ -n "$font_families" ]]; then
        unique_font_count=$(echo -e "$font_families" | sort -u | grep -c '[a-zA-Z]' 2>/dev/null) || true
        unique_font_count="${unique_font_count%%[!0-9]*}"
        unique_font_count="${unique_font_count:-0}"
    fi

    if [[ $unique_font_count -gt 4 ]]; then
        score=$(( score - 15 ))
        findings="${findings}BRAND: フォントファミリー ${unique_font_count}種使用。3種以内に統一してください\n"
    fi

    # Check Tailwind config exists (design token centralization)
    if [[ -f "${dir}/tailwind.config.js" ]] || [[ -f "${dir}/tailwind.config.ts" ]]; then
        # Good - centralized design tokens
        :
    else
        score=$(( score - 10 ))
        findings="${findings}BRAND: tailwind.config未検出。デザイントークンの一元管理が必要です\n"
    fi

    [[ $score -lt 0 ]] && score=0

    _QGW_SCORES+=("brand:${score}")
    [[ -n "$findings" ]] && _QGW_FINDINGS+=("$findings")

    _qgw_log "INFO" "ブランド一貫性スコア: ${score}/100"
    echo "$score"
}

# ============================================================
# Axis 2: CV Optimization - CV最適化
# ============================================================
qgw_check_cv_optimization() {
    local dir="${1:-$_QGW_PROJECT_DIR}"
    local score=100
    local findings=""

    _qgw_log "INFO" "Axis 2: CV最適化チェック..."

    local components
    components="$(_qgw_find_component_files "$dir")"

    if [[ -z "$components" ]]; then
        _QGW_SCORES+=("cv:50")
        _QGW_FINDINGS+=("CV: コンポーネントファイル未検出")
        echo 50
        return
    fi

    # Check CTA exists in at least 3 locations
    local cta_count=0
    while IFS= read -r f; do
        local count
        count=$(grep -ciE 'cta|call.?to.?action|btn.*primary|button.*primary|contact.*button|submit.*button|register|sign.?up|get.?started|apply.?now|free.?trial' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        if [[ ${count:-0} -gt 0 ]]; then
            cta_count=$(( cta_count + 1 ))
        fi
    done <<< "$components"

    if [[ $cta_count -lt 3 ]]; then
        score=$(( score - 30 ))
        findings="${findings}CV: CTAが ${cta_count}箇所のみ。最低3箇所に配置してください\n"
    fi

    # Check form has Zod validation
    local form_files=0
    local zod_validated_forms=0
    while IFS= read -r f; do
        local has_form
        has_form=$(grep -cE 'useForm|<form|<Form|onSubmit|handleSubmit' "$f" 2>/dev/null) || true
        has_form="${has_form%%[!0-9]*}"
        if [[ ${has_form:-0} -gt 0 ]]; then
            form_files=$(( form_files + 1 ))
            local has_zod
            has_zod=$(grep -cE 'zodResolver|z\.object|z\.string|zod' "$f" 2>/dev/null) || true
            has_zod="${has_zod%%[!0-9]*}"
            if [[ ${has_zod:-0} -gt 0 ]]; then
                zod_validated_forms=$(( zod_validated_forms + 1 ))
            fi
        fi
    done <<< "$components"

    if [[ $form_files -gt 0 ]] && [[ $zod_validated_forms -eq 0 ]]; then
        score=$(( score - 30 ))
        findings="${findings}CV: フォーム ${form_files}件にZodバリデーションなし。zodResolverを使用してください\n"
    elif [[ $form_files -gt 0 ]] && [[ $zod_validated_forms -lt $form_files ]]; then
        score=$(( score - 15 ))
        findings="${findings}CV: フォーム ${form_files}件中 ${zod_validated_forms}件のみZodバリデーション済み\n"
    fi

    # Check for thank-you / success page
    local has_thankyou=0
    while IFS= read -r f; do
        local count
        count=$(grep -ciE 'thank.?you|success|complete|送信完了|お問い合わせありがとう' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        if [[ ${count:-0} -gt 0 ]]; then
            has_thankyou=1
            break
        fi
    done <<< "$components"

    if [[ $has_thankyou -eq 0 ]]; then
        score=$(( score - 15 ))
        findings="${findings}CV: サンクスページ/成功メッセージ未検出\n"
    fi

    [[ $score -lt 0 ]] && score=0

    _QGW_SCORES+=("cv:${score}")
    [[ -n "$findings" ]] && _QGW_FINDINGS+=("$findings")

    _qgw_log "INFO" "CV最適化スコア: ${score}/100"
    echo "$score"
}

# ============================================================
# Axis 3: Responsive Design - レスポンシブ設計
# ============================================================
qgw_check_responsive() {
    local dir="${1:-$_QGW_PROJECT_DIR}"
    local score=100
    local findings=""

    _qgw_log "INFO" "Axis 3: レスポンシブ設計チェック..."

    local all_source
    all_source="$(_qgw_find_source_files "$dir")"

    if [[ -z "$all_source" ]]; then
        _QGW_SCORES+=("responsive:50")
        _QGW_FINDINGS+=("RESPONSIVE: ソースファイル未検出")
        echo 50
        return
    fi

    # Check Tailwind responsive prefixes (sm:, md:, lg:, xl:)
    local responsive_sm=0
    local responsive_md=0
    local responsive_lg=0
    while IFS= read -r f; do
        local sm md lg
        sm=$(grep -cE '\bsm:' "$f" 2>/dev/null) || true; sm="${sm%%[!0-9]*}"; responsive_sm=$(( responsive_sm + ${sm:-0} ))
        md=$(grep -cE '\bmd:' "$f" 2>/dev/null) || true; md="${md%%[!0-9]*}"; responsive_md=$(( responsive_md + ${md:-0} ))
        lg=$(grep -cE '\blg:' "$f" 2>/dev/null) || true; lg="${lg%%[!0-9]*}"; responsive_lg=$(( responsive_lg + ${lg:-0} ))
    done <<< "$all_source"

    local breakpoint_count=0
    [[ $responsive_sm -gt 0 ]] && breakpoint_count=$(( breakpoint_count + 1 ))
    [[ $responsive_md -gt 0 ]] && breakpoint_count=$(( breakpoint_count + 1 ))
    [[ $responsive_lg -gt 0 ]] && breakpoint_count=$(( breakpoint_count + 1 ))

    if [[ $breakpoint_count -eq 0 ]]; then
        score=$(( score - 40 ))
        findings="${findings}RESPONSIVE: Tailwindレスポンシブプレフィックス(sm:/md:/lg:)未検出\n"
    elif [[ $breakpoint_count -lt 2 ]]; then
        score=$(( score - 20 ))
        findings="${findings}RESPONSIVE: レスポンシブブレークポイント ${breakpoint_count}種のみ。最低2種(md:, lg:)使用してください\n"
    fi

    # Check viewport meta tag in layout/head
    local has_viewport=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'viewport|<meta.*name.*viewport' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        if [[ ${count:-0} -gt 0 ]]; then
            has_viewport=1
            break
        fi
    done <<< "$all_source"

    # Also check layout files specifically
    if [[ $has_viewport -eq 0 ]]; then
        local layout_files
        layout_files=$(find "$dir" -type f \( -name "layout.tsx" -o -name "layout.jsx" -o -name "_document.tsx" -o -name "_app.tsx" \) \
            -not -path "*/node_modules/*" 2>/dev/null || true)
        if [[ -n "$layout_files" ]]; then
            while IFS= read -r f; do
                local count
                count=$(grep -cE 'viewport|Viewport' "$f" 2>/dev/null) || true
                count="${count%%[!0-9]*}"
                if [[ ${count:-0} -gt 0 ]]; then
                    has_viewport=1
                    break
                fi
            done <<< "$layout_files"
        fi
    fi

    if [[ $has_viewport -eq 0 ]]; then
        score=$(( score - 20 ))
        findings="${findings}RESPONSIVE: viewport meta tag未検出\n"
    fi

    # Check for fixed pixel widths (bad pattern)
    local fixed_widths=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'width:\s*[0-9]{4,}px|width:\s*[0-9]+px[^;]*!important' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        fixed_widths=$(( fixed_widths + ${count:-0} ))
    done <<< "$all_source"

    if [[ $fixed_widths -gt 5 ]]; then
        score=$(( score - 20 ))
        findings="${findings}RESPONSIVE: 固定幅(px) ${fixed_widths}件検出。レスポンシブ単位を使用してください\n"
    fi

    [[ $score -lt 0 ]] && score=0

    _QGW_SCORES+=("responsive:${score}")
    [[ -n "$findings" ]] && _QGW_FINDINGS+=("$findings")

    _qgw_log "INFO" "レスポンシブ設計スコア: ${score}/100"
    echo "$score"
}

# ============================================================
# Axis 4: Performance - パフォーマンス
# ============================================================
qgw_check_performance() {
    local dir="${1:-$_QGW_PROJECT_DIR}"
    local score=100
    local findings=""

    _qgw_log "INFO" "Axis 4: パフォーマンスチェック..."

    local components
    components="$(_qgw_find_component_files "$dir")"

    if [[ -z "$components" ]]; then
        _QGW_SCORES+=("performance:50")
        _QGW_FINDINGS+=("PERFORMANCE: コンポーネントファイル未検出")
        echo 50
        return
    fi

    # Check for next/image usage (vs raw <img>)
    local next_image_usage=0
    local raw_img_usage=0
    while IFS= read -r f; do
        local ni ri
        ni=$(grep -cE "from ['\"]next/image['\"]|from 'next/image'|import.*Image.*from.*next" "$f" 2>/dev/null) || true
        ni="${ni%%[!0-9]*}"; next_image_usage=$(( next_image_usage + ${ni:-0} ))
        ri=$(grep -cE '<img\s' "$f" 2>/dev/null) || true
        ri="${ri%%[!0-9]*}"; raw_img_usage=$(( raw_img_usage + ${ri:-0} ))
    done <<< "$components"

    if [[ $next_image_usage -eq 0 ]] && [[ $raw_img_usage -gt 0 ]]; then
        score=$(( score - 30 ))
        findings="${findings}PERFORMANCE: next/image未使用。raw <img>が ${raw_img_usage}件。next/imageに置換してください\n"
    fi

    # Check for priority prop on hero/above-the-fold image
    local has_priority=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'priority\s*[={]|priority\b' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        if [[ ${count:-0} -gt 0 ]]; then
            has_priority=1
            break
        fi
    done <<< "$components"

    if [[ $next_image_usage -gt 0 ]] && [[ $has_priority -eq 0 ]]; then
        score=$(( score - 15 ))
        findings="${findings}PERFORMANCE: ヒーロー画像にpriority propがありません。LCPを改善するために追加してください\n"
    fi

    # Check for lazy loading
    local lazy_usage=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'loading="lazy"|loading=.lazy.|lazy\b.*load|dynamic.*import|React\.lazy|next/dynamic' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        lazy_usage=$(( lazy_usage + ${count:-0} ))
    done <<< "$components"

    if [[ $lazy_usage -eq 0 ]]; then
        score=$(( score - 15 ))
        findings="${findings}PERFORMANCE: lazy loading未検出。below-the-foldコンテンツにはlazyを使用してください\n"
    fi

    # Check for font preloading/optimization
    local all_source
    all_source="$(_qgw_find_source_files "$dir")"
    local font_optimized=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'next/font|font-display:\s*swap|preload.*font|font.*preload' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        if [[ ${count:-0} -gt 0 ]]; then
            font_optimized=1
            break
        fi
    done <<< "$all_source"

    if [[ $font_optimized -eq 0 ]]; then
        score=$(( score - 10 ))
        findings="${findings}PERFORMANCE: フォント最適化(next/font, font-display:swap)未検出\n"
    fi

    [[ $score -lt 0 ]] && score=0

    _QGW_SCORES+=("performance:${score}")
    [[ -n "$findings" ]] && _QGW_FINDINGS+=("$findings")

    _qgw_log "INFO" "パフォーマンススコア: ${score}/100"
    echo "$score"
}

# ============================================================
# Axis 5: SEO - SEO対策
# ============================================================
qgw_check_seo() {
    local dir="${1:-$_QGW_PROJECT_DIR}"
    local score=100
    local findings=""

    _qgw_log "INFO" "Axis 5: SEOチェック..."

    local all_source
    all_source="$(_qgw_find_source_files "$dir")"

    if [[ -z "$all_source" ]]; then
        _QGW_SCORES+=("seo:50")
        _QGW_FINDINGS+=("SEO: ソースファイル未検出")
        echo 50
        return
    fi

    # Check for Metadata export or generateMetadata
    local has_metadata=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'export.*metadata|export.*Metadata|generateMetadata|export const metadata' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        if [[ ${count:-0} -gt 0 ]]; then
            has_metadata=1
            break
        fi
    done <<< "$all_source"

    if [[ $has_metadata -eq 0 ]]; then
        score=$(( score - 25 ))
        findings="${findings}SEO: Next.js Metadata export未検出。各ページにメタデータを定義してください\n"
    fi

    # Check for OGP (Open Graph Protocol)
    local has_ogp=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'openGraph|og:title|og:description|og:image|twitter:card|twitter:title' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        if [[ ${count:-0} -gt 0 ]]; then
            has_ogp=1
            break
        fi
    done <<< "$all_source"

    if [[ $has_ogp -eq 0 ]]; then
        score=$(( score - 20 ))
        findings="${findings}SEO: OGP(Open Graph)タグ未検出。SNSシェア用にOGPを設定してください\n"
    fi

    # Check for JSON-LD structured data
    local has_jsonld=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'application/ld\+json|JSON-LD|jsonLd|json-ld|@context.*schema\.org' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        if [[ ${count:-0} -gt 0 ]]; then
            has_jsonld=1
            break
        fi
    done <<< "$all_source"

    if [[ $has_jsonld -eq 0 ]]; then
        score=$(( score - 20 ))
        findings="${findings}SEO: JSON-LD構造化データ未検出。検索リッチリザルト対応が必要です\n"
    fi

    # Check for sitemap
    local has_sitemap=0
    if [[ -f "${dir}/public/sitemap.xml" ]] || [[ -f "${dir}/app/sitemap.ts" ]] || [[ -f "${dir}/app/sitemap.xml" ]]; then
        has_sitemap=1
    fi
    # Also check for sitemap generation
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'sitemap|MetadataRoute\.Sitemap' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        if [[ ${count:-0} -gt 0 ]]; then
            has_sitemap=1
            break
        fi
    done <<< "$all_source"

    if [[ $has_sitemap -eq 0 ]]; then
        score=$(( score - 15 ))
        findings="${findings}SEO: sitemap.xml未検出。サイトマップを生成してください\n"
    fi

    # Check for robots.txt
    if [[ ! -f "${dir}/public/robots.txt" ]] && [[ ! -f "${dir}/app/robots.ts" ]]; then
        score=$(( score - 10 ))
        findings="${findings}SEO: robots.txt未検出\n"
    fi

    [[ $score -lt 0 ]] && score=0

    _QGW_SCORES+=("seo:${score}")
    [[ -n "$findings" ]] && _QGW_FINDINGS+=("$findings")

    _qgw_log "INFO" "SEOスコア: ${score}/100"
    echo "$score"
}

# ============================================================
# Axis 6: Accessibility - アクセシビリティ
# ============================================================
qgw_check_accessibility() {
    local dir="${1:-$_QGW_PROJECT_DIR}"
    local score=100
    local findings=""

    _qgw_log "INFO" "Axis 6: アクセシビリティチェック..."

    local components
    components="$(_qgw_find_component_files "$dir")"

    if [[ -z "$components" ]]; then
        _QGW_SCORES+=("a11y:50")
        _QGW_FINDINGS+=("A11Y: コンポーネントファイル未検出")
        echo 50
        return
    fi

    # Check for aria- attributes
    local aria_usage=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'aria-label|aria-labelledby|aria-describedby|aria-hidden|aria-live|aria-expanded|role=' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        aria_usage=$(( aria_usage + ${count:-0} ))
    done <<< "$components"

    if [[ $aria_usage -eq 0 ]]; then
        score=$(( score - 30 ))
        findings="${findings}A11Y: ARIA属性が一切未使用。インタラクティブ要素にaria-labelを追加してください\n"
    elif [[ $aria_usage -lt 5 ]]; then
        score=$(( score - 15 ))
        findings="${findings}A11Y: ARIA属性が ${aria_usage}件のみ。不足の可能性があります\n"
    fi

    # Check for alt text on images
    local img_count=0
    local img_with_alt=0
    while IFS= read -r f; do
        local imgs alts
        imgs=$(grep -cE '<img\s|<Image\s' "$f" 2>/dev/null) || true
        imgs="${imgs%%[!0-9]*}"; img_count=$(( img_count + ${imgs:-0} ))
        alts=$(grep -cE 'alt="[^"]+"|alt={[^}]+}|alt=\x27[^\x27]+\x27' "$f" 2>/dev/null) || true
        alts="${alts%%[!0-9]*}"; img_with_alt=$(( img_with_alt + ${alts:-0} ))
    done <<< "$components"

    if [[ $img_count -gt 0 ]] && [[ $img_with_alt -eq 0 ]]; then
        score=$(( score - 25 ))
        findings="${findings}A11Y: 画像 ${img_count}件にalt属性なし\n"
    elif [[ $img_count -gt 0 ]] && [[ $img_with_alt -lt $img_count ]]; then
        local missing=$(( img_count - img_with_alt ))
        score=$(( score - 10 ))
        findings="${findings}A11Y: 画像 ${missing}件にalt属性が不足\n"
    fi

    # Check for semantic HTML (h1, h2, nav, main, footer, section)
    local semantic_count=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE '<h[1-6]|<nav|<main|<footer|<section|<header|<article|<aside' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        semantic_count=$(( semantic_count + ${count:-0} ))
    done <<< "$components"

    if [[ $semantic_count -lt 3 ]]; then
        score=$(( score - 15 ))
        findings="${findings}A11Y: セマンティックHTML要素が ${semantic_count}件のみ。nav/main/footer/sectionを使用してください\n"
    fi

    # Check for focus-visible/focus styles
    local focus_styles=0
    local all_source
    all_source="$(_qgw_find_source_files "$dir")"
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'focus-visible|focus:|:focus|focus-within|tabIndex|tabindex' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        focus_styles=$(( focus_styles + ${count:-0} ))
    done <<< "$all_source"

    if [[ $focus_styles -eq 0 ]]; then
        score=$(( score - 10 ))
        findings="${findings}A11Y: フォーカススタイル(focus-visible)未検出。キーボードナビゲーション対応が必要です\n"
    fi

    [[ $score -lt 0 ]] && score=0

    _QGW_SCORES+=("a11y:${score}")
    [[ -n "$findings" ]] && _QGW_FINDINGS+=("$findings")

    _qgw_log "INFO" "アクセシビリティスコア: ${score}/100"
    echo "$score"
}

# ============================================================
# Axis 7: Animation Quality - アニメーション品質
# ============================================================
qgw_check_animation_quality() {
    local dir="${1:-$_QGW_PROJECT_DIR}"
    local score=100
    local findings=""

    _qgw_log "INFO" "Axis 7: アニメーション品質チェック..."

    local all_source
    all_source="$(_qgw_find_source_files "$dir")"

    if [[ -z "$all_source" ]]; then
        _QGW_SCORES+=("animation:70")
        _QGW_FINDINGS+=("ANIMATION: ソースファイル未検出")
        echo 70
        return
    fi

    # Check for prefers-reduced-motion support
    local reduced_motion=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'prefers-reduced-motion|reduced-motion|useReducedMotion|reducedMotion' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        reduced_motion=$(( reduced_motion + ${count:-0} ))
    done <<< "$all_source"

    # Check if animations exist
    local has_animations=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'framer-motion|motion\.|@keyframes|animation:|transition:|animate\b|useSpring|useAnimation' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        if [[ ${count:-0} -gt 0 ]]; then
            has_animations=1
            break
        fi
    done <<< "$all_source"

    if [[ $has_animations -eq 1 ]] && [[ $reduced_motion -eq 0 ]]; then
        score=$(( score - 30 ))
        findings="${findings}ANIMATION: prefers-reduced-motion未対応。アクセシビリティのために必須です\n"
    fi

    # Check animation durations (warn if > 1s / 1000ms)
    local long_animations=0
    while IFS= read -r f; do
        local count
        # Match duration values > 1 (seconds) or > 1000 (ms)
        count=$(grep -cE 'duration:\s*[2-9]\b|duration:\s*[1-9][0-9]+\b|duration:\s*[0-9]*\.[0-9]*[2-9][^0-9]|1[0-9]{3,}ms|[2-9][0-9]{3,}ms' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        long_animations=$(( long_animations + ${count:-0} ))
    done <<< "$all_source"

    if [[ $long_animations -gt 0 ]]; then
        score=$(( score - 20 ))
        findings="${findings}ANIMATION: 長いアニメーション(>1s) ${long_animations}件検出。0.2-0.5sを推奨\n"
    fi

    # Check Framer Motion usage (quality indicator for LP)
    local framer_usage=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE "from ['\"]framer-motion['\"]|motion\." "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        framer_usage=$(( framer_usage + ${count:-0} ))
    done <<< "$all_source"

    if [[ $has_animations -eq 0 ]]; then
        score=$(( score - 20 ))
        findings="${findings}ANIMATION: アニメーション未検出。LP/サイトにはスクロールアニメーションを推奨\n"
    fi

    [[ $score -lt 0 ]] && score=0

    _QGW_SCORES+=("animation:${score}")
    [[ -n "$findings" ]] && _QGW_FINDINGS+=("$findings")

    _qgw_log "INFO" "アニメーション品質スコア: ${score}/100"
    echo "$score"
}

# ============================================================
# Axis 8: CMS Operability - CMS運用性
# ============================================================
qgw_check_cms_operability() {
    local dir="${1:-$_QGW_PROJECT_DIR}"
    local score=100
    local findings=""

    _qgw_log "INFO" "Axis 8: CMS運用性チェック..."

    # Check for /api/admin/* routes
    local admin_routes=0
    local api_dir="${dir}/app/api/admin"
    if [[ -d "$api_dir" ]]; then
        admin_routes=$(find "$api_dir" -type f -name "route.ts" -o -name "route.js" 2>/dev/null | wc -l)
        admin_routes="${admin_routes// /}"
    fi

    # Also check src/app structure
    local src_api_dir="${dir}/src/app/api/admin"
    if [[ -d "$src_api_dir" ]]; then
        local src_count
        src_count=$(find "$src_api_dir" -type f -name "route.ts" -o -name "route.js" 2>/dev/null | wc -l)
        src_count="${src_count// /}"
        admin_routes=$(( admin_routes + src_count ))
    fi

    # Check for admin pages/routes in pages directory
    local admin_pages=0
    if [[ -d "${dir}/app/admin" ]] || [[ -d "${dir}/src/app/admin" ]]; then
        admin_pages=$(find "$dir" -path "*/admin/*" -name "page.tsx" -o -path "*/admin/*" -name "page.jsx" 2>/dev/null | wc -l)
        admin_pages="${admin_pages// /}"
    fi

    if [[ $admin_routes -eq 0 ]] && [[ $admin_pages -eq 0 ]]; then
        score=$(( score - 35 ))
        findings="${findings}CMS: 管理画面(/api/admin/*, /admin/*)ルート未検出。コンテンツ管理機能が必要です\n"
    fi

    # Check Prisma schema has content models
    local has_content_models=0
    local prisma_schema="${dir}/prisma/schema.prisma"
    if [[ -f "$prisma_schema" ]]; then
        local content_models
        content_models=$(grep -cE 'model\s+(Post|Article|Page|Content|Blog|News|FAQ|Testimonial|Service|Product|Category)' "$prisma_schema" 2>/dev/null) || true
        content_models="${content_models%%[!0-9]*}"
        has_content_models="${content_models:-0}"
    fi

    if [[ $has_content_models -eq 0 ]]; then
        # Check if any ORM/DB schema exists at all
        local has_any_schema=0
        if [[ -f "$prisma_schema" ]]; then
            has_any_schema=1
        fi
        if [[ $has_any_schema -eq 1 ]]; then
            score=$(( score - 20 ))
            findings="${findings}CMS: Prismaスキーマにコンテンツモデル(Post/Article/Page等)未検出\n"
        else
            score=$(( score - 30 ))
            findings="${findings}CMS: Prismaスキーマ自体が未検出。DB連携コンテンツ管理が必要です\n"
        fi
    fi

    # Check for WYSIWYG/Rich text editor
    local has_editor=0
    local all_source
    all_source="$(_qgw_find_source_files "$dir")"
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'tiptap|quill|slate|draft-js|editor|rich-text|markdown|MDXRemote' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        if [[ ${count:-0} -gt 0 ]]; then
            has_editor=1
            break
        fi
    done <<< "$all_source"

    if [[ $has_editor -eq 0 ]] && [[ $has_content_models -gt 0 ]]; then
        score=$(( score - 15 ))
        findings="${findings}CMS: リッチテキストエディター未検出。コンテンツ編集にはWYSIWYGエディターを推奨\n"
    fi

    [[ $score -lt 0 ]] && score=0

    _QGW_SCORES+=("cms:${score}")
    [[ -n "$findings" ]] && _QGW_FINDINGS+=("$findings")

    _qgw_log "INFO" "CMS運用性スコア: ${score}/100"
    echo "$score"
}

# ============================================================
# Axis 9: Content Quality - コンテンツ品質
# ============================================================
qgw_check_content_quality() {
    local dir="${1:-$_QGW_PROJECT_DIR}"
    local score=100
    local findings=""

    _qgw_log "INFO" "Axis 9: コンテンツ品質チェック..."

    local all_source
    all_source="$(_qgw_find_source_files "$dir")"

    if [[ -z "$all_source" ]]; then
        _QGW_SCORES+=("content:50")
        _QGW_FINDINGS+=("CONTENT: ソースファイル未検出")
        echo 50
        return
    fi

    # Check for placeholder text
    local placeholder_count=0
    while IFS= read -r f; do
        local count
        count=$(grep -ciE 'Lorem ipsum|TODO|FIXME|placeholder|PLACEHOLDER|TBD|coming soon|sample text' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        placeholder_count=$(( placeholder_count + ${count:-0} ))
    done <<< "$all_source"

    # Japanese placeholders
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'DUMMY|dummy' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        placeholder_count=$(( placeholder_count + ${count:-0} ))
    done <<< "$all_source"

    if [[ $placeholder_count -gt 10 ]]; then
        score=$(( score - 40 ))
        findings="${findings}CONTENT: プレースホルダーテキスト ${placeholder_count}件検出。本番コンテンツに置換してください\n"
    elif [[ $placeholder_count -gt 3 ]]; then
        score=$(( score - 20 ))
        findings="${findings}CONTENT: プレースホルダーテキスト ${placeholder_count}件検出\n"
    elif [[ $placeholder_count -gt 0 ]]; then
        score=$(( score - 10 ))
        findings="${findings}CONTENT: プレースホルダーテキスト ${placeholder_count}件検出\n"
    fi

    # Check for example.com/test URLs
    local test_urls=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'example\.com|test\.com|localhost:[0-9]|http://127\.0\.0\.1' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        test_urls=$(( test_urls + ${count:-0} ))
    done <<< "$all_source"

    if [[ $test_urls -gt 3 ]]; then
        score=$(( score - 15 ))
        findings="${findings}CONTENT: テストURL(example.com等) ${test_urls}件検出。本番URLに置換してください\n"
    fi

    # Check for empty strings in visible content areas
    local empty_strings=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE '>\s*</(h[1-6]|p|span|a|button)>|"".*title|"".*description|"".*label' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        empty_strings=$(( empty_strings + ${count:-0} ))
    done <<< "$all_source"

    if [[ $empty_strings -gt 3 ]]; then
        score=$(( score - 15 ))
        findings="${findings}CONTENT: 空コンテンツ要素 ${empty_strings}件検出\n"
    fi

    [[ $score -lt 0 ]] && score=0

    _QGW_SCORES+=("content:${score}")
    [[ -n "$findings" ]] && _QGW_FINDINGS+=("$findings")

    _qgw_log "INFO" "コンテンツ品質スコア: ${score}/100"
    echo "$score"
}

# ============================================================
# Axis 10: Mobile First - モバイルファースト
# ============================================================
qgw_check_mobile_first() {
    local dir="${1:-$_QGW_PROJECT_DIR}"
    local score=100
    local findings=""

    _qgw_log "INFO" "Axis 10: モバイルファーストチェック..."

    local all_source
    all_source="$(_qgw_find_source_files "$dir")"

    if [[ -z "$all_source" ]]; then
        _QGW_SCORES+=("mobile_first:50")
        _QGW_FINDINGS+=("MOBILE_FIRST: ソースファイル未検出")
        echo 50
        return
    fi

    # Mobile-first: base styles should be mobile, breakpoints scale UP
    # Check that responsive classes use min-width (scale up) not max-width (scale down)
    local max_width_queries=0
    local min_width_queries=0
    while IFS= read -r f; do
        local max_w min_w
        max_w=$(grep -cE 'max-width:\s*[0-9]' "$f" 2>/dev/null) || true
        max_w="${max_w%%[!0-9]*}"; max_width_queries=$(( max_width_queries + ${max_w:-0} ))
        min_w=$(grep -cE 'min-width:\s*[0-9]' "$f" 2>/dev/null) || true
        min_w="${min_w%%[!0-9]*}"; min_width_queries=$(( min_width_queries + ${min_w:-0} ))
    done <<< "$all_source"

    if [[ $max_width_queries -gt $min_width_queries ]] && [[ $max_width_queries -gt 3 ]]; then
        score=$(( score - 25 ))
        findings="${findings}MOBILE_FIRST: max-width(${max_width_queries}件) > min-width(${min_width_queries}件)。デスクトップファースト設計になっています\n"
    fi

    # Tailwind: check that base classes are mobile, with sm:/md:/lg: for larger screens
    # Good: "flex flex-col md:flex-row" (base=mobile column, md=row)
    # Bad: "flex flex-row sm:flex-col" (base=desktop, sm=mobile override)
    local desktop_base_count=0
    while IFS= read -r f; do
        local count
        # Detect patterns where sm: is used to go smaller (desktop-first anti-pattern)
        count=$(grep -cE 'sm:hidden|sm:block.*hidden|sm:flex-col.*flex-row|sm:w-full.*w-\[' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        desktop_base_count=$(( desktop_base_count + ${count:-0} ))
    done <<< "$all_source"

    if [[ $desktop_base_count -gt 5 ]]; then
        score=$(( score - 20 ))
        findings="${findings}MOBILE_FIRST: デスクトップファーストパターン ${desktop_base_count}件検出。基本スタイルはモバイル、ブレークポイントでスケールアップしてください\n"
    fi

    # Check touch-friendly tap targets (min 44x44px for interactive elements)
    local small_targets=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'w-[1-6]\b|h-[1-6]\b|p-[01]\b|text-\[([0-9]|1[01])px\]' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        small_targets=$(( small_targets + ${count:-0} ))
    done <<< "$all_source"

    # This is a weak heuristic - just flag if very common
    if [[ $small_targets -gt 20 ]]; then
        score=$(( score - 10 ))
        findings="${findings}MOBILE_FIRST: 小さいタップターゲットの可能性 ${small_targets}件。最小44x44pxを確保してください\n"
    fi

    # Check for mobile-specific features
    local mobile_features=0
    while IFS= read -r f; do
        local count
        count=$(grep -cE 'touch-action|overscroll|scroll-snap|-webkit-tap|safe-area|env\(safe-area' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        mobile_features=$(( mobile_features + ${count:-0} ))
    done <<< "$all_source"

    # Hamburger menu / mobile nav
    local has_mobile_nav=0
    while IFS= read -r f; do
        local count
        count=$(grep -ciE 'hamburger|mobile.?menu|mobile.?nav|menu.?toggle|drawer|sidebar.*mobile|sheet' "$f" 2>/dev/null) || true
        count="${count%%[!0-9]*}"
        if [[ ${count:-0} -gt 0 ]]; then
            has_mobile_nav=1
            break
        fi
    done <<< "$all_source"

    if [[ $has_mobile_nav -eq 0 ]]; then
        score=$(( score - 15 ))
        findings="${findings}MOBILE_FIRST: モバイルナビゲーション(ハンバーガーメニュー等)未検出\n"
    fi

    [[ $score -lt 0 ]] && score=0

    _QGW_SCORES+=("mobile_first:${score}")
    [[ -n "$findings" ]] && _QGW_FINDINGS+=("$findings")

    _qgw_log "INFO" "モバイルファーストスコア: ${score}/100"
    echo "$score"
}

# ============================================================
# Main: Run All 10 Checks
# ============================================================
qgw_run_all_checks() {
    local dir="${1:-${PROJECT_DIR:-$(pwd)}}"
    local threshold="${2:-$QGW_DEFAULT_THRESHOLD}"

    _QGW_PROJECT_DIR="$dir"
    _qgw_reset_state

    _qgw_log "INFO" "============================================================"
    _qgw_log "INFO" "Web Creative Quality Gate v${QGW_VERSION} - 10軸品質検証開始"
    _qgw_log "INFO" "Project: ${dir}"
    _qgw_log "INFO" "Threshold: ${threshold}/100"
    _qgw_log "INFO" "============================================================"

    # Run all 10 checks
    local s_brand s_cv s_responsive s_performance s_seo s_a11y s_animation s_cms s_content s_mobile

    s_brand=$(qgw_check_brand_consistency "$dir")
    s_cv=$(qgw_check_cv_optimization "$dir")
    s_responsive=$(qgw_check_responsive "$dir")
    s_performance=$(qgw_check_performance "$dir")
    s_seo=$(qgw_check_seo "$dir")
    s_a11y=$(qgw_check_accessibility "$dir")
    s_animation=$(qgw_check_animation_quality "$dir")
    s_cms=$(qgw_check_cms_operability "$dir")
    s_content=$(qgw_check_content_quality "$dir")
    s_mobile=$(qgw_check_mobile_first "$dir")

    # Calculate weighted average score
    local total_score=0
    total_score=$(( (s_brand * QGW_WEIGHT_BRAND + s_cv * QGW_WEIGHT_CV + s_responsive * QGW_WEIGHT_RESPONSIVE + s_performance * QGW_WEIGHT_PERFORMANCE + s_seo * QGW_WEIGHT_SEO + s_a11y * QGW_WEIGHT_A11Y + s_animation * QGW_WEIGHT_ANIMATION + s_cms * QGW_WEIGHT_CMS + s_content * QGW_WEIGHT_CONTENT + s_mobile * QGW_WEIGHT_MOBILE_FIRST) / 100 ))

    # Output report
    _qgw_log "INFO" "============================================================"
    _qgw_log "INFO" "Web Creative Quality Gate - 結果レポート"
    _qgw_log "INFO" "============================================================"
    _qgw_log "INFO" "  1. ブランド一貫性:     ${s_brand}/100  (weight: ${QGW_WEIGHT_BRAND}%)"
    _qgw_log "INFO" "  2. CV最適化:          ${s_cv}/100  (weight: ${QGW_WEIGHT_CV}%)"
    _qgw_log "INFO" "  3. レスポンシブ設計:   ${s_responsive}/100  (weight: ${QGW_WEIGHT_RESPONSIVE}%)"
    _qgw_log "INFO" "  4. パフォーマンス:     ${s_performance}/100  (weight: ${QGW_WEIGHT_PERFORMANCE}%)"
    _qgw_log "INFO" "  5. SEO対策:           ${s_seo}/100  (weight: ${QGW_WEIGHT_SEO}%)"
    _qgw_log "INFO" "  6. アクセシビリティ:   ${s_a11y}/100  (weight: ${QGW_WEIGHT_A11Y}%)"
    _qgw_log "INFO" "  7. アニメーション品質: ${s_animation}/100  (weight: ${QGW_WEIGHT_ANIMATION}%)"
    _qgw_log "INFO" "  8. CMS運用性:         ${s_cms}/100  (weight: ${QGW_WEIGHT_CMS}%)"
    _qgw_log "INFO" "  9. コンテンツ品質:     ${s_content}/100  (weight: ${QGW_WEIGHT_CONTENT}%)"
    _qgw_log "INFO" " 10. モバイルファースト: ${s_mobile}/100  (weight: ${QGW_WEIGHT_MOBILE_FIRST}%)"
    _qgw_log "INFO" "------------------------------------------------------------"
    _qgw_log "INFO" "  Total Score: ${total_score}/100  (threshold: ${threshold})"
    _qgw_log "INFO" "============================================================"

    # Output findings
    if [[ ${#_QGW_FINDINGS[@]} -gt 0 ]]; then
        _qgw_log "INFO" "検出された問題:"
        for finding in "${_QGW_FINDINGS[@]}"; do
            echo -e "    ${finding}" >&2
        done
    fi

    # PASS/FAIL judgment
    if [[ $total_score -ge $threshold ]]; then
        _qgw_log "INFO" ">>> PASS: Web Creative Quality Gate 合格 (${total_score} >= ${threshold})"
        echo "$total_score"
        return 0
    elif [[ $total_score -ge $QGW_WARN_THRESHOLD ]]; then
        _qgw_log "WARN" ">>> WARNING: Web Creative Quality Gate 警告レベル (${total_score} < ${threshold})"
        echo "$total_score"
        return 1
    else
        _qgw_log "ERROR" ">>> FAIL: Web Creative Quality Gate 不合格 (${total_score} < ${threshold})"
        echo "$total_score"
        return 1
    fi
}

# ============================================================
# JSON report export
# ============================================================
qgw_export_report_json() {
    local output_file="${1:-${SESSION_LOG_DIR:-/tmp}/qgw_report.json}"

    cat > "$output_file" <<EOJSON
{
  "version": "${QGW_VERSION}",
  "timestamp": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')",
  "project": "${_QGW_PROJECT_DIR}",
  "scores": {
$(printf '    "%s": %s,\n' "${_QGW_SCORES[@]}" | sed 's/:\([0-9]*\)/": \1/' | sed '$ s/,$//')
  },
  "findings_count": ${#_QGW_FINDINGS[@]},
  "threshold": ${QGW_DEFAULT_THRESHOLD}
}
EOJSON

    _qgw_log "INFO" "レポートJSON出力: ${output_file}"
}
