#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v392.0 - Code Review AI
# =============================================================================
# AIコードレビューエンジン。コードレビュー/バグ検出/改善提案を自動生成。
# All globals use the CRA_ prefix.
# =============================================================================

[[ -n "${_CODE_REVIEW_AI_LOADED:-}" ]] && return 0
_CODE_REVIEW_AI_LOADED=1

declare -g CRA_VERSION="392.0"
declare -g CRA_INITIALIZED=false
declare -g CRA_REVIEWED_COUNT=0
declare -g CRA_BUGS_DETECTED=0
declare -g CRA_IMPROVEMENTS_SUGGESTED=0
declare -g ENABLE_CRA="${ENABLE_CRA:-true}"

_cra_init() { CRA_INITIALIZED=true; CRA_REVIEWED_COUNT=0; CRA_BUGS_DETECTED=0; CRA_IMPROVEMENTS_SUGGESTED=0; return 0; }

_cra_run_all() {
    local project_dir="${1:-.}"
    [[ "$CRA_INITIALIZED" != "true" ]] && _cra_init
    echo -e "  ${CYAN:-\033[0;36m}[CRA]${NC:-\033[0m} AIコードレビュー開始..." >&2
    _cra_review_code "$project_dir"
    _cra_detect_bugs "$project_dir"
    _cra_suggest_improvements "$project_dir"
    echo -e "  ${GREEN:-\033[0;32m}[CRA]${NC:-\033[0m} コードレビュー完了: ${CRA_REVIEWED_COUNT}件, バグ${CRA_BUGS_DETECTED}件, 改善${CRA_IMPROVEMENTS_SUGGESTED}件" >&2
    return 0
}

_cra_review_code() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [CRA-REVIEW] コードレビューテンプレート

### Review Rules Engine
```typescript
interface ReviewRule {
  id: string;
  name: string;
  severity: 'error' | 'warning' | 'info';
  category: 'security' | 'performance' | 'maintainability' | 'reliability' | 'style';
  check: (code: string, filename: string) => ReviewFinding[];
}

const REVIEW_RULES: ReviewRule[] = [
  { id: 'SEC-001', name: 'ハードコードされたシークレット', severity: 'error', category: 'security',
    check: (code) => {
      const patterns = [/password\s*=\s*['"][^'"]+['"]/gi, /api_key\s*=\s*['"][^'"]+['"]/gi, /secret\s*=\s*['"][^'"]+['"]/gi];
      return patterns.flatMap(p => [...code.matchAll(p)].map(m => ({ line: getLineNumber(code, m.index!), message: `ハードコードされた秘密情報: ${m[0].substring(0, 30)}...` })));
    }
  },
  { id: 'PERF-001', name: 'N+1クエリリスク', severity: 'warning', category: 'performance',
    check: (code) => {
      const findings: ReviewFinding[] = [];
      const forLoopWithQuery = /for\s*\(.*\)\s*\{[^}]*prisma\./g;
      for (const match of code.matchAll(forLoopWithQuery)) {
        findings.push({ line: getLineNumber(code, match.index!), message: 'ループ内でDBクエリが実行される可能性があります（N+1問題）' });
      }
      return findings;
    }
  },
  { id: 'REL-001', name: '未処理のPromise', severity: 'error', category: 'reliability',
    check: (code) => {
      const findings: ReviewFinding[] = [];
      const asyncWithoutAwait = /(?:fetch|prisma\.\w+)\([^)]*\)(?!\s*\.then|\s*\.catch|\s*;?\s*await)/g;
      for (const match of code.matchAll(asyncWithoutAwait)) {
        findings.push({ line: getLineNumber(code, match.index!), message: '非同期呼び出しがawaitされていない可能性があります' });
      }
      return findings;
    }
  },
  { id: 'MAINT-001', name: '関数の複雑度', severity: 'warning', category: 'maintainability',
    check: (code) => {
      const findings: ReviewFinding[] = [];
      const functions = code.match(/(?:function\s+\w+|const\s+\w+\s*=\s*(?:async\s*)?\()/g) ?? [];
      // Simplified cyclomatic complexity check
      const ifCount = (code.match(/\bif\b/g) ?? []).length;
      const switchCount = (code.match(/\bcase\b/g) ?? []).length;
      if (ifCount + switchCount > 15) {
        findings.push({ line: 1, message: `高い循環的複雑度 (条件分岐: ${ifCount + switchCount})。関数の分割を検討してください` });
      }
      return findings;
    }
  },
];

export class CodeReviewer {
  review(code: string, filename: string): ReviewResult {
    const findings: ReviewFinding[] = [];
    for (const rule of REVIEW_RULES) {
      const ruleFindings = rule.check(code, filename);
      findings.push(...ruleFindings.map(f => ({ ...f, ruleId: rule.id, ruleName: rule.name, severity: rule.severity, category: rule.category })));
    }
    return { filename, findings, score: this.calculateScore(findings), reviewedAt: new Date() };
  }

  private calculateScore(findings: ReviewFinding[]): number {
    let score = 100;
    for (const f of findings) {
      if (f.severity === 'error') score -= 15;
      else if (f.severity === 'warning') score -= 5;
      else score -= 1;
    }
    return Math.max(0, score);
  }
}
```
TEMPLATE
    CRA_REVIEWED_COUNT=$((CRA_REVIEWED_COUNT + 1))
    return 0
}

_cra_detect_bugs() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [CRA-BUGS] バグ検出テンプレート

```typescript
const BUG_PATTERNS = [
  { pattern: /===\s*undefined\s*\|\|\s*===\s*null/g, message: '== null で十分です（undefinedとnullの両方をカバー）', fix: '== null' },
  { pattern: /\.forEach\(\s*async/g, message: 'forEach内のasyncは並列実行されません。for...ofまたはPromise.allを使用してください', severity: 'error' },
  { pattern: /JSON\.parse\([^)]+\)(?!\s*(?:catch|try))/g, message: 'JSON.parseはtry-catchで囲んでください', severity: 'warning' },
  { pattern: /new Date\(\s*\)\.toISOString\(\)/g, message: 'タイムゾーンに注意。サーバー時刻がUTCか確認してください', severity: 'info' },
  { pattern: /parseInt\([^,)]+\)(?!\s*,\s*10)/g, message: 'parseInt()にはradixパラメータ(10)を指定してください', severity: 'warning' },
];

export function detectBugs(code: string): BugDetection[] {
  const bugs: BugDetection[] = [];
  for (const pattern of BUG_PATTERNS) {
    for (const match of code.matchAll(pattern.pattern)) {
      bugs.push({ line: getLineNumber(code, match.index!), pattern: pattern.message, severity: pattern.severity ?? 'warning', fix: pattern.fix });
    }
  }
  return bugs;
}
```
TEMPLATE
    CRA_BUGS_DETECTED=$((CRA_BUGS_DETECTED + 1))
    return 0
}

_cra_suggest_improvements() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [CRA-IMPROVE] 改善提案テンプレート

```typescript
export function suggestImprovements(code: string, filename: string): Improvement[] {
  const improvements: Improvement[] = [];

  // Type safety
  if (code.includes(': any') && filename.endsWith('.ts')) {
    improvements.push({ category: 'type_safety', message: 'any型の使用を検出。具体的な型定義に置き換えてください', priority: 'high' });
  }

  // Error handling
  if (code.includes('fetch(') && !code.includes('try')) {
    improvements.push({ category: 'error_handling', message: 'fetch呼び出しにエラーハンドリングを追加してください', priority: 'high' });
  }

  // Performance
  if (code.includes('useEffect') && !code.includes('useMemo') && code.match(/\.map\(/g)?.length > 2) {
    improvements.push({ category: 'performance', message: '重い計算をuseMemoでメモ化することを検討してください', priority: 'medium' });
  }

  // Accessibility
  if (code.includes('<img') && !code.includes('alt=')) {
    improvements.push({ category: 'accessibility', message: 'img要素にalt属性を追加してください', priority: 'high' });
  }

  return improvements;
}
```
TEMPLATE
    CRA_IMPROVEMENTS_SUGGESTED=$((CRA_IMPROVEMENTS_SUGGESTED + 1))
    return 0
}

_cra_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Code Review AI v${CRA_VERSION} ===${NC:-\033[0m}"
    echo -e "  レビュー数         : ${CRA_REVIEWED_COUNT}"
    echo -e "  バグ検出           : ${CRA_BUGS_DETECTED}"
    echo -e "  改善提案           : ${CRA_IMPROVEMENTS_SUGGESTED}"
}

_cra_score() {
    local score=30
    [[ "$CRA_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ $CRA_REVIEWED_COUNT -gt 0 ]] && score=$((score + 20))
    [[ $CRA_BUGS_DETECTED -gt 0 ]] && score=$((score + 20))
    [[ $CRA_IMPROVEMENTS_SUGGESTED -gt 0 ]] && score=$((score + 20))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "code-review-ai" \
    --version "392.0" \
    --description "AIコードレビュー（レビュー/バグ検出/改善提案）" \
    --init "_cra_init" \
    --report "_cra_report" \
    --score "_cra_score" \
    --enable-var "ENABLE_CRA" \
    --cli-flags "--code-review:--no-code-review"
