#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v360.0 - Dependency Updater
# =============================================================================
# 依存関係の最新化チェック×更新生成×テスト実行
#
# 機能:
#   - 古い依存関係の検出（npm outdated）
#   - セキュリティ脆弱性チェック（npm audit）
#   - 更新PR自動生成（major/minor/patch分離）
#   - 更新後テスト実行・検証
#   - 更新レポート生成
#
# 全globals: DU_ prefix
# =============================================================================

[[ -n "${_DU_LOADED:-}" ]] && return 0; _DU_LOADED=1

DU_VERSION="360.0"
DU_GENERATED=0
DU_ERRORS=0
DU_PHASE="dependency_update"
DU_FILES_CREATED=()
DU_UPDATES_FOUND=0

: "${GREEN:=\033[0;32m}" ; : "${RED:=\033[0;31m}" ; : "${YELLOW:=\033[0;33m}"
: "${CYAN:=\033[0;36m}" ; : "${BOLD:=\033[1m}" ; : "${NC:=\033[0m}"

_du_log() { echo -e "  ${CYAN}[DU]${NC} $*"; }
_du_ok() { echo -e "  ${GREEN}[DU]${NC} $*"; }
_du_warn() { echo -e "  ${YELLOW}[DU]${NC} $*"; }
_du_err() { echo -e "  ${RED}[DU]${NC} $*"; }

_du_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        DU_FILES_CREATED+=("$filepath")
        DU_GENERATED=$((DU_GENERATED + 1))
        _du_ok "Created: ${filepath##*/}"
    else
        DU_ERRORS=$((DU_ERRORS + 1))
        _du_err "Failed: ${filepath##*/}"
    fi
}

du_init() {
    DU_GENERATED=0; DU_ERRORS=0; DU_UPDATES_FOUND=0; DU_FILES_CREATED=()
    _du_log "Dependency Updater v${DU_VERSION} initialized"
    return 0
}

# =============================================================================
# Check Outdated
# =============================================================================
_du_check_outdated() {
    local project_dir="${1:-.}"

    _du_log "Generating dependency checker..."

    local dep_dir="${project_dir}/src/lib/dependency-management"
    mkdir -p "$dep_dir" 2>/dev/null

    _du_write_file "${dep_dir}/checker.ts" "$(cat <<'TS'
import { execSync } from 'child_process';

interface OutdatedPackage {
  name: string;
  current: string;
  wanted: string;
  latest: string;
  type: 'dependencies' | 'devDependencies';
  updateType: 'major' | 'minor' | 'patch';
  hasVulnerability: boolean;
  vulnerabilitySeverity?: 'critical' | 'high' | 'moderate' | 'low';
}

interface CheckResult {
  outdated: OutdatedPackage[];
  totalDeps: number;
  upToDate: number;
  patchUpdates: number;
  minorUpdates: number;
  majorUpdates: number;
  vulnerabilities: number;
}

function classifyUpdate(current: string, latest: string): 'major' | 'minor' | 'patch' {
  const [cMaj, cMin] = current.replace(/[^0-9.]/g, '').split('.').map(Number);
  const [lMaj, lMin] = latest.replace(/[^0-9.]/g, '').split('.').map(Number);
  if (lMaj > cMaj) return 'major';
  if (lMin > cMin) return 'minor';
  return 'patch';
}

export async function checkOutdated(cwd: string): Promise<CheckResult> {
  let outdatedJson: Record<string, any> = {};
  try {
    const output = execSync('npm outdated --json', { cwd, encoding: 'utf-8', stdio: 'pipe' });
    outdatedJson = JSON.parse(output || '{}');
  } catch (e: any) {
    if (e.stdout) outdatedJson = JSON.parse(e.stdout || '{}');
  }

  let auditJson: Record<string, any> = {};
  try {
    const output = execSync('npm audit --json', { cwd, encoding: 'utf-8', stdio: 'pipe' });
    auditJson = JSON.parse(output || '{}');
  } catch (e: any) {
    if (e.stdout) auditJson = JSON.parse(e.stdout || '{}');
  }

  const vulnPackages = new Set<string>();
  for (const [name, advisory] of Object.entries(auditJson.vulnerabilities || {})) {
    vulnPackages.add(name);
  }

  const outdated: OutdatedPackage[] = Object.entries(outdatedJson).map(([name, info]: [string, any]) => ({
    name,
    current: info.current || '0.0.0',
    wanted: info.wanted || info.current,
    latest: info.latest || info.current,
    type: info.type === 'devDependencies' ? 'devDependencies' : 'dependencies',
    updateType: classifyUpdate(info.current || '0', info.latest || '0'),
    hasVulnerability: vulnPackages.has(name),
  }));

  return {
    outdated,
    totalDeps: outdated.length,
    upToDate: 0,
    patchUpdates: outdated.filter(p => p.updateType === 'patch').length,
    minorUpdates: outdated.filter(p => p.updateType === 'minor').length,
    majorUpdates: outdated.filter(p => p.updateType === 'major').length,
    vulnerabilities: outdated.filter(p => p.hasVulnerability).length,
  };
}
TS
)"

    _du_ok "Dependency checker generated"
}

# =============================================================================
# Generate Updates
# =============================================================================
_du_generate_updates() {
    local project_dir="${1:-.}"

    _du_log "Generating dependency update automation..."

    local ci_dir="${project_dir}/.github/workflows"
    mkdir -p "$ci_dir" 2>/dev/null

    _du_write_file "${ci_dir}/dependency-update.yml" "$(cat <<'YAML'
name: Dependency Update
on:
  schedule:
    - cron: '0 9 * * 1'
  workflow_dispatch:

permissions:
  contents: write
  pull-requests: write

jobs:
  update-deps:
    runs-on: ubuntu-latest
    strategy:
      matrix:
        update-type: [patch, minor]
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-node@v4
        with:
          node-version: '20'
          cache: 'npm'

      - run: npm ci

      - name: Check for updates
        id: check
        run: |
          if [ "${{ matrix.update-type }}" = "patch" ]; then
            npx npm-check-updates -u --target patch
          else
            npx npm-check-updates -u --target minor
          fi
          if git diff --quiet package.json; then
            echo "has_updates=false" >> "$GITHUB_OUTPUT"
          else
            echo "has_updates=true" >> "$GITHUB_OUTPUT"
          fi

      - name: Install & Test
        if: steps.check.outputs.has_updates == 'true'
        run: |
          npm install
          npm test
          npm run build

      - name: Create PR
        if: steps.check.outputs.has_updates == 'true'
        uses: peter-evans/create-pull-request@v6
        with:
          branch: deps/${{ matrix.update-type }}-updates
          title: "deps: ${{ matrix.update-type }} dependency updates"
          body: |
            Automated ${{ matrix.update-type }} dependency updates.
            All tests passed.
          commit-message: "deps: ${{ matrix.update-type }} dependency updates"
YAML
)"

    _du_ok "Dependency update automation generated"
}

# =============================================================================
# Test Updates
# =============================================================================
_du_test_updates() {
    local project_dir="${1:-.}"

    _du_log "Generating update test runner..."

    local dep_dir="${project_dir}/src/lib/dependency-management"
    mkdir -p "$dep_dir" 2>/dev/null

    _du_write_file "${dep_dir}/test-runner.ts" "$(cat <<'TS'
import { execSync } from 'child_process';

interface TestResult {
  step: string;
  passed: boolean;
  output: string;
  duration: number;
}

export async function testUpdates(cwd: string): Promise<{ success: boolean; results: TestResult[] }> {
  const results: TestResult[] = [];
  const steps = [
    { name: 'npm install', cmd: 'npm install' },
    { name: 'TypeScript check', cmd: 'npx tsc --noEmit' },
    { name: 'Lint', cmd: 'npm run lint --if-present' },
    { name: 'Unit tests', cmd: 'npm test -- --passWithNoTests' },
    { name: 'Build', cmd: 'npm run build' },
  ];

  for (const step of steps) {
    const start = Date.now();
    try {
      const output = execSync(step.cmd, { cwd, encoding: 'utf-8', stdio: 'pipe', timeout: 300000 });
      results.push({ step: step.name, passed: true, output: output.slice(-500), duration: Date.now() - start });
    } catch (e: any) {
      results.push({ step: step.name, passed: false, output: (e.stderr || e.message || '').slice(-500), duration: Date.now() - start });
      break;
    }
  }

  return { success: results.every(r => r.passed), results };
}
TS
)"

    _du_ok "Update test runner generated"
}

# =============================================================================
# Report / Score / Register
# =============================================================================
du_report() {
    echo -e "\n  ${BOLD}=== Dependency Updater v${DU_VERSION} ===${NC}"
    echo -e "  生成ファイル数 : ${DU_GENERATED}"
    echo -e "  エラー         : ${DU_ERRORS}"
    echo -e "  更新検出数     : ${DU_UPDATES_FOUND}"
    if [[ ${#DU_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${DU_FILES_CREATED[@]}"; do echo -e "    - ${f}"; done
    fi
}

du_score() {
    if [[ ${DU_GENERATED} -ge 3 ]] && [[ ${DU_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${DU_GENERATED} -gt 0 ]] && [[ ${DU_ERRORS} -eq 0 ]]; then echo "90"
    elif [[ ${DU_GENERATED} -gt 0 ]]; then echo "70"
    else echo "50"; fi
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "dependency-updater" --version "360.0" \
        --description "依存関係チェック×更新自動化×テスト検証" \
        --init "du_init" --report "du_report" --score "du_score" \
        --enable-var "ENABLE_DEPENDENCY_UPDATER" --cli-flags "--dependency-updater:--no-dependency-updater"
fi

# v2003.1: source時のexit codeを確実に0にする
true
