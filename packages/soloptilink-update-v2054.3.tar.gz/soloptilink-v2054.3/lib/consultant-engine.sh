#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v28.0 - Consultant Engine
# =============================================================================
# Phase 0.1: コンサルタント型対話エンジン
#
# 「言われた通りに作る」のではなく、プロのITコンサルタントとして：
# 1. Web検索で類似サービス・最新トレンド・業界標準を実調査
# 2. ユーザーの「本当の目的」を対話で深掘り
# 3. 調査結果に基づく具体的な提案・アドバイスを提示
# 4. ユーザー承認を得てから開発に進む
#
# 既存の prompt-expander.sh (Phase 0) の「前」に実行され、
# 対話結果が後続全フェーズに注入される。
# =============================================================================
# sourceされるライブラリなので set -euo pipefail は設定しない

# ============================================================
# カラー定義
# ============================================================
CE_GREEN='\033[0;32m'
CE_YELLOW='\033[0;33m'
CE_RED='\033[0;31m'
CE_BLUE='\033[0;34m'
CE_PURPLE='\033[0;35m'
CE_CYAN='\033[0;36m'
CE_BOLD='\033[1m'
CE_DIM='\033[2m'
CE_NC='\033[0m'

# 設定
CE_WORK_DIR="${HOME}/.soloptilink/consultant"
CE_CLAUDE_TIMEOUT=300
CE_MAX_RETRIES=3
CE_WEB_SEARCH_TIMEOUT=30

# グローバル変数: 対話結果を保持
declare -g CE_CONSULTATION_RESULT=""
declare -g CE_WEB_RESEARCH=""
declare -g CE_USER_APPROVED=""
declare -g CE_CONSULTATION_FILE=""
declare -g CE_SKIP_CONSULTATION="${CE_SKIP_CONSULTATION:-0}"

# ============================================================
# 初期化
# ============================================================
consultant_engine_init() {
    mkdir -p "${CE_WORK_DIR}" 2>/dev/null || true
    _ce_log "INFO" "Consultant Engine v28.0 初期化完了"
}

# ============================================================
# ログ出力
# ============================================================
_ce_log() {
    local level="$1" message="$2"
    local color="${CE_NC}"
    case "$level" in
        INFO)    color="${CE_CYAN}"   ;;
        SUCCESS) color="${CE_GREEN}"  ;;
        WARN)    color="${CE_YELLOW}" ;;
        ERROR)   color="${CE_RED}"    ;;
        STEP)    color="${CE_PURPLE}" ;;
        CONSULT) color="${CE_BLUE}"   ;;
    esac
    echo -e "  ${color}[CE:${level}]${CE_NC} ${message}"
}

# ============================================================
# Claude CLI呼び出しラッパー
# ============================================================
_ce_call_claude() {
    local prompt="$1"
    local output_file="${2:-}"
    local retry=0
    local result=""

    while [[ "$retry" -lt "$CE_MAX_RETRIES" ]]; do
        retry=$((retry + 1))
        local _ce_claude_cmd
        if command -v timeout &>/dev/null; then
            _ce_claude_cmd="timeout ${CE_CLAUDE_TIMEOUT} claude"
        else
            _ce_claude_cmd="claude"
        fi
        result=$(${_ce_claude_cmd} -p --dangerously-skip-permissions \
            --output-format text "$prompt" 2>/dev/null || echo "")

        if [[ -n "$result" ]]; then
            if [[ -n "$output_file" ]]; then
                mkdir -p "$(dirname "$output_file")" 2>/dev/null || true
                printf '%s\n' "$result" > "$output_file"
            fi
            echo "$result"
            return 0
        fi
        _ce_log "WARN" "Claude CLI応答なし (試行 ${retry}/${CE_MAX_RETRIES})"
        sleep $((retry * 2))
    done

    _ce_log "ERROR" "Claude CLI: 全リトライ失敗"
    return 1
}

# ============================================================
# Web検索実行
# ============================================================
# claude CLIのWeb検索能力を活用して実際のWeb情報を取得
_ce_web_research() {
    local task_desc="$1"
    local domain="$2"
    local output_file="$3"

    _ce_log "STEP" "Web調査を実行中... (類似サービス・最新トレンド・業界標準)"

    local prompt="あなたはITコンサルタントです。Webで最新の情報を検索して調査してください。

## 調査対象
ユーザーの依頼: 「${task_desc}」
推定ドメイン: ${domain}

## 調査項目（実際のWebの情報をもとに回答すること）

### 1. 類似サービス・競合調査（5-8個）
Web検索で実際に今使われているサービスを調べてください。各サービスについて：
- **サービス名** と **URL**
- **特徴的な機能**（3-5個）
- **無料/有料プラン**の概要
- **ユーザー評価・レビュー**の概要（分かる範囲で）
- **主なターゲットユーザー**

### 2. 業界の最新トレンド（2026年時点）
このドメインで今注目されている技術・アプローチ・デザインパターンを3-5個挙げてください。

### 3. ユーザーが「当たり前」だと思っている機能（期待値）
この種のシステムを使うユーザーが「これは絶対あるだろう」と思っている基本機能を10個。

### 4. 差別化できるポイント
既存サービスの弱点や、追加すると喜ばれる機能を5個。

### 5. 失敗しやすいポイント
この種のシステム開発で、よくある失敗パターンや落とし穴を3-5個。

各項目は必ず実際のWebの情報や事例に基づいて回答してください。
推測だけでなく、具体的なサービス名・数字・事実を含めてください。"

    local result
    result=$(_ce_call_claude "$prompt" "$output_file" 2>/dev/null || echo "")

    if [[ -n "$result" ]]; then
        CE_WEB_RESEARCH="$result"
        _ce_log "SUCCESS" "Web調査完了"
        return 0
    else
        _ce_log "WARN" "Web調査失敗（内部知識で続行）"
        CE_WEB_RESEARCH=""
        return 0
    fi
}

# ============================================================
# ドメイン簡易判定（prompt-expander.shと同様だが独立で動作可能に）
# ============================================================
_ce_detect_domain() {
    local task_desc="$1"
    local task_lower
    task_lower=$(echo "$task_desc" | tr '[:upper:]' '[:lower:]')

    if [[ "$task_lower" =~ (家計簿|会計|支出|収入|経費|finance|accounting|budget|expense|income|ledger) ]]; then
        echo "finance"; return 0
    fi
    if [[ "$task_lower" =~ (crm|顧客管理|顧客|営業管理|営業|商談|リード|customer|sales|lead) ]]; then
        echo "crm"; return 0
    fi
    if [[ "$task_lower" =~ (チャット|メッセージ|dm|chat|messenger|messaging|リアルタイム通信) ]]; then
        echo "chat"; return 0
    fi
    if [[ "$task_lower" =~ (ec|ecommerce|ショップ|通販|商品|カート|決済|shop|store|cart|payment) ]]; then
        echo "ecommerce"; return 0
    fi
    if [[ "$task_lower" =~ (タスク|todo|プロジェクト管理|進捗|カンバン|task|kanban|project.management|issue.tracker) ]]; then
        echo "task-management"; return 0
    fi
    if [[ "$task_lower" =~ (sns|ソーシャル|投稿|フォロー|タイムライン|social|feed|timeline|follow|post) ]]; then
        echo "social"; return 0
    fi
    if [[ "$task_lower" =~ (ブログ|記事|コンテンツ|cms|blog|article|content|publish|editor) ]]; then
        echo "content"; return 0
    fi
    if [[ "$task_lower" =~ (ダッシュボード|分析|レポート|analytics|dashboard|report|metrics|bi|visualization) ]]; then
        echo "analytics"; return 0
    fi
    if [[ "$task_lower" =~ (lp|ランディング|landing.page|ランディングページ|集客|サービス紹介) ]]; then
        echo "landing-page"; return 0
    fi
    if [[ "$task_lower" =~ (予約|booking|reservation|スケジュール|カレンダー|calendar|appointment) ]]; then
        echo "booking"; return 0
    fi
    if [[ "$task_lower" =~ (在庫|inventory|倉庫|warehouse|物流|logistics|stock) ]]; then
        echo "inventory"; return 0
    fi
    if [[ "$task_lower" =~ (人事|hr|勤怠|給与|従業員|employee|attendance|payroll) ]]; then
        echo "hr"; return 0
    fi
    if [[ "$task_lower" =~ (学習|lms|コース|レッスン|教育|learning|course|lesson|education) ]]; then
        echo "lms"; return 0
    fi

    echo "general"
    return 0
}

# ============================================================
# 目的深掘り質問の生成（対話型）
# ============================================================
_ce_generate_purpose_questions() {
    local task_desc="$1"
    local domain="$2"
    local web_research="$3"
    local output_file="$4"

    _ce_log "STEP" "コンサルタント視点で深掘り質問を生成中..."

    # Web調査結果がある場合は注入
    local web_context=""
    if [[ -n "$web_research" ]]; then
        # 長すぎる場合は先頭を切り詰め
        if [[ ${#web_research} -gt 6000 ]]; then
            web_context="${web_research:0:6000}
...(調査結果は続きがありますが省略)"
        else
            web_context="$web_research"
        fi
    fi

    local prompt="あなたはシステム開発のITコンサルタントです。
顧客から「${task_desc}」というシステムの開発を依頼されました。

${web_context:+## Web調査結果（類似サービス・最新トレンド）
${web_context}
}

## あなたの役割
顧客の依頼をそのまま受けるのではなく、プロのコンサルタントとして：
- 顧客が**本当に達成したい目的**を明確にする
- 調査した類似サービスの知見を活かして**より良い提案**をする
- 顧客が**気づいていないかもしれない課題やチャンス**を指摘する

## 出力フォーマット（必ずこの形式で出力）

### 📋 プロジェクト概要理解
依頼内容「${task_desc}」から読み取れる要求の整理（2-3行）

### ❓ 確認したいこと（3-5個）
顧客に確認すべき重要な質問。各質問には：
- **質問の意図**（なぜこれを聞くのか）
- **選択肢や例**（答えやすくするため）
を含めてください。

質問は以下の観点を必ずカバーすること：
1. **利用目的・ゴール**: 「なぜこのシステムが必要なのか？」「現状の何に困っているのか？」
2. **ユーザー像**: 「誰が使うのか？ITリテラシーは？」「何人くらいで使うのか？」
3. **優先度**: 「最も重視するのは？（使いやすさ/機能数/スピード/コスト）」

### 💡 コンサルタントからの提案（3-5個）
Web調査や業界知見に基づく、顧客への具体的な提案。各提案には：
- **提案内容**
- **その理由**（なぜそうすべきか、類似サービスではどうしているか）
- **実装した場合のメリット**
を含めてください。

例えば：
- 「○○のような機能を入れると、ユーザーの利便性が大幅に上がります。類似サービスの△△でも採用されています」
- 「□□の機能は一見良さそうですが、開発コストに対して使われない傾向があります。代わりに◇◇がおすすめです」
- 「このドメインでは◎◎が業界標準になっています。入れておかないとユーザーが違和感を感じます」

### ⚠️ 注意すべきポイント（2-3個）
この種のシステム開発で陥りがちな失敗や、事前に考慮すべきリスク。

必ず具体的かつ実用的な内容にしてください。抽象的な一般論は不要です。"

    local result
    result=$(_ce_call_claude "$prompt" "$output_file" 2>/dev/null || echo "")

    if [[ -n "$result" ]]; then
        _ce_log "SUCCESS" "コンサルタント提案生成完了"
        echo "$result"
        return 0
    else
        _ce_log "WARN" "提案生成失敗"
        return 1
    fi
}

# ============================================================
# ユーザーとの対話を実施（ターミナル対話）
# ============================================================
_ce_interactive_consultation() {
    local task_desc="$1"
    local consultation_content="$2"
    local output_file="$3"

    echo ""
    echo -e "${CE_BOLD}${CE_PURPLE}╔═══════════════════════════════════════════════════════════╗${CE_NC}"
    echo -e "${CE_BOLD}${CE_PURPLE}║   🧑‍💼 Consultant Engine - コンサルタント提案               ║${CE_NC}"
    echo -e "${CE_BOLD}${CE_PURPLE}╠═══════════════════════════════════════════════════════════╣${CE_NC}"
    echo -e "${CE_BOLD}${CE_PURPLE}║   依頼: ${task_desc:0:47}${CE_NC}"
    echo -e "${CE_BOLD}${CE_PURPLE}╚═══════════════════════════════════════════════════════════╝${CE_NC}"
    echo ""

    # 提案内容を表示
    echo -e "${CE_BOLD}${CE_BLUE}━━━ コンサルタント分析レポート ━━━${CE_NC}"
    echo ""
    echo "$consultation_content"
    echo ""
    echo -e "${CE_BOLD}${CE_BLUE}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${CE_NC}"
    echo ""

    # ユーザーに確認
    echo -e "${CE_BOLD}${CE_CYAN}上記の提案・質問について、ご意見をお聞かせください。${CE_NC}"
    echo -e "${CE_DIM}（入力方法）${CE_NC}"
    echo -e "  ${CE_GREEN}y${CE_NC} / ${CE_GREEN}yes${CE_NC}  → この内容で開発を進める"
    echo -e "  ${CE_CYAN}テキスト入力${CE_NC} → 質問への回答・追加要件・修正要望を入力"
    echo -e "  ${CE_YELLOW}s${CE_NC} / ${CE_YELLOW}skip${CE_NC} → コンサルをスキップして開発に進む"
    echo ""
    echo -ne "${CE_BOLD}> ${CE_NC}"

    local user_response=""
    # ターミナルから直接読み取り（パイプ入力のchain.shでもSTDINを使える）
    if [[ -t 0 ]]; then
        # 対話的ターミナル
        read -r user_response
    else
        # パイプ入力の場合は /dev/tty から読み取り試行
        if [[ -e /dev/tty ]]; then
            read -r user_response < /dev/tty
        else
            # 対話不可: 自動承認
            _ce_log "INFO" "対話不可（非TTY環境） → 提案内容で自動続行"
            user_response="y"
        fi
    fi

    # 応答を保存
    local response_lower
    response_lower=$(echo "$user_response" | tr '[:upper:]' '[:lower:]' | tr -d '[:space:]')

    case "$response_lower" in
        y|yes|はい|ok|進めて)
            CE_USER_APPROVED="approved"
            _ce_log "SUCCESS" "ユーザー承認: 提案内容で開発を進めます"

            # 承認された内容を保存
            {
                echo "# コンサルテーション結果"
                echo ""
                echo "## ステータス: 承認済み"
                echo "## 依頼: ${task_desc}"
                echo "## 日時: $(date '+%Y-%m-%d %H:%M:%S')"
                echo ""
                echo "---"
                echo ""
                echo "$consultation_content"
            } > "$output_file"
            ;;
        s|skip|スキップ)
            CE_USER_APPROVED="skipped"
            _ce_log "INFO" "ユーザー判断: コンサルスキップ"
            ;;
        *)
            CE_USER_APPROVED="feedback_provided"
            _ce_log "CONSULT" "ユーザーからフィードバック受領 → 反映中..."

            # ユーザーのフィードバックを踏まえた再分析
            local refined_result
            refined_result=$(_ce_refine_with_feedback "$task_desc" "$consultation_content" "$user_response" 2>/dev/null || echo "")

            if [[ -n "$refined_result" ]]; then
                # 再分析結果を保存
                {
                    echo "# コンサルテーション結果（フィードバック反映済み）"
                    echo ""
                    echo "## ステータス: フィードバック反映"
                    echo "## 依頼: ${task_desc}"
                    echo "## ユーザーフィードバック:"
                    echo "$user_response"
                    echo ""
                    echo "## 日時: $(date '+%Y-%m-%d %H:%M:%S')"
                    echo ""
                    echo "---"
                    echo ""
                    echo "## 最初の提案:"
                    echo "$consultation_content"
                    echo ""
                    echo "---"
                    echo ""
                    echo "## フィードバック反映後の最終方針:"
                    echo "$refined_result"
                } > "$output_file"

                # 反映後の内容を表示
                echo ""
                echo -e "${CE_BOLD}${CE_GREEN}━━━ フィードバック反映後の方針 ━━━${CE_NC}"
                echo ""
                echo "$refined_result"
                echo ""
                echo -e "${CE_BOLD}${CE_GREEN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${CE_NC}"
                echo ""
                echo -e "${CE_BOLD}${CE_CYAN}この方針で開発を進めます。${CE_NC}"
            else
                # 再分析失敗時はオリジナル+フィードバックで保存
                {
                    echo "# コンサルテーション結果"
                    echo ""
                    echo "## ステータス: フィードバック付き承認"
                    echo "## 依頼: ${task_desc}"
                    echo "## ユーザーフィードバック:"
                    echo "$user_response"
                    echo ""
                    echo "---"
                    echo ""
                    echo "$consultation_content"
                } > "$output_file"
            fi
            ;;
    esac

    return 0
}

# ============================================================
# フィードバック反映: ユーザーの回答を踏まえた再分析
# ============================================================
_ce_refine_with_feedback() {
    local task_desc="$1"
    local original_consultation="$2"
    local user_feedback="$3"

    local prompt="あなたはITコンサルタントです。

## 元の依頼
「${task_desc}」

## あなたの最初の提案
${original_consultation:0:4000}

## 顧客からのフィードバック
${user_feedback}

## 指示
顧客のフィードバックを踏まえて、開発方針を確定してください。

以下のフォーマットで出力：

### 🎯 確定した開発方針
顧客のフィードバックを反映した、最終的な開発方針（3-5行）

### 📝 確定要件（Must）
絶対に実装する機能のリスト（番号付き、5-10個）

### 📝 推奨要件（Should）
できれば実装する機能のリスト（番号付き、3-5個）

### 📝 将来検討（Could）
今回は見送るが、将来的に追加を検討する機能（2-3個）

### 🏗️ 推奨アーキテクチャ
- フロントエンド:
- バックエンド:
- データベース:
- 認証:
- 特記事項:

### ⚡ 開発で特に注意すること
顧客のフィードバックから読み取れる重要なポイント（2-3個）"

    _ce_call_claude "$prompt" ""
}

# ============================================================
# メイン関数: consultant_run(task_desc, output_dir)
# ============================================================
# 返り値: consultation_result.md のパス
consultant_run() {
    local task_desc="${1:-}"
    local output_dir="${2:-}"

    if [[ -z "$task_desc" ]]; then
        _ce_log "ERROR" "タスク説明が空です"
        return 1
    fi

    # スキップモード
    if [[ "${CE_SKIP_CONSULTATION:-0}" == "1" ]]; then
        _ce_log "INFO" "コンサルテーション: スキップ (CE_SKIP_CONSULTATION=1)"
        CE_CONSULTATION_RESULT=""
        CE_USER_APPROVED="skipped"
        return 0
    fi

    # 出力ディレクトリ
    if [[ -z "$output_dir" ]]; then
        output_dir="${CE_WORK_DIR}/session_$(date +%Y%m%d_%H%M%S)_$$"
    fi
    mkdir -p "$output_dir" 2>/dev/null || true

    echo ""
    echo -e "${CE_BOLD}${CE_PURPLE}╔═══════════════════════════════════════════════════════════╗${CE_NC}"
    echo -e "${CE_BOLD}${CE_PURPLE}║   🧑‍💼 Consultant Engine v28.0                            ║${CE_NC}"
    echo -e "${CE_BOLD}${CE_PURPLE}║   Web調査 × 目的深掘り × プロ提案 × 対話承認             ║${CE_NC}"
    echo -e "${CE_BOLD}${CE_PURPLE}╚═══════════════════════════════════════════════════════════╝${CE_NC}"
    echo -e "  依頼: ${CE_CYAN}${task_desc}${CE_NC}"
    echo ""

    local start_time
    start_time=$(date +%s)

    # ── Step 1: ドメイン簡易判定 ──────────────────────────
    _ce_log "STEP" "[1/4] ドメイン判定中..."
    local domain
    domain=$(_ce_detect_domain "$task_desc")
    _ce_log "SUCCESS" "ドメイン: ${domain}"

    # ── Step 2: Web調査（類似サービス・トレンド） ─────────
    _ce_log "STEP" "[2/4] Web調査中（類似サービス・最新トレンド）..."
    local web_research_file="${output_dir}/web_research.md"
    _ce_web_research "$task_desc" "$domain" "$web_research_file"

    # ── Step 3: コンサルタント提案生成 ────────────────────
    _ce_log "STEP" "[3/4] コンサルタント分析・提案を生成中..."
    local consultation_file="${output_dir}/consultation_proposal.md"
    local consultation_content
    consultation_content=$(_ce_generate_purpose_questions "$task_desc" "$domain" "${CE_WEB_RESEARCH:-}" "$consultation_file" 2>/dev/null || echo "")

    if [[ -z "$consultation_content" ]]; then
        _ce_log "WARN" "提案生成失敗 → コンサルテーションをスキップして続行"
        CE_CONSULTATION_RESULT=""
        CE_USER_APPROVED="skipped"
        return 0
    fi

    # ── Step 4: ユーザーとの対話 ──────────────────────────
    _ce_log "STEP" "[4/4] コンサルタント提案をユーザーに提示..."
    local result_file="${output_dir}/consultation_result.md"
    _ce_interactive_consultation "$task_desc" "$consultation_content" "$result_file"

    # ── 結果をグローバル変数に格納 ────────────────────────
    if [[ -f "$result_file" ]]; then
        CE_CONSULTATION_RESULT=$(cat "$result_file" 2>/dev/null || echo "")
        CE_CONSULTATION_FILE="$result_file"
    else
        CE_CONSULTATION_RESULT="$consultation_content"
        CE_CONSULTATION_FILE="$consultation_file"
    fi

    # ── 完了サマリー ──────────────────────────────────────
    local end_time elapsed_sec
    end_time=$(date +%s)
    elapsed_sec=$((end_time - start_time))

    echo ""
    echo -e "${CE_BOLD}${CE_GREEN}╔═══════════════════════════════════════════════════════════╗${CE_NC}"
    echo -e "${CE_BOLD}${CE_GREEN}║   Consultation 完了                                       ║${CE_NC}"
    echo -e "${CE_BOLD}${CE_GREEN}╠═══════════════════════════════════════════════════════════╣${CE_NC}"
    echo -e "  ドメイン      : ${CE_CYAN}${domain}${CE_NC}"
    echo -e "  承認状態      : ${CE_CYAN}${CE_USER_APPROVED}${CE_NC}"
    echo -e "  所要時間      : ${elapsed_sec}秒"
    echo -e "  生成ファイル  :"
    [[ -f "${web_research_file}" ]] && echo -e "    ${CE_BLUE}1.${CE_NC} web_research.md          (Web調査結果)"
    [[ -f "${consultation_file}" ]] && echo -e "    ${CE_BLUE}2.${CE_NC} consultation_proposal.md  (提案内容)"
    [[ -f "${result_file}" ]] && echo -e "    ${CE_BLUE}3.${CE_NC} consultation_result.md    (対話結果)"
    echo -e "${CE_BOLD}${CE_GREEN}╚═══════════════════════════════════════════════════════════╝${CE_NC}"
    echo ""

    return 0
}

# ============================================================
# ヘルパー: コンサル結果をプロンプトに注入する文字列を返す
# ============================================================
ce_get_consultation_context() {
    if [[ -z "${CE_CONSULTATION_RESULT:-}" ]]; then
        echo ""
        return 0
    fi

    # 長すぎる場合は先頭部分のみ
    local context="${CE_CONSULTATION_RESULT}"
    if [[ ${#context} -gt 8000 ]]; then
        context="${context:0:8000}
...(以下省略)"
    fi

    cat <<CONSULTCTX

## コンサルテーション結果（ITコンサルタントによる分析・ユーザー承認済み）
以下はプロのITコンサルタントがWeb調査・ユーザー対話を経て確定した開発方針です。
すべての設計・実装において、この方針に最優先で従ってください。

${context}

---
上記のコンサルテーション結果を踏まえ、以下を特に重視してください：
- 確定要件（Must）は必ず全て実装する
- コンサルタントの提案で承認されたものは積極的に取り入れる
- 注意すべきポイントは必ず対策する
- ユーザーのフィードバックがあればそれを最優先する
CONSULTCTX
}

# ============================================================
# ヘルパー: Web調査結果のみを返す（競合調査フェーズで使用）
# ============================================================
ce_get_web_research() {
    echo "${CE_WEB_RESEARCH:-}"
}
