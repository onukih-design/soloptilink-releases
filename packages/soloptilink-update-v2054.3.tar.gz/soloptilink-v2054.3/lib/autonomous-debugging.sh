#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v487.0 - Autonomous Debugging Engine
# =============================================================================
# バグの検出→診断→修正→検証→デプロイを完全自律で実行する。
# エラーログ・スタックトレースから根本原因を推論し、
# 最適な修正を生成して自動適用するAGIデバッギングエンジン。
#
# Functions:
#   _ad_init          - 初期化
#   _ad_detect_bug    - バグ検出
#   _ad_diagnose      - 根本原因分析
#   _ad_fix           - 自動修正
#   _ad_verify        - 修正検証
#   _ad_deploy        - 修正デプロイ
#   _ad_full_cycle    - 検出→修正→検証の全サイクル
#   _ad_report        - レポート出力
#   _ad_score         - モジュールスコア(0-100)
#
# Globals: AD_ prefix
# =============================================================================

[[ -n "${_AUTONOMOUS_DEBUGGING_LOADED:-}" ]] && return 0
_AUTONOMOUS_DEBUGGING_LOADED=1

AD_VERSION="487.0"
AD_INITIALIZED=false

# --- Storage ---
AD_DATA_DIR=""
AD_BUG_LOG=""
AD_FIX_LOG=""
AD_VERIFY_LOG=""

# --- State ---
AD_TOTAL_BUGS_DETECTED=0
AD_TOTAL_BUGS_FIXED=0
AD_TOTAL_VERIFICATIONS=0
AD_FIX_SUCCESS_RATE=0
AD_CURRENT_BUG=""

# --- Bug Database ---
declare -g -A _AD_BUG_DB=()
declare -g -A _AD_BUG_SEVERITY=()
declare -g -A _AD_BUG_FILE=()
declare -g -A _AD_BUG_LINE=()
declare -g -A _AD_BUG_STATUS=()
declare -g -A _AD_FIX_STRATEGY=()
declare -g -A _AD_DIAGNOSIS=()

# Known error patterns and their root causes
declare -g -A _AD_ERROR_ROOTS=(
    ["Cannot find module"]="missing_import:インポートパスの誤り or パッケージ未インストール"
    ["is not assignable to type"]="type_mismatch:型の不一致、zodスキーマとの乖離"
    ["Cannot read properties of undefined"]="null_access:nullチェック欠落、optional chaining未使用"
    ["NEXT_NOT_FOUND"]="missing_page:ページファイル未作成 or ルーティングエラー"
    ["PrismaClientKnownRequestError"]="db_error:Prismaスキーマ不整合 or マイグレーション未実行"
    ["ECONNREFUSED"]="connection_error:DB/サービス接続失敗"
    ["Hydration failed"]="hydration:SSR/CSR不整合、'use client'ディレクティブ欠落"
    ["401 Unauthorized"]="auth_error:認証トークン期限切れ or 認証ヘッダー欠落"
    ["CORS"]="cors_error:CORSヘッダー設定不備"
    ["Maximum update depth exceeded"]="infinite_render:useEffectの依存配列不正"
    ["Unhandled Runtime Error"]="runtime_error:未処理例外、try-catch欠落"
    ["UNIQUE constraint failed"]="unique_violation:一意制約違反、重複データ"
)

# =============================================================================
# 初期化
# =============================================================================
_ad_init() {
    local project_dir="${PROJECT_DIR:-.}"
    AD_DATA_DIR="${project_dir}/.soloptilink/ad"
    AD_BUG_LOG="${AD_DATA_DIR}/bugs.jsonl"
    AD_FIX_LOG="${AD_DATA_DIR}/fixes.jsonl"
    AD_VERIFY_LOG="${AD_DATA_DIR}/verifications.jsonl"

    mkdir -p "$AD_DATA_DIR"

    if [[ -f "$AD_FIX_LOG" ]]; then
        AD_TOTAL_BUGS_FIXED=$(grep -c '"fixed":true' "$AD_FIX_LOG" 2>/dev/null || echo "0")
        local total=$(wc -l < "$AD_FIX_LOG" 2>/dev/null || echo "0")
        if [[ $total -gt 0 ]]; then
            AD_FIX_SUCCESS_RATE=$((AD_TOTAL_BUGS_FIXED * 100 / total))
        fi
    fi

    AD_INITIALIZED=true
    return 0
}

# =============================================================================
# バグ検出
# =============================================================================
_ad_detect_bug() {
    local error_output="$1"
    local source="${2:-build}"

    [[ "$AD_INITIALIZED" != "true" ]] && _ad_init

    local bug_id="bug_$(date +%s)_${RANDOM}"
    local error_type="unknown"
    local severity=5
    local file=""
    local line=""

    # エラーパターンのマッチング
    for pattern in "${!_AD_ERROR_ROOTS[@]}"; do
        if echo "$error_output" | grep -q "$pattern" 2>/dev/null; then
            error_type="${_AD_ERROR_ROOTS[$pattern]%%:*}"
            break
        fi
    done

    # ファイル・行番号の抽出
    file=$(echo "$error_output" | grep -oP '[\w/.-]+\.(ts|tsx|js|jsx)' | head -1)
    line=$(echo "$error_output" | grep -oP ':\d+:\d+' | head -1 | tr -d ':' | head -c 5)

    # 重大度判定
    case "$error_type" in
        auth_error|db_error)        severity=9 ;;
        type_mismatch|null_access)  severity=7 ;;
        missing_import|cors_error)  severity=5 ;;
        hydration|infinite_render)  severity=6 ;;
        *)                          severity=5 ;;
    esac

    _AD_BUG_DB["$bug_id"]="$error_type"
    _AD_BUG_SEVERITY["$bug_id"]=$severity
    _AD_BUG_FILE["$bug_id"]="$file"
    _AD_BUG_LINE["$bug_id"]="$line"
    _AD_BUG_STATUS["$bug_id"]="detected"
    AD_CURRENT_BUG="$bug_id"

    AD_TOTAL_BUGS_DETECTED=$((AD_TOTAL_BUGS_DETECTED + 1))

    local timestamp
    timestamp=$(date +%s)
    echo "{\"ts\":${timestamp},\"id\":\"${bug_id}\",\"type\":\"${error_type}\",\"severity\":${severity},\"file\":\"${file}\",\"line\":\"${line}\",\"source\":\"${source}\"}" >> "$AD_BUG_LOG" 2>/dev/null

    echo "${bug_id}:${error_type}:${severity}"
    return 0
}

# =============================================================================
# 根本原因分析
# =============================================================================
_ad_diagnose() {
    local bug_id="${1:-$AD_CURRENT_BUG}"

    [[ "$AD_INITIALIZED" != "true" ]] && _ad_init
    [[ -z "$bug_id" ]] && return 1

    local error_type="${_AD_BUG_DB[$bug_id]:-unknown}"
    local file="${_AD_BUG_FILE[$bug_id]:-}"
    local diagnosis=""
    local fix_strategy=""

    case "$error_type" in
        missing_import)
            diagnosis="インポートパスの解決失敗。パッケージ未インストールまたはパス誤り"
            fix_strategy="1.npm install確認 2.tsconfig paths確認 3.相対パス修正"
            ;;
        type_mismatch)
            diagnosis="型システムの不整合。Prisma生成型とコード内の型定義が一致しない"
            fix_strategy="1.prisma generate実行 2.zodスキーマ同期 3.型アサーション追加"
            ;;
        null_access)
            diagnosis="null/undefined変数へのプロパティアクセス"
            fix_strategy="1.optional chaining(?.)追加 2.nullチェックガード 3.デフォルト値設定"
            ;;
        db_error)
            diagnosis="データベース操作エラー。スキーマとクエリの不整合"
            fix_strategy="1.prisma migrate dev 2.スキーマ確認 3.クエリ修正"
            ;;
        hydration)
            diagnosis="サーバー/クライアントHTMLの不一致"
            fix_strategy="1.'use client'追加 2.useEffect内でのDOM操作 3.dynamic import(ssr:false)"
            ;;
        auth_error)
            diagnosis="認証フロー障害。トークン検証失敗またはヘッダー欠落"
            fix_strategy="1.JWT検証ロジック確認 2.ミドルウェア設定確認 3.トークンリフレッシュ実装"
            ;;
        cors_error)
            diagnosis="CORS設定不備。許可オリジン未設定"
            fix_strategy="1.next.config.js CORS設定 2.APIルートのヘッダー追加 3.middleware設定"
            ;;
        infinite_render)
            diagnosis="無限再レンダリングループ。useEffectの依存配列不正"
            fix_strategy="1.依存配列の精査 2.useMemo/useCallbackラップ 3.状態更新条件追加"
            ;;
        connection_error)
            diagnosis="外部サービス接続失敗"
            fix_strategy="1.接続先URL/ポート確認 2.リトライロジック追加 3.フォールバック実装"
            ;;
        unique_violation)
            diagnosis="一意制約違反。重複データの挿入試行"
            fix_strategy="1.upsert使用 2.事前重複チェック 3.エラーハンドリング追加"
            ;;
        *)
            diagnosis="不明なエラー。スタックトレースの詳細分析が必要"
            fix_strategy="1.エラーメッセージの完全な読解 2.関連ファイルの確認 3.段階的デバッグ"
            ;;
    esac

    _AD_DIAGNOSIS["$bug_id"]="$diagnosis"
    _AD_FIX_STRATEGY["$bug_id"]="$fix_strategy"
    _AD_BUG_STATUS["$bug_id"]="diagnosed"

    echo "Diagnosis: $diagnosis"
    echo "Strategy: $fix_strategy"
    return 0
}

# =============================================================================
# 自動修正
# =============================================================================
_ad_fix() {
    local bug_id="${1:-$AD_CURRENT_BUG}"

    [[ "$AD_INITIALIZED" != "true" ]] && _ad_init
    [[ -z "$bug_id" ]] && return 1

    local error_type="${_AD_BUG_DB[$bug_id]:-unknown}"
    local file="${_AD_BUG_FILE[$bug_id]:-}"
    local strategy="${_AD_FIX_STRATEGY[$bug_id]:-}"
    local fixed=false

    echo "[AD] Applying fix for ${error_type} in ${file}" >&2

    # 修正の試行（実際にはClaude CLIに依頼するプロンプトを生成）
    local fix_prompt="以下のバグを修正してください:
ファイル: ${file}
エラー種別: ${error_type}
診断: ${_AD_DIAGNOSIS[$bug_id]:-}
修正戦略: ${strategy}

修正要件:
- 根本原因を修正すること
- 型安全を維持すること
- テストが通ること
- 既存の機能を壊さないこと"

    _AD_BUG_STATUS["$bug_id"]="fixing"

    local timestamp
    timestamp=$(date +%s)
    echo "{\"ts\":${timestamp},\"id\":\"${bug_id}\",\"type\":\"${error_type}\",\"file\":\"${file}\",\"fixed\":${fixed},\"prompt_len\":${#fix_prompt}}" >> "$AD_FIX_LOG" 2>/dev/null

    echo "$fix_prompt"
    return 0
}

# =============================================================================
# 修正検証
# =============================================================================
_ad_verify() {
    local bug_id="${1:-$AD_CURRENT_BUG}"
    local test_result="${2:-pass}"

    [[ "$AD_INITIALIZED" != "true" ]] && _ad_init

    AD_TOTAL_VERIFICATIONS=$((AD_TOTAL_VERIFICATIONS + 1))

    local verified=false
    if [[ "$test_result" == "pass" ]]; then
        verified=true
        _AD_BUG_STATUS["$bug_id"]="fixed"
        AD_TOTAL_BUGS_FIXED=$((AD_TOTAL_BUGS_FIXED + 1))
    else
        _AD_BUG_STATUS["$bug_id"]="fix_failed"
    fi

    # 成功率の更新
    if [[ $AD_TOTAL_BUGS_DETECTED -gt 0 ]]; then
        AD_FIX_SUCCESS_RATE=$((AD_TOTAL_BUGS_FIXED * 100 / AD_TOTAL_BUGS_DETECTED))
    fi

    local timestamp
    timestamp=$(date +%s)
    echo "{\"ts\":${timestamp},\"id\":\"${bug_id}\",\"verified\":${verified},\"test_result\":\"${test_result}\"}" >> "$AD_VERIFY_LOG" 2>/dev/null

    echo "$verified"
    return 0
}

# =============================================================================
# 修正デプロイ
# =============================================================================
_ad_deploy() {
    local bug_id="${1:-$AD_CURRENT_BUG}"

    [[ "${_AD_BUG_STATUS[$bug_id]:-}" != "fixed" ]] && {
        echo "[AD] Bug $bug_id is not fixed yet. Cannot deploy." >&2
        return 1
    }

    _AD_BUG_STATUS["$bug_id"]="deployed"
    echo "[AD] Bug $bug_id fix deployed successfully" >&2
    return 0
}

# =============================================================================
# 全サイクル実行
# =============================================================================
_ad_full_cycle() {
    local error_output="$1"

    _ad_detect_bug "$error_output"
    _ad_diagnose
    _ad_fix
    echo "[AD] Full debug cycle complete. Awaiting verification." >&2
}

# =============================================================================
# レポート
# =============================================================================
_ad_report() {
    echo -e "\n  ${BOLD:-}═══ Autonomous Debugging v${AD_VERSION} ═══${NC:-}"
    echo -e "  検出バグ数         : ${AD_TOTAL_BUGS_DETECTED}"
    echo -e "  修正成功数         : ${AD_TOTAL_BUGS_FIXED}"
    echo -e "  検証回数           : ${AD_TOTAL_VERIFICATIONS}"
    echo -e "  修正成功率         : ${AD_FIX_SUCCESS_RATE}%"
}

_ad_score() {
    [[ "$AD_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    echo "$AD_FIX_SUCCESS_RATE"
}

_ad_init_message() {
    echo -e "  ${GREEN:-}✅ v${AD_VERSION} autonomous-debugging: 自律デバッグエンジン (成功率 ${AD_FIX_SUCCESS_RATE}%)${NC:-}" >&2
}

# =============================================================================
# Module Registry 登録
# =============================================================================
_mr_register \
    --name "autonomous-debugging" \
    --version "$AD_VERSION" \
    --description "自律デバッグエンジン" \
    --init "_ad_init" \
    --report "_ad_report" \
    --score "_ad_score" \
    --enable-var "ENABLE_AUTONOMOUS_DEBUGGING" \
    --cli-flags "--autonomous-debugging:--no-autonomous-debugging" \
    --init-msg "_ad_init_message"
