#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v107.0 - Pattern Verifier
# 生成コードがエンタープライズパターンに準拠しているか検証
#
# 問題: Quality Gateはgrep程度の検査しかしない。
# 実際にはトランザクション未使用、バリデーション不足、
# エラーハンドリング欠如、認証チェック漏れが残る。
#
# 解決: AST的手法(awk/sed)で構造的にパターン準拠を検証。
# 各検証はファイル単位で違反を特定し、修正プロンプトに変換。
# ============================================================

[[ -n "${_PV_LOADED:-}" ]] && return 0
_PV_LOADED=1

PV_VERSION="107.0"
PV_INITIALIZED=false

# Verification results
PV_TRANSACTION_PASS=0
PV_TRANSACTION_FAIL=0
PV_TRANSACTION_DETAIL=""

PV_VALIDATION_PASS=0
PV_VALIDATION_FAIL=0
PV_VALIDATION_DETAIL=""

PV_ERROR_HANDLING_PASS=0
PV_ERROR_HANDLING_FAIL=0
PV_ERROR_HANDLING_DETAIL=""

PV_AUTH_CHECK_PASS=0
PV_AUTH_CHECK_FAIL=0
PV_AUTH_CHECK_DETAIL=""

# ============================================================
# Init
# ============================================================
pv_init() {
    PV_TRANSACTION_PASS=0
    PV_TRANSACTION_FAIL=0
    PV_TRANSACTION_DETAIL=""
    PV_VALIDATION_PASS=0
    PV_VALIDATION_FAIL=0
    PV_VALIDATION_DETAIL=""
    PV_ERROR_HANDLING_PASS=0
    PV_ERROR_HANDLING_FAIL=0
    PV_ERROR_HANDLING_DETAIL=""
    PV_AUTH_CHECK_PASS=0
    PV_AUTH_CHECK_FAIL=0
    PV_AUTH_CHECK_DETAIL=""
    PV_INITIALIZED=true
    return 0
}

# ============================================================
# Verify: Multi-model writes use $transaction
# ============================================================
pv_verify_transactions() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1

    local pass=0
    local fail=0
    local detail=""

    # Find route.ts/js files that have multiple prisma write operations
    while IFS= read -r route_file; do
        [[ "$route_file" == *"node_modules"* ]] && continue
        [[ "$route_file" == *".next"* ]] && continue

        local rel="${route_file#$project_dir/}"

        # Count distinct prisma write operations (create, update, delete, upsert)
        local write_count
        write_count=$(echo "$write_count" | tr -d '[:space:]')

        # Skip files with 0 or 1 writes (no transaction needed)
        if [[ ${write_count:-0} -le 1 ]]; then
            if [[ ${write_count:-0} -eq 1 ]]; then
                pass=$((pass + 1))
            fi
            continue
        fi

        # Multiple writes detected - check for $transaction
        local has_transaction
        has_transaction=$(echo "$has_transaction" | tr -d '[:space:]')

        if [[ ${has_transaction:-0} -gt 0 ]]; then
            pass=$((pass + 1))
        else
            fail=$((fail + 1))
            detail+="  [TX_MISSING] ${rel}: ${write_count} write operations without \$transaction\n"

            # Show which operations are not wrapped
            local operations
            operations=$(grep -nE 'prisma\.[a-zA-Z]+\.(create|update|delete|upsert)\s*\(' "$route_file" 2>/dev/null | head -5)
            while IFS= read -r op; do
                [[ -n "$op" ]] && detail+="    Line: ${op}\n"
            done <<< "$operations"
        fi
    done < <(find "$project_dir" \
        -type f \( -name "route.ts" -o -name "route.js" -o -name "*.service.ts" -o -name "*.service.js" \) \
        ! -path "*/node_modules/*" ! -path "*/.next/*" \
        2>/dev/null)

    PV_TRANSACTION_PASS=$pass
    PV_TRANSACTION_FAIL=$fail
    PV_TRANSACTION_DETAIL="$detail"

    return 0
}

# ============================================================
# Verify: POST/PUT/PATCH routes have zod validation
# ============================================================
pv_verify_validation() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1

    local pass=0
    local fail=0
    local detail=""

    while IFS= read -r route_file; do
        [[ "$route_file" == *"node_modules"* ]] && continue
        [[ "$route_file" == *".next"* ]] && continue

        local rel="${route_file#$project_dir/}"

        # Check which mutation methods exist in this file
        local has_post=false
        local has_put=false
        local has_patch=false

        grep -qE 'export\s+(async\s+)?function\s+POST' "$route_file" 2>/dev/null && has_post=true
        grep -qE 'export\s+(async\s+)?function\s+PUT' "$route_file" 2>/dev/null && has_put=true
        grep -qE 'export\s+(async\s+)?function\s+PATCH' "$route_file" 2>/dev/null && has_patch=true

        # Skip if no mutation methods
        [[ "$has_post" == "false" ]] && [[ "$has_put" == "false" ]] && [[ "$has_patch" == "false" ]] && continue

        # Check for zod validation before DB operation
        # Look for .parse() or .safeParse() calls
        local has_parse

        # Also accept other validation patterns
        local has_zod_import

        if [[ ${has_parse:-0} -gt 0 ]]; then
            pass=$((pass + 1))

            # Extra check: is validation BEFORE the DB call?
            # Use awk to verify ordering within each handler
            local validation_after_db
            validation_after_db=$(awk '
                /prisma\.[a-zA-Z]+\.(create|update)/ { db_line=NR }
                /\.(parse|safeParse)\s*\(/ { parse_line=NR }
                END {
                    if (db_line > 0 && parse_line > 0 && parse_line > db_line) print "1"
                    else print "0"
                }
            ' "$route_file" 2>/dev/null)

            if [[ "$validation_after_db" == "1" ]]; then
                detail+="  [VAL_ORDER] ${rel}: validation appears AFTER DB operation (should be before)\n"
                # Don't fail, just warn
            fi
        elif [[ ${has_zod_import:-0} -gt 0 ]]; then
            # Has zod imported but no .parse() - schema defined but not used
            fail=$((fail + 1))
            detail+="  [VAL_UNUSED] ${rel}: zod imported but .parse()/.safeParse() not called\n"
        else
            fail=$((fail + 1))
            local methods=""
            [[ "$has_post" == "true" ]] && methods+="POST "
            [[ "$has_put" == "true" ]] && methods+="PUT "
            [[ "$has_patch" == "true" ]] && methods+="PATCH "
            detail+="  [VAL_MISSING] ${rel}: ${methods}handler(s) without zod validation\n"
        fi
    done < <(find "$project_dir" \
        -type f \( -name "route.ts" -o -name "route.js" \) \
        ! -path "*/node_modules/*" ! -path "*/.next/*" \
        2>/dev/null)

    PV_VALIDATION_PASS=$pass
    PV_VALIDATION_FAIL=$fail
    PV_VALIDATION_DETAIL="$detail"

    return 0
}

# ============================================================
# Verify: Async route handlers have try/catch
# ============================================================
pv_verify_error_handling() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1

    local pass=0
    local fail=0
    local detail=""

    while IFS= read -r route_file; do
        [[ "$route_file" == *"node_modules"* ]] && continue
        [[ "$route_file" == *".next"* ]] && continue

        local rel="${route_file#$project_dir/}"

        # Count exported async functions (route handlers)
        local handler_count

        [[ ${handler_count:-0} -eq 0 ]] && continue

        # Check for try/catch blocks
        local try_count

        # Check for NextResponse error returns (catch block pattern)
        local error_response

        # Verify try/catch covers handlers adequately
        if [[ ${try_count:-0} -ge 1 ]] && [[ ${error_response:-0} -ge 1 ]]; then
            pass=$((pass + 1))

            # Extra: check that EVERY handler has try/catch (not just some)
            # Use awk to match handler functions and check for try block inside
            local unprotected
            unprotected=$(awk '
                /export\s+(async\s+)?function\s+(GET|POST|PUT|PATCH|DELETE)/ {
                    handler_name=$NF; in_handler=1; depth=0; has_try=0
                }
                in_handler && /\{/ { depth++ }
                in_handler && /\}/ { depth--; if(depth<=0) { if(!has_try) print handler_name; in_handler=0 } }
                in_handler && /try\s*\{/ { has_try=1 }
            ' "$route_file" 2>/dev/null)

            if [[ -n "$unprotected" ]]; then
                while IFS= read -r handler; do
                    [[ -n "$handler" ]] && detail+="  [ERR_PARTIAL] ${rel}: handler ${handler} lacks try/catch\n"
                done <<< "$unprotected"
            fi
        elif [[ ${try_count:-0} -ge 1 ]]; then
            # Has try/catch but no error response
            pass=$((pass + 1))
            detail+="  [ERR_RESPONSE] ${rel}: try/catch exists but no error response with status code\n"
        else
            fail=$((fail + 1))
            detail+="  [ERR_MISSING] ${rel}: ${handler_count} handler(s) without try/catch\n"
        fi
    done < <(find "$project_dir" \
        -type f \( -name "route.ts" -o -name "route.js" \) \
        ! -path "*/node_modules/*" ! -path "*/.next/*" \
        2>/dev/null)

    PV_ERROR_HANDLING_PASS=$pass
    PV_ERROR_HANDLING_FAIL=$fail
    PV_ERROR_HANDLING_DETAIL="$detail"

    return 0
}

# ============================================================
# Verify: Protected routes check authentication
# ============================================================
pv_verify_auth_check() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1

    local pass=0
    local fail=0
    local detail=""

    # Skip public routes
    local -a public_patterns=("login" "register" "signup" "signin" "auth/callback" "webhook" "health" "status" "public" "download" "cron")

    while IFS= read -r route_file; do
        [[ "$route_file" == *"node_modules"* ]] && continue
        [[ "$route_file" == *".next"* ]] && continue

        local rel="${route_file#$project_dir/}"

        # Check if this is a public route
        local is_public=false
        for pattern in "${public_patterns[@]}"; do
            if echo "$rel" | grep -qi "$pattern" 2>/dev/null; then
                is_public=true
                break
            fi
        done
        [[ "$is_public" == "true" ]] && continue

        # Check if this route has DB operations (protected data access)
        local has_db
        [[ ${has_db:-0} -eq 0 ]] && continue

        # Check for authentication patterns
        local has_auth=false

        # Pattern 1: Session/token check
        if grep -qE 'getServerSession|getSession|getToken|cookies\(\)\.get|headers\(\)\.get.*[Aa]uth' "$route_file" 2>/dev/null; then
            has_auth=true
        fi

        # Pattern 2: Auth middleware or wrapper
        if grep -qE 'withAuth|requireAuth|authenticate|verifyToken|verifyJWT|authMiddleware' "$route_file" 2>/dev/null; then
            has_auth=true
        fi

        # Pattern 3: Direct JWT/Bearer check
        if grep -qE 'authorization.*bearer|Bearer|jwt\.verify|jsonwebtoken' "$route_file" 2>/dev/null; then
            has_auth=true
        fi

        # Pattern 4: NextAuth session check
        if grep -qE 'auth\(\)|useSession|session\s*=' "$route_file" 2>/dev/null; then
            has_auth=true
        fi

        if [[ "$has_auth" == "true" ]]; then
            pass=$((pass + 1))

            # Extra: verify auth check is BEFORE DB operations
            local auth_line
            auth_line=$(grep -nE 'getServerSession|getSession|getToken|withAuth|requireAuth|verifyToken|auth\(\)' "$route_file" 2>/dev/null | head -1 | cut -d: -f1)
            local db_line
            db_line=$(grep -nE 'prisma\.[a-zA-Z]+\.(find|create|update|delete)' "$route_file" 2>/dev/null | head -1 | cut -d: -f1)

            if [[ -n "$auth_line" ]] && [[ -n "$db_line" ]] && [[ ${auth_line:-0} -gt ${db_line:-0} ]]; then
                detail+="  [AUTH_ORDER] ${rel}: auth check (line ${auth_line}) is AFTER DB query (line ${db_line})\n"
            fi
        else
            fail=$((fail + 1))
            detail+="  [AUTH_MISSING] ${rel}: DB operations without authentication check\n"
        fi
    done < <(find "$project_dir" \
        -type f \( -name "route.ts" -o -name "route.js" \) \
        -path "*/api/*" \
        ! -path "*/node_modules/*" ! -path "*/.next/*" \
        2>/dev/null)

    PV_AUTH_CHECK_PASS=$pass
    PV_AUTH_CHECK_FAIL=$fail
    PV_AUTH_CHECK_DETAIL="$detail"

    return 0
}

# ============================================================
# Main: run all verifications
# ============================================================
pv_run() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1
    [[ "$PV_INITIALIZED" != "true" ]] && pv_init

    pv_verify_transactions "$project_dir"
    pv_verify_validation "$project_dir"
    pv_verify_error_handling "$project_dir"
    pv_verify_auth_check "$project_dir"

    echo "=== Pattern Verifier v${PV_VERSION} ==="
    echo "Transactions: ${PV_TRANSACTION_PASS} pass / ${PV_TRANSACTION_FAIL} fail"
    echo "Validation:   ${PV_VALIDATION_PASS} pass / ${PV_VALIDATION_FAIL} fail"
    echo "Error handling: ${PV_ERROR_HANDLING_PASS} pass / ${PV_ERROR_HANDLING_FAIL} fail"
    echo "Auth check:   ${PV_AUTH_CHECK_PASS} pass / ${PV_AUTH_CHECK_FAIL} fail"
    echo "Score: $(pv_score)/100"

    # Print details
    [[ -n "$PV_TRANSACTION_DETAIL" ]] && echo -e "$PV_TRANSACTION_DETAIL"
    [[ -n "$PV_VALIDATION_DETAIL" ]] && echo -e "$PV_VALIDATION_DETAIL"
    [[ -n "$PV_ERROR_HANDLING_DETAIL" ]] && echo -e "$PV_ERROR_HANDLING_DETAIL"
    [[ -n "$PV_AUTH_CHECK_DETAIL" ]] && echo -e "$PV_AUTH_CHECK_DETAIL"

    return 0
}

# ============================================================
# Score: 25 points per verification category
# ============================================================
pv_score() {
    local score=0

    # Transactions: 25 points
    local tx_total=$((PV_TRANSACTION_PASS + PV_TRANSACTION_FAIL))
    if [[ $tx_total -eq 0 ]]; then
        score=$((score + 25))  # No multi-write routes = pass
    elif [[ $PV_TRANSACTION_FAIL -eq 0 ]]; then
        score=$((score + 25))
    else
        local tx_ratio=$(( (PV_TRANSACTION_PASS * 25) / tx_total ))
        score=$((score + tx_ratio))
    fi

    # Validation: 25 points
    local val_total=$((PV_VALIDATION_PASS + PV_VALIDATION_FAIL))
    if [[ $val_total -eq 0 ]]; then
        score=$((score + 25))
    elif [[ $PV_VALIDATION_FAIL -eq 0 ]]; then
        score=$((score + 25))
    else
        local val_ratio=$(( (PV_VALIDATION_PASS * 25) / val_total ))
        score=$((score + val_ratio))
    fi

    # Error handling: 25 points
    local err_total=$((PV_ERROR_HANDLING_PASS + PV_ERROR_HANDLING_FAIL))
    if [[ $err_total -eq 0 ]]; then
        score=$((score + 25))
    elif [[ $PV_ERROR_HANDLING_FAIL -eq 0 ]]; then
        score=$((score + 25))
    else
        local err_ratio=$(( (PV_ERROR_HANDLING_PASS * 25) / err_total ))
        score=$((score + err_ratio))
    fi

    # Auth check: 25 points
    local auth_total=$((PV_AUTH_CHECK_PASS + PV_AUTH_CHECK_FAIL))
    if [[ $auth_total -eq 0 ]]; then
        score=$((score + 25))
    elif [[ $PV_AUTH_CHECK_FAIL -eq 0 ]]; then
        score=$((score + 25))
    else
        local auth_ratio=$(( (PV_AUTH_CHECK_PASS * 25) / auth_total ))
        score=$((score + auth_ratio))
    fi

    echo "$score"
}

# ============================================================
# Report
# ============================================================
pv_report() {
    echo -e "\n  ${BOLD:-}=== Pattern Verifier v${PV_VERSION} ===${NC:-}"
    echo -e "  Transactions: ${PV_TRANSACTION_PASS} pass / ${PV_TRANSACTION_FAIL} fail"
    echo -e "  Validation:   ${PV_VALIDATION_PASS} pass / ${PV_VALIDATION_FAIL} fail"
    echo -e "  Error handling: ${PV_ERROR_HANDLING_PASS} pass / ${PV_ERROR_HANDLING_FAIL} fail"
    echo -e "  Auth check:   ${PV_AUTH_CHECK_PASS} pass / ${PV_AUTH_CHECK_FAIL} fail"
    echo -e "  Score: $(pv_score)/100"
}

# ============================================================
# Module Registry self-registration
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "pattern-verifier" \
        --version "$PV_VERSION" \
        --description "エンタープライズパターン検証 - TX/Validation/ErrorHandling/Auth" \
        --init "pv_init" \
        --report "pv_report" \
        --score "pv_score" \
        --enable-var "ENABLE_PV" \
        --cli-flags "--pattern-verifier:--no-pattern-verifier"
fi

# v2003.1: source時のexit codeを確実に0にする
true
