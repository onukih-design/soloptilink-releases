#!/usr/bin/env bash
# SoloptiLinkAI v2033.2 - Weekly Trend Aggregator (WTA)
# 過去 7 日分の daily_upgrade_<UTC>.md を読み込み、
# 構造的トレンド (errors / fix-failed / blockers / fortress_score) を時系列で出す。
#
# 設計方針:
#   - 読み取り専用 (新規ファイル書き込みは行わない)
#   - DUE から呼び出されて report 内に inline で埋め込まれる
#   - 7 日に満たない場合は手元にある分だけで集計

[[ -n "${_WEEKLY_TREND_AGGREGATOR_LOADED:-}" ]] && return 0
_WEEKLY_TREND_AGGREGATOR_LOADED=1

WTA_VERSION="2033.2"
WTA_HOME="${SOLOPTILINK_HOME:-$HOME/.soloptilink}"
WTA_PROPOSALS="${WTA_HOME}/.proposals"
WTA_WINDOW_DAYS="${WTA_WINDOW_DAYS:-7}"

# ============================================================
# 内部ユーティリティ
# ============================================================
_wta_extract_metric() {
    # $1: report file, $2: metric label (e.g. "raw failures")
    # 括弧入りラベルでも安全に値を取り出すため awk で ": " 以降を抽出
    local file="$1" label="$2"
    [[ -f "$file" ]] || { echo ""; return; }
    awk -v lbl="- ${label}:" '
        index($0, lbl) == 1 {
            sub(/^[^:]*: */, "", $0)
            print $0
            exit
        }
    ' "$file" | head -c 64
}

_wta_recent_reports() {
    # 直近 N 日 (UTC) の daily_upgrade_*.md を新しい順で出す
    [[ -d "$WTA_PROPOSALS" ]] || return
    # ファイル名: daily_upgrade_YYYYMMDDTHHMMSSZ.md
    # mtime 降順で並べて、上位を返す (BSD/GNU find 双方互換)
    ls -1t "$WTA_PROPOSALS"/daily_upgrade_*.md 2>/dev/null | head -n "$WTA_WINDOW_DAYS"
}

# ============================================================
# サマリ生成 (DUE から呼ばれる)
# ============================================================
wta_summary() {
    local files
    files=$(_wta_recent_reports)
    if [[ -z "$files" ]]; then
        echo "- WTA: 過去 ${WTA_WINDOW_DAYS} 日の daily_upgrade レポートが見つかりません (初回起動 or 旧形式)"
        return 0
    fi

    local count=0
    local trend_failed=() trend_blockers=() trend_errs=() trend_dates=()

    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        count=$((count + 1))
        local date_tag
        date_tag=$(basename "$f" | sed -E 's/^daily_upgrade_([0-9TZ]+)\.md$/\1/')
        trend_dates+=("$date_tag")
        trend_errs+=("$(_wta_extract_metric "$f" "raw failures")")
        trend_failed+=("$(_wta_extract_metric "$f" "fix-failed entries")")
        trend_blockers+=("$(_wta_extract_metric "$f" "distribution blockers (latest distilled)")")
    done <<< "$files"

    echo "- WTA window: 直近 ${count} 日分の daily_upgrade を集計"
    echo "- date | raw_failures | fix_failed | dist_blockers"
    local i
    for ((i = 0; i < ${#trend_dates[@]}; i++)); do
        printf -- "  - %s | %s | %s | %s\n" \
            "${trend_dates[$i]:-?}" \
            "${trend_errs[$i]:-?}" \
            "${trend_failed[$i]:-?}" \
            "${trend_blockers[$i]:-?}"
    done

    # 単純トレンド判定 (最新 vs 1つ前)
    if [[ ${#trend_blockers[@]} -ge 2 ]]; then
        local latest prev
        latest="${trend_blockers[0]}"
        prev="${trend_blockers[1]}"
        if [[ "$latest" =~ ^[0-9]+$ ]] && [[ "$prev" =~ ^[0-9]+$ ]]; then
            if (( latest > prev )); then
                echo "- trend (blockers): WORSENING (${prev} -> ${latest})"
            elif (( latest < prev )); then
                echo "- trend (blockers): IMPROVING (${prev} -> ${latest})"
            else
                echo "- trend (blockers): STABLE (${prev} == ${latest})"
            fi
        fi
    fi
}

# CLI 直接実行
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-summary}" in
        summary) wta_summary ;;
        version) echo "$WTA_VERSION" ;;
        *) echo "usage: $0 {summary|version}" >&2; exit 2 ;;
    esac
fi
