#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v57.0 - JSON File Extractor
# Claude CLIの --json-schema を使った確実なファイル抽出
#
# 問題: 従来のファイルライターは正規表現でClaudeの出力をパース
# - "--- FILE: path ---" マーカーの検出が不安定
# - Claudeが微妙に異なる形式で出力すると失敗
# - ネストしたコードブロック内のマーカーを誤検出
#
# 解決: --json-schema でClaudeに構造化JSON出力を強制
# {
#   "files": [
#     {"path": "src/api/users.ts", "content": "..."},
#     {"path": "src/lib/prisma.ts", "content": "..."}
#   ]
# }
# JSONなので100%パース成功。正規表現の不確実性ゼロ。
#
# v57.0: Smart Generation
# ============================================================

# --- グローバル状態 ---
JFE_VERSION="57.0"
JFE_INITIALIZED=false
JFE_EXTRACT_COUNT=0
JFE_FILES_EXTRACTED=0
JFE_FALLBACK_COUNT=0

# --- JSON Schema定義 ---
# Claudeに強制する出力形式
JFE_FILE_SCHEMA='{
  "type": "object",
  "properties": {
    "files": {
      "type": "array",
      "items": {
        "type": "object",
        "properties": {
          "path": {"type": "string", "description": "Relative file path"},
          "content": {"type": "string", "description": "File content"},
          "language": {"type": "string", "description": "Programming language"}
        },
        "required": ["path", "content"]
      }
    },
    "summary": {"type": "string", "description": "Brief summary of generated files"}
  },
  "required": ["files"]
}'

# ============================================================
# 初期化
# ============================================================
jfe_init() {
    JFE_INITIALIZED=true
    JFE_EXTRACT_COUNT=0
    JFE_FILES_EXTRACTED=0
    JFE_FALLBACK_COUNT=0
    return 0
}

# ============================================================
# JSON Schema付きClaude呼び出し → ファイル抽出
# ============================================================
jfe_generate_and_extract() {
    local prompt="$1"
    local project_dir="${2:-.}"
    local phase="${3:-implementation}"

    JFE_EXTRACT_COUNT=$((JFE_EXTRACT_COUNT + 1))

    # プロンプトにJSON出力指示を追加
    local enhanced_prompt="${prompt}

## 出力形式（厳守）
以下のJSON形式で出力してください。各ファイルのpathとcontentを含めてください。
{
  \"files\": [
    {\"path\": \"relative/path/to/file.ts\", \"content\": \"ファイルの完全な内容\", \"language\": \"typescript\"}
  ],
  \"summary\": \"生成したファイルの概要\"
}"

    local result=""

    # Claude Bridge の構造化呼び出しを試行
    if type -t cb2_call_structured &>/dev/null && [[ "${ENABLE_CLAUDE_BRIDGE:-true}" == "true" ]]; then
        result=$(cb2_call_structured "$enhanced_prompt" "$JFE_FILE_SCHEMA" "$phase" 2>/dev/null || echo "")
    fi

    # 結果からファイル抽出
    if [[ -n "$result" ]]; then
        local extracted
        extracted=$(jfe_parse_json_output "$result" "$project_dir")
        if [[ $? -eq 0 && -n "$extracted" ]]; then
            echo "$extracted"
            return 0
        fi
    fi

    # フォールバック: 通常テキスト生成 → 従来方式パース
    JFE_FALLBACK_COUNT=$((JFE_FALLBACK_COUNT + 1))

    if type -t cb2_call &>/dev/null && [[ "${ENABLE_CLAUDE_BRIDGE:-true}" == "true" ]]; then
        result=$(cb2_call "$prompt" "" "$phase" 2>/dev/null || echo "")
    elif type -t _call_claude &>/dev/null; then
        result=$(_call_claude "$prompt" "" "$phase" 2>/dev/null || echo "")
    fi

    if [[ -n "$result" ]]; then
        # 従来のマーカーベースパース
        jfe_parse_marker_output "$result" "$project_dir"
    fi
}

# ============================================================
# JSON出力パース → ファイル書き込み
# ============================================================
jfe_parse_json_output() {
    local json_output="$1"
    local project_dir="${2:-.}"

    # jqが利用可能かチェック
    if ! command -v jq &>/dev/null; then
        # jqなし: Python fallback
        if command -v python3 &>/dev/null; then
            jfe_parse_json_with_python "$json_output" "$project_dir"
            return $?
        fi
        return 1
    fi

    # JSON妥当性チェック
    if ! echo "$json_output" | jq empty 2>/dev/null; then
        # JSONの部分抽出を試みる（Claude出力にJSONが埋まっている場合）
        local extracted_json
        extracted_json=$(echo "$json_output" | grep -oP '\{[\s\S]*"files"[\s\S]*\}' 2>/dev/null | head -1)
        if [[ -n "$extracted_json" ]] && echo "$extracted_json" | jq empty 2>/dev/null; then
            json_output="$extracted_json"
        else
            return 1
        fi
    fi

    # ファイル抽出
    local file_count
    file_count=$(echo "$json_output" | jq '.files | length' 2>/dev/null || echo "0")

    if [[ "$file_count" -eq 0 ]]; then
        return 1
    fi

    local files_written=0

    for ((i=0; i<file_count; i++)); do
        local file_path
        file_path=$(echo "$json_output" | jq -r ".files[$i].path" 2>/dev/null || echo "")
        local file_content
        file_content=$(echo "$json_output" | jq -r ".files[$i].content" 2>/dev/null || echo "")

        [[ -z "$file_path" || -z "$file_content" ]] && continue

        # パストラバーサル防止
        if echo "$file_path" | grep -qE '^\.\.|\.\./' 2>/dev/null; then
            echo -e "  ${RED:-}[JFE] パストラバーサル検出: ${file_path} → スキップ${NC:-}" >&2
            continue
        fi

        # ファイル書き込み
        local full_path="${project_dir}/${file_path}"
        mkdir -p "$(dirname "$full_path")" 2>/dev/null || true
        printf '%s\n' "$file_content" > "$full_path"

        files_written=$((files_written + 1))
        echo -e "  ${GREEN:-}[JFE] ✅ ${file_path}${NC:-}" >&2
    done

    JFE_FILES_EXTRACTED=$((JFE_FILES_EXTRACTED + files_written))
    echo "extracted:${files_written}"
    return 0
}

# ============================================================
# Python fallback for JSON parsing (jq不要)
# ============================================================
jfe_parse_json_with_python() {
    local json_output="$1"
    local project_dir="${2:-.}"

    local result
    result=$(python3 -c "
import json, sys, os

try:
    data = json.loads(sys.stdin.read())
except:
    sys.exit(1)

files = data.get('files', [])
count = 0

for f in files:
    path = f.get('path', '')
    content = f.get('content', '')
    if not path or not content:
        continue
    if '..' in path:
        continue

    full_path = os.path.join('${project_dir}', path)
    os.makedirs(os.path.dirname(full_path), exist_ok=True)
    with open(full_path, 'w') as fp:
        fp.write(content)
    count += 1
    print(f'  ✅ {path}', file=sys.stderr)

print(f'extracted:{count}')
" <<< "$json_output" 2>/dev/null)

    if [[ -n "$result" ]]; then
        local count
        count=$(echo "$result" | grep -oP 'extracted:\K\d+' 2>/dev/null || echo "0")
        JFE_FILES_EXTRACTED=$((JFE_FILES_EXTRACTED + count))
        echo "$result"
        return 0
    fi
    return 1
}

# ============================================================
# 従来マーカーベースパース（フォールバック）
# --- FILE: path --- 形式
# ============================================================
jfe_parse_marker_output() {
    local text_output="$1"
    local project_dir="${2:-.}"

    local files_written=0
    local current_path=""
    local current_content=""
    local in_file=false

    while IFS= read -r line; do
        # ファイルマーカー検出
        if echo "$line" | grep -qE '^---\s*FILE:\s*(.+)\s*---' 2>/dev/null; then
            # 前のファイルを保存
            if [[ "$in_file" == "true" && -n "$current_path" ]]; then
                _jfe_write_file "$project_dir" "$current_path" "$current_content"
                files_written=$((files_written + 1))
            fi

            current_path=$(echo "$line" | sed -E 's/^---\s*FILE:\s*(.+)\s*---$/\1/' | xargs)
            current_content=""
            in_file=true
            continue
        fi

        # END FILE マーカー
        if echo "$line" | grep -qE '^---\s*END FILE\s*---' 2>/dev/null; then
            if [[ "$in_file" == "true" && -n "$current_path" ]]; then
                _jfe_write_file "$project_dir" "$current_path" "$current_content"
                files_written=$((files_written + 1))
            fi
            in_file=false
            current_path=""
            current_content=""
            continue
        fi

        # ファイル内容蓄積
        if [[ "$in_file" == "true" ]]; then
            current_content+="${line}
"
        fi
    done <<< "$text_output"

    # 最後のファイル
    if [[ "$in_file" == "true" && -n "$current_path" && -n "$current_content" ]]; then
        _jfe_write_file "$project_dir" "$current_path" "$current_content"
        files_written=$((files_written + 1))
    fi

    JFE_FILES_EXTRACTED=$((JFE_FILES_EXTRACTED + files_written))
    echo "extracted:${files_written}"
}

# --- ファイル書き込みヘルパー ---
_jfe_write_file() {
    local project_dir="$1"
    local file_path="$2"
    local content="$3"

    # パストラバーサル防止
    if echo "$file_path" | grep -qE '^\.\.|\.\./' 2>/dev/null; then
        return 1
    fi

    local full_path="${project_dir}/${file_path}"
    mkdir -p "$(dirname "$full_path")" 2>/dev/null || true
    printf '%s' "$content" > "$full_path"
    echo -e "  ${GREEN:-}[JFE] ✅ ${file_path}${NC:-}" >&2
}

# ============================================================
# レポート
# ============================================================
jfe_report() {
    echo -e "\n  ${BOLD:-}═══ JSON File Extractor v57.0 レポート ═══${NC:-}"
    echo -e "  抽出実行回数     : ${JFE_EXTRACT_COUNT}"
    echo -e "  抽出ファイル数   : ${JFE_FILES_EXTRACTED}"
    echo -e "  フォールバック回数: ${JFE_FALLBACK_COUNT}"
}

jfe_report_json() {
    cat <<EOF
{"module":"json-file-extractor","version":"${JFE_VERSION}","extractions":${JFE_EXTRACT_COUNT},"files":${JFE_FILES_EXTRACTED},"fallbacks":${JFE_FALLBACK_COUNT}}
EOF
}

jfe_score() {
    if [[ $JFE_EXTRACT_COUNT -eq 0 ]]; then
        echo "50"
    elif [[ $JFE_FALLBACK_COUNT -eq 0 ]]; then
        echo "100"
    else
        local success_rate=$(( (JFE_EXTRACT_COUNT - JFE_FALLBACK_COUNT) * 100 / JFE_EXTRACT_COUNT ))
        echo "$success_rate"
    fi
}

# ============================================================
# v59.0: Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "json-file-extractor" \
        --version "57.0" \
        --description "--json-schema構造化抽出×regexフォールバック" \
        --init "jfe_init" \
        --report "jfe_report" \
        --score "jfe_score" \
        --enable-var "ENABLE_JSON_EXTRACTOR" \
        --cli-flags "--json-extractor:--no-json-extractor"
fi

# v2003.1: source時のexit codeを確実に0にする
true
