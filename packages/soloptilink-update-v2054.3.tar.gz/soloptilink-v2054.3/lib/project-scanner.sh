#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v201.0 - Project Scanner
# =============================================================================
# プロジェクト構造スキャン×テックスタック検出×設定ファイル発見×要約生成
#
# 機能:
#   - ディレクトリ構造マッピング
#   - テックスタック自動検出（フレームワーク/言語/DB/ツール）
#   - package.json 依存関係解析
#   - 設定ファイル発見（tsconfig/next.config/prisma/docker等）
#   - プロジェクトJSON要約生成
#   - プロジェクト規模（ファイル数/行数）計測
#   - モノレポ検出
#
# 全globals: PS_ prefix
# =============================================================================

[[ -n "${_PS_LOADED:-}" ]] && return 0; _PS_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g PS_VERSION="201.0"
declare -g PS_INITIALIZED=false
declare -g PS_SCAN_COUNT=0
declare -g PS_ERRORS=0
declare -g PS_PHASE="project_scanner"
declare -g PS_STORAGE_DIR="${HOME}/.soloptilink/project-scanner"

# Detected state
declare -g PS_PROJECT_DIR=""
declare -g PS_PROJECT_NAME=""
declare -g PS_DETECTED_FRAMEWORKS=""
declare -g PS_DETECTED_LANGUAGES=""
declare -g PS_DETECTED_DATABASES=""
declare -g PS_DETECTED_TOOLS=""
declare -g PS_TOTAL_FILES=0
declare -g PS_TOTAL_LINES=0
declare -g PS_IS_MONOREPO=false
declare -g PS_CONFIG_FILES=""

# Color codes (fallback if not loaded)
declare -g PS_GREEN="${GREEN:-\033[0;32m}"
declare -g PS_YELLOW="${YELLOW:-\033[1;33m}"
declare -g PS_RED="${RED:-\033[0;31m}"
declare -g PS_CYAN="${CYAN:-\033[0;36m}"
declare -g PS_BOLD="${BOLD:-\033[1m}"
declare -g PS_NC="${NC:-\033[0m}"

# =============================================================================
# 初期化
# =============================================================================
ps_init() {
    PS_INITIALIZED=true
    PS_SCAN_COUNT=0
    PS_ERRORS=0
    PS_DETECTED_FRAMEWORKS=""
    PS_DETECTED_LANGUAGES=""
    PS_DETECTED_DATABASES=""
    PS_DETECTED_TOOLS=""
    PS_TOTAL_FILES=0
    PS_TOTAL_LINES=0
    PS_IS_MONOREPO=false
    PS_CONFIG_FILES=""
    mkdir -p "${PS_STORAGE_DIR}" 2>/dev/null
    return 0
}

# =============================================================================
# ユーティリティ: ログ
# =============================================================================
_ps_log() {
    local level="$1"
    shift
    local msg="$*"
    case "$level" in
        info)  echo -e "  ${PS_CYAN}[project-scanner]${PS_NC} ${msg}" >&2 ;;
        ok)    echo -e "  ${PS_GREEN}[project-scanner]${PS_NC} ${msg}" >&2 ;;
        warn)  echo -e "  ${PS_YELLOW}[project-scanner]${PS_NC} ${msg}" >&2 ;;
        error) echo -e "  ${PS_RED}[project-scanner]${PS_NC} ${msg}" >&2; PS_ERRORS=$((PS_ERRORS + 1)) ;;
    esac
}

# =============================================================================
# ディレクトリ構造マッピング
# =============================================================================
_ps_map_directory_structure() {
    local project_dir="$1"
    local max_depth="${2:-4}"
    local output_file="${PS_STORAGE_DIR}/directory-structure.txt"

    if [[ ! -d "$project_dir" ]]; then
        _ps_log error "Directory not found: ${project_dir}"
        return 1
    fi

    # Build directory tree, excluding common noise
    local tree_output=""
    tree_output=$(find "$project_dir" -maxdepth "$max_depth" \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        -not -path "*/.git/*" \
        -not -path "*/dist/*" \
        -not -path "*/build/*" \
        -not -path "*/.cache/*" \
        -not -path "*/__pycache__/*" \
        -not -path "*/.turbo/*" \
        -not -path "*/.vercel/*" \
        -type d 2>/dev/null | sort)

    echo "$tree_output" > "$output_file" 2>/dev/null
    _ps_log info "Mapped directory structure (depth=${max_depth})"
    echo "$tree_output"
}

# =============================================================================
# 設定ファイル発見
# =============================================================================
_ps_find_config_files() {
    local project_dir="$1"
    local configs=""

    # Known config file patterns
    local config_patterns=(
        "package.json"
        "tsconfig.json"
        "tsconfig.*.json"
        "next.config.js"
        "next.config.mjs"
        "next.config.ts"
        "vite.config.ts"
        "vite.config.js"
        "vue.config.js"
        "nuxt.config.ts"
        "nuxt.config.js"
        "angular.json"
        "svelte.config.js"
        "astro.config.mjs"
        "remix.config.js"
        "tailwind.config.js"
        "tailwind.config.ts"
        "postcss.config.js"
        "postcss.config.mjs"
        "prisma/schema.prisma"
        "drizzle.config.ts"
        "docker-compose.yml"
        "docker-compose.yaml"
        "Dockerfile"
        ".env"
        ".env.local"
        ".env.example"
        ".eslintrc.js"
        ".eslintrc.json"
        "eslint.config.js"
        ".prettierrc"
        ".prettierrc.json"
        "prettier.config.js"
        "jest.config.js"
        "jest.config.ts"
        "vitest.config.ts"
        "playwright.config.ts"
        "cypress.config.ts"
        ".github/workflows/*.yml"
        "vercel.json"
        "netlify.toml"
        "fly.toml"
        "wrangler.toml"
        "turbo.json"
        "pnpm-workspace.yaml"
        "lerna.json"
        "nx.json"
        "Cargo.toml"
        "go.mod"
        "requirements.txt"
        "pyproject.toml"
        "Gemfile"
        "build.gradle"
        "pom.xml"
    )

    for pattern in "${config_patterns[@]}"; do
        local found
        found=$(find "$project_dir" -maxdepth 3 -path "*/${pattern}" \
            -not -path "*/node_modules/*" \
            -not -path "*/.next/*" \
            -not -path "*/.git/*" 2>/dev/null | head -5)
        if [[ -n "$found" ]]; then
            while IFS= read -r f; do
                [[ -z "$f" ]] && continue
                local rel="${f#${project_dir}/}"
                configs+="${rel}\n"
            done <<< "$found"
        fi
    done

    PS_CONFIG_FILES=$(echo -e "$configs" | sort -u | grep -v '^$')
    echo "$PS_CONFIG_FILES"
}

# =============================================================================
# package.json 解析
# =============================================================================
_ps_parse_package_json() {
    local pkg_file="$1"

    if [[ ! -f "$pkg_file" ]]; then
        return 1
    fi

    local deps=""
    local dev_deps=""
    local scripts=""
    local name=""

    # Extract name
    name=$(grep -oE '"name"\s*:\s*"[^"]*"' "$pkg_file" 2>/dev/null | head -1 | sed 's/.*: *"//;s/"//')

    # Extract dependencies using grep/sed (no jq dependency)
    # Simple approach: extract keys from dependencies and devDependencies blocks
    local in_deps=false
    local in_dev_deps=false
    local in_scripts=false
    local brace_depth=0

    while IFS= read -r line; do
        # Detect section starts
        if [[ "$line" =~ \"dependencies\"[[:space:]]*: ]]; then
            in_deps=true; in_dev_deps=false; in_scripts=false; brace_depth=0; continue
        fi
        if [[ "$line" =~ \"devDependencies\"[[:space:]]*: ]]; then
            in_dev_deps=true; in_deps=false; in_scripts=false; brace_depth=0; continue
        fi
        if [[ "$line" =~ \"scripts\"[[:space:]]*: ]]; then
            in_scripts=true; in_deps=false; in_dev_deps=false; brace_depth=0; continue
        fi

        # Track braces
        if [[ "$line" =~ \{ ]]; then
            brace_depth=$((brace_depth + 1))
        fi
        if [[ "$line" =~ \} ]]; then
            brace_depth=$((brace_depth - 1))
            if [[ $brace_depth -le 0 ]]; then
                in_deps=false; in_dev_deps=false; in_scripts=false
            fi
            continue
        fi

        # Extract package names
        local pkg_name=""
        if [[ "$line" =~ \"([^\"]+)\"[[:space:]]*: ]]; then
            pkg_name="${BASH_REMATCH[1]}"
        fi
        [[ -z "$pkg_name" ]] && continue

        if [[ "$in_deps" == "true" ]]; then
            deps+="${pkg_name}\n"
        elif [[ "$in_dev_deps" == "true" ]]; then
            dev_deps+="${pkg_name}\n"
        elif [[ "$in_scripts" == "true" ]]; then
            scripts+="${pkg_name}\n"
        fi
    done < "$pkg_file"

    # Output as structured text
    echo "NAME:${name}"
    echo "DEPS:$(echo -e "$deps" | grep -v '^$' | tr '\n' ',' | sed 's/,$//')"
    echo "DEV_DEPS:$(echo -e "$dev_deps" | grep -v '^$' | tr '\n' ',' | sed 's/,$//')"
    echo "SCRIPTS:$(echo -e "$scripts" | grep -v '^$' | tr '\n' ',' | sed 's/,$//')"
}

# =============================================================================
# テックスタック検出
# =============================================================================
_ps_detect_tech_stack() {
    local project_dir="${1:-${PS_PROJECT_DIR:-./output}}"

    local frameworks=""
    local languages=""
    local databases=""
    local tools=""

    # --- Framework Detection ---
    # Check package.json dependencies
    local pkg_file="${project_dir}/package.json"
    local all_deps=""
    if [[ -f "$pkg_file" ]]; then
        all_deps=$(grep -oE '"[^"]+"\s*:\s*"[^"]*"' "$pkg_file" 2>/dev/null | sed 's/\s*:.*//' | tr -d '"')
    fi

    # Next.js
    if echo "$all_deps" | grep -q "^next$" 2>/dev/null || [[ -f "${project_dir}/next.config.js" ]] || [[ -f "${project_dir}/next.config.mjs" ]] || [[ -f "${project_dir}/next.config.ts" ]]; then
        frameworks+="Next.js,"
    fi

    # React (standalone)
    if echo "$all_deps" | grep -q "^react$" 2>/dev/null; then
        frameworks+="React,"
    fi

    # Vue.js
    if echo "$all_deps" | grep -q "^vue$" 2>/dev/null || [[ -f "${project_dir}/vue.config.js" ]]; then
        frameworks+="Vue.js,"
    fi

    # Nuxt
    if echo "$all_deps" | grep -q "^nuxt$" 2>/dev/null || [[ -f "${project_dir}/nuxt.config.ts" ]]; then
        frameworks+="Nuxt,"
    fi

    # Angular
    if echo "$all_deps" | grep -q "^@angular/core$" 2>/dev/null || [[ -f "${project_dir}/angular.json" ]]; then
        frameworks+="Angular,"
    fi

    # Svelte / SvelteKit
    if echo "$all_deps" | grep -q "^svelte$" 2>/dev/null || [[ -f "${project_dir}/svelte.config.js" ]]; then
        frameworks+="Svelte,"
    fi

    # Astro
    if echo "$all_deps" | grep -q "^astro$" 2>/dev/null || [[ -f "${project_dir}/astro.config.mjs" ]]; then
        frameworks+="Astro,"
    fi

    # Remix
    if echo "$all_deps" | grep -q "^@remix-run" 2>/dev/null || [[ -f "${project_dir}/remix.config.js" ]]; then
        frameworks+="Remix,"
    fi

    # Express
    if echo "$all_deps" | grep -q "^express$" 2>/dev/null; then
        frameworks+="Express,"
    fi

    # Fastify
    if echo "$all_deps" | grep -q "^fastify$" 2>/dev/null; then
        frameworks+="Fastify,"
    fi

    # NestJS
    if echo "$all_deps" | grep -q "^@nestjs/core$" 2>/dev/null; then
        frameworks+="NestJS,"
    fi

    # Hono
    if echo "$all_deps" | grep -q "^hono$" 2>/dev/null; then
        frameworks+="Hono,"
    fi

    # Django / Flask / FastAPI (Python)
    if [[ -f "${project_dir}/requirements.txt" ]] || [[ -f "${project_dir}/pyproject.toml" ]]; then
        local py_deps=""
        [[ -f "${project_dir}/requirements.txt" ]] && py_deps=$(cat "${project_dir}/requirements.txt" 2>/dev/null)
        [[ -f "${project_dir}/pyproject.toml" ]] && py_deps+=$(cat "${project_dir}/pyproject.toml" 2>/dev/null)
        echo "$py_deps" | grep -qi "django" && frameworks+="Django,"
        echo "$py_deps" | grep -qi "flask" && frameworks+="Flask,"
        echo "$py_deps" | grep -qi "fastapi" && frameworks+="FastAPI,"
    fi

    # Rails (Ruby)
    if [[ -f "${project_dir}/Gemfile" ]]; then
        grep -qi "rails" "${project_dir}/Gemfile" 2>/dev/null && frameworks+="Rails,"
    fi

    # Vite (build tool, but commonly listed)
    if echo "$all_deps" | grep -q "^vite$" 2>/dev/null || [[ -f "${project_dir}/vite.config.ts" ]]; then
        tools+="Vite,"
    fi

    # --- Language Detection ---
    local ts_count=0
    local js_count=0
    local py_count=0
    local go_count=0
    local rs_count=0
    local rb_count=0
    local java_count=0

    ts_count=$(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" \) -not -path "*/node_modules/*" -not -path "*/.next/*" -not -path "*/dist/*" 2>/dev/null | head -500 | wc -l | tr -d ' ')
    js_count=$(find "$project_dir" \( -name "*.js" -o -name "*.jsx" \) -not -path "*/node_modules/*" -not -path "*/.next/*" -not -path "*/dist/*" 2>/dev/null | head -500 | wc -l | tr -d ' ')
    py_count=$(find "$project_dir" -name "*.py" -not -path "*/node_modules/*" -not -path "*/__pycache__/*" 2>/dev/null | head -500 | wc -l | tr -d ' ')
    go_count=$(find "$project_dir" -name "*.go" -not -path "*/vendor/*" 2>/dev/null | head -500 | wc -l | tr -d ' ')
    rs_count=$(find "$project_dir" -name "*.rs" -not -path "*/target/*" 2>/dev/null | head -500 | wc -l | tr -d ' ')
    rb_count=$(find "$project_dir" -name "*.rb" -not -path "*/vendor/*" 2>/dev/null | head -500 | wc -l | tr -d ' ')
    java_count=$(find "$project_dir" \( -name "*.java" -o -name "*.kt" \) -not -path "*/build/*" 2>/dev/null | head -500 | wc -l | tr -d ' ')

    [[ $ts_count -gt 0 ]] && languages+="TypeScript(${ts_count}),"
    [[ $js_count -gt 0 ]] && languages+="JavaScript(${js_count}),"
    [[ $py_count -gt 0 ]] && languages+="Python(${py_count}),"
    [[ $go_count -gt 0 ]] && languages+="Go(${go_count}),"
    [[ $rs_count -gt 0 ]] && languages+="Rust(${rs_count}),"
    [[ $rb_count -gt 0 ]] && languages+="Ruby(${rb_count}),"
    [[ $java_count -gt 0 ]] && languages+="Java/Kotlin(${java_count}),"

    # Shell scripts
    local sh_count=0
    sh_count=$(find "$project_dir" -name "*.sh" -not -path "*/node_modules/*" 2>/dev/null | head -500 | wc -l | tr -d ' ')
    [[ $sh_count -gt 0 ]] && languages+="Shell(${sh_count}),"

    # --- Database Detection ---
    # Prisma
    if find "$project_dir" -name "schema.prisma" -not -path "*/node_modules/*" 2>/dev/null | grep -q .; then
        local prisma_provider=""
        prisma_provider=$(grep -oE 'provider\s*=\s*"[^"]*"' "$(find "$project_dir" -name "schema.prisma" -not -path "*/node_modules/*" 2>/dev/null | head -1)" 2>/dev/null | head -1 | sed 's/.*"//;s/"//')
        databases+="Prisma,"
        case "$prisma_provider" in
            postgresql) databases+="PostgreSQL," ;;
            mysql) databases+="MySQL," ;;
            sqlite) databases+="SQLite," ;;
            mongodb) databases+="MongoDB," ;;
            sqlserver) databases+="SQLServer," ;;
        esac
    fi

    # Drizzle
    if echo "$all_deps" | grep -q "^drizzle-orm$" 2>/dev/null; then
        databases+="Drizzle,"
    fi

    # Mongoose / MongoDB
    if echo "$all_deps" | grep -q "^mongoose$" 2>/dev/null; then
        databases+="MongoDB,"
    fi

    # Redis
    if echo "$all_deps" | grep -qE "^(redis|ioredis)$" 2>/dev/null; then
        databases+="Redis,"
    fi

    # Supabase
    if echo "$all_deps" | grep -q "^@supabase" 2>/dev/null; then
        databases+="Supabase,"
    fi

    # Firebase
    if echo "$all_deps" | grep -q "^firebase" 2>/dev/null; then
        databases+="Firebase,"
    fi

    # --- Tools Detection ---
    # Tailwind
    if echo "$all_deps" | grep -q "^tailwindcss$" 2>/dev/null || [[ -f "${project_dir}/tailwind.config.js" ]] || [[ -f "${project_dir}/tailwind.config.ts" ]]; then
        tools+="TailwindCSS,"
    fi

    # ESLint
    if echo "$all_deps" | grep -q "^eslint$" 2>/dev/null || [[ -f "${project_dir}/.eslintrc.js" ]] || [[ -f "${project_dir}/.eslintrc.json" ]] || [[ -f "${project_dir}/eslint.config.js" ]]; then
        tools+="ESLint,"
    fi

    # Prettier
    if echo "$all_deps" | grep -q "^prettier$" 2>/dev/null || [[ -f "${project_dir}/.prettierrc" ]] || [[ -f "${project_dir}/.prettierrc.json" ]]; then
        tools+="Prettier,"
    fi

    # Docker
    if [[ -f "${project_dir}/Dockerfile" ]] || [[ -f "${project_dir}/docker-compose.yml" ]] || [[ -f "${project_dir}/docker-compose.yaml" ]]; then
        tools+="Docker,"
    fi

    # CI/CD
    if [[ -d "${project_dir}/.github/workflows" ]]; then
        tools+="GitHubActions,"
    fi

    # Testing
    if echo "$all_deps" | grep -q "^jest$" 2>/dev/null; then
        tools+="Jest,"
    fi
    if echo "$all_deps" | grep -q "^vitest$" 2>/dev/null; then
        tools+="Vitest,"
    fi
    if echo "$all_deps" | grep -q "^@playwright" 2>/dev/null || [[ -f "${project_dir}/playwright.config.ts" ]]; then
        tools+="Playwright,"
    fi
    if echo "$all_deps" | grep -q "^cypress$" 2>/dev/null || [[ -f "${project_dir}/cypress.config.ts" ]]; then
        tools+="Cypress,"
    fi

    # Monorepo detection
    if [[ -f "${project_dir}/turbo.json" ]] || [[ -f "${project_dir}/pnpm-workspace.yaml" ]] || [[ -f "${project_dir}/lerna.json" ]] || [[ -f "${project_dir}/nx.json" ]]; then
        PS_IS_MONOREPO=true
        tools+="Monorepo,"
    fi

    # Package manager
    if [[ -f "${project_dir}/pnpm-lock.yaml" ]]; then
        tools+="pnpm,"
    elif [[ -f "${project_dir}/yarn.lock" ]]; then
        tools+="Yarn,"
    elif [[ -f "${project_dir}/package-lock.json" ]]; then
        tools+="npm,"
    elif [[ -f "${project_dir}/bun.lockb" ]]; then
        tools+="Bun,"
    fi

    # Remove trailing commas and deduplicate
    PS_DETECTED_FRAMEWORKS=$(echo "$frameworks" | tr ',' '\n' | sort -u | grep -v '^$' | tr '\n' ',' | sed 's/,$//')
    PS_DETECTED_LANGUAGES=$(echo "$languages" | tr ',' '\n' | sort -u | grep -v '^$' | tr '\n' ',' | sed 's/,$//')
    PS_DETECTED_DATABASES=$(echo "$databases" | tr ',' '\n' | sort -u | grep -v '^$' | tr '\n' ',' | sed 's/,$//')
    PS_DETECTED_TOOLS=$(echo "$tools" | tr ',' '\n' | sort -u | grep -v '^$' | tr '\n' ',' | sed 's/,$//')

    _ps_log ok "Frameworks: ${PS_DETECTED_FRAMEWORKS:-none}"
    _ps_log ok "Languages: ${PS_DETECTED_LANGUAGES:-none}"
    _ps_log ok "Databases: ${PS_DETECTED_DATABASES:-none}"
    _ps_log ok "Tools: ${PS_DETECTED_TOOLS:-none}"
}

# =============================================================================
# プロジェクト規模計測
# =============================================================================
_ps_measure_project_size() {
    local project_dir="$1"

    PS_TOTAL_FILES=$(find "$project_dir" -type f \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        -not -path "*/.git/*" \
        -not -path "*/dist/*" \
        -not -path "*/build/*" \
        -not -path "*/__pycache__/*" \
        -not -path "*/target/*" \
        2>/dev/null | wc -l | tr -d ' ')

    # Count lines of code (source files only)
    PS_TOTAL_LINES=0
    local line_count
    line_count=$(find "$project_dir" \
        \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \
           -o -name "*.py" -o -name "*.go" -o -name "*.rs" -o -name "*.rb" \
           -o -name "*.sh" -o -name "*.java" -o -name "*.kt" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        -not -path "*/dist/*" \
        -not -path "*/build/*" \
        2>/dev/null | head -1000 | xargs wc -l 2>/dev/null | tail -1 | awk '{print $1}')

    PS_TOTAL_LINES="${line_count:-0}"

    _ps_log info "Project size: ${PS_TOTAL_FILES} files, ${PS_TOTAL_LINES} lines of code"
}

# =============================================================================
# モノレポワークスペース検出
# =============================================================================
_ps_detect_workspaces() {
    local project_dir="$1"
    local workspaces=""

    # pnpm workspaces
    if [[ -f "${project_dir}/pnpm-workspace.yaml" ]]; then
        while IFS= read -r line; do
            [[ "$line" =~ ^[[:space:]]*-[[:space:]]*[\'\"]?([^\'\"]+) ]] && workspaces+="${BASH_REMATCH[1]}\n"
        done < "${project_dir}/pnpm-workspace.yaml"
    fi

    # npm/yarn workspaces from package.json
    if [[ -f "${project_dir}/package.json" ]]; then
        local in_workspaces=false
        while IFS= read -r line; do
            if [[ "$line" =~ \"workspaces\" ]]; then
                in_workspaces=true; continue
            fi
            if [[ "$in_workspaces" == "true" ]]; then
                if [[ "$line" =~ \] ]]; then
                    in_workspaces=false; continue
                fi
                if [[ "$line" =~ \"([^\"]+)\" ]]; then
                    workspaces+="${BASH_REMATCH[1]}\n"
                fi
            fi
        done < "${project_dir}/package.json"
    fi

    # Detect actual workspace directories
    local found_workspaces=""
    while IFS= read -r ws_pattern; do
        [[ -z "$ws_pattern" ]] && continue
        # Resolve glob patterns
        local ws_dirs
        ws_dirs=$(find "$project_dir" -maxdepth 2 -path "${project_dir}/${ws_pattern}/package.json" 2>/dev/null | while read -r f; do dirname "$f"; done)
        while IFS= read -r ws_dir; do
            [[ -z "$ws_dir" ]] && continue
            local ws_name
            ws_name=$(basename "$ws_dir")
            found_workspaces+="${ws_name}\n"
        done <<< "$ws_dirs"
    done < <(echo -e "$workspaces" | grep -v '^$')

    echo -e "$found_workspaces" | sort -u | grep -v '^$'
}

# =============================================================================
# メインスキャン関数
# =============================================================================
_ps_scan_project() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    PS_PROJECT_DIR="$project_dir"

    if [[ ! -d "$project_dir" ]]; then
        _ps_log error "Project directory not found: ${project_dir}"
        return 1
    fi

    PS_PROJECT_NAME=$(basename "$project_dir")
    _ps_log info "Scanning project: ${PS_PROJECT_NAME} (${project_dir})"

    # Step 1: Map directory structure
    _ps_map_directory_structure "$project_dir" 4 >/dev/null 2>&1

    # Step 2: Find config files
    _ps_find_config_files "$project_dir" >/dev/null 2>&1

    # Step 3: Detect tech stack
    _ps_detect_tech_stack "$project_dir"

    # Step 4: Measure project size
    _ps_measure_project_size "$project_dir"

    # Step 5: Detect workspaces if monorepo
    local workspaces=""
    if [[ "$PS_IS_MONOREPO" == "true" ]]; then
        workspaces=$(_ps_detect_workspaces "$project_dir")
        _ps_log info "Workspaces: $(echo "$workspaces" | tr '\n' ', ' | sed 's/,$//')"
    fi

    PS_SCAN_COUNT=$((PS_SCAN_COUNT + 1))
    _ps_log ok "Scan complete: ${PS_TOTAL_FILES} files, ${PS_TOTAL_LINES} LOC"
    return 0
}

# =============================================================================
# プロジェクト要約JSON生成
# =============================================================================
_ps_get_project_summary() {
    local project_dir="${1:-${PS_PROJECT_DIR:-./output}}"
    local output_file="${PS_STORAGE_DIR}/project-summary.json"

    # Auto-scan if not done yet
    if [[ "$PS_SCAN_COUNT" -eq 0 ]] || [[ "$PS_PROJECT_DIR" != "$project_dir" ]]; then
        _ps_scan_project "$project_dir" 2>/dev/null
    fi

    # Build config files JSON array
    local configs_json="["
    local first=true
    while IFS= read -r cfg; do
        [[ -z "$cfg" ]] && continue
        [[ "$first" == "true" ]] && first=false || configs_json+=","
        configs_json+="\"${cfg}\""
    done <<< "$PS_CONFIG_FILES"
    configs_json+="]"

    # Build frameworks array
    local fw_json="["
    first=true
    IFS=',' read -ra fw_arr <<< "$PS_DETECTED_FRAMEWORKS"
    for fw in "${fw_arr[@]}"; do
        [[ -z "$fw" ]] && continue
        [[ "$first" == "true" ]] && first=false || fw_json+=","
        fw_json+="\"${fw}\""
    done
    fw_json+="]"

    # Build languages array
    local lang_json="["
    first=true
    IFS=',' read -ra lang_arr <<< "$PS_DETECTED_LANGUAGES"
    for lang in "${lang_arr[@]}"; do
        [[ -z "$lang" ]] && continue
        [[ "$first" == "true" ]] && first=false || lang_json+=","
        lang_json+="\"${lang}\""
    done
    lang_json+="]"

    # Build databases array
    local db_json="["
    first=true
    IFS=',' read -ra db_arr <<< "$PS_DETECTED_DATABASES"
    for db in "${db_arr[@]}"; do
        [[ -z "$db" ]] && continue
        [[ "$first" == "true" ]] && first=false || db_json+=","
        db_json+="\"${db}\""
    done
    db_json+="]"

    # Build tools array
    local tools_json="["
    first=true
    IFS=',' read -ra tools_arr <<< "$PS_DETECTED_TOOLS"
    for tool in "${tools_arr[@]}"; do
        [[ -z "$tool" ]] && continue
        [[ "$first" == "true" ]] && first=false || tools_json+=","
        tools_json+="\"${tool}\""
    done
    tools_json+="]"

    # Detect entry points
    local entry_points="["
    first=true
    for ep in "app/page.tsx" "app/page.ts" "src/app/page.tsx" "src/index.ts" "src/index.tsx" \
              "src/main.ts" "src/main.tsx" "index.ts" "index.js" "main.go" "main.py" "app.py"; do
        if [[ -f "${project_dir}/${ep}" ]]; then
            [[ "$first" == "true" ]] && first=false || entry_points+=","
            entry_points+="\"${ep}\""
        fi
    done
    entry_points+="]"

    local json
    json=$(cat <<EOF
{
  "name": "${PS_PROJECT_NAME}",
  "path": "${project_dir}",
  "scannedAt": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "isMonorepo": ${PS_IS_MONOREPO},
  "size": {
    "totalFiles": ${PS_TOTAL_FILES},
    "totalLines": ${PS_TOTAL_LINES}
  },
  "techStack": {
    "frameworks": ${fw_json},
    "languages": ${lang_json},
    "databases": ${db_json},
    "tools": ${tools_json}
  },
  "configFiles": ${configs_json},
  "entryPoints": ${entry_points},
  "errors": ${PS_ERRORS}
}
EOF
)
    echo "$json" > "$output_file" 2>/dev/null
    echo "$json"
}

# =============================================================================
# Claude プロンプト注入用コンテキスト
# =============================================================================
_ps_inject_context() {
    local project_dir="${1:-${PS_PROJECT_DIR:-./output}}"

    # Auto-scan if needed
    if [[ "$PS_SCAN_COUNT" -eq 0 ]]; then
        _ps_scan_project "$project_dir" 2>/dev/null
    fi

    cat <<CONTEXT
## [Project Scanner] プロジェクト構造コンテキスト

### プロジェクト名: ${PS_PROJECT_NAME:-unknown}
### テックスタック:
- フレームワーク: ${PS_DETECTED_FRAMEWORKS:-未検出}
- 言語: ${PS_DETECTED_LANGUAGES:-未検出}
- データベース: ${PS_DETECTED_DATABASES:-未検出}
- ツール: ${PS_DETECTED_TOOLS:-未検出}

### 規模:
- ファイル数: ${PS_TOTAL_FILES}
- コード行数: ${PS_TOTAL_LINES}
- モノレポ: ${PS_IS_MONOREPO}

### 設定ファイル:
${PS_CONFIG_FILES:-未検出}

### ルール:
1. 検出されたフレームワークの規約に従ってコード生成すること
2. 既存の技術スタックと互換性のある依存を選択すること
3. プロジェクト規模に応じた設計を行うこと
CONTEXT
}

# =============================================================================
# レポート & スコア
# =============================================================================
ps_report() {
    echo -e "\n  ${PS_BOLD}=== project-scanner v${PS_VERSION} ===${PS_NC}"
    echo -e "  スキャン回数: ${PS_SCAN_COUNT}"
    echo -e "  エラー: ${PS_ERRORS}"
    if [[ "$PS_SCAN_COUNT" -gt 0 ]]; then
        echo -e "  プロジェクト: ${PS_PROJECT_NAME}"
        echo -e "  フレームワーク: ${PS_DETECTED_FRAMEWORKS:-none}"
        echo -e "  言語: ${PS_DETECTED_LANGUAGES:-none}"
        echo -e "  データベース: ${PS_DETECTED_DATABASES:-none}"
        echo -e "  ツール: ${PS_DETECTED_TOOLS:-none}"
        echo -e "  ファイル数: ${PS_TOTAL_FILES}"
        echo -e "  コード行数: ${PS_TOTAL_LINES}"
        echo -e "  モノレポ: ${PS_IS_MONOREPO}"
    fi
}

ps_score() {
    if [[ ${PS_SCAN_COUNT} -ge 1 ]] && [[ ${PS_ERRORS} -eq 0 ]]; then
        echo "95"
    elif [[ ${PS_SCAN_COUNT} -gt 0 ]]; then
        echo "80"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "project-scanner" --version "201.0" \
        --description "プロジェクト構造スキャン×テックスタック検出×設定ファイル発見" \
        --init "ps_init" --report "ps_report" --score "ps_score" \
        --enable-var "ENABLE_PROJECT_SCANNER" --cli-flags "--project-scanner:--no-project-scanner"
fi

# v2003.1: source時のexit codeを確実に0にする
true
