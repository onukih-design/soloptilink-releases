#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v30.0 - Agent Runtime Engine
# =============================================================================
# Bridges the gap between agent definitions (.claude/agents/*.md) and
# phase execution. Routes each DAG phase through the appropriate specialized
# agent, enabling domain-specific code generation quality.
#
# v17.0: Initial agent runtime with phase-to-agent routing
# v18.0: 18 agents, Intelligent Platform phases
# v19.0: 19 agents, Automation Gateway phases (workflow/cost/template)
# v20.0: Quality Fortress phases (quality_gate/functional_healing/smoke_test)
# v21.0: Full phase mapping alignment, version sync
# v23.0: Error Guardian integration, version sync
# v25.0: 20 agents, Adaptive Intelligence phases (dependency_resolve/performance_profile/api_contract_validate)
# v30.0: 30 agents, Swarm Autonomy phases (swarm_allocate/swarm_vote/governance_check)
#
# Functions:
#   ar_init                  - Initialize runtime, load agent registry
#   ar_map_phase_to_agents   - Return which agent handles a phase
#   ar_execute_phase         - Route phase execution through correct agent
#   ar_execute_with_agent    - Execute via specific agent
#   ar_get_agent_system_prompt - Load .md file content as system prompt
#   ar_fallback_execute      - Fall back to generic call_claude()
#   ar_report                - Agent runtime usage summary
#
# All globals use the AR_ prefix.
# =============================================================================

[[ -n "${_AGENT_RUNTIME_LOADED:-}" ]] && return 0
_AGENT_RUNTIME_LOADED=1

# ============================================================
# State
# ============================================================
declare -g AR_VERSION="31.0"
declare -g AR_ENABLED="false"
declare -g AR_SESSION_ID=""
declare -g AR_AGENTS_DIR=""
declare -g AR_TOTAL_CALLS=0
declare -g AR_AGENT_CALLS=0
declare -g AR_FALLBACK_CALLS=0
declare -g AR_MAX_RETRIES=3              # v16.0: Worker retry count
declare -g AR_DEFAULT_TIMEOUT=300        # v16.0: Default timeout per agent call
declare -g -A AR_CALLS_BY_AGENT=()
declare -g -A AR_AGENT_TIMEOUT=()        # v16.0: Per-agent timeout config

# Phase-to-Agent mapping (v27.0: 20エージェント + Precision Prompt Engine phases)
declare -g -A AR_PHASE_MAP=(
    [requirements]="pm"
    [competitive_research]="pm"
    [prompt_expand]="pm"
    [scaffold]="pm"
    [database]="db-architect"
    [backend]="backend-dev"
    [api]="api-designer"
    [implementation]="backend-dev"
    [hotfix]="backend-dev"
    [frontend]="frontend-dev"
    [ui_design]="designer"
    [quality_check]="qa-engineer"
    [testing]="test-architect"
    [security_audit]="security-auditor"
    [browser_test]="qa-engineer"
    [deploy]="devops"
    [deploy_preparation]="devops"
    [documentation]="documentation-writer"
    [knowledge_save]="pm"
    [migration]="migration-engineer"
    [integration]="integration-engineer"
    [performance]="performance-engineer"
    [data_integrity]="db-architect"
    [audit]="security-auditor"
    # --- v18.0 Intelligent Platform ---
    [data_import]="data-analyst"
    [saas_architecture]="saas-architect"
    [ai_integration]="ai-engineer"
    # --- v19.0 Automation Gateway ---
    [workflow]="workflow-designer"
    [cost_analysis]="cost-optimizer"
    [template_apply]="pm"
    # --- v20.0 Quality Fortress ---
    [quality_gate]="qa-engineer"
    [functional_healing]="backend-dev"
    [smoke_test]="qa-engineer"
    # --- v22.0 Phase name alignment ---
    [rag_search]="pm"
    [e2e_test]="test-architect"
    [auto_deploy]="devops"
    [audit_log_validation]="security-auditor"
    [quality_check]="qa-engineer"
    # --- v25.0 Adaptive Intelligence ---
    [dependency_resolve]="dependency-manager"
    [performance_profile]="performance-engineer"
    [api_contract_validate]="api-designer"
    # --- v26.0 Deep Fix Engine ---
    [deep_fix_investigate]="qa-engineer"
    [deep_fix_integrate]="pm"
    [deep_fix_implement]="backend-dev"
    [deep_fix_verify]="qa-engineer"
    # --- v27.0 Precision Prompt Engine ---
    [domain_knowledge]="pm"
    [blueprint]="pm"
    [prompt_compile]="pm"
    # --- v28.0 Consultant Engine ---
    [consultation]="pm"
    # --- v28.0 Follow-up Intelligence ---
    [followup_detect]="pm"
    [code_scan]="follow-up-analyst"
    [incremental_analysis]="follow-up-analyst"
    [targeted_compile]="follow-up-analyst"
    [delta_apply]="follow-up-analyst"
    # --- v29.0 Ripple Intelligence ---
    [ripple_analysis]="follow-up-analyst"
    [fix_learning]="follow-up-analyst"
    [collaborative_fix]="follow-up-analyst"
    # --- v30.0 Swarm Autonomy ---
    [swarm_allocate]="swarm-coordinator"
    [swarm_vote]="swarm-coordinator"
    [governance_check]="governance-agent"
    [ux_review]="ux-researcher"
    [i18n_setup]="i18n-engineer"
    [cache_strategy]="cache-strategist"
    [accessibility_audit]="accessibility-auditor"
    [state_design]="state-architect"
    [error_recovery_design]="error-recovery-agent"
    # --- iOS Support ---
    [ios_implementation]="ios-dev"
    [ios_ui_design]="ios-dev"
    [ios_testing]="ios-dev"
)

# ============================================================
# Internal logger
# ============================================================
_ar_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    [[ "$level" == "SUCCESS" ]] && color="${GREEN:-}"
    echo -e "  ${color}[AGENT-RT]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize agent runtime
# ============================================================
ar_init() {
    local session_id="${1:-${SESSION_ID:-unknown}}"

    AR_SESSION_ID="$session_id"
    AR_ENABLED="true"
    AR_TOTAL_CALLS=0
    AR_AGENT_CALLS=0
    AR_FALLBACK_CALLS=0
    AR_CALLS_BY_AGENT=()

    # Locate agents directory
    local script_dir="${SCRIPT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
    AR_AGENTS_DIR="${script_dir}/.claude/agents"

    if [[ ! -d "$AR_AGENTS_DIR" ]]; then
        _ar_log "WARN" "エージェント定義ディレクトリ未検出: ${AR_AGENTS_DIR}"
        AR_ENABLED="false"
        return 1
    fi

    # Count available agents
    local agent_count=0
    for md_file in "${AR_AGENTS_DIR}"/*.md; do
        [[ -f "$md_file" ]] && agent_count=$((agent_count + 1))
    done

    _ar_log "SUCCESS" "エージェントランタイム初期化: ${agent_count}エージェント検出"
    return 0
}

# ============================================================
# Map phase to agent ID
# v17.0: agent-scaler.sh と統合。as_get_agents_for_phase()が
#        利用可能ならフェーズ別マルチエージェントルーティングを使用
# ============================================================
ar_map_phase_to_agents() {
    local phase="$1"

    # v17.0: agent-scaler が利用可能ならそちらを優先
    if type -t as_get_agents_for_phase &>/dev/null; then
        local scaler_agents
        scaler_agents=$(as_get_agents_for_phase "$phase" 2>/dev/null || echo "")
        if [[ -n "$scaler_agents" ]]; then
            # スペース区切りの最初のエージェントをプライマリとして返す
            local primary_agent="${scaler_agents%% *}"
            local md_path="${AR_AGENTS_DIR}/${primary_agent}.md"
            if [[ -f "$md_path" ]]; then
                echo "$primary_agent"
                return 0
            fi
        fi
    fi

    # フォールバック: 静的マッピング
    local agent_id="${AR_PHASE_MAP[$phase]:-}"

    if [[ -z "$agent_id" ]]; then
        echo ""
        return 0
    fi

    # Verify agent definition exists
    local md_path="${AR_AGENTS_DIR}/${agent_id}.md"
    if [[ ! -f "$md_path" ]]; then
        echo ""
        return 1
    fi

    echo "$agent_id"
    return 0
}

# ============================================================
# Get agent system prompt (load .md content)
# ============================================================
ar_get_agent_system_prompt() {
    local agent_id="$1"
    local md_path="${AR_AGENTS_DIR}/${agent_id}.md"

    if [[ ! -f "$md_path" ]]; then
        return 1
    fi

    cat "$md_path" 2>/dev/null
}

# ============================================================
# Execute phase through the appropriate agent
# ============================================================
ar_execute_phase() {
    local phase="$1"
    local prompt="$2"
    local output_file="${3:-}"

    AR_TOTAL_CALLS=$((AR_TOTAL_CALLS + 1))

    # Determine which agent handles this phase
    local agent_id
    agent_id=$(ar_map_phase_to_agents "$phase")

    if [[ -z "$agent_id" ]]; then
        _ar_log "WARN" "フェーズ '${phase}' にマッピングされたエージェントなし → フォールバック"
        ar_fallback_execute "$prompt" "$output_file"
        return $?
    fi

    ar_execute_with_agent "$agent_id" "$prompt" "$output_file"
    return $?
}

# ============================================================
# Execute with a specific agent
# ============================================================
ar_execute_with_agent() {
    local agent_id="$1"
    local prompt="$2"
    local output_file="${3:-}"

    local md_path="${AR_AGENTS_DIR}/${agent_id}.md"

    if [[ ! -f "$md_path" ]]; then
        _ar_log "WARN" "エージェント定義未検出: ${agent_id} → フォールバック"
        ar_fallback_execute "$prompt" "$output_file"
        return $?
    fi

    AR_AGENT_CALLS=$((AR_AGENT_CALLS + 1))
    AR_CALLS_BY_AGENT["$agent_id"]=$(( ${AR_CALLS_BY_AGENT[$agent_id]:-0} + 1 ))

    # Update phase executor state
    _CURRENT_AGENT="$agent_id"

    _ar_log "SUCCESS" "エージェント '${agent_id}' でフェーズ実行"

    # Try ao_dispatch first (if agent-orchestrator is available and agent is registered)
    if type -t ao_dispatch &>/dev/null && [[ -n "${AO_AGENT_PATHS[$agent_id]:-}" ]]; then
        ao_dispatch "$agent_id" "$prompt" "$output_file"
        local rc=$?

        # v15.0: Record cost with agent attribution
        if type -t cost_record &>/dev/null; then
            local cost_amount="0.08"
            # Use structured output token data if available
            if [[ -n "${SO_LAST_COST:-}" && "${SO_LAST_COST}" != "" ]]; then
                cost_amount="$SO_LAST_COST"
            fi
            cost_record "$cost_amount" "${_CURRENT_PHASE:-unknown}" "$agent_id" "" 2>/dev/null || true
        fi

        # v15.0: Emit observatory event
        if type -t obs_emit_event &>/dev/null; then
            obs_emit_event "AGENT_DISPATCH" "{\"agent\":\"${agent_id}\",\"phase\":\"${_CURRENT_PHASE:-}\",\"status\":\"$([ $rc -eq 0 ] && echo ok || echo error)\"}" 2>/dev/null || true
        fi

        return $rc
    fi

    # Direct Claude CLI call with agent flag + v16.0 retry logic
    local timeout_sec="${AR_AGENT_TIMEOUT[$agent_id]:-${AR_DEFAULT_TIMEOUT}}"
    local max_retries="${AR_MAX_RETRIES}"
    local result=""
    local rc=1
    local claude_err="${SESSION_LOG_DIR:-/tmp}/claude_agent_${agent_id}.stderr"

    # v16.0: Model routing flag
    local ar_model_flag=""
    if [[ "${MR_ENABLED:-false}" == "true" ]] && type -t mr_route_phase &>/dev/null; then
        local ar_tier
        ar_tier=$(mr_route_phase "${_CURRENT_PHASE:-unknown}" "" 2>/dev/null || echo "balanced")
        ar_model_flag=$(mr_get_model_flag "$ar_tier" 2>/dev/null || echo "")
    fi

    for ((ar_retry=1; ar_retry<=max_retries; ar_retry++)); do
        if [[ -n "${SO_ENABLED:-}" && "$SO_ENABLED" == "true" ]] && type -t so_call_claude_json &>/dev/null; then
            # v15.0: Structured output mode with agent
            result=$(so_call_claude_json "$prompt" "$output_file" "$md_path")
            rc=$?
        else
            # Standard text mode with agent
            if command -v timeout &>/dev/null; then
                result=$(timeout "$timeout_sec" claude -p \
                    --dangerously-skip-permissions \
                    --output-format text \
                    ${ar_model_flag} \
                    -a "$md_path" \
                    "$prompt" 2>>"$claude_err")
                rc=$?
            else
                result=$(claude -p \
                    --dangerously-skip-permissions \
                    --output-format text \
                    ${ar_model_flag} \
                    -a "$md_path" \
                    "$prompt" 2>>"$claude_err")
                rc=$?
            fi
        fi

        if [[ $rc -eq 0 && -n "$result" ]]; then
            break
        fi

        if [[ $ar_retry -lt $max_retries ]]; then
            _ar_log "WARN" "エージェント '${agent_id}' リトライ (${ar_retry}/${max_retries})"
            sleep $((ar_retry * 2))
        fi
    done

    if [[ $rc -eq 0 && -n "$result" ]]; then
        if [[ -n "$output_file" ]]; then
            mkdir -p "$(dirname "$output_file")" 2>/dev/null || true
            printf '%s\n' "$result" > "$output_file"
        else
            printf '%s\n' "$result"
        fi

        # Cost tracking
        if type -t cost_record &>/dev/null; then
            local cost_amount="0.08"
            [[ -n "${SO_LAST_COST:-}" && "${SO_LAST_COST}" != "" ]] && cost_amount="$SO_LAST_COST"
            cost_record "$cost_amount" "${_CURRENT_PHASE:-unknown}" "$agent_id" "" 2>/dev/null || true
        fi

        # v16.0: Model router usage tracking
        if [[ "${MR_ENABLED:-false}" == "true" ]] && type -t mr_record_usage &>/dev/null; then
            mr_record_usage "${ar_tier:-balanced}" "${SO_LAST_INPUT_TOKENS:-0}" "${SO_LAST_OUTPUT_TOKENS:-0}" 2>/dev/null || true
        fi

        # Observatory event
        type -t obs_emit_event &>/dev/null && obs_emit_event "AGENT_CALL_OK" "{\"agent\":\"${agent_id}\",\"phase\":\"${_CURRENT_PHASE:-}\",\"chars\":${#result},\"retries\":${ar_retry}}" 2>/dev/null || true
    else
        _ar_log "WARN" "エージェント '${agent_id}' 呼び出し失敗 (rc=${rc}, ${max_retries}回リトライ後)"
    fi

    # v31.0: Secondary agent review (best-effort, non-blocking)
    if [[ "${AR_SECONDARY_REVIEW:-true}" == "true" ]] && type -t as_get_agents_for_phase &>/dev/null; then
        local _ar_all_agents
        _ar_all_agents=$(as_get_agents_for_phase "$phase_name" 2>/dev/null || echo "")
        local _ar_secondary=""
        local _ar_count=0
        for _ar_a in $_ar_all_agents; do
            _ar_count=$((_ar_count + 1))
            if [[ $_ar_count -eq 2 ]]; then
                _ar_secondary="$_ar_a"
                break
            fi
        done
        if [[ -n "$_ar_secondary" && -n "${output_file:-}" && -f "$output_file" ]]; then
            _ar_log "INFO" "セカンダリエージェント '${_ar_secondary}' でレビュー実行" 2>/dev/null || true
            local _ar_review_output="${output_file}.review"
            local _ar_review_prompt="以下のコード出力をレビューし、重大な問題があれば指摘してください（簡潔に）:\n$(head -c 2000 "$output_file" 2>/dev/null || echo '')"
            (ar_execute_single_agent "$_ar_secondary" "$_ar_review_prompt" "$_ar_review_output" 2>/dev/null || true) &
            disown 2>/dev/null || true
        fi
    fi

    return $rc
}

# ============================================================
# v31.0: Execute a single agent in lightweight mode (for reviews)
# ============================================================
ar_execute_single_agent() {
    local agent_id="$1"
    local prompt="$2"
    local output_file="${3:-}"

    local md_path="${AR_AGENTS_DIR}/${agent_id}.md"
    [[ ! -f "$md_path" ]] && return 1

    local result=""
    if command -v timeout &>/dev/null; then
        result=$(timeout 120 claude -p \
            --dangerously-skip-permissions \
            --output-format text \
            -a "$md_path" \
            "$prompt" 2>/dev/null)
    else
        result=$(claude -p \
            --dangerously-skip-permissions \
            --output-format text \
            -a "$md_path" \
            "$prompt" 2>/dev/null)
    fi

    if [[ -n "$result" && -n "$output_file" ]]; then
        mkdir -p "$(dirname "$output_file")" 2>/dev/null || true
        printf '%s\n' "$result" > "$output_file"
    fi
    return 0
}

# ============================================================
# Fallback: execute without agent specialization
# ============================================================
ar_fallback_execute() {
    local prompt="$1"
    local output_file="${2:-}"

    AR_FALLBACK_CALLS=$((AR_FALLBACK_CALLS + 1))
    _CURRENT_AGENT="system"

    # Delegate to the standard call_claude path
    # We bypass agent routing to avoid infinite recursion
    local timeout_sec=300
    local result
    local claude_err="${SESSION_LOG_DIR:-/tmp}/claude_fallback.stderr"

    if command -v timeout &>/dev/null; then
        result=$(timeout "$timeout_sec" claude -p \
            --dangerously-skip-permissions \
            --output-format text \
            "$prompt" 2>>"$claude_err")
    else
        result=$(claude -p \
            --dangerously-skip-permissions \
            --output-format text \
            "$prompt" 2>>"$claude_err")
    fi

    local rc=$?

    if [[ $rc -eq 0 && -n "$result" ]]; then
        if [[ -n "$output_file" ]]; then
            mkdir -p "$(dirname "$output_file")" 2>/dev/null || true
            printf '%s\n' "$result" > "$output_file"
        else
            printf '%s\n' "$result"
        fi
    fi

    return $rc
}

# ============================================================
# Report: Agent runtime usage summary
# ============================================================
ar_report() {
    echo ""
    echo -e "  ${BOLD:-}${CYAN:-}[Agent Runtime Report] v29.0${NC:-}"
    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    echo -e "  ランタイム状態:     ${AR_ENABLED}"
    echo -e "  総呼び出し:         ${AR_TOTAL_CALLS}"
    echo -e "  エージェント経由:   ${AR_AGENT_CALLS}"
    echo -e "  フォールバック:     ${AR_FALLBACK_CALLS}"

    # v17.0: agent-scaler 統合情報
    if type -t as_list_agents &>/dev/null; then
        local _ar_total_agents
        _ar_total_agents=$(as_list_agents 2>/dev/null | wc -l | tr -d ' ')
        echo -e "  登録エージェント:   ${_ar_total_agents:-0}体 (via agent-scaler)"
    fi
    echo ""

    if [[ ${#AR_CALLS_BY_AGENT[@]} -gt 0 ]]; then
        printf "  %-20s  %8s\n" "Agent" "Calls"
        echo -e "  ────────────────────  ────────"
        for agent_id in "${!AR_CALLS_BY_AGENT[@]}"; do
            printf "  %-20s  %8d\n" "$agent_id" "${AR_CALLS_BY_AGENT[$agent_id]}"
        done
    fi

    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    echo ""
}
