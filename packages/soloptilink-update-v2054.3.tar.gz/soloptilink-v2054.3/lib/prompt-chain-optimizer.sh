#!/usr/bin/env bash
# SoloptiLinkAI v75.0 - prompt-chain-optimizer
# プロンプトチェーン最適化×冗長削減
[[ -n "${_PCO_LOADED:-}" ]] && return 0; _PCO_LOADED=1

PCO_GENERATED=0
PCO_ERRORS=0
PCO_PHASE="prompt_optimize"

pco_init() {
    PCO_GENERATED=0
    PCO_ERRORS=0
    return 0
}

pco_analyze_prompts() {
    local session_dir="${SESSION_DIR:-/tmp}"
    local prompt_count=0
    local total_tokens=0
    if [[ -d "$session_dir" ]]; then
        prompt_count=$(find "$session_dir" -name "*-prompt-*.txt" 2>/dev/null | wc -l)
        prompt_count=$(echo "$prompt_count" | tr -d ' ')
    fi
    echo "$prompt_count"
}

pco_optimize_chain() {
    local project_dir="${PROJECT_DIR:-./output}"
    local domain="${DOMAIN_TYPE:-general}"
    local task="${TASK_DESC:-}"

    local prompt="Analyze and optimize the prompt chain for this project:
1. Identify redundant context across prompts
2. Optimize prompt ordering for dependency resolution
3. Reduce total token usage by compressing repeated patterns
4. Generate optimized prompt templates
5. Report token savings and quality impact

Project directory: ${project_dir}
Domain: ${domain}
Task description: ${task}

Requirements:
- TypeScript/Node.js (Next.js App Router) preferred
- Use zod for validation, Prisma for DB
- Enterprise security best practices
- Use --- FILE: path --- markers to separate files

Generate production-ready code."

    local output_file="${SESSION_DIR:-/tmp}/prompt-chain-optimizer-output.txt"

    if type -t cb2_call &>/dev/null; then
        cb2_call "$prompt" "$output_file" "prompt_optimize" "${domain}" 2>/dev/null
    elif type -t _call_claude &>/dev/null; then
        _call_claude "$prompt" "$output_file" "prompt_optimize" 2>/dev/null
    else
        echo "[prompt-chain-optimizer] No Claude bridge available" >&2
        PCO_ERRORS=$((PCO_ERRORS + 1))
        return 1
    fi

    if [[ -f "$output_file" ]] && [[ -s "$output_file" ]]; then
        if type -t _write_claude_output_to_files &>/dev/null; then
            _write_claude_output_to_files "$output_file" "$project_dir" 2>/dev/null
        fi
        PCO_GENERATED=$((PCO_GENERATED + 1))
        return 0
    else
        PCO_ERRORS=$((PCO_ERRORS + 1))
        return 1
    fi
}

pco_report() {
    echo -e "\n  ${BOLD:-}=== prompt-chain-optimizer v75.0 ===${NC:-}"
    echo -e "  生成数: ${PCO_GENERATED}"
    echo -e "  エラー: ${PCO_ERRORS}"
}

pco_score() {
    if [[ ${PCO_GENERATED} -gt 0 ]] && [[ ${PCO_ERRORS} -eq 0 ]]; then
        echo "90"
    elif [[ ${PCO_GENERATED} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# v59.0: Module Registry 自己登録
if type -t _mr_register &>/dev/null; then
    _mr_register --name "prompt-chain-optimizer" --version "75.0" \
        --description "プロンプトチェーン最適化×冗長削減" \
        --init "pco_init" --report "pco_report" --score "pco_score" \
        --enable-var "ENABLE_PROMPT_CHAIN_OPT" --cli-flags "--prompt-chain-opt:--no-prompt-chain-opt"
fi

# v2003.1: source時のexit codeを確実に0にする
true
