#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v376.0 - Industry Template: Real Estate
# =============================================================================
# 不動産特化テンプレートエンジン。
# 物件管理/内見予約/契約管理/ポータル等の不動産必須コンポーネントを自動生成。
#
# All globals use the ITR_ prefix.
# =============================================================================

[[ -n "${_INDUSTRY_TEMPLATE_REALESTATE_LOADED:-}" ]] && return 0
_INDUSTRY_TEMPLATE_REALESTATE_LOADED=1

declare -g ITR_VERSION="376.0"
declare -g ITR_INITIALIZED=false
declare -g ITR_GENERATED_COUNT=0
declare -g ITR_PROPERTY_GENERATED=false
declare -g ITR_VIEWING_GENERATED=false
declare -g ITR_CONTRACT_GENERATED=false
declare -g ITR_PORTAL_GENERATED=false
declare -g ENABLE_ITR="${ENABLE_ITR:-true}"

_itr_init() {
    ITR_INITIALIZED=true
    ITR_GENERATED_COUNT=0
    return 0
}

_itr_generate_realestate() {
    local project_dir="${1:-.}"
    [[ "$ITR_INITIALIZED" != "true" ]] && _itr_init

    echo -e "  ${CYAN:-\033[0;36m}[ITR]${NC:-\033[0m} 不動産業界テンプレート生成開始..." >&2

    _itr_generate_property "$project_dir"
    _itr_generate_viewing "$project_dir"
    _itr_generate_contract "$project_dir"
    _itr_generate_portal "$project_dir"

    echo -e "  ${GREEN:-\033[0;32m}[ITR]${NC:-\033[0m} 不動産業界テンプレート生成完了: ${ITR_GENERATED_COUNT}件" >&2
    return 0
}

_itr_generate_property() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITR-PROPERTY] 物件管理テンプレート

### Prisma Schema
```prisma
model Property {
  id            String   @id @default(cuid())
  title         String
  type          String
  transactionType String
  price         BigInt
  pricePer      BigInt?
  address       String
  prefecture    String
  city          String
  latitude      Float?
  longitude     Float?
  floorArea     Float
  landArea      Float?
  rooms         Int?
  layout        String?
  floor         Int?
  totalFloors   Int?
  builtYear     Int?
  structure     String?
  parking       Boolean  @default(false)
  features      String[]
  status        String   @default("available")
  description   String?  @db.Text
  images        PropertyImage[]
  viewings      Viewing[]
  agentId       String
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt
  @@index([prefecture, city])
  @@index([type, transactionType])
  @@index([price])
  @@index([status])
}

model PropertyImage {
  id         String   @id @default(cuid())
  propertyId String
  property   Property @relation(fields: [propertyId], references: [id], onDelete: Cascade)
  url        String
  caption    String?
  sortOrder  Int      @default(0)
  @@index([propertyId])
}
```

### Property Search with Map
```tsx
'use client';
export function PropertySearch() {
  const [filters, setFilters] = useState<PropertyFilters>({
    type: 'all', transactionType: 'all',
    priceMin: 0, priceMax: 100000000,
    prefecture: '', rooms: 0,
  });
  const params = buildSearchParams(filters);
  const { data, isLoading } = useSWR(`/api/properties?${params}`);

  if (isLoading) return <PropertySearchSkeleton />;

  return (
    <div className="flex gap-4 h-[calc(100vh-80px)]">
      <div className="w-80 overflow-y-auto">
        <PropertyFilterPanel filters={filters} onChange={setFilters} />
        {data?.properties?.map((p: Property) => (
          <PropertyCard key={p.id} property={p} />
        ))}
        {!data?.properties?.length && <EmptyState message="条件に合う物件がありません" />}
      </div>
      <div className="flex-1">
        <PropertyMap properties={data?.properties ?? []} />
      </div>
    </div>
  );
}
```
TEMPLATE

    ITR_PROPERTY_GENERATED=true
    ITR_GENERATED_COUNT=$((ITR_GENERATED_COUNT + 1))
    return 0
}

_itr_generate_viewing() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITR-VIEWING] 内見予約テンプレート

### Schema
```prisma
model Viewing {
  id          String   @id @default(cuid())
  propertyId  String
  property    Property @relation(fields: [propertyId], references: [id])
  customerId  String
  agentId     String
  scheduledAt DateTime
  duration    Int      @default(60)
  status      String   @default("pending")
  notes       String?
  feedback    String?
  rating      Int?
  createdAt   DateTime @default(now())
  @@index([propertyId, scheduledAt])
  @@index([agentId, scheduledAt])
}
```

### Viewing Scheduler
```typescript
export async function scheduleViewing(propertyId: string, customerId: string, requestedDate: Date) {
  const property = await prisma.property.findUniqueOrThrow({
    where: { id: propertyId }, select: { agentId: true, title: true },
  });
  const conflicts = await prisma.viewing.findMany({
    where: { agentId: property.agentId, scheduledAt: { gte: subMinutes(requestedDate, 90), lte: addMinutes(requestedDate, 90) },
      status: { not: 'cancelled' } },
  });
  if (conflicts.length > 0) throw new Error('この時間帯は予約済みです');
  const viewing = await prisma.viewing.create({
    data: { propertyId, customerId, agentId: property.agentId, scheduledAt: requestedDate },
  });
  await Promise.all([
    sendNotification(property.agentId, 'new_viewing', { propertyTitle: property.title, date: requestedDate }),
    sendNotification(customerId, 'viewing_confirmed', { propertyTitle: property.title, date: requestedDate }),
  ]);
  return viewing;
}
```
TEMPLATE

    ITR_VIEWING_GENERATED=true
    ITR_GENERATED_COUNT=$((ITR_GENERATED_COUNT + 1))
    return 0
}

_itr_generate_contract() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITR-CONTRACT] 不動産契約管理テンプレート

### Schema
```prisma
model PropertyContract {
  id           String   @id @default(cuid())
  propertyId   String
  buyerId      String
  sellerId     String
  agentId      String
  type         String
  price        BigInt
  deposit      BigInt?
  commission   BigInt?
  status       String   @default("draft")
  signedAt     DateTime?
  effectiveDate DateTime?
  expiryDate   DateTime?
  terms        Json
  documents    ContractDocument[]
  createdAt    DateTime @default(now())
  updatedAt    DateTime @updatedAt
}

model ContractDocument {
  id         String @id @default(cuid())
  contractId String
  contract   PropertyContract @relation(fields: [contractId], references: [id])
  name       String
  type       String
  url        String
  uploadedAt DateTime @default(now())
}
```

### Contract Workflow
```typescript
export async function advanceContractStatus(contractId: string, action: string) {
  const contract = await prisma.propertyContract.findUniqueOrThrow({ where: { id: contractId } });
  const transitions: Record<string, Record<string, string>> = {
    draft: { submit: 'pending_review' },
    pending_review: { approve: 'pending_signature', reject: 'draft' },
    pending_signature: { sign: 'active', cancel: 'cancelled' },
    active: { complete: 'completed', terminate: 'terminated' },
  };
  const nextStatus = transitions[contract.status]?.[action];
  if (!nextStatus) throw new Error(`無効な操作: ${contract.status} -> ${action}`);
  return prisma.propertyContract.update({
    where: { id: contractId },
    data: { status: nextStatus, ...(action === 'sign' ? { signedAt: new Date() } : {}) },
  });
}
```
TEMPLATE

    ITR_CONTRACT_GENERATED=true
    ITR_GENERATED_COUNT=$((ITR_GENERATED_COUNT + 1))
    return 0
}

_itr_generate_portal() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [ITR-PORTAL] 不動産ポータルテンプレート

### Customer Portal Dashboard
```tsx
'use client';
export function CustomerPortal() {
  const { data, isLoading } = useSWR('/api/customer/dashboard');
  if (isLoading) return <PortalSkeleton />;
  return (
    <div className="space-y-6">
      <section>
        <h2 className="text-lg font-semibold">お気に入り物件</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {data?.favorites?.map((p: Property) => <PropertyCard key={p.id} property={p} />)}
        </div>
      </section>
      <section>
        <h2 className="text-lg font-semibold">内見予約</h2>
        {data?.viewings?.map((v: Viewing) => <ViewingCard key={v.id} viewing={v} />)}
      </section>
      <section>
        <h2 className="text-lg font-semibold">契約状況</h2>
        {data?.contracts?.map((c: Contract) => <ContractStatusCard key={c.id} contract={c} />)}
      </section>
    </div>
  );
}
```
TEMPLATE

    ITR_PORTAL_GENERATED=true
    ITR_GENERATED_COUNT=$((ITR_GENERATED_COUNT + 1))
    return 0
}

_itr_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Industry Template: Real Estate v${ITR_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成テンプレート数 : ${ITR_GENERATED_COUNT}"
    echo -e "  Property           : ${ITR_PROPERTY_GENERATED}"
    echo -e "  Viewing            : ${ITR_VIEWING_GENERATED}"
    echo -e "  Contract           : ${ITR_CONTRACT_GENERATED}"
    echo -e "  Portal             : ${ITR_PORTAL_GENERATED}"
}

_itr_score() {
    local score=30
    [[ "$ITR_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$ITR_PROPERTY_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITR_VIEWING_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITR_CONTRACT_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITR_PORTAL_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "industry-template-realestate" \
    --version "376.0" \
    --description "不動産業界テンプレート（物件/内見/契約/ポータル）" \
    --init "_itr_init" \
    --report "_itr_report" \
    --score "_itr_score" \
    --enable-var "ENABLE_ITR" \
    --cli-flags "--industry-realestate:--no-industry-realestate"
