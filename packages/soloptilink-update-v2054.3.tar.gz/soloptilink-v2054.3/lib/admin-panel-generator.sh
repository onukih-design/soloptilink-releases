#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v301.0 - Admin Panel Generator
# =============================================================================
# ドメイン特化システムジェネレーター: 管理パネル自動生成
# サイドバー/ヘッダー/ブレッドクラム付きレイアウト、全モデルCRUDページ、
# ユーザー管理（一覧/作成/編集/ロール）、設定ページを自動生成。
#
# 全globals: APG_ prefix
# =============================================================================

[[ -n "${_ADMIN_PANEL_GENERATOR_LOADED:-}" ]] && return 0
_ADMIN_PANEL_GENERATOR_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g APG_VERSION="301.0"
declare -g APG_INITIALIZED=false
declare -g APG_GENERATED_COUNT=0
declare -g APG_OUTPUT_DIR=""
declare -g APG_MODELS=()
declare -g APG_SIDEBAR_ITEMS=()
declare -g ENABLE_ADMIN_PANEL_GENERATOR="${ENABLE_ADMIN_PANEL_GENERATOR:-true}"

# Color fallbacks
readonly APG_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly APG_YELLOW="${CLR_YELLOW:-\033[0;33m}"
readonly APG_RED="${CLR_RED:-\033[0;31m}"
readonly APG_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly APG_BOLD="${CLR_BOLD:-\033[1m}"
readonly APG_NC="${CLR_NC:-\033[0m}"

# =============================================================================
# Logging
# =============================================================================
_apg_log() { echo -e "  ${APG_CYAN}[APG]${APG_NC} $*" >&2; }
_apg_ok()  { echo -e "  ${APG_GREEN}[APG] OK${APG_NC} $*" >&2; }
_apg_warn(){ echo -e "  ${APG_YELLOW}[APG] WARN${APG_NC} $*" >&2; }
_apg_err() { echo -e "  ${APG_RED}[APG] ERR${APG_NC} $*" >&2; }

# =============================================================================
# Init / Report / Score
# =============================================================================
apg_init() {
    APG_INITIALIZED=true
    APG_GENERATED_COUNT=0
    APG_MODELS=()
    APG_SIDEBAR_ITEMS=()
    return 0
}

apg_report() {
    [[ "$APG_INITIALIZED" != "true" ]] && return 0
    echo -e "\n  ${APG_BOLD}--- Admin Panel Generator v${APG_VERSION} ---${APG_NC}" >&2
    echo -e "  生成コンポーネント数: ${APG_GENERATED_COUNT}" >&2
    echo -e "  モデル数: ${#APG_MODELS[@]}" >&2
}

apg_score() {
    [[ "$APG_INITIALIZED" != "true" ]] && { echo "0"; return; }
    local score=50
    [[ ${APG_GENERATED_COUNT} -ge 4 ]] && score=80
    [[ ${APG_GENERATED_COUNT} -ge 8 ]] && score=95
    echo "$score"
}

apg_init_message() {
    echo -e "  ${APG_GREEN}v${APG_VERSION} admin-panel-generator: 管理パネル自動生成エンジン${APG_NC}" >&2
}

# =============================================================================
# _apg_generate_admin_layout() - Admin layout (sidebar, header, breadcrumbs)
# =============================================================================
_apg_generate_admin_layout() {
    local project_dir="${1:-.}"
    local app_name="${2:-Admin}"
    local sidebar_items_json="${3:-}"

    _apg_log "管理パネルレイアウト生成: ${app_name}"

    local layout_dir="${project_dir}/src/components/admin"
    mkdir -p "$layout_dir"

    # Sidebar component
    cat > "${layout_dir}/AdminSidebar.tsx" <<'SIDEBAR_EOF'
'use client';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import {
  LayoutDashboard, Users, Settings, FileText, BarChart3,
  ChevronLeft, ChevronRight, LogOut
} from 'lucide-react';

interface SidebarItem {
  label: string;
  href: string;
  icon: React.ReactNode;
  badge?: number;
}

const defaultItems: SidebarItem[] = [
  { label: 'ダッシュボード', href: '/admin', icon: <LayoutDashboard size={20} /> },
  { label: 'ユーザー管理', href: '/admin/users', icon: <Users size={20} /> },
  { label: 'コンテンツ', href: '/admin/content', icon: <FileText size={20} /> },
  { label: 'アナリティクス', href: '/admin/analytics', icon: <BarChart3 size={20} /> },
  { label: '設定', href: '/admin/settings', icon: <Settings size={20} /> },
];

interface AdminSidebarProps {
  items?: SidebarItem[];
  collapsed?: boolean;
  onToggle?: () => void;
}

export function AdminSidebar({ items = defaultItems, collapsed = false, onToggle }: AdminSidebarProps) {
  const pathname = usePathname();

  return (
    <aside className={cn(
      'h-screen bg-gray-900 text-white transition-all duration-300 flex flex-col',
      collapsed ? 'w-16' : 'w-64'
    )}>
      <div className="p-4 flex items-center justify-between border-b border-gray-700">
        {!collapsed && <span className="font-bold text-lg">Admin</span>}
        <button onClick={onToggle} className="p-1 rounded hover:bg-gray-700">
          {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
        </button>
      </div>
      <nav className="flex-1 py-4 space-y-1 overflow-y-auto">
        {items.map((item) => {
          const isActive = pathname === item.href || pathname.startsWith(item.href + '/');
          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                'flex items-center gap-3 px-4 py-2.5 text-sm transition-colors',
                isActive
                  ? 'bg-blue-600 text-white font-medium'
                  : 'text-gray-300 hover:bg-gray-800 hover:text-white'
              )}
            >
              {item.icon}
              {!collapsed && <span>{item.label}</span>}
              {!collapsed && item.badge != null && (
                <span className="ml-auto bg-red-500 text-xs px-2 py-0.5 rounded-full">{item.badge}</span>
              )}
            </Link>
          );
        })}
      </nav>
      <div className="p-4 border-t border-gray-700">
        <button className="flex items-center gap-3 text-gray-400 hover:text-white text-sm w-full">
          <LogOut size={20} />
          {!collapsed && <span>ログアウト</span>}
        </button>
      </div>
    </aside>
  );
}
SIDEBAR_EOF

    # Header component
    cat > "${layout_dir}/AdminHeader.tsx" <<'HEADER_EOF'
'use client';
import { Bell, Search, User } from 'lucide-react';

interface AdminHeaderProps {
  title: string;
  breadcrumbs?: { label: string; href?: string }[];
  user?: { name: string; email: string; avatar?: string };
}

export function AdminHeader({ title, breadcrumbs = [], user }: AdminHeaderProps) {
  return (
    <header className="bg-white border-b px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          {breadcrumbs.length > 0 && (
            <nav className="text-sm text-gray-500 mb-1">
              {breadcrumbs.map((bc, i) => (
                <span key={i}>
                  {i > 0 && <span className="mx-1">/</span>}
                  {bc.href ? (
                    <a href={bc.href} className="hover:text-blue-600">{bc.label}</a>
                  ) : (
                    <span className="text-gray-700">{bc.label}</span>
                  )}
                </span>
              ))}
            </nav>
          )}
          <h1 className="text-2xl font-bold text-gray-900">{title}</h1>
        </div>
        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" size={16} />
            <input
              type="search"
              placeholder="検索..."
              className="pl-9 pr-4 py-2 border rounded-lg text-sm w-64 focus:ring-2 focus:ring-blue-500 focus:outline-none"
            />
          </div>
          <button className="relative p-2 rounded-lg hover:bg-gray-100">
            <Bell size={20} />
            <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 rounded-full flex items-center justify-center">3</span>
          </button>
          <div className="flex items-center gap-2 pl-4 border-l">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center text-white text-sm">
              {user?.name?.charAt(0) || <User size={16} />}
            </div>
            <div className="text-sm">
              <p className="font-medium">{user?.name || 'Admin'}</p>
              <p className="text-gray-500 text-xs">{user?.email || ''}</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
HEADER_EOF

    # Admin layout wrapper
    cat > "${layout_dir}/AdminLayout.tsx" <<'LAYOUT_EOF'
'use client';
import { useState } from 'react';
import { AdminSidebar } from './AdminSidebar';
import { AdminHeader } from './AdminHeader';

interface AdminLayoutProps {
  children: React.ReactNode;
  title: string;
  breadcrumbs?: { label: string; href?: string }[];
}

export function AdminLayout({ children, title, breadcrumbs }: AdminLayoutProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);

  return (
    <div className="flex h-screen bg-gray-50">
      <AdminSidebar
        collapsed={sidebarCollapsed}
        onToggle={() => setSidebarCollapsed(!sidebarCollapsed)}
      />
      <div className="flex-1 flex flex-col overflow-hidden">
        <AdminHeader title={title} breadcrumbs={breadcrumbs} />
        <main className="flex-1 overflow-y-auto p-6">
          {children}
        </main>
      </div>
    </div>
  );
}
LAYOUT_EOF

    APG_GENERATED_COUNT=$((APG_GENERATED_COUNT + 3))
    _apg_ok "レイアウト生成完了: AdminSidebar, AdminHeader, AdminLayout"
    return 0
}

# =============================================================================
# _apg_generate_crud_pages() - CRUD pages for all models
# =============================================================================
_apg_generate_crud_pages() {
    local project_dir="${1:-.}"
    local models="${2:-}"  # comma-separated model names

    [[ -z "$models" ]] && { _apg_warn "モデル指定なし"; return 1; }

    _apg_log "CRUDページ生成: ${models}"

    IFS=',' read -ra model_list <<< "$models"
    for model in "${model_list[@]}"; do
        model="$(echo "$model" | xargs)"
        local lower_model="$(echo "$model" | tr '[:upper:]' '[:lower:]')"
        local page_dir="${project_dir}/src/app/admin/${lower_model}s"
        mkdir -p "$page_dir"

        APG_MODELS+=("$model")

        # List page
        cat > "${page_dir}/page.tsx" <<LISTPAGE_EOF
'use client';
import useSWR from 'swr';
import Link from 'next/link';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Plus, Pencil, Trash2 } from 'lucide-react';
import { useState } from 'react';

const fetcher = (url: string) => fetch(url).then(r => r.json());

export default function ${model}ListPage() {
  const { data, error, isLoading, mutate } = useSWR('/api/admin/${lower_model}s', fetcher);
  const [deleting, setDeleting] = useState<string | null>(null);

  const handleDelete = async (id: string) => {
    if (!confirm('本当に削除しますか？')) return;
    setDeleting(id);
    try {
      await fetch(\`/api/admin/${lower_model}s/\${id}\`, { method: 'DELETE' });
      mutate();
    } catch (e) {
      alert('削除に失敗しました');
    } finally {
      setDeleting(null);
    }
  };

  return (
    <AdminLayout title="${model}管理" breadcrumbs={[{ label: 'Admin', href: '/admin' }, { label: '${model}管理' }]}>
      <div className="flex justify-between items-center mb-6">
        <p className="text-gray-600">{data?.data?.length ?? 0}件</p>
        <Link href="/admin/${lower_model}s/new" className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700">
          <Plus size={16} /> 新規作成
        </Link>
      </div>

      {isLoading && <div className="space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="h-16 bg-gray-200 rounded animate-pulse" />)}</div>}
      {error && <p className="text-red-600">読み込みに失敗しました</p>}
      {data?.data?.length === 0 && <p className="text-gray-500 text-center py-8">データがありません</p>}

      {data?.data && (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="text-left px-4 py-3 font-medium">ID</th>
                <th className="text-left px-4 py-3 font-medium">名前</th>
                <th className="text-left px-4 py-3 font-medium">作成日</th>
                <th className="text-right px-4 py-3 font-medium">操作</th>
              </tr>
            </thead>
            <tbody>
              {data.data.map((item: any) => (
                <tr key={item.id} className="border-b hover:bg-gray-50">
                  <td className="px-4 py-3 text-gray-500">{item.id}</td>
                  <td className="px-4 py-3 font-medium">{item.name || item.title || '-'}</td>
                  <td className="px-4 py-3 text-gray-500">{new Date(item.createdAt).toLocaleDateString('ja-JP')}</td>
                  <td className="px-4 py-3 text-right space-x-2">
                    <Link href={\`/admin/${lower_model}s/\${item.id}/edit\`} className="inline-flex p-1 text-blue-600 hover:bg-blue-50 rounded"><Pencil size={16} /></Link>
                    <button onClick={() => handleDelete(item.id)} disabled={deleting === item.id} className="inline-flex p-1 text-red-600 hover:bg-red-50 rounded disabled:opacity-50"><Trash2 size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </AdminLayout>
  );
}
LISTPAGE_EOF

        # New/Edit page
        cat > "${page_dir}/new/page.tsx" <<NEWPAGE_EOF
'use client';
import { useRouter } from 'next/navigation';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { useState } from 'react';

export default function New${model}Page() {
  const router = useRouter();
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitting(true);
    setError('');
    const formData = new FormData(e.currentTarget);
    const body = Object.fromEntries(formData);
    try {
      const res = await fetch('/api/admin/${lower_model}s', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(body),
      });
      if (!res.ok) throw new Error('作成に失敗しました');
      router.push('/admin/${lower_model}s');
    } catch (e: any) {
      setError(e.message);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <AdminLayout title="${model}作成" breadcrumbs={[{ label: 'Admin', href: '/admin' }, { label: '${model}管理', href: '/admin/${lower_model}s' }, { label: '新規作成' }]}>
      <div className="max-w-2xl bg-white p-6 rounded-lg shadow">
        {error && <p className="text-red-600 mb-4">{error}</p>}
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">名前</label>
            <input name="name" required className="w-full border rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:outline-none" />
          </div>
          <div className="flex gap-3">
            <button type="submit" disabled={submitting} className="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 disabled:opacity-50">
              {submitting ? '作成中...' : '作成'}
            </button>
            <button type="button" onClick={() => router.back()} className="px-6 py-2 border rounded-lg hover:bg-gray-50">キャンセル</button>
          </div>
        </form>
      </div>
    </AdminLayout>
  );
}
NEWPAGE_EOF

        APG_GENERATED_COUNT=$((APG_GENERATED_COUNT + 2))
        _apg_ok "CRUDページ生成: ${model} (list, new)"
    done
    return 0
}

# =============================================================================
# _apg_generate_user_management() - User management (list, create, edit, roles)
# =============================================================================
_apg_generate_user_management() {
    local project_dir="${1:-.}"

    _apg_log "ユーザー管理ページ生成"

    local users_dir="${project_dir}/src/app/admin/users"
    mkdir -p "${users_dir}"

    cat > "${users_dir}/page.tsx" <<'USERS_EOF'
'use client';
import useSWR from 'swr';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { Plus, Shield, Pencil, Trash2, MoreVertical } from 'lucide-react';
import Link from 'next/link';
import { useState } from 'react';

const fetcher = (url: string) => fetch(url).then(r => r.json());
const ROLES = ['admin', 'editor', 'viewer'] as const;

export default function UserManagementPage() {
  const { data, error, isLoading, mutate } = useSWR('/api/admin/users', fetcher);
  const [roleFilter, setRoleFilter] = useState<string>('all');
  const [search, setSearch] = useState('');

  const filteredUsers = data?.data?.filter((u: any) => {
    if (roleFilter !== 'all' && u.role !== roleFilter) return false;
    if (search && !u.name?.toLowerCase().includes(search.toLowerCase()) && !u.email?.toLowerCase().includes(search.toLowerCase())) return false;
    return true;
  }) ?? [];

  const handleRoleChange = async (userId: string, newRole: string) => {
    try {
      await fetch(`/api/admin/users/${userId}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ role: newRole }),
      });
      mutate();
    } catch { alert('ロール変更に失敗'); }
  };

  const handleDelete = async (userId: string) => {
    if (!confirm('このユーザーを削除しますか？')) return;
    try {
      await fetch(`/api/admin/users/${userId}`, { method: 'DELETE' });
      mutate();
    } catch { alert('削除に失敗'); }
  };

  return (
    <AdminLayout title="ユーザー管理" breadcrumbs={[{ label: 'Admin', href: '/admin' }, { label: 'ユーザー管理' }]}>
      <div className="flex flex-col sm:flex-row gap-4 mb-6">
        <input value={search} onChange={e => setSearch(e.target.value)} placeholder="名前・メールで検索..."
          className="border rounded-lg px-3 py-2 text-sm flex-1 focus:ring-2 focus:ring-blue-500 focus:outline-none" />
        <select value={roleFilter} onChange={e => setRoleFilter(e.target.value)}
          className="border rounded-lg px-3 py-2 text-sm">
          <option value="all">全ロール</option>
          {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
        </select>
        <Link href="/admin/users/new" className="bg-blue-600 text-white px-4 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 text-sm whitespace-nowrap">
          <Plus size={16} /> ユーザー追加
        </Link>
      </div>

      {isLoading && <div className="space-y-3">{[...Array(5)].map((_, i) => <div key={i} className="h-14 bg-gray-200 rounded animate-pulse" />)}</div>}
      {error && <p className="text-red-600">読み込みエラー</p>}

      {!isLoading && !error && (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b">
              <tr>
                <th className="text-left px-4 py-3 font-medium">ユーザー</th>
                <th className="text-left px-4 py-3 font-medium">ロール</th>
                <th className="text-left px-4 py-3 font-medium">ステータス</th>
                <th className="text-left px-4 py-3 font-medium">最終ログイン</th>
                <th className="text-right px-4 py-3 font-medium">操作</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map((user: any) => (
                <tr key={user.id} className="border-b hover:bg-gray-50">
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-medium text-sm">
                        {user.name?.charAt(0)?.toUpperCase() || '?'}
                      </div>
                      <div>
                        <p className="font-medium">{user.name}</p>
                        <p className="text-gray-500 text-xs">{user.email}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3">
                    <select value={user.role} onChange={e => handleRoleChange(user.id, e.target.value)}
                      className="text-xs border rounded px-2 py-1">
                      {ROLES.map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </td>
                  <td className="px-4 py-3">
                    <span className={`text-xs px-2 py-0.5 rounded-full ${user.active !== false ? 'bg-green-100 text-green-700' : 'bg-gray-100 text-gray-500'}`}>
                      {user.active !== false ? 'アクティブ' : '無効'}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-gray-500 text-xs">
                    {user.lastLoginAt ? new Date(user.lastLoginAt).toLocaleString('ja-JP') : '-'}
                  </td>
                  <td className="px-4 py-3 text-right space-x-1">
                    <Link href={`/admin/users/${user.id}/edit`} className="inline-flex p-1 text-blue-600 hover:bg-blue-50 rounded"><Pencil size={16} /></Link>
                    <button onClick={() => handleDelete(user.id)} className="inline-flex p-1 text-red-600 hover:bg-red-50 rounded"><Trash2 size={16} /></button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
          {filteredUsers.length === 0 && <p className="text-center py-8 text-gray-500">該当ユーザーなし</p>}
        </div>
      )}
    </AdminLayout>
  );
}
USERS_EOF

    APG_GENERATED_COUNT=$((APG_GENERATED_COUNT + 1))
    _apg_ok "ユーザー管理ページ生成完了"
    return 0
}

# =============================================================================
# _apg_generate_settings_page() - Settings page with sections
# =============================================================================
_apg_generate_settings_page() {
    local project_dir="${1:-.}"

    _apg_log "設定ページ生成"

    local settings_dir="${project_dir}/src/app/admin/settings"
    mkdir -p "$settings_dir"

    cat > "${settings_dir}/page.tsx" <<'SETTINGS_EOF'
'use client';
import { AdminLayout } from '@/components/admin/AdminLayout';
import { useState } from 'react';
import { Save, Globe, Bell, Shield, Palette } from 'lucide-react';

interface SettingSection {
  id: string;
  label: string;
  icon: React.ReactNode;
}

const sections: SettingSection[] = [
  { id: 'general', label: '一般', icon: <Globe size={18} /> },
  { id: 'notifications', label: '通知', icon: <Bell size={18} /> },
  { id: 'security', label: 'セキュリティ', icon: <Shield size={18} /> },
  { id: 'appearance', label: '外観', icon: <Palette size={18} /> },
];

export default function SettingsPage() {
  const [activeSection, setActiveSection] = useState('general');
  const [saving, setSaving] = useState(false);
  const [saved, setSaved] = useState(false);

  const handleSave = async () => {
    setSaving(true);
    try {
      await new Promise(r => setTimeout(r, 500));
      setSaved(true);
      setTimeout(() => setSaved(false), 2000);
    } finally {
      setSaving(false);
    }
  };

  return (
    <AdminLayout title="設定" breadcrumbs={[{ label: 'Admin', href: '/admin' }, { label: '設定' }]}>
      <div className="flex gap-6">
        <nav className="w-48 space-y-1">
          {sections.map(s => (
            <button key={s.id} onClick={() => setActiveSection(s.id)}
              className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg text-sm text-left ${
                activeSection === s.id ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-600 hover:bg-gray-50'
              }`}>
              {s.icon} {s.label}
            </button>
          ))}
        </nav>

        <div className="flex-1 bg-white rounded-lg shadow p-6">
          {activeSection === 'general' && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">一般設定</h3>
              <div><label className="block text-sm font-medium mb-1">サイト名</label>
                <input defaultValue="My App" className="w-full border rounded-lg px-3 py-2" /></div>
              <div><label className="block text-sm font-medium mb-1">サイトURL</label>
                <input defaultValue="https://example.com" className="w-full border rounded-lg px-3 py-2" /></div>
              <div><label className="block text-sm font-medium mb-1">言語</label>
                <select className="w-full border rounded-lg px-3 py-2">
                  <option value="ja">日本語</option><option value="en">English</option>
                </select></div>
            </div>
          )}
          {activeSection === 'notifications' && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">通知設定</h3>
              {['メール通知', 'プッシュ通知', 'Slack通知'].map(label => (
                <label key={label} className="flex items-center justify-between py-2 border-b">
                  <span>{label}</span>
                  <input type="checkbox" defaultChecked className="w-5 h-5 rounded" />
                </label>
              ))}
            </div>
          )}
          {activeSection === 'security' && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">セキュリティ設定</h3>
              <div><label className="block text-sm font-medium mb-1">セッションタイムアウト（分）</label>
                <input type="number" defaultValue="30" className="w-full border rounded-lg px-3 py-2" /></div>
              <label className="flex items-center justify-between py-2 border-b">
                <span>二要素認証を必須にする</span>
                <input type="checkbox" className="w-5 h-5 rounded" />
              </label>
            </div>
          )}
          {activeSection === 'appearance' && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold">外観設定</h3>
              <div><label className="block text-sm font-medium mb-1">テーマカラー</label>
                <input type="color" defaultValue="#2563eb" className="w-12 h-10 rounded border p-1" /></div>
              <label className="flex items-center justify-between py-2 border-b">
                <span>ダークモード</span>
                <input type="checkbox" className="w-5 h-5 rounded" />
              </label>
            </div>
          )}

          <div className="mt-6 flex items-center gap-3">
            <button onClick={handleSave} disabled={saving}
              className="bg-blue-600 text-white px-6 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 disabled:opacity-50">
              <Save size={16} /> {saving ? '保存中...' : '保存'}
            </button>
            {saved && <span className="text-green-600 text-sm">保存しました</span>}
          </div>
        </div>
      </div>
    </AdminLayout>
  );
}
SETTINGS_EOF

    APG_GENERATED_COUNT=$((APG_GENERATED_COUNT + 1))
    _apg_ok "設定ページ生成完了"
    return 0
}

# =============================================================================
# Module Registration
# =============================================================================
_mr_register \
    --name "admin-panel-generator" \
    --version "301.0" \
    --description "管理パネル自動生成エンジン（レイアウト/CRUD/ユーザー管理/設定）" \
    --init "apg_init" \
    --report "apg_report" \
    --score "apg_score" \
    --enable-var "ENABLE_ADMIN_PANEL_GENERATOR" \
    --cli-flags "--admin-panel:--no-admin-panel" \
    --init-msg "apg_init_message"
