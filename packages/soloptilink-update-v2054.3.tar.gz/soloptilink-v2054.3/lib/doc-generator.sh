#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - Doc Generator
# =============================================================================
# ドキュメント自動生成×OpenAPI×コンポーネントDocs×ERダイアグラム
#
# 機能:
#   - OpenAPI/Swagger仕様生成（ルートハンドラから抽出）
#   - コンポーネントドキュメント（propsテーブル、使用例）
#   - DBスキーマドキュメント（ERダイアグラム/Mermaid）
#   - 環境変数ドキュメント
#   - デプロイメントガイド
#   - コントリビューティングガイド
#   - README.md生成
#   - Claude生成プロンプト注入
#
# 全globals: DG_ prefix
# =============================================================================

[[ -n "${_DG_LOADED:-}" ]] && return 0; _DG_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g DG_VERSION="140.0"
declare -g DG_INITIALIZED=false
declare -g DG_GENERATED=0
declare -g DG_ERRORS=0
declare -g DG_PHASE="documentation"

# =============================================================================
# 初期化
# =============================================================================
dg_init() {
    DG_INITIALIZED=true
    DG_GENERATED=0
    DG_ERRORS=0
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} Doc Generator v${DG_VERSION}"
}

# =============================================================================
# ユーティリティ
# =============================================================================
_dg_write_file() {
    local filepath="$1"
    local dir
    dir=$(dirname "$filepath")
    mkdir -p "$dir" 2>/dev/null
    cat > "$filepath"
    if [[ $? -eq 0 ]]; then
        DG_GENERATED=$((DG_GENERATED + 1))
        return 0
    else
        DG_ERRORS=$((DG_ERRORS + 1))
        return 1
    fi
}

# =============================================================================
# OpenAPI仕様生成
# =============================================================================
dg_generate_api_docs() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local api_dir=""

    for candidate in "${project_dir}/app/api" "${project_dir}/src/app/api" "${project_dir}/pages/api"; do
        [[ -d "$candidate" ]] && api_dir="$candidate" && break
    done

    local project_name
    project_name=$(basename "$project_dir" | sed 's/-/ /g; s/_/ /g')
    [[ "$project_name" == "output" ]] && project_name="SoloptiLinkAI Project"

    # Start building OpenAPI spec
    local spec="openapi: '3.0.3'\ninfo:\n  title: '${project_name} API'\n  version: '1.0.0'\n  description: 'Auto-generated API documentation'\nservers:\n  - url: 'http://localhost:3000'\n    description: 'Development server'\npaths:\n"

    if [[ -n "$api_dir" ]]; then
        while IFS= read -r route_file; do
            [[ -z "$route_file" ]] && continue
            local rel_path="${route_file#${api_dir}}"
            rel_path="${rel_path%/route.ts}"
            rel_path="${rel_path%/route.js}"
            local api_path="/api${rel_path}"
            # Convert [param] to {param} for OpenAPI
            api_path=$(echo "$api_path" | sed 's/\[\([^]]*\)\]/{\1}/g')

            spec+="  ${api_path}:\n"

            # Detect methods
            for method in GET POST PUT PATCH DELETE; do
                if grep -qE "export\s+(async\s+)?function\s+${method}" "$route_file" 2>/dev/null; then
                    local lower_method
                    lower_method=$(echo "$method" | tr '[:upper:]' '[:lower:]')
                    local tag
                    tag=$(echo "$rel_path" | sed 's|^/||; s|/.*||')
                    [[ -z "$tag" ]] && tag="general"

                    spec+="    ${lower_method}:\n"
                    spec+="      tags: ['${tag}']\n"
                    spec+="      summary: '${method} ${api_path}'\n"
                    spec+="      responses:\n"
                    spec+="        '200':\n"
                    spec+="          description: 'Success'\n"
                    spec+="          content:\n"
                    spec+="            application/json:\n"
                    spec+="              schema:\n"
                    spec+="                type: object\n"

                    # Detect path parameters
                    if [[ "$api_path" == *"{"* ]]; then
                        spec+="      parameters:\n"
                        while [[ "$api_path" =~ \{([^}]+)\} ]]; do
                            local param="${BASH_REMATCH[1]}"
                            spec+="        - in: path\n"
                            spec+="          name: '${param}'\n"
                            spec+="          required: true\n"
                            spec+="          schema:\n"
                            spec+="            type: string\n"
                            api_path="${api_path/\{${param}\}/DONE}"
                        done
                    fi

                    # POST/PUT/PATCH have request body
                    if [[ "$method" == "POST" || "$method" == "PUT" || "$method" == "PATCH" ]]; then
                        spec+="      requestBody:\n"
                        spec+="        required: true\n"
                        spec+="        content:\n"
                        spec+="          application/json:\n"
                        spec+="            schema:\n"
                        spec+="              type: object\n"
                    fi
                fi
            done
        done < <(find "$api_dir" \( -name "route.ts" -o -name "route.js" \) 2>/dev/null | sort)
    fi

    _dg_write_file "${project_dir}/docs/api/openapi.yaml" <<< "$(echo -e "$spec")"

    echo "[doc-generator] Generated OpenAPI spec"
}

# =============================================================================
# コンポーネントドキュメント生成
# =============================================================================
dg_generate_component_docs() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local comp_dir=""

    for candidate in "${project_dir}/src/components" "${project_dir}/components"; do
        [[ -d "$candidate" ]] && comp_dir="$candidate" && break
    done

    [[ -z "$comp_dir" ]] && return 0

    local doc="# Component Documentation\n\n"
    doc+="Auto-generated component reference.\n\n"
    doc+="## Components\n\n"

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local comp_name
        comp_name=$(basename "$file" | sed 's/\.\(tsx\|jsx\)$//')
        [[ ! "$comp_name" =~ ^[A-Z] ]] && continue

        local rel_path="${file#${project_dir}/}"
        doc+="### ${comp_name}\n\n"
        doc+="**File:** \`${rel_path}\`\n\n"

        # Extract interface/type Props
        local props
        props=$(grep -A 20 'interface.*Props' "$file" 2>/dev/null | head -20 || true)
        if [[ -n "$props" ]]; then
            doc+="**Props:**\n\n"
            doc+="\`\`\`typescript\n${props}\n\`\`\`\n\n"
        fi

        # Extract JSDoc comments
        local jsdoc
        jsdoc=$(grep -B 5 "export.*function\|export default" "$file" 2>/dev/null | grep '^\s*\*\|/\*\*' | head -5 || true)
        if [[ -n "$jsdoc" ]]; then
            doc+="**Description:** ${jsdoc}\n\n"
        fi

        # Usage example
        doc+="**Usage:**\n\n"
        doc+="\`\`\`tsx\nimport { ${comp_name} } from '@/components/${comp_name}';\n\n"
        doc+="<${comp_name} />\n\`\`\`\n\n"
        doc+="---\n\n"
    done < <(find "$comp_dir" \( -name "*.tsx" -o -name "*.jsx" \) 2>/dev/null | sort)

    _dg_write_file "${project_dir}/docs/components.md" <<< "$(echo -e "$doc")"
    echo "[doc-generator] Generated component docs"
}

# =============================================================================
# DBスキーマドキュメント（ERダイアグラム）
# =============================================================================
dg_generate_db_schema_docs() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local schema_file=""

    for candidate in \
        "${project_dir}/prisma/schema.prisma" \
        "${project_dir}/src/prisma/schema.prisma"; do
        [[ -f "$candidate" ]] && schema_file="$candidate" && break
    done

    [[ -z "$schema_file" ]] && return 0

    local doc="# Database Schema Documentation\n\n"
    doc+="Auto-generated from \`${schema_file#${project_dir}/}\`.\n\n"
    doc+="## ER Diagram\n\n"
    doc+="\`\`\`mermaid\nerDiagram\n"

    local current_model=""
    local models_section=""
    local relations=""

    while IFS= read -r line; do
        # Model start
        if [[ "$line" =~ ^model[[:space:]]+([A-Za-z_][A-Za-z0-9_]*)[[:space:]]*\{ ]]; then
            current_model="${BASH_REMATCH[1]}"
            doc+="    ${current_model} {\n"
            models_section+="\n### ${current_model}\n\n"
            models_section+="| Field | Type | Required | Description |\n"
            models_section+="|-------|------|----------|-------------|\n"
            continue
        fi

        # Model end
        if [[ "$line" =~ ^\} && -n "$current_model" ]]; then
            doc+="    }\n"
            current_model=""
            continue
        fi

        # Field in model
        if [[ -n "$current_model" && "$line" =~ ^[[:space:]]+([a-zA-Z_][a-zA-Z0-9_]*)[[:space:]]+([A-Za-z\[\]?]+) ]]; then
            local field_name="${BASH_REMATCH[1]}"
            local field_type="${BASH_REMATCH[2]}"
            [[ "$field_name" == "@@"* || "$field_name" == "@"* ]] && continue

            local required="Yes"
            [[ "$field_type" == *"?" ]] && required="No"

            local clean_type="${field_type%\?}"
            local mermaid_type
            case "$clean_type" in
                String) mermaid_type="string" ;;
                Int) mermaid_type="int" ;;
                Float|Decimal) mermaid_type="float" ;;
                Boolean) mermaid_type="boolean" ;;
                DateTime) mermaid_type="datetime" ;;
                Json) mermaid_type="json" ;;
                *) mermaid_type="string" ;;
            esac

            local pk_marker=""
            if [[ "$line" == *"@id"* ]]; then
                pk_marker=" PK"
                mermaid_type="string PK"
            fi
            if [[ "$line" == *"@unique"* ]]; then
                mermaid_type="${mermaid_type} UK"
            fi

            doc+="        ${mermaid_type} ${field_name}\n"
            models_section+="| \`${field_name}\` | \`${field_type}\` | ${required} | ${pk_marker:+Primary Key} |\n"

            # Detect @relation for ER diagram
            if [[ "$line" == *"@relation"* ]]; then
                local ref_model="${clean_type%\[\]}"
                if [[ "$clean_type" == *"[]" ]]; then
                    relations+="    ${current_model} ||--o{ ${ref_model} : \"has many\"\n"
                else
                    relations+="    ${current_model} }o--|| ${ref_model} : \"belongs to\"\n"
                fi
            fi
        fi
    done < "$schema_file"

    doc+="${relations}"
    doc+="\`\`\`\n\n"
    doc+="## Models\n"
    doc+="${models_section}"

    _dg_write_file "${project_dir}/docs/database-schema.md" <<< "$(echo -e "$doc")"
    echo "[doc-generator] Generated DB schema docs with ER diagram"
}

# =============================================================================
# 環境変数ドキュメント
# =============================================================================
dg_generate_env_docs() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local doc="# Environment Variables\n\n"
    doc+="## Required Variables\n\n"
    doc+="| Variable | Description | Example | Required |\n"
    doc+="|----------|-------------|---------|----------|\n"

    # Scan for process.env references
    local env_vars=""
    if [[ -d "$project_dir" ]]; then
        env_vars=$(grep -rhE 'process\.env\.([A-Z_][A-Z0-9_]*)' "$project_dir" --include='*.ts' --include='*.tsx' --include='*.js' 2>/dev/null \
            | grep -v node_modules \
            | grep -oE 'process\.env\.([A-Z_][A-Z0-9_]*)' \
            | sed 's/process\.env\.//' \
            | sort -u || true)
    fi

    while IFS= read -r var; do
        [[ -z "$var" ]] && continue
        local description="" example="" required="Yes"

        case "$var" in
            DATABASE_URL) description="Database connection string"; example="postgresql://user:pass@localhost:5432/db" ;;
            NEXTAUTH_SECRET|JWT_SECRET|AUTH_SECRET) description="Authentication secret key"; example="your-secret-key-here"; required="Yes" ;;
            NEXTAUTH_URL|NEXT_PUBLIC_APP_URL) description="Application base URL"; example="http://localhost:3000" ;;
            NEXT_PUBLIC_*) description="Public client-side variable"; example=""; required="No" ;;
            REDIS_URL) description="Redis connection URL"; example="redis://localhost:6379" ;;
            SMTP_*|EMAIL_*) description="Email service configuration"; example=""; required="No" ;;
            AWS_*) description="AWS service configuration"; example="" ;;
            STRIPE_*) description="Stripe payment configuration"; example="" ;;
            NODE_ENV) description="Node.js environment"; example="development | production"; required="Yes" ;;
            *) description="Application configuration"; example="" ;;
        esac

        doc+="| \`${var}\` | ${description} | \`${example}\` | ${required} |\n"
    done <<< "$env_vars"

    doc+="\n## Setup\n\n"
    doc+="1. Copy the example env file:\n"
    doc+="\`\`\`bash\ncp .env.example .env\n\`\`\`\n\n"
    doc+="2. Fill in the required values.\n\n"
    doc+="3. For production, set environment variables in your hosting platform.\n"

    # Generate .env.example
    local env_example=""
    while IFS= read -r var; do
        [[ -z "$var" ]] && continue
        env_example+="# ${var}\n${var}=\n\n"
    done <<< "$env_vars"

    _dg_write_file "${project_dir}/docs/environment.md" <<< "$(echo -e "$doc")"

    if [[ -n "$env_example" ]]; then
        _dg_write_file "${project_dir}/.env.example" <<< "$(echo -e "$env_example")"
    fi

    echo "[doc-generator] Generated env docs"
}

# =============================================================================
# デプロイメントガイド生成
# =============================================================================
dg_generate_deployment_guide() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local framework="Next.js"

    # Detect framework
    if [[ -f "${project_dir}/next.config.js" || -f "${project_dir}/next.config.mjs" || -f "${project_dir}/next.config.ts" ]]; then
        framework="Next.js"
    elif [[ -f "${project_dir}/vite.config.ts" ]]; then
        framework="Vite"
    fi

    _dg_write_file "${project_dir}/docs/deployment.md" << MARKDOWN
# Deployment Guide

## Prerequisites

- Node.js 18+ (LTS recommended)
- npm or yarn
- PostgreSQL 15+ (or configured database)
- (Optional) Redis for caching

## Local Development

\`\`\`bash
# Install dependencies
npm install

# Setup database
npx prisma generate
npx prisma db push

# Seed database (optional)
npx prisma db seed

# Start dev server
npm run dev
\`\`\`

## Production Build

\`\`\`bash
# Build
npm run build

# Start production server
npm start
\`\`\`

## Vercel Deployment

1. Push your code to GitHub
2. Import project in [Vercel Dashboard](https://vercel.com/new)
3. Set environment variables in Project Settings
4. Deploy

Required environment variables for Vercel:
- \`DATABASE_URL\` - Production database URL
- \`NEXTAUTH_SECRET\` - Auth secret (generate with \`openssl rand -base64 32\`)
- \`NEXTAUTH_URL\` - Production URL

## Docker Deployment

\`\`\`dockerfile
FROM node:18-alpine AS base

FROM base AS deps
WORKDIR /app
COPY package.json package-lock.json ./
RUN npm ci --omit=dev

FROM base AS builder
WORKDIR /app
COPY --from=deps /app/node_modules ./node_modules
COPY . .
RUN npx prisma generate
RUN npm run build

FROM base AS runner
WORKDIR /app
ENV NODE_ENV=production
COPY --from=builder /app/public ./public
COPY --from=builder /app/.next/standalone ./
COPY --from=builder /app/.next/static ./.next/static
EXPOSE 3000
CMD ["node", "server.js"]
\`\`\`

## Database Migrations

\`\`\`bash
# Create migration
npx prisma migrate dev --name migration_name

# Apply migration in production
npx prisma migrate deploy
\`\`\`

## Troubleshooting

### Database Connection Fails
- Verify \`DATABASE_URL\` format: \`postgresql://USER:PASSWORD@HOST:PORT/DATABASE\`
- Ensure database server is running and accessible
- Check firewall/security group rules

### Build Errors
- Run \`npm run lint\` to check for TypeScript errors
- Ensure all environment variables are set
- Clear cache: \`rm -rf .next node_modules && npm install\`

### Memory Issues
- Set \`NODE_OPTIONS=--max-old-space-size=4096\` for large builds
MARKDOWN

    echo "[doc-generator] Generated deployment guide"
}

# =============================================================================
# コントリビューティングガイド生成
# =============================================================================
dg_generate_contributing_guide() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _dg_write_file "${project_dir}/docs/CONTRIBUTING.md" << 'MARKDOWN'
# Contributing Guide

Thank you for your interest in contributing!

## Development Setup

1. Fork and clone the repository
2. Install dependencies: `npm install`
3. Setup local database (see [Deployment Guide](./deployment.md))
4. Create a branch: `git checkout -b feature/your-feature`

## Code Style

- **TypeScript**: Strict mode enabled, no `any` types
- **Formatting**: Prettier with default config
- **Linting**: ESLint with Next.js recommended rules
- **Naming**: PascalCase for components, camelCase for functions/variables
- **Files**: kebab-case for file names

## Pull Request Process

1. Create a feature branch from `main`
2. Write/update tests for your changes
3. Ensure all tests pass: `npm test`
4. Ensure lint passes: `npm run lint`
5. Update documentation if needed
6. Submit PR with a clear description

## Commit Messages

Follow [Conventional Commits](https://www.conventionalcommits.org/):

```
feat: add user profile page
fix: resolve login redirect issue
docs: update API reference
chore: update dependencies
refactor: extract shared validation logic
test: add unit tests for auth service
```

## Testing

```bash
# Unit tests
npm test

# E2E tests
npm run test:e2e

# Type checking
npx tsc --noEmit

# Linting
npm run lint
```

## Architecture Decisions

- **API**: Next.js App Router with Route Handlers
- **Database**: Prisma ORM with PostgreSQL
- **Validation**: Zod for all input validation
- **Auth**: JWT with bcrypt password hashing
- **Styling**: Tailwind CSS

## Reporting Issues

- Use the issue template
- Include reproduction steps
- Include error messages and screenshots
MARKDOWN

    echo "[doc-generator] Generated contributing guide"
}

# =============================================================================
# README.md生成
# =============================================================================
dg_generate_readme() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local project_name
    project_name=$(basename "$project_dir" | sed 's/-/ /g; s/_/ /g; s/\b\(.\)/\u\1/g')
    [[ "$project_name" == "Output" ]] && project_name="SoloptiLinkAI Project"

    # Detect tech stack
    local tech_badges=""
    [[ -f "${project_dir}/next.config.js" || -f "${project_dir}/next.config.mjs" || -f "${project_dir}/next.config.ts" ]] && tech_badges+="![Next.js](https://img.shields.io/badge/Next.js-14-black) "
    [[ -f "${project_dir}/prisma/schema.prisma" ]] && tech_badges+="![Prisma](https://img.shields.io/badge/Prisma-5-blue) "
    [[ -f "${project_dir}/tailwind.config.ts" || -f "${project_dir}/tailwind.config.js" ]] && tech_badges+="![Tailwind](https://img.shields.io/badge/Tailwind-3-38B2AC) "
    [[ -f "${project_dir}/tsconfig.json" ]] && tech_badges+="![TypeScript](https://img.shields.io/badge/TypeScript-5-3178C6) "

    # Count entities
    local model_count=0 api_count=0 page_count=0
    if [[ -f "${project_dir}/prisma/schema.prisma" ]]; then
        model_count=$(grep -c '^model ' "${project_dir}/prisma/schema.prisma" 2>/dev/null || echo 0)
    fi
    local api_search_dir=""
    for candidate in "${project_dir}/app/api" "${project_dir}/src/app/api"; do
        [[ -d "$candidate" ]] && api_search_dir="$candidate" && break
    done
    if [[ -n "$api_search_dir" ]]; then
        api_count=$(find "$api_search_dir" -name "route.ts" 2>/dev/null | wc -l | tr -d ' ')
    fi

    _dg_write_file "${project_dir}/README.md" << MARKDOWN
# ${project_name}

${tech_badges}

## Overview

${project_name} - built with Next.js, TypeScript, Prisma, and Tailwind CSS.

## Quick Start

\`\`\`bash
# Install dependencies
npm install

# Setup database
npx prisma generate
npx prisma db push

# Start development server
npm run dev
\`\`\`

Open [http://localhost:3000](http://localhost:3000) in your browser.

## Project Stats

- **Models**: ${model_count}
- **API Routes**: ${api_count}
- **Framework**: Next.js 14 (App Router)
- **Database**: PostgreSQL + Prisma ORM
- **Auth**: JWT + bcrypt
- **Validation**: Zod

## Project Structure

\`\`\`
src/
  app/             # Next.js App Router pages
    api/           # API route handlers
  components/      # React components
  hooks/           # Custom React hooks
  lib/             # Shared utilities
  types/           # TypeScript types
prisma/
  schema.prisma    # Database schema
docs/              # Documentation
  api/             # OpenAPI spec
\`\`\`

## Documentation

- [API Reference](./docs/api/openapi.yaml) - OpenAPI 3.0 specification
- [Database Schema](./docs/database-schema.md) - ER diagram and model reference
- [Components](./docs/components.md) - Component documentation
- [Environment](./docs/environment.md) - Environment variable reference
- [Deployment](./docs/deployment.md) - Deployment guide
- [Contributing](./docs/CONTRIBUTING.md) - Contributing guidelines

## Scripts

| Command | Description |
|---------|-------------|
| \`npm run dev\` | Start development server |
| \`npm run build\` | Production build |
| \`npm start\` | Start production server |
| \`npm test\` | Run tests |
| \`npm run lint\` | Run ESLint |
| \`npx prisma studio\` | Open Prisma Studio |

## License

Private - All rights reserved.
MARKDOWN

    echo "[doc-generator] Generated README.md"
}

# =============================================================================
# Claudeプロンプト注入
# =============================================================================
dg_inject_doc_patterns() {
    local prompt="${1:-}"

    cat <<'INJECTION'

## [Documentation Patterns] ドキュメント生成ルール

### 必須ドキュメント（全プロジェクト共通）:
1. **README.md** - プロジェクト概要、クイックスタート、構造、スクリプト一覧
2. **OpenAPI spec** - 全APIエンドポイントの仕様（docs/api/openapi.yaml）
3. **DB Schema** - ERダイアグラム付きスキーマドキュメント（Mermaid形式）
4. **.env.example** - 必要な環境変数テンプレート（値は空）
5. **Deployment guide** - デプロイ手順（Vercel/Docker両対応）

### コード内ドキュメント:
- 全export関数にJSDoc（@param, @returns, @example）
- 複雑なロジックにはインラインコメント
- コンポーネントにはProps型定義 + 使用例
- API routeにはリクエスト/レスポンス型コメント

### 禁止:
- ドキュメントなしのpublic API
- .env.example なしのデプロイ
- JSDocなしのユーティリティ関数
INJECTION

    echo "$prompt"
}

# =============================================================================
# 全生成実行
# =============================================================================
dg_generate_docs() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    echo "[doc-generator] Generating project documentation..."
    dg_generate_api_docs "$project_dir"
    dg_generate_component_docs "$project_dir"
    dg_generate_db_schema_docs "$project_dir"
    dg_generate_env_docs "$project_dir"
    dg_generate_deployment_guide "$project_dir"
    dg_generate_contributing_guide "$project_dir"
    dg_generate_readme "$project_dir"
    echo "[doc-generator] Generated ${DG_GENERATED} files (${DG_ERRORS} errors)"
}

# =============================================================================
# レポート & スコア
# =============================================================================
dg_report() {
    echo -e "\n  ${BOLD:-}=== doc-generator v${DG_VERSION} ===${NC:-}"
    echo -e "  生成ファイル数: ${DG_GENERATED}"
    echo -e "  エラー: ${DG_ERRORS}"
    if [[ ${DG_GENERATED} -gt 0 ]]; then
        echo -e "  生成内容: OpenAPI, components, DB schema, env, deployment, contributing, README"
    fi
}

dg_score() {
    if [[ ${DG_GENERATED} -ge 6 ]] && [[ ${DG_ERRORS} -eq 0 ]]; then
        echo "95"
    elif [[ ${DG_GENERATED} -gt 0 ]] && [[ ${DG_ERRORS} -eq 0 ]]; then
        echo "90"
    elif [[ ${DG_GENERATED} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "doc-generator" --version "140.0" \
        --description "ドキュメント自動生成×OpenAPI×ERダイアグラム×README" \
        --init "dg_init" --report "dg_report" --score "dg_score" \
        --enable-var "ENABLE_DOC_GEN" --cli-flags "--doc-gen:--no-doc-gen"
fi

# v2003.1: source時のexit codeを確実に0にする
true
