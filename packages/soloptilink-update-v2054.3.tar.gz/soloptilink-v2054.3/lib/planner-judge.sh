#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v16.0 - Planner-Worker-Judge Engine
# =============================================================================
# Implements the industry-validated Planner-Worker-Judge pattern:
#
#   1. PLANNER: Analyzes the task, creates a detailed execution plan
#      - Breaks complex tasks into subtasks
#      - Assigns model tier per subtask
#      - Sets acceptance criteria and confidence threshold
#
#   2. WORKER: Executes each subtask through the appropriate agent
#      - Routes through model-router for optimal model selection
#      - Tracks progress and outputs per subtask
#      - Supports retry with escalation (Haiku → Sonnet → Opus)
#
#   3. JUDGE: Evaluates the quality of worker output
#      - Scores output against acceptance criteria
#      - Decides: accept, rework (with feedback), or escalate
#      - Uses economy model for cost-efficient evaluation
#
# Functions:
#   pj_init              - Initialize Planner-Judge engine
#   pj_plan              - Generate execution plan for a task
#   pj_execute           - Execute a plan (run all subtasks)
#   pj_judge             - Judge the quality of an output
#   pj_execute_subtask   - Execute a single subtask with retry
#   pj_escalate          - Escalate subtask to higher model tier
#   pj_get_plan_status   - Get current plan execution status
#   pj_report            - Print execution report
#   pj_export_json       - Export plan data as JSON
#
# All globals use the PJ_ prefix.
# =============================================================================

[[ -n "${_PLANNER_JUDGE_LOADED:-}" ]] && return 0
_PLANNER_JUDGE_LOADED=1

# ============================================================
# State
# ============================================================
declare -g PJ_ENABLED="false"
declare -g PJ_SESSION_ID=""
declare -g PJ_CONFIDENCE_THRESHOLD="0.7"  # Minimum acceptable confidence
declare -g PJ_MAX_REWORK=3                # Max rework attempts per subtask
declare -g PJ_MAX_ESCALATIONS=2           # Max tier escalations per subtask

# Execution statistics
declare -g PJ_PLANS_CREATED=0
declare -g PJ_SUBTASKS_TOTAL=0
declare -g PJ_SUBTASKS_ACCEPTED=0
declare -g PJ_SUBTASKS_REWORKED=0
declare -g PJ_SUBTASKS_ESCALATED=0
declare -g PJ_SUBTASKS_FAILED=0
declare -g PJ_JUDGE_CALLS=0

# Current plan state
declare -g PJ_CURRENT_PLAN_FILE=""
declare -g PJ_CURRENT_PLAN_PHASE=""

# ============================================================
# Internal logger
# ============================================================
_pj_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    [[ "$level" == "SUCCESS" ]] && color="${GREEN:-}"
    [[ "$level" == "JUDGE" ]] && color="${PURPLE:-}"
    echo -e "  ${color}[PLANNER-JUDGE]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize Planner-Judge engine
# ============================================================
pj_init() {
    local session_id="${1:-${SESSION_ID:-unknown}}"
    local confidence="${2:-${PJ_CONFIDENCE_THRESHOLD}}"

    PJ_SESSION_ID="$session_id"
    PJ_CONFIDENCE_THRESHOLD="$confidence"
    PJ_ENABLED="true"

    PJ_PLANS_CREATED=0
    PJ_SUBTASKS_TOTAL=0
    PJ_SUBTASKS_ACCEPTED=0
    PJ_SUBTASKS_REWORKED=0
    PJ_SUBTASKS_ESCALATED=0
    PJ_SUBTASKS_FAILED=0
    PJ_JUDGE_CALLS=0

    local plans_dir="${SESSION_LOG_DIR:-/tmp}/plans"
    mkdir -p "$plans_dir" 2>/dev/null || true

    _pj_log "SUCCESS" "Planner-Judge v16.0 初期化: 信頼度閾値=${confidence}"
    return 0
}

# ============================================================
# PLANNER: Generate execution plan for a task
# Uses frontier model for planning quality
# ============================================================
pj_plan() {
    local phase="${1:?pj_plan: phase required}"
    local task_desc="${2:?pj_plan: task_desc required}"
    local context="${3:-}"

    PJ_CURRENT_PLAN_PHASE="$phase"
    PJ_PLANS_CREATED=$((PJ_PLANS_CREATED + 1))

    local plans_dir="${SESSION_LOG_DIR:-/tmp}/plans"
    PJ_CURRENT_PLAN_FILE="${plans_dir}/plan_${phase}_$(date +%s).json"

    # Build planning prompt
    local plan_prompt="あなたは SoloptiLink Chain のプランナーです。以下のタスクを分析し、サブタスクに分解してください。

## フェーズ: ${phase}
## タスク: ${task_desc}

${context:+## コンテキスト:
${context}
}
以下のJSON形式で実行計画を出力してください:
{
  \"phase\": \"${phase}\",
  \"subtasks\": [
    {
      \"id\": 1,
      \"name\": \"サブタスク名\",
      \"description\": \"詳細説明\",
      \"model_tier\": \"balanced\",
      \"acceptance_criteria\": \"受け入れ基準の説明\",
      \"estimated_tokens\": 5000,
      \"dependencies\": []
    }
  ],
  \"total_subtasks\": 3,
  \"estimated_total_tokens\": 15000
}

サブタスクは2-8個に分解し、各サブタスクのmodel_tierは \"frontier\"/\"balanced\"/\"economy\" から選択してください。
JSONのみを出力し、他の説明は不要です。"

    # Use frontier model for planning (if model router available)
    local model_tier="frontier"
    local plan_output=""

    if type -t mr_get_model_flag &>/dev/null && [[ "${MR_ENABLED:-false}" == "true" ]]; then
        local model_flag
        model_flag=$(mr_get_model_flag "$model_tier")
        plan_output=$(timeout 120 claude -p \
            --dangerously-skip-permissions \
            --output-format text \
            ${model_flag} \
            "$plan_prompt" 2>/dev/null) || plan_output=""

        type -t mr_record_usage &>/dev/null && mr_record_usage "frontier" 2000 3000 2>/dev/null || true
    else
        # Fallback: use default model
        plan_output=$(timeout 120 claude -p \
            --dangerously-skip-permissions \
            --output-format text \
            "$plan_prompt" 2>/dev/null) || plan_output=""
    fi

    if [[ -z "$plan_output" ]]; then
        _pj_log "WARN" "プラン生成失敗: デフォルトプランを使用"
        # Generate a default single-subtask plan
        plan_output="{
  \"phase\": \"${phase}\",
  \"subtasks\": [
    {
      \"id\": 1,
      \"name\": \"${phase} 実行\",
      \"description\": \"${task_desc}\",
      \"model_tier\": \"balanced\",
      \"acceptance_criteria\": \"エラーなく完了すること\",
      \"estimated_tokens\": 10000,
      \"dependencies\": []
    }
  ],
  \"total_subtasks\": 1,
  \"estimated_total_tokens\": 10000
}"
    fi

    # Extract JSON from output (handle markdown code blocks)
    local clean_json
    clean_json=$(echo "$plan_output" | python3 -c "
import sys, json, re
text = sys.stdin.read()
# Try to extract JSON from markdown code blocks
match = re.search(r'\`\`\`(?:json)?\s*\n?(.*?)\`\`\`', text, re.DOTALL)
if match:
    text = match.group(1)
# Try to find JSON object
match = re.search(r'\{.*\}', text, re.DOTALL)
if match:
    try:
        parsed = json.loads(match.group(0))
        print(json.dumps(parsed, ensure_ascii=False, indent=2))
    except:
        print(match.group(0))
else:
    print(text)
" 2>/dev/null) || clean_json="$plan_output"

    # Save plan
    echo "$clean_json" > "$PJ_CURRENT_PLAN_FILE" 2>/dev/null

    # Count subtasks
    if command -v python3 &>/dev/null; then
        local subtask_count
        subtask_count=$(python3 -c "
import json, sys
try:
    plan = json.loads(sys.stdin.read())
    print(len(plan.get('subtasks', [])))
except: print(1)
" <<< "$clean_json" 2>/dev/null) || subtask_count=1
        PJ_SUBTASKS_TOTAL=$((PJ_SUBTASKS_TOTAL + subtask_count))
    fi

    _pj_log "SUCCESS" "プラン生成完了: ${PJ_CURRENT_PLAN_FILE}"
    echo "$PJ_CURRENT_PLAN_FILE"
}

# ============================================================
# WORKER: Execute a single subtask with retry and escalation
# ============================================================
pj_execute_subtask() {
    local subtask_json="${1:?pj_execute_subtask: subtask_json required}"
    local phase="${2:-${PJ_CURRENT_PLAN_PHASE:-unknown}}"
    local full_context="${3:-}"

    # Parse subtask
    local subtask_name subtask_desc model_tier criteria
    if command -v python3 &>/dev/null; then
        subtask_name=$(python3 -c "import json,sys; d=json.loads(sys.argv[1]); print(d.get('name',''))" "$subtask_json" 2>/dev/null)
        subtask_desc=$(python3 -c "import json,sys; d=json.loads(sys.argv[1]); print(d.get('description',''))" "$subtask_json" 2>/dev/null)
        model_tier=$(python3 -c "import json,sys; d=json.loads(sys.argv[1]); print(d.get('model_tier','balanced'))" "$subtask_json" 2>/dev/null)
        criteria=$(python3 -c "import json,sys; d=json.loads(sys.argv[1]); print(d.get('acceptance_criteria',''))" "$subtask_json" 2>/dev/null)
    else
        subtask_name="subtask"
        subtask_desc="$subtask_json"
        model_tier="balanced"
        criteria=""
    fi

    _pj_log "INFO" "Worker実行: '${subtask_name}' [${model_tier}]"

    local attempt=0
    local max_attempts=$((PJ_MAX_REWORK + PJ_MAX_ESCALATIONS))
    local current_tier="$model_tier"
    local escalation_count=0
    local rework_count=0
    local result=""
    local accepted="false"

    while [[ $attempt -lt $max_attempts && "$accepted" != "true" ]]; do
        attempt=$((attempt + 1))

        # Build worker prompt
        local worker_prompt="## サブタスク: ${subtask_name}
${subtask_desc}

${full_context:+## コンテキスト:
${full_context}
}
## 受け入れ基準:
${criteria:-エラーなく、正しく動作するコードを出力すること}

完全なコードを出力してください。省略やプレースホルダーは不可。"

        # Add rework feedback if this is a retry
        if [[ $attempt -gt 1 && -n "${_PJ_LAST_FEEDBACK:-}" ]]; then
            worker_prompt+="

## 前回のフィードバック（修正必須）:
${_PJ_LAST_FEEDBACK}"
        fi

        # Execute through model router
        if type -t mr_get_model_flag &>/dev/null && [[ "${MR_ENABLED:-false}" == "true" ]]; then
            local model_flag
            model_flag=$(mr_get_model_flag "$current_tier")
            result=$(timeout 300 claude -p \
                --dangerously-skip-permissions \
                --output-format text \
                ${model_flag} \
                "$worker_prompt" 2>/dev/null) || result=""

            type -t mr_record_usage &>/dev/null && mr_record_usage "$current_tier" 3000 5000 2>/dev/null || true
        else
            result=$(timeout 300 claude -p \
                --dangerously-skip-permissions \
                --output-format text \
                "$worker_prompt" 2>/dev/null) || result=""
        fi

        if [[ -z "$result" ]]; then
            _pj_log "WARN" "Worker出力なし (attempt ${attempt}/${max_attempts})"
            continue
        fi

        # JUDGE the output
        local judge_result
        judge_result=$(pj_judge "$result" "$criteria" "$subtask_name")
        local confidence
        confidence=$(echo "$judge_result" | head -1)
        local feedback
        feedback=$(echo "$judge_result" | tail -n +2)

        _pj_log "JUDGE" "信頼度: ${confidence} (閾値: ${PJ_CONFIDENCE_THRESHOLD}) - ${subtask_name}"

        # Check if accepted
        local meets_threshold="false"
        if command -v bc &>/dev/null; then
            meets_threshold=$(echo "${confidence} >= ${PJ_CONFIDENCE_THRESHOLD}" | bc 2>/dev/null || echo "0")
        elif command -v awk &>/dev/null; then
            meets_threshold=$(awk "BEGIN{print (${confidence} >= ${PJ_CONFIDENCE_THRESHOLD}) ? 1 : 0}" 2>/dev/null)
        fi

        if [[ "$meets_threshold" == "1" ]]; then
            accepted="true"
            PJ_SUBTASKS_ACCEPTED=$((PJ_SUBTASKS_ACCEPTED + 1))
            _pj_log "SUCCESS" "サブタスク承認: '${subtask_name}' (confidence=${confidence})"
        else
            # Decide: rework or escalate
            _PJ_LAST_FEEDBACK="$feedback"

            if [[ $rework_count -lt $PJ_MAX_REWORK ]]; then
                rework_count=$((rework_count + 1))
                PJ_SUBTASKS_REWORKED=$((PJ_SUBTASKS_REWORKED + 1))
                _pj_log "WARN" "再作業要求 (${rework_count}/${PJ_MAX_REWORK}): ${subtask_name}"
            elif [[ $escalation_count -lt $PJ_MAX_ESCALATIONS ]]; then
                # Escalate to higher tier
                current_tier=$(pj_escalate "$current_tier")
                escalation_count=$((escalation_count + 1))
                PJ_SUBTASKS_ESCALATED=$((PJ_SUBTASKS_ESCALATED + 1))
                _pj_log "WARN" "エスカレーション (${escalation_count}/${PJ_MAX_ESCALATIONS}): ${subtask_name} → ${current_tier}"
            fi
        fi
    done

    if [[ "$accepted" != "true" ]]; then
        PJ_SUBTASKS_FAILED=$((PJ_SUBTASKS_FAILED + 1))
        _pj_log "ERROR" "サブタスク失敗: '${subtask_name}' (${max_attempts}回試行後)"
    fi

    unset _PJ_LAST_FEEDBACK
    echo "$result"
}

# ============================================================
# JUDGE: Evaluate the quality of worker output
# Uses economy model for cost-efficient evaluation
# ============================================================
pj_judge() {
    local output="${1:?pj_judge: output required}"
    local criteria="${2:-エラーなく完了すること}"
    local subtask_name="${3:-subtask}"

    PJ_JUDGE_CALLS=$((PJ_JUDGE_CALLS + 1))

    # Truncate output for judge (save tokens)
    local output_sample="${output:0:8000}"

    local judge_prompt="あなたは品質判定官（Judge）です。以下のコード出力を評価してください。

## サブタスク: ${subtask_name}

## 受け入れ基準:
${criteria}

## 出力（先頭8000文字）:
${output_sample}

以下の形式で評価を出力してください（最初の行に信頼度スコア、2行目以降にフィードバック）:
0.85
フィードバック: コードは基準を満たしています。型定義が一部不足していますが、動作に支障はありません。

信頼度スコアは 0.0-1.0 の小数で、基準を完全に満たす場合は 0.9 以上としてください。
不足がある場合は具体的な改善点をフィードバックに記述してください。"

    local judge_output=""

    # Use economy model for judging
    if type -t mr_get_model_flag &>/dev/null && [[ "${MR_ENABLED:-false}" == "true" ]]; then
        local model_flag
        model_flag=$(mr_get_model_flag "economy")
        judge_output=$(timeout 60 claude -p \
            --dangerously-skip-permissions \
            --output-format text \
            ${model_flag} \
            "$judge_prompt" 2>/dev/null) || judge_output=""

        type -t mr_record_usage &>/dev/null && mr_record_usage "economy" 3000 500 2>/dev/null || true
    else
        judge_output=$(timeout 60 claude -p \
            --dangerously-skip-permissions \
            --output-format text \
            "$judge_prompt" 2>/dev/null) || judge_output=""
    fi

    if [[ -z "$judge_output" ]]; then
        # Default: accept with moderate confidence
        echo "0.75"
        echo "Judge応答なし: デフォルト信頼度0.75を適用"
        return 0
    fi

    # Extract confidence score from first line
    local confidence
    confidence=$(echo "$judge_output" | head -1 | grep -oE '[0-9]+\.[0-9]+' | head -1)

    if [[ -z "$confidence" ]]; then
        confidence="0.75"
    fi

    # Clamp to 0-1 range
    if command -v bc &>/dev/null; then
        local valid
        valid=$(echo "${confidence} >= 0 && ${confidence} <= 1" | bc 2>/dev/null || echo "0")
        [[ "$valid" != "1" ]] && confidence="0.75"
    fi

    echo "$confidence"
    echo "$judge_output" | tail -n +2
}

# ============================================================
# Escalate to higher model tier
# ============================================================
pj_escalate() {
    local current_tier="${1:-economy}"

    case "$current_tier" in
        economy)  echo "balanced" ;;
        balanced) echo "frontier" ;;
        frontier) echo "frontier" ;;  # Already highest
        *)        echo "balanced" ;;
    esac
}

# ============================================================
# Execute full plan
# ============================================================
pj_execute() {
    local plan_file="${1:-${PJ_CURRENT_PLAN_FILE}}"
    local full_context="${2:-}"

    [[ ! -f "$plan_file" ]] && { _pj_log "ERROR" "プランファイルなし: ${plan_file}"; return 1; }

    local plan_json
    plan_json=$(cat "$plan_file" 2>/dev/null)

    if ! command -v python3 &>/dev/null; then
        _pj_log "ERROR" "python3が必要です"
        return 1
    fi

    local subtask_count
    subtask_count=$(python3 -c "
import json, sys
try:
    plan = json.loads(sys.stdin.read())
    print(len(plan.get('subtasks', [])))
except: print(0)
" <<< "$plan_json" 2>/dev/null) || subtask_count=0

    if [[ $subtask_count -eq 0 ]]; then
        _pj_log "WARN" "サブタスクなし: スキップ"
        return 0
    fi

    _pj_log "INFO" "プラン実行開始: ${subtask_count}サブタスク"

    local all_outputs=""

    for i in $(seq 0 $((subtask_count - 1))); do
        local subtask_json
        subtask_json=$(python3 -c "
import json, sys
plan = json.loads(sys.stdin.read())
subtasks = plan.get('subtasks', [])
if $i < len(subtasks):
    print(json.dumps(subtasks[$i], ensure_ascii=False))
else:
    print('{}')
" <<< "$plan_json" 2>/dev/null)

        local output
        output=$(pj_execute_subtask "$subtask_json" "$PJ_CURRENT_PLAN_PHASE" "$full_context")
        all_outputs+="${output}\n\n"

        # Record episode for memory manager
        if type -t mm_record_episode &>/dev/null && [[ "${MM_ENABLED:-false}" == "true" ]]; then
            local subtask_name
            subtask_name=$(python3 -c "import json,sys; print(json.loads(sys.argv[1]).get('name',''))" "$subtask_json" 2>/dev/null)
            mm_record_episode "$PJ_CURRENT_PLAN_PHASE" "success" "Subtask '${subtask_name}' completed" 2>/dev/null || true
        fi
    done

    echo -e "$all_outputs"
}

# ============================================================
# Get current plan execution status
# ============================================================
pj_get_plan_status() {
    echo "plans_created=${PJ_PLANS_CREATED}"
    echo "subtasks_total=${PJ_SUBTASKS_TOTAL}"
    echo "subtasks_accepted=${PJ_SUBTASKS_ACCEPTED}"
    echo "subtasks_reworked=${PJ_SUBTASKS_REWORKED}"
    echo "subtasks_escalated=${PJ_SUBTASKS_ESCALATED}"
    echo "subtasks_failed=${PJ_SUBTASKS_FAILED}"
    echo "judge_calls=${PJ_JUDGE_CALLS}"
}

# ============================================================
# Execution report (ASCII)
# ============================================================
pj_report() {
    echo ""
    echo -e "  ${BOLD:-}${CYAN:-}[Planner-Judge Report] v16.0${NC:-}"
    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    echo -e "  信頼度閾値:         ${PJ_CONFIDENCE_THRESHOLD}"
    echo -e "  プラン生成:         ${PJ_PLANS_CREATED}"
    echo -e "  サブタスク合計:     ${PJ_SUBTASKS_TOTAL}"
    echo ""
    printf "  %-20s  %8s\n" "Status" "Count"
    echo -e "  ────────────────────  ────────"
    printf "  %-20s  ${GREEN:-}%8d${NC:-}\n" "✅ 承認 (Accepted)" "$PJ_SUBTASKS_ACCEPTED"
    printf "  %-20s  ${YELLOW:-}%8d${NC:-}\n" "🔄 再作業 (Reworked)" "$PJ_SUBTASKS_REWORKED"
    printf "  %-20s  ${YELLOW:-}%8d${NC:-}\n" "⬆️ エスカレーション" "$PJ_SUBTASKS_ESCALATED"
    printf "  %-20s  ${RED:-}%8d${NC:-}\n" "❌ 失敗 (Failed)" "$PJ_SUBTASKS_FAILED"
    echo -e "  ────────────────────  ────────"
    printf "  %-20s  %8d\n" "Judge呼び出し" "$PJ_JUDGE_CALLS"

    # Acceptance rate
    if [[ $PJ_SUBTASKS_TOTAL -gt 0 ]]; then
        local rate=$((PJ_SUBTASKS_ACCEPTED * 100 / PJ_SUBTASKS_TOTAL))
        echo ""
        echo -e "  承認率: ${rate}%"
    fi

    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    echo ""
}

# ============================================================
# Export plan data as JSON
# ============================================================
pj_export_json() {
    local output_file="${1:-${SESSION_LOG_DIR:-/tmp}/observatory/planner_judge_report.json}"

    local acceptance_rate=0
    [[ $PJ_SUBTASKS_TOTAL -gt 0 ]] && acceptance_rate=$((PJ_SUBTASKS_ACCEPTED * 100 / PJ_SUBTASKS_TOTAL))

    {
        echo "{"
        echo "  \"version\": \"16.0\","
        echo "  \"session_id\": \"${PJ_SESSION_ID}\","
        echo "  \"confidence_threshold\": \"${PJ_CONFIDENCE_THRESHOLD}\","
        echo "  \"plans_created\": ${PJ_PLANS_CREATED},"
        echo "  \"subtasks\": {"
        echo "    \"total\": ${PJ_SUBTASKS_TOTAL},"
        echo "    \"accepted\": ${PJ_SUBTASKS_ACCEPTED},"
        echo "    \"reworked\": ${PJ_SUBTASKS_REWORKED},"
        echo "    \"escalated\": ${PJ_SUBTASKS_ESCALATED},"
        echo "    \"failed\": ${PJ_SUBTASKS_FAILED}"
        echo "  },"
        echo "  \"judge_calls\": ${PJ_JUDGE_CALLS},"
        echo "  \"acceptance_rate\": ${acceptance_rate}"
        echo "}"
    } > "$output_file" 2>/dev/null || true
}
