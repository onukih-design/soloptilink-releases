#!/usr/bin/env bash
# ============================================================
# SoloptiLink Chain v13.0 - Multi-Agent Orchestrator
# ============================================================
# Manages multiple Claude Code agent sessions. Each agent is
# defined by an .md system prompt and dispatched via Claude CLI.
# Supports parallel dispatch, result collection, and iterative
# implement-then-review cycles.
#
# Functions:
#   ao_init              - Initialize orchestrator session
#   ao_register_agent    - Register an agent definition
#   ao_dispatch          - Dispatch a single agent task
#   ao_dispatch_parallel - Launch multiple agents in parallel
#   ao_collect_results   - Wait for and collect agent outputs
#   ao_review_cycle      - Implement -> review -> fix loop
#   ao_report            - Print session summary
#
# All globals use the AO_ prefix.
# Sourced by the main orchestrator -- do NOT use set -euo pipefail.

[[ -n "${_AGENT_ORCHESTRATOR_LOADED:-}" ]] && return 0
_AGENT_ORCHESTRATOR_LOADED=1
# ============================================================

###############################################################
# Global state
###############################################################

AO_GREEN='\033[0;32m';  AO_RED='\033[0;31m';    AO_YELLOW='\033[1;33m'
AO_CYAN='\033[0;36m';   AO_BLUE='\033[0;34m';   AO_MAGENTA='\033[0;35m'
AO_BOLD='\033[1m';      AO_DIM='\033[2m';        AO_RESET='\033[0m'

declare -g    AO_SESSION_ID=""
declare -g    AO_OUTPUT_DIR=""
declare -g    AO_START_TIME=0
declare -g    AO_TOTAL_DISPATCHES=0
declare -g    AO_SUCCEEDED=0
declare -g    AO_FAILED=0

# Agent registry: agent_id -> md_path
declare -g -A AO_AGENT_PATHS=()
# Agent registry: agent_id -> role
declare -g -A AO_AGENT_ROLES=()
# PID tracking: agent_id -> PID
declare -g -A AO_PIDS=()
# Status tracking: agent_id -> status (pending|running|success|failed)
declare -g -A AO_STATUS=()
# Output tracking: agent_id -> output_file
declare -g -A AO_OUTPUTS=()
# Timing: agent_id -> duration_seconds
declare -g -A AO_DURATIONS=()

# Claude CLI timeout per agent dispatch (seconds)
AO_AGENT_TIMEOUT="${AO_AGENT_TIMEOUT:-300}"

###############################################################
# Helpers
###############################################################

_ao_log() {
    local level="$1" message="$2"
    local color="${AO_RESET}"
    case "$level" in
        INFO)     color="${AO_CYAN}"    ;;
        SUCCESS)  color="${AO_GREEN}"   ;;
        WARN)     color="${AO_YELLOW}"  ;;
        ERROR)    color="${AO_RED}"     ;;
        DISPATCH) color="${AO_MAGENTA}" ;;
    esac
    echo -e "  ${color}[AO:${level}]${AO_RESET} ${message}"
    if [[ -n "$AO_OUTPUT_DIR" ]]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [${level}] ${message}" \
            >> "${AO_OUTPUT_DIR}/agent-orchestrator.log" 2>/dev/null || true
    fi
}

_ao_timestamp() { date +%s; }

###############################################################
# ao_init(session_id)
#   Initialize an orchestrator session.
###############################################################
ao_init() {
    local session_id="${1:-ao-$(date +%Y%m%d-%H%M%S)}"
    AO_SESSION_ID="$session_id"
    AO_START_TIME=$(_ao_timestamp)
    AO_TOTAL_DISPATCHES=0
    AO_SUCCEEDED=0
    AO_FAILED=0

    # Determine output directory
    if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
        AO_OUTPUT_DIR="${SESSION_LOG_DIR}/agents"
    else
        AO_OUTPUT_DIR="/tmp/soloptilink-agents/${AO_SESSION_ID}"
    fi
    mkdir -p "${AO_OUTPUT_DIR}/outputs" "${AO_OUTPUT_DIR}/logs"

    # Reset registries
    AO_AGENT_PATHS=()
    AO_AGENT_ROLES=()
    AO_PIDS=()
    AO_STATUS=()
    AO_OUTPUTS=()
    AO_DURATIONS=()

    _ao_log "INFO" "Agent Orchestrator initialized  session=${AO_SESSION_ID}"
    _ao_log "INFO" "Output directory: ${AO_OUTPUT_DIR}"
    return 0
}

###############################################################
# ao_register_agent(agent_id, agent_md_path, role)
#   Register an agent definition for later dispatch.
###############################################################
ao_register_agent() {
    local agent_id="$1" agent_md_path="$2" role="${3:-general}"

    if [[ -z "$agent_id" || -z "$agent_md_path" ]]; then
        _ao_log "ERROR" "ao_register_agent: agent_id and agent_md_path are required"
        return 1
    fi
    if [[ ! -f "$agent_md_path" ]]; then
        _ao_log "ERROR" "Agent definition not found: ${agent_md_path}"
        return 1
    fi

    AO_AGENT_PATHS[$agent_id]="$agent_md_path"
    AO_AGENT_ROLES[$agent_id]="$role"
    AO_STATUS[$agent_id]="registered"

    _ao_log "INFO" "Registered agent: ${AO_BOLD}${agent_id}${AO_RESET} role=${role} md=${agent_md_path}"
    return 0
}

###############################################################
# ao_dispatch(agent_id, task_prompt, output_file)
#   Launch a single agent task via Claude CLI.
#   Blocks until the agent completes.
#   Returns 0 on success, 1 on failure.
###############################################################
ao_dispatch() {
    local agent_id="$1" task_prompt="$2" output_file="${3:-}"

    if [[ -z "${AO_AGENT_PATHS[$agent_id]:-}" ]]; then
        _ao_log "ERROR" "Agent not registered: ${agent_id}"
        return 1
    fi

    local agent_md="${AO_AGENT_PATHS[$agent_id]}"
    [[ -z "$output_file" ]] && output_file="${AO_OUTPUT_DIR}/outputs/${agent_id}-$(date +%s).txt"

    AO_OUTPUTS[$agent_id]="$output_file"
    AO_STATUS[$agent_id]="running"
    AO_TOTAL_DISPATCHES=$((AO_TOTAL_DISPATCHES + 1))

    _ao_log "DISPATCH" "Dispatching ${AO_BOLD}${agent_id}${AO_RESET} (${AO_AGENT_ROLES[$agent_id]:-unknown})"

    local start_ts
    start_ts=$(_ao_timestamp)

    # Launch Claude CLI with the agent's system prompt
    if command -v timeout &>/dev/null; then
        timeout "${AO_AGENT_TIMEOUT}" \
            claude -p --dangerously-skip-permissions --output-format text \
            -a "$agent_md" "$task_prompt" \
            > "$output_file" 2>"${AO_OUTPUT_DIR}/logs/${agent_id}.stderr"
    else
        claude -p --dangerously-skip-permissions --output-format text \
            -a "$agent_md" "$task_prompt" \
            > "$output_file" 2>"${AO_OUTPUT_DIR}/logs/${agent_id}.stderr"
    fi
    local exit_code=$?

    local end_ts
    end_ts=$(_ao_timestamp)
    AO_DURATIONS[$agent_id]=$(( end_ts - start_ts ))

    if [[ $exit_code -eq 0 ]]; then
        AO_STATUS[$agent_id]="success"
        AO_SUCCEEDED=$((AO_SUCCEEDED + 1))
        _ao_log "SUCCESS" "Agent ${agent_id} completed in ${AO_DURATIONS[$agent_id]}s  output=${output_file}"
    else
        AO_STATUS[$agent_id]="failed"
        AO_FAILED=$((AO_FAILED + 1))
        _ao_log "ERROR" "Agent ${agent_id} failed (exit=${exit_code}) after ${AO_DURATIONS[$agent_id]}s"
    fi

    return $exit_code
}

###############################################################
# ao_dispatch_parallel(agents_json)
#   Launch multiple agents in parallel.
#   agents_json format (one per line or JSON array):
#     [{"id":"backend-dev","prompt":"Build REST API","output":"out.txt"}, ...]
#   Returns 0 if all succeed, 1 if any fail.
###############################################################
ao_dispatch_parallel() {
    local agents_json="$1"

    _ao_log "INFO" "Starting parallel dispatch..."

    # Parse JSON array into lines using Python (available on macOS)
    local tmpfile="${AO_OUTPUT_DIR}/parallel-spec-$$.json"
    echo "$agents_json" > "$tmpfile"

    local count
    count=$(python3 -c "import json,sys; d=json.load(open('${tmpfile}')); print(len(d))" 2>/dev/null || echo 0)

    if [[ "$count" -eq 0 ]]; then
        _ao_log "ERROR" "No agents found in parallel spec"
        rm -f "$tmpfile"
        return 1
    fi

    _ao_log "INFO" "Dispatching ${count} agents in parallel"

    local i=0
    local pids=()
    local agent_ids=()

    while [[ $i -lt $count ]]; do
        local aid prompt ofile
        aid=$(python3 -c "import json; d=json.load(open('${tmpfile}')); print(d[${i}]['id'])" 2>/dev/null)
        prompt=$(python3 -c "import json; d=json.load(open('${tmpfile}')); print(d[${i}]['prompt'])" 2>/dev/null)
        ofile=$(python3 -c "import json; d=json.load(open('${tmpfile}')); print(d[${i}].get('output',''))" 2>/dev/null)

        if [[ -z "${AO_AGENT_PATHS[$aid]:-}" ]]; then
            _ao_log "WARN" "Skipping unregistered agent: ${aid}"
            i=$((i + 1))
            continue
        fi

        local agent_md="${AO_AGENT_PATHS[$aid]}"
        [[ -z "$ofile" ]] && ofile="${AO_OUTPUT_DIR}/outputs/${aid}-$(date +%s).txt"

        AO_OUTPUTS[$aid]="$ofile"
        AO_STATUS[$aid]="running"
        AO_TOTAL_DISPATCHES=$((AO_TOTAL_DISPATCHES + 1))

        _ao_log "DISPATCH" "  [parallel] ${AO_BOLD}${aid}${AO_RESET}"

        # Launch in background
        (
            local s; s=$(_ao_timestamp)
            if command -v timeout &>/dev/null; then
                timeout "${AO_AGENT_TIMEOUT}" \
                    claude -p --dangerously-skip-permissions --output-format text \
                    -a "$agent_md" "$prompt" \
                    > "$ofile" 2>"${AO_OUTPUT_DIR}/logs/${aid}.stderr"
            else
                claude -p --dangerously-skip-permissions --output-format text \
                    -a "$agent_md" "$prompt" \
                    > "$ofile" 2>"${AO_OUTPUT_DIR}/logs/${aid}.stderr"
            fi
        ) &
        local pid=$!
        AO_PIDS[$aid]=$pid
        pids+=("$pid")
        agent_ids+=("$aid")

        i=$((i + 1))
    done

    rm -f "$tmpfile"

    # Wait for all
    local all_ok=0
    for idx in "${!pids[@]}"; do
        local p="${pids[$idx]}"
        local a="${agent_ids[$idx]}"
        local start_ts
        start_ts=$(_ao_timestamp)

        if wait "$p"; then
            AO_STATUS[$a]="success"
            AO_SUCCEEDED=$((AO_SUCCEEDED + 1))
            _ao_log "SUCCESS" "  [parallel] ${a} completed"
        else
            AO_STATUS[$a]="failed"
            AO_FAILED=$((AO_FAILED + 1))
            _ao_log "ERROR" "  [parallel] ${a} failed"
            all_ok=1
        fi
        local end_ts
        end_ts=$(_ao_timestamp)
        AO_DURATIONS[$a]=$(( end_ts - start_ts ))
    done

    return $all_ok
}

###############################################################
# ao_collect_results(agent_ids...)
#   Wait for and collect results from the specified agents.
#   Prints combined output to stdout.
###############################################################
ao_collect_results() {
    local agent_ids=("$@")
    local results=""

    for aid in "${agent_ids[@]}"; do
        local ofile="${AO_OUTPUTS[$aid]:-}"
        local status="${AO_STATUS[$aid]:-unknown}"

        if [[ -z "$ofile" || ! -f "$ofile" ]]; then
            _ao_log "WARN" "No output for agent: ${aid} (status=${status})"
            continue
        fi

        results+="$(printf '\n--- Agent: %s (status: %s) ---\n' "$aid" "$status")"
        results+="$(cat "$ofile" 2>/dev/null)"
        results+=$'\n'
    done

    echo "$results"
    return 0
}

###############################################################
# ao_review_cycle(impl_agent, qa_agent, task, max_rounds)
#   Iterative implement -> review -> fix loop.
#   impl_agent implements, qa_agent reviews, impl_agent fixes.
#   Continues until qa_agent approves or max_rounds is reached.
#   Returns 0 on approval, 1 on max rounds exceeded.
###############################################################
ao_review_cycle() {
    local impl_agent="$1" qa_agent="$2" task="$3" max_rounds="${4:-5}"

    _ao_log "INFO" "Starting review cycle: impl=${impl_agent} qa=${qa_agent} max_rounds=${max_rounds}"

    local round=1
    local impl_output="${AO_OUTPUT_DIR}/outputs/${impl_agent}-impl.txt"
    local qa_output="${AO_OUTPUT_DIR}/outputs/${qa_agent}-review.txt"

    # Round 1: initial implementation
    _ao_log "INFO" "Round ${round}/${max_rounds}: Implementation"
    ao_dispatch "$impl_agent" "$task" "$impl_output"
    if [[ $? -ne 0 ]]; then
        _ao_log "ERROR" "Implementation agent failed on initial task"
        return 1
    fi

    while [[ $round -le $max_rounds ]]; do
        _ao_log "INFO" "Round ${round}/${max_rounds}: QA Review"

        local impl_content
        impl_content=$(cat "$impl_output" 2>/dev/null)

        # QA reviews the implementation
        local review_prompt="以下の実装をレビューしてください。問題がなければ「APPROVED」と先頭に出力してください。問題がある場合は修正すべき点を具体的に指摘してください。

--- 実装内容 ---
${impl_content}
--- ここまで ---

元のタスク: ${task}"

        ao_dispatch "$qa_agent" "$review_prompt" "$qa_output"
        if [[ $? -ne 0 ]]; then
            _ao_log "WARN" "QA agent failed, treating as needs-fix"
        fi

        local review_content
        review_content=$(cat "$qa_output" 2>/dev/null)

        # Check for approval
        if echo "$review_content" | head -5 | grep -qi "APPROVED"; then
            _ao_log "SUCCESS" "QA approved at round ${round}/${max_rounds}"
            return 0
        fi

        # Not approved - fix
        round=$((round + 1))
        if [[ $round -gt $max_rounds ]]; then
            _ao_log "WARN" "Max review rounds (${max_rounds}) exceeded without approval"
            return 1
        fi

        _ao_log "INFO" "Round ${round}/${max_rounds}: Fix based on review"

        local fix_prompt="以下のQAレビュー指摘事項に基づいて実装を修正してください。

--- QAレビュー指摘 ---
${review_content}
--- ここまで ---

--- 現在の実装 ---
${impl_content}
--- ここまで ---

元のタスク: ${task}
修正した完全な実装を出力してください。"

        ao_dispatch "$impl_agent" "$fix_prompt" "$impl_output"
        if [[ $? -ne 0 ]]; then
            _ao_log "ERROR" "Implementation agent failed during fix round ${round}"
            return 1
        fi
    done

    return 1
}

###############################################################
# ao_report()
#   Print a summary of the orchestrator session.
###############################################################
ao_report() {
    local end_ts
    end_ts=$(_ao_timestamp)
    local elapsed=$(( end_ts - AO_START_TIME ))

    echo ""
    echo -e "${AO_BOLD}╔══════════════════════════════════════════════════════════════╗${AO_RESET}"
    echo -e "${AO_BOLD}║         Agent Orchestrator Report  (v13.0)                  ║${AO_RESET}"
    echo -e "${AO_BOLD}╚══════════════════════════════════════════════════════════════╝${AO_RESET}"
    echo -e "  Session:    ${AO_CYAN}${AO_SESSION_ID}${AO_RESET}"
    echo -e "  Duration:   ${elapsed}s"
    echo -e "  Dispatches: ${AO_TOTAL_DISPATCHES}  (${AO_GREEN}${AO_SUCCEEDED} ok${AO_RESET} / ${AO_RED}${AO_FAILED} fail${AO_RESET})"
    echo ""

    # Per-agent details
    echo -e "  ${AO_BOLD}Registered Agents:${AO_RESET}"
    for aid in "${!AO_AGENT_ROLES[@]}"; do
        local role="${AO_AGENT_ROLES[$aid]}"
        local status="${AO_STATUS[$aid]:-not-dispatched}"
        local dur="${AO_DURATIONS[$aid]:-0}"
        local status_color="${AO_DIM}"
        case "$status" in
            success)    status_color="${AO_GREEN}" ;;
            failed)     status_color="${AO_RED}"   ;;
            running)    status_color="${AO_YELLOW}" ;;
            registered) status_color="${AO_BLUE}"  ;;
        esac
        printf "    %-18s role=%-16s status=${status_color}%-10s${AO_RESET} time=%ss\n" \
            "$aid" "$role" "$status" "$dur"
    done

    echo ""
    echo -e "  Output dir: ${AO_DIM}${AO_OUTPUT_DIR}${AO_RESET}"
    echo ""

    # Write report to file
    if [[ -n "$AO_OUTPUT_DIR" ]]; then
        {
            echo "# Agent Orchestrator Report"
            echo "Session: ${AO_SESSION_ID}"
            echo "Date: $(date '+%Y-%m-%d %H:%M:%S')"
            echo "Duration: ${elapsed}s"
            echo "Total dispatches: ${AO_TOTAL_DISPATCHES}"
            echo "Succeeded: ${AO_SUCCEEDED}"
            echo "Failed: ${AO_FAILED}"
            echo ""
            echo "## Agent Details"
            for aid in "${!AO_AGENT_ROLES[@]}"; do
                echo "- ${aid}: role=${AO_AGENT_ROLES[$aid]} status=${AO_STATUS[$aid]:-n/a} duration=${AO_DURATIONS[$aid]:-0}s"
            done
        } > "${AO_OUTPUT_DIR}/orchestrator-report.md" 2>/dev/null || true
    fi

    return 0
}
