#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v69.0 - Dependency Analyzer
#
# プロジェクトの依存関係を分析し、脆弱性・互換性・最適化を自動検出。
#
# 分析対象:
# - npm パッケージ (package.json / package-lock.json)
# - Python パッケージ (requirements.txt / pyproject.toml)
# - Swift パッケージ (Package.swift)
# - Go モジュール (go.mod)
#
# 検出項目:
# - 既知の脆弱性 (npm audit / pip-audit)
# - 非推奨パッケージ
# - 不要な依存（使用されていないパッケージ）
# - バージョン競合
# - ライセンス互換性
# ============================================================

[[ -n "${_DEP_ANALYZER_LOADED:-}" ]] && return 0
_DEP_ANALYZER_LOADED=1

# --- Configuration ---
DA_ENABLE="${DA_ENABLE:-true}"
DA_AUTO_FIX="${DA_AUTO_FIX:-false}"     # 自動修正は慎重に
DA_VULNERABILITY_LEVEL="${DA_VULNERABILITY_LEVEL:-moderate}"  # low/moderate/high/critical

# --- State ---
DA_SCAN_COUNT=0
DA_VULNERABILITIES=0
DA_CRITICAL_VULNS=0
DA_UNUSED_DEPS=0
DA_OUTDATED_DEPS=0
DA_PACKAGES_TOTAL=0

# ============================================================
# 初期化
# ============================================================
da_init() {
    DA_SCAN_COUNT=0
    DA_VULNERABILITIES=0
    DA_CRITICAL_VULNS=0
    DA_UNUSED_DEPS=0
    DA_OUTDATED_DEPS=0
    DA_PACKAGES_TOTAL=0
    return 0
}

# ============================================================
# npm 依存分析
# ============================================================
da_analyze_npm() {
    local project_dir="$1"

    if [[ ! -f "${project_dir}/package.json" ]]; then
        return 0
    fi

    DA_SCAN_COUNT=$((DA_SCAN_COUNT + 1))
    local results=""

    # パッケージ数カウント
    local dep_count
    dep_count=$(python3 -c "
import json
data = json.load(open('${project_dir}/package.json'))
deps = len(data.get('dependencies', {}))
dev_deps = len(data.get('devDependencies', {}))
print(f'{deps + dev_deps}')
" 2>/dev/null || echo "0")
    DA_PACKAGES_TOTAL=$((DA_PACKAGES_TOTAL + dep_count))

    # npm audit（脆弱性チェック）
    if command -v npm &>/dev/null && [[ -f "${project_dir}/package-lock.json" ]]; then
        local audit_output
        audit_output=$(cd "$project_dir" && npm audit --json 2>/dev/null || true)

        if [[ -n "$audit_output" ]]; then
            local vuln_info
            vuln_info=$(python3 -c "
import json, sys
try:
    data = json.loads(sys.argv[1])
    meta = data.get('metadata', {}).get('vulnerabilities', {})
    critical = meta.get('critical', 0)
    high = meta.get('high', 0)
    moderate = meta.get('moderate', 0)
    low = meta.get('low', 0)
    total = critical + high + moderate + low
    print(f'{total}|{critical}|{high}|{moderate}|{low}')
except:
    print('0|0|0|0|0')
" "$audit_output" 2>/dev/null || echo "0|0|0|0|0")

            IFS='|' read -r total critical high moderate low <<< "$vuln_info"
            DA_VULNERABILITIES=$((DA_VULNERABILITIES + total))
            DA_CRITICAL_VULNS=$((DA_CRITICAL_VULNS + critical))

            results+="VULN_SUMMARY|total=${total},critical=${critical},high=${high},moderate=${moderate},low=${low}\n"
        fi
    fi

    # 不要パッケージ検出（depcheckスタイル）
    local unused
    unused=$(python3 -c "
import json, os, re

pkg = json.load(open('${project_dir}/package.json'))
deps = set(pkg.get('dependencies', {}).keys())

# ソースファイルからimportを抽出
used = set()
for root, dirs, files in os.walk('${project_dir}/src'):
    dirs[:] = [d for d in dirs if d not in ['node_modules', '.next', 'dist']]
    for f in files:
        if f.endswith(('.ts', '.tsx', '.js', '.jsx')):
            try:
                content = open(os.path.join(root, f)).read()
                imports = re.findall(r\"from ['\\\"]([^'\\\"./][^'\\\"]*)\", content)
                imports += re.findall(r\"require\(['\\\"]([^'\\\"./][^'\\\"]*)\", content)
                for imp in imports:
                    pkg_name = imp.split('/')[0]
                    if pkg_name.startswith('@'):
                        pkg_name = '/'.join(imp.split('/')[:2])
                    used.add(pkg_name)
            except:
                pass

unused = deps - used
for u in sorted(unused):
    print(u)
" 2>/dev/null || true)

    if [[ -n "$unused" ]]; then
        local unused_count
        unused_count=$(echo "$unused" | wc -l | tr -d ' ')
        DA_UNUSED_DEPS=$((DA_UNUSED_DEPS + unused_count))
        while IFS= read -r pkg; do
            results+="UNUSED|${pkg}\n"
        done <<< "$unused"
    fi

    echo -e "$results"
}

# ============================================================
# Python 依存分析
# ============================================================
da_analyze_python() {
    local project_dir="$1"

    if [[ ! -f "${project_dir}/requirements.txt" ]] && [[ ! -f "${project_dir}/pyproject.toml" ]]; then
        return 0
    fi

    DA_SCAN_COUNT=$((DA_SCAN_COUNT + 1))

    # pip-audit（脆弱性チェック）
    if command -v pip-audit &>/dev/null; then
        local audit_output
        audit_output=$(cd "$project_dir" && pip-audit --format=json 2>/dev/null || true)
        if [[ -n "$audit_output" ]]; then
            local vuln_count
            vuln_count=$(python3 -c "
import json, sys
try:
    data = json.loads(sys.argv[1])
    print(len(data))
except:
    print(0)
" "$audit_output" 2>/dev/null || echo "0")
            DA_VULNERABILITIES=$((DA_VULNERABILITIES + vuln_count))
        fi
    fi
}

# ============================================================
# 総合依存レポート生成
# ============================================================
da_full_analysis() {
    local project_dir="$1"
    local results=""

    echo -e "${BOLD:-}[Dependency Analyzer] ${project_dir} を分析中...${NC:-}" >&2

    # npm
    local npm_result
    npm_result=$(da_analyze_npm "$project_dir")
    [[ -n "$npm_result" ]] && results+="$npm_result"

    # Python
    local py_result
    py_result=$(da_analyze_python "$project_dir")
    [[ -n "$py_result" ]] && results+="$py_result"

    # サマリー出力
    echo -e "  パッケージ総数  : ${DA_PACKAGES_TOTAL}" >&2
    echo -e "  脆弱性          : ${DA_VULNERABILITIES} (critical: ${DA_CRITICAL_VULNS})" >&2
    echo -e "  未使用パッケージ: ${DA_UNUSED_DEPS}" >&2

    if [[ $DA_CRITICAL_VULNS -gt 0 ]]; then
        echo -e "  ${RED:-}🚨 CRITICAL脆弱性あり！即座の対応を推奨${NC:-}" >&2
    fi

    echo -e "$results"
}

# ============================================================
# 依存修正プロンプト生成
# ============================================================
da_build_fix_prompt() {
    local analysis_result="$1"
    local project_dir="$2"

    cat << PROMPT
# Dependency Fix Request

## Analysis Results
${analysis_result}

## Instructions
1. Update vulnerable packages to patched versions
2. Remove unused dependencies from package.json
3. Run npm audit fix for automatic fixes
4. If breaking changes are needed, provide migration steps

## Project Directory
${project_dir}

## Rules
- Do NOT remove packages that might be used indirectly
- Check peerDependencies before updating
- Keep major version changes minimal
PROMPT
}

# ============================================================
# レポート / スコア
# ============================================================
da_report() {
    echo -e "\n  ${BOLD:-}═══ Dependency Analyzer v69.0 レポート ═══${NC:-}"
    echo -e "  スキャン回数       : ${DA_SCAN_COUNT}"
    echo -e "  パッケージ総数     : ${DA_PACKAGES_TOTAL}"
    echo -e "  脆弱性検出         : ${DA_VULNERABILITIES} (critical: ${DA_CRITICAL_VULNS})"
    echo -e "  未使用パッケージ   : ${DA_UNUSED_DEPS}"
}

da_score() {
    if [[ $DA_SCAN_COUNT -eq 0 ]]; then
        echo "50"
    elif [[ $DA_CRITICAL_VULNS -gt 0 ]]; then
        echo "20"
    elif [[ $DA_VULNERABILITIES -gt 0 ]]; then
        echo "60"
    elif [[ $DA_UNUSED_DEPS -gt 5 ]]; then
        echo "70"
    else
        echo "95"
    fi
}

# ============================================================
# v59.0: Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "dep-analyzer" \
        --version "69.0" \
        --description "依存関係分析×脆弱性検出×不要パッケージ検出" \
        --init "da_init" \
        --report "da_report" \
        --score "da_score" \
        --enable-var "ENABLE_DEP_ANALYZER" \
        --cli-flags "--dep-analyze:--no-dep-analyze"
fi

# v2003.1: source時のexit codeを確実に0にする
true
