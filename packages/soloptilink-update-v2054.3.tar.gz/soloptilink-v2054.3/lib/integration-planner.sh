#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2037.x - Integration Planner
# =============================================================================
# タスク文から「必要になる外部API連携」を推論し、無料/有料/申請制で振り分ける。
#  - 無料で即動く・安全 → 自動接続候補(人へは事後の一言報告)
#  - 有料 → 「これが必要ですが大丈夫?」を人に確認(最安の選択肢を提示)
#  - 契約/申請が必要 → 即時不可を明示して確認
#  - AI が必要 → 既定 Gemini 2.5 Flash / 高品質時のみ Claude Sonnet
# 判定は各コネクタ辞書の connectivity メタを実体参照(同期ずれ防止)。
#
# Functions:
#   ip_init / ip_plan <task> / ip_human <task> / ip_report / ip_score
# (c) 2026 SoloptiLink Inc. - 営業秘密 / 著作権法・不正競争防止法で保護
# =============================================================================
[[ -n "${_INTEGRATION_PLANNER_LOADED:-}" ]] && return 0
_INTEGRATION_PLANNER_LOADED=1

declare -g IP_VERSION="1.0"
declare -g IP_PY="${HOME}/.soloptilink/lib/integration-planner/planner.py"
declare -g IP_PLAN_COUNT=0

ip_init() { return 0; }

# 機械可読プラン(JSON)
ip_plan() {
    local task="$1"
    [[ -z "$task" ]] && { echo '{"error":"empty task"}'; return 1; }
    IP_PLAN_COUNT=$((IP_PLAN_COUNT + 1))
    python3 "$IP_PY" "$task"
}

# 人(お客様)向けの日本語確認文
ip_human() {
    local task="$1"
    [[ -z "$task" ]] && return 1
    IP_PLAN_COUNT=$((IP_PLAN_COUNT + 1))
    python3 "$IP_PY" "$task" --human
}

# 自動接続すべき連携先(無料・安全)のコネクタIDだけを列挙(Forge 連携用)
ip_auto_connectors() {
    local task="$1"
    python3 "$IP_PY" "$task" | python3 -c "import sys,json;[print(x['connector']) for x in json.load(sys.stdin)['groups']['auto_connect']]" 2>/dev/null
}

# 有料/申請で確認が要る連携先のコネクタIDを列挙(AskUserQuestion 連携用)
ip_confirm_connectors() {
    local task="$1"
    python3 "$IP_PY" "$task" | python3 -c "
import sys,json
d=json.load(sys.stdin); g=d['groups']
for x in g['confirm_paid']: print(x['connector'],'paid')
for x in g['confirm_gated']: print(x['connector'],'gated')
if d['ai'].get('needed'): print('ai','ai')
" 2>/dev/null
}

ip_report() {
    echo -e "\n  ${BOLD:-}=== Integration Planner v${IP_VERSION} ===${NC:-}"
    echo -e "  プラン作成回数 : ${IP_PLAN_COUNT}"
}

ip_score() {
    local score=40
    [[ -f "$IP_PY" ]] && score=$((score + 40))
    [[ $IP_PLAN_COUNT -gt 0 ]] && score=$((score + 20))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "integration-planner" \
        --version "1.0" \
        --description "必要API推論→無料自動/有料確認の振り分け + AIコスト最適化" \
        --init "ip_init" \
        --report "ip_report" \
        --score "ip_score" \
        --enable-var "ENABLE_INTEGRATION_PLANNER" \
        --cli-flags "--integration-planner:--no-integration-planner"
fi

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-help}" in
        plan)    ip_plan "${2:-}" ;;
        human)   ip_human "${2:-}" ;;
        auto)    ip_auto_connectors "${2:-}" ;;
        confirm) ip_confirm_connectors "${2:-}" ;;
        report)  ip_report ;;
        score)   ip_score ;;
        *)       echo "usage: integration-planner.sh {plan|human|auto|confirm|report|score} \"<task>\"" ;;
    esac
fi
true
