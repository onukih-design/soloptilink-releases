#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v315.0 - Audit Trail System
# =============================================================================
# 監査証跡システム自動生成: 監査モデル/ミドルウェア/ビューア/コンプライアンスレポート
#
# 全globals: ATS_ prefix
# =============================================================================

[[ -n "${_AUDIT_TRAIL_SYSTEM_LOADED:-}" ]] && return 0
_AUDIT_TRAIL_SYSTEM_LOADED=1

declare -g ATS_VERSION="315.0"
declare -g ATS_INITIALIZED=false
declare -g ATS_GENERATED_COUNT=0
declare -g ENABLE_AUDIT_TRAIL_SYSTEM="${ENABLE_AUDIT_TRAIL_SYSTEM:-true}"

readonly ATS_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly ATS_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly ATS_BOLD="${CLR_BOLD:-\033[1m}"
readonly ATS_NC="${CLR_NC:-\033[0m}"

_ats_log() { echo -e "  ${ATS_CYAN}[ATS]${ATS_NC} $*" >&2; }
_ats_ok()  { echo -e "  ${ATS_GREEN}[ATS] OK${ATS_NC} $*" >&2; }

ats_init() { ATS_INITIALIZED=true; ATS_GENERATED_COUNT=0; return 0; }
ats_report() { [[ "$ATS_INITIALIZED" != "true" ]] && return 0; echo -e "\n  ${ATS_BOLD}--- Audit Trail System v${ATS_VERSION} ---${ATS_NC}" >&2; echo -e "  生成数: ${ATS_GENERATED_COUNT}" >&2; }
ats_score() { [[ "$ATS_INITIALIZED" != "true" ]] && { echo "0"; return; }; local s=50; [[ $ATS_GENERATED_COUNT -ge 3 ]] && s=85; echo "$s"; }
ats_init_message() { echo -e "  ${ATS_GREEN}v${ATS_VERSION} audit-trail-system: 監査証跡システム自動生成${ATS_NC}" >&2; }

_ats_generate_audit_model() {
    local project_dir="${1:-.}"
    _ats_log "監査ログモデル生成"
    local snippet='
// --- Audit Trail Models (v315.0) ---
model AuditLog {
  id         String   @id @default(cuid())
  action     String   // CREATE, UPDATE, DELETE, LOGIN, LOGOUT, etc.
  entity     String   // Table/model name
  entityId   String?
  userId     String?
  userEmail  String?
  ipAddress  String?
  userAgent  String?
  oldValues  Json?
  newValues  Json?
  metadata   Json?
  severity   AuditSeverity @default(INFO)
  createdAt  DateTime @default(now())

  @@index([entity, entityId])
  @@index([userId])
  @@index([action])
  @@index([createdAt])
}

enum AuditSeverity { INFO WARNING CRITICAL }'

    mkdir -p "${project_dir}/prisma"
    local sf="${project_dir}/prisma/schema.prisma"
    if [[ -f "$sf" ]] && ! grep -q "model AuditLog" "$sf" 2>/dev/null; then echo "$snippet" >> "$sf"; fi
    ATS_GENERATED_COUNT=$((ATS_GENERATED_COUNT + 1))
    _ats_ok "監査ログモデル生成完了"
    return 0
}

_ats_generate_middleware() {
    local project_dir="${1:-.}"
    _ats_log "監査ミドルウェア生成"
    local lib_dir="${project_dir}/src/lib"
    mkdir -p "$lib_dir"

    cat > "${lib_dir}/audit.ts" <<'EOF'
import { prisma } from '@/lib/prisma';
import { NextRequest } from 'next/server';

interface AuditOptions { action: string; entity: string; entityId?: string; oldValues?: any; newValues?: any; metadata?: any; severity?: 'INFO' | 'WARNING' | 'CRITICAL'; }

export async function auditLog(req: NextRequest | null, userId: string | null, options: AuditOptions) {
  try {
    await prisma.auditLog.create({
      data: {
        action: options.action,
        entity: options.entity,
        entityId: options.entityId,
        userId: userId,
        ipAddress: req?.headers.get('x-forwarded-for') || req?.headers.get('x-real-ip') || undefined,
        userAgent: req?.headers.get('user-agent') || undefined,
        oldValues: options.oldValues || undefined,
        newValues: options.newValues || undefined,
        metadata: options.metadata || undefined,
        severity: options.severity || 'INFO',
      },
    });
  } catch (error) {
    console.error('[Audit] Failed to log:', error);
  }
}

// Prisma middleware for automatic audit logging
export function createAuditMiddleware(getCurrentUserId: () => string | null) {
  return async (params: any, next: (params: any) => Promise<any>) => {
    const result = await next(params);

    if (['create', 'update', 'delete'].includes(params.action)) {
      const action = params.action.toUpperCase();
      const entity = params.model || 'unknown';
      const entityId = result?.id;

      // Skip audit log of audit logs
      if (entity === 'AuditLog') return result;

      try {
        await prisma.auditLog.create({
          data: { action, entity, entityId, userId: getCurrentUserId(), newValues: params.action === 'delete' ? undefined : params.args?.data, severity: params.action === 'delete' ? 'WARNING' : 'INFO' },
        });
      } catch { /* silent */ }
    }

    return result;
  };
}

export async function getAuditLogs(filters: { entity?: string; entityId?: string; userId?: string; action?: string; from?: Date; to?: Date; severity?: string; page?: number; limit?: number; }) {
  const where: any = {};
  if (filters.entity) where.entity = filters.entity;
  if (filters.entityId) where.entityId = filters.entityId;
  if (filters.userId) where.userId = filters.userId;
  if (filters.action) where.action = filters.action;
  if (filters.severity) where.severity = filters.severity;
  if (filters.from || filters.to) {
    where.createdAt = {};
    if (filters.from) where.createdAt.gte = filters.from;
    if (filters.to) where.createdAt.lte = filters.to;
  }

  const page = filters.page || 1;
  const limit = filters.limit || 50;

  const [logs, total] = await Promise.all([
    prisma.auditLog.findMany({ where, orderBy: { createdAt: 'desc' }, skip: (page - 1) * limit, take: limit }),
    prisma.auditLog.count({ where }),
  ]);

  return { data: logs, total, page, totalPages: Math.ceil(total / limit) };
}
EOF

    ATS_GENERATED_COUNT=$((ATS_GENERATED_COUNT + 1))
    _ats_ok "監査ミドルウェア生成完了"
    return 0
}

_ats_generate_viewer() {
    local project_dir="${1:-.}"
    _ats_log "監査ログビューア生成"
    local page_dir="${project_dir}/src/app/admin/audit"
    mkdir -p "$page_dir"

    cat > "${page_dir}/page.tsx" <<'EOF'
'use client';
import useSWR from 'swr';
import { useState } from 'react';
import { Shield, AlertTriangle, Info, Filter } from 'lucide-react';

const fetcher = (url: string) => fetch(url).then(r => r.json());
const severityIcons: Record<string, React.ReactNode> = {
  INFO: <Info size={14} className="text-blue-500" />,
  WARNING: <AlertTriangle size={14} className="text-yellow-500" />,
  CRITICAL: <Shield size={14} className="text-red-500" />,
};

export default function AuditLogPage() {
  const [filters, setFilters] = useState({ entity: '', action: '', severity: '', page: 1 });
  const queryStr = Object.entries(filters).filter(([_, v]) => v).map(([k, v]) => `${k}=${v}`).join('&');
  const { data, isLoading } = useSWR(`/api/admin/audit?${queryStr}`, fetcher);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-6">監査ログ</h1>
      <div className="flex gap-3 mb-4">
        <select value={filters.action} onChange={e => setFilters({ ...filters, action: e.target.value, page: 1 })} className="border rounded-lg px-3 py-2 text-sm">
          <option value="">全アクション</option><option value="CREATE">作成</option><option value="UPDATE">更新</option><option value="DELETE">削除</option><option value="LOGIN">ログイン</option>
        </select>
        <select value={filters.severity} onChange={e => setFilters({ ...filters, severity: e.target.value, page: 1 })} className="border rounded-lg px-3 py-2 text-sm">
          <option value="">全レベル</option><option value="INFO">INFO</option><option value="WARNING">WARNING</option><option value="CRITICAL">CRITICAL</option>
        </select>
      </div>

      {isLoading && <div className="space-y-2">{[1,2,3,4,5].map(i => <div key={i} className="h-12 bg-gray-200 rounded animate-pulse" />)}</div>}
      {data?.data && (
        <div className="bg-white rounded-lg shadow overflow-hidden">
          <table className="w-full text-sm">
            <thead className="bg-gray-50 border-b"><tr>
              <th className="text-left px-4 py-3 font-medium w-8"></th>
              <th className="text-left px-4 py-3 font-medium">日時</th>
              <th className="text-left px-4 py-3 font-medium">アクション</th>
              <th className="text-left px-4 py-3 font-medium">エンティティ</th>
              <th className="text-left px-4 py-3 font-medium">ユーザー</th>
              <th className="text-left px-4 py-3 font-medium">IP</th>
            </tr></thead>
            <tbody>{data.data.map((log: any) => (
              <tr key={log.id} className="border-b hover:bg-gray-50">
                <td className="px-4 py-3">{severityIcons[log.severity] || severityIcons.INFO}</td>
                <td className="px-4 py-3 text-gray-500 text-xs font-mono">{new Date(log.createdAt).toLocaleString('ja-JP')}</td>
                <td className="px-4 py-3"><span className="bg-gray-100 text-gray-700 text-xs px-2 py-0.5 rounded">{log.action}</span></td>
                <td className="px-4 py-3">{log.entity} {log.entityId && <span className="text-gray-400 text-xs">#{log.entityId.substring(0,8)}</span>}</td>
                <td className="px-4 py-3 text-gray-500 text-xs">{log.userEmail || log.userId || '-'}</td>
                <td className="px-4 py-3 text-gray-400 text-xs font-mono">{log.ipAddress || '-'}</td>
              </tr>
            ))}</tbody>
          </table>
        </div>
      )}
      {data?.totalPages > 1 && (
        <div className="flex justify-center gap-2 mt-4">
          <button onClick={() => setFilters({ ...filters, page: filters.page - 1 })} disabled={filters.page <= 1} className="px-3 py-1 border rounded text-sm disabled:opacity-50">前</button>
          <span className="px-3 py-1 text-sm">{filters.page}/{data.totalPages}</span>
          <button onClick={() => setFilters({ ...filters, page: filters.page + 1 })} disabled={filters.page >= data.totalPages} className="px-3 py-1 border rounded text-sm disabled:opacity-50">次</button>
        </div>
      )}
    </div>
  );
}
EOF

    ATS_GENERATED_COUNT=$((ATS_GENERATED_COUNT + 1))
    _ats_ok "監査ログビューア生成完了"
    return 0
}

_ats_generate_compliance_report() {
    local project_dir="${1:-.}"
    _ats_log "コンプライアンスレポートAPI生成"
    local api_dir="${project_dir}/src/app/api/admin/audit/compliance"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const from = req.nextUrl.searchParams.get('from') || new Date(Date.now() - 30 * 86400000).toISOString();
    const to = req.nextUrl.searchParams.get('to') || new Date().toISOString();
    const dateFilter = { gte: new Date(from), lte: new Date(to) };

    const [totalLogs, byAction, bySeverity, byEntity, criticalEvents, uniqueUsers] = await Promise.all([
      prisma.auditLog.count({ where: { createdAt: dateFilter } }),
      prisma.auditLog.groupBy({ by: ['action'], _count: true, where: { createdAt: dateFilter } }),
      prisma.auditLog.groupBy({ by: ['severity'], _count: true, where: { createdAt: dateFilter } }),
      prisma.auditLog.groupBy({ by: ['entity'], _count: true, where: { createdAt: dateFilter }, orderBy: { _count: { entity: 'desc' } }, take: 10 }),
      prisma.auditLog.findMany({ where: { severity: 'CRITICAL', createdAt: dateFilter }, orderBy: { createdAt: 'desc' }, take: 20 }),
      prisma.auditLog.findMany({ where: { createdAt: dateFilter }, distinct: ['userId'], select: { userId: true } }),
    ]);

    return NextResponse.json({
      period: { from, to },
      summary: { totalLogs, uniqueUsers: uniqueUsers.length, criticalCount: criticalEvents.length },
      byAction: byAction.map(a => ({ action: a.action, count: a._count })),
      bySeverity: bySeverity.map(s => ({ severity: s.severity, count: s._count })),
      topEntities: byEntity.map(e => ({ entity: e.entity, count: e._count })),
      criticalEvents,
    });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to generate compliance report' }, { status: 500 });
  }
}
EOF

    ATS_GENERATED_COUNT=$((ATS_GENERATED_COUNT + 1))
    _ats_ok "コンプライアンスレポート生成完了"
    return 0
}

_mr_register \
    --name "audit-trail-system" \
    --version "315.0" \
    --description "監査証跡システム自動生成（モデル/ミドルウェア/ビューア/コンプライアンス）" \
    --init "ats_init" \
    --report "ats_report" \
    --score "ats_score" \
    --enable-var "ENABLE_AUDIT_TRAIL_SYSTEM" \
    --cli-flags "--audit-trail:--no-audit-trail" \
    --init-msg "ats_init_message"
