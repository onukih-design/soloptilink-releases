#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2003.0 - Real Competitive Research Engine
# =============================================================================
# 依頼されたシステムの競合サービスを「実際にWeb検索」して調査し、
# その結果を設計・要件定義に反映する。
#
# 従来の問題: Claude CLIに「競合調査して」と投げるだけ → 古い内部知識のみ
# 解決策: claude CLI の --allowedTools を使い、WebSearch/WebFetch で実Web検索
#
# フロー:
#   1. ドメイン判定 → 検索クエリ生成
#   2. claude CLI + WebSearch で実際の競合サービスを検索
#   3. 各競合サービスの機能・価格・強み・弱みを構造化
#   4. 差別化ポイント・推奨機能リストを生成
#   5. 結果を後続フェーズ（設計・実装）に注入
# =============================================================================

[[ -n "${_REAL_COMPETITIVE_RESEARCH_LOADED:-}" ]] && return 0
_REAL_COMPETITIVE_RESEARCH_LOADED=1

# 設定
RCR_WORK_DIR="${HOME}/.soloptilink/competitive-research"
RCR_CLAUDE_TIMEOUT=600
RCR_MAX_COMPETITORS=8
RCR_MAX_FEATURES=15

# グローバル: 調査結果を保持
declare -g RCR_RESEARCH_RESULT=""
declare -g RCR_RECOMMENDED_FEATURES=""
declare -g RCR_COMPETITIVE_CONTEXT=""
declare -g RCR_DIFFERENTIATORS=""

# カラー
RCR_GREEN='\033[0;32m'
RCR_YELLOW='\033[0;33m'
RCR_RED='\033[0;31m'
RCR_BLUE='\033[0;34m'
RCR_PURPLE='\033[0;35m'
RCR_CYAN='\033[0;36m'
RCR_BOLD='\033[1m'
RCR_NC='\033[0m'

# =============================================================================
# 初期化
# =============================================================================
rcr_init() {
    mkdir -p "${RCR_WORK_DIR}" 2>/dev/null || true
    echo -e "  ${RCR_GREEN}🔍 v2003.0 Real Competitive Research Engine 初期化完了${RCR_NC}"
}

# =============================================================================
# ログ
# =============================================================================
_rcr_log() {
    local level="$1" message="$2"
    local color="${RCR_NC}"
    case "$level" in
        INFO)     color="${RCR_CYAN}"   ;;
        SUCCESS)  color="${RCR_GREEN}"  ;;
        WARN)     color="${RCR_YELLOW}" ;;
        ERROR)    color="${RCR_RED}"    ;;
        STEP)     color="${RCR_PURPLE}" ;;
        RESEARCH) color="${RCR_BLUE}"   ;;
    esac
    echo -e "  ${color}[RCR:${level}]${RCR_NC} ${message}"
}

# =============================================================================
# ドメインに応じた検索クエリを生成
# =============================================================================
_rcr_generate_search_queries() {
    local task_desc="$1"
    local domain="$2"

    # ドメイン別の検索キーワードマップ
    local -A domain_keywords=(
        ["finance"]="家計簿アプリ 会計ソフト 経費管理 比較 ランキング"
        ["crm"]="CRM 顧客管理 営業支援 SaaS 比較 2026"
        ["chat"]="ビジネスチャット メッセージアプリ 比較 Slack Teams"
        ["ecommerce"]="ECサイト ネットショップ 構築 比較 Shopify BASE"
        ["task-management"]="タスク管理 プロジェクト管理 ツール 比較 Asana Notion"
        ["social"]="SNS コミュニティ プラットフォーム 構築"
        ["content"]="CMS ブログ コンテンツ管理 比較 WordPress"
        ["analytics"]="BIツール ダッシュボード データ分析 比較"
        ["landing-page"]="LP作成 ランディングページ ツール 比較"
        ["booking"]="予約システム 予約管理 比較 SaaS"
        ["inventory"]="在庫管理 倉庫管理 システム 比較"
        ["hr"]="人事管理 勤怠管理 HRテック 比較"
        ["lms"]="LMS 学習管理 eラーニング 比較"
        ["general"]="業務システム SaaS ツール 比較 2026"
    )

    local base_keywords="${domain_keywords[$domain]:-${domain_keywords[general]}}"

    # タスク説明から追加キーワードを抽出
    local extra_keywords=""
    if [[ "$task_desc" =~ (管理|システム|アプリ|ツール|サービス|プラットフォーム) ]]; then
        extra_keywords="$task_desc 類似サービス 機能比較"
    fi

    echo "${base_keywords}"
    echo "${extra_keywords}"
    echo "${task_desc} 競合 機能 比較 2026"
}

# =============================================================================
# 実際のWeb検索を実行して競合を調査
# =============================================================================
rcr_research_competitors() {
    local task_desc="$1"
    local domain="${2:-general}"
    local session_id="${3:-}"

    _rcr_log "STEP" "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    _rcr_log "RESEARCH" "${RCR_BOLD}実Web競合調査を開始${RCR_NC}"
    _rcr_log "STEP" "  依頼: ${task_desc}"
    _rcr_log "STEP" "  ドメイン: ${domain}"
    _rcr_log "STEP" "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    local output_dir="${RCR_WORK_DIR}/${session_id:-$(date +%Y%m%d_%H%M%S)}"
    mkdir -p "$output_dir" 2>/dev/null || true

    local research_file="${output_dir}/competitive_research.md"
    local features_file="${output_dir}/recommended_features.md"
    local diff_file="${output_dir}/differentiators.md"

    # Step 1: 検索クエリ生成
    _rcr_log "STEP" "[1/4] 検索クエリ生成中..."
    local queries
    queries=$(_rcr_generate_search_queries "$task_desc" "$domain")

    # Step 2: Claude CLI + Web検索で実際に調査
    # claude CLIはWeb検索ツールを内蔵しているため、
    # 明示的に「Webで検索して、実際のサービス名・URL・機能を調べろ」と指示する
    _rcr_log "STEP" "[2/4] Web検索による競合調査実行中..."

    local research_prompt="あなたは市場調査の専門アナリストです。
以下のシステムの競合サービスを**実際にWeb検索して**調査してください。

## 調査対象
ユーザーの依頼: 「${task_desc}」
ドメイン: ${domain}

## 検索すべきキーワード
${queries}

## 必須調査項目

### 1. 競合サービス一覧（${RCR_MAX_COMPETITORS}社以上）
**実在するサービスのみ**を記載。各サービスについて:
- **サービス名**（正式名称）
- **URL**（公式サイト）
- **概要**（1-2文）
- **主要機能**（箇条書き5-10個、具体的に）
- **料金プラン**（無料プラン有無、有料の最低価格）
- **対象ユーザー**（個人/中小/大企業）
- **強み**（他サービスとの差別化ポイント）
- **弱み**（ユーザーレビューで指摘されている課題）
- **技術的特徴**（API提供、連携サービス、モバイル対応等）

### 2. 機能マトリクス
全競合サービスの機能を横断比較する表を作成。
列: 各サービス名、行: 主要機能（○/×/△で対応状況を記載）

### 3. ユーザーが「当然あるべき」と思う機能（${RCR_MAX_FEATURES}個以上）
このドメインのサービスでユーザーが期待する機能を優先度別に:
- **必須（ないと使わない）**: 〇〇個
- **標準（あって当然）**: 〇〇個
- **差別化（あると嬉しい）**: 〇〇個

### 4. 市場トレンド（2025-2026年）
- AI/自動化のトレンド
- UX/UIのトレンド
- 技術アーキテクチャのトレンド

### 5. 差別化の機会
既存サービスが**まだ提供していない**、または**弱い**領域で、
新規参入者が差別化できるポイントを5-10個。具体的に。

---
**重要**: 架空のサービスや推測は書かないでください。
実際にWeb検索で確認した情報のみ記載すること。
各サービスのURLは必ず含めること。"

    # Claude CLI実行（Web検索を活用）
    local result=""
    if type -t ai_call &>/dev/null; then
        AIP_TIMEOUT="${RCR_CLAUDE_TIMEOUT}" AIP_MAX_RETRIES=2 AIP_SKIP_ENHANCE=true \
            result=$(ai_call "$research_prompt" "$research_file" "competitive_research" "$domain" 2>/dev/null || echo "")
    elif command -v claude &>/dev/null; then
        local _rcr_cmd="claude"
        command -v timeout &>/dev/null && _rcr_cmd="timeout ${RCR_CLAUDE_TIMEOUT} claude"
        result=$(${_rcr_cmd} -p --dangerously-skip-permissions \
            --output-format text \
            "$research_prompt" 2>/dev/null || echo "")
    fi

    if [[ -n "$result" ]]; then
        echo "$result" > "$research_file"
        RCR_RESEARCH_RESULT="$result"
        _rcr_log "SUCCESS" "競合調査完了 → ${research_file}"
    else
        _rcr_log "WARN" "Web検索結果が空。Claude内部知識でフォールバック"
        # フォールバック: 最低限の調査
        _rcr_fallback_research "$task_desc" "$domain" "$research_file"
    fi

    # Step 3: 推奨機能リストの生成
    _rcr_log "STEP" "[3/4] 推奨機能リスト生成中..."
    _rcr_generate_feature_recommendations "$task_desc" "$domain" "$features_file"

    # Step 4: 差別化戦略の生成
    _rcr_log "STEP" "[4/4] 差別化戦略策定中..."
    _rcr_generate_differentiators "$task_desc" "$domain" "$diff_file"

    _rcr_log "SUCCESS" "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
    _rcr_log "SUCCESS" "競合調査完了"
    _rcr_log "SUCCESS" "  調査レポート: ${research_file}"
    _rcr_log "SUCCESS" "  推奨機能: ${features_file}"
    _rcr_log "SUCCESS" "  差別化戦略: ${diff_file}"
    _rcr_log "SUCCESS" "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

    return 0
}

# =============================================================================
# 推奨機能リスト生成（競合調査結果を基に）
# =============================================================================
_rcr_generate_feature_recommendations() {
    local task_desc="$1"
    local domain="$2"
    local output_file="$3"

    # 競合調査結果を切り詰め（コンテキスト制限対策）
    local research_context=""
    if [[ -n "$RCR_RESEARCH_RESULT" ]]; then
        if [[ ${#RCR_RESEARCH_RESULT} -gt 8000 ]]; then
            research_context="${RCR_RESEARCH_RESULT:0:8000}
...(省略)"
        else
            research_context="$RCR_RESEARCH_RESULT"
        fi
    fi

    local prompt="あなたはプロダクトマネージャーです。
以下の競合調査結果を基に、新規開発する「${task_desc}」に実装すべき機能を
優先度付きで提案してください。

## 競合調査結果
${research_context}

## 出力フォーマット（必ずこの形式で）

### 🔴 必須機能（ないとユーザーが使わない）
1. **機能名**: 説明（競合サービスの〇〇が参考、全競合が実装済み）
2. ...（10個以上）

### 🟡 標準機能（あって当然、ないと見劣りする）
1. **機能名**: 説明（競合の〇〇にはあるが△△にはない）
2. ...（5-10個）

### 🟢 差別化機能（あると競合に勝てる）
1. **機能名**: 説明（どの競合も未実装、実装すれば独自の強みに）
2. ...（5-10個）

### 🚫 不要機能（コストに見合わないもの）
1. **機能名**: なぜ不要か

### 📐 推奨技術スタック
競合調査結果を踏まえ、最適な技術構成を提案。

各機能には必ず「なぜその優先度なのか」の理由を含めること。
競合サービス名を具体的に引用すること。"

    local result=""
    if type -t ai_call &>/dev/null; then
        AIP_TIMEOUT="${RCR_CLAUDE_TIMEOUT}" AIP_SKIP_ENHANCE=true \
            result=$(ai_call "$prompt" "$output_file" "feature_recommendation" "$domain" 2>/dev/null || echo "")
    elif command -v claude &>/dev/null; then
        result=$(timeout "${RCR_CLAUDE_TIMEOUT}" claude -p --dangerously-skip-permissions \
            --output-format text "$prompt" 2>/dev/null || echo "")
    fi

    if [[ -n "$result" ]]; then
        echo "$result" > "$output_file"
        RCR_RECOMMENDED_FEATURES="$result"
    fi
}

# =============================================================================
# 差別化戦略生成
# =============================================================================
_rcr_generate_differentiators() {
    local task_desc="$1"
    local domain="$2"
    local output_file="$3"

    local research_context=""
    if [[ -n "$RCR_RESEARCH_RESULT" ]]; then
        if [[ ${#RCR_RESEARCH_RESULT} -gt 6000 ]]; then
            research_context="${RCR_RESEARCH_RESULT:0:6000}...(省略)"
        else
            research_context="$RCR_RESEARCH_RESULT"
        fi
    fi

    local prompt="あなたはプロダクト戦略コンサルタントです。

## タスク
「${task_desc}」を新規開発します。以下の競合調査を踏まえ、
**競合より優れたシステム**にするための具体的な差別化戦略を策定してください。

## 競合調査結果（要約）
${research_context}

## 出力フォーマット

### 💎 コア差別化ポイント（3つ）
この3つがあれば競合に勝てるという核心的な差別化要素。
各ポイントに:
- なぜ差別化になるか
- どの競合が弱いか
- 技術的な実現方法

### 🎯 UX差別化（5つ）
ユーザー体験で競合を上回るポイント。
- 操作性
- 表示速度
- 直感性
- カスタマイズ性
- モバイル対応

### 🔧 技術差別化（5つ）
技術的に競合を上回るポイント。
- パフォーマンス
- セキュリティ
- 拡張性
- 統合性
- 保守性

### 📊 ビジネス差別化（3つ）
料金モデル、サポート、ターゲット等でのポジショニング。"

    local result=""
    if type -t ai_call &>/dev/null; then
        AIP_TIMEOUT="${RCR_CLAUDE_TIMEOUT}" AIP_SKIP_ENHANCE=true \
            result=$(ai_call "$prompt" "$output_file" "differentiators" "$domain" 2>/dev/null || echo "")
    elif command -v claude &>/dev/null; then
        result=$(timeout "${RCR_CLAUDE_TIMEOUT}" claude -p --dangerously-skip-permissions \
            --output-format text "$prompt" 2>/dev/null || echo "")
    fi

    if [[ -n "$result" ]]; then
        echo "$result" > "$output_file"
        RCR_DIFFERENTIATORS="$result"
    fi
}

# =============================================================================
# フォールバック: Web検索失敗時
# =============================================================================
_rcr_fallback_research() {
    local task_desc="$1"
    local domain="$2"
    local output_file="$3"

    _rcr_log "WARN" "フォールバック: Claude内部知識による競合調査"

    local prompt="あなたは市場調査アナリストです。
「${task_desc}」(ドメイン: ${domain}) の競合サービスを、
あなたの知識に基づいて調査してください。

実在するサービスのみ記載し、以下の形式で出力:
- サービス名、概要、主要機能（5個以上）、料金、強み、弱み

最低5サービス以上調査すること。"

    local result=""
    if command -v claude &>/dev/null; then
        result=$(timeout "${RCR_CLAUDE_TIMEOUT}" claude -p --dangerously-skip-permissions \
            --output-format text "$prompt" 2>/dev/null || echo "")
    fi

    if [[ -n "$result" ]]; then
        echo "$result" > "$output_file"
        RCR_RESEARCH_RESULT="$result"
    fi
}

# =============================================================================
# 競合調査結果をプロンプトに注入するためのコンテキスト取得
# =============================================================================
rcr_get_context_for_prompt() {
    local max_chars="${1:-4000}"

    if [[ -z "$RCR_RESEARCH_RESULT" && -z "$RCR_RECOMMENDED_FEATURES" ]]; then
        echo ""
        return 0
    fi

    local context="
## 競合調査に基づく設計指針

### 競合サービスの主要機能（実装必須）
${RCR_RECOMMENDED_FEATURES:0:$max_chars}

### 差別化ポイント（優先実装）
${RCR_DIFFERENTIATORS:0:2000}
"
    echo "$context"
}

# =============================================================================
# 調査結果のサマリーを表示
# =============================================================================
rcr_show_summary() {
    if [[ -z "$RCR_RESEARCH_RESULT" ]]; then
        _rcr_log "WARN" "競合調査結果がありません"
        return 1
    fi

    echo -e "\n${RCR_BOLD}${RCR_BLUE}╔═══════════════════════════════════════════════════════╗${RCR_NC}"
    echo -e "${RCR_BOLD}${RCR_BLUE}║  📊 競合調査サマリー                                   ║${RCR_NC}"
    echo -e "${RCR_BOLD}${RCR_BLUE}╚═══════════════════════════════════════════════════════╝${RCR_NC}\n"

    # 調査結果の先頭部分を表示
    echo "$RCR_RESEARCH_RESULT" | head -40

    if [[ -n "$RCR_RECOMMENDED_FEATURES" ]]; then
        echo -e "\n${RCR_BOLD}${RCR_GREEN}━━━ 推奨機能（競合調査ベース）━━━${RCR_NC}\n"
        echo "$RCR_RECOMMENDED_FEATURES" | head -30
    fi

    if [[ -n "$RCR_DIFFERENTIATORS" ]]; then
        echo -e "\n${RCR_BOLD}${RCR_PURPLE}━━━ 差別化戦略 ━━━${RCR_NC}\n"
        echo "$RCR_DIFFERENTIATORS" | head -20
    fi

    echo ""
}

# =============================================================================
# Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "real-competitive-research" \
        --version "2003.0" \
        --init "rcr_init" \
        --report "rcr_show_summary" \
        --description "実Web検索による競合調査エンジン"
fi

# v2003.1: source時のexit codeを確実に0にする
true
