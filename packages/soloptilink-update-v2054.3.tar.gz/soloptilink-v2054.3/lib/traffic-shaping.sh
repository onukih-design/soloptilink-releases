#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v451.0 - Traffic Shaping Engine
# =============================================================================
# トラフィックシェーピング自動構築: 優先度キュー、帯域制限、バースト制御。
# APIリクエストの優先度付けとレート制御を本番品質TypeScriptコードとして生成。
#
# Functions:
#   _ts_init()                   - Initialize traffic shaping config
#   _ts_generate_priority_queue()  - Priority queue for API requests
#   _ts_generate_bandwidth_limit() - Bandwidth limiting middleware
#   _ts_generate_burst_control()   - Burst control / token bucket
#   _ts_generate_all()             - Full traffic shaping scaffold
#   _ts_report() / _ts_score()     - Reporting
#
# All globals use the TS_ prefix.
# =============================================================================

[[ -n "${_TS_LOADED:-}" ]] && return 0; _TS_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g TS_VERSION="451.0"
TS_GENERATED=0
TS_ERRORS=0
TS_FILES_WRITTEN=0
TS_PRIORITY_QUEUE_OK=false
TS_BANDWIDTH_LIMIT_OK=false
TS_BURST_CONTROL_OK=false

# =============================================================================
# Init
# =============================================================================
_ts_init() {
    TS_GENERATED=0
    TS_ERRORS=0
    TS_FILES_WRITTEN=0
    TS_PRIORITY_QUEUE_OK=false
    TS_BANDWIDTH_LIMIT_OK=false
    TS_BURST_CONTROL_OK=false
    return 0
}

# =============================================================================
# Utility
# =============================================================================
_ts_log() { echo -e "  ${CYAN:-\033[0;36m}[traffic-shaping]${NC:-\033[0m} $*" >&2; }
_ts_ok()  { echo -e "  ${GREEN:-\033[0;32m}✅ [traffic-shaping]${NC:-\033[0m} $*" >&2; }
_ts_err() { echo -e "  ${RED:-\033[0;31m}❌ [traffic-shaping]${NC:-\033[0m} $*" >&2; TS_ERRORS=$((TS_ERRORS + 1)); }

_ts_write_file() {
    local filepath="$1"
    local content="$2"
    local dir
    dir="$(dirname "$filepath")"
    [[ -d "$dir" ]] || mkdir -p "$dir"
    echo "$content" > "$filepath" 2>/dev/null || { _ts_err "Failed to write $filepath"; return 1; }
    TS_FILES_WRITTEN=$((TS_FILES_WRITTEN + 1))
    return 0
}

# =============================================================================
# Priority Queue Generator
# =============================================================================
_ts_generate_priority_queue() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/traffic/priority-queue.ts"
    _ts_log "Generating priority queue..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v451.0 - Priority Queue for Traffic Shaping
import { EventEmitter } from 'events';

export enum RequestPriority {
  CRITICAL = 0,
  HIGH = 1,
  NORMAL = 2,
  LOW = 3,
  BACKGROUND = 4,
}

interface QueuedRequest<T = unknown> {
  id: string;
  priority: RequestPriority;
  handler: () => Promise<T>;
  resolve: (value: T) => void;
  reject: (reason: unknown) => void;
  enqueuedAt: number;
  timeoutMs: number;
}

export class PriorityRequestQueue extends EventEmitter {
  private queues: Map<RequestPriority, QueuedRequest[]> = new Map();
  private activeCount = 0;
  private readonly maxConcurrent: number;
  private readonly defaultTimeoutMs: number;

  constructor(opts: { maxConcurrent?: number; defaultTimeoutMs?: number } = {}) {
    super();
    this.maxConcurrent = opts.maxConcurrent ?? 50;
    this.defaultTimeoutMs = opts.defaultTimeoutMs ?? 30000;
    for (const p of Object.values(RequestPriority).filter(v => typeof v === 'number')) {
      this.queues.set(p as RequestPriority, []);
    }
  }

  async enqueue<T>(
    priority: RequestPriority,
    handler: () => Promise<T>,
    timeoutMs?: number,
  ): Promise<T> {
    return new Promise<T>((resolve, reject) => {
      const request: QueuedRequest<T> = {
        id: `req_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
        priority,
        handler,
        resolve: resolve as (v: unknown) => void,
        reject,
        enqueuedAt: Date.now(),
        timeoutMs: timeoutMs ?? this.defaultTimeoutMs,
      };
      this.queues.get(priority)!.push(request as QueuedRequest);
      this.emit('enqueue', { id: request.id, priority, queueSize: this.size });
      this.processNext();
    });
  }

  private async processNext(): Promise<void> {
    if (this.activeCount >= this.maxConcurrent) return;
    const request = this.dequeueHighest();
    if (!request) return;
    this.activeCount++;
    const timer = setTimeout(() => {
      request.reject(new Error(`Request ${request.id} timed out after ${request.timeoutMs}ms`));
    }, request.timeoutMs);
    try {
      const result = await request.handler();
      clearTimeout(timer);
      request.resolve(result);
      this.emit('complete', { id: request.id, duration: Date.now() - request.enqueuedAt });
    } catch (err) {
      clearTimeout(timer);
      request.reject(err);
      this.emit('error', { id: request.id, error: err });
    } finally {
      this.activeCount--;
      this.processNext();
    }
  }

  private dequeueHighest(): QueuedRequest | undefined {
    for (const priority of [
      RequestPriority.CRITICAL, RequestPriority.HIGH,
      RequestPriority.NORMAL, RequestPriority.LOW, RequestPriority.BACKGROUND,
    ]) {
      const queue = this.queues.get(priority)!;
      if (queue.length > 0) return queue.shift();
    }
    return undefined;
  }

  get size(): number {
    let total = 0;
    for (const q of this.queues.values()) total += q.length;
    return total;
  }

  get active(): number { return this.activeCount; }

  getStats(): Record<string, number> {
    const stats: Record<string, number> = { active: this.activeCount, total: this.size };
    for (const [p, q] of this.queues.entries()) stats[`priority_${p}`] = q.length;
    return stats;
  }
}
TYPESCRIPT
)
    _ts_write_file "$outfile" "$content" || return 1
    TS_PRIORITY_QUEUE_OK=true
    TS_GENERATED=$((TS_GENERATED + 1))
    _ts_ok "Priority queue generated"
    return 0
}

# =============================================================================
# Bandwidth Limit Generator
# =============================================================================
_ts_generate_bandwidth_limit() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/traffic/bandwidth-limiter.ts"
    _ts_log "Generating bandwidth limiter..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v451.0 - Bandwidth Limiter Middleware
import type { NextRequest, NextResponse } from 'next/server';

interface BandwidthConfig {
  maxBytesPerSecond: number;
  maxBytesPerMinute: number;
  perIpLimit: boolean;
  burstAllowance: number;
}

const DEFAULT_CONFIG: BandwidthConfig = {
  maxBytesPerSecond: 10 * 1024 * 1024,   // 10 MB/s
  maxBytesPerMinute: 200 * 1024 * 1024,   // 200 MB/min
  perIpLimit: true,
  burstAllowance: 1.5,
};

class BandwidthTracker {
  private windows: Map<string, { bytes: number; resetAt: number }[]> = new Map();

  record(key: string, bytes: number): boolean {
    const now = Date.now();
    if (!this.windows.has(key)) this.windows.set(key, []);
    const entries = this.windows.get(key)!;
    // Purge old entries (> 60s)
    const cutoff = now - 60000;
    while (entries.length > 0 && entries[0].resetAt < cutoff) entries.shift();
    entries.push({ bytes, resetAt: now });
    return true;
  }

  getBytesInWindow(key: string, windowMs: number): number {
    const now = Date.now();
    const entries = this.windows.get(key) ?? [];
    const cutoff = now - windowMs;
    return entries.filter(e => e.resetAt >= cutoff).reduce((sum, e) => sum + e.bytes, 0);
  }

  isWithinLimit(key: string, config: BandwidthConfig): boolean {
    const perSecond = this.getBytesInWindow(key, 1000);
    const perMinute = this.getBytesInWindow(key, 60000);
    const burstLimit = config.maxBytesPerSecond * config.burstAllowance;
    return perSecond <= burstLimit && perMinute <= config.maxBytesPerMinute;
  }
}

const tracker = new BandwidthTracker();

export function bandwidthLimiter(config: Partial<BandwidthConfig> = {}) {
  const cfg = { ...DEFAULT_CONFIG, ...config };
  return function checkBandwidth(req: NextRequest): { allowed: boolean; retryAfterMs?: number } {
    const key = cfg.perIpLimit
      ? (req.headers.get('x-forwarded-for') ?? req.ip ?? 'unknown')
      : 'global';
    const contentLength = parseInt(req.headers.get('content-length') ?? '0', 10);
    tracker.record(key, contentLength);
    if (!tracker.isWithinLimit(key, cfg)) {
      return { allowed: false, retryAfterMs: 1000 };
    }
    return { allowed: true };
  };
}

export { BandwidthTracker, BandwidthConfig, DEFAULT_CONFIG };
TYPESCRIPT
)
    _ts_write_file "$outfile" "$content" || return 1
    TS_BANDWIDTH_LIMIT_OK=true
    TS_GENERATED=$((TS_GENERATED + 1))
    _ts_ok "Bandwidth limiter generated"
    return 0
}

# =============================================================================
# Burst Control Generator (Token Bucket)
# =============================================================================
_ts_generate_burst_control() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/traffic/burst-control.ts"
    _ts_log "Generating burst control (token bucket)..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v451.0 - Burst Control (Token Bucket Algorithm)

export interface TokenBucketConfig {
  capacity: number;         // Max tokens
  refillRate: number;       // Tokens per second
  initialTokens?: number;
}

export class TokenBucket {
  private tokens: number;
  private readonly capacity: number;
  private readonly refillRate: number;
  private lastRefill: number;

  constructor(config: TokenBucketConfig) {
    this.capacity = config.capacity;
    this.refillRate = config.refillRate;
    this.tokens = config.initialTokens ?? config.capacity;
    this.lastRefill = Date.now();
  }

  private refill(): void {
    const now = Date.now();
    const elapsed = (now - this.lastRefill) / 1000;
    this.tokens = Math.min(this.capacity, this.tokens + elapsed * this.refillRate);
    this.lastRefill = now;
  }

  consume(count = 1): boolean {
    this.refill();
    if (this.tokens >= count) {
      this.tokens -= count;
      return true;
    }
    return false;
  }

  peek(): number {
    this.refill();
    return Math.floor(this.tokens);
  }

  waitTime(count = 1): number {
    this.refill();
    if (this.tokens >= count) return 0;
    return Math.ceil((count - this.tokens) / this.refillRate * 1000);
  }
}

export class DistributedBurstController {
  private buckets: Map<string, TokenBucket> = new Map();
  private readonly defaultConfig: TokenBucketConfig;

  constructor(defaultConfig?: Partial<TokenBucketConfig>) {
    this.defaultConfig = {
      capacity: defaultConfig?.capacity ?? 100,
      refillRate: defaultConfig?.refillRate ?? 10,
      initialTokens: defaultConfig?.initialTokens,
    };
  }

  getBucket(key: string, config?: Partial<TokenBucketConfig>): TokenBucket {
    if (!this.buckets.has(key)) {
      this.buckets.set(key, new TokenBucket({ ...this.defaultConfig, ...config }));
    }
    return this.buckets.get(key)!;
  }

  tryConsume(key: string, count = 1): { allowed: boolean; remaining: number; retryAfterMs: number } {
    const bucket = this.getBucket(key);
    const allowed = bucket.consume(count);
    return {
      allowed,
      remaining: bucket.peek(),
      retryAfterMs: allowed ? 0 : bucket.waitTime(count),
    };
  }

  getStats(): { buckets: number; entries: Array<{ key: string; tokens: number }> } {
    const entries = Array.from(this.buckets.entries()).map(([key, bucket]) => ({
      key,
      tokens: bucket.peek(),
    }));
    return { buckets: this.buckets.size, entries };
  }

  cleanup(maxIdleMs = 300000): number {
    const now = Date.now();
    let removed = 0;
    for (const [key, bucket] of this.buckets.entries()) {
      if (bucket.peek() >= this.defaultConfig.capacity) {
        this.buckets.delete(key);
        removed++;
      }
    }
    return removed;
  }
}
TYPESCRIPT
)
    _ts_write_file "$outfile" "$content" || return 1
    TS_BURST_CONTROL_OK=true
    TS_GENERATED=$((TS_GENERATED + 1))
    _ts_ok "Burst control generated"
    return 0
}

# =============================================================================
# Full Generation
# =============================================================================
_ts_generate_all() {
    local project_dir="${1:-.}"
    _ts_log "Generating full traffic shaping layer..."
    _ts_generate_priority_queue "$project_dir"
    _ts_generate_bandwidth_limit "$project_dir"
    _ts_generate_burst_control "$project_dir"
    _ts_ok "Traffic shaping complete: ${TS_GENERATED} components, ${TS_ERRORS} errors"
    return 0
}

# =============================================================================
# Report / Score
# =============================================================================
_ts_report() {
    echo -e "\n  ${BOLD:-\033[1m}═══ Traffic Shaping v${TS_VERSION} ═══${NC:-\033[0m}"
    echo -e "  Generated  : ${TS_GENERATED}"
    echo -e "  Files      : ${TS_FILES_WRITTEN}"
    echo -e "  Errors     : ${TS_ERRORS}"
    echo -e "  Priority Q : ${TS_PRIORITY_QUEUE_OK}"
    echo -e "  Bandwidth  : ${TS_BANDWIDTH_LIMIT_OK}"
    echo -e "  Burst Ctrl : ${TS_BURST_CONTROL_OK}"
}

_ts_report_json() {
    cat <<JSON
{"module":"traffic-shaping","version":"${TS_VERSION}","generated":${TS_GENERATED},"errors":${TS_ERRORS},"components":{"priority_queue":${TS_PRIORITY_QUEUE_OK},"bandwidth_limit":${TS_BANDWIDTH_LIMIT_OK},"burst_control":${TS_BURST_CONTROL_OK}}}
JSON
}

_ts_score() {
    local score=50
    ${TS_PRIORITY_QUEUE_OK} && score=$((score + 15))
    ${TS_BANDWIDTH_LIMIT_OK} && score=$((score + 15))
    ${TS_BURST_CONTROL_OK} && score=$((score + 15))
    [[ ${TS_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry self-registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "traffic-shaping" --version "451.0" \
        --description "トラフィックシェーピング: 優先度キュー×帯域制限×バースト制御" \
        --init "_ts_init" --report "_ts_report" --score "_ts_score" \
        --enable-var "ENABLE_TRAFFIC_SHAPING" --cli-flags "--traffic-shaping:--no-traffic-shaping"
fi

# v2003.1: source時のexit codeを確実に0にする
true
