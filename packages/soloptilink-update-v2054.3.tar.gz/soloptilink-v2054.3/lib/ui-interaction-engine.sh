#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - UI Interaction Engine
# =============================================================================
# ユーザー苦情No.1「ボタンが押せない、チャットが動かない、操作できない」を根絶。
#
# 問題: 生成AIは見た目だけ正しいUIを作り、インタラクションを空にする
#   - onClick={() => {}} の空ハンドラ
#   - onSubmit なしの <form>
#   - href="#" のリンク
#   - onChange なしの <input>
#   - 閉じるボタンのないモーダル
#
# 解決: 2段構えで「動くUI」を保証
#   Part A: 生成時にインタラクションパターンをClaudeに注入（予防）
#   Part B: 生成後に全インタラクティブ要素を検証（検出＋修正）
#
# 8カテゴリのインタラクション検証:
#   UIE-001: ボタン（onClick + loading + disabled）
#   UIE-002: フォーム（onSubmit + validation + error display）
#   UIE-003: チャット（送信 + メッセージ表示 + リアルタイム）
#   UIE-004: ナビゲーション（Link/router.push + active state）
#   UIE-005: モーダル（open/close + backdrop + escape + focus trap）
#   UIE-006: ドロップダウン/セレクト（open/close + keyboard + selection）
#   UIE-007: ドラッグ&ドロップ（onDragEnd + state update + API sync）
#   UIE-008: 無限スクロール/ページネーション（Intersection Observer + fetch）
#
# 全globals: UIE_ prefix
# =============================================================================

[[ -n "${_UI_INTERACTION_ENGINE_LOADED:-}" ]] && return 0
_UI_INTERACTION_ENGINE_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g UIE_VERSION="140.0"
declare -g UIE_INITIALIZED=false
declare -g UIE_INJECT_COUNT=0
declare -g UIE_LAST_SCORE=0
declare -g UIE_LAST_ISSUES=""
declare -g UIE_LAST_ISSUE_COUNT=0
declare -g UIE_BROKEN_COUNT=0
declare -g UIE_CHECKED_FILES=0
declare -g UIE_CHECKED_ELEMENTS=0

# Enable flag (default: true)
declare -g ENABLE_UIE="${ENABLE_UIE:-true}"

# =============================================================================
# 初期化
# =============================================================================
uie_init() {
    UIE_INITIALIZED=true
    UIE_INJECT_COUNT=0
    UIE_LAST_SCORE=0
    UIE_LAST_ISSUE_COUNT=0
    UIE_LAST_ISSUES=""
    UIE_BROKEN_COUNT=0
    UIE_CHECKED_FILES=0
    UIE_CHECKED_ELEMENTS=0
    return 0
}

uie_init_message() {
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} UI Interaction Engine v${UIE_VERSION} (8 interaction categories)" >&2
}

# =============================================================================
# Part A: Generation Patterns
# =============================================================================

# -----------------------------------------------------------------------------
# UIE-001: Button Interaction Pattern
# -----------------------------------------------------------------------------
_uie_pattern_button() {
    cat <<'PATTERN'
## [UIE-001] Button Interaction Pattern (MANDATORY)

Every `<button>` MUST have a working handler. Empty handlers are FORBIDDEN.

```tsx
// === CORRECT: Button with full interaction lifecycle ===
const [loading, setLoading] = useState(false);

const handleAction = async () => {
  setLoading(true);
  try {
    const res = await fetch('/api/resource', { method: 'POST' });
    if (!res.ok) throw new Error('操作に失敗しました');
    // Success: update UI state, show toast, navigate, or mutate
    mutate(); // or router.push() or toast.success()
  } catch (err) {
    alert(err instanceof Error ? err.message : 'エラーが発生しました');
  } finally {
    setLoading(false);
  }
};

<button
  onClick={handleAction}
  disabled={loading}
  className="px-4 py-2 bg-blue-600 text-white rounded disabled:opacity-50"
>
  {loading ? '処理中...' : '実行'}
</button>
```

**FORBIDDEN patterns (auto-FAIL)**:
- `onClick={() => {}}` - empty handler
- `onClick={() => console.log('clicked')}` - console.log only
- `onClick={() => alert('TODO')}` - placeholder alert
- `<button>` without onClick and not type="submit" inside a form
- onClick referencing an undefined function
PATTERN
}

# -----------------------------------------------------------------------------
# UIE-002: Form Interaction Pattern
# -----------------------------------------------------------------------------
_uie_pattern_form() {
    cat <<'PATTERN'
## [UIE-002] Form Interaction Pattern (MANDATORY)

Every `<form>` MUST have onSubmit. Every `<input>` MUST be controlled or registered.

```tsx
// === CORRECT: Form with complete interaction chain ===
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';

const schema = z.object({
  name: z.string().min(1, '必須項目です'),
  email: z.string().email('有効なメールアドレスを入力'),
});
type FormValues = z.infer<typeof schema>;

const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm<FormValues>({
  resolver: zodResolver(schema),
});

const onSubmit = async (data: FormValues) => {
  try {
    const res = await fetch('/api/resource', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    if (!res.ok) throw new Error('保存に失敗しました');
    router.push('/resource');
  } catch (err) {
    setError(err instanceof Error ? err.message : 'エラーが発生しました');
  }
};

<form onSubmit={handleSubmit(onSubmit)}>
  <input {...register('name')} />
  {errors.name && <p className="text-red-600">{errors.name.message}</p>}

  <input {...register('email')} />
  {errors.email && <p className="text-red-600">{errors.email.message}</p>}

  <button type="submit" disabled={isSubmitting}>
    {isSubmitting ? '保存中...' : '保存'}
  </button>
</form>
```

**FORBIDDEN patterns (auto-FAIL)**:
- `<form>` without onSubmit
- `<input>` without onChange, value, register, or ref
- `<textarea>` without onChange or register
- Submit button without disabled={isSubmitting}
PATTERN
}

# -----------------------------------------------------------------------------
# UIE-003: Chat Interaction Pattern
# -----------------------------------------------------------------------------
_uie_pattern_chat() {
    cat <<'PATTERN'
## [UIE-003] Chat/Messaging Interaction Pattern (MANDATORY for chat domains)

Chat UI MUST have: message list, input, send handler, auto-scroll, loading.

```tsx
const [messages, setMessages] = useState<Message[]>([]);
const [input, setInput] = useState('');
const [sending, setSending] = useState(false);
const bottomRef = useRef<HTMLDivElement>(null);

// Load history
useEffect(() => {
  fetch('/api/messages').then(r => r.json()).then(d => setMessages(d.data ?? []));
}, []);

// Auto-scroll on new messages
useEffect(() => {
  bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
}, [messages]);

// Send handler with optimistic update
const handleSend = async () => {
  if (!input.trim() || sending) return;
  const tempId = crypto.randomUUID();
  const optimistic = { id: tempId, content: input.trim(), sender: 'me', createdAt: new Date().toISOString() };

  setMessages(prev => [...prev, optimistic]);
  setInput('');
  setSending(true);

  try {
    const res = await fetch('/api/messages', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ content: optimistic.content }),
    });
    if (!res.ok) throw new Error('送信失敗');
    const saved = await res.json();
    setMessages(prev => prev.map(m => m.id === tempId ? saved : m));
  } catch {
    setMessages(prev => prev.filter(m => m.id !== tempId));
    alert('メッセージの送信に失敗しました');
  } finally {
    setSending(false);
  }
};

// Render: message list + input + send button
<div className="flex flex-col h-full">
  <div className="flex-1 overflow-y-auto p-4 space-y-2">
    {messages.map(m => <div key={m.id}>{m.content}</div>)}
    <div ref={bottomRef} />
  </div>
  <div className="border-t p-3 flex gap-2">
    <input
      value={input}
      onChange={e => setInput(e.target.value)}
      onKeyDown={e => e.key === 'Enter' && !e.shiftKey && handleSend()}
      placeholder="メッセージを入力..."
      className="flex-1 border rounded px-3 py-2"
    />
    <button onClick={handleSend} disabled={!input.trim() || sending}>
      {sending ? '送信中...' : '送信'}
    </button>
  </div>
</div>
```

**REQUIRED**: send handler with API call, input with onChange+onKeyDown, auto-scroll ref, loading state
PATTERN
}

# -----------------------------------------------------------------------------
# UIE-004: Navigation Interaction Pattern
# -----------------------------------------------------------------------------
_uie_pattern_navigation() {
    cat <<'PATTERN'
## [UIE-004] Navigation Interaction Pattern (MANDATORY)

All links and navigation items MUST navigate to real pages.

```tsx
import Link from 'next/link';
import { useRouter, usePathname } from 'next/navigation';

const router = useRouter();
const pathname = usePathname();

// Preferred: Next.js Link for static navigation
<Link href="/dashboard" className={pathname === '/dashboard' ? 'text-blue-600 font-bold' : ''}>
  ダッシュボード
</Link>

// Programmatic navigation with loading state
const [navigating, setNavigating] = useState(false);
const navigateTo = (path: string) => {
  setNavigating(true);
  router.push(path);
};

<button onClick={() => navigateTo('/items/new')} disabled={navigating}>
  {navigating ? '遷移中...' : '新規作成'}
</button>
```

**FORBIDDEN patterns (auto-FAIL)**:
- `<a href="#">` or `<a href="javascript:void(0)">`
- `<Link href="#">` placeholder links
- onClick without router.push/router.back/window.location
- Navigation to pages that don't exist in the project
PATTERN
}

# -----------------------------------------------------------------------------
# UIE-005: Modal/Dialog Interaction Pattern
# -----------------------------------------------------------------------------
_uie_pattern_modal() {
    cat <<'PATTERN'
## [UIE-005] Modal/Dialog Interaction Pattern (MANDATORY)

Modals MUST have: open/close state, backdrop click, escape key, close button.

```tsx
const [open, setOpen] = useState(false);

// Escape key handler
useEffect(() => {
  if (!open) return;
  const handler = (e: KeyboardEvent) => { if (e.key === 'Escape') setOpen(false); };
  document.addEventListener('keydown', handler);
  return () => document.removeEventListener('keydown', handler);
}, [open]);

// Trigger
<button onClick={() => setOpen(true)}>開く</button>

// Modal with backdrop click + close button
{open && (
  <div className="fixed inset-0 z-50 flex items-center justify-center">
    {/* Backdrop: click to close */}
    <div className="absolute inset-0 bg-black/50" onClick={() => setOpen(false)} />
    {/* Content */}
    <div className="relative bg-white rounded-lg p-6 max-w-md w-full mx-4" role="dialog" aria-modal="true">
      <button
        onClick={() => setOpen(false)}
        className="absolute top-3 right-3 text-gray-400 hover:text-gray-600"
        aria-label="閉じる"
      >
        ✕
      </button>
      {/* Modal body with form or content */}
    </div>
  </div>
)}
```

**REQUIRED**: open state, setOpen(true) on trigger, setOpen(false) on close/backdrop/escape, aria attributes
PATTERN
}

# -----------------------------------------------------------------------------
# UIE-006: Dropdown/Select Interaction Pattern
# -----------------------------------------------------------------------------
_uie_pattern_dropdown() {
    cat <<'PATTERN'
## [UIE-006] Dropdown/Select Interaction Pattern (MANDATORY)

Select/dropdown elements MUST respond to user selection.

```tsx
// Native select with onChange
const [status, setStatus] = useState('active');

<select
  value={status}
  onChange={(e) => {
    setStatus(e.target.value);
    handleStatusChange(e.target.value); // trigger side effect
  }}
  className="border rounded px-3 py-2"
>
  <option value="active">有効</option>
  <option value="inactive">無効</option>
  <option value="archived">アーカイブ</option>
</select>

// Custom dropdown with keyboard navigation
const [dropdownOpen, setDropdownOpen] = useState(false);
const [selected, setSelected] = useState<string | null>(null);
const [focusIndex, setFocusIndex] = useState(-1);

const options = ['Option A', 'Option B', 'Option C'];

const handleKeyDown = (e: React.KeyboardEvent) => {
  if (e.key === 'ArrowDown') setFocusIndex(i => Math.min(options.length - 1, i + 1));
  if (e.key === 'ArrowUp') setFocusIndex(i => Math.max(0, i - 1));
  if (e.key === 'Enter' && focusIndex >= 0) {
    setSelected(options[focusIndex]);
    setDropdownOpen(false);
  }
  if (e.key === 'Escape') setDropdownOpen(false);
};
```

**FORBIDDEN**: `<select>` without onChange, custom dropdown without keyboard support
PATTERN
}

# -----------------------------------------------------------------------------
# UIE-007: Drag-and-Drop Interaction Pattern
# -----------------------------------------------------------------------------
_uie_pattern_dnd() {
    cat <<'PATTERN'
## [UIE-007] Drag-and-Drop Interaction Pattern (when applicable)

DnD MUST update both local state and backend on reorder.

```tsx
import { DndContext, closestCenter, DragEndEvent } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy, useSortable, arrayMove } from '@dnd-kit/sortable';

const [items, setItems] = useState<Item[]>(initialItems);

const handleDragEnd = async (event: DragEndEvent) => {
  const { active, over } = event;
  if (!over || active.id === over.id) return;

  const oldIndex = items.findIndex(i => i.id === active.id);
  const newIndex = items.findIndex(i => i.id === over.id);
  const reordered = arrayMove(items, oldIndex, newIndex);

  setItems(reordered); // Optimistic UI update
  try {
    await fetch('/api/items/reorder', {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids: reordered.map(i => i.id) }),
    });
  } catch {
    setItems(items); // Rollback on failure
    alert('並び替えの保存に失敗しました');
  }
};

<DndContext collisionDetection={closestCenter} onDragEnd={handleDragEnd}>
  <SortableContext items={items.map(i => i.id)} strategy={verticalListSortingStrategy}>
    {items.map(item => <SortableItem key={item.id} item={item} />)}
  </SortableContext>
</DndContext>
```

**REQUIRED**: onDragEnd with state update + API sync, optimistic update with rollback
PATTERN
}

# -----------------------------------------------------------------------------
# UIE-008: Infinite Scroll / Pagination Interaction Pattern
# -----------------------------------------------------------------------------
_uie_pattern_infinite_scroll() {
    cat <<'PATTERN'
## [UIE-008] Infinite Scroll / Pagination Pattern (MANDATORY for lists)

Long lists MUST have pagination or infinite scroll that actually loads data.

```tsx
// === Intersection Observer infinite scroll ===
const [items, setItems] = useState<Item[]>([]);
const [page, setPage] = useState(1);
const [hasMore, setHasMore] = useState(true);
const [loadingMore, setLoadingMore] = useState(false);
const observerRef = useRef<HTMLDivElement>(null);

const loadMore = useCallback(async () => {
  if (loadingMore || !hasMore) return;
  setLoadingMore(true);
  try {
    const res = await fetch(`/api/items?page=${page + 1}&limit=20`);
    if (!res.ok) throw new Error('読み込み失敗');
    const data = await res.json();
    if (data.data.length === 0) {
      setHasMore(false);
    } else {
      setItems(prev => [...prev, ...data.data]);
      setPage(p => p + 1);
    }
  } catch {
    // Retry is available via scroll
  } finally {
    setLoadingMore(false);
  }
}, [page, loadingMore, hasMore]);

useEffect(() => {
  if (!observerRef.current) return;
  const observer = new IntersectionObserver(
    entries => { if (entries[0].isIntersecting) loadMore(); },
    { threshold: 0.1 }
  );
  observer.observe(observerRef.current);
  return () => observer.disconnect();
}, [loadMore]);

// Render
<div>
  {items.map(item => <ItemCard key={item.id} item={item} />)}
  {hasMore && <div ref={observerRef} className="h-10 flex items-center justify-center">
    {loadingMore ? <span>読み込み中...</span> : <span>スクロールして続きを表示</span>}
  </div>}
  {!hasMore && <p className="text-center text-gray-400 py-4">全て表示しました</p>}
</div>
```

**REQUIRED**: load trigger (observer or button), loading state, hasMore flag, append to existing data
PATTERN
}

# =============================================================================
# Pattern Injection (called during code generation prompts)
# =============================================================================
uie_inject_interaction_patterns() {
    local claude_prompt="${1:-}"
    local domain="${2:-general}"

    UIE_INJECT_COUNT=$((UIE_INJECT_COUNT + 1))

    local output=""
    output+="
# ============================================================
# UI Interaction Engine v140.0 - インタラクション必須パターン
# ============================================================
# ユーザー苦情No.1: 「ボタンが押せない」「チャットが動かない」を根絶する。
# 全てのインタラクティブ要素は以下のパターンに完全準拠すること。
# 空ハンドラ、プレースホルダ、TODOコメント残しは品質ゲートで自動FAIL。
# ============================================================

$(_uie_pattern_button)

$(_uie_pattern_form)

$(_uie_pattern_navigation)

$(_uie_pattern_modal)

$(_uie_pattern_dropdown)"

    # Chat domain: add chat pattern
    case "$domain" in
        chat|messaging|communication|sns|social|support|helpdesk)
            output+="

$(_uie_pattern_chat)"
            ;;
    esac

    # Complex UI domains: add DnD pattern
    case "$domain" in
        kanban|project|task|trello|board|crm|cms)
            output+="

$(_uie_pattern_dnd)"
            ;;
    esac

    # List-heavy domains: add infinite scroll
    case "$domain" in
        ecommerce|ec|shop|catalog|social|sns|feed|blog|news)
            output+="

$(_uie_pattern_infinite_scroll)"
            ;;
    esac

    echo "${claude_prompt}

${output}"
}

# =============================================================================
# Part B: Post-Generation Validation
# =============================================================================

# -----------------------------------------------------------------------------
# Helper: Find frontend files
# -----------------------------------------------------------------------------
_uie_find_frontend_files() {
    local project_dir="$1"
    local files=""

    for dir in "${project_dir}/app" "${project_dir}/src/app" \
               "${project_dir}/src/components" "${project_dir}/components" \
               "${project_dir}/src/pages" "${project_dir}/pages"; do
        if [[ -d "$dir" ]]; then
            files+=$(find "$dir" -name "*.tsx" -o -name "*.jsx" 2>/dev/null \
                | grep -v node_modules | grep -v '.next' | grep -v '.test.' | grep -v '.spec.' || true)
            files+=$'\n'
        fi
    done

    echo "$files" | sort -u | grep -v '^$'
}

# -----------------------------------------------------------------------------
# Check UIE-001: Buttons must have working onClick or be submit in form
# -----------------------------------------------------------------------------
_uie_check_buttons() {
    local project_dir="$1"
    local issues=""
    local total=0
    local pass=0

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue

        # Find all <button lines
        local button_count
        button_count=$(echo "$content" | grep -c '<button' 2>/dev/null || echo "0")
        [[ "$button_count" -eq 0 ]] && continue

        local rel_file="${file#${project_dir}/}"
        local line_num=0

        while IFS= read -r line; do
            line_num=$((line_num + 1))
            # Skip if not a button line
            echo "$line" | grep -q '<button' 2>/dev/null || continue

            total=$((total + 1))
            UIE_CHECKED_ELEMENTS=$((UIE_CHECKED_ELEMENTS + 1))

            # Pass: type="submit" (handled by form onSubmit)
            if echo "$line" | grep -qE 'type\s*=\s*["\x27]submit["\x27]' 2>/dev/null; then
                pass=$((pass + 1))
                continue
            fi

            # Pass: has onClick with a real handler
            if echo "$line" | grep -qE 'onClick\s*=\s*\{' 2>/dev/null; then
                # Fail: empty handler () => {}
                if echo "$line" | grep -qE 'onClick\s*=\s*\{\s*\(\)\s*=>\s*\{\s*\}\s*\}' 2>/dev/null; then
                    issues+="[EMPTY_BUTTON_HANDLER] ${rel_file}:${line_num}: onClick={() => {}) 空ハンドラ\n"
                    continue
                fi
                # Fail: console.log only
                if echo "$line" | grep -qE "onClick\s*=\s*\{\s*\(\)\s*=>\s*console\.log" 2>/dev/null; then
                    issues+="[PLACEHOLDER_BUTTON] ${rel_file}:${line_num}: onClick with console.log only\n"
                    continue
                fi
                pass=$((pass + 1))
                continue
            fi

            # No onClick and not submit type
            issues+="[BUTTON_NO_HANDLER] ${rel_file}:${line_num}: <button> without onClick or type=\"submit\"\n"
        done <<< "$content"
    done < <(_uie_find_frontend_files "$project_dir")

    echo "$issues"
    if [[ $total -eq 0 ]]; then
        echo "100" >&3
    else
        echo "$(( pass * 100 / total ))" >&3
    fi
}

# -----------------------------------------------------------------------------
# Check UIE-002: Forms must have onSubmit, inputs must be controlled
# -----------------------------------------------------------------------------
_uie_check_forms() {
    local project_dir="$1"
    local issues=""
    local total=0
    local pass=0

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue
        local rel_file="${file#${project_dir}/}"

        # Check <form> elements have onSubmit
        if echo "$content" | grep -q '<form' 2>/dev/null; then
            total=$((total + 1))
            UIE_CHECKED_ELEMENTS=$((UIE_CHECKED_ELEMENTS + 1))

            if echo "$content" | grep -qE 'onSubmit\s*=\s*\{|handleSubmit' 2>/dev/null; then
                pass=$((pass + 1))
            else
                issues+="[FORM_NO_SUBMIT] ${rel_file}: <form> without onSubmit handler\n"
            fi
        fi

        # Check inputs are controlled or registered
        local input_lines
        input_lines=$(echo "$content" | grep -n '<input\|<textarea' 2>/dev/null || true)
        while IFS= read -r iline; do
            [[ -z "$iline" ]] && continue
            local lnum="${iline%%:*}"
            local lcontent="${iline#*:}"

            # Skip hidden inputs and submit buttons
            echo "$lcontent" | grep -qE 'type\s*=\s*["\x27](hidden|submit)["\x27]' 2>/dev/null && continue

            total=$((total + 1))
            UIE_CHECKED_ELEMENTS=$((UIE_CHECKED_ELEMENTS + 1))

            if echo "$lcontent" | grep -qE 'onChange|register\(|\.\.\.register|value\s*=\s*\{|defaultValue|ref\s*=\s*\{' 2>/dev/null; then
                pass=$((pass + 1))
            else
                issues+="[INPUT_NOT_CONTROLLED] ${rel_file}:${lnum}: <input>/<textarea> without onChange/register/value\n"
            fi
        done <<< "$input_lines"
    done < <(_uie_find_frontend_files "$project_dir")

    echo "$issues"
    if [[ $total -eq 0 ]]; then
        echo "100" >&3
    else
        echo "$(( pass * 100 / total ))" >&3
    fi
}

# -----------------------------------------------------------------------------
# Check UIE-003: Chat elements must have send handler + input wiring
# -----------------------------------------------------------------------------
_uie_check_chat() {
    local project_dir="$1"
    local issues=""
    local total=0
    local pass=0

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue
        local rel_file="${file#${project_dir}/}"

        # Detect chat-like components (message list + input pattern)
        local is_chat=false
        if echo "$content" | grep -qiE 'chat|message|メッセージ' 2>/dev/null; then
            if echo "$content" | grep -qE '\.map\s*\(' 2>/dev/null; then
                is_chat=true
            fi
        fi
        [[ "$is_chat" != "true" ]] && continue

        total=$((total + 1))
        UIE_CHECKED_ELEMENTS=$((UIE_CHECKED_ELEMENTS + 1))
        local chat_score=0
        local chat_max=5

        # 1. Has send handler
        echo "$content" | grep -qE 'handleSend|sendMessage|onSend|送信' 2>/dev/null && chat_score=$((chat_score + 1))

        # 2. Input with onChange
        echo "$content" | grep -qE 'onChange.*setInput\|onChange.*setMessage\|onChange.*set[A-Z]' 2>/dev/null && chat_score=$((chat_score + 1))

        # 3. Enter key handler
        echo "$content" | grep -qE "onKeyDown|onKeyPress|key\s*===?\s*['\"]Enter['\"]" 2>/dev/null && chat_score=$((chat_score + 1))

        # 4. Auto-scroll ref
        echo "$content" | grep -qE 'scrollIntoView|useRef.*bottom|useRef.*scroll|messagesEnd' 2>/dev/null && chat_score=$((chat_score + 1))

        # 5. API call for sending
        echo "$content" | grep -qE "fetch\s*\(|axios\.|\.post\s*\(" 2>/dev/null && chat_score=$((chat_score + 1))

        if [[ $chat_score -ge 4 ]]; then
            pass=$((pass + 1))
        else
            local missing=""
            echo "$content" | grep -qE 'handleSend|sendMessage|onSend' 2>/dev/null || missing+="send-handler,"
            echo "$content" | grep -qE "onKeyDown|key\s*===?\s*['\"]Enter['\"]" 2>/dev/null || missing+="enter-key,"
            echo "$content" | grep -qE 'scrollIntoView' 2>/dev/null || missing+="auto-scroll,"
            echo "$content" | grep -qE "fetch\s*\(|axios\." 2>/dev/null || missing+="api-call,"
            issues+="[BROKEN_CHAT] ${rel_file}: Chat missing: ${missing%,} (${chat_score}/${chat_max})\n"
        fi
    done < <(_uie_find_frontend_files "$project_dir")

    echo "$issues"
    if [[ $total -eq 0 ]]; then
        echo "100" >&3
    else
        echo "$(( pass * 100 / total ))" >&3
    fi
}

# -----------------------------------------------------------------------------
# Check UIE-004: Links/anchors must have real hrefs
# -----------------------------------------------------------------------------
_uie_check_navigation() {
    local project_dir="$1"
    local issues=""
    local total=0
    local pass=0

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue
        local rel_file="${file#${project_dir}/}"

        # Check <a> tags
        local a_lines
        a_lines=$(echo "$content" | grep -n '<a ' 2>/dev/null || true)
        while IFS= read -r aline; do
            [[ -z "$aline" ]] && continue
            local lnum="${aline%%:*}"
            local lcontent="${aline#*:}"

            total=$((total + 1))
            UIE_CHECKED_ELEMENTS=$((UIE_CHECKED_ELEMENTS + 1))

            # Fail: href="#" or href="javascript:void(0)"
            if echo "$lcontent" | grep -qE 'href\s*=\s*["\x27](#|javascript:)' 2>/dev/null; then
                issues+="[DEAD_LINK] ${rel_file}:${lnum}: <a> with href=\"#\" or javascript:void(0)\n"
                continue
            fi

            # Pass: has real href or onClick with navigation
            if echo "$lcontent" | grep -qE 'href\s*=\s*["\x27{]' 2>/dev/null; then
                pass=$((pass + 1))
            elif echo "$lcontent" | grep -qE 'onClick' 2>/dev/null; then
                pass=$((pass + 1))
            else
                issues+="[LINK_NO_HREF] ${rel_file}:${lnum}: <a> without href or onClick\n"
            fi
        done <<< "$a_lines"

        # Check Next.js <Link> components
        local link_lines
        link_lines=$(echo "$content" | grep -n '<Link ' 2>/dev/null || true)
        while IFS= read -r lline; do
            [[ -z "$lline" ]] && continue
            local lnum="${lline%%:*}"
            local lcontent="${lline#*:}"

            total=$((total + 1))
            UIE_CHECKED_ELEMENTS=$((UIE_CHECKED_ELEMENTS + 1))

            if echo "$lcontent" | grep -qE 'href\s*=\s*["\x27]#["\x27]' 2>/dev/null; then
                issues+="[DEAD_LINK] ${rel_file}:${lnum}: <Link> with href=\"#\"\n"
                continue
            fi

            if echo "$lcontent" | grep -qE 'href\s*=\s*["\x27{/]' 2>/dev/null; then
                pass=$((pass + 1))
            else
                issues+="[LINK_NO_HREF] ${rel_file}:${lnum}: <Link> without valid href\n"
            fi
        done <<< "$link_lines"
    done < <(_uie_find_frontend_files "$project_dir")

    echo "$issues"
    if [[ $total -eq 0 ]]; then
        echo "100" >&3
    else
        echo "$(( pass * 100 / total ))" >&3
    fi
}

# -----------------------------------------------------------------------------
# Check UIE-005: Modals must have close mechanism
# -----------------------------------------------------------------------------
_uie_check_modals() {
    local project_dir="$1"
    local issues=""
    local total=0
    local pass=0

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue
        local rel_file="${file#${project_dir}/}"

        # Detect modals (Dialog/Modal components or fixed inset-0 pattern)
        local has_modal=false
        if echo "$content" | grep -qE '<Dialog|<Modal|fixed\s+inset-0|role\s*=\s*["\x27]dialog["\x27]' 2>/dev/null; then
            has_modal=true
        fi
        [[ "$has_modal" != "true" ]] && continue

        total=$((total + 1))
        UIE_CHECKED_ELEMENTS=$((UIE_CHECKED_ELEMENTS + 1))
        local modal_score=0
        local modal_max=3

        # 1. Has open state management
        echo "$content" | grep -qE 'useState.*open|isOpen|showModal|setOpen|setIsOpen|setShowModal|onOpenChange' 2>/dev/null && modal_score=$((modal_score + 1))

        # 2. Has close button/mechanism
        echo "$content" | grep -qE 'setOpen\(false\)|setIsOpen\(false\)|setShowModal\(false\)|onClose|onOpenChange' 2>/dev/null && modal_score=$((modal_score + 1))

        # 3. Has backdrop click or escape key
        if echo "$content" | grep -qE 'onClick.*close\|onClick.*setOpen.*false\|Escape\|onClose' 2>/dev/null; then
            modal_score=$((modal_score + 1))
        elif echo "$content" | grep -qE '<Dialog' 2>/dev/null; then
            # Headless UI Dialog handles this automatically
            modal_score=$((modal_score + 1))
        fi

        if [[ $modal_score -ge 2 ]]; then
            pass=$((pass + 1))
        else
            issues+="[BROKEN_MODAL] ${rel_file}: Modal missing close mechanism (score: ${modal_score}/${modal_max})\n"
        fi
    done < <(_uie_find_frontend_files "$project_dir")

    echo "$issues"
    if [[ $total -eq 0 ]]; then
        echo "100" >&3
    else
        echo "$(( pass * 100 / total ))" >&3
    fi
}

# -----------------------------------------------------------------------------
# Check UIE-006: Select elements must have onChange
# -----------------------------------------------------------------------------
_uie_check_selects() {
    local project_dir="$1"
    local issues=""
    local total=0
    local pass=0

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue
        local rel_file="${file#${project_dir}/}"

        local select_lines
        select_lines=$(echo "$content" | grep -n '<select' 2>/dev/null || true)
        while IFS= read -r sline; do
            [[ -z "$sline" ]] && continue
            local lnum="${sline%%:*}"
            local lcontent="${sline#*:}"

            total=$((total + 1))
            UIE_CHECKED_ELEMENTS=$((UIE_CHECKED_ELEMENTS + 1))

            if echo "$lcontent" | grep -qE 'onChange|register\(|\.\.\.register' 2>/dev/null; then
                pass=$((pass + 1))
            else
                issues+="[SELECT_NO_HANDLER] ${rel_file}:${lnum}: <select> without onChange or register\n"
            fi
        done <<< "$select_lines"
    done < <(_uie_find_frontend_files "$project_dir")

    echo "$issues"
    if [[ $total -eq 0 ]]; then
        echo "100" >&3
    else
        echo "$(( pass * 100 / total ))" >&3
    fi
}

# -----------------------------------------------------------------------------
# Check UIE-007: Async handlers must have loading states
# -----------------------------------------------------------------------------
_uie_check_async_loading() {
    local project_dir="$1"
    local issues=""
    local total=0
    local pass=0

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue
        local rel_file="${file#${project_dir}/}"

        # Files with async handlers that call fetch/axios
        if echo "$content" | grep -qE 'async\s.*=>\s*\{' 2>/dev/null; then
            if echo "$content" | grep -qE 'fetch\s*\(|axios\.' 2>/dev/null; then
                total=$((total + 1))
                UIE_CHECKED_ELEMENTS=$((UIE_CHECKED_ELEMENTS + 1))

                if echo "$content" | grep -qE 'setLoading|setSubmitting|setSending|setDeleting|isSubmitting|isLoading|loading|pending' 2>/dev/null; then
                    pass=$((pass + 1))
                else
                    issues+="[MISSING_ASYNC_LOADING] ${rel_file}: Async API handler without loading state management\n"
                fi
            fi
        fi
    done < <(_uie_find_frontend_files "$project_dir")

    echo "$issues"
    if [[ $total -eq 0 ]]; then
        echo "100" >&3
    else
        echo "$(( pass * 100 / total ))" >&3
    fi
}

# -----------------------------------------------------------------------------
# Check UIE-008: Event handlers reference defined functions
# -----------------------------------------------------------------------------
_uie_check_handler_definitions() {
    local project_dir="$1"
    local issues=""
    local total=0
    local pass=0

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue
        local rel_file="${file#${project_dir}/}"

        # Extract handler names from onClick={handlerName} patterns
        local handlers
        handlers=$(echo "$content" | grep -oE 'onClick\s*=\s*\{\s*([a-zA-Z_][a-zA-Z0-9_]*)' 2>/dev/null \
            | sed 's/onClick\s*=\s*{\s*//' | grep -v '^$' || true)

        while IFS= read -r handler; do
            [[ -z "$handler" ]] && continue
            # Skip inline arrow functions, common globals, and short variable names
            [[ "$handler" == "(" ]] && continue
            [[ "$handler" == "e" || "$handler" == "event" ]] && continue
            [[ ${#handler} -le 1 ]] && continue

            total=$((total + 1))
            UIE_CHECKED_ELEMENTS=$((UIE_CHECKED_ELEMENTS + 1))

            # Check if the function is defined in the same file
            if echo "$content" | grep -qE "(const|let|var|function)\s+${handler}[^a-zA-Z0-9_]" 2>/dev/null; then
                pass=$((pass + 1))
            elif echo "$content" | grep -qE "import.*${handler}" 2>/dev/null; then
                pass=$((pass + 1))
            elif echo "$content" | grep -qE "${handler}\s*:" 2>/dev/null; then
                # Destructured prop
                pass=$((pass + 1))
            else
                issues+="[UNDEFINED_HANDLER] ${rel_file}: onClick references '${handler}' which is not defined in file\n"
            fi
        done <<< "$handlers"
    done < <(_uie_find_frontend_files "$project_dir")

    echo "$issues"
    if [[ $total -eq 0 ]]; then
        echo "100" >&3
    else
        echo "$(( pass * 100 / total ))" >&3
    fi
}

# =============================================================================
# Main Validation Entry Point
# =============================================================================
uie_validate_interactions() {
    local project_dir="${1:-.}"

    UIE_CHECKED_FILES=0
    UIE_CHECKED_ELEMENTS=0
    UIE_BROKEN_COUNT=0

    # Count frontend files
    UIE_CHECKED_FILES=$(echo "$(_uie_find_frontend_files "$project_dir")" | grep -c '.' 2>/dev/null || echo "0")

    local all_issues=""
    local scores=()
    local issues score

    # Run all 8 checks via fd3 for score passing
    issues=$(_uie_check_buttons "$project_dir" 3>/tmp/uie_score_1.txt)
    score=$(cat /tmp/uie_score_1.txt 2>/dev/null || echo "100")
    all_issues+="$issues"
    scores+=("$score")

    issues=$(_uie_check_forms "$project_dir" 3>/tmp/uie_score_2.txt)
    score=$(cat /tmp/uie_score_2.txt 2>/dev/null || echo "100")
    all_issues+="$issues"
    scores+=("$score")

    issues=$(_uie_check_chat "$project_dir" 3>/tmp/uie_score_3.txt)
    score=$(cat /tmp/uie_score_3.txt 2>/dev/null || echo "100")
    all_issues+="$issues"
    scores+=("$score")

    issues=$(_uie_check_navigation "$project_dir" 3>/tmp/uie_score_4.txt)
    score=$(cat /tmp/uie_score_4.txt 2>/dev/null || echo "100")
    all_issues+="$issues"
    scores+=("$score")

    issues=$(_uie_check_modals "$project_dir" 3>/tmp/uie_score_5.txt)
    score=$(cat /tmp/uie_score_5.txt 2>/dev/null || echo "100")
    all_issues+="$issues"
    scores+=("$score")

    issues=$(_uie_check_selects "$project_dir" 3>/tmp/uie_score_6.txt)
    score=$(cat /tmp/uie_score_6.txt 2>/dev/null || echo "100")
    all_issues+="$issues"
    scores+=("$score")

    issues=$(_uie_check_async_loading "$project_dir" 3>/tmp/uie_score_7.txt)
    score=$(cat /tmp/uie_score_7.txt 2>/dev/null || echo "100")
    all_issues+="$issues"
    scores+=("$score")

    issues=$(_uie_check_handler_definitions "$project_dir" 3>/tmp/uie_score_8.txt)
    score=$(cat /tmp/uie_score_8.txt 2>/dev/null || echo "100")
    all_issues+="$issues"
    scores+=("$score")

    # Compute weighted average (buttons and forms weighted higher)
    local weights=(20 20 10 10 10 5 15 10)
    local weighted_total=0
    local weight_sum=0
    for i in "${!scores[@]}"; do
        local w="${weights[$i]:-10}"
        weighted_total=$((weighted_total + scores[i] * w))
        weight_sum=$((weight_sum + w))
    done

    if [[ $weight_sum -gt 0 ]]; then
        UIE_LAST_SCORE=$((weighted_total / weight_sum))
    else
        UIE_LAST_SCORE=100
    fi

    UIE_LAST_ISSUES="$all_issues"
    UIE_LAST_ISSUE_COUNT=$(echo -e "$all_issues" | grep -cE '\[' 2>/dev/null || echo "0")
    UIE_BROKEN_COUNT=$UIE_LAST_ISSUE_COUNT

    # Cleanup temp files
    rm -f /tmp/uie_score_*.txt 2>/dev/null || true

    echo -e "  ${CYAN:-\033[0;36m}[UIE] UI Interaction Score: ${UIE_LAST_SCORE}/100 (broken: ${UIE_BROKEN_COUNT}, files: ${UIE_CHECKED_FILES}, elements: ${UIE_CHECKED_ELEMENTS})${NC:-\033[0m}" >&2
    echo "${UIE_LAST_SCORE}"
}

# =============================================================================
# Get broken interactions list
# =============================================================================
uie_get_broken_interactions() {
    local project_dir="${1:-.}"

    # Re-run validation if not done yet
    if [[ -z "$UIE_LAST_ISSUES" && "$UIE_LAST_SCORE" -eq 0 ]]; then
        uie_validate_interactions "$project_dir" >/dev/null 2>&1
    fi

    echo -e "$UIE_LAST_ISSUES" | grep -v '^$' | sort
}

# =============================================================================
# Generate fix prompt for Claude
# =============================================================================
uie_generate_fix_prompt() {
    local project_dir="${1:-.}"

    if [[ ${UIE_LAST_ISSUE_COUNT:-0} -eq 0 ]]; then
        return 0
    fi

    cat <<EOF
## UI Interaction Engine v140.0 - 修正指示（${UIE_LAST_ISSUE_COUNT}件）

ユーザーの最大の苦情「ボタンが押せない、操作できない」の根本原因を修正します。
以下の全問題を修正してください。

$(echo -e "$UIE_LAST_ISSUES" | grep -v '^$' | sort)

### 修正ガイド:

**BUTTON_NO_HANDLER / EMPTY_BUTTON_HANDLER / PLACEHOLDER_BUTTON**:
- UIE-001パターン適用: onClick with async handler + try/catch + loading state
- 全ボタンは「何かを実行する」こと（API呼出/ページ遷移/状態変更）

**FORM_NO_SUBMIT**:
- UIE-002パターン適用: onSubmit={handleSubmit(onSubmit)} + React Hook Form
- zodResolver + field-level error + isSubmitting disabled

**INPUT_NOT_CONTROLLED**:
- UIE-002パターン適用: {...register('fieldName')} or onChange+value
- 全input/textareaは制御されていること

**BROKEN_CHAT**:
- UIE-003パターン適用: 完全なチャットUI（送信/受信/スクロール/リアルタイム）
- handleSend + onKeyDown(Enter) + scrollIntoView + API POST

**DEAD_LINK / LINK_NO_HREF**:
- UIE-004パターン適用: Next.js Link with real href or router.push
- href="#" を実在するページパスに置換

**BROKEN_MODAL**:
- UIE-005パターン適用: open state + close button + backdrop click + Escape key
- setOpen(false) を閉じるボタン/バックドロップ/Escapeに接続

**SELECT_NO_HANDLER**:
- UIE-006パターン適用: onChange={(e) => setState(e.target.value)}

**MISSING_ASYNC_LOADING**:
- useState(false) + setLoading(true) before fetch + finally { setLoading(false) }
- ボタンに disabled={loading} + テキスト変更

**UNDEFINED_HANDLER**:
- onClick で参照している関数が未定義。関数を実装するかインポートすること。
EOF
}

# =============================================================================
# Deep validation: trace event wiring
# =============================================================================
uie_validate_event_wiring() {
    local project_dir="${1:-.}"
    local issues=""
    local total=0
    local pass=0

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue
        local rel_file="${file#${project_dir}/}"

        # Find async functions with fetch calls
        local async_fns
        async_fns=$(echo "$content" | grep -oE '(const|let)\s+([a-zA-Z_][a-zA-Z0-9_]*)\s*=\s*async' 2>/dev/null \
            | sed 's/(const|let)\s\+//;s/\s*=\s*async//' | grep -oE '[a-zA-Z_][a-zA-Z0-9_]*' || true)

        while IFS= read -r fn_name; do
            [[ -z "$fn_name" ]] && continue

            # Check if this async fn has fetch/axios
            # We need multiline matching, use a simpler heuristic
            if echo "$content" | grep -qE "fetch\s*\(|axios\." 2>/dev/null; then
                total=$((total + 1))

                # Check 1: Has error handling (try/catch)
                local has_error_handling=false
                echo "$content" | grep -qE 'try\s*\{|\.catch\s*\(' 2>/dev/null && has_error_handling=true

                # Check 2: Has state update after API call
                local has_state_update=false
                echo "$content" | grep -qE 'set[A-Z]|mutate\(|router\.(push|refresh|back)|revalidate' 2>/dev/null && has_state_update=true

                if [[ "$has_error_handling" == "true" && "$has_state_update" == "true" ]]; then
                    pass=$((pass + 1))
                else
                    local missing=""
                    [[ "$has_error_handling" != "true" ]] && missing+="error-handling,"
                    [[ "$has_state_update" != "true" ]] && missing+="state-update-after-api,"
                    issues+="[WEAK_EVENT_WIRING] ${rel_file}: ${fn_name}() missing: ${missing%,}\n"
                fi
            fi
        done <<< "$async_fns"
    done < <(_uie_find_frontend_files "$project_dir")

    if [[ -n "$issues" ]]; then
        echo -e "$issues" | grep -v '^$'
    fi

    if [[ $total -eq 0 ]]; then
        echo "100"
    else
        echo "$(( pass * 100 / total ))"
    fi
}

# =============================================================================
# Report
# =============================================================================
uie_report() {
    echo -e "\n  ${BOLD:-}═══ UI Interaction Engine v${UIE_VERSION} ═══${NC:-}"
    echo -e "  インタラクションスコア : ${UIE_LAST_SCORE}/100"
    echo -e "  検査ファイル数         : ${UIE_CHECKED_FILES}"
    echo -e "  検査要素数             : ${UIE_CHECKED_ELEMENTS}"
    echo -e "  壊れた要素数           : ${UIE_BROKEN_COUNT}"
    echo -e "  パターン注入回数       : ${UIE_INJECT_COUNT}"
    if [[ ${UIE_BROKEN_COUNT:-0} -gt 0 ]]; then
        echo -e "  ${RED:-\033[0;31m}要修正:${NC:-\033[0m}"
        echo -e "$UIE_LAST_ISSUES" | grep -v '^$' | head -10 | while IFS= read -r line; do
            echo -e "    - ${line}"
        done
        [[ ${UIE_BROKEN_COUNT:-0} -gt 10 ]] && echo -e "    ... 他 $((UIE_BROKEN_COUNT - 10))件"
    fi
}

uie_report_json() {
    cat <<EOF
{"module":"ui-interaction-engine","version":"${UIE_VERSION}","score":${UIE_LAST_SCORE:-0},"checked_files":${UIE_CHECKED_FILES:-0},"checked_elements":${UIE_CHECKED_ELEMENTS:-0},"broken_count":${UIE_BROKEN_COUNT:-0},"inject_count":${UIE_INJECT_COUNT:-0}}
EOF
}

uie_score() {
    echo "${UIE_LAST_SCORE:-100}"
}

# =============================================================================
# v59.0: Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "ui-interaction-engine" \
        --version "140.0" \
        --description "UIインタラクション保証（ボタン/フォーム/チャット/ナビ/モーダル/DnD）" \
        --init "uie_init" \
        --report "uie_report" \
        --score "uie_score" \
        --enable-var "ENABLE_UIE" \
        --cli-flags "--ui-interaction-engine:--no-ui-interaction-engine" \
        --init-msg "uie_init_message"
fi

# v2003.1: source時のexit codeを確実に0にする
true
