#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v459.0 - Background Sync Engine
# =============================================================================
# バックグラウンド同期: オフラインサポート、同期キュー、コンフリクト解決。
#
# Functions:
#   _bs_init()                     - Initialize
#   _bs_generate_offline_support() - Service worker offline support
#   _bs_generate_sync_queue()      - Background sync queue
#   _bs_resolve_conflicts()        - Conflict resolution strategies
#   _bs_report() / _bs_score()
# =============================================================================

[[ -n "${_BS_LOADED:-}" ]] && return 0; _BS_LOADED=1

declare -g BS_VERSION="459.0"
BS_GENERATED=0; BS_ERRORS=0; BS_FILES_WRITTEN=0
BS_OFFLINE_OK=false; BS_SYNC_QUEUE_OK=false; BS_CONFLICTS_OK=false

_bs_init() {
    BS_GENERATED=0; BS_ERRORS=0; BS_FILES_WRITTEN=0
    BS_OFFLINE_OK=false; BS_SYNC_QUEUE_OK=false; BS_CONFLICTS_OK=false
    return 0
}

_bs_log() { echo -e "  ${CYAN:-\033[0;36m}[bg-sync]${NC:-\033[0m} $*" >&2; }
_bs_ok()  { echo -e "  ${GREEN:-\033[0;32m}✅ [bg-sync]${NC:-\033[0m} $*" >&2; }
_bs_err() { echo -e "  ${RED:-\033[0;31m}❌ [bg-sync]${NC:-\033[0m} $*" >&2; BS_ERRORS=$((BS_ERRORS + 1)); }

_bs_write_file() {
    local filepath="$1" content="$2"
    local dir; dir="$(dirname "$filepath")"
    [[ -d "$dir" ]] || mkdir -p "$dir"
    echo "$content" > "$filepath" 2>/dev/null || { _bs_err "Failed to write $filepath"; return 1; }
    BS_FILES_WRITTEN=$((BS_FILES_WRITTEN + 1))
    return 0
}

_bs_generate_offline_support() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/sync/offline-manager.ts"
    _bs_log "Generating offline support manager..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v459.0 - Offline Support Manager

export type ConnectionStatus = 'online' | 'offline' | 'slow';

export interface OfflineConfig {
  cacheName: string;
  maxCacheSize: number;        // bytes
  offlinePageUrl: string;
  strategies: Record<string, 'cache-first' | 'network-first' | 'stale-while-revalidate'>;
}

const DEFAULT_CONFIG: OfflineConfig = {
  cacheName: 'soloptilink-offline-v1',
  maxCacheSize: 50 * 1024 * 1024, // 50MB
  offlinePageUrl: '/offline',
  strategies: {
    '/api/*': 'network-first',
    '/_next/static/*': 'cache-first',
    '/images/*': 'cache-first',
    '/': 'stale-while-revalidate',
  },
};

export class OfflineManager {
  private config: OfflineConfig;
  private status: ConnectionStatus = 'online';
  private listeners: Array<(status: ConnectionStatus) => void> = [];

  constructor(config?: Partial<OfflineConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => this.setStatus('online'));
      window.addEventListener('offline', () => this.setStatus('offline'));
    }
  }

  private setStatus(status: ConnectionStatus): void {
    this.status = status;
    this.listeners.forEach(fn => fn(status));
  }

  onStatusChange(fn: (status: ConnectionStatus) => void): () => void {
    this.listeners.push(fn);
    return () => { this.listeners = this.listeners.filter(l => l !== fn); };
  }

  getStatus(): ConnectionStatus { return this.status; }
  isOnline(): boolean { return this.status === 'online'; }

  getStrategyForUrl(url: string): string {
    for (const [pattern, strategy] of Object.entries(this.config.strategies)) {
      const regex = new RegExp('^' + pattern.replace(/\*/g, '.*') + '$');
      if (regex.test(url)) return strategy;
    }
    return 'network-first';
  }

  generateServiceWorker(): string {
    return `// Auto-generated Service Worker\nconst CACHE_NAME = '${this.config.cacheName}';\nself.addEventListener('install', (e) => { e.waitUntil(caches.open(CACHE_NAME)); });\n`;
  }
}

export const offlineManager = new OfflineManager();
TYPESCRIPT
)
    _bs_write_file "$outfile" "$content" || return 1
    BS_OFFLINE_OK=true
    BS_GENERATED=$((BS_GENERATED + 1))
    _bs_ok "Offline support generated"
    return 0
}

_bs_generate_sync_queue() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/sync/sync-queue.ts"
    _bs_log "Generating background sync queue..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v459.0 - Background Sync Queue

export interface SyncItem {
  id: string;
  url: string;
  method: 'POST' | 'PUT' | 'PATCH' | 'DELETE';
  body: string;
  headers: Record<string, string>;
  createdAt: number;
  retries: number;
  maxRetries: number;
  status: 'pending' | 'syncing' | 'failed' | 'completed';
}

export class SyncQueue {
  private queue: SyncItem[] = [];
  private isSyncing = false;
  private readonly storageKey = 'soloptilink-sync-queue';

  constructor() { this.loadFromStorage(); }

  private loadFromStorage(): void {
    if (typeof localStorage === 'undefined') return;
    try {
      const data = localStorage.getItem(this.storageKey);
      if (data) this.queue = JSON.parse(data);
    } catch { /* ignore */ }
  }

  private saveToStorage(): void {
    if (typeof localStorage === 'undefined') return;
    try { localStorage.setItem(this.storageKey, JSON.stringify(this.queue)); } catch { /* ignore */ }
  }

  enqueue(item: Omit<SyncItem, 'id' | 'createdAt' | 'retries' | 'status'>): string {
    const id = `sync_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
    this.queue.push({ ...item, id, createdAt: Date.now(), retries: 0, status: 'pending' });
    this.saveToStorage();
    return id;
  }

  async flush(): Promise<{ synced: number; failed: number }> {
    if (this.isSyncing) return { synced: 0, failed: 0 };
    this.isSyncing = true;
    let synced = 0, failed = 0;
    const pending = this.queue.filter(i => i.status === 'pending' || i.status === 'failed');
    for (const item of pending) {
      item.status = 'syncing';
      try {
        await fetch(item.url, { method: item.method, body: item.body, headers: item.headers });
        item.status = 'completed';
        synced++;
      } catch {
        item.retries++;
        item.status = item.retries >= item.maxRetries ? 'failed' : 'pending';
        failed++;
      }
    }
    this.queue = this.queue.filter(i => i.status !== 'completed');
    this.saveToStorage();
    this.isSyncing = false;
    return { synced, failed };
  }

  getPending(): SyncItem[] { return this.queue.filter(i => i.status === 'pending'); }
  getStats() { return { total: this.queue.length, pending: this.getPending().length, isSyncing: this.isSyncing }; }
}

export const syncQueue = new SyncQueue();
TYPESCRIPT
)
    _bs_write_file "$outfile" "$content" || return 1
    BS_SYNC_QUEUE_OK=true
    BS_GENERATED=$((BS_GENERATED + 1))
    _bs_ok "Sync queue generated"
    return 0
}

_bs_resolve_conflicts() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/sync/conflict-resolver.ts"
    _bs_log "Generating conflict resolver..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v459.0 - Conflict Resolution Strategies

export type ConflictStrategy = 'client-wins' | 'server-wins' | 'last-write-wins' | 'merge' | 'manual';

export interface ConflictRecord<T = unknown> {
  id: string;
  clientVersion: T;
  serverVersion: T;
  clientTimestamp: number;
  serverTimestamp: number;
  resolved: boolean;
  resolution?: T;
}

export class ConflictResolver {
  private strategy: ConflictStrategy;
  private conflicts: ConflictRecord[] = [];

  constructor(strategy: ConflictStrategy = 'last-write-wins') { this.strategy = strategy; }

  resolve<T extends Record<string, unknown>>(client: T, server: T, clientTs: number, serverTs: number): T {
    switch (this.strategy) {
      case 'client-wins': return client;
      case 'server-wins': return server;
      case 'last-write-wins': return clientTs > serverTs ? client : server;
      case 'merge': return this.mergeObjects(client, server, clientTs, serverTs);
      default: return server;
    }
  }

  private mergeObjects<T extends Record<string, unknown>>(client: T, server: T, clientTs: number, serverTs: number): T {
    const merged = { ...server };
    for (const key of Object.keys(client)) {
      if (JSON.stringify(client[key]) !== JSON.stringify(server[key])) {
        // Field-level last-write-wins
        (merged as Record<string, unknown>)[key] = clientTs > serverTs ? client[key] : server[key];
      }
    }
    return merged as T;
  }

  getUnresolved(): ConflictRecord[] { return this.conflicts.filter(c => !c.resolved); }
}

export const conflictResolver = new ConflictResolver();
TYPESCRIPT
)
    _bs_write_file "$outfile" "$content" || return 1
    BS_CONFLICTS_OK=true
    BS_GENERATED=$((BS_GENERATED + 1))
    _bs_ok "Conflict resolver generated"
    return 0
}

_bs_generate_all() {
    local project_dir="${1:-.}"
    _bs_generate_offline_support "$project_dir"
    _bs_generate_sync_queue "$project_dir"
    _bs_resolve_conflicts "$project_dir"
    _bs_ok "Background sync complete: ${BS_GENERATED} components, ${BS_ERRORS} errors"
}

_bs_report() {
    echo -e "\n  ${BOLD:-\033[1m}═══ Background Sync v${BS_VERSION} ═══${NC:-\033[0m}"
    echo -e "  Generated   : ${BS_GENERATED}"
    echo -e "  Errors      : ${BS_ERRORS}"
    echo -e "  Offline     : ${BS_OFFLINE_OK}"
    echo -e "  Sync Queue  : ${BS_SYNC_QUEUE_OK}"
    echo -e "  Conflicts   : ${BS_CONFLICTS_OK}"
}

_bs_score() {
    local score=50
    ${BS_OFFLINE_OK} && score=$((score + 15))
    ${BS_SYNC_QUEUE_OK} && score=$((score + 15))
    ${BS_CONFLICTS_OK} && score=$((score + 15))
    [[ ${BS_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "background-sync" --version "459.0" \
        --description "バックグラウンド同期: オフライン×同期キュー×コンフリクト解決" \
        --init "_bs_init" --report "_bs_report" --score "_bs_score" \
        --enable-var "ENABLE_BACKGROUND_SYNC" --cli-flags "--bg-sync:--no-bg-sync"
fi

# v2003.1: source時のexit codeを確実に0にする
true
