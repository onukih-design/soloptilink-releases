#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v102.0 - Migration Tester
# Prismaスキーマを実際にマイグレーションしてテーブル/リレーション検証
#
# SQLiteテストDBで安全にテスト（本番DBに影響なし）
# ============================================================

[[ -n "${_MGT_LOADED:-}" ]] && return 0
_MGT_LOADED=1

MGT_VERSION="102.0"
MGT_INITIALIZED=false
MGT_TEST_DB=""

# --- 統計 ---
MGT_TABLES_EXPECTED=0
MGT_TABLES_FOUND=0
MGT_RELATIONS_VALID=0
MGT_ERRORS=()

# ============================================================
# 初期化
# ============================================================
mgt_init() {
    MGT_TEST_DB=""
    MGT_TABLES_EXPECTED=0
    MGT_TABLES_FOUND=0
    MGT_RELATIONS_VALID=0
    MGT_ERRORS=()
    MGT_INITIALIZED=true
    return 0
}

# ============================================================
# メイン: マイグレーションテスト
# ============================================================
mgt_run() {
    local project_dir="$1"

    [[ ! -f "${project_dir}/prisma/schema.prisma" ]] && return 0

    mgt_init
    echo -e "  🗄️ [MGT] Migration Tester v${MGT_VERSION} 開始" >&2

    # Prisma利用可能チェック
    if ! command -v npx &>/dev/null; then
        echo -e "  ⚠️ [MGT] npxが利用不可 → スキップ" >&2
        return 0
    fi

    # --- Step 1: テストDB用の一時schema作成 ---
    local test_dir
    test_dir=$(mktemp -d)
    MGT_TEST_DB="${test_dir}/test.db"

    # schema.prismaをコピーしてSQLiteに変更
    mkdir -p "${test_dir}/prisma"
    _mgt_create_test_schema "${project_dir}/prisma/schema.prisma" "${test_dir}/prisma/schema.prisma"

    # package.json(prisma用)
    cat > "${test_dir}/package.json" << 'EOF'
{"name":"mgt-test","private":true}
EOF

    # .env
    echo "DATABASE_URL=\"file:./test.db\"" > "${test_dir}/.env"

    # node_modules シンボリックリンク（プロジェクトのprismaを再利用）
    if [[ -d "${project_dir}/node_modules" ]]; then
        ln -sf "${project_dir}/node_modules" "${test_dir}/node_modules" 2>/dev/null || true
    fi

    # --- Step 2: prisma db push（マイグレーション実行） ---
    echo -e "  🔄 [MGT] prisma db push 実行中..." >&2
    local push_output
    push_output=$(cd "$test_dir" && DATABASE_URL="file:./test.db" timeout 30 npx prisma db push --skip-generate --accept-data-loss 2>&1 || true)

    if echo "$push_output" | grep -qiE "error|Error"; then
        MGT_ERRORS+=("MIGRATION_FAILED: $(echo "$push_output" | grep -i "error" | head -3)")
        echo -e "  ❌ [MGT] マイグレーション失敗" >&2
        rm -rf "$test_dir"
        return 1
    fi

    echo -e "  ✅ [MGT] マイグレーション成功" >&2

    # --- Step 3: テーブル検証 ---
    _mgt_verify_tables "$test_dir" "$project_dir"

    # --- Step 4: クリーンアップ ---
    rm -rf "$test_dir"

    echo -e "  📊 [MGT] テーブル: ${MGT_TABLES_FOUND}/${MGT_TABLES_EXPECTED} 作成, エラー: ${#MGT_ERRORS[@]}" >&2

    [[ ${#MGT_ERRORS[@]} -gt 0 ]] && return 1
    return 0
}

# ============================================================
# テスト用スキーマ作成（PostgreSQL→SQLite変換）
# ============================================================
_mgt_create_test_schema() {
    local source="$1"
    local target="$2"

    # providerをsqliteに変更、PostgreSQL固有の型を変換
    # url行もfile:./test.dbに直書き
    sed -e 's/provider *= *"postgresql"/provider = "sqlite"/' \
        -e 's/provider *= *"mysql"/provider = "sqlite"/' \
        -e 's/url *= *env("DATABASE_URL")/url = "file:.\/test.db"/' \
        -e 's/@db\.Text//g' \
        -e 's/@db\.VarChar([0-9]*)//g' \
        -e 's/@db\.Uuid//g' \
        -e 's/@db\.JsonB//g' \
        -e 's/@db\.Json//g' \
        -e 's/@db\.Timestamp([0-9]*)//g' \
        -e '/directUrl/d' \
        -e '/shadowDatabaseUrl/d' \
        -e '/extensions/d' \
        -e '/postgresqlExtensions/d' \
        "$source" > "$target"
}

# ============================================================
# テーブル検証
# ============================================================
_mgt_verify_tables() {
    local test_dir="$1"
    local project_dir="$2"

    # Prismaスキーマからモデル名を取得
    local models
    models=$(grep "^model " "${project_dir}/prisma/schema.prisma" 2>/dev/null | awk '{print $2}')

    MGT_TABLES_EXPECTED=$(echo "$models" | wc -l | tr -d ' ')

    # SQLiteテーブル一覧取得
    if command -v sqlite3 &>/dev/null && [[ -f "${test_dir}/test.db" ]]; then
        local tables
        tables=$(sqlite3 "${test_dir}/test.db" ".tables" 2>/dev/null)

        for model in $models; do
            # Prismaはモデル名をそのままテーブル名にする
            if echo "$tables" | grep -qi "$model"; then
                MGT_TABLES_FOUND=$((MGT_TABLES_FOUND + 1))
            else
                MGT_ERRORS+=("TABLE_MISSING: テーブル '${model}' が作成されなかった")
            fi
        done
    else
        # sqlite3がない場合はprisma db pushの成功をもってOKとする
        MGT_TABLES_FOUND=$MGT_TABLES_EXPECTED
    fi
}

# ============================================================
# レポート
# ============================================================
mgt_build_report() {
    if [[ ${#MGT_ERRORS[@]} -eq 0 ]]; then
        echo ""
        return
    fi

    local report="## マイグレーションテストエラー
"
    for err in "${MGT_ERRORS[@]}"; do
        report+="- ${err}
"
    done
    echo "$report"
}

mgt_report() {
    echo "=== Migration Tester v${MGT_VERSION} ==="
    echo "  Tables: ${MGT_TABLES_FOUND}/${MGT_TABLES_EXPECTED}, Errors: ${#MGT_ERRORS[@]}"
}

mgt_score() {
    [[ $MGT_TABLES_EXPECTED -eq 0 ]] && { echo "80"; return; }
    echo "$(( (MGT_TABLES_FOUND * 100) / MGT_TABLES_EXPECTED ))"
}

# Module Registry
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "migration-tester" \
        --version "$MGT_VERSION" \
        --description "マイグレーションテスト - Prismaスキーマの実行検証(SQLiteサンドボックス)" \
        --init "mgt_init" \
        --report "mgt_report" \
        --score "mgt_score" \
        --enable-var "ENABLE_MGT" \
        --cli-flags "--migration-test:--no-migration-test"
fi

# v2003.1: source時のexit codeを確実に0にする
true
