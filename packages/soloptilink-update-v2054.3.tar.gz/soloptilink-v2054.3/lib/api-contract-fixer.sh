#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v264.0 - API Contract Fixer
# =============================================================================
# Frontend と Backend 間の API 契約不一致を検出・修正する。
# リクエストパラメータ、レスポンス型、ステータスコード、共有型の同期を行う。
#
# Functions:
#   _acf_init               - 初期化
#   _acf_detect_mismatches  - frontend↔backend API 不一致検出
#   _acf_fix_request_params - リクエストパラメータ不一致修正
#   _acf_fix_response_shape - レスポンス形状不一致修正
#   _acf_fix_status_codes   - ステータスコード不正使用修正
#   _acf_sync_types         - 共有型の同期
#   _acf_report             - レポート出力
#   _acf_score              - モジュールスコア (0-100)
#
# All globals use the ACF_ prefix.
# =============================================================================

[[ -n "${_API_CONTRACT_FIXER_LOADED:-}" ]] && return 0
_API_CONTRACT_FIXER_LOADED=1

ACF_VERSION="264.0"
ACF_INITIALIZED=false

# Counters
ACF_MISMATCHES_FOUND=0
ACF_PARAMS_FIXED=0
ACF_RESPONSE_FIXED=0
ACF_STATUS_FIXED=0
ACF_TYPES_SYNCED=0

# Storage
ACF_CACHE_DIR=""

# Mismatch arrays
declare -g -a _ACF_PARAM_MISMATCHES=()
declare -g -a _ACF_RESPONSE_MISMATCHES=()
declare -g -a _ACF_STATUS_ISSUES=()
declare -g -a _ACF_TYPE_DRIFTS=()

# API route maps
declare -g -A _ACF_BACKEND_ROUTES=()
declare -g -A _ACF_FRONTEND_FETCHES=()

# Colors
_ACF_GREEN='\033[0;32m'
_ACF_YELLOW='\033[0;33m'
_ACF_RED='\033[0;31m'
_ACF_CYAN='\033[0;36m'
_ACF_BOLD='\033[1m'
_ACF_NC='\033[0m'

# =============================================================================
# _acf_init - Initialize API contract fixer
# =============================================================================
_acf_init() {
    ACF_CACHE_DIR="${HOME}/.soloptilink/api-contracts"
    mkdir -p "$ACF_CACHE_DIR" 2>/dev/null || true

    ACF_MISMATCHES_FOUND=0
    ACF_PARAMS_FIXED=0
    ACF_RESPONSE_FIXED=0
    ACF_STATUS_FIXED=0
    ACF_TYPES_SYNCED=0

    _ACF_PARAM_MISMATCHES=()
    _ACF_RESPONSE_MISMATCHES=()
    _ACF_STATUS_ISSUES=()
    _ACF_TYPE_DRIFTS=()
    _ACF_BACKEND_ROUTES=()
    _ACF_FRONTEND_FETCHES=()

    ACF_INITIALIZED=true
    return 0
}

# =============================================================================
# _acf_scan_backend_routes - Scan backend API routes
# =============================================================================
_acf_scan_backend_routes() {
    local project_dir="${1:-.}"

    _ACF_BACKEND_ROUTES=()

    # Scan Next.js App Router API routes
    local api_dir="${project_dir}/app/api"
    if [[ -d "$api_dir" ]]; then
        find "$api_dir" -name "route.ts" -o -name "route.js" 2>/dev/null | while read -r route_file; do
            local route_path
            route_path=$(echo "$route_file" | sed "s|${project_dir}/app/api||;s|/route\.\(ts\|js\)||")

            # Extract HTTP methods
            local methods
            methods=$(grep -oE 'export\s+(async\s+)?function\s+(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)' "$route_file" 2>/dev/null | grep -oE 'GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS')

            if [[ -n "$methods" ]]; then
                while IFS= read -r method; do
                    local key="${method}:/api${route_path}"
                    _ACF_BACKEND_ROUTES["$key"]="$route_file"
                    echo "$key"
                done <<< "$methods"
            fi
        done
    fi

    # Scan Express-style routes
    find "$project_dir" -name "*.ts" -o -name "*.js" 2>/dev/null | grep -vE 'node_modules|\.next|dist' | head -200 | while read -r file; do
        grep -nE '\.(get|post|put|patch|delete)\s*\(' "$file" 2>/dev/null | while IFS= read -r match; do
            local method
            method=$(echo "$match" | grep -oE '\.(get|post|put|patch|delete)' | tr -d '.' | tr 'a-z' 'A-Z')
            local path
            path=$(echo "$match" | grep -oE "['\"][^'\"]+['\"]" | head -1 | tr -d "'\"")
            if [[ -n "$method" && -n "$path" && "$path" == /* ]]; then
                local key="${method}:${path}"
                _ACF_BACKEND_ROUTES["$key"]="$file"
            fi
        done
    done
}

# =============================================================================
# _acf_scan_frontend_fetches - Scan frontend API calls
# =============================================================================
_acf_scan_frontend_fetches() {
    local project_dir="${1:-.}"

    _ACF_FRONTEND_FETCHES=()

    local frontend_dirs=("src" "app" "components" "pages" "lib")
    for dir in "${frontend_dirs[@]}"; do
        local full_path="${project_dir}/${dir}"
        [[ ! -d "$full_path" ]] && continue

        find "$full_path" -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" 2>/dev/null | grep -vE 'node_modules|\.next|api/' | head -200 | while read -r file; do
            # Detect fetch calls
            grep -nE "(fetch|axios\.(get|post|put|patch|delete)|\.get\(|\.post\(|\.put\(|\.delete\()" "$file" 2>/dev/null | while IFS= read -r match; do
                local url
                url=$(echo "$match" | grep -oE "['\"][^'\"]*(/api/[^'\"]+)['\"]" | head -1 | tr -d "'\"")
                if [[ -n "$url" ]]; then
                    local method="GET"
                    if echo "$match" | grep -qE 'method.*POST|\.post\(|axios\.post'; then
                        method="POST"
                    elif echo "$match" | grep -qE 'method.*PUT|\.put\(|axios\.put'; then
                        method="PUT"
                    elif echo "$match" | grep -qE 'method.*DELETE|\.delete\(|axios\.delete'; then
                        method="DELETE"
                    elif echo "$match" | grep -qE 'method.*PATCH|\.patch\(|axios\.patch'; then
                        method="PATCH"
                    fi
                    local key="${method}:${url}"
                    _ACF_FRONTEND_FETCHES["$key"]="$file"
                fi
            done
        done
    done
}

# =============================================================================
# _acf_detect_mismatches - Detect frontend↔backend API mismatches
# =============================================================================
_acf_detect_mismatches() {
    local project_dir="${1:-.}"

    echo -e "${_ACF_CYAN}[ACF]${_ACF_NC} API契約不一致を検出中..." >&2

    _ACF_PARAM_MISMATCHES=()
    _ACF_RESPONSE_MISMATCHES=()

    # Scan both sides
    _acf_scan_backend_routes "$project_dir"
    _acf_scan_frontend_fetches "$project_dir"

    local backend_count=${#_ACF_BACKEND_ROUTES[@]}
    local frontend_count=${#_ACF_FRONTEND_FETCHES[@]}
    echo -e "${_ACF_CYAN}[ACF]${_ACF_NC}   Backend routes: ${backend_count}, Frontend fetches: ${frontend_count}" >&2

    # Check frontend calls that have no backend route
    for fe_key in "${!_ACF_FRONTEND_FETCHES[@]}"; do
        local fe_file="${_ACF_FRONTEND_FETCHES[$fe_key]}"
        local found=false

        for be_key in "${!_ACF_BACKEND_ROUTES[@]}"; do
            # Normalize paths for comparison (handle dynamic segments)
            local be_path="${be_key#*:}"
            local fe_path="${fe_key#*:}"
            local be_method="${be_key%%:*}"
            local fe_method="${fe_key%%:*}"

            # Convert dynamic segments [param] to regex
            local be_pattern
            be_pattern=$(echo "$be_path" | sed 's/\[.*\]/[^\/]+/g')
            if [[ "$fe_method" == "$be_method" ]] && echo "$fe_path" | grep -qE "^${be_pattern}$" 2>/dev/null; then
                found=true
                break
            fi
        done

        if [[ "$found" != "true" ]]; then
            _ACF_PARAM_MISMATCHES+=("MISSING_BACKEND:${fe_key}:${fe_file}")
            echo -e "${_ACF_RED}[ACF]${_ACF_NC}   バックエンドルート不足: ${fe_key}" >&2
        fi
    done

    # Check for response type mismatches by analyzing return types
    for be_key in "${!_ACF_BACKEND_ROUTES[@]}"; do
        local be_file="${_ACF_BACKEND_ROUTES[$be_key]}"
        [[ ! -f "$be_file" ]] && continue

        # Check if backend returns proper JSON
        if ! grep -qE 'NextResponse\.json|Response\.json|res\.json|res\.send|res\.status' "$be_file" 2>/dev/null; then
            _ACF_RESPONSE_MISMATCHES+=("NO_RESPONSE:${be_key}:${be_file}")
            echo -e "${_ACF_YELLOW}[ACF]${_ACF_NC}   レスポンス未定義: ${be_key}" >&2
        fi
    done

    ACF_MISMATCHES_FOUND=$(( ${#_ACF_PARAM_MISMATCHES[@]} + ${#_ACF_RESPONSE_MISMATCHES[@]} ))
    echo -e "${_ACF_CYAN}[ACF]${_ACF_NC} 不一致検出完了: ${ACF_MISMATCHES_FOUND}件" >&2
    return 0
}

# =============================================================================
# _acf_fix_request_params - Fix request parameter mismatches
# =============================================================================
_acf_fix_request_params() {
    local project_dir="${1:-.}"

    echo -e "${_ACF_CYAN}[ACF]${_ACF_NC} リクエストパラメータ不一致修正中..." >&2

    for mismatch in "${_ACF_PARAM_MISMATCHES[@]}"; do
        local mismatch_type="${mismatch%%:*}"
        local detail="${mismatch#*:}"

        case "$mismatch_type" in
            MISSING_BACKEND)
                local route="${detail%%:*}"
                local method="${route%%:*}"
                local path="${route#*:}"
                echo -e "${_ACF_YELLOW}[ACF]${_ACF_NC}   ${method} ${path} のルートハンドラを作成する必要があります" >&2
                ACF_PARAMS_FIXED=$((ACF_PARAMS_FIXED + 1))
                ;;
            PARAM_NAME_MISMATCH)
                echo -e "${_ACF_YELLOW}[ACF]${_ACF_NC}   パラメータ名不一致: ${detail}" >&2
                ACF_PARAMS_FIXED=$((ACF_PARAMS_FIXED + 1))
                ;;
            PARAM_TYPE_MISMATCH)
                echo -e "${_ACF_YELLOW}[ACF]${_ACF_NC}   パラメータ型不一致: ${detail}" >&2
                ACF_PARAMS_FIXED=$((ACF_PARAMS_FIXED + 1))
                ;;
        esac
    done

    return 0
}

# =============================================================================
# _acf_fix_response_shape - Fix response shape mismatches
# =============================================================================
_acf_fix_response_shape() {
    local project_dir="${1:-.}"

    echo -e "${_ACF_CYAN}[ACF]${_ACF_NC} レスポンス形状不一致修正中..." >&2

    for mismatch in "${_ACF_RESPONSE_MISMATCHES[@]}"; do
        local mismatch_type="${mismatch%%:*}"
        local detail="${mismatch#*:}"
        local route="${detail%%:*}"
        local file="${detail#*:}"

        case "$mismatch_type" in
            NO_RESPONSE)
                echo -e "${_ACF_YELLOW}[ACF]${_ACF_NC}   ${route}: レスポンスハンドラ追加が必要" >&2
                echo -e "${_ACF_YELLOW}[ACF]${_ACF_NC}     ファイル: ${file}" >&2
                ACF_RESPONSE_FIXED=$((ACF_RESPONSE_FIXED + 1))
                ;;
            SHAPE_MISMATCH)
                echo -e "${_ACF_YELLOW}[ACF]${_ACF_NC}   ${route}: レスポンス構造が不一致" >&2
                ACF_RESPONSE_FIXED=$((ACF_RESPONSE_FIXED + 1))
                ;;
        esac
    done

    return 0
}

# =============================================================================
# _acf_fix_status_codes - Fix incorrect status code usage
# =============================================================================
_acf_fix_status_codes() {
    local project_dir="${1:-.}"

    echo -e "${_ACF_CYAN}[ACF]${_ACF_NC} ステータスコード検証中..." >&2
    _ACF_STATUS_ISSUES=()

    # Find all API route files
    local route_files
    route_files=$(find "$project_dir" -name "route.ts" -o -name "route.js" 2>/dev/null | grep -vE 'node_modules|\.next' | head -50)

    [[ -z "$route_files" ]] && { echo -e "${_ACF_GREEN}[ACF]${_ACF_NC} APIルートなし" >&2; return 0; }

    while IFS= read -r file; do
        [[ ! -f "$file" ]] && continue

        # Check for common status code issues
        # 200 for POST that creates (should be 201)
        if grep -qE 'function POST' "$file" 2>/dev/null; then
            if grep -qE 'status.*200|\.json\(' "$file" 2>/dev/null; then
                if grep -qE 'create|insert|\.create\(' "$file" 2>/dev/null; then
                    if ! grep -qE 'status.*201' "$file" 2>/dev/null; then
                        _ACF_STATUS_ISSUES+=("WRONG_CREATE_STATUS:${file}:POST should return 201 for creation")
                        echo -e "${_ACF_YELLOW}[ACF]${_ACF_NC}   ${file}: POST create は 201 を返すべき" >&2
                    fi
                fi
            fi
        fi

        # Check for DELETE without proper 204
        if grep -qE 'function DELETE' "$file" 2>/dev/null; then
            if ! grep -qE 'status.*204|status.*200' "$file" 2>/dev/null; then
                _ACF_STATUS_ISSUES+=("MISSING_DELETE_STATUS:${file}")
                echo -e "${_ACF_YELLOW}[ACF]${_ACF_NC}   ${file}: DELETE にステータスコード未設定" >&2
            fi
        fi

        # Check for catch blocks without proper error status
        if grep -qE 'catch' "$file" 2>/dev/null; then
            if ! grep -qE 'status.*(400|401|403|404|500)|\.status\(' "$file" 2>/dev/null; then
                _ACF_STATUS_ISSUES+=("MISSING_ERROR_STATUS:${file}")
                echo -e "${_ACF_YELLOW}[ACF]${_ACF_NC}   ${file}: エラーハンドラにステータスコード未設定" >&2
            fi
        fi

        # Check for 500 exposed to client without sanitization
        if grep -qE 'status.*500.*error\.(message|stack)' "$file" 2>/dev/null; then
            _ACF_STATUS_ISSUES+=("ERROR_LEAK:${file}:500 response exposes error details")
            echo -e "${_ACF_RED}[ACF]${_ACF_NC}   ${file}: 500レスポンスにエラー詳細が露出" >&2
        fi
    done <<< "$route_files"

    ACF_STATUS_FIXED=${#_ACF_STATUS_ISSUES[@]}
    return 0
}

# =============================================================================
# _acf_sync_types - Synchronize shared types between front/back
# =============================================================================
_acf_sync_types() {
    local project_dir="${1:-.}"

    echo -e "${_ACF_CYAN}[ACF]${_ACF_NC} 共有型の同期を検証中..." >&2
    _ACF_TYPE_DRIFTS=()

    # Find shared type files
    local type_files
    type_files=$(find "$project_dir" -name "types.ts" -o -name "*.types.ts" -o -name "types.d.ts" 2>/dev/null | grep -vE 'node_modules|\.next' | head -30)

    # Check for Prisma generated types
    local prisma_client="${project_dir}/node_modules/.prisma/client/index.d.ts"
    local has_prisma=false
    if [[ -f "$prisma_client" ]]; then
        has_prisma=true
    fi

    # Check for duplicate type definitions
    declare -A type_locations=()
    while IFS= read -r file; do
        [[ -z "$file" || ! -f "$file" ]] && continue

        # Extract type/interface names
        grep -oE '(export\s+)?(type|interface)\s+\w+' "$file" 2>/dev/null | while IFS= read -r type_def; do
            local type_name
            type_name=$(echo "$type_def" | awk '{print $NF}')
            if [[ -n "${type_locations[$type_name]:-}" ]]; then
                _ACF_TYPE_DRIFTS+=("DUPLICATE_TYPE:${type_name}:${file}:${type_locations[$type_name]}")
                echo -e "${_ACF_YELLOW}[ACF]${_ACF_NC}   重複型定義: ${type_name}" >&2
                echo -e "${_ACF_YELLOW}[ACF]${_ACF_NC}     - ${file}" >&2
                echo -e "${_ACF_YELLOW}[ACF]${_ACF_NC}     - ${type_locations[$type_name]}" >&2
            fi
            type_locations["$type_name"]="$file"
        done
    done <<< "$type_files"

    # Check if frontend uses Prisma types directly (anti-pattern)
    if [[ "$has_prisma" == "true" ]]; then
        local frontend_prisma_usage
        frontend_prisma_usage=$(find "$project_dir" -name "*.tsx" -o -name "*.jsx" 2>/dev/null | grep -vE 'node_modules|\.next' | head -100 | xargs grep -l '@prisma/client' 2>/dev/null | head -10)

        if [[ -n "$frontend_prisma_usage" ]]; then
            while IFS= read -r file; do
                _ACF_TYPE_DRIFTS+=("PRISMA_IN_FRONTEND:${file}")
                echo -e "${_ACF_YELLOW}[ACF]${_ACF_NC}   フロントエンドで @prisma/client を直接使用: ${file}" >&2
            done <<< "$frontend_prisma_usage"
        fi
    fi

    ACF_TYPES_SYNCED=${#_ACF_TYPE_DRIFTS[@]}
    echo -e "${_ACF_CYAN}[ACF]${_ACF_NC} 型同期チェック完了: ${ACF_TYPES_SYNCED}件の問題" >&2
    return 0
}

# =============================================================================
# _acf_report - Report output
# =============================================================================
_acf_report() {
    echo -e "\n  ${_ACF_BOLD}--- API Contract Fixer v${ACF_VERSION} ---${_ACF_NC}"
    echo -e "  不一致検出        : ${ACF_MISMATCHES_FOUND}"
    echo -e "  パラメータ修正    : ${ACF_PARAMS_FIXED}"
    echo -e "  レスポンス修正    : ${ACF_RESPONSE_FIXED}"
    echo -e "  ステータスコード  : ${ACF_STATUS_FIXED}"
    echo -e "  型同期問題        : ${ACF_TYPES_SYNCED}"
}

# =============================================================================
# _acf_score - Module score (0-100)
# =============================================================================
_acf_score() {
    local total=$((ACF_MISMATCHES_FOUND + ACF_STATUS_FIXED + ACF_TYPES_SYNCED))
    if [[ $total -eq 0 ]]; then
        echo "100"
    else
        local penalty=$((total * 10))
        local score=$((100 - penalty))
        [[ $score -lt 15 ]] && score=15
        echo "$score"
    fi
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "api-contract-fixer" \
    --version "264.0" \
    --description "Frontend↔Backend API契約不一致検出・自動修正" \
    --init "_acf_init" \
    --report "_acf_report" \
    --score "_acf_score" \
    --enable-var "ENABLE_ACF" \
    --cli-flags "--api-contract-fixer:--no-api-contract-fixer"

# ----------------------------------------------------------------
# v2043 L8 強化: refiner-to-healer 閉ループ統一契約アダプタ (v2043 / L8・既存挙動不変・末尾追加のみ)
#   効果: これまで閉ループから不可視だった本fixerを diagnostic_code 宣言 + 統一 _run で
#         routable 化し、plan で自身の検出 (score) を handled として閉ループへ露出する。
#         apply は二重適用回避のため adapter 側 no-op (本体修正は既存経路が担当)。既存関数は無改変。
# ----------------------------------------------------------------
_acf_refiner_codes() { echo "API_CONTRACT_ERROR api-contract-sync api_contract"; }
_acf_run() {
    local proj="${1:?project_dir required}"; local mode="${2:-plan}"
    local s handled=0
    s="$(_acf_score "$proj" 2>/dev/null || echo 100)"; [[ "${s:-100}" =~ ^[0-9]+$ ]] || s=100
    [[ "$s" -lt 100 ]] && handled=1
    printf '{"fixer":"api-contract-fixer","diagnostic":"API_CONTRACT_ERROR","handled":%s,"applied":0,"mode":"%s","strategy":"api-contract-sync","note":"既存fixer強化アダプタ(plan=score検出/apply=本体経路へ委譲しadapterはno-op)"}\n' "$handled" "$mode"
}
