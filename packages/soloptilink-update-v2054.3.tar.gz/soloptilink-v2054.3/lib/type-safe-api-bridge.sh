#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v227.0 - Type-Safe API Bridge
# =============================================================================
# Ensures frontend-backend type safety by generating shared types, validating
# API contracts, generating typed clients, and detecting mismatches.
#
# Functions:
#   _tsab_generate_shared_types() - Generate shared type definitions
#   _tsab_validate_contract()     - Validate frontend calls match backend types
#   _tsab_generate_api_client()   - Generate type-safe API client
#   _tsab_detect_mismatches()     - Detect type mismatches front/back
#   _tsab_generate_response_types() - Generate response wrapper types
#   _tsab_check_consistency()     - Full consistency check
#
# All globals: TSAB_ prefix
# =============================================================================

[[ -n "${_TSAB_LOADED:-}" ]] && return 0
_TSAB_LOADED=1

# --- Colors ---
readonly TSAB_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly TSAB_YELLOW="${CLR_YELLOW:-\033[0;33m}"
readonly TSAB_RED="${CLR_RED:-\033[0;31m}"
readonly TSAB_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly TSAB_BOLD="${CLR_BOLD:-\033[1m}"
readonly TSAB_NC="${CLR_NC:-\033[0m}"

# --- State ---
declare -g TSAB_VERSION="227.0"
declare -g TSAB_INITIALIZED=false
declare -g TSAB_TYPES_GENERATED=0
declare -g TSAB_MISMATCHES_FOUND=0
declare -g TSAB_CLIENTS_GENERATED=0
declare -g TSAB_CONSISTENCY_SCORE=0

# =============================================================================
# Logging
# =============================================================================
_tsab_log()  { echo -e "  ${TSAB_CYAN}[TSAB]${TSAB_NC} $*" >&2; }
_tsab_ok()   { echo -e "  ${TSAB_GREEN}[TSAB] OK${TSAB_NC} $*" >&2; }
_tsab_warn() { echo -e "  ${TSAB_YELLOW}[TSAB] WARN${TSAB_NC} $*" >&2; }
_tsab_err()  { echo -e "  ${TSAB_RED}[TSAB] ERR${TSAB_NC} $*" >&2; }

# =============================================================================
# Init
# =============================================================================
tsab_init() {
    TSAB_INITIALIZED=true
    TSAB_TYPES_GENERATED=0
    TSAB_MISMATCHES_FOUND=0
    TSAB_CLIENTS_GENERATED=0
    TSAB_CONSISTENCY_SCORE=0
    return 0
}

# =============================================================================
# _tsab_generate_shared_types - Generate shared type definitions from Prisma
# =============================================================================
_tsab_generate_shared_types() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _tsab_log "Generating shared types from Prisma schema..."

    local schema_file
    schema_file=$(find "$project_dir" -name "schema.prisma" -not -path "*/node_modules/*" 2>/dev/null | head -1)

    if [[ -z "$schema_file" ]]; then
        _tsab_warn "No Prisma schema found"
        return 1
    fi

    local content
    content=$(cat "$schema_file" 2>/dev/null)

    echo "// --- FILE: lib/types/shared.ts ---"
    echo "// Auto-generated from Prisma schema by SoloptiLinkAI v${TSAB_VERSION}"
    echo "// Do NOT edit manually - regenerate with _tsab_generate_shared_types"
    echo ""

    # Extract models and convert to TypeScript interfaces
    local current_model=""
    local in_model=false

    while IFS= read -r line; do
        # Model start
        if echo "$line" | grep -qE '^\s*model\s+\w+'; then
            current_model=$(echo "$line" | grep -oE 'model\s+\w+' | awk '{print $2}')
            in_model=true
            echo "export interface ${current_model} {"
            continue
        fi

        # Model end
        if $in_model && echo "$line" | grep -qE '^\s*\}'; then
            echo "}"
            echo ""
            in_model=false
            TSAB_TYPES_GENERATED=$((TSAB_TYPES_GENERATED + 1))
            continue
        fi

        # Skip annotations and empty lines inside model
        if $in_model; then
            # Skip @@index, @@map etc
            echo "$line" | grep -qE '^\s*@@' && continue
            # Skip empty lines
            echo "$line" | grep -qE '^\s*$' && continue

            # Parse field
            local field_name
            field_name=$(echo "$line" | awk '{print $1}')
            local field_type
            field_type=$(echo "$line" | awk '{print $2}')

            # Skip relation fields without a type mapping
            [[ -z "$field_name" || -z "$field_type" ]] && continue
            echo "$field_name" | grep -qE '^\s*//' && continue

            # Convert Prisma types to TypeScript
            local ts_type="string"
            local optional=""

            # Handle optional (?)
            if echo "$field_type" | grep -q '?$'; then
                optional=" | null"
                field_type="${field_type%?}"
            fi

            case "$field_type" in
                String)   ts_type="string" ;;
                Int|Float|Decimal) ts_type="number" ;;
                Boolean)  ts_type="boolean" ;;
                DateTime) ts_type="string" ;; # ISO date string
                Json)     ts_type="Record<string, unknown>" ;;
                BigInt)   ts_type="bigint" ;;
                Bytes)    ts_type="Buffer" ;;
                *)
                    # Relation type (another model) or array
                    if echo "$field_type" | grep -qE '\[\]$'; then
                        local base="${field_type%\[\]}"
                        ts_type="${base}[]"
                    else
                        ts_type="$field_type"
                    fi
                    ;;
            esac

            echo "  ${field_name}: ${ts_type}${optional};"
        fi
    done <<< "$content"

    # Generate common response types
    echo "// --- API Response Types ---"
    echo ""
    echo "export interface ApiResponse<T> {"
    echo "  data: T;"
    echo "  error?: string;"
    echo "}"
    echo ""
    echo "export interface PaginatedResponse<T> {"
    echo "  data: T[];"
    echo "  total: number;"
    echo "  page: number;"
    echo "  limit: number;"
    echo "  totalPages: number;"
    echo "}"
    echo ""
    echo "export interface ApiError {"
    echo "  error: string;"
    echo "  code?: string;"
    echo "  details?: Record<string, string[]>;"
    echo "}"

    _tsab_ok "Generated ${TSAB_TYPES_GENERATED} shared types"
}

# =============================================================================
# _tsab_validate_contract - Validate frontend calls match backend types
# =============================================================================
_tsab_validate_contract() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local score=100
    local issues=()

    _tsab_log "Validating frontend-backend type contracts..."

    # Find all API route files
    local api_routes=()
    while IFS= read -r f; do
        [[ -n "$f" ]] && api_routes+=("$f")
    done < <(find "$project_dir" -name "route.ts" -path "*/api/*" -not -path "*/node_modules/*" 2>/dev/null)

    # Find all frontend fetch calls
    local frontend_files=()
    while IFS= read -r f; do
        [[ -n "$f" ]] && frontend_files+=("$f")
    done < <(find "$project_dir" -name "*.tsx" -not -path "*/node_modules/*" -not -path "*/.next/*" -not -path "*/api/*" 2>/dev/null)

    # Extract API endpoints from routes
    local api_paths=()
    for route_file in "${api_routes[@]}"; do
        local rel_path
        rel_path=$(echo "$route_file" | grep -oP '(?<=app/)api/.*(?=/route\.ts)' | sed 's/\[.*\]/:id/g')
        [[ -n "$rel_path" ]] && api_paths+=("/$rel_path")
    done

    # Extract fetch URLs from frontend
    local fetch_urls=()
    for fe_file in "${frontend_files[@]}"; do
        local content
        content=$(cat "$fe_file" 2>/dev/null) || continue
        while IFS= read -r url; do
            [[ -n "$url" ]] && fetch_urls+=("$url")
        done < <(echo "$content" | grep -oP "fetch\(['\"]([^'\"]+)['\"]" | grep -oP "(?<=')[^']+|(?<=\")[^\"]+")
    done

    # Check for unmatched frontend URLs
    for url in "${fetch_urls[@]}"; do
        local normalized
        normalized=$(echo "$url" | sed 's/\$\{[^}]*\}/:id/g; s|/[a-zA-Z0-9_-]\{20,\}|/:id|g')
        local found=false
        for api_path in "${api_paths[@]}"; do
            if [[ "$normalized" == *"$api_path"* ]]; then
                found=true
                break
            fi
        done
        if ! $found && echo "$normalized" | grep -q "^/api/"; then
            issues+=("Frontend calls ${normalized} but no matching API route found")
            score=$((score - 5))
        fi
    done

    # Check for Zod validation on all POST/PUT routes
    for route_file in "${api_routes[@]}"; do
        local content
        content=$(cat "$route_file" 2>/dev/null) || continue
        if echo "$content" | grep -qE 'export async function (POST|PUT)' && ! echo "$content" | grep -q "z\.object\|\.parse("; then
            local route_name
            route_name=$(echo "$route_file" | grep -oP 'api/[^/]+')
            issues+=("${route_name} has POST/PUT without Zod validation")
            score=$((score - 10))
        fi
    done

    # Check for typed responses
    for route_file in "${api_routes[@]}"; do
        local content
        content=$(cat "$route_file" 2>/dev/null) || continue
        if echo "$content" | grep -q "NextResponse.json" && ! echo "$content" | grep -qE ':\s*(ApiResponse|PaginatedResponse|NextResponse)<'; then
            : # Many routes don't use explicit return types, mild issue
        fi
    done

    [[ $score -lt 0 ]] && score=0
    TSAB_CONSISTENCY_SCORE=$score
    TSAB_MISMATCHES_FOUND=${#issues[@]}

    echo "{"
    echo "  \"score\": ${score},"
    echo "  \"apiRoutes\": ${#api_routes[@]},"
    echo "  \"frontendFetches\": ${#fetch_urls[@]},"
    echo "  \"mismatches\": ${#issues[@]},"
    echo "  \"issues\": ["
    local first=true
    for issue in "${issues[@]}"; do
        $first || echo ","
        echo -n "    \"${issue}\""
        first=false
    done
    echo ""
    echo "  ]"
    echo "}"

    [[ $score -ge 80 ]] && _tsab_ok "Contract validation: ${score}/100" || _tsab_warn "Contract validation: ${score}/100"
}

# =============================================================================
# _tsab_generate_api_client - Generate type-safe API client
# =============================================================================
_tsab_generate_api_client() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _tsab_log "Generating type-safe API client..."

    # Find all API resources
    local resources=()
    while IFS= read -r route_dir; do
        [[ -z "$route_dir" ]] && continue
        local resource
        resource=$(basename "$route_dir")
        [[ "$resource" == "auth" || "$resource" == "v1" || "$resource" =~ ^\[ ]] && continue
        resources+=("$resource")
    done < <(find "$project_dir" -name "route.ts" -path "*/api/*" -not -path "*/node_modules/*" 2>/dev/null | xargs -I{} dirname {} | sort -u)

    cat <<'EOF'
// --- FILE: lib/api-client.ts ---
// Auto-generated type-safe API client by SoloptiLinkAI v227.0

type RequestOptions = {
  headers?: Record<string, string>;
  signal?: AbortSignal;
};

class ApiError extends Error {
  constructor(public status: number, message: string, public details?: unknown) {
    super(message);
    this.name = 'ApiError';
  }
}

async function request<T>(url: string, options: RequestInit & RequestOptions = {}): Promise<T> {
  const res = await fetch(url, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...options.headers,
    },
  });
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new ApiError(res.status, body.error || `HTTP ${res.status}`, body);
  }
  return res.json();
}

interface PaginatedResult<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

interface ListParams {
  page?: number;
  limit?: number;
  q?: string;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
}

function buildQuery(params: Record<string, unknown>): string {
  const entries = Object.entries(params).filter(([, v]) => v !== undefined && v !== null && v !== '');
  return entries.length ? '?' + new URLSearchParams(entries.map(([k, v]) => [k, String(v)])).toString() : '';
}

function createResourceClient<T extends { id: string }>(basePath: string) {
  return {
    list: (params?: ListParams) =>
      request<PaginatedResult<T>>(`${basePath}${buildQuery(params || {})}`),
    get: (id: string) =>
      request<{ data: T }>(`${basePath}/${id}`),
    create: (data: Omit<T, 'id' | 'createdAt' | 'updatedAt'>) =>
      request<{ data: T }>(basePath, { method: 'POST', body: JSON.stringify(data) }),
    update: (id: string, data: Partial<Omit<T, 'id' | 'createdAt' | 'updatedAt'>>) =>
      request<{ data: T }>(`${basePath}/${id}`, { method: 'PUT', body: JSON.stringify(data) }),
    delete: (id: string) =>
      request<{ success: boolean }>(`${basePath}/${id}`, { method: 'DELETE' }),
  };
}

EOF

    echo "export const api = {"
    for resource in "${resources[@]}"; do
        local singular="${resource%s}"
        echo "  ${resource}: createResourceClient<any>('/api/${resource}'),"
    done
    echo "  auth: {"
    echo "    login: (data: { email: string; password: string }) =>"
    echo "      request<{ user: any }>('/api/auth/login', { method: 'POST', body: JSON.stringify(data) }),"
    echo "    register: (data: { email: string; password: string; name: string }) =>"
    echo "      request<{ user: any }>('/api/auth/register', { method: 'POST', body: JSON.stringify(data) }),"
    echo "    me: () => request<{ user: any }>('/api/auth/me'),"
    echo "    logout: () => request<void>('/api/auth/logout', { method: 'POST' }),"
    echo "  },"
    echo "};"

    TSAB_CLIENTS_GENERATED=$((TSAB_CLIENTS_GENERATED + 1))
    _tsab_ok "Generated API client with ${#resources[@]} resources"
}

# =============================================================================
# _tsab_detect_mismatches - Detect type mismatches between front/back
# =============================================================================
_tsab_detect_mismatches() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local mismatches=()

    _tsab_log "Detecting type mismatches..."

    # Check for common mismatch patterns
    local tsx_files
    tsx_files=$(find "$project_dir" -name "*.tsx" -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null)

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue
        local basename_f
        basename_f=$(basename "$file")

        # Check for .data.data access (double wrapping)
        if echo "$content" | grep -qE '\.data\.data'; then
            mismatches+=("${basename_f}: Double .data.data access suggests response type mismatch")
        fi

        # Check for accessing non-existent fields (common with untyped)
        if echo "$content" | grep -qE 'as\s+any' | head -1 | grep -q '.'; then
            local any_count
            any_count=$(echo "$content" | grep -c "as any" || true)
            [[ $any_count -gt 3 ]] && mismatches+=("${basename_f}: ${any_count} 'as any' casts suggest type mismatches")
        fi

        # Check for incorrect date handling
        if echo "$content" | grep -qE '\.createdAt\b' && ! echo "$content" | grep -qE 'new Date\(.*createdAt\)|toLocaleDateString|format\('; then
            : # Mild - date might be displayed as-is
        fi

        # Check for missing null checks on optional fields
        if echo "$content" | grep -qE '\?\.' | head -5 | grep -q '&&'; then
            : # Good pattern
        fi
    done <<< "$tsx_files"

    # Check for schema/fetch URL naming mismatches
    local route_models=()
    while IFS= read -r route_file; do
        [[ -z "$route_file" ]] && continue
        local content
        content=$(cat "$route_file" 2>/dev/null) || continue
        local model
        model=$(echo "$content" | grep -oP 'prisma\.\K\w+' | head -1)
        [[ -n "$model" ]] && route_models+=("$model")
    done < <(find "$project_dir" -name "route.ts" -path "*/api/*" -not -path "*/node_modules/*" 2>/dev/null)

    TSAB_MISMATCHES_FOUND=${#mismatches[@]}

    echo "{"
    echo "  \"mismatches\": ${#mismatches[@]},"
    echo "  \"issues\": ["
    local first=true
    for m in "${mismatches[@]}"; do
        $first || echo ","
        echo -n "    \"${m}\""
        first=false
    done
    echo ""
    echo "  ]"
    echo "}"

    [[ ${#mismatches[@]} -eq 0 ]] && _tsab_ok "No type mismatches detected" || _tsab_warn "${#mismatches[@]} potential mismatches"
}

# =============================================================================
# _tsab_generate_response_types - Generate standardized response wrapper types
# =============================================================================
_tsab_generate_response_types() {
    cat <<'EOF'
// --- FILE: lib/types/api-responses.ts ---

/** Standard API response wrapper */
export interface ApiResponse<T = unknown> {
  data: T;
  error?: never;
}

/** Standard API error response */
export interface ApiErrorResponse {
  data?: never;
  error: string;
  code?: string;
  details?: Record<string, string[]>;
}

/** Paginated list response */
export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

/** Mutation response (create/update) */
export interface MutationResponse<T> {
  data: T;
  message?: string;
}

/** Delete response */
export interface DeleteResponse {
  success: boolean;
  message?: string;
}

/** Union type for any API call result */
export type ApiResult<T> = ApiResponse<T> | ApiErrorResponse;

/** Type guard for error responses */
export function isApiError(result: ApiResult<unknown>): result is ApiErrorResponse {
  return 'error' in result && result.error !== undefined;
}
EOF

    TSAB_TYPES_GENERATED=$((TSAB_TYPES_GENERATED + 1))
    _tsab_ok "Generated response wrapper types"
}

# =============================================================================
# Report / Score
# =============================================================================
tsab_report() {
    echo -e "\n  ${TSAB_BOLD}=== Type-Safe API Bridge v${TSAB_VERSION} ===${TSAB_NC}"
    echo -e "  Types generated    : ${TSAB_TYPES_GENERATED}"
    echo -e "  Mismatches found   : ${TSAB_MISMATCHES_FOUND}"
    echo -e "  Clients generated  : ${TSAB_CLIENTS_GENERATED}"
    echo -e "  Consistency score  : ${TSAB_CONSISTENCY_SCORE}"
}

tsab_score() {
    [[ "$TSAB_INITIALIZED" == "true" ]] && echo 100 || echo 0
}

# =============================================================================
# v59.0: Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "type-safe-api-bridge" \
        --version "227.0" \
        --description "Frontend-Backend type safety (shared types/contract validation/typed client)" \
        --init "tsab_init" \
        --report "tsab_report" \
        --score "tsab_score" \
        --enable-var "ENABLE_TYPE_SAFE_BRIDGE" \
        --cli-flags "--type-safe-bridge:--no-type-safe-bridge"
fi

# v2003.1: source時のexit codeを確実に0にする
true
