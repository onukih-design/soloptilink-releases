#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2037.x - IBL (Integration Blueprint Library) Query Engine
# =============================================================================
# 外部サービス連携辞書(~/.soloptilink/integrations/*.json)を検索・引照する。
# DBL(業種辞書)の外部連携版。自然言語から最適コネクタを検出し、その
# OAuth/エンドポイント/Webhook/落とし穴の知識を生成プロンプトへ注入する。
#
# Functions:
#   ibl_init            - 辞書ディレクトリ走査・索引構築
#   ibl_detect <text>   - 自然言語から最適コネクタをキーワード突合で検出 (JSON出力)
#   ibl_list            - 登録コネクタ一覧
#   ibl_show <conn>     - コネクタの要点を日本語で表示
#   ibl_field <conn> <jq_path> - 任意フィールド取得
#   ibl_inject_prompt <conn>   - 生成プロンプトへ注入する日本語知識ブロックを出力
#   ibl_report          - レポート
#   ibl_score           - モジュールスコア(0-100)
#
# All globals use the IBL_ prefix.
# (c) 2026 SoloptiLink Inc. - 営業秘密 / 著作権法・不正競争防止法で保護
# =============================================================================

[[ -n "${_IBL_LOADED:-}" ]] && return 0
_IBL_LOADED=1

declare -g IBL_VERSION="1.0"
declare -g IBL_INITIALIZED=false
declare -g IBL_DIR="${IBL_DIR:-${HOME}/.soloptilink/integrations}"
declare -g IBL_DETECT_COUNT=0
declare -g IBL_INJECT_COUNT=0
declare -g IBL_CONNECTOR_COUNT=0

# =============================================================================
# ibl_init
# =============================================================================
ibl_init() {
    [[ ! -d "$IBL_DIR" ]] && { IBL_CONNECTOR_COUNT=0; return 0; }
    IBL_CONNECTOR_COUNT=$(find "$IBL_DIR" -maxdepth 1 -name '*.json' ! -name '_*' 2>/dev/null | wc -l | tr -d ' ')
    IBL_INITIALIZED=true
    return 0
}

# 内部: jq が無い環境向けの最小フォールバックは python3 を使う
_ibl_have_jq() { command -v jq >/dev/null 2>&1; }

# =============================================================================
# ibl_detect <自然言語テキスト>
#   keywords[] と突合し最高スコアのコネクタを JSON で返す
#   出力: {"connector":"zoom","display_name":"Zoom","score":4,"matched":["Zoom","ミーティング"],"registered":true}
# =============================================================================
ibl_detect() {
    local text="$1"
    [[ -z "$text" ]] && { echo '{"connector":"","score":0,"registered":false}'; return 0; }
    [[ ! -d "$IBL_DIR" ]] && { echo '{"connector":"","score":0,"registered":false}'; return 0; }
    IBL_DETECT_COUNT=$((IBL_DETECT_COUNT + 1))

    IBL_DIR="$IBL_DIR" python3 - "$text" <<'PY'
import json, glob, os, sys, re
text = sys.argv[1].lower()
ibl_dir = os.environ["IBL_DIR"]
best = {"connector": "", "display_name": "", "score": 0, "matched": [], "registered": False}

# カタカナ文字クラス(長音符ー・反復記号・半角カナを含む / 中黒・は語区切りとして除外)。
# 純カタカナ語の前後がこのクラスなら「より長いカタカナ語の一部」とみなし埋め込み誤一致を防ぐ。
# 例: トレロ⊂トレロッコ, アンプリ⊂アンプリファイア, ライン⊂オンライン。
_KATA = r'ァ-ヺー-ヿｦ-ﾝ'
_RE_KATA_ONLY = re.compile(r'^[' + _KATA + r']+$')

def _match(term):
    """ASCII語は英数境界一致(box が dropbox に埋もれるのを防ぐ)、純カタカナ語はカタカナ境界一致
    (短いカタカナ語が長いカタカナ語の内部に埋もれる誤検出を阻止)、それ以外(漢字/ひらがな/英カナ混在)は部分一致。"""
    t = term.lower().strip()
    if not t:
        return False
    if all(ord(c) < 128 for c in t):
        return re.search(r'(?<![a-z0-9])' + re.escape(t) + r'(?![a-z0-9])', text) is not None
    if _RE_KATA_ONLY.match(t):
        return re.search(r'(?<![' + _KATA + r'])' + re.escape(t) + r'(?![' + _KATA + r'])', text) is not None
    return t in text

# 汎用的な動作語/カテゴリ語: ブランド名(LINE/Stripe等)より弱く扱う(DFに関わらず減衰)。
# これにより「LINEでログイン」は"ログイン"でなく"LINE"で line-login-liff に当たる。
GENERIC = {
    "ログイン", "サインイン", "ログアウト", "認証", "ユーザー認証", "決済", "支払い", "支払",
    "メール", "通知", "プッシュ通知", "連携", "同期", "カレンダー", "予定", "予定表",
    "スケジュール", "請求書", "請求", "見積", "見積書", "納品書", "ファイル", "ストレージ",
    "クラウドストレージ", "アップロード", "ダウンロード", "チャット", "メッセージ", "送信",
    "受信", "会計", "勤怠", "契約", "電子契約", "電子署名", "署名", "決済代行", "オンライン決済",
    # 在庫/在庫管理: 在庫系コネクタ(ubiregi/openlogi/nextengine/smaregi 等)が共有する汎用業務カテゴリ語。
    # 裸では POS/WMS/EC のどれにも確信bindすべきでない(識別は複合形=在庫連携/在庫同期 やブランド名で担保)。
    "在庫", "在庫管理",
    "api", "oauth", "oidc", "sso", "openid connect", "webhook", "sms", "payment", "invoice",
    "calendar", "events", "login", "auth", "ai", "crm", "sfa",
    # 一般日本語語彙/汎用句と衝突するブランド日本語読み(IBL敵対監査 is_real=true 確証分)。
    # 該当語は 0.1 倍に減衰させ、ブランド名指しは各辞書の ASCII 語/複合語で担保する。
    # activecampaign: 「現在稼働中のキャンペーン」を表す汎用句 / intercom: 玄関ドアホン等の建物設備
    # calendly: カレンダー機能を指す汎用表記 / freee: 「フリー(無料/フリーランス)」の汎用カタカナ
    "アクティブキャンペーン", "アクティブキャンペーン連携", "インターコム", "カレンダリー", "フリー",
}

# パス1: 全コネクタ読込 + キーワードの document frequency(DF) 集計
# DF が高い語(多くのコネクタが持つ汎用語=ログイン/決済/メール 等)は軽く、
# DF=1 の固有語(ブランド名)は重く扱う(IDF重み付け)。
conns = []
df = {}
for f in glob.glob(os.path.join(ibl_dir, "*.json")):
    b = os.path.basename(f)
    if b.startswith("_"):
        continue
    try:
        d = json.load(open(f))
    except Exception:
        continue
    conns.append((b, d))
    kws = set()
    for kw in d.get("keywords", []):
        if isinstance(kw, str) and kw.strip():
            kws.add(kw.lower().strip())
    for k in kws:
        df[k] = df.get(k, 0) + 1

# パス2: IDF×文字長で採点
for b, d in conns:
    matched = []
    score = 0.0
    seen = set()
    for kw in d.get("keywords", []):
        if not isinstance(kw, str) or not kw.strip():
            continue
        lk = kw.lower().strip()
        if lk in seen:
            continue
        if _match(kw):
            seen.add(lk)
            matched.append(kw)
            dfk = df.get(lk, 1)
            idf = 1.0 if dfk <= 1 else (0.45 if dfk <= 3 else 0.2)  # 共有語ほど減衰
            w = 0.1 if lk in GENERIC else idf                        # 汎用語は強く減衰
            score += max(2, len(lk)) * w
    if score > 0 and score > best["score"]:
        best = {
            "connector": d.get("connector", b[:-5]),
            "display_name": d.get("display_name", ""),
            "score": round(score, 2),
            "matched": matched[:8],
            "registered": True,
        }
# 確信度: スコアが閾値未満(汎用語だけの弱い一致など)は『未登録扱い』にして
# 長尾フォールバック(辞書の新規作成)へ回す。誤検出で別サービスに繋ぐ事故を防ぐ。
CONFIDENCE_MIN = 2.0
best["confident"] = best.get("score", 0) >= CONFIDENCE_MIN
print(json.dumps(best, ensure_ascii=False))
PY
}

# =============================================================================
# ibl_list - 登録コネクタ一覧 (connector  display_name  category  doc_lang)
# =============================================================================
ibl_list() {
    [[ ! -d "$IBL_DIR" ]] && { echo "(IBL未初期化)"; return 0; }
    IBL_DIR="$IBL_DIR" python3 - <<'PY'
import json, glob, os
ibl_dir = os.environ["IBL_DIR"]
rows = []
for f in sorted(glob.glob(os.path.join(ibl_dir, "*.json"))):
    b = os.path.basename(f)
    if b.startswith("_"):
        continue
    try:
        d = json.load(open(f))
    except Exception:
        continue
    rows.append((d.get("connector", b[:-5]), d.get("display_name", ""),
                 d.get("category", ""), d.get("doc_language", "")))
w = max((len(r[0]) for r in rows), default=10)
for c, n, cat, doc in rows:
    print(f"  {c:<{w}}  {n:<16}  {cat:<18}  docs:{doc}")
print(f"\n  合計 {len(rows)} コネクタ")
PY
}

# =============================================================================
# ibl_show <connector> - コネクタ要点の日本語サマリ
# =============================================================================
ibl_show() {
    local conn="$1"
    local f="${IBL_DIR}/${conn}.json"
    [[ ! -f "$f" ]] && { echo "コネクタ '${conn}' は未登録です。利用可能: $(ibl_list | tr -s ' ' | grep -o '^[[:space:]]*[a-z-]*' | tr '\n' ' ')"; return 1; }
    F="$f" python3 - <<'PY'
import json, os
d = json.load(open(os.environ["F"]))
print(f"■ {d.get('display_name')} ({d.get('connector')})  分類:{d.get('category')}  公式ドキュメント言語:{d.get('doc_language')}")
print(f"  概要: {d.get('description_ja','')}")
auth = d.get("auth", {})
print(f"  推奨認証: {auth.get('primary','')}")
oa = auth.get("oauth", {})
if oa.get("scopes"):
    print("  主要スコープ:")
    for s in oa["scopes"][:6]:
        print(f"    - {s.get('scope')}: {s.get('purpose_ja','')}")
print("  主要エンドポイント:")
for e in d.get("endpoints", [])[:6]:
    print(f"    - [{e.get('method')}] {e.get('path')}  … {e.get('name_ja','')}")
wh = d.get("webhooks", {})
if wh.get("supported"):
    v = wh.get("verification", {})
    print(f"  Webhook署名: {v.get('method','')} (ヘッダ {v.get('header','')})")
print("  落とし穴(英語ドキュメントを読まないと踏む罠):")
for p in d.get("pitfalls_ja", [])[:8]:
    print(f"    ⚠ {p}")
print("  必要な環境変数: " + ", ".join(v.get("name","") for v in d.get("env_vars", [])))
PY
}

# =============================================================================
# ibl_field <connector> <jq_path> - 任意フィールドを JSON で取得
# =============================================================================
ibl_field() {
    local conn="$1" path="$2"
    local f="${IBL_DIR}/${conn}.json"
    [[ ! -f "$f" ]] && return 1
    if _ibl_have_jq; then
        jq -c "$path" "$f" 2>/dev/null
    else
        F="$f" P="$path" python3 -c "import json,os; d=json.load(open(os.environ['F'])); print(json.dumps(d.get(os.environ['P'].lstrip('.'), None), ensure_ascii=False))"
    fi
}

# =============================================================================
# ibl_inject_prompt <connector>
#   Connector Forge / 生成プロンプトに差し込む「Claudeがこの連携を知っている」
#   状態を作るための日本語知識ブロックを stdout に出力する。
# =============================================================================
ibl_inject_prompt() {
    local conn="$1"
    local f="${IBL_DIR}/${conn}.json"
    [[ ! -f "$f" ]] && { echo ""; return 1; }
    IBL_INJECT_COUNT=$((IBL_INJECT_COUNT + 1))
    F="$f" python3 - <<'PY'
import json, os
d = json.load(open(os.environ["F"]))
L = []
L.append(f"### 外部連携ナレッジ: {d.get('display_name')} (IBL辞書より / 英語仕様を日本語化済み)")
L.append(f"概要: {d.get('description_ja','')}")
auth = d.get("auth", {})
L.append(f"認証: 推奨={auth.get('primary','')}")
for m in auth.get("methods", [])[:3]:
    L.append(f"  - {m.get('name_ja', m.get('type',''))}: {m.get('when_to_use_ja','')}")
oa = auth.get("oauth", {})
if oa:
    if oa.get("authorize_url"): L.append(f"  authorize_url: {oa['authorize_url']}")
    if oa.get("token_url"): L.append(f"  token_url: {oa['token_url']}")
    if oa.get("scopes"):
        L.append("  必要スコープ: " + ", ".join(s.get("scope","") for s in oa["scopes"]))
    if oa.get("gotcha_ja"): L.append(f"  スコープ注意: {oa['gotcha_ja']}")
L.append(f"ベースURL: {d.get('base_url','')}")
L.append("主要エンドポイント:")
for e in d.get("endpoints", []):
    L.append(f"  - [{e.get('method')}] {e.get('path')}  ({e.get('name_ja','')}) {e.get('purpose_ja','')}")
wh = d.get("webhooks", {})
if wh.get("supported"):
    v = wh.get("verification", {})
    L.append(f"Webhook署名検証: {v.get('method','')} / ヘッダ {v.get('header','')} / アルゴリズム: {v.get('algorithm_ja','')}")
    if wh.get("url_validation_ja"): L.append(f"  登録時検証: {wh['url_validation_ja']}")
    if wh.get("events"): L.append("  購読イベント: " + ", ".join(ev.get("event","") for ev in wh["events"][:8]))
rl = d.get("rate_limits", {})
if rl: L.append(f"レート制限: {rl.get('model_ja','')} / 429時: {rl.get('on_429_ja','')}")
L.append("必要な環境変数:")
for v in d.get("env_vars", []):
    req = "必須" if v.get("required") else "任意"
    L.append(f"  - {v.get('name','')} ({req}): {v.get('desc_ja','')} [取得: {v.get('where_ja','')}]")
L.append("【最重要】落とし穴(これを避けないと連携が動かない):")
for p in d.get("pitfalls_ja", []):
    L.append(f"  ⚠ {p}")
lp = d.get("learned_pitfalls", [])
if lp:
    L.append("【実運用で学習した追加の罠】:")
    for p in lp:
        note = p.get("note_ja", p) if isinstance(p, dict) else p
        L.append(f"  ★ {note}")
sc = d.get("scaffold", {})
if sc.get("files"):
    L.append("生成すべきファイル:")
    for fl in sc["files"]:
        L.append(f"  - {fl.get('path','')} [{fl.get('kind','')}] {fl.get('desc_ja','')}")
if sc.get("prisma_models"):
    L.append("トークン/連携状態のPrismaモデル:")
    for pm in sc["prisma_models"]:
        L.append(f"  - {pm.get('name','')}: {pm.get('fields_ja','')}")
if sc.get("ui_ja"): L.append(f"設定UI(日本語): {sc['ui_ja']}")
L.append("生成規約: UI文字列/コメントは日本語、識別子は英語。秘密キーは.env参照(平文ハードコード禁止)。PFP-082 Watermarkをファイル先頭に注入。")
print("\n".join(L))
PY
}

# =============================================================================
# Report / Score
# =============================================================================
ibl_report() {
    echo -e "\n  ${BOLD:-}=== IBL (Integration Blueprint Library) v${IBL_VERSION} ===${NC:-}"
    echo -e "  登録コネクタ数 : ${IBL_CONNECTOR_COUNT}"
    echo -e "  検出実行回数   : ${IBL_DETECT_COUNT}"
    echo -e "  注入実行回数   : ${IBL_INJECT_COUNT}"
}

ibl_score() {
    local score=20
    [[ "$IBL_INITIALIZED" == "true" ]] && score=$((score + 20))
    [[ $IBL_CONNECTOR_COUNT -ge 5 ]] && score=$((score + 30))
    [[ $IBL_CONNECTOR_COUNT -ge 10 ]] && score=$((score + 15))
    [[ $IBL_DETECT_COUNT -gt 0 ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "ibl" \
        --version "1.0" \
        --description "外部連携辞書(Integration Blueprint Library)検索・引照エンジン" \
        --init "ibl_init" \
        --report "ibl_report" \
        --score "ibl_score" \
        --enable-var "ENABLE_IBL" \
        --cli-flags "--ibl:--no-ibl"
fi

# CLI ディスパッチ (直接実行/管理者検証用)
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    ibl_init
    case "${1:-list}" in
        list)    ibl_list ;;
        detect)  ibl_detect "${2:-}" ;;
        show)    ibl_show "${2:-}" ;;
        inject)  ibl_inject_prompt "${2:-}" ;;
        field)   ibl_field "${2:-}" "${3:-.}" ;;
        report)  ibl_report ;;
        score)   ibl_score ;;
        *)       echo "usage: ibl.sh {list|detect <text>|show <conn>|inject <conn>|field <conn> <path>|report|score}" ;;
    esac
fi

# source時のexit codeを確実に0にする
true
