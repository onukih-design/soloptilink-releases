#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2009.0 - Telemetry Reporter (テレメトリレポーター)
# =============================================================================
# chain.sh のスキル実行データ・エラーパターンを Admin Dashboard の
# テレメトリAPIに送信するモジュール。
#
# - スキル実行開始 → POST /api/v1/telemetry/skill-invocations
# - スキル実行完了 → PUT  /api/v1/telemetry/skill-invocations
# - エラーパターン → POST /api/v1/telemetry/error-patterns
#
# ダッシュボードが起動していない場合はサイレントスキップ（影響なし）。
# すべてのネットワーク呼び出しはバックグラウンドで非同期実行。
#
# v2009.0: 初版 - テレメトリ送信
#
# Functions:
#   tr_init              - テレメトリ初期化（サーバーURL取得・接続テスト）
#   tr_skill_start       - スキル実行開始をAPIに送信
#   tr_skill_complete    - スキル実行完了/失敗をAPIに送信
#   tr_report_error      - エラーパターンをバッファに追加
#   tr_flush_errors      - エラーバッファを一括送信
#   tr_report            - テレメトリレポート出力
#
# All globals use the TR_ prefix. Private functions use _tr_ prefix.
# =============================================================================

[[ -n "${_TELEMETRY_REPORTER_LOADED:-}" ]] && return 0
_TELEMETRY_REPORTER_LOADED=1

# PII マスキング層を読み込み (顧客プロンプトの中央サーバー漏えい防止)
# 同ディレクトリの security/pii-mask.sh を絶対パスで解決する。
_TR_SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
if [[ -f "${_TR_SCRIPT_DIR}/security/pii-mask.sh" ]]; then
    # shellcheck source=security/pii-mask.sh
    source "${_TR_SCRIPT_DIR}/security/pii-mask.sh"
fi

# pii-mask が読み込めなかったときのフェイルクローズ実装
# (マスク不能 = 機微情報を素のまま送ってはならない → 全文を [REDACTED] に置換)
if ! type -t pii_mask &>/dev/null; then
    pii_mask() {
        local input="${1:-}"
        [[ -z "$input" ]] && { echo -n ""; return 0; }
        echo -n "[REDACTED:PII_MASK_UNAVAILABLE]"
    }
fi

# State variables
declare -g TR_VERSION="2009.1"
declare -g TR_ENABLED="false"
declare -g TR_BASE_URL=""
declare -g TR_INVOCATION_ID=""
declare -g TR_COMPANY_ID=""
declare -g TR_DEVICE_ID=""
declare -g TR_REQUESTS_SENT=0
declare -g TR_REQUESTS_FAILED=0
declare -g TR_ERRORS_BUFFERED=0
declare -g TR_ERROR_BUFFER_FILE=""
declare -g TR_LAST_ERROR=""

# Error buffer settings
declare -g _TR_ERROR_FLUSH_THRESHOLD=20

# =============================================================================
# Internal logger
# =============================================================================
_tr_log() {
    local level="$1" msg="$2" color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    [[ "$level" == "SUCCESS" ]] && color="${GREEN:-}"
    echo -e "  ${color}[TELEMETRY]${NC:-} ${msg}" >&2
}

# =============================================================================
# _tr_server_url - Get server URL (same pattern as license-guard.sh)
# =============================================================================
_tr_server_url() {
    # 1. Environment variable
    if [[ -n "${SOLOPTILINK_SERVER_URL:-}" ]]; then
        echo "$SOLOPTILINK_SERVER_URL"
        return
    fi
    # 2. License guard function
    if type -t _lg_server_url &>/dev/null; then
        _lg_server_url 2>/dev/null
        return
    fi
    # 3. .server_url file
    local url_file="${HOME}/.soloptilink/.server_url"
    if [[ -f "$url_file" ]]; then
        local url
        url=$(cat "$url_file" 2>/dev/null | tr -d '[:space:]')
        if [[ -n "$url" ]]; then
            echo "$url"
            return
        fi
    fi
    # 4. Default
    echo "${SOLOPTILINK_DEFAULT_SERVER:-https://admin-dashboard-blue-alpha-78.vercel.app}"
}

# =============================================================================
# _tr_load_identity - Load company_id and device_id from activation.json
# =============================================================================
_tr_load_identity() {
    local activation_file="${HOME}/.soloptilink/activation.json"
    if [[ -f "$activation_file" ]]; then
        if command -v python3 &>/dev/null; then
            TR_COMPANY_ID=$(python3 -c "
import json,sys
try:
    d=json.load(open('$activation_file'))
    print(d.get('company_id',''))
except: pass
" 2>/dev/null || echo "")
            TR_DEVICE_ID=$(python3 -c "
import json,sys
try:
    d=json.load(open('$activation_file'))
    print(d.get('device_id',d.get('terminal_id','')))
except: pass
" 2>/dev/null || echo "")
        fi
    fi
}

# =============================================================================
# _tr_curl_bg - Async background HTTP call (never blocks)
# =============================================================================
# Usage: _tr_curl_bg <method> <endpoint> <json_body>
# =============================================================================
_tr_curl_bg() {
    local method="${1:-POST}" endpoint="${2:-}" json_body="${3:-{}}"

    [[ "${TR_ENABLED}" != "true" ]] && return 1
    command -v curl &>/dev/null || return 1
    [[ -z "${TR_BASE_URL}" ]] && return 1

    local url="${TR_BASE_URL}${endpoint}"
    local error_log="${HOME}/.soloptilink/.error-log"

    # v2034.2 堅牢化:
    # - timeout 10s -> 15s, connect-timeout 5s 明示, --retry 2 --retry-delay 1 を追加
    # - stderr を 2>/dev/null から 2>>$error_log に変更 (黙殺禁止)
    # Run curl in background - fire and forget
    (
        local http_code
        http_code=$(curl -s \
            -X "$method" \
            -H "Content-Type: application/json" \
            -H "X-Terminal-Id: ${TR_DEVICE_ID:-}" \
            --max-time 15 \
            --connect-timeout 5 \
            --retry 2 \
            --retry-delay 1 \
            -w "%{http_code}" \
            -o /dev/null \
            -d "$json_body" \
            "$url" 2>>"$error_log" || echo "000")

        # 失敗時 (000 or 4xx/5xx) のみ error-log に記録
        case "$http_code" in
            2[0-9][0-9]|204) : ;;
            *)
                echo "$(date '+%Y-%m-%dT%H:%M:%S') [telemetry-bg] FAIL http=$http_code url=$url" >> "$error_log" 2>/dev/null
                ;;
        esac
    ) &>/dev/null &
    disown 2>/dev/null || true

    TR_REQUESTS_SENT=$((TR_REQUESTS_SENT + 1))
    return 0
}

# =============================================================================
# _tr_curl_sync - Synchronous HTTP call that captures response
# =============================================================================
# Usage: _tr_curl_sync <method> <endpoint> <json_body>
# Outputs: response body on stdout
# =============================================================================
_tr_curl_sync() {
    local method="${1:-POST}" endpoint="${2:-}" json_body="${3:-{}}"

    [[ "${TR_ENABLED}" != "true" ]] && return 1
    command -v curl &>/dev/null || return 1
    [[ -z "${TR_BASE_URL}" ]] && return 1

    local url="${TR_BASE_URL}${endpoint}"
    local error_log="${HOME}/.soloptilink/.error-log"
    local tmp_file
    tmp_file=$(mktemp 2>/dev/null || echo "/tmp/tr_resp_$$")

    # v2034.2 堅牢化:
    # - timeout 10s -> 15s, connect-timeout 5s, --retry 2 --retry-delay 1
    # - stderr 黙殺禁止: 2>/dev/null → 2>>$error_log
    local http_code
    http_code=$(curl -s \
        -X "$method" \
        -H "Content-Type: application/json" \
        -H "X-Terminal-Id: ${TR_DEVICE_ID:-}" \
        --max-time 15 \
        --connect-timeout 5 \
        --retry 2 \
        --retry-delay 1 \
        -w "%{http_code}" \
        -o "$tmp_file" \
        -d "$json_body" \
        "$url" 2>>"$error_log" || echo "000")

    TR_REQUESTS_SENT=$((TR_REQUESTS_SENT + 1))

    case "$http_code" in
        2[0-9][0-9])
            cat "$tmp_file" 2>/dev/null
            rm -f "$tmp_file" 2>/dev/null
            return 0
            ;;
        *)
            TR_REQUESTS_FAILED=$((TR_REQUESTS_FAILED + 1))
            TR_LAST_ERROR="HTTP ${http_code} on ${method} ${endpoint}"
            echo "$(date '+%Y-%m-%dT%H:%M:%S') [telemetry-sync] FAIL http=$http_code method=$method endpoint=$endpoint" >> "$error_log" 2>/dev/null
            rm -f "$tmp_file" 2>/dev/null
            return 1
            ;;
    esac
}

# =============================================================================
# _tr_escape_json - Escape string for JSON embedding
# =============================================================================
_tr_escape_json() {
    local s="${1:-}"
    s="${s//\\/\\\\}"
    s="${s//\"/\\\"}"
    s="${s//$'\n'/\\n}"
    s="${s//$'\r'/\\r}"
    s="${s//$'\t'/\\t}"
    echo -n "$s"
}

# =============================================================================
# tr_init - Initialize telemetry reporter
# =============================================================================
# Checks server connectivity and loads identity.
# Sets TR_ENABLED=true if server is reachable.
# =============================================================================
tr_init() {
    # オプトアウト: SOLOPTILINK_TELEMETRY_OPTOUT=1 で送信を完全停止する。
    # ~/.soloptilink/.telemetry_optout が存在しても同じ扱い (永続オプトアウト)。
    if [[ "${SOLOPTILINK_TELEMETRY_OPTOUT:-}" == "1" ]] || \
       [[ -f "${HOME}/.soloptilink/.telemetry_optout" ]]; then
        TR_ENABLED="false"
        _tr_log "WARN" "テレメトリ オプトアウト有効 — 送信停止"
        return 0
    fi

    TR_BASE_URL=$(_tr_server_url)

    # Strip trailing slash
    TR_BASE_URL="${TR_BASE_URL%/}"

    # Load identity
    _tr_load_identity

    # Create error buffer file
    TR_ERROR_BUFFER_FILE=$(mktemp 2>/dev/null || echo "/tmp/tr_errors_$$")
    echo "[]" > "$TR_ERROR_BUFFER_FILE" 2>/dev/null
    TR_ERRORS_BUFFERED=0

    # Connectivity test - quick HEAD request
    if command -v curl &>/dev/null; then
        local http_code
        http_code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 3 \
            "${TR_BASE_URL}/api/v1/telemetry/skill-invocations" \
            -X OPTIONS 2>/dev/null || echo "000")

        case "$http_code" in
            2[0-9][0-9]|204|405)
                TR_ENABLED="true"
                _tr_log "SUCCESS" "テレメトリ接続OK (${TR_BASE_URL})"
                ;;
            000)
                TR_ENABLED="false"
                _tr_log "WARN" "テレメトリサーバー接続不可 - テレメトリ無効"
                ;;
            *)
                # Server reachable but may have different response - enable anyway
                TR_ENABLED="true"
                _tr_log "SUCCESS" "テレメトリ有効 (HTTP ${http_code})"
                ;;
        esac
    else
        TR_ENABLED="false"
        _tr_log "WARN" "curl未検出 - テレメトリ無効"
    fi

    return 0
}

# =============================================================================
# tr_skill_start - Record skill execution start
# =============================================================================
# Usage: tr_skill_start <skill_name> <prompt_summary> <target_domain> <version>
# =============================================================================
tr_skill_start() {
    local skill_name="${1:-soloptilink}"
    local prompt_summary="${2:-}"
    local target_domain="${3:-general}"
    local version="${4:-unknown}"

    [[ "${TR_ENABLED}" != "true" ]] && return 0

    # PII マスキング (顧客プロンプトを素のまま送らない)
    local masked_prompt
    masked_prompt=$(pii_mask "$prompt_summary")

    local escaped_prompt
    escaped_prompt=$(_tr_escape_json "$masked_prompt")

    local json_body
    json_body=$(cat <<EOJSON
{
  "skill_name": "${skill_name}",
  "skill_version": "${version}",
  "prompt_summary": "${escaped_prompt}",
  "target_domain": "${target_domain}",
  "company_id": "${TR_COMPANY_ID:-}",
  "terminal_id": "${TR_DEVICE_ID:-}"
}
EOJSON
)

    # Synchronous call to capture invocation_id
    local response
    response=$(_tr_curl_sync "POST" "/api/v1/telemetry/skill-invocations" "$json_body" 2>/dev/null)

    if [[ $? -eq 0 ]] && [[ -n "$response" ]]; then
        # Extract invocation_id from response
        if command -v python3 &>/dev/null; then
            TR_INVOCATION_ID=$(echo "$response" | python3 -c "
import json,sys
try:
    d=json.load(sys.stdin)
    print(d.get('invocation_id',''))
except: pass
" 2>/dev/null || echo "")
        fi

        if [[ -n "$TR_INVOCATION_ID" ]]; then
            _tr_log "SUCCESS" "スキル実行開始記録: ${TR_INVOCATION_ID}"
        fi
    fi

    return 0
}

# =============================================================================
# tr_skill_complete - Record skill execution completion
# =============================================================================
# Usage: tr_skill_complete <status> <quality_score> <duration_seconds> \
#                          <files_generated> <error_count> <cost_usd> \
#                          [result_summary]
# =============================================================================
tr_skill_complete() {
    local status="${1:-completed}"
    local quality_score="${2:-0}"
    local duration_seconds="${3:-0}"
    local files_generated="${4:-0}"
    local error_count="${5:-0}"
    local cost_usd="${6:-0}"
    local result_summary="${7:-}"

    [[ "${TR_ENABLED}" != "true" ]] && return 0
    [[ -z "${TR_INVOCATION_ID}" ]] && return 0

    # PII マスキング (生成結果サマリにも顧客情報が混入しうる)
    local masked_summary
    masked_summary=$(pii_mask "$result_summary")

    local escaped_summary
    escaped_summary=$(_tr_escape_json "$masked_summary")

    local json_body
    json_body=$(cat <<EOJSON
{
  "invocation_id": "${TR_INVOCATION_ID}",
  "execution_status": "${status}",
  "quality_score": ${quality_score},
  "duration_seconds": ${duration_seconds},
  "files_generated": ${files_generated},
  "error_count": ${error_count},
  "cost_usd": ${cost_usd},
  "result_summary": "${escaped_summary}",
  "company_id": "${TR_COMPANY_ID:-}",
  "terminal_id": "${TR_DEVICE_ID:-}"
}
EOJSON
)

    _tr_curl_bg "PUT" "/api/v1/telemetry/skill-invocations" "$json_body"
    _tr_log "SUCCESS" "スキル実行完了記録: ${status} (score=${quality_score}, ${duration_seconds}s)"

    return 0
}

# =============================================================================
# tr_report_error - Buffer an error pattern for batch sending
# =============================================================================
# Usage: tr_report_error <error_message> [error_code] [affected_file] \
#                        [stack_trace] [affected_phase]
# =============================================================================
tr_report_error() {
    local error_message="${1:-}"
    local error_code="${2:-}"
    local affected_file="${3:-}"
    local stack_trace="${4:-}"
    local affected_phase="${5:-}"

    [[ "${TR_ENABLED}" != "true" ]] && return 0
    [[ -z "$error_message" ]] && return 0

    # PII マスキング (エラーメッセージ/スタックトレースにファイルパスや
    # 顧客指定の値が含まれることが多い)
    local masked_msg masked_file masked_stack
    masked_msg=$(pii_mask "$error_message")
    masked_file=$(pii_mask "$affected_file")
    masked_stack=$(pii_mask "$stack_trace")
    # error_code / affected_phase は ENUM 相当なのでマスク不要

    local escaped_msg escaped_code escaped_file escaped_stack escaped_phase
    escaped_msg=$(_tr_escape_json "$masked_msg")
    escaped_code=$(_tr_escape_json "$error_code")
    escaped_file=$(_tr_escape_json "$masked_file")
    escaped_stack=$(_tr_escape_json "$masked_stack")
    escaped_phase=$(_tr_escape_json "$affected_phase")

    # Append to buffer file
    local entry
    entry=$(cat <<EOJSON
{
  "error_message": "${escaped_msg}",
  "error_code": "${escaped_code}",
  "affected_file": "${escaped_file}",
  "stack_trace": "${escaped_stack}",
  "affected_phase": "${escaped_phase}",
  "invocation_id": "${TR_INVOCATION_ID:-}",
  "company_id": "${TR_COMPANY_ID:-}",
  "terminal_id": "${TR_DEVICE_ID:-}"
}
EOJSON
)

    # Append to buffer
    if [[ -f "$TR_ERROR_BUFFER_FILE" ]]; then
        if command -v python3 &>/dev/null; then
            python3 -c "
import json,sys
try:
    with open('${TR_ERROR_BUFFER_FILE}','r') as f:
        buf=json.load(f)
    buf.append(json.loads('''${entry}'''))
    with open('${TR_ERROR_BUFFER_FILE}','w') as f:
        json.dump(buf,f)
except Exception as e:
    pass
" 2>/dev/null
        else
            # Fallback: write individual error files
            echo "$entry" >> "${TR_ERROR_BUFFER_FILE}.lines"
        fi
    fi

    TR_ERRORS_BUFFERED=$((TR_ERRORS_BUFFERED + 1))

    # Auto-flush if buffer is full
    if [[ "$TR_ERRORS_BUFFERED" -ge "$_TR_ERROR_FLUSH_THRESHOLD" ]]; then
        tr_flush_errors
    fi

    return 0
}

# =============================================================================
# tr_flush_errors - Send buffered errors to API
# =============================================================================
tr_flush_errors() {
    [[ "${TR_ENABLED}" != "true" ]] && return 0
    [[ "$TR_ERRORS_BUFFERED" -eq 0 ]] && return 0

    local json_body=""

    if [[ -f "$TR_ERROR_BUFFER_FILE" ]] && command -v python3 &>/dev/null; then
        json_body=$(python3 -c "
import json
try:
    with open('${TR_ERROR_BUFFER_FILE}','r') as f:
        buf=json.load(f)
    if buf:
        print(json.dumps(buf))
except: pass
" 2>/dev/null || echo "")
    fi

    if [[ -n "$json_body" ]] && [[ "$json_body" != "[]" ]]; then
        _tr_curl_bg "POST" "/api/v1/telemetry/error-patterns" "$json_body"
        _tr_log "SUCCESS" "エラーパターン ${TR_ERRORS_BUFFERED}件 送信"
    fi

    # Reset buffer
    echo "[]" > "$TR_ERROR_BUFFER_FILE" 2>/dev/null
    TR_ERRORS_BUFFERED=0

    return 0
}

# =============================================================================
# tr_report - Output telemetry report summary
# =============================================================================
tr_report() {
    if [[ "${TR_ENABLED}" != "true" ]]; then
        _tr_log "WARN" "テレメトリ無効のためレポートなし"
        return 0
    fi

    echo -e "\n  ${CYAN:-}━━━ Telemetry Report v${TR_VERSION} ━━━${NC:-}" >&2
    echo -e "  📡 サーバー: ${TR_BASE_URL}" >&2
    echo -e "  🏢 企業ID: ${TR_COMPANY_ID:-未設定}" >&2
    echo -e "  🔑 デバイスID: ${TR_DEVICE_ID:-未設定}" >&2
    echo -e "  📋 実行ID: ${TR_INVOCATION_ID:-未記録}" >&2
    echo -e "  📤 送信数: ${TR_REQUESTS_SENT}" >&2
    echo -e "  ❌ 失敗数: ${TR_REQUESTS_FAILED}" >&2
    echo -e "  🐛 エラーバッファ: ${TR_ERRORS_BUFFERED}件" >&2

    if [[ -n "$TR_LAST_ERROR" ]]; then
        echo -e "  ⚠️  最終エラー: ${TR_LAST_ERROR}" >&2
    fi

    echo -e "  ${CYAN:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}\n" >&2

    # Cleanup buffer file
    rm -f "$TR_ERROR_BUFFER_FILE" 2>/dev/null
    rm -f "${TR_ERROR_BUFFER_FILE}.lines" 2>/dev/null

    return 0
}
