#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v388.0 - Contract Management
# =============================================================================
# 契約管理エンジン。契約作成/電子署名/更新追跡等を自動生成。
# All globals use the CM_ prefix.
# =============================================================================

[[ -n "${_CONTRACT_MANAGEMENT_LOADED:-}" ]] && return 0
_CONTRACT_MANAGEMENT_LOADED=1

declare -g CM_VERSION="388.0"
declare -g CM_INITIALIZED=false
declare -g CM_GENERATED_COUNT=0
declare -g CM_CONTRACT_GENERATED=false
declare -g CM_SIGNING_GENERATED=false
declare -g CM_RENEWAL_GENERATED=false
declare -g CM_TEMPLATE_GENERATED=false
declare -g ENABLE_CM="${ENABLE_CM:-true}"

_cm_init() { CM_INITIALIZED=true; CM_GENERATED_COUNT=0; return 0; }

_cm_generate_all() {
    local project_dir="${1:-.}"
    [[ "$CM_INITIALIZED" != "true" ]] && _cm_init
    echo -e "  ${CYAN:-\033[0;36m}[CM]${NC:-\033[0m} 契約管理テンプレート生成開始..." >&2
    _cm_generate_contract "$project_dir"
    _cm_generate_signing "$project_dir"
    _cm_track_renewal "$project_dir"
    _cm_generate_template "$project_dir"
    echo -e "  ${GREEN:-\033[0;32m}[CM]${NC:-\033[0m} 契約管理生成完了: ${CM_GENERATED_COUNT}件" >&2
    return 0
}

_cm_generate_contract() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [CM-CONTRACT] 契約管理テンプレート

### Schema
```prisma
model Contract {
  id            String   @id @default(cuid())
  contractNumber String  @unique
  title         String
  type          String
  status        String   @default("draft")
  partyA        Json
  partyB        Json
  startDate     DateTime?
  endDate       DateTime?
  autoRenew     Boolean  @default(false)
  renewalPeriod Int?
  value         BigInt?
  currency      String   @default("JPY")
  content       String   @db.Text
  versions      ContractVersion[]
  signatures    ContractSignature[]
  reminders     ContractReminder[]
  createdBy     String
  createdAt     DateTime @default(now())
  updatedAt     DateTime @updatedAt
  @@index([status])
  @@index([endDate])
}

model ContractVersion {
  id          String   @id @default(cuid())
  contractId  String
  contract    Contract @relation(fields: [contractId], references: [id])
  version     Int
  content     String   @db.Text
  changelog   String?
  createdBy   String
  createdAt   DateTime @default(now())
  @@unique([contractId, version])
}
```

### Contract CRUD
```typescript
export class ContractService {
  async create(data: CreateContractInput): Promise<Contract> {
    const number = `CT-${format(new Date(), 'yyyyMM')}-${String(await this.getNextSeq()).padStart(4, '0')}`;
    return prisma.$transaction(async (tx) => {
      const contract = await tx.contract.create({
        data: { ...data, contractNumber: number, versions: { create: { version: 1, content: data.content, createdBy: data.createdBy } } },
      });
      if (data.endDate && data.autoRenew) {
        await tx.contractReminder.create({
          data: { contractId: contract.id, type: 'renewal', remindAt: subDays(new Date(data.endDate), 30) },
        });
      }
      return contract;
    });
  }

  async updateContent(contractId: string, content: string, userId: string, changelog: string) {
    const current = await prisma.contractVersion.findFirst({
      where: { contractId }, orderBy: { version: 'desc' },
    });
    return prisma.$transaction([
      prisma.contractVersion.create({
        data: { contractId, version: (current?.version ?? 0) + 1, content, changelog, createdBy: userId },
      }),
      prisma.contract.update({ where: { id: contractId }, data: { content } }),
    ]);
  }
}
```
TEMPLATE
    CM_CONTRACT_GENERATED=true
    CM_GENERATED_COUNT=$((CM_GENERATED_COUNT + 1))
    return 0
}

_cm_generate_signing() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [CM-SIGNING] 電子署名テンプレート

```typescript
model ContractSignature {
  id         String   @id @default(cuid())
  contractId String
  contract   Contract @relation(fields: [contractId], references: [id])
  signerId   String
  signerName String
  signerEmail String
  status     String   @default("pending")
  signedAt   DateTime?
  ipAddress  String?
  userAgent  String?
  signatureHash String?
  @@unique([contractId, signerId])
}

export class SigningService {
  async requestSignatures(contractId: string, signers: { id: string; name: string; email: string }[]) {
    for (const signer of signers) {
      await prisma.contractSignature.create({
        data: { contractId, signerId: signer.id, signerName: signer.name, signerEmail: signer.email },
      });
      await sendEmail(signer.email, 'contract_signing_request', { contractId, signerName: signer.name });
    }
    await prisma.contract.update({ where: { id: contractId }, data: { status: 'pending_signature' } });
  }

  async sign(contractId: string, signerId: string, ipAddress: string, userAgent: string) {
    const hash = createHash('sha256').update(`${contractId}:${signerId}:${Date.now()}`).digest('hex');
    await prisma.contractSignature.update({
      where: { contractId_signerId: { contractId, signerId } },
      data: { status: 'signed', signedAt: new Date(), ipAddress, userAgent, signatureHash: hash },
    });
    const pending = await prisma.contractSignature.count({ where: { contractId, status: 'pending' } });
    if (pending === 0) {
      await prisma.contract.update({ where: { id: contractId }, data: { status: 'active' } });
    }
  }
}
```
TEMPLATE
    CM_SIGNING_GENERATED=true
    CM_GENERATED_COUNT=$((CM_GENERATED_COUNT + 1))
    return 0
}

_cm_track_renewal() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [CM-RENEWAL] 契約更新追跡テンプレート

```typescript
export class RenewalTracker {
  async checkUpcomingRenewals(daysAhead: number = 30): Promise<Contract[]> {
    return prisma.contract.findMany({
      where: { status: 'active', autoRenew: true,
        endDate: { gte: new Date(), lte: addDays(new Date(), daysAhead) } },
      orderBy: { endDate: 'asc' },
    });
  }

  async processAutoRenewal(contractId: string) {
    const contract = await prisma.contract.findUniqueOrThrow({ where: { id: contractId } });
    if (!contract.autoRenew || !contract.renewalPeriod) return;
    const newEndDate = addMonths(contract.endDate!, contract.renewalPeriod);
    await prisma.contract.update({
      where: { id: contractId }, data: { endDate: newEndDate },
    });
    await prisma.auditLog.create({
      data: { action: 'contract_auto_renewed', entityId: contractId, details: JSON.stringify({ newEndDate }) },
    });
  }
}
```
TEMPLATE
    CM_RENEWAL_GENERATED=true
    CM_GENERATED_COUNT=$((CM_GENERATED_COUNT + 1))
    return 0
}

_cm_generate_template() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [CM-TEMPLATE] 契約書テンプレート管理

```typescript
export const CONTRACT_TEMPLATES = {
  nda: { name: '秘密保持契約書', variables: ['partyA', 'partyB', 'effectiveDate', 'duration', 'scope'] },
  service: { name: '業務委託契約書', variables: ['partyA', 'partyB', 'scope', 'fee', 'paymentTerms', 'duration'] },
  employment: { name: '雇用契約書', variables: ['employer', 'employee', 'position', 'salary', 'startDate'] },
  saas: { name: 'SaaS利用規約', variables: ['provider', 'customer', 'plan', 'fee', 'sla'] },
};

export function renderTemplate(templateKey: string, variables: Record<string, string>): string {
  const template = CONTRACT_TEMPLATES[templateKey as keyof typeof CONTRACT_TEMPLATES];
  if (!template) throw new Error(`Unknown template: ${templateKey}`);
  let content = getTemplateContent(templateKey);
  for (const [key, value] of Object.entries(variables)) {
    content = content.replace(new RegExp(`\\{\\{${key}\\}\\}`, 'g'), value);
  }
  return content;
}
```
TEMPLATE
    CM_TEMPLATE_GENERATED=true
    CM_GENERATED_COUNT=$((CM_GENERATED_COUNT + 1))
    return 0
}

_cm_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Contract Management v${CM_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成数             : ${CM_GENERATED_COUNT}"
    echo -e "  契約管理           : ${CM_CONTRACT_GENERATED}"
    echo -e "  電子署名           : ${CM_SIGNING_GENERATED}"
    echo -e "  更新追跡           : ${CM_RENEWAL_GENERATED}"
    echo -e "  テンプレート       : ${CM_TEMPLATE_GENERATED}"
}

_cm_score() {
    local score=30
    [[ "$CM_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$CM_CONTRACT_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$CM_SIGNING_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$CM_RENEWAL_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$CM_TEMPLATE_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "contract-management" \
    --version "388.0" \
    --description "契約管理（作成/電子署名/更新追跡/テンプレート）" \
    --init "_cm_init" \
    --report "_cm_report" \
    --score "_cm_score" \
    --enable-var "ENABLE_CM" \
    --cli-flags "--contract-mgmt:--no-contract-mgmt"
