#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v16.0 - Model Router
# =============================================================================
# Intelligent model tiering: routes tasks to the optimal Claude model based on
# task complexity, phase requirements, and cost constraints.
#
# Tiers:
#   frontier  → Claude Opus   (planning, architecture, complex reasoning)
#   balanced  → Claude Sonnet  (implementation, code generation)
#   economy   → Claude Haiku   (formatting, simple tasks, validation checks)
#   auto      → Automatic selection based on phase/task analysis
#
# Pricing (per 1M tokens):
#   Opus:   $15 input / $75 output
#   Sonnet: $3 input  / $15 output
#   Haiku:  $0.25 input / $1.25 output
#
# Functions:
#   mr_init              - Initialize model router
#   mr_select_model      - Select optimal model for a task
#   mr_get_model_flag    - Get Claude CLI model flag string
#   mr_route_phase       - Route a phase to the right model
#   mr_estimate_cost     - Estimate cost for model + tokens
#   mr_record_usage      - Record model usage for tracking
#   mr_get_pricing       - Get pricing for a model tier
#   mr_report            - Print model routing report
#   mr_export_json       - Export routing data as JSON
#
# All globals use the MR_ prefix.
# =============================================================================

[[ -n "${_MODEL_ROUTER_LOADED:-}" ]] && return 0
_MODEL_ROUTER_LOADED=1

# ============================================================
# State
# ============================================================
declare -g MR_ENABLED="false"
declare -g MR_SESSION_ID=""
declare -g MR_DEFAULT_TIER="balanced"   # auto | frontier | balanced | economy
declare -g MR_TOTAL_CALLS=0

# Per-model tracking
declare -g MR_OPUS_CALLS=0
declare -g MR_SONNET_CALLS=0
declare -g MR_HAIKU_CALLS=0
declare -g MR_OPUS_COST="0.00"
declare -g MR_SONNET_COST="0.00"
declare -g MR_HAIKU_COST="0.00"

# Phase-to-tier mapping (for auto mode)
declare -g -A MR_PHASE_TIER=(
    [requirements]="frontier"
    [competitive_research]="frontier"
    [prompt_expand]="frontier"
    [scaffold]="balanced"
    [database]="balanced"
    [backend]="balanced"
    [api]="balanced"
    [implementation]="balanced"
    [frontend]="balanced"
    [testing]="balanced"
    [quality_check]="economy"
    [security_audit]="balanced"
    [browser_test]="economy"
    [documentation]="economy"
    [deploy]="economy"
    [hotfix]="balanced"
    [knowledge_save]="economy"
    [ui_design]="balanced"
)

# Model names for Claude CLI --model flag
declare -g -A MR_MODEL_NAMES=(
    [frontier]="claude-opus-4-20250514"
    [balanced]="claude-sonnet-4-20250514"
    [economy]="claude-haiku-3-5-20241022"
)

# Pricing per 1M tokens (input, output)
declare -g -A MR_PRICING_INPUT=(
    [frontier]="15.00"
    [balanced]="3.00"
    [economy]="0.25"
)
declare -g -A MR_PRICING_OUTPUT=(
    [frontier]="75.00"
    [balanced]="15.00"
    [economy]="1.25"
)

# ============================================================
# Internal logger
# ============================================================
_mr_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    [[ "$level" == "SUCCESS" ]] && color="${GREEN:-}"
    echo -e "  ${color}[MODEL-RT]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize model router
# ============================================================
mr_init() {
    local session_id="${1:-${SESSION_ID:-unknown}}"
    local default_tier="${2:-${MR_DEFAULT_TIER}}"

    MR_SESSION_ID="$session_id"
    MR_DEFAULT_TIER="$default_tier"
    MR_ENABLED="true"
    MR_TOTAL_CALLS=0
    MR_OPUS_CALLS=0
    MR_SONNET_CALLS=0
    MR_HAIKU_CALLS=0
    MR_OPUS_COST="0.00"
    MR_SONNET_COST="0.00"
    MR_HAIKU_COST="0.00"

    _mr_log "SUCCESS" "モデルルーター v16.0 初期化: デフォルトティア=${default_tier}"
    return 0
}

# ============================================================
# Select optimal model tier for a task
# ============================================================
mr_select_model() {
    local phase="${1:-unknown}"
    local task_hint="${2:-}"
    local override_tier="${3:-}"

    # Explicit override takes precedence
    if [[ -n "$override_tier" && "$override_tier" != "auto" ]]; then
        echo "$override_tier"
        return 0
    fi

    # If not auto mode, use default tier
    if [[ "$MR_DEFAULT_TIER" != "auto" ]]; then
        echo "$MR_DEFAULT_TIER"
        return 0
    fi

    # Auto mode: route based on phase mapping
    local tier="${MR_PHASE_TIER[$phase]:-balanced}"

    # Complexity analysis of task hint
    if [[ -n "$task_hint" ]]; then
        local hint_lower
        hint_lower=$(echo "$task_hint" | tr '[:upper:]' '[:lower:]')

        # Upgrade to frontier for complex tasks
        if [[ "$hint_lower" =~ (設計|アーキテクチャ|architecture|design|計画|plan|分析|analysis|戦略|strategy) ]]; then
            tier="frontier"
        fi

        # Downgrade to economy for simple tasks
        if [[ "$hint_lower" =~ (フォーマット|format|整形|lint|コメント|comment|ドキュメント|documentation|rename|リネーム) ]]; then
            tier="economy"
        fi
    fi

    echo "$tier"
}

# ============================================================
# Get Claude CLI model flag for a tier
# ============================================================
mr_get_model_flag() {
    local tier="${1:-balanced}"
    local model_name="${MR_MODEL_NAMES[$tier]:-${MR_MODEL_NAMES[balanced]}}"
    echo "--model ${model_name}"
}

# ============================================================
# Get model name for a tier
# ============================================================
mr_get_model_name() {
    local tier="${1:-balanced}"
    echo "${MR_MODEL_NAMES[$tier]:-${MR_MODEL_NAMES[balanced]}}"
}

# ============================================================
# Route a phase to the right model (returns tier name)
# ============================================================
mr_route_phase() {
    local phase="${1:?mr_route_phase: phase required}"
    local task_hint="${2:-}"

    local tier
    tier=$(mr_select_model "$phase" "$task_hint")

    _mr_log "INFO" "フェーズ '${phase}' → ${tier} ($(mr_get_model_name "$tier"))"
    echo "$tier"
}

# ============================================================
# Estimate cost for model + tokens
# ============================================================
mr_estimate_cost() {
    local tier="${1:-balanced}"
    local input_tokens="${2:-0}"
    local output_tokens="${3:-0}"

    local input_price="${MR_PRICING_INPUT[$tier]:-3.00}"
    local output_price="${MR_PRICING_OUTPUT[$tier]:-15.00}"

    if command -v bc &>/dev/null; then
        local cost
        cost=$(echo "scale=6; (${input_tokens} * ${input_price} / 1000000) + (${output_tokens} * ${output_price} / 1000000)" | bc 2>/dev/null | sed 's/^\./0./')
        echo "${cost:-0.00}"
    elif command -v awk &>/dev/null; then
        awk "BEGIN{printf \"%.6f\", (${input_tokens} * ${input_price} / 1000000) + (${output_tokens} * ${output_price} / 1000000)}" 2>/dev/null
    else
        echo "0.00"
    fi
}

# ============================================================
# Record model usage for tracking
# ============================================================
mr_record_usage() {
    local tier="${1:?mr_record_usage: tier required}"
    local input_tokens="${2:-0}"
    local output_tokens="${3:-0}"

    MR_TOTAL_CALLS=$((MR_TOTAL_CALLS + 1))

    local cost
    cost=$(mr_estimate_cost "$tier" "$input_tokens" "$output_tokens")

    case "$tier" in
        frontier)
            MR_OPUS_CALLS=$((MR_OPUS_CALLS + 1))
            if command -v bc &>/dev/null; then
                MR_OPUS_COST=$(echo "scale=4; ${MR_OPUS_COST} + ${cost}" | bc 2>/dev/null | sed 's/^\./0./' || echo "$MR_OPUS_COST")
            fi
            ;;
        balanced)
            MR_SONNET_CALLS=$((MR_SONNET_CALLS + 1))
            if command -v bc &>/dev/null; then
                MR_SONNET_COST=$(echo "scale=4; ${MR_SONNET_COST} + ${cost}" | bc 2>/dev/null | sed 's/^\./0./' || echo "$MR_SONNET_COST")
            fi
            ;;
        economy)
            MR_HAIKU_CALLS=$((MR_HAIKU_CALLS + 1))
            if command -v bc &>/dev/null; then
                MR_HAIKU_COST=$(echo "scale=4; ${MR_HAIKU_COST} + ${cost}" | bc 2>/dev/null | sed 's/^\./0./' || echo "$MR_HAIKU_COST")
            fi
            ;;
    esac

    # Log to observatory
    if type -t obs_emit_event &>/dev/null; then
        obs_emit_event "MODEL_ROUTE" "{\"tier\":\"${tier}\",\"input_tokens\":${input_tokens},\"output_tokens\":${output_tokens},\"cost\":\"${cost}\"}" 2>/dev/null || true
    fi
}

# ============================================================
# Get pricing info for a tier
# ============================================================
mr_get_pricing() {
    local tier="${1:-balanced}"
    echo "input=\$${MR_PRICING_INPUT[$tier]:-3.00}/1M output=\$${MR_PRICING_OUTPUT[$tier]:-15.00}/1M"
}

# ============================================================
# Calculate savings compared to all-frontier
# ============================================================
mr_calculate_savings() {
    if ! command -v bc &>/dev/null; then
        echo "0.00"
        return
    fi

    # Total actual cost
    local actual_total
    actual_total=$(echo "scale=4; ${MR_OPUS_COST} + ${MR_SONNET_COST} + ${MR_HAIKU_COST}" | bc 2>/dev/null | sed 's/^\./0./' || echo "0.00")

    # What it would have cost if all calls used frontier
    # Approximation: assume same token counts but frontier pricing
    # Use ratio: frontier is 5x sonnet, 60x haiku
    local frontier_equivalent
    frontier_equivalent=$(echo "scale=4; (${MR_OPUS_COST}) + (${MR_SONNET_COST} * 5) + (${MR_HAIKU_COST} * 60)" | bc 2>/dev/null | sed 's/^\./0./' || echo "0.00")

    local savings
    savings=$(echo "scale=4; ${frontier_equivalent} - ${actual_total}" | bc 2>/dev/null | sed 's/^\./0./' || echo "0.00")

    echo "$savings"
}

# ============================================================
# Model routing report (ASCII)
# ============================================================
mr_report() {
    echo ""
    echo -e "  ${BOLD:-}${CYAN:-}[Model Router Report] v16.0${NC:-}"
    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    echo -e "  デフォルトティア:   ${MR_DEFAULT_TIER}"
    echo -e "  総呼び出し:         ${MR_TOTAL_CALLS}"
    echo ""

    printf "  %-12s  %-28s  %6s  %10s\n" "Tier" "Model" "Calls" "Cost"
    echo -e "  ────────────  ────────────────────────────  ──────  ──────────"
    printf "  %-12s  %-28s  %6d  \$%9s\n" "frontier" "${MR_MODEL_NAMES[frontier]:0:28}" "$MR_OPUS_CALLS" "$MR_OPUS_COST"
    printf "  %-12s  %-28s  %6d  \$%9s\n" "balanced" "${MR_MODEL_NAMES[balanced]:0:28}" "$MR_SONNET_CALLS" "$MR_SONNET_COST"
    printf "  %-12s  %-28s  %6d  \$%9s\n" "economy" "${MR_MODEL_NAMES[economy]:0:28}" "$MR_HAIKU_CALLS" "$MR_HAIKU_COST"

    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"

    local total_cost
    if command -v bc &>/dev/null; then
        total_cost=$(echo "scale=4; ${MR_OPUS_COST} + ${MR_SONNET_COST} + ${MR_HAIKU_COST}" | bc 2>/dev/null | sed 's/^\./0./' || echo "0.00")
    else
        total_cost="N/A"
    fi
    printf "  %-12s  %-28s  %6d  \$%9s\n" "TOTAL" "" "$MR_TOTAL_CALLS" "$total_cost"

    local savings
    savings=$(mr_calculate_savings)
    if [[ "$savings" != "0.00" && "$savings" != "0" ]]; then
        echo ""
        echo -e "  ${GREEN:-}💰 全Opus使用比での節約額: \$${savings}${NC:-}"
    fi

    echo ""
}

# ============================================================
# Export routing data as JSON
# ============================================================
mr_export_json() {
    local output_file="${1:-${SESSION_LOG_DIR:-/tmp}/observatory/model_router_report.json}"

    local total_cost="0.00"
    if command -v bc &>/dev/null; then
        total_cost=$(echo "scale=4; ${MR_OPUS_COST} + ${MR_SONNET_COST} + ${MR_HAIKU_COST}" | bc 2>/dev/null | sed 's/^\./0./' || echo "0.00")
    fi

    {
        echo "{"
        echo "  \"version\": \"16.0\","
        echo "  \"session_id\": \"${MR_SESSION_ID}\","
        echo "  \"default_tier\": \"${MR_DEFAULT_TIER}\","
        echo "  \"total_calls\": ${MR_TOTAL_CALLS},"
        echo "  \"models\": {"
        echo "    \"frontier\": {\"model\": \"${MR_MODEL_NAMES[frontier]}\", \"calls\": ${MR_OPUS_CALLS}, \"cost\": \"${MR_OPUS_COST}\"},"
        echo "    \"balanced\": {\"model\": \"${MR_MODEL_NAMES[balanced]}\", \"calls\": ${MR_SONNET_CALLS}, \"cost\": \"${MR_SONNET_COST}\"},"
        echo "    \"economy\": {\"model\": \"${MR_MODEL_NAMES[economy]}\", \"calls\": ${MR_HAIKU_CALLS}, \"cost\": \"${MR_HAIKU_COST}\"}"
        echo "  },"
        echo "  \"total_cost\": \"${total_cost}\","
        echo "  \"savings\": \"$(mr_calculate_savings)\""
        echo "}"
    } > "$output_file" 2>/dev/null || true
}
