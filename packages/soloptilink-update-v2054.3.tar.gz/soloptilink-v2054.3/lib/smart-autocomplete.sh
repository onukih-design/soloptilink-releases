#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v411.0 - Smart Autocomplete Engine
# =============================================================================
# コンテキスト認識型コード補完エンジン。プロジェクト構造・パターン学習・
# 型情報を活用したインテリジェントな補完候補生成を実現する。
#
# Functions:
#   _sac_init               - 初期化
#   _sac_analyze_context    - コード位置コンテキスト分析
#   _sac_suggest_completion - 補完候補生成
#   _sac_learn_patterns     - プロジェクトパターン学習
#   _sac_report             - レポート出力
#   _sac_score              - モジュールスコア(0-100)
#
# All globals use the SAC_ prefix.
# =============================================================================

[[ -n "${_SMART_AUTOCOMPLETE_LOADED:-}" ]] && return 0
_SMART_AUTOCOMPLETE_LOADED=1

declare -g SAC_VERSION="411.0"
declare -g SAC_INITIALIZED=false
declare -g SAC_STORE_DIR=""
declare -g SAC_ANALYZE_COUNT=0
declare -g SAC_SUGGEST_COUNT=0
declare -g SAC_PATTERNS_LEARNED=0

declare -g -A _SAC_PATTERNS=()         # pattern_key → frequency
declare -g -A _SAC_IMPORTS=()          # module_name → "from:path"
declare -g -A _SAC_FUNCTIONS=()        # func_name → "params:return_type"
declare -g -A _SAC_TYPES=()            # type_name → "fields"
declare -g -A _SAC_COMPLETIONS=()      # prefix → "suggestion1,suggestion2,..."

# =============================================================================
_sac_init() {
    local project_dir="${PROJECT_DIR:-.}"
    SAC_STORE_DIR="${project_dir}/.soloptilink/smart-autocomplete"
    mkdir -p "${SAC_STORE_DIR}/patterns" "${SAC_STORE_DIR}/cache"

    # Pre-populate common completions
    _SAC_COMPLETIONS["use"]="useState,useEffect,useCallback,useMemo,useRef,useContext,useReducer"
    _SAC_COMPLETIONS["import"]="{ useState } from 'react',{ useEffect } from 'react',{ NextRequest, NextResponse } from 'next/server'"
    _SAC_COMPLETIONS["export"]="default function,function,const,type,interface"
    _SAC_COMPLETIONS["const"]="router = useRouter(),searchParams = useSearchParams(),pathname = usePathname()"
    _SAC_COMPLETIONS["async"]="function,() =>"
    _SAC_COMPLETIONS["try"]="{ } catch (error) { }"
    _SAC_COMPLETIONS["if"]="(!response.ok),(loading),(error),(data)"
    _SAC_COMPLETIONS["return"]="NextResponse.json(,<div className=,null"
    _SAC_COMPLETIONS["await"]="fetch(,prisma.,response.json()"
    _SAC_COMPLETIONS["prisma"]="user.findMany(,user.create(,user.update(,user.delete(,$transaction("
    _SAC_COMPLETIONS["z."]="string(),number(),boolean(),object({}),array(),enum([]),optional(),nullable()"
    _SAC_COMPLETIONS["router"]="push(,replace(,back(),refresh()"

    SAC_INITIALIZED=true
    return 0
}

# =============================================================================
# _sac_analyze_context - Analyze code context for intelligent completions
# =============================================================================
_sac_analyze_context() {
    local file_path="$1"
    local cursor_line="${2:-0}"
    local cursor_col="${3:-0}"

    [[ "$SAC_INITIALIZED" != "true" ]] && { echo "ERROR: SAC not initialized" >&2; return 1; }
    SAC_ANALYZE_COUNT=$((SAC_ANALYZE_COUNT + 1))

    local context_type="unknown"
    local scope="global"
    local current_token=""

    if [[ -f "$file_path" ]]; then
        local file_ext="${file_path##*.}"
        local line_content=""

        if [[ $cursor_line -gt 0 ]]; then
            line_content=$(sed -n "${cursor_line}p" "$file_path" 2>/dev/null)
        fi

        # Determine context type
        if echo "$line_content" | grep -q 'import '; then
            context_type="import"
        elif echo "$line_content" | grep -q 'export '; then
            context_type="export"
        elif echo "$line_content" | grep -q '<[A-Z]'; then
            context_type="jsx_element"
        elif echo "$line_content" | grep -q 'className='; then
            context_type="css_class"
        elif echo "$line_content" | grep -q 'prisma\.'; then
            context_type="prisma_query"
        elif echo "$line_content" | grep -q 'z\.'; then
            context_type="zod_schema"
        elif echo "$line_content" | grep -q 'fetch('; then
            context_type="api_call"
        elif echo "$line_content" | grep -q 'use[A-Z]'; then
            context_type="react_hook"
        elif echo "$line_content" | grep -q 'function \|const .* = '; then
            context_type="declaration"
        fi

        # Determine scope
        local func_context
        func_context=$(head -n "$cursor_line" "$file_path" 2>/dev/null | grep -c 'function \|=> {' || echo "0")
        local close_braces
        close_braces=$(head -n "$cursor_line" "$file_path" 2>/dev/null | grep -c '^}' || echo "0")
        if [[ $func_context -gt $close_braces ]]; then
            scope="function"
        fi

        # Extract current token (word before cursor)
        if [[ -n "$line_content" && $cursor_col -gt 0 ]]; then
            current_token=$(echo "${line_content:0:$cursor_col}" | grep -oE '[a-zA-Z_.]+$' | tail -1)
        fi

        # Detect file type patterns
        case "$file_ext" in
            tsx) context_type="${context_type:-react_component}" ;;
            ts)
                if echo "$file_path" | grep -q 'route\.\|api/'; then
                    context_type="${context_type:-api_route}"
                fi
                ;;
        esac
    fi

    cat <<CTXEOF
{"context_type":"${context_type}","scope":"${scope}","current_token":"${current_token}","file":"${file_path}","line":${cursor_line}}
CTXEOF
    return 0
}

# =============================================================================
# _sac_suggest_completion - Generate completion suggestions
# =============================================================================
_sac_suggest_completion() {
    local context_json="$1"
    local max_suggestions="${2:-5}"

    [[ "$SAC_INITIALIZED" != "true" ]] && { echo "ERROR: SAC not initialized" >&2; return 1; }
    SAC_SUGGEST_COUNT=$((SAC_SUGGEST_COUNT + 1))

    local context_type current_token scope
    context_type=$(echo "$context_json" | sed 's/.*"context_type":"\([^"]*\)".*/\1/')
    current_token=$(echo "$context_json" | sed 's/.*"current_token":"\([^"]*\)".*/\1/')
    scope=$(echo "$context_json" | sed 's/.*"scope":"\([^"]*\)".*/\1/')

    local suggestions=()

    # Check pre-populated completions first
    if [[ -n "$current_token" ]]; then
        local cached="${_SAC_COMPLETIONS[$current_token]:-}"
        if [[ -n "$cached" ]]; then
            IFS=',' read -ra cached_arr <<< "$cached"
            for s in "${cached_arr[@]}"; do
                suggestions+=("$s")
                [[ ${#suggestions[@]} -ge $max_suggestions ]] && break
            done
        fi
    fi

    # Context-specific suggestions
    if [[ ${#suggestions[@]} -lt $max_suggestions ]]; then
        case "$context_type" in
            react_hook)
                suggestions+=("useState(initialValue)" "useEffect(() => {}, [])" "useCallback(() => {}, [])")
                ;;
            jsx_element)
                suggestions+=("<Button onClick={handleClick}>" "<Input value={value} onChange={handleChange} />" "<Card className=\"p-4\">")
                ;;
            css_class)
                suggestions+=("flex items-center" "p-4 rounded-lg" "text-sm font-medium" "bg-white shadow-sm border")
                ;;
            prisma_query)
                suggestions+=("findMany({ where: {}, orderBy: { createdAt: 'desc' } })" "create({ data: {} })" "update({ where: { id }, data: {} })")
                ;;
            zod_schema)
                suggestions+=("object({ name: z.string().min(1) })" "string().email()" "number().int().positive()")
                ;;
            api_call)
                suggestions+=("'/api/endpoint', { method: 'POST', body: JSON.stringify(data) }" "await response.json()")
                ;;
            import)
                for mod_name in "${!_SAC_IMPORTS[@]}"; do
                    local from_path="${_SAC_IMPORTS[$mod_name]}"
                    suggestions+=("{ ${mod_name} } from '${from_path}'")
                    [[ ${#suggestions[@]} -ge $max_suggestions ]] && break
                done
                ;;
            api_route)
                suggestions+=("NextResponse.json({ data }, { status: 200 })" "request.json()" "NextResponse.json({ error: 'Not found' }, { status: 404 })")
                ;;
        esac
    fi

    # Learned pattern suggestions
    for pattern_key in "${!_SAC_PATTERNS[@]}"; do
        [[ ${#suggestions[@]} -ge $max_suggestions ]] && break
        if [[ "$pattern_key" == "${current_token}"* ]]; then
            suggestions+=("${pattern_key}")
        fi
    done

    # Output suggestions
    local i=0
    for s in "${suggestions[@]}"; do
        [[ $i -ge $max_suggestions ]] && break
        echo "$s"
        i=$((i + 1))
    done
    return 0
}

# =============================================================================
# _sac_learn_patterns - Learn patterns from project codebase
# =============================================================================
_sac_learn_patterns() {
    local project_dir="${1:-${PROJECT_DIR:-.}}"
    local max_files="${2:-50}"

    [[ "$SAC_INITIALIZED" != "true" ]] && { echo "ERROR: SAC not initialized" >&2; return 1; }

    local files_scanned=0

    # Learn import patterns
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        [[ $files_scanned -ge $max_files ]] && break

        # Extract imports
        while IFS= read -r import_line; do
            local module from_path
            module=$(echo "$import_line" | grep -oE '\{[^}]+\}' | tr -d '{}' | tr ',' '\n' | head -1 | xargs)
            from_path=$(echo "$import_line" | grep -oE "from '[^']+'" | sed "s/from '//;s/'//")
            if [[ -n "$module" && -n "$from_path" ]]; then
                _SAC_IMPORTS["$module"]="$from_path"
            fi
        done < <(grep "^import " "$file" 2>/dev/null)

        # Extract function declarations
        while IFS= read -r func_line; do
            local func_name
            func_name=$(echo "$func_line" | grep -oE '(function|const)\s+[a-zA-Z_]+' | awk '{print $2}')
            [[ -n "$func_name" ]] && _SAC_FUNCTIONS["$func_name"]="learned"
        done < <(grep -E '(export\s+)?(function|const)\s+[a-zA-Z_]+' "$file" 2>/dev/null | head -20)

        # Extract type/interface declarations
        while IFS= read -r type_line; do
            local type_name
            type_name=$(echo "$type_line" | grep -oE '(type|interface)\s+[A-Z][a-zA-Z]*' | awk '{print $2}')
            [[ -n "$type_name" ]] && _SAC_TYPES["$type_name"]="learned"
        done < <(grep -E '(export\s+)?(type|interface)\s+[A-Z]' "$file" 2>/dev/null | head -20)

        # Learn common token sequences
        while IFS= read -r line; do
            local tokens
            tokens=$(echo "$line" | grep -oE '[a-zA-Z]+' | head -3 | tr '\n' '.')
            [[ -n "$tokens" ]] && _SAC_PATTERNS["$tokens"]=$(( ${_SAC_PATTERNS[$tokens]:-0} + 1 ))
        done < <(grep -v '^\s*//' "$file" 2>/dev/null | grep -v '^\s*$' | head -30)

        files_scanned=$((files_scanned + 1))
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" \) -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null | head -$max_files)

    SAC_PATTERNS_LEARNED=$((SAC_PATTERNS_LEARNED + files_scanned))

    echo "{\"files_scanned\":${files_scanned},\"imports\":${#_SAC_IMPORTS[@]},\"functions\":${#_SAC_FUNCTIONS[@]},\"types\":${#_SAC_TYPES[@]},\"patterns\":${#_SAC_PATTERNS[@]}}"
    return 0
}

# =============================================================================
# Report / Score
# =============================================================================
_sac_report() {
    echo -e "\n  ${BOLD:-}=== Smart Autocomplete v${SAC_VERSION} ===${NC:-}"
    echo -e "  Contexts Analyzed : ${SAC_ANALYZE_COUNT}"
    echo -e "  Suggestions Made  : ${SAC_SUGGEST_COUNT}"
    echo -e "  Patterns Learned  : ${SAC_PATTERNS_LEARNED}"
    echo -e "  Known Imports     : ${#_SAC_IMPORTS[@]}"
    echo -e "  Known Functions   : ${#_SAC_FUNCTIONS[@]}"
    echo -e "  Known Types       : ${#_SAC_TYPES[@]}"
}

_sac_score() {
    local score=30
    [[ "$SAC_INITIALIZED" == "true" ]] && score=$((score + 20))
    [[ $SAC_PATTERNS_LEARNED -gt 0 ]] && score=$((score + 20))
    [[ $SAC_SUGGEST_COUNT -gt 0 ]] && score=$((score + 15))
    [[ ${#_SAC_IMPORTS[@]} -gt 5 ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "smart-autocomplete" \
        --version "411.0" \
        --description "コンテキスト認識型インテリジェントコード補完" \
        --init "_sac_init" \
        --report "_sac_report" \
        --score "_sac_score" \
        --enable-var "ENABLE_SAC" \
        --cli-flags "--smart-autocomplete:--no-smart-autocomplete"
fi

# v2003.1: source時のexit codeを確実に0にする
true
