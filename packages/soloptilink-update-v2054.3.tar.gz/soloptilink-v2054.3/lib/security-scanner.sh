#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v106.0 - Security Scanner
# 生成コードに対する実セキュリティ検査
#
# 問題: 生成されたコードに脆弱性が含まれていても
# ビルドは通る。依存関係の脆弱性、ハードコードされたシークレット、
# セキュリティヘッダー未設定は品質ゲートでは検出できない。
#
# 解決: npm audit / secret scan / header check を実行し、
# 具体的な修正プロンプトをOWASP参照付きで生成。
# ============================================================

[[ -n "${_SS_LOADED:-}" ]] && return 0
_SS_LOADED=1

SS_VERSION="106.0"
SS_INITIALIZED=false
SS_HAS_NPM_AUDIT=false
SS_HAS_SEMGREP=false

# Severity counts
SS_CRITICAL=0
SS_HIGH=0
SS_MEDIUM=0
SS_LOW=0
SS_INFO=0
SS_SECRETS_FOUND=0
SS_HEADER_ISSUES=0
SS_REPORT=""

# ============================================================
# Init: Detect available security tools
# ============================================================
ss_init() {
    SS_CRITICAL=0
    SS_HIGH=0
    SS_MEDIUM=0
    SS_LOW=0
    SS_INFO=0
    SS_SECRETS_FOUND=0
    SS_HEADER_ISSUES=0
    SS_REPORT=""

    if command -v npm &>/dev/null; then
        SS_HAS_NPM_AUDIT=true
    fi

    if command -v semgrep &>/dev/null; then
        SS_HAS_SEMGREP=true
    fi

    SS_INITIALIZED=true
    return 0
}

# ============================================================
# Dependency audit via npm audit
# ============================================================
ss_run_dependency_audit() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1
    [[ ! -f "${project_dir}/package.json" ]] && return 0

    local result=""
    local audit_output=""

    # Run npm audit and capture output
    if [[ "$SS_HAS_NPM_AUDIT" == "true" ]] && [[ -f "${project_dir}/package-lock.json" ]]; then
        audit_output=$(cd "$project_dir" && npm audit --json 2>/dev/null || true)

        if [[ -n "$audit_output" ]]; then
            # Parse severity counts without jq using grep/sed
            local crit high med low
            crit=$(echo "$audit_output" | grep -oE '"critical":[0-9]+' | head -1 | grep -oE '[0-9]+$' || echo "0")
            high=$(echo "$audit_output" | grep -oE '"high":[0-9]+' | head -1 | grep -oE '[0-9]+$' || echo "0")
            med=$(echo "$audit_output" | grep -oE '"moderate":[0-9]+' | head -1 | grep -oE '[0-9]+$' || echo "0")
            low=$(echo "$audit_output" | grep -oE '"low":[0-9]+' | head -1 | grep -oE '[0-9]+$' || echo "0")

            SS_CRITICAL=$((SS_CRITICAL + ${crit:-0}))
            SS_HIGH=$((SS_HIGH + ${high:-0}))
            SS_MEDIUM=$((SS_MEDIUM + ${med:-0}))
            SS_LOW=$((SS_LOW + ${low:-0}))

            result="npm audit: critical=${crit:-0} high=${high:-0} moderate=${med:-0} low=${low:-0}"
        else
            result="npm audit: no output (clean or no lock file)"
        fi
    else
        # Fallback: check package.json for known vulnerable patterns
        local pkg_content
        pkg_content=$(cat "${project_dir}/package.json" 2>/dev/null || true)

        # Check for packages with known severe vulnerabilities
        local vuln_pkgs=("event-stream" "ua-parser-js<0.7.30" "log4js<6.4.0" "minimist<1.2.6" "glob-parent<5.1.2" "trim-newlines<3.0.1" "node-fetch<2.6.7")
        for pkg in "${vuln_pkgs[@]}"; do
            local pkg_name="${pkg%%<*}"
            if echo "$pkg_content" | grep -q "\"${pkg_name}\"" 2>/dev/null; then
                SS_HIGH=$((SS_HIGH + 1))
            fi
        done
        result="npm audit: fallback check (npm not available or no lock file)"
    fi

    SS_REPORT+="[DEP_AUDIT] ${result}\n"
    return 0
}

# ============================================================
# Secret scan: find hardcoded credentials in source
# ============================================================
ss_run_secret_scan() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1

    local secrets_found=0
    local findings=""

    # Define patterns with descriptions
    # Format: "regex_pattern|description"
    local -a patterns=(
        'AKIA[0-9A-Z]{16}|AWS Access Key ID'
        '["\x27]sk-[a-zA-Z0-9]{20,}["\x27]|OpenAI/Stripe Secret Key'
        'AIza[0-9A-Za-z_-]{35}|Google API Key'
        'ghp_[a-zA-Z0-9]{36}|GitHub Personal Access Token'
        'xoxb-[0-9]{11,13}-[0-9]{11,13}-[a-zA-Z0-9]{24}|Slack Bot Token'
        'SG\.[a-zA-Z0-9_-]{22}\.[a-zA-Z0-9_-]{43}|SendGrid API Key'
        '["\x27]password["\x27]\s*[:=]\s*["\x27][^"\x27]{3,}["\x27]|Hardcoded Password'
        'PRIVATE[_ ]KEY.*BEGIN|Private Key in Source'
        'jdbc:.*password=|Database Connection String with Password'
        'mongodb(\+srv)?://[^/\s]+:[^@/\s]+@|MongoDB Connection URI with Credentials'
        'postgres(ql)?://[^/\s]+:[^@/\s]+@|PostgreSQL Connection URI with Credentials'
        'mysql://[^/\s]+:[^@/\s]+@|MySQL Connection URI with Credentials'
        'bearer\s+[a-zA-Z0-9_-]{20,}|Hardcoded Bearer Token'
        'JWT_SECRET\s*=\s*["\x27][^"\x27]{3,}["\x27]|Hardcoded JWT Secret'
        'DATABASE_URL\s*=\s*["\x27]postgres|Hardcoded Database URL'
    )

    # Scan .ts, .js, .tsx, .jsx, .env, .json files (exclude node_modules, .next, .git)
    local -a scan_files=()
    while IFS= read -r f; do
        scan_files+=("$f")
    done < <(find "$project_dir" \
        -type f \( -name "*.ts" -o -name "*.js" -o -name "*.tsx" -o -name "*.jsx" -o -name "*.env" -o -name "*.env.*" -o -name "*.json" \) \
        ! -path "*/node_modules/*" \
        ! -path "*/.next/*" \
        ! -path "*/.git/*" \
        ! -path "*/dist/*" \
        ! -path "*/*.test.*" \
        ! -path "*/__tests__/*" \
        2>/dev/null | head -500)

    for pattern_desc in "${patterns[@]}"; do
        local pattern="${pattern_desc%%|*}"
        local desc="${pattern_desc##*|}"

        for f in "${scan_files[@]}"; do
            [[ ! -f "$f" ]] && continue
            local matches
            matches=$(grep -nE "$pattern" "$f" 2>/dev/null | head -5)
            if [[ -n "$matches" ]]; then
                local rel_path="${f#$project_dir/}"
                # Skip .env.example and .env.sample
                [[ "$rel_path" == *.env.example ]] && continue
                [[ "$rel_path" == *.env.sample ]] && continue
                # Skip test/example files
                [[ "$rel_path" == *example* ]] && continue

                local match_count
                match_count=$(echo "$matches" | wc -l | tr -d ' ')
                secrets_found=$((secrets_found + match_count))
                findings+="  [SECRET] ${desc} in ${rel_path} (${match_count} occurrence(s))\n"

                # Each secret is critical severity
                SS_CRITICAL=$((SS_CRITICAL + match_count))
            fi
        done
    done

    SS_SECRETS_FOUND=$secrets_found

    if [[ $secrets_found -gt 0 ]]; then
        SS_REPORT+="[SECRET_SCAN] Found ${secrets_found} potential secret(s):\n${findings}"
    else
        SS_REPORT+="[SECRET_SCAN] No hardcoded secrets detected.\n"
    fi

    return 0
}

# ============================================================
# Header check: verify security headers configured
# ============================================================
ss_run_header_check() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1

    local issues=0
    local findings=""

    # Detect if Express/Next.js is used
    local has_express=false
    local has_nextjs=false

    if grep -rq "express\(\)" "$project_dir" --include="*.ts" --include="*.js" \
        --exclude-dir=node_modules --exclude-dir=.next 2>/dev/null; then
        has_express=true
    fi

    if [[ -f "${project_dir}/next.config.js" ]] || [[ -f "${project_dir}/next.config.mjs" ]] || [[ -f "${project_dir}/next.config.ts" ]]; then
        has_nextjs=true
    fi

    # Check helmet.js for Express
    if [[ "$has_express" == "true" ]]; then
        if ! grep -rq "helmet" "$project_dir" --include="*.ts" --include="*.js" \
            --exclude-dir=node_modules --exclude-dir=.next 2>/dev/null; then
            issues=$((issues + 1))
            findings+="  [HEADER] Express detected but helmet.js not configured (OWASP A05:2021)\n"
            SS_HIGH=$((SS_HIGH + 1))
        fi
    fi

    # Check CSP configuration
    local has_csp=false
    if grep -rqE "Content-Security-Policy|contentSecurityPolicy|CSP" "$project_dir" \
        --include="*.ts" --include="*.js" --include="*.mjs" \
        --exclude-dir=node_modules --exclude-dir=.next 2>/dev/null; then
        has_csp=true
    fi
    # Next.js headers config
    if [[ "$has_nextjs" == "true" ]]; then
        local next_config=""
        for cfg in next.config.js next.config.mjs next.config.ts; do
            [[ -f "${project_dir}/${cfg}" ]] && next_config="${project_dir}/${cfg}" && break
        done
        if [[ -n "$next_config" ]]; then
            if grep -q "Content-Security-Policy" "$next_config" 2>/dev/null; then
                has_csp=true
            fi
            if grep -q "headers" "$next_config" 2>/dev/null; then
                # Check for HSTS
                if ! grep -q "Strict-Transport-Security" "$next_config" 2>/dev/null; then
                    issues=$((issues + 1))
                    findings+="  [HEADER] HSTS not configured in next.config (OWASP A05:2021)\n"
                    SS_MEDIUM=$((SS_MEDIUM + 1))
                fi
                # Check for X-Frame-Options
                if ! grep -q "X-Frame-Options" "$next_config" 2>/dev/null; then
                    issues=$((issues + 1))
                    findings+="  [HEADER] X-Frame-Options not set (clickjacking risk)\n"
                    SS_MEDIUM=$((SS_MEDIUM + 1))
                fi
            else
                issues=$((issues + 1))
                findings+="  [HEADER] No security headers configured in next.config\n"
                SS_MEDIUM=$((SS_MEDIUM + 1))
            fi
        fi
    fi

    if [[ "$has_csp" == "false" ]] && { [[ "$has_express" == "true" ]] || [[ "$has_nextjs" == "true" ]]; }; then
        issues=$((issues + 1))
        findings+="  [HEADER] No Content-Security-Policy detected (OWASP A05:2021)\n"
        SS_HIGH=$((SS_HIGH + 1))
    fi

    # Check CORS configuration
    if grep -rqE "cors|Access-Control-Allow-Origin" "$project_dir" \
        --include="*.ts" --include="*.js" \
        --exclude-dir=node_modules --exclude-dir=.next 2>/dev/null; then
        # Check for wildcard CORS
        if grep -rqE "origin:\s*['\"]?\*['\"]?" "$project_dir" \
            --include="*.ts" --include="*.js" \
            --exclude-dir=node_modules --exclude-dir=.next 2>/dev/null; then
            issues=$((issues + 1))
            findings+="  [HEADER] CORS wildcard (*) origin detected - use explicit whitelist (OWASP A01:2021)\n"
            SS_HIGH=$((SS_HIGH + 1))
        fi
        if grep -rqE "Access-Control-Allow-Origin.*\*" "$project_dir" \
            --include="*.ts" --include="*.js" \
            --exclude-dir=node_modules --exclude-dir=.next 2>/dev/null; then
            issues=$((issues + 1))
            findings+="  [HEADER] Access-Control-Allow-Origin: * detected\n"
            SS_HIGH=$((SS_HIGH + 1))
        fi
    fi

    # Check rate limiting
    local has_rate_limit=false
    if grep -rqE "rate-limit|rateLimit|express-rate-limit|@nestjs/throttler" "$project_dir" \
        --include="*.ts" --include="*.js" \
        --exclude-dir=node_modules --exclude-dir=.next 2>/dev/null; then
        has_rate_limit=true
    fi
    if [[ "$has_rate_limit" == "false" ]] && { [[ "$has_express" == "true" ]] || [[ "$has_nextjs" == "true" ]]; }; then
        issues=$((issues + 1))
        findings+="  [HEADER] No rate limiting detected on API routes (OWASP A04:2021)\n"
        SS_MEDIUM=$((SS_MEDIUM + 1))
    fi

    SS_HEADER_ISSUES=$issues

    if [[ $issues -gt 0 ]]; then
        SS_REPORT+="[HEADER_CHECK] ${issues} issue(s):\n${findings}"
    else
        SS_REPORT+="[HEADER_CHECK] Security headers properly configured.\n"
    fi

    return 0
}

# ============================================================
# Main: run all security checks
# ============================================================
ss_run() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1
    [[ "$SS_INITIALIZED" != "true" ]] && ss_init

    SS_REPORT="=== Security Scanner v${SS_VERSION} Report ===\n"
    SS_REPORT+="Target: ${project_dir}\n"
    SS_REPORT+="Timestamp: $(date '+%Y-%m-%d %H:%M:%S')\n\n"

    ss_run_dependency_audit "$project_dir"
    ss_run_secret_scan "$project_dir"
    ss_run_header_check "$project_dir"

    # Semgrep if available
    if [[ "$SS_HAS_SEMGREP" == "true" ]]; then
        local semgrep_output
        semgrep_output=$(cd "$project_dir" && semgrep --config=auto --json --quiet 2>/dev/null | head -200 || true)
        if [[ -n "$semgrep_output" ]]; then
            local sg_errors
            sg_errors=$(echo "$semgrep_output" | grep -c '"severity":"ERROR"' 2>/dev/null || echo "0")
            local sg_warnings
            sg_warnings=$(echo "$semgrep_output" | grep -c '"severity":"WARNING"' 2>/dev/null || echo "0")
            SS_HIGH=$((SS_HIGH + ${sg_errors:-0}))
            SS_MEDIUM=$((SS_MEDIUM + ${sg_warnings:-0}))
            SS_REPORT+="[SEMGREP] errors=${sg_errors:-0} warnings=${sg_warnings:-0}\n"
        fi
    fi

    # Summary
    local score
    score=$(ss_score)
    SS_REPORT+="\n--- Summary ---\n"
    SS_REPORT+="Critical: ${SS_CRITICAL} | High: ${SS_HIGH} | Medium: ${SS_MEDIUM} | Low: ${SS_LOW}\n"
    SS_REPORT+="Secrets found: ${SS_SECRETS_FOUND}\n"
    SS_REPORT+="Header issues: ${SS_HEADER_ISSUES}\n"
    SS_REPORT+="Security Score: ${score}/100\n"

    echo -e "$SS_REPORT"
    return 0
}

# ============================================================
# Generate AI fix prompt from security findings
# ============================================================
ss_generate_fix_prompt() {
    local report="${1:-$SS_REPORT}"
    local prompt="Fix the following security issues found by automated scanning.\n"
    prompt+="Reference OWASP Top 10 2021 for each fix.\n\n"

    if [[ $SS_SECRETS_FOUND -gt 0 ]]; then
        prompt+="## CRITICAL: Hardcoded Secrets (OWASP A02:2021 - Cryptographic Failures)\n"
        prompt+="Move ALL secrets to environment variables (.env.local).\n"
        prompt+="Use process.env.VARIABLE_NAME instead of hardcoded values.\n"
        prompt+="Add .env* to .gitignore immediately.\n\n"
    fi

    if [[ $SS_HEADER_ISSUES -gt 0 ]]; then
        prompt+="## Security Headers (OWASP A05:2021 - Security Misconfiguration)\n"
        prompt+="Configure the following in next.config.js or middleware:\n"
        prompt+="- Content-Security-Policy: default-src 'self'; script-src 'self' 'unsafe-inline'\n"
        prompt+="- Strict-Transport-Security: max-age=31536000; includeSubDomains\n"
        prompt+="- X-Frame-Options: DENY\n"
        prompt+="- X-Content-Type-Options: nosniff\n"
        prompt+="- Referrer-Policy: strict-origin-when-cross-origin\n"
        prompt+="For Express: install and configure helmet.js\n"
        prompt+="For Next.js: add headers() to next.config.js\n\n"
    fi

    if [[ $SS_CRITICAL -gt 0 ]] || [[ $SS_HIGH -gt 0 ]]; then
        prompt+="## Dependency Vulnerabilities (OWASP A06:2021 - Vulnerable Components)\n"
        prompt+="Run: npm audit fix\n"
        prompt+="For breaking changes: npm audit fix --force (review changes)\n"
        prompt+="Replace severely vulnerable packages with alternatives.\n\n"
    fi

    if echo "$report" | grep -q "CORS wildcard" 2>/dev/null; then
        prompt+="## CORS Configuration (OWASP A01:2021 - Broken Access Control)\n"
        prompt+="Replace '*' with explicit origin whitelist:\n"
        prompt+="const allowedOrigins = [process.env.FRONTEND_URL];\n"
        prompt+="Validate Origin header against allowedOrigins array.\n\n"
    fi

    if echo "$report" | grep -q "rate limiting" 2>/dev/null; then
        prompt+="## Rate Limiting (OWASP A04:2021 - Insecure Design)\n"
        prompt+="Add rate limiting to all API endpoints.\n"
        prompt+="For Next.js: use middleware with token bucket algorithm.\n"
        prompt+="Recommended: 100 requests per minute per IP for general API,\n"
        prompt+="5 requests per minute for auth endpoints.\n\n"
    fi

    echo -e "$prompt"
}

# ============================================================
# Score: 100 minus weighted severity deductions
# ============================================================
ss_score() {
    local deduction=0
    deduction=$((SS_CRITICAL * 20 + SS_HIGH * 10 + SS_MEDIUM * 5 + SS_LOW * 1))

    local score=$((100 - deduction))
    if [[ $score -lt 0 ]]; then
        score=0
    fi
    echo "$score"
}

# ============================================================
# Report
# ============================================================
ss_report() {
    echo -e "\n  ${BOLD:-}=== Security Scanner v${SS_VERSION} ===${NC:-}"
    echo -e "  Critical: ${SS_CRITICAL} | High: ${SS_HIGH} | Medium: ${SS_MEDIUM} | Low: ${SS_LOW}"
    echo -e "  Secrets detected: ${SS_SECRETS_FOUND}"
    echo -e "  Header issues: ${SS_HEADER_ISSUES}"
    echo -e "  Score: $(ss_score)/100"
}

# ============================================================
# Module Registry self-registration
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "security-scanner" \
        --version "$SS_VERSION" \
        --description "実セキュリティスキャン - 依存関係/シークレット/ヘッダー検査" \
        --init "ss_init" \
        --report "ss_report" \
        --score "ss_score" \
        --enable-var "ENABLE_SS" \
        --cli-flags "--security-scanner:--no-security-scanner"
fi

# v2003.1: source時のexit codeを確実に0にする
true
