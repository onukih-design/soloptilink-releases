#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v260.0 - React Error Expert
# =============================================================================
# React固有のエラーパターンを専門的に解析・修正するエキスパートモジュール。
# 20+の一般的なReactエラーパターンと修正テンプレートのデータベースを内蔵。
#
# 対象エラー:
#   - React hydration errors
#   - Hook rule violations (conditional hooks, hooks in loops)
#   - Infinite render loops
#   - Missing/duplicate key errors
#   - "Cannot update during render" errors
#   - Event handler errors
#   - React ref errors
#   - Context errors
#   - Suspense/Error Boundary errors
#   - Component lifecycle errors
#
# Functions:
#   _ree_init                - 初期化・パターンDB構築
#   _ree_fix_hydration       - React hydration errors
#   _ree_fix_hook_rules      - Hook rule violations
#   _ree_fix_render_loop     - Infinite render loop
#   _ree_fix_key_error       - Missing/duplicate key errors
#   _ree_fix_state_update    - "Cannot update during render" errors
#   _ree_fix_event_handler   - Event handler errors
#   _ree_fix_ref_error       - React ref errors
#   _ree_classify            - Classify React error
#   _ree_get_fix_prompt      - Generate Claude prompt
#   _ree_report              - Report output
#   _ree_score               - Module score (0-100)
#
# All globals use the REE_ prefix.
# =============================================================================

[[ -n "${_REACT_ERROR_EXPERT_LOADED:-}" ]] && return 0
_REACT_ERROR_EXPERT_LOADED=1

# --- Colors ---
readonly _REE_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly _REE_YELLOW="${CLR_YELLOW:-\033[0;33m}"
readonly _REE_RED="${CLR_RED:-\033[0;31m}"
readonly _REE_BLUE="${CLR_BLUE:-\033[0;34m}"
readonly _REE_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly _REE_PURPLE="${CLR_PURPLE:-\033[0;35m}"
readonly _REE_BOLD="${CLR_BOLD:-\033[1m}"
readonly _REE_NC="${CLR_NC:-\033[0m}"

# --- Module State ---
REE_VERSION="260.0"
REE_INITIALIZED=false
REE_ENABLED="${REE_ENABLED:-true}"

# --- Counters ---
REE_TOTAL_ANALYZED=0
REE_TOTAL_FIXED=0
REE_TOTAL_PROMPTS=0
REE_FIX_SUCCESS=0
REE_FIX_FAIL=0
REE_HYDRATION_FIXED=0
REE_HOOK_FIXED=0
REE_LOOP_FIXED=0
REE_KEY_FIXED=0
REE_STATE_FIXED=0
REE_EVENT_FIXED=0
REE_REF_FIXED=0

# --- Storage ---
REE_STORE_DIR=""
REE_HISTORY_FILE=""

# --- Pattern Database ---
declare -g -a _REE_PATTERNS=()

# --- Error buffer ---
declare -g -a _REE_ERROR_MSGS=()
declare -g -a _REE_ERROR_FILES=()
declare -g -a _REE_ERROR_CATEGORIES=()

# =============================================================================
# Pattern Database - 24 common React error patterns
# =============================================================================
_ree_init_patterns() {
    _REE_PATTERNS=()

    # --- Hydration Errors ---
    _REE_PATTERNS+=("HYDRATION|Hydration failed because|hydration_mismatch|_ree_tmpl_hydration_mismatch|9|Hydration mismatch")
    _REE_PATTERNS+=("HYDRATION|There was an error while hydrating|hydration_error|_ree_tmpl_hydration_error|8|Hydration error")
    _REE_PATTERNS+=("HYDRATION|Text content does not match server|hydration_text|_ree_tmpl_hydration_text|7|Text content mismatch")

    # --- Hook Rule Violations ---
    _REE_PATTERNS+=("HOOKS|Invalid hook call|invalid_hook|_ree_tmpl_invalid_hook|10|Invalid hook call")
    _REE_PATTERNS+=("HOOKS|Rendered more hooks than during the previous render|hooks_count_changed|_ree_tmpl_hooks_count|9|Hook count changed")
    _REE_PATTERNS+=("HOOKS|React Hook .* is called conditionally|conditional_hook|_ree_tmpl_conditional_hook|9|Conditional hook call")
    _REE_PATTERNS+=("HOOKS|React Hook .* is called in a function|hook_in_function|_ree_tmpl_hook_in_function|8|Hook in non-component function")
    _REE_PATTERNS+=("HOOKS|useEffect.*missing dependency|missing_dep|_ree_tmpl_missing_dep|6|Missing useEffect dependency")

    # --- Render Loop Errors ---
    _REE_PATTERNS+=("RENDER|Too many re-renders|too_many_renders|_ree_tmpl_too_many_renders|10|Too many re-renders")
    _REE_PATTERNS+=("RENDER|Maximum update depth exceeded|max_depth|_ree_tmpl_max_depth|10|Maximum update depth exceeded")
    _REE_PATTERNS+=("RENDER|Infinite loop|infinite_loop|_ree_tmpl_infinite_loop|10|Infinite loop detected")

    # --- Key Errors ---
    _REE_PATTERNS+=("KEY|Each child in a list should have a unique|missing_key|_ree_tmpl_missing_key|6|Missing key prop")
    _REE_PATTERNS+=("KEY|Encountered two children with the same key|duplicate_key|_ree_tmpl_duplicate_key|6|Duplicate key")

    # --- State Update Errors ---
    _REE_PATTERNS+=("STATE|Cannot update a component .* while rendering|update_during_render|_ree_tmpl_update_during_render|9|Update during render")
    _REE_PATTERNS+=("STATE|Cannot update state on an unmounted component|unmounted_update|_ree_tmpl_unmounted_update|7|Update on unmounted component")
    _REE_PATTERNS+=("STATE|Cannot read property .* of undefined|undefined_state|_ree_tmpl_undefined_state|7|Accessing undefined state")

    # --- Event Handler Errors ---
    _REE_PATTERNS+=("EVENT|is not a function|handler_not_function|_ree_tmpl_handler_not_fn|7|Handler is not a function")
    _REE_PATTERNS+=("EVENT|Cannot read properties.*onClick|onclick_error|_ree_tmpl_onclick_error|6|onClick handler error")
    _REE_PATTERNS+=("EVENT|Expected.*handler.*is undefined|undefined_handler|_ree_tmpl_undefined_handler|7|Undefined event handler")

    # --- Ref Errors ---
    _REE_PATTERNS+=("REF|Cannot read properties of null.*useRef|ref_null|_ree_tmpl_ref_null|7|Ref is null")
    _REE_PATTERNS+=("REF|Ref is not assignable|ref_type|_ree_tmpl_ref_type|5|Ref type mismatch")
    _REE_PATTERNS+=("REF|forwardRef render functions|forward_ref|_ree_tmpl_forward_ref|6|forwardRef error")

    # --- Context Errors ---
    _REE_PATTERNS+=("CONTEXT|Cannot read properties of undefined.*useContext|context_undefined|_ree_tmpl_context_undef|8|Context is undefined")
    _REE_PATTERNS+=("CONTEXT|createContext|context_creation|_ree_tmpl_context_creation|5|Context creation error")
}

# =============================================================================
# Fix Template Functions
# =============================================================================

_ree_tmpl_hydration_mismatch() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for React Hydration Mismatch** (${file})
Server and client rendered different content.

Common Causes & Fixes:
1. **Browser-only values in initial render**:
   \`\`\`tsx
   // WRONG
   const [value, setValue] = useState(localStorage.getItem('key'));

   // RIGHT - use null initial, set in effect
   const [value, setValue] = useState<string | null>(null);
   useEffect(() => { setValue(localStorage.getItem('key')); }, []);
   \`\`\`

2. **Date/time-based rendering**:
   \`\`\`tsx
   // Use suppressHydrationWarning for timestamps
   <time suppressHydrationWarning>{new Date().toLocaleString()}</time>
   \`\`\`

3. **useIsClient pattern**:
   \`\`\`tsx
   function useIsClient() {
     const [isClient, setIsClient] = useState(false);
     useEffect(() => { setIsClient(true); }, []);
     return isClient;
   }
   // In component:
   const isClient = useIsClient();
   if (!isClient) return <Skeleton />;
   return <ClientContent />;
   \`\`\`

4. **Invalid HTML nesting** (\`<div>\` inside \`<p>\`, \`<a>\` inside \`<a>\`):
   Fix the JSX to produce valid HTML structure.

5. **Third-party scripts/extensions**: Use \`suppressHydrationWarning\` on body or affected elements.
FIX
}

_ree_tmpl_hydration_error() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for React Hydration Error** (${file})
1. Check for conditional rendering that differs between server and client
2. Ensure all useEffect-dependent UI shows a consistent initial state
3. Verify no browser APIs are called during render
4. Check for mismatched component tree structure
FIX
}

_ree_tmpl_hydration_text() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Text Content Mismatch** (${file})
Text rendered on server differs from client.
1. Avoid \`Math.random()\`, \`Date.now()\`, or locale-dependent formatting in render
2. Use \`useEffect\` for dynamic text that changes between server and client
3. Add \`suppressHydrationWarning\` to the element if the difference is expected
FIX
}

_ree_tmpl_invalid_hook() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Invalid Hook Call** (${file})
Hooks can only be called inside function components or custom hooks.

3 Most Common Causes:
1. **Mismatching React versions**: Check \`npm ls react react-dom\`
   Both must be the same version. Fix: \`npm install react@latest react-dom@latest\`

2. **Multiple copies of React**: Check \`npm ls react\`
   Should show only ONE version. Fix duplicate with npm dedup.

3. **Breaking the Rules of Hooks**: Hook is called outside a component:
   \`\`\`tsx
   // WRONG - not a component (lowercase or not in JSX context)
   function helper() { const [x, setX] = useState(0); }

   // RIGHT - component (uppercase, returns JSX)
   function Helper() { const [x, setX] = useState(0); return <div>{x}</div>; }
   \`\`\`
FIX
}

_ree_tmpl_hooks_count() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Hook Count Changed** (${file})
Different number of hooks were called between renders. This means a hook is
behind a conditional or early return.

\`\`\`tsx
// WRONG - hook after condition
function Component({ show }) {
  if (!show) return null;    // early return BEFORE hook
  const [val, setVal] = useState('');  // this hook is conditional!
  return <input value={val} />;
}

// RIGHT - all hooks before any early return
function Component({ show }) {
  const [val, setVal] = useState('');  // hook ALWAYS called
  if (!show) return null;              // early return AFTER hooks
  return <input value={val} />;
}
\`\`\`

Rules: ALL hooks must be called on EVERY render, in the SAME order.
FIX
}

_ree_tmpl_conditional_hook() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Conditional Hook Call** (${file})
A hook is inside an if/else, loop, or nested function.

\`\`\`tsx
// WRONG
if (condition) {
  useEffect(() => { /* ... */ }, []);
}

// RIGHT - always call the hook, guard inside
useEffect(() => {
  if (condition) { /* ... */ }
}, [condition]);
\`\`\`
FIX
}

_ree_tmpl_hook_in_function() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Hook in Non-Component Function** (${file})
Hooks can only be called in:
1. React function components (starting with uppercase)
2. Custom hooks (starting with \`use\`)

\`\`\`tsx
// WRONG - regular function
function getData() { return useQuery(...); }

// RIGHT - custom hook
function useGetData() { return useQuery(...); }
\`\`\`
FIX
}

_ree_tmpl_missing_dep() {
    local msg="$1" file="$2"
    local dep
    dep=$(echo "$msg" | grep -oP "'\\K[^']+(?=')" | head -1)
    cat <<FIX
**Fix for Missing useEffect Dependency** (${file})
Missing dependency: \`${dep}\`

Solutions:
1. **Add to dependency array**:
   \`\`\`tsx
   useEffect(() => { /* uses ${dep} */ }, [${dep}]);
   \`\`\`
2. **Wrap in useCallback** if it's a function:
   \`\`\`tsx
   const stableFn = useCallback(() => { /* ... */ }, [deps]);
   useEffect(() => { stableFn(); }, [stableFn]);
   \`\`\`
3. **Use useRef** for values you don't want to trigger re-runs:
   \`\`\`tsx
   const latestRef = useRef(${dep});
   latestRef.current = ${dep};
   useEffect(() => { /* use latestRef.current */ }, []);
   \`\`\`
4. **Intentionally omit** (add eslint-disable comment with explanation):
   \`\`\`tsx
   useEffect(() => { /* ... */ }, []); // eslint-disable-line react-hooks/exhaustive-deps
   \`\`\`
FIX
}

_ree_tmpl_too_many_renders() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Too Many Re-renders** (${file})
React limits renders to prevent infinite loops. A state update triggers render,
which triggers another state update, ad infinitum.

Most Common Causes:
1. **Calling setState in render body**:
   \`\`\`tsx
   // WRONG
   function Component() {
     const [count, setCount] = useState(0);
     setCount(count + 1);  // infinite loop!

     // RIGHT: move to useEffect or event handler
     useEffect(() => { setCount(c => c + 1); }, []);
   }
   \`\`\`

2. **Passing function call instead of reference**:
   \`\`\`tsx
   // WRONG - calls handleClick immediately on render
   <button onClick={handleClick()}>Click</button>

   // RIGHT - passes reference
   <button onClick={handleClick}>Click</button>
   <button onClick={() => handleClick(arg)}>Click</button>
   \`\`\`

3. **Object/array in useEffect dependency**:
   \`\`\`tsx
   // WRONG - new object every render triggers effect
   useEffect(() => { fetch(url) }, [{ page: 1 }]);

   // RIGHT - use primitive or useMemo
   const params = useMemo(() => ({ page: 1 }), []);
   useEffect(() => { fetch(url) }, [params]);
   \`\`\`
FIX
}

_ree_tmpl_max_depth() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Maximum Update Depth Exceeded** (${file})
Same root cause as "Too many re-renders": circular state updates.

Check for:
1. useEffect that sets state that triggers itself
2. Parent-child setState loops (parent passes callback, child calls it in effect)
3. useEffect with object dependencies recreated every render

Debugging: Add console.log at the start of your component to see how many
times it renders. Then trace which setState causes the re-render.
FIX
}

_ree_tmpl_infinite_loop() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Infinite Loop** (${file})
1. Check all useEffect dependencies for object/array references
2. Use useMemo/useCallback to stabilize references
3. Avoid setState in the render path
4. Use functional state updates: \`setState(prev => prev + 1)\`
FIX
}

_ree_tmpl_missing_key() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Missing Key Prop** (${file})
Each item in a list needs a unique \`key\` prop.

\`\`\`tsx
// WRONG
{items.map(item => <div>{item.name}</div>)}

// RIGHT - use unique identifier
{items.map(item => <div key={item.id}>{item.name}</div>)}

// ACCEPTABLE if no ID - use index (but not recommended for reorderable lists)
{items.map((item, index) => <div key={index}>{item.name}</div>)}
\`\`\`

Key rules:
- Keys must be unique among siblings (not globally)
- Keys must be stable (don't use Math.random())
- Use database IDs or other stable unique identifiers
- Index keys are OK for static lists that never reorder
FIX
}

_ree_tmpl_duplicate_key() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Duplicate Key** (${file})
Two children have the same key. Keys must be unique among siblings.

Solutions:
1. Use a truly unique identifier (database ID, UUID)
2. If items can repeat, combine with index: \`key={\`\${item.id}-\${index}\`}\`
3. Check for duplicate data in the source array
4. Use a compound key from multiple fields if no single unique field exists
FIX
}

_ree_tmpl_update_during_render() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Cannot Update During Render** (${file})
A component is calling setState on another component during rendering.

\`\`\`tsx
// WRONG - parent calls child's setState during render
function Parent() {
  return <Child onChange={(val) => setParentState(val)} />;
}
function Child({ onChange }) {
  const val = computeValue();
  onChange(val);  // calling parent setState during Child render!
  return <div>{val}</div>;
}

// RIGHT - use useEffect
function Child({ onChange }) {
  const val = computeValue();
  useEffect(() => { onChange(val); }, [val, onChange]);
  return <div>{val}</div>;
}
\`\`\`
FIX
}

_ree_tmpl_unmounted_update() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Update on Unmounted Component** (${file})
A state update was attempted after the component unmounted (e.g., async callback).

\`\`\`tsx
useEffect(() => {
  let cancelled = false;

  async function fetchData() {
    const result = await api.getData();
    if (!cancelled) {
      setData(result);  // only update if still mounted
    }
  }

  fetchData();
  return () => { cancelled = true; };  // cleanup on unmount
}, []);
\`\`\`

Or use AbortController:
\`\`\`tsx
useEffect(() => {
  const controller = new AbortController();
  fetch(url, { signal: controller.signal })
    .then(res => res.json())
    .then(setData)
    .catch(err => { if (err.name !== 'AbortError') throw err; });
  return () => controller.abort();
}, [url]);
\`\`\`
FIX
}

_ree_tmpl_undefined_state() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Accessing Undefined State** (${file})
State is undefined, likely not initialized or wrong destructuring.

1. Check initial state: \`useState(defaultValue)\` not \`useState()\`
2. Check object destructuring matches state shape
3. Add null checks: \`state?.property\`
4. Verify async data is loaded before accessing
FIX
}

_ree_tmpl_handler_not_fn() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Handler Not a Function** (${file})
The event handler is not a function.

Common causes:
1. **Typo in handler name**: Check spelling of the handler function
2. **Handler not passed as prop**: Verify parent passes the callback
3. **Destructuring error**: \`const { onClick } = props\` - verify prop name
4. **Arrow function syntax**: \`onClick={() => doSomething()}\` not \`onClick={doSomething()}\`
FIX
}

_ree_tmpl_onclick_error() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for onClick Error** (${file})
The onClick handler or its context is undefined.

1. Verify the handler function exists and is in scope
2. Check if \`this\` binding is needed (class components)
3. Ensure the handler is a function reference, not a function call
4. If passed as prop, verify the parent provides it
FIX
}

_ree_tmpl_undefined_handler() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Undefined Event Handler** (${file})
1. Declare the handler before using it in JSX
2. If from props: add a default or null check
   \`\`\`tsx
   <button onClick={onSubmit ?? (() => {})}>Submit</button>
   \`\`\`
3. If from a custom hook: verify the hook returns the handler
FIX
}

_ree_tmpl_ref_null() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Null Ref** (${file})
\`ref.current\` is null because the DOM element hasn't mounted yet.

\`\`\`tsx
// WRONG - accessing ref during render
function Component() {
  const ref = useRef<HTMLDivElement>(null);
  console.log(ref.current.offsetWidth);  // null during first render!

  // RIGHT - access in useEffect (after mount)
  useEffect(() => {
    if (ref.current) {
      console.log(ref.current.offsetWidth);
    }
  }, []);

  return <div ref={ref}>Content</div>;
}
\`\`\`

Rules:
- Ref is null until after the component mounts
- Always check \`ref.current !== null\` before accessing
- Use callback refs for more control: \`ref={(node) => { if (node) { ... } }}\`
FIX
}

_ree_tmpl_ref_type() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Ref Type Mismatch** (${file})
The ref type doesn't match the element it's attached to.

\`\`\`tsx
// Match the ref type to the element
const divRef = useRef<HTMLDivElement>(null);
const inputRef = useRef<HTMLInputElement>(null);
const buttonRef = useRef<HTMLButtonElement>(null);

// For component refs:
const componentRef = useRef<ComponentHandle>(null);
\`\`\`
FIX
}

_ree_tmpl_forward_ref() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for forwardRef Error** (${file})
Components that accept a ref prop need forwardRef:

\`\`\`tsx
// React 18 with forwardRef:
const MyInput = forwardRef<HTMLInputElement, Props>((props, ref) => {
  return <input ref={ref} {...props} />;
});

// React 19+ (ref as regular prop):
function MyInput({ ref, ...props }: Props & { ref?: React.Ref<HTMLInputElement> }) {
  return <input ref={ref} {...props} />;
}
\`\`\`
FIX
}

_ree_tmpl_context_undef() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Undefined Context** (${file})
\`useContext\` returned undefined because the component is not wrapped in the Provider.

\`\`\`tsx
// 1. Create context with default value
const MyContext = createContext<ContextType | null>(null);

// 2. Create a safe hook
function useMyContext() {
  const context = useContext(MyContext);
  if (!context) {
    throw new Error('useMyContext must be used within MyProvider');
  }
  return context;
}

// 3. Wrap your component tree
function App() {
  return (
    <MyProvider>
      <ComponentThatUsesContext />
    </MyProvider>
  );
}
\`\`\`

Common mistake: Provider is in a layout but the component renders outside that layout.
FIX
}

_ree_tmpl_context_creation() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Context Creation Error** (${file})
Ensure createContext is called at module scope (top level), not inside a component.
\`\`\`tsx
// RIGHT - module scope
const ThemeContext = createContext<'light' | 'dark'>('light');

// WRONG - inside component (creates new context every render)
function App() { const Ctx = createContext('light'); }
\`\`\`
FIX
}

# =============================================================================
# _ree_init - Initialize module
# =============================================================================
_ree_init() {
    [[ "$REE_ENABLED" != "true" ]] && return 0

    REE_STORE_DIR="${HOME}/.soloptilink/react-errors"
    mkdir -p "$REE_STORE_DIR" 2>/dev/null || true
    REE_HISTORY_FILE="${REE_STORE_DIR}/fix_history.jsonl"

    REE_TOTAL_ANALYZED=0
    REE_TOTAL_FIXED=0
    REE_TOTAL_PROMPTS=0
    REE_FIX_SUCCESS=0
    REE_FIX_FAIL=0
    REE_HYDRATION_FIXED=0
    REE_HOOK_FIXED=0
    REE_LOOP_FIXED=0
    REE_KEY_FIXED=0
    REE_STATE_FIXED=0
    REE_EVENT_FIXED=0
    REE_REF_FIXED=0

    _REE_ERROR_MSGS=()
    _REE_ERROR_FILES=()
    _REE_ERROR_CATEGORIES=()

    _ree_init_patterns

    REE_INITIALIZED=true
    echo -e "  ${_REE_GREEN}[REE]${_REE_NC} React Error Expert v${REE_VERSION} initialized (${#_REE_PATTERNS[@]} patterns)" >&2
    return 0
}

# =============================================================================
# _ree_classify - Classify a React error
# Returns: "code|category|severity|pattern_index"
# =============================================================================
_ree_classify() {
    local error_msg="${1:-}"
    [[ -z "$error_msg" ]] && echo "unknown|unknown|0|-1" && return 0

    local i=0
    for pattern_def in "${_REE_PATTERNS[@]}"; do
        local IFS='|'
        local parts=($pattern_def)
        unset IFS

        local regex="${parts[1]}"
        local category="${parts[2]}"
        local severity="${parts[4]}"
        local code="${parts[0]}"

        if echo "$error_msg" | grep -qiE "$regex" 2>/dev/null; then
            echo "${code}|${category}|${severity}|${i}"
            return 0
        fi
        i=$((i + 1))
    done

    echo "unknown|unknown|3|-1"
}

# =============================================================================
# _ree_fix_hydration - Fix React hydration errors
# =============================================================================
_ree_fix_hydration() {
    local error_msg="${1:-}"
    local file="${2:-}"

    REE_TOTAL_ANALYZED=$((REE_TOTAL_ANALYZED + 1))
    echo -e "  ${_REE_CYAN}[REE]${_REE_NC} Fixing hydration error: ${error_msg:0:80}" >&2

    if echo "$error_msg" | grep -qi "Text content" 2>/dev/null; then
        _ree_tmpl_hydration_text "$error_msg" "$file"
    else
        _ree_tmpl_hydration_mismatch "$error_msg" "$file"
    fi

    REE_TOTAL_FIXED=$((REE_TOTAL_FIXED + 1))
    REE_HYDRATION_FIXED=$((REE_HYDRATION_FIXED + 1))
}

# =============================================================================
# _ree_fix_hook_rules - Fix React hook rule violations
# =============================================================================
_ree_fix_hook_rules() {
    local error_msg="${1:-}"
    local file="${2:-}"

    REE_TOTAL_ANALYZED=$((REE_TOTAL_ANALYZED + 1))
    echo -e "  ${_REE_CYAN}[REE]${_REE_NC} Fixing hook rule violation: ${error_msg:0:80}" >&2

    if echo "$error_msg" | grep -qi "Invalid hook call" 2>/dev/null; then
        _ree_tmpl_invalid_hook "$error_msg" "$file"
    elif echo "$error_msg" | grep -qi "Rendered more hooks" 2>/dev/null; then
        _ree_tmpl_hooks_count "$error_msg" "$file"
    elif echo "$error_msg" | grep -qi "called conditionally" 2>/dev/null; then
        _ree_tmpl_conditional_hook "$error_msg" "$file"
    elif echo "$error_msg" | grep -qi "missing dependency" 2>/dev/null; then
        _ree_tmpl_missing_dep "$error_msg" "$file"
    else
        _ree_tmpl_hook_in_function "$error_msg" "$file"
    fi

    REE_TOTAL_FIXED=$((REE_TOTAL_FIXED + 1))
    REE_HOOK_FIXED=$((REE_HOOK_FIXED + 1))
}

# =============================================================================
# _ree_fix_render_loop - Fix infinite render loop
# =============================================================================
_ree_fix_render_loop() {
    local error_msg="${1:-}"
    local file="${2:-}"

    REE_TOTAL_ANALYZED=$((REE_TOTAL_ANALYZED + 1))
    echo -e "  ${_REE_CYAN}[REE]${_REE_NC} Fixing render loop: ${error_msg:0:80}" >&2

    if echo "$error_msg" | grep -qi "Maximum update depth" 2>/dev/null; then
        _ree_tmpl_max_depth "$error_msg" "$file"
    else
        _ree_tmpl_too_many_renders "$error_msg" "$file"
    fi

    REE_TOTAL_FIXED=$((REE_TOTAL_FIXED + 1))
    REE_LOOP_FIXED=$((REE_LOOP_FIXED + 1))
}

# =============================================================================
# _ree_fix_key_error - Fix missing/duplicate key errors
# =============================================================================
_ree_fix_key_error() {
    local error_msg="${1:-}"
    local file="${2:-}"

    REE_TOTAL_ANALYZED=$((REE_TOTAL_ANALYZED + 1))
    echo -e "  ${_REE_CYAN}[REE]${_REE_NC} Fixing key error: ${error_msg:0:80}" >&2

    if echo "$error_msg" | grep -qi "same key" 2>/dev/null; then
        _ree_tmpl_duplicate_key "$error_msg" "$file"
    else
        _ree_tmpl_missing_key "$error_msg" "$file"
    fi

    REE_TOTAL_FIXED=$((REE_TOTAL_FIXED + 1))
    REE_KEY_FIXED=$((REE_KEY_FIXED + 1))
}

# =============================================================================
# _ree_fix_state_update - Fix "Cannot update during render" errors
# =============================================================================
_ree_fix_state_update() {
    local error_msg="${1:-}"
    local file="${2:-}"

    REE_TOTAL_ANALYZED=$((REE_TOTAL_ANALYZED + 1))
    echo -e "  ${_REE_CYAN}[REE]${_REE_NC} Fixing state update error: ${error_msg:0:80}" >&2

    if echo "$error_msg" | grep -qi "unmounted" 2>/dev/null; then
        _ree_tmpl_unmounted_update "$error_msg" "$file"
    elif echo "$error_msg" | grep -qi "while rendering" 2>/dev/null; then
        _ree_tmpl_update_during_render "$error_msg" "$file"
    else
        _ree_tmpl_undefined_state "$error_msg" "$file"
    fi

    REE_TOTAL_FIXED=$((REE_TOTAL_FIXED + 1))
    REE_STATE_FIXED=$((REE_STATE_FIXED + 1))
}

# =============================================================================
# _ree_fix_event_handler - Fix event handler errors
# =============================================================================
_ree_fix_event_handler() {
    local error_msg="${1:-}"
    local file="${2:-}"

    REE_TOTAL_ANALYZED=$((REE_TOTAL_ANALYZED + 1))
    echo -e "  ${_REE_CYAN}[REE]${_REE_NC} Fixing event handler error: ${error_msg:0:80}" >&2

    if echo "$error_msg" | grep -qi "onClick" 2>/dev/null; then
        _ree_tmpl_onclick_error "$error_msg" "$file"
    elif echo "$error_msg" | grep -qi "is not a function" 2>/dev/null; then
        _ree_tmpl_handler_not_fn "$error_msg" "$file"
    else
        _ree_tmpl_undefined_handler "$error_msg" "$file"
    fi

    REE_TOTAL_FIXED=$((REE_TOTAL_FIXED + 1))
    REE_EVENT_FIXED=$((REE_EVENT_FIXED + 1))
}

# =============================================================================
# _ree_fix_ref_error - Fix React ref errors
# =============================================================================
_ree_fix_ref_error() {
    local error_msg="${1:-}"
    local file="${2:-}"

    REE_TOTAL_ANALYZED=$((REE_TOTAL_ANALYZED + 1))
    echo -e "  ${_REE_CYAN}[REE]${_REE_NC} Fixing ref error: ${error_msg:0:80}" >&2

    if echo "$error_msg" | grep -qi "forwardRef" 2>/dev/null; then
        _ree_tmpl_forward_ref "$error_msg" "$file"
    elif echo "$error_msg" | grep -qi "assignable" 2>/dev/null; then
        _ree_tmpl_ref_type "$error_msg" "$file"
    else
        _ree_tmpl_ref_null "$error_msg" "$file"
    fi

    REE_TOTAL_FIXED=$((REE_TOTAL_FIXED + 1))
    REE_REF_FIXED=$((REE_REF_FIXED + 1))
}

# =============================================================================
# _ree_get_fix_prompt - Generate Claude prompt with React context
# =============================================================================
_ree_get_fix_prompt() {
    local error_msg="${1:-}"
    local file="${2:-}"
    local file_content="${3:-}"

    REE_TOTAL_PROMPTS=$((REE_TOTAL_PROMPTS + 1))

    local classification
    classification=$(_ree_classify "$error_msg")
    local code category severity pattern_idx
    code=$(echo "$classification" | cut -d'|' -f1)
    category=$(echo "$classification" | cut -d'|' -f2)
    severity=$(echo "$classification" | cut -d'|' -f3)
    pattern_idx=$(echo "$classification" | cut -d'|' -f4)

    local fix_guidance=""
    if [[ "$pattern_idx" -ge 0 ]] && [[ "$pattern_idx" -lt ${#_REE_PATTERNS[@]} ]]; then
        local pattern_def="${_REE_PATTERNS[$pattern_idx]}"
        local IFS='|'
        local parts=($pattern_def)
        unset IFS
        local fix_fn="${parts[3]}"
        if type -t "$fix_fn" &>/dev/null; then
            fix_guidance=$($fix_fn "$error_msg" "$file")
        fi
    fi

    cat <<PROMPT
## React Error Fix Request

### Error Details
- **Category**: ${code} - ${category}
- **Severity**: ${severity}/10
- **File**: ${file}
- **Message**: ${error_msg}

### Expert Fix Guidance
${fix_guidance}

### Component Code
\`\`\`tsx
${file_content}
\`\`\`

### Instructions
1. Fix the React error described above
2. Follow the Rules of Hooks strictly
3. Avoid unnecessary re-renders (use useMemo, useCallback where appropriate)
4. Ensure proper cleanup in useEffect return functions
5. Use TypeScript types for all props and state
6. After fix: verify no console warnings remain
PROMPT
}

# =============================================================================
# _ree_analyze_batch - Analyze batch of React errors
# =============================================================================
_ree_analyze_batch() {
    local output="${1:-}"
    [[ -z "$output" ]] && return 0

    local count=0
    while IFS= read -r line; do
        local classification
        classification=$(_ree_classify "$line")
        local category
        category=$(echo "$classification" | cut -d'|' -f2)
        if [[ "$category" != "unknown" ]]; then
            _REE_ERROR_MSGS+=("$line")
            _REE_ERROR_CATEGORIES+=("$category")
            count=$((count + 1))
        fi
    done <<< "$output"

    REE_TOTAL_ANALYZED=$((REE_TOTAL_ANALYZED + count))
    echo -e "  ${_REE_BLUE}[REE]${_REE_NC} Analyzed ${count} React errors" >&2
    echo "$count"
}

# =============================================================================
# _ree_log_fix
# =============================================================================
_ree_log_fix() {
    local category="$1" file="$2" success="$3"
    [[ -z "$REE_HISTORY_FILE" ]] && return 0

    local timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    echo "{\"timestamp\":\"${timestamp}\",\"category\":\"${category}\",\"file\":\"${file}\",\"success\":${success}}" >> "$REE_HISTORY_FILE" 2>/dev/null || true

    if [[ "$success" == "true" ]]; then
        REE_FIX_SUCCESS=$((REE_FIX_SUCCESS + 1))
    else
        REE_FIX_FAIL=$((REE_FIX_FAIL + 1))
    fi
}

# =============================================================================
# _ree_report
# =============================================================================
_ree_report() {
    echo -e "\n  ${_REE_BOLD}=== React Error Expert v${REE_VERSION} Report ===${_REE_NC}"
    echo -e "  Patterns loaded      : ${#_REE_PATTERNS[@]}"
    echo -e "  Errors analyzed      : ${REE_TOTAL_ANALYZED}"
    echo -e "  Fixes generated      : ${REE_TOTAL_FIXED}"
    echo -e "  Fix prompts          : ${REE_TOTAL_PROMPTS}"
    echo -e "  Fix success          : ${REE_FIX_SUCCESS}"
    echo -e "  Fix failures         : ${REE_FIX_FAIL}"
    echo -e "  ${_REE_BOLD}By Category:${_REE_NC}"
    echo -e "    Hydration          : ${REE_HYDRATION_FIXED}"
    echo -e "    Hook rules         : ${REE_HOOK_FIXED}"
    echo -e "    Render loops       : ${REE_LOOP_FIXED}"
    echo -e "    Key errors         : ${REE_KEY_FIXED}"
    echo -e "    State updates      : ${REE_STATE_FIXED}"
    echo -e "    Event handlers     : ${REE_EVENT_FIXED}"
    echo -e "    Ref errors         : ${REE_REF_FIXED}"
}

# =============================================================================
# _ree_score
# =============================================================================
_ree_score() {
    local score=50
    [[ ${#_REE_PATTERNS[@]} -ge 20 ]] && score=$((score + 10))
    [[ $REE_TOTAL_ANALYZED -gt 0 ]] && score=$((score + 10))
    [[ $REE_TOTAL_FIXED -gt 0 ]] && score=$((score + 10))
    if [[ $((REE_FIX_SUCCESS + REE_FIX_FAIL)) -gt 0 ]]; then
        local rate=$((REE_FIX_SUCCESS * 100 / (REE_FIX_SUCCESS + REE_FIX_FAIL)))
        [[ $rate -ge 70 ]] && score=$((score + 20))
    fi
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# _ree_init_message
# =============================================================================
_ree_init_message() {
    echo -e "  ${_REE_GREEN}v${REE_VERSION}${_REE_NC} React Error Expert: ${#_REE_PATTERNS[@]} error patterns, hooks/render/state/ref fix" >&2
}

# =============================================================================
# Module Registry Registration
# =============================================================================
_mr_register \
    --name "react-error-expert" \
    --version "${REE_VERSION}" \
    --description "React専門エラー解析・修正（24パターン、hooks/render loop/state/ref対応）" \
    --init "_ree_init" \
    --report "_ree_report" \
    --score "_ree_score" \
    --enable-var "REE_ENABLED" \
    --cli-flags "--react-error-expert:--no-react-error-expert" \
    --init-msg "_ree_init_message"
