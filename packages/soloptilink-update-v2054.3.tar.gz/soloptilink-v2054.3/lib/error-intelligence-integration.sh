#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v280.0 - Error Intelligence Integration
# =============================================================================
# v251-v279の全Error Intelligenceモジュールを統合する統合レイヤー。
# マスターエラーハンドラ、エラーコンテキスト収集、Healer注入、
# 包括的レポート生成を提供する。
#
# Functions:
#   _eii_init             - 全Error Intelligenceモジュールの初期化
#   _eii_handle_error     - マスターエラーハンドラ: 分類→解析→修正→検証
#   _eii_get_error_context - エラーの完全コンテキスト取得
#   _eii_inject_into_healer - healer.shへのError Intelligence注入
#   _eii_report           - 包括的Error Intelligenceレポート
#   _eii_score            - 統合スコア算出(0-100)
#
# All globals use the EII_ prefix.
# =============================================================================

[[ -n "${_ERROR_INTELLIGENCE_INTEGRATION_LOADED:-}" ]] && return 0
_ERROR_INTELLIGENCE_INTEGRATION_LOADED=1

EII_VERSION="280.0"
EII_INITIALIZED=false
ENABLE_EII="${ENABLE_EII:-true}"

# Counters
EII_ERRORS_HANDLED=0
EII_ERRORS_RESOLVED=0
EII_ERRORS_ESCALATED=0
EII_CONTEXTS_BUILT=0
EII_HEALER_INJECTIONS=0
EII_REPORTS_GENERATED=0

# Module integration status
declare -g -A _EII_MODULE_STATUS=()

# Supported modules (v271-v279)
declare -g -a _EII_MODULES=(
    "smart-diff-analyzer"
    "compile-time-safety-net"
    "runtime-safety-net"
    "deployment-error-resolver"
    "database-deadlock-resolver"
    "memory-leak-detector"
    "infinite-loop-detector"
    "error-knowledge-base"
    "self-healing-system"
)

# Module init functions
declare -g -A _EII_MODULE_INIT=(
    ["smart-diff-analyzer"]="_sda_init"
    ["compile-time-safety-net"]="_ctsn_init"
    ["runtime-safety-net"]="_rsn_init"
    ["deployment-error-resolver"]="_der_init"
    ["database-deadlock-resolver"]="_ddr_init"
    ["memory-leak-detector"]="_mld_init"
    ["infinite-loop-detector"]="_ild_init"
    ["error-knowledge-base"]="_ekb_init"
    ["self-healing-system"]="_shs_init"
)

# Module scan/analyze functions
declare -g -A _EII_MODULE_SCAN=(
    ["smart-diff-analyzer"]="_sda_analyze_diff"
    ["memory-leak-detector"]="_mld_scan_all"
    ["infinite-loop-detector"]="_ild_scan_all"
    ["database-deadlock-resolver"]="_ddr_detect_deadlock_risk"
)

# Error category to module routing
declare -g -A _EII_CATEGORY_ROUTER=(
    ["typescript"]="compile-time-safety-net"
    ["eslint"]="compile-time-safety-net"
    ["runtime"]="runtime-safety-net"
    ["deployment"]="deployment-error-resolver"
    ["vercel"]="deployment-error-resolver"
    ["docker"]="deployment-error-resolver"
    ["aws"]="deployment-error-resolver"
    ["deadlock"]="database-deadlock-resolver"
    ["transaction"]="database-deadlock-resolver"
    ["memory"]="memory-leak-detector"
    ["leak"]="memory-leak-detector"
    ["loop"]="infinite-loop-detector"
    ["recursion"]="infinite-loop-detector"
    ["import"]="self-healing-system"
    ["build"]="self-healing-system"
    ["test"]="self-healing-system"
    ["prisma"]="self-healing-system"
)

# Storage
EII_WORK_DIR=""
declare -g -a _EII_HANDLED_ERRORS=()
declare -g -a _EII_RESOLUTION_LOG=()

# =============================================================================
# _eii_init - Initialize all error intelligence modules
# =============================================================================
_eii_init() {
    EII_WORK_DIR="${HOME}/.soloptilink/error-intelligence"
    mkdir -p "$EII_WORK_DIR" 2>/dev/null || true

    EII_ERRORS_HANDLED=0
    EII_ERRORS_RESOLVED=0
    EII_ERRORS_ESCALATED=0
    EII_CONTEXTS_BUILT=0
    EII_HEALER_INJECTIONS=0
    EII_REPORTS_GENERATED=0
    _EII_MODULE_STATUS=()
    _EII_HANDLED_ERRORS=()
    _EII_RESOLUTION_LOG=()

    echo -e "  ${CYAN:-}[EII] Initializing Error Intelligence Integration v280.0...${NC:-}" >&2

    # Initialize each module
    local init_success=0
    local init_fail=0

    for module in "${_EII_MODULES[@]}"; do
        local init_fn="${_EII_MODULE_INIT[$module]:-}"
        if [[ -n "$init_fn" ]] && type -t "$init_fn" &>/dev/null; then
            if $init_fn 2>/dev/null; then
                _EII_MODULE_STATUS["$module"]="active"
                init_success=$((init_success + 1))
            else
                _EII_MODULE_STATUS["$module"]="error"
                init_fail=$((init_fail + 1))
            fi
        else
            _EII_MODULE_STATUS["$module"]="not_loaded"
        fi
    done

    echo -e "  ${GREEN:-}[EII] Modules: ${init_success} active, ${init_fail} failed${NC:-}" >&2

    EII_INITIALIZED=true
    return 0
}

# =============================================================================
# _eii_handle_error - Master error handler
# Usage: _eii_handle_error <error_message> <category> <file> <project_dir>
# =============================================================================
_eii_handle_error() {
    [[ "$EII_INITIALIZED" != "true" ]] && _eii_init
    local error_message="${1:-}"
    local category="${2:-unknown}"
    local file="${3:-}"
    local project_dir="${4:-.}"

    EII_ERRORS_HANDLED=$((EII_ERRORS_HANDLED + 1))

    echo -e "  ${BOLD:-}[EII] Handling error: [${category}] ${error_message:0:80}${NC:-}" >&2

    # Step 1: Get full context
    local context
    context=$(_eii_get_error_context "$error_message" "$category" "$file" "$project_dir")

    # Step 2: Search knowledge base for past solutions
    local past_solution=""
    if [[ "${_EII_MODULE_STATUS[error-knowledge-base]:-}" == "active" ]]; then
        past_solution=$(_ekb_search "$error_message" 1 2>/dev/null)
        if [[ -n "$past_solution" ]] && [[ "$past_solution" != "[]" ]]; then
            local best_strategy
            best_strategy=$(_ekb_get_best_strategy "$category" 2>/dev/null)
            echo -e "  ${GREEN:-}[EII] Found past solution (strategy: ${best_strategy})${NC:-}" >&2
        fi
    fi

    # Step 3: Route to appropriate module
    local target_module="${_EII_CATEGORY_ROUTER[$category]:-self-healing-system}"
    echo -e "  ${CYAN:-}[EII] Routing to: ${target_module}${NC:-}" >&2

    # Step 4: Attempt resolution
    local resolved=false

    case "$target_module" in
        "self-healing-system")
            if [[ "${_EII_MODULE_STATUS[self-healing-system]:-}" == "active" ]]; then
                SHS_LAST_ERROR="$error_message"
                SHS_LAST_CATEGORY="$category"
                SHS_LAST_FILE="$file"

                local strategy
                strategy=$(_shs_classify_and_route "$error_message" "$category")
                _shs_generate_fix "$strategy" "$file" "$error_message"

                if _shs_apply_fix "$project_dir" "$SHS_LAST_FIX" 2>/dev/null; then
                    if _shs_verify_fix "$project_dir" 2>/dev/null; then
                        resolved=true
                        _shs_learn_from_fix "success"
                    else
                        _shs_rollback_if_needed
                        _shs_learn_from_fix "failure"
                    fi
                fi
            fi
            ;;

        "deployment-error-resolver")
            if [[ "${_EII_MODULE_STATUS[deployment-error-resolver]:-}" == "active" ]]; then
                case "$category" in
                    vercel) _der_fix_vercel_error "$project_dir" "$error_message" 2>/dev/null ;;
                    docker) _der_fix_docker_error "$project_dir" "$error_message" 2>/dev/null ;;
                    aws)    _der_fix_aws_error "$project_dir" "$error_message" 2>/dev/null ;;
                    *)      _der_fix_build_output "$project_dir" "$error_message" 2>/dev/null ;;
                esac
                resolved=true  # DER applies fixes directly
            fi
            ;;

        "database-deadlock-resolver")
            if [[ "${_EII_MODULE_STATUS[database-deadlock-resolver]:-}" == "active" ]]; then
                _ddr_detect_deadlock_risk "$project_dir" 2>/dev/null
                _ddr_add_lock_timeout "$project_dir" 2>/dev/null
                resolved=true
            fi
            ;;

        "compile-time-safety-net")
            if [[ "${_EII_MODULE_STATUS[compile-time-safety-net]:-}" == "active" ]]; then
                _ctsn_validate_config "$project_dir" 2>/dev/null
                resolved=true
            fi
            ;;

        "memory-leak-detector")
            if [[ "${_EII_MODULE_STATUS[memory-leak-detector]:-}" == "active" ]]; then
                _mld_scan_all "$project_dir" 2>/dev/null
                _mld_generate_cleanup "$project_dir" 2>/dev/null
                resolved=true
            fi
            ;;

        "infinite-loop-detector")
            if [[ "${_EII_MODULE_STATUS[infinite-loop-detector]:-}" == "active" ]]; then
                _ild_scan_all "$project_dir" 2>/dev/null
                _ild_add_guards "$project_dir" 2>/dev/null
                resolved=true
            fi
            ;;
    esac

    if [[ "$resolved" == "true" ]]; then
        EII_ERRORS_RESOLVED=$((EII_ERRORS_RESOLVED + 1))
        _EII_RESOLUTION_LOG+=("[RESOLVED] [${category}] ${error_message:0:80} -> ${target_module}")
        echo -e "  ${GREEN:-}[EII] Error resolved by ${target_module}${NC:-}" >&2
    else
        EII_ERRORS_ESCALATED=$((EII_ERRORS_ESCALATED + 1))
        _EII_RESOLUTION_LOG+=("[ESCALATED] [${category}] ${error_message:0:80}")
        echo -e "  ${YELLOW:-}[EII] Error escalated for manual review${NC:-}" >&2
    fi

    # Store in knowledge base regardless
    if [[ "${_EII_MODULE_STATUS[error-knowledge-base]:-}" == "active" ]]; then
        local result="failure"
        [[ "$resolved" == "true" ]] && result="success"
        _ekb_store_error "$category" "$error_message" "$file" "$category" "$target_module" "auto-routed" "$result" 2>/dev/null
    fi

    _EII_HANDLED_ERRORS+=("${category}::${error_message:0:80}")
    return 0
}

# =============================================================================
# _eii_get_error_context - Get full context for an error
# Usage: _eii_get_error_context <error> <category> <file> <project_dir>
# =============================================================================
_eii_get_error_context() {
    [[ "$EII_INITIALIZED" != "true" ]] && _eii_init
    local error="${1:-}"
    local category="${2:-}"
    local file="${3:-}"
    local project_dir="${4:-.}"

    EII_CONTEXTS_BUILT=$((EII_CONTEXTS_BUILT + 1))

    local context=""
    context+="Error: ${error}\n"
    context+="Category: ${category}\n"
    context+="File: ${file}\n"

    # Get file content snippet if file exists
    if [[ -n "$file" ]] && [[ -f "${project_dir}/${file}" ]]; then
        context+="File exists: yes\n"
        local line_count
        line_count=$(wc -l < "${project_dir}/${file}" 2>/dev/null || echo "0")
        context+="File lines: ${line_count}\n"
    fi

    # Get git info
    if [[ -d "${project_dir}/.git" ]]; then
        local branch
        branch=$(cd "$project_dir" && git branch --show-current 2>/dev/null || echo "unknown")
        context+="Branch: ${branch}\n"

        local recent_commits
        recent_commits=$(cd "$project_dir" && git log --oneline -3 2>/dev/null || echo "")
        context+="Recent commits:\n${recent_commits}\n"
    fi

    # Get dependency info
    if [[ -f "${project_dir}/package.json" ]]; then
        local dep_count
        dep_count=$(grep -c '"' "${project_dir}/package.json" 2>/dev/null || echo "0")
        context+="Package.json present: yes\n"

        # Check for relevant dependency versions
        if [[ "$category" == "prisma" ]]; then
            local prisma_ver
            prisma_ver=$(grep '"prisma"' "${project_dir}/package.json" 2>/dev/null | head -1)
            context+="Prisma: ${prisma_ver}\n"
        fi
    fi

    # Get past errors for context
    if [[ "${_EII_MODULE_STATUS[error-knowledge-base]:-}" == "active" ]]; then
        local past_count
        past_count=$(_ekb_search "$category" 0 2>/dev/null | grep -c '"error_type"' 2>/dev/null || echo "0")
        context+="Past similar errors: ${past_count}\n"

        local success_rate
        success_rate=$(_ekb_get_success_rate "$category" 2>/dev/null || echo "0")
        context+="Historical fix rate: ${success_rate}%\n"
    fi

    echo -e "$context"
}

# =============================================================================
# _eii_inject_into_healer - Inject error intelligence into healer.sh
# Usage: _eii_inject_into_healer <project_dir>
# =============================================================================
_eii_inject_into_healer() {
    [[ "$EII_INITIALIZED" != "true" ]] && _eii_init
    local project_dir="${1:-.}"

    echo -e "  ${CYAN:-}[EII] Injecting Error Intelligence into Healer...${NC:-}" >&2
    EII_HEALER_INJECTIONS=$((EII_HEALER_INJECTIONS + 1))

    # Pre-analyze the project with all available modules
    local analyses_done=0

    # Run diff analysis
    if [[ "${_EII_MODULE_STATUS[smart-diff-analyzer]:-}" == "active" ]]; then
        _sda_analyze_diff "$project_dir" 2>/dev/null
        analyses_done=$((analyses_done + 1))
    fi

    # Run memory leak scan
    if [[ "${_EII_MODULE_STATUS[memory-leak-detector]:-}" == "active" ]]; then
        _mld_scan_all "$project_dir" 2>/dev/null
        analyses_done=$((analyses_done + 1))
    fi

    # Run infinite loop scan
    if [[ "${_EII_MODULE_STATUS[infinite-loop-detector]:-}" == "active" ]]; then
        _ild_scan_all "$project_dir" 2>/dev/null
        analyses_done=$((analyses_done + 1))
    fi

    # Run deadlock detection
    if [[ "${_EII_MODULE_STATUS[database-deadlock-resolver]:-}" == "active" ]]; then
        _ddr_detect_deadlock_risk "$project_dir" 2>/dev/null
        analyses_done=$((analyses_done + 1))
    fi

    # Validate config
    if [[ "${_EII_MODULE_STATUS[compile-time-safety-net]:-}" == "active" ]]; then
        _ctsn_validate_config "$project_dir" 2>/dev/null
        analyses_done=$((analyses_done + 1))
    fi

    # Check deployment config
    if [[ "${_EII_MODULE_STATUS[deployment-error-resolver]:-}" == "active" ]]; then
        _der_fix_env_missing "$project_dir" 2>/dev/null
        _der_fix_build_output "$project_dir" 2>/dev/null
        analyses_done=$((analyses_done + 1))
    fi

    # Generate prevention artifacts
    if [[ "${_EII_MODULE_STATUS[runtime-safety-net]:-}" == "active" ]]; then
        # Only generate if they don't exist
        local src_dir="${project_dir}/src"
        [[ -d "${project_dir}/app" ]] && src_dir="${project_dir}"

        if [[ ! -f "${src_dir}/src/components/ErrorBoundary.tsx" ]] && \
           [[ ! -f "${src_dir}/components/ErrorBoundary.tsx" ]]; then
            _rsn_generate_all "$src_dir" 2>/dev/null
        fi
    fi

    echo -e "  ${GREEN:-}[EII] Healer injection complete: ${analyses_done} analyses performed${NC:-}" >&2
    return 0
}

# =============================================================================
# _eii_full_scan - Run comprehensive error intelligence scan
# Usage: _eii_full_scan <project_dir>
# =============================================================================
_eii_full_scan() {
    [[ "$EII_INITIALIZED" != "true" ]] && _eii_init
    local project_dir="${1:-.}"

    echo -e "  ${BOLD:-}[EII] Running full Error Intelligence scan...${NC:-}" >&2

    for module in "${_EII_MODULES[@]}"; do
        local scan_fn="${_EII_MODULE_SCAN[$module]:-}"
        if [[ -n "$scan_fn" ]] && type -t "$scan_fn" &>/dev/null; then
            echo -e "  ${CYAN:-}[EII] Running: ${module}${NC:-}" >&2
            $scan_fn "$project_dir" 2>/dev/null || true
        fi
    done

    echo -e "  ${GREEN:-}[EII] Full scan complete${NC:-}" >&2
}

# =============================================================================
# _eii_report - Comprehensive error intelligence report
# =============================================================================
_eii_report() {
    EII_REPORTS_GENERATED=$((EII_REPORTS_GENERATED + 1))

    echo -e "\n  ${BOLD:-}╔══════════════════════════════════════════════╗${NC:-}"
    echo -e "  ${BOLD:-}║  Error Intelligence Integration v280.0       ║${NC:-}"
    echo -e "  ${BOLD:-}╚══════════════════════════════════════════════╝${NC:-}"
    echo -e ""
    echo -e "  ${BOLD:-}Module Status:${NC:-}"

    for module in "${_EII_MODULES[@]}"; do
        local status="${_EII_MODULE_STATUS[$module]:-not_loaded}"
        local icon=""
        case "$status" in
            active)     icon="${GREEN:-}[OK]${NC:-}" ;;
            error)      icon="${RED:-}[ERR]${NC:-}" ;;
            not_loaded) icon="${YELLOW:-}[--]${NC:-}" ;;
        esac
        printf "    %s %-35s %s\n" "$icon" "$module" "$status"
    done

    echo -e ""
    echo -e "  ${BOLD:-}Error Handling:${NC:-}"
    echo -e "    Errors handled   : ${EII_ERRORS_HANDLED}"
    echo -e "    Errors resolved  : ${EII_ERRORS_RESOLVED}"
    echo -e "    Errors escalated : ${EII_ERRORS_ESCALATED}"
    echo -e "    Contexts built   : ${EII_CONTEXTS_BUILT}"
    echo -e "    Healer injections: ${EII_HEALER_INJECTIONS}"

    local rate=0
    [[ $EII_ERRORS_HANDLED -gt 0 ]] && rate=$((EII_ERRORS_RESOLVED * 100 / EII_ERRORS_HANDLED))
    echo -e "    Resolution rate  : ${rate}%"

    # Aggregate sub-module reports
    echo -e ""
    echo -e "  ${BOLD:-}Sub-Module Summaries:${NC:-}"

    if [[ "${_EII_MODULE_STATUS[smart-diff-analyzer]:-}" == "active" ]]; then
        echo -e "    [SDA] Incomplete:${SDA_INCOMPLETE_COUNT:-0} Breaks:${SDA_PATTERN_BREAK_COUNT:-0} Risky:${SDA_RISKY_COUNT:-0}"
    fi
    if [[ "${_EII_MODULE_STATUS[memory-leak-detector]:-}" == "active" ]]; then
        echo -e "    [MLD] Listeners:${MLD_LISTENER_LEAKS:-0} Timers:${MLD_INTERVAL_LEAKS:-0} Subs:${MLD_SUBSCRIPTION_LEAKS:-0}"
    fi
    if [[ "${_EII_MODULE_STATUS[infinite-loop-detector]:-}" == "active" ]]; then
        echo -e "    [ILD] While:${ILD_WHILE_ISSUES:-0} Recursive:${ILD_RECURSIVE_ISSUES:-0} Effect:${ILD_USEEFFECT_ISSUES:-0}"
    fi
    if [[ "${_EII_MODULE_STATUS[database-deadlock-resolver]:-}" == "active" ]]; then
        echo -e "    [DDR] Risks:${DDR_RISKS_DETECTED:-0} Timeouts:${DDR_TIMEOUT_ADDS:-0} Retries:${DDR_RETRY_GENERATED:-0}"
    fi
    if [[ "${_EII_MODULE_STATUS[error-knowledge-base]:-}" == "active" ]]; then
        echo -e "    [EKB] Entries:${EKB_TOTAL_ENTRIES:-0} Searches:${EKB_TOTAL_SEARCHES:-0} Hits:${EKB_TOTAL_HITS:-0}"
    fi
    if [[ "${_EII_MODULE_STATUS[self-healing-system]:-}" == "active" ]]; then
        echo -e "    [SHS] Cycles:${SHS_TOTAL_CYCLES:-0} Success:${SHS_HEAL_SUCCESS:-0} Failure:${SHS_HEAL_FAILURE:-0}"
    fi

    if [[ ${#_EII_RESOLUTION_LOG[@]} -gt 0 ]]; then
        echo -e ""
        echo -e "  ${BOLD:-}Resolution Log (last 10):${NC:-}"
        local start=0
        [[ ${#_EII_RESOLUTION_LOG[@]} -gt 10 ]] && start=$((${#_EII_RESOLUTION_LOG[@]} - 10))
        for ((i=start; i<${#_EII_RESOLUTION_LOG[@]}; i++)); do
            echo -e "    ${_EII_RESOLUTION_LOG[$i]}"
        done
    fi
}

# =============================================================================
# _eii_score - Integrated score
# =============================================================================
_eii_score() {
    local score=50
    local active_count=0

    for module in "${_EII_MODULES[@]}"; do
        [[ "${_EII_MODULE_STATUS[$module]:-}" == "active" ]] && active_count=$((active_count + 1))
    done

    # Score based on active modules
    score=$((score + active_count * 3))

    # Score based on resolution rate
    if [[ $EII_ERRORS_HANDLED -gt 0 ]]; then
        local rate=$((EII_ERRORS_RESOLVED * 100 / EII_ERRORS_HANDLED))
        score=$((score + rate / 10))
    fi

    [[ $EII_HEALER_INJECTIONS -gt 0 ]] && score=$((score + 5))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "error-intelligence-integration" \
    --version "280.0" \
    --description "全Error Intelligenceモジュール統合（v271-v279統合レイヤー）" \
    --init "_eii_init" \
    --report "_eii_report" \
    --score "_eii_score" \
    --enable-var "ENABLE_EII" \
    --cli-flags "--error-intelligence:--no-error-intelligence"
