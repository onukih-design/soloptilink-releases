#!/usr/bin/env bash
# ============================================================
# check-boost-marker.sh - PFP-054 Boost退避検出補助
# ============================================================
# chain.sh が直近で正常完了したかを確認する診断スクリプト
#
# 用途:
#   Claude セッションが「Goランチャーが故障」とハルシネートする前に、
#   直近の chain.sh 実行履歴を3点実測でAIに見せる
#
# 使い方:
#   bash ~/.soloptilink/lib/check-boost-marker.sh          # 人間向け
#   bash ~/.soloptilink/lib/check-boost-marker.sh --json   # AI向け
#
# 出力例 (--json):
#   {"marker_exists":true,"age_minutes":3,"version":"2034.7","exit_code":0,...}
# ============================================================

set -uo pipefail

MARKER="${HOME}/.soloptilink/.last_boost_session.json"
MODE="${1:-human}"

if [[ ! -f "$MARKER" ]]; then
    if [[ "$MODE" == "--json" ]]; then
        echo '{"marker_exists":false,"verdict":"never_run","ai_notice":"chain.sh has never completed successfully on this machine. PFP-054: do NOT conclude Go launcher is broken without first running ./soloptilink \"<task>\" to test."}'
    else
        echo "❌ Boost session marker not found: $MARKER"
        echo ""
        echo "意味: chain.sh が一度も正常完了していない (または初回起動前)。"
        echo ""
        echo "PFP-054 注意:"
        echo "  「Goランチャーが故障している」と結論する前に、必ず以下を試してください:"
        echo "    ./soloptilink \"<やりたいこと>\"   # 正規実行経路"
        echo "    ./soloptilink --status              # ライセンス状態"
        echo "    ./soloptilink --diagnose            # 端末診断"
    fi
    exit 1
fi

# JSON フィールド抽出 (jq 不要)
_now=$(date +%s)
_mtime=$(stat -f %m "$MARKER" 2>/dev/null || stat -c %Y "$MARKER" 2>/dev/null || echo 0)
_age_seconds=$(( _now - _mtime ))
_age_minutes=$(( _age_seconds / 60 ))

_version=$(grep -oE '"version":"[^"]*"' "$MARKER" 2>/dev/null | head -1 | cut -d'"' -f4)
_exit_code=$(grep -oE '"exit_code":[0-9]+' "$MARKER" 2>/dev/null | head -1 | cut -d':' -f2)
_phases=$(grep -oE '"phases_completed":[0-9]+' "$MARKER" 2>/dev/null | head -1 | cut -d':' -f2)
_quality=$(grep -oE '"quality_score":[0-9.]+' "$MARKER" 2>/dev/null | head -1 | cut -d':' -f2)
_task=$(grep -oE '"task":"[^"]*"' "$MARKER" 2>/dev/null | head -1 | cut -d'"' -f4)
_timestamp=$(grep -oE '"timestamp":"[^"]*"' "$MARKER" 2>/dev/null | head -1 | cut -d'"' -f4)

_version="${_version:-unknown}"
_exit_code="${_exit_code:-0}"
_phases="${_phases:-0}"
_quality="${_quality:-0}"

# Verdict 判定
if [[ $_age_minutes -lt 10 ]] && [[ "$_exit_code" == "0" ]]; then
    _verdict="recent_success"
    _ai_notice="chain.sh completed successfully ${_age_minutes} minutes ago. Go launcher is FUNCTIONING. Do NOT diagnose as 'broken'."
elif [[ $_age_minutes -lt 60 ]] && [[ "$_exit_code" == "0" ]]; then
    _verdict="success_within_hour"
    _ai_notice="chain.sh completed successfully within the last hour. If you see errors now, it is most likely PFP-047 launcher-bypass, NOT a structural failure."
elif [[ "$_exit_code" != "0" ]]; then
    _verdict="last_run_failed"
    _ai_notice="Last chain.sh run exited with code ${_exit_code}. Run --diagnose to inspect. Do NOT conclude 'structural failure' without 3-point verification."
else
    _verdict="stale_success"
    _ai_notice="Last successful chain.sh run was ${_age_minutes} minutes ago. Run ./soloptilink \"<task>\" to verify current state before concluding any failure."
fi

if [[ "$MODE" == "--json" ]]; then
    printf '{"marker_exists":true,"marker_path":"%s","timestamp":"%s","age_minutes":%d,"version":"%s","exit_code":%s,"phases_completed":%s,"quality_score":%s,"task":"%s","verdict":"%s","ai_notice":"%s"}\n' \
        "$MARKER" "$_timestamp" "$_age_minutes" "$_version" "$_exit_code" "$_phases" "$_quality" "$_task" "$_verdict" "$_ai_notice"
else
    echo "╔══════════════════════════════════════════════════════════════╗"
    echo "║      SoloptiLinkAI - Boost Session Marker (PFP-054)          ║"
    echo "╚══════════════════════════════════════════════════════════════╝"
    echo ""
    echo "  Marker     : $MARKER"
    echo "  Timestamp  : $_timestamp"
    echo "  Age        : $_age_minutes minutes (${_age_seconds}s)"
    echo "  Version    : v$_version"
    echo "  Exit code  : $_exit_code"
    echo "  Phases     : $_phases"
    echo "  Quality    : $_quality"
    echo "  Task       : $_task"
    echo "  Verdict    : $_verdict"
    echo ""
    echo "::AI_NOTICE:: $_ai_notice"
fi
