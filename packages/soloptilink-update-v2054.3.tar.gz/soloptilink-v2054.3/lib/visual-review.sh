#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v13.0 - Visual Review Module
# =============================================================================
# Playwrightでスクリーンショットを撮影し、Claude LLMによるビジュアル品質レビュー
# を実施する。デザイン品質・レイアウト崩れ・レスポンシブ対応・UX問題を自動検出。
#
# 機能:
#   1. Playwright環境チェック & セットアップ
#   2. マルチブレークポイントでのスクリーンショット撮影
#   3. Claude LLMによるビジュアル品質評価（スコアリング）
#   4. 改善提案の自動生成
#   5. ビジュアルレビューレポート生成
#
# Usage: source lib/visual-review.sh
# =============================================================================
# sourceされるライブラリなので set -euo pipefail は設定しない

# Load guard
[[ -n "${_VR_LOADED:-}" ]] && return 0
_VR_LOADED=1

# =============================================================================
# カラー定義（VR_プレフィックスで他モジュールとの衝突を防止）
# =============================================================================
VR_GREEN='\033[0;32m'
VR_YELLOW='\033[0;33m'
VR_RED='\033[0;31m'
VR_BLUE='\033[0;34m'
VR_PURPLE='\033[0;35m'
VR_CYAN='\033[0;36m'
VR_BOLD='\033[1m'
VR_NC='\033[0m'

# =============================================================================
# グローバル状態
# =============================================================================
VR_WORK_DIR="${HOME}/.soloptilink/visual-review"
VR_CLAUDE_TIMEOUT=300
VR_MAX_RETRIES=3

VR_PROJECT_DIR=""
VR_SCREENSHOT_DIR=""
VR_PLAYWRIGHT_AVAILABLE=false
VR_SCREENSHOTS_TAKEN=0
VR_REVIEW_SCORE=0
VR_ISSUES_FOUND=0
VR_IMPROVEMENTS=""
VR_RESULTS=""
VR_REPORT_FILE=""

# デフォルトのブレークポイント定義
VR_BREAKPOINTS=(
    "mobile:375:812"
    "tablet:768:1024"
    "desktop:1440:900"
)

# =============================================================================
# ヘルパー関数
# =============================================================================
_vr_log() {
    local level="$1" message="$2"
    local color="${VR_NC}"
    case "$level" in
        INFO)    color="${VR_CYAN}"   ;;
        SUCCESS) color="${VR_GREEN}"  ;;
        WARN)    color="${VR_YELLOW}" ;;
        ERROR)   color="${VR_RED}"    ;;
        STEP)    color="${VR_PURPLE}" ;;
        FAIL)    color="${VR_RED}"    ;;
    esac
    echo -e "  ${color}[VR:${level}]${VR_NC} ${message}"
    VR_RESULTS+="${level}: ${message}\n"
}

_vr_call_claude() {
    local prompt="$1"
    local output_file="${2:-}"
    local retry=0
    local result=""

    while [[ "$retry" -lt "$VR_MAX_RETRIES" ]]; do
        retry=$((retry + 1))
        result=$(timeout "${VR_CLAUDE_TIMEOUT}" \
            claude -p --dangerously-skip-permissions \
            --output-format text "$prompt" 2>/dev/null || echo "")

        if [[ -n "$result" ]]; then
            if [[ -n "$output_file" ]]; then
                mkdir -p "$(dirname "$output_file")" 2>/dev/null || true
                printf '%s\n' "$result" > "$output_file"
            fi
            echo "$result"
            return 0
        fi
        _vr_log "WARN" "Claude CLI応答なし (試行 ${retry}/${VR_MAX_RETRIES})"
        sleep $((retry * 3))
    done

    _vr_log "ERROR" "Claude CLI: 全リトライ失敗"
    return 1
}

# =============================================================================
# 1. vr_init(project_dir) - 初期化
# =============================================================================
vr_init() {
    local project_dir="${1:-}"
    [[ -z "$project_dir" || ! -d "$project_dir" ]] && {
        _vr_log "ERROR" "無効なプロジェクトディレクトリ: ${project_dir}"
        return 1
    }

    VR_PROJECT_DIR="$project_dir"
    VR_SCREENSHOT_DIR="${VR_WORK_DIR}/screenshots_$(date +%Y%m%d_%H%M%S)"
    VR_PLAYWRIGHT_AVAILABLE=false
    VR_SCREENSHOTS_TAKEN=0
    VR_REVIEW_SCORE=0
    VR_ISSUES_FOUND=0
    VR_IMPROVEMENTS=""
    VR_RESULTS=""
    VR_REPORT_FILE=""

    mkdir -p "${VR_WORK_DIR}" 2>/dev/null || true
    mkdir -p "${VR_SCREENSHOT_DIR}" 2>/dev/null || true

    echo -e "\n${VR_BOLD}${VR_PURPLE}╔═══════════════════════════════════════════════════════╗${VR_NC}"
    echo -e "${VR_BOLD}${VR_PURPLE}║   Visual Review v13.0 - Playwright Quality Review     ║${VR_NC}"
    echo -e "${VR_BOLD}${VR_PURPLE}╚═══════════════════════════════════════════════════════╝${VR_NC}\n"

    _vr_log "INFO" "Visual Review v13.0 初期化完了"
    _vr_log "INFO" "プロジェクト: ${project_dir}"
    _vr_log "INFO" "スクリーンショット保存先: ${VR_SCREENSHOT_DIR}"
}

# =============================================================================
# 2. vr_check_playwright() - Playwright環境チェック
# =============================================================================
# 戻り値: 0=利用可能, 1=利用不可
vr_check_playwright() {
    _vr_log "STEP" "Playwright環境チェック中..."

    # npx playwright チェック
    if npx playwright --version &>/dev/null 2>&1; then
        local pw_version
        pw_version=$(npx playwright --version 2>/dev/null | head -1)
        VR_PLAYWRIGHT_AVAILABLE=true
        _vr_log "SUCCESS" "Playwright検出: ${pw_version}"

        # ブラウザインストール確認
        if npx playwright install --dry-run chromium &>/dev/null 2>&1; then
            _vr_log "INFO" "Chromiumブラウザ: インストール済み"
        else
            _vr_log "WARN" "Chromiumブラウザ未インストール → インストール中..."
            npx playwright install chromium 2>/dev/null || {
                _vr_log "WARN" "Chromiumインストール失敗（続行可能）"
            }
        fi
        return 0
    fi

    # Playwright未インストール → インストール試行
    if command -v npx &>/dev/null; then
        _vr_log "WARN" "Playwright未検出 → インストール試行中..."
        if npm install -D @playwright/test 2>/dev/null; then
            npx playwright install chromium 2>/dev/null || true
            VR_PLAYWRIGHT_AVAILABLE=true
            _vr_log "SUCCESS" "Playwrightインストール完了"
            return 0
        fi
    fi

    VR_PLAYWRIGHT_AVAILABLE=false
    _vr_log "ERROR" "Playwrightが利用できません。npm install -D @playwright/test を実行してください"
    return 1
}

# =============================================================================
# 3. vr_capture_screenshots(url, breakpoints) - スクリーンショット撮影
# =============================================================================
# url: 対象URL (例: http://localhost:3000)
# breakpoints: オプション、カンマ区切り (例: "mobile:375:812,tablet:768:1024")
# 未指定時はデフォルトブレークポイントを使用
vr_capture_screenshots() {
    local url="${1:-http://localhost:3000}"
    local custom_breakpoints="${2:-}"

    _vr_log "STEP" "スクリーンショット撮影中: ${url}"

    if [[ "$VR_PLAYWRIGHT_AVAILABLE" != "true" ]]; then
        _vr_log "WARN" "Playwright未検出 → フォールバック（curlスナップショット）"
        _vr_capture_fallback "$url"
        return $?
    fi

    # ブレークポイント設定
    local breakpoints=()
    if [[ -n "$custom_breakpoints" ]]; then
        IFS=',' read -ra breakpoints <<< "$custom_breakpoints"
    else
        breakpoints=("${VR_BREAKPOINTS[@]}")
    fi

    # Playwrightスクリプトを動的生成
    local pw_script="${VR_SCREENSHOT_DIR}/_capture.mjs"
    local routes_to_capture="/"

    # プロジェクトのルート一覧を推定
    if [[ -d "${VR_PROJECT_DIR}/app" ]]; then
        routes_to_capture=$(find "${VR_PROJECT_DIR}/app" -name "page.tsx" -o -name "page.jsx" -o -name "page.js" 2>/dev/null \
            | sed "s|${VR_PROJECT_DIR}/app||" | sed 's|/page\.[jt]sx\?$||' | sed 's|^$|/|' | sort -u | head -20)
    elif [[ -d "${VR_PROJECT_DIR}/src/pages" ]]; then
        routes_to_capture=$(find "${VR_PROJECT_DIR}/src/pages" -name "*.tsx" -o -name "*.jsx" -o -name "*.js" 2>/dev/null \
            | grep -v '_app\|_document\|_error\|404\|500\|api/' \
            | sed "s|${VR_PROJECT_DIR}/src/pages||" | sed 's|\.[jt]sx\?$||' | sed 's|/index$|/|' | sort -u | head -20)
    fi
    [[ -z "$routes_to_capture" ]] && routes_to_capture="/"

    # Playwrightスクリプト生成
    cat > "$pw_script" <<'PWEOF'
import { chromium } from 'playwright';

const url = process.argv[2] || 'http://localhost:3000';
const outDir = process.argv[3] || './screenshots';
const breakpointsArg = process.argv[4] || 'desktop:1440:900';
const routesArg = process.argv[5] || '/';

const breakpoints = breakpointsArg.split(',').map(b => {
    const [name, w, h] = b.split(':');
    return { name, width: parseInt(w), height: parseInt(h) };
});
const routes = routesArg.split(',').filter(Boolean);

(async () => {
    const browser = await chromium.launch({ headless: true });
    let count = 0;

    for (const bp of breakpoints) {
        const context = await browser.newContext({
            viewport: { width: bp.width, height: bp.height },
            deviceScaleFactor: bp.name === 'mobile' ? 2 : 1,
        });
        const page = await context.newPage();

        for (const route of routes) {
            try {
                const fullUrl = url.replace(/\/$/, '') + (route === '/' ? '/' : route);
                await page.goto(fullUrl, { waitUntil: 'networkidle', timeout: 15000 });
                await page.waitForTimeout(1000); // アニメーション待ち

                const safeName = route.replace(/\//g, '_').replace(/^_/, '') || 'index';
                const filename = `${outDir}/${bp.name}_${safeName}.png`;
                await page.screenshot({ path: filename, fullPage: true });
                count++;
                console.log(`CAPTURED: ${bp.name} ${route} -> ${filename}`);
            } catch (e) {
                console.error(`SKIP: ${bp.name} ${route} - ${e.message}`);
            }
        }
        await context.close();
    }
    await browser.close();
    console.log(`TOTAL: ${count} screenshots`);
})();
PWEOF

    # ブレークポイントを文字列化
    local bp_str
    bp_str=$(printf '%s,' "${breakpoints[@]}" | sed 's/,$//')
    local routes_str
    routes_str=$(echo "$routes_to_capture" | tr '\n' ',' | sed 's/,$//')

    # 実行
    _vr_log "INFO" "ブレークポイント: ${bp_str}"
    _vr_log "INFO" "ルート: ${routes_str}"

    local capture_output
    capture_output=$(node "$pw_script" "$url" "$VR_SCREENSHOT_DIR" "$bp_str" "$routes_str" 2>&1)
    local exit_code=$?

    if [[ $exit_code -ne 0 ]]; then
        _vr_log "WARN" "Playwright撮影でエラー発生 (exit: ${exit_code})"
        _vr_log "INFO" "$capture_output"
    fi

    # 撮影枚数カウント
    VR_SCREENSHOTS_TAKEN=$(find "$VR_SCREENSHOT_DIR" -name "*.png" 2>/dev/null | wc -l | tr -d ' ')
    _vr_log "SUCCESS" "スクリーンショット撮影完了: ${VR_SCREENSHOTS_TAKEN}枚"
    _vr_log "INFO" "保存先: ${VR_SCREENSHOT_DIR}"

    # 撮影結果をログ出力
    echo "$capture_output" | grep "^CAPTURED:" | while IFS= read -r line; do
        _vr_log "INFO" "$line"
    done

    return 0
}

# --- フォールバック: curl + テキストスナップショット ---
_vr_capture_fallback() {
    local url="$1"
    _vr_log "INFO" "フォールバックモード: HTMLをダウンロードして解析"

    local html_file="${VR_SCREENSHOT_DIR}/page_source.html"
    if curl -sL --max-time 15 "$url" -o "$html_file" 2>/dev/null; then
        local file_size
        file_size=$(wc -c < "$html_file" | tr -d ' ')
        _vr_log "SUCCESS" "HTML取得完了: ${file_size} bytes"
        VR_SCREENSHOTS_TAKEN=1
        return 0
    else
        _vr_log "ERROR" "URL取得失敗: ${url}"
        return 1
    fi
}

# =============================================================================
# 4. vr_review_quality(screenshot_dir) - Claude LLMによるビジュアル品質評価
# =============================================================================
# screenshot_dir内のスクリーンショットをClaudeに送ってレビュー
# 戻り値(stdout): レビュー結果（Markdown）
vr_review_quality() {
    local screenshot_dir="${1:-$VR_SCREENSHOT_DIR}"
    [[ ! -d "$screenshot_dir" ]] && {
        _vr_log "ERROR" "スクリーンショットディレクトリが存在しません: ${screenshot_dir}"
        return 1
    }

    _vr_log "STEP" "ビジュアル品質レビュー実行中..."

    local screenshots
    screenshots=$(find "$screenshot_dir" -name "*.png" -o -name "*.html" 2>/dev/null | sort)
    local screenshot_count
    screenshot_count=$(echo "$screenshots" | grep -c '.' || echo "0")

    if [[ "$screenshot_count" -eq 0 ]]; then
        _vr_log "ERROR" "レビュー対象のスクリーンショットがありません"
        return 1
    fi

    # スクリーンショット情報をテキスト化（ファイル名リスト）
    local screenshot_list=""
    while IFS= read -r ss; do
        [[ -z "$ss" ]] && continue
        local basename_ss
        basename_ss=$(basename "$ss")
        local filesize_ss
        filesize_ss=$(wc -c < "$ss" | tr -d ' ')
        screenshot_list+="- ${basename_ss} (${filesize_ss} bytes)\n"
    done <<< "$screenshots"

    # HTMLフォールバックの場合: HTMLソースからレビュー
    local html_file="${screenshot_dir}/page_source.html"
    local review_prompt=""

    if [[ -f "$html_file" ]]; then
        local html_content
        html_content=$(head -c 20000 "$html_file")
        review_prompt="以下のHTMLソースコードを分析し、ビジュアル品質レビューを実施してください。

## HTMLソース（先頭20KB）:
\`\`\`html
${html_content}
\`\`\`

## レビュー項目（各10点満点、合計100点）:
1. **レイアウト構造** (10点): セマンティックHTML、適切なグリッド/フレックス使用
2. **レスポンシブ対応** (10点): ブレークポイント、モバイルファースト
3. **カラー設計** (10点): コントラスト比、一貫性、ダークモード対応
4. **タイポグラフィ** (10点): フォント選定、階層構造、可読性
5. **スペーシング** (10点): 余白の一貫性、呼吸感
6. **コンポーネント品質** (10点): UIコンポーネントの適切な使用
7. **インタラクション** (10点): ホバー/フォーカス/アクティブ状態
8. **アクセシビリティ** (10点): alt属性、ARIA、キーボード操作
9. **パフォーマンス** (10点): 画像最適化、CSS効率
10. **全体的な印象** (10点): プロフェッショナル感、統一感

## 出力形式:
以下の形式でJSON出力してください:
\`\`\`json
{
  \"total_score\": 75,
  \"categories\": {
    \"layout\": { \"score\": 8, \"comment\": \"...\" },
    \"responsive\": { \"score\": 7, \"comment\": \"...\" },
    \"color\": { \"score\": 8, \"comment\": \"...\" },
    \"typography\": { \"score\": 7, \"comment\": \"...\" },
    \"spacing\": { \"score\": 8, \"comment\": \"...\" },
    \"components\": { \"score\": 7, \"comment\": \"...\" },
    \"interaction\": { \"score\": 7, \"comment\": \"...\" },
    \"accessibility\": { \"score\": 8, \"comment\": \"...\" },
    \"performance\": { \"score\": 7, \"comment\": \"...\" },
    \"impression\": { \"score\": 8, \"comment\": \"...\" }
  },
  \"issues\": [\"issue1\", \"issue2\"],
  \"strengths\": [\"strength1\", \"strength2\"]
}
\`\`\`"
    else
        review_prompt="以下のスクリーンショットファイル構成を元に、Webアプリケーションのビジュアル品質レビューを実施してください。

## スクリーンショット一覧:
$(printf '%b' "$screenshot_list")

各ファイル名のプレフィックスはビューポート（mobile_, tablet_, desktop_）を示します。

## レビュー項目（各10点満点、合計100点）:
1. **レイアウト構造** (10点): ページ構成の適切さ
2. **レスポンシブ対応** (10点): 全ビューポートでの適切な表示
3. **カラー設計** (10点): ブランド一貫性、コントラスト
4. **タイポグラフィ** (10点): 階層構造、可読性
5. **スペーシング** (10点): 余白の一貫性
6. **コンポーネント品質** (10点): UIパーツの品質
7. **インタラクション** (10点): 操作性の設計
8. **アクセシビリティ** (10点): 包括的なデザイン
9. **パフォーマンス** (10点): 表示速度への配慮
10. **全体的な印象** (10点): プロフェッショナル感

## 出力形式:
以下の形式でJSON出力してください:
\`\`\`json
{
  \"total_score\": 75,
  \"categories\": {
    \"layout\": { \"score\": 8, \"comment\": \"...\" },
    \"responsive\": { \"score\": 7, \"comment\": \"...\" },
    \"color\": { \"score\": 8, \"comment\": \"...\" },
    \"typography\": { \"score\": 7, \"comment\": \"...\" },
    \"spacing\": { \"score\": 8, \"comment\": \"...\" },
    \"components\": { \"score\": 7, \"comment\": \"...\" },
    \"interaction\": { \"score\": 7, \"comment\": \"...\" },
    \"accessibility\": { \"score\": 8, \"comment\": \"...\" },
    \"performance\": { \"score\": 7, \"comment\": \"...\" },
    \"impression\": { \"score\": 8, \"comment\": \"...\" }
  },
  \"issues\": [\"issue1\", \"issue2\"],
  \"strengths\": [\"strength1\", \"strength2\"]
}
\`\`\`"
    fi

    local review_result
    review_result=$(_vr_call_claude "$review_prompt" "${screenshot_dir}/review_result.md")

    if [[ -z "$review_result" ]]; then
        _vr_log "ERROR" "レビュー結果が空です"
        return 1
    fi

    # スコア抽出
    local score
    score=$(echo "$review_result" | grep -o '"total_score"[[:space:]]*:[[:space:]]*[0-9]*' | grep -o '[0-9]*' | head -1)
    VR_REVIEW_SCORE="${score:-0}"

    # 問題数カウント
    local issues_count
    issues_count=$(echo "$review_result" | grep -c '"issues"' || echo "0")
    VR_ISSUES_FOUND="$issues_count"

    local score_color="${VR_GREEN}"
    [[ "${VR_REVIEW_SCORE}" -lt 80 ]] && score_color="${VR_YELLOW}"
    [[ "${VR_REVIEW_SCORE}" -lt 50 ]] && score_color="${VR_RED}"

    _vr_log "SUCCESS" "ビジュアル品質スコア: ${VR_REVIEW_SCORE}/100"
    echo "$review_result"
}

# =============================================================================
# 5. vr_suggest_improvements(review_result) - 改善提案生成
# =============================================================================
# レビュー結果から具体的なコード改善提案を生成
# 戻り値(stdout): 改善提案リスト（Markdown）
vr_suggest_improvements() {
    local review_result="${1:-}"
    [[ -z "$review_result" ]] && {
        _vr_log "ERROR" "レビュー結果が空です"
        return 1
    }

    _vr_log "STEP" "改善提案生成中..."

    local improvement_prompt="以下のビジュアル品質レビュー結果に基づき、具体的なコード改善提案を生成してください。

## レビュー結果:
${review_result}

## 出力形式:
各改善提案について以下の形式で出力:

### 改善提案 1: [タイトル]
- **優先度**: HIGH / MEDIUM / LOW
- **カテゴリ**: layout / responsive / color / typography / spacing / components / interaction / accessibility / performance
- **問題**: [現在の問題点]
- **解決策**: [具体的な修正方法]
- **コード例**:
\`\`\`tsx
// 改善前
...
// 改善後
...
\`\`\`
- **期待効果**: スコア +X点

優先度HIGHから順に、最大10件の改善提案を出力してください。"

    local improvements
    improvements=$(_vr_call_claude "$improvement_prompt" "${VR_SCREENSHOT_DIR}/improvements.md")

    if [[ -n "$improvements" ]]; then
        VR_IMPROVEMENTS="$improvements"
        local improvement_count
        improvement_count=$(echo "$improvements" | grep -c '### 改善提案' || echo "0")
        _vr_log "SUCCESS" "改善提案生成完了: ${improvement_count}件"
    else
        _vr_log "WARN" "改善提案の生成に失敗しました"
    fi

    echo "$improvements"
}

# =============================================================================
# 6. vr_report() - ビジュアルレビューレポート生成
# =============================================================================
vr_report() {
    local report_file="${VR_SCREENSHOT_DIR}/visual-review-report.md"

    _vr_log "STEP" "ビジュアルレビューレポート生成中..."

    local timestamp
    timestamp=$(date '+%Y-%m-%d %H:%M:%S')

    local score_emoji="PASS"
    [[ "${VR_REVIEW_SCORE}" -lt 80 ]] && score_emoji="WARN"
    [[ "${VR_REVIEW_SCORE}" -lt 50 ]] && score_emoji="FAIL"

    cat > "$report_file" <<EOF
# Visual Review Report
Generated by SoloptiLink Visual Review v13.0
Date: ${timestamp}

## Summary
| Metric               | Value                     |
|----------------------|---------------------------|
| Project              | ${VR_PROJECT_DIR}         |
| Screenshots Taken    | ${VR_SCREENSHOTS_TAKEN}   |
| Visual Quality Score | ${VR_REVIEW_SCORE}/100    |
| Status               | ${score_emoji}            |
| Issues Found         | ${VR_ISSUES_FOUND}        |

## Score Breakdown

$(if [[ -f "${VR_SCREENSHOT_DIR}/review_result.md" ]]; then
    cat "${VR_SCREENSHOT_DIR}/review_result.md"
else
    echo "No detailed review data available."
fi)

## Improvements

$(if [[ -n "${VR_IMPROVEMENTS}" ]]; then
    echo "${VR_IMPROVEMENTS}"
else
    echo "No improvement suggestions generated."
fi)

## Screenshots

$(find "${VR_SCREENSHOT_DIR}" -name "*.png" 2>/dev/null | sort | while IFS= read -r f; do
    echo "- $(basename "$f")"
done)

## Breakpoints Tested
| Device  | Width | Height |
|---------|-------|--------|
| Mobile  | 375px | 812px  |
| Tablet  | 768px | 1024px |
| Desktop | 1440px| 900px  |

---
*Report generated by SoloptiLink Chain v13.0 - Visual Review Module*
EOF

    VR_REPORT_FILE="$report_file"
    _vr_log "SUCCESS" "レポート生成完了: ${report_file}"
    echo "$report_file"
}

# =============================================================================
# 7. vr_run_all(project_dir, url) - 全機能一括実行
# =============================================================================
vr_run_all() {
    local project_dir="${1:-}"
    local url="${2:-http://localhost:3000}"

    [[ -z "$project_dir" ]] && { _vr_log "ERROR" "プロジェクトディレクトリが未指定です"; return 1; }

    local start_time
    start_time=$(date +%s)

    # 初期化
    vr_init "$project_dir" || return 1

    # Playwright環境チェック
    _vr_log "STEP" "[1/5] Playwright環境チェック"
    vr_check_playwright

    # スクリーンショット撮影
    _vr_log "STEP" "[2/5] スクリーンショット撮影"
    vr_capture_screenshots "$url"

    # ビジュアル品質レビュー
    _vr_log "STEP" "[3/5] ビジュアル品質レビュー"
    local review_result
    review_result=$(vr_review_quality)

    # 改善提案
    _vr_log "STEP" "[4/5] 改善提案生成"
    if [[ -n "$review_result" ]]; then
        vr_suggest_improvements "$review_result" > /dev/null
    fi

    # レポート生成
    _vr_log "STEP" "[5/5] レポート生成"
    vr_report

    local elapsed=$(( $(date +%s) - start_time ))

    echo ""
    echo -e "${VR_BOLD}+----------------------------------------------+${VR_NC}"
    echo -e "${VR_BOLD}|        Visual Review Summary                 |${VR_NC}"
    echo -e "${VR_BOLD}+----------------------------------------------+${VR_NC}"
    printf "${VR_BOLD}|${VR_NC}  Screenshots:    %-25d${VR_BOLD}|${VR_NC}\n" "$VR_SCREENSHOTS_TAKEN"
    printf "${VR_BOLD}|${VR_NC}  Quality Score:  %-25s${VR_BOLD}|${VR_NC}\n" "${VR_REVIEW_SCORE}/100"
    printf "${VR_BOLD}|${VR_NC}  Issues:         %-25d${VR_BOLD}|${VR_NC}\n" "$VR_ISSUES_FOUND"
    printf "${VR_BOLD}|${VR_NC}  Time:           %-25s${VR_BOLD}|${VR_NC}\n" "${elapsed}s"
    echo -e "${VR_BOLD}+----------------------------------------------+${VR_NC}"
    echo -e "  ${VR_CYAN}Report: ${VR_REPORT_FILE}${VR_NC}"
}

# =============================================================================
# エクスポート
# =============================================================================
#   source lib/visual-review.sh
#   vr_init "/path/to/project"
#   vr_check_playwright
#   vr_capture_screenshots "http://localhost:3000"
#   vr_review_quality
#   vr_suggest_improvements "$review_result"
#   vr_report
#   vr_run_all "/path/to/project" "http://localhost:3000"
