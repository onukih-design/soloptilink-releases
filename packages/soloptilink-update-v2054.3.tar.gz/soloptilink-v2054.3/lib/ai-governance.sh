#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v101.0 - AI Governance Engine
# AGI時代に最重要: AIに何をさせて良いかを制御する
#
# 既存との棲み分け:
#   governance-engine.sh → コード品質のガバナンス（命名規約、アーキテクチャ）
#   ★ ai-governance.sh  → AI操作のガバナンス（承認、監査、制限、ポリシー）
#
# 機能:
#   1. 承認フロー階層化（影響範囲・コストで自動判定）
#   2. AI操作の全トレーシング（不変の監査証跡）
#   3. ポリシーエンジン（ドメイン×フェーズのルールマトリクス）
#   4. AI出力の検証ゲート（デプロイ前の安全性チェック）
#   5. コンプライアンスレポート生成
#
# v101.0: AGI-Ready Governance
# ============================================================

[[ -n "${_AI_GOVERNANCE_LOADED:-}" ]] && return 0
_AI_GOVERNANCE_LOADED=1

# --- グローバル状態 ---
AIG_VERSION="109.0"
AIG_INITIALIZED=false
AIG_BASE_DIR="${HOME}/.soloptilink/ai-governance"
AIG_AUDIT_DIR=""
AIG_POLICY_DIR=""

# --- 統計 ---
AIG_TOTAL_DECISIONS=0
AIG_APPROVED=0
AIG_BLOCKED=0
AIG_ESCALATED=0

# --- ポリシーレベル ---
# Level 0: AUTO     - 自動承認（低リスク）
# Level 1: NOTIFY   - 実行＋通知（中リスク）
# Level 2: CONFIRM  - 確認後実行（高リスク）
# Level 3: ESCALATE - 人間承認必須（クリティカル）
declare -A AIG_PHASE_LEVEL=()
declare -A AIG_DOMAIN_RISK=()

# ============================================================
# 初期化
# ============================================================
aig_init() {
    AIG_AUDIT_DIR="${AIG_BASE_DIR}/audit"
    AIG_POLICY_DIR="${AIG_BASE_DIR}/policies"

    mkdir -p "$AIG_AUDIT_DIR" "$AIG_POLICY_DIR" 2>/dev/null || true

    # フェーズ別デフォルトレベル
    AIG_PHASE_LEVEL=(
        [requirements]=0      # AUTO: 要件定義は安全
        [competitive_research]=0
        [prompt_expand]=0
        [scaffold]=0          # AUTO: スキャフォルドは安全
        [design]=0
        [database]=1          # NOTIFY: DB変更は要注意
        [backend]=1
        [api]=1
        [frontend]=0
        [implementation]=1
        [testing]=0           # AUTO: テストは安全
        [quality_check]=0
        [browser_test]=0
        [documentation]=0
        [deploy]=2            # CONFIRM: デプロイは確認必須
        [security_audit]=1
        [hotfix]=2            # CONFIRM: ホットフィクスは確認必須
    )

    # ドメイン別リスクレベル（0-3）
    AIG_DOMAIN_RISK=(
        [general]=0
        [saas]=1
        [ecommerce]=1
        [crm]=1
        [healthcare]=3        # ESCALATE: 医療は常に人間承認
        [finance]=3           # ESCALATE: 金融も同様
        [education]=2
        [government]=3
        [task_management]=0
    )

    # ポリシー初期化
    if [[ ! -f "${AIG_POLICY_DIR}/default.json" ]]; then
        _aig_seed_policies
    fi

    # v109.0: セッションコスト追跡初期化
    AIG_SESSION_TOTAL_COST=0
    AIG_MAX_CALLS="${AIG_MAX_CALLS:-100}"
    AIG_MAX_COST="${AIG_MAX_COST:-50}"
    AIG_MAX_FILES="${AIG_MAX_FILES:-500}"

    AIG_INITIALIZED=true
    return 0
}

# ============================================================
# 承認フロー（ai_call pre-hookとして使用）
# ============================================================

# AI操作の承認判定
aig_check_approval() {
    local phase="${1:-implementation}"
    local domain="${2:-general}"
    local estimated_cost="${3:-0}"
    local operation_desc="${4:-AI generation}"

    AIG_TOTAL_DECISIONS=$((AIG_TOTAL_DECISIONS + 1))

    # --- レベル算出 ---
    local phase_level=${AIG_PHASE_LEVEL[$phase]:-1}
    local domain_risk=${AIG_DOMAIN_RISK[$domain]:-0}

    # 最終レベル = max(phase_level, domain_risk)
    local final_level=$phase_level
    [[ $domain_risk -gt $final_level ]] && final_level=$domain_risk

    # コストによるエスカレーション
    if [[ -n "$estimated_cost" ]]; then
        local cost_int
        cost_int=$(printf '%.0f' "$estimated_cost" 2>/dev/null || echo "0")
        if [[ $cost_int -gt 50 ]]; then
            [[ $final_level -lt 2 ]] && final_level=2
        fi
        if [[ $cost_int -gt 200 ]]; then
            final_level=3
        fi
    fi

    # --- 判定実行 ---
    local decision=""
    local reason=""

    case $final_level in
        0)
            decision="APPROVED"
            reason="auto-approved (low risk: phase=${phase}, domain=${domain})"
            AIG_APPROVED=$((AIG_APPROVED + 1))
            ;;
        1)
            decision="APPROVED"
            reason="approved with notification (medium risk: phase=${phase}, domain=${domain})"
            AIG_APPROVED=$((AIG_APPROVED + 1))
            # 通知（ログ記録）
            echo -e "  ${CYAN:-}[Governance] ${operation_desc} - ${reason}${NC:-}" >&2
            ;;
        2)
            # 確認フロー - 自動モードでは承認、対話モードでは確認
            if [[ "${AIG_AUTO_APPROVE:-true}" == "true" ]]; then
                decision="APPROVED"
                reason="auto-confirmed (high risk, auto-mode: phase=${phase}, domain=${domain})"
                AIG_APPROVED=$((AIG_APPROVED + 1))
            else
                decision="PENDING"
                reason="requires confirmation (high risk: phase=${phase}, domain=${domain})"
                AIG_ESCALATED=$((AIG_ESCALATED + 1))
            fi
            echo -e "  ${YELLOW:-}[Governance] ⚠️ ${operation_desc} - ${reason}${NC:-}" >&2
            ;;
        3)
            # エスカレーション - 自動モードでも警告
            if [[ "${AIG_AUTO_APPROVE:-true}" == "true" ]]; then
                decision="APPROVED"
                reason="escalation auto-approved (critical risk, auto-mode: phase=${phase}, domain=${domain})"
                AIG_APPROVED=$((AIG_APPROVED + 1))
            else
                decision="BLOCKED"
                reason="requires human approval (critical: phase=${phase}, domain=${domain})"
                AIG_BLOCKED=$((AIG_BLOCKED + 1))
            fi
            echo -e "  ${RED:-}[Governance] 🚫 ${operation_desc} - ${reason}${NC:-}" >&2
            ;;
    esac

    # --- 監査記録 ---
    _aig_audit_log "$phase" "$domain" "$final_level" "$decision" "$reason" "$estimated_cost"

    # 判定結果を返す（0=承認, 1=ブロック）
    if [[ "$decision" == "APPROVED" || "$decision" == "PENDING" ]]; then
        return 0
    else
        return 1
    fi
}

# ============================================================
# 監査証跡（不変ログ）
# ============================================================
_aig_audit_log() {
    local phase="$1"
    local domain="$2"
    local level="$3"
    local decision="$4"
    local reason="$5"
    local cost="$6"

    local audit_file="${AIG_AUDIT_DIR}/$(date '+%Y%m%d').jsonl"

    local record="{\"timestamp\":\"$(date '+%Y-%m-%dT%H:%M:%S')\",\"session\":\"${SESSION_ID:-unknown}\",\"phase\":\"${phase}\",\"domain\":\"${domain}\",\"level\":${level},\"decision\":\"${decision}\",\"reason\":\"${reason}\",\"estimated_cost\":${cost:-0},\"provider\":\"${AIP_PROVIDER:-claude-cli}\"}"

    echo "$record" >> "$audit_file" 2>/dev/null || true
}

# 監査ログ取得
aig_get_audit_log() {
    local date="${1:-$(date '+%Y%m%d')}"
    local audit_file="${AIG_AUDIT_DIR}/${date}.jsonl"

    if [[ -f "$audit_file" ]]; then
        cat "$audit_file"
    else
        echo "No audit log for ${date}"
    fi
}

# 監査サマリー生成
aig_audit_summary() {
    local date="${1:-$(date '+%Y%m%d')}"
    local audit_file="${AIG_AUDIT_DIR}/${date}.jsonl"

    if [[ -f "$audit_file" ]] && command -v python3 &>/dev/null; then
        python3 -c "
import json
records = []
with open('$audit_file') as f:
    for line in f:
        line = line.strip()
        if line:
            try:
                records.append(json.loads(line))
            except:
                pass
total = len(records)
approved = sum(1 for r in records if r.get('decision') == 'APPROVED')
blocked = sum(1 for r in records if r.get('decision') == 'BLOCKED')
by_phase = {}
for r in records:
    p = r.get('phase', 'unknown')
    by_phase[p] = by_phase.get(p, 0) + 1
print(f'=== AI Governance Audit Summary ({\"$date\"}) ===')
print(f'  Total decisions: {total}')
print(f'  Approved: {approved} ({approved*100//max(total,1)}%)')
print(f'  Blocked: {blocked}')
print(f'  By phase:')
for p, c in sorted(by_phase.items(), key=lambda x: -x[1]):
    print(f'    {p}: {c}')
" 2>/dev/null
    else
        echo "Audit summary: ${AIG_TOTAL_DECISIONS} decisions (${AIG_APPROVED} approved, ${AIG_BLOCKED} blocked, ${AIG_ESCALATED} escalated)"
    fi
}

# ============================================================
# ポリシーエンジン
# ============================================================

# ポリシー適用チェック
aig_check_policy() {
    local policy_name="$1"
    local context="$2"

    local policy_file="${AIG_POLICY_DIR}/${policy_name}.json"
    if [[ -f "$policy_file" ]]; then
        cat "$policy_file"
        return 0
    fi
    return 1
}

# カスタムフェーズレベル設定
aig_set_phase_level() {
    local phase="$1"
    local level="$2"  # 0-3
    AIG_PHASE_LEVEL["$phase"]=$level
}

# カスタムドメインリスク設定
aig_set_domain_risk() {
    local domain="$1"
    local risk="$2"  # 0-3
    AIG_DOMAIN_RISK["$domain"]=$risk
}

# ============================================================
# AI出力の安全性検証
# ============================================================
aig_validate_output() {
    local output="$1"
    local phase="${2:-implementation}"
    local domain="${3:-general}"

    local violations=0
    local warnings=""

    # --- 機密情報漏洩チェック ---
    if echo "$output" | grep -qiE '(api.key|secret.key|password\s*=|private.key|aws_access)' 2>/dev/null; then
        violations=$((violations + 1))
        warnings+="  - 機密情報（APIキー/パスワード/秘密鍵）がハードコードされている可能性\n"
    fi

    # --- SQL Injection脆弱性チェック ---
    if echo "$output" | grep -qE '\$\{.*\}.*FROM|query\(`.*\$\{' 2>/dev/null; then
        violations=$((violations + 1))
        warnings+="  - SQLインジェクション脆弱性の可能性（テンプレートリテラルを直接SQLに使用）\n"
    fi

    # --- 危険なファイル操作チェック ---
    if echo "$output" | grep -qE '(rm -rf|chmod 777|eval\(|exec\()' 2>/dev/null; then
        violations=$((violations + 1))
        warnings+="  - 危険なファイル操作またはコード実行の可能性\n"
    fi

    # --- ドメイン固有チェック ---
    local domain_risk=${AIG_DOMAIN_RISK[$domain]:-0}
    if [[ $domain_risk -ge 2 ]]; then
        # 高リスクドメインでの暗号化なしデータ処理チェック
        if echo "$output" | grep -qiE '(plain.text|unencrypted|http://)' 2>/dev/null; then
            violations=$((violations + 1))
            warnings+="  - 高リスクドメイン(${domain})で暗号化されていないデータ処理の可能性\n"
        fi
    fi

    if [[ $violations -gt 0 ]]; then
        echo -e "${YELLOW:-}[Governance] ⚠️ AI出力に${violations}件の安全性警告:${NC:-}" >&2
        echo -e "$warnings" >&2

        # 監査記録
        _aig_audit_log "$phase" "$domain" "2" "WARN" "output_validation: ${violations} violations" "0"
    fi

    return $violations
}

# ============================================================
# v109.0 Pre-call enforcement (ai_call統合用)
# ============================================================

# AI呼び出し前チェック: 予算・ドメイン承認・インテント記録
aig_enforce_pre_call() {
    local task_type="${1:-code_generation}"
    local estimated_cost="${2:-0}"
    local domain="${3:-general}"

    # --- 予算チェック ---
    local session_cost="${AIG_SESSION_TOTAL_COST:-0}"
    local max_cost="${AIG_MAX_COST:-50}"

    # 整数比較用に変換
    local cost_int session_cost_int max_cost_int
    cost_int=$(printf '%.0f' "$estimated_cost" 2>/dev/null || echo "0")
    session_cost_int=$(printf '%.0f' "$session_cost" 2>/dev/null || echo "0")
    max_cost_int=$(printf '%.0f' "$max_cost" 2>/dev/null || echo "0")

    local projected_cost=$((session_cost_int + cost_int))
    if [[ $projected_cost -gt $max_cost_int ]]; then
        echo -e "${RED:-}[Governance] Pre-call BLOCKED: projected cost \$${projected_cost} exceeds limit \$${max_cost_int}${NC:-}" >&2
        _aig_audit_log "$task_type" "$domain" "3" "BLOCKED" "cost_limit_exceeded: projected=${projected_cost}, limit=${max_cost_int}" "$estimated_cost"
        AIG_BLOCKED=$((AIG_BLOCKED + 1))
        return 1
    fi

    # --- ドメイン承認チェック ---
    local domain_risk=${AIG_DOMAIN_RISK[$domain]:-0}
    if [[ $domain_risk -ge 3 && "${AIG_AUTO_APPROVE:-true}" != "true" ]]; then
        echo -e "${RED:-}[Governance] Pre-call BLOCKED: domain '${domain}' requires human approval (risk=${domain_risk})${NC:-}" >&2
        _aig_audit_log "$task_type" "$domain" "$domain_risk" "BLOCKED" "domain_risk_high" "$estimated_cost"
        AIG_BLOCKED=$((AIG_BLOCKED + 1))
        return 1
    fi

    # --- インテント記録 ---
    aig_audit_log "PRE_CALL" "${AIP_PROVIDER:-claude-cli}" "$task_type" "" "" "0" "$estimated_cost"

    AIG_TOTAL_DECISIONS=$((AIG_TOTAL_DECISIONS + 1))
    AIG_APPROVED=$((AIG_APPROVED + 1))
    return 0
}

# ============================================================
# v109.0 拡張監査ログ（公開API）
# ============================================================

# 不変監査レコードを追記
aig_audit_log() {
    local event_type="${1:-UNKNOWN}"
    local provider="${2:-unknown}"
    local task="${3:-}"
    local input_hash="${4:-}"
    local output_hash="${5:-}"
    local quality_score="${6:-0}"
    local cost="${7:-0}"

    local audit_file="${AIG_AUDIT_DIR:-${AIG_BASE_DIR}/audit}/governance_audit.jsonl"
    mkdir -p "$(dirname "$audit_file")" 2>/dev/null || true

    # 入力/出力ハッシュが未指定の場合、簡易ハッシュ生成
    if [[ -z "$input_hash" && -n "$task" ]]; then
        input_hash=$(printf '%s' "$task" | cksum 2>/dev/null | awk '{print $1}' || echo "0")
    fi

    local record="{\"timestamp\":\"$(date '+%Y-%m-%dT%H:%M:%S')\",\"event_type\":\"${event_type}\",\"session\":\"${SESSION_ID:-unknown}\",\"provider\":\"${provider}\",\"task\":\"${task}\",\"input_hash\":\"${input_hash:-}\",\"output_hash\":\"${output_hash:-}\",\"quality_score\":${quality_score},\"cost\":${cost}}"

    echo "$record" >> "$audit_file" 2>/dev/null || true

    # セッションコスト累計更新
    local cost_int
    cost_int=$(printf '%.0f' "$cost" 2>/dev/null || echo "0")
    AIG_SESSION_TOTAL_COST=${AIG_SESSION_TOTAL_COST:-0}
    AIG_SESSION_TOTAL_COST=$((AIG_SESSION_TOTAL_COST + cost_int))
}

# ============================================================
# v109.0 リミットエンフォースメント
# ============================================================

# セッションレベルの各種制限チェック
aig_enforce_limits() {
    local session_id="${1:-${SESSION_ID:-unknown}}"

    local max_calls="${AIG_MAX_CALLS:-100}"
    local max_cost="${AIG_MAX_COST:-50}"
    local max_files="${AIG_MAX_FILES:-500}"

    local violations=0
    local violation_details=""

    # --- 呼び出し回数チェック ---
    local total_calls=${AIP_CALL_COUNT:-0}
    if [[ $total_calls -ge $max_calls ]]; then
        violations=$((violations + 1))
        violation_details="${violation_details}  - Call limit exceeded: ${total_calls}/${max_calls}\n"
    fi

    # --- コストチェック ---
    local total_cost=${AIG_SESSION_TOTAL_COST:-0}
    local max_cost_int
    max_cost_int=$(printf '%.0f' "$max_cost" 2>/dev/null || echo "50")
    if [[ $total_cost -ge $max_cost_int ]]; then
        violations=$((violations + 1))
        violation_details="${violation_details}  - Cost limit exceeded: \$${total_cost}/\$${max_cost_int}\n"
    fi

    # --- ファイル変更数チェック ---
    local modified_files=0
    if [[ -n "${PROJECT_DIR:-}" && -d "${PROJECT_DIR:-}" ]]; then
        modified_files=$(find "${PROJECT_DIR}" -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" -o -name "*.prisma" 2>/dev/null | wc -l | tr -d ' ')
    fi
    modified_files=${modified_files:-0}
    if [[ $modified_files -ge $max_files ]]; then
        violations=$((violations + 1))
        violation_details="${violation_details}  - File limit exceeded: ${modified_files}/${max_files}\n"
    fi

    if [[ $violations -gt 0 ]]; then
        echo -e "${YELLOW:-}[Governance] Limit violations detected (${violations}):${NC:-}" >&2
        echo -e "$violation_details" >&2
        aig_audit_log "LIMIT_VIOLATION" "${AIP_PROVIDER:-unknown}" "enforce_limits" "" "" "0" "0"
        return 1
    fi

    return 0
}

# ============================================================
# v109.0 拡張コンプライアンスレポート
# ============================================================
aig_compliance_report() {
    local output_file="${1:-}"

    # --- コスト・呼び出し集計 ---
    local total_cost=${AIG_SESSION_TOTAL_COST:-0}
    local total_calls=${AIP_CALL_COUNT:-0}

    # --- 品質平均（AIPから取得） ---
    local quality_avg="N/A"
    if type -t aip_score &>/dev/null; then
        quality_avg=$(aip_score 2>/dev/null || echo "N/A")
    fi

    # --- ポリシー違反チェック ---
    local policy_violations=""
    local violation_count=0

    # コスト制限チェック
    local max_cost_int
    max_cost_int=$(printf '%.0f' "${AIG_MAX_COST:-50}" 2>/dev/null || echo "50")
    if [[ $total_cost -gt $max_cost_int ]]; then
        violation_count=$((violation_count + 1))
        policy_violations="${policy_violations}\n- Cost exceeded: \$${total_cost}/\$${max_cost_int}"
    fi

    # 呼び出し制限チェック
    if [[ $total_calls -gt ${AIG_MAX_CALLS:-100} ]]; then
        violation_count=$((violation_count + 1))
        policy_violations="${policy_violations}\n- Calls exceeded: ${total_calls}/${AIG_MAX_CALLS:-100}"
    fi

    # ブロック率チェック
    if [[ $AIG_TOTAL_DECISIONS -gt 10 ]]; then
        local block_rate=$((AIG_BLOCKED * 100 / AIG_TOTAL_DECISIONS))
        if [[ $block_rate -gt 20 ]]; then
            violation_count=$((violation_count + 1))
            policy_violations="${policy_violations}\n- High block rate: ${block_rate}% (threshold: 20%)"
        fi
    fi

    local report="# AI Governance Compliance Report
Generated: $(date '+%Y-%m-%d %H:%M:%S')
Session: ${SESSION_ID:-unknown}

## Summary
- Total AI Decisions: ${AIG_TOTAL_DECISIONS}
- Approved: ${AIG_APPROVED}
- Blocked: ${AIG_BLOCKED}
- Escalated: ${AIG_ESCALATED}
- Approval Rate: $(( AIG_TOTAL_DECISIONS > 0 ? AIG_APPROVED * 100 / AIG_TOTAL_DECISIONS : 0 ))%

## Cost & Usage
- Total AI Calls: ${total_calls}
- Total Cost: \$${total_cost}
- Quality Average: ${quality_avg}

## Policy Violations: ${violation_count}
$(if [[ $violation_count -gt 0 ]]; then echo -e "$policy_violations"; else echo "None - all policies compliant."; fi)

## Policy Configuration
### Phase Levels (0=Auto, 1=Notify, 2=Confirm, 3=Escalate)
$(for phase in "${!AIG_PHASE_LEVEL[@]}"; do echo "- ${phase}: Level ${AIG_PHASE_LEVEL[$phase]}"; done | sort)

### Domain Risk Levels
$(for domain in "${!AIG_DOMAIN_RISK[@]}"; do echo "- ${domain}: Risk ${AIG_DOMAIN_RISK[$domain]}"; done | sort)

## Limits
- Max Calls: ${AIG_MAX_CALLS:-100} (used: ${total_calls})
- Max Cost: \$${AIG_MAX_COST:-50} (used: \$${total_cost})
- Max Files: ${AIG_MAX_FILES:-500}

## Audit Trail
$(aig_audit_summary 2>/dev/null || echo 'No audit data available')
"

    if [[ -n "$output_file" ]]; then
        mkdir -p "$(dirname "$output_file")" 2>/dev/null || true
        echo "$report" > "$output_file"
        echo "Compliance report saved to: $output_file"
    else
        echo "$report"
    fi
}

# ============================================================
# シードデータ
# ============================================================
_aig_seed_policies() {
    cat > "${AIG_POLICY_DIR}/default.json" << 'EOF'
{
  "name": "default",
  "description": "Default AI governance policy",
  "version": "1.0",
  "rules": {
    "max_cost_per_call": 10.00,
    "max_cost_per_session": 999.00,
    "require_audit_for_deploy": true,
    "require_security_scan_for_production": true,
    "auto_approve_low_risk": true,
    "block_without_tests": false,
    "max_retries_before_escalate": 5
  },
  "created_at": "2026-03-21T00:00:00"
}
EOF

    cat > "${AIG_POLICY_DIR}/strict.json" << 'EOF'
{
  "name": "strict",
  "description": "Strict governance for regulated industries",
  "version": "1.0",
  "rules": {
    "max_cost_per_call": 5.00,
    "max_cost_per_session": 100.00,
    "require_audit_for_deploy": true,
    "require_security_scan_for_production": true,
    "auto_approve_low_risk": false,
    "block_without_tests": true,
    "max_retries_before_escalate": 3,
    "require_human_review_for_db_changes": true,
    "require_encryption_for_pii": true
  },
  "created_at": "2026-03-21T00:00:00"
}
EOF
}

# ============================================================
# レポート
# ============================================================
aig_report() {
    echo "=== AI Governance Engine v${AIG_VERSION} ==="
    echo "  Decisions: ${AIG_TOTAL_DECISIONS} (Approved: ${AIG_APPROVED}, Blocked: ${AIG_BLOCKED}, Escalated: ${AIG_ESCALATED})"
    echo "  Phase levels: ${#AIG_PHASE_LEVEL[@]} configured"
    echo "  Domain risks: ${#AIG_DOMAIN_RISK[@]} configured"
    echo "  Audit dir: ${AIG_AUDIT_DIR}"
}

aig_score() {
    local score=60
    [[ $AIG_TOTAL_DECISIONS -gt 0 ]] && score=$((score + 10))
    [[ -f "${AIG_POLICY_DIR}/default.json" ]] && score=$((score + 10))
    [[ -d "$AIG_AUDIT_DIR" ]] && score=$((score + 5))
    # v109.0: リミット遵守で加点
    if aig_enforce_limits "${SESSION_ID:-unknown}" 2>/dev/null; then
        score=$((score + 15))
    fi
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# ============================================================
# Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "ai-governance" \
        --version "$AIG_VERSION" \
        --description "AGI対応AIガバナンス - 承認フロー×監査証跡×ポリシーエンジン" \
        --init "aig_init" \
        --report "aig_report" \
        --score "aig_score" \
        --enable-var "ENABLE_AI_GOVERNANCE" \
        --cli-flags "--ai-governance:--no-ai-governance"
fi

# v2003.1: source時のexit codeを確実に0にする
true
