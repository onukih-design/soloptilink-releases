#!/usr/bin/env bash
# ==============================================================================
# compliance-attach.sh — 法令DBL自動アタッチ resolver (Compliance DBL Attachment)
#
# 背景(なぜ必要か):
#   domains/_compliance/ には個情法(APPI)・電帳法・インボイス・マイナンバー・GDPR・
#   下請法・建設業法・労働者派遣法 等の詳細な法令辞書(必須モデル・業務ルール・データ
#   取扱ルール・監査要件を条文番号付きで完備)が 11 本ある。ところが DBL 自動検出
#   (dbl-detect.sh) は domains/*.json (トップ階層) のみを走査し、サブ階層 _compliance/
#   には届かないため、これらの法令知識が生成ラインから物理的に切断されていた。
#   本スクリプトは「検出済みの業種ドメイン」から、適用される法令辞書(applicable_domains に
#   当該ドメインを含むもの)を逆引きでアタッチする正準 resolver。
#
# サブコマンド:
#   list                         _compliance 配下の法令辞書一覧 (framework / 適用業種数)
#   resolve <domain> [taskfile]  当該ドメインに適用される法令辞書の詳細を JSON 出力
#   digest  <domain> [taskfile]  生成プロンプトへ注入する markdown ブロックを出力
#   verify-spec <domain>         法令実装ゲート用の検証仕様 (必須概念+シグナル) を JSON 出力
#   selftest                     born-passing: 既知ドメインで適用法令が引けることを検証
#
# 入力の優先順位: 引数 <domain> > 環境変数 SOLOPTILINK_DETECTED_DBL
#   taskfile を渡すと、本文中のキーワード(個人情報/マイナンバー/電帳/インボイス 等)でも
#   横断法令を追加アタッチする(業種が未登録でも法的観点を拾えるようにするため)。
#
# kill-switch: SOLOPTILINK_COMPLIANCE_ATTACH=off で無効化(空集合を返す)
# 環境変数: SOLOPTILINK_DOMAINS_DIR (default: ~/.soloptilink/domains) — dbl-detect と同一規約
# 終了コード: 0=正常(該当0件も0) / 2=引数/設定エラー
# ==============================================================================
set -uo pipefail

SL="$HOME/.soloptilink"
DOMAINS_DIR="${SOLOPTILINK_DOMAINS_DIR:-$SL/domains}"
COMPLIANCE_DIR="$DOMAINS_DIR/_compliance"

_emit_empty() {
  # kill-switch / ディレクトリ不在時の安全な空集合 (no-op で素通り)
  local mode="$1" reason="$2"
  case "$mode" in
    resolve|verify-spec) printf '{"domain":"","applicable":[],"reason":"%s"}\n' "$reason" ;;
    digest)              : ;;  # 空文字 (注入なし)
    list)                echo "(該当なし: $reason)" ;;
  esac
}

_resolve_py() {
  # $1=mode (resolve|digest|verify-spec|list) $2=domain $3=taskfile(optional)
  local mode="$1" domain="${2:-}" taskfile="${3:-}"
  MODE="$mode" DOMAIN="$domain" TASKFILE="$taskfile" COMPLIANCE_DIR="$COMPLIANCE_DIR" python3 - <<'PY'
import os, json, glob, re

mode   = os.environ["MODE"]
domain = (os.environ.get("DOMAIN") or "").strip()
cdir   = os.environ["COMPLIANCE_DIR"]
taskfile = os.environ.get("TASKFILE") or ""
task_text = ""
if taskfile and os.path.isfile(taskfile):
    try: task_text = open(taskfile, encoding="utf-8", errors="ignore").read()
    except Exception: task_text = ""

# 横断法令をタスク本文からも拾うためのキーワード(業種未登録でも法的観点を逃さない)
TASK_KEYWORDS = {
    "appi.json":      ["個人情報", "個情法", "プライバシー", "personal data", "個人データ"],
    "mynumber.json":  ["マイナンバー", "個人番号", "特定個人情報"],
    "denchoho.json":  ["電帳法", "電子帳簿", "電子取引", "スキャナ保存"],
    "invoice.json":   ["インボイス", "適格請求書", "登録番号", "仕入税額控除"],
    "gdpr.json":      ["gdpr", "eu", "個人データ域外"],
    "hipaa.json":     ["hipaa", "phi", "医療情報(米"],
    "pci-dss.json":   ["pci", "カード番号", "クレジットカード", "決済"],
    "subcontract-act.json":     ["下請", "外注", "委託先", "下請法"],
    "worker-dispatch-act.json": ["派遣", "労働者派遣"],
    "construction-business-act.json": ["建設業", "工事", "建設業法"],
    "antique-dealer-act.json":  ["古物", "中古", "買取", "古物営業"],
}

# 外国法/特殊法: 業種一致だけでは引かず、タスク本文の明示シグナル時のみアタッチする。
# (日本ネイティブ製品の既定。例: 日本の介護に米国 HIPAA を自動適用しない)
FOREIGN = {"gdpr.json", "hipaa.json", "pci-dss.json"}

def applies(cj, fname):
    ad = cj.get("applicable_domains") or []
    task_hit = False
    if task_text:
        tl = task_text.lower()
        for kw in TASK_KEYWORDS.get(fname, []):
            if kw.lower() in tl:
                task_hit = True
                break
    if fname in FOREIGN:
        return "task" if task_hit else None
    if domain and isinstance(ad, list) and (domain in ad or "*" in ad or "all" in ad):
        return "domain"
    if task_hit:
        return "task"
    return None

# --- camelCase / snake_case トークン分割 ----------------------------------------
def tokens(s):
    s = str(s)
    parts = re.findall(r"[A-Z]+(?=[A-Z][a-z])|[A-Z]?[a-z]+|[A-Z]+|[0-9]+", s)
    return [p.lower() for p in parts if len(p) >= 3]

# 法令概念トークン → 弁別的な日本語フレーズ。
# ★単独で意味をなさない汎用語(情報/データ/記録/履歴/番号/報告/提供/取引/請求 等)は意図的に
#   除外する。これらをシグナルにすると UI テキストや無関係なフィールド名で誤爆し、法対応ゼロの
#   生成物を coverage 高判定してしまう(false-PASS の根本原因)。複合語・業務用語のみを採用する。
JA_SIG = {
    "consent":      ["同意取得", "同意管理", "同意履歴", "同意"],
    "inventory":    ["取扱台帳", "個人情報台帳", "保有個人データ"],
    "personal":     ["個人情報", "個人データ"],
    "disclosure":   ["開示請求", "開示等請求"],
    "deletion":     ["削除請求", "利用停止", "消去請求"],
    "retention":    ["保存期間", "保持期間", "保管期間"],
    "breach":       ["漏えい", "漏洩", "漏えい等報告"],
    "third":        ["第三者提供"], "party": ["第三者提供"], "provision": ["第三者提供"],
    "audit":        ["監査証跡", "監査ログ"],
    "access":       ["アクセスログ", "アクセス記録"],
    "encryption":   ["暗号化"],
    "mynumber":     ["マイナンバー", "個人番号", "特定個人情報"],
    "individual":   ["マイナンバー", "個人番号"],
    "identity":     ["本人確認"], "verification": ["本人確認"],
    "outsourcing":  ["委託先監督", "委託先"],
    "invoice":      ["適格請求書", "インボイス"],
    "registration": ["登録番号"],
    "transaction":  ["電子取引"], "electronic": ["電子取引", "電子帳簿"],
    "scanner":      ["スキャナ保存"], "book": ["電子帳簿"], "storage": ["電子保存"],
    "timestamp":    ["タイムスタンプ"],
    "subcontract":  ["下請代金", "下請事業者"],
    "dispatch":     ["派遣労働者", "派遣元", "派遣先"],
    "processed":    ["仮名加工情報", "匿名加工情報"],
}
# 説明文から拾ってよい弁別的フレーズの許可リスト(汎用語は決して入れない)
JA_DESC_ALLOW = sorted({p for ps in JA_SIG.values() for p in ps})

def signals_for(model):
    # シグナル = ①PascalCaseモデル名の完全一致(gate側で「宣言」として照合) +
    #           ②弁別的な日本語フレーズのみ。素の英語サブトークンは誤爆源なので一切採用しない。
    if isinstance(model, dict):
        name = str(model.get("name") or "")
        desc = str(model.get("description") or "")
    else:
        name, desc = str(model), ""
    sig = set()
    if name:
        sig.add(name)                       # モデル名(英語/PascalCase)の完全一致のみ
    for t in tokens(name):
        for ja in JA_SIG.get(t, []):        # 概念トークン→弁別的フレーズ(汎用語なし)
            sig.add(ja)
    for ph in JA_DESC_ALLOW:                # 説明文中の弁別的フレーズのみ追加
        if ph and ph in desc:
            sig.add(ph)
    return sorted(s for s in sig if s)

PRIVACY_FW = {"APPI", "MyNumber", "GDPR", "HIPAA"}

selected = []
for cf in sorted(glob.glob(os.path.join(cdir, "*.json"))):
    fname = os.path.basename(cf)
    try:
        cj = json.load(open(cf, encoding="utf-8"))
    except Exception:
        continue
    why = applies(cj, fname)
    if not why:
        continue
    fw = cj.get("framework") or cj.get("name") or fname[:-5]
    selected.append((fname, fw, cj, why))

# 重要度順(プライバシー系優先)に整列。digest の予算切りで MyNumber 等が無言脱落するのを防ぐ。
PRIORITY = ["appi.json", "mynumber.json", "denchoho.json", "invoice.json",
            "subcontract-act.json", "worker-dispatch-act.json",
            "construction-business-act.json", "antique-dealer-act.json",
            "gdpr.json", "hipaa.json", "pci-dss.json"]
selected.sort(key=lambda x: PRIORITY.index(x[0]) if x[0] in PRIORITY else 99)

if mode == "list":
    print(f"📋 法令辞書 (_compliance/) — domain={domain or '(未指定)'}")
    for cf in sorted(glob.glob(os.path.join(cdir, "*.json"))):
        try: cj = json.load(open(cf, encoding="utf-8"))
        except Exception: continue
        fname = os.path.basename(cf)
        ad = cj.get("applicable_domains") or []
        fw = cj.get("framework") or fname[:-5]
        # FOREIGN(外国法)はタスクシグナル無しで ★適用 表示しない: applies() に判定を一本化
        hit = "★適用" if applies(cj, fname) else "  "
        print(f"  {hit} {fw:42s} 適用業種={len(ad) if isinstance(ad,list) else '?'}")
    raise SystemExit(0)

if mode == "resolve":
    out = {"domain": domain, "applicable": []}
    for fname, fw, cj, why in selected:
        out["applicable"].append({
            "framework": fw, "dbl": fname, "matched_by": why,
            "required_models": [m.get("name") if isinstance(m, dict) else str(m)
                                for m in (cj.get("required_models") or [])],
            "business_rules": cj.get("business_rules") or [],
            "data_handling_rules": cj.get("data_handling_rules") or [],
            "audit_requirements": cj.get("audit_requirements") or [],
            "security_requirements": cj.get("security_requirements") or [],
            "is_personal_data": fw in PRIVACY_FW,
        })
    print(json.dumps(out, ensure_ascii=False, indent=1))
    raise SystemExit(0)

if mode == "verify-spec":
    out = {"domain": domain, "applicable": [], "personal_data_frameworks": []}
    for fname, fw, cj, why in selected:
        concepts = []
        for m in (cj.get("required_models") or []):
            cid = m.get("name") if isinstance(m, dict) else str(m)
            concepts.append({
                "id": cid,
                "label": (m.get("description") if isinstance(m, dict) else "") or cid,
                "signals": signals_for(m),
            })
        out["applicable"].append({
            "framework": fw, "dbl": fname, "matched_by": why,
            "is_personal_data": fw in PRIVACY_FW, "concepts": concepts,
        })
        if fw in PRIVACY_FW:
            out["personal_data_frameworks"].append(fw)
    print(json.dumps(out, ensure_ascii=False, indent=1))
    raise SystemExit(0)

if mode == "digest":
    if not selected:
        raise SystemExit(0)
    lines = ["## 該当法令の実装要件 (該当する日本法/規制。必須モデルを Prisma に実装し、同意取得・"
             "保有データの開示/訂正/利用停止・保持/削除・アクセスログ・監査証跡を画面と API に落とすこと。"
             "条文番号は根拠として保持)"]
    # ★全該当法令の「法令名+必須モデル」は予算に依らず必ず出す(優先度順の予算切りで MyNumber 等が
    #   無言脱落するのを防ぐ=FIND-002)。ルール詳細のみ予算(肥大化抑制)内で優先順に追記する。
    rule_budget, used = 1600, 0
    for fname, fw, cj, why in selected:
        rm = [m.get("name") if isinstance(m, dict) else str(m) for m in (cj.get("required_models") or [])]
        rm = [str(x)[:40] for x in rm if x][:8]
        head = f"### {fw}"
        if rm:
            head += "\n必須モデル: " + ", ".join(rm)
        lines.append(head)
        for key, label in (("business_rules", "業務ルール"),
                           ("data_handling_rules", "データ取扱ルール"),
                           ("audit_requirements", "監査要件")):
            vals = cj.get(key) or []
            if isinstance(vals, list) and vals:
                rline = f"{label}: " + " / ".join(str(v)[:90] for v in vals[:4])
                if used + len(rline) + 1 <= rule_budget:
                    lines.append(rline); used += len(rline) + 1
    print("\n".join(lines))
    raise SystemExit(0)
PY
}

_selftest() {
  # born-passing: 既知の適用業種(long-term-care=APPI適用)で法令が引け、無関係ドメインでは引けないことを弁別
  local v_hit v_miss
  if [[ ! -d "$COMPLIANCE_DIR" ]]; then
    echo "  ❌ _compliance ディレクトリ不在: $COMPLIANCE_DIR"; return 1
  fi
  v_hit=$(_resolve_py resolve "long-term-care" "" | python3 -c "import sys,json;print(len(json.load(sys.stdin)['applicable']))" 2>/dev/null || echo 0)
  v_miss=$(_resolve_py resolve "__no_such_domain__" "" | python3 -c "import sys,json;print(len(json.load(sys.stdin)['applicable']))" 2>/dev/null || echo -1)
  echo "  適用業種(long-term-care)で引けた法令数=$v_hit (期待 >=1)"
  echo "  無関係ドメインで引けた法令数=$v_miss (期待 0)"
  if [[ "$v_hit" -ge 1 && "$v_miss" -eq 0 ]]; then
    echo "  ✅ born-passing OK: 適用は引け/非適用は引かない を弁別"; return 0
  else
    echo "  ❌ born-passing NG"; return 1
  fi
}

# --- dispatch (selftest は kill-switch の影響を受けず常に弁別を実行) ------------
CMD="${1:-list}"
if [[ "$CMD" == "selftest" ]]; then _selftest; exit $?; fi
# --- kill-switch / ディレクトリガード -------------------------------------------
if [[ "${SOLOPTILINK_COMPLIANCE_ATTACH:-on}" == "off" ]]; then
  _emit_empty "${CMD}" "kill-switch(SOLOPTILINK_COMPLIANCE_ATTACH=off)"; exit 0
fi
if [[ ! -d "$COMPLIANCE_DIR" ]]; then
  _emit_empty "${CMD}" "_compliance dir 不在"; exit 0
fi

case "$CMD" in
  list)        _resolve_py list "${2:-${SOLOPTILINK_DETECTED_DBL:-}}" "${3:-}" ;;
  resolve)     _resolve_py resolve "${2:-${SOLOPTILINK_DETECTED_DBL:-}}" "${3:-}" ;;
  digest)      _resolve_py digest "${2:-${SOLOPTILINK_DETECTED_DBL:-}}" "${3:-}" ;;
  verify-spec) _resolve_py verify-spec "${2:-${SOLOPTILINK_DETECTED_DBL:-}}" "${3:-}" ;;
  selftest)    _selftest ;;
  *) echo "usage: compliance-attach.sh {list|resolve|digest|verify-spec|selftest} <domain> [taskfile]" >&2; exit 2 ;;
esac
