#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v462.0 - Streaming SSR Engine
# =============================================================================
# ストリーミングSSR: React Server Components streaming、Suspense境界、TTFB最適化。
#
# Functions:
#   _ssr_init()                         - Initialize
#   _ssr_generate_streaming()           - Streaming SSR configuration
#   _ssr_generate_suspense_boundaries() - Suspense boundary placement
#   _ssr_optimize_ttfb()                - Time to First Byte optimization
#   _ssr_report() / _ssr_score()
# =============================================================================

[[ -n "${_SSR_LOADED:-}" ]] && return 0; _SSR_LOADED=1

declare -g SSR_VERSION="462.0"
SSR_GENERATED=0; SSR_ERRORS=0; SSR_FILES_WRITTEN=0
SSR_STREAMING_OK=false; SSR_SUSPENSE_OK=false; SSR_TTFB_OK=false

_ssr_init() {
    SSR_GENERATED=0; SSR_ERRORS=0; SSR_FILES_WRITTEN=0
    SSR_STREAMING_OK=false; SSR_SUSPENSE_OK=false; SSR_TTFB_OK=false
    return 0
}

_ssr_log() { echo -e "  ${CYAN:-\033[0;36m}[streaming-ssr]${NC:-\033[0m} $*" >&2; }
_ssr_ok()  { echo -e "  ${GREEN:-\033[0;32m}✅ [streaming-ssr]${NC:-\033[0m} $*" >&2; }
_ssr_err() { echo -e "  ${RED:-\033[0;31m}❌ [streaming-ssr]${NC:-\033[0m} $*" >&2; SSR_ERRORS=$((SSR_ERRORS + 1)); }

_ssr_write_file() {
    local filepath="$1" content="$2"
    local dir; dir="$(dirname "$filepath")"
    [[ -d "$dir" ]] || mkdir -p "$dir"
    echo "$content" > "$filepath" 2>/dev/null || { _ssr_err "Failed to write $filepath"; return 1; }
    SSR_FILES_WRITTEN=$((SSR_FILES_WRITTEN + 1))
    return 0
}

_ssr_generate_streaming() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/ssr/streaming-config.ts"
    _ssr_log "Generating streaming SSR configuration..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v462.0 - Streaming SSR Configuration

export interface StreamingSSRConfig {
  enableStreaming: boolean;
  flushThreshold: number;       // bytes before flush
  timeoutMs: number;            // max wait before streaming shell
  progressiveHydration: boolean;
  selectiveHydration: boolean;
}

const DEFAULT_CONFIG: StreamingSSRConfig = {
  enableStreaming: true,
  flushThreshold: 4096,
  timeoutMs: 5000,
  progressiveHydration: true,
  selectiveHydration: true,
};

export interface StreamingSegment {
  id: string;
  priority: 'critical' | 'high' | 'normal' | 'low';
  dataFetcher: string;            // function name or API path
  fallbackComponent: string;
  estimatedMs: number;
}

export class StreamingSSREngine {
  private config: StreamingSSRConfig;
  private segments: StreamingSegment[] = [];

  constructor(config?: Partial<StreamingSSRConfig>) {
    this.config = { ...DEFAULT_CONFIG, ...config };
  }

  addSegment(segment: StreamingSegment): void {
    this.segments.push(segment);
  }

  getStreamOrder(): StreamingSegment[] {
    const priorityOrder = { critical: 0, high: 1, normal: 2, low: 3 };
    return [...this.segments].sort((a, b) => priorityOrder[a.priority] - priorityOrder[b.priority]);
  }

  generateLoadingStrategy(): Record<string, string> {
    const strategy: Record<string, string> = {};
    for (const seg of this.segments) {
      if (seg.priority === 'critical') strategy[seg.id] = 'blocking';
      else if (seg.priority === 'high') strategy[seg.id] = 'streaming';
      else strategy[seg.id] = 'deferred';
    }
    return strategy;
  }

  generateNextConfig(): Record<string, unknown> {
    return {
      experimental: {
        serverActions: { bodySizeLimit: '2mb' },
        ppr: this.config.enableStreaming,
      },
    };
  }

  getConfig(): StreamingSSRConfig { return this.config; }
}

export const streamingSSR = new StreamingSSREngine();
TYPESCRIPT
)
    _ssr_write_file "$outfile" "$content" || return 1
    SSR_STREAMING_OK=true
    SSR_GENERATED=$((SSR_GENERATED + 1))
    _ssr_ok "Streaming SSR configuration generated"
    return 0
}

_ssr_generate_suspense_boundaries() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/ssr/suspense-strategy.ts"
    _ssr_log "Generating Suspense boundary strategy..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v462.0 - SSR Suspense Boundary Strategy
import React, { Suspense } from 'react';

export interface SuspenseBoundaryPlacement {
  componentPath: string;
  wrapComponent: boolean;
  reason: string;
  fallbackType: 'skeleton' | 'spinner' | 'placeholder' | 'none';
}

const PLACEMENT_RULES: Array<{ pattern: RegExp; fallbackType: SuspenseBoundaryPlacement['fallbackType']; reason: string }> = [
  { pattern: /DataTable|DataGrid/i, fallbackType: 'skeleton', reason: 'Tables should show skeleton while loading' },
  { pattern: /Chart|Graph|Analytics/i, fallbackType: 'skeleton', reason: 'Charts need skeleton placeholders' },
  { pattern: /UserProfile|Avatar/i, fallbackType: 'placeholder', reason: 'User info can show placeholder' },
  { pattern: /Comments|Feed|Timeline/i, fallbackType: 'skeleton', reason: 'Lists benefit from skeleton loading' },
  { pattern: /Sidebar|Navigation/i, fallbackType: 'none', reason: 'Navigation should be in the shell' },
  { pattern: /Modal|Dialog/i, fallbackType: 'spinner', reason: 'Modals can show simple spinner' },
];

export class SuspenseStrategyEngine {
  analyzePlacement(componentName: string, componentPath: string): SuspenseBoundaryPlacement {
    for (const rule of PLACEMENT_RULES) {
      if (rule.pattern.test(componentName)) {
        return { componentPath, wrapComponent: true, reason: rule.reason, fallbackType: rule.fallbackType };
      }
    }
    return { componentPath, wrapComponent: false, reason: 'No specific rule matched', fallbackType: 'none' };
  }

  generateSkeletonComponent(name: string, lines = 5): string {
    return `export function ${name}Skeleton() {\n  return (\n    <div className="animate-pulse space-y-3 p-4">\n      ${Array(lines).fill(0).map((_, i) => `<div className="h-4 bg-gray-200 rounded w-${['full', '3/4', '1/2', '5/6', '2/3'][i % 5]}" />`).join('\n      ')}\n    </div>\n  );\n}`;
  }
}

export const suspenseStrategy = new SuspenseStrategyEngine();
TYPESCRIPT
)
    _ssr_write_file "$outfile" "$content" || return 1
    SSR_SUSPENSE_OK=true
    SSR_GENERATED=$((SSR_GENERATED + 1))
    _ssr_ok "Suspense strategy generated"
    return 0
}

_ssr_optimize_ttfb() {
    local project_dir="${1:-.}"
    local outfile="${project_dir}/lib/ssr/ttfb-optimizer.ts"
    _ssr_log "Generating TTFB optimizer..."

    local content
    content=$(cat <<'TYPESCRIPT'
// SoloptiLinkAI v462.0 - Time to First Byte Optimizer

export interface TTFBOptimization {
  name: string;
  category: 'caching' | 'compute' | 'network' | 'data';
  impact: 'high' | 'medium' | 'low';
  implementation: string;
}

const OPTIMIZATIONS: TTFBOptimization[] = [
  { name: 'Edge Runtime', category: 'network', impact: 'high', implementation: "export const runtime = 'edge';" },
  { name: 'Static Shell', category: 'compute', impact: 'high', implementation: 'Move static layout to generateStaticParams' },
  { name: 'Parallel Data Fetching', category: 'data', impact: 'high', implementation: 'Use Promise.all for independent queries' },
  { name: 'Response Caching', category: 'caching', impact: 'medium', implementation: "export const revalidate = 60; // ISR" },
  { name: 'Connection Pooling', category: 'data', impact: 'medium', implementation: 'Use PrismaClient singleton with connection pool' },
  { name: 'Precomputed Data', category: 'compute', impact: 'medium', implementation: 'Precompute aggregations in background jobs' },
  { name: 'CDN Cache Headers', category: 'caching', impact: 'high', implementation: "headers: [{ 'CDN-Cache-Control': 's-maxage=60' }]" },
  { name: 'Database Indexes', category: 'data', impact: 'high', implementation: 'Add indexes on frequently queried columns' },
];

export class TTFBOptimizer {
  analyze(currentTTFBMs: number): TTFBOptimization[] {
    if (currentTTFBMs < 200) return OPTIMIZATIONS.filter(o => o.impact === 'low');
    if (currentTTFBMs < 500) return OPTIMIZATIONS.filter(o => o.impact !== 'low');
    return OPTIMIZATIONS;
  }

  getAll(): TTFBOptimization[] { return OPTIMIZATIONS; }

  estimateImprovement(optimizations: TTFBOptimization[]): number {
    const impactMap = { high: 30, medium: 15, low: 5 };
    return optimizations.reduce((total, o) => total + impactMap[o.impact], 0);
  }
}

export const ttfbOptimizer = new TTFBOptimizer();
TYPESCRIPT
)
    _ssr_write_file "$outfile" "$content" || return 1
    SSR_TTFB_OK=true
    SSR_GENERATED=$((SSR_GENERATED + 1))
    _ssr_ok "TTFB optimizer generated"
    return 0
}

_ssr_generate_all() {
    local project_dir="${1:-.}"
    _ssr_generate_streaming "$project_dir"
    _ssr_generate_suspense_boundaries "$project_dir"
    _ssr_optimize_ttfb "$project_dir"
    _ssr_ok "Streaming SSR complete: ${SSR_GENERATED} components, ${SSR_ERRORS} errors"
}

_ssr_report() {
    echo -e "\n  ${BOLD:-\033[1m}═══ Streaming SSR v${SSR_VERSION} ═══${NC:-\033[0m}"
    echo -e "  Generated  : ${SSR_GENERATED}"
    echo -e "  Errors     : ${SSR_ERRORS}"
    echo -e "  Streaming  : ${SSR_STREAMING_OK}"
    echo -e "  Suspense   : ${SSR_SUSPENSE_OK}"
    echo -e "  TTFB       : ${SSR_TTFB_OK}"
}

_ssr_score() {
    local score=50
    ${SSR_STREAMING_OK} && score=$((score + 15))
    ${SSR_SUSPENSE_OK} && score=$((score + 15))
    ${SSR_TTFB_OK} && score=$((score + 15))
    [[ ${SSR_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "streaming-ssr" --version "462.0" \
        --description "ストリーミングSSR: React Server Components×Suspense×TTFB最適化" \
        --init "_ssr_init" --report "_ssr_report" --score "_ssr_score" \
        --enable-var "ENABLE_STREAMING_SSR" --cli-flags "--streaming-ssr:--no-streaming-ssr"
fi

# v2003.1: source時のexit codeを確実に0にする
true
