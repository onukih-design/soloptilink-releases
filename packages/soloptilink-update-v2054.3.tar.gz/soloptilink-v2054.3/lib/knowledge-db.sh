#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v100.0 - Knowledge DB
# 全セッションの知見を蓄積し、RAG検索でプロンプトに注入
# 将来のファインチューニング用データ基盤
#
# 収集対象:
#   1. エラー→修正パターン (error_fix)
#   2. 成功プロンプト×品質スコア (prompt_score)
#   3. ドメイン別ベストプラクティス (domain_practice)
#   4. フェーズ別成功/失敗記録 (phase_result)
#
# 検索方式: キーワードベースTF-IDF的マッチング（Bash実装）
# 将来: ベクトル検索（embeddings API）に移行可能
# ============================================================

[[ -n "${_KDB_LOADED:-}" ]] && return 0; _KDB_LOADED=1

# --- 設定 ---
KDB_VERSION="1.0.0"
KDB_BASE_DIR="${HOME}/.soloptilink/knowledge-db"
KDB_PATTERNS_DIR="${KDB_BASE_DIR}/patterns"
KDB_PROMPTS_DIR="${KDB_BASE_DIR}/prompts"
KDB_SCORES_DIR="${KDB_BASE_DIR}/scores"
KDB_DOMAINS_DIR="${KDB_BASE_DIR}/domains"
KDB_EXPORT_DIR="${KDB_BASE_DIR}/export"
KDB_INDEX_FILE="${KDB_BASE_DIR}/index.json"

# 統計
KDB_RECORDS_ADDED=0
KDB_QUERIES_MADE=0
KDB_INJECTIONS_MADE=0
KDB_TOTAL_RECORDS=0

# --- 初期化 ---
kdb_init() {
    KDB_RECORDS_ADDED=0
    KDB_QUERIES_MADE=0
    KDB_INJECTIONS_MADE=0

    # ディレクトリ構造作成
    mkdir -p "$KDB_PATTERNS_DIR" "$KDB_PROMPTS_DIR" "$KDB_SCORES_DIR" \
             "$KDB_DOMAINS_DIR" "$KDB_EXPORT_DIR" 2>/dev/null

    # インデックスファイル初期化
    if [[ ! -f "$KDB_INDEX_FILE" ]]; then
        echo '{"version":"'"$KDB_VERSION"'","created":"'"$(date -u +%Y-%m-%dT%H:%M:%SZ)"'","records":0,"categories":{}}' > "$KDB_INDEX_FILE"
    fi

    # 既存レコード数カウント
    KDB_TOTAL_RECORDS=$(find "$KDB_BASE_DIR" -name "*.json" -not -name "index.json" 2>/dev/null | wc -l)
    KDB_TOTAL_RECORDS=$(echo "$KDB_TOTAL_RECORDS" | tr -d ' ')

    return 0
}

# ============================================================
# 収集: エラー→修正パターン記録
# cb2_call失敗時、healer修正成功時に呼ばれる
# ============================================================
kdb_record_error_fix() {
    local error_type="$1"      # e.g., "typescript_error", "import_not_found"
    local error_message="$2"   # 元のエラーメッセージ
    local fix_description="$3" # 修正内容の要約
    local domain="${4:-general}"
    local phase="${5:-unknown}"

    [[ -z "$error_type" || -z "$error_message" ]] && return 1

    local record_id="ef_$(date +%s)_${RANDOM}"
    local record_file="${KDB_PATTERNS_DIR}/${record_id}.json"

    # エラーメッセージのハッシュ（重複検出用）
    local error_hash
    error_hash=$(echo "$error_message" | head -c 200 | md5sum 2>/dev/null | cut -c1-16 || echo "$RANDOM")

    # 重複チェック: 同じエラーハッシュが既にあればスキップ
    if grep -rl "\"error_hash\":\"${error_hash}\"" "$KDB_PATTERNS_DIR" 2>/dev/null | head -1 | grep -q .; then
        return 0  # 重複 → 記録不要
    fi

    python3 -c "
import json, sys
record = {
    'id': '$record_id',
    'type': 'error_fix',
    'error_type': '$error_type',
    'error_hash': '$error_hash',
    'error_message': sys.stdin.read().strip()[:500],
    'fix_description': '''$fix_description'''[:500],
    'domain': '$domain',
    'phase': '$phase',
    'timestamp': '$(date -u +%Y-%m-%dT%H:%M:%SZ)',
    'success_count': 1
}
with open('$record_file', 'w') as f:
    json.dump(record, f, ensure_ascii=False, indent=2)
" <<< "$error_message" 2>/dev/null || return 1

    KDB_RECORDS_ADDED=$((KDB_RECORDS_ADDED + 1))
    return 0
}

# ============================================================
# 収集: 成功プロンプト×品質スコア記録
# quality-gate通過後に呼ばれる
# ============================================================
kdb_record_prompt_score() {
    local phase="$1"
    local domain="$2"
    local quality_score="$3"
    local prompt_summary="$4"  # プロンプトの要約（先頭500文字）

    [[ -z "$phase" || -z "$quality_score" ]] && return 1
    [[ "$quality_score" -lt 60 ]] && return 0  # 低品質は記録しない

    local record_id="ps_$(date +%s)_${RANDOM}"
    local record_file="${KDB_PROMPTS_DIR}/${record_id}.json"

    python3 -c "
import json, sys
record = {
    'id': '$record_id',
    'type': 'prompt_score',
    'phase': '$phase',
    'domain': '$domain',
    'quality_score': $quality_score,
    'prompt_summary': sys.stdin.read().strip()[:500],
    'timestamp': '$(date -u +%Y-%m-%dT%H:%M:%SZ)'
}
with open('$record_file', 'w') as f:
    json.dump(record, f, ensure_ascii=False, indent=2)
" <<< "$prompt_summary" 2>/dev/null || return 1

    KDB_RECORDS_ADDED=$((KDB_RECORDS_ADDED + 1))
    return 0
}

# ============================================================
# 収集: ドメイン別ベストプラクティス記録
# 高品質(score>=80)の生成結果からパターン抽出
# ============================================================
kdb_record_domain_practice() {
    local domain="$1"
    local practice_type="$2"   # e.g., "prisma_schema", "api_pattern", "component_structure"
    local practice_content="$3"
    local quality_score="${4:-80}"

    [[ -z "$domain" || -z "$practice_content" ]] && return 1

    local record_id="dp_$(date +%s)_${RANDOM}"
    local record_file="${KDB_DOMAINS_DIR}/${domain}_${record_id}.json"

    python3 -c "
import json, sys
record = {
    'id': '$record_id',
    'type': 'domain_practice',
    'domain': '$domain',
    'practice_type': '$practice_type',
    'content': sys.stdin.read().strip()[:2000],
    'quality_score': $quality_score,
    'timestamp': '$(date -u +%Y-%m-%dT%H:%M:%SZ)',
    'usage_count': 0
}
with open('$record_file', 'w') as f:
    json.dump(record, f, ensure_ascii=False, indent=2)
" <<< "$practice_content" 2>/dev/null || return 1

    KDB_RECORDS_ADDED=$((KDB_RECORDS_ADDED + 1))
    return 0
}

# ============================================================
# 収集: フェーズ別成功/失敗記録
# 各フェーズ完了時に呼ばれる
# ============================================================
kdb_record_phase_result() {
    local phase="$1"
    local domain="$2"
    local success="$3"    # true/false
    local duration="$4"   # 秒
    local details="$5"    # 追加情報

    local record_id="pr_$(date +%s)_${RANDOM}"
    local record_file="${KDB_SCORES_DIR}/${record_id}.json"

    python3 -c "
import json
record = {
    'id': '$record_id',
    'type': 'phase_result',
    'phase': '$phase',
    'domain': '$domain',
    'success': $( [[ "$success" == "true" ]] && echo "true" || echo "false" ),
    'duration_sec': ${duration:-0},
    'details': '''${details:-}'''[:500],
    'timestamp': '$(date -u +%Y-%m-%dT%H:%M:%SZ)'
}
with open('$record_file', 'w') as f:
    json.dump(record, f, ensure_ascii=False, indent=2)
" 2>/dev/null || return 1

    KDB_RECORDS_ADDED=$((KDB_RECORDS_ADDED + 1))
    return 0
}

# ============================================================
# RAG検索: エラーメッセージから類似修正パターンを検索
# ============================================================
kdb_search_error_fixes() {
    local error_message="$1"
    local max_results="${2:-3}"

    KDB_QUERIES_MADE=$((KDB_QUERIES_MADE + 1))

    [[ ! -d "$KDB_PATTERNS_DIR" ]] && return 0
    local pattern_files
    pattern_files=$(find "$KDB_PATTERNS_DIR" -name "*.json" 2>/dev/null)
    [[ -z "$pattern_files" ]] && return 0

    # キーワード抽出（エラーメッセージから重要語を取得）
    local keywords
    keywords=$(echo "$error_message" | tr '[:upper:]' '[:lower:]' | \
        grep -oE '[a-z_]+Error|Cannot find|is not assignable|unexpected token|Module not found|import.*from|undefined|null' | \
        head -5 | tr '\n' '|' | sed 's/|$//')

    [[ -z "$keywords" ]] && keywords=$(echo "$error_message" | head -c 100)

    # マッチングスコア計算してソート
    python3 -c "
import json, os, re, sys

keywords = '''$keywords'''.split('|')
pattern_dir = '$KDB_PATTERNS_DIR'
results = []

for fname in os.listdir(pattern_dir):
    if not fname.endswith('.json'):
        continue
    try:
        with open(os.path.join(pattern_dir, fname)) as f:
            record = json.load(f)
        error_msg = record.get('error_message', '').lower()
        fix_desc = record.get('fix_description', '')
        score = 0
        for kw in keywords:
            if kw and kw.lower() in error_msg:
                score += 10
        score += record.get('success_count', 0) * 2
        if score > 0:
            results.append((score, fix_desc, record.get('error_type', ''), record.get('domain', '')))
    except:
        continue

results.sort(key=lambda x: -x[0])
for score, fix, etype, domain in results[:$max_results]:
    print(f'[{etype}@{domain}] {fix}')
" 2>/dev/null
}

# ============================================================
# RAG検索: ドメイン別ベストプラクティス検索
# ============================================================
kdb_search_domain_practices() {
    local domain="$1"
    local practice_type="${2:-}"
    local max_results="${3:-5}"

    KDB_QUERIES_MADE=$((KDB_QUERIES_MADE + 1))

    [[ ! -d "$KDB_DOMAINS_DIR" ]] && return 0

    python3 -c "
import json, os

domain = '$domain'
ptype = '$practice_type'
domain_dir = '$KDB_DOMAINS_DIR'
results = []

for fname in os.listdir(domain_dir):
    if not fname.endswith('.json'):
        continue
    if domain != 'all' and not fname.startswith(domain + '_'):
        continue
    try:
        with open(os.path.join(domain_dir, fname)) as f:
            record = json.load(f)
        if ptype and record.get('practice_type') != ptype:
            continue
        results.append((record.get('quality_score', 0), record.get('content', ''), record.get('practice_type', '')))
    except:
        continue

results.sort(key=lambda x: -x[0])
for score, content, pt in results[:$max_results]:
    print(f'### {pt} (score={score})')
    print(content[:500])
    print()
" 2>/dev/null
}

# ============================================================
# RAG検索: 成功プロンプト検索（同じドメイン×フェーズ）
# ============================================================
kdb_search_successful_prompts() {
    local phase="$1"
    local domain="$2"
    local max_results="${3:-2}"

    KDB_QUERIES_MADE=$((KDB_QUERIES_MADE + 1))

    [[ ! -d "$KDB_PROMPTS_DIR" ]] && return 0

    python3 -c "
import json, os

phase = '$phase'
domain = '$domain'
prompts_dir = '$KDB_PROMPTS_DIR'
results = []

for fname in os.listdir(prompts_dir):
    if not fname.endswith('.json'):
        continue
    try:
        with open(os.path.join(prompts_dir, fname)) as f:
            record = json.load(f)
        if record.get('phase') != phase:
            continue
        domain_match = 1 if record.get('domain') == domain else 0
        score = record.get('quality_score', 0) + domain_match * 20
        results.append((score, record.get('prompt_summary', '')))
    except:
        continue

results.sort(key=lambda x: -x[0])
for score, summary in results[:$max_results]:
    print(f'[score={score}] {summary[:300]}')
    print()
" 2>/dev/null
}

# ============================================================
# プロンプト注入: 全知見をまとめてプロンプトに注入可能な形で返す
# cb2_build_append_system_prompt() から呼ばれる
# ============================================================
kdb_build_injection() {
    local phase="$1"
    local domain="$2"
    local error_context="${3:-}"

    local injection=""

    # 1. エラーコンテキストがあれば修正パターン検索
    if [[ -n "$error_context" ]]; then
        local fixes
        fixes=$(kdb_search_error_fixes "$error_context" 3 2>/dev/null)
        if [[ -n "$fixes" ]]; then
            injection+="
=== Knowledge DB: 過去の類似エラー修正パターン ===
${fixes}
"
            KDB_INJECTIONS_MADE=$((KDB_INJECTIONS_MADE + 1))
        fi
    fi

    # 2. ドメイン別ベストプラクティス
    local practices
    practices=$(kdb_search_domain_practices "$domain" "" 3 2>/dev/null)
    if [[ -n "$practices" ]]; then
        injection+="
=== Knowledge DB: ${domain}ドメイン ベストプラクティス ===
${practices}
"
        KDB_INJECTIONS_MADE=$((KDB_INJECTIONS_MADE + 1))
    fi

    # 3. 成功プロンプト参照（品質の高いものを参考として提示）
    local prompts
    prompts=$(kdb_search_successful_prompts "$phase" "$domain" 1 2>/dev/null)
    if [[ -n "$prompts" ]]; then
        injection+="
=== Knowledge DB: 過去の高品質生成パターン（参考） ===
${prompts}
"
        KDB_INJECTIONS_MADE=$((KDB_INJECTIONS_MADE + 1))
    fi

    echo "$injection"
}

# ============================================================
# エクスポート: ファインチューニング用JSONL生成
# Claude API fine-tuning形式に変換
# ============================================================
kdb_export_for_finetuning() {
    local output_file="${1:-${KDB_EXPORT_DIR}/training_data_$(date +%Y%m%d).jsonl}"

    python3 -c "
import json, os, glob

base_dir = '$KDB_BASE_DIR'
output_file = '$output_file'
records = []

# 全JSONレコードを読み込み
for dirpath in ['patterns', 'prompts', 'scores', 'domains']:
    full_dir = os.path.join(base_dir, dirpath)
    if not os.path.isdir(full_dir):
        continue
    for fname in os.listdir(full_dir):
        if not fname.endswith('.json'):
            continue
        try:
            with open(os.path.join(full_dir, fname)) as f:
                record = json.load(f)
            records.append(record)
        except:
            continue

# ファインチューニング用JSONL形式に変換
# Anthropic Messages API format: {'messages': [{'role': 'user', 'content': ...}, {'role': 'assistant', 'content': ...}]}
training_lines = []

for r in records:
    rtype = r.get('type', '')

    if rtype == 'error_fix':
        user_msg = f\"\"\"以下のエラーを修正してください:
エラー種別: {r.get('error_type', '')}
エラーメッセージ: {r.get('error_message', '')}
ドメイン: {r.get('domain', '')}\"\"\"
        assistant_msg = r.get('fix_description', '')
        if user_msg and assistant_msg:
            training_lines.append({
                'messages': [
                    {'role': 'user', 'content': user_msg},
                    {'role': 'assistant', 'content': assistant_msg}
                ],
                'metadata': {'type': 'error_fix', 'domain': r.get('domain', '')}
            })

    elif rtype == 'prompt_score' and r.get('quality_score', 0) >= 80:
        # 高品質プロンプトのみ
        training_lines.append({
            'messages': [
                {'role': 'user', 'content': f\"Generate high-quality code for phase={r.get('phase','')} domain={r.get('domain','')}\"},
                {'role': 'assistant', 'content': r.get('prompt_summary', '')}
            ],
            'metadata': {'type': 'high_quality_prompt', 'score': r.get('quality_score', 0)}
        })

    elif rtype == 'domain_practice':
        training_lines.append({
            'messages': [
                {'role': 'user', 'content': f\"{r.get('domain','')}ドメインの{r.get('practice_type','')}のベストプラクティスを教えてください\"},
                {'role': 'assistant', 'content': r.get('content', '')}
            ],
            'metadata': {'type': 'domain_practice', 'domain': r.get('domain', '')}
        })

# JSONL書き出し
os.makedirs(os.path.dirname(output_file), exist_ok=True)
with open(output_file, 'w', encoding='utf-8') as f:
    for line in training_lines:
        f.write(json.dumps(line, ensure_ascii=False) + '\\n')

print(f'エクスポート完了: {len(training_lines)}レコード → {output_file}')
print(f'  error_fix: {sum(1 for l in training_lines if l[\"metadata\"][\"type\"]==\"error_fix\")}')
print(f'  high_quality_prompt: {sum(1 for l in training_lines if l[\"metadata\"][\"type\"]==\"high_quality_prompt\")}')
print(f'  domain_practice: {sum(1 for l in training_lines if l[\"metadata\"][\"type\"]==\"domain_practice\")}')
" 2>/dev/null
}

# ============================================================
# 統計: Knowledge DB の現状レポート
# ============================================================
kdb_stats() {
    python3 -c "
import os, json

base_dir = '$KDB_BASE_DIR'
stats = {'patterns': 0, 'prompts': 0, 'scores': 0, 'domains': 0}

for category in stats:
    d = os.path.join(base_dir, category)
    if os.path.isdir(d):
        stats[category] = len([f for f in os.listdir(d) if f.endswith('.json')])

total = sum(stats.values())
print(f'Knowledge DB v$KDB_VERSION')
print(f'  エラー修正パターン : {stats[\"patterns\"]}件')
print(f'  成功プロンプト     : {stats[\"prompts\"]}件')
print(f'  フェーズ結果       : {stats[\"scores\"]}件')
print(f'  ドメイン知見       : {stats[\"domains\"]}件')
print(f'  合計               : {total}件')
" 2>/dev/null
}

# ============================================================
# レポート / スコア
# ============================================================
kdb_report() {
    echo -e "\n  ${BOLD:-}═══ Knowledge DB v${KDB_VERSION} レポート ═══${NC:-}"
    echo -e "  蓄積レコード数     : ${KDB_TOTAL_RECORDS}"
    echo -e "  今回追加           : ${KDB_RECORDS_ADDED}"
    echo -e "  検索クエリ数       : ${KDB_QUERIES_MADE}"
    echo -e "  プロンプト注入回数 : ${KDB_INJECTIONS_MADE}"
    kdb_stats 2>/dev/null || true
}

kdb_score() {
    if [[ ${KDB_INJECTIONS_MADE} -gt 0 ]]; then
        echo "90"
    elif [[ ${KDB_RECORDS_ADDED} -gt 0 ]]; then
        echo "75"
    elif [[ ${KDB_TOTAL_RECORDS} -gt 0 ]]; then
        echo "60"
    else
        echo "50"
    fi
}

# ============================================================
# v59.0: Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "knowledge-db" --version "100.0" \
        --description "全セッション知見蓄積×RAG検索×プロンプト注入×Fine-tuning基盤" \
        --init "kdb_init" --report "kdb_report" --score "kdb_score" \
        --enable-var "ENABLE_KNOWLEDGE_DB" --cli-flags "--knowledge-db:--no-knowledge-db"
fi

# v2003.1: source時のexit codeを確実に0にする
true
