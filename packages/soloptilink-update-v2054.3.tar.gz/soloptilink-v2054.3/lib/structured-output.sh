#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v15.0 - Structured Output Parser
# =============================================================================
# Uses Claude CLI --output-format json mode for reliable output parsing.
# Replaces fragile regex-based file extraction with structured JSON parsing.
# Enables actual token-based cost tracking.
# =============================================================================

[[ -n "${_STRUCTURED_OUTPUT_LOADED:-}" ]] && return 0
_STRUCTURED_OUTPUT_LOADED=1

# ============================================================
# State
# ============================================================
declare -g SO_ENABLED="false"
declare -g SO_LAST_INPUT_TOKENS=0
declare -g SO_LAST_OUTPUT_TOKENS=0
declare -g SO_LAST_COST=""
declare -g SO_TOTAL_INPUT_TOKENS=0
declare -g SO_TOTAL_OUTPUT_TOKENS=0
declare -g SO_CALLS=0

# ============================================================
# Internal logger
# ============================================================
_so_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    echo -e "  ${color}[STRUCT-OUT]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize structured output mode
# ============================================================
so_init() {
    SO_ENABLED="true"
    SO_LAST_INPUT_TOKENS=0
    SO_LAST_OUTPUT_TOKENS=0
    SO_LAST_COST=""
    SO_TOTAL_INPUT_TOKENS=0
    SO_TOTAL_OUTPUT_TOKENS=0
    SO_CALLS=0

    _so_log "INFO" "構造化出力モード有効化"
}

# ============================================================
# Call Claude with --output-format json
# ============================================================
so_call_claude_json() {
    local prompt="$1"
    local output_file="${2:-}"
    local agent_flag="${3:-}"

    local cmd_args=(-p --dangerously-skip-permissions --output-format json)
    [[ -n "$agent_flag" ]] && cmd_args+=(-a "$agent_flag")

    local raw_output
    raw_output=$(timeout 300 claude "${cmd_args[@]}" "$prompt" 2>/dev/null)
    local rc=$?

    if [[ $rc -ne 0 || -z "$raw_output" ]]; then
        _so_log "WARN" "Claude JSON呼び出し失敗 (rc=${rc})、テキストモードにフォールバック"
        # Fallback to text mode
        local text_output
        local fallback_args=(-p --dangerously-skip-permissions --output-format text)
        [[ -n "$agent_flag" ]] && fallback_args+=(-a "$agent_flag")
        text_output=$(timeout 300 claude "${fallback_args[@]}" "$prompt" 2>/dev/null)
        [[ -n "$output_file" ]] && echo "$text_output" > "$output_file"
        echo "$text_output"
        return $rc
    fi

    SO_CALLS=$((SO_CALLS + 1))

    # Parse cost metadata from JSON
    so_parse_cost_metadata "$raw_output"

    # Extract text content
    local text_content
    text_content=$(so_extract_text "$raw_output")

    if [[ -n "$output_file" ]]; then
        echo "$text_content" > "$output_file"
    fi

    echo "$text_content"
    return 0
}

# ============================================================
# Extract plain text from JSON response
# ============================================================
so_extract_text() {
    local json_output="$1"
    [[ -z "$json_output" ]] && return

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys
try:
    data = json.loads(sys.argv[1])
    # Claude CLI JSON output has 'result' field
    if isinstance(data, dict):
        result = data.get('result', data.get('content', data.get('text', '')))
        if isinstance(result, list):
            # Handle content blocks array
            texts = [b.get('text', '') for b in result if b.get('type') == 'text']
            print('\\n'.join(texts))
        else:
            print(str(result))
    else:
        print(str(data))
except Exception:
    # If JSON parsing fails, return raw input
    print(sys.argv[1])
" "$json_output" 2>/dev/null
    elif command -v jq &>/dev/null; then
        echo "$json_output" | jq -r '.result // .content // .text // .' 2>/dev/null
    else
        # Regex fallback: extract "result":"..." value
        echo "$json_output" | sed 's/.*"result":"\(.*\)".*/\1/' 2>/dev/null || echo "$json_output"
    fi
}

# ============================================================
# Extract file blocks from JSON output
# ============================================================
so_extract_files() {
    local json_output="$1"
    [[ -z "$json_output" ]] && return

    # Extract text first, then delegate to existing file writer
    local text_content
    text_content=$(so_extract_text "$json_output")

    # Return the text for file writer to process
    echo "$text_content"
}

# ============================================================
# Validate JSON response structure
# ============================================================
so_validate_response() {
    local json_output="$1"
    [[ -z "$json_output" ]] && return 1

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys
try:
    data = json.loads(sys.argv[1])
    if isinstance(data, dict):
        sys.exit(0)
    sys.exit(1)
except Exception:
    sys.exit(1)
" "$json_output" 2>/dev/null
        return $?
    elif command -v jq &>/dev/null; then
        echo "$json_output" | jq '.' &>/dev/null
        return $?
    fi

    # Basic check: starts with { or [
    [[ "$json_output" =~ ^\s*[\{\[] ]] && return 0
    return 1
}

# ============================================================
# Parse token counts and cost from JSON response
# ============================================================
so_parse_cost_metadata() {
    local json_output="$1"
    [[ -z "$json_output" ]] && return

    SO_LAST_INPUT_TOKENS=0
    SO_LAST_OUTPUT_TOKENS=0
    SO_LAST_COST=""

    if command -v python3 &>/dev/null; then
        # Instead of eval, read into variables safely
        local py_output
        py_output=$(python3 -c "
import json, sys
try:
    d = json.loads(sys.argv[1])
    usage = d.get('usage', {})
    print(usage.get('input_tokens', 0))
    print(usage.get('output_tokens', 0))
except Exception:
    print(0)
    print(0)
" "$json_output" 2>/dev/null) || py_output=$'0\n0'

        SO_LAST_INPUT_TOKENS=$(echo "$py_output" | head -1)
        SO_LAST_OUTPUT_TOKENS=$(echo "$py_output" | tail -1)

        # Claude pricing: $3/1M input, $15/1M output (Sonnet)
        if [[ $SO_LAST_INPUT_TOKENS -gt 0 || $SO_LAST_OUTPUT_TOKENS -gt 0 ]]; then
            SO_LAST_COST=$(python3 -c "
inp = ${SO_LAST_INPUT_TOKENS}
out = ${SO_LAST_OUTPUT_TOKENS}
cost = (inp * 0.000003) + (out * 0.000015)
print(f'{cost:.4f}')
" 2>/dev/null) || SO_LAST_COST=""
        fi
    fi

    SO_TOTAL_INPUT_TOKENS=$((SO_TOTAL_INPUT_TOKENS + SO_LAST_INPUT_TOKENS))
    SO_TOTAL_OUTPUT_TOKENS=$((SO_TOTAL_OUTPUT_TOKENS + SO_LAST_OUTPUT_TOKENS))
}

# ============================================================
# Report structured output statistics
# ============================================================
so_report() {
    echo -e "\n${BOLD:-}=== Structured Output Report ===${NC:-}"
    echo -e "  モード:           ${SO_ENABLED}"
    echo -e "  呼び出し回数:     ${SO_CALLS}"
    echo -e "  入力トークン合計: ${SO_TOTAL_INPUT_TOKENS}"
    echo -e "  出力トークン合計: ${SO_TOTAL_OUTPUT_TOKENS}"
    if [[ -n "$SO_LAST_COST" ]]; then
        echo -e "  最終呼び出しコスト: \$${SO_LAST_COST}"
    fi
}
