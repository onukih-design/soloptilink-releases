#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v311.0 - Reservation System Generator
# =============================================================================
# 予約システム自動生成: リソースモデル/空き状況カレンダー/予約フロー/リマインダー
#
# 全globals: RSG_ prefix
# =============================================================================

[[ -n "${_RESERVATION_SYSTEM_GENERATOR_LOADED:-}" ]] && return 0
_RESERVATION_SYSTEM_GENERATOR_LOADED=1

declare -g RSG_VERSION="311.0"
declare -g RSG_INITIALIZED=false
declare -g RSG_GENERATED_COUNT=0
declare -g ENABLE_RESERVATION_SYSTEM_GENERATOR="${ENABLE_RESERVATION_SYSTEM_GENERATOR:-true}"

readonly RSG_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly RSG_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly RSG_BOLD="${CLR_BOLD:-\033[1m}"
readonly RSG_NC="${CLR_NC:-\033[0m}"

_rsg_log() { echo -e "  ${RSG_CYAN}[RSG]${RSG_NC} $*" >&2; }
_rsg_ok()  { echo -e "  ${RSG_GREEN}[RSG] OK${RSG_NC} $*" >&2; }

rsg_init() { RSG_INITIALIZED=true; RSG_GENERATED_COUNT=0; return 0; }
rsg_report() { [[ "$RSG_INITIALIZED" != "true" ]] && return 0; echo -e "\n  ${RSG_BOLD}--- Reservation System Generator v${RSG_VERSION} ---${RSG_NC}" >&2; echo -e "  生成数: ${RSG_GENERATED_COUNT}" >&2; }
rsg_score() { [[ "$RSG_INITIALIZED" != "true" ]] && { echo "0"; return; }; local s=50; [[ $RSG_GENERATED_COUNT -ge 3 ]] && s=85; echo "$s"; }
rsg_init_message() { echo -e "  ${RSG_GREEN}v${RSG_VERSION} reservation-system-generator: 予約システム自動生成${RSG_NC}" >&2; }

# =============================================================================
# _rsg_generate_resource_model() - Reservable resource model
# =============================================================================
_rsg_generate_resource_model() {
    local project_dir="${1:-.}"
    _rsg_log "予約リソースモデル生成"

    local snippet='
// --- Reservation System Models (v311.0) ---
model Resource {
  id          String   @id @default(cuid())
  name        String
  description String?
  type        String?
  capacity    Int      @default(1)
  pricePerSlot Int?
  imageUrl    String?
  isActive    Boolean  @default(true)
  availabilities ResourceAvailability[]
  bookings    Booking[]
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}

model ResourceAvailability {
  id         String   @id @default(cuid())
  resourceId String
  resource   Resource @relation(fields: [resourceId], references: [id], onDelete: Cascade)
  dayOfWeek  Int?     // 0=Sun, 6=Sat; null=specific date
  date       DateTime? @db.Date
  startTime  String   // "09:00"
  endTime    String   // "17:00"
  slotMinutes Int     @default(60)
}

model Booking {
  id          String   @id @default(cuid())
  bookingNo   String   @unique
  resourceId  String
  resource    Resource @relation(fields: [resourceId], references: [id])
  userId      String?
  guestName   String?
  guestEmail  String?
  guestPhone  String?
  date        DateTime @db.Date
  startTime   String
  endTime     String
  status      BookingStatus @default(PENDING)
  totalPrice  Int?
  notes       String?
  reminderSent Boolean @default(false)
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}

enum BookingStatus { PENDING CONFIRMED CANCELLED NO_SHOW COMPLETED }'

    mkdir -p "${project_dir}/prisma"
    local schema_file="${project_dir}/prisma/schema.prisma"
    if [[ -f "$schema_file" ]] && ! grep -q "model Booking" "$schema_file" 2>/dev/null; then
        echo "$snippet" >> "$schema_file"
    fi

    RSG_GENERATED_COUNT=$((RSG_GENERATED_COUNT + 1))
    _rsg_ok "予約リソースモデル生成完了"
    return 0
}

# =============================================================================
# _rsg_generate_availability() - Availability calendar
# =============================================================================
_rsg_generate_availability() {
    local project_dir="${1:-.}"
    _rsg_log "空き状況カレンダー生成"

    local comp_dir="${project_dir}/src/components/reservation"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/AvailabilityCalendar.tsx" <<'EOF'
'use client';
import { useState, useMemo } from 'react';
import useSWR from 'swr';
import { ChevronLeft, ChevronRight } from 'lucide-react';

const fetcher = (url: string) => fetch(url).then(r => r.json());
const DAYS = ['日', '月', '火', '水', '木', '金', '土'];

interface AvailabilityCalendarProps {
  resourceId: string;
  onSelectSlot?: (date: string, time: string) => void;
}

export function AvailabilityCalendar({ resourceId, onSelectSlot }: AvailabilityCalendarProps) {
  const [currentMonth, setCurrentMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<string | null>(null);

  const year = currentMonth.getFullYear();
  const month = currentMonth.getMonth();

  const { data } = useSWR(
    `/api/reservations/availability?resourceId=${resourceId}&year=${year}&month=${month + 1}`,
    fetcher
  );

  const days = useMemo(() => {
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const result: (number | null)[] = Array(firstDay).fill(null);
    for (let d = 1; d <= daysInMonth; d++) result.push(d);
    return result;
  }, [year, month]);

  const availableDates = new Set(data?.availableDates || []);
  const slots = data?.slots?.[selectedDate || ''] || [];

  const prevMonth = () => setCurrentMonth(new Date(year, month - 1, 1));
  const nextMonth = () => setCurrentMonth(new Date(year, month + 1, 1));

  return (
    <div className="bg-white rounded-lg shadow p-4">
      <div className="flex items-center justify-between mb-4">
        <button onClick={prevMonth} className="p-1 hover:bg-gray-100 rounded"><ChevronLeft size={20} /></button>
        <h3 className="font-semibold">{year}年{month + 1}月</h3>
        <button onClick={nextMonth} className="p-1 hover:bg-gray-100 rounded"><ChevronRight size={20} /></button>
      </div>
      <div className="grid grid-cols-7 gap-1 text-center text-xs mb-2">
        {DAYS.map(d => <div key={d} className="font-medium text-gray-500 py-1">{d}</div>)}
      </div>
      <div className="grid grid-cols-7 gap-1">
        {days.map((day, i) => {
          if (!day) return <div key={i} />;
          const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
          const available = availableDates.has(dateStr);
          const isSelected = selectedDate === dateStr;
          const isPast = new Date(dateStr) < new Date(new Date().toDateString());
          return (
            <button key={i} disabled={!available || isPast}
              onClick={() => setSelectedDate(dateStr)}
              className={`aspect-square rounded-lg text-sm flex items-center justify-center ${
                isSelected ? 'bg-blue-600 text-white' :
                available && !isPast ? 'bg-green-50 text-green-700 hover:bg-green-100' :
                'text-gray-300 cursor-not-allowed'
              }`}>{day}</button>
          );
        })}
      </div>

      {selectedDate && (
        <div className="mt-4 border-t pt-4">
          <h4 className="text-sm font-medium mb-2">{selectedDate} の空き枠</h4>
          {slots.length === 0 ? (
            <p className="text-gray-500 text-sm">空き枠なし</p>
          ) : (
            <div className="grid grid-cols-3 gap-2">
              {slots.map((slot: string) => (
                <button key={slot} onClick={() => onSelectSlot?.(selectedDate, slot)}
                  className="text-sm py-2 border rounded-lg hover:bg-blue-50 hover:border-blue-300 transition">
                  {slot}
                </button>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
EOF

    RSG_GENERATED_COUNT=$((RSG_GENERATED_COUNT + 1))
    _rsg_ok "空き状況カレンダー生成完了"
    return 0
}

# =============================================================================
# _rsg_generate_booking_flow() - Booking flow
# =============================================================================
_rsg_generate_booking_flow() {
    local project_dir="${1:-.}"
    _rsg_log "予約フロー生成"

    local api_dir="${project_dir}/src/app/api/reservations"
    mkdir -p "${api_dir}/availability"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

function generateBookingNo() {
  return `BK-${Date.now().toString(36).toUpperCase()}-${Math.random().toString(36).substr(2,4).toUpperCase()}`;
}

export async function GET(req: NextRequest) {
  try {
    const userId = req.nextUrl.searchParams.get('userId');
    const resourceId = req.nextUrl.searchParams.get('resourceId');
    const status = req.nextUrl.searchParams.get('status');
    const where: any = {};
    if (userId) where.userId = userId;
    if (resourceId) where.resourceId = resourceId;
    if (status) where.status = status;
    const bookings = await prisma.booking.findMany({
      where, include: { resource: { select: { name: true, type: true } } },
      orderBy: { date: 'desc' }, take: 100,
    });
    return NextResponse.json({ data: bookings });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch bookings' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { resourceId, userId, guestName, guestEmail, guestPhone, date, startTime, endTime, notes } = await req.json();
    if (!resourceId || !date || !startTime || !endTime) return NextResponse.json({ error: 'Missing required fields' }, { status: 400 });

    // Check for conflicts
    const existing = await prisma.booking.findFirst({
      where: { resourceId, date: new Date(date), startTime, status: { in: ['PENDING', 'CONFIRMED'] } },
    });
    if (existing) return NextResponse.json({ error: 'Time slot already booked' }, { status: 409 });

    const resource = await prisma.resource.findUnique({ where: { id: resourceId } });
    const booking = await prisma.booking.create({
      data: {
        bookingNo: generateBookingNo(), resourceId, userId, guestName, guestEmail, guestPhone,
        date: new Date(date), startTime, endTime, notes,
        totalPrice: resource?.pricePerSlot || 0,
        status: 'CONFIRMED',
      },
    });
    return NextResponse.json(booking, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create booking' }, { status: 500 });
  }
}
EOF

    cat > "${api_dir}/availability/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest) {
  try {
    const resourceId = req.nextUrl.searchParams.get('resourceId');
    const year = parseInt(req.nextUrl.searchParams.get('year') || String(new Date().getFullYear()));
    const month = parseInt(req.nextUrl.searchParams.get('month') || String(new Date().getMonth() + 1));

    if (!resourceId) return NextResponse.json({ error: 'resourceId required' }, { status: 400 });

    const availabilities = await prisma.resourceAvailability.findMany({ where: { resourceId } });
    const daysInMonth = new Date(year, month, 0).getDate();
    const availableDates: string[] = [];
    const slots: Record<string, string[]> = {};

    for (let d = 1; d <= daysInMonth; d++) {
      const dateObj = new Date(year, month - 1, d);
      const dayOfWeek = dateObj.getDay();
      const dateStr = `${year}-${String(month).padStart(2, '0')}-${String(d).padStart(2, '0')}`;

      const matching = availabilities.filter(a =>
        (a.dayOfWeek !== null && a.dayOfWeek === dayOfWeek) ||
        (a.date && a.date.toISOString().split('T')[0] === dateStr)
      );

      if (matching.length > 0) {
        availableDates.push(dateStr);
        const dateSlots: string[] = [];
        for (const avail of matching) {
          const [sh, sm] = avail.startTime.split(':').map(Number);
          const [eh, em] = avail.endTime.split(':').map(Number);
          const startMin = sh * 60 + sm;
          const endMin = eh * 60 + em;
          for (let m = startMin; m < endMin; m += avail.slotMinutes) {
            dateSlots.push(`${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`);
          }
        }

        // Remove booked slots
        const booked = await prisma.booking.findMany({
          where: { resourceId, date: dateObj, status: { in: ['PENDING', 'CONFIRMED'] } },
          select: { startTime: true },
        });
        const bookedTimes = new Set(booked.map(b => b.startTime));
        slots[dateStr] = dateSlots.filter(s => !bookedTimes.has(s));
      }
    }

    return NextResponse.json({ availableDates, slots });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch availability' }, { status: 500 });
  }
}
EOF

    RSG_GENERATED_COUNT=$((RSG_GENERATED_COUNT + 2))
    _rsg_ok "予約フロー生成完了"
    return 0
}

# =============================================================================
# _rsg_generate_reminders() - Booking reminder emails
# =============================================================================
_rsg_generate_reminders() {
    local project_dir="${1:-.}"
    _rsg_log "リマインダー生成"

    local api_dir="${project_dir}/src/app/api/cron/booking-reminders"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET() {
  try {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    const dayAfter = new Date(tomorrow);
    dayAfter.setDate(dayAfter.getDate() + 1);

    const upcomingBookings = await prisma.booking.findMany({
      where: {
        date: { gte: tomorrow, lt: dayAfter },
        status: 'CONFIRMED',
        reminderSent: false,
      },
      include: { resource: { select: { name: true } } },
    });

    let sentCount = 0;
    for (const booking of upcomingBookings) {
      const email = booking.guestEmail;
      if (!email) continue;

      // TODO: Send actual email via provider
      // await sendEmail({ to: email, subject: `予約リマインダー: ${booking.resource.name}`, ... });

      await prisma.booking.update({ where: { id: booking.id }, data: { reminderSent: true } });
      sentCount++;
    }

    return NextResponse.json({ sent: sentCount, total: upcomingBookings.length });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to send reminders' }, { status: 500 });
  }
}
EOF

    RSG_GENERATED_COUNT=$((RSG_GENERATED_COUNT + 1))
    _rsg_ok "リマインダー生成完了"
    return 0
}

# =============================================================================
# Module Registration
# =============================================================================
_mr_register \
    --name "reservation-system-generator" \
    --version "311.0" \
    --description "予約システム自動生成（リソース/空き状況/予約フロー/リマインダー）" \
    --init "rsg_init" \
    --report "rsg_report" \
    --score "rsg_score" \
    --enable-var "ENABLE_RESERVATION_SYSTEM_GENERATOR" \
    --cli-flags "--reservation:--no-reservation" \
    --init-msg "rsg_init_message"
