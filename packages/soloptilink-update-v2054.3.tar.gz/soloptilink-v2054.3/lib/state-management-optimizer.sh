#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v226.0 - State Management Optimizer
# =============================================================================
# Analyzes application state needs and recommends optimal state management.
# Supports useState, useContext, Zustand, Redux Toolkit, and Jotai.
# Generates store code and migration paths between solutions.
#
# Functions:
#   _smo_analyze_state_needs()   - Analyze what state management the app needs
#   _smo_recommend_solution()    - Recommend state solution
#   _smo_generate_store()        - Generate store based on recommendation
#   _smo_migrate_state()         - Migrate between state solutions
#   _smo_check_state_health()    - Check for state management anti-patterns
#   _smo_generate_hooks()        - Generate custom hooks for state access
#
# All globals: SMO_ prefix
# =============================================================================

[[ -n "${_SMO_LOADED:-}" ]] && return 0
_SMO_LOADED=1

# --- Colors ---
readonly SMO_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly SMO_YELLOW="${CLR_YELLOW:-\033[0;33m}"
readonly SMO_RED="${CLR_RED:-\033[0;31m}"
readonly SMO_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly SMO_BOLD="${CLR_BOLD:-\033[1m}"
readonly SMO_NC="${CLR_NC:-\033[0m}"

# --- State ---
declare -g SMO_VERSION="226.0"
declare -g SMO_INITIALIZED=false
declare -g SMO_RECOMMENDATION=""
declare -g SMO_STORES_GENERATED=0
declare -g SMO_ANTIPATTERNS_FOUND=0
declare -g SMO_STATE_COMPLEXITY=""

# =============================================================================
# Logging
# =============================================================================
_smo_log()  { echo -e "  ${SMO_CYAN}[SMO]${SMO_NC} $*" >&2; }
_smo_ok()   { echo -e "  ${SMO_GREEN}[SMO] OK${SMO_NC} $*" >&2; }
_smo_warn() { echo -e "  ${SMO_YELLOW}[SMO] WARN${SMO_NC} $*" >&2; }
_smo_err()  { echo -e "  ${SMO_RED}[SMO] ERR${SMO_NC} $*" >&2; }

# =============================================================================
# Init
# =============================================================================
smo_init() {
    SMO_INITIALIZED=true
    SMO_RECOMMENDATION=""
    SMO_STORES_GENERATED=0
    SMO_ANTIPATTERNS_FOUND=0
    SMO_STATE_COMPLEXITY=""
    return 0
}

# =============================================================================
# _smo_analyze_state_needs - Analyze what state management the app needs
# =============================================================================
_smo_analyze_state_needs() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _smo_log "Analyzing state management needs in ${project_dir}..."

    local tsx_files
    tsx_files=$(find "$project_dir" -name "*.tsx" -name "*.ts" -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null)

    # Count state patterns
    local use_state_count=0
    local use_context_count=0
    local use_reducer_count=0
    local zustand_count=0
    local redux_count=0
    local jotai_count=0
    local prop_drilling=0
    local global_state_files=0
    local total_components=0

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue

        # Count state hooks
        local us_count
        us_count=$(echo "$content" | grep -c "useState" || true)
        use_state_count=$((use_state_count + us_count))

        echo "$content" | grep -q "useContext\|createContext" && use_context_count=$((use_context_count + 1))
        echo "$content" | grep -q "useReducer" && use_reducer_count=$((use_reducer_count + 1))
        echo "$content" | grep -q "zustand\|create(" && zustand_count=$((zustand_count + 1))
        echo "$content" | grep -q "useSelector\|useDispatch\|configureStore" && redux_count=$((redux_count + 1))
        echo "$content" | grep -q "atom\|useAtom\|jotai" && jotai_count=$((jotai_count + 1))

        # Check for prop drilling (many props passed through)
        local prop_count
        prop_count=$(echo "$content" | grep -oE '\b\w+\s*=\s*\{[^}]*\}' | wc -l || true)
        [[ "$prop_count" -gt 8 ]] && prop_drilling=$((prop_drilling + 1))

        # Count components
        echo "$content" | grep -qE 'export (default )?function|export const \w+ =' && total_components=$((total_components + 1))

        # Global state files
        echo "$content" | grep -qE 'createContext|configureStore|create\(' && echo "$file" | grep -qE 'store|context|state|provider' && global_state_files=$((global_state_files + 1))
    done < <(find "$project_dir" -name "*.tsx" -o -name "*.ts" 2>/dev/null | grep -v node_modules | grep -v .next)

    # Determine complexity
    local complexity="simple"
    local total_state=$((use_state_count + use_context_count + use_reducer_count + zustand_count + redux_count + jotai_count))

    if [[ $total_components -gt 50 ]] || [[ $global_state_files -gt 5 ]]; then
        complexity="complex"
    elif [[ $total_components -gt 20 ]] || [[ $global_state_files -gt 2 ]]; then
        complexity="moderate"
    fi

    SMO_STATE_COMPLEXITY="$complexity"

    echo "{"
    echo "  \"complexity\": \"${complexity}\","
    echo "  \"totalComponents\": ${total_components},"
    echo "  \"statePatterns\": {"
    echo "    \"useState\": ${use_state_count},"
    echo "    \"useContext\": ${use_context_count},"
    echo "    \"useReducer\": ${use_reducer_count},"
    echo "    \"zustand\": ${zustand_count},"
    echo "    \"redux\": ${redux_count},"
    echo "    \"jotai\": ${jotai_count}"
    echo "  },"
    echo "  \"propDrillingFiles\": ${prop_drilling},"
    echo "  \"globalStateFiles\": ${global_state_files},"
    echo "  \"currentSolution\": \"$( \
        [[ $redux_count -gt 0 ]] && echo 'redux' || \
        [[ $zustand_count -gt 0 ]] && echo 'zustand' || \
        [[ $jotai_count -gt 0 ]] && echo 'jotai' || \
        [[ $use_context_count -gt 3 ]] && echo 'context' || \
        echo 'useState' \
    )\""
    echo "}"

    _smo_ok "Analysis complete: ${complexity} complexity, ${total_components} components"
}

# =============================================================================
# _smo_recommend_solution - Recommend optimal state management
# Usage: _smo_recommend_solution "simple" 15
# =============================================================================
_smo_recommend_solution() {
    local complexity="${1:-${SMO_STATE_COMPLEXITY:-simple}}"
    local component_count="${2:-10}"
    local has_realtime="${3:-false}"
    local has_forms="${4:-false}"

    _smo_log "Recommending state solution (complexity: ${complexity})..."

    local recommendation=""
    local reason=""
    local alternatives=""

    case "$complexity" in
        simple)
            if [[ "$component_count" -lt 10 ]]; then
                recommendation="useState"
                reason="Small app with few components. useState + prop passing is sufficient."
                alternatives="useContext for theme/auth"
            else
                recommendation="zustand"
                reason="Growing app benefits from Zustand's simplicity and no boilerplate."
                alternatives="useState for local state, useContext for static context"
            fi
            ;;
        moderate)
            recommendation="zustand"
            reason="Moderate complexity app. Zustand provides global state without Redux boilerplate."
            alternatives="Jotai for atomic state, React Context for simple shared state"
            ;;
        complex)
            if [[ "$has_realtime" == "true" ]]; then
                recommendation="zustand"
                reason="Complex app with realtime needs. Zustand handles subscriptions well with minimal re-renders."
                alternatives="Redux Toolkit for large teams, Jotai for atomic updates"
            else
                recommendation="zustand"
                reason="Complex app benefits from Zustand's devtools, middleware, and minimal API."
                alternatives="Redux Toolkit for enterprise/large teams, Jotai for fine-grained reactivity"
            fi
            ;;
    esac

    SMO_RECOMMENDATION="$recommendation"

    echo "{"
    echo "  \"recommendation\": \"${recommendation}\","
    echo "  \"reason\": \"${reason}\","
    echo "  \"alternatives\": \"${alternatives}\","
    echo "  \"complexity\": \"${complexity}\","
    echo "  \"guidelines\": ["
    echo "    \"Use useState for component-local UI state (modals, form inputs, toggles)\","
    echo "    \"Use ${recommendation} for shared/global state (auth, cart, notifications)\","
    echo "    \"Use React Query/SWR for server state (API data, caching, revalidation)\","
    echo "    \"Never store server-fetched data in global state - use SWR/React Query instead\","
    echo "    \"Keep state as close to where it is used as possible\""
    echo "  ]"
    echo "}"

    _smo_ok "Recommended: ${recommendation} (${complexity})"
}

# =============================================================================
# _smo_generate_store - Generate store based on recommendation
# Usage: _smo_generate_store "zustand" "auth" "user:User|null" "token:string|null"
# =============================================================================
_smo_generate_store() {
    local solution="${1:-zustand}"
    local store_name="${2:-app}"
    shift 2
    local fields=("$@")

    _smo_log "Generating ${solution} store: ${store_name}..."

    case "$solution" in
        zustand)
            _smo_gen_zustand "$store_name" "${fields[@]}"
            ;;
        context)
            _smo_gen_context "$store_name" "${fields[@]}"
            ;;
        redux)
            _smo_gen_redux "$store_name" "${fields[@]}"
            ;;
        jotai)
            _smo_gen_jotai "$store_name" "${fields[@]}"
            ;;
        *)
            _smo_err "Unknown solution: ${solution}. Available: zustand, context, redux, jotai"
            return 1
            ;;
    esac

    SMO_STORES_GENERATED=$((SMO_STORES_GENERATED + 1))
}

_smo_gen_zustand() {
    local name="${1:-app}"
    shift
    local fields=("$@")

    local store_name
    store_name="use$(echo "${name^}" | sed 's/-\(.\)/\U\1/g')Store"

    cat <<EOF
// --- FILE: lib/stores/${name}-store.ts ---
import { create } from 'zustand';
import { devtools, persist } from 'zustand/middleware';

interface ${name^}State {
EOF

    # Generate interface fields
    for field_def in "${fields[@]}"; do
        local fname="${field_def%%:*}"
        local ftype="${field_def#*:}"
        echo "  ${fname}: ${ftype};"
    done

    cat <<EOF
}

interface ${name^}Actions {
EOF

    # Generate action signatures
    for field_def in "${fields[@]}"; do
        local fname="${field_def%%:*}"
        local ftype="${field_def#*:}"
        local setter_name="set$(echo "${fname^}" | sed 's/^./\U&/')"
        echo "  ${setter_name}: (value: ${ftype}) => void;"
    done

    cat <<EOF
  reset: () => void;
}

type ${name^}Store = ${name^}State & ${name^}Actions;

const initialState: ${name^}State = {
EOF

    for field_def in "${fields[@]}"; do
        local fname="${field_def%%:*}"
        local ftype="${field_def#*:}"
        local default_val="null"
        echo "$ftype" | grep -qE "^string$" && default_val="''"
        echo "$ftype" | grep -qE "^number$" && default_val="0"
        echo "$ftype" | grep -qE "^boolean$" && default_val="false"
        echo "$ftype" | grep -qE "\[\]$" && default_val="[]"
        echo "  ${fname}: ${default_val},"
    done

    cat <<EOF
};

export const ${store_name} = create<${name^}Store>()(
  devtools(
    persist(
      (set) => ({
        ...initialState,
EOF

    for field_def in "${fields[@]}"; do
        local fname="${field_def%%:*}"
        local ftype="${field_def#*:}"
        local setter_name="set$(echo "${fname^}" | sed 's/^./\U&/')"
        echo "        ${setter_name}: (value) => set({ ${fname}: value }),"
    done

    cat <<EOF
        reset: () => set(initialState),
      }),
      { name: '${name}-store' }
    ),
    { name: '${name^}Store' }
  )
);
EOF

    _smo_ok "Generated Zustand store: ${store_name}"
}

_smo_gen_context() {
    local name="${1:-app}"
    shift
    local fields=("$@")

    cat <<EOF
// --- FILE: lib/contexts/${name}-context.tsx ---
'use client';
import { createContext, useContext, useState, useCallback, ReactNode } from 'react';

interface ${name^}ContextType {
EOF
    for field_def in "${fields[@]}"; do
        local fname="${field_def%%:*}"
        local ftype="${field_def#*:}"
        echo "  ${fname}: ${ftype};"
        local setter_name="set$(echo "${fname^}" | sed 's/^./\U&/')"
        echo "  ${setter_name}: (value: ${ftype}) => void;"
    done
    cat <<EOF
}

const ${name^}Context = createContext<${name^}ContextType | null>(null);

export function ${name^}Provider({ children }: { children: ReactNode }) {
EOF
    for field_def in "${fields[@]}"; do
        local fname="${field_def%%:*}"
        local ftype="${field_def#*:}"
        local default_val="null"
        echo "$ftype" | grep -qE "^string$" && default_val="''"
        echo "$ftype" | grep -qE "^number$" && default_val="0"
        echo "$ftype" | grep -qE "^boolean$" && default_val="false"
        echo "  const [${fname}, set${fname^}] = useState<${ftype}>(${default_val});"
    done
    echo ""
    echo "  return ("
    echo -n "    <${name^}Context.Provider value={{ "
    for field_def in "${fields[@]}"; do
        local fname="${field_def%%:*}"
        echo -n "${fname}, set${fname^}, "
    done
    echo "}}>"
    echo "      {children}"
    echo "    </${name^}Context.Provider>"
    echo "  );"
    echo "}"
    echo ""
    echo "export function use${name^}() {"
    echo "  const ctx = useContext(${name^}Context);"
    echo "  if (!ctx) throw new Error('use${name^} must be used within ${name^}Provider');"
    echo "  return ctx;"
    echo "}"

    _smo_ok "Generated Context: ${name^}Provider"
}

_smo_gen_redux() {
    local name="${1:-app}"
    shift
    local fields=("$@")

    cat <<EOF
// --- FILE: lib/store/${name}-slice.ts ---
import { createSlice, PayloadAction } from '@reduxjs/toolkit';

interface ${name^}State {
EOF
    for field_def in "${fields[@]}"; do
        local fname="${field_def%%:*}"
        local ftype="${field_def#*:}"
        echo "  ${fname}: ${ftype};"
    done
    cat <<EOF
}

const initialState: ${name^}State = {
EOF
    for field_def in "${fields[@]}"; do
        local fname="${field_def%%:*}"
        local ftype="${field_def#*:}"
        local default_val="null"
        echo "$ftype" | grep -qE "^string$" && default_val="''"
        echo "$ftype" | grep -qE "^number$" && default_val="0"
        echo "$ftype" | grep -qE "^boolean$" && default_val="false"
        echo "  ${fname}: ${default_val},"
    done
    cat <<EOF
};

export const ${name}Slice = createSlice({
  name: '${name}',
  initialState,
  reducers: {
EOF
    for field_def in "${fields[@]}"; do
        local fname="${field_def%%:*}"
        local ftype="${field_def#*:}"
        echo "    set${fname^}: (state, action: PayloadAction<${ftype}>) => { state.${fname} = action.payload; },"
    done
    cat <<EOF
    reset: () => initialState,
  },
});

export const { $(for f in "${fields[@]}"; do echo -n "set${f%%:*}, "; done)reset } = ${name}Slice.actions;
export default ${name}Slice.reducer;
EOF
    _smo_ok "Generated Redux slice: ${name}Slice"
}

_smo_gen_jotai() {
    local name="${1:-app}"
    shift
    local fields=("$@")

    cat <<EOF
// --- FILE: lib/atoms/${name}-atoms.ts ---
import { atom, useAtom } from 'jotai';
import { atomWithStorage } from 'jotai/utils';

EOF
    for field_def in "${fields[@]}"; do
        local fname="${field_def%%:*}"
        local ftype="${field_def#*:}"
        local default_val="null"
        echo "$ftype" | grep -qE "^string$" && default_val="''"
        echo "$ftype" | grep -qE "^number$" && default_val="0"
        echo "$ftype" | grep -qE "^boolean$" && default_val="false"
        echo "export const ${fname}Atom = atomWithStorage<${ftype}>('${name}-${fname}', ${default_val});"
    done

    echo ""
    echo "// Convenience hook"
    echo "export function use${name^}() {"
    for field_def in "${fields[@]}"; do
        local fname="${field_def%%:*}"
        echo "  const [${fname}, set${fname^}] = useAtom(${fname}Atom);"
    done
    echo -n "  return { "
    for field_def in "${fields[@]}"; do
        local fname="${field_def%%:*}"
        echo -n "${fname}, set${fname^}, "
    done
    echo "};"
    echo "}"

    _smo_ok "Generated Jotai atoms: ${name}"
}

# =============================================================================
# _smo_check_state_health - Check for state management anti-patterns
# =============================================================================
_smo_check_state_health() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local score=100
    local issues=()

    _smo_log "Checking state management health..."

    local source_files
    source_files=$(find "$project_dir" \( -name "*.tsx" -o -name "*.ts" \) -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null)

    local derived_state=0
    local state_in_useeffect=0
    local global_for_local=0

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue

        # Anti-pattern: derived state in useState (should be useMemo/computed)
        if echo "$content" | grep -qE 'useState.*filter|useState.*sort|useState.*map'; then
            derived_state=$((derived_state + 1))
        fi

        # Anti-pattern: setState inside useEffect for synchronization
        if echo "$content" | grep -qE 'useEffect\([^)]*set[A-Z]' | head -1 | grep -qv 'fetch\|api\|load'; then
            state_in_useeffect=$((state_in_useeffect + 1))
        fi

        # Anti-pattern: storing server data in global state
        if echo "$content" | grep -qE 'useDispatch|useStore|zustand' && echo "$content" | grep -qE 'fetch\(|axios\.' && ! echo "$content" | grep -qE 'useSWR|useQuery|react-query'; then
            global_for_local=$((global_for_local + 1))
        fi
    done <<< "$source_files"

    [[ $derived_state -gt 3 ]] && { score=$((score - 15)); issues+=("${derived_state} instances of derived state in useState (use useMemo)"); }
    [[ $state_in_useeffect -gt 5 ]] && { score=$((score - 15)); issues+=("${state_in_useeffect} state sync in useEffect (consider reducing)"); }
    [[ $global_for_local -gt 3 ]] && { score=$((score - 20)); issues+=("${global_for_local} files store server data in global state (use SWR/React Query)"); }

    [[ $score -lt 0 ]] && score=0
    SMO_ANTIPATTERNS_FOUND=${#issues[@]}

    echo "{"
    echo "  \"score\": ${score},"
    echo "  \"antipatterns\": ${#issues[@]},"
    echo "  \"issues\": ["
    local first=true
    for issue in "${issues[@]}"; do
        $first || echo ","
        echo -n "    \"${issue}\""
        first=false
    done
    echo ""
    echo "  ]"
    echo "}"

    [[ $score -ge 80 ]] && _smo_ok "State health: ${score}/100" || _smo_warn "State health: ${score}/100"
}

# =============================================================================
# Report / Score
# =============================================================================
smo_report() {
    echo -e "\n  ${SMO_BOLD}=== State Management Optimizer v${SMO_VERSION} ===${SMO_NC}"
    echo -e "  Recommendation     : ${SMO_RECOMMENDATION:-none}"
    echo -e "  Complexity         : ${SMO_STATE_COMPLEXITY:-unknown}"
    echo -e "  Stores generated   : ${SMO_STORES_GENERATED}"
    echo -e "  Antipatterns found : ${SMO_ANTIPATTERNS_FOUND}"
}

smo_score() {
    [[ "$SMO_INITIALIZED" == "true" ]] && echo 100 || echo 0
}

# =============================================================================
# v59.0: Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "state-management-optimizer" \
        --version "226.0" \
        --description "Optimal state management (analyze/recommend/generate Zustand/Redux/Jotai)" \
        --init "smo_init" \
        --report "smo_report" \
        --score "smo_score" \
        --enable-var "ENABLE_STATE_MANAGEMENT" \
        --cli-flags "--state-management:--no-state-management"
fi

# v2003.1: source時のexit codeを確実に0にする
true
