#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v224.0 - Component Library Integrator
# =============================================================================
# Detects, recommends, and generates component compositions for shadcn/ui,
# Radix UI, Headless UI, and other popular React component libraries.
#
# Functions:
#   _cli2_detect_ui_library()    - Detect installed UI library
#   _cli2_suggest_components()   - Suggest components for UI requirement
#   _cli2_generate_composition() - Generate component compositions
#   _cli2_inject_imports()       - Auto-inject correct imports
#   _cli2_check_component_usage() - Audit component usage consistency
#   _cli2_generate_theme()       - Generate theme configuration
#
# All globals: CLI2_ prefix
# =============================================================================

[[ -n "${_CLI2_LOADED:-}" ]] && return 0
_CLI2_LOADED=1

# --- Colors ---
readonly CLI2_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly CLI2_YELLOW="${CLR_YELLOW:-\033[0;33m}"
readonly CLI2_RED="${CLR_RED:-\033[0;31m}"
readonly CLI2_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly CLI2_BOLD="${CLR_BOLD:-\033[1m}"
readonly CLI2_NC="${CLR_NC:-\033[0m}"

# --- State ---
declare -g CLI2_VERSION="224.0"
declare -g CLI2_INITIALIZED=false
declare -g CLI2_DETECTED_LIBRARY=""
declare -g CLI2_COMPOSITIONS_GENERATED=0
declare -g CLI2_IMPORTS_INJECTED=0

# Component registry: component_name -> import_path
declare -gA CLI2_SHADCN_COMPONENTS=()
declare -gA CLI2_COMPONENT_DESCRIPTIONS=()

# =============================================================================
# Logging
# =============================================================================
_cli2_log()  { echo -e "  ${CLI2_CYAN}[CLI2]${CLI2_NC} $*" >&2; }
_cli2_ok()   { echo -e "  ${CLI2_GREEN}[CLI2] OK${CLI2_NC} $*" >&2; }
_cli2_warn() { echo -e "  ${CLI2_YELLOW}[CLI2] WARN${CLI2_NC} $*" >&2; }
_cli2_err()  { echo -e "  ${CLI2_RED}[CLI2] ERR${CLI2_NC} $*" >&2; }

# =============================================================================
# Init
# =============================================================================
cli2_init() {
    CLI2_INITIALIZED=true
    CLI2_COMPOSITIONS_GENERATED=0
    CLI2_IMPORTS_INJECTED=0
    _cli2_register_components
    return 0
}

# =============================================================================
# Register known components
# =============================================================================
_cli2_register_components() {
    # shadcn/ui components
    CLI2_SHADCN_COMPONENTS["Button"]="@/components/ui/button"
    CLI2_SHADCN_COMPONENTS["Card"]="@/components/ui/card"
    CLI2_SHADCN_COMPONENTS["Input"]="@/components/ui/input"
    CLI2_SHADCN_COMPONENTS["Label"]="@/components/ui/label"
    CLI2_SHADCN_COMPONENTS["Select"]="@/components/ui/select"
    CLI2_SHADCN_COMPONENTS["Textarea"]="@/components/ui/textarea"
    CLI2_SHADCN_COMPONENTS["Dialog"]="@/components/ui/dialog"
    CLI2_SHADCN_COMPONENTS["AlertDialog"]="@/components/ui/alert-dialog"
    CLI2_SHADCN_COMPONENTS["Sheet"]="@/components/ui/sheet"
    CLI2_SHADCN_COMPONENTS["Tabs"]="@/components/ui/tabs"
    CLI2_SHADCN_COMPONENTS["Table"]="@/components/ui/table"
    CLI2_SHADCN_COMPONENTS["Badge"]="@/components/ui/badge"
    CLI2_SHADCN_COMPONENTS["Avatar"]="@/components/ui/avatar"
    CLI2_SHADCN_COMPONENTS["Separator"]="@/components/ui/separator"
    CLI2_SHADCN_COMPONENTS["DropdownMenu"]="@/components/ui/dropdown-menu"
    CLI2_SHADCN_COMPONENTS["Toast"]="@/components/ui/toast"
    CLI2_SHADCN_COMPONENTS["Skeleton"]="@/components/ui/skeleton"
    CLI2_SHADCN_COMPONENTS["Switch"]="@/components/ui/switch"
    CLI2_SHADCN_COMPONENTS["Checkbox"]="@/components/ui/checkbox"
    CLI2_SHADCN_COMPONENTS["RadioGroup"]="@/components/ui/radio-group"
    CLI2_SHADCN_COMPONENTS["Progress"]="@/components/ui/progress"
    CLI2_SHADCN_COMPONENTS["Tooltip"]="@/components/ui/tooltip"
    CLI2_SHADCN_COMPONENTS["Popover"]="@/components/ui/popover"
    CLI2_SHADCN_COMPONENTS["Command"]="@/components/ui/command"
    CLI2_SHADCN_COMPONENTS["Calendar"]="@/components/ui/calendar"
    CLI2_SHADCN_COMPONENTS["Form"]="@/components/ui/form"
    CLI2_SHADCN_COMPONENTS["Breadcrumb"]="@/components/ui/breadcrumb"
    CLI2_SHADCN_COMPONENTS["Pagination"]="@/components/ui/pagination"
    CLI2_SHADCN_COMPONENTS["Accordion"]="@/components/ui/accordion"
    CLI2_SHADCN_COMPONENTS["ScrollArea"]="@/components/ui/scroll-area"

    # Descriptions for suggestion
    CLI2_COMPONENT_DESCRIPTIONS["Button"]="Clickable button with variants (default/destructive/outline/ghost/link)"
    CLI2_COMPONENT_DESCRIPTIONS["Card"]="Container with header, content, footer sections"
    CLI2_COMPONENT_DESCRIPTIONS["Dialog"]="Modal dialog for forms and confirmations"
    CLI2_COMPONENT_DESCRIPTIONS["Table"]="Data table with headers and rows"
    CLI2_COMPONENT_DESCRIPTIONS["Form"]="Form wrapper with react-hook-form integration"
    CLI2_COMPONENT_DESCRIPTIONS["Tabs"]="Tab-based content switching"
    CLI2_COMPONENT_DESCRIPTIONS["Select"]="Dropdown select input"
    CLI2_COMPONENT_DESCRIPTIONS["DropdownMenu"]="Context/action menu with items and sub-menus"
    CLI2_COMPONENT_DESCRIPTIONS["Toast"]="Notification toasts (success/error/info)"
    CLI2_COMPONENT_DESCRIPTIONS["AlertDialog"]="Destructive action confirmation dialog"
    CLI2_COMPONENT_DESCRIPTIONS["Sheet"]="Slide-in side panel"
    CLI2_COMPONENT_DESCRIPTIONS["Skeleton"]="Loading placeholder animation"
    CLI2_COMPONENT_DESCRIPTIONS["Badge"]="Status/label badge (variant colored)"
    CLI2_COMPONENT_DESCRIPTIONS["Avatar"]="User profile image with fallback"
    CLI2_COMPONENT_DESCRIPTIONS["Command"]="Searchable command palette (Cmd+K)"
    CLI2_COMPONENT_DESCRIPTIONS["Pagination"]="Page navigation controls"
    CLI2_COMPONENT_DESCRIPTIONS["Accordion"]="Collapsible content sections"
    CLI2_COMPONENT_DESCRIPTIONS["Breadcrumb"]="Navigation breadcrumb trail"
}

# =============================================================================
# _cli2_detect_ui_library - Detect which UI library is installed
# =============================================================================
_cli2_detect_ui_library() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local detected=""

    _cli2_log "Detecting UI library in ${project_dir}..."

    local pkg_json="${project_dir}/package.json"
    if [[ ! -f "$pkg_json" ]]; then
        _cli2_warn "No package.json found"
        echo "none"
        return 1
    fi

    local pkg_content
    pkg_content=$(cat "$pkg_json" 2>/dev/null)

    # Check for shadcn/ui (components/ui directory + radix primitives)
    if [[ -d "${project_dir}/components/ui" ]] || echo "$pkg_content" | grep -q "@radix-ui"; then
        detected="shadcn"
    fi

    # Check for specific libraries
    if echo "$pkg_content" | grep -q "@chakra-ui"; then
        detected="chakra"
    elif echo "$pkg_content" | grep -q "@mui/material\|@material-ui"; then
        detected="mui"
    elif echo "$pkg_content" | grep -q "@mantine"; then
        detected="mantine"
    elif echo "$pkg_content" | grep -q "@headlessui"; then
        detected="headless"
    elif echo "$pkg_content" | grep -q "antd\|ant-design"; then
        detected="antd"
    fi

    # Fallback: check for Tailwind (shadcn compatible)
    if [[ -z "$detected" ]] && echo "$pkg_content" | grep -q "tailwindcss"; then
        detected="tailwind-only"
    fi

    [[ -z "$detected" ]] && detected="none"

    CLI2_DETECTED_LIBRARY="$detected"
    _cli2_ok "Detected: ${detected}"
    echo "$detected"
}

# =============================================================================
# _cli2_suggest_components - Suggest components for a UI requirement
# Usage: _cli2_suggest_components "data table with search and pagination"
# =============================================================================
_cli2_suggest_components() {
    local requirement="${1:-}"
    [[ -z "$requirement" ]] && { _cli2_err "UI requirement description needed"; return 1; }

    local req_lower
    req_lower=$(echo "$requirement" | tr '[:upper:]' '[:lower:]')

    local suggestions=()

    echo "$req_lower" | grep -qE 'table|list|data|grid' && suggestions+=("Table" "Badge" "Pagination" "DropdownMenu" "Skeleton")
    echo "$req_lower" | grep -qE 'form|input|create|edit' && suggestions+=("Form" "Input" "Label" "Select" "Textarea" "Button" "Checkbox" "RadioGroup" "Switch")
    echo "$req_lower" | grep -qE 'dialog|modal|popup|confirm' && suggestions+=("Dialog" "AlertDialog" "Button")
    echo "$req_lower" | grep -qE 'tab|section|panel' && suggestions+=("Tabs" "Card" "Separator")
    echo "$req_lower" | grep -qE 'search|command|filter' && suggestions+=("Command" "Input" "Select")
    echo "$req_lower" | grep -qE 'navigation|menu|sidebar' && suggestions+=("Sheet" "DropdownMenu" "Breadcrumb" "Button")
    echo "$req_lower" | grep -qE 'card|stat|metric|dashboard' && suggestions+=("Card" "Badge" "Avatar" "Progress" "Skeleton")
    echo "$req_lower" | grep -qE 'notification|toast|alert' && suggestions+=("Toast" "Badge" "AlertDialog")
    echo "$req_lower" | grep -qE 'profile|user|avatar' && suggestions+=("Avatar" "Card" "Badge" "Tooltip")
    echo "$req_lower" | grep -qE 'calendar|date|schedule' && suggestions+=("Calendar" "Popover" "Button")
    echo "$req_lower" | grep -qE 'setting|preference|config' && suggestions+=("Tabs" "Switch" "Input" "Label" "Select" "Button")
    echo "$req_lower" | grep -qE 'loading|skeleton|placeholder' && suggestions+=("Skeleton" "Progress")
    echo "$req_lower" | grep -qE 'accordion|collapse|expand|faq' && suggestions+=("Accordion")
    echo "$req_lower" | grep -qE 'scroll|long|content' && suggestions+=("ScrollArea")
    echo "$req_lower" | grep -qE 'tooltip|hover|help' && suggestions+=("Tooltip")

    # Deduplicate
    local unique=()
    local seen=""
    for s in "${suggestions[@]}"; do
        if [[ ! "$seen" == *"|${s}|"* ]]; then
            unique+=("$s")
            seen="${seen}|${s}|"
        fi
    done

    echo "{"
    echo "  \"requirement\": \"${requirement}\","
    echo "  \"library\": \"${CLI2_DETECTED_LIBRARY:-shadcn}\","
    echo "  \"components\": ["
    local first=true
    for comp in "${unique[@]}"; do
        $first || echo ","
        local desc="${CLI2_COMPONENT_DESCRIPTIONS[$comp]:-}"
        local import_path="${CLI2_SHADCN_COMPONENTS[$comp]:-}"
        echo -n "    {\"name\":\"${comp}\",\"import\":\"${import_path}\",\"description\":\"${desc}\"}"
        first=false
    done
    echo ""
    echo "  ]"
    echo "}"

    _cli2_ok "Suggested ${#unique[@]} components for: ${requirement:0:40}"
}

# =============================================================================
# _cli2_generate_composition - Generate component composition
# Usage: _cli2_generate_composition "data-table" "users"
# =============================================================================
_cli2_generate_composition() {
    local composition_type="${1:-}"
    local entity="${2:-items}"
    [[ -z "$composition_type" ]] && { _cli2_err "Composition type required"; return 1; }

    _cli2_log "Generating composition: ${composition_type}..."

    case "$composition_type" in
        data-table)
            _cli2_comp_data_table "$entity"
            ;;
        form-dialog)
            _cli2_comp_form_dialog "$entity"
            ;;
        delete-confirm)
            _cli2_comp_delete_confirm "$entity"
            ;;
        stats-cards)
            _cli2_comp_stats_cards
            ;;
        search-command)
            _cli2_comp_search_command
            ;;
        sidebar-nav)
            _cli2_comp_sidebar_nav
            ;;
        *)
            _cli2_err "Unknown composition type: ${composition_type}"
            _cli2_log "Available: data-table, form-dialog, delete-confirm, stats-cards, search-command, sidebar-nav"
            return 1
            ;;
    esac

    CLI2_COMPOSITIONS_GENERATED=$((CLI2_COMPOSITIONS_GENERATED + 1))
}

_cli2_comp_data_table() {
    local entity="${1:-items}"
    cat <<EOF
// --- Composition: DataTable for ${entity} ---
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { Skeleton } from '@/components/ui/skeleton';
import { Input } from '@/components/ui/input';
import { MoreHorizontal, Search } from 'lucide-react';

interface DataTableProps<T> {
  data: T[];
  columns: { key: string; label: string; render?: (item: T) => React.ReactNode }[];
  isLoading?: boolean;
  searchValue?: string;
  onSearchChange?: (value: string) => void;
  onEdit?: (item: T) => void;
  onDelete?: (item: T) => void;
}

export function DataTable<T extends { id: string }>({ data, columns, isLoading, searchValue, onSearchChange, onEdit, onDelete }: DataTableProps<T>) {
  if (isLoading) {
    return (
      <div className="space-y-3">
        {[...Array(5)].map((_, i) => <Skeleton key={i} className="h-12 w-full" />)}
      </div>
    );
  }
  return (
    <div className="space-y-4">
      {onSearchChange && (
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <Input placeholder="Search..." value={searchValue} onChange={e => onSearchChange(e.target.value)} className="pl-10" />
        </div>
      )}
      <div className="rounded-md border">
        <Table>
          <TableHeader>
            <TableRow>
              {columns.map(col => <TableHead key={col.key}>{col.label}</TableHead>)}
              {(onEdit || onDelete) && <TableHead className="w-[50px]" />}
            </TableRow>
          </TableHeader>
          <TableBody>
            {data.length === 0 ? (
              <TableRow><TableCell colSpan={columns.length + 1} className="text-center py-8 text-muted-foreground">No data</TableCell></TableRow>
            ) : data.map(item => (
              <TableRow key={item.id}>
                {columns.map(col => <TableCell key={col.key}>{col.render ? col.render(item) : (item as any)[col.key]}</TableCell>)}
                {(onEdit || onDelete) && (
                  <TableCell>
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild><Button variant="ghost" size="icon"><MoreHorizontal className="h-4 w-4" /></Button></DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        {onEdit && <DropdownMenuItem onClick={() => onEdit(item)}>Edit</DropdownMenuItem>}
                        {onDelete && <DropdownMenuItem onClick={() => onDelete(item)} className="text-destructive">Delete</DropdownMenuItem>}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}
EOF
}

_cli2_comp_form_dialog() {
    local entity="${1:-item}"
    cat <<EOF
// --- Composition: FormDialog for ${entity} ---
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';

interface FormDialogProps { open: boolean; onClose: () => void; onSubmit: (data: any) => Promise<void>; title: string; defaultValues?: any; }

export function FormDialog({ open, onClose, onSubmit, title, defaultValues }: FormDialogProps) {
  const [submitting, setSubmitting] = useState(false);
  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setSubmitting(true);
    try {
      const formData = new FormData(e.currentTarget);
      await onSubmit(Object.fromEntries(formData));
      onClose();
    } catch (err) {
      alert(err instanceof Error ? err.message : 'Error');
    } finally { setSubmitting(false); }
  };
  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent>
        <DialogHeader><DialogTitle>{title}</DialogTitle></DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div><Label htmlFor="name">Name</Label><Input id="name" name="name" defaultValue={defaultValues?.name} required /></div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={submitting}>{submitting ? 'Saving...' : 'Save'}</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
EOF
}

_cli2_comp_delete_confirm() {
    local entity="${1:-item}"
    cat <<EOF
// --- Composition: DeleteConfirm for ${entity} ---
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';

interface DeleteConfirmProps { open: boolean; onClose: () => void; onConfirm: () => Promise<void>; itemName?: string; }

export function DeleteConfirm({ open, onClose, onConfirm, itemName }: DeleteConfirmProps) {
  const [deleting, setDeleting] = useState(false);
  const handleConfirm = async () => {
    setDeleting(true);
    try { await onConfirm(); onClose(); } catch { alert('Delete failed'); } finally { setDeleting(false); }
  };
  return (
    <AlertDialog open={open} onOpenChange={onClose}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
          <AlertDialogDescription>This will permanently delete {itemName || 'this item'}. This action cannot be undone.</AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>Cancel</AlertDialogCancel>
          <AlertDialogAction onClick={handleConfirm} disabled={deleting} className="bg-destructive text-destructive-foreground">
            {deleting ? 'Deleting...' : 'Delete'}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}
EOF
}

_cli2_comp_stats_cards() {
    cat <<'EOF'
// --- Composition: StatsCards ---
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Skeleton } from '@/components/ui/skeleton';

interface StatCard { title: string; value: string | number; description?: string; icon?: React.ReactNode; trend?: number; }

export function StatsCards({ stats, isLoading }: { stats: StatCard[]; isLoading?: boolean }) {
  if (isLoading) return <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">{[...Array(4)].map((_, i) => <Skeleton key={i} className="h-32" />)}</div>;
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map(stat => (
        <Card key={stat.title}>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">{stat.title}</CardTitle>
            {stat.icon}
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stat.value}</div>
            {stat.description && <p className="text-xs text-muted-foreground mt-1">{stat.description}</p>}
            {stat.trend !== undefined && <p className={`text-xs mt-1 ${stat.trend >= 0 ? 'text-green-600' : 'text-red-600'}`}>{stat.trend >= 0 ? '+' : ''}{stat.trend}% from last month</p>}
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
EOF
}

_cli2_comp_search_command() {
    cat <<'EOF'
// --- Composition: SearchCommand ---
import { Command, CommandDialog, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandList } from '@/components/ui/command';
import { useEffect, useState } from 'react';

export function SearchCommand() {
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const down = (e: KeyboardEvent) => { if (e.key === 'k' && (e.metaKey || e.ctrlKey)) { e.preventDefault(); setOpen(o => !o); } };
    document.addEventListener('keydown', down);
    return () => document.removeEventListener('keydown', down);
  }, []);
  return (
    <CommandDialog open={open} onOpenChange={setOpen}>
      <CommandInput placeholder="Type a command or search..." />
      <CommandList>
        <CommandEmpty>No results found.</CommandEmpty>
        <CommandGroup heading="Navigation">
          <CommandItem onSelect={() => { window.location.href = '/dashboard'; setOpen(false); }}>Dashboard</CommandItem>
          <CommandItem onSelect={() => { window.location.href = '/settings'; setOpen(false); }}>Settings</CommandItem>
        </CommandGroup>
      </CommandList>
    </CommandDialog>
  );
}
EOF
}

_cli2_comp_sidebar_nav() {
    cat <<'EOF'
// --- Composition: SidebarNav ---
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu } from 'lucide-react';

interface NavItem { label: string; href: string; icon?: React.ReactNode; }

export function SidebarNav({ items }: { items: NavItem[] }) {
  const pathname = usePathname();
  const NavLinks = () => (
    <nav className="flex flex-col gap-1 p-4">
      {items.map(item => (
        <Link key={item.href} href={item.href}
          className={cn('flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-colors',
            pathname === item.href ? 'bg-primary text-primary-foreground' : 'hover:bg-muted')}>
          {item.icon}{item.label}
        </Link>
      ))}
    </nav>
  );
  return (
    <>
      <aside className="hidden md:flex md:w-64 md:flex-col border-r"><NavLinks /></aside>
      <Sheet>
        <SheetTrigger asChild><Button variant="ghost" size="icon" className="md:hidden"><Menu className="h-5 w-5" /></Button></SheetTrigger>
        <SheetContent side="left" className="w-64 p-0"><NavLinks /></SheetContent>
      </Sheet>
    </>
  );
}
EOF
}

# =============================================================================
# _cli2_inject_imports - Auto-inject correct imports for components
# =============================================================================
_cli2_inject_imports() {
    local file_path="${1:-}"
    [[ -z "$file_path" || ! -f "$file_path" ]] && { _cli2_err "File path required"; return 1; }

    local content
    content=$(cat "$file_path" 2>/dev/null)
    local injected=0

    for comp in "${!CLI2_SHADCN_COMPONENTS[@]}"; do
        local import_path="${CLI2_SHADCN_COMPONENTS[$comp]}"
        # Check if component is used but not imported
        if echo "$content" | grep -q "<${comp}" && ! echo "$content" | grep -q "from '${import_path}'"; then
            _cli2_log "Missing import: ${comp} from ${import_path}"
            injected=$((injected + 1))
        fi
    done

    CLI2_IMPORTS_INJECTED=$((CLI2_IMPORTS_INJECTED + injected))
    [[ $injected -gt 0 ]] && _cli2_warn "${injected} missing imports detected" || _cli2_ok "All imports present"
    echo "$injected"
}

# =============================================================================
# _cli2_check_component_usage - Audit component usage consistency
# =============================================================================
_cli2_check_component_usage() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local issues=()
    local score=100

    _cli2_log "Auditing component usage..."

    local tsx_files
    tsx_files=$(find "$project_dir" -name "*.tsx" -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null)
    [[ -z "$tsx_files" ]] && { echo '{"score":0,"issues":["No TSX files found"]}'; return 1; }

    # Check for native HTML where shadcn should be used
    local native_button=0 native_input=0 native_select=0
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue

        echo "$content" | grep -qE '<button\s' && native_button=$((native_button + 1))
        echo "$content" | grep -qE '<input\s' && ! echo "$content" | grep -q "react-hook-form\|register(" && native_input=$((native_input + 1))
        echo "$content" | grep -qE '<select\s' && native_select=$((native_select + 1))
    done <<< "$tsx_files"

    [[ $native_button -gt 3 ]] && { issues+=("${native_button} files use native <button> instead of <Button>"); score=$((score - 15)); }
    [[ $native_input -gt 3 ]] && { issues+=("${native_input} files use native <input> instead of <Input>"); score=$((score - 10)); }
    [[ $native_select -gt 2 ]] && { issues+=("${native_select} files use native <select> instead of <Select>"); score=$((score - 10)); }

    [[ $score -lt 0 ]] && score=0

    echo "{"
    echo "  \"score\": ${score},"
    echo "  \"library\": \"${CLI2_DETECTED_LIBRARY:-unknown}\","
    echo "  \"issues\": ["
    local first=true
    for issue in "${issues[@]}"; do
        $first || echo ","
        echo -n "    \"${issue}\""
        first=false
    done
    echo ""
    echo "  ]"
    echo "}"
}

# =============================================================================
# Report / Score
# =============================================================================
cli2_report() {
    echo -e "\n  ${CLI2_BOLD}=== Component Library Integrator v${CLI2_VERSION} ===${CLI2_NC}"
    echo -e "  Detected library     : ${CLI2_DETECTED_LIBRARY:-none}"
    echo -e "  Compositions generated: ${CLI2_COMPOSITIONS_GENERATED}"
    echo -e "  Imports injected      : ${CLI2_IMPORTS_INJECTED}"
}

cli2_score() {
    [[ "$CLI2_INITIALIZED" == "true" ]] && echo 100 || echo 0
}

# =============================================================================
# v59.0: Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "component-library-integrator" \
        --version "224.0" \
        --description "shadcn/ui integration (detect/suggest/compose/import)" \
        --init "cli2_init" \
        --report "cli2_report" \
        --score "cli2_score" \
        --enable-var "ENABLE_COMPONENT_LIBRARY" \
        --cli-flags "--component-library:--no-component-library"
fi

# v2003.1: source時のexit codeを確実に0にする
true
