#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v303.0 - LP/Marketing Page Generator
# =============================================================================
# ランディングページ自動生成: Hero/Features/Pricing/Testimonials/CTA/Footer
#
# 全globals: LMG_ prefix
# =============================================================================

[[ -n "${_LP_MARKETING_GENERATOR_LOADED:-}" ]] && return 0
_LP_MARKETING_GENERATOR_LOADED=1

declare -g LMG_VERSION="303.0"
declare -g LMG_INITIALIZED=false
declare -g LMG_GENERATED_COUNT=0
declare -g ENABLE_LP_MARKETING_GENERATOR="${ENABLE_LP_MARKETING_GENERATOR:-true}"

readonly LMG_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly LMG_YELLOW="${CLR_YELLOW:-\033[0;33m}"
readonly LMG_RED="${CLR_RED:-\033[0;31m}"
readonly LMG_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly LMG_BOLD="${CLR_BOLD:-\033[1m}"
readonly LMG_NC="${CLR_NC:-\033[0m}"

_lmg_log() { echo -e "  ${LMG_CYAN}[LMG]${LMG_NC} $*" >&2; }
_lmg_ok()  { echo -e "  ${LMG_GREEN}[LMG] OK${LMG_NC} $*" >&2; }
_lmg_warn(){ echo -e "  ${LMG_YELLOW}[LMG] WARN${LMG_NC} $*" >&2; }
_lmg_err() { echo -e "  ${LMG_RED}[LMG] ERR${LMG_NC} $*" >&2; }

lmg_init() { LMG_INITIALIZED=true; LMG_GENERATED_COUNT=0; return 0; }

lmg_report() {
    [[ "$LMG_INITIALIZED" != "true" ]] && return 0
    echo -e "\n  ${LMG_BOLD}--- LP/Marketing Generator v${LMG_VERSION} ---${LMG_NC}" >&2
    echo -e "  生成セクション数: ${LMG_GENERATED_COUNT}" >&2
}

lmg_score() {
    [[ "$LMG_INITIALIZED" != "true" ]] && { echo "0"; return; }
    local s=50; [[ $LMG_GENERATED_COUNT -ge 4 ]] && s=80; [[ $LMG_GENERATED_COUNT -ge 6 ]] && s=95; echo "$s"
}

lmg_init_message() { echo -e "  ${LMG_GREEN}v${LMG_VERSION} lp-marketing-generator: LP/マーケティングページ自動生成${LMG_NC}" >&2; }

# =============================================================================
# _lmg_generate_hero() - Hero section
# =============================================================================
_lmg_generate_hero() {
    local project_dir="${1:-.}"
    local headline="${2:-ビジネスを次のレベルへ}"
    local subheadline="${3:-最先端のソリューションで業務効率を10倍に}"
    _lmg_log "Hero セクション生成"

    local comp_dir="${project_dir}/src/components/landing"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/HeroSection.tsx" <<HERO_EOF
'use client';
import Link from 'next/link';
import { ArrowRight, Play } from 'lucide-react';

interface HeroProps {
  headline?: string;
  subheadline?: string;
  ctaText?: string;
  ctaHref?: string;
  secondaryCta?: string;
  secondaryHref?: string;
  imageUrl?: string;
}

export function HeroSection({
  headline = '${headline}',
  subheadline = '${subheadline}',
  ctaText = '無料で始める',
  ctaHref = '/signup',
  secondaryCta = 'デモを見る',
  secondaryHref = '#demo',
  imageUrl,
}: HeroProps) {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-blue-600 via-blue-700 to-indigo-800">
      <div className="absolute inset-0 bg-[url('/grid.svg')] opacity-10" />
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24 sm:py-32 relative">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight">
              {headline}
            </h1>
            <p className="mt-6 text-lg sm:text-xl text-blue-100 max-w-lg">
              {subheadline}
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link href={ctaHref}
                className="bg-white text-blue-700 px-8 py-3 rounded-lg font-semibold text-lg hover:bg-blue-50 transition flex items-center gap-2 shadow-lg">
                {ctaText} <ArrowRight size={20} />
              </Link>
              <Link href={secondaryHref}
                className="border-2 border-white/30 text-white px-8 py-3 rounded-lg font-semibold text-lg hover:bg-white/10 transition flex items-center gap-2">
                <Play size={20} /> {secondaryCta}
              </Link>
            </div>
            <div className="mt-8 flex items-center gap-6 text-blue-200 text-sm">
              <span>14日間無料トライアル</span>
              <span>クレジットカード不要</span>
            </div>
          </div>
          <div className="hidden lg:block">
            {imageUrl ? (
              <img src={imageUrl} alt="Hero" className="rounded-2xl shadow-2xl" />
            ) : (
              <div className="bg-white/10 backdrop-blur rounded-2xl p-8 aspect-video flex items-center justify-center border border-white/20">
                <span className="text-white/50 text-lg">ヒーローイメージ</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
HERO_EOF

    LMG_GENERATED_COUNT=$((LMG_GENERATED_COUNT + 1))
    _lmg_ok "Hero セクション生成完了"
    return 0
}

# =============================================================================
# _lmg_generate_features() - Features section
# =============================================================================
_lmg_generate_features() {
    local project_dir="${1:-.}"
    _lmg_log "Features セクション生成"

    local comp_dir="${project_dir}/src/components/landing"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/FeaturesSection.tsx" <<'EOF'
import { Zap, Shield, BarChart3, Globe, Clock, Users } from 'lucide-react';

const defaultFeatures = [
  { icon: <Zap size={24} />, title: '高速パフォーマンス', description: 'ミリ秒レベルの応答速度で業務効率を最大化' },
  { icon: <Shield size={24} />, title: 'セキュリティ', description: 'エンタープライズグレードのセキュリティで安心' },
  { icon: <BarChart3 size={24} />, title: 'データ分析', description: 'リアルタイムダッシュボードで意思決定をサポート' },
  { icon: <Globe size={24} />, title: 'グローバル対応', description: '多言語・多通貨対応で海外展開もスムーズ' },
  { icon: <Clock size={24} />, title: '24/7サポート', description: '専任チームが24時間365日サポート' },
  { icon: <Users size={24} />, title: 'チーム管理', description: '柔軟な権限管理でチームコラボレーションを促進' },
];

interface Feature { icon: React.ReactNode; title: string; description: string; }

export function FeaturesSection({ features = defaultFeatures }: { features?: Feature[] }) {
  return (
    <section className="py-20 bg-white" id="features">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900">主な機能</h2>
          <p className="mt-4 text-lg text-gray-600">必要な機能をすべてひとつのプラットフォームで</p>
        </div>
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((f, i) => (
            <div key={i} className="p-6 rounded-xl border hover:shadow-lg transition group">
              <div className="w-12 h-12 bg-blue-50 rounded-lg flex items-center justify-center text-blue-600 mb-4 group-hover:bg-blue-600 group-hover:text-white transition">
                {f.icon}
              </div>
              <h3 className="text-lg font-semibold mb-2">{f.title}</h3>
              <p className="text-gray-600 text-sm leading-relaxed">{f.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
EOF

    LMG_GENERATED_COUNT=$((LMG_GENERATED_COUNT + 1))
    _lmg_ok "Features セクション生成完了"
    return 0
}

# =============================================================================
# _lmg_generate_pricing() - Pricing table
# =============================================================================
_lmg_generate_pricing() {
    local project_dir="${1:-.}"
    _lmg_log "Pricing セクション生成"

    local comp_dir="${project_dir}/src/components/landing"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/PricingSection.tsx" <<'EOF'
import { Check } from 'lucide-react';
import Link from 'next/link';

const plans = [
  { name: 'スターター', price: '¥0', period: '/月', description: '個人利用に最適', features: ['5ユーザーまで', '1GBストレージ', 'メールサポート', '基本分析'], cta: '無料で始める', popular: false },
  { name: 'プロ', price: '¥4,980', period: '/月', description: '成長中のチームに', features: ['50ユーザーまで', '100GBストレージ', '優先サポート', '高度な分析', 'API連携', 'カスタムドメイン'], cta: 'プロを選択', popular: true },
  { name: 'エンタープライズ', price: '要相談', period: '', description: '大規模組織向け', features: ['無制限ユーザー', '無制限ストレージ', '24/7専任サポート', '全機能利用可', 'SLA保証', 'オンプレミス対応'], cta: 'お問い合わせ', popular: false },
];

export function PricingSection() {
  return (
    <section className="py-20 bg-gray-50" id="pricing">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold">料金プラン</h2>
          <p className="mt-4 text-lg text-gray-600">ビジネスの規模に合わせて選べるプラン</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          {plans.map(plan => (
            <div key={plan.name} className={`bg-white rounded-2xl p-8 ${plan.popular ? 'ring-2 ring-blue-600 shadow-xl relative' : 'border shadow'}`}>
              {plan.popular && <span className="absolute -top-4 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-xs px-4 py-1 rounded-full font-medium">人気</span>}
              <h3 className="text-xl font-bold">{plan.name}</h3>
              <p className="text-gray-500 text-sm mt-1">{plan.description}</p>
              <div className="mt-6 mb-8">
                <span className="text-4xl font-bold">{plan.price}</span>
                <span className="text-gray-500">{plan.period}</span>
              </div>
              <ul className="space-y-3 mb-8">
                {plan.features.map(f => (
                  <li key={f} className="flex items-center gap-2 text-sm"><Check size={16} className="text-green-500 flex-shrink-0" /> {f}</li>
                ))}
              </ul>
              <Link href="/signup" className={`block text-center py-3 rounded-lg font-medium ${plan.popular ? 'bg-blue-600 text-white hover:bg-blue-700' : 'border border-gray-300 hover:bg-gray-50'}`}>
                {plan.cta}
              </Link>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
EOF

    LMG_GENERATED_COUNT=$((LMG_GENERATED_COUNT + 1))
    _lmg_ok "Pricing セクション生成完了"
    return 0
}

# =============================================================================
# _lmg_generate_testimonials() - Testimonials section
# =============================================================================
_lmg_generate_testimonials() {
    local project_dir="${1:-.}"
    _lmg_log "Testimonials セクション生成"

    local comp_dir="${project_dir}/src/components/landing"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/TestimonialsSection.tsx" <<'EOF'
import { Star } from 'lucide-react';

const testimonials = [
  { name: '田中太郎', company: '株式会社テクノ', role: 'CTO', text: '導入後、業務効率が3倍に。チーム全員が満足しています。', rating: 5 },
  { name: '鈴木花子', company: 'デザインラボ', role: 'CEO', text: 'UIが直感的で、オンボーディングがスムーズでした。サポートも素晴らしい。', rating: 5 },
  { name: '佐藤一郎', company: 'グローバルEC', role: 'プロダクトマネージャー', text: 'API連携の柔軟性が決め手。既存システムとの統合も簡単でした。', rating: 4 },
];

export function TestimonialsSection() {
  return (
    <section className="py-20 bg-white" id="testimonials">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold">お客様の声</h2>
          <p className="mt-4 text-lg text-gray-600">1,000社以上の企業に選ばれています</p>
        </div>
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((t, i) => (
            <div key={i} className="bg-gray-50 rounded-xl p-6">
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, j) => (
                  <Star key={j} size={16} className={j < t.rating ? 'text-yellow-400 fill-yellow-400' : 'text-gray-300'} />
                ))}
              </div>
              <p className="text-gray-700 mb-6 leading-relaxed">&ldquo;{t.text}&rdquo;</p>
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-sm">
                  {t.name.charAt(0)}
                </div>
                <div>
                  <p className="font-medium text-sm">{t.name}</p>
                  <p className="text-gray-500 text-xs">{t.role} - {t.company}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
EOF

    LMG_GENERATED_COUNT=$((LMG_GENERATED_COUNT + 1))
    _lmg_ok "Testimonials セクション生成完了"
    return 0
}

# =============================================================================
# _lmg_generate_cta() - CTA section with form
# =============================================================================
_lmg_generate_cta() {
    local project_dir="${1:-.}"
    _lmg_log "CTA セクション生成"

    local comp_dir="${project_dir}/src/components/landing"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/CTASection.tsx" <<'EOF'
'use client';
import { useState } from 'react';
import { ArrowRight, CheckCircle } from 'lucide-react';

export function CTASection() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setLoading(true);
    try {
      await fetch('/api/newsletter', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ email }) });
      setSubmitted(true);
    } catch { /* silent */ } finally { setLoading(false); }
  };

  return (
    <section className="py-20 bg-gradient-to-r from-blue-600 to-indigo-700" id="cta">
      <div className="max-w-4xl mx-auto px-4 text-center">
        <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">今すぐ始めましょう</h2>
        <p className="text-blue-100 text-lg mb-8">14日間の無料トライアル。いつでもキャンセル可能。</p>
        {submitted ? (
          <div className="flex items-center justify-center gap-2 text-white"><CheckCircle size={24} /> <span className="text-lg">ありがとうございます！確認メールを送信しました。</span></div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col sm:flex-row gap-3 max-w-lg mx-auto">
            <input type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="メールアドレス" required
              className="flex-1 px-4 py-3 rounded-lg text-gray-900 focus:ring-2 focus:ring-white focus:outline-none" />
            <button type="submit" disabled={loading}
              className="bg-white text-blue-700 px-8 py-3 rounded-lg font-semibold hover:bg-blue-50 transition flex items-center justify-center gap-2 disabled:opacity-50">
              {loading ? '送信中...' : <><span>無料で始める</span> <ArrowRight size={18} /></>}
            </button>
          </form>
        )}
      </div>
    </section>
  );
}
EOF

    LMG_GENERATED_COUNT=$((LMG_GENERATED_COUNT + 1))
    _lmg_ok "CTA セクション生成完了"
    return 0
}

# =============================================================================
# _lmg_generate_footer() - Footer with links
# =============================================================================
_lmg_generate_footer() {
    local project_dir="${1:-.}"
    _lmg_log "Footer 生成"

    local comp_dir="${project_dir}/src/components/landing"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/Footer.tsx" <<'EOF'
import Link from 'next/link';

const footerLinks = {
  'プロダクト': [{ label: '機能', href: '#features' }, { label: '料金', href: '#pricing' }, { label: 'ロードマップ', href: '/roadmap' }],
  'サポート': [{ label: 'ヘルプセンター', href: '/help' }, { label: 'ドキュメント', href: '/docs' }, { label: 'お問い合わせ', href: '/contact' }],
  '会社情報': [{ label: '会社概要', href: '/about' }, { label: 'ブログ', href: '/blog' }, { label: '採用', href: '/careers' }],
  '法的情報': [{ label: 'プライバシーポリシー', href: '/privacy' }, { label: '利用規約', href: '/terms' }, { label: '特定商取引法', href: '/tokushoho' }],
};

export function Footer() {
  return (
    <footer className="bg-gray-900 text-gray-300 py-16">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 md:grid-cols-5 gap-8">
          <div className="col-span-2 md:col-span-1">
            <span className="text-white font-bold text-xl">SoloptiLinkAI</span>
            <p className="mt-3 text-sm text-gray-400">ビジネスを次のレベルへ</p>
          </div>
          {Object.entries(footerLinks).map(([category, links]) => (
            <div key={category}>
              <h3 className="text-white font-medium mb-4 text-sm">{category}</h3>
              <ul className="space-y-2">
                {links.map(l => (
                  <li key={l.href}><Link href={l.href} className="text-sm hover:text-white transition">{l.label}</Link></li>
                ))}
              </ul>
            </div>
          ))}
        </div>
        <div className="border-t border-gray-800 mt-12 pt-8 text-sm text-gray-500 text-center">
          &copy; {new Date().getFullYear()} SoloptiLinkAI. All rights reserved.
        </div>
      </div>
    </footer>
  );
}
EOF

    LMG_GENERATED_COUNT=$((LMG_GENERATED_COUNT + 1))
    _lmg_ok "Footer 生成完了"
    return 0
}

# =============================================================================
# Module Registration
# =============================================================================
_mr_register \
    --name "lp-marketing-generator" \
    --version "303.0" \
    --description "LP/マーケティングページ自動生成（Hero/Features/Pricing/CTA/Footer）" \
    --init "lmg_init" \
    --report "lmg_report" \
    --score "lmg_score" \
    --enable-var "ENABLE_LP_MARKETING_GENERATOR" \
    --cli-flags "--lp-marketing:--no-lp-marketing" \
    --init-msg "lmg_init_message"
