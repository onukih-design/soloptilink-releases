#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v272.0 - Compile-Time Safety Net
# =============================================================================
# ビルド前にTypeScript strict/ESLint/Prettier/lint-stagedを設定し、
# コンパイル時に最大限のバグを検出するセーフティネット。
#
# Functions:
#   _ctsn_init              - 初期化
#   _ctsn_setup_strict_ts   - strict TypeScript設定
#   _ctsn_setup_eslint_strict - strict ESLint設定
#   _ctsn_setup_prettier    - Prettier設定
#   _ctsn_setup_lint_staged - lint-staged設定
#   _ctsn_validate_config   - 設定整合性検証
#   _ctsn_report            - レポート出力
#   _ctsn_score             - スコア算出(0-100)
#
# All globals use the CTSN_ prefix.
# =============================================================================

[[ -n "${_COMPILE_TIME_SAFETY_NET_LOADED:-}" ]] && return 0
_COMPILE_TIME_SAFETY_NET_LOADED=1

CTSN_VERSION="272.0"
CTSN_INITIALIZED=false
ENABLE_CTSN="${ENABLE_CTSN:-true}"

# Counters
CTSN_TS_CONFIGURED=false
CTSN_ESLINT_CONFIGURED=false
CTSN_PRETTIER_CONFIGURED=false
CTSN_LINT_STAGED_CONFIGURED=false
CTSN_VALIDATION_ISSUES=0
CTSN_TOTAL_SETUPS=0

# Storage
CTSN_WORK_DIR=""
declare -g -a _CTSN_ISSUES=()
declare -g -a _CTSN_APPLIED=()

# =============================================================================
# _ctsn_init
# =============================================================================
_ctsn_init() {
    CTSN_WORK_DIR="${HOME}/.soloptilink/compile-safety"
    mkdir -p "$CTSN_WORK_DIR" 2>/dev/null || true

    CTSN_TS_CONFIGURED=false
    CTSN_ESLINT_CONFIGURED=false
    CTSN_PRETTIER_CONFIGURED=false
    CTSN_LINT_STAGED_CONFIGURED=false
    CTSN_VALIDATION_ISSUES=0
    CTSN_TOTAL_SETUPS=0
    _CTSN_ISSUES=()
    _CTSN_APPLIED=()

    CTSN_INITIALIZED=true
    return 0
}

# =============================================================================
# _ctsn_setup_strict_ts - Setup strict TypeScript config
# Usage: _ctsn_setup_strict_ts <project_dir>
# =============================================================================
_ctsn_setup_strict_ts() {
    [[ "$CTSN_INITIALIZED" != "true" ]] && _ctsn_init
    local project_dir="${1:-.}"
    local tsconfig="${project_dir}/tsconfig.json"

    echo -e "  ${CYAN:-}[CTSN] Setting up strict TypeScript...${NC:-}" >&2

    if [[ ! -f "$tsconfig" ]]; then
        # Generate strict tsconfig
        cat > "$tsconfig" << 'TSEOF'
{
  "compilerOptions": {
    "target": "ES2022",
    "lib": ["ES2022", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "moduleResolution": "bundler",
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "noImplicitOverride": true,
    "noPropertyAccessFromIndexSignature": true,
    "noFallthroughCasesInSwitch": true,
    "exactOptionalPropertyTypes": false,
    "forceConsistentCasingInFileNames": true,
    "isolatedModules": true,
    "verbatimModuleSyntax": false,
    "skipLibCheck": true,
    "esModuleInterop": true,
    "resolveJsonModule": true,
    "jsx": "react-jsx",
    "incremental": true,
    "declaration": true,
    "declarationMap": true,
    "sourceMap": true,
    "outDir": "./dist",
    "baseUrl": ".",
    "paths": {
      "@/*": ["./src/*"]
    }
  },
  "include": ["src/**/*.ts", "src/**/*.tsx"],
  "exclude": ["node_modules", "dist", "**/*.test.ts"]
}
TSEOF
        _CTSN_APPLIED+=("Created strict tsconfig.json")
    else
        # Validate existing config for strictness
        local has_strict=false
        if grep -q '"strict"\s*:\s*true' "$tsconfig" 2>/dev/null; then
            has_strict=true
        fi

        if [[ "$has_strict" != "true" ]]; then
            _CTSN_ISSUES+=("tsconfig.json: 'strict' is not enabled")
            CTSN_VALIDATION_ISSUES=$((CTSN_VALIDATION_ISSUES + 1))
        fi

        # Check for noUncheckedIndexedAccess
        if ! grep -q '"noUncheckedIndexedAccess"' "$tsconfig" 2>/dev/null; then
            _CTSN_ISSUES+=("tsconfig.json: 'noUncheckedIndexedAccess' not set")
            CTSN_VALIDATION_ISSUES=$((CTSN_VALIDATION_ISSUES + 1))
        fi

        # Check for noImplicitOverride
        if ! grep -q '"noImplicitOverride"' "$tsconfig" 2>/dev/null; then
            _CTSN_ISSUES+=("tsconfig.json: 'noImplicitOverride' not set")
            CTSN_VALIDATION_ISSUES=$((CTSN_VALIDATION_ISSUES + 1))
        fi

        # Check for skipLibCheck (should be true for perf)
        if ! grep -q '"skipLibCheck"\s*:\s*true' "$tsconfig" 2>/dev/null; then
            _CTSN_ISSUES+=("tsconfig.json: 'skipLibCheck' should be true for build performance")
        fi

        _CTSN_APPLIED+=("Validated existing tsconfig.json")
    fi

    CTSN_TS_CONFIGURED=true
    CTSN_TOTAL_SETUPS=$((CTSN_TOTAL_SETUPS + 1))
    return 0
}

# =============================================================================
# _ctsn_setup_eslint_strict - Setup strict ESLint rules
# Usage: _ctsn_setup_eslint_strict <project_dir>
# =============================================================================
_ctsn_setup_eslint_strict() {
    [[ "$CTSN_INITIALIZED" != "true" ]] && _ctsn_init
    local project_dir="${1:-.}"

    echo -e "  ${CYAN:-}[CTSN] Setting up strict ESLint...${NC:-}" >&2

    local eslint_config=""
    for candidate in ".eslintrc.js" ".eslintrc.cjs" ".eslintrc.json" "eslint.config.js" "eslint.config.mjs"; do
        [[ -f "${project_dir}/${candidate}" ]] && { eslint_config="${project_dir}/${candidate}"; break; }
    done

    if [[ -z "$eslint_config" ]]; then
        # Create eslint.config.mjs (flat config)
        cat > "${project_dir}/eslint.config.mjs" << 'ESLEOF'
import js from '@eslint/js';
import tseslint from 'typescript-eslint';

export default tseslint.config(
  js.configs.recommended,
  ...tseslint.configs.strictTypeChecked,
  ...tseslint.configs.stylisticTypeChecked,
  {
    languageOptions: {
      parserOptions: {
        projectService: true,
        tsconfigRootDir: import.meta.dirname,
      },
    },
    rules: {
      '@typescript-eslint/no-unused-vars': ['error', { argsIgnorePattern: '^_' }],
      '@typescript-eslint/no-explicit-any': 'error',
      '@typescript-eslint/no-non-null-assertion': 'error',
      '@typescript-eslint/prefer-nullish-coalescing': 'warn',
      '@typescript-eslint/prefer-optional-chain': 'warn',
      '@typescript-eslint/strict-boolean-expressions': 'warn',
      '@typescript-eslint/switch-exhaustiveness-check': 'error',
      'no-console': ['warn', { allow: ['warn', 'error'] }],
      'eqeqeq': ['error', 'always'],
      'no-eval': 'error',
      'no-implied-eval': 'error',
      'no-var': 'error',
      'prefer-const': 'error',
      'prefer-template': 'warn',
      'no-throw-literal': 'error',
    },
  },
  {
    ignores: ['dist/', 'node_modules/', '*.config.*'],
  }
);
ESLEOF
        _CTSN_APPLIED+=("Created eslint.config.mjs with strict rules")
    else
        # Validate existing config
        if grep -qE 'no-explicit-any.*off|no-explicit-any.*0' "$eslint_config" 2>/dev/null; then
            _CTSN_ISSUES+=("ESLint: @typescript-eslint/no-explicit-any is disabled")
            CTSN_VALIDATION_ISSUES=$((CTSN_VALIDATION_ISSUES + 1))
        fi

        if ! grep -q 'eqeqeq' "$eslint_config" 2>/dev/null; then
            _CTSN_ISSUES+=("ESLint: 'eqeqeq' rule not configured")
            CTSN_VALIDATION_ISSUES=$((CTSN_VALIDATION_ISSUES + 1))
        fi

        _CTSN_APPLIED+=("Validated existing ESLint config")
    fi

    CTSN_ESLINT_CONFIGURED=true
    CTSN_TOTAL_SETUPS=$((CTSN_TOTAL_SETUPS + 1))
    return 0
}

# =============================================================================
# _ctsn_setup_prettier - Setup Prettier for consistent formatting
# Usage: _ctsn_setup_prettier <project_dir>
# =============================================================================
_ctsn_setup_prettier() {
    [[ "$CTSN_INITIALIZED" != "true" ]] && _ctsn_init
    local project_dir="${1:-.}"

    echo -e "  ${CYAN:-}[CTSN] Setting up Prettier...${NC:-}" >&2

    local prettier_config=""
    for candidate in ".prettierrc" ".prettierrc.js" ".prettierrc.json" "prettier.config.js"; do
        [[ -f "${project_dir}/${candidate}" ]] && { prettier_config="${project_dir}/${candidate}"; break; }
    done

    if [[ -z "$prettier_config" ]]; then
        cat > "${project_dir}/.prettierrc" << 'PRETEOF'
{
  "semi": true,
  "trailingComma": "all",
  "singleQuote": true,
  "printWidth": 100,
  "tabWidth": 2,
  "useTabs": false,
  "bracketSpacing": true,
  "arrowParens": "always",
  "endOfLine": "lf",
  "plugins": []
}
PRETEOF

        cat > "${project_dir}/.prettierignore" << 'PIGEOF'
dist/
node_modules/
.next/
coverage/
*.min.js
*.min.css
package-lock.json
pnpm-lock.yaml
PIGEOF

        _CTSN_APPLIED+=("Created .prettierrc and .prettierignore")
    else
        _CTSN_APPLIED+=("Validated existing Prettier config")
    fi

    CTSN_PRETTIER_CONFIGURED=true
    CTSN_TOTAL_SETUPS=$((CTSN_TOTAL_SETUPS + 1))
    return 0
}

# =============================================================================
# _ctsn_setup_lint_staged - Setup lint-staged for pre-commit checks
# Usage: _ctsn_setup_lint_staged <project_dir>
# =============================================================================
_ctsn_setup_lint_staged() {
    [[ "$CTSN_INITIALIZED" != "true" ]] && _ctsn_init
    local project_dir="${1:-.}"

    echo -e "  ${CYAN:-}[CTSN] Setting up lint-staged...${NC:-}" >&2

    local has_lint_staged=false
    if [[ -f "${project_dir}/.lintstagedrc" ]] || [[ -f "${project_dir}/.lintstagedrc.json" ]]; then
        has_lint_staged=true
    fi

    # Check package.json for lint-staged config
    if [[ -f "${project_dir}/package.json" ]] && grep -q '"lint-staged"' "${project_dir}/package.json" 2>/dev/null; then
        has_lint_staged=true
    fi

    if [[ "$has_lint_staged" != "true" ]]; then
        cat > "${project_dir}/.lintstagedrc.json" << 'LSEOF'
{
  "*.{ts,tsx}": [
    "eslint --fix --max-warnings=0",
    "prettier --write"
  ],
  "*.{js,jsx,mjs,cjs}": [
    "eslint --fix",
    "prettier --write"
  ],
  "*.{json,md,yml,yaml}": [
    "prettier --write"
  ],
  "*.css": [
    "prettier --write"
  ]
}
LSEOF
        _CTSN_APPLIED+=("Created .lintstagedrc.json")

        # Setup husky if git repo
        if [[ -d "${project_dir}/.git" ]]; then
            mkdir -p "${project_dir}/.husky" 2>/dev/null || true
            cat > "${project_dir}/.husky/pre-commit" << 'HUSKYEOF'
#!/usr/bin/env sh
. "$(dirname -- "$0")/_/husky.sh"
npx lint-staged
HUSKYEOF
            chmod +x "${project_dir}/.husky/pre-commit" 2>/dev/null || true
            _CTSN_APPLIED+=("Created .husky/pre-commit hook")
        fi
    else
        _CTSN_APPLIED+=("Validated existing lint-staged config")
    fi

    CTSN_LINT_STAGED_CONFIGURED=true
    CTSN_TOTAL_SETUPS=$((CTSN_TOTAL_SETUPS + 1))
    return 0
}

# =============================================================================
# _ctsn_validate_config - Validate all tool configs are consistent
# Usage: _ctsn_validate_config <project_dir>
# =============================================================================
_ctsn_validate_config() {
    [[ "$CTSN_INITIALIZED" != "true" ]] && _ctsn_init
    local project_dir="${1:-.}"
    local issues_before=$CTSN_VALIDATION_ISSUES

    echo -e "  ${CYAN:-}[CTSN] Validating config consistency...${NC:-}" >&2

    # Check tsconfig exists
    if [[ ! -f "${project_dir}/tsconfig.json" ]]; then
        _CTSN_ISSUES+=("Missing tsconfig.json")
        CTSN_VALIDATION_ISSUES=$((CTSN_VALIDATION_ISSUES + 1))
    fi

    # Check ESLint and Prettier don't conflict
    local has_eslint_prettier=false
    if [[ -f "${project_dir}/package.json" ]]; then
        if grep -q 'eslint-config-prettier' "${project_dir}/package.json" 2>/dev/null; then
            has_eslint_prettier=true
        fi
    fi

    if [[ "$CTSN_ESLINT_CONFIGURED" == "true" ]] && [[ "$CTSN_PRETTIER_CONFIGURED" == "true" ]]; then
        if [[ "$has_eslint_prettier" != "true" ]]; then
            _CTSN_ISSUES+=("eslint-config-prettier not installed - ESLint and Prettier may conflict")
            CTSN_VALIDATION_ISSUES=$((CTSN_VALIDATION_ISSUES + 1))
        fi
    fi

    # Check package.json has required devDependencies
    if [[ -f "${project_dir}/package.json" ]]; then
        local pkg="${project_dir}/package.json"
        for dep in "typescript" "eslint" "prettier"; do
            if ! grep -q "\"${dep}\"" "$pkg" 2>/dev/null; then
                _CTSN_ISSUES+=("package.json missing devDependency: ${dep}")
                CTSN_VALIDATION_ISSUES=$((CTSN_VALIDATION_ISSUES + 1))
            fi
        done

        # Check scripts
        if ! grep -q '"lint"' "$pkg" 2>/dev/null; then
            _CTSN_ISSUES+=("package.json missing 'lint' script")
            CTSN_VALIDATION_ISSUES=$((CTSN_VALIDATION_ISSUES + 1))
        fi

        if ! grep -q '"type-check\|typecheck\|tsc"' "$pkg" 2>/dev/null; then
            _CTSN_ISSUES+=("package.json missing type-check script")
            CTSN_VALIDATION_ISSUES=$((CTSN_VALIDATION_ISSUES + 1))
        fi
    fi

    # Check .gitignore includes build artifacts
    if [[ -f "${project_dir}/.gitignore" ]]; then
        if ! grep -q 'dist' "${project_dir}/.gitignore" 2>/dev/null; then
            _CTSN_ISSUES+=(".gitignore missing 'dist' directory")
            CTSN_VALIDATION_ISSUES=$((CTSN_VALIDATION_ISSUES + 1))
        fi
        if ! grep -q 'node_modules' "${project_dir}/.gitignore" 2>/dev/null; then
            _CTSN_ISSUES+=(".gitignore missing 'node_modules'")
            CTSN_VALIDATION_ISSUES=$((CTSN_VALIDATION_ISSUES + 1))
        fi
    fi

    local new_issues=$((CTSN_VALIDATION_ISSUES - issues_before))
    if [[ $new_issues -eq 0 ]]; then
        echo -e "  ${GREEN:-}[CTSN] All configs consistent${NC:-}" >&2
    else
        echo -e "  ${YELLOW:-}[CTSN] ${new_issues} config issues found${NC:-}" >&2
    fi

    return 0
}

# =============================================================================
# _ctsn_setup_all - Run all setups
# =============================================================================
_ctsn_setup_all() {
    local project_dir="${1:-.}"
    _ctsn_setup_strict_ts "$project_dir"
    _ctsn_setup_eslint_strict "$project_dir"
    _ctsn_setup_prettier "$project_dir"
    _ctsn_setup_lint_staged "$project_dir"
    _ctsn_validate_config "$project_dir"
}

# =============================================================================
# _ctsn_report
# =============================================================================
_ctsn_report() {
    echo -e "\n  ${BOLD:-}═══ Compile-Time Safety Net v272.0 ═══${NC:-}"
    echo -e "  TypeScript strict  : ${CTSN_TS_CONFIGURED}"
    echo -e "  ESLint strict      : ${CTSN_ESLINT_CONFIGURED}"
    echo -e "  Prettier           : ${CTSN_PRETTIER_CONFIGURED}"
    echo -e "  lint-staged        : ${CTSN_LINT_STAGED_CONFIGURED}"
    echo -e "  Config issues      : ${CTSN_VALIDATION_ISSUES}"
    echo -e "  Applied changes    : ${#_CTSN_APPLIED[@]}"

    if [[ ${#_CTSN_ISSUES[@]} -gt 0 ]]; then
        echo -e "  ${YELLOW:-}--- Issues ---${NC:-}"
        for issue in "${_CTSN_ISSUES[@]}"; do
            echo -e "    ${YELLOW:-}${issue}${NC:-}"
        done
    fi
}

# =============================================================================
# _ctsn_score
# =============================================================================
_ctsn_score() {
    local score=50
    [[ "$CTSN_TS_CONFIGURED" == "true" ]] && score=$((score + 15))
    [[ "$CTSN_ESLINT_CONFIGURED" == "true" ]] && score=$((score + 15))
    [[ "$CTSN_PRETTIER_CONFIGURED" == "true" ]] && score=$((score + 10))
    [[ "$CTSN_LINT_STAGED_CONFIGURED" == "true" ]] && score=$((score + 10))
    [[ $CTSN_VALIDATION_ISSUES -eq 0 ]] && score=$((score + 5))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "compile-time-safety-net" \
    --version "272.0" \
    --description "TypeScript/ESLint/Prettier/lint-stagedのstrict設定一括セットアップ" \
    --init "_ctsn_init" \
    --report "_ctsn_report" \
    --score "_ctsn_score" \
    --enable-var "ENABLE_CTSN" \
    --cli-flags "--compile-time-safety:--no-compile-time-safety"
