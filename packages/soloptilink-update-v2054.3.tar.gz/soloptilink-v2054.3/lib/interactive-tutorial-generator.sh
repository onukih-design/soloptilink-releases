#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v400.0 - Interactive Tutorial Generator
# =============================================================================
# インタラクティブチュートリアル生成エンジン。
# ステップバイステップチュートリアル/演習問題/進捗追跡を自動生成。
# All globals use the ITG2_ prefix.
# =============================================================================

[[ -n "${_INTERACTIVE_TUTORIAL_GENERATOR_LOADED:-}" ]] && return 0
_INTERACTIVE_TUTORIAL_GENERATOR_LOADED=1

declare -g ITG2_VERSION="400.0"
declare -g ITG2_INITIALIZED=false
declare -g ITG2_GENERATED_COUNT=0
declare -g ITG2_TUTORIAL_GENERATED=false
declare -g ITG2_EXERCISES_GENERATED=false
declare -g ITG2_PROGRESS_GENERATED=false
declare -g ITG2_SANDBOX_GENERATED=false
declare -g ENABLE_ITG2="${ENABLE_ITG2:-true}"

_itg2_init() { ITG2_INITIALIZED=true; ITG2_GENERATED_COUNT=0; return 0; }

_itg2_generate_all() {
    local project_dir="${1:-.}"
    [[ "$ITG2_INITIALIZED" != "true" ]] && _itg2_init
    echo -e "  ${CYAN:-\033[0;36m}[ITG2]${NC:-\033[0m} チュートリアル生成開始..." >&2
    _itg2_generate_tutorial "$project_dir"
    _itg2_generate_exercises "$project_dir"
    _itg2_track_progress "$project_dir"
    _itg2_generate_sandbox "$project_dir"
    echo -e "  ${GREEN:-\033[0;32m}[ITG2]${NC:-\033[0m} チュートリアル生成完了: ${ITG2_GENERATED_COUNT}件" >&2
    return 0
}

_itg2_generate_tutorial() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [ITG2-TUTORIAL] チュートリアル生成

### Tutorial Definition
```typescript
interface Tutorial {
  id: string;
  title: string;
  description: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  estimatedMinutes: number;
  steps: TutorialStep[];
  prerequisites: string[];
}

interface TutorialStep {
  id: string;
  title: string;
  content: string;
  type: 'explanation' | 'code' | 'exercise' | 'quiz';
  code?: { language: string; initial: string; solution: string; hints: string[] };
  validation?: (userCode: string) => { passed: boolean; feedback: string };
}

// Project-specific tutorial generation
export function generateProjectTutorial(project: ProjectInfo): Tutorial[] {
  const tutorials: Tutorial[] = [];

  tutorials.push({
    id: 'getting-started', title: 'プロジェクト入門',
    description: `${project.name}の基本を学びます`, difficulty: 'beginner', estimatedMinutes: 30,
    prerequisites: [],
    steps: [
      { id: 'env-setup', title: '環境セットアップ', type: 'explanation',
        content: `まず開発環境をセットアップします。\n\n1. リポジトリをクローン\n2. 依存関係をインストール\n3. 環境変数を設定\n4. 開発サーバーを起動` },
      { id: 'project-structure', title: 'プロジェクト構成', type: 'explanation',
        content: generateStructureExplanation(project) },
      { id: 'first-page', title: '最初のページを作成', type: 'code',
        code: { language: 'tsx', initial: '// app/hello/page.tsx\nexport default function HelloPage() {\n  // ここにコードを書いてください\n}',
          solution: "export default function HelloPage() {\n  return <h1>Hello World</h1>;\n}", hints: ['export defaultを使用', 'JSXを返す'] } },
    ],
  });

  if (project.database.includes('Prisma')) {
    tutorials.push({
      id: 'database-basics', title: 'データベース操作入門',
      description: 'PrismaでCRUD操作を学びます', difficulty: 'beginner', estimatedMinutes: 45,
      prerequisites: ['getting-started'],
      steps: [
        { id: 'prisma-schema', title: 'スキーマ定義', type: 'explanation',
          content: 'Prismaスキーマでモデルを定義し、マイグレーションを実行します' },
        { id: 'crud-operations', title: 'CRUD操作', type: 'code',
          code: { language: 'typescript', initial: '// lib/services/todo.ts\nexport async function createTodo(title: string) {\n  // Prismaを使ってTodoを作成\n}',
            solution: "export async function createTodo(title: string) {\n  return prisma.todo.create({ data: { title } });\n}",
            hints: ['prisma.todo.create()を使用', 'dataオブジェクトでフィールドを指定'] } },
      ],
    });
  }

  return tutorials;
}
```

### Tutorial Component
```tsx
'use client';
export function TutorialViewer({ tutorialId }: { tutorialId: string }) {
  const { data: tutorial, isLoading } = useSWR(`/api/tutorials/${tutorialId}`);
  const [currentStep, setCurrentStep] = useState(0);
  const [userCode, setUserCode] = useState('');
  const [feedback, setFeedback] = useState<string | null>(null);

  if (isLoading) return <TutorialSkeleton />;
  const step = tutorial?.steps[currentStep];

  const handleCheck = () => {
    if (step?.validation) {
      const result = step.validation(userCode);
      setFeedback(result.feedback);
      if (result.passed) toast.success('正解！');
    }
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 h-[calc(100vh-80px)]">
      <div className="overflow-y-auto p-6">
        <ProgressBar current={currentStep + 1} total={tutorial.steps.length} />
        <h2 className="text-xl font-bold mt-4">{step?.title}</h2>
        <div className="prose mt-4" dangerouslySetInnerHTML={{ __html: renderMarkdown(step?.content ?? '') }} />
        {step?.code?.hints && (
          <details className="mt-4"><summary className="cursor-pointer text-primary">ヒントを見る</summary>
            <ul className="mt-2">{step.code.hints.map((h, i) => <li key={i}>{h}</li>)}</ul>
          </details>
        )}
      </div>
      {step?.type === 'code' && (
        <div className="flex flex-col">
          <CodeEditor value={userCode || step.code?.initial || ''} onChange={setUserCode} language={step.code?.language ?? 'typescript'} />
          {feedback && <div className="p-2 bg-muted text-sm">{feedback}</div>}
          <div className="flex gap-2 p-2">
            <Button variant="outline" onClick={() => setCurrentStep(Math.max(0, currentStep - 1))} disabled={currentStep === 0}>前へ</Button>
            <Button onClick={handleCheck}>チェック</Button>
            <Button onClick={() => setCurrentStep(Math.min(tutorial.steps.length - 1, currentStep + 1))}>次へ</Button>
          </div>
        </div>
      )}
    </div>
  );
}
```
TEMPLATE
    ITG2_TUTORIAL_GENERATED=true
    ITG2_GENERATED_COUNT=$((ITG2_GENERATED_COUNT + 1))
    return 0
}

_itg2_generate_exercises() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [ITG2-EXERCISES] 演習問題生成

```typescript
interface Exercise {
  id: string;
  title: string;
  difficulty: 'easy' | 'medium' | 'hard';
  description: string;
  starterCode: string;
  testCases: { input: any; expected: any; description: string }[];
  solution: string;
  hints: string[];
}

const EXERCISE_TEMPLATES: Record<string, (project: ProjectInfo) => Exercise[]> = {
  api_routes: (project) => [
    { id: 'create-api', title: 'APIルート作成', difficulty: 'easy',
      description: 'GET /api/healthでステータスを返すAPIを作成してください',
      starterCode: '// app/api/health/route.ts\nimport { NextResponse } from "next/server";\n\nexport async function GET() {\n  // ここにコードを書く\n}',
      testCases: [{ input: 'GET /api/health', expected: { status: 'ok' }, description: 'ステータスokを返す' }],
      solution: 'export async function GET() {\n  return NextResponse.json({ status: "ok" });\n}',
      hints: ['NextResponse.json()を使用', 'オブジェクトを渡す'] },
  ],
  prisma_queries: (project) => [
    { id: 'find-many', title: 'データ取得', difficulty: 'easy',
      description: '全てのユーザーを取得する関数を実装してください',
      starterCode: 'export async function getAllUsers() {\n  // prismaを使ってユーザーを取得\n}',
      testCases: [{ input: null, expected: 'Array', description: '配列を返す' }],
      solution: 'export async function getAllUsers() {\n  return prisma.user.findMany();\n}',
      hints: ['prisma.user.findMany()を使用'] },
  ],
};

export function generateExercises(project: ProjectInfo, topic: string): Exercise[] {
  const generator = EXERCISE_TEMPLATES[topic];
  return generator ? generator(project) : [];
}
```
TEMPLATE
    ITG2_EXERCISES_GENERATED=true
    ITG2_GENERATED_COUNT=$((ITG2_GENERATED_COUNT + 1))
    return 0
}

_itg2_track_progress() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [ITG2-PROGRESS] 進捗追跡テンプレート

```typescript
export class TutorialProgress {
  async getProgress(userId: string): Promise<UserProgress> {
    const completions = await prisma.tutorialCompletion.findMany({ where: { userId } });
    const exerciseResults = await prisma.exerciseResult.findMany({ where: { userId } });

    return {
      completedTutorials: completions.filter(c => c.completed).length,
      totalTutorials: await prisma.tutorial.count(),
      completedExercises: exerciseResults.filter(r => r.passed).length,
      totalExercises: await prisma.exercise.count(),
      streakDays: await this.calculateStreak(userId),
      skillLevel: this.calculateLevel(completions.length, exerciseResults.filter(r => r.passed).length),
    };
  }

  async markStepCompleted(userId: string, tutorialId: string, stepId: string) {
    await prisma.tutorialStepCompletion.upsert({
      where: { userId_tutorialId_stepId: { userId, tutorialId, stepId } },
      create: { userId, tutorialId, stepId, completedAt: new Date() },
      update: { completedAt: new Date() },
    });
  }

  private calculateLevel(tutorials: number, exercises: number): string {
    const total = tutorials * 2 + exercises;
    if (total >= 20) return 'expert';
    if (total >= 10) return 'intermediate';
    if (total >= 3) return 'beginner';
    return 'newcomer';
  }
}
```
TEMPLATE
    ITG2_PROGRESS_GENERATED=true
    ITG2_GENERATED_COUNT=$((ITG2_GENERATED_COUNT + 1))
    return 0
}

_itg2_generate_sandbox() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [ITG2-SANDBOX] コードサンドボックス

```tsx
'use client';
export function CodeSandbox({ initialCode, language, onRun }: Props) {
  const [code, setCode] = useState(initialCode);
  const [output, setOutput] = useState('');
  const [isRunning, setIsRunning] = useState(false);

  const handleRun = async () => {
    setIsRunning(true);
    try {
      const result = await fetch('/api/sandbox/run', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ code, language }),
      });
      const data = await result.json();
      setOutput(data.output);
      onRun?.(data);
    } catch (error) {
      setOutput(`Error: ${error}`);
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="border rounded-lg overflow-hidden">
      <div className="flex items-center justify-between bg-muted px-4 py-2">
        <span className="text-sm font-mono">{language}</span>
        <Button size="sm" onClick={handleRun} disabled={isRunning}>
          {isRunning ? '実行中...' : '実行'}
        </Button>
      </div>
      <CodeEditor value={code} onChange={setCode} language={language} className="min-h-[200px]" />
      {output && (
        <div className="border-t bg-black text-green-400 p-4 font-mono text-sm whitespace-pre-wrap max-h-[200px] overflow-y-auto">
          {output}
        </div>
      )}
    </div>
  );
}
```
TEMPLATE
    ITG2_SANDBOX_GENERATED=true
    ITG2_GENERATED_COUNT=$((ITG2_GENERATED_COUNT + 1))
    return 0
}

_itg2_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Interactive Tutorial Generator v${ITG2_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成数             : ${ITG2_GENERATED_COUNT}"
    echo -e "  チュートリアル     : ${ITG2_TUTORIAL_GENERATED}"
    echo -e "  演習問題           : ${ITG2_EXERCISES_GENERATED}"
    echo -e "  進捗追跡           : ${ITG2_PROGRESS_GENERATED}"
    echo -e "  サンドボックス     : ${ITG2_SANDBOX_GENERATED}"
}

_itg2_score() {
    local score=30
    [[ "$ITG2_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$ITG2_TUTORIAL_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITG2_EXERCISES_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITG2_PROGRESS_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$ITG2_SANDBOX_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "interactive-tutorial-generator" \
    --version "400.0" \
    --description "チュートリアル生成（ステップ学習/演習/進捗追跡/サンドボックス）" \
    --init "_itg2_init" \
    --report "_itg2_report" \
    --score "_itg2_score" \
    --enable-var "ENABLE_ITG2" \
    --cli-flags "--tutorial-gen:--no-tutorial-gen"
