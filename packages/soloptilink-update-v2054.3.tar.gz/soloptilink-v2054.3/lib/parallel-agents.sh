#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v65.0 - Parallel Agent Orchestrator
#
# 独立したタスクを複数のClaude CLIインスタンスで並列実行し、
# 生成速度を大幅に向上させる。
#
# 従来: Schema → Types → Backend → API → Frontend (直列 = 5×1分 = 5分)
# v65.0: {Schema, Config} 並列 → {Backend, Frontend} 並列 → API統合 (= 3分)
#
# DAG (Directed Acyclic Graph) ベースの依存解決:
# - 依存がないタスクは同時実行
# - 依存があるタスクは先行タスク完了後に実行
# - 最大並列数を制限（CPU/メモリ保護）
#
# バックグラウンドプロセスで複数claude実行:
#   claude -p "task1" &
#   claude -p "task2" &
#   wait
# ============================================================

[[ -n "${_PARALLEL_AGENTS_LOADED:-}" ]] && return 0
_PARALLEL_AGENTS_LOADED=1

# --- Configuration ---
PA_ENABLE="${PA_ENABLE:-true}"
PA_MAX_PARALLEL="${PA_MAX_PARALLEL:-3}"      # 最大並列数
PA_TIMEOUT="${PA_TIMEOUT:-300}"              # 各タスクのタイムアウト(秒)
PA_WORK_DIR="${PA_WORK_DIR:-.soloptilink/parallel}"

# --- State ---
PA_TOTAL_TASKS=0
PA_PARALLEL_BATCHES=0
PA_MAX_CONCURRENT_ACHIEVED=0
PA_TIME_SAVED_SEC=0
PA_TASKS_SUCCESS=0
PA_TASKS_FAIL=0

# ============================================================
# 初期化
# ============================================================
pa_init() {
    PA_TOTAL_TASKS=0
    PA_PARALLEL_BATCHES=0
    PA_MAX_CONCURRENT_ACHIEVED=0
    PA_TIME_SAVED_SEC=0
    PA_TASKS_SUCCESS=0
    PA_TASKS_FAIL=0
    mkdir -p "${PA_WORK_DIR}" 2>/dev/null || true
    return 0
}

# ============================================================
# タスクDAG定義
# 依存関係を宣言的に定義
# ============================================================
# フォーマット: "task_name:dependency1,dependency2:prompt"
# 例:
#   "schema::Create prisma schema"
#   "types:schema:Generate TypeScript types from schema"
#   "backend:types:Implement backend services"
#   "frontend:types:Implement frontend components"
#   "api:backend,frontend:Create API routes"

declare -A _PA_TASKS=()         # name → prompt
declare -A _PA_DEPS=()          # name → "dep1,dep2"
declare -A _PA_STATUS=()        # name → pending|running|done|fail
declare -A _PA_OUTPUT=()        # name → output file path
declare -a _PA_ORDER=()         # 登録順

pa_add_task() {
    local name="$1"
    local deps="$2"
    local prompt="$3"

    _PA_TASKS["$name"]="$prompt"
    _PA_DEPS["$name"]="$deps"
    _PA_STATUS["$name"]="pending"
    _PA_OUTPUT["$name"]="${PA_WORK_DIR}/${name}.output"
    _PA_ORDER+=("$name")
    PA_TOTAL_TASKS=$((PA_TOTAL_TASKS + 1))
}

pa_clear_tasks() {
    _PA_TASKS=()
    _PA_DEPS=()
    _PA_STATUS=()
    _PA_OUTPUT=()
    _PA_ORDER=()
    PA_TOTAL_TASKS=0
}

# ============================================================
# 依存解決: 実行可能なタスクを取得
# ============================================================
_pa_get_ready_tasks() {
    local -a ready=()

    for name in "${_PA_ORDER[@]}"; do
        [[ "${_PA_STATUS[$name]}" != "pending" ]] && continue

        local deps="${_PA_DEPS[$name]}"
        local all_done=true

        if [[ -n "$deps" ]]; then
            IFS=',' read -ra dep_array <<< "$deps"
            for dep in "${dep_array[@]}"; do
                if [[ "${_PA_STATUS[$dep]:-}" != "done" ]]; then
                    all_done=false
                    break
                fi
            done
        fi

        if $all_done; then
            ready+=("$name")
        fi
    done

    echo "${ready[@]}"
}

# ============================================================
# 単一タスク実行（バックグラウンド用）
# ============================================================
_pa_execute_task() {
    local name="$1"
    local prompt="${_PA_TASKS[$name]}"
    local output_file="${_PA_OUTPUT[$name]}"

    # 依存タスクの出力をコンテキストに追加
    local deps="${_PA_DEPS[$name]}"
    local context=""
    if [[ -n "$deps" ]]; then
        IFS=',' read -ra dep_array <<< "$deps"
        for dep in "${dep_array[@]}"; do
            local dep_output="${_PA_OUTPUT[$dep]}"
            if [[ -f "$dep_output" ]]; then
                context+="

## Output from ${dep} step:
$(head -200 "$dep_output" 2>/dev/null || true)
"
            fi
        done
    fi

    # プロンプト構築
    local full_prompt="${prompt}"
    if [[ -n "$context" ]]; then
        full_prompt+="

# Context from previous steps:
${context}"
    fi

    # Complexity Router連携
    local -a cmd_args=()
    if type -t cr_route &>/dev/null && [[ "${CR_ENABLE:-false}" == "true" ]]; then
        local route_result
        route_result=$(cr_route "$prompt" "implementation" 1 2>/dev/null || true)
        if [[ -n "$route_result" ]]; then
            local model fallback budget
            model=$(echo "$route_result" | grep -o 'model=[^ ]*' | cut -d= -f2)
            fallback=$(echo "$route_result" | grep -o 'fallback=[^ ]*' | cut -d= -f2)
            budget=$(echo "$route_result" | grep -o 'budget=[^ ]*' | cut -d= -f2)
            cmd_args+=("claude" "-p" "--dangerously-skip-permissions")
            cmd_args+=("--model" "$model")
            cmd_args+=("--fallback-model" "$fallback")
            cmd_args+=("--max-budget-usd" "$budget")
            cmd_args+=("--output-format" "text")
            cmd_args+=("$full_prompt")
        fi
    fi

    if [[ ${#cmd_args[@]} -eq 0 ]]; then
        cmd_args+=("claude" "-p" "--dangerously-skip-permissions")
        cmd_args+=("--fallback-model" "claude-sonnet-4-20250514")
        cmd_args+=("--max-budget-usd" "2.00")
        cmd_args+=("--output-format" "text")
        cmd_args+=("$full_prompt")
    fi

    # 実行
    timeout "$PA_TIMEOUT" "${cmd_args[@]}" > "$output_file" 2>/dev/null
    return $?
}

# ============================================================
# DAG実行エンジン
# 依存関係を尊重しながら最大並列で実行
# ============================================================
pa_execute_dag() {
    local start_time
    start_time=$(date +%s)

    echo -e "${BOLD:-}[Parallel Agents] DAGベース並列実行開始 (${PA_TOTAL_TASKS}タスク, 最大並列${PA_MAX_PARALLEL})${NC:-}" >&2

    local completed=0
    local batch_num=0

    while [[ $completed -lt $PA_TOTAL_TASKS ]]; do
        # 実行可能タスク取得
        local ready_str
        ready_str=$(_pa_get_ready_tasks)

        if [[ -z "$ready_str" ]]; then
            # デッドロック検出
            local any_running=false
            for name in "${_PA_ORDER[@]}"; do
                [[ "${_PA_STATUS[$name]}" == "running" ]] && any_running=true
            done
            if ! $any_running; then
                echo -e "  ${RED:-}⚠️ デッドロック検出: 実行可能タスクなし${NC:-}" >&2
                break
            fi
            sleep 1
            continue
        fi

        read -ra ready_tasks <<< "$ready_str"

        # 並列数制限
        local batch_size=${#ready_tasks[@]}
        if [[ $batch_size -gt $PA_MAX_PARALLEL ]]; then
            batch_size=$PA_MAX_PARALLEL
        fi

        batch_num=$((batch_num + 1))
        PA_PARALLEL_BATCHES=$((PA_PARALLEL_BATCHES + 1))

        if [[ $batch_size -gt $PA_MAX_CONCURRENT_ACHIEVED ]]; then
            PA_MAX_CONCURRENT_ACHIEVED=$batch_size
        fi

        echo -e "  ${CYAN:-}📦 Batch ${batch_num}: ${batch_size}タスク並列実行${NC:-}" >&2

        # バックグラウンド実行
        local -a pids=()
        local -a batch_names=()
        local i=0

        while [[ $i -lt $batch_size ]]; do
            local task_name="${ready_tasks[$i]}"
            _PA_STATUS["$task_name"]="running"
            batch_names+=("$task_name")

            _pa_execute_task "$task_name" &
            pids+=($!)

            echo -e "    🚀 ${task_name} (PID ${pids[-1]})" >&2
            i=$((i + 1))
        done

        # 完了待ち
        local j=0
        for pid in "${pids[@]}"; do
            local task_name="${batch_names[$j]}"
            if wait "$pid"; then
                _PA_STATUS["$task_name"]="done"
                PA_TASKS_SUCCESS=$((PA_TASKS_SUCCESS + 1))
                echo -e "    ${GREEN:-}✅ ${task_name} 完了${NC:-}" >&2
            else
                _PA_STATUS["$task_name"]="fail"
                PA_TASKS_FAIL=$((PA_TASKS_FAIL + 1))
                echo -e "    ${RED:-}❌ ${task_name} 失敗${NC:-}" >&2
            fi
            completed=$((completed + 1))
            j=$((j + 1))
        done
    done

    local end_time
    end_time=$(date +%s)
    local elapsed=$((end_time - start_time))

    # 直列実行時間推定（各タスク60秒と仮定）
    local serial_est=$((PA_TOTAL_TASKS * 60))
    PA_TIME_SAVED_SEC=$((serial_est - elapsed))
    [[ $PA_TIME_SAVED_SEC -lt 0 ]] && PA_TIME_SAVED_SEC=0

    echo -e "${GREEN:-}[Parallel Agents] 完了: ${PA_TASKS_SUCCESS}成功, ${PA_TASKS_FAIL}失敗, ${elapsed}秒 (推定節約${PA_TIME_SAVED_SEC}秒)${NC:-}" >&2
    return 0
}

# ============================================================
# プロジェクト種別からDAGを自動構築
# ============================================================
pa_build_project_dag() {
    local task_desc="$1"
    local project_type="${2:-fullstack}"
    local project_dir="${3:-.}"

    pa_clear_tasks

    case "$project_type" in
        fullstack|nextjs)
            pa_add_task "schema" "" \
                "Create Prisma schema for: ${task_desc}. Output prisma/schema.prisma content."
            pa_add_task "config" "" \
                "Create project config files for: ${task_desc}. Output package.json, tsconfig.json, next.config.js."
            pa_add_task "types" "schema" \
                "Generate TypeScript types and Zod schemas based on the Prisma schema. Output src/types/ files."
            pa_add_task "backend" "types" \
                "Implement backend services and database access layer. Use Prisma client with proper transactions."
            pa_add_task "frontend" "types" \
                "Implement React frontend components with proper typing. Use the generated types."
            pa_add_task "api" "backend" \
                "Create Next.js API routes connecting frontend to backend services."
            pa_add_task "integration" "api,frontend" \
                "Wire frontend components to API routes. Add error handling and loading states."
            ;;
        api|backend)
            pa_add_task "schema" "" \
                "Create database schema for: ${task_desc}."
            pa_add_task "types" "schema" \
                "Generate types and validation schemas."
            pa_add_task "services" "types" \
                "Implement business logic services."
            pa_add_task "routes" "services" \
                "Create API routes with input validation."
            pa_add_task "middleware" "" \
                "Implement authentication and rate limiting middleware."
            pa_add_task "integration" "routes,middleware" \
                "Wire middleware to routes and add error handling."
            ;;
        ios|swift)
            pa_add_task "models" "" \
                "Create Swift data models for: ${task_desc}."
            pa_add_task "views" "models" \
                "Create SwiftUI views using the data models."
            pa_add_task "viewmodels" "models" \
                "Create view models with business logic."
            pa_add_task "navigation" "views" \
                "Implement navigation flow."
            pa_add_task "networking" "models" \
                "Implement API client networking layer."
            ;;
    esac
}

# ============================================================
# レポート / スコア
# ============================================================
pa_report() {
    echo -e "\n  ${BOLD:-}═══ Parallel Agents v65.0 レポート ═══${NC:-}"
    echo -e "  総タスク数         : ${PA_TOTAL_TASKS}"
    echo -e "  並列バッチ数       : ${PA_PARALLEL_BATCHES}"
    echo -e "  最大同時実行数     : ${PA_MAX_CONCURRENT_ACHIEVED}"
    echo -e "  成功/失敗          : ${PA_TASKS_SUCCESS}/${PA_TASKS_FAIL}"
    echo -e "  推定節約時間       : ${PA_TIME_SAVED_SEC}秒"
}

pa_score() {
    if [[ $PA_TOTAL_TASKS -eq 0 ]]; then
        echo "50"
    elif [[ $PA_TASKS_FAIL -eq 0 && $PA_MAX_CONCURRENT_ACHIEVED -gt 1 ]]; then
        echo "95"
    elif [[ $PA_TASKS_FAIL -eq 0 ]]; then
        echo "85"
    else
        local success_rate=$((PA_TASKS_SUCCESS * 100 / PA_TOTAL_TASKS))
        echo "$success_rate"
    fi
}

# ============================================================
# v59.0: Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "parallel-agents" \
        --version "65.0" \
        --description "DAGベース複数Claude並列実行×依存解決×時間短縮" \
        --init "pa_init" \
        --report "pa_report" \
        --score "pa_score" \
        --enable-var "ENABLE_PARALLEL_AGENTS" \
        --cli-flags "--parallel-agents:--no-parallel-agents"
fi

# v2003.1: source時のexit codeを確実に0にする
true
