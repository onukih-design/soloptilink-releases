#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v314.0 - Reporting Engine Generator
# =============================================================================
# レポートエンジン自動生成: レポートビルダー/チャート/フィルター/エクスポート
#
# 全globals: REG_ prefix
# =============================================================================

[[ -n "${_REPORTING_ENGINE_GENERATOR_LOADED:-}" ]] && return 0
_REPORTING_ENGINE_GENERATOR_LOADED=1

declare -g REG_VERSION="314.0"
declare -g REG_INITIALIZED=false
declare -g REG_GENERATED_COUNT=0
declare -g ENABLE_REPORTING_ENGINE_GENERATOR="${ENABLE_REPORTING_ENGINE_GENERATOR:-true}"

readonly REG_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly REG_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly REG_BOLD="${CLR_BOLD:-\033[1m}"
readonly REG_NC="${CLR_NC:-\033[0m}"

_reg_log() { echo -e "  ${REG_CYAN}[REG]${REG_NC} $*" >&2; }
_reg_ok()  { echo -e "  ${REG_GREEN}[REG] OK${REG_NC} $*" >&2; }

reg_init() { REG_INITIALIZED=true; REG_GENERATED_COUNT=0; return 0; }
reg_report() { [[ "$REG_INITIALIZED" != "true" ]] && return 0; echo -e "\n  ${REG_BOLD}--- Reporting Engine Generator v${REG_VERSION} ---${REG_NC}" >&2; echo -e "  生成数: ${REG_GENERATED_COUNT}" >&2; }
reg_score() { [[ "$REG_INITIALIZED" != "true" ]] && { echo "0"; return; }; local s=50; [[ $REG_GENERATED_COUNT -ge 3 ]] && s=85; echo "$s"; }
reg_init_message() { echo -e "  ${REG_GREEN}v${REG_VERSION} reporting-engine-generator: レポートエンジン自動生成${REG_NC}" >&2; }

_reg_generate_report_builder() {
    local project_dir="${1:-.}"
    _reg_log "レポートビルダーUI生成"
    local comp_dir="${project_dir}/src/components/reports"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/ReportBuilder.tsx" <<'EOF'
'use client';
import { useState } from 'react';
import { BarChart3, LineChart, PieChart, Table, Download, Filter, Play } from 'lucide-react';

interface ReportConfig { title: string; dataSource: string; chartType: 'bar' | 'line' | 'pie' | 'table'; filters: { field: string; operator: string; value: string }[]; groupBy?: string; dateRange?: { from: string; to: string }; }

export function ReportBuilder({ dataSources = ['users', 'orders', 'products', 'revenue'] }: { dataSources?: string[] }) {
  const [config, setConfig] = useState<ReportConfig>({ title: '', dataSource: dataSources[0] || '', chartType: 'bar', filters: [] });
  const [result, setResult] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const addFilter = () => setConfig({ ...config, filters: [...config.filters, { field: '', operator: 'eq', value: '' }] });
  const removeFilter = (i: number) => setConfig({ ...config, filters: config.filters.filter((_, idx) => idx !== i) });

  const runReport = async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/reports/run', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(config) });
      const data = await res.json();
      setResult(data);
    } catch { alert('レポート生成に失敗'); } finally { setLoading(false); }
  };

  const chartIcons = { bar: <BarChart3 size={18} />, line: <LineChart size={18} />, pie: <PieChart size={18} />, table: <Table size={18} /> };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-lg shadow p-6 space-y-4">
        <h2 className="text-lg font-bold">レポートビルダー</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div><label className="block text-sm font-medium mb-1">タイトル</label>
            <input value={config.title} onChange={e => setConfig({ ...config, title: e.target.value })} className="w-full border rounded-lg px-3 py-2 text-sm" placeholder="レポートタイトル" /></div>
          <div><label className="block text-sm font-medium mb-1">データソース</label>
            <select value={config.dataSource} onChange={e => setConfig({ ...config, dataSource: e.target.value })} className="w-full border rounded-lg px-3 py-2 text-sm">
              {dataSources.map(ds => <option key={ds} value={ds}>{ds}</option>)}
            </select></div>
        </div>
        <div><label className="block text-sm font-medium mb-2">表示形式</label>
          <div className="flex gap-2">
            {(Object.entries(chartIcons) as [keyof typeof chartIcons, React.ReactNode][]).map(([type, icon]) => (
              <button key={type} onClick={() => setConfig({ ...config, chartType: type })}
                className={`flex items-center gap-2 px-4 py-2 rounded-lg border text-sm ${config.chartType === type ? 'bg-blue-50 border-blue-300 text-blue-700' : 'hover:bg-gray-50'}`}>
                {icon} {type}
              </button>
            ))}
          </div>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div><label className="block text-sm font-medium mb-1">開始日</label>
            <input type="date" onChange={e => setConfig({ ...config, dateRange: { ...config.dateRange!, from: e.target.value, to: config.dateRange?.to || '' } })} className="w-full border rounded-lg px-3 py-2 text-sm" /></div>
          <div><label className="block text-sm font-medium mb-1">終了日</label>
            <input type="date" onChange={e => setConfig({ ...config, dateRange: { ...config.dateRange!, to: e.target.value, from: config.dateRange?.from || '' } })} className="w-full border rounded-lg px-3 py-2 text-sm" /></div>
        </div>
        <div>
          <div className="flex items-center justify-between mb-2"><label className="text-sm font-medium">フィルター</label>
            <button onClick={addFilter} className="text-blue-600 text-sm flex items-center gap-1"><Filter size={14} /> 追加</button>
          </div>
          {config.filters.map((f, i) => (
            <div key={i} className="flex gap-2 mb-2">
              <input value={f.field} onChange={e => { const nf = [...config.filters]; nf[i].field = e.target.value; setConfig({ ...config, filters: nf }); }} placeholder="フィールド" className="border rounded px-2 py-1 text-sm flex-1" />
              <select value={f.operator} onChange={e => { const nf = [...config.filters]; nf[i].operator = e.target.value; setConfig({ ...config, filters: nf }); }} className="border rounded px-2 py-1 text-sm">
                <option value="eq">=</option><option value="neq">!=</option><option value="gt">&gt;</option><option value="lt">&lt;</option><option value="contains">含む</option>
              </select>
              <input value={f.value} onChange={e => { const nf = [...config.filters]; nf[i].value = e.target.value; setConfig({ ...config, filters: nf }); }} placeholder="値" className="border rounded px-2 py-1 text-sm flex-1" />
              <button onClick={() => removeFilter(i)} className="text-red-500 text-sm px-2">X</button>
            </div>
          ))}
        </div>
        <button onClick={runReport} disabled={loading} className="bg-blue-600 text-white px-6 py-2 rounded-lg flex items-center gap-2 hover:bg-blue-700 disabled:opacity-50">
          <Play size={16} /> {loading ? '生成中...' : 'レポート生成'}
        </button>
      </div>
      {result && <div className="bg-white rounded-lg shadow p-6"><pre className="text-sm overflow-auto">{JSON.stringify(result, null, 2)}</pre></div>}
    </div>
  );
}
EOF

    REG_GENERATED_COUNT=$((REG_GENERATED_COUNT + 1))
    _reg_ok "レポートビルダー生成完了"
    return 0
}

_reg_generate_charts() {
    local project_dir="${1:-.}"
    _reg_log "チャートコンポーネント生成"
    local comp_dir="${project_dir}/src/components/reports"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/Charts.tsx" <<'EOF'
'use client';

interface DataPoint { label: string; value: number; color?: string; }
interface ChartProps { data: DataPoint[]; title?: string; height?: number; }

const COLORS = ['#3B82F6', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899', '#06B6D4', '#84CC16'];

export function BarChart({ data, title, height = 300 }: ChartProps) {
  const maxVal = Math.max(...data.map(d => d.value), 1);
  return (
    <div>
      {title && <h3 className="font-semibold mb-4">{title}</h3>}
      <div className="flex items-end gap-2" style={{ height }}>
        {data.map((d, i) => (
          <div key={i} className="flex-1 flex flex-col items-center gap-1">
            <span className="text-xs font-medium">{d.value.toLocaleString()}</span>
            <div className="w-full rounded-t transition-all duration-500"
              style={{ height: `${(d.value / maxVal) * 100}%`, backgroundColor: d.color || COLORS[i % COLORS.length], minHeight: 4 }} />
            <span className="text-xs text-gray-500 truncate w-full text-center">{d.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function PieChart({ data, title }: ChartProps) {
  const total = data.reduce((s, d) => s + d.value, 0);
  let cumAngle = 0;

  return (
    <div>
      {title && <h3 className="font-semibold mb-4">{title}</h3>}
      <div className="flex items-center gap-8">
        <svg viewBox="-1 -1 2 2" className="w-48 h-48" style={{ transform: 'rotate(-90deg)' }}>
          {data.map((d, i) => {
            const angle = (d.value / total) * 2 * Math.PI;
            const x1 = Math.cos(cumAngle); const y1 = Math.sin(cumAngle);
            cumAngle += angle;
            const x2 = Math.cos(cumAngle); const y2 = Math.sin(cumAngle);
            const largeArc = angle > Math.PI ? 1 : 0;
            return <path key={i} d={`M 0 0 L ${x1} ${y1} A 1 1 0 ${largeArc} 1 ${x2} ${y2} Z`} fill={d.color || COLORS[i % COLORS.length]} />;
          })}
        </svg>
        <div className="space-y-2">
          {data.map((d, i) => (
            <div key={i} className="flex items-center gap-2 text-sm">
              <div className="w-3 h-3 rounded-full" style={{ backgroundColor: d.color || COLORS[i % COLORS.length] }} />
              <span>{d.label}</span>
              <span className="text-gray-500">({Math.round((d.value / total) * 100)}%)</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export function LineChart({ data, title, height = 200 }: ChartProps) {
  const maxVal = Math.max(...data.map(d => d.value), 1);
  const points = data.map((d, i) => ({ x: (i / (data.length - 1)) * 100, y: 100 - (d.value / maxVal) * 100 }));
  const pathD = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ');

  return (
    <div>
      {title && <h3 className="font-semibold mb-4">{title}</h3>}
      <svg viewBox="0 0 100 100" className="w-full" style={{ height }} preserveAspectRatio="none">
        <path d={pathD} fill="none" stroke="#3B82F6" strokeWidth="2" vectorEffect="non-scaling-stroke" />
        {points.map((p, i) => <circle key={i} cx={p.x} cy={p.y} r="1.5" fill="#3B82F6" />)}
      </svg>
      <div className="flex justify-between text-xs text-gray-500 mt-1">
        {data.filter((_, i) => i % Math.ceil(data.length / 6) === 0 || i === data.length - 1).map((d, i) => (
          <span key={i}>{d.label}</span>
        ))}
      </div>
    </div>
  );
}
EOF

    REG_GENERATED_COUNT=$((REG_GENERATED_COUNT + 1))
    _reg_ok "チャートコンポーネント生成完了"
    return 0
}

_reg_generate_filters() {
    local project_dir="${1:-.}"
    _reg_log "レポートフィルター生成"
    local comp_dir="${project_dir}/src/components/reports"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/ReportFilters.tsx" <<'EOF'
'use client';
import { useState } from 'react';
import { Filter, X, Calendar } from 'lucide-react';

interface FilterConfig { dateRange: { from: string; to: string }; category: string; userId: string; status: string; }

interface ReportFiltersProps { categories?: string[]; statuses?: string[]; onChange: (filters: Partial<FilterConfig>) => void; }

export function ReportFilters({ categories = [], statuses = [], onChange }: ReportFiltersProps) {
  const [filters, setFilters] = useState<Partial<FilterConfig>>({});
  const [expanded, setExpanded] = useState(false);

  const update = (partial: Partial<FilterConfig>) => { const next = { ...filters, ...partial }; setFilters(next); onChange(next); };
  const clear = () => { setFilters({}); onChange({}); };
  const activeCount = Object.values(filters).filter(v => v && (typeof v === 'string' ? v : v.from || v.to)).length;

  return (
    <div className="bg-white rounded-lg border p-4">
      <div className="flex items-center justify-between">
        <button onClick={() => setExpanded(!expanded)} className="flex items-center gap-2 text-sm font-medium">
          <Filter size={16} /> フィルター {activeCount > 0 && <span className="bg-blue-100 text-blue-700 text-xs px-2 py-0.5 rounded-full">{activeCount}</span>}
        </button>
        {activeCount > 0 && <button onClick={clear} className="text-xs text-gray-500 hover:text-red-500 flex items-center gap-1"><X size={12} /> クリア</button>}
      </div>
      {expanded && (
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mt-4">
          <div><label className="block text-xs font-medium mb-1">開始日</label>
            <input type="date" value={filters.dateRange?.from || ''} onChange={e => update({ dateRange: { from: e.target.value, to: filters.dateRange?.to || '' } })} className="w-full border rounded px-2 py-1.5 text-sm" /></div>
          <div><label className="block text-xs font-medium mb-1">終了日</label>
            <input type="date" value={filters.dateRange?.to || ''} onChange={e => update({ dateRange: { from: filters.dateRange?.from || '', to: e.target.value } })} className="w-full border rounded px-2 py-1.5 text-sm" /></div>
          {categories.length > 0 && <div><label className="block text-xs font-medium mb-1">カテゴリ</label>
            <select value={filters.category || ''} onChange={e => update({ category: e.target.value })} className="w-full border rounded px-2 py-1.5 text-sm">
              <option value="">すべて</option>{categories.map(c => <option key={c} value={c}>{c}</option>)}
            </select></div>}
          {statuses.length > 0 && <div><label className="block text-xs font-medium mb-1">ステータス</label>
            <select value={filters.status || ''} onChange={e => update({ status: e.target.value })} className="w-full border rounded px-2 py-1.5 text-sm">
              <option value="">すべて</option>{statuses.map(s => <option key={s} value={s}>{s}</option>)}
            </select></div>}
        </div>
      )}
    </div>
  );
}
EOF

    REG_GENERATED_COUNT=$((REG_GENERATED_COUNT + 1))
    _reg_ok "フィルター生成完了"
    return 0
}

_reg_generate_export() {
    local project_dir="${1:-.}"
    _reg_log "エクスポートAPI生成"
    local api_dir="${project_dir}/src/app/api/reports/export"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    const { data, format, title } = await req.json();
    if (!data || !format) return NextResponse.json({ error: 'data and format required' }, { status: 400 });

    if (format === 'csv') {
      const rows = data as Record<string, any>[];
      if (rows.length === 0) return NextResponse.json({ error: 'No data' }, { status: 400 });
      const headers = Object.keys(rows[0]);
      const csv = [headers.join(','), ...rows.map(r => headers.map(h => `"${String(r[h] ?? '').replace(/"/g, '""')}"`).join(','))].join('\n');
      return new NextResponse(csv, { headers: { 'Content-Type': 'text/csv; charset=utf-8', 'Content-Disposition': `attachment; filename="${title || 'report'}.csv"` } });
    }

    if (format === 'json') {
      const json = JSON.stringify(data, null, 2);
      return new NextResponse(json, { headers: { 'Content-Type': 'application/json', 'Content-Disposition': `attachment; filename="${title || 'report'}.json"` } });
    }

    // For PDF/Excel, return instruction for client-side generation
    return NextResponse.json({
      instruction: 'Use client-side libraries (jsPDF for PDF, xlsx for Excel) for rich formatting',
      data, format,
    });
  } catch (error) {
    return NextResponse.json({ error: 'Export failed' }, { status: 500 });
  }
}
EOF

    REG_GENERATED_COUNT=$((REG_GENERATED_COUNT + 1))
    _reg_ok "エクスポートAPI生成完了"
    return 0
}

_mr_register \
    --name "reporting-engine-generator" \
    --version "314.0" \
    --description "レポートエンジン自動生成（ビルダー/チャート/フィルター/エクスポート）" \
    --init "reg_init" \
    --report "reg_report" \
    --score "reg_score" \
    --enable-var "ENABLE_REPORTING_ENGINE_GENERATOR" \
    --cli-flags "--reporting:--no-reporting" \
    --init-msg "reg_init_message"
