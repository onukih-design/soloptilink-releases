#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v18.0 - Multi-Tenant SaaS Builder
# =============================================================================
# マルチテナントSaaSアプリケーションの基盤を自動構築。テナント分離戦略の
# 自動検出、RBAC権限管理、認証/認可スキャフォールド、課金/サブスクリプション
# 統合を一括生成する。
#
# 機能:
#   1.  sb_init()                        - 初期化（テナント戦略指定）
#   2.  sb_detect_tenant_strategy()      - 要件からテナント戦略を自動判定
#   3.  sb_generate_tenant_schema()      - テナントテーブル/スキーマ生成
#   4.  sb_generate_tenant_middleware()   - テナントコンテキスト抽出ミドルウェア
#   5.  sb_generate_rbac_schema()        - RBAC権限テーブル生成
#   6.  sb_generate_rbac_middleware()     - 権限チェックミドルウェア生成
#   7.  sb_suggest_roles()               - 要件からロール提案
#   8.  sb_generate_jwt_auth()           - JWT認証コード生成
#   9.  sb_generate_session_auth()       - セッション認証コード生成
#   10. sb_generate_oauth2_scaffold()    - OAuth2スキャフォールド生成
#   11. sb_generate_saml_scaffold()      - SAML SSOスキャフォールド生成
#   12. sb_generate_billing_schema()     - 課金/サブスクリプションスキーマ生成
#   13. sb_generate_stripe_scaffold()    - Stripe統合コード生成
#   14. sb_generate_tenant_migration()   - テナント戦略間マイグレーション
#   15. sb_generate_saas_prompt()        - Claude CLI用SaaS要件プロンプト生成
#   16. sb_report()                      - カラーレポート出力
#   17. sb_export_json()                 - JSONエクスポート
#
# Usage: source lib/saas-builder.sh
# =============================================================================

[[ -n "${_SAAS_BUILDER_LOADED:-}" ]] && return 0
_SAAS_BUILDER_LOADED=1

# --- カラー定義 (SB_ prefix) -------------------------------------------------
SB_GREEN='\033[0;32m'   SB_YELLOW='\033[0;33m'  SB_RED='\033[0;31m'
SB_CYAN='\033[0;36m'    SB_PURPLE='\033[0;35m'  SB_BOLD='\033[1m'
SB_DIM='\033[2m'        SB_NC='\033[0m'

# --- グローバル状態 (SB_ prefix) ----------------------------------------------
SB_VERSION="18.0"
SB_ENABLED="false"
SB_SESSION_ID=""
SB_PROJECT_DIR=""
SB_TENANT_STRATEGY="row-level"
SB_AUTH_METHODS="jwt"
SB_BILLING_ENABLED="false"
SB_RBAC_ENABLED="true"
SB_DETECTED_FRAMEWORK=""
SB_DETECTED_ORM=""
SB_ROLES_COUNT=0
SB_PERMISSIONS_COUNT=0
SB_RESULTS=""

# =============================================================================
# 内部ヘルパー関数
# =============================================================================

# --- _sb_log: 構造化ログ出力 ------------------------------------------------
_sb_log() {
    local level="$1"; shift
    local color="${SB_NC}"
    case "$level" in
        INFO)    color="${SB_CYAN}" ;;
        PASS)    color="${SB_GREEN}" ;;
        WARN)    color="${SB_YELLOW}" ;;
        ERROR)   color="${SB_RED}" ;;
        SECTION) color="${SB_PURPLE}" ;;
    esac
    echo -e "  ${color}[SB:${level}]${SB_NC} $*" >&2
    SB_RESULTS+="${level}|$*\n"
}

# --- _sb_record: Observatory イベント記録 ------------------------------------
_sb_record() {
    local event_type="$1" data_json="$2"
    local ts events_file
    ts=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    events_file="${SESSION_LOG_DIR:-/tmp}/observatory/events.jsonl"
    [[ -d "$(dirname "$events_file")" ]] || mkdir -p "$(dirname "$events_file")"
    printf '{"type":"SAAS_BUILDER","subtype":"%s","data":%s,"timestamp":"%s","module":"saas-builder","version":"%s"}\n' \
        "$event_type" "$data_json" "$ts" "$SB_VERSION" >> "$events_file" 2>/dev/null || true
}

# --- _sb_detect_framework: フレームワーク自動検出 ----------------------------
_sb_detect_framework() {
    local pd="${1:-$SB_PROJECT_DIR}"
    [[ -z "$pd" || ! -d "$pd" ]] && { echo "unknown"; return; }
    if [[ -f "${pd}/package.json" ]]; then
        local pkg; pkg="$(cat "${pd}/package.json" 2>/dev/null)"
        echo "$pkg" | grep -q '"hono"' && { echo "hono"; return; }
        echo "$pkg" | grep -q '"fastify"' && { echo "fastify"; return; }
        echo "$pkg" | grep -q '"express"' && { echo "express"; return; }
        echo "$pkg" | grep -q '"next"' && { echo "nextjs"; return; }
        echo "node"; return
    fi
    if [[ -f "${pd}/requirements.txt" ]] || [[ -f "${pd}/pyproject.toml" ]]; then
        grep -q 'fastapi\|FastAPI' "${pd}/requirements.txt" "${pd}/pyproject.toml" 2>/dev/null && { echo "fastapi"; return; }
        grep -q 'django\|Django' "${pd}/requirements.txt" "${pd}/pyproject.toml" 2>/dev/null && { echo "django"; return; }
        grep -q 'flask\|Flask' "${pd}/requirements.txt" "${pd}/pyproject.toml" 2>/dev/null && { echo "flask"; return; }
        echo "python"; return
    fi
    [[ -f "${pd}/go.mod" ]] && { echo "go"; return; }
    echo "unknown"
}

# --- _sb_detect_db_orm: ORM自動検出 -----------------------------------------
_sb_detect_db_orm() {
    local pd="${1:-$SB_PROJECT_DIR}"
    [[ -z "$pd" || ! -d "$pd" ]] && { echo "unknown"; return; }
    if [[ -f "${pd}/package.json" ]]; then
        local pkg; pkg="$(cat "${pd}/package.json" 2>/dev/null)"
        echo "$pkg" | grep -q '"prisma"\|"@prisma/client"' && { echo "prisma"; return; }
        echo "$pkg" | grep -q '"typeorm"' && { echo "typeorm"; return; }
        echo "$pkg" | grep -q '"sequelize"' && { echo "sequelize"; return; }
        echo "$pkg" | grep -q '"drizzle-orm"' && { echo "drizzle"; return; }
        echo "$pkg" | grep -q '"mongoose"' && { echo "mongoose"; return; }
    fi
    if [[ -f "${pd}/requirements.txt" ]] || [[ -f "${pd}/pyproject.toml" ]]; then
        grep -q 'django' "${pd}/requirements.txt" "${pd}/pyproject.toml" 2>/dev/null && { echo "django-orm"; return; }
        grep -q 'sqlalchemy\|SQLAlchemy' "${pd}/requirements.txt" "${pd}/pyproject.toml" 2>/dev/null && { echo "sqlalchemy"; return; }
    fi
    echo "unknown"
}

# --- _sb_validate_strategy: テナント戦略バリデーション -----------------------
_sb_validate_strategy() {
    local strategy="$1"
    case "$strategy" in
        row-level|db-level|schema-level) return 0 ;;
        *) _sb_log ERROR "Invalid tenant strategy: ${strategy} (valid: row-level, db-level, schema-level)"; return 1 ;;
    esac
}

# --- _sb_generate_tenant_context: テナントコンテキスト伝播コード -------------
_sb_generate_tenant_context() {
    cat <<'TENANT_CTX'
// SoloptiLink v18.0 - Tenant Context Propagation
// AsyncLocalStorage-based tenant context for request-scoped isolation

import { AsyncLocalStorage } from 'node:async_hooks';

interface TenantContext {
  tenantId: string;
  tenantSlug?: string;
  tenantPlan?: string;
  userId?: string;
}

const tenantStorage = new AsyncLocalStorage<TenantContext>();

export function runWithTenant<T>(ctx: TenantContext, fn: () => T): T {
  return tenantStorage.run(ctx, fn);
}

export function getCurrentTenant(): TenantContext | undefined {
  return tenantStorage.getStore();
}

export function requireTenant(): TenantContext {
  const ctx = tenantStorage.getStore();
  if (!ctx) throw new Error('No tenant context available');
  return ctx;
}

// Prisma middleware: auto-inject tenant_id on all queries
export function prismaMultiTenantMiddleware() {
  return async (params: any, next: any) => {
    const tenant = getCurrentTenant();
    if (!tenant) return next(params);

    // Auto-filter reads by tenant_id
    if (['findMany', 'findFirst', 'findUnique', 'count', 'aggregate'].includes(params.action)) {
      if (params.args?.where) {
        params.args.where.tenantId = tenant.tenantId;
      } else {
        params.args = { ...params.args, where: { tenantId: tenant.tenantId } };
      }
    }

    // Auto-inject tenant_id on creates
    if (['create', 'createMany'].includes(params.action)) {
      if (params.args?.data) {
        if (Array.isArray(params.args.data)) {
          params.args.data = params.args.data.map((d: any) => ({ ...d, tenantId: tenant.tenantId }));
        } else {
          params.args.data.tenantId = tenant.tenantId;
        }
      }
    }

    // Auto-scope updates/deletes by tenant_id
    if (['update', 'updateMany', 'delete', 'deleteMany'].includes(params.action)) {
      if (params.args?.where) {
        params.args.where.tenantId = tenant.tenantId;
      }
    }

    return next(params);
  };
}
TENANT_CTX
}

# --- _sb_generate_permission_check: 権限チェックヘルパー --------------------
_sb_generate_permission_check() {
    cat <<'PERM_CHECK'
// SoloptiLink v18.0 - Permission Check Helper
// Usage: await checkPermission(userId, tenantId, 'posts', 'write');

interface PermissionCheckResult {
  allowed: boolean;
  roles: string[];
  missingPermission?: string;
}

async function checkPermission(
  userId: string,
  tenantId: string,
  resource: string,
  action: string
): Promise<boolean> {
  // Query user_roles -> role_permissions -> permissions
  const userRoles = await db.userRole.findMany({
    where: { userId, tenantId },
    include: {
      role: {
        include: {
          rolePermissions: {
            include: { permission: true }
          }
        }
      }
    }
  });

  for (const ur of userRoles) {
    for (const rp of ur.role.rolePermissions) {
      const p = rp.permission;
      if (p.resource === resource && p.action === action) return true;
      if (p.resource === '*' && p.action === '*') return true;        // superadmin
      if (p.resource === resource && p.action === '*') return true;   // resource admin
    }
  }
  return false;
}

async function getUserPermissions(
  userId: string,
  tenantId: string
): Promise<{ resource: string; action: string }[]> {
  const userRoles = await db.userRole.findMany({
    where: { userId, tenantId },
    include: {
      role: {
        include: {
          rolePermissions: {
            include: { permission: true }
          }
        }
      }
    }
  });

  const permissions: { resource: string; action: string }[] = [];
  for (const ur of userRoles) {
    for (const rp of ur.role.rolePermissions) {
      permissions.push({ resource: rp.permission.resource, action: rp.permission.action });
    }
  }
  return [...new Map(permissions.map(p => [`${p.resource}.${p.action}`, p])).values()];
}

module.exports = { checkPermission, getUserPermissions };
PERM_CHECK
}

# =============================================================================
# 1. sb_init - 初期化
# =============================================================================
sb_init() {
    local session_id="${1:-}" tenant_strategy="${2:-row-level}"

    [[ -z "$session_id" ]] && { _sb_log ERROR "session_id is required"; return 1; }
    _sb_validate_strategy "$tenant_strategy" || return 1

    SB_ENABLED="true"
    SB_SESSION_ID="$session_id"
    SB_TENANT_STRATEGY="$tenant_strategy"
    SB_ROLES_COUNT=0
    SB_PERMISSIONS_COUNT=0
    SB_RESULTS=""

    # プロジェクトディレクトリの検出
    SB_PROJECT_DIR="${SB_PROJECT_DIR:-.}"
    SB_DETECTED_FRAMEWORK="$(_sb_detect_framework)"
    SB_DETECTED_ORM="$(_sb_detect_db_orm)"

    _sb_log INFO "SaaS Builder v${SB_VERSION} initialized"
    _sb_log INFO "  Session: ${SB_SESSION_ID}"
    _sb_log INFO "  Tenant Strategy: ${SB_TENANT_STRATEGY}"
    _sb_log INFO "  Framework: ${SB_DETECTED_FRAMEWORK} | ORM: ${SB_DETECTED_ORM}"

    _sb_record "INIT" "{\"session_id\":\"${SB_SESSION_ID}\",\"strategy\":\"${SB_TENANT_STRATEGY}\",\"framework\":\"${SB_DETECTED_FRAMEWORK}\",\"orm\":\"${SB_DETECTED_ORM}\"}"

    return 0
}

# =============================================================================
# 2. sb_detect_tenant_strategy - 要件からテナント戦略を自動判定
# =============================================================================
sb_detect_tenant_strategy() {
    local requirements_text="$1"
    [[ -z "$requirements_text" ]] && { echo "row-level"; return; }

    # enterprise / 大規模 / 高セキュリティ → db-level
    if echo "$requirements_text" | grep -qiE '(enterprise|大規模|高セキュリティ|high.?security|data.?isolation|規制|compliance|HIPAA|SOC2|dedicated.?database)'; then
        _sb_log INFO "Detected tenant strategy: db-level (enterprise/high-security requirements)"
        echo "db-level"
        return
    fi

    # schema / スキーマ → schema-level
    if echo "$requirements_text" | grep -qiE '(schema.?level|スキーマ|schema.?isolation|per.?schema|namespace)'; then
        _sb_log INFO "Detected tenant strategy: schema-level (schema isolation requested)"
        echo "schema-level"
        return
    fi

    # Default → row-level (most common, cost-effective)
    _sb_log INFO "Detected tenant strategy: row-level (default, most cost-effective)"
    echo "row-level"
}

# =============================================================================
# 3. sb_generate_tenant_schema - テナントテーブル/スキーマ生成
# =============================================================================
sb_generate_tenant_schema() {
    local strategy="${1:-$SB_TENANT_STRATEGY}"
    local db_type="${2:-prisma}"

    _sb_validate_strategy "$strategy" || return 1
    _sb_log INFO "Generating tenant schema: strategy=${strategy}, db_type=${db_type}"

    case "${strategy}:${db_type}" in

        # --- Row-Level: Prisma ---
        row-level:prisma)
            cat <<'SCHEMA_ROW_PRISMA'
// SoloptiLink v18.0 - Multi-Tenant Schema (Row-Level, Prisma)
// Every tenant-scoped model includes a tenantId field with index.

model Tenant {
  id          String   @id @default(uuid())
  name        String
  slug        String   @unique
  domain      String?  @unique
  plan        String   @default("free")
  status      String   @default("active") // active | suspended | cancelled
  settings    Json     @default("{}")
  createdAt   DateTime @default(now()) @map("created_at")
  updatedAt   DateTime @updatedAt @map("updated_at")
  deletedAt   DateTime? @map("deleted_at")

  users       User[]
  @@map("tenants")
}

model User {
  id          String   @id @default(uuid())
  tenantId    String   @map("tenant_id")
  email       String
  name        String?
  passwordHash String  @map("password_hash")
  status      String   @default("active")
  lastLoginAt DateTime? @map("last_login_at")
  createdAt   DateTime @default(now()) @map("created_at")
  updatedAt   DateTime @updatedAt @map("updated_at")

  tenant      Tenant   @relation(fields: [tenantId], references: [id], onDelete: Cascade)

  @@unique([tenantId, email])
  @@index([tenantId])
  @@map("users")
}

// Add tenantId to ALL domain models. Example:
// model Post {
//   id        String @id @default(uuid())
//   tenantId  String @map("tenant_id")
//   title     String
//   ...
//   @@index([tenantId])
// }
SCHEMA_ROW_PRISMA
            ;;

        # --- Row-Level: PostgreSQL ---
        row-level:postgresql)
            cat <<'SCHEMA_ROW_PG'
-- SoloptiLink v18.0 - Multi-Tenant Schema (Row-Level, PostgreSQL)
-- All tenant-scoped tables include tenant_id with foreign key + index.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS tenants (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    domain VARCHAR(255) UNIQUE,
    plan VARCHAR(50) NOT NULL DEFAULT 'free',
    status VARCHAR(20) NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'suspended', 'cancelled')),
    settings JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    deleted_at TIMESTAMPTZ
);

CREATE INDEX IF NOT EXISTS idx_tenants_slug ON tenants(slug);
CREATE INDEX IF NOT EXISTS idx_tenants_status ON tenants(status) WHERE deleted_at IS NULL;

CREATE TABLE IF NOT EXISTS users (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    tenant_id UUID NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    email VARCHAR(255) NOT NULL,
    name VARCHAR(255),
    password_hash VARCHAR(255) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    last_login_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    UNIQUE(tenant_id, email)
);

CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(tenant_id, email);

-- Row-Level Security (RLS) policies for automatic tenant filtering
-- IMPORTANT: Set tenant context before queries: SET app.current_tenant_id = '<tenant_uuid>';
-- In application middleware: await pool.query("SET app.current_tenant_id = $1", [tenantId]);
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation_users ON users
    USING (tenant_id = current_setting('app.current_tenant_id', true)::uuid);
SCHEMA_ROW_PG
            ;;

        # --- Row-Level: MySQL ---
        row-level:mysql)
            cat <<'SCHEMA_ROW_MYSQL'
-- SoloptiLink v18.0 - Multi-Tenant Schema (Row-Level, MySQL)

CREATE TABLE IF NOT EXISTS tenants (
    id CHAR(36) DEFAULT (UUID()) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(100) NOT NULL UNIQUE,
    domain VARCHAR(255) UNIQUE,
    plan VARCHAR(50) NOT NULL DEFAULT 'free',
    status ENUM('active', 'suspended', 'cancelled') NOT NULL DEFAULT 'active',
    settings JSON DEFAULT ('{}'),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    deleted_at TIMESTAMP NULL,
    INDEX idx_slug (slug),
    INDEX idx_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS users (
    id CHAR(36) DEFAULT (UUID()) PRIMARY KEY,
    tenant_id CHAR(36) NOT NULL,
    email VARCHAR(255) NOT NULL,
    name VARCHAR(255),
    password_hash VARCHAR(255) NOT NULL,
    status ENUM('active', 'inactive', 'suspended') NOT NULL DEFAULT 'active',
    last_login_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
    UNIQUE KEY uq_tenant_email (tenant_id, email),
    INDEX idx_tenant (tenant_id),
    FOREIGN KEY (tenant_id) REFERENCES tenants(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
SCHEMA_ROW_MYSQL
            ;;

        # --- Row-Level: SQLite ---
        row-level:sqlite)
            cat <<'SCHEMA_ROW_SQLITE'
-- SoloptiLink v18.0 - Multi-Tenant Schema (Row-Level, SQLite)

CREATE TABLE IF NOT EXISTS tenants (
    id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    name TEXT NOT NULL,
    slug TEXT NOT NULL UNIQUE,
    domain TEXT UNIQUE,
    plan TEXT NOT NULL DEFAULT 'free',
    status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'suspended', 'cancelled')),
    settings TEXT DEFAULT '{}',
    created_at TEXT DEFAULT (datetime('now')) NOT NULL,
    updated_at TEXT DEFAULT (datetime('now')) NOT NULL,
    deleted_at TEXT
);

CREATE INDEX IF NOT EXISTS idx_tenants_slug ON tenants(slug);

CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY DEFAULT (lower(hex(randomblob(16)))),
    tenant_id TEXT NOT NULL REFERENCES tenants(id) ON DELETE CASCADE,
    email TEXT NOT NULL,
    name TEXT,
    password_hash TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    last_login_at TEXT,
    created_at TEXT DEFAULT (datetime('now')) NOT NULL,
    updated_at TEXT DEFAULT (datetime('now')) NOT NULL,
    UNIQUE(tenant_id, email)
);

CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id);
SCHEMA_ROW_SQLITE
            ;;

        # --- DB-Level ---
        db-level:*)
            cat <<'SCHEMA_DB_LEVEL'
-- SoloptiLink v18.0 - Multi-Tenant Schema (DB-Level)
-- Each tenant gets a separate database. This is the routing/management DB.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS tenant_databases (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    tenant_id UUID NOT NULL UNIQUE,
    tenant_slug VARCHAR(100) NOT NULL UNIQUE,
    db_host VARCHAR(255) NOT NULL DEFAULT 'localhost',
    db_port INTEGER NOT NULL DEFAULT 5432,
    db_name VARCHAR(100) NOT NULL,
    db_username VARCHAR(100) NOT NULL,
    db_password_encrypted TEXT NOT NULL,
    connection_pool_size INTEGER NOT NULL DEFAULT 10,
    status VARCHAR(20) NOT NULL DEFAULT 'active'
        CHECK (status IN ('provisioning', 'active', 'suspended', 'decommissioned')),
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_td_tenant ON tenant_databases(tenant_id);
CREATE INDEX IF NOT EXISTS idx_td_slug ON tenant_databases(tenant_slug);

-- Tenant provisioning log
CREATE TABLE IF NOT EXISTS tenant_provisions (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    tenant_id UUID NOT NULL REFERENCES tenant_databases(tenant_id),
    action VARCHAR(50) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    details JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

-- Connection routing helper:
-- SELECT db_host, db_port, db_name, db_username
-- FROM tenant_databases WHERE tenant_slug = :slug AND status = 'active';
SCHEMA_DB_LEVEL
            ;;

        # --- Schema-Level ---
        schema-level:*)
            cat <<'SCHEMA_SCHEMA_LEVEL'
-- SoloptiLink v18.0 - Multi-Tenant Schema (Schema-Level)
-- Each tenant gets a dedicated PostgreSQL schema within the same database.

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Management schema (public)
CREATE TABLE IF NOT EXISTS tenant_schemas (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    tenant_id UUID NOT NULL UNIQUE,
    tenant_slug VARCHAR(100) NOT NULL UNIQUE,
    schema_name VARCHAR(63) NOT NULL UNIQUE,
    status VARCHAR(20) NOT NULL DEFAULT 'active'
        CHECK (status IN ('provisioning', 'active', 'suspended', 'dropped')),
    created_at TIMESTAMPTZ DEFAULT NOW() NOT NULL,
    updated_at TIMESTAMPTZ DEFAULT NOW() NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_ts_slug ON tenant_schemas(tenant_slug);
CREATE INDEX IF NOT EXISTS idx_ts_schema ON tenant_schemas(schema_name);

-- Create tenant schema function
CREATE OR REPLACE FUNCTION create_tenant_schema(p_slug TEXT)
RETURNS TEXT AS $$
DECLARE
    v_schema_name TEXT;
    v_tenant_id UUID;
BEGIN
    v_schema_name := 'tenant_' || replace(p_slug, '-', '_');
    v_tenant_id := uuid_generate_v4();

    EXECUTE format('CREATE SCHEMA IF NOT EXISTS %I', v_schema_name);

    -- Create tables in the tenant schema (mirror of base tables)
    EXECUTE format('CREATE TABLE IF NOT EXISTS %I.users (
        id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
        email VARCHAR(255) NOT NULL UNIQUE,
        name VARCHAR(255),
        password_hash VARCHAR(255) NOT NULL,
        status VARCHAR(20) DEFAULT ''active'',
        created_at TIMESTAMPTZ DEFAULT NOW(),
        updated_at TIMESTAMPTZ DEFAULT NOW()
    )', v_schema_name);

    INSERT INTO public.tenant_schemas (id, tenant_id, tenant_slug, schema_name)
    VALUES (uuid_generate_v4(), v_tenant_id, p_slug, v_schema_name);

    RETURN v_schema_name;
END;
$$ LANGUAGE plpgsql;

-- Set search_path for tenant context:
-- SET search_path TO tenant_acme, public;
SCHEMA_SCHEMA_LEVEL
            ;;
    esac

    _sb_record "SCHEMA_GENERATED" "{\"strategy\":\"${strategy}\",\"db_type\":\"${db_type}\"}"
    _sb_log PASS "Tenant schema generated: strategy=${strategy}, db_type=${db_type}"
}

# =============================================================================
# 4. sb_generate_tenant_middleware - テナントコンテキスト抽出ミドルウェア
# =============================================================================
sb_generate_tenant_middleware() {
    local strategy="${1:-$SB_TENANT_STRATEGY}"
    local framework="${2:-$SB_DETECTED_FRAMEWORK}"

    _sb_log INFO "Generating tenant middleware: strategy=${strategy}, framework=${framework}"

    case "$framework" in

        express)
            cat <<'MW_TENANT_EXPRESS'
// SoloptiLink v18.0 - Tenant Context Middleware (Express)
// Usage: app.use(extractTenantId);

const jwt = require('jsonwebtoken');

const extractTenantId = (req, res, next) => {
  // Strategy 1: From JWT token
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (token) {
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      req.tenantId = decoded.tenantId;
      req.tenantSlug = decoded.tenantSlug;
      return next();
    } catch (e) { /* fall through to next strategy */ }
  }

  // Strategy 2: From subdomain
  const host = req.hostname || req.headers.host?.split(':')[0] || '';
  const subdomain = host.split('.')[0];
  if (subdomain && subdomain !== 'www' && subdomain !== 'api' && subdomain !== 'app') {
    req.tenantId = null; // Will be resolved by DB lookup
    req.tenantSlug = subdomain;
    return next();
  }

  // Strategy 3: From X-Tenant-ID header (for API clients)
  const headerTenant = req.headers['x-tenant-id'];
  if (headerTenant) {
    req.tenantId = headerTenant;
    return next();
  }

  // Strategy 4: From query parameter (for webhooks)
  if (req.query.tenant_id) {
    req.tenantId = req.query.tenant_id;
    return next();
  }

  return res.status(401).json({ error: 'Tenant identification failed' });
};

// Resolve tenant slug to tenant ID (DB lookup)
const resolveTenant = (db) => async (req, res, next) => {
  if (req.tenantId) return next();
  if (!req.tenantSlug) return res.status(400).json({ error: 'No tenant context' });

  try {
    const tenant = await db.tenant.findUnique({ where: { slug: req.tenantSlug } });
    if (!tenant || tenant.status !== 'active') {
      return res.status(404).json({ error: 'Tenant not found or inactive' });
    }
    req.tenantId = tenant.id;
    req.tenant = tenant;
    next();
  } catch (err) {
    return res.status(500).json({ error: 'Tenant resolution failed' });
  }
};

module.exports = { extractTenantId, resolveTenant };
MW_TENANT_EXPRESS
            ;;

        fastify)
            cat <<'MW_TENANT_FASTIFY'
// SoloptiLink v18.0 - Tenant Context Middleware (Fastify)
// Usage: fastify.register(tenantPlugin);

const fp = require('fastify-plugin');
const jwt = require('jsonwebtoken');

async function tenantPlugin(fastify, opts) {
  fastify.decorateRequest('tenantId', null);
  fastify.decorateRequest('tenantSlug', null);
  fastify.decorateRequest('tenant', null);

  fastify.addHook('onRequest', async (request, reply) => {
    // Strategy 1: From JWT token
    const token = request.headers.authorization?.replace('Bearer ', '');
    if (token) {
      try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET);
        request.tenantId = decoded.tenantId;
        request.tenantSlug = decoded.tenantSlug;
        return;
      } catch (e) { /* fall through */ }
    }

    // Strategy 2: From subdomain
    const host = request.hostname || '';
    const subdomain = host.split('.')[0];
    if (subdomain && !['www', 'api', 'app'].includes(subdomain)) {
      request.tenantSlug = subdomain;
      return;
    }

    // Strategy 3: From header
    const headerTenant = request.headers['x-tenant-id'];
    if (headerTenant) {
      request.tenantId = headerTenant;
      return;
    }

    reply.code(401).send({ error: 'Tenant identification failed' });
  });
}

module.exports = fp(tenantPlugin, { name: 'tenant-context' });
MW_TENANT_FASTIFY
            ;;

        nextjs)
            cat <<'MW_TENANT_NEXTJS'
// SoloptiLink v18.0 - Tenant Context Middleware (Next.js)
// File: middleware.ts (project root)

import { NextRequest, NextResponse } from 'next/server';
import { jwtVerify } from 'jose';

const PUBLIC_PATHS = ['/api/auth/login', '/api/auth/register', '/api/health'];

export async function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Skip public paths
  if (PUBLIC_PATHS.some(p => pathname.startsWith(p))) {
    return NextResponse.next();
  }

  const headers = new Headers(request.headers);
  let tenantId: string | null = null;
  let tenantSlug: string | null = null;

  // Strategy 1: From JWT token
  const token = request.headers.get('authorization')?.replace('Bearer ', '');
  if (token) {
    try {
      const secret = new TextEncoder().encode(process.env.JWT_SECRET!);
      const { payload } = await jwtVerify(token, secret);
      tenantId = payload.tenantId as string;
      tenantSlug = payload.tenantSlug as string;
    } catch (e) { /* fall through */ }
  }

  // Strategy 2: From subdomain
  if (!tenantId) {
    const host = request.headers.get('host') || '';
    const subdomain = host.split('.')[0];
    if (subdomain && !['www', 'api', 'app', 'localhost'].includes(subdomain)) {
      tenantSlug = subdomain;
    }
  }

  // Strategy 3: From header
  if (!tenantId && !tenantSlug) {
    tenantId = request.headers.get('x-tenant-id');
  }

  if (!tenantId && !tenantSlug) {
    return NextResponse.json({ error: 'Tenant identification failed' }, { status: 401 });
  }

  // Pass tenant context to API routes via headers
  if (tenantId) headers.set('x-tenant-id', tenantId);
  if (tenantSlug) headers.set('x-tenant-slug', tenantSlug);

  return NextResponse.next({ request: { headers } });
}

export const config = {
  matcher: ['/api/:path*'],
};
MW_TENANT_NEXTJS
            ;;

        django)
            cat <<'MW_TENANT_DJANGO'
# SoloptiLink v18.0 - Tenant Context Middleware (Django)
# File: middleware/tenant.py
# Add to MIDDLEWARE: 'middleware.tenant.TenantMiddleware'

import jwt
from django.conf import settings
from django.http import JsonResponse


class TenantMiddleware:
    """Extract tenant context from JWT, subdomain, or header."""

    PUBLIC_PATHS = ['/api/auth/login', '/api/auth/register', '/api/health']

    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        # Skip public paths
        if any(request.path.startswith(p) for p in self.PUBLIC_PATHS):
            return self.get_response(request)

        tenant_id = None
        tenant_slug = None

        # Strategy 1: From JWT token
        auth_header = request.META.get('HTTP_AUTHORIZATION', '')
        if auth_header.startswith('Bearer '):
            token = auth_header[7:]
            try:
                payload = jwt.decode(token, settings.SECRET_KEY, algorithms=['HS256', 'RS256'])
                tenant_id = payload.get('tenant_id')
                tenant_slug = payload.get('tenant_slug')
            except jwt.InvalidTokenError:
                pass

        # Strategy 2: From subdomain
        if not tenant_id:
            host = request.get_host().split(':')[0]
            parts = host.split('.')
            if len(parts) > 2 and parts[0] not in ('www', 'api', 'app'):
                tenant_slug = parts[0]

        # Strategy 3: From header
        if not tenant_id and not tenant_slug:
            tenant_id = request.META.get('HTTP_X_TENANT_ID')

        if not tenant_id and not tenant_slug:
            return JsonResponse({'error': 'Tenant identification failed'}, status=401)

        request.tenant_id = tenant_id
        request.tenant_slug = tenant_slug

        return self.get_response(request)
MW_TENANT_DJANGO
            ;;

        *)
            _sb_log WARN "Unknown framework: ${framework}. Generating Express middleware as default."
            sb_generate_tenant_middleware "$strategy" "express"
            return $?
            ;;
    esac

    _sb_record "TENANT_MW_GENERATED" "{\"strategy\":\"${strategy}\",\"framework\":\"${framework}\"}"
    _sb_log PASS "Tenant middleware generated for ${framework}"
}

# =============================================================================
# 5. sb_generate_rbac_schema - RBAC権限テーブル生成
# =============================================================================
sb_generate_rbac_schema() {
    _sb_log INFO "Generating RBAC schema..."

    cat <<'RBAC_SCHEMA'
// SoloptiLink v18.0 - RBAC Schema (Prisma)

model Role {
  id          String   @id @default(uuid())
  tenantId    String   @map("tenant_id")
  name        String   // admin, manager, user, viewer, editor
  description String?
  isSystem    Boolean  @default(false) @map("is_system")
  createdAt   DateTime @default(now()) @map("created_at")
  updatedAt   DateTime @updatedAt @map("updated_at")

  rolePermissions RolePermission[]
  userRoles       UserRole[]

  @@unique([tenantId, name])
  @@index([tenantId])
  @@map("roles")
}

model Permission {
  id          String   @id @default(uuid())
  name        String   @unique   // e.g. "posts.write", "users.delete"
  resource    String              // e.g. "posts", "users", "settings"
  action      String              // e.g. "read", "write", "delete", "admin"
  description String?
  createdAt   DateTime @default(now()) @map("created_at")

  rolePermissions RolePermission[]

  @@unique([resource, action])
  @@map("permissions")
}

model RolePermission {
  id           String     @id @default(uuid())
  roleId       String     @map("role_id")
  permissionId String     @map("permission_id")
  createdAt    DateTime   @default(now()) @map("created_at")

  role         Role       @relation(fields: [roleId], references: [id], onDelete: Cascade)
  permission   Permission @relation(fields: [permissionId], references: [id], onDelete: Cascade)

  @@unique([roleId, permissionId])
  @@map("role_permissions")
}

model UserRole {
  id        String   @id @default(uuid())
  userId    String   @map("user_id")
  roleId    String   @map("role_id")
  tenantId  String   @map("tenant_id")
  createdAt DateTime @default(now()) @map("created_at")

  role      Role     @relation(fields: [roleId], references: [id], onDelete: Cascade)

  @@unique([userId, roleId, tenantId])
  @@index([userId, tenantId])
  @@index([tenantId])
  @@map("user_roles")
}
RBAC_SCHEMA

    SB_RBAC_ENABLED="true"
    _sb_record "RBAC_SCHEMA_GENERATED" "{\"tables\":[\"roles\",\"permissions\",\"role_permissions\",\"user_roles\"]}"
    _sb_log PASS "RBAC schema generated (4 tables)"
}

# =============================================================================
# 6. sb_generate_rbac_middleware - 権限チェックミドルウェア生成
# =============================================================================
sb_generate_rbac_middleware() {
    local framework="${1:-$SB_DETECTED_FRAMEWORK}"

    _sb_log INFO "Generating RBAC middleware for: ${framework}"

    case "$framework" in

        express)
            cat <<'RBAC_MW_EXPRESS'
// SoloptiLink v18.0 - RBAC Middleware (Express)
// Usage: router.post('/posts', requirePermission('posts.write'), handler);

const requirePermission = (permission) => {
  return async (req, res, next) => {
    const userId = req.user?.id;
    const tenantId = req.tenantId;

    if (!userId || !tenantId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const [resource, action] = permission.split('.');
    const hasPermission = await checkPermission(userId, tenantId, resource, action);

    if (!hasPermission) {
      return res.status(403).json({
        error: 'Forbidden',
        required: permission,
        message: `You do not have '${permission}' permission`
      });
    }

    next();
  };
};

const requireRole = (roleName) => {
  return async (req, res, next) => {
    const userId = req.user?.id;
    const tenantId = req.tenantId;

    if (!userId || !tenantId) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const userRoles = await db.userRole.findMany({
      where: { userId, tenantId },
      include: { role: true }
    });

    const hasRole = userRoles.some(ur => ur.role.name === roleName);

    if (!hasRole) {
      return res.status(403).json({
        error: 'Forbidden',
        required: roleName,
        message: `Role '${roleName}' is required`
      });
    }

    next();
  };
};

async function checkPermission(userId, tenantId, resource, action) {
  const userRoles = await db.userRole.findMany({
    where: { userId, tenantId },
    include: {
      role: {
        include: {
          rolePermissions: {
            include: { permission: true }
          }
        }
      }
    }
  });

  for (const ur of userRoles) {
    for (const rp of ur.role.rolePermissions) {
      const p = rp.permission;
      if (p.resource === resource && p.action === action) return true;
      if (p.resource === '*' && p.action === '*') return true;
      if (p.resource === resource && p.action === '*') return true;
    }
  }
  return false;
}

module.exports = { requirePermission, requireRole, checkPermission };
RBAC_MW_EXPRESS
            ;;

        fastify)
            cat <<'RBAC_MW_FASTIFY'
// SoloptiLink v18.0 - RBAC Middleware (Fastify)
// Usage: fastify.get('/posts', { preHandler: requirePermission('posts.read') }, handler);

function requirePermission(permission) {
  return async (request, reply) => {
    const userId = request.user?.id;
    const tenantId = request.tenantId;

    if (!userId || !tenantId) {
      reply.code(401).send({ error: 'Unauthorized' });
      return;
    }

    const [resource, action] = permission.split('.');
    const db = request.server.prisma || request.server.db;
    const hasPermission = await checkPermission(db, userId, tenantId, resource, action);

    if (!hasPermission) {
      reply.code(403).send({ error: 'Forbidden', required: permission });
      return;
    }
  };
}

async function checkPermission(db, userId, tenantId, resource, action) {
  const userRoles = await db.userRole.findMany({
    where: { userId, tenantId },
    include: { role: { include: { rolePermissions: { include: { permission: true } } } } }
  });

  for (const ur of userRoles) {
    for (const rp of ur.role.rolePermissions) {
      const p = rp.permission;
      if ((p.resource === resource || p.resource === '*') &&
          (p.action === action || p.action === '*')) return true;
    }
  }
  return false;
}

module.exports = { requirePermission, checkPermission };
RBAC_MW_FASTIFY
            ;;

        nextjs)
            cat <<'RBAC_MW_NEXTJS'
// SoloptiLink v18.0 - RBAC Helper (Next.js App Router)
// Usage in route handler: const perm = await requirePermission(request, 'posts.write');

import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function requirePermission(request: NextRequest, permission: string) {
  const userId = request.headers.get('x-user-id');
  const tenantId = request.headers.get('x-tenant-id');

  if (!userId || !tenantId) {
    return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
  }

  const [resource, action] = permission.split('.');
  const hasPermission = await checkPermission(userId, tenantId, resource, action);

  if (!hasPermission) {
    return NextResponse.json(
      { error: 'Forbidden', required: permission },
      { status: 403 }
    );
  }

  return null; // Permission granted
}

async function checkPermission(
  userId: string, tenantId: string, resource: string, action: string
): Promise<boolean> {
  const userRoles = await prisma.userRole.findMany({
    where: { userId, tenantId },
    include: { role: { include: { rolePermissions: { include: { permission: true } } } } }
  });

  for (const ur of userRoles) {
    for (const rp of ur.role.rolePermissions) {
      const p = rp.permission;
      if ((p.resource === resource || p.resource === '*') &&
          (p.action === action || p.action === '*')) return true;
    }
  }
  return false;
}

export { checkPermission };
RBAC_MW_NEXTJS
            ;;

        django)
            cat <<'RBAC_MW_DJANGO'
# SoloptiLink v18.0 - RBAC Decorator (Django)
# Usage: @require_permission('posts.write')

from functools import wraps
from django.http import JsonResponse
from .models import UserRole


def require_permission(permission_str):
    """Decorator to check RBAC permission before view execution."""
    resource, action = permission_str.split('.')

    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            user_id = getattr(request, 'user_id', None) or getattr(request.user, 'id', None)
            tenant_id = getattr(request, 'tenant_id', None)

            if not user_id or not tenant_id:
                return JsonResponse({'error': 'Unauthorized'}, status=401)

            if not check_permission(user_id, tenant_id, resource, action):
                return JsonResponse(
                    {'error': 'Forbidden', 'required': permission_str},
                    status=403
                )

            return view_func(request, *args, **kwargs)
        return wrapper
    return decorator


def check_permission(user_id, tenant_id, resource, action):
    user_roles = UserRole.objects.filter(
        user_id=user_id, tenant_id=tenant_id
    ).select_related('role__rolepermission_set__permission')

    for ur in user_roles:
        for rp in ur.role.rolepermission_set.all():
            p = rp.permission
            if (p.resource == resource or p.resource == '*') and \
               (p.action == action or p.action == '*'):
                return True
    return False
RBAC_MW_DJANGO
            ;;

        *)
            _sb_log WARN "Unknown framework: ${framework}. Generating Express RBAC as default."
            sb_generate_rbac_middleware "express"
            return $?
            ;;
    esac

    _sb_record "RBAC_MW_GENERATED" "{\"framework\":\"${framework}\"}"
    _sb_log PASS "RBAC middleware generated for ${framework}"
}

# =============================================================================
# 7. sb_suggest_roles - 要件からロール提案
# =============================================================================
sb_suggest_roles() {
    local requirements_text="${1:-}"

    # Base 4 roles (always present)
    SB_ROLES_COUNT=4
    local roles='[{"name":"admin","description":"Full system access","permissions":["*.*"]},{"name":"manager","description":"Manage resources and users","permissions":["*.read","*.write"]},{"name":"user","description":"Standard user access","permissions":["*.read","own.write"]},{"name":"viewer","description":"Read-only access","permissions":["*.read"]}'

    # 追加ロール判定
    if echo "$requirements_text" | grep -qiE '(editor|編集者|content|コンテンツ)'; then
        roles+=',{"name":"editor","description":"Content editing access","permissions":["content.read","content.write","content.publish"]}'
        SB_ROLES_COUNT=$((SB_ROLES_COUNT + 1))
    fi

    # 追加の業務ロール判定
    if echo "$requirements_text" | grep -qiE '(billing|課金|経理|finance|accounting)'; then
        roles+=',{"name":"billing_admin","description":"Billing and subscription management","permissions":["billing.*","subscriptions.*"]}'
        SB_ROLES_COUNT=$((SB_ROLES_COUNT + 1))
    fi

    if echo "$requirements_text" | grep -qiE '(support|サポート|customer.?service|カスタマー)'; then
        roles+=',{"name":"support","description":"Customer support access","permissions":["users.read","tickets.*","audit.read"]}'
        SB_ROLES_COUNT=$((SB_ROLES_COUNT + 1))
    fi

    if echo "$requirements_text" | grep -qiE '(developer|開発者|api.?access|API)'; then
        roles+=',{"name":"developer","description":"API and developer access","permissions":["api.*","webhooks.*","settings.read"]}'
        SB_ROLES_COUNT=$((SB_ROLES_COUNT + 1))
    fi

    roles+=']'

    _sb_log PASS "Suggested ${SB_ROLES_COUNT} roles based on requirements"
    _sb_record "ROLES_SUGGESTED" "{\"count\":${SB_ROLES_COUNT}}"
    echo "$roles"
}

# =============================================================================
# 8. sb_generate_jwt_auth - JWT認証コード生成
# =============================================================================
sb_generate_jwt_auth() {
    local config_json="${1:-{}}"

    _sb_log INFO "Generating JWT authentication code..."
    SB_AUTH_METHODS="jwt"

    cat <<'JWT_AUTH'
// SoloptiLink v18.0 - JWT Authentication (RS256/ES256)
// Access Token: 15min | Refresh Token: 7 days | Token Rotation enabled

const jwt = require('jsonwebtoken');
const crypto = require('crypto');
const bcrypt = require('bcrypt');

const JWT_CONFIG = {
  accessTokenSecret: process.env.JWT_ACCESS_SECRET,
  refreshTokenSecret: process.env.JWT_REFRESH_SECRET,
  accessTokenExpiry: '15m',
  refreshTokenExpiry: '7d',
  algorithm: 'RS256',  // Use RS256 or ES256 for production
  issuer: 'soloptilink-saas',
};

// --- Token Generation ---

function generateAccessToken(user, tenant) {
  return jwt.sign(
    {
      sub: user.id,
      email: user.email,
      tenantId: tenant.id,
      tenantSlug: tenant.slug,
      roles: user.roles || [],
      type: 'access',
    },
    JWT_CONFIG.accessTokenSecret,
    {
      expiresIn: JWT_CONFIG.accessTokenExpiry,
      algorithm: JWT_CONFIG.algorithm,
      issuer: JWT_CONFIG.issuer,
    }
  );
}

function generateRefreshToken(user, tenant) {
  const tokenFamily = crypto.randomUUID();
  return {
    token: jwt.sign(
      {
        sub: user.id,
        tenantId: tenant.id,
        type: 'refresh',
        family: tokenFamily,
      },
      JWT_CONFIG.refreshTokenSecret,
      {
        expiresIn: JWT_CONFIG.refreshTokenExpiry,
        algorithm: JWT_CONFIG.algorithm,
        issuer: JWT_CONFIG.issuer,
      }
    ),
    family: tokenFamily,
  };
}

// --- Token Verification ---

function verifyAccessToken(token) {
  try {
    return jwt.verify(token, JWT_CONFIG.accessTokenSecret, {
      algorithms: [JWT_CONFIG.algorithm],
      issuer: JWT_CONFIG.issuer,
    });
  } catch (err) {
    if (err.name === 'TokenExpiredError') throw new Error('ACCESS_TOKEN_EXPIRED');
    throw new Error('INVALID_ACCESS_TOKEN');
  }
}

function verifyRefreshToken(token) {
  try {
    return jwt.verify(token, JWT_CONFIG.refreshTokenSecret, {
      algorithms: [JWT_CONFIG.algorithm],
      issuer: JWT_CONFIG.issuer,
    });
  } catch (err) {
    throw new Error('INVALID_REFRESH_TOKEN');
  }
}

// --- Token Rotation ---

async function rotateTokens(refreshToken, db) {
  const payload = verifyRefreshToken(refreshToken);

  // Check if refresh token family is revoked (token reuse detection)
  const storedToken = await db.refreshToken.findFirst({
    where: { userId: payload.sub, family: payload.family, revoked: false },
  });

  if (!storedToken) {
    // Token reuse detected! Revoke entire family
    await db.refreshToken.updateMany({
      where: { family: payload.family },
      data: { revoked: true },
    });
    throw new Error('REFRESH_TOKEN_REUSE_DETECTED');
  }

  // Revoke old token
  await db.refreshToken.update({
    where: { id: storedToken.id },
    data: { revoked: true },
  });

  // Get user and tenant
  const user = await db.user.findUnique({ where: { id: payload.sub } });
  const tenant = await db.tenant.findUnique({ where: { id: payload.tenantId } });

  // Generate new token pair
  const newAccessToken = generateAccessToken(user, tenant);
  const newRefreshToken = generateRefreshToken(user, tenant);

  // Store new refresh token
  await db.refreshToken.create({
    data: {
      userId: user.id,
      token: newRefreshToken.token,
      family: newRefreshToken.family,
      expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
    },
  });

  return { accessToken: newAccessToken, refreshToken: newRefreshToken.token };
}

// --- Auth Middleware ---

function authenticate(req, res, next) {
  const token = req.headers.authorization?.replace('Bearer ', '');
  if (!token) return res.status(401).json({ error: 'No token provided' });

  try {
    req.user = verifyAccessToken(token);
    req.tenantId = req.user.tenantId;
    next();
  } catch (err) {
    if (err.message === 'ACCESS_TOKEN_EXPIRED') {
      return res.status(401).json({ error: 'Token expired', code: 'TOKEN_EXPIRED' });
    }
    return res.status(401).json({ error: 'Invalid token' });
  }
}

module.exports = {
  generateAccessToken, generateRefreshToken,
  verifyAccessToken, verifyRefreshToken,
  rotateTokens, authenticate, JWT_CONFIG,
};
JWT_AUTH

    _sb_record "JWT_AUTH_GENERATED" "{\"algorithm\":\"RS256\",\"access_expiry\":\"15m\",\"refresh_expiry\":\"7d\"}"
    _sb_log PASS "JWT authentication code generated (RS256, token rotation)"
}

# =============================================================================
# 9. sb_generate_session_auth - セッション認証コード生成
# =============================================================================
sb_generate_session_auth() {
    local config_json="${1:-{}}"

    _sb_log INFO "Generating session-based authentication code..."
    SB_AUTH_METHODS="session"

    cat <<'SESSION_AUTH'
// SoloptiLink v18.0 - Session-Based Authentication
// express-session + connect-redis for production-grade session management

const session = require('express-session');
const RedisStore = require('connect-redis').default;
const { createClient } = require('redis');
const bcrypt = require('bcrypt');
const crypto = require('crypto');

// --- Redis Client Setup ---
const redisClient = createClient({
  url: process.env.REDIS_URL || 'redis://localhost:6379',
  socket: { reconnectStrategy: (retries) => Math.min(retries * 100, 3000) },
});
redisClient.connect().catch(console.error);

// --- Session Configuration ---
const sessionMiddleware = session({
  store: new RedisStore({ client: redisClient, prefix: 'sess:' }),
  secret: process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex'),
  name: '__saas_sid',
  resave: false,
  saveUninitialized: false,
  rolling: true,
  cookie: {
    secure: process.env.NODE_ENV === 'production',
    httpOnly: true,
    sameSite: 'lax',
    maxAge: 24 * 60 * 60 * 1000, // 24 hours
    domain: process.env.COOKIE_DOMAIN || undefined,
  },
});

// --- Login Handler ---
async function login(req, res, db) {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: 'Email and password required' });
  }

  const user = await db.user.findFirst({
    where: { email, tenantId: req.tenantId },
    include: { tenant: true },
  });

  if (!user || !(await bcrypt.compare(password, user.passwordHash))) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  if (user.status !== 'active') {
    return res.status(403).json({ error: 'Account is not active' });
  }

  // Regenerate session to prevent fixation
  req.session.regenerate((err) => {
    if (err) return res.status(500).json({ error: 'Session error' });

    req.session.userId = user.id;
    req.session.tenantId = user.tenantId;
    req.session.email = user.email;

    req.session.save((err) => {
      if (err) return res.status(500).json({ error: 'Session save error' });
      res.json({ message: 'Login successful', user: { id: user.id, email: user.email } });
    });
  });
}

// --- Logout Handler ---
async function logout(req, res) {
  req.session.destroy((err) => {
    if (err) return res.status(500).json({ error: 'Logout failed' });
    res.clearCookie('__saas_sid');
    res.json({ message: 'Logged out' });
  });
}

// --- Session Auth Middleware ---
function requireSession(req, res, next) {
  if (!req.session?.userId) {
    return res.status(401).json({ error: 'Not authenticated' });
  }
  req.user = { id: req.session.userId };
  req.tenantId = req.session.tenantId;
  next();
}

module.exports = { sessionMiddleware, login, logout, requireSession, redisClient };
SESSION_AUTH

    _sb_record "SESSION_AUTH_GENERATED" "{\"store\":\"redis\",\"cookie_max_age\":\"24h\"}"
    _sb_log PASS "Session authentication code generated (Redis store)"
}

# =============================================================================
# 10. sb_generate_oauth2_scaffold - OAuth2スキャフォールド生成
# =============================================================================
sb_generate_oauth2_scaffold() {
    local providers_json="${1:-[\"google\",\"github\"]}"

    _sb_log INFO "Generating OAuth2 scaffold..."

    cat <<'OAUTH2_SCAFFOLD'
// SoloptiLink v18.0 - OAuth2 Scaffold (NextAuth.js / Passport.js)

// === Option A: NextAuth.js (Next.js) ===
// File: app/api/auth/[...nextauth]/route.ts

import NextAuth from 'next-auth';
import GoogleProvider from 'next-auth/providers/google';
import GitHubProvider from 'next-auth/providers/github';
import MicrosoftProvider from 'next-auth/providers/azure-ad';
import { PrismaAdapter } from '@auth/prisma-adapter';
import { prisma } from '@/lib/prisma';

const handler = NextAuth({
  adapter: PrismaAdapter(prisma),
  providers: [
    GoogleProvider({
      clientId: process.env.GOOGLE_CLIENT_ID!,
      clientSecret: process.env.GOOGLE_CLIENT_SECRET!,
    }),
    GitHubProvider({
      clientId: process.env.GITHUB_CLIENT_ID!,
      clientSecret: process.env.GITHUB_CLIENT_SECRET!,
    }),
    MicrosoftProvider({
      clientId: process.env.AZURE_AD_CLIENT_ID!,
      clientSecret: process.env.AZURE_AD_CLIENT_SECRET!,
      tenantId: process.env.AZURE_AD_TENANT_ID!,
    }),
  ],
  callbacks: {
    async signIn({ user, account, profile }) {
      // Auto-create tenant or link to existing tenant
      return true;
    },
    async session({ session, user }) {
      // Inject tenant context into session
      const dbUser = await prisma.user.findUnique({
        where: { id: user.id },
        include: { tenant: true },
      });
      if (dbUser?.tenant) {
        session.tenantId = dbUser.tenant.id;
        session.tenantSlug = dbUser.tenant.slug;
      }
      session.user.id = user.id;
      return session;
    },
    async jwt({ token, user }) {
      if (user) token.userId = user.id;
      return token;
    },
  },
  pages: {
    signIn: '/auth/signin',
    error: '/auth/error',
  },
});

export { handler as GET, handler as POST };

// === Option B: Passport.js (Express) ===
// File: src/auth/passport.js

/*
const passport = require('passport');
const GoogleStrategy = require('passport-google-oauth20').Strategy;
const GitHubStrategy = require('passport-github2').Strategy;

passport.use(new GoogleStrategy({
    clientID: process.env.GOOGLE_CLIENT_ID,
    clientSecret: process.env.GOOGLE_CLIENT_SECRET,
    callbackURL: '/api/auth/google/callback',
  },
  async (accessToken, refreshToken, profile, done) => {
    try {
      let user = await db.user.findFirst({
        where: { email: profile.emails[0].value },
      });
      if (!user) {
        // Auto-provision: create tenant + user
        const tenant = await db.tenant.create({
          data: { name: profile.displayName, slug: generateSlug(profile.displayName) },
        });
        user = await db.user.create({
          data: {
            email: profile.emails[0].value,
            name: profile.displayName,
            tenantId: tenant.id,
            passwordHash: 'oauth-no-password',
          },
        });
      }
      done(null, user);
    } catch (err) { done(err); }
  }
));

passport.use(new GitHubStrategy({
    clientID: process.env.GITHUB_CLIENT_ID,
    clientSecret: process.env.GITHUB_CLIENT_SECRET,
    callbackURL: '/api/auth/github/callback',
  },
  async (accessToken, refreshToken, profile, done) => {
    // Same pattern as Google
    done(null, profile);
  }
));

// Routes:
// GET /api/auth/google -> passport.authenticate('google', { scope: ['profile', 'email'] })
// GET /api/auth/google/callback -> passport.authenticate('google', { ... })
// GET /api/auth/github -> passport.authenticate('github', { scope: ['user:email'] })
// GET /api/auth/github/callback -> passport.authenticate('github', { ... })
*/

// === Environment Variables (.env) ===
// GOOGLE_CLIENT_ID=your-google-client-id
// GOOGLE_CLIENT_SECRET=your-google-client-secret
// GITHUB_CLIENT_ID=your-github-client-id
// GITHUB_CLIENT_SECRET=your-github-client-secret
// AZURE_AD_CLIENT_ID=your-azure-client-id
// AZURE_AD_CLIENT_SECRET=your-azure-client-secret
// AZURE_AD_TENANT_ID=your-azure-tenant-id
// NEXTAUTH_URL=http://localhost:3000
// NEXTAUTH_SECRET=your-nextauth-secret
OAUTH2_SCAFFOLD

    _sb_record "OAUTH2_GENERATED" "{\"providers\":${providers_json}}"
    _sb_log PASS "OAuth2 scaffold generated (Google, GitHub, Microsoft)"
}

# =============================================================================
# 11. sb_generate_saml_scaffold - SAML SSOスキャフォールド生成
# =============================================================================
sb_generate_saml_scaffold() {
    _sb_log INFO "Generating SAML SSO scaffold..."

    cat <<'SAML_SCAFFOLD'
// SoloptiLink v18.0 - SAML SSO Scaffold
// Enterprise SSO using passport-saml / saml2-js

const passport = require('passport');
const { Strategy: SamlStrategy } = require('passport-saml');

// --- SAML Strategy Configuration ---
const samlConfig = {
  entryPoint: process.env.SAML_ENTRY_POINT,      // IdP SSO URL
  issuer: process.env.SAML_ISSUER || 'soloptilink-saas',
  callbackUrl: process.env.SAML_CALLBACK_URL || 'http://localhost:3000/api/auth/saml/callback',
  cert: process.env.SAML_IDP_CERT,               // IdP public certificate
  privateKey: process.env.SAML_SP_PRIVATE_KEY,    // SP private key (for signing)
  signatureAlgorithm: 'sha256',
  digestAlgorithm: 'sha256',
  wantAuthnResponseSigned: true,
  wantAssertionsSigned: true,
  identifierFormat: 'urn:oasis:names:tc:SAML:2.0:nameid-format:emailAddress',
};

passport.use('saml', new SamlStrategy(samlConfig,
  async (profile, done) => {
    try {
      const email = profile.nameID || profile.email;
      const name = profile.displayName || profile.firstName;

      // Find or create user based on SAML assertion
      let user = await db.user.findFirst({ where: { email } });
      if (!user) {
        // Auto-provision from SAML attributes
        const tenantSlug = profile['urn:oid:2.5.4.10'] || 'default';  // Organization
        let tenant = await db.tenant.findUnique({ where: { slug: tenantSlug } });
        if (!tenant) {
          tenant = await db.tenant.create({
            data: { name: tenantSlug, slug: tenantSlug, plan: 'enterprise' }
          });
        }
        user = await db.user.create({
          data: { email, name, tenantId: tenant.id, passwordHash: 'saml-sso' }
        });
      }

      done(null, user);
    } catch (err) { done(err); }
  }
));

// --- SP Metadata Endpoint ---
// GET /api/auth/saml/metadata
function getMetadata(req, res) {
  const strategy = passport._strategy('saml');
  res.type('application/xml');
  res.send(strategy.generateServiceProviderMetadata(
    process.env.SAML_SP_CERT,   // SP public certificate
    process.env.SAML_SP_CERT
  ));
}

// --- Routes ---
// POST /api/auth/saml/login  -> passport.authenticate('saml')
// POST /api/auth/saml/callback -> passport.authenticate('saml', { ... })
// GET  /api/auth/saml/metadata -> getMetadata

// --- Environment Variables ---
// SAML_ENTRY_POINT=https://idp.example.com/sso
// SAML_ISSUER=soloptilink-saas
// SAML_CALLBACK_URL=https://app.example.com/api/auth/saml/callback
// SAML_IDP_CERT=<base64-encoded IdP cert>
// SAML_SP_PRIVATE_KEY=<base64-encoded SP private key>
// SAML_SP_CERT=<base64-encoded SP certificate>

module.exports = { samlConfig, getMetadata };
SAML_SCAFFOLD

    _sb_record "SAML_GENERATED" "{\"protocol\":\"SAML2.0\"}"
    _sb_log PASS "SAML SSO scaffold generated"
}

# =============================================================================
# 12. sb_generate_billing_schema - 課金/サブスクリプションスキーマ生成
# =============================================================================
sb_generate_billing_schema() {
    _sb_log INFO "Generating billing/subscription schema..."
    SB_BILLING_ENABLED="true"

    cat <<'BILLING_SCHEMA'
// SoloptiLink v18.0 - Billing & Subscription Schema (Prisma)

model Plan {
  id            String   @id @default(uuid())
  name          String   @unique         // free, starter, professional, enterprise
  displayName   String   @map("display_name")
  price         Decimal  @db.Decimal(10, 2)
  interval      String   @default("month")  // month | year
  currency      String   @default("usd")
  features      Json     @default("[]")     // ["feature1", "feature2"]
  limits        Json     @default("{}")     // {"users": 5, "storage_gb": 10}
  stripePriceId String?  @unique @map("stripe_price_id")
  isActive      Boolean  @default(true) @map("is_active")
  sortOrder     Int      @default(0) @map("sort_order")
  createdAt     DateTime @default(now()) @map("created_at")
  updatedAt     DateTime @updatedAt @map("updated_at")

  subscriptions Subscription[]
  @@map("plans")
}

model Subscription {
  id                  String    @id @default(uuid())
  tenantId            String    @map("tenant_id")
  planId              String    @map("plan_id")
  stripeSubscriptionId String?  @unique @map("stripe_subscription_id")
  stripeCustomerId    String?   @map("stripe_customer_id")
  status              String    @default("active")
                                // active | past_due | cancelled | trialing | paused
  currentPeriodStart  DateTime  @map("current_period_start")
  currentPeriodEnd    DateTime  @map("current_period_end")
  cancelAtPeriodEnd   Boolean   @default(false) @map("cancel_at_period_end")
  cancelledAt         DateTime? @map("cancelled_at")
  trialEnd            DateTime? @map("trial_end")
  metadata            Json      @default("{}")
  createdAt           DateTime  @default(now()) @map("created_at")
  updatedAt           DateTime  @updatedAt @map("updated_at")

  plan     Plan      @relation(fields: [planId], references: [id])
  invoices Invoice[]

  @@index([tenantId])
  @@index([status])
  @@map("subscriptions")
}

model Invoice {
  id                  String    @id @default(uuid())
  tenantId            String    @map("tenant_id")
  subscriptionId      String?   @map("subscription_id")
  stripeInvoiceId     String?   @unique @map("stripe_invoice_id")
  amount              Decimal   @db.Decimal(10, 2)
  currency            String    @default("usd")
  status              String    @default("draft")
                                // draft | open | paid | void | uncollectible
  description         String?
  paidAt              DateTime? @map("paid_at")
  dueDate             DateTime? @map("due_date")
  invoicePdfUrl       String?   @map("invoice_pdf_url")
  metadata            Json      @default("{}")
  createdAt           DateTime  @default(now()) @map("created_at")
  updatedAt           DateTime  @updatedAt @map("updated_at")

  subscription Subscription? @relation(fields: [subscriptionId], references: [id])

  @@index([tenantId])
  @@index([status])
  @@map("invoices")
}

model PaymentMethod {
  id                    String   @id @default(uuid())
  tenantId              String   @map("tenant_id")
  stripePaymentMethodId String   @unique @map("stripe_payment_method_id")
  type                  String   @default("card")  // card | bank_account
  last4                 String
  brand                 String?                     // visa | mastercard | amex
  expMonth              Int?     @map("exp_month")
  expYear               Int?     @map("exp_year")
  isDefault             Boolean  @default(false) @map("is_default")
  createdAt             DateTime @default(now()) @map("created_at")

  @@index([tenantId])
  @@map("payment_methods")
}
BILLING_SCHEMA

    _sb_record "BILLING_SCHEMA_GENERATED" "{\"tables\":[\"plans\",\"subscriptions\",\"invoices\",\"payment_methods\"]}"
    _sb_log PASS "Billing schema generated (4 tables)"
}

# =============================================================================
# 13. sb_generate_stripe_scaffold - Stripe統合コード生成
# =============================================================================
sb_generate_stripe_scaffold() {
    _sb_log INFO "Generating Stripe integration scaffold..."

    cat <<'STRIPE_SCAFFOLD'
// SoloptiLink v18.0 - Stripe Integration Scaffold
// Checkout sessions, webhooks, customer portal, usage-based billing

const Stripe = require('stripe');
const stripe = new Stripe(process.env.STRIPE_SECRET_KEY, {
  apiVersion: '2024-12-18.acacia',
});

// --- Checkout Session ---
async function createCheckoutSession(tenantId, planId, db) {
  const tenant = await db.tenant.findUnique({ where: { id: tenantId } });
  const plan = await db.plan.findUnique({ where: { id: planId } });

  if (!tenant || !plan) throw new Error('Tenant or plan not found');

  // Get or create Stripe customer
  let customerId;
  const existingSub = await db.subscription.findFirst({ where: { tenantId } });
  if (existingSub?.stripeCustomerId) {
    customerId = existingSub.stripeCustomerId;
  } else {
    const customer = await stripe.customers.create({
      name: tenant.name,
      metadata: { tenantId, tenantSlug: tenant.slug },
    });
    customerId = customer.id;
  }

  const session = await stripe.checkout.sessions.create({
    customer: customerId,
    mode: 'subscription',
    line_items: [{ price: plan.stripePriceId, quantity: 1 }],
    success_url: `${process.env.APP_URL}/billing/success?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${process.env.APP_URL}/billing/cancel`,
    metadata: { tenantId, planId },
    subscription_data: {
      metadata: { tenantId, planId },
    },
  });

  return { sessionId: session.id, url: session.url };
}

// --- Customer Portal ---
async function createPortalSession(tenantId, db) {
  const subscription = await db.subscription.findFirst({
    where: { tenantId, status: 'active' },
  });

  if (!subscription?.stripeCustomerId) {
    throw new Error('No active subscription found');
  }

  const session = await stripe.billingPortal.sessions.create({
    customer: subscription.stripeCustomerId,
    return_url: `${process.env.APP_URL}/billing`,
  });

  return { url: session.url };
}

// --- Usage-Based Billing ---
async function reportUsage(subscriptionId, quantity, db) {
  const subscription = await db.subscription.findUnique({
    where: { id: subscriptionId },
  });

  if (!subscription?.stripeSubscriptionId) {
    throw new Error('Subscription not found');
  }

  const stripeSubscription = await stripe.subscriptions.retrieve(
    subscription.stripeSubscriptionId
  );

  const meteredItem = stripeSubscription.items.data.find(
    item => item.price.recurring?.usage_type === 'metered'
  );

  if (!meteredItem) throw new Error('No metered item found');

  await stripe.subscriptionItems.createUsageRecord(meteredItem.id, {
    quantity,
    timestamp: Math.floor(Date.now() / 1000),
    action: 'increment',
  });
}

// --- Webhook Handler ---
async function handleWebhook(req, res, db) {
  const sig = req.headers['stripe-signature'];
  let event;

  try {
    event = stripe.webhooks.constructEvent(
      req.body,                           // raw body
      sig,
      process.env.STRIPE_WEBHOOK_SECRET
    );
  } catch (err) {
    console.error('Webhook signature verification failed:', err.message);
    return res.status(400).send(`Webhook Error: ${err.message}`);
  }

  switch (event.type) {
    case 'checkout.session.completed': {
      const session = event.data.object;
      const { tenantId, planId } = session.metadata;

      await db.subscription.create({
        data: {
          tenantId,
          planId,
          stripeSubscriptionId: session.subscription,
          stripeCustomerId: session.customer,
          status: 'active',
          currentPeriodStart: new Date(),
          currentPeriodEnd: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000),
        },
      });

      // Update tenant plan
      await db.tenant.update({
        where: { id: tenantId },
        data: { plan: (await db.plan.findUnique({ where: { id: planId } }))?.name || 'starter' },
      });
      break;
    }

    case 'invoice.paid': {
      const invoice = event.data.object;
      await db.invoice.create({
        data: {
          tenantId: invoice.metadata?.tenantId,
          stripeInvoiceId: invoice.id,
          amount: invoice.amount_paid / 100,
          currency: invoice.currency,
          status: 'paid',
          paidAt: new Date(),
          invoicePdfUrl: invoice.invoice_pdf,
        },
      });
      break;
    }

    case 'invoice.payment_failed': {
      const invoice = event.data.object;
      const sub = await db.subscription.findFirst({
        where: { stripeSubscriptionId: invoice.subscription },
      });
      if (sub) {
        await db.subscription.update({
          where: { id: sub.id },
          data: { status: 'past_due' },
        });
      }
      break;
    }

    case 'customer.subscription.deleted': {
      const subscription = event.data.object;
      const sub = await db.subscription.findFirst({
        where: { stripeSubscriptionId: subscription.id },
      });
      if (sub) {
        await db.subscription.update({
          where: { id: sub.id },
          data: { status: 'cancelled', cancelledAt: new Date() },
        });
        // Downgrade tenant to free plan
        await db.tenant.update({
          where: { id: sub.tenantId },
          data: { plan: 'free' },
        });
      }
      break;
    }

    case 'customer.subscription.updated': {
      const subscription = event.data.object;
      const sub = await db.subscription.findFirst({
        where: { stripeSubscriptionId: subscription.id },
      });
      if (sub) {
        await db.subscription.update({
          where: { id: sub.id },
          data: {
            status: subscription.status,
            currentPeriodStart: new Date(subscription.current_period_start * 1000),
            currentPeriodEnd: new Date(subscription.current_period_end * 1000),
            cancelAtPeriodEnd: subscription.cancel_at_period_end,
          },
        });
      }
      break;
    }

    default:
      console.log(`Unhandled event type: ${event.type}`);
  }

  res.json({ received: true });
}

// --- Routes ---
// POST /api/billing/checkout -> createCheckoutSession
// POST /api/billing/portal   -> createPortalSession
// POST /api/billing/usage    -> reportUsage
// POST /api/webhooks/stripe  -> handleWebhook (use express.raw() for body)

// --- Environment Variables ---
// STRIPE_SECRET_KEY=sk_...
// STRIPE_WEBHOOK_SECRET=whsec_...
// APP_URL=http://localhost:3000

module.exports = {
  createCheckoutSession, createPortalSession,
  reportUsage, handleWebhook, stripe,
};
STRIPE_SCAFFOLD

    _sb_record "STRIPE_GENERATED" "{\"features\":[\"checkout\",\"portal\",\"webhooks\",\"usage_billing\"]}"
    _sb_log PASS "Stripe integration scaffold generated"
}

# =============================================================================
# 14. sb_generate_tenant_migration - テナント戦略間マイグレーション
# =============================================================================
sb_generate_tenant_migration() {
    local from_strategy="${1:-row-level}"
    local to_strategy="${2:-schema-level}"

    _sb_validate_strategy "$from_strategy" || return 1
    _sb_validate_strategy "$to_strategy" || return 1

    _sb_log INFO "Generating migration script: ${from_strategy} -> ${to_strategy}"

    cat <<MIGRATION_SCRIPT
-- SoloptiLink v18.0 - Tenant Strategy Migration
-- Migration: ${from_strategy} -> ${to_strategy}
-- Generated: $(date -u '+%Y-%m-%dT%H:%M:%SZ')
--
-- WARNING: This is a significant architectural change.
-- 1. Back up ALL data before execution.
-- 2. Test in staging environment first.
-- 3. Plan for downtime during migration.

BEGIN;

-- Phase 1: Pre-migration validation
DO \$\$
DECLARE
    tenant_count INTEGER;
BEGIN
    SELECT COUNT(*) INTO tenant_count FROM tenants WHERE deleted_at IS NULL;
    RAISE NOTICE 'Migrating % tenants from ${from_strategy} to ${to_strategy}', tenant_count;
END \$\$;

MIGRATION_SCRIPT

    case "${from_strategy}:${to_strategy}" in
        row-level:schema-level)
            cat <<'MIGRATE_ROW_TO_SCHEMA'
-- Phase 2: Create schema infrastructure
CREATE TABLE IF NOT EXISTS tenant_schemas (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    tenant_id UUID NOT NULL UNIQUE,
    tenant_slug VARCHAR(100) NOT NULL UNIQUE,
    schema_name VARCHAR(63) NOT NULL UNIQUE,
    status VARCHAR(20) DEFAULT 'provisioning',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Phase 3: Create schemas for each tenant and migrate data
DO $$
DECLARE
    t RECORD;
    schema_name TEXT;
BEGIN
    FOR t IN SELECT id, slug FROM tenants WHERE deleted_at IS NULL LOOP
        schema_name := 'tenant_' || replace(t.slug, '-', '_');

        -- Create schema
        EXECUTE format('CREATE SCHEMA IF NOT EXISTS %I', schema_name);

        -- Create tables in tenant schema (replicate structure without tenant_id)
        EXECUTE format('CREATE TABLE %I.users AS SELECT id, email, name, password_hash, status, created_at, updated_at FROM users WHERE tenant_id = %L', schema_name, t.id);

        -- Register schema mapping
        INSERT INTO tenant_schemas (tenant_id, tenant_slug, schema_name, status)
        VALUES (t.id, t.slug, schema_name, 'active');

        RAISE NOTICE 'Migrated tenant % to schema %', t.slug, schema_name;
    END LOOP;
END $$;

-- Phase 4: Verification
SELECT ts.tenant_slug, ts.schema_name, ts.status,
       (SELECT COUNT(*) FROM information_schema.tables
        WHERE table_schema = ts.schema_name) as table_count
FROM tenant_schemas ts ORDER BY ts.tenant_slug;
MIGRATE_ROW_TO_SCHEMA
            ;;

        row-level:db-level)
            cat <<'MIGRATE_ROW_TO_DB'
-- Phase 2: Create routing infrastructure
CREATE TABLE IF NOT EXISTS tenant_databases (
    id UUID DEFAULT uuid_generate_v4() PRIMARY KEY,
    tenant_id UUID NOT NULL UNIQUE,
    tenant_slug VARCHAR(100) NOT NULL UNIQUE,
    db_host VARCHAR(255) DEFAULT 'localhost',
    db_port INTEGER DEFAULT 5432,
    db_name VARCHAR(100) NOT NULL,
    db_username VARCHAR(100) NOT NULL,
    db_password_encrypted TEXT NOT NULL,
    connection_pool_size INTEGER DEFAULT 10,
    status VARCHAR(20) DEFAULT 'provisioning',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Phase 3: Register each tenant (actual DB creation requires external script)
DO $$
DECLARE
    t RECORD;
    db_name TEXT;
BEGIN
    FOR t IN SELECT id, slug FROM tenants WHERE deleted_at IS NULL LOOP
        db_name := 'saas_' || replace(t.slug, '-', '_');

        INSERT INTO tenant_databases (tenant_id, tenant_slug, db_name, db_username, db_password_encrypted, status)
        VALUES (t.id, t.slug, db_name, 'saas_user', 'ENCRYPTED_PLACEHOLDER', 'pending');

        RAISE NOTICE 'Registered tenant % for DB migration: %', t.slug, db_name;
    END LOOP;
END $$;

-- NOTE: Actual database creation and data migration must be performed
-- by an external migration script using pg_dump/pg_restore per tenant.
-- SELECT tenant_slug, db_name FROM tenant_databases WHERE status = 'pending';
MIGRATE_ROW_TO_DB
            ;;

        schema-level:row-level)
            cat <<'MIGRATE_SCHEMA_TO_ROW'
-- Phase 2: Ensure row-level columns exist
ALTER TABLE users ADD COLUMN IF NOT EXISTS tenant_id UUID;

-- Phase 3: Migrate data from schemas to single table
DO $$
DECLARE
    ts RECORD;
BEGIN
    FOR ts IN SELECT tenant_id, schema_name FROM tenant_schemas WHERE status = 'active' LOOP
        EXECUTE format(
            'INSERT INTO users (id, tenant_id, email, name, password_hash, status, created_at, updated_at)
             SELECT id, %L, email, name, password_hash, status, created_at, updated_at
             FROM %I.users
             ON CONFLICT (id) DO NOTHING',
            ts.tenant_id, ts.schema_name
        );

        RAISE NOTICE 'Migrated schema % to row-level', ts.schema_name;
    END LOOP;
END $$;

-- Phase 4: Add constraints
ALTER TABLE users ALTER COLUMN tenant_id SET NOT NULL;
CREATE INDEX IF NOT EXISTS idx_users_tenant ON users(tenant_id);

-- Phase 5: Enable RLS
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON users USING (tenant_id = current_setting('app.current_tenant_id', true)::uuid);
MIGRATE_SCHEMA_TO_ROW
            ;;

        *)
            _sb_log WARN "Migration path ${from_strategy} -> ${to_strategy} requires custom handling"
            echo "-- Custom migration required for ${from_strategy} -> ${to_strategy}"
            echo "-- Please implement based on your specific schema and data requirements."
            ;;
    esac

    echo ""
    echo "COMMIT;"

    _sb_record "MIGRATION_GENERATED" "{\"from\":\"${from_strategy}\",\"to\":\"${to_strategy}\"}"
    _sb_log PASS "Migration script generated: ${from_strategy} -> ${to_strategy}"
}

# =============================================================================
# 15. sb_generate_saas_prompt - Claude CLI用SaaS要件プロンプト生成
# =============================================================================
sb_generate_saas_prompt() {
    local tenant_strategy="${1:-$SB_TENANT_STRATEGY}"
    local auth_methods="${2:-$SB_AUTH_METHODS}"
    local billing_enabled="${3:-$SB_BILLING_ENABLED}"

    cat <<SAAS_PROMPT
## マルチテナントSaaS要件（必須 - SoloptiLink v18.0 SaaS Builder）

### テナント分離戦略: ${tenant_strategy}
$(case "$tenant_strategy" in
    row-level)
        echo "- 全テーブルにtenant_idカラム（UUID, NOT NULL, INDEX）を追加"
        echo "- 全クエリにWHERE tenant_id = :currentTenantIdを自動付与"
        echo "- Prisma middleware / Django middleware でテナントコンテキスト自動注入"
        echo "- テナント間のデータ漏洩を絶対に防止（RLSポリシー推奨）"
        ;;
    db-level)
        echo "- テナントごとに独立したデータベースを使用"
        echo "- ルーティングテーブルでテナント→DB接続情報を管理"
        echo "- 接続プール管理: テナントごとの接続プールサイズ制限"
        echo "- データベースのプロビジョニング/デプロビジョニング自動化"
        ;;
    schema-level)
        echo "- テナントごとにPostgreSQLスキーマを分離"
        echo "- search_pathでテナントスキーマに切り替え"
        echo "- スキーマのプロビジョニング関数を実装"
        echo "- マイグレーション時は全テナントスキーマに適用"
        ;;
esac)

### 認証方式: ${auth_methods}
$(case "$auth_methods" in
    jwt)
        echo "- JWT (RS256/ES256): アクセストークン15分、リフレッシュトークン7日"
        echo "- トークンローテーション実装（リフレッシュ時に古いトークンを無効化）"
        echo "- トークンにtenantId, tenantSlugを含める"
        echo "- bcrypt/argon2idでパスワードハッシュ化"
        ;;
    session)
        echo "- セッション認証: express-session + connect-redis"
        echo "- Secure/HttpOnly/SameSite=Lax Cookie設定"
        echo "- セッションにtenantId保持、regenerateでフィクセーション防止"
        ;;
    oauth2)
        echo "- OAuth2: Google/GitHub/Microsoft対応"
        echo "- NextAuth.js or Passport.js パターン"
        echo "- 初回ログイン時にテナント自動プロビジョニング"
        ;;
    saml)
        echo "- SAML 2.0 SSO: エンタープライズIdP対応"
        echo "- SP Metadataエンドポイント提供"
        echo "- SAML Assertionからユーザーとテナントをマッピング"
        ;;
esac)

### RBAC権限管理
- roles, permissions, role_permissions, user_rolesテーブル
- requirePermission('resource.action')ミドルウェアパターン
- デフォルトロール: admin, manager, user, viewer
- テナントスコープのロール（tenant_id付き）

$(if [[ "$billing_enabled" == "true" ]]; then
    echo "### 課金/サブスクリプション"
    echo "- plans, subscriptions, invoices, payment_methodsテーブル"
    echo "- Stripe Checkout / Customer Portal / Webhook統合"
    echo "- プラン制限の強制（ユーザー数、ストレージ等）"
    echo "- 使用量ベース課金対応"
fi)

### SaaSセキュリティ要件
- テナントデータの完全分離（クロステナントアクセス防止）
- API Rate Limiting: テナント別/プラン別のレート制限
- サブドメインベースのテナント識別（acme.app.com）
- CORS: テナント固有ドメインのホワイトリスト
- 管理者APIの分離（/api/admin/* は superadmin のみ）
SAAS_PROMPT

    _sb_record "SAAS_PROMPT_GENERATED" "{\"strategy\":\"${tenant_strategy}\",\"auth\":\"${auth_methods}\",\"billing\":\"${billing_enabled}\"}"
    _sb_log PASS "SaaS prompt generated for Claude CLI injection"
}

# =============================================================================
# 16. sb_report - カラーレポート出力
# =============================================================================
sb_report() {
    echo
    printf "${SB_BOLD}${SB_PURPLE}"
    printf '=%.0s' {1..60}; echo
    printf "  SoloptiLink Chain v18.0 - SaaS Builder Report\n"
    printf '=%.0s' {1..60}
    printf "${SB_NC}\n"

    printf "${SB_BOLD}|${SB_NC}  %-24s: ${SB_CYAN}%-30s${SB_NC}${SB_BOLD}|${SB_NC}\n" \
        "Version" "${SB_VERSION}"
    printf "${SB_BOLD}|${SB_NC}  %-24s: ${SB_CYAN}%-30s${SB_NC}${SB_BOLD}|${SB_NC}\n" \
        "Session" "${SB_SESSION_ID}"
    printf "${SB_BOLD}|${SB_NC}  %-24s: ${SB_GREEN}%-30s${SB_NC}${SB_BOLD}|${SB_NC}\n" \
        "Tenant Strategy" "${SB_TENANT_STRATEGY}"
    printf "${SB_BOLD}|${SB_NC}  %-24s: ${SB_GREEN}%-30s${SB_NC}${SB_BOLD}|${SB_NC}\n" \
        "Auth Methods" "${SB_AUTH_METHODS}"
    printf "${SB_BOLD}|${SB_NC}  %-24s: ${SB_GREEN}%-30s${SB_NC}${SB_BOLD}|${SB_NC}\n" \
        "RBAC Enabled" "${SB_RBAC_ENABLED}"
    printf "${SB_BOLD}|${SB_NC}  %-24s: ${SB_GREEN}%-30s${SB_NC}${SB_BOLD}|${SB_NC}\n" \
        "Billing Enabled" "${SB_BILLING_ENABLED}"
    printf "${SB_BOLD}|${SB_NC}  %-24s: ${SB_CYAN}%-30s${SB_NC}${SB_BOLD}|${SB_NC}\n" \
        "Framework" "${SB_DETECTED_FRAMEWORK}"
    printf "${SB_BOLD}|${SB_NC}  %-24s: ${SB_CYAN}%-30s${SB_NC}${SB_BOLD}|${SB_NC}\n" \
        "ORM" "${SB_DETECTED_ORM}"
    printf "${SB_BOLD}|${SB_NC}  %-24s: ${SB_CYAN}%-30d${SB_NC}${SB_BOLD}|${SB_NC}\n" \
        "Roles Configured" "${SB_ROLES_COUNT}"

    printf "${SB_BOLD}"
    printf '=%.0s' {1..60}
    printf "${SB_NC}\n"

    # 結果一覧
    if [[ -n "$SB_RESULTS" ]]; then
        echo -e "${SB_BOLD}  Execution Log:${SB_NC}"
        printf '%b' "$SB_RESULTS" | while IFS='|' read -r lv msg; do
            [[ -z "$lv" || -z "$msg" ]] && continue
            local c="$SB_NC"
            case "$lv" in
                PASS)    c="$SB_GREEN" ;;
                WARN)    c="$SB_YELLOW" ;;
                ERROR)   c="$SB_RED" ;;
                INFO)    c="$SB_CYAN" ;;
                SECTION) c="$SB_PURPLE" ;;
            esac
            printf "    ${c}[${lv}]${SB_NC} %s\n" "$msg"
        done
    fi

    echo
}

# =============================================================================
# 17. sb_export_json - JSONエクスポート
# =============================================================================
sb_export_json() {
    local output_file="${1:-}"
    [[ -z "$output_file" ]] && {
        local pd="${SB_PROJECT_DIR:-.}"
        output_file="${pd}/docs/chain-logs/saas-builder-$(date '+%Y%m%d-%H%M%S').json"
    }
    mkdir -p "$(dirname "$output_file")" 2>/dev/null || true

    # findings配列
    local findings_json="[" first=true
    while IFS='|' read -r lv msg; do
        [[ -z "$lv" || -z "$msg" ]] && continue
        [[ "$first" == "true" ]] && first=false || findings_json+=","
        msg=$(echo "$msg" | sed 's/\\/\\\\/g; s/"/\\"/g; s/\t/\\t/g')
        findings_json+="{\"level\":\"${lv}\",\"message\":\"${msg}\"}"
    done < <(printf '%b' "$SB_RESULTS"); findings_json+="]"

    cat > "$output_file" <<ENDJSON
{
  "report_type": "saas_builder",
  "version": "${SB_VERSION}",
  "generated_at": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')",
  "session_id": "${SB_SESSION_ID}",
  "project_dir": "${SB_PROJECT_DIR}",
  "configuration": {
    "tenant_strategy": "${SB_TENANT_STRATEGY}",
    "auth_methods": "${SB_AUTH_METHODS}",
    "billing_enabled": ${SB_BILLING_ENABLED},
    "rbac_enabled": ${SB_RBAC_ENABLED},
    "detected_framework": "${SB_DETECTED_FRAMEWORK}",
    "detected_orm": "${SB_DETECTED_ORM}",
    "roles_count": ${SB_ROLES_COUNT},
    "permissions_count": ${SB_PERMISSIONS_COUNT}
  },
  "findings": ${findings_json}
}
ENDJSON

    _sb_log INFO "JSON exported: ${output_file}"
    echo "$output_file"
}

# =============================================================================
# エクスポート情報
# =============================================================================
#   source lib/saas-builder.sh
#   sb_init "session_123" "row-level"
#   sb_detect_tenant_strategy "enterprise CRM with high security"
#   sb_generate_tenant_schema "row-level" "prisma"
#   sb_generate_tenant_middleware "row-level" "express"
#   sb_generate_rbac_schema
#   sb_generate_rbac_middleware "express"
#   sb_suggest_roles "CRM with editors and billing"
#   sb_generate_jwt_auth '{}'
#   sb_generate_session_auth '{}'
#   sb_generate_oauth2_scaffold '["google","github"]'
#   sb_generate_saml_scaffold
#   sb_generate_billing_schema
#   sb_generate_stripe_scaffold
#   sb_generate_tenant_migration "row-level" "schema-level"
#   sb_generate_saas_prompt "row-level" "jwt" "true"
#   sb_report
#   sb_export_json "/path/to/output.json"
