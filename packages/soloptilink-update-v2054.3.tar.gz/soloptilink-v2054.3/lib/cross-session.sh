#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v44.0 - Cross-Session Intelligence Engine
# =============================================================================
# セッション間の学習データを横断分析し、新規セッション開始時に
# 過去の知見を自動注入するエンジン。Living System(v40)のセッション履歴 +
# Prompt Memory + Cost Gate学習 + Smart Retry統計を統合分析。
#
# v44.0の核心: 「前回CRMを作った時に品質ゲートでモック残存が問題だった」
# 「ecommerceではPrismaスキーマで外部キー設定漏れが多い」等の
# セッション間パターンを自動学習し、次回セッション開始時に注入。
#
# Functions:
#   cs_init              - Cross-Session初期化
#   cs_load_history      - 過去セッション履歴の読み込み
#   cs_analyze_patterns  - パターン分析
#   cs_get_domain_insights - ドメイン別知見取得
#   cs_get_common_errors  - よくあるエラーパターン取得
#   cs_get_quality_trend  - 品質トレンド取得
#   cs_generate_advisory  - アドバイザリー生成
#   cs_get_stats         - 統計情報を返す
#   cs_save              - 分析結果永続化
#
# All globals use the CS_ prefix.
# =============================================================================

[[ -n "${_CROSS_SESSION_LOADED:-}" ]] && return 0
_CROSS_SESSION_LOADED=1

declare -g CS_VERSION="44.0"
declare -g CS_ENABLED="${CS_ENABLED:-true}"

# 分析結果
declare -g CS_TOTAL_SESSIONS=0
declare -g CS_DOMAINS_SEEN=0
declare -g CS_AVG_QUALITY=0
declare -g CS_AVG_COST=0
declare -g CS_COMMON_ERRORS=""
declare -g CS_QUALITY_TREND=""      # improving|stable|declining
declare -g CS_ADVISORY=""
declare -g CS_HISTORY_FILE=""
declare -g CS_ANALYSIS_FILE=""

# ドメイン別データ
declare -g -A CS_DOMAIN_QUALITY=()
declare -g -A CS_DOMAIN_COUNT=()

# =============================================================================
# cs_init - Cross-Session初期化
# =============================================================================
cs_init() {
    local session_id="${1:-default}"

    CS_TOTAL_SESSIONS=0
    CS_DOMAINS_SEEN=0
    CS_AVG_QUALITY=0
    CS_AVG_COST=0
    CS_COMMON_ERRORS=""
    CS_QUALITY_TREND="stable"
    CS_ADVISORY=""
    CS_DOMAIN_QUALITY=()
    CS_DOMAIN_COUNT=()

    local knowledge_dir="${HOME}/.soloptilink/knowledge"
    mkdir -p "$knowledge_dir" 2>/dev/null || true
    CS_HISTORY_FILE="${knowledge_dir}/living_system_sessions.jsonl"
    CS_ANALYSIS_FILE="${knowledge_dir}/cross_session_analysis.json"

    # 過去データがあれば読み込み
    cs_load_history

    return 0
}

# =============================================================================
# cs_load_history - 過去セッション履歴の読み込み
# =============================================================================
cs_load_history() {
    CS_TOTAL_SESSIONS=0

    # Living Systemのセッション履歴を読み込み
    if [[ -f "$CS_HISTORY_FILE" ]]; then
        CS_TOTAL_SESSIONS=$(wc -l < "$CS_HISTORY_FILE" 2>/dev/null | tr -d ' ')
        [[ -z "$CS_TOTAL_SESSIONS" ]] && CS_TOTAL_SESSIONS=0
    fi

    # 前回の分析結果があれば読み込み
    if [[ -f "$CS_ANALYSIS_FILE" ]]; then
        # JSON解析（bashで簡易的に）
        local prev_quality prev_trend
        prev_quality=$(grep -o '"avg_quality":[0-9]*' "$CS_ANALYSIS_FILE" 2>/dev/null | head -1 | cut -d: -f2)
        prev_trend=$(grep -o '"quality_trend":"[a-z]*"' "$CS_ANALYSIS_FILE" 2>/dev/null | head -1 | cut -d'"' -f4)

        [[ -n "$prev_quality" ]] && CS_AVG_QUALITY=$prev_quality
        [[ -n "$prev_trend" ]] && CS_QUALITY_TREND=$prev_trend
    fi

    return 0
}

# =============================================================================
# cs_analyze_patterns - パターン分析
# =============================================================================
cs_analyze_patterns() {
    [[ ! -f "$CS_HISTORY_FILE" ]] && return 0
    [[ $CS_TOTAL_SESSIONS -eq 0 ]] && return 0

    local total_quality=0
    local total_cost=0
    local count=0
    local domains_list=""

    # セッション履歴を行ごとに分析
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue

        local domain quality cost
        domain=$(echo "$line" | grep -o '"domain":"[^"]*"' | head -1 | cut -d'"' -f4)
        quality=$(echo "$line" | grep -o '"quality_score":[0-9]*' | head -1 | cut -d: -f2)
        cost=$(echo "$line" | grep -o '"cost":"[^"]*"' | head -1 | cut -d'"' -f4)

        [[ -z "$domain" ]] && domain="general"
        [[ -z "$quality" ]] && quality=0
        [[ -z "$cost" ]] && cost="0"

        # 数値変換
        quality=$(echo "$quality" | tr -d '[:space:]')
        [[ -z "$quality" || ! "$quality" =~ ^[0-9]+$ ]] && quality=0

        total_quality=$((total_quality + quality))
        count=$((count + 1))

        # ドメイン別集計
        if [[ -n "$domain" ]]; then
            local prev_q="${CS_DOMAIN_QUALITY[$domain]:-0}"
            local prev_c="${CS_DOMAIN_COUNT[$domain]:-0}"
            CS_DOMAIN_QUALITY[$domain]=$((prev_q + quality))
            CS_DOMAIN_COUNT[$domain]=$((prev_c + 1))

            if [[ "$domains_list" != *"$domain"* ]]; then
                domains_list="${domains_list:+${domains_list},}${domain}"
            fi
        fi
    done < "$CS_HISTORY_FILE"

    if [[ $count -gt 0 ]]; then
        CS_AVG_QUALITY=$((total_quality / count))
    fi

    # ドメイン数カウント
    CS_DOMAINS_SEEN=0
    local IFS_BAK="$IFS"
    IFS=','
    for d in $domains_list; do
        CS_DOMAINS_SEEN=$((CS_DOMAINS_SEEN + 1))
    done
    IFS="$IFS_BAK"

    # 品質トレンド判定（最新5件 vs 前5件）
    CS_QUALITY_TREND=$(_cs_calc_trend)

    return 0
}

# =============================================================================
# _cs_calc_trend - 品質トレンド計算
# =============================================================================
_cs_calc_trend() {
    [[ ! -f "$CS_HISTORY_FILE" ]] && echo "stable" && return 0

    local total_lines
    total_lines=$(wc -l < "$CS_HISTORY_FILE" 2>/dev/null | tr -d ' ')
    [[ -z "$total_lines" || "$total_lines" -lt 4 ]] && echo "stable" && return 0

    local half=$((total_lines / 2))
    local first_total=0 first_count=0
    local second_total=0 second_count=0
    local line_num=0

    while IFS= read -r line; do
        line_num=$((line_num + 1))
        local q
        q=$(echo "$line" | grep -o '"quality_score":[0-9]*' | head -1 | cut -d: -f2)
        q=$(echo "$q" | tr -d '[:space:]')
        [[ -z "$q" || ! "$q" =~ ^[0-9]+$ ]] && q=0

        if [[ $line_num -le $half ]]; then
            first_total=$((first_total + q))
            first_count=$((first_count + 1))
        else
            second_total=$((second_total + q))
            second_count=$((second_count + 1))
        fi
    done < "$CS_HISTORY_FILE"

    [[ $first_count -eq 0 || $second_count -eq 0 ]] && echo "stable" && return 0

    local first_avg=$((first_total / first_count))
    local second_avg=$((second_total / second_count))
    local diff=$((second_avg - first_avg))

    if [[ $diff -gt 5 ]]; then
        echo "improving"
    elif [[ $diff -lt -5 ]]; then
        echo "declining"
    else
        echo "stable"
    fi
}

# =============================================================================
# cs_get_domain_insights - ドメイン別知見取得
# =============================================================================
cs_get_domain_insights() {
    local domain="${1:-general}"

    local count="${CS_DOMAIN_COUNT[$domain]:-0}"
    local total_quality="${CS_DOMAIN_QUALITY[$domain]:-0}"

    [[ $count -eq 0 ]] && echo "no_data" && return 0

    local avg=$((total_quality / count))
    echo "sessions=${count};avg_quality=${avg}"
}

# =============================================================================
# cs_get_common_errors - よくあるエラーパターン取得
# =============================================================================
cs_get_common_errors() {
    local errors=""

    # Smart Retry履歴からエラーパターンを取得
    local sr_file="${HOME}/.soloptilink/knowledge/smart_retry_history.json"
    if [[ -f "$sr_file" ]]; then
        local timeout_count rate_limit_count
        timeout_count=$(grep -c "timeout" "$sr_file" 2>/dev/null || echo "0")
        rate_limit_count=$(grep -c "rate_limit" "$sr_file" 2>/dev/null || echo "0")
        timeout_count=$(echo "$timeout_count" | tr -d '[:space:]')
        rate_limit_count=$(echo "$rate_limit_count" | tr -d '[:space:]')
        [[ -z "$timeout_count" ]] && timeout_count=0
        [[ -z "$rate_limit_count" ]] && rate_limit_count=0

        [[ $timeout_count -gt 2 ]] && errors="${errors:+${errors};}frequent_timeouts"
        [[ $rate_limit_count -gt 2 ]] && errors="${errors:+${errors};}rate_limiting"
    fi

    # Output Analyzer履歴からパターン取得
    local oa_file="${HOME}/.soloptilink/knowledge/output_analyzer_history.jsonl"
    if [[ -f "$oa_file" ]]; then
        local low_quality_count
        low_quality_count=$(grep -c '"avg_quality":[0-6][0-9],' "$oa_file" 2>/dev/null || echo "0")
        low_quality_count=$(echo "$low_quality_count" | tr -d '[:space:]')
        [[ -z "$low_quality_count" ]] && low_quality_count=0
        [[ $low_quality_count -gt 2 ]] && errors="${errors:+${errors};}low_quality_output"
    fi

    CS_COMMON_ERRORS="$errors"
    [[ -z "$errors" ]] && errors="none"
    echo "$errors"
}

# =============================================================================
# cs_generate_advisory - アドバイザリー生成
# =============================================================================
cs_generate_advisory() {
    local domain="${1:-general}"
    local advisory=""

    # セッション数ベース
    if [[ $CS_TOTAL_SESSIONS -eq 0 ]]; then
        advisory="first_session"
        CS_ADVISORY="$advisory"
        echo "$advisory"
        return 0
    fi

    # 品質トレンドベース
    case "$CS_QUALITY_TREND" in
        declining)
            advisory="quality_declining:consider_stricter_validation"
            ;;
        improving)
            advisory="quality_improving:maintain_current_approach"
            ;;
    esac

    # ドメイン経験ベース
    local domain_count="${CS_DOMAIN_COUNT[$domain]:-0}"
    if [[ $domain_count -gt 3 ]]; then
        advisory="${advisory:+${advisory};}domain_experienced:use_learned_patterns"
    elif [[ $domain_count -eq 0 ]]; then
        advisory="${advisory:+${advisory};}domain_new:apply_extra_validation"
    fi

    # 平均品質ベース
    if [[ $CS_AVG_QUALITY -lt 60 ]]; then
        advisory="${advisory:+${advisory};}low_avg_quality:enable_strict_mode"
    fi

    [[ -z "$advisory" ]] && advisory="normal_operation"
    CS_ADVISORY="$advisory"
    echo "$advisory"
}

# =============================================================================
# cs_get_stats - 統計情報をJSON形式で返す
# =============================================================================
cs_get_stats() {
    cat <<EOF
{
  "version": "${CS_VERSION}",
  "total_sessions": ${CS_TOTAL_SESSIONS},
  "domains_seen": ${CS_DOMAINS_SEEN},
  "avg_quality": ${CS_AVG_QUALITY},
  "quality_trend": "${CS_QUALITY_TREND}",
  "common_errors": "${CS_COMMON_ERRORS}",
  "advisory": "${CS_ADVISORY}"
}
EOF
}

# =============================================================================
# cs_save - 分析結果永続化
# =============================================================================
cs_save() {
    [[ -z "$CS_ANALYSIS_FILE" ]] && return 0

    local timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ" 2>/dev/null || date +"%Y-%m-%d")

    cat > "$CS_ANALYSIS_FILE" 2>/dev/null <<EOF
{
  "timestamp": "${timestamp}",
  "version": "${CS_VERSION}",
  "total_sessions": ${CS_TOTAL_SESSIONS},
  "domains_seen": ${CS_DOMAINS_SEEN},
  "avg_quality": ${CS_AVG_QUALITY},
  "quality_trend": "${CS_QUALITY_TREND}",
  "common_errors": "${CS_COMMON_ERRORS}",
  "advisory": "${CS_ADVISORY}"
}
EOF
    return 0
}
