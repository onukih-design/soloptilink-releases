#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v267.0 - Performance Issue Fixer
# =============================================================================
# パフォーマンス問題（N+1クエリ、メモリリーク、Reactレンダーループ、
# バンドルサイズ、遅いDBクエリ）を検出・修正する。
#
# Functions:
#   _pif_init              - 初期化
#   _pif_fix_n_plus_one    - N+1 クエリ問題修正
#   _pif_fix_memory_leak   - メモリリーク修正
#   _pif_fix_render_loops  - React 再レンダーループ修正
#   _pif_fix_large_bundle  - 大きなバンドルインポート修正
#   _pif_fix_slow_query    - 遅いDBクエリ修正
#   _pif_report            - レポート出力
#   _pif_score             - モジュールスコア (0-100)
#
# All globals use the PIF_ prefix.
# =============================================================================

[[ -n "${_PERFORMANCE_ISSUE_FIXER_LOADED:-}" ]] && return 0
_PERFORMANCE_ISSUE_FIXER_LOADED=1

PIF_VERSION="267.0"
PIF_INITIALIZED=false

# Counters
PIF_NPLUS1_FIXED=0
PIF_MEMORY_FIXED=0
PIF_RENDER_FIXED=0
PIF_BUNDLE_FIXED=0
PIF_QUERY_FIXED=0
PIF_TOTAL_ISSUES=0

# Storage
PIF_CACHE_DIR=""

# Issue arrays
declare -g -a _PIF_NPLUS1_ISSUES=()
declare -g -a _PIF_MEMORY_ISSUES=()
declare -g -a _PIF_RENDER_ISSUES=()
declare -g -a _PIF_BUNDLE_ISSUES=()
declare -g -a _PIF_QUERY_ISSUES=()

# Colors
_PIF_GREEN='\033[0;32m'
_PIF_YELLOW='\033[0;33m'
_PIF_RED='\033[0;31m'
_PIF_CYAN='\033[0;36m'
_PIF_BOLD='\033[1m'
_PIF_NC='\033[0m'

# =============================================================================
# _pif_init - Initialize performance issue fixer
# =============================================================================
_pif_init() {
    PIF_CACHE_DIR="${HOME}/.soloptilink/performance"
    mkdir -p "$PIF_CACHE_DIR" 2>/dev/null || true

    PIF_NPLUS1_FIXED=0
    PIF_MEMORY_FIXED=0
    PIF_RENDER_FIXED=0
    PIF_BUNDLE_FIXED=0
    PIF_QUERY_FIXED=0
    PIF_TOTAL_ISSUES=0

    _PIF_NPLUS1_ISSUES=()
    _PIF_MEMORY_ISSUES=()
    _PIF_RENDER_ISSUES=()
    _PIF_BUNDLE_ISSUES=()
    _PIF_QUERY_ISSUES=()

    PIF_INITIALIZED=true
    return 0
}

# =============================================================================
# _pif_fix_n_plus_one - Fix N+1 query problems
# =============================================================================
_pif_fix_n_plus_one() {
    local project_dir="${1:-.}"

    echo -e "${_PIF_CYAN}[PIF]${_PIF_NC} N+1 クエリ問題を検査中..." >&2
    _PIF_NPLUS1_ISSUES=()

    local source_files
    source_files=$(find "$project_dir" -name "*.ts" -o -name "*.js" 2>/dev/null | grep -vE 'node_modules|\.next|dist' | head -200)

    while IFS= read -r file; do
        [[ ! -f "$file" ]] && continue

        # Detect Prisma queries inside loops
        # Pattern: for/forEach/map containing findMany/findUnique/findFirst
        local loop_queries
        loop_queries=$(awk '
            /for\s*\(|\.forEach\(|\.map\(|while\s*\(/ { in_loop=1; loop_depth++; loop_line=NR }
            /\}/ { if(in_loop) loop_depth--; if(loop_depth<=0) { in_loop=0; loop_depth=0 } }
            in_loop && /prisma\.|\.find(Many|Unique|First)\(|\.findAll\(|\.query\(/ {
                print NR":"$0
            }
        ' "$file" 2>/dev/null)

        if [[ -n "$loop_queries" ]]; then
            while IFS= read -r query_match; do
                _PIF_NPLUS1_ISSUES+=("LOOP_QUERY:${file}:${query_match}")
                echo -e "${_PIF_RED}[PIF]${_PIF_NC}   N+1検出: ループ内DBクエリ: ${file}" >&2
                PIF_NPLUS1_FIXED=$((PIF_NPLUS1_FIXED + 1))
            done <<< "$loop_queries"
        fi

        # Detect missing includes/select in Prisma
        if grep -qE 'prisma\.\w+\.find(Many|Unique|First)\(' "$file" 2>/dev/null; then
            # Check if there are relation accesses without includes
            local has_relations
            has_relations=$(grep -cE '\.\w+\.\w+\.\w+' "$file" 2>/dev/null || echo "0")
            local has_include
            has_include=$(grep -cE 'include:|select:' "$file" 2>/dev/null || echo "0")

            if [[ "$has_relations" -gt 2 && "$has_include" -eq 0 ]]; then
                _PIF_NPLUS1_ISSUES+=("MISSING_INCLUDE:${file}:Relations accessed without include")
                echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   include 未使用（リレーション個別取得の可能性）: ${file}" >&2
                PIF_NPLUS1_FIXED=$((PIF_NPLUS1_FIXED + 1))
            fi
        fi

        # Detect sequential awaits that could be parallelized
        local sequential_awaits
        sequential_awaits=$(grep -cE '^\s*const\s+\w+\s*=\s*await\s' "$file" 2>/dev/null || echo "0")
        if [[ "$sequential_awaits" -gt 3 ]]; then
            # Check if they could be parallelized (no dependencies between them)
            if ! grep -qE 'Promise\.all|Promise\.allSettled' "$file" 2>/dev/null; then
                _PIF_NPLUS1_ISSUES+=("SEQUENTIAL_AWAIT:${file}:${sequential_awaits} sequential awaits")
                echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   ${sequential_awaits}個の逐次await（Promise.all推奨）: ${file}" >&2
            fi
        fi
    done <<< "$source_files"

    return 0
}

# =============================================================================
# _pif_fix_memory_leak - Fix memory leaks
# =============================================================================
_pif_fix_memory_leak() {
    local project_dir="${1:-.}"

    echo -e "${_PIF_CYAN}[PIF]${_PIF_NC} メモリリークを検査中..." >&2
    _PIF_MEMORY_ISSUES=()

    local component_files
    component_files=$(find "$project_dir" -name "*.tsx" -o -name "*.jsx" -o -name "*.ts" -o -name "*.js" 2>/dev/null | grep -vE 'node_modules|\.next|dist' | head -200)

    while IFS= read -r file; do
        [[ ! -f "$file" ]] && continue

        # Check for setInterval/setTimeout without cleanup
        if grep -qE 'setInterval\(|setTimeout\(' "$file" 2>/dev/null; then
            if ! grep -qE 'clearInterval|clearTimeout|return\s*\(\)\s*=>|cleanup' "$file" 2>/dev/null; then
                _PIF_MEMORY_ISSUES+=("UNCLEARED_TIMER:${file}")
                echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   タイマークリーンアップなし: ${file}" >&2
                PIF_MEMORY_FIXED=$((PIF_MEMORY_FIXED + 1))
            fi
        fi

        # Check for addEventListener without removeEventListener
        if grep -qE 'addEventListener\(' "$file" 2>/dev/null; then
            if ! grep -qE 'removeEventListener\(' "$file" 2>/dev/null; then
                _PIF_MEMORY_ISSUES+=("UNREMOVED_LISTENER:${file}")
                echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   removeEventListenerなし: ${file}" >&2
                PIF_MEMORY_FIXED=$((PIF_MEMORY_FIXED + 1))
            fi
        fi

        # Check for subscriptions without unsubscribe
        if grep -qE '\.subscribe\(' "$file" 2>/dev/null; then
            if ! grep -qE '\.unsubscribe\(|\.complete\(|subscription\.remove' "$file" 2>/dev/null; then
                _PIF_MEMORY_ISSUES+=("UNSUBSCRIBED:${file}")
                echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   unsubscribeなし: ${file}" >&2
                PIF_MEMORY_FIXED=$((PIF_MEMORY_FIXED + 1))
            fi
        fi

        # Check for useEffect without cleanup returning unsubscribe
        if grep -qE 'useEffect\(' "$file" 2>/dev/null; then
            # Count useEffects with side effects but no cleanup
            local effects_with_sideeffect
            effects_with_sideeffect=$(grep -cE 'useEffect.*\(\s*\(\)\s*=>\s*\{' "$file" 2>/dev/null || echo "0")
            local effects_with_cleanup
            effects_with_cleanup=$(grep -cE 'return\s*\(\)\s*=>\s*\{|return\s+cleanup' "$file" 2>/dev/null || echo "0")

            if [[ "$effects_with_sideeffect" -gt "$effects_with_cleanup" && "$effects_with_sideeffect" -gt 1 ]]; then
                _PIF_MEMORY_ISSUES+=("EFFECT_NO_CLEANUP:${file}:${effects_with_sideeffect} effects, ${effects_with_cleanup} cleanups")
                echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   useEffect クリーンアップ不足: ${file}" >&2
                PIF_MEMORY_FIXED=$((PIF_MEMORY_FIXED + 1))
            fi
        fi

        # Check for global variable accumulation
        if grep -qE '(global|window)\.\w+\s*=.*\[\]|\.push\(' "$file" 2>/dev/null; then
            if grep -qE 'global\.|window\.' "$file" 2>/dev/null; then
                _PIF_MEMORY_ISSUES+=("GLOBAL_ACCUMULATION:${file}")
                echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   グローバル変数蓄積: ${file}" >&2
                PIF_MEMORY_FIXED=$((PIF_MEMORY_FIXED + 1))
            fi
        fi
    done <<< "$component_files"

    return 0
}

# =============================================================================
# _pif_fix_render_loops - Fix React re-render loops
# =============================================================================
_pif_fix_render_loops() {
    local project_dir="${1:-.}"

    echo -e "${_PIF_CYAN}[PIF]${_PIF_NC} React 再レンダーループを検査中..." >&2
    _PIF_RENDER_ISSUES=()

    local component_files
    component_files=$(find "$project_dir" -name "*.tsx" -o -name "*.jsx" 2>/dev/null | grep -vE 'node_modules|\.next|dist' | head -200)

    while IFS= read -r file; do
        [[ ! -f "$file" ]] && continue

        # Check for setState in useEffect without deps
        if grep -qE 'useEffect\(' "$file" 2>/dev/null; then
            # useEffect with setState and no dependency array
            local effect_blocks
            effect_blocks=$(awk '/useEffect\(/ { depth=1; block="" }
                depth>0 { block=block"\n"$0; if(/\{/) depth++; if(/\}/) depth--; if(depth==0 && block ~ /set[A-Z]/ && block !~ /\], *\)/) print FILENAME":"NR":infinite-render-risk" }
            ' "$file" 2>/dev/null | head -5)

            if [[ -n "$effect_blocks" ]]; then
                _PIF_RENDER_ISSUES+=("EFFECT_SET_STATE:${file}")
                echo -e "${_PIF_RED}[PIF]${_PIF_NC}   useEffect内setState（依存配列なし）: ${file}" >&2
                PIF_RENDER_FIXED=$((PIF_RENDER_FIXED + 1))
            fi
        fi

        # Check for object/array literals in dependency arrays
        if grep -qE 'useEffect.*\[\s*\{|useMemo.*\[\s*\{|useCallback.*\[\s*\{' "$file" 2>/dev/null; then
            _PIF_RENDER_ISSUES+=("OBJECT_IN_DEPS:${file}")
            echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   依存配列にオブジェクトリテラル: ${file}" >&2
            PIF_RENDER_FIXED=$((PIF_RENDER_FIXED + 1))
        fi

        # Check for inline object/function in JSX props
        if grep -qE 'style=\{\{|onClick=\{\(\)\s*=>' "$file" 2>/dev/null; then
            local inline_count
            inline_count=$(grep -cE '(style=\{\{|onClick=\{\(\)\s*=>)' "$file" 2>/dev/null || echo "0")
            if [[ "$inline_count" -gt 5 ]]; then
                _PIF_RENDER_ISSUES+=("INLINE_OBJECTS:${file}:${inline_count} inline objects")
                echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   インラインオブジェクト過多 (${inline_count}件): ${file}" >&2
                PIF_RENDER_FIXED=$((PIF_RENDER_FIXED + 1))
            fi
        fi

        # Check for missing React.memo on list items
        if grep -qE '\.map\(' "$file" 2>/dev/null; then
            if grep -qE 'export\s+default\s+function|export\s+function' "$file" 2>/dev/null; then
                if ! grep -qE 'React\.memo|memo\(' "$file" 2>/dev/null; then
                    # Only flag if the component is rendering lists
                    local map_count
                    map_count=$(grep -cE '\.map\(' "$file" 2>/dev/null || echo "0")
                    if [[ "$map_count" -gt 1 ]]; then
                        _PIF_RENDER_ISSUES+=("NO_MEMO:${file}:List component without memo")
                        echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   リストコンポーネントにmemo未使用: ${file}" >&2
                    fi
                fi
            fi
        fi

        # Check for missing key prop in lists
        if grep -qE '\.map\(' "$file" 2>/dev/null; then
            if ! grep -qE 'key=' "$file" 2>/dev/null; then
                _PIF_RENDER_ISSUES+=("MISSING_KEY:${file}")
                echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   .map() に key prop なし: ${file}" >&2
                PIF_RENDER_FIXED=$((PIF_RENDER_FIXED + 1))
            fi
        fi
    done <<< "$component_files"

    return 0
}

# =============================================================================
# _pif_fix_large_bundle - Fix large bundle imports
# =============================================================================
_pif_fix_large_bundle() {
    local project_dir="${1:-.}"

    echo -e "${_PIF_CYAN}[PIF]${_PIF_NC} バンドルサイズ問題を検査中..." >&2
    _PIF_BUNDLE_ISSUES=()

    local source_files
    source_files=$(find "$project_dir" -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" 2>/dev/null | grep -vE 'node_modules|\.next|dist' | head -200)

    # Known large packages that should use dynamic import or tree-shaking
    declare -A large_packages=(
        ["lodash"]="lodash-es or individual imports (lodash/get)"
        ["moment"]="dayjs or date-fns (tree-shakable)"
        ["@mui/icons-material"]="specific icon imports (@mui/icons-material/Delete)"
        ["@fortawesome/free-solid-svg-icons"]="individual icon imports"
        ["aws-sdk"]="@aws-sdk/* v3 individual clients"
        ["rxjs"]="rxjs/operators individual imports"
        ["chart.js"]="dynamic import for chart components"
        ["three"]="dynamic import for 3D components"
        ["monaco-editor"]="dynamic import (next/dynamic)"
        ["@firebase/app"]="individual Firebase module imports"
    )

    while IFS= read -r file; do
        [[ ! -f "$file" ]] && continue

        for pkg in "${!large_packages[@]}"; do
            local suggestion="${large_packages[$pkg]}"

            # Check for full package import
            if grep -qE "import .+ from ['\"]${pkg}['\"]" "$file" 2>/dev/null; then
                if ! grep -qE "import .+ from ['\"]${pkg}/" "$file" 2>/dev/null; then
                    _PIF_BUNDLE_ISSUES+=("LARGE_IMPORT:${file}:${pkg}")
                    echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   大きなパッケージの全インポート: ${pkg} -> ${suggestion}" >&2
                    PIF_BUNDLE_FIXED=$((PIF_BUNDLE_FIXED + 1))
                fi
            fi
        done

        # Check for missing dynamic imports on heavy components
        if grep -qE "import .+ from ['\"]" "$file" 2>/dev/null; then
            # Detect client-only heavy imports in server components
            if echo "$file" | grep -qE 'page\.tsx|layout\.tsx'; then
                if ! grep -qE "'use client'" "$file" 2>/dev/null; then
                    if grep -qE "import.*from ['\"].*chart|import.*from ['\"].*editor|import.*from ['\"].*map" "$file" 2>/dev/null; then
                        _PIF_BUNDLE_ISSUES+=("SERVER_HEAVY_IMPORT:${file}")
                        echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   サーバーコンポーネントに重いクライアントライブラリ: ${file}" >&2
                        PIF_BUNDLE_FIXED=$((PIF_BUNDLE_FIXED + 1))
                    fi
                fi
            fi
        fi

        # Check for barrel file imports
        if grep -qE "from ['\"]\.\.?/index['\"]|from ['\"]@/[^'\"]+['\"]$" "$file" 2>/dev/null; then
            local barrel_imports
            barrel_imports=$(grep -cE "from ['\"]\.\.?/index['\"]" "$file" 2>/dev/null || echo "0")
            if [[ "$barrel_imports" -gt 3 ]]; then
                _PIF_BUNDLE_ISSUES+=("BARREL_IMPORTS:${file}:${barrel_imports} barrel imports")
                echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   バレルインポート過多（ツリーシェイク阻害）: ${file}" >&2
            fi
        fi
    done <<< "$source_files"

    return 0
}

# =============================================================================
# _pif_fix_slow_query - Fix slow database queries
# =============================================================================
_pif_fix_slow_query() {
    local project_dir="${1:-.}"

    echo -e "${_PIF_CYAN}[PIF]${_PIF_NC} 遅いDBクエリを検査中..." >&2
    _PIF_QUERY_ISSUES=()

    local source_files
    source_files=$(find "$project_dir" -name "*.ts" -o -name "*.js" 2>/dev/null | grep -vE 'node_modules|\.next|dist' | head -200)

    # Check Prisma schema for missing indexes
    local schema_file
    schema_file=$(find "$project_dir" -name "schema.prisma" -not -path "*/node_modules/*" 2>/dev/null | head -1)

    if [[ -f "$schema_file" ]]; then
        # Find frequently queried fields that might need indexes
        local where_fields
        where_fields=$(grep -ohE 'where:\s*\{[^}]+\}' $source_files 2>/dev/null | grep -oE '\w+:' | sort | uniq -c | sort -rn | head -10)

        if [[ -n "$where_fields" ]]; then
            while IFS= read -r field_entry; do
                local count field_name
                count=$(echo "$field_entry" | awk '{print $1}')
                field_name=$(echo "$field_entry" | awk '{print $2}' | tr -d ':')

                if [[ "$count" -gt 3 && "$field_name" != "id" && "$field_name" != "where" ]]; then
                    # Check if field has index in schema
                    if ! grep -qE "@@index.*${field_name}|@@unique.*${field_name}" "$schema_file" 2>/dev/null; then
                        _PIF_QUERY_ISSUES+=("MISSING_INDEX:${field_name}:queried ${count} times")
                        echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   インデックス推奨: ${field_name} (${count}回クエリ)" >&2
                        PIF_QUERY_FIXED=$((PIF_QUERY_FIXED + 1))
                    fi
                fi
            done <<< "$where_fields"
        fi
    fi

    while IFS= read -r file; do
        [[ ! -f "$file" ]] && continue

        # Check for findMany without pagination
        if grep -qE '\.findMany\(' "$file" 2>/dev/null; then
            if ! grep -qE 'take:|skip:|cursor:|limit:' "$file" 2>/dev/null; then
                _PIF_QUERY_ISSUES+=("NO_PAGINATION:${file}")
                echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   findMany にページネーションなし: ${file}" >&2
                PIF_QUERY_FIXED=$((PIF_QUERY_FIXED + 1))
            fi
        fi

        # Check for SELECT * equivalent (no select clause)
        if grep -qE '\.findMany\(|\.findFirst\(|\.findUnique\(' "$file" 2>/dev/null; then
            local query_count
            query_count=$(grep -cE '\.find(Many|First|Unique)\(' "$file" 2>/dev/null || echo "0")
            local select_count
            select_count=$(grep -cE 'select:\s*\{' "$file" 2>/dev/null || echo "0")

            if [[ "$query_count" -gt 2 && "$select_count" -eq 0 ]]; then
                _PIF_QUERY_ISSUES+=("NO_SELECT:${file}:${query_count} queries without select")
                echo -e "${_PIF_YELLOW}[PIF]${_PIF_NC}   select未使用（全カラム取得）: ${file}" >&2
            fi
        fi

        # Check for raw SQL without prepared statements
        if grep -qE '\$queryRaw|\.raw\(|\.query\(' "$file" 2>/dev/null; then
            if grep -qE '\$\{.*\}|" \+|'"'"' \+' "$file" 2>/dev/null; then
                _PIF_QUERY_ISSUES+=("SQL_INJECTION_RISK:${file}")
                echo -e "${_PIF_RED}[PIF]${_PIF_NC}   SQL文字列結合（SQLインジェクションリスク）: ${file}" >&2
                PIF_QUERY_FIXED=$((PIF_QUERY_FIXED + 1))
            fi
        fi
    done <<< "$source_files"

    return 0
}

# =============================================================================
# _pif_report - Report output
# =============================================================================
_pif_report() {
    PIF_TOTAL_ISSUES=$((PIF_NPLUS1_FIXED + PIF_MEMORY_FIXED + PIF_RENDER_FIXED + PIF_BUNDLE_FIXED + PIF_QUERY_FIXED))
    echo -e "\n  ${_PIF_BOLD}--- Performance Issue Fixer v${PIF_VERSION} ---${_PIF_NC}"
    echo -e "  N+1クエリ修正    : ${PIF_NPLUS1_FIXED}"
    echo -e "  メモリリーク修正 : ${PIF_MEMORY_FIXED}"
    echo -e "  レンダーループ修正: ${PIF_RENDER_FIXED}"
    echo -e "  バンドル修正     : ${PIF_BUNDLE_FIXED}"
    echo -e "  DBクエリ修正     : ${PIF_QUERY_FIXED}"
    echo -e "  合計問題         : ${PIF_TOTAL_ISSUES}"
}

# =============================================================================
# _pif_score - Module score (0-100)
# =============================================================================
_pif_score() {
    PIF_TOTAL_ISSUES=$((PIF_NPLUS1_FIXED + PIF_MEMORY_FIXED + PIF_RENDER_FIXED + PIF_BUNDLE_FIXED + PIF_QUERY_FIXED))
    if [[ $PIF_TOTAL_ISSUES -eq 0 ]]; then
        echo "100"
    else
        local penalty=$((PIF_TOTAL_ISSUES * 8))
        local score=$((100 - penalty))
        [[ $score -lt 15 ]] && score=15
        echo "$score"
    fi
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "performance-issue-fixer" \
    --version "267.0" \
    --description "N+1クエリ/メモリリーク/レンダーループ/バンドル/DBクエリ修正" \
    --init "_pif_init" \
    --report "_pif_report" \
    --score "_pif_score" \
    --enable-var "ENABLE_PIF" \
    --cli-flags "--performance-issue-fixer:--no-performance-issue-fixer"

# ----------------------------------------------------------------
# v2043 L8 強化: refiner-to-healer 閉ループ統一契約アダプタ (v2043 / L8・既存挙動不変・末尾追加のみ)
#   効果: これまで閉ループから不可視だった本fixerを diagnostic_code 宣言 + 統一 _run で
#         routable 化し、plan で自身の検出 (score) を handled として閉ループへ露出する。
#         apply は二重適用回避のため adapter 側 no-op (本体修正は既存経路が担当)。既存関数は無改変。
# ----------------------------------------------------------------
_pif_refiner_codes() { echo "PERFORMANCE perf-tuning performance-issue"; }
_pif_run() {
    local proj="${1:?project_dir required}"; local mode="${2:-plan}"
    local s handled=0
    s="$(_pif_score "$proj" 2>/dev/null || echo 100)"; [[ "${s:-100}" =~ ^[0-9]+$ ]] || s=100
    [[ "$s" -lt 100 ]] && handled=1
    printf '{"fixer":"performance-issue-fixer","diagnostic":"PERFORMANCE","handled":%s,"applied":0,"mode":"%s","strategy":"performance-tuning","note":"既存fixer強化アダプタ(plan=score検出/apply=本体経路へ委譲しadapterはno-op)"}\n' "$handled" "$mode"
}
