#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v437.0 - Connection Pool Manager
# =============================================================================
# DB接続プール設定の分析・最適化。Prisma/TypeORM/Knex等の接続プール
# 設定を検証し、最適なプールサイズ・タイムアウト設定を提案する。
#
# Functions:
#   _cpm_init()                  - 初期化
#   _cpm_configure_pool()        - プール設定分析
#   _cpm_monitor_connections()   - 接続モニタリング設定
#   _cpm_optimize_size()         - プールサイズ最適化
#   _cpm_report() / _cpm_score()
#
# All globals use the CPM_ prefix.
# =============================================================================

[[ -n "${_CPM_LOADED:-}" ]] && return 0; _CPM_LOADED=1

declare -g CPM_VERSION="437.0"
declare -g CPM_GENERATED=0
declare -g CPM_ERRORS=0
declare -g CPM_ORM_DETECTED=""
declare -g CPM_POOL_CONFIGURED=false
declare -g CPM_POOL_SIZE=0
declare -g CPM_TIMEOUT_MS=0
declare -g CPM_ISSUES=0

declare -ga _CPM_FINDINGS=()

_CPM_GREEN="${GREEN:-\033[0;32m}"
_CPM_RED="${RED:-\033[0;31m}"
_CPM_YELLOW="${YELLOW:-\033[0;33m}"
_CPM_CYAN="${CYAN:-\033[0;36m}"
_CPM_BOLD="${BOLD:-\033[1m}"
_CPM_NC="${NC:-\033[0m}"

_cpm_init() {
    CPM_GENERATED=0; CPM_ERRORS=0; CPM_ORM_DETECTED=""
    CPM_POOL_CONFIGURED=false; CPM_POOL_SIZE=0
    CPM_TIMEOUT_MS=0; CPM_ISSUES=0
    _CPM_FINDINGS=()
    return 0
}

_cpm_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_CPM_CYAN}[CPM]${_CPM_NC} $*" >&2 ;;
        ok)    echo -e "  ${_CPM_GREEN}[CPM]${_CPM_NC} $*" >&2 ;;
        warn)  echo -e "  ${_CPM_YELLOW}[CPM]${_CPM_NC} $*" >&2 ;;
        error) echo -e "  ${_CPM_RED}[CPM]${_CPM_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _cpm_configure_pool - プール設定分析
# =============================================================================
_cpm_configure_pool() {
    local project_dir="${1:-.}"
    _cpm_log info "接続プール設定分析"

    CPM_ORM_DETECTED=""
    CPM_POOL_CONFIGURED=false

    # ORM検出
    if [[ -f "${project_dir}/prisma/schema.prisma" ]] || \
       [[ -n "$(find "$project_dir" -name "schema.prisma" -not -path "*/node_modules/*" 2>/dev/null | head -1)" ]]; then
        CPM_ORM_DETECTED="prisma"
    fi

    local pkg_json="${project_dir}/package.json"
    if [[ -f "$pkg_json" ]]; then
        if grep -q '"typeorm"' "$pkg_json" 2>/dev/null; then
            CPM_ORM_DETECTED="${CPM_ORM_DETECTED:+${CPM_ORM_DETECTED}+}typeorm"
        fi
        if grep -q '"knex"' "$pkg_json" 2>/dev/null; then
            CPM_ORM_DETECTED="${CPM_ORM_DETECTED:+${CPM_ORM_DETECTED}+}knex"
        fi
        if grep -q '"drizzle-orm"' "$pkg_json" 2>/dev/null; then
            CPM_ORM_DETECTED="${CPM_ORM_DETECTED:+${CPM_ORM_DETECTED}+}drizzle"
        fi
        if grep -q '"pg"' "$pkg_json" 2>/dev/null; then
            CPM_ORM_DETECTED="${CPM_ORM_DETECTED:+${CPM_ORM_DETECTED}+}pg"
        fi
    fi

    # Prisma接続プール設定
    if [[ "$CPM_ORM_DETECTED" == *"prisma"* ]]; then
        local schema
        schema=$(find "$project_dir" -name "schema.prisma" -not -path "*/node_modules/*" 2>/dev/null | head -1)
        if [[ -f "$schema" ]]; then
            local pool_setting
            pool_setting=$(grep "connection_limit\|pool_size" "$schema" 2>/dev/null || echo "")
            if [[ -n "$pool_setting" ]]; then
                CPM_POOL_CONFIGURED=true
                _cpm_log ok "Prismaプール設定検出"
            else
                _CPM_FINDINGS+=("PRISMA_POOL:schema.prisma should set connection_limit in url")
                CPM_ISSUES=$((CPM_ISSUES + 1))
            fi
        fi

        # PrismaClient singleton チェック
        local singleton=0
        while IFS= read -r -d '' file; do
            if grep -q "new PrismaClient" "$file" 2>/dev/null; then
                singleton=$((singleton + 1))
            fi
        done < <(find "$project_dir" \( -name "*.ts" -o -name "*.js" \) \
                 -not -path "*/node_modules/*" -print0 2>/dev/null)

        if [[ $singleton -gt 1 ]]; then
            CPM_ISSUES=$((CPM_ISSUES + 1))
            _CPM_FINDINGS+=("PRISMA_SINGLETON:${singleton}x PrismaClient instances - use singleton pattern")
            _cpm_log error "PrismaClientが${singleton}箇所で生成: シングルトン推奨"
        fi
    fi

    # DATABASE_URL チェック
    local env_files=(".env" ".env.local" ".env.production")
    for env_file in "${env_files[@]}"; do
        if [[ -f "${project_dir}/${env_file}" ]]; then
            local db_url
            db_url=$(grep "DATABASE_URL" "${project_dir}/${env_file}" 2>/dev/null || echo "")
            if [[ -n "$db_url" ]]; then
                if [[ "$db_url" == *"connection_limit"* ]]; then
                    CPM_POOL_CONFIGURED=true
                    local limit
                    limit=$(echo "$db_url" | grep -o "connection_limit=[0-9]*" | grep -o "[0-9]*")
                    CPM_POOL_SIZE=${limit:-0}
                    _cpm_log ok "接続プールサイズ: ${CPM_POOL_SIZE}"
                fi

                if [[ "$db_url" == *"pool_timeout"* ]]; then
                    local timeout
                    timeout=$(echo "$db_url" | grep -o "pool_timeout=[0-9]*" | grep -o "[0-9]*")
                    CPM_TIMEOUT_MS=$((${timeout:-10} * 1000))
                fi
            fi
        fi
    done

    CPM_GENERATED=$((CPM_GENERATED + 1))
    _cpm_log ok "ORM検出: ${CPM_ORM_DETECTED:-none}, プール設定: ${CPM_POOL_CONFIGURED}"
    return 0
}

# =============================================================================
# _cpm_monitor_connections - 接続モニタリング設定生成
# =============================================================================
_cpm_monitor_connections() {
    local project_dir="${1:-.}"
    _cpm_log info "接続モニタリング設定"

    # Prismaイベントログ設定推奨
    if [[ "$CPM_ORM_DETECTED" == *"prisma"* ]]; then
        _CPM_FINDINGS+=("PRISMA_LOG:Enable Prisma query logging: log: ['query', 'warn', 'error']")
        _CPM_FINDINGS+=("PRISMA_METRICS:Enable Prisma metrics: previewFeatures = ['metrics']")
    fi

    # pgBouncer推奨
    if [[ "$CPM_ORM_DETECTED" == *"pg"* ]] || [[ "$CPM_ORM_DETECTED" == *"prisma"* ]]; then
        _CPM_FINDINGS+=("PGBOUNCER:Consider pgBouncer for serverless/high-connection environments")
    fi

    CPM_GENERATED=$((CPM_GENERATED + 1))
    return 0
}

# =============================================================================
# _cpm_optimize_size - プールサイズ最適化
# =============================================================================
_cpm_optimize_size() {
    local project_dir="${1:-.}"
    local environment="${2:-production}"
    local cpu_count
    cpu_count=$(nproc 2>/dev/null || sysctl -n hw.ncpu 2>/dev/null || echo 4)

    _cpm_log info "プールサイズ最適化 (CPU: ${cpu_count}, env: ${environment})"

    # プールサイズ推奨計算
    # PostgreSQL推奨: (2 * CPU) + 有効ディスク数
    local recommended_pool=$((cpu_count * 2 + 1))

    # Serverless環境ではプールを小さく
    if [[ -f "${project_dir}/vercel.json" ]] || [[ -f "${project_dir}/netlify.toml" ]]; then
        recommended_pool=5
        _cpm_log info "Serverless環境検出: プールサイズ=${recommended_pool}推奨"
        _CPM_FINDINGS+=("SERVERLESS_POOL:connection_limit=${recommended_pool} for serverless")
    fi

    # Docker環境
    if [[ -f "${project_dir}/Dockerfile" ]]; then
        recommended_pool=$((cpu_count * 2))
        _CPM_FINDINGS+=("DOCKER_POOL:connection_limit=${recommended_pool} for containerized deployment")
    fi

    if [[ $CPM_POOL_SIZE -gt 0 ]] && [[ $CPM_POOL_SIZE -gt $((recommended_pool * 2)) ]]; then
        CPM_ISSUES=$((CPM_ISSUES + 1))
        _CPM_FINDINGS+=("POOL_TOO_LARGE:current=${CPM_POOL_SIZE} recommended=${recommended_pool}")
        _cpm_log warn "プールサイズ過大: ${CPM_POOL_SIZE} → ${recommended_pool}推奨"
    fi

    # タイムアウト推奨
    local recommended_timeout=10000  # 10秒
    if [[ $CPM_TIMEOUT_MS -gt 30000 ]]; then
        CPM_ISSUES=$((CPM_ISSUES + 1))
        _CPM_FINDINGS+=("TIMEOUT_TOO_LONG:current=${CPM_TIMEOUT_MS}ms recommended=${recommended_timeout}ms")
    fi

    CPM_GENERATED=$((CPM_GENERATED + 1))
    _cpm_log ok "推奨プールサイズ: ${recommended_pool}, タイムアウト: ${recommended_timeout}ms"

    echo "${recommended_pool}"
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_cpm_report() {
    echo -e "\n  ${_CPM_BOLD}=== connection-pool-manager v${CPM_VERSION} ===${_CPM_NC}"
    echo -e "  ORM             : ${CPM_ORM_DETECTED:-none}"
    echo -e "  プール設定      : ${CPM_POOL_CONFIGURED}"
    echo -e "  プールサイズ    : ${CPM_POOL_SIZE}"
    echo -e "  タイムアウト    : ${CPM_TIMEOUT_MS}ms"
    echo -e "  問題            : ${CPM_ISSUES}"
    echo -e "  エラー          : ${CPM_ERRORS}"
}

_cpm_score() {
    local score=50
    [[ -n "$CPM_ORM_DETECTED" ]] && score=$((score + 10))
    [[ "$CPM_POOL_CONFIGURED" == "true" ]] && score=$((score + 15))
    [[ ${CPM_ISSUES} -eq 0 ]] && score=$((score + 15))
    [[ ${CPM_ERRORS} -eq 0 ]] && score=$((score + 10))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "connection-pool-manager" --version "${CPM_VERSION}" \
        --description "接続プール管理×Prisma/ORM最適化×サイズ調整 (v437)" \
        --init "_cpm_init" --report "_cpm_report" --score "_cpm_score" \
        --enable-var "ENABLE_CONN_POOL" --cli-flags "--conn-pool:--no-conn-pool"
fi

# v2003.1: source時のexit codeを確実に0にする
true
