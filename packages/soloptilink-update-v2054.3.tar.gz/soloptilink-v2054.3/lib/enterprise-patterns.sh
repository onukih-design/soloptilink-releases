#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v31.0 - Enterprise Patterns Engine
# =============================================================================
# Generates battle-tested, production-grade code templates from domain JSON.
# Instead of telling Claude "implement CRUD", we GIVE Claude working reference
# implementations and say "follow this exact pattern for all models."
#
# Core Principle: "参照実装を渡してパターン統一 → 無駄なコード排出ゼロ"
#
# Template Categories:
#   1. API Route Templates     - zod validation + Prisma CRUD + error handling
#   2. Service Layer Templates - transactions + audit logging + business logic
#   3. React CRUD Templates    - useSWR + React Hook Form + DataTable + Dialog
#   4. Error Boundary          - React error boundary + global error handler
#   5. Middleware Templates    - auth + rate limiting + CORS + request logging
#   6. Prisma Client          - singleton + connection pooling
#   7. Compliance Patterns    - HIPAA/GDPR/PCI-DSS specific patterns
#
# Functions:
#   ep_init                          - Initialize with tech stack
#   ep_generate_api_route_template   - API route reference implementation
#   ep_generate_service_template     - Service layer with transactions
#   ep_generate_react_crud_template  - React CRUD page template
#   ep_generate_error_boundary       - Error boundary pattern
#   ep_generate_middleware_template   - Middleware stack
#   ep_generate_prisma_client        - Prisma client singleton
#   ep_generate_all_templates        - Generate full reference implementation
#   ep_inject_into_prompt            - Inject patterns into Claude prompt
#
# All globals use the EP_ prefix.
# =============================================================================

[[ -n "${_ENTERPRISE_PATTERNS_LOADED:-}" ]] && return 0
_ENTERPRISE_PATTERNS_LOADED=1

# ============================================================
# State
# ============================================================
declare -g EP_VERSION="31.0"
declare -g EP_TECH_STACK="nextjs"
declare -g EP_DOMAIN=""
declare -g EP_FIRST_MODEL=""
declare -g EP_FIRST_MODEL_FIELDS=""
declare -g EP_PROJECT_DIR=""
declare -g EP_TEMPLATE_DIR=""
declare -g EP_TEMPLATES_GENERATED="false"

# Enterprise anti-patterns (extends existing PC_ANTI_PATTERNS)
declare -g -a EP_ANTI_PATTERNS=(
    "トランザクションなしの複数テーブル書き込み禁止"
    "エラーバウンダリなしのページコンポーネント禁止"
    "try-catchなしのasync関数禁止"
    "ハードコードされたシークレット禁止（環境変数を使用）"
    "入力バリデーションなしのAPIエンドポイント禁止"
    "監査ログなしのデータ変更操作禁止"
    "リトライロジックなしの外部API呼び出し禁止"
    "型安全でないAPIレスポンス禁止（型定義必須）"
    "エラーメッセージにスタックトレース露出禁止"
    "N+1クエリパターン禁止（includeまたはjoin使用）"
    "Force unwrap (!) 禁止（guard let/if let を使用）"
    "Force try (try!) 禁止（do-catch を使用）"
    "メインスレッドでの重い処理禁止（async/await + Task を使用）"
    "循環参照禁止（[weak self] を使用）"
    "Implicitly Unwrapped Optional 禁止（lazy var または optional を使用）"
)

# ============================================================
# Internal logger
# ============================================================
_ep_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    [[ "$level" == "SUCCESS" ]] && color="${GREEN:-}"
    echo -e "  ${color}[ENT-PATTERNS]${NC:-} ${msg}" >&2
}

# ============================================================
# Initialize enterprise patterns engine
# ============================================================
ep_init() {
    local tech_stack="${1:-nextjs}"
    local domain="${2:-}"
    local project_dir="${3:-${PROJECT_DIR:-}}"

    EP_TECH_STACK="$tech_stack"
    EP_DOMAIN="$domain"
    EP_PROJECT_DIR="$project_dir"
    EP_TEMPLATES_GENERATED="false"

    local work_dir="${SESSION_LOG_DIR:-/tmp}/enterprise_patterns"
    mkdir -p "$work_dir" 2>/dev/null || true
    EP_TEMPLATE_DIR="$work_dir"

    _ep_log "SUCCESS" "Enterprise Patterns v31.0 初期化: stack=${tech_stack}, domain=${domain}"
    return 0
}

# ============================================================
# Extract first model from domain JSON for reference implementation
# ============================================================
_ep_extract_first_model() {
    local domain="${1:-${EP_DOMAIN}}"
    local domain_file="${PROJECT_DIR:-${HOME}/.soloptilink}/domains/${domain}.json"

    [[ ! -f "$domain_file" ]] && return 1

    local result
    result=$(python3 -c "
import json, sys
# R3: DBL models は dict {Name:{fields:dict}}(101辞書)と list [{name,fields:list|dict|strlist}]
# (8辞書)の両形式が混在する。両型を (name, spec) / (fname, ftype) へ正規化して吸収し、
# list 形式辞書で models.items()/fields.items() が AttributeError を起こし汎用テンプレへ
# 劣化していたのを解消する。
def model_items(m):
    if isinstance(m, dict):
        return list(m.items())
    if isinstance(m, list):
        out = []
        for x in m:
            if isinstance(x, dict):
                nm = x.get('name') or x.get('model') or x.get('title')
                if nm:
                    out.append((nm, x))
        return out
    return []
def field_items(fields):
    # -> [(fname, ftype)] を dict / list[{name,type}] / 素の文字列list から抽出
    out = []
    if isinstance(fields, dict):
        for fn, fs in fields.items():
            out.append((fn, fs.get('type', 'String') if isinstance(fs, dict) else 'String'))
    elif isinstance(fields, list):
        for f in fields:
            if isinstance(f, dict) and f.get('name'):
                out.append((f['name'], f.get('type', 'String')))
            elif isinstance(f, str) and f:
                out.append((f, 'String'))
    return out
try:
    with open('${domain_file}') as f:
        data = json.load(f)
    models = data.get('models', {})
    if not models:
        sys.exit(1)
    # Get first model (skip User/base models)
    for name, spec in model_items(models):
        if name in ('User', 'Session', 'AuditLog'):
            continue
        if not isinstance(spec, dict):
            continue
        field_list = []
        for fname, ftype in field_items(spec.get('fields', {})):
            field_list.append(f'{fname}:{ftype}')
        # Get search fields
        search_fields = spec.get('search_fields', [])
        # Get relations (belongsTo|hasMany 形式 / many-to-one 等の list 形式の両方に対応)
        relations = spec.get('relations', [])
        rel_list = []
        for r in relations:
            if not isinstance(r, dict):
                continue
            rmodel = r.get('model', '')
            rfield = r.get('field', '') or (rmodel[:1].lower() + rmodel[1:] if rmodel else '')
            rel_list.append(f\"{rfield}:{rmodel}:{r.get('type','')}\")
        print(f'MODEL_NAME={name}')
        print(f'FIELDS={\"|\".join(field_list)}')
        print(f'SEARCH_FIELDS={\"|\".join(search_fields)}')
        print(f'RELATIONS={\"|\".join(rel_list)}')
        break
except Exception as e:
    sys.exit(1)
" 2>/dev/null)

    [[ -z "$result" ]] && return 1

    EP_FIRST_MODEL=$(echo "$result" | grep "^MODEL_NAME=" | cut -d= -f2)
    EP_FIRST_MODEL_FIELDS=$(echo "$result" | grep "^FIELDS=" | cut -d= -f2-)

    return 0
}

# ============================================================
# Generate: API Route Template (Next.js App Router)
# ============================================================
ep_generate_api_route_template() {
    local model_name="${1:-${EP_FIRST_MODEL:-Item}}"
    local model_lower
    model_lower=$(echo "$model_name" | sed 's/\(.\)/\L\1/')  # first letter lowercase
    local model_plural="${model_lower}s"
    local route_path="src/app/api/${model_plural}"

    # Parse fields to generate zod schema
    local fields_str="${2:-${EP_FIRST_MODEL_FIELDS:-id:String|name:String|createdAt:DateTime}}"
    local zod_fields=""
    local prisma_select=""

    IFS='|' read -ra field_arr <<< "$fields_str"
    for field_def in "${field_arr[@]}"; do
        local fname="${field_def%%:*}"
        local ftype="${field_def#*:}"
        # Skip auto fields
        [[ "$fname" == "id" || "$fname" == "createdAt" || "$fname" == "updatedAt" ]] && continue

        local optional=""
        [[ "$ftype" == *"?" ]] && optional=".optional()" && ftype="${ftype%?}"

        local zod_type
        case "$ftype" in
            String)   zod_type="z.string()${optional}" ;;
            Int)      zod_type="z.number().int()${optional}" ;;
            Float)    zod_type="z.number()${optional}" ;;
            Boolean)  zod_type="z.boolean()${optional}" ;;
            DateTime) zod_type="z.string().datetime()${optional}" ;;
            *)        zod_type="z.string()${optional}" ;;
        esac

        zod_fields+="    ${fname}: ${zod_type},
"
    done

    cat << 'TEMPLATE_EOF'
// ============================================================
// REFERENCE IMPLEMENTATION: API Route Pattern
// Follow this EXACT pattern for all models.
// ============================================================

// --- FILE: ROUTE_PATH/route.ts ---
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

// Input validation schema (zodで全入力を検証)
const createSCHEMA_NAMESchema = z.object({
ZOD_FIELDS});

const updateSCHEMA_NAMESchema = createSCHEMA_NAMESchema.partial();

// Standard API response type
type ApiResponse<T> = {
  success: boolean;
  data?: T;
  error?: string;
  pagination?: { page: number; limit: number; total: number; totalPages: number };
};

// GET: List with pagination, search, sort
export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url);
    const page = Math.max(1, parseInt(searchParams.get('page') || '1'));
    const limit = Math.min(100, Math.max(1, parseInt(searchParams.get('limit') || '20')));
    const search = searchParams.get('search') || '';
    const sortBy = searchParams.get('sortBy') || 'createdAt';
    const sortOrder = searchParams.get('sortOrder') === 'asc' ? 'asc' : 'desc';

    const where = search
      ? { OR: [/* SEARCH_FIELDS mapped to contains */ ] }
      : {};

    const [items, total] = await Promise.all([
      prisma.MODEL_LOWER.findMany({
        where,
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { [sortBy]: sortOrder },
        include: { /* RELATIONS */ },
      }),
      prisma.MODEL_LOWER.count({ where }),
    ]);

    return NextResponse.json({
      success: true,
      data: items,
      pagination: { page, limit, total, totalPages: Math.ceil(total / limit) },
    } satisfies ApiResponse<typeof items>);
  } catch (error) {
    console.error('[API] GET /api/MODEL_PLURAL error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' } satisfies ApiResponse<never>,
      { status: 500 }
    );
  }
}

// POST: Create with validation + audit
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const validated = createSCHEMA_NAMESchema.parse(body);

    const item = await prisma.$transaction(async (tx) => {
      const created = await tx.MODEL_LOWER.create({ data: validated });
      // Audit log
      await tx.auditLog.create({
        data: {
          action: 'CREATE',
          entity: 'MODEL_NAME',
          entityId: created.id,
          changes: JSON.stringify(validated),
          timestamp: new Date(),
        },
      }).catch(() => {}); // Audit failure should not block operation
      return created;
    });

    return NextResponse.json(
      { success: true, data: item } satisfies ApiResponse<typeof item>,
      { status: 201 }
    );
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: error.errors.map(e => e.message).join(', ') },
        { status: 400 }
      );
    }
    console.error('[API] POST /api/MODEL_PLURAL error:', error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
TEMPLATE_EOF

    # Replace placeholders
    local template
    template=$(cat << 'TEMPLATE_EOF'
// --- FILE: ROUTE_PATH/[id]/route.ts ---
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { z } from 'zod';

const updateSchema = z.object({
ZOD_FIELDS}).partial();

// GET: Single item by ID
export async function GET(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const item = await prisma.MODEL_LOWER.findUnique({
      where: { id: params.id },
      include: { /* RELATIONS */ },
    });

    if (!item) {
      return NextResponse.json(
        { success: false, error: 'Not found' },
        { status: 404 }
      );
    }

    return NextResponse.json({ success: true, data: item });
  } catch (error) {
    console.error(`[API] GET /api/MODEL_PLURAL/${params.id} error:`, error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// PUT: Update with validation + audit
export async function PUT(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    const body = await request.json();
    const validated = updateSchema.parse(body);

    const item = await prisma.$transaction(async (tx) => {
      const before = await tx.MODEL_LOWER.findUnique({ where: { id: params.id } });
      if (!before) throw new Error('Not found');

      const updated = await tx.MODEL_LOWER.update({
        where: { id: params.id },
        data: validated,
      });

      await tx.auditLog.create({
        data: {
          action: 'UPDATE',
          entity: 'MODEL_NAME',
          entityId: params.id,
          changes: JSON.stringify({ before, after: validated }),
          timestamp: new Date(),
        },
      }).catch(() => {});

      return updated;
    });

    return NextResponse.json({ success: true, data: item });
  } catch (error) {
    if (error instanceof z.ZodError) {
      return NextResponse.json(
        { success: false, error: error.errors.map(e => e.message).join(', ') },
        { status: 400 }
      );
    }
    if (error instanceof Error && error.message === 'Not found') {
      return NextResponse.json({ success: false, error: 'Not found' }, { status: 404 });
    }
    console.error(`[API] PUT /api/MODEL_PLURAL/${params.id} error:`, error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}

// DELETE: Soft delete + audit + confirmation
export async function DELETE(
  request: NextRequest,
  { params }: { params: { id: string } }
) {
  try {
    await prisma.$transaction(async (tx) => {
      const item = await tx.MODEL_LOWER.findUnique({ where: { id: params.id } });
      if (!item) throw new Error('Not found');

      await tx.MODEL_LOWER.delete({ where: { id: params.id } });

      await tx.auditLog.create({
        data: {
          action: 'DELETE',
          entity: 'MODEL_NAME',
          entityId: params.id,
          changes: JSON.stringify(item),
          timestamp: new Date(),
        },
      }).catch(() => {});
    });

    return NextResponse.json({ success: true, data: null });
  } catch (error) {
    if (error instanceof Error && error.message === 'Not found') {
      return NextResponse.json({ success: false, error: 'Not found' }, { status: 404 });
    }
    console.error(`[API] DELETE /api/MODEL_PLURAL/${params.id} error:`, error);
    return NextResponse.json(
      { success: false, error: 'Internal server error' },
      { status: 500 }
    );
  }
}
TEMPLATE_EOF
)

    echo "$template"
}

# ============================================================
# Generate: Service Layer Template
# ============================================================
ep_generate_service_template() {
    local model_name="${1:-${EP_FIRST_MODEL:-Item}}"
    local model_lower
    model_lower=$(echo "$model_name" | sed 's/\(.\)/\L\1/')

    cat << TEMPLATE_EOF
// ============================================================
// REFERENCE IMPLEMENTATION: Service Layer Pattern
// All business logic MUST go through service layer, NOT in API routes.
// ============================================================

// --- FILE: src/lib/services/${model_lower}-service.ts ---
import { prisma } from '@/lib/prisma';
import { Prisma } from '@prisma/client';

export class ${model_name}Service {
  /**
   * Create with transaction + audit
   */
  async create(data: Prisma.${model_name}CreateInput, userId?: string) {
    return prisma.\$transaction(async (tx) => {
      const item = await tx.${model_lower}.create({ data });

      await tx.auditLog.create({
        data: {
          action: 'CREATE',
          entity: '${model_name}',
          entityId: item.id,
          userId: userId || 'system',
          changes: JSON.stringify(data),
          timestamp: new Date(),
        },
      }).catch(() => {});

      return item;
    });
  }

  /**
   * Find with pagination + search
   */
  async findMany(params: {
    page?: number;
    limit?: number;
    search?: string;
    sortBy?: string;
    sortOrder?: 'asc' | 'desc';
    where?: Prisma.${model_name}WhereInput;
  }) {
    const { page = 1, limit = 20, search, sortBy = 'createdAt', sortOrder = 'desc', where = {} } = params;

    const [items, total] = await Promise.all([
      prisma.${model_lower}.findMany({
        where,
        skip: (page - 1) * limit,
        take: limit,
        orderBy: { [sortBy]: sortOrder },
      }),
      prisma.${model_lower}.count({ where }),
    ]);

    return { items, total, page, limit, totalPages: Math.ceil(total / limit) };
  }

  /**
   * Update with optimistic locking + audit
   */
  async update(id: string, data: Prisma.${model_name}UpdateInput, userId?: string) {
    return prisma.\$transaction(async (tx) => {
      const before = await tx.${model_lower}.findUniqueOrThrow({ where: { id } });
      const updated = await tx.${model_lower}.update({ where: { id }, data });

      await tx.auditLog.create({
        data: {
          action: 'UPDATE',
          entity: '${model_name}',
          entityId: id,
          userId: userId || 'system',
          changes: JSON.stringify({ before, after: data }),
          timestamp: new Date(),
        },
      }).catch(() => {});

      return updated;
    });
  }

  /**
   * Delete with cascade safety + audit
   */
  async delete(id: string, userId?: string) {
    return prisma.\$transaction(async (tx) => {
      const item = await tx.${model_lower}.findUniqueOrThrow({ where: { id } });
      await tx.${model_lower}.delete({ where: { id } });

      await tx.auditLog.create({
        data: {
          action: 'DELETE',
          entity: '${model_name}',
          entityId: id,
          userId: userId || 'system',
          changes: JSON.stringify(item),
          timestamp: new Date(),
        },
      }).catch(() => {});

      return item;
    });
  }
}

export const ${model_lower}Service = new ${model_name}Service();
TEMPLATE_EOF
}

# ============================================================
# Generate: React CRUD Page Template
# ============================================================
ep_generate_react_crud_template() {
    local model_name="${1:-${EP_FIRST_MODEL:-Item}}"
    local model_lower
    model_lower=$(echo "$model_name" | sed 's/\(.\)/\L\1/')
    local model_plural="${model_lower}s"

    cat << TEMPLATE_EOF
// ============================================================
// REFERENCE IMPLEMENTATION: React CRUD Page Pattern
// useSWR for data fetching, React Hook Form + zod for forms,
// Dialog for create/edit, AlertDialog for delete confirmation.
// ============================================================

// --- FILE: src/app/${model_plural}/page.tsx ---
'use client';

import { useState } from 'react';
import useSWR from 'swr';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { toast } from 'sonner';

// Type-safe API client
const fetcher = (url: string) => fetch(url).then(r => r.json());

const ${model_lower}Schema = z.object({
  // Generated from domain JSON fields
  name: z.string().min(1, '必須項目です'),
});

type ${model_name}Input = z.infer<typeof ${model_lower}Schema>;

export default function ${model_name}Page() {
  const [page, setPage] = useState(1);
  const [search, setSearch] = useState('');
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isCreateOpen, setIsCreateOpen] = useState(false);
  const [deleteTarget, setDeleteTarget] = useState<string | null>(null);

  // Data fetching with SWR (auto-revalidation)
  const { data, error, isLoading, mutate } = useSWR(
    \`/api/${model_plural}?page=\${page}&search=\${search}&limit=20\`,
    fetcher,
    { keepPreviousData: true }
  );

  const form = useForm<${model_name}Input>({
    resolver: zodResolver(${model_lower}Schema),
    defaultValues: {},
  });

  // Create
  const handleCreate = async (values: ${model_name}Input) => {
    try {
      const res = await fetch('/api/${model_plural}', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values),
      });
      const result = await res.json();
      if (!result.success) throw new Error(result.error);
      toast.success('${model_name}を作成しました');
      setIsCreateOpen(false);
      form.reset();
      mutate(); // Revalidate data
    } catch (err) {
      toast.error(err instanceof Error ? err.message : '作成に失敗しました');
    }
  };

  // Update
  const handleUpdate = async (id: string, values: Partial<${model_name}Input>) => {
    try {
      const res = await fetch(\`/api/${model_plural}/\${id}\`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(values),
      });
      const result = await res.json();
      if (!result.success) throw new Error(result.error);
      toast.success('${model_name}を更新しました');
      setEditingId(null);
      mutate();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : '更新に失敗しました');
    }
  };

  // Delete with confirmation
  const handleDelete = async () => {
    if (!deleteTarget) return;
    try {
      const res = await fetch(\`/api/${model_plural}/\${deleteTarget}\`, {
        method: 'DELETE',
      });
      const result = await res.json();
      if (!result.success) throw new Error(result.error);
      toast.success('${model_name}を削除しました');
      setDeleteTarget(null);
      mutate();
    } catch (err) {
      toast.error(err instanceof Error ? err.message : '削除に失敗しました');
    }
  };

  if (error) return <div className="p-8 text-red-500">Error: {error.message}</div>;

  return (
    <div className="p-8 max-w-7xl mx-auto">
      {/* Header + Search + Create Button */}
      {/* Data Table with sort/pagination */}
      {/* Create/Edit Dialog */}
      {/* Delete Confirmation AlertDialog */}
    </div>
  );
}
TEMPLATE_EOF
}

# ============================================================
# Generate: Prisma Client Singleton
# ============================================================
ep_generate_prisma_client() {
    cat << 'TEMPLATE_EOF'
// ============================================================
// REFERENCE IMPLEMENTATION: Prisma Client Singleton
// MUST use this pattern. Never instantiate PrismaClient directly.
// ============================================================

// --- FILE: src/lib/prisma.ts ---
import { PrismaClient } from '@prisma/client';

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined;
};

export const prisma = globalForPrisma.prisma ?? new PrismaClient({
  log: process.env.NODE_ENV === 'development'
    ? ['query', 'error', 'warn']
    : ['error'],
});

if (process.env.NODE_ENV !== 'production') {
  globalForPrisma.prisma = prisma;
}
TEMPLATE_EOF
}

# ============================================================
# Generate: Error Boundary
# ============================================================
ep_generate_error_boundary() {
    cat << 'TEMPLATE_EOF'
// ============================================================
// REFERENCE IMPLEMENTATION: Error Boundary Pattern
// Every page MUST be wrapped in an error boundary.
// ============================================================

// --- FILE: src/app/error.tsx ---
'use client';

import { useEffect } from 'react';

export default function ErrorPage({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    // Log to error reporting service (never expose stack trace to user)
    console.error('[ErrorBoundary]', error.digest || error.message);
  }, [error]);

  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="text-center space-y-4">
        <h2 className="text-2xl font-bold">Something went wrong</h2>
        <p className="text-muted-foreground">
          An unexpected error occurred. Please try again.
        </p>
        <button
          onClick={reset}
          className="px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90"
        >
          Try again
        </button>
      </div>
    </div>
  );
}

// --- FILE: src/app/not-found.tsx ---
import Link from 'next/link';

export default function NotFound() {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="text-center space-y-4">
        <h2 className="text-2xl font-bold">Page Not Found</h2>
        <p className="text-muted-foreground">
          The page you are looking for does not exist.
        </p>
        <Link
          href="/"
          className="inline-block px-4 py-2 bg-primary text-primary-foreground rounded-md hover:bg-primary/90"
        >
          Go Home
        </Link>
      </div>
    </div>
  );
}
TEMPLATE_EOF
}

# ============================================================
# Generate: Middleware Template
# ============================================================
ep_generate_middleware_template() {
    cat << 'TEMPLATE_EOF'
// ============================================================
// REFERENCE IMPLEMENTATION: Middleware Stack
// Auth + Rate Limiting + Request Logging + CORS
// ============================================================

// --- FILE: src/middleware.ts ---
import { NextResponse } from 'next/server';
import type { NextRequest } from 'next/server';

// Simple in-memory rate limiter (use Redis in production)
const rateLimitMap = new Map<string, { count: number; resetTime: number }>();
const RATE_LIMIT = 100; // requests per minute
const RATE_WINDOW = 60 * 1000; // 1 minute in ms

function rateLimit(ip: string): boolean {
  const now = Date.now();
  const record = rateLimitMap.get(ip);

  if (!record || now > record.resetTime) {
    rateLimitMap.set(ip, { count: 1, resetTime: now + RATE_WINDOW });
    return true;
  }

  if (record.count >= RATE_LIMIT) return false;
  record.count++;
  return true;
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // Skip static assets
  if (pathname.startsWith('/_next') || pathname.startsWith('/favicon')) {
    return NextResponse.next();
  }

  // Rate limiting for API routes
  if (pathname.startsWith('/api/')) {
    const ip = request.headers.get('x-forwarded-for') || 'unknown';
    if (!rateLimit(ip)) {
      return NextResponse.json(
        { success: false, error: 'Too many requests' },
        { status: 429, headers: { 'Retry-After': '60' } }
      );
    }
  }

  // Request logging
  const start = Date.now();
  const response = NextResponse.next();

  // Security headers
  response.headers.set('X-Content-Type-Options', 'nosniff');
  response.headers.set('X-Frame-Options', 'DENY');
  response.headers.set('X-XSS-Protection', '1; mode=block');
  response.headers.set('Referrer-Policy', 'strict-origin-when-cross-origin');

  return response;
}

export const config = {
  matcher: ['/((?!_next/static|_next/image|favicon.ico).*)'],
};
TEMPLATE_EOF
}

# ============================================================
# Generate: iOS Repository Template (CoreData + Protocol)
# ============================================================
ep_generate_ios_repository_template() {
    local model_name="${1:-${EP_FIRST_MODEL:-Item}}"
    local model_lower
    model_lower=$(echo "$model_name" | sed 's/\(.\)/\L\1/')

    cat << TEMPLATE_EOF
// ============================================================
// REFERENCE IMPLEMENTATION: iOS Repository Pattern
// Protocol-oriented repository with CoreData implementation.
// All data access MUST go through repository layer.
// ============================================================

// --- FILE: Sources/Repositories/${model_name}Repository.swift ---
import Foundation
import CoreData

// MARK: - Repository Protocol
protocol ${model_name}RepositoryProtocol {
    func fetchAll() async throws -> [${model_name}]
    func fetchById(_ id: UUID) async throws -> ${model_name}?
    func create(_ input: ${model_name}Input) async throws -> ${model_name}
    func update(_ id: UUID, _ input: ${model_name}Input) async throws -> ${model_name}
    func delete(_ id: UUID) async throws
    func search(query: String) async throws -> [${model_name}]
}

// MARK: - CoreData Implementation
@MainActor
final class ${model_name}Repository: ${model_name}RepositoryProtocol {
    private let context: NSManagedObjectContext

    init(context: NSManagedObjectContext = PersistenceController.shared.container.viewContext) {
        self.context = context
    }

    func fetchAll() async throws -> [${model_name}] {
        let request = ${model_name}Entity.fetchRequest()
        request.sortDescriptors = [NSSortDescriptor(keyPath: \\${model_name}Entity.createdAt, ascending: false)]
        let entities = try context.fetch(request)
        return entities.map { \$0.toDomain() }
    }

    func fetchById(_ id: UUID) async throws -> ${model_name}? {
        let request = ${model_name}Entity.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@", id as CVarArg)
        request.fetchLimit = 1
        guard let entity = try context.fetch(request).first else { return nil }
        return entity.toDomain()
    }

    func create(_ input: ${model_name}Input) async throws -> ${model_name} {
        let entity = ${model_name}Entity(context: context)
        entity.id = UUID()
        entity.createdAt = Date()
        entity.updatedAt = Date()
        input.apply(to: entity)
        try context.save()
        return entity.toDomain()
    }

    func update(_ id: UUID, _ input: ${model_name}Input) async throws -> ${model_name} {
        let request = ${model_name}Entity.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@", id as CVarArg)
        request.fetchLimit = 1
        guard let entity = try context.fetch(request).first else {
            throw RepositoryError.notFound(entity: "${model_name}", id: id)
        }
        input.apply(to: entity)
        entity.updatedAt = Date()
        try context.save()
        return entity.toDomain()
    }

    func delete(_ id: UUID) async throws {
        let request = ${model_name}Entity.fetchRequest()
        request.predicate = NSPredicate(format: "id == %@", id as CVarArg)
        request.fetchLimit = 1
        guard let entity = try context.fetch(request).first else {
            throw RepositoryError.notFound(entity: "${model_name}", id: id)
        }
        context.delete(entity)
        try context.save()
    }

    func search(query: String) async throws -> [${model_name}] {
        let request = ${model_name}Entity.fetchRequest()
        request.predicate = NSPredicate(format: "name CONTAINS[cd] %@", query)
        request.sortDescriptors = [NSSortDescriptor(keyPath: \\${model_name}Entity.createdAt, ascending: false)]
        let entities = try context.fetch(request)
        return entities.map { \$0.toDomain() }
    }
}

// MARK: - Repository Error
enum RepositoryError: LocalizedError {
    case notFound(entity: String, id: UUID)
    case saveFailed(underlying: Error)

    var errorDescription: String? {
        switch self {
        case .notFound(let entity, let id):
            return "\(entity) not found: \(id)"
        case .saveFailed(let error):
            return "Save failed: \(error.localizedDescription)"
        }
    }
}
TEMPLATE_EOF
}

# ============================================================
# Generate: iOS ViewModel Template (MVVM + async/await)
# ============================================================
ep_generate_ios_viewmodel_template() {
    local model_name="${1:-${EP_FIRST_MODEL:-Item}}"
    local model_lower
    model_lower=$(echo "$model_name" | sed 's/\(.\)/\L\1/')
    local model_plural="${model_lower}s"

    cat << TEMPLATE_EOF
// ============================================================
// REFERENCE IMPLEMENTATION: iOS MVVM ViewModel Pattern
// @Published properties, async/await, Task, proper error state.
// Follow this EXACT pattern for all ViewModels.
// ============================================================

// --- FILE: Sources/ViewModels/${model_name}ViewModel.swift ---
import Foundation
import Combine

@MainActor
final class ${model_name}ViewModel: ObservableObject {
    // MARK: - Published State
    @Published private(set) var ${model_plural}: [${model_name}] = []
    @Published private(set) var isLoading = false
    @Published private(set) var error: AppError?
    @Published var searchQuery = ""
    @Published var selectedItem: ${model_name}?
    @Published var showingCreateSheet = false
    @Published var showingDeleteConfirmation = false
    @Published var itemToDelete: ${model_name}?

    // MARK: - Dependencies
    private let repository: ${model_name}RepositoryProtocol

    // MARK: - Init
    init(repository: ${model_name}RepositoryProtocol = ${model_name}Repository()) {
        self.repository = repository
    }

    // MARK: - CRUD Operations

    func fetchAll() {
        Task { [weak self] in
            guard let self else { return }
            self.isLoading = true
            self.error = nil
            do {
                self.${model_plural} = try await self.repository.fetchAll()
            } catch {
                self.error = AppError.from(error)
            }
            self.isLoading = false
        }
    }

    func create(_ input: ${model_name}Input) {
        Task { [weak self] in
            guard let self else { return }
            self.isLoading = true
            self.error = nil
            do {
                let created = try await self.repository.create(input)
                self.${model_plural}.insert(created, at: 0)
                self.showingCreateSheet = false
            } catch {
                self.error = AppError.from(error)
            }
            self.isLoading = false
        }
    }

    func update(_ id: UUID, _ input: ${model_name}Input) {
        Task { [weak self] in
            guard let self else { return }
            self.isLoading = true
            self.error = nil
            do {
                let updated = try await self.repository.update(id, input)
                if let index = self.${model_plural}.firstIndex(where: { \$0.id == id }) {
                    self.${model_plural}[index] = updated
                }
                self.selectedItem = nil
            } catch {
                self.error = AppError.from(error)
            }
            self.isLoading = false
        }
    }

    func confirmDelete(_ item: ${model_name}) {
        self.itemToDelete = item
        self.showingDeleteConfirmation = true
    }

    func deleteConfirmed() {
        guard let item = itemToDelete else { return }
        Task { [weak self] in
            guard let self else { return }
            self.isLoading = true
            self.error = nil
            do {
                try await self.repository.delete(item.id)
                self.${model_plural}.removeAll { \$0.id == item.id }
                self.itemToDelete = nil
                self.showingDeleteConfirmation = false
            } catch {
                self.error = AppError.from(error)
            }
            self.isLoading = false
        }
    }

    func search() {
        guard !searchQuery.isEmpty else {
            fetchAll()
            return
        }
        Task { [weak self] in
            guard let self else { return }
            self.isLoading = true
            self.error = nil
            do {
                self.${model_plural} = try await self.repository.search(query: self.searchQuery)
            } catch {
                self.error = AppError.from(error)
            }
            self.isLoading = false
        }
    }
}

// MARK: - App Error
enum AppError: LocalizedError, Identifiable {
    case network(String)
    case repository(String)
    case validation(String)
    case unknown(String)

    var id: String { errorDescription ?? "unknown" }

    var errorDescription: String? {
        switch self {
        case .network(let msg): return msg
        case .repository(let msg): return msg
        case .validation(let msg): return msg
        case .unknown(let msg): return msg
        }
    }

    static func from(_ error: Error) -> AppError {
        if let repoError = error as? RepositoryError {
            return .repository(repoError.localizedDescription)
        }
        return .unknown(error.localizedDescription)
    }
}
TEMPLATE_EOF
}

# ============================================================
# Generate: iOS SwiftUI View Template (List/Detail/Create/Edit/Delete)
# ============================================================
ep_generate_ios_view_template() {
    local model_name="${1:-${EP_FIRST_MODEL:-Item}}"
    local model_lower
    model_lower=$(echo "$model_name" | sed 's/\(.\)/\L\1/')
    local model_plural="${model_lower}s"

    cat << TEMPLATE_EOF
// ============================================================
// REFERENCE IMPLEMENTATION: SwiftUI CRUD View Pattern
// List + Detail + Create + Edit + Delete with confirmation.
// Follow this EXACT pattern for all model views.
// ============================================================

// --- FILE: Sources/Views/${model_name}ListView.swift ---
import SwiftUI

struct ${model_name}ListView: View {
    @StateObject private var viewModel = ${model_name}ViewModel()

    var body: some View {
        NavigationStack {
            Group {
                if viewModel.isLoading && viewModel.${model_plural}.isEmpty {
                    ProgressView("読み込み中...")
                } else if viewModel.${model_plural}.isEmpty {
                    ContentUnavailableView(
                        "${model_name}がありません",
                        systemImage: "tray",
                        description: Text("新しい${model_name}を作成してください")
                    )
                } else {
                    List {
                        ForEach(viewModel.${model_plural}) { item in
                            NavigationLink(value: item) {
                                ${model_name}RowView(item: item)
                            }
                            .swipeActions(edge: .trailing, allowsFullSwipe: false) {
                                Button(role: .destructive) {
                                    viewModel.confirmDelete(item)
                                } label: {
                                    Label("削除", systemImage: "trash")
                                }
                            }
                        }
                    }
                    .searchable(text: \$viewModel.searchQuery, prompt: "検索...")
                    .onSubmit(of: .search) { viewModel.search() }
                    .refreshable { viewModel.fetchAll() }
                }
            }
            .navigationTitle("${model_name}一覧")
            .navigationDestination(for: ${model_name}.self) { item in
                ${model_name}DetailView(item: item, viewModel: viewModel)
            }
            .toolbar {
                ToolbarItem(placement: .primaryAction) {
                    Button {
                        viewModel.showingCreateSheet = true
                    } label: {
                        Image(systemName: "plus")
                    }
                }
            }
            .sheet(isPresented: \$viewModel.showingCreateSheet) {
                ${model_name}CreateView(viewModel: viewModel)
            }
            .alert("削除確認", isPresented: \$viewModel.showingDeleteConfirmation) {
                Button("キャンセル", role: .cancel) {}
                Button("削除", role: .destructive) {
                    viewModel.deleteConfirmed()
                }
            } message: {
                Text("この${model_name}を削除しますか？この操作は取り消せません。")
            }
            .alert(item: \$viewModel.error) { error in
                Button("OK") { viewModel.error = nil }
            } message: { error in
                Text(error.localizedDescription)
            }
        }
        .onAppear { viewModel.fetchAll() }
    }
}

// --- FILE: Sources/Views/${model_name}RowView.swift ---
struct ${model_name}RowView: View {
    let item: ${model_name}

    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(item.name)
                .font(.headline)
            Text(item.createdAt, style: .date)
                .font(.caption)
                .foregroundStyle(.secondary)
        }
        .padding(.vertical, 4)
    }
}

// --- FILE: Sources/Views/${model_name}DetailView.swift ---
struct ${model_name}DetailView: View {
    let item: ${model_name}
    @ObservedObject var viewModel: ${model_name}ViewModel
    @State private var isEditing = false

    var body: some View {
        Form {
            Section("基本情報") {
                LabeledContent("名前", value: item.name)
                LabeledContent("作成日", value: item.createdAt, format: .dateTime)
                LabeledContent("更新日", value: item.updatedAt, format: .dateTime)
            }
        }
        .navigationTitle(item.name)
        .toolbar {
            ToolbarItem(placement: .primaryAction) {
                Button("編集") { isEditing = true }
            }
        }
        .sheet(isPresented: \$isEditing) {
            ${model_name}EditView(item: item, viewModel: viewModel)
        }
    }
}

// --- FILE: Sources/Views/${model_name}CreateView.swift ---
struct ${model_name}CreateView: View {
    @ObservedObject var viewModel: ${model_name}ViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var name = ""

    var body: some View {
        NavigationStack {
            Form {
                Section("新規${model_name}") {
                    TextField("名前", text: \$name)
                }
            }
            .navigationTitle("${model_name}作成")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("キャンセル") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        let input = ${model_name}Input(name: name)
                        viewModel.create(input)
                    }
                    .disabled(name.isEmpty)
                }
            }
        }
    }
}

// --- FILE: Sources/Views/${model_name}EditView.swift ---
struct ${model_name}EditView: View {
    let item: ${model_name}
    @ObservedObject var viewModel: ${model_name}ViewModel
    @Environment(\.dismiss) private var dismiss
    @State private var name: String

    init(item: ${model_name}, viewModel: ${model_name}ViewModel) {
        self.item = item
        self.viewModel = viewModel
        _name = State(initialValue: item.name)
    }

    var body: some View {
        NavigationStack {
            Form {
                Section("${model_name}を編集") {
                    TextField("名前", text: \$name)
                }
            }
            .navigationTitle("${model_name}編集")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .cancellationAction) {
                    Button("キャンセル") { dismiss() }
                }
                ToolbarItem(placement: .confirmationAction) {
                    Button("保存") {
                        let input = ${model_name}Input(name: name)
                        viewModel.update(item.id, input)
                        dismiss()
                    }
                    .disabled(name.isEmpty)
                }
            }
        }
    }
}
TEMPLATE_EOF
}

# ============================================================
# Generate ALL templates as a combined reference
# ============================================================
ep_generate_all_templates() {
    local domain="${1:-${EP_DOMAIN}}"
    local output_file="${EP_TEMPLATE_DIR}/reference_implementation.md"

    # Extract first model from domain
    _ep_extract_first_model "$domain"

    {
        echo "# Enterprise Reference Implementation (v31.0)"
        echo ""
        echo "## CRITICAL INSTRUCTIONS"
        echo "以下の参照実装に厳密に従ってください。"

        # Tech-stack-specific critical instructions
        if [[ "${EP_TECH_STACK}" == "ios-swiftui" || "${EP_TECH_STACK}" == "ios-uikit" ]]; then
            echo "- MVVM アーキテクチャに厳密に従う（View → ViewModel → Repository）"
            echo "- 全データアクセスは Repository Protocol 経由"
            echo "- async/await + Task で非同期処理（コールバック地獄禁止）"
            echo "- エラーは AppError 型で統一管理し、ユーザーに適切に表示"
            echo "- [weak self] で循環参照を防止"
        else
            echo "- APIレスポンス形式: { success: boolean, data?: T, error?: string, pagination?: {...} }"
            echo "- 全書き込みはトランザクション内で実行"
            echo "- 全入力はzodでバリデーション"
            echo "- エラーは適切にcatchし、スタックトレースをクライアントに露出しない"
            echo "- 監査ログは操作と同一トランザクション内で記録"
        fi

        echo ""
        echo "## Enterprise Anti-Patterns (これらは絶対禁止)"
        local i=1
        for pattern in "${EP_ANTI_PATTERNS[@]}"; do
            echo "${i}. ${pattern}"
            i=$((i + 1))
        done
        echo ""
        echo "---"
        echo ""

        # Tech-stack branching for template generation
        if [[ "${EP_TECH_STACK}" == "ios-swiftui" || "${EP_TECH_STACK}" == "ios-uikit" ]]; then
            # iOS templates
            echo "## 1. Repository Pattern (${EP_FIRST_MODEL:-Model})"
            ep_generate_ios_repository_template "${EP_FIRST_MODEL:-Item}"
            echo ""
            echo "---"
            echo ""
            echo "## 2. ViewModel Pattern (${EP_FIRST_MODEL:-Model})"
            ep_generate_ios_viewmodel_template "${EP_FIRST_MODEL:-Item}"
            echo ""
            echo "---"
            echo ""
            echo "## 3. SwiftUI View Pattern (${EP_FIRST_MODEL:-Model})"
            ep_generate_ios_view_template "${EP_FIRST_MODEL:-Item}"
        else
            # Next.js templates (default)
            echo "## 1. Prisma Client (必須パターン)"
            ep_generate_prisma_client
            echo ""
            echo "---"
            echo ""
            echo "## 2. API Route Pattern (${EP_FIRST_MODEL:-Model})"
            ep_generate_api_route_template "${EP_FIRST_MODEL:-Item}" "${EP_FIRST_MODEL_FIELDS:-}"
            echo ""
            echo "---"
            echo ""
            echo "## 3. Service Layer Pattern (${EP_FIRST_MODEL:-Model})"
            ep_generate_service_template "${EP_FIRST_MODEL:-Item}"
            echo ""
            echo "---"
            echo ""
            echo "## 4. React CRUD Page Pattern (${EP_FIRST_MODEL:-Model})"
            ep_generate_react_crud_template "${EP_FIRST_MODEL:-Item}"
            echo ""
            echo "---"
            echo ""
            echo "## 5. Error Boundary"
            ep_generate_error_boundary
            echo ""
            echo "---"
            echo ""
            echo "## 6. Middleware Stack"
            ep_generate_middleware_template
        fi
    } > "$output_file" 2>/dev/null

    EP_TEMPLATES_GENERATED="true"
    _ep_log "SUCCESS" "参照実装生成完了: ${output_file} ($(wc -c < "$output_file" 2>/dev/null || echo 0) bytes)"

    echo "$output_file"
    return 0
}

# ============================================================
# Inject enterprise patterns into Claude prompt
# ============================================================
ep_inject_into_prompt() {
    local prompt="${1:-}"
    local domain="${2:-${EP_DOMAIN}}"
    local tech_stack="${3:-${EP_TECH_STACK:-nextjs}}"

    # Only for supported stacks (Next.js, iOS SwiftUI, iOS UIKit)
    [[ "$tech_stack" != "nextjs" && "$tech_stack" != "ios-swiftui" && "$tech_stack" != "ios-uikit" ]] && echo "$prompt" && return 0

    # Generate templates if not done yet
    if [[ "${EP_TEMPLATES_GENERATED}" != "true" ]]; then
        ep_generate_all_templates "$domain" > /dev/null 2>&1
    fi

    local ref_file="${EP_TEMPLATE_DIR}/reference_implementation.md"
    if [[ ! -f "$ref_file" ]]; then
        echo "$prompt"
        return 0
    fi

    local ref_content
    ref_content=$(cat "$ref_file" 2>/dev/null)

    # Inject reference implementation between domain knowledge and constraints
    local injection=""
    injection+="

=== ENTERPRISE REFERENCE IMPLEMENTATION (v31.0) ===
上記の参照実装パターンに厳密に従い、全モデルに同じパターンを適用してください。

${ref_content}

=== END REFERENCE IMPLEMENTATION ===

"
    echo "${prompt}${injection}"
    return 0
}

# ============================================================
# Get enterprise anti-patterns as string (for prompt compiler)
# ============================================================
ep_get_anti_patterns() {
    local result=""
    local i=1
    for pattern in "${EP_ANTI_PATTERNS[@]}"; do
        result+="${i}. ${pattern}\n"
        i=$((i + 1))
    done
    echo -e "$result"
}
