#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v54.0 - Dashboard Connector (ダッシュボード連携)
# =============================================================================
# chain.sh のセッション実行データをAdmin Dashboardに送信するコネクター。
# ダッシュボードが起動していない場合はサイレントスキップ（影響なし）。
#
# v54.0: 初版 - Admin Dashboard連携
#
# Functions:
#   dc_init              - コネクター初期化・接続テスト
#   dc_session_start     - セッション開始をAPIに通知
#   dc_phase_update      - フェーズ進捗をAPIに送信
#   dc_metric_record     - メトリクス（コスト、品質スコア等）を送信
#   dc_session_complete  - セッション完了通知
#   dc_is_connected      - ダッシュボード接続確認
#   dc_report            - コネクターレポート出力
#
# All globals use the DC_ prefix. Private functions use _dc_ prefix.
# =============================================================================

[[ -n "${_DASHBOARD_CONNECTOR_LOADED:-}" ]] && return 0
_DASHBOARD_CONNECTOR_LOADED=1

# State variables
declare -g DC_VERSION="54.0"
declare -g DC_ENABLED="false"
declare -g DC_BASE_URL=""
declare -g DC_SESSION_ID=""
declare -g DC_CONNECTED="false"
declare -g DC_API_TOKEN=""
declare -g DC_REQUESTS_SENT=0
declare -g DC_REQUESTS_FAILED=0
declare -g DC_LAST_ERROR=""

# =============================================================================
# Internal logger
# =============================================================================
_dc_log() {
    local level="$1" msg="$2" color="${CYAN:-}"
    [[ "$level" == "WARN" ]] && color="${YELLOW:-}"
    [[ "$level" == "ERROR" ]] && color="${RED:-}"
    [[ "$level" == "SUCCESS" ]] && color="${GREEN:-}"
    echo -e "  ${color}[DASH-CONN]${NC:-} ${msg}" >&2
}

# =============================================================================
# _dc_scrub_payload - 送信前 機密スクラブ (PFP-104 / 2026-06-11)
# =============================================================================
# 全送信ペイロードをチョークポイントでスクラブする。呼び出し元に委譲しない。
# 将来の呼び出し元が自由文 (エラー文/プロンプト断片) を載せても、APIキー/
# JWT/DB接続文字列/秘密鍵/カード番号等が平文で外部送信されることはない。
# pii-mask.sh が読めない環境では原文を出さずフェイルクローズ ({} に置換)。
# =============================================================================
_dc_scrub_payload() {
    local body="${1:-{}}"
    if ! declare -F pii_mask_secrets &>/dev/null; then
        local _sl_dir="${SOLOPTILINK_DIR:-$HOME/.soloptilink}"
        if [[ -f "$_sl_dir/lib/security/pii-mask.sh" ]]; then
            # shellcheck source=/dev/null
            source "$_sl_dir/lib/security/pii-mask.sh"
        fi
    fi
    if declare -F pii_mask_secrets &>/dev/null; then
        pii_mask_secrets "$body"
    else
        # フェイルクローズ: スクラブ不能なペイロードは送らない
        echo -n '{"redacted":"PII_MASK_UNAVAILABLE"}'
    fi
}

# =============================================================================
# _dc_post - Internal HTTP helper
# =============================================================================
# Usage: _dc_post <endpoint> <json_body> [method]
# Returns 0 on 2xx, 1 otherwise. Increments failure counter on error.
# All network errors are silently absorbed to never break the pipeline.
# =============================================================================
_dc_post() {
    local endpoint="${1:-}" json_body="${2:-{}}" method="${3:-POST}"

    # Guard: if not connected or curl not available, silently skip
    [[ "${DC_CONNECTED}" != "true" ]] && return 1
    command -v curl &>/dev/null || return 1

    # PFP-104: 送信前 機密スクラブ (チョークポイント強制)
    json_body=$(_dc_scrub_payload "$json_body")

    local url="${DC_BASE_URL}${endpoint}"
    local -a curl_args=(
        -s
        -X "$method"
        -H "Content-Type: application/json"
        --max-time 5
        -w "%{http_code}"
        -o /dev/null
    )

    # Add Authorization header if token is set
    if [[ -n "${DC_API_TOKEN}" ]]; then
        curl_args+=(-H "Authorization: Bearer ${DC_API_TOKEN}")
    fi

    curl_args+=(-d "$json_body")

    local http_code
    http_code=$(curl "${curl_args[@]}" "$url" 2>/dev/null || echo "000")

    DC_REQUESTS_SENT=$((DC_REQUESTS_SENT + 1))

    # Check for 2xx status
    case "$http_code" in
        2[0-9][0-9])
            return 0
            ;;
        *)
            DC_REQUESTS_FAILED=$((DC_REQUESTS_FAILED + 1))
            DC_LAST_ERROR="HTTP ${http_code} on ${method} ${endpoint}"
            return 1
            ;;
    esac
}

# =============================================================================
# _dc_post_with_response - Internal HTTP helper that captures response body
# =============================================================================
# Usage: _dc_post_with_response <endpoint> <json_body> [method]
# Prints response body to stdout. Returns 0 on 2xx, 1 otherwise.
# =============================================================================
_dc_post_with_response() {
    local endpoint="${1:-}" json_body="${2:-{}}" method="${3:-POST}"

    [[ "${DC_CONNECTED}" != "true" ]] && return 1
    command -v curl &>/dev/null || return 1

    # PFP-104: 送信前 機密スクラブ (チョークポイント強制)
    json_body=$(_dc_scrub_payload "$json_body")

    local url="${DC_BASE_URL}${endpoint}"
    local tmp_file
    tmp_file=$(mktemp 2>/dev/null || echo "/tmp/dc_resp_$$")

    local -a curl_args=(
        -s
        -X "$method"
        -H "Content-Type: application/json"
        --max-time 5
        -w "%{http_code}"
        -o "$tmp_file"
    )

    if [[ -n "${DC_API_TOKEN}" ]]; then
        curl_args+=(-H "Authorization: Bearer ${DC_API_TOKEN}")
    fi

    curl_args+=(-d "$json_body")

    local http_code
    http_code=$(curl "${curl_args[@]}" "$url" 2>/dev/null || echo "000")

    DC_REQUESTS_SENT=$((DC_REQUESTS_SENT + 1))

    local body=""
    [[ -f "$tmp_file" ]] && body=$(cat "$tmp_file" 2>/dev/null || echo "")
    rm -f "$tmp_file" 2>/dev/null || true

    case "$http_code" in
        2[0-9][0-9])
            echo "$body"
            return 0
            ;;
        *)
            DC_REQUESTS_FAILED=$((DC_REQUESTS_FAILED + 1))
            DC_LAST_ERROR="HTTP ${http_code} on ${method} ${endpoint}"
            return 1
            ;;
    esac
}

# =============================================================================
# dc_init - コネクター初期化・接続テスト
# =============================================================================
# Usage: dc_init [dashboard_url]
# Tests connection to the admin dashboard health endpoint.
# Sets DC_CONNECTED=true if the dashboard is reachable.
# If not reachable, silently continues (no error output to user).
# =============================================================================
dc_init() {
    local dashboard_url="${1:-${DASHBOARD_URL:-http://localhost:3000}}"

    DC_BASE_URL="${dashboard_url}"
    DC_CONNECTED="false"
    DC_ENABLED="false"
    DC_REQUESTS_SENT=0
    DC_REQUESTS_FAILED=0
    DC_LAST_ERROR=""
    DC_SESSION_ID=""

    # Store API token from environment if available
    if [[ -n "${API_TOKEN:-}" ]]; then
        DC_API_TOKEN="${API_TOKEN}"
    fi

    # Test connection with short timeout - silently skip if not available
    if ! command -v curl &>/dev/null; then
        return 0
    fi

    local http_code
    http_code=$(curl -s -o /dev/null -w "%{http_code}" --max-time 2 \
        "${DC_BASE_URL}/api/health" 2>/dev/null || echo "000")

    case "$http_code" in
        2[0-9][0-9])
            DC_CONNECTED="true"
            DC_ENABLED="true"
            _dc_log "SUCCESS" "Dashboard Connector v${DC_VERSION} 接続成功: ${DC_BASE_URL}"
            ;;
        *)
            # Silent - dashboard not running is a normal condition
            DC_CONNECTED="false"
            DC_ENABLED="false"
            ;;
    esac

    return 0
}

# =============================================================================
# dc_session_start - セッション開始をAPIに通知
# =============================================================================
# Usage: dc_session_start <trace_id> <project_name> <domain> <pipeline> <model_tier> <budget>
# POSTs session data to the admin dashboard API.
# Stores the returned session ID in DC_SESSION_ID.
# On failure, logs error silently and continues.
# =============================================================================
dc_session_start() {
    local trace_id="${1:-${SESSION_ID:-unknown}}"
    local project_name="${2:-unknown}"
    local domain="${3:-general}"
    local pipeline="${4:-full}"
    local model_tier="${5:-auto}"
    local budget="${6:-10.00}"

    [[ "${DC_CONNECTED}" != "true" ]] && return 0

    local timestamp
    timestamp=$(date -u '+%Y-%m-%dT%H:%M:%SZ' 2>/dev/null || date +%s)

    local json_body
    json_body=$(cat <<EOJSON
{
  "traceId": "${trace_id}",
  "projectName": "${project_name}",
  "domain": "${domain}",
  "pipeline": "${pipeline}",
  "modelTier": "${model_tier}",
  "budget": "${budget}",
  "startedAt": "${timestamp}",
  "status": "RUNNING"
}
EOJSON
)

    local response
    response=$(_dc_post_with_response "/api/v1/admin/sessions" "$json_body" "POST") || {
        _dc_log "WARN" "セッション開始通知失敗 (続行)"
        return 0
    }

    # Extract session ID from response JSON (best-effort parsing)
    local returned_id
    returned_id=$(echo "$response" | grep -o '"id"[[:space:]]*:[[:space:]]*"[^"]*"' | head -1 | sed 's/.*"id"[[:space:]]*:[[:space:]]*"\([^"]*\)".*/\1/' 2>/dev/null || echo "")

    if [[ -n "$returned_id" ]]; then
        DC_SESSION_ID="$returned_id"
    else
        # Fallback: use trace_id as session reference
        DC_SESSION_ID="$trace_id"
    fi

    _dc_log "SUCCESS" "セッション開始通知完了: ${DC_SESSION_ID}"
    return 0
}

# =============================================================================
# dc_phase_update - フェーズ進捗をAPIに送信
# =============================================================================
# Usage: dc_phase_update <phase_name> <status> [agent_name] [cost] [duration]
# Status: PENDING, RUNNING, COMPLETED, FAILED
# POSTs phase data to the admin dashboard API.
# =============================================================================
dc_phase_update() {
    local phase_name="${1:-unknown}"
    local status="${2:-RUNNING}"
    local agent_name="${3:-system}"
    local cost="${4:-0.00}"
    local duration="${5:-0}"

    [[ "${DC_CONNECTED}" != "true" ]] && return 0
    [[ -z "${DC_SESSION_ID}" ]] && return 0

    local timestamp
    timestamp=$(date -u '+%Y-%m-%dT%H:%M:%SZ' 2>/dev/null || date +%s)

    local json_body
    json_body=$(cat <<EOJSON
{
  "phaseName": "${phase_name}",
  "status": "${status}",
  "agentName": "${agent_name}",
  "cost": "${cost}",
  "duration": ${duration},
  "timestamp": "${timestamp}"
}
EOJSON
)

    _dc_post "/api/v1/admin/sessions/${DC_SESSION_ID}/phases" "$json_body" "POST" || true
    return 0
}

# =============================================================================
# dc_metric_record - メトリクス（コスト、品質スコア等）を送信
# =============================================================================
# Usage: dc_metric_record <key> <value>
# POSTs metric data to the admin dashboard API.
# =============================================================================
dc_metric_record() {
    local key="${1:-}" value="${2:-}"

    [[ "${DC_CONNECTED}" != "true" ]] && return 0
    [[ -z "${DC_SESSION_ID}" ]] && return 0
    [[ -z "${key}" ]] && return 0

    local timestamp
    timestamp=$(date -u '+%Y-%m-%dT%H:%M:%SZ' 2>/dev/null || date +%s)

    local json_body
    json_body=$(cat <<EOJSON
{
  "key": "${key}",
  "value": "${value}",
  "timestamp": "${timestamp}"
}
EOJSON
)

    _dc_post "/api/v1/admin/sessions/${DC_SESSION_ID}/metrics" "$json_body" "POST" || true
    return 0
}

# =============================================================================
# dc_session_complete - セッション完了通知
# =============================================================================
# Usage: dc_session_complete <status> [quality_score] [total_cost] [error_count]
# Status: COMPLETED, FAILED, CANCELLED
# PATCHes the session record on the admin dashboard.
# =============================================================================
dc_session_complete() {
    local status="${1:-COMPLETED}"
    local quality_score="${2:-0}"
    local total_cost="${3:-0.00}"
    local error_count="${4:-0}"

    [[ "${DC_CONNECTED}" != "true" ]] && return 0
    [[ -z "${DC_SESSION_ID}" ]] && return 0

    local timestamp
    timestamp=$(date -u '+%Y-%m-%dT%H:%M:%SZ' 2>/dev/null || date +%s)

    local json_body
    json_body=$(cat <<EOJSON
{
  "status": "${status}",
  "qualityScore": ${quality_score},
  "totalCost": "${total_cost}",
  "errorCount": ${error_count},
  "completedAt": "${timestamp}"
}
EOJSON
)

    _dc_post "/api/v1/admin/sessions/${DC_SESSION_ID}" "$json_body" "PATCH" || true

    if [[ "${DC_CONNECTED}" == "true" ]]; then
        _dc_log "SUCCESS" "セッション完了通知: ${status} (品質=${quality_score}, コスト=\$${total_cost})"
    fi

    return 0
}

# =============================================================================
# dc_is_connected - ダッシュボード接続確認
# =============================================================================
# Returns 0 if connected, 1 otherwise.
# =============================================================================
dc_is_connected() {
    [[ "${DC_CONNECTED}" == "true" ]] && return 0
    return 1
}

# =============================================================================
# dc_report - コネクターレポート出力
# =============================================================================
# Prints summary of requests sent, failed, and last error.
# =============================================================================
dc_report() {
    echo ""
    echo -e "  ${BOLD:-}${CYAN:-}[Dashboard Connector Summary] v${DC_VERSION}${NC:-}"
    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    echo -e "  Dashboard URL     : ${DC_BASE_URL:-not set}"
    echo -e "  Connected         : ${DC_CONNECTED}"
    echo -e "  Enabled           : ${DC_ENABLED}"
    echo -e "  Session ID        : ${DC_SESSION_ID:-none}"
    echo -e "  Requests Sent     : ${DC_REQUESTS_SENT}"
    echo -e "  Requests Failed   : ${DC_REQUESTS_FAILED}"
    if [[ -n "${DC_LAST_ERROR}" ]]; then
        echo -e "  Last Error        : ${DC_LAST_ERROR}"
    fi
    local success_rate="100"
    if [[ "${DC_REQUESTS_SENT}" -gt 0 ]]; then
        local successful=$((DC_REQUESTS_SENT - DC_REQUESTS_FAILED))
        success_rate=$(( (successful * 100) / DC_REQUESTS_SENT ))
    fi
    echo -e "  Success Rate      : ${success_rate}%"
    echo -e "  ${BOLD:-}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC:-}"
    echo ""
}
