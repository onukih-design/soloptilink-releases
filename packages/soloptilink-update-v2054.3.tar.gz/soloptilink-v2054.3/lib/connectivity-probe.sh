#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2037.x - Connectivity Probe (実動作確認)
# =============================================================================
# 「繋いだ後に本当に動くか」を構造的に確かめる。
#  - 無料・鍵不要(live_testable) → 実APIを叩いて応答を検証(本物の動作確認)
#  - 鍵/OAuthが要る           → 鍵設定の有無を確認し、設定済なら実呼び出し、
#                                未設定なら「鍵設定後に押すだけ」の接続テスト手順を提示
# 相手企業の繋ぎ方(IBL辞書の endpoints/verification)を実体参照して検証する。
#
# Functions:
#   cp_init / cp_probe <connector> [project_dir] / cp_probe_free_all / cp_report / cp_score
# (c) 2026 SoloptiLink Inc. - 営業秘密 / 著作権法・不正競争防止法で保護
# =============================================================================
[[ -n "${_CONNECTIVITY_PROBE_LOADED:-}" ]] && return 0
_CONNECTIVITY_PROBE_LOADED=1

declare -g CPB_VERSION="1.0"
declare -g CPB_IBL="${HOME}/.soloptilink/integrations"
declare -g CPB_PROBE_COUNT=0

cp_init() { return 0; }

# 単一コネクタの実動作確認 (JSON結果)
cp_probe() {
    local conn="$1"; local project="${2:-}"
    local f="${CPB_IBL}/${conn}.json"
    [[ ! -f "$f" ]] && { echo "{\"connector\":\"$conn\",\"verdict\":\"unknown_connector\"}"; return 1; }
    CPB_PROBE_COUNT=$((CPB_PROBE_COUNT + 1))
    CONN_FILE="$f" PROJECT="$project" python3 - <<'PY'
import json, os, sys, urllib.request, urllib.error

f = os.environ["CONN_FILE"]; project = os.environ.get("PROJECT", "")
d = json.load(open(f, encoding="utf-8"))
conn = d["connector"]; c = d.get("connectivity", {}) or {}
res = {"connector": conn, "display_name": d.get("display_name", conn), "verdict": "", "detail_ja": ""}

# 1) 無料・鍵不要なら実APIで本物の動作確認
probe = c.get("live_probe")
if c.get("live_testable") and probe:
    url = probe.get("url"); expect = probe.get("expect", "")
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "SoloptiLinkAI-ConnectivityProbe/1.0"})
        with urllib.request.urlopen(req, timeout=10) as r:
            body = r.read(8000).decode("utf-8", "replace")
            status = r.status
        if status == 200 and (not expect or expect in body):
            res["verdict"] = "LIVE_OK"
            res["detail_ja"] = f"実APIを呼び出し、正しい応答(『{expect}』を含む)を確認しました。本当に繋がって動いています。"
            res["http_status"] = status
        else:
            res["verdict"] = "LIVE_UNEXPECTED"
            res["detail_ja"] = f"応答は得られましたが期待値『{expect}』が見つかりません(status={status})。仕様変更の可能性。"
    except Exception as e:
        res["verdict"] = "LIVE_FAIL"
        res["detail_ja"] = f"実API呼び出しに失敗しました: {e}"
    print(json.dumps(res, ensure_ascii=False)); raise SystemExit(0)

# 2) 鍵/OAuthが要るコネクタ: 環境変数の設定状況で分岐
envs = [v.get("name") for v in d.get("env_vars", []) if v.get("required")] or [v.get("name") for v in d.get("env_vars", [])]
set_env = [e for e in envs if e and os.environ.get(e)]
# プロジェクトの .env も確認
env_in_project = False
if project:
    for envf in (os.path.join(project, ".env"), os.path.join(project, ".env.local")):
        if os.path.exists(envf):
            txt = open(envf, encoding="utf-8", errors="replace").read()
            if any(e and (e + "=") in txt and not txt.split(e + "=", 1)[1].lstrip().startswith(("\n", "")) for e in envs):
                env_in_project = True
if set_env or env_in_project:
    res["verdict"] = "READY_TO_TEST"
    res["detail_ja"] = "認証情報が設定されています。生成された接続テスト(/api/integrations/<conn>/test または設定画面の『接続テスト』ボタン)を実行すると実呼び出しで疎通確認できます。"
else:
    tier = c.get("cost_tier", "")
    res["verdict"] = "NEEDS_CREDENTIALS"
    res["detail_ja"] = (f"連携コードは生成済みです。動作させるには認証情報({', '.join(e for e in envs if e)})を設定してください。"
                        + ("(このサービスは契約・申請が前提です)" if tier == "partner-gated" else "(設定後、設定画面の『接続テスト』で疎通確認できます)"))
res["required_env"] = [e for e in envs if e]
res["cost_tier"] = c.get("cost_tier")
print(json.dumps(res, ensure_ascii=False))
PY
}

# 無料・鍵不要の全コネクタを実APIで動作確認(本物の証拠)
cp_probe_free_all() {
    local any=0
    for f in "$CPB_IBL"/*.json; do
        local b; b=$(basename "$f" .json); [[ "$b" == _* ]] && continue
        local live; live=$(python3 -c "import json;print(json.load(open('$f')).get('connectivity',{}).get('live_testable',False))" 2>/dev/null)
        [[ "$live" != "True" ]] && continue
        any=1
        cp_probe "$b" | python3 -c "import sys,json;d=json.load(sys.stdin);print(f\"  [{d['verdict']}] {d['display_name']}: {d['detail_ja']}\")" 2>/dev/null
    done
    [[ "$any" == "0" ]] && echo "  (実APIで検証可能な無料コネクタがありません)"
}

cp_report() {
    echo -e "\n  ${BOLD:-}=== Connectivity Probe v${CPB_VERSION} ===${NC:-}"
    echo -e "  実動作確認回数 : ${CPB_PROBE_COUNT}"
}

cp_score() {
    local score=50
    [[ -d "$CPB_IBL" ]] && score=$((score + 30))
    [[ $CPB_PROBE_COUNT -gt 0 ]] && score=$((score + 20))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "connectivity-probe" \
        --version "1.0" \
        --description "連携の実動作確認(無料は実API/鍵要は接続テスト生成)" \
        --init "cp_init" \
        --report "cp_report" \
        --score "cp_score" \
        --enable-var "ENABLE_CONNECTIVITY_PROBE" \
        --cli-flags "--connectivity-probe:--no-connectivity-probe"
fi

if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-help}" in
        probe)     cp_probe "${2:-}" "${3:-}" ;;
        free-all)  cp_probe_free_all ;;
        report)    cp_report ;;
        score)     cp_score ;;
        *)         echo "usage: connectivity-probe.sh {probe <connector> [project] | free-all | report | score}" ;;
    esac
fi
true
