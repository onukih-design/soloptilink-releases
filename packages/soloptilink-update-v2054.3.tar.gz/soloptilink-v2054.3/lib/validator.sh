#!/usr/bin/env bash
# ============================================================
# SoloptiLink Chain v11.0 - 5-Layer Validation System
# ============================================================
# 6層バリデーションでゼロエラーを保証。人間が見落とすミスを検出。
# L1:構文 L2:型 L3:ランタイム L4:UI L5:エッジケース+脆弱性監査 L6:UI操作性
#
# v11.0 新機能:
#   - 依存パッケージ脆弱性監査 (npm audit / pip-audit)
#   - パフォーマンスアンチパターン検出 (N+1, missing index, large bundle)
#   - 自動修正サジェスション (各エラーに修正コマンド/スニペット付与)
#   - インクリメンタルバリデーション (変更ファイルのみ検証)
#   - 並列バリデーション (L1+L2を並列実行)
#   - 重大度スコアリング (1-10, プロジェクトヘルススコア)
# ============================================================

[[ -n "${_VALIDATOR_LOADED:-}" ]] && return 0
_VALIDATOR_LOADED=1

# カラー定義（source時の重複ガード付き）
: "${VLD_GREEN:='\033[0;32m'}"
: "${VLD_YELLOW:='\033[0;33m'}"
: "${VLD_RED:='\033[0;31m'}"
: "${VLD_CYAN:='\033[0;36m'}"
: "${VLD_MAGENTA:='\033[0;35m'}"
: "${VLD_BOLD:='\033[1m'}"
: "${VLD_DIM:='\033[2m'}"
: "${VLD_NC:='\033[0m'}"

# バリデータ設定
VLD_REPORT_DIR=""
VLD_PROJECT_TYPE=""
VLD_LOG_FILE=""
VLD_SKIP_DIRS="node_modules .git dist build __pycache__ .next .venv venv coverage .cache .turbo .output"
VLD_HAS_NODE=false; VLD_HAS_PYTHON=false; VLD_HAS_TYPESCRIPT=false
VLD_HAS_HTML=false; VLD_HAS_CSS=false; VLD_HAS_SHELL=false

# v11.0 グローバル設定
VLD_PARALLEL_ENABLED=true
VLD_AUTOFIX_ENABLED=true
VLD_SEVERITY_WEIGHTS_ERROR=8
VLD_SEVERITY_WEIGHTS_WARNING=3
VLD_SEVERITY_WEIGHTS_INFO=1
VLD_HEALTH_SCORE=100
VLD_TOTAL_ISSUES=0
VLD_TOTAL_SEVERITY=0
VLD_FIX_SUGGESTIONS="[]"
VLD_VERSION="11.0"
VLD_PERF_ISSUES="[]"

# ============================================================
# 初期化: プロジェクト検出・レポートディレクトリ設定
# ============================================================
validator_init() {
    local project_dir="${1:-.}"
    project_dir="$(cd "$project_dir" 2>/dev/null && pwd)" || {
        _validator_log "ERROR" "INIT" "ディレクトリが見つかりません: $1"; return 1
    }
    VLD_REPORT_DIR="${project_dir}/docs/chain-logs"
    VLD_LOG_FILE="${VLD_REPORT_DIR}/validator_$(date +%Y%m%d_%H%M%S).log"
    mkdir -p "$VLD_REPORT_DIR" 2>/dev/null || true

    # v11.0 スコアリングリセット
    VLD_HEALTH_SCORE=100
    VLD_TOTAL_ISSUES=0
    VLD_TOTAL_SEVERITY=0
    VLD_FIX_SUGGESTIONS="[]"
    VLD_PERF_ISSUES="[]"

    # プロジェクトタイプ自動検出
    VLD_PROJECT_TYPE="unknown"
    VLD_HAS_NODE=false; VLD_HAS_PYTHON=false; VLD_HAS_TYPESCRIPT=false
    VLD_HAS_HTML=false; VLD_HAS_CSS=false; VLD_HAS_SHELL=false

    [[ -f "${project_dir}/package.json" ]] && VLD_HAS_NODE=true && VLD_PROJECT_TYPE="node"
    [[ -f "${project_dir}/tsconfig.json" ]] && VLD_HAS_TYPESCRIPT=true && VLD_PROJECT_TYPE="typescript"
    [[ -f "${project_dir}/requirements.txt" || -f "${project_dir}/pyproject.toml" || -f "${project_dir}/setup.py" ]] && \
        VLD_HAS_PYTHON=true && [[ "$VLD_PROJECT_TYPE" == "unknown" ]] && VLD_PROJECT_TYPE="python"

    # ファイル走査による補足検出
    local d="$project_dir"
    (( $(_validator_scan_files "$d" "html" | wc -l) > 0 )) && VLD_HAS_HTML=true
    (( $(_validator_scan_files "$d" "py" | wc -l) > 0 )) && VLD_HAS_PYTHON=true
    (( $(_validator_scan_files "$d" "css" | wc -l) > 0 )) && VLD_HAS_CSS=true
    (( $(_validator_scan_files "$d" "sh" | wc -l) > 0 )) && VLD_HAS_SHELL=true
    [[ "$VLD_PROJECT_TYPE" == "unknown" && "$VLD_HAS_HTML" == "true" ]] && VLD_PROJECT_TYPE="static"

    echo -e "${VLD_BOLD}${VLD_CYAN}[VALIDATOR v${VLD_VERSION}] 初期化完了${VLD_NC}"
    echo -e "  タイプ: ${VLD_PROJECT_TYPE} | Node:${VLD_HAS_NODE} Py:${VLD_HAS_PYTHON} TS:${VLD_HAS_TYPESCRIPT} HTML:${VLD_HAS_HTML}"
    echo -e "  並列実行: ${VLD_PARALLEL_ENABLED} | 自動修正: ${VLD_AUTOFIX_ENABLED}"
}

# ============================================================
# 全5層実行: 各Layerを順次実行し統合結果を返す
# v11.0: L1+L2の並列実行対応、重大度スコアリング統合
# ============================================================
validator_run_all() {
    local project_dir="${1:-.}"
    project_dir="$(cd "$project_dir" 2>/dev/null && pwd)" || return 1

    echo -e "\n${VLD_BOLD}${VLD_CYAN}  6-Layer Validation System (v${VLD_VERSION})${VLD_NC}\n"
    local all="[]"

    # v11.0: L1とL2は並列実行可能（構文と型は互いに依存しない）
    if [[ "$VLD_PARALLEL_ENABLED" == "true" ]]; then
        echo -e "${VLD_BOLD}[Layer 1+2] 構文検証 + 型チェック (並列実行)${VLD_NC}"
        local tmpdir; tmpdir=$(mktemp -d 2>/dev/null || mktemp -d -t 'vld')
        local l1_out="${tmpdir}/l1.json"
        local l2_out="${tmpdir}/l2.json"
        local l1_pid l2_pid

        # バックグラウンドでL1を実行
        ( _validator_layer1_syntax "$project_dir" > "$l1_out" 2>/dev/null ) &
        l1_pid=$!

        # バックグラウンドでL2を実行
        ( _validator_layer2_types "$project_dir" > "$l2_out" 2>/dev/null ) &
        l2_pid=$!

        # 両方の完了を待機
        wait "$l1_pid" 2>/dev/null
        wait "$l2_pid" 2>/dev/null

        local result1="" result2=""
        [[ -f "$l1_out" ]] && result1=$(cat "$l1_out" 2>/dev/null)
        [[ -f "$l2_out" ]] && result2=$(cat "$l2_out" 2>/dev/null)

        # フォールバック: 並列実行結果が空なら直列で再実行
        [[ -z "$result1" || "$result1" == "" ]] && result1=$(_validator_layer1_syntax "$project_dir")
        [[ -z "$result2" || "$result2" == "" ]] && result2=$(_validator_layer2_types "$project_dir")

        all=$(_vld_merge_results "$all" "$result1")
        _vld_print_layer_summary "1" "構文検証" "$result1"
        all=$(_vld_merge_results "$all" "$result2")
        _vld_print_layer_summary "2" "型チェック" "$result2"
        echo ""

        rm -rf "$tmpdir" 2>/dev/null || true
    else
        # 直列実行（フォールバック）
        for i in 0 1; do
            local funcs=("_validator_layer1_syntax" "_validator_layer2_types")
            local names=("構文検証" "型チェック")
            local n=$((i+1))
            echo -e "${VLD_BOLD}[Layer ${n}/5] ${names[$i]}${VLD_NC}"
            local result; result=$(${funcs[$i]} "$project_dir")
            all=$(_vld_merge_results "$all" "$result")
            _vld_print_layer_summary "$n" "${names[$i]}" "$result"
            echo ""
        done
    fi

    # L3, L4, L5, L6 は順次実行（ランタイムは先行結果に依存する可能性あり）
    local layer_funcs=("_validator_layer3_runtime" "_validator_layer4_ui" "_validator_layer5_edge" "_validator_layer6_interactivity")
    local layer_names=("ランタイム" "UI検証" "エッジケース+監査" "UI操作性")
    for i in 0 1 2 3; do
        local n=$((i+3))
        echo -e "${VLD_BOLD}[Layer ${n}/5] ${layer_names[$i]}${VLD_NC}"
        local result; result=$(${layer_funcs[$i]} "$project_dir")
        all=$(_vld_merge_results "$all" "$result")
        _vld_print_layer_summary "$n" "${layer_names[$i]}" "$result"
        echo ""
    done

    # v11.0: 重大度スコアリング計算
    _vld_calculate_health_score "$all"

    local te; te=$(validator_count_errors "$all")
    local tw; tw=$(_vld_count_warnings "$all")
    echo -e "${VLD_BOLD}============================================${VLD_NC}"
    if (( te == 0 )); then echo -e "${VLD_GREEN}  PASSED: ${te}E / ${tw}W${VLD_NC}"
    else echo -e "${VLD_RED}  FAILED: ${te}E / ${tw}W${VLD_NC}"; fi
    echo -e "  ${VLD_CYAN}Project Health Score: ${VLD_HEALTH_SCORE}/100${VLD_NC}"
    echo "$all"
}

# ============================================================
# v11.0: インクリメンタルバリデーション
# 最後のコミットから変更されたファイルのみ検証
# ============================================================
validator_run_changed() {
    local project_dir="${1:-.}"
    project_dir="$(cd "$project_dir" 2>/dev/null && pwd)" || return 1

    echo -e "\n${VLD_BOLD}${VLD_CYAN}  Incremental Validation (v${VLD_VERSION})${VLD_NC}"

    # git差分ファイル取得
    local changed_files
    changed_files=$(cd "$project_dir" && git diff --name-only HEAD 2>/dev/null || true)
    local staged_files
    staged_files=$(cd "$project_dir" && git diff --cached --name-only 2>/dev/null || true)
    local untracked_files
    untracked_files=$(cd "$project_dir" && git ls-files --others --exclude-standard 2>/dev/null || true)

    # 全変更ファイルを統合（重複排除）
    local all_changed
    all_changed=$(printf '%s\n%s\n%s' "$changed_files" "$staged_files" "$untracked_files" | sort -u | grep -v '^$')

    if [[ -z "$all_changed" ]]; then
        echo -e "  ${VLD_GREEN}変更ファイルなし: バリデーション不要${VLD_NC}"
        echo "[]"
        return 0
    fi

    local file_count
    file_count=$(echo "$all_changed" | wc -l | tr -d ' ')
    echo -e "  ${VLD_YELLOW}変更ファイル: ${file_count}件${VLD_NC}"

    # 変更ファイルを種別分類
    local js_files="" py_files="" html_files="" css_files="" json_files="" sh_files="" ts_files=""
    while IFS= read -r relpath; do
        [[ -z "$relpath" ]] && continue
        local fullpath="${project_dir}/${relpath}"
        [[ ! -f "$fullpath" ]] && continue
        # VLD_SKIP_DIRS内のファイルを除外
        local skip=false
        for sd in $VLD_SKIP_DIRS; do
            [[ "$relpath" == *"${sd}/"* ]] && { skip=true; break; }
        done
        [[ "$skip" == "true" ]] && continue
        case "$relpath" in
            *.js|*.jsx|*.mjs|*.cjs) js_files="${js_files}${fullpath}"$'\n' ;;
            *.ts|*.tsx)              ts_files="${ts_files}${fullpath}"$'\n' ;;
            *.py)                    py_files="${py_files}${fullpath}"$'\n' ;;
            *.html|*.htm)            html_files="${html_files}${fullpath}"$'\n' ;;
            *.css)                   css_files="${css_files}${fullpath}"$'\n' ;;
            *.json)                  json_files="${json_files}${fullpath}"$'\n' ;;
            *.sh|*.bash)             sh_files="${sh_files}${fullpath}"$'\n' ;;
        esac
    done <<< "$all_changed"

    local all_results="[]"
    local errors="[]" warnings="[]" checked=0 failed=0

    # 構文チェック（変更ファイルのみ）
    echo -e "  ${VLD_DIM}[INC-L1] 構文チェック...${VLD_NC}"
    if [[ -n "$js_files" ]] && command -v node &>/dev/null; then
        while IFS= read -r f; do [[ -z "$f" ]] && continue; ((checked++))
            local out; out=$(node --check "$f" 2>&1) || {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "$f" "" "$out" 8 "node --check \"$f\" でエラー確認後修正")
            }
        done <<< "$js_files"
    fi
    if [[ -n "$py_files" ]] && command -v python3 &>/dev/null; then
        while IFS= read -r f; do [[ -z "$f" ]] && continue; ((checked++))
            local out; out=$(python3 -m py_compile "$f" 2>&1) || {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "$f" "" "$out" 8 "python3 -m py_compile \"$f\" でエラー箇所確認")
            }
        done <<< "$py_files"
    fi
    if [[ -n "$ts_files" ]] && command -v node &>/dev/null; then
        while IFS= read -r f; do [[ -z "$f" ]] && continue; ((checked++))
            local out; out=$(node --check "$f" 2>&1) || {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "$f" "" "$out" 8 "npx tsc --noEmit で型エラー確認")
            }
        done <<< "$ts_files"
    fi
    if [[ -n "$json_files" ]] && command -v python3 &>/dev/null; then
        while IFS= read -r f; do [[ -z "$f" ]] && continue
            local bn; bn=$(basename "$f")
            [[ "$bn" == "package-lock.json" || "$bn" == "yarn.lock" ]] && continue
            ((checked++))
            local out; out=$(python3 -c "import json,sys;json.load(open(sys.argv[1],encoding='utf-8'))" "$f" 2>&1) || {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "$f" "" "$out" 7 "JSONフォーマッタで修正: python3 -m json.tool \"$f\"")
            }
        done <<< "$json_files"
    fi
    if [[ -n "$sh_files" ]]; then
        while IFS= read -r f; do [[ -z "$f" ]] && continue; ((checked++))
            local out; out=$(bash -n "$f" 2>&1) || {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "$f" "" "$out" 7 "bash -n \"$f\" のエラー行を確認して修正")
            }
        done <<< "$sh_files"
    fi

    local inc_status="pass"
    (( failed > 0 )) && inc_status="fail"
    local inc_result; inc_result=$(_vld_build_layer_json 0 "incremental" "$inc_status" "$errors" "$warnings" "$checked" "$failed")
    all_results=$(_vld_merge_results "$all_results" "$inc_result")

    _vld_calculate_health_score "$all_results"

    local te; te=$(validator_count_errors "$all_results")
    local tw; tw=$(_vld_count_warnings "$all_results")
    echo -e "  ${VLD_BOLD}[INC結果] ${checked}ファイル検査 / ${VLD_RED}${te}E${VLD_NC} / ${VLD_YELLOW}${tw}W${VLD_NC}"
    echo -e "  ${VLD_CYAN}Project Health Score: ${VLD_HEALTH_SCORE}/100${VLD_NC}"
    echo "$all_results"
}

# ============================================================
# Layer 1: 構文検証 - 全ファイルの構文を機械的にチェック
# ============================================================
_validator_layer1_syntax() {
    local project_dir="$1" errors="[]" warnings="[]" status="pass" checked=0 failed=0

    # JavaScript: node --check
    local files; files=$(_validator_scan_files "$project_dir" "js,jsx,mjs,cjs")
    if [[ -n "$files" ]] && command -v node &>/dev/null; then
        while IFS= read -r f; do [[ -z "$f" ]] && continue; ((checked++))
            local out; out=$(node --check "$f" 2>&1) || {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "$f" "" "$out" 9 "構文エラー修正: エディタで該当行を開き括弧/セミコロン等を確認")
            }
        done <<< "$files"
    fi

    # Python: py_compile
    files=$(_validator_scan_files "$project_dir" "py")
    if [[ -n "$files" ]] && command -v python3 &>/dev/null; then
        while IFS= read -r f; do [[ -z "$f" ]] && continue; ((checked++))
            local out; out=$(python3 -m py_compile "$f" 2>&1) || {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "$f" "" "$out" 9 "python3 -m py_compile \"$f\" でエラー行確認、インデントや構文を修正")
            }
        done <<< "$files"
    fi

    # HTML: タグバランスチェック
    files=$(_validator_scan_files "$project_dir" "html,htm")
    if [[ -n "$files" ]] && command -v python3 &>/dev/null; then
        while IFS= read -r f; do [[ -z "$f" ]] && continue; ((checked++))
            local out; out=$(python3 -c "
import re,sys
c=open(sys.argv[1],'r',encoding='utf-8',errors='ignore').read()
tags=re.findall(r'<(/?)(\w+)[^>]*>',c); stack=[]; issues=[]
void_t={'br','hr','img','input','meta','link','area','base','col','embed','source','track','wbr'}
for cl,t in tags:
 t=t.lower()
 if t in void_t: continue
 if not cl: stack.append(t)
 elif stack and stack[-1]==t: stack.pop()
 else: issues.append(f'タグ不一致: </{t}>')
for t in stack: issues.append(f'未閉タグ: <{t}>')
if issues: print('\\n'.join(issues[:5])); sys.exit(1)
" "$f" 2>&1) || {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "$f" "" "$out" 7 "HTMLタグの開閉を確認。未閉タグには対応する閉じタグを追加")
            }
        done <<< "$files"
    fi

    # CSS: 括弧バランス
    files=$(_validator_scan_files "$project_dir" "css")
    if [[ -n "$files" ]] && command -v python3 &>/dev/null; then
        while IFS= read -r f; do [[ -z "$f" ]] && continue; ((checked++))
            local out; out=$(python3 -c "
import re,sys; c=open(sys.argv[1],'r',encoding='utf-8',errors='ignore').read()
c=re.sub(r'/\*.*?\*/','',c,flags=re.DOTALL)
o=c.count('{'); cl=c.count('}')
if o!=cl: print(f'括弧不一致: {{{o}個 vs }}{cl}個'); sys.exit(1)
" "$f" 2>&1) || {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "$f" "" "$out" 7 "CSSの{}括弧数を確認。プロパティブロックの閉じ忘れをチェック")
            }
        done <<< "$files"
    fi

    # JSON: json.load
    files=$(_validator_scan_files "$project_dir" "json")
    if [[ -n "$files" ]] && command -v python3 &>/dev/null; then
        while IFS= read -r f; do [[ -z "$f" ]] && continue
            local bn; bn=$(basename "$f")
            [[ "$bn" == "package-lock.json" || "$bn" == "yarn.lock" ]] && continue
            ((checked++))
            local out; out=$(python3 -c "import json,sys;json.load(open(sys.argv[1],encoding='utf-8'))" "$f" 2>&1) || {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "$f" "" "$out" 7 "JSON修正: python3 -m json.tool \"$f\" でフォーマット確認。末尾カンマ・引用符を確認")
            }
        done <<< "$files"
    fi

    # Shell: bash -n
    files=$(_validator_scan_files "$project_dir" "sh,bash")
    if [[ -n "$files" ]]; then
        while IFS= read -r f; do [[ -z "$f" ]] && continue; ((checked++))
            local out; out=$(bash -n "$f" 2>&1) || {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "$f" "" "$out" 8 "bash -n でシンタックスエラー行を確認。fi/done/esac等の閉じ忘れが多い")
            }
        done <<< "$files"
    fi

    (( failed > 0 )) && status="fail"
    _validator_log "INFO" "L1" "${checked}ファイル検査, ${failed}件エラー"
    _vld_build_layer_json 1 "syntax" "$status" "$errors" "$warnings" "$checked" "$failed"
}

# ============================================================
# Layer 2: 型チェック - tsc/mypy/Claude CLIによる型分析
# ============================================================
_validator_layer2_types() {
    local project_dir="$1" errors="[]" warnings="[]" status="pass" checked=0 failed=0

    # TypeScript: tsc --noEmit
    if [[ -f "${project_dir}/tsconfig.json" ]]; then
        if command -v npx &>/dev/null; then
            ((checked++))
            local out; out=$(cd "$project_dir" && npx tsc --noEmit --pretty 2>&1) || {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "tsconfig.json" "" "$(echo "$out" | head -30)" 8 "npx tsc --noEmit で型エラー確認。型定義の追加: npm i -D @types/パッケージ名")
            }
        else
            warnings=$(_vld_append_issue "$warnings" "" "" "npx未検出: TypeScript型チェックをスキップ")
        fi
    fi

    # Python: mypy（インストール済みの場合のみ）
    if [[ "$VLD_HAS_PYTHON" == "true" ]] && command -v mypy &>/dev/null; then
        ((checked++))
        local out; out=$(cd "$project_dir" && mypy --ignore-missing-imports --no-error-summary . 2>&1) || {
            local ec; ec=$(echo "$out" | grep -c "error:" 2>/dev/null || echo "0")
            if (( ec > 0 )); then ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "python" "" "$(echo "$out" | grep 'error:' | head -10)" 7 "mypy --ignore-missing-imports . で詳細確認。型ヒント追加: def func(x: int) -> str:")
            fi
        }
    elif [[ "$VLD_HAS_PYTHON" == "true" ]]; then
        warnings=$(_vld_append_issue "$warnings" "" "" "mypy未インストール: pip install mypy を推奨")
    fi

    # Claude CLIによる未定義変数・未使用import検出（主要ファイル最大5つ）
    local key_files; key_files=$(_validator_scan_files "$project_dir" "js,jsx,ts,tsx,py" | head -5)
    if [[ -n "$key_files" ]]; then
        while IFS= read -r f; do [[ -z "$f" ]] && continue; ((checked++))
            local content; content=$(head -100 "$f" 2>/dev/null); [[ -z "$content" ]] && continue
            local cr; cr=$(_validator_call_claude "以下のコードに型エラー・未定義変数・未使用importがないかチェック。問題は「ERROR: 説明」形式、なければ「NO_ISSUES」で返答。\n\nファイル: ${f}\n\`\`\`\n${content}\n\`\`\`")
            if [[ -n "$cr" && "$cr" != *"NO_ISSUES"* ]]; then
                local il; il=$(echo "$cr" | grep -i "ERROR:" | head -5)
                [[ -n "$il" ]] && { ((failed++)); errors=$(_vld_append_issue_scored "$errors" "$f" "" "$il" 6 "未使用importを削除。未定義変数には適切な宣言を追加"); }
            fi
        done <<< "$key_files"
    fi

    (( failed > 0 )) && status="fail"
    _validator_log "INFO" "L2" "${checked}項目検査, ${failed}件エラー"
    _vld_build_layer_json 2 "types" "$status" "$errors" "$warnings" "$checked" "$failed"
}

# ============================================================
# Layer 3: ランタイム検証 - ビルド・サーバー起動・テスト実行
# ============================================================
_validator_layer3_runtime() {
    local project_dir="$1" errors="[]" warnings="[]" status="pass" checked=0 failed=0

    if [[ -f "${project_dir}/package.json" ]] && command -v npm &>/dev/null; then
        # ビルドスクリプト検出・実行
        local script; script=$(python3 -c "
import json,sys; s=json.load(open(sys.argv[1])).get('scripts',{})
print('build' if 'build' in s else ('compile' if 'compile' in s else ''))" "${project_dir}/package.json" 2>/dev/null)
        if [[ -n "$script" ]]; then ((checked++))
            local out; out=$(cd "$project_dir" && npm run "$script" 2>&1) || {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "package.json" "" "npm run ${script} 失敗: $(echo "$out" | tail -15)" 9 "ビルドエラー修正: npm run ${script} 2>&1 | tail -30 でエラー詳細確認")
            }
        fi

        # devサーバー起動テスト
        local dev; dev=$(python3 -c "
import json,sys; s=json.load(open(sys.argv[1])).get('scripts',{})
print('dev' if 'dev' in s else ('start' if 'start' in s else ''))" "${project_dir}/package.json" 2>/dev/null)
        if [[ -n "$dev" ]]; then ((checked++))
            (cd "$project_dir" && npm run "$dev" &>/dev/null) &
            local pid=$!; local ok=false; local w=0
            while (( w < 8 )); do sleep 1; ((w++))
                for p in 3000 5173 8080 4200 8000; do
                    curl -s -o /dev/null -w "%{http_code}" "http://localhost:${p}" 2>/dev/null | grep -q "200\|301\|302\|304" && { ok=true; break 2; }
                done
            done
            kill "$pid" 2>/dev/null; wait "$pid" 2>/dev/null; pkill -P "$pid" 2>/dev/null || true
            [[ "$ok" != "true" ]] && warnings=$(_vld_append_issue "$warnings" "" "" "devサーバーが8秒以内にHTTP応答なし")
        fi

        # テストスイート実行
        local has_test; has_test=$(python3 -c "
import json,sys; s=json.load(open(sys.argv[1])).get('scripts',{}).get('test','')
print('yes' if s and 'no test specified' not in s else '')" "${project_dir}/package.json" 2>/dev/null)
        if [[ "$has_test" == "yes" ]]; then ((checked++))
            local out; out=$(cd "$project_dir" && timeout 120 npm test -- --passWithNoTests 2>&1) || {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "package.json" "" "テスト失敗: $(echo "$out" | tail -10)" 8 "npm test -- --verbose でテスト詳細確認。失敗テストの期待値を確認")
            }
        fi
    fi

    # Python: メインスクリプト起動テスト
    if [[ "$VLD_HAS_PYTHON" == "true" ]] && command -v python3 &>/dev/null; then
        local mp=""
        [[ -f "${project_dir}/main.py" ]] && mp="${project_dir}/main.py"
        [[ -f "${project_dir}/app.py" ]] && mp="${project_dir}/app.py"
        if [[ -n "$mp" ]]; then ((checked++))
            timeout 10 python3 "$mp" --help &>/dev/null || \
            timeout 10 python3 -c "import importlib.util as u;s=u.spec_from_file_location('m','$mp');u.module_from_spec(s)" 2>&1 || {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "$mp" "" "Pythonインポートエラー" 8 "python3 -c \"import $(basename "$mp" .py)\" で依存関係を確認。pip install -r requirements.txt を実行")
            }
        fi
    fi

    (( failed > 0 )) && status="fail"
    _validator_log "INFO" "L3" "${checked}項目検査, ${failed}件エラー"
    _vld_build_layer_json 3 "runtime" "$status" "$errors" "$warnings" "$checked" "$failed"
}

# ============================================================
# Layer 4: UI/インタラクション検証 - アクセシビリティ・UXチェック
# ============================================================
_validator_layer4_ui() {
    local project_dir="$1" errors="[]" warnings="[]" status="pass" checked=0 failed=0
    local ui_files; ui_files=$(_validator_scan_files "$project_dir" "html,htm,jsx,tsx")
    if [[ -z "$ui_files" ]]; then
        _vld_build_layer_json 4 "ui" "skip" "[]" "[]" 0 0; return 0; fi

    # 静的パターンチェック
    while IFS= read -r f; do [[ -z "$f" ]] && continue; ((checked++))
        local issues; issues=$(python3 -c "
import re,sys; c=open(sys.argv[1],'r',encoding='utf-8',errors='ignore').read(); iss=[]
for a in re.findall(r'<button([^>]*)>',c,re.I):
 if 'onClick' not in a and 'onclick' not in a and 'type=' not in a: iss.append('WARNING: <button>にonClick/type無し')
for a in re.findall(r'<form([^>]*)>',c,re.I):
 if 'onSubmit' not in a and 'action=' not in a: iss.append('WARNING: <form>にonSubmit/action無し')
for a in re.findall(r'<img([^>]*)/?>', c, re.I):
 if 'alt=' not in a: iss.append('ERROR: <img>にalt属性無し')
for a in re.findall(r'<a([^>]*)>',c,re.I):
 if ('href=\"#\"' in a or \"href='#'\" in a) and 'onClick' not in a and 'onclick' not in a: iss.append('WARNING: href=#にonClick無し')
for a in re.findall(r'<input([^>]*)/?>', c, re.I):
 if 'hidden' in a: continue
 if 'aria-label' not in a and 'id=' not in a: iss.append('WARNING: <input>にaria-label/id無し')
if sys.argv[1].endswith(('.html','.htm')):
 if 'viewport' not in c: iss.append('WARNING: viewportメタタグ無し')
 if '<!DOCTYPE' not in c and '<!doctype' not in c: iss.append('WARNING: DOCTYPE宣言無し')
for i in iss[:10]: print(i)
if any('ERROR:' in i for i in iss): sys.exit(1)
" "$f" 2>&1)
        if [[ -n "$issues" ]]; then
            local el; el=$(echo "$issues" | grep "^ERROR:" || true)
            local wl; wl=$(echo "$issues" | grep "^WARNING:" || true)
            [[ -n "$el" ]] && {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "$f" "" "$el" 6 "imgタグにalt属性追加: <img alt=\"説明\" ...>。アクセシビリティ必須")
            }
            [[ -n "$wl" ]] && warnings=$(_vld_append_issue "$warnings" "$f" "" "$wl")
        fi
    done <<< "$ui_files"

    # Claude CLIによるUI品質分析（上位3ファイル）
    local top; top=$(echo "$ui_files" | head -3)
    while IFS= read -r f; do [[ -z "$f" ]] && continue
        local content; content=$(head -80 "$f" 2>/dev/null); [[ -z "$content" ]] && continue
        local cr; cr=$(_validator_call_claude "UIコードのアクセシビリティ・UX問題をチェック。「ERROR: 説明」「WARNING: 説明」形式、問題なしなら「NO_ISSUES」。\n\nファイル: ${f}\n\`\`\`\n${content}\n\`\`\`")
        if [[ -n "$cr" && "$cr" != *"NO_ISSUES"* ]]; then
            local ce; ce=$(echo "$cr" | grep -i "^ERROR:" | head -3)
            local cw; cw=$(echo "$cr" | grep -i "^WARNING:" | head -3)
            [[ -n "$ce" ]] && { ((failed++)); errors=$(_vld_append_issue_scored "$errors" "$f" "" "$ce" 5 "Claude AIが検出したUI問題。該当コンポーネントを確認"); }
            [[ -n "$cw" ]] && warnings=$(_vld_append_issue "$warnings" "$f" "" "$cw")
        fi
    done <<< "$top"

    (( failed > 0 )) && status="fail"
    _validator_log "INFO" "L4" "${checked}ファイル検査, ${failed}件エラー"
    _vld_build_layer_json 4 "ui" "$status" "$errors" "$warnings" "$checked" "$failed"
}

# ============================================================
# Layer 5: エッジケース + 脆弱性監査 + パフォーマンスLint (v11.0拡張)
# ============================================================
_validator_layer5_edge() {
    local project_dir="$1" errors="[]" warnings="[]" status="pass" checked=0 failed=0
    local src; src=$(_validator_scan_files "$project_dir" "js,jsx,ts,tsx,py" | head -8)
    if [[ -z "$src" ]]; then
        _vld_build_layer_json 5 "edge" "skip" "[]" "[]" 0 0; return 0; fi

    # Claude CLIでエッジケース分析
    while IFS= read -r f; do [[ -z "$f" ]] && continue; ((checked++))
        local content; content=$(head -120 "$f" 2>/dev/null); [[ -z "$content" ]] && continue
        local cr; cr=$(_validator_call_claude "コードのエッジケース問題を厳密チェック。観点: 空文字列/null未処理, 配列境界, ゼロ除算, SQLi, XSS, async未catch, リソース未close, 競合状態。「ERROR:」「WARNING:」形式、問題なしなら「NO_ISSUES」。\n\nファイル: ${f}\n\`\`\`\n${content}\n\`\`\`")
        if [[ -n "$cr" && "$cr" != *"NO_ISSUES"* ]]; then
            local ee; ee=$(echo "$cr" | grep -i "^ERROR:" | head -5)
            local ew; ew=$(echo "$cr" | grep -i "^WARNING:" | head -5)
            [[ -n "$ee" ]] && { ((failed++)); errors=$(_vld_append_issue_scored "$errors" "$f" "" "$ee" 7 "エッジケース対応: null/undefinedチェック追加、try-catchでラップ"); }
            [[ -n "$ew" ]] && warnings=$(_vld_append_issue "$warnings" "$f" "" "$ew")
        fi
    done <<< "$src"

    # 静的パターンマッチ: セキュリティリスク検出
    local all_src; all_src=$(_validator_scan_files "$project_dir" "js,jsx,ts,tsx,py,php,rb")
    if [[ -n "$all_src" ]]; then
        while IFS= read -r f; do [[ -z "$f" ]] && continue
            local c; c=$(cat "$f" 2>/dev/null); [[ -z "$c" ]] && continue
            echo "$c" | grep -qE '\.innerHTML\s*=|dangerouslySetInnerHTML' && \
                warnings=$(_vld_append_issue_scored "$warnings" "$f" "" "XSSリスク: innerHTML使用検出" 5 "textContent or DOMPurify.sanitize() に置換")
            echo "$c" | grep -qE '\beval\s*\(' && \
                warnings=$(_vld_append_issue_scored "$warnings" "$f" "" "セキュリティ: eval()使用検出" 6 "eval()をFunction()またはJSON.parse()に置換")
            echo "$c" | grep -qEi "(SELECT|INSERT|UPDATE|DELETE).*\+.*(\"|')" 2>/dev/null && \
                warnings=$(_vld_append_issue_scored "$warnings" "$f" "" "SQLiリスク: SQL文字列結合検出" 8 "パラメータ化クエリに変更: db.query('SELECT * FROM t WHERE id=?', [id])")
            echo "$c" | grep -qEi '(password|secret|api_key|token)\s*=\s*["'"'"'][^"'"'"']{8,}' 2>/dev/null && {
                errors=$(_vld_append_issue_scored "$errors" "$f" "" "ハードコードされたシークレットの可能性" 10 "環境変数に移行: process.env.SECRET_KEY or os.environ['SECRET_KEY']。.envファイルを.gitignoreに追加")
                ((failed++)); }
        done <<< "$all_src"
    fi

    # =====================================================
    # v11.0 新機能: 依存パッケージ脆弱性監査
    # =====================================================
    _validator_layer5_dependency_audit "$project_dir"
    local dep_errors="$_VLD_DEP_ERRORS"
    local dep_warnings="$_VLD_DEP_WARNINGS"
    local dep_checked="$_VLD_DEP_CHECKED"
    local dep_failed="$_VLD_DEP_FAILED"
    checked=$((checked + dep_checked))
    failed=$((failed + dep_failed))
    errors=$(_vld_merge_issue_arrays "$errors" "$dep_errors")
    warnings=$(_vld_merge_issue_arrays "$warnings" "$dep_warnings")

    # =====================================================
    # v11.0 新機能: パフォーマンスアンチパターン検出
    # =====================================================
    _validator_layer5_performance_lint "$project_dir"
    local perf_warnings="$_VLD_PERF_WARNINGS"
    local perf_checked="$_VLD_PERF_CHECKED"
    checked=$((checked + perf_checked))
    warnings=$(_vld_merge_issue_arrays "$warnings" "$perf_warnings")

    (( failed > 0 )) && status="fail"
    _validator_log "INFO" "L5" "${checked}ファイル検査, ${failed}件エラー"
    _vld_build_layer_json 5 "edge" "$status" "$errors" "$warnings" "$checked" "$failed"
}

# ============================================================
# Layer 6: UI操作性検証 (v14.0)
# ボタン・フォーム・テーブルが実際に操作可能かを静的解析
# ============================================================
_validator_layer6_interactivity() {
    local project_dir="$1" errors="[]" warnings="[]" status="pass" checked=0 failed=0
    local ui_files; ui_files=$(_validator_scan_files "$project_dir" "jsx,tsx,vue,svelte,html,htm")
    if [[ -z "$ui_files" ]]; then
        _vld_build_layer_json 6 "interactivity" "skip" "[]" "[]" 0 0; return 0; fi

    echo -e "  ${VLD_DIM}[L6-INTERACT] UI操作性チェック...${VLD_NC}"

    while IFS= read -r f; do [[ -z "$f" ]] && continue; ((checked++))
        local issues; issues=$(python3 -c "
import re, sys
c = open(sys.argv[1], 'r', encoding='utf-8', errors='ignore').read()
iss = []

# 1. 空のonClickハンドラ検出
empty_onclick = re.findall(r'onClick\s*=\s*\{\s*\(\)\s*=>\s*\{\s*\}\s*\}', c)
if empty_onclick:
    iss.append('ERROR: 空のonClickハンドラ検出 (%d箇所) - 実際の処理を実装してください' % len(empty_onclick))

# 2. console.logだけのハンドラ
console_only = re.findall(r'onClick\s*=\s*\{\s*\(\)\s*=>\s*\{?\s*console\.log\b[^}]*\}?\s*\}', c)
if console_only:
    iss.append('WARNING: console.logのみのonClickハンドラ (%d箇所) - 実際の処理に置き換えてください' % len(console_only))

# 3. フォームにonSubmitがない
forms = re.findall(r'<form([^>]*)>', c, re.I)
forms_no_submit = [f for f in forms if 'onSubmit' not in f and 'onsubmit' not in f and 'action=' not in f]
if forms_no_submit:
    iss.append('ERROR: onSubmit未実装のフォーム (%d個) - フォーム送信処理を実装してください' % len(forms_no_submit))

# 4. ボタンにonClickもtypeもない（disabled除外）
buttons = re.findall(r'<button([^>]*)>', c, re.I)
dead_buttons = [b for b in buttons if 'onClick' not in b and 'onclick' not in b and 'type=\"submit\"' not in b and 'type=\"button\"' not in b and 'disabled' not in b]
if dead_buttons:
    iss.append('ERROR: イベントハンドラ未実装のボタン (%d個) - onClickを実装してください' % len(dead_buttons))

# 5. テーブルにソート機能がない（th要素にonClick無し）
if '<table' in c.lower() or '<Table' in c:
    th_tags = re.findall(r'<th([^>]*)>', c, re.I)
    if th_tags and not any('onClick' in th or 'onclick' in th or 'sortable' in th.lower() for th in th_tags):
        iss.append('WARNING: テーブルヘッダーにソート機能なし - カラムクリックでソートを実装してください')

# 6. 検索/フィルター機能の欠如（データ一覧画面の場合）
has_table_or_list = bool(re.search(r'<(?:table|Table|ul|ol|div)\b[^>]*(?:className|class)\s*=\s*[\"'\''][^\"'\'']*(list|table|grid|items|data|records)', c, re.I))
has_search = bool(re.search(r'(?:search|filter|query|keyword|検索|フィルタ)', c, re.I))
if has_table_or_list and not has_search:
    iss.append('WARNING: データ一覧に検索/フィルター機能がありません - 検索バーを実装してください')

# 7. ページネーション機能の欠如
has_pagination = bool(re.search(r'(?:pagination|Pagination|page\s*=|currentPage|pageSize|ページ|次へ|前へ|next.*page|prev.*page)', c, re.I))
if has_table_or_list and not has_pagination:
    iss.append('WARNING: データ一覧にページネーションがありません')

# 8. 削除操作に確認ダイアログがない
delete_actions = re.findall(r'(?:delete|remove|削除)\s*[(\']', c, re.I)
has_confirm = bool(re.search(r'(?:confirm|window\.confirm|確認|ConfirmDialog|AlertDialog|Modal)', c, re.I))
if delete_actions and not has_confirm:
    iss.append('WARNING: 削除操作に確認ダイアログがありません - confirm()またはモーダルを実装してください')

for i in iss[:15]:
    print(i)
if any('ERROR:' in i for i in iss):
    sys.exit(1)
" "$f" 2>&1)
        if [[ -n "$issues" ]]; then
            local el; el=$(echo "$issues" | grep "^ERROR:" || true)
            local wl; wl=$(echo "$issues" | grep "^WARNING:" || true)
            [[ -n "$el" ]] && {
                ((failed++))
                errors=$(_vld_append_issue_scored "$errors" "$f" "" "$el" 8 "UI操作性: 空ハンドラを実際の処理に置換し、フォームにonSubmit実装")
            }
            [[ -n "$wl" ]] && warnings=$(_vld_append_issue "$warnings" "$f" "" "$wl")
        fi
    done <<< "$ui_files"

    (( failed > 0 )) && status="fail"
    _validator_log "INFO" "L6" "${checked}ファイル検査, ${failed}件エラー"
    _vld_build_layer_json 6 "interactivity" "$status" "$errors" "$warnings" "$checked" "$failed"
}

# ============================================================
# v11.0: 依存パッケージ脆弱性監査サブルーチン
# ============================================================
_validator_layer5_dependency_audit() {
    local project_dir="$1"
    _VLD_DEP_ERRORS="[]"
    _VLD_DEP_WARNINGS="[]"
    _VLD_DEP_CHECKED=0
    _VLD_DEP_FAILED=0

    echo -e "  ${VLD_DIM}[L5-DEP] 依存パッケージ脆弱性監査...${VLD_NC}"

    # npm audit (Node.jsプロジェクト)
    if [[ -f "${project_dir}/package.json" && -d "${project_dir}/node_modules" ]] && command -v npm &>/dev/null; then
        ((_VLD_DEP_CHECKED++))
        local audit_out; audit_out=$(cd "$project_dir" && npm audit --json 2>/dev/null) || true
        if [[ -n "$audit_out" ]]; then
            local vuln_summary; vuln_summary=$(python3 -c "
import json,sys
try:
    data = json.loads(sys.stdin.read())
    meta = data.get('metadata',{}).get('vulnerabilities',{})
    crit = meta.get('critical',0)
    high = meta.get('high',0)
    moderate = meta.get('moderate',0)
    low = meta.get('low',0)
    total = meta.get('total', crit+high+moderate+low)
    print(f'{total}|{crit}|{high}|{moderate}|{low}')
except:
    print('0|0|0|0|0')
" <<< "$audit_out" 2>/dev/null)
            IFS='|' read -r total crit high moderate low <<< "$vuln_summary"
            total=${total:-0}; crit=${crit:-0}; high=${high:-0}; moderate=${moderate:-0}; low=${low:-0}

            if (( crit > 0 || high > 0 )); then
                ((_VLD_DEP_FAILED++))
                _VLD_DEP_ERRORS=$(_vld_append_issue_scored "$_VLD_DEP_ERRORS" "package.json" "" \
                    "npm脆弱性: critical=${crit} high=${high} moderate=${moderate} low=${low}" \
                    10 "npm audit fix で自動修正。critical: npm audit fix --force。詳細: npm audit")
            elif (( moderate > 0 || low > 0 )); then
                _VLD_DEP_WARNINGS=$(_vld_append_issue_scored "$_VLD_DEP_WARNINGS" "package.json" "" \
                    "npm脆弱性(低〜中): moderate=${moderate} low=${low}" \
                    4 "npm audit fix で修正可能。npm update で依存関係を更新")
            fi

            if (( total > 0 )); then
                echo -e "    ${VLD_YELLOW}npm audit: ${total}件の脆弱性 (C:${crit} H:${high} M:${moderate} L:${low})${VLD_NC}"
            else
                echo -e "    ${VLD_GREEN}npm audit: 脆弱性なし${VLD_NC}"
            fi
        fi
    elif [[ -f "${project_dir}/package.json" ]] && command -v npm &>/dev/null; then
        # node_modulesが無い場合はpackage-lock.jsonベースでチェック
        if [[ -f "${project_dir}/package-lock.json" ]]; then
            ((_VLD_DEP_CHECKED++))
            local audit_out; audit_out=$(cd "$project_dir" && npm audit --json 2>/dev/null) || true
            if [[ -n "$audit_out" ]]; then
                local has_vulns; has_vulns=$(python3 -c "
import json,sys
try:
    data=json.loads(sys.stdin.read())
    t=data.get('metadata',{}).get('vulnerabilities',{}).get('total',0)
    print(t)
except: print(0)
" <<< "$audit_out" 2>/dev/null)
                if [[ "${has_vulns:-0}" != "0" ]]; then
                    _VLD_DEP_WARNINGS=$(_vld_append_issue_scored "$_VLD_DEP_WARNINGS" "package-lock.json" "" \
                        "npm audit: ${has_vulns}件の脆弱性検出(node_modules未インストール)" \
                        5 "npm install && npm audit fix で修正")
                fi
            fi
        fi
    fi

    # pip-audit (Pythonプロジェクト)
    if [[ "$VLD_HAS_PYTHON" == "true" ]]; then
        if command -v pip-audit &>/dev/null; then
            ((_VLD_DEP_CHECKED++))
            local pip_out; pip_out=$(cd "$project_dir" && pip-audit --format=json 2>/dev/null) || true
            if [[ -n "$pip_out" ]]; then
                local pip_vulns; pip_vulns=$(python3 -c "
import json,sys
try:
    data=json.loads(sys.stdin.read())
    vulns=[d for d in data if d.get('vulns')]
    total=sum(len(d.get('vulns',[]))for d in data)
    names=[f\"{d['name']}=={d['version']}\"for d in vulns[:5]]
    print(f'{total}|{\",\".join(names)}')
except: print('0|')
" <<< "$pip_out" 2>/dev/null)
                IFS='|' read -r pip_total pip_names <<< "$pip_vulns"
                pip_total=${pip_total:-0}
                if (( pip_total > 0 )); then
                    ((_VLD_DEP_FAILED++))
                    _VLD_DEP_ERRORS=$(_vld_append_issue_scored "$_VLD_DEP_ERRORS" "requirements.txt" "" \
                        "pip脆弱性: ${pip_total}件 (${pip_names})" \
                        9 "pip-audit --fix で自動修正。手動: pip install --upgrade パッケージ名")
                    echo -e "    ${VLD_RED}pip-audit: ${pip_total}件の脆弱性${VLD_NC}"
                else
                    echo -e "    ${VLD_GREEN}pip-audit: 脆弱性なし${VLD_NC}"
                fi
            fi
        elif [[ -f "${project_dir}/requirements.txt" || -f "${project_dir}/pyproject.toml" ]]; then
            # pip-audit未インストール時: safety checkフォールバック
            if command -v safety &>/dev/null && [[ -f "${project_dir}/requirements.txt" ]]; then
                ((_VLD_DEP_CHECKED++))
                local safety_out; safety_out=$(cd "$project_dir" && safety check -r requirements.txt --output json 2>/dev/null) || true
                if [[ -n "$safety_out" ]]; then
                    local safety_count; safety_count=$(python3 -c "
import json,sys
try: print(len(json.loads(sys.stdin.read())))
except: print(0)
" <<< "$safety_out" 2>/dev/null)
                    if [[ "${safety_count:-0}" != "0" ]]; then
                        _VLD_DEP_WARNINGS=$(_vld_append_issue_scored "$_VLD_DEP_WARNINGS" "requirements.txt" "" \
                            "safety check: ${safety_count}件の既知脆弱性" \
                            6 "pip install pip-audit && pip-audit --fix を推奨")
                    fi
                fi
            else
                _VLD_DEP_WARNINGS=$(_vld_append_issue "$_VLD_DEP_WARNINGS" "" "" \
                    "pip-audit/safety未インストール: pip install pip-audit を推奨")
            fi
        fi
    fi
}

# ============================================================
# v11.0: パフォーマンスアンチパターン検出サブルーチン
# ============================================================
_validator_layer5_performance_lint() {
    local project_dir="$1"
    _VLD_PERF_WARNINGS="[]"
    _VLD_PERF_CHECKED=0

    echo -e "  ${VLD_DIM}[L5-PERF] パフォーマンスアンチパターン検出...${VLD_NC}"

    local all_src; all_src=$(_validator_scan_files "$project_dir" "js,jsx,ts,tsx,py,rb")
    [[ -z "$all_src" ]] && return 0

    while IFS= read -r f; do [[ -z "$f" ]] && continue; ((_VLD_PERF_CHECKED++))
        local c; c=$(cat "$f" 2>/dev/null); [[ -z "$c" ]] && continue
        local relpath="${f#${project_dir}/}"

        # ----- N+1 クエリパターン検出 -----
        # forループ内のDB呼び出し（JS/TS）
        echo "$c" | python3 -c "
import sys,re
c=sys.stdin.read()
# for/while内でのawait db/query/find/fetch パターン
pattern=r'(?:for|while)\s*\([^)]*\)\s*\{[^}]*(?:await\s+(?:db|prisma|mongoose|knex|sequelize|pool)\.|\.query\(|\.find\(|\.findOne\(|\.findMany\(|\.execute\()[^}]*\}'
if re.search(pattern,c,re.DOTALL|re.IGNORECASE):
    print('N+1_QUERY')
    sys.exit(0)
# forEach/map内のawait
pattern2=r'\.(?:forEach|map)\s*\(\s*async[^)]*\)\s*=>\s*\{[^}]*(?:await\s+(?:db|prisma|mongoose|knex|sequelize|pool)\.|\.query\(|\.find\()[^}]*\}'
if re.search(pattern2,c,re.DOTALL|re.IGNORECASE):
    print('N+1_QUERY')
" 2>/dev/null | grep -q "N+1_QUERY" && \
            _VLD_PERF_WARNINGS=$(_vld_append_issue_scored "$_VLD_PERF_WARNINGS" "$relpath" "" \
                "N+1クエリパターン: ループ内でDBクエリが実行されている可能性" \
                7 "バッチクエリに変更: WHERE id IN (...) を使用。ORMならeager loading (include/populate)を使用")

        # Python: forループ内のORM呼び出し
        echo "$c" | python3 -c "
import sys,re
c=sys.stdin.read()
pattern=r'for\s+\w+\s+in\s+[^:]+:\s*\n[^#]*(?:\.objects\.|\.query\.|\.filter\(|\.get\(|session\.query|cursor\.execute)'
if re.search(pattern,c,re.MULTILINE):
    print('N+1_PY')
" 2>/dev/null | grep -q "N+1_PY" && \
            _VLD_PERF_WARNINGS=$(_vld_append_issue_scored "$_VLD_PERF_WARNINGS" "$relpath" "" \
                "N+1クエリ(Python): ループ内でORM/DBアクセス" \
                7 "select_related() / prefetch_related() を使用(Django)。SQLAlchemyなら joinedload() を使用")

        # ----- 大きなバンドルインポート検出 -----
        echo "$c" | grep -qE "^import\s+(?:_\s+from\s+)?['\"](?:moment|lodash|rxjs|aws-sdk|firebase)['\"]" 2>/dev/null && \
            _VLD_PERF_WARNINGS=$(_vld_append_issue_scored "$_VLD_PERF_WARNINGS" "$relpath" "" \
                "大規模パッケージの全体インポート検出" \
                5 "トレーシェイキング可能なインポートに変更: import { specific } from 'lodash/specific' 等。moment -> dayjs, lodash -> lodash-es")

        # import * from large packages
        echo "$c" | grep -qE "import\s+\*\s+as\s+\w+\s+from\s+['\"](?:lodash|moment|rxjs|aws-sdk|@aws-sdk)" 2>/dev/null && \
            _VLD_PERF_WARNINGS=$(_vld_append_issue_scored "$_VLD_PERF_WARNINGS" "$relpath" "" \
                "ワイルドカードインポート: バンドルサイズ増大の原因" \
                5 "名前付きインポートに変更: import { debounce } from 'lodash-es'")

        # require() of large packages without destructuring
        echo "$c" | grep -qE "(?:const|let|var)\s+\w+\s*=\s*require\(['\"](?:moment|lodash|aws-sdk|firebase)['\"]" 2>/dev/null && \
            _VLD_PERF_WARNINGS=$(_vld_append_issue_scored "$_VLD_PERF_WARNINGS" "$relpath" "" \
                "大規模パッケージのrequire()全体読み込み" \
                4 "個別モジュール読み込みに変更: require('lodash/debounce')")

        # ----- Missing index hints (SQL定義ファイル) -----
        if [[ "$f" == *.sql ]] || echo "$c" | grep -qEi "CREATE\s+TABLE" 2>/dev/null; then
            echo "$c" | python3 -c "
import sys,re
c=sys.stdin.read()
# WHERE句で使われるカラムにインデックスがあるかヒント
tables=re.findall(r'CREATE\s+TABLE\s+(\w+)',c,re.I)
indexes=re.findall(r'CREATE\s+(?:UNIQUE\s+)?INDEX\s+\w+\s+ON\s+(\w+)\s*\(([^)]+)\)',c,re.I)
indexed_cols=set()
for t,cols in indexes:
    for col in cols.split(','): indexed_cols.add(f'{t.lower()}.{col.strip().lower()}')
fk_cols=re.findall(r'(\w+_id)\s+(?:INT|INTEGER|BIGINT)',c,re.I)
for col in fk_cols:
    found=False
    for ic in indexed_cols:
        if col.lower() in ic: found=True; break
    if not found: print(f'MISSING_INDEX:{col}')
" 2>/dev/null | while IFS= read -r line; do
                local col="${line#MISSING_INDEX:}"
                _VLD_PERF_WARNINGS=$(_vld_append_issue_scored "$_VLD_PERF_WARNINGS" "$relpath" "" \
                    "インデックス未定義: ${col} (外部キーカラム)" \
                    6 "CREATE INDEX idx_${col} ON テーブル名(${col}); を追加")
            done
        fi

        # ----- 同期的な大量データ処理 -----
        echo "$c" | grep -qE "JSON\.parse\(.*readFileSync\(" 2>/dev/null && \
            _VLD_PERF_WARNINGS=$(_vld_append_issue_scored "$_VLD_PERF_WARNINGS" "$relpath" "" \
                "同期ファイル読み込み+パース: ブロッキングの原因" \
                5 "非同期に変更: const data = JSON.parse(await fs.readFile(path, 'utf-8'))")

        # ----- React: 不要な再レンダリングパターン -----
        echo "$c" | grep -qE "(?:onClick|onChange|onSubmit)\s*=\s*\{\s*\(\)\s*=>" 2>/dev/null && \
            _VLD_PERF_WARNINGS=$(_vld_append_issue_scored "$_VLD_PERF_WARNINGS" "$relpath" "" \
                "インラインアロー関数: レンダリング毎に新関数生成" \
                3 "useCallbackでメモ化: const handler = useCallback(() => {...}, [deps])")

        # ----- Python: リスト内包表記で改善可能なforループ -----
        echo "$c" | python3 -c "
import sys,re
c=sys.stdin.read()
pattern=r'(\w+)\s*=\s*\[\]\s*\n\s*for\s+\w+\s+in\s+[^:]+:\s*\n\s+\1\.append\('
if re.search(pattern,c): print('APPEND_LOOP')
" 2>/dev/null | grep -q "APPEND_LOOP" && \
            _VLD_PERF_WARNINGS=$(_vld_append_issue_scored "$_VLD_PERF_WARNINGS" "$relpath" "" \
                "list.append()ループ: リスト内包表記で高速化可能" \
                2 "result = [transform(x) for x in iterable] に変更")

    done <<< "$all_src"

    local perf_count
    perf_count=$(python3 -c "import json;print(len(json.loads('''${_VLD_PERF_WARNINGS}''')))" 2>/dev/null || echo 0)
    if (( perf_count > 0 )); then
        echo -e "    ${VLD_YELLOW}パフォーマンス警告: ${perf_count}件${VLD_NC}"
    else
        echo -e "    ${VLD_GREEN}パフォーマンスアンチパターン: 検出なし${VLD_NC}"
    fi
}

# ============================================================
# v11.0: 単一ファイルバリデーション（healer.shから呼ばれる）
# ============================================================
validator_check_file() {
    local file="$1"
    [[ ! -f "$file" ]] && return 1

    local ext="${file##*.}"
    local result=0

    case "$ext" in
        js|jsx|mjs|cjs)
            if command -v node &>/dev/null; then
                node --check "$file" 2>/dev/null || result=1
            fi
            ;;
        py)
            if command -v python3 &>/dev/null; then
                python3 -m py_compile "$file" 2>/dev/null || result=1
            fi
            ;;
        ts|tsx)
            # TSファイルは構文レベルでnodeチェック（簡易）
            if command -v node &>/dev/null; then
                node -e "try{require('fs').readFileSync('$file','utf8')}catch(e){process.exit(1)}" 2>/dev/null || result=1
            fi
            ;;
        json)
            if command -v python3 &>/dev/null; then
                python3 -c "import json,sys;json.load(open(sys.argv[1],encoding='utf-8'))" "$file" 2>/dev/null || result=1
            fi
            ;;
        sh|bash)
            bash -n "$file" 2>/dev/null || result=1
            ;;
        html|htm)
            # 基本的なHTMLタグバランスチェック
            if command -v python3 &>/dev/null; then
                python3 -c "
import re,sys
c=open(sys.argv[1],'r',encoding='utf-8',errors='ignore').read()
tags=re.findall(r'<(/?)(\w+)[^>]*>',c); stack=[]
void_t={'br','hr','img','input','meta','link','area','base','col','embed','source','track','wbr'}
for cl,t in tags:
 t=t.lower()
 if t in void_t: continue
 if not cl: stack.append(t)
 elif stack and stack[-1]==t: stack.pop()
if len(stack)>3: sys.exit(1)
" "$file" 2>/dev/null || result=1
            fi
            ;;
        css)
            if command -v python3 &>/dev/null; then
                python3 -c "
import re,sys;c=open(sys.argv[1],'r',encoding='utf-8',errors='ignore').read()
c=re.sub(r'/\*.*?\*/','',c,flags=re.DOTALL)
if abs(c.count('{')-c.count('}'))>1: sys.exit(1)
" "$file" 2>/dev/null || result=1
            fi
            ;;
    esac

    return $result
}

# ============================================================
# レポート生成: コンソール出力 + Markdownファイル保存
# v11.0: 重大度スコア・修正サジェスション・ヘルススコア統合
# ============================================================
validator_report() {
    local results_json="$1"
    [[ -z "$VLD_REPORT_DIR" ]] && VLD_REPORT_DIR="docs/chain-logs"
    mkdir -p "$VLD_REPORT_DIR" 2>/dev/null || true
    local report_file="${VLD_REPORT_DIR}/validation_report.md"
    local te; te=$(validator_count_errors "$results_json")
    local tw; tw=$(_vld_count_warnings "$results_json")

    echo -e "\n${VLD_BOLD}${VLD_CYAN}  Validation Report (v${VLD_VERSION})${VLD_NC}\n"
    if (( te == 0 && tw == 0 )); then echo -e "  ${VLD_GREEN}ALL CLEAR: 全5層通過${VLD_NC}"
    elif (( te == 0 )); then echo -e "  ${VLD_YELLOW}PASSED: 0E / ${tw}W${VLD_NC}"
    else echo -e "  ${VLD_RED}FAILED: ${te}E / ${tw}W${VLD_NC}"; fi
    echo -e "  ${VLD_CYAN}Health Score: ${VLD_HEALTH_SCORE}/100${VLD_NC}"

    # Layer別表示 + Markdown生成（v11.0: severity/fix_suggestion付き）
    python3 -c "
import json
from datetime import datetime
try: results = json.loads('''${results_json}''')
except: results = []
ln={0:'インクリメンタル',1:'構文検証',2:'型チェック',3:'ランタイム',4:'UI検証',5:'エッジケース+監査'}
le={0:'Incremental',1:'Syntax',2:'Types',3:'Runtime',4:'UI',5:'Edge Cases + Audit'}
health=${VLD_HEALTH_SCORE}
# コンソール
for r in results:
    l=r.get('layer',0); s=r.get('status','?'); e=len(r.get('errors',[])); w=len(r.get('warnings',[]))
    ic='\033[0;32mPASS\033[0m' if s=='pass' else ('\033[0;33mSKIP\033[0m' if s=='skip' else '\033[0;31mFAIL\033[0m')
    print(f'  L{l} {ln.get(l,\"?\"):<14} [{ic}] {r.get(\"checked\",0)}検査/{e}E/{w}W')
    for err in r.get('errors',[])[:3]:
        sev=err.get('severity','?')
        print(f'    \033[0;31m-> [{sev}/10] {err.get(\"file\",\"\")} {err.get(\"message\",\"\")[:60]}\033[0m')
        fix=err.get('fix_suggestion','')
        if fix: print(f'    \033[0;36m   FIX: {fix[:80]}\033[0m')
# Markdown
rp=['# Validation Report (v11.0)','',f'Date: {datetime.now():%Y-%m-%d %H:%M:%S}','',
    f'## Project Health Score: **{health}/100**','','## Summary','',
    f'- Errors: **{sum(len(r.get(\"errors\",[]))for r in results)}**',
    f'- Warnings: **{sum(len(r.get(\"warnings\",[]))for r in results)}**',
    f'- Health: **{health}/100**','']
# Severity-sorted fix list
all_issues=[]
for r in results:
    for e in r.get('errors',[]):
        all_issues.append((e.get('severity',5),r.get('layer',0),e.get('file',''),e.get('message',''),e.get('fix_suggestion','')))
    for w in r.get('warnings',[]):
        all_issues.append((w.get('severity',3),r.get('layer',0),w.get('file',''),w.get('message',''),w.get('fix_suggestion','')))
all_issues.sort(key=lambda x:-x[0])
if all_issues:
    rp+=['## Fix List (Severity順)','','| # | Severity | Layer | File | Issue | Fix |','|---|----------|-------|------|-------|-----|']
    for i,(sev,l,f,m,fix) in enumerate(all_issues[:30],1):
        rp.append(f'| {i} | **{sev}/10** | L{l} | \`{f}\` | {m[:80]} | {fix[:80]} |')
    rp.append('')
for r in results:
    l=r.get('layer',0); rp+=[f'## Layer {l}: {le.get(l,\"\")} ({r.get(\"status\",\"\").upper()})','']
    for e in r.get('errors',[]):
        sev=e.get('severity','?')
        fix=e.get('fix_suggestion','')
        rp.append(f'  - [{sev}/10] [ERROR] \`{e.get(\"file\",\"\")}\`: {e.get(\"message\",\"\")}')
        if fix: rp.append(f'    - FIX: {fix}')
    for w in r.get('warnings',[]):
        sev=w.get('severity','?')
        fix=w.get('fix_suggestion','')
        rp.append(f'  - [{sev}/10] [WARN] \`{w.get(\"file\",\"\")}\`: {w.get(\"message\",\"\")}')
        if fix: rp.append(f'    - FIX: {fix}')
    rp.append('')
open('${report_file}','w').write('\\n'.join(rp))
" 2>/dev/null
    echo -e "\n  ${VLD_GREEN}レポート保存: ${report_file}${VLD_NC}"
}

# ============================================================
# v11.0: 自動修正サジェスション取得
# 全エラー/警告の修正提案をまとめて取得
# ============================================================
validator_get_fix_suggestions() {
    local results_json="$1"
    python3 -c "
import json,sys
try: results = json.loads('''${results_json}''')
except: results = []; print('[]'); sys.exit(0)
fixes = []
for r in results:
    layer = r.get('layer', 0)
    for issue_type in ['errors', 'warnings']:
        for item in r.get(issue_type, []):
            fix = item.get('fix_suggestion', '')
            if fix:
                fixes.append({
                    'layer': layer,
                    'file': item.get('file', ''),
                    'message': item.get('message', ''),
                    'severity': item.get('severity', 5),
                    'fix': fix,
                    'type': 'error' if issue_type == 'errors' else 'warning'
                })
fixes.sort(key=lambda x: -x['severity'])
print(json.dumps(fixes, ensure_ascii=False))
" 2>/dev/null || echo "[]"
}

# ============================================================
# v11.0: Claude CLIによる自動修正実行
# 最も重大度の高いエラーからClaude CLIに修正させる
# ============================================================
validator_auto_fix() {
    local project_dir="${1:-.}" results_json="${2:-}"
    project_dir="$(cd "$project_dir" 2>/dev/null && pwd)" || return 1

    if [[ -z "$results_json" ]]; then
        echo -e "${VLD_YELLOW}[AUTOFIX] 結果JSONが空です${VLD_NC}"
        return 1
    fi

    local fixes; fixes=$(validator_get_fix_suggestions "$results_json")
    local fix_count; fix_count=$(python3 -c "import json;print(len(json.loads('''${fixes}''')))" 2>/dev/null || echo 0)

    if (( fix_count == 0 )); then
        echo -e "${VLD_GREEN}[AUTOFIX] 修正対象なし${VLD_NC}"
        return 0
    fi

    echo -e "${VLD_BOLD}${VLD_CYAN}[AUTOFIX] ${fix_count}件の修正提案を処理中...${VLD_NC}"

    # 上位5件のエラーをClaude CLIに修正させる
    local top_fixes; top_fixes=$(python3 -c "
import json
fixes = json.loads('''${fixes}''')
errors_only = [f for f in fixes if f['type'] == 'error'][:5]
for f in errors_only:
    print(f['file'] + '|||' + f['message'] + '|||' + f['fix'])
" 2>/dev/null)

    local fixed=0
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        IFS='|||' read -r fix_file fix_msg fix_hint <<< "$line"
        [[ -z "$fix_file" || "$fix_file" == "[]" ]] && continue

        local full_path="${project_dir}/${fix_file}"
        [[ ! -f "$full_path" ]] && full_path="$fix_file"
        [[ ! -f "$full_path" ]] && continue

        echo -e "  ${VLD_YELLOW}修正中: ${fix_file}${VLD_NC}"
        local prompt="以下のファイルのエラーを修正してください。\nエラー: ${fix_msg}\nヒント: ${fix_hint}\nファイルパス: ${full_path}\n\n修正を適用して、ファイルを直接書き換えてください。"
        _validator_call_claude "$prompt" > /dev/null 2>&1
        ((fixed++))
    done <<< "$top_fixes"

    echo -e "${VLD_GREEN}[AUTOFIX] ${fixed}件の修正を試行しました${VLD_NC}"
}

# ============================================================
# エラー数カウント（ヒーリングループ用）
# ============================================================
validator_count_errors() {
    local r="$1"
    python3 -c "import json
try: print(sum(len(x.get('errors',[]))for x in json.loads('''${r}''')))
except: print(0)" 2>/dev/null || echo "0"
}

_vld_count_warnings() {
    local r="$1"
    python3 -c "import json
try: print(sum(len(x.get('warnings',[]))for x in json.loads('''${r}''')))
except: print(0)" 2>/dev/null || echo "0"
}

# ============================================================
# v11.0: 重大度スコアリング・プロジェクトヘルススコア計算
# ============================================================
_vld_calculate_health_score() {
    local results_json="$1"
    local score_data; score_data=$(python3 -c "
import json,sys
try: results = json.loads('''${results_json}''')
except: results = []
total_issues = 0
total_severity = 0
for r in results:
    for e in r.get('errors', []):
        sev = e.get('severity', ${VLD_SEVERITY_WEIGHTS_ERROR})
        total_issues += 1
        total_severity += sev
    for w in r.get('warnings', []):
        sev = w.get('severity', ${VLD_SEVERITY_WEIGHTS_WARNING})
        total_issues += 1
        total_severity += sev
# Health score: 100 - (total_severity * 2), floored at 0
health = max(0, 100 - (total_severity * 2))
# Bonus: if no errors at all, minimum 80
error_count = sum(len(r.get('errors', [])) for r in results)
if error_count == 0 and health < 80:
    health = 80
print(f'{health}|{total_issues}|{total_severity}')
" 2>/dev/null || echo "100|0|0")

    IFS='|' read -r health issues severity <<< "$score_data"
    VLD_HEALTH_SCORE="${health:-100}"
    VLD_TOTAL_ISSUES="${issues:-0}"
    VLD_TOTAL_SEVERITY="${severity:-0}"
}

# ============================================================
# v11.0: 重大度スコア付きissue追加
# ============================================================
_vld_append_issue_scored() {
    local arr="$1" file="$2" line="${3:-}" msg="$4" severity="${5:-5}" fix_suggestion="${6:-}"
    msg=$(echo "$msg" | tr '\n' ' ' | head -c 300)
    fix_suggestion=$(echo "$fix_suggestion" | tr '\n' ' ' | head -c 200)
    python3 -c "
import json,sys
a=json.loads(sys.argv[1])
item={'file':sys.argv[2],'line':sys.argv[3],'message':sys.argv[4][:300],'severity':int(sys.argv[5]),'fix_suggestion':sys.argv[6][:200]}
a.append(item)
print(json.dumps(a,ensure_ascii=False))
" "$arr" "$file" "$line" "$msg" "$severity" "$fix_suggestion" 2>/dev/null || echo "$arr"
}

# ============================================================
# ヘルパー関数群
# ============================================================

# ファイル再帰検索（VLD_SKIP_DIRS除外）
_validator_scan_files() {
    local dir="$1" extensions="$2"
    local find_args=() prune_args=() first=true pfirst=true
    IFS=',' read -ra exts <<< "$extensions"
    for ext in "${exts[@]}"; do ext=$(echo "$ext"|xargs); [[ -z "$ext" ]] && continue
        [[ "$first" == "true" ]] && { find_args+=(-name "*.${ext}"); first=false; } || find_args+=(-o -name "*.${ext}")
    done
    [[ ${#find_args[@]} -eq 0 ]] && return 0
    for skip in $VLD_SKIP_DIRS; do
        [[ "$pfirst" == "true" ]] && { prune_args+=(-name "$skip"); pfirst=false; } || prune_args+=(-o -name "$skip")
    done
    if [[ ${#prune_args[@]} -gt 0 ]]; then
        find "$dir" \( "${prune_args[@]}" \) -prune -o -type f \( "${find_args[@]}" \) -print 2>/dev/null
    else find "$dir" -type f \( "${find_args[@]}" \) -print 2>/dev/null; fi
}

# Claude CLI呼び出し（リトライ付き、失敗時は空返却で処理続行）
_validator_call_claude() {
    local prompt="$1" retry=0
    while (( retry < 2 )); do
        local r; r=$(claude -p --dangerously-skip-permissions --output-format text "$prompt" 2>/dev/null) && { echo "$r"; return 0; }
        ((retry++)); sleep 1
    done
    _validator_log "WARN" "CLAUDE" "Claude CLI呼び出し失敗"; return 0
}

# 構造化ログ
_validator_log() {
    local level="$1" layer="$2" msg="$3" ts; ts=$(date '+%H:%M:%S')
    local color="$VLD_NC"
    case "$level" in INFO) color="$VLD_GREEN";; WARN) color="$VLD_YELLOW";; ERROR) color="$VLD_RED";; esac
    echo -e "  ${color}[${level}][${layer}] ${msg}${VLD_NC}"
    [[ -n "$VLD_LOG_FILE" ]] && echo "[${ts}][${level}][${layer}] ${msg}" >> "$VLD_LOG_FILE" 2>/dev/null || true
}

# JSON配列にissue追加（後方互換: severity/fixなし版）
_vld_append_issue() {
    local arr="$1" file="$2" line="${3:-}" msg="$4"
    msg=$(echo "$msg" | tr '\n' ' ' | head -c 300)
    python3 -c "
import json,sys
a=json.loads(sys.argv[1])
a.append({'file':sys.argv[2],'line':sys.argv[3],'message':sys.argv[4][:300]})
print(json.dumps(a,ensure_ascii=False))
" "$arr" "$file" "$line" "$msg" 2>/dev/null || echo "$arr"
}

# Layer結果JSON構築
_vld_build_layer_json() {
    local layer=$1 name=$2 status=$3 errors=$4 warnings=$5 checked=$6 failed=$7
    python3 -c "
import json,sys
print(json.dumps({'layer':int(sys.argv[1]),'name':sys.argv[2],'status':sys.argv[3],
'errors':json.loads(sys.argv[4]),'warnings':json.loads(sys.argv[5]),
'checked':int(sys.argv[6]),'failed':int(sys.argv[7])},ensure_ascii=False))
" "$layer" "$name" "$status" "$errors" "$warnings" "$checked" "$failed" 2>/dev/null \
        || echo "{\"layer\":${layer},\"name\":\"${name}\",\"status\":\"${status}\",\"errors\":[],\"warnings\":[],\"checked\":${checked},\"failed\":${failed}}"
}

# 結果配列マージ
_vld_merge_results() {
    local all="$1" new="$2"
    python3 -c "
import json,sys
a=json.loads(sys.argv[1]); a.append(json.loads(sys.argv[2])); print(json.dumps(a,ensure_ascii=False))
" "$all" "$new" 2>/dev/null || echo "$all"
}

# issue配列同士のマージ (v11.0)
_vld_merge_issue_arrays() {
    local arr1="$1" arr2="$2"
    python3 -c "
import json,sys
a=json.loads(sys.argv[1]); b=json.loads(sys.argv[2]); a.extend(b); print(json.dumps(a,ensure_ascii=False))
" "$arr1" "$arr2" 2>/dev/null || echo "$arr1"
}

# Layer結果サマリー1行表示（v11.0: severity表示追加）
_vld_print_layer_summary() {
    local n="$1" name="$2" result="$3"
    local e w s c max_sev
    e=$(python3 -c "import json;print(len(json.loads('''${result}''').get('errors',[])))" 2>/dev/null || echo 0)
    w=$(python3 -c "import json;print(len(json.loads('''${result}''').get('warnings',[])))" 2>/dev/null || echo 0)
    s=$(python3 -c "import json;print(json.loads('''${result}''').get('status','?'))" 2>/dev/null || echo "?")
    c=$(python3 -c "import json;print(json.loads('''${result}''').get('checked',0))" 2>/dev/null || echo 0)
    max_sev=$(python3 -c "
import json
r=json.loads('''${result}''')
sevs=[i.get('severity',0) for i in r.get('errors',[])+r.get('warnings',[])]
print(max(sevs) if sevs else 0)
" 2>/dev/null || echo 0)
    local icon color
    case "$s" in pass) icon="PASS"; color="$VLD_GREEN";; skip) icon="SKIP"; color="$VLD_YELLOW";; *) icon="FAIL"; color="$VLD_RED";; esac
    local sev_display=""
    if (( max_sev > 0 )); then
        sev_display=" | MaxSev:${max_sev}/10"
    fi
    echo -e "  ${color}[${icon}]${VLD_NC} ${name}: ${c}検査 / ${VLD_RED}${e}E${VLD_NC} / ${VLD_YELLOW}${w}W${VLD_NC}${VLD_MAGENTA}${sev_display}${VLD_NC}"
}

# ============================================================
# エクスポート: chain.sh から source して使用
# ============================================================
#   source lib/validator.sh
#   validator_init "/path/to/project"
#
#   # 全層バリデーション（L1+L2並列実行）
#   results=$(validator_run_all "/path/to/project")
#   validator_report "$results"
#   error_count=$(validator_count_errors "$results")
#
#   # v11.0: インクリメンタルバリデーション
#   results=$(validator_run_changed "/path/to/project")
#
#   # v11.0: 修正サジェスション取得
#   fixes=$(validator_get_fix_suggestions "$results")
#
#   # v11.0: 自動修正実行
#   validator_auto_fix "/path/to/project" "$results"
#
#   # v11.0: 単一ファイルチェック
#   validator_check_file "/path/to/file.js"
#
#   # v11.0: ヘルススコア参照
#   echo "Health: $VLD_HEALTH_SCORE/100"
