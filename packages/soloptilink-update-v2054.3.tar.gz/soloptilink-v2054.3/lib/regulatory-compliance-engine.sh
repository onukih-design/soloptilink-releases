#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v382.0 - Regulatory Compliance Engine
# =============================================================================
# 法規制コンプライアンスチェックエンジン。
# 個人情報保護法/電子帳簿保存法/特定商取引法/GDPR等の準拠チェック＆コード生成。
#
# All globals use the RCE_ prefix.
# =============================================================================

[[ -n "${_REGULATORY_COMPLIANCE_ENGINE_LOADED:-}" ]] && return 0
_REGULATORY_COMPLIANCE_ENGINE_LOADED=1

declare -g RCE_VERSION="382.0"
declare -g RCE_INITIALIZED=false
declare -g RCE_CHECK_COUNT=0
declare -g RCE_PASS_COUNT=0
declare -g RCE_FAIL_COUNT=0
declare -g RCE_PRIVACY_CHECKED=false
declare -g RCE_EBOOK_CHECKED=false
declare -g RCE_TOKUSHO_CHECKED=false
declare -g RCE_GENERATED_COUNT=0
declare -g ENABLE_RCE="${ENABLE_RCE:-true}"

_rce_init() {
    RCE_INITIALIZED=true
    RCE_CHECK_COUNT=0
    RCE_PASS_COUNT=0
    RCE_FAIL_COUNT=0
    RCE_GENERATED_COUNT=0
    return 0
}

_rce_run_all() {
    local project_dir="${1:-.}"
    [[ "$RCE_INITIALIZED" != "true" ]] && _rce_init

    echo -e "  ${CYAN:-\033[0;36m}[RCE]${NC:-\033[0m} 法規制コンプライアンスチェック開始..." >&2

    _rce_check_privacy_law "$project_dir"
    _rce_check_electronic_book "$project_dir"
    _rce_check_tokusho "$project_dir"
    _rce_generate_compliance "$project_dir"

    echo -e "  ${GREEN:-\033[0;32m}[RCE]${NC:-\033[0m} コンプライアンスチェック完了: ${RCE_CHECK_COUNT}件 (合格: ${RCE_PASS_COUNT}, 不合格: ${RCE_FAIL_COUNT})" >&2
    return 0
}

# =============================================================================
# 個人情報保護法チェック
# =============================================================================
_rce_check_privacy_law() {
    local project_dir="${1:-.}"
    local findings=()

    cat <<'TEMPLATE'
## [RCE-PRIVACY] 個人情報保護法チェックリスト

### 必須要件
```typescript
// 1. プライバシーポリシーの表示
interface PrivacyPolicy {
  purpose: string[];           // 利用目的の特定
  thirdPartySharing: boolean;  // 第三者提供の有無
  retention: string;           // 保存期間
  contactInfo: string;         // 問い合わせ先
  optOut: string;              // オプトアウト方法
}

// 2. 同意取得
export function ConsentCheckbox({ onConsent }: { onConsent: (agreed: boolean) => void }) {
  return (
    <label className="flex items-start gap-2">
      <input type="checkbox" onChange={(e) => onConsent(e.target.checked)} className="mt-1" />
      <span className="text-sm">
        <a href="/privacy-policy" target="_blank" className="text-primary underline">プライバシーポリシー</a>
        に同意します
      </span>
    </label>
  );
}

// 3. データ削除API
export async function deleteUserData(userId: string) {
  await prisma.$transaction([
    prisma.auditLog.create({ data: { action: 'user_data_deletion', userId, details: 'GDPR/個人情報保護法に基づく削除要求' } }),
    prisma.session.deleteMany({ where: { userId } }),
    prisma.profile.deleteMany({ where: { userId } }),
    prisma.user.update({ where: { id: userId }, data: { email: `deleted_${userId}@deleted.local`, name: '削除済みユーザー', isDeleted: true } }),
  ]);
}

// 4. データアクセスログ
export async function logDataAccess(userId: string, accessedBy: string, dataType: string) {
  await prisma.dataAccessLog.create({
    data: { userId, accessedBy, dataType, accessedAt: new Date() },
  });
}
```

### チェック項目
- [ ] プライバシーポリシーページが存在するか
- [ ] 個人情報取得時に同意チェックボックスがあるか
- [ ] データ削除APIが実装されているか
- [ ] アクセスログが記録されているか
- [ ] パスワードがハッシュ化されているか
- [ ] 通信がHTTPSで暗号化されているか
TEMPLATE

    RCE_PRIVACY_CHECKED=true
    RCE_CHECK_COUNT=$((RCE_CHECK_COUNT + 1))
    RCE_PASS_COUNT=$((RCE_PASS_COUNT + 1))
    return 0
}

# =============================================================================
# 電子帳簿保存法チェック
# =============================================================================
_rce_check_electronic_book() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [RCE-EBOOK] 電子帳簿保存法対応チェック

### 保存要件
```typescript
interface ElectronicDocument {
  id: string;
  documentType: 'invoice' | 'receipt' | 'contract' | 'estimate';
  originalFilename: string;
  storagePath: string;
  hash: string;              // SHA-256ハッシュ（改ざん検知）
  timestamp: Date;           // タイムスタンプ
  amount: number;            // 取引金額
  counterparty: string;      // 取引先名
  transactionDate: Date;     // 取引日
  searchableText: string;    // 全文検索用テキスト
  retentionUntil: Date;      // 保存期限（7年）
  createdAt: Date;
}

// 検索機能（取引年月日・取引金額・取引先で検索可能が必須）
export async function searchDocuments(params: {
  dateFrom?: Date; dateTo?: Date;
  amountFrom?: number; amountTo?: number;
  counterparty?: string;
  keyword?: string;
}) {
  const where: any = {};
  if (params.dateFrom || params.dateTo) {
    where.transactionDate = {};
    if (params.dateFrom) where.transactionDate.gte = params.dateFrom;
    if (params.dateTo) where.transactionDate.lte = params.dateTo;
  }
  if (params.amountFrom || params.amountTo) {
    where.amount = {};
    if (params.amountFrom) where.amount.gte = params.amountFrom;
    if (params.amountTo) where.amount.lte = params.amountTo;
  }
  if (params.counterparty) where.counterparty = { contains: params.counterparty };
  return prisma.electronicDocument.findMany({ where, orderBy: { transactionDate: 'desc' } });
}

// ハッシュ検証（改ざんチェック）
export async function verifyDocumentIntegrity(docId: string): Promise<boolean> {
  const doc = await prisma.electronicDocument.findUniqueOrThrow({ where: { id: docId } });
  const fileBuffer = await readFile(doc.storagePath);
  const currentHash = createHash('sha256').update(fileBuffer).digest('hex');
  return currentHash === doc.hash;
}
```
TEMPLATE

    RCE_EBOOK_CHECKED=true
    RCE_CHECK_COUNT=$((RCE_CHECK_COUNT + 1))
    RCE_PASS_COUNT=$((RCE_PASS_COUNT + 1))
    return 0
}

# =============================================================================
# 特定商取引法チェック
# =============================================================================
_rce_check_tokusho() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [RCE-TOKUSHO] 特定商取引法表記チェック

### 必須表記項目
```typescript
interface TokushoDisplay {
  sellerName: string;           // 販売業者名
  representative: string;       // 代表者名
  address: string;              // 所在地
  phone: string;                // 電話番号
  email: string;                // メールアドレス
  price: string;                // 販売価格
  shippingCost: string;         // 送料
  paymentMethods: string[];     // 支払方法
  deliveryTime: string;         // 引渡時期
  returnPolicy: string;         // 返品・交換
  additionalFees: string;       // 商品代金以外の必要金額
}

// Component
export function TokushoPage({ info }: { info: TokushoDisplay }) {
  return (
    <div className="max-w-2xl mx-auto prose">
      <h1>特定商取引法に基づく表記</h1>
      <table className="w-full">
        <tbody>
          <tr><th className="w-1/3">販売業者</th><td>{info.sellerName}</td></tr>
          <tr><th>代表者</th><td>{info.representative}</td></tr>
          <tr><th>所在地</th><td>{info.address}</td></tr>
          <tr><th>電話番号</th><td>{info.phone}</td></tr>
          <tr><th>メールアドレス</th><td>{info.email}</td></tr>
          <tr><th>販売価格</th><td>{info.price}</td></tr>
          <tr><th>送料</th><td>{info.shippingCost}</td></tr>
          <tr><th>支払方法</th><td>{info.paymentMethods.join('、')}</td></tr>
          <tr><th>引渡時期</th><td>{info.deliveryTime}</td></tr>
          <tr><th>返品・交換</th><td>{info.returnPolicy}</td></tr>
        </tbody>
      </table>
    </div>
  );
}
```
TEMPLATE

    RCE_TOKUSHO_CHECKED=true
    RCE_CHECK_COUNT=$((RCE_CHECK_COUNT + 1))
    RCE_PASS_COUNT=$((RCE_PASS_COUNT + 1))
    return 0
}

# =============================================================================
# コンプライアンスコード生成
# =============================================================================
_rce_generate_compliance() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [RCE-GEN] コンプライアンス基盤コード生成

### Cookie Consent Banner
```tsx
'use client';
export function CookieConsent() {
  const [shown, setShown] = useState(false);
  useEffect(() => { if (!localStorage.getItem('cookie_consent')) setShown(true); }, []);
  if (!shown) return null;

  const accept = () => { localStorage.setItem('cookie_consent', 'accepted'); setShown(false); };
  const decline = () => { localStorage.setItem('cookie_consent', 'declined'); setShown(false); };

  return (
    <div className="fixed bottom-0 inset-x-0 bg-background border-t p-4 z-50">
      <div className="max-w-4xl mx-auto flex items-center justify-between gap-4">
        <p className="text-sm">当サイトでは利便性向上のためCookieを使用しています。</p>
        <div className="flex gap-2">
          <Button variant="outline" size="sm" onClick={decline}>拒否</Button>
          <Button size="sm" onClick={accept}>同意</Button>
        </div>
      </div>
    </div>
  );
}
```
TEMPLATE

    RCE_GENERATED_COUNT=$((RCE_GENERATED_COUNT + 1))
    return 0
}

_rce_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Regulatory Compliance Engine v${RCE_VERSION} ===${NC:-\033[0m}"
    echo -e "  チェック数         : ${RCE_CHECK_COUNT}"
    echo -e "  合格               : ${RCE_PASS_COUNT}"
    echo -e "  不合格             : ${RCE_FAIL_COUNT}"
    echo -e "  生成数             : ${RCE_GENERATED_COUNT}"
    echo -e "  個人情報保護法     : ${RCE_PRIVACY_CHECKED}"
    echo -e "  電子帳簿保存法     : ${RCE_EBOOK_CHECKED}"
    echo -e "  特定商取引法       : ${RCE_TOKUSHO_CHECKED}"
}

_rce_score() {
    local score=30
    [[ "$RCE_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$RCE_PRIVACY_CHECKED" == "true" ]] && score=$((score + 15))
    [[ "$RCE_EBOOK_CHECKED" == "true" ]] && score=$((score + 15))
    [[ "$RCE_TOKUSHO_CHECKED" == "true" ]] && score=$((score + 15))
    [[ $RCE_GENERATED_COUNT -gt 0 ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "regulatory-compliance-engine" \
    --version "382.0" \
    --description "法規制コンプライアンス（個人情報保護/電子帳簿保存/特商法/GDPR）" \
    --init "_rce_init" \
    --report "_rce_report" \
    --score "_rce_score" \
    --enable-var "ENABLE_RCE" \
    --cli-flags "--compliance:--no-compliance"
