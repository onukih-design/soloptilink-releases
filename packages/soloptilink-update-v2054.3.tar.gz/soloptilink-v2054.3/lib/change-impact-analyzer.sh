#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v206.0 - Change Impact Analyzer
# 変更対象ファイルから影響範囲を予測し、リスクスコアを算出。
# どのテストを実行すべきか、どのAPIが影響を受けるかを特定する。
#
# 問題: ファイルを1つ変更すると、依存チェーンを辿って
# 多数のファイルに影響が出る。影響範囲を手動で把握するのは困難。
#
# 解決: import/require/source解析で依存グラフを構築し、
# 変更ファイルから影響が波及するファイル群を特定。
# リスクスコア算出とテスト推薦を自動実行。
# ============================================================

[[ -n "${_CIA_LOADED:-}" ]] && return 0
_CIA_LOADED=1

CIA_VERSION="206.0"
CIA_INITIALIZED=false

# State
CIA_PROJECT_DIR=""
CIA_CACHE_DIR=""
CIA_DEP_GRAPH_FILE=""
CIA_ANALYZED_FILES=0
CIA_TOTAL_DEPS=0
CIA_AFFECTED_COUNT=0
CIA_RISK_SCORE=0
CIA_LAST_ANALYSIS=""

# ============================================================
# Init
# ============================================================
cia_init() {
    CIA_ANALYZED_FILES=0
    CIA_TOTAL_DEPS=0
    CIA_AFFECTED_COUNT=0
    CIA_RISK_SCORE=0
    CIA_LAST_ANALYSIS=""

    CIA_PROJECT_DIR="${PROJECT_DIR:-.}"
    CIA_CACHE_DIR="${CIA_PROJECT_DIR}/.soloptilink/cache"
    CIA_DEP_GRAPH_FILE="${CIA_CACHE_DIR}/dep-graph.json"

    mkdir -p "$CIA_CACHE_DIR" 2>/dev/null || true

    CIA_INITIALIZED=true
    return 0
}

# ============================================================
# Internal: Collect importable source files
# ============================================================
_cia_collect_files() {
    local project_dir="${1:-$CIA_PROJECT_DIR}"
    find "$project_dir" \
        -type f \( \
            -name "*.ts" -o -name "*.tsx" -o \
            -name "*.js" -o -name "*.jsx" -o \
            -name "*.sh" \
        \) \
        ! -path "*/node_modules/*" \
        ! -path "*/.next/*" \
        ! -path "*/.git/*" \
        ! -path "*/dist/*" \
        ! -path "*/build/*" \
        ! -path "*/.soloptilink/*" \
        2>/dev/null | sort
}

# ============================================================
# Internal: Extract imports/dependencies from a file
# Returns list of resolved relative paths this file depends on
# ============================================================
_cia_extract_deps() {
    local file="$1"
    local project_dir="${2:-$CIA_PROJECT_DIR}"
    [[ ! -f "$file" ]] && return 0

    local file_dir
    file_dir=$(dirname "$file")
    local ext="${file##*.}"
    local deps=()

    case "$ext" in
        ts|tsx|js|jsx)
            # Extract import paths: import ... from 'path'
            # Extract require: require('path')
            # Extract dynamic import: import('path')
            while IFS= read -r import_path; do
                [[ -z "$import_path" ]] && continue
                # Skip node_modules imports (no ./ or ../ prefix)
                if [[ "$import_path" != .* ]] && [[ "$import_path" != /* ]]; then
                    continue
                fi

                # Resolve relative path
                local resolved=""
                if [[ "$import_path" == .* ]]; then
                    resolved=$(cd "$file_dir" && realpath -m "$import_path" 2>/dev/null || echo "${file_dir}/${import_path}")
                elif [[ "$import_path" == @/* ]]; then
                    # Alias like @/lib/db - assume src/ or project root
                    local alias_path="${import_path#@/}"
                    resolved="${project_dir}/${alias_path}"
                    [[ ! -f "$resolved" ]] && resolved="${project_dir}/src/${alias_path}"
                else
                    resolved="$import_path"
                fi

                # Try to find the actual file (with extensions)
                local found=""
                for try_ext in "" ".ts" ".tsx" ".js" ".jsx" "/index.ts" "/index.tsx" "/index.js"; do
                    if [[ -f "${resolved}${try_ext}" ]]; then
                        found="${resolved}${try_ext}"
                        break
                    fi
                done

                if [[ -n "$found" ]]; then
                    local rel="${found#$project_dir/}"
                    echo "$rel"
                fi
            done < <(
                grep -oE "(import|require|from)\s*[\(']([^')]+)['\)]" "$file" 2>/dev/null | \
                grep -oE "[\'\"][^'\"]+[\'\"]" | tr -d "'\""
            )
            ;;
        sh)
            # Extract source/. commands
            while IFS= read -r sourced; do
                [[ -z "$sourced" ]] && continue
                local resolved=""
                if [[ "$sourced" == .* ]] || [[ "$sourced" == /* ]]; then
                    if [[ "$sourced" == ./* ]] || [[ "$sourced" == ../* ]]; then
                        resolved=$(cd "$file_dir" && realpath -m "$sourced" 2>/dev/null || echo "")
                    else
                        resolved="$sourced"
                    fi
                elif [[ "$sourced" == *'$'* ]]; then
                    # Variable-based paths, try common patterns
                    local expanded
                    expanded=$(echo "$sourced" | sed "s|\\\$LIB_DIR|${project_dir}/lib|g; s|\\\${LIB_DIR}|${project_dir}/lib|g; s|\\\$SCRIPT_DIR|${file_dir}|g")
                    [[ -f "$expanded" ]] && resolved="$expanded"
                fi

                if [[ -n "$resolved" ]] && [[ -f "$resolved" ]]; then
                    local rel="${resolved#$project_dir/}"
                    echo "$rel"
                fi
            done < <(
                grep -oE '(source|\.)\s+[^;|&]+' "$file" 2>/dev/null | \
                sed 's/^\(source\|\.\)\s*//' | tr -d '"' | tr -d "'"
            )
            ;;
    esac
}

# ============================================================
# Internal: Build reverse dependency map
# For each file, which files depend ON it
# ============================================================
_cia_build_reverse_map() {
    local project_dir="${1:-$CIA_PROJECT_DIR}"
    local files_list
    files_list=$(_cia_collect_files "$project_dir")

    # Associative array: file -> list of files that depend on it
    declare -A reverse_map

    local total=0
    while IFS= read -r filepath; do
        [[ -z "$filepath" ]] && continue
        [[ ! -f "$filepath" ]] && continue

        local rel_path="${filepath#$project_dir/}"
        local deps
        deps=$(_cia_extract_deps "$filepath" "$project_dir")

        while IFS= read -r dep; do
            [[ -z "$dep" ]] && continue
            if [[ -n "${reverse_map[$dep]:-}" ]]; then
                reverse_map["$dep"]="${reverse_map[$dep]}|${rel_path}"
            else
                reverse_map["$dep"]="$rel_path"
            fi
            total=$((total + 1))
        done <<< "$deps"

        CIA_ANALYZED_FILES=$((CIA_ANALYZED_FILES + 1))
    done <<< "$files_list"

    CIA_TOTAL_DEPS=$total

    # Output the reverse map
    for key in "${!reverse_map[@]}"; do
        echo "${key}=${reverse_map[$key]}"
    done
}

# ============================================================
# Analyze impact of changing given file(s)
# ============================================================
_cia_analyze_impact() {
    local project_dir="${1:-$CIA_PROJECT_DIR}"
    shift
    local -a changed_files=("$@")

    [[ ${#changed_files[@]} -eq 0 ]] && { echo "[CIA] Error: no files specified" >&2; return 1; }
    [[ ! -d "$project_dir" ]] && { echo "[CIA] Error: project directory not found" >&2; return 1; }
    [[ "$CIA_INITIALIZED" != "true" ]] && cia_init

    CIA_PROJECT_DIR="$project_dir"
    CIA_CACHE_DIR="${project_dir}/.soloptilink/cache"
    mkdir -p "$CIA_CACHE_DIR" 2>/dev/null

    echo "[CIA] Analyzing impact for ${#changed_files[@]} file(s)..." >&2

    # Build reverse dependency map
    CIA_ANALYZED_FILES=0
    CIA_TOTAL_DEPS=0
    local reverse_map_data
    reverse_map_data=$(_cia_build_reverse_map "$project_dir")

    echo "[CIA] Dependency graph: ${CIA_ANALYZED_FILES} files, ${CIA_TOTAL_DEPS} edges" >&2

    # BFS to find all affected files
    declare -A visited
    local -a queue=()
    local -a affected=()

    # Initialize queue with changed files
    for f in "${changed_files[@]}"; do
        local rel="${f#$project_dir/}"
        queue+=("$rel")
        visited["$rel"]=1
    done

    # BFS traversal
    local depth=0
    local max_depth=10
    while [[ ${#queue[@]} -gt 0 ]] && [[ $depth -lt $max_depth ]]; do
        local -a next_queue=()
        for current in "${queue[@]}"; do
            # Find files that depend on current
            local dependents=""
            while IFS= read -r map_entry; do
                [[ -z "$map_entry" ]] && continue
                local key="${map_entry%%=*}"
                local vals="${map_entry#*=}"
                if [[ "$key" == "$current" ]]; then
                    dependents="$vals"
                    break
                fi
            done <<< "$reverse_map_data"

            if [[ -n "$dependents" ]]; then
                IFS='|' read -ra dep_array <<< "$dependents"
                for dep in "${dep_array[@]}"; do
                    [[ -z "$dep" ]] && continue
                    if [[ -z "${visited[$dep]:-}" ]]; then
                        visited["$dep"]=1
                        next_queue+=("$dep")
                        affected+=("$dep")
                    fi
                done
            fi

            # Also check: files that grep-reference the changed file's exports
            local basename_noext
            basename_noext=$(basename "$current" | sed 's/\.[^.]*$//')
            while IFS= read -r referencing_file; do
                [[ -z "$referencing_file" ]] && continue
                local ref_rel="${referencing_file#$project_dir/}"
                if [[ -z "${visited[$ref_rel]:-}" ]]; then
                    visited["$ref_rel"]=1
                    next_queue+=("$ref_rel")
                    affected+=("$ref_rel")
                fi
            done < <(grep -rl "$basename_noext" "$project_dir" \
                --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" \
                --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=.git --exclude-dir=.soloptilink \
                2>/dev/null | head -50)
        done

        queue=("${next_queue[@]}")
        depth=$((depth + 1))
    done

    # Deduplicate affected files
    local -a unique_affected=()
    declare -A seen
    for f in "${affected[@]}"; do
        if [[ -z "${seen[$f]:-}" ]]; then
            seen["$f"]=1
            unique_affected+=("$f")
        fi
    done

    CIA_AFFECTED_COUNT=${#unique_affected[@]}
    CIA_LAST_ANALYSIS=$(date '+%Y-%m-%dT%H:%M:%S')

    echo ""
    echo "=== Change Impact Analysis ==="
    echo "Changed files:"
    for f in "${changed_files[@]}"; do
        echo "  * ${f#$project_dir/}"
    done
    echo ""
    echo "Affected files (${CIA_AFFECTED_COUNT}):"
    for f in "${unique_affected[@]}"; do
        # Categorize by type
        local category="source"
        [[ "$f" == *test* ]] && category="test"
        [[ "$f" == *spec* ]] && category="test"
        [[ "$f" == *api/* ]] && category="api"
        [[ "$f" == *route* ]] && category="api"
        [[ "$f" == *middleware* ]] && category="middleware"
        [[ "$f" == *component* ]] && category="component"
        [[ "$f" == *page* ]] && category="page"
        [[ "$f" == *lib/* ]] && category="library"
        echo "  [$category] $f"
    done

    # Calculate risk score
    CIA_RISK_SCORE=$(_cia_get_risk_score "$project_dir" "${changed_files[@]}")
    echo ""
    echo "Risk Score: ${CIA_RISK_SCORE}/100"

    # Save analysis to cache
    {
        echo "{"
        echo "  \"timestamp\": \"${CIA_LAST_ANALYSIS}\","
        echo "  \"changed_files\": [$(printf '"%s",' "${changed_files[@]}" | sed 's/,$//')],"
        echo "  \"affected_count\": ${CIA_AFFECTED_COUNT},"
        echo "  \"risk_score\": ${CIA_RISK_SCORE},"
        echo "  \"affected_files\": [$(printf '"%s",' "${unique_affected[@]}" | sed 's/,$//')]"
        echo "}"
    } > "${CIA_CACHE_DIR}/last-impact-analysis.json"

    return 0
}

# ============================================================
# Calculate risk score of a change (0-100)
# ============================================================
_cia_get_risk_score() {
    local project_dir="${1:-$CIA_PROJECT_DIR}"
    shift
    local -a changed_files=("$@")
    local risk=0

    for f in "${changed_files[@]}"; do
        local rel="${f#$project_dir/}"
        local full_path="$f"
        [[ ! -f "$full_path" ]] && full_path="${project_dir}/${rel}"

        # Risk factor 1: File type (core files are riskier)
        case "$rel" in
            *middleware*|*auth*|*security*)
                risk=$((risk + 25))
                ;;
            *lib/db*|*prisma*|*schema*)
                risk=$((risk + 20))
                ;;
            *api/*)
                risk=$((risk + 15))
                ;;
            *config*|*env*|*.json)
                risk=$((risk + 15))
                ;;
            *test*|*spec*|*__test__*)
                risk=$((risk + 2))
                ;;
            *page*|*component*)
                risk=$((risk + 8))
                ;;
            *)
                risk=$((risk + 5))
                ;;
        esac

        # Risk factor 2: File size (larger files = more risk)
        if [[ -f "$full_path" ]]; then
            local lines
            lines=$(wc -l < "$full_path" 2>/dev/null | tr -d ' ')
            if [[ ${lines:-0} -gt 500 ]]; then
                risk=$((risk + 15))
            elif [[ ${lines:-0} -gt 200 ]]; then
                risk=$((risk + 8))
            elif [[ ${lines:-0} -gt 100 ]]; then
                risk=$((risk + 4))
            fi
        fi

        # Risk factor 3: Number of importers (how many files depend on this)
        local importer_count=0
        if [[ -f "$full_path" ]]; then
            local basename_noext
            basename_noext=$(basename "$rel" | sed 's/\.[^.]*$//')
            importer_count=$(grep -rl "$basename_noext" "$project_dir" \
                --include="*.ts" --include="*.tsx" --include="*.js" --include="*.jsx" \
                --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=.git \
                2>/dev/null | wc -l | tr -d ' ')
        fi
        if [[ ${importer_count:-0} -gt 20 ]]; then
            risk=$((risk + 20))
        elif [[ ${importer_count:-0} -gt 10 ]]; then
            risk=$((risk + 12))
        elif [[ ${importer_count:-0} -gt 5 ]]; then
            risk=$((risk + 6))
        fi

        # Risk factor 4: Contains security-sensitive patterns
        if [[ -f "$full_path" ]]; then
            if grep -qE '(bcrypt|jwt|token|password|secret|encrypt|decrypt|auth|session)' "$full_path" 2>/dev/null; then
                risk=$((risk + 10))
            fi
        fi

        # Risk factor 5: Shared/exported extensively
        if [[ -f "$full_path" ]]; then
            local export_count
            export_count=$(grep -cE '^export\s' "$full_path" 2>/dev/null || echo "0")
            if [[ ${export_count:-0} -gt 10 ]]; then
                risk=$((risk + 10))
            elif [[ ${export_count:-0} -gt 5 ]]; then
                risk=$((risk + 5))
            fi
        fi
    done

    # Average across files and cap at 100
    local file_count=${#changed_files[@]}
    [[ $file_count -eq 0 ]] && file_count=1
    risk=$((risk / file_count))

    # Add impact spread factor
    if [[ $CIA_AFFECTED_COUNT -gt 50 ]]; then
        risk=$((risk + 20))
    elif [[ $CIA_AFFECTED_COUNT -gt 20 ]]; then
        risk=$((risk + 12))
    elif [[ $CIA_AFFECTED_COUNT -gt 10 ]]; then
        risk=$((risk + 8))
    elif [[ $CIA_AFFECTED_COUNT -gt 5 ]]; then
        risk=$((risk + 4))
    fi

    [[ $risk -gt 100 ]] && risk=100
    [[ $risk -lt 0 ]] && risk=0

    echo "$risk"
}

# ============================================================
# Suggest which tests to run based on change impact
# ============================================================
_cia_suggest_tests() {
    local project_dir="${1:-$CIA_PROJECT_DIR}"
    shift
    local -a changed_files=("$@")

    [[ ${#changed_files[@]} -eq 0 ]] && { echo "[CIA] Error: no files specified" >&2; return 1; }

    echo "=== Suggested Tests ==="
    echo ""

    local -a suggested_tests=()
    declare -A test_seen

    for f in "${changed_files[@]}"; do
        local rel="${f#$project_dir/}"
        local basename_noext
        basename_noext=$(basename "$rel" | sed 's/\.[^.]*$//')
        local dir
        dir=$(dirname "$rel")

        # Strategy 1: Find co-located test files
        local -a test_patterns=(
            "${dir}/${basename_noext}.test.ts"
            "${dir}/${basename_noext}.test.tsx"
            "${dir}/${basename_noext}.test.js"
            "${dir}/${basename_noext}.spec.ts"
            "${dir}/${basename_noext}.spec.tsx"
            "${dir}/${basename_noext}.spec.js"
            "${dir}/__tests__/${basename_noext}.test.ts"
            "${dir}/__tests__/${basename_noext}.test.tsx"
            "tests/${basename_noext}.test.ts"
            "tests/unit/${basename_noext}.bats"
            "tests/unit/test_${basename_noext}.bats"
        )

        for tp in "${test_patterns[@]}"; do
            local full="${project_dir}/${tp}"
            if [[ -f "$full" ]] && [[ -z "${test_seen[$tp]:-}" ]]; then
                test_seen["$tp"]=1
                suggested_tests+=("$tp")
                echo "  [direct] $tp"
            fi
        done

        # Strategy 2: Find tests that import or reference the changed file
        local test_files
        test_files=$(grep -rl "$basename_noext" "$project_dir" \
            --include="*.test.ts" --include="*.test.tsx" --include="*.test.js" \
            --include="*.spec.ts" --include="*.spec.tsx" --include="*.spec.js" \
            --include="*.bats" \
            --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=.git \
            2>/dev/null | head -20)

        while IFS= read -r tf; do
            [[ -z "$tf" ]] && continue
            local trel="${tf#$project_dir/}"
            if [[ -z "${test_seen[$trel]:-}" ]]; then
                test_seen["$trel"]=1
                suggested_tests+=("$trel")
                echo "  [references] $trel"
            fi
        done <<< "$test_files"

        # Strategy 3: If it's an API route, suggest API tests
        if [[ "$rel" == *api/* ]] || [[ "$rel" == *route* ]]; then
            local api_tests
            api_tests=$(find "$project_dir" -type f \( -name "*.test.ts" -o -name "*.test.js" -o -name "*.bats" \) \
                -path "*api*" \
                ! -path "*/node_modules/*" ! -path "*/.next/*" \
                2>/dev/null | head -10)
            while IFS= read -r at; do
                [[ -z "$at" ]] && continue
                local atrel="${at#$project_dir/}"
                if [[ -z "${test_seen[$atrel]:-}" ]]; then
                    test_seen["$atrel"]=1
                    suggested_tests+=("$atrel")
                    echo "  [api-related] $atrel"
                fi
            done <<< "$api_tests"
        fi

        # Strategy 4: If it's a DB/schema change, suggest migration and integration tests
        if [[ "$rel" == *schema* ]] || [[ "$rel" == *prisma* ]] || [[ "$rel" == *migration* ]]; then
            echo "  [WARNING] Schema change detected - run ALL integration tests"
            local int_tests
            int_tests=$(find "$project_dir" -type f \( -name "*integration*" -o -name "*e2e*" \) \
                ! -path "*/node_modules/*" ! -path "*/.next/*" \
                2>/dev/null | head -10)
            while IFS= read -r it; do
                [[ -z "$it" ]] && continue
                local itrel="${it#$project_dir/}"
                if [[ -z "${test_seen[$itrel]:-}" ]]; then
                    test_seen["$itrel"]=1
                    suggested_tests+=("$itrel")
                    echo "  [integration] $itrel"
                fi
            done <<< "$int_tests"
        fi
    done

    echo ""
    echo "Total suggested tests: ${#suggested_tests[@]}"

    # Generate test run command
    if [[ ${#suggested_tests[@]} -gt 0 ]]; then
        echo ""
        echo "Run commands:"
        local has_jest=false has_bats=false
        for t in "${suggested_tests[@]}"; do
            case "$t" in
                *.bats) has_bats=true ;;
                *.test.*|*.spec.*) has_jest=true ;;
            esac
        done
        if [[ "$has_jest" == true ]]; then
            local jest_files=()
            for t in "${suggested_tests[@]}"; do
                [[ "$t" == *.test.* ]] || [[ "$t" == *.spec.* ]] && jest_files+=("$t")
            done
            echo "  npx jest ${jest_files[*]}"
        fi
        if [[ "$has_bats" == true ]]; then
            local bats_files=()
            for t in "${suggested_tests[@]}"; do
                [[ "$t" == *.bats ]] && bats_files+=("$t")
            done
            echo "  bats ${bats_files[*]}"
        fi
    fi

    return 0
}

# ============================================================
# Find which API endpoints are affected by a change
# ============================================================
_cia_get_affected_apis() {
    local project_dir="${1:-$CIA_PROJECT_DIR}"
    shift
    local -a changed_files=("$@")

    [[ ${#changed_files[@]} -eq 0 ]] && { echo "[CIA] Error: no files specified" >&2; return 1; }

    echo "=== Affected API Endpoints ==="
    echo ""

    local -a affected_apis=()
    declare -A api_seen

    for f in "${changed_files[@]}"; do
        local rel="${f#$project_dir/}"
        local full_path="$f"
        [[ ! -f "$full_path" ]] && full_path="${project_dir}/${rel}"

        # Direct API route file
        if [[ "$rel" == *api/* ]] && [[ "$rel" == *route* ]]; then
            # Extract API path from file path (Next.js App Router convention)
            local api_path
            api_path=$(echo "$rel" | sed 's|.*/api/|/api/|; s|/route\.[^.]*$||')
            if [[ -z "${api_seen[$api_path]:-}" ]]; then
                api_seen["$api_path"]=1
                affected_apis+=("$api_path")

                # Extract HTTP methods
                local methods=""
                if [[ -f "$full_path" ]]; then
                    methods=$(grep -oE 'export\s+(async\s+)?function\s+(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)' "$full_path" 2>/dev/null | \
                        grep -oE '(GET|POST|PUT|PATCH|DELETE|HEAD|OPTIONS)' | tr '\n' ',' | sed 's/,$//')
                fi
                echo "  [DIRECT] ${api_path} (${methods:-unknown methods})"
            fi
        fi

        # Indirect: find API routes that import/reference the changed file
        local basename_noext
        basename_noext=$(basename "$rel" | sed 's/\.[^.]*$//')

        local api_files
        api_files=$(grep -rl "$basename_noext" "$project_dir" \
            --include="*.ts" --include="*.js" \
            --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=.git \
            2>/dev/null | grep -E 'api/.*route\.' | head -20)

        while IFS= read -r api_file; do
            [[ -z "$api_file" ]] && continue
            local api_rel="${api_file#$project_dir/}"
            local api_path
            api_path=$(echo "$api_rel" | sed 's|.*/api/|/api/|; s|/route\.[^.]*$||')

            if [[ -z "${api_seen[$api_path]:-}" ]]; then
                api_seen["$api_path"]=1
                affected_apis+=("$api_path")

                local methods=""
                methods=$(grep -oE 'export\s+(async\s+)?function\s+(GET|POST|PUT|PATCH|DELETE)' "$api_file" 2>/dev/null | \
                    grep -oE '(GET|POST|PUT|PATCH|DELETE)' | tr '\n' ',' | sed 's/,$//')
                echo "  [INDIRECT] ${api_path} (${methods:-unknown}) <- ${rel}"
            fi
        done <<< "$api_files"

        # Check if file exports middleware used by API routes
        if [[ -f "$full_path" ]]; then
            if grep -qE 'export.*(middleware|handler|guard|interceptor)' "$full_path" 2>/dev/null; then
                echo "  [WARNING] ${rel} exports middleware/handler - may affect ALL API routes"
            fi
        fi
    done

    echo ""
    echo "Total affected APIs: ${#affected_apis[@]}"

    if [[ ${#affected_apis[@]} -gt 0 ]]; then
        echo ""
        echo "Recommended API testing:"
        for api in "${affected_apis[@]}"; do
            echo "  curl -X GET http://localhost:3000${api}"
        done
    fi

    return 0
}

# ============================================================
# Score
# ============================================================
cia_score() {
    # Score based on analysis coverage
    if [[ $CIA_ANALYZED_FILES -eq 0 ]]; then
        echo "30"
        return 0
    fi

    local score=50
    [[ $CIA_ANALYZED_FILES -gt 10 ]] && score=$((score + 10))
    [[ $CIA_ANALYZED_FILES -gt 50 ]] && score=$((score + 10))
    [[ $CIA_TOTAL_DEPS -gt 20 ]] && score=$((score + 10))
    [[ $CIA_TOTAL_DEPS -gt 100 ]] && score=$((score + 10))

    # Deduct for high risk
    if [[ $CIA_RISK_SCORE -gt 80 ]]; then
        score=$((score - 15))
    elif [[ $CIA_RISK_SCORE -gt 60 ]]; then
        score=$((score - 8))
    fi

    [[ $score -gt 100 ]] && score=100
    [[ $score -lt 0 ]] && score=0
    echo "$score"
}

# ============================================================
# Report
# ============================================================
cia_report() {
    echo -e "\n  ${BOLD:-}=== Change Impact Analyzer v${CIA_VERSION} ===${NC:-}"
    echo -e "  Files analyzed:   ${CIA_ANALYZED_FILES}"
    echo -e "  Dependencies:     ${CIA_TOTAL_DEPS}"
    echo -e "  Affected files:   ${CIA_AFFECTED_COUNT}"
    echo -e "  Risk score:       ${CIA_RISK_SCORE}/100"
    echo -e "  Last analysis:    ${CIA_LAST_ANALYSIS:-none}"
    echo -e "  Score:            $(cia_score)/100"
}

# ============================================================
# Module Registry self-registration
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "change-impact-analyzer" \
        --version "$CIA_VERSION" \
        --description "変更影響分析 - 依存グラフベースのリスクスコア・テスト推薦" \
        --init "cia_init" \
        --report "cia_report" \
        --score "cia_score" \
        --enable-var "ENABLE_CIA" \
        --cli-flags "--change-impact:--no-change-impact"
fi

# v2003.1: source時のexit codeを確実に0にする
true
