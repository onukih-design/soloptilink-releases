#!/usr/bin/env bash
# universal-task-router.sh v2012.0 - ユニバーサルタスクルーター
# SoloptiLinkAI の全タスクタイプを統一的にルーティング
#
# 役割:
#   ユーザーの入力からタスクタイプを判定し、
#   適切なドメインJSON + 品質フレームワーク + 実行パイプラインを選択する
#
# タスクタイプ:
#   1. system_development - システム開発（従来のchain.sh フロー）
#   2. web_creative       - LP/サイト/CMS 開発
#   3. creative_production - 動画制作/編集
#   4. document_creation  - PPTX/DOCX/PDF 制作
#   5. data_analysis      - データ分析/可視化

UTR_VERSION="2012.0"
UTR_DOMAINS_DIR="${SOLOPTILINK_ROOT:-$(dirname "$(dirname "$0")")}/domains"

# ────────────────────────────────────────────
# タスクタイプ判定キーワードマップ
# ────────────────────────────────────────────

declare -A UTR_KEYWORDS

# web_creative: LP/サイト開発
UTR_WEB_CREATIVE_KEYWORDS="lp|landing|ランディング|LP|ホームページ|HP|コーポレート|企業サイト|会社サイト|サイト構築|サイト開発|ウェブサイト|website|cms|コンテンツ管理|サイト制作|web制作|ウェブ制作|サイトリニューアル|ホームページ制作"

# creative_production: 動画
UTR_VIDEO_KEYWORDS="動画|video|映像|YouTube|TikTok|リール|Reels|ショート動画|動画編集|動画制作|映像制作|CM|プロモーション動画|ムービー|vlog|サムネイル|テロップ|字幕"

# document_creation: プレゼン/ドキュメント
UTR_PPTX_KEYWORDS="プレゼン|スライド|PowerPoint|PPTX|パワポ|Keynote|ピッチ|pitch|deck|営業資料|提案書|発表資料"
UTR_DOC_KEYWORDS="ドキュメント|文書|書類|Word|docx|要件定義|仕様書|設計書|マニュアル|議事録|契約書|報告書|レポート|ホワイトペーパー"

# ────────────────────────────────────────────
# メイン判定関数
# ────────────────────────────────────────────

utr_detect_task_type() {
    local input="$1"
    local input_lower
    input_lower=$(echo "$input" | tr '[:upper:]' '[:lower:]')

    # 1. web_creative チェック
    if echo "$input_lower" | grep -qiE "$UTR_WEB_CREATIVE_KEYWORDS"; then
        # LP と コーポレートサイト を区別
        if echo "$input_lower" | grep -qiE "lp|landing|ランディング|集客|cv|コンバージョン|リード|キャンペーン|プロモーション|セールス"; then
            echo "web_creative:landing-page"
        else
            echo "web_creative:corporate-site"
        fi
        return 0
    fi

    # 2. creative_production チェック（動画）
    if echo "$input_lower" | grep -qiE "$UTR_VIDEO_KEYWORDS"; then
        echo "creative_production:video-production"
        return 0
    fi

    # 3. document_creation チェック（PPTX）
    if echo "$input_lower" | grep -qiE "$UTR_PPTX_KEYWORDS"; then
        echo "document_creation:presentation"
        return 0
    fi

    # 4. document_creation チェック（DOCX）
    if echo "$input_lower" | grep -qiE "$UTR_DOC_KEYWORDS"; then
        echo "document_creation:document"
        return 0
    fi

    # 5. デフォルト: system_development（既存フロー）
    echo "system_development:auto"
    return 0
}

# ────────────────────────────────────────────
# ドメインJSON読み込み
# ────────────────────────────────────────────

utr_load_domain() {
    local domain_name="$1"
    local domain_file="${UTR_DOMAINS_DIR}/${domain_name}.json"

    if [ -f "$domain_file" ]; then
        cat "$domain_file"
        return 0
    else
        echo "{\"error\": \"Domain not found: ${domain_name}\"}"
        return 1
    fi
}

# ────────────────────────────────────────────
# タスクタイプ別パイプライン定義
# ────────────────────────────────────────────

utr_get_pipeline() {
    local task_type="$1"

    case "$task_type" in
        system_development)
            # 従来の chain.sh フルパイプライン
            echo "prompt_expand→scaffold→design→implement→quality_gate→smoke_test→deploy"
            ;;
        web_creative)
            # LP/サイト開発パイプライン
            echo "brand_analysis→section_design→implement→design_review→performance_check→seo_audit→deploy"
            ;;
        creative_production)
            # 動画制作パイプライン
            echo "concept→storyboard→script→edit_instructions→asset_list→export_settings"
            ;;
        document_creation)
            # ドキュメント制作パイプライン
            echo "structure→content_draft→formatting→review→export"
            ;;
        *)
            echo "auto_detect→execute"
            ;;
    esac
}

# ────────────────────────────────────────────
# タスクタイプ別品質ゲート
# ────────────────────────────────────────────

utr_get_quality_axes() {
    local task_type="$1"

    case "$task_type" in
        system_development)
            # 既存の10軸品質ゲート
            echo "mock_data|event_handlers|db_integration|api_connectivity|crud_completeness|enterprise_patterns|interaction_score|build_integrity|anti_slop|secret_safety"
            ;;
        web_creative)
            # LP/サイト開発品質ゲート
            echo "brand_consistency|cv_optimization|responsive_design|performance_metrics|seo_compliance|accessibility|animation_quality|cms_operability|content_quality|mobile_first"
            ;;
        creative_production)
            # 動画制作品質ゲート
            echo "hook_effectiveness|pacing|text_readability|audio_balance|brand_consistency|cta_presence|platform_optimization|color_consistency|resolution_quality|thumbnail_quality"
            ;;
        document_creation)
            # ドキュメント制作品質ゲート
            echo "structure_completeness|formatting_consistency|terminology_unity|figure_numbering|readability|revision_history|confidentiality|print_compatibility|content_accuracy|style_guide"
            ;;
    esac
}

# ────────────────────────────────────────────
# タスクタイプ別エージェント割り当て
# ────────────────────────────────────────────

utr_get_agents() {
    local task_type="$1"

    case "$task_type" in
        system_development)
            echo "pm,backend-dev,frontend-dev,designer,qa-engineer,devops,db-architect,security-auditor,api-designer"
            ;;
        web_creative)
            echo "pm,frontend-dev,designer,ux-researcher,qa-engineer,accessibility-auditor,devops"
            ;;
        creative_production)
            echo "pm,designer,ux-researcher"
            ;;
        document_creation)
            echo "pm,documentation-writer"
            ;;
    esac
}

# ────────────────────────────────────────────
# ルーティング結果サマリー出力
# ────────────────────────────────────────────

utr_route_summary() {
    local input="$1"
    local result
    result=$(utr_detect_task_type "$input")

    local task_type="${result%%:*}"
    local domain="${result##*:}"
    local pipeline
    pipeline=$(utr_get_pipeline "$task_type")
    local quality_axes
    quality_axes=$(utr_get_quality_axes "$task_type")
    local agents
    agents=$(utr_get_agents "$task_type")

    cat <<EOF
{
  "task_type": "${task_type}",
  "domain": "${domain}",
  "pipeline": "${pipeline}",
  "quality_axes": "${quality_axes}",
  "agents": "${agents}",
  "domain_file": "${UTR_DOMAINS_DIR}/${domain}.json"
}
EOF
}

# ────────────────────────────────────────────
# ドメイン一覧
# ────────────────────────────────────────────

utr_list_domains() {
    echo "=== SoloptiLinkAI ドメイン一覧 ==="
    echo ""
    echo "【システム開発】(23ドメイン)"
    for f in "${UTR_DOMAINS_DIR}"/*.json; do
        local name
        name=$(basename "$f" .json)
        local desc
        desc=$(grep -o '"description": "[^"]*"' "$f" 2>/dev/null | head -1 | sed 's/"description": "//;s/"$//')
        if [ "$name" != "_base" ] && [ "$name" != "landing-page" ] && [ "$name" != "corporate-site" ] && [ "$name" != "video-production" ] && [ "$name" != "presentation" ] && [ "$name" != "document" ]; then
            echo "  - ${name}: ${desc}"
        fi
    done
    echo ""
    echo "【Web クリエイティブ】(2ドメイン)"
    echo "  - landing-page: LP/ランディングページ開発"
    echo "  - corporate-site: コーポレートサイト/CMS構築"
    echo ""
    echo "【クリエイティブ制作】(1ドメイン)"
    echo "  - video-production: 動画制作/編集"
    echo ""
    echo "【ドキュメント制作】(2ドメイン)"
    echo "  - presentation: プレゼンテーション/PPTX制作"
    echo "  - document: ドキュメント/DOCX制作"
}

# エクスポート
export -f utr_detect_task_type 2>/dev/null
export -f utr_load_domain 2>/dev/null
export -f utr_get_pipeline 2>/dev/null
export -f utr_get_quality_axes 2>/dev/null
export -f utr_get_agents 2>/dev/null
export -f utr_route_summary 2>/dev/null
export -f utr_list_domains 2>/dev/null
