#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v120.0 - Completion Checklist Engine
# =============================================================================
# プロンプト末尾に自己検証チェックリストを注入。
# Claudeがコード出力前に全項目を確認することで、初回生成品質を向上。
#
# 原理: LLMは「出力前にチェックリストを確認せよ」という指示に従い、
#        自己検証によって省略・手抜きを防止する。
#
# 全globals: CCL_ prefix
# =============================================================================

[[ -n "${_COMPLETION_CHECKLIST_LOADED:-}" ]] && return 0
_COMPLETION_CHECKLIST_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g CCL_VERSION="120.0"
declare -g CCL_INITIALIZED=false
declare -g CCL_INJECT_COUNT=0

# =============================================================================
# 初期化
# =============================================================================
ccl_init() {
    CCL_INITIALIZED=true
    CCL_INJECT_COUNT=0
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} Completion Checklist v${CCL_VERSION}"
}

# =============================================================================
# フェーズ別チェックリスト生成
# =============================================================================
ccl_get_checklist() {
    local phase="${1:-implementation}"
    local domain="${2:-general}"

    local checklist=""

    # --- 共通チェックリスト ---
    checklist+="
# ============================================================
# 出力前チェックリスト v120.0（省略厳禁 - 全項目を確認してから出力せよ）
# ============================================================
# このチェックリストの全項目をパスしない限り、コードを出力してはいけません。
# 1つでも違反があれば、該当箇所を修正してから出力してください。
# ============================================================

## 基本品質チェック
□ モックデータ・ハードコード配列は一切使用していないか？（全データはDB/API経由）
□ console.log/alert/TODO/FIXME は一切残っていないか？
□ any型・as キャストは使用していないか？
□ 全てのimportは名前付きインポートで、存在するファイルを参照しているか？"

    # --- フロントエンドチェック ---
    case "$phase" in
        frontend|ui_design|implementation|frontend_pages|frontend_core|pages)
            checklist+="

## UI完全性チェック（Golden Pattern準拠）
□ 全てのボタンのonClickは実際の関数を呼び出しているか？
  - console.log/alert/空関数 → 禁止。必ずAPI呼び出しまたはrouter.push()
□ 全てのrouter.push()の遷移先ページファイルを出力に含めたか？
  - router.push('/items/new') → app/items/new/page.tsx が出力に必要
□ 全てのfetch()/useSWR()のURLはAPIルートファイルのパスと完全一致するか？
  - fetch('/api/items') → app/api/items/route.ts が存在するか確認
□ 全てのデータ取得箇所に4状態があるか？
  - loading状態（スケルトンまたはスピナー）
  - error状態（エラーメッセージ + 再試行ボタン）
  - empty状態（「データがありません」メッセージ）
  - success状態（データ表示）
□ 全てのフォームに以下があるか？
  - React Hook Form + zodResolver
  - 各フィールドにfield-levelエラー表示
  - onSubmit（API呼び出し + エラー処理 + 成功時遷移）
  - 送信ボタンにdisabled={isSubmitting} + loading表示
  - サーバーエラー表示領域
□ 全ての削除ボタンに確認ダイアログがあるか？
  - confirm() または AlertDialog
  - 削除中のdisabled状態
  - 削除後のデータ再取得（mutate()）
□ href=\"#\" を使用していないか？（全リンクは実URLを設定）
□ ErrorBoundaryで全ページをラップしているか？"
            ;;
    esac

    # --- バックエンドチェック ---
    case "$phase" in
        backend|api|database|implementation)
            checklist+="

## API品質チェック
□ 全APIエンドポイントの入力にzodバリデーションがあるか？
□ 全async関数にtry-catch + 適切なHTTPステータスコードがあるか？
  - 200: 成功, 201: 作成成功, 400: バリデーションエラー, 404: 未検出, 500: サーバーエラー
□ 複数テーブル操作にprisma.\$transaction()を使用しているか？
□ CUD操作に監査ログ（auditLog.create）があるか？
□ パスワードはbcrypt/argon2idでハッシュしているか？（平文保存禁止）
□ レスポンス形式は { success: boolean, data?: T, error?: string } で統一されているか？"
            ;;
    esac

    # --- スキーマチェック ---
    case "$phase" in
        schema|database|implementation)
            checklist+="

## スキーマ品質チェック
□ Prismaスキーマの全モデルにid, createdAt, updatedAtがあるか？
□ zodバリデーションスキーマはPrismaスキーマの全必須フィールドをカバーしているか？
□ リレーション（1:N, N:N）は正しく定義されているか？"
            ;;
    esac

    # --- ドメイン固有チェック ---
    case "$domain" in
        crm|sales)
            checklist+="

## CRM固有チェック
□ 顧客ステータス遷移（lead→prospect→customer→churned）は実装されているか？
□ 担当者アサイン機能は動作するか？
□ 商談（Deal）のパイプラインビューは実装されているか？"
            ;;
        ec|ecommerce|shop)
            checklist+="

## EC固有チェック
□ カート操作（追加/数量変更/削除）は全て動作するか？
□ 在庫数のリアルタイム反映はあるか？
□ 注文フローは完結するか（カート→確認→決済→完了）？"
            ;;
        task|project|todo)
            checklist+="

## タスク管理固有チェック
□ タスクのドラッグ&ドロップ（ステータス変更）は動作するか？
□ 担当者フィルタリングは実装されているか？
□ 期限アラートは表示されるか？"
            ;;
        chat|messaging)
            checklist+="

## チャット固有チェック
□ WebSocket接続 + 再接続ロジックは実装されているか？
□ メッセージの送信 + リアルタイム受信は動作するか？
□ 過去メッセージの取得 + 無限スクロールはあるか？"
            ;;
    esac

    checklist+="

# ============================================================
# 上記の全項目を確認した上で、コードを出力してください。
# 違反が1つでもあれば、品質ゲートで自動FAIL → 修正ループに入ります。
# 最初から全項目をパスすれば、修正ループ不要で高速に完了します。
# ============================================================"

    echo "$checklist"
}

# =============================================================================
# プロンプトへのチェックリスト注入
# =============================================================================
ccl_inject_into_prompt() {
    local prompt="$1"
    local phase="${2:-implementation}"
    local domain="${3:-general}"

    CCL_INJECT_COUNT=$((CCL_INJECT_COUNT + 1))

    local checklist
    checklist=$(ccl_get_checklist "$phase" "$domain")

    echo "${prompt}

${checklist}"
}

# =============================================================================
# v152: Completion Checklist enforcement
# =============================================================================
ccl_verify_output() {
    local output="$1"
    local phase="${2:-frontend}"
    local domain="${3:-general}"
    local missing_items=()
    local total_items=0
    local passed_items=0

    # Frontend checklist verification
    if [[ "$phase" == "frontend" || "$phase" == "implementation" ]]; then
        total_items=$((total_items + 5))
        # Check: loading state
        if echo "$output" | grep -qiE 'loading|isLoading|Skeleton|spinner|animate-pulse'; then
            passed_items=$((passed_items + 1))
        else
            missing_items+=("loading状態の実装が欠落")
        fi
        # Check: error handling
        if echo "$output" | grep -qiE 'error|isError|catch\s*\(|ErrorBoundary'; then
            passed_items=$((passed_items + 1))
        else
            missing_items+=("エラーハンドリングが欠落")
        fi
        # Check: form validation
        if echo "$output" | grep -qiE 'zodResolver|useForm|validation|required'; then
            passed_items=$((passed_items + 1))
        else
            missing_items+=("フォームバリデーションが欠落")
        fi
        # Check: onClick handlers not empty
        if echo "$output" | grep -qE 'onClick=\{[^}]+\}' && ! echo "$output" | grep -qE 'onClick=\{\(\)\s*=>\s*\{\s*\}\}'; then
            passed_items=$((passed_items + 1))
        else
            missing_items+=("onClick空ハンドラが存在")
        fi
        # Check: try-catch around API calls
        if echo "$output" | grep -qE 'try\s*\{' || ! echo "$output" | grep -qE 'fetch\s*\(|axios'; then
            passed_items=$((passed_items + 1))
        else
            missing_items+=("API呼出のtry-catchが欠落")
        fi
    fi

    # Export results
    CCL_TOTAL_ITEMS=$total_items
    CCL_PASSED_ITEMS=$passed_items
    CCL_MISSING_ITEMS=("${missing_items[@]}")

    if [[ ${#missing_items[@]} -gt 0 ]]; then
        echo -e "  ⚠️ [v152] Checklist不合格: ${#missing_items[@]}件欠落" >&2
        printf '    - %s\n' "${missing_items[@]}" >&2
        return 1
    fi
    return 0
}

# =============================================================================
# レポート
# =============================================================================
ccl_report() {
    echo -e "\n  ${BOLD:-}═══ Completion Checklist v${CCL_VERSION} ═══${NC:-}"
    echo -e "  注入回数  : ${CCL_INJECT_COUNT}"
}

ccl_report_json() {
    cat <<EOF
{"module":"completion-checklist","version":"${CCL_VERSION}","inject_count":${CCL_INJECT_COUNT}}
EOF
}

ccl_score() {
    [[ "$CCL_INITIALIZED" == "true" ]] && echo 100 || echo 0
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "completion-checklist" \
        --version "152.0" \
        --description "出力前自己検証チェックリスト注入" \
        --init "ccl_init" \
        --report "ccl_report" \
        --score "ccl_score" \
        --enable-var "ENABLE_COMPLETION_CHECKLIST" \
        --cli-flags "--completion-checklist:--no-completion-checklist"
fi

# v2003.1: source時のexit codeを確実に0にする
true
