#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v394.0 - Migration Assistant
# =============================================================================
# マイグレーション支援エンジン。バージョン検出/移行計画/自動適用を提供。
# All globals use the MA2_ prefix.
# =============================================================================

[[ -n "${_MIGRATION_ASSISTANT_LOADED:-}" ]] && return 0
_MIGRATION_ASSISTANT_LOADED=1

declare -g MA2_VERSION="394.0"
declare -g MA2_INITIALIZED=false
declare -g MA2_GENERATED_COUNT=0
declare -g MA2_VERSION_DETECTED=false
declare -g MA2_PLAN_GENERATED=false
declare -g MA2_MIGRATION_APPLIED=false
declare -g MA2_ROLLBACK_GENERATED=false
declare -g ENABLE_MA2="${ENABLE_MA2:-true}"

_ma2_init() { MA2_INITIALIZED=true; MA2_GENERATED_COUNT=0; return 0; }

_ma2_generate_all() {
    local project_dir="${1:-.}"
    [[ "$MA2_INITIALIZED" != "true" ]] && _ma2_init
    echo -e "  ${CYAN:-\033[0;36m}[MA2]${NC:-\033[0m} マイグレーションアシスタント生成開始..." >&2
    _ma2_detect_version "$project_dir"
    _ma2_generate_migration_plan "$project_dir"
    _ma2_apply_migration "$project_dir"
    _ma2_generate_rollback "$project_dir"
    echo -e "  ${GREEN:-\033[0;32m}[MA2]${NC:-\033[0m} マイグレーション生成完了: ${MA2_GENERATED_COUNT}件" >&2
    return 0
}

_ma2_detect_version() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [MA2-DETECT] バージョン検出

### Dependency Version Analyzer
```typescript
interface DependencyInfo {
  name: string;
  currentVersion: string;
  latestVersion: string;
  isOutdated: boolean;
  hasBreakingChanges: boolean;
  migrationGuide?: string;
}

export async function detectVersions(packageJsonPath: string): Promise<DependencyInfo[]> {
  const pkg = JSON.parse(await readFile(packageJsonPath, 'utf-8'));
  const deps = { ...pkg.dependencies, ...pkg.devDependencies };
  const results: DependencyInfo[] = [];

  for (const [name, version] of Object.entries(deps)) {
    const current = (version as string).replace(/[\^~]/, '');
    const latest = await fetchLatestVersion(name);
    const majorDiff = semver.major(latest) - semver.major(current);
    results.push({
      name, currentVersion: current, latestVersion: latest,
      isOutdated: semver.lt(current, latest),
      hasBreakingChanges: majorDiff > 0,
      migrationGuide: majorDiff > 0 ? `https://github.com/${name}/blob/main/MIGRATION.md` : undefined,
    });
  }
  return results;
}

// Framework version detection
export function detectFrameworkVersions(pkg: any): Record<string, string> {
  const frameworks: Record<string, string> = {};
  if (pkg.dependencies?.next) frameworks.nextjs = pkg.dependencies.next;
  if (pkg.dependencies?.react) frameworks.react = pkg.dependencies.react;
  if (pkg.dependencies?.['@prisma/client']) frameworks.prisma = pkg.dependencies['@prisma/client'];
  if (pkg.dependencies?.typescript) frameworks.typescript = pkg.dependencies.typescript;
  return frameworks;
}
```
TEMPLATE
    MA2_VERSION_DETECTED=true
    MA2_GENERATED_COUNT=$((MA2_GENERATED_COUNT + 1))
    return 0
}

_ma2_generate_migration_plan() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [MA2-PLAN] マイグレーション計画

```typescript
interface MigrationPlan {
  from: string;
  to: string;
  steps: MigrationStep[];
  estimatedTime: string;
  riskLevel: 'low' | 'medium' | 'high';
  breakingChanges: string[];
}

const MIGRATION_GUIDES: Record<string, MigrationPlan> = {
  'next@13->14': {
    from: '13', to: '14', riskLevel: 'medium', estimatedTime: '2-4時間',
    breakingChanges: ['Server Actionsの安定化', 'Partial Prerenderingの追加'],
    steps: [
      { order: 1, description: 'package.json更新: next@14', command: 'npm install next@14' },
      { order: 2, description: 'next.config.js: experimental設定の確認', manual: true },
      { order: 3, description: 'Server Actions: "use server"の確認', manual: true },
      { order: 4, description: 'テスト実行', command: 'npm test' },
    ],
  },
  'prisma@4->5': {
    from: '4', to: '5', riskLevel: 'high', estimatedTime: '3-6時間',
    breakingChanges: ['クエリエンジンの変更', '一部APIの廃止'],
    steps: [
      { order: 1, description: 'Prisma CLI & Client更新', command: 'npm install prisma@5 @prisma/client@5' },
      { order: 2, description: 'prisma generate実行', command: 'npx prisma generate' },
      { order: 3, description: '廃止API（findMany.count等）の置換', manual: true },
      { order: 4, description: 'マイグレーション実行', command: 'npx prisma migrate dev' },
    ],
  },
};

export function generateMigrationPlan(dependency: string, fromVersion: string, toVersion: string): MigrationPlan | null {
  const key = `${dependency}@${semver.major(fromVersion)}->${semver.major(toVersion)}`;
  return MIGRATION_GUIDES[key] ?? null;
}
```
TEMPLATE
    MA2_PLAN_GENERATED=true
    MA2_GENERATED_COUNT=$((MA2_GENERATED_COUNT + 1))
    return 0
}

_ma2_apply_migration() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [MA2-APPLY] マイグレーション適用

```typescript
export class MigrationExecutor {
  async execute(plan: MigrationPlan): Promise<MigrationResult> {
    await exec('git checkout -b migration/' + plan.from + '-to-' + plan.to);
    const results: StepResult[] = [];

    for (const step of plan.steps) {
      if (step.manual) {
        results.push({ order: step.order, status: 'manual_required', description: step.description });
        continue;
      }
      try {
        await exec(step.command!);
        const testResult = await exec('npm test 2>&1 || true');
        results.push({ order: step.order, status: 'applied', description: step.description });
      } catch (error) {
        results.push({ order: step.order, status: 'failed', description: step.description, error: String(error) });
        break;
      }
    }
    return { plan, results, success: results.every(r => r.status !== 'failed') };
  }
}
```
TEMPLATE
    MA2_MIGRATION_APPLIED=true
    MA2_GENERATED_COUNT=$((MA2_GENERATED_COUNT + 1))
    return 0
}

_ma2_generate_rollback() {
    local project_dir="${1:-.}"
    cat <<'TEMPLATE'
## [MA2-ROLLBACK] ロールバック戦略

```typescript
export async function rollbackMigration(branchName: string) {
  await exec('git stash');
  await exec('git checkout main');
  await exec(`git branch -D ${branchName}`);
  await exec('npm install');
  await exec('npx prisma generate');
}
```
TEMPLATE
    MA2_ROLLBACK_GENERATED=true
    MA2_GENERATED_COUNT=$((MA2_GENERATED_COUNT + 1))
    return 0
}

_ma2_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Migration Assistant v${MA2_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成数             : ${MA2_GENERATED_COUNT}"
    echo -e "  バージョン検出     : ${MA2_VERSION_DETECTED}"
    echo -e "  計画生成           : ${MA2_PLAN_GENERATED}"
    echo -e "  適用               : ${MA2_MIGRATION_APPLIED}"
    echo -e "  ロールバック       : ${MA2_ROLLBACK_GENERATED}"
}

_ma2_score() {
    local score=30
    [[ "$MA2_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$MA2_VERSION_DETECTED" == "true" ]] && score=$((score + 15))
    [[ "$MA2_PLAN_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$MA2_MIGRATION_APPLIED" == "true" ]] && score=$((score + 15))
    [[ "$MA2_ROLLBACK_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "migration-assistant" \
    --version "394.0" \
    --description "マイグレーションアシスタント（検出/計画/適用/ロールバック）" \
    --init "_ma2_init" \
    --report "_ma2_report" \
    --score "_ma2_score" \
    --enable-var "ENABLE_MA2" \
    --cli-flags "--migration-assist:--no-migration-assist"
