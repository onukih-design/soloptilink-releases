#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v493.0 - Code Evolution Tracker
# =============================================================================
# コードベースの変化を追跡し、品質デルタを測定、進化を可視化する。
#
# Functions:
#   _cet_init                   - 初期化
#   _cet_track_changes          - 変更追跡
#   _cet_measure_quality_delta  - 品質デルタ測定
#   _cet_visualize_evolution    - 進化可視化
#   _cet_report / _cet_score
#
# Globals: CET_ prefix
# =============================================================================

[[ -n "${_CODE_EVOLUTION_TRACKER_LOADED:-}" ]] && return 0
_CODE_EVOLUTION_TRACKER_LOADED=1

CET_VERSION="493.0"
CET_INITIALIZED=false
CET_DATA_DIR=""
CET_CHANGES_LOG=""
CET_TOTAL_SNAPSHOTS=0
CET_QUALITY_TREND=""
CET_LINES_ADDED=0
CET_LINES_REMOVED=0
CET_NET_GROWTH=0

declare -g -A _CET_SNAPSHOTS=()
declare -g -A _CET_QUALITY_HISTORY=()
declare -g -a _CET_TIMELINE=()

_cet_init() {
    local project_dir="${PROJECT_DIR:-.}"
    CET_DATA_DIR="${project_dir}/.soloptilink/cet"
    CET_CHANGES_LOG="${CET_DATA_DIR}/changes.jsonl"
    mkdir -p "$CET_DATA_DIR"
    if [[ -f "$CET_CHANGES_LOG" ]]; then
        CET_TOTAL_SNAPSHOTS=$(wc -l < "$CET_CHANGES_LOG" 2>/dev/null || echo "0")
    fi
    CET_INITIALIZED=true
    return 0
}

_cet_track_changes() {
    local project_dir="${1:-.}"
    [[ "$CET_INITIALIZED" != "true" ]] && _cet_init

    local timestamp
    timestamp=$(date +%s)

    # Git diffからの変更量取得
    local added=0 removed=0
    if command -v git &>/dev/null && [[ -d "${project_dir}/.git" ]]; then
        local diff_stat
        diff_stat=$(cd "$project_dir" && git diff --stat HEAD 2>/dev/null | tail -1)
        added=$(echo "$diff_stat" | grep -oP '\d+ insertion' | grep -oP '\d+' || echo "0")
        removed=$(echo "$diff_stat" | grep -oP '\d+ deletion' | grep -oP '\d+' || echo "0")
    fi

    # ファイル数スナップショット
    local file_count
    file_count=$(find "$project_dir" -name "*.ts" -o -name "*.tsx" 2>/dev/null | grep -v node_modules | grep -v ".next" | wc -l)
    local line_count
    line_count=$(find "$project_dir" -name "*.ts" -o -name "*.tsx" 2>/dev/null | grep -v node_modules | grep -v ".next" | head -200 | xargs wc -l 2>/dev/null | tail -1 | awk '{print $1+0}')

    _CET_SNAPSHOTS["${timestamp}"]="${file_count}:${line_count}:${added}:${removed}"
    CET_LINES_ADDED=$((CET_LINES_ADDED + added))
    CET_LINES_REMOVED=$((CET_LINES_REMOVED + removed))
    CET_NET_GROWTH=$((CET_LINES_ADDED - CET_LINES_REMOVED))
    CET_TOTAL_SNAPSHOTS=$((CET_TOTAL_SNAPSHOTS + 1))
    _CET_TIMELINE+=("${timestamp}")

    echo "{\"ts\":${timestamp},\"files\":${file_count},\"lines\":${line_count},\"added\":${added},\"removed\":${removed}}" >> "$CET_CHANGES_LOG" 2>/dev/null

    echo "${file_count}:${line_count}"
    return 0
}

_cet_measure_quality_delta() {
    local current_score="$1"
    local phase="${2:-unknown}"

    [[ "$CET_INITIALIZED" != "true" ]] && _cet_init

    local timestamp
    timestamp=$(date +%s)
    _CET_QUALITY_HISTORY["${phase}::${timestamp}"]=$current_score

    # トレンド判定
    local prev_scores=()
    for key in "${!_CET_QUALITY_HISTORY[@]}"; do
        prev_scores+=("${_CET_QUALITY_HISTORY[$key]}")
    done

    if [[ ${#prev_scores[@]} -ge 2 ]]; then
        local last="${prev_scores[-1]}"
        local prev="${prev_scores[-2]}"
        local delta=$((last - prev))

        if [[ $delta -gt 5 ]]; then
            CET_QUALITY_TREND="improving"
        elif [[ $delta -lt -5 ]]; then
            CET_QUALITY_TREND="degrading"
        else
            CET_QUALITY_TREND="stable"
        fi
    else
        CET_QUALITY_TREND="insufficient_data"
    fi

    echo "${CET_QUALITY_TREND}"
    return 0
}

_cet_visualize_evolution() {
    [[ "$CET_INITIALIZED" != "true" ]] && _cet_init

    echo "=== Code Evolution Timeline ==="
    echo "Snapshots: ${CET_TOTAL_SNAPSHOTS}"
    echo "Lines added: +${CET_LINES_ADDED}"
    echo "Lines removed: -${CET_LINES_REMOVED}"
    echo "Net growth: ${CET_NET_GROWTH}"
    echo "Quality trend: ${CET_QUALITY_TREND}"

    # 直近のスナップショット表示
    local count=0
    for ts in "${_CET_TIMELINE[@]}"; do
        local data="${_CET_SNAPSHOTS[$ts]:-}"
        [[ -z "$data" ]] && continue
        echo "  [${ts}] files:lines:added:removed = ${data}"
        count=$((count + 1))
        [[ $count -ge 5 ]] && break
    done
}

_cet_report() {
    echo -e "\n  ${BOLD:-}═══ Code Evolution Tracker v${CET_VERSION} ═══${NC:-}"
    echo -e "  スナップショット数 : ${CET_TOTAL_SNAPSHOTS}"
    echo -e "  追加行数           : +${CET_LINES_ADDED}"
    echo -e "  削除行数           : -${CET_LINES_REMOVED}"
    echo -e "  純増減             : ${CET_NET_GROWTH}"
    echo -e "  品質トレンド       : ${CET_QUALITY_TREND}"
}

_cet_score() {
    [[ "$CET_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    local s=60
    [[ $CET_TOTAL_SNAPSHOTS -gt 0 ]] && s=$((s + 15))
    [[ "$CET_QUALITY_TREND" == "improving" ]] && s=$((s + 25))
    [[ "$CET_QUALITY_TREND" == "stable" ]] && s=$((s + 15))
    [[ $s -gt 100 ]] && s=100
    echo "$s"
}

_cet_init_message() {
    echo -e "  ${GREEN:-}✅ v${CET_VERSION} code-evolution-tracker: コード進化トラッカー${NC:-}" >&2
}

_mr_register \
    --name "code-evolution-tracker" \
    --version "$CET_VERSION" \
    --description "コード進化トラッカー" \
    --init "_cet_init" \
    --report "_cet_report" \
    --score "_cet_score" \
    --enable-var "ENABLE_CODE_EVOLUTION_TRACKER" \
    --cli-flags "--code-evolution:--no-code-evolution" \
    --init-msg "_cet_init_message"
