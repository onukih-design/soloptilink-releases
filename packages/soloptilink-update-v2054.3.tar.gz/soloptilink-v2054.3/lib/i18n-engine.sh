#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - i18n Engine
# =============================================================================
# 国際化基盤×next-intl/react-i18next×ロケール検出×RTLサポート
#
# 機能:
#   - i18n セットアップ（next-intl / i18next 設定）
#   - 翻訳ファイル生成（ja/en/zh/ko 構造化JSON）
#   - useTranslation フック（名前空間サポート）
#   - 言語切替UIコンポーネント
#   - 日付/数値/通貨フォーマット（ロケール別）
#   - RTLレイアウトサポート（アラビア語/ヘブライ語）
#   - 翻訳キー抽出（ソースコードからt()呼び出し抽出）
#   - Claude生成プロンプト注入
#
# 全globals: I18N_ prefix
# =============================================================================

[[ -n "${_I18N_LOADED:-}" ]] && return 0; _I18N_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g I18N_VERSION="140.0"
declare -g I18N_INITIALIZED=false
declare -g I18N_GENERATED=0
declare -g I18N_ERRORS=0
declare -g I18N_PHASE="i18n"

# =============================================================================
# 初期化
# =============================================================================
i18n_init() {
    I18N_INITIALIZED=true
    I18N_GENERATED=0
    I18N_ERRORS=0
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} i18n Engine v${I18N_VERSION}"
}

# =============================================================================
# ユーティリティ
# =============================================================================
_i18n_write_file() {
    local filepath="$1"
    local dir
    dir=$(dirname "$filepath")
    mkdir -p "$dir" 2>/dev/null
    cat > "$filepath"
    if [[ $? -eq 0 ]]; then
        I18N_GENERATED=$((I18N_GENERATED + 1))
        return 0
    else
        I18N_ERRORS=$((I18N_ERRORS + 1))
        return 1
    fi
}

# =============================================================================
# i18n セットアップ生成（next-intl ベース）
# =============================================================================
i18n_generate_setup() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local framework="${2:-next-intl}"

    # --- i18n configuration ---
    _i18n_write_file "${project_dir}/src/lib/i18n.ts" <<'TYPESCRIPT'
import { getRequestConfig } from 'next-intl/server';
import { notFound } from 'next/navigation';

export const locales = ['ja', 'en', 'zh', 'ko'] as const;
export type Locale = (typeof locales)[number];
export const defaultLocale: Locale = 'ja';

export const localeNames: Record<Locale, string> = {
  ja: '日本語',
  en: 'English',
  zh: '中文',
  ko: '한국어',
};

export function isValidLocale(locale: string): locale is Locale {
  return locales.includes(locale as Locale);
}

export default getRequestConfig(async ({ locale }) => {
  if (!isValidLocale(locale)) notFound();

  return {
    messages: (await import(`@/messages/${locale}.json`)).default,
    timeZone: getTimeZone(locale),
    now: new Date(),
  };
});

function getTimeZone(locale: Locale): string {
  const timezones: Record<Locale, string> = {
    ja: 'Asia/Tokyo',
    en: 'America/New_York',
    zh: 'Asia/Shanghai',
    ko: 'Asia/Seoul',
  };
  return timezones[locale] ?? 'UTC';
}
TYPESCRIPT

    # --- Middleware for locale detection ---
    _i18n_write_file "${project_dir}/src/middleware/i18n-middleware.ts" <<'TYPESCRIPT'
import createMiddleware from 'next-intl/middleware';
import { locales, defaultLocale } from '@/lib/i18n';

export default createMiddleware({
  locales,
  defaultLocale,
  localePrefix: 'as-needed',
  localeDetection: true,
});

export const config = {
  matcher: ['/((?!api|_next|_vercel|.*\\..*).*)'],
};
TYPESCRIPT

    # --- Navigation utilities ---
    _i18n_write_file "${project_dir}/src/lib/navigation.ts" <<'TYPESCRIPT'
import { createSharedPathnamesNavigation } from 'next-intl/navigation';
import { locales } from './i18n';

export const { Link, redirect, usePathname, useRouter } =
  createSharedPathnamesNavigation({ locales });
TYPESCRIPT

    # --- Layout with IntlProvider ---
    _i18n_write_file "${project_dir}/src/app/[locale]/layout.tsx" <<'TYPESCRIPT'
import { NextIntlClientProvider } from 'next-intl';
import { getMessages } from 'next-intl/server';
import { notFound } from 'next/navigation';
import { locales, Locale } from '@/lib/i18n';
import { ReactNode } from 'react';

interface Props {
  children: ReactNode;
  params: { locale: string };
}

export function generateStaticParams() {
  return locales.map((locale) => ({ locale }));
}

export default async function LocaleLayout({ children, params: { locale } }: Props) {
  if (!locales.includes(locale as Locale)) notFound();

  const messages = await getMessages();
  const dir = ['ar', 'he'].includes(locale) ? 'rtl' : 'ltr';

  return (
    <html lang={locale} dir={dir}>
      <body>
        <NextIntlClientProvider messages={messages}>
          {children}
        </NextIntlClientProvider>
      </body>
    </html>
  );
}
TYPESCRIPT
}

# =============================================================================
# 翻訳ファイル生成
# =============================================================================
i18n_generate_translation_files() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local locales_str="${2:-ja,en,zh,ko}"
    local msg_dir="${project_dir}/src/messages"

    # --- Japanese (default) ---
    _i18n_write_file "${msg_dir}/ja.json" <<'JSON'
{
  "common": {
    "appName": "SoloptiLinkAI",
    "loading": "読み込み中...",
    "error": "エラーが発生しました",
    "retry": "再試行",
    "save": "保存",
    "cancel": "キャンセル",
    "delete": "削除",
    "edit": "編集",
    "create": "新規作成",
    "search": "検索",
    "noData": "データがありません",
    "confirm": "確認",
    "back": "戻る",
    "next": "次へ",
    "submit": "送信",
    "close": "閉じる",
    "yes": "はい",
    "no": "いいえ"
  },
  "auth": {
    "login": "ログイン",
    "logout": "ログアウト",
    "register": "新規登録",
    "email": "メールアドレス",
    "password": "パスワード",
    "forgotPassword": "パスワードを忘れた方",
    "resetPassword": "パスワードリセット",
    "loginFailed": "ログインに失敗しました",
    "registerFailed": "登録に失敗しました"
  },
  "nav": {
    "home": "ホーム",
    "dashboard": "ダッシュボード",
    "settings": "設定",
    "profile": "プロフィール",
    "help": "ヘルプ"
  },
  "validation": {
    "required": "{field}は必須です",
    "minLength": "{field}は{min}文字以上で入力してください",
    "maxLength": "{field}は{max}文字以内で入力してください",
    "invalidEmail": "有効なメールアドレスを入力してください",
    "passwordTooShort": "パスワードは8文字以上で入力してください"
  },
  "table": {
    "showing": "{total}件中 {from}〜{to}件を表示",
    "noResults": "該当するデータがありません",
    "rowsPerPage": "表示件数",
    "page": "ページ"
  }
}
JSON

    # --- English ---
    _i18n_write_file "${msg_dir}/en.json" <<'JSON'
{
  "common": {
    "appName": "SoloptiLinkAI",
    "loading": "Loading...",
    "error": "An error occurred",
    "retry": "Retry",
    "save": "Save",
    "cancel": "Cancel",
    "delete": "Delete",
    "edit": "Edit",
    "create": "Create New",
    "search": "Search",
    "noData": "No data available",
    "confirm": "Confirm",
    "back": "Back",
    "next": "Next",
    "submit": "Submit",
    "close": "Close",
    "yes": "Yes",
    "no": "No"
  },
  "auth": {
    "login": "Log In",
    "logout": "Log Out",
    "register": "Sign Up",
    "email": "Email",
    "password": "Password",
    "forgotPassword": "Forgot Password?",
    "resetPassword": "Reset Password",
    "loginFailed": "Login failed",
    "registerFailed": "Registration failed"
  },
  "nav": {
    "home": "Home",
    "dashboard": "Dashboard",
    "settings": "Settings",
    "profile": "Profile",
    "help": "Help"
  },
  "validation": {
    "required": "{field} is required",
    "minLength": "{field} must be at least {min} characters",
    "maxLength": "{field} must be at most {max} characters",
    "invalidEmail": "Please enter a valid email address",
    "passwordTooShort": "Password must be at least 8 characters"
  },
  "table": {
    "showing": "Showing {from} to {to} of {total} results",
    "noResults": "No results found",
    "rowsPerPage": "Rows per page",
    "page": "Page"
  }
}
JSON

    # --- Chinese (Simplified) ---
    _i18n_write_file "${msg_dir}/zh.json" <<'JSON'
{
  "common": {
    "appName": "SoloptiLinkAI",
    "loading": "加载中...",
    "error": "发生错误",
    "retry": "重试",
    "save": "保存",
    "cancel": "取消",
    "delete": "删除",
    "edit": "编辑",
    "create": "新建",
    "search": "搜索",
    "noData": "暂无数据",
    "confirm": "确认",
    "back": "返回",
    "next": "下一步",
    "submit": "提交",
    "close": "关闭",
    "yes": "是",
    "no": "否"
  },
  "auth": {
    "login": "登录",
    "logout": "退出登录",
    "register": "注册",
    "email": "邮箱地址",
    "password": "密码",
    "forgotPassword": "忘记密码？",
    "resetPassword": "重置密码",
    "loginFailed": "登录失败",
    "registerFailed": "注册失败"
  },
  "nav": {
    "home": "首页",
    "dashboard": "仪表盘",
    "settings": "设置",
    "profile": "个人资料",
    "help": "帮助"
  },
  "validation": {
    "required": "{field}为必填项",
    "minLength": "{field}至少需要{min}个字符",
    "maxLength": "{field}最多{max}个字符",
    "invalidEmail": "请输入有效的邮箱地址",
    "passwordTooShort": "密码至少需要8个字符"
  },
  "table": {
    "showing": "显示第{from}到{to}条，共{total}条",
    "noResults": "未找到结果",
    "rowsPerPage": "每页显示",
    "page": "页"
  }
}
JSON

    # --- Korean ---
    _i18n_write_file "${msg_dir}/ko.json" <<'JSON'
{
  "common": {
    "appName": "SoloptiLinkAI",
    "loading": "로딩 중...",
    "error": "오류가 발생했습니다",
    "retry": "재시도",
    "save": "저장",
    "cancel": "취소",
    "delete": "삭제",
    "edit": "수정",
    "create": "새로 만들기",
    "search": "검색",
    "noData": "데이터가 없습니다",
    "confirm": "확인",
    "back": "뒤로",
    "next": "다음",
    "submit": "제출",
    "close": "닫기",
    "yes": "예",
    "no": "아니요"
  },
  "auth": {
    "login": "로그인",
    "logout": "로그아웃",
    "register": "회원가입",
    "email": "이메일",
    "password": "비밀번호",
    "forgotPassword": "비밀번호를 잊으셨나요?",
    "resetPassword": "비밀번호 재설정",
    "loginFailed": "로그인에 실패했습니다",
    "registerFailed": "가입에 실패했습니다"
  },
  "nav": {
    "home": "홈",
    "dashboard": "대시보드",
    "settings": "설정",
    "profile": "프로필",
    "help": "도움말"
  },
  "validation": {
    "required": "{field}은(는) 필수입니다",
    "minLength": "{field}은(는) 최소 {min}자 이상이어야 합니다",
    "maxLength": "{field}은(는) 최대 {max}자까지 입력할 수 있습니다",
    "invalidEmail": "유효한 이메일 주소를 입력해주세요",
    "passwordTooShort": "비밀번호는 최소 8자 이상이어야 합니다"
  },
  "table": {
    "showing": "전체 {total}건 중 {from}~{to}건 표시",
    "noResults": "결과를 찾을 수 없습니다",
    "rowsPerPage": "페이지당 행 수",
    "page": "페이지"
  }
}
JSON
}

# =============================================================================
# useTranslation フック生成（名前空間サポート）
# =============================================================================
i18n_generate_translation_hook() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _i18n_write_file "${project_dir}/src/hooks/useAppTranslation.ts" <<'TYPESCRIPT'
'use client';
import { useTranslations, useLocale } from 'next-intl';
import { useCallback } from 'react';
import type { Locale } from '@/lib/i18n';

/**
 * Enhanced translation hook with namespace support and formatting.
 *
 * Usage:
 *   const { t, locale, formatDate, formatNumber, formatCurrency } = useAppTranslation('common');
 *   <p>{t('loading')}</p>
 *   <p>{formatDate(new Date())}</p>
 *   <p>{formatCurrency(1500)}</p>
 */
export function useAppTranslation(namespace?: string) {
  const t = useTranslations(namespace);
  const locale = useLocale() as Locale;

  const formatDate = useCallback(
    (date: Date | string, options?: Intl.DateTimeFormatOptions) => {
      const d = typeof date === 'string' ? new Date(date) : date;
      return new Intl.DateTimeFormat(locale, {
        year: 'numeric',
        month: 'long',
        day: 'numeric',
        ...options,
      }).format(d);
    },
    [locale]
  );

  const formatNumber = useCallback(
    (num: number, options?: Intl.NumberFormatOptions) => {
      return new Intl.NumberFormat(locale, options).format(num);
    },
    [locale]
  );

  const formatCurrency = useCallback(
    (amount: number, currency?: string) => {
      const currencyMap: Record<string, string> = {
        ja: 'JPY',
        en: 'USD',
        zh: 'CNY',
        ko: 'KRW',
      };
      return new Intl.NumberFormat(locale, {
        style: 'currency',
        currency: currency ?? currencyMap[locale] ?? 'USD',
      }).format(amount);
    },
    [locale]
  );

  const formatRelativeTime = useCallback(
    (date: Date | string) => {
      const d = typeof date === 'string' ? new Date(date) : date;
      const now = new Date();
      const diffMs = now.getTime() - d.getTime();
      const diffSec = Math.floor(diffMs / 1000);
      const diffMin = Math.floor(diffSec / 60);
      const diffHour = Math.floor(diffMin / 60);
      const diffDay = Math.floor(diffHour / 24);

      const rtf = new Intl.RelativeTimeFormat(locale, { numeric: 'auto' });

      if (diffDay > 0) return rtf.format(-diffDay, 'day');
      if (diffHour > 0) return rtf.format(-diffHour, 'hour');
      if (diffMin > 0) return rtf.format(-diffMin, 'minute');
      return rtf.format(-diffSec, 'second');
    },
    [locale]
  );

  return { t, locale, formatDate, formatNumber, formatCurrency, formatRelativeTime };
}
TYPESCRIPT
}

# =============================================================================
# 言語切替UIコンポーネント生成
# =============================================================================
i18n_generate_locale_switcher() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _i18n_write_file "${project_dir}/src/components/LocaleSwitcher.tsx" <<'TYPESCRIPT'
'use client';
import { useLocale } from 'next-intl';
import { useRouter, usePathname } from '@/lib/navigation';
import { locales, localeNames, Locale } from '@/lib/i18n';
import { useState, useRef, useEffect } from 'react';

/**
 * Language switcher dropdown component.
 * Renders current locale flag + name with a dropdown to switch.
 */
export function LocaleSwitcher() {
  const locale = useLocale() as Locale;
  const router = useRouter();
  const pathname = usePathname();
  const [isOpen, setIsOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  // Close dropdown on outside click
  useEffect(() => {
    function handleClickOutside(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const localeFlags: Record<Locale, string> = {
    ja: '\u{1F1EF}\u{1F1F5}',
    en: '\u{1F1FA}\u{1F1F8}',
    zh: '\u{1F1E8}\u{1F1F3}',
    ko: '\u{1F1F0}\u{1F1F7}',
  };

  const handleChange = (newLocale: Locale) => {
    setIsOpen(false);
    router.replace(pathname, { locale: newLocale });
  };

  return (
    <div ref={ref} className="relative inline-block">
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 border rounded-lg hover:bg-gray-50 transition-colors"
        aria-label="Switch language"
        aria-expanded={isOpen}
      >
        <span>{localeFlags[locale]}</span>
        <span className="text-sm">{localeNames[locale]}</span>
        <svg className={`w-4 h-4 transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-1 w-48 bg-white border rounded-lg shadow-lg z-50">
          {locales.map((l) => (
            <button
              key={l}
              onClick={() => handleChange(l)}
              className={`w-full flex items-center gap-3 px-4 py-2 text-sm hover:bg-gray-50 first:rounded-t-lg last:rounded-b-lg ${
                l === locale ? 'bg-blue-50 text-blue-700 font-medium' : 'text-gray-700'
              }`}
            >
              <span>{localeFlags[l]}</span>
              <span>{localeNames[l]}</span>
              {l === locale && (
                <svg className="w-4 h-4 ml-auto" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                </svg>
              )}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
TYPESCRIPT
}

# =============================================================================
# 日付/数値/通貨フォーマット生成
# =============================================================================
i18n_generate_date_format() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _i18n_write_file "${project_dir}/src/lib/formatters.ts" <<'TYPESCRIPT'
import type { Locale } from './i18n';

/**
 * Locale-aware date formatting utilities.
 */
export const dateFormats = {
  short: (date: Date, locale: Locale) =>
    new Intl.DateTimeFormat(locale, { year: 'numeric', month: '2-digit', day: '2-digit' }).format(date),

  long: (date: Date, locale: Locale) =>
    new Intl.DateTimeFormat(locale, { year: 'numeric', month: 'long', day: 'numeric', weekday: 'long' }).format(date),

  datetime: (date: Date, locale: Locale) =>
    new Intl.DateTimeFormat(locale, {
      year: 'numeric', month: 'short', day: 'numeric',
      hour: '2-digit', minute: '2-digit',
    }).format(date),

  relative: (date: Date, locale: Locale) => {
    const now = new Date();
    const diffMs = now.getTime() - date.getTime();
    const diffSec = Math.floor(diffMs / 1000);
    const diffMin = Math.floor(diffSec / 60);
    const diffHour = Math.floor(diffMin / 60);
    const diffDay = Math.floor(diffHour / 24);

    const rtf = new Intl.RelativeTimeFormat(locale, { numeric: 'auto' });
    if (Math.abs(diffDay) > 0) return rtf.format(-diffDay, 'day');
    if (Math.abs(diffHour) > 0) return rtf.format(-diffHour, 'hour');
    if (Math.abs(diffMin) > 0) return rtf.format(-diffMin, 'minute');
    return rtf.format(-diffSec, 'second');
  },
};

/**
 * Number formatting per locale.
 */
export const numberFormats = {
  decimal: (num: number, locale: Locale, decimals = 2) =>
    new Intl.NumberFormat(locale, { minimumFractionDigits: decimals, maximumFractionDigits: decimals }).format(num),

  integer: (num: number, locale: Locale) =>
    new Intl.NumberFormat(locale, { maximumFractionDigits: 0 }).format(num),

  percent: (num: number, locale: Locale) =>
    new Intl.NumberFormat(locale, { style: 'percent', maximumFractionDigits: 1 }).format(num),

  compact: (num: number, locale: Locale) =>
    new Intl.NumberFormat(locale, { notation: 'compact', maximumFractionDigits: 1 }).format(num),
};

/**
 * Currency formatting per locale.
 */
const localeCurrencyMap: Record<Locale, string> = {
  ja: 'JPY',
  en: 'USD',
  zh: 'CNY',
  ko: 'KRW',
};

export function formatCurrency(amount: number, locale: Locale, currency?: string): string {
  return new Intl.NumberFormat(locale, {
    style: 'currency',
    currency: currency ?? localeCurrencyMap[locale] ?? 'USD',
  }).format(amount);
}

/**
 * List formatting (conjunction/disjunction).
 */
export function formatList(items: string[], locale: Locale, type: 'conjunction' | 'disjunction' = 'conjunction'): string {
  return new Intl.ListFormat(locale, { style: 'long', type }).format(items);
}
TYPESCRIPT
}

# =============================================================================
# RTLサポート生成
# =============================================================================
i18n_generate_rtl_support() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _i18n_write_file "${project_dir}/src/lib/rtl.ts" <<'TYPESCRIPT'
import type { Locale } from './i18n';

/**
 * RTL (Right-to-Left) layout support.
 */
export const RTL_LOCALES = ['ar', 'he', 'fa', 'ur'] as const;
export type RTLLocale = (typeof RTL_LOCALES)[number];

export function isRTL(locale: string): boolean {
  return RTL_LOCALES.includes(locale as RTLLocale);
}

export function getDirection(locale: string): 'ltr' | 'rtl' {
  return isRTL(locale) ? 'rtl' : 'ltr';
}

/**
 * CSS logical properties helper for RTL support.
 * Maps physical to logical (start/end) equivalents.
 */
export function rtlClass(locale: string, ltrClass: string, rtlClass: string): string {
  return isRTL(locale) ? rtlClass : ltrClass;
}

/**
 * Tailwind CSS directional classes.
 * Converts margin/padding from physical to logical.
 */
export const directionalClasses = {
  ml: (locale: string, size: string) => isRTL(locale) ? `mr-${size}` : `ml-${size}`,
  mr: (locale: string, size: string) => isRTL(locale) ? `ml-${size}` : `mr-${size}`,
  pl: (locale: string, size: string) => isRTL(locale) ? `pr-${size}` : `pl-${size}`,
  pr: (locale: string, size: string) => isRTL(locale) ? `pl-${size}` : `pr-${size}`,
  left: (locale: string, size: string) => isRTL(locale) ? `right-${size}` : `left-${size}`,
  right: (locale: string, size: string) => isRTL(locale) ? `left-${size}` : `right-${size}`,
  textLeft: (locale: string) => isRTL(locale) ? 'text-right' : 'text-left',
  textRight: (locale: string) => isRTL(locale) ? 'text-left' : 'text-right',
};
TYPESCRIPT
}

# =============================================================================
# 翻訳キー抽出ツール
# =============================================================================
i18n_generate_extraction() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _i18n_write_file "${project_dir}/scripts/extract-i18n-keys.ts" <<'TYPESCRIPT'
/**
 * Extract translation keys from source code.
 * Run: npx ts-node scripts/extract-i18n-keys.ts
 *
 * Scans .tsx/.ts files for t('key') and t("key") calls,
 * then reports missing keys per locale file.
 */
import fs from 'fs';
import path from 'path';

const SRC_DIR = path.join(__dirname, '..', 'src');
const MESSAGES_DIR = path.join(__dirname, '..', 'src', 'messages');

function findFiles(dir: string, ext: string[]): string[] {
  const results: string[] = [];
  if (!fs.existsSync(dir)) return results;

  for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
    const fullPath = path.join(dir, entry.name);
    if (entry.isDirectory() && !entry.name.startsWith('.') && entry.name !== 'node_modules') {
      results.push(...findFiles(fullPath, ext));
    } else if (ext.some(e => entry.name.endsWith(e))) {
      results.push(fullPath);
    }
  }
  return results;
}

function extractKeys(content: string): string[] {
  const keys: string[] = [];
  // Match t('key'), t("key"), t(`key`)
  const regex = /\bt\(\s*['"`]([^'"`]+)['"`]\s*(?:,|\))/g;
  let match;
  while ((match = regex.exec(content)) !== null) {
    keys.push(match[1]);
  }
  return keys;
}

function getNestedKeys(obj: Record<string, unknown>, prefix = ''): string[] {
  const keys: string[] = [];
  for (const [key, value] of Object.entries(obj)) {
    const fullKey = prefix ? `${prefix}.${key}` : key;
    if (typeof value === 'object' && value !== null) {
      keys.push(...getNestedKeys(value as Record<string, unknown>, fullKey));
    } else {
      keys.push(fullKey);
    }
  }
  return keys;
}

// Main
const files = findFiles(SRC_DIR, ['.tsx', '.ts']);
const usedKeys = new Set<string>();
for (const file of files) {
  const content = fs.readFileSync(file, 'utf-8');
  for (const key of extractKeys(content)) {
    usedKeys.add(key);
  }
}

console.log(`Found ${usedKeys.size} unique translation keys in ${files.length} files.\n`);

// Check each locale file
const localeFiles = fs.readdirSync(MESSAGES_DIR).filter(f => f.endsWith('.json'));
for (const localeFile of localeFiles) {
  const locale = path.basename(localeFile, '.json');
  const messages = JSON.parse(fs.readFileSync(path.join(MESSAGES_DIR, localeFile), 'utf-8'));
  const existingKeys = new Set(getNestedKeys(messages));

  const missing = [...usedKeys].filter(k => !existingKeys.has(k));
  const unused = [...existingKeys].filter(k => !usedKeys.has(k));

  console.log(`[${locale}] Existing: ${existingKeys.size}, Missing: ${missing.length}, Unused: ${unused.length}`);
  if (missing.length > 0) {
    console.log(`  Missing keys: ${missing.slice(0, 10).join(', ')}${missing.length > 10 ? '...' : ''}`);
  }
}
TYPESCRIPT
}

# =============================================================================
# Claudeプロンプト注入
# =============================================================================
i18n_inject_i18n_patterns() {
    local prompt="${1:-}"

    cat <<'INJECTION'

## [i18n Patterns] 国際化実装ルール

### 必須パターン:
1. **テキスト**: ハードコード文字列禁止。全て `t('key')` で参照
2. **名前空間**: `useTranslations('common')` で名前空間指定
3. **補間**: `t('validation.required', { field: t('auth.email') })` で動的値
4. **日付/通貨**: `Intl.DateTimeFormat(locale, ...)` / `Intl.NumberFormat(locale, ...)` 使用
5. **ロケール検出**: `next-intl/middleware` で自動検出、Cookie/Accept-Language優先
6. **RTL**: `dir={isRTL(locale) ? 'rtl' : 'ltr'}` をhtml要素に設定
7. **翻訳ファイル**: `src/messages/{locale}.json` に階層構造で格納

### サポートロケール:
- ja (日本語, default), en (English), zh (中文), ko (한국어)

### 禁止:
- `"保存"` 等のハードコード日本語/英語テキスト
- `new Date().toLocaleDateString()` 等のロケール未指定フォーマット
- `$` や `¥` 等の通貨記号ハードコード
INJECTION

    echo "$prompt"
}

# =============================================================================
# 全生成実行
# =============================================================================
i18n_generate_i18n() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    echo "[i18n-engine] Generating internationalization infrastructure..."
    i18n_generate_setup "$project_dir"
    i18n_generate_translation_files "$project_dir"
    i18n_generate_translation_hook "$project_dir"
    i18n_generate_locale_switcher "$project_dir"
    i18n_generate_date_format "$project_dir"
    i18n_generate_rtl_support "$project_dir"
    i18n_generate_extraction "$project_dir"
    echo "[i18n-engine] Generated ${I18N_GENERATED} files (${I18N_ERRORS} errors)"
}

# =============================================================================
# レポート & スコア
# =============================================================================
i18n_report() {
    echo -e "\n  ${BOLD:-}=== i18n-engine v${I18N_VERSION} ===${NC:-}"
    echo -e "  生成ファイル数: ${I18N_GENERATED}"
    echo -e "  エラー: ${I18N_ERRORS}"
    if [[ ${I18N_GENERATED} -gt 0 ]]; then
        echo -e "  生成内容: i18n setup, ja/en/zh/ko translations, hooks, locale-switcher, formatters, RTL, key-extractor"
    fi
}

i18n_score() {
    if [[ ${I18N_GENERATED} -ge 8 ]] && [[ ${I18N_ERRORS} -eq 0 ]]; then
        echo "95"
    elif [[ ${I18N_GENERATED} -gt 0 ]] && [[ ${I18N_ERRORS} -eq 0 ]]; then
        echo "90"
    elif [[ ${I18N_GENERATED} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "i18n-engine" --version "140.0" \
        --description "国際化基盤×next-intl×ロケール検出×RTLサポート" \
        --init "i18n_init" --report "i18n_report" --score "i18n_score" \
        --enable-var "ENABLE_I18N" --cli-flags "--i18n:--no-i18n"
fi

# v2003.1: source時のexit codeを確実に0にする
true
