#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v216.0 - Security Surface Scanner
# =============================================================================
# プロジェクトのセキュリティ攻撃面を包括的にスキャンし、
# 認証フロー・認可・入力検証・秘密情報・CORS・セキュリティヘッダーを検証する
#
# 機能:
#   1. 認証フロースキャン (Auth Flow Scan)
#   2. 認可チェック (Authorization Check)
#   3. 入力検証検出 (Input Validation Detection)
#   4. 秘密情報スキャン (Secret Scan)
#   5. CORS検証 (CORS Validation)
#   6. セキュリティヘッダー検証 (Security Headers Check)
#   7. セキュリティレポート生成 (Security Report)
#
# 使用方法:
#   source lib/security-surface-scanner.sh
#   _sss_scan_auth_flows "/path/to/project"
#   _sss_check_authorization "/path/to/project"
#   _sss_find_input_validation "/path/to/project"
#   _sss_check_secrets "/path/to/project"
#   _sss_check_cors "/path/to/project"
#   _sss_check_headers "/path/to/project"
#   _sss_generate_security_report "/path/to/project"
# =============================================================================

[[ -n "${_SECURITY_SURFACE_SCANNER_LOADED:-}" ]] && return 0
_SECURITY_SURFACE_SCANNER_LOADED=1

# ============================================================
# Constants
# ============================================================
SSS_VERSION="216.0"
SSS_SEVERITY_CRITICAL=4
SSS_SEVERITY_HIGH=3
SSS_SEVERITY_MEDIUM=2
SSS_SEVERITY_LOW=1
ENABLE_SECURITY_SURFACE_SCANNER="${ENABLE_SECURITY_SURFACE_SCANNER:-true}"

# ============================================================
# Internal State
# ============================================================
declare -a _SSS_FINDINGS=()
declare -A _SSS_FINDING_SEVERITY=()    # index → severity level
declare -A _SSS_FINDING_CATEGORY=()    # index → category
declare -A _SSS_FINDING_FILE=()        # index → file path
declare -A _SSS_FINDING_DETAIL=()      # index → detail message
_SSS_PROJECT_DIR=""
_SSS_FINDING_COUNT=0
_SSS_CRITICAL_COUNT=0
_SSS_HIGH_COUNT=0
_SSS_MEDIUM_COUNT=0
_SSS_LOW_COUNT=0
_SSS_AUTH_SCORE=0
_SSS_AUTHZ_SCORE=0
_SSS_VALIDATION_SCORE=0
_SSS_SECRETS_SCORE=0
_SSS_CORS_SCORE=0
_SSS_HEADERS_SCORE=0
_SSS_SCORE=50

# ============================================================
# Logging
# ============================================================
_sss_log() {
    local level="$1" msg="$2"
    local timestamp
    timestamp="$(date '+%Y-%m-%d %H:%M:%S')"
    echo -e "  [SSS][${level}] ${msg}" >&2
    if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
        echo "[${timestamp}][SSS][${level}] ${msg}" >> "${SESSION_LOG_DIR}/security_surface_scanner.log" 2>/dev/null || true
    fi
}

# ============================================================
# Utility: Add finding
# ============================================================
_sss_add_finding() {
    local severity="$1"
    local category="$2"
    local file="$3"
    local detail="$4"

    local idx=$_SSS_FINDING_COUNT
    _SSS_FINDINGS+=("$idx")
    _SSS_FINDING_SEVERITY["$idx"]="$severity"
    _SSS_FINDING_CATEGORY["$idx"]="$category"
    _SSS_FINDING_FILE["$idx"]="$file"
    _SSS_FINDING_DETAIL["$idx"]="$detail"
    _SSS_FINDING_COUNT=$((_SSS_FINDING_COUNT + 1))

    case "$severity" in
        $SSS_SEVERITY_CRITICAL) _SSS_CRITICAL_COUNT=$((_SSS_CRITICAL_COUNT + 1)) ;;
        $SSS_SEVERITY_HIGH)     _SSS_HIGH_COUNT=$((_SSS_HIGH_COUNT + 1)) ;;
        $SSS_SEVERITY_MEDIUM)   _SSS_MEDIUM_COUNT=$((_SSS_MEDIUM_COUNT + 1)) ;;
        $SSS_SEVERITY_LOW)      _SSS_LOW_COUNT=$((_SSS_LOW_COUNT + 1)) ;;
    esac
}

# ============================================================
# Utility: Find scannable files
# ============================================================
_sss_find_files() {
    local dir="$1"
    find "$dir" \
        -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" -o -name "*.py" -o -name "*.env*" -o -name "*.json" -o -name "*.yaml" -o -name "*.yml" \) \
        ! -path "*/node_modules/*" \
        ! -path "*/.next/*" \
        ! -path "*/dist/*" \
        ! -path "*/build/*" \
        ! -path "*/.git/*" \
        ! -name "*.d.ts" \
        ! -name "package-lock.json" \
        ! -name "yarn.lock" \
        ! -name "pnpm-lock.yaml" \
        2>/dev/null | sort
}

_sss_find_source_files() {
    local dir="$1"
    find "$dir" \
        -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" -o -name "*.py" \) \
        ! -path "*/node_modules/*" \
        ! -path "*/.next/*" \
        ! -path "*/dist/*" \
        ! -path "*/build/*" \
        ! -path "*/.git/*" \
        ! -name "*.d.ts" \
        ! -name "*.test.*" \
        ! -name "*.spec.*" \
        2>/dev/null | sort
}

_sss_find_api_files() {
    local dir="$1"
    find "$dir" \
        -type f \( -name "*.ts" -o -name "*.js" \) \
        \( -path "*/api/*" -o -path "*/routes/*" -o -path "*/lambda/*" \) \
        ! -path "*/node_modules/*" \
        ! -path "*/.next/*" \
        ! -path "*/dist/*" \
        ! -name "*.d.ts" \
        ! -name "*.test.*" \
        2>/dev/null | sort
}

# ============================================================
# Utility: Severity label
# ============================================================
_sss_severity_label() {
    case "$1" in
        $SSS_SEVERITY_CRITICAL) echo "CRITICAL" ;;
        $SSS_SEVERITY_HIGH)     echo "HIGH" ;;
        $SSS_SEVERITY_MEDIUM)   echo "MEDIUM" ;;
        $SSS_SEVERITY_LOW)      echo "LOW" ;;
        *) echo "INFO" ;;
    esac
}

# ============================================================
# 1. Scan Auth Flows
# ============================================================
_sss_scan_auth_flows() {
    local project_dir="${1:-.}"
    _SSS_PROJECT_DIR="$project_dir"

    _sss_log "INFO" "認証フロースキャン開始: ${project_dir}"

    local auth_issues=0
    local auth_checks=0

    local files
    files=$(_sss_find_source_files "$project_dir")

    # Check for password hashing
    local has_bcrypt=false
    local has_argon=false
    local has_plain_password=false

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue
        local rel_file="${file#${project_dir}/}"

        # Check password hashing
        if echo "$content" | grep -qE 'bcrypt|bcryptjs'; then
            has_bcrypt=true
            auth_checks=$((auth_checks + 1))
        fi
        if echo "$content" | grep -qE 'argon2'; then
            has_argon=true
            auth_checks=$((auth_checks + 1))
        fi

        # Plain text password storage
        if echo "$content" | grep -qE 'password\s*[:=]\s*req\.|password\s*[:=]\s*body\.' | grep -vqE 'hash|bcrypt|argon'; then
            if ! echo "$content" | grep -qE 'bcrypt|argon|hash'; then
                _sss_add_finding $SSS_SEVERITY_CRITICAL "AUTH" "$rel_file" "パスワードが平文で処理されている可能性"
                has_plain_password=true
                auth_issues=$((auth_issues + 1))
            fi
        fi

        # JWT configuration
        if echo "$content" | grep -qE 'jwt|jsonwebtoken|jose'; then
            auth_checks=$((auth_checks + 1))

            # Check for weak algorithm
            if echo "$content" | grep -qE "algorithm.*HS256|alg.*HS256"; then
                _sss_add_finding $SSS_SEVERITY_MEDIUM "AUTH" "$rel_file" "JWT: HS256使用 - RS256/ES256推奨"
                auth_issues=$((auth_issues + 1))
            fi

            # Check for long expiry
            if echo "$content" | grep -qE "expiresIn.*['\"]([0-9]+[dh])['\"]"; then
                local expiry
                expiry=$(echo "$content" | grep -oE "expiresIn.*['\"]([0-9]+[dh])['\"]" | grep -oE '[0-9]+[dh]' | head -1)
                if echo "$expiry" | grep -qE '^[0-9]+d$'; then
                    _sss_add_finding $SSS_SEVERITY_HIGH "AUTH" "$rel_file" "JWT有効期限が長すぎます: ${expiry} (15分以内推奨)"
                    auth_issues=$((auth_issues + 1))
                elif echo "$expiry" | grep -qE '^[2-9][0-9]*h$|^[0-9]{2,}h$'; then
                    _sss_add_finding $SSS_SEVERITY_MEDIUM "AUTH" "$rel_file" "JWT有効期限: ${expiry} (短い有効期限推奨)"
                    auth_issues=$((auth_issues + 1))
                fi
            fi

            # Check for hardcoded secret
            if echo "$content" | grep -qE "secret.*['\"][a-zA-Z0-9]{8,}['\"]|JWT_SECRET.*=.*['\"]"; then
                _sss_add_finding $SSS_SEVERITY_CRITICAL "AUTH" "$rel_file" "JWTシークレットがハードコードされている可能性"
                auth_issues=$((auth_issues + 1))
            fi
        fi

        # Session management
        if echo "$content" | grep -qE 'session|cookie'; then
            if echo "$content" | grep -qE 'httpOnly|HttpOnly'; then
                auth_checks=$((auth_checks + 1))
            else
                if echo "$content" | grep -qE 'set-cookie|setCookie|cookie.*='; then
                    _sss_add_finding $SSS_SEVERITY_HIGH "AUTH" "$rel_file" "Cookie設定でhttpOnlyフラグ未設定"
                    auth_issues=$((auth_issues + 1))
                fi
            fi

            if echo "$content" | grep -qE 'secure.*true|Secure'; then
                auth_checks=$((auth_checks + 1))
            fi

            if echo "$content" | grep -qE 'sameSite|SameSite'; then
                auth_checks=$((auth_checks + 1))
            fi
        fi

        # Rate limiting on auth endpoints
        if echo "$file" | grep -qiE 'login|auth|register|sign-?in|sign-?up'; then
            if ! echo "$content" | grep -qE 'rateLimit|rate-limit|throttle|slowDown'; then
                _sss_add_finding $SSS_SEVERITY_HIGH "AUTH" "$rel_file" "認証エンドポイントにレート制限なし"
                auth_issues=$((auth_issues + 1))
            else
                auth_checks=$((auth_checks + 1))
            fi
        fi
    done <<< "$files"

    # Score calculation
    if [[ $auth_checks -gt 0 ]]; then
        _SSS_AUTH_SCORE=$(( (auth_checks * 100) / (auth_checks + auth_issues) ))
    else
        _SSS_AUTH_SCORE=0
    fi

    _sss_log "INFO" "認証フロースキャン完了: checks=${auth_checks}, issues=${auth_issues}"
    return 0
}

# ============================================================
# 2. Check Authorization
# ============================================================
_sss_check_authorization() {
    local project_dir="${1:-.}"

    _sss_log "INFO" "認可チェック開始"

    local authz_issues=0
    local authz_checks=0

    local api_files
    api_files=$(_sss_find_api_files "$project_dir")

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue
        local rel_file="${file#${project_dir}/}"

        # Check for auth middleware/guards
        local has_auth_check=false

        if echo "$content" | grep -qE 'auth|authenticate|isAuthenticated|requireAuth|getSession|verifyToken|middleware'; then
            has_auth_check=true
            authz_checks=$((authz_checks + 1))
        fi

        # Check for role-based access
        if echo "$content" | grep -qE 'role|permission|authorize|isAdmin|requireRole|checkPermission|rbac'; then
            authz_checks=$((authz_checks + 1))
        fi

        # API endpoints without auth checks
        if echo "$content" | grep -qE 'export\s+(async\s+)?function\s+(GET|POST|PUT|DELETE|PATCH)'; then
            if [[ "$has_auth_check" != "true" ]]; then
                # Exclude public endpoints
                if ! echo "$file" | grep -qiE 'public|health|status|webhook|callback|register|login|reset'; then
                    _sss_add_finding $SSS_SEVERITY_HIGH "AUTHZ" "$rel_file" "APIエンドポイントに認証チェックなし"
                    authz_issues=$((authz_issues + 1))
                fi
            fi
        fi

        # Check for direct DB access without auth
        if echo "$content" | grep -qE 'prisma\.\w+\.(delete|update|create)'; then
            if ! echo "$content" | grep -qE 'session|auth|token|userId|user\.id|currentUser'; then
                _sss_add_finding $SSS_SEVERITY_MEDIUM "AUTHZ" "$rel_file" "DB変更操作にユーザー認証コンテキストなし"
                authz_issues=$((authz_issues + 1))
            else
                authz_checks=$((authz_checks + 1))
            fi
        fi

        # IDOR vulnerability check (direct ID from request without ownership verification)
        if echo "$content" | grep -qE 'params\.\w+Id|params\.id|query\.id'; then
            if ! echo "$content" | grep -qE 'userId.*session|session.*userId|where.*userId|ownerId|createdBy'; then
                _sss_add_finding $SSS_SEVERITY_HIGH "AUTHZ" "$rel_file" "IDOR脆弱性の可能性: リクエストIDの所有者検証なし"
                authz_issues=$((authz_issues + 1))
            fi
        fi
    done <<< "$api_files"

    if [[ $((authz_checks + authz_issues)) -gt 0 ]]; then
        _SSS_AUTHZ_SCORE=$(( (authz_checks * 100) / (authz_checks + authz_issues) ))
    else
        _SSS_AUTHZ_SCORE=50
    fi

    _sss_log "INFO" "認可チェック完了: checks=${authz_checks}, issues=${authz_issues}"
    return 0
}

# ============================================================
# 3. Find Input Validation
# ============================================================
_sss_find_input_validation() {
    local project_dir="${1:-.}"

    _sss_log "INFO" "入力検証スキャン開始"

    local validation_issues=0
    local validation_checks=0

    local api_files
    api_files=$(_sss_find_api_files "$project_dir")

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue
        local rel_file="${file#${project_dir}/}"

        # Check for validation library usage
        local has_validation=false

        if echo "$content" | grep -qE 'zod|z\.\w+|\.parse\(|\.safeParse\('; then
            has_validation=true
            validation_checks=$((validation_checks + 1))
        fi

        if echo "$content" | grep -qE 'joi|yup|class-validator|pydantic|validate'; then
            has_validation=true
            validation_checks=$((validation_checks + 1))
        fi

        # POST/PUT/PATCH endpoints should have validation
        if echo "$content" | grep -qE 'export\s+(async\s+)?function\s+(POST|PUT|PATCH)'; then
            if [[ "$has_validation" != "true" ]]; then
                _sss_add_finding $SSS_SEVERITY_HIGH "VALIDATION" "$rel_file" "POST/PUT/PATCHエンドポイントに入力検証なし"
                validation_issues=$((validation_issues + 1))
            fi
        fi

        # Check for request body access without validation
        if echo "$content" | grep -qE 'req\.body|request\.json|body\s*=\s*await.*\.json\(\)'; then
            if [[ "$has_validation" != "true" ]]; then
                _sss_add_finding $SSS_SEVERITY_MEDIUM "VALIDATION" "$rel_file" "リクエストボディの使用に検証なし"
                validation_issues=$((validation_issues + 1))
            fi
        fi

        # SQL injection risk (string concatenation in queries)
        if echo "$content" | grep -qE '\$\{.*\}.*SELECT|\$\{.*\}.*INSERT|\$\{.*\}.*UPDATE|\$\{.*\}.*DELETE'; then
            _sss_add_finding $SSS_SEVERITY_CRITICAL "VALIDATION" "$rel_file" "SQL文に文字列テンプレートを使用: SQLインジェクション脆弱性"
            validation_issues=$((validation_issues + 1))
        fi

        # Command injection risk
        if echo "$content" | grep -qE 'exec\(.*\$\{|spawn\(.*\$\{|child_process|eval\(.*req'; then
            _sss_add_finding $SSS_SEVERITY_CRITICAL "VALIDATION" "$rel_file" "コマンドインジェクション脆弱性の可能性"
            validation_issues=$((validation_issues + 1))
        fi

        # XSS risk (dangerouslySetInnerHTML)
        if echo "$content" | grep -qE 'dangerouslySetInnerHTML|innerHTML\s*='; then
            _sss_add_finding $SSS_SEVERITY_HIGH "VALIDATION" "$rel_file" "XSS脆弱性: dangerouslySetInnerHTML/innerHTML使用"
            validation_issues=$((validation_issues + 1))
        fi

        # Path traversal
        if echo "$content" | grep -qE 'path\.(join|resolve)\(.*req\.|readFile.*req\.'; then
            if ! echo "$content" | grep -qE 'sanitize|normalize|\.\.'; then
                _sss_add_finding $SSS_SEVERITY_HIGH "VALIDATION" "$rel_file" "パストラバーサル脆弱性の可能性"
                validation_issues=$((validation_issues + 1))
            fi
        fi
    done <<< "$api_files"

    if [[ $((validation_checks + validation_issues)) -gt 0 ]]; then
        _SSS_VALIDATION_SCORE=$(( (validation_checks * 100) / (validation_checks + validation_issues) ))
    else
        _SSS_VALIDATION_SCORE=50
    fi

    _sss_log "INFO" "入力検証スキャン完了: checks=${validation_checks}, issues=${validation_issues}"
    return 0
}

# ============================================================
# 4. Check Secrets
# ============================================================
_sss_check_secrets() {
    local project_dir="${1:-.}"

    _sss_log "INFO" "秘密情報スキャン開始"

    local secret_issues=0

    local files
    files=$(_sss_find_files "$project_dir")

    # High-entropy string patterns that look like secrets
    local secret_patterns=(
        'AKIA[0-9A-Z]{16}'                    # AWS Access Key
        'AIza[0-9A-Za-z_-]{35}'               # Google API Key
        'sk-[a-zA-Z0-9]{48}'                  # OpenAI/Stripe secret key
        'sk_live_[a-zA-Z0-9]{24,}'            # Stripe live key
        'pk_live_[a-zA-Z0-9]{24,}'            # Stripe public live key
        'ghp_[a-zA-Z0-9]{36}'                 # GitHub personal token
        'gho_[a-zA-Z0-9]{36}'                 # GitHub OAuth token
        'xoxb-[0-9]{11}-[0-9]{11}-[a-zA-Z0-9]{24}'  # Slack Bot Token
        'SG\.[a-zA-Z0-9_-]{22}\.[a-zA-Z0-9_-]{43}'  # SendGrid API Key
    )

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue

        # Skip binary files and lock files
        local ext="${file##*.}"
        case "$ext" in
            png|jpg|jpeg|gif|ico|woff|woff2|ttf|eot|map) continue ;;
        esac

        local content
        content=$(cat "$file" 2>/dev/null) || continue
        local rel_file="${file#${project_dir}/}"

        # Check for known secret patterns
        for pattern in "${secret_patterns[@]}"; do
            if echo "$content" | grep -qE "$pattern"; then
                _sss_add_finding $SSS_SEVERITY_CRITICAL "SECRETS" "$rel_file" "ハードコードされた秘密情報検出: ${pattern%%[*]*}..."
                secret_issues=$((secret_issues + 1))
            fi
        done

        # Check for generic secret patterns in source code (not .env files)
        if [[ "$ext" != "env" ]] && ! echo "$file" | grep -qE '\.env'; then
            # password = "..." or secret = "..."
            if echo "$content" | grep -qE '(password|secret|api_key|apiKey|API_KEY|SECRET_KEY|PRIVATE_KEY)\s*(=|:)\s*["\x27][^"\x27]{8,}["\x27]' 2>/dev/null; then
                # Exclude test files and example configs
                if ! echo "$file" | grep -qiE 'test|spec|example|sample|mock|fixture'; then
                    _sss_add_finding $SSS_SEVERITY_HIGH "SECRETS" "$rel_file" "ソースコードにシークレットがハードコードされている可能性"
                    secret_issues=$((secret_issues + 1))
                fi
            fi
        fi

        # Check .env files committed to repo
        if echo "$file" | grep -qE '\.env$|\.env\.local$|\.env\.production$'; then
            if echo "$content" | grep -qE '(PASSWORD|SECRET|KEY|TOKEN)=.{8,}'; then
                _sss_add_finding $SSS_SEVERITY_HIGH "SECRETS" "$rel_file" ".envファイルに秘密情報が含まれています (gitignore推奨)"
                secret_issues=$((secret_issues + 1))
            fi
        fi
    done <<< "$files"

    # Check .gitignore for .env exclusion
    local gitignore="${project_dir}/.gitignore"
    if [[ -f "$gitignore" ]]; then
        if ! grep -qE '\.env' "$gitignore" 2>/dev/null; then
            _sss_add_finding $SSS_SEVERITY_HIGH "SECRETS" ".gitignore" ".gitignoreに.envが含まれていません"
            secret_issues=$((secret_issues + 1))
        fi
    else
        _sss_add_finding $SSS_SEVERITY_MEDIUM "SECRETS" "(missing)" ".gitignoreファイルがありません"
        secret_issues=$((secret_issues + 1))
    fi

    _SSS_SECRETS_SCORE=$((100 - (secret_issues * 15)))
    [[ $_SSS_SECRETS_SCORE -lt 0 ]] && _SSS_SECRETS_SCORE=0

    _sss_log "INFO" "秘密情報スキャン完了: issues=${secret_issues}"
    return 0
}

# ============================================================
# 5. Check CORS
# ============================================================
_sss_check_cors() {
    local project_dir="${1:-.}"

    _sss_log "INFO" "CORS検証開始"

    local cors_issues=0
    local cors_checks=0

    local files
    files=$(_sss_find_source_files "$project_dir")

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue
        local rel_file="${file#${project_dir}/}"

        # Check for CORS configuration
        if echo "$content" | grep -qiE 'cors|access-control-allow-origin|Access-Control'; then
            cors_checks=$((cors_checks + 1))

            # Wildcard origin is dangerous
            if echo "$content" | grep -qE "origin.*['\"]\\*['\"]|Access-Control-Allow-Origin.*\\*|cors\(\)"; then
                _sss_add_finding $SSS_SEVERITY_HIGH "CORS" "$rel_file" "CORS: ワイルドカードオリジン(*) 使用 - 明示的オリジンリスト推奨"
                cors_issues=$((cors_issues + 1))
            fi

            # Credentials with wildcard
            if echo "$content" | grep -qE 'credentials.*true' && echo "$content" | grep -qE "origin.*\\*"; then
                _sss_add_finding $SSS_SEVERITY_CRITICAL "CORS" "$rel_file" "CORS: credentials=trueとワイルドカードオリジンの組み合わせ"
                cors_issues=$((cors_issues + 1))
            fi

            # Reflect origin (echoing back request origin)
            if echo "$content" | grep -qE 'origin.*req\.|headers.*origin|origin:\s*true'; then
                _sss_add_finding $SSS_SEVERITY_MEDIUM "CORS" "$rel_file" "CORS: リクエストオリジンの反映 - ホワイトリスト推奨"
                cors_issues=$((cors_issues + 1))
            fi
        fi
    done <<< "$files"

    # Check Next.js config
    local next_config="${project_dir}/next.config.js"
    [[ ! -f "$next_config" ]] && next_config="${project_dir}/next.config.mjs"
    [[ ! -f "$next_config" ]] && next_config="${project_dir}/next.config.ts"

    if [[ -f "$next_config" ]]; then
        local content
        content=$(cat "$next_config" 2>/dev/null) || true
        if echo "$content" | grep -qE 'headers.*Access-Control'; then
            cors_checks=$((cors_checks + 1))
        fi
    fi

    # Check middleware for CORS headers
    local middleware_files
    middleware_files=$(find "$project_dir" -name "middleware.ts" -o -name "middleware.js" 2>/dev/null | head -5)
    for mw_file in $middleware_files; do
        local content
        content=$(cat "$mw_file" 2>/dev/null) || continue
        if echo "$content" | grep -qiE 'cors|access-control'; then
            cors_checks=$((cors_checks + 1))
        fi
    done

    if [[ $((cors_checks + cors_issues)) -gt 0 ]]; then
        _SSS_CORS_SCORE=$(( (cors_checks * 100) / (cors_checks + cors_issues) ))
    else
        _SSS_CORS_SCORE=50  # No CORS config found - neutral
    fi

    _sss_log "INFO" "CORS検証完了: checks=${cors_checks}, issues=${cors_issues}"
    return 0
}

# ============================================================
# 6. Check Security Headers
# ============================================================
_sss_check_headers() {
    local project_dir="${1:-.}"

    _sss_log "INFO" "セキュリティヘッダー検証開始"

    local header_issues=0
    local header_checks=0

    local files
    files=$(_sss_find_source_files "$project_dir")

    # Check for helmet.js
    local has_helmet=false
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content=$(cat "$file" 2>/dev/null) || continue

        if echo "$content" | grep -qE 'helmet|Helmet'; then
            has_helmet=true
            header_checks=$((header_checks + 5))  # helmet covers multiple headers
            break
        fi
    done <<< "$files"

    if [[ "$has_helmet" != "true" ]]; then
        # Check for individual security headers
        local has_csp=false
        local has_hsts=false
        local has_xframe=false
        local has_xcontent=false
        local has_referrer=false

        while IFS= read -r file; do
            [[ -z "$file" ]] && continue
            local content
            content=$(cat "$file" 2>/dev/null) || continue
            local rel_file="${file#${project_dir}/}"

            echo "$content" | grep -qiE 'content-security-policy|contentSecurityPolicy' && has_csp=true
            echo "$content" | grep -qiE 'strict-transport-security|hsts' && has_hsts=true
            echo "$content" | grep -qiE 'x-frame-options|xFrameOptions' && has_xframe=true
            echo "$content" | grep -qiE 'x-content-type-options|xContentTypeOptions' && has_xcontent=true
            echo "$content" | grep -qiE 'referrer-policy|referrerPolicy' && has_referrer=true
        done <<< "$files"

        [[ "$has_csp" == "true" ]] && header_checks=$((header_checks + 1)) || {
            _sss_add_finding $SSS_SEVERITY_MEDIUM "HEADERS" "(global)" "Content-Security-Policy ヘッダー未設定"
            header_issues=$((header_issues + 1))
        }

        [[ "$has_hsts" == "true" ]] && header_checks=$((header_checks + 1)) || {
            _sss_add_finding $SSS_SEVERITY_MEDIUM "HEADERS" "(global)" "Strict-Transport-Security (HSTS) ヘッダー未設定"
            header_issues=$((header_issues + 1))
        }

        [[ "$has_xframe" == "true" ]] && header_checks=$((header_checks + 1)) || {
            _sss_add_finding $SSS_SEVERITY_MEDIUM "HEADERS" "(global)" "X-Frame-Options ヘッダー未設定 (クリックジャッキング防止)"
            header_issues=$((header_issues + 1))
        }

        [[ "$has_xcontent" == "true" ]] && header_checks=$((header_checks + 1)) || {
            _sss_add_finding $SSS_SEVERITY_LOW "HEADERS" "(global)" "X-Content-Type-Options ヘッダー未設定"
            header_issues=$((header_issues + 1))
        }

        [[ "$has_referrer" == "true" ]] && header_checks=$((header_checks + 1)) || {
            _sss_add_finding $SSS_SEVERITY_LOW "HEADERS" "(global)" "Referrer-Policy ヘッダー未設定"
            header_issues=$((header_issues + 1))
        }
    fi

    # Check Next.js headers config
    local next_config="${project_dir}/next.config.js"
    [[ ! -f "$next_config" ]] && next_config="${project_dir}/next.config.mjs"
    [[ ! -f "$next_config" ]] && next_config="${project_dir}/next.config.ts"

    if [[ -f "$next_config" ]]; then
        local content
        content=$(cat "$next_config" 2>/dev/null) || true
        if echo "$content" | grep -qE 'headers.*\['; then
            header_checks=$((header_checks + 1))
        fi
    fi

    # Check vercel.json for headers
    local vercel_json="${project_dir}/vercel.json"
    if [[ -f "$vercel_json" ]]; then
        local content
        content=$(cat "$vercel_json" 2>/dev/null) || true
        if echo "$content" | grep -qE '"headers"'; then
            header_checks=$((header_checks + 1))
        fi
    fi

    if [[ $((header_checks + header_issues)) -gt 0 ]]; then
        _SSS_HEADERS_SCORE=$(( (header_checks * 100) / (header_checks + header_issues) ))
    else
        _SSS_HEADERS_SCORE=30
    fi

    _sss_log "INFO" "セキュリティヘッダー検証完了: checks=${header_checks}, issues=${header_issues}"
    return 0
}

# ============================================================
# 7. Generate Security Report
# ============================================================
_sss_generate_security_report() {
    local project_dir="${1:-.}"

    # Run all scans if not already done
    if [[ $_SSS_FINDING_COUNT -eq 0 && $_SSS_AUTH_SCORE -eq 0 ]]; then
        _sss_scan_auth_flows "$project_dir"
        _sss_check_authorization "$project_dir"
        _sss_find_input_validation "$project_dir"
        _sss_check_secrets "$project_dir"
        _sss_check_cors "$project_dir"
        _sss_check_headers "$project_dir"
    fi

    _sss_log "INFO" "セキュリティレポート生成開始"

    local output_file="${SESSION_LOG_DIR:-/tmp}/security_report.txt"

    {
        echo "================================================================"
        echo " Security Surface Scanner Report (v${SSS_VERSION})"
        echo " Project: ${project_dir}"
        echo " Date: $(date '+%Y-%m-%d %H:%M:%S')"
        echo "================================================================"
        echo ""

        # Overall score
        local overall=$(( (_SSS_AUTH_SCORE + _SSS_AUTHZ_SCORE + _SSS_VALIDATION_SCORE + _SSS_SECRETS_SCORE + _SSS_CORS_SCORE + _SSS_HEADERS_SCORE) / 6 ))
        echo "  ╔══════════════════════════════════════╗"
        echo "  ║ Overall Security Score: ${overall}/100      ║"
        echo "  ╠══════════════════════════════════════╣"
        printf "  ║ Authentication:   %3d/100            ║\n" "$_SSS_AUTH_SCORE"
        printf "  ║ Authorization:    %3d/100            ║\n" "$_SSS_AUTHZ_SCORE"
        printf "  ║ Input Validation: %3d/100            ║\n" "$_SSS_VALIDATION_SCORE"
        printf "  ║ Secret Safety:    %3d/100            ║\n" "$_SSS_SECRETS_SCORE"
        printf "  ║ CORS Config:      %3d/100            ║\n" "$_SSS_CORS_SCORE"
        printf "  ║ Security Headers: %3d/100            ║\n" "$_SSS_HEADERS_SCORE"
        echo "  ╚══════════════════════════════════════╝"
        echo ""

        # Finding summary
        echo "  Findings Summary:"
        echo "    CRITICAL: ${_SSS_CRITICAL_COUNT}"
        echo "    HIGH:     ${_SSS_HIGH_COUNT}"
        echo "    MEDIUM:   ${_SSS_MEDIUM_COUNT}"
        echo "    LOW:      ${_SSS_LOW_COUNT}"
        echo "    Total:    ${_SSS_FINDING_COUNT}"
        echo ""

        # Detailed findings by severity
        for severity in $SSS_SEVERITY_CRITICAL $SSS_SEVERITY_HIGH $SSS_SEVERITY_MEDIUM $SSS_SEVERITY_LOW; do
            local sev_label
            sev_label=$(_sss_severity_label "$severity")

            local has_findings=false
            for idx in "${_SSS_FINDINGS[@]}"; do
                if [[ "${_SSS_FINDING_SEVERITY[$idx]}" == "$severity" ]]; then
                    has_findings=true
                    break
                fi
            done

            [[ "$has_findings" != "true" ]] && continue

            echo "  --- ${sev_label} Findings ---"
            for idx in "${_SSS_FINDINGS[@]}"; do
                [[ "${_SSS_FINDING_SEVERITY[$idx]}" != "$severity" ]] && continue

                local cat="${_SSS_FINDING_CATEGORY[$idx]:-}"
                local file="${_SSS_FINDING_FILE[$idx]:-}"
                local detail="${_SSS_FINDING_DETAIL[$idx]:-}"

                echo "    [${sev_label}][${cat}] ${file}"
                echo "      ${detail}"
                echo ""
            done
        done

        # Recommendations
        echo "  ═══════════════════════════════════════"
        echo "  Recommendations:"
        echo "  ═══════════════════════════════════════"

        if [[ $_SSS_AUTH_SCORE -lt 70 ]]; then
            echo "    - 認証: bcrypt/argon2idによるパスワードハッシュ、JWT RS256/ES256、15分以内の有効期限"
        fi
        if [[ $_SSS_AUTHZ_SCORE -lt 70 ]]; then
            echo "    - 認可: 全APIエンドポイントに認証ミドルウェア、RBAC、IDORチェック"
        fi
        if [[ $_SSS_VALIDATION_SCORE -lt 70 ]]; then
            echo "    - 入力検証: zod/joiによる全エンドポイントのスキーマ検証、パラメータ化クエリ"
        fi
        if [[ $_SSS_SECRETS_SCORE -lt 70 ]]; then
            echo "    - 秘密管理: .envのgitignore、環境変数の使用、ハードコードされた秘密情報の除去"
        fi
        if [[ $_SSS_CORS_SCORE -lt 70 ]]; then
            echo "    - CORS: 明示的オリジンホワイトリスト、ワイルドカード禁止"
        fi
        if [[ $_SSS_HEADERS_SCORE -lt 70 ]]; then
            echo "    - ヘッダー: helmet.js導入、CSP/HSTS/X-Frame-Options設定"
        fi
    } > "$output_file" 2>/dev/null

    _sss_log "INFO" "セキュリティレポート出力: ${output_file}"
    echo "$output_file"
    return 0
}

# ============================================================
# Module Interface: Init / Report / Score
# ============================================================
_sss_init() {
    # Reset state
    _SSS_FINDINGS=()
    _SSS_FINDING_SEVERITY=()
    _SSS_FINDING_CATEGORY=()
    _SSS_FINDING_FILE=()
    _SSS_FINDING_DETAIL=()
    _SSS_FINDING_COUNT=0
    _SSS_CRITICAL_COUNT=0
    _SSS_HIGH_COUNT=0
    _SSS_MEDIUM_COUNT=0
    _SSS_LOW_COUNT=0

    _sss_log "INFO" "Security Surface Scanner v${SSS_VERSION} 初期化"
    return 0
}

_sss_init_message() {
    echo -e "  ${GREEN:-}v${SSS_VERSION} Security Surface Scanner: セキュリティ攻撃面の包括スキャン${NC:-}" >&2
}

_sss_report() {
    echo -e "\n  ${BOLD:-}--- Security Surface Scanner v${SSS_VERSION} ---${NC:-}"
    echo -e "  Auth Score        : ${_SSS_AUTH_SCORE}/100"
    echo -e "  AuthZ Score       : ${_SSS_AUTHZ_SCORE}/100"
    echo -e "  Validation Score  : ${_SSS_VALIDATION_SCORE}/100"
    echo -e "  Secrets Score     : ${_SSS_SECRETS_SCORE}/100"
    echo -e "  CORS Score        : ${_SSS_CORS_SCORE}/100"
    echo -e "  Headers Score     : ${_SSS_HEADERS_SCORE}/100"
    echo -e "  Findings          : C=${_SSS_CRITICAL_COUNT} H=${_SSS_HIGH_COUNT} M=${_SSS_MEDIUM_COUNT} L=${_SSS_LOW_COUNT}"
    echo -e "  Overall Score     : ${_SSS_SCORE}/100"
}

_sss_score() {
    local score=$(( (_SSS_AUTH_SCORE + _SSS_AUTHZ_SCORE + _SSS_VALIDATION_SCORE + _SSS_SECRETS_SCORE + _SSS_CORS_SCORE + _SSS_HEADERS_SCORE) / 6 ))

    # Extra penalties for critical findings
    score=$((score - (_SSS_CRITICAL_COUNT * 10)))

    [[ $score -lt 0 ]] && score=0
    [[ $score -gt 100 ]] && score=100

    _SSS_SCORE=$score
    echo "$score"
}

# ============================================================
# Run all scans
# ============================================================
_sss_run_all() {
    local project_dir="${1:-.}"

    _sss_scan_auth_flows "$project_dir"
    _sss_check_authorization "$project_dir"
    _sss_find_input_validation "$project_dir"
    _sss_check_secrets "$project_dir"
    _sss_check_cors "$project_dir"
    _sss_check_headers "$project_dir"
    _sss_generate_security_report "$project_dir"
    _sss_score

    _sss_report
}

# ============================================================
# Module Registry Registration
# ============================================================
_mr_register \
    --name "security-surface-scanner" \
    --version "216.0" \
    --description "セキュリティ攻撃面スキャン (認証/認可/入力検証/秘密情報/CORS/ヘッダー)" \
    --init "_sss_init" \
    --report "_sss_report" \
    --score "_sss_score" \
    --enable-var "ENABLE_SECURITY_SURFACE_SCANNER" \
    --cli-flags "--security-surface:--no-security-surface" \
    --init-msg "_sss_init_message"
