#!/usr/bin/env bash
# ╔═══════════════════════════════════════════════════════════╗
# ║  SoloptiLinkAI v2001.0 - Repair Engine                   ║
# ║  「1を打ったら10直してくれる」修復エンジン                ║
# ║                                                           ║
# ║  新規構築ではなく、既存プロジェクトの修復・改善に特化     ║
# ║  - エラー修正: ビルドエラー/ランタイムエラー/型エラー     ║
# ║  - 問題解決: パフォーマンス/セキュリティ/アクセシビリティ ║
# ║  - 波及修正: 1箇所直したら関連箇所も自動で検出・修正     ║
# ║  - 忠実性: ユーザーが頼んだことだけ。勝手に機能追加しない ║
# ╚═══════════════════════════════════════════════════════════╝

[[ -n "${_REPAIR_ENGINE_LOADED:-}" ]] && return 0
_REPAIR_ENGINE_LOADED=1

readonly RE_VERSION="1.0.0"

# カラー
readonly RE_RED='\033[0;31m' RE_GREEN='\033[0;32m' RE_YELLOW='\033[0;33m'
readonly RE_CYAN='\033[0;36m' RE_PURPLE='\033[0;35m' RE_BOLD='\033[1m'
readonly RE_DIM='\033[2m' RE_NC='\033[0m'

# 設定
RE_MAX_REPAIR_CYCLES="${RE_MAX_REPAIR_CYCLES:-3}"   # v2034.8: 10→3に削減 (FH×REの累積爆発防止 / PFP-055)
RE_MAX_CASCADE_DEPTH="${RE_MAX_CASCADE_DEPTH:-3}"
RE_PROJECT_DIR=""
RE_REPAIR_LOG=""
RE_TASK_DESCRIPTION=""
RE_ORIGINAL_FILE_HASHES=""

# ============================================================
# 修復モード判定
# ============================================================
# ユーザーの指示から修復タイプを自動判定
re_detect_mode() {
    local task="$1"
    local mode="unknown"

    # エラー修正系キーワード
    if echo "$task" | grep -qiE "エラー|error|バグ|bug|修正|fix|直し|なおし|壊れ|動かない|失敗|落ちる|クラッシュ|crash"; then
        mode="error_fix"
    # 問題解決系
    elif echo "$task" | grep -qiE "問題|遅い|重い|パフォーマンス|セキュリティ|脆弱|アクセシビリティ|改善|最適化|optimize"; then
        mode="improvement"
    # 機能追加系
    elif echo "$task" | grep -qiE "追加|新しい|作って|作成|実装|implement|add|create|新機能"; then
        mode="feature_add"
    # レビュー・確認系
    elif echo "$task" | grep -qiE "確認|チェック|レビュー|review|検証|調査|調べ|問題点|問題ない"; then
        mode="review"
    fi

    echo "$mode"
}

# ============================================================
# プロジェクトスナップショット
# ============================================================
# 修復前の全ファイルハッシュを記録（Regression Shield連携）
re_snapshot_project() {
    local project_dir="$1"
    local snapshot_file="${2:-/tmp/soloptilink_snapshot_$$}"

    if [[ ! -d "$project_dir" ]]; then
        echo ""
        return 1
    fi

    # git管理下ならgit statusを使用（高速）
    if [[ -d "${project_dir}/.git" ]]; then
        (cd "$project_dir" && git diff HEAD --name-only 2>/dev/null; git status --porcelain 2>/dev/null) > "$snapshot_file"
    else
        # git外ならfind+shasum
        find "$project_dir" -type f \
            -not -path "*/node_modules/*" \
            -not -path "*/.next/*" \
            -not -path "*/.git/*" \
            -not -path "*/dist/*" \
            -not -name "*.lock" \
            -exec shasum -a 256 {} \; 2>/dev/null > "$snapshot_file"
    fi

    echo "$snapshot_file"
}

# ============================================================
# エラー収集（多角的）
# ============================================================
re_collect_errors() {
    local project_dir="$1"
    local errors_file="${2:-/tmp/soloptilink_errors_$$}"
    local error_count=0

    echo "[]" > "$errors_file"

    # 1. TypeScriptコンパイルエラー
    if [[ -f "${project_dir}/tsconfig.json" ]]; then
        local tsc_errors
        tsc_errors=$(cd "$project_dir" && npx tsc --noEmit 2>&1 || true)
        if [[ -n "$tsc_errors" && "$tsc_errors" != *"0 errors"* ]]; then
            local tsc_count
            tsc_count=$(echo "$tsc_errors" | grep -c "error TS" 2>/dev/null || echo "0")
            error_count=$((error_count + tsc_count))
            echo -e "  ${RE_RED}TypeScript: ${tsc_count}件のエラー${RE_NC}" >&2
        fi
    fi

    # 2. ESLintエラー
    if [[ -f "${project_dir}/.eslintrc.json" || -f "${project_dir}/.eslintrc.js" || -f "${project_dir}/eslint.config.mjs" ]]; then
        local eslint_errors
        eslint_errors=$(cd "$project_dir" && npx eslint src/ --format json 2>/dev/null || true)
        if [[ -n "$eslint_errors" ]]; then
            local eslint_count
            eslint_count=$(echo "$eslint_errors" | python3 -c "import sys,json; data=json.load(sys.stdin); print(sum(r['errorCount'] for r in data))" 2>/dev/null || echo "0")
            if [[ "$eslint_count" -gt 0 ]]; then
                error_count=$((error_count + eslint_count))
                echo -e "  ${RE_RED}ESLint: ${eslint_count}件のエラー${RE_NC}" >&2
            fi
        fi
    fi

    # 3. Prismaスキーマエラー
    if [[ -f "${project_dir}/prisma/schema.prisma" ]]; then
        local prisma_errors
        prisma_errors=$(cd "$project_dir" && npx prisma validate 2>&1 || true)
        if echo "$prisma_errors" | grep -qi "error"; then
            error_count=$((error_count + 1))
            echo -e "  ${RE_RED}Prisma: スキーマエラー${RE_NC}" >&2
        fi
    fi

    # 4. ビルドエラー
    if [[ -f "${project_dir}/package.json" ]]; then
        local build_errors
        build_errors=$(cd "$project_dir" && npm run build 2>&1 || true)
        if echo "$build_errors" | grep -qiE "error|failed|ELIFECYCLE"; then
            local build_count
            build_count=$(echo "$build_errors" | grep -ciE "^error|Error:" 2>/dev/null || echo "1")
            error_count=$((error_count + build_count))
            echo -e "  ${RE_RED}Build: ${build_count}件のエラー${RE_NC}" >&2
        fi
    fi

    echo "$error_count"
}

# ============================================================
# 波及影響分析
# ============================================================
# 修正対象ファイルから影響を受ける他ファイルを特定
re_analyze_impact() {
    local project_dir="$1"
    local target_file="$2"
    local impact_files=""

    if [[ ! -f "$target_file" ]]; then
        echo ""
        return
    fi

    local basename
    basename=$(basename "$target_file" | sed 's/\.[^.]*$//')

    # このファイルをimportしているファイルを検索
    local importers
    importers=$(grep -rl "from.*['\"].*${basename}['\"]" "${project_dir}/src" "${project_dir}/app" 2>/dev/null || true)

    # このファイルがexportしている関数/型を使っているファイル
    local exports
    exports=$(grep -oE "export (function|const|type|interface|class) \w+" "$target_file" 2>/dev/null | awk '{print $3}' || true)

    for exp in $exports; do
        local users
        users=$(grep -rl "\b${exp}\b" "${project_dir}/src" "${project_dir}/app" 2>/dev/null | grep -v "$target_file" || true)
        importers="${importers}
${users}"
    done

    # 重複除去
    echo "$importers" | sort -u | grep -v "^$"
}

# ============================================================
# 修復プロンプト生成
# ============================================================
# Claude CLIに渡す修復用プロンプトを構築
re_build_repair_prompt() {
    local task_desc="$1"
    local mode="$2"
    local project_dir="$3"
    local error_context="${4:-}"

    local prompt=""

    # Scope Guard制約を必ず注入
    prompt+="# 修復タスク指示

## あなたの役割
既存プロジェクトの修復者。ユーザーが指示した問題のみを修正する。

## 絶対厳守ルール（Scope Guard）
1. **指示された問題だけを修正する**。新機能の追加は絶対に禁止。
2. **既存の動作を壊さない**。修正前に動いていた機能は修正後も必ず動くこと。
3. 修正に関連する波及箇所は直してよいが、「ついでにリファクタリング」は禁止。
4. 修正対象外のファイルは触らない。影響があるファイルのみ最小限の変更。
5. 修正前後で何を変えたか、なぜ変えたかを必ず報告する。

## ユーザーの指示
${task_desc}

## 修復モード: ${mode}
"

    case "$mode" in
        "error_fix")
            prompt+="
## エラー修正の手順
1. まずエラーの全容を把握する（tsc, eslint, build, runtime）
2. エラー間の依存関係を分析する（Aを直せばBも直る等）
3. 根本原因から順に修正する（表面的なエラーではなく原因を直す）
4. 修正したら関連ファイルの影響をチェックする
5. 全エラーが解消されたことを確認する

## 禁止事項
- エラーと無関係なコードの変更
- 新しいライブラリの追加（エラー修正に必要な場合を除く）
- UIデザインの変更
- 新機能の追加
"
            ;;
        "improvement")
            prompt+="
## 改善の手順
1. 指摘された問題箇所を特定する
2. 最小限の変更で改善する
3. 改善前後でパフォーマンスや品質が向上したことを検証する

## 禁止事項
- 改善と無関係な箇所の変更
- アーキテクチャの大幅な変更
- 新機能の追加
"
            ;;
        "review")
            prompt+="
## レビューの手順
1. コード全体を分析する
2. 問題点をリストアップする（重要度順）
3. 各問題の修正方法を提案する
4. **修正は提案のみ。自動で修正しない。ユーザーの承認を待つ。**
"
            ;;
    esac

    if [[ -n "$error_context" ]]; then
        prompt+="
## 現在のエラー情報
${error_context}
"
    fi

    echo "$prompt"
}

# ============================================================
# メイン修復関数
# ============================================================
re_run_repair() {
    local project_dir="$1"
    local task_desc="$2"

    RE_PROJECT_DIR="$project_dir"
    RE_TASK_DESCRIPTION="$task_desc"

    echo "" >&2
    echo -e "${RE_BOLD}${RE_PURPLE}╔═══════════════════════════════════════════════════════╗${RE_NC}" >&2
    echo -e "${RE_BOLD}${RE_PURPLE}║  SoloptiLinkAI Repair Engine v${RE_VERSION}                  ║${RE_NC}" >&2
    echo -e "${RE_BOLD}${RE_PURPLE}║  「1を打ったら10直してくれる」修復モード             ║${RE_NC}" >&2
    echo -e "${RE_BOLD}${RE_PURPLE}╚═══════════════════════════════════════════════════════╝${RE_NC}" >&2
    echo "" >&2

    # Step 1: 修復モード判定
    local mode
    mode=$(re_detect_mode "$task_desc")
    echo -e "  ${RE_CYAN}修復モード: ${RE_BOLD}${mode}${RE_NC}" >&2

    # Step 2: プロジェクトスナップショット（修復前）
    echo -e "  ${RE_CYAN}スナップショット取得中...${RE_NC}" >&2
    local snapshot_before
    snapshot_before=$(re_snapshot_project "$project_dir")

    # Step 3: エラー収集
    echo -e "  ${RE_CYAN}エラー収集中...${RE_NC}" >&2
    local error_count
    error_count=$(re_collect_errors "$project_dir")
    echo -e "  ${RE_YELLOW}検出エラー: ${error_count}件${RE_NC}" >&2

    # Step 4: EPL予測注入（過去の類似エラーパターンから修正戦略を提案）
    local epl_context=""
    if type -t epl_predict_errors &>/dev/null; then
        echo -e "  ${RE_CYAN}[EPL] 過去エラーパターンから予測中...${RE_NC}" >&2
        epl_context=$(epl_predict_errors "${DOMAIN_TYPE:-general}" 2>/dev/null || echo "")
        if [[ -n "$epl_context" ]]; then
            echo -e "  ${RE_GREEN}[EPL] ${epl_context}" | head -3 >&2
        fi
    fi

    # Step 5: Error Intelligence予防プロンプト注入
    local ei_prevention=""
    if [[ "${ENABLE_ERROR_INTELLIGENCE:-true}" == "true" ]] && type -t ei_build_prevention_prompt &>/dev/null; then
        echo -e "  ${RE_CYAN}[EI] エラー予防プロンプト構築中...${RE_NC}" >&2
        ei_prevention=$(ei_build_prevention_prompt 2>/dev/null || echo "")
    fi

    # Step 6: 修復プロンプト生成（EPL+EI予防を統合）
    local repair_prompt
    repair_prompt=$(re_build_repair_prompt "$task_desc" "$mode" "$project_dir" "${epl_context}${ei_prevention}")

    # Step 7: Scope Guard初期化（修復対象範囲を制限）
    if type -t sg_init &>/dev/null; then
        sg_init "$project_dir" "$task_desc" "$mode"
    fi

    # Step 8: Scope Guard制約をプロンプトに注入
    if type -t sg_inject_constraints &>/dev/null; then
        repair_prompt=$(sg_inject_constraints "$repair_prompt")
    fi

    # Step 9: Swarm Vote（30エージェント投票で修正戦略を決定）
    if [[ "${ENABLE_SWARM:-true}" == "true" ]] && type -t pe_execute_swarm_vote &>/dev/null; then
        echo -e "  ${RE_CYAN}[Swarm] 修復戦略を投票中...${RE_NC}" >&2
        pe_execute_swarm_vote "$project_dir" "repair_strategy" 2>/dev/null || true
    fi

    # Step 10: Claude CLIで修復実行（Healer自動修復ループ付き）
    echo -e "  ${RE_CYAN}修復実行中（自動修復ループ対応）...${RE_NC}" >&2
    local repair_cycle=0
    local max_repair_cycles=${RE_MAX_REPAIR_CYCLES:-10}
    local repair_success=false

    while [[ $repair_cycle -lt $max_repair_cycles ]]; do
        repair_cycle=$((repair_cycle + 1))
        echo -e "  ${RE_CYAN}  修復サイクル ${repair_cycle}/${max_repair_cycles}${RE_NC}" >&2

        # Claude CLI呼び出し
        if type -t cb2_call &>/dev/null; then
            cb2_call "$repair_prompt" "" "repair_cycle_${repair_cycle}" "${DOMAIN_TYPE:-general}" 2>/dev/null
        elif type -t _call_claude &>/dev/null; then
            _call_claude "$repair_prompt" "" "repair" 2>/dev/null
        else
            claude -p --dangerously-skip-permissions --output-format text "$repair_prompt" 2>/dev/null
        fi

        # Code Validator: 修復結果をファイル書込前に検証
        if type -t cv2_validate_output &>/dev/null; then
            echo -e "  ${RE_CYAN}  [CV] コードバリデーション中...${RE_NC}" >&2
            local cv_result
            cv_result=$(cv2_validate_output "$project_dir" 2>/dev/null || echo "FAIL")
            if echo "$cv_result" | grep -qi "FAIL\|不合格"; then
                echo -e "  ${RE_YELLOW}  [CV] バリデーション不合格 → 再修復${RE_NC}" >&2
                # 不合格理由をプロンプトに追加して再修復
                repair_prompt="${repair_prompt}

## 前回の修復結果が不合格でした。以下を修正してください:
${cv_result}"
                continue
            fi
        fi

        # エラー再チェック
        local cycle_error_count
        cycle_error_count=$(re_collect_errors "$project_dir" 2>/dev/null)

        if [[ "$cycle_error_count" -eq 0 ]]; then
            echo -e "  ${RE_GREEN}  ✓ エラーゼロ達成（${repair_cycle}サイクル目）${RE_NC}" >&2
            repair_success=true
            break
        elif [[ "$cycle_error_count" -lt "$error_count" ]]; then
            echo -e "  ${RE_YELLOW}  残りエラー: ${cycle_error_count}件（${error_count}→${cycle_error_count}）${RE_NC}" >&2
            error_count=$cycle_error_count
            # 残りエラーをプロンプトに追加して継続
            repair_prompt=$(re_build_repair_prompt "残りのエラーを修正して: $task_desc" "$mode" "$project_dir")
            if type -t sg_inject_constraints &>/dev/null; then
                repair_prompt=$(sg_inject_constraints "$repair_prompt")
            fi
        else
            echo -e "  ${RE_YELLOW}  エラー数変化なし（${cycle_error_count}件）${RE_NC}" >&2
            # Healer: 別戦略を試行
            if type -t healer_run &>/dev/null; then
                echo -e "  ${RE_CYAN}  [Healer] 別戦略で修復試行...${RE_NC}" >&2
                healer_run "$project_dir" 2>/dev/null || true
            fi
        fi

        # EPLにエラー学習を蓄積
        if type -t epl_ingest_failure &>/dev/null; then
            epl_ingest_failure "repair_cycle_${repair_cycle}" "errors:${cycle_error_count}" "${DOMAIN_TYPE:-general}" 2>/dev/null || true
        fi
    done

    # Step 11: Quality Gate 7軸検証（修復後の品質チェック）
    if type -t qg_run &>/dev/null; then
        echo -e "  ${RE_CYAN}[QG] 品質ゲート7軸検証中...${RE_NC}" >&2
        local qg_result
        qg_result=$(qg_run "$project_dir" 2>/dev/null || echo "")
        if [[ -n "$qg_result" ]]; then
            echo -e "  ${RE_GREEN}[QG] $qg_result${RE_NC}" >&2
        fi
    fi

    # Step 12: Regression Shield検証（修復後）
    echo -e "  ${RE_CYAN}リグレッション検証中...${RE_NC}" >&2
    if type -t rs_verify &>/dev/null; then
        local snapshot_after
        snapshot_after=$(re_snapshot_project "$project_dir" "/tmp/soloptilink_snapshot_after_$$")
        rs_verify "$project_dir" "$snapshot_before" "$snapshot_after" "$task_desc"
    fi

    # Step 13: 修復後エラーカウント
    local post_error_count
    post_error_count=$(re_collect_errors "$project_dir" 2>/dev/null)

    echo "" >&2
    echo -e "${RE_BOLD}${RE_GREEN}╔═══════════════════════════════════════════════════════╗${RE_NC}" >&2
    echo -e "${RE_BOLD}${RE_GREEN}║  修復完了                                             ║${RE_NC}" >&2
    echo -e "${RE_BOLD}${RE_GREEN}╚═══════════════════════════════════════════════════════╝${RE_NC}" >&2
    echo -e "  修復前エラー: ${error_count}件" >&2
    echo -e "  修復後エラー: ${post_error_count}件" >&2
    if [[ "$post_error_count" -lt "$error_count" ]]; then
        echo -e "  ${RE_GREEN}✓ $((error_count - post_error_count))件のエラーを解消${RE_NC}" >&2
    fi
    echo "" >&2

    # クリーンアップ
    rm -f "$snapshot_before" "/tmp/soloptilink_snapshot_after_$$" 2>/dev/null

    return 0
}

# ============================================================
# Module Registry 登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register "repair-engine" "$RE_VERSION" "修復エンジン（エラー修正・問題解決特化）"
    _mr_register "repair-engine" "$RE_VERSION" "re_run_repair"
fi

# v2003.1: source時のexit codeを確実に0にする
true
