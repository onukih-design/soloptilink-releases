#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2016.0 - Live Crawler (RVG-2)
# =============================================================================
# routes.json を読み、起動済み dev サーバーへ実 HTTP リクエストを送って
# 各 URL のステータスを記録する。
#
# 旧 e2e-verifier.sh の ev_check_pages は 200/301/302/304/404/401/403 を
# 全て成功扱いにしていたため `/invoices/[id]` が無くても緑信号だった。
# 本モジュールは 200/201/204/301/302/304 のみ PASS、
# 4xx/5xx を厳密に FAIL として記録する。
#
# 使用:
#   bash ~/.soloptilink/lib/live-crawler.sh <ROUTES_JSON> <BASE_URL>
#     例: live-crawler.sh .rvg/routes.json http://localhost:3000
# 出力: 同じディレクトリに crawl-results.json
# 戻り値: 0=全 PASS, 1=FAIL を含む, 2=routes.json missing
# =============================================================================

[[ -n "${_LIVE_CRAWLER_LOADED:-}" ]] && return 0
_LIVE_CRAWLER_LOADED=1

readonly LC_VERSION="2.0.0"  # v2034.6: auth-aware crawl, redirect分離
# v2034.6: 301/302 を PASS から分離. middleware redirect を「画面正常」と誤判定する穴を塞ぐ.
# 旧動作に戻すには LC_PASS_CODES="200|201|204|301|302|304" を export.
LC_PASS_CODES="${LC_PASS_CODES:-200|201|204}"
LC_REDIRECT_CODES="${LC_REDIRECT_CODES:-301|302|307|308}"
LC_TIMEOUT="${LC_TIMEOUT:-8}"
LC_MAX_PARALLEL="${LC_MAX_PARALLEL:-8}"
# Auth-aware crawl: 認証セッションCookieを与えて再クロール、middleware redirectを正しく判定.
LC_AUTH_COOKIE="${LC_AUTH_COOKIE:-}"          # 例: "scp_session=eyJhbGc..."
LC_AUTH_REDIRECT_PATH="${LC_AUTH_REDIRECT_PATH:-/login}"  # 認証画面のpath

# ============================================================
# Public: lc_crawl <routes_json> <base_url> [out_json]
# ============================================================
lc_crawl() {
    local routes_json="${1:-.rvg/routes.json}"
    local base_url="${2:-http://localhost:3000}"
    local out_json="${3:-$(dirname "$routes_json")/crawl-results.json}"

    if [[ ! -f "$routes_json" ]]; then
        echo "[live-crawler] ERROR: routes.json not found: $routes_json" >&2
        return 2
    fi

    if ! command -v curl >/dev/null 2>&1; then
        echo "[live-crawler] ERROR: curl required but missing" >&2
        return 2
    fi

    mkdir -p "$(dirname "$out_json")" 2>/dev/null

    local tmpdir
    tmpdir=$(mktemp -d)
    local job_count=0

    # Iterate JSON entries (extract method+url pairs without jq)
    while IFS=$'\t' read -r kind url method file; do
        [[ -z "$url" ]] && continue
        # Skip wildcard routes (cannot crawl meaningfully)
        case "$url" in
            *':'*|*'*'*) continue ;;
        esac
        # Skip non-GET API methods (would mutate state) — record as DEFERRED
        if [[ "$kind" == "api" && "$method" != "GET" ]]; then
            _lc_record_deferred "$tmpdir" "$kind" "$url" "$method" "$file"
            continue
        fi
        _lc_request_async "$tmpdir" "$base_url" "$kind" "$url" "$method" "$file" &
        job_count=$((job_count + 1))
        if [[ $((job_count % LC_MAX_PARALLEL)) -eq 0 ]]; then
            wait
        fi
    done < <(_lc_parse_routes "$routes_json")

    wait

    # Aggregate results
    {
        echo '['
        local first=1
        local rec
        for rec in "$tmpdir"/*.rec; do
            [[ -f "$rec" ]] || continue
            [[ $first -eq 1 ]] && first=0 || echo ','
            cat "$rec"
        done
        echo ''
        echo ']'
    } > "$out_json"

    rm -rf "$tmpdir"

    # Compute summary
    local total pass fail
    total=$(grep -c '"status_code"' "$out_json" 2>/dev/null) || total=0
    pass=$(grep -c '"verdict":"PASS"' "$out_json" 2>/dev/null) || pass=0
    fail=$(grep -c '"verdict":"FAIL"' "$out_json" 2>/dev/null) || fail=0

    echo "[live-crawler] crawled=$total pass=$pass fail=$fail → $out_json" >&2

    [[ "$fail" -eq 0 ]]
}

# ============================================================
# Internal: parse routes.json without jq
# Output: tab-separated kind\turl\tmethod\tfile
# ============================================================
_lc_parse_routes() {
    local f="$1"
    # naive JSON parsing for our well-formed records
    python3 - "$f" 2>/dev/null <<'PY' || _lc_parse_routes_fallback "$f"
import json, sys
path = sys.argv[1]
with open(path) as fp:
    try:
        data = json.load(fp)
    except Exception:
        sys.exit(1)
for r in data:
    print('\t'.join([r.get('kind',''), r.get('url',''), r.get('method',''), r.get('file','')]))
PY
}

_lc_parse_routes_fallback() {
    local f="$1"
    grep -oE '\{"kind":"[^"]*","url":"[^"]*","method":"[^"]*","file":"[^"]*"\}' "$f" 2>/dev/null | while IFS= read -r line; do
        local kind url method file
        kind=$(echo "$line" | sed -nE 's/.*"kind":"([^"]*)".*/\1/p')
        url=$(echo "$line" | sed -nE 's/.*"url":"([^"]*)".*/\1/p')
        method=$(echo "$line" | sed -nE 's/.*"method":"([^"]*)".*/\1/p')
        file=$(echo "$line" | sed -nE 's/.*"file":"([^"]*)".*/\1/p')
        printf '%s\t%s\t%s\t%s\n' "$kind" "$url" "$method" "$file"
    done
}

# ============================================================
# Internal: async request + record
# ============================================================
_lc_request_async() {
    local tmpdir="$1" base="$2" kind="$3" url="$4" method="$5" file="$6"
    local full_url="${base}${url}"
    local id
    id=$(echo -n "${method}:${url}" | shasum -a 256 2>/dev/null | cut -c1-12)
    [[ -z "$id" ]] && id="r$$$(date +%N)"

    local code body_size
    # -o /dev/null to avoid memory hit; -w to extract code & size
    local out
    out=$(curl -s -o /dev/null -w '%{http_code}|%{size_download}' \
        -X "$method" \
        -H 'Accept: text/html,application/json' \
        --max-time "$LC_TIMEOUT" \
        "$full_url" 2>/dev/null) || out="000|0"
    code="${out%%|*}"
    body_size="${out##*|}"

    local verdict reason redirect_location=""
    # v2034.6: redirect は別レイヤーで判定. middleware が /login へ飛ばしただけのケースを画面正常と誤判定しない.
    if [[ "$code" =~ ^(${LC_REDIRECT_CODES})$ ]]; then
        # Location ヘッダを取得して /login など認証画面へのリダイレクトか確認
        redirect_location=$(curl -s -o /dev/null -w '%{redirect_url}' \
            -X "$method" --max-time "$LC_TIMEOUT" "$full_url" 2>/dev/null || echo "")
        if [[ -n "$LC_AUTH_COOKIE" ]]; then
            # 認証Cookieを付けて再クロール (auth-aware)
            local auth_code
            auth_code=$(curl -s -o /dev/null -w '%{http_code}' \
                -X "$method" -H "Cookie: $LC_AUTH_COOKIE" --max-time "$LC_TIMEOUT" "$full_url" 2>/dev/null || echo "000")
            if [[ "$auth_code" =~ ^(${LC_PASS_CODES})$ ]]; then
                verdict="PASS"
                reason="auth_required_then_ok"
            else
                verdict="FAIL"
                reason="redirect_${code}_to_${redirect_location##*/}_then_${auth_code}"
            fi
        else
            # Cookie 無し → middleware redirect 想定. /login への redirect なら WARN, それ以外は PASS
            if [[ "$redirect_location" == *"$LC_AUTH_REDIRECT_PATH"* ]]; then
                verdict="WARN"
                reason="middleware_redirect_to_auth"
            else
                verdict="PASS"
                reason="redirect_${code}"
            fi
        fi
    elif [[ "$code" =~ ^(${LC_PASS_CODES})$ ]]; then
        verdict="PASS"
        reason=""
    elif [[ "$code" == "000" ]]; then
        verdict="FAIL"
        reason="connection_failed_or_timeout"
    elif [[ "$code" =~ ^5 ]]; then
        verdict="FAIL"
        reason="server_error_${code}"
    elif [[ "$code" == "404" ]]; then
        verdict="FAIL"
        reason="route_not_found_404"
    elif [[ "$code" == "401" || "$code" == "403" ]]; then
        verdict="FAIL"
        reason="auth_blocked_${code}"
    else
        verdict="FAIL"
        reason="unexpected_${code}"
    fi

    local esc_url="${url//\"/\\\"}"
    local esc_file="${file//\"/\\\"}"
    printf '{"kind":"%s","url":"%s","method":"%s","file":"%s","status_code":%s,"size":%s,"verdict":"%s","reason":"%s"}' \
        "$kind" "$esc_url" "$method" "$esc_file" "${code:-0}" "${body_size:-0}" "$verdict" "$reason" \
        > "${tmpdir}/${id}.rec"
}

_lc_record_deferred() {
    local tmpdir="$1" kind="$2" url="$3" method="$4" file="$5"
    local id
    id=$(echo -n "${method}:${url}:def" | shasum -a 256 2>/dev/null | cut -c1-12)
    [[ -z "$id" ]] && id="d$$$(date +%N)"
    local esc_url="${url//\"/\\\"}"
    local esc_file="${file//\"/\\\"}"
    printf '{"kind":"%s","url":"%s","method":"%s","file":"%s","status_code":0,"size":0,"verdict":"DEFERRED","reason":"mutating_method_skipped_in_crawl"}' \
        "$kind" "$esc_url" "$method" "$esc_file" \
        > "${tmpdir}/${id}.rec"
}

# ============================================================
# CLI entry
# ============================================================
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    lc_crawl "${1:-.rvg/routes.json}" "${2:-http://localhost:3000}" "${3:-}"
    exit $?
fi
