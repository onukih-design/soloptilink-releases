#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v101.0 - Live Verification Engine
# Schema ↔ API ↔ Frontend の統合整合性を検証
#
# 問題: 各レイヤー単独ではパスするが、組み合わせると壊れる。
# 解決: 3レイヤーを横断的に解析し、不整合を検出する。
# ============================================================

[[ -n "${_LIVE_VERIFICATION_LOADED:-}" ]] && return 0
_LIVE_VERIFICATION_LOADED=1

LV_VERSION="101.0"
LV_INITIALIZED=false
LV_TOTAL_ISSUES=0
LV_CRITICAL_ISSUES=0

lv_init() {
    LV_TOTAL_ISSUES=0
    LV_CRITICAL_ISSUES=0
    LV_INITIALIZED=true
    return 0
}

# ============================================================
# メイン: 4レイヤー統合検証
# ============================================================
lv_verify_integration() {
    local project_dir="$1"
    [[ ! -d "$project_dir" ]] && return 1

    local report=""
    LV_TOTAL_ISSUES=0
    LV_CRITICAL_ISSUES=0

    local schema_api
    schema_api=$(_lv_check_schema_api "$project_dir")
    [[ -n "$schema_api" ]] && report+="$schema_api"

    local api_frontend
    api_frontend=$(_lv_check_api_frontend "$project_dir")
    [[ -n "$api_frontend" ]] && report+="$api_frontend"

    local routing
    routing=$(_lv_check_routing "$project_dir")
    [[ -n "$routing" ]] && report+="$routing"

    local env_check
    env_check=$(_lv_check_env_vars "$project_dir")
    [[ -n "$env_check" ]] && report+="$env_check"

    if [[ -n "$report" ]]; then
        echo "
# 統合検証レポート (${LV_TOTAL_ISSUES}件, うちCritical ${LV_CRITICAL_ISSUES}件)
${report}"
        return 1
    fi

    return 0
}

# ============================================================
# 1. Prismaスキーマ → APIルート整合性
# ============================================================
_lv_check_schema_api() {
    local project_dir="$1"
    local schema_file="${project_dir}/prisma/schema.prisma"
    [[ ! -f "$schema_file" ]] && return

    local result=""
    local issues=0
    local current_model=""

    while IFS= read -r line; do
        if [[ "$line" =~ ^model[[:space:]]+([A-Za-z]+) ]]; then
            current_model="${BASH_REMATCH[1]}"
            continue
        fi

        if [[ -n "$current_model" && "$line" =~ ^[[:space:]]+([a-zA-Z]+)[[:space:]]+(String|Int|Float|Boolean|DateTime|Json) ]]; then
            local field_name="${BASH_REMATCH[1]}"
            local field_type="${BASH_REMATCH[2]}"
            local model_lower
            model_lower=$(echo "$current_model" | tr '[:upper:]' '[:lower:]')

            local api_file=""
            for candidate in \
                "${project_dir}/app/api/${model_lower}s/route.ts" \
                "${project_dir}/app/api/${model_lower}/route.ts" \
                "${project_dir}/app/api/v1/${model_lower}s/route.ts" \
                "${project_dir}/app/api/v1/${model_lower}/route.ts" \
                "${project_dir}/app/api/v1/admin/${model_lower}s/route.ts" \
                "${project_dir}/src/app/api/${model_lower}s/route.ts"; do
                if [[ -f "$candidate" ]]; then
                    api_file="$candidate"
                    break
                fi
            done

            if [[ -n "$api_file" ]] && grep -q "POST" "$api_file" 2>/dev/null && grep -q "z\." "$api_file" 2>/dev/null; then
                if [[ "$field_name" != "id" && "$field_name" != "createdAt" && "$field_name" != "updatedAt" ]]; then
                    if [[ ! "$field_name" =~ Id$ && ! "$line" =~ "@relation" ]]; then
                        if ! grep -q "${field_name}" "$api_file" 2>/dev/null; then
                            issues=$((issues + 1))
                            LV_TOTAL_ISSUES=$((LV_TOTAL_ISSUES + 1))
                            local rel_api="${api_file#$project_dir/}"
                            result+="- [Schema->API] ${current_model}.${field_name} (${field_type}) がAPIルート ${rel_api} に存在しません
"
                        fi
                    fi
                fi
            fi
        fi

        if [[ -n "$current_model" && "$line" == "}" ]]; then
            current_model=""
        fi
    done < "$schema_file"

    if [[ $issues -gt 0 ]]; then
        echo "
## Schema -> API 整合性 (${issues}件)
${result}"
    fi
}

# ============================================================
# 2. APIルート → フロントエンドfetch整合性
# ============================================================
_lv_check_api_frontend() {
    local project_dir="$1"
    local result=""
    local issues=0

    local api_routes_file="/tmp/_lv_api_routes_$$.txt"
    : > "$api_routes_file"
    while IFS= read -r route_file; do
        local rel_path="${route_file#$project_dir/}"
        local api_path
        api_path=$(echo "$rel_path" | sed 's|^src/||' | sed 's|^app||' | sed 's|/route\.ts$||' | sed 's|/route\.js$||')
        echo "$api_path" >> "$api_routes_file"
    done < <(find "$project_dir" -path "*/api/*/route.ts" -o -path "*/api/*/route.js" 2>/dev/null | grep -v node_modules)

    local api_route_count
    api_route_count=$(wc -l < "$api_routes_file" 2>/dev/null | tr -d ' ')

    if [[ "$api_route_count" -gt 0 ]]; then
        while IFS= read -r frontend_file; do
            [[ "$frontend_file" == *"node_modules"* || "$frontend_file" == *".next"* || "$frontend_file" == *"/api/"* ]] && continue

            grep -noE "fetch\(['\"\`](/api/[a-zA-Z0-9/_-]+)" "$frontend_file" 2>/dev/null | while IFS= read -r match; do
                local line_num fetch_path
                line_num=$(echo "$match" | cut -d: -f1)
                fetch_path=$(echo "$match" | grep -oE "/api/[a-zA-Z0-9/_-]+" | head -1)
                [[ -z "$fetch_path" ]] && continue

                local found=false
                while IFS= read -r api_route; do
                    [[ -z "$api_route" ]] && continue
                    if [[ "$fetch_path" == "$api_route"* ]]; then
                        found=true
                        break
                    fi
                    local api_pattern
                    api_pattern=$(echo "$api_route" | sed 's|\[.*\]|[^/]*|g')
                    if echo "$fetch_path" | grep -qE "^${api_pattern}" 2>/dev/null; then
                        found=true
                        break
                    fi
                done < "$api_routes_file"

                if ! $found; then
                    issues=$((issues + 1))
                    LV_TOTAL_ISSUES=$((LV_TOTAL_ISSUES + 1))
                    LV_CRITICAL_ISSUES=$((LV_CRITICAL_ISSUES + 1))
                    local rel_file="${frontend_file#$project_dir/}"
                    result+="- [API->Frontend] ${rel_file}:${line_num}: fetch('${fetch_path}') に対応するAPIルートがありません
"
                fi
            done
        done < <(find "$project_dir" \( -name "*.tsx" -o -name "*.ts" \) 2>/dev/null | grep -v node_modules | grep -v ".next" | head -200)
    fi

    rm -f "$api_routes_file"

    if [[ $issues -gt 0 ]]; then
        echo "
## API -> Frontend 整合性 (${issues}件) CRITICAL
${result}"
    fi
}

# ============================================================
# 3. フロントエンドルーティング整合性
# ============================================================
_lv_check_routing() {
    local project_dir="$1"
    local result=""
    local issues=0

    local pages_file="/tmp/_lv_pages_$$.txt"
    : > "$pages_file"
    while IFS= read -r page_file; do
        local rel_path="${page_file#$project_dir/}"
        local page_path
        page_path=$(echo "$rel_path" | sed 's|^src/||' | sed 's|^app||' | sed 's|/page\.tsx$||' | sed 's|/page\.ts$||')
        [[ -z "$page_path" ]] && page_path="/"
        echo "$page_path" >> "$pages_file"
    done < <(find "$project_dir" \( -name "page.tsx" -o -name "page.ts" \) 2>/dev/null | grep -v node_modules | grep -v ".next")

    local page_count
    page_count=$(wc -l < "$pages_file" 2>/dev/null | tr -d ' ')

    if [[ "$page_count" -gt 0 ]]; then
        while IFS= read -r src_file; do
            [[ "$src_file" == *"node_modules"* || "$src_file" == *".next"* ]] && continue

            grep -noE "(href|push|replace)\s*[=(]\s*['\"\`](/[a-zA-Z0-9/_-]+)" "$src_file" 2>/dev/null | while IFS= read -r match; do
                local line_num link_path
                line_num=$(echo "$match" | cut -d: -f1)
                link_path=$(echo "$match" | grep -oE "/[a-zA-Z0-9/_-]+" | head -1)
                [[ -z "$link_path" ]] && continue
                [[ "$link_path" == "/api"* || "$link_path" == "/_"* ]] && continue

                local found=false
                while IFS= read -r page; do
                    [[ -z "$page" ]] && continue
                    if [[ "$link_path" == "$page" ]]; then
                        found=true
                        break
                    fi
                    local page_pattern
                    page_pattern=$(echo "$page" | sed 's|\[.*\]|[^/]*|g')
                    if echo "$link_path" | grep -qE "^${page_pattern}$" 2>/dev/null; then
                        found=true
                        break
                    fi
                done < "$pages_file"

                if ! $found; then
                    issues=$((issues + 1))
                    LV_TOTAL_ISSUES=$((LV_TOTAL_ISSUES + 1))
                    local rel_file="${src_file#$project_dir/}"
                    result+="- [Routing] ${rel_file}:${line_num}: リンク先 '${link_path}' に対応するページがありません
"
                fi
            done
        done < <(find "$project_dir" \( -name "*.tsx" -o -name "*.ts" \) 2>/dev/null | grep -v node_modules | grep -v ".next" | head -200)
    fi

    rm -f "$pages_file"

    if [[ $issues -gt 0 ]]; then
        echo "
## ルーティング整合性 (${issues}件)
${result}"
    fi
}

# ============================================================
# 4. 環境変数の未定義チェック
# ============================================================
_lv_check_env_vars() {
    local project_dir="$1"
    local result=""
    local issues=0

    local env_vars_file="/tmp/_lv_env_vars_$$.txt"
    : > "$env_vars_file"

    find "$project_dir" \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" \) 2>/dev/null | grep -v node_modules | grep -v ".next" | head -200 | while IFS= read -r src_file; do
        grep -oE "process\.env\.[A-Z_]+" "$src_file" 2>/dev/null | sed 's/process\.env\.//'
    done | sort -u > "$env_vars_file"

    local env_file="${project_dir}/.env"
    local env_local="${project_dir}/.env.local"
    local env_example="${project_dir}/.env.example"

    while IFS= read -r var; do
        [[ -z "$var" ]] && continue
        case "$var" in
            NODE_ENV|VERCEL|VERCEL_URL|NEXT_RUNTIME|HOSTNAME|PORT) continue ;;
        esac

        local defined=false
        for ef in "$env_file" "$env_local" "$env_example"; do
            if [[ -f "$ef" ]] && grep -q "^${var}=" "$ef" 2>/dev/null; then
                defined=true
                break
            fi
        done

        if ! $defined; then
            issues=$((issues + 1))
            LV_TOTAL_ISSUES=$((LV_TOTAL_ISSUES + 1))
            result+="- [ENV] process.env.${var} が .env ファイルに定義されていません
"
        fi
    done < "$env_vars_file"
    rm -f "$env_vars_file"

    if [[ $issues -gt 0 ]]; then
        echo "
## 環境変数整合性 (${issues}件)
${result}"
    fi
}

# ============================================================
# レポート・スコア
# ============================================================
lv_report() {
    echo "=== Live Verification v${LV_VERSION} ==="
    echo "  Issues: ${LV_TOTAL_ISSUES} (Critical: ${LV_CRITICAL_ISSUES})"
}

lv_score() {
    if [[ $LV_TOTAL_ISSUES -eq 0 ]]; then echo "100"
    elif [[ $LV_CRITICAL_ISSUES -gt 0 ]]; then echo "30"
    elif [[ $LV_TOTAL_ISSUES -lt 5 ]]; then echo "70"
    else echo "50"
    fi
}

# Module Registry 自己登録
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "live-verification" \
        --version "$LV_VERSION" \
        --description "統合検証エンジン - Schema/API/Frontend型整合性+ルーティング+環境変数" \
        --init "lv_init" \
        --report "lv_report" \
        --score "lv_score" \
        --enable-var "ENABLE_LIVE_VERIFICATION" \
        --cli-flags "--live-verification:--no-live-verification"
fi

# v2003.1: source時のexit codeを確実に0にする
true
