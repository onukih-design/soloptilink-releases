#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v30.0 - Agent Scaler
# =============================================================================
# Manages the scaling of agents from 18 (v18.0) to 30 (v30.0), with a design
# foundation for future expansion to 50+ and dynamic agent generation.
# v18.0: Added data-analyst, saas-architect, ai-engineer agents.
# v19.0: Added workflow-designer agent.
# v20.0: Quality Fortress phase mappings (quality_gate/functional_healing/smoke_test)
# v21.0: Version alignment, full phase mapping coverage
# v23.0: Error Guardian integration, version sync
# v25.0: Added dependency-manager agent. Adaptive Intelligence phase mappings.
#
# Responsibilities:
#   - Registry of all 15 agents with metadata (specialties, model tier, etc.)
#   - Phase-to-agent mapping (multi-agent per phase)
#   - Task-driven heuristic agent selection
#   - Parallel scaling limits and resource enforcement
#   - Future stubs for dynamic agent generation (v18.0) and
#     self-learning agent selection (v19.0)
#
# Functions:
#   as_init                    - Initialize scaler, scan agent definitions
#   as_register_agent          - Register an agent to the registry
#   as_get_agents_for_phase    - Return agent list for a given phase
#   as_select_agents           - Heuristic agent selection from task description
#   as_get_agent_config        - Get agent config as JSON
#   as_list_agents             - Print all registered agents
#   as_get_agent_stats         - Get execution statistics
#   as_can_scale               - Check if a new agent can be spawned
#   as_enforce_limits          - Enforce resource limits on parallelism
#   as_generate_dynamic_agent  - [STUB v18.0] Dynamic agent generation
#   as_learn_from_execution    - [STUB v19.0] Learn from execution results
#
# All globals use the AS_ prefix.
# Sourced by the main orchestrator -- do NOT use set -euo pipefail.
# =============================================================================

[[ -n "${_AGENT_SCALER_LOADED:-}" ]] && return 0
_AGENT_SCALER_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g AS_VERSION="30.0"
declare -g AS_ENABLED="false"
declare -g AS_SESSION_ID=""
declare -g AS_AGENTS_DIR=""
declare -g AS_MAX_PARALLEL=5          # Maximum concurrent agent executions
declare -g AS_TOTAL_AGENTS=0          # Number of registered agents
declare -g AS_ACTIVE_COUNT=0          # Currently active agent count
declare -g AS_TOTAL_DISPATCHES=0      # Total dispatch count this session
declare -g AS_CPU_THRESHOLD=80        # CPU % above which we reduce parallelism
declare -g AS_MEM_THRESHOLD=85        # Memory % above which we reduce parallelism

# Active agents (space-separated list of currently running agent IDs)
declare -g AS_ACTIVE_AGENTS=""

# Agent registry: associative arrays keyed by agent_id
declare -g -A AS_AGENT_PATHS=()       # agent_id -> md file path
declare -g -A AS_AGENT_SPECIALTIES=() # agent_id -> comma-separated specialties
declare -g -A AS_AGENT_MODEL_TIER=()  # agent_id -> frontier|balanced|economy
declare -g -A AS_AGENT_MAX_RETRIES=() # agent_id -> max retries
declare -g -A AS_AGENT_TIMEOUT=()     # agent_id -> timeout in seconds
declare -g -A AS_AGENT_PRIORITY=()    # agent_id -> priority (1=highest)

# Execution statistics
declare -g -A AS_STAT_CALLS=()        # agent_id -> invocation count
declare -g -A AS_STAT_SUCCESS=()      # agent_id -> success count
declare -g -A AS_STAT_FAIL=()         # agent_id -> failure count
declare -g -A AS_STAT_TOTAL_TIME=()   # agent_id -> cumulative seconds

# =============================================================================
# Phase-to-Agents mapping (multi-agent per phase)
# Each value is a space-separated list of agent IDs
# =============================================================================
declare -g -A AS_PHASE_AGENTS=(
    [requirements]="pm api-designer"
    [competitive_research]="pm"
    [prompt_expand]="pm"
    [scaffold]="pm db-architect"
    [database]="db-architect backend-dev migration-engineer"
    [backend]="backend-dev api-designer security-auditor"
    [api]="api-designer backend-dev"
    [implementation]="backend-dev frontend-dev"
    [hotfix]="backend-dev qa-engineer"
    [frontend]="frontend-dev designer"
    [ui_design]="designer frontend-dev"
    [testing]="test-architect qa-engineer performance-engineer"
    [quality_check]="qa-engineer test-architect"
    [security_audit]="security-auditor qa-engineer"
    [browser_test]="qa-engineer performance-engineer"
    [deploy]="devops"
    [deploy_preparation]="devops security-auditor"
    [documentation]="documentation-writer pm"
    [knowledge_save]="pm documentation-writer"
    [integration]="integration-engineer api-designer"
    [migration]="migration-engineer db-architect"
    [performance]="performance-engineer test-architect"
    # --- v18.0 Intelligent Platform phases ---
    [data_import]="data-analyst db-architect"
    [saas_architecture]="saas-architect security-auditor backend-dev"
    [ai_integration]="ai-engineer backend-dev frontend-dev"
    # --- v19.0 Automation Gateway phases ---
    [workflow]="workflow-designer pm devops"
    [cost_analysis]="cost-optimizer workflow-designer"
    [template_apply]="pm workflow-designer backend-dev"
    # --- v20.0 Quality Fortress phases ---
    [quality_gate]="qa-engineer security-auditor test-architect"
    [functional_healing]="backend-dev qa-engineer frontend-dev"
    [smoke_test]="qa-engineer devops performance-engineer"
    # --- v22.0 Phase name alignment (missing phases補完) ---
    [rag_search]="pm"
    [e2e_test]="test-architect qa-engineer devops"
    [auto_deploy]="devops"
    [audit]="security-auditor db-architect"
    [audit_log_validation]="security-auditor db-architect"
    [quality_check]="qa-engineer test-architect"
    [data_integrity]="db-architect backend-dev"
    # --- v25.0 Adaptive Intelligence phases ---
    [dependency_resolve]="dependency-manager security-auditor"
    [performance_profile]="performance-engineer frontend-dev"
    [api_contract_validate]="api-designer backend-dev qa-engineer"
    # --- v26.0 Deep Fix Engine phases ---
    # deep_fix_investigate: 20体が並列で多角的調査を実行（全専門エージェント）
    [deep_fix_investigate]="qa-engineer pm backend-dev frontend-dev designer devops cost-optimizer db-architect security-auditor api-designer test-architect performance-engineer documentation-writer migration-engineer integration-engineer data-analyst saas-architect ai-engineer workflow-designer dependency-manager follow-up-analyst"
    # deep_fix_integrate: Judgeが調査結果を統合し修正計画を生成
    [deep_fix_integrate]="pm qa-engineer security-auditor"
    # deep_fix_implement: 担当エージェントが修正を協調実装
    [deep_fix_implement]="backend-dev frontend-dev db-architect api-designer security-auditor"
    # deep_fix_verify: 修正後の全方位検証
    [deep_fix_verify]="qa-engineer security-auditor api-designer db-architect frontend-dev performance-engineer"
    # --- v27.0 Precision Prompt Engine phases ---
    [domain_knowledge]="pm db-architect api-designer"
    [blueprint]="pm backend-dev frontend-dev api-designer"
    [prompt_compile]="pm backend-dev frontend-dev"
    # --- v28.0 Follow-up Intelligence phases ---
    [followup_detect]="pm follow-up-analyst"
    [code_scan]="follow-up-analyst backend-dev frontend-dev"
    [incremental_analysis]="follow-up-analyst pm api-designer"
    [targeted_compile]="follow-up-analyst pm backend-dev frontend-dev"
    [delta_apply]="follow-up-analyst backend-dev frontend-dev"
    # --- Consultation (v28.0) ---
    [consultation]="pm consultant follow-up-analyst"
    # --- v30.0 Swarm Autonomy phases ---
    [swarm_allocate]="swarm-coordinator pm cost-optimizer"
    [swarm_vote]="swarm-coordinator pm qa-engineer"
    [governance_check]="governance-agent security-auditor qa-engineer"
    [ux_review]="ux-researcher designer frontend-dev accessibility-auditor"
    [i18n_setup]="i18n-engineer frontend-dev pm"
    [cache_strategy]="cache-strategist performance-engineer backend-dev"
    [accessibility_audit]="accessibility-auditor ux-researcher designer frontend-dev"
    [state_design]="state-architect frontend-dev backend-dev"
    [error_recovery_design]="error-recovery-agent backend-dev qa-engineer"
    # --- iOS Support phases ---
    [ios_implementation]="ios-dev mobile-architect backend-dev"
    [ios_ui_design]="ios-dev mobile-architect designer ux-researcher"
    [ios_testing]="ios-dev qa-engineer test-architect"
)

# =============================================================================
# Default agent definitions (the 15 agents of v17.0)
# =============================================================================
# Format: "specialties|model_tier|max_retries|timeout|priority"
declare -g -A AS_DEFAULT_AGENTS=(
    # --- Original 7 (v16.0) ---
    [pm]="requirements,planning,coordination,stakeholder|balanced|3|300|1"
    [backend-dev]="backend,api,database,server,nodejs,python,go|balanced|3|300|2"
    [frontend-dev]="frontend,react,vue,nextjs,tailwind,css,html|balanced|3|300|2"
    [designer]="ui,ux,design,accessibility,responsive,figma|balanced|3|300|3"
    [qa-engineer]="testing,quality,validation,e2e,unit-test,coverage|balanced|3|300|2"
    [devops]="deploy,ci-cd,docker,kubernetes,monitoring,infrastructure|balanced|3|300|3"
    [cost-optimizer]="cost,budget,optimization,resource,pricing|economy|2|180|4"
    # --- New 8 (v17.0) ---
    [db-architect]="database,schema,migration,postgresql,mysql,mongodb,redis,indexing|frontier|3|300|2"
    [security-auditor]="security,owasp,vulnerability,audit,penetration,compliance,encryption|frontier|3|360|1"
    [api-designer]="api,rest,graphql,openapi,swagger,grpc,websocket,protocol|balanced|3|300|2"
    [test-architect]="test-strategy,tdd,bdd,coverage,regression,load-test,integration-test|balanced|3|300|2"
    [performance-engineer]="performance,profiling,optimization,caching,load-testing,lcp,fcp,cls|balanced|3|300|3"
    [documentation-writer]="documentation,readme,api-docs,changelog,jsdoc,typedoc|economy|2|180|4"
    [migration-engineer]="migration,data-migration,schema-migration,version-upgrade,backward-compat|balanced|3|300|3"
    [integration-engineer]="integration,third-party,webhook,oauth,sdk,external-api,messaging|balanced|3|300|3"
    # --- New 3 (v18.0) ---
    [data-analyst]="data-analysis,etl,schema-inference,excel,csv,analytics,sql,pandas,profiling|balanced|3|300|2"
    [saas-architect]="saas,multi-tenant,rbac,auth,oauth,jwt,billing,stripe,subscription,tenant|frontier|3|360|1"
    [ai-engineer]="ai,llm,openai,claude,gemini,rag,vector-db,embedding,langchain,streaming,analytics|frontier|3|360|2"
    # --- New 1 (v19.0) ---
    [workflow-designer]="workflow,pipeline,dag,template,cost-optimization,automation,yaml|balanced|3|300|2"
    # --- New 1 (v25.0) ---
    [dependency-manager]="dependency,npm,yarn,pip,go-mod,cargo,vulnerability,lockfile,audit,semver|balanced|3|300|2"
    # --- New 1 (v28.0) ---
    [follow-up-analyst]="followup,context,genome,diff,incremental,modification,error-fix,refactor,impact-analysis|balanced|3|300|2"
    # --- Consultant (v28.0) ---
    [consultant]="project-consulting,tech-advising,requirement-review|balanced|3|300|5"
    # --- New 8 (v30.0 Swarm Autonomy) ---
    [ux-researcher]="ux,usability,persona,user-flow,a-b-test,wcag,accessibility,user-research|balanced|3|300|3"
    [i18n-engineer]="i18n,l10n,multilingual,next-intl,react-i18next,rtl,translation,locale|balanced|3|300|3"
    [cache-strategist]="cache,redis,cdn,ttl,cache-invalidation,browser-cache,edge-cache,memcached|balanced|3|300|3"
    [accessibility-auditor]="accessibility,wcag,aria,screen-reader,keyboard-nav,color-contrast,a11y|balanced|3|300|3"
    [state-architect]="state-management,zustand,redux,jotai,tanstack-query,optimistic-update,realtime-sync|balanced|3|300|3"
    [error-recovery-agent]="error-boundary,fallback,retry,circuit-breaker,graceful-degradation,error-handling|balanced|3|300|3"
    [swarm-coordinator]="swarm,aco,task-allocation,voting,consensus,multi-agent,coordination|frontier|3|360|1"
    [governance-agent]="governance,code-standards,tech-debt,architecture-consistency,naming-convention,policy|balanced|3|300|2"
    # --- iOS Support agents ---
    [ios-dev]="ios,swift,swiftui,uikit,xcode,coredata,combine,async-await,spm,cocoapods,xctest|balanced|3|360|2"
    [mobile-architect]="mobile,ios,android,cross-platform,app-architecture,mvvm,clean-architecture,dependency-injection,offline-first|frontier|3|360|1"
)

# =============================================================================
# Keyword-to-agent mapping for heuristic selection
# =============================================================================
declare -g -A AS_KEYWORD_MAP_AGENTS=""  # Built at init time

# =============================================================================
# Internal logger
# =============================================================================
_as_log() {
    local level="$1" msg="$2"
    local color="${CYAN:-\033[0;36m}"
    case "$level" in
        WARN)    color="${YELLOW:-\033[1;33m}" ;;
        ERROR)   color="${RED:-\033[0;31m}" ;;
        SUCCESS) color="${GREEN:-\033[0;32m}" ;;
        DEBUG)   color="${DIM:-\033[2m}" ;;
    esac
    echo -e "  ${color}[AGENT-SC]${NC:-\033[0m} ${msg}" >&2

    # Write to log file if session log dir is available
    if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
        echo "[$(date '+%Y-%m-%d %H:%M:%S')] [${level}] ${msg}" \
            >> "${SESSION_LOG_DIR}/agent-scaler.log" 2>/dev/null || true
    fi
}

# =============================================================================
# Detect .claude/agents/ directory
# =============================================================================
_as_detect_agents_dir() {
    local script_dir="${SCRIPT_DIR:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
    local agents_dir="${script_dir}/.claude/agents"

    if [[ -d "$agents_dir" ]]; then
        echo "$agents_dir"
        return 0
    fi

    # Fallback: check relative to CWD
    if [[ -d ".claude/agents" ]]; then
        echo "$(cd ".claude/agents" && pwd)"
        return 0
    fi

    echo ""
    return 1
}

# =============================================================================
# Parse agent .md file to extract metadata
# Looks for YAML-like front matter or header comments
# =============================================================================
_as_parse_agent_md() {
    local md_path="$1"
    local agent_id="$2"

    if [[ ! -f "$md_path" ]]; then
        echo ""
        return 1
    fi

    # Extract a simple role/specialty line from the .md header
    # Look for patterns like "# Role: Backend Developer" or specialties list
    local first_lines
    first_lines=$(head -20 "$md_path" 2>/dev/null || true)

    # Try to detect specialties from content keywords
    local detected_specialties=""
    local content_lower
    content_lower=$(echo "$first_lines" | tr '[:upper:]' '[:lower:]')

    # Match against known domains
    local -a domain_checks=(
        "backend:backend"
        "frontend:frontend"
        "database:database"
        "security:security"
        "test:testing"
        "deploy:deploy"
        "design:design"
        "api:api"
        "performance:performance"
        "documentation:documentation"
        "migration:migration"
        "integration:integration"
        "cost:cost"
        "quality:quality"
    )

    for check in "${domain_checks[@]}"; do
        local keyword="${check%%:*}"
        local specialty="${check#*:}"
        if echo "$content_lower" | grep -q "$keyword" 2>/dev/null; then
            if [[ -n "$detected_specialties" ]]; then
                detected_specialties="${detected_specialties},${specialty}"
            else
                detected_specialties="$specialty"
            fi
        fi
    done

    echo "${detected_specialties:-general}"
    return 0
}

# =============================================================================
# as_init(session_id)
#   Initialize the agent scaler, scan and register all agent definitions.
# =============================================================================
as_init() {
    local session_id="${1:-${SESSION_ID:-as-$(date +%Y%m%d-%H%M%S)}}"

    AS_SESSION_ID="$session_id"
    AS_ENABLED="true"
    AS_TOTAL_AGENTS=0
    AS_ACTIVE_COUNT=0
    AS_ACTIVE_AGENTS=""
    AS_TOTAL_DISPATCHES=0

    # Reset registries
    AS_AGENT_PATHS=()
    AS_AGENT_SPECIALTIES=()
    AS_AGENT_MODEL_TIER=()
    AS_AGENT_MAX_RETRIES=()
    AS_AGENT_TIMEOUT=()
    AS_AGENT_PRIORITY=()
    AS_STAT_CALLS=()
    AS_STAT_SUCCESS=()
    AS_STAT_FAIL=()
    AS_STAT_TOTAL_TIME=()

    # Locate agents directory
    AS_AGENTS_DIR=$(_as_detect_agents_dir)
    if [[ -z "$AS_AGENTS_DIR" ]]; then
        _as_log "WARN" "エージェント定義ディレクトリ未検出"
        AS_ENABLED="false"
        return 1
    fi

    _as_log "INFO" "Agent Scaler v${AS_VERSION} 初期化開始: ${AS_AGENTS_DIR}"

    # Register all 15 default agents
    local registered=0
    for agent_id in "${!AS_DEFAULT_AGENTS[@]}"; do
        local def="${AS_DEFAULT_AGENTS[$agent_id]}"
        local specialties model_tier max_retries timeout priority

        # Parse pipe-delimited definition
        IFS='|' read -r specialties model_tier max_retries timeout priority <<< "$def"

        local md_path="${AS_AGENTS_DIR}/${agent_id}.md"

        # Register even if .md file doesn't exist yet (will use defaults)
        as_register_agent "$agent_id" "$md_path" "$specialties" "$model_tier" \
                         "$max_retries" "$timeout" "$priority"
        registered=$((registered + 1))
    done

    # Scan for any additional .md files not in the default list
    for md_file in "${AS_AGENTS_DIR}"/*.md; do
        [[ -f "$md_file" ]] || continue
        local fname
        fname=$(basename "$md_file" .md)

        # Skip if already registered
        if [[ -n "${AS_AGENT_PATHS[$fname]:-}" ]]; then
            continue
        fi

        # Auto-detect specialties from content
        local auto_specialties
        auto_specialties=$(_as_parse_agent_md "$md_file" "$fname")

        as_register_agent "$fname" "$md_file" "${auto_specialties:-general}" \
                         "balanced" "3" "300" "5"
        registered=$((registered + 1))
        _as_log "INFO" "追加エージェント自動検出: ${fname}"
    done

    _as_log "SUCCESS" "Agent Scaler 初期化完了: ${AS_TOTAL_AGENTS}エージェント登録済み (最大並列=${AS_MAX_PARALLEL})"

    # Emit observatory event if available
    if type -t obs_emit_event &>/dev/null; then
        obs_emit_event "SCALER_INIT" \
            "{\"version\":\"${AS_VERSION}\",\"agents\":${AS_TOTAL_AGENTS},\"max_parallel\":${AS_MAX_PARALLEL}}" \
            2>/dev/null || true
    fi

    return 0
}

# =============================================================================
# as_register_agent(agent_id, md_path, specialties, model_tier,
#                   max_retries, timeout, priority)
#   Register an agent in the scaler registry.
# =============================================================================
as_register_agent() {
    local agent_id="$1"
    local md_path="${2:-}"
    local specialties="${3:-general}"
    local model_tier="${4:-balanced}"
    local max_retries="${5:-3}"
    local timeout="${6:-300}"
    local priority="${7:-3}"

    if [[ -z "$agent_id" ]]; then
        _as_log "ERROR" "as_register_agent: agent_id が空です"
        return 1
    fi

    # Validate model tier
    case "$model_tier" in
        frontier|balanced|economy) ;;
        *) model_tier="balanced" ;;
    esac

    AS_AGENT_PATHS["$agent_id"]="$md_path"
    AS_AGENT_SPECIALTIES["$agent_id"]="$specialties"
    AS_AGENT_MODEL_TIER["$agent_id"]="$model_tier"
    AS_AGENT_MAX_RETRIES["$agent_id"]="$max_retries"
    AS_AGENT_TIMEOUT["$agent_id"]="$timeout"
    AS_AGENT_PRIORITY["$agent_id"]="$priority"

    # Initialize stats
    AS_STAT_CALLS["$agent_id"]="${AS_STAT_CALLS[$agent_id]:-0}"
    AS_STAT_SUCCESS["$agent_id"]="${AS_STAT_SUCCESS[$agent_id]:-0}"
    AS_STAT_FAIL["$agent_id"]="${AS_STAT_FAIL[$agent_id]:-0}"
    AS_STAT_TOTAL_TIME["$agent_id"]="${AS_STAT_TOTAL_TIME[$agent_id]:-0}"

    # Update total count (only count new registrations)
    if [[ "${AS_STAT_CALLS[$agent_id]}" == "0" ]]; then
        AS_TOTAL_AGENTS=$((AS_TOTAL_AGENTS + 1))
    fi

    return 0
}

# =============================================================================
# as_get_agents_for_phase(phase_name)
#   Return space-separated list of agent IDs for a given phase.
#   This is the primary interface called by agent-runtime.sh.
# =============================================================================
as_get_agents_for_phase() {
    local phase="$1"

    if [[ -z "$phase" ]]; then
        echo ""
        return 1
    fi

    # Look up in phase-agents mapping
    local agents="${AS_PHASE_AGENTS[$phase]:-}"

    if [[ -n "$agents" ]]; then
        # Filter to only registered agents with existing .md files
        local valid_agents=""
        for agent_id in $agents; do
            if [[ -n "${AS_AGENT_PATHS[$agent_id]:-}" ]]; then
                if [[ -n "$valid_agents" ]]; then
                    valid_agents="${valid_agents} ${agent_id}"
                else
                    valid_agents="$agent_id"
                fi
            fi
        done

        if [[ -n "$valid_agents" ]]; then
            echo "$valid_agents"
            return 0
        fi
    fi

    # Fallback: try to match phase name against agent specialties
    local matched=""
    for agent_id in "${!AS_AGENT_SPECIALTIES[@]}"; do
        local specs="${AS_AGENT_SPECIALTIES[$agent_id]}"
        if echo ",$specs," | grep -qi ",${phase}," 2>/dev/null; then
            if [[ -n "$matched" ]]; then
                matched="${matched} ${agent_id}"
            else
                matched="$agent_id"
            fi
        fi
    done

    echo "$matched"
    return 0
}

# =============================================================================
# _as_keyword_match(task_description)
#   Internal: keyword-based heuristic to find matching agents.
#   Returns space-separated agent IDs.
# =============================================================================
_as_keyword_match() {
    local task="$1"
    local task_lower
    task_lower=$(echo "$task" | tr '[:upper:]' '[:lower:]')

    local matched_agents=""
    local -A already_added=()

    # Keyword groups mapped to agents
    # Format: "keyword_pattern:agent_id"
    local -a keyword_rules=(
        # Database related
        "database:db-architect"
        "db:db-architect"
        "データベース:db-architect"
        "スキーマ:db-architect"
        "schema:db-architect"
        "sql:db-architect"
        "postgresql:db-architect"
        "mysql:db-architect"
        "mongodb:db-architect"
        "redis:db-architect"
        "migration:migration-engineer"
        "マイグレーション:migration-engineer"

        # Security related
        "security:security-auditor"
        "セキュリティ:security-auditor"
        "owasp:security-auditor"
        "vulnerability:security-auditor"
        "脆弱性:security-auditor"
        "audit:security-auditor"
        "監査:security-auditor"
        "encryption:security-auditor"
        "暗号:security-auditor"
        "authentication:security-auditor"
        "認証:security-auditor"

        # API related
        "api:api-designer"
        "rest:api-designer"
        "graphql:api-designer"
        "openapi:api-designer"
        "swagger:api-designer"
        "grpc:api-designer"
        "websocket:api-designer"
        "endpoint:api-designer"
        "エンドポイント:api-designer"

        # Testing related
        "test:test-architect"
        "テスト:test-architect"
        "tdd:test-architect"
        "bdd:test-architect"
        "coverage:test-architect"
        "カバレッジ:test-architect"
        "regression:test-architect"

        # Performance related
        "performance:performance-engineer"
        "パフォーマンス:performance-engineer"
        "profiling:performance-engineer"
        "optimization:performance-engineer"
        "最適化:performance-engineer"
        "caching:performance-engineer"
        "キャッシュ:performance-engineer"
        "load:performance-engineer"
        "負荷:performance-engineer"
        "速度:performance-engineer"

        # Documentation related
        "documentation:documentation-writer"
        "ドキュメント:documentation-writer"
        "readme:documentation-writer"
        "doc:documentation-writer"
        "文書:documentation-writer"
        "マニュアル:documentation-writer"

        # Integration related
        "integration:integration-engineer"
        "統合:integration-engineer"
        "連携:integration-engineer"
        "webhook:integration-engineer"
        "oauth:integration-engineer"
        "third-party:integration-engineer"
        "外部api:integration-engineer"
        "sdk:integration-engineer"

        # Migration related
        "migration:migration-engineer"
        "移行:migration-engineer"
        "upgrade:migration-engineer"
        "アップグレード:migration-engineer"
        "backward:migration-engineer"
        "互換:migration-engineer"

        # Backend related
        "backend:backend-dev"
        "バックエンド:backend-dev"
        "server:backend-dev"
        "サーバー:backend-dev"
        "nodejs:backend-dev"
        "express:backend-dev"
        "python:backend-dev"
        "flask:backend-dev"
        "fastapi:backend-dev"

        # Frontend related
        "frontend:frontend-dev"
        "フロントエンド:frontend-dev"
        "react:frontend-dev"
        "vue:frontend-dev"
        "nextjs:frontend-dev"
        "next.js:frontend-dev"
        "ui:designer"
        "ux:designer"
        "デザイン:designer"
        "design:designer"
        "tailwind:frontend-dev"
        "css:frontend-dev"

        # DevOps related
        "deploy:devops"
        "デプロイ:devops"
        "docker:devops"
        "kubernetes:devops"
        "k8s:devops"
        "ci/cd:devops"
        "cicd:devops"
        "infrastructure:devops"
        "インフラ:devops"

        # QA related
        "quality:qa-engineer"
        "品質:qa-engineer"
        "validation:qa-engineer"
        "バリデーション:qa-engineer"
        "e2e:qa-engineer"

        # PM related
        "要件:pm"
        "requirements:pm"
        "planning:pm"
        "計画:pm"
        "project:pm"
        "プロジェクト:pm"

        # Cost related
        "cost:cost-optimizer"
        "コスト:cost-optimizer"
        "budget:cost-optimizer"
        "予算:cost-optimizer"
        "pricing:cost-optimizer"
        "料金:cost-optimizer"

        # iOS/Mobile related
        "ios:ios-dev"
        "swift:ios-dev"
        "swiftui:ios-dev"
        "uikit:ios-dev"
        "xcode:ios-dev"
        "iphone:ios-dev"
        "ipad:ios-dev"
        "coredata:ios-dev"
        "mobile:mobile-architect"
        "モバイル:mobile-architect"
        "アプリ:mobile-architect"
    )

    for rule in "${keyword_rules[@]}"; do
        local keyword="${rule%%:*}"
        local agent="${rule#*:}"

        if echo "$task_lower" | grep -q "$keyword" 2>/dev/null; then
            if [[ -z "${already_added[$agent]:-}" ]]; then
                already_added["$agent"]=1
                if [[ -n "$matched_agents" ]]; then
                    matched_agents="${matched_agents} ${agent}"
                else
                    matched_agents="$agent"
                fi
            fi
        fi
    done

    echo "$matched_agents"
}

# =============================================================================
# as_select_agents(task_description)
#   Select the optimal set of agents for a task based on keyword heuristics.
#   Returns JSON array of agent selections.
# =============================================================================
as_select_agents() {
    local task="${1:-}"

    if [[ -z "$task" ]]; then
        echo "[]"
        return 1
    fi

    # Run keyword-based heuristic
    local matched
    matched=$(_as_keyword_match "$task")

    # If no matches, default to PM + backend-dev
    if [[ -z "$matched" ]]; then
        matched="pm backend-dev"
        _as_log "INFO" "キーワード一致なし - デフォルトエージェント選択: ${matched}"
    else
        _as_log "INFO" "タスク分析で${#matched[@]}エージェント選択: ${matched}"
    fi

    # Build JSON output
    local json_array="["
    local first=true

    for agent_id in $matched; do
        # Verify agent is registered
        if [[ -z "${AS_AGENT_PATHS[$agent_id]:-}" ]]; then
            continue
        fi

        local priority="${AS_AGENT_PRIORITY[$agent_id]:-3}"
        local tier="${AS_AGENT_MODEL_TIER[$agent_id]:-balanced}"

        if [[ "$first" == "true" ]]; then
            first=false
        else
            json_array="${json_array},"
        fi

        json_array="${json_array}{\"id\":\"${agent_id}\",\"priority\":${priority},\"model_tier\":\"${tier}\"}"
    done

    json_array="${json_array}]"
    echo "$json_array"
    return 0
}

# =============================================================================
# as_get_agent_config(agent_id)
#   Get a single agent's configuration as JSON.
# =============================================================================
as_get_agent_config() {
    local agent_id="$1"

    if [[ -z "$agent_id" || -z "${AS_AGENT_PATHS[$agent_id]:-}" ]]; then
        _as_log "WARN" "エージェント未登録: ${agent_id}"
        echo "{}"
        return 1
    fi

    local path="${AS_AGENT_PATHS[$agent_id]}"
    local specialties="${AS_AGENT_SPECIALTIES[$agent_id]:-general}"
    local model_tier="${AS_AGENT_MODEL_TIER[$agent_id]:-balanced}"
    local max_retries="${AS_AGENT_MAX_RETRIES[$agent_id]:-3}"
    local timeout="${AS_AGENT_TIMEOUT[$agent_id]:-300}"
    local priority="${AS_AGENT_PRIORITY[$agent_id]:-3}"
    local has_md="false"
    [[ -f "$path" ]] && has_md="true"

    cat <<EOJSON
{"id":"${agent_id}","path":"${path}","specialties":"${specialties}","model_tier":"${model_tier}","max_retries":${max_retries},"timeout":${timeout},"priority":${priority},"has_definition":${has_md}}
EOJSON
    return 0
}

# =============================================================================
# as_list_agents()
#   Print all registered agents in a formatted table.
# =============================================================================
as_list_agents() {
    local header_color="${CYAN:-\033[0;36m}"
    local reset="${NC:-\033[0m}"
    local green="${GREEN:-\033[0;32m}"
    local yellow="${YELLOW:-\033[1;33m}"
    local dim="${DIM:-\033[2m}"

    echo ""
    echo -e "${header_color}╔══════════════════════════════════════════════════════════════════════════════╗${reset}"
    echo -e "${header_color}║            SoloptiLink Agent Scaler v${AS_VERSION} - Agent Registry                  ║${reset}"
    echo -e "${header_color}╠══════════════════════════════════════════════════════════════════════════════╣${reset}"
    printf "${header_color}║${reset} %-22s %-10s %-8s %-7s %-6s %-5s ${header_color}║${reset}\n" \
        "AGENT ID" "TIER" "RETRIES" "TIMEOUT" "PRI" "DEF"
    echo -e "${header_color}╠══════════════════════════════════════════════════════════════════════════════╣${reset}"

    # Sort agents by priority
    local sorted_agents
    sorted_agents=$(
        for agent_id in "${!AS_AGENT_PATHS[@]}"; do
            echo "${AS_AGENT_PRIORITY[$agent_id]:-9} $agent_id"
        done | sort -n | awk '{print $2}'
    )

    for agent_id in $sorted_agents; do
        local tier="${AS_AGENT_MODEL_TIER[$agent_id]:-balanced}"
        local retries="${AS_AGENT_MAX_RETRIES[$agent_id]:-3}"
        local timeout="${AS_AGENT_TIMEOUT[$agent_id]:-300}"
        local priority="${AS_AGENT_PRIORITY[$agent_id]:-3}"
        local has_md="N"
        [[ -f "${AS_AGENT_PATHS[$agent_id]:-}" ]] && has_md="Y"

        local tier_color="$reset"
        case "$tier" in
            frontier) tier_color="${yellow}" ;;
            balanced) tier_color="${green}" ;;
            economy)  tier_color="${dim}" ;;
        esac

        printf "${header_color}║${reset} %-22s ${tier_color}%-10s${reset} %-8s %-7s %-6s %-5s ${header_color}║${reset}\n" \
            "$agent_id" "$tier" "$retries" "${timeout}s" "$priority" "$has_md"
    done

    echo -e "${header_color}╠══════════════════════════════════════════════════════════════════════════════╣${reset}"
    printf "${header_color}║${reset} Total: %-3d agents | Max parallel: %-3d | Active: %-3d                        ${header_color}║${reset}\n" \
        "$AS_TOTAL_AGENTS" "$AS_MAX_PARALLEL" "$AS_ACTIVE_COUNT"
    echo -e "${header_color}╚══════════════════════════════════════════════════════════════════════════════╝${reset}"
    echo ""

    return 0
}

# =============================================================================
# as_get_agent_stats(agent_id)
#   Get execution statistics for an agent (or all if agent_id is empty).
#   Returns formatted text output.
# =============================================================================
as_get_agent_stats() {
    local agent_id="${1:-}"

    if [[ -n "$agent_id" ]]; then
        # Stats for a single agent
        local calls="${AS_STAT_CALLS[$agent_id]:-0}"
        local success="${AS_STAT_SUCCESS[$agent_id]:-0}"
        local fail="${AS_STAT_FAIL[$agent_id]:-0}"
        local total_time="${AS_STAT_TOTAL_TIME[$agent_id]:-0}"

        local success_rate=0
        if [[ "$calls" -gt 0 ]]; then
            success_rate=$(( (success * 100) / calls ))
        fi

        local avg_time=0
        if [[ "$calls" -gt 0 ]]; then
            avg_time=$(( total_time / calls ))
        fi

        cat <<EOSTATS
{"agent_id":"${agent_id}","calls":${calls},"success":${success},"fail":${fail},"success_rate":${success_rate},"avg_time_sec":${avg_time},"total_time_sec":${total_time}}
EOSTATS
        return 0
    fi

    # Stats for all agents
    echo "{"
    echo "  \"total_dispatches\": ${AS_TOTAL_DISPATCHES},"
    echo "  \"total_agents\": ${AS_TOTAL_AGENTS},"
    echo "  \"agents\": {"

    local first=true
    for aid in "${!AS_STAT_CALLS[@]}"; do
        local calls="${AS_STAT_CALLS[$aid]:-0}"
        [[ "$calls" -eq 0 ]] && continue

        local success="${AS_STAT_SUCCESS[$aid]:-0}"
        local fail="${AS_STAT_FAIL[$aid]:-0}"
        local total_time="${AS_STAT_TOTAL_TIME[$aid]:-0}"

        local success_rate=0
        if [[ "$calls" -gt 0 ]]; then
            success_rate=$(( (success * 100) / calls ))
        fi

        if [[ "$first" == "true" ]]; then
            first=false
        else
            echo ","
        fi

        printf '    "%s": {"calls":%d,"success":%d,"fail":%d,"rate":%d%%,"time":%ds}' \
            "$aid" "$calls" "$success" "$fail" "$success_rate" "$total_time"
    done

    echo ""
    echo "  }"
    echo "}"
    return 0
}

# =============================================================================
# as_record_execution(agent_id, success, duration_sec)
#   Record the result of an agent execution for statistics.
# =============================================================================
as_record_execution() {
    local agent_id="$1"
    local success="${2:-1}"    # 0=success, 1=failure
    local duration="${3:-0}"

    AS_TOTAL_DISPATCHES=$((AS_TOTAL_DISPATCHES + 1))
    AS_STAT_CALLS["$agent_id"]=$(( ${AS_STAT_CALLS[$agent_id]:-0} + 1 ))
    AS_STAT_TOTAL_TIME["$agent_id"]=$(( ${AS_STAT_TOTAL_TIME[$agent_id]:-0} + duration ))

    if [[ "$success" -eq 0 ]]; then
        AS_STAT_SUCCESS["$agent_id"]=$(( ${AS_STAT_SUCCESS[$agent_id]:-0} + 1 ))
    else
        AS_STAT_FAIL["$agent_id"]=$(( ${AS_STAT_FAIL[$agent_id]:-0} + 1 ))
    fi

    # Emit observatory event
    if type -t obs_emit_event &>/dev/null; then
        local status_str="error"
        [[ "$success" -eq 0 ]] && status_str="ok"
        obs_emit_event "AGENT_EXEC" \
            "{\"agent\":\"${agent_id}\",\"status\":\"${status_str}\",\"duration\":${duration}}" \
            2>/dev/null || true
    fi

    return 0
}

# =============================================================================
# as_activate_agent(agent_id)
#   Mark an agent as active (running).
# =============================================================================
as_activate_agent() {
    local agent_id="$1"

    # Check if already active
    if echo " ${AS_ACTIVE_AGENTS} " | grep -q " ${agent_id} " 2>/dev/null; then
        return 0
    fi

    AS_ACTIVE_AGENTS="${AS_ACTIVE_AGENTS} ${agent_id}"
    AS_ACTIVE_COUNT=$((AS_ACTIVE_COUNT + 1))
    _as_log "DEBUG" "エージェント起動: ${agent_id} (アクティブ: ${AS_ACTIVE_COUNT}/${AS_MAX_PARALLEL})"
    return 0
}

# =============================================================================
# as_deactivate_agent(agent_id)
#   Mark an agent as no longer active.
# =============================================================================
as_deactivate_agent() {
    local agent_id="$1"

    AS_ACTIVE_AGENTS=$(echo " ${AS_ACTIVE_AGENTS} " | sed "s/ ${agent_id} / /g" | xargs)
    if [[ "$AS_ACTIVE_COUNT" -gt 0 ]]; then
        AS_ACTIVE_COUNT=$((AS_ACTIVE_COUNT - 1))
    fi
    _as_log "DEBUG" "エージェント停止: ${agent_id} (アクティブ: ${AS_ACTIVE_COUNT}/${AS_MAX_PARALLEL})"
    return 0
}

# =============================================================================
# as_can_scale()
#   Check whether a new agent can be spawned.
#   Returns 0 if scaling is possible, 1 if not.
# =============================================================================
as_can_scale() {
    # Check parallel limit
    if [[ "$AS_ACTIVE_COUNT" -ge "$AS_MAX_PARALLEL" ]]; then
        _as_log "WARN" "並列上限到達: ${AS_ACTIVE_COUNT}/${AS_MAX_PARALLEL}"
        return 1
    fi

    # Check CPU usage (macOS and Linux compatible)
    local cpu_usage=0
    if [[ "$(uname)" == "Darwin" ]]; then
        # macOS: extract CPU idle from top -l 1
        local idle_pct
        idle_pct=$(top -l 1 -n 0 2>/dev/null | awk '/CPU usage/ {
            for(i=1;i<=NF;i++) if($i ~ /idle/) { gsub(/%/,"",$(i-1)); print int($(i-1)) }
        }' 2>/dev/null) || true
        if [[ -n "$idle_pct" && "$idle_pct" =~ ^[0-9]+$ ]]; then
            cpu_usage=$((100 - idle_pct))
        fi
    else
        # Linux: extract from /proc/stat
        if [[ -f /proc/stat ]]; then
            local stat_line
            stat_line=$(head -1 /proc/stat 2>/dev/null)
            local idle_val total_val
            idle_val=$(echo "$stat_line" | awk '{print $5}')
            total_val=$(echo "$stat_line" | awk '{s=0; for(i=2;i<=NF;i++) s+=$i; print s}')
            if [[ -n "$total_val" && "$total_val" -gt 0 ]] 2>/dev/null; then
                cpu_usage=$(( ((total_val - idle_val) * 100) / total_val ))
            fi
        fi
    fi

    if [[ -n "$cpu_usage" && "$cpu_usage" =~ ^[0-9]+$ && "$cpu_usage" -gt "$AS_CPU_THRESHOLD" ]] 2>/dev/null; then
        _as_log "WARN" "CPU使用率が閾値超過: ${cpu_usage}% > ${AS_CPU_THRESHOLD}%"
        return 1
    fi

    # Check memory usage
    local mem_usage=0
    if [[ "$(uname)" == "Darwin" ]]; then
        # macOS: use vm_stat - parse page counts (values end with '.')
        local pages_free pages_active pages_wired
        pages_free=$(vm_stat 2>/dev/null | awk '/Pages free:/ {gsub(/\./,"",$NF); print $NF}') || true
        pages_active=$(vm_stat 2>/dev/null | awk '/Pages active:/ {gsub(/\./,"",$NF); print $NF}') || true
        pages_wired=$(vm_stat 2>/dev/null | awk '/Pages wired down:/ {gsub(/\./,"",$NF); print $NF}') || true

        # Default to 0 if not numeric
        [[ ! "$pages_free" =~ ^[0-9]+$ ]] && pages_free=0
        [[ ! "$pages_active" =~ ^[0-9]+$ ]] && pages_active=0
        [[ ! "$pages_wired" =~ ^[0-9]+$ ]] && pages_wired=0

        local total_pages=$(( pages_free + pages_active + pages_wired ))
        if [[ "$total_pages" -gt 0 ]]; then
            local used_pages=$(( pages_active + pages_wired ))
            mem_usage=$(( (used_pages * 100) / total_pages ))
        fi
    else
        # Linux: use /proc/meminfo
        if [[ -f /proc/meminfo ]]; then
            local total avail
            total=$(awk '/MemTotal/ {print $2}' /proc/meminfo 2>/dev/null || echo 0)
            avail=$(awk '/MemAvailable/ {print $2}' /proc/meminfo 2>/dev/null || echo 0)
            if [[ "$total" -gt 0 ]] 2>/dev/null; then
                mem_usage=$(( ((total - avail) * 100) / total ))
            fi
        fi
    fi

    if [[ -n "$mem_usage" && "$mem_usage" =~ ^[0-9]+$ && "$mem_usage" -gt "$AS_MEM_THRESHOLD" ]] 2>/dev/null; then
        _as_log "WARN" "メモリ使用率が閾値超過: ${mem_usage}% > ${AS_MEM_THRESHOLD}%"
        return 1
    fi

    return 0
}

# =============================================================================
# as_enforce_limits()
#   Enforce resource limits. If system resources are strained, reduce
#   the maximum parallel count dynamically.
# =============================================================================
as_enforce_limits() {
    local original_max="$AS_MAX_PARALLEL"

    # Check CPU usage
    local cpu_usage=0
    if [[ "$(uname)" == "Darwin" ]]; then
        local idle_pct
        idle_pct=$(top -l 1 -n 0 2>/dev/null | awk '/CPU usage/ {
            for(i=1;i<=NF;i++) if($i ~ /idle/) { gsub(/%/,"",$(i-1)); print int($(i-1)) }
        }' 2>/dev/null) || true
        if [[ -n "$idle_pct" && "$idle_pct" =~ ^[0-9]+$ ]]; then
            cpu_usage=$((100 - idle_pct))
        fi
    else
        if [[ -f /proc/stat ]]; then
            local stat_line
            stat_line=$(head -1 /proc/stat 2>/dev/null)
            local idle_val total_val
            idle_val=$(echo "$stat_line" | awk '{print $5}')
            total_val=$(echo "$stat_line" | awk '{s=0; for(i=2;i<=NF;i++) s+=$i; print s}')
            if [[ -n "$total_val" && "$total_val" -gt 0 ]] 2>/dev/null; then
                cpu_usage=$(( ((total_val - idle_val) * 100) / total_val ))
            fi
        fi
    fi

    # Dynamically adjust max parallel based on load
    if [[ "$cpu_usage" =~ ^[0-9]+$ ]]; then
        if [[ "$cpu_usage" -gt 90 ]]; then
            AS_MAX_PARALLEL=1
        elif [[ "$cpu_usage" -gt 80 ]]; then
            AS_MAX_PARALLEL=2
        elif [[ "$cpu_usage" -gt 70 ]]; then
            AS_MAX_PARALLEL=3
        else
            # Restore to default (max 5) if load is low
            AS_MAX_PARALLEL=5
        fi
    fi

    if [[ "$AS_MAX_PARALLEL" -ne "$original_max" ]]; then
        _as_log "INFO" "並列上限を動的調整: ${original_max} → ${AS_MAX_PARALLEL} (CPU: ${cpu_usage}%)"
    fi

    return 0
}

# =============================================================================
# as_get_primary_agent(phase)
#   Get the highest-priority (lowest priority number) agent for a phase.
#   Returns a single agent_id.
# =============================================================================
as_get_primary_agent() {
    local phase="$1"
    local agents
    agents=$(as_get_agents_for_phase "$phase")

    if [[ -z "$agents" ]]; then
        echo ""
        return 1
    fi

    # Find agent with highest priority (lowest number)
    local best_agent=""
    local best_priority=999

    for agent_id in $agents; do
        local priority="${AS_AGENT_PRIORITY[$agent_id]:-9}"
        if [[ "$priority" -lt "$best_priority" ]]; then
            best_priority="$priority"
            best_agent="$agent_id"
        fi
    done

    echo "$best_agent"
    return 0
}

# =============================================================================
# as_get_secondary_agents(phase)
#   Get all agents for a phase except the primary one.
#   Returns space-separated agent IDs.
# =============================================================================
as_get_secondary_agents() {
    local phase="$1"
    local primary
    primary=$(as_get_primary_agent "$phase")

    local all_agents
    all_agents=$(as_get_agents_for_phase "$phase")

    local secondary=""
    for agent_id in $all_agents; do
        if [[ "$agent_id" != "$primary" ]]; then
            if [[ -n "$secondary" ]]; then
                secondary="${secondary} ${agent_id}"
            else
                secondary="$agent_id"
            fi
        fi
    done

    echo "$secondary"
    return 0
}

# =============================================================================
# as_report()
#   Print a summary report of the agent scaler session.
# =============================================================================
as_report() {
    local header_color="${CYAN:-\033[0;36m}"
    local reset="${NC:-\033[0m}"
    local green="${GREEN:-\033[0;32m}"
    local red="${RED:-\033[0;31m}"
    local yellow="${YELLOW:-\033[1;33m}"

    echo ""
    echo -e "${header_color}╔═══════════════════════════════════════════════════════════╗${reset}"
    echo -e "${header_color}║         Agent Scaler v${AS_VERSION} - Session Report              ║${reset}"
    echo -e "${header_color}╠═══════════════════════════════════════════════════════════╣${reset}"
    printf "${header_color}║${reset} %-20s : %-34s ${header_color}║${reset}\n" \
        "Session ID" "$AS_SESSION_ID"
    printf "${header_color}║${reset} %-20s : %-34s ${header_color}║${reset}\n" \
        "Total Agents" "$AS_TOTAL_AGENTS"
    printf "${header_color}║${reset} %-20s : %-34s ${header_color}║${reset}\n" \
        "Total Dispatches" "$AS_TOTAL_DISPATCHES"
    printf "${header_color}║${reset} %-20s : %-34s ${header_color}║${reset}\n" \
        "Max Parallel" "$AS_MAX_PARALLEL"
    echo -e "${header_color}╠═══════════════════════════════════════════════════════════╣${reset}"

    # Per-agent stats
    local has_stats=false
    for agent_id in "${!AS_STAT_CALLS[@]}"; do
        local calls="${AS_STAT_CALLS[$agent_id]:-0}"
        [[ "$calls" -eq 0 ]] && continue
        has_stats=true

        local success="${AS_STAT_SUCCESS[$agent_id]:-0}"
        local fail="${AS_STAT_FAIL[$agent_id]:-0}"
        local rate=0
        [[ "$calls" -gt 0 ]] && rate=$(( (success * 100) / calls ))

        local rate_color="$green"
        [[ "$rate" -lt 80 ]] && rate_color="$yellow"
        [[ "$rate" -lt 50 ]] && rate_color="$red"

        printf "${header_color}║${reset}  %-18s : %d calls, ${rate_color}%d%%${reset} success, %d fail    ${header_color}║${reset}\n" \
            "$agent_id" "$calls" "$rate" "$fail"
    done

    if [[ "$has_stats" == "false" ]]; then
        printf "${header_color}║${reset}  %-50s       ${header_color}║${reset}\n" \
            "No agent executions recorded yet."
    fi

    echo -e "${header_color}╚═══════════════════════════════════════════════════════════╝${reset}"
    echo ""

    return 0
}

# =============================================================================
# as_export_json()
#   Export the full scaler state as JSON.
# =============================================================================
as_export_json() {
    echo "{"
    echo "  \"version\": \"${AS_VERSION}\","
    echo "  \"session_id\": \"${AS_SESSION_ID}\","
    echo "  \"enabled\": ${AS_ENABLED},"
    echo "  \"total_agents\": ${AS_TOTAL_AGENTS},"
    echo "  \"max_parallel\": ${AS_MAX_PARALLEL},"
    echo "  \"active_count\": ${AS_ACTIVE_COUNT},"
    echo "  \"total_dispatches\": ${AS_TOTAL_DISPATCHES},"
    echo "  \"agents\": {"

    local first=true
    for agent_id in "${!AS_AGENT_PATHS[@]}"; do
        if [[ "$first" == "true" ]]; then
            first=false
        else
            echo ","
        fi

        local path="${AS_AGENT_PATHS[$agent_id]}"
        local specs="${AS_AGENT_SPECIALTIES[$agent_id]:-general}"
        local tier="${AS_AGENT_MODEL_TIER[$agent_id]:-balanced}"
        local retries="${AS_AGENT_MAX_RETRIES[$agent_id]:-3}"
        local timeout="${AS_AGENT_TIMEOUT[$agent_id]:-300}"
        local priority="${AS_AGENT_PRIORITY[$agent_id]:-3}"
        local calls="${AS_STAT_CALLS[$agent_id]:-0}"
        local success="${AS_STAT_SUCCESS[$agent_id]:-0}"
        local fail="${AS_STAT_FAIL[$agent_id]:-0}"
        local has_md="false"
        [[ -f "$path" ]] && has_md="true"

        printf '    "%s": {"path":"%s","specialties":"%s","model_tier":"%s","max_retries":%d,"timeout":%d,"priority":%d,"has_definition":%s,"stats":{"calls":%d,"success":%d,"fail":%d}}' \
            "$agent_id" "$path" "$specs" "$tier" "$retries" "$timeout" "$priority" "$has_md" "$calls" "$success" "$fail"
    done

    echo ""
    echo "  },"
    echo "  \"phase_mapping\": {"

    local first_phase=true
    for phase in "${!AS_PHASE_AGENTS[@]}"; do
        if [[ "$first_phase" == "true" ]]; then
            first_phase=false
        else
            echo ","
        fi

        local agents="${AS_PHASE_AGENTS[$phase]}"
        # Convert space-separated to JSON array
        local json_arr="["
        local first_a=true
        for a in $agents; do
            if [[ "$first_a" == "true" ]]; then
                first_a=false
            else
                json_arr="${json_arr},"
            fi
            json_arr="${json_arr}\"${a}\""
        done
        json_arr="${json_arr}]"

        printf '    "%s": %s' "$phase" "$json_arr"
    done

    echo ""
    echo "  }"
    echo "}"

    return 0
}

# =============================================================================
# as_generate_dynamic_agent(task_description, suggested_name)
#   [STUB - v18.0] Dynamically generate an agent definition from task analysis.
#   In v17.0, this only logs the intent and returns a placeholder.
# =============================================================================
as_generate_dynamic_agent() {
    local task="${1:-}"
    local suggested_name="${2:-dynamic-agent}"

    _as_log "INFO" "[STUB v18.0] 動的エージェント生成リクエスト: ${suggested_name}"
    _as_log "INFO" "[STUB v18.0] タスク: ${task:0:80}..."
    _as_log "INFO" "[STUB v18.0] v18.0で実装予定 - Claude APIによるエージェント定義の自動生成"

    # Return a placeholder indicating this is a stub
    echo "{\"status\":\"stub\",\"version\":\"18.0\",\"message\":\"Dynamic agent generation not yet implemented\",\"suggested_name\":\"${suggested_name}\"}"
    return 0
}

# =============================================================================
# as_learn_from_execution(agent_id, task_type, success, duration, quality_score)
#   [STUB - v19.0] Learn from execution results to improve agent selection.
#   In v17.0, this only logs the data for future analysis.
# =============================================================================
as_learn_from_execution() {
    local agent_id="${1:-}"
    local task_type="${2:-unknown}"
    local success="${3:-1}"
    local duration="${4:-0}"
    local quality_score="${5:-0}"

    _as_log "INFO" "[STUB v19.0] 実行学習データ記録: agent=${agent_id}, task=${task_type}, success=${success}, duration=${duration}s, quality=${quality_score}"

    # Write learning data to episodic memory if available
    local memory_dir="${HOME}/.soloptilink/memory/episodic"
    if [[ -d "$memory_dir" ]] || mkdir -p "$memory_dir" 2>/dev/null; then
        local timestamp
        timestamp=$(date +%Y%m%d-%H%M%S)
        local entry="{\"timestamp\":\"${timestamp}\",\"agent\":\"${agent_id}\",\"task_type\":\"${task_type}\",\"success\":${success},\"duration\":${duration},\"quality\":${quality_score}}"

        echo "$entry" >> "${memory_dir}/agent_learning.jsonl" 2>/dev/null || true
    fi

    _as_log "INFO" "[STUB v19.0] v19.0で実装予定 - エージェント選択の自己最適化"

    echo "{\"status\":\"stub\",\"version\":\"19.0\",\"message\":\"Execution learning not yet implemented\"}"
    return 0
}

# =============================================================================
# as_set_max_parallel(n)
#   Update the maximum parallel agent limit.
# =============================================================================
as_set_max_parallel() {
    local n="${1:-5}"

    if [[ "$n" -lt 1 ]]; then
        n=1
    elif [[ "$n" -gt 15 ]]; then
        n=15
        _as_log "WARN" "並列上限は15が最大です"
    fi

    local old="$AS_MAX_PARALLEL"
    AS_MAX_PARALLEL="$n"
    _as_log "INFO" "並列上限変更: ${old} → ${n}"
    return 0
}

# =============================================================================
# as_reset_stats()
#   Reset all execution statistics.
# =============================================================================
as_reset_stats() {
    AS_TOTAL_DISPATCHES=0
    for agent_id in "${!AS_STAT_CALLS[@]}"; do
        AS_STAT_CALLS["$agent_id"]=0
        AS_STAT_SUCCESS["$agent_id"]=0
        AS_STAT_FAIL["$agent_id"]=0
        AS_STAT_TOTAL_TIME["$agent_id"]=0
    done
    _as_log "INFO" "実行統計をリセットしました"
    return 0
}

# =============================================================================
# as_is_registered(agent_id)
#   Check if an agent is registered.
#   Returns 0 if registered, 1 if not.
# =============================================================================
as_is_registered() {
    local agent_id="$1"
    [[ -n "${AS_AGENT_PATHS[$agent_id]:-}" ]]
}

# =============================================================================
# as_get_agents_by_specialty(specialty)
#   Find agents that have a given specialty.
#   Returns space-separated agent IDs.
# =============================================================================
as_get_agents_by_specialty() {
    local specialty="$1"
    local matched=""

    for agent_id in "${!AS_AGENT_SPECIALTIES[@]}"; do
        local specs="${AS_AGENT_SPECIALTIES[$agent_id]}"
        if echo ",$specs," | grep -qi ",${specialty}," 2>/dev/null; then
            if [[ -n "$matched" ]]; then
                matched="${matched} ${agent_id}"
            else
                matched="$agent_id"
            fi
        fi
    done

    echo "$matched"
    return 0
}

# =============================================================================
# as_get_agents_by_tier(tier)
#   Find all agents assigned to a given model tier.
#   Returns space-separated agent IDs.
# =============================================================================
as_get_agents_by_tier() {
    local tier="$1"
    local matched=""

    for agent_id in "${!AS_AGENT_MODEL_TIER[@]}"; do
        if [[ "${AS_AGENT_MODEL_TIER[$agent_id]}" == "$tier" ]]; then
            if [[ -n "$matched" ]]; then
                matched="${matched} ${agent_id}"
            else
                matched="$agent_id"
            fi
        fi
    done

    echo "$matched"
    return 0
}
