#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v283.0 - API Gateway Generator
# =============================================================================
# APIゲートウェイ自動生成エンジン。リクエストルーティング、認証プロキシ、
# レート制限、リクエスト集約を備えたゲートウェイを生成する。
#
# 機能一覧:
#   _agg_generate_gateway    - APIゲートウェイ本体生成
#   _agg_generate_routing    - リクエストルーティング設定
#   _agg_generate_auth_proxy - 認証プロキシ生成
#   _agg_inject_patterns     - Claudeプロンプトへのパターン注入
#
# 全globals: AGG_ prefix
# =============================================================================

[[ -n "${_AGG_LOADED:-}" ]] && return 0; _AGG_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g AGG_VERSION="283.0"
declare -g AGG_GENERATED=0
declare -g AGG_ERRORS=0
declare -g AGG_FILES_WRITTEN=0

# =============================================================================
# 初期化
# =============================================================================
agg_init() {
    AGG_GENERATED=0
    AGG_ERRORS=0
    AGG_FILES_WRITTEN=0
    return 0
}

_agg_write_file() {
    local filepath="$1"
    local content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then
        AGG_FILES_WRITTEN=$((AGG_FILES_WRITTEN + 1))
        echo "  [agg] wrote: $filepath" >&2
    else
        AGG_ERRORS=$((AGG_ERRORS + 1))
    fi
}

_agg_log() {
    echo -e "  ${GREEN:-\033[0;32m}[AGG]${NC:-\033[0m} $*" >&2
}

# =============================================================================
# _agg_generate_gateway - APIゲートウェイ本体
# =============================================================================
_agg_generate_gateway() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _agg_log "Generating API gateway..."

    local gateway_ts
    gateway_ts=$(cat <<'GWEOF'
// =============================================================================
// API Gateway - Central entry point for all microservices
// Features: routing, auth proxy, rate limiting, request aggregation
// =============================================================================
import express, { Request, Response, NextFunction } from 'express';
import { createProxyMiddleware, Options } from 'http-proxy-middleware';
import rateLimit from 'express-rate-limit';
import helmet from 'helmet';
import cors from 'cors';

const app = express();
const PORT = parseInt(process.env.GATEWAY_PORT || '3000');

// --- Security ---
app.use(helmet());
app.use(cors({
  origin: process.env.ALLOWED_ORIGINS?.split(',') || ['http://localhost:3000'],
  credentials: true,
}));
app.use(express.json({ limit: '10mb' }));

// --- Rate Limiting ---
const globalLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 1000,
  standardHeaders: true,
  legacyHeaders: false,
  message: { error: 'Too many requests, please try again later' },
});
app.use(globalLimiter);

// --- Health Check ---
app.get('/health', (req, res) => {
  res.json({
    status: 'ok',
    gateway: 'api-gateway',
    version: '1.0.0',
    timestamp: new Date().toISOString(),
    uptime: process.uptime(),
  });
});

// --- Request ID Middleware ---
app.use((req: Request, res: Response, next: NextFunction) => {
  const requestId = req.headers['x-request-id'] as string || crypto.randomUUID();
  req.headers['x-request-id'] = requestId;
  res.setHeader('x-request-id', requestId);
  next();
});

// --- Request Logging ---
app.use((req: Request, res: Response, next: NextFunction) => {
  const start = Date.now();
  res.on('finish', () => {
    const duration = Date.now() - start;
    console.log(JSON.stringify({
      method: req.method,
      path: req.path,
      status: res.statusCode,
      duration,
      requestId: req.headers['x-request-id'],
      timestamp: new Date().toISOString(),
    }));
  });
  next();
});

// --- Service Registry ---
interface ServiceConfig {
  name: string;
  url: string;
  pathPrefix: string;
  healthPath: string;
  timeout: number;
  retries: number;
}

const services: ServiceConfig[] = [
  { name: 'identity', url: process.env.IDENTITY_SERVICE_URL || 'http://localhost:3001', pathPrefix: '/api/auth', healthPath: '/health', timeout: 5000, retries: 2 },
  { name: 'users', url: process.env.USER_SERVICE_URL || 'http://localhost:3001', pathPrefix: '/api/users', healthPath: '/health', timeout: 5000, retries: 2 },
  { name: 'catalog', url: process.env.CATALOG_SERVICE_URL || 'http://localhost:3002', pathPrefix: '/api/products', healthPath: '/health', timeout: 5000, retries: 2 },
  { name: 'orders', url: process.env.ORDER_SERVICE_URL || 'http://localhost:3003', pathPrefix: '/api/orders', healthPath: '/health', timeout: 10000, retries: 3 },
  { name: 'billing', url: process.env.BILLING_SERVICE_URL || 'http://localhost:3004', pathPrefix: '/api/payments', healthPath: '/health', timeout: 15000, retries: 1 },
  { name: 'notifications', url: process.env.NOTIFICATION_SERVICE_URL || 'http://localhost:3005', pathPrefix: '/api/notifications', healthPath: '/health', timeout: 5000, retries: 2 },
];

// --- Proxy Setup ---
for (const service of services) {
  const proxyOptions: Options = {
    target: service.url,
    changeOrigin: true,
    timeout: service.timeout,
    proxyTimeout: service.timeout,
    on: {
      proxyReq: (proxyReq, req) => {
        proxyReq.setHeader('x-forwarded-service', service.name);
        proxyReq.setHeader('x-gateway-timestamp', Date.now().toString());
      },
      error: (err, req, res) => {
        console.error(`[gateway] Proxy error for ${service.name}:`, err.message);
        if ('writeHead' in res && typeof res.writeHead === 'function') {
          (res as any).writeHead(502).end(JSON.stringify({
            error: 'Bad Gateway',
            service: service.name,
            message: 'Service temporarily unavailable',
          }));
        }
      },
    },
  };
  app.use(service.pathPrefix, createProxyMiddleware(proxyOptions));
}

// --- Service Health Aggregation ---
app.get('/api/services/health', async (req: Request, res: Response) => {
  const results: Record<string, { status: string; latency?: number }> = {};
  for (const service of services) {
    const start = Date.now();
    try {
      const resp = await fetch(`${service.url}${service.healthPath}`, {
        signal: AbortSignal.timeout(3000),
      });
      results[service.name] = {
        status: resp.ok ? 'healthy' : 'degraded',
        latency: Date.now() - start,
      };
    } catch {
      results[service.name] = { status: 'down', latency: Date.now() - start };
    }
  }
  const allHealthy = Object.values(results).every((r) => r.status === 'healthy');
  res.status(allHealthy ? 200 : 503).json({ services: results, overall: allHealthy ? 'healthy' : 'degraded' });
});

// --- 404 ---
app.use((req: Request, res: Response) => {
  res.status(404).json({ error: 'Not Found', path: req.path });
});

// --- Start ---
app.listen(PORT, () => {
  console.log(`[API Gateway] Running on port ${PORT}`);
  console.log(`[API Gateway] Routing ${services.length} services`);
});

export { app, services };
GWEOF
)
    _agg_write_file "${project_dir}/gateway/src/server.ts" "$gateway_ts"
    AGG_GENERATED=$((AGG_GENERATED + 1))
    return 0
}

# =============================================================================
# _agg_generate_routing - ルーティング設定
# =============================================================================
_agg_generate_routing() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _agg_log "Generating routing configuration..."

    local routing_ts
    routing_ts=$(cat <<'RTEOF'
// =============================================================================
// API Gateway - Dynamic Routing Configuration
// =============================================================================

export interface RouteConfig {
  pathPattern: string;
  service: string;
  methods: Array<'GET' | 'POST' | 'PUT' | 'PATCH' | 'DELETE'>;
  requiresAuth: boolean;
  rateLimit?: { windowMs: number; max: number };
  transform?: {
    request?: (req: any) => any;
    response?: (res: any) => any;
  };
  cache?: { ttlSeconds: number; varyBy?: string[] };
}

export const routes: RouteConfig[] = [
  // Auth - no auth required
  { pathPattern: '/api/auth/login', service: 'identity', methods: ['POST'], requiresAuth: false, rateLimit: { windowMs: 900000, max: 10 } },
  { pathPattern: '/api/auth/register', service: 'identity', methods: ['POST'], requiresAuth: false, rateLimit: { windowMs: 3600000, max: 5 } },
  { pathPattern: '/api/auth/refresh', service: 'identity', methods: ['POST'], requiresAuth: false },
  // Users
  { pathPattern: '/api/users/:id', service: 'identity', methods: ['GET', 'PUT'], requiresAuth: true },
  { pathPattern: '/api/users', service: 'identity', methods: ['GET'], requiresAuth: true },
  // Products - read is public
  { pathPattern: '/api/products', service: 'catalog', methods: ['GET'], requiresAuth: false, cache: { ttlSeconds: 60, varyBy: ['category', 'search'] } },
  { pathPattern: '/api/products/:id', service: 'catalog', methods: ['GET'], requiresAuth: false, cache: { ttlSeconds: 120 } },
  { pathPattern: '/api/products', service: 'catalog', methods: ['POST', 'PUT', 'DELETE'], requiresAuth: true },
  // Orders
  { pathPattern: '/api/orders', service: 'orders', methods: ['GET', 'POST'], requiresAuth: true },
  { pathPattern: '/api/orders/:id', service: 'orders', methods: ['GET', 'PUT', 'PATCH'], requiresAuth: true },
  { pathPattern: '/api/cart', service: 'orders', methods: ['GET', 'POST', 'PUT', 'DELETE'], requiresAuth: true },
  // Payments
  { pathPattern: '/api/payments', service: 'billing', methods: ['POST'], requiresAuth: true },
  { pathPattern: '/api/invoices', service: 'billing', methods: ['GET'], requiresAuth: true },
  // Notifications
  { pathPattern: '/api/notifications', service: 'notifications', methods: ['GET', 'POST'], requiresAuth: true },
];

export function findRoute(path: string, method: string): RouteConfig | undefined {
  return routes.find((r) => {
    const pattern = r.pathPattern.replace(/:[\w]+/g, '[^/]+');
    const regex = new RegExp(`^${pattern}$`);
    return regex.test(path) && r.methods.includes(method as any);
  });
}

export function getServiceRoutes(serviceName: string): RouteConfig[] {
  return routes.filter((r) => r.service === serviceName);
}
RTEOF
)
    _agg_write_file "${project_dir}/gateway/src/routing.ts" "$routing_ts"
    AGG_GENERATED=$((AGG_GENERATED + 1))
    return 0
}

# =============================================================================
# _agg_generate_auth_proxy - 認証プロキシ
# =============================================================================
_agg_generate_auth_proxy() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _agg_log "Generating auth proxy..."

    local auth_ts
    auth_ts=$(cat <<'AUTHEOF'
// =============================================================================
// API Gateway - Authentication Proxy
// Validates JWT tokens before forwarding requests to services.
// =============================================================================
import { Request, Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';

const JWT_SECRET = process.env.JWT_SECRET || 'change-me-in-production';
const PUBLIC_PATHS = ['/api/auth/login', '/api/auth/register', '/api/auth/refresh', '/health'];

export interface AuthenticatedRequest extends Request {
  user?: { userId: string; email: string; role: string };
}

export function authProxy(req: AuthenticatedRequest, res: Response, next: NextFunction): void {
  // Skip auth for public paths
  if (PUBLIC_PATHS.some((p) => req.path.startsWith(p))) {
    return next();
  }

  // Skip auth for OPTIONS (CORS preflight)
  if (req.method === 'OPTIONS') {
    return next();
  }

  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    res.status(401).json({ error: 'Missing or invalid authorization header' });
    return;
  }

  const token = authHeader.substring(7);
  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string; email: string; role: string };
    req.user = decoded;

    // Forward user info to downstream services
    req.headers['x-user-id'] = decoded.userId;
    req.headers['x-user-email'] = decoded.email;
    req.headers['x-user-role'] = decoded.role;

    next();
  } catch (err: any) {
    if (err.name === 'TokenExpiredError') {
      res.status(401).json({ error: 'Token expired' });
    } else {
      res.status(401).json({ error: 'Invalid token' });
    }
  }
}

export function requireRole(...roles: string[]) {
  return (req: AuthenticatedRequest, res: Response, next: NextFunction) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Not authenticated' });
    }
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }
    next();
  };
}
AUTHEOF
)
    _agg_write_file "${project_dir}/gateway/src/auth-proxy.ts" "$auth_ts"
    AGG_GENERATED=$((AGG_GENERATED + 1))
    return 0
}

# =============================================================================
# _agg_inject_patterns
# =============================================================================
_agg_inject_patterns() {
    cat <<'INJECT'

## [API Gateway] ゲートウェイパターン

### 必須構成:
- **認証プロキシ**: JWT検証をゲートウェイで集中処理、x-user-*ヘッダーで伝播
- **レート制限**: エンドポイント別のレート制限
- **ルーティング**: パスベースでサービスへ振り分け
- **ヘルスチェック集約**: 全サービスの健全性を一括確認

INJECT
    echo "${1:-}"
}

# =============================================================================
# レポート & スコア
# =============================================================================
agg_report() {
    echo -e "\n  ${BOLD:-}=== api-gateway-generator v${AGG_VERSION} ===${NC:-}"
    echo -e "  生成数: ${AGG_GENERATED}"
    echo -e "  書込数: ${AGG_FILES_WRITTEN}"
    echo -e "  エラー: ${AGG_ERRORS}"
}

agg_score() {
    if [[ ${AGG_GENERATED} -ge 3 ]] && [[ ${AGG_ERRORS} -eq 0 ]]; then echo "95"
    elif [[ ${AGG_GENERATED} -gt 0 ]] && [[ ${AGG_ERRORS} -eq 0 ]]; then echo "85"
    else echo "50"; fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "api-gateway-generator" --version "${AGG_VERSION}" \
        --description "APIゲートウェイ×認証プロキシ×ルーティング×レート制限" \
        --init "agg_init" --report "agg_report" --score "agg_score" \
        --enable-var "ENABLE_API_GATEWAY" --cli-flags "--api-gateway:--no-api-gateway"
fi

# v2003.1: source時のexit codeを確実に0にする
true
