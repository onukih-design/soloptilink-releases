#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v258.0 - Prisma Error Expert
# =============================================================================
# Prisma ORM固有のエラーパターンを専門的に解析・修正するエキスパートモジュール。
# 20+の一般的なPrismaエラーパターンと修正テンプレートのデータベースを内蔵。
#
# 対象エラー:
#   - Migration errors (drift, failed, pending)
#   - Relation errors (missing, wrong cardinality, ambiguous)
#   - Unique constraint violations (P2002)
#   - Schema validation errors
#   - Client generation errors
#   - Database connection errors (P1001, P1002)
#   - Query errors (P2025, P2003, P2014)
#   - Introspection errors
#
# Functions:
#   _pee_init                   - 初期化・パターンDB構築
#   _pee_fix_migration          - Migration errors
#   _pee_fix_relation           - Relation errors
#   _pee_fix_unique_constraint  - Unique constraint violations
#   _pee_fix_schema_validation  - Schema validation errors
#   _pee_fix_client_generation  - Client generation errors
#   _pee_fix_connection         - Database connection errors
#   _pee_classify               - Classify Prisma error
#   _pee_get_fix_prompt         - Generate Claude prompt
#   _pee_report                 - Report output
#   _pee_score                  - Module score (0-100)
#
# All globals use the PEE_ prefix.
# =============================================================================

[[ -n "${_PRISMA_ERROR_EXPERT_LOADED:-}" ]] && return 0
_PRISMA_ERROR_EXPERT_LOADED=1

# --- Colors ---
readonly _PEE_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly _PEE_YELLOW="${CLR_YELLOW:-\033[0;33m}"
readonly _PEE_RED="${CLR_RED:-\033[0;31m}"
readonly _PEE_BLUE="${CLR_BLUE:-\033[0;34m}"
readonly _PEE_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly _PEE_PURPLE="${CLR_PURPLE:-\033[0;35m}"
readonly _PEE_BOLD="${CLR_BOLD:-\033[1m}"
readonly _PEE_NC="${CLR_NC:-\033[0m}"

# --- Module State ---
PEE_VERSION="258.0"
PEE_INITIALIZED=false
PEE_ENABLED="${PEE_ENABLED:-true}"

# --- Counters ---
PEE_TOTAL_ANALYZED=0
PEE_TOTAL_FIXED=0
PEE_TOTAL_PROMPTS=0
PEE_FIX_SUCCESS=0
PEE_FIX_FAIL=0
PEE_MIGRATIONS_FIXED=0
PEE_RELATIONS_FIXED=0
PEE_CONSTRAINTS_FIXED=0
PEE_SCHEMA_FIXED=0
PEE_CLIENT_FIXED=0
PEE_CONNECTION_FIXED=0

# --- Storage ---
PEE_STORE_DIR=""
PEE_HISTORY_FILE=""

# --- Pattern Database ---
# Format: "prisma_code|pattern_regex|category|fix_fn|severity|description"
declare -g -a _PEE_PATTERNS=()

# --- Error buffer ---
declare -g -a _PEE_ERROR_MSGS=()
declare -g -a _PEE_ERROR_FILES=()
declare -g -a _PEE_ERROR_CODES=()
declare -g -a _PEE_ERROR_CATEGORIES=()

# =============================================================================
# Pattern Database - 25 common Prisma error patterns
# =============================================================================
_pee_init_patterns() {
    _PEE_PATTERNS=()

    # --- Connection Errors (P1xxx) ---
    _PEE_PATTERNS+=("P1001|Can't reach database server|connection|_pee_tmpl_p1001|10|Database server unreachable")
    _PEE_PATTERNS+=("P1002|database server .* timed out|connection_timeout|_pee_tmpl_p1002|9|Database connection timeout")
    _PEE_PATTERNS+=("P1003|does not exist at|db_not_found|_pee_tmpl_p1003|8|Database file/name not found")
    _PEE_PATTERNS+=("P1008|Operations timed out|operation_timeout|_pee_tmpl_p1008|7|Database operation timeout")
    _PEE_PATTERNS+=("P1009|already exists on the database server|db_already_exists|_pee_tmpl_p1009|5|Database already exists")
    _PEE_PATTERNS+=("P1010|denied access|access_denied|_pee_tmpl_p1010|9|Database access denied")
    _PEE_PATTERNS+=("P1011|Error opening a TLS connection|tls_error|_pee_tmpl_p1011|8|TLS connection error")
    _PEE_PATTERNS+=("P1017|Server has closed the connection|connection_closed|_pee_tmpl_p1017|7|Server closed connection")

    # --- Query Errors (P2xxx) ---
    _PEE_PATTERNS+=("P2002|Unique constraint failed|unique_constraint|_pee_tmpl_p2002|8|Unique constraint violation")
    _PEE_PATTERNS+=("P2003|Foreign key constraint failed|foreign_key|_pee_tmpl_p2003|8|Foreign key constraint failure")
    _PEE_PATTERNS+=("P2014|The change you are trying to make would violate the required relation|required_relation|_pee_tmpl_p2014|7|Required relation violation")
    _PEE_PATTERNS+=("P2025|not found|record_not_found|_pee_tmpl_p2025|6|Record not found")
    _PEE_PATTERNS+=("P2000|value .* out of range|value_out_of_range|_pee_tmpl_p2000|5|Value out of range")
    _PEE_PATTERNS+=("P2001|record .* does not exist|record_missing|_pee_tmpl_p2001|6|Referenced record missing")
    _PEE_PATTERNS+=("P2005|value .* stored in the database .* is invalid|invalid_stored_value|_pee_tmpl_p2005|7|Invalid stored value")
    _PEE_PATTERNS+=("P2011|Null constraint violation|null_constraint|_pee_tmpl_p2011|7|Null constraint violation")
    _PEE_PATTERNS+=("P2015|related record could not be found|related_not_found|_pee_tmpl_p2015|6|Related record not found")
    _PEE_PATTERNS+=("P2021|table .* does not exist|table_not_found|_pee_tmpl_p2021|9|Table does not exist")
    _PEE_PATTERNS+=("P2022|column .* does not exist|column_not_found|_pee_tmpl_p2022|8|Column does not exist")

    # --- Migration Errors (P3xxx) ---
    _PEE_PATTERNS+=("P3000|Failed to create database|create_db_failed|_pee_tmpl_p3000|9|Failed to create database")
    _PEE_PATTERNS+=("P3005|database schema is not empty|schema_not_empty|_pee_tmpl_p3005|7|Database schema not empty")
    _PEE_PATTERNS+=("P3006|Migration .* failed to apply|migration_failed|_pee_tmpl_p3006|9|Migration failed to apply")
    _PEE_PATTERNS+=("P3009|migrate found failed migrations|found_failed|_pee_tmpl_p3009|8|Found failed migrations")

    # --- Schema Validation & Client Generation ---
    _PEE_PATTERNS+=("SCHEMA|Error validating|schema_validation|_pee_tmpl_schema_validation|8|Schema validation error")
    _PEE_PATTERNS+=("CLIENT|PrismaClientInitializationError|client_init|_pee_tmpl_client_init|9|Client initialization error")
    _PEE_PATTERNS+=("CLIENT|PrismaClientValidationError|client_validation|_pee_tmpl_client_validation|8|Client validation error")
    _PEE_PATTERNS+=("CLIENT|PrismaClientKnownRequestError|client_request|_pee_tmpl_client_request|7|Client request error")
    _PEE_PATTERNS+=("GENERATE|prisma generate|client_generation|_pee_tmpl_client_generation|7|Client generation error")
    _PEE_PATTERNS+=("RELATION|ambiguous.*relation|ambiguous_relation|_pee_tmpl_ambiguous_relation|7|Ambiguous relation")
    _PEE_PATTERNS+=("RELATION|missing.*@relation|missing_relation|_pee_tmpl_missing_relation|8|Missing @relation directive")
}

# =============================================================================
# Fix Template Functions
# =============================================================================

_pee_tmpl_p1001() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P1001: Database Server Unreachable** (${file})
The Prisma client cannot connect to the database server.

Checklist:
1. **Check DATABASE_URL** in \`.env\`:
   - PostgreSQL: \`postgresql://user:password@host:5432/dbname\`
   - MySQL: \`mysql://user:password@host:3306/dbname\`
   - SQLite: \`file:./dev.db\`
2. **Verify database is running**:
   - PostgreSQL: \`pg_isready -h localhost -p 5432\`
   - MySQL: \`mysqladmin ping -h localhost\`
   - Docker: \`docker ps | grep postgres\`
3. **Check firewall/network**: Ensure the port is accessible
4. **Docker compose**: Run \`docker compose up -d db\`
5. **Connection pooling**: If using PgBouncer/Supabase, add \`?pgbouncer=true\` to URL
6. **SSL**: If required, add \`?sslmode=require\` to DATABASE_URL
FIX
}

_pee_tmpl_p1002() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P1002: Connection Timeout** (${file})
1. Increase connection timeout: \`?connect_timeout=30\` in DATABASE_URL
2. Check network latency to database server
3. Verify connection pool is not exhausted
4. Add \`connection_limit=5\` for serverless environments
FIX
}

_pee_tmpl_p1003() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P1003: Database Not Found** (${file})
1. Create the database: \`npx prisma db push\` or \`CREATE DATABASE dbname;\`
2. For SQLite: ensure directory exists for the .db file
3. Verify DATABASE_URL has the correct database name
FIX
}

_pee_tmpl_p1008() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P1008: Operation Timeout** (${file})
1. Increase pool timeout: add \`pool_timeout=30\` to DATABASE_URL
2. Optimize slow queries (add indexes)
3. Use \`\$transaction\` with timeout: \`prisma.\$transaction([...], { timeout: 30000 })\`
FIX
}

_pee_tmpl_p1009() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P1009: Database Already Exists** (${file})
Use \`npx prisma migrate deploy\` instead of \`npx prisma migrate dev\` in production.
Or drop and recreate: \`npx prisma migrate reset\` (dev only, destroys data).
FIX
}

_pee_tmpl_p1010() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P1010: Access Denied** (${file})
1. Verify username and password in DATABASE_URL
2. Grant permissions: \`GRANT ALL PRIVILEGES ON dbname.* TO 'user'@'host';\`
3. Check the database user has CREATE/ALTER permissions for migrations
FIX
}

_pee_tmpl_p1011() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P1011: TLS Error** (${file})
1. Add \`?sslmode=require\` or \`?sslmode=prefer\` to DATABASE_URL
2. For self-signed certs: \`?sslmode=no-verify\` (dev only)
3. Provide CA cert: \`?sslcert=/path/to/cert\`
FIX
}

_pee_tmpl_p1017() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P1017: Server Closed Connection** (${file})
1. Implement connection retry logic in your application
2. Check database server logs for OOM/crash
3. Use connection pooling (PgBouncer)
4. Add \`?connection_limit=5\` for serverless
FIX
}

_pee_tmpl_p2002() {
    local msg="$1" file="$2"
    local field
    field=$(echo "$msg" | grep -oP 'fields: \(\K[^)]+' | head -1)
    [[ -z "$field" ]] && field=$(echo "$msg" | grep -oE 'constraint on.*\(([^)]+)\)' | grep -oE '\([^)]+\)' | tr -d '()' | head -1)
    cat <<FIX
**Fix for P2002: Unique Constraint Violation** (${file})
Field(s): \`${field}\`

Solutions:
1. **Use upsert** instead of create:
   \`\`\`typescript
   await prisma.model.upsert({
     where: { ${field}: value },
     update: { /* fields to update */ },
     create: { /* fields to create */ },
   });
   \`\`\`
2. **Check before inserting**:
   \`\`\`typescript
   const existing = await prisma.model.findUnique({ where: { ${field}: value } });
   if (!existing) { await prisma.model.create({ data }); }
   \`\`\`
3. **Handle the error**:
   \`\`\`typescript
   try { await prisma.model.create({ data }); }
   catch (e) { if (e.code === 'P2002') { /* handle duplicate */ } }
   \`\`\`
4. **Remove duplicate data** from seed or migration
5. **Review the unique constraint** - should it be a compound unique?
FIX
}

_pee_tmpl_p2003() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P2003: Foreign Key Constraint** (${file})
A referenced record does not exist.

Solutions:
1. Create the referenced record first, then create the dependent
2. Use \`connect\` instead of providing a raw ID:
   \`\`\`typescript
   await prisma.post.create({
     data: { author: { connect: { id: authorId } } }
   });
   \`\`\`
3. Make the relation optional if it's not always needed
4. Check cascade delete settings in schema.prisma
5. Ensure seed data creates parent records before children
FIX
}

_pee_tmpl_p2014() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P2014: Required Relation Violation** (${file})
Cannot delete/disconnect because a required relation would be broken.

Solutions:
1. Add cascade delete: \`@relation(onDelete: Cascade)\`
2. Delete dependent records first
3. Make the relation optional if appropriate
4. Use \`prisma.\$transaction\` for atomic deletion of related records
FIX
}

_pee_tmpl_p2025() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P2025: Record Not Found** (${file})
An operation expected a record that doesn't exist.

Solutions:
1. Use \`findUnique\` with null check instead of update/delete directly
2. Use \`updateMany\`/\`deleteMany\` which don't throw on missing records
3. Use \`upsert\` for create-or-update semantics
4. Add proper error handling:
   \`\`\`typescript
   const record = await prisma.model.findUnique({ where: { id } });
   if (!record) { return res.status(404).json({ error: 'Not found' }); }
   \`\`\`
FIX
}

_pee_tmpl_p2000() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P2000: Value Out of Range** (${file})
1. Check column type size (Int vs BigInt, Char length, etc.)
2. Add application-level validation before Prisma queries
3. Use appropriate Prisma scalar types (BigInt, Decimal, etc.)
FIX
}

_pee_tmpl_p2001() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P2001: Referenced Record Missing** (${file})
Ensure the WHERE clause references an existing record.
Check IDs are valid and the record hasn't been deleted.
FIX
}

_pee_tmpl_p2005() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P2005: Invalid Stored Value** (${file})
The database contains a value that doesn't match the Prisma schema type.
1. Check the database directly for corrupted data
2. Run \`npx prisma db pull\` to sync schema with actual DB
3. Create a migration to fix the column type
FIX
}

_pee_tmpl_p2011() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P2011: Null Constraint Violation** (${file})
A required field received null.

Solutions:
1. Provide a value for the required field in the create/update
2. Add a default value in schema: \`field String @default("default")\`
3. Make the field optional: \`field String?\`
FIX
}

_pee_tmpl_p2015() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P2015: Related Record Not Found** (${file})
A nested connect/disconnect operation references a non-existent record.
Verify the related record ID is correct and exists in the database.
FIX
}

_pee_tmpl_p2021() {
    local msg="$1" file="$2"
    local table
    table=$(echo "$msg" | grep -oP "table \`?\K[^\`]+(?=\`?)" | head -1)
    cat <<FIX
**Fix for P2021: Table Not Found** (${file})
Table \`${table}\` does not exist in the database.

Solutions:
1. Run migrations: \`npx prisma migrate dev\`
2. Push schema: \`npx prisma db push\`
3. Verify the table name matches schema.prisma (case-sensitive)
4. Check if the migration creating this table was applied: \`npx prisma migrate status\`
FIX
}

_pee_tmpl_p2022() {
    local msg="$1" file="$2"
    local column
    column=$(echo "$msg" | grep -oP "column \`?\K[^\`]+(?=\`?)" | head -1)
    cat <<FIX
**Fix for P2022: Column Not Found** (${file})
Column \`${column}\` does not exist.

Solutions:
1. Run \`npx prisma migrate dev\` to apply pending migrations
2. Check if the field is correctly named in schema.prisma
3. Use \`@map("db_column_name")\` if the DB column differs from the field name
4. Run \`npx prisma db pull\` to sync schema with the actual database
FIX
}

_pee_tmpl_p3000() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P3000: Failed to Create Database** (${file})
1. Verify database user has CREATE DATABASE permission
2. Check DATABASE_URL format is correct
3. For PostgreSQL: connect as superuser first
4. For SQLite: ensure parent directory is writable
FIX
}

_pee_tmpl_p3005() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P3005: Schema Not Empty** (${file})
Database already has tables when trying to baseline.

Solutions:
1. Use \`npx prisma migrate dev\` (dev: recreates DB)
2. Use \`npx prisma migrate resolve --applied "migration_name"\` to mark as applied
3. Use \`npx prisma db push --accept-data-loss\` to force sync
4. Baseline: \`npx prisma migrate resolve --applied "0_init"\`
FIX
}

_pee_tmpl_p3006() {
    local msg="$1" file="$2"
    local migration
    migration=$(echo "$msg" | grep -oP "Migration \`?\K[^\`]+(?=\`?)" | head -1)
    cat <<FIX
**Fix for P3006: Migration Failed** (${file})
Migration \`${migration}\` failed to apply.

Solutions:
1. **Check the SQL** in \`prisma/migrations/${migration}/migration.sql\`
2. **Fix the SQL** and retry: \`npx prisma migrate deploy\`
3. **Mark as rolled back**: \`npx prisma migrate resolve --rolled-back "${migration}"\`
4. **Reset (dev only)**: \`npx prisma migrate reset\` (destroys all data)
5. **Manual fix**: Apply SQL manually, then mark as applied:
   \`npx prisma migrate resolve --applied "${migration}"\`
FIX
}

_pee_tmpl_p3009() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for P3009: Found Failed Migrations** (${file})
Previous migrations have failed and need to be addressed.

Solutions:
1. List migration status: \`npx prisma migrate status\`
2. Fix and re-apply: \`npx prisma migrate deploy\`
3. Mark as rolled back: \`npx prisma migrate resolve --rolled-back "migration_name"\`
4. Reset (dev only): \`npx prisma migrate reset\`
FIX
}

_pee_tmpl_schema_validation() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Schema Validation Error** (${file})
The schema.prisma file has validation errors.

Common Issues:
1. **Missing @id**: Every model needs \`@id\` on a field or \`@@id([fields])\`
2. **Invalid relation**: Both sides of a relation must reference each other
3. **Unknown type**: Use valid Prisma types (String, Int, Float, Boolean, DateTime, etc.)
4. **Missing @relation**: Ambiguous relations need explicit \`@relation(name)\`
5. **Invalid default**: \`@default()\` value must match the field type
6. **Unsupported features**: Check provider compatibility

Run \`npx prisma validate\` for detailed error output.
Run \`npx prisma format\` to auto-format the schema.
FIX
}

_pee_tmpl_client_init() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for PrismaClientInitializationError** (${file})
The Prisma client failed to initialize.

Solutions:
1. **Regenerate client**: \`npx prisma generate\`
2. **Check DATABASE_URL**: Verify it's set correctly
3. **Engine mismatch**: Delete \`node_modules/.prisma\` and regenerate
4. **Platform mismatch**: Add \`binaryTargets\` to schema generator:
   \`\`\`prisma
   generator client {
     provider = "prisma-client-js"
     binaryTargets = ["native", "linux-musl-openssl-3.0.x"]
   }
   \`\`\`
5. **Singleton pattern**: Use a single PrismaClient instance:
   \`\`\`typescript
   const globalForPrisma = globalThis as unknown as { prisma: PrismaClient };
   export const prisma = globalForPrisma.prisma ?? new PrismaClient();
   if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma;
   \`\`\`
FIX
}

_pee_tmpl_client_validation() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for PrismaClientValidationError** (${file})
The query arguments don't match the schema.

Solutions:
1. **Regenerate client**: \`npx prisma generate\` to sync types
2. **Check field names**: Ensure they match schema.prisma exactly
3. **Check field types**: Prisma enforces strict type matching
4. **Check relations**: Use \`connect\`, \`create\`, \`connectOrCreate\` properly
5. **Check select/include**: Only select fields that exist on the model
FIX
}

_pee_tmpl_client_request() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for PrismaClientKnownRequestError** (${file})
A known error occurred during a Prisma query.

Handle by error code:
\`\`\`typescript
import { Prisma } from '@prisma/client';
try { await prisma.model.create({ data }); }
catch (e) {
  if (e instanceof Prisma.PrismaClientKnownRequestError) {
    switch (e.code) {
      case 'P2002': /* unique constraint */ break;
      case 'P2025': /* not found */ break;
      default: throw e;
    }
  }
}
\`\`\`
FIX
}

_pee_tmpl_client_generation() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Client Generation Error** (${file})
\`prisma generate\` failed.

Solutions:
1. Fix schema.prisma syntax errors: \`npx prisma validate\`
2. Delete and regenerate: \`rm -rf node_modules/.prisma && npx prisma generate\`
3. Check generator block in schema.prisma
4. Ensure @prisma/client is installed: \`npm install @prisma/client\`
5. Check Node.js version compatibility
FIX
}

_pee_tmpl_ambiguous_relation() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Ambiguous Relation** (${file})
Multiple relations between two models need explicit names.

Fix: Add \`@relation("name")\` to both sides:
\`\`\`prisma
model User {
  writtenPosts Post[] @relation("WrittenPosts")
  likedPosts   Post[] @relation("LikedPosts")
}
model Post {
  author  User @relation("WrittenPosts", fields: [authorId], references: [id])
  likedBy User @relation("LikedPosts", fields: [likedById], references: [id])
  authorId   String
  likedById  String
}
\`\`\`
FIX
}

_pee_tmpl_missing_relation() {
    local msg="$1" file="$2"
    cat <<FIX
**Fix for Missing @relation** (${file})
A foreign key field needs a \`@relation\` directive.

Add the \`@relation\` with \`fields\` and \`references\`:
\`\`\`prisma
model Post {
  authorId String
  author   User @relation(fields: [authorId], references: [id])
}
\`\`\`
Both sides of the relation must be defined.
FIX
}

# =============================================================================
# _pee_init - Initialize module
# =============================================================================
_pee_init() {
    [[ "$PEE_ENABLED" != "true" ]] && return 0

    PEE_STORE_DIR="${HOME}/.soloptilink/prisma-errors"
    mkdir -p "$PEE_STORE_DIR" 2>/dev/null || true
    PEE_HISTORY_FILE="${PEE_STORE_DIR}/fix_history.jsonl"

    PEE_TOTAL_ANALYZED=0
    PEE_TOTAL_FIXED=0
    PEE_TOTAL_PROMPTS=0
    PEE_FIX_SUCCESS=0
    PEE_FIX_FAIL=0
    PEE_MIGRATIONS_FIXED=0
    PEE_RELATIONS_FIXED=0
    PEE_CONSTRAINTS_FIXED=0
    PEE_SCHEMA_FIXED=0
    PEE_CLIENT_FIXED=0
    PEE_CONNECTION_FIXED=0

    _PEE_ERROR_MSGS=()
    _PEE_ERROR_FILES=()
    _PEE_ERROR_CODES=()
    _PEE_ERROR_CATEGORIES=()

    _pee_init_patterns

    PEE_INITIALIZED=true
    echo -e "  ${_PEE_GREEN}[PEE]${_PEE_NC} Prisma Error Expert v${PEE_VERSION} initialized (${#_PEE_PATTERNS[@]} patterns)" >&2
    return 0
}

# =============================================================================
# _pee_classify - Classify a Prisma error
# Returns: "prisma_code|category|severity|pattern_index"
# =============================================================================
_pee_classify() {
    local error_msg="${1:-}"
    [[ -z "$error_msg" ]] && echo "unknown|unknown|0|-1" && return 0

    local i=0
    for pattern_def in "${_PEE_PATTERNS[@]}"; do
        local IFS='|'
        local parts=($pattern_def)
        unset IFS

        local prisma_code="${parts[0]}"
        local regex="${parts[1]}"
        local category="${parts[2]}"
        local severity="${parts[4]}"

        # Match by regex
        if echo "$error_msg" | grep -qiE "$regex" 2>/dev/null; then
            echo "${prisma_code}|${category}|${severity}|${i}"
            return 0
        fi

        # Match by Prisma error code
        if echo "$error_msg" | grep -q "$prisma_code" 2>/dev/null; then
            echo "${prisma_code}|${category}|${severity}|${i}"
            return 0
        fi

        i=$((i + 1))
    done

    echo "unknown|unknown|3|-1"
}

# =============================================================================
# _pee_fix_migration - Fix Prisma migration errors
# =============================================================================
_pee_fix_migration() {
    local error_msg="${1:-}"
    local file="${2:-schema.prisma}"
    local project_dir="${3:-.}"

    PEE_TOTAL_ANALYZED=$((PEE_TOTAL_ANALYZED + 1))
    echo -e "  ${_PEE_CYAN}[PEE]${_PEE_NC} Fixing migration error: ${error_msg:0:80}" >&2

    local classification
    classification=$(_pee_classify "$error_msg")
    local code category
    code=$(echo "$classification" | cut -d'|' -f1)
    category=$(echo "$classification" | cut -d'|' -f2)

    case "$code" in
        P3005) _pee_tmpl_p3005 "$error_msg" "$file" ;;
        P3006) _pee_tmpl_p3006 "$error_msg" "$file" ;;
        P3009) _pee_tmpl_p3009 "$error_msg" "$file" ;;
        P3000) _pee_tmpl_p3000 "$error_msg" "$file" ;;
        *)
            cat <<FIX
**Fix for Migration Error** (${file})
1. Check migration status: \`npx prisma migrate status\`
2. Review pending migrations in \`prisma/migrations/\`
3. Reset if needed (dev): \`npx prisma migrate reset\`
4. Apply migrations: \`npx prisma migrate deploy\`
FIX
            ;;
    esac

    PEE_TOTAL_FIXED=$((PEE_TOTAL_FIXED + 1))
    PEE_MIGRATIONS_FIXED=$((PEE_MIGRATIONS_FIXED + 1))
}

# =============================================================================
# _pee_fix_relation - Fix relation errors
# =============================================================================
_pee_fix_relation() {
    local error_msg="${1:-}"
    local file="${2:-schema.prisma}"

    PEE_TOTAL_ANALYZED=$((PEE_TOTAL_ANALYZED + 1))
    echo -e "  ${_PEE_CYAN}[PEE]${_PEE_NC} Fixing relation error: ${error_msg:0:80}" >&2

    if echo "$error_msg" | grep -qi "ambiguous" 2>/dev/null; then
        _pee_tmpl_ambiguous_relation "$error_msg" "$file"
    elif echo "$error_msg" | grep -qi "@relation" 2>/dev/null; then
        _pee_tmpl_missing_relation "$error_msg" "$file"
    elif echo "$error_msg" | grep -q "P2003" 2>/dev/null; then
        _pee_tmpl_p2003 "$error_msg" "$file"
    elif echo "$error_msg" | grep -q "P2014" 2>/dev/null; then
        _pee_tmpl_p2014 "$error_msg" "$file"
    else
        _pee_tmpl_missing_relation "$error_msg" "$file"
    fi

    PEE_TOTAL_FIXED=$((PEE_TOTAL_FIXED + 1))
    PEE_RELATIONS_FIXED=$((PEE_RELATIONS_FIXED + 1))
}

# =============================================================================
# _pee_fix_unique_constraint - Fix unique constraint violations
# =============================================================================
_pee_fix_unique_constraint() {
    local error_msg="${1:-}"
    local file="${2:-}"

    PEE_TOTAL_ANALYZED=$((PEE_TOTAL_ANALYZED + 1))
    echo -e "  ${_PEE_CYAN}[PEE]${_PEE_NC} Fixing unique constraint: ${error_msg:0:80}" >&2

    _pee_tmpl_p2002 "$error_msg" "$file"

    PEE_TOTAL_FIXED=$((PEE_TOTAL_FIXED + 1))
    PEE_CONSTRAINTS_FIXED=$((PEE_CONSTRAINTS_FIXED + 1))
}

# =============================================================================
# _pee_fix_schema_validation - Fix schema.prisma validation errors
# =============================================================================
_pee_fix_schema_validation() {
    local error_msg="${1:-}"
    local file="${2:-prisma/schema.prisma}"

    PEE_TOTAL_ANALYZED=$((PEE_TOTAL_ANALYZED + 1))
    echo -e "  ${_PEE_CYAN}[PEE]${_PEE_NC} Fixing schema validation: ${error_msg:0:80}" >&2

    _pee_tmpl_schema_validation "$error_msg" "$file"

    PEE_TOTAL_FIXED=$((PEE_TOTAL_FIXED + 1))
    PEE_SCHEMA_FIXED=$((PEE_SCHEMA_FIXED + 1))
}

# =============================================================================
# _pee_fix_client_generation - Fix Prisma client generation errors
# =============================================================================
_pee_fix_client_generation() {
    local error_msg="${1:-}"
    local file="${2:-}"

    PEE_TOTAL_ANALYZED=$((PEE_TOTAL_ANALYZED + 1))
    echo -e "  ${_PEE_CYAN}[PEE]${_PEE_NC} Fixing client generation: ${error_msg:0:80}" >&2

    if echo "$error_msg" | grep -qi "InitializationError" 2>/dev/null; then
        _pee_tmpl_client_init "$error_msg" "$file"
    elif echo "$error_msg" | grep -qi "ValidationError" 2>/dev/null; then
        _pee_tmpl_client_validation "$error_msg" "$file"
    else
        _pee_tmpl_client_generation "$error_msg" "$file"
    fi

    PEE_TOTAL_FIXED=$((PEE_TOTAL_FIXED + 1))
    PEE_CLIENT_FIXED=$((PEE_CLIENT_FIXED + 1))
}

# =============================================================================
# _pee_fix_connection - Fix database connection errors
# =============================================================================
_pee_fix_connection() {
    local error_msg="${1:-}"
    local file="${2:-}"

    PEE_TOTAL_ANALYZED=$((PEE_TOTAL_ANALYZED + 1))
    echo -e "  ${_PEE_CYAN}[PEE]${_PEE_NC} Fixing connection error: ${error_msg:0:80}" >&2

    local classification
    classification=$(_pee_classify "$error_msg")
    local code
    code=$(echo "$classification" | cut -d'|' -f1)

    case "$code" in
        P1001) _pee_tmpl_p1001 "$error_msg" "$file" ;;
        P1002) _pee_tmpl_p1002 "$error_msg" "$file" ;;
        P1010) _pee_tmpl_p1010 "$error_msg" "$file" ;;
        P1011) _pee_tmpl_p1011 "$error_msg" "$file" ;;
        P1017) _pee_tmpl_p1017 "$error_msg" "$file" ;;
        *)     _pee_tmpl_p1001 "$error_msg" "$file" ;;
    esac

    PEE_TOTAL_FIXED=$((PEE_TOTAL_FIXED + 1))
    PEE_CONNECTION_FIXED=$((PEE_CONNECTION_FIXED + 1))
}

# =============================================================================
# _pee_get_fix_prompt - Generate Claude prompt with Prisma-specific context
# =============================================================================
_pee_get_fix_prompt() {
    local error_msg="${1:-}"
    local file="${2:-}"
    local schema_content="${3:-}"
    local query_code="${4:-}"

    PEE_TOTAL_PROMPTS=$((PEE_TOTAL_PROMPTS + 1))

    local classification
    classification=$(_pee_classify "$error_msg")
    local prisma_code category severity pattern_idx
    prisma_code=$(echo "$classification" | cut -d'|' -f1)
    category=$(echo "$classification" | cut -d'|' -f2)
    severity=$(echo "$classification" | cut -d'|' -f3)
    pattern_idx=$(echo "$classification" | cut -d'|' -f4)

    # Get fix template
    local fix_guidance=""
    if [[ "$pattern_idx" -ge 0 ]] && [[ "$pattern_idx" -lt ${#_PEE_PATTERNS[@]} ]]; then
        local pattern_def="${_PEE_PATTERNS[$pattern_idx]}"
        local IFS='|'
        local parts=($pattern_def)
        unset IFS
        local fix_fn="${parts[3]}"
        if type -t "$fix_fn" &>/dev/null; then
            fix_guidance=$($fix_fn "$error_msg" "$file")
        fi
    fi

    cat <<PROMPT
## Prisma Error Fix Request

### Error Details
- **Prisma Code**: ${prisma_code}
- **Category**: ${category}
- **Severity**: ${severity}/10
- **File**: ${file}
- **Message**: ${error_msg}

### Expert Fix Guidance
${fix_guidance}

### Schema Context
\`\`\`prisma
${schema_content}
\`\`\`

### Query Code
\`\`\`typescript
${query_code}
\`\`\`

### Instructions
1. Fix the Prisma error described above
2. If schema change needed: update schema.prisma and run \`npx prisma generate\`
3. If migration needed: describe the migration steps
4. Ensure Prisma best practices: use transactions for multi-step operations
5. Add proper error handling with Prisma error codes
6. After fix: \`npx prisma validate && npx prisma generate\`
PROMPT
}

# =============================================================================
# _pee_analyze_batch - Analyze batch of Prisma errors from output
# =============================================================================
_pee_analyze_batch() {
    local output="${1:-}"
    [[ -z "$output" ]] && return 0

    local count=0
    while IFS= read -r line; do
        if echo "$line" | grep -qE "P[0-9]{4}|PrismaClient|prisma.*error|schema.*validation" 2>/dev/null; then
            local classification
            classification=$(_pee_classify "$line")
            local code category
            code=$(echo "$classification" | cut -d'|' -f1)
            category=$(echo "$classification" | cut -d'|' -f2)

            _PEE_ERROR_MSGS+=("$line")
            _PEE_ERROR_CODES+=("$code")
            _PEE_ERROR_CATEGORIES+=("$category")
            count=$((count + 1))
        fi
    done <<< "$output"

    PEE_TOTAL_ANALYZED=$((PEE_TOTAL_ANALYZED + count))
    echo -e "  ${_PEE_BLUE}[PEE]${_PEE_NC} Analyzed ${count} Prisma errors" >&2
    echo "$count"
}

# =============================================================================
# _pee_log_fix - Log a fix to history
# =============================================================================
_pee_log_fix() {
    local code="$1" category="$2" success="$3"
    [[ -z "$PEE_HISTORY_FILE" ]] && return 0

    local timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    echo "{\"timestamp\":\"${timestamp}\",\"code\":\"${code}\",\"category\":\"${category}\",\"success\":${success}}" >> "$PEE_HISTORY_FILE" 2>/dev/null || true

    if [[ "$success" == "true" ]]; then
        PEE_FIX_SUCCESS=$((PEE_FIX_SUCCESS + 1))
    else
        PEE_FIX_FAIL=$((PEE_FIX_FAIL + 1))
    fi
}

# =============================================================================
# _pee_report - Report output
# =============================================================================
_pee_report() {
    echo -e "\n  ${_PEE_BOLD}=== Prisma Error Expert v${PEE_VERSION} Report ===${_PEE_NC}"
    echo -e "  Patterns loaded      : ${#_PEE_PATTERNS[@]}"
    echo -e "  Errors analyzed      : ${PEE_TOTAL_ANALYZED}"
    echo -e "  Fixes generated      : ${PEE_TOTAL_FIXED}"
    echo -e "  Fix prompts          : ${PEE_TOTAL_PROMPTS}"
    echo -e "  Fix success          : ${PEE_FIX_SUCCESS}"
    echo -e "  Fix failures         : ${PEE_FIX_FAIL}"
    echo -e "  ${_PEE_BOLD}By Category:${_PEE_NC}"
    echo -e "    Migrations         : ${PEE_MIGRATIONS_FIXED}"
    echo -e "    Relations          : ${PEE_RELATIONS_FIXED}"
    echo -e "    Constraints        : ${PEE_CONSTRAINTS_FIXED}"
    echo -e "    Schema             : ${PEE_SCHEMA_FIXED}"
    echo -e "    Client             : ${PEE_CLIENT_FIXED}"
    echo -e "    Connection         : ${PEE_CONNECTION_FIXED}"
}

# =============================================================================
# _pee_score - Module score (0-100)
# =============================================================================
_pee_score() {
    local score=50
    [[ ${#_PEE_PATTERNS[@]} -ge 20 ]] && score=$((score + 10))
    [[ $PEE_TOTAL_ANALYZED -gt 0 ]] && score=$((score + 10))
    [[ $PEE_TOTAL_FIXED -gt 0 ]] && score=$((score + 10))
    if [[ $((PEE_FIX_SUCCESS + PEE_FIX_FAIL)) -gt 0 ]]; then
        local rate=$((PEE_FIX_SUCCESS * 100 / (PEE_FIX_SUCCESS + PEE_FIX_FAIL)))
        [[ $rate -ge 70 ]] && score=$((score + 20))
    fi
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# _pee_init_message
# =============================================================================
_pee_init_message() {
    echo -e "  ${_PEE_GREEN}v${PEE_VERSION}${_PEE_NC} Prisma Error Expert: ${#_PEE_PATTERNS[@]} error patterns, migration/relation/constraint fix" >&2
}

# =============================================================================
# Module Registry Registration
# =============================================================================
_mr_register \
    --name "prisma-error-expert" \
    --version "${PEE_VERSION}" \
    --description "Prisma専門エラー解析・修正（25+パターン、migration/relation/constraint対応）" \
    --init "_pee_init" \
    --report "_pee_report" \
    --score "_pee_score" \
    --enable-var "PEE_ENABLED" \
    --cli-flags "--prisma-error-expert:--no-prisma-error-expert" \
    --init-msg "_pee_init_message"
