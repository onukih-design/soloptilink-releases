#!/usr/bin/env bash
# ============================================================
# SoloptiLink Chain v11.0 - DAG Dynamic Pipeline Engine
# ============================================================
# v7.0の静的パイプライン（Quick/Standard/Deep/Hotfix）を拡張し、
# タスク分析に基づいてDAG（有向非巡回グラフ）を動的に構築。
# 依存関係を解析し、並列実行可能なステージを自動判定する。
#
# v11.0 新機能:
#   - dag_replan()         : 失敗ノード発生時のDAG動的リプランニング
#   - コスト見積もり         : 各ノードの推定Claude APIコスト追跡
#   - dag_critical_path()  : 最長実行パス（クリティカルパス）分析
#   - dag_timeline()       : ASCII Ganttチャート風タイムライン表示
#   - dag_smart_preset()   : キーワード分析による最適プリセット自動選択
#   - 循環依存バリデーション : 実行前に循環依存を検出して拒否
# ============================================================

[[ -n "${_DAG_PIPELINE_LOADED:-}" ]] && return 0
_DAG_PIPELINE_LOADED=1

# sourceされるライブラリなので set -euo pipefail は設定しない
# カラー定義（readonlyガード付き：他モジュールとの衝突を防止）
[[ -z "${RED:-}" ]]    && RED='\033[0;31m'
[[ -z "${GREEN:-}" ]]  && GREEN='\033[0;32m'
[[ -z "${YELLOW:-}" ]] && YELLOW='\033[0;33m'
[[ -z "${BLUE:-}" ]]   && BLUE='\033[0;34m'
[[ -z "${PURPLE:-}" ]] && PURPLE='\033[0;35m'
[[ -z "${CYAN:-}" ]]   && CYAN='\033[0;36m'
[[ -z "${BOLD:-}" ]]   && BOLD='\033[1m'
[[ -z "${NC:-}" ]]     && NC='\033[0m'

# DAG設定
DAG_DIR="${HOME}/.soloptilink/dag"
DAG_LOG_DIR="docs/chain-logs/dag"
mkdir -p "${DAG_DIR}" "${DAG_LOG_DIR}" 2>/dev/null || true

# ============================================================
# DAGノード定義
# ============================================================
# 各ノードはパイプラインの1ステージを表す
# フォーマット: ノードID|名前|推定時間(分)|依存ノードIDs(カンマ区切り)|実行コマンド

declare -gA DAG_NODES=()
declare -gA DAG_STATUS=()     # pending / running / completed / failed / skipped
declare -gA DAG_RESULTS=()    # 各ノードの実行結果
declare -gA DAG_START_TIME=()
declare -gA DAG_END_TIME=()
declare -ga DAG_UNDEFINED_NODES=()  # REQ-WIRE-001: 未定義cmdで縮退スキップしたノード (false-success可視化)

# v11.0: コスト見積もりトラッキング
declare -gA DAG_COST_ESTIMATE=()   # ノードごとの推定コスト（USD）
declare -gA DAG_COST_ACTUAL=()     # ノードごとの実コスト（USD）
DAG_COST_PER_MINUTE=0.05          # デフォルト: Claude API $0.05/min
DAG_COST_TOTAL_BUDGET=10.00       # セッションコスト上限

# 連想配列の安全なリセット（set -u 対策）
_dag_reset_arrays() {
    unset DAG_NODES DAG_STATUS DAG_COST_ESTIMATE DAG_COST_ACTUAL DAG_RESULTS DAG_START_TIME DAG_END_TIME 2>/dev/null || true
    declare -gA DAG_NODES=()
    declare -gA DAG_STATUS=()
    declare -gA DAG_COST_ESTIMATE=()
    declare -gA DAG_COST_ACTUAL=()
    declare -gA DAG_RESULTS=()
    declare -gA DAG_START_TIME=()
    declare -gA DAG_END_TIME=()
}

# ============================================================
# タスク分析 → DAG構築
# ============================================================
dag_analyze_task() {
    local task_desc="$1"
    local complexity="${2:-standard}"

    echo -e "${BOLD}${PURPLE}[DAG] タスク分析中...${NC}"

    # タスクタイプの判定
    local task_type="generic"
    local has_frontend=false
    local has_backend=false
    local has_db=false
    local has_api=false
    local has_test=false
    local has_deploy=false
    local has_docs=false

    # キーワードベースのタスク分析
    local task_lower=$(echo "$task_desc" | tr '[:upper:]' '[:lower:]')

    [[ "$task_lower" =~ (react|vue|next|html|css|ui|画面|フロント|ランディング|lp) ]] && has_frontend=true
    [[ "$task_lower" =~ (api|backend|サーバ|express|fastapi|node|バック) ]] && has_backend=true
    [[ "$task_lower" =~ (db|database|sql|postgres|mongo|データベース|テーブル) ]] && has_db=true
    [[ "$task_lower" =~ (api|rest|graphql|endpoint|エンドポイント) ]] && has_api=true
    [[ "$task_lower" =~ (test|テスト|spec|jest|pytest) ]] && has_test=true
    [[ "$task_lower" =~ (deploy|デプロイ|vercel|aws|本番) ]] && has_deploy=true
    [[ "$task_lower" =~ (doc|readme|ドキュメント|仕様) ]] && has_docs=true

    # SaaS / フルスタック判定
    if [[ "$task_lower" =~ (saas|crm|sfa|管理システム|ツール作|ecommerce|ec|ショッピング|家計簿|チャット|sns) ]]; then
        task_type="fullstack"
        has_frontend=true
        has_backend=true
        has_db=true
        has_api=true
    elif [[ "$task_lower" =~ (lp|ランディング|ページ) ]]; then
        task_type="landing_page"
        has_frontend=true
    elif [[ "$task_lower" =~ (script|スクリプト|自動化|バッチ) ]]; then
        task_type="script"
    fi

    echo -e "  タスクタイプ: ${CYAN}${task_type}${NC}"
    echo -e "  フロントエンド: $(bool_icon $has_frontend) | バックエンド: $(bool_icon $has_backend)"
    echo -e "  DB: $(bool_icon $has_db) | API: $(bool_icon $has_api) | テスト: $(bool_icon $has_test)"

    # DAGノードを構築
    _build_dag "$task_type" "$complexity" \
        "$has_frontend" "$has_backend" "$has_db" "$has_api" "$has_test" "$has_deploy" "$has_docs"

    # v11.0: コスト見積もりを計算
    _dag_estimate_costs

    # v11.0: 循環依存のバリデーション
    if ! dag_validate_dependencies; then
        echo -e "  ${RED}[DAG] 循環依存を検出しました。DAGを再構築してください。${NC}"
        return 1
    fi
}

bool_icon() {
    [[ "$1" == "true" ]] && echo -e "${GREEN}✓${NC}" || echo -e "${YELLOW}–${NC}"
}

# ============================================================
# DAG構築ロジック
# ============================================================
_build_dag() {
    local task_type="$1"
    local complexity="$2"
    local has_frontend="$3"
    local has_backend="$4"
    local has_db="$5"
    local has_api="$6"
    local has_test="$7"
    local has_deploy="$8"
    local has_docs="$9"

    # 全DAGノードをクリア（連想配列属性を維持）
    _dag_reset_arrays

    # ============ 共通ノード ============

    # Phase 0: 要件分析（常に最初）
    dag_add_node "REQ" "要件分析・設計" "3" "" "phase_requirements"

    # Phase 0.5: RAG検索（v7.0新機能 - REQ完了後）
    dag_add_node "RAG" "RAGナレッジ検索" "1" "REQ" "phase_rag_search"

    # Phase 1: 競合調査（complexityがdeepの場合のみ）
    if [[ "$complexity" == "deep" ]]; then
        dag_add_node "COMP" "競合・市場調査" "5" "REQ" "phase_competitive_research"
    fi

    # ============ 実装ノード（並列可能） ============
    local impl_deps="RAG"
    [[ "$complexity" == "deep" ]] && impl_deps="RAG,COMP"

    if [[ "$has_db" == "true" ]]; then
        dag_add_node "DB" "DB設計・実装" "5" "$impl_deps" "phase_database"
    fi

    if [[ "$has_backend" == "true" ]]; then
        local be_deps="$impl_deps"
        [[ "$has_db" == "true" ]] && be_deps="${be_deps},DB"
        dag_add_node "BE" "バックエンド実装" "10" "$be_deps" "phase_backend"
    fi

    if [[ "$has_api" == "true" ]]; then
        local api_deps="$impl_deps"
        [[ "$has_backend" == "true" ]] && api_deps="BE"
        dag_add_node "API" "API実装" "8" "$api_deps" "phase_api"
    fi

    if [[ "$has_frontend" == "true" ]]; then
        local fe_deps="$impl_deps"
        [[ "$has_api" == "true" ]] && fe_deps="API"
        [[ "$has_backend" == "true" && "$has_api" != "true" ]] && fe_deps="BE"
        dag_add_node "FE" "フロントエンド実装" "10" "$fe_deps" "phase_frontend"
    fi

    # 単純なスクリプトタスク
    if [[ "$task_type" == "script" ]]; then
        dag_add_node "IMPL" "実装" "5" "$impl_deps" "phase_implementation"
    fi

    # ============ 品質保証ノード ============
    local qa_deps=""
    [[ "$has_frontend" == "true" ]] && qa_deps="FE"
    [[ "$has_backend" == "true" && -z "$qa_deps" ]] && qa_deps="BE"
    [[ "$has_api" == "true" && -z "$qa_deps" ]] && qa_deps="API"
    [[ "$task_type" == "script" ]] && qa_deps="IMPL"

    if [[ -n "$qa_deps" ]]; then
        dag_add_node "QA" "品質チェック・修正" "5" "$qa_deps" "phase_quality_check"

        if [[ "$has_test" == "true" || "$complexity" == "deep" ]]; then
            dag_add_node "TEST" "テスト実装・実行" "5" "$qa_deps" "phase_testing"
        fi
    fi

    # ============ v20.0 品質要塞ノード ============
    local qf_deps="QA"
    [[ -n "${DAG_NODES["TEST"]:-}" ]] && qf_deps="${qf_deps},TEST"

    # Phase 3.8: Quality Gate（品質ゲート）
    if [[ "${ENABLE_QUALITY_GATE:-true}" == "true" ]]; then
        dag_add_node "QG" "品質ゲート (6軸検証)" "3" "$qf_deps" "phase_quality_gate"
        # Phase 3.9: Functional Healing（機能修復）
        dag_add_node "FH" "機能修復エンジン" "4" "QG" "phase_functional_healing"
        qf_deps="FH"
    fi

    # ============ 最終ノード ============
    local final_deps="$qf_deps"

    if [[ "$has_docs" == "true" || "$complexity" == "deep" ]]; then
        dag_add_node "DOC" "ドキュメント生成" "3" "$final_deps" "phase_documentation"
        final_deps="DOC"
    fi

    if [[ "$has_deploy" == "true" ]]; then
        dag_add_node "DEPLOY" "デプロイ準備" "3" "$final_deps" "phase_deploy"
        final_deps="DEPLOY"
    fi

    # Phase 5.9: Smoke Test（スモークテスト）
    # v2034.8 / PFP-055: QG高スコア時の SMOKE スキップは phase_smoke_test() 内で判定
    # (DAG構築時点では QG_SCORE 未確定のため、ここでは常に登録する)
    if [[ "${ENABLE_SMOKE_TEST:-true}" == "true" ]]; then
        dag_add_node "SMOKE" "スモークテスト (CRUD往復)" "5" "$final_deps" "phase_smoke_test"
        final_deps="SMOKE"
    fi

    # ナレッジ蓄積（常に最後）
    dag_add_node "LEARN" "ナレッジ蓄積" "2" "$final_deps" "phase_knowledge_save"

    echo ""
    echo -e "${BOLD}${GREEN}[DAG] パイプライン構築完了: ${#DAG_NODES[@]}ノード${NC}"
    dag_print_graph
}

# ============================================================
# DAGノード操作
# ============================================================
dag_add_node() {
    local id="$1"
    local name="$2"
    local est_minutes="$3"
    local dependencies="$4"
    local command="$5"

    DAG_NODES["$id"]="${name}|${est_minutes}|${dependencies}|${command}"
    DAG_STATUS["$id"]="pending"

    # v11.0: コスト見積もりを自動計算
    local cost
    cost=$(awk "BEGIN { printf \"%.2f\", ${est_minutes} * ${DAG_COST_PER_MINUTE} }")
    DAG_COST_ESTIMATE["$id"]="$cost"
}

dag_get_name() { echo "${DAG_NODES[$1]}" | cut -d'|' -f1; }
dag_get_est()  { echo "${DAG_NODES[$1]}" | cut -d'|' -f2; }
dag_get_deps() { echo "${DAG_NODES[$1]}" | cut -d'|' -f3; }
dag_get_cmd()  { echo "${DAG_NODES[$1]}" | cut -d'|' -f4; }

# ============================================================
# v11.0: 循環依存バリデーション
# ============================================================
# DAG内の循環依存を検出する。実行前に呼び出して安全性を保証。
dag_validate_dependencies() {
    echo -e "  ${CYAN}[DAG] 依存関係バリデーション中...${NC}"

    # 各ノードについてDFS（深さ優先探索）で循環を検出
    local -A visit_state=()  # unvisited / visiting / visited

    for node_id in "${!DAG_NODES[@]}"; do
        visit_state[$node_id]="unvisited"
    done

    _dag_dfs_detect_cycle() {
        local node="$1"
        local path="$2"

        [[ "${visit_state[$node]}" == "visited" ]] && return 0

        if [[ "${visit_state[$node]}" == "visiting" ]]; then
            echo -e "    ${RED}循環依存を検出: ${path} -> ${node}${NC}"
            return 1
        fi

        visit_state[$node]="visiting"

        local deps
        deps=$(dag_get_deps "$node")
        if [[ -n "$deps" ]]; then
            IFS=',' read -ra dep_arr <<< "$deps"
            for dep in "${dep_arr[@]}"; do
                dep=$(echo "$dep" | xargs)
                [[ -z "$dep" ]] && continue
                [[ -z "${DAG_NODES["$dep"]:-}" ]] && {
                    echo -e "    ${YELLOW}警告: ノード [${node}] が存在しない依存先 [${dep}] を参照${NC}"
                    continue
                }
                if ! _dag_dfs_detect_cycle "$dep" "${path} -> ${node}"; then
                    return 1
                fi
            done
        fi

        visit_state[$node]="visited"
        return 0
    }

    for node_id in "${!DAG_NODES[@]}"; do
        if [[ "${visit_state[$node_id]}" == "unvisited" ]]; then
            if ! _dag_dfs_detect_cycle "$node_id" "(root)"; then
                echo -e "    ${RED}[DAG] 循環依存バリデーション: FAILED${NC}"
                return 1
            fi
        fi
    done

    echo -e "    ${GREEN}[DAG] 循環依存バリデーション: OK (${#DAG_NODES[@]}ノード検証済み)${NC}"
    return 0
}

# ============================================================
# v11.0: コスト見積もり
# ============================================================
_dag_estimate_costs() {
    local total_cost=0

    echo -e "\n  ${BOLD}${CYAN}[DAG] コスト見積もり:${NC}"
    echo -e "    ├ レート: \$${DAG_COST_PER_MINUTE}/min"

    for node_id in "${!DAG_NODES[@]}"; do
        local est_min
        est_min=$(dag_get_est "$node_id")
        local cost="${DAG_COST_ESTIMATE["$node_id"]:-0}"
        total_cost=$(awk "BEGIN { printf \"%.2f\", ${total_cost} + ${cost} }")
    done

    echo -e "    ├ 推定合計コスト: \$${total_cost}"
    echo -e "    ├ セッション予算: \$${DAG_COST_TOTAL_BUDGET}"

    local within_budget
    within_budget=$(awk "BEGIN { print (${total_cost} <= ${DAG_COST_TOTAL_BUDGET}) ? 1 : 0 }")
    if [[ "$within_budget" == "1" ]]; then
        echo -e "    └ ステータス: ${GREEN}予算内${NC}"
    else
        echo -e "    └ ステータス: ${RED}予算超過の可能性あり${NC}"
    fi
}

# ノード別コスト詳細を表示
dag_cost_report() {
    echo -e "\n${BOLD}  ┌────────────────────────────────────────────────────┐${NC}"
    echo -e "${BOLD}  │          DAG Cost Report (v11.0)                    │${NC}"
    echo -e "${BOLD}  └────────────────────────────────────────────────────┘${NC}"

    local total_estimate=0
    local total_actual=0

    printf "  %-8s %-20s %8s %8s %8s\n" "Node" "Name" "Est(\$)" "Act(\$)" "Delta"
    echo -e "  $(printf '%.0s─' {1..56})"

    for node_id in "${!DAG_NODES[@]}"; do
        local name
        name=$(dag_get_name "$node_id")
        local est_cost="${DAG_COST_ESTIMATE["$node_id"]:-0.00}"
        local act_cost="${DAG_COST_ACTUAL["$node_id"]:-0.00}"
        local delta
        delta=$(awk "BEGIN { printf \"%.2f\", ${act_cost} - ${est_cost} }")

        local delta_color="${NC}"
        local delta_sign=""
        local cmp
        cmp=$(awk "BEGIN { print (${delta} > 0) ? 1 : 0 }")
        [[ "$cmp" == "1" ]] && delta_color="${RED}" && delta_sign="+"
        cmp=$(awk "BEGIN { print (${delta} < 0) ? 1 : 0 }")
        [[ "$cmp" == "1" ]] && delta_color="${GREEN}"

        printf "  %-8s %-20s %8s %8s " "$node_id" "$name" "$est_cost" "$act_cost"
        echo -e "${delta_color}${delta_sign}${delta}${NC}"

        total_estimate=$(awk "BEGIN { printf \"%.2f\", ${total_estimate} + ${est_cost} }")
        total_actual=$(awk "BEGIN { printf \"%.2f\", ${total_actual} + ${act_cost} }")
    done

    echo -e "  $(printf '%.0s─' {1..56})"
    local total_delta
    total_delta=$(awk "BEGIN { printf \"%.2f\", ${total_actual} - ${total_estimate} }")
    printf "  %-8s %-20s %8s %8s %8s\n" "TOTAL" "" "$total_estimate" "$total_actual" "$total_delta"
    echo ""
}

# ============================================================
# v11.0: クリティカルパス分析
# ============================================================
# DAG中の最長実行パスを特定する（ボトルネック分析用）
dag_critical_path() {
    echo -e "\n${BOLD}  ┌────────────────────────────────────────────────────┐${NC}"
    echo -e "${BOLD}  │        Critical Path Analysis (v11.0)               │${NC}"
    echo -e "${BOLD}  └────────────────────────────────────────────────────┘${NC}"

    # 各ノードの最長パスコスト（そのノードまでの累積時間）を計算
    local -A longest_path_cost=()
    local -A longest_path_prev=()
    local -A computed=()

    _dag_compute_longest() {
        local node="$1"
        [[ -n "${computed[$node]:-}" ]] && return

        local est
        est=$(dag_get_est "$node")
        local deps
        deps=$(dag_get_deps "$node")
        local max_prev_cost=0
        local max_prev_node=""

        if [[ -n "$deps" ]]; then
            IFS=',' read -ra dep_arr <<< "$deps"
            for dep in "${dep_arr[@]}"; do
                dep=$(echo "$dep" | xargs)
                [[ -z "$dep" ]] && continue
                [[ -z "${DAG_NODES["$dep"]:-}" ]] && continue
                _dag_compute_longest "$dep"
                local dep_cost="${longest_path_cost[$dep]:-0}"
                if (( dep_cost > max_prev_cost )); then
                    max_prev_cost=$dep_cost
                    max_prev_node="$dep"
                fi
            done
        fi

        longest_path_cost[$node]=$((max_prev_cost + est))
        longest_path_prev[$node]="$max_prev_node"
        computed[$node]=1
    }

    for node_id in "${!DAG_NODES[@]}"; do
        _dag_compute_longest "$node_id"
    done

    # 最長パスの終端ノードを特定
    local critical_end=""
    local critical_cost=0
    for node_id in "${!longest_path_cost[@]}"; do
        if (( ${longest_path_cost[$node_id]} > critical_cost )); then
            critical_cost=${longest_path_cost[$node_id]}
            critical_end="$node_id"
        fi
    done

    # 終端から逆順にクリティカルパスを復元
    local -a critical_nodes=()
    local current="$critical_end"
    while [[ -n "$current" ]]; do
        critical_nodes=("$current" "${critical_nodes[@]}")
        current="${longest_path_prev[$current]:-}"
    done

    echo ""
    echo -e "  ${BOLD}クリティカルパス（最長実行パス）:${NC}"
    echo -e "  合計推定時間: ${RED}${critical_cost}分${NC}"
    echo ""

    local path_str=""
    local step=1
    for nid in "${critical_nodes[@]}"; do
        local name
        name=$(dag_get_name "$nid")
        local est
        est=$(dag_get_est "$nid")
        local cost="${DAG_COST_ESTIMATE["$nid"]:-0}"

        if [[ -n "$path_str" ]]; then
            echo -e "       ${BLUE}│${NC}"
            echo -e "       ${BLUE}▼${NC}"
        fi
        echo -e "    ${RED}[${step}]${NC} ${CYAN}${nid}${NC}: ${name} (~${est}min, \$${cost})"
        ((step++))
    done

    echo ""
    echo -e "  ${YELLOW}注意: クリティカルパス上のノードが全体の実行時間を決定します${NC}"
    echo -e "  ${YELLOW}最適化するにはこれらのノードの実行時間短縮が効果的です${NC}"
    echo ""

    # 各ノードの余裕時間（スラック）を表示
    echo -e "  ${BOLD}ノード別スラック（余裕時間）:${NC}"
    printf "    %-8s %-20s %8s %8s %8s\n" "Node" "Name" "Est(min)" "CP(min)" "Slack"
    echo -e "    $(printf '%.0s─' {1..56})"

    for node_id in "${!DAG_NODES[@]}"; do
        local name
        name=$(dag_get_name "$node_id")
        local est
        est=$(dag_get_est "$node_id")
        local node_cp_cost="${longest_path_cost[$node_id]:-0}"
        local slack=$((critical_cost - node_cp_cost))

        local slack_color="${GREEN}"
        (( slack == 0 )) && slack_color="${RED}"
        (( slack > 0 && slack <= 3 )) && slack_color="${YELLOW}"

        printf "    %-8s %-20s %8s %8s " "$node_id" "$name" "${est}" "${node_cp_cost}"
        echo -e "${slack_color}${slack}min${NC}"
    done
    echo ""
}

# ============================================================
# v11.0: ASCII Ganttチャート風タイムライン
# ============================================================
dag_timeline() {
    echo -e "\n${BOLD}  ┌────────────────────────────────────────────────────────────────┐${NC}"
    echo -e "${BOLD}  │              Execution Timeline (v11.0)                         │${NC}"
    echo -e "${BOLD}  └────────────────────────────────────────────────────────────────┘${NC}"

    # 各ノードのレベル（開始可能最早時刻）を計算
    local -A earliest_start=()
    local -A computed=()

    _dag_compute_earliest() {
        local node="$1"
        [[ -n "${computed[$node]:-}" ]] && return

        local deps
        deps=$(dag_get_deps "$node")
        local max_end=0

        if [[ -n "$deps" ]]; then
            IFS=',' read -ra dep_arr <<< "$deps"
            for dep in "${dep_arr[@]}"; do
                dep=$(echo "$dep" | xargs)
                [[ -z "$dep" ]] && continue
                [[ -z "${DAG_NODES["$dep"]:-}" ]] && continue
                _dag_compute_earliest "$dep"
                local dep_est
                dep_est=$(dag_get_est "$dep")
                local dep_end=$(( ${earliest_start[$dep]:-0} + dep_est ))
                (( dep_end > max_end )) && max_end=$dep_end
            done
        fi

        earliest_start[$node]=$max_end
        computed[$node]=1
    }

    for node_id in "${!DAG_NODES[@]}"; do
        _dag_compute_earliest "$node_id"
    done

    # 最大タイムスパンを計算
    local max_time=0
    for node_id in "${!DAG_NODES[@]}"; do
        local est
        est=$(dag_get_est "$node_id")
        local end_time=$(( ${earliest_start[$node_id]:-0} + est ))
        (( end_time > max_time )) && max_time=$end_time
    done

    # チャート幅（端末幅に合わせる）
    local chart_width=40
    local scale=1
    if (( max_time > 0 )); then
        scale=$(awk "BEGIN { printf \"%.4f\", ${chart_width} / ${max_time} }")
    fi

    # タイムラインヘッダー
    echo ""
    printf "    %-8s %-14s " "Node" "Name"
    local tick=0
    while (( tick <= max_time )); do
        printf "%-4s" "${tick}"
        tick=$((tick + 5))
    done
    echo " (min)"

    printf "    %-8s %-14s " "" ""
    for (( i=0; i<chart_width; i++ )); do
        printf "-"
    done
    echo ""

    # ノードをearliest_start順にソートして表示
    local -a sorted_nodes=()
    for node_id in "${!DAG_NODES[@]}"; do
        sorted_nodes+=("${earliest_start[$node_id]:-0}:${node_id}")
    done
    IFS=$'\n' sorted_nodes=($(sort -t: -k1 -n <<< "${sorted_nodes[*]}")); unset IFS

    for entry in "${sorted_nodes[@]}"; do
        local node_id="${entry#*:}"
        local name
        name=$(dag_get_name "$node_id")
        local est
        est=$(dag_get_est "$node_id")
        local start="${earliest_start[$node_id]:-0}"
        local status="${DAG_STATUS["$node_id"]:-pending}"

        # 名前を短縮
        local short_name="${name:0:13}"

        # バーの位置を計算
        local bar_start
        bar_start=$(awk "BEGIN { printf \"%d\", ${start} * ${scale} }")
        local bar_len
        bar_len=$(awk "BEGIN { v = ${est} * ${scale}; printf \"%d\", (v < 1 && v > 0) ? 1 : v }")
        (( bar_len < 1 )) && bar_len=1

        # ステータスに応じた色と文字
        local bar_char="="
        local bar_color="${BLUE}"
        case "$status" in
            completed) bar_color="${GREEN}";  bar_char="#" ;;
            running)   bar_color="${YELLOW}"; bar_char=">" ;;
            failed)    bar_color="${RED}";    bar_char="X" ;;
            skipped)   bar_color="${PURPLE}"; bar_char="-" ;;
        esac

        printf "    %-8s %-14s " "$node_id" "$short_name"

        # 空白（開始位置まで）
        for (( i=0; i<bar_start; i++ )); do
            printf " "
        done

        # バー描画
        echo -ne "${bar_color}"
        printf "["
        for (( i=0; i<bar_len; i++ )); do
            printf "%s" "$bar_char"
        done
        printf "]"
        echo -e "${NC} ${est}m"
    done

    # フッター
    printf "    %-8s %-14s " "" ""
    for (( i=0; i<chart_width; i++ )); do
        printf "-"
    done
    echo ""
    echo -e "    ${BOLD}推定総時間（並列時）: ~${max_time}分${NC}"
    echo ""
}

# ============================================================
# v11.0: DAG動的リプランニング
# ============================================================
# ノード失敗時にDAGを再構成し、代替パスや軽量版ノードに切り替える
dag_replan() {
    local session_id="$1"
    local failed_node="$2"

    echo -e "\n${BOLD}${YELLOW}[DAG] 動的リプランニング開始${NC}"
    echo -e "  失敗ノード: ${RED}${failed_node}${NC}"
    echo -e "  セッション: ${session_id}"

    local failed_name
    failed_name=$(dag_get_name "$failed_node")
    local failed_deps
    failed_deps=$(dag_get_deps "$failed_node")
    local failed_cmd
    failed_cmd=$(dag_get_cmd "$failed_node")

    # 戦略1: 失敗ノードを軽量版に置き換え
    local replan_strategy="simplify"

    # 失敗ノードに依存しているノードを特定
    local -a dependent_nodes=()
    for node_id in "${!DAG_NODES[@]}"; do
        local deps
        deps=$(dag_get_deps "$node_id")
        if [[ "$deps" == *"$failed_node"* ]]; then
            dependent_nodes+=("$node_id")
        fi
    done

    echo -e "  影響を受けるノード: ${#dependent_nodes[@]}個"
    for dep_node in "${dependent_nodes[@]}"; do
        echo -e "    - ${CYAN}${dep_node}${NC}: $(dag_get_name "$dep_node")"
    done

    # リプランニング戦略の決定
    case "$failed_node" in
        DB)
            echo -e "  ${YELLOW}戦略: SQLite簡易版にフォールバック${NC}"
            dag_add_node "DB_LITE" "DB設計・実装(簡易版)" "3" "$failed_deps" "phase_database_lite"
            DAG_STATUS["DB_LITE"]="pending"
            # 依存ノードの参照先を切り替え
            for dep_node in "${dependent_nodes[@]}"; do
                _dag_replace_dependency "$dep_node" "$failed_node" "DB_LITE"
            done
            replan_strategy="fallback_lite"
            ;;
        BE)
            echo -e "  ${YELLOW}戦略: 最小限APIサーバーにフォールバック${NC}"
            dag_add_node "BE_MIN" "バックエンド(最小版)" "5" "$failed_deps" "phase_backend_minimal"
            DAG_STATUS["BE_MIN"]="pending"
            for dep_node in "${dependent_nodes[@]}"; do
                _dag_replace_dependency "$dep_node" "$failed_node" "BE_MIN"
            done
            replan_strategy="fallback_minimal"
            ;;
        FE)
            echo -e "  ${YELLOW}戦略: 静的HTML版にフォールバック${NC}"
            dag_add_node "FE_STATIC" "フロントエンド(静的版)" "4" "$failed_deps" "phase_frontend_static"
            DAG_STATUS["FE_STATIC"]="pending"
            for dep_node in "${dependent_nodes[@]}"; do
                _dag_replace_dependency "$dep_node" "$failed_node" "FE_STATIC"
            done
            replan_strategy="fallback_static"
            ;;
        TEST|QA)
            echo -e "  ${YELLOW}戦略: 手動テストチェックリスト生成に切り替え${NC}"
            dag_add_node "QA_MANUAL" "手動テストリスト生成" "2" "$failed_deps" "phase_qa_manual"
            DAG_STATUS["QA_MANUAL"]="pending"
            for dep_node in "${dependent_nodes[@]}"; do
                _dag_replace_dependency "$dep_node" "$failed_node" "QA_MANUAL"
            done
            replan_strategy="manual_fallback"
            ;;
        *)
            echo -e "  ${YELLOW}戦略: 失敗ノードをスキップし後続ノードの依存を切り替え${NC}"
            # 失敗ノードの依存先を後続に引き継ぐ
            for dep_node in "${dependent_nodes[@]}"; do
                _dag_replace_dependency "$dep_node" "$failed_node" "$failed_deps"
            done
            replan_strategy="skip_and_rewire"
            ;;
    esac

    # 失敗ノードをスキップ状態に
    DAG_STATUS["$failed_node"]="skipped"
    # 配信前監査D4: 失敗ノードをグラフから除去(複数リプラン時の可視化混乱・依存解決の誤認を防止。
    # 依存は _dag_replace_dependency でフォールバック先へ置換済)
    unset 'DAG_NODES[$failed_node]' 2>/dev/null || true

    # コスト再見積もり
    _dag_estimate_costs

    # リプラン後のDAGバリデーション
    if dag_validate_dependencies; then
        echo -e "\n  ${GREEN}[DAG] リプランニング完了 (戦略: ${replan_strategy})${NC}"
        dag_print_graph
        return 0
    else
        echo -e "\n  ${RED}[DAG] リプランニング後も依存関係エラーが残存${NC}"
        return 1
    fi
}

# 依存関係の差し替えヘルパー
_dag_replace_dependency() {
    local node_id="$1"
    local old_dep="$2"
    local new_dep="$3"

    local current="${DAG_NODES["$node_id"]}"
    local name
    name=$(echo "$current" | cut -d'|' -f1)
    local est
    est=$(echo "$current" | cut -d'|' -f2)
    local deps
    deps=$(echo "$current" | cut -d'|' -f3)
    local cmd
    cmd=$(echo "$current" | cut -d'|' -f4)

    # 依存関係内の旧ノードIDを新ノードIDに置換
    local new_deps
    new_deps=$(echo "$deps" | sed "s/${old_dep}/${new_dep}/g")

    DAG_NODES["$node_id"]="${name}|${est}|${new_deps}|${cmd}"
}

# ============================================================
# v11.0: スマートプリセット選択
# ============================================================
# タスク説明のキーワード分析から最適なプリセットを自動選択
dag_smart_preset() {
    local task_desc="$1"
    local task_lower
    task_lower=$(echo "$task_desc" | tr '[:upper:]' '[:lower:]')

    echo -e "\n${BOLD}${PURPLE}[DAG] スマートプリセット分析中...${NC}"

    local score_quick=0
    local score_standard=0
    local score_deep=0
    local score_hotfix=0

    # Hotfixスコアリング
    [[ "$task_lower" =~ (バグ|bug|fix|修正|エラー|error|壊れ|broken|crash|緊急|urgent|hotfix) ]] && score_hotfix=$((score_hotfix + 10))
    [[ "$task_lower" =~ (直して|なおして|治して|修復|repair|patch) ]] && score_hotfix=$((score_hotfix + 8))

    # Quickスコアリング
    [[ "$task_lower" =~ (簡単|simple|すぐ|quick|小さ|small|ちょっと|minor|軽い|light) ]] && score_quick=$((score_quick + 10))
    [[ "$task_lower" =~ (スクリプト|script|コマンド|command|ツール|tool|ユーティリティ|utility) ]] && score_quick=$((score_quick + 5))
    [[ "$task_lower" =~ (1ファイル|単一|single|one.file) ]] && score_quick=$((score_quick + 5))

    # Standardスコアリング
    [[ "$task_lower" =~ (作って|作成|create|build|開発|develop|実装|implement) ]] && score_standard=$((score_standard + 5))
    [[ "$task_lower" =~ (アプリ|app|サイト|site|ページ|page|システム|system) ]] && score_standard=$((score_standard + 5))

    # Deepスコアリング
    [[ "$task_lower" =~ (saas|crm|ecommerce|ec|大規模|enterprise|本格|production|プロダクション) ]] && score_deep=$((score_deep + 10))
    [[ "$task_lower" =~ (テスト|test|品質|quality|セキュリティ|security|パフォーマンス|performance) ]] && score_deep=$((score_deep + 5))
    [[ "$task_lower" =~ (デプロイ|deploy|ci.cd|自動化|automation|スケール|scale) ]] && score_deep=$((score_deep + 5))
    [[ "$task_lower" =~ (競合|調査|research|分析|analysis|ドキュメント|document) ]] && score_deep=$((score_deep + 3))
    [[ "$task_lower" =~ (フルスタック|fullstack|full.stack|マイクロサービス|microservice) ]] && score_deep=$((score_deep + 8))

    # 文字数による複雑度ボーナス
    local desc_len=${#task_desc}
    if (( desc_len > 100 )); then
        score_deep=$((score_deep + 3))
    elif (( desc_len < 20 )); then
        score_quick=$((score_quick + 3))
    fi

    # スコア表示
    echo -e "  スコア分析:"
    echo -e "    Quick    : ${score_quick}"
    echo -e "    Standard : ${score_standard}"
    echo -e "    Deep     : ${score_deep}"
    echo -e "    Hotfix   : ${score_hotfix}"

    # 最高スコアのプリセットを選択
    local best_preset="standard"
    local best_score=$score_standard

    if (( score_hotfix > best_score )); then
        best_preset="hotfix"
        best_score=$score_hotfix
    fi
    if (( score_quick > best_score )); then
        best_preset="quick"
        best_score=$score_quick
    fi
    if (( score_deep > best_score )); then
        best_preset="deep"
        best_score=$score_deep
    fi

    echo -e "\n  ${BOLD}${GREEN}選択されたプリセット: ${best_preset} (スコア: ${best_score})${NC}"

    # プリセットを適用
    case "$best_preset" in
        quick)   dag_preset_quick   ;;
        hotfix)  dag_preset_hotfix  ;;
        deep)    dag_analyze_task "$task_desc" "deep" ;;
        *)       dag_analyze_task "$task_desc" "standard" ;;
    esac

    echo "$best_preset"
}

# ============================================================
# DAGグラフ表示
# ============================================================
dag_print_graph() {
    echo ""
    echo -e "${BOLD}  ┌─────────────────────────────────────────┐${NC}"
    echo -e "${BOLD}  │          DAG Pipeline Graph              │${NC}"
    echo -e "${BOLD}  └─────────────────────────────────────────┘${NC}"
    echo ""

    # トポロジカルソートしてレベル別に表示
    local -A levels=()
    local -A visited=()

    _compute_level() {
        local node="$1"
        [[ -n "${visited[$node]:-}" ]] && return
        visited[$node]=1

        local deps=$(dag_get_deps "$node")
        local max_dep_level=-1

        if [[ -n "$deps" ]]; then
            IFS=',' read -ra dep_arr <<< "$deps"
            for dep in "${dep_arr[@]}"; do
                dep=$(echo "$dep" | xargs)
                [[ -z "$dep" ]] && continue
                [[ -z "${DAG_NODES["$dep"]:-}" ]] && continue
                _compute_level "$dep"
                local dep_level="${levels[$dep]:-0}"
                (( dep_level > max_dep_level )) && max_dep_level=$dep_level
            done
        fi

        levels[$node]=$((max_dep_level + 1))
    }

    for node_id in "${!DAG_NODES[@]}"; do
        _compute_level "$node_id"
    done

    # レベル別にグループ化して表示
    local max_level=0
    for level in "${levels[@]}"; do
        (( level > max_level )) && max_level=$level
    done

    local total_est=0

    for (( lvl=0; lvl<=max_level; lvl++ )); do
        local nodes_at_level=()
        for node_id in "${!levels[@]}"; do
            [[ "${levels[$node_id]}" == "$lvl" ]] && nodes_at_level+=("$node_id")
        done

        if [[ ${#nodes_at_level[@]} -gt 0 ]]; then
            local parallel_label=""
            (( ${#nodes_at_level[@]} > 1 )) && parallel_label=" ${YELLOW}(並列実行可)${NC}"

            echo -e "  ${BOLD}Stage $lvl${parallel_label}${NC}"

            local stage_max_est=0
            for nid in "${nodes_at_level[@]}"; do
                local name=$(dag_get_name "$nid")
                local est=$(dag_get_est "$nid")
                local deps=$(dag_get_deps "$nid")
                local status="${DAG_STATUS["$nid"]:-pending}"
                local cost="${DAG_COST_ESTIMATE["$nid"]:-0}"

                # ステータスアイコン
                local icon="⬜"
                case "$status" in
                    completed) icon="✅" ;;
                    running)   icon="🔄" ;;
                    failed)    icon="❌" ;;
                    skipped)   icon="⏭️" ;;
                esac

                local dep_str=""
                [[ -n "$deps" ]] && dep_str=" ← [${deps}]"

                echo -e "    ${icon} ${CYAN}${nid}${NC}: ${name} (~${est}min, \$${cost})${dep_str}"

                (( est > stage_max_est )) && stage_max_est=$est
            done

            total_est=$((total_est + stage_max_est))

            if (( lvl < max_level )); then
                echo -e "    ${BLUE}│${NC}"
                echo -e "    ${BLUE}▼${NC}"
            fi
        fi
    done

    echo ""
    echo -e "  ${BOLD}推定総実行時間: ~${total_est}分（並列実行時）${NC}"
    echo ""
}

# ============================================================
# DAG実行エンジン
# ============================================================
dag_execute() {
    local session_id="$1"
    local task_desc="$2"

    echo -e "\n${BOLD}${PURPLE}[DAG] パイプライン実行開始${NC}"
    echo -e "  セッションID: ${session_id}"
    echo -e "  タスク: ${task_desc}"
    echo ""

    # v11.0: 実行前に循環依存をチェック
    if ! dag_validate_dependencies; then
        echo -e "  ${RED}[DAG] 循環依存が存在するため実行を中止${NC}"
        return 1
    fi

    local dag_start=$(date +%s)
    local execution_order=()
    local failed_nodes=()

    # トポロジカルソート順に実行
    while true; do
        local runnable_nodes=()
        local all_done=true

        for node_id in "${!DAG_NODES[@]}"; do
            local status="${DAG_STATUS["$node_id"]}"

            # 完了・失敗・スキップ済みはスキップ
            [[ "$status" != "pending" ]] && continue
            all_done=false

            # 依存関係チェック
            local deps=$(dag_get_deps "$node_id")
            local deps_satisfied=true

            if [[ -n "$deps" ]]; then
                IFS=',' read -ra dep_arr <<< "$deps"
                for dep in "${dep_arr[@]}"; do
                    dep=$(echo "$dep" | xargs)
                    [[ -z "$dep" ]] && continue
                    [[ -z "${DAG_NODES["$dep"]:-}" ]] && continue

                    local dep_status="${DAG_STATUS["$dep"]:-pending}"
                    if [[ "$dep_status" == "pending" || "$dep_status" == "running" ]]; then
                        deps_satisfied=false
                        break
                    elif [[ "$dep_status" == "failed" ]]; then
                        # v11.0: 失敗時はリプランを試行
                        echo -e "  ${YELLOW}依存ノード ${dep} が失敗 → リプランニング試行${NC}"
                        if dag_replan "$session_id" "$dep"; then
                            # リプラン成功: 依存関係が変わったので再チェック
                            deps_satisfied=false
                        else
                            # リプラン失敗: スキップ
                            DAG_STATUS["$node_id"]="skipped"
                            echo -e "  ⏭️ ${YELLOW}スキップ: $(dag_get_name "$node_id")（依存ノード ${dep} が失敗、リプラン不可）${NC}"
                            deps_satisfied=false
                        fi
                        break
                    fi
                done
            fi

            [[ "$deps_satisfied" == "true" ]] && runnable_nodes+=("$node_id")
        done

        # 全て完了チェック
        [[ "$all_done" == "true" ]] && break
        [[ ${#runnable_nodes[@]} -eq 0 ]] && { echo -e "  ${RED}❌ デッドロック検出: 実行可能なノードがありません${NC}"; break; }

        # 実行可能ノードを順次実行（v7.0ではシーケンシャル、将来的に並列化）
        for node_id in "${runnable_nodes[@]}"; do
            local name=$(dag_get_name "$node_id")
            local cmd=$(dag_get_cmd "$node_id")

            echo -e "\n${BOLD}═══════════════════════════════════════════════${NC}"
            echo -e "${BOLD}  🔄 [${node_id}] ${name}${NC}"
            echo -e "${BOLD}═══════════════════════════════════════════════${NC}"

            DAG_STATUS["$node_id"]="running"
            DAG_START_TIME["$node_id"]=$(date +%s)

            # ノードのコマンドを実行
            if type -t "$cmd" &>/dev/null; then
                if $cmd "$session_id" "$task_desc" 2>&1; then
                    DAG_STATUS["$node_id"]="completed"
                    echo -e "  ${GREEN}✅ [${node_id}] 完了${NC}"
                else
                    DAG_STATUS["$node_id"]="failed"
                    failed_nodes+=("$node_id")
                    echo -e "  ${RED}❌ [${node_id}] 失敗${NC}"

                    # セルフヒール試行
                    if _dag_self_heal "$node_id" "$session_id" "$task_desc"; then
                        DAG_STATUS["$node_id"]="completed"
                        echo -e "  ${GREEN}🔧 [${node_id}] セルフヒールで回復${NC}"
                    fi
                fi
            else
                # REQ-WIRE-001: 未定義cmdを completed と偽装しない (false-success 根絶)。
                # skipped は依存充足を満たす(dag_get_runnable_nodes line ~1267)ため
                # デッドロックは起きず、サマリでは ⏭️ として正直に可視化される。
                echo -e "  ${YELLOW}⚠️ コマンド未定義: ${cmd}（縮退スキップ — 成功扱いにしない）${NC}"
                DAG_STATUS["$node_id"]="skipped"
                DAG_UNDEFINED_NODES+=("$node_id:$cmd")
            fi

            DAG_END_TIME["$node_id"]=$(date +%s)
            execution_order+=("$node_id")

            # v11.0: 実コストを記録
            local node_start="${DAG_START_TIME["$node_id"]}"
            local node_end="${DAG_END_TIME["$node_id"]}"
            local node_duration_sec=$((node_end - node_start))
            local node_duration_min
            node_duration_min=$(awk "BEGIN { printf \"%.2f\", ${node_duration_sec} / 60 }")
            DAG_COST_ACTUAL["$node_id"]=$(awk "BEGIN { printf \"%.2f\", ${node_duration_min} * ${DAG_COST_PER_MINUTE} }")
        done
    done

    local dag_end=$(date +%s)
    local dag_duration=$((dag_end - dag_start))

    # 実行サマリー（空配列の安全な展開）
    local _exec_order_str="${execution_order[*]:-}"
    local _failed_nodes_str="${failed_nodes[*]:-}"
    _dag_print_summary "$session_id" "$task_desc" "$dag_duration" "$_exec_order_str" "$_failed_nodes_str"

    # v11.0: コストレポート
    dag_cost_report

    # v11.0: タイムライン表示
    dag_timeline

    # DAGログ保存
    _dag_save_log "$session_id" "$task_desc" "$dag_duration"

    local _fail_count=0
    [[ ${#failed_nodes[@]} -gt 0 ]] 2>/dev/null && _fail_count=${#failed_nodes[@]}
    return $(( _fail_count > 0 ? 1 : 0 ))
}

# ============================================================
# セルフヒール（v6.0から継承 + DAG対応）
# ============================================================
_dag_self_heal() {
    local node_id="$1"
    local session_id="$2"
    local task_desc="$3"
    local max_retries=2

    echo -e "  ${YELLOW}🔧 セルフヒール試行中 (最大${max_retries}回)...${NC}"

    # capstone[low]: 同一コマンドを再試行する設計。causal の根本原因ヒント(_root_hint)は
    # 診断表示のみで、ターミナル自動retryのプロンプトには未注入 (causal-healer は Desktop で
    # Claude 本体が読み根本修復に使う前提の設計。自動retryへの実注入は将来の functional-healer 経路で対応)。
    local retry
    for (( retry=1; retry<=max_retries; retry++ )); do
        echo -e "    試行 ${retry}/${max_retries}..."

        local cmd=$(dag_get_cmd "$node_id")
        if type -t "$cmd" &>/dev/null; then
            # REQ-PERF-006 (v2038): 失敗出力を causal-healer で根本原因分析する。
            # 【重要】ノードコマンドは「直接実行」する。コマンド置換 $(...) やパイプは
            # サブシェル化し、phase_requirements / phase_implementation 等が設定する
            # グローバル副作用 (REQUIREMENTS_FILE / BLUEPRINT_FILE / PC_COMPILED_*) を
            # 喪失させ、ヒール成功後の下流フェーズを壊すため (検証 #6 で確認)。
            # 出力は一時ファイルへ捕捉して表示し、失敗時のみ causal_healer_analyze に渡す。
            # 非ブロッキング・型ガード・既定ON。ENABLE_CAUSAL_HEALER=false で無効化可。
            local _heal_log
            _heal_log=$(mktemp 2>/dev/null || echo "${TMPDIR:-/tmp}/_sl_heal_$$_${retry}.log")
            if $cmd "$session_id" "$task_desc" >"$_heal_log" 2>&1; then
                cat "$_heal_log" 2>/dev/null
                rm -f "$_heal_log" 2>/dev/null
                return 0
            fi
            cat "$_heal_log" 2>/dev/null
            if [[ "${ENABLE_CAUSAL_HEALER:-true}" == "true" ]] && type -t causal_healer_analyze &>/dev/null; then
                local _heal_text _root_hint
                _heal_text=$(cat "$_heal_log" 2>/dev/null)
                if [[ -n "$_heal_text" ]]; then
                    _root_hint=$(causal_healer_analyze "$_heal_text" 2>/dev/null || true)
                    [[ -n "$_root_hint" ]] && echo -e "    ${CYAN}🧠 因果分析(根本原因):${NC} ${_root_hint}"
                fi
            fi
            rm -f "$_heal_log" 2>/dev/null
        fi

        sleep 2
    done

    return 1
}

# ============================================================
# 実行サマリー
# ============================================================
_dag_print_summary() {
    local session_id="$1"
    local task_desc="$2"
    local duration="$3"
    local execution_order="$4"
    local failed_nodes="$5"

    local completed=0
    local failed=0
    local skipped=0

    for node_id in "${!DAG_STATUS[@]}"; do
        case "${DAG_STATUS["$node_id"]}" in
            completed) completed=$((completed + 1)) ;;
            failed)    failed=$((failed + 1)) ;;
            skipped)   skipped=$((skipped + 1)) ;;
        esac
    done

    local total=${#DAG_NODES[@]}
    local minutes=$((duration / 60))
    local seconds=$((duration % 60))

    echo ""
    echo -e "${BOLD}╔═══════════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}║        DAG Pipeline 実行結果 (v11.0)          ║${NC}"
    echo -e "${BOLD}╠═══════════════════════════════════════════════╣${NC}"
    echo -e "║ セッション  : ${session_id}"
    echo -e "║ 実行時間    : ${minutes}分${seconds}秒"
    echo -e "║ ノード数    : ${total} (✅${completed} ❌${failed} ⏭️${skipped})"
    # 配信前監査D4: 未定義cmdで縮退スキップしたノードを可視化(デバッグ性)
    if [[ ${#DAG_UNDEFINED_NODES[@]} -gt 0 ]]; then
        echo -e "║ 未定義スキップ: ⚠️ ${#DAG_UNDEFINED_NODES[@]}個 (${DAG_UNDEFINED_NODES[*]})"
    fi

    if [[ $failed -eq 0 ]]; then
        echo -e "║ ステータス  : ${GREEN}SUCCESS${NC}"
    else
        echo -e "║ ステータス  : ${RED}PARTIAL FAILURE${NC}"
        echo -e "║ 失敗ノード  : ${failed_nodes}"
    fi

    echo -e "${BOLD}╚═══════════════════════════════════════════════╝${NC}"
}

# ============================================================
# DAGログ保存
# ============================================================
_dag_save_log() {
    local session_id="$1"
    local task_desc="$2"
    local duration="$3"
    local log_file="${DAG_LOG_DIR}/dag_${session_id}.json"

    local nodes_json="{"
    local first=true
    for node_id in "${!DAG_NODES[@]}"; do
        [[ "$first" != "true" ]] && nodes_json+=","
        first=false
        local name=$(dag_get_name "$node_id")
        local status="${DAG_STATUS["$node_id"]}"
        local start="${DAG_START_TIME["$node_id"]:-0}"
        local end="${DAG_END_TIME["$node_id"]:-0}"
        local est_cost="${DAG_COST_ESTIMATE["$node_id"]:-0}"
        local act_cost="${DAG_COST_ACTUAL["$node_id"]:-0}"
        nodes_json+="\"${node_id}\":{\"name\":\"${name}\",\"status\":\"${status}\",\"start\":${start},\"end\":${end},\"est_cost\":${est_cost},\"act_cost\":${act_cost}}"
    done
    nodes_json+="}"

    cat > "$log_file" <<EOF
{
  "session_id": "${session_id}",
  "task": "${task_desc}",
  "duration_seconds": ${duration},
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "dag_version": "11.0",
  "nodes": ${nodes_json}
}
EOF

    echo -e "  📝 DAGログ保存: ${log_file}"
}

# ============================================================
# DAGテンプレート（プリセット）
# ============================================================
dag_preset_quick() {
    # Quick: 最小限のノードで高速実行
    _dag_reset_arrays
    dag_add_node "REQ" "要件分析" "2" "" "phase_requirements"
    dag_add_node "RAG" "RAG検索" "1" "REQ" "phase_rag_search"
    dag_add_node "IMPL" "実装" "5" "RAG" "phase_implementation"
    dag_add_node "QA" "品質チェック" "3" "IMPL" "phase_quality_check"
    dag_add_node "LEARN" "ナレッジ蓄積" "1" "QA" "phase_knowledge_save"
}

dag_preset_hotfix() {
    # Hotfix: 最小のバグ修正パイプライン
    _dag_reset_arrays
    dag_add_node "RAG" "RAG検索（エラーパターン）" "1" "" "phase_rag_search"
    dag_add_node "FIX" "バグ修正" "5" "RAG" "phase_hotfix"
    dag_add_node "TEST" "修正テスト" "3" "FIX" "phase_testing"
    dag_add_node "LEARN" "ナレッジ蓄積" "1" "TEST" "phase_knowledge_save"
}

# ============================================================
# dag_get_runnable_nodes() -> JSON array of runnable node IDs
# ============================================================
# Returns a JSON array of node IDs whose dependencies are all
# completed (or skipped) and whose own status is still "pending".
# Used by external orchestrators to determine which nodes can
# be dispatched next.
dag_get_runnable_nodes() {
    local runnable='['
    local first=true

    for node_id in "${!DAG_NODES[@]}"; do
        local status="${DAG_STATUS["$node_id"]:-pending}"

        # Only consider pending nodes
        [[ "$status" != "pending" ]] && continue

        # Check all dependencies are completed or skipped
        local deps
        deps=$(dag_get_deps "$node_id")
        local deps_satisfied=true

        if [[ -n "$deps" ]]; then
            IFS=',' read -ra dep_arr <<< "$deps"
            for dep in "${dep_arr[@]}"; do
                dep=$(echo "$dep" | xargs)
                [[ -z "$dep" ]] && continue
                [[ -z "${DAG_NODES["$dep"]:-}" ]] && continue

                local dep_status="${DAG_STATUS["$dep"]:-pending}"
                if [[ "$dep_status" != "completed" && "$dep_status" != "skipped" ]]; then
                    deps_satisfied=false
                    break
                fi
            done
        fi

        if [[ "$deps_satisfied" == "true" ]]; then
            if [[ "$first" == "true" ]]; then
                first=false
            else
                runnable+=','
            fi
            runnable+="\"${node_id}\""
        fi
    done

    runnable+=']'
    echo "$runnable"
}

# ============================================================
# エクスポート（chain.shから使用）
# ============================================================
# このファイルは chain.sh から source される
# 使用例:
#   source lib/dag-pipeline.sh
#   dag_analyze_task "SaaS CRM作って" "deep"
#   dag_execute "session_001" "SaaS CRM作って"
#
# v11.0 新機能:
#   dag_smart_preset "バグを修正して"      # 最適プリセット自動選択
#   dag_validate_dependencies              # 循環依存チェック
#   dag_critical_path                      # クリティカルパス分析
#   dag_timeline                           # ASCII Ganttタイムライン
#   dag_cost_report                        # コスト詳細レポート
#   dag_replan "session_001" "DB"          # 失敗ノードからのリプラン
#   dag_get_runnable_nodes                 # 実行可能ノード一覧（JSON配列）
