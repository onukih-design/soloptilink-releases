#!/usr/bin/env bash
# SoloptiLinkAI v55.0 - Quality & Testing Phase Functions
# Quality gate, testing, code scan, healing phases
# Auto-generated from phases.sh - 9 functions



# ---- Phase: コードスキャン (v28.0) ----
phase_code_scan() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "code_scan" 2>/dev/null || true

    if ! type -t code_scan_init &>/dev/null; then
        echo -e "  ${YELLOW}code-scanner.sh 未ロード → スキップ${NC}"
        return 0
    fi

    echo -e "\n${BOLD}${CYAN}[v28.0] Code Scanner - 既存プロジェクトスキャン${NC}"

    code_scan_init "$session_id"
    local project_dir
    project_dir="$(_detect_project_dir 2>/dev/null || echo ".")"

    # v52.0: 前回Genomeを保存（スキャン前に退避、差分比較用）
    local FUC_PREV_GENOME_JSON="${FUC_GENOME_JSON:-}"

    local genome_json
    genome_json=$(code_scan_project "$project_dir" 2>/dev/null || echo "")

    if [[ -n "$genome_json" ]]; then
        # Store genome for other phases
        FUC_GENOME_JSON="$genome_json"
        FUC_GENOME_LOADED="true"
        echo -e "  ${GREEN}スキャン完了: schema=${CS_SCHEMA_FOUND}, routes=${CS_ROUTES_COUNT}, components=${CS_COMPONENTS_COUNT}${NC}"

        # v52.0: Phase B-7: Genome差分比較 - 前回保存Genomeと現在状態を比較
        if [[ "${FUC_IS_FOLLOWUP:-false}" == "true" ]] && [[ -n "${FUC_PREV_GENOME_JSON:-}" ]]; then
            echo -e "  ${CYAN}🧬 Genome差分比較:${NC}"
            local _gd_prev_schema _gd_curr_schema _gd_prev_routes _gd_curr_routes _gd_prev_comps _gd_curr_comps
            _gd_prev_schema=$(echo "${FUC_PREV_GENOME_JSON}" | grep -o '"schema_count":[0-9]*' | grep -o '[0-9]*' 2>/dev/null || echo "0")
            _gd_curr_schema="${CS_SCHEMA_FOUND:-0}"
            _gd_prev_routes=$(echo "${FUC_PREV_GENOME_JSON}" | grep -o '"routes_count":[0-9]*' | grep -o '[0-9]*' 2>/dev/null || echo "0")
            _gd_curr_routes="${CS_ROUTES_COUNT:-0}"
            _gd_prev_comps=$(echo "${FUC_PREV_GENOME_JSON}" | grep -o '"components_count":[0-9]*' | grep -o '[0-9]*' 2>/dev/null || echo "0")
            _gd_curr_comps="${CS_COMPONENTS_COUNT:-0}"

            local _gd_changes=0
            if [[ "$_gd_prev_schema" != "$_gd_curr_schema" ]]; then
                echo -e "    スキーマ: ${_gd_prev_schema} → ${_gd_curr_schema}"
                _gd_changes=$((_gd_changes + 1))
            fi
            if [[ "$_gd_prev_routes" != "$_gd_curr_routes" ]]; then
                echo -e "    ルート: ${_gd_prev_routes} → ${_gd_curr_routes}"
                _gd_changes=$((_gd_changes + 1))
            fi
            if [[ "$_gd_prev_comps" != "$_gd_curr_comps" ]]; then
                echo -e "    コンポーネント: ${_gd_prev_comps} → ${_gd_curr_comps}"
                _gd_changes=$((_gd_changes + 1))
            fi

            if [[ $_gd_changes -eq 0 ]]; then
                echo -e "    ${DIM}変更なし（前回セッションと同一構成）${NC}"
            else
                echo -e "    ${YELLOW}${_gd_changes}カテゴリに変更検出 → 影響分析に反映${NC}"
                export GENOME_DRIFT_DETECTED="true"
                export GENOME_DRIFT_COUNT="${_gd_changes}"
            fi
        elif [[ "${FUC_IS_FOLLOWUP:-false}" == "true" ]]; then
            echo -e "  ${DIM}🧬 前回Genome未保存 → 差分比較スキップ${NC}"
        fi

        # Save to context engine
        if type -t ctx_save &>/dev/null; then
            ctx_save "code_scan" "genome" "$genome_json" 2>/dev/null || true
        fi
    fi

    _post_phase_checkpoint "code_scan"
    return 0
}



# ---- Phase: Follow-up検出 (v28.0) ----
phase_followup_detect() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "followup_detect" 2>/dev/null || true

    if [[ "${ENABLE_FOLLOWUP:-auto}" == "false" ]]; then
        echo -e "  ${YELLOW}Follow-up Intelligence 無効${NC}"
        return 0
    fi

    if ! type -t fuc_init &>/dev/null; then
        echo -e "  ${YELLOW}followup-context.sh 未ロード → スキップ${NC}"
        return 0
    fi

    echo -e "\n${BOLD}${CYAN}[v28.0] Follow-up Intelligence - 検出フェーズ${NC}"

    fuc_init "$session_id"
    local project_dir
    project_dir="$(_detect_project_dir 2>/dev/null || echo ".")"
    fuc_detect_followup "$project_dir" "$task_desc"

    if [[ "$FUC_IS_FOLLOWUP" == "true" ]]; then
        echo -e "  ${CYAN}Follow-up検出: タイプ=${FUC_REQUEST_TYPE}${NC}"
        fuc_load_genome "$project_dir" 2>/dev/null || true
    else
        echo -e "  ${GREEN}新規ビルドとして処理${NC}"
    fi

    _post_phase_checkpoint "followup_detect"
    return 0
}



# ---- Phase 3.9: Functional Healing（機能修復） v20.0 ----
phase_functional_healing() {
    local session_id="$1"
    local task_desc="$2"

    if [[ "${ENABLE_QUALITY_GATE}" != "true" ]]; then
        return 0
    fi

    echo -e "  ${CYAN}🔧 Phase 3.9: Functional Healing - 機能修復${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    local _healing_failed=false
    local project_dir
    project_dir="$(_detect_project_dir)"

    if ! type -t fh_run_functional_healing &>/dev/null; then
        echo -e "  ${YELLOW}⚠️ Functional Healerモジュール未ロード - スキップ${NC}"
        return 0
    fi

    # v52.0: Error Chain → Healer連携 - 根本原因分析で修復戦略を高精度化
    if type -t ec_find_root_cause &>/dev/null && type -t ec_get_chain &>/dev/null; then
        local _ec_chain _ec_latest_error _ec_root_info
        _ec_chain=$(ec_get_chain 5 2>/dev/null || echo "no_errors")
        if [[ "$_ec_chain" != "no_errors" ]]; then
            # 最新エラーから根本原因を分析
            # v2003.1: 安全な配列末尾要素取得
            local _ec_buf_len=${#EC_ERROR_BUFFER[@]}
            if (( _ec_buf_len > 0 )); then
                _ec_latest_error="${EC_ERROR_BUFFER[$((_ec_buf_len - 1))]}" 2>/dev/null || true
            else
                _ec_latest_error=""
            fi
            if [[ -n "$_ec_latest_error" ]]; then
                _ec_root_info=$(ec_find_root_cause "$_ec_latest_error" 2>/dev/null || echo "")
                if [[ -n "$_ec_root_info" ]]; then
                    local _ec_root _ec_fix
                    _ec_root=$(echo "$_ec_root_info" | sed 's/.*root=\([^;]*\).*/\1/')
                    _ec_fix=$(echo "$_ec_root_info" | sed 's/.*fix=\([^;]*\).*/\1/')
                    echo -e "  ${CYAN}🔍 Error Chain分析: 根本原因=${_ec_root}, 修復戦略=${_ec_fix}${NC}"
                    echo -e "  ${DIM}  エラーチェーン: ${_ec_chain}${NC}"
                    # 根本原因をHealer環境に注入
                    export FH_ROOT_CAUSE="${_ec_root}"
                    export FH_FIX_STRATEGY="${_ec_fix}"
                    export FH_ERROR_CHAIN="${_ec_chain}"
                fi
            fi
        fi
    fi

    # v145: Feed Real Validator errors to healer
    local _rv_context=""
    if [[ -n "${QG_REAL_VALIDATOR_ERRORS:-}" ]]; then
        echo -e "  🔍 [v145] Real Validatorエラーを修復プロンプトに注入" >&2
        _rv_context="

=== コンパイルエラー（Real Validator検出） ===
${QG_REAL_VALIDATOR_ERRORS}
=== これらのエラーを優先的に修正してください ===
"
        # Export for fh_run_functional_healing to consume
        export FH_REAL_VALIDATOR_CONTEXT="$_rv_context"
    fi

    # v162: Structured QG findings for targeted healing
    local _qg_findings_context=""
    if [[ -n "${QG_STRUCTURED_FINDINGS:-}" ]]; then
        _qg_findings_context="
=== Quality Gate検出結果（優先修正） ===
$(echo -e "$QG_STRUCTURED_FINDINGS")
=== 上記の問題を重点的に修正してください ===
"
        export FH_QG_FINDINGS_CONTEXT="$_qg_findings_context"
    fi

    if fh_run_functional_healing "$project_dir" "${QUALITY_THRESHOLD:-80}"; then
        QG_SCORE=$(qg_calculate_score 2>/dev/null || echo "0")
        echo -e "  ${GREEN}✅ 機能修復完了 → 品質ゲートPASS (スコア: ${QG_SCORE})${NC}"
    else
        QG_SCORE=$(qg_calculate_score 2>/dev/null || echo "0")
        echo -e "  ${YELLOW}⚠️ 機能修復後も品質基準未達 (スコア: ${QG_SCORE})${NC}"

        # v52.0: Phase B-8: Healer失敗 → Deep Fix Engineエスカレーション
        if type -t dfe_run &>/dev/null; then
            echo -e "  ${MAGENTA}🚀 Deep Fix Engineにエスカレーション (Healer ${FH_MAX_HEAL_LOOPS:-3}回失敗)${NC}"
            local _dfe_request="品質ゲートスコア ${QG_SCORE}/${QUALITY_THRESHOLD:-80} - "
            _dfe_request+="修復${FH_MAX_HEAL_LOOPS:-3}回失敗。"
            # v145: Include RV errors in DFE request
            if [[ -n "${QG_REAL_VALIDATOR_ERRORS:-}" ]]; then
                _dfe_request+="コンパイルエラー: $(echo "${QG_REAL_VALIDATOR_ERRORS}" | head -5 | tr '\n' ' ')。"
            fi
            if [[ -n "${FH_ROOT_CAUSE:-}" ]]; then
                _dfe_request+="根本原因: ${FH_ROOT_CAUSE}, 戦略: ${FH_FIX_STRATEGY:-investigate}。"
            fi
            if [[ -n "${FH_ERROR_CHAIN:-}" ]]; then
                _dfe_request+="エラーチェーン: ${FH_ERROR_CHAIN}。"
            fi
            _dfe_request+="プロジェクト: ${project_dir}"
            local _dfe_rc=0
            dfe_run "$_dfe_request" "$project_dir" "${session_id}" 2>/dev/null || _dfe_rc=$?

            if [[ $_dfe_rc -ne 0 ]]; then
                echo -e "  ${YELLOW}⚠️ Deep Fix Engine実行エラー (rc=${_dfe_rc})${NC}"
                if type -t err_degrade &>/dev/null; then
                    err_degrade "DeepFixEngine" "dfe_run failed (rc=${_dfe_rc})" 2>/dev/null || true
                fi
            fi

            # DFE後に品質ゲート再チェック
            QG_SCORE=$(qg_calculate_score 2>/dev/null || echo "0")
            if [[ "${QG_SCORE}" -ge "${QUALITY_THRESHOLD:-80}" ]] 2>/dev/null; then
                echo -e "  ${GREEN}✅ Deep Fix Engine成功 → 品質ゲートPASS (スコア: ${QG_SCORE})${NC}"
            else
                echo -e "  ${YELLOW}⚠️ Deep Fix Engine後も品質基準未達 (スコア: ${QG_SCORE}) - 続行${NC}"
                if type -t ec_record_error &>/dev/null; then
                    _warn_on_fail "ErrorChain" "record_dfe_fail" ec_record_error "Healing+DFE failed: score=${QG_SCORE}" "functional_healing" "$project_dir" || true
                fi
                _healing_failed=true
            fi
        else
            if type -t ec_record_error &>/dev/null; then
                _warn_on_fail "ErrorChain" "record_heal_fail" ec_record_error "Healing failed, DFE unavailable: score=${QG_SCORE}" "functional_healing" "$project_dir" || true
            fi
            _healing_failed=true
        fi
    fi

    # 環境変数クリーンアップ
    unset FH_ROOT_CAUSE FH_FIX_STRATEGY FH_ERROR_CHAIN 2>/dev/null || true

    _post_phase_checkpoint "functional_healing"
    # v52.0: 修復失敗を呼び出し元に伝える（return 0→return 1で修復失敗を通知）
    [[ "${_healing_failed:-false}" == "true" ]] && return 1
    return 0
}



# ---- Phase: 差分分析 (v28.0) ----
phase_incremental_analysis() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "incremental_analysis" 2>/dev/null || true

    if ! type -t ica_init &>/dev/null; then
        echo -e "  ${YELLOW}incremental-analyzer.sh 未ロード → スキップ${NC}"
        return 0
    fi

    echo -e "\n${BOLD}${CYAN}[v28.0] Incremental Analyzer - 差分分析${NC}"

    ica_init "$session_id"

    local change_plan
    change_plan=$(ica_analyze "$task_desc" "${FUC_GENOME_JSON:-}" "${FUC_REQUEST_TYPE:-modification}" 2>/dev/null || echo "")

    if [[ -n "$change_plan" ]]; then
        ICA_CHANGE_PLAN="$change_plan"
        echo -e "  ${GREEN}差分分析完了: scope=${ICA_SCOPE}${NC}"

        if type -t ctx_save &>/dev/null; then
            ctx_save "incremental_analysis" "change_plan" "$change_plan" 2>/dev/null || true
        fi

        # v52.0: Phase C-10: import依存グラフ構築 - 変更影響範囲を正確に特定
        local _project_dir
        _project_dir="$(_detect_project_dir 2>/dev/null || echo ".")"
        if [[ -d "$_project_dir" ]]; then
            echo -e "  ${CYAN}🔗 import依存グラフ構築中...${NC}"
            local _dep_graph="" _affected_files="" _changed_files=""
            # 変更対象ファイルを取得（gitベース）
            _changed_files=$(cd "$_project_dir" && git diff --name-only HEAD 2>/dev/null | head -20 || echo "")
            if [[ -z "$_changed_files" ]]; then
                _changed_files=$(cd "$_project_dir" && git diff --name-only 2>/dev/null | head -20 || echo "")
            fi

            if [[ -n "$_changed_files" ]]; then
                local _dep_count=0
                while IFS= read -r _cf; do
                    [[ -z "$_cf" ]] && continue
                    local _cf_base
                    _cf_base=$(basename "$_cf" | sed 's/\.[^.]*$//')
                    # このファイルをimportしている他のファイルを検索
                    local _importers
                    _importers=$(grep -rl "import.*['\"].*${_cf_base}['\"]" "$_project_dir/src" "$_project_dir/app" "$_project_dir/pages" "$_project_dir/components" "$_project_dir/lib" 2>/dev/null | head -10 || echo "")
                    if [[ -n "$_importers" ]]; then
                        while IFS= read -r _imp; do
                            [[ -z "$_imp" ]] && continue
                            _dep_count=$((_dep_count + 1))
                            local _imp_rel="${_imp#${_project_dir}/}"
                            _affected_files="${_affected_files:+${_affected_files}\n}  ${_cf} → ${_imp_rel}"
                        done <<< "$_importers"
                    fi
                done <<< "$_changed_files"

                if [[ $_dep_count -gt 0 ]]; then
                    echo -e "  ${YELLOW}  影響波及ファイル: ${_dep_count}件${NC}"
                    echo -e "${_affected_files}" | head -10 | while IFS= read -r _line; do
                        [[ -n "$_line" ]] && echo -e "    ${DIM}${_line}${NC}"
                    done
                    export ICA_AFFECTED_FILE_COUNT="${_dep_count}"
                    export ICA_DEPENDENCY_GRAPH_BUILT="true"
                else
                    echo -e "  ${DIM}  影響波及なし（独立ファイル変更）${NC}"
                fi
            fi
        fi
    fi

    _post_phase_checkpoint "incremental_analysis"
    return 0
}



# ---- Phase: 品質チェック・修正 ----
# REQ-WIRE-005 (v2037): phase_quality_check の二重定義を一本化。
# 旧・詳細版(5ラウンドheal loop)はここに定義していたが、source 順序(chain.sh:264 で
# phases.sh を source → 後続の chain.sh:382 で再定義)により bash 後勝ちで常に
# chain.sh:382 版が稼働し、本詳細版は一度も実行されない死蔵だった。さらに本詳細版は
# validator 経路で project_dir="." をハードコードし呼出側 PROJECT_DIR を無視する
# 潜在バグを持つ。よって正本を chain.sh:382 (qg_run+fh_heal / PROJECT_DIR 尊重) に一本化し、
# 死蔵・バグ持ちの本定義を退役した。品質チェックの正本は chain.sh:382 を参照。



# ---- Phase 3.8: Quality Gate（品質ゲート） v20.0 ----
phase_quality_gate() {
    local session_id="$1"
    local task_desc="$2"

    if [[ "${ENABLE_QUALITY_GATE}" != "true" ]]; then
        echo -e "  ${YELLOW}⏭️ 品質ゲートスキップ (--no-quality-gate)${NC}"
        return 0
    fi

    echo -e "  ${CYAN}🏰 Phase 3.8: Quality Gate - 品質ゲート${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    local project_dir
    project_dir="$(_detect_project_dir)"

    if ! type -t qg_run_quality_gate &>/dev/null; then
        echo -e "  ${YELLOW}⚠️ Quality Gateモジュール未ロード - スキップ${NC}"
        return 0
    fi

    if qg_run_quality_gate "$project_dir" "${QUALITY_THRESHOLD:-80}"; then
        QG_SCORE=$(qg_calculate_score 2>/dev/null || echo "0")
        echo -e "  ${GREEN}✅ 品質ゲートPASS (スコア: ${QG_SCORE})${NC}"

        # v150: Live Verification - Schema↔API↔Frontend整合性検証
        if type -t lv_verify_integration &>/dev/null && [[ "${ENABLE_LIVE_VERIFICATION:-true}" == "true" ]]; then
            echo -e "  ${CYAN}🔗 [v150] Live Verification実行中...${NC}" >&2
            local _lv_result=""
            _lv_result=$(lv_verify_integration "${project_dir:-.}" 2>/dev/null || echo "")
            if [[ -n "$_lv_result" ]]; then
                local _lv_issues
                _lv_issues=$(echo "$_lv_result" | grep -c "MISMATCH\|ERROR\|INCONSIST" 2>/dev/null || echo "0")
                if [[ "$_lv_issues" -gt 0 ]]; then
                    echo -e "  ${YELLOW}⚠️ [v150] Live Verification: ${_lv_issues}件の不整合検出${NC}" >&2
                    echo "$_lv_result" | head -10 >&2
                    export LV_VERIFICATION_ISSUES="$_lv_result"
                else
                    echo -e "  ${GREEN}✅ [v150] Live Verification: 整合性OK${NC}" >&2
                fi
            fi
        fi

        # v145: Real Validator integration (PASSでもコンパイルエラーチェック)
        if type -t rv_validate_project &>/dev/null && [[ "${ENABLE_REAL_VALIDATOR:-true}" == "true" ]]; then
            echo -e "  🔍 [v145] Real Validator実行中..." >&2
            rv_init 2>/dev/null || true
            local _rv_errors=""
            _rv_errors=$(rv_validate_project "$project_dir" 2>/dev/null || echo "")
            if [[ -n "$_rv_errors" ]]; then
                echo -e "  ⚠️ [v145] Real Validator: コンパイルエラー検出" >&2
                export QG_REAL_VALIDATOR_ERRORS="$_rv_errors"
            fi
        fi

        _post_phase_checkpoint "quality_gate"
        return 0
    else
        QG_SCORE=$(qg_calculate_score 2>/dev/null || echo "0")
        echo -e "  ${YELLOW}⚠️ 品質ゲートFAIL (スコア: ${QG_SCORE}) → 機能修復へ${NC}"

        # v145: Real Validator integration (FAILの場合もコンパイルエラー収集)
        if type -t rv_validate_project &>/dev/null && [[ "${ENABLE_REAL_VALIDATOR:-true}" == "true" ]]; then
            echo -e "  🔍 [v145] Real Validator実行中..." >&2
            rv_init 2>/dev/null || true
            local _rv_errors=""
            _rv_errors=$(rv_validate_project "$project_dir" 2>/dev/null || echo "")
            if [[ -n "$_rv_errors" ]]; then
                echo -e "  ⚠️ [v145] Real Validator: コンパイルエラー検出" >&2
                export QG_REAL_VALIDATOR_ERRORS="$_rv_errors"
            fi
        fi

        # v52.0: Error Chain記録 - 品質ゲート失敗をエラーチェーンに記録
        if type -t ec_record_error &>/dev/null; then
            _warn_on_fail "ErrorChain" "record_qg_fail" ec_record_error "Quality Gate FAIL: score=${QG_SCORE}, threshold=${QUALITY_THRESHOLD:-80}" "quality_gate" "$project_dir" || true
        fi

        _post_phase_checkpoint "quality_gate"
        return 1
    fi
}



# ---- Phase 5.9: Smoke Test（スモークテスト） v20.0 ----
phase_smoke_test() {
    local session_id="$1"
    local task_desc="$2"

    if [[ "${ENABLE_SMOKE_TEST}" != "true" ]]; then
        echo -e "  ${YELLOW}⏭️ スモークテストスキップ (--no-smoke-test)${NC}"
        return 0
    fi

    # v2034.8 / PFP-055: QG高スコア (≥95) 時はSMOKEをスキップ (重複削減)
    # QG が CRUD/handlers/api を既に厳格検証済みのため、SMOKE は冗長
    # 環境変数 SOLOPTILINK_SKIP_SMOKE_IF_QG_HIGH=0 で従来動作 (常時実行)
    if [[ "${SOLOPTILINK_SKIP_SMOKE_IF_QG_HIGH:-1}" == "1" ]] && [[ -n "${QG_SCORE:-}" ]] && [[ "${QG_SCORE:-0}" -ge 95 ]]; then
        echo -e "  ${GREEN}⏭️ スモークテストスキップ (QGスコア${QG_SCORE}/100で十分検証済み - 5分節約)${NC}"
        _post_phase_checkpoint "smoke_test_skipped_qg_high"
        return 0
    fi

    echo -e "  ${CYAN}🧪 Phase 5.9: Smoke Test - スモークテスト${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    local project_dir
    project_dir="$(_detect_project_dir)"

    if ! type -t str_run_smoke_tests &>/dev/null; then
        echo -e "  ${YELLOW}⚠️ Smoke Test Runnerモジュール未ロード - スキップ${NC}"
        return 0
    fi

    # v2034.6: Strict gate (default ON). SOLAI_STRICT_GATE=false で従来動作
    # 100%完成宣言を構造的に保証するため smoke FAIL を fatal 化.
    local strict_gate="${SOLAI_STRICT_GATE:-true}"

    if str_run_smoke_tests "$project_dir"; then
        echo -e "  ${GREEN}✅ スモークテストPASS${NC}"
        _post_phase_checkpoint "smoke_test"
        return 0
    fi

    if [[ "$strict_gate" == "true" ]]; then
        echo -e "  ${RED}❌ スモークテストFAIL - Strict Gateにより完成宣言を停止${NC}"
        echo -e "  ${YELLOW}復旧: 検出された欠陥を修正するか、SOLAI_STRICT_GATE=false で従来動作に戻せます${NC}"
        _post_phase_checkpoint "smoke_test_failed"
        return 1
    fi

    echo -e "  ${YELLOW}⚠️ スモークテスト一部FAIL - SOLAI_STRICT_GATE=false により非致命扱い${NC}"
    _post_phase_checkpoint "smoke_test"
    return 0
}



# ---- Phase: Follow-up用プロンプトコンパイル (v28.0) ----
phase_targeted_compile() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "targeted_compile" 2>/dev/null || true

    if ! type -t trc_init &>/dev/null; then
        echo -e "  ${YELLOW}targeted-compiler.sh 未ロード → スキップ${NC}"
        return 0
    fi

    echo -e "\n${BOLD}${CYAN}[v28.0] Targeted Compiler - Follow-upプロンプトコンパイル${NC}"

    trc_init "$session_id"

    local compiled_prompt
    compiled_prompt=$(trc_compile_followup_prompt "$task_desc" "${FUC_GENOME_JSON:-}" "${ICA_CHANGE_PLAN:-}" "${FUC_REQUEST_TYPE:-modification}" 2>/dev/null || echo "")

    if [[ -n "$compiled_prompt" ]]; then
        TRC_COMPILED_PROMPT="$compiled_prompt"
        echo -e "  ${GREEN}コンパイル完了: ${TRC_PROMPT_CHARS} chars${NC}"
    fi

    _post_phase_checkpoint "targeted_compile"
    return 0
}



# ---- Phase: テスト実装・実行 ----
phase_testing() {
    local session_id="$1"
    local task_desc="$2"
    pe_set_phase "testing" 2>/dev/null || true

    echo -e "  ${CYAN}🧪 テスト実装・実行フェーズ${NC}"
    echo -e "  経過時間: $(_elapsed_time)"

    # QAエンジンが使用可能なら網羅的テスト
    if type -t qa_init &>/dev/null; then
        echo -e "  ${BOLD}網羅的QAテスト実行中...${NC}"
        qa_init "." 2>/dev/null || true
        if type -t qa_run_exhaustive &>/dev/null; then
            qa_run_exhaustive "." 2>/dev/null || true
        fi
    fi

    # v2003.1: Layer 29 DevOps Testing - AI-Poweredテスト自動生成
    local _test_project_dir
    _test_project_dir="$(_detect_project_dir 2>/dev/null || echo ".")"

    # ユニットテスト自動生成
    if type -t _utg_generate_tests &>/dev/null; then
        echo -e "  ${CYAN}🧪 [v2003.1] AI-Poweredユニットテスト生成中...${NC}"
        _utg_generate_tests "$_test_project_dir" 2>/dev/null || true
    fi

    # E2Eテスト自動生成
    if type -t _etg_generate_playwright &>/dev/null; then
        echo -e "  ${CYAN}🧪 [v2003.1] Playwrightテスト生成中...${NC}"
        _etg_generate_playwright "$_test_project_dir" 2>/dev/null || true
    fi

    # Claude CLIでテストファイル生成
    local req_content=""
    [[ -n "${REQUIREMENTS_FILE:-}" && -f "$REQUIREMENTS_FILE" ]] && req_content="$(cat "$REQUIREMENTS_FILE")"

    local prompt="あなたはQAエンジニアです。以下のプロジェクトのテストを作成・実行してください。

タスク: ${task_desc}

要件:
${req_content:-（なし）}

以下を作成してください:
1. ユニットテスト（全関数・コンポーネント）
2. 統合テスト（API + DB）
3. E2Eテスト（主要ユーザーフロー）
4. エッジケーステスト

テストフレームワーク: Jest/Vitest (Node), pytest (Python)
全テストファイルをプロジェクトに書き出し、テストを実行してください。"

    local output_file="${SESSION_LOG_DIR}/testing_results.md"
    if _call_claude "$prompt" "$output_file"; then
        echo -e "  ${GREEN}✅ テスト作成・実行完了${NC}"
        _write_claude_output_to_files "$output_file"
    else
        echo -e "  ${RED}❌ テスト作成失敗${NC}"
    fi

    [[ "$NO_LEARN" != "1" ]] && type -t rt_capture_success &>/dev/null && \
        rt_capture_success "TEST" "testing" "テスト実行完了"

    _post_phase_checkpoint "testing"
    return 0
}

# v172: Module Registry self-registration
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "phases-quality" \
        --version "120.0" \
        --description "品質フェーズ実行（コードスキャン/品質ゲート/スモークテスト/テスト）"
fi

# v2003.1: source時のexit codeを確実に0にする
true
