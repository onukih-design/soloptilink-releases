#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v445.0 - Horizontal Scaling Engine
# =============================================================================
# 水平スケーリング対応。ステートレス化、セッションストア外部化、
# ロードバランサ設定生成を行う。
#
# Functions:
#   _hs_init()                    - 初期化
#   _hs_make_stateless()          - ステートレス化分析
#   _hs_setup_session_store()     - セッションストア設定
#   _hs_generate_lb_config()      - LB設定生成
#   _hs_report() / _hs_score()
#
# All globals use the HS_ prefix.
# =============================================================================

[[ -n "${_HS_LOADED:-}" ]] && return 0; _HS_LOADED=1

declare -g HS_VERSION="445.0"
declare -g HS_GENERATED=0
declare -g HS_ERRORS=0
declare -g HS_STATEFUL_PATTERNS=0
declare -g HS_SESSION_STORE=""
declare -g HS_LB_CONFIGURED=false
declare -g HS_SCALING_READY=false

declare -ga _HS_FINDINGS=()

_HS_GREEN="${GREEN:-\033[0;32m}"
_HS_YELLOW="${YELLOW:-\033[0;33m}"
_HS_CYAN="${CYAN:-\033[0;36m}"
_HS_BOLD="${BOLD:-\033[1m}"
_HS_NC="${NC:-\033[0m}"

_hs_init() {
    HS_GENERATED=0; HS_ERRORS=0; HS_STATEFUL_PATTERNS=0
    HS_SESSION_STORE=""; HS_LB_CONFIGURED=false; HS_SCALING_READY=false
    _HS_FINDINGS=()
    return 0
}

_hs_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_HS_CYAN}[HS]${_HS_NC} $*" >&2 ;;
        ok)    echo -e "  ${_HS_GREEN}[HS]${_HS_NC} $*" >&2 ;;
        warn)  echo -e "  ${_HS_YELLOW}[HS]${_HS_NC} $*" >&2 ;;
        *)     echo -e "  ${_HS_CYAN}[HS]${_HS_NC} $*" >&2 ;;
    esac
}

_hs_make_stateless() {
    local project_dir="${1:-.}"
    _hs_log info "ステートレス化分析"

    HS_STATEFUL_PATTERNS=0

    while IFS= read -r -d '' file; do
        local rel="${file#${project_dir}/}"

        # インメモリキャッシュ（Mapやglobal変数）
        local in_memory
        in_memory=$(grep -c "new Map()\|global\.\|globalThis\." "$file" 2>/dev/null || echo 0)
        if [[ $in_memory -gt 2 ]]; then
            HS_STATEFUL_PATTERNS=$((HS_STATEFUL_PATTERNS + 1))
            _HS_FINDINGS+=("STATEFUL_CACHE:${rel}:in-memory state - use Redis/external store")
        fi

        # ファイルシステム依存
        local fs_usage
        fs_usage=$(grep -c "fs\.\|writeFileSync\|readFileSync\|createWriteStream" "$file" 2>/dev/null || echo 0)
        if [[ $fs_usage -gt 2 ]]; then
            HS_STATEFUL_PATTERNS=$((HS_STATEFUL_PATTERNS + 1))
            _HS_FINDINGS+=("FS_DEPENDENCY:${rel}:filesystem access - use S3/R2 for multi-instance")
        fi

        # ローカルセッション
        local local_session
        local_session=$(grep -c "express-session.*MemoryStore\|session.*memory" "$file" 2>/dev/null || echo 0)
        if [[ $local_session -gt 0 ]]; then
            HS_STATEFUL_PATTERNS=$((HS_STATEFUL_PATTERNS + 1))
            _HS_FINDINGS+=("LOCAL_SESSION:${rel}:MemoryStore session - use Redis session store")
        fi
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.js" \) \
             -not -path "*/node_modules/*" -not -path "*/.next/*" -print0 2>/dev/null)

    HS_SCALING_READY=$([[ $HS_STATEFUL_PATTERNS -eq 0 ]] && echo true || echo false)
    HS_GENERATED=$((HS_GENERATED + 1))
    _hs_log ok "ステートフルパターン: ${HS_STATEFUL_PATTERNS}件 (ready=${HS_SCALING_READY})"
    return 0
}

_hs_setup_session_store() {
    local project_dir="${1:-.}"
    _hs_log info "セッションストア設定"

    HS_SESSION_STORE=""
    local pkg="${project_dir}/package.json"
    if [[ -f "$pkg" ]]; then
        if grep -q "connect-redis\|ioredis" "$pkg" 2>/dev/null; then
            HS_SESSION_STORE="redis"
        elif grep -q "connect-pg-simple" "$pkg" 2>/dev/null; then
            HS_SESSION_STORE="postgresql"
        elif grep -q "connect-mongo" "$pkg" 2>/dev/null; then
            HS_SESSION_STORE="mongodb"
        fi
    fi

    if [[ -z "$HS_SESSION_STORE" ]]; then
        _HS_FINDINGS+=("SESSION_STORE:no external session store detected - use Redis for scaling")
        HS_SESSION_STORE="none"
    fi

    # JWT使用チェック（ステートレス認証）
    local jwt_count=0
    while IFS= read -r -d '' file; do
        local count
        count=$(grep -c "jsonwebtoken\|jose\|jwt\|JWT" "$file" 2>/dev/null || echo 0)
        jwt_count=$((jwt_count + count))
    done < <(find "$project_dir" \( -name "*.ts" -o -name "*.js" \) \
             -not -path "*/node_modules/*" -print0 2>/dev/null)

    if [[ $jwt_count -gt 0 ]]; then
        _hs_log ok "JWT認証検出: ステートレス認証で水平スケーリング対応"
    fi

    HS_GENERATED=$((HS_GENERATED + 1))
    _hs_log ok "セッションストア: ${HS_SESSION_STORE}"
    return 0
}

_hs_generate_lb_config() {
    local project_dir="${1:-.}"
    _hs_log info "ロードバランサ設定生成"

    local has_docker
    has_docker=$([[ -f "${project_dir}/Dockerfile" ]] && echo true || echo false)
    local has_k8s
    has_k8s=$([[ -d "${project_dir}/k8s" ]] || [[ -f "${project_dir}/kubernetes.yaml" ]] && echo true || echo false)

    if [[ "$has_docker" == "true" ]]; then
        _HS_FINDINGS+=("DOCKER_REPLICAS:docker-compose: deploy.replicas: 3 for horizontal scaling")
    fi

    if [[ "$has_k8s" == "true" ]]; then
        _HS_FINDINGS+=("K8S_HPA:configure HorizontalPodAutoscaler for auto-scaling")
    fi

    _HS_FINDINGS+=("HEALTH_CHECK:implement /api/health endpoint for LB health checks")
    _HS_FINDINGS+=("GRACEFUL_SHUTDOWN:implement SIGTERM handler for graceful shutdown")
    _HS_FINDINGS+=("STICKY_SESSIONS:avoid sticky sessions - use stateless design")

    HS_LB_CONFIGURED=true
    HS_GENERATED=$((HS_GENERATED + 1))
    _hs_log ok "LB設定推奨完了"
    return 0
}

_hs_report() {
    echo -e "\n  ${_HS_BOLD}=== horizontal-scaling v${HS_VERSION} ===${_HS_NC}"
    echo -e "  ステートフル    : ${HS_STATEFUL_PATTERNS}パターン"
    echo -e "  セッションストア: ${HS_SESSION_STORE:-none}"
    echo -e "  LB設定          : ${HS_LB_CONFIGURED}"
    echo -e "  スケーリング対応: ${HS_SCALING_READY}"
    echo -e "  エラー          : ${HS_ERRORS}"
}

_hs_score() {
    local score=50
    [[ "$HS_SCALING_READY" == "true" ]] && score=$((score + 20))
    [[ "$HS_SESSION_STORE" != "none" ]] && [[ -n "$HS_SESSION_STORE" ]] && score=$((score + 15))
    [[ "$HS_LB_CONFIGURED" == "true" ]] && score=$((score + 10))
    [[ ${HS_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "horizontal-scaling" --version "${HS_VERSION}" \
        --description "水平スケーリング×ステートレス化×セッション外部化×LB設定 (v445)" \
        --init "_hs_init" --report "_hs_report" --score "_hs_score" \
        --enable-var "ENABLE_H_SCALING" --cli-flags "--h-scaling:--no-h-scaling"
fi

# v2003.1: source時のexit codeを確実に0にする
true
