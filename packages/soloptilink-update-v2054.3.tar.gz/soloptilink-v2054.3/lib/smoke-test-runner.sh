#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v20.0 - Smoke Test Runner (スモークテストランナー)
# =============================================================================
# 実際にサーバーを起動してCRUDが動くか自動検証する
#
# テスト項目:
#   1. サーバー起動テスト
#   2. CRUD往復テスト (POST → GET → PUT → GET → DELETE → GET 404)
#   3. データ永続性テスト
#   4. レスポンス構造検証
#
# 使用方法:
#   source lib/smoke-test-runner.sh
#   str_run_smoke_tests "/path/to/project"
# =============================================================================

[[ -n "${_SMOKE_TEST_RUNNER_LOADED:-}" ]] && return 0
_SMOKE_TEST_RUNNER_LOADED=1

# ============================================================
# Constants
# ============================================================
STR_VERSION="20.0"
STR_SERVER_TIMEOUT=30
STR_REQUEST_TIMEOUT=10
STR_DEFAULT_PORT=3000
STR_HEALTH_RETRIES=15
STR_HEALTH_INTERVAL=2

# ============================================================
# Internal state
# ============================================================
_STR_SERVER_PID=""
_STR_SERVER_PORT=""
_STR_BASE_URL=""
_STR_LOG_DIR=""
_STR_PASS_COUNT=0
_STR_FAIL_COUNT=0
_STR_SKIP_COUNT=0
_STR_RESULTS=()

# ============================================================
# Logging
# ============================================================
_str_log() {
    local level="$1" msg="$2"
    local timestamp
    timestamp="$(date '+%Y-%m-%d %H:%M:%S')"
    echo -e "  [SmokeTest][${level}] ${msg}" >&2
    if [[ -n "${_STR_LOG_DIR}" ]]; then
        echo "[${timestamp}][STR][${level}] ${msg}" >> "${_STR_LOG_DIR}/smoke_test.log" 2>/dev/null || true
    fi
}

# ============================================================
# Test result recording
# ============================================================
_str_record() {
    local test_name="$1" status="$2" detail="${3:-}"

    case "$status" in
        PASS) _STR_PASS_COUNT=$((_STR_PASS_COUNT + 1)) ;;
        FAIL) _STR_FAIL_COUNT=$((_STR_FAIL_COUNT + 1)) ;;
        SKIP) _STR_SKIP_COUNT=$((_STR_SKIP_COUNT + 1)) ;;
    esac

    _STR_RESULTS+=("${status}: ${test_name}${detail:+ - ${detail}}")
    _str_log "${status}" "${test_name}${detail:+ - ${detail}}"
}

# ============================================================
# Detect project type and start command
# ============================================================
_str_detect_start_command() {
    local project_dir="$1"

    # Next.js
    if [[ -f "${project_dir}/next.config.js" ]] || [[ -f "${project_dir}/next.config.mjs" ]] || [[ -f "${project_dir}/next.config.ts" ]]; then
        if grep -q '"dev"' "${project_dir}/package.json" 2>/dev/null; then
            echo "npm run dev"
            return 0
        fi
    fi

    # Node.js (package.json with dev/start script)
    if [[ -f "${project_dir}/package.json" ]]; then
        if grep -q '"dev"' "${project_dir}/package.json" 2>/dev/null; then
            echo "npm run dev"
            return 0
        elif grep -q '"start"' "${project_dir}/package.json" 2>/dev/null; then
            echo "npm start"
            return 0
        fi
    fi

    # Python Flask
    if [[ -f "${project_dir}/app.py" ]]; then
        if grep -qE '(Flask|flask)' "${project_dir}/app.py" 2>/dev/null; then
            echo "python app.py"
            return 0
        fi
    fi

    # Python FastAPI
    if [[ -f "${project_dir}/main.py" ]]; then
        if grep -qE '(FastAPI|fastapi)' "${project_dir}/main.py" 2>/dev/null; then
            echo "uvicorn main:app --host 0.0.0.0 --port 3000"
            return 0
        fi
    fi

    # Swift Package Manager
    if [[ -f "${project_dir}/Package.swift" ]]; then
        echo "swift run"
        return 0
    fi

    # Fallback: Try to detect any runnable
    if [[ -f "${project_dir}/server.js" ]] || [[ -f "${project_dir}/server.ts" ]]; then
        echo "node server.js"
        return 0
    fi

    return 1
}

# ============================================================
# Detect server port
# ============================================================
_str_detect_port() {
    local project_dir="$1"

    # Check package.json scripts for port
    if [[ -f "${project_dir}/package.json" ]]; then
        local port
        port=$(grep -oE 'PORT[=:]\s*[0-9]+' "${project_dir}/package.json" 2>/dev/null | grep -oE '[0-9]+' | head -1)
        [[ -n "$port" ]] && { echo "$port"; return 0; }
    fi

    # Check .env for PORT
    if [[ -f "${project_dir}/.env" ]]; then
        local port
        port=$(grep -oE '^PORT\s*=\s*[0-9]+' "${project_dir}/.env" 2>/dev/null | grep -oE '[0-9]+' | head -1)
        [[ -n "$port" ]] && { echo "$port"; return 0; }
    fi

    # Check source files for port number
    local port
    port=$(grep -rhoE 'listen\s*\(\s*[0-9]+' "$project_dir" --include="*.js" --include="*.ts" 2>/dev/null | grep -oE '[0-9]+' | head -1)
    [[ -n "$port" ]] && { echo "$port"; return 0; }

    echo "$STR_DEFAULT_PORT"
}

# ============================================================
# Detect API endpoints
# ============================================================
_str_detect_api_endpoints() {
    local project_dir="$1"
    local -a endpoints=()

    # Look for Express/Fastify routes
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        # Extract route paths
        while IFS= read -r route; do
            [[ -n "$route" ]] && endpoints+=("$route")
        done < <(grep -oE "(router|app)\.(get|post|put|patch|delete)\s*\(\s*['\"][^'\"]+['\"]" "$file" 2>/dev/null | \
            grep -oE "['\"][^'\"]+['\"]" | tr -d "'" | tr -d '"')
    done < <(find "$project_dir" -type f \( -name "*.js" -o -name "*.ts" \) \
        \( -path "*/routes/*" -o -path "*/api/*" -o -name "server.*" -o -name "app.*" \) \
        -not -path "*/node_modules/*" 2>/dev/null)

    # Look for Next.js App Router API routes (app/api/*/route.ts)
    if [[ -d "${project_dir}/app/api" ]] || [[ -d "${project_dir}/src/app/api" ]]; then
        local api_base="${project_dir}/app/api"
        [[ -d "${project_dir}/src/app/api" ]] && api_base="${project_dir}/src/app/api"

        while IFS= read -r route_file; do
            local rel="${route_file#${api_base}}"
            rel="/api${rel%/route.*}"
            endpoints+=("$rel")
        done < <(find "$api_base" -name "route.*" 2>/dev/null)
    fi

    # Look for Next.js Pages Router API routes (pages/api/*.ts)
    if [[ -d "${project_dir}/pages/api" ]] || [[ -d "${project_dir}/src/pages/api" ]]; then
        local pages_api_base="${project_dir}/pages/api"
        [[ -d "${project_dir}/src/pages/api" ]] && pages_api_base="${project_dir}/src/pages/api"

        while IFS= read -r api_file; do
            local rel="${api_file#${pages_api_base}}"
            # Remove file extension and index
            rel="/api${rel%.*}"
            rel="${rel%/index}"
            # Skip _middleware files
            [[ "$rel" == *"_middleware"* ]] && continue
            endpoints+=("$rel")
        done < <(find "$pages_api_base" -type f \( -name "*.ts" -o -name "*.js" \) \
            -not -name "_*" 2>/dev/null)
    fi

    # Deduplicate and output
    printf '%s\n' "${endpoints[@]}" | sort -u
}

# ============================================================
# Start the dev server
# ============================================================
str_start_server() {
    local project_dir="$1"

    _str_log "INFO" "サーバー起動テスト..."

    # Detect start command
    local start_cmd
    start_cmd=$(_str_detect_start_command "$project_dir") || {
        _str_record "サーバー起動" "SKIP" "起動コマンド検出不可"
        return 1
    }

    # Detect port
    _STR_SERVER_PORT=$(_str_detect_port "$project_dir")
    _STR_BASE_URL="http://localhost:${_STR_SERVER_PORT}"

    _str_log "INFO" "起動コマンド: ${start_cmd}"
    _str_log "INFO" "ポート: ${_STR_SERVER_PORT}"

    # Check if port is already in use
    if command -v lsof &>/dev/null && lsof -i ":${_STR_SERVER_PORT}" &>/dev/null; then
        _str_log "WARN" "ポート${_STR_SERVER_PORT}は既に使用中"
        # Try to use existing server
        if curl -s --max-time 3 "${_STR_BASE_URL}" &>/dev/null || \
           curl -s --max-time 3 "${_STR_BASE_URL}/api" &>/dev/null; then
            _str_record "サーバー起動" "PASS" "既存サーバー利用 (port ${_STR_SERVER_PORT})"
            return 0
        fi
    fi

    # Run DB setup if needed (Prisma)
    if [[ -f "${project_dir}/prisma/schema.prisma" ]]; then
        _str_log "INFO" "Prisma DB セットアップ中..."
        (cd "$project_dir" && npx prisma db push --accept-data-loss 2>/dev/null) || true
        (cd "$project_dir" && npx prisma generate 2>/dev/null) || true
    fi

    # Start server in background
    (cd "$project_dir" && $start_cmd > "${_STR_LOG_DIR}/server_stdout.log" 2> "${_STR_LOG_DIR}/server_stderr.log") &
    _STR_SERVER_PID=$!

    _str_log "INFO" "サーバー起動中... (PID: ${_STR_SERVER_PID})"

    # Wait for health check
    local retries=0
    while [[ $retries -lt $STR_HEALTH_RETRIES ]]; do
        retries=$((retries + 1))
        sleep $STR_HEALTH_INTERVAL

        # Check if process is still running
        if ! kill -0 "$_STR_SERVER_PID" 2>/dev/null; then
            _str_record "サーバー起動" "FAIL" "サーバープロセスが終了 (PID: ${_STR_SERVER_PID})"
            _str_log "ERROR" "stderr: $(tail -5 "${_STR_LOG_DIR}/server_stderr.log" 2>/dev/null)"
            return 1
        fi

        # Health check
        if curl -s --max-time 3 "${_STR_BASE_URL}" &>/dev/null || \
           curl -s --max-time 3 "${_STR_BASE_URL}/api" &>/dev/null || \
           curl -s --max-time 3 "${_STR_BASE_URL}/api/health" &>/dev/null; then
            _str_record "サーバー起動" "PASS" "port ${_STR_SERVER_PORT}, ${retries}回目で応答"
            return 0
        fi

        _str_log "INFO" "ヘルスチェック待機中... (${retries}/${STR_HEALTH_RETRIES})"
    done

    _str_record "サーバー起動" "FAIL" "${STR_HEALTH_RETRIES}回のヘルスチェック全て失敗"
    return 1
}

# ============================================================
# Stop the dev server
# ============================================================
str_stop_server() {
    if [[ -n "$_STR_SERVER_PID" ]]; then
        kill "$_STR_SERVER_PID" 2>/dev/null || true
        wait "$_STR_SERVER_PID" 2>/dev/null || true
        _str_log "INFO" "サーバー停止 (PID: ${_STR_SERVER_PID})"
        _STR_SERVER_PID=""
    fi

    # Kill any process on the port
    if [[ -n "${_STR_SERVER_PORT}" ]] && command -v lsof &>/dev/null; then
        local port_pid
        port_pid=$(lsof -ti ":${_STR_SERVER_PORT}" 2>/dev/null | head -1)
        if [[ -n "$port_pid" ]]; then
            kill "$port_pid" 2>/dev/null || true
        fi
    fi
}

# ============================================================
# HTTP request helper
# ============================================================
_str_http() {
    local method="$1" url="$2" data="${3:-}"
    local response_file="${_STR_LOG_DIR}/http_response_$$.txt"
    local header_file="${_STR_LOG_DIR}/http_headers_$$.txt"

    local -a curl_args=(
        -s
        --max-time "$STR_REQUEST_TIMEOUT"
        -w "\n%{http_code}"
        -D "$header_file"
        -X "$method"
        -H "Content-Type: application/json"
        -H "Accept: application/json"
    )

    [[ -n "$data" ]] && curl_args+=(-d "$data")
    curl_args+=("$url")

    local output
    output=$(curl "${curl_args[@]}" 2>/dev/null) || {
        echo "000"
        return 1
    }

    # Extract status code (last line added by -w "\n%{http_code}")
    # The status code is always a 3-digit number on the last line
    local status_code
    status_code=$(echo "$output" | grep -oE '^[0-9]{3}$' | tail -1)
    if [[ -z "$status_code" ]]; then
        # Fallback: get last line
        status_code=$(echo "$output" | tail -1 | grep -oE '[0-9]{3}' | head -1)
    fi
    [[ -z "$status_code" ]] && status_code="000"
    local body
    # Remove the last line (status code) from output
    body=$(echo "$output" | sed '$d')

    echo "${status_code}|${body}"
    rm -f "$response_file" "$header_file" 2>/dev/null
}

# ============================================================
# CRUD Roundtrip Test
# ============================================================
str_test_crud_roundtrip() {
    local base_url="$1"
    local endpoint="$2"
    local test_data="${3:-{\"name\": \"SmokeTest Item\", \"description\": \"Created by v20.0 Smoke Test\"}}"

    local url="${base_url}${endpoint}"
    _str_log "INFO" "CRUD往復テスト: ${endpoint}"

    local created_id=""

    # 1. CREATE (POST)
    local create_response
    create_response=$(_str_http "POST" "$url" "$test_data")
    local create_status="${create_response%%|*}"
    local create_body="${create_response#*|}"

    if [[ "$create_status" =~ ^2[0-9][0-9]$ ]]; then
        # Extract ID from response (supports numeric, UUID, and string IDs)
        # Try UUID pattern first (e.g., "id": "550e8400-e29b-41d4-a716-446655440000")
        created_id=$(echo "$create_body" | grep -oE '"id"\s*:\s*"[0-9a-fA-F-]{36}"' | head -1 | grep -oE '[0-9a-fA-F-]{36}')
        if [[ -z "$created_id" ]]; then
            # Try numeric ID (e.g., "id": 123)
            created_id=$(echo "$create_body" | grep -oE '"id"\s*:\s*[0-9]+' | head -1 | grep -oE '[0-9]+')
        fi
        if [[ -z "$created_id" ]]; then
            # Try string ID (e.g., "id": "abc123")
            created_id=$(echo "$create_body" | grep -oE '"id"\s*:\s*"[^"]*"' | head -1 | sed 's/.*"id"\s*:\s*"//;s/".*//')
        fi
        _str_record "CREATE ${endpoint}" "PASS" "status=${create_status}, id=${created_id:-unknown}"
    else
        _str_record "CREATE ${endpoint}" "FAIL" "status=${create_status}, body=${create_body:0:200}"
        return 1
    fi

    # 2. READ (GET by ID)
    if [[ -n "$created_id" ]]; then
        local read_response
        read_response=$(_str_http "GET" "${url}/${created_id}")
        local read_status="${read_response%%|*}"
        local read_body="${read_response#*|}"

        if [[ "$read_status" =~ ^2[0-9][0-9]$ ]]; then
            _str_record "READ ${endpoint}/${created_id}" "PASS" "status=${read_status}"
        else
            _str_record "READ ${endpoint}/${created_id}" "FAIL" "status=${read_status}"
        fi
    fi

    # 3. READ ALL (GET list)
    local list_response
    list_response=$(_str_http "GET" "$url")
    local list_status="${list_response%%|*}"

    if [[ "$list_status" =~ ^2[0-9][0-9]$ ]]; then
        _str_record "READ LIST ${endpoint}" "PASS" "status=${list_status}"
    else
        _str_record "READ LIST ${endpoint}" "FAIL" "status=${list_status}"
    fi

    # 4. UPDATE (PUT)
    if [[ -n "$created_id" ]]; then
        local update_data='{"name": "Updated SmokeTest Item", "description": "Updated by v20.0"}'
        local update_response
        update_response=$(_str_http "PUT" "${url}/${created_id}" "$update_data")
        local update_status="${update_response%%|*}"

        if [[ "$update_status" =~ ^2[0-9][0-9]$ ]]; then
            _str_record "UPDATE ${endpoint}/${created_id}" "PASS" "status=${update_status}"

            # Verify update was applied
            local verify_response
            verify_response=$(_str_http "GET" "${url}/${created_id}")
            local verify_body="${verify_response#*|}"

            if echo "$verify_body" | grep -q "Updated SmokeTest" 2>/dev/null; then
                _str_record "UPDATE VERIFY ${endpoint}" "PASS" "更新データ確認済"
            else
                _str_record "UPDATE VERIFY ${endpoint}" "FAIL" "更新が反映されていない"
            fi
        else
            _str_record "UPDATE ${endpoint}/${created_id}" "FAIL" "status=${update_status}"
        fi
    fi

    # 5. DELETE
    if [[ -n "$created_id" ]]; then
        local delete_response
        delete_response=$(_str_http "DELETE" "${url}/${created_id}")
        local delete_status="${delete_response%%|*}"

        if [[ "$delete_status" =~ ^2[0-9][0-9]$ ]]; then
            _str_record "DELETE ${endpoint}/${created_id}" "PASS" "status=${delete_status}"

            # Verify deletion
            local gone_response
            gone_response=$(_str_http "GET" "${url}/${created_id}")
            local gone_status="${gone_response%%|*}"

            if [[ "$gone_status" == "404" ]] || [[ "$gone_status" == "410" ]]; then
                _str_record "DELETE VERIFY ${endpoint}" "PASS" "削除後404確認済"
            else
                _str_record "DELETE VERIFY ${endpoint}" "FAIL" "削除後もstatus=${gone_status}（404期待）"
            fi
        else
            _str_record "DELETE ${endpoint}/${created_id}" "FAIL" "status=${delete_status}"
        fi
    fi

    return 0
}

# ============================================================
# Display Smoke Test Results
# ============================================================
_str_display_results() {
    local RED='\033[0;31m'
    local GREEN='\033[0;32m'
    local YELLOW='\033[1;33m'
    local CYAN='\033[0;36m'
    local BOLD='\033[1m'
    local NC='\033[0m'

    local total=$((_STR_PASS_COUNT + _STR_FAIL_COUNT + _STR_SKIP_COUNT))

    echo ""
    echo -e "${BOLD}╔═══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}║        Smoke Test Runner v${STR_VERSION} - テスト結果             ║${NC}"
    echo -e "${BOLD}╠═══════════════════════════════════════════════════════════╣${NC}"

    printf "║  ${GREEN}PASS: %3d${NC}  ${RED}FAIL: %3d${NC}  ${YELLOW}SKIP: %3d${NC}  Total: %3d      ║\n" \
        "$_STR_PASS_COUNT" "$_STR_FAIL_COUNT" "$_STR_SKIP_COUNT" "$total"

    echo -e "${BOLD}╠───────────────────────────────────────────────────────────╣${NC}"

    for result in "${_STR_RESULTS[@]}"; do
        local color="$NC"
        case "${result%%:*}" in
            PASS) color="$GREEN" ;;
            FAIL) color="$RED" ;;
            SKIP) color="$YELLOW" ;;
        esac
        local display="${result:0:57}"
        printf "║  ${color}%-57s${NC}║\n" "$display"
    done

    echo -e "${BOLD}╚═══════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# ============================================================
# Generate smoke test report
# ============================================================
str_generate_report() {
    local report_file="${_STR_LOG_DIR}/smoke_test_report.json"

    local results_json="["
    local first=1
    for result in "${_STR_RESULTS[@]}"; do
        [[ $first -eq 0 ]] && results_json+=","
        first=0
        local escaped
        escaped=$(echo "$result" | sed 's/"/\\"/g')
        results_json+="\"${escaped}\""
    done
    results_json+="]"

    cat > "$report_file" <<EOF
{
    "version": "${STR_VERSION}",
    "timestamp": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')",
    "pass": ${_STR_PASS_COUNT},
    "fail": ${_STR_FAIL_COUNT},
    "skip": ${_STR_SKIP_COUNT},
    "total": $((_STR_PASS_COUNT + _STR_FAIL_COUNT + _STR_SKIP_COUNT)),
    "results": ${results_json}
}
EOF

    echo "$report_file"
}

# ============================================================
# Main Entry Point
# ============================================================
str_run_smoke_tests() {
    local project_dir="${1:-.}"

    # Reset state
    _STR_PASS_COUNT=0
    _STR_FAIL_COUNT=0
    _STR_SKIP_COUNT=0
    _STR_RESULTS=()
    _STR_LOG_DIR="${SESSION_LOG_DIR:-/tmp}/smoke_tests"
    mkdir -p "${_STR_LOG_DIR}" 2>/dev/null

    _str_log "INFO" "═══ Smoke Test Runner v${STR_VERSION} 開始 ═══"
    _str_log "INFO" "プロジェクト: ${project_dir}"

    # iOS/Swift project detection: use dedicated iOS smoke test path
    if [[ -f "${project_dir}/Package.swift" ]] || find "$project_dir" -name "*.xcodeproj" -maxdepth 2 2>/dev/null | grep -q . || find "$project_dir" -name "*.xcworkspace" -maxdepth 2 2>/dev/null | grep -q .; then
        _str_log "INFO" "iOS/Swiftプロジェクトを検出 - iOSスモークテストを実行"
        _str_ios_smoke_test "$project_dir"
        local ios_rc=$?
        _str_display_results
        str_generate_report > /dev/null
        if type -t obs_record_event &>/dev/null; then
            obs_record_event "SMOKE_TEST" "{\"pass\": ${_STR_PASS_COUNT}, \"fail\": ${_STR_FAIL_COUNT}, \"skip\": ${_STR_SKIP_COUNT}, \"type\": \"ios\"}"
        fi
        _str_log "INFO" "═══ iOS Smoke Test 完了: PASS=${_STR_PASS_COUNT}, FAIL=${_STR_FAIL_COUNT} ═══"
        [[ $_STR_FAIL_COUNT -eq 0 ]] && return 0 || return 1
    fi

    # Ensure curl is available
    if ! command -v curl &>/dev/null; then
        _str_log "ERROR" "curlコマンドが見つかりません"
        _str_record "前提条件" "FAIL" "curl未インストール"
        _str_display_results
        return 1
    fi

    # Start server
    if ! str_start_server "$project_dir"; then
        _str_log "WARN" "サーバー起動失敗 - HTTPテストをスキップ"
        _str_display_results
        str_generate_report > /dev/null
        return 1
    fi

    # Detect API endpoints
    local -a endpoints=()
    while IFS= read -r ep; do
        [[ -n "$ep" ]] && endpoints+=("$ep")
    done < <(_str_detect_api_endpoints "$project_dir")

    if [[ ${#endpoints[@]} -eq 0 ]]; then
        _str_log "WARN" "APIエンドポイント検出不可 - 一般的なパスを試行"
        endpoints=("/api/items" "/api/users" "/api/posts" "/api/tasks" "/api/products")
    fi

    _str_log "INFO" "検出エンドポイント: ${endpoints[*]}"

    # Run CRUD tests on detected endpoints
    local tested=0
    for endpoint in "${endpoints[@]}"; do
        # Quick check if endpoint exists
        local check_response
        check_response=$(_str_http "GET" "${_STR_BASE_URL}${endpoint}")
        local check_status="${check_response%%|*}"

        if [[ "$check_status" =~ ^[2-4][0-9][0-9]$ ]] && [[ "$check_status" != "000" ]]; then
            str_test_crud_roundtrip "${_STR_BASE_URL}" "$endpoint"
            tested=$((tested + 1))
        else
            _str_log "INFO" "エンドポイント ${endpoint} は存在しない (status=${check_status}) - スキップ"
        fi

        [[ $tested -ge 3 ]] && break  # Test up to 3 endpoints
    done

    if [[ $tested -eq 0 ]]; then
        _str_record "エンドポイント検出" "FAIL" "有効なAPIエンドポイントが見つからない"
    fi

    # Stop server
    str_stop_server

    # Display results
    _str_display_results

    # Generate report
    str_generate_report > /dev/null

    # Record observatory event
    if type -t obs_record_event &>/dev/null; then
        obs_record_event "SMOKE_TEST" "{\"pass\": ${_STR_PASS_COUNT}, \"fail\": ${_STR_FAIL_COUNT}, \"skip\": ${_STR_SKIP_COUNT}}"
    fi

    _str_log "INFO" "═══ Smoke Test 完了: PASS=${_STR_PASS_COUNT}, FAIL=${_STR_FAIL_COUNT} ═══"

    # Return based on failures
    [[ $_STR_FAIL_COUNT -eq 0 ]] && return 0 || return 1
}

# ============================================================
# iOS/Swift Smoke Test
# ============================================================
_str_ios_smoke_test() {
    local project_dir="$1"

    _str_log "INFO" "iOS/Swiftスモークテスト開始..."

    # Check for xcrun simctl availability
    if ! command -v xcrun &>/dev/null; then
        _str_record "iOS前提条件" "SKIP" "xcrunコマンドが見つかりません（Xcodeが必要）"
        return 1
    fi

    # Build the project
    local build_rc=0
    if [[ -f "${project_dir}/Package.swift" ]]; then
        _str_log "INFO" "Swift Package Manager ビルド中..."
        (cd "$project_dir" && swift build 2>"${_STR_LOG_DIR}/swift_build.stderr") || build_rc=$?
    elif find "$project_dir" -name "*.xcodeproj" -maxdepth 2 2>/dev/null | grep -q .; then
        _str_log "INFO" "xcodebuild ビルド中..."
        local xcproj
        xcproj=$(find "$project_dir" -name "*.xcodeproj" -maxdepth 2 2>/dev/null | head -1)
        (cd "$project_dir" && xcodebuild build -project "$xcproj" -scheme "$(basename "$xcproj" .xcodeproj)" -destination 'platform=iOS Simulator,name=iPhone 15' CODE_SIGNING_ALLOWED=NO 2>"${_STR_LOG_DIR}/xcodebuild.stderr") || build_rc=$?
    else
        _str_record "iOSビルド" "SKIP" "Package.swiftまたは.xcodeprojが見つかりません"
        return 1
    fi

    if [[ $build_rc -eq 0 ]]; then
        _str_record "iOSビルド" "PASS" "ビルド成功"
    else
        _str_record "iOSビルド" "FAIL" "ビルド失敗 (rc=${build_rc})"
        _str_log "ERROR" "stderr: $(tail -5 "${_STR_LOG_DIR}/swift_build.stderr" "${_STR_LOG_DIR}/xcodebuild.stderr" 2>/dev/null)"
        return 1
    fi

    # Run tests
    local test_rc=0
    if [[ -f "${project_dir}/Package.swift" ]]; then
        _str_log "INFO" "swift test 実行中..."
        (cd "$project_dir" && swift test 2>"${_STR_LOG_DIR}/swift_test.stderr") || test_rc=$?
    else
        local xcproj
        xcproj=$(find "$project_dir" -name "*.xcodeproj" -maxdepth 2 2>/dev/null | head -1)
        if [[ -n "$xcproj" ]]; then
            _str_log "INFO" "xcodebuild test 実行中..."
            (cd "$project_dir" && xcodebuild test -project "$xcproj" -scheme "$(basename "$xcproj" .xcodeproj)" -destination 'platform=iOS Simulator,name=iPhone 15' CODE_SIGNING_ALLOWED=NO 2>"${_STR_LOG_DIR}/xcodebuild_test.stderr") || test_rc=$?
        fi
    fi

    if [[ $test_rc -eq 0 ]]; then
        _str_record "iOSテスト" "PASS" "テスト成功"
    else
        _str_record "iOSテスト" "FAIL" "テスト失敗 (rc=${test_rc})"
    fi

    return $test_rc
}

# ============================================================
# Get test stats
# ============================================================
str_get_stats() {
    echo "{\"pass\": ${_STR_PASS_COUNT}, \"fail\": ${_STR_FAIL_COUNT}, \"skip\": ${_STR_SKIP_COUNT}}"
}
