#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v101.0 - Business Context Engine
# AGI時代の最大の堀: 顧客固有のビジネス知識を蓄積・活用
#
# 既存インフラとの棲み分け:
#   learning-hub.sh    → 技術的パターン（コード品質、エラー修正）
#   cross-session.sh   → セッション間の技術的学習
#   knowledge-db.sh    → エラー→修正のマッピング
#   ★ business-context.sh → ビジネスドメイン知識（AGIでも知り得ない情報）
#
# 蓄積するもの:
#   1. 顧客プロファイル（業種、規模、技術スタック、ビジネスルール）
#   2. ドメイン別成功パターン（SaaS/EC/CRM等のベストプラクティス）
#   3. プロジェクト成果記録（見積り精度、デプロイ成功率、顧客満足度）
#   4. ビジネスルール（コスト閾値、リスク判定、優先度ルール）
#   5. 業界固有の制約（法規制、セキュリティ要件、コンプライアンス）
#
# v101.0: AGI-Ready Business Intelligence
# ============================================================

[[ -n "${_BUSINESS_CONTEXT_LOADED:-}" ]] && return 0
_BUSINESS_CONTEXT_LOADED=1

# --- グローバル状態 ---
BCE_VERSION="101.0"
BCE_INITIALIZED=false
BCE_BASE_DIR="${HOME}/.soloptilink/business-context"
BCE_PROFILES_DIR=""
BCE_OUTCOMES_DIR=""
BCE_RULES_DIR=""
BCE_INDUSTRY_DIR=""

# --- 統計 ---
BCE_TOTAL_PROFILES=0
BCE_TOTAL_OUTCOMES=0
BCE_TOTAL_RULES=0

# ============================================================
# 初期化
# ============================================================
bce_init() {
    BCE_PROFILES_DIR="${BCE_BASE_DIR}/profiles"
    BCE_OUTCOMES_DIR="${BCE_BASE_DIR}/outcomes"
    BCE_RULES_DIR="${BCE_BASE_DIR}/rules"
    BCE_INDUSTRY_DIR="${BCE_BASE_DIR}/industry"

    mkdir -p "$BCE_PROFILES_DIR" "$BCE_OUTCOMES_DIR" "$BCE_RULES_DIR" "$BCE_INDUSTRY_DIR" 2>/dev/null || true

    # 初期データ投入（初回のみ）
    if [[ ! -f "${BCE_BASE_DIR}/initialized" ]]; then
        _bce_seed_domain_knowledge
        _bce_seed_industry_rules
        _bce_seed_business_rules
        date '+%Y-%m-%dT%H:%M:%S' > "${BCE_BASE_DIR}/initialized"
    fi

    # 統計カウント
    BCE_TOTAL_PROFILES=$(find "$BCE_PROFILES_DIR" -name "*.json" 2>/dev/null | wc -l | tr -d ' ')
    BCE_TOTAL_OUTCOMES=$(find "$BCE_OUTCOMES_DIR" -name "*.jsonl" 2>/dev/null | wc -l | tr -d ' ')
    BCE_TOTAL_RULES=$(find "$BCE_RULES_DIR" -name "*.json" 2>/dev/null | wc -l | tr -d ' ')

    BCE_INITIALIZED=true
    return 0
}

# ============================================================
# ドメインプロファイル管理
# ============================================================

# ドメインプロファイルを取得
bce_get_domain_profile() {
    local domain="${1:-general}"
    local profile_file="${BCE_PROFILES_DIR}/${domain}.json"

    if [[ -f "$profile_file" ]]; then
        cat "$profile_file"
    else
        # デフォルトプロファイル生成
        _bce_create_default_profile "$domain"
        [[ -f "$profile_file" ]] && cat "$profile_file"
    fi
}

# ドメインプロファイルを更新
bce_update_domain_profile() {
    local domain="$1"
    local field="$2"
    local value="$3"

    local profile_file="${BCE_PROFILES_DIR}/${domain}.json"
    if [[ ! -f "$profile_file" ]]; then
        _bce_create_default_profile "$domain"
    fi

    # JSONフィールド更新（jq不要の簡易実装）
    local tmp_file="${profile_file}.tmp"
    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys
with open('$profile_file') as f:
    data = json.load(f)
data['$field'] = '$value'
data['updated_at'] = '$(date '+%Y-%m-%dT%H:%M:%S')'
with open('$tmp_file', 'w') as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
" 2>/dev/null && mv "$tmp_file" "$profile_file"
    fi
}

# デフォルトプロファイル作成
_bce_create_default_profile() {
    local domain="$1"
    local profile_file="${BCE_PROFILES_DIR}/${domain}.json"

    cat > "$profile_file" << PROFILE_EOF
{
  "domain": "${domain}",
  "display_name": "${domain}",
  "industry": "general",
  "typical_complexity": "medium",
  "typical_budget_usd": 50.00,
  "avg_build_time_min": 30,
  "success_rate": 0.0,
  "total_projects": 0,
  "tech_stack_preference": {
    "frontend": "react",
    "backend": "nextjs",
    "database": "postgresql",
    "orm": "prisma",
    "auth": "jwt"
  },
  "business_rules": [],
  "compliance_requirements": [],
  "quality_targets": {
    "min_quality_score": 70,
    "require_tests": true,
    "require_audit_log": true,
    "require_rate_limiting": true
  },
  "lessons_learned": [],
  "created_at": "$(date '+%Y-%m-%dT%H:%M:%S')",
  "updated_at": "$(date '+%Y-%m-%dT%H:%M:%S')"
}
PROFILE_EOF
}

# ============================================================
# プロジェクト成果記録
# ============================================================

# セッション完了時に成果を記録
bce_record_outcome() {
    local domain="${1:-general}"
    local project_desc="$2"
    local estimated_cost="${3:-0}"
    local actual_cost="${4:-0}"
    local quality_score="${5:-0}"
    local build_time_sec="${6:-0}"
    local success="${7:-true}"
    local notes="${8:-}"

    local outcome_file="${BCE_OUTCOMES_DIR}/${domain}.jsonl"

    # 見積精度算出
    local cost_accuracy=0
    if [[ "$estimated_cost" != "0" ]]; then
        cost_accuracy=$(echo "scale=2; ($actual_cost / $estimated_cost) * 100" | bc 2>/dev/null || echo "0")
    fi

    local record="{\"timestamp\":\"$(date '+%Y-%m-%dT%H:%M:%S')\",\"domain\":\"${domain}\",\"description\":\"${project_desc}\",\"estimated_cost\":${estimated_cost},\"actual_cost\":${actual_cost},\"cost_accuracy\":${cost_accuracy},\"quality_score\":${quality_score},\"build_time_sec\":${build_time_sec},\"success\":${success},\"notes\":\"${notes}\"}"

    echo "$record" >> "$outcome_file"

    # プロファイルの統計を更新
    _bce_update_profile_stats "$domain" "$quality_score" "$success" "$actual_cost" "$build_time_sec"
}

# プロファイル統計更新
_bce_update_profile_stats() {
    local domain="$1"
    local quality="$2"
    local success="$3"
    local cost="$4"
    local time="$5"

    local profile_file="${BCE_PROFILES_DIR}/${domain}.json"
    [[ ! -f "$profile_file" ]] && return

    if command -v python3 &>/dev/null; then
        python3 -c "
import json
with open('$profile_file') as f:
    data = json.load(f)
data['total_projects'] = data.get('total_projects', 0) + 1
total = data['total_projects']
if $success:
    old_rate = data.get('success_rate', 0)
    data['success_rate'] = round(((old_rate * (total-1)) + 1.0) / total, 3)
data['updated_at'] = '$(date '+%Y-%m-%dT%H:%M:%S')'
with open('$profile_file', 'w') as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
" 2>/dev/null || true
    fi
}

# ============================================================
# ビジネスルール管理
# ============================================================

# ルール取得
bce_get_rules() {
    local rule_type="${1:-all}"  # cost, risk, compliance, priority
    local rules_file="${BCE_RULES_DIR}/business_rules.json"

    if [[ -f "$rules_file" ]]; then
        if [[ "$rule_type" == "all" ]]; then
            cat "$rules_file"
        else
            # 特定タイプのルールだけ抽出
            python3 -c "
import json
with open('$rules_file') as f:
    data = json.load(f)
rules = [r for r in data.get('rules', []) if r.get('type') == '$rule_type']
print(json.dumps(rules, indent=2, ensure_ascii=False))
" 2>/dev/null || cat "$rules_file"
        fi
    fi
}

# ルール追加
bce_add_rule() {
    local rule_type="$1"   # cost, risk, compliance, priority
    local condition="$2"   # 条件式
    local action="$3"      # アクション
    local description="$4" # 説明

    local rules_file="${BCE_RULES_DIR}/business_rules.json"

    if command -v python3 &>/dev/null; then
        python3 -c "
import json
try:
    with open('$rules_file') as f:
        data = json.load(f)
except:
    data = {'rules': []}
data['rules'].append({
    'type': '$rule_type',
    'condition': '$condition',
    'action': '$action',
    'description': '$description',
    'created_at': '$(date '+%Y-%m-%dT%H:%M:%S')',
    'active': True
})
with open('$rules_file', 'w') as f:
    json.dump(data, f, indent=2, ensure_ascii=False)
" 2>/dev/null
    fi
}

# ============================================================
# 業界固有制約
# ============================================================

# 業界制約を取得
bce_get_industry_constraints() {
    local industry="${1:-general}"
    local constraint_file="${BCE_INDUSTRY_DIR}/${industry}.json"

    if [[ -f "$constraint_file" ]]; then
        cat "$constraint_file"
    fi
}

# ============================================================
# AI呼び出しへの知識注入（ai_call pre-hook）
# ============================================================

# プロンプトにビジネスコンテキストを注入
bce_inject_context() {
    local prompt="$1"
    local domain="${2:-general}"
    local phase="${3:-implementation}"

    [[ "$BCE_INITIALIZED" != "true" ]] && { echo "$prompt"; return; }

    local context=""

    # --- ドメインプロファイルから知見注入 ---
    local profile_file="${BCE_PROFILES_DIR}/${domain}.json"
    if [[ -f "$profile_file" ]]; then
        local tech_stack="" quality_targets="" lessons=""

        if command -v python3 &>/dev/null; then
            tech_stack=$(python3 -c "
import json
with open('$profile_file') as f:
    d = json.load(f)
ts = d.get('tech_stack_preference', {})
parts = []
for k,v in ts.items():
    parts.append(f'{k}: {v}')
print(', '.join(parts))
" 2>/dev/null || echo "")

            quality_targets=$(python3 -c "
import json
with open('$profile_file') as f:
    d = json.load(f)
qt = d.get('quality_targets', {})
parts = []
for k,v in qt.items():
    parts.append(f'{k}={v}')
print(', '.join(parts))
" 2>/dev/null || echo "")

            lessons=$(python3 -c "
import json
with open('$profile_file') as f:
    d = json.load(f)
ll = d.get('lessons_learned', [])
for l in ll[-5:]:
    print(f'- {l}')
" 2>/dev/null || echo "")
        fi

        if [[ -n "$tech_stack" ]]; then
            context+="
[ビジネスコンテキスト - ドメイン: ${domain}]
推奨技術スタック: ${tech_stack}
品質目標: ${quality_targets}"
        fi

        if [[ -n "$lessons" && "$lessons" != *"[]"* ]]; then
            context+="
過去の教訓:
${lessons}"
        fi
    fi

    # --- 業界制約注入 ---
    local industry_file="${BCE_INDUSTRY_DIR}/${domain}.json"
    if [[ -f "$industry_file" ]]; then
        local constraints
        constraints=$(python3 -c "
import json
with open('$industry_file') as f:
    d = json.load(f)
for c in d.get('constraints', [])[:3]:
    print(f'- {c}')
" 2>/dev/null || echo "")
        if [[ -n "$constraints" ]]; then
            context+="
業界固有の制約:
${constraints}"
        fi
    fi

    # --- 成果履歴から注入（直近5件） ---
    local outcome_file="${BCE_OUTCOMES_DIR}/${domain}.jsonl"
    if [[ -f "$outcome_file" ]]; then
        local recent_outcomes
        recent_outcomes=$(tail -3 "$outcome_file" 2>/dev/null)
        if [[ -n "$recent_outcomes" ]]; then
            local avg_quality
            avg_quality=$(python3 -c "
import json
outcomes = []
for line in '''${recent_outcomes}'''.strip().split('\n'):
    if line.strip():
        try:
            outcomes.append(json.loads(line))
        except:
            pass
if outcomes:
    avg_q = sum(o.get('quality_score', 0) for o in outcomes) / len(outcomes)
    print(f'過去{len(outcomes)}件の平均品質: {avg_q:.0f}/100')
" 2>/dev/null || echo "")
            [[ -n "$avg_quality" ]] && context+="
${avg_quality}"
        fi
    fi

    if [[ -n "$context" ]]; then
        echo "${prompt}
${context}"
    else
        echo "$prompt"
    fi
}

# ============================================================
# 見積り精度向上（Cost Gateとの連携）
# ============================================================

# ドメイン別のコスト見積り補正
bce_estimate_cost() {
    local domain="${1:-general}"
    local base_estimate="${2:-5.00}"

    local outcome_file="${BCE_OUTCOMES_DIR}/${domain}.jsonl"
    if [[ -f "$outcome_file" ]]; then
        python3 -c "
import json
outcomes = []
with open('$outcome_file') as f:
    for line in f:
        line = line.strip()
        if line:
            try:
                outcomes.append(json.loads(line))
            except:
                pass
if len(outcomes) >= 3:
    recent = outcomes[-5:]
    avg_ratio = sum(o.get('cost_accuracy', 100) for o in recent) / len(recent) / 100
    adjusted = ${base_estimate} * avg_ratio
    print(f'{adjusted:.2f}')
else:
    print('${base_estimate}')
" 2>/dev/null || echo "$base_estimate"
    else
        echo "$base_estimate"
    fi
}

# ============================================================
# 教訓の記録
# ============================================================
bce_record_lesson() {
    local domain="${1:-general}"
    local lesson="$2"

    local profile_file="${BCE_PROFILES_DIR}/${domain}.json"
    [[ ! -f "$profile_file" ]] && _bce_create_default_profile "$domain"

    if command -v python3 &>/dev/null; then
        python3 -c "
import json
with open('$profile_file') as f:
    data = json.load(f)
lessons = data.get('lessons_learned', [])
lesson_text = '$(date '+%Y-%m-%d'): $lesson'
if lesson_text not in lessons:
    lessons.append(lesson_text)
    data['lessons_learned'] = lessons[-20:]
    data['updated_at'] = '$(date '+%Y-%m-%dT%H:%M:%S')'
    with open('$profile_file', 'w') as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
" 2>/dev/null
    fi
}

# ============================================================
# 初期シードデータ
# ============================================================

_bce_seed_domain_knowledge() {
    # SaaS ドメイン
    cat > "${BCE_PROFILES_DIR}/saas.json" << 'EOF'
{
  "domain": "saas",
  "display_name": "SaaS Application",
  "industry": "technology",
  "typical_complexity": "high",
  "typical_budget_usd": 80.00,
  "avg_build_time_min": 60,
  "success_rate": 0.0,
  "total_projects": 0,
  "tech_stack_preference": {
    "frontend": "react + tailwind",
    "backend": "nextjs api routes",
    "database": "postgresql",
    "orm": "prisma",
    "auth": "nextauth + jwt",
    "payment": "stripe",
    "email": "resend",
    "deployment": "vercel"
  },
  "business_rules": [
    "マルチテナント設計必須",
    "料金プラン（Free/Pro/Enterprise）3段階以上",
    "Stripe決済連携必須",
    "管理者ダッシュボード必須"
  ],
  "compliance_requirements": [
    "個人情報保護法対応",
    "利用規約・プライバシーポリシーページ必須"
  ],
  "quality_targets": {
    "min_quality_score": 80,
    "require_tests": true,
    "require_audit_log": true,
    "require_rate_limiting": true,
    "require_multi_tenant": true
  },
  "lessons_learned": [],
  "created_at": "2026-03-21T00:00:00",
  "updated_at": "2026-03-21T00:00:00"
}
EOF

    # EC ドメイン
    cat > "${BCE_PROFILES_DIR}/ecommerce.json" << 'EOF'
{
  "domain": "ecommerce",
  "display_name": "EC/Online Store",
  "industry": "retail",
  "typical_complexity": "high",
  "typical_budget_usd": 70.00,
  "avg_build_time_min": 50,
  "success_rate": 0.0,
  "total_projects": 0,
  "tech_stack_preference": {
    "frontend": "react + tailwind",
    "backend": "nextjs",
    "database": "postgresql",
    "orm": "prisma",
    "auth": "nextauth",
    "payment": "stripe",
    "search": "meilisearch",
    "storage": "s3"
  },
  "business_rules": [
    "商品カタログ + カート + チェックアウト必須",
    "在庫管理リアルタイム更新",
    "注文ステータス追跡",
    "レビュー・評価システム"
  ],
  "compliance_requirements": [
    "特定商取引法表記必須",
    "PCI DSS準拠（決済情報非保持）",
    "個人情報保護法対応"
  ],
  "quality_targets": {
    "min_quality_score": 80,
    "require_tests": true,
    "require_audit_log": true,
    "require_rate_limiting": true
  },
  "lessons_learned": [],
  "created_at": "2026-03-21T00:00:00",
  "updated_at": "2026-03-21T00:00:00"
}
EOF

    # CRM ドメイン
    cat > "${BCE_PROFILES_DIR}/crm.json" << 'EOF'
{
  "domain": "crm",
  "display_name": "CRM/Customer Management",
  "industry": "business",
  "typical_complexity": "medium",
  "typical_budget_usd": 50.00,
  "avg_build_time_min": 40,
  "success_rate": 0.0,
  "total_projects": 0,
  "tech_stack_preference": {
    "frontend": "react + tailwind + shadcn",
    "backend": "nextjs",
    "database": "postgresql",
    "orm": "prisma",
    "auth": "jwt + rbac"
  },
  "business_rules": [
    "顧客管理（CRUD + 検索 + フィルタ）",
    "営業パイプライン管理",
    "活動履歴（コール/メール/ミーティング）",
    "ダッシュボード（KPI/グラフ）",
    "CSV/Excelインポート・エクスポート"
  ],
  "compliance_requirements": [
    "個人情報保護法対応",
    "アクセス権限管理（RBAC）",
    "監査ログ必須"
  ],
  "quality_targets": {
    "min_quality_score": 75,
    "require_tests": true,
    "require_audit_log": true,
    "require_rate_limiting": true
  },
  "lessons_learned": [],
  "created_at": "2026-03-21T00:00:00",
  "updated_at": "2026-03-21T00:00:00"
}
EOF

    # タスク管理
    cat > "${BCE_PROFILES_DIR}/task_management.json" << 'EOF'
{
  "domain": "task_management",
  "display_name": "Task/Project Management",
  "industry": "productivity",
  "typical_complexity": "medium",
  "typical_budget_usd": 40.00,
  "avg_build_time_min": 35,
  "success_rate": 0.0,
  "total_projects": 0,
  "tech_stack_preference": {
    "frontend": "react + dnd-kit",
    "backend": "nextjs",
    "database": "postgresql",
    "orm": "prisma",
    "realtime": "websocket"
  },
  "business_rules": [
    "カンバンボード + リスト表示",
    "タスク割り当て・期限・優先度",
    "プロジェクト管理",
    "コメント・添付ファイル",
    "通知（期限超過・メンション）"
  ],
  "compliance_requirements": [],
  "quality_targets": {
    "min_quality_score": 70,
    "require_tests": true,
    "require_audit_log": false,
    "require_rate_limiting": true
  },
  "lessons_learned": [],
  "created_at": "2026-03-21T00:00:00",
  "updated_at": "2026-03-21T00:00:00"
}
EOF
}

_bce_seed_industry_rules() {
    # 医療業界
    cat > "${BCE_INDUSTRY_DIR}/healthcare.json" << 'EOF'
{
  "industry": "healthcare",
  "display_name": "医療・ヘルスケア",
  "constraints": [
    "個人情報保護法 + 医療個人情報ガイドライン準拠必須",
    "データ暗号化（保存時 + 通信時）必須",
    "アクセスログ完全記録（誰が・いつ・何を閲覧したか）",
    "データバックアップ・復旧計画必須",
    "パスワードポリシー強化（12文字以上、MFA推奨）"
  ],
  "required_features": ["audit_log", "encryption", "mfa", "backup", "access_control"],
  "prohibited": ["外部クラウドへの無暗号データ送信", "ログなしの個人情報アクセス"]
}
EOF

    # 金融業界
    cat > "${BCE_INDUSTRY_DIR}/finance.json" << 'EOF'
{
  "industry": "finance",
  "display_name": "金融・フィンテック",
  "constraints": [
    "金融商品取引法・資金決済法対応",
    "KYC（本人確認）フロー必須",
    "トランザクション監査証跡（改ざん不可）",
    "暗号化 + HSM推奨",
    "レート制限 + 不正検知必須"
  ],
  "required_features": ["kyc", "audit_log", "encryption", "rate_limiting", "fraud_detection"],
  "prohibited": ["平文での金融データ保存", "監査なしのトランザクション"]
}
EOF

    # 教育業界
    cat > "${BCE_INDUSTRY_DIR}/education.json" << 'EOF'
{
  "industry": "education",
  "display_name": "教育・EdTech",
  "constraints": [
    "未成年者の個人情報保護",
    "アクセシビリティ対応（WCAG 2.1 AA）",
    "学習データの適切な管理・削除",
    "保護者同意フロー（13歳未満）"
  ],
  "required_features": ["a11y", "parental_consent", "data_retention_policy"],
  "prohibited": ["未成年データの第三者提供", "追跡広告"]
}
EOF
}

_bce_seed_business_rules() {
    cat > "${BCE_RULES_DIR}/business_rules.json" << 'EOF'
{
  "rules": [
    {
      "type": "cost",
      "condition": "estimated_cost > 100",
      "action": "require_approval",
      "description": "$100超のプロジェクトはユーザー承認必須",
      "active": true
    },
    {
      "type": "cost",
      "condition": "actual_cost > estimated_cost * 1.5",
      "action": "alert_overrun",
      "description": "見積りの150%超過で警告",
      "active": true
    },
    {
      "type": "risk",
      "condition": "domain == 'healthcare' || domain == 'finance'",
      "action": "enforce_security_audit",
      "description": "医療・金融ドメインはセキュリティ監査必須",
      "active": true
    },
    {
      "type": "quality",
      "condition": "quality_score < 60",
      "action": "block_deploy",
      "description": "品質スコア60未満はデプロイブロック",
      "active": true
    },
    {
      "type": "compliance",
      "condition": "handles_pii == true",
      "action": "require_encryption",
      "description": "個人情報を扱う場合は暗号化必須",
      "active": true
    }
  ],
  "created_at": "2026-03-21T00:00:00"
}
EOF
}

# ============================================================
# レポート
# ============================================================
bce_report() {
    echo "=== Business Context Engine v${BCE_VERSION} ==="
    echo "  Profiles: ${BCE_TOTAL_PROFILES}"
    echo "  Outcomes: ${BCE_TOTAL_OUTCOMES} domains tracked"
    echo "  Rules: ${BCE_TOTAL_RULES} rule files"
    echo "  Storage: ${BCE_BASE_DIR}"

    if [[ -d "$BCE_PROFILES_DIR" ]]; then
        echo "  Domains:"
        for f in "$BCE_PROFILES_DIR"/*.json; do
            [[ -f "$f" ]] || continue
            local name
            name=$(basename "$f" .json)
            local projects=0
            projects=$(python3 -c "import json; print(json.load(open('$f')).get('total_projects',0))" 2>/dev/null || echo "0")
            echo "    - ${name} (${projects} projects)"
        done
    fi
}

bce_score() {
    local score=50
    [[ $BCE_TOTAL_PROFILES -gt 0 ]] && score=$((score + 15))
    [[ $BCE_TOTAL_PROFILES -gt 5 ]] && score=$((score + 10))
    [[ $BCE_TOTAL_OUTCOMES -gt 0 ]] && score=$((score + 15))
    [[ -f "${BCE_RULES_DIR}/business_rules.json" ]] && score=$((score + 10))
    echo "$score"
}

# ============================================================
# Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "business-context" \
        --version "$BCE_VERSION" \
        --description "AGI対応ビジネスコンテキストエンジン - 顧客固有知識の蓄積と活用" \
        --init "bce_init" \
        --report "bce_report" \
        --score "bce_score" \
        --enable-var "ENABLE_BUSINESS_CONTEXT" \
        --cli-flags "--business-context:--no-business-context"
fi

# v2003.1: source時のexit codeを確実に0にする
true
