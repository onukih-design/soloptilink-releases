#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2016.0 - Inference ↔ Implementation Diff (RVG-4)
# =============================================================================
# docs/DESIGN_CONTRACT.md (BOOST Step 0.4 Silent Inference の推論サマリー保存先)
# と routes.json (RVG-1 出力) を突合し、推論で約束した機能のうち
# 実装に至っていないものを列挙する。
#
# 抽出する「機能トークン」は推論サマリーに頻出する単語:
#   - 「請求書」「見積書」「契約」「商品」「顧客」「ユーザー」「ダッシュボード」
#   - 「ログイン」「サインアップ」「会社」「端末」「分析」「設定」「メール」「監査ログ」
# 推論サマリー内に出現する機能トークンに対し、
# routes.json の URL に対応するセグメントが含まれているかを確認する。
# 例: 「請求書」→ /invoices, /api/invoices, /billing 等を許容
#
# 使用:
#   bash ~/.soloptilink/lib/inference-impl-diff.sh \
#         <DESIGN_CONTRACT_MD> <ROUTES_JSON> [OUT_JSON]
# 戻り値: 0=完全一致 (欠落ゼロ), 1=欠落あり, 2=入力ファイルなし
# =============================================================================

[[ -n "${_INFERENCE_IMPL_DIFF_LOADED:-}" ]] && return 0
_INFERENCE_IMPL_DIFF_LOADED=1

readonly IID_VERSION="1.0.0"

# ============================================================
# 機能トークン → URL セグメント候補のマップ (日本語 → 英語)
# 値はパイプ区切り。1つでもマッチすれば実装済み判定
# ============================================================
declare -A _IID_TOKEN_MAP=(
    [請求書]="invoice|invoices|billing|bills"
    [請求]="invoice|invoices|billing|bills"
    [見積書]="estimate|estimates|quote|quotes|quotation"
    [見積]="estimate|estimates|quote|quotes|quotation"
    [契約]="contract|contracts|agreement|agreements"
    [契約書]="contract|contracts|agreement|agreements"
    [商品]="product|products|item|items|catalog"
    [製品]="product|products|item|items"
    [顧客]="customer|customers|client|clients|account|accounts"
    [取引先]="customer|customers|client|clients|company|companies"
    [会社]="company|companies|organization|organizations|tenant|tenants"
    [企業]="company|companies|organization|organizations"
    [ユーザー]="user|users|member|members|account"
    [メンバー]="user|users|member|members"
    [従業員]="employee|employees|staff"
    [社員]="employee|employees|staff|user|users"
    [ダッシュボード]="dashboard|home|overview|index"
    [ホーム]="dashboard|home|index"
    [ログイン]="login|signin|auth|authentication"
    [サインアップ]="signup|register|registration"
    [サインイン]="login|signin|auth"
    [ログアウト]="logout|signout"
    [認証]="auth|authentication|login|signin"
    [権限]="role|roles|permission|permissions|rbac"
    [設定]="setting|settings|config|configuration|preferences"
    [プロフィール]="profile|profiles|me|account"
    [プロファイル]="profile|profiles"
    [端末]="device|devices|machine|machines|terminal|terminals"
    [デバイス]="device|devices"
    [分析]="analytics|analysis|insight|insights|report|reports"
    [レポート]="report|reports|analytics"
    [統計]="stats|statistics|analytics"
    [メール]="email|emails|mail|mails|notification|notifications"
    [通知]="notification|notifications|alert|alerts"
    [監査ログ]="audit|audit_log|audit-log|auditlog|audits"
    [監査]="audit|audits"
    [操作ログ]="audit|audit_log|operation_log|activity_log|activities"
    [履歴]="history|histories|log|logs"
    [タスク]="task|tasks|todo|todos|job|jobs"
    [スケジュール]="schedule|schedules|calendar|calendars|event|events"
    [カレンダー]="calendar|calendars|schedule|schedules"
    [チャット]="chat|chats|message|messages|conversation|conversations"
    [メッセージ]="message|messages|chat|chats"
    [プロジェクト]="project|projects|workspace|workspaces"
    [案件]="project|projects|deal|deals|opportunity|opportunities"
    [在庫]="inventory|stock|stocks|warehouse|warehouses"
    [注文]="order|orders|purchase|purchases"
    [カート]="cart|carts|basket"
    [決済]="payment|payments|checkout|billing"
    [支払]="payment|payments|billing"
    [支払い]="payment|payments|billing"
    [入金]="payment|payments|deposit|deposits|receipt|receipts"
    [出金]="payout|payouts|withdrawal|withdrawals"
    [予約]="reservation|reservations|booking|bookings|appointment|appointments"
    [予算]="budget|budgets"
    [原価]="cost|costs|costing"
    [見込み]="lead|leads|prospect|prospects"
    [リード]="lead|leads"
    [営業]="sales|deal|deals|opportunity|opportunities"
    [マーケティング]="marketing|campaign|campaigns"
    [キャンペーン]="campaign|campaigns|promo|promotion"
    [サポート]="support|ticket|tickets|inquiry|inquiries"
    [問い合わせ]="contact|inquiry|inquiries|support|ticket|tickets"
    [FAQ]="faq|faqs|help|knowledge"
    [ヘルプ]="help|faq|support"
    [診療]="visit|visits|consultation|consultations|appointment|appointments"
    [患者]="patient|patients"
    [診療報酬]="medical_fee|medical|claim|claims|reimbursement"
    [介護]="care|carers|longterm-care|longterm_care"
    [図面]="drawing|drawings|blueprint|blueprints"
    [建築]="architecture|building|construction"
    [見積もり]="estimate|estimates|quote|quotes"
    [入札]="bid|bids|tender|tenders|procurement"
    [補助金]="subsidy|subsidies|grant|grants"
    [振込]="transfer|transfers|remittance"
    [口座]="account|accounts|bank|banks"
    [部署]="department|departments|team|teams"
    [部門]="department|departments|division|divisions"
    [予実]="budget|forecast|actual|variance"
    [稟議]="ringi|approval|approvals|workflow|workflows"
    [稟議書]="ringi|approval|approvals|workflow"
    [承認]="approval|approvals|approve"
    [ワークフロー]="workflow|workflows|approval|approvals"
    [請求]="invoice|invoices|billing"
    [納品]="delivery|deliveries|shipment|shipments"
    [納品書]="delivery|deliveries|delivery_note|deliverynote|shipment"
    [出荷]="shipment|shipments|shipping"
    [仕入]="purchase|purchases|procurement"
    [仕入先]="supplier|suppliers|vendor|vendors"
)

# ============================================================
# Public: iid_diff <design_contract_md> <routes_json> [out_json]
# ============================================================
iid_diff() {
    local md="${1:-docs/DESIGN_CONTRACT.md}"
    local routes_json="${2:-.rvg/routes.json}"
    local out_json="${3:-$(dirname "$routes_json")/inference-diff.json}"

    if [[ ! -f "$md" ]]; then
        echo "[inference-diff] WARN: DESIGN_CONTRACT.md not found: $md" >&2
        # No contract → skip with empty diff (success)
        echo '{"contract_present":false,"declared":[],"missing":[],"implemented":[],"coverage":1.0}' > "$out_json"
        return 0
    fi

    if [[ ! -f "$routes_json" ]]; then
        echo "[inference-diff] ERROR: routes.json not found: $routes_json" >&2
        return 2
    fi

    mkdir -p "$(dirname "$out_json")" 2>/dev/null

    # 1. Extract "主要機能" / "対象ユーザー" tokens from inference summary
    local declared
    declared=$(_iid_extract_tokens "$md")

    # 2. Concatenate all URLs into a search blob
    local url_blob
    url_blob=$(grep -oE '"url":"[^"]+"' "$routes_json" 2>/dev/null | tr 'A-Z' 'a-z' | tr -d '"' | sed 's/url://g')

    # 3. For each declared token, check if URL contains corresponding segment
    local missing=() implemented=()
    local tok
    while IFS= read -r tok; do
        [[ -z "$tok" ]] && continue
        local segs="${_IID_TOKEN_MAP[$tok]:-}"
        if [[ -z "$segs" ]]; then
            # Unknown token: try direct lowercase match
            segs=$(echo "$tok" | tr 'A-Z' 'a-z')
        fi
        if echo "$url_blob" | grep -qE "($segs)"; then
            implemented+=("$tok")
        else
            missing+=("$tok")
        fi
    done <<< "$declared"

    # 4. Compute coverage and emit JSON
    local total=$(( ${#implemented[@]} + ${#missing[@]} ))
    local coverage="1.0"
    if [[ $total -gt 0 ]]; then
        coverage=$(awk -v i="${#implemented[@]}" -v t="$total" 'BEGIN{printf "%.4f", i/t}')
    fi

    {
        echo '{'
        echo '  "contract_present": true,'
        printf '  "declared": ['
        _iid_json_array "$(printf '%s\n' "${implemented[@]}" "${missing[@]}" | sort -u)"
        echo '],'
        printf '  "implemented": ['
        _iid_json_array "$(printf '%s\n' "${implemented[@]}")"
        echo '],'
        printf '  "missing": ['
        _iid_json_array "$(printf '%s\n' "${missing[@]}")"
        echo '],'
        echo "  \"coverage\": ${coverage}"
        echo '}'
    } > "$out_json"

    local ms="${#missing[@]}"
    if [[ "$ms" -eq 0 ]]; then
        echo "[inference-diff] coverage=${coverage} (all declared features implemented) → $out_json" >&2
        return 0
    else
        echo "[inference-diff] coverage=${coverage} missing=${ms} (${missing[*]}) → $out_json" >&2
        return 1
    fi
}

# Extract tokens from "主要機能", "対象ユーザー", "推論サマリー" sections
_iid_extract_tokens() {
    local md="$1"
    local tok
    {
        # Token map keys が原文に出現するか
        for tok in "${!_IID_TOKEN_MAP[@]}"; do
            if grep -qF "$tok" "$md" 2>/dev/null; then
                echo "$tok"
            fi
        done
    } | sort -u
}

_iid_json_array() {
    local items="$1"
    if [[ -z "$items" ]]; then return 0; fi
    local first=1
    local i
    while IFS= read -r i; do
        [[ -z "$i" ]] && continue
        [[ $first -eq 1 ]] && first=0 || echo -n ','
        # JSON-escape
        local esc="${i//\\/\\\\}"
        esc="${esc//\"/\\\"}"
        printf '"%s"' "$esc"
    done <<< "$items"
}

# ============================================================
# CLI entry
# ============================================================
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    iid_diff "${1:-docs/DESIGN_CONTRACT.md}" "${2:-.rvg/routes.json}" "${3:-}"
    exit $?
fi
