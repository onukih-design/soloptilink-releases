#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v20.0 - Quality Gate (品質ゲート)
# =============================================================================
# 生成コードの品質を6軸で検証し、モックデータ・空ハンドラ・DB未接続を検出する
#
# 検証軸:
#   1. モックデータ検出 (Mock Data Detection)
#   2. イベントハンドラ検証 (Event Handler Verification)
#   3. DB統合検証 (Database Integration Check)
#   4. API接続検証 (API Connection Validation)
#   5. CRUD完全性検証 (CRUD Completeness Check)
#   6. インタラクティビティスコア (Interactivity Score)
#
# 使用方法:
#   source lib/quality-gate.sh
#   qg_run_quality_gate "/path/to/project"
#   # 戻り値: 0=PASS, 1=FAIL
# =============================================================================

[[ -n "${_QUALITY_GATE_LOADED:-}" ]] && return 0
_QUALITY_GATE_LOADED=1

# ============================================================
# Constants
# ============================================================
QG_VERSION="20.0"
QG_DEFAULT_THRESHOLD=80
QG_WARN_THRESHOLD=60

# Weight for each axis (total should be 100)
# v31.0: 7-axis (added enterprise patterns compliance)
QG_WEIGHT_MOCK=22
QG_WEIGHT_HANDLERS=22
QG_WEIGHT_DB=18
QG_WEIGHT_API=13
QG_WEIGHT_CRUD=13
QG_WEIGHT_ENTERPRISE=12  # v31.0: Enterprise Pattern Compliance

# ============================================================
# Internal state
# ============================================================
_QG_PROJECT_DIR=""
_QG_FINDINGS=()
_QG_SCORES=()
_QG_REPORT_FILE=""

# Reset internal state (called between heal loops)
_qg_reset_state() {
    _QG_FINDINGS=()
    _QG_SCORES=()
    _QG_REPORT_FILE=""
}

# ============================================================
# Logging
# ============================================================
_qg_log() {
    local level="$1" msg="$2"
    local timestamp
    timestamp="$(date '+%Y-%m-%d %H:%M:%S')"
    echo -e "  [QualityGate][${level}] ${msg}" >&2
    if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
        echo "[${timestamp}][QG][${level}] ${msg}" >> "${SESSION_LOG_DIR}/quality_gate.log" 2>/dev/null || true
    fi
}

# ============================================================
# Safe numeric grep count (prevents arithmetic errors from non-numeric output)
# ============================================================
_qg_grep_count() {
    # Usage: echo "$content" | _qg_grep_count 'pattern'
    # Returns a clean integer count
    local pattern="$1"
    local result
    result=$(grep -cE "$pattern" 2>/dev/null) || true
    # Ensure we only return a clean integer
    result="${result%%[!0-9]*}"
    echo "${result:-0}"
}

# ============================================================
# File scanning utilities
# ============================================================

# Find source files in project (JS/TS/JSX/TSX/Python)
_qg_find_source_files() {
    local dir="$1"
    local -a files=()

    # Find frontend files
    while IFS= read -r -d '' f; do
        files+=("$f")
    done < <(find "$dir" -type f \( -name "*.js" -o -name "*.jsx" -o -name "*.ts" -o -name "*.tsx" -o -name "*.vue" -o -name "*.svelte" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        -not -path "*/dist/*" \
        -not -path "*/build/*" \
        -not -path "*/.git/*" \
        -not -path "*/coverage/*" \
        -print0 2>/dev/null)

    # Find backend files
    while IFS= read -r -d '' f; do
        files+=("$f")
    done < <(find "$dir" -type f \( -name "*.py" -o -name "*.rb" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/__pycache__/*" \
        -not -path "*/.venv/*" \
        -not -path "*/venv/*" \
        -not -path "*/.git/*" \
        -print0 2>/dev/null)

    # Find Swift files (iOS/macOS)
    while IFS= read -r -d '' f; do
        files+=("$f")
    done < <(find "$dir" -type f -name "*.swift" \
        -not -path "*/.build/*" \
        -not -path "*/DerivedData/*" \
        -not -path "*/.git/*" \
        -print0 2>/dev/null)

    printf '%s\n' "${files[@]}"
}

# Find only frontend component files
_qg_find_component_files() {
    local dir="$1"
    find "$dir" -type f \( -name "*.jsx" -o -name "*.tsx" -o -name "*.vue" -o -name "*.svelte" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        -not -path "*/dist/*" \
        -not -path "*/build/*" \
        -not -path "*/.git/*" \
        2>/dev/null
}

# Find backend route/controller files
_qg_find_backend_files() {
    local dir="$1"
    find "$dir" -type f \( -name "*.js" -o -name "*.ts" -o -name "*.py" \) \
        \( -path "*/routes/*" -o -path "*/controllers/*" -o -path "*/api/*" \
           -o -path "*/routers/*" -o -path "*/views/*" -o -path "*/endpoints/*" \
           -o -name "server.*" -o -name "app.*" -o -name "index.*" \) \
        -not -path "*/node_modules/*" \
        -not -path "*/.next/*" \
        -not -path "*/dist/*" \
        -not -path "*/.git/*" \
        2>/dev/null
}

# ============================================================
# Axis 1: Mock Data Detection
# ============================================================
qg_check_mock_data() {
    local project_dir="$1"
    local score=100
    local -a issues=()
    local file_count=0
    local mock_count=0

    _qg_log "INFO" "Axis 1: モックデータ検出を開始..."

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        file_count=$((file_count + 1))
        local content
        content="$(cat "$file" 2>/dev/null)" || continue
        local relpath="${file#$project_dir/}"

        # Pattern 1: Hardcoded data arrays in useState/state
        # e.g., useState([{id: 1, name: "John"...}])
        if echo "$content" | grep -qE 'useState\s*\(\s*\[' 2>/dev/null; then
            # Check if the array has hardcoded objects inside
            if echo "$content" | grep -qE 'useState\s*\(\s*\[\s*\{' 2>/dev/null; then
                issues+=("MOCK_ARRAY: ${relpath} - useStateにハードコードされたオブジェクト配列")
                mock_count=$((mock_count + 1))
            fi
        fi

        # Pattern 2: Hardcoded const data arrays at module level
        if echo "$content" | grep -qE '(const|let|var)\s+\w+(Data|Items|List|Records|Users|Products)\s*[:=]\s*\[' 2>/dev/null; then
            if echo "$content" | grep -qE '(const|let|var)\s+\w+(Data|Items|List|Records|Users|Products)\s*[:=]\s*\[\s*\{' 2>/dev/null; then
                issues+=("MOCK_CONST: ${relpath} - モジュールレベルのハードコードデータ配列")
                mock_count=$((mock_count + 1))
            fi
        fi

        # Pattern 3: TODO/FIXME stubs
        if echo "$content" | grep -qiE '(TODO|FIXME).*?(replace|implement|connect|database|DB|API|後で)' 2>/dev/null; then
            issues+=("TODO_STUB: ${relpath} - 未実装TODOスタブが残存")
            mock_count=$((mock_count + 1))
        fi

        # Pattern 4: Date.now() as ID
        if echo "$content" | grep -qE 'id:\s*Date\.now\(\)' 2>/dev/null; then
            issues+=("MOCK_ID: ${relpath} - Date.now()をIDとして使用（DB自動採番を使うべき）")
            mock_count=$((mock_count + 1))
        fi

        # Pattern 5: localStorage/sessionStorage as primary data store
        if echo "$content" | grep -qE '(localStorage|sessionStorage)\.(setItem|getItem).*?(items|data|records|users|products)' 2>/dev/null; then
            # Check if this is the ONLY data storage (not a cache)
            if ! echo "$content" | grep -qE '(fetch|axios|api\.|prisma|query|mutation)' 2>/dev/null; then
                issues+=("LOCAL_STORAGE: ${relpath} - localStorage/sessionStorageのみでデータ管理")
                mock_count=$((mock_count + 1))
            fi
        fi

        # Pattern 6: Dummy email/name/phone patterns
        if echo "$content" | grep -qE '(john@example\.com|jane@example\.com|test@test\.com|dummy@|sample@)' 2>/dev/null; then
            if echo "$content" | grep -qvE '(test|spec|mock|fixture|seed)' <<< "$relpath" 2>/dev/null; then
                issues+=("DUMMY_DATA: ${relpath} - ダミーのメールアドレス/名前がソースコードに埋め込み")
                mock_count=$((mock_count + 1))
            fi
        fi

        # Pattern 7: Swift hardcoded arrays (e.g., let items = [Item(...),...])
        if echo "$content" | grep -qE '(var|let)\s+\w+\s*[:=]\s*\[\s*[A-Z]\w+\(' 2>/dev/null; then
            if echo "$content" | grep -qvE '(test|spec|mock|fixture|seed|preview)' <<< "$relpath" 2>/dev/null; then
                issues+=("SWIFT_MOCK_ARRAY: ${relpath} - Swiftハードコードされたオブジェクト配列")
                mock_count=$((mock_count + 1))
            fi
        fi

        # Pattern 8: In-memory arrays as "database" in backend
        if echo "$content" | grep -qE '(const|let|var)\s+\w+\s*=\s*\[\];\s*//.*?(database|db|store|data)' 2>/dev/null; then
            issues+=("MEMORY_DB: ${relpath} - インメモリ配列をデータベース代わりに使用")
            mock_count=$((mock_count + 1))
        fi
        if echo "$content" | grep -qE '\.push\(.*?\).*?//.*?(save|store|add|create)' 2>/dev/null; then
            if ! echo "$content" | grep -qE '(prisma|sequelize|mongoose|typeorm|knex|sqlalchemy|session\.add)' 2>/dev/null; then
                # Check if file has any ORM import
                if ! echo "$content" | grep -qE '^(import|from|require).*?(prisma|sequelize|mongoose|typeorm|knex)' 2>/dev/null; then
                    issues+=("MEMORY_PUSH: ${relpath} - Array.push()でデータ保存（ORM未使用）")
                    mock_count=$((mock_count + 1))
                fi
            fi
        fi

    done < <(_qg_find_source_files "$project_dir")

    # Calculate score
    if [[ $file_count -gt 0 && $mock_count -gt 0 ]]; then
        # Deduct points based on mock data ratio
        local deduction=$(( (mock_count * 100) / file_count ))
        [[ $deduction -gt 100 ]] && deduction=100
        score=$((100 - deduction))
        [[ $score -lt 0 ]] && score=0
    fi

    # Store results
    _QG_SCORES[0]=$score
    for issue in "${issues[@]}"; do
        _QG_FINDINGS+=("$issue")
    done

    _qg_log "INFO" "Axis 1完了: スコア=${score}/100, 検出=${mock_count}件 (${file_count}ファイル検査)"
    echo "$score"
}

# ============================================================
# Axis 2: Event Handler Verification
# ============================================================
qg_check_event_handlers() {
    local project_dir="$1"
    local score=100
    local -a issues=()
    local total_handlers=0
    local empty_handlers=0

    _qg_log "INFO" "Axis 2: イベントハンドラ検証を開始..."

    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content="$(cat "$file" 2>/dev/null)" || continue
        local relpath="${file#$project_dir/}"

        # Pattern 1: Empty onClick handlers
        # onClick={() => {}}  or  onClick={() => { }}  or  onClick={()=>{}}
        local empty_onclick
        empty_onclick=$(echo "$content" | _qg_grep_count 'onClick\s*=\s*\{\s*\(\s*\)\s*=>\s*\{\s*\}\s*\}')
        if [[ "$empty_onclick" -gt 0 ]]; then
            issues+=("EMPTY_ONCLICK: ${relpath} - 空のonClickハンドラが${empty_onclick}個")
            empty_handlers=$((empty_handlers + empty_onclick))
        fi

        # Pattern 2: Empty onSubmit handlers
        local empty_onsubmit
        empty_onsubmit=$(echo "$content" | _qg_grep_count 'onSubmit\s*=\s*\{\s*\(\s*[^)]*\)\s*=>\s*\{\s*\}\s*\}')
        if [[ "$empty_onsubmit" -gt 0 ]]; then
            issues+=("EMPTY_ONSUBMIT: ${relpath} - 空のonSubmitハンドラが${empty_onsubmit}個")
            empty_handlers=$((empty_handlers + empty_onsubmit))
        fi

        # Pattern 3: console.log-only handlers
        local console_only
        console_only=$(echo "$content" | _qg_grep_count 'on(Click|Submit|Change)\s*=\s*\{?\s*\(\s*[^)]*\)\s*=>\s*\{\s*console\.log')
        if [[ "$console_only" -gt 0 ]]; then
            issues+=("CONSOLE_ONLY: ${relpath} - console.logのみのハンドラが${console_only}個")
            empty_handlers=$((empty_handlers + console_only))
        fi

        # Pattern 4: alert()-only handlers
        local alert_only
        alert_only=$(echo "$content" | _qg_grep_count 'on(Click|Submit|Change)\s*=\s*\{?\s*\(\s*[^)]*\)\s*=>\s*\{\s*alert\(')
        if [[ "$alert_only" -gt 0 ]]; then
            issues+=("ALERT_ONLY: ${relpath} - alert()のみのハンドラが${alert_only}個")
            empty_handlers=$((empty_handlers + alert_only))
        fi

        # Count total handlers for ratio
        local all_handlers
        all_handlers=$(echo "$content" | _qg_grep_count 'on(Click|Submit|Change|Input|KeyDown|KeyUp|Focus|Blur)\s*=')
        total_handlers=$((total_handlers + all_handlers))

    done < <(_qg_find_component_files "$project_dir")

    # Calculate score
    if [[ $total_handlers -gt 0 && $empty_handlers -gt 0 ]]; then
        local valid=$((total_handlers - empty_handlers))
        score=$(( (valid * 100) / total_handlers ))
        [[ $score -lt 0 ]] && score=0
    elif [[ $total_handlers -eq 0 ]]; then
        # No handlers found at all - might be backend-only or no components yet
        local component_count
        component_count=$(_qg_find_component_files "$project_dir" | wc -l | tr -d ' ')
        if [[ "$component_count" -gt 0 ]]; then
            score=20  # Components exist but no handlers
            issues+=("NO_HANDLERS: コンポーネントが${component_count}個あるがイベントハンドラなし")
        else
            score=100  # No components - backend only, skip this check
        fi
    fi

    _QG_SCORES[1]=$score
    for issue in "${issues[@]}"; do
        _QG_FINDINGS+=("$issue")
    done

    _qg_log "INFO" "Axis 2完了: スコア=${score}/100, 空ハンドラ=${empty_handlers}/${total_handlers}"
    echo "$score"
}

# ============================================================
# Axis 3: Database Integration Check
# ============================================================
qg_check_db_integration() {
    local project_dir="$1"
    local score=0
    local -a issues=()
    local checks_passed=0
    local checks_total=5

    _qg_log "INFO" "Axis 3: DB統合検証を開始..."

    # Check 1: ORM schema file exists
    if [[ -f "${project_dir}/prisma/schema.prisma" ]]; then
        checks_passed=$((checks_passed + 1))
        _qg_log "INFO" "  ✓ prisma/schema.prisma 存在"
    elif [[ -f "${project_dir}/models.py" ]] || find "$project_dir" -name "models.py" -not -path "*/node_modules/*" 2>/dev/null | grep -q .; then
        checks_passed=$((checks_passed + 1))
        _qg_log "INFO" "  ✓ SQLAlchemy models.py 存在"
    elif find "$project_dir" -name "*.xcdatamodeld" -not -path "*/.git/*" 2>/dev/null | grep -q .; then
        checks_passed=$((checks_passed + 1))
        _qg_log "INFO" "  ✓ CoreData .xcdatamodeld 存在"
    else
        issues+=("NO_SCHEMA: ORMスキーマファイルなし（prisma/schema.prisma または models.py または .xcdatamodeld）")
    fi

    # Check 2: DATABASE_URL in .env
    if [[ -f "${project_dir}/.env" ]]; then
        if grep -q "DATABASE_URL" "${project_dir}/.env" 2>/dev/null; then
            checks_passed=$((checks_passed + 1))
            _qg_log "INFO" "  ✓ .env DATABASE_URL 設定済"
        else
            issues+=("NO_DB_URL: .envファイルにDATABASE_URLがない")
        fi
    elif [[ -f "${project_dir}/.env.example" ]] || [[ -f "${project_dir}/.env.local" ]]; then
        if grep -q "DATABASE_URL" "${project_dir}/.env.example" "${project_dir}/.env.local" 2>/dev/null; then
            checks_passed=$((checks_passed + 1))
        else
            issues+=("NO_DB_URL: .env系ファイルにDATABASE_URLがない")
        fi
    else
        issues+=("NO_ENV: .envファイル自体がない")
    fi

    # Check 3: ORM import in source code
    local orm_imports=0
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        if grep -qE '(from.*prisma|require.*prisma|import.*prisma|from.*sqlalchemy|import.*sequelize|import.*typeorm|import.*mongoose|from.*django\.db)' "$file" 2>/dev/null; then
            orm_imports=$((orm_imports + 1))
        fi
    done < <(_qg_find_source_files "$project_dir")

    if [[ $orm_imports -gt 0 ]]; then
        checks_passed=$((checks_passed + 1))
        _qg_log "INFO" "  ✓ ORMインポート: ${orm_imports}ファイル"
    else
        issues+=("NO_ORM_IMPORT: ソースコードにORMインポートなし")
    fi

    # Check 4: Migration or DB push capability
    if [[ -d "${project_dir}/prisma/migrations" ]] || \
       [[ -f "${project_dir}/prisma/schema.prisma" ]] || \
       [[ -d "${project_dir}/migrations" ]] || \
       [[ -d "${project_dir}/alembic" ]]; then
        checks_passed=$((checks_passed + 1))
        _qg_log "INFO" "  ✓ マイグレーション/DBプッシュ可能"
    else
        issues+=("NO_MIGRATION: マイグレーション機構なし")
    fi

    # Check 5: Seed script exists
    if [[ -f "${project_dir}/prisma/seed.ts" ]] || \
       [[ -f "${project_dir}/prisma/seed.js" ]] || \
       [[ -f "${project_dir}/seed.py" ]] || \
       [[ -f "${project_dir}/seeds/index.ts" ]] || \
       [[ -f "${project_dir}/seeds/index.js" ]] || \
       grep -rq '"seed"' "${project_dir}/package.json" 2>/dev/null; then
        checks_passed=$((checks_passed + 1))
        _qg_log "INFO" "  ✓ シードスクリプト存在"
    else
        issues+=("NO_SEED: シードスクリプトなし（初期データ投入不可）")
    fi

    # Calculate score
    score=$(( (checks_passed * 100) / checks_total ))

    _QG_SCORES[2]=$score
    for issue in "${issues[@]}"; do
        _QG_FINDINGS+=("$issue")
    done

    _qg_log "INFO" "Axis 3完了: スコア=${score}/100, ${checks_passed}/${checks_total}チェック通過"
    echo "$score"
}

# ============================================================
# Axis 4: API Connection Validation
# ============================================================
qg_check_api_connections() {
    local project_dir="$1"
    local score=100
    local -a issues=()
    local api_calls=0
    local valid_calls=0

    _qg_log "INFO" "Axis 4: API接続検証を開始..."

    # Check frontend: Are there actual API calls?
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content="$(cat "$file" 2>/dev/null)" || continue
        local relpath="${file#$project_dir/}"

        # Count fetch/axios calls
        local calls
        calls=$(echo "$content" | _qg_grep_count '(fetch\s*\(|axios\.(get|post|put|patch|delete)\s*\(|api\.(get|post|put|patch|delete)\s*\(|\.query\(|\.mutate\()')
        api_calls=$((api_calls + calls))

        # Check for real endpoints (not just placeholders)
        if echo "$content" | grep -qE "(fetch|axios)\s*\(\s*['\"]https?://(localhost|127\.0\.0\.1|example\.com)" 2>/dev/null; then
            valid_calls=$((valid_calls + calls))
        elif echo "$content" | grep -qE "(fetch|axios|api)\s*\.\s*(get|post|put|patch|delete)\s*\(\s*['\"]/" 2>/dev/null; then
            valid_calls=$((valid_calls + calls))
        elif echo "$content" | grep -qE "(fetch|axios|api)\s*\.\s*(get|post|put|patch|delete)\s*\(\s*\`" 2>/dev/null; then
            valid_calls=$((valid_calls + calls))
        elif echo "$content" | grep -qE "fetch\s*\(\s*['\"]/" 2>/dev/null; then
            valid_calls=$((valid_calls + calls))
        fi

    done < <(_qg_find_component_files "$project_dir")

    # Check backend: Are there route handlers?
    local backend_routes=0
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        local content
        content="$(cat "$file" 2>/dev/null)" || continue

        # Express/Fastify routes
        local routes
        routes=$(echo "$content" | _qg_grep_count '(router|app)\.(get|post|put|patch|delete)\s*\(')
        backend_routes=$((backend_routes + routes))

        # FastAPI/Flask routes
        routes=$(echo "$content" | _qg_grep_count '@(app|router)\.(get|post|put|patch|delete|route)\s*\(')
        backend_routes=$((backend_routes + routes))

        # Next.js API routes (export default/named handler)
        routes=$(echo "$content" | _qg_grep_count 'export\s+(default\s+)?(async\s+)?function\s+(GET|POST|PUT|PATCH|DELETE|handler)')
        backend_routes=$((backend_routes + routes))

    done < <(_qg_find_backend_files "$project_dir")

    # Score calculation
    local component_count
    component_count=$(_qg_find_component_files "$project_dir" | wc -l | tr -d ' ')

    if [[ "$component_count" -gt 0 && "$api_calls" -eq 0 ]]; then
        score=20
        issues+=("NO_API_CALLS: フロントエンドコンポーネントが${component_count}個あるがAPI呼び出しなし")
    elif [[ "$api_calls" -gt 0 && "$valid_calls" -eq 0 ]]; then
        score=40
        issues+=("INVALID_API: API呼び出しが${api_calls}個あるがエンドポイントが不正")
    fi

    if [[ "$component_count" -gt 0 && "$backend_routes" -eq 0 ]]; then
        score=$((score - 30))
        [[ $score -lt 0 ]] && score=0
        issues+=("NO_BACKEND_ROUTES: バックエンドルートが1つもない")
    fi

    # Check CORS setup for separate frontend/backend
    if [[ "$backend_routes" -gt 0 ]]; then
        local has_cors=0
        while IFS= read -r file; do
            if grep -qE '(cors|CORS|Access-Control-Allow-Origin)' "$file" 2>/dev/null; then
                has_cors=1
                break
            fi
        done < <(_qg_find_backend_files "$project_dir")

        if [[ $has_cors -eq 0 ]]; then
            # Check if it's Next.js (built-in API routes, no CORS needed)
            if [[ ! -f "${project_dir}/next.config.js" ]] && [[ ! -f "${project_dir}/next.config.mjs" ]] && [[ ! -f "${project_dir}/next.config.ts" ]]; then
                issues+=("NO_CORS: バックエンドにCORS設定なし（フロントからアクセス不可の恐れ）")
                score=$((score - 10))
                [[ $score -lt 0 ]] && score=0
            fi
        fi
    fi

    _QG_SCORES[3]=$score
    for issue in "${issues[@]}"; do
        _QG_FINDINGS+=("$issue")
    done

    _qg_log "INFO" "Axis 4完了: スコア=${score}/100, API呼出=${api_calls}, バックエンドルート=${backend_routes}"
    echo "$score"
}

# ============================================================
# Axis 5: CRUD Completeness Check
# ============================================================
qg_check_crud_completeness() {
    local project_dir="$1"
    local score=0
    local -a issues=()
    local crud_ops=0
    local crud_total=4  # C, R, U, D

    _qg_log "INFO" "Axis 5: CRUD完全性検証を開始..."

    local all_backend_content=""
    local _qg_file_count=0
    local _qg_max_files=50
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        [[ $_qg_file_count -ge $_qg_max_files ]] && break
        # Skip files larger than 100KB to prevent memory issues
        local _fsize
        _fsize=$(wc -c < "$file" 2>/dev/null || echo "0")
        [[ "$_fsize" -gt 102400 ]] && continue
        all_backend_content+="$(cat "$file" 2>/dev/null)"$'\n'
        _qg_file_count=$((_qg_file_count + 1))
    done < <(_qg_find_backend_files "$project_dir")

    local all_frontend_content=""
    _qg_file_count=0
    while IFS= read -r file; do
        [[ -z "$file" ]] && continue
        [[ $_qg_file_count -ge $_qg_max_files ]] && break
        local _fsize
        _fsize=$(wc -c < "$file" 2>/dev/null || echo "0")
        [[ "$_fsize" -gt 102400 ]] && continue
        all_frontend_content+="$(cat "$file" 2>/dev/null)"$'\n'
        _qg_file_count=$((_qg_file_count + 1))
    done < <(_qg_find_component_files "$project_dir")

    # Check Create (POST)
    local has_create_backend=0
    local has_create_frontend=0
    if echo "$all_backend_content" | grep -qE '\.(post)\s*\(' 2>/dev/null || \
       echo "$all_backend_content" | grep -qE '@(app|router)\.post' 2>/dev/null || \
       echo "$all_backend_content" | grep -qE 'export\s+(async\s+)?function\s+POST' 2>/dev/null; then
        has_create_backend=1
    fi
    if echo "$all_frontend_content" | grep -qE '(onSubmit|handleSubmit|handleCreate|\.post\s*\(|\.create\s*\()' 2>/dev/null; then
        has_create_frontend=1
    fi
    if [[ $has_create_backend -eq 1 && $has_create_frontend -eq 1 ]]; then
        crud_ops=$((crud_ops + 1))
    elif [[ $has_create_backend -eq 1 || $has_create_frontend -eq 1 ]]; then
        issues+=("CRUD_CREATE_PARTIAL: Create操作がフロント/バック片方のみ実装")
    else
        issues+=("CRUD_CREATE_MISSING: Create操作が未実装")
    fi

    # Check Read (GET)
    local has_read_backend=0
    local has_read_frontend=0
    if echo "$all_backend_content" | grep -qE '\.(get)\s*\(' 2>/dev/null || \
       echo "$all_backend_content" | grep -qE '@(app|router)\.get' 2>/dev/null || \
       echo "$all_backend_content" | grep -qE 'export\s+(async\s+)?function\s+GET' 2>/dev/null; then
        has_read_backend=1
    fi
    if echo "$all_frontend_content" | grep -qE '(useEffect|fetchAll|fetchData|\.get\s*\(|\.findMany|useSWR|useQuery)' 2>/dev/null; then
        has_read_frontend=1
    fi
    if [[ $has_read_backend -eq 1 && $has_read_frontend -eq 1 ]]; then
        crud_ops=$((crud_ops + 1))
    elif [[ $has_read_backend -eq 1 || $has_read_frontend -eq 1 ]]; then
        issues+=("CRUD_READ_PARTIAL: Read操作がフロント/バック片方のみ実装")
    else
        issues+=("CRUD_READ_MISSING: Read操作が未実装")
    fi

    # Check Update (PUT/PATCH)
    local has_update_backend=0
    local has_update_frontend=0
    if echo "$all_backend_content" | grep -qE '\.(put|patch)\s*\(' 2>/dev/null || \
       echo "$all_backend_content" | grep -qE '@(app|router)\.(put|patch)' 2>/dev/null || \
       echo "$all_backend_content" | grep -qE 'export\s+(async\s+)?function\s+(PUT|PATCH)' 2>/dev/null; then
        has_update_backend=1
    fi
    if echo "$all_frontend_content" | grep -qE '(handleUpdate|handleEdit|handleSave|\.put\s*\(|\.patch\s*\(|\.update\s*\()' 2>/dev/null; then
        has_update_frontend=1
    fi
    if [[ $has_update_backend -eq 1 && $has_update_frontend -eq 1 ]]; then
        crud_ops=$((crud_ops + 1))
    elif [[ $has_update_backend -eq 1 || $has_update_frontend -eq 1 ]]; then
        issues+=("CRUD_UPDATE_PARTIAL: Update操作がフロント/バック片方のみ実装")
    else
        issues+=("CRUD_UPDATE_MISSING: Update操作が未実装")
    fi

    # Check Delete (DELETE)
    local has_delete_backend=0
    local has_delete_frontend=0
    if echo "$all_backend_content" | grep -qE '\.(delete)\s*\(' 2>/dev/null || \
       echo "$all_backend_content" | grep -qE '@(app|router)\.delete' 2>/dev/null || \
       echo "$all_backend_content" | grep -qE 'export\s+(async\s+)?function\s+DELETE' 2>/dev/null; then
        has_delete_backend=1
    fi
    if echo "$all_frontend_content" | grep -qE '(handleDelete|handleRemove|\.delete\s*\(|\.remove\s*\()' 2>/dev/null; then
        has_delete_frontend=1
    fi
    if [[ $has_delete_backend -eq 1 && $has_delete_frontend -eq 1 ]]; then
        crud_ops=$((crud_ops + 1))
    elif [[ $has_delete_backend -eq 1 || $has_delete_frontend -eq 1 ]]; then
        issues+=("CRUD_DELETE_PARTIAL: Delete操作がフロント/バック片方のみ実装")
    else
        issues+=("CRUD_DELETE_MISSING: Delete操作が未実装")
    fi

    # Check for confirmation dialog on delete
    if [[ $has_delete_frontend -eq 1 ]]; then
        if ! echo "$all_frontend_content" | grep -qE '(confirm\s*\(|Confirm|Dialog|Modal|modal|dialog).*?(delete|削除|remove)' 2>/dev/null && \
           ! echo "$all_frontend_content" | grep -qE '(delete|削除|remove).*?(confirm|Confirm|Dialog|Modal|modal|dialog)' 2>/dev/null; then
            issues+=("NO_DELETE_CONFIRM: 削除操作に確認ダイアログなし")
        fi
    fi

    # Score calculation
    score=$(( (crud_ops * 100) / crud_total ))

    _QG_SCORES[4]=$score
    for issue in "${issues[@]}"; do
        _QG_FINDINGS+=("$issue")
    done

    _qg_log "INFO" "Axis 5完了: スコア=${score}/100, CRUD ${crud_ops}/${crud_total} 実装"
    echo "$score"
}

# ============================================================
# v31.0: Axis 6 - Enterprise Pattern Compliance
# ============================================================
qg_check_enterprise_patterns() {
    local project_dir="$1"
    local score=100
    local issues=0

    # 1. Check for service layer pattern (business logic separated from routes)
    local service_files
    service_files=$(find "$project_dir/src" -path "*/services/*.ts" -o -path "*/services/*.js" 2>/dev/null | wc -l | tr -d ' ')
    [[ "${service_files:-0}" -eq 0 ]] && issues=$((issues + 1))

    # 2. Check for transaction usage ($transaction)
    local transaction_count
    transaction_count=$(grep -r '\$transaction' "$project_dir/src" 2>/dev/null | wc -l | tr -d ' ')
    local write_ops
    write_ops=$(grep -rE '\.(create|update|delete)\(' "$project_dir/src" --include="*.ts" --include="*.tsx" 2>/dev/null | grep -v node_modules | wc -l | tr -d ' ')
    if [[ "${write_ops:-0}" -gt 0 && "${transaction_count:-0}" -eq 0 ]]; then
        issues=$((issues + 2))  # Heavier penalty
    fi

    # 3. Check for zod validation in API routes
    local api_files
    api_files=$(find "$project_dir/src" -path "*/api/*" -name "*.ts" 2>/dev/null | wc -l | tr -d ' ')
    local zod_in_api
    zod_in_api=$(grep -rl "z\.\(object\|string\|number\)" "$project_dir/src" --include="*.ts" 2>/dev/null | wc -l | tr -d ' ')
    if [[ "${api_files:-0}" -gt 0 && "${zod_in_api:-0}" -eq 0 ]]; then
        issues=$((issues + 1))
    fi

    # 4. Check for consistent error response format
    local error_format_count
    error_format_count=$(grep -r "success.*false.*error" "$project_dir/src" --include="*.ts" 2>/dev/null | wc -l | tr -d ' ')
    local raw_error_count
    raw_error_count=$(grep -rE "res\.(status|send)\(.*error" "$project_dir/src" --include="*.ts" 2>/dev/null | grep -v "success" | wc -l | tr -d ' ')
    if [[ "${raw_error_count:-0}" -gt "${error_format_count:-0}" ]]; then
        issues=$((issues + 1))
    fi

    # 5. Check for error boundary (React)
    local error_boundary
    error_boundary=$(find "$project_dir/src" -name "error.tsx" -o -name "ErrorBoundary.tsx" 2>/dev/null | wc -l | tr -d ' ')
    [[ "${error_boundary:-0}" -eq 0 ]] && issues=$((issues + 1))

    # 6. Check for force unwrap abuse in Swift files
    local swift_file_count
    swift_file_count=$(find "$project_dir" -name "*.swift" -not -path "*/.build/*" -not -path "*/DerivedData/*" -not -path "*/.git/*" -not -path "*Test*" 2>/dev/null | wc -l | tr -d ' ')
    if [[ "${swift_file_count:-0}" -gt 0 ]]; then
        local force_unwrap_count
        force_unwrap_count=$(grep -r '![^=]' "$project_dir" --include="*.swift" 2>/dev/null | grep -vE '(//|/\*|\*|!=|Test|Spec|Preview)' | grep -cE '\w+!' 2>/dev/null | tr -d ' ')
        [[ -z "$force_unwrap_count" ]] && force_unwrap_count=0
        if [[ "${force_unwrap_count:-0}" -gt 5 ]]; then
            issues=$((issues + 2))  # Heavy penalty for excessive force unwraps
        elif [[ "${force_unwrap_count:-0}" -gt 0 ]]; then
            issues=$((issues + 1))
        fi
    fi

    # Calculate score: deduct per issue, min 0
    score=$((100 - issues * 15))
    [[ "$score" -lt 0 ]] && score=0

    _QG_SCORES[5]="$score"
    echo "$score"
}

# ============================================================
# Calculate Weighted Score
# ============================================================
qg_calculate_score() {
    local s1="${_QG_SCORES[0]:-0}"
    local s2="${_QG_SCORES[1]:-0}"
    local s3="${_QG_SCORES[2]:-0}"
    local s4="${_QG_SCORES[3]:-0}"
    local s5="${_QG_SCORES[4]:-0}"
    local s6="${_QG_SCORES[5]:-100}"  # v31.0: Enterprise patterns (default 100 if not checked)

    local weighted=$(( \
        (s1 * QG_WEIGHT_MOCK + \
         s2 * QG_WEIGHT_HANDLERS + \
         s3 * QG_WEIGHT_DB + \
         s4 * QG_WEIGHT_API + \
         s5 * QG_WEIGHT_CRUD + \
         s6 * QG_WEIGHT_ENTERPRISE) / 100 ))

    echo "$weighted"
}

# ============================================================
# Generate Quality Report (JSON)
# ============================================================
qg_generate_report() {
    local project_dir="$1"
    local total_score="$2"
    local threshold="${3:-$QG_DEFAULT_THRESHOLD}"
    local report_file="${SESSION_LOG_DIR:-/tmp}/quality_gate_report.json"

    local status="PASS"
    [[ "$total_score" -lt "$QG_WARN_THRESHOLD" ]] && status="FAIL"
    [[ "$total_score" -ge "$QG_WARN_THRESHOLD" && "$total_score" -lt "$threshold" ]] && status="WARNING"

    local findings_json="["
    local first=1
    for finding in "${_QG_FINDINGS[@]}"; do
        [[ $first -eq 0 ]] && findings_json+=","
        first=0
        # Escape special characters for JSON (backslashes first, then quotes)
        local escaped
        escaped=$(echo "$finding" | sed 's/\\/\\\\/g; s/"/\\"/g')
        findings_json+="\"${escaped}\""
    done
    findings_json+="]"

    cat > "$report_file" <<EOF
{
    "version": "${QG_VERSION}",
    "timestamp": "$(date -u '+%Y-%m-%dT%H:%M:%SZ')",
    "project": "${project_dir}",
    "status": "${status}",
    "total_score": ${total_score},
    "threshold": ${threshold},
    "axes": {
        "mock_data": {"score": ${_QG_SCORES[0]:-0}, "weight": ${QG_WEIGHT_MOCK}},
        "event_handlers": {"score": ${_QG_SCORES[1]:-0}, "weight": ${QG_WEIGHT_HANDLERS}},
        "db_integration": {"score": ${_QG_SCORES[2]:-0}, "weight": ${QG_WEIGHT_DB}},
        "api_connections": {"score": ${_QG_SCORES[3]:-0}, "weight": ${QG_WEIGHT_API}},
        "crud_completeness": {"score": ${_QG_SCORES[4]:-0}, "weight": ${QG_WEIGHT_CRUD}}
    },
    "findings": ${findings_json},
    "findings_count": ${#_QG_FINDINGS[@]}
}
EOF

    _QG_REPORT_FILE="$report_file"
    echo "$report_file"
}

# ============================================================
# Display ASCII Quality Dashboard
# ============================================================
qg_display_dashboard() {
    local total_score="$1"
    local threshold="${2:-$QG_DEFAULT_THRESHOLD}"

    local RED='\033[0;31m'
    local GREEN='\033[0;32m'
    local YELLOW='\033[1;33m'
    local CYAN='\033[0;36m'
    local BOLD='\033[1m'
    local NC='\033[0m'

    local status_color="$GREEN"
    local status_text="PASS"
    if [[ "$total_score" -lt "$QG_WARN_THRESHOLD" ]]; then
        status_color="$RED"
        status_text="FAIL"
    elif [[ "$total_score" -lt "$threshold" ]]; then
        status_color="$YELLOW"
        status_text="WARNING"
    fi

    echo ""
    echo -e "${BOLD}╔═══════════════════════════════════════════════════════════╗${NC}"
    echo -e "${BOLD}║        Quality Gate v${QG_VERSION} - 品質ゲート結果               ║${NC}"
    echo -e "${BOLD}╠═══════════════════════════════════════════════════════════╣${NC}"

    # Score bar
    local bar_len=40
    local filled=$(( (total_score * bar_len) / 100 ))
    [[ $filled -gt $bar_len ]] && filled=$bar_len
    local empty=$((bar_len - filled))
    local bar=""
    for ((i=0; i<filled; i++)); do bar+="█"; done
    for ((i=0; i<empty; i++)); do bar+="░"; done

    printf "║  総合スコア: ${status_color}%3d/100${NC} [${status_color}%s${NC}] ${status_color}%s${NC}  ║\n" \
        "$total_score" "$bar" "$status_text"

    echo -e "${BOLD}╠───────────────────────────────────────────────────────────╣${NC}"

    # Per-axis scores
    local axes=("モックデータ" "ハンドラ  " "DB統合    " "API接続   " "CRUD完全性")
    local weights=($QG_WEIGHT_MOCK $QG_WEIGHT_HANDLERS $QG_WEIGHT_DB $QG_WEIGHT_API $QG_WEIGHT_CRUD)

    for i in 0 1 2 3 4; do
        local s="${_QG_SCORES[$i]:-0}"
        local w="${weights[$i]}"
        local c="$GREEN"
        [[ "$s" -lt 60 ]] && c="$RED"
        [[ "$s" -ge 60 && "$s" -lt 80 ]] && c="$YELLOW"

        local axis_bar_len=25
        local axis_filled=$(( (s * axis_bar_len) / 100 ))
        [[ $axis_filled -gt $axis_bar_len ]] && axis_filled=$axis_bar_len
        local axis_empty=$((axis_bar_len - axis_filled))
        local axis_bar=""
        for ((j=0; j<axis_filled; j++)); do axis_bar+="▓"; done
        for ((j=0; j<axis_empty; j++)); do axis_bar+="░"; done

        printf "║  ${axes[$i]} (w=%2d): ${c}%3d${NC} [${c}%s${NC}]  ║\n" \
            "$w" "$s" "$axis_bar"
    done

    echo -e "${BOLD}╠───────────────────────────────────────────────────────────╣${NC}"

    # Findings summary
    local finding_count=${#_QG_FINDINGS[@]}
    if [[ $finding_count -gt 0 ]]; then
        echo -e "║  ${RED}検出事項: ${finding_count}件${NC}                                        ║"
        local shown=0
        for finding in "${_QG_FINDINGS[@]}"; do
            [[ $shown -ge 8 ]] && break
            # Truncate long findings
            local display="${finding:0:55}"
            printf "║    ${YELLOW}• %-55s${NC}║\n" "$display"
            shown=$((shown + 1))
        done
        if [[ $finding_count -gt 8 ]]; then
            printf "║    ${YELLOW}... 他 %d件${NC}                                          ║\n" $((finding_count - 8))
        fi
    else
        echo -e "║  ${GREEN}検出事項: なし - 全品質基準をクリア${NC}                    ║"
    fi

    echo -e "${BOLD}╚═══════════════════════════════════════════════════════════╝${NC}"
    echo ""
}

# ============================================================
# Get findings for functional healer
# ============================================================
qg_get_findings() {
    printf '%s\n' "${_QG_FINDINGS[@]}"
}

qg_get_findings_json() {
    local json="["
    local first=1
    for finding in "${_QG_FINDINGS[@]}"; do
        [[ $first -eq 0 ]] && json+=","
        first=0
        local escaped
        escaped=$(echo "$finding" | sed 's/\\/\\\\/g; s/"/\\"/g')
        json+="\"${escaped}\""
    done
    json+="]"
    echo "$json"
}

qg_get_report_file() {
    echo "${_QG_REPORT_FILE:-}"
}

# ============================================================
# Main Entry Point
# ============================================================
qg_run_quality_gate() {
    local project_dir="${1:-.}"
    local threshold="${2:-$QG_DEFAULT_THRESHOLD}"

    # Validate project directory
    if [[ ! -d "$project_dir" ]]; then
        _qg_log "ERROR" "プロジェクトディレクトリが存在しません: ${project_dir}"
        return 1
    fi

    _qg_log "INFO" "═══ Quality Gate v${QG_VERSION} 開始 ═══"
    _qg_log "INFO" "プロジェクト: ${project_dir}"
    _qg_log "INFO" "閾値: ${threshold}"

    # Reset state
    _QG_PROJECT_DIR="$project_dir"
    _QG_FINDINGS=()
    _QG_SCORES=()
    _QG_REPORT_FILE=""

    # Run all 5 axes
    qg_check_mock_data "$project_dir" > /dev/null
    qg_check_event_handlers "$project_dir" > /dev/null
    qg_check_db_integration "$project_dir" > /dev/null
    qg_check_api_connections "$project_dir" > /dev/null
    qg_check_crud_completeness "$project_dir" > /dev/null

    # Calculate weighted total
    local total_score
    total_score=$(qg_calculate_score)

    # Generate report
    qg_generate_report "$project_dir" "$total_score" "$threshold" > /dev/null

    # Display dashboard
    qg_display_dashboard "$total_score" "$threshold"

    # Record observatory event
    if type -t obs_record_event &>/dev/null; then
        obs_record_event "QUALITY_GATE" "{\"score\": ${total_score}, \"threshold\": ${threshold}, \"findings\": ${#_QG_FINDINGS[@]}}"
    fi

    _qg_log "INFO" "═══ Quality Gate 完了: スコア=${total_score}, 閾値=${threshold} ═══"

    # Return pass/fail
    if [[ "$total_score" -ge "$threshold" ]]; then
        return 0
    else
        return 1
    fi
}

# ============================================================
# Quick check (lighter version for iteration loops)
# ============================================================
qg_quick_check() {
    local project_dir="${1:-.}"

    _QG_FINDINGS=()
    _QG_SCORES=()

    qg_check_mock_data "$project_dir" > /dev/null
    qg_check_db_integration "$project_dir" > /dev/null

    local mock_score="${_QG_SCORES[0]:-0}"
    local db_score="${_QG_SCORES[2]:-0}"

    local quick_score=$(( (mock_score + db_score) / 2 ))
    echo "$quick_score"
}
