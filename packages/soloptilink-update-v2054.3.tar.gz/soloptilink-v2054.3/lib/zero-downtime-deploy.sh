#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v325.0 - Zero-Downtime Deployment Engine
# =============================================================================
# Blue/Green、Canary、Rolling Update戦略の自動生成。
# ヘルスチェック、ロールバック、トラフィック分割を含む。
#
# Functions:
#   _zdd_init()               - Initialize
#   _zdd_generate_blue_green() - Blue/Green deployment config
#   _zdd_generate_canary()    - Canary deployment with traffic splitting
#   _zdd_generate_rolling()   - Rolling update strategy
#   _zdd_report() / _zdd_score()
# =============================================================================

[[ -n "${_ZDD_LOADED:-}" ]] && return 0; _ZDD_LOADED=1

readonly _ZDD_RED='\033[0;31m'
readonly _ZDD_GREEN='\033[0;32m'
readonly _ZDD_YELLOW='\033[0;33m'
readonly _ZDD_CYAN='\033[0;36m'
readonly _ZDD_NC='\033[0m'

declare -g ZDD_VERSION="325.0"
ZDD_GENERATED=0
ZDD_ERRORS=0
ZDD_FILES_WRITTEN=0
ZDD_BLUE_GREEN_OK=false
ZDD_CANARY_OK=false
ZDD_ROLLING_OK=false

_zdd_init() {
    ZDD_GENERATED=0; ZDD_ERRORS=0; ZDD_FILES_WRITTEN=0
    ZDD_BLUE_GREEN_OK=false; ZDD_CANARY_OK=false; ZDD_ROLLING_OK=false
    echo -e "  ${_ZDD_GREEN}OK${_ZDD_NC} Zero-Downtime Deploy v${ZDD_VERSION}" >&2
    return 0
}

_zdd_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { ZDD_FILES_WRITTEN=$((ZDD_FILES_WRITTEN + 1)); return 0; }
    ZDD_ERRORS=$((ZDD_ERRORS + 1)); return 1
}

_zdd_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_ZDD_CYAN}[deploy]${_ZDD_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_ZDD_GREEN}[deploy]${_ZDD_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_ZDD_YELLOW}[deploy]${_ZDD_NC} $msg" >&2 ;;
        error) echo -e "  ${_ZDD_RED}[deploy]${_ZDD_NC} $msg" >&2 ;;
    esac
}

# =============================================================================
# Blue/Green Deployment
# =============================================================================
_zdd_generate_blue_green() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local deploy_dir="${project_dir}/deploy"

    _zdd_log info "Generating Blue/Green deployment config..."

    _zdd_write_file "${deploy_dir}/blue-green.sh" '#!/usr/bin/env bash
# Blue/Green Deployment Script (Auto-Generated)
set -euo pipefail

CLUSTER="${CLUSTER_NAME:-app-cluster}"
SERVICE="${SERVICE_NAME:-app-service}"
REGION="${AWS_REGION:-ap-northeast-1}"
IMAGE_TAG="${IMAGE_TAG:-latest}"
HEALTH_PATH="${HEALTH_PATH:-/api/health}"
ROLLBACK_TIMEOUT=300

log() { echo "[$(date +%H:%M:%S)] $*"; }

# Step 1: Deploy to green environment
log "Deploying new version (green) with tag: ${IMAGE_TAG}"
GREEN_TG_ARN=$(aws elbv2 describe-target-groups \
  --names "${SERVICE}-green" --region "$REGION" \
  --query "TargetGroups[0].TargetGroupArn" --output text 2>/dev/null || echo "")

if [[ -z "$GREEN_TG_ARN" ]]; then
  log "ERROR: Green target group not found"
  exit 1
fi

# Step 2: Update green task definition
TASK_DEF=$(aws ecs describe-services --cluster "$CLUSTER" --services "${SERVICE}-green" \
  --region "$REGION" --query "services[0].taskDefinition" --output text)

NEW_TASK_DEF=$(aws ecs register-task-definition \
  --cli-input-json "$(aws ecs describe-task-definition --task-definition "$TASK_DEF" \
    --region "$REGION" --query taskDefinition | \
    jq ".containerDefinitions[0].image=\"${IMAGE_TAG}\"" | \
    jq "del(.taskDefinitionArn,.revision,.status,.registeredAt,.registeredBy,.requiresAttributes,.compatibilities)")" \
  --region "$REGION" --query "taskDefinition.taskDefinitionArn" --output text)

aws ecs update-service --cluster "$CLUSTER" --service "${SERVICE}-green" \
  --task-definition "$NEW_TASK_DEF" --region "$REGION" > /dev/null

# Step 3: Wait for green to be healthy
log "Waiting for green environment to become healthy..."
SECONDS=0
while [[ $SECONDS -lt $ROLLBACK_TIMEOUT ]]; do
  HEALTH=$(aws elbv2 describe-target-health --target-group-arn "$GREEN_TG_ARN" \
    --region "$REGION" --query "TargetHealthDescriptions[0].TargetHealth.State" --output text 2>/dev/null)
  [[ "$HEALTH" == "healthy" ]] && break
  sleep 10
done

if [[ "$HEALTH" != "healthy" ]]; then
  log "ERROR: Green environment failed health check. Aborting."
  exit 1
fi

# Step 4: Switch traffic from blue to green
log "Switching traffic to green environment..."
LISTENER_ARN=$(aws elbv2 describe-listeners --load-balancer-arn "$LB_ARN" \
  --region "$REGION" --query "Listeners[0].ListenerArn" --output text)

aws elbv2 modify-listener --listener-arn "$LISTENER_ARN" \
  --default-actions "Type=forward,TargetGroupArn=${GREEN_TG_ARN}" \
  --region "$REGION" > /dev/null

log "Blue/Green deployment complete. Green is now live."
'

    _zdd_log ok "Blue/Green deployment script generated"
    ZDD_BLUE_GREEN_OK=true
    ZDD_GENERATED=$((ZDD_GENERATED + 1))
    return 0
}

# =============================================================================
# Canary Deployment
# =============================================================================
_zdd_generate_canary() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local deploy_dir="${project_dir}/deploy"

    _zdd_log info "Generating Canary deployment config..."

    _zdd_write_file "${deploy_dir}/canary.sh" '#!/usr/bin/env bash
# Canary Deployment Script (Auto-Generated)
set -euo pipefail

CLUSTER="${CLUSTER_NAME:-app-cluster}"
SERVICE="${SERVICE_NAME:-app-service}"
REGION="${AWS_REGION:-ap-northeast-1}"
IMAGE_TAG="${IMAGE_TAG:-latest}"
CANARY_WEIGHT_STEPS=(5 10 25 50 100)
STEP_WAIT=120
ERROR_THRESHOLD=5

log() { echo "[$(date +%H:%M:%S)] $*"; }

# Deploy canary with weight 0
log "Deploying canary version: ${IMAGE_TAG}"

for weight in "${CANARY_WEIGHT_STEPS[@]}"; do
  log "Setting canary traffic weight to ${weight}%..."

  # Update ALB listener rule weights
  BLUE_WEIGHT=$((100 - weight))
  aws elbv2 modify-rule --rule-arn "$RULE_ARN" --region "$REGION" \
    --actions "[
      {\"Type\":\"forward\",\"ForwardConfig\":{\"TargetGroups\":[
        {\"TargetGroupArn\":\"${BLUE_TG_ARN}\",\"Weight\":${BLUE_WEIGHT}},
        {\"TargetGroupArn\":\"${CANARY_TG_ARN}\",\"Weight\":${weight}}
      ]}}
    ]" > /dev/null

  if [[ $weight -lt 100 ]]; then
    log "Monitoring canary for ${STEP_WAIT}s at ${weight}% traffic..."
    sleep "$STEP_WAIT"

    # Check error rate from CloudWatch
    ERROR_RATE=$(aws cloudwatch get-metric-data \
      --metric-data-queries "[{\"Id\":\"e1\",\"MetricStat\":{\"Metric\":{\"Namespace\":\"AWS/ApplicationELB\",\"MetricName\":\"HTTPCode_Target_5XX_Count\",\"Dimensions\":[{\"Name\":\"TargetGroup\",\"Value\":\"${CANARY_TG_NAME}\"}]},\"Period\":60,\"Stat\":\"Sum\"},\"ReturnData\":true}]" \
      --start-time "$(date -u -d '2 minutes ago' +%Y-%m-%dT%H:%M:%S)" \
      --end-time "$(date -u +%Y-%m-%dT%H:%M:%S)" \
      --region "$REGION" --query "MetricDataResults[0].Values[0]" --output text 2>/dev/null || echo 0)

    if [[ "${ERROR_RATE:-0}" -gt "$ERROR_THRESHOLD" ]]; then
      log "ERROR: Canary error rate ${ERROR_RATE}% exceeds threshold. Rolling back..."
      aws elbv2 modify-rule --rule-arn "$RULE_ARN" --region "$REGION" \
        --actions "[{\"Type\":\"forward\",\"ForwardConfig\":{\"TargetGroups\":[{\"TargetGroupArn\":\"${BLUE_TG_ARN}\",\"Weight\":100},{\"TargetGroupArn\":\"${CANARY_TG_ARN}\",\"Weight\":0}]}}]" > /dev/null
      exit 1
    fi
    log "Canary healthy at ${weight}%. Proceeding..."
  fi
done

log "Canary deployment complete. New version serving 100% traffic."
'

    _zdd_log ok "Canary deployment script generated"
    ZDD_CANARY_OK=true
    ZDD_GENERATED=$((ZDD_GENERATED + 1))
    return 0
}

# =============================================================================
# Rolling Update
# =============================================================================
_zdd_generate_rolling() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local deploy_dir="${project_dir}/deploy"

    _zdd_log info "Generating Rolling Update config..."

    _zdd_write_file "${deploy_dir}/rolling-update.sh" '#!/usr/bin/env bash
# Rolling Update Deployment Script (Auto-Generated)
set -euo pipefail

CLUSTER="${CLUSTER_NAME:-app-cluster}"
SERVICE="${SERVICE_NAME:-app-service}"
REGION="${AWS_REGION:-ap-northeast-1}"
IMAGE_TAG="${IMAGE_TAG:-latest}"
DEPLOY_TIMEOUT=600

log() { echo "[$(date +%H:%M:%S)] $*"; }

log "Starting rolling update to ${IMAGE_TAG}..."

# Register new task definition
CURRENT_TASK=$(aws ecs describe-services --cluster "$CLUSTER" --services "$SERVICE" \
  --region "$REGION" --query "services[0].taskDefinition" --output text)

NEW_TASK=$(aws ecs register-task-definition \
  --cli-input-json "$(aws ecs describe-task-definition --task-definition "$CURRENT_TASK" \
    --region "$REGION" --query taskDefinition | \
    jq ".containerDefinitions[0].image=\"${IMAGE_TAG}\"" | \
    jq "del(.taskDefinitionArn,.revision,.status,.registeredAt,.registeredBy,.requiresAttributes,.compatibilities)")" \
  --region "$REGION" --query "taskDefinition.taskDefinitionArn" --output text)

# Update service (ECS handles rolling update via deployment config)
aws ecs update-service --cluster "$CLUSTER" --service "$SERVICE" \
  --task-definition "$NEW_TASK" \
  --deployment-configuration "maximumPercent=200,minimumHealthyPercent=100" \
  --region "$REGION" > /dev/null

log "Waiting for deployment to stabilize (timeout: ${DEPLOY_TIMEOUT}s)..."
aws ecs wait services-stable --cluster "$CLUSTER" --services "$SERVICE" \
  --region "$REGION" 2>/dev/null

if [[ $? -eq 0 ]]; then
  log "Rolling update completed successfully."
else
  log "ERROR: Deployment did not stabilize. Check ECS console."
  exit 1
fi
'

    _zdd_log ok "Rolling update config generated"
    ZDD_ROLLING_OK=true
    ZDD_GENERATED=$((ZDD_GENERATED + 1))
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_zdd_report() {
    echo -e "\n  ${_ZDD_CYAN}=== Zero-Downtime Deploy v${ZDD_VERSION} ===${_ZDD_NC}"
    echo -e "  Generated: ${ZDD_GENERATED} | Files: ${ZDD_FILES_WRITTEN} | Errors: ${ZDD_ERRORS}"
    echo -e "  Blue/Green: $( ${ZDD_BLUE_GREEN_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Canary: $( ${ZDD_CANARY_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Rolling: $( ${ZDD_ROLLING_OK} && echo 'OK' || echo 'SKIP')"
}

_zdd_score() {
    local score=50
    ${ZDD_BLUE_GREEN_OK} && score=$((score + 15))
    ${ZDD_CANARY_OK} && score=$((score + 15))
    ${ZDD_ROLLING_OK} && score=$((score + 15))
    [[ ${ZDD_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "zero-downtime-deploy" --version "325.0" \
        --description "ゼロダウンタイムデプロイ Blue/Green/Canary/Rolling (v325)" \
        --init "_zdd_init" --report "_zdd_report" --score "_zdd_score" \
        --enable-var "ENABLE_ZERO_DOWNTIME" --cli-flags "--zero-downtime:--no-zero-downtime"
fi

# v2003.1: source時のexit codeを確実に0にする
true
