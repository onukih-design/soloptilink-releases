#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v254.0 - Multi-Strategy Fixer
# =============================================================================
# 1つのエラーに対して3つの異なる修正戦略を生成し、最適なものを選択する。
#
# 問題: 単一の修正アプローチだと失敗した場合にリトライが非効率。
#   - Quick fixが根本解決にならず再発する
#   - Proper fixがリスクが高すぎて適用をためらう
#   - 防御的修正が過剰で不要なコード増加を招く
#
# 解決: 常に3戦略を並行生成し、コンテキスト（緊急度/リスク/スコープ）に
#   応じて最適戦略を選択する。
#
# Functions:
#   msf_init                  - 初期化
#   _msf_generate_strategies  - 3つの修正戦略を生成
#   _msf_strategy_quick_fix   - Quick Fix: 最小限の変更
#   _msf_strategy_proper_fix  - Proper Fix: 根本原因を修正
#   _msf_strategy_defensive_fix - Defensive Fix: 再発防止ガード追加
#   _msf_select_best          - コンテキストに基づき最適戦略を選択
#   _msf_apply_strategy       - 選択した戦略のClaude修正プロンプトを生成
#   msf_report                - レポート出力
#   msf_score                 - モジュールスコア(0-100)
#
# All globals use the MSF_ prefix.
# =============================================================================

[[ -n "${_MULTI_STRATEGY_FIXER_LOADED:-}" ]] && return 0
_MULTI_STRATEGY_FIXER_LOADED=1

MSF_VERSION="254.0"
MSF_INITIALIZED=false

# --- Paths ---
MSF_CACHE_DIR=""
MSF_STRATEGY_LOG=""

# --- Counters ---
MSF_TOTAL_GENERATED=0
MSF_QUICK_SELECTED=0
MSF_PROPER_SELECTED=0
MSF_DEFENSIVE_SELECTED=0
MSF_TOTAL_APPLIED=0
MSF_TOTAL_SUCCESS=0

# --- Strategy types ---
readonly MSF_STRATEGY_QUICK="quick_fix"
readonly MSF_STRATEGY_PROPER="proper_fix"
readonly MSF_STRATEGY_DEFENSIVE="defensive_fix"

# --- In-memory storage ---
declare -g -A _MSF_STRATEGY_CACHE=()   # error_hash → strategies JSON
declare -g -A _MSF_OUTCOMES=()          # strategy_type::error_type → success:total

# =============================================================================
# msf_init - Initialize multi-strategy fixer
# =============================================================================
msf_init() {
    MSF_CACHE_DIR="${HOME}/.soloptilink/cache/msf"
    mkdir -p "$MSF_CACHE_DIR" 2>/dev/null || true

    MSF_STRATEGY_LOG="${MSF_CACHE_DIR}/strategy-log.jsonl"

    MSF_TOTAL_GENERATED=0
    MSF_QUICK_SELECTED=0
    MSF_PROPER_SELECTED=0
    MSF_DEFENSIVE_SELECTED=0
    MSF_TOTAL_APPLIED=0
    MSF_TOTAL_SUCCESS=0
    _MSF_STRATEGY_CACHE=()
    _MSF_OUTCOMES=()

    # Load historical outcomes
    _msf_load_outcomes

    MSF_INITIALIZED=true
    return 0
}

# =============================================================================
# _msf_detect_error_type - Detect error type for strategy generation
# Arguments:
#   $1 - error_message
# Returns:
#   error type string via stdout
# =============================================================================
_msf_detect_error_type() {
    local msg="${1:-}"

    if echo "$msg" | grep -qiE 'TypeError|Type.*not assignable|TS2[0-9]{3}'; then
        echo "type_error"
    elif echo "$msg" | grep -qiE 'Cannot find module|Module not found|import.*error'; then
        echo "import_error"
    elif echo "$msg" | grep -qiE 'PrismaClient|P[0-9]{4}|database|migration|unique constraint'; then
        echo "db_error"
    elif echo "$msg" | grep -qiE '404.*api|route.*not found|fetch.*failed|API.*error'; then
        echo "api_error"
    elif echo "$msg" | grep -qiE 'Cannot read propert|undefined|null|ReferenceError'; then
        echo "null_access"
    elif echo "$msg" | grep -qiE 'Build error|Compilation.*failed|Failed to compile|webpack'; then
        echo "build_error"
    elif echo "$msg" | grep -qiE 'ZodError|validation.*failed|invalid.*input'; then
        echo "validation_error"
    elif echo "$msg" | grep -qiE 'ECONNREFUSED|network.*error|CORS|fetch.*fail'; then
        echo "network_error"
    elif echo "$msg" | grep -qiE 'config|\.env|tsconfig|missing.*env'; then
        echo "config_error"
    else
        echo "generic_error"
    fi
}

# =============================================================================
# _msf_extract_error_detail - Extract structured details from error
# Arguments:
#   $1 - error_message
# Returns:
#   file, function, identifier details via global vars
# =============================================================================
_MSF_ERR_FILE=""
_MSF_ERR_FUNC=""
_MSF_ERR_IDENTIFIER=""

_msf_extract_error_detail() {
    local msg="${1:-}"

    _MSF_ERR_FILE=$(echo "$msg" | grep -oE '[/.][a-zA-Z0-9_/.-]+\.(ts|tsx|js|jsx)' | head -1)
    [[ -z "$_MSF_ERR_FILE" ]] && _MSF_ERR_FILE=$(echo "$msg" | grep -oE '\./[a-zA-Z0-9_/.-]+' | head -1)

    _MSF_ERR_FUNC=$(echo "$msg" | grep -oE 'at ([a-zA-Z0-9_.]+)' | head -1 | sed 's/at //')

    # Extract key identifier (variable name, property name, module name)
    _MSF_ERR_IDENTIFIER=$(echo "$msg" | grep -oE "'[^']+'" | head -1 | tr -d "'")
    [[ -z "$_MSF_ERR_IDENTIFIER" ]] && _MSF_ERR_IDENTIFIER=$(echo "$msg" | grep -oE '"[^"]{1,50}"' | head -1 | tr -d '"')
}

# =============================================================================
# _msf_generate_strategies - Generate 3 fix strategies for an error
# Arguments:
#   $1 - error_message
#   $2 - error_category (from error-taxonomy-engine)
#   $3 - project_dir (optional)
# Returns:
#   JSON with 3 strategies via stdout
# =============================================================================
_msf_generate_strategies() {
    local error_message="${1:-}"
    local error_category="${2:-UNKNOWN}"
    local project_dir="${3:-.}"

    [[ -z "$error_message" ]] && echo '{"strategies":[]}' && return 1

    MSF_TOTAL_GENERATED=$((MSF_TOTAL_GENERATED + 1))

    local error_hash
    error_hash=$(echo "$error_message" | head -c 100 | cksum | awk '{print $1}')

    # Check cache
    if [[ -n "${_MSF_STRATEGY_CACHE[$error_hash]:-}" ]]; then
        echo "${_MSF_STRATEGY_CACHE[$error_hash]}"
        return 0
    fi

    # Detect error type and extract details
    local error_type
    error_type=$(_msf_detect_error_type "$error_message")
    _msf_extract_error_detail "$error_message"

    # Generate 3 strategies
    local quick_fix proper_fix defensive_fix
    quick_fix=$(_msf_strategy_quick_fix "$error_message" "$error_type" "$project_dir")
    proper_fix=$(_msf_strategy_proper_fix "$error_message" "$error_type" "$project_dir")
    defensive_fix=$(_msf_strategy_defensive_fix "$error_message" "$error_type" "$project_dir")

    local result
    result=$(cat <<EOF
{
  "error_type": "${error_type}",
  "error_category": "${error_category}",
  "strategies": [
    ${quick_fix},
    ${proper_fix},
    ${defensive_fix}
  ]
}
EOF
)

    _MSF_STRATEGY_CACHE["$error_hash"]="$result"
    echo "$result"
    return 0
}

# =============================================================================
# _msf_strategy_quick_fix - Generate minimal/quick fix strategy
# Arguments:
#   $1 - error_message
#   $2 - error_type
#   $3 - project_dir
# Returns:
#   JSON strategy object via stdout
# =============================================================================
_msf_strategy_quick_fix() {
    local error_message="${1:-}"
    local error_type="${2:-generic}"
    local project_dir="${3:-.}"

    local fix_desc=""
    local fix_target=""
    local fix_lines=0
    local fix_risk="low"
    local fix_time="short"

    case "$error_type" in
        "type_error")
            if [[ -n "$_MSF_ERR_IDENTIFIER" ]]; then
                fix_desc="型アサーション(as)を使って型エラーを解消: '${_MSF_ERR_IDENTIFIER}' に適切な型キャストを追加"
                fix_target="${_MSF_ERR_FILE:-}"
                fix_lines=2
            else
                fix_desc="any型キャストで型エラーを即座に解消（TODO: 後で適切な型に修正）"
                fix_target="${_MSF_ERR_FILE:-}"
                fix_lines=1
            fi
            ;;
        "import_error")
            fix_desc="不足しているimport文を追加するか、存在するパスにimportを修正"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=1
            ;;
        "null_access")
            fix_desc="オプショナルチェーニング(?.)を追加してnull/undefinedアクセスを回避"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=1
            ;;
        "db_error")
            if echo "$error_message" | grep -qiE 'unique constraint'; then
                fix_desc="try-catchでユニーク制約違反をキャッチし、適切なエラーレスポンスを返す"
                fix_target="${_MSF_ERR_FILE:-}"
                fix_lines=5
            else
                fix_desc="DBエラーをキャッチして適切なエラーメッセージを返す"
                fix_target="${_MSF_ERR_FILE:-}"
                fix_lines=5
            fi
            ;;
        "api_error")
            local api_path
            api_path=$(echo "$error_message" | grep -oE '/api/[a-zA-Z0-9/_-]+' | head -1)
            if [[ -n "$api_path" ]]; then
                fix_desc="不足しているAPIルート ${api_path}/route.ts を最小限のハンドラで作成"
                fix_target="app${api_path}/route.ts"
                fix_lines=15
            else
                fix_desc="fetchのURLパスを正しいAPIエンドポイントに修正"
                fix_target="${_MSF_ERR_FILE:-}"
                fix_lines=1
            fi
            ;;
        "build_error")
            fix_desc="構文エラーを修正（未閉じ括弧、セミコロン欠落、不正なJSX等）"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=2
            ;;
        "validation_error")
            fix_desc="zodスキーマにoptional()を追加して必須フィールドエラーを回避"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=2
            ;;
        "network_error")
            fix_desc="fetch呼び出しにtry-catchを追加してネットワークエラーをハンドリング"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=5
            ;;
        "config_error")
            local missing_var
            missing_var=$(echo "$error_message" | grep -oE '[A-Z_]{3,}' | head -1)
            if [[ -n "$missing_var" ]]; then
                fix_desc="環境変数 ${missing_var} にデフォルト値を設定（process.env.${missing_var} || 'default'）"
            else
                fix_desc="設定ファイルの不足エントリを追加"
            fi
            fix_target=".env"
            fix_lines=1
            ;;
        *)
            fix_desc="エラー箇所にtry-catchを追加してエラーをログ出力+グレースフルに処理"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=5
            ;;
    esac

    cat <<EOF
{
    "strategy": "${MSF_STRATEGY_QUICK}",
    "label": "Quick Fix",
    "description": "$(echo "$fix_desc" | sed 's/"/\\"/g')",
    "target_file": "${fix_target:-}",
    "estimated_lines": ${fix_lines},
    "risk": "${fix_risk}",
    "time": "${fix_time}",
    "pros": "最速で修正完了。変更量最小。",
    "cons": "根本解決にならない可能性。技術的負債になりうる。"
}
EOF
    return 0
}

# =============================================================================
# _msf_strategy_proper_fix - Generate proper/thorough fix strategy
# Arguments:
#   $1 - error_message
#   $2 - error_type
#   $3 - project_dir
# Returns:
#   JSON strategy object via stdout
# =============================================================================
_msf_strategy_proper_fix() {
    local error_message="${1:-}"
    local error_type="${2:-generic}"
    local project_dir="${3:-.}"

    local fix_desc=""
    local fix_target=""
    local fix_lines=0
    local fix_risk="medium"
    local fix_time="medium"
    local additional_files=""

    case "$error_type" in
        "type_error")
            fix_desc="型定義ファイルを修正して正しい型をexport。Prismaスキーマと同期させ、zodスキーマも更新。"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=15

            # Find related type files
            if [[ -n "$_MSF_ERR_IDENTIFIER" ]]; then
                local type_files
                type_files=$(grep -rlE "(interface|type) .*${_MSF_ERR_IDENTIFIER}" "$project_dir" \
                    --include="*.ts" --include="*.tsx" 2>/dev/null | grep -v node_modules | head -3 | tr '\n' ',')
                additional_files="${type_files%,}"
            fi
            ;;
        "import_error")
            local missing_module
            missing_module=$(echo "$error_message" | grep -oE "'[^']+'" | head -1 | tr -d "'")
            fix_desc="不足しているモジュール '${missing_module}' を作成し、必要なexportを定義。tsconfig.jsonのpaths設定も確認・修正。"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=20
            additional_files="tsconfig.json"
            ;;
        "null_access")
            fix_desc="データソース（API/props/state）からのデータ取得部分を修正。loading/error状態を追加し、データが存在しない場合のフォールバックUIを実装。"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=25
            ;;
        "db_error")
            fix_desc="Prismaスキーマを正しく定義し直し、npx prisma generateで型を再生成。クエリロジックをトランザクションで囲みエラーハンドリングを追加。"
            fix_target="prisma/schema.prisma"
            fix_lines=20
            additional_files="${_MSF_ERR_FILE:-}"
            fix_risk="high"
            fix_time="long"
            ;;
        "api_error")
            local api_path
            api_path=$(echo "$error_message" | grep -oE '/api/[a-zA-Z0-9/_-]+' | head -1)
            fix_desc="APIルート ${api_path:-/api/xxx}/route.tsを完全実装。Prismaクエリ、zodバリデーション、エラーハンドリング、適切なHTTPステータスコードを含む。"
            fix_target="app${api_path:-/api}/route.ts"
            fix_lines=50
            fix_risk="medium"
            fix_time="long"
            ;;
        "build_error")
            fix_desc="構文エラーの根本原因（不正なJSXパターン、不整合なインデント、未解決の型参照等）を特定し修正。ESLint設定も確認。"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=10
            additional_files=".eslintrc*,tsconfig.json"
            ;;
        "validation_error")
            fix_desc="zodスキーマをPrismaスキーマと完全同期。フロントエンドのフォームバリデーションもzodスキーマを共有するよう統一。"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=30
            additional_files="prisma/schema.prisma"
            ;;
        "network_error")
            fix_desc="API接続層を修正。ベースURL設定の確認、CORSヘッダー設定、リトライロジック（exponential backoff）を実装。"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=30
            additional_files="next.config.*,middleware.ts"
            fix_time="long"
            ;;
        "config_error")
            fix_desc="環境変数をzodでバリデーション。.env.exampleを更新。不足変数のデフォルト値設定と起動時チェックを追加。"
            fix_target=".env"
            fix_lines=20
            additional_files="lib/env.ts,.env.example"
            ;;
        *)
            fix_desc="エラーの根本原因を分析し、適切なエラーハンドリングパターン（ErrorBoundary、try-catch、バリデーション）を適用。"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=20
            ;;
    esac

    cat <<EOF
{
    "strategy": "${MSF_STRATEGY_PROPER}",
    "label": "Proper Fix",
    "description": "$(echo "$fix_desc" | sed 's/"/\\"/g')",
    "target_file": "${fix_target:-}",
    "additional_files": "${additional_files:-}",
    "estimated_lines": ${fix_lines},
    "risk": "${fix_risk}",
    "time": "${fix_time}",
    "pros": "根本原因を解決。再発しない。コード品質向上。",
    "cons": "変更量が多い。他の機能に影響する可能性。"
}
EOF
    return 0
}

# =============================================================================
# _msf_strategy_defensive_fix - Generate defensive fix strategy
# Arguments:
#   $1 - error_message
#   $2 - error_type
#   $3 - project_dir
# Returns:
#   JSON strategy object via stdout
# =============================================================================
_msf_strategy_defensive_fix() {
    local error_message="${1:-}"
    local error_type="${2:-generic}"
    local project_dir="${3:-.}"

    local fix_desc=""
    local fix_target=""
    local fix_lines=0
    local fix_risk="low"
    local fix_time="medium"
    local guard_type=""

    case "$error_type" in
        "type_error")
            fix_desc="ランタイム型チェック(zod.parse)を追加し、型不一致を事前検出。TypeScript strict modeを有効化。型ガード関数を作成。"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=20
            guard_type="type_guard+runtime_validation"
            ;;
        "import_error")
            fix_desc="動的importをtry-catchで囲み、モジュール不在時のフォールバック動作を定義。パス解決のユーティリティ関数を作成。"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=15
            guard_type="dynamic_import_guard"
            ;;
        "null_access")
            fix_desc="全データアクセスポイントにnullチェック/デフォルト値を追加。TypeScriptのstrictNullChecksを有効化。Null Object Patternを適用。"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=25
            guard_type="null_guard+default_values"
            ;;
        "db_error")
            fix_desc="DB操作をトランザクションで囲み、リトライロジックを追加。接続ヘルスチェックを実装。DB操作のラッパー関数でエラーを統一処理。"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=40
            guard_type="transaction+retry+health_check"
            fix_time="long"
            ;;
        "api_error")
            fix_desc="API呼び出し層にインターセプター(レスポンス検証/リトライ/キャッシュフォールバック)を追加。APIルートにバリデーションミドルウェアを設置。"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=40
            guard_type="interceptor+validation_middleware"
            fix_time="long"
            ;;
        "build_error")
            fix_desc="pre-commitフックでtsc --noEmitとESLintを実行するよう設定。CI/CDパイプラインにビルドチェックステップを追加。"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=15
            guard_type="pre_commit+ci_check"
            ;;
        "validation_error")
            fix_desc="API全エンドポイントにzodミドルウェアを追加。フロントエンドのフォーム送信前にクライアントサイドバリデーションを強制。"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=30
            guard_type="zod_middleware+client_validation"
            ;;
        "network_error")
            fix_desc="サーキットブレーカーパターンを実装。ネットワーク障害時のキャッシュフォールバックとユーザーへの明示的エラー表示を追加。"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=35
            guard_type="circuit_breaker+cache_fallback"
            fix_time="long"
            ;;
        "config_error")
            fix_desc="起動時に全環境変数をzodで厳格にバリデーション。不足時は明確なエラーメッセージで起動を中止。設定ドキュメントを自動生成。"
            fix_target="lib/env-validation.ts"
            fix_lines=25
            guard_type="startup_validation+documentation"
            ;;
        *)
            fix_desc="グローバルエラーハンドラーを設置。未捕捉例外のログ出力とグレースフルデグラデーションを実装。Error Boundaryを全ルートに配置。"
            fix_target="${_MSF_ERR_FILE:-}"
            fix_lines=30
            guard_type="global_error_handler+error_boundary"
            ;;
    esac

    cat <<EOF
{
    "strategy": "${MSF_STRATEGY_DEFENSIVE}",
    "label": "Defensive Fix",
    "description": "$(echo "$fix_desc" | sed 's/"/\\"/g')",
    "target_file": "${fix_target:-}",
    "guard_type": "${guard_type}",
    "estimated_lines": ${fix_lines},
    "risk": "${fix_risk}",
    "time": "${fix_time}",
    "pros": "再発防止。システム全体の堅牢性向上。",
    "cons": "コード量が増加。過剰防御になる可能性。"
}
EOF
    return 0
}

# =============================================================================
# _msf_select_best - Select best strategy based on context
# Arguments:
#   $1 - strategies_json (output of _msf_generate_strategies)
#   $2 - urgency ("low"|"medium"|"high"|"critical")
#   $3 - iteration (current fix loop iteration, 1-based)
#   $4 - remaining_budget_pct (0-100)
# Returns:
#   JSON with selected strategy and reasoning via stdout
# =============================================================================
_msf_select_best() {
    local strategies_json="${1:-}"
    local urgency="${2:-medium}"
    local iteration="${3:-1}"
    local budget_pct="${4:-100}"

    local selected="$MSF_STRATEGY_PROPER"
    local reasoning=""

    # Decision matrix
    # Critical urgency + first iteration → Quick fix
    if [[ "$urgency" == "critical" && $iteration -le 1 ]]; then
        selected="$MSF_STRATEGY_QUICK"
        reasoning="緊急度が高いため最速修正を選択（後でproper fixに昇格予定）"
    # Budget low → Quick fix to save resources
    elif [[ $budget_pct -lt 30 ]]; then
        selected="$MSF_STRATEGY_QUICK"
        reasoning="残り予算${budget_pct}%のため最小限修正を選択"
    # Multiple failed attempts → Defensive fix
    elif [[ $iteration -ge 3 ]]; then
        selected="$MSF_STRATEGY_DEFENSIVE"
        reasoning="${iteration}回目の修正試行。防御的修正で根本的に再発を防止。"
    # Second attempt → Proper fix
    elif [[ $iteration -ge 2 ]]; then
        selected="$MSF_STRATEGY_PROPER"
        reasoning="2回目の修正試行。根本原因を解決するproper fixを選択。"
    # Normal case → Proper fix
    elif [[ "$urgency" == "low" || "$urgency" == "medium" ]]; then
        selected="$MSF_STRATEGY_PROPER"
        reasoning="標準的な修正。根本原因を解決するproper fixを選択。"
    # High urgency first attempt → Quick fix
    elif [[ "$urgency" == "high" ]]; then
        selected="$MSF_STRATEGY_QUICK"
        reasoning="緊急度が高いためquick fixで素早く修正。"
    fi

    # Check historical outcomes for this error type
    local error_type
    error_type=$(echo "$strategies_json" | grep -oE '"error_type":"[^"]*"' | head -1 | sed 's/"error_type":"//;s/"//')

    if [[ -n "$error_type" ]]; then
        local quick_key="${MSF_STRATEGY_QUICK}::${error_type}"
        local proper_key="${MSF_STRATEGY_PROPER}::${error_type}"
        local defensive_key="${MSF_STRATEGY_DEFENSIVE}::${error_type}"

        # If selected strategy has poor history, switch
        local selected_key="${selected}::${error_type}"
        if [[ -n "${_MSF_OUTCOMES[$selected_key]:-}" ]]; then
            local s_succ s_total
            s_succ=$(echo "${_MSF_OUTCOMES[$selected_key]}" | cut -d: -f1)
            s_total=$(echo "${_MSF_OUTCOMES[$selected_key]}" | cut -d: -f2)
            if [[ $s_total -ge 3 ]]; then
                local s_rate=$(( (s_succ * 100) / s_total ))
                if [[ $s_rate -lt 30 ]]; then
                    # Switch to a better strategy
                    for alt_key in "$proper_key" "$defensive_key" "$quick_key"; do
                        local alt_strat
                        alt_strat=$(echo "$alt_key" | cut -d: -f1)
                        [[ "$alt_strat" == "$selected" ]] && continue

                        if [[ -n "${_MSF_OUTCOMES[$alt_key]:-}" ]]; then
                            local a_succ a_total
                            a_succ=$(echo "${_MSF_OUTCOMES[$alt_key]}" | cut -d: -f1)
                            a_total=$(echo "${_MSF_OUTCOMES[$alt_key]}" | cut -d: -f2)
                            if [[ $a_total -ge 2 ]]; then
                                local a_rate=$(( (a_succ * 100) / a_total ))
                                if [[ $a_rate -gt $s_rate ]]; then
                                    selected="$alt_strat"
                                    reasoning="過去データに基づき戦略を変更: ${selected}の成功率(${a_rate}%)が${selected}(${s_rate}%)より高い"
                                    break
                                fi
                            fi
                        fi
                    done
                fi
            fi
        fi
    fi

    # Extract the selected strategy details from the JSON
    local strategy_detail
    strategy_detail=$(echo "$strategies_json" | grep -oE "\{[^{}]*\"strategy\":\"${selected}\"[^{}]*\}" | head -1)

    # Update selection counters
    case "$selected" in
        "$MSF_STRATEGY_QUICK")     MSF_QUICK_SELECTED=$((MSF_QUICK_SELECTED + 1)) ;;
        "$MSF_STRATEGY_PROPER")    MSF_PROPER_SELECTED=$((MSF_PROPER_SELECTED + 1)) ;;
        "$MSF_STRATEGY_DEFENSIVE") MSF_DEFENSIVE_SELECTED=$((MSF_DEFENSIVE_SELECTED + 1)) ;;
    esac

    cat <<EOF
{
  "selected_strategy": "${selected}",
  "reasoning": "${reasoning}",
  "urgency": "${urgency}",
  "iteration": ${iteration},
  "budget_pct": ${budget_pct},
  "strategy_detail": ${strategy_detail:-{}}
}
EOF
    return 0
}

# =============================================================================
# _msf_apply_strategy - Generate Claude fix prompt for the selected strategy
# Arguments:
#   $1 - error_message
#   $2 - selected_strategy_json (output of _msf_select_best)
#   $3 - project_dir
#   $4 - additional_context (optional)
# Returns:
#   Fix prompt text via stdout
# =============================================================================
_msf_apply_strategy() {
    local error_message="${1:-}"
    local strategy_json="${2:-}"
    local project_dir="${3:-.}"
    local additional_context="${4:-}"

    MSF_TOTAL_APPLIED=$((MSF_TOTAL_APPLIED + 1))

    local selected
    selected=$(echo "$strategy_json" | grep -oE '"selected_strategy":"[^"]*"' | sed 's/"selected_strategy":"//;s/"//')

    local description
    description=$(echo "$strategy_json" | grep -oE '"description":"[^"]*"' | head -1 | sed 's/"description":"//;s/"//')

    local target_file
    target_file=$(echo "$strategy_json" | grep -oE '"target_file":"[^"]*"' | head -1 | sed 's/"target_file":"//;s/"//')

    local guard_type
    guard_type=$(echo "$strategy_json" | grep -oE '"guard_type":"[^"]*"' | head -1 | sed 's/"guard_type":"//;s/"//')

    # Build the fix prompt
    local prompt=""

    case "$selected" in
        "$MSF_STRATEGY_QUICK")
            prompt="【Quick Fix - 最小限修正】\n"
            prompt="${prompt}以下のエラーを最小限の変更で修正してください。\n\n"
            prompt="${prompt}エラー:\n${error_message}\n\n"
            prompt="${prompt}修正方針:\n${description}\n\n"
            prompt="${prompt}制約:\n"
            prompt="${prompt}- 変更は最小限（5行以内を目標）\n"
            prompt="${prompt}- 既存のコードパターンを維持\n"
            prompt="${prompt}- 新しいファイルの作成は避ける\n"
            if [[ -n "$target_file" ]]; then
                prompt="${prompt}- 修正対象ファイル: ${target_file}\n"
            fi
            ;;
        "$MSF_STRATEGY_PROPER")
            prompt="【Proper Fix - 根本原因修正】\n"
            prompt="${prompt}以下のエラーの根本原因を分析し、正しく修正してください。\n\n"
            prompt="${prompt}エラー:\n${error_message}\n\n"
            prompt="${prompt}修正方針:\n${description}\n\n"
            prompt="${prompt}要件:\n"
            prompt="${prompt}- 根本原因を特定し解決すること\n"
            prompt="${prompt}- 型安全を維持すること\n"
            prompt="${prompt}- 関連する全ファイルを整合させること\n"
            prompt="${prompt}- テストが必要な場合はテストも更新\n"
            if [[ -n "$target_file" ]]; then
                prompt="${prompt}- 主な修正対象: ${target_file}\n"
            fi
            ;;
        "$MSF_STRATEGY_DEFENSIVE")
            prompt="【Defensive Fix - 防御的修正】\n"
            prompt="${prompt}以下のエラーを修正し、再発を防止するガードを追加してください。\n\n"
            prompt="${prompt}エラー:\n${error_message}\n\n"
            prompt="${prompt}修正方針:\n${description}\n\n"
            prompt="${prompt}要件:\n"
            prompt="${prompt}- エラーを直接修正すること\n"
            prompt="${prompt}- 同種エラーの再発を防止するガードを追加\n"
            if [[ -n "$guard_type" ]]; then
                prompt="${prompt}- ガードタイプ: ${guard_type}\n"
            fi
            prompt="${prompt}- バリデーション/型チェック/エラーハンドリングを強化\n"
            prompt="${prompt}- 適切なログ出力を追加\n"
            if [[ -n "$target_file" ]]; then
                prompt="${prompt}- 修正対象: ${target_file}\n"
            fi
            ;;
    esac

    if [[ -n "$additional_context" ]]; then
        prompt="${prompt}\n追加コンテキスト:\n${additional_context}\n"
    fi

    echo -e "$prompt"

    # Log the application
    _msf_log_strategy "$selected" "$error_message" "$target_file"

    return 0
}

# =============================================================================
# _msf_record_outcome - Record strategy outcome for learning
# Arguments:
#   $1 - strategy_type
#   $2 - error_type
#   $3 - success ("true"|"false")
# =============================================================================
_msf_record_outcome() {
    local strategy="${1:-}"
    local error_type="${2:-generic}"
    local success="${3:-false}"

    local key="${strategy}::${error_type}"
    local prev="${_MSF_OUTCOMES[$key]:-0:0}"
    local prev_succ prev_total
    prev_succ=$(echo "$prev" | cut -d: -f1)
    prev_total=$(echo "$prev" | cut -d: -f2)

    prev_total=$((prev_total + 1))
    if [[ "$success" == "true" ]]; then
        prev_succ=$((prev_succ + 1))
        MSF_TOTAL_SUCCESS=$((MSF_TOTAL_SUCCESS + 1))
    fi

    _MSF_OUTCOMES["$key"]="${prev_succ}:${prev_total}"
    return 0
}

# =============================================================================
# _msf_load_outcomes / _msf_log_strategy - Persistence
# =============================================================================
_msf_load_outcomes() {
    [[ ! -f "$MSF_STRATEGY_LOG" ]] && return 0

    while IFS= read -r line; do
        [[ -z "$line" ]] && continue

        local strategy error_type success
        strategy=$(echo "$line" | grep -oE '"strategy":"[^"]*"' | sed 's/"strategy":"//;s/"//')
        error_type=$(echo "$line" | grep -oE '"error_type":"[^"]*"' | sed 's/"error_type":"//;s/"//')
        success=$(echo "$line" | grep -oE '"success":[a-z]*' | sed 's/"success"://')

        [[ -z "$strategy" || -z "$error_type" ]] && continue

        local key="${strategy}::${error_type}"
        local prev="${_MSF_OUTCOMES[$key]:-0:0}"
        local p_s p_t
        p_s=$(echo "$prev" | cut -d: -f1)
        p_t=$(echo "$prev" | cut -d: -f2)
        p_t=$((p_t + 1))
        [[ "$success" == "true" ]] && p_s=$((p_s + 1))
        _MSF_OUTCOMES["$key"]="${p_s}:${p_t}"
    done < "$MSF_STRATEGY_LOG"

    return 0
}

_msf_log_strategy() {
    local strategy="${1:-}"
    local error_msg="${2:-}"
    local target="${3:-}"

    [[ -z "$MSF_STRATEGY_LOG" ]] && return 0

    local safe_msg
    safe_msg=$(echo "$error_msg" | head -c 200 | sed 's/"/\\"/g; s/\n/ /g')

    echo "{\"strategy\":\"${strategy}\",\"target\":\"${target}\",\"error\":\"${safe_msg}\",\"ts\":\"$(date -u +%Y-%m-%dT%H:%M:%SZ)\"}" \
        >> "$MSF_STRATEGY_LOG" 2>/dev/null || true

    # Rotate
    local lines
    lines=$(wc -l < "$MSF_STRATEGY_LOG" 2>/dev/null | tr -d ' ')
    if [[ "${lines:-0}" -gt 500 ]]; then
        tail -250 "$MSF_STRATEGY_LOG" > "${MSF_STRATEGY_LOG}.tmp" 2>/dev/null
        mv "${MSF_STRATEGY_LOG}.tmp" "$MSF_STRATEGY_LOG" 2>/dev/null || true
    fi
}

# =============================================================================
# msf_report - Module report output
# =============================================================================
msf_report() {
    echo -e "\n  ${CLR_BOLD:-}═══ Multi-Strategy Fixer v${MSF_VERSION} ═══${CLR_NC:-}" >&2
    echo -e "  戦略生成総数       : ${MSF_TOTAL_GENERATED}" >&2
    echo -e "  Quick Fix選択      : ${MSF_QUICK_SELECTED}" >&2
    echo -e "  Proper Fix選択     : ${MSF_PROPER_SELECTED}" >&2
    echo -e "  Defensive Fix選択  : ${MSF_DEFENSIVE_SELECTED}" >&2
    echo -e "  適用総数           : ${MSF_TOTAL_APPLIED}" >&2
    echo -e "  成功数             : ${MSF_TOTAL_SUCCESS}" >&2

    if [[ $MSF_TOTAL_APPLIED -gt 0 ]]; then
        local success_rate=$(( (MSF_TOTAL_SUCCESS * 100) / MSF_TOTAL_APPLIED ))
        echo -e "  修正成功率         : ${success_rate}%" >&2
    fi
}

# =============================================================================
# msf_score - Module score (0-100)
# =============================================================================
msf_score() {
    local score=50

    if [[ $MSF_TOTAL_APPLIED -gt 0 ]]; then
        local success_rate=$(( (MSF_TOTAL_SUCCESS * 100) / MSF_TOTAL_APPLIED ))
        score=$((30 + (success_rate * 50 / 100)))
    fi

    [[ $MSF_TOTAL_GENERATED -ge 5 ]] && score=$((score + 10))
    [[ $MSF_TOTAL_GENERATED -ge 20 ]] && score=$((score + 10))

    [[ $score -gt 100 ]] && score=100
    [[ $score -lt 0 ]] && score=0

    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "multi-strategy-fixer" \
    --version "254.0" \
    --description "1エラーに対して3戦略を生成し最適修正を選択" \
    --init "msf_init" \
    --report "msf_report" \
    --score "msf_score" \
    --enable-var "ENABLE_MSF" \
    --cli-flags "--multi-strategy-fixer:--no-multi-strategy-fixer"

# ----------------------------------------------------------------
# v2043 L8 強化: refiner-to-healer 閉ループ統一契約アダプタ (v2043 / L8・既存挙動不変・末尾追加のみ)
#   効果: これまで閉ループから不可視だった本fixerを diagnostic_code 宣言 + 統一 _run で
#         routable 化し、plan で自身の検出 (score) を handled として閉ループへ露出する。
#         apply は二重適用回避のため adapter 側 no-op (本体修正は既存経路が担当)。既存関数は無改変。
# ----------------------------------------------------------------
_msf_refiner_codes() { echo "UNKNOWN multi-strategy fallback"; }
_msf_run() {
    local proj="${1:?project_dir required}"; local mode="${2:-plan}"
    local s handled=0
    s="$(msf_score "$proj" 2>/dev/null || echo 100)"; [[ "${s:-100}" =~ ^[0-9]+$ ]] || s=100
    [[ "$s" -lt 100 ]] && handled=1
    printf '{"fixer":"multi-strategy-fixer","diagnostic":"UNKNOWN","handled":%s,"applied":0,"mode":"%s","strategy":"multi-strategy","note":"既存fixer強化アダプタ(plan=score検出/apply=本体経路へ委譲しadapterはno-op)"}\n' "$handled" "$mode"
}
