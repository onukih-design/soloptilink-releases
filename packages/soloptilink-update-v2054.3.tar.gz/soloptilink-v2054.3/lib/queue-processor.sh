#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - Queue Processor
# =============================================================================
# 非同期ジョブキュー自動構築エンジン。
# BullMQ/インメモリ/pg-bossのキュー抽象化、ワーカープロセス、ジョブ型レジストリ、
# リトライポリシー、モニタリングダッシュボード、スケジュールジョブを生成。
#
# 機能一覧:
#   qp_generate_queue_service   - キュー抽象化サービス
#   qp_generate_worker          - ワーカープロセス+並行制御
#   qp_generate_job_types       - ジョブ型レジストリ（zodバリデーション）
#   qp_generate_retry_policy    - リトライ+指数バックオフ+DLQ
#   qp_generate_dashboard       - Bull Board モニタリング
#   qp_generate_scheduled_jobs  - Cronライク定期ジョブ
#   qp_inject_queue_patterns    - Claudeプロンプトへのパターン注入
#
# 全globals: QP_ prefix
# =============================================================================

[[ -n "${_QP_LOADED:-}" ]] && return 0; _QP_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g QP_VERSION="140.0"
declare -g QP_GENERATED=0
declare -g QP_ERRORS=0
declare -g QP_PHASE="queue"
declare -g QP_FILES_WRITTEN=0

# =============================================================================
# 初期化
# =============================================================================
qp_init() {
    QP_GENERATED=0
    QP_ERRORS=0
    QP_FILES_WRITTEN=0
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} queue-processor v${QP_VERSION}"
    return 0
}

# =============================================================================
# ユーティリティ
# =============================================================================
_qp_write_file() {
    local filepath="$1"
    local content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ $? -eq 0 ]]; then
        QP_FILES_WRITTEN=$((QP_FILES_WRITTEN + 1))
        echo "  [queue] wrote: $filepath" >&2
    else
        QP_ERRORS=$((QP_ERRORS + 1))
    fi
}

# =============================================================================
# qp_generate_queue_service - キュー抽象化サービス
# =============================================================================
qp_generate_queue_service() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local backend="${2:-bullmq}"

    local queue_ts
    queue_ts=$(cat <<'QSEOF'
import { Queue, Worker, Job, QueueEvents, ConnectionOptions } from 'bullmq';
import { z } from 'zod';

// --- Connection ---
const connection: ConnectionOptions = {
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379'),
  password: process.env.REDIS_PASSWORD || undefined,
  maxRetriesPerRequest: null,
};

// --- Queue Registry ---
const queues: Map<string, Queue> = new Map();
const workers: Map<string, Worker> = new Map();

/**
 * Get or create a named queue.
 */
export function getQueue(name: string): Queue {
  if (!queues.has(name)) {
    const queue = new Queue(name, {
      connection,
      defaultJobOptions: {
        removeOnComplete: { count: 1000, age: 24 * 3600 },
        removeOnFail: { count: 5000, age: 7 * 24 * 3600 },
        attempts: 3,
        backoff: { type: 'exponential', delay: 1000 },
      },
    });
    queues.set(name, queue);
  }
  return queues.get(name)!;
}

/**
 * Add a job to a queue with type-safe payload.
 */
export async function addJob<T extends z.ZodSchema>(
  queueName: string,
  jobName: string,
  data: z.infer<T>,
  schema: T,
  options?: {
    delay?: number;
    priority?: number;
    attempts?: number;
    jobId?: string;
  }
): Promise<Job> {
  // Validate payload
  const parsed = schema.safeParse(data);
  if (!parsed.success) {
    throw new Error(`Job payload validation failed: ${parsed.error.message}`);
  }

  const queue = getQueue(queueName);
  return queue.add(jobName, parsed.data, {
    delay: options?.delay,
    priority: options?.priority,
    attempts: options?.attempts,
    jobId: options?.jobId,
  });
}

/**
 * Get job by ID.
 */
export async function getJob(queueName: string, jobId: string): Promise<Job | undefined> {
  const queue = getQueue(queueName);
  return queue.getJob(jobId) ?? undefined;
}

/**
 * Get queue statistics.
 */
export async function getQueueStats(queueName: string) {
  const queue = getQueue(queueName);
  const [waiting, active, completed, failed, delayed] = await Promise.all([
    queue.getWaitingCount(),
    queue.getActiveCount(),
    queue.getCompletedCount(),
    queue.getFailedCount(),
    queue.getDelayedCount(),
  ]);
  return { queueName, waiting, active, completed, failed, delayed };
}

/**
 * Gracefully shut down all queues and workers.
 */
export async function shutdownQueues() {
  const workerCloses = Array.from(workers.values()).map((w) => w.close());
  const queueCloses = Array.from(queues.values()).map((q) => q.close());
  await Promise.all([...workerCloses, ...queueCloses]);
  workers.clear();
  queues.clear();
}

// Graceful shutdown on process exit
process.on('SIGTERM', () => shutdownQueues());
process.on('SIGINT', () => shutdownQueues());
QSEOF
)
    _qp_write_file "${project_dir}/src/lib/queue.ts" "$queue_ts"
    QP_GENERATED=$((QP_GENERATED + 1))
    return 0
}

# =============================================================================
# qp_generate_worker - ワーカープロセス
# =============================================================================
qp_generate_worker() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local worker_ts
    worker_ts=$(cat <<'WKEOF'
import { Worker, Job } from 'bullmq';
import { jobHandlers } from './job-types';

const connection = {
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT || '6379'),
  password: process.env.REDIS_PASSWORD || undefined,
  maxRetriesPerRequest: null,
};

interface WorkerConfig {
  queueName: string;
  concurrency?: number;
  limiter?: { max: number; duration: number };
}

/**
 * Create a worker for a specific queue.
 */
export function createWorker(config: WorkerConfig): Worker {
  const { queueName, concurrency = 5, limiter } = config;

  const worker = new Worker(
    queueName,
    async (job: Job) => {
      const startTime = Date.now();
      const handler = jobHandlers.get(job.name);

      if (!handler) {
        throw new Error(`No handler registered for job type: ${job.name}`);
      }

      console.log(`[worker:${queueName}] Processing ${job.name} (${job.id})`);

      try {
        // Progress tracking
        await job.updateProgress(0);
        const result = await handler(job);
        await job.updateProgress(100);

        const duration = Date.now() - startTime;
        console.log(`[worker:${queueName}] Completed ${job.name} (${job.id}) in ${duration}ms`);
        return result;
      } catch (err: any) {
        const duration = Date.now() - startTime;
        console.error(
          `[worker:${queueName}] Failed ${job.name} (${job.id}) after ${duration}ms:`,
          err.message
        );
        throw err;
      }
    },
    {
      connection,
      concurrency,
      limiter,
      autorun: true,
      settings: {
        stalledInterval: 30_000,
        maxStalledCount: 2,
      },
    }
  );

  // Event handlers
  worker.on('completed', (job: Job) => {
    console.log(`[worker:${queueName}] Job ${job.id} completed`);
  });

  worker.on('failed', (job: Job | undefined, err: Error) => {
    console.error(`[worker:${queueName}] Job ${job?.id} failed:`, err.message);
  });

  worker.on('stalled', (jobId: string) => {
    console.warn(`[worker:${queueName}] Job ${jobId} stalled`);
  });

  worker.on('error', (err: Error) => {
    console.error(`[worker:${queueName}] Worker error:`, err.message);
  });

  return worker;
}

/**
 * Start all default workers.
 */
export function startAllWorkers() {
  const workers = [
    createWorker({ queueName: 'email', concurrency: 10 }),
    createWorker({ queueName: 'reports', concurrency: 3 }),
    createWorker({ queueName: 'exports', concurrency: 2 }),
    createWorker({
      queueName: 'webhooks',
      concurrency: 20,
      limiter: { max: 100, duration: 60_000 }, // 100/min
    }),
  ];

  console.log(`[worker] Started ${workers.length} workers`);
  return workers;
}

// CLI entry point
if (require.main === module) {
  console.log('[worker] Starting worker processes...');
  startAllWorkers();
}
WKEOF
)
    _qp_write_file "${project_dir}/src/workers/worker.ts" "$worker_ts"
    QP_GENERATED=$((QP_GENERATED + 1))
    return 0
}

# =============================================================================
# qp_generate_job_types - ジョブ型レジストリ
# =============================================================================
qp_generate_job_types() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local job_types_ts
    job_types_ts=$(cat <<'JTEOF'
import { Job } from 'bullmq';
import { z } from 'zod';

// --- Job Handler Registry ---
type JobHandler = (job: Job) => Promise<unknown>;
export const jobHandlers: Map<string, JobHandler> = new Map();

function registerJob(name: string, handler: JobHandler) {
  jobHandlers.set(name, handler);
}

// === Email Send ===
export const EmailJobSchema = z.object({
  to: z.string().email(),
  subject: z.string().min(1).max(500),
  html: z.string(),
  cc: z.array(z.string().email()).optional(),
  replyTo: z.string().email().optional(),
  attachments: z.array(z.object({
    filename: z.string(),
    content: z.string(), // base64
  })).optional(),
});

registerJob('email-send', async (job: Job<z.infer<typeof EmailJobSchema>>) => {
  const { to, subject, html, cc, replyTo } = job.data;
  // Use nodemailer/resend here
  console.log(`[email] Sending to ${to}: ${subject}`);
  await job.updateProgress(50);

  // Simulated send - replace with actual email provider
  const response = await fetch(process.env.EMAIL_API_URL || 'https://api.resend.com/emails', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.EMAIL_API_KEY}`,
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({ from: process.env.EMAIL_FROM || 'noreply@example.com', to, subject, html, cc, reply_to: replyTo }),
  });

  if (!response.ok) {
    throw new Error(`Email send failed: ${response.status}`);
  }

  return { sent: true, to, messageId: (await response.json()).id };
});

// === Report Generate ===
export const ReportJobSchema = z.object({
  reportType: z.enum(['daily-summary', 'monthly-analytics', 'user-activity', 'financial']),
  userId: z.string(),
  tenantId: z.string().optional(),
  dateRange: z.object({
    start: z.string(),
    end: z.string(),
  }),
  format: z.enum(['pdf', 'csv', 'xlsx']).default('pdf'),
});

registerJob('report-generate', async (job: Job<z.infer<typeof ReportJobSchema>>) => {
  const { reportType, dateRange, format } = job.data;
  console.log(`[report] Generating ${reportType} (${format}) for ${dateRange.start}-${dateRange.end}`);
  await job.updateProgress(10);

  // Step 1: Fetch data
  await job.updateProgress(30);

  // Step 2: Generate report
  await job.updateProgress(60);

  // Step 3: Save to storage
  await job.updateProgress(90);

  const outputPath = `/tmp/reports/${job.id}.${format}`;
  return { outputPath, reportType, format };
});

// === Data Export ===
export const ExportJobSchema = z.object({
  exportType: z.enum(['users', 'transactions', 'logs', 'all']),
  userId: z.string(),
  tenantId: z.string().optional(),
  format: z.enum(['csv', 'json', 'xlsx']).default('csv'),
  filters: z.record(z.unknown()).optional(),
});

registerJob('data-export', async (job: Job<z.infer<typeof ExportJobSchema>>) => {
  const { exportType, format, filters } = job.data;
  console.log(`[export] Exporting ${exportType} as ${format}`);

  await job.updateProgress(20);
  // Fetch and stream data
  await job.updateProgress(80);

  const outputPath = `/tmp/exports/${job.id}.${format}`;
  return { outputPath, exportType, format, recordCount: 0 };
});

// === Webhook Deliver ===
export const WebhookJobSchema = z.object({
  url: z.string().url(),
  method: z.enum(['POST', 'PUT', 'PATCH']).default('POST'),
  headers: z.record(z.string()).optional(),
  payload: z.unknown(),
  secret: z.string().optional(),
  eventType: z.string(),
});

registerJob('webhook-deliver', async (job: Job<z.infer<typeof WebhookJobSchema>>) => {
  const { url, method, headers, payload, secret, eventType } = job.data;
  console.log(`[webhook] Delivering ${eventType} to ${url}`);

  const requestHeaders: Record<string, string> = {
    'Content-Type': 'application/json',
    'X-Webhook-Event': eventType,
    'X-Webhook-Delivery': job.id || '',
    ...headers,
  };

  // HMAC signature if secret provided
  if (secret) {
    const crypto = await import('crypto');
    const signature = crypto
      .createHmac('sha256', secret)
      .update(JSON.stringify(payload))
      .digest('hex');
    requestHeaders['X-Webhook-Signature'] = `sha256=${signature}`;
  }

  const response = await fetch(url, {
    method,
    headers: requestHeaders,
    body: JSON.stringify(payload),
    signal: AbortSignal.timeout(30_000),
  });

  if (!response.ok) {
    throw new Error(`Webhook delivery failed: ${response.status} ${response.statusText}`);
  }

  return { delivered: true, statusCode: response.status, url, eventType };
});
JTEOF
)
    _qp_write_file "${project_dir}/src/lib/job-types.ts" "$job_types_ts"
    QP_GENERATED=$((QP_GENERATED + 1))
    return 0
}

# =============================================================================
# qp_generate_retry_policy - リトライポリシー+DLQ
# =============================================================================
qp_generate_retry_policy() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local retry_ts
    retry_ts=$(cat <<'RPEOF'
import { Queue, QueueEvents } from 'bullmq';
import { getQueue } from './queue';

// --- Retry Policies ---
export interface RetryPolicy {
  maxAttempts: number;
  backoff: 'exponential' | 'linear' | 'fixed';
  baseDelayMs: number;
  maxDelayMs: number;
}

export const RETRY_POLICIES: Record<string, RetryPolicy> = {
  'email-send': {
    maxAttempts: 5,
    backoff: 'exponential',
    baseDelayMs: 2000,
    maxDelayMs: 300_000, // 5 min
  },
  'webhook-deliver': {
    maxAttempts: 10,
    backoff: 'exponential',
    baseDelayMs: 1000,
    maxDelayMs: 3600_000, // 1 hour
  },
  'report-generate': {
    maxAttempts: 3,
    backoff: 'fixed',
    baseDelayMs: 5000,
    maxDelayMs: 5000,
  },
  'data-export': {
    maxAttempts: 3,
    backoff: 'linear',
    baseDelayMs: 10_000,
    maxDelayMs: 60_000,
  },
};

export function getRetryOptions(jobName: string) {
  const policy = RETRY_POLICIES[jobName] || {
    maxAttempts: 3,
    backoff: 'exponential',
    baseDelayMs: 1000,
    maxDelayMs: 30_000,
  };

  return {
    attempts: policy.maxAttempts,
    backoff: {
      type: policy.backoff === 'fixed' ? 'fixed' as const : 'exponential' as const,
      delay: policy.baseDelayMs,
    },
  };
}

// --- Dead Letter Queue ---
const DLQ_NAME = 'dead-letter';

/**
 * Setup DLQ listener to capture permanently failed jobs.
 */
export function setupDeadLetterQueue() {
  const dlq = getQueue(DLQ_NAME);

  // Monitor all queues for failed jobs that exhaust retries
  const monitoredQueues = ['email', 'reports', 'exports', 'webhooks'];

  for (const queueName of monitoredQueues) {
    const events = new QueueEvents(queueName, {
      connection: {
        host: process.env.REDIS_HOST || 'localhost',
        port: parseInt(process.env.REDIS_PORT || '6379'),
        password: process.env.REDIS_PASSWORD || undefined,
        maxRetriesPerRequest: null,
      },
    });

    events.on('failed', async ({ jobId, failedReason, prev }) => {
      if (prev !== 'active') return; // Only on final failure

      try {
        const sourceQueue = getQueue(queueName);
        const job = await sourceQueue.getJob(jobId);
        if (!job) return;

        const policy = RETRY_POLICIES[job.name];
        const maxAttempts = policy?.maxAttempts || 3;

        if (job.attemptsMade >= maxAttempts) {
          // Move to DLQ
          await dlq.add('dead-letter-job', {
            originalQueue: queueName,
            originalJobName: job.name,
            originalJobId: job.id,
            payload: job.data,
            failedReason,
            attempts: job.attemptsMade,
            failedAt: new Date().toISOString(),
          });
          console.warn(`[DLQ] Job ${job.name}:${job.id} moved to dead letter queue after ${job.attemptsMade} attempts`);
        }
      } catch (err) {
        console.error('[DLQ] Failed to process dead letter:', err);
      }
    });
  }

  return dlq;
}

/**
 * Retry a dead letter job by moving it back to original queue.
 */
export async function retryDeadLetterJob(dlqJobId: string) {
  const dlq = getQueue(DLQ_NAME);
  const job = await dlq.getJob(dlqJobId);
  if (!job) throw new Error(`DLQ job ${dlqJobId} not found`);

  const { originalQueue, originalJobName, payload } = job.data;
  const targetQueue = getQueue(originalQueue);

  await targetQueue.add(originalJobName, payload, {
    attempts: 3, // Fresh retry attempts
    backoff: { type: 'exponential', delay: 5000 },
  });

  await job.remove();
  console.log(`[DLQ] Retried job ${dlqJobId} back to ${originalQueue}`);
}
RPEOF
)
    _qp_write_file "${project_dir}/src/lib/retry-policy.ts" "$retry_ts"
    QP_GENERATED=$((QP_GENERATED + 1))
    return 0
}

# =============================================================================
# qp_generate_dashboard - Bull Board モニタリング
# =============================================================================
qp_generate_dashboard() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local dashboard_ts
    dashboard_ts=$(cat <<'DBEOF'
import { NextRequest, NextResponse } from 'next/server';
import { getQueueStats, getQueue } from '@/lib/queue';

const MONITORED_QUEUES = ['email', 'reports', 'exports', 'webhooks', 'dead-letter'];

// --- GET /api/admin/queues ---
export async function GET(request: NextRequest) {
  try {
    const stats = await Promise.all(
      MONITORED_QUEUES.map((name) => getQueueStats(name))
    );

    const totalJobs = stats.reduce(
      (acc, s) => ({
        waiting: acc.waiting + s.waiting,
        active: acc.active + s.active,
        completed: acc.completed + s.completed,
        failed: acc.failed + s.failed,
        delayed: acc.delayed + s.delayed,
      }),
      { waiting: 0, active: 0, completed: 0, failed: 0, delayed: 0 }
    );

    return NextResponse.json({
      queues: stats,
      summary: totalJobs,
      timestamp: new Date().toISOString(),
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

// --- POST /api/admin/queues/[name]/retry-all ---
export async function retryAllFailed(queueName: string) {
  const queue = getQueue(queueName);
  const failed = await queue.getFailed(0, 100);
  let retried = 0;

  for (const job of failed) {
    try {
      await job.retry();
      retried++;
    } catch { /* skip jobs that can't be retried */ }
  }

  return { retried, total: failed.length };
}

// --- POST /api/admin/queues/[name]/clean ---
export async function cleanQueue(queueName: string, status: 'completed' | 'failed' = 'completed', olderThanMs: number = 24 * 3600_000) {
  const queue = getQueue(queueName);
  const removed = await queue.clean(olderThanMs, 1000, status);
  return { removed: removed.length, status, queueName };
}

// --- POST /api/admin/queues/[name]/pause ---
export async function pauseQueue(queueName: string) {
  const queue = getQueue(queueName);
  await queue.pause();
  return { paused: true, queueName };
}

// --- POST /api/admin/queues/[name]/resume ---
export async function resumeQueue(queueName: string) {
  const queue = getQueue(queueName);
  await queue.resume();
  return { resumed: true, queueName };
}
DBEOF
)
    _qp_write_file "${project_dir}/src/app/api/admin/queues/route.ts" "$dashboard_ts"
    QP_GENERATED=$((QP_GENERATED + 1))
    return 0
}

# =============================================================================
# qp_generate_scheduled_jobs - 定期ジョブスケジューラ
# =============================================================================
qp_generate_scheduled_jobs() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    local scheduled_ts
    scheduled_ts=$(cat <<'SJEOF'
import { Queue } from 'bullmq';
import { getQueue } from './queue';

interface ScheduledJobConfig {
  name: string;
  queueName: string;
  cron: string;
  data: Record<string, unknown>;
  description: string;
  timezone?: string;
}

const scheduledJobs: ScheduledJobConfig[] = [
  {
    name: 'daily-report',
    queueName: 'reports',
    cron: '0 8 * * *', // 8:00 AM daily
    data: {
      reportType: 'daily-summary',
      dateRange: { start: 'yesterday', end: 'today' },
      format: 'pdf',
    },
    description: 'Generate daily summary report',
    timezone: 'Asia/Tokyo',
  },
  {
    name: 'weekly-cleanup',
    queueName: 'maintenance',
    cron: '0 2 * * 0', // 2:00 AM Sunday
    data: { action: 'cleanup-expired-sessions' },
    description: 'Clean expired sessions and temporary data',
    timezone: 'Asia/Tokyo',
  },
  {
    name: 'monthly-billing',
    queueName: 'billing',
    cron: '0 0 1 * *', // Midnight on 1st of month
    data: { action: 'generate-invoices' },
    description: 'Generate monthly invoices for all tenants',
    timezone: 'UTC',
  },
  {
    name: 'health-check',
    queueName: 'monitoring',
    cron: '*/5 * * * *', // Every 5 minutes
    data: { action: 'check-services' },
    description: 'Check health of dependent services',
  },
];

/**
 * Register all scheduled (repeatable) jobs.
 */
export async function registerScheduledJobs() {
  for (const job of scheduledJobs) {
    const queue = getQueue(job.queueName);

    // Remove existing repeatable job to avoid duplicates
    const existing = await queue.getRepeatableJobs();
    for (const rep of existing) {
      if (rep.name === job.name) {
        await queue.removeRepeatableByKey(rep.key);
      }
    }

    // Add repeatable job
    await queue.add(job.name, job.data, {
      repeat: {
        pattern: job.cron,
        tz: job.timezone,
      },
      jobId: `scheduled-${job.name}`,
    });

    console.log(`[scheduler] Registered: ${job.name} (${job.cron}) - ${job.description}`);
  }
}

/**
 * List all registered scheduled jobs with next run time.
 */
export async function listScheduledJobs() {
  const allJobs: Array<{
    name: string;
    queue: string;
    cron: string;
    timezone?: string;
    nextRun?: string;
    description: string;
  }> = [];

  for (const job of scheduledJobs) {
    const queue = getQueue(job.queueName);
    const repeatableJobs = await queue.getRepeatableJobs();
    const match = repeatableJobs.find((r) => r.name === job.name);

    allJobs.push({
      name: job.name,
      queue: job.queueName,
      cron: job.cron,
      timezone: job.timezone,
      nextRun: match?.next ? new Date(match.next).toISOString() : undefined,
      description: job.description,
    });
  }

  return allJobs;
}

/**
 * Remove a scheduled job.
 */
export async function removeScheduledJob(name: string) {
  const config = scheduledJobs.find((j) => j.name === name);
  if (!config) throw new Error(`Scheduled job not found: ${name}`);

  const queue = getQueue(config.queueName);
  const repeatable = await queue.getRepeatableJobs();
  const match = repeatable.find((r) => r.name === name);
  if (match) {
    await queue.removeRepeatableByKey(match.key);
    console.log(`[scheduler] Removed: ${name}`);
  }
}

// CLI entry point
if (require.main === module) {
  registerScheduledJobs()
    .then(() => console.log('[scheduler] All scheduled jobs registered'))
    .catch((err) => {
      console.error('[scheduler] Failed:', err);
      process.exit(1);
    });
}
SJEOF
)
    _qp_write_file "${project_dir}/src/lib/scheduled-jobs.ts" "$scheduled_ts"
    QP_GENERATED=$((QP_GENERATED + 1))
    return 0
}

# =============================================================================
# qp_inject_queue_patterns - Claudeプロンプトへのパターン注入
# =============================================================================
qp_inject_queue_patterns() {
    local prompt="${1:-}"

    cat <<'INJECT'

## [Queue Patterns] - 非同期ジョブキュー必須要件

### BullMQ必須構成:
- **Queue**: defaultJobOptions で removeOnComplete, removeOnFail, attempts, backoff を設定
- **Worker**: concurrency制御、stalledInterval、maxStalledCount
- **Connection**: maxRetriesPerRequest: null（必須）

### ジョブ型必須:
- **zodバリデーション**: addJob時にスキーマ検証、不正ペイロードは即拒否
- **進捗報告**: job.updateProgress(0-100) でリアルタイム進捗
- **型安全**: Job<PayloadType> で型付きハンドラ

### リトライポリシー:
- **email**: 5回、指数バックオフ(2s-5min)
- **webhook**: 10回、指数バックオフ(1s-1h)
- **report**: 3回、固定5s
- **Dead Letter Queue**: 全リトライ失敗→DLQ移動→管理画面で手動リトライ

### ダッシュボード:
- キュー別統計: waiting/active/completed/failed/delayed
- 手動操作: retry-all, clean, pause, resume

### 定期ジョブ:
- BullMQ repeat + cron パターン
- 冪等性必須（同じジョブが複数回実行されても安全）
- タイムゾーン指定: repeat.tz

INJECT

    echo "$prompt"
}

# =============================================================================
# qp_generate_queue - 全キュー一括生成（レガシー互換）
# =============================================================================
qp_generate_queue() {
    local project_dir="${PROJECT_DIR:-./output}"
    qp_generate_queue_service "$project_dir" "bullmq"
    qp_generate_worker "$project_dir"
    qp_generate_job_types "$project_dir"
    qp_generate_retry_policy "$project_dir"
    qp_generate_dashboard "$project_dir"
    qp_generate_scheduled_jobs "$project_dir"
    return 0
}

# =============================================================================
# レポート & スコア
# =============================================================================
qp_report() {
    echo -e "\n  ${BOLD:-}=== queue-processor v${QP_VERSION} ===${NC:-}"
    echo -e "  生成数: ${QP_GENERATED}"
    echo -e "  書込数: ${QP_FILES_WRITTEN}"
    echo -e "  エラー: ${QP_ERRORS}"
}

qp_score() {
    if [[ ${QP_GENERATED} -ge 4 ]] && [[ ${QP_ERRORS} -eq 0 ]]; then
        echo "95"
    elif [[ ${QP_GENERATED} -gt 0 ]] && [[ ${QP_ERRORS} -eq 0 ]]; then
        echo "85"
    elif [[ ${QP_GENERATED} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "queue-processor" --version "${QP_VERSION}" \
        --description "非同期ジョブキュー×BullMQ×リトライ×DLQ×スケジューラ" \
        --init "qp_init" --report "qp_report" --score "qp_score" \
        --enable-var "ENABLE_QUEUE" --cli-flags "--queue:--no-queue"
fi

# v2003.1: source時のexit codeを確実に0にする
true
