#!/usr/bin/env bash
# =============================================================================
# SoloptiLink Chain v13.0 - Self-Learning Knowledge Graph
# =============================================================================
# ビルド結果・成功/失敗パターンをJSON-LDノードとして蓄積し、
# ドメイン×フェーズごとに最適パターンを推薦する自己学習ナレッジグラフ。
#
# 機能:
#   1. kg_init()                    - ナレッジグラフの初期化
#   2. kg_record_build()            - ビルド結果をJSON-LDノードとして保存
#   3. kg_record_pattern()          - 成功/失敗パターンの記録
#   4. kg_query_patterns()          - ドメイン×フェーズの最適パターン検索
#   5. kg_get_success_rate()        - ドメイン別の総合成功率
#   6. kg_prune_low_score()         - 低スコアパターンの剪定
#   7. kg_export_report()           - ナレッジグラフのレポート出力
#
# Storage: ~/.soloptilink/knowledge/ (JSON files per domain)
# Usage: source lib/knowledge-graph.sh
# =============================================================================

# Load guard
[[ -n "${_KG_LOADED:-}" ]] && return 0
_KG_LOADED=1

# ---------------------------------------------------------------------------
# Color definitions (KG_ prefix to avoid collision)
# ---------------------------------------------------------------------------
KG_RED='\033[0;31m'
KG_GREEN='\033[0;32m'
KG_YELLOW='\033[0;33m'
KG_CYAN='\033[0;36m'
KG_PURPLE='\033[0;35m'
KG_BOLD='\033[1m'
KG_NC='\033[0m'

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
KG_BASE_DIR="${HOME}/.soloptilink/knowledge"
KG_BUILDS_DIR="${KG_BASE_DIR}/builds"
KG_PATTERNS_DIR="${KG_BASE_DIR}/patterns"
KG_INDEX_FILE="${KG_BASE_DIR}/index.json"
KG_STATS_FILE="${KG_BASE_DIR}/stats.json"

# Limits
KG_MAX_PATTERNS_PER_DOMAIN=200
KG_MAX_BUILDS=500
KG_DEFAULT_PRUNE_THRESHOLD=0.3

# ---------------------------------------------------------------------------
# Helper: _kg_log(level, message)
# ---------------------------------------------------------------------------
_kg_log() {
    local level="$1" message="$2" ts
    ts="$(date '+%Y-%m-%d %H:%M:%S')"
    case "$level" in
        INFO)  printf "${KG_CYAN}[KG %s]${KG_NC} %s\n"    "$ts" "$message" ;;
        OK)    printf "${KG_GREEN}[KG %s]${KG_NC} %s\n"    "$ts" "$message" ;;
        WARN)  printf "${KG_YELLOW}[KG %s]${KG_NC} %s\n"   "$ts" "$message" ;;
        ERROR) printf "${KG_RED}[KG %s]${KG_NC} %s\n"      "$ts" "$message" ;;
        LEARN) printf "${KG_PURPLE}[KG %s]${KG_NC} %s\n"   "$ts" "$message" ;;
        *)     printf "[KG %s] %s\n" "$ts" "$message" ;;
    esac
}

# ---------------------------------------------------------------------------
# Helper: _kg_json_write(file, json_string)
#   python3 preferred for valid JSON; bash fallback for simple writes
# ---------------------------------------------------------------------------
_kg_json_write() {
    local file="$1" json_string="$2"
    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys
try:
    obj = json.loads(sys.argv[1])
    with open(sys.argv[2], 'w') as f:
        json.dump(obj, f, indent=2, ensure_ascii=False)
except Exception as e:
    print(f'JSON write error: {e}', file=sys.stderr)
    with open(sys.argv[2], 'w') as f:
        f.write(sys.argv[1])
" "$json_string" "$file"
    else
        printf '%s\n' "$json_string" > "$file"
    fi
}

# ---------------------------------------------------------------------------
# Helper: _kg_json_read(file) -> stdout
# ---------------------------------------------------------------------------
_kg_json_read() {
    local file="$1"
    [[ ! -f "$file" ]] && { echo '{}'; return; }
    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys
try:
    with open(sys.argv[1]) as f:
        data = json.load(f)
    print(json.dumps(data, ensure_ascii=False))
except Exception:
    print('{}')
" "$file"
    else
        cat "$file" 2>/dev/null || echo '{}'
    fi
}

# ---------------------------------------------------------------------------
# Helper: _kg_json_append_array(file, new_element_json)
#   Appends a JSON object to a JSON array stored in file
# ---------------------------------------------------------------------------
_kg_json_append_array() {
    local file="$1" element="$2"
    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os
file_path = sys.argv[1]
element = json.loads(sys.argv[2])
arr = []
if os.path.exists(file_path):
    try:
        with open(file_path) as f:
            arr = json.load(f)
        if not isinstance(arr, list):
            arr = [arr]
    except Exception:
        arr = []
arr.append(element)
with open(file_path, 'w') as f:
    json.dump(arr, f, indent=2, ensure_ascii=False)
" "$file" "$element"
    else
        # bash fallback: simple append
        if [[ -f "$file" ]]; then
            # Remove trailing ] and append
            local content
            content="$(cat "$file")"
            if [[ "$content" == "["* ]]; then
                # Strip trailing ']', add comma and new element
                content="${content%]}"
                printf '%s,\n%s\n]' "$content" "$element" > "$file"
            else
                printf '[\n%s,\n%s\n]' "$content" "$element" > "$file"
            fi
        else
            printf '[\n%s\n]' "$element" > "$file"
        fi
    fi
}

# ---------------------------------------------------------------------------
# Helper: _kg_timestamp() -> ISO 8601 timestamp
# ---------------------------------------------------------------------------
_kg_timestamp() {
    date -u '+%Y-%m-%dT%H:%M:%SZ'
}

# ---------------------------------------------------------------------------
# Helper: _kg_uuid() -> simple unique ID
# ---------------------------------------------------------------------------
_kg_uuid() {
    if command -v uuidgen &>/dev/null; then
        uuidgen | tr '[:upper:]' '[:lower:]'
    else
        printf '%s-%04x' "$(date +%s)" "$RANDOM"
    fi
}

# ---------------------------------------------------------------------------
# Helper: _kg_ensure_domain_dir(domain)
# ---------------------------------------------------------------------------
_kg_ensure_domain_dir() {
    local domain="$1"
    local dir="${KG_PATTERNS_DIR}/${domain}"
    mkdir -p "$dir" 2>/dev/null || true
    echo "$dir"
}

# =============================================================================
# kg_init() - Initialize the knowledge graph storage
# =============================================================================
kg_init() {
    _kg_log INFO "ナレッジグラフを初期化中..."

    mkdir -p "${KG_BASE_DIR}" "${KG_BUILDS_DIR}" "${KG_PATTERNS_DIR}" 2>/dev/null || true

    # Create index if not exists
    if [[ ! -f "${KG_INDEX_FILE}" ]]; then
        _kg_json_write "${KG_INDEX_FILE}" '{
  "@context": "https://schema.org/",
  "@type": "KnowledgeGraph",
  "name": "SoloptiLink Knowledge Graph",
  "version": "17.0",
  "created_at": "'"$(_kg_timestamp)"'",
  "domains": [],
  "total_builds": 0,
  "total_patterns": 0
}'
    fi

    # Create stats if not exists
    if [[ ! -f "${KG_STATS_FILE}" ]]; then
        _kg_json_write "${KG_STATS_FILE}" '{
  "domains": {},
  "overall_success_rate": 0.0,
  "total_builds": 0,
  "total_patterns": 0,
  "last_updated": "'"$(_kg_timestamp)"'"
}'
    fi

    _kg_log OK "ナレッジグラフ初期化完了: ${KG_BASE_DIR}"
    _kg_log INFO "  builds: ${KG_BUILDS_DIR}"
    _kg_log INFO "  patterns: ${KG_PATTERNS_DIR}"
    return 0
}

# =============================================================================
# kg_record_build(session_id, task_desc, tech_stack, phases_data, success)
#   Saves a complete build result as a JSON-LD node
#   - session_id:  unique session identifier
#   - task_desc:   what was built (e.g. "CRM system")
#   - tech_stack:  comma-separated or JSON string of technologies used
#   - phases_data: JSON string with per-phase timing/status
#   - success:     "true" or "false"
# =============================================================================
kg_record_build() {
    local session_id="${1:?session_id required}"
    local task_desc="${2:?task_desc required}"
    local tech_stack="${3:-unknown}"
    local phases_data="${4:-{}}"
    local success="${5:-false}"

    _kg_log LEARN "ビルド結果を記録中: ${task_desc} (success=${success})"

    local node_id
    node_id="$(_kg_uuid)"
    local ts
    ts="$(_kg_timestamp)"

    # Detect domain from task description
    local domain
    domain="$(_kg_detect_domain "$task_desc")"

    # Build JSON-LD node
    local node_json
    node_json='{
  "@context": "https://schema.org/",
  "@type": "SoftwareBuild",
  "@id": "'"${node_id}"'",
  "session_id": "'"${session_id}"'",
  "task_description": "'"$(echo "$task_desc" | sed 's/"/\\"/g')"'",
  "domain": "'"${domain}"'",
  "tech_stack": "'"$(echo "$tech_stack" | sed 's/"/\\"/g')"'",
  "phases": '"${phases_data}"',
  "success": '"${success}"',
  "timestamp": "'"${ts}"'",
  "version": "17.0"
}'

    # Save to builds directory
    local build_file="${KG_BUILDS_DIR}/${session_id}_${node_id}.json"
    _kg_json_write "$build_file" "$node_json"

    # Update domain-level stats
    _kg_update_domain_stats "$domain" "$success"

    # Auto-extract patterns from build
    if [[ "$success" == "true" ]]; then
        _kg_auto_extract_patterns "$domain" "$tech_stack" "$phases_data"
    fi

    # Prune old builds if over limit
    _kg_prune_old_builds

    _kg_log OK "ビルド記録完了: ${build_file##*/} (domain=${domain})"
    echo "$node_id"
    return 0
}

# =============================================================================
# kg_record_pattern(domain, pattern_type, pattern_data, success_rate)
#   Records a reusable pattern for a given domain
#   - domain:       e.g. "crm", "ecommerce", "chat"
#   - pattern_type: e.g. "tech_stack", "architecture", "prompt", "phase_order"
#   - pattern_data: JSON string describing the pattern
#   - success_rate: float 0.0 - 1.0
# =============================================================================
kg_record_pattern() {
    local domain="${1:?domain required}"
    local pattern_type="${2:?pattern_type required}"
    local pattern_data="${3:?pattern_data required}"
    local success_rate="${4:-0.5}"

    _kg_log LEARN "パターン記録: domain=${domain}, type=${pattern_type}, rate=${success_rate}"

    local domain_dir
    domain_dir="$(_kg_ensure_domain_dir "$domain")"
    local pattern_file="${domain_dir}/${pattern_type}.json"

    local pattern_id
    pattern_id="$(_kg_uuid)"
    local ts
    ts="$(_kg_timestamp)"

    local pattern_json='{
  "@id": "'"${pattern_id}"'",
  "domain": "'"${domain}"'",
  "pattern_type": "'"${pattern_type}"'",
  "data": '"${pattern_data}"',
  "success_rate": '"${success_rate}"',
  "usage_count": 1,
  "created_at": "'"${ts}"'",
  "updated_at": "'"${ts}"'"
}'

    # Check for existing similar pattern and merge if found
    if [[ -f "$pattern_file" ]] && command -v python3 &>/dev/null; then
        python3 -c "
import json, sys

pattern_file = sys.argv[1]
new_pattern = json.loads(sys.argv[2])
new_data = json.dumps(new_pattern.get('data', {}), sort_keys=True)

with open(pattern_file) as f:
    patterns = json.load(f)
if not isinstance(patterns, list):
    patterns = [patterns]

# Check for duplicate by data content
merged = False
for p in patterns:
    existing_data = json.dumps(p.get('data', {}), sort_keys=True)
    if existing_data == new_data:
        # Merge: update success_rate with exponential moving average
        old_rate = float(p.get('success_rate', 0.5))
        new_rate = float(new_pattern.get('success_rate', 0.5))
        p['success_rate'] = round(old_rate * 0.7 + new_rate * 0.3, 4)
        p['usage_count'] = p.get('usage_count', 1) + 1
        p['updated_at'] = new_pattern['updated_at']
        merged = True
        break

if not merged:
    patterns.append(new_pattern)

with open(pattern_file, 'w') as f:
    json.dump(patterns, f, indent=2, ensure_ascii=False)
" "$pattern_file" "$pattern_json"
    else
        _kg_json_append_array "$pattern_file" "$pattern_json"
    fi

    # Update index
    _kg_update_index "$domain"

    _kg_log OK "パターン記録完了: ${pattern_type} @ ${domain} (rate=${success_rate})"
    return 0
}

# =============================================================================
# kg_query_patterns(domain, phase) -> returns best patterns for domain+phase
#   Returns JSON array sorted by success_rate descending
# =============================================================================
kg_query_patterns() {
    local domain="${1:?domain required}"
    local phase="${2:-}"

    local domain_dir="${KG_PATTERNS_DIR}/${domain}"
    if [[ ! -d "$domain_dir" ]]; then
        _kg_log WARN "ドメイン '${domain}' のパターンが見つかりません"
        echo '[]'
        return 0
    fi

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os, glob

domain_dir = sys.argv[1]
phase_filter = sys.argv[2] if len(sys.argv) > 2 and sys.argv[2] else None

all_patterns = []
for pfile in glob.glob(os.path.join(domain_dir, '*.json')):
    try:
        with open(pfile) as f:
            data = json.load(f)
        if isinstance(data, list):
            all_patterns.extend(data)
        else:
            all_patterns.append(data)
    except Exception:
        continue

# Filter by phase if specified
if phase_filter:
    filtered = [p for p in all_patterns
                if p.get('pattern_type', '') == phase_filter
                or phase_filter in json.dumps(p.get('data', {}))
               ]
    if filtered:
        all_patterns = filtered

# Sort by success_rate descending
all_patterns.sort(key=lambda x: float(x.get('success_rate', 0)), reverse=True)

# Return top 10
print(json.dumps(all_patterns[:10], indent=2, ensure_ascii=False))
" "$domain_dir" "${phase:-}"
    else
        # bash fallback: just cat all pattern files
        _kg_log WARN "python3未検出: 全パターンを未ソートで返却"
        local result="["
        local first=true
        for pfile in "${domain_dir}"/*.json; do
            [[ -f "$pfile" ]] || continue
            if [[ "$first" == "true" ]]; then
                first=false
            else
                result+=","
            fi
            result+="$(cat "$pfile")"
        done
        result+="]"
        echo "$result"
    fi
    return 0
}

# =============================================================================
# kg_get_success_rate(domain) -> overall success rate for the domain
#   Returns a float 0.0 - 1.0 (or "N/A" if no data)
# =============================================================================
kg_get_success_rate() {
    local domain="${1:?domain required}"

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os

stats_file = sys.argv[1]
domain = sys.argv[2]

if not os.path.exists(stats_file):
    print('N/A')
    sys.exit(0)

try:
    with open(stats_file) as f:
        stats = json.load(f)
    domain_stats = stats.get('domains', {}).get(domain, {})
    total = domain_stats.get('total_builds', 0)
    successes = domain_stats.get('successful_builds', 0)
    if total == 0:
        print('N/A')
    else:
        print(f'{successes / total:.4f}')
except Exception:
    print('N/A')
" "${KG_STATS_FILE}" "$domain"
    else
        # bash fallback: count build files
        local build_count=0 success_count=0
        for bfile in "${KG_BUILDS_DIR}"/*.json; do
            [[ -f "$bfile" ]] || continue
            if grep -q "\"domain\": \"${domain}\"" "$bfile" 2>/dev/null; then
                ((build_count++))
                if grep -q '"success": true' "$bfile" 2>/dev/null; then
                    ((success_count++))
                fi
            fi
        done
        if [[ "$build_count" -eq 0 ]]; then
            echo "N/A"
        else
            # bash integer arithmetic approximation
            echo "scale=4; ${success_count} / ${build_count}" | bc 2>/dev/null || echo "N/A"
        fi
    fi
    return 0
}

# =============================================================================
# kg_prune_low_score(threshold) -> removes patterns below threshold
#   - threshold: float 0.0 - 1.0 (default: 0.3)
# =============================================================================
kg_prune_low_score() {
    local threshold="${1:-${KG_DEFAULT_PRUNE_THRESHOLD}}"

    _kg_log INFO "低スコアパターンを剪定中 (threshold < ${threshold})..."

    if command -v python3 &>/dev/null; then
        local pruned_count
        pruned_count="$(python3 -c "
import json, sys, os, glob

patterns_dir = sys.argv[1]
threshold = float(sys.argv[2])
pruned = 0

for domain_dir in glob.glob(os.path.join(patterns_dir, '*')):
    if not os.path.isdir(domain_dir):
        continue
    for pfile in glob.glob(os.path.join(domain_dir, '*.json')):
        try:
            with open(pfile) as f:
                data = json.load(f)
            if not isinstance(data, list):
                data = [data]
            before = len(data)
            data = [p for p in data if float(p.get('success_rate', 0)) >= threshold]
            after = len(data)
            pruned += (before - after)
            if data:
                with open(pfile, 'w') as f:
                    json.dump(data, f, indent=2, ensure_ascii=False)
            else:
                os.remove(pfile)
        except Exception:
            continue

print(pruned)
" "${KG_PATTERNS_DIR}" "$threshold")"
        _kg_log OK "剪定完了: ${pruned_count} パターン削除 (threshold=${threshold})"
    else
        _kg_log WARN "python3未検出: 剪定をスキップ"
    fi
    return 0
}

# =============================================================================
# kg_export_report() -> prints a formatted knowledge graph report
# =============================================================================
kg_export_report() {
    _kg_log INFO "ナレッジグラフレポート生成中..."

    echo ""
    echo -e "${KG_BOLD}============================================${KG_NC}"
    echo -e "${KG_BOLD}  SoloptiLink Knowledge Graph Report v13.0${KG_NC}"
    echo -e "${KG_BOLD}============================================${KG_NC}"
    echo ""

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os, glob
from datetime import datetime

base_dir = sys.argv[1]
builds_dir = sys.argv[2]
patterns_dir = sys.argv[3]
stats_file = sys.argv[4]

# Count builds
build_files = glob.glob(os.path.join(builds_dir, '*.json'))
total_builds = len(build_files)

# Count patterns per domain
domain_data = {}
for domain_dir in glob.glob(os.path.join(patterns_dir, '*')):
    if not os.path.isdir(domain_dir):
        continue
    domain = os.path.basename(domain_dir)
    pattern_count = 0
    for pfile in glob.glob(os.path.join(domain_dir, '*.json')):
        try:
            with open(pfile) as f:
                data = json.load(f)
            if isinstance(data, list):
                pattern_count += len(data)
            else:
                pattern_count += 1
        except Exception:
            continue
    domain_data[domain] = {'patterns': pattern_count}

# Load stats
try:
    with open(stats_file) as f:
        stats = json.load(f)
except Exception:
    stats = {}

# Print report
print(f'  Generated: {datetime.utcnow().strftime(\"%Y-%m-%d %H:%M:%S UTC\")}')
print(f'  Storage:   {base_dir}')
print()
print(f'  Total Builds:    {total_builds}')
print(f'  Total Domains:   {len(domain_data)}')
total_patterns = sum(d[\"patterns\"] for d in domain_data.values())
print(f'  Total Patterns:  {total_patterns}')

overall = stats.get('overall_success_rate', 'N/A')
print(f'  Overall Success: {overall}')
print()

if domain_data:
    print('  Domain Breakdown:')
    print('  ' + '-' * 50)
    print(f'  {\"Domain\":<20} {\"Patterns\":<12} {\"Success Rate\":<15}')
    print('  ' + '-' * 50)
    for domain, info in sorted(domain_data.items()):
        domain_stats = stats.get('domains', {}).get(domain, {})
        t = domain_stats.get('total_builds', 0)
        s = domain_stats.get('successful_builds', 0)
        rate = f'{s/t:.1%}' if t > 0 else 'N/A'
        print(f'  {domain:<20} {info[\"patterns\"]:<12} {rate:<15}')
    print('  ' + '-' * 50)
else:
    print('  (No pattern data yet)')
print()
" "${KG_BASE_DIR}" "${KG_BUILDS_DIR}" "${KG_PATTERNS_DIR}" "${KG_STATS_FILE}"
    else
        # bash fallback
        local build_count=0
        for bfile in "${KG_BUILDS_DIR}"/*.json; do
            [[ -f "$bfile" ]] && ((build_count++))
        done
        echo "  Total Builds: ${build_count}"

        local domain_count=0
        for ddir in "${KG_PATTERNS_DIR}"/*/; do
            [[ -d "$ddir" ]] && ((domain_count++))
        done
        echo "  Total Domains: ${domain_count}"
        echo ""
        echo "  (Install python3 for detailed report)"
    fi

    echo -e "${KG_BOLD}============================================${KG_NC}"
    echo ""
    return 0
}

# =============================================================================
# kg_auto_record(domain, event, outcome, description, score)
#   Convenience wrapper for kg_record_pattern() that auto-formats the input
#   as a pattern_data JSON and delegates to kg_record_pattern.
#   - domain:      e.g. "crm", "ecommerce", "chat"
#   - event:       e.g. "build", "test", "deploy", "heal"
#   - outcome:     e.g. "success", "failure", "partial"
#   - description: free-text description of what happened
#   - score:       float 0.0 - 1.0 (success_rate)
# =============================================================================
kg_auto_record() {
    local domain="${1:?kg_auto_record: domain required}"
    local event="${2:?kg_auto_record: event required}"
    local outcome="${3:-unknown}"
    local description="${4:-}"
    local score="${5:-0.5}"

    _kg_log LEARN "自動記録: domain=${domain}, event=${event}, outcome=${outcome}"

    # Build pattern_data JSON from arguments
    local safe_desc
    safe_desc="$(echo "$description" | sed 's/"/\\"/g' | head -c 500)"
    local pattern_data='{
  "event": "'"${event}"'",
  "outcome": "'"${outcome}"'",
  "description": "'"${safe_desc}"'",
  "timestamp": "'"$(_kg_timestamp)"'"
}'

    # Delegate to kg_record_pattern
    kg_record_pattern "$domain" "$event" "$pattern_data" "$score"
}

# =============================================================================
# Internal helpers
# =============================================================================

# ---------------------------------------------------------------------------
# _kg_detect_domain(task_desc) -> echoes domain name
# ---------------------------------------------------------------------------
_kg_detect_domain() {
    local desc="$1"
    local desc_lower
    desc_lower="$(echo "$desc" | tr '[:upper:]' '[:lower:]')"

    case "$desc_lower" in
        *crm*|*顧客管理*|*customer*)          echo "crm" ;;
        *ecommerce*|*ec*|*ショップ*|*shop*|*通販*) echo "ecommerce" ;;
        *chat*|*チャット*|*メッセージ*|*message*) echo "chat" ;;
        *家計簿*|*finance*|*会計*|*accounting*)   echo "finance" ;;
        *task*|*タスク*|*todo*|*kanban*)          echo "task-management" ;;
        *blog*|*ブログ*|*cms*)                    echo "blog" ;;
        *api*|*backend*|*バックエンド*)           echo "api" ;;
        *lp*|*landing*|*ランディング*)           echo "landing-page" ;;
        *dashboard*|*ダッシュボード*|*analytics*) echo "dashboard" ;;
        *auth*|*認証*|*login*|*ログイン*)        echo "auth" ;;
        *saas*|*subscription*|*サブスク*)        echo "saas" ;;
        *portfolio*|*ポートフォリオ*)            echo "portfolio" ;;
        *)                                        echo "general" ;;
    esac
}

# ---------------------------------------------------------------------------
# _kg_update_domain_stats(domain, success)
# ---------------------------------------------------------------------------
_kg_update_domain_stats() {
    local domain="$1" success="$2"

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os
from datetime import datetime

stats_file = sys.argv[1]
domain = sys.argv[2]
success = sys.argv[3] == 'true'

stats = {}
if os.path.exists(stats_file):
    try:
        with open(stats_file) as f:
            stats = json.load(f)
    except Exception:
        stats = {}

if 'domains' not in stats:
    stats['domains'] = {}

if domain not in stats['domains']:
    stats['domains'][domain] = {
        'total_builds': 0,
        'successful_builds': 0,
        'failed_builds': 0,
        'first_seen': datetime.utcnow().isoformat() + 'Z'
    }

ds = stats['domains'][domain]
ds['total_builds'] = ds.get('total_builds', 0) + 1
if success:
    ds['successful_builds'] = ds.get('successful_builds', 0) + 1
else:
    ds['failed_builds'] = ds.get('failed_builds', 0) + 1
ds['last_updated'] = datetime.utcnow().isoformat() + 'Z'

# Recalculate overall
total_all = sum(d.get('total_builds', 0) for d in stats['domains'].values())
success_all = sum(d.get('successful_builds', 0) for d in stats['domains'].values())
stats['total_builds'] = total_all
stats['overall_success_rate'] = round(success_all / total_all, 4) if total_all > 0 else 0.0
stats['last_updated'] = datetime.utcnow().isoformat() + 'Z'

with open(stats_file, 'w') as f:
    json.dump(stats, f, indent=2, ensure_ascii=False)
" "${KG_STATS_FILE}" "$domain" "$success"
    else
        _kg_log WARN "python3未検出: ドメイン統計更新スキップ"
    fi
}

# ---------------------------------------------------------------------------
# _kg_auto_extract_patterns(domain, tech_stack, phases_data)
#   Auto-extracts reusable patterns from a successful build
# ---------------------------------------------------------------------------
_kg_auto_extract_patterns() {
    local domain="$1" tech_stack="$2" phases_data="$3"

    # Record tech_stack pattern
    if [[ -n "$tech_stack" && "$tech_stack" != "unknown" ]]; then
        local tech_data='{"tech_stack": "'"$(echo "$tech_stack" | sed 's/"/\\"/g')"'"}'
        kg_record_pattern "$domain" "tech_stack" "$tech_data" "0.8"
    fi

    # Record phases pattern if available
    if [[ -n "$phases_data" && "$phases_data" != "{}" ]]; then
        kg_record_pattern "$domain" "phase_order" "$phases_data" "0.8"
    fi
}

# ---------------------------------------------------------------------------
# _kg_update_index(domain)
# ---------------------------------------------------------------------------
_kg_update_index() {
    local domain="$1"

    if command -v python3 &>/dev/null; then
        python3 -c "
import json, sys, os
from datetime import datetime

index_file = sys.argv[1]
domain = sys.argv[2]

index = {}
if os.path.exists(index_file):
    try:
        with open(index_file) as f:
            index = json.load(f)
    except Exception:
        index = {}

domains = index.get('domains', [])
if domain not in domains:
    domains.append(domain)
    index['domains'] = domains

index['total_domains'] = len(domains)
index['last_updated'] = datetime.utcnow().isoformat() + 'Z'

with open(index_file, 'w') as f:
    json.dump(index, f, indent=2, ensure_ascii=False)
" "${KG_INDEX_FILE}" "$domain"
    fi
}

# ---------------------------------------------------------------------------
# _kg_prune_old_builds()
#   Keeps only the most recent KG_MAX_BUILDS build files
# ---------------------------------------------------------------------------
_kg_prune_old_builds() {
    local count
    count="$(find "${KG_BUILDS_DIR}" -maxdepth 1 -name '*.json' 2>/dev/null | wc -l | tr -d ' ')"

    if [[ "$count" -gt "$KG_MAX_BUILDS" ]]; then
        local to_remove=$(( count - KG_MAX_BUILDS ))
        _kg_log INFO "古いビルド記録を剪定: ${to_remove} 件削除"
        # Remove oldest files by modification time
        find "${KG_BUILDS_DIR}" -maxdepth 1 -name '*.json' -print0 2>/dev/null \
            | xargs -0 ls -1t 2>/dev/null \
            | tail -n "$to_remove" \
            | while read -r f; do rm -f "$f" 2>/dev/null; done
    fi
}
