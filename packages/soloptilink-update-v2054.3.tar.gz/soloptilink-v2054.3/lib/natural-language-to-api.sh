#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v403.0 - Natural Language to API Engine
# =============================================================================
# 自然言語リクエストをAPI呼び出しに変換する。エンドポイント検出・
# パラメータ推論・レスポンスハンドリングを自動化する。
#
# Functions:
#   _nlapi_init            - 初期化・API定義ロード
#   _nlapi_parse_request   - 自然言語をAPIリクエスト仕様にパース
#   _nlapi_generate_call   - APIリクエストコードを生成
#   _nlapi_handle_response - レスポンスハンドリングコードを生成
#   _nlapi_detect_endpoints - プロジェクトからAPIエンドポイント自動検出
#   _nlapi_report          - レポート出力
#   _nlapi_score           - モジュールスコア(0-100)
#
# All globals use the NLAPI_ prefix.
# =============================================================================

[[ -n "${_NATURAL_LANGUAGE_TO_API_LOADED:-}" ]] && return 0
_NATURAL_LANGUAGE_TO_API_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g NLAPI_VERSION="403.0"
declare -g NLAPI_INITIALIZED=false
declare -g NLAPI_STORE_DIR=""
declare -g NLAPI_PARSE_COUNT=0
declare -g NLAPI_GENERATE_COUNT=0
declare -g NLAPI_ENDPOINTS_DETECTED=0

declare -g -A _NLAPI_ENDPOINTS=()      # path → "METHOD:description"
declare -g -A _NLAPI_PARAMS=()         # path → "param1,param2,..."
declare -g -A _NLAPI_RESPONSES=()      # path → response_type
declare -g -a _NLAPI_REQUEST_LOG=()

# HTTP verb keyword mapping
declare -g -A _NLAPI_VERB_MAP=()

# =============================================================================
# _nlapi_init
# =============================================================================
_nlapi_init() {
    local project_dir="${PROJECT_DIR:-.}"
    NLAPI_STORE_DIR="${project_dir}/.soloptilink/nl-api"
    mkdir -p "${NLAPI_STORE_DIR}/calls" "${NLAPI_STORE_DIR}/cache"

    # Verb mapping from natural language
    _NLAPI_VERB_MAP["get"]="GET"
    _NLAPI_VERB_MAP["fetch"]="GET"
    _NLAPI_VERB_MAP["retrieve"]="GET"
    _NLAPI_VERB_MAP["list"]="GET"
    _NLAPI_VERB_MAP["show"]="GET"
    _NLAPI_VERB_MAP["create"]="POST"
    _NLAPI_VERB_MAP["add"]="POST"
    _NLAPI_VERB_MAP["submit"]="POST"
    _NLAPI_VERB_MAP["send"]="POST"
    _NLAPI_VERB_MAP["update"]="PUT"
    _NLAPI_VERB_MAP["modify"]="PUT"
    _NLAPI_VERB_MAP["change"]="PATCH"
    _NLAPI_VERB_MAP["patch"]="PATCH"
    _NLAPI_VERB_MAP["delete"]="DELETE"
    _NLAPI_VERB_MAP["remove"]="DELETE"
    _NLAPI_VERB_MAP["destroy"]="DELETE"

    # Auto-detect endpoints
    _nlapi_detect_endpoints "$project_dir"

    NLAPI_INITIALIZED=true
    return 0
}

# =============================================================================
# _nlapi_detect_endpoints - Auto-detect API endpoints from project
# =============================================================================
_nlapi_detect_endpoints() {
    local project_dir="$1"
    local api_dir=""

    # Find API routes (Next.js App Router pattern)
    for candidate in \
        "${project_dir}/app/api" \
        "${project_dir}/admin-dashboard/app/api" \
        "${project_dir}/src/app/api" \
        "${project_dir}/pages/api" \
        "${project_dir}/src/pages/api"; do
        [[ -d "$candidate" ]] && { api_dir="$candidate"; break; }
    done

    [[ -z "$api_dir" ]] && return 0

    # Scan route files
    while IFS= read -r route_file; do
        local rel_path="${route_file#${api_dir}}"
        rel_path="/api${rel_path%/route.ts}"
        rel_path="${rel_path%/route.js}"
        rel_path=$(echo "$rel_path" | sed 's/\[/:/g; s/\]//g')

        # Detect HTTP methods from exports
        local methods=""
        if grep -q 'export.*function GET\|export.*GET' "$route_file" 2>/dev/null; then
            methods="${methods:+${methods},}GET"
        fi
        if grep -q 'export.*function POST\|export.*POST' "$route_file" 2>/dev/null; then
            methods="${methods:+${methods},}POST"
        fi
        if grep -q 'export.*function PUT\|export.*PUT' "$route_file" 2>/dev/null; then
            methods="${methods:+${methods},}PUT"
        fi
        if grep -q 'export.*function DELETE\|export.*DELETE' "$route_file" 2>/dev/null; then
            methods="${methods:+${methods},}DELETE"
        fi
        if grep -q 'export.*function PATCH\|export.*PATCH' "$route_file" 2>/dev/null; then
            methods="${methods:+${methods},}PATCH"
        fi

        [[ -n "$methods" ]] && {
            _NLAPI_ENDPOINTS["$rel_path"]="$methods"
            NLAPI_ENDPOINTS_DETECTED=$((NLAPI_ENDPOINTS_DETECTED + 1))
        }
    done < <(find "$api_dir" -name "route.ts" -o -name "route.js" 2>/dev/null)

    return 0
}

# =============================================================================
# _nlapi_parse_request - Parse natural language to API request spec
# =============================================================================
_nlapi_parse_request() {
    local nl_request="$1"
    [[ -z "$nl_request" ]] && { echo "ERROR: Empty request" >&2; return 1; }

    NLAPI_PARSE_COUNT=$((NLAPI_PARSE_COUNT + 1))
    local lower
    lower=$(echo "$nl_request" | tr '[:upper:]' '[:lower:]')

    local method="GET"
    local endpoint=""
    local body=""
    local params=""

    # Detect HTTP method from first verb
    local first_word
    first_word=$(echo "$lower" | awk '{print $1}')
    local mapped="${_NLAPI_VERB_MAP[$first_word]:-}"
    [[ -n "$mapped" ]] && method="$mapped"

    # Match against known endpoints
    local best_match="" best_score=0
    for ep in "${!_NLAPI_ENDPOINTS[@]}"; do
        local ep_lower
        ep_lower=$(echo "$ep" | tr '[:upper:]' '[:lower:]')
        # Score based on word overlap
        local score=0
        local segment
        for segment in $(echo "$ep_lower" | tr '/' ' ' | tr '-' ' '); do
            [[ ${#segment} -lt 3 ]] && continue
            if echo "$lower" | grep -qi "$segment"; then
                score=$((score + 1))
            fi
        done
        if [[ $score -gt $best_score ]]; then
            best_score=$score
            best_match="$ep"
        fi
    done
    endpoint="${best_match:-/api/unknown}"

    # Extract potential ID parameters
    local id_match
    id_match=$(echo "$nl_request" | grep -oE '[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}|#[0-9]+|id [0-9]+' | head -1)
    [[ -n "$id_match" ]] && params="id=${id_match}"

    # Detect body content hints
    if echo "$lower" | grep -qi 'with name\|with title\|with email'; then
        body="detected_fields"
    fi

    _NLAPI_REQUEST_LOG+=("${method} ${endpoint}")
    cat <<REQEOF
{"method":"${method}","endpoint":"${endpoint}","params":"${params}","body":"${body}","confidence":${best_score}}
REQEOF
    return 0
}

# =============================================================================
# _nlapi_generate_call - Generate API call code from request spec
# =============================================================================
_nlapi_generate_call() {
    local request_spec="$1"
    local language="${2:-typescript}"  # typescript|curl|python

    [[ "$NLAPI_INITIALIZED" != "true" ]] && { echo "ERROR: NLAPI not initialized" >&2; return 1; }
    NLAPI_GENERATE_COUNT=$((NLAPI_GENERATE_COUNT + 1))

    local method endpoint params body
    method=$(echo "$request_spec" | sed 's/.*"method":"\([^"]*\)".*/\1/')
    endpoint=$(echo "$request_spec" | sed 's/.*"endpoint":"\([^"]*\)".*/\1/')
    params=$(echo "$request_spec" | sed 's/.*"params":"\([^"]*\)".*/\1/')
    body=$(echo "$request_spec" | sed 's/.*"body":"\([^"]*\)".*/\1/')

    case "$language" in
        typescript)
            cat <<TSEOF
const response = await fetch('${endpoint}', {
  method: '${method}',
  headers: {
    'Content-Type': 'application/json',
    'Authorization': \`Bearer \${token}\`,
  },
${body:+  body: JSON.stringify(data),}
});

if (!response.ok) {
  const error = await response.json();
  throw new Error(error.message || 'API request failed');
}

const result = await response.json();
TSEOF
            ;;
        curl)
            local curl_cmd="curl -s -X ${method}"
            curl_cmd+=" -H 'Content-Type: application/json'"
            curl_cmd+=" -H 'Authorization: Bearer \${TOKEN}'"
            [[ -n "$body" ]] && curl_cmd+=" -d '\${JSON_BODY}'"
            curl_cmd+=" '${endpoint}'"
            echo "$curl_cmd"
            ;;
        python)
            cat <<PYEOF
import requests

response = requests.${method,,}(
    '${endpoint}',
    headers={'Authorization': f'Bearer {token}'},
${body:+    json=data,}
)
response.raise_for_status()
result = response.json()
PYEOF
            ;;
    esac
    return 0
}

# =============================================================================
# _nlapi_handle_response - Generate response handling code
# =============================================================================
_nlapi_handle_response() {
    local endpoint="$1"
    local response_type="${2:-json}"  # json|stream|blob
    local language="${3:-typescript}"

    case "$language" in
        typescript)
            case "$response_type" in
                json)
                    cat <<'HANDLEEOF'
// Response handler: JSON
try {
  const data = await response.json();
  if (data.error) {
    console.error('API Error:', data.error);
    throw new Error(data.error.message);
  }
  return { success: true, data: data.data ?? data };
} catch (err) {
  if (err instanceof SyntaxError) {
    throw new Error('Invalid JSON response from server');
  }
  throw err;
}
HANDLEEOF
                    ;;
                stream)
                    cat <<'STREAMEOF'
// Response handler: Stream
const reader = response.body?.getReader();
if (!reader) throw new Error('No readable stream');
const decoder = new TextDecoder();
let result = '';
while (true) {
  const { done, value } = await reader.read();
  if (done) break;
  result += decoder.decode(value, { stream: true });
  onChunk?.(decoder.decode(value));
}
return result;
STREAMEOF
                    ;;
                blob)
                    cat <<'BLOBEOF'
// Response handler: Blob
const blob = await response.blob();
const url = URL.createObjectURL(blob);
return { url, blob, size: blob.size, type: blob.type };
BLOBEOF
                    ;;
            esac
            ;;
    esac
    return 0
}

# =============================================================================
# Report / Score
# =============================================================================
_nlapi_report() {
    echo -e "\n  ${BOLD:-}=== Natural Language to API v${NLAPI_VERSION} ===${NC:-}"
    echo -e "  Requests Parsed     : ${NLAPI_PARSE_COUNT}"
    echo -e "  Calls Generated     : ${NLAPI_GENERATE_COUNT}"
    echo -e "  Endpoints Detected  : ${NLAPI_ENDPOINTS_DETECTED}"
}

_nlapi_score() {
    local score=30
    [[ "$NLAPI_INITIALIZED" == "true" ]] && score=$((score + 20))
    [[ $NLAPI_ENDPOINTS_DETECTED -gt 0 ]] && score=$((score + 20))
    [[ $NLAPI_PARSE_COUNT -gt 0 ]] && score=$((score + 15))
    [[ $NLAPI_GENERATE_COUNT -gt 0 ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "natural-language-to-api" \
        --version "403.0" \
        --description "自然言語リクエストからAPI呼び出し自動生成" \
        --init "_nlapi_init" \
        --report "_nlapi_report" \
        --score "_nlapi_score" \
        --enable-var "ENABLE_NLAPI" \
        --cli-flags "--nl-api:--no-nl-api"
fi

# v2003.1: source時のexit codeを確実に0にする
true
