#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v386.0 - Report Template Engine
# =============================================================================
# 帳票/レポートテンプレートエンジン。
# 日報/月次報告/年次決算レポート等のビジネスレポートを自動生成。
#
# All globals use the RTE_ prefix.
# =============================================================================

[[ -n "${_REPORT_TEMPLATE_ENGINE_LOADED:-}" ]] && return 0
_REPORT_TEMPLATE_ENGINE_LOADED=1

declare -g RTE_VERSION="386.0"
declare -g RTE_INITIALIZED=false
declare -g RTE_GENERATED_COUNT=0
declare -g RTE_DAILY_GENERATED=false
declare -g RTE_MONTHLY_GENERATED=false
declare -g RTE_FISCAL_GENERATED=false
declare -g RTE_CUSTOM_GENERATED=false
declare -g ENABLE_RTE="${ENABLE_RTE:-true}"

_rte_init() {
    RTE_INITIALIZED=true
    RTE_GENERATED_COUNT=0
    return 0
}

_rte_generate_all() {
    local project_dir="${1:-.}"
    [[ "$RTE_INITIALIZED" != "true" ]] && _rte_init
    echo -e "  ${CYAN:-\033[0;36m}[RTE]${NC:-\033[0m} レポートテンプレート生成開始..." >&2

    _rte_generate_daily "$project_dir"
    _rte_generate_monthly "$project_dir"
    _rte_generate_fiscal "$project_dir"
    _rte_generate_custom "$project_dir"

    echo -e "  ${GREEN:-\033[0;32m}[RTE]${NC:-\033[0m} レポート生成完了: ${RTE_GENERATED_COUNT}件" >&2
    return 0
}

_rte_generate_daily() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [RTE-DAILY] 日報テンプレート

### Schema
```prisma
model DailyReport {
  id        String   @id @default(cuid())
  userId    String
  date      DateTime
  summary   String
  tasks     Json
  issues    String?
  nextDay   String?
  workHours Float
  status    String   @default("draft")
  submittedAt DateTime?
  approvedBy String?
  createdAt DateTime @default(now())
  @@unique([userId, date])
  @@index([date])
}
```

### Daily Report Form
```tsx
'use client';
export function DailyReportForm({ date }: { date: Date }) {
  const { register, handleSubmit, control, formState: { errors, isSubmitting } } = useForm({
    resolver: zodResolver(z.object({
      summary: z.string().min(10, '10文字以上で入力'),
      tasks: z.array(z.object({ title: z.string(), status: z.enum(['done', 'in_progress', 'blocked']), hours: z.number() })).min(1),
      issues: z.string().optional(),
      nextDay: z.string().optional(),
      workHours: z.number().min(0).max(24),
    })),
  });

  const { fields, append, remove } = useFieldArray({ control, name: 'tasks' });
  const onSubmit = async (data: any) => {
    await fetch('/api/reports/daily', { method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...data, date: date.toISOString() }) });
    toast.success('日報を提出しました');
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <Textarea label="本日の概要" {...register('summary')} error={errors.summary?.message} />
      <div>
        <h3 className="font-semibold mb-2">タスク一覧</h3>
        {fields.map((field, index) => (
          <div key={field.id} className="flex gap-2 mb-2">
            <Input {...register(`tasks.${index}.title`)} placeholder="タスク名" className="flex-1" />
            <Select {...register(`tasks.${index}.status`)}>
              <option value="done">完了</option><option value="in_progress">進行中</option><option value="blocked">ブロック</option>
            </Select>
            <Input type="number" step="0.5" {...register(`tasks.${index}.hours`, { valueAsNumber: true })} className="w-20" />
            <Button variant="ghost" size="sm" onClick={() => remove(index)}>x</Button>
          </div>
        ))}
        <Button variant="outline" size="sm" onClick={() => append({ title: '', status: 'done', hours: 1 })}>+ タスク追加</Button>
      </div>
      <Textarea label="課題・問題点" {...register('issues')} />
      <Textarea label="明日の予定" {...register('nextDay')} />
      <Input type="number" step="0.5" label="勤務時間" {...register('workHours', { valueAsNumber: true })} />
      <Button type="submit" disabled={isSubmitting}>{isSubmitting ? '提出中...' : '日報を提出'}</Button>
    </form>
  );
}
```
TEMPLATE

    RTE_DAILY_GENERATED=true
    RTE_GENERATED_COUNT=$((RTE_GENERATED_COUNT + 1))
    return 0
}

_rte_generate_monthly() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [RTE-MONTHLY] 月次レポートテンプレート

### Monthly Aggregation
```typescript
export async function generateMonthlyReport(year: number, month: number) {
  const start = new Date(year, month - 1, 1);
  const end = new Date(year, month, 0, 23, 59, 59);

  const [sales, expenses, newCustomers, churned, tasks] = await Promise.all([
    prisma.order.aggregate({ where: { status: 'paid', paidAt: { gte: start, lte: end } }, _sum: { total: true }, _count: true }),
    prisma.expense.aggregate({ where: { date: { gte: start, lte: end } }, _sum: { amount: true } }),
    prisma.customer.count({ where: { createdAt: { gte: start, lte: end } } }),
    prisma.customer.count({ where: { churnedAt: { gte: start, lte: end } } }),
    prisma.task.groupBy({ by: ['status'], where: { updatedAt: { gte: start, lte: end } }, _count: true }),
  ]);

  return {
    period: { year, month },
    revenue: { total: sales._sum.total ?? 0, orderCount: sales._count },
    expenses: expenses._sum.amount ?? 0,
    profit: (sales._sum.total ?? 0) - (expenses._sum.amount ?? 0),
    customers: { new: newCustomers, churned, net: newCustomers - churned },
    tasks: Object.fromEntries(tasks.map(t => [t.status, t._count])),
  };
}
```
TEMPLATE

    RTE_MONTHLY_GENERATED=true
    RTE_GENERATED_COUNT=$((RTE_GENERATED_COUNT + 1))
    return 0
}

_rte_generate_fiscal() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [RTE-FISCAL] 年次/決算レポートテンプレート

### Fiscal Year Report
```typescript
export async function generateFiscalReport(fiscalYear: number) {
  const start = new Date(fiscalYear, 3, 1);  // 4月始まり
  const end = new Date(fiscalYear + 1, 2, 31, 23, 59, 59);

  const monthlyData = [];
  for (let m = 0; m < 12; m++) {
    const mStart = new Date(start.getFullYear(), start.getMonth() + m, 1);
    const mEnd = new Date(start.getFullYear(), start.getMonth() + m + 1, 0, 23, 59, 59);
    const revenue = await prisma.order.aggregate({
      where: { status: 'paid', paidAt: { gte: mStart, lte: mEnd } }, _sum: { total: true },
    });
    monthlyData.push({ month: mStart, revenue: revenue._sum.total ?? 0 });
  }

  const totalRevenue = monthlyData.reduce((s, m) => s + m.revenue, 0);
  const yoyGrowth = await calculateYoYGrowth(fiscalYear);

  return {
    fiscalYear, period: { start, end }, monthlyData, totalRevenue, yoyGrowth,
    averageMonthly: Math.round(totalRevenue / 12),
  };
}
```
TEMPLATE

    RTE_FISCAL_GENERATED=true
    RTE_GENERATED_COUNT=$((RTE_GENERATED_COUNT + 1))
    return 0
}

_rte_generate_custom() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [RTE-CUSTOM] カスタムレポートビルダー

```typescript
interface ReportField { key: string; label: string; type: 'number' | 'string' | 'date' | 'currency'; aggregation?: 'sum' | 'avg' | 'count' | 'min' | 'max'; }

export class ReportBuilder {
  private fields: ReportField[] = [];
  private filters: Record<string, any> = {};
  private groupBy: string[] = [];
  private orderBy: { field: string; direction: 'asc' | 'desc' }[] = [];

  addField(field: ReportField): this { this.fields.push(field); return this; }
  setFilter(key: string, value: any): this { this.filters[key] = value; return this; }
  setGroupBy(fields: string[]): this { this.groupBy = fields; return this; }
  setOrderBy(field: string, direction: 'asc' | 'desc' = 'asc'): this { this.orderBy.push({ field, direction }); return this; }

  async execute(): Promise<ReportResult> {
    // Build and execute Prisma query from configuration
    const data = await this.buildAndExecuteQuery();
    return { fields: this.fields, data, generatedAt: new Date() };
  }

  async exportCSV(): Promise<string> {
    const result = await this.execute();
    const header = this.fields.map(f => f.label).join(',');
    const rows = result.data.map(row => this.fields.map(f => row[f.key]).join(','));
    return [header, ...rows].join('\n');
  }
}
```
TEMPLATE

    RTE_CUSTOM_GENERATED=true
    RTE_GENERATED_COUNT=$((RTE_GENERATED_COUNT + 1))
    return 0
}

_rte_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Report Template Engine v${RTE_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成レポート数     : ${RTE_GENERATED_COUNT}"
    echo -e "  日報               : ${RTE_DAILY_GENERATED}"
    echo -e "  月次               : ${RTE_MONTHLY_GENERATED}"
    echo -e "  年次/決算          : ${RTE_FISCAL_GENERATED}"
    echo -e "  カスタム           : ${RTE_CUSTOM_GENERATED}"
}

_rte_score() {
    local score=30
    [[ "$RTE_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$RTE_DAILY_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$RTE_MONTHLY_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$RTE_FISCAL_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$RTE_CUSTOM_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "report-template-engine" \
    --version "386.0" \
    --description "レポートテンプレート（日報/月次/年次決算/カスタム）" \
    --init "_rte_init" \
    --report "_rte_report" \
    --score "_rte_score" \
    --enable-var "ENABLE_RTE" \
    --cli-flags "--report-templates:--no-report-templates"
