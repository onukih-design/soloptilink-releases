#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - Notification Engine
# =============================================================================
# 通知基盤の完全自動構築: Email/Push/In-App マルチチャネル対応。
# 通知サービス、テンプレート、ユーザー設定、リアルタイムSSE配信を
# 本番品質TypeScript/Reactコードとして直接生成する。
#
# Functions:
#   ne_init()                          - Initialize notification config
#   ne_generate_notification_service() - Core notification service
#   ne_generate_email_provider()       - Email (Resend/SendGrid/Nodemailer)
#   ne_generate_push_provider()        - Push notifications (web-push)
#   ne_generate_in_app()               - In-app (bell, SSE, read/unread)
#   ne_generate_notification_preferences() - User preferences
#   ne_generate_templates()            - Notification templates
#   ne_generate_notifications()        - Full scaffold
#   ne_inject_notification_patterns()  - Inject patterns into Claude prompt
#   ne_report() / ne_score()          - Reporting
#
# All globals use the NE_ prefix.
# =============================================================================

[[ -n "${_NE_LOADED:-}" ]] && return 0; _NE_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g NE_VERSION="140.0"
NE_GENERATED=0
NE_ERRORS=0
NE_FILES_WRITTEN=0
NE_PHASE="notification"
NE_SERVICE_OK=false
NE_EMAIL_OK=false
NE_PUSH_OK=false
NE_INAPP_OK=false
NE_PREFERENCES_OK=false
NE_TEMPLATES_OK=false

# =============================================================================
# Init
# =============================================================================
ne_init() {
    NE_GENERATED=0
    NE_ERRORS=0
    NE_FILES_WRITTEN=0
    NE_SERVICE_OK=false
    NE_EMAIL_OK=false
    NE_PUSH_OK=false
    NE_INAPP_OK=false
    NE_PREFERENCES_OK=false
    NE_TEMPLATES_OK=false
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} Notification Engine v${NE_VERSION}"
    return 0
}

# =============================================================================
# Utility
# =============================================================================
_ne_write_file() {
    local filepath="$1"
    local content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        NE_FILES_WRITTEN=$((NE_FILES_WRITTEN + 1))
        return 0
    else
        NE_ERRORS=$((NE_ERRORS + 1))
        return 1
    fi
}

# =============================================================================
# Generate Core Notification Service
# =============================================================================
ne_generate_notification_service() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ne_write_file "${project_dir}/src/lib/notification-service.ts" "$(cat <<'TYPESCRIPT'
import { prisma } from '@/lib/prisma';
import { sendEmail } from './email-provider';
import { sendPush } from './push-provider';
import { logger } from '@/lib/logger';

// ====================================================================
// Multi-Channel Notification Service
// ====================================================================

export type NotificationChannel = 'email' | 'push' | 'in_app';
export type NotificationType = 'info' | 'success' | 'warning' | 'error' | 'action_required';

export interface NotificationPayload {
  userId: string;
  type: NotificationType;
  title: string;
  body: string;
  channels: NotificationChannel[];
  data?: Record<string, unknown>;    // Structured data for templates
  actionUrl?: string;                 // Deep link for the notification
  templateId?: string;                // Template to use
  priority?: 'low' | 'normal' | 'high' | 'urgent';
}

interface ChannelResult {
  channel: NotificationChannel;
  success: boolean;
  error?: string;
}

/** Send a notification through specified channels, respecting user preferences */
export async function sendNotification(payload: NotificationPayload): Promise<ChannelResult[]> {
  const log = logger;
  const results: ChannelResult[] = [];

  // Check user preferences for each channel
  const preferences = await prisma.notificationPreference.findUnique({
    where: { userId: payload.userId },
  }).catch(() => null);

  for (const channel of payload.channels) {
    // Respect user opt-out (unless urgent priority)
    if (preferences && payload.priority !== 'urgent') {
      const prefKey = `${channel}Enabled` as keyof typeof preferences;
      if (preferences[prefKey] === false) {
        results.push({ channel, success: false, error: 'User opted out' });
        continue;
      }
    }

    try {
      switch (channel) {
        case 'email': {
          const user = await prisma.user.findUnique({ where: { id: payload.userId }, select: { email: true, name: true } });
          if (user?.email) {
            await sendEmail({
              to: user.email,
              subject: payload.title,
              html: renderNotificationEmail(payload),
            });
          }
          results.push({ channel: 'email', success: true });
          break;
        }
        case 'push': {
          await sendPush(payload.userId, {
            title: payload.title,
            body: payload.body,
            url: payload.actionUrl,
            data: payload.data,
          });
          results.push({ channel: 'push', success: true });
          break;
        }
        case 'in_app': {
          await prisma.notification.create({
            data: {
              userId: payload.userId,
              type: payload.type,
              title: payload.title,
              body: payload.body,
              actionUrl: payload.actionUrl,
              data: payload.data ? JSON.stringify(payload.data) : null,
              priority: payload.priority || 'normal',
            },
          });
          results.push({ channel: 'in_app', success: true });
          break;
        }
      }
    } catch (error) {
      const errMsg = error instanceof Error ? error.message : String(error);
      log.error(`Notification failed on ${channel}`, error as Error, { userId: payload.userId });
      results.push({ channel, success: false, error: errMsg });
    }
  }

  return results;
}

/** Send to multiple users at once */
export async function sendBulkNotification(
  userIds: string[],
  payload: Omit<NotificationPayload, 'userId'>
): Promise<Map<string, ChannelResult[]>> {
  const resultMap = new Map<string, ChannelResult[]>();
  // Process in batches of 10 to avoid overwhelming external services
  const batchSize = 10;
  for (let i = 0; i < userIds.length; i += batchSize) {
    const batch = userIds.slice(i, i + batchSize);
    const batchResults = await Promise.allSettled(
      batch.map(userId => sendNotification({ ...payload, userId }))
    );
    batch.forEach((userId, idx) => {
      const result = batchResults[idx];
      resultMap.set(userId, result.status === 'fulfilled' ? result.value : []);
    });
  }
  return resultMap;
}

/** Simple email HTML renderer */
function renderNotificationEmail(payload: NotificationPayload): string {
  return `
    <div style="font-family: -apple-system, sans-serif; max-width: 600px; margin: 0 auto; padding: 20px;">
      <h2 style="color: #1a1a1a; margin-bottom: 16px;">${escapeHtml(payload.title)}</h2>
      <p style="color: #4a4a4a; line-height: 1.6;">${escapeHtml(payload.body)}</p>
      ${payload.actionUrl ? `<a href="${escapeHtml(payload.actionUrl)}" style="display: inline-block; margin-top: 16px; padding: 10px 24px; background: #4f46e5; color: white; text-decoration: none; border-radius: 6px;">View Details</a>` : ''}
      <hr style="margin-top: 32px; border: none; border-top: 1px solid #e5e7eb;" />
      <p style="color: #9ca3af; font-size: 12px;">You received this because of your notification settings.</p>
    </div>
  `;
}

function escapeHtml(str: string): string {
  return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
}
TYPESCRIPT
)"

    # Prisma schema fragment for notifications
    _ne_write_file "${project_dir}/prisma/notification-schema-fragment.prisma" "$(cat <<'PRISMA'
// Notification models - merge into your main schema.prisma

model Notification {
  id        String   @id @default(cuid())
  userId    String
  type      String   @default("info")  // info | success | warning | error | action_required
  title     String
  body      String
  actionUrl String?
  data      String?  // JSON payload
  priority  String   @default("normal")  // low | normal | high | urgent
  read      Boolean  @default(false)
  readAt    DateTime?
  createdAt DateTime @default(now())

  user User @relation(fields: [userId], references: [id], onDelete: Cascade)

  @@index([userId, read])
  @@index([userId, createdAt])
}

model NotificationPreference {
  id            String  @id @default(cuid())
  userId        String  @unique
  emailEnabled  Boolean @default(true)
  pushEnabled   Boolean @default(true)
  in_appEnabled Boolean @default(true)
  // Per-type overrides (JSON: { "marketing": false, "system": true })
  typeOverrides String?

  user User @relation(fields: [userId], references: [id], onDelete: Cascade)
}

model PushSubscription {
  id        String   @id @default(cuid())
  userId    String
  endpoint  String   @unique
  p256dh    String
  auth      String
  userAgent String?
  createdAt DateTime @default(now())

  user User @relation(fields: [userId], references: [id], onDelete: Cascade)

  @@index([userId])
}
PRISMA
)"
    NE_SERVICE_OK=true
    NE_GENERATED=$((NE_GENERATED + 1))
}

# =============================================================================
# Generate Email Provider
# =============================================================================
ne_generate_email_provider() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ne_write_file "${project_dir}/src/lib/email-provider.ts" "$(cat <<'TYPESCRIPT'
import { logger } from '@/lib/logger';

// ====================================================================
// Email Provider - Resend / SendGrid / SMTP fallback
// ====================================================================

interface EmailMessage {
  to: string;
  subject: string;
  html: string;
  from?: string;
  replyTo?: string;
  attachments?: Array<{ filename: string; content: Buffer }>;
}

const FROM_DEFAULT = process.env.EMAIL_FROM || 'noreply@example.com';
const PROVIDER = process.env.EMAIL_PROVIDER || 'resend'; // resend | sendgrid | smtp

/** Send email via configured provider */
export async function sendEmail(message: EmailMessage): Promise<boolean> {
  const from = message.from || FROM_DEFAULT;

  try {
    switch (PROVIDER) {
      case 'resend': return await sendViaResend({ ...message, from });
      case 'sendgrid': return await sendViaSendGrid({ ...message, from });
      case 'smtp': return await sendViaSMTP({ ...message, from });
      default:
        // Development: log to console instead of sending
        logger.info('[email] Dev mode - email logged', {
          to: message.to,
          subject: message.subject,
        });
        return true;
    }
  } catch (error) {
    logger.error('[email] Send failed', error as Error, { to: message.to, subject: message.subject });
    return false;
  }
}

async function sendViaResend(msg: EmailMessage & { from: string }): Promise<boolean> {
  const apiKey = process.env.RESEND_API_KEY;
  if (!apiKey) throw new Error('RESEND_API_KEY not configured');

  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: msg.from, to: msg.to, subject: msg.subject, html: msg.html }),
  });

  if (!res.ok) {
    const body = await res.text();
    throw new Error(`Resend API error ${res.status}: ${body}`);
  }
  return true;
}

async function sendViaSendGrid(msg: EmailMessage & { from: string }): Promise<boolean> {
  const apiKey = process.env.SENDGRID_API_KEY;
  if (!apiKey) throw new Error('SENDGRID_API_KEY not configured');

  const res = await fetch('https://api.sendgrid.com/v3/mail/send', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      personalizations: [{ to: [{ email: msg.to }] }],
      from: { email: msg.from },
      subject: msg.subject,
      content: [{ type: 'text/html', value: msg.html }],
    }),
  });

  if (!res.ok) throw new Error(`SendGrid error ${res.status}`);
  return true;
}

async function sendViaSMTP(msg: EmailMessage & { from: string }): Promise<boolean> {
  // Dynamic import to avoid bundling nodemailer when not needed
  const nodemailer = await import('nodemailer');
  const transport = nodemailer.createTransport({
    host: process.env.SMTP_HOST || 'localhost',
    port: parseInt(process.env.SMTP_PORT || '587'),
    secure: process.env.SMTP_SECURE === 'true',
    auth: process.env.SMTP_USER ? { user: process.env.SMTP_USER, pass: process.env.SMTP_PASS } : undefined,
  });
  await transport.sendMail({ from: msg.from, to: msg.to, subject: msg.subject, html: msg.html });
  return true;
}
TYPESCRIPT
)"
    NE_EMAIL_OK=true
    NE_GENERATED=$((NE_GENERATED + 1))
}

# =============================================================================
# Generate Push Provider
# =============================================================================
ne_generate_push_provider() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ne_write_file "${project_dir}/src/lib/push-provider.ts" "$(cat <<'TYPESCRIPT'
import { prisma } from '@/lib/prisma';
import { logger } from '@/lib/logger';

// ====================================================================
// Web Push Notifications
// ====================================================================

interface PushPayload {
  title: string;
  body: string;
  url?: string;
  icon?: string;
  data?: Record<string, unknown>;
}

const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY || '';
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY || '';
const VAPID_SUBJECT = process.env.VAPID_SUBJECT || 'mailto:admin@example.com';

/** Send push notification to all user's registered devices */
export async function sendPush(userId: string, payload: PushPayload): Promise<void> {
  if (!VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY) {
    logger.warn('[push] VAPID keys not configured, skipping push notification');
    return;
  }

  const subscriptions = await prisma.pushSubscription.findMany({ where: { userId } });
  if (subscriptions.length === 0) return;

  // Lazy-load web-push to avoid bundling when not needed
  const webpush = await import('web-push');
  webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);

  const pushPayload = JSON.stringify({
    title: payload.title,
    body: payload.body,
    icon: payload.icon || '/icon-192.png',
    data: { url: payload.url, ...payload.data },
  });

  const results = await Promise.allSettled(
    subscriptions.map(sub =>
      webpush.sendNotification(
        { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
        pushPayload
      )
    )
  );

  // Clean up expired/invalid subscriptions
  for (let i = 0; i < results.length; i++) {
    if (results[i].status === 'rejected') {
      const error = (results[i] as PromiseRejectedResult).reason;
      if (error?.statusCode === 410 || error?.statusCode === 404) {
        await prisma.pushSubscription.delete({ where: { id: subscriptions[i].id } }).catch(() => {});
        logger.info('[push] Removed expired subscription', { subscriptionId: subscriptions[i].id });
      }
    }
  }
}

/** Register a push subscription for a user */
export async function registerPushSubscription(
  userId: string,
  subscription: { endpoint: string; keys: { p256dh: string; auth: string } },
  userAgent?: string
): Promise<void> {
  await prisma.pushSubscription.upsert({
    where: { endpoint: subscription.endpoint },
    update: { p256dh: subscription.keys.p256dh, auth: subscription.keys.auth, userAgent },
    create: {
      userId,
      endpoint: subscription.endpoint,
      p256dh: subscription.keys.p256dh,
      auth: subscription.keys.auth,
      userAgent,
    },
  });
}

/** Get VAPID public key for client-side subscription */
export function getVapidPublicKey(): string {
  return VAPID_PUBLIC_KEY;
}
TYPESCRIPT
)"
    NE_PUSH_OK=true
    NE_GENERATED=$((NE_GENERATED + 1))
}

# =============================================================================
# Generate In-App Notifications (API + SSE + React hook)
# =============================================================================
ne_generate_in_app() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    # Notification API (CRUD)
    _ne_write_file "${project_dir}/src/app/api/notifications/route.ts" "$(cat <<'TYPESCRIPT'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';

/** GET /api/notifications - List user's notifications */
export async function GET(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const url = request.nextUrl;
    const page = parseInt(url.searchParams.get('page') || '1');
    const limit = Math.min(parseInt(url.searchParams.get('limit') || '20'), 50);
    const unreadOnly = url.searchParams.get('unread') === 'true';

    const where = { userId: user.userId, ...(unreadOnly ? { read: false } : {}) };
    const [notifications, total, unreadCount] = await Promise.all([
      prisma.notification.findMany({
        where,
        orderBy: { createdAt: 'desc' },
        skip: (page - 1) * limit,
        take: limit,
      }),
      prisma.notification.count({ where }),
      prisma.notification.count({ where: { userId: user.userId, read: false } }),
    ]);

    return NextResponse.json({ notifications, total, unreadCount, page, limit });
  } catch (error) {
    console.error('[notifications] GET error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

/** PATCH /api/notifications - Mark notifications as read */
export async function PATCH(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await request.json();
    const { ids, markAllRead } = body as { ids?: string[]; markAllRead?: boolean };

    if (markAllRead) {
      await prisma.notification.updateMany({
        where: { userId: user.userId, read: false },
        data: { read: true, readAt: new Date() },
      });
    } else if (ids?.length) {
      await prisma.notification.updateMany({
        where: { id: { in: ids }, userId: user.userId },
        data: { read: true, readAt: new Date() },
      });
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('[notifications] PATCH error:', error);
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
TYPESCRIPT
)"

    # SSE endpoint for real-time notifications
    _ne_write_file "${project_dir}/src/app/api/notifications/stream/route.ts" "$(cat <<'TYPESCRIPT'
import { NextRequest } from 'next/server';
import { getCurrentUser } from '@/lib/auth';

// In-memory SSE connections (per-process; use Redis pub/sub for multi-instance)
const connections = new Map<string, Set<ReadableStreamDefaultController>>();

/** Add an SSE connection for a user */
export function addSSEConnection(userId: string, controller: ReadableStreamDefaultController) {
  if (!connections.has(userId)) connections.set(userId, new Set());
  connections.get(userId)!.add(controller);
}

/** Remove an SSE connection */
export function removeSSEConnection(userId: string, controller: ReadableStreamDefaultController) {
  connections.get(userId)?.delete(controller);
  if (connections.get(userId)?.size === 0) connections.delete(userId);
}

/** Push notification to user's SSE connections */
export function pushToUser(userId: string, data: Record<string, unknown>) {
  const userConns = connections.get(userId);
  if (!userConns) return;
  const message = `data: ${JSON.stringify(data)}\n\n`;
  const encoder = new TextEncoder();
  for (const controller of userConns) {
    try { controller.enqueue(encoder.encode(message)); } catch { userConns.delete(controller); }
  }
}

/** GET /api/notifications/stream - SSE endpoint */
export async function GET(request: NextRequest) {
  const user = await getCurrentUser();
  if (!user) {
    return new Response('Unauthorized', { status: 401 });
  }

  const stream = new ReadableStream({
    start(controller) {
      addSSEConnection(user.userId, controller);
      // Send initial heartbeat
      const encoder = new TextEncoder();
      controller.enqueue(encoder.encode(': heartbeat\n\n'));

      // Heartbeat interval to keep connection alive
      const heartbeat = setInterval(() => {
        try { controller.enqueue(encoder.encode(': heartbeat\n\n')); } catch { clearInterval(heartbeat); }
      }, 30000);

      // Cleanup on close
      request.signal.addEventListener('abort', () => {
        clearInterval(heartbeat);
        removeSSEConnection(user.userId, controller);
        try { controller.close(); } catch {}
      });
    },
  });

  return new Response(stream, {
    headers: {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache',
      'Connection': 'keep-alive',
    },
  });
}
TYPESCRIPT
)"

    # React hook for notifications
    _ne_write_file "${project_dir}/src/hooks/useNotifications.ts" "$(cat <<'TYPESCRIPT'
'use client';
import { useState, useEffect, useCallback, useRef } from 'react';
import useSWR from 'swr';

interface Notification {
  id: string;
  type: string;
  title: string;
  body: string;
  actionUrl?: string;
  read: boolean;
  createdAt: string;
}

const fetcher = (url: string) => fetch(url).then(r => r.json());

export function useNotifications() {
  const { data, mutate } = useSWR('/api/notifications?limit=20', fetcher, {
    refreshInterval: 30000,
  });
  const [unreadCount, setUnreadCount] = useState(0);
  const eventSourceRef = useRef<EventSource | null>(null);

  // SSE connection for real-time updates
  useEffect(() => {
    const es = new EventSource('/api/notifications/stream');
    eventSourceRef.current = es;

    es.onmessage = (event) => {
      try {
        const notification = JSON.parse(event.data);
        mutate(); // Refetch notifications
        setUnreadCount(prev => prev + 1);
      } catch {}
    };

    es.onerror = () => {
      // Auto-reconnect is handled by EventSource
    };

    return () => { es.close(); };
  }, [mutate]);

  useEffect(() => {
    if (data?.unreadCount !== undefined) {
      setUnreadCount(data.unreadCount);
    }
  }, [data?.unreadCount]);

  const markAsRead = useCallback(async (ids: string[]) => {
    await fetch('/api/notifications', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ids }),
    });
    mutate();
  }, [mutate]);

  const markAllRead = useCallback(async () => {
    await fetch('/api/notifications', {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ markAllRead: true }),
    });
    mutate();
  }, [mutate]);

  return {
    notifications: (data?.notifications ?? []) as Notification[],
    unreadCount,
    total: data?.total ?? 0,
    markAsRead,
    markAllRead,
    refresh: mutate,
  };
}
TYPESCRIPT
)"
    NE_INAPP_OK=true
    NE_GENERATED=$((NE_GENERATED + 1))
}

# =============================================================================
# Generate Notification Preferences
# =============================================================================
ne_generate_notification_preferences() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ne_write_file "${project_dir}/src/app/api/notifications/preferences/route.ts" "$(cat <<'TYPESCRIPT'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';
import { getCurrentUser } from '@/lib/auth';
import { z } from 'zod';

const preferencesSchema = z.object({
  emailEnabled: z.boolean().optional(),
  pushEnabled: z.boolean().optional(),
  in_appEnabled: z.boolean().optional(),
  typeOverrides: z.record(z.boolean()).optional(),
});

/** GET /api/notifications/preferences */
export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const prefs = await prisma.notificationPreference.findUnique({
      where: { userId: user.userId },
    });

    return NextResponse.json(prefs || {
      emailEnabled: true,
      pushEnabled: true,
      in_appEnabled: true,
      typeOverrides: null,
    });
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

/** PUT /api/notifications/preferences */
export async function PUT(request: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await request.json();
    const parsed = preferencesSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: 'Validation failed', details: parsed.error.flatten() }, { status: 400 });
    }

    const data = {
      ...parsed.data,
      typeOverrides: parsed.data.typeOverrides ? JSON.stringify(parsed.data.typeOverrides) : undefined,
    };

    const prefs = await prisma.notificationPreference.upsert({
      where: { userId: user.userId },
      update: data,
      create: { userId: user.userId, ...data },
    });

    return NextResponse.json(prefs);
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
TYPESCRIPT
)"
    NE_PREFERENCES_OK=true
    NE_GENERATED=$((NE_GENERATED + 1))
}

# =============================================================================
# Generate Notification Templates
# =============================================================================
ne_generate_templates() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    _ne_write_file "${project_dir}/src/lib/notification-templates.ts" "$(cat <<'TYPESCRIPT'
// ====================================================================
// Notification Templates with Variable Substitution
// ====================================================================

export interface NotificationTemplate {
  id: string;
  title: string;      // Supports {{variable}} placeholders
  body: string;
  defaultChannels: ('email' | 'push' | 'in_app')[];
  priority: 'low' | 'normal' | 'high' | 'urgent';
}

const TEMPLATES: Record<string, NotificationTemplate> = {
  welcome: {
    id: 'welcome',
    title: 'Welcome to {{appName}}!',
    body: 'Hi {{userName}}, your account has been created successfully. Get started by exploring your dashboard.',
    defaultChannels: ['email', 'in_app'],
    priority: 'normal',
  },
  password_changed: {
    id: 'password_changed',
    title: 'Password Changed',
    body: 'Your password was changed on {{date}}. If this was not you, contact support immediately.',
    defaultChannels: ['email', 'in_app', 'push'],
    priority: 'high',
  },
  task_assigned: {
    id: 'task_assigned',
    title: 'New Task: {{taskTitle}}',
    body: '{{assignerName}} assigned you "{{taskTitle}}" with deadline {{deadline}}.',
    defaultChannels: ['in_app', 'push'],
    priority: 'normal',
  },
  task_completed: {
    id: 'task_completed',
    title: 'Task Completed: {{taskTitle}}',
    body: '{{completedBy}} completed "{{taskTitle}}".',
    defaultChannels: ['in_app'],
    priority: 'low',
  },
  invoice_created: {
    id: 'invoice_created',
    title: 'Invoice #{{invoiceNumber}} Created',
    body: 'A new invoice for {{amount}} has been created for {{clientName}}.',
    defaultChannels: ['email', 'in_app'],
    priority: 'normal',
  },
  system_alert: {
    id: 'system_alert',
    title: 'System Alert: {{alertType}}',
    body: '{{message}}',
    defaultChannels: ['email', 'in_app', 'push'],
    priority: 'urgent',
  },
};

/** Get a template by ID */
export function getTemplate(templateId: string): NotificationTemplate | null {
  return TEMPLATES[templateId] ?? null;
}

/** Render template with variables */
export function renderTemplate(
  template: NotificationTemplate,
  variables: Record<string, string>
): { title: string; body: string } {
  let title = template.title;
  let body = template.body;
  for (const [key, value] of Object.entries(variables)) {
    const placeholder = `{{${key}}}`;
    title = title.split(placeholder).join(value);
    body = body.split(placeholder).join(value);
  }
  return { title, body };
}

/** Send a templated notification */
export function buildTemplatedNotification(
  templateId: string,
  variables: Record<string, string>,
  userId: string,
  overrides?: Partial<{ channels: ('email' | 'push' | 'in_app')[]; actionUrl: string }>
) {
  const template = getTemplate(templateId);
  if (!template) throw new Error(`Unknown notification template: ${templateId}`);

  const { title, body } = renderTemplate(template, variables);
  return {
    userId,
    type: template.priority === 'urgent' ? 'warning' as const : 'info' as const,
    title,
    body,
    channels: overrides?.channels ?? template.defaultChannels,
    actionUrl: overrides?.actionUrl,
    templateId,
    priority: template.priority,
  };
}
TYPESCRIPT
)"
    NE_TEMPLATES_OK=true
    NE_GENERATED=$((NE_GENERATED + 1))
}

# =============================================================================
# Inject Notification Patterns
# =============================================================================
ne_inject_notification_patterns() {
    local prompt="${1:-}"
    cat <<'INJECT'

## [NOTIFICATION] Notification Best Practices (MANDATORY)

### Multi-Channel Pattern:
```typescript
import { sendNotification } from '@/lib/notification-service';
await sendNotification({
  userId: user.id,
  type: 'info',
  title: 'Task Assigned',
  body: `You have been assigned "${task.title}"`,
  channels: ['in_app', 'push'],
  actionUrl: `/tasks/${task.id}`,
});
```

### Rules:
- ALWAYS use notification-service.ts, NEVER send emails directly
- Respect user preferences (check NotificationPreference before sending)
- Use templates for consistent messaging
- In-app notifications MUST have read/unread state
- SSE for real-time delivery, poll as fallback
- Bulk notifications MUST be batched (max 10 concurrent)
- HTML in emails MUST escape user-provided content (XSS prevention)

INJECT
    echo "$prompt"
}

# =============================================================================
# Full Notification Scaffold
# =============================================================================
ne_generate_notifications() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"

    echo "[notification-engine] Generating notification system for ${project_dir}..."

    ne_generate_notification_service "$project_dir"
    ne_generate_email_provider "$project_dir"
    ne_generate_push_provider "$project_dir"
    ne_generate_in_app "$project_dir"
    ne_generate_notification_preferences "$project_dir"
    ne_generate_templates "$project_dir"

    echo "[notification-engine] Generated ${NE_FILES_WRITTEN} files, ${NE_GENERATED} components"
    return 0
}

# =============================================================================
# Report
# =============================================================================
ne_report() {
    echo -e "\n  ${BOLD:-}=== Notification Engine v${NE_VERSION} ===${NC:-}"
    echo -e "  生成コンポーネント: ${NE_GENERATED}"
    echo -e "  ファイル書込数: ${NE_FILES_WRITTEN}"
    echo -e "  Core Service: $(${NE_SERVICE_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Email Provider: $(${NE_EMAIL_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Push Provider: $(${NE_PUSH_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  In-App + SSE: $(${NE_INAPP_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Preferences: $(${NE_PREFERENCES_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Templates: $(${NE_TEMPLATES_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  エラー: ${NE_ERRORS}"
}

ne_report_json() {
    cat <<JSON
{
  "module": "notification-engine",
  "version": "${NE_VERSION}",
  "generated": ${NE_GENERATED},
  "files_written": ${NE_FILES_WRITTEN},
  "errors": ${NE_ERRORS},
  "components": {
    "service": ${NE_SERVICE_OK},
    "email": ${NE_EMAIL_OK},
    "push": ${NE_PUSH_OK},
    "in_app": ${NE_INAPP_OK},
    "preferences": ${NE_PREFERENCES_OK},
    "templates": ${NE_TEMPLATES_OK}
  }
}
JSON
}

ne_score() {
    local score=40
    ${NE_SERVICE_OK} && score=$((score + 10))
    ${NE_EMAIL_OK} && score=$((score + 10))
    ${NE_PUSH_OK} && score=$((score + 10))
    ${NE_INAPP_OK} && score=$((score + 10))
    ${NE_PREFERENCES_OK} && score=$((score + 10))
    ${NE_TEMPLATES_OK} && score=$((score + 10))
    [[ ${NE_ERRORS} -eq 0 ]] || score=$((score - 10))
    echo "${score}"
}

# =============================================================================
# v59.0: Module Registry self-registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "notification-engine" --version "140.0" \
        --description "通知基盤自動構築×Email/Push/In-App (v140完全実装)" \
        --init "ne_init" --report "ne_report" --report-json "ne_report_json" --score "ne_score" \
        --enable-var "ENABLE_NOTIFICATION" --cli-flags "--notification:--no-notification"
fi

# v2003.1: source時のexit codeを確実に0にする
true
