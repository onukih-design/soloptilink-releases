#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v2034.6 - API Contract Negative Test (ACNT)
# =============================================================================
# 各APIエンドポイントに対し、以下のnegative testを自動実走:
#   1. 空POST → 400期待 (zod/validation検証)
#   2. 不正型POST → 400期待
#   3. 未認証アクセス → 401期待
#   4. (任意) 未認可アクセス → 403期待
#
# 既存 smoke-test-runner は固定の有効データでの正常系のみ実走しており、
# withAuth 等が new Response('{"error":...}', {status: 400}) を返した場合に
# NextResponse.json でラップされて 200 を返してしまう真因 (PFP-049) を
# 検出できなかった。本モジュールは「期待ステータスコード」を厳格に検証する。
#
# 使用:
#   source ~/.soloptilink/lib/api-contract-negative-test.sh
#   acnt_test_endpoint <base_url> <method> <path> [auth_cookie]
#   acnt_test_routes_file <routes_json> <base_url>
#
# 戻り値: 0=全テストPASS, 1=FAIL含む
# =============================================================================

[[ -n "${_ACNT_LOADED:-}" ]] && return 0
_ACNT_LOADED=1

readonly ACNT_VERSION="1.0.0"
ACNT_TIMEOUT="${ACNT_TIMEOUT:-8}"
# v2034.6: zsh alias/PATH汚染を回避するため curl の絶対パスを1回だけ確定
ACNT_CURL_BIN="${ACNT_CURL:-$(command -v curl 2>/dev/null || echo /usr/bin/curl)}"

# ============================================================
# Public: acnt_test_endpoint <base_url> <method> <path> [auth_cookie]
# 1エンドポイントに対し 3〜4 のnegative testを実走
# ============================================================
acnt_test_endpoint() {
    local base_url="$1"
    local method="$2"
    local path="$3"
    local auth_cookie="${4:-}"
    local full_url="${base_url}${path}"

    local results=()
    local pass=0 fail=0

    # Test 1: 未認証アクセス → 401期待 (POST/PUT/PATCH/DELETEで重要)
    if [[ "$method" =~ ^(POST|PUT|PATCH|DELETE)$ ]]; then
        local code
        code=$("$ACNT_CURL_BIN" -s -o /dev/null -w '%{http_code}' \
            -X "$method" \
            -H 'Content-Type: application/json' \
            -d '{}' \
            --max-time "$ACNT_TIMEOUT" \
            "$full_url" 2>/dev/null || echo "000")
        if [[ "$code" == "401" || "$code" == "403" ]]; then
            results+=("PASS|unauth_${method}|${code}")
            pass=$((pass + 1))
        else
            results+=("FAIL|unauth_${method}|${code}|期待401/403、実際${code}")
            fail=$((fail + 1))
        fi
    fi

    # Test 2: 認証付きで空POST → 400期待 (zod validation)
    if [[ "$method" == "POST" || "$method" == "PUT" || "$method" == "PATCH" ]] && [[ -n "$auth_cookie" ]]; then
        local code
        code=$("$ACNT_CURL_BIN" -s -o /dev/null -w '%{http_code}' \
            -X "$method" \
            -H 'Content-Type: application/json' \
            -H "Cookie: $auth_cookie" \
            -d '{}' \
            --max-time "$ACNT_TIMEOUT" \
            "$full_url" 2>/dev/null || echo "000")
        if [[ "$code" == "400" || "$code" == "422" ]]; then
            results+=("PASS|empty_body|${code}")
            pass=$((pass + 1))
        elif [[ "$code" == "200" || "$code" == "201" ]]; then
            results+=("FAIL|empty_body|${code}|空POSTが成功した (zod未適用 or withAuthのResponse誤判定 = PFP-049 真因)")
            fail=$((fail + 1))
        else
            # 500等は別問題、警告のみ
            results+=("WARN|empty_body|${code}|期待400、実際${code}")
        fi
    fi

    # Test 3: 認証付きで不正型 → 400期待
    if [[ "$method" == "POST" || "$method" == "PUT" ]] && [[ -n "$auth_cookie" ]]; then
        local code
        code=$("$ACNT_CURL_BIN" -s -o /dev/null -w '%{http_code}' \
            -X "$method" \
            -H 'Content-Type: application/json' \
            -H "Cookie: $auth_cookie" \
            -d '{"__invalid__field":12345,"name":null,"email":"not-an-email"}' \
            --max-time "$ACNT_TIMEOUT" \
            "$full_url" 2>/dev/null || echo "000")
        if [[ "$code" == "400" || "$code" == "422" ]]; then
            results+=("PASS|invalid_type|${code}")
            pass=$((pass + 1))
        elif [[ "$code" == "200" || "$code" == "201" ]]; then
            results+=("FAIL|invalid_type|${code}|不正型POSTが成功した (zod scheme不十分)")
            fail=$((fail + 1))
        else
            results+=("WARN|invalid_type|${code}|期待400、実際${code}")
        fi
    fi

    # 出力
    for r in "${results[@]}"; do
        echo "[acnt] ${method} ${path}: $r"
    done

    [[ $fail -eq 0 ]]
}

# ============================================================
# Public: acnt_test_routes_file <routes_json> <base_url> [auth_cookie]
# routes.json 経由で全APIエンドポイントに対し negative test 実走
# ============================================================
acnt_test_routes_file() {
    local routes_json="${1:-.rvg/routes.json}"
    local base_url="${2:-http://localhost:3000}"
    local auth_cookie="${3:-}"

    if [[ ! -f "$routes_json" ]]; then
        echo "[acnt] ERROR: routes.json not found: $routes_json" >&2
        return 2
    fi

    local total_pass=0 total_fail=0 endpoints=0

    while IFS=$'\t' read -r kind url method file; do
        [[ "$kind" != "api" ]] && continue
        [[ -z "$method" ]] && continue
        # 動的セグメント (/[id] 等) は仮値で置換
        local resolved_url="${url//\[id\]/test-id-123}"
        resolved_url="${resolved_url//\[code\]/1000001}"

        endpoints=$((endpoints + 1))
        if acnt_test_endpoint "$base_url" "$method" "$resolved_url" "$auth_cookie"; then
            total_pass=$((total_pass + 1))
        else
            total_fail=$((total_fail + 1))
        fi
    done < <(python3 -c "
import json,sys
try:
    with open('$routes_json') as f: data = json.load(f)
    for r in data:
        print('\t'.join([r.get('kind',''), r.get('url',''), r.get('method',''), r.get('file','')]))
except: pass
" 2>/dev/null)

    echo "[acnt] エンドポイント検査: ${endpoints}件 / PASS: ${total_pass} / FAIL: ${total_fail}"
    [[ $total_fail -eq 0 ]]
}

# ============================================================
# Public: acnt_gate <project_dir> <base_url> [auth_cookie]
# Quality Gate統合
# ============================================================
acnt_gate() {
    local project_dir="${1:-.}"
    local base_url="${2:-http://localhost:3000}"
    local auth_cookie="${3:-}"
    local routes_json="${project_dir}/.rvg/routes.json"

    if [[ ! -f "$routes_json" ]]; then
        echo "[acnt-gate] routes.json未生成 - RVG実走後に再試行してください" >&2
        return 0
    fi

    acnt_test_routes_file "$routes_json" "$base_url" "$auth_cookie"
}

# CLI entry
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    cmd="${1:-test}"
    shift || true
    case "$cmd" in
        endpoint) acnt_test_endpoint "$@" ;;
        routes)   acnt_test_routes_file "$@" ;;
        gate)     acnt_gate "$@" ;;
        *) echo "Usage: $0 {endpoint|routes|gate} ..." >&2; exit 2 ;;
    esac
fi
