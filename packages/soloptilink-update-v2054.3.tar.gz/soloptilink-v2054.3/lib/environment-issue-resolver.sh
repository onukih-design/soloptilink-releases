#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v269.0 - Environment Issue Resolver
# =============================================================================
# 環境問題（環境変数、Node.jsバージョン、DB接続、環境設定不一致）を
# 検出・修正し、.env.example テンプレートを生成する。
#
# Functions:
#   _eir_init                - 初期化
#   _eir_check_env_vars     - 必須環境変数チェック
#   _eir_check_node_version - Node.jsバージョン互換性チェック
#   _eir_check_db_connection - DB接続チェック
#   _eir_fix_env_mismatch   - 環境設定不一致修正
#   _eir_generate_env_template - .env.example 生成
#   _eir_report              - レポート出力
#   _eir_score               - モジュールスコア (0-100)
#
# All globals use the EIR_ prefix.
# =============================================================================

[[ -n "${_ENVIRONMENT_ISSUE_RESOLVER_LOADED:-}" ]] && return 0
_ENVIRONMENT_ISSUE_RESOLVER_LOADED=1

EIR_VERSION="269.0"
EIR_INITIALIZED=false

# Counters
EIR_ENV_MISSING=0
EIR_ENV_EMPTY=0
EIR_NODE_ISSUES=0
EIR_DB_ISSUES=0
EIR_MISMATCHES=0
EIR_TOTAL_ISSUES=0

# Storage
EIR_CACHE_DIR=""

# Issue arrays
declare -g -a _EIR_MISSING_VARS=()
declare -g -a _EIR_EMPTY_VARS=()
declare -g -a _EIR_NODE_ISSUES=()
declare -g -a _EIR_DB_ISSUES=()
declare -g -a _EIR_MISMATCH_ISSUES=()
declare -g -A _EIR_REQUIRED_VARS=()

# Colors
_EIR_GREEN='\033[0;32m'
_EIR_YELLOW='\033[0;33m'
_EIR_RED='\033[0;31m'
_EIR_CYAN='\033[0;36m'
_EIR_BOLD='\033[1m'
_EIR_NC='\033[0m'

# =============================================================================
# _eir_init - Initialize environment issue resolver
# =============================================================================
_eir_init() {
    EIR_CACHE_DIR="${HOME}/.soloptilink/env-resolver"
    mkdir -p "$EIR_CACHE_DIR" 2>/dev/null || true

    EIR_ENV_MISSING=0
    EIR_ENV_EMPTY=0
    EIR_NODE_ISSUES=0
    EIR_DB_ISSUES=0
    EIR_MISMATCHES=0
    EIR_TOTAL_ISSUES=0

    _EIR_MISSING_VARS=()
    _EIR_EMPTY_VARS=()
    _EIR_NODE_ISSUES=()
    _EIR_DB_ISSUES=()
    _EIR_MISMATCH_ISSUES=()
    _EIR_REQUIRED_VARS=()

    EIR_INITIALIZED=true
    return 0
}

# =============================================================================
# _eir_extract_env_references - Extract env var references from source code
# =============================================================================
_eir_extract_env_references() {
    local project_dir="${1:-.}"

    _EIR_REQUIRED_VARS=()

    local source_files
    source_files=$(find "$project_dir" -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" 2>/dev/null | grep -vE 'node_modules|\.next|dist|\.env' | head -200)

    while IFS= read -r file; do
        [[ ! -f "$file" ]] && continue

        # Extract process.env.* references
        grep -oE 'process\.env\.([A-Z_][A-Z0-9_]*)' "$file" 2>/dev/null | while IFS= read -r ref; do
            local var_name
            var_name=$(echo "$ref" | sed 's/process\.env\.//')
            echo "${var_name}:${file}"
        done

        # Extract process.env["*"] references
        grep -oE 'process\.env\["([A-Z_][A-Z0-9_]*)"\]' "$file" 2>/dev/null | while IFS= read -r ref; do
            local var_name
            var_name=$(echo "$ref" | grep -oE '"[^"]*"' | tr -d '"')
            echo "${var_name}:${file}"
        done

        # Extract Vite import.meta.env.* references
        grep -oE 'import\.meta\.env\.([A-Z_][A-Z0-9_]*)' "$file" 2>/dev/null | while IFS= read -r ref; do
            local var_name
            var_name=$(echo "$ref" | sed 's/import\.meta\.env\.//')
            echo "${var_name}:${file}"
        done
    done | sort -u | while IFS=: read -r var_name file_ref; do
        [[ -z "$var_name" ]] && continue
        _EIR_REQUIRED_VARS["$var_name"]="${_EIR_REQUIRED_VARS[$var_name]:-} ${file_ref}"
    done
}

# =============================================================================
# _eir_check_env_vars - Check all required env vars are set
# =============================================================================
_eir_check_env_vars() {
    local project_dir="${1:-.}"

    echo -e "${_EIR_CYAN}[EIR]${_EIR_NC} 環境変数を検査中..." >&2
    _EIR_MISSING_VARS=()
    _EIR_EMPTY_VARS=()

    # Extract required vars from code
    _eir_extract_env_references "$project_dir"

    # Load .env file if present
    local env_file="${project_dir}/.env"
    local env_local="${project_dir}/.env.local"
    declare -A env_values=()

    for ef in "$env_file" "$env_local"; do
        if [[ -f "$ef" ]]; then
            while IFS= read -r line; do
                # Skip comments and empty lines
                [[ "$line" =~ ^#.*$ || -z "$line" ]] && continue
                local key="${line%%=*}"
                local value="${line#*=}"
                # Remove quotes
                value=$(echo "$value" | sed "s/^['\"]//;s/['\"]$//")
                env_values["$key"]="$value"
            done < "$ef"
        fi
    done

    # Check each required var
    for var_name in "${!_EIR_REQUIRED_VARS[@]}"; do
        # Skip Next.js internal vars
        if echo "$var_name" | grep -qE '^(NODE_ENV|NEXT_PUBLIC_|VERCEL|CI|PWD|HOME|PATH|SHELL)'; then
            continue
        fi

        if [[ -z "${env_values[$var_name]+x}" ]]; then
            _EIR_MISSING_VARS+=("$var_name")
            local refs="${_EIR_REQUIRED_VARS[$var_name]}"
            echo -e "${_EIR_RED}[EIR]${_EIR_NC}   未設定: ${var_name}" >&2
            EIR_ENV_MISSING=$((EIR_ENV_MISSING + 1))
        elif [[ -z "${env_values[$var_name]}" ]]; then
            _EIR_EMPTY_VARS+=("$var_name")
            echo -e "${_EIR_YELLOW}[EIR]${_EIR_NC}   空: ${var_name}" >&2
            EIR_ENV_EMPTY=$((EIR_ENV_EMPTY + 1))
        fi
    done

    # Check for sensitive vars in .env that should not be committed
    if [[ -f "$env_file" ]]; then
        local sensitive_patterns="SECRET|PASSWORD|KEY|TOKEN|PRIVATE|CREDENTIAL|API_KEY"
        local sensitive_vars
        sensitive_vars=$(grep -oE "^[A-Z_]*($sensitive_patterns)[A-Z_]*=" "$env_file" 2>/dev/null | head -10)
        if [[ -n "$sensitive_vars" ]]; then
            # Check if .env is in .gitignore
            local gitignore="${project_dir}/.gitignore"
            if [[ -f "$gitignore" ]]; then
                if ! grep -qE '\.env$|\.env\.local' "$gitignore" 2>/dev/null; then
                    echo -e "${_EIR_RED}[EIR]${_EIR_NC}   .env が .gitignore に未登録（機密情報漏洩リスク）" >&2
                    EIR_MISMATCHES=$((EIR_MISMATCHES + 1))
                fi
            fi
        fi
    fi

    echo -e "${_EIR_CYAN}[EIR]${_EIR_NC} 環境変数チェック完了: 未設定=${EIR_ENV_MISSING} 空=${EIR_ENV_EMPTY}" >&2
    return 0
}

# =============================================================================
# _eir_check_node_version - Check Node.js version compatibility
# =============================================================================
_eir_check_node_version() {
    local project_dir="${1:-.}"

    echo -e "${_EIR_CYAN}[EIR]${_EIR_NC} Node.js バージョン互換性を検査中..." >&2
    _EIR_NODE_ISSUES=()

    # Get current Node version
    local current_node
    current_node=$(node --version 2>/dev/null | tr -d 'v')
    if [[ -z "$current_node" ]]; then
        _EIR_NODE_ISSUES+=("NODE_NOT_FOUND:Node.js がインストールされていません")
        echo -e "${_EIR_RED}[EIR]${_EIR_NC}   Node.js がインストールされていません" >&2
        EIR_NODE_ISSUES=$((EIR_NODE_ISSUES + 1))
        return 1
    fi

    local current_major
    current_major=$(echo "$current_node" | cut -d. -f1)
    echo -e "${_EIR_CYAN}[EIR]${_EIR_NC}   現在のNode.js: v${current_node}" >&2

    # Check package.json engines field
    local pkg_json="${project_dir}/package.json"
    if [[ -f "$pkg_json" ]]; then
        local required_node
        required_node=$(grep -oE '"node"\s*:\s*"[^"]+"' "$pkg_json" 2>/dev/null | grep -oE '"[0-9>=<^~. ]+' | tr -d '"')

        if [[ -n "$required_node" ]]; then
            local required_major
            required_major=$(echo "$required_node" | grep -oE '[0-9]+' | head -1)
            echo -e "${_EIR_CYAN}[EIR]${_EIR_NC}   要求バージョン: ${required_node}" >&2

            if [[ "$current_major" -lt "$required_major" ]]; then
                _EIR_NODE_ISSUES+=("NODE_TOO_OLD:current=${current_node}:required=${required_node}")
                echo -e "${_EIR_RED}[EIR]${_EIR_NC}   Node.js バージョンが古い: v${current_node} < ${required_node}" >&2
                EIR_NODE_ISSUES=$((EIR_NODE_ISSUES + 1))
            fi
        fi
    fi

    # Check .nvmrc or .node-version
    for version_file in ".nvmrc" ".node-version" ".tool-versions"; do
        local vf="${project_dir}/${version_file}"
        if [[ -f "$vf" ]]; then
            local specified_version
            specified_version=$(grep -oE '[0-9]+(\.[0-9]+)*' "$vf" 2>/dev/null | head -1)
            if [[ -n "$specified_version" ]]; then
                local specified_major
                specified_major=$(echo "$specified_version" | cut -d. -f1)
                if [[ "$current_major" != "$specified_major" ]]; then
                    _EIR_NODE_ISSUES+=("VERSION_FILE_MISMATCH:${version_file}:specified=${specified_version}:current=${current_node}")
                    echo -e "${_EIR_YELLOW}[EIR]${_EIR_NC}   ${version_file} 指定バージョン不一致: v${specified_version} vs v${current_node}" >&2
                    EIR_NODE_ISSUES=$((EIR_NODE_ISSUES + 1))
                fi
            fi
        fi
    done

    # Check npm version
    local npm_version
    npm_version=$(npm --version 2>/dev/null)
    if [[ -n "$npm_version" ]]; then
        echo -e "${_EIR_CYAN}[EIR]${_EIR_NC}   npm: v${npm_version}" >&2
    fi

    # Check TypeScript version compatibility
    local tsc_version
    tsc_version=$(grep -oE '"typescript"\s*:\s*"[^"]+"' "$pkg_json" 2>/dev/null | grep -oE '[0-9]+\.[0-9]+' | head -1)
    if [[ -n "$tsc_version" ]]; then
        local tsc_major
        tsc_major=$(echo "$tsc_version" | cut -d. -f1)
        if [[ "$tsc_major" -lt 5 ]]; then
            echo -e "${_EIR_YELLOW}[EIR]${_EIR_NC}   TypeScript ${tsc_version}: v5+ への更新を推奨" >&2
        fi
    fi

    return 0
}

# =============================================================================
# _eir_check_db_connection - Check database connectivity
# =============================================================================
_eir_check_db_connection() {
    local project_dir="${1:-.}"

    echo -e "${_EIR_CYAN}[EIR]${_EIR_NC} データベース接続を検査中..." >&2
    _EIR_DB_ISSUES=()

    # Check for DATABASE_URL
    local db_url=""
    local env_file="${project_dir}/.env"
    if [[ -f "$env_file" ]]; then
        db_url=$(grep -oE 'DATABASE_URL="[^"]+"' "$env_file" 2>/dev/null | sed 's/DATABASE_URL="//;s/"$//')
        [[ -z "$db_url" ]] && db_url=$(grep -oE "DATABASE_URL='[^']+'" "$env_file" 2>/dev/null | sed "s/DATABASE_URL='//;s/'$//")
        [[ -z "$db_url" ]] && db_url=$(grep -oE 'DATABASE_URL=[^[:space:]]+' "$env_file" 2>/dev/null | sed 's/DATABASE_URL=//')
    fi

    if [[ -z "$db_url" ]]; then
        # Check if project uses a database
        local uses_db=false
        if find "$project_dir" -name "schema.prisma" -not -path "*/node_modules/*" 2>/dev/null | grep -q .; then
            uses_db=true
        fi
        if grep -rq 'prisma\|typeorm\|drizzle\|mongoose\|sequelize' "$project_dir/package.json" 2>/dev/null; then
            uses_db=true
        fi

        if [[ "$uses_db" == "true" ]]; then
            _EIR_DB_ISSUES+=("NO_DATABASE_URL:DATABASE_URL not set but project uses database")
            echo -e "${_EIR_RED}[EIR]${_EIR_NC}   DATABASE_URL が未設定（データベース使用プロジェクト）" >&2
            EIR_DB_ISSUES=$((EIR_DB_ISSUES + 1))
        fi
        return 0
    fi

    # Validate DATABASE_URL format
    local db_type
    db_type=$(echo "$db_url" | grep -oE '^[a-z]+' | head -1)
    echo -e "${_EIR_CYAN}[EIR]${_EIR_NC}   DB種別: ${db_type}" >&2

    case "$db_type" in
        postgresql|postgres)
            # Check for common PostgreSQL URL issues
            if ! echo "$db_url" | grep -qE 'postgresql://|postgres://'; then
                _EIR_DB_ISSUES+=("INVALID_URL:Invalid PostgreSQL URL format")
                echo -e "${_EIR_RED}[EIR]${_EIR_NC}   PostgreSQL URL フォーマットエラー" >&2
                EIR_DB_ISSUES=$((EIR_DB_ISSUES + 1))
            fi
            # Check for missing sslmode for production
            if [[ -n "${NODE_ENV:-}" && "$NODE_ENV" == "production" ]]; then
                if ! echo "$db_url" | grep -qE 'sslmode=|ssl='; then
                    echo -e "${_EIR_YELLOW}[EIR]${_EIR_NC}   本番環境でSSL未設定" >&2
                fi
            fi
            ;;
        mysql)
            if ! echo "$db_url" | grep -qE 'mysql://'; then
                _EIR_DB_ISSUES+=("INVALID_URL:Invalid MySQL URL format")
                EIR_DB_ISSUES=$((EIR_DB_ISSUES + 1))
            fi
            ;;
        sqlite|file)
            # Check if SQLite file path exists/is writable
            local db_path
            db_path=$(echo "$db_url" | sed 's|file:||;s|sqlite:||;s|?.*||')
            if [[ -n "$db_path" && "$db_path" != ":memory:" ]]; then
                local db_dir
                db_dir=$(dirname "$db_path")
                if [[ ! -d "$db_dir" ]]; then
                    _EIR_DB_ISSUES+=("DIR_NOT_EXISTS:SQLite directory does not exist: ${db_dir}")
                    echo -e "${_EIR_YELLOW}[EIR]${_EIR_NC}   SQLiteディレクトリが存在しません: ${db_dir}" >&2
                    EIR_DB_ISSUES=$((EIR_DB_ISSUES + 1))
                fi
            fi
            ;;
    esac

    # Try prisma db pull to test connection (non-destructive)
    local prisma_bin="${project_dir}/node_modules/.bin/prisma"
    if [[ -x "$prisma_bin" ]]; then
        local status_output
        status_output=$(cd "$project_dir" && "$prisma_bin" migrate status 2>&1) || true
        if echo "$status_output" | grep -qiE 'error|connect|ECONNREFUSED|ETIMEDOUT'; then
            _EIR_DB_ISSUES+=("CONNECTION_FAILED:${status_output:0:100}")
            echo -e "${_EIR_RED}[EIR]${_EIR_NC}   DB接続失敗" >&2
            EIR_DB_ISSUES=$((EIR_DB_ISSUES + 1))
        else
            echo -e "${_EIR_GREEN}[EIR]${_EIR_NC}   DB接続OK" >&2
        fi
    fi

    return 0
}

# =============================================================================
# _eir_fix_env_mismatch - Fix environment configuration mismatches
# =============================================================================
_eir_fix_env_mismatch() {
    local project_dir="${1:-.}"

    echo -e "${_EIR_CYAN}[EIR]${_EIR_NC} 環境設定不一致を検査中..." >&2
    _EIR_MISMATCH_ISSUES=()

    # Check .env vs .env.example consistency
    local env_file="${project_dir}/.env"
    local env_example="${project_dir}/.env.example"

    if [[ -f "$env_example" && -f "$env_file" ]]; then
        # Find vars in .env.example that are not in .env
        while IFS= read -r line; do
            [[ "$line" =~ ^#.*$ || -z "$line" ]] && continue
            local key="${line%%=*}"
            [[ -z "$key" ]] && continue

            if ! grep -qE "^${key}=" "$env_file" 2>/dev/null; then
                _EIR_MISMATCH_ISSUES+=("MISSING_FROM_ENV:${key}")
                echo -e "${_EIR_YELLOW}[EIR]${_EIR_NC}   .env に不足: ${key} (.env.example にあり)" >&2
                EIR_MISMATCHES=$((EIR_MISMATCHES + 1))
            fi
        done < "$env_example"

        # Find vars in .env that are not in .env.example
        while IFS= read -r line; do
            [[ "$line" =~ ^#.*$ || -z "$line" ]] && continue
            local key="${line%%=*}"
            [[ -z "$key" ]] && continue

            if ! grep -qE "^${key}=" "$env_example" 2>/dev/null; then
                _EIR_MISMATCH_ISSUES+=("MISSING_FROM_EXAMPLE:${key}")
                echo -e "${_EIR_YELLOW}[EIR]${_EIR_NC}   .env.example に不足: ${key}" >&2
                EIR_MISMATCHES=$((EIR_MISMATCHES + 1))
            fi
        done < "$env_file"
    fi

    # Check for environment-specific issues
    # Vercel
    if [[ -f "${project_dir}/vercel.json" ]]; then
        if [[ ! -f "${project_dir}/.env.production" && ! -f "${project_dir}/.env.local" ]]; then
            echo -e "${_EIR_YELLOW}[EIR]${_EIR_NC}   Vercelプロジェクトに.env.production未設定" >&2
        fi
    fi

    # Docker
    if [[ -f "${project_dir}/Dockerfile" || -f "${project_dir}/docker-compose.yml" ]]; then
        if [[ -f "${project_dir}/docker-compose.yml" ]]; then
            if ! grep -qE 'env_file|\.env' "${project_dir}/docker-compose.yml" 2>/dev/null; then
                echo -e "${_EIR_YELLOW}[EIR]${_EIR_NC}   docker-compose.yml にenv_file設定なし" >&2
            fi
        fi
    fi

    return 0
}

# =============================================================================
# _eir_generate_env_template - Generate .env.example from code analysis
# =============================================================================
_eir_generate_env_template() {
    local project_dir="${1:-.}"
    local output_file="${2:-${project_dir}/.env.example}"

    echo -e "${_EIR_CYAN}[EIR]${_EIR_NC} .env.example を生成中..." >&2

    # Extract all env references
    _eir_extract_env_references "$project_dir"

    # Group vars by category
    declare -A var_categories=()
    for var_name in "${!_EIR_REQUIRED_VARS[@]}"; do
        local category="general"

        if echo "$var_name" | grep -qiE 'DATABASE|DB_|PRISMA'; then
            category="database"
        elif echo "$var_name" | grep -qiE 'AUTH|JWT|SECRET|SESSION|TOKEN'; then
            category="auth"
        elif echo "$var_name" | grep -qiE 'NEXT_PUBLIC|VITE_'; then
            category="client"
        elif echo "$var_name" | grep -qiE 'API|URL|ENDPOINT|HOST|PORT'; then
            category="api"
        elif echo "$var_name" | grep -qiE 'MAIL|EMAIL|SMTP|SENDGRID'; then
            category="email"
        elif echo "$var_name" | grep -qiE 'AWS|S3|BUCKET|CLOUD|STORAGE'; then
            category="storage"
        elif echo "$var_name" | grep -qiE 'REDIS|CACHE|MEMCACHE'; then
            category="cache"
        elif echo "$var_name" | grep -qiE 'LOG|DEBUG|SENTRY|MONITORING'; then
            category="monitoring"
        fi

        var_categories["$var_name"]="$category"
    done

    # Generate template
    local template=""
    template+="# =============================================================================\n"
    template+="# Environment Variables - Auto-generated by SoloptiLinkAI v${EIR_VERSION}\n"
    template+="# Copy this file to .env and fill in the values\n"
    template+="# =============================================================================\n\n"

    # Output by category
    for category in "general" "api" "database" "auth" "client" "email" "storage" "cache" "monitoring"; do
        local has_vars=false
        for var_name in "${!var_categories[@]}"; do
            if [[ "${var_categories[$var_name]}" == "$category" ]]; then
                has_vars=true
                break
            fi
        done

        [[ "$has_vars" != "true" ]] && continue

        template+="# --- ${category^^} ---\n"
        for var_name in $(echo "${!var_categories[@]}" | tr ' ' '\n' | sort); do
            if [[ "${var_categories[$var_name]}" == "$category" ]]; then
                local default_val=""
                # Set intelligent defaults
                case "$var_name" in
                    NODE_ENV) default_val="development" ;;
                    PORT) default_val="3000" ;;
                    DATABASE_URL) default_val="postgresql://user:password@localhost:5432/dbname" ;;
                    NEXTAUTH_URL) default_val="http://localhost:3000" ;;
                    *SECRET*|*KEY*|*TOKEN*|*PASSWORD*) default_val="change-me-in-production" ;;
                    *) default_val="" ;;
                esac
                template+="${var_name}=${default_val}\n"
            fi
        done
        template+="\n"
    done

    echo -e "$template" > "$output_file"
    echo -e "${_EIR_GREEN}[EIR]${_EIR_NC} .env.example 生成完了: ${output_file}" >&2
    return 0
}

# =============================================================================
# _eir_report - Report output
# =============================================================================
_eir_report() {
    EIR_TOTAL_ISSUES=$((EIR_ENV_MISSING + EIR_ENV_EMPTY + EIR_NODE_ISSUES + EIR_DB_ISSUES + EIR_MISMATCHES))
    echo -e "\n  ${_EIR_BOLD}--- Environment Issue Resolver v${EIR_VERSION} ---${_EIR_NC}"
    echo -e "  環境変数不足     : ${EIR_ENV_MISSING}"
    echo -e "  環境変数空       : ${EIR_ENV_EMPTY}"
    echo -e "  Node.js問題      : ${EIR_NODE_ISSUES}"
    echo -e "  DB接続問題       : ${EIR_DB_ISSUES}"
    echo -e "  設定不一致       : ${EIR_MISMATCHES}"
    echo -e "  合計問題         : ${EIR_TOTAL_ISSUES}"
}

# =============================================================================
# _eir_score - Module score (0-100)
# =============================================================================
_eir_score() {
    EIR_TOTAL_ISSUES=$((EIR_ENV_MISSING + EIR_ENV_EMPTY + EIR_NODE_ISSUES + EIR_DB_ISSUES + EIR_MISMATCHES))
    if [[ $EIR_TOTAL_ISSUES -eq 0 ]]; then
        echo "100"
    else
        local penalty=$((EIR_TOTAL_ISSUES * 12))
        local score=$((100 - penalty))
        [[ $score -lt 10 ]] && score=10
        echo "$score"
    fi
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "environment-issue-resolver" \
    --version "269.0" \
    --description "環境変数/Node.jsバージョン/DB接続/設定不一致の検出・修正" \
    --init "_eir_init" \
    --report "_eir_report" \
    --score "_eir_score" \
    --enable-var "ENABLE_EIR" \
    --cli-flags "--environment-issue-resolver:--no-environment-issue-resolver"
