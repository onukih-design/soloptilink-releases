#!/usr/bin/env bash
# ╔═══════════════════════════════════════════════════════════════╗
# ║  SoloptiLink Chain v19.1 - Real Data Connector               ║
# ║  モックデータ排除 → 実DB接続 + 無料API連携 + 実運用設定       ║
# ╚═══════════════════════════════════════════════════════════════╝
#
# 目的: 生成されるコードが「モックデータ」や「TODO スタブ」ではなく、
#       実際のDB接続・外部API連携・データ永続化を完備した状態で出力されること。
#
# 3つの柱:
#   1. DB接続レイヤー (SQLite/PostgreSQL/MySQL - ORM付きCRUD自動生成)
#   2. 無料外部API連携 (ドメイン別に最適なAPIを自動選択)
#   3. 実運用設定 (.env生成、マイグレーション、シード、ヘルスチェック)

[[ -n "${_REAL_DATA_CONNECTOR_LOADED:-}" ]] && return 0
_REAL_DATA_CONNECTOR_LOADED=1

set -euo pipefail 2>/dev/null || true

# ============================================================
# 定数・グローバル
# ============================================================
RDC_VERSION="19.1"
RDC_INITIALIZED=false
RDC_LOG_PREFIX="[RealDataConnector]"
RDC_DB_ENGINE="${RDC_DB_ENGINE:-sqlite}"  # sqlite | postgres | mysql
RDC_ENABLE_FREE_API="${RDC_ENABLE_FREE_API:-true}"

# カラー (共通ロード前のフォールバック)
_rdc_RED='\033[0;31m'; _rdc_GREEN='\033[0;32m'; _rdc_YELLOW='\033[0;33m'
_rdc_CYAN='\033[0;36m'; _rdc_PURPLE='\033[0;35m'; _rdc_BOLD='\033[1m'
_rdc_NC='\033[0m'

_rdc_log() {
    local level="$1"; shift
    local color="$_rdc_NC"
    case "$level" in
        INFO)    color="$_rdc_CYAN" ;;
        SUCCESS) color="$_rdc_GREEN" ;;
        WARN)    color="$_rdc_YELLOW" ;;
        ERROR)   color="$_rdc_RED" ;;
    esac
    echo -e "${color}${RDC_LOG_PREFIX} [${level}] $*${_rdc_NC}" >&2
}

# ============================================================
# 初期化
# ============================================================
rdc_init() {
    [[ "$RDC_INITIALIZED" == "true" ]] && return 0
    _rdc_log INFO "Real Data Connector v${RDC_VERSION} 初期化中..."
    RDC_INITIALIZED=true
    return 0
}

# ============================================================
# ドメイン別 無料API マッピング
# ============================================================
# 全て無料・APIキー不要 or 無料枠が十分にあるものを厳選
# ============================================================
rdc_get_free_apis_for_domain() {
    local domain="${1:-general}"

    case "$domain" in
        crm|顧客管理|customer)
            cat <<'APIS'
{
  "domain": "CRM/顧客管理",
  "apis": [
    {
      "name": "JSONPlaceholder (プロトタイプ用・即利用可)",
      "url": "https://jsonplaceholder.typicode.com",
      "endpoints": ["/users", "/posts", "/comments"],
      "auth": "不要",
      "note": "開発初期の動作確認用。本番はDBに置換"
    }
  ],
  "recommended_db": "postgresql",
  "orm": "prisma",
  "real_data_strategy": "SQLiteで即起動 → PostgreSQLにマイグレーション可能な設計",
  "prompt_injection": "顧客データはDBに永続化すること。モックデータやハードコードされたJSONは使用禁止。Prisma ORMでCRUD操作を実装し、全エンドポイントがDB経由でデータを読み書きすること。"
}
APIS
            ;;
        ecommerce|EC|ショッピング|通販)
            cat <<'APIS'
{
  "domain": "ECサイト",
  "apis": [
    {
      "name": "Fake Store API (商品データ参考)",
      "url": "https://fakestoreapi.com",
      "endpoints": ["/products", "/carts", "/users"],
      "auth": "不要",
      "note": "商品カテゴリ・価格構造の参考データ。初期シードデータとして取り込み可"
    },
    {
      "name": "Exchange Rate API (通貨換算)",
      "url": "https://open.er-api.com/v6/latest/JPY",
      "endpoints": ["/v6/latest/{currency}"],
      "auth": "不要",
      "note": "多通貨対応時の為替レート取得"
    }
  ],
  "recommended_db": "postgresql",
  "orm": "prisma",
  "real_data_strategy": "商品・注文・ユーザーは全てDBに永続化。外部APIからシードデータをインポートして初期商品を登録",
  "prompt_injection": "商品・注文・カート・ユーザーデータは全てDBに保存すること。ハードコードされた商品リストは使用禁止。Prisma ORMで全CRUD操作を実装。決済はStripe Test Modeを使用。"
}
APIS
            ;;
        finance|家計簿|会計|finance|accounting)
            cat <<'APIS'
{
  "domain": "家計簿/会計",
  "apis": [
    {
      "name": "Exchange Rate API (為替)",
      "url": "https://open.er-api.com/v6/latest/JPY",
      "endpoints": ["/v6/latest/{currency}"],
      "auth": "不要",
      "note": "外貨取引がある場合の為替レート"
    }
  ],
  "recommended_db": "sqlite",
  "orm": "prisma",
  "real_data_strategy": "収支データは全てSQLiteに永続化。CSVインポート/エクスポート機能を実装してExcelとの相互運用を確保",
  "prompt_injection": "収入・支出・カテゴリデータは全てDBに保存すること。メモリ上やlocalStorageのみの保存は禁止。集計・グラフデータもDB集計関数で算出。CSVインポート/エクスポート機能を必ず実装。"
}
APIS
            ;;
        task|タスク|todo|project)
            cat <<'APIS'
{
  "domain": "タスク管理",
  "apis": [
    {
      "name": "World Time API (タイムゾーン)",
      "url": "http://worldtimeapi.org/api",
      "endpoints": ["/timezone", "/ip"],
      "auth": "不要",
      "note": "リモートチーム対応のタイムゾーン表示"
    }
  ],
  "recommended_db": "sqlite",
  "orm": "prisma",
  "real_data_strategy": "タスク・プロジェクト・ユーザーは全てDBに永続化。リアルタイム更新はWebSocket/SSE",
  "prompt_injection": "タスク・プロジェクト・担当者データは全てDBに保存すること。ダミーのタスクリストやハードコードされた配列は使用禁止。ドラッグ&ドロップの並び順もDBのsort_orderカラムで永続化。"
}
APIS
            ;;
        chat|チャット|messaging)
            cat <<'APIS'
{
  "domain": "チャット/メッセージング",
  "apis": [
    {
      "name": "Random User API (アバター生成)",
      "url": "https://randomuser.me/api",
      "endpoints": ["/?results=10&nat=jp"],
      "auth": "不要",
      "note": "テスト用ユーザーアバター/プロフィール画像"
    }
  ],
  "recommended_db": "postgresql",
  "orm": "prisma",
  "real_data_strategy": "メッセージは全てDBに永続化。WebSocketでリアルタイム配信。既読管理もDB管理",
  "prompt_injection": "メッセージ・チャネル・ユーザーは全てDBに保存すること。メモリ上の配列でのメッセージ管理は禁止。WebSocket/Socket.ioでリアルタイム通信を実装し、メッセージ永続化はDB経由。"
}
APIS
            ;;
        blog|ブログ|CMS|cms)
            cat <<'APIS'
{
  "domain": "ブログ/CMS",
  "apis": [
    {
      "name": "Unsplash Source (画像)",
      "url": "https://source.unsplash.com",
      "endpoints": ["/random/800x600"],
      "auth": "不要",
      "note": "記事のサムネイル/カバー画像"
    }
  ],
  "recommended_db": "sqlite",
  "orm": "prisma",
  "real_data_strategy": "記事・カテゴリ・タグ・コメントは全てDBに永続化。Markdownエディターで入力→HTMLレンダリング",
  "prompt_injection": "記事・カテゴリ・タグ・コメントは全てDBに保存すること。ハードコードされた記事配列は使用禁止。記事本文はMarkdownで保存し、表示時にHTMLに変換。画像はpublic/uploads/に保存。"
}
APIS
            ;;
        weather|天気|気象)
            cat <<'APIS'
{
  "domain": "天気/気象",
  "apis": [
    {
      "name": "Open-Meteo (天気予報)",
      "url": "https://api.open-meteo.com/v1/forecast",
      "endpoints": ["?latitude=35.68&longitude=139.77&hourly=temperature_2m,precipitation"],
      "auth": "不要・完全無料",
      "note": "商用利用可。日本の天気データ取得可能。レート制限なし"
    },
    {
      "name": "Open-Meteo Geocoding (地名→緯度経度)",
      "url": "https://geocoding-api.open-meteo.com/v1/search",
      "endpoints": ["?name=Tokyo&count=5&language=ja"],
      "auth": "不要",
      "note": "地名検索で緯度経度を取得"
    }
  ],
  "recommended_db": "sqlite",
  "orm": "prisma",
  "real_data_strategy": "天気データはOpen-Meteo APIからリアルタイム取得。お気に入り地点・通知設定はDBに永続化",
  "prompt_injection": "天気データはOpen-Meteo API (https://api.open-meteo.com) からリアルタイムで取得すること。ハードコードされた天気データは使用禁止。APIキー不要・完全無料。"
}
APIS
            ;;
        *)
            cat <<'APIS'
{
  "domain": "汎用",
  "apis": [
    {
      "name": "JSONPlaceholder (REST APIプロトタイプ)",
      "url": "https://jsonplaceholder.typicode.com",
      "endpoints": ["/users", "/posts", "/comments", "/todos"],
      "auth": "不要",
      "note": "開発初期のAPI動作確認用"
    }
  ],
  "recommended_db": "sqlite",
  "orm": "prisma",
  "real_data_strategy": "全ビジネスデータはDBに永続化。開発初期はSQLite、本番はPostgreSQLに移行可能な設計",
  "prompt_injection": "全てのデータはデータベースに永続化すること。ハードコードされたデータ配列、モックデータ、ダミーレスポンスは使用禁止。ORM経由でCRUD操作を実装。"
}
APIS
            ;;
    esac
}

# ============================================================
# DB接続テンプレート生成 (Node.js / Python)
# ============================================================

# Node.js: Prisma ORM セットアップ生成
rdc_generate_prisma_setup() {
    local project_dir="$1"
    local db_engine="${2:-sqlite}"

    local db_url_template=""
    local provider=""
    case "$db_engine" in
        sqlite)
            provider="sqlite"
            db_url_template='file:./dev.db'
            ;;
        postgres|postgresql)
            provider="postgresql"
            db_url_template='postgresql://user:password@localhost:5432/mydb?schema=public'
            ;;
        mysql)
            provider="mysql"
            db_url_template='mysql://user:password@localhost:3306/mydb'
            ;;
    esac

    cat <<PRISMA_SETUP
// ===== prisma/schema.prisma =====
// Real Data Connector v${RDC_VERSION} - 実DB接続設定
// SQLiteで即起動 → PostgreSQL/MySQLにurl変更だけで移行可能

datasource db {
  provider = "${provider}"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

// --- 以下にモデルを定義 ---
// chain.shが生成する設計書のDBスキーマに基づいて自動追加される

// ===== .env =====
DATABASE_URL="${db_url_template}"
NODE_ENV=development

// ===== セットアップコマンド =====
// npm install prisma @prisma/client
// npx prisma generate
// npx prisma db push  (開発時: スキーマをDBに即反映)
// npx prisma migrate dev --name init  (本番向け: マイグレーションファイル生成)
PRISMA_SETUP
}

# Node.js: 実DB接続 CRUD ルートテンプレート (Express)
rdc_generate_express_crud_with_db() {
    local entity_name="${1:-item}"
    cat <<'CRUD_TEMPLATE'
const express = require('express');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// Real Data Connector v19.1 - 実DB接続CRUDルート
// モックデータ・TODOスタブなし。全操作がDB経由。
function createCrudRouter(entityName) {
  const router = express.Router();

  // GET /api/{entity} - 一覧取得（検索・ソート・ページネーション）
  router.get('/', async (req, res) => {
    try {
      const { search, sort = 'createdAt', order = 'desc', page = 1, limit = 10 } = req.query;
      const skip = (Number(page) - 1) * Number(limit);
      const where = search ? {
        OR: [
          { name: { contains: search, mode: 'insensitive' } },
          { description: { contains: search, mode: 'insensitive' } }
        ].filter(Boolean)
      } : {};

      const [data, total] = await Promise.all([
        prisma[entityName].findMany({
          where,
          orderBy: { [sort]: order },
          skip,
          take: Number(limit),
        }),
        prisma[entityName].count({ where }),
      ]);

      res.json({ data, total, page: Number(page), limit: Number(limit), totalPages: Math.ceil(total / Number(limit)) });
    } catch (error) {
      console.error(`[${entityName}] List error:`, error);
      res.status(500).json({ message: `${entityName}の取得に失敗しました`, error: error.message });
    }
  });

  // GET /api/{entity}/:id - 詳細取得
  router.get('/:id', async (req, res) => {
    try {
      const item = await prisma[entityName].findUnique({ where: { id: req.params.id } });
      if (!item) return res.status(404).json({ message: `${entityName}が見つかりません` });
      res.json(item);
    } catch (error) {
      console.error(`[${entityName}] Get error:`, error);
      res.status(500).json({ message: `${entityName}の取得に失敗しました` });
    }
  });

  // POST /api/{entity} - 新規作成
  router.post('/', async (req, res) => {
    try {
      if (!req.body || Object.keys(req.body).length === 0) {
        return res.status(400).json({ message: '入力データが空です' });
      }
      const item = await prisma[entityName].create({ data: req.body });
      res.status(201).json(item);
    } catch (error) {
      console.error(`[${entityName}] Create error:`, error);
      res.status(500).json({ message: `${entityName}の作成に失敗しました`, error: error.message });
    }
  });

  // PUT /api/{entity}/:id - 更新
  router.put('/:id', async (req, res) => {
    try {
      const item = await prisma[entityName].update({
        where: { id: req.params.id },
        data: req.body,
      });
      res.json(item);
    } catch (error) {
      if (error.code === 'P2025') return res.status(404).json({ message: `${entityName}が見つかりません` });
      console.error(`[${entityName}] Update error:`, error);
      res.status(500).json({ message: `${entityName}の更新に失敗しました` });
    }
  });

  // DELETE /api/{entity}/:id - 削除
  router.delete('/:id', async (req, res) => {
    try {
      await prisma[entityName].delete({ where: { id: req.params.id } });
      res.json({ message: `${entityName}を削除しました`, id: req.params.id });
    } catch (error) {
      if (error.code === 'P2025') return res.status(404).json({ message: `${entityName}が見つかりません` });
      console.error(`[${entityName}] Delete error:`, error);
      res.status(500).json({ message: `${entityName}の削除に失敗しました` });
    }
  });

  return router;
}

module.exports = { createCrudRouter, prisma };
CRUD_TEMPLATE
}

# Python: SQLAlchemy 実DB接続CRUDテンプレート (Flask)
rdc_generate_flask_crud_with_db() {
    cat <<'PYCRUD'
"""
Real Data Connector v19.1 - Flask + SQLAlchemy 実DB接続CRUDルート
モックデータ・TODOスタブなし。全操作がDB経由。
"""
from flask import Blueprint, request, jsonify
from sqlalchemy import or_

def create_crud_blueprint(name, model, db_session):
    """汎用CRUD Blueprintファクトリ"""
    bp = Blueprint(name, __name__, url_prefix=f'/api/{name}')

    @bp.route('/', methods=['GET'])
    def list_items():
        search = request.args.get('search', '')
        page = int(request.args.get('page', 1))
        limit = int(request.args.get('limit', 10))
        sort = request.args.get('sort', 'created_at')
        order = request.args.get('order', 'desc')

        query = db_session.query(model)
        if search and hasattr(model, 'name'):
            query = query.filter(or_(
                model.name.ilike(f'%{search}%'),
                model.description.ilike(f'%{search}%') if hasattr(model, 'description') else False
            ))

        sort_col = getattr(model, sort, model.created_at if hasattr(model, 'created_at') else None)
        if sort_col is not None:
            query = query.order_by(sort_col.desc() if order == 'desc' else sort_col.asc())

        total = query.count()
        items = query.offset((page - 1) * limit).limit(limit).all()

        return jsonify({
            'data': [item.to_dict() for item in items],
            'total': total,
            'page': page,
            'limit': limit,
            'total_pages': (total + limit - 1) // limit
        })

    @bp.route('/', methods=['POST'])
    def create_item():
        data = request.get_json()
        if not data:
            return jsonify({'message': '入力データが空です'}), 400
        item = model(**data)
        db_session.add(item)
        db_session.commit()
        return jsonify(item.to_dict()), 201

    @bp.route('/<int:item_id>', methods=['GET'])
    def get_item(item_id):
        item = db_session.get(model, item_id)
        if not item:
            return jsonify({'message': f'{name}が見つかりません'}), 404
        return jsonify(item.to_dict())

    @bp.route('/<int:item_id>', methods=['PUT'])
    def update_item(item_id):
        item = db_session.get(model, item_id)
        if not item:
            return jsonify({'message': f'{name}が見つかりません'}), 404
        data = request.get_json()
        for key, value in data.items():
            if hasattr(item, key):
                setattr(item, key, value)
        db_session.commit()
        return jsonify(item.to_dict())

    @bp.route('/<int:item_id>', methods=['DELETE'])
    def delete_item(item_id):
        item = db_session.get(model, item_id)
        if not item:
            return jsonify({'message': f'{name}が見つかりません'}), 404
        db_session.delete(item)
        db_session.commit()
        return jsonify({'message': f'{name}を削除しました', 'id': item_id})

    return bp
PYCRUD
}

# Python: SQLAlchemy DB設定テンプレート
rdc_generate_python_db_setup() {
    local db_engine="${1:-sqlite}"
    local db_url=""
    case "$db_engine" in
        sqlite)    db_url="sqlite:///instance/app.db" ;;
        postgres)  db_url="postgresql://user:password@localhost:5432/mydb" ;;
        mysql)     db_url="mysql+pymysql://user:password@localhost:3306/mydb" ;;
    esac

    cat <<PYDB
"""
Real Data Connector v${RDC_VERSION} - SQLAlchemy DB設定
"""
import os
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, DeclarativeBase

DATABASE_URL = os.environ.get('DATABASE_URL', '${db_url}')
engine = create_engine(DATABASE_URL, echo=os.environ.get('SQL_DEBUG', '') == 'true')
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

class Base(DeclarativeBase):
    pass

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

def init_db():
    """テーブル作成（開発時用）"""
    Base.metadata.create_all(bind=engine)
PYDB
}

# ============================================================
# 実データ要件プロンプト注入テキスト生成
# ============================================================
# prompt-expander.sh の _pe_get_interactivity_requirements() に
# 追加注入されるテキスト
rdc_get_real_data_requirements() {
    local domain="${1:-general}"
    local api_info
    api_info=$(rdc_get_free_apis_for_domain "$domain" 2>/dev/null || echo '{}')

    local prompt_injection=""
    prompt_injection=$(echo "$api_info" | grep -o '"prompt_injection": "[^"]*"' 2>/dev/null | head -1 | sed 's/"prompt_injection": "//;s/"$//' || echo "")

    cat <<REALDATA

## 実データ接続要件（CRITICAL - モックデータ使用禁止）

### 絶対禁止事項
- ❌ ハードコードされたJSON配列やオブジェクトをデータソースとして使用
- ❌ \`// TODO: DB接続に置き換え\` のようなスタブコメントを残す
- ❌ \`res.json({ data: [], total: 0 })\` のような空レスポンスを返す
- ❌ \`Date.now()\` をIDとして使用（DBの自動採番を使う）
- ❌ localStorage/sessionStorage/メモリ上のみでデータを管理
- ❌ サンプルデータやダミーテキスト（"John Doe", "test@example.com"等）をソースコードに埋め込む

### 必須実装事項
- ✅ **ORM（Prisma/SQLAlchemy）を使用してDB接続**: 全CRUDはDB経由
- ✅ **マイグレーション**: \`prisma migrate dev\` or \`alembic upgrade head\` で即DB構築
- ✅ **環境変数**: DATABASE_URL等は.envファイルで管理（ハードコード禁止）
- ✅ **シードスクリプト**: 初期データ投入用の \`prisma/seed.ts\` or \`seed.py\` を作成
- ✅ **エラーハンドリング**: DB接続エラー、NOT FOUND、バリデーションエラーを適切に処理
- ✅ **型安全**: Prismaの生成型 or Pydanticスキーマで入出力を型付け

### DB設定
- 開発環境: SQLite（\`file:./dev.db\`）で即起動・ゼロ設定
- 本番環境: DATABASE_URLを変更するだけでPostgreSQL/MySQLに移行可能
- 設定は\`.env\`ファイルのみで切り替え（コード変更不要）

### 外部API連携
- 外部データが必要な機能は、実際の無料APIに接続すること
- APIキーが必要な場合は.envで管理し、ハードコード禁止
${prompt_injection:+- ドメイン固有: ${prompt_injection}}

### シードデータ（初期データ投入）
- \`prisma/seed.ts\` (Node.js) または \`seed.py\` (Python) を作成
- 現実的なサンプルデータを10〜20件程度投入するスクリプト
- \`npx prisma db seed\` or \`python seed.py\` で実行可能
- シードデータは「テスト用」ではなく「デモ用」として現実的な内容にする
REALDATA
}

# ============================================================
# scaffolder用: 実DB接続セットアップを生成してプロジェクトに書き込む
# ============================================================
rdc_setup_db_for_project() {
    local project_dir="$1"
    local framework="${2:-nextjs}"  # nextjs | react-express | python-flask | python-fastapi
    local db_engine="${3:-sqlite}"

    _rdc_log INFO "実DB接続セットアップ: ${framework} + ${db_engine}"

    case "$framework" in
        nextjs|react-express)
            # Prisma セットアップ
            mkdir -p "${project_dir}/prisma" 2>/dev/null

            if [[ ! -f "${project_dir}/prisma/schema.prisma" ]]; then
                local provider="sqlite"
                local db_url='file:./dev.db'
                case "$db_engine" in
                    postgres|postgresql) provider="postgresql"; db_url='postgresql://user:password@localhost:5432/mydb?schema=public' ;;
                    mysql) provider="mysql"; db_url='mysql://user:password@localhost:3306/mydb' ;;
                esac

                cat > "${project_dir}/prisma/schema.prisma" <<SCHEMA
datasource db {
  provider = "${provider}"
  url      = env("DATABASE_URL")
}

generator client {
  provider = "prisma-client-js"
}

// SoloptiLink Real Data Connector v${RDC_VERSION}
// 設計書のDBスキーマに基づいてモデルが自動追加されます
SCHEMA
                _rdc_log SUCCESS "prisma/schema.prisma 生成完了"
            fi

            # .env (存在しなければ)
            if [[ ! -f "${project_dir}/.env" ]]; then
                local db_url='file:./dev.db'
                case "$db_engine" in
                    postgres|postgresql) db_url='postgresql://user:password@localhost:5432/mydb?schema=public' ;;
                    mysql) db_url='mysql://user:password@localhost:3306/mydb' ;;
                esac
                cat > "${project_dir}/.env" <<ENV
DATABASE_URL="${db_url}"
NODE_ENV=development
PORT=3001
ENV
                _rdc_log SUCCESS ".env 生成完了"
            fi

            # lib/prisma.ts (Prismaクライアントシングルトン)
            local prisma_dir="${project_dir}/src/lib"
            [[ "$framework" == "react-express" ]] && prisma_dir="${project_dir}/backend/lib"
            mkdir -p "$prisma_dir" 2>/dev/null

            if [[ ! -f "${prisma_dir}/prisma.ts" && ! -f "${prisma_dir}/prisma.js" ]]; then
                cat > "${prisma_dir}/prisma.ts" <<'PRISMA_CLIENT'
import { PrismaClient } from '@prisma/client'

const globalForPrisma = globalThis as unknown as { prisma: PrismaClient }

export const prisma = globalForPrisma.prisma || new PrismaClient({
  log: process.env.NODE_ENV === 'development' ? ['query', 'error', 'warn'] : ['error'],
})

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma
PRISMA_CLIENT
                _rdc_log SUCCESS "Prisma クライアント生成完了"
            fi
            ;;

        python-flask|python-fastapi)
            mkdir -p "${project_dir}/instance" 2>/dev/null

            if [[ ! -f "${project_dir}/database.py" ]]; then
                rdc_generate_python_db_setup "$db_engine" > "${project_dir}/database.py"
                _rdc_log SUCCESS "database.py 生成完了"
            fi

            if [[ ! -f "${project_dir}/.env" ]]; then
                local db_url="sqlite:///instance/app.db"
                case "$db_engine" in
                    postgres) db_url="postgresql://user:password@localhost:5432/mydb" ;;
                    mysql) db_url="mysql+pymysql://user:password@localhost:3306/mydb" ;;
                esac
                cat > "${project_dir}/.env" <<ENV
DATABASE_URL="${db_url}"
FLASK_ENV=development
PORT=5000
SECRET_KEY=$(python3 -c "import secrets; print(secrets.token_hex(32))" 2>/dev/null || echo "change-me-in-production")
ENV
                _rdc_log SUCCESS ".env 生成完了"
            fi
            ;;
    esac

    return 0
}

# ============================================================
# ドメイン判定ヘルパー
# ============================================================
rdc_detect_domain() {
    local task_desc="$1"
    case "$task_desc" in
        *CRM*|*crm*|*顧客*|*customer*) echo "crm" ;;
        *EC*|*ショッピング*|*通販*|*ecommerce*|*shop*|*商品*) echo "ecommerce" ;;
        *家計簿*|*会計*|*finance*|*accounting*|*経理*|*収支*) echo "finance" ;;
        *タスク*|*todo*|*TODO*|*プロジェクト管理*) echo "task" ;;
        *チャット*|*chat*|*メッセージ*|*messaging*) echo "chat" ;;
        *ブログ*|*blog*|*CMS*|*cms*|*記事*) echo "blog" ;;
        *天気*|*weather*|*気象*) echo "weather" ;;
        *) echo "general" ;;
    esac
}

# ============================================================
# メインエントリ: chain.sh から呼ばれる統合関数
# ============================================================
rdc_apply_real_data_config() {
    local project_dir="$1"
    local task_desc="$2"
    local framework="${3:-nextjs}"

    rdc_init

    local domain
    domain=$(rdc_detect_domain "$task_desc")
    _rdc_log INFO "ドメイン判定: ${domain}"

    # 1. 無料API情報取得
    local api_info
    api_info=$(rdc_get_free_apis_for_domain "$domain")
    _rdc_log INFO "無料API情報取得完了"

    # 2. DB推奨エンジン判定
    local recommended_db
    recommended_db=$(echo "$api_info" | grep -o '"recommended_db": "[^"]*"' | head -1 | sed 's/"recommended_db": "//;s/"$//' || echo "sqlite")
    RDC_DB_ENGINE="${recommended_db:-sqlite}"
    _rdc_log INFO "推奨DB: ${RDC_DB_ENGINE}"

    # 3. プロジェクトにDB接続セットアップ書き込み
    rdc_setup_db_for_project "$project_dir" "$framework" "$RDC_DB_ENGINE"

    # 4. API情報をセッションに保存（後続フェーズで参照）
    if [[ -n "${SESSION_LOG_DIR:-}" ]]; then
        mkdir -p "${SESSION_LOG_DIR}" 2>/dev/null || true
        echo "$api_info" > "${SESSION_LOG_DIR}/real_data_api_info.json" 2>/dev/null || true
        rdc_get_real_data_requirements "$domain" > "${SESSION_LOG_DIR}/real_data_requirements.md" 2>/dev/null || true
    fi

    _rdc_log SUCCESS "Real Data Connector 設定完了 (domain=${domain}, db=${RDC_DB_ENGINE})"
    return 0
}

_rdc_log INFO "Real Data Connector v${RDC_VERSION} ロード完了"
