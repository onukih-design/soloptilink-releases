#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v62.0 - Stream Processing
#
# Claude CLI の --output-format stream-json を活用し、
# 生成プロセスをリアルタイムで監視・制御する。
#
# 従来: Claude実行 → 完了まで待機 → 結果取得（ブラックボックス）
# v62.0: Claude実行 → ストリームでリアルタイム監視 → 早期エラー検出 → 即座に中断/修正
#
# Stream JSON イベント:
#   {"type":"assistant","subtype":"text","text":"..."}
#   {"type":"result","subtype":"success","result":"...",
#    "session_id":"...","cost_usd":0.05,"duration_ms":3000}
#
# メリット:
# - 生成中のリアルタイム進捗表示
# - コスト即時追跡（budget超過前に中断可能）
# - session_id取得（--resumeでの再開に使用）
# - エラーパターン早期検出
# ============================================================

[[ -n "${_STREAM_PROCESSOR_LOADED:-}" ]] && return 0
_STREAM_PROCESSOR_LOADED=1

# --- Configuration ---
SP_ENABLE="${SP_ENABLE:-true}"
SP_SHOW_PROGRESS="${SP_SHOW_PROGRESS:-true}"
SP_COST_ALERT_THRESHOLD="${SP_COST_ALERT_THRESHOLD:-5.00}"
SP_ERROR_PATTERN_DETECT="${SP_ERROR_PATTERN_DETECT:-true}"
SP_CAPTURE_SESSION_ID="${SP_CAPTURE_SESSION_ID:-true}"

# --- State ---
SP_CALL_COUNT=0
SP_TOTAL_COST=0
SP_TOTAL_DURATION_MS=0
SP_SESSIONS_CAPTURED=0
SP_ERRORS_DETECTED=0
SP_LAST_SESSION_ID=""

declare -a SP_SESSION_IDS=()

# ============================================================
# 初期化
# ============================================================
sp_init() {
    SP_CALL_COUNT=0
    SP_TOTAL_COST=0
    SP_TOTAL_DURATION_MS=0
    SP_SESSIONS_CAPTURED=0
    SP_ERRORS_DETECTED=0
    SP_LAST_SESSION_ID=""
    SP_SESSION_IDS=()
    return 0
}

# ============================================================
# ストリーム付きClaude実行
# リアルタイムで出力を処理しながら実行
# ============================================================
sp_call_streaming() {
    local prompt="$1"
    local output_file="${2:-}"
    local phase="${3:-implementation}"

    SP_CALL_COUNT=$((SP_CALL_COUNT + 1))

    # コマンド構築
    local -a cmd_args=()
    cmd_args+=("claude" "-p" "--dangerously-skip-permissions")
    cmd_args+=("--output-format" "stream-json")  # ← 核心

    # System Prompt（Claude Bridge連携）
    if type -t cb2_build_system_prompt &>/dev/null; then
        local sys_prompt
        sys_prompt=$(cb2_build_system_prompt "$phase" 2>/dev/null || true)
        if [[ -n "$sys_prompt" ]]; then
            cmd_args+=("--system-prompt" "$sys_prompt")
        fi
    fi

    cmd_args+=("--fallback-model" "claude-sonnet-4-20250514")
    cmd_args+=("--max-budget-usd" "${SP_BUDGET:-3.00}")
    cmd_args+=("$prompt")

    # 一時ファイルでストリーム処理
    local tmp_stream
    tmp_stream=$(mktemp)
    local tmp_result
    tmp_result=$(mktemp)
    local tmp_text
    tmp_text=$(mktemp)

    # ストリーム実行
    timeout 300 "${cmd_args[@]}" > "$tmp_stream" 2>/dev/null || true

    # ストリームJSONパース
    local session_id="" cost="" duration="" full_text="" error_count=0

    while IFS= read -r line; do
        [[ -z "$line" ]] && continue

        # Python でJSONパース（jqが無い環境対策）
        local parsed
        parsed=$(python3 -c "
import json, sys
try:
    d = json.loads(sys.argv[1])
    t = d.get('type','')
    st = d.get('subtype','')

    if t == 'assistant' and st == 'text':
        print('TEXT:' + d.get('text',''))
    elif t == 'result':
        sid = d.get('session_id','')
        cost = d.get('cost_usd', 0)
        dur = d.get('duration_ms', 0)
        res = d.get('result','')
        print(f'RESULT:session_id={sid},cost={cost},duration={dur}')
        print('RESULT_TEXT:' + res)
    elif t == 'error':
        print('ERROR:' + d.get('error', {}).get('message', 'unknown'))
except:
    print('RAW:' + sys.argv[1])
" "$line" 2>/dev/null || echo "RAW:$line")

        while IFS= read -r parsed_line; do
            case "$parsed_line" in
                TEXT:*)
                    local text="${parsed_line#TEXT:}"
                    echo -n "$text" >> "$tmp_text"
                    # 進捗表示
                    if [[ "${SP_SHOW_PROGRESS}" == "true" ]]; then
                        local char_count
                        char_count=$(wc -c < "$tmp_text" | tr -d ' ')
                        printf "\r  📝 生成中... %d chars" "$char_count" >&2
                    fi
                    ;;
                RESULT:*)
                    local result_meta="${parsed_line#RESULT:}"
                    session_id=$(echo "$result_meta" | grep -o 'session_id=[^,]*' | cut -d= -f2)
                    cost=$(echo "$result_meta" | grep -o 'cost=[^,]*' | cut -d= -f2)
                    duration=$(echo "$result_meta" | grep -o 'duration=[^,]*' | cut -d= -f2)
                    ;;
                RESULT_TEXT:*)
                    full_text="${parsed_line#RESULT_TEXT:}"
                    echo "$full_text" >> "$tmp_text"
                    ;;
                ERROR:*)
                    error_count=$((error_count + 1))
                    SP_ERRORS_DETECTED=$((SP_ERRORS_DETECTED + 1))
                    echo -e "\n  ${RED:-}⚠️ Stream Error: ${parsed_line#ERROR:}${NC:-}" >&2
                    ;;
                RAW:*)
                    # 非JSONの場合はそのまま記録
                    echo "${parsed_line#RAW:}" >> "$tmp_text"
                    ;;
            esac
        done <<< "$parsed"

    done < "$tmp_stream"

    # 進捗表示クリア
    if [[ "${SP_SHOW_PROGRESS}" == "true" ]]; then
        printf "\r                                     \r" >&2
    fi

    # セッションID保存
    if [[ -n "$session_id" ]]; then
        SP_LAST_SESSION_ID="$session_id"
        SP_SESSION_IDS+=("$session_id")
        SP_SESSIONS_CAPTURED=$((SP_SESSIONS_CAPTURED + 1))
    fi

    # コスト追跡
    if [[ -n "$cost" ]]; then
        SP_TOTAL_COST=$(python3 -c "print(round(${SP_TOTAL_COST} + ${cost}, 4))" 2>/dev/null || echo "$SP_TOTAL_COST")

        # コストアラート
        local over_threshold
        over_threshold=$(python3 -c "print('yes' if ${SP_TOTAL_COST} > ${SP_COST_ALERT_THRESHOLD} else 'no')" 2>/dev/null || echo "no")
        if [[ "$over_threshold" == "yes" ]]; then
            echo -e "  ${RED:-}💰 コストアラート: 累計 \$${SP_TOTAL_COST} > 閾値 \$${SP_COST_ALERT_THRESHOLD}${NC:-}" >&2
        fi
    fi

    # 時間追跡
    if [[ -n "$duration" ]]; then
        SP_TOTAL_DURATION_MS=$((SP_TOTAL_DURATION_MS + ${duration%.*}))
    fi

    # 結果出力
    local final_text
    final_text=$(cat "$tmp_text")

    if [[ -n "$output_file" ]]; then
        echo "$final_text" > "$output_file"
    fi

    # クリーンアップ
    rm -f "$tmp_stream" "$tmp_result" "$tmp_text"

    echo "$final_text"
    return 0
}

# ============================================================
# 最後のセッションIDを返す（--resume用）
# ============================================================
sp_get_last_session_id() {
    echo "${SP_LAST_SESSION_ID}"
}

# ============================================================
# コスト集計
# ============================================================
sp_get_total_cost() {
    echo "${SP_TOTAL_COST}"
}

# ============================================================
# レポート / スコア
# ============================================================
sp_report() {
    echo -e "\n  ${BOLD:-}═══ Stream Processing v62.0 レポート ═══${NC:-}"
    echo -e "  ストリーム呼出数   : ${SP_CALL_COUNT}"
    echo -e "  累計コスト         : \$${SP_TOTAL_COST}"
    echo -e "  累計所要時間       : $((SP_TOTAL_DURATION_MS / 1000))秒"
    echo -e "  セッションID取得数 : ${SP_SESSIONS_CAPTURED}"
    echo -e "  エラー検出数       : ${SP_ERRORS_DETECTED}"
}

sp_score() {
    if [[ $SP_CALL_COUNT -eq 0 ]]; then
        echo "50"
    elif [[ $SP_ERRORS_DETECTED -eq 0 && $SP_SESSIONS_CAPTURED -gt 0 ]]; then
        echo "95"
    elif [[ $SP_ERRORS_DETECTED -eq 0 ]]; then
        echo "85"
    else
        echo "70"
    fi
}

# ============================================================
# v59.0: Module Registry 自己登録
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "stream-processor" \
        --version "62.0" \
        --description "stream-jsonリアルタイム監視×コスト追跡×session_id取得" \
        --init "sp_init" \
        --report "sp_report" \
        --score "sp_score" \
        --enable-var "ENABLE_STREAM_PROCESSOR" \
        --cli-flags "--stream-process:--no-stream-process"
fi

# v2003.1: source時のexit codeを確実に0にする
true
