#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v417.0 - Smart Git Workflow
# =============================================================================
# AIによるブランチ提案・コミットメッセージ生成・PR管理を自動化。
# Conventional Commits準拠・変更内容分析・PRテンプレート生成を統合。
#
# Functions:
#   _sgw_init               - 初期化
#   _sgw_suggest_branch     - ブランチ名提案
#   _sgw_generate_commit_msg - コミットメッセージ生成
#   _sgw_manage_pr          - PR作成・テンプレート生成
#   _sgw_report             - レポート出力
#   _sgw_score              - モジュールスコア(0-100)
#
# All globals use the SGW_ prefix.
# =============================================================================

[[ -n "${_SMART_GIT_WORKFLOW_LOADED:-}" ]] && return 0
_SMART_GIT_WORKFLOW_LOADED=1

declare -g SGW_VERSION="417.0"
declare -g SGW_INITIALIZED=false
declare -g SGW_STORE_DIR=""
declare -g SGW_BRANCH_SUGGESTIONS=0
declare -g SGW_COMMIT_GENERATED=0
declare -g SGW_PR_GENERATED=0

declare -g -A _SGW_COMMIT_TYPES=()     # type → description
declare -g -A _SGW_SCOPE_MAP=()        # path_prefix → scope
declare -g -a _SGW_COMMIT_HISTORY=()

# =============================================================================
_sgw_init() {
    local project_dir="${PROJECT_DIR:-.}"
    SGW_STORE_DIR="${project_dir}/.soloptilink/smart-git"
    mkdir -p "${SGW_STORE_DIR}/templates" "${SGW_STORE_DIR}/history"

    # Conventional Commit types
    _SGW_COMMIT_TYPES["feat"]="A new feature"
    _SGW_COMMIT_TYPES["fix"]="A bug fix"
    _SGW_COMMIT_TYPES["docs"]="Documentation changes"
    _SGW_COMMIT_TYPES["style"]="Code style changes (formatting, semicolons)"
    _SGW_COMMIT_TYPES["refactor"]="Code refactoring"
    _SGW_COMMIT_TYPES["perf"]="Performance improvement"
    _SGW_COMMIT_TYPES["test"]="Adding or fixing tests"
    _SGW_COMMIT_TYPES["build"]="Build system changes"
    _SGW_COMMIT_TYPES["ci"]="CI configuration changes"
    _SGW_COMMIT_TYPES["chore"]="Other changes (deps, scripts)"
    _SGW_COMMIT_TYPES["revert"]="Revert a previous commit"

    # Scope mapping from file paths
    _SGW_SCOPE_MAP["app/api"]="api"
    _SGW_SCOPE_MAP["app/"]="ui"
    _SGW_SCOPE_MAP["components/"]="ui"
    _SGW_SCOPE_MAP["lib/"]="core"
    _SGW_SCOPE_MAP["prisma/"]="db"
    _SGW_SCOPE_MAP["tests/"]="test"
    _SGW_SCOPE_MAP["docs/"]="docs"
    _SGW_SCOPE_MAP[".github/"]="ci"
    _SGW_SCOPE_MAP["public/"]="assets"
    _SGW_SCOPE_MAP["middleware"]="middleware"

    SGW_INITIALIZED=true
    return 0
}

# =============================================================================
# _sgw_suggest_branch - Suggest branch name based on work description
# =============================================================================
_sgw_suggest_branch() {
    local description="$1"
    local branch_type="${2:-auto}"  # auto|feature|fix|chore|release

    [[ "$SGW_INITIALIZED" != "true" ]] && { echo "ERROR: SGW not initialized" >&2; return 1; }
    SGW_BRANCH_SUGGESTIONS=$((SGW_BRANCH_SUGGESTIONS + 1))

    local lower
    lower=$(echo "$description" | tr '[:upper:]' '[:lower:]')

    # Auto-detect branch type
    if [[ "$branch_type" == "auto" ]]; then
        if echo "$lower" | grep -qi 'fix\|bug\|error\|crash\|broken'; then
            branch_type="fix"
        elif echo "$lower" | grep -qi 'release\|version\|deploy'; then
            branch_type="release"
        elif echo "$lower" | grep -qi 'chore\|update\|upgrade\|dep\|refactor'; then
            branch_type="chore"
        elif echo "$lower" | grep -qi 'hotfix\|urgent\|critical'; then
            branch_type="hotfix"
        else
            branch_type="feature"
        fi
    fi

    # Generate slug from description
    local slug
    slug=$(echo "$lower" | \
        sed 's/[^a-z0-9 ]//g' | \
        tr ' ' '-' | \
        sed 's/--*/-/g' | \
        sed 's/^-//;s/-$//' | \
        cut -c1-40)

    # Generate branch name
    local branch_name="${branch_type}/${slug}"

    # Add ticket number if detected
    local ticket
    ticket=$(echo "$description" | grep -oE '[A-Z]+-[0-9]+' | head -1)
    [[ -n "$ticket" ]] && branch_name="${branch_type}/${ticket}-${slug}"

    echo "$branch_name"
    return 0
}

# =============================================================================
# _sgw_generate_commit_msg - Generate conventional commit message
# =============================================================================
_sgw_generate_commit_msg() {
    local project_dir="${1:-${PROJECT_DIR:-.}}"
    local custom_description="${2:-}"

    [[ "$SGW_INITIALIZED" != "true" ]] && { echo "ERROR: SGW not initialized" >&2; return 1; }
    SGW_COMMIT_GENERATED=$((SGW_COMMIT_GENERATED + 1))

    # Analyze staged changes
    local changed_files=""
    local additions=0
    local deletions=0

    if [[ -d "${project_dir}/.git" ]]; then
        changed_files=$(cd "$project_dir" && git diff --cached --name-only 2>/dev/null)
        if [[ -z "$changed_files" ]]; then
            changed_files=$(cd "$project_dir" && git diff --name-only 2>/dev/null)
        fi

        local stats
        stats=$(cd "$project_dir" && git diff --cached --shortstat 2>/dev/null)
        if [[ -z "$stats" ]]; then
            stats=$(cd "$project_dir" && git diff --shortstat 2>/dev/null)
        fi
        additions=$(echo "$stats" | grep -oE '[0-9]+ insertion' | grep -oE '[0-9]+' || echo "0")
        deletions=$(echo "$stats" | grep -oE '[0-9]+ deletion' | grep -oE '[0-9]+' || echo "0")
    fi

    # Determine commit type from changes
    local commit_type="chore"
    local scope=""

    if [[ -n "$changed_files" ]]; then
        # Detect scope from most common path prefix
        for prefix in "${!_SGW_SCOPE_MAP[@]}"; do
            if echo "$changed_files" | grep -q "$prefix"; then
                scope="${_SGW_SCOPE_MAP[$prefix]}"
                break
            fi
        done

        # Detect type from file patterns
        if echo "$changed_files" | grep -q '\.test\.\|\.spec\.'; then
            commit_type="test"
        elif echo "$changed_files" | grep -q 'README\|docs/\|\.md'; then
            commit_type="docs"
        elif echo "$changed_files" | grep -q '\.css\|\.scss\|tailwind'; then
            commit_type="style"
        elif echo "$changed_files" | grep -q 'prisma/\|migration'; then
            commit_type="feat"
            scope="db"
        elif echo "$changed_files" | grep -q 'package.json\|package-lock\|yarn.lock'; then
            commit_type="chore"
            scope="deps"
        elif echo "$changed_files" | grep -q '\.github/\|Dockerfile\|docker-compose'; then
            commit_type="ci"
        elif [[ $deletions -gt $additions && $additions -gt 0 ]]; then
            commit_type="refactor"
        elif [[ $additions -gt 0 ]]; then
            commit_type="feat"
        fi
    fi

    # Use custom description or generate one
    local description="${custom_description:-}"
    if [[ -z "$description" ]]; then
        local file_count
        file_count=$(echo "$changed_files" | grep -c '.' || echo "0")
        case "$commit_type" in
            feat) description="add new functionality" ;;
            fix) description="resolve issue" ;;
            docs) description="update documentation" ;;
            test) description="update tests" ;;
            refactor) description="improve code structure" ;;
            style) description="update styling" ;;
            chore) description="update project configuration" ;;
            ci) description="update CI/CD configuration" ;;
            *) description="update ${file_count} files" ;;
        esac
    fi

    # Build commit message
    local msg="${commit_type}"
    [[ -n "$scope" ]] && msg="${msg}(${scope})"
    msg="${msg}: ${description}"

    # Add body with changed files summary
    local body=""
    if [[ -n "$changed_files" ]]; then
        local file_count
        file_count=$(echo "$changed_files" | grep -c '.' || echo "0")
        body="\n\nChanged ${file_count} file(s): +${additions}/-${deletions}"
    fi

    echo -e "${msg}${body}"
    _SGW_COMMIT_HISTORY+=("$msg")
    return 0
}

# =============================================================================
# _sgw_manage_pr - Generate PR template
# =============================================================================
_sgw_manage_pr() {
    local action="${1:-create}"  # create|template|checklist
    local project_dir="${2:-${PROJECT_DIR:-.}}"

    [[ "$SGW_INITIALIZED" != "true" ]] && { echo "ERROR: SGW not initialized" >&2; return 1; }
    SGW_PR_GENERATED=$((SGW_PR_GENERATED + 1))

    case "$action" in
        create|template)
            # Analyze branch diff
            local branch_name=""
            local commit_count=0
            local files_changed=0

            if [[ -d "${project_dir}/.git" ]]; then
                branch_name=$(cd "$project_dir" && git rev-parse --abbrev-ref HEAD 2>/dev/null)
                commit_count=$(cd "$project_dir" && git log main..HEAD --oneline 2>/dev/null | wc -l | tr -d ' ')
                files_changed=$(cd "$project_dir" && git diff main --name-only 2>/dev/null | wc -l | tr -d ' ')
            fi

            # Extract PR type from branch name
            local pr_type="Feature"
            if echo "$branch_name" | grep -q '^fix/'; then pr_type="Bug Fix"
            elif echo "$branch_name" | grep -q '^chore/'; then pr_type="Chore"
            elif echo "$branch_name" | grep -q '^hotfix/'; then pr_type="Hotfix"
            elif echo "$branch_name" | grep -q '^release/'; then pr_type="Release"
            fi

            cat <<PREOF
## ${pr_type}: ${branch_name:-unknown}

### Summary
<!-- Describe the changes -->

### Changes
- ${commit_count} commit(s), ${files_changed} file(s) changed

### Type of Change
- [ ] New feature
- [ ] Bug fix
- [ ] Breaking change
- [ ] Documentation update
- [ ] Refactoring

### Testing
- [ ] Unit tests pass
- [ ] Integration tests pass
- [ ] Manual testing completed
- [ ] No regressions observed

### Checklist
- [ ] Code follows project conventions
- [ ] Self-reviewed the changes
- [ ] Added/updated documentation
- [ ] No sensitive data exposed
- [ ] Error handling is comprehensive
PREOF
            ;;
        checklist)
            echo "=== PR Readiness Checklist ==="
            local ready=true
            # Check for uncommitted changes
            if [[ -d "${project_dir}/.git" ]]; then
                local uncommitted
                uncommitted=$(cd "$project_dir" && git status --porcelain 2>/dev/null | wc -l | tr -d ' ')
                if [[ $uncommitted -gt 0 ]]; then
                    echo "  [WARN] ${uncommitted} uncommitted changes"
                    ready=false
                else
                    echo "  [OK] All changes committed"
                fi

                local conflicts
                conflicts=$(cd "$project_dir" && git diff --name-only --diff-filter=U 2>/dev/null | wc -l | tr -d ' ')
                if [[ $conflicts -gt 0 ]]; then
                    echo "  [FAIL] ${conflicts} unresolved conflicts"
                    ready=false
                else
                    echo "  [OK] No merge conflicts"
                fi
            fi
            echo ""
            [[ "$ready" == "true" ]] && echo "Ready for PR!" || echo "Please resolve issues before creating PR."
            ;;
    esac
    return 0
}

# =============================================================================
# Report / Score
# =============================================================================
_sgw_report() {
    echo -e "\n  ${BOLD:-}=== Smart Git Workflow v${SGW_VERSION} ===${NC:-}"
    echo -e "  Branch Suggestions : ${SGW_BRANCH_SUGGESTIONS}"
    echo -e "  Commits Generated  : ${SGW_COMMIT_GENERATED}"
    echo -e "  PRs Generated      : ${SGW_PR_GENERATED}"
}

_sgw_score() {
    local score=30
    [[ "$SGW_INITIALIZED" == "true" ]] && score=$((score + 20))
    [[ $SGW_BRANCH_SUGGESTIONS -gt 0 ]] && score=$((score + 15))
    [[ $SGW_COMMIT_GENERATED -gt 0 ]] && score=$((score + 20))
    [[ $SGW_PR_GENERATED -gt 0 ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "smart-git-workflow" \
        --version "417.0" \
        --description "AI駆動ブランチ提案・コミットメッセージ・PR管理" \
        --init "_sgw_init" \
        --report "_sgw_report" \
        --score "_sgw_score" \
        --enable-var "ENABLE_SGW" \
        --cli-flags "--smart-git:--no-smart-git"
fi

# v2003.1: source時のexit codeを確実に0にする
true
