#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v324.0 - CI/CD Pipeline Optimizer
# =============================================================================
# GitHub Actions最適化、パイプラインステージ生成、キャッシュ戦略、並列実行最適化。
#
# Functions:
#   _cpo_init()                    - Initialize
#   _cpo_generate_github_actions() - Generate optimized GA workflows
#   _cpo_optimize_pipeline()       - Analyze & optimize existing pipeline
#   _cpo_generate_stages()         - Generate stage definitions
#   _cpo_report() / _cpo_score()
# =============================================================================

[[ -n "${_CPO_LOADED:-}" ]] && return 0; _CPO_LOADED=1

readonly _CPO_RED='\033[0;31m'
readonly _CPO_GREEN='\033[0;32m'
readonly _CPO_YELLOW='\033[0;33m'
readonly _CPO_CYAN='\033[0;36m'
readonly _CPO_NC='\033[0m'

declare -g CPO_VERSION="324.0"
CPO_GENERATED=0
CPO_ERRORS=0
CPO_FILES_WRITTEN=0
CPO_ACTIONS_OK=false
CPO_OPTIMIZE_OK=false
CPO_STAGES_OK=false

_cpo_init() {
    CPO_GENERATED=0; CPO_ERRORS=0; CPO_FILES_WRITTEN=0
    CPO_ACTIONS_OK=false; CPO_OPTIMIZE_OK=false; CPO_STAGES_OK=false
    echo -e "  ${_CPO_GREEN}OK${_CPO_NC} CI/CD Pipeline Optimizer v${CPO_VERSION}" >&2
    return 0
}

_cpo_write_file() {
    local filepath="$1" content="$2"
    mkdir -p "$(dirname "$filepath")" 2>/dev/null
    printf '%s\n' "$content" > "$filepath"
    [[ -f "$filepath" ]] && { CPO_FILES_WRITTEN=$((CPO_FILES_WRITTEN + 1)); return 0; }
    CPO_ERRORS=$((CPO_ERRORS + 1)); return 1
}

_cpo_log() {
    local level="$1" msg="$2"
    case "$level" in
        info)  echo -e "  ${_CPO_CYAN}[cicd]${_CPO_NC} $msg" >&2 ;;
        ok)    echo -e "  ${_CPO_GREEN}[cicd]${_CPO_NC} $msg" >&2 ;;
        warn)  echo -e "  ${_CPO_YELLOW}[cicd]${_CPO_NC} $msg" >&2 ;;
        error) echo -e "  ${_CPO_RED}[cicd]${_CPO_NC} $msg" >&2 ;;
    esac
}

# =============================================================================
# Generate GitHub Actions Workflows
# =============================================================================
_cpo_generate_github_actions() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local ga_dir="${project_dir}/.github/workflows"

    _cpo_log info "Generating GitHub Actions workflows..."

    # CI workflow
    _cpo_write_file "${ga_dir}/ci.yml" "$(cat <<'YAML'
name: CI
on:
  pull_request:
    branches: [main, develop]
  push:
    branches: [main]

concurrency:
  group: ci-${{ github.ref }}
  cancel-in-progress: true

jobs:
  lint:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm ci
      - run: npm run lint

  type-check:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm ci
      - run: npx tsc --noEmit

  test:
    runs-on: ubuntu-latest
    needs: [lint, type-check]
    services:
      postgres:
        image: postgres:16-alpine
        env:
          POSTGRES_USER: test
          POSTGRES_PASSWORD: test
          POSTGRES_DB: test
        ports: ['5432:5432']
        options: >-
          --health-cmd pg_isready
          --health-interval 10s
          --health-timeout 5s
          --health-retries 5
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm ci
      - run: npx prisma migrate deploy
        env:
          DATABASE_URL: postgresql://test:test@localhost:5432/test
      - run: npm test -- --coverage
        env:
          DATABASE_URL: postgresql://test:test@localhost:5432/test
      - uses: actions/upload-artifact@v4
        with:
          name: coverage
          path: coverage/

  build:
    runs-on: ubuntu-latest
    needs: test
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm ci
      - run: npm run build
      - uses: actions/upload-artifact@v4
        with:
          name: build
          path: .next/
YAML
)"

    # Deploy workflow
    _cpo_write_file "${ga_dir}/deploy.yml" "$(cat <<'YAML'
name: Deploy
on:
  push:
    branches: [main]
  workflow_dispatch:
    inputs:
      environment:
        description: 'Deploy environment'
        required: true
        default: 'staging'
        type: choice
        options: [staging, production]

permissions:
  id-token: write
  contents: read

jobs:
  deploy:
    runs-on: ubuntu-latest
    environment: ${{ github.event.inputs.environment || 'staging' }}
    steps:
      - uses: actions/checkout@v4

      - name: Configure AWS credentials
        uses: aws-actions/configure-aws-credentials@v4
        with:
          role-to-arn: ${{ secrets.AWS_ROLE_ARN }}
          aws-region: ap-northeast-1

      - name: Login to ECR
        id: ecr
        uses: aws-actions/amazon-ecr-login@v2

      - name: Build & push Docker image
        env:
          REGISTRY: ${{ steps.ecr.outputs.registry }}
          IMAGE_TAG: ${{ github.sha }}
        run: |
          docker build -t $REGISTRY/app:$IMAGE_TAG .
          docker push $REGISTRY/app:$IMAGE_TAG

      - name: Deploy to ECS
        run: |
          aws ecs update-service \
            --cluster app-cluster \
            --service app-service \
            --force-new-deployment
YAML
)"

    # Security scan workflow
    _cpo_write_file "${ga_dir}/security.yml" "$(cat <<'YAML'
name: Security Scan
on:
  schedule:
    - cron: '0 6 * * 1'
  pull_request:
    branches: [main]

jobs:
  audit:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: npm
      - run: npm audit --audit-level=high
      - name: Trivy scan
        uses: aquasecurity/trivy-action@master
        with:
          scan-type: fs
          severity: HIGH,CRITICAL
YAML
)"

    _cpo_log ok "GitHub Actions workflows generated"
    CPO_ACTIONS_OK=true
    CPO_GENERATED=$((CPO_GENERATED + 1))
    return 0
}

# =============================================================================
# Optimize Existing Pipeline
# =============================================================================
_cpo_optimize_pipeline() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local issues=0

    _cpo_log info "Analyzing CI/CD pipeline for optimizations..."

    # Check for workflow files
    local workflow_dir="${project_dir}/.github/workflows"
    if [[ ! -d "$workflow_dir" ]]; then
        _cpo_log warn "No .github/workflows directory found"
        return 1
    fi

    # Check caching
    local cache_found=false
    if grep -rq "actions/cache\|cache:" "$workflow_dir" 2>/dev/null; then
        cache_found=true
        _cpo_log ok "Dependency caching detected"
    else
        _cpo_log warn "No dependency caching. Add actions/cache or setup-node cache."
        issues=$((issues + 1))
    fi

    # Check concurrency
    if ! grep -rq "concurrency:" "$workflow_dir" 2>/dev/null; then
        _cpo_log warn "No concurrency control. Duplicate runs may waste resources."
        issues=$((issues + 1))
    fi

    # Check parallelization
    local job_count
    job_count=$(grep -c "^\s*[a-z_-]*:" "$workflow_dir"/*.yml 2>/dev/null | awk -F: '{sum+=$2} END{print sum+0}')
    if [[ "$job_count" -lt 3 ]]; then
        _cpo_log warn "Few jobs defined. Consider splitting lint/test/build for parallelism."
        issues=$((issues + 1))
    fi

    # Check for hardcoded secrets
    if grep -rq "password:\|secret:\|token:" "$workflow_dir" 2>/dev/null | grep -vq '\${{'; then
        _cpo_log error "Possible hardcoded secrets in workflow files!"
        issues=$((issues + 1))
    fi

    if [[ $issues -eq 0 ]]; then
        _cpo_log ok "Pipeline passes all optimization checks"
    else
        _cpo_log warn "${issues} optimization opportunities found"
    fi

    CPO_OPTIMIZE_OK=true
    CPO_GENERATED=$((CPO_GENERATED + 1))
    return 0
}

# =============================================================================
# Generate Stage Definitions
# =============================================================================
_cpo_generate_stages() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    _cpo_log info "Generating pipeline stage definitions..."

    local has_prisma=false has_tests=false has_e2e=false
    [[ -f "${project_dir}/prisma/schema.prisma" ]] && has_prisma=true
    [[ -d "${project_dir}/tests" ]] || [[ -d "${project_dir}/__tests__" ]] && has_tests=true
    [[ -d "${project_dir}/e2e" ]] || [[ -d "${project_dir}/tests/e2e" ]] && has_e2e=true

    local stages="lint,type-check"
    ${has_prisma} && stages="${stages},db-migrate"
    ${has_tests} && stages="${stages},unit-test"
    ${has_e2e} && stages="${stages},e2e-test"
    stages="${stages},build,deploy"

    _cpo_write_file "${project_dir}/.pipeline-stages.json" "$(cat <<JSON
{
  "stages": ["$(echo "$stages" | sed 's/,/","/g')"],
  "parallel_groups": {
    "quality": ["lint", "type-check"],
    "test": ["unit-test"$( ${has_e2e} && echo ', "e2e-test"' )]
  },
  "generated_at": "$(date -u +%Y-%m-%dT%H:%M:%SZ)"
}
JSON
)"

    _cpo_log ok "Pipeline stages: ${stages}"
    CPO_STAGES_OK=true
    CPO_GENERATED=$((CPO_GENERATED + 1))
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_cpo_report() {
    echo -e "\n  ${_CPO_CYAN}=== CI/CD Pipeline Optimizer v${CPO_VERSION} ===${_CPO_NC}"
    echo -e "  Generated: ${CPO_GENERATED} | Files: ${CPO_FILES_WRITTEN} | Errors: ${CPO_ERRORS}"
    echo -e "  Actions: $( ${CPO_ACTIONS_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Optimization: $( ${CPO_OPTIMIZE_OK} && echo 'OK' || echo 'SKIP')"
    echo -e "  Stages: $( ${CPO_STAGES_OK} && echo 'OK' || echo 'SKIP')"
}

_cpo_score() {
    local score=50
    ${CPO_ACTIONS_OK} && score=$((score + 20))
    ${CPO_OPTIMIZE_OK} && score=$((score + 15))
    ${CPO_STAGES_OK} && score=$((score + 10))
    [[ ${CPO_ERRORS} -eq 0 ]] && score=$((score + 5))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "cicd-pipeline-optimizer" --version "324.0" \
        --description "CI/CDパイプライン最適化 GitHub Actions/並列化/キャッシュ (v324)" \
        --init "_cpo_init" --report "_cpo_report" --score "_cpo_score" \
        --enable-var "ENABLE_CICD_PIPELINE_OPT" --cli-flags "--cicd-pipeline-opt:--no-cicd-pipeline-opt"
fi

# v2003.1: source時のexit codeを確実に0にする
true
