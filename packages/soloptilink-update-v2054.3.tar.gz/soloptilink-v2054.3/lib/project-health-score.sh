#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v208.0 - Project Health Score
# プロジェクトの総合的な健全性スコアを算出。
# テストカバレッジ、依存関係の鮮度、コード品質、セキュリティを
# 多角的に検査して0-100のスコアとHTMLレポートを生成する。
#
# 問題: プロジェクトの健全性は多くの指標から構成されるが、
# 一目で把握する方法がない。テスト不足、古い依存関係、
# コードスメル、セキュリティ問題が放置されがち。
#
# 解決: 5つの検査軸（テスト/依存関係/コード品質/セキュリティ/構造）
# を実行し、加重平均で総合スコアを算出。HTMLレポートで可視化。
# ============================================================

[[ -n "${_PHS_LOADED:-}" ]] && return 0
_PHS_LOADED=1

PHS_VERSION="208.0"
PHS_INITIALIZED=false

# State
PHS_PROJECT_DIR=""
PHS_CACHE_DIR=""
PHS_OVERALL_SCORE=0
PHS_TEST_SCORE=0
PHS_DEPENDENCY_SCORE=0
PHS_CODE_QUALITY_SCORE=0
PHS_SECURITY_SCORE=0
PHS_STRUCTURE_SCORE=0
PHS_REPORT_FILE=""
PHS_LAST_CHECK=""

# Detailed findings
PHS_TEST_FINDINGS=""
PHS_DEP_FINDINGS=""
PHS_QUALITY_FINDINGS=""
PHS_SECURITY_FINDINGS=""
PHS_STRUCTURE_FINDINGS=""

# ============================================================
# Init
# ============================================================
phs_init() {
    PHS_OVERALL_SCORE=0
    PHS_TEST_SCORE=0
    PHS_DEPENDENCY_SCORE=0
    PHS_CODE_QUALITY_SCORE=0
    PHS_SECURITY_SCORE=0
    PHS_STRUCTURE_SCORE=0
    PHS_REPORT_FILE=""
    PHS_LAST_CHECK=""

    PHS_TEST_FINDINGS=""
    PHS_DEP_FINDINGS=""
    PHS_QUALITY_FINDINGS=""
    PHS_SECURITY_FINDINGS=""
    PHS_STRUCTURE_FINDINGS=""

    PHS_PROJECT_DIR="${PROJECT_DIR:-.}"
    PHS_CACHE_DIR="${PHS_PROJECT_DIR}/.soloptilink/cache"
    mkdir -p "$PHS_CACHE_DIR" 2>/dev/null || true

    PHS_INITIALIZED=true
    return 0
}

# ============================================================
# Check test coverage (estimate from test file count/size)
# ============================================================
_phs_check_test_coverage() {
    local project_dir="${1:-$PHS_PROJECT_DIR}"
    [[ ! -d "$project_dir" ]] && { PHS_TEST_SCORE=0; return 1; }

    local score=0
    PHS_TEST_FINDINGS=""

    # Count source files
    local src_count=0
    src_count=$(find "$project_dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
        ! -path "*/node_modules/*" ! -path "*/.next/*" ! -path "*/.git/*" ! -path "*/dist/*" \
        ! -name "*.test.*" ! -name "*.spec.*" ! -path "*/__tests__/*" ! -path "*/tests/*" \
        2>/dev/null | wc -l | tr -d ' ')

    # Count test files
    local test_count=0
    test_count=$(find "$project_dir" -type f \( \
        -name "*.test.ts" -o -name "*.test.tsx" -o -name "*.test.js" -o \
        -name "*.spec.ts" -o -name "*.spec.tsx" -o -name "*.spec.js" -o \
        -name "*.bats" \
    \) \
        ! -path "*/node_modules/*" ! -path "*/.next/*" ! -path "*/.git/*" \
        2>/dev/null | wc -l | tr -d ' ')

    # Count total test lines (rough indicator of test depth)
    local test_lines=0
    test_lines=$(find "$project_dir" -type f \( \
        -name "*.test.ts" -o -name "*.test.tsx" -o -name "*.test.js" -o \
        -name "*.spec.ts" -o -name "*.spec.tsx" -o -name "*.bats" \
    \) \
        ! -path "*/node_modules/*" ! -path "*/.next/*" \
        2>/dev/null -exec wc -l {} + 2>/dev/null | tail -1 | awk '{print $1}')
    test_lines=${test_lines:-0}

    # Calculate test ratio
    local test_ratio=0
    if [[ $src_count -gt 0 ]]; then
        test_ratio=$((test_count * 100 / src_count))
    fi

    PHS_TEST_FINDINGS+="Source files: ${src_count}\n"
    PHS_TEST_FINDINGS+="Test files: ${test_count}\n"
    PHS_TEST_FINDINGS+="Test lines: ${test_lines}\n"
    PHS_TEST_FINDINGS+="Test file ratio: ${test_ratio}%\n"

    # Score based on test ratio
    if [[ $test_ratio -ge 80 ]]; then
        score=95
        PHS_TEST_FINDINGS+="Excellent test coverage ratio\n"
    elif [[ $test_ratio -ge 60 ]]; then
        score=80
        PHS_TEST_FINDINGS+="Good test coverage ratio\n"
    elif [[ $test_ratio -ge 40 ]]; then
        score=65
        PHS_TEST_FINDINGS+="Moderate test coverage\n"
    elif [[ $test_ratio -ge 20 ]]; then
        score=45
        PHS_TEST_FINDINGS+="Low test coverage - consider adding more tests\n"
    elif [[ $test_count -gt 0 ]]; then
        score=30
        PHS_TEST_FINDINGS+="Minimal test coverage - significant risk\n"
    else
        score=10
        PHS_TEST_FINDINGS+="NO tests found - critical risk\n"
    fi

    # Check for testing framework configuration
    local has_jest=false has_vitest=false has_playwright=false has_bats=false
    if [[ -f "${project_dir}/jest.config.js" ]] || [[ -f "${project_dir}/jest.config.ts" ]] || \
       grep -q '"jest"' "${project_dir}/package.json" 2>/dev/null; then
        has_jest=true
        PHS_TEST_FINDINGS+="Jest configured: yes\n"
        score=$((score + 3))
    fi
    if [[ -f "${project_dir}/vitest.config.ts" ]] || [[ -f "${project_dir}/vitest.config.js" ]]; then
        has_vitest=true
        PHS_TEST_FINDINGS+="Vitest configured: yes\n"
        score=$((score + 3))
    fi
    if [[ -f "${project_dir}/playwright.config.ts" ]] || [[ -f "${project_dir}/playwright.config.js" ]]; then
        has_playwright=true
        PHS_TEST_FINDINGS+="Playwright (E2E) configured: yes\n"
        score=$((score + 5))
    fi
    if find "$project_dir" -name "*.bats" -not -path "*/node_modules/*" 2>/dev/null | head -1 | grep -q .; then
        has_bats=true
        PHS_TEST_FINDINGS+="Bats tests found: yes\n"
        score=$((score + 2))
    fi

    # Check for CI test configuration
    if find "$project_dir" -path "*/.github/workflows/*" -name "*.yml" 2>/dev/null | \
       xargs grep -l "test\|jest\|vitest\|playwright" 2>/dev/null | head -1 | grep -q .; then
        PHS_TEST_FINDINGS+="CI test pipeline: yes\n"
        score=$((score + 5))
    fi

    [[ $score -gt 100 ]] && score=100
    PHS_TEST_SCORE=$score
    return 0
}

# ============================================================
# Check how outdated dependencies are
# ============================================================
_phs_check_dependency_freshness() {
    local project_dir="${1:-$PHS_PROJECT_DIR}"
    [[ ! -d "$project_dir" ]] && { PHS_DEPENDENCY_SCORE=0; return 1; }

    local score=80  # Start optimistic
    PHS_DEP_FINDINGS=""

    # Check if package.json exists
    if [[ ! -f "${project_dir}/package.json" ]]; then
        PHS_DEP_FINDINGS+="No package.json found\n"
        PHS_DEPENDENCY_SCORE=50
        return 0
    fi

    # Count dependencies
    local dep_count=0
    local dev_dep_count=0
    dep_count=$(grep -oE '"[^"]+"\s*:\s*"[~^]?[0-9]' "${project_dir}/package.json" 2>/dev/null | wc -l | tr -d ' ')
    PHS_DEP_FINDINGS+="Total dependencies: ${dep_count}\n"

    # Check for package-lock.json (reproducible builds)
    if [[ -f "${project_dir}/package-lock.json" ]]; then
        PHS_DEP_FINDINGS+="Lock file: present (good)\n"
        score=$((score + 5))
    else
        PHS_DEP_FINDINGS+="Lock file: MISSING (builds not reproducible)\n"
        score=$((score - 15))
    fi

    # Check for outdated patterns in dependency versions
    local pinned=0
    local range=0
    local latest=0
    while IFS= read -r version; do
        [[ -z "$version" ]] && continue
        version=$(echo "$version" | tr -d ' "')
        case "$version" in
            \^*|~*) range=$((range + 1)) ;;
            latest|*\*) latest=$((latest + 1)) ;;
            [0-9]*) pinned=$((pinned + 1)) ;;
        esac
    done < <(grep -oE ':\s*"[^"]+' "${project_dir}/package.json" 2>/dev/null | \
        grep -E '^\s*:\s*"[~^0-9*]|latest' | sed 's/^:\s*"//')

    PHS_DEP_FINDINGS+="Pinned versions: ${pinned}\n"
    PHS_DEP_FINDINGS+="Range versions: ${range}\n"
    PHS_DEP_FINDINGS+="Latest/wildcard: ${latest}\n"

    if [[ $latest -gt 0 ]]; then
        score=$((score - latest * 5))
        PHS_DEP_FINDINGS+="WARNING: ${latest} dependencies using 'latest' or wildcard\n"
    fi

    # Check for known problematic packages
    local -a deprecated_pkgs=("request" "moment" "tslint" "node-uuid" "nomnom" "coffee-script")
    for pkg in "${deprecated_pkgs[@]}"; do
        if grep -q "\"${pkg}\"" "${project_dir}/package.json" 2>/dev/null; then
            score=$((score - 5))
            PHS_DEP_FINDINGS+="Deprecated package found: ${pkg}\n"
        fi
    done

    # Check for duplicate/conflicting major versions (if lock file exists)
    if [[ -f "${project_dir}/package-lock.json" ]]; then
        local lock_size
        lock_size=$(wc -c < "${project_dir}/package-lock.json" 2>/dev/null | tr -d ' ')
        if [[ ${lock_size:-0} -gt 5000000 ]]; then
            score=$((score - 5))
            PHS_DEP_FINDINGS+="Large lock file (${lock_size} bytes) - possible dependency bloat\n"
        fi
    fi

    # npm audit check (if available)
    if command -v npm &>/dev/null && [[ -f "${project_dir}/package-lock.json" ]]; then
        local audit_json
        audit_json=$(cd "$project_dir" && npm audit --json 2>/dev/null | head -100 || true)
        if [[ -n "$audit_json" ]]; then
            local vulns
            vulns=$(echo "$audit_json" | grep -oE '"total":[0-9]+' | head -1 | grep -oE '[0-9]+$' || echo "0")
            PHS_DEP_FINDINGS+="Known vulnerabilities: ${vulns:-0}\n"
            if [[ ${vulns:-0} -gt 20 ]]; then
                score=$((score - 25))
            elif [[ ${vulns:-0} -gt 10 ]]; then
                score=$((score - 15))
            elif [[ ${vulns:-0} -gt 5 ]]; then
                score=$((score - 8))
            elif [[ ${vulns:-0} -gt 0 ]]; then
                score=$((score - 3))
            fi
        fi
    fi

    # Check engines field
    if grep -q '"engines"' "${project_dir}/package.json" 2>/dev/null; then
        PHS_DEP_FINDINGS+="Node engines specified: yes (good)\n"
        score=$((score + 3))
    else
        PHS_DEP_FINDINGS+="Node engines: not specified\n"
    fi

    [[ $score -gt 100 ]] && score=100
    [[ $score -lt 0 ]] && score=0
    PHS_DEPENDENCY_SCORE=$score
    return 0
}

# ============================================================
# Check for common code smells
# ============================================================
_phs_check_code_quality() {
    local project_dir="${1:-$PHS_PROJECT_DIR}"
    [[ ! -d "$project_dir" ]] && { PHS_CODE_QUALITY_SCORE=0; return 1; }

    local score=80
    PHS_QUALITY_FINDINGS=""
    local issues=0

    # Check 1: Long files (>500 lines)
    local long_files=0
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        local lines
        lines=$(wc -l < "$f" 2>/dev/null | tr -d ' ')
        if [[ ${lines:-0} -gt 500 ]]; then
            long_files=$((long_files + 1))
            if [[ $long_files -le 5 ]]; then
                local rel="${f#$project_dir/}"
                PHS_QUALITY_FINDINGS+="Long file (${lines} lines): ${rel}\n"
            fi
        fi
    done < <(find "$project_dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
        ! -path "*/node_modules/*" ! -path "*/.next/*" ! -path "*/.git/*" ! -path "*/dist/*" \
        2>/dev/null)

    if [[ $long_files -gt 10 ]]; then
        score=$((score - 15))
        PHS_QUALITY_FINDINGS+="Total files >500 lines: ${long_files} (too many)\n"
    elif [[ $long_files -gt 5 ]]; then
        score=$((score - 8))
        PHS_QUALITY_FINDINGS+="Total files >500 lines: ${long_files}\n"
    elif [[ $long_files -gt 0 ]]; then
        score=$((score - 3))
        PHS_QUALITY_FINDINGS+="Total files >500 lines: ${long_files}\n"
    fi

    # Check 2: Deep nesting (4+ levels of indentation with logic)
    local deep_nesting_files=0
    while IFS= read -r f; do
        [[ -z "$f" ]] && continue
        local deep_count
        deep_count=$(grep -cE '^\s{16,}(if |for |while |switch )' "$f" 2>/dev/null || echo "0")
        if [[ ${deep_count:-0} -gt 3 ]]; then
            deep_nesting_files=$((deep_nesting_files + 1))
            if [[ $deep_nesting_files -le 3 ]]; then
                local rel="${f#$project_dir/}"
                PHS_QUALITY_FINDINGS+="Deep nesting (${deep_count} instances): ${rel}\n"
            fi
        fi
    done < <(find "$project_dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
        ! -path "*/node_modules/*" ! -path "*/.next/*" ! -path "*/.git/*" \
        2>/dev/null | head -200)

    if [[ $deep_nesting_files -gt 5 ]]; then
        score=$((score - 10))
    elif [[ $deep_nesting_files -gt 0 ]]; then
        score=$((score - 3))
    fi
    PHS_QUALITY_FINDINGS+="Files with deep nesting: ${deep_nesting_files}\n"

    # Check 3: any usage in TypeScript
    local any_count=0
    any_count=$(find "$project_dir" -type f -name "*.ts" -o -name "*.tsx" \
        ! -path "*/node_modules/*" ! -path "*/.next/*" ! -path "*/.git/*" ! -path "*/dist/*" \
        2>/dev/null | xargs grep -lE ':\s*any\b|<any>' 2>/dev/null | wc -l | tr -d ' ')

    if [[ ${any_count:-0} -gt 20 ]]; then
        score=$((score - 12))
        PHS_QUALITY_FINDINGS+="Files using 'any' type: ${any_count} (excessive)\n"
    elif [[ ${any_count:-0} -gt 10 ]]; then
        score=$((score - 6))
        PHS_QUALITY_FINDINGS+="Files using 'any' type: ${any_count}\n"
    elif [[ ${any_count:-0} -gt 0 ]]; then
        score=$((score - 2))
        PHS_QUALITY_FINDINGS+="Files using 'any' type: ${any_count}\n"
    fi

    # Check 4: Console.log statements (should be removed in production)
    local console_count=0
    console_count=$(find "$project_dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
        ! -path "*/node_modules/*" ! -path "*/.next/*" ! -path "*/.git/*" ! -path "*/dist/*" \
        ! -name "*.test.*" ! -name "*.spec.*" \
        2>/dev/null | xargs grep -c 'console\.log' 2>/dev/null | \
        awk -F: '{sum += $2} END {print sum}')
    console_count=${console_count:-0}

    if [[ $console_count -gt 50 ]]; then
        score=$((score - 10))
        PHS_QUALITY_FINDINGS+="console.log statements: ${console_count} (too many)\n"
    elif [[ $console_count -gt 20 ]]; then
        score=$((score - 5))
        PHS_QUALITY_FINDINGS+="console.log statements: ${console_count}\n"
    elif [[ $console_count -gt 0 ]]; then
        PHS_QUALITY_FINDINGS+="console.log statements: ${console_count}\n"
    fi

    # Check 5: TODO/FIXME/HACK comments
    local todo_count=0
    todo_count=$(find "$project_dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" -o -name "*.sh" \) \
        ! -path "*/node_modules/*" ! -path "*/.next/*" ! -path "*/.git/*" \
        2>/dev/null | xargs grep -ciE '(TODO|FIXME|HACK|XXX):' 2>/dev/null | \
        awk -F: '{sum += $2} END {print sum}')
    todo_count=${todo_count:-0}

    PHS_QUALITY_FINDINGS+="TODO/FIXME/HACK comments: ${todo_count}\n"
    if [[ $todo_count -gt 30 ]]; then
        score=$((score - 8))
    elif [[ $todo_count -gt 15 ]]; then
        score=$((score - 4))
    fi

    # Check 6: ESLint/TypeScript strict configuration
    if [[ -f "${project_dir}/tsconfig.json" ]]; then
        if grep -q '"strict":\s*true' "${project_dir}/tsconfig.json" 2>/dev/null; then
            PHS_QUALITY_FINDINGS+="TypeScript strict mode: enabled (good)\n"
            score=$((score + 5))
        else
            PHS_QUALITY_FINDINGS+="TypeScript strict mode: NOT enabled\n"
            score=$((score - 5))
        fi
    fi

    if [[ -f "${project_dir}/.eslintrc.json" ]] || [[ -f "${project_dir}/.eslintrc.js" ]] || \
       [[ -f "${project_dir}/eslint.config.js" ]] || [[ -f "${project_dir}/eslint.config.mjs" ]]; then
        PHS_QUALITY_FINDINGS+="ESLint configured: yes\n"
        score=$((score + 3))
    else
        PHS_QUALITY_FINDINGS+="ESLint: not configured\n"
        score=$((score - 3))
    fi

    # Check 7: Prettier/formatting
    if [[ -f "${project_dir}/.prettierrc" ]] || [[ -f "${project_dir}/.prettierrc.json" ]] || \
       [[ -f "${project_dir}/.prettierrc.js" ]] || grep -q '"prettier"' "${project_dir}/package.json" 2>/dev/null; then
        PHS_QUALITY_FINDINGS+="Prettier configured: yes\n"
        score=$((score + 2))
    fi

    [[ $score -gt 100 ]] && score=100
    [[ $score -lt 0 ]] && score=0
    PHS_CODE_QUALITY_SCORE=$score
    return 0
}

# ============================================================
# Check for basic security issues
# ============================================================
_phs_check_security() {
    local project_dir="${1:-$PHS_PROJECT_DIR}"
    [[ ! -d "$project_dir" ]] && { PHS_SECURITY_SCORE=0; return 1; }

    local score=85
    PHS_SECURITY_FINDINGS=""

    # Check 1: Hardcoded secrets
    local secret_files=0
    local -a secret_patterns=(
        'AKIA[0-9A-Z]{16}'
        '["\x27]sk-[a-zA-Z0-9]{20,}["\x27]'
        'ghp_[a-zA-Z0-9]{36}'
        'password\s*[:=]\s*["\x27][^"\x27]{4,}["\x27]'
        'PRIVATE.KEY.*BEGIN'
        'JWT_SECRET\s*=\s*["\x27][^"\x27]{4,}'
    )

    for pattern in "${secret_patterns[@]}"; do
        local matches
        matches=$(find "$project_dir" -type f \( -name "*.ts" -o -name "*.js" -o -name "*.tsx" -o -name "*.jsx" -o -name "*.env" \) \
            ! -path "*/node_modules/*" ! -path "*/.next/*" ! -path "*/.git/*" \
            ! -name "*.env.example" ! -name "*.env.sample" \
            2>/dev/null | xargs grep -lE "$pattern" 2>/dev/null | head -5)
        if [[ -n "$matches" ]]; then
            secret_files=$((secret_files + 1))
            while IFS= read -r sf; do
                local rel="${sf#$project_dir/}"
                PHS_SECURITY_FINDINGS+="Potential secret in: ${rel}\n"
            done <<< "$matches"
        fi
    done

    if [[ $secret_files -gt 0 ]]; then
        score=$((score - secret_files * 10))
        PHS_SECURITY_FINDINGS+="CRITICAL: ${secret_files} secret pattern(s) detected\n"
    else
        PHS_SECURITY_FINDINGS+="No hardcoded secrets detected\n"
    fi

    # Check 2: .env in .gitignore
    if [[ -f "${project_dir}/.gitignore" ]]; then
        if grep -qE '^\.env$|^\.env\.' "${project_dir}/.gitignore" 2>/dev/null; then
            PHS_SECURITY_FINDINGS+=".env in .gitignore: yes (good)\n"
        else
            score=$((score - 10))
            PHS_SECURITY_FINDINGS+=".env NOT in .gitignore - secrets may be committed\n"
        fi
    else
        score=$((score - 5))
        PHS_SECURITY_FINDINGS+="No .gitignore found\n"
    fi

    # Check 3: Authentication patterns
    local has_auth=false
    if grep -rqE '(bcrypt|argon2|jwt|jsonwebtoken|next-auth|passport|lucia)' "$project_dir" \
        --include="*.ts" --include="*.js" --include="*.json" \
        --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=.git 2>/dev/null; then
        has_auth=true
        PHS_SECURITY_FINDINGS+="Authentication library detected: yes\n"
    fi

    # Check if API routes exist but no auth
    local api_count=0
    api_count=$(find "$project_dir" -path "*/api/*" -name "route.*" \
        ! -path "*/node_modules/*" ! -path "*/.next/*" \
        2>/dev/null | wc -l | tr -d ' ')

    if [[ $api_count -gt 0 ]] && [[ "$has_auth" == "false" ]]; then
        score=$((score - 15))
        PHS_SECURITY_FINDINGS+="API routes (${api_count}) found but NO authentication library\n"
    fi

    # Check 4: Input validation
    local has_validation=false
    if grep -rqE '(zod|yup|joi|class-validator|superstruct|valibot)' "$project_dir" \
        --include="*.ts" --include="*.js" --include="*.json" \
        --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=.git 2>/dev/null; then
        has_validation=true
        PHS_SECURITY_FINDINGS+="Input validation library: yes\n"
        score=$((score + 5))
    else
        if [[ $api_count -gt 0 ]]; then
            score=$((score - 10))
            PHS_SECURITY_FINDINGS+="No input validation library found (zod/joi/yup)\n"
        fi
    fi

    # Check 5: Security headers
    local has_security_headers=false
    if grep -rqE '(helmet|Content-Security-Policy|Strict-Transport-Security)' "$project_dir" \
        --include="*.ts" --include="*.js" --include="*.mjs" \
        --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=.git 2>/dev/null; then
        has_security_headers=true
        PHS_SECURITY_FINDINGS+="Security headers configured: yes\n"
    else
        score=$((score - 5))
        PHS_SECURITY_FINDINGS+="Security headers: not detected\n"
    fi

    # Check 6: CORS wildcard
    if grep -rqE "origin.*['\"]?\*['\"]?" "$project_dir" \
        --include="*.ts" --include="*.js" \
        --exclude-dir=node_modules --exclude-dir=.next --exclude-dir=.git 2>/dev/null; then
        score=$((score - 10))
        PHS_SECURITY_FINDINGS+="CORS wildcard (*) detected\n"
    fi

    # Check 7: SQL injection risk (raw queries)
    local raw_sql=0
    raw_sql=$(find "$project_dir" -type f \( -name "*.ts" -o -name "*.js" \) \
        ! -path "*/node_modules/*" ! -path "*/.next/*" ! -path "*/.git/*" \
        2>/dev/null | xargs grep -cE '\$\{.*\}.*SQL|query\(`.*\$\{' 2>/dev/null | \
        awk -F: '{sum += $2} END {print sum}')
    raw_sql=${raw_sql:-0}

    if [[ $raw_sql -gt 0 ]]; then
        score=$((score - raw_sql * 5))
        PHS_SECURITY_FINDINGS+="Potential SQL injection risks: ${raw_sql}\n"
    fi

    [[ $score -gt 100 ]] && score=100
    [[ $score -lt 0 ]] && score=0
    PHS_SECURITY_SCORE=$score
    return 0
}

# ============================================================
# Internal: Check project structure health
# ============================================================
_phs_check_structure() {
    local project_dir="${1:-$PHS_PROJECT_DIR}"
    [[ ! -d "$project_dir" ]] && { PHS_STRUCTURE_SCORE=0; return 1; }

    local score=70
    PHS_STRUCTURE_FINDINGS=""

    # Check for README
    if [[ -f "${project_dir}/README.md" ]]; then
        local readme_lines
        readme_lines=$(wc -l < "${project_dir}/README.md" 2>/dev/null | tr -d ' ')
        if [[ ${readme_lines:-0} -gt 20 ]]; then
            score=$((score + 5))
            PHS_STRUCTURE_FINDINGS+="README.md: present (${readme_lines} lines)\n"
        else
            PHS_STRUCTURE_FINDINGS+="README.md: present but minimal\n"
        fi
    else
        score=$((score - 5))
        PHS_STRUCTURE_FINDINGS+="README.md: missing\n"
    fi

    # Check for proper directory structure
    local structure_score=0
    [[ -d "${project_dir}/lib" ]] || [[ -d "${project_dir}/src" ]] && structure_score=$((structure_score + 1))
    [[ -d "${project_dir}/tests" ]] || [[ -d "${project_dir}/__tests__" ]] && structure_score=$((structure_score + 1))
    [[ -f "${project_dir}/package.json" ]] || [[ -f "${project_dir}/Cargo.toml" ]] || [[ -f "${project_dir}/go.mod" ]] && structure_score=$((structure_score + 1))
    [[ -d "${project_dir}/docs" ]] && structure_score=$((structure_score + 1))
    [[ -f "${project_dir}/.gitignore" ]] && structure_score=$((structure_score + 1))

    score=$((score + structure_score * 3))
    PHS_STRUCTURE_FINDINGS+="Structure score: ${structure_score}/5\n"

    # Check for CI/CD configuration
    if [[ -d "${project_dir}/.github/workflows" ]]; then
        local workflow_count
        workflow_count=$(find "${project_dir}/.github/workflows" -name "*.yml" -o -name "*.yaml" 2>/dev/null | wc -l | tr -d ' ')
        score=$((score + 5))
        PHS_STRUCTURE_FINDINGS+="GitHub Actions workflows: ${workflow_count}\n"
    fi

    # Check for Docker support
    if [[ -f "${project_dir}/Dockerfile" ]] || [[ -f "${project_dir}/docker-compose.yml" ]] || [[ -f "${project_dir}/docker-compose.yaml" ]]; then
        score=$((score + 3))
        PHS_STRUCTURE_FINDINGS+="Docker configuration: present\n"
    fi

    # Check for environment example
    if [[ -f "${project_dir}/.env.example" ]] || [[ -f "${project_dir}/.env.sample" ]]; then
        score=$((score + 3))
        PHS_STRUCTURE_FINDINGS+=".env.example: present (good for onboarding)\n"
    fi

    # Check for consistent file naming
    local mixed_naming=0
    local camel_files=0
    local kebab_files=0
    while IFS= read -r f; do
        local base
        base=$(basename "$f" | sed 's/\.[^.]*$//')
        if echo "$base" | grep -qE '[A-Z].*[a-z]|[a-z].*[A-Z]' 2>/dev/null; then
            camel_files=$((camel_files + 1))
        fi
        if echo "$base" | grep -q '-' 2>/dev/null; then
            kebab_files=$((kebab_files + 1))
        fi
    done < <(find "$project_dir" -type f \( -name "*.ts" -o -name "*.tsx" -o -name "*.js" -o -name "*.jsx" \) \
        ! -path "*/node_modules/*" ! -path "*/.next/*" ! -path "*/.git/*" \
        2>/dev/null | head -100)

    if [[ $camel_files -gt 5 ]] && [[ $kebab_files -gt 5 ]]; then
        PHS_STRUCTURE_FINDINGS+="Mixed naming conventions (camelCase: ${camel_files}, kebab-case: ${kebab_files})\n"
        score=$((score - 3))
    fi

    [[ $score -gt 100 ]] && score=100
    [[ $score -lt 0 ]] && score=0
    PHS_STRUCTURE_SCORE=$score
    return 0
}

# ============================================================
# Calculate overall project health score (0-100)
# ============================================================
_phs_calculate() {
    local project_dir="${1:-$PHS_PROJECT_DIR}"
    [[ ! -d "$project_dir" ]] && { echo "[PHS] Error: project directory not found" >&2; return 1; }
    [[ "$PHS_INITIALIZED" != "true" ]] && phs_init

    PHS_PROJECT_DIR="$project_dir"

    echo "[PHS] Calculating project health score..." >&2

    # Run all checks
    _phs_check_test_coverage "$project_dir"
    echo "[PHS] Test coverage: ${PHS_TEST_SCORE}/100" >&2

    _phs_check_dependency_freshness "$project_dir"
    echo "[PHS] Dependencies: ${PHS_DEPENDENCY_SCORE}/100" >&2

    _phs_check_code_quality "$project_dir"
    echo "[PHS] Code quality: ${PHS_CODE_QUALITY_SCORE}/100" >&2

    _phs_check_security "$project_dir"
    echo "[PHS] Security: ${PHS_SECURITY_SCORE}/100" >&2

    _phs_check_structure "$project_dir"
    echo "[PHS] Structure: ${PHS_STRUCTURE_SCORE}/100" >&2

    # Weighted average (security and code quality weighted higher)
    # Weights: test=20%, deps=15%, quality=25%, security=25%, structure=15%
    PHS_OVERALL_SCORE=$(( \
        (PHS_TEST_SCORE * 20 + \
         PHS_DEPENDENCY_SCORE * 15 + \
         PHS_CODE_QUALITY_SCORE * 25 + \
         PHS_SECURITY_SCORE * 25 + \
         PHS_STRUCTURE_SCORE * 15) / 100 \
    ))

    PHS_LAST_CHECK=$(date '+%Y-%m-%dT%H:%M:%S')

    echo ""
    echo "=== Project Health Score ==="
    echo "Project:      ${project_dir}"
    echo "Timestamp:    ${PHS_LAST_CHECK}"
    echo ""
    echo "Test Coverage:    ${PHS_TEST_SCORE}/100 (weight: 20%)"
    echo "Dependencies:     ${PHS_DEPENDENCY_SCORE}/100 (weight: 15%)"
    echo "Code Quality:     ${PHS_CODE_QUALITY_SCORE}/100 (weight: 25%)"
    echo "Security:         ${PHS_SECURITY_SCORE}/100 (weight: 25%)"
    echo "Structure:        ${PHS_STRUCTURE_SCORE}/100 (weight: 15%)"
    echo ""
    echo "Overall Score:    ${PHS_OVERALL_SCORE}/100"
    echo ""

    # Grade
    local grade=""
    if [[ $PHS_OVERALL_SCORE -ge 90 ]]; then
        grade="A (Excellent)"
    elif [[ $PHS_OVERALL_SCORE -ge 80 ]]; then
        grade="B (Good)"
    elif [[ $PHS_OVERALL_SCORE -ge 70 ]]; then
        grade="C (Fair)"
    elif [[ $PHS_OVERALL_SCORE -ge 60 ]]; then
        grade="D (Needs Improvement)"
    else
        grade="F (Critical)"
    fi
    echo "Grade: ${grade}"

    # Save to cache
    {
        echo "{"
        echo "  \"version\": \"${PHS_VERSION}\","
        echo "  \"project\": \"${project_dir}\","
        echo "  \"timestamp\": \"${PHS_LAST_CHECK}\","
        echo "  \"overall\": ${PHS_OVERALL_SCORE},"
        echo "  \"grade\": \"${grade}\","
        echo "  \"scores\": {"
        echo "    \"test_coverage\": ${PHS_TEST_SCORE},"
        echo "    \"dependencies\": ${PHS_DEPENDENCY_SCORE},"
        echo "    \"code_quality\": ${PHS_CODE_QUALITY_SCORE},"
        echo "    \"security\": ${PHS_SECURITY_SCORE},"
        echo "    \"structure\": ${PHS_STRUCTURE_SCORE}"
        echo "  }"
        echo "}"
    } > "${PHS_CACHE_DIR}/health-score.json"

    return 0
}

# ============================================================
# Generate HTML health report
# ============================================================
_phs_generate_report() {
    local project_dir="${1:-$PHS_PROJECT_DIR}"
    local output_file="${2:-${PHS_CACHE_DIR}/health-report.html}"

    [[ "$PHS_INITIALIZED" != "true" ]] && phs_init
    PHS_PROJECT_DIR="$project_dir"

    # Run calculation if not done yet
    if [[ $PHS_OVERALL_SCORE -eq 0 ]] && [[ -z "$PHS_LAST_CHECK" ]]; then
        _phs_calculate "$project_dir" >/dev/null 2>&1
    fi

    mkdir -p "$(dirname "$output_file")" 2>/dev/null

    local grade_color=""
    if [[ $PHS_OVERALL_SCORE -ge 90 ]]; then grade_color="#22c55e"
    elif [[ $PHS_OVERALL_SCORE -ge 80 ]]; then grade_color="#84cc16"
    elif [[ $PHS_OVERALL_SCORE -ge 70 ]]; then grade_color="#eab308"
    elif [[ $PHS_OVERALL_SCORE -ge 60 ]]; then grade_color="#f97316"
    else grade_color="#ef4444"
    fi

    cat > "$output_file" << 'HTMLEOF'
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Project Health Report - SoloptiLinkAI</title>
<style>
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; background: #0f172a; color: #e2e8f0; padding: 2rem; }
  .container { max-width: 900px; margin: 0 auto; }
  h1 { text-align: center; margin-bottom: 0.5rem; font-size: 1.8rem; }
  .subtitle { text-align: center; color: #94a3b8; margin-bottom: 2rem; }
  .score-card { background: #1e293b; border-radius: 16px; padding: 2rem; text-align: center; margin-bottom: 2rem; }
  .overall-score { font-size: 5rem; font-weight: 800; line-height: 1; }
  .grade { font-size: 1.5rem; margin-top: 0.5rem; }
  .scores-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
  .score-item { background: #1e293b; border-radius: 12px; padding: 1.5rem; }
  .score-item h3 { font-size: 0.9rem; color: #94a3b8; text-transform: uppercase; letter-spacing: 0.05em; margin-bottom: 0.5rem; }
  .score-item .value { font-size: 2.5rem; font-weight: 700; }
  .score-bar { height: 6px; background: #334155; border-radius: 3px; margin-top: 0.75rem; overflow: hidden; }
  .score-bar-fill { height: 100%; border-radius: 3px; transition: width 0.5s; }
  .findings { background: #1e293b; border-radius: 12px; padding: 1.5rem; margin-bottom: 1rem; }
  .findings h3 { margin-bottom: 1rem; font-size: 1.1rem; }
  .findings pre { font-size: 0.85rem; color: #94a3b8; white-space: pre-wrap; line-height: 1.6; }
  .footer { text-align: center; color: #475569; font-size: 0.8rem; margin-top: 2rem; }
</style>
</head>
<body>
<div class="container">
  <h1>Project Health Report</h1>
  <p class="subtitle">SoloptiLinkAI v208.0 - Generated: TIMESTAMP_PLACEHOLDER</p>

  <div class="score-card">
    <div class="overall-score" style="color: GRADE_COLOR_PLACEHOLDER">OVERALL_PLACEHOLDER</div>
    <div class="grade">GRADE_PLACEHOLDER</div>
  </div>

  <div class="scores-grid">
    <div class="score-item">
      <h3>Test Coverage</h3>
      <div class="value" style="color: TEST_COLOR">TEST_SCORE/100</div>
      <div class="score-bar"><div class="score-bar-fill" style="width: TEST_SCORE%; background: TEST_COLOR"></div></div>
    </div>
    <div class="score-item">
      <h3>Dependencies</h3>
      <div class="value" style="color: DEP_COLOR">DEP_SCORE/100</div>
      <div class="score-bar"><div class="score-bar-fill" style="width: DEP_SCORE%; background: DEP_COLOR"></div></div>
    </div>
    <div class="score-item">
      <h3>Code Quality</h3>
      <div class="value" style="color: QUALITY_COLOR">QUALITY_SCORE/100</div>
      <div class="score-bar"><div class="score-bar-fill" style="width: QUALITY_SCORE%; background: QUALITY_COLOR"></div></div>
    </div>
    <div class="score-item">
      <h3>Security</h3>
      <div class="value" style="color: SECURITY_COLOR">SECURITY_SCORE/100</div>
      <div class="score-bar"><div class="score-bar-fill" style="width: SECURITY_SCORE%; background: SECURITY_COLOR"></div></div>
    </div>
    <div class="score-item">
      <h3>Structure</h3>
      <div class="value" style="color: STRUCTURE_COLOR">STRUCTURE_SCORE/100</div>
      <div class="score-bar"><div class="score-bar-fill" style="width: STRUCTURE_SCORE%; background: STRUCTURE_COLOR"></div></div>
    </div>
  </div>

  <div class="findings">
    <h3>Test Coverage Details</h3>
    <pre>TEST_FINDINGS</pre>
  </div>
  <div class="findings">
    <h3>Dependency Details</h3>
    <pre>DEP_FINDINGS</pre>
  </div>
  <div class="findings">
    <h3>Code Quality Details</h3>
    <pre>QUALITY_FINDINGS</pre>
  </div>
  <div class="findings">
    <h3>Security Details</h3>
    <pre>SECURITY_FINDINGS</pre>
  </div>
  <div class="findings">
    <h3>Structure Details</h3>
    <pre>STRUCTURE_FINDINGS</pre>
  </div>

  <div class="footer">
    SoloptiLinkAI Project Health Score v208.0 | Project: PROJECT_PLACEHOLDER
  </div>
</div>
</body>
</html>
HTMLEOF

    # Helper to get color from score
    _phs_score_color() {
        local s=$1
        if [[ $s -ge 80 ]]; then echo "#22c55e"
        elif [[ $s -ge 60 ]]; then echo "#eab308"
        elif [[ $s -ge 40 ]]; then echo "#f97316"
        else echo "#ef4444"
        fi
    }

    local grade=""
    if [[ $PHS_OVERALL_SCORE -ge 90 ]]; then grade="A - Excellent"
    elif [[ $PHS_OVERALL_SCORE -ge 80 ]]; then grade="B - Good"
    elif [[ $PHS_OVERALL_SCORE -ge 70 ]]; then grade="C - Fair"
    elif [[ $PHS_OVERALL_SCORE -ge 60 ]]; then grade="D - Needs Improvement"
    else grade="F - Critical"
    fi

    # Replace placeholders using sed
    sed -i.bak \
        -e "s|TIMESTAMP_PLACEHOLDER|${PHS_LAST_CHECK}|g" \
        -e "s|GRADE_COLOR_PLACEHOLDER|${grade_color}|g" \
        -e "s|OVERALL_PLACEHOLDER|${PHS_OVERALL_SCORE}|g" \
        -e "s|GRADE_PLACEHOLDER|${grade}|g" \
        -e "s|TEST_SCORE|${PHS_TEST_SCORE}|g" \
        -e "s|DEP_SCORE|${PHS_DEPENDENCY_SCORE}|g" \
        -e "s|QUALITY_SCORE|${PHS_CODE_QUALITY_SCORE}|g" \
        -e "s|SECURITY_SCORE|${PHS_SECURITY_SCORE}|g" \
        -e "s|STRUCTURE_SCORE|${PHS_STRUCTURE_SCORE}|g" \
        -e "s|TEST_COLOR|$(_phs_score_color $PHS_TEST_SCORE)|g" \
        -e "s|DEP_COLOR|$(_phs_score_color $PHS_DEPENDENCY_SCORE)|g" \
        -e "s|QUALITY_COLOR|$(_phs_score_color $PHS_CODE_QUALITY_SCORE)|g" \
        -e "s|SECURITY_COLOR|$(_phs_score_color $PHS_SECURITY_SCORE)|g" \
        -e "s|STRUCTURE_COLOR|$(_phs_score_color $PHS_STRUCTURE_SCORE)|g" \
        -e "s|PROJECT_PLACEHOLDER|${project_dir}|g" \
        "$output_file" 2>/dev/null

    # Replace findings (multi-line, use a different approach)
    local test_findings_escaped dep_findings_escaped quality_findings_escaped security_findings_escaped structure_findings_escaped
    test_findings_escaped=$(echo -e "$PHS_TEST_FINDINGS" | sed 's/[&/\]/\\&/g' | tr '\n' '\r')
    dep_findings_escaped=$(echo -e "$PHS_DEP_FINDINGS" | sed 's/[&/\]/\\&/g' | tr '\n' '\r')
    quality_findings_escaped=$(echo -e "$PHS_QUALITY_FINDINGS" | sed 's/[&/\]/\\&/g' | tr '\n' '\r')
    security_findings_escaped=$(echo -e "$PHS_SECURITY_FINDINGS" | sed 's/[&/\]/\\&/g' | tr '\n' '\r')
    structure_findings_escaped=$(echo -e "$PHS_STRUCTURE_FINDINGS" | sed 's/[&/\]/\\&/g' | tr '\n' '\r')

    # Use perl for multi-line replacement (more reliable than sed)
    if command -v perl &>/dev/null; then
        perl -i -pe "s|TEST_FINDINGS|$(echo -e "$PHS_TEST_FINDINGS" | perl -pe 's/[\n\r]/\\n/g; s/[|]/\\|/g')|g" "$output_file" 2>/dev/null || true
        perl -i -pe "s|DEP_FINDINGS|$(echo -e "$PHS_DEP_FINDINGS" | perl -pe 's/[\n\r]/\\n/g; s/[|]/\\|/g')|g" "$output_file" 2>/dev/null || true
        perl -i -pe "s|QUALITY_FINDINGS|$(echo -e "$PHS_QUALITY_FINDINGS" | perl -pe 's/[\n\r]/\\n/g; s/[|]/\\|/g')|g" "$output_file" 2>/dev/null || true
        perl -i -pe "s|SECURITY_FINDINGS|$(echo -e "$PHS_SECURITY_FINDINGS" | perl -pe 's/[\n\r]/\\n/g; s/[|]/\\|/g')|g" "$output_file" 2>/dev/null || true
        perl -i -pe "s|STRUCTURE_FINDINGS|$(echo -e "$PHS_STRUCTURE_FINDINGS" | perl -pe 's/[\n\r]/\\n/g; s/[|]/\\|/g')|g" "$output_file" 2>/dev/null || true
    fi

    # Cleanup backup
    rm -f "${output_file}.bak" 2>/dev/null

    PHS_REPORT_FILE="$output_file"
    echo "[PHS] HTML report saved to: $output_file" >&2

    return 0
}

# ============================================================
# Score (for Module Registry)
# ============================================================
phs_score() {
    if [[ $PHS_OVERALL_SCORE -gt 0 ]]; then
        echo "$PHS_OVERALL_SCORE"
    else
        echo "50"
    fi
}

# ============================================================
# Report
# ============================================================
phs_report() {
    echo -e "\n  ${BOLD:-}=== Project Health Score v${PHS_VERSION} ===${NC:-}"
    echo -e "  Overall:        ${PHS_OVERALL_SCORE}/100"
    echo -e "  Test coverage:  ${PHS_TEST_SCORE}/100"
    echo -e "  Dependencies:   ${PHS_DEPENDENCY_SCORE}/100"
    echo -e "  Code quality:   ${PHS_CODE_QUALITY_SCORE}/100"
    echo -e "  Security:       ${PHS_SECURITY_SCORE}/100"
    echo -e "  Structure:      ${PHS_STRUCTURE_SCORE}/100"
    echo -e "  Last check:     ${PHS_LAST_CHECK:-not run}"
    [[ -n "$PHS_REPORT_FILE" ]] && echo -e "  Report:         ${PHS_REPORT_FILE}"
}

# ============================================================
# Module Registry self-registration
# ============================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "project-health-score" \
        --version "$PHS_VERSION" \
        --description "プロジェクト健全性スコア - テスト/依存/品質/セキュリティ/構造の5軸評価" \
        --init "phs_init" \
        --report "phs_report" \
        --score "phs_score" \
        --enable-var "ENABLE_PHS" \
        --cli-flags "--health-score:--no-health-score"
fi

# v2003.1: source時のexit codeを確実に0にする
true
