#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v320.0 - Architecture Integration (Master Orchestrator)
# =============================================================================
# v301-v319のドメイン特化ジェネレーター群を統合するマスターオーケストレーター。
# 要件分析→アーキテクチャ選択→ジェネレーター選択→統合生成→検証を一貫実行。
#
# 全globals: AI2_ prefix
# =============================================================================

[[ -n "${_ARCHITECTURE_INTEGRATION_LOADED:-}" ]] && return 0
_ARCHITECTURE_INTEGRATION_LOADED=1

declare -g AI2_VERSION="320.0"
declare -g AI2_INITIALIZED=false
declare -g AI2_SELECTED_GENERATORS=()
declare -g AI2_GENERATED_SYSTEMS=()
declare -g AI2_VALIDATION_RESULTS=()
declare -g AI2_ANALYSIS_RESULT=""
declare -g ENABLE_ARCHITECTURE_INTEGRATION="${ENABLE_ARCHITECTURE_INTEGRATION:-true}"

# Generator registry: name -> functions prefix -> description -> keywords
declare -A AI2_GENERATOR_MAP
AI2_GENERATOR_MAP=(
    ["admin-panel"]="apg|管理パネル|admin,dashboard,管理,パネル,backoffice,バックオフィス"
    ["customer-portal"]="cpg|カスタマーポータル|portal,ポータル,顧客,customer,マイページ"
    ["lp-marketing"]="lmg|LP/マーケティング|lp,ランディング,landing,marketing,マーケティング,LP"
    ["blog-cms"]="bcg|ブログ/CMS|blog,ブログ,cms,記事,article,コンテンツ"
    ["ecommerce"]="ee|Eコマース|ec,ecommerce,shop,ショップ,商品,product,カート,cart,注文,order"
    ["crm"]="crm|CRM|crm,顧客管理,リード,lead,パイプライン,pipeline,営業"
    ["project-management"]="pmg|プロジェクト管理|project,プロジェクト,タスク,task,カンバン,kanban,ガント,gantt"
    ["hr-system"]="hsg|人事システム|hr,人事,勤怠,attendance,休暇,leave,従業員,employee,評価"
    ["inventory"]="isg|在庫管理|inventory,在庫,stock,倉庫,warehouse,発注,barcode"
    ["accounting"]="asg|会計システム|accounting,会計,仕訳,journal,請求,invoice,元帳,ledger"
    ["reservation"]="rsg|予約システム|reservation,予約,booking,カレンダー,calendar,空き"
    ["chat"]="chsg|チャットシステム|chat,チャット,メッセージ,message,リアルタイム,realtime"
    ["workflow"]="weg|ワークフロー|workflow,ワークフロー,承認,approval,フロー,flow"
    ["reporting"]="reg|レポートエンジン|report,レポート,分析,chart,グラフ,export"
    ["audit-trail"]="ats|監査証跡|audit,監査,ログ,compliance,コンプライアンス,証跡"
    ["data-hub"]="dieh|データハブ|import,export,csv,webhook,sync,データ連携"
    ["notification-hub"]="nh|通知ハブ|notification,通知,email,push,slack,line"
    ["analytics-dashboard"]="adg|分析ダッシュボード|analytics,アナリティクス,kpi,funnel,ファネル,cohort"
    ["system-integration"]="sib|システム連携|integration,連携,slack,google,api,webhook"
)

readonly AI2_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly AI2_YELLOW="${CLR_YELLOW:-\033[0;33m}"
readonly AI2_RED="${CLR_RED:-\033[0;31m}"
readonly AI2_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly AI2_BOLD="${CLR_BOLD:-\033[1m}"
readonly AI2_NC="${CLR_NC:-\033[0m}"

_ai2_log()  { echo -e "  ${AI2_CYAN}[AI2]${AI2_NC} $*" >&2; }
_ai2_ok()   { echo -e "  ${AI2_GREEN}[AI2] OK${AI2_NC} $*" >&2; }
_ai2_warn() { echo -e "  ${AI2_YELLOW}[AI2] WARN${AI2_NC} $*" >&2; }
_ai2_err()  { echo -e "  ${AI2_RED}[AI2] ERR${AI2_NC} $*" >&2; }

# =============================================================================
# _ai2_init() - Initialize all architecture modules
# =============================================================================
_ai2_init() {
    AI2_INITIALIZED=true
    AI2_SELECTED_GENERATORS=()
    AI2_GENERATED_SYSTEMS=()
    AI2_VALIDATION_RESULTS=()
    AI2_ANALYSIS_RESULT=""

    _ai2_log "Architecture Integration v${AI2_VERSION} 初期化"
    _ai2_log "登録済みジェネレーター: ${#AI2_GENERATOR_MAP[@]}種"
    return 0
}

ai2_report() {
    [[ "$AI2_INITIALIZED" != "true" ]] && return 0
    echo -e "\n  ${AI2_BOLD}=== Architecture Integration v${AI2_VERSION} レポート ===${AI2_NC}" >&2
    echo -e "  登録ジェネレーター: ${#AI2_GENERATOR_MAP[@]}" >&2
    echo -e "  選択ジェネレーター: ${#AI2_SELECTED_GENERATORS[@]}" >&2
    echo -e "  生成システム: ${#AI2_GENERATED_SYSTEMS[@]}" >&2

    if [[ ${#AI2_SELECTED_GENERATORS[@]} -gt 0 ]]; then
        echo -e "  選択済み:" >&2
        for gen in "${AI2_SELECTED_GENERATORS[@]}"; do
            local entry="${AI2_GENERATOR_MAP[$gen]:-}"
            local desc="${entry#*|}"
            desc="${desc%%|*}"
            echo -e "    - ${gen}: ${desc}" >&2
        done
    fi

    if [[ ${#AI2_VALIDATION_RESULTS[@]} -gt 0 ]]; then
        echo -e "  検証結果:" >&2
        for result in "${AI2_VALIDATION_RESULTS[@]}"; do
            echo -e "    ${result}" >&2
        done
    fi
}

ai2_score() {
    [[ "$AI2_INITIALIZED" != "true" ]] && { echo "0"; return; }
    local score=50
    [[ ${#AI2_SELECTED_GENERATORS[@]} -gt 0 ]] && score=70
    [[ ${#AI2_GENERATED_SYSTEMS[@]} -gt 0 ]] && score=85
    [[ ${#AI2_VALIDATION_RESULTS[@]} -gt 0 ]] && score=95
    echo "$score"
}

ai2_init_message() {
    echo -e "  ${AI2_GREEN}v${AI2_VERSION} architecture-integration: マスターアーキテクチャ統合 (${#AI2_GENERATOR_MAP[@]}ジェネレーター)${AI2_NC}" >&2
}

# =============================================================================
# _ai2_analyze_requirements() - Analyze requirements to select architecture
# =============================================================================
_ai2_analyze_requirements() {
    local requirements="${1:-}"
    local project_type="${2:-web}"

    [[ -z "$requirements" ]] && { _ai2_err "要件指定なし"; return 1; }

    _ai2_log "要件分析開始: $(echo "$requirements" | head -c 100)..."

    local req_lower
    req_lower="$(echo "$requirements" | tr '[:upper:]' '[:lower:]')"

    # Detect domain keywords
    local detected_domains=()
    local detected_features=()

    # Pattern matching for domain detection
    if echo "$req_lower" | grep -qE "crm|顧客管理|営業管理|リード|パイプライン"; then
        detected_domains+=("crm")
    fi
    if echo "$req_lower" | grep -qE "ec|ecommerce|ショップ|商品|カート|注文|決済"; then
        detected_domains+=("ecommerce")
    fi
    if echo "$req_lower" | grep -qE "ブログ|blog|記事|cms|コンテンツ管理"; then
        detected_domains+=("blog-cms")
    fi
    if echo "$req_lower" | grep -qE "プロジェクト|タスク管理|カンバン|ガント"; then
        detected_domains+=("project-management")
    fi
    if echo "$req_lower" | grep -qE "人事|hr|勤怠|休暇|従業員|給与"; then
        detected_domains+=("hr-system")
    fi
    if echo "$req_lower" | grep -qE "在庫|inventory|倉庫|発注|バーコード"; then
        detected_domains+=("inventory")
    fi
    if echo "$req_lower" | grep -qE "会計|accounting|仕訳|請求書|元帳"; then
        detected_domains+=("accounting")
    fi
    if echo "$req_lower" | grep -qE "予約|reservation|booking|カレンダー"; then
        detected_domains+=("reservation")
    fi
    if echo "$req_lower" | grep -qE "チャット|chat|メッセージ|リアルタイム通信"; then
        detected_domains+=("chat")
    fi
    if echo "$req_lower" | grep -qE "lp|ランディング|マーケティング"; then
        detected_domains+=("lp-marketing")
    fi

    # Common features detection
    if echo "$req_lower" | grep -qE "管理画面|admin|バックオフィス|管理パネル"; then
        detected_features+=("admin-panel")
    fi
    if echo "$req_lower" | grep -qE "ポータル|マイページ|顧客ポータル"; then
        detected_features+=("customer-portal")
    fi
    if echo "$req_lower" | grep -qE "通知|notification|メール通知|プッシュ"; then
        detected_features+=("notification-hub")
    fi
    if echo "$req_lower" | grep -qE "レポート|report|分析|ダッシュボード|kpi"; then
        detected_features+=("analytics-dashboard")
        detected_features+=("reporting")
    fi
    if echo "$req_lower" | grep -qE "ワークフロー|承認|approval|フロー"; then
        detected_features+=("workflow")
    fi
    if echo "$req_lower" | grep -qE "監査|audit|コンプライアンス|ログ"; then
        detected_features+=("audit-trail")
    fi
    if echo "$req_lower" | grep -qE "連携|integration|slack|google|api"; then
        detected_features+=("system-integration")
    fi
    if echo "$req_lower" | grep -qE "インポート|エクスポート|csv|データ移行"; then
        detected_features+=("data-hub")
    fi

    # Admin panel is almost always needed for business apps
    if [[ ${#detected_domains[@]} -gt 0 ]]; then
        local has_admin=false
        for f in "${detected_features[@]}"; do [[ "$f" == "admin-panel" ]] && has_admin=true; done
        [[ "$has_admin" != "true" ]] && detected_features+=("admin-panel")
    fi

    AI2_ANALYSIS_RESULT="domains=${detected_domains[*]:-none};features=${detected_features[*]:-none};type=${project_type}"

    _ai2_ok "要件分析完了: ドメイン=${#detected_domains[@]}件, 機能=${#detected_features[@]}件"

    # Output analysis
    echo "domains:${detected_domains[*]:-}"
    echo "features:${detected_features[*]:-}"
    return 0
}

# =============================================================================
# _ai2_select_generators() - Select relevant system generators
# =============================================================================
_ai2_select_generators() {
    local domains="${1:-}"
    local features="${2:-}"

    AI2_SELECTED_GENERATORS=()

    _ai2_log "ジェネレーター選択開始"

    # Add domain generators
    for domain in $domains; do
        if [[ -n "${AI2_GENERATOR_MAP[$domain]:-}" ]]; then
            AI2_SELECTED_GENERATORS+=("$domain")
            _ai2_log "  +ドメイン: $domain"
        fi
    done

    # Add feature generators
    for feature in $features; do
        if [[ -n "${AI2_GENERATOR_MAP[$feature]:-}" ]]; then
            local already=false
            for sel in "${AI2_SELECTED_GENERATORS[@]}"; do [[ "$sel" == "$feature" ]] && already=true; done
            if [[ "$already" != "true" ]]; then
                AI2_SELECTED_GENERATORS+=("$feature")
                _ai2_log "  +機能: $feature"
            fi
        fi
    done

    _ai2_ok "選択完了: ${#AI2_SELECTED_GENERATORS[@]}ジェネレーター"
    return 0
}

# =============================================================================
# _ai2_orchestrate_generation() - Orchestrate multi-system generation
# =============================================================================
_ai2_orchestrate_generation() {
    local project_dir="${1:-.}"

    [[ ${#AI2_SELECTED_GENERATORS[@]} -eq 0 ]] && { _ai2_warn "選択済みジェネレーターなし"; return 1; }

    _ai2_log "統合生成開始: ${#AI2_SELECTED_GENERATORS[@]}システム"

    AI2_GENERATED_SYSTEMS=()
    local success=0
    local fail=0

    for gen_name in "${AI2_SELECTED_GENERATORS[@]}"; do
        local entry="${AI2_GENERATOR_MAP[$gen_name]:-}"
        [[ -z "$entry" ]] && continue

        local prefix="${entry%%|*}"

        _ai2_log "  生成中: ${gen_name} (prefix=${prefix})"

        # Call each generator's functions based on the prefix
        local gen_functions=()
        case "$gen_name" in
            admin-panel)
                gen_functions=("_apg_generate_admin_layout" "_apg_generate_user_management" "_apg_generate_settings_page") ;;
            customer-portal)
                gen_functions=("_cpg_generate_portal_layout" "_cpg_generate_dashboard" "_cpg_generate_support" "_cpg_generate_billing_page") ;;
            lp-marketing)
                gen_functions=("_lmg_generate_hero" "_lmg_generate_features" "_lmg_generate_pricing" "_lmg_generate_testimonials" "_lmg_generate_cta" "_lmg_generate_footer") ;;
            blog-cms)
                gen_functions=("_bcg_generate_article_model" "_bcg_generate_editor" "_bcg_generate_list_page" "_bcg_generate_article_page" "_bcg_generate_category_tags") ;;
            ecommerce)
                gen_functions=("_ee_generate_product_model" "_ee_generate_cart" "_ee_generate_checkout" "_ee_generate_order_management" "_ee_generate_inventory") ;;
            crm)
                gen_functions=("_crm_generate_contact_model" "_crm_generate_pipeline" "_crm_generate_activity_log" "_crm_generate_email_integration" "_crm_generate_reports") ;;
            project-management)
                gen_functions=("_pmg_generate_project_model" "_pmg_generate_task_board" "_pmg_generate_gantt" "_pmg_generate_time_tracking" "_pmg_generate_team_management") ;;
            hr-system)
                gen_functions=("_hsg_generate_employee_model" "_hsg_generate_attendance" "_hsg_generate_leave_management" "_hsg_generate_performance_review") ;;
            inventory)
                gen_functions=("_isg_generate_product_model" "_isg_generate_stock_tracking" "_isg_generate_purchase_order" "_isg_generate_barcode") ;;
            accounting)
                gen_functions=("_asg_generate_journal_entry" "_asg_generate_ledger" "_asg_generate_balance_sheet" "_asg_generate_invoice_system") ;;
            reservation)
                gen_functions=("_rsg_generate_resource_model" "_rsg_generate_availability" "_rsg_generate_booking_flow" "_rsg_generate_reminders") ;;
            chat)
                gen_functions=("_chsg_generate_message_model" "_chsg_generate_chat_ui" "_chsg_generate_websocket" "_chsg_generate_file_sharing" "_chsg_generate_read_receipts") ;;
            workflow)
                gen_functions=("_weg_generate_workflow_model" "_weg_generate_state_machine" "_weg_generate_approval_flow" "_weg_generate_triggers") ;;
            reporting)
                gen_functions=("_reg_generate_report_builder" "_reg_generate_charts" "_reg_generate_filters" "_reg_generate_export") ;;
            audit-trail)
                gen_functions=("_ats_generate_audit_model" "_ats_generate_middleware" "_ats_generate_viewer" "_ats_generate_compliance_report") ;;
            data-hub)
                gen_functions=("_dieh_generate_csv_import" "_dieh_generate_api_sync" "_dieh_generate_webhook_receiver" "_dieh_generate_export_scheduler") ;;
            notification-hub)
                gen_functions=("_nh_generate_multi_channel" "_nh_generate_preferences" "_nh_generate_templates" "_nh_generate_scheduler") ;;
            analytics-dashboard)
                gen_functions=("_adg_generate_kpi_tracker" "_adg_generate_funnel" "_adg_generate_cohort" "_adg_generate_prediction") ;;
            system-integration)
                gen_functions=("_sib_generate_slack_integration" "_sib_generate_google_integration" "_sib_generate_webhook_sender" "_sib_generate_api_connector") ;;
        esac

        local gen_success=true
        for fn in "${gen_functions[@]}"; do
            if type -t "$fn" &>/dev/null; then
                if "$fn" "$project_dir" 2>/dev/null; then
                    :
                else
                    _ai2_warn "    ${fn} 実行失敗"
                    gen_success=false
                fi
            else
                _ai2_warn "    ${fn} 未定義（モジュール未ロード？）"
                gen_success=false
            fi
        done

        if [[ "$gen_success" == "true" ]]; then
            AI2_GENERATED_SYSTEMS+=("$gen_name")
            success=$((success + 1))
        else
            fail=$((fail + 1))
        fi
    done

    _ai2_ok "統合生成完了: 成功=${success}, 失敗=${fail}"
    return 0
}

# =============================================================================
# _ai2_validate_integration() - Validate generated systems work together
# =============================================================================
_ai2_validate_integration() {
    local project_dir="${1:-.}"

    _ai2_log "統合検証開始"

    AI2_VALIDATION_RESULTS=()
    local pass=0
    local fail=0

    # 1. Check Prisma schema consistency
    local schema_file="${project_dir}/prisma/schema.prisma"
    if [[ -f "$schema_file" ]]; then
        local model_count
        model_count=$(grep -c "^model " "$schema_file" 2>/dev/null || echo "0")
        AI2_VALIDATION_RESULTS+=("${AI2_GREEN}PASS${AI2_NC} Prismaスキーマ: ${model_count}モデル")
        pass=$((pass + 1))

        # Check for duplicate model names
        local dupes
        dupes=$(grep "^model " "$schema_file" | sort | uniq -d | wc -l | tr -d ' ')
        if [[ "$dupes" -gt 0 ]]; then
            AI2_VALIDATION_RESULTS+=("${AI2_RED}FAIL${AI2_NC} 重複モデル: ${dupes}件")
            fail=$((fail + 1))
        else
            AI2_VALIDATION_RESULTS+=("${AI2_GREEN}PASS${AI2_NC} モデル重複なし")
            pass=$((pass + 1))
        fi
    fi

    # 2. Check component directory structure
    local comp_dir="${project_dir}/src/components"
    if [[ -d "$comp_dir" ]]; then
        local comp_count
        comp_count=$(find "$comp_dir" -name "*.tsx" 2>/dev/null | wc -l | tr -d ' ')
        AI2_VALIDATION_RESULTS+=("${AI2_GREEN}PASS${AI2_NC} コンポーネント: ${comp_count}ファイル")
        pass=$((pass + 1))
    fi

    # 3. Check API route structure
    local api_dir="${project_dir}/src/app/api"
    if [[ -d "$api_dir" ]]; then
        local route_count
        route_count=$(find "$api_dir" -name "route.ts" 2>/dev/null | wc -l | tr -d ' ')
        AI2_VALIDATION_RESULTS+=("${AI2_GREEN}PASS${AI2_NC} APIルート: ${route_count}エンドポイント")
        pass=$((pass + 1))
    fi

    # 4. Check for common import pattern consistency
    local lib_dir="${project_dir}/src/lib"
    if [[ -d "$lib_dir" ]]; then
        local lib_count
        lib_count=$(find "$lib_dir" -name "*.ts" 2>/dev/null | wc -l | tr -d ' ')
        AI2_VALIDATION_RESULTS+=("${AI2_GREEN}PASS${AI2_NC} ライブラリ: ${lib_count}ファイル")
        pass=$((pass + 1))
    fi

    # 5. Cross-system reference check
    for gen in "${AI2_GENERATED_SYSTEMS[@]}"; do
        AI2_VALIDATION_RESULTS+=("${AI2_GREEN}OK${AI2_NC} ${gen} 生成済み")
        pass=$((pass + 1))
    done

    _ai2_ok "統合検証完了: PASS=${pass}, FAIL=${fail}"
    return $fail
}

# =============================================================================
# _ai2_report() - Generate architecture report
# =============================================================================
_ai2_report() {
    local output_file="${1:-}"

    local report=""
    report+="# Architecture Integration Report v${AI2_VERSION}\n"
    report+="Generated: $(date '+%Y-%m-%d %H:%M:%S')\n\n"
    report+="## Selected Generators (${#AI2_SELECTED_GENERATORS[@]})\n"

    for gen in "${AI2_SELECTED_GENERATORS[@]}"; do
        local entry="${AI2_GENERATOR_MAP[$gen]:-}"
        local desc="${entry#*|}"
        desc="${desc%%|*}"
        report+="- **${gen}**: ${desc}\n"
    done

    report+="\n## Generated Systems (${#AI2_GENERATED_SYSTEMS[@]})\n"
    for sys in "${AI2_GENERATED_SYSTEMS[@]}"; do
        report+="- ${sys}\n"
    done

    report+="\n## Validation Results\n"
    for result in "${AI2_VALIDATION_RESULTS[@]}"; do
        # Strip color codes for file output
        local clean_result
        clean_result=$(echo -e "$result" | sed 's/\x1b\[[0-9;]*m//g')
        report+="- ${clean_result}\n"
    done

    if [[ -n "$output_file" ]]; then
        echo -e "$report" > "$output_file"
        _ai2_ok "レポート出力: ${output_file}"
    else
        echo -e "$report" >&2
    fi

    return 0
}

# =============================================================================
# Convenience: Full pipeline
# =============================================================================
_ai2_full_pipeline() {
    local requirements="${1:-}"
    local project_dir="${2:-.}"

    _ai2_log "フルパイプライン実行"

    # Step 1: Analyze
    local analysis
    analysis=$(_ai2_analyze_requirements "$requirements")
    local domains features
    domains=$(echo "$analysis" | grep "^domains:" | sed 's/^domains://')
    features=$(echo "$analysis" | grep "^features:" | sed 's/^features://')

    # Step 2: Select
    _ai2_select_generators "$domains" "$features"

    # Step 3: Generate
    _ai2_orchestrate_generation "$project_dir"

    # Step 4: Validate
    _ai2_validate_integration "$project_dir"

    # Step 5: Report
    _ai2_report "${project_dir}/architecture-report.md"

    _ai2_ok "フルパイプライン完了"
    return 0
}

# =============================================================================
# Module Registration
# =============================================================================
_mr_register \
    --name "architecture-integration" \
    --version "320.0" \
    --description "マスターアーキテクチャ統合（v301-v319全ジェネレーター統合オーケストレーション）" \
    --init "_ai2_init" \
    --report "ai2_report" \
    --score "ai2_score" \
    --enable-var "ENABLE_ARCHITECTURE_INTEGRATION" \
    --cli-flags "--arch-integration:--no-arch-integration" \
    --init-msg "ai2_init_message"
