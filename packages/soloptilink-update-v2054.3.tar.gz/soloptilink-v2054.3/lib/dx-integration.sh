#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v420.0 - DX Integration Hub
# =============================================================================
# Developer Experience (DX) 全モジュール (v401-v419) を統合し、
# プロジェクト特性に応じた最適DXモジュール選択・ワークフロー強化・
# 統合レポート生成を行うハブモジュール。
#
# Functions:
#   _dxi_init                - 初期化・DXモジュール一括セットアップ
#   _dxi_select_dx_modules   - プロジェクト分析→最適DXモジュール選択
#   _dxi_enhance_workflow    - ビルドフローにDX機能を注入
#   _dxi_report              - 統合レポート出力
#   _dxi_score               - 統合スコア(0-100)
#
# All globals use the DXI_ prefix.
# =============================================================================

[[ -n "${_DX_INTEGRATION_LOADED:-}" ]] && return 0
_DX_INTEGRATION_LOADED=1

declare -g DXI_VERSION="420.0"
declare -g DXI_INITIALIZED=false
declare -g DXI_STORE_DIR=""
declare -g DXI_MODULES_SELECTED=0
declare -g DXI_ENHANCEMENTS_APPLIED=0
declare -g DXI_TOTAL_DX_SCORE=0

# DX Module registry: module_name → "version:description:init_function:enabled"
declare -g -A _DXI_DX_MODULES=()
declare -g -A _DXI_MODULE_SCORES=()   # module_name → score
declare -g -A _DXI_MODULE_STATUS=()   # module_name → active|inactive|error
declare -g -a _DXI_SELECTED_MODULES=()
declare -g -a _DXI_ENHANCEMENT_LOG=()

# =============================================================================
_dxi_init() {
    local project_dir="${PROJECT_DIR:-.}"
    DXI_STORE_DIR="${project_dir}/.soloptilink/dx-hub"
    mkdir -p "${DXI_STORE_DIR}/reports" "${DXI_STORE_DIR}/selections"

    # Register all DX modules
    _DXI_DX_MODULES["prompt-engineering-studio"]="401:プロンプト設計・テスト・バージョン管理:_pes_init"
    _DXI_DX_MODULES["natural-language-to-sql"]="402:自然言語SQL生成:_nlsql_init"
    _DXI_DX_MODULES["natural-language-to-api"]="403:自然言語API呼び出し生成:_nlapi_init"
    _DXI_DX_MODULES["voice-command-interface"]="404:音声コマンドUI生成:_vci_init"
    _DXI_DX_MODULES["sketch-to-code"]="405:ワイヤーフレーム→コード変換:_stc_init"
    _DXI_DX_MODULES["specification-to-system"]="406:仕様書→システム生成:_sts_init"
    _DXI_DX_MODULES["chat-driven-development"]="407:チャット駆動開発:_cdd_init"
    _DXI_DX_MODULES["live-preview-engine"]="408:リアルタイムプレビュー:_lpe_init"
    _DXI_DX_MODULES["collaborative-development"]="409:協調開発・競合解決:_cd2_init"
    _DXI_DX_MODULES["developer-analytics"]="410:開発生産性分析:_da_init"
    _DXI_DX_MODULES["smart-autocomplete"]="411:AI補完:_sac_init"
    _DXI_DX_MODULES["code-navigation-ai"]="412:AI支援コードナビ:_cna_init"
    _DXI_DX_MODULES["dependency-impact-preview"]="413:依存更新影響プレビュー:_dip_init"
    _DXI_DX_MODULES["performance-budget-monitor"]="414:パフォーマンス予算監視:_pbm_init"
    _DXI_DX_MODULES["technical-debt-tracker"]="415:技術的負債追跡:_tdt_init"
    _DXI_DX_MODULES["code-health-dashboard"]="416:コード健全性ダッシュボード:_chd_init"
    _DXI_DX_MODULES["smart-git-workflow"]="417:AI駆動Gitワークフロー:_sgw_init"
    _DXI_DX_MODULES["environment-parity-checker"]="418:環境一貫性チェック:_epc_init"
    _DXI_DX_MODULES["release-notes-generator"]="419:リリースノート自動生成:_rng_init"

    # Auto-initialize always-on modules
    local always_on="developer-analytics code-navigation-ai smart-autocomplete code-health-dashboard smart-git-workflow"
    for mod in $always_on; do
        local info="${_DXI_DX_MODULES[$mod]:-}"
        [[ -z "$info" ]] && continue
        local init_fn="${info##*:}"
        if type -t "$init_fn" &>/dev/null; then
            if $init_fn 2>/dev/null; then
                _DXI_MODULE_STATUS["$mod"]="active"
            else
                _DXI_MODULE_STATUS["$mod"]="error"
            fi
        else
            _DXI_MODULE_STATUS["$mod"]="inactive"
        fi
    done

    DXI_INITIALIZED=true
    return 0
}

# =============================================================================
# _dxi_select_dx_modules - Analyze project and select optimal DX modules
# =============================================================================
_dxi_select_dx_modules() {
    local project_dir="${1:-${PROJECT_DIR:-.}}"
    local mode="${2:-auto}"  # auto|all|minimal

    [[ "$DXI_INITIALIZED" != "true" ]] && { echo "ERROR: DXI not initialized" >&2; return 1; }

    _DXI_SELECTED_MODULES=()
    local selections=()

    if [[ "$mode" == "all" ]]; then
        for mod in "${!_DXI_DX_MODULES[@]}"; do
            selections+=("$mod")
        done
    elif [[ "$mode" == "minimal" ]]; then
        selections=("developer-analytics" "smart-git-workflow" "code-health-dashboard")
    else
        # Auto mode: analyze project characteristics

        # Always selected
        selections+=("developer-analytics" "smart-git-workflow" "code-health-dashboard" "smart-autocomplete" "code-navigation-ai")

        # Database present → NL-SQL
        if find "$project_dir" -name "schema.prisma" -not -path "*/node_modules/*" 2>/dev/null | head -1 | grep -q .; then
            selections+=("natural-language-to-sql")
        fi

        # API routes present → NL-API, API monitoring
        if find "$project_dir" -name "route.ts" -path "*/api/*" -not -path "*/node_modules/*" 2>/dev/null | head -1 | grep -q .; then
            selections+=("natural-language-to-api")
        fi

        # Multiple env files → env parity
        local env_count
        env_count=$(find "$project_dir" -name ".env*" -maxdepth 2 2>/dev/null | wc -l | tr -d ' ')
        if [[ $env_count -ge 2 ]]; then
            selections+=("environment-parity-checker")
        fi

        # Large codebase → debt tracker, performance
        local file_count
        file_count=$(find "$project_dir" \( -name "*.ts" -o -name "*.tsx" \) -not -path "*/node_modules/*" -not -path "*/.next/*" 2>/dev/null | wc -l | tr -d ' ')
        if [[ $file_count -gt 30 ]]; then
            selections+=("technical-debt-tracker" "performance-budget-monitor" "dependency-impact-preview")
        fi

        # Git repository → release notes
        if [[ -d "${project_dir}/.git" ]]; then
            selections+=("release-notes-generator")
        fi

        # Has build output → live preview
        if [[ -f "${project_dir}/package.json" ]]; then
            local has_dev
            has_dev=$(grep -c '"dev"' "${project_dir}/package.json" 2>/dev/null || echo "0")
            [[ $has_dev -gt 0 ]] && selections+=("live-preview-engine")
        fi

        # Frontend components → sketch-to-code
        if find "$project_dir" -name "*.tsx" -path "*/components/*" -not -path "*/node_modules/*" 2>/dev/null | head -1 | grep -q .; then
            selections+=("sketch-to-code")
        fi

        # Chat/AI features → chat-driven dev
        selections+=("chat-driven-development")

        # Prompt management
        selections+=("prompt-engineering-studio")

        # Collaborative → if multiple branches
        if [[ -d "${project_dir}/.git" ]]; then
            local branch_count
            branch_count=$(cd "$project_dir" && git branch -a 2>/dev/null | wc -l | tr -d ' ')
            [[ $branch_count -gt 3 ]] && selections+=("collaborative-development")
        fi

        # Specification available
        if find "$project_dir" -name "*.spec.md" -o -name "SPEC.md" -o -name "requirements.*" 2>/dev/null | head -1 | grep -q .; then
            selections+=("specification-to-system")
        fi
    fi

    # Deduplicate
    local -A seen=()
    for mod in "${selections[@]}"; do
        if [[ -z "${seen[$mod]:-}" ]]; then
            _DXI_SELECTED_MODULES+=("$mod")
            seen["$mod"]=1
        fi
    done

    DXI_MODULES_SELECTED=${#_DXI_SELECTED_MODULES[@]}

    # Initialize selected modules
    for mod in "${_DXI_SELECTED_MODULES[@]}"; do
        local info="${_DXI_DX_MODULES[$mod]:-}"
        [[ -z "$info" ]] && continue
        local init_fn="${info##*:}"
        if [[ "${_DXI_MODULE_STATUS[$mod]:-}" != "active" ]]; then
            if type -t "$init_fn" &>/dev/null; then
                if $init_fn 2>/dev/null; then
                    _DXI_MODULE_STATUS["$mod"]="active"
                else
                    _DXI_MODULE_STATUS["$mod"]="error"
                fi
            else
                _DXI_MODULE_STATUS["$mod"]="inactive"
            fi
        fi
    done

    # Save selection
    local timestamp
    timestamp=$(date +%s 2>/dev/null || echo "0")
    local selection_file="${DXI_STORE_DIR}/selections/selection_${timestamp}.json"
    echo "{\"mode\":\"${mode}\",\"selected\":${DXI_MODULES_SELECTED},\"modules\":[" > "$selection_file" 2>/dev/null
    local first=true
    for mod in "${_DXI_SELECTED_MODULES[@]}"; do
        [[ "$first" != "true" ]] && echo "," >> "$selection_file" 2>/dev/null
        echo "\"${mod}\"" >> "$selection_file" 2>/dev/null
        first=false
    done
    echo "]}" >> "$selection_file" 2>/dev/null

    cat <<SELEOF
{"mode":"${mode}","selected":${DXI_MODULES_SELECTED},"total_available":${#_DXI_DX_MODULES[@]}}
SELEOF

    echo "Selected DX modules:" >&2
    for mod in "${_DXI_SELECTED_MODULES[@]}"; do
        local version="${_DXI_DX_MODULES[$mod]%%:*}"
        local status="${_DXI_MODULE_STATUS[$mod]:-inactive}"
        echo "  v${version} ${mod} [${status}]" >&2
    done

    return 0
}

# =============================================================================
# _dxi_enhance_workflow - Inject DX enhancements into build workflow
# =============================================================================
_dxi_enhance_workflow() {
    local phase="$1"  # pre-build|build|post-build|test|deploy
    local project_dir="${2:-${PROJECT_DIR:-.}}"

    [[ "$DXI_INITIALIZED" != "true" ]] && { echo "ERROR: DXI not initialized" >&2; return 1; }
    DXI_ENHANCEMENTS_APPLIED=$((DXI_ENHANCEMENTS_APPLIED + 1))

    local enhancements_applied=0

    case "$phase" in
        pre-build)
            # Env parity check
            if _dxi_is_active "environment-parity-checker"; then
                echo "  [DX] Running environment parity check..." >&2
                _epc_detect_drift "$project_dir" >/dev/null 2>&1 && enhancements_applied=$((enhancements_applied + 1))
            fi

            # Dependency impact analysis
            if _dxi_is_active "dependency-impact-preview"; then
                echo "  [DX] Checking dependency impacts..." >&2
                enhancements_applied=$((enhancements_applied + 1))
            fi

            # Technical debt scan
            if _dxi_is_active "technical-debt-tracker"; then
                echo "  [DX] Scanning technical debt..." >&2
                _tdt_scan_debt "$project_dir" >/dev/null 2>&1 && enhancements_applied=$((enhancements_applied + 1))
            fi

            # Smart autocomplete learning
            if _dxi_is_active "smart-autocomplete"; then
                echo "  [DX] Learning project patterns..." >&2
                _sac_learn_patterns "$project_dir" >/dev/null 2>&1 && enhancements_applied=$((enhancements_applied + 1))
            fi
            ;;

        build)
            # Code navigation index
            if _dxi_is_active "code-navigation-ai"; then
                echo "  [DX] Building code navigation index..." >&2
                _cna_generate_map "$project_dir" "json" >/dev/null 2>&1 && enhancements_applied=$((enhancements_applied + 1))
            fi

            # Developer analytics tracking
            if _dxi_is_active "developer-analytics"; then
                _da_track_productivity "build" "phase_build"
                enhancements_applied=$((enhancements_applied + 1))
            fi

            # Prompt optimization
            if _dxi_is_active "prompt-engineering-studio"; then
                echo "  [DX] Prompt studio active..." >&2
                enhancements_applied=$((enhancements_applied + 1))
            fi
            ;;

        post-build)
            # Performance budget check
            if _dxi_is_active "performance-budget-monitor"; then
                echo "  [DX] Checking performance budgets..." >&2
                _pbm_continuous_check "$project_dir" >/dev/null 2>&1 && enhancements_applied=$((enhancements_applied + 1))
            fi

            # Code health aggregation
            if _dxi_is_active "code-health-dashboard"; then
                echo "  [DX] Aggregating code health..." >&2
                _chd_aggregate_metrics "$project_dir" >/dev/null 2>&1 && enhancements_applied=$((enhancements_applied + 1))
            fi

            # Live preview start
            if _dxi_is_active "live-preview-engine"; then
                echo "  [DX] Live preview available..." >&2
                enhancements_applied=$((enhancements_applied + 1))
            fi
            ;;

        test)
            # Track test events
            if _dxi_is_active "developer-analytics"; then
                _da_track_productivity "test_run" "phase_test"
                enhancements_applied=$((enhancements_applied + 1))
            fi
            ;;

        deploy)
            # Generate release notes
            if _dxi_is_active "release-notes-generator"; then
                echo "  [DX] Generating release notes..." >&2
                _rng_analyze_commits "$project_dir" >/dev/null 2>&1 && enhancements_applied=$((enhancements_applied + 1))
            fi

            # Smart git: commit message suggestion
            if _dxi_is_active "smart-git-workflow"; then
                echo "  [DX] Smart Git workflow active..." >&2
                enhancements_applied=$((enhancements_applied + 1))
            fi
            ;;
    esac

    _DXI_ENHANCEMENT_LOG+=("${phase}:${enhancements_applied}")
    echo "${enhancements_applied}"
    return 0
}

# =============================================================================
# Helper: Check if a DX module is active
# =============================================================================
_dxi_is_active() {
    local module_name="$1"
    [[ "${_DXI_MODULE_STATUS[$module_name]:-}" == "active" ]]
}

# =============================================================================
# _dxi_collect_scores - Collect scores from all active DX modules
# =============================================================================
_dxi_collect_scores() {
    local total_score=0
    local active_count=0

    # Collect from each module's score function
    local -A score_fns=(
        ["prompt-engineering-studio"]="_pes_score"
        ["natural-language-to-sql"]="_nlsql_score"
        ["natural-language-to-api"]="_nlapi_score"
        ["voice-command-interface"]="_vci_score"
        ["sketch-to-code"]="_stc_score"
        ["specification-to-system"]="_sts_score"
        ["chat-driven-development"]="_cdd_score"
        ["live-preview-engine"]="_lpe_score"
        ["collaborative-development"]="_cd2_score"
        ["developer-analytics"]="_da_score"
        ["smart-autocomplete"]="_sac_score"
        ["code-navigation-ai"]="_cna_score"
        ["dependency-impact-preview"]="_dip_score"
        ["performance-budget-monitor"]="_pbm_score"
        ["technical-debt-tracker"]="_tdt_score"
        ["code-health-dashboard"]="_chd_score"
        ["smart-git-workflow"]="_sgw_score"
        ["environment-parity-checker"]="_epc_score"
        ["release-notes-generator"]="_rng_score"
    )

    for mod in "${_DXI_SELECTED_MODULES[@]}"; do
        local score_fn="${score_fns[$mod]:-}"
        if [[ -n "$score_fn" ]] && type -t "$score_fn" &>/dev/null; then
            local score
            score=$($score_fn 2>/dev/null || echo "0")
            _DXI_MODULE_SCORES["$mod"]=$score
            total_score=$((total_score + score))
            active_count=$((active_count + 1))
        fi
    done

    if [[ $active_count -gt 0 ]]; then
        DXI_TOTAL_DX_SCORE=$((total_score / active_count))
    else
        DXI_TOTAL_DX_SCORE=0
    fi

    echo "$DXI_TOTAL_DX_SCORE"
}

# =============================================================================
# Report / Score
# =============================================================================
_dxi_report() {
    echo -e "\n  ${BOLD:-}=== DX Integration Hub v${DXI_VERSION} ===${NC:-}"
    echo -e "  Available Modules   : ${#_DXI_DX_MODULES[@]}"
    echo -e "  Selected Modules    : ${DXI_MODULES_SELECTED}"
    echo -e "  Enhancements Applied: ${DXI_ENHANCEMENTS_APPLIED}"

    _dxi_collect_scores >/dev/null
    echo -e "  DX Score            : ${DXI_TOTAL_DX_SCORE}/100"

    echo -e "\n  Module Status:"
    for mod in "${_DXI_SELECTED_MODULES[@]}"; do
        local status="${_DXI_MODULE_STATUS[$mod]:-inactive}"
        local version="${_DXI_DX_MODULES[$mod]%%:*}"
        local score="${_DXI_MODULE_SCORES[$mod]:-N/A}"
        local status_icon="?"
        case "$status" in
            active) status_icon="${GREEN:-}OK${NC:-}" ;;
            inactive) status_icon="${YELLOW:-}--${NC:-}" ;;
            error) status_icon="${RED:-}ER${NC:-}" ;;
        esac
        echo -e "    [${status_icon}] v${version} ${mod} (score: ${score})"
    done

    echo -e "\n  Enhancement Log:"
    for entry in "${_DXI_ENHANCEMENT_LOG[@]}"; do
        local phase="${entry%%:*}"
        local count="${entry##*:}"
        echo -e "    ${phase}: ${count} enhancements"
    done
}

_dxi_score() {
    _dxi_collect_scores >/dev/null
    local score=30
    [[ "$DXI_INITIALIZED" == "true" ]] && score=$((score + 15))
    [[ $DXI_MODULES_SELECTED -gt 5 ]] && score=$((score + 15))
    [[ $DXI_ENHANCEMENTS_APPLIED -gt 0 ]] && score=$((score + 15))
    [[ $DXI_TOTAL_DX_SCORE -ge 50 ]] && score=$((score + 15))
    [[ $DXI_TOTAL_DX_SCORE -ge 70 ]] && score=$((score + 10))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "dx-integration" \
        --version "420.0" \
        --description "Developer Experience全モジュール統合ハブ (v401-v419)" \
        --init "_dxi_init" \
        --report "_dxi_report" \
        --score "_dxi_score" \
        --enable-var "ENABLE_DXI" \
        --cli-flags "--dx-integration:--no-dx-integration"
fi

# v2003.1: source時のexit codeを確実に0にする
true
