#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v242.0 - Accessibility Enforcer
# =============================================================================
# WCAG 2.1 AA 準拠を強制するアクセシビリティ検証エンジン。
# ARIA属性、キーボードナビゲーション、コントラスト比、スクリーンリーダー対応を検査。
#
# 機能:
#   - ARIA 属性の網羅性チェック
#   - キーボードナビゲーション対応検証
#   - 色コントラスト比チェック（WCAG AA: 4.5:1）
#   - スクリーンリーダー互換性検証
#   - 自動修正コード生成
#   - WCAG 2.1 AA コンプライアンスレポート
#
# 全globals: AE_ prefix
# =============================================================================

[[ -n "${_ACCESSIBILITY_ENFORCER_LOADED:-}" ]] && return 0
_ACCESSIBILITY_ENFORCER_LOADED=1

# =============================================================================
# State
# =============================================================================
declare -g AE_VERSION="242.0"
declare -g AE_INITIALIZED=false
declare -g AE_TOTAL_CHECKS=0
declare -g AE_TOTAL_ISSUES=0
declare -g AE_FIXES_GENERATED=0
declare -g AE_PROJECT_DIR=""
declare -g AE_LOG_PREFIX="[AE]"
declare -g AE_ARIA_ISSUES=0
declare -g AE_KEYBOARD_ISSUES=0
declare -g AE_CONTRAST_ISSUES=0
declare -g AE_SR_ISSUES=0

# =============================================================================
# ログユーティリティ
# =============================================================================
_ae_log() { echo -e "  ${CLR_CYAN:-\033[0;36m}${AE_LOG_PREFIX}${CLR_NC:-\033[0m} $*" >&2; }
_ae_success() { echo -e "  ${CLR_GREEN:-\033[0;32m}${AE_LOG_PREFIX} OK${CLR_NC:-\033[0m} $*" >&2; }
_ae_warn() { echo -e "  ${CLR_YELLOW:-\033[0;33m}${AE_LOG_PREFIX} WARN${CLR_NC:-\033[0m} $*" >&2; }
_ae_error() { echo -e "  ${CLR_RED:-\033[0;31m}${AE_LOG_PREFIX} ERROR${CLR_NC:-\033[0m} $*" >&2; }

# =============================================================================
# 初期化
# =============================================================================
ae_init() {
    AE_INITIALIZED=true
    AE_TOTAL_CHECKS=0
    AE_TOTAL_ISSUES=0
    AE_FIXES_GENERATED=0
    AE_ARIA_ISSUES=0
    AE_KEYBOARD_ISSUES=0
    AE_CONTRAST_ISSUES=0
    AE_SR_ISSUES=0
    AE_PROJECT_DIR="${PROJECT_DIR:-.}"
    return 0
}

# =============================================================================
# ファイル収集ヘルパー
# =============================================================================
_ae_collect_files() {
    local project_dir="${1:-${AE_PROJECT_DIR}}"
    local files=()
    if [[ -d "$project_dir" ]]; then
        while IFS= read -r -d '' f; do
            files+=("$f")
        done < <(find "$project_dir" -type f \( -name '*.tsx' -o -name '*.jsx' \) \
            -not -path '*/node_modules/*' -not -path '*/.next/*' \
            -not -path '*/dist/*' -not -path '*/.git/*' -print0 2>/dev/null)
    fi
    printf '%s\0' "${files[@]}"
}

# =============================================================================
# ARIA 属性チェック
# =============================================================================
# 全てのインタラクティブ要素に適切な ARIA 属性が付与されているか検査。
# button, input, select, textarea, a[href], [role] を対象。
#
# 使い方: _ae_check_aria <project_dir>
# =============================================================================
_ae_check_aria() {
    local project_dir="${1:-${AE_PROJECT_DIR}}"
    local issues=0
    local checked=0

    [[ "$AE_INITIALIZED" != "true" ]] && { _ae_error "未初期化"; return 1; }

    _ae_log "ARIA属性チェック開始: ${project_dir}"

    local files=()
    while IFS= read -r -d '' f; do
        [[ -n "$f" ]] && files+=("$f")
    done < <(_ae_collect_files "$project_dir")

    for f in "${files[@]}"; do
        checked=$((checked + 1))
        local bn
        bn=$(basename "$f")

        # 1. img タグに alt 属性がないか
        if grep -qP '<img\b(?![^>]*\balt\b)' "$f" 2>/dev/null; then
            _ae_warn "${bn}: <img> に alt 属性なし"
            issues=$((issues + 1))
        fi

        # 2. button に aria-label なし（テキストコンテンツもない場合）
        if grep -qP '<button[^>]*>\s*<(?:svg|img|span class)' "$f" 2>/dev/null; then
            if ! grep -qP '<button[^>]*aria-label' "$f" 2>/dev/null; then
                _ae_warn "${bn}: アイコンのみの <button> に aria-label なし"
                issues=$((issues + 1))
            fi
        fi

        # 3. input に label/aria-label がないか
        if grep -qP '<input\b' "$f" 2>/dev/null; then
            if ! grep -qP '(?:aria-label|aria-labelledby|<label)' "$f" 2>/dev/null; then
                _ae_warn "${bn}: <input> に label/aria-label なし（要確認）"
                issues=$((issues + 1))
            fi
        fi

        # 4. role 属性付き要素の必須 ARIA プロパティ
        if grep -qP 'role="dialog"' "$f" 2>/dev/null; then
            if ! grep -qP 'aria-(?:label|labelledby)' "$f" 2>/dev/null; then
                _ae_warn "${bn}: role=dialog に aria-label/labelledby なし"
                issues=$((issues + 1))
            fi
        fi

        # 5. tabIndex が不正な値
        if grep -qP 'tabIndex=\{[2-9]' "$f" 2>/dev/null; then
            _ae_warn "${bn}: tabIndex > 1 は非推奨"
            issues=$((issues + 1))
        fi

        # 6. div/span に onClick だけで role/tabIndex なし
        if grep -qP '<(?:div|span)[^>]*onClick' "$f" 2>/dev/null; then
            if ! grep -qP '<(?:div|span)[^>]*(?:role=|tabIndex)' "$f" 2>/dev/null; then
                _ae_warn "${bn}: クリック可能な div/span に role/tabIndex なし"
                issues=$((issues + 1))
            fi
        fi

        AE_TOTAL_CHECKS=$((AE_TOTAL_CHECKS + 1))
    done

    AE_ARIA_ISSUES=$((AE_ARIA_ISSUES + issues))
    AE_TOTAL_ISSUES=$((AE_TOTAL_ISSUES + issues))

    if [[ $issues -eq 0 ]]; then
        _ae_success "ARIA チェック完了: ${checked}ファイル、問題なし"
    else
        _ae_warn "ARIA チェック完了: ${checked}ファイル、${issues}件の問題"
    fi

    echo "$issues"
    return 0
}

# =============================================================================
# キーボードナビゲーションチェック
# =============================================================================
# キーボードのみで全機能にアクセスできるか検査。
# Tab/Enter/Escape/Arrow キーの処理を確認。
#
# 使い方: _ae_check_keyboard <project_dir>
# =============================================================================
_ae_check_keyboard() {
    local project_dir="${1:-${AE_PROJECT_DIR}}"
    local issues=0
    local checked=0

    [[ "$AE_INITIALIZED" != "true" ]] && { _ae_error "未初期化"; return 1; }

    _ae_log "キーボードナビゲーションチェック開始"

    local files=()
    while IFS= read -r -d '' f; do
        [[ -n "$f" ]] && files+=("$f")
    done < <(_ae_collect_files "$project_dir")

    for f in "${files[@]}"; do
        checked=$((checked + 1))
        local bn
        bn=$(basename "$f")

        # 1. onMouseDown/onMouseUp without onKeyDown
        if grep -qP 'onMouse(?:Down|Up|Enter)' "$f" 2>/dev/null; then
            if ! grep -qP 'onKey(?:Down|Up|Press)' "$f" 2>/dev/null; then
                _ae_warn "${bn}: マウスイベントのみ（キーボード対応なし）"
                issues=$((issues + 1))
            fi
        fi

        # 2. カスタムドロップダウン/メニューの Arrow キー処理
        if grep -qP '(?:dropdown|menu|listbox|combobox)' "$f" 2>/dev/null; then
            if ! grep -qP 'Arrow(?:Down|Up|Left|Right)' "$f" 2>/dev/null; then
                _ae_warn "${bn}: ドロップダウン/メニューに矢印キーハンドラなし"
                issues=$((issues + 1))
            fi
        fi

        # 3. モーダル/ダイアログの Escape キー処理
        if grep -qP '(?:modal|dialog|Dialog)' "$f" 2>/dev/null; then
            if ! grep -qP 'Escape' "$f" 2>/dev/null; then
                _ae_warn "${bn}: モーダルに Escape キーハンドラなし"
                issues=$((issues + 1))
            fi
        fi

        # 4. フォーカストラップ（モーダル内）
        if grep -qP '(?:Modal|Dialog)' "$f" 2>/dev/null; then
            if ! grep -qP '(?:focusTrap|FocusTrap|focus-trap|createFocusTrap|useFocusTrap)' "$f" 2>/dev/null; then
                # ライブラリ側で自動処理の可能性もあるので INFO レベル
                _ae_log "${bn}: フォーカストラップ未検出（ライブラリ側で対応の可能性）"
            fi
        fi

        # 5. outline: none (フォーカス表示の削除)
        if grep -qP 'outline:\s*(?:none|0)' "$f" 2>/dev/null; then
            if ! grep -qP 'focus-visible' "$f" 2>/dev/null; then
                _ae_warn "${bn}: outline:none でフォーカス表示が消えている（focus-visible 代替必須）"
                issues=$((issues + 1))
            fi
        fi

        AE_TOTAL_CHECKS=$((AE_TOTAL_CHECKS + 1))
    done

    AE_KEYBOARD_ISSUES=$((AE_KEYBOARD_ISSUES + issues))
    AE_TOTAL_ISSUES=$((AE_TOTAL_ISSUES + issues))

    if [[ $issues -eq 0 ]]; then
        _ae_success "キーボードチェック完了: ${checked}ファイル、問題なし"
    else
        _ae_warn "キーボードチェック完了: ${checked}ファイル、${issues}件の問題"
    fi

    echo "$issues"
    return 0
}

# =============================================================================
# 色コントラスト比チェック
# =============================================================================
# ハードコードされた色の組み合わせを検出し、WCAG AA 4.5:1 を満たすか確認。
# 静的解析のみ（実行時レンダリングは対象外）。
#
# 使い方: _ae_check_contrast <project_dir>
# =============================================================================
_ae_check_contrast() {
    local project_dir="${1:-${AE_PROJECT_DIR}}"
    local issues=0
    local checked=0

    [[ "$AE_INITIALIZED" != "true" ]] && { _ae_error "未初期化"; return 1; }

    _ae_log "色コントラストチェック開始"

    # CSS ファイルを検査
    local css_files=()
    if [[ -d "$project_dir" ]]; then
        while IFS= read -r -d '' f; do
            css_files+=("$f")
        done < <(find "$project_dir" -type f \( -name '*.css' -o -name '*.scss' \) \
            -not -path '*/node_modules/*' -not -path '*/.next/*' -print0 2>/dev/null)
    fi

    for f in "${css_files[@]}"; do
        checked=$((checked + 1))
        local bn
        bn=$(basename "$f")

        # 1. 薄いグレーテキスト（コントラスト不足の可能性）
        if grep -qP 'color:\s*#(?:ccc|ddd|eee|bbb|aaa)' "$f" 2>/dev/null; then
            _ae_warn "${bn}: 薄い色のテキスト（コントラスト比不足の可能性）"
            issues=$((issues + 1))
        fi

        # 2. 白背景に薄い色
        if grep -qP 'color:\s*#(?:9[0-9a-f]{5}|a[0-9a-f]{5}|b[0-9a-f]{5})' "$f" 2>/dev/null; then
            _ae_warn "${bn}: グレー系テキスト色（白背景でコントラスト不足の可能性）"
            issues=$((issues + 1))
        fi

        AE_TOTAL_CHECKS=$((AE_TOTAL_CHECKS + 1))
    done

    # TSX/JSX の Tailwind クラスも検査
    local tsx_files=()
    while IFS= read -r -d '' f; do
        [[ -n "$f" ]] && tsx_files+=("$f")
    done < <(_ae_collect_files "$project_dir")

    for f in "${tsx_files[@]}"; do
        checked=$((checked + 1))
        local bn
        bn=$(basename "$f")

        # Tailwind の薄い色クラス
        if grep -qP 'text-gray-(?:300|400)(?:\s|")' "$f" 2>/dev/null; then
            if grep -qP 'bg-white' "$f" 2>/dev/null; then
                _ae_warn "${bn}: text-gray-300/400 on bg-white（コントラスト比不足）"
                issues=$((issues + 1))
            fi
        fi

        # placeholder の色が薄すぎる
        if grep -qP 'placeholder-gray-(?:200|300)' "$f" 2>/dev/null; then
            _ae_warn "${bn}: placeholder色が薄すぎる（WCAG AA 非準拠の可能性）"
            issues=$((issues + 1))
        fi

        AE_TOTAL_CHECKS=$((AE_TOTAL_CHECKS + 1))
    done

    AE_CONTRAST_ISSUES=$((AE_CONTRAST_ISSUES + issues))
    AE_TOTAL_ISSUES=$((AE_TOTAL_ISSUES + issues))

    if [[ $issues -eq 0 ]]; then
        _ae_success "コントラストチェック完了: ${checked}ファイル、問題なし"
    else
        _ae_warn "コントラストチェック完了: ${checked}ファイル、${issues}件の問題"
    fi

    echo "$issues"
    return 0
}

# =============================================================================
# スクリーンリーダー互換性チェック
# =============================================================================
# スクリーンリーダーで正しく読み上げられるか検査。
# ランドマーク、見出し構造、ライブリージョン、非表示テキストを確認。
#
# 使い方: _ae_check_screen_reader <project_dir>
# =============================================================================
_ae_check_screen_reader() {
    local project_dir="${1:-${AE_PROJECT_DIR}}"
    local issues=0
    local checked=0

    [[ "$AE_INITIALIZED" != "true" ]] && { _ae_error "未初期化"; return 1; }

    _ae_log "スクリーンリーダー互換性チェック開始"

    local files=()
    while IFS= read -r -d '' f; do
        [[ -n "$f" ]] && files+=("$f")
    done < <(_ae_collect_files "$project_dir")

    # ランドマーク検出（プロジェクト全体で1回）
    local has_main=false has_nav=false has_header=false
    for f in "${files[@]}"; do
        grep -qP '<main\b|role="main"' "$f" 2>/dev/null && has_main=true
        grep -qP '<nav\b|role="navigation"' "$f" 2>/dev/null && has_nav=true
        grep -qP '<header\b|role="banner"' "$f" 2>/dev/null && has_header=true
    done

    if [[ "$has_main" != "true" && ${#files[@]} -gt 3 ]]; then
        _ae_warn "プロジェクト全体: <main> ランドマークなし"
        issues=$((issues + 1))
    fi

    for f in "${files[@]}"; do
        checked=$((checked + 1))
        local bn
        bn=$(basename "$f")

        # 1. h1 の後に h3（h2 をスキップ）
        local headings
        headings=$(grep -oP '<h[1-6]' "$f" 2>/dev/null | sed 's/<h//' | tr '\n' ' ')
        if [[ -n "$headings" ]]; then
            local prev=0
            for h in $headings; do
                if [[ $prev -gt 0 && $((h - prev)) -gt 1 ]]; then
                    _ae_warn "${bn}: 見出しレベルスキップ（h${prev} → h${h}）"
                    issues=$((issues + 1))
                    break
                fi
                prev=$h
            done
        fi

        # 2. aria-live がフォーム送信結果に使われているか
        if grep -qP '(?:onSubmit|handleSubmit)' "$f" 2>/dev/null; then
            if ! grep -qP 'aria-live|role="(?:alert|status)"' "$f" 2>/dev/null; then
                _ae_warn "${bn}: フォーム送信結果に aria-live/role=alert なし"
                issues=$((issues + 1))
            fi
        fi

        # 3. sr-only テキスト（スクリーンリーダーのみ表示テキスト）
        if grep -qP '<svg\b' "$f" 2>/dev/null; then
            if ! grep -qP '(?:sr-only|aria-hidden|aria-label|<title)' "$f" 2>/dev/null; then
                _ae_warn "${bn}: SVG にアクセシブルな代替テキストなし"
                issues=$((issues + 1))
            fi
        fi

        # 4. 非表示コンテンツの aria-hidden
        if grep -qP 'display:\s*none|visibility:\s*hidden' "$f" 2>/dev/null; then
            # 適切に aria-hidden されているか確認
            :
        fi

        # 5. テーブルに caption/th がないか
        if grep -qP '<table\b' "$f" 2>/dev/null; then
            if ! grep -qP '(?:<caption|<th\b|aria-label)' "$f" 2>/dev/null; then
                _ae_warn "${bn}: <table> に caption/th なし"
                issues=$((issues + 1))
            fi
        fi

        AE_TOTAL_CHECKS=$((AE_TOTAL_CHECKS + 1))
    done

    AE_SR_ISSUES=$((AE_SR_ISSUES + issues))
    AE_TOTAL_ISSUES=$((AE_TOTAL_ISSUES + issues))

    if [[ $issues -eq 0 ]]; then
        _ae_success "スクリーンリーダーチェック完了: ${checked}ファイル、問題なし"
    else
        _ae_warn "スクリーンリーダーチェック完了: ${checked}ファイル、${issues}件の問題"
    fi

    echo "$issues"
    return 0
}

# =============================================================================
# アクセシビリティ修正コード生成
# =============================================================================
# 検出された問題に対する修正コードを生成する。
#
# 使い方: _ae_generate_fixes <output_file>
# =============================================================================
_ae_generate_fixes() {
    local output_file="${1:-${AE_PROJECT_DIR}/a11y-fixes.md}"

    [[ "$AE_INITIALIZED" != "true" ]] && { _ae_error "未初期化"; return 1; }

    _ae_log "アクセシビリティ修正ガイド生成中"

    mkdir -p "$(dirname "$output_file")" 2>/dev/null || true

    cat > "$output_file" <<'A11Y_FIXES'
# Accessibility Fixes Guide (SoloptiLinkAI v242.0)

## ARIA 属性修正

### img タグの alt 属性
```tsx
// Before (NG)
<img src="/logo.png" />

// After (OK)
<img src="/logo.png" alt="SoloptiLinkAI ロゴ" />

// 装飾的な画像の場合
<img src="/decoration.png" alt="" role="presentation" />
```

### アイコンボタンの aria-label
```tsx
// Before (NG)
<button onClick={handleDelete}><TrashIcon /></button>

// After (OK)
<button onClick={handleDelete} aria-label="削除">
  <TrashIcon aria-hidden="true" />
</button>
```

### クリック可能な div
```tsx
// Before (NG)
<div onClick={handleClick}>...</div>

// After (OK)
<div role="button" tabIndex={0} onClick={handleClick}
     onKeyDown={(e) => e.key === 'Enter' && handleClick()}>
  ...
</div>

// Best: button 要素を使う
<button onClick={handleClick}>...</button>
```

## キーボードナビゲーション修正

### Escape キーでモーダルを閉じる
```tsx
useEffect(() => {
  const handleEscape = (e: KeyboardEvent) => {
    if (e.key === 'Escape') onClose();
  };
  document.addEventListener('keydown', handleEscape);
  return () => document.removeEventListener('keydown', handleEscape);
}, [onClose]);
```

### ドロップダウンの矢印キー操作
```tsx
const handleKeyDown = (e: React.KeyboardEvent) => {
  switch (e.key) {
    case 'ArrowDown':
      e.preventDefault();
      setActiveIndex(prev => Math.min(prev + 1, items.length - 1));
      break;
    case 'ArrowUp':
      e.preventDefault();
      setActiveIndex(prev => Math.max(prev - 1, 0));
      break;
    case 'Enter':
      e.preventDefault();
      selectItem(activeIndex);
      break;
    case 'Escape':
      setIsOpen(false);
      break;
  }
};
```

## コントラスト修正

### Tailwind CSS でのコントラスト確保
```tsx
// Before (NG) - contrast ratio ~3:1
<p className="text-gray-400 bg-white">...</p>

// After (OK) - contrast ratio ~7:1
<p className="text-gray-700 bg-white">...</p>
```

## スクリーンリーダー修正

### フォーム送信結果のライブリージョン
```tsx
<div aria-live="polite" role="status">
  {submitStatus === 'success' && <p>保存しました</p>}
  {submitStatus === 'error' && <p role="alert">エラーが発生しました</p>}
</div>
```

### 見出しレベルの正しい順序
```tsx
// Before (NG)
<h1>ページタイトル</h1>
<h3>セクション</h3>  // h2 をスキップ

// After (OK)
<h1>ページタイトル</h1>
<h2>セクション</h2>
<h3>サブセクション</h3>
```
A11Y_FIXES

    if [[ -f "$output_file" ]]; then
        AE_FIXES_GENERATED=$((AE_FIXES_GENERATED + 1))
        _ae_success "修正ガイド生成完了: ${output_file}"
        return 0
    else
        _ae_error "修正ガイド生成失敗"
        return 1
    fi
}

# =============================================================================
# WCAG 2.1 AA コンプライアンスレポート
# =============================================================================
_ae_generate_a11y_report() {
    local output_file="${1:-${AE_PROJECT_DIR}/a11y-report.json}"

    [[ "$AE_INITIALIZED" != "true" ]] && { _ae_error "未初期化"; return 1; }

    _ae_log "WCAG 2.1 AA コンプライアンスレポート生成中"

    local total_issues=$((AE_ARIA_ISSUES + AE_KEYBOARD_ISSUES + AE_CONTRAST_ISSUES + AE_SR_ISSUES))
    local compliance_score=100
    [[ $total_issues -gt 0 ]] && compliance_score=$((100 - (total_issues * 5)))
    [[ $compliance_score -lt 0 ]] && compliance_score=0

    local status="PASS"
    [[ $compliance_score -lt 70 ]] && status="FAIL"
    [[ $compliance_score -ge 70 && $compliance_score -lt 90 ]] && status="WARN"

    mkdir -p "$(dirname "$output_file")" 2>/dev/null || true

    cat > "$output_file" <<EOF
{
  "report": "WCAG 2.1 AA Compliance Report",
  "version": "${AE_VERSION}",
  "timestamp": "$(date -u +%Y-%m-%dT%H:%M:%SZ)",
  "status": "${status}",
  "compliance_score": ${compliance_score},
  "total_checks": ${AE_TOTAL_CHECKS},
  "total_issues": ${total_issues},
  "categories": {
    "aria": { "issues": ${AE_ARIA_ISSUES}, "criteria": "4.1.2 Name, Role, Value" },
    "keyboard": { "issues": ${AE_KEYBOARD_ISSUES}, "criteria": "2.1.1 Keyboard" },
    "contrast": { "issues": ${AE_CONTRAST_ISSUES}, "criteria": "1.4.3 Contrast (Minimum)" },
    "screen_reader": { "issues": ${AE_SR_ISSUES}, "criteria": "1.3.1 Info and Relationships" }
  },
  "fixes_generated": ${AE_FIXES_GENERATED}
}
EOF

    if [[ -f "$output_file" ]]; then
        _ae_success "レポート生成完了: ${output_file} (スコア: ${compliance_score}/100 - ${status})"
        return 0
    else
        _ae_error "レポート生成失敗"
        return 1
    fi
}

# =============================================================================
# フルチェック実行
# =============================================================================
_ae_run_full_check() {
    local project_dir="${1:-${AE_PROJECT_DIR}}"

    [[ "$AE_INITIALIZED" != "true" ]] && { _ae_error "未初期化"; return 1; }

    _ae_log "=== アクセシビリティフルチェック開始 ==="

    _ae_check_aria "$project_dir"
    _ae_check_keyboard "$project_dir"
    _ae_check_contrast "$project_dir"
    _ae_check_screen_reader "$project_dir"
    _ae_generate_fixes "${project_dir}/a11y-fixes.md"
    _ae_generate_a11y_report "${project_dir}/a11y-report.json"

    _ae_success "=== フルチェック完了: 総問題数 ${AE_TOTAL_ISSUES} ==="
    return 0
}

# =============================================================================
# プロンプト注入
# =============================================================================
_ae_inject_prompt() {
    cat <<'PROMPT'
## [AE] アクセシビリティ必須ルール (WCAG 2.1 AA)

### ARIA
- 全ての <img> に alt 属性必須（装飾的 → alt="" role="presentation"）
- アイコンボタンは aria-label 必須
- クリック可能な div/span → button 要素に変更、または role+tabIndex+onKeyDown
- role="dialog" には aria-label/labelledby 必須
- tabIndex は 0 または -1 のみ使用

### キーボード
- 全インタラクティブ要素が Tab でフォーカス可能
- Enter/Space で実行可能
- モーダルは Escape で閉じる
- ドロップダウンは矢印キーで操作可能
- フォーカス表示（outline）を削除しない

### コントラスト
- テキスト: 4.5:1 以上（AA基準）
- 大テキスト: 3:1 以上
- UI コンポーネント: 3:1 以上

### スクリーンリーダー
- 見出しレベルをスキップしない（h1→h2→h3）
- フォーム送信結果に aria-live="polite" or role="alert"
- SVG に aria-hidden="true" + 親要素に aria-label
PROMPT
}

# =============================================================================
# レポート
# =============================================================================
ae_report() {
    echo -e "\n  ${BOLD:-}--- Accessibility Enforcer v${AE_VERSION} ---${NC:-}"
    echo -e "  総チェック数    : ${AE_TOTAL_CHECKS}"
    echo -e "  ARIA問題        : ${AE_ARIA_ISSUES}"
    echo -e "  キーボード問題  : ${AE_KEYBOARD_ISSUES}"
    echo -e "  コントラスト問題: ${AE_CONTRAST_ISSUES}"
    echo -e "  SR問題          : ${AE_SR_ISSUES}"
    echo -e "  修正ガイド生成  : ${AE_FIXES_GENERATED}"
}

ae_report_json() {
    cat <<EOF
{"module":"accessibility-enforcer","version":"${AE_VERSION}","total_checks":${AE_TOTAL_CHECKS},"aria_issues":${AE_ARIA_ISSUES},"keyboard_issues":${AE_KEYBOARD_ISSUES},"contrast_issues":${AE_CONTRAST_ISSUES},"sr_issues":${AE_SR_ISSUES},"fixes_generated":${AE_FIXES_GENERATED}}
EOF
}

ae_score() {
    if [[ "$AE_INITIALIZED" != "true" ]]; then echo 0; return; fi
    local score=100
    score=$((score - AE_TOTAL_ISSUES * 5))
    [[ $score -lt 0 ]] && score=0
    echo "$score"
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "accessibility-enforcer" \
        --version "242.0" \
        --description "WCAG 2.1 AA 準拠アクセシビリティ検証エンジン" \
        --init "ae_init" \
        --report "ae_report" \
        --score "ae_score" \
        --enable-var "ENABLE_ACCESSIBILITY_ENFORCER" \
        --cli-flags "--a11y-enforce:--no-a11y-enforce"
fi

# v2003.1: source時のexit codeを確実に0にする
true
