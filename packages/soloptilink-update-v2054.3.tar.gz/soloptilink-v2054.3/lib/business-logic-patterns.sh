#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v383.0 - Business Logic Patterns
# =============================================================================
# 汎用ビジネスロジックパターン生成エンジン。
# 承認フロー/ステートマシン/締切管理/通知連携等の汎用パターンを自動生成。
#
# All globals use the BLP_ prefix.
# =============================================================================

[[ -n "${_BUSINESS_LOGIC_PATTERNS_LOADED:-}" ]] && return 0
_BUSINESS_LOGIC_PATTERNS_LOADED=1

declare -g BLP_VERSION="383.0"
declare -g BLP_INITIALIZED=false
declare -g BLP_GENERATED_COUNT=0
declare -g BLP_APPROVAL_GENERATED=false
declare -g BLP_STATE_MACHINE_GENERATED=false
declare -g BLP_DEADLINE_GENERATED=false
declare -g BLP_NOTIFICATION_GENERATED=false
declare -g ENABLE_BLP="${ENABLE_BLP:-true}"

_blp_init() {
    BLP_INITIALIZED=true
    BLP_GENERATED_COUNT=0
    return 0
}

_blp_generate_all() {
    local project_dir="${1:-.}"
    [[ "$BLP_INITIALIZED" != "true" ]] && _blp_init

    echo -e "  ${CYAN:-\033[0;36m}[BLP]${NC:-\033[0m} ビジネスロジックパターン生成開始..." >&2

    _blp_generate_approval_flow "$project_dir"
    _blp_generate_status_machine "$project_dir"
    _blp_generate_deadline "$project_dir"
    _blp_generate_notification_trigger "$project_dir"

    echo -e "  ${GREEN:-\033[0;32m}[BLP]${NC:-\033[0m} ビジネスロジック生成完了: ${BLP_GENERATED_COUNT}件" >&2
    return 0
}

# =============================================================================
# 承認フロー
# =============================================================================
_blp_generate_approval_flow() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [BLP-APPROVAL] 承認フローテンプレート

### Schema
```prisma
model ApprovalRequest {
  id          String   @id @default(cuid())
  type        String
  requesterId String
  title       String
  description String?
  data        Json
  status      String   @default("pending")
  currentStep Int      @default(0)
  steps       ApprovalStep[]
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
  @@index([requesterId])
  @@index([status])
}

model ApprovalStep {
  id          String   @id @default(cuid())
  requestId   String
  request     ApprovalRequest @relation(fields: [requestId], references: [id])
  stepOrder   Int
  approverId  String
  status      String   @default("pending")
  comment     String?
  decidedAt   DateTime?
  @@index([approverId, status])
  @@unique([requestId, stepOrder])
}
```

### Approval Service
```typescript
export class ApprovalService {
  async createRequest(data: { type: string; requesterId: string; title: string; data: any; approverIds: string[] }) {
    return prisma.approvalRequest.create({
      data: {
        type: data.type, requesterId: data.requesterId, title: data.title, data: data.data,
        steps: { create: data.approverIds.map((id, i) => ({ stepOrder: i, approverId: id })) },
      },
    });
  }

  async approve(requestId: string, approverId: string, comment?: string) {
    const request = await prisma.approvalRequest.findUniqueOrThrow({
      where: { id: requestId }, include: { steps: { orderBy: { stepOrder: 'asc' } } },
    });
    const currentStep = request.steps[request.currentStep];
    if (!currentStep || currentStep.approverId !== approverId) throw new Error('承認権限がありません');

    await prisma.approvalStep.update({
      where: { id: currentStep.id }, data: { status: 'approved', comment, decidedAt: new Date() },
    });

    const isLastStep = request.currentStep >= request.steps.length - 1;
    await prisma.approvalRequest.update({
      where: { id: requestId },
      data: { status: isLastStep ? 'approved' : 'pending', currentStep: { increment: isLastStep ? 0 : 1 } },
    });

    if (isLastStep) await this.onApproved(request);
    else await this.notifyNextApprover(request.steps[request.currentStep + 1]);
  }

  async reject(requestId: string, approverId: string, comment: string) {
    await prisma.$transaction([
      prisma.approvalStep.updateMany({
        where: { requestId, approverId, status: 'pending' },
        data: { status: 'rejected', comment, decidedAt: new Date() },
      }),
      prisma.approvalRequest.update({ where: { id: requestId }, data: { status: 'rejected' } }),
    ]);
  }

  private async onApproved(request: ApprovalRequest) { /* ビジネスロジック実行 */ }
  private async notifyNextApprover(step: ApprovalStep) { /* 通知送信 */ }
}
```
TEMPLATE

    BLP_APPROVAL_GENERATED=true
    BLP_GENERATED_COUNT=$((BLP_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# ステートマシン
# =============================================================================
_blp_generate_status_machine() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [BLP-STATE] ステートマシンテンプレート

```typescript
type StateTransition<S extends string, A extends string> = {
  from: S; action: A; to: S;
  guard?: (context: any) => boolean;
  onTransition?: (context: any) => Promise<void>;
};

export class StateMachine<S extends string, A extends string> {
  constructor(
    private transitions: StateTransition<S, A>[],
    private currentState: S,
  ) {}

  canPerform(action: A, context?: any): boolean {
    return this.transitions.some(t =>
      t.from === this.currentState && t.action === action && (!t.guard || t.guard(context))
    );
  }

  async perform(action: A, context?: any): Promise<S> {
    const transition = this.transitions.find(t =>
      t.from === this.currentState && t.action === action && (!t.guard || t.guard(context))
    );
    if (!transition) throw new Error(`Invalid: ${this.currentState} + ${action}`);
    if (transition.onTransition) await transition.onTransition(context);
    this.currentState = transition.to;
    return this.currentState;
  }

  getAvailableActions(context?: any): A[] {
    return [...new Set(
      this.transitions.filter(t => t.from === this.currentState && (!t.guard || t.guard(context))).map(t => t.action)
    )];
  }

  get state(): S { return this.currentState; }
}

// 使用例: 注文ステータス
const orderMachine = new StateMachine<OrderStatus, OrderAction>([
  { from: 'pending', action: 'confirm', to: 'confirmed' },
  { from: 'confirmed', action: 'ship', to: 'shipped' },
  { from: 'shipped', action: 'deliver', to: 'delivered' },
  { from: 'pending', action: 'cancel', to: 'cancelled' },
  { from: 'confirmed', action: 'cancel', to: 'cancelled', guard: (ctx) => !ctx.isShipped },
], 'pending');
```
TEMPLATE

    BLP_STATE_MACHINE_GENERATED=true
    BLP_GENERATED_COUNT=$((BLP_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# 締切管理
# =============================================================================
_blp_generate_deadline() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [BLP-DEADLINE] 締切管理テンプレート

```typescript
interface DeadlineRule {
  name: string;
  calculateDueDate: (startDate: Date) => Date;
  reminderDays: number[];
  escalationDays: number;
}

const DEADLINE_RULES: Record<string, DeadlineRule> = {
  invoice_payment: { name: '請求書支払期限', calculateDueDate: (d) => addDays(d, 30), reminderDays: [7, 3, 1], escalationDays: 0 },
  contract_review: { name: '契約書レビュー', calculateDueDate: (d) => addBusinessDays(d, 5), reminderDays: [2, 1], escalationDays: -1 },
  task_completion: { name: 'タスク完了期限', calculateDueDate: (d) => addDays(d, 14), reminderDays: [3, 1], escalationDays: 0 },
};

export class DeadlineManager {
  async scheduleReminders(entityId: string, entityType: string, ruleKey: string, startDate: Date) {
    const rule = DEADLINE_RULES[ruleKey];
    if (!rule) throw new Error(`Unknown deadline rule: ${ruleKey}`);

    const dueDate = rule.calculateDueDate(startDate);
    const reminders = rule.reminderDays.map(days => ({
      entityId, entityType, triggerAt: subDays(dueDate, days),
      message: `${rule.name}まであと${days}日です`,
    }));

    await prisma.reminder.createMany({ data: reminders });
    return { dueDate, reminderCount: reminders.length };
  }

  async checkOverdue(): Promise<OverdueItem[]> {
    return prisma.deadline.findMany({
      where: { dueDate: { lt: new Date() }, status: { not: 'completed' } },
      include: { assignee: true },
      orderBy: { dueDate: 'asc' },
    });
  }
}

function addBusinessDays(date: Date, days: number): Date {
  let result = new Date(date);
  let added = 0;
  while (added < days) {
    result = addDays(result, 1);
    if (result.getDay() !== 0 && result.getDay() !== 6) added++;
  }
  return result;
}
```
TEMPLATE

    BLP_DEADLINE_GENERATED=true
    BLP_GENERATED_COUNT=$((BLP_GENERATED_COUNT + 1))
    return 0
}

# =============================================================================
# 通知トリガー
# =============================================================================
_blp_generate_notification_trigger() {
    local project_dir="${1:-.}"

    cat <<'TEMPLATE'
## [BLP-NOTIFY] 通知トリガーテンプレート

```typescript
type NotificationChannel = 'email' | 'push' | 'in_app' | 'slack';

interface NotificationTrigger {
  event: string;
  channels: NotificationChannel[];
  template: string;
  recipients: (context: any) => Promise<string[]>;
}

const TRIGGERS: NotificationTrigger[] = [
  { event: 'approval_requested', channels: ['email', 'in_app'], template: 'approval_request',
    recipients: async (ctx) => [ctx.approverId] },
  { event: 'order_placed', channels: ['email'], template: 'order_confirmation',
    recipients: async (ctx) => [ctx.customerId] },
  { event: 'deadline_approaching', channels: ['email', 'push', 'in_app'], template: 'deadline_reminder',
    recipients: async (ctx) => [ctx.assigneeId] },
];

export class NotificationDispatcher {
  async dispatch(event: string, context: any) {
    const triggers = TRIGGERS.filter(t => t.event === event);
    for (const trigger of triggers) {
      const recipientIds = await trigger.recipients(context);
      for (const recipientId of recipientIds) {
        for (const channel of trigger.channels) {
          await this.send(channel, recipientId, trigger.template, context);
        }
      }
    }
  }

  private async send(channel: NotificationChannel, recipientId: string, template: string, context: any) {
    await prisma.notification.create({
      data: { recipientId, channel, template, context: JSON.stringify(context), status: 'pending' },
    });
  }
}
```
TEMPLATE

    BLP_NOTIFICATION_GENERATED=true
    BLP_GENERATED_COUNT=$((BLP_GENERATED_COUNT + 1))
    return 0
}

_blp_report() {
    echo -e "\n  ${BOLD:-\033[1m}=== Business Logic Patterns v${BLP_VERSION} ===${NC:-\033[0m}"
    echo -e "  生成パターン数     : ${BLP_GENERATED_COUNT}"
    echo -e "  承認フロー         : ${BLP_APPROVAL_GENERATED}"
    echo -e "  ステートマシン     : ${BLP_STATE_MACHINE_GENERATED}"
    echo -e "  締切管理           : ${BLP_DEADLINE_GENERATED}"
    echo -e "  通知トリガー       : ${BLP_NOTIFICATION_GENERATED}"
}

_blp_score() {
    local score=30
    [[ "$BLP_INITIALIZED" == "true" ]] && score=$((score + 10))
    [[ "$BLP_APPROVAL_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$BLP_STATE_MACHINE_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$BLP_DEADLINE_GENERATED" == "true" ]] && score=$((score + 15))
    [[ "$BLP_NOTIFICATION_GENERATED" == "true" ]] && score=$((score + 15))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

_mr_register \
    --name "business-logic-patterns" \
    --version "383.0" \
    --description "ビジネスロジックパターン（承認フロー/ステートマシン/締切/通知）" \
    --init "_blp_init" \
    --report "_blp_report" \
    --score "_blp_score" \
    --enable-var "ENABLE_BLP" \
    --cli-flags "--biz-patterns:--no-biz-patterns"
