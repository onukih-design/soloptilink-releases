#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v140.0 - File Upload Engine
# =============================================================================
# ファイルアップロード基盤×S3/R2/GCS統合×画像処理×CDN配信
#
# 機能:
#   - マルチストレージ抽象化（Local / S3 / R2 / GCS）
#   - Multipartアップロード（サイズ制限・MIME検証・Magic Number検査）
#   - 画像処理（リサイズ・サムネイル・フォーマット変換 via sharp）
#   - React DnDアップロードコンポーネント（プログレスバー・プレビュー）
#   - S3 Presigned URL（クライアント直接アップロード）
#   - ウイルススキャン代替（ファイルタイプ検証・Magic Number）
#   - CDN/静的アセット配信設定
#
# 全globals: FUE_ prefix
# =============================================================================

[[ -n "${_FUE_LOADED:-}" ]] && return 0; _FUE_LOADED=1

# =============================================================================
# State
# =============================================================================
FUE_VERSION="140.0"
FUE_GENERATED=0
FUE_ERRORS=0
FUE_PHASE="upload"
FUE_FILES_CREATED=()

# =============================================================================
# Helper: ファイル書き込み
# =============================================================================
_fue_write_file() {
    local filepath="$1"
    local content="$2"
    local dir
    dir="$(dirname "$filepath")"
    mkdir -p "$dir" 2>/dev/null
    echo "$content" > "$filepath"
    if [[ -f "$filepath" ]]; then
        FUE_FILES_CREATED+=("$filepath")
        FUE_GENERATED=$((FUE_GENERATED + 1))
        echo -e "  ${GREEN:-\033[0;32m}[FUE]${NC:-\033[0m} Created: ${filepath##*/}"
    else
        FUE_ERRORS=$((FUE_ERRORS + 1))
        echo -e "  ${RED:-\033[0;31m}[FUE]${NC:-\033[0m} Failed: ${filepath##*/}"
    fi
}

# =============================================================================
# 初期化
# =============================================================================
fu_init() {
    FUE_GENERATED=0
    FUE_ERRORS=0
    FUE_FILES_CREATED=()
    echo -e "  ${GREEN:-\033[0;32m}OK${NC:-\033[0m} File Upload Engine v${FUE_VERSION}"
    return 0
}

# =============================================================================
# Upload Service 抽象化 (Local / S3 / R2 / GCS)
# =============================================================================
fu_generate_upload_service() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local storage="${2:-local}"
    local target="${project_dir}/src/lib/upload-service.ts"

    _fue_write_file "$target" "$(cat <<'TYPESCRIPT'
import { z } from 'zod';
import { randomUUID } from 'crypto';
import path from 'path';
import fs from 'fs/promises';

// ---------------------------------------------------------------------------
// Storage Provider Abstraction
// ---------------------------------------------------------------------------
export const UploadConfigSchema = z.object({
  provider: z.enum(['local', 's3', 'r2', 'gcs']).default('local'),
  maxFileSize: z.number().default(10 * 1024 * 1024), // 10MB
  allowedMimeTypes: z.array(z.string()).default([
    'image/jpeg', 'image/png', 'image/webp', 'image/gif',
    'application/pdf', 'text/csv',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
  ]),
  localDir: z.string().default('uploads'),
  s3Bucket: z.string().optional(),
  s3Region: z.string().default('ap-northeast-1'),
  r2AccountId: z.string().optional(),
  r2Bucket: z.string().optional(),
  gcsBucket: z.string().optional(),
  cdnBaseUrl: z.string().optional(),
});

export type UploadConfig = z.infer<typeof UploadConfigSchema>;

export interface UploadResult {
  id: string;
  key: string;
  url: string;
  size: number;
  mimeType: string;
  originalName: string;
  createdAt: Date;
}

export interface StorageProvider {
  upload(buffer: Buffer, key: string, mimeType: string): Promise<string>;
  delete(key: string): Promise<void>;
  getSignedUrl(key: string, expiresIn?: number): Promise<string>;
}

// ---------------------------------------------------------------------------
// Local Storage Provider
// ---------------------------------------------------------------------------
class LocalStorageProvider implements StorageProvider {
  constructor(private baseDir: string) {}

  async upload(buffer: Buffer, key: string, _mimeType: string): Promise<string> {
    const fullPath = path.join(this.baseDir, key);
    await fs.mkdir(path.dirname(fullPath), { recursive: true });
    await fs.writeFile(fullPath, buffer);
    return `/uploads/${key}`;
  }

  async delete(key: string): Promise<void> {
    const fullPath = path.join(this.baseDir, key);
    await fs.unlink(fullPath).catch(() => {});
  }

  async getSignedUrl(key: string, _expiresIn?: number): Promise<string> {
    return `/uploads/${key}`;
  }
}

// ---------------------------------------------------------------------------
// S3 Storage Provider
// ---------------------------------------------------------------------------
class S3StorageProvider implements StorageProvider {
  private bucket: string;
  private region: string;

  constructor(bucket: string, region: string) {
    this.bucket = bucket;
    this.region = region;
  }

  async upload(buffer: Buffer, key: string, mimeType: string): Promise<string> {
    const { S3Client, PutObjectCommand } = await import('@aws-sdk/client-s3');
    const client = new S3Client({ region: this.region });
    await client.send(new PutObjectCommand({
      Bucket: this.bucket,
      Key: key,
      Body: buffer,
      ContentType: mimeType,
    }));
    return `https://${this.bucket}.s3.${this.region}.amazonaws.com/${key}`;
  }

  async delete(key: string): Promise<void> {
    const { S3Client, DeleteObjectCommand } = await import('@aws-sdk/client-s3');
    const client = new S3Client({ region: this.region });
    await client.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
  }

  async getSignedUrl(key: string, expiresIn = 3600): Promise<string> {
    const { S3Client, GetObjectCommand } = await import('@aws-sdk/client-s3');
    const { getSignedUrl } = await import('@aws-sdk/s3-request-presigner');
    const client = new S3Client({ region: this.region });
    return getSignedUrl(client, new GetObjectCommand({ Bucket: this.bucket, Key: key }), { expiresIn });
  }
}

// ---------------------------------------------------------------------------
// R2 Storage Provider (Cloudflare)
// ---------------------------------------------------------------------------
class R2StorageProvider implements StorageProvider {
  private accountId: string;
  private bucket: string;

  constructor(accountId: string, bucket: string) {
    this.accountId = accountId;
    this.bucket = bucket;
  }

  async upload(buffer: Buffer, key: string, mimeType: string): Promise<string> {
    const { S3Client, PutObjectCommand } = await import('@aws-sdk/client-s3');
    const client = new S3Client({
      region: 'auto',
      endpoint: `https://${this.accountId}.r2.cloudflarestorage.com`,
    });
    await client.send(new PutObjectCommand({
      Bucket: this.bucket, Key: key, Body: buffer, ContentType: mimeType,
    }));
    return `https://${this.bucket}.r2.dev/${key}`;
  }

  async delete(key: string): Promise<void> {
    const { S3Client, DeleteObjectCommand } = await import('@aws-sdk/client-s3');
    const client = new S3Client({
      region: 'auto',
      endpoint: `https://${this.accountId}.r2.cloudflarestorage.com`,
    });
    await client.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
  }

  async getSignedUrl(key: string): Promise<string> {
    return `https://${this.bucket}.r2.dev/${key}`;
  }
}

// ---------------------------------------------------------------------------
// Factory
// ---------------------------------------------------------------------------
export function createStorageProvider(config: UploadConfig): StorageProvider {
  switch (config.provider) {
    case 's3':
      if (!config.s3Bucket) throw new Error('S3 bucket is required');
      return new S3StorageProvider(config.s3Bucket, config.s3Region);
    case 'r2':
      if (!config.r2AccountId || !config.r2Bucket) throw new Error('R2 config is required');
      return new R2StorageProvider(config.r2AccountId, config.r2Bucket);
    case 'gcs':
      throw new Error('GCS provider not yet implemented - use S3-compatible API');
    default:
      return new LocalStorageProvider(config.localDir);
  }
}

// ---------------------------------------------------------------------------
// Upload Service (orchestrates validation + storage + DB)
// ---------------------------------------------------------------------------
export class UploadService {
  private provider: StorageProvider;
  private config: UploadConfig;

  constructor(config: UploadConfig) {
    this.config = UploadConfigSchema.parse(config);
    this.provider = createStorageProvider(this.config);
  }

  async upload(file: { buffer: Buffer; originalName: string; mimeType: string }): Promise<UploadResult> {
    // Validate size
    if (file.buffer.length > this.config.maxFileSize) {
      throw new Error(`File too large: ${file.buffer.length} bytes (max: ${this.config.maxFileSize})`);
    }
    // Validate MIME type
    if (!this.config.allowedMimeTypes.includes(file.mimeType)) {
      throw new Error(`File type not allowed: ${file.mimeType}`);
    }

    const id = randomUUID();
    const ext = path.extname(file.originalName) || '.bin';
    const key = `${new Date().toISOString().slice(0,10)}/${id}${ext}`;
    const url = await this.provider.upload(file.buffer, key, file.mimeType);

    return {
      id, key, url,
      size: file.buffer.length,
      mimeType: file.mimeType,
      originalName: file.originalName,
      createdAt: new Date(),
    };
  }

  async delete(key: string): Promise<void> {
    await this.provider.delete(key);
  }

  async getSignedUrl(key: string, expiresIn?: number): Promise<string> {
    return this.provider.getSignedUrl(key, expiresIn);
  }
}
TYPESCRIPT
)"
}

# =============================================================================
# Multipart Upload API Endpoint
# =============================================================================
fu_generate_upload_api() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/app/api/upload/route.ts"

    _fue_write_file "$target" "$(cat <<'TYPESCRIPT'
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { UploadService, UploadConfigSchema } from '@/lib/upload-service';
import { validateFileType } from '@/lib/file-validator';
import { prisma } from '@/lib/prisma';
import { getSession } from '@/lib/auth';

const uploadConfig = UploadConfigSchema.parse({
  provider: process.env.UPLOAD_PROVIDER || 'local',
  s3Bucket: process.env.S3_BUCKET,
  s3Region: process.env.S3_REGION,
  r2AccountId: process.env.R2_ACCOUNT_ID,
  r2Bucket: process.env.R2_BUCKET,
  maxFileSize: Number(process.env.MAX_FILE_SIZE) || 10 * 1024 * 1024,
});

const uploadService = new UploadService(uploadConfig);

export async function POST(request: NextRequest) {
  try {
    const session = await getSession(request);
    if (!session?.userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const formData = await request.formData();
    const file = formData.get('file') as File | null;
    if (!file) {
      return NextResponse.json({ error: 'No file provided' }, { status: 400 });
    }

    const buffer = Buffer.from(await file.arrayBuffer());

    // Magic number validation
    const typeCheck = validateFileType(buffer, file.name);
    if (!typeCheck.valid) {
      return NextResponse.json({ error: `Invalid file: ${typeCheck.reason}` }, { status: 400 });
    }

    const result = await uploadService.upload({
      buffer,
      originalName: file.name,
      mimeType: typeCheck.mimeType || file.type,
    });

    // Persist to DB
    const record = await prisma.file.create({
      data: {
        id: result.id,
        key: result.key,
        url: result.url,
        size: result.size,
        mimeType: result.mimeType,
        originalName: result.originalName,
        uploadedBy: session.userId,
      },
    });

    return NextResponse.json({ data: record }, { status: 201 });
  } catch (error: any) {
    console.error('[Upload API]', error);
    if (error.message?.includes('too large') || error.message?.includes('not allowed')) {
      return NextResponse.json({ error: error.message }, { status: 400 });
    }
    return NextResponse.json({ error: 'Upload failed' }, { status: 500 });
  }
}

export async function DELETE(request: NextRequest) {
  try {
    const session = await getSession(request);
    if (!session?.userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const { searchParams } = new URL(request.url);
    const fileId = searchParams.get('id');
    if (!fileId) {
      return NextResponse.json({ error: 'File ID required' }, { status: 400 });
    }

    const file = await prisma.file.findUnique({ where: { id: fileId } });
    if (!file) {
      return NextResponse.json({ error: 'File not found' }, { status: 404 });
    }
    if (file.uploadedBy !== session.userId && session.role !== 'admin') {
      return NextResponse.json({ error: 'Forbidden' }, { status: 403 });
    }

    await uploadService.delete(file.key);
    await prisma.file.delete({ where: { id: fileId } });

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('[Upload API DELETE]', error);
    return NextResponse.json({ error: 'Delete failed' }, { status: 500 });
  }
}
TYPESCRIPT
)"
}

# =============================================================================
# Image Processing (sharp)
# =============================================================================
fu_generate_image_processing() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/lib/image-processor.ts"

    _fue_write_file "$target" "$(cat <<'TYPESCRIPT'
import sharp from 'sharp';

export interface ImageProcessingOptions {
  width?: number;
  height?: number;
  quality?: number;
  format?: 'jpeg' | 'png' | 'webp' | 'avif';
  fit?: 'cover' | 'contain' | 'fill' | 'inside' | 'outside';
}

export interface ThumbnailSpec {
  suffix: string;
  width: number;
  height: number;
  quality?: number;
}

const DEFAULT_THUMBNAILS: ThumbnailSpec[] = [
  { suffix: '_thumb', width: 150, height: 150, quality: 80 },
  { suffix: '_medium', width: 600, height: 600, quality: 85 },
  { suffix: '_large', width: 1200, height: 1200, quality: 90 },
];

export async function processImage(
  buffer: Buffer,
  options: ImageProcessingOptions = {}
): Promise<Buffer> {
  let pipeline = sharp(buffer);

  if (options.width || options.height) {
    pipeline = pipeline.resize({
      width: options.width,
      height: options.height,
      fit: options.fit || 'inside',
      withoutEnlargement: true,
    });
  }

  const format = options.format || 'webp';
  const quality = options.quality || 85;

  switch (format) {
    case 'jpeg':
      pipeline = pipeline.jpeg({ quality, mozjpeg: true });
      break;
    case 'png':
      pipeline = pipeline.png({ quality, compressionLevel: 9 });
      break;
    case 'webp':
      pipeline = pipeline.webp({ quality });
      break;
    case 'avif':
      pipeline = pipeline.avif({ quality });
      break;
  }

  return pipeline.toBuffer();
}

export async function generateThumbnails(
  buffer: Buffer,
  specs: ThumbnailSpec[] = DEFAULT_THUMBNAILS
): Promise<Map<string, Buffer>> {
  const results = new Map<string, Buffer>();

  await Promise.all(
    specs.map(async (spec) => {
      const processed = await processImage(buffer, {
        width: spec.width,
        height: spec.height,
        quality: spec.quality || 80,
        format: 'webp',
        fit: 'cover',
      });
      results.set(spec.suffix, processed);
    })
  );

  return results;
}

export async function getImageMetadata(buffer: Buffer) {
  const metadata = await sharp(buffer).metadata();
  return {
    width: metadata.width || 0,
    height: metadata.height || 0,
    format: metadata.format || 'unknown',
    size: buffer.length,
    hasAlpha: metadata.hasAlpha || false,
    isAnimated: (metadata.pages || 1) > 1,
  };
}

export async function convertFormat(
  buffer: Buffer,
  targetFormat: 'jpeg' | 'png' | 'webp' | 'avif',
  quality = 85
): Promise<Buffer> {
  return processImage(buffer, { format: targetFormat, quality });
}
TYPESCRIPT
)"
}

# =============================================================================
# React Upload Component (DnD + Progress + Preview)
# =============================================================================
fu_generate_upload_component() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/components/FileUpload.tsx"

    _fue_write_file "$target" "$(cat <<'TYPESCRIPT'
'use client';

import { useState, useCallback, useRef } from 'react';

interface UploadedFile {
  id: string;
  url: string;
  originalName: string;
  size: number;
  mimeType: string;
}

interface FileUploadProps {
  onUpload?: (file: UploadedFile) => void;
  onError?: (error: string) => void;
  accept?: string;
  maxSize?: number; // bytes
  multiple?: boolean;
  className?: string;
}

interface UploadProgress {
  fileName: string;
  progress: number;
  status: 'pending' | 'uploading' | 'done' | 'error';
  error?: string;
  preview?: string;
}

export default function FileUpload({
  onUpload,
  onError,
  accept = 'image/*,.pdf,.csv',
  maxSize = 10 * 1024 * 1024,
  multiple = false,
  className = '',
}: FileUploadProps) {
  const [uploads, setUploads] = useState<UploadProgress[]>([]);
  const [isDragging, setIsDragging] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const handleFiles = useCallback(async (files: FileList | File[]) => {
    const fileArray = Array.from(files);

    // Initialize progress
    const initial: UploadProgress[] = fileArray.map((f) => ({
      fileName: f.name,
      progress: 0,
      status: 'pending',
      preview: f.type.startsWith('image/') ? URL.createObjectURL(f) : undefined,
    }));
    setUploads((prev) => [...prev, ...initial]);

    for (let i = 0; i < fileArray.length; i++) {
      const file = fileArray[i];
      const idx = uploads.length + i;

      if (file.size > maxSize) {
        setUploads((prev) => {
          const next = [...prev];
          next[idx] = { ...next[idx], status: 'error', error: `File too large (max ${Math.round(maxSize / 1024 / 1024)}MB)` };
          return next;
        });
        onError?.(`${file.name} is too large`);
        continue;
      }

      setUploads((prev) => {
        const next = [...prev];
        next[idx] = { ...next[idx], status: 'uploading', progress: 10 };
        return next;
      });

      try {
        const formData = new FormData();
        formData.append('file', file);

        const response = await fetch('/api/upload', { method: 'POST', body: formData });

        if (!response.ok) {
          const err = await response.json().catch(() => ({ error: 'Upload failed' }));
          throw new Error(err.error || `HTTP ${response.status}`);
        }

        const result = await response.json();

        setUploads((prev) => {
          const next = [...prev];
          next[idx] = { ...next[idx], status: 'done', progress: 100 };
          return next;
        });

        onUpload?.(result.data);
      } catch (error: any) {
        setUploads((prev) => {
          const next = [...prev];
          next[idx] = { ...next[idx], status: 'error', error: error.message };
          return next;
        });
        onError?.(error.message);
      }
    }
  }, [uploads.length, maxSize, onUpload, onError]);

  const onDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  }, []);

  const onDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const onDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    if (e.dataTransfer.files.length > 0) {
      handleFiles(e.dataTransfer.files);
    }
  }, [handleFiles]);

  const removeUpload = (idx: number) => {
    setUploads((prev) => prev.filter((_, i) => i !== idx));
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes}B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)}KB`;
    return `${(bytes / 1024 / 1024).toFixed(1)}MB`;
  };

  return (
    <div className={className}>
      <div
        onDragOver={onDragOver}
        onDragLeave={onDragLeave}
        onDrop={onDrop}
        onClick={() => inputRef.current?.click()}
        className={`
          border-2 border-dashed rounded-lg p-8 text-center cursor-pointer transition-colors
          ${isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'}
        `}
      >
        <svg className="mx-auto h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
        </svg>
        <p className="mt-2 text-sm text-gray-600">
          ドラッグ&ドロップ または <span className="text-blue-600 underline">ファイルを選択</span>
        </p>
        <p className="mt-1 text-xs text-gray-500">最大 {formatSize(maxSize)}</p>
        <input
          ref={inputRef}
          type="file"
          accept={accept}
          multiple={multiple}
          onChange={(e) => e.target.files && handleFiles(e.target.files)}
          className="hidden"
        />
      </div>

      {uploads.length > 0 && (
        <ul className="mt-4 space-y-2">
          {uploads.map((u, idx) => (
            <li key={idx} className="flex items-center gap-3 p-2 bg-gray-50 rounded">
              {u.preview && (
                <img src={u.preview} alt="" className="w-10 h-10 object-cover rounded" />
              )}
              <div className="flex-1 min-w-0">
                <p className="text-sm truncate">{u.fileName}</p>
                {u.status === 'uploading' && (
                  <div className="w-full bg-gray-200 rounded-full h-1.5 mt-1">
                    <div className="bg-blue-600 h-1.5 rounded-full transition-all" style={{ width: `${u.progress}%` }} />
                  </div>
                )}
                {u.status === 'error' && <p className="text-xs text-red-600">{u.error}</p>}
                {u.status === 'done' && <p className="text-xs text-green-600">アップロード完了</p>}
              </div>
              <button onClick={() => removeUpload(idx)} className="text-gray-400 hover:text-red-500">&times;</button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
TYPESCRIPT
)"
}

# =============================================================================
# S3 Presigned URL Generation
# =============================================================================
fu_generate_presigned_urls() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/lib/presigned-url.ts"

    _fue_write_file "$target" "$(cat <<'TYPESCRIPT'
import { S3Client, PutObjectCommand, GetObjectCommand } from '@aws-sdk/client-s3';
import { getSignedUrl } from '@aws-sdk/s3-request-presigner';
import { z } from 'zod';
import { randomUUID } from 'crypto';
import path from 'path';

const PresignedRequestSchema = z.object({
  fileName: z.string().min(1),
  fileType: z.string().min(1),
  fileSize: z.number().max(50 * 1024 * 1024), // 50MB limit
});

export type PresignedRequest = z.infer<typeof PresignedRequestSchema>;

const s3Client = new S3Client({
  region: process.env.S3_REGION || 'ap-northeast-1',
});

const BUCKET = process.env.S3_BUCKET || '';

const ALLOWED_TYPES = new Set([
  'image/jpeg', 'image/png', 'image/webp', 'image/gif',
  'application/pdf', 'text/csv',
]);

export async function generateUploadPresignedUrl(input: PresignedRequest) {
  const data = PresignedRequestSchema.parse(input);

  if (!ALLOWED_TYPES.has(data.fileType)) {
    throw new Error(`File type not allowed: ${data.fileType}`);
  }

  const ext = path.extname(data.fileName) || '.bin';
  const key = `uploads/${new Date().toISOString().slice(0, 10)}/${randomUUID()}${ext}`;

  const command = new PutObjectCommand({
    Bucket: BUCKET,
    Key: key,
    ContentType: data.fileType,
    ContentLength: data.fileSize,
  });

  const url = await getSignedUrl(s3Client, command, { expiresIn: 600 }); // 10 minutes

  return { uploadUrl: url, key, expiresIn: 600 };
}

export async function generateDownloadPresignedUrl(key: string, expiresIn = 3600) {
  const command = new GetObjectCommand({ Bucket: BUCKET, Key: key });
  const url = await getSignedUrl(s3Client, command, { expiresIn });
  return { downloadUrl: url, expiresIn };
}
TYPESCRIPT
)"

    # Also generate the API route for presigned URLs
    local api_target="${project_dir}/src/app/api/upload/presigned/route.ts"
    _fue_write_file "$api_target" "$(cat <<'TYPESCRIPT'
import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { generateUploadPresignedUrl } from '@/lib/presigned-url';
import { getSession } from '@/lib/auth';

const RequestSchema = z.object({
  fileName: z.string().min(1),
  fileType: z.string().min(1),
  fileSize: z.number().positive().max(50 * 1024 * 1024),
});

export async function POST(request: NextRequest) {
  try {
    const session = await getSession(request);
    if (!session?.userId) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    const body = await request.json();
    const data = RequestSchema.parse(body);
    const result = await generateUploadPresignedUrl(data);

    return NextResponse.json({ data: result });
  } catch (error: any) {
    if (error instanceof z.ZodError) {
      return NextResponse.json({ error: 'Validation failed', details: error.errors }, { status: 400 });
    }
    console.error('[Presigned URL]', error);
    return NextResponse.json({ error: error.message || 'Failed to generate URL' }, { status: 500 });
  }
}
TYPESCRIPT
)"
}

# =============================================================================
# File Type Validation / Virus Scan Alternative (Magic Number)
# =============================================================================
fu_generate_virus_scan() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/lib/file-validator.ts"

    _fue_write_file "$target" "$(cat <<'TYPESCRIPT'
// ---------------------------------------------------------------------------
// File Type Validator - Magic Number Verification
// ---------------------------------------------------------------------------
// MIME spoofing を防ぐため、ファイルヘッダのMagic Numberを検査する

interface FileTypeResult {
  valid: boolean;
  mimeType?: string;
  reason?: string;
}

const MAGIC_NUMBERS: Array<{ mime: string; bytes: number[]; offset?: number }> = [
  { mime: 'image/jpeg', bytes: [0xFF, 0xD8, 0xFF] },
  { mime: 'image/png', bytes: [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A] },
  { mime: 'image/gif', bytes: [0x47, 0x49, 0x46, 0x38] },
  { mime: 'image/webp', bytes: [0x52, 0x49, 0x46, 0x46], offset: 0 }, // RIFF
  { mime: 'application/pdf', bytes: [0x25, 0x50, 0x44, 0x46] }, // %PDF
  { mime: 'application/zip', bytes: [0x50, 0x4B, 0x03, 0x04] }, // PK
];

const DANGEROUS_EXTENSIONS = new Set([
  '.exe', '.bat', '.cmd', '.com', '.vbs', '.js', '.ws', '.wsf',
  '.scr', '.pif', '.msi', '.msp', '.mst', '.cpl', '.hta',
  '.inf', '.ins', '.isp', '.jse', '.lnk', '.reg', '.rgs', '.sct',
  '.shb', '.shs', '.vbe', '.wsc', '.wsh', '.ps1', '.ps1xml',
]);

export function validateFileType(buffer: Buffer, fileName: string): FileTypeResult {
  const ext = fileName.toLowerCase().slice(fileName.lastIndexOf('.'));

  // Block dangerous extensions
  if (DANGEROUS_EXTENSIONS.has(ext)) {
    return { valid: false, reason: `Dangerous file extension: ${ext}` };
  }

  // Block empty files
  if (buffer.length === 0) {
    return { valid: false, reason: 'Empty file' };
  }

  // Check magic numbers for known types
  for (const sig of MAGIC_NUMBERS) {
    const offset = sig.offset || 0;
    if (buffer.length < offset + sig.bytes.length) continue;

    const match = sig.bytes.every((byte, i) => buffer[offset + i] === byte);
    if (match) {
      return { valid: true, mimeType: sig.mime };
    }
  }

  // For text-based files (CSV, etc.) allow if extension is safe
  const textExtensions = new Set(['.csv', '.txt', '.json', '.xml', '.yaml', '.yml', '.md']);
  if (textExtensions.has(ext)) {
    // Check for null bytes (binary in disguise)
    const sample = buffer.slice(0, Math.min(1024, buffer.length));
    const hasNullByte = sample.includes(0x00);
    if (hasNullByte) {
      return { valid: false, reason: 'Binary content in text file' };
    }
    return { valid: true, mimeType: `text/${ext.slice(1)}` };
  }

  // XLSX/DOCX are ZIP-based
  if (['.xlsx', '.docx', '.pptx'].includes(ext)) {
    if (buffer[0] === 0x50 && buffer[1] === 0x4B) {
      return { valid: true, mimeType: 'application/octet-stream' };
    }
  }

  return { valid: false, reason: `Unknown file type for extension: ${ext}` };
}
TYPESCRIPT
)"
}

# =============================================================================
# CDN / Static Asset Configuration
# =============================================================================
fu_generate_cdn_config() {
    local project_dir="${1:-${PROJECT_DIR:-./output}}"
    local target="${project_dir}/src/lib/cdn-config.ts"

    _fue_write_file "$target" "$(cat <<'TYPESCRIPT'
import { z } from 'zod';

export const CdnConfigSchema = z.object({
  enabled: z.boolean().default(false),
  baseUrl: z.string().url().optional(),
  cacheControl: z.object({
    images: z.string().default('public, max-age=31536000, immutable'),
    documents: z.string().default('public, max-age=86400'),
    default: z.string().default('public, max-age=3600'),
  }).default({}),
});

export type CdnConfig = z.infer<typeof CdnConfigSchema>;

const config = CdnConfigSchema.parse({
  enabled: !!process.env.CDN_BASE_URL,
  baseUrl: process.env.CDN_BASE_URL || undefined,
});

export function getAssetUrl(key: string): string {
  if (config.enabled && config.baseUrl) {
    return `${config.baseUrl}/${key}`;
  }
  return `/uploads/${key}`;
}

export function getCacheHeaders(mimeType: string): Record<string, string> {
  if (mimeType.startsWith('image/')) {
    return { 'Cache-Control': config.cacheControl.images };
  }
  if (mimeType === 'application/pdf' || mimeType.startsWith('text/')) {
    return { 'Cache-Control': config.cacheControl.documents };
  }
  return { 'Cache-Control': config.cacheControl.default };
}
TYPESCRIPT
)"

    # Next.js config for static assets
    local next_target="${project_dir}/next.config.upload.mjs"
    _fue_write_file "$next_target" "$(cat <<'JAVASCRIPT'
/** @type {import('next').NextConfig} */
const uploadConfig = {
  images: {
    remotePatterns: [
      { protocol: 'https', hostname: '**.amazonaws.com' },
      { protocol: 'https', hostname: '**.r2.dev' },
      { protocol: 'https', hostname: '**.cloudfront.net' },
    ],
    formats: ['image/avif', 'image/webp'],
  },
  async headers() {
    return [
      {
        source: '/uploads/:path*',
        headers: [
          { key: 'Cache-Control', value: 'public, max-age=31536000, immutable' },
          { key: 'X-Content-Type-Options', value: 'nosniff' },
        ],
      },
    ];
  },
};

export default uploadConfig;
JAVASCRIPT
)"
}

# =============================================================================
# Inject upload patterns into Claude prompt
# =============================================================================
fu_inject_upload_patterns() {
    local prompt="${1:-}"

    cat <<'PATTERNS'

## [FILE-UPLOAD] ファイルアップロードパターン（必須準拠）

### ストレージプロバイダー
- `UploadService` で Local/S3/R2/GCS を抽象化
- 環境変数 `UPLOAD_PROVIDER` で切替（default: local）
- ファイルは `uploads/YYYY-MM-DD/uuid.ext` 形式で保存

### アップロードAPI
- POST /api/upload - FormData multipart upload
- POST /api/upload/presigned - S3 presigned URL取得
- DELETE /api/upload?id=xxx - ファイル削除
- 全エンドポイントで認証必須

### バリデーション
- サイズ制限: MAX_FILE_SIZE env (default 10MB)
- MIME検証: allowedMimeTypes ホワイトリスト
- Magic Number検査: ファイルヘッダ検証
- 危険拡張子(.exe, .bat等)ブロック

### 画像処理
- sharp でリサイズ/サムネイル/フォーマット変換
- デフォルト3サイズ: thumb(150), medium(600), large(1200)
- WebP自動変換推奨

### Reactコンポーネント
- FileUpload: DnD + プログレスバー + プレビュー
- accept/maxSize/multiple props対応
PATTERNS

    echo "$prompt"
}

# =============================================================================
# Report
# =============================================================================
fue_report() {
    echo -e "\n  ${BOLD:-}=== File Upload Engine v${FUE_VERSION} ===${NC:-}"
    echo -e "  生成数: ${FUE_GENERATED}"
    echo -e "  エラー: ${FUE_ERRORS}"
    if [[ ${#FUE_FILES_CREATED[@]} -gt 0 ]]; then
        echo -e "  ファイル:"
        for f in "${FUE_FILES_CREATED[@]}"; do
            echo -e "    - ${f}"
        done
    fi
}

fue_score() {
    if [[ ${FUE_GENERATED} -ge 5 ]] && [[ ${FUE_ERRORS} -eq 0 ]]; then
        echo "95"
    elif [[ ${FUE_GENERATED} -gt 0 ]] && [[ ${FUE_ERRORS} -eq 0 ]]; then
        echo "90"
    elif [[ ${FUE_GENERATED} -gt 0 ]]; then
        echo "70"
    else
        echo "50"
    fi
}

# =============================================================================
# v59.0: Module Registry 自己登録
# =============================================================================
if type -t _mr_register &>/dev/null; then
    _mr_register --name "file-upload-engine" --version "140.0" \
        --description "ファイルアップロード基盤×S3/R2/GCS統合×画像処理×CDN配信" \
        --init "fu_init" --report "fue_report" --score "fue_score" \
        --enable-var "ENABLE_FILE_UPLOAD" --cli-flags "--file-upload:--no-file-upload"
fi

# v2003.1: source時のexit codeを確実に0にする
true
