#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v441.0 - Database Sharding Engine
# =============================================================================
# データベースシャーディング設計支援。シャードキー設計、シャード設定生成、
# ルーティングロジック生成を行う。水平分割戦略を自動提案する。
#
# Functions:
#   _ds_init()                    - 初期化
#   _ds_design_shard_key()        - シャードキー設計
#   _ds_generate_shard_config()   - シャード設定生成
#   _ds_generate_routing()        - ルーティングロジック生成
#   _ds_report() / _ds_score()
#
# All globals use the DS_ prefix.
# =============================================================================

[[ -n "${_DS_LOADED:-}" ]] && return 0; _DS_LOADED=1

declare -g DS_VERSION="441.0"
declare -g DS_GENERATED=0
declare -g DS_ERRORS=0
declare -g DS_SHARD_KEYS=0
declare -g DS_SHARD_COUNT="${DS_SHARD_COUNT:-4}"
declare -g DS_ROUTING_GENERATED=false
declare -g DS_TABLES_ANALYZED=0

declare -ga _DS_FINDINGS=()
declare -gA _DS_TABLE_SIZES=()
declare -gA _DS_SHARD_MAP=()

_DS_GREEN="${GREEN:-\033[0;32m}"
_DS_RED="${RED:-\033[0;31m}"
_DS_YELLOW="${YELLOW:-\033[0;33m}"
_DS_CYAN="${CYAN:-\033[0;36m}"
_DS_BOLD="${BOLD:-\033[1m}"
_DS_NC="${NC:-\033[0m}"

_ds_init() {
    DS_GENERATED=0; DS_ERRORS=0; DS_SHARD_KEYS=0
    DS_ROUTING_GENERATED=false; DS_TABLES_ANALYZED=0
    _DS_FINDINGS=(); _DS_TABLE_SIZES=(); _DS_SHARD_MAP=()
    return 0
}

_ds_log() {
    local level="$1"; shift
    case "$level" in
        info)  echo -e "  ${_DS_CYAN}[DS]${_DS_NC} $*" >&2 ;;
        ok)    echo -e "  ${_DS_GREEN}[DS]${_DS_NC} $*" >&2 ;;
        warn)  echo -e "  ${_DS_YELLOW}[DS]${_DS_NC} $*" >&2 ;;
        error) echo -e "  ${_DS_RED}[DS]${_DS_NC} $*" >&2 ;;
    esac
}

# =============================================================================
# _ds_design_shard_key - シャードキー設計
# =============================================================================
_ds_design_shard_key() {
    local project_dir="${1:-.}"
    _ds_log info "シャードキー設計分析"

    DS_SHARD_KEYS=0
    DS_TABLES_ANALYZED=0

    local schema
    schema=$(find "$project_dir" -name "schema.prisma" -not -path "*/node_modules/*" 2>/dev/null | head -1)

    if [[ -f "$schema" ]]; then
        local current_model=""
        local model_fields=""

        while IFS= read -r line; do
            if [[ "$line" =~ ^model[[:space:]]+([A-Z][a-zA-Z]+) ]]; then
                # 前のモデルを処理
                if [[ -n "$current_model" ]]; then
                    _ds_analyze_model "$current_model" "$model_fields"
                fi
                current_model="${BASH_REMATCH[1]}"
                model_fields=""
                DS_TABLES_ANALYZED=$((DS_TABLES_ANALYZED + 1))
            elif [[ -n "$current_model" ]] && [[ "$line" =~ ^[[:space:]]+([a-zA-Z_]+) ]]; then
                model_fields="${model_fields}${model_fields:+,}${BASH_REMATCH[1]}"
            fi
        done < "$schema"

        # 最後のモデル
        if [[ -n "$current_model" ]]; then
            _ds_analyze_model "$current_model" "$model_fields"
        fi
    fi

    DS_GENERATED=$((DS_GENERATED + 1))
    _ds_log ok "シャードキー設計: ${DS_SHARD_KEYS}テーブル分析, ${DS_TABLES_ANALYZED}モデル"
    return 0
}

_ds_analyze_model() {
    local model="$1"
    local fields="$2"

    # テナントID（マルチテナント向け最適シャードキー）
    if [[ "$fields" == *"tenantId"* ]] || [[ "$fields" == *"organizationId"* ]] || [[ "$fields" == *"companyId"* ]]; then
        local key="tenantId"
        [[ "$fields" == *"organizationId"* ]] && key="organizationId"
        [[ "$fields" == *"companyId"* ]] && key="companyId"
        _DS_SHARD_MAP["$model"]="$key"
        DS_SHARD_KEYS=$((DS_SHARD_KEYS + 1))
        _DS_FINDINGS+=("SHARD_KEY:${model}:${key} (tenant-based sharding)")
        _ds_log ok "${model}: シャードキー=${key}"
    elif [[ "$fields" == *"userId"* ]]; then
        _DS_SHARD_MAP["$model"]="userId"
        DS_SHARD_KEYS=$((DS_SHARD_KEYS + 1))
        _DS_FINDINGS+=("SHARD_KEY:${model}:userId (user-based sharding)")
    elif [[ "$fields" == *"regionId"* ]] || [[ "$fields" == *"region"* ]]; then
        _DS_SHARD_MAP["$model"]="region"
        DS_SHARD_KEYS=$((DS_SHARD_KEYS + 1))
        _DS_FINDINGS+=("SHARD_KEY:${model}:region (geo-based sharding)")
    elif [[ "$fields" == *"createdAt"* ]]; then
        _DS_FINDINGS+=("SHARD_CANDIDATE:${model}:createdAt (time-range sharding possible)")
    fi
}

# =============================================================================
# _ds_generate_shard_config - シャード設定生成
# =============================================================================
_ds_generate_shard_config() {
    local project_dir="${1:-.}"
    local shard_count="${2:-$DS_SHARD_COUNT}"

    _ds_log info "シャード設定生成 (${shard_count}シャード)"

    local config=$(cat <<SHARD_CONFIG
// lib/shard-config.ts - Database Sharding Configuration
export interface ShardConfig {
  id: number;
  host: string;
  port: number;
  database: string;
  weight: number;
}

export const SHARD_COUNT = ${shard_count};

export const shards: ShardConfig[] = Array.from({ length: SHARD_COUNT }, (_, i) => ({
  id: i,
  host: process.env[\`DB_SHARD_\${i}_HOST\`] || 'localhost',
  port: parseInt(process.env[\`DB_SHARD_\${i}_PORT\`] || '5432'),
  database: process.env[\`DB_SHARD_\${i}_DB\`] || \`app_shard_\${i}\`,
  weight: 1,
}));

export function getShardId(key: string | number): number {
  if (typeof key === 'number') return key % SHARD_COUNT;
  let hash = 0;
  for (let i = 0; i < key.length; i++) {
    const char = key.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0;
  }
  return Math.abs(hash) % SHARD_COUNT;
}
SHARD_CONFIG
)

    _DS_FINDINGS+=("SHARD_CONFIG:generated shard-config.ts with ${shard_count} shards")
    DS_GENERATED=$((DS_GENERATED + 1))
    _ds_log ok "シャード設定生成完了"

    echo "$config"
    return 0
}

# =============================================================================
# _ds_generate_routing - ルーティングロジック生成
# =============================================================================
_ds_generate_routing() {
    local project_dir="${1:-.}"
    _ds_log info "シャードルーティング生成"

    local routing=$(cat <<'ROUTING'
// lib/shard-router.ts - Shard Routing Logic
import { PrismaClient } from '@prisma/client';
import { getShardId, shards, type ShardConfig } from './shard-config';

const clients = new Map<number, PrismaClient>();

function getClient(shardId: number): PrismaClient {
  let client = clients.get(shardId);
  if (!client) {
    const shard = shards[shardId];
    client = new PrismaClient({
      datasources: {
        db: {
          url: `postgresql://${shard.host}:${shard.port}/${shard.database}`,
        },
      },
    });
    clients.set(shardId, client);
  }
  return client;
}

export function getShardClient(shardKey: string | number): PrismaClient {
  const shardId = getShardId(shardKey);
  return getClient(shardId);
}

export async function queryAllShards<T>(
  queryFn: (client: PrismaClient) => Promise<T[]>
): Promise<T[]> {
  const results = await Promise.all(
    shards.map(shard => queryFn(getClient(shard.id)))
  );
  return results.flat();
}
ROUTING
)

    DS_ROUTING_GENERATED=true
    DS_GENERATED=$((DS_GENERATED + 1))

    for model in "${!_DS_SHARD_MAP[@]}"; do
        local key="${_DS_SHARD_MAP[$model]}"
        _DS_FINDINGS+=("ROUTING:${model}: getShardClient(${key}) for routing")
    done

    _ds_log ok "ルーティング生成完了"
    echo "$routing"
    return 0
}

# =============================================================================
# Report & Score
# =============================================================================
_ds_report() {
    echo -e "\n  ${_DS_BOLD}=== database-sharding v${DS_VERSION} ===${_DS_NC}"
    echo -e "  分析テーブル    : ${DS_TABLES_ANALYZED}"
    echo -e "  シャードキー    : ${DS_SHARD_KEYS}"
    echo -e "  シャード数      : ${DS_SHARD_COUNT}"
    echo -e "  ルーティング    : ${DS_ROUTING_GENERATED}"
    echo -e "  エラー          : ${DS_ERRORS}"
}

_ds_score() {
    local score=50
    [[ ${DS_TABLES_ANALYZED} -gt 0 ]] && score=$((score + 10))
    [[ ${DS_SHARD_KEYS} -gt 0 ]] && score=$((score + 15))
    [[ "$DS_ROUTING_GENERATED" == "true" ]] && score=$((score + 15))
    [[ ${DS_ERRORS} -eq 0 ]] && score=$((score + 10))
    echo "${score}"
}

if type -t _mr_register &>/dev/null; then
    _mr_register --name "database-sharding" --version "${DS_VERSION}" \
        --description "DBシャーディング×シャードキー設計×ルーティング生成 (v441)" \
        --init "_ds_init" --report "_ds_report" --score "_ds_score" \
        --enable-var "ENABLE_DB_SHARDING" --cli-flags "--db-sharding:--no-db-sharding"
fi

# v2003.1: source時のexit codeを確実に0にする
true
