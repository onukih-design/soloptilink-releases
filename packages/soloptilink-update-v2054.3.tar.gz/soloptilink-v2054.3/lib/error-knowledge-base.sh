#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v278.0 - Error Knowledge Base
# =============================================================================
# エラー・修正・結果をJSONLで蓄積する知識ベース。
# 類似エラーの検索、修正履歴の取得、成功率の計算、レポート出力を提供。
#
# Functions:
#   _ekb_init            - 初期化（ディレクトリ・インデックス準備）
#   _ekb_store_error     - エラー+修正+結果を格納
#   _ekb_search          - 類似エラー検索
#   _ekb_get_fix_history - エラーパターンの修正履歴取得
#   _ekb_get_success_rate - 修正戦略の成功率取得
#   _ekb_export_report   - ナレッジベースレポート出力
#   _ekb_report          - モジュールレポート
#   _ekb_score           - スコア算出(0-100)
#
# All globals use the EKB_ prefix.
# =============================================================================

[[ -n "${_ERROR_KNOWLEDGE_BASE_LOADED:-}" ]] && return 0
_ERROR_KNOWLEDGE_BASE_LOADED=1

EKB_VERSION="278.0"
EKB_INITIALIZED=false
ENABLE_EKB="${ENABLE_EKB:-true}"

# Counters
EKB_TOTAL_ENTRIES=0
EKB_TOTAL_SEARCHES=0
EKB_TOTAL_HITS=0
EKB_SUCCESS_ENTRIES=0
EKB_FAILURE_ENTRIES=0

# Storage paths
EKB_BASE_DIR=""
EKB_ERRORS_FILE=""
EKB_INDEX_FILE=""
EKB_STATS_FILE=""

# In-memory index
declare -g -A _EKB_ERROR_INDEX=()     # error_hash -> line numbers in errors file
declare -g -A _EKB_FIX_COUNT=()       # strategy -> count
declare -g -A _EKB_FIX_SUCCESS=()     # strategy -> success count
declare -g -A _EKB_CATEGORY_COUNT=()  # category -> count

# =============================================================================
# _ekb_init - Initialize error knowledge base
# =============================================================================
_ekb_init() {
    EKB_BASE_DIR="${HOME}/.soloptilink/knowledge/errors"
    mkdir -p "$EKB_BASE_DIR" 2>/dev/null || true

    EKB_ERRORS_FILE="${EKB_BASE_DIR}/errors.jsonl"
    EKB_INDEX_FILE="${EKB_BASE_DIR}/index.jsonl"
    EKB_STATS_FILE="${EKB_BASE_DIR}/stats.json"

    EKB_TOTAL_ENTRIES=0
    EKB_TOTAL_SEARCHES=0
    EKB_TOTAL_HITS=0
    EKB_SUCCESS_ENTRIES=0
    EKB_FAILURE_ENTRIES=0
    _EKB_ERROR_INDEX=()
    _EKB_FIX_COUNT=()
    _EKB_FIX_SUCCESS=()
    _EKB_CATEGORY_COUNT=()

    # Load existing data
    if [[ -f "$EKB_ERRORS_FILE" ]]; then
        _ekb_load_index
    fi

    # Create files if they don't exist
    touch "$EKB_ERRORS_FILE" 2>/dev/null || true
    touch "$EKB_INDEX_FILE" 2>/dev/null || true

    EKB_INITIALIZED=true
    return 0
}

# =============================================================================
# _ekb_load_index - Load index from existing errors file
# =============================================================================
_ekb_load_index() {
    local line_num=0

    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        line_num=$((line_num + 1))

        # Extract fields from JSON
        local error_type
        error_type=$(echo "$line" | grep -oE '"error_type"\s*:\s*"[^"]*"' | sed 's/.*"error_type"\s*:\s*"//;s/"//')
        local category
        category=$(echo "$line" | grep -oE '"category"\s*:\s*"[^"]*"' | sed 's/.*"category"\s*:\s*"//;s/"//')
        local strategy
        strategy=$(echo "$line" | grep -oE '"strategy"\s*:\s*"[^"]*"' | sed 's/.*"strategy"\s*:\s*"//;s/"//')
        local result
        result=$(echo "$line" | grep -oE '"result"\s*:\s*"[^"]*"' | sed 's/.*"result"\s*:\s*"//;s/"//')

        # Build index
        if [[ -n "$error_type" ]]; then
            local hash
            hash=$(_ekb_hash "$error_type")
            _EKB_ERROR_INDEX["$hash"]="${_EKB_ERROR_INDEX[$hash]:-}${line_num},"
        fi

        # Track categories
        if [[ -n "$category" ]]; then
            _EKB_CATEGORY_COUNT["$category"]=$(( ${_EKB_CATEGORY_COUNT[$category]:-0} + 1 ))
        fi

        # Track fix strategies
        if [[ -n "$strategy" ]]; then
            _EKB_FIX_COUNT["$strategy"]=$(( ${_EKB_FIX_COUNT[$strategy]:-0} + 1 ))
            if [[ "$result" == "success" ]]; then
                _EKB_FIX_SUCCESS["$strategy"]=$(( ${_EKB_FIX_SUCCESS[$strategy]:-0} + 1 ))
                EKB_SUCCESS_ENTRIES=$((EKB_SUCCESS_ENTRIES + 1))
            else
                EKB_FAILURE_ENTRIES=$((EKB_FAILURE_ENTRIES + 1))
            fi
        fi

        EKB_TOTAL_ENTRIES=$((EKB_TOTAL_ENTRIES + 1))
    done < "$EKB_ERRORS_FILE"
}

# =============================================================================
# _ekb_hash - Simple hash for error matching
# =============================================================================
_ekb_hash() {
    local input="$1"
    # Normalize: lowercase, remove numbers, trim
    local normalized
    normalized=$(echo "$input" | tr '[:upper:]' '[:lower:]' | sed 's/[0-9]//g;s/  */ /g;s/^ //;s/ $//')
    echo "$normalized" | cksum | awk '{print $1}'
}

# =============================================================================
# _ekb_store_error - Store error + fix + result in knowledge base
# Usage: _ekb_store_error <error_type> <error_message> <file> <category> <strategy> <fix_description> <result>
# =============================================================================
_ekb_store_error() {
    [[ "$EKB_INITIALIZED" != "true" ]] && _ekb_init

    local error_type="${1:-unknown}"
    local error_message="${2:-}"
    local file="${3:-}"
    local category="${4:-general}"
    local strategy="${5:-manual}"
    local fix_description="${6:-}"
    local result="${7:-unknown}"

    local timestamp
    timestamp=$(date -u +"%Y-%m-%dT%H:%M:%SZ")

    # Escape JSON special chars
    local esc_msg
    esc_msg=$(echo "$error_message" | sed 's/\\/\\\\/g;s/"/\\"/g;s/\t/\\t/g' | tr '\n' ' ')
    local esc_fix
    esc_fix=$(echo "$fix_description" | sed 's/\\/\\\\/g;s/"/\\"/g;s/\t/\\t/g' | tr '\n' ' ')

    local entry="{\"timestamp\":\"${timestamp}\",\"error_type\":\"${error_type}\",\"message\":\"${esc_msg}\",\"file\":\"${file}\",\"category\":\"${category}\",\"strategy\":\"${strategy}\",\"fix\":\"${esc_fix}\",\"result\":\"${result}\"}"

    echo "$entry" >> "$EKB_ERRORS_FILE"

    # Update in-memory index
    EKB_TOTAL_ENTRIES=$((EKB_TOTAL_ENTRIES + 1))

    local hash
    hash=$(_ekb_hash "$error_type")
    _EKB_ERROR_INDEX["$hash"]="${_EKB_ERROR_INDEX[$hash]:-}${EKB_TOTAL_ENTRIES},"

    _EKB_CATEGORY_COUNT["$category"]=$(( ${_EKB_CATEGORY_COUNT[$category]:-0} + 1 ))
    _EKB_FIX_COUNT["$strategy"]=$(( ${_EKB_FIX_COUNT[$strategy]:-0} + 1 ))

    if [[ "$result" == "success" ]]; then
        _EKB_FIX_SUCCESS["$strategy"]=$(( ${_EKB_FIX_SUCCESS[$strategy]:-0} + 1 ))
        EKB_SUCCESS_ENTRIES=$((EKB_SUCCESS_ENTRIES + 1))
    else
        EKB_FAILURE_ENTRIES=$((EKB_FAILURE_ENTRIES + 1))
    fi

    echo -e "  ${GREEN:-}[EKB] Stored: ${error_type} (${result})${NC:-}" >&2
    return 0
}

# =============================================================================
# _ekb_search - Search knowledge base for similar errors
# Usage: _ekb_search <error_type_or_message> [max_results]
# =============================================================================
_ekb_search() {
    [[ "$EKB_INITIALIZED" != "true" ]] && _ekb_init

    local query="${1:-}"
    local max_results="${2:-5}"
    EKB_TOTAL_SEARCHES=$((EKB_TOTAL_SEARCHES + 1))

    if [[ -z "$query" ]]; then
        echo "[]"
        return 0
    fi

    echo -e "  ${CYAN:-}[EKB] Searching: ${query:0:80}...${NC:-}" >&2

    # Try exact hash match first
    local hash
    hash=$(_ekb_hash "$query")
    local line_nums="${_EKB_ERROR_INDEX[$hash]:-}"

    local results=()
    local result_count=0

    if [[ -n "$line_nums" ]]; then
        # Exact type match - get entries by line number
        local IFS=','
        for ln in $line_nums; do
            [[ -z "$ln" ]] && continue
            [[ $result_count -ge $max_results ]] && break

            local entry
            entry=$(sed -n "${ln}p" "$EKB_ERRORS_FILE" 2>/dev/null)
            if [[ -n "$entry" ]]; then
                results+=("$entry")
                result_count=$((result_count + 1))
            fi
        done
        unset IFS
    fi

    # Fallback: grep search
    if [[ $result_count -eq 0 ]]; then
        local query_lower
        query_lower=$(echo "$query" | tr '[:upper:]' '[:lower:]')

        while IFS= read -r line; do
            [[ -z "$line" ]] && continue
            [[ $result_count -ge $max_results ]] && break
            results+=("$line")
            result_count=$((result_count + 1))
        done < <(grep -i "$query_lower" "$EKB_ERRORS_FILE" 2>/dev/null | tail -n "$max_results")
    fi

    EKB_TOTAL_HITS=$((EKB_TOTAL_HITS + result_count))

    if [[ $result_count -gt 0 ]]; then
        echo -e "  ${GREEN:-}[EKB] Found ${result_count} results${NC:-}" >&2
        printf '[%s]\n' "$(printf '%s,' "${results[@]}" | sed 's/,$//')"
    else
        echo -e "  ${YELLOW:-}[EKB] No results found${NC:-}" >&2
        echo "[]"
    fi

    return 0
}

# =============================================================================
# _ekb_get_fix_history - Get fix history for an error pattern
# Usage: _ekb_get_fix_history <error_type>
# =============================================================================
_ekb_get_fix_history() {
    [[ "$EKB_INITIALIZED" != "true" ]] && _ekb_init

    local error_type="${1:-}"
    if [[ -z "$error_type" ]]; then
        echo "No error type specified"
        return 1
    fi

    echo -e "  ${CYAN:-}[EKB] Getting fix history for: ${error_type}${NC:-}" >&2

    local hash
    hash=$(_ekb_hash "$error_type")
    local line_nums="${_EKB_ERROR_INDEX[$hash]:-}"

    if [[ -z "$line_nums" ]]; then
        # Fallback to grep
        grep -i "$(echo "$error_type" | tr '[:upper:]' '[:lower:]')" "$EKB_ERRORS_FILE" 2>/dev/null | \
            grep -oE '"strategy"\s*:\s*"[^"]*"|"result"\s*:\s*"[^"]*"|"fix"\s*:\s*"[^"]*"' | \
            paste - - - 2>/dev/null
        return 0
    fi

    local IFS=','
    for ln in $line_nums; do
        [[ -z "$ln" ]] && continue
        local entry
        entry=$(sed -n "${ln}p" "$EKB_ERRORS_FILE" 2>/dev/null)
        if [[ -n "$entry" ]]; then
            local strategy
            strategy=$(echo "$entry" | grep -oE '"strategy"\s*:\s*"[^"]*"' | sed 's/.*"strategy"\s*:\s*"//;s/"//')
            local result
            result=$(echo "$entry" | grep -oE '"result"\s*:\s*"[^"]*"' | sed 's/.*"result"\s*:\s*"//;s/"//')
            local fix
            fix=$(echo "$entry" | grep -oE '"fix"\s*:\s*"[^"]*"' | sed 's/.*"fix"\s*:\s*"//;s/"//')
            local timestamp
            timestamp=$(echo "$entry" | grep -oE '"timestamp"\s*:\s*"[^"]*"' | sed 's/.*"timestamp"\s*:\s*"//;s/"//')

            echo "  [${timestamp}] strategy=${strategy} result=${result} fix=${fix:0:80}"
        fi
    done
    unset IFS

    return 0
}

# =============================================================================
# _ekb_get_success_rate - Get success rate for a fix strategy
# Usage: _ekb_get_success_rate <strategy>
# =============================================================================
_ekb_get_success_rate() {
    [[ "$EKB_INITIALIZED" != "true" ]] && _ekb_init

    local strategy="${1:-}"

    if [[ -z "$strategy" ]]; then
        # Return all strategy success rates
        echo -e "  ${CYAN:-}[EKB] Fix Strategy Success Rates:${NC:-}" >&2
        for s in "${!_EKB_FIX_COUNT[@]}"; do
            local total="${_EKB_FIX_COUNT[$s]}"
            local success="${_EKB_FIX_SUCCESS[$s]:-0}"
            local rate=0
            [[ $total -gt 0 ]] && rate=$((success * 100 / total))
            echo "  ${s}: ${rate}% (${success}/${total})"
        done
        return 0
    fi

    local total="${_EKB_FIX_COUNT[$strategy]:-0}"
    local success="${_EKB_FIX_SUCCESS[$strategy]:-0}"

    if [[ $total -eq 0 ]]; then
        echo "0"
        return 0
    fi

    local rate=$((success * 100 / total))
    echo "$rate"
}

# =============================================================================
# _ekb_get_best_strategy - Get the best strategy for an error type
# Usage: _ekb_get_best_strategy <error_type>
# =============================================================================
_ekb_get_best_strategy() {
    [[ "$EKB_INITIALIZED" != "true" ]] && _ekb_init

    local error_type="${1:-}"
    local best_strategy=""
    local best_rate=0

    local hash
    hash=$(_ekb_hash "$error_type")
    local line_nums="${_EKB_ERROR_INDEX[$hash]:-}"

    if [[ -z "$line_nums" ]]; then
        echo ""
        return 0
    fi

    # Count successes per strategy for this error type
    declare -A _local_strategy_total=()
    declare -A _local_strategy_success=()

    local IFS=','
    for ln in $line_nums; do
        [[ -z "$ln" ]] && continue
        local entry
        entry=$(sed -n "${ln}p" "$EKB_ERRORS_FILE" 2>/dev/null)
        if [[ -n "$entry" ]]; then
            local strategy
            strategy=$(echo "$entry" | grep -oE '"strategy"\s*:\s*"[^"]*"' | sed 's/.*"strategy"\s*:\s*"//;s/"//')
            local result
            result=$(echo "$entry" | grep -oE '"result"\s*:\s*"[^"]*"' | sed 's/.*"result"\s*:\s*"//;s/"//')

            [[ -n "$strategy" ]] && {
                _local_strategy_total["$strategy"]=$(( ${_local_strategy_total[$strategy]:-0} + 1 ))
                [[ "$result" == "success" ]] && \
                    _local_strategy_success["$strategy"]=$(( ${_local_strategy_success[$strategy]:-0} + 1 ))
            }
        fi
    done
    unset IFS

    for s in "${!_local_strategy_total[@]}"; do
        local total="${_local_strategy_total[$s]}"
        local success="${_local_strategy_success[$s]:-0}"
        local rate=0
        [[ $total -gt 0 ]] && rate=$((success * 100 / total))

        if [[ $rate -gt $best_rate ]] || { [[ $rate -eq $best_rate ]] && [[ $total -gt ${_local_strategy_total[$best_strategy]:-0} ]]; }; then
            best_rate=$rate
            best_strategy="$s"
        fi
    done

    echo "$best_strategy"
}

# =============================================================================
# _ekb_export_report - Export knowledge base as report
# Usage: _ekb_export_report [output_file]
# =============================================================================
_ekb_export_report() {
    [[ "$EKB_INITIALIZED" != "true" ]] && _ekb_init

    local output_file="${1:-${EKB_BASE_DIR}/report.txt}"

    echo -e "  ${CYAN:-}[EKB] Exporting report to ${output_file}...${NC:-}" >&2

    {
        echo "============================================="
        echo "Error Knowledge Base Report"
        echo "Generated: $(date -u +"%Y-%m-%d %H:%M:%S UTC")"
        echo "SoloptiLinkAI v278.0"
        echo "============================================="
        echo ""
        echo "Summary:"
        echo "  Total entries    : ${EKB_TOTAL_ENTRIES}"
        echo "  Successful fixes : ${EKB_SUCCESS_ENTRIES}"
        echo "  Failed fixes     : ${EKB_FAILURE_ENTRIES}"
        local overall_rate=0
        [[ $EKB_TOTAL_ENTRIES -gt 0 ]] && overall_rate=$((EKB_SUCCESS_ENTRIES * 100 / EKB_TOTAL_ENTRIES))
        echo "  Overall success  : ${overall_rate}%"
        echo "  Searches         : ${EKB_TOTAL_SEARCHES}"
        echo "  Search hits      : ${EKB_TOTAL_HITS}"
        echo ""
        echo "Categories:"
        for cat in "${!_EKB_CATEGORY_COUNT[@]}"; do
            printf "  %-20s : %d\n" "$cat" "${_EKB_CATEGORY_COUNT[$cat]}"
        done
        echo ""
        echo "Fix Strategies (success rate):"
        for s in "${!_EKB_FIX_COUNT[@]}"; do
            local total="${_EKB_FIX_COUNT[$s]}"
            local success="${_EKB_FIX_SUCCESS[$s]:-0}"
            local rate=0
            [[ $total -gt 0 ]] && rate=$((success * 100 / total))
            printf "  %-25s : %3d%% (%d/%d)\n" "$s" "$rate" "$success" "$total"
        done
        echo ""
        echo "Recent Errors (last 20):"
        tail -20 "$EKB_ERRORS_FILE" 2>/dev/null | while IFS= read -r line; do
            local etype
            etype=$(echo "$line" | grep -oE '"error_type"\s*:\s*"[^"]*"' | sed 's/.*"//;s/"//')
            local result
            result=$(echo "$line" | grep -oE '"result"\s*:\s*"[^"]*"' | sed 's/.*"//;s/"//')
            local ts
            ts=$(echo "$line" | grep -oE '"timestamp"\s*:\s*"[^"]*"' | sed 's/.*"//;s/"//')
            echo "  [${ts}] ${etype} -> ${result}"
        done
        echo ""
        echo "============================================="
    } > "$output_file"

    echo -e "  ${GREEN:-}[EKB] Report exported: ${output_file}${NC:-}" >&2
    return 0
}

# =============================================================================
# _ekb_report
# =============================================================================
_ekb_report() {
    echo -e "\n  ${BOLD:-}═══ Error Knowledge Base v278.0 ═══${NC:-}"
    echo -e "  Total entries      : ${EKB_TOTAL_ENTRIES}"
    echo -e "  Successful fixes   : ${EKB_SUCCESS_ENTRIES}"
    echo -e "  Failed fixes       : ${EKB_FAILURE_ENTRIES}"
    echo -e "  Searches           : ${EKB_TOTAL_SEARCHES}"
    echo -e "  Search hits        : ${EKB_TOTAL_HITS}"
    echo -e "  Categories         : ${#_EKB_CATEGORY_COUNT[@]}"
    echo -e "  Fix strategies     : ${#_EKB_FIX_COUNT[@]}"
}

# =============================================================================
# _ekb_score
# =============================================================================
_ekb_score() {
    local score=60
    [[ $EKB_TOTAL_ENTRIES -gt 0 ]] && score=$((score + 10))
    [[ $EKB_TOTAL_ENTRIES -gt 50 ]] && score=$((score + 10))
    [[ $EKB_TOTAL_SEARCHES -gt 0 ]] && score=$((score + 5))
    [[ $EKB_TOTAL_HITS -gt 0 ]] && score=$((score + 5))
    local rate=0
    [[ $EKB_TOTAL_ENTRIES -gt 0 ]] && rate=$((EKB_SUCCESS_ENTRIES * 100 / EKB_TOTAL_ENTRIES))
    [[ $rate -gt 70 ]] && score=$((score + 10))
    [[ $score -gt 100 ]] && score=100
    echo "$score"
}

# =============================================================================
# Module Registry Self-Registration
# =============================================================================
_mr_register \
    --name "error-knowledge-base" \
    --version "278.0" \
    --description "エラー・修正・結果の知識ベース蓄積・検索・成功率分析" \
    --init "_ekb_init" \
    --report "_ekb_report" \
    --score "_ekb_score" \
    --enable-var "ENABLE_EKB" \
    --cli-flags "--error-knowledge-base:--no-error-knowledge-base"
