#!/usr/bin/env bash
# ============================================================
# SoloptiLinkAI v101.0 - Error Intelligence Engine
# エラーパターン学習 × 予防注入 × 再発防止
#
# 問題: 同じエラーが毎セッション繰り返される。
# - 「fetch先のAPIルートがない」→ 何度も修正ループ
# - 「Prisma型とzod型の不一致」→ 毎回同じ修正
# - 「import先ファイルが存在しない」→ 繰り返し発生
#
# 解決: エラーをパターン化して記録し、次のAI呼び出し時に
# 「このドメインでよく起きるエラー」を予防的にプロンプトに注入。
# ============================================================

[[ -n "${_ERROR_INTELLIGENCE_LOADED:-}" ]] && return 0
_ERROR_INTELLIGENCE_LOADED=1

EI_VERSION="101.0"
EI_INITIALIZED=false
EI_DB_DIR=""
EI_PATTERNS_INJECTED=0
EI_PATTERNS_TOTAL=0

# エラーパターンDB（セッション内インメモリ + ファイル永続化）
declare -A _EI_PATTERNS=()          # pattern_id → count
declare -A _EI_PATTERN_DESC=()      # pattern_id → description
declare -A _EI_PATTERN_FIX=()       # pattern_id → fix instruction
declare -A _EI_PATTERN_DOMAIN=()    # pattern_id → domain(s)

# ============================================================
# 初期化
# ============================================================
ei_init() {
    EI_DB_DIR="${SESSION_LOG_DIR:-/tmp}/error_intelligence"
    mkdir -p "$EI_DB_DIR" 2>/dev/null || true

    # 永続化DBから既知パターンをロード
    _ei_load_patterns

    # 組み込みパターン（過去の分析で判明した頻出エラー）
    _ei_register_builtin_patterns

    EI_INITIALIZED=true
    return 0
}

# ============================================================
# 組み込みパターン登録（実際の頻出エラーから抽出）
# ============================================================
_ei_register_builtin_patterns() {
    # Pattern 1: fetch先にAPIルートがない
    _ei_add_pattern "fetch_no_route" \
        "フロントエンドのfetch()呼び出しに対応するAPIルートが存在しない" \
        "fetch()のURLパスと完全に一致するapp/api/xxx/route.tsを必ず作成してください。fetchパスが/api/itemsなら、app/api/items/route.tsが必須です。" \
        "all"

    # Pattern 2: Prisma型とzodスキーマの不一致
    _ei_add_pattern "prisma_zod_mismatch" \
        "Prismaモデルのフィールドがzodバリデーションスキーマに含まれていない" \
        "Prismaスキーマの全フィールド（id,createdAt,updatedAt除く）をzodスキーマにも定義してください。型も一致させてください（String→z.string(), Int→z.number().int(), Float→z.number(), Boolean→z.boolean()）。" \
        "all"

    # Pattern 3: import先ファイルが存在しない
    _ei_add_pattern "broken_import" \
        "相対importのパスに対応するファイルが存在しない" \
        "import文を書く前に、import先のファイルが既に存在することを確認してください。存在しない場合は先にファイルを作成してください。@/lib/prismaをimportする場合、lib/prisma.tsが必須です。" \
        "all"

    # Pattern 4: 環境変数の未定義
    _ei_add_pattern "undefined_env" \
        "process.env.XXXを使っているが.envに定義がない" \
        "process.env.XXXを使う場合、.envファイルにXXX=値を定義し、.env.exampleにもXXX=を追加してください。" \
        "all"

    # Pattern 5: useStateにハードコード配列
    _ei_add_pattern "hardcoded_state" \
        "useStateの初期値にハードコードされたオブジェクト配列がある" \
        "useState([{id:1,name:'...'}, ...])は禁止です。useState([])で初期化し、useEffectでAPIからfetchしてください。" \
        "all"

    # Pattern 6: 空のイベントハンドラ
    _ei_add_pattern "empty_handler" \
        "onClick等のイベントハンドラが空または未実装" \
        "onClick={() => {}}は禁止です。必ず実際のAPI呼び出しまたは状態更新を実装してください。" \
        "all"

    # Pattern 7: Next.js リンク先ページ不存在
    _ei_add_pattern "broken_link" \
        "href='/xxx'のリンク先に対応するpage.tsxが存在しない" \
        "href='/items'を設定する場合、app/items/page.tsxが存在することを確認してください。" \
        "all"

    # Pattern 8: CRM固有 - パイプラインステータス未定義
    _ei_add_pattern "crm_pipeline_missing" \
        "CRMのDealモデルにstageフィールドがないまたは遷移ロジックが未実装" \
        "CRMではDealモデルにstage(qualification/proposal/negotiation/closed_won/closed_lost)を必ず定義し、ステージ変更APIも実装してください。" \
        "crm"

    # Pattern 9: SaaS固有 - テナント分離漏れ
    _ei_add_pattern "saas_tenant_leak" \
        "SaaSでテナントIDによるデータフィルタリングが漏れている" \
        "SaaSの全データ取得クエリにwhere: { tenantId }を追加してください。テナント分離なしのクエリは禁止です。" \
        "saas"

    # Pattern 10: EC固有 - 在庫チェック漏れ
    _ei_add_pattern "ec_stock_missing" \
        "ECのカート追加/注文時に在庫チェックがない" \
        "カート追加・注文確定時にproduct.stockとquantityを比較する在庫チェックをトランザクション内で実装してください。" \
        "ecommerce"

    # ============================================================
    # Round 1 Training (2026-03-21) admin-dashboard実戦から学習
    # ============================================================

    # Pattern 11: Prisma datasource mismatch
    _ei_add_pattern "prisma_provider_mismatch" \
        "Prismaのdatasource providerが実際のDB(PostgreSQL)と一致しない" \
        "Neon/PostgreSQLを使う場合、prisma/schema.prismaのproviderは必ず'postgresql'にしてください。'sqlite'のままだとmigrationが失敗します。" \
        "all"

    # Pattern 12: Frontend→API path mismatch
    _ei_add_pattern "frontend_api_path_mismatch" \
        "フロントエンドが/api/v1/xxxをfetchするが、APIルートは/api/v1/admin/xxxにある" \
        "フロントエンドのfetchパスとAPIルートのパスを完全一致させてください。/api/v1/admin/usersにルートがある場合、フロントも/api/v1/admin/usersをfetchしてください。パスの省略（/api/v1/users→/api/v1/admin/users）はエラーの原因です。" \
        "all"

    # Pattern 13: DB関数未実装
    _ei_add_pattern "db_function_missing" \
        "APIルートがlib/db.tsの未実装関数をimportしている" \
        "新しいAPIルートを作る前に、必要なDB関数が全てlib/db.tsにexportされていることを確認してください。estimates/invoicesなどの新機能を追加する場合、CRUD関数（create, get, list, update, delete）を全て先に定義してください。" \
        "all"

    # Pattern 14: ENV変数未定義
    _ei_add_pattern "env_vars_missing_critical" \
        "JWT_SECRETなどセキュリティ関連のENV変数が.envに未定義" \
        "process.env.XXXを使う場合、.env.localとenv.exampleの両方に定義してください。特にJWT_SECRET, DATABASE_URL, RESEND_API_KEYは必須です。" \
        "all"

    # Pattern 15: zod v4 API差異
    _ei_add_pattern "zod_v4_api_change" \
        "zod v4では.errorsではなく.issuesを使う" \
        "zodのsafeParse結果のエラーアクセスは parsed.error.issues[0]?.message です。parsed.error.errors は zod v3以前のAPIです。zod v4を使う場合は必ず.issuesを使ってください。" \
        "all"

    # Pattern 16: 型の曖昧さ（Record<string, any>）
    _ei_add_pattern "loose_typing" \
        "DB関数の引数がanyやRecord<string, any>で型安全性がない" \
        "DB関数の引数には具体的な型を定義してください。最低限、必須フィールドは明示的に型定義し、オプショナルフィールドは?をつけてください。" \
        "all"

    # ============================================================
    # Round 9-11 Training (2026-03-21) 追加学習
    # ============================================================

    # Pattern 17: .env と .env.local の優先順位問題
    _ei_add_pattern "env_file_priority" \
        "Prisma CLIは.envを優先読みし、.env.localは無視する" \
        ".envファイルのDATABASE_URLがPrismaスキーマのproviderと一致していることを確認してください。Prisma CLIは.env.localではなく.envを読みます。PostgreSQL使用時は.envにも正しいPostgreSQL URLを設定してください。" \
        "all"

    # Pattern 18: Prismaモデルの全フィールドをAPI出力に含める
    _ei_add_pattern "schema_field_in_api_response" \
        "PrismaモデルのフィールドがAPIレスポンスに含まれていない" \
        "Prismaスキーマのモデルフィールドは全てAPIレスポンスに含めてください。特にcompletedAt, deletedAt等の状態フィールドを忘れがちです。formatResponse時にフィールドを省略しないでください。" \
        "all"

    # Pattern 19: TODOコメントの放置
    _ei_add_pattern "todo_in_response" \
        "APIレスポンスにTODOコメント付きのnull/空配列が残っている" \
        "APIレスポンスにproject: null // TODOやtags: [] // TODOを残さないでください。実装しない場合はフィールド自体を省略してください。nullを返すとフロントエンドが混乱します。" \
        "all"

    # Pattern 20: .nextディレクトリの重複route検出
    _ei_add_pattern "next_build_cache_confusion" \
        ".next/types/内のroute.tsが検証対象に混入する" \
        "ファイル検索時に.nextディレクトリを必ず除外してください。grep/find実行時は-not -path '*/.next/*'を付けてください。ビルドキャッシュのroute.tsは本体ではありません。" \
        "all"
}

# ============================================================
# パターン追加（内部）
# ============================================================
_ei_add_pattern() {
    local id="$1" desc="$2" fix="$3" domain="$4"
    _EI_PATTERNS["$id"]="${_EI_PATTERNS[$id]:-0}"
    _EI_PATTERN_DESC["$id"]="$desc"
    _EI_PATTERN_FIX["$id"]="$fix"
    _EI_PATTERN_DOMAIN["$id"]="$domain"
    EI_PATTERNS_TOTAL=$((EI_PATTERNS_TOTAL + 1))
}

# ============================================================
# エラー記録（Real Validator / Live Verification から呼ばれる）
# ============================================================
ei_record_error() {
    local error_type="$1"    # fetch_no_route, prisma_zod_mismatch, etc.
    local context="$2"       # 追加コンテキスト
    local domain="${3:-all}"

    if [[ -n "${_EI_PATTERNS[$error_type]+x}" ]]; then
        _EI_PATTERNS["$error_type"]=$(( ${_EI_PATTERNS[$error_type]} + 1 ))
    else
        # 未知のパターン → 新規登録
        _ei_add_pattern "$error_type" "$context" "このエラーを修正してください: $context" "$domain"
        _EI_PATTERNS["$error_type"]=1
    fi

    # 永続化
    _ei_save_pattern "$error_type"
}

# ============================================================
# 予防プロンプト生成（ai_callのpre-hookから呼ばれる）
# ============================================================
ei_build_prevention_prompt() {
    local domain="${1:-all}"
    local result=""
    local injected=0

    # 頻出パターン（count >= 1）を予防注入
    for pattern_id in "${!_EI_PATTERNS[@]}"; do
        local count="${_EI_PATTERNS[$pattern_id]}"
        [[ "$count" -lt 1 ]] && continue

        local pat_domain="${_EI_PATTERN_DOMAIN[$pattern_id]:-all}"
        # ドメインフィルタ
        if [[ "$pat_domain" != "all" && "$pat_domain" != "$domain" ]]; then
            continue
        fi

        local fix="${_EI_PATTERN_FIX[$pattern_id]:-}"
        if [[ -n "$fix" ]]; then
            result+="- ${fix}
"
            injected=$((injected + 1))
        fi
    done

    EI_PATTERNS_INJECTED=$injected

    if [[ -n "$result" ]]; then
        echo "
=== エラー予防ルール（過去のエラーパターンから自動生成） ===
以下のルールは過去のビルドで検出された実際のエラーから学習したものです。必ず遵守してください:
${result}"
    fi
}

# ============================================================
# Real Validator結果からパターン自動検出
# ============================================================
ei_learn_from_rv() {
    local rv_report="$1"
    local domain="${2:-all}"

    [[ -z "$rv_report" ]] && return

    # TypeScriptエラーパターン検出
    if echo "$rv_report" | grep -q "TypeScriptコンパイルエラー"; then
        ei_record_error "typescript_compile" "TypeScriptコンパイルエラーが発生" "$domain"
    fi

    # import整合性エラーパターン検出
    if echo "$rv_report" | grep -q "インポート整合性エラー"; then
        ei_record_error "broken_import" "存在しないファイルへのimport" "$domain"
    fi

    # Prismaエラーパターン検出
    if echo "$rv_report" | grep -q "Prismaスキーマエラー"; then
        ei_record_error "prisma_schema_error" "Prismaスキーマ定義エラー" "$domain"
    fi
}

# ============================================================
# Live Verification結果からパターン自動検出
# ============================================================
ei_learn_from_lv() {
    local lv_report="$1"
    local domain="${2:-all}"

    [[ -z "$lv_report" ]] && return

    if echo "$lv_report" | grep -q "Schema.*API.*整合性"; then
        ei_record_error "prisma_zod_mismatch" "Schema↔API型不一致" "$domain"
    fi

    if echo "$lv_report" | grep -q "API.*Frontend.*整合性"; then
        ei_record_error "fetch_no_route" "fetch先APIルート不存在" "$domain"
    fi

    if echo "$lv_report" | grep -q "ルーティング整合性"; then
        ei_record_error "broken_link" "リンク先ページ不存在" "$domain"
    fi

    if echo "$lv_report" | grep -q "環境変数整合性"; then
        ei_record_error "undefined_env" "環境変数未定義" "$domain"
    fi
}

# ============================================================
# 永続化
# ============================================================
_ei_save_pattern() {
    local pattern_id="$1"
    [[ -z "$EI_DB_DIR" ]] && return

    local count="${_EI_PATTERNS[$pattern_id]:-0}"
    local desc="${_EI_PATTERN_DESC[$pattern_id]:-}"
    local fix="${_EI_PATTERN_FIX[$pattern_id]:-}"
    local domain="${_EI_PATTERN_DOMAIN[$pattern_id]:-all}"

    echo "${count}|${desc}|${fix}|${domain}" > "${EI_DB_DIR}/${pattern_id}.pat" 2>/dev/null || true
}

_ei_load_patterns() {
    [[ -z "$EI_DB_DIR" || ! -d "$EI_DB_DIR" ]] && return

    for pat_file in "${EI_DB_DIR}"/*.pat; do
        [[ -f "$pat_file" ]] || continue
        local pattern_id
        pattern_id=$(basename "$pat_file" .pat)
        local content
        content=$(cat "$pat_file" 2>/dev/null || echo "")
        [[ -z "$content" ]] && continue

        IFS='|' read -r count desc fix domain <<< "$content"
        _EI_PATTERNS["$pattern_id"]="${count:-0}"
        _EI_PATTERN_DESC["$pattern_id"]="${desc:-}"
        _EI_PATTERN_FIX["$pattern_id"]="${fix:-}"
        _EI_PATTERN_DOMAIN["$pattern_id"]="${domain:-all}"
    done
}

# ============================================================
# レポート
# ============================================================
ei_report() {
    echo "=== Error Intelligence v${EI_VERSION} ==="
    echo "  Known patterns: ${EI_PATTERNS_TOTAL}"
    echo "  Injected preventions: ${EI_PATTERNS_INJECTED}"
    echo "  Top errors:"
    # ソートして上位5件表示
    for pid in "${!_EI_PATTERNS[@]}"; do
        local c="${_EI_PATTERNS[$pid]}"
        [[ "$c" -gt 0 ]] && echo "    ${pid}: ${c}回 - ${_EI_PATTERN_DESC[$pid]:0:60}"
    done | sort -t: -k2 -rn | head -5
}

ei_score() {
    # 予防注入が有効ならスコア加点
    if [[ $EI_PATTERNS_INJECTED -gt 0 ]]; then
        echo "85"
    else
        echo "70"
    fi
}

# ============================================================
# v2001.0: 欠落していた関数の実装
# healer.shからei_learn_pattern()が呼ばれるが未定義だった問題を修正
# chain.shエラー回復パイプラインからei_analyze_and_predict()が呼ばれる
# ============================================================

# エラーパターンを記録・学習（healer.shから呼ばれる）
ei_learn_pattern() {
    local error_msg="${1:-}" error_file="${2:-}" fix_applied="${3:-}" success="${4:-0}"
    [[ -z "$error_msg" ]] && return 0

    # パターンIDを生成（エラーメッセージの正規化ハッシュ）
    local normalized
    normalized=$(echo "$error_msg" | sed 's/[0-9]\+/N/g; s/\/[^ ]*//g' | head -c 100)
    local pattern_id
    pattern_id=$(echo "$normalized" | md5sum 2>/dev/null | cut -c1-8 || echo "unknown")

    # インメモリDBに記録
    local current_count="${_EI_PATTERNS[$pattern_id]:-0}"
    _EI_PATTERNS[$pattern_id]=$((current_count + 1))
    _EI_PATTERN_DESC[$pattern_id]="${error_msg:0:200}"

    if [[ "$success" == "1" ]] && [[ -n "$fix_applied" ]]; then
        _EI_PATTERN_FIX[$pattern_id]="${fix_applied:0:200}"
    fi

    EI_PATTERNS_TOTAL=$((EI_PATTERNS_TOTAL + 1))

    # 永続化（JSONLファイルに追記）
    if [[ -n "${EI_DB_DIR:-}" ]]; then
        local db_file="${EI_DB_DIR}/learned_patterns.jsonl"
        local timestamp
        timestamp=$(date -u '+%Y-%m-%dT%H:%M:%SZ')
        echo "{\"ts\":\"${timestamp}\",\"pid\":\"${pattern_id}\",\"msg\":\"${error_msg:0:150}\",\"file\":\"${error_file}\",\"fix\":\"${fix_applied:0:150}\",\"ok\":${success}}" >> "$db_file" 2>/dev/null || true
    fi

    return 0
}

# エラー分析と予測修復（chain.shエラー回復パイプラインから呼ばれる）
ei_analyze_and_predict() {
    local project_dir="${1:-.}"
    echo -e "  [EI v${EI_VERSION}] プロジェクトエラー予測分析中..." >&2

    local issues_found=0

    # 1. 過去のパターンDBから頻出エラーを予測
    if [[ ${#_EI_PATTERNS[@]} -gt 0 ]]; then
        echo -e "  [EI] 既知パターン: ${#_EI_PATTERNS[@]}件" >&2
        local high_freq_count=0
        for pid in "${!_EI_PATTERNS[@]}"; do
            if [[ ${_EI_PATTERNS[$pid]} -ge 3 ]]; then
                high_freq_count=$((high_freq_count + 1))
                if [[ -n "${_EI_PATTERN_FIX[$pid]:-}" ]]; then
                    echo -e "  [EI] 高頻度エラー [${pid}]: 修正パターンあり → 予防注入可能" >&2
                else
                    echo -e "  [EI] ⚠ 高頻度エラー [${pid}]: ${_EI_PATTERN_DESC[$pid]:0:80}" >&2
                fi
            fi
        done
        [[ $high_freq_count -gt 0 ]] && echo -e "  [EI] 高頻度エラー: ${high_freq_count}パターン" >&2
    fi

    # 2. プロジェクト構造から潜在的問題を検出
    # 2a. TypeScript型エラー予測
    if [[ -f "${project_dir}/tsconfig.json" ]]; then
        local strict_mode
        strict_mode=$(grep -c '"strict".*true' "${project_dir}/tsconfig.json" 2>/dev/null || echo "0")
        if [[ "$strict_mode" -eq 0 ]]; then
            echo -e "  [EI] ⚠ tsconfig.json: strict mode OFF → 型エラーのリスク" >&2
            issues_found=$((issues_found + 1))
        fi
    fi

    # 2b. Prismaスキーマと.envの整合性
    if [[ -f "${project_dir}/prisma/schema.prisma" ]]; then
        local db_provider
        db_provider=$(grep 'provider.*=' "${project_dir}/prisma/schema.prisma" 2>/dev/null | head -1 || echo "")
        if [[ -f "${project_dir}/.env" ]]; then
            local db_url
            db_url=$(grep 'DATABASE_URL' "${project_dir}/.env" 2>/dev/null | head -1 || echo "")
            if [[ -z "$db_url" ]]; then
                echo -e "  [EI] ⚠ DATABASE_URLが.envに未設定 → DB接続エラーのリスク" >&2
                issues_found=$((issues_found + 1))
            fi
        fi
    fi

    # 2c. 壊れたインポートパスの検出
    local broken_imports=0
    if [[ -d "${project_dir}/app" ]] || [[ -d "${project_dir}/src" ]]; then
        local search_dirs=""
        [[ -d "${project_dir}/app" ]] && search_dirs="${project_dir}/app"
        [[ -d "${project_dir}/src" ]] && search_dirs="${search_dirs} ${project_dir}/src"
        [[ -d "${project_dir}/lib" ]] && search_dirs="${search_dirs} ${project_dir}/lib"
        [[ -d "${project_dir}/components" ]] && search_dirs="${search_dirs} ${project_dir}/components"

        if [[ -n "$search_dirs" ]]; then
            broken_imports=$(grep -rn "from ['\"]@/" $search_dirs 2>/dev/null | while read -r line; do
                local import_path
                import_path=$(echo "$line" | grep -oP "from ['\"]@/([^'\"]+)" | sed "s/from ['\"]@\///" 2>/dev/null || echo "")
                if [[ -n "$import_path" ]]; then
                    local resolved="${project_dir}/${import_path}"
                    local found=false
                    for ext in "" ".ts" ".tsx" ".js" ".jsx"; do
                        [[ -f "${resolved}${ext}" ]] && found=true && break
                    done
                    [[ "$found" == "false" ]] && echo "BROKEN"
                fi
            done 2>/dev/null | wc -l || echo "0")

            if [[ "$broken_imports" -gt 0 ]]; then
                echo -e "  [EI] ⚠ 壊れたインポートパス: ${broken_imports}件 → ビルドエラーのリスク" >&2
                issues_found=$((issues_found + broken_imports))
            fi
        fi
    fi

    echo -e "  [EI] 分析完了: 潜在的問題 ${issues_found}件" >&2
    return 0
}

# Module Registry 自己登録
if type -t _mr_register &>/dev/null; then
    _mr_register \
        --name "error-intelligence" \
        --version "$EI_VERSION" \
        --description "エラーパターン学習 - 頻出エラー自動検出×予防プロンプト注入×再発防止" \
        --init "ei_init" \
        --report "ei_report" \
        --score "ei_score" \
        --enable-var "ENABLE_ERROR_INTELLIGENCE" \
        --cli-flags "--error-intelligence:--no-error-intelligence"
fi

# v2003.1: source時のexit codeを確実に0にする
true
