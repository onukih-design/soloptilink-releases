#!/usr/bin/env bash
# SoloptiLinkAI v2033.2 - Solutions Prefilter (SPF)
# learning/solutions/index.jsonl を読み込み、
# 「再発する可能性が高い未解決パターン」と「実証済み解決パターン」を分離して提示する。
#
# 設計方針:
#   - 読み取り専用
#   - DUE から呼び出されて report 内に inline で埋め込まれる
#   - success_rate=null は「未実証」、success_rate>=80 は「proven」、それ未満は「risky」と分類

[[ -n "${_SOLUTIONS_PREFILTER_LOADED:-}" ]] && return 0
_SOLUTIONS_PREFILTER_LOADED=1

SPF_VERSION="2033.2"
SPF_HOME="${SOLOPTILINK_HOME:-$HOME/.soloptilink}"
SPF_INDEX="${SPF_HOME}/learning/solutions/index.jsonl"

_spf_field() {
    # $1: line, $2: field name (string)
    local line="$1" field="$2"
    echo "$line" | grep -oE "\"${field}\":[^,}]*" | head -1 | sed -E "s/^\"${field}\"://; s/^\"//; s/\"$//"
}

# ============================================================
# サマリ生成 (DUE から呼ばれる)
# ============================================================
spf_summary() {
    if [[ ! -f "$SPF_INDEX" ]]; then
        echo "- SPF: solutions/index.jsonl が未生成 (IER 未起動 or 学習データ無し)"
        return 0
    fi

    local total proven risky unproven
    total=$(wc -l < "$SPF_INDEX" 2>/dev/null | tr -d ' ')
    proven=0
    risky=0
    unproven=0

    local proven_list=()
    local risky_list=()
    local unproven_list=()

    while IFS= read -r line; do
        [[ -z "$line" ]] && continue
        local sig rate dom
        sig=$(_spf_field "$line" "error_signature")
        rate=$(_spf_field "$line" "success_rate")
        dom=$(_spf_field "$line" "domain")
        if [[ "$rate" == "null" ]]; then
            unproven=$((unproven + 1))
            unproven_list+=("${sig} (${dom})")
        elif [[ "$rate" =~ ^[0-9]+$ ]] && (( rate >= 80 )); then
            proven=$((proven + 1))
            proven_list+=("${sig} (${dom}, ${rate}%)")
        else
            risky=$((risky + 1))
            risky_list+=("${sig} (${dom}, ${rate}%)")
        fi
    done < "$SPF_INDEX"

    echo "- SPF total: ${total} (proven=${proven} / risky=${risky} / unproven=${unproven})"
    if (( proven > 0 )); then
        echo "- proven solutions (再発時 0-shot 適用可):"
        local s
        for s in "${proven_list[@]}"; do
            echo "    - ${s}"
        done
    fi
    if (( risky > 0 )); then
        echo "- risky solutions (success_rate < 80, 注意):"
        local s
        for s in "${risky_list[@]}"; do
            echo "    - ${s}"
        done
    fi
    if (( unproven > 0 )); then
        echo "- unproven (まだ実走検証されていない解決テンプレ):"
        local s
        for s in "${unproven_list[@]}"; do
            echo "    - ${s}"
        done
    fi
}

# CLI 直接実行
if [[ "${BASH_SOURCE[0]}" == "${0}" ]]; then
    case "${1:-summary}" in
        summary) spf_summary ;;
        version) echo "$SPF_VERSION" ;;
        *) echo "usage: $0 {summary|version}" >&2; exit 2 ;;
    esac
fi
