#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v307.0 - Project Management Generator
# =============================================================================
# プロジェクト管理自動生成: プロジェクトモデル/カンバン/ガントチャート/時間管理/チーム
#
# 全globals: PMG_ prefix
# =============================================================================

[[ -n "${_PROJECT_MANAGEMENT_GENERATOR_LOADED:-}" ]] && return 0
_PROJECT_MANAGEMENT_GENERATOR_LOADED=1

declare -g PMG_VERSION="307.0"
declare -g PMG_INITIALIZED=false
declare -g PMG_GENERATED_COUNT=0
declare -g ENABLE_PROJECT_MANAGEMENT_GENERATOR="${ENABLE_PROJECT_MANAGEMENT_GENERATOR:-true}"

readonly PMG_GREEN="${CLR_GREEN:-\033[0;32m}"
readonly PMG_CYAN="${CLR_CYAN:-\033[0;36m}"
readonly PMG_BOLD="${CLR_BOLD:-\033[1m}"
readonly PMG_NC="${CLR_NC:-\033[0m}"

_pmg_log() { echo -e "  ${PMG_CYAN}[PMG]${PMG_NC} $*" >&2; }
_pmg_ok()  { echo -e "  ${PMG_GREEN}[PMG] OK${PMG_NC} $*" >&2; }

pmg_init() { PMG_INITIALIZED=true; PMG_GENERATED_COUNT=0; return 0; }
pmg_report() { [[ "$PMG_INITIALIZED" != "true" ]] && return 0; echo -e "\n  ${PMG_BOLD}--- Project Management Generator v${PMG_VERSION} ---${PMG_NC}" >&2; echo -e "  生成数: ${PMG_GENERATED_COUNT}" >&2; }
pmg_score() { [[ "$PMG_INITIALIZED" != "true" ]] && { echo "0"; return; }; local s=50; [[ $PMG_GENERATED_COUNT -ge 3 ]] && s=80; [[ $PMG_GENERATED_COUNT -ge 5 ]] && s=95; echo "$s"; }
pmg_init_message() { echo -e "  ${PMG_GREEN}v${PMG_VERSION} project-management-generator: プロジェクト管理自動生成${PMG_NC}" >&2; }

# =============================================================================
# _pmg_generate_project_model() - Project model
# =============================================================================
_pmg_generate_project_model() {
    local project_dir="${1:-.}"
    _pmg_log "プロジェクトモデル生成"
    local prisma_dir="${project_dir}/prisma"
    mkdir -p "$prisma_dir"

    local snippet='
// --- Project Management Models (v307.0) ---
model Project {
  id          String   @id @default(cuid())
  name        String
  description String?  @db.Text
  status      ProjectStatus @default(ACTIVE)
  startDate   DateTime?
  endDate     DateTime?
  ownerId     String
  tasks       Task[]
  members     ProjectMember[]
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}

enum ProjectStatus { PLANNING ACTIVE ON_HOLD COMPLETED CANCELLED }

model Task {
  id          String   @id @default(cuid())
  title       String
  description String?  @db.Text
  status      TaskStatus @default(TODO)
  priority    TaskPriority @default(MEDIUM)
  projectId   String
  project     Project  @relation(fields: [projectId], references: [id], onDelete: Cascade)
  assigneeId  String?
  parentId    String?
  position    Int      @default(0)
  startDate   DateTime?
  dueDate     DateTime?
  estimatedHours Float?
  timeEntries TimeEntry[]
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt
}

enum TaskStatus { TODO IN_PROGRESS IN_REVIEW DONE BLOCKED }
enum TaskPriority { LOW MEDIUM HIGH URGENT }

model ProjectMember {
  id        String @id @default(cuid())
  projectId String
  project   Project @relation(fields: [projectId], references: [id], onDelete: Cascade)
  userId    String
  role      MemberRole @default(MEMBER)
  @@unique([projectId, userId])
}

enum MemberRole { OWNER ADMIN MEMBER VIEWER }

model TimeEntry {
  id        String   @id @default(cuid())
  taskId    String
  task      Task     @relation(fields: [taskId], references: [id], onDelete: Cascade)
  userId    String
  hours     Float
  note      String?
  date      DateTime @default(now())
  createdAt DateTime @default(now())
}'

    local schema_file="${prisma_dir}/schema.prisma"
    if [[ -f "$schema_file" ]] && ! grep -q "model Project" "$schema_file" 2>/dev/null; then
        echo "$snippet" >> "$schema_file"
    fi

    PMG_GENERATED_COUNT=$((PMG_GENERATED_COUNT + 1))
    _pmg_ok "プロジェクトモデル生成完了"
    return 0
}

# =============================================================================
# _pmg_generate_task_board() - Kanban task board
# =============================================================================
_pmg_generate_task_board() {
    local project_dir="${1:-.}"
    _pmg_log "カンバンボード生成"
    local comp_dir="${project_dir}/src/components/projects"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/TaskBoard.tsx" <<'EOF'
'use client';
import { useState, useCallback } from 'react';
import useSWR from 'swr';
import { GripVertical, Plus, Clock, AlertCircle, User } from 'lucide-react';

const fetcher = (url: string) => fetch(url).then(r => r.json());
const columns = [
  { id: 'TODO', label: 'To Do', color: '#94A3B8' },
  { id: 'IN_PROGRESS', label: '進行中', color: '#3B82F6' },
  { id: 'IN_REVIEW', label: 'レビュー', color: '#F59E0B' },
  { id: 'DONE', label: '完了', color: '#10B981' },
];
const priorityColors: Record<string, string> = { LOW: 'bg-gray-100 text-gray-600', MEDIUM: 'bg-blue-100 text-blue-600', HIGH: 'bg-orange-100 text-orange-600', URGENT: 'bg-red-100 text-red-600' };

export function TaskBoard({ projectId }: { projectId: string }) {
  const { data, mutate } = useSWR(`/api/projects/${projectId}/tasks`, fetcher);
  const [dragging, setDragging] = useState<string | null>(null);

  const moveTask = useCallback(async (taskId: string, status: string) => {
    try {
      await fetch(`/api/projects/${projectId}/tasks/${taskId}`, {
        method: 'PATCH', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status }),
      });
      mutate();
    } catch { /* silent */ }
  }, [projectId, mutate]);

  const tasks = data?.data || [];

  return (
    <div className="flex gap-4 overflow-x-auto pb-4">
      {columns.map(col => {
        const colTasks = tasks.filter((t: any) => t.status === col.id);
        return (
          <div key={col.id} className="flex-shrink-0 w-72 bg-gray-50 rounded-lg p-3"
            onDragOver={e => e.preventDefault()} onDrop={e => { e.preventDefault(); if (dragging) { moveTask(dragging, col.id); setDragging(null); } }}>
            <div className="flex items-center gap-2 mb-3">
              <div className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: col.color }} />
              <h3 className="font-medium text-sm">{col.label}</h3>
              <span className="text-xs text-gray-400 ml-auto">{colTasks.length}</span>
            </div>
            <div className="space-y-2">
              {colTasks.map((task: any) => (
                <div key={task.id} draggable onDragStart={() => setDragging(task.id)}
                  className="bg-white rounded-lg border p-3 cursor-grab hover:shadow-sm transition text-sm">
                  <p className="font-medium mb-2">{task.title}</p>
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className={`text-xs px-1.5 py-0.5 rounded ${priorityColors[task.priority] || ''}`}>{task.priority}</span>
                    {task.dueDate && <span className="text-xs text-gray-500 flex items-center gap-1"><Clock size={12} /> {new Date(task.dueDate).toLocaleDateString('ja-JP')}</span>}
                    {task.assigneeId && <span className="text-xs text-gray-400 flex items-center gap-1 ml-auto"><User size={12} /></span>}
                  </div>
                </div>
              ))}
            </div>
            <button className="w-full mt-2 text-sm text-gray-400 hover:text-gray-600 flex items-center justify-center gap-1 py-2 border border-dashed rounded-lg hover:bg-white">
              <Plus size={14} /> タスク追加
            </button>
          </div>
        );
      })}
    </div>
  );
}
EOF

    PMG_GENERATED_COUNT=$((PMG_GENERATED_COUNT + 1))
    _pmg_ok "カンバンボード生成完了"
    return 0
}

# =============================================================================
# _pmg_generate_gantt() - Gantt chart view
# =============================================================================
_pmg_generate_gantt() {
    local project_dir="${1:-.}"
    _pmg_log "ガントチャート生成"
    local comp_dir="${project_dir}/src/components/projects"
    mkdir -p "$comp_dir"

    cat > "${comp_dir}/GanttChart.tsx" <<'EOF'
'use client';
import useSWR from 'swr';
import { useMemo } from 'react';

const fetcher = (url: string) => fetch(url).then(r => r.json());
const DAY_WIDTH = 40;
const ROW_HEIGHT = 36;

function daysBetween(a: Date, b: Date) { return Math.ceil((b.getTime() - a.getTime()) / (1000 * 60 * 60 * 24)); }
const statusColors: Record<string, string> = { TODO: '#94A3B8', IN_PROGRESS: '#3B82F6', IN_REVIEW: '#F59E0B', DONE: '#10B981', BLOCKED: '#EF4444' };

export function GanttChart({ projectId }: { projectId: string }) {
  const { data, isLoading } = useSWR(`/api/projects/${projectId}/tasks`, fetcher);
  const tasks = data?.data || [];

  const { startDate, totalDays, months } = useMemo(() => {
    if (tasks.length === 0) return { startDate: new Date(), totalDays: 30, months: [] };
    const dates = tasks.flatMap((t: any) => [t.startDate, t.dueDate].filter(Boolean).map((d: string) => new Date(d)));
    if (dates.length === 0) return { startDate: new Date(), totalDays: 30, months: [] };
    const min = new Date(Math.min(...dates.map((d: Date) => d.getTime())));
    const max = new Date(Math.max(...dates.map((d: Date) => d.getTime())));
    min.setDate(min.getDate() - 2);
    max.setDate(max.getDate() + 7);
    const total = daysBetween(min, max);
    const m: { label: string; offset: number; width: number }[] = [];
    let cur = new Date(min);
    while (cur <= max) {
      const monthStart = new Date(cur.getFullYear(), cur.getMonth(), 1);
      const monthEnd = new Date(cur.getFullYear(), cur.getMonth() + 1, 0);
      const offset = daysBetween(min, monthStart < min ? min : monthStart) * DAY_WIDTH;
      const end = monthEnd > max ? max : monthEnd;
      const start = monthStart < min ? min : monthStart;
      m.push({ label: `${cur.getFullYear()}/${cur.getMonth() + 1}`, offset, width: daysBetween(start, end) * DAY_WIDTH });
      cur = new Date(cur.getFullYear(), cur.getMonth() + 1, 1);
    }
    return { startDate: min, totalDays: total, months: m };
  }, [tasks]);

  if (isLoading) return <div className="h-64 bg-gray-200 rounded animate-pulse" />;
  if (tasks.length === 0) return <p className="text-gray-500 text-center py-12">タスクがありません</p>;

  return (
    <div className="border rounded-lg overflow-auto">
      <div className="flex">
        <div className="w-48 flex-shrink-0 border-r bg-gray-50">
          <div className="h-10 border-b px-3 flex items-center font-medium text-sm">タスク</div>
          {tasks.map((t: any) => (
            <div key={t.id} className="h-9 border-b px-3 flex items-center text-sm truncate">{t.title}</div>
          ))}
        </div>
        <div className="flex-1 overflow-x-auto">
          <div style={{ width: totalDays * DAY_WIDTH, minWidth: '100%' }}>
            <div className="h-10 border-b flex relative">
              {months.map((m, i) => (
                <div key={i} className="absolute top-0 h-full flex items-center text-xs text-gray-500 px-2 border-l" style={{ left: m.offset, width: m.width }}>{m.label}</div>
              ))}
            </div>
            {tasks.map((task: any) => {
              const tStart = task.startDate ? new Date(task.startDate) : null;
              const tEnd = task.dueDate ? new Date(task.dueDate) : null;
              if (!tStart || !tEnd) return <div key={task.id} className="h-9 border-b" />;
              const left = daysBetween(startDate, tStart) * DAY_WIDTH;
              const width = Math.max(daysBetween(tStart, tEnd) * DAY_WIDTH, DAY_WIDTH);
              return (
                <div key={task.id} className="h-9 border-b relative">
                  <div className="absolute top-1.5 h-6 rounded text-xs text-white flex items-center px-2 truncate"
                    style={{ left, width, backgroundColor: statusColors[task.status] || '#94A3B8' }}>
                    {task.title}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}
EOF

    PMG_GENERATED_COUNT=$((PMG_GENERATED_COUNT + 1))
    _pmg_ok "ガントチャート生成完了"
    return 0
}

# =============================================================================
# _pmg_generate_time_tracking() - Time tracking
# =============================================================================
_pmg_generate_time_tracking() {
    local project_dir="${1:-.}"
    _pmg_log "時間管理生成"

    local api_dir="${project_dir}/src/app/api/projects/[projectId]/time-entries"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest, { params }: { params: { projectId: string } }) {
  try {
    const taskId = req.nextUrl.searchParams.get('taskId');
    const userId = req.nextUrl.searchParams.get('userId');
    const where: any = { task: { projectId: params.projectId } };
    if (taskId) where.taskId = taskId;
    if (userId) where.userId = userId;

    const entries = await prisma.timeEntry.findMany({ where, include: { task: { select: { title: true } } }, orderBy: { date: 'desc' }, take: 100 });
    const totalHours = entries.reduce((sum: number, e: any) => sum + e.hours, 0);
    return NextResponse.json({ data: entries, totalHours });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch time entries' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const { taskId, userId, hours, note, date } = await req.json();
    if (!taskId || !userId || !hours) return NextResponse.json({ error: 'taskId, userId, hours required' }, { status: 400 });
    const entry = await prisma.timeEntry.create({ data: { taskId, userId, hours, note, date: date ? new Date(date) : new Date() } });
    return NextResponse.json(entry, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to create time entry' }, { status: 500 });
  }
}
EOF

    PMG_GENERATED_COUNT=$((PMG_GENERATED_COUNT + 1))
    _pmg_ok "時間管理API生成完了"
    return 0
}

# =============================================================================
# _pmg_generate_team_management() - Team/member management
# =============================================================================
_pmg_generate_team_management() {
    local project_dir="${1:-.}"
    _pmg_log "チーム管理生成"

    local api_dir="${project_dir}/src/app/api/projects/[projectId]/members"
    mkdir -p "$api_dir"

    cat > "${api_dir}/route.ts" <<'EOF'
import { NextRequest, NextResponse } from 'next/server';
import { prisma } from '@/lib/prisma';

export async function GET(req: NextRequest, { params }: { params: { projectId: string } }) {
  try {
    const members = await prisma.projectMember.findMany({
      where: { projectId: params.projectId },
      orderBy: { role: 'asc' },
    });
    return NextResponse.json({ data: members });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to fetch members' }, { status: 500 });
  }
}

export async function POST(req: NextRequest, { params }: { params: { projectId: string } }) {
  try {
    const { userId, role } = await req.json();
    if (!userId) return NextResponse.json({ error: 'userId required' }, { status: 400 });
    const member = await prisma.projectMember.create({ data: { projectId: params.projectId, userId, role: role || 'MEMBER' } });
    return NextResponse.json(member, { status: 201 });
  } catch (error: any) {
    if (error.code === 'P2002') return NextResponse.json({ error: 'Already a member' }, { status: 409 });
    return NextResponse.json({ error: 'Failed to add member' }, { status: 500 });
  }
}

export async function DELETE(req: NextRequest, { params }: { params: { projectId: string } }) {
  try {
    const { userId } = await req.json();
    if (!userId) return NextResponse.json({ error: 'userId required' }, { status: 400 });
    await prisma.projectMember.delete({ where: { projectId_userId: { projectId: params.projectId, userId } } });
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json({ error: 'Failed to remove member' }, { status: 500 });
  }
}
EOF

    PMG_GENERATED_COUNT=$((PMG_GENERATED_COUNT + 1))
    _pmg_ok "チーム管理API生成完了"
    return 0
}

# =============================================================================
# Module Registration
# =============================================================================
_mr_register \
    --name "project-management-generator" \
    --version "307.0" \
    --description "プロジェクト管理自動生成（カンバン/ガント/時間管理/チーム）" \
    --init "pmg_init" \
    --report "pmg_report" \
    --score "pmg_score" \
    --enable-var "ENABLE_PROJECT_MANAGEMENT_GENERATOR" \
    --cli-flags "--project-mgmt:--no-project-mgmt" \
    --init-msg "pmg_init_message"
