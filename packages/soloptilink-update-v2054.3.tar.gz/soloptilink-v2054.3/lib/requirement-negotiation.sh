#!/usr/bin/env bash
# =============================================================================
# SoloptiLinkAI v483.0 - Requirement Negotiation Engine
# =============================================================================
# 要件間の矛盾・競合を検出し、実現可能性を評価して代替案を提案する。
# トレードオフ分析により最適な要件セットを交渉・決定するエンジン。
#
# Functions:
#   _rn_init                  - 初期化
#   _rn_detect_conflicts      - 要件間矛盾の検出
#   _rn_suggest_alternatives  - 代替案の提案
#   _rn_validate_feasibility  - 実現可能性の検証
#   _rn_analyze_tradeoffs     - トレードオフ分析
#   _rn_prioritize            - 要件の優先順位付け
#   _rn_report                - レポート出力
#   _rn_score                 - モジュールスコア(0-100)
#
# Globals: RN_ prefix
# =============================================================================

[[ -n "${_REQUIREMENT_NEGOTIATION_LOADED:-}" ]] && return 0
_REQUIREMENT_NEGOTIATION_LOADED=1

RN_VERSION="483.0"
RN_INITIALIZED=false

# --- Storage ---
RN_DATA_DIR=""
RN_CONFLICT_LOG=""
RN_DECISION_LOG=""

# --- State ---
RN_TOTAL_REQUIREMENTS=0
RN_CONFLICTS_DETECTED=0
RN_ALTERNATIVES_SUGGESTED=0
RN_FEASIBILITY_CHECKS=0

# --- Requirement Structures ---
declare -g -A _RN_REQUIREMENTS=()
declare -g -A _RN_REQ_PRIORITY=()
declare -g -A _RN_REQ_EFFORT=()
declare -g -A _RN_REQ_FEASIBILITY=()
declare -g -a _RN_CONFLICTS=()
declare -g -A _RN_ALTERNATIVES=()
declare -g -A _RN_TRADEOFFS=()

# Known conflict patterns
declare -g -A _RN_CONFLICT_PATTERNS=(
    ["realtime+sqlite"]="リアルタイム機能はSQLiteの同時接続制限と競合する可能性"
    ["payment+no_auth"]="決済機能は認証なしでは実装不可"
    ["multi_tenant+simple"]="マルチテナントとシンプルさは両立困難"
    ["high_perf+full_orm"]="高パフォーマンス要件とフルORMの重さのトレードオフ"
    ["seo+spa"]="SEO最適化とSPAの相性問題(SSR/ISR推奨)"
    ["offline+realtime"]="オフライン対応とリアルタイム同期の複雑性"
    ["zero_downtime+monolith"]="ゼロダウンタイムデプロイとモノリスの制約"
)

# =============================================================================
# 初期化
# =============================================================================
_rn_init() {
    local project_dir="${PROJECT_DIR:-.}"
    RN_DATA_DIR="${project_dir}/.soloptilink/rn"
    RN_CONFLICT_LOG="${RN_DATA_DIR}/conflicts.jsonl"
    RN_DECISION_LOG="${RN_DATA_DIR}/decisions.jsonl"

    mkdir -p "$RN_DATA_DIR"

    RN_INITIALIZED=true
    return 0
}

# =============================================================================
# 要件間矛盾の検出
# =============================================================================
_rn_detect_conflicts() {
    local requirements="$1"

    [[ "$RN_INITIALIZED" != "true" ]] && _rn_init

    _RN_CONFLICTS=()
    local conflict_count=0

    # 要件リストをパース
    local req_list
    IFS=' ' read -ra req_list <<< "$requirements"

    RN_TOTAL_REQUIREMENTS=${#req_list[@]}

    # 既知の競合パターンチェック
    for pattern in "${!_RN_CONFLICT_PATTERNS[@]}"; do
        local req_a="${pattern%%+*}"
        local req_b="${pattern##*+}"
        local found_a=false found_b=false

        for req in "${req_list[@]}"; do
            [[ "$req" == *"$req_a"* ]] && found_a=true
            [[ "$req" == *"$req_b"* ]] && found_b=true
        done

        if [[ "$found_a" == "true" && "$found_b" == "true" ]]; then
            local desc="${_RN_CONFLICT_PATTERNS[$pattern]}"
            _RN_CONFLICTS+=("${req_a}+${req_b}: ${desc}")
            conflict_count=$((conflict_count + 1))
        fi
    done

    # リソース競合チェック（工数超過）
    local total_effort=0
    for req in "${req_list[@]}"; do
        local effort=4  # デフォルト工数
        case "$req" in
            *payment*|*決済*)        effort=8 ;;
            *multi_tenant*|*テナント*) effort=10 ;;
            *realtime*|*チャット*)     effort=6 ;;
            *auth*|*認証*)            effort=5 ;;
            *search*|*検索*)          effort=3 ;;
            *upload*|*アップロード*)   effort=4 ;;
            *analytics*|*分析*)       effort=5 ;;
            *i18n*|*多言語*)          effort=4 ;;
        esac
        _RN_REQ_EFFORT["$req"]=$effort
        total_effort=$((total_effort + effort))
    done

    if [[ $total_effort -gt 50 ]]; then
        _RN_CONFLICTS+=("RESOURCE: 総工数(${total_effort}h)が推奨上限(50h)を超過。機能の絞り込みを推奨")
        conflict_count=$((conflict_count + 1))
    fi

    RN_CONFLICTS_DETECTED=$conflict_count

    local timestamp
    timestamp=$(date +%s)
    echo "{\"ts\":${timestamp},\"reqs\":${RN_TOTAL_REQUIREMENTS},\"conflicts\":${conflict_count}}" >> "$RN_CONFLICT_LOG" 2>/dev/null

    echo "$conflict_count"
    return 0
}

# =============================================================================
# 代替案の提案
# =============================================================================
_rn_suggest_alternatives() {
    [[ "$RN_INITIALIZED" != "true" ]] && _rn_init

    _RN_ALTERNATIVES=()
    local alt_count=0

    for conflict in "${_RN_CONFLICTS[@]}"; do
        local key="${conflict%%:*}"

        case "$key" in
            "realtime+sqlite")
                _RN_ALTERNATIVES["$key"]="PostgreSQL + WebSocket基盤に変更 | SQLite + SSEポーリング(5秒間隔)にダウングレード"
                ;;
            "payment+no_auth")
                _RN_ALTERNATIVES["$key"]="認証機能を追加(JWT+bcrypt) | ゲストチェックアウトのみに限定"
                ;;
            "multi_tenant+simple")
                _RN_ALTERNATIVES["$key"]="Phase1:シングルテナント→Phase2:マルチテナント移行 | 行レベル分離でシンプルに実装"
                ;;
            "high_perf+full_orm")
                _RN_ALTERNATIVES["$key"]="ホットパスのみrawクエリ+その他はPrisma | Drizzle ORMに変更(軽量)"
                ;;
            "seo+spa")
                _RN_ALTERNATIVES["$key"]="Next.js SSR/ISRの活用 | 重要ページのみSSR、その他CSR"
                ;;
            "RESOURCE"*)
                _RN_ALTERNATIVES["resource"]="MVP機能に絞り込み(認証+CRUD+基本UI) | Phase分割(P1:コア機能, P2:拡張機能)"
                ;;
        esac

        alt_count=$((alt_count + 1))
    done

    RN_ALTERNATIVES_SUGGESTED=$alt_count

    for key in "${!_RN_ALTERNATIVES[@]}"; do
        echo "  [RN] 代替案 (${key}): ${_RN_ALTERNATIVES[$key]}" >&2
    done

    echo "$alt_count"
    return 0
}

# =============================================================================
# 実現可能性の検証
# =============================================================================
_rn_validate_feasibility() {
    local requirement="$1"
    local stack="${2:-nextjs}"
    local timeline="${3:-standard}"

    [[ "$RN_INITIALIZED" != "true" ]] && _rn_init

    RN_FEASIBILITY_CHECKS=$((RN_FEASIBILITY_CHECKS + 1))

    local feasibility=80  # ベースライン
    local effort="${_RN_REQ_EFFORT[$requirement]:-4}"

    # スタック互換性チェック
    case "$requirement" in
        *payment*)
            [[ "$stack" == "nextjs" ]] && feasibility=$((feasibility + 10))  # Stripe統合容易
            ;;
        *realtime*)
            [[ "$stack" == "nextjs" ]] && feasibility=$((feasibility - 5))  # Next.jsのWebSocket制限
            ;;
        *mobile*|*ios*)
            [[ "$stack" == "nextjs" ]] && feasibility=$((feasibility - 20))  # Web特化スタック
            ;;
    esac

    # タイムライン補正
    case "$timeline" in
        quick)
            [[ $effort -gt 5 ]] && feasibility=$((feasibility - 20))
            ;;
        standard)
            [[ $effort -gt 8 ]] && feasibility=$((feasibility - 10))
            ;;
        extended)
            feasibility=$((feasibility + 10))
            ;;
    esac

    [[ $feasibility -lt 0 ]] && feasibility=0
    [[ $feasibility -gt 100 ]] && feasibility=100

    _RN_REQ_FEASIBILITY["$requirement"]=$feasibility

    echo "$feasibility"
    return 0
}

# =============================================================================
# トレードオフ分析
# =============================================================================
_rn_analyze_tradeoffs() {
    [[ "$RN_INITIALIZED" != "true" ]] && _rn_init

    _RN_TRADEOFFS=()

    _RN_TRADEOFFS["speed_vs_quality"]="迅速な開発 vs 高品質コード: Enterprise Patternsの適用レベルで調整"
    _RN_TRADEOFFS["features_vs_simplicity"]="機能の豊富さ vs シンプルさ: MVP→段階拡張が推奨"
    _RN_TRADEOFFS["security_vs_ux"]="セキュリティ vs ユーザビリティ: 適切な認証フロー設計が鍵"
    _RN_TRADEOFFS["performance_vs_dev_speed"]="パフォーマンス vs 開発速度: 80/20の法則(ホットパスのみ最適化)"

    for key in "${!_RN_TRADEOFFS[@]}"; do
        echo "  [RN] トレードオフ: ${_RN_TRADEOFFS[$key]}" >&2
    done

    echo "${#_RN_TRADEOFFS[@]}"
    return 0
}

# =============================================================================
# 要件の優先順位付け
# =============================================================================
_rn_prioritize() {
    local requirements="$1"

    [[ "$RN_INITIALIZED" != "true" ]] && _rn_init

    local req_list
    IFS=' ' read -ra req_list <<< "$requirements"

    # MoSCoW法による分類
    local must=() should=() could=() wont=()

    for req in "${req_list[@]}"; do
        local feasibility="${_RN_REQ_FEASIBILITY[$req]:-70}"
        local effort="${_RN_REQ_EFFORT[$req]:-4}"

        if [[ "$req" == *"auth"* || "$req" == *"crud"* ]]; then
            must+=("$req")
            _RN_REQ_PRIORITY["$req"]="must"
        elif [[ $feasibility -gt 70 && $effort -le 5 ]]; then
            should+=("$req")
            _RN_REQ_PRIORITY["$req"]="should"
        elif [[ $feasibility -gt 50 ]]; then
            could+=("$req")
            _RN_REQ_PRIORITY["$req"]="could"
        else
            wont+=("$req")
            _RN_REQ_PRIORITY["$req"]="wont"
        fi
    done

    echo "MUST:${#must[@]} SHOULD:${#should[@]} COULD:${#could[@]} WONT:${#wont[@]}"
    return 0
}

# =============================================================================
# レポート
# =============================================================================
_rn_report() {
    echo -e "\n  ${BOLD:-}═══ Requirement Negotiation v${RN_VERSION} ═══${NC:-}"
    echo -e "  総要件数           : ${RN_TOTAL_REQUIREMENTS}"
    echo -e "  矛盾検出数         : ${RN_CONFLICTS_DETECTED}"
    echo -e "  代替案提案数       : ${RN_ALTERNATIVES_SUGGESTED}"
    echo -e "  実現可能性検証数   : ${RN_FEASIBILITY_CHECKS}"
}

_rn_score() {
    [[ "$RN_INITIALIZED" != "true" ]] && { echo "50"; return 0; }
    local s=60
    [[ $RN_TOTAL_REQUIREMENTS -gt 0 ]] && s=$((s + 10))
    [[ $RN_CONFLICTS_DETECTED -ge 0 ]] && s=$((s + 10))
    [[ $RN_ALTERNATIVES_SUGGESTED -gt 0 ]] && s=$((s + 10))
    [[ $RN_FEASIBILITY_CHECKS -gt 0 ]] && s=$((s + 10))
    [[ $s -gt 100 ]] && s=100
    echo "$s"
}

_rn_init_message() {
    echo -e "  ${GREEN:-}✅ v${RN_VERSION} requirement-negotiation: 要件交渉エンジン${NC:-}" >&2
}

# =============================================================================
# Module Registry 登録
# =============================================================================
_mr_register \
    --name "requirement-negotiation" \
    --version "$RN_VERSION" \
    --description "要件交渉エンジン" \
    --init "_rn_init" \
    --report "_rn_report" \
    --score "_rn_score" \
    --enable-var "ENABLE_REQUIREMENT_NEGOTIATION" \
    --cli-flags "--requirement-negotiation:--no-requirement-negotiation" \
    --init-msg "_rn_init_message"
